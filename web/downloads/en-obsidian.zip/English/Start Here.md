# English study

[[English|Open the complete English course note]]

Audio and the printable PDF are in Resources. This vault contains one language.

[[Sources and licenses]]
