# English

Highly advanced English - C2-oriented study

Everything for this language is in this note. Open a rule, read its examples and follow its practice link. Answers stay in this same note.

[[Start Here|All languages]] · [[Sources and licenses|Sources]]

## Start reading

### the alphabet

| Written form | Name / reading | Related forms |
|---|---|---|
| A a | ay  |  ·  ·  |
| B b | bee  |  ·  ·  |
| C c | see  |  ·  ·  |
| D d | dee  |  ·  ·  |
| E e | ee  |  ·  ·  |
| F f | ef  |  ·  ·  |
| G g | jee  |  ·  ·  |
| H h | aitch  |  ·  ·  |
| I i | eye  |  ·  ·  |
| J j | jay  |  ·  ·  |
| K k | kay  |  ·  ·  |
| L l | el  |  ·  ·  |
| M m | em  |  ·  ·  |
| N n | en  |  ·  ·  |
| O o | oh  |  ·  ·  |
| P p | pee  |  ·  ·  |
| Q q | cue  |  ·  ·  |
| R r | ar  |  ·  ·  |
| S s | ess  |  ·  ·  |
| T t | tee  |  ·  ·  |
| U u | you  |  ·  ·  |
| V v | vee  |  ·  ·  |
| W w | double-you  |  ·  ·  |
| X x | ex  |  ·  ·  |
| Y y | why  |  ·  ·  |
| Z z | zed (UK) / zee (US)  |  ·  ·  |

![[Resources/Audio/en/Script and first phrases.mp3]]

The player above is synthetic speech. Word tracks below work offline.

### Use the alphabet as a reference

You already read English. Keep this table for spelling aloud and move into the advanced grammar section. Letter names do not reliably predict pronunciation in words. English has many more vowel sounds than vowel letters.

### Read sound and stress together

Learn a word’s IPA, stressed syllable and recording together: record as a noun and record as a verb commonly differ in stress. schwa /ə/ is a frequent unstressed vowel. Connected speech changes the surface form while the written words remain the same.

### Use two accent models

The course contrasts contemporary standard southern British English and General American. General American is usually rhotic: /r/ in car. The southern British model usually drops post-vocalic /r/ before a pause/consonant. UK and US each contain many other accents. Listen to both model recordings and shadow phrases, not isolated letters.

### Build a word family

analyse/analyze → analysis → analytical. Word class, spelling and stress can change. un- reverses many adjectives; re- often means again; neither works freely with every word.

### Build natural combinations

make a decision, reach a conclusion, conduct research, strong evidence. A synonym does not automatically fit the same collocations. Research and evidence are normally uncountable in academic use.

### Compress without hiding meaning

The team revised the report. is clearer than The implementation of a revision was undertaken. Use nominalisation when it helps compare concepts, not to make every sentence longer.

**Could you clarify what you mean?**

Ask for a more precise explanation.

**The evidence suggests a possible association.**

State a cautious finding without claiming causation.

**I agree with the aim, but I have concerns about the method.**

Disagree with one specific aspect politely.

**Would you mind repeating the last point?**

Ask for repetition politely.

### Grammar terms in plain English

**Noun** — A word naming a person, thing or idea: student, book, freedom.

**Verb** — A word describing an action or state: read, know, be.

**Subject** — The participant linked to the main verb’s subject pattern. In The student reads a book, the student is the subject.

**Object** — A participant selected by a verb. In The student reads a book, a book is the direct object.

**Agreement** — One word changes to match another, for example an adjective matching a noun’s gender and number.

**Case** — A noun/pronoun form marking its relationship in a sentence. Cases can mark subjects, objects, possession or relations usually expressed by English prepositions.

**Gender** — A grammatical noun class. It does not always describe the sex of a person or any physical property.

**Tense** — A verb system that relates a situation to a time, often past or non-past.

**Aspect** — How a situation is viewed: unfolding, completed, habitual, experienced or in a resulting state.

**Infinitive** — A non-finite verb form often used for a dictionary entry or a complement. It does not by itself give the ordinary person/tense pattern.

**Participle** — A verb-derived form used in compound predicates or as a modifier; its exact function depends on the language and construction.

**Clause** — A unit organised around a predicate. One sentence can contain several clauses.

**Register** — Language choices suited to a situation: casual conversation, polite requests, academic writing or another context.

## Grammar, examples and practice

### Foundation repair: the noun phrase

English articles encode how a reader identifies a referent. Use a/an for a singular countable noun introduced as one member of a class, the for a sufficiently identifiable referent, and zero article for many general plural and uncountable expressions. Identifiability can come from context, not just previous mention. A hospital can be one unspecified institution; the hospital can be the locally relevant one. British in hospital and American in the hospital also illustrate conventional regional usage.
Countability belongs to a word's meaning in context. Research and evidence are normally uncountable in general academic English: some evidence, a piece of evidence, several studies. Experience can be uncountable knowledge or a countable event. Generic statements differ from specific ones: Scientists revise models; the scientists who conducted this study revised the model. Avoid deleting an article merely because Hindi has no matching article system.

**The evidence is persuasive, but it is not conclusive.**

A particular body of evidence supports a view without proving it decisively. Evidence is uncountable; persuasive and conclusive express different strengths.

**She has considerable experience, but this was an unusual experience.**

She has substantial accumulated knowledge; this event was unusual. The same noun changes countability with meaning.

#### Articles, countability and reference

Article choice reflects reference and countability. A/an selects a singular countable noun and follows the initial sound, not the first letter. Research and evidence are normally uncountable in academic uses; experience can change countability with meaning.

**This is the opposite of what I expected.**

मुझे जो अपेक्षा थी उसके यह विपरीत है।

**My grandfather was murdered during the Second World War.**

दूसरे विश्वयुद्ध के दौरान मेरे दादा का खून हुआ था।

![[Resources/Audio/en/Rule 01.mp3]]

[[English#^en-Q0001|Practise this rule (182 questions)]]

#### Quantifiers and agreement

Quantifiers interact with countability and agreement. Much/little often pair with uncountables, many/few with count plurals. Each/every usually selects singular agreement, while usage around either/neither can depend on the full construction.

**I drank too much. My face is swollen!**

मैंने कुछ ज़्यादा ही पी लिया है। मेरा पूरा चेहरा सूज गया है!

**How many letters does the Russian alphabet have?**

रूसी वर्णमाला में कितने अक्षर हैं?

![[Resources/Audio/en/Rule 16.mp3]]

[[English#^en-Q0629|Practise this rule (50 questions)]]

<details><summary>Correct: The researcher collected many evidences and gave an useful explanation.</summary>

The researcher collected substantial evidence and gave a useful explanation. Evidence is normally uncountable; useful begins with a consonant sound /j/.

</details>

<details><summary>Explain the difference between a solution and the solution.</summary>

A solution introduces one possible answer. The solution identifies a contextually known or uniquely relevant answer; it does not automatically mean the only imaginable solution.

</details>

### Time, aspect and narrative perspective

Tense and aspect are not interchangeable. The simple form can present a fact or event as a whole; the progressive presents an activity from inside its unfolding; the perfect relates an earlier situation to a reference time. I have worked here for years connects earlier work with the present. I worked there for years places it in a finished past frame. I had worked there for years makes a later past moment the reference point.
Stative verbs often resist a progressive in their ordinary meanings, but meanings can change: I think it is correct expresses an opinion; I am thinking about it describes an active process. Do not add a perfect merely to sound advanced. Use past simple with a finished past-time expression: I submitted it yesterday. In a narrative, establish the time frame clearly and use past perfect only where the earlier relationship needs marking.

**By the time the review began, we had already revised the report.**

The revision preceded the beginning of the review. Past perfect anchors one past event before another.

**I have been reading the report, but I have not finished it.**

Reading has occupied the recent period; completion has not occurred. Perfect progressive emphasises the activity, while the perfect marks the result.

#### Perfect auxiliaries and reference time

A perfect relates an earlier situation to a reference time. Have/has normally anchors the present; had anchors a past reference point. The auxiliary can also be ordinary possession, so inspect the participle and time phrase.

**Please give me the paper when you have done with it.**

जब आपने अखबार पढ़ लिया हो तो मुझे दे दीजिएगा।

**His health has enabled him to succeed in life.**

उसके स्वास्थ्य ने उसको ज़िन्दगी में कामयाब होने दिया है।

![[Resources/Audio/en/Rule 02.mp3]]

[[English#^en-Q0051|Practise this rule (50 questions)]]

#### Progressive perspective

A progressive presents a situation from within its unfolding. Stative versus dynamic interpretations matter. The -ing form also serves in non-finite clauses and noun-like uses, so an -ing word alone does not prove a progressive.

**One of the lights is not working. Do you think you could come take a look?**

एक बत्ती नहीं जल रही है। तुम ज़रा आकर देख सकते हो क्या?

**Are these the glasses you were looking for?**

क्या यह वह ऐनक है जिसे आप ढूँढ रहे थे ?

![[Resources/Audio/en/Rule 03.mp3]]

[[English#^en-Q0101|Practise this rule (34 questions)]]

#### Time-frame control

Time expressions help establish an interval/reference point but do not select a tense mechanically. Ago normally locates a finished past time. Since marks a starting point; for a duration in relevant uses.

**That was just the trailer, the movie's yet to come, my friend!**

यह तो बस ट्रेलर है, पिक्चर अभी बाकी है, मेरे दोस्त!

**The workers were laid off for three weeks.**

कर्मचारियों को तीन हफ़्तों के लिए काम से निकाल दिया गया।

![[Resources/Audio/en/Rule 17.mp3]]

[[English#^en-Q0679|Practise this rule (50 questions)]]

<details><summary>Explain: I have lived here for five years / I lived here for five years.</summary>

The first ordinarily includes the present. The second describes a finished period, though fuller context can refine that interpretation.

</details>

<details><summary>Correct: I have met her last Tuesday.</summary>

I met her last Tuesday. A finished, explicitly dated past event normally takes past simple.

</details>

### Modality, inference and counterfactuals

Modal verbs express different kinds of meaning: permission, obligation, ability, probability or inference. Must in You must submit the form is an obligation; must in She must have left is an inference. Must not is prohibition, while do not have to is absence of necessity. Could have can describe an unrealised possibility or an uncertain explanation; context decides.
Use counterfactual conditionals to control the relationship between condition and consequence. If we had checked, we would have noticed refers to an unrealised past. If I had accepted that job, I would live abroad now combines a past condition with a present consequence. Do not mechanically use would in every if-clause. Hedging is not vagueness: may, is likely to and must have commit to different strengths.

**The result may reflect a sampling bias.**

Sampling bias is a possible explanation. May marks possibility, not a demonstrated cause.

**If the records had been complete, we would know the answer now.**

Past incompleteness explains present uncertainty. Mixed conditional: past condition, present result.

#### Modal inference

Modal meaning depends on context: inference, permission, ability and obligation differ. Must have + participle commonly makes a past inference; might have leaves alternatives open. Absence of necessity is not prohibition.

**In order to stay awake I may have to drink more coffee.**

मुझे जगे रहने के लिए शायद और कॉफ़ी पीनी पड़ेगी।

**I was scared that you might leave me.**

मुझे डर था कि तुम मुझे छोड़ दोगे।

![[Resources/Audio/en/Rule 04.mp3]]

[[English#^en-Q0135|Practise this rule (50 questions)]]

#### Past modal constructions

Modal + have + participle relates modality to a prior event. Could have can mean unrealised opportunity or uncertain explanation. Match the speaker’s commitment and the intended timeline.

**Something must have happened to him on the way.**

उसके साथ रास्ते पर कुछ हुआ होगा।

**If I had known her address, I would have written to her.**

अगर मुझे उसका पता पता होता, तो मैंने उसे चिट्ठी लिखी हुई होती।

![[Resources/Audio/en/Rule 05.mp3]]

[[English#^en-Q0185|Practise this rule (12 questions)]]

#### Conditional relationships

Choose tense and modal forms according to reality and temporal relation. If + past perfect can describe an unreal past condition; a present consequence creates a mixed conditional. Unless is not a free substitute for every if not.

**Keep hold of my hand if you're afraid.**

मेरा हाथ पकड़लो अगर तुम्हे डर लग रहा है तो।

**Tom wouldn't be here if it wasn't for me.**

मैं ना होता तो टॉम आज यहाँ नहीं होता।

![[Resources/Audio/en/Rule 06.mp3]]

[[English#^en-Q0197|Practise this rule (50 questions)]]

<details><summary>Distinguish must not enter from do not have to enter.</summary>

Must not enter forbids entry. Do not have to enter allows staying out but does not forbid entering.

</details>

<details><summary>Make a cautious inference from an unanswered email without claiming certainty.</summary>

She may not have seen the message yet. This preserves alternative explanations.

</details>

### Information structure, inversion and emphasis

A grammatical sentence can still present information awkwardly. Place familiar information where it helps the reader connect to the preceding sentence, and reserve the end for a useful new focus. A cleft such as What matters is the quality of the evidence highlights one component. It was the second trial that failed contrasts that trial with others.
Negative or restrictive fronting can trigger subject-auxiliary inversion: Rarely do we see this pattern; Only after the review did we identify the error. If there is no auxiliary, introduce do in an appropriate tense. Not every initial adverb triggers inversion. Under no circumstances and not until are strong rhetorical choices; repeated inversion can sound theatrical in ordinary correspondence.

**Only after the second review did we identify the omission.**

The omission was identified after, not before, that review. Fronted restrictive phrase triggers did + subject + base verb.

**What the analysis establishes is a correlation.**

Correlation is the focused result. A wh-cleft controls emphasis and does not strengthen correlation into causation.

#### Negative and restrictive emphasis

Fronted negative/restrictive adverbials can trigger subject–auxiliary inversion. Only before the subject does not: Only Anna agreed. Scope and placement decide what the restriction actually excludes.

**The capital of Himachal Pradesh, Shimla, is only 115 kilometres away from Chandigarh.**

हिमाचल प्रदेश की राजधानी, शिमला, चण्डीगढ़ से केवल ११५ किलोमीटर की दूरी पर है।

**No matter what happens, I will never betray my friend.**

चाहे जो भी हो, मैं कभी भी अपने दोस्त को धोखा नहीं दूँगा।

![[Resources/Audio/en/Rule 07.mp3]]

[[English#^en-Q0247|Practise this rule (50 questions)]]

#### Cleft and focus structures

Clefts and related constructions organise focus: What matters is accuracy. A form such as what can also introduce a question or relative structure, so identify what the sentence highlights and its grammatical frame.

**It was the window that Tom broke yesterday.**

वह वह खिड़की है जिसको टॉम ने कल थोड़ा था।

**What were you and Tom doing in the attic?**

तुम और टौम पडछत्ती पर क्या कर रहे थे?

![[Resources/Audio/en/Rule 08.mp3]]

[[English#^en-Q0297|Practise this rule (50 questions)]]

<details><summary>Rewrite with fronted Never: I have never encountered this problem.</summary>

Never have I encountered this problem. The auxiliary precedes the subject.

</details>

<details><summary>Why is Only the supervisor approved it different?</summary>

Only modifies the subject itself, so it does not trigger subject-auxiliary inversion.

</details>

### Academic precision, evidence and synthesis

Distinguish reporting from endorsement. The author argues that introduces a position; the results indicate that presents evidence; it has been established that asserts a stronger consensus. Qualify scope explicitly: in this sample, under these conditions, over the study period. Statistical significance is not the same as practical importance.
Summarise the reasoning, not a sequence of disconnected quotations. A synthesis states how sources relate: agreement on observations but disagreement on mechanism; similar conclusions reached by different methods; or differences caused by population and measurement. Avoid nominalisations that hide agents or responsibility. The implementation of a revision occurred is usually less useful than The team revised the protocol.

**Although the findings are consistent with the hypothesis, they do not rule out alternative explanations.**

The evidence fits the hypothesis but does not establish exclusivity. Concession plus a limit on inference.

**The two accounts agree on the outcome but differ in their explanation of its cause.**

Their observations converge; their causal interpretations do not. Parallel structure makes the comparison precise.

#### Relative clauses

Relative forms connect an antecedent to a clause. Restrictive and supplementary clauses differ in punctuation and meaning. Whose expresses a possessive relation; whom is an object form mainly retained in formal contexts.

**The passengers who were injured in the accident were taken to the nearest hospital.**

जिन यात्रियों को दुर्घटना मे चोट आई थी उन्हे अस्पताल ले जाया गया।

**Mother Teresa was a Catholic nun who lived and worked in Calcutta, India.**

मदर टेरेसा एक कैथोलिक नन थीं जो कलकत्ता में रहतीं और काम करतीं थीं।

![[Resources/Audio/en/Rule 09.mp3]]

[[English#^en-Q0347|Practise this rule (50 questions)]]

#### Concession and limits on claims

Although introduces a finite concessive clause; despite usually takes a noun phrase or -ing construction. However/nevertheless link discourse differently. A concessive sentence can accept evidence while limiting the conclusion.

**Although fatalities tend to be rare, many people died as a result of volcanic eruptions during the last quarter century.**

घायलो की संख्या कम है पर पिछले सवा सौ वर्षों में ज्वालामुखी विस्फोटो के कारण बहुत लोग मरे है ।

**Though he is rich, he is not happy.**

वह अमीर हो कर भी ख़ुश नहीं है।

![[Resources/Audio/en/Rule 11.mp3]]

[[English#^en-Q0447|Practise this rule (8 questions)]]

#### Cause, purpose and consequence

Distinguish a reason, a purpose and an outcome. Since can be temporal or causal. Therefore signals a supported consequence; it does not itself prove a causal mechanism.

**I love life because what more is there.**

मैं जीवन से प्यार करता हूँ क्योंकि और है ही क्या।

**Because of his advice, I was able to succeed.**

मैं उसकी सलाह की वजह से कामयाब हो गया।

![[Resources/Audio/en/Rule 12.mp3]]

[[English#^en-Q0455|Practise this rule (50 questions)]]

<details><summary>We found an association. Rewrite without claiming causation.</summary>

The study found an association between the variables; the design does not establish that one caused the other.

</details>

<details><summary>Replace: The execution of the assessment was undertaken by the panel.</summary>

The panel conducted the assessment. A clear agent and verb improve readability.

</details>

### Register, diplomacy and professional control

Professional politeness combines clarity with proportionate consideration. A request can use Could you, Would you be able to or I would appreciate, but piling them together sounds cumbersome. Explain the practical reason and propose a next step. Tactful disagreement should identify the precise point: I agree with the overall aim; my concern is the assumption about cost.
Register depends on audience, medium and relationship. Contractions can be natural in many professional emails. Legal and technical contexts may require precise conventional language. Avoid importing casual idioms into a formal report, and avoid bureaucratic language in a message to a friend. A firm refusal can be courteous without becoming ambiguous.

**Could you confirm whether the revised deadline is feasible?**

Please assess the new deadline and reply. Whether introduces alternatives; feasible concerns practicality.

**I can support the proposal provided that the budget assumptions are clarified.**

Support is conditional on clarification. Provided that expresses a real condition politely.

#### Embedded questions

Embedded questions ordinarily have statement order: I wonder where she is. Whether can introduce explicit alternatives. Do not carry direct-question inversion into an ordinary embedded question.

**I don't know how to operate this computer.**

मुझे यह कम्प्यूटर चलाना नहीं आता।

**She's trying to whistle, but she doesn't know how.**

वह सीटी बजाने की कोशिश कर रही है, मगर उसे बजाने नहीं आती।

![[Resources/Audio/en/Rule 10.mp3]]

[[English#^en-Q0397|Practise this rule (50 questions)]]

#### Comparison and parallel structure

A comparison needs a clear standard and comparable structures. As ... as expresses equality; more/less ... than inequality. Ellipsis can omit understood material but should not create ambiguity.

**One thought driven home is better than three left on base.**

एक क्रियान्वित विचार तीन अधूरे विचारों से कहीं बेहतर है।

**The rich are not always happier than the poor.**

अमीर हमेशा गरीबों से ज़्यादा ख़ुश नहीं होते।

![[Resources/Audio/en/Rule 18.mp3]]

[[English#^en-Q0729|Practise this rule (50 questions)]]

#### Reported speech and stance

Reporting verbs encode stance and govern distinct complements. Say and tell differ in object requirements; suggest does not accept every pattern that advise accepts. Reporting a claim is not endorsing it.

**The doctor told her that she should take a rest.**

डॉक्टर ने उससे कहा कि उसे आराम लेना चाहिए।

**She told me that she wanted a pet dog.**

उसने मुझसे कहा कि उसे कुत्ता पालने का मन था।

![[Resources/Audio/en/Rule 19.mp3]]

[[English#^en-Q0779|Practise this rule (40 questions)]]

#### Hedging and professional modality

Hedges express different strengths and types of commitment. Could you is often a request, not a question about physical ability. Pair a precise request with a practical reason; avoid stacking several courtesy formulas.

**When he would not give them higher pay, they went on strike.**

जब उसने उनके वेतन बढ़ाने से इनकार कर दिया, उन्होंने हड़ताल कर दी।

**To investigate the incident would take us at least three weeks.**

हमको इस घटना की तहकीकात करने में कम-से-कम तीन हफ़्ते लगेंगे।

![[Resources/Audio/en/Rule 20.mp3]]

[[English#^en-Q0819|Practise this rule (50 questions)]]

<details><summary>Rewrite politely and clearly: You did not explain this. Send it now.</summary>

Could you clarify how this figure was calculated? We need the explanation before completing the review.

</details>

<details><summary>Write a firm refusal with an alternative.</summary>

We cannot complete the full review by Friday. We can deliver the priority findings then and the remaining analysis on Tuesday. The refusal stays explicit.

</details>

### Editing for style, rhythm and naturalness

Check collocation before choosing a sophisticated synonym: make a decision, reach a conclusion, pose a question, conduct research. Words can share a dictionary gloss yet differ in typical partners. Strong prose varies sentence length according to purpose. Use parallel syntax for parallel ideas and a short sentence for a decisive implication.
Ambiguous pronouns, dangling modifiers and misplaced negation can change meaning. After reviewing the evidence, the conclusion became clear incorrectly assigns the review to the conclusion. Repair the agent: After reviewing the evidence, we reached a clearer conclusion. Only can attach to different parts of a sentence; place it near its intended focus. Naturalness comes from contemporary examples, not a list of ornamental idioms.

**The policy is simple to explain, difficult to implement and expensive to maintain.**

Three comparable properties are listed. Parallel adjective + infinitive pattern creates coherence.

**We reviewed only the first report.**

The review was restricted to that report. Only scopes the object rather than the identity of the reviewers.

#### Passive and agency

A be form plus a past participle can build a passive; a be form alone can be a copula/progressive auxiliary. Passive voice helps manage focus but can also hide an agent. Restore the agent when responsibility matters.

**These texts were written in Hebrew, not in Aramaic.**

यह पाठ्य इब्रानी में लिखे थे, आरामाईक में नहीं।

**Their conversation was carried on for about an hour.**

उनकी बातचीत लगभग एक घंटे तक चलती रही।

![[Resources/Audio/en/Rule 13.mp3]]

[[English#^en-Q0505|Practise this rule (50 questions)]]

#### Non-finite complements

Complement patterns belong to the governing word: decide to act, avoid acting, insist on acting. To can be infinitive marker or preposition. Do not assume a synonym accepts the same complement pattern.

**Traveling by boat takes longer than going by car.**

नाव के सफ़र में कार से ज्यादा समय लगता है.

**Goals determine what you are going to be.**

हमारे लक्ष्य निर्धारित करते हैं कि हम क्या बनने जा रहे हैं।

![[Resources/Audio/en/Rule 14.mp3]]

[[English#^en-Q0555|Practise this rule (50 questions)]]

#### Pronoun reference and reflexives

A reflexive typically refers back to an appropriate antecedent. It can also add emphasis. Professional style does not require replacing me with myself when no reflexive relation exists.

**Maybe I am unhappy, but I don't intend to kill myself.**

हाँ शायद मैं दुखी हूँ, पर मुझे अपनी जान लेने का इरादा नहीं है।

**When you betray somebody else, you also betray yourself.**

आप किसी व्यक्ति को धोखा देते हैं तो आप अपने आप को भी धोखा देते हैं।

![[Resources/Audio/en/Rule 15.mp3]]

[[English#^en-Q0605|Practise this rule (24 questions)]]

<details><summary>Correct the dangling modifier: Walking into the room, the results were surprising.</summary>

When I walked into the room, I was surprised by the results. The person doing the walking is explicit.

</details>

<details><summary>Improve: We did a conclusion after making research.</summary>

We reached a conclusion after conducting research. Collocations and uncountable research are repaired.

</details>

### UK and US accents: choosing reference models

Accent is pronunciation; dialect also includes grammar and vocabulary. The UK includes London, northern English, Scottish, Welsh and Northern Irish varieties, among many others. The US includes regional and social varieties beyond General American. The two reference models here are useful learning anchors, not national uniformity.
A major distinction is rhoticity. Most General American speech pronounces /r/ after a vowel in car and hard. Many southern British varieties do not pronounce that /r/ before a consonant or pause, but may link it before a following vowel: far away. Scottish and some other UK varieties are rhotic. In General American, /r/ can be bunched or retroflex; do not replace it with a Hindi tap or trill when practising that model.
Record the same paragraph in your chosen reference model. First compare /r/, then vowels, then rhythm. Preserve intelligibility before pursuing subtle regional features.

**car: reference UK /kɑː/; reference US /kɑr/**

The US model retains post-vocalic /r/. The vowel quality and exact /r/ vary by speaker.

**far away: UK linking /r/ may occur before the vowel of away.**

A non-rhotic speaker can pronounce /r/ at a word boundary before a vowel. Non-rhotic does not mean deleting every written r.

<details><summary>Which words expose rhoticity: red, hard, very, teacher?</summary>

Hard and teacher before a pause expose post-vocalic /r/. Red and very have /r/ before a vowel in both reference models.

</details>

<details><summary>Should Scottish speech be described as non-rhotic UK English?</summary>

No. Many Scottish varieties are rhotic; national labels are too broad.

</details>

### UK and US vowels and consonants

Learn contrasts through sound, not spelling. A common southern British distinction in the BATH set gives bath and dance /ɑː/, while General American commonly uses /æ/. Many northern English accents also use a short /a/-type vowel in these words. Reference British hot has /ɒ/; General American typically has an /ɑ/-type vowel. The LOT/THOUGHT merger varies across US speakers.
In many American accents, /t/ and /d/ can become a flap [ɾ] between appropriate vowel sounds when the following syllable is unstressed, as in writer and ladder. This is not the rule that every t becomes d. British /t/ can be clearly released, unreleased or glottalised depending on context and speaker. General American often has a more widespread dark /l/; both reference models can have dark /l/ in final positions. Practise contrasts with a recording rather than exaggerating a national stereotype.

**bath: reference UK /bɑːθ/; reference US /bæθ/**

The reference vowels differ; both end with /θ/. This distinction does not describe every British accent.

**writer can contain a flap [ɾ] in General American.**

The medial consonant may resemble a brief tap. It is context-dependent and should not be replaced mechanically with a full /d/.

<details><summary>Practise thin /θɪn/ and then /ðen/. What changes?</summary>

The tongue is near the teeth in both. /θ/ is voiceless and /ð/ voiced. Avoid consistently substituting /t/, /d/ or /s/ if the distinction affects clarity.

</details>

<details><summary>Why is a single rule for US hot and caught unreliable?</summary>

Some American speakers merge their vowels and others distinguish them. Select a real model speaker and follow that system consistently.

</details>

### Connected speech, stress, rhythm and intonation

English speech groups words into meaning units. Content words often carry prominence; grammatical words often weaken, but contrast can make any word prominent. To commonly weakens to /tə/ and and to /ən/ in suitable unstressed contexts. These reductions belong to speech; do not write gonna in a formal report merely because you hear it.
The location of sentence stress can change the implied correction: I wanted the BLUE one contrasts colour; I WANTED the blue one contrasts intention with some other relation. Use pauses to clarify clause boundaries and reserve the main pitch movement for the intended focus. English is often described as stress-timed, but do not force mechanically equal intervals between stressed syllables. Natural timing varies with speaker and situation.
For practice, mark thought groups with a vertical bar, underline prominent words and record. Compare whether listeners hear the intended contrast, not just whether the recording sounds fast.

**I said she could BORROW it, not keep it.**

Borrowing rather than ownership is the contrast. The prominence carries the correction.

**Although the sample was small | the pattern was consistent.**

A concession is followed by the main observation. A thought-group boundary supports interpretation.

<details><summary>Say: I did not say he stole it. Move stress to I, say, he and stole.</summary>

Each placement suggests a different correction: speaker, wording, person or action. Explain the intended implication before recording.

</details>

<details><summary>Make a 30-second accent practice log.</summary>

Record the model, your attempt and one measurable focus, such as maintaining /θ/ in three words. Do not rate yourself solely on speed.

</details>

### Regional vocabulary, spelling and advanced reading

UK/US distinctions include colour/color, centre/center, pavement/sidewalk and flat/apartment. Usage overlaps and terminology depends on context: first floor is above the ground floor in typical British building numbering, but commonly ground level in US numbering. Check the actual location. Collective agreement also varies: British the team are can emphasise members; American the team is is more usual as a default. Both systems allow contextual choices.
Original teaching passage: A public debate can become polarised even when participants agree on the observations. They may disagree about which risks deserve priority, or about who should bear the cost of reducing them. A careful reader therefore separates empirical disagreement from disagreement over values. Recognising that distinction does not settle the debate, but it makes the reasoning easier to evaluate.
The passage uses concession, modal possibility, embedded questions and a limited conclusion. Notice that may avoids asserting a universal explanation. Read it aloud in your chosen reference accent without changing its formal register.

**Participants may disagree about who should bear the cost.**

The disagreement can concern responsibility for cost. The embedded question keeps declarative word order.

**Recognising the distinction does not settle the debate.**

Analysis improves clarity without guaranteeing agreement. The gerund clause serves as subject; negation limits the claim.

<details><summary>Summarise the passage in 40 words.</summary>

Debates may reflect differences in values and risk priorities rather than observations. Separating these forms of disagreement helps evaluate reasoning, although it does not itself produce agreement.

</details>

<details><summary>Write two professional versions of an email, one with consistent UK spelling and one with US spelling.</summary>

Check consistency, terminology and audience expectations. Neither version should become a caricature of national speech.

</details>

## Word bank and recordings

1,000 study entries, based on dictionary selections and authored teaching glosses. Learn a word in a phrase; consult the linked entry for additional senses.

<details><summary>Words 1–50</summary>

![[Resources/Audio/en/Words 0001-0050.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [caught](https://en.wiktionary.org/wiki/caught#English) | captured; past tense and participle of catch | /kɔːt/ · verb |
| [disease](https://en.wiktionary.org/wiki/disease#English) | An abnormal condition of a human, animal or plant that causes discomfort or dysfunction; distinct from injury insofar as the latter is usually instantaneously acquired. | /dɪˈziːz/ · noun |
| [doctor](https://en.wiktionary.org/wiki/doctor#English) | a medical practitioner; also a holder of a doctorate | /ˈdɒktə(ɹ)/ · noun |
| [doubt](https://en.wiktionary.org/wiki/doubt#English) | To consider questionable or unlikely; to hesitate to believe; to lack confidence in; to question. | /daʊt/ · verb |
| [drink](https://en.wiktionary.org/wiki/drink#English) | To consume (a liquid) through the mouth. | /ˈdɹɪŋk/ · verb |
| [fish](https://en.wiktionary.org/wiki/fish#English) | A typically cold-blooded vertebrate animal that lives in water, moving with the help of fins and breathing with gills; any vertebrate that is not a tetrapod. | /fɪʃ/ · noun |
| [grow](https://en.wiktionary.org/wiki/grow#English) | To become larger, to increase in magnitude. | /ˈɡɹəʊ/ · verb |
| [machine](https://en.wiktionary.org/wiki/machine#English) | A device that directs and controls energy, often in the form of movement or electricity, to produce a certain effect. | /məˈʃiːn/ · noun |
| [sit](https://en.wiktionary.org/wiki/sit#English) | To be in a position in which the upper body is upright and supported by the buttocks. | /sɪt/ · verb |
| [crime](https://en.wiktionary.org/wiki/crime#English) | A specific act committed in violation of the law, especially criminal law. | /kɹaɪm/ · noun |
| [male](https://en.wiktionary.org/wiki/male#English) | Belonging to the sex which typically produces sperm, or to the gender which is typically associated with it. | /meɪl/ · adj |
| [plant](https://en.wiktionary.org/wiki/plant#English) | An organism that is not an animal, especially an organism capable of photosynthesis, and typically a small or herbaceous organism of this kind, rather than a tree. | /plɑːnt/ · noun |
| [reality](https://en.wiktionary.org/wiki/reality#English) | The state of being actual or real; realness. | /ɹiːˈælɪti/ · noun |
| [winter](https://en.wiktionary.org/wiki/winter#English) | The period of decay, old age, death, or the like. | /ˈwɪntə/ · noun |
| [Christian](https://en.wiktionary.org/wiki/Christian#English) | A believer in Christianity. | /ˈkɹɪʃt͡ʃən/ · noun |
| [advice](https://en.wiktionary.org/wiki/advice#English) | An opinion offered to guide behavior in an effort to be helpful. | /ədˈvaɪs/ · noun |
| [agreement](https://en.wiktionary.org/wiki/agreement#English) | An understanding between entities to follow a specific course of conduct. | /əˈɡɹiːmənt/ · noun |
| [broken](https://en.wiktionary.org/wiki/broken#English) | Fragmented; in separate pieces. | /ˈbɹəʊ.kn̩/ · adj |
| [eventually](https://en.wiktionary.org/wiki/eventually#English) | In the end; at some later time, especially after a long time, a series of problems, struggles, delays or setbacks. | /ɪˈvɛn.t͡ʃuː.ə.li/ · adv |
| [theory](https://en.wiktionary.org/wiki/theory#English) | A description of an event or system that is considered to be accurate. | /ˈθɪə.ɹi/ · noun |
| [Saturday](https://en.wiktionary.org/wiki/Saturday#English) | The seventh day of the week in many religious traditions, and the sixth day of the week in systems using the ISO 8601 norm; the Jewish Sabbath; it follows Friday and precedes Sunday. | /ˈsæt.ə.deɪ/ · noun |
| [camera](https://en.wiktionary.org/wiki/camera#English) | A device for taking still or moving pictures or photographs. | /ˈkæməɹə/ · noun |
| [catch](https://en.wiktionary.org/wiki/catch#English) | The act of seizing or capturing. | /kæt͡ʃ/ · noun |
| [cell](https://en.wiktionary.org/wiki/cell#English) | A single-room dwelling for a hermit. | /sɛl/ · noun |
| [drug](https://en.wiktionary.org/wiki/drug#English) | A substance used to treat an illness, relieve a symptom, or modify a chemical process in the body for a specific purpose. | /ˈdɹʌɡ/ · noun |
| [environment](https://en.wiktionary.org/wiki/environment#English) | The surroundings of, and influences on, a particular item of interest. | /ɪnˈvaɪ.ɹə.mənt/ · noun |
| [foot](https://en.wiktionary.org/wiki/foot#English) | A biological structure found in many animals that is used for locomotion and that is frequently a separate organ at the terminal part of the leg. | /fʊt/ · noun |
| [mass](https://en.wiktionary.org/wiki/mass#English) | A quantity of matter cohering so as to make one body, or an aggregation of particles or things which collectively make one body or quantity, usually of considerable size. | /mæs/ · noun |
| [nine](https://en.wiktionary.org/wiki/nine#English) | A numerical value equal to 9; the number following eight and preceding ten. | /naɪn/ · num |
| [politics](https://en.wiktionary.org/wiki/politics#English) | A methodology and activities associated with the interpersonal aspects of running a government, an organization, or a movement. | /ˈpɒl.ɪ.tɪks/ · noun |
| [ran](https://en.wiktionary.org/wiki/ran#English) | Yarns coiled on a spun-yarn winch. | /ɹæn/ · noun |
| [therefore](https://en.wiktionary.org/wiki/therefore#English) | Consequently, by or in consequence of that or this cause; referring to something previously stated. | /ˈðɛə.fɔː/ · adv |
| [weather](https://en.wiktionary.org/wiki/weather#English) | The short-term state of the atmosphere at a specific time and place, including the temperature, relative humidity, cloud cover, precipitation, wind, etc. | /ˈwɛðə/ · noun |
| [activity](https://en.wiktionary.org/wiki/activity#English) | The state or quality of being active; activeness. | /ækˈtɪv.ɪ.ti/ · noun |
| [coffee](https://en.wiktionary.org/wiki/coffee#English) | A beverage made by infusing the beans of the coffee plant in hot water. | /ˈkɒfi/ · noun |
| [complex](https://en.wiktionary.org/wiki/complex#English) | Made up of multiple parts; composite; not simple. | /ˈkɒmplɛks/ · adj |
| [condition](https://en.wiktionary.org/wiki/condition#English) | A state or quality. | /kənˈdɪʃ(ə)n/ · noun |
| [google](https://en.wiktionary.org/wiki/google#English) | To bowl (a cricket ball) so that it performs a googly (“a ball by a leg-break bowler that spins from off to leg (to a right-handed batsman), unlike a normal leg-break delivery”). | /ˈɡuː.ɡəl/ · verb |
| [queen](https://en.wiktionary.org/wiki/queen#English) | The wife, consort, or widow of a king. | /kwiːn/ · noun |
| [accept](https://en.wiktionary.org/wiki/accept#English) | To receive, especially with a consent, with favour, or with approval. | /əkˈsɛpt/ · verb |
| [attempt](https://en.wiktionary.org/wiki/attempt#English) | To try. | /əˈtɛm(p)t/ · verb |
| [broke](https://en.wiktionary.org/wiki/broke#English) | Financially ruined, bankrupt. | /ˈbɹəʊ̯k/ · adj |
| [distance](https://en.wiktionary.org/wiki/distance#English) | An amount of space between points (often geographical points), usually (but not necessarily) measured along a straight line. | /ˈdɪst(ə)n(t)s/ · noun |
| [fell](https://en.wiktionary.org/wiki/fell#English) | To make something fall, especially a tree. | /fɛl/ · verb |
| [learned](https://en.wiktionary.org/wiki/learned#English) | Having much learning, knowledgeable, erudite; highly educated. | /ˈlɜːnɪd/ · adj |
| [mobile](https://en.wiktionary.org/wiki/mobile#English) | Capable of being moved, especially on wheels. | /ˈməʊ.baɪl/ · adj |
| [ride](https://en.wiktionary.org/wiki/ride#English) | To transport oneself by sitting on and directing a horse, later also a bicycle etc. | /ɹaɪd/ · verb |
| [slow](https://en.wiktionary.org/wiki/slow#English) | Taking a long time to move or go a short distance, or to perform an action; not quick in motion; proceeding at a low speed. | /sləʊ/ · adj |
| [species](https://en.wiktionary.org/wiki/species#English) | A type or kind. (Compare race.) | /ˈspiːʃiːz/ · noun |
| [traffic](https://en.wiktionary.org/wiki/traffic#English) | Moving pedestrians or vehicles, or the flux or passage thereof. | /ˈtɹæfɪk/ · noun |

</details>

<details><summary>Words 51–100</summary>

![[Resources/Audio/en/Words 0051-0100.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [tree](https://en.wiktionary.org/wiki/tree#English) | A perennial woody plant taller and larger than a shrub with a wooden trunk and, at some distance from the ground, having leaves and branches. | /tɹiː/ · noun |
| [whom](https://en.wiktionary.org/wiki/whom#English) | As the object of a verb. | /huːm/ · pron |
| [begin](https://en.wiktionary.org/wiki/begin#English) | To start, to initiate or take the first step into something. | /bɪˈɡɪn/ · verb |
| [engine](https://en.wiktionary.org/wiki/engine#English) | A large construction used in warfare, such as a battering ram, catapult etc. | /ˈɛnd͡ʒɪn/ · noun |
| [everybody](https://en.wiktionary.org/wiki/everybody#English) | Every individual in a set; all people. | /ˈɛv.ɹi.bɒ.di/ · pron |
| [investment](https://en.wiktionary.org/wiki/investment#English) | The act of investing, or state of being invested. | /ɪnˈvɛstmənt/ · noun |
| [lie](https://en.wiktionary.org/wiki/lie#English) | To rest in a horizontal position on a surface. | /laɪ̯/ · verb |
| [southern](https://en.wiktionary.org/wiki/southern#English) | Of, facing, situated in, or related to the south. | /ˈsʌðən/ · adj |
| [square](https://en.wiktionary.org/wiki/square#English) | A polygon with four straight sides of equal length and four right angles; an equilateral rectangle; a regular quadrilateral. | /skwɛə(ɹ)/ · noun |
| [wind](https://en.wiktionary.org/wiki/wind#English) | Real or perceived movement of atmospheric air usually caused by convection or differences in air pressure. | /ˈwɪnd/ · noun |
| [count](https://en.wiktionary.org/wiki/count#English) | To recite numbers in sequence. | /kaʊnt/ · verb |
| [digital](https://en.wiktionary.org/wiki/digital#English) | Having to do with digits (fingers or toes); especially, performed with a finger. | /ˈdɪd͡ʒɪtl̩/ · adj |
| [fourth](https://en.wiktionary.org/wiki/fourth#English) | The ordinal form of the number four. | /fɔːθ/ · adj |
| [fresh](https://en.wiktionary.org/wiki/fresh#English) | Newly produced or obtained; recent. | /fɹɛʃ/ · adj |
| [lake](https://en.wiktionary.org/wiki/lake#English) | A large, landlocked stretch of water or similar liquid. | /leɪk/ · noun |
| [mental](https://en.wiktionary.org/wiki/mental#English) | Occurring or experienced in the mind. | /ˈmɛn.təl/ · adj |
| [mouth](https://en.wiktionary.org/wiki/mouth#English) | The front opening of a creature through which food is ingested. | /maʊθ/ · noun |
| [separate](https://en.wiktionary.org/wiki/separate#English) | To divide (a thing) into separate parts. | /ˈsɛp.əˌɹeɪt/ · verb |
| [throw](https://en.wiktionary.org/wiki/throw#English) | To hurl; to release (an object) with some force from one’s hands, an apparatus, etc. so that it moves rapidly through the air. | /θɹəʊ/ · verb |
| [benefit](https://en.wiktionary.org/wiki/benefit#English) | An advantage; help or aid from something. | /ˈbɛn.ɪ.fɪt/ · noun |
| [feature](https://en.wiktionary.org/wiki/feature#English) | A component that draws attention or interest. | /ˈfiː.t͡ʃəː/ · noun |
| [generation](https://en.wiktionary.org/wiki/generation#English) | The act of creating something or bringing something into being; production, creation. | /ˌd͡ʒɛnəˈɹeɪʃən/ · noun |
| [jack](https://en.wiktionary.org/wiki/jack#English) | A coarse medieval coat of defence, especially one made of leather. | /ˈd͡ʒæk/ · noun |
| [metal](https://en.wiktionary.org/wiki/metal#English) | Any of a number of chemical elements in the periodic table that form a metallic bond with other metal atoms; generally shiny, somewhat malleable and hard, often a conductor of heat and electricity. | /ˈmɛ.təl/ · noun |
| [profile](https://en.wiktionary.org/wiki/profile#English) | The outermost shape, view, or edge of an object. | /ˈpɹəʊ.faɪl/ · noun |
| [pull](https://en.wiktionary.org/wiki/pull#English) | To apply a force to (an object) so that it comes toward the person or thing applying the force. | /pʊl/ · verb |
| [push](https://en.wiktionary.org/wiki/push#English) | To apply a force to (an object) such that it moves away from the person or thing applying the force. | /pʊʃ/ · verb |
| [rose](https://en.wiktionary.org/wiki/rose#English) | A shrub of the genus Rosa, with red, pink, white or yellow flowers. | /ɹəʊz/ · noun |
| [Japanese](https://en.wiktionary.org/wiki/Japanese#English) | Of, relating to, derived from, or characteristic of Japan, its people, language, or culture. | /ˌdʒæp.əˈniːz/ · adj |
| [animal](https://en.wiktionary.org/wiki/animal#English) | Any member of the kingdom Animalia other than a human. | /ˈænɪməl/ · noun |
| [authority](https://en.wiktionary.org/wiki/authority#English) | Power or right to make or enforce rules, give orders, or impose obligation; or a position having such power or right. | /ɔːˈθɒɹəti/ · noun |
| [basis](https://en.wiktionary.org/wiki/basis#English) | A physical base or foundation. | /ˈbeɪ.sɪs/ · noun |
| [draw](https://en.wiktionary.org/wiki/draw#English) | To pull (someone or something) in a particular direction or manner. | /dɹɑ/ · verb |
| [gain](https://en.wiktionary.org/wiki/gain#English) | To acquire possession of. | /ɡeɪn/ · verb |
| [ring](https://en.wiktionary.org/wiki/ring#English) | A circumscribing object, (roughly) circular and hollow, looking like an annual ring, earring, finger ring etc. | /ɹɪŋ/ · noun |
| [rise](https://en.wiktionary.org/wiki/rise#English) | To move upwards. | /ɹaɪz/ · verb |
| [silver](https://en.wiktionary.org/wiki/silver#English) | A lustrous, white, metallic element, atomic number 47, atomic weight 107.87, symbol Ag. | /ˈsɪl.və/ · noun |
| [spread](https://en.wiktionary.org/wiki/spread#English) | To stretch out, open out (a material etc.) so that it more fully covers a given area of space. | /spɹɛd/ · verb |
| [Monday](https://en.wiktionary.org/wiki/Monday#English) | The second day of the week in many religious traditions, and the first day of the week in systems using the ISO 8601 norm. It follows Sunday and precedes Tuesday. | /ˈmʌn.deɪ/ · noun |
| [adult](https://en.wiktionary.org/wiki/adult#English) | An animal that is full-grown. | /ˈæd.ʌlt/ · noun |
| [chairman](https://en.wiktionary.org/wiki/chairman#English) | A person presiding over a meeting, sometimes especially a man. (Compare chairwoman, chairperson, chair.) | /ˈtʃɛːmən/ · noun |
| [somebody](https://en.wiktionary.org/wiki/somebody#English) | Some unspecified person. | /ˈsʌmˌbɒdi/ · pron |
| [stone](https://en.wiktionary.org/wiki/stone#English) | A hard earthen substance that can form rocks; especially, such substance when regarded as a building material. | /stəʊ̯n/ · noun |
| [window](https://en.wiktionary.org/wiki/window#English) | An opening, usually covered by one or more panes of clear glass, to allow light and air from outside to enter a building or vehicle. | /ˈwɪndəʊ/ · noun |
| [bag](https://en.wiktionary.org/wiki/bag#English) | A soft container made out of cloth, paper, thin plastic, etc. and open at the top, used to hold food, commodities, and other goods. | /bæɡ/ · noun |
| [bet](https://en.wiktionary.org/wiki/bet#English) | A wager, an agreement between two parties that a stake (usually money) will be paid by the loser to the winner (the winner being the one who correctly forecast the outcome of an event). | /bɛt/ · noun |
| [cast](https://en.wiktionary.org/wiki/cast#English) | To move, or be moved, away. | /kɑːst/ · verb |
| [correct](https://en.wiktionary.org/wiki/correct#English) | Free from error; true; accurate. | /kəˈɹɛkt/ · adj |
| [handle](https://en.wiktionary.org/wiki/handle#English) | The part of an object which is (designed to be) held in the hand when used or moved. | /ˈhæn.d(ə)l/ · noun |
| [cat](https://en.wiktionary.org/wiki/cat#English) | A mammal of the family Felidae. | /ˈkæt/ · noun |

</details>

<details><summary>Words 101–150</summary>

![[Resources/Audio/en/Words 0101-0150.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [fifth](https://en.wiktionary.org/wiki/fifth#English) | The ordinal form of the number five. | /fɪfθ/ · adj |
| [herself](https://en.wiktionary.org/wiki/herself#English) | Her; the feminine object of a verb or preposition that also appears as the subject. | /hɜːˈsɛlf/ · pron |
| [shut](https://en.wiktionary.org/wiki/shut#English) | To remove or block an opening, gap or passage through. | /ʃʌt/ · verb |
| [van](https://en.wiktionary.org/wiki/van#English) | An enclosed railway vehicle for transport of goods, such as a boxcar/box van. | /væn/ · noun |
| [wood](https://en.wiktionary.org/wiki/wood#English) | The substance making up the central part of the trunk and branches of a tree. Used as a material for construction, to manufacture various items, etc. or as fuel. | /wʊd/ · noun |
| [birth](https://en.wiktionary.org/wiki/birth#English) | The process of childbearing; the beginning of life; the emergence of a human baby or other viviparous animal offspring from the mother's body into the environment. | /bɜːθ/ · noun |
| [bridge](https://en.wiktionary.org/wiki/bridge#English) | A construction spanning a waterway, ravine, or valley from a height, allowing for the passage of vehicles, pedestrians, trains, etc. | /bɹɪd͡ʒ/ · noun |
| [dear](https://en.wiktionary.org/wiki/dear#English) | High in price; expensive. | /dɪə/ · adj |
| [garden](https://en.wiktionary.org/wiki/garden#English) | An outdoor area containing one or more types of plants, usually plants grown for food or ornamental purposes. | /ˈɡɑː.d(ə)n/ · noun |
| [prove](https://en.wiktionary.org/wiki/prove#English) | To demonstrate that something is true or viable; to give proof for; to bear out; to testify. | /ˈpɹuːv/ · verb |
| [software](https://en.wiktionary.org/wiki/software#English) | programs and instructions used by a computer | /ˈsɒf(t)ˌwɛə/ · noun |
| [ad](https://en.wiktionary.org/wiki/ad#English) | Advantage; also, designating the left-hand side, from the player's point of view, of their half of the court, where the advantage point following a deuce is always played. | /æd/ · noun |
| [apple](https://en.wiktionary.org/wiki/apple#English) | The fruit of the tree Malus domestica, chiefly with a green, red, or yellow skin, cultivated in temperate climates for cidermaking, cooking, and eating. | /ˈæpəl/ · noun |
| [balance](https://en.wiktionary.org/wiki/balance#English) | A state in which opposing forces harmonise; equilibrium. | /ˈbæləns/ · noun |
| [boss](https://en.wiktionary.org/wiki/boss#English) | One who oversees and directs the work of others; a supervisor. | /bɒs/ · noun |
| [connection](https://en.wiktionary.org/wiki/connection#English) | The act of connecting. | /kəˈnɛkʃ(ə)n/ · noun |
| [map](https://en.wiktionary.org/wiki/map#English) | A visual representation of an area, whether real or imaginary, showing the relative positions of places and other features. | /mæp/ · noun |
| [stick](https://en.wiktionary.org/wiki/stick#English) | A small, thin branch from a tree or bush; a twig; a branch. | /stɪk/ · noun |
| [volume](https://en.wiktionary.org/wiki/volume#English) | A three-dimensional measure of space that comprises a length, a width and a height. It is measured in units of cubic centimeters in metric, cubic inches or cubic feet in English measurement. | /ˈvɒl.juːm/ · noun |
| [wake](https://en.wiktionary.org/wiki/wake#English) | (often followed by up) To stop sleeping. | /ˈweɪ̯k/ · verb |
| [billion](https://en.wiktionary.org/wiki/billion#English) | a thousand million (logic: 1,000 × 1,000²): 1 followed by nine zeros, 10⁹. | /ˈbɪljən/ · num |
| [criminal](https://en.wiktionary.org/wiki/criminal#English) | Against the law; forbidden by law. | /ˈkɹɪm.ɪ.nəl/ · adj |
| [file](https://en.wiktionary.org/wiki/file#English) | A collection of papers collated and archived together. | /faɪl/ · noun |
| [fly](https://en.wiktionary.org/wiki/fly#English) | Any insect of the order Diptera; characterized by having two wings (except for some wingless species), also called true flies. | /flaɪ/ · noun |
| [yours](https://en.wiktionary.org/wiki/yours#English) | That or those belonging to you; the possessive second-person singular pronoun used without a following noun. | /jɔːz/ · pron |
| [dry](https://en.wiktionary.org/wiki/dry#English) | Free from or lacking moisture. | /ˈdɹaɪ̯/ · adj |
| [evil](https://en.wiktionary.org/wiki/evil#English) | Intending to harm; malevolent. | /ˈiːvəl/ · adj |
| [forever](https://en.wiktionary.org/wiki/forever#English) | For all time, for all eternity; for a lifetime; for an infinite amount of time. | /fəˈɹɛvə(ɹ)/ · adv |
| [henry](https://en.wiktionary.org/wiki/henry#English) | A turd. |  · noun |
| [iron](https://en.wiktionary.org/wiki/iron#English) | A common, inexpensive metal, silvery grey when untarnished, that rusts, is attracted by magnets, and is used in making steel: a chemical element having atomic number 26 and symbol Fe. | /ˈaɪ.ən/ · noun |
| [religion](https://en.wiktionary.org/wiki/religion#English) | Belief in a spiritual or metaphysical reality (often including at least one deity), accompanied by practices or rituals pertaining to the belief. | /ɹɪˈlɪd͡ʒ.ən/ · noun |
| [wine](https://en.wiktionary.org/wiki/wine#English) | An alcoholic beverage made by fermenting grape juice, with an ABV ranging from 5.5–16%. | /ˈwaɪ̯n/ · noun |
| [Spanish](https://en.wiktionary.org/wiki/Spanish#English) | Of or pertaining to Spain. | /ˈspænɪʃ/ · adj |
| [arm](https://en.wiktionary.org/wiki/arm#English) | The portion of the upper human appendage, from the shoulder to the wrist and sometimes including the hand. | /ɑːm/ · noun |
| [lies](https://en.wiktionary.org/wiki/lies#English) | Great, wonderful | /laɪz/ · adj |
| [medicine](https://en.wiktionary.org/wiki/medicine#English) | A substance which specifically promotes healing when ingested or consumed in some way; a pharmaceutical drug. | /ˈmɛd.ɪ.s(ɪ)n/ · noun |
| [mountain](https://en.wiktionary.org/wiki/mountain#English) | An elevation of land of considerable dimensions rising more or less abruptly, forming a conspicuous figure in the landscape, usually having a small extent of surface at its summit. | /ˈmaʊn.tɪn/ · noun |
| [port](https://en.wiktionary.org/wiki/port#English) | A place on the coast at which ships can shelter, or dock to load and unload cargo or passengers. | /pɔːt/ · noun |
| [shoot](https://en.wiktionary.org/wiki/shoot#English) | To fire (a weapon that releases a bullet or other projectile). | /ʃuːt/ · verb |
| [solid](https://en.wiktionary.org/wiki/solid#English) | That can be picked up or held, having a texture, and usually firm. Unlike a liquid, gas or plasma. | /ˈsɒl.ɪd/ · adj |
| [classic](https://en.wiktionary.org/wiki/classic#English) | Of or relating to the first class or rank, especially in literature or art. | /ˈklæsɪk/ · adj |
| [electric](https://en.wiktionary.org/wiki/electric#English) | Of, relating to, produced by, operated with, or utilising electricity; electrical. | /ɪˈlɛktɹɪk/ · adj |
| [flat](https://en.wiktionary.org/wiki/flat#English) | Having no variations in height. | /ˈflæt/ · adj |
| [hello](https://en.wiktionary.org/wiki/hello#English) | A greeting (salutation) said when meeting someone or acknowledging someone’s arrival or presence. | /hɛˈloʊ/ · intj |
| [prince](https://en.wiktionary.org/wiki/prince#English) | Someone who is preeminent in their field; a great person. | /pɹɪns/ · noun |
| [quarter](https://en.wiktionary.org/wiki/quarter#English) | Each of four equal parts into which something can be divided; a fourth part. | /ˈk(w)ɔːtə/ · noun |
| [shape](https://en.wiktionary.org/wiki/shape#English) | The status or condition of something | /ˈʃeɪ̯p/ · noun |
| [sky](https://en.wiktionary.org/wiki/sky#English) | The atmosphere above a given point, especially as visible from the surface of the Earth as the place where the sun, moon, stars, and clouds are seen. | /skaɪ/ · noun |
| [accident](https://en.wiktionary.org/wiki/accident#English) | An unexpected event with negative consequences occurring without the intention of the one suffering the consequences, and (in the strict sense) not directly caused by humans. | /ˈæk.sɪ.dənt/ · noun |
| [bear](https://en.wiktionary.org/wiki/bear#English) | A large, generally omnivorous mammal (a few species are purely carnivorous or herbivorous) of the family Ursidae; having shaggy fur, a very small tail, and flat feet. | /bɛə/ · noun |

</details>

<details><summary>Words 151–200</summary>

![[Resources/Audio/en/Words 0151-0200.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [boat](https://en.wiktionary.org/wiki/boat#English) | A small, usually open craft used for travelling over water, propelled by oars, motor or wind. Usually contrasted with "ship". | /bəʊ̯t/ · noun |
| [cheap](https://en.wiktionary.org/wiki/cheap#English) | Low or reduced in price. | /ˈt͡ʃiːp/ · adj |
| [governor](https://en.wiktionary.org/wiki/governor#English) | The chief executive officer of a first-level administrative division of a country. | /ˈɡʌv(ə)nə/ · noun |
| [hundred](https://en.wiktionary.org/wiki/hundred#English) | A numerical value equal to 100 (10²), occurring after ninety-nine; ten times ten. | /ˈhʌn.dɹəd/ · num |
| [industrial](https://en.wiktionary.org/wiki/industrial#English) | Of or relating to industry, notably manufacturing. | /ɪnˈdʌs.tɹi.əl/ · adj |
| [path](https://en.wiktionary.org/wiki/path#English) | A trail for the use of, or worn by, pedestrians. | /pɑːθ/ · noun |
| [rain](https://en.wiktionary.org/wiki/rain#English) | Condensed water falling from a cloud. | /ɹeɪn/ · noun |
| [warm](https://en.wiktionary.org/wiki/warm#English) | Of a somewhat high temperature, often but not always connoting that the high temperature is pleasant rather than uncomfortable. | /wɔːm/ · adj |
| [Canadian](https://en.wiktionary.org/wiki/Canadian#English) | Of, belonging to, or relating to Canada, its culture, or people. | /kəˈneɪ.di.ən/ · adj |
| [arts](https://en.wiktionary.org/wiki/arts#English) | The study of languages and literature. | /ɑɹts/ · noun |
| [beer](https://en.wiktionary.org/wiki/beer#English) | An alcoholic drink fermented from starch material, commonly barley malt; often with hops or some other substance (like gruit) to impart a bitter flavor. | /ˈbɪə̯/ · noun |
| [crew](https://en.wiktionary.org/wiki/crew#English) | A group of people (often staff) manning and operating a large facility or piece of equipment such as a factory, ship, boat, airplane, or spacecraft. | /kɹuː/ · noun |
| [crowd](https://en.wiktionary.org/wiki/crowd#English) | To press forward; to advance by pushing. | /ˈkɹaʊ̯d/ · verb |
| [labour](https://en.wiktionary.org/wiki/labour#English) | An effort expended on a particular task; toil, work. | /ˈleɪ.bə/ · noun |
| [moon](https://en.wiktionary.org/wiki/moon#English) | Any natural satellite of a planet. | /muːn/ · noun |
| [suit](https://en.wiktionary.org/wiki/suit#English) | A set of clothes to be worn together, now especially a man's matching jacket and trousers (also business suit or lounge suit), or a similar outfit for a woman. | /sjuːt/ · noun |
| [Asian](https://en.wiktionary.org/wiki/Asian#English) | A person from or with ancestry in East or Southeast Asia, occasionally South Asia. | /ˈeɪʒən/ · noun |
| [PM](https://en.wiktionary.org/wiki/PM#English) | To project manage. | /ˌpiː ˈɛm/ · verb |
| [attorney](https://en.wiktionary.org/wiki/attorney#English) | A lawyer; one who advises or represents others in legal matters as a profession. | /əˈtɜːni/ · noun |
| [behavior](https://en.wiktionary.org/wiki/behavior#English) | Human conduct relative to social norms. | /bɪˈheɪ.vjə/ · noun |
| [ben](https://en.wiktionary.org/wiki/ben#English) | In, into. | /bɛn/ · prep |
| [chair](https://en.wiktionary.org/wiki/chair#English) | An item of furniture used to sit on or in, comprising a seat, legs or wheels, back, and sometimes arm rests, for use by one person. | /t͡ʃɛə/ · noun |
| [debt](https://en.wiktionary.org/wiki/debt#English) | An action, state of mind, or object one has an obligation to perform for another, adopt toward another, or give to another. | /ˈdɛt/ · noun |
| [jump](https://en.wiktionary.org/wiki/jump#English) | To propel oneself rapidly upward, downward and/or in any horizontal direction such that momentum causes the body to become airborne. | /d͡ʒʌmp/ · verb |
| [ray](https://en.wiktionary.org/wiki/ray#English) | A beam of light or radiation. | /ɹeɪ/ · noun |
| [update](https://en.wiktionary.org/wiki/update#English) | An additional piece of information, an addition to existing information. | /ˈʌp.deɪt/ · noun |
| [writer](https://en.wiktionary.org/wiki/writer#English) | A person who writes, or produces literary work; an author can refer to themselves as "the writer". | /ˈɹaɪ.tə(ɹ)/ · noun |
| [yellow](https://en.wiktionary.org/wiki/yellow#English) | The middle light in a set of three traffic lights, the lighting of which indicates that drivers should stop short of the intersection if it is safe to do so. | /ˈjɛləʊ/ · noun |
| [younger](https://en.wiktionary.org/wiki/younger#English) | Synonym of junior. | /ˈjʌŋɡə/ · adj |
| [ending](https://en.wiktionary.org/wiki/ending#English) | A termination or conclusion. | /ˈɛndɪŋ/ · noun |
| [flow](https://en.wiktionary.org/wiki/flow#English) | Movement in people or things characterized with a continuous motion, involving either a non solid mass or a multitude. | /ˈfləʊ/ · noun |
| [girlfriend](https://en.wiktionary.org/wiki/girlfriend#English) | A female partner in an unmarried romantic relationship. | /ˈɡɜːlfɹɛnd/ · noun |
| [loan](https://en.wiktionary.org/wiki/loan#English) | An act or instance of lending, an act or instance of granting something for temporary use. | /ləʊn/ · noun |
| [planet](https://en.wiktionary.org/wiki/planet#English) | construed with the or this: The Earth. | /ˈplænɪt/ · noun |
| [stuck](https://en.wiktionary.org/wiki/stuck#English) | Unable to move. | /stʌk/ · adj |
| [sugar](https://en.wiktionary.org/wiki/sugar#English) | A food consisting of small, sweet crystals, principally of sucrose, obtained from sugar cane or sugar beet and used as sweetener and preservative. | /ˈʃʊɡə/ · noun |
| [MS](https://en.wiktionary.org/wiki/MS#English) | M/S: Initialism of motor ship. |  · noun |
| [Muslim](https://en.wiktionary.org/wiki/Muslim#English) | An adherent of Islam. | /ˈmʊz.lɪm/ · noun |
| [device](https://en.wiktionary.org/wiki/device#English) | Any piece of equipment made for a particular purpose, especially a mechanical or electrical one. | /dɪˈvaɪs/ · noun |
| [era](https://en.wiktionary.org/wiki/era#English) | A time period of indeterminate length, generally more than one year. | /ˈɪə.ɹə/ · noun |
| [factor](https://en.wiktionary.org/wiki/factor#English) | An agent or representative; a reseller or distributor (sometimes with a private label); a consignee. | /ˈfæk.tə/ · noun |
| [feed](https://en.wiktionary.org/wiki/feed#English) | To give (someone or something) food to eat. | /fiːd/ · verb |
| [grown](https://en.wiktionary.org/wiki/grown#English) | Covered by growth; overgrown. | /ɡɹəʊn/ · adj |
| [mistake](https://en.wiktionary.org/wiki/mistake#English) | To understand wrongly, taking one thing or person for another. | /mɪˈsteɪk/ · verb |
| [platform](https://en.wiktionary.org/wiki/platform#English) | A raised stage from which speeches are made and on which musical and other performances are made. | /ˈplætfɔːm/ · noun |
| [smoke](https://en.wiktionary.org/wiki/smoke#English) | The visible vapor/vapour, gases, and fine particles given off by burning or smoldering material. | /sməʊk/ · noun |
| [teach](https://en.wiktionary.org/wiki/teach#English) | To pass on knowledge to. | /tiːt͡ʃ/ · verb |
| [Italian](https://en.wiktionary.org/wiki/Italian#English) | Pertaining to Italy. | /ɪˈtæl.jən/ · adj |
| [abuse](https://en.wiktionary.org/wiki/abuse#English) | Improper treatment or usage; application to a wrong or bad purpose; an unjust, corrupt or wrongful practice or custom. | /əˈbjuːs/ · noun |
| [angry](https://en.wiktionary.org/wiki/angry#English) | Displaying or feeling anger. | /ˈæŋ.ɡɹi/ · adj |

</details>

<details><summary>Words 201–250</summary>

![[Resources/Audio/en/Words 0201-0250.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [candidate](https://en.wiktionary.org/wiki/candidate#English) | A person who seeks to be elected or appointed to a position or privilege. | /ˈkæn.dɪ.dət/ · noun |
| [concern](https://en.wiktionary.org/wiki/concern#English) | That which affects one’s welfare or happiness. A matter of interest to someone. | /kənˈsɝn/ · noun |
| [fox](https://en.wiktionary.org/wiki/fox#English) | Any member of the genus Vulpes; a true fox. | /fɒks/ · noun |
| [hole](https://en.wiktionary.org/wiki/hole#English) | A hollow place or cavity; an excavation; a pit; a dent; a depression; a fissure. | /həʊl/ · noun |
| [internal](https://en.wiktionary.org/wiki/internal#English) | Of or situated on the inside. | /ɪnˈtɜː.nəl/ · adj |
| [laugh](https://en.wiktionary.org/wiki/laugh#English) | An expression of mirth particular to the human species; the sound heard in laughing; laughter. | /lɑːf/ · noun |
| [leg](https://en.wiktionary.org/wiki/leg#English) | A limb or appendage that an animal uses for support or locomotion on land. | /lɛɡ/ · noun |
| [liberal](https://en.wiktionary.org/wiki/liberal#English) | Generous; permitting liberty; willing to give unsparingly. | /ˈlɪb.(ə.)ɹəl/ · adj |
| [payment](https://en.wiktionary.org/wiki/payment#English) | The act of paying. | /ˈpeɪmənt/ · noun |
| [snow](https://en.wiktionary.org/wiki/snow#English) | The partly frozen, crystalline state of water that falls from the atmosphere as precipitation in flakes; also, the falling of such flakes; and the accumulation of them on the ground or on objects as a white layer. | /snəʊ̯/ · noun |
| [storm](https://en.wiktionary.org/wiki/storm#English) | A heavy fall of precipitation (hail, rain, or snow) or bout of lightning and thunder without strong winds; a hail storm, rainstorm, snowstorm, or thunderstorm. | /stɔːm/ · noun |
| [strike](https://en.wiktionary.org/wiki/strike#English) | To delete or cross out; to scratch or eliminate. | /stɹaɪk/ · verb |
| [actor](https://en.wiktionary.org/wiki/actor#English) | Someone or something that takes part in some action; a doer, an agent. | /ˈæk.təː/ · noun |
| [chain](https://en.wiktionary.org/wiki/chain#English) | A series of interconnected rings or links usually made of metal. | /ˈt͡ʃeɪn/ · noun |
| [cook](https://en.wiktionary.org/wiki/cook#English) | A person who prepares food. | /kʊk/ · noun |
| [cute](https://en.wiktionary.org/wiki/cute#English) | Lovable, charming, attractive or pleasing, especially in a youthful, dainty, quaint or fun-spirited way. | /kjuːt/ · adj |
| [journey](https://en.wiktionary.org/wiki/journey#English) | A set amount of travelling, seen as a single unit; a discrete trip, a voyage. | /ˈd͡ʒɝni/ · noun |
| [quiet](https://en.wiktionary.org/wiki/quiet#English) | With little or no sound; free of disturbing noise. | /ˈkwaɪ̯.ət/ · adj |
| [split](https://en.wiktionary.org/wiki/split#English) | To divide fully or partly along a more or less straight line. | /splɪt/ · verb |
| [twenty](https://en.wiktionary.org/wiki/twenty#English) | The cardinal number 20, occurring after nineteen and before twenty-one. | /ˈtwɛnti/ · num |
| [urban](https://en.wiktionary.org/wiki/urban#English) | Of, pertaining to, characteristic of, or happening or located in, a city or town; of, pertaining to, or characteristic of life in such a place, especially when contrasted with the countryside. | /ˈɜː.bən/ · adj |
| [aircraft](https://en.wiktionary.org/wiki/aircraft#English) | A vehicle capable of atmospheric flight due to interaction with the air, such as buoyancy or lift. | /ˈɛə.kɹɑːft/ · noun |
| [argument](https://en.wiktionary.org/wiki/argument#English) | A fact or statement used to support a proposition; a reason. | /ˈɑːɡjʊmənt/ · noun |
| [corporate](https://en.wiktionary.org/wiki/corporate#English) | Of or relating to an institution; institutional. | /ˈkɔː.pə.ɹət/ · adj |
| [distribution](https://en.wiktionary.org/wiki/distribution#English) | An act of distributing or state of being distributed. | /ˌdɪstɹɪˈbjuːʃən/ · noun |
| [lay](https://en.wiktionary.org/wiki/lay#English) | To place down in a position of rest, or in a horizontal position. | /leɪ/ · verb |
| [revenue](https://en.wiktionary.org/wiki/revenue#English) | The income returned by an investment. | /ˈɹɛvənjuː/ · noun |
| [sat](https://en.wiktionary.org/wiki/sat#English) | past tense and participle of sit | /sæt/ · verb |
| [smile](https://en.wiktionary.org/wiki/smile#English) | Favour; propitious regard. | /ˈsmaɪl/ · noun |
| [talent](https://en.wiktionary.org/wiki/talent#English) | A marked natural ability or skill. | /ˈtæl.ənt/ · noun |
| [temperature](https://en.wiktionary.org/wiki/temperature#English) | A measure of cold or heat, often measurable with a thermometer. | /ˈtɛm.pəɹ.ə.t͡ʃə(ɹ)/ · noun |
| [thousand](https://en.wiktionary.org/wiki/thousand#English) | A numerical value equal to 1,000; ten times a hundred (1 E+3 exactly—in scientific E notation) | /ˈθaʊz(ə)nd/ · num |
| [Tuesday](https://en.wiktionary.org/wiki/Tuesday#English) | The third day of the week in many religious traditions, and the second day of the week in systems that use the ISO 8601 norm; it follows Monday and precedes Wednesday. | /ˈtjuːz.deɪ/ · noun |
| [bird](https://en.wiktionary.org/wiki/bird#English) | An animal of the clade (traditionally class) Aves in the phylum Chordata, characterized by being warm-blooded, having feathers and wings usually capable of flight, having a beaked mouth, and laying eggs. | /ˈbɜːd/ · noun |
| [chicken](https://en.wiktionary.org/wiki/chicken#English) | A domesticated subspecies of red junglefowl (Gallus gallus domesticus). | /ˈt͡ʃɪkɪn/ · noun |
| [context](https://en.wiktionary.org/wiki/context#English) | The surroundings, circumstances, environment, background or settings that determine, specify, or clarify the meaning of an event or other occurrence. | /ˈkɒn.tɛkst/ · noun |
| [display](https://en.wiktionary.org/wiki/display#English) | A show or spectacle. | /dɪsˈpleɪ/ · noun |
| [false](https://en.wiktionary.org/wiki/false#English) | Untrue, not factual, factually incorrect. | /fɔːls/ · adj |
| [meat](https://en.wiktionary.org/wiki/meat#English) | The flesh (muscle tissue) of a killed animal used as food. | /miːt/ · noun |
| [neck](https://en.wiktionary.org/wiki/neck#English) | The part of the body connecting the head and the trunk found in humans and some animals. | /ˈnɛk/ · noun |
| [shirt](https://en.wiktionary.org/wiki/shirt#English) | An article of clothing that is worn on the upper part of the body, often with sleeves that cover some or all of the arms. | /ʃɜːt/ · noun |
| [zero](https://en.wiktionary.org/wiki/zero#English) | The cardinal number occurring before one and that denotes no quantity or amount at all, represented in Arabic numerals as 0. | /ˈzɪəɹəʊ/ · num |
| [Thursday](https://en.wiktionary.org/wiki/Thursday#English) | The fifth day of the week in many religious traditions, and the fourth day of the week in systems using the ISO 8601 norm; it follows Wednesday and precedes Friday. | /ˈθɜːz.deɪ/ · noun |
| [cream](https://en.wiktionary.org/wiki/cream#English) | The butterfat or milkfat part of milk which rises to the top; this part when separated from the remainder. | /kɹiːm/ · noun |
| [crisis](https://en.wiktionary.org/wiki/crisis#English) | A crucial or decisive point or situation; a turning point. | /ˈkɹaɪsɪs/ · noun |
| [kingdom](https://en.wiktionary.org/wiki/kingdom#English) | A realm having a king or queen as its actual or nominal sovereign. | /ˈkɪŋdəm/ · noun |
| [mayor](https://en.wiktionary.org/wiki/mayor#English) | The chief executive of the municipal government of a city, borough, etc., formerly (historical) usually appointed as a caretaker by European royal courts but now usually appointed or elected locally. | /ˈmɛə̯/ · noun |
| [orange](https://en.wiktionary.org/wiki/orange#English) | An evergreen tree of the genus Citrus such as Citrus sinensis which yields oranges (the fruit). | /ˈɒɹɪnd͡ʒ/ · noun |
| [ourselves](https://en.wiktionary.org/wiki/ourselves#English) | Us; the group including the speaker as the object of a verb or preposition when that group also is the subject. | /aʊəˈsɛlvz/ · pron |
| [ID](https://en.wiktionary.org/wiki/ID#English) | An ident. | /aɪˈdiː/ · noun |

</details>

<details><summary>Words 251–300</summary>

![[Resources/Audio/en/Words 0251-0300.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [breakfast](https://en.wiktionary.org/wiki/breakfast#English) | The first meal of the day, usually eaten in the morning. | /ˈbɹɛk.fəst/ · noun |
| [bright](https://en.wiktionary.org/wiki/bright#English) | Emitting much light; visually dazzling; luminous, lucent, radiant. | /ˈbɹaɪ̯t/ · adj |
| [chosen](https://en.wiktionary.org/wiki/chosen#English) | picked; selected | /ˈt͡ʃəʊ.zən/ · adj |
| [drunk](https://en.wiktionary.org/wiki/drunk#English) | Intoxicated as a result of excessive alcohol consumption, usually by drinking alcoholic beverages. | /dɹʌŋk/ · adj |
| [seek](https://en.wiktionary.org/wiki/seek#English) | To try to find; to look for; to search for. | /ˈsiːk/ · verb |
| [spoke](https://en.wiktionary.org/wiki/spoke#English) | A support structure that connects the axle or the hub of a wheel to the rim. | /spəʊk/ · noun |
| [upset](https://en.wiktionary.org/wiki/upset#English) | Angry, distressed, or unhappy | /ʌpˈsɛt/ · adj |
| [wing](https://en.wiktionary.org/wiki/wing#English) | An appendage of an animal's (bird, bat, insect) body that enables it to fly. | /wɪŋ/ · noun |
| [bomb](https://en.wiktionary.org/wiki/bomb#English) | An explosive device used or intended as a weapon, especially, one dropped from an aircraft. | /bɒm/ · noun |
| [cycle](https://en.wiktionary.org/wiki/cycle#English) | An interval of space or time in which one set of events or phenomena is completed. | /ˈsaɪ.kəl/ · noun |
| [entertainment](https://en.wiktionary.org/wiki/entertainment#English) | An activity designed to give pleasure, enjoyment, diversion, amusement, or relaxation to an audience, no matter whether the audience participates passively as in watching opera or a movie, or actively as in games. | /ˌɛn.təˈteɪn.mənt/ · noun |
| [hang](https://en.wiktionary.org/wiki/hang#English) | To be or remain suspended. | /hæŋ/ · verb |
| [republic](https://en.wiktionary.org/wiki/republic#English) | A state where sovereignty rests with the people or their representatives, rather than with a monarch or emperor; a country with no monarchy. | /ɹɪˈpʌb.lɪk/ · noun |
| [salt](https://en.wiktionary.org/wiki/salt#English) | A common substance, chemically consisting mainly of sodium chloride (NaCl), used extensively as a food ingredient, seasoning, condiment, and preservative. | /sɒlt/ · noun |
| [threat](https://en.wiktionary.org/wiki/threat#English) | An expression of intent to injure or punish another. | /θɹɛt/ · noun |
| [Wednesday](https://en.wiktionary.org/wiki/Wednesday#English) | The fourth day of the week in many religious traditions, and the third day of the week in systems using the ISO 8601 norm; it follows Tuesday and precedes Thursday. | /ˈwɛnz.deɪ/ · noun |
| [bell](https://en.wiktionary.org/wiki/bell#English) | A percussive instrument made of metal or other hard material, typically but not always in the shape of an inverted cup with a flared rim, which resonates when struck. | /bɛl/ · noun |
| [blow](https://en.wiktionary.org/wiki/blow#English) | To produce an air current. | /bləʊ/ · verb |
| [boyfriend](https://en.wiktionary.org/wiki/boyfriend#English) | A male partner in an unmarried romantic relationship. | /ˈbɔɪˌfɹɛnd/ · noun |
| [careful](https://en.wiktionary.org/wiki/careful#English) | Taking care; attentive to potential danger, error or harm; cautious. | /ˈkɛɹfəl/ · adj |
| [corporation](https://en.wiktionary.org/wiki/corporation#English) | A body corporate, created by law or under authority of law, having a continuous existence independent of the existences of its members, and powers and liabilities distinct from those of its members. | /ˌkɔː.pəˈɹeɪ.ʃən/ · noun |
| [cry](https://en.wiktionary.org/wiki/cry#English) | To shed tears; to weep, especially in anger or sadness. | /kɹaɪ/ · verb |
| [danger](https://en.wiktionary.org/wiki/danger#English) | Exposure to likely harm; risk of death or serious injury. | /ˈdeɪn.d͡ʒə/ · noun |
| [dollar](https://en.wiktionary.org/wiki/dollar#English) | Official designation for currency in some parts of the world, including Canada, the United States, Australia, New Zealand, Singapore, Hong Kong, and elsewhere. Its symbol is $. | /ˈdɒl.ə/ · noun |
| [gender](https://en.wiktionary.org/wiki/gender#English) | Sex (a category, either male or female, into which sexually-reproducing organisms are divided on the basis of their reproductive roles in their species). | /ˈd͡ʒɛndə/ · noun |
| [branch](https://en.wiktionary.org/wiki/branch#English) | The woody part of a tree arising from the trunk and usually dividing. | /bɹɑːnt͡ʃ/ · noun |
| [definition](https://en.wiktionary.org/wiki/definition#English) | A statement of the meaning of a word, word group, sign, or symbol; especially, a dictionary definition. | /ˌdɛf.ɪˈnɪʃ.ən/ · noun |
| [drawing](https://en.wiktionary.org/wiki/drawing#English) | A picture, likeness, diagram or representation, usually drawn on paper. | /ˈdɹɔː.ɪŋ/ · noun |
| [heaven](https://en.wiktionary.org/wiki/heaven#English) | The abode of God and of the angels and saints in His presence. | /ˈhɛvən/ · noun |
| [sentence](https://en.wiktionary.org/wiki/sentence#English) | The judicial order for a punishment to be imposed on a person convicted of a crime. | /ˈsɛn.təns/ · noun |
| [understood](https://en.wiktionary.org/wiki/understood#English) | Having been comprehended. | /ʌndəˈstʊd/ · adj |
| [academic](https://en.wiktionary.org/wiki/academic#English) | Belonging to the school or philosophy of Plato. | /ˌæk.əˈdɛm.ɪk/ · adj |
| [academy](https://en.wiktionary.org/wiki/academy#English) | An institution for the study of higher learning; a college or a university; typically a private school. | /əˈkæd.ə.mi/ · noun |
| [accurate](https://en.wiktionary.org/wiki/accurate#English) | Telling the truth or giving a true result; exact; not defective or faulty. | /ˈak.jʊ.ɹɪt/ · adj |
| [achieve](https://en.wiktionary.org/wiki/achieve#English) | To carry out or conclude (something, as a task) successfully; to accomplish. | /əˈt͡ʃiːv/ · verb |
| [bottle](https://en.wiktionary.org/wiki/bottle#English) | A container, typically made of glass or plastic and having a tapered neck, used primarily for holding liquids. | /ˈbɒtəl/ · noun |
| [chat](https://en.wiktionary.org/wiki/chat#English) | To be engaged in informal conversation. | /ˈt͡ʃæt/ · verb |
| [cheese](https://en.wiktionary.org/wiki/cheese#English) | A dairy product made from curdled or cultured milk. | /t͡ʃiːz/ · noun |
| [chemical](https://en.wiktionary.org/wiki/chemical#English) | Of or relating to chemistry. | /ˈkɛm.ɪ.kəl/ · adj |
| [fruit](https://en.wiktionary.org/wiki/fruit#English) | A product of fertilization in a plant, specifically | /fɹuːt/ · noun |
| [index](https://en.wiktionary.org/wiki/index#English) | An alphabetical listing of items and their location. | /ˈɪndɛks/ · noun |
| [lane](https://en.wiktionary.org/wiki/lane#English) | A road, street, or similar thoroughfare. | /leɪn/ · noun |
| [navy](https://en.wiktionary.org/wiki/navy#English) | A country's entire maritime military force, including ships and personnel. | /ˈneɪvi/ · noun |
| [parent](https://en.wiktionary.org/wiki/parent#English) | A person who raises a child (which they have made, adopted, fostered, taken as their own, etc.). | /ˈpɛəɹənt/ · noun |
| [weekly](https://en.wiktionary.org/wiki/weekly#English) | Once every week. | /ˈwiːk.li/ · adv |
| [DC](https://en.wiktionary.org/wiki/DC#English) | To become disconnected from a network. |  · verb |
| [button](https://en.wiktionary.org/wiki/button#English) | A knob or disc that is passed through a loop or (buttonhole), serving as a fastener. | /ˈbʌtən/ · noun |
| [constitution](https://en.wiktionary.org/wiki/constitution#English) | The act, or process of setting something up, or establishing something; the composition or structure of such a thing; its makeup. | /ˌkɒn.stɪˈtjuː.ʃ(ə)n/ · noun |
| [crown](https://en.wiktionary.org/wiki/crown#English) | A royal, imperial or princely headdress; a diadem. | /kɹaʊ̯n/ · noun |
| [clarify](https://en.wiktionary.org/wiki/clarify) | to make something easier to understand |  · verb |

</details>

<details><summary>Words 301–350</summary>

![[Resources/Audio/en/Words 0301-0350.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [laid](https://en.wiktionary.org/wiki/laid#English) | Marked with parallel lines, as if ribbed, from wires in the mould. | /leɪd/ · adj |
| [q](https://en.wiktionary.org/wiki/q#English) | The seventeenth numeral symbol of the English alphabet, called cue and written in the Latin script. | /kjuː/ · num |
| [sleeping](https://en.wiktionary.org/wiki/sleeping#English) | Asleep. | /ˈsliːpɪŋ/ · adj |
| [tournament](https://en.wiktionary.org/wiki/tournament#English) | A series of games; either the same game played many times, or a succession of games related by a single theme; played competitively to determine a single winning team or individual. | /ˈtʊənəmənt/ · noun |
| [turkey](https://en.wiktionary.org/wiki/turkey#English) | A wild turkey of Meleagris gallopavo. | /ˈtɜːki/ · noun |
| [attend](https://en.wiktionary.org/wiki/attend#English) | To care for (someone requiring attention); specifically, of a doctor, nurse, etc.: to provide professional care to (someone). | /əˈtɛnd/ · verb |
| [ban](https://en.wiktionary.org/wiki/ban#English) | To prohibit; to interdict; to proscribe; to forbid or block from participation. | /ˈbæn/ · verb |
| [chose](https://en.wiktionary.org/wiki/chose#English) | A thing; personal property. |  · noun |
| [circle](https://en.wiktionary.org/wiki/circle#English) | A two-dimensional geometric figure, a line, consisting of the set of all those points in a plane that are equally distant from a given point (center). | /ˈsɜɹkəl/ · noun |
| [depth](https://en.wiktionary.org/wiki/depth#English) | the vertical distance below a surface; the degree to which something is deep | /dɛpθ/ · noun |
| [dirty](https://en.wiktionary.org/wiki/dirty#English) | Unclean; covered with or containing unpleasant substances such as dirt or grime. | /ˈdɜːti/ · adj |
| [existence](https://en.wiktionary.org/wiki/existence#English) | The state of being, existing, or occurring; beinghood. | /ɛɡˈzɪs.təns/ · noun |
| [expression](https://en.wiktionary.org/wiki/expression#English) | The action of expressing thoughts, ideas, feelings, etc. | /əkˈspɹɛʃ.n̩/ · noun |
| [interior](https://en.wiktionary.org/wiki/interior#English) | Within any limits, enclosure, or substance; inside; internal; inner. | /ɪnˈtɪə.ɹɪ.ə/ · adj |
| [plate](https://en.wiktionary.org/wiki/plate#English) | A slightly curved but almost flat dish from which food is served or eaten. | /ˈpleɪ̯t/ · noun |
| [rice](https://en.wiktionary.org/wiki/rice#English) | Cereal plants, Oryza sativa of the grass family whose seeds are used as food. | /ɹaɪs/ · noun |
| [Irish](https://en.wiktionary.org/wiki/Irish#English) | Temper; anger, passion. | /ˈaɪɹɪʃ/ · noun |
| [absolute](https://en.wiktionary.org/wiki/absolute#English) | Free of restrictions, limitations, qualifications or conditions; unconditional. | /ˈæb.sə.luːt/ · adj |
| [bathroom](https://en.wiktionary.org/wiki/bathroom#English) | A room containing a shower or bathtub, and (typically but not necessarily) a toilet. | /ˈbɑːθɹʊm/ · noun |
| [bible](https://en.wiktionary.org/wiki/bible#English) | A comprehensive manual that describes something, or a publication with a loyal readership; a foundational text. | /ˈbaɪbəl/ · noun |
| [cable](https://en.wiktionary.org/wiki/cable#English) | A strong, large-diameter wire or rope, or something resembling such a rope. | /ˈkeɪ.bəl/ · noun |
| [driven](https://en.wiktionary.org/wiki/driven#English) | Obsessed; passionately motivated to achieve goals. | /ˈdɹɪvn̩/ · adj |
| [empire](https://en.wiktionary.org/wiki/empire#English) | A political state, often a monarchy, that has achieved a much greater current size than its initial size by conquering surrounding territories, cities or nations. | /ˈɛm.paɪ̯ə̯/ · noun |
| [hide](https://en.wiktionary.org/wiki/hide#English) | To put (something) in a place where it will be out of sight or harder to discover. | /haɪd/ · verb |
| [quit](https://en.wiktionary.org/wiki/quit#English) | Released from obligation, penalty, etc; free, clear, or rid. | /kwɪt/ · adj |
| [sing](https://en.wiktionary.org/wiki/sing#English) | To produce musical or harmonious sounds with one’s voice. | /ˈsɪŋ/ · verb |
| [weapon](https://en.wiktionary.org/wiki/weapon#English) | An instrument of attack or defense in combat or hunting, e.g. most guns, missiles, or swords. | /ˈwɛp.ən/ · noun |
| [wet](https://en.wiktionary.org/wiki/wet#English) | Made up of liquid or moisture, usually (but not always) water. | /wɛt/ · adj |
| [broad](https://en.wiktionary.org/wiki/broad#English) | Wide in extent or scope. | /bɹɔːd/ · adj |
| [burn](https://en.wiktionary.org/wiki/burn#English) | A physical injury caused by heat, cold, electricity, radiation or caustic chemicals. | /bɜːn/ · noun |
| [cake](https://en.wiktionary.org/wiki/cake#English) | A rich, sweet dessert food, typically made of flour, sugar, and eggs and baked in an oven, and often covered in icing. | /keɪk/ · noun |
| [drawn](https://en.wiktionary.org/wiki/drawn#English) | Depleted. | /dɹɔːn/ · adj |
| [hidden](https://en.wiktionary.org/wiki/hidden#English) | Located or positioned out of sight; not visually apparent. | /ˈhɪd.(ə)n/ · adj |
| [princess](https://en.wiktionary.org/wiki/princess#English) | A female member of a royal family other than a queen, especially a daughter or granddaughter of a monarch. | /pɹɪnˈsɛs/ · noun |
| [breath](https://en.wiktionary.org/wiki/breath#English) | The act or process of breathing. | /bɹɛθ/ · noun |
| [brief](https://en.wiktionary.org/wiki/brief#English) | Of short duration; happening quickly. | /ˈbɹiːf/ · adj |
| [decade](https://en.wiktionary.org/wiki/decade#English) | A group, set, or series of ten , particularly | /ˈdɛkeɪd/ · noun |
| [paint](https://en.wiktionary.org/wiki/paint#English) | A substance that is applied as a liquid or paste, and dries into a solid coating that protects or adds colour to an object or surface to which it has been applied. | /peɪnt/ · noun |
| [pink](https://en.wiktionary.org/wiki/pink#English) | A color reminiscent of pinks, the flowers. | /ˈpɪŋk/ · noun |
| [tall](https://en.wiktionary.org/wiki/tall#English) | Having great vertical extent (usually reckoned from the bottom of the feet to the very top of the head) when standing. (For instance, somebody with a height of over 6 feet would generally be deemed tall.) | /tɔːl/ · adj |
| [comparison](https://en.wiktionary.org/wiki/comparison#English) | The act of comparing or the state or process of being compared. | /kəmˈpæɹ.ɪ.sən/ · noun |
| [defeat](https://en.wiktionary.org/wiki/defeat#English) | To overcome in battle or contest. | /dɪˈfiːt/ · verb |
| [democracy](https://en.wiktionary.org/wiki/democracy#English) | Rule by the people, especially as a form of government, such as | /dɪˈmɒk.ɹə.si/ · noun |
| [fed](https://en.wiktionary.org/wiki/fed#English) | A police officer. | /ˈfɛd/ · noun |
| [musical](https://en.wiktionary.org/wiki/musical#English) | Of, belonging or relating to music, or to its performance or notation. | /ˈmju.zɪ.kəl/ · adj |
| [nose](https://en.wiktionary.org/wiki/nose#English) | A protuberance on the face housing the nostrils, which are used to breathe or smell. | /nəʊ̯z/ · noun |
| [quote](https://en.wiktionary.org/wiki/quote#English) | A statement attributed to a person; a quotation. | /kwəʊt/ · noun |
| [swear](https://en.wiktionary.org/wiki/swear#English) | To take an oath, to promise intensely, solemnly, and/or with legally binding effect. | /ˈswɛə(ɹ)/ · verb |
| [wealth](https://en.wiktionary.org/wiki/wealth#English) | Riches; a great amount of valuable assets or material possessions. | /wɛlθ/ · noun |
| [Greek](https://en.wiktionary.org/wiki/Greek#English) | Of or relating to Greece, its people, its language, or its culture. | /ɡɹiːk/ · adj |

</details>

<details><summary>Words 351–400</summary>

![[Resources/Audio/en/Words 0351-0400.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [approval](https://en.wiktionary.org/wiki/approval#English) | An expression granting permission; an indication of agreement with a proposal; an acknowledgement that a person, thing, or event meets requirements. | /əˈpɹuːvəl/ · noun |
| [bread](https://en.wiktionary.org/wiki/bread#English) | A foodstuff made by baking dough made from cereals. | /brɛd/ · noun |
| [evaluate](https://en.wiktionary.org/wiki/evaluate) | to judge value or quality using evidence |  · verb |
| [graduate](https://en.wiktionary.org/wiki/graduate#English) | A person who is recognized by a university as having completed the requirements of a degree studied at the institution. | /ˈɡɹæd͡ʒuət/ · noun |
| [lift](https://en.wiktionary.org/wiki/lift#English) | To raise or rise. | /lɪft/ · verb |
| [monthly](https://en.wiktionary.org/wiki/monthly#English) | Occurring every month. | /ˈmʌnθli/ · adj |
| [rid](https://en.wiktionary.org/wiki/rid#English) | Followed by of: to free (oneself or someone, or a place) from an annoyance or hindrance. | /ɹɪd/ · verb |
| [tower](https://en.wiktionary.org/wiki/tower#English) | A tall, narrow structure (significantly taller than it is wide, either standing alone or forming part of a larger structure. | /ˈtaʊ.ə(ɹ)/ · noun |
| [DNA](https://en.wiktionary.org/wiki/DNA#English) | The part of a living thing that carries genetic information. | /ˌdiːɛnˈeɪ/ · noun |
| [Korean](https://en.wiktionary.org/wiki/Korean#English) | Of or relating to the Asian Peninsula comprising North Korea and South Korea. | /kəˈɹi.ən/ · adj |
| [chocolate](https://en.wiktionary.org/wiki/chocolate#English) | A food made from ground roasted cocoa beans. | /ˈtʃɒk.(ə.)lət/ · noun |
| [coal](https://en.wiktionary.org/wiki/coal#English) | A black or brownish black rock formed from prehistoric plant remains, composed largely of carbon and burned as a fuel. | /kəʊl/ · noun |
| [colour](https://en.wiktionary.org/wiki/colour#English) | Commonwealth and Ireland standard spelling of color. |  · noun |
| [contemporary](https://en.wiktionary.org/wiki/contemporary#English) | From the same time period, coexistent in time; contemporaneous. | /kənˈtɛm.p(ə.)ɹə.ɹi/ · adj |
| [highway](https://en.wiktionary.org/wiki/highway#English) | A main public road, especially a multi-lane, high-speed thoroughfare. | /ˈhaɪweɪ/ · noun |
| [hunt](https://en.wiktionary.org/wiki/hunt#English) | To find or search for an animal in the wild with the intention of killing the animal for its meat or for sport. | /hʌnt/ · verb |
| [rough](https://en.wiktionary.org/wiki/rough#English) | Not smooth; uneven. | /ɹʌf/ · adj |
| [smell](https://en.wiktionary.org/wiki/smell#English) | A sensation, pleasant or unpleasant, detected by inhaling air (or, the case of water-breathing animals, water) carrying airborne molecules of a substance. | /smɛl/ · noun |
| [finger](https://en.wiktionary.org/wiki/finger#English) | A slender jointed extremity of the human hand, (often) exclusive of the thumb, and the corresponding part, irrespective of including a thumb, in many other animals. | /ˈfɪŋɡəː/ · noun |
| [grey](https://en.wiktionary.org/wiki/grey#English) | Commonwealth standard spelling of gray. | /ɡɹeɪ/ · adj |
| [guitar](https://en.wiktionary.org/wiki/guitar#English) | A stringed musical instrument, of European origin, usually with a fretted fingerboard and six strings, played with the fingers or a plectrum (guitar pick). | /ɡɪˈtɑː/ · noun |
| [pants](https://en.wiktionary.org/wiki/pants#English) | An outer garment that covers the body from the waist downwards, covering each leg separately, usually as far as the ankles; trousers. | /pænts/ · noun |
| [rape](https://en.wiktionary.org/wiki/rape#English) | To force sexual intercourse or other sexual activity upon (someone) without their consent. | /ˈɹeɪ̯p/ · verb |
| [sharp](https://en.wiktionary.org/wiki/sharp#English) | Terminating in a point or edge, especially one that can cut or pierce easily; not dull, obtuse, or rounded. | /ʃɑːp/ · adj |
| [soccer](https://en.wiktionary.org/wiki/soccer#English) | Association football. | /ˈsɒk.ə/ · noun |
| [bone](https://en.wiktionary.org/wiki/bone#English) | A composite material consisting largely of calcium phosphate and collagen and making up the skeleton of most vertebrates. | /bəʊn/ · noun |
| [bullshit](https://en.wiktionary.org/wiki/bullshit#English) | Statements that are intentionally misleading, whether true or not. | /ˈbʊɫʃɪt/ · noun |
| [gotten](https://en.wiktionary.org/wiki/gotten#English) | Obtained, acquired. | /ˈɡɒt.n̩/ · adj |
| [thin](https://en.wiktionary.org/wiki/thin#English) | Having little thickness or extent from one surface to its opposite. | /ˈθɪn/ · adj |
| [CEO](https://en.wiktionary.org/wiki/CEO#English) | A notional title for a leading partaker in, or advocate of something or someone. |  · noun |
| [accused](https://en.wiktionary.org/wiki/accused#English) | The person charged with an offense; the defendant in a criminal case. | /əˈkjuzd/ · noun |
| [atmosphere](https://en.wiktionary.org/wiki/atmosphere#English) | The gases surrounding the Earth or any astronomical body. | /ˈætməsˌfɪə/ · noun |
| [belief](https://en.wiktionary.org/wiki/belief#English) | Mental acceptance of a claim as true. | /bɪˈliːf/ · noun |
| [bound](https://en.wiktionary.org/wiki/bound#English) | Obliged (to). | /ˈbaʊ̯nd/ · adj |
| [cloud](https://en.wiktionary.org/wiki/cloud#English) | A visible mass of water droplets suspended in the air. | /ˈklaʊ̯d/ · noun |
| [egg](https://en.wiktionary.org/wiki/egg#English) | An approximately spherical or ellipsoidal body produced by birds, insects, reptiles, and other animals, often housing an embryo within a membrane or shell during its development. | /ɛɡ/ · noun |
| [loose](https://en.wiktionary.org/wiki/loose#English) | To let loose, to free from restraints. | /luːs/ · verb |
| [railway](https://en.wiktionary.org/wiki/railway#English) | A transport system using rails used to move passengers or goods. | /ˈɹeɪlˌweɪ/ · noun |
| [shock](https://en.wiktionary.org/wiki/shock#English) | A sudden, heavy impact. | /ʃɒk/ · noun |
| [thick](https://en.wiktionary.org/wiki/thick#English) | Relatively great in extent from one surface to the opposite in its smallest solid dimension. | /θɪk/ · adj |
| [acid](https://en.wiktionary.org/wiki/acid#English) | Sour, sharp, or biting to the taste; tart; having the taste of vinegar. | /ˈæsɪd/ · adj |
| [angel](https://en.wiktionary.org/wiki/angel#English) | An incorporeal and holy or semidivine messenger from a deity or other divine entity, traditionally depicted as a youthful, winged figure in flowing robes. | /ˈeɪ̯n.d͡ʒəl/ · noun |
| [castle](https://en.wiktionary.org/wiki/castle#English) | An instance of castling. | /ˈkɑːsəl/ · noun |
| [duke](https://en.wiktionary.org/wiki/duke#English) | The male ruler of a duchy (female equivalent: duchess). | /dʒuːk/ · noun |
| [flash](https://en.wiktionary.org/wiki/flash#English) | To cause to shine briefly or intermittently. | /flæʃ/ · verb |
| [gray](https://en.wiktionary.org/wiki/gray#English) | Of a color between black and white, having neutral hue and intermediate brightness. | /ɡɹeɪ/ · adj |
| [hungry](https://en.wiktionary.org/wiki/hungry#English) | Affected by hunger; having the physical need for food. | /ˈhʌŋ.ɡɹi/ · adj |
| [palace](https://en.wiktionary.org/wiki/palace#English) | Official residence of a head of state or other dignitary, especially in a monarchical or imperial governmental system. | /ˈpælɪs/ · noun |
| [penalty](https://en.wiktionary.org/wiki/penalty#English) | A legal sentence. | /ˈpɛn.əl.ti/ · noun |
| [pet](https://en.wiktionary.org/wiki/pet#English) | An animal kept as a companion or otherwise for pleasure, rather than for some practical benefit or use. | /pɛt/ · noun |

</details>

<details><summary>Words 401–450</summary>

![[Resources/Audio/en/Words 0401-0450.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [spoken](https://en.wiktionary.org/wiki/spoken#English) | Expressed in speech. | /ˈspəʊ.k(ə)n/ · adj |
| [trail](https://en.wiktionary.org/wiki/trail#English) | To follow behind (someone or something); to tail (someone or something). | /tɹeɪl/ · verb |
| [uncle](https://en.wiktionary.org/wiki/uncle#English) | The brother or brother-in-law of one’s parent. | /ˈʌŋ.kl̩/ · noun |
| [unusual](https://en.wiktionary.org/wiki/unusual#English) | Not usual, out of the ordinary. | /ʌnˈjuːʒ(u)əl/ · adj |
| [Victoria](https://en.wiktionary.org/wiki/Victoria#English) | One of an American breed of medium-sized white pigs with a slightly dished face and very erect ears. | /vɪkˈtɔː.ɹi.ə/ · noun |
| [concrete](https://en.wiktionary.org/wiki/concrete#English) | Real, actual, tangible. | /ˈkɒnkɹiːt/ · adj |
| [ideal](https://en.wiktionary.org/wiki/ideal#English) | Pertaining to ideas, or to a given idea. | /aɪˈdɪəl/ · adj |
| [sand](https://en.wiktionary.org/wiki/sand#English) | Rock that is ground more finely than gravel, but is not as fine as silt (more formally, see grain sizes chart), forming beaches and deserts and also used in construction. | /sænd/ · noun |
| [wage](https://en.wiktionary.org/wiki/wage#English) | An amount of money paid to a worker for a specified quantity of work, usually calculated on an hourly basis and expressed in an amount of money per hour. | /weɪd͡ʒ/ · noun |
| [FBI](https://en.wiktionary.org/wiki/FBI#English) | Fixed-bit index. | /ˈɛf.biː.aɪ/ · noun |
| [avenue](https://en.wiktionary.org/wiki/avenue#English) | A broad street, especially one bordered by trees or, in cities laid out in a grid pattern, one that is on a particular side of the city or that runs in a particular direction. | /ˈæv.əˌnjuː/ · noun |
| [clock](https://en.wiktionary.org/wiki/clock#English) | Any device or mechanism that enables time to be measured or regulated. | /klɒk/ · noun |
| [ear](https://en.wiktionary.org/wiki/ear#English) | The organ of hearing, consisting of the pinna or auricle, auditory canal, eardrum, malleus, incus, stapes and cochlea. | /ɪə̯/ · noun |
| [pizza](https://en.wiktionary.org/wiki/pizza#English) | A baked Italian dish of a thinly rolled bread crust typically topped before baking with tomato sauce, cheese, and other ingredients such as meat or vegetables. | /ˈpiː.tsə/ · noun |
| [wire](https://en.wiktionary.org/wiki/wire#English) | Metal formed into a thin, even thread, now usually by being drawn through a hole in a steel die. | /waɪə(ɹ)/ · noun |
| [capture](https://en.wiktionary.org/wiki/capture#English) | An act of capturing; a seizing by force or stratagem. | /ˈkæp.(t)ʃəː/ · noun |
| [comic](https://en.wiktionary.org/wiki/comic#English) | Pertaining to comedy, as a literary genre. | /ˈkɒmɪk/ · adj |
| [economics](https://en.wiktionary.org/wiki/economics#English) | The study of resource and wealth allocation, consumption, and distribution, of capital and investment, and of management of the factors of production. | /ˌiːkəˈnɒmɪks/ · noun |
| [flower](https://en.wiktionary.org/wiki/flower#English) | A colorful, conspicuous structure associated with angiosperms, frequently scented and attracting various insects, and which may or may not be used for sexual reproduction. | /ˈflaʊ̯.ə/ · noun |
| [handed](https://en.wiktionary.org/wiki/handed#English) | Having a certain kind or number of hands. | /ˈhændɪd/ · adj |
| [odd](https://en.wiktionary.org/wiki/odd#English) | Differing from what is usual, ordinary or expected. | /ɒd/ · adj |
| [skill](https://en.wiktionary.org/wiki/skill#English) | A capacity to do something well; a technique, an ability, usually acquired or learned, as opposed to abilities that are regarded as innate. | /skɪl/ · noun |
| [soil](https://en.wiktionary.org/wiki/soil#English) | A mixture of mineral particles and organic material, used to support plant growth. | /sɔɪl/ · noun |
| [stomach](https://en.wiktionary.org/wiki/stomach#English) | An organ in animals that stores food in the process of digestion. | /ˈstʌmək/ · noun |
| [suck](https://en.wiktionary.org/wiki/suck#English) | An instance of drawing something into one's lungs by inhaling or into one's mouth by suction. | /sʌk/ · noun |
| [Dutch](https://en.wiktionary.org/wiki/Dutch#English) | Of or pertaining to the Netherlands, the Dutch people or the Dutch language. | /dʌt͡ʃ/ · adj |
| [Mexican](https://en.wiktionary.org/wiki/Mexican#English) | A person from the country of Mexico or of Mexican descent. | /ˈmɛksɪk(ə)n/ · noun |
| [cousin](https://en.wiktionary.org/wiki/cousin#English) | Chiefly with a qualifying word: Any relation (especially a distant one) who is not a direct ancestor or descendant but part of a person's extended family; a kinsman or kinswoman. | /ˈkʌzn̩/ · noun |
| [dust](https://en.wiktionary.org/wiki/dust#English) | Fine, dry particles of matter found in the air and covering the surface of objects, typically consisting of soil lifted up by the wind, pollen, hair, fiber debris, dead skin cells, etc. | /dʌst/ · noun |
| [knife](https://en.wiktionary.org/wiki/knife#English) | A weapon designed with the aforementioned specifications intended for slashing or stabbing but too short to be called a sword; a dagger. | /ˈnaɪ̯f/ · noun |
| [rail](https://en.wiktionary.org/wiki/rail#English) | A horizontal bar extending between supports and used for support or as a barrier; a railing. | /ɹeɪ(ə)l/ · noun |
| [remote](https://en.wiktionary.org/wiki/remote#English) | At a distance; disconnected. | [ɹɪˈməʊt] · adj |
| [stolen](https://en.wiktionary.org/wiki/stolen#English) | That has been stolen. | /ˈstəʊ.ln̩/ · adj |
| [AP](https://en.wiktionary.org/wiki/AP#English) | An Advanced Placement program. |  · noun |
| [BID](https://en.wiktionary.org/wiki/BID#English) | twice a day, two times per day |  · adv |
| [abandoned](https://en.wiktionary.org/wiki/abandoned#English) | Having given oneself up to vice; immoral; extremely wicked, or sinning without restraint; irreclaimably wicked. | /əˈbæn.dənd/ · adj |
| [bid](https://en.wiktionary.org/wiki/bid#English) | To issue a command; to tell. | /bɪd/ · verb |
| [butter](https://en.wiktionary.org/wiki/butter#English) | A soft, fatty foodstuff made by churning the cream of milk (generally cow's milk). | /ˈbʌtəɹ/ · noun |
| [crap](https://en.wiktionary.org/wiki/crap#English) | A losing throw of 2, 3, or 12 in craps. | /kɹæp/ · noun |
| [decline](https://en.wiktionary.org/wiki/decline#English) | Downward movement, fall. | /dɪˈklaɪn/ · noun |
| [forgotten](https://en.wiktionary.org/wiki/forgotten#English) | Of which knowledge has been lost; which is no longer remembered. | /fəˈɡɒt.n̩/ · adj |
| [nurse](https://en.wiktionary.org/wiki/nurse#English) | Anyone performing this role, regardless of training or profession. | /nɜːs/ · noun |
| [sake](https://en.wiktionary.org/wiki/sake#English) | Cause, interest or account. | /ˈseɪ̯k/ · noun |
| [smooth](https://en.wiktionary.org/wiki/smooth#English) | Having a texture that lacks friction. Not rough. | /smuːð/ · adj |
| [string](https://en.wiktionary.org/wiki/string#English) | A long, thin and flexible structure made from threads twisted together. | /stɹɪŋ/ · noun |
| [thrown](https://en.wiktionary.org/wiki/thrown#English) | Launched by throwing. | /θɹəʊn/ · adj |
| [abroad](https://en.wiktionary.org/wiki/abroad#English) | Beyond the bounds of a country; in foreign countries. | /əˈbɹɔːd/ · adv |
| [bench](https://en.wiktionary.org/wiki/bench#English) | A long seat with or without a back, found for example in parks and schools. | /ˈbɛnt͡ʃ/ · noun |
| [broadcast](https://en.wiktionary.org/wiki/broadcast#English) | Cast or scattered widely in all directions; cast abroad. | /ˈbɹɔːd(ˌ)kɑːst/ · adj |
| [citizen](https://en.wiktionary.org/wiki/citizen#English) | A resident of a city or town, especially one with legally recognized rights or duties. | /ˈsɪtɪzən/ · noun |

</details>

<details><summary>Words 451–500</summary>

![[Resources/Audio/en/Words 0451-0500.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [entrance](https://en.wiktionary.org/wiki/entrance#English) | The action of entering, or going in. | /ˈɛn.tɹəns/ · noun |
| [fallen](https://en.wiktionary.org/wiki/fallen#English) | Having dropped by the force of gravity. | /ˈfɔːlən/ · adj |
| [handling](https://en.wiktionary.org/wiki/handling#English) | A touching, controlling, managing, using, taking care of, etc., with the hand or hands, or as with the hands. | /ˈhændl̩ɪŋ/ · noun |
| [lifetime](https://en.wiktionary.org/wiki/lifetime#English) | The duration of the life of someone or something. | /ˈlaɪf.taɪm/ · noun |
| [liquid](https://en.wiktionary.org/wiki/liquid#English) | Any of a class of consonant sounds that includes l and r. | /ˈlɪk.wɪd/ · noun |
| [mortgage](https://en.wiktionary.org/wiki/mortgage#English) | A legal agreement in which a borrower pledges real property as collateral for a loan used to purchase or refinance that property. | /ˈmɔːɡɪd͡ʒ/ · noun |
| [narrow](https://en.wiktionary.org/wiki/narrow#English) | Having a small width; not wide; having opposite edges or sides that are close, especially by comparison to length or depth. | /ˈnæɹəʊ/ · adj |
| [physics](https://en.wiktionary.org/wiki/physics#English) | The branch of science concerned with the study of the properties and interactions of space, time, matter and energy. | /ˈfɪz.ɪks/ · noun |
| [silly](https://en.wiktionary.org/wiki/silly#English) | Laughable or amusing through foolishness or a foolish appearance. | /ˈsɪl.i/ · adj |
| [translation](https://en.wiktionary.org/wiki/translation#English) | The conversion of text from one language to another. | /tɹænzˈleɪʃən/ · noun |
| [angle](https://en.wiktionary.org/wiki/angle#English) | A figure formed by two rays which start from a common point (a plane angle) or by three planes that intersect (a solid angle). | /ˈæŋ.ɡəl/ · noun |
| [enterprise](https://en.wiktionary.org/wiki/enterprise#English) | A company, business, organization, or other purposeful endeavor. | /ˈɛntəˌpɹaɪz/ · noun |
| [experiment](https://en.wiktionary.org/wiki/experiment#English) | A test under controlled conditions made to either demonstrate a known truth, examine the validity of a hypothesis, or determine the efficacy or likelihood of something previously untried. | /ɪkˈspɛɹ.ɪ.mənt/ · noun |
| [grass](https://en.wiktionary.org/wiki/grass#English) | Any plant of the family Poaceae, characterized by leaves that arise from nodes in the stem and leaf bases that wrap around the stem, especially those grown as ground cover rather than for grain. | /ɡɹɑːs/ · noun |
| [jay](https://en.wiktionary.org/wiki/jay#English) | Any of various other birds of similar appearance and behaviour. | /ˈd͡ʒeɪ/ · noun |
| [mill](https://en.wiktionary.org/wiki/mill#English) | A grinding apparatus for substances such as grains, seeds, etc. (Some are small and simple, and some are large and complex.) | /mɪl/ · noun |
| [pen](https://en.wiktionary.org/wiki/pen#English) | An enclosure (enclosed area) used to contain domesticated animals, especially sheep or cattle. | /pɛn/ · noun |
| [sixth](https://en.wiktionary.org/wiki/sixth#English) | The ordinal form of the number six. | /sɪksθ/ · adj |
| [spin](https://en.wiktionary.org/wiki/spin#English) | To rotate, revolve, gyrate (usually quickly); to partially or completely rotate to face another direction. | /spɪn/ · verb |
| [thirty](https://en.wiktionary.org/wiki/thirty#English) | The cardinal number occurring after twenty-nine and before thirty-one, represented in Arabic numerals as 30. | /ˈθɜːti/ · num |
| [collect](https://en.wiktionary.org/wiki/collect#English) | To gather together; amass. | /kəˈlɛkt/ · verb |
| [currency](https://en.wiktionary.org/wiki/currency#English) | Money or other items used to facilitate transactions. | /ˈkʌɹ.ən.si/ · noun |
| [funeral](https://en.wiktionary.org/wiki/funeral#English) | A ceremony to honor and remember a deceased person, often distinguished from a memorial service by the presence of the body of the deceased. | /ˈfjuː.nə.ɹəl/ · noun |
| [honey](https://en.wiktionary.org/wiki/honey#English) | A sweet, viscous, gold-colored fluid produced from plant nectar by bees, and often consumed by humans. | /ˈhʌni/ · noun |
| [settle](https://en.wiktionary.org/wiki/settle#English) | To determine (something which was exposed to doubt or question); to resolve conclusively; to set or fix (a time, an order of succession, etc). | /ˈsɛ.təl/ · verb |
| [sin](https://en.wiktionary.org/wiki/sin#English) | A violation of divine will or religious law. | /ˈsɪn/ · noun |
| [spell](https://en.wiktionary.org/wiki/spell#English) | Words or a formula supposed to have magical powers. | /spɛl/ · noun |
| [sword](https://en.wiktionary.org/wiki/sword#English) | A long bladed weapon with a grip and typically a pommel and crossguard (together forming a hilt), which is designed to cut, stab, slash and/or hack. | /soɹd/ · noun |
| [tongue](https://en.wiktionary.org/wiki/tongue#English) | The flexible muscular organ in the mouth that is used to move food around, for tasting and that is moved into various positions to modify the flow of air from the lungs in order to produce different sounds in speech. | /tʌŋ/ · noun |
| [achievement](https://en.wiktionary.org/wiki/achievement#English) | The act of achieving or performing; a successful performance; accomplishment. | /əˈt͡ʃiːv.mənt/ · noun |
| [automatic](https://en.wiktionary.org/wiki/automatic#English) | Capable of operating without external control or intervention. | /ˌɔː.təˈmæt.ɪk/ · adj |
| [begun](https://en.wiktionary.org/wiki/begun#English) | Having begun. | /bɪˈɡʌn/ · adj |
| [coat](https://en.wiktionary.org/wiki/coat#English) | An outer garment covering the upper torso and arms. | /ˈkoʊ̯t/ · noun |
| [consent](https://en.wiktionary.org/wiki/consent#English) | To express willingness, to give permission. | /kənˈsɛnt/ · verb |
| [drove](https://en.wiktionary.org/wiki/drove#English) | The herd being driven in a cattle (or other animal) drive; thus, a number of animals driven to market or new pastures; a group of livestock animals more generally. | /dɹəʊv/ · noun |
| [frequency](https://en.wiktionary.org/wiki/frequency#English) | The rate of occurrence of anything; the relationship between incidence and time period. | /ˈfɹiːkwənsi/ · noun |
| [logic](https://en.wiktionary.org/wiki/logic#English) | Logical. | /ˈlɒd͡ʒ.ɪk/ · adj |
| [objective](https://en.wiktionary.org/wiki/objective#English) | Of or relating to a material object, actual existence or reality. | /ɒbˈd͡ʒɛk.tɪv/ · adj |
| [Singapore](https://en.wiktionary.org/wiki/Singapore#English) | Singapore-style noodles | /ˈsɪŋəpɔː/ · noun |
| [breast](https://en.wiktionary.org/wiki/breast#English) | Either of the two organs on the front of a female human's chest, which contain the mammary glands; also the analogous organs in males. | /bɹɛst/ · noun |
| [chemistry](https://en.wiktionary.org/wiki/chemistry#English) | The branch of natural science that deals with the composition and constitution of substances and the changes that they undergo as a consequence of alterations in the constitution of their molecules. | /ˈkɛm.ɪ.stɹi/ · noun |
| [cotton](https://en.wiktionary.org/wiki/cotton#English) | A soft, fibrous, usually white substance consisting of fine hairs, especially the substance around the seeds of a plant of genus Gossypium. | /ˈkɒt.n̩/ · noun |
| [exit](https://en.wiktionary.org/wiki/exit#English) | An act of going out or going away, or leaving; a departure. | /ˈɛksɪt/ · noun |
| [input](https://en.wiktionary.org/wiki/input#English) | The act or process of putting in; infusion. | /ˈɪnpʊt/ · noun |
| [leather](https://en.wiktionary.org/wiki/leather#English) | A tough material produced from the skin of animals, by tanning or similar process, used e.g. for clothing; often denotes leather from cattle when no qualifier specifies otherwise. | /ˈlɛðə/ · noun |
| [outcome](https://en.wiktionary.org/wiki/outcome#English) | That which is produced or occurs as a result of an event or process. | /ˈaʊtkʌm/ · noun |
| [sequence](https://en.wiktionary.org/wiki/sequence#English) | A set of things next to each other in a set order; a series. | /ˈsiː.kwəns/ · noun |
| [tear](https://en.wiktionary.org/wiki/tear#English) | To rend (a solid material) by holding or restraining in two places and pulling apart, whether intentionally or not; to destroy or separate. | /tɛə/ · verb |
| [tennis](https://en.wiktionary.org/wiki/tennis#English) | A sport played by two players (or four in doubles), who alternately strike the ball over a net using racquets. | /ˈtɛn.ɪs/ · noun |
| [twelve](https://en.wiktionary.org/wiki/twelve#English) | The cardinal number occurring after eleven and before thirteen, represented in Arabic numerals as 12 and in Roman numerals as XII. | /twɛlv/ · num |

</details>

<details><summary>Words 501–550</summary>

![[Resources/Audio/en/Words 0501-0550.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [wolf](https://en.wiktionary.org/wiki/wolf#English) | Canis lupus; the largest wild member of the canine subfamily. | /wʊlf/ · noun |
| [absence](https://en.wiktionary.org/wiki/absence#English) | A state of being away or withdrawn from a place or from companionship | /ˈæb.s(ə)n̩s/ · noun |
| [ate](https://en.wiktionary.org/wiki/ate#English) | An elder sister | [ˈʔɐ.te] · noun |
| [bull](https://en.wiktionary.org/wiki/bull#English) | Specifically, one that is uncastrated. | /bʊl/ · noun |
| [swing](https://en.wiktionary.org/wiki/swing#English) | To rotate about an off-centre fixed point. | /ˈswɪŋ/ · verb |
| [tail](https://en.wiktionary.org/wiki/tail#English) | The caudal appendage of an animal that is attached to their posterior and near the anus or cloaca. | /ˈteɪ̯l/ · noun |
| [alert](https://en.wiktionary.org/wiki/alert#English) | Attentive; awake; on guard. | /əˈlɜːt/ · adj |
| [boom](https://en.wiktionary.org/wiki/boom#English) | To make a loud, hollow, resonant sound. | /buːm/ · verb |
| [knee](https://en.wiktionary.org/wiki/knee#English) | In humans, the joint or the region of the joint in the middle part of the leg between the thigh and the shank. | /niː/ · noun |
| [priest](https://en.wiktionary.org/wiki/priest#English) | A religious clergyman (clergywoman, clergyperson) who is trained to perform services or sacrifices at a church or temple. | /ˈpɹiːst/ · noun |
| [proven](https://en.wiktionary.org/wiki/proven#English) | Having been proved; having proved its value or truth. | /ˈpɹuː.vn̩/ · adj |
| [robin](https://en.wiktionary.org/wiki/robin#English) | A European robin, Erithacus rubecula. | /ˈɹɒ.bɪn/ · noun |
| [shake](https://en.wiktionary.org/wiki/shake#English) | To cause (something) to move rapidly in opposite directions alternatingly. | /ˈʃeɪk/ · verb |
| [teen](https://en.wiktionary.org/wiki/teen#English) | Synonym of teenager: a person between 13 and 19 years old (inclusive). | /ˈtiːn/ · noun |
| [wildlife](https://en.wiktionary.org/wiki/wildlife#English) | undomesticated animals, especially mammals, birds, and fish, which live in the wild. | /ˈwaɪldlaɪf/ · noun |
| [communist](https://en.wiktionary.org/wiki/communist#English) | Of, relating to, supporting, or advocating communism. | /ˈkɒm.jʊ.nɪst/ · adj |
| [courage](https://en.wiktionary.org/wiki/courage#English) | The quality of being confident, not afraid or easily intimidated, but without being incautious or inconsiderate. | /ˈkʌɹ.ɪd͡ʒ/ · noun |
| [del](https://en.wiktionary.org/wiki/del#English) | The symbol ∇ used to denote the gradient operator. | /dɛl/ · noun |
| [fighter](https://en.wiktionary.org/wiki/fighter#English) | A person who fights; a combatant. | /ˈfaɪ.tə(ɹ)/ · noun |
| [frozen](https://en.wiktionary.org/wiki/frozen#English) | Having undergone the process of freezing; in ice form. | /ˈfɹəʊzən/ · adj |
| [hiding](https://en.wiktionary.org/wiki/hiding#English) | A state of concealment. | /ˈhaɪdɪŋ/ · noun |
| [invest](https://en.wiktionary.org/wiki/invest#English) | To spend money, time, or energy on something, especially for some benefit or purpose; used with in. | /ɪnˈvɛst/ · verb |
| [pound](https://en.wiktionary.org/wiki/pound#English) | A unit of weight in various measurement systems. | /ˈpaʊ̯nd/ · noun |
| [purple](https://en.wiktionary.org/wiki/purple#English) | A colour between red and blue; violet, though often closer to magenta. | /ˈpɜː.pl̩/ · noun |
| [tissue](https://en.wiktionary.org/wiki/tissue#English) | Thin, woven, gauzelike fabric. | /ˈtɪs.juː/ · noun |
| [Vietnam](https://en.wiktionary.org/wiki/Vietnam#English) | A long and protracted war or conflict in which the dominating foreign occupier is unable to secure a victory. | /ˌviːətˈnɑːm/ · noun |
| [bite](https://en.wiktionary.org/wiki/bite#English) | To cut into something by clamping the teeth. | /baɪt/ · verb |
| [burned](https://en.wiktionary.org/wiki/burned#English) | Damaged or consumed by heat, fire, oxidation, or similar process. | /ˈbɜːnd/ · adj |
| [dare](https://en.wiktionary.org/wiki/dare#English) | To have enough courage (to do something). | /dɛə/ · verb |
| [domain](https://en.wiktionary.org/wiki/domain#English) | A geographic area owned or controlled by a single person or organization. | /ˌdəʊˈmeɪ̯n/ · noun |
| [investigate](https://en.wiktionary.org/wiki/investigate#English) | To inquire into or study in order to ascertain facts or information. | /ɪnˈvɛs.tə.ɡeɪt/ · verb |
| [mask](https://en.wiktionary.org/wiki/mask#English) | A cover, or partial cover, for the face, used for disguise or protection. | /mɑːsk/ · noun |
| [midnight](https://en.wiktionary.org/wiki/midnight#English) | The middle of the night: the sixth temporal hour, equidistant between sunset and sunrise. | /ˈmɪd(ˌ)naɪt/ · noun |
| [mouse](https://en.wiktionary.org/wiki/mouse#English) | Any mammal of the many rodent families (especially Muridae) that have a small body and a long tail. | /maʊs/ · noun |
| [piano](https://en.wiktionary.org/wiki/piano#English) | A percussive keyboard musical instrument, usually ranging over seven octaves, with white and black colored keys, played by pressing these keys, causing hammers to strike strings. | /ˈpjænəʊ/ · noun |
| [symbol](https://en.wiktionary.org/wiki/symbol#English) | A character or glyph representing an idea, concept or object. | /ˈsɪmbəl/ · noun |
| [toilet](https://en.wiktionary.org/wiki/toilet#English) | A room, enclosed area or single-purpose building containing a fixture or fixtures used for urination and defecation; a bathroom or water closet. | /ˈtɔɪ.lət/ · noun |
| [treaty](https://en.wiktionary.org/wiki/treaty#English) | A formal binding agreement concluded by subjects of international law, namely, states and international organizations; a convention, a pact. | /ˈtɹiːti/ · noun |
| [SA](https://en.wiktionary.org/wiki/SA#English) | To sexually assault (someone). | /ˈɛs.eɪ/ · verb |
| [bat](https://en.wiktionary.org/wiki/bat#English) | Any flying mammal of the order Chiroptera, usually small and nocturnal, insectivorous or frugivorous. | /bæt/ · noun |
| [calendar](https://en.wiktionary.org/wiki/calendar#English) | Any system by which time is divided into days, weeks, months, and years. | /ˈkæl.ən.də/ · noun |
| [craft](https://en.wiktionary.org/wiki/craft#English) | Ability, skillfulness, especially skill in making plans and carrying them into execution; dexterity in managing affairs, adroitness, practical cunning; ingenuity in constructing, dexterity . | /ˈkɹɑːft/ · noun |
| [edit](https://en.wiktionary.org/wiki/edit#English) | A change to the text of a document. | /ˈɛdɪt/ · noun |
| [fortune](https://en.wiktionary.org/wiki/fortune#English) | Destiny, especially favorable. | /ˈfɔːtjuːn/ · noun |
| [goodbye](https://en.wiktionary.org/wiki/goodbye#English) | Farewell; a formula used to another person or persons when the speaker, writer, or person addressed is departing. | /ɡʊdˈbaɪ/ · intj |
| [hardware](https://en.wiktionary.org/wiki/hardware#English) | Fixtures, equipment, fasteners, tools, and devices used for general-purpose construction and repair of a structure or object. Also such equipment as sold as stock by a store of the same name, e.g. hardware store. | /ˈhɑɹdˌwɛɹ/ · noun |
| [mi](https://en.wiktionary.org/wiki/mi#English) | A syllable used in sol-fa (solfège) to represent the third note of a major scale. | /miː/ · noun |
| [phrase](https://en.wiktionary.org/wiki/phrase#English) | A short written or spoken expression. | /ˈfɹeɪ̯z/ · noun |
| [regime](https://en.wiktionary.org/wiki/regime#English) | Mode of rule or management. | /ɹəˈʒiːm/ · noun |
| [slide](https://en.wiktionary.org/wiki/slide#English) | To (cause to) move in continuous contact with a surface. | /ˈslaɪ̯d/ · verb |

</details>

<details><summary>Words 551–600</summary>

![[Resources/Audio/en/Words 0551-0600.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [stem](https://en.wiktionary.org/wiki/stem#English) | The stock of a family; a race or generation of progenitors. | /stɛm/ · noun |
| [tiger](https://en.wiktionary.org/wiki/tiger#English) | Panthera tigris, a large predatory mammal of the cat family, indigenous to Asia. | /ˈtaɪɡə/ · noun |
| [Polish](https://en.wiktionary.org/wiki/Polish#English) | Of, from or native to Poland, or relating to the Polish language. | /ˈpəʊlɪʃ/ · adj |
| [alien](https://en.wiktionary.org/wiki/alien#English) | A person, animal, plant, or other thing which is from outside the family, group, organization, or territory under consideration. | /ˈeɪ.li.ən/ · noun |
| [dialogue](https://en.wiktionary.org/wiki/dialogue#English) | A conversation or other form of discourse between two or more individuals. | /ˈdaɪəlɒɡ/ · noun |
| [distinct](https://en.wiktionary.org/wiki/distinct#English) | Capable of being perceived very clearly. | /dɪˈstɪŋkt/ · adj |
| [drag](https://en.wiktionary.org/wiki/drag#English) | Resistance of a fluid to something moving through it. | /dɹæɡ/ · noun |
| [fifty](https://en.wiktionary.org/wiki/fifty#English) | The cardinal number occurring after forty-nine and before fifty-one. | /ˈfɪfti/ · num |
| [tables](https://en.wiktionary.org/wiki/tables#English) | Backgammon. | /ˈteɪbl̩z/ · noun |
| [worship](https://en.wiktionary.org/wiki/worship#English) | The devotion accorded to a deity or to a sacred object. | /ˈwɜː.ʃɪp/ · noun |
| [Turkish](https://en.wiktionary.org/wiki/Turkish#English) | Of, from, or pertaining to Turkey, the Turkish people or the Turkish language. | /ˈtɜː.kɪʃ/ · adj |
| [bass](https://en.wiktionary.org/wiki/bass#English) | Of sound, a voice or an instrument, low in pitch or frequency. | /beɪs/ · adj |
| [dual](https://en.wiktionary.org/wiki/dual#English) | Characterized by having two (usually equivalent) components. | /ˈd͡ʒuː.əl/ · adj |
| [galaxy](https://en.wiktionary.org/wiki/galaxy#English) | Any of the collections of many millions or billions of stars, galactic dust, black holes, etc. existing as independent and coherent systems, of which there are billions in the known universe. | /ˈɡæl.ək.si/ · noun |
| [knight](https://en.wiktionary.org/wiki/knight#English) | An armored and mounted warrior of the Middle Ages. | /ˈnaɪ̯t/ · noun |
| [pin](https://en.wiktionary.org/wiki/pin#English) | A needle without an eye (usually) made of drawn-out steel wire with one end sharpened and the other flattened or rounded into a head, used for fastening. | /pɪn/ · noun |
| [CM](https://en.wiktionary.org/wiki/CM#English) | A member of the Order of Canada. |  · noun |
| [acceptable](https://en.wiktionary.org/wiki/acceptable#English) | Capable, worthy, or sure of being accepted or received with pleasure; welcome; gratifying; pleasing to a receiver. | /əkˈsɛp.tə.bəl/ · adj |
| [copper](https://en.wiktionary.org/wiki/copper#English) | A reddish-brown metallic chemical element (symbol Cu) with the atomic number 29; also, the metal made up of this element. | /ˈkɒpə/ · noun |
| [overcome](https://en.wiktionary.org/wiki/overcome#English) | To surmount (a physical or abstract obstacle); to prevail over, to get the better of. | /ˌəʊ.vəˈkʌm/ · verb |
| [parallel](https://en.wiktionary.org/wiki/parallel#English) | Equally distant from one another at all points. | /ˈpæɹ.əˌlɛl/ · adj |
| [passage](https://en.wiktionary.org/wiki/passage#English) | A paragraph or section of text or music with particular meaning. | /ˈpæsɪd͡ʒ/ · noun |
| [pit](https://en.wiktionary.org/wiki/pit#English) | A hole in the ground. | /pɪt/ · noun |
| [stroke](https://en.wiktionary.org/wiki/stroke#English) | An act of hitting; a blow, a hit. | /stɹəʊk/ · noun |
| [vessel](https://en.wiktionary.org/wiki/vessel#English) | Any craft designed for transportation on or in water, such as a ship, boat, or submarine. | /ˈvɛsəl/ · noun |
| [anime](https://en.wiktionary.org/wiki/anime#English) | An animated work that originated in Japan, regardless of the artistic style. | /ˈæn.ɪ.meɪ/ · noun |
| [autumn](https://en.wiktionary.org/wiki/autumn#English) | The time period when someone or something is past its prime. | /ˈɔːtəm/ · noun |
| [bold](https://en.wiktionary.org/wiki/bold#English) | Courageous; daring. | /ˈbəʊld/ · adj |
| [breathe](https://en.wiktionary.org/wiki/breathe#English) | To draw air into (inhale), and expel air from (exhale), the lungs in order to extract oxygen and excrete waste gases. | /bɹiːð/ · verb |
| [federation](https://en.wiktionary.org/wiki/federation#English) | An act of joining together into a single political entity. | /ˌfɛdəˈɹeɪ̯ʃən/ · noun |
| [fiscal](https://en.wiktionary.org/wiki/fiscal#English) | Related to the treasury of a country, company, region or city, particularly to government spending and revenue. | /ˈfɪskəl/ · adj |
| [menu](https://en.wiktionary.org/wiki/menu#English) | The details of the food to be served at a banquet; a bill of fare. | /ˈmɛn.juː/ · noun |
| [oral](https://en.wiktionary.org/wiki/oral#English) | Relating to the mouth. | /ˈɔː.ɹəl/ · adj |
| [worn](https://en.wiktionary.org/wiki/worn#English) | Damaged and shabby as a result of much use. | /wɔːn/ · adj |
| [AC](https://en.wiktionary.org/wiki/AC#English) | supply of electric energy via a public electricity grid |  · noun |
| [brick](https://en.wiktionary.org/wiki/brick#English) | A hardened rectangular block of mud, clay etc., used for building. | /ˈbɹɪk/ · noun |
| [emperor](https://en.wiktionary.org/wiki/emperor#English) | The male monarch or ruler of an empire. | /ˈɛmp(ə)ɹə/ · noun |
| [forgive](https://en.wiktionary.org/wiki/forgive#English) | To pardon (someone); to waive any negative feeling towards or desire for punishment or retribution against. | /fə(ɹ)ˈɡɪv/ · verb |
| [oxygen](https://en.wiktionary.org/wiki/oxygen#English) | The chemical element (symbol O) with an atomic number of 8 and relative atomic mass of 15.9994. It is a colorless and odorless gas. Sometimes called elemental oxygen to distinguish it from molecular oxygen. | /ˈɒksɪd͡ʒən/ · noun |
| [pipe](https://en.wiktionary.org/wiki/pipe#English) | A wind instrument consisting of a tube, often lined with holes to allow for adjustment in pitch, sounded by blowing into the tube. | /ˈpaɪp/ · noun |
| [powder](https://en.wiktionary.org/wiki/powder#English) | The fine particles which are the result of reducing a dry substance by pounding, grinding, or triturating, or the result of decay; dust. | /ˈpaʊ.də(ɹ)/ · noun |
| [seventh](https://en.wiktionary.org/wiki/seventh#English) | The ordinal form of the number seven. | /ˈsɛvnθ/ · adj |
| [ye](https://en.wiktionary.org/wiki/ye#English) | You (the people being addressed). | /jiː/ · pron |
| [abortion](https://en.wiktionary.org/wiki/abortion#English) | A spontaneous abortion; a miscarriage. | /əˈbɔɹ.ʃn̩/ · noun |
| [accuracy](https://en.wiktionary.org/wiki/accuracy#English) | The state of being accurate; being free from error; exactness; correctness | /ˈak.jʊ.ɹə.si/ · noun |
| [artificial](https://en.wiktionary.org/wiki/artificial#English) | Man-made; made by humans; of artifice. | /ˌɑː.tɪˈfɪʃ.əl/ · adj |
| [bullet](https://en.wiktionary.org/wiki/bullet#English) | A projectile, usually of metal, shot from a gun at high speed. | /ˈbʊlɪt/ · noun |
| [copyright](https://en.wiktionary.org/wiki/copyright#English) | The right by law to be the entity which determines who may publish, copy and distribute a piece of writing, music, picture or other work of authorship. | /ˈkɑpiˌɹaɪt/ · noun |
| [deposit](https://en.wiktionary.org/wiki/deposit#English) | Sediment or rock that is not native to its present location or is different from the surrounding material. Sometimes refers to ore or gems. | /dɪˈpɒz.ɪt/ · noun |
| [er](https://en.wiktionary.org/wiki/er#English) | Said when hesitating in speech. | /ɜː/ · intj |

</details>

<details><summary>Words 601–650</summary>

![[Resources/Audio/en/Words 0601-0650.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [grandfather](https://en.wiktionary.org/wiki/grandfather#English) | A father of someone's parent. | /ˈɡɹæn(d)ˌfɑːðə(r)/ · noun |
| [habit](https://en.wiktionary.org/wiki/habit#English) | An action performed on a regular basis. | /ˈhæb.ɪt/ · noun |
| [mama](https://en.wiktionary.org/wiki/mama#English) | Synonym of mother (“a female parent”). | /ˈmæmə/ · noun |
| [robot](https://en.wiktionary.org/wiki/robot#English) | An intelligent mechanical being designed to look like a human or other creature, and usually made from metal. | /ˈɹəʊ.bɒt/ · noun |
| [shoe](https://en.wiktionary.org/wiki/shoe#English) | A piece of metal designed to be attached to a horse's foot as a means of protection; a horseshoe. | /ʃuː/ · noun |
| [suspension](https://en.wiktionary.org/wiki/suspension#English) | The act of suspending, or the state of being suspended. | /səˈspɛnʃən/ · noun |
| [wound](https://en.wiktionary.org/wiki/wound#English) | An injury, such as a cut, stab, or tear, to a (usually external) part of the body. | /ˈwuːnd/ · noun |
| [Brazilian](https://en.wiktionary.org/wiki/Brazilian#English) | A person from Brazil or of Brazilian descent. | /bɹəˈzɪ.lɪ.ən/ · noun |
| [Switzerland](https://en.wiktionary.org/wiki/Switzerland#English) | A neutral party in a dispute; one who does not take sides. | /ˈswɪtsələnd/ · noun |
| [ai](https://en.wiktionary.org/wiki/ai#English) | A pale-throated sloth (Bradypus tridactylus), endemic to forests of southern Venezuela, the Guianas, and northern Brazil. | /ˈɑ.i/ · noun |
| [asset](https://en.wiktionary.org/wiki/asset#English) | A thing or quality that has value, especially one that generates cash flows. | /ˈæsɛt/ · noun |
| [brush](https://en.wiktionary.org/wiki/brush#English) | An implement consisting of multiple more or less flexible bristles or other filaments attached to a handle, used for any of various purposes including cleaning, painting, and arranging hair. | /bɹʌʃ/ · noun |
| [burden](https://en.wiktionary.org/wiki/burden#English) | A heavy load. | /ˈbɜːdn̩/ · noun |
| [civilian](https://en.wiktionary.org/wiki/civilian#English) | A person following the pursuits of civil life, especially one who is not an active member of the armed forces. | /sɪˈvɪl.jən/ · noun |
| [cock](https://en.wiktionary.org/wiki/cock#English) | A rooster: a male gallinaceous bird, especially a male domestic chicken (Gallus gallus domesticus). | /kɒk/ · noun |
| [palm](https://en.wiktionary.org/wiki/palm#English) | Any of various evergreen trees from the family Palmae or Arecaceae, which are mainly found in the tropics. | /pɑːm/ · noun |
| [pub](https://en.wiktionary.org/wiki/pub#English) | A public house where beverages, primarily alcoholic, may be bought and consumed, also providing food and sometimes entertainment such as live music or television. | /pʌb/ · noun |
| [recipe](https://en.wiktionary.org/wiki/recipe#English) | Any set of instructions for preparing a mixture of ingredients. | /ˈɹɛs.ɪ.pi/ · noun |
| [shed](https://en.wiktionary.org/wiki/shed#English) | To part with, separate from, leave off; cast off, cast, let fall, be divested of. | /ʃɛd/ · verb |
| [snake](https://en.wiktionary.org/wiki/snake#English) | Any of the suborder Serpentes of legless reptiles with long, thin bodies and fork-shaped tongues. | /sneɪk/ · noun |
| [substance](https://en.wiktionary.org/wiki/substance#English) | Physical matter; material. | /ˈsʌbstəns/ · noun |
| [usage](https://en.wiktionary.org/wiki/usage#English) | A custom or established practice. | /ˈjuːsɪd͡ʒ/ · noun |
| [accidentally](https://en.wiktionary.org/wiki/accidentally#English) | In an accidental manner; by chance, unexpectedly. | /ˌæk.sɪˈdɛnt(ə)li/ · adv |
| [biology](https://en.wiktionary.org/wiki/biology#English) | The study of all life or living matter. | /baɪˈɒləd͡ʒi/ · noun |
| [canal](https://en.wiktionary.org/wiki/canal#English) | An artificial waterway or artificially improved river used for travel, shipping, or irrigation. | /kəˈnæl/ · noun |
| [dig](https://en.wiktionary.org/wiki/dig#English) | To get by digging; to take from the ground; often with up. | /dɪɡ/ · verb |
| [fluid](https://en.wiktionary.org/wiki/fluid#English) | Any substance which can flow with relative ease, tends to assume the shape of its container, and obeys Bernoulli's principle; a liquid, gas or plasma. | /ˈfluːɪd/ · noun |
| [handsome](https://en.wiktionary.org/wiki/handsome#English) | Having a pleasing appearance, good-looking, attractive, particularly | /ˈhæn.səm/ · adj |
| [lightning](https://en.wiktionary.org/wiki/lightning#English) | A flash of light produced by short-duration, high-voltage discharge of electricity within a cloud, between clouds, or between a cloud and the earth. | /ˈlaɪt.nɪŋ/ · noun |
| [unemployment](https://en.wiktionary.org/wiki/unemployment#English) | The state of having no job; joblessness. | /ʌn.ɪmˈplɔɪ.mənt/ · noun |
| [woke](https://en.wiktionary.org/wiki/woke#English) | Awake: conscious and not asleep. | /wəʊk/ · adj |
| [Swedish](https://en.wiktionary.org/wiki/Swedish#English) | Of or pertaining to Sweden. | /ˈswiː.dɪʃ/ · adj |
| [advocate](https://en.wiktionary.org/wiki/advocate#English) | Someone whose job is to speak for someone's case in a court of law; a counsel. | /ˈæd.və.kət/ · noun |
| [beaten](https://en.wiktionary.org/wiki/beaten#English) | Defeated. | /ˈbiː.tən/ · adj |
| [bitter](https://en.wiktionary.org/wiki/bitter#English) | Having an acrid taste (usually from a basic substance). | /ˈbɪt.ə/ · adj |
| [blown](https://en.wiktionary.org/wiki/blown#English) | Distended, swollen, or inflated. | /bləʊn/ · adj |
| [continuous](https://en.wiktionary.org/wiki/continuous#English) | Without stopping; without a break, cessation, or interruption. | /kənˈtɪn.juː.əs/ · adj |
| [dish](https://en.wiktionary.org/wiki/dish#English) | A vessel such as a plate for holding or serving food, often flat with a depressed region in the middle. | /dɪʃ/ · noun |
| [duck](https://en.wiktionary.org/wiki/duck#English) | To quickly lower (the head or body), often in order to prevent it from being struck by something. | /dʌk/ · verb |
| [gravity](https://en.wiktionary.org/wiki/gravity#English) | Of an activity, situation, words, etc.: the quality of having important or serious consequences; importance, seriousness. | /ˈɡɹævɪti/ · noun |
| [hung](https://en.wiktionary.org/wiki/hung#English) | Suspended by hanging. | /ˈhʌŋ/ · adj |
| [lied](https://en.wiktionary.org/wiki/lied#English) | An art song, usually sung solo in German and accompanied on the piano. | /liːd/ · noun |
| [nonsense](https://en.wiktionary.org/wiki/nonsense#English) | Letters or words, in writing or speech, that have no meaning or pattern or seem to have no meaning. | /ˈnɒn.səns/ · noun |
| [phoenix](https://en.wiktionary.org/wiki/phoenix#English) | A mythological bird, said to be the only one of its kind, which lives for 500 years and then dies by burning to ashes on a pyre of its own making, ignited by the sun. It then arises anew from the ashes. | /ˈfiːnɪks/ · noun |
| [stole](https://en.wiktionary.org/wiki/stole#English) | A scarf-like garment, often made of fur. | /stəʊl/ · noun |
| [swim](https://en.wiktionary.org/wiki/swim#English) | To move through the water, without touching the bottom; to propel oneself in water by natural means. | /swɪm/ · verb |
| [MD](https://en.wiktionary.org/wiki/MD#English) | Medicinae Doctor: Symbol indicating a higher research doctorate in medicine; Doctor of Medicine |  · noun |
| [bronze](https://en.wiktionary.org/wiki/bronze#English) | A naturally occurring or man-made alloy of copper, usually in combination with tin, but also with one or more other metals. | /bɹɒnz/ · noun |
| [bug](https://en.wiktionary.org/wiki/bug#English) | An insect of the order Hemiptera (the “true bugs”). | /bʌɡ/ · noun |
| [eighth](https://en.wiktionary.org/wiki/eighth#English) | The ordinal form of the number eight. | /eɪtθ/ · adj |

</details>

<details><summary>Words 651–700</summary>

![[Resources/Audio/en/Words 0651-0700.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [fa](https://en.wiktionary.org/wiki/fa#English) | A syllable used in solfège to represent the fourth diatonic (or sixth chromatic) note of a major scale. | /fɑ/ · noun |
| [flesh](https://en.wiktionary.org/wiki/flesh#English) | The soft tissue of the body, especially muscle and fat. | /flɛʃ/ · noun |
| [forty](https://en.wiktionary.org/wiki/forty#English) | The cardinal number occurring after thirty-nine and before forty-one, represented in Roman numerals as XL and in Arabic numerals as 40. | /ˈfɔːti/ · num |
| [laser](https://en.wiktionary.org/wiki/laser#English) | A device that produces a monochromatic, coherent beam of light. | /ˈleɪz.ə(ɹ)/ · noun |
| [occupation](https://en.wiktionary.org/wiki/occupation#English) | An activity or task with which one occupies oneself; usually specifically the productive activity, service, trade, or craft for which one is regularly paid; a job. | /ˌɒkjʊˈpeɪʃən/ · noun |
| [pollution](https://en.wiktionary.org/wiki/pollution#English) | Physical contamination, now especially the contamination of the environment by harmful substances, or by disruptive levels of noise, light etc. | /pəˈljuːʃən/ · noun |
| [radar](https://en.wiktionary.org/wiki/radar#English) | Often preceded by a descriptive word: a system using one of the above detection methods, differentiated by configuration or platform, frequency, power, and other technical attributes. | /ˈɹeɪdɑː/ · noun |
| [wireless](https://en.wiktionary.org/wiki/wireless#English) | Not having any wires. | /ˈwaɪə.ləs/ · adj |
| [PR](https://en.wiktionary.org/wiki/PR#English) | A PR interval. |  · noun |
| [bacteria](https://en.wiktionary.org/wiki/bacteria#English) | A type, species, or strain of bacterium. | /bakˈtɪə̯.ri.ə/ · noun |
| [blade](https://en.wiktionary.org/wiki/blade#English) | The (typically sharp-edged) part of a knife, sword, razor, or other tool with which it cuts. | /bleɪd/ · noun |
| [boot](https://en.wiktionary.org/wiki/boot#English) | A heavy shoe that covers part of the leg. | /buːt/ · noun |
| [coin](https://en.wiktionary.org/wiki/coin#English) | A piece of currency, usually metallic and in the shape of a disc, but sometimes polygonal, or with a hole in the middle. | /ˈkoɪ̯n/ · noun |
| [lit](https://en.wiktionary.org/wiki/lit#English) | Illuminated. | /ˈlɪt/ · adj |
| [pie](https://en.wiktionary.org/wiki/pie#English) | Any of various other, non-pastry dishes that maintain the general concept of a shell with a filling. | /paɪ/ · noun |
| [ram](https://en.wiktionary.org/wiki/ram#English) | A male sheep, typically uncastrated. | /ɹæm/ · noun |
| [sheep](https://en.wiktionary.org/wiki/sheep#English) | A woolly ruminant of the genus Ovis. | /ˈʃiːp/ · noun |
| [Ukrainian](https://en.wiktionary.org/wiki/Ukrainian#English) | Relating to Ukraine or its people or language. | /juːˈkɹeɪ.nɪ.ən/ · adj |
| [accessible](https://en.wiktionary.org/wiki/accessible#English) | Easy of access or approach. | /əkˈsɛs.ɪ.bəl/ · adj |
| [cherry](https://en.wiktionary.org/wiki/cherry#English) | A small fruit, usually red, black or yellow, with a smooth hard seed and a short hard stem. | /ˈt͡ʃɛɹi/ · noun |
| [conscious](https://en.wiktionary.org/wiki/conscious#English) | Alert, awake; with one's mental faculties active. | /ˈkɑn.ʃəs/ · adj |
| [earl](https://en.wiktionary.org/wiki/earl#English) | A British or Irish nobleman next in rank above a viscount and below a marquess; equivalent to a European count. A female using the style is termed a countess. | /ɜːl/ · noun |
| [liver](https://en.wiktionary.org/wiki/liver#English) | A large organ in the body that stores and metabolizes nutrients, destroys toxins and produces bile. It is responsible for thousands of biochemical reactions. | /ˈlɪvə/ · noun |
| [HIV](https://en.wiktionary.org/wiki/HIV#English) | The infection caused by HIV. | /ˌeɪtʃˌaɪˈviː/ · noun |
| [Thai](https://en.wiktionary.org/wiki/Thai#English) | Of or pertaining to Thailand. | /taɪ/ · adj |
| [crush](https://en.wiktionary.org/wiki/crush#English) | A violent collision or compression; a crash; destruction; ruin. | /kɹʌʃ/ · noun |
| [decrease](https://en.wiktionary.org/wiki/decrease#English) | Of a quantity, to become smaller. | /dɪˈkɹiːs/ · verb |
| [grammar](https://en.wiktionary.org/wiki/grammar#English) | A system of rules and principles for the structure of a language, or of languages in general. | /ˈɡɹæm.ə(ɹ)/ · noun |
| [lens](https://en.wiktionary.org/wiki/lens#English) | An object, usually made of glass, that focuses or defocuses the light that passes through it. | /lɛnz/ · noun |
| [rat](https://en.wiktionary.org/wiki/rat#English) | Any of the numerous members of several rodent families that usually have short limbs, a pointy snout, a long, hairless tail, and a body length greater than about 12 cm, or 5 inches. | /ɹæt/ · noun |
| [shine](https://en.wiktionary.org/wiki/shine#English) | To emit or reflect light so as to glow. | /ʃaɪn/ · verb |
| [acceptance](https://en.wiktionary.org/wiki/acceptance#English) | The act of accepting; the receiving of something offered, with acquiescence, approbation, or satisfaction; especially, favourable reception; approval. | /əkˈsɛp.təns/ · noun |
| [annually](https://en.wiktionary.org/wiki/annually#English) | Once every year without fail, yearly. | /ˈæn.jʊə.li/ · adv |
| [ash](https://en.wiktionary.org/wiki/ash#English) | The solid remains of a fire. | /ˈæʃ/ · noun |
| [aunt](https://en.wiktionary.org/wiki/aunt#English) | The sister or sister-in-law of one’s parent. | /ɑːnt/ · noun |
| [bubble](https://en.wiktionary.org/wiki/bubble#English) | A spherically contained volume of air or other gas in a liquid, commonly a soapy liquid. | /ˈbʌbəl/ · noun |
| [flew](https://en.wiktionary.org/wiki/flew#English) | The thick, dangling upper lip of certain breeds of dog, or the canine equivalent of the upper lip. | /fluː/ · noun |
| [hammer](https://en.wiktionary.org/wiki/hammer#English) | A tool with a heavy head and a handle used for pounding. | /ˈhæmə/ · noun |
| [icon](https://en.wiktionary.org/wiki/icon#English) | An image, symbol, picture, portrait, or other representation, usually as an object of religious devotion. | /ˈaɪ.kɒn/ · noun |
| [ours](https://en.wiktionary.org/wiki/ours#English) | Excluding the person(s) being addressed (exclusive ours) | /ˈaʊəz/ · pron |
| [thou](https://en.wiktionary.org/wiki/thou#English) | To address (a person) using the pronoun thou, especially as an expression of contempt or familiarity. | /ðaʊ/ · verb |
| [vocal](https://en.wiktionary.org/wiki/vocal#English) | Of, pertaining to, or resembling the human voice or speech. | /ˈvəʊ̯.kəl/ · adj |
| [Welsh](https://en.wiktionary.org/wiki/Welsh#English) | Of or pertaining to Wales. | /ˈwɛlʃ/ · adj |
| [accomplished](https://en.wiktionary.org/wiki/accomplished#English) | Completed; effected; established. | /əˈkɑm.plɪʃt/ · adj |
| [burst](https://en.wiktionary.org/wiki/burst#English) | To break from internal pressure. | /bɜːst/ · verb |
| [cattle](https://en.wiktionary.org/wiki/cattle#English) | Domesticated animals of the species Bos taurus (cows, bulls, steers, oxen etc), and other hoofed mammals of the genus Bos. | /ˈkætəl/ · noun |
| [earthquake](https://en.wiktionary.org/wiki/earthquake#English) | A shaking of the ground, caused by volcanic activity or movement around geologic faults. | /ˈɜːθkweɪk/ · noun |
| [southeast](https://en.wiktionary.org/wiki/southeast#English) | The intercardinal compass point halfway between east and south; specifically at a bearing of 135°. | /sawˈθɪjst/ · noun |
| [vertical](https://en.wiktionary.org/wiki/vertical#English) | Standing, pointing, or moving straight up or down; parallel to the local direction of gravity; along the direction of a plumb line; perpendicular to something horizontal. | /ˈvɜː.tɪ.kəl/ · adj |
| [workshop](https://en.wiktionary.org/wiki/workshop#English) | A room, especially one which is not particularly large, used for manufacturing or other light industrial work. | /ˈwɜːk.ʃɒp/ · noun |

</details>

<details><summary>Words 701–750</summary>

![[Resources/Audio/en/Words 0701-0750.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [aboard](https://en.wiktionary.org/wiki/aboard#English) | On board; into or within a ship or boat; hence, into or within a railway car. | /əˈbɔːd/ · adv |
| [abstract](https://en.wiktionary.org/wiki/abstract#English) | An abridgement or summary of a longer publication. | /ˈæbˌstɹækt/ · noun |
| [accent](https://en.wiktionary.org/wiki/accent#English) | A higher-pitched or stronger (louder or longer) articulation of a particular syllable of a word or phrase in order to distinguish it from the others or to emphasize it. | /ˈak.sənt/ · noun |
| [awake](https://en.wiktionary.org/wiki/awake#English) | Not asleep; conscious. | /əˈweɪk/ · adj |
| [buffalo](https://en.wiktionary.org/wiki/buffalo#English) | An animal from the subtribe Bubalina, also known as true buffalos, such as the Cape buffalo, Syncerus caffer, or the water buffalo, Bubalus bubalis. | /ˈbʌf.əl.əʊ/ · noun |
| [cow](https://en.wiktionary.org/wiki/cow#English) | An adult female of the species Bos taurus, especially one that has calved. | /kaʊ/ · noun |
| [curve](https://en.wiktionary.org/wiki/curve#English) | A bend, such as in a road. | /kɜːv/ · noun |
| [fifteen](https://en.wiktionary.org/wiki/fifteen#English) | The cardinal number occurring after fourteen (14) and before sixteen (16). | /ˈfɪf.tiːn/ · num |
| [grandmother](https://en.wiktionary.org/wiki/grandmother#English) | A mother of someone's parent. | /ˈɡɹæn(d)ˌmʌðə(r)/ · noun |
| [inflation](https://en.wiktionary.org/wiki/inflation#English) | An act, instance of, or state of expansion or increase in size, especially by injection of a gas or liquid. | /ɪnˈfleɪ.ʃən/ · noun |
| [lean](https://en.wiktionary.org/wiki/lean#English) | To incline, deviate, or bend, from a vertical position; to be in a position thus inclining or deviating. | /ˈliːn/ · verb |
| [mason](https://en.wiktionary.org/wiki/mason#English) | A bricklayer, one whose occupation is to build with stone or brick. | /ˈmeɪsən/ · noun |
| [northwest](https://en.wiktionary.org/wiki/northwest#English) | The intercardinal compass point halfway between west and north; specifically at a bearing of 315°. | /nɔɹθˈwɛst/ · noun |
| [organ](https://en.wiktionary.org/wiki/organ#English) | The larger part of an organism, composed of tissues that perform similar functions. | /ˈɔːɡən/ · noun |
| [peer](https://en.wiktionary.org/wiki/peer#English) | To look with difficulty, or as if searching for something. | /pɪə/ · verb |
| [pig](https://en.wiktionary.org/wiki/pig#English) | Any of several mammalian species of the family Suidae, having cloven hooves, bristles and a snout adapted for digging; especially the domesticated animal Sus domesticus. | /ˈpɪɡ/ · noun |
| [rod](https://en.wiktionary.org/wiki/rod#English) | A straight, round stick, shaft, bar, cane, or staff. | /ɹɒd/ · noun |
| [thunder](https://en.wiktionary.org/wiki/thunder#English) | The loud rumbling, cracking, or crashing sound caused by expansion of rapidly heated air around a lightning bolt. | /ˈθʌndə/ · noun |
| [accordance](https://en.wiktionary.org/wiki/accordance#English) | Agreement; harmony; conformity; compliance. | /əˈkɔː.dəns/ · noun |
| [ba](https://en.wiktionary.org/wiki/ba#English) | A being's soul or personality, represented as a bird-headed figure, which survives after death but must be sustained with offerings of food. | /bɑː/ · noun |
| [bend](https://en.wiktionary.org/wiki/bend#English) | To cause (something) to change its shape into a curve, by physical force, chemical action, or any other means. | /bɛnd/ · verb |
| [eagle](https://en.wiktionary.org/wiki/eagle#English) | Any of several large carnivorous and carrion-eating birds in the family Accipitridae, having a powerful hooked bill and keen vision. | /ˈiːɡəl/ · noun |
| [eaten](https://en.wiktionary.org/wiki/eaten#English) | Having been consumed by eating. | /ˈiː.tn̩/ · adj |
| [fitted](https://en.wiktionary.org/wiki/fitted#English) | Tailored to the shape of a person's body. | /ˈfɪtɪd/ · adj |
| [helicopter](https://en.wiktionary.org/wiki/helicopter#English) | A powered troweling machine with spinning blades used to spread concrete. | /ˈheliːˌkɔptə(ɹ)/ · noun |
| [observation](https://en.wiktionary.org/wiki/observation#English) | The act of observing, and the fact of being observed (see observance) | /ˌɒbzəˈveɪʃn̩/ · noun |
| [precise](https://en.wiktionary.org/wiki/precise#English) | Both exact and accurate. | /pɹɪˈsaɪs/ · adj |
| [retreat](https://en.wiktionary.org/wiki/retreat#English) | The act of pulling back or withdrawing, as from something dangerous, or unpleasant. | /ɹɪˈtɹiːt/ · noun |
| [um](https://en.wiktionary.org/wiki/um#English) | Expression of hesitation, uncertainty or space filler in conversation. | /ʌm/ · intj |
| [valve](https://en.wiktionary.org/wiki/valve#English) | A device that controls the flow of a gas or fluid through a space, such as a pipe, manifold, or plenum. | /vælv/ · noun |
| [MG](https://en.wiktionary.org/wiki/MG#English) | A sports car manufactured by Morris Garages. |  · noun |
| [charm](https://en.wiktionary.org/wiki/charm#English) | An object, act or words believed to have magic power (usually carries a positive connotation). | /tʃɑːm/ · noun |
| [cruel](https://en.wiktionary.org/wiki/cruel#English) | Intentionally causing or reveling in pain and suffering; merciless, heartless. | /ˈkɹuːəl/ · adj |
| [deer](https://en.wiktionary.org/wiki/deer#English) | A ruminant mammal with hooves and often antlers, of the family Cervidae, or one of several similar animals from related families of the order Artiodactyla, such as the musk deer or mouse deer. | /dɪə/ · noun |
| [dive](https://en.wiktionary.org/wiki/dive#English) | To swim under water. | /daɪv/ · verb |
| [eleven](https://en.wiktionary.org/wiki/eleven#English) | The cardinal number occurring after ten and before twelve. Represented as 11 in Arabic digits. | /ɪˈlɛv.ən/ · num |
| [tribe](https://en.wiktionary.org/wiki/tribe#English) | An ethnic group larger than a band or clan (and which may contain clans) but smaller than a nation (and which in turn may constitute a nation with other tribes). The tribe is often the basis of ethnic identity. | /tɹaɪb/ · noun |
| [CT](https://en.wiktionary.org/wiki/CT#English) | A CT scan. |  · noun |
| [ace](https://en.wiktionary.org/wiki/ace#English) | A playing card showing a single pip, typically the highest or lowest ranking card in a game. | /ˈeɪ̯s/ · noun |
| [bankruptcy](https://en.wiktionary.org/wiki/bankruptcy#English) | A legally declared or recognized condition of insolvency of a person or organization. | /ˈbæŋ.kɹʌp(t).si/ · noun |
| [entertaining](https://en.wiktionary.org/wiki/entertaining#English) | Very amusing; that entertains. | /ˌɛntəɹˈteɪnɪŋ/ · adj |
| [freeze](https://en.wiktionary.org/wiki/freeze#English) | Especially of a liquid, to become solid due to low temperature. | /ˈfɹiːz/ · verb |
| [handful](https://en.wiktionary.org/wiki/handful#English) | The amount that a hand will grasp or contain. | /ˈhæn(d)fʊl/ · noun |
| [keyboard](https://en.wiktionary.org/wiki/keyboard#English) | A set of keys laid out in a gridlike pattern, used for typing on a typewriter, computer, etc. | /ˈki.bɔɹd/ · noun |
| [locally](https://en.wiktionary.org/wiki/locally#English) | With respect to place; in place. | /ˈləʊkəli/ · adv |
| [noon](https://en.wiktionary.org/wiki/noon#English) | The time of day when the Sun seems to reach its highest point in the sky; solar noon. | /nuːn/ · noun |
| [proportion](https://en.wiktionary.org/wiki/proportion#English) | A quantity of something that is part of the whole amount or number. | /pɹəˈpɔɹʃən/ · noun |
| [throne](https://en.wiktionary.org/wiki/throne#English) | An impressive seat used by a monarch, often on a raised dais in a throne room and reserved for formal occasions. | /θɹəʊ̯n/ · noun |
| [OS](https://en.wiktionary.org/wiki/OS#English) | An Ordnance Survey map. | /ˌoʊ ˈɛs/ · noun |
| [array](https://en.wiktionary.org/wiki/array#English) | Clothing and ornamentation; raiment. | /əˈɹeɪ/ · noun |

</details>

<details><summary>Words 751–800</summary>

![[Resources/Audio/en/Words 0751-0800.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [belly](https://en.wiktionary.org/wiki/belly#English) | The abdomen (especially a fat one). | /ˈbɛli/ · noun |
| [consensus](https://en.wiktionary.org/wiki/consensus#English) | A process of decision-making that seeks widespread agreement among group members. | /kənˈsɛnsəs/ · noun |
| [lemon](https://en.wiktionary.org/wiki/lemon#English) | A yellowish citrus fruit. | /ˈlɛmən/ · noun |
| [ore](https://en.wiktionary.org/wiki/ore#English) | Rock or other material that contains valuable or utilitarian materials; primarily a rock containing metals or gems for which it is typically mined and processed. | /oɹ/ · noun |
| [os](https://en.wiktionary.org/wiki/os#English) | Synonym of bone. | /ɒs/ · noun |
| [pour](https://en.wiktionary.org/wiki/pour#English) | To cause (liquid, or liquid-like substance) to flow in a stream, either out of a container or into it. | /pɔː/ · verb |
| [sang](https://en.wiktionary.org/wiki/sang#English) | ginseng | /ˈsæŋ/ · noun |
| [southwest](https://en.wiktionary.org/wiki/southwest#English) | The intercardinal compass point halfway between south and west; specifically at a bearing of 225°. | /saʊθˈwɛst/ · noun |
| [bee](https://en.wiktionary.org/wiki/bee#English) | Any stinging flying insect, especially a wasp. | /ˈbiː/ · noun |
| [dairy](https://en.wiktionary.org/wiki/dairy#English) | (also dairy products or dairy produce) Products produced from milk. | /ˈdɛə.ɹi/ · noun |
| [drill](https://en.wiktionary.org/wiki/drill#English) | To create (a hole) by removing material with a drill (tool). | /dɹɪl/ · verb |
| [euro](https://en.wiktionary.org/wiki/euro#English) | The currency unit of the European Monetary Union. Symbol: € | /ˈjʊəɹəʊ/ · noun |
| [forecast](https://en.wiktionary.org/wiki/forecast#English) | To estimate how something will be in the future. | /ˈfɔːkɑːst/ · verb |
| [meter](https://en.wiktionary.org/wiki/meter#English) | A device that measures things. | /ˈmitəɹ/ · noun |
| [olive](https://en.wiktionary.org/wiki/olive#English) | A tree of species Olea europaea cultivated since ancient times in the Mediterranean for its fruit and the oil obtained from it. | /ˈɒ.lɪv/ · noun |
| [servant](https://en.wiktionary.org/wiki/servant#English) | One who is hired to perform regular household or other duties, and receives compensation. As opposed to a slave. | /ˈsɜːvənt/ · noun |
| [vacuum](https://en.wiktionary.org/wiki/vacuum#English) | A region of space that contains no matter. | /ˈvæ.kjuːm/ · noun |
| [basin](https://en.wiktionary.org/wiki/basin#English) | A wide bowl for washing, sometimes affixed to a wall. | /ˈbeɪsɪn/ · noun |
| [breed](https://en.wiktionary.org/wiki/breed#English) | To produce offspring sexually; to bear young. | /ˈbɹiːd/ · verb |
| [dump](https://en.wiktionary.org/wiki/dump#English) | A place where waste or garbage is left; a ground or place for dumping ashes, refuse, etc.; a disposal site. | /dʌmp/ · noun |
| [elephant](https://en.wiktionary.org/wiki/elephant#English) | A large mammal of the family Elephantidae in the order Proboscidea, having a trunk, and native to Africa and Asia. | /ˈɛlɪfənt/ · noun |
| [poison](https://en.wiktionary.org/wiki/poison#English) | A substance that is harmful or lethal to a living organism when ingested. | /ˈpɔɪ.zən/ · noun |
| [tooth](https://en.wiktionary.org/wiki/tooth#English) | A hard, calcareous structure present in the mouth of many vertebrate animals, generally used for biting and chewing food. | /tuːθ/ · noun |
| [torn](https://en.wiktionary.org/wiki/torn#English) | Having undergone tearing; ripped or shredded. | /tɔːn/ · adj |
| [basket](https://en.wiktionary.org/wiki/basket#English) | A lightweight woven container, generally round, open at the top, and tapering toward the bottom. | /ˈbɑːskɪt/ · noun |
| [beard](https://en.wiktionary.org/wiki/beard#English) | Facial hair on the chin, cheeks, jaw and neck. | /bɪəd/ · noun |
| [bio](https://en.wiktionary.org/wiki/bio#English) | A short section of a user profile that contains information about the user, especially one which can be customised; the about me section. | /ˈbaɪəʊ/ · noun |
| [blanket](https://en.wiktionary.org/wiki/blanket#English) | A heavy, loosely woven fabric, usually large and woollen, used for warmth while sleeping or resting. | /ˈblæŋ.kɪt/ · noun |
| [bucket](https://en.wiktionary.org/wiki/bucket#English) | A container made of rigid material, often with a handle, used to carry liquids or small items. | /ˈbʌkɪt/ · noun |
| [computing](https://en.wiktionary.org/wiki/computing#English) | The process or act of calculation. | /kəmˈpjuːtɪŋ/ · noun |
| [continent](https://en.wiktionary.org/wiki/continent#English) | One of the main contiguous landmasses, separated by water or geological features, on the surface of a planet, sometimes including its continental shelves and the islands on them. | /ˈkɒntɪnənt/ · noun |
| [flame](https://en.wiktionary.org/wiki/flame#English) | The visible part of fire; a stream of burning vapour or gas, emitting light and heat. | /fleɪm/ · noun |
| [graduation](https://en.wiktionary.org/wiki/graduation#English) | The action or process of graduating and receiving a diploma for completing a course of study (such as from an educational institution). | /ˌɡɹæd͡ʒuˈeɪʃən/ · noun |
| [ninth](https://en.wiktionary.org/wiki/ninth#English) | The ordinal form of the number nine. | /naɪnθ/ · adj |
| [penny](https://en.wiktionary.org/wiki/penny#English) | In the United Kingdom, a unit of currency worth ¹⁄₁₀₀ of a pound sterling, or a copper coin worth this amount. Abbreviation: p. | /ˈpɛni/ · noun |
| [quantity](https://en.wiktionary.org/wiki/quantity#English) | A fundamental, generic term used when referring to the measurement (count, amount) of a scalar, vector, number of items or to some other way of denominating the value of a collection or group of items. | /ˈkwɒn.tɪ.ti/ · noun |
| [rainbow](https://en.wiktionary.org/wiki/rainbow#English) | A multicoloured arch in the sky, produced by prismatic refraction of light within droplets of rain in the air. | /ˈɹeɪnboʊ/ · noun |
| [te](https://en.wiktionary.org/wiki/te#English) | In solfège, the lowered seventh note of a major scale (the note B-flat in the fixed-do system): ta. | /tiː/ · noun |
| [toe](https://en.wiktionary.org/wiki/toe#English) | Each of the five digits on the end of the human foot. | /təʊ/ · noun |
| [AB](https://en.wiktionary.org/wiki/AB#English) | A blood type of the ABO system that has both blood antigens and may receive all blood types, and donate to AB. | /ˌeɪˈbiː/ · noun |
| [AR](https://en.wiktionary.org/wiki/AR#English) | An AR-15 personal semi-automatic rifle, M-16 assault rifle, M-4 carbine, derivative or related gun; the Armalite AR family and derivatives. |  · noun |
| [ab](https://en.wiktionary.org/wiki/ab#English) | An abscess caused by injecting an illegal drug, usually heroin. | /æb/ · noun |
| [accommodation](https://en.wiktionary.org/wiki/accommodation#English) | Lodging in a dwelling or similar living quarters afforded to travellers in hotels or on cruise ships, or students, etc. | /əˌkɒm.əˈdeɪ.ʃən/ · noun |
| [cemetery](https://en.wiktionary.org/wiki/cemetery#English) | A place where the dead are buried; a graveyard or memorial park. | /ˈsɛm.ɪˌtɹi/ · noun |
| [deficit](https://en.wiktionary.org/wiki/deficit#English) | Deficiency in amount or quality; a falling short; lack. | /ˈdɛfɪsɪt/ · noun |
| [laundry](https://en.wiktionary.org/wiki/laundry#English) | A laundering; a washing. | /ˈlɔːn.dɹi/ · noun |
| [lifting](https://en.wiktionary.org/wiki/lifting#English) | The action or process by which something is lifted; elevation | /ˈlɪf.tɪŋ/ · noun |
| [northeast](https://en.wiktionary.org/wiki/northeast#English) | The intercardinal compass point halfway between north and east; specifically at a bearing of 45°. | /noːˈθɪjst/ · noun |
| [password](https://en.wiktionary.org/wiki/password#English) | A word relayed to a person to gain admittance to a place or to gain access to information. | /ˈpæs.wɜɹd/ · noun |
| [rational](https://en.wiktionary.org/wiki/rational#English) | Capable of reasoning. | /ˈɹæʃ(ə)nəl/ · adj |

</details>

<details><summary>Words 801–850</summary>

![[Resources/Audio/en/Words 0801-0850.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [temporarily](https://en.wiktionary.org/wiki/temporarily#English) | For a limited period of time; not permanently. | /ˌtɛmpəˈɹɛɹəli/ · adv |
| [NC](https://en.wiktionary.org/wiki/NC#English) | NASA research cargo plane designations. |  · noun |
| [accomplish](https://en.wiktionary.org/wiki/accomplish#English) | To finish successfully. | /əˈkʌm.plɪʃ/ · verb |
| [apology](https://en.wiktionary.org/wiki/apology#English) | An expression of remorse or regret for having said or done something that harmed another: an instance of apologizing (saying that one is sorry). | /əˈpɒl.ə.d͡ʒi/ · noun |
| [beg](https://en.wiktionary.org/wiki/beg#English) | To request the help of someone, often in the form of money. | /ˈbɛɡ/ · verb |
| [brass](https://en.wiktionary.org/wiki/brass#English) | A memorial or sepulchral tablet usually made of brass or latten: a monumental brass. | /bɹɑːs/ · noun |
| [diesel](https://en.wiktionary.org/wiki/diesel#English) | A fuel derived from petroleum (or other oils) but heavier than gasoline/petrol. Used to power diesel engines which burn this fuel using the heat produced when air is compressed. | /ˈdiːzəl/ · noun |
| [hack](https://en.wiktionary.org/wiki/hack#English) | To chop or cut down in a rough manner. | /hæk/ · verb |
| [penis](https://en.wiktionary.org/wiki/penis#English) | The male erectile reproductive organ used for sexual intercourse that in the human male and other placental mammals is also used for urination; the tubular portion of the external male genitalia (excluding the scrotum). | /ˈpiː.nɪs/ · noun |
| [rabbit](https://en.wiktionary.org/wiki/rabbit#English) | A mammal of most genera of the family Leporidae, with long ears, long hind legs and a short, fluffy tail. (Those of the larger kind are instead called hares) | /ˈɹæbɪt/ · noun |
| [shook](https://en.wiktionary.org/wiki/shook#English) | A set of pieces for making a cask or box, usually wood. | /ʃʊk/ · noun |
| [slim](https://en.wiktionary.org/wiki/slim#English) | Slender in an attractive way. | /ˈslɪm/ · adj |
| [tide](https://en.wiktionary.org/wiki/tide#English) | The daily fluctuation in the level of the sea caused by the gravitational influence of the moon and the sun. | /taɪd/ · noun |
| [withdraw](https://en.wiktionary.org/wiki/withdraw#English) | To draw or pull (something) away or back from its original position or situation. | /wɪðˈdɹɔː/ · verb |
| [withdrawal](https://en.wiktionary.org/wiki/withdrawal#English) | Receiving from someone's care what one has earlier entrusted to them. Usually refers to money. | /wɪðˈdɹɔː(ə)l/ · noun |
| [bi](https://en.wiktionary.org/wiki/bi#English) | A biceps muscle. | /baɪ/ · noun |
| [blonde](https://en.wiktionary.org/wiki/blonde#English) | (film, television, theater) A kind of 2,000-watt lamp. | /blɒnd/ · noun |
| [bust](https://en.wiktionary.org/wiki/bust#English) | To break. | /bʌst/ · verb |
| [collar](https://en.wiktionary.org/wiki/collar#English) | The part of an upper garment (shirt, jacket, etc.) that fits around the neck and throat, especially if sewn from a separate piece of fabric. | /ˈkɒlə/ · noun |
| [cum](https://en.wiktionary.org/wiki/cum#English) | Used in indicating a thing or person which has two or more roles, functions, or natures, or which has changed from one to another. | /kʌm/ · prep |
| [finale](https://en.wiktionary.org/wiki/finale#English) | The grand end of something, especially of a show or piece of music. | /fɪˈnɑːli · noun |
| [hart](https://en.wiktionary.org/wiki/hart#English) | A male deer, especially the male of the red deer after his fifth year. | /hɑːt/ · noun |
| [nut](https://en.wiktionary.org/wiki/nut#English) | Any of various hard-shelled seeds or hard, dry fruits from various families of plants. | /nʌt/ · noun |
| [o'clock](https://en.wiktionary.org/wiki/o%27clock#English) | Used to indicate that it is time to do a specific action, or time for a specific action to occur. | /əˈklɒk/ · adv |
| [shallow](https://en.wiktionary.org/wiki/shallow#English) | Having little depth; significantly less deep than wide. | /ˈʃæləʊ/ · adj |
| [sunset](https://en.wiktionary.org/wiki/sunset#English) | The moment each evening when the sun disappears below the western horizon. | /ˈsʌnˌsɛt/ · noun |
| [thee](https://en.wiktionary.org/wiki/thee#English) | To address (a person) using the pronoun thee. | /ðiː/ · verb |
| [Arabic](https://en.wiktionary.org/wiki/Arabic#English) | Related to the Arabic language. | /ˈæɹəbɪk/ · adj |
| [Portuguese](https://en.wiktionary.org/wiki/Portuguese#English) | Of or pertaining to Portugal. | /ˌpɔː.t͡ʃəˈɡiːz/ · adj |
| [analyst](https://en.wiktionary.org/wiki/analyst#English) | Someone who analyzes. | /ˈænəlɪst/ · noun |
| [burnt](https://en.wiktionary.org/wiki/burnt#English) | Damaged or injured by fire or heat. | /bɜːnt/ · adj |
| [cloth](https://en.wiktionary.org/wiki/cloth#English) | A fabric, usually made of woven, knitted, or felted fibres or filaments, such as used in dressing, decorating, cleaning or other practical use. Sometimes, woven fabric specifically. | /klɒθ/ · noun |
| [differ](https://en.wiktionary.org/wiki/differ#English) | Not to have the same traits or characteristics; to be unalike or distinct. | /ˈdɪfə/ · verb |
| [kidney](https://en.wiktionary.org/wiki/kidney#English) | An organ in the body that filters the blood, producing urine. | /ˈkɪdni/ · noun |
| [orbit](https://en.wiktionary.org/wiki/orbit#English) | An elliptical movement of an object about a celestial object or Lagrange point, especially a periodic elliptical revolution. | /ˈɔː.bɪt/ · noun |
| [tin](https://en.wiktionary.org/wiki/tin#English) | A malleable, ductile, metallic element, resistant to corrosion, with atomic number 50 and symbol Sn. | /tɪn/ · noun |
| [TA](https://en.wiktionary.org/wiki/TA#English) | To act as a teaching assistant (for a class). |  · verb |
| [abandon](https://en.wiktionary.org/wiki/abandon#English) | To give up or relinquish control of, to surrender or to give oneself over, or to yield to one's emotions. | /əˈbæn.dən/ · verb |
| [accordingly](https://en.wiktionary.org/wiki/accordingly#English) | Agreeably; correspondingly; suitably. | /əˈkɔɹ.dɪŋ.li/ · adv |
| [aesthetic](https://en.wiktionary.org/wiki/aesthetic#English) | Concerned with beauty, artistic effect, or appearance. | /iːsˈθɛ.tɪk/ · adj |
| [anchor](https://en.wiktionary.org/wiki/anchor#English) | A tool used to moor a vessel to the bottom of a sea or river to resist movement. | /ˈæŋ.kəː/ · noun |
| [dictionary](https://en.wiktionary.org/wiki/dictionary#English) | A synchronic dictionary of a standardised language held to only contain words that are properly part of the language. | /ˈdɪk.ʃə.nə.ɹi/ · noun |
| [dimension](https://en.wiktionary.org/wiki/dimension#English) | A single aspect of a given thing. | /daɪˈmɛn.ʃən/ · noun |
| [goat](https://en.wiktionary.org/wiki/goat#English) | Any ruminant of the genus Capra. | /ɡəʊt/ · noun |
| [AA](https://en.wiktionary.org/wiki/AA#English) | A member of Alcoholics Anonymous. |  · noun |
| [aa](https://en.wiktionary.org/wiki/aa#English) | A form of lava flow associated with Hawaiian-type volcanoes, consisting of basaltic rock, usually dark-colored with a jagged and loose, clinkery surface. Compare pahoehoe. | /ˈɑː.ɑː/ · noun |
| [civilization](https://en.wiktionary.org/wiki/civilization#English) | An organized culture encompassing many communities, often on the scale of a nation or a people; a stage or system of social, political, or technical development. | /ˌsɪv.ɪ.laɪˈzeɪ.ʃən/ · noun |
| [goddess](https://en.wiktionary.org/wiki/goddess#English) | A female deity. | /ˈɡɒdɛs/ · noun |
| [massage](https://en.wiktionary.org/wiki/massage#English) | The action of rubbing, kneading or hitting someone's body, to help the person relax, prepare for muscular action (as in contact sports) or to relieve aches. | /ˈmæsɑː(d)ʒ/ · noun |
| [musician](https://en.wiktionary.org/wiki/musician#English) | A composer, conductor, or performer of music; specifically, a person who sings and/or plays a musical instrument as a hobby, occupation, or profession. | /mjuˈzɪʃən/ · noun |

</details>

<details><summary>Words 851–900</summary>

![[Resources/Audio/en/Words 0851-0900.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [nephew](https://en.wiktionary.org/wiki/nephew#English) | A son of one's sibling, brother-in-law, or sister-in-law; either a son of one's brother (fraternal nephew) or a son of one's sister (sororal nephew). | /ˈnɛf.ju/ · noun |
| [relaxed](https://en.wiktionary.org/wiki/relaxed#English) | Made more lenient; less strict; lax. | /ɹɪˈlækst/ · adj |
| [salmon](https://en.wiktionary.org/wiki/salmon#English) | One of several species of fish, typically of the Salmoninae subfamily, brownish above with silvery sides and delicate pinkish-orange flesh; they ascend rivers to spawn. | /ˈsæmən/ · noun |
| [tan](https://en.wiktionary.org/wiki/tan#English) | A light, brown-like colour. | /tæn/ · noun |
| [thumb](https://en.wiktionary.org/wiki/thumb#English) | The shortest and thickest digit of the hand that for humans has the most mobility and can be made to oppose (moved to touch) all of the other fingers. | /ˈθʌm/ · noun |
| [upside](https://en.wiktionary.org/wiki/upside#English) | The highest or uppermost side or portion of something. | /ˈʌpˌsaɪd/ · noun |
| [whip](https://en.wiktionary.org/wiki/whip#English) | A lash; a pliant, flexible instrument, such as a rod (commonly of cane or rattan) or a plaited or braided rope or thong (commonly of leather) used to create a sharp "crack" sound for directing or herding animals. | /ˈwɪp/ · noun |
| [MC](https://en.wiktionary.org/wiki/MC#English) | A rapper. |  · noun |
| [banana](https://en.wiktionary.org/wiki/banana#English) | The elongated curved tropical fruit of a banana plant, which grows in bunches and has a creamy flesh and a smooth skin. | /bəˈnɑːnə/ · noun |
| [bo](https://en.wiktionary.org/wiki/bo#English) | An exclamation used to startle or frighten. | /bəʊ/ · intj |
| [chan](https://en.wiktionary.org/wiki/chan#English) | An IRC channel. | /t͡ʃæn/ · noun |
| [chin](https://en.wiktionary.org/wiki/chin#English) | The bottom of a face, (specifically) the typically jutting jawline below the mouth. | /ˈt͡ʃɪn/ · noun |
| [civic](https://en.wiktionary.org/wiki/civic#English) | Of, relating to, or belonging to a city, a citizen, or citizenship; municipal or civil. | /ˈsɪvɪk/ · adj |
| [crude](https://en.wiktionary.org/wiki/crude#English) | In a natural, untreated state. | /kɹuːd/ · adj |
| [jerk](https://en.wiktionary.org/wiki/jerk#English) | A sudden, often uncontrolled movement, especially of the human body. | /ˈd͡ʒɜːk/ · noun |
| [outlet](https://en.wiktionary.org/wiki/outlet#English) | A vent or similar passage to allow the escape of something. | /ˈaʊtlɛt/ · noun |
| [pledge](https://en.wiktionary.org/wiki/pledge#English) | To make a solemn promise (to do something). | /plɛd͡ʒ/ · verb |
| [silicon](https://en.wiktionary.org/wiki/silicon#English) | A nonmetallic element (symbol Si) with an atomic number of 14 and atomic weight of 28.0855. | /ˈsɪlɪkən/ · noun |
| [spelling](https://en.wiktionary.org/wiki/spelling#English) | The act, practice, ability, or subject of forming words with letters, or of reading the letters of words; orthography. | /ˈspɛl.ɪŋ/ · noun |
| [Brussels](https://en.wiktionary.org/wiki/Brussels#English) | A Brussels carpet. | /ˈbɹʌsəlz/ · noun |
| [Mediterranean](https://en.wiktionary.org/wiki/Mediterranean#English) | Of or pertaining to the Mediterranean Sea and its surrounding region. | /ˌmɛdɪtəˈɹeɪni.ən/ · adj |
| [accurately](https://en.wiktionary.org/wiki/accurately#English) | In an accurate manner; exactly; precisely; without error or defect. | /ˈak.jə.ɹɪt.li/ · adv |
| [asylum](https://en.wiktionary.org/wiki/asylum#English) | A place of safety or refuge. | /əˈsaɪləm/ · noun |
| [bent](https://en.wiktionary.org/wiki/bent#English) | Folded or dented out of its usual shape. | /bɛnt/ · adj |
| [clause](https://en.wiktionary.org/wiki/clause#English) | A group of words that contains a subject and a verb; it may be part of a sentence or may constitute the whole sentence, depending on the syntax in each instance. | /klɔːz/ · noun |
| [cylinder](https://en.wiktionary.org/wiki/cylinder#English) | A surface created by projecting a closed two-dimensional curve along an axis intersecting the plane of the curve. | /ˈsɪlɪndə(ɹ)/ · noun |
| [feat](https://en.wiktionary.org/wiki/feat#English) | A relatively rare or difficult accomplishment. | /fiːt/ · noun |
| [freight](https://en.wiktionary.org/wiki/freight#English) | The transportation of goods (originally by water; now also (chiefly US) by land); also, the hiring of a vehicle or vessel for such transportation. | /fɹeɪt/ · noun |
| [instrumental](https://en.wiktionary.org/wiki/instrumental#English) | Essential or central; of great importance or relevance. | /ɪnstɹəˈmɛntəl/ · adj |
| [offset](https://en.wiktionary.org/wiki/offset#English) | Anything that acts as counterbalance; a compensating equivalent. | /ˈɒf.sɛt/ · noun |
| [quarterly](https://en.wiktionary.org/wiki/quarterly#English) | Occurring once every quarter year (three months); taking place quarter-yearly. |  · adj |
| [Ottawa](https://en.wiktionary.org/wiki/Ottawa#English) | A member of the Ottawa people. | /ˈɒtəwə/ · noun |
| [absent](https://en.wiktionary.org/wiki/absent#English) | Being away from a place; withdrawn from a place; existing but not present; (sometimes) missing. | /ˈæb.sn̩t/ · adj |
| [acoustic](https://en.wiktionary.org/wiki/acoustic#English) | Used for soundproofing or modifying sound. | /əˈkuː.stɪk/ · adj |
| [doctrine](https://en.wiktionary.org/wiki/doctrine#English) | A belief or tenet, especially about philosophical or theological matters. | /ˈdɒk.tɹɪn/ · noun |
| [habitat](https://en.wiktionary.org/wiki/habitat#English) | Conditions suitable for an organism or population of organisms to live. | /ˈhæb.ɪ.tæt/ · noun |
| [hydrogen](https://en.wiktionary.org/wiki/hydrogen#English) | The lightest chemical element (symbol H), with an atomic number of 1 and atomic weight of 1.008. | /ˈhaɪdɹəd͡ʒ(ə)n/ · noun |
| [mistaken](https://en.wiktionary.org/wiki/mistaken#English) | Erroneous. | /mɪˈsteɪkn̩/ · adj |
| [pond](https://en.wiktionary.org/wiki/pond#English) | An inland body of standing water, either natural or man-made, that is smaller than a lake. | /pɒnd/ · noun |
| [ruby](https://en.wiktionary.org/wiki/ruby#English) | A clear, deep, red variety of corundum, valued as a precious stone. | /ˈɹuː.bi/ · noun |
| [Hispanic](https://en.wiktionary.org/wiki/Hispanic#English) | Of or relating to Spain. | /hɪˈspænɪk/ · adj |
| [amber](https://en.wiktionary.org/wiki/amber#English) | A yellow-orange colour. | /ˈæm.bəː/ · noun |
| [capitalism](https://en.wiktionary.org/wiki/capitalism#English) | A socio-economic system based on private ownership of resources, and capital and their exploitation for profit. | /ˈkapɪt(ə)lɪz(ə)m/ · noun |
| [handy](https://en.wiktionary.org/wiki/handy#English) | Easy to use, useful. | /ˈhæn.di/ · adj |
| [hers](https://en.wiktionary.org/wiki/hers#English) | That or those belonging to her; the possessive case of she, used without a following noun. | /ˈhɜːz/ · pron |
| [manga](https://en.wiktionary.org/wiki/manga#English) | A comic originating in Japan. | /ˈmæŋɡə/ · noun |
| [merger](https://en.wiktionary.org/wiki/merger#English) | One that merges. | /ˈmɜː.d͡ʒə/ · noun |
| [sweep](https://en.wiktionary.org/wiki/sweep#English) | To clean (a surface) by means of a stroking motion of a broom or brush. | /swiːp/ · verb |
| [tuition](https://en.wiktionary.org/wiki/tuition#English) | The training or instruction provided by a teacher or tutor. | /tjuːˈɪʃən/ · noun |
| [enforce](https://en.wiktionary.org/wiki/enforce#English) | To keep up, impose or bring into effect something, not necessarily by force. | /ɪnˈfoɹs/ · verb |

</details>

<details><summary>Words 901–950</summary>

![[Resources/Audio/en/Words 0901-0950.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [forbidden](https://en.wiktionary.org/wiki/forbidden#English) | Not allowed; specifically disallowed. | /fəˈbɪdən/ · adj |
| [melt](https://en.wiktionary.org/wiki/melt#English) | To change (or to be changed) from a solid state to a liquid state, usually by a gradual heat. | /mɛlt/ · verb |
| [skirt](https://en.wiktionary.org/wiki/skirt#English) | A separate article of clothing, usually worn by women and girls, that hangs from the waist and covers the lower torso and part of the legs. | /skɜːt/ · noun |
| [stir](https://en.wiktionary.org/wiki/stir#English) | To disturb the relative position of the particles (of a liquid or similar) by passing an object through it. | /stɜː/ · verb |
| [tendency](https://en.wiktionary.org/wiki/tendency#English) | A likelihood of behaving in a particular way or going in a particular direction; a tending toward. | /ˈtɛn.dən.si/ · noun |
| [theirs](https://en.wiktionary.org/wiki/theirs#English) | That or those belonging to them; the possessive case of they, used without a following noun. | /ðɛəz/ · pron |
| [viable](https://en.wiktionary.org/wiki/viable#English) | Able to live on its own (as for a newborn). | /ˈvaɪəbəl/ · adj |
| [AG](https://en.wiktionary.org/wiki/AG#English) | An aggressive (a butch woman, especially a Black butch woman); an aggressive girl. |  · noun |
| [Czech](https://en.wiktionary.org/wiki/Czech#English) | Of, from, or pertaining to Czechia, the Czech people, culture, or language. | /t͡ʃɛk/ · adj |
| [Norwegian](https://en.wiktionary.org/wiki/Norwegian#English) | A native or inhabitant of Norway. | /nɔːˈwiːd͡ʒn̩/ · noun |
| [absurd](https://en.wiktionary.org/wiki/absurd#English) | Contrary to reason or propriety; obviously and flatly opposed to manifest truth; inconsistent with the plain dictates of common sense; logically contradictory; nonsensical; ridiculous; silly. | /əbˈsɜːd/ · adj |
| [ag](https://en.wiktionary.org/wiki/ag#English) | Expressing annoyance, remorse, surprise, etc.: oh, ah. | /ˈax/ · intj |
| [brake](https://en.wiktionary.org/wiki/brake#English) | The act of braking, of using a brake to slow down a machine or vehicle | /bɹeɪk/ · noun |
| [businessman](https://en.wiktionary.org/wiki/businessman#English) | A man in business, one who works at a commercial institution. | /ˈbɪznəsmən/ · noun |
| [cough](https://en.wiktionary.org/wiki/cough#English) | Sometimes followed by up: to force (something) out of the lungs or throat by pushing air from the lungs through the glottis (causing a short, explosive sound), and out through the mouth. | /kɒf/ · verb |
| [drank](https://en.wiktionary.org/wiki/drank#English) | Dextromethorphan. | /dɹæŋk/ · noun |
| [pencil](https://en.wiktionary.org/wiki/pencil#English) | A writing utensil with a graphite (commonly referred to as lead) shaft, usually blended with clay, clad in wood, and sharpened to a taper. | /ˈpɛn(t)səl/ · noun |
| [plasma](https://en.wiktionary.org/wiki/plasma#English) | A state of matter consisting of partially ionized gas and electrons. | /ˈplæzmə/ · noun |
| [plea](https://en.wiktionary.org/wiki/plea#English) | An appeal, petition, urgent prayer or entreaty. | /pliː/ · noun |
| [rhetoric](https://en.wiktionary.org/wiki/rhetoric#English) | The art of using language, especially public speaking, as a means to persuade. | /ˈɹɛtəɹɪk/ · noun |
| [sixteen](https://en.wiktionary.org/wiki/sixteen#English) | The cardinal number occurring after fifteen and before seventeen, represented in Arabic numerals as 16 and in Roman numerals as XVI. | /ˈsɪks.tiːn/ · num |
| [sovereign](https://en.wiktionary.org/wiki/sovereign#English) | Exercising power of rule. | /ˈsɒv.ɹɪn/ · adj |
| [tense](https://en.wiktionary.org/wiki/tense#English) | The property of indicating the point in time at which an action or state of being occurs or exists. | /tɛns/ · noun |
| [cement](https://en.wiktionary.org/wiki/cement#English) | A powdered substance produced by firing (calcining) calcium carbonate (limestone) and clay that develops strong cohesive properties when mixed with water. The main ingredient of concrete. | /səˈmɛnt/ · noun |
| [chess](https://en.wiktionary.org/wiki/chess#English) | A board game for two players, each beginning with sixteen chess pieces moving according to fixed rules across a chessboard with the objective to checkmate the opposing king. | /t͡ʃɛs/ · noun |
| [dull](https://en.wiktionary.org/wiki/dull#English) | Lacking the ability to cut easily; not sharp. | /dʌl/ · adj |
| [float](https://en.wiktionary.org/wiki/float#English) | To be supported by a fluid of greater density (than the object). | /fləʊt/ · verb |
| [grind](https://en.wiktionary.org/wiki/grind#English) | To reduce to smaller pieces by crushing with lateral motion. | /ˈɡɹaɪnd/ · verb |
| [hobby](https://en.wiktionary.org/wiki/hobby#English) | An activity that one enjoys doing in one's spare time. | /ˈhɒ.bi/ · noun |
| [leap](https://en.wiktionary.org/wiki/leap#English) | To jump. | /ˈliːp/ · verb |
| [locate](https://en.wiktionary.org/wiki/locate#English) | To place; to set in a particular spot or position. | /lə(ʊ)ˈkeɪt/ · verb |
| [swap](https://en.wiktionary.org/wiki/swap#English) | To exchange or give (something) in an non-normal exchange (for something else). | /ˈswɒp/ · verb |
| [swept](https://en.wiktionary.org/wiki/swept#English) | Cleared of mines (explosive devices). | /swɛpt/ · adj |
| [threaten](https://en.wiktionary.org/wiki/threaten#English) | To make a threat against someone; to use threats. | /ˈθɹɛt.n̩/ · verb |
| [vegetable](https://en.wiktionary.org/wiki/vegetable#English) | The edible part of such a plant. | /ˈvɛd͡ʒ.tə.bəl/ · noun |
| [virtue](https://en.wiktionary.org/wiki/virtue#English) | Accordance with moral principles; conformity of behaviour or thought with the strictures of morality; good moral conduct. | /ˈvɜːt͡ʃuː/ · noun |
| [Chad](https://en.wiktionary.org/wiki/Chad#English) | A very handsome, genetically gifted and sexually active man whom women find sexually attractive; at times seen as an alpha male of a group. | /t͡ʃæd/ · noun |
| [acre](https://en.wiktionary.org/wiki/acre#English) | An English unit of land area (symbol: a. or ac.) originally denoting a day's ploughing for a yoke of oxen, now standardized as 4,840 square yards or 4,046.86 square metres. | /ˈeɪ.kə/ · noun |
| [arise](https://en.wiktionary.org/wiki/arise#English) | To come up from a lower to a higher position. | /əˈɹaɪz/ · verb |
| [bore](https://en.wiktionary.org/wiki/bore#English) | To inspire boredom in somebody. | /bɔː/ · verb |
| [butterfly](https://en.wiktionary.org/wiki/butterfly#English) | A flying insect of the order Lepidoptera, distinguished from moths by their diurnal activity and generally brighter colouring. | /ˈbʌ.tə(ɹ).flaɪ/ · noun |
| [conjunction](https://en.wiktionary.org/wiki/conjunction#English) | The act of joining, or condition of being joined. | /kənˈd͡ʒʌŋk.ʃn̩/ · noun |
| [directory](https://en.wiktionary.org/wiki/directory#English) | A list of names, addresses etc, of specific classes of people or organizations, often in alphabetical order or in some classification. | /dɪˈɹɛktəɹi/ · noun |
| [han](https://en.wiktionary.org/wiki/han#English) | Sorrowful resentment, as a part of the Korean cultural identity. |  · noun |
| [implied](https://en.wiktionary.org/wiki/implied#English) | Suggested without being stated directly; implicated or hinted at. | /ɪmˈplaɪd/ · adj |
| [merchandise](https://en.wiktionary.org/wiki/merchandise#English) | Goods which are or were offered or intended for sale. | /ˈmɜː.t͡ʃənˌdaɪs/ · noun |
| [sixty](https://en.wiktionary.org/wiki/sixty#English) | The cardinal number occurring after fifty-nine and before sixty-one, represented in Roman numerals as LX and in Arabic numerals as 60. | /ˈsɪksti/ · num |
| [translate](https://en.wiktionary.org/wiki/translate#English) | To change spoken words or written text (of a book, document, movie, etc.) from one language to another. | /tɹɑːnzˈleɪt/ · verb |
| [triangle](https://en.wiktionary.org/wiki/triangle#English) | A polygon with three sides and three angles. | /ˈtɹaɪəŋɡəl/ · noun |
| [airplane](https://en.wiktionary.org/wiki/airplane#English) | A powered heavier-than-air aircraft with fixed wings: a fixed-wing aircraft with at least one engine or electric motor. | /ˈɛəˌpleɪ̯n/ · noun |

</details>

<details><summary>Words 951–1000</summary>

![[Resources/Audio/en/Words 0951-1000.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [altitude](https://en.wiktionary.org/wiki/altitude#English) | The absolute height of a location, usually measured from sea level. | /ˈælt.ɪˌtjuːd/ · noun |
| [biblical](https://en.wiktionary.org/wiki/biblical#English) | Of or relating to the Bible. | /ˈbɪblɪkəl/ · adj |
| [impose](https://en.wiktionary.org/wiki/impose#English) | To apply, enforce, or establish (something, often regarded as burdensome as a restriction or tax: see verb sense 1.2.2) with authority. | /ɪmˈpəʊz/ · verb |
| [lend](https://en.wiktionary.org/wiki/lend#English) | To allow to be used by someone temporarily, on condition that it or its equivalent will be returned. | /ˈlɛnd/ · verb |
| [pi](https://en.wiktionary.org/wiki/pi#English) | The sixteenth letter of the Classical and Modern Greek alphabets and the seventeenth in Old Greek. | /paɪ/ · noun |
| [tenth](https://en.wiktionary.org/wiki/tenth#English) | The ordinal numeral form of ten; next in order after that which is ninth. | /tɛnθ/ · adj |
| [velocity](https://en.wiktionary.org/wiki/velocity#English) | A vector quantity that denotes the rate of change of position with respect to time, combining speed with a directional component. | /vəˈlɒsəti/ · noun |
| [wax](https://en.wiktionary.org/wiki/wax#English) | Any oily, water-resistant, solid or semisolid substance; normally long-chain hydrocarbons, alcohols or esters. | /waks/ · noun |
| [Danish](https://en.wiktionary.org/wiki/Danish#English) | Of or pertaining to Denmark. | /ˈdeɪ.nɪʃ/ · adj |
| [Hebrew](https://en.wiktionary.org/wiki/Hebrew#English) | Of or pertaining to the Hebrew people or language. | /ˈhiːbɹuː/ · adj |
| [accountability](https://en.wiktionary.org/wiki/accountability#English) | The state of being accountable; liability to be called on to render an account or give an explanation; liability to be held responsible or answerable for something. | /əˌkaʊn.təˈbɪl.ə.ti/ · noun |
| [batch](https://en.wiktionary.org/wiki/batch#English) | The quantity of bread or other baked goods baked at one time. | /bæt͡ʃ/ · noun |
| [exterior](https://en.wiktionary.org/wiki/exterior#English) | Relating to the outside parts or surface of something. | /ɪkˈstɪəɹɪə/ · adj |
| [feminine](https://en.wiktionary.org/wiki/feminine#English) | Of or pertaining to the female gender. | /ˈfɛmɪnɪn/ · adj |
| [hay](https://en.wiktionary.org/wiki/hay#English) | Grass cut and dried for use as animal fodder. | /heɪ/ · noun |
| [massacre](https://en.wiktionary.org/wiki/massacre#English) | The killing of a considerable number (usually limited to people) where little or no resistance can be made, with indiscriminate violence, without necessity, and/or contrary to civilized norms. | /ˈmæs.ə.kə(ɹ)/ · noun |
| [plaza](https://en.wiktionary.org/wiki/plaza#English) | A town's public square. | /ˈplɑːzə/ · noun |
| [rode](https://en.wiktionary.org/wiki/rode#English) | Of a male woodcock, to fly back and forth over the edge of a woodland while calling; to perform its, typically crepuscular, mating flight. | /ɹəʊd/ · verb |
| [transgender](https://en.wiktionary.org/wiki/transgender#English) | Of a person: having a gender (identity) which is different from one's assigned sex; that is, the identity of a trans man, trans woman, or someone non-binary, for example, agender, bigender, or third-gender. | /tɹænzˈd͡ʒɛndə/ · adj |
| [turtle](https://en.wiktionary.org/wiki/turtle#English) | Any land, aquatic, or semi-aquatic reptile of the order Testudines, characterised by a protective shell enclosing its body. See also tortoise. | /ˈtɜːtl̩/ · noun |
| [verbal](https://en.wiktionary.org/wiki/verbal#English) | Of or relating to words. | /ˈvɜː.bəl/ · adj |
| [wool](https://en.wiktionary.org/wiki/wool#English) | The hair of the sheep, llama and some other ruminants. | /wʊl/ · noun |
| [accountable](https://en.wiktionary.org/wiki/accountable#English) | Obliged, when called upon, to answer (for one’s deeds); answerable. | /əˈkaʊntəbl̩/ · adj |
| [aggression](https://en.wiktionary.org/wiki/aggression#English) | The act of initiating hostilities or invasion. | /əˈɡɹɛʃən/ · noun |
| [cardinal](https://en.wiktionary.org/wiki/cardinal#English) | Of fundamental importance; crucial, pivotal. | /ˈkɑːd(ɪ)nəl/ · adj |
| [fog](https://en.wiktionary.org/wiki/fog#English) | A thick cloud that forms near the ground; the obscurity of such a cloud. | /fɒɡ/ · noun |
| [horizontal](https://en.wiktionary.org/wiki/horizontal#English) | Perpendicular to the vertical; parallel to the plane of the horizon; level, flat. | /ˌhɒɹɪˈzɒn.təl/ · adj |
| [moisture](https://en.wiktionary.org/wiki/moisture#English) | That which moistens or makes damp or wet; exuding fluid; liquid in small quantity. | /ˈmɔɪs.t͡ʃə/ · noun |
| [particle](https://en.wiktionary.org/wiki/particle#English) | A very small piece of matter, a fragment; especially, the smallest possible part of something. | /ˈpɑːtɪkl̩/ · noun |
| [rebuild](https://en.wiktionary.org/wiki/rebuild#English) | To build again or anew. | /ɹiːˈbɪld/ · verb |
| [shuttle](https://en.wiktionary.org/wiki/shuttle#English) | A tool used to carry the woof back and forth between the warp threads on a loom. | /ˈʃʌtəl/ · noun |
| [stiff](https://en.wiktionary.org/wiki/stiff#English) | Rigid; hard to bend; inflexible. | /stɪf/ · adj |
| [sworn](https://en.wiktionary.org/wiki/sworn#English) | Given or declared under oath. | /swɔːn/ · adj |
| [withdrawn](https://en.wiktionary.org/wiki/withdrawn#English) | Removed from circulation. | /wɪðˈdɹɔːn/ · adj |
| [Indonesian](https://en.wiktionary.org/wiki/Indonesian#English) | Of or relating to Indonesia or its people or language. | /ˌɪndəˈniːʒən/ · adj |
| [cod](https://en.wiktionary.org/wiki/cod#English) | A sea fish of the family Gadidae which are sold as "cod", as haddock (Melanogrammus aeglefinus), and whiting (usually Merlangius merlangus). | /kɒd/ · noun |
| [mosque](https://en.wiktionary.org/wiki/mosque#English) | A place of worship for Muslims, often having at least one minaret; a masjid. | /mɑsk/ · noun |
| [solidarity](https://en.wiktionary.org/wiki/solidarity#English) | A bond of unity or agreement between individuals, united around a common goal or against a common enemy, such as the unifying principle that defines the labor movement; mutual support within a group. | /ˌsɒl.ɪˈdæɹ.ə.ti/ · noun |
| [thirteen](https://en.wiktionary.org/wiki/thirteen#English) | The cardinal number occurring after twelve and before fourteen: ten and three. | /ˌθɜːˈtiːn/ · num |
| [touring](https://en.wiktionary.org/wiki/touring#English) | Working for a short time in different places. | /ˈtʊəɹɪŋ/ · adj |
| [umbrella](https://en.wiktionary.org/wiki/umbrella#English) | A cloth-covered frame used for protection against rain or sun. | /ʌmˈbɹɛl.ə/ · noun |
| [abbey](https://en.wiktionary.org/wiki/abbey#English) | The office or dominion of an abbot or abbess. | /ˈæbi/ · noun |
| [adjustment](https://en.wiktionary.org/wiki/adjustment#English) | The action of adjusting something. | /əˈd͡ʒʌst.mənt/ · noun |
| [attachment](https://en.wiktionary.org/wiki/attachment#English) | The act or process of (physically or figuratively) attaching. | /əˈtæt͡ʃmənt/ · noun |
| [baron](https://en.wiktionary.org/wiki/baron#English) | The male ruler of a barony. | /ˈbæɹən/ · noun |
| [choir](https://en.wiktionary.org/wiki/choir#English) | A group of people who sing together; a company of people who are trained to sing together. | /kwaɪə(ɹ)/ · noun |
| [clutch](https://en.wiktionary.org/wiki/clutch#English) | To seize, as though with claws. | /ˈklʌt͡ʃ/ · verb |
| [fourteen](https://en.wiktionary.org/wiki/fourteen#English) | The cardinal number occurring after thirteen and before fifteen. | /ˈfɔː.tiːn/ · num |
| [gossip](https://en.wiktionary.org/wiki/gossip#English) | Someone who likes to talk about other people's private or personal business. | /ˈɡɒsɪp/ · noun |
| [metric](https://en.wiktionary.org/wiki/metric#English) | Of or relating to the metric system of measurement. | /ˈmɛt.ɹɪk/ · adj |

</details>

## Question bank

Try before opening the answers. Different tasks use the same sentence to practise complementary skills. Open translation and explanation tasks can have valid alternatives.

### Articles, countability and reference · 182 questions

**en-Q0001 · Fill the gap**

This is ____ opposite of what I expected.

मुझे जो अपेक्षा थी उसके यह विपरीत है।

[[English#^en-Q0001-answer|Compare the answer]]
^en-Q0001

**en-Q0002 · Choose the form**

This is ____ opposite of what I expected.

मुझे जो अपेक्षा थी उसके यह विपरीत है।

Choices: an / the / a / some

[[English#^en-Q0002-answer|Compare the answer]]
^en-Q0002

**en-Q0003 · Edit the changed sentence**

My grandfather was murdered during 【a】 Second World War.

दूसरे विश्वयुद्ध के दौरान मेरे दादा का खून हुआ था।

[[English#^en-Q0003-answer|Compare the answer]]
^en-Q0003

**en-Q0004 · Build the sentence**

Arrange: during / the / My / World / Second / was / War. / murdered / grandfather

दूसरे विश्वयुद्ध के दौरान मेरे दादा का खून हुआ था।

[[English#^en-Q0004-answer|Compare the answer]]
^en-Q0004

**en-Q0005 · Write a translation**

Write this in English: वह उस दरवाज़े से धीरे से कमरे में घुसा।

[[English#^en-Q0005-answer|Compare the answer]]
^en-Q0005

**en-Q0006 · Explain the grammar**

He entered 【the】 room slowly by that door.

वह उस दरवाज़े से धीरे से कमरे में घुसा।

[[English#^en-Q0006-answer|Compare the answer]]
^en-Q0006

**en-Q0007 · Fill the gap**

Men whose mothers had breast cancer run ____ higher risk of developing prostate cancer.

जिन मर्दों की माताओं को छाती का कैंसर था उनको प्रोस्ट्रेट कैंसर होने का अधिक खदशा रहता है |

[[English#^en-Q0007-answer|Compare the answer]]
^en-Q0007

**en-Q0008 · Choose the form**

Men whose mothers had breast cancer run ____ higher risk of developing prostate cancer.

जिन मर्दों की माताओं को छाती का कैंसर था उनको प्रोस्ट्रेट कैंसर होने का अधिक खदशा रहता है |

Choices: some / a / the / an

[[English#^en-Q0008-answer|Compare the answer]]
^en-Q0008

**en-Q0009 · Edit the changed sentence**

Terrorists attacked 【a】 World Trade Center in New York City in 2001.

२००१ में न्यूयॉर्क शहर में आतंकवादियों वर्ल्ड ट्रेड सेंटर पर हमला किया।

[[English#^en-Q0009-answer|Compare the answer]]
^en-Q0009

**en-Q0010 · Build the sentence**

Arrange: 2001. / attacked / Trade / Terrorists / in / World / New / City / in / the / Center / York

२००१ में न्यूयॉर्क शहर में आतंकवादियों वर्ल्ड ट्रेड सेंटर पर हमला किया।

[[English#^en-Q0010-answer|Compare the answer]]
^en-Q0010

**en-Q0011 · Write a translation**

Write this in English: बगुले को हर दिन भोजन के लिए शिकार करना पड़ता था।

[[English#^en-Q0011-answer|Compare the answer]]
^en-Q0011

**en-Q0012 · Explain the grammar**

【The】 heron had to hunt for food every day.

बगुले को हर दिन भोजन के लिए शिकार करना पड़ता था।

[[English#^en-Q0012-answer|Compare the answer]]
^en-Q0012

**en-Q0013 · Fill the gap**

Opening ____ door, I found a stranger standing there.

मैंने जब दरवाज़ा खोला, मुझे एक अजनबी वहाँ खड़ा मिला।

[[English#^en-Q0013-answer|Compare the answer]]
^en-Q0013

**en-Q0014 · Choose the form**

Opening ____ door, I found a stranger standing there.

मैंने जब दरवाज़ा खोला, मुझे एक अजनबी वहाँ खड़ा मिला।

Choices: some / an / a / the

[[English#^en-Q0014-answer|Compare the answer]]
^en-Q0014

**en-Q0015 · Edit the changed sentence**

Do you keep your money in 【an】 bank?

क्या आप अपने पैसे बैंक में रखते हैं?

[[English#^en-Q0015-answer|Compare the answer]]
^en-Q0015

**en-Q0016 · Build the sentence**

Arrange: bank? / keep / you / money / Do / in / your / a

क्या आप अपने पैसे बैंक में रखते हैं?

[[English#^en-Q0016-answer|Compare the answer]]
^en-Q0016

**en-Q0017 · Write a translation**

Write this in English: वह दो सालों में डॉक्टर बन जाएगी।

[[English#^en-Q0017-answer|Compare the answer]]
^en-Q0017

**en-Q0018 · Explain the grammar**

She will become 【a】 doctor in two years.

वह दो सालों में डॉक्टर बन जाएगी।

[[English#^en-Q0018-answer|Compare the answer]]
^en-Q0018

**en-Q0019 · Fill the gap**

Who were you waiting for at ____ station?

तुम स्टेशन पर किसका इंतज़ार कर रहे थे?

[[English#^en-Q0019-answer|Compare the answer]]
^en-Q0019

**en-Q0020 · Choose the form**

Who were you waiting for at ____ station?

तुम स्टेशन पर किसका इंतज़ार कर रहे थे?

Choices: the / a / an / some

[[English#^en-Q0020-answer|Compare the answer]]
^en-Q0020

**en-Q0021 · Edit the changed sentence**

I haven't had 【an】 chance to see the movie yet.

मुझे अभी तक उस फ़िल्म को देखने का मौका नहीं मिला है।

[[English#^en-Q0021-answer|Compare the answer]]
^en-Q0021

**en-Q0022 · Build the sentence**

Arrange: I / yet. / movie / had / chance / the / haven't / a / to / see

मुझे अभी तक उस फ़िल्म को देखने का मौका नहीं मिला है।

[[English#^en-Q0022-answer|Compare the answer]]
^en-Q0022

**en-Q0023 · Write a translation**

Write this in English: तुम उसके बारे में ऐसे बात क्यों करते हो जैसे कि वह बूढ़ा आदमी हो?

[[English#^en-Q0023-answer|Compare the answer]]
^en-Q0023

**en-Q0024 · Explain the grammar**

Why do you talk about him as if he were 【an】 old man?

तुम उसके बारे में ऐसे बात क्यों करते हो जैसे कि वह बूढ़ा आदमी हो?

[[English#^en-Q0024-answer|Compare the answer]]
^en-Q0024

**en-Q0025 · Fill the gap**

She reproached me for not answering ____ letter.

उसने मुझे चिट्ठी का जवाब न देने के लिए डाँटा।

[[English#^en-Q0025-answer|Compare the answer]]
^en-Q0025

**en-Q0026 · Choose the form**

She reproached me for not answering ____ letter.

उसने मुझे चिट्ठी का जवाब न देने के लिए डाँटा।

Choices: the / an / a / some

[[English#^en-Q0026-answer|Compare the answer]]
^en-Q0026

**en-Q0027 · Edit the changed sentence**

【a】 people of Boston hated the British soldiers.

बॉस्टन के लोग ब्रिटिश सैनिकों से नफ़रत करते थें।

[[English#^en-Q0027-answer|Compare the answer]]
^en-Q0027

**en-Q0028 · Build the sentence**

Arrange: of / the / Boston / people / The / soldiers. / hated / British

बॉस्टन के लोग ब्रिटिश सैनिकों से नफ़रत करते थें।

[[English#^en-Q0028-answer|Compare the answer]]
^en-Q0028

**en-Q0029 · Write a translation**

Write this in English: अगर तुम्हे परीक्षा पास करनी है तो मन लगाकर काम करना होगा।

[[English#^en-Q0029-answer|Compare the answer]]
^en-Q0029

**en-Q0030 · Explain the grammar**

You'll have to work hard if you want to pass 【the】 exam.

अगर तुम्हे परीक्षा पास करनी है तो मन लगाकर काम करना होगा।

[[English#^en-Q0030-answer|Compare the answer]]
^en-Q0030

**en-Q0031 · Fill the gap**

For once in my life I'm doing ____ good deed... And it is useless.

मैंने ज़िन्दगी में पहली बार कोई अच्छा काम किया पर वह भी बेकार निकला।

[[English#^en-Q0031-answer|Compare the answer]]
^en-Q0031

**en-Q0032 · Choose the form**

For once in my life I'm doing ____ good deed... And it is useless.

मैंने ज़िन्दगी में पहली बार कोई अच्छा काम किया पर वह भी बेकार निकला।

Choices: some / the / a / an

[[English#^en-Q0032-answer|Compare the answer]]
^en-Q0032

**en-Q0033 · Edit the changed sentence**

He ran away in 【a】 direction of the wood.

वह जंगल की दिशा में भाग गया।

[[English#^en-Q0033-answer|Compare the answer]]
^en-Q0033

**en-Q0034 · Build the sentence**

Arrange: He / wood. / the / away / of / the / in / ran / direction

वह जंगल की दिशा में भाग गया।

[[English#^en-Q0034-answer|Compare the answer]]
^en-Q0034

**en-Q0035 · Write a translation**

Write this in English: मन जो स्नेह संजो सकता है उन में से सबसे पवित्र है किसी नौ वर्षीय का निश्छल प्रेम।

[[English#^en-Q0035-answer|Compare the answer]]
^en-Q0035

**en-Q0036 · Explain the grammar**

【The】 purest affection the heart can hold is the honest love of a nine-year-old.

मन जो स्नेह संजो सकता है उन में से सबसे पवित्र है किसी नौ वर्षीय का निश्छल प्रेम।

[[English#^en-Q0036-answer|Compare the answer]]
^en-Q0036

**en-Q0037 · Fill the gap**

What's ____ height of the Empire State Building?

एम्पायर स्टेट बिल्डिंग की ऊँचाई कितनी है?

[[English#^en-Q0037-answer|Compare the answer]]
^en-Q0037

**en-Q0038 · Choose the form**

What's ____ height of the Empire State Building?

एम्पायर स्टेट बिल्डिंग की ऊँचाई कितनी है?

Choices: an / some / the / a

[[English#^en-Q0038-answer|Compare the answer]]
^en-Q0038

**en-Q0039 · Edit the changed sentence**

I have lots of work to clear up by 【a】 weekend.

मुझे इस हफ़्ते बहुत सारा काम कर के खतम करना है।

[[English#^en-Q0039-answer|Compare the answer]]
^en-Q0039

**en-Q0040 · Build the sentence**

Arrange: clear / have / the / I / lots / weekend. / by / of / to / work / up

मुझे इस हफ़्ते बहुत सारा काम कर के खतम करना है।

[[English#^en-Q0040-answer|Compare the answer]]
^en-Q0040

**en-Q0041 · Write a translation**

Write this in English: तुम्हें कुत्ते को बांध देना चाहिए जिससे कि वह किसी को काट न ले।

[[English#^en-Q0041-answer|Compare the answer]]
^en-Q0041

**en-Q0042 · Explain the grammar**

You had better chain up 【the】 dog so that he won't bite.

तुम्हें कुत्ते को बांध देना चाहिए जिससे कि वह किसी को काट न ले।

[[English#^en-Q0042-answer|Compare the answer]]
^en-Q0042

**en-Q0043 · Fill the gap**

____ bat was stolen yesterday, along with the balls.

बैट और बॉल दोनो कल एकसाथ चोरी हो गए।

[[English#^en-Q0043-answer|Compare the answer]]
^en-Q0043

**en-Q0044 · Choose the form**

____ bat was stolen yesterday, along with the balls.

बैट और बॉल दोनो कल एकसाथ चोरी हो गए।

Choices: The / an / some / a

[[English#^en-Q0044-answer|Compare the answer]]
^en-Q0044

**en-Q0045 · Edit the changed sentence**

Even Japanese people make mistakes using 【a】 prefixes 'o' and 'go'.

"ओ" और "गो" इन उपसर्गों के उपयोग में जापानी लोग भी गलतीयाँ करते हैं।

[[English#^en-Q0045-answer|Compare the answer]]
^en-Q0045

**en-Q0046 · Build the sentence**

Arrange: Japanese / Even / the / 'go'. / people / mistakes / using / 'o' / prefixes / make / and

"ओ" और "गो" इन उपसर्गों के उपयोग में जापानी लोग भी गलतीयाँ करते हैं।

[[English#^en-Q0046-answer|Compare the answer]]
^en-Q0046

**en-Q0047 · Write a translation**

Write this in English: मेरे पास तुम्हारी काम में मदद करने के लिए समय नहीं है।

[[English#^en-Q0047-answer|Compare the answer]]
^en-Q0047

**en-Q0048 · Explain the grammar**

I have no time to help you with 【the】 work.

मेरे पास तुम्हारी काम में मदद करने के लिए समय नहीं है।

[[English#^en-Q0048-answer|Compare the answer]]
^en-Q0048

**en-Q0049 · Fill the gap**

____ novel is centered on the Civil War.

यह उपन्यास सिविल वॉर के बारे में है।

[[English#^en-Q0049-answer|Compare the answer]]
^en-Q0049

**en-Q0050 · Choose the form**

____ novel is centered on the Civil War.

यह उपन्यास सिविल वॉर के बारे में है।

Choices: a / The / an / some

[[English#^en-Q0050-answer|Compare the answer]]
^en-Q0050

**en-Q0869 · Write a translation**

Write this in English: हिमाचल प्रदेश की राजधानी, शिमला, चण्डीगढ़ से केवल ११५ किलोमीटर की दूरी पर है।

[[English#^en-Q0869-answer|Compare the answer]]
^en-Q0869

**en-Q0870 · Explain the grammar**

【The】 capital of Himachal Pradesh, Shimla, is only 115 kilometres away from Chandigarh.

हिमाचल प्रदेश की राजधानी, शिमला, चण्डीगढ़ से केवल ११५ किलोमीटर की दूरी पर है।

[[English#^en-Q0870-answer|Compare the answer]]
^en-Q0870

**en-Q0871 · Fill the gap**

Come on! I will show you ____ taste of defeat.

आओ! मैं तुम्हें हार का स्वाद चखाऊँगा।

[[English#^en-Q0871-answer|Compare the answer]]
^en-Q0871

**en-Q0872 · Choose the form**

Come on! I will show you ____ taste of defeat.

आओ! मैं तुम्हें हार का स्वाद चखाऊँगा।

Choices: the / some / an / a

[[English#^en-Q0872-answer|Compare the answer]]
^en-Q0872

**en-Q0873 · Edit the changed sentence**

【a】 children built a sand castle on the beach.

बच्चों ने बीच पर रेत का किला बनाया।

[[English#^en-Q0873-answer|Compare the answer]]
^en-Q0873

**en-Q0874 · Build the sentence**

Arrange: built / children / beach. / on / castle / The / a / the / sand

बच्चों ने बीच पर रेत का किला बनाया।

[[English#^en-Q0874-answer|Compare the answer]]
^en-Q0874

**en-Q0875 · Write a translation**

Write this in English: वह वह खिड़की है जिसको टॉम ने कल थोड़ा था।

[[English#^en-Q0875-answer|Compare the answer]]
^en-Q0875

**en-Q0876 · Explain the grammar**

It was 【the】 window that Tom broke yesterday.

वह वह खिड़की है जिसको टॉम ने कल थोड़ा था।

[[English#^en-Q0876-answer|Compare the answer]]
^en-Q0876

**en-Q0877 · Fill the gap**

How many strokes does ____ kanji for "michi" have?

"मिचि" के कान्जी में किती रेखाएं होती हैं?

[[English#^en-Q0877-answer|Compare the answer]]
^en-Q0877

**en-Q0878 · Choose the form**

How many strokes does ____ kanji for "michi" have?

"मिचि" के कान्जी में किती रेखाएं होती हैं?

Choices: some / the / an / a

[[English#^en-Q0878-answer|Compare the answer]]
^en-Q0878

**en-Q0879 · Edit the changed sentence**

She burst into tears when she heard 【a】 news.

वह खबर सुनते ही रो पड़ी।

[[English#^en-Q0879-answer|Compare the answer]]
^en-Q0879

**en-Q0880 · Build the sentence**

Arrange: the / news. / into / tears / when / heard / burst / she / She

वह खबर सुनते ही रो पड़ी।

[[English#^en-Q0880-answer|Compare the answer]]
^en-Q0880

**en-Q0881 · Write a translation**

Write this in English: वोह एक वैज्ञानिक न ही है, पर हमारा दोस्त जरूर है |

[[English#^en-Q0881-answer|Compare the answer]]
^en-Q0881

**en-Q0882 · Explain the grammar**

He's not 【a】 scientist, but he is our friend.

वोह एक वैज्ञानिक न ही है, पर हमारा दोस्त जरूर है |

[[English#^en-Q0882-answer|Compare the answer]]
^en-Q0882

**en-Q0883 · Fill the gap**

It's all ____ same to me whether you go or stay.

तुम जाओ या रहो, मुझे कोई फ़र्क नहीं पड़ता।

[[English#^en-Q0883-answer|Compare the answer]]
^en-Q0883

**en-Q0884 · Choose the form**

It's all ____ same to me whether you go or stay.

तुम जाओ या रहो, मुझे कोई फ़र्क नहीं पड़ता।

Choices: an / the / some / a

[[English#^en-Q0884-answer|Compare the answer]]
^en-Q0884

**en-Q0885 · Edit the changed sentence**

Which is 【a】 best hotel in the town?

शहर में सबसे अच्छा होटल कौन सा है?

[[English#^en-Q0885-answer|Compare the answer]]
^en-Q0885

**en-Q0886 · Build the sentence**

Arrange: is / hotel / best / the / town? / Which / the / in

शहर में सबसे अच्छा होटल कौन सा है?

[[English#^en-Q0886-answer|Compare the answer]]
^en-Q0886

**en-Q0887 · Write a translation**

Write this in English: जोखिम उठाइये! पूरी जिंदगी एक जोखिम है।

[[English#^en-Q0887-answer|Compare the answer]]
^en-Q0887

**en-Q0888 · Explain the grammar**

Take 【a】 chance! All life is a chance.

जोखिम उठाइये! पूरी जिंदगी एक जोखिम है।

[[English#^en-Q0888-answer|Compare the answer]]
^en-Q0888

**en-Q0889 · Fill the gap**

She cried out ____ moment she saw her mother.

उसने जैसे ही अपनी मम्मी को देखा, वह चिल्ला उठी।

[[English#^en-Q0889-answer|Compare the answer]]
^en-Q0889

**en-Q0890 · Choose the form**

She cried out ____ moment she saw her mother.

उसने जैसे ही अपनी मम्मी को देखा, वह चिल्ला उठी।

Choices: some / the / a / an

[[English#^en-Q0890-answer|Compare the answer]]
^en-Q0890

**en-Q0891 · Edit the changed sentence**

【an】 man like that gets on my nerves.

उस तरह का आदमी मुझसे झिलता नहीं है।

[[English#^en-Q0891-answer|Compare the answer]]
^en-Q0891

**en-Q0892 · Build the sentence**

Arrange: A / man / that / my / like / gets / on / nerves.

उस तरह का आदमी मुझसे झिलता नहीं है।

[[English#^en-Q0892-answer|Compare the answer]]
^en-Q0892

**en-Q0893 · Write a translation**

Write this in English: धीर्ग आयु का राज़ अपने माता पिता का सतर्क चुनाव में है |

[[English#^en-Q0893-answer|Compare the answer]]
^en-Q0893

**en-Q0894 · Explain the grammar**

【The】 secret of longevity is to choose your parents carefully.

धीर्ग आयु का राज़ अपने माता पिता का सतर्क चुनाव में है |

[[English#^en-Q0894-answer|Compare the answer]]
^en-Q0894

**en-Q0895 · Fill the gap**

As ____ matter of fact, I dislike him.

दरअसल मुझे वह पसंद नहीं है।

[[English#^en-Q0895-answer|Compare the answer]]
^en-Q0895

**en-Q0896 · Choose the form**

As ____ matter of fact, I dislike him.

दरअसल मुझे वह पसंद नहीं है।

Choices: an / a / the / some

[[English#^en-Q0896-answer|Compare the answer]]
^en-Q0896

**en-Q0897 · Edit the changed sentence**

We simply didn't expect to see such filth on 【a】 family shopping site.

हमने पारिवारिक शापिंग साइट पर इस प्रकार की अश्लीलता देखने की कभी कल्पना नहीं की थी।

[[English#^en-Q0897-answer|Compare the answer]]
^en-Q0897

**en-Q0898 · Build the sentence**

Arrange: expect / filth / We / see / simply / to / shopping / didn't / the / family / on / such / site.

हमने पारिवारिक शापिंग साइट पर इस प्रकार की अश्लीलता देखने की कभी कल्पना नहीं की थी।

[[English#^en-Q0898-answer|Compare the answer]]
^en-Q0898

**en-Q0899 · Write a translation**

Write this in English: मुझे बच्चे को सुलाना है।

[[English#^en-Q0899-answer|Compare the answer]]
^en-Q0899

**en-Q0900 · Explain the grammar**

I have to put 【the】 baby to bed.

मुझे बच्चे को सुलाना है।

[[English#^en-Q0900-answer|Compare the answer]]
^en-Q0900

**en-Q0901 · Fill the gap**

I am connecting this computer to ____ Internet.

मैं इस कम्प्यूटर को इंटरनेट से जोड़ रहा हूं।

[[English#^en-Q0901-answer|Compare the answer]]
^en-Q0901

**en-Q0902 · Choose the form**

I am connecting this computer to ____ Internet.

मैं इस कम्प्यूटर को इंटरनेट से जोड़ रहा हूं।

Choices: an / some / a / the

[[English#^en-Q0902-answer|Compare the answer]]
^en-Q0902

**en-Q0903 · Edit the changed sentence**

【a】 passengers who were injured in the accident were taken to the nearest hospital.

जिन यात्रियों को दुर्घटना मे चोट आई थी उन्हे अस्पताल ले जाया गया।

[[English#^en-Q0903-answer|Compare the answer]]
^en-Q0903

**en-Q0904 · Build the sentence**

Arrange: accident / were / The / who / the / to / in / passengers / hospital. / nearest / the / injured / taken / were

जिन यात्रियों को दुर्घटना मे चोट आई थी उन्हे अस्पताल ले जाया गया।

[[English#^en-Q0904-answer|Compare the answer]]
^en-Q0904

**en-Q0905 · Write a translation**

Write this in English: एक बत्ती नहीं जल रही है। तुम ज़रा आकर देख सकते हो क्या?

[[English#^en-Q0905-answer|Compare the answer]]
^en-Q0905

**en-Q0906 · Explain the grammar**

One of 【the】 lights is not working. Do you think you could come take a look?

एक बत्ती नहीं जल रही है। तुम ज़रा आकर देख सकते हो क्या?

[[English#^en-Q0906-answer|Compare the answer]]
^en-Q0906

**en-Q0907 · Fill the gap**

____ madman is not accountable for his actions.

एक पागल इनसान को अपने किये-धरे के लिए ज़िम्मेदार नहीं ठहराया जा सकता।

[[English#^en-Q0907-answer|Compare the answer]]
^en-Q0907

**en-Q0908 · Choose the form**

____ madman is not accountable for his actions.

एक पागल इनसान को अपने किये-धरे के लिए ज़िम्मेदार नहीं ठहराया जा सकता।

Choices: A / the / some / an

[[English#^en-Q0908-answer|Compare the answer]]
^en-Q0908

**en-Q0909 · Edit the changed sentence**

【a】 population of Sweden is on the increase.

स्वीडन की जनसंख्या बढ़ रही है।

[[English#^en-Q0909-answer|Compare the answer]]
^en-Q0909

**en-Q0910 · Build the sentence**

Arrange: The / is / on / increase. / Sweden / the / population / of

स्वीडन की जनसंख्या बढ़ रही है।

[[English#^en-Q0910-answer|Compare the answer]]
^en-Q0910

**en-Q0911 · Write a translation**

Write this in English: जब आपने अखबार पढ़ लिया हो तो मुझे दे दीजिएगा।

[[English#^en-Q0911-answer|Compare the answer]]
^en-Q0911

**en-Q0912 · Explain the grammar**

Please give me 【the】 paper when you have done with it.

जब आपने अखबार पढ़ लिया हो तो मुझे दे दीजिएगा।

[[English#^en-Q0912-answer|Compare the answer]]
^en-Q0912

**en-Q0913 · Fill the gap**

____ rich are not always happier than the poor.

अमीर हमेशा गरीबों से ज़्यादा ख़ुश नहीं होते।

[[English#^en-Q0913-answer|Compare the answer]]
^en-Q0913

**en-Q0914 · Choose the form**

____ rich are not always happier than the poor.

अमीर हमेशा गरीबों से ज़्यादा ख़ुश नहीं होते।

Choices: The / an / a / some

[[English#^en-Q0914-answer|Compare the answer]]
^en-Q0914

**en-Q0915 · Edit the changed sentence**

Tatoeba is currently unavailable. We are sorry for 【a】 inconvenience. You can check our blog or Twitter for more information.

तातोएबा इस वक़्त अनुपलब्ध है। असुविधा के लिए हमें खेद है। अधिक जानकारी के लिये आप हमारा ब्लॉग या ट्विटर देख सकते हैं।

[[English#^en-Q0915-answer|Compare the answer]]
^en-Q0915

**en-Q0916 · Build the sentence**

Arrange: information. / our / or / Tatoeba / can / for / blog / inconvenience. / is / for / currently / are / sorry / the / We / check / more / You / Twitter / unavailable.

तातोएबा इस वक़्त अनुपलब्ध है। असुविधा के लिए हमें खेद है। अधिक जानकारी के लिये आप हमारा ब्लॉग या ट्विटर देख सकते हैं।

[[English#^en-Q0916-answer|Compare the answer]]
^en-Q0916

**en-Q0917 · Write a translation**

Write this in English: मदर टेरेसा एक कैथोलिक नन थीं जो कलकत्ता में रहतीं और काम करतीं थीं।

[[English#^en-Q0917-answer|Compare the answer]]
^en-Q0917

**en-Q0918 · Explain the grammar**

Mother Teresa was 【a】 Catholic nun who lived and worked in Calcutta, India.

मदर टेरेसा एक कैथोलिक नन थीं जो कलकत्ता में रहतीं और काम करतीं थीं।

[[English#^en-Q0918-answer|Compare the answer]]
^en-Q0918

**en-Q0919 · Fill the gap**

Do you want me to open ____ windows?

क्या आप चाहते हैं कि मैं खिड़कियाँ खोलूँ?

[[English#^en-Q0919-answer|Compare the answer]]
^en-Q0919

**en-Q0920 · Choose the form**

Do you want me to open ____ windows?

क्या आप चाहते हैं कि मैं खिड़कियाँ खोलूँ?

Choices: an / the / some / a

[[English#^en-Q0920-answer|Compare the answer]]
^en-Q0920

**en-Q0921 · Edit the changed sentence**

Let me give you 【an】 piece of advice.

मैं तुम्हें एक बात की सलाह देता हूँ।

[[English#^en-Q0921-answer|Compare the answer]]
^en-Q0921

**en-Q0922 · Build the sentence**

Arrange: a / me / Let / give / piece / you / of / advice.

मैं तुम्हें एक बात की सलाह देता हूँ।

[[English#^en-Q0922-answer|Compare the answer]]
^en-Q0922

**en-Q0923 · Write a translation**

Write this in English: वह कभी अपनी ग़लती नहीं मानेगा।

[[English#^en-Q0923-answer|Compare the answer]]
^en-Q0923

**en-Q0924 · Explain the grammar**

He'll never admit to being in 【the】 wrong.

वह कभी अपनी ग़लती नहीं मानेगा।

[[English#^en-Q0924-answer|Compare the answer]]
^en-Q0924

**en-Q0925 · Fill the gap**

That was just ____ trailer, the movie's yet to come, my friend!

यह तो बस ट्रेलर है, पिक्चर अभी बाकी है, मेरे दोस्त!

[[English#^en-Q0925-answer|Compare the answer]]
^en-Q0925

**en-Q0926 · Choose the form**

That was just ____ trailer, the movie's yet to come, my friend!

यह तो बस ट्रेलर है, पिक्चर अभी बाकी है, मेरे दोस्त!

Choices: an / some / a / the

[[English#^en-Q0926-answer|Compare the answer]]
^en-Q0926

**en-Q0927 · Edit the changed sentence**

They say that Firefox is downloaded more than 8 million times 【an】 day.

कहते हैं के फ़ायरफ़ॉक्स प्रतिदिन ८ मिलियन से ज़्यादा बार डाउनलोड किया जाता है।

[[English#^en-Q0927-answer|Compare the answer]]
^en-Q0927

**en-Q0928 · Build the sentence**

Arrange: than / is / say / more / a / Firefox / downloaded / 8 / They / that / day. / million / times

कहते हैं के फ़ायरफ़ॉक्स प्रतिदिन ८ मिलियन से ज़्यादा बार डाउनलोड किया जाता है।

[[English#^en-Q0928-answer|Compare the answer]]
^en-Q0928

**en-Q0929 · Write a translation**

Write this in English: बारिश की वजह से उन्हें खेल रद्द करना पड़ा।

[[English#^en-Q0929-answer|Compare the answer]]
^en-Q0929

**en-Q0930 · Explain the grammar**

Because of 【the】 rain they had to cancel the game.

बारिश की वजह से उन्हें खेल रद्द करना पड़ा।

[[English#^en-Q0930-answer|Compare the answer]]
^en-Q0930

**en-Q0931 · Fill the gap**

Did you have ____ good sleep last night?

तुम कल रात अच्छे से सोये क्या?

[[English#^en-Q0931-answer|Compare the answer]]
^en-Q0931

**en-Q0932 · Choose the form**

Did you have ____ good sleep last night?

तुम कल रात अच्छे से सोये क्या?

Choices: some / the / a / an

[[English#^en-Q0932-answer|Compare the answer]]
^en-Q0932

**en-Q0933 · Edit the changed sentence**

Is it necessary for me to attend 【a】 party?

मेरा पार्टी में आना ज़रूरी है क्या?

[[English#^en-Q0933-answer|Compare the answer]]
^en-Q0933

**en-Q0934 · Build the sentence**

Arrange: for / Is / party? / to / attend / it / the / necessary / me

मेरा पार्टी में आना ज़रूरी है क्या?

[[English#^en-Q0934-answer|Compare the answer]]
^en-Q0934

**en-Q0935 · Write a translation**

Write this in English: उन्होंने वह उपन्यास का रूसी से आर्मीनियाई में भाषांतर किया।

[[English#^en-Q0935-answer|Compare the answer]]
^en-Q0935

**en-Q0936 · Explain the grammar**

They translated 【the】 novel from Russian into Armenian.

उन्होंने वह उपन्यास का रूसी से आर्मीनियाई में भाषांतर किया।

[[English#^en-Q0936-answer|Compare the answer]]
^en-Q0936

**en-Q0937 · Fill the gap**

You must get rid of such ____ habit.

तुम्हे इस तरह की आदत तोड़ देनी चाहिए।

[[English#^en-Q0937-answer|Compare the answer]]
^en-Q0937

**en-Q0938 · Choose the form**

You must get rid of such ____ habit.

तुम्हे इस तरह की आदत तोड़ देनी चाहिए।

Choices: the / a / some / an

[[English#^en-Q0938-answer|Compare the answer]]
^en-Q0938

**en-Q0939 · Edit the changed sentence**

How many letters does 【a】 Russian alphabet have?

रूसी वर्णमाला में कितने अक्षर हैं?

[[English#^en-Q0939-answer|Compare the answer]]
^en-Q0939

**en-Q0940 · Build the sentence**

Arrange: How / many / Russian / letters / does / alphabet / the / have?

रूसी वर्णमाला में कितने अक्षर हैं?

[[English#^en-Q0940-answer|Compare the answer]]
^en-Q0940

**en-Q0941 · Write a translation**

Write this in English: हमको इस घटना की तहकीकात करने में कम-से-कम तीन हफ़्ते लगेंगे।

[[English#^en-Q0941-answer|Compare the answer]]
^en-Q0941

**en-Q0942 · Explain the grammar**

To investigate 【the】 incident would take us at least three weeks.

हमको इस घटना की तहकीकात करने में कम-से-कम तीन हफ़्ते लगेंगे।

[[English#^en-Q0942-answer|Compare the answer]]
^en-Q0942

**en-Q0943 · Fill the gap**

I know ____ girl who can ride a unicycle.

मेरे जान-पहचान की एक लड़की को युनिसायकल चलाना आता है।

[[English#^en-Q0943-answer|Compare the answer]]
^en-Q0943

**en-Q0944 · Choose the form**

I know ____ girl who can ride a unicycle.

मेरे जान-पहचान की एक लड़की को युनिसायकल चलाना आता है।

Choices: some / an / the / a

[[English#^en-Q0944-answer|Compare the answer]]
^en-Q0944

**en-Q0945 · Edit the changed sentence**

One lives in Fukuoka, and 【a】 others live in Niigata.

एक फ़ुकुओका में रहता है, और बाकी निइगाता में रहते हैं।

[[English#^en-Q0945-answer|Compare the answer]]
^en-Q0945

**en-Q0946 · Build the sentence**

Arrange: others / and / One / in / Fukuoka, / lives / live / the / Niigata. / in

एक फ़ुकुओका में रहता है, और बाकी निइगाता में रहते हैं।

[[English#^en-Q0946-answer|Compare the answer]]
^en-Q0946

**en-Q0947 · Write a translation**

Write this in English: धूम्रपान आपको हानि पहुँचाएगा।

[[English#^en-Q0947-answer|Compare the answer]]
^en-Q0947

**en-Q0948 · Explain the grammar**

Smoking will do you 【a】 lot of harm.

धूम्रपान आपको हानि पहुँचाएगा।

[[English#^en-Q0948-answer|Compare the answer]]
^en-Q0948

**en-Q0949 · Fill the gap**

____ man is great by deeds, not by birth.

“व्यक्ति कर्मों से महान बनता है, जन्म से नहीं।

[[English#^en-Q0949-answer|Compare the answer]]
^en-Q0949

**en-Q0950 · Choose the form**

____ man is great by deeds, not by birth.

“व्यक्ति कर्मों से महान बनता है, जन्म से नहीं।

Choices: the / an / some / A

[[English#^en-Q0950-answer|Compare the answer]]
^en-Q0950

**en-Q0951 · Edit the changed sentence**

【a】 walls in the old house were not straight.

उस पुराने घर की दीवारें सीधी नहीं थी।

[[English#^en-Q0951-answer|Compare the answer]]
^en-Q0951

**en-Q0952 · Build the sentence**

Arrange: walls / house / The / in / were / straight. / the / old / not

उस पुराने घर की दीवारें सीधी नहीं थी।

[[English#^en-Q0952-answer|Compare the answer]]
^en-Q0952

**en-Q0953 · Write a translation**

Write this in English: तुम इन दो तस्वीरों में अंतर बता सकते हो?

[[English#^en-Q0953-answer|Compare the answer]]
^en-Q0953

**en-Q0954 · Explain the grammar**

Can you tell 【the】 difference between these two pictures?

तुम इन दो तस्वीरों में अंतर बता सकते हो?

[[English#^en-Q0954-answer|Compare the answer]]
^en-Q0954

**en-Q0955 · Fill the gap**

I saw ____ red car and a white one. The red one was nicer looking than the white one.

मैंने एक लाल कार और सफ़ेद कार देखि. लाल कार सफ़ेद कार से दिखने में ज्यादा अछी थी.

[[English#^en-Q0955-answer|Compare the answer]]
^en-Q0955

**en-Q0956 · Choose the form**

I saw ____ red car and a white one. The red one was nicer looking than the white one.

मैंने एक लाल कार और सफ़ेद कार देखि. लाल कार सफ़ेद कार से दिखने में ज्यादा अछी थी.

Choices: the / an / a / some

[[English#^en-Q0956-answer|Compare the answer]]
^en-Q0956

**en-Q0957 · Edit the changed sentence**

Egyptian began to be written using 【a】 Greek alphabet in the 1st century.

पहले शतक से मिस्री भाषा यूनानी अक्षरों में लिखी जाने लगी।

[[English#^en-Q0957-answer|Compare the answer]]
^en-Q0957

**en-Q0958 · Build the sentence**

Arrange: Egyptian / the / Greek / using / century. / alphabet / written / began / in / to / be / the / 1st

पहले शतक से मिस्री भाषा यूनानी अक्षरों में लिखी जाने लगी।

[[English#^en-Q0958-answer|Compare the answer]]
^en-Q0958

**en-Q0959 · Write a translation**

Write this in English: पता नहीं क्यों मुझे रात में ज़्यादा ज़िन्दा महसूस होता है।

[[English#^en-Q0959-answer|Compare the answer]]
^en-Q0959

**en-Q0960 · Explain the grammar**

For 【some】 reason I feel more alive at night.

पता नहीं क्यों मुझे रात में ज़्यादा ज़िन्दा महसूस होता है।

[[English#^en-Q0960-answer|Compare the answer]]
^en-Q0960

**en-Q0961 · Fill the gap**

This car has enough power to go up ____ mountain easily.

गाड़ी में आसानी से पहाड़ चढ़ने लायक जान है।

[[English#^en-Q0961-answer|Compare the answer]]
^en-Q0961

**en-Q0962 · Choose the form**

This car has enough power to go up ____ mountain easily.

गाड़ी में आसानी से पहाड़ चढ़ने लायक जान है।

Choices: the / a / an / some

[[English#^en-Q0962-answer|Compare the answer]]
^en-Q0962

**en-Q0963 · Edit the changed sentence**

If it isn't 【an】 bad, dirty, or wrong thing, then it's alright.

यदि वह बुरा, गंदा या गलत न हो तो ठीक है।

[[English#^en-Q0963-answer|Compare the answer]]
^en-Q0963

**en-Q0964 · Build the sentence**

Arrange: thing, / it's / alright. / it / a / bad, / then / or / dirty, / isn't / wrong / If

यदि वह बुरा, गंदा या गलत न हो तो ठीक है।

[[English#^en-Q0964-answer|Compare the answer]]
^en-Q0964

**en-Q0965 · Write a translation**

Write this in English: वह हवाई जहाज़ पृथ्वीपर वापस लौटनेवाला नहीं था.

[[English#^en-Q0965-answer|Compare the answer]]
^en-Q0965

**en-Q0966 · Explain the grammar**

【The】 spaceship was never to return to the earth.

वह हवाई जहाज़ पृथ्वीपर वापस लौटनेवाला नहीं था.

[[English#^en-Q0966-answer|Compare the answer]]
^en-Q0966

**en-Q0967 · Fill the gap**

He couldn't sleep because of ____ noise outside his window.

उसकी खिड़की के बाहर इतना शोर हो रहा था कि वह सो नहीं पा रहा था।

[[English#^en-Q0967-answer|Compare the answer]]
^en-Q0967

**en-Q0968 · Choose the form**

He couldn't sleep because of ____ noise outside his window.

उसकी खिड़की के बाहर इतना शोर हो रहा था कि वह सो नहीं पा रहा था।

Choices: some / the / a / an

[[English#^en-Q0968-answer|Compare the answer]]
^en-Q0968

**en-Q0969 · Edit the changed sentence**

Do you feel 【a】 pain in your stomach?

क्या आपको पेट में दर्द महसूस हो रहा है?

[[English#^en-Q0969-answer|Compare the answer]]
^en-Q0969

**en-Q0970 · Build the sentence**

Arrange: in / pain / any / Do / you / your / stomach? / feel

क्या आपको पेट में दर्द महसूस हो रहा है?

[[English#^en-Q0970-answer|Compare the answer]]
^en-Q0970

**en-Q0971 · Write a translation**

Write this in English: उनकी बातचीत लगभग एक घंटे तक चलती रही।

[[English#^en-Q0971-answer|Compare the answer]]
^en-Q0971

**en-Q0972 · Explain the grammar**

Their conversation was carried on for about 【an】 hour.

उनकी बातचीत लगभग एक घंटे तक चलती रही।

[[English#^en-Q0972-answer|Compare the answer]]
^en-Q0972

**en-Q0973 · Fill the gap**

We need to look for ____ gas station because this car will soon run out of gas.

हमे पेट्रोल पम्प ढूँढना चाहिए क्योंकि गाड़ी में पेट्रोल खतम होने वाला है।

[[English#^en-Q0973-answer|Compare the answer]]
^en-Q0973

**en-Q0974 · Choose the form**

We need to look for ____ gas station because this car will soon run out of gas.

हमे पेट्रोल पम्प ढूँढना चाहिए क्योंकि गाड़ी में पेट्रोल खतम होने वाला है।

Choices: the / some / a / an

[[English#^en-Q0974-answer|Compare the answer]]
^en-Q0974

**en-Q0975 · Edit the changed sentence**

Barcelona is 【a】 capital city of Catalonia and the second largest city in Spain.

बार्सेलोना केटलोनिआ की राजधानी और स्पेन का दूसरा सबसे बड़ा शहर है।

[[English#^en-Q0975-answer|Compare the answer]]
^en-Q0975

**en-Q0976 · Build the sentence**

Arrange: the / Catalonia / Barcelona / capital / city / is / largest / and / second / city / in / the / of / Spain.

बार्सेलोना केटलोनिआ की राजधानी और स्पेन का दूसरा सबसे बड़ा शहर है।

[[English#^en-Q0976-answer|Compare the answer]]
^en-Q0976

**en-Q0977 · Write a translation**

Write this in English: आप किसी को बिस्तर बनाने के लिए भेज सकते हैं क्या?

[[English#^en-Q0977-answer|Compare the answer]]
^en-Q0977

**en-Q0978 · Explain the grammar**

Could you send someone up to make 【the】 bed?

आप किसी को बिस्तर बनाने के लिए भेज सकते हैं क्या?

[[English#^en-Q0978-answer|Compare the answer]]
^en-Q0978

**en-Q0979 · Fill the gap**

It's ____ absolute waste of time to wait any longer.

और इंतेज़ार करना समय की सरासर बर्बादी होगी।

[[English#^en-Q0979-answer|Compare the answer]]
^en-Q0979

**en-Q0980 · Choose the form**

It's ____ absolute waste of time to wait any longer.

और इंतेज़ार करना समय की सरासर बर्बादी होगी।

Choices: an / some / the / a

[[English#^en-Q0980-answer|Compare the answer]]
^en-Q0980

**en-Q0981 · Edit the changed sentence**

He had nothing to do with 【a】 case.

उसका इस केस के साथ कोई लेना-देना नहीं था।

[[English#^en-Q0981-answer|Compare the answer]]
^en-Q0981

**en-Q0982 · Build the sentence**

Arrange: case. / the / do / to / with / nothing / He / had

उसका इस केस के साथ कोई लेना-देना नहीं था।

[[English#^en-Q0982-answer|Compare the answer]]
^en-Q0982

**en-Q0983 · Write a translation**

Write this in English: उस समय टॉम न्यूयॉर्क में था।

[[English#^en-Q0983-answer|Compare the answer]]
^en-Q0983

**en-Q0984 · Explain the grammar**

Tom was in New York at 【the】 time.

उस समय टॉम न्यूयॉर्क में था।

[[English#^en-Q0984-answer|Compare the answer]]
^en-Q0984

**en-Q0985 · Fill the gap**

This is ____ plant unique to this country.

यह पौधा केवल इस देश में ही पाया जाता है।

[[English#^en-Q0985-answer|Compare the answer]]
^en-Q0985

**en-Q0986 · Choose the form**

This is ____ plant unique to this country.

यह पौधा केवल इस देश में ही पाया जाता है।

Choices: some / the / an / a

[[English#^en-Q0986-answer|Compare the answer]]
^en-Q0986

**en-Q0987 · Edit the changed sentence**

Did you give 【a】 money back to your mother?

क्या तुमने अपनी माँ को पैसे लौटा दिए?

[[English#^en-Q0987-answer|Compare the answer]]
^en-Q0987

**en-Q0988 · Build the sentence**

Arrange: to / you / your / back / mother? / give / money / Did / the

क्या तुमने अपनी माँ को पैसे लौटा दिए?

[[English#^en-Q0988-answer|Compare the answer]]
^en-Q0988

**en-Q0989 · Write a translation**

Write this in English: और उसका नतीजा क्या होगा?

[[English#^en-Q0989-answer|Compare the answer]]
^en-Q0989

**en-Q0990 · Explain the grammar**

And what will be 【the】 result of that?

और उसका नतीजा क्या होगा?

[[English#^en-Q0990-answer|Compare the answer]]
^en-Q0990

**en-Q0991 · Fill the gap**

His younger sister is ____ well-known TV star.

उसकी छोटी बहन बहुत जानीमानी टीवी स्टार है।

[[English#^en-Q0991-answer|Compare the answer]]
^en-Q0991

**en-Q0992 · Choose the form**

His younger sister is ____ well-known TV star.

उसकी छोटी बहन बहुत जानीमानी टीवी स्टार है।

Choices: some / the / a / an

[[English#^en-Q0992-answer|Compare the answer]]
^en-Q0992

**en-Q0993 · Edit the changed sentence**

In Greek mythology, Hermes, 【a】 son of Zeus, is the messenger of the gods.

यूनानी पुराणों में, ज़्यूस के पुत्र, हरमीस, देवताओं के दूत थे।

[[English#^en-Q0993-answer|Compare the answer]]
^en-Q0993

**en-Q0994 · Build the sentence**

Arrange: Greek / Zeus, / gods. / is / In / the / the / Hermes, / of / mythology, / messenger / son / the / of

यूनानी पुराणों में, ज़्यूस के पुत्र, हरमीस, देवताओं के दूत थे।

[[English#^en-Q0994-answer|Compare the answer]]
^en-Q0994

**en-Q0995 · Write a translation**

Write this in English: वह रोम गया, जहां उसे कई पुरानी इमारतें दिखीं।

[[English#^en-Q0995-answer|Compare the answer]]
^en-Q0995

**en-Q0996 · Explain the grammar**

He went to Rome, where he saw 【a】 lot of old buildings.

वह रोम गया, जहां उसे कई पुरानी इमारतें दिखीं।

[[English#^en-Q0996-answer|Compare the answer]]
^en-Q0996

**en-Q0997 · Fill the gap**

We can hear ____ church bell every morning.

हमें हर सुबह चर्च की घंटी सुनाई देती है।

[[English#^en-Q0997-answer|Compare the answer]]
^en-Q0997

**en-Q0998 · Choose the form**

We can hear ____ church bell every morning.

हमें हर सुबह चर्च की घंटी सुनाई देती है।

Choices: an / the / a / some

[[English#^en-Q0998-answer|Compare the answer]]
^en-Q0998

**en-Q0999 · Edit the changed sentence**

I missed my stop. How long does it take to reach 【a】 next stop?

मेरा स्टॉप छूट गया। अगला स्टॉप कितनी देर में आएगा?

[[English#^en-Q0999-answer|Compare the answer]]
^en-Q0999

**en-Q1000 · Build the sentence**

Arrange: does / my / I / reach / stop? / to / How / next / it / stop. / take / the / missed / long

मेरा स्टॉप छूट गया। अगला स्टॉप कितनी देर में आएगा?

[[English#^en-Q1000-answer|Compare the answer]]
^en-Q1000


### Perfect auxiliaries and reference time · 50 questions

**en-Q0051 · Edit the changed sentence**

Please give me the paper when you 【has】 done with it.

जब आपने अखबार पढ़ लिया हो तो मुझे दे दीजिएगा।

[[English#^en-Q0051-answer|Compare the answer]]
^en-Q0051

**en-Q0052 · Build the sentence**

Arrange: me / when / with / give / the / it. / you / paper / have / Please / done

जब आपने अखबार पढ़ लिया हो तो मुझे दे दीजिएगा।

[[English#^en-Q0052-answer|Compare the answer]]
^en-Q0052

**en-Q0053 · Write a translation**

Write this in English: उसके स्वास्थ्य ने उसको ज़िन्दगी में कामयाब होने दिया है।

[[English#^en-Q0053-answer|Compare the answer]]
^en-Q0053

**en-Q0054 · Explain the grammar**

His health 【has】 enabled him to succeed in life.

उसके स्वास्थ्य ने उसको ज़िन्दगी में कामयाब होने दिया है।

[[English#^en-Q0054-answer|Compare the answer]]
^en-Q0054

**en-Q0055 · Fill the gap**

My pen ____ run out of ink! Can I borrow your pen?

मेरी कलम में स्याही खतम हो गई है। मैं तुम्हारी कलम ले सकता हूँ क्या?

[[English#^en-Q0055-answer|Compare the answer]]
^en-Q0055

**en-Q0056 · Choose the form**

My pen ____ run out of ink! Can I borrow your pen?

मेरी कलम में स्याही खतम हो गई है। मैं तुम्हारी कलम ले सकता हूँ क्या?

Choices: has / have / had

[[English#^en-Q0056-answer|Compare the answer]]
^en-Q0056

**en-Q0057 · Edit the changed sentence**

This museum 【have】 been closed for five years.

यह म्युज़ियम पाँच साल से बंद है।

[[English#^en-Q0057-answer|Compare the answer]]
^en-Q0057

**en-Q0058 · Build the sentence**

Arrange: has / museum / closed / five / years. / for / This / been

यह म्युज़ियम पाँच साल से बंद है।

[[English#^en-Q0058-answer|Compare the answer]]
^en-Q0058

**en-Q0059 · Write a translation**

Write this in English: विद्यार्थियों में से केवल एक ही ने किताब को पढ़ा था।

[[English#^en-Q0059-answer|Compare the answer]]
^en-Q0059

**en-Q0060 · Explain the grammar**

Out of the students, only one 【had】 read that book.

विद्यार्थियों में से केवल एक ही ने किताब को पढ़ा था।

[[English#^en-Q0060-answer|Compare the answer]]
^en-Q0060

**en-Q0061 · Fill the gap**

I ____ been learning English for five years.

मैं पाँच साल से अंग्रेज़ी सीख रहा हूँ।

[[English#^en-Q0061-answer|Compare the answer]]
^en-Q0061

**en-Q0062 · Choose the form**

I ____ been learning English for five years.

मैं पाँच साल से अंग्रेज़ी सीख रहा हूँ।

Choices: have / has / had

[[English#^en-Q0062-answer|Compare the answer]]
^en-Q0062

**en-Q0063 · Edit the changed sentence**

They 【has】 demanded that all copies of the book be destroyed.

उन्होंने मांग करी है कि इस किताब की सारी कॉपियाँ नष्ट कर दीं जाएं।

[[English#^en-Q0063-answer|Compare the answer]]
^en-Q0063

**en-Q0064 · Build the sentence**

Arrange: of / They / all / book / copies / destroyed. / the / that / have / demanded / be

उन्होंने मांग करी है कि इस किताब की सारी कॉपियाँ नष्ट कर दीं जाएं।

[[English#^en-Q0064-answer|Compare the answer]]
^en-Q0064

**en-Q0065 · Write a translation**

Write this in English: अगर वे एक और मिनट जल्दी पहुँचा होता तो उनकी बस छूट नहीं गई हुई होती।

[[English#^en-Q0065-answer|Compare the answer]]
^en-Q0065

**en-Q0066 · Explain the grammar**

One minute earlier, and they could 【have】 caught the bus.

अगर वे एक और मिनट जल्दी पहुँचा होता तो उनकी बस छूट नहीं गई हुई होती।

[[English#^en-Q0066-answer|Compare the answer]]
^en-Q0066

**en-Q0067 · Fill the gap**

Until yesterday, I ____ known nothing about it.

मुझे कल तक इसके बारे में कुछ भी नहीं पता था।

[[English#^en-Q0067-answer|Compare the answer]]
^en-Q0067

**en-Q0068 · Choose the form**

Until yesterday, I ____ known nothing about it.

मुझे कल तक इसके बारे में कुछ भी नहीं पता था।

Choices: have / had / has

[[English#^en-Q0068-answer|Compare the answer]]
^en-Q0068

**en-Q0069 · Edit the changed sentence**

I 【has】 tried innumerable times to contact him.

मैं बहुत बार उससे सम्पर्क करने की कोशिश कर चुकी हूँ।

[[English#^en-Q0069-answer|Compare the answer]]
^en-Q0069

**en-Q0070 · Build the sentence**

Arrange: I / to / innumerable / have / times / him. / tried / contact

मैं बहुत बार उससे सम्पर्क करने की कोशिश कर चुकी हूँ।

[[English#^en-Q0070-answer|Compare the answer]]
^en-Q0070

**en-Q0071 · Write a translation**

Write this in English: लोकतंत्र सरकार का सबसे घिनौना रूप है, अगर बाकी सारी तरह की सरकारों को अंदेखा किया जाए तो।

[[English#^en-Q0071-answer|Compare the answer]]
^en-Q0071

**en-Q0072 · Explain the grammar**

Democracy is the worst form of government, except all the others that 【have】 been tried.

लोकतंत्र सरकार का सबसे घिनौना रूप है, अगर बाकी सारी तरह की सरकारों को अंदेखा किया जाए तो।

[[English#^en-Q0072-answer|Compare the answer]]
^en-Q0072

**en-Q0073 · Fill the gap**

I ____ been living here for three years.

मैं यहां तीन सोलों से रहते आया हूं।

[[English#^en-Q0073-answer|Compare the answer]]
^en-Q0073

**en-Q0074 · Choose the form**

I ____ been living here for three years.

मैं यहां तीन सोलों से रहते आया हूं।

Choices: had / have / has

[[English#^en-Q0074-answer|Compare the answer]]
^en-Q0074

**en-Q0075 · Edit the changed sentence**

Carol 【have】 been studying Spanish for three years.

कैरल तीन साल से स्पैनिश पढ़ रही है।

[[English#^en-Q0075-answer|Compare the answer]]
^en-Q0075

**en-Q0076 · Build the sentence**

Arrange: has / studying / been / Carol / Spanish / three / for / years.

कैरल तीन साल से स्पैनिश पढ़ रही है।

[[English#^en-Q0076-answer|Compare the answer]]
^en-Q0076

**en-Q0077 · Write a translation**

Write this in English: १९०५ में जापान ने रूस को एक युद्ध में हराया था।

[[English#^en-Q0077-answer|Compare the answer]]
^en-Q0077

**en-Q0078 · Explain the grammar**

Japan 【had】 defeated Russia in a war in 1905.

१९०५ में जापान ने रूस को एक युद्ध में हराया था।

[[English#^en-Q0078-answer|Compare the answer]]
^en-Q0078

**en-Q0079 · Fill the gap**

You ought not to ____ spent so much money on your hobby.

तुम्हें अपने शौक पर इतने सारे पैसे खर्च नहीं करने चाहिए थे।

[[English#^en-Q0079-answer|Compare the answer]]
^en-Q0079

**en-Q0080 · Choose the form**

You ought not to ____ spent so much money on your hobby.

तुम्हें अपने शौक पर इतने सारे पैसे खर्च नहीं करने चाहिए थे।

Choices: had / has / have

[[English#^en-Q0080-answer|Compare the answer]]
^en-Q0080

**en-Q0081 · Edit the changed sentence**

She 【have】 been with me through the ebb and flow of my fortunes.

वे मेरी किस्मत के उतार चढ़ाव में लगातार मेरे साथ रहीं हैं।

[[English#^en-Q0081-answer|Compare the answer]]
^en-Q0081

**en-Q0082 · Build the sentence**

Arrange: fortunes. / my / with / of / ebb / has / the / been / me / She / flow / and / through

वे मेरी किस्मत के उतार चढ़ाव में लगातार मेरे साथ रहीं हैं।

[[English#^en-Q0082-answer|Compare the answer]]
^en-Q0082

**en-Q0083 · Write a translation**

Write this in English: उसकी मदद के बिना तुम नहीं कर पाते।

[[English#^en-Q0083-answer|Compare the answer]]
^en-Q0083

**en-Q0084 · Explain the grammar**

If it 【had】 not been for her help, you would never have done it.

उसकी मदद के बिना तुम नहीं कर पाते।

[[English#^en-Q0084-answer|Compare the answer]]
^en-Q0084

**en-Q0085 · Fill the gap**

The depredations of human hunters are thought to ____ been the key factor that pushed many species to extinction.

ऐसा माना जाता है कि मानव शिकारियों द्वारा की गई लूटमार ही अनेक प्रजातियों के लुप्त होने का बड़ा कारण है।

[[English#^en-Q0085-answer|Compare the answer]]
^en-Q0085

**en-Q0086 · Choose the form**

The depredations of human hunters are thought to ____ been the key factor that pushed many species to extinction.

ऐसा माना जाता है कि मानव शिकारियों द्वारा की गई लूटमार ही अनेक प्रजातियों के लुप्त होने का बड़ा कारण है।

Choices: has / have / had

[[English#^en-Q0086-answer|Compare the answer]]
^en-Q0086

**en-Q0087 · Edit the changed sentence**

Kate 【have】 been given an opportunity to play a major role in a movie.

केट को एक फ़िल्म में प्रमुख भूमिका निभाने का मौका दिया गया गै।

[[English#^en-Q0087-answer|Compare the answer]]
^en-Q0087

**en-Q0088 · Build the sentence**

Arrange: given / play / a / Kate / been / to / in / an / role / opportunity / has / a / major / movie.

केट को एक फ़िल्म में प्रमुख भूमिका निभाने का मौका दिया गया गै।

[[English#^en-Q0088-answer|Compare the answer]]
^en-Q0088

**en-Q0089 · Write a translation**

Write this in English: जैक ने मेरा छाता शायद ग़लती से ले लिया है।

[[English#^en-Q0089-answer|Compare the answer]]
^en-Q0089

**en-Q0090 · Explain the grammar**

Jack may 【have】 taken my umbrella by mistake.

जैक ने मेरा छाता शायद ग़लती से ले लिया है।

[[English#^en-Q0090-answer|Compare the answer]]
^en-Q0090

**en-Q0091 · Fill the gap**

The authorities ____ been hiding the facts from the public.

अधिकारियों ने सच्चाई को आम जनता से छिपा कर रखा हुआ है।

[[English#^en-Q0091-answer|Compare the answer]]
^en-Q0091

**en-Q0092 · Choose the form**

The authorities ____ been hiding the facts from the public.

अधिकारियों ने सच्चाई को आम जनता से छिपा कर रखा हुआ है।

Choices: have / had / has

[[English#^en-Q0092-answer|Compare the answer]]
^en-Q0092

**en-Q0093 · Edit the changed sentence**

A committee 【have】 been set up to investigate the problem.

इस समस्या की तहकीकात करने के लिए एक समिति स्थापित करी गई है।

[[English#^en-Q0093-answer|Compare the answer]]
^en-Q0093

**en-Q0094 · Build the sentence**

Arrange: investigate / problem. / the / has / A / to / committee / been / up / set

इस समस्या की तहकीकात करने के लिए एक समिति स्थापित करी गई है।

[[English#^en-Q0094-answer|Compare the answer]]
^en-Q0094

**en-Q0095 · Write a translation**

Write this in English: मैं आपके अच्छेपन को कभी नहीं भूलूँगा।

[[English#^en-Q0095-answer|Compare the answer]]
^en-Q0095

**en-Q0096 · Explain the grammar**

I'll never forget how kind you 【have】 been.

मैं आपके अच्छेपन को कभी नहीं भूलूँगा।

[[English#^en-Q0096-answer|Compare the answer]]
^en-Q0096

**en-Q0097 · Fill the gap**

The police arrested the man who ____ murdered the girl.

पुलिस ने उस लड़की के क़ातिल को हरासत में ले लिया।

[[English#^en-Q0097-answer|Compare the answer]]
^en-Q0097

**en-Q0098 · Choose the form**

The police arrested the man who ____ murdered the girl.

पुलिस ने उस लड़की के क़ातिल को हरासत में ले लिया।

Choices: had / have / has

[[English#^en-Q0098-answer|Compare the answer]]
^en-Q0098

**en-Q0099 · Edit the changed sentence**

I 【have】 met him many times before then.

मैं उससे पहले कई बार मिल चुका था।

[[English#^en-Q0099-answer|Compare the answer]]
^en-Q0099

**en-Q0100 · Build the sentence**

Arrange: I / times / had / met / before / then. / him / many

मैं उससे पहले कई बार मिल चुका था।

[[English#^en-Q0100-answer|Compare the answer]]
^en-Q0100


### Progressive perspective · 34 questions

**en-Q0101 · Write a translation**

Write this in English: एक बत्ती नहीं जल रही है। तुम ज़रा आकर देख सकते हो क्या?

[[English#^en-Q0101-answer|Compare the answer]]
^en-Q0101

**en-Q0102 · Explain the grammar**

One of the lights is not 【working】. Do you think you could come take a look?

एक बत्ती नहीं जल रही है। तुम ज़रा आकर देख सकते हो क्या?

[[English#^en-Q0102-answer|Compare the answer]]
^en-Q0102

**en-Q0103 · Fill the gap**

Are these the glasses you were ____ for?

क्या यह वह ऐनक है जिसे आप ढूँढ रहे थे ?

[[English#^en-Q0103-answer|Compare the answer]]
^en-Q0103

**en-Q0104 · Choose the form**

Are these the glasses you were ____ for?

क्या यह वह ऐनक है जिसे आप ढूँढ रहे थे ?

Choices: waiting / looking / working / being

[[English#^en-Q0104-answer|Compare the answer]]
^en-Q0104

**en-Q0105 · Edit the changed sentence**

The scientists are 【being】 on a new experiment.

वैज्ञानिक नए प्रयोग पर काम कर रहे है I

[[English#^en-Q0105-answer|Compare the answer]]
^en-Q0105

**en-Q0106 · Build the sentence**

Arrange: are / on / a / scientists / The / working / new / experiment.

वैज्ञानिक नए प्रयोग पर काम कर रहे है I

[[English#^en-Q0106-answer|Compare the answer]]
^en-Q0106

**en-Q0107 · Write a translation**

Write this in English: हम एक ऐसे दुश्मन के विरुद्ध काम कर रहे हैं जो कपटपूर्ण विधियां अपनाने में प्रवीण है।

[[English#^en-Q0107-answer|Compare the answer]]
^en-Q0107

**en-Q0108 · Explain the grammar**

We are 【working】 against an enemy who is very insidious in his methods.

हम एक ऐसे दुश्मन के विरुद्ध काम कर रहे हैं जो कपटपूर्ण विधियां अपनाने में प्रवीण है।

[[English#^en-Q0108-answer|Compare the answer]]
^en-Q0108

**en-Q0109 · Fill the gap**

A new building is ____ built in front of my house.

मेरे घर के सामने एक नई ईमारत बन रही है।

[[English#^en-Q0109-answer|Compare the answer]]
^en-Q0109

**en-Q0110 · Choose the form**

A new building is ____ built in front of my house.

मेरे घर के सामने एक नई ईमारत बन रही है।

Choices: waiting / working / being

[[English#^en-Q0110-answer|Compare the answer]]
^en-Q0110

**en-Q0111 · Edit the changed sentence**

I am 【being】 for a present for my mother.

मैं अपनी मम्मी के लिए तोह्फ़ा ढूँढ रहा हूँ।

[[English#^en-Q0111-answer|Compare the answer]]
^en-Q0111

**en-Q0112 · Build the sentence**

Arrange: a / am / for / looking / for / mother. / my / present / I

मैं अपनी मम्मी के लिए तोह्फ़ा ढूँढ रहा हूँ।

[[English#^en-Q0112-answer|Compare the answer]]
^en-Q0112

**en-Q0113 · Write a translation**

Write this in English: वह चिट्ठी पढ़ने के समय दुखी लग रही थी।

[[English#^en-Q0113-answer|Compare the answer]]
^en-Q0113

**en-Q0114 · Explain the grammar**

When she was 【reading】 the letter, she looked sad.

वह चिट्ठी पढ़ने के समय दुखी लग रही थी।

[[English#^en-Q0114-answer|Compare the answer]]
^en-Q0114

**en-Q0115 · Fill the gap**

I am ____ business on a large scale.

मैं बड़े पैमाने पर व्यापार कर रहा हूँ।

[[English#^en-Q0115-answer|Compare the answer]]
^en-Q0115

**en-Q0116 · Choose the form**

I am ____ business on a large scale.

मैं बड़े पैमाने पर व्यापार कर रहा हूँ।

Choices: working / waiting / being / doing

[[English#^en-Q0116-answer|Compare the answer]]
^en-Q0116

**en-Q0117 · Edit the changed sentence**

What do you think she is 【being】 now?

तुम्हारे हिसाब से वह अभी क्या कर रही होगी?

[[English#^en-Q0117-answer|Compare the answer]]
^en-Q0117

**en-Q0118 · Build the sentence**

Arrange: is / What / think / now? / you / she / doing / do

तुम्हारे हिसाब से वह अभी क्या कर रही होगी?

[[English#^en-Q0118-answer|Compare the answer]]
^en-Q0118

**en-Q0119 · Write a translation**

Write this in English: तुम कल इस समय क्या कर रहे होगे?

[[English#^en-Q0119-answer|Compare the answer]]
^en-Q0119

**en-Q0120 · Explain the grammar**

What will you be 【doing】 at this time tomorrow?

तुम कल इस समय क्या कर रहे होगे?

[[English#^en-Q0120-answer|Compare the answer]]
^en-Q0120

**en-Q0121 · Fill the gap**

I am ____ to memorise the names of constellations.

मैं सभी नक्षत्रों के नाम याद रखने की कोशिश कर रहा हूं।

[[English#^en-Q0121-answer|Compare the answer]]
^en-Q0121

**en-Q0122 · Choose the form**

I am ____ to memorise the names of constellations.

मैं सभी नक्षत्रों के नाम याद रखने की कोशिश कर रहा हूं।

Choices: waiting / trying / being / working

[[English#^en-Q0122-answer|Compare the answer]]
^en-Q0122

**en-Q0123 · Edit the changed sentence**

You are 【being】 very well. Keep it up.

तुम अच्छा काम कर रहे हो। ऐसे ही करते रहो।

[[English#^en-Q0123-answer|Compare the answer]]
^en-Q0123

**en-Q0124 · Build the sentence**

Arrange: are / You / very / doing / Keep / up. / well. / it

तुम अच्छा काम कर रहे हो। ऐसे ही करते रहो।

[[English#^en-Q0124-answer|Compare the answer]]
^en-Q0124

**en-Q0125 · Write a translation**

Write this in English: मुझे यह बताओ, कि टॉम ऐसा कर क्यों रहा है।

[[English#^en-Q0125-answer|Compare the answer]]
^en-Q0125

**en-Q0126 · Explain the grammar**

I want to know why Tom is 【doing】 this.

मुझे यह बताओ, कि टॉम ऐसा कर क्यों रहा है।

[[English#^en-Q0126-answer|Compare the answer]]
^en-Q0126

**en-Q0127 · Fill the gap**

Someone called Mr Dell is ____ for you in your office, Mrs Stevens.

श्री स्टीवन्स, आपके दफ़्तर में श्री डेल नाम के कोई व्यक्ती आपकी प्रतिक्षा कर रहे हैं।

[[English#^en-Q0127-answer|Compare the answer]]
^en-Q0127

**en-Q0128 · Choose the form**

Someone called Mr Dell is ____ for you in your office, Mrs Stevens.

श्री स्टीवन्स, आपके दफ़्तर में श्री डेल नाम के कोई व्यक्ती आपकी प्रतिक्षा कर रहे हैं।

Choices: waiting / working / being

[[English#^en-Q0128-answer|Compare the answer]]
^en-Q0128

**en-Q0129 · Edit the changed sentence**

What'll you be 【being】 at this time tomorrow?

तुम कल इस समय क्या कर रहे होगे?

[[English#^en-Q0129-answer|Compare the answer]]
^en-Q0129

**en-Q0130 · Build the sentence**

Arrange: at / time / tomorrow? / this / you / What'll / doing / be

तुम कल इस समय क्या कर रहे होगे?

[[English#^en-Q0130-answer|Compare the answer]]
^en-Q0130

**en-Q0131 · Write a translation**

Write this in English: मेरी उस समय तुम्हें ढूँढ रही थी।

[[English#^en-Q0131-answer|Compare the answer]]
^en-Q0131

**en-Q0132 · Explain the grammar**

Mary was 【looking】 for you at that time.

मेरी उस समय तुम्हें ढूँढ रही थी।

[[English#^en-Q0132-answer|Compare the answer]]
^en-Q0132

**en-Q0133 · Fill the gap**

Tell me what you are ____ forward to.

मुझे बताओ तुम किस चीज़ की आशा कर रहे हो।

[[English#^en-Q0133-answer|Compare the answer]]
^en-Q0133

**en-Q0134 · Choose the form**

Tell me what you are ____ forward to.

मुझे बताओ तुम किस चीज़ की आशा कर रहे हो।

Choices: waiting / working / being / looking

[[English#^en-Q0134-answer|Compare the answer]]
^en-Q0134


### Modal inference · 50 questions

**en-Q0135 · Edit the changed sentence**

In order to stay awake I 【must】 have to drink more coffee.

मुझे जगे रहने के लिए शायद और कॉफ़ी पीनी पड़ेगी।

[[English#^en-Q0135-answer|Compare the answer]]
^en-Q0135

**en-Q0136 · Build the sentence**

Arrange: awake / to / order / have / to / stay / more / may / coffee. / In / drink / I

मुझे जगे रहने के लिए शायद और कॉफ़ी पीनी पड़ेगी।

[[English#^en-Q0136-answer|Compare the answer]]
^en-Q0136

**en-Q0137 · Write a translation**

Write this in English: मुझे डर था कि तुम मुझे छोड़ दोगे।

[[English#^en-Q0137-answer|Compare the answer]]
^en-Q0137

**en-Q0138 · Explain the grammar**

I was scared that you 【might】 leave me.

मुझे डर था कि तुम मुझे छोड़ दोगे।

[[English#^en-Q0138-answer|Compare the answer]]
^en-Q0138

**en-Q0139 · Fill the gap**

Oh, I do wish I ____ go to France.

ओह, काश मैं फ़्रान्स जा सकती!

[[English#^en-Q0139-answer|Compare the answer]]
^en-Q0139

**en-Q0140 · Choose the form**

Oh, I do wish I ____ go to France.

ओह, काश मैं फ़्रान्स जा सकती!

Choices: must / might / may / could

[[English#^en-Q0140-answer|Compare the answer]]
^en-Q0140

**en-Q0141 · Edit the changed sentence**

You 【might】 get rid of such a habit.

तुम्हे इस तरह की आदत तोड़ देनी चाहिए।

[[English#^en-Q0141-answer|Compare the answer]]
^en-Q0141

**en-Q0142 · Build the sentence**

Arrange: must / a / such / You / habit. / get / of / rid

तुम्हे इस तरह की आदत तोड़ देनी चाहिए।

[[English#^en-Q0142-answer|Compare the answer]]
^en-Q0142

**en-Q0143 · Write a translation**

Write this in English: आप किसी को बिस्तर बनाने के लिए भेज सकते हैं क्या?

[[English#^en-Q0143-answer|Compare the answer]]
^en-Q0143

**en-Q0144 · Explain the grammar**

【Could】 you send someone up to make the bed?

आप किसी को बिस्तर बनाने के लिए भेज सकते हैं क्या?

[[English#^en-Q0144-answer|Compare the answer]]
^en-Q0144

**en-Q0145 · Fill the gap**

He ____ not come because of his illness.

वह बीमारी की वजह से नहीं आ सका।

[[English#^en-Q0145-answer|Compare the answer]]
^en-Q0145

**en-Q0146 · Choose the form**

He ____ not come because of his illness.

वह बीमारी की वजह से नहीं आ सका।

Choices: must / may / might / could

[[English#^en-Q0146-answer|Compare the answer]]
^en-Q0146

**en-Q0147 · Edit the changed sentence**

However hard it 【must】 rain, we will start tomorrow.

चाहे जितनी भी ज़ोर से बारिश हो, हम कल निकल चलेंगे।

[[English#^en-Q0147-answer|Compare the answer]]
^en-Q0147

**en-Q0148 · Build the sentence**

Arrange: will / rain, / tomorrow. / it / start / hard / we / may / However

चाहे जितनी भी ज़ोर से बारिश हो, हम कल निकल चलेंगे।

[[English#^en-Q0148-answer|Compare the answer]]
^en-Q0148

**en-Q0149 · Write a translation**

Write this in English: तुम किसी भी हालत में आज बाहर नहीं जा सकते।

[[English#^en-Q0149-answer|Compare the answer]]
^en-Q0149

**en-Q0150 · Explain the grammar**

On no account 【must】 you go out today.

तुम किसी भी हालत में आज बाहर नहीं जा सकते।

[[English#^en-Q0150-answer|Compare the answer]]
^en-Q0150

**en-Q0151 · Fill the gap**

You ____ eat your cake and have it too.

तुम "चित भी मेरी पट भी मेरी" नहीं कर सकते।

[[English#^en-Q0151-answer|Compare the answer]]
^en-Q0151

**en-Q0152 · Choose the form**

You ____ eat your cake and have it too.

तुम "चित भी मेरी पट भी मेरी" नहीं कर सकते।

Choices: cannot / must / might / may

[[English#^en-Q0152-answer|Compare the answer]]
^en-Q0152

**en-Q0153 · Edit the changed sentence**

She 【must】 attend school on account of illness.

वह बीमारी की वजह से स्कूल नहीं जा सकती।

[[English#^en-Q0153-answer|Compare the answer]]
^en-Q0153

**en-Q0154 · Build the sentence**

Arrange: attend / She / cannot / account / illness. / of / on / school

वह बीमारी की वजह से स्कूल नहीं जा सकती।

[[English#^en-Q0154-answer|Compare the answer]]
^en-Q0154

**en-Q0155 · Write a translation**

Write this in English: मैं उसके मज़ाक पर बस हँस पड़ा।

[[English#^en-Q0155-answer|Compare the answer]]
^en-Q0155

**en-Q0156 · Explain the grammar**

I 【could】 not but laugh at his joke.

मैं उसके मज़ाक पर बस हँस पड़ा।

[[English#^en-Q0156-answer|Compare the answer]]
^en-Q0156

**en-Q0157 · Fill the gap**

He ____ buy a car, still less a house.

मकान की बात तो छोड़ो वह तो गाड़ी भी नहीं ख़रीद सकता।

[[English#^en-Q0157-answer|Compare the answer]]
^en-Q0157

**en-Q0158 · Choose the form**

He ____ buy a car, still less a house.

मकान की बात तो छोड़ो वह तो गाड़ी भी नहीं ख़रीद सकता।

Choices: might / may / cannot / must

[[English#^en-Q0158-answer|Compare the answer]]
^en-Q0158

**en-Q0159 · Edit the changed sentence**

It's been nice talking to you, but I really 【might】 go now.

आपसे बात करके खुशी हुई, पर अब मुझे जाना पड़ेगा।

[[English#^en-Q0159-answer|Compare the answer]]
^en-Q0159

**en-Q0160 · Build the sentence**

Arrange: go / been / really / It's / to / nice / you, / I / now. / talking / must / but

आपसे बात करके खुशी हुई, पर अब मुझे जाना पड़ेगा।

[[English#^en-Q0160-answer|Compare the answer]]
^en-Q0160

**en-Q0161 · Write a translation**

Write this in English: तुम्हारे ऐसे दोस्त होने चाहिए के जो तुम्हारी मदद करें।

[[English#^en-Q0161-answer|Compare the answer]]
^en-Q0161

**en-Q0162 · Explain the grammar**

You 【must】 have such friends as will help you.

तुम्हारे ऐसे दोस्त होने चाहिए के जो तुम्हारी मदद करें।

[[English#^en-Q0162-answer|Compare the answer]]
^en-Q0162

**en-Q0163 · Fill the gap**

We ____ decide whether to go to college or not.

हम यह फ़ैसला नहीं ले पा रहें हैं कि कॉलेज जाएं या न जाएं।

[[English#^en-Q0163-answer|Compare the answer]]
^en-Q0163

**en-Q0164 · Choose the form**

We ____ decide whether to go to college or not.

हम यह फ़ैसला नहीं ले पा रहें हैं कि कॉलेज जाएं या न जाएं।

Choices: cannot / might / must / may

[[English#^en-Q0164-answer|Compare the answer]]
^en-Q0164

**en-Q0165 · Edit the changed sentence**

All trees and shrubs 【might】 be trimmed so that their branches are no closer than one metre from a power line.

सभी व्रक्ष व झाड़ियाँ इस प्रकार काटी जाएं ताकि उनकी शाखाएं बिजली की तार से एक मीटर की दूरी से अधिक नज़दीक न हों |

[[English#^en-Q0165-answer|Compare the answer]]
^en-Q0165

**en-Q0166 · Build the sentence**

Arrange: power / closer / no / be / shrubs / than / branches / from / metre / their / and / must / trees / a / trimmed / so / are / one / line. / that / All

सभी व्रक्ष व झाड़ियाँ इस प्रकार काटी जाएं ताकि उनकी शाखाएं बिजली की तार से एक मीटर की दूरी से अधिक नज़दीक न हों |

[[English#^en-Q0166-answer|Compare the answer]]
^en-Q0166

**en-Q0167 · Write a translation**

Write this in English: भारत में आप हिमालय क्षेत्र में ऐसे अनेक साधुओं को देख सकते हैं जिन्हें भविष्यदर्शी कहा जा सकता है।

[[English#^en-Q0167-answer|Compare the answer]]
^en-Q0167

**en-Q0168 · Explain the grammar**

In India, you can find many saints in the Himalayan region who 【could】 be called prescient.

भारत में आप हिमालय क्षेत्र में ऐसे अनेक साधुओं को देख सकते हैं जिन्हें भविष्यदर्शी कहा जा सकता है।

[[English#^en-Q0168-answer|Compare the answer]]
^en-Q0168

**en-Q0169 · Fill the gap**

Strange as it ____ sound, this is true.

चाहे सुनने में जितना भी अजीब लगे, यह सच है।

[[English#^en-Q0169-answer|Compare the answer]]
^en-Q0169

**en-Q0170 · Choose the form**

Strange as it ____ sound, this is true.

चाहे सुनने में जितना भी अजीब लगे, यह सच है।

Choices: could / must / may / might

[[English#^en-Q0170-answer|Compare the answer]]
^en-Q0170

**en-Q0171 · Edit the changed sentence**

We calculated that we 【must】 reach the place within two weeks.

हमने हिसाब लगाया कि हम वहाँ दो हफ़्तों में पहुँच सकते थे।

[[English#^en-Q0171-answer|Compare the answer]]
^en-Q0171

**en-Q0172 · Build the sentence**

Arrange: weeks. / that / we / calculated / place / reach / the / We / could / within / two

हमने हिसाब लगाया कि हम वहाँ दो हफ़्तों में पहुँच सकते थे।

[[English#^en-Q0172-answer|Compare the answer]]
^en-Q0172

**en-Q0173 · Write a translation**

Write this in English: मैं हैरान था कि वह सवाल का जवाब नहीं दे पाई।

[[English#^en-Q0173-answer|Compare the answer]]
^en-Q0173

**en-Q0174 · Explain the grammar**

To my surprise, she 【could】 not answer the question.

मैं हैरान था कि वह सवाल का जवाब नहीं दे पाई।

[[English#^en-Q0174-answer|Compare the answer]]
^en-Q0174

**en-Q0175 · Fill the gap**

You ____ as well read a novel instead of staring at the ceiling.

छत पर घूरने के बजाए उपन्यास ही पढ़लो।

[[English#^en-Q0175-answer|Compare the answer]]
^en-Q0175

**en-Q0176 · Choose the form**

You ____ as well read a novel instead of staring at the ceiling.

छत पर घूरने के बजाए उपन्यास ही पढ़लो।

Choices: could / might / may / must

[[English#^en-Q0176-answer|Compare the answer]]
^en-Q0176

**en-Q0177 · Edit the changed sentence**

They wanted to get married as soon as they 【must】.

वे जल्द-से-जल्द शादी करना चाहते थे।

[[English#^en-Q0177-answer|Compare the answer]]
^en-Q0177

**en-Q0178 · Build the sentence**

Arrange: they / could. / as / wanted / get / as / They / soon / to / married

वे जल्द-से-जल्द शादी करना चाहते थे।

[[English#^en-Q0178-answer|Compare the answer]]
^en-Q0178

**en-Q0179 · Write a translation**

Write this in English: युद्ध का आतंक टॉम कभी नहीं भूल पाया।

[[English#^en-Q0179-answer|Compare the answer]]
^en-Q0179

**en-Q0180 · Explain the grammar**

Tom 【could】 never forget the terror of war.

युद्ध का आतंक टॉम कभी नहीं भूल पाया।

[[English#^en-Q0180-answer|Compare the answer]]
^en-Q0180

**en-Q0181 · Fill the gap**

If you have a time, ____ you translate some sentences below, please?

अगर आपके पास थोड़ा समय हो, तो कृपया निम्न वाक्यों का अनुवाद करेंगे?

[[English#^en-Q0181-answer|Compare the answer]]
^en-Q0181

**en-Q0182 · Choose the form**

If you have a time, ____ you translate some sentences below, please?

अगर आपके पास थोड़ा समय हो, तो कृपया निम्न वाक्यों का अनुवाद करेंगे?

Choices: may / could / might / must

[[English#^en-Q0182-answer|Compare the answer]]
^en-Q0182

**en-Q0183 · Edit the changed sentence**

I 【must】 dance one single step of Salsa.

मुझे साल्सा नाचना बिलकुल नहीं आता।

[[English#^en-Q0183-answer|Compare the answer]]
^en-Q0183

**en-Q0184 · Build the sentence**

Arrange: Salsa. / cannot / of / step / I / dance / single / one

मुझे साल्सा नाचना बिलकुल नहीं आता।

[[English#^en-Q0184-answer|Compare the answer]]
^en-Q0184


### Past modal constructions · 12 questions

**en-Q0185 · Write a translation**

Write this in English: उसके साथ रास्ते पर कुछ हुआ होगा।

[[English#^en-Q0185-answer|Compare the answer]]
^en-Q0185

**en-Q0186 · Explain the grammar**

Something 【must have】 happened to him on the way.

उसके साथ रास्ते पर कुछ हुआ होगा।

[[English#^en-Q0186-answer|Compare the answer]]
^en-Q0186

**en-Q0187 · Fill the gap**

If I had known her address, I ____ written to her.

अगर मुझे उसका पता पता होता, तो मैंने उसे चिट्ठी लिखी हुई होती।

[[English#^en-Q0187-answer|Compare the answer]]
^en-Q0187

**en-Q0188 · Choose the form**

If I had known her address, I ____ written to her.

अगर मुझे उसका पता पता होता, तो मैंने उसे चिट्ठी लिखी हुई होती।

Choices: would have / could have / should have

[[English#^en-Q0188-answer|Compare the answer]]
^en-Q0188

**en-Q0189 · Edit the changed sentence**

With a little more patience, you 【should have】 succeeded.

अगर तुममें थोड़ा और सब्र होता तो तुम कामयाब हो जाते।

[[English#^en-Q0189-answer|Compare the answer]]
^en-Q0189

**en-Q0190 · Build the sentence**

Arrange: you / With / have / a / little / patience, / would / succeeded. / more

अगर तुममें थोड़ा और सब्र होता तो तुम कामयाब हो जाते।

[[English#^en-Q0190-answer|Compare the answer]]
^en-Q0190

**en-Q0191 · Write a translation**

Write this in English: मैंने उसे बस में छोड़ दिया होगा।

[[English#^en-Q0191-answer|Compare the answer]]
^en-Q0191

**en-Q0192 · Explain the grammar**

I 【must have】 left it on the bus.

मैंने उसे बस में छोड़ दिया होगा।

[[English#^en-Q0192-answer|Compare the answer]]
^en-Q0192

**en-Q0193 · Fill the gap**

Had he tried it once more, he ____ succeeded in it.

अगर उसने और एक बार कोशिश की होती, तो शायद वह सफल हो जाता.

[[English#^en-Q0193-answer|Compare the answer]]
^en-Q0193

**en-Q0194 · Choose the form**

Had he tried it once more, he ____ succeeded in it.

अगर उसने और एक बार कोशिश की होती, तो शायद वह सफल हो जाता.

Choices: would have / could have / should have

[[English#^en-Q0194-answer|Compare the answer]]
^en-Q0194

**en-Q0195 · Edit the changed sentence**

He told the truth, otherwise he 【should have】 been punished.

उसने सच बताया, वरना उसे सज़ा होती।

[[English#^en-Q0195-answer|Compare the answer]]
^en-Q0195

**en-Q0196 · Build the sentence**

Arrange: otherwise / the / have / been / He / punished. / told / he / would / truth,

उसने सच बताया, वरना उसे सज़ा होती।

[[English#^en-Q0196-answer|Compare the answer]]
^en-Q0196


### Conditional relationships · 50 questions

**en-Q0197 · Write a translation**

Write this in English: मेरा हाथ पकड़लो अगर तुम्हे डर लग रहा है तो।

[[English#^en-Q0197-answer|Compare the answer]]
^en-Q0197

**en-Q0198 · Explain the grammar**

Keep hold of my hand 【if】 you're afraid.

मेरा हाथ पकड़लो अगर तुम्हे डर लग रहा है तो।

[[English#^en-Q0198-answer|Compare the answer]]
^en-Q0198

**en-Q0199 · Fill the gap**

Tom wouldn't be here ____ it wasn't for me.

मैं ना होता तो टॉम आज यहाँ नहीं होता।

[[English#^en-Q0199-answer|Compare the answer]]
^en-Q0199

**en-Q0200 · Choose the form**

Tom wouldn't be here ____ it wasn't for me.

मैं ना होता तो टॉम आज यहाँ नहीं होता।

Choices: if / provided that / unless

[[English#^en-Q0200-answer|Compare the answer]]
^en-Q0200

**en-Q0201 · Edit the changed sentence**

You will get fat 【unless】 you eat too much.

बहुत ज़्यादा खा लिया तो मोटे हो जाओगे।

[[English#^en-Q0201-answer|Compare the answer]]
^en-Q0201

**en-Q0202 · Build the sentence**

Arrange: get / too / will / fat / You / if / eat / much. / you

बहुत ज़्यादा खा लिया तो मोटे हो जाओगे।

[[English#^en-Q0202-answer|Compare the answer]]
^en-Q0202

**en-Q0203 · Write a translation**

Write this in English: टॉम आज ज़िंदा होता तो वह क्या कहता?

[[English#^en-Q0203-answer|Compare the answer]]
^en-Q0203

**en-Q0204 · Explain the grammar**

What would Tom say 【if】 he were alive today?

टॉम आज ज़िंदा होता तो वह क्या कहता?

[[English#^en-Q0204-answer|Compare the answer]]
^en-Q0204

**en-Q0205 · Fill the gap**

____ it isn't a bad, dirty, or wrong thing, then it's alright.

यदि वह बुरा, गंदा या गलत न हो तो ठीक है।

[[English#^en-Q0205-answer|Compare the answer]]
^en-Q0205

**en-Q0206 · Choose the form**

____ it isn't a bad, dirty, or wrong thing, then it's alright.

यदि वह बुरा, गंदा या गलत न हो तो ठीक है।

Choices: provided that / unless / If

[[English#^en-Q0206-answer|Compare the answer]]
^en-Q0206

**en-Q0207 · Edit the changed sentence**

I don't see any point in going 【unless】 the party is almost over.

मुझे जाने मेँ कोई तुक नहिं लगता अगर पीृतिभोज लगभग समापत हो चुका हो ।

[[English#^en-Q0207-answer|Compare the answer]]
^en-Q0207

**en-Q0208 · Build the sentence**

Arrange: party / don't / point / going / over. / is / in / I / see / almost / any / the / if

मुझे जाने मेँ कोई तुक नहिं लगता अगर पीृतिभोज लगभग समापत हो चुका हो ।

[[English#^en-Q0208-answer|Compare the answer]]
^en-Q0208

**en-Q0209 · Write a translation**

Write this in English: अगर कल बर्फ़ गिरी तो मैं स्नोमैन बनाऊंगा।

[[English#^en-Q0209-answer|Compare the answer]]
^en-Q0209

**en-Q0210 · Explain the grammar**

【If】 it snows tomorrow, I'll build a snowman.

अगर कल बर्फ़ गिरी तो मैं स्नोमैन बनाऊंगा।

[[English#^en-Q0210-answer|Compare the answer]]
^en-Q0210

**en-Q0211 · Fill the gap**

He will commit suicide ____ he can't see his son.

वह अपने बेटे को नहीं देख पाया तो वह आत्महत्या कर लेगा।

[[English#^en-Q0211-answer|Compare the answer]]
^en-Q0211

**en-Q0212 · Choose the form**

He will commit suicide ____ he can't see his son.

वह अपने बेटे को नहीं देख पाया तो वह आत्महत्या कर लेगा।

Choices: if / unless / provided that

[[English#^en-Q0212-answer|Compare the answer]]
^en-Q0212

**en-Q0213 · Edit the changed sentence**

Nothing happens 【if】 it is preceded by a dream.

कोई सपना देखे बिना कुछ नहीं होता।

[[English#^en-Q0213-answer|Compare the answer]]
^en-Q0213

**en-Q0214 · Build the sentence**

Arrange: Nothing / preceded / by / is / dream. / a / it / unless / happens

कोई सपना देखे बिना कुछ नहीं होता।

[[English#^en-Q0214-answer|Compare the answer]]
^en-Q0214

**en-Q0215 · Write a translation**

Write this in English: माज्याँग मैं केवल कभी-कभार ही खेलती हूँ, क्योंकि अगर आदत लग गई तो सारा समय उसी पर बरबाद कर दूँगी।

[[English#^en-Q0215-answer|Compare the answer]]
^en-Q0215

**en-Q0216 · Explain the grammar**

I play mahjong only now and then, because 【if】 I made a habit of it, I'd end up wasting all my time on it.

माज्याँग मैं केवल कभी-कभार ही खेलती हूँ, क्योंकि अगर आदत लग गई तो सारा समय उसी पर बरबाद कर दूँगी।

[[English#^en-Q0216-answer|Compare the answer]]
^en-Q0216

**en-Q0217 · Fill the gap**

____ you do anything at all, do it well.

अगर कुछ करना है तो ढंग से करो।

[[English#^en-Q0217-answer|Compare the answer]]
^en-Q0217

**en-Q0218 · Choose the form**

____ you do anything at all, do it well.

अगर कुछ करना है तो ढंग से करो।

Choices: unless / provided that / If

[[English#^en-Q0218-answer|Compare the answer]]
^en-Q0218

**en-Q0219 · Edit the changed sentence**

【unless】 Tom doesn't help us, we'll never be able to finish this on time.

अगर टॉम हमारी मदद नहीं करेगा तो हम ये समय पर कभी नहीं कर पायेंगे।

[[English#^en-Q0219-answer|Compare the answer]]
^en-Q0219

**en-Q0220 · Build the sentence**

Arrange: finish / help / doesn't / be / time. / never / we'll / to / able / this / us, / If / Tom / on

अगर टॉम हमारी मदद नहीं करेगा तो हम ये समय पर कभी नहीं कर पायेंगे।

[[English#^en-Q0220-answer|Compare the answer]]
^en-Q0220

**en-Q0221 · Write a translation**

Write this in English: अगर तुम कानून तोड़ोगे तो तुम्हे सज़ा मिलेगी।

[[English#^en-Q0221-answer|Compare the answer]]
^en-Q0221

**en-Q0222 · Explain the grammar**

You'll be punished 【if】 you break the law.

अगर तुम कानून तोड़ोगे तो तुम्हे सज़ा मिलेगी।

[[English#^en-Q0222-answer|Compare the answer]]
^en-Q0222

**en-Q0223 · Fill the gap**

The way I see it, ____ you want the rainbow, you gotta put up with the rain.

मेरे विचार से यदि आप इन्द्रधनुष चाहते हैं, तो आपको वर्षा को सहना होगा।

[[English#^en-Q0223-answer|Compare the answer]]
^en-Q0223

**en-Q0224 · Choose the form**

The way I see it, ____ you want the rainbow, you gotta put up with the rain.

मेरे विचार से यदि आप इन्द्रधनुष चाहते हैं, तो आपको वर्षा को सहना होगा।

Choices: provided that / unless / if

[[English#^en-Q0224-answer|Compare the answer]]
^en-Q0224

**en-Q0225 · Edit the changed sentence**

I don't know 【unless】 I'll have time to do it.

मुझे नहीं पता मेरे पास यह करने के लिए समय होगा कि नहीं।

[[English#^en-Q0225-answer|Compare the answer]]
^en-Q0225

**en-Q0226 · Build the sentence**

Arrange: if / I'll / it. / to / have / time / don't / do / I / know

मुझे नहीं पता मेरे पास यह करने के लिए समय होगा कि नहीं।

[[English#^en-Q0226-answer|Compare the answer]]
^en-Q0226

**en-Q0227 · Write a translation**

Write this in English: उस सूपरमार्केट में तुम लगभग कोई भी रोजाने में इस्तेमाल होने वाला सामान ख़रीद सकते हो।

[[English#^en-Q0227-answer|Compare the answer]]
^en-Q0227

**en-Q0228 · Explain the grammar**

【If】 you go to that supermarket, you can buy most things you use in your daily life.

उस सूपरमार्केट में तुम लगभग कोई भी रोजाने में इस्तेमाल होने वाला सामान ख़रीद सकते हो।

[[English#^en-Q0228-answer|Compare the answer]]
^en-Q0228

**en-Q0229 · Fill the gap**

Tom won't do that ____ you ask him.

जब तक तुम टॉम को नहीं पूछोगे, तब तक वह उसे नहीं करेगा।

[[English#^en-Q0229-answer|Compare the answer]]
^en-Q0229

**en-Q0230 · Choose the form**

Tom won't do that ____ you ask him.

जब तक तुम टॉम को नहीं पूछोगे, तब तक वह उसे नहीं करेगा।

Choices: if / provided that / unless

[[English#^en-Q0230-answer|Compare the answer]]
^en-Q0230

**en-Q0231 · Edit the changed sentence**

Tom won't do that even 【unless】 you ask him.

यदि तुम उसे पूछो तो भी टॉम उसे नहीं करेगा।

[[English#^en-Q0231-answer|Compare the answer]]
^en-Q0231

**en-Q0232 · Build the sentence**

Arrange: you / that / if / won't / Tom / ask / even / him. / do

यदि तुम उसे पूछो तो भी टॉम उसे नहीं करेगा।

[[English#^en-Q0232-answer|Compare the answer]]
^en-Q0232

**en-Q0233 · Write a translation**

Write this in English: कैंसर का अगर समय में पता चल जाए, तो उसका इलाज हो सकता है।

[[English#^en-Q0233-answer|Compare the answer]]
^en-Q0233

**en-Q0234 · Explain the grammar**

Cancer can be cured 【if】 discovered in time.

कैंसर का अगर समय में पता चल जाए, तो उसका इलाज हो सकता है।

[[English#^en-Q0234-answer|Compare the answer]]
^en-Q0234

**en-Q0235 · Fill the gap**

____ I want to go, I'll let you know.

यदि मैने जाना हुआ तो आपको बता दूँगी।

[[English#^en-Q0235-answer|Compare the answer]]
^en-Q0235

**en-Q0236 · Choose the form**

____ I want to go, I'll let you know.

यदि मैने जाना हुआ तो आपको बता दूँगी।

Choices: unless / provided that / If

[[English#^en-Q0236-answer|Compare the answer]]
^en-Q0236

**en-Q0237 · Edit the changed sentence**

So what 【unless】 I am gay? Is it a crime?

तो क्या अगर मैं गे हूँ? कोई अपराध है क्या?

[[English#^en-Q0237-answer|Compare the answer]]
^en-Q0237

**en-Q0238 · Build the sentence**

Arrange: it / if / Is / So / gay? / a / I / am / crime? / what

तो क्या अगर मैं गे हूँ? कोई अपराध है क्या?

[[English#^en-Q0238-answer|Compare the answer]]
^en-Q0238

**en-Q0239 · Write a translation**

Write this in English: अगर लम्बी ज़िन्दगी जीना चाहते हो तो सिगरेट पीना छोड़ दो।

[[English#^en-Q0239-answer|Compare the answer]]
^en-Q0239

**en-Q0240 · Explain the grammar**

Give up smoking 【if】 you want to live long.

अगर लम्बी ज़िन्दगी जीना चाहते हो तो सिगरेट पीना छोड़ दो।

[[English#^en-Q0240-answer|Compare the answer]]
^en-Q0240

**en-Q0241 · Fill the gap**

____ I had wings, I would fly to you.

अगर मेरे पास पंख होते तो मैं उड़कर तुम्हारे पास चला आता।

[[English#^en-Q0241-answer|Compare the answer]]
^en-Q0241

**en-Q0242 · Choose the form**

____ I had wings, I would fly to you.

अगर मेरे पास पंख होते तो मैं उड़कर तुम्हारे पास चला आता।

Choices: unless / If / provided that

[[English#^en-Q0242-answer|Compare the answer]]
^en-Q0242

**en-Q0243 · Edit the changed sentence**

【unless】 you help me learn English, I'll help you learn Japanese.

अगर तुम ने मेरी अंग्रेज़ी सीखने में मदद की तो में तुम्हारी जापानी सीखने में मदद करूँगा।

[[English#^en-Q0243-answer|Compare the answer]]
^en-Q0243

**en-Q0244 · Build the sentence**

Arrange: you / learn / help / English, / learn / If / you / me / Japanese. / help / I'll

अगर तुम ने मेरी अंग्रेज़ी सीखने में मदद की तो में तुम्हारी जापानी सीखने में मदद करूँगा।

[[English#^en-Q0244-answer|Compare the answer]]
^en-Q0244

**en-Q0245 · Write a translation**

Write this in English: उसने मुझसे एक एहसान माँगा।

[[English#^en-Q0245-answer|Compare the answer]]
^en-Q0245

**en-Q0246 · Explain the grammar**

He asked me 【if】 I could do him a favor.

उसने मुझसे एक एहसान माँगा।

[[English#^en-Q0246-answer|Compare the answer]]
^en-Q0246


### Negative and restrictive emphasis · 50 questions

**en-Q0247 · Fill the gap**

The capital of Himachal Pradesh, Shimla, is ____ 115 kilometres away from Chandigarh.

हिमाचल प्रदेश की राजधानी, शिमला, चण्डीगढ़ से केवल ११५ किलोमीटर की दूरी पर है।

[[English#^en-Q0247-answer|Compare the answer]]
^en-Q0247

**en-Q0248 · Choose the form**

The capital of Himachal Pradesh, Shimla, is ____ 115 kilometres away from Chandigarh.

हिमाचल प्रदेश की राजधानी, शिमला, चण्डीगढ़ से केवल ११५ किलोमीटर की दूरी पर है।

Choices: rarely / hardly / never / only

[[English#^en-Q0248-answer|Compare the answer]]
^en-Q0248

**en-Q0249 · Edit the changed sentence**

No matter what happens, I will 【rarely】 betray my friend.

चाहे जो भी हो, मैं कभी भी अपने दोस्त को धोखा नहीं दूँगा।

[[English#^en-Q0249-answer|Compare the answer]]
^en-Q0249

**en-Q0250 · Build the sentence**

Arrange: No / matter / what / never / betray / happens, / will / I / my / friend.

चाहे जो भी हो, मैं कभी भी अपने दोस्त को धोखा नहीं दूँगा।

[[English#^en-Q0250-answer|Compare the answer]]
^en-Q0250

**en-Q0251 · Write a translation**

Write this in English: वह कभी अपनी ग़लती नहीं मानेगा।

[[English#^en-Q0251-answer|Compare the answer]]
^en-Q0251

**en-Q0252 · Explain the grammar**

He'll 【never】 admit to being in the wrong.

वह कभी अपनी ग़लती नहीं मानेगा।

[[English#^en-Q0252-answer|Compare the answer]]
^en-Q0252

**en-Q0253 · Fill the gap**

The spaceship was ____ to return to the earth.

वह हवाई जहाज़ पृथ्वीपर वापस लौटनेवाला नहीं था.

[[English#^en-Q0253-answer|Compare the answer]]
^en-Q0253

**en-Q0254 · Choose the form**

The spaceship was ____ to return to the earth.

वह हवाई जहाज़ पृथ्वीपर वापस लौटनेवाला नहीं था.

Choices: hardly / rarely / only / never

[[English#^en-Q0254-answer|Compare the answer]]
^en-Q0254

**en-Q0255 · Edit the changed sentence**

I've 【rarely】 met him, but I recognize him.

मैं उसे पहचानता हूँ पर मैं उससे कभी मिला नहीं हूँ।

[[English#^en-Q0255-answer|Compare the answer]]
^en-Q0255

**en-Q0256 · Build the sentence**

Arrange: but / never / met / him. / I / I've / recognize / him,

मैं उसे पहचानता हूँ पर मैं उससे कभी मिला नहीं हूँ।

[[English#^en-Q0256-answer|Compare the answer]]
^en-Q0256

**en-Q0257 · Write a translation**

Write this in English: ख़ुद डूब कर पत्थर दूसरे को डुबो देता है।

[[English#^en-Q0257-answer|Compare the answer]]
^en-Q0257

**en-Q0258 · Explain the grammar**

Not 【only】 does a rock drown, but it drowns others with it.

ख़ुद डूब कर पत्थर दूसरे को डुबो देता है।

[[English#^en-Q0258-answer|Compare the answer]]
^en-Q0258

**en-Q0259 · Fill the gap**

The pulao with meat is eight yuan. The vegetarian pulao is ____ four yuan.

मांस वाला पुलाव आठ युएन का है। बिना मांस वाला पुलाव केवल चार युएन का है।

[[English#^en-Q0259-answer|Compare the answer]]
^en-Q0259

**en-Q0260 · Choose the form**

The pulao with meat is eight yuan. The vegetarian pulao is ____ four yuan.

मांस वाला पुलाव आठ युएन का है। बिना मांस वाला पुलाव केवल चार युएन का है।

Choices: hardly / never / only / rarely

[[English#^en-Q0260-answer|Compare the answer]]
^en-Q0260

**en-Q0261 · Edit the changed sentence**

He was destined 【rarely】 to meet her again.

उसके नसीब में उससे फिरसे मिलना नहीं लिखा हुआ था।

[[English#^en-Q0261-answer|Compare the answer]]
^en-Q0261

**en-Q0262 · Build the sentence**

Arrange: destined / her / He / again. / meet / was / to / never

उसके नसीब में उससे फिरसे मिलना नहीं लिखा हुआ था।

[[English#^en-Q0262-answer|Compare the answer]]
^en-Q0262

**en-Q0263 · Write a translation**

Write this in English: मैंने पुलाव ही नहीं, बल्कि कबाब भी खाए।

[[English#^en-Q0263-answer|Compare the answer]]
^en-Q0263

**en-Q0264 · Explain the grammar**

Not 【only】 did I eat pulao, but I also ate kebabs.

मैंने पुलाव ही नहीं, बल्कि कबाब भी खाए।

[[English#^en-Q0264-answer|Compare the answer]]
^en-Q0264

**en-Q0265 · Fill the gap**

There are ____ two kind of people in the world.

दुनिया में बस दो तरह के लोग होते हैं।

[[English#^en-Q0265-answer|Compare the answer]]
^en-Q0265

**en-Q0266 · Choose the form**

There are ____ two kind of people in the world.

दुनिया में बस दो तरह के लोग होते हैं।

Choices: rarely / never / only / hardly

[[English#^en-Q0266-answer|Compare the answer]]
^en-Q0266

**en-Q0267 · Edit the changed sentence**

He went to China as a soldier, 【rarely】 to come back.

वह सिपाही के रूप में चीन गया, और कभी लौटकर नहीं आया।

[[English#^en-Q0267-answer|Compare the answer]]
^en-Q0267

**en-Q0268 · Build the sentence**

Arrange: to / back. / a / He / soldier, / to / China / never / come / as / went

वह सिपाही के रूप में चीन गया, और कभी लौटकर नहीं आया।

[[English#^en-Q0268-answer|Compare the answer]]
^en-Q0268

**en-Q0269 · Write a translation**

Write this in English: कुछ लोग, चाहे जितने बूढ़े हो जाएं, उन की सुंदरता नहीं मिटती।

[[English#^en-Q0269-answer|Compare the answer]]
^en-Q0269

**en-Q0270 · Explain the grammar**

Some people, no matter how old they get, 【never】 lose their beauty.

कुछ लोग, चाहे जितने बूढ़े हो जाएं, उन की सुंदरता नहीं मिटती।

[[English#^en-Q0270-answer|Compare the answer]]
^en-Q0270

**en-Q0271 · Fill the gap**

We should not fret for what is past, nor should we be anxious about the future; men of discernment deal ____ with the present moment.

हमें न अतीत पर कुढ़ना चाहिए और न ही हमें भविष्य के बारे में चिंतित होना चाहिए; विवेकी व्यक्ति केवल वर्तमान क्षण में ही जीते हैं।

[[English#^en-Q0271-answer|Compare the answer]]
^en-Q0271

**en-Q0272 · Choose the form**

We should not fret for what is past, nor should we be anxious about the future; men of discernment deal ____ with the present moment.

हमें न अतीत पर कुढ़ना चाहिए और न ही हमें भविष्य के बारे में चिंतित होना चाहिए; विवेकी व्यक्ति केवल वर्तमान क्षण में ही जीते हैं।

Choices: only / never / hardly / rarely

[[English#^en-Q0272-answer|Compare the answer]]
^en-Q0272

**en-Q0273 · Edit the changed sentence**

I had 【never】 reached the school when the bell rang.

मैं बस स्कूल पहुँचा ही था कि घंटी बज गई।

[[English#^en-Q0273-answer|Compare the answer]]
^en-Q0273

**en-Q0274 · Build the sentence**

Arrange: when / the / bell / the / I / hardly / rang. / school / had / reached

मैं बस स्कूल पहुँचा ही था कि घंटी बज गई।

[[English#^en-Q0274-answer|Compare the answer]]
^en-Q0274

**en-Q0275 · Write a translation**

Write this in English: मैं दुनिया में किसी भी चीज़ के लिए अपने दोस्त को धोखा नहीं दूँगा।

[[English#^en-Q0275-answer|Compare the answer]]
^en-Q0275

**en-Q0276 · Explain the grammar**

I will 【never】 sell my friend down the river for anything in the world.

मैं दुनिया में किसी भी चीज़ के लिए अपने दोस्त को धोखा नहीं दूँगा।

[[English#^en-Q0276-answer|Compare the answer]]
^en-Q0276

**en-Q0277 · Fill the gap**

Not ____ did I eat pilaf, but I also ate kebabs.

मैंने पुलाव ही नहीं, बल्कि कबाब भी खाए।

[[English#^en-Q0277-answer|Compare the answer]]
^en-Q0277

**en-Q0278 · Choose the form**

Not ____ did I eat pilaf, but I also ate kebabs.

मैंने पुलाव ही नहीं, बल्कि कबाब भी खाए।

Choices: only / rarely / hardly / never

[[English#^en-Q0278-answer|Compare the answer]]
^en-Q0278

**en-Q0279 · Edit the changed sentence**

You have 【never】 to study hard, and you will pass the test.

तुम्हें टेस्ट पास करने के लिए बस मन लगाकर पढ़ना होगा।

[[English#^en-Q0279-answer|Compare the answer]]
^en-Q0279

**en-Q0280 · Build the sentence**

Arrange: and / study / to / You / will / only / you / have / the / test. / pass / hard,

तुम्हें टेस्ट पास करने के लिए बस मन लगाकर पढ़ना होगा।

[[English#^en-Q0280-answer|Compare the answer]]
^en-Q0280

**en-Q0281 · Write a translation**

Write this in English: इतने अड़ियल व्यक्ति से मेरी कभी भी मुलाकात नहीं हुई है।

[[English#^en-Q0281-answer|Compare the answer]]
^en-Q0281

**en-Q0282 · Explain the grammar**

I have 【never】 come across such a stubborn person.

इतने अड़ियल व्यक्ति से मेरी कभी भी मुलाकात नहीं हुई है।

[[English#^en-Q0282-answer|Compare the answer]]
^en-Q0282

**en-Q0283 · Fill the gap**

I know her by sight, but I've ____ spoken to her.

मैं उसे पहचानता हूँ पर मैंने उससे कभी बात नहीं करी है।

[[English#^en-Q0283-answer|Compare the answer]]
^en-Q0283

**en-Q0284 · Choose the form**

I know her by sight, but I've ____ spoken to her.

मैं उसे पहचानता हूँ पर मैंने उससे कभी बात नहीं करी है।

Choices: hardly / rarely / only / never

[[English#^en-Q0284-answer|Compare the answer]]
^en-Q0284

**en-Q0285 · Edit the changed sentence**

I'm 【never】 doing this for your own good.

मैं यह बस तुम्हारे ही भले के लिये कर रहा हूं।

[[English#^en-Q0285-answer|Compare the answer]]
^en-Q0285

**en-Q0286 · Build the sentence**

Arrange: own / only / I'm / doing / for / good. / this / your

मैं यह बस तुम्हारे ही भले के लिये कर रहा हूं।

[[English#^en-Q0286-answer|Compare the answer]]
^en-Q0286

**en-Q0287 · Write a translation**

Write this in English: सबसे काली गाय भी सफ़ेद दूध ही देती।

[[English#^en-Q0287-answer|Compare the answer]]
^en-Q0287

**en-Q0288 · Explain the grammar**

Even the blackest cow 【only】 gives white milk.

सबसे काली गाय भी सफ़ेद दूध ही देती।

[[English#^en-Q0288-answer|Compare the answer]]
^en-Q0288

**en-Q0289 · Fill the gap**

He likes not ____ music but sports as well.

संगीत के अलावा उसे खेल भी पसंद है।

[[English#^en-Q0289-answer|Compare the answer]]
^en-Q0289

**en-Q0290 · Choose the form**

He likes not ____ music but sports as well.

संगीत के अलावा उसे खेल भी पसंद है।

Choices: rarely / never / only / hardly

[[English#^en-Q0290-answer|Compare the answer]]
^en-Q0290

**en-Q0291 · Edit the changed sentence**

I had 【rarely】 seen her before that time.

मैंने उसे पहले कभी नहीं देखा था।

[[English#^en-Q0291-answer|Compare the answer]]
^en-Q0291

**en-Q0292 · Build the sentence**

Arrange: her / before / never / seen / that / had / time. / I

मैंने उसे पहले कभी नहीं देखा था।

[[English#^en-Q0292-answer|Compare the answer]]
^en-Q0292

**en-Q0293 · Write a translation**

Write this in English: उसको एक ही काम से दिलचस्पी है, और वह है पैसा इकट्ठा करना।

[[English#^en-Q0293-answer|Compare the answer]]
^en-Q0293

**en-Q0294 · Explain the grammar**

Her 【only】 interest is the accumulation of money.

उसको एक ही काम से दिलचस्पी है, और वह है पैसा इकट्ठा करना।

[[English#^en-Q0294-answer|Compare the answer]]
^en-Q0294

**en-Q0295 · Fill the gap**

Anger is ____ without a reason, but seldom with a good one.

क्रोध कभी भी बिना कारण नहीं होता, लेकिन कदाचित ही यह कारण सार्थक होता है।

[[English#^en-Q0295-answer|Compare the answer]]
^en-Q0295

**en-Q0296 · Choose the form**

Anger is ____ without a reason, but seldom with a good one.

क्रोध कभी भी बिना कारण नहीं होता, लेकिन कदाचित ही यह कारण सार्थक होता है।

Choices: never / only / hardly / rarely

[[English#^en-Q0296-answer|Compare the answer]]
^en-Q0296


### Cleft and focus structures · 50 questions

**en-Q0297 · Edit the changed sentence**

【what】 the window that Tom broke yesterday.

वह वह खिड़की है जिसको टॉम ने कल थोड़ा था।

[[English#^en-Q0297-answer|Compare the answer]]
^en-Q0297

**en-Q0298 · Build the sentence**

Arrange: yesterday. / that / was / the / Tom / broke / It / window

वह वह खिड़की है जिसको टॉम ने कल थोड़ा था।

[[English#^en-Q0298-answer|Compare the answer]]
^en-Q0298

**en-Q0299 · Write a translation**

Write this in English: तुम और टौम पडछत्ती पर क्या कर रहे थे?

[[English#^en-Q0299-answer|Compare the answer]]
^en-Q0299

**en-Q0300 · Explain the grammar**

【What】 were you and Tom doing in the attic?

तुम और टौम पडछत्ती पर क्या कर रहे थे?

[[English#^en-Q0300-answer|Compare the answer]]
^en-Q0300

**en-Q0301 · Fill the gap**

____ he did was nothing less than madness.

उसने जो किया वह पागलपन से कुछ कम नहीं था।

[[English#^en-Q0301-answer|Compare the answer]]
^en-Q0301

**en-Q0302 · Choose the form**

____ he did was nothing less than madness.

उसने जो किया वह पागलपन से कुछ कम नहीं था।

Choices: What / it is / it was

[[English#^en-Q0302-answer|Compare the answer]]
^en-Q0302

**en-Q0303 · Edit the changed sentence**

Almost everything you do will seem insignificant, but 【what】 important that you do it.

आप का कोई भी काम महत्वहीन हो सकता है, किंतु महत्वपूर्ण तो यह है कि आप कुछ करें।

[[English#^en-Q0303-answer|Compare the answer]]
^en-Q0303

**en-Q0304 · Build the sentence**

Arrange: that / it. / it / Almost / you / is / insignificant, / everything / will / important / do / you / do / seem / but

आप का कोई भी काम महत्वहीन हो सकता है, किंतु महत्वपूर्ण तो यह है कि आप कुछ करें।

[[English#^en-Q0304-answer|Compare the answer]]
^en-Q0304

**en-Q0305 · Write a translation**

Write this in English: दीवारें इंसानों को नहीं बचातीं, बल्कि इंसान दीवारों को बचाते हैं.

[[English#^en-Q0305-answer|Compare the answer]]
^en-Q0305

**en-Q0306 · Explain the grammar**

【It is】 not walls that protect men but men that protect walls.

दीवारें इंसानों को नहीं बचातीं, बल्कि इंसान दीवारों को बचाते हैं.

[[English#^en-Q0306-answer|Compare the answer]]
^en-Q0306

**en-Q0307 · Fill the gap**

____ is it you want to ask me?

तुम मुझसे क्या पूछना चाहते हो?

[[English#^en-Q0307-answer|Compare the answer]]
^en-Q0307

**en-Q0308 · Choose the form**

____ is it you want to ask me?

तुम मुझसे क्या पूछना चाहते हो?

Choices: it is / What / it was

[[English#^en-Q0308-answer|Compare the answer]]
^en-Q0308

**en-Q0309 · Edit the changed sentence**

【it was】 are you going to do with this car?

तुम इस गाड़ी के साथ क्या करने वाले हो?

[[English#^en-Q0309-answer|Compare the answer]]
^en-Q0309

**en-Q0310 · Build the sentence**

Arrange: What / do / with / going / to / this / car? / you / are

तुम इस गाड़ी के साथ क्या करने वाले हो?

[[English#^en-Q0310-answer|Compare the answer]]
^en-Q0310

**en-Q0311 · Write a translation**

Write this in English: कहा जाता है कि वह दुनिया में सबसे अमीर आदमी है।

[[English#^en-Q0311-answer|Compare the answer]]
^en-Q0311

**en-Q0312 · Explain the grammar**

【It is】 said that he is the richest man in the world.

कहा जाता है कि वह दुनिया में सबसे अमीर आदमी है।

[[English#^en-Q0312-answer|Compare the answer]]
^en-Q0312

**en-Q0313 · Fill the gap**

____ time does your watch say it is now?

तुम्हारी घड़ी अब क्या समय बता रही है?

[[English#^en-Q0313-answer|Compare the answer]]
^en-Q0313

**en-Q0314 · Choose the form**

____ time does your watch say it is now?

तुम्हारी घड़ी अब क्या समय बता रही है?

Choices: What / it is / it was

[[English#^en-Q0314-answer|Compare the answer]]
^en-Q0314

**en-Q0315 · Edit the changed sentence**

【what】 said that she is a good cook.

कहते हैं की वह अच्छी बावर्ची है।

[[English#^en-Q0315-answer|Compare the answer]]
^en-Q0315

**en-Q0316 · Build the sentence**

Arrange: good / cook. / is / said / a / is / It / she / that

कहते हैं की वह अच्छी बावर्ची है।

[[English#^en-Q0316-answer|Compare the answer]]
^en-Q0316

**en-Q0317 · Write a translation**

Write this in English: तुम कल रात ९ बजे क्या कर रहे थे?

[[English#^en-Q0317-answer|Compare the answer]]
^en-Q0317

**en-Q0318 · Explain the grammar**

【What】 were you doing at 9 o'clock last night?

तुम कल रात ९ बजे क्या कर रहे थे?

[[English#^en-Q0318-answer|Compare the answer]]
^en-Q0318

**en-Q0319 · Fill the gap**

____ are you going to do with this money?

तुम इन पैसों के साथ क्या करोगे?

[[English#^en-Q0319-answer|Compare the answer]]
^en-Q0319

**en-Q0320 · Choose the form**

____ are you going to do with this money?

तुम इन पैसों के साथ क्या करोगे?

Choices: it is / What / it was

[[English#^en-Q0320-answer|Compare the answer]]
^en-Q0320

**en-Q0321 · Edit the changed sentence**

【it was】 we are seeking so frantically elsewhere may turn out to be the horse we have been riding all along.

हम जिस चीज़ की तलाश कहीं और कर रहे होते हैं वह हो सकता है कि हमारे पास ही हो।

[[English#^en-Q0321-answer|Compare the answer]]
^en-Q0321

**en-Q0322 · Build the sentence**

Arrange: have / be / turn / frantically / are / horse / seeking / out / we / What / may / to / we / elsewhere / the / so / all / along. / riding / been

हम जिस चीज़ की तलाश कहीं और कर रहे होते हैं वह हो सकता है कि हमारे पास ही हो।

[[English#^en-Q0322-answer|Compare the answer]]
^en-Q0322

**en-Q0323 · Write a translation**

Write this in English: उसके दिए गए कारण को समझना मुश्किल है।

[[English#^en-Q0323-answer|Compare the answer]]
^en-Q0323

**en-Q0324 · Explain the grammar**

【The reason】 which he gave is hard to understand.

उसके दिए गए कारण को समझना मुश्किल है।

[[English#^en-Q0324-answer|Compare the answer]]
^en-Q0324

**en-Q0325 · Fill the gap**

____ definite that he will go to America.

कि वह अम्रीका जाएगा, यह तो पक्का है।

[[English#^en-Q0325-answer|Compare the answer]]
^en-Q0325

**en-Q0326 · Choose the form**

____ definite that he will go to America.

कि वह अम्रीका जाएगा, यह तो पक्का है।

Choices: what / it was / It is

[[English#^en-Q0326-answer|Compare the answer]]
^en-Q0326

**en-Q0327 · Edit the changed sentence**

【what】 my brother that made the mistake.

वह ग़लती मेरे भ्राता की थी.

[[English#^en-Q0327-answer|Compare the answer]]
^en-Q0327

**en-Q0328 · Build the sentence**

Arrange: It / the / made / brother / my / mistake. / that / was

वह ग़लती मेरे भ्राता की थी.

[[English#^en-Q0328-answer|Compare the answer]]
^en-Q0328

**en-Q0329 · Write a translation**

Write this in English: कहा जाता है कि औरतों की उम्र आदमियों से ज़्यादा लम्बी होती है।

[[English#^en-Q0329-answer|Compare the answer]]
^en-Q0329

**en-Q0330 · Explain the grammar**

【It is】 said that women live longer than men.

कहा जाता है कि औरतों की उम्र आदमियों से ज़्यादा लम्बी होती है।

[[English#^en-Q0330-answer|Compare the answer]]
^en-Q0330

**en-Q0331 · Fill the gap**

____ for declaring war is not certain.

जंग के ऐलान का कारण साफ़ नहीं है।

[[English#^en-Q0331-answer|Compare the answer]]
^en-Q0331

**en-Q0332 · Choose the form**

____ for declaring war is not certain.

जंग के ऐलान का कारण साफ़ नहीं है।

Choices: it was / what / it is / The reason

[[English#^en-Q0332-answer|Compare the answer]]
^en-Q0332

**en-Q0333 · Edit the changed sentence**

【what】 cold that day, and moreover it began to rain.

उस दिन ठंड थी, और ऊपर से बारिश होने लगी।

[[English#^en-Q0333-answer|Compare the answer]]
^en-Q0333

**en-Q0334 · Build the sentence**

Arrange: it / day, / that / moreover / was / and / to / rain. / cold / It / began

उस दिन ठंड थी, और ऊपर से बारिश होने लगी।

[[English#^en-Q0334-answer|Compare the answer]]
^en-Q0334

**en-Q0335 · Write a translation**

Write this in English: आपने क्या कहा? माफ़ करें, मैं सोच में डूबा था इसलिए मैंने सुना नहीं।

[[English#^en-Q0335-answer|Compare the answer]]
^en-Q0335

**en-Q0336 · Explain the grammar**

【What】 did you say? I'm sorry, I was lost in thought.

आपने क्या कहा? माफ़ करें, मैं सोच में डूबा था इसलिए मैंने सुना नहीं।

[[English#^en-Q0336-answer|Compare the answer]]
^en-Q0336

**en-Q0337 · Fill the gap**

____ necessary that she should go herself.

उसका अकेला जाना ज़रूरी है।

[[English#^en-Q0337-answer|Compare the answer]]
^en-Q0337

**en-Q0338 · Choose the form**

____ necessary that she should go herself.

उसका अकेला जाना ज़रूरी है।

Choices: what / It is / it was

[[English#^en-Q0338-answer|Compare the answer]]
^en-Q0338

**en-Q0339 · Edit the changed sentence**

【what】 why you failed is you did not try hard enough.

तुम नाकामयाब इसलिए रहे क्योंकि तुमने पूरी तरह मेहनत नहीं लगाई।

[[English#^en-Q0339-answer|Compare the answer]]
^en-Q0339

**en-Q0340 · Build the sentence**

Arrange: did / you / not / reason / hard / is / try / failed / why / enough. / you / The

तुम नाकामयाब इसलिए रहे क्योंकि तुमने पूरी तरह मेहनत नहीं लगाई।

[[English#^en-Q0340-answer|Compare the answer]]
^en-Q0340

**en-Q0341 · Write a translation**

Write this in English: इतना शोर था कि किसी को भी मेरी आवाज़ सुनाई नहीं दे रही थी।

[[English#^en-Q0341-answer|Compare the answer]]
^en-Q0341

**en-Q0342 · Explain the grammar**

【It was】 so noisy that I couldn't make myself heard.

इतना शोर था कि किसी को भी मेरी आवाज़ सुनाई नहीं दे रही थी।

[[English#^en-Q0342-answer|Compare the answer]]
^en-Q0342

**en-Q0343 · Fill the gap**

____ not the man who has too little, but the man who craves more, that is poor.

वह व्यक्ति ग़रीब नहीं है जिस के पास थोड़ा बहुत ही है। ग़रीब तो वह है जो ज़्यादा के लिए मरा जा रहा है।

[[English#^en-Q0343-answer|Compare the answer]]
^en-Q0343

**en-Q0344 · Choose the form**

____ not the man who has too little, but the man who craves more, that is poor.

वह व्यक्ति ग़रीब नहीं है जिस के पास थोड़ा बहुत ही है। ग़रीब तो वह है जो ज़्यादा के लिए मरा जा रहा है।

Choices: It is / what / it was

[[English#^en-Q0344-answer|Compare the answer]]
^en-Q0344

**en-Q0345 · Edit the changed sentence**

【what】 often said that the best way to learn a foreign language is to go to the country where it is spoken.

अक्सर कहा जाता है कि किसी भी विदेशी भाषा को सीखने का सबसे अच्छा तरीका उस देश में जाकर रहना होता है।

[[English#^en-Q0345-answer|Compare the answer]]
^en-Q0345

**en-Q0346 · Build the sentence**

Arrange: country / it / to / a / to / that / is / learn / spoken. / is / the / said / language / the / foreign / way / to / It / best / where / go / is / often

अक्सर कहा जाता है कि किसी भी विदेशी भाषा को सीखने का सबसे अच्छा तरीका उस देश में जाकर रहना होता है।

[[English#^en-Q0346-answer|Compare the answer]]
^en-Q0346


### Relative clauses · 50 questions

**en-Q0347 · Write a translation**

Write this in English: जिन यात्रियों को दुर्घटना मे चोट आई थी उन्हे अस्पताल ले जाया गया।

[[English#^en-Q0347-answer|Compare the answer]]
^en-Q0347

**en-Q0348 · Explain the grammar**

The passengers 【who】 were injured in the accident were taken to the nearest hospital.

जिन यात्रियों को दुर्घटना मे चोट आई थी उन्हे अस्पताल ले जाया गया।

[[English#^en-Q0348-answer|Compare the answer]]
^en-Q0348

**en-Q0349 · Fill the gap**

Mother Teresa was a Catholic nun ____ lived and worked in Calcutta, India.

मदर टेरेसा एक कैथोलिक नन थीं जो कलकत्ता में रहतीं और काम करतीं थीं।

[[English#^en-Q0349-answer|Compare the answer]]
^en-Q0349

**en-Q0350 · Choose the form**

Mother Teresa was a Catholic nun ____ lived and worked in Calcutta, India.

मदर टेरेसा एक कैथोलिक नन थीं जो कलकत्ता में रहतीं और काम करतीं थीं।

Choices: whose / which / whom / who

[[English#^en-Q0350-answer|Compare the answer]]
^en-Q0350

**en-Q0351 · Edit the changed sentence**

I know a girl 【whom】 can ride a unicycle.

मेरे जान-पहचान की एक लड़की को युनिसायकल चलाना आता है।

[[English#^en-Q0351-answer|Compare the answer]]
^en-Q0351

**en-Q0352 · Build the sentence**

Arrange: girl / ride / unicycle. / who / a / can / a / know / I

मेरे जान-पहचान की एक लड़की को युनिसायकल चलाना आता है।

[[English#^en-Q0352-answer|Compare the answer]]
^en-Q0352

**en-Q0353 · Write a translation**

Write this in English: बेकरी में काम करनेवाली वह लड़की प्यारी है।

[[English#^en-Q0353-answer|Compare the answer]]
^en-Q0353

**en-Q0354 · Explain the grammar**

The girl 【who】 works at that bakery is cute.

बेकरी में काम करनेवाली वह लड़की प्यारी है।

[[English#^en-Q0354-answer|Compare the answer]]
^en-Q0354

**en-Q0355 · Fill the gap**

I have an uncle ____ lives in Kyoto.

मेरे क्योतो में रहने वाले एक चाचा हैं।

[[English#^en-Q0355-answer|Compare the answer]]
^en-Q0355

**en-Q0356 · Choose the form**

I have an uncle ____ lives in Kyoto.

मेरे क्योतो में रहने वाले एक चाचा हैं।

Choices: who / whose / which / whom

[[English#^en-Q0356-answer|Compare the answer]]
^en-Q0356

**en-Q0357 · Edit the changed sentence**

He 【whom】 starts ten tasks won't finish a single one.

जो दस काम शुरू करता है वह एक भी खत्म नहीं करेगा।

[[English#^en-Q0357-answer|Compare the answer]]
^en-Q0357

**en-Q0358 · Build the sentence**

Arrange: won't / ten / finish / who / one. / a / tasks / starts / He / single

जो दस काम शुरू करता है वह एक भी खत्म नहीं करेगा।

[[English#^en-Q0358-answer|Compare the answer]]
^en-Q0358

**en-Q0359 · Write a translation**

Write this in English: मैं एक ऐसी चीज़ ढूँढ रहा था जिसका अस्तित्व कभी था ही नहीं।

[[English#^en-Q0359-answer|Compare the answer]]
^en-Q0359

**en-Q0360 · Explain the grammar**

I was searching for something 【that】 didn't exist.

मैं एक ऐसी चीज़ ढूँढ रहा था जिसका अस्तित्व कभी था ही नहीं।

[[English#^en-Q0360-answer|Compare the answer]]
^en-Q0360

**en-Q0361 · Fill the gap**

Children ____ parents are dead are referred to as "orphans".

जिन बच्चों के माता-पिता की मृत्यु हो गई होती है उने "अनाथ" बुलाया जाता है।

[[English#^en-Q0361-answer|Compare the answer]]
^en-Q0361

**en-Q0362 · Choose the form**

Children ____ parents are dead are referred to as "orphans".

जिन बच्चों के माता-पिता की मृत्यु हो गई होती है उने "अनाथ" बुलाया जाता है।

Choices: which / whom / whose / who

[[English#^en-Q0362-answer|Compare the answer]]
^en-Q0362

**en-Q0363 · Edit the changed sentence**

John, 【whom】 is the youngest in a family of seven, is the apple of his parents' eyes.

जॉन, जो सात बच्चों के परिवार में सबसे छोटा है, वह अपने माता-पिता के आँखों का तारा है.

[[English#^en-Q0363-answer|Compare the answer]]
^en-Q0363

**en-Q0364 · Build the sentence**

Arrange: in / family / the / a / his / parents' / is / eyes. / of / is / of / youngest / John, / seven, / the / who / apple

जॉन, जो सात बच्चों के परिवार में सबसे छोटा है, वह अपने माता-पिता के आँखों का तारा है.

[[English#^en-Q0364-answer|Compare the answer]]
^en-Q0364

**en-Q0365 · Write a translation**

Write this in English: कोई परिस्थिति, कोई उद्देश्य, किसी भी प्रकार का कोई कानून, किसी अंतर्निहित रूप से अवैध कार्य को कभी वैध नहीं बना सकता है।

[[English#^en-Q0365-answer|Compare the answer]]
^en-Q0365

**en-Q0366 · Explain the grammar**

No circumstance, no purpose, no law whatsoever can ever make licit an act 【which】 is intrinsically illicit.

कोई परिस्थिति, कोई उद्देश्य, किसी भी प्रकार का कोई कानून, किसी अंतर्निहित रूप से अवैध कार्य को कभी वैध नहीं बना सकता है।

[[English#^en-Q0366-answer|Compare the answer]]
^en-Q0366

**en-Q0367 · Fill the gap**

I have a friend ____ lives in England.

मेरा एक दोस्त है जो इंग्लैंड में रहता है।

[[English#^en-Q0367-answer|Compare the answer]]
^en-Q0367

**en-Q0368 · Choose the form**

I have a friend ____ lives in England.

मेरा एक दोस्त है जो इंग्लैंड में रहता है।

Choices: whom / whose / which / who

[[English#^en-Q0368-answer|Compare the answer]]
^en-Q0368

**en-Q0369 · Edit the changed sentence**

There was a man 【whom】 had three sons.

एक आदमी था जिसके तीन बेटे थे।

[[English#^en-Q0369-answer|Compare the answer]]
^en-Q0369

**en-Q0370 · Build the sentence**

Arrange: was / man / who / three / sons. / a / had / There

एक आदमी था जिसके तीन बेटे थे।

[[English#^en-Q0370-answer|Compare the answer]]
^en-Q0370

**en-Q0371 · Write a translation**

Write this in English: पुलिस को अब तक इस बात की जानकारी नहीं है कि जुर्म किसने किया है।

[[English#^en-Q0371-answer|Compare the answer]]
^en-Q0371

**en-Q0372 · Explain the grammar**

The police still can't point out 【who】 committed the crime.

पुलिस को अब तक इस बात की जानकारी नहीं है कि जुर्म किसने किया है।

[[English#^en-Q0372-answer|Compare the answer]]
^en-Q0372

**en-Q0373 · Fill the gap**

Don't meddle in things ____ are none of your business.

तुम दूसरों के मसलों में अपनी नाक मत घुसाओ।

[[English#^en-Q0373-answer|Compare the answer]]
^en-Q0373

**en-Q0374 · Choose the form**

Don't meddle in things ____ are none of your business.

तुम दूसरों के मसलों में अपनी नाक मत घुसाओ।

Choices: that / who / whose / whom

[[English#^en-Q0374-answer|Compare the answer]]
^en-Q0374

**en-Q0375 · Edit the changed sentence**

I saw a girl 【who】 hair came down to her waist.

मैंने एक लड़की को देखा जिसके बाल उसकी कमर तक आते थे।

[[English#^en-Q0375-answer|Compare the answer]]
^en-Q0375

**en-Q0376 · Build the sentence**

Arrange: girl / waist. / down / came / I / to / her / hair / saw / a / whose

मैंने एक लड़की को देखा जिसके बाल उसकी कमर तक आते थे।

[[English#^en-Q0376-answer|Compare the answer]]
^en-Q0376

**en-Q0377 · Write a translation**

Write this in English: मेरी दो बहनें हैं और दोनो की शादी हो चुकी है।

[[English#^en-Q0377-answer|Compare the answer]]
^en-Q0377

**en-Q0378 · Explain the grammar**

I have two sisters, both of 【whom】 are married.

मेरी दो बहनें हैं और दोनो की शादी हो चुकी है।

[[English#^en-Q0378-answer|Compare the answer]]
^en-Q0378

**en-Q0379 · Fill the gap**

This is the very book ____ I wanted to read.

यह वही किताब है जिसे मैं पढ़ना चाह्ता था।

[[English#^en-Q0379-answer|Compare the answer]]
^en-Q0379

**en-Q0380 · Choose the form**

This is the very book ____ I wanted to read.

यह वही किताब है जिसे मैं पढ़ना चाह्ता था।

Choices: that / who / whom / whose

[[English#^en-Q0380-answer|Compare the answer]]
^en-Q0380

**en-Q0381 · Edit the changed sentence**

The man 【whom】 is standing there is my father.

वहाँ पर खड़े हुए वे मेरे पिता हैं।

[[English#^en-Q0381-answer|Compare the answer]]
^en-Q0381

**en-Q0382 · Build the sentence**

Arrange: my / standing / there / man / who / father. / The / is / is

वहाँ पर खड़े हुए वे मेरे पिता हैं।

[[English#^en-Q0382-answer|Compare the answer]]
^en-Q0382

**en-Q0383 · Write a translation**

Write this in English: असफल व्यक्तियों में से निन्यानवे प्रतिशत वे लोग होते हैं जिन की आदत बहाने बनाने की होती है।

[[English#^en-Q0383-answer|Compare the answer]]
^en-Q0383

**en-Q0384 · Explain the grammar**

Ninety-nine percent of all failures come from people 【who】 have the habit of making excuses.

असफल व्यक्तियों में से निन्यानवे प्रतिशत वे लोग होते हैं जिन की आदत बहाने बनाने की होती है।

[[English#^en-Q0384-answer|Compare the answer]]
^en-Q0384

**en-Q0385 · Fill the gap**

Cross off the names of the people ____ have paid their dues.

जो पैसे भर चुकें हैं, उनके नाम काट दो।

[[English#^en-Q0385-answer|Compare the answer]]
^en-Q0385

**en-Q0386 · Choose the form**

Cross off the names of the people ____ have paid their dues.

जो पैसे भर चुकें हैं, उनके नाम काट दो।

Choices: which / who / whom / whose

[[English#^en-Q0386-answer|Compare the answer]]
^en-Q0386

**en-Q0387 · Edit the changed sentence**

I don't like teachers 【whom】 like students who don't like asking questions.

सवाल पूछना न पसंद करने वाले विद्यार्थियों को पसंद करने वाले शिक्षक मुझे पसंद नहीं।

[[English#^en-Q0387-answer|Compare the answer]]
^en-Q0387

**en-Q0388 · Build the sentence**

Arrange: like / like / students / don't / who / like / I / asking / questions. / who / teachers / don't

सवाल पूछना न पसंद करने वाले विद्यार्थियों को पसंद करने वाले शिक्षक मुझे पसंद नहीं।

[[English#^en-Q0388-answer|Compare the answer]]
^en-Q0388

**en-Q0389 · Write a translation**

Write this in English: मेरी अलमारी में चार पट और दो आईनें हैं. उसको एक स्वीडिश कंपनी ने बनाया है, जिसके नाम में तीन स्वर और एक व्यंजन है.

[[English#^en-Q0389-answer|Compare the answer]]
^en-Q0389

**en-Q0390 · Explain the grammar**

My wardrobe has four doors and two mirrors. It was manufactured by a Swedish company, 【whose】 name contains three vowels and a consonant.

मेरी अलमारी में चार पट और दो आईनें हैं. उसको एक स्वीडिश कंपनी ने बनाया है, जिसके नाम में तीन स्वर और एक व्यंजन है.

[[English#^en-Q0390-answer|Compare the answer]]
^en-Q0390

**en-Q0391 · Fill the gap**

He never takes into account the fact ____ I am very busy.

वह कभी भी इस बात का खयाल नहीं करता है कि मैं कितना व्यस्थ हूँ।

[[English#^en-Q0391-answer|Compare the answer]]
^en-Q0391

**en-Q0392 · Choose the form**

He never takes into account the fact ____ I am very busy.

वह कभी भी इस बात का खयाल नहीं करता है कि मैं कितना व्यस्थ हूँ।

Choices: who / whom / that / whose

[[English#^en-Q0392-answer|Compare the answer]]
^en-Q0392

**en-Q0393 · Edit the changed sentence**

In baseball, the pitcher is the player 【whom】 throws the ball.

बेसबॉल में गेंद फेंकने वाले को "पिचर" कहते है।

[[English#^en-Q0393-answer|Compare the answer]]
^en-Q0393

**en-Q0394 · Build the sentence**

Arrange: the / the / In / is / pitcher / throws / ball. / who / baseball, / the / player

बेसबॉल में गेंद फेंकने वाले को "पिचर" कहते है।

[[English#^en-Q0394-answer|Compare the answer]]
^en-Q0394

**en-Q0395 · Write a translation**

Write this in English: अंग्रेज़ी में समझाया तो चलेगा क्या? जिन्हें अंग्रेज़ी से तकलीफ़ है वो हाथ उठाएँ।

[[English#^en-Q0395-answer|Compare the answer]]
^en-Q0395

**en-Q0396 · Explain the grammar**

Is it fine if I explain in English? Anyone 【who】 wouldn't be comfortable with English, please raise your hand.

अंग्रेज़ी में समझाया तो चलेगा क्या? जिन्हें अंग्रेज़ी से तकलीफ़ है वो हाथ उठाएँ।

[[English#^en-Q0396-answer|Compare the answer]]
^en-Q0396


### Embedded questions · 50 questions

**en-Q0397 · Fill the gap**

I don't know ____ to operate this computer.

मुझे यह कम्प्यूटर चलाना नहीं आता।

[[English#^en-Q0397-answer|Compare the answer]]
^en-Q0397

**en-Q0398 · Choose the form**

I don't know ____ to operate this computer.

मुझे यह कम्प्यूटर चलाना नहीं आता।

Choices: when / whether / why / how

[[English#^en-Q0398-answer|Compare the answer]]
^en-Q0398

**en-Q0399 · Edit the changed sentence**

She's trying to whistle, but she doesn't know 【whether】.

वह सीटी बजाने की कोशिश कर रही है, मगर उसे बजाने नहीं आती।

[[English#^en-Q0399-answer|Compare the answer]]
^en-Q0399

**en-Q0400 · Build the sentence**

Arrange: whistle, / trying / how. / She's / know / she / doesn't / but / to

वह सीटी बजाने की कोशिश कर रही है, मगर उसे बजाने नहीं आती।

[[English#^en-Q0400-answer|Compare the answer]]
^en-Q0400

**en-Q0401 · Write a translation**

Write this in English: टॉम पूछ रहा है कि तुमने उसे कॉल बैक क्यों नहीं किया।

[[English#^en-Q0401-answer|Compare the answer]]
^en-Q0401

**en-Q0402 · Explain the grammar**

Tom wants to know 【why】 you didn't call him back.

टॉम पूछ रहा है कि तुमने उसे कॉल बैक क्यों नहीं किया।

[[English#^en-Q0402-answer|Compare the answer]]
^en-Q0402

**en-Q0403 · Fill the gap**

Can you tell me ____ to switch the machine off?

क्या मुझे बता सकते हो कि मशीन को कब बंद करना है?

[[English#^en-Q0403-answer|Compare the answer]]
^en-Q0403

**en-Q0404 · Choose the form**

Can you tell me ____ to switch the machine off?

क्या मुझे बता सकते हो कि मशीन को कब बंद करना है?

Choices: how / whether / why / when

[[English#^en-Q0404-answer|Compare the answer]]
^en-Q0404

**en-Q0405 · Edit the changed sentence**

But I don't know 【whether】 to cook kebabs!

पर मुझे कबाब पकाना नहीं आता!

[[English#^en-Q0405-answer|Compare the answer]]
^en-Q0405

**en-Q0406 · Build the sentence**

Arrange: cook / kebabs! / But / to / know / I / how / don't

पर मुझे कबाब पकाना नहीं आता!

[[English#^en-Q0406-answer|Compare the answer]]
^en-Q0406

**en-Q0407 · Write a translation**

Write this in English: टॉम अभी तक नहीं जानता कि ऐसा कैसे करना है।

[[English#^en-Q0407-answer|Compare the answer]]
^en-Q0407

**en-Q0408 · Explain the grammar**

Tom doesn't yet know 【how】 to do that.

टॉम अभी तक नहीं जानता कि ऐसा कैसे करना है।

[[English#^en-Q0408-answer|Compare the answer]]
^en-Q0408

**en-Q0409 · Fill the gap**

I will tell him about it ____ he comes next time.

जब वह अगली बार आएगा, मैं उसे इसके बारे में बाताऊँगा।

[[English#^en-Q0409-answer|Compare the answer]]
^en-Q0409

**en-Q0410 · Choose the form**

I will tell him about it ____ he comes next time.

जब वह अगली बार आएगा, मैं उसे इसके बारे में बाताऊँगा।

Choices: whether / why / when / how

[[English#^en-Q0410-answer|Compare the answer]]
^en-Q0410

**en-Q0411 · Edit the changed sentence**

I am not sure 【whether】 to pronounce the word.

मुझे ठीक से नहीं पता इस शब्द को कैसे पढ़ा जाता है।

[[English#^en-Q0411-answer|Compare the answer]]
^en-Q0411

**en-Q0412 · Build the sentence**

Arrange: am / how / pronounce / sure / I / not / word. / the / to

मुझे ठीक से नहीं पता इस शब्द को कैसे पढ़ा जाता है।

[[English#^en-Q0412-answer|Compare the answer]]
^en-Q0412

**en-Q0413 · Write a translation**

Write this in English: क्या आपको कम्प्यूटर का इस्तेमाल करना आता है?

[[English#^en-Q0413-answer|Compare the answer]]
^en-Q0413

**en-Q0414 · Explain the grammar**

Do you know 【how】 to use a computer?

क्या आपको कम्प्यूटर का इस्तेमाल करना आता है?

[[English#^en-Q0414-answer|Compare the answer]]
^en-Q0414

**en-Q0415 · Fill the gap**

Don't ask me ____ but, he ran away when he saw me.

मुझे यह मत पूछना क्यूँ, किन्तु वह मुझे देख कर भाग गया.

[[English#^en-Q0415-answer|Compare the answer]]
^en-Q0415

**en-Q0416 · Choose the form**

Don't ask me ____ but, he ran away when he saw me.

मुझे यह मत पूछना क्यूँ, किन्तु वह मुझे देख कर भाग गया.

Choices: when / why / how / whether

[[English#^en-Q0416-answer|Compare the answer]]
^en-Q0416

**en-Q0417 · Edit the changed sentence**

Tom doesn't know 【whether】 to do that yet.

टॉम अभी तक नहीं जानता कि यह कैसे करना है।

[[English#^en-Q0417-answer|Compare the answer]]
^en-Q0417

**en-Q0418 · Build the sentence**

Arrange: know / to / Tom / how / that / do / yet. / doesn't

टॉम अभी तक नहीं जानता कि यह कैसे करना है।

[[English#^en-Q0418-answer|Compare the answer]]
^en-Q0418

**en-Q0419 · Write a translation**

Write this in English: पता नहीं कैसे पर उसने कर दिया।

[[English#^en-Q0419-answer|Compare the answer]]
^en-Q0419

**en-Q0420 · Explain the grammar**

I don't know 【how】, but she did it.

पता नहीं कैसे पर उसने कर दिया।

[[English#^en-Q0420-answer|Compare the answer]]
^en-Q0420

**en-Q0421 · Fill the gap**

I'm not sure ____ much we should wait.

मुझे नहीं पता हमे कितनी देर इंतेज़ार करना चाहिए।

[[English#^en-Q0421-answer|Compare the answer]]
^en-Q0421

**en-Q0422 · Choose the form**

I'm not sure ____ much we should wait.

मुझे नहीं पता हमे कितनी देर इंतेज़ार करना चाहिए।

Choices: why / whether / how / when

[[English#^en-Q0422-answer|Compare the answer]]
^en-Q0422

**en-Q0423 · Edit the changed sentence**

Do you know 【whether】 to drive a car?

क्या आपको गाड़ी चलाना आता है?

[[English#^en-Q0423-answer|Compare the answer]]
^en-Q0423

**en-Q0424 · Build the sentence**

Arrange: you / a / know / car? / to / how / Do / drive

क्या आपको गाड़ी चलाना आता है?

[[English#^en-Q0424-answer|Compare the answer]]
^en-Q0424

**en-Q0425 · Write a translation**

Write this in English: पता नहीं कैसे पर टॉम ने कर दिया।

[[English#^en-Q0425-answer|Compare the answer]]
^en-Q0425

**en-Q0426 · Explain the grammar**

I don't know 【how】, but Tom did it.

पता नहीं कैसे पर टॉम ने कर दिया।

[[English#^en-Q0426-answer|Compare the answer]]
^en-Q0426

**en-Q0427 · Fill the gap**

Tell me, ____ do you want to do something like this?

बोलो तुम ऐसा क्यों करना चाहते हो।

[[English#^en-Q0427-answer|Compare the answer]]
^en-Q0427

**en-Q0428 · Choose the form**

Tell me, ____ do you want to do something like this?

बोलो तुम ऐसा क्यों करना चाहते हो।

Choices: how / why / when / whether

[[English#^en-Q0428-answer|Compare the answer]]
^en-Q0428

**en-Q0429 · Edit the changed sentence**

I don't know 【whether】 Bob came to Japan.

बॉब जापान कब आया मुझे पता नही।

[[English#^en-Q0429-answer|Compare the answer]]
^en-Q0429

**en-Q0430 · Build the sentence**

Arrange: Bob / to / don't / came / I / when / Japan. / know

बॉब जापान कब आया मुझे पता नही।

[[English#^en-Q0430-answer|Compare the answer]]
^en-Q0430

**en-Q0431 · Write a translation**

Write this in English: जॉन ने मेरी से पूछा कि वह दोपहर में उसके साथ बाज़ार जाना चाह्ती है क्या।

[[English#^en-Q0431-answer|Compare the answer]]
^en-Q0431

**en-Q0432 · Explain the grammar**

John asked Mary 【whether】 she would like to go shopping in the afternoon.

जॉन ने मेरी से पूछा कि वह दोपहर में उसके साथ बाज़ार जाना चाह्ती है क्या।

[[English#^en-Q0432-answer|Compare the answer]]
^en-Q0432

**en-Q0433 · Fill the gap**

Tom didn't know ____ to laugh or cry.

टॉम को सूझ नहीं रहा था के वह हँसे या रोये.

[[English#^en-Q0433-answer|Compare the answer]]
^en-Q0433

**en-Q0434 · Choose the form**

Tom didn't know ____ to laugh or cry.

टॉम को सूझ नहीं रहा था के वह हँसे या रोये.

Choices: when / whether / how / why

[[English#^en-Q0434-answer|Compare the answer]]
^en-Q0434

**en-Q0435 · Edit the changed sentence**

I don't know 【whether】 she will leave for London.

मुझे नहीं पता वह लंदन के लिए रवाना कब होएगी।

[[English#^en-Q0435-answer|Compare the answer]]
^en-Q0435

**en-Q0436 · Build the sentence**

Arrange: she / know / London. / I / when / don't / will / for / leave

मुझे नहीं पता वह लंदन के लिए रवाना कब होएगी।

[[English#^en-Q0436-answer|Compare the answer]]
^en-Q0436

**en-Q0437 · Write a translation**

Write this in English: सोच रही हूँ उसकी दी हुई तस्वीर को कहाँ टाँगा जाए।

[[English#^en-Q0437-answer|Compare the answer]]
^en-Q0437

**en-Q0438 · Explain the grammar**

I wonder 【where】 to hang the picture he gave me.

सोच रही हूँ उसकी दी हुई तस्वीर को कहाँ टाँगा जाए।

[[English#^en-Q0438-answer|Compare the answer]]
^en-Q0438

**en-Q0439 · Fill the gap**

I'll let you know ____ it has been decided.

वो तए किये जाने पर मैं तुम्हे बता दूंगा।

[[English#^en-Q0439-answer|Compare the answer]]
^en-Q0439

**en-Q0440 · Choose the form**

I'll let you know ____ it has been decided.

वो तए किये जाने पर मैं तुम्हे बता दूंगा।

Choices: whether / when / how / why

[[English#^en-Q0440-answer|Compare the answer]]
^en-Q0440

**en-Q0441 · Edit the changed sentence**

Friends are those rare people who ask 【whether】 we are and then wait to hear the answer.

मित्र वे दुर्लभ लोग होते हैं जो हमारा हालचाल पूछते हैं और उत्तर सुनने को रुकते भी हैं।

[[English#^en-Q0441-answer|Compare the answer]]
^en-Q0441

**en-Q0442 · Build the sentence**

Arrange: who / the / Friends / people / and / we / those / are / answer. / ask / rare / how / to / are / then / wait / hear

मित्र वे दुर्लभ लोग होते हैं जो हमारा हालचाल पूछते हैं और उत्तर सुनने को रुकते भी हैं।

[[English#^en-Q0442-answer|Compare the answer]]
^en-Q0442

**en-Q0443 · Write a translation**

Write this in English: सब्ज़ियाँ काटने के बाद वहाँ रख दो। पता नहीं इन्हें कब आ कर पकाऊँगी।

[[English#^en-Q0443-answer|Compare the answer]]
^en-Q0443

**en-Q0444 · Explain the grammar**

After you're done cutting up the vegetables, put them there. Don't know 【when】 I'll be back to cook them.

सब्ज़ियाँ काटने के बाद वहाँ रख दो। पता नहीं इन्हें कब आ कर पकाऊँगी।

[[English#^en-Q0444-answer|Compare the answer]]
^en-Q0444

**en-Q0445 · Fill the gap**

I don't know ____, but you did it.

पता नहीं कैसे पर तुमने कर दिया।

[[English#^en-Q0445-answer|Compare the answer]]
^en-Q0445

**en-Q0446 · Choose the form**

I don't know ____, but you did it.

पता नहीं कैसे पर तुमने कर दिया।

Choices: why / whether / when / how

[[English#^en-Q0446-answer|Compare the answer]]
^en-Q0446


### Concession and limits on claims · 8 questions

**en-Q0447 · Edit the changed sentence**

【despite】 fatalities tend to be rare, many people died as a result of volcanic eruptions during the last quarter century.

घायलो की संख्या कम है पर पिछले सवा सौ वर्षों में ज्वालामुखी विस्फोटो के कारण बहुत लोग मरे है ।

[[English#^en-Q0447-answer|Compare the answer]]
^en-Q0447

**en-Q0448 · Build the sentence**

Arrange: during / eruptions / of / be / fatalities / many / quarter / as / tend / people / rare, / last / century. / Although / to / a / volcanic / died / the / result

घायलो की संख्या कम है पर पिछले सवा सौ वर्षों में ज्वालामुखी विस्फोटो के कारण बहुत लोग मरे है ।

[[English#^en-Q0448-answer|Compare the answer]]
^en-Q0448

**en-Q0449 · Write a translation**

Write this in English: वह अमीर हो कर भी ख़ुश नहीं है।

[[English#^en-Q0449-answer|Compare the answer]]
^en-Q0449

**en-Q0450 · Explain the grammar**

【Though】 he is rich, he is not happy.

वह अमीर हो कर भी ख़ुश नहीं है।

[[English#^en-Q0450-answer|Compare the answer]]
^en-Q0450

**en-Q0451 · Fill the gap**

It is, ____, apposite to note that this process will continue in the year ahead.

तथापि, यह नोट करना उपयुक्त है कि यह प्रक्रिया अगले वर्ष जारी रहेगी।

[[English#^en-Q0451-answer|Compare the answer]]
^en-Q0451

**en-Q0452 · Choose the form**

It is, ____, apposite to note that this process will continue in the year ahead.

तथापि, यह नोट करना उपयुक्त है कि यह प्रक्रिया अगले वर्ष जारी रहेगी।

Choices: although / however / despite

[[English#^en-Q0452-answer|Compare the answer]]
^en-Q0452

**en-Q0453 · Edit the changed sentence**

【despite】 they are twins, they have few interests in common.

वे हालांकि जुड़वा हैं, उनके शोक एक-दूसरे से बहुत अलग हैं।

[[English#^en-Q0453-answer|Compare the answer]]
^en-Q0453

**en-Q0454 · Build the sentence**

Arrange: twins, / in / Although / interests / common. / they / are / they / few / have

वे हालांकि जुड़वा हैं, उनके शोक एक-दूसरे से बहुत अलग हैं।

[[English#^en-Q0454-answer|Compare the answer]]
^en-Q0454


### Cause, purpose and consequence · 50 questions

**en-Q0455 · Write a translation**

Write this in English: मैं जीवन से प्यार करता हूँ क्योंकि और है ही क्या।

[[English#^en-Q0455-answer|Compare the answer]]
^en-Q0455

**en-Q0456 · Explain the grammar**

I love life 【because】 what more is there.

मैं जीवन से प्यार करता हूँ क्योंकि और है ही क्या।

[[English#^en-Q0456-answer|Compare the answer]]
^en-Q0456

**en-Q0457 · Fill the gap**

____ of his advice, I was able to succeed.

मैं उसकी सलाह की वजह से कामयाब हो गया।

[[English#^en-Q0457-answer|Compare the answer]]
^en-Q0457

**en-Q0458 · Choose the form**

____ of his advice, I was able to succeed.

मैं उसकी सलाह की वजह से कामयाब हो गया।

Choices: therefore / Because / so that

[[English#^en-Q0458-answer|Compare the answer]]
^en-Q0458

**en-Q0459 · Edit the changed sentence**

【therefore】 of the rain they had to cancel the game.

बारिश की वजह से उन्हें खेल रद्द करना पड़ा।

[[English#^en-Q0459-answer|Compare the answer]]
^en-Q0459

**en-Q0460 · Build the sentence**

Arrange: had / Because / the / the / game. / cancel / they / to / of / rain

बारिश की वजह से उन्हें खेल रद्द करना पड़ा।

[[English#^en-Q0460-answer|Compare the answer]]
^en-Q0460

**en-Q0461 · Write a translation**

Write this in English: उसकी खिड़की के बाहर इतना शोर हो रहा था कि वह सो नहीं पा रहा था।

[[English#^en-Q0461-answer|Compare the answer]]
^en-Q0461

**en-Q0462 · Explain the grammar**

He couldn't sleep 【because】 of the noise outside his window.

उसकी खिड़की के बाहर इतना शोर हो रहा था कि वह सो नहीं पा रहा था।

[[English#^en-Q0462-answer|Compare the answer]]
^en-Q0462

**en-Q0463 · Fill the gap**

We need to look for a gas station ____ this car will soon run out of gas.

हमे पेट्रोल पम्प ढूँढना चाहिए क्योंकि गाड़ी में पेट्रोल खतम होने वाला है।

[[English#^en-Q0463-answer|Compare the answer]]
^en-Q0463

**en-Q0464 · Choose the form**

We need to look for a gas station ____ this car will soon run out of gas.

हमे पेट्रोल पम्प ढूँढना चाहिए क्योंकि गाड़ी में पेट्रोल खतम होने वाला है।

Choices: therefore / so that / because

[[English#^en-Q0464-answer|Compare the answer]]
^en-Q0464

**en-Q0465 · Edit the changed sentence**

The Indian flag is called the tricolour 【therefore】 it has stripes of three colours – saffron, white and green.

भारत का झंडा तिरंगा कहलाया जाता है क्योंकि उसमें तीन रंगों की पट्टियाँ हैं - केसरी, सफ़ेद और हरा।

[[English#^en-Q0465-answer|Compare the answer]]
^en-Q0465

**en-Q0466 · Build the sentence**

Arrange: has / the / is / Indian / – / tricolour / white / called / saffron, / and / The / of / green. / because / flag / it / three / stripes / colours

भारत का झंडा तिरंगा कहलाया जाता है क्योंकि उसमें तीन रंगों की पट्टियाँ हैं - केसरी, सफ़ेद और हरा।

[[English#^en-Q0466-answer|Compare the answer]]
^en-Q0466

**en-Q0467 · Write a translation**

Write this in English: कल रविवार था, तो मैं पूरे दिन सोते रहा।

[[English#^en-Q0467-answer|Compare the answer]]
^en-Q0467

**en-Q0468 · Explain the grammar**

I slept all day yesterday, 【because】 it was Sunday.

कल रविवार था, तो मैं पूरे दिन सोते रहा।

[[English#^en-Q0468-answer|Compare the answer]]
^en-Q0468

**en-Q0469 · Fill the gap**

He finished his dinner ____ he didn't like to waste food.

उसे खाने की बर्बादी करना पसंद नहीं था, तो उसने अपना खाना खाकर खतम किया।

[[English#^en-Q0469-answer|Compare the answer]]
^en-Q0469

**en-Q0470 · Choose the form**

He finished his dinner ____ he didn't like to waste food.

उसे खाने की बर्बादी करना पसंद नहीं था, तो उसने अपना खाना खाकर खतम किया।

Choices: because / so that / therefore

[[English#^en-Q0470-answer|Compare the answer]]
^en-Q0470

**en-Q0471 · Edit the changed sentence**

【because】 happiness doesn't exist, we have to strive to be happy without it.

क्योंकि ख़ुशी का कोई अस्तित्व नहीं है, हमें उसके बिना खुश रहने का प्रयत्न करना चाहिए |

[[English#^en-Q0471-answer|Compare the answer]]
^en-Q0471

**en-Q0472 · Build the sentence**

Arrange: be / doesn't / to / Since / have / without / we / exist, / strive / it. / happy / to / happiness

क्योंकि ख़ुशी का कोई अस्तित्व नहीं है, हमें उसके बिना खुश रहने का प्रयत्न करना चाहिए |

[[English#^en-Q0472-answer|Compare the answer]]
^en-Q0472

**en-Q0473 · Write a translation**

Write this in English: वह अत्यंत बलवान है, इतना अधिक बलवान के उसे कोई पछाड़ नहीं सकता.

[[English#^en-Q0473-answer|Compare the answer]]
^en-Q0473

**en-Q0474 · Explain the grammar**

He is very strong--so much 【so that】 no one can defeat him.

वह अत्यंत बलवान है, इतना अधिक बलवान के उसे कोई पछाड़ नहीं सकता.

[[English#^en-Q0474-answer|Compare the answer]]
^en-Q0474

**en-Q0475 · Fill the gap**

How long has it been ____ you gave up teaching at that school?

तुम्हे स्कूल में पढ़ाना छोड़े हुए कितना समय हो गया है?

[[English#^en-Q0475-answer|Compare the answer]]
^en-Q0475

**en-Q0476 · Choose the form**

How long has it been ____ you gave up teaching at that school?

तुम्हे स्कूल में पढ़ाना छोड़े हुए कितना समय हो गया है?

Choices: because / therefore / since / so that

[[English#^en-Q0476-answer|Compare the answer]]
^en-Q0476

**en-Q0477 · Edit the changed sentence**

I got up early, 【because】 I could catch the first train.

मैं जल्दी उठा था, क्योंकि मुझे पहली ट्रेन पकड़नी थी।

[[English#^en-Q0477-answer|Compare the answer]]
^en-Q0477

**en-Q0478 · Build the sentence**

Arrange: the / that / could / first / catch / I / up / early, / so / got / train. / I

मैं जल्दी उठा था, क्योंकि मुझे पहली ट्रेन पकड़नी थी।

[[English#^en-Q0478-answer|Compare the answer]]
^en-Q0478

**en-Q0479 · Write a translation**

Write this in English: मैं अपनी गर्दन नहीं घुमा सकता क्योंकि बहुत दर्द होता है।

[[English#^en-Q0479-answer|Compare the answer]]
^en-Q0479

**en-Q0480 · Explain the grammar**

I can't turn my neck, 【because】 it hurts a lot.

मैं अपनी गर्दन नहीं घुमा सकता क्योंकि बहुत दर्द होता है।

[[English#^en-Q0480-answer|Compare the answer]]
^en-Q0480

**en-Q0481 · Fill the gap**

____ he was tired, he went to bed.

वह थक गया था, तो सोने चला गया।

[[English#^en-Q0481-answer|Compare the answer]]
^en-Q0481

**en-Q0482 · Choose the form**

____ he was tired, he went to bed.

वह थक गया था, तो सोने चला गया।

Choices: therefore / because / so that / Since

[[English#^en-Q0482-answer|Compare the answer]]
^en-Q0482

**en-Q0483 · Edit the changed sentence**

【because】 of the war, many people died.

जंग की वजह से बहुत सारे लोग मर गए।

[[English#^en-Q0483-answer|Compare the answer]]
^en-Q0483

**en-Q0484 · Build the sentence**

Arrange: many / the / a / result / of / died. / As / war, / people

जंग की वजह से बहुत सारे लोग मर गए।

[[English#^en-Q0484-answer|Compare the answer]]
^en-Q0484

**en-Q0485 · Write a translation**

Write this in English: मैं जिम को बचपन से जानता हूँ।

[[English#^en-Q0485-answer|Compare the answer]]
^en-Q0485

**en-Q0486 · Explain the grammar**

I've known Jim 【since】 I was a child.

मैं जिम को बचपन से जानता हूँ।

[[English#^en-Q0486-answer|Compare the answer]]
^en-Q0486

**en-Q0487 · Fill the gap**

He could not join us ____ he was ill.

वह बीमारी की वजह से हमारे साथ नहीं आ सका।

[[English#^en-Q0487-answer|Compare the answer]]
^en-Q0487

**en-Q0488 · Choose the form**

He could not join us ____ he was ill.

वह बीमारी की वजह से हमारे साथ नहीं आ सका।

Choices: because / therefore / so that

[[English#^en-Q0488-answer|Compare the answer]]
^en-Q0488

**en-Q0489 · Edit the changed sentence**

Nobody likes him, 【therefore】 he is always blowing his own horn.

उसे कोई भी पसंद नहीं करता क्योंकि वह सारे टाईम अपनी बड़ाई करता रहता है।

[[English#^en-Q0489-answer|Compare the answer]]
^en-Q0489

**en-Q0490 · Build the sentence**

Arrange: Nobody / because / blowing / his / always / horn. / him, / he / is / own / likes

उसे कोई भी पसंद नहीं करता क्योंकि वह सारे टाईम अपनी बड़ाई करता रहता है।

[[English#^en-Q0490-answer|Compare the answer]]
^en-Q0490

**en-Q0491 · Write a translation**

Write this in English: औद्योगिक क्रांति के बाद से दुनिया की आबादी तीन गुना से भी ज़्यादा बढ़ गयी है।

[[English#^en-Q0491-answer|Compare the answer]]
^en-Q0491

**en-Q0492 · Explain the grammar**

【Since】 the Industrial Revolution, the world population has more than tripled.

औद्योगिक क्रांति के बाद से दुनिया की आबादी तीन गुना से भी ज़्यादा बढ़ गयी है।

[[English#^en-Q0492-answer|Compare the answer]]
^en-Q0492

**en-Q0493 · Fill the gap**

It is forty years ____ I began the study of Japanese.

अब चालीस साल हो गए हैं मेरी जापानी की पढ़ाई को शुरू किए हुए।

[[English#^en-Q0493-answer|Compare the answer]]
^en-Q0493

**en-Q0494 · Choose the form**

It is forty years ____ I began the study of Japanese.

अब चालीस साल हो गए हैं मेरी जापानी की पढ़ाई को शुरू किए हुए।

Choices: so that / because / therefore / since

[[English#^en-Q0494-answer|Compare the answer]]
^en-Q0494

**en-Q0495 · Edit the changed sentence**

He was arrested 【therefore】 he stole the money.

उसे पैसे चुराने के लिए गिरफ़्तार कर लिया गया।

[[English#^en-Q0495-answer|Compare the answer]]
^en-Q0495

**en-Q0496 · Build the sentence**

Arrange: money. / was / stole / the / He / arrested / because / he

उसे पैसे चुराने के लिए गिरफ़्तार कर लिया गया।

[[English#^en-Q0496-answer|Compare the answer]]
^en-Q0496

**en-Q0497 · Write a translation**

Write this in English: मुझे अंग्रेजी की पढाई शुरू किये हुए छह महिने हुए हैं।

[[English#^en-Q0497-answer|Compare the answer]]
^en-Q0497

**en-Q0498 · Explain the grammar**

It has been six years 【since】 I started to study English.

मुझे अंग्रेजी की पढाई शुरू किये हुए छह महिने हुए हैं।

[[English#^en-Q0498-answer|Compare the answer]]
^en-Q0498

**en-Q0499 · Fill the gap**

Your feet are swollen ____ your shoes are too small.

तुम्हारे पैर सूज गए हैं क्योंकि तुम्हारे जूते बहुत छोटे हैं।

[[English#^en-Q0499-answer|Compare the answer]]
^en-Q0499

**en-Q0500 · Choose the form**

Your feet are swollen ____ your shoes are too small.

तुम्हारे पैर सूज गए हैं क्योंकि तुम्हारे जूते बहुत छोटे हैं।

Choices: because / so that / therefore

[[English#^en-Q0500-answer|Compare the answer]]
^en-Q0500

**en-Q0501 · Edit the changed sentence**

My daughter is in hospital 【therefore】 she was injured in a traffic accident.

मेरी बेटी हस्पताल में है क्योंकि उसे यातायात दुर्घटना में चोट पहुँची है।

[[English#^en-Q0501-answer|Compare the answer]]
^en-Q0501

**en-Q0502 · Build the sentence**

Arrange: because / she / in / is / accident. / in / a / injured / was / daughter / traffic / hospital / My

मेरी बेटी हस्पताल में है क्योंकि उसे यातायात दुर्घटना में चोट पहुँची है।

[[English#^en-Q0502-answer|Compare the answer]]
^en-Q0502

**en-Q0503 · Write a translation**

Write this in English: उसने इनाम पाने के लिए कड़ी मेहनत की।

[[English#^en-Q0503-answer|Compare the answer]]
^en-Q0503

**en-Q0504 · Explain the grammar**

He worked hard 【in order to】 get the prize.

उसने इनाम पाने के लिए कड़ी मेहनत की।

[[English#^en-Q0504-answer|Compare the answer]]
^en-Q0504


### Passive and agency · 50 questions

**en-Q0505 · Fill the gap**

These texts ____ written in Hebrew, not in Aramaic.

यह पाठ्य इब्रानी में लिखे थे, आरामाईक में नहीं।

[[English#^en-Q0505-answer|Compare the answer]]
^en-Q0505

**en-Q0506 · Choose the form**

These texts ____ written in Hebrew, not in Aramaic.

यह पाठ्य इब्रानी में लिखे थे, आरामाईक में नहीं।

Choices: being / was / been / were

[[English#^en-Q0506-answer|Compare the answer]]
^en-Q0506

**en-Q0507 · Edit the changed sentence**

Their conversation 【were】 carried on for about an hour.

उनकी बातचीत लगभग एक घंटे तक चलती रही।

[[English#^en-Q0507-answer|Compare the answer]]
^en-Q0507

**en-Q0508 · Build the sentence**

Arrange: conversation / for / an / about / carried / hour. / was / on / Their

उनकी बातचीत लगभग एक घंटे तक चलती रही।

[[English#^en-Q0508-answer|Compare the answer]]
^en-Q0508

**en-Q0509 · Write a translation**

Write this in English: सैम अठारह साल की उम्र में आर्मी में भर्ती हुआ था।

[[English#^en-Q0509-answer|Compare the answer]]
^en-Q0509

**en-Q0510 · Explain the grammar**

Sam joined the army when he 【was】 eighteen.

सैम अठारह साल की उम्र में आर्मी में भर्ती हुआ था।

[[English#^en-Q0510-answer|Compare the answer]]
^en-Q0510

**en-Q0511 · Fill the gap**

A strange car ____ parked in front of my house.

मेरे घर के सामने एक अजीब सी गाड़ी पार्क की गयी थी।

[[English#^en-Q0511-answer|Compare the answer]]
^en-Q0511

**en-Q0512 · Choose the form**

A strange car ____ parked in front of my house.

मेरे घर के सामने एक अजीब सी गाड़ी पार्क की गयी थी।

Choices: been / being / were / was

[[English#^en-Q0512-answer|Compare the answer]]
^en-Q0512

**en-Q0513 · Edit the changed sentence**

He 【were】 respected both as a teacher and as a man.

उसको दोनो एक अध्यापक और एक इनसान के रूप में सम्मान मिला।

[[English#^en-Q0513-answer|Compare the answer]]
^en-Q0513

**en-Q0514 · Build the sentence**

Arrange: and / respected / teacher / man. / both / was / a / as / a / He / as

उसको दोनो एक अध्यापक और एक इनसान के रूप में सम्मान मिला।

[[English#^en-Q0514-answer|Compare the answer]]
^en-Q0514

**en-Q0515 · Write a translation**

Write this in English: दुर्रानी साम्राज्य १७४७ में अफगानिस्तान में अहमद शाह दुर्रानी ने स्थापित किया था।

[[English#^en-Q0515-answer|Compare the answer]]
^en-Q0515

**en-Q0516 · Explain the grammar**

The Durrani Empire 【was】 established in Afghanistan by Ahmad Shah Durrani in 1747.

दुर्रानी साम्राज्य १७४७ में अफगानिस्तान में अहमद शाह दुर्रानी ने स्थापित किया था।

[[English#^en-Q0516-answer|Compare the answer]]
^en-Q0516

**en-Q0517 · Fill the gap**

This poem ____ written by a nameless poet.

यह कविता किसी बेनाम कवी ने लिखी थी।

[[English#^en-Q0517-answer|Compare the answer]]
^en-Q0517

**en-Q0518 · Choose the form**

This poem ____ written by a nameless poet.

यह कविता किसी बेनाम कवी ने लिखी थी।

Choices: been / were / being / was

[[English#^en-Q0518-answer|Compare the answer]]
^en-Q0518

**en-Q0519 · Edit the changed sentence**

The jeans looked none the cleaner for having 【was】 washed.

जीन्ज़ धुलकर भी साफ़ नहीं लग रहीं थीं।

[[English#^en-Q0519-answer|Compare the answer]]
^en-Q0519

**en-Q0520 · Build the sentence**

Arrange: looked / none / washed. / for / jeans / The / the / having / cleaner / been

जीन्ज़ धुलकर भी साफ़ नहीं लग रहीं थीं।

[[English#^en-Q0520-answer|Compare the answer]]
^en-Q0520

**en-Q0521 · Write a translation**

Write this in English: फ़्रांसीसी क्रांति के दौरान आँत्वाँ लाव्वाज़्ये का सिर काट दिया गया।

[[English#^en-Q0521-answer|Compare the answer]]
^en-Q0521

**en-Q0522 · Explain the grammar**

Antoine Lavoisier 【was】 beheaded during the French revolution.

फ़्रांसीसी क्रांति के दौरान आँत्वाँ लाव्वाज़्ये का सिर काट दिया गया।

[[English#^en-Q0522-answer|Compare the answer]]
^en-Q0522

**en-Q0523 · Fill the gap**

I ____ amazed at the speed of the car.

मैं उस गाड़ी की रफ़तार देखकर हैरान रह गया।

[[English#^en-Q0523-answer|Compare the answer]]
^en-Q0523

**en-Q0524 · Choose the form**

I ____ amazed at the speed of the car.

मैं उस गाड़ी की रफ़तार देखकर हैरान रह गया।

Choices: were / been / was / being

[[English#^en-Q0524-answer|Compare the answer]]
^en-Q0524

**en-Q0525 · Edit the changed sentence**

India 【were】 governed by Great Britain for many years.

भारत पर बहुत सालों तक ग्रेट ब्रिटेन राज करता था।

[[English#^en-Q0525-answer|Compare the answer]]
^en-Q0525

**en-Q0526 · Build the sentence**

Arrange: governed / Britain / for / by / Great / was / India / years. / many

भारत पर बहुत सालों तक ग्रेट ब्रिटेन राज करता था।

[[English#^en-Q0526-answer|Compare the answer]]
^en-Q0526

**en-Q0527 · Write a translation**

Write this in English: जापान दस साल पहले जैसे था वैसा अब नहीं रहा।

[[English#^en-Q0527-answer|Compare the answer]]
^en-Q0527

**en-Q0528 · Explain the grammar**

Japan is not what it 【was】 ten years ago.

जापान दस साल पहले जैसे था वैसा अब नहीं रहा।

[[English#^en-Q0528-answer|Compare the answer]]
^en-Q0528

**en-Q0529 · Fill the gap**

I ____ asked to give you a message.

मुझसे आपको यह संदेश देने के लिए बताया गया था।

[[English#^en-Q0529-answer|Compare the answer]]
^en-Q0529

**en-Q0530 · Choose the form**

I ____ asked to give you a message.

मुझसे आपको यह संदेश देने के लिए बताया गया था।

Choices: were / was / being / been

[[English#^en-Q0530-answer|Compare the answer]]
^en-Q0530

**en-Q0531 · Edit the changed sentence**

I've 【was】 given until tomorrow to finish this.

मुझे ये कल तक खतम करना है ।

[[English#^en-Q0531-answer|Compare the answer]]
^en-Q0531

**en-Q0532 · Build the sentence**

Arrange: until / this. / to / I've / tomorrow / finish / given / been

मुझे ये कल तक खतम करना है ।

[[English#^en-Q0532-answer|Compare the answer]]
^en-Q0532

**en-Q0533 · Write a translation**

Write this in English: वे रास्ते में बारिश में फँस गए।

[[English#^en-Q0533-answer|Compare the answer]]
^en-Q0533

**en-Q0534 · Explain the grammar**

They 【were】 caught in a shower on the way.

वे रास्ते में बारिश में फँस गए।

[[English#^en-Q0534-answer|Compare the answer]]
^en-Q0534

**en-Q0535 · Fill the gap**

Last night I ____ caught in a shower and got wet to the skin.

कल रात मैं बारिश में फंस गया और तर तर भीग गया।

[[English#^en-Q0535-answer|Compare the answer]]
^en-Q0535

**en-Q0536 · Choose the form**

Last night I ____ caught in a shower and got wet to the skin.

कल रात मैं बारिश में फंस गया और तर तर भीग गया।

Choices: been / being / was / were

[[English#^en-Q0536-answer|Compare the answer]]
^en-Q0536

**en-Q0537 · Edit the changed sentence**

In the 1600s, tea 【were】 introduced into Europe from India.

१६०० की शतक में चाय को भारत से यूरोप में लाया गया था।

[[English#^en-Q0537-answer|Compare the answer]]
^en-Q0537

**en-Q0538 · Build the sentence**

Arrange: into / Europe / the / 1600s, / India. / was / from / In / tea / introduced

१६०० की शतक में चाय को भारत से यूरोप में लाया गया था।

[[English#^en-Q0538-answer|Compare the answer]]
^en-Q0538

**en-Q0539 · Write a translation**

Write this in English: हैदराबाद पर १९४८ तक निज़ाम का राज था।

[[English#^en-Q0539-answer|Compare the answer]]
^en-Q0539

**en-Q0540 · Explain the grammar**

Hyderabad 【was】 ruled by a nizam until 1948.

हैदराबाद पर १९४८ तक निज़ाम का राज था।

[[English#^en-Q0540-answer|Compare the answer]]
^en-Q0540

**en-Q0541 · Fill the gap**

If my boy had not ____ killed in the traffic accident, he would be a college student now.

अगर मेरा बेटा ट्रेफ़िक हादसे में नहीं मारा गया होता, तो वह अभी कॉलेज जा रहा होता।

[[English#^en-Q0541-answer|Compare the answer]]
^en-Q0541

**en-Q0542 · Choose the form**

If my boy had not ____ killed in the traffic accident, he would be a college student now.

अगर मेरा बेटा ट्रेफ़िक हादसे में नहीं मारा गया होता, तो वह अभी कॉलेज जा रहा होता।

Choices: were / been / being / was

[[English#^en-Q0542-answer|Compare the answer]]
^en-Q0542

**en-Q0543 · Edit the changed sentence**

The drug smuggler 【were】 arrested at the airport.

दवा तस्कर हवाई अड्डे पर गिरफ्तार किया गया था।

[[English#^en-Q0543-answer|Compare the answer]]
^en-Q0543

**en-Q0544 · Build the sentence**

Arrange: smuggler / arrested / at / airport. / The / drug / was / the

दवा तस्कर हवाई अड्डे पर गिरफ्तार किया गया था।

[[English#^en-Q0544-answer|Compare the answer]]
^en-Q0544

**en-Q0545 · Write a translation**

Write this in English: ऐक्टिनियम का खोज आंड्रे-लूई डेबिएर्न ने साल १८९९ में किया था।

[[English#^en-Q0545-answer|Compare the answer]]
^en-Q0545

**en-Q0546 · Explain the grammar**

Actinium 【was】 discovered by André-Louis Debierne in 1899.

ऐक्टिनियम का खोज आंड्रे-लूई डेबिएर्न ने साल १८९९ में किया था।

[[English#^en-Q0546-answer|Compare the answer]]
^en-Q0546

**en-Q0547 · Fill the gap**

The date has ____ appointed but the place has not.

तारीख चुन ली गई है पर जगह नहीं।

[[English#^en-Q0547-answer|Compare the answer]]
^en-Q0547

**en-Q0548 · Choose the form**

The date has ____ appointed but the place has not.

तारीख चुन ली गई है पर जगह नहीं।

Choices: being / been / were / was

[[English#^en-Q0548-answer|Compare the answer]]
^en-Q0548

**en-Q0549 · Edit the changed sentence**

The Sikh Empire 【were】 established in 1799 by Ranjit Singh.

सिख साम्राज्य १७९९ में रणजीत सिंह ने स्थापित किया था।

[[English#^en-Q0549-answer|Compare the answer]]
^en-Q0549

**en-Q0550 · Build the sentence**

Arrange: Singh. / was / The / in / Ranjit / Sikh / by / established / 1799 / Empire

सिख साम्राज्य १७९९ में रणजीत सिंह ने स्थापित किया था।

[[English#^en-Q0550-answer|Compare the answer]]
^en-Q0550

**en-Q0551 · Write a translation**

Write this in English: मेरे माता-पिता के विवाह विच्छेद के हालात उनके काम के प्रति अत्याधिक लगाव से पैदा हुए थे।

[[English#^en-Q0551-answer|Compare the answer]]
^en-Q0551

**en-Q0552 · Explain the grammar**

The conditions that lead to my parents' divorce 【were】 engendered by their obsessive attitude toward work.

मेरे माता-पिता के विवाह विच्छेद के हालात उनके काम के प्रति अत्याधिक लगाव से पैदा हुए थे।

[[English#^en-Q0552-answer|Compare the answer]]
^en-Q0552

**en-Q0553 · Fill the gap**

I learned to drive a car and got a driver's license when I ____ eighteen.

जब मैं अठारह साल का था मैंने गाड़ी चलानी सीखी और लाईसेंस बनवालिया।

[[English#^en-Q0553-answer|Compare the answer]]
^en-Q0553

**en-Q0554 · Choose the form**

I learned to drive a car and got a driver's license when I ____ eighteen.

जब मैं अठारह साल का था मैंने गाड़ी चलानी सीखी और लाईसेंस बनवालिया।

Choices: were / being / was / been

[[English#^en-Q0554-answer|Compare the answer]]
^en-Q0554


### Non-finite complements · 50 questions

**en-Q0555 · Edit the changed sentence**

Traveling 【to】 boat takes longer than going by car.

नाव के सफ़र में कार से ज्यादा समय लगता है.

[[English#^en-Q0555-answer|Compare the answer]]
^en-Q0555

**en-Q0556 · Build the sentence**

Arrange: going / by / Traveling / longer / than / by / takes / car. / boat

नाव के सफ़र में कार से ज्यादा समय लगता है.

[[English#^en-Q0556-answer|Compare the answer]]
^en-Q0556

**en-Q0557 · Write a translation**

Write this in English: हमारे लक्ष्य निर्धारित करते हैं कि हम क्या बनने जा रहे हैं।

[[English#^en-Q0557-answer|Compare the answer]]
^en-Q0557

**en-Q0558 · Explain the grammar**

Goals determine what you are going 【to】 be.

हमारे लक्ष्य निर्धारित करते हैं कि हम क्या बनने जा रहे हैं।

[[English#^en-Q0558-answer|Compare the answer]]
^en-Q0558

**en-Q0559 · Fill the gap**

This is Tom speaking. I'd like ____ speak to Ann.

मैं टॉम बोल रहा हूँ। मुझे ऐन से बात करनी है।

[[English#^en-Q0559-answer|Compare the answer]]
^en-Q0559

**en-Q0560 · Choose the form**

This is Tom speaking. I'd like ____ speak to Ann.

मैं टॉम बोल रहा हूँ। मुझे ऐन से बात करनी है।

Choices: of / to / for / by

[[English#^en-Q0560-answer|Compare the answer]]
^en-Q0560

**en-Q0561 · Edit the changed sentence**

It's impossible 【to】 me to explain it to you.

मुझे तुमको यह बात समझाना नामुमकिन है।

[[English#^en-Q0561-answer|Compare the answer]]
^en-Q0561

**en-Q0562 · Build the sentence**

Arrange: for / impossible / it / to / me / It's / explain / you. / to

मुझे तुमको यह बात समझाना नामुमकिन है।

[[English#^en-Q0562-answer|Compare the answer]]
^en-Q0562

**en-Q0563 · Write a translation**

Write this in English: मैं सोच रही हूँ तुम्हारे जन्मदिव्स पर तुम्हे क्या उपहार दूँ।

[[English#^en-Q0563-answer|Compare the answer]]
^en-Q0563

**en-Q0564 · Explain the grammar**

I wonder what I should get you 【for】 your birthday.

मैं सोच रही हूँ तुम्हारे जन्मदिव्स पर तुम्हे क्या उपहार दूँ।

[[English#^en-Q0564-answer|Compare the answer]]
^en-Q0564

**en-Q0565 · Fill the gap**

Come on! I will show you the taste ____ defeat.

आओ! मैं तुम्हें हार का स्वाद चखाऊँगा।

[[English#^en-Q0565-answer|Compare the answer]]
^en-Q0565

**en-Q0566 · Choose the form**

Come on! I will show you the taste ____ defeat.

आओ! मैं तुम्हें हार का स्वाद चखाऊँगा।

Choices: by / to / for / of

[[English#^en-Q0566-answer|Compare the answer]]
^en-Q0566

**en-Q0567 · Edit the changed sentence**

I thought Tom would bring us something 【for】 eat.

मैंने सोचा टॉम हमारे खाने के लिए कुछ लाएगा.

[[English#^en-Q0567-answer|Compare the answer]]
^en-Q0567

**en-Q0568 · Build the sentence**

Arrange: eat. / us / bring / Tom / something / thought / I / to / would

मैंने सोचा टॉम हमारे खाने के लिए कुछ लाएगा.

[[English#^en-Q0568-answer|Compare the answer]]
^en-Q0568

**en-Q0569 · Write a translation**

Write this in English: "मिचि" के कान्जी में किती रेखाएं होती हैं?

[[English#^en-Q0569-answer|Compare the answer]]
^en-Q0569

**en-Q0570 · Explain the grammar**

How many strokes does the kanji 【for】 "michi" have?

"मिचि" के कान्जी में किती रेखाएं होती हैं?

[[English#^en-Q0570-answer|Compare the answer]]
^en-Q0570

**en-Q0571 · Fill the gap**

It is better ____ live rich, than to die rich.

अमीर हो कर मरने से बेहतर है अमीर हो कर जीना।

[[English#^en-Q0571-answer|Compare the answer]]
^en-Q0571

**en-Q0572 · Choose the form**

It is better ____ live rich, than to die rich.

अमीर हो कर मरने से बेहतर है अमीर हो कर जीना।

Choices: to / by / for / of

[[English#^en-Q0572-answer|Compare the answer]]
^en-Q0572

**en-Q0573 · Edit the changed sentence**

It's all the same 【for】 me whether you go or stay.

तुम जाओ या रहो, मुझे कोई फ़र्क नहीं पड़ता।

[[English#^en-Q0573-answer|Compare the answer]]
^en-Q0573

**en-Q0574 · Build the sentence**

Arrange: stay. / me / the / same / to / go / all / or / whether / It's / you

तुम जाओ या रहो, मुझे कोई फ़र्क नहीं पड़ता।

[[English#^en-Q0574-answer|Compare the answer]]
^en-Q0574

**en-Q0575 · Write a translation**

Write this in English: हमारी भाषा में रूचि रखने के लिए धन्यवाद्।

[[English#^en-Q0575-answer|Compare the answer]]
^en-Q0575

**en-Q0576 · Explain the grammar**

Thank you 【for】 your interest in our language.

हमारी भाषा में रूचि रखने के लिए धन्यवाद्।

[[English#^en-Q0576-answer|Compare the answer]]
^en-Q0576

**en-Q0577 · Fill the gap**

What kind ____ people do you like best?

तुम्हें किस तरह के लोग सबसे ज़्यादा पसंद हैं?

[[English#^en-Q0577-answer|Compare the answer]]
^en-Q0577

**en-Q0578 · Choose the form**

What kind ____ people do you like best?

तुम्हें किस तरह के लोग सबसे ज़्यादा पसंद हैं?

Choices: of / by / to / for

[[English#^en-Q0578-answer|Compare the answer]]
^en-Q0578

**en-Q0579 · Edit the changed sentence**

Their manners and customs are different from those 【to】 this country.

उनके रीति-रिवाज़ इस देश के से अलग हैं।

[[English#^en-Q0579-answer|Compare the answer]]
^en-Q0579

**en-Q0580 · Build the sentence**

Arrange: different / from / this / customs / Their / and / are / country. / manners / of / those

उनके रीति-रिवाज़ इस देश के से अलग हैं।

[[English#^en-Q0580-answer|Compare the answer]]
^en-Q0580

**en-Q0581 · Write a translation**

Write this in English: उसके डाक्टर ने उसे मद्य पीने से मना किया।

[[English#^en-Q0581-answer|Compare the answer]]
^en-Q0581

**en-Q0582 · Explain the grammar**

His doctor told him not 【to】 drink alcohol.

उसके डाक्टर ने उसे मद्य पीने से मना किया।

[[English#^en-Q0582-answer|Compare the answer]]
^en-Q0582

**en-Q0583 · Fill the gap**

The secret ____ longevity is to choose your parents carefully.

धीर्ग आयु का राज़ अपने माता पिता का सतर्क चुनाव में है |

[[English#^en-Q0583-answer|Compare the answer]]
^en-Q0583

**en-Q0584 · Choose the form**

The secret ____ longevity is to choose your parents carefully.

धीर्ग आयु का राज़ अपने माता पिता का सतर्क चुनाव में है |

Choices: to / of / for / by

[[English#^en-Q0584-answer|Compare the answer]]
^en-Q0584

**en-Q0585 · Edit the changed sentence**

It would be better 【to】 you not to ask him for advice.

बहतर होगा कि तुम उससे सलाह न माँगो।

[[English#^en-Q0585-answer|Compare the answer]]
^en-Q0585

**en-Q0586 · Build the sentence**

Arrange: to / not / for / him / better / you / ask / It / for / be / would / advice.

बहतर होगा कि तुम उससे सलाह न माँगो।

[[English#^en-Q0586-answer|Compare the answer]]
^en-Q0586

**en-Q0587 · Write a translation**

Write this in English: मुझे मालूम है आप मेरे साथ बात नहीं करना चाहते।

[[English#^en-Q0587-answer|Compare the answer]]
^en-Q0587

**en-Q0588 · Explain the grammar**

I know that you don't want 【to】 talk to me.

मुझे मालूम है आप मेरे साथ बात नहीं करना चाहते।

[[English#^en-Q0588-answer|Compare the answer]]
^en-Q0588

**en-Q0589 · Fill the gap**

Write back ____ me as soon as you get this letter.

तुम्हें जैसे ही यह पत्र मिले मुझे लिखकर जवाब देना।

[[English#^en-Q0589-answer|Compare the answer]]
^en-Q0589

**en-Q0590 · Choose the form**

Write back ____ me as soon as you get this letter.

तुम्हें जैसे ही यह पत्र मिले मुझे लिखकर जवाब देना।

Choices: of / by / to / for

[[English#^en-Q0590-answer|Compare the answer]]
^en-Q0590

**en-Q0591 · Edit the changed sentence**

As a matter 【to】 fact, I dislike him.

दरअसल मुझे वह पसंद नहीं है।

[[English#^en-Q0591-answer|Compare the answer]]
^en-Q0591

**en-Q0592 · Build the sentence**

Arrange: I / fact, / him. / dislike / As / matter / of / a

दरअसल मुझे वह पसंद नहीं है।

[[English#^en-Q0592-answer|Compare the answer]]
^en-Q0592

**en-Q0593 · Write a translation**

Write this in English: हमने पारिवारिक शापिंग साइट पर इस प्रकार की अश्लीलता देखने की कभी कल्पना नहीं की थी।

[[English#^en-Q0593-answer|Compare the answer]]
^en-Q0593

**en-Q0594 · Explain the grammar**

We simply didn't expect 【to】 see such filth on the family shopping site.

हमने पारिवारिक शापिंग साइट पर इस प्रकार की अश्लीलता देखने की कभी कल्पना नहीं की थी।

[[English#^en-Q0594-answer|Compare the answer]]
^en-Q0594

**en-Q0595 · Fill the gap**

I have ____ put the baby to bed.

मुझे बच्चे को सुलाना है।

[[English#^en-Q0595-answer|Compare the answer]]
^en-Q0595

**en-Q0596 · Choose the form**

I have ____ put the baby to bed.

मुझे बच्चे को सुलाना है।

Choices: to / for / by / of

[[English#^en-Q0596-answer|Compare the answer]]
^en-Q0596

**en-Q0597 · Edit the changed sentence**

I am connecting this computer 【for】 the Internet.

मैं इस कम्प्यूटर को इंटरनेट से जोड़ रहा हूं।

[[English#^en-Q0597-answer|Compare the answer]]
^en-Q0597

**en-Q0598 · Build the sentence**

Arrange: I / to / this / am / the / computer / connecting / Internet.

मैं इस कम्प्यूटर को इंटरनेट से जोड़ रहा हूं।

[[English#^en-Q0598-answer|Compare the answer]]
^en-Q0598

**en-Q0599 · Write a translation**

Write this in English: क्या हमे कल सुबह जल्दी उठना है?

[[English#^en-Q0599-answer|Compare the answer]]
^en-Q0599

**en-Q0600 · Explain the grammar**

Do we have 【to】 get up early tomorrow morning?

क्या हमे कल सुबह जल्दी उठना है?

[[English#^en-Q0600-answer|Compare the answer]]
^en-Q0600

**en-Q0601 · Fill the gap**

Susan is older than me ____ 2 years.

सूज़ैन मुझसे दो साल बड़ी है।

[[English#^en-Q0601-answer|Compare the answer]]
^en-Q0601

**en-Q0602 · Choose the form**

Susan is older than me ____ 2 years.

सूज़ैन मुझसे दो साल बड़ी है।

Choices: of / by / to / for

[[English#^en-Q0602-answer|Compare the answer]]
^en-Q0602

**en-Q0603 · Edit the changed sentence**

A madman is not accountable 【to】 his actions.

एक पागल इनसान को अपने किये-धरे के लिए ज़िम्मेदार नहीं ठहराया जा सकता।

[[English#^en-Q0603-answer|Compare the answer]]
^en-Q0603

**en-Q0604 · Build the sentence**

Arrange: A / madman / is / actions. / for / his / accountable / not

एक पागल इनसान को अपने किये-धरे के लिए ज़िम्मेदार नहीं ठहराया जा सकता।

[[English#^en-Q0604-answer|Compare the answer]]
^en-Q0604


### Pronoun reference and reflexives · 24 questions

**en-Q0605 · Write a translation**

Write this in English: हाँ शायद मैं दुखी हूँ, पर मुझे अपनी जान लेने का इरादा नहीं है।

[[English#^en-Q0605-answer|Compare the answer]]
^en-Q0605

**en-Q0606 · Explain the grammar**

Maybe I am unhappy, but I don't intend to kill 【myself】.

हाँ शायद मैं दुखी हूँ, पर मुझे अपनी जान लेने का इरादा नहीं है।

[[English#^en-Q0606-answer|Compare the answer]]
^en-Q0606

**en-Q0607 · Fill the gap**

When you betray somebody else, you also betray ____.

आप किसी व्यक्ति को धोखा देते हैं तो आप अपने आप को भी धोखा देते हैं।

[[English#^en-Q0607-answer|Compare the answer]]
^en-Q0607

**en-Q0608 · Choose the form**

When you betray somebody else, you also betray ____.

आप किसी व्यक्ति को धोखा देते हैं तो आप अपने आप को भी धोखा देते हैं।

Choices: himself / herself / themselves / yourself

[[English#^en-Q0608-answer|Compare the answer]]
^en-Q0608

**en-Q0609 · Edit the changed sentence**

You need to be attentive during the interview and grab any opportunity that presents 【himself】.

इंटरव्यू के दौरान तुम्हें सतर्क रहना होगा और मौक़ा दिखते ही उसे हाथ ले लेना होगा।

[[English#^en-Q0609-answer|Compare the answer]]
^en-Q0609

**en-Q0610 · Build the sentence**

Arrange: opportunity / itself. / grab / attentive / during / be / need / any / presents / the / and / interview / that / You / to

इंटरव्यू के दौरान तुम्हें सतर्क रहना होगा और मौक़ा दिखते ही उसे हाथ ले लेना होगा।

[[English#^en-Q0610-answer|Compare the answer]]
^en-Q0610

**en-Q0611 · Write a translation**

Write this in English: हम जब तक खुद मां बाप नहीं बन जाएं, मां बाप का प्यार कभी नहीं जान पाते।

[[English#^en-Q0611-answer|Compare the answer]]
^en-Q0611

**en-Q0612 · Explain the grammar**

We never know the love of a parent till we become parents 【ourselves】.

हम जब तक खुद मां बाप नहीं बन जाएं, मां बाप का प्यार कभी नहीं जान पाते।

[[English#^en-Q0612-answer|Compare the answer]]
^en-Q0612

**en-Q0613 · Fill the gap**

She said to ____, "I am very happy."

उसने अपने आप से कहा: "मैं बहुत खुश हूँ"

[[English#^en-Q0613-answer|Compare the answer]]
^en-Q0613

**en-Q0614 · Choose the form**

She said to ____, "I am very happy."

उसने अपने आप से कहा: "मैं बहुत खुश हूँ"

Choices: themselves / herself / himself

[[English#^en-Q0614-answer|Compare the answer]]
^en-Q0614

**en-Q0615 · Edit the changed sentence**

"What shall I do?" I said to 【himself】.

"क्या करूँ?" मैंने अपने-आप से पूछा।

[[English#^en-Q0615-answer|Compare the answer]]
^en-Q0615

**en-Q0616 · Build the sentence**

Arrange: myself. / said / "What / I / to / I / do?" / shall

"क्या करूँ?" मैंने अपने-आप से पूछा।

[[English#^en-Q0616-answer|Compare the answer]]
^en-Q0616

**en-Q0617 · Write a translation**

Write this in English: वह वहाँ अकेले जाने लायक बहादुर है।

[[English#^en-Q0617-answer|Compare the answer]]
^en-Q0617

**en-Q0618 · Explain the grammar**

He is brave enough to go there by 【himself】.

वह वहाँ अकेले जाने लायक बहादुर है।

[[English#^en-Q0618-answer|Compare the answer]]
^en-Q0618

**en-Q0619 · Fill the gap**

He is now old enough to travel by ____.

उसकी अकेले सफ़र करने की उम्र हो गयी है।

[[English#^en-Q0619-answer|Compare the answer]]
^en-Q0619

**en-Q0620 · Choose the form**

He is now old enough to travel by ____.

उसकी अकेले सफ़र करने की उम्र हो गयी है।

Choices: themselves / herself / himself

[[English#^en-Q0620-answer|Compare the answer]]
^en-Q0620

**en-Q0621 · Edit the changed sentence**

It will go away by 【himself】 in two weeks.

वह दो हफ़्तों में अपने-आप चला जाएगा।

[[English#^en-Q0621-answer|Compare the answer]]
^en-Q0621

**en-Q0622 · Build the sentence**

Arrange: will / itself / away / two / weeks. / in / It / go / by

वह दो हफ़्तों में अपने-आप चला जाएगा।

[[English#^en-Q0622-answer|Compare the answer]]
^en-Q0622

**en-Q0623 · Write a translation**

Write this in English: कृपया भविष्य में अपने बेतुके दोषारोपणों को अपने पास ही रखें।

[[English#^en-Q0623-answer|Compare the answer]]
^en-Q0623

**en-Q0624 · Explain the grammar**

Please keep your ludicrous accusations to 【yourself】 in future.

कृपया भविष्य में अपने बेतुके दोषारोपणों को अपने पास ही रखें।

[[English#^en-Q0624-answer|Compare the answer]]
^en-Q0624

**en-Q0625 · Fill the gap**

I was a fool to have tried explaining something to you that I don't understand ____.

मैं अक्ल का मारा था जो तुम्हें वह समझाने की कोशिश करने बैठा जिसकी मुझे खुद ही समझ नहीं थी।

[[English#^en-Q0625-answer|Compare the answer]]
^en-Q0625

**en-Q0626 · Choose the form**

I was a fool to have tried explaining something to you that I don't understand ____.

मैं अक्ल का मारा था जो तुम्हें वह समझाने की कोशिश करने बैठा जिसकी मुझे खुद ही समझ नहीं थी।

Choices: myself / themselves / herself / himself

[[English#^en-Q0626-answer|Compare the answer]]
^en-Q0626

**en-Q0627 · Edit the changed sentence**

He broke 【herself】 of the bad habit of smoking.

उसने अपनी सिगरेट पीने की बुरी आदत छोड़ दी।

[[English#^en-Q0627-answer|Compare the answer]]
^en-Q0627

**en-Q0628 · Build the sentence**

Arrange: of / of / broke / bad / the / himself / He / smoking. / habit

उसने अपनी सिगरेट पीने की बुरी आदत छोड़ दी।

[[English#^en-Q0628-answer|Compare the answer]]
^en-Q0628


### Quantifiers and agreement · 50 questions

**en-Q0629 · Write a translation**

Write this in English: मैंने कुछ ज़्यादा ही पी लिया है। मेरा पूरा चेहरा सूज गया है!

[[English#^en-Q0629-answer|Compare the answer]]
^en-Q0629

**en-Q0630 · Explain the grammar**

I drank too 【much】. My face is swollen!

मैंने कुछ ज़्यादा ही पी लिया है। मेरा पूरा चेहरा सूज गया है!

[[English#^en-Q0630-answer|Compare the answer]]
^en-Q0630

**en-Q0631 · Fill the gap**

How ____ letters does the Russian alphabet have?

रूसी वर्णमाला में कितने अक्षर हैं?

[[English#^en-Q0631-answer|Compare the answer]]
^en-Q0631

**en-Q0632 · Choose the form**

How ____ letters does the Russian alphabet have?

रूसी वर्णमाला में कितने अक्षर हैं?

Choices: many / each / both / much

[[English#^en-Q0632-answer|Compare the answer]]
^en-Q0632

**en-Q0633 · Edit the changed sentence**

We can hear the church bell 【each】 morning.

हमें हर सुबह चर्च की घंटी सुनाई देती है।

[[English#^en-Q0633-answer|Compare the answer]]
^en-Q0633

**en-Q0634 · Build the sentence**

Arrange: can / every / We / morning. / hear / the / church / bell

हमें हर सुबह चर्च की घंटी सुनाई देती है।

[[English#^en-Q0634-answer|Compare the answer]]
^en-Q0634

**en-Q0635 · Write a translation**

Write this in English: भारत में कई लोग गाय को पूज्य मानते हैं।

[[English#^en-Q0635-answer|Compare the answer]]
^en-Q0635

**en-Q0636 · Explain the grammar**

Cows are sacred to 【many】 people in India.

भारत में कई लोग गाय को पूज्य मानते हैं।

[[English#^en-Q0636-answer|Compare the answer]]
^en-Q0636

**en-Q0637 · Fill the gap**

____ great men went through hardship during their youth.

कई महान पुरुषों को अपने जवानी में कठिनाई का सामना करना पड़ा।

[[English#^en-Q0637-answer|Compare the answer]]
^en-Q0637

**en-Q0638 · Choose the form**

____ great men went through hardship during their youth.

कई महान पुरुषों को अपने जवानी में कठिनाई का सामना करना पड़ा।

Choices: much / both / each / Many

[[English#^en-Q0638-answer|Compare the answer]]
^en-Q0638

**en-Q0639 · Edit the changed sentence**

【each】 people encouraged me to fulfill my ambitions.

अपनी अभिलाषाओं को पूरी करने के लिए मुझे बहुत से लोगों ने बढ़ावा दिया।

[[English#^en-Q0639-answer|Compare the answer]]
^en-Q0639

**en-Q0640 · Build the sentence**

Arrange: Many / ambitions. / to / encouraged / me / people / my / fulfill

अपनी अभिलाषाओं को पूरी करने के लिए मुझे बहुत से लोगों ने बढ़ावा दिया।

[[English#^en-Q0640-answer|Compare the answer]]
^en-Q0640

**en-Q0641 · Write a translation**

Write this in English: हम एक दूसरे से प्यार करते हैं, मगर अब हम सेक्स नहीं करते।

[[English#^en-Q0641-answer|Compare the answer]]
^en-Q0641

**en-Q0642 · Explain the grammar**

We love 【each】 other, but we don't have sex anymore.

हम एक दूसरे से प्यार करते हैं, मगर अब हम सेक्स नहीं करते।

[[English#^en-Q0642-answer|Compare the answer]]
^en-Q0642

**en-Q0643 · Fill the gap**

____ member has to pay a membership fee.

हर सदस्य को सदस्यता शुल्क भरना होगा।

[[English#^en-Q0643-answer|Compare the answer]]
^en-Q0643

**en-Q0644 · Choose the form**

____ member has to pay a membership fee.

हर सदस्य को सदस्यता शुल्क भरना होगा।

Choices: many / Each / both / much

[[English#^en-Q0644-answer|Compare the answer]]
^en-Q0644

**en-Q0645 · Edit the changed sentence**

Tom has two sons. 【each】 of them live in Boston.

टॉम के दो बेटे हैं। दोनों बॉस्टन में रहते हैं।

[[English#^en-Q0645-answer|Compare the answer]]
^en-Q0645

**en-Q0646 · Build the sentence**

Arrange: two / Both / in / sons. / Tom / of / live / them / Boston. / has

टॉम के दो बेटे हैं। दोनों बॉस्टन में रहते हैं।

[[English#^en-Q0646-answer|Compare the answer]]
^en-Q0646

**en-Q0647 · Write a translation**

Write this in English: उसकी सफ़लता सालों की मेहनत का फल है।

[[English#^en-Q0647-answer|Compare the answer]]
^en-Q0647

**en-Q0648 · Explain the grammar**

His success is the result of 【many】 years of perseverance.

उसकी सफ़लता सालों की मेहनत का फल है।

[[English#^en-Q0648-answer|Compare the answer]]
^en-Q0648

**en-Q0649 · Fill the gap**

We communicate with ____ other by telephone every day.

हम रोज़ एक-दूसरे से फ़ोन पर बात करते हैं।

[[English#^en-Q0649-answer|Compare the answer]]
^en-Q0649

**en-Q0650 · Choose the form**

We communicate with ____ other by telephone every day.

हम रोज़ एक-दूसरे से फ़ोन पर बात करते हैं।

Choices: each / many / much / both

[[English#^en-Q0650-answer|Compare the answer]]
^en-Q0650

**en-Q0651 · Edit the changed sentence**

My father stayed a 【each】 days in Frankfurt.

मेरे पिता फ़्रैंकफुर्ट में कुछ दिन रहें।

[[English#^en-Q0651-answer|Compare the answer]]
^en-Q0651

**en-Q0652 · Build the sentence**

Arrange: Frankfurt. / father / days / few / in / stayed / a / My

मेरे पिता फ़्रैंकफुर्ट में कुछ दिन रहें।

[[English#^en-Q0652-answer|Compare the answer]]
^en-Q0652

**en-Q0653 · Write a translation**

Write this in English: मैं लेखक के तौर पर उनका आदर करता हूँ, पर इनसान के तौर पर उन्हें पसंद नहीं करता।

[[English#^en-Q0653-answer|Compare the answer]]
^en-Q0653

**en-Q0654 · Explain the grammar**

【Much】 as I admire him as a writer, I don't like him as a man.

मैं लेखक के तौर पर उनका आदर करता हूँ, पर इनसान के तौर पर उन्हें पसंद नहीं करता।

[[English#^en-Q0654-answer|Compare the answer]]
^en-Q0654

**en-Q0655 · Fill the gap**

How ____ people were present at the meeting?

बैठक मैं कितने लोग मौजूद थे ?

[[English#^en-Q0655-answer|Compare the answer]]
^en-Q0655

**en-Q0656 · Choose the form**

How ____ people were present at the meeting?

बैठक मैं कितने लोग मौजूद थे ?

Choices: much / each / both / many

[[English#^en-Q0656-answer|Compare the answer]]
^en-Q0656

**en-Q0657 · Edit the changed sentence**

Have you spoke to him in the past 【each】 days?

क्या तुमने उस से बीते दिनों में वार्तालाप की है?

[[English#^en-Q0657-answer|Compare the answer]]
^en-Q0657

**en-Q0658 · Build the sentence**

Arrange: in / Have / days? / spoke / past / to / him / the / few / you

क्या तुमने उस से बीते दिनों में वार्तालाप की है?

[[English#^en-Q0658-answer|Compare the answer]]
^en-Q0658

**en-Q0659 · Write a translation**

Write this in English: न तो वन्य जीवों और न ही घरेलू जीवों को मृत्यु का पूर्वाभास होता है।

[[English#^en-Q0659-answer|Compare the answer]]
^en-Q0659

**en-Q0660 · Explain the grammar**

【Neither】 wild nor domestic animals appear to have any premonition of death.

न तो वन्य जीवों और न ही घरेलू जीवों को मृत्यु का पूर्वाभास होता है।

[[English#^en-Q0660-answer|Compare the answer]]
^en-Q0660

**en-Q0661 · Fill the gap**

It's good now; ____ too heavy nor too light.

अब ठीक है। न ज़्यादा भारी है न ज़्यादा हल्का है।

[[English#^en-Q0661-answer|Compare the answer]]
^en-Q0661

**en-Q0662 · Choose the form**

It's good now; ____ too heavy nor too light.

अब ठीक है। न ज़्यादा भारी है न ज़्यादा हल्का है।

Choices: both / each / much / neither

[[English#^en-Q0662-answer|Compare the answer]]
^en-Q0662

**en-Q0663 · Edit the changed sentence**

She is capable of teaching 【each】 English and French.

उसके पास अंग्रेज़ी और फ़्रांसीसी सिखाने की काबिलियत है।

[[English#^en-Q0663-answer|Compare the answer]]
^en-Q0663

**en-Q0664 · Build the sentence**

Arrange: She / of / English / and / capable / teaching / is / both / French.

उसके पास अंग्रेज़ी और फ़्रांसीसी सिखाने की काबिलियत है।

[[English#^en-Q0664-answer|Compare the answer]]
^en-Q0664

**en-Q0665 · Write a translation**

Write this in English: उसके पास तुमसे नाराज़ होने का पूरा हक है।

[[English#^en-Q0665-answer|Compare the answer]]
^en-Q0665

**en-Q0666 · Explain the grammar**

He has 【every】 reason for getting angry with you.

उसके पास तुमसे नाराज़ होने का पूरा हक है।

[[English#^en-Q0666-answer|Compare the answer]]
^en-Q0666

**en-Q0667 · Fill the gap**

How ____ books do you read a month?

तुम एक महीने में कितनी किताबें पढ़ते हो?

[[English#^en-Q0667-answer|Compare the answer]]
^en-Q0667

**en-Q0668 · Choose the form**

How ____ books do you read a month?

तुम एक महीने में कितनी किताबें पढ़ते हो?

Choices: much / many / each / both

[[English#^en-Q0668-answer|Compare the answer]]
^en-Q0668

**en-Q0669 · Edit the changed sentence**

He goes with his mother to Russia 【each】 year.

वह हर साल अपनी माँ के साथ रूस जाता है।

[[English#^en-Q0669-answer|Compare the answer]]
^en-Q0669

**en-Q0670 · Build the sentence**

Arrange: He / to / Russia / his / goes / year. / every / with / mother

वह हर साल अपनी माँ के साथ रूस जाता है।

[[English#^en-Q0670-answer|Compare the answer]]
^en-Q0670

**en-Q0671 · Write a translation**

Write this in English: वह आदमी तो भला है, पर बात बहुत ज़्यादा करता है।

[[English#^en-Q0671-answer|Compare the answer]]
^en-Q0671

**en-Q0672 · Explain the grammar**

He is a nice man, except that he talks too 【much】.

वह आदमी तो भला है, पर बात बहुत ज़्यादा करता है।

[[English#^en-Q0672-answer|Compare the answer]]
^en-Q0672

**en-Q0673 · Fill the gap**

We talked to ____ other for a while.

हमने थोड़ी देर के लिए एक-दूसरे के साथ बात करी।

[[English#^en-Q0673-answer|Compare the answer]]
^en-Q0673

**en-Q0674 · Choose the form**

We talked to ____ other for a while.

हमने थोड़ी देर के लिए एक-दूसरे के साथ बात करी।

Choices: both / many / much / each

[[English#^en-Q0674-answer|Compare the answer]]
^en-Q0674

**en-Q0675 · Edit the changed sentence**

Mom, add a 【each】 more salt to the soup.

मम्मी, सूप में थोड़ा और नमक डालो।

[[English#^en-Q0675-answer|Compare the answer]]
^en-Q0675

**en-Q0676 · Build the sentence**

Arrange: more / salt / a / little / to / add / soup. / Mom, / the

मम्मी, सूप में थोड़ा और नमक डालो।

[[English#^en-Q0676-answer|Compare the answer]]
^en-Q0676

**en-Q0677 · Write a translation**

Write this in English: हमारे लिए एक-दूसरे को समझना बहुत ज़रूरी है।

[[English#^en-Q0677-answer|Compare the answer]]
^en-Q0677

**en-Q0678 · Explain the grammar**

It is very important for us to know 【each】 other.

हमारे लिए एक-दूसरे को समझना बहुत ज़रूरी है।

[[English#^en-Q0678-answer|Compare the answer]]
^en-Q0678


### Time-frame control · 50 questions

**en-Q0679 · Fill the gap**

That was just the trailer, the movie's ____ to come, my friend!

यह तो बस ट्रेलर है, पिक्चर अभी बाकी है, मेरे दोस्त!

[[English#^en-Q0679-answer|Compare the answer]]
^en-Q0679

**en-Q0680 · Choose the form**

That was just the trailer, the movie's ____ to come, my friend!

यह तो बस ट्रेलर है, पिक्चर अभी बाकी है, मेरे दोस्त!

Choices: since / yet / still / already

[[English#^en-Q0680-answer|Compare the answer]]
^en-Q0680

**en-Q0681 · Edit the changed sentence**

The workers were laid off 【already】 three weeks.

कर्मचारियों को तीन हफ़्तों के लिए काम से निकाल दिया गया।

[[English#^en-Q0681-answer|Compare the answer]]
^en-Q0681

**en-Q0682 · Build the sentence**

Arrange: were / workers / three / The / for / laid / weeks. / off

कर्मचारियों को तीन हफ़्तों के लिए काम से निकाल दिया गया।

[[English#^en-Q0682-answer|Compare the answer]]
^en-Q0682

**en-Q0683 · Write a translation**

Write this in English: जहाँ तक की मुझे पता है, उसने अभी तक शादी नहीं की है।

[[English#^en-Q0683-answer|Compare the answer]]
^en-Q0683

**en-Q0684 · Explain the grammar**

As far as I know, she's not 【yet】 married.

जहाँ तक की मुझे पता है, उसने अभी तक शादी नहीं की है।

[[English#^en-Q0684-answer|Compare the answer]]
^en-Q0684

**en-Q0685 · Fill the gap**

Add the rice and cook gently ____ the grains begin to turn translucent.

चावल डालें और धीरे-धीरे उस समय तक पकाएं जब तक कि दानें पारभासी (स्वच्छ) न हो जाएं।

[[English#^en-Q0685-answer|Compare the answer]]
^en-Q0685

**en-Q0686 · Choose the form**

Add the rice and cook gently ____ the grains begin to turn translucent.

चावल डालें और धीरे-धीरे उस समय तक पकाएं जब तक कि दानें पारभासी (स्वच्छ) न हो जाएं।

Choices: already / yet / still / until

[[English#^en-Q0686-answer|Compare the answer]]
^en-Q0686

**en-Q0687 · Edit the changed sentence**

I'll wait here 【already】 my medicine is ready.

जब तक मेरी दवाई तैयार नहीं होती मैं यहीं इंतेज़ार करूंगी।

[[English#^en-Q0687-answer|Compare the answer]]
^en-Q0687

**en-Q0688 · Build the sentence**

Arrange: until / here / I'll / is / my / ready. / wait / medicine

जब तक मेरी दवाई तैयार नहीं होती मैं यहीं इंतेज़ार करूंगी।

[[English#^en-Q0688-answer|Compare the answer]]
^en-Q0688

**en-Q0689 · Write a translation**

Write this in English: डाक टिकट की तरह बनिए, मंजिल पर जब तक न पहुंच जाएं उसी चीज़ पर जमे रहिए।

[[English#^en-Q0689-answer|Compare the answer]]
^en-Q0689

**en-Q0690 · Explain the grammar**

Be like a postage stamp. Stick to one thing 【until】 you get there.

डाक टिकट की तरह बनिए, मंजिल पर जब तक न पहुंच जाएं उसी चीज़ पर जमे रहिए।

[[English#^en-Q0690-answer|Compare the answer]]
^en-Q0690

**en-Q0691 · Fill the gap**

Will you exchange this sweater ____ a larger one?

आप यह स्वेटर बड़े नाप वाले के लिए बदल देंगे क्या?

[[English#^en-Q0691-answer|Compare the answer]]
^en-Q0691

**en-Q0692 · Choose the form**

Will you exchange this sweater ____ a larger one?

आप यह स्वेटर बड़े नाप वाले के लिए बदल देंगे क्या?

Choices: already / still / for / yet

[[English#^en-Q0692-answer|Compare the answer]]
^en-Q0692

**en-Q0693 · Edit the changed sentence**

Facebook will buy WhatsApp 【already】 19 billion dollars.

फ़ेसबुक वॉट्सएप को १९ अरब डॉलरों में खरीद लेगा।

[[English#^en-Q0693-answer|Compare the answer]]
^en-Q0693

**en-Q0694 · Build the sentence**

Arrange: buy / billion / dollars. / 19 / will / Facebook / for / WhatsApp

फ़ेसबुक वॉट्सएप को १९ अरब डॉलरों में खरीद लेगा।

[[English#^en-Q0694-answer|Compare the answer]]
^en-Q0694

**en-Q0695 · Write a translation**

Write this in English: टीवी सेट के लिए और जगह नहीं है।

[[English#^en-Q0695-answer|Compare the answer]]
^en-Q0695

**en-Q0696 · Explain the grammar**

There is no more room 【for】 a TV set.

टीवी सेट के लिए और जगह नहीं है।

[[English#^en-Q0696-answer|Compare the answer]]
^en-Q0696

**en-Q0697 · Fill the gap**

It will not be long ____ we know the result.

नतीजा जानने में अब ज़्यादा देर नहीं लगेगी।

[[English#^en-Q0697-answer|Compare the answer]]
^en-Q0697

**en-Q0698 · Choose the form**

It will not be long ____ we know the result.

नतीजा जानने में अब ज़्यादा देर नहीं लगेगी।

Choices: already / still / before / yet

[[English#^en-Q0698-answer|Compare the answer]]
^en-Q0698

**en-Q0699 · Edit the changed sentence**

He went outside 【already】 a breath of fresh air.

वह थोड़ी ताज़ा हवा खाने के लिए बाहर गया।

[[English#^en-Q0699-answer|Compare the answer]]
^en-Q0699

**en-Q0700 · Build the sentence**

Arrange: went / air. / He / fresh / for / a / of / breath / outside

वह थोड़ी ताज़ा हवा खाने के लिए बाहर गया।

[[English#^en-Q0700-answer|Compare the answer]]
^en-Q0700

**en-Q0701 · Write a translation**

Write this in English: मेरी शादी पाँच साल पहले इसी दिन पर हुई थी।

[[English#^en-Q0701-answer|Compare the answer]]
^en-Q0701

**en-Q0702 · Explain the grammar**

I got married five years 【ago】 on this very day.

मेरी शादी पाँच साल पहले इसी दिन पर हुई थी।

[[English#^en-Q0702-answer|Compare the answer]]
^en-Q0702

**en-Q0703 · Fill the gap**

The law kept people from playing football ____ a while.

क़ानून ने लोगों को फ़ुटबॉल खेलने से बहुत देर तक रोका।

[[English#^en-Q0703-answer|Compare the answer]]
^en-Q0703

**en-Q0704 · Choose the form**

The law kept people from playing football ____ a while.

क़ानून ने लोगों को फ़ुटबॉल खेलने से बहुत देर तक रोका।

Choices: for / still / already / yet

[[English#^en-Q0704-answer|Compare the answer]]
^en-Q0704

**en-Q0705 · Edit the changed sentence**

I haven't got in touch with him 【already】 a long time.

मेरा उसके साथ काफ़ी देर से सम्पर्क नहीं हुआ है।

[[English#^en-Q0705-answer|Compare the answer]]
^en-Q0705

**en-Q0706 · Build the sentence**

Arrange: with / touch / long / for / I / in / haven't / got / him / time. / a

मेरा उसके साथ काफ़ी देर से सम्पर्क नहीं हुआ है।

[[English#^en-Q0706-answer|Compare the answer]]
^en-Q0706

**en-Q0707 · Write a translation**

Write this in English: मैं अभी दो सालों से उइघुर भाषा सीख रहा हूं।

[[English#^en-Q0707-answer|Compare the answer]]
^en-Q0707

**en-Q0708 · Explain the grammar**

I've been studying Uighur 【for】 two years now.

मैं अभी दो सालों से उइघुर भाषा सीख रहा हूं।

[[English#^en-Q0708-answer|Compare the answer]]
^en-Q0708

**en-Q0709 · Fill the gap**

I am going to stay here ____ a couple of days.

मैं यहाँ एक-दो दिन रहूँगा।

[[English#^en-Q0709-answer|Compare the answer]]
^en-Q0709

**en-Q0710 · Choose the form**

I am going to stay here ____ a couple of days.

मैं यहाँ एक-दो दिन रहूँगा।

Choices: still / yet / for / already

[[English#^en-Q0710-answer|Compare the answer]]
^en-Q0710

**en-Q0711 · Edit the changed sentence**

I had met her many times 【already】 then.

मैं उससे पहले कई बार मिल चुका था।

[[English#^en-Q0711-answer|Compare the answer]]
^en-Q0711

**en-Q0712 · Build the sentence**

Arrange: met / I / had / before / then. / her / times / many

मैं उससे पहले कई बार मिल चुका था।

[[English#^en-Q0712-answer|Compare the answer]]
^en-Q0712

**en-Q0713 · Write a translation**

Write this in English: वह बच्चा हालांकि केवल चार साल का ही है, वह अभी से ही सौ तक गिनती कर सकता है।

[[English#^en-Q0713-answer|Compare the answer]]
^en-Q0713

**en-Q0714 · Explain the grammar**

That child is only four, but he can 【already】 count to 100.

वह बच्चा हालांकि केवल चार साल का ही है, वह अभी से ही सौ तक गिनती कर सकता है।

[[English#^en-Q0714-answer|Compare the answer]]
^en-Q0714

**en-Q0715 · Fill the gap**

____ I joined the army, I was a doctor.

सेना में दाखिल होने से पहले में एक वैद्य था।

[[English#^en-Q0715-answer|Compare the answer]]
^en-Q0715

**en-Q0716 · Choose the form**

____ I joined the army, I was a doctor.

सेना में दाखिल होने से पहले में एक वैद्य था।

Choices: yet / Before / still / already

[[English#^en-Q0716-answer|Compare the answer]]
^en-Q0716

**en-Q0717 · Edit the changed sentence**

Will you take us 【already】 a drive next Sunday?

हमें अगले हफ़्ते ड्राईव पर लेजाओगे क्या?

[[English#^en-Q0717-answer|Compare the answer]]
^en-Q0717

**en-Q0718 · Build the sentence**

Arrange: Will / next / take / us / Sunday? / you / for / drive / a

हमें अगले हफ़्ते ड्राईव पर लेजाओगे क्या?

[[English#^en-Q0718-answer|Compare the answer]]
^en-Q0718

**en-Q0719 · Write a translation**

Write this in English: मैंने उसे बहुत दिनों से नहीं देखा है।

[[English#^en-Q0719-answer|Compare the answer]]
^en-Q0719

**en-Q0720 · Explain the grammar**

I haven't seen him 【for】 a long time.

मैंने उसे बहुत दिनों से नहीं देखा है।

[[English#^en-Q0720-answer|Compare the answer]]
^en-Q0720

**en-Q0721 · Fill the gap**

We will have to take off our shoes ____ going in.

हमे अंदर जाने से पहले जूते उतारने होंगे।

[[English#^en-Q0721-answer|Compare the answer]]
^en-Q0721

**en-Q0722 · Choose the form**

We will have to take off our shoes ____ going in.

हमे अंदर जाने से पहले जूते उतारने होंगे।

Choices: yet / before / still / already

[[English#^en-Q0722-answer|Compare the answer]]
^en-Q0722

**en-Q0723 · Edit the changed sentence**

She has worn the same hat 【already】 a month.

उसने एक महीने से वही टोपी पहन रखी है.

[[English#^en-Q0723-answer|Compare the answer]]
^en-Q0723

**en-Q0724 · Build the sentence**

Arrange: worn / for / She / the / has / hat / same / month. / a

उसने एक महीने से वही टोपी पहन रखी है.

[[English#^en-Q0724-answer|Compare the answer]]
^en-Q0724

**en-Q0725 · Write a translation**

Write this in English: उसने पार्सल को परसों भेजा था।

[[English#^en-Q0725-answer|Compare the answer]]
^en-Q0725

**en-Q0726 · Explain the grammar**

He sent out the parcel the day 【before】 yesterday.

उसने पार्सल को परसों भेजा था।

[[English#^en-Q0726-answer|Compare the answer]]
^en-Q0726

**en-Q0727 · Fill the gap**

He took great care, ____ he made a mistake.

उसने बहुत ध्यान लगाकर काम किया, पर फिर भी ग़लती कर बैठा।

[[English#^en-Q0727-answer|Compare the answer]]
^en-Q0727

**en-Q0728 · Choose the form**

He took great care, ____ he made a mistake.

उसने बहुत ध्यान लगाकर काम किया, पर फिर भी ग़लती कर बैठा।

Choices: since / still / yet / already

[[English#^en-Q0728-answer|Compare the answer]]
^en-Q0728


### Comparison and parallel structure · 50 questions

**en-Q0729 · Edit the changed sentence**

One thought driven home is 【than】 than three left on base.

एक क्रियान्वित विचार तीन अधूरे विचारों से कहीं बेहतर है।

[[English#^en-Q0729-answer|Compare the answer]]
^en-Q0729

**en-Q0730 · Build the sentence**

Arrange: three / home / thought / left / than / is / on / driven / One / base. / better

एक क्रियान्वित विचार तीन अधूरे विचारों से कहीं बेहतर है।

[[English#^en-Q0730-answer|Compare the answer]]
^en-Q0730

**en-Q0731 · Write a translation**

Write this in English: अमीर हमेशा गरीबों से ज़्यादा ख़ुश नहीं होते।

[[English#^en-Q0731-answer|Compare the answer]]
^en-Q0731

**en-Q0732 · Explain the grammar**

The rich are not always happier 【than】 the poor.

अमीर हमेशा गरीबों से ज़्यादा ख़ुश नहीं होते।

[[English#^en-Q0732-answer|Compare the answer]]
^en-Q0732

**en-Q0733 · Fill the gap**

Tatoeba is currently unavailable. We are sorry for the inconvenience. You can check our blog or Twitter for ____ information.

तातोएबा इस वक़्त अनुपलब्ध है। असुविधा के लिए हमें खेद है। अधिक जानकारी के लिये आप हमारा ब्लॉग या ट्विटर देख सकते हैं।

[[English#^en-Q0733-answer|Compare the answer]]
^en-Q0733

**en-Q0734 · Choose the form**

Tatoeba is currently unavailable. We are sorry for the inconvenience. You can check our blog or Twitter for ____ information.

तातोएबा इस वक़्त अनुपलब्ध है। असुविधा के लिए हमें खेद है। अधिक जानकारी के लिये आप हमारा ब्लॉग या ट्विटर देख सकते हैं।

Choices: as / less / than / more

[[English#^en-Q0734-answer|Compare the answer]]
^en-Q0734

**en-Q0735 · Edit the changed sentence**

They say that Firefox is downloaded 【than】 than 8 million times a day.

कहते हैं के फ़ायरफ़ॉक्स प्रतिदिन ८ मिलियन से ज़्यादा बार डाउनलोड किया जाता है।

[[English#^en-Q0735-answer|Compare the answer]]
^en-Q0735

**en-Q0736 · Build the sentence**

Arrange: that / is / a / They / say / 8 / times / downloaded / than / million / Firefox / day. / more

कहते हैं के फ़ायरफ़ॉक्स प्रतिदिन ८ मिलियन से ज़्यादा बार डाउनलोड किया जाता है।

[[English#^en-Q0736-answer|Compare the answer]]
^en-Q0736

**en-Q0737 · Write a translation**

Write this in English: मैंने एक लाल कार और सफ़ेद कार देखि. लाल कार सफ़ेद कार से दिखने में ज्यादा अछी थी.

[[English#^en-Q0737-answer|Compare the answer]]
^en-Q0737

**en-Q0738 · Explain the grammar**

I saw a red car and a white one. The red one was nicer looking 【than】 the white one.

मैंने एक लाल कार और सफ़ेद कार देखि. लाल कार सफ़ेद कार से दिखने में ज्यादा अछी थी.

[[English#^en-Q0738-answer|Compare the answer]]
^en-Q0738

**en-Q0739 · Fill the gap**

For some reason I feel ____ alive at night.

पता नहीं क्यों मुझे रात में ज़्यादा ज़िन्दा महसूस होता है।

[[English#^en-Q0739-answer|Compare the answer]]
^en-Q0739

**en-Q0740 · Choose the form**

For some reason I feel ____ alive at night.

पता नहीं क्यों मुझे रात में ज़्यादा ज़िन्दा महसूस होता है।

Choices: less / more / than / as

[[English#^en-Q0740-answer|Compare the answer]]
^en-Q0740

**en-Q0741 · Edit the changed sentence**

I didn't want to spend any 【than】 time in jail.

मैं जेल में और वक्त नहीं बिताना चाहता था।

[[English#^en-Q0741-answer|Compare the answer]]
^en-Q0741

**en-Q0742 · Build the sentence**

Arrange: I / any / in / to / spend / want / jail. / more / didn't / time

मैं जेल में और वक्त नहीं बिताना चाहता था।

[[English#^en-Q0742-answer|Compare the answer]]
^en-Q0742

**en-Q0743 · Write a translation**

Write this in English: आपको एक समय में केवल पांच पुस्तकों को ले जाने की इजाज़त है.

[[English#^en-Q0743-answer|Compare the answer]]
^en-Q0743

**en-Q0744 · Explain the grammar**

You are allowed to check out not 【more】 than five books at a time.

आपको एक समय में केवल पांच पुस्तकों को ले जाने की इजाज़त है.

[[English#^en-Q0744-answer|Compare the answer]]
^en-Q0744

**en-Q0745 · Fill the gap**

Can I extend my stay one ____ night?

मैं एक रात और रह सकता हूँ क्या?

[[English#^en-Q0745-answer|Compare the answer]]
^en-Q0745

**en-Q0746 · Choose the form**

Can I extend my stay one ____ night?

मैं एक रात और रह सकता हूँ क्या?

Choices: less / than / as / more

[[English#^en-Q0746-answer|Compare the answer]]
^en-Q0746

**en-Q0747 · Edit the changed sentence**

I guess I'm not 【than】 smart as you.

मुझे लगता है मैं आपकी तरह चुस्त नहीं हूँ.

[[English#^en-Q0747-answer|Compare the answer]]
^en-Q0747

**en-Q0748 · Build the sentence**

Arrange: you. / as / I'm / smart / as / I / not / guess

मुझे लगता है मैं आपकी तरह चुस्त नहीं हूँ.

[[English#^en-Q0748-answer|Compare the answer]]
^en-Q0748

**en-Q0749 · Write a translation**

Write this in English: गांववालें अजनबी को अपना दुश्मन मानते थे।

[[English#^en-Q0749-answer|Compare the answer]]
^en-Q0749

**en-Q0750 · Explain the grammar**

The villagers regarded the stranger 【as】 their enemy.

गांववालें अजनबी को अपना दुश्मन मानते थे।

[[English#^en-Q0750-answer|Compare the answer]]
^en-Q0750

**en-Q0751 · Fill the gap**

Natural mineral water contains calcium, magnesium, sodium, potassium ____ well as nitrate.

प्राकृतिक खनिज पानी में समाहित है चूर्णातु, भ्राजातु, क्षारातु, दहातु, व भूयीयों भी।

[[English#^en-Q0751-answer|Compare the answer]]
^en-Q0751

**en-Q0752 · Choose the form**

Natural mineral water contains calcium, magnesium, sodium, potassium ____ well as nitrate.

प्राकृतिक खनिज पानी में समाहित है चूर्णातु, भ्राजातु, क्षारातु, दहातु, व भूयीयों भी।

Choices: more / as / less / than

[[English#^en-Q0752-answer|Compare the answer]]
^en-Q0752

**en-Q0753 · Edit the changed sentence**

I want to get to know you 【than】.

मैं तुम्हे और अच्छी तरह से जानना चाहता हूं।

[[English#^en-Q0753-answer|Compare the answer]]
^en-Q0753

**en-Q0754 · Build the sentence**

Arrange: I / know / better. / get / to / to / you / want

मैं तुम्हे और अच्छी तरह से जानना चाहता हूं।

[[English#^en-Q0754-answer|Compare the answer]]
^en-Q0754

**en-Q0755 · Write a translation**

Write this in English: जैसे दीपक बुझता है, वैसे ही आदमी मरता है।

[[English#^en-Q0755-answer|Compare the answer]]
^en-Q0755

**en-Q0756 · Explain the grammar**

【As】 a light goes out, so a man dies.

जैसे दीपक बुझता है, वैसे ही आदमी मरता है।

[[English#^en-Q0756-answer|Compare the answer]]
^en-Q0756

**en-Q0757 · Fill the gap**

He earns ____ money than he can spend.

वह ज़रूरत से ज़्यादा पैसे कमाता है।

[[English#^en-Q0757-answer|Compare the answer]]
^en-Q0757

**en-Q0758 · Choose the form**

He earns ____ money than he can spend.

वह ज़रूरत से ज़्यादा पैसे कमाता है।

Choices: less / as / than / more

[[English#^en-Q0758-answer|Compare the answer]]
^en-Q0758

**en-Q0759 · Edit the changed sentence**

The older you are, the 【than】 difficult it is to learn a language.

तुम्हारी उम्र जितनी बड़ी होती है, तुम्हारे लिए कोई भाषा सीखना उतना ही कठिन होता है।

[[English#^en-Q0759-answer|Compare the answer]]
^en-Q0759

**en-Q0760 · Build the sentence**

Arrange: a / difficult / to / it / are, / is / language. / older / more / The / the / learn / you

तुम्हारी उम्र जितनी बड़ी होती है, तुम्हारे लिए कोई भाषा सीखना उतना ही कठिन होता है।

[[English#^en-Q0760-answer|Compare the answer]]
^en-Q0760

**en-Q0761 · Write a translation**

Write this in English: काश मेरे पास और समय होता तुम्हारे साथ बात करने के लिए।

[[English#^en-Q0761-answer|Compare the answer]]
^en-Q0761

**en-Q0762 · Explain the grammar**

I wish I had 【more】 time to talk with you.

काश मेरे पास और समय होता तुम्हारे साथ बात करने के लिए।

[[English#^en-Q0762-answer|Compare the answer]]
^en-Q0762

**en-Q0763 · Fill the gap**

I will help you ____ far as I can.

मैं तुम्हारा जितना हो सकेगा उतना मदद करूँगा।

[[English#^en-Q0763-answer|Compare the answer]]
^en-Q0763

**en-Q0764 · Choose the form**

I will help you ____ far as I can.

मैं तुम्हारा जितना हो सकेगा उतना मदद करूँगा।

Choices: more / as / than / less

[[English#^en-Q0764-answer|Compare the answer]]
^en-Q0764

**en-Q0765 · Edit the changed sentence**

I make a lot 【than】 money than he does.

मैं उससे बहुत ज़्यादा कमाता हूँ।

[[English#^en-Q0765-answer|Compare the answer]]
^en-Q0765

**en-Q0766 · Build the sentence**

Arrange: lot / than / money / make / does. / more / I / a / he

मैं उससे बहुत ज़्यादा कमाता हूँ।

[[English#^en-Q0766-answer|Compare the answer]]
^en-Q0766

**en-Q0767 · Write a translation**

Write this in English: जैसा देस, वैसा भेस।

[[English#^en-Q0767-answer|Compare the answer]]
^en-Q0767

**en-Q0768 · Explain the grammar**

When in Rome, do 【as】 the Romans do.

जैसा देस, वैसा भेस।

[[English#^en-Q0768-answer|Compare the answer]]
^en-Q0768

**en-Q0769 · Fill the gap**

In Japan there aren't any lakes bigger ____ Lake Biwa.

जापान में बीवा झील से बड़ी और कोई झील नहीं है।

[[English#^en-Q0769-answer|Compare the answer]]
^en-Q0769

**en-Q0770 · Choose the form**

In Japan there aren't any lakes bigger ____ Lake Biwa.

जापान में बीवा झील से बड़ी और कोई झील नहीं है।

Choices: as / more / than / less

[[English#^en-Q0770-answer|Compare the answer]]
^en-Q0770

**en-Q0771 · Edit the changed sentence**

It looks like rain. You had 【than】 take an umbrella with you.

लगता है कि बारिश होगी। तुम्हे छाता लेकर जाना चाहिए।

[[English#^en-Q0771-answer|Compare the answer]]
^en-Q0771

**en-Q0772 · Build the sentence**

Arrange: umbrella / looks / like / with / rain. / better / take / had / you. / an / It / You

लगता है कि बारिश होगी। तुम्हे छाता लेकर जाना चाहिए।

[[English#^en-Q0772-answer|Compare the answer]]
^en-Q0772

**en-Q0773 · Write a translation**

Write this in English: में होटेल मे पार्ट-टाइम नौकरानी थी, पर मुज़े वो पसंद नहीं था

[[English#^en-Q0773-answer|Compare the answer]]
^en-Q0773

**en-Q0774 · Explain the grammar**

I had a part-time job 【as】 a hotel maid, but I didn't like it very much.

में होटेल मे पार्ट-टाइम नौकरानी थी, पर मुज़े वो पसंद नहीं था

[[English#^en-Q0774-answer|Compare the answer]]
^en-Q0774

**en-Q0775 · Fill the gap**

Saudi Arabia is called "Al-Mamlakah Al-‘Arabiyyah ____-Sa‘ūdiyyah" in Arabic.

सऊदी अरब को अरबी में "अल-मामलकह अल-अरबिय्यह अस-सऊदिय्याह" कहते हैं।

[[English#^en-Q0775-answer|Compare the answer]]
^en-Q0775

**en-Q0776 · Choose the form**

Saudi Arabia is called "Al-Mamlakah Al-‘Arabiyyah ____-Sa‘ūdiyyah" in Arabic.

सऊदी अरब को अरबी में "अल-मामलकह अल-अरबिय्यह अस-सऊदिय्याह" कहते हैं।

Choices: than / more / As / less

[[English#^en-Q0776-answer|Compare the answer]]
^en-Q0776

**en-Q0777 · Edit the changed sentence**

【than】 he was an honest man, I employed him.

वह ईमानदार इनसान था, इसलिए मैंने उसे नौकरी पर रख लिया।

[[English#^en-Q0777-answer|Compare the answer]]
^en-Q0777

**en-Q0778 · Build the sentence**

Arrange: he / an / man, / As / honest / I / employed / him. / was

वह ईमानदार इनसान था, इसलिए मैंने उसे नौकरी पर रख लिया।

[[English#^en-Q0778-answer|Compare the answer]]
^en-Q0778


### Reported speech and stance · 40 questions

**en-Q0779 · Write a translation**

Write this in English: डॉक्टर ने उससे कहा कि उसे आराम लेना चाहिए।

[[English#^en-Q0779-answer|Compare the answer]]
^en-Q0779

**en-Q0780 · Explain the grammar**

The doctor 【told】 her that she should take a rest.

डॉक्टर ने उससे कहा कि उसे आराम लेना चाहिए।

[[English#^en-Q0780-answer|Compare the answer]]
^en-Q0780

**en-Q0781 · Fill the gap**

She ____ me that she wanted a pet dog.

उसने मुझसे कहा कि उसे कुत्ता पालने का मन था।

[[English#^en-Q0781-answer|Compare the answer]]
^en-Q0781

**en-Q0782 · Choose the form**

She ____ me that she wanted a pet dog.

उसने मुझसे कहा कि उसे कुत्ता पालने का मन था।

Choices: claimed / said / suggested / told

[[English#^en-Q0782-answer|Compare the answer]]
^en-Q0782

**en-Q0783 · Edit the changed sentence**

Aksai Chin is 【said】 by India, but controlled by China.

अक्साई चिन पर भारत का दावा है, मगर वह चीन के नियंत्रण में है।

[[English#^en-Q0783-answer|Compare the answer]]
^en-Q0783

**en-Q0784 · Build the sentence**

Arrange: Chin / claimed / China. / controlled / India, / by / is / Aksai / by / but

अक्साई चिन पर भारत का दावा है, मगर वह चीन के नियंत्रण में है।

[[English#^en-Q0784-answer|Compare the answer]]
^en-Q0784

**en-Q0785 · Write a translation**

Write this in English: उसने जैसे बताया था मैंने वैसे किया।

[[English#^en-Q0785-answer|Compare the answer]]
^en-Q0785

**en-Q0786 · Explain the grammar**

I did it the way he 【told】 me to.

उसने जैसे बताया था मैंने वैसे किया।

[[English#^en-Q0786-answer|Compare the answer]]
^en-Q0786

**en-Q0787 · Fill the gap**

Do you think that Tom ____ the truth?

तुम्हारे विचार में क्या टॉम ने सच कहा?

[[English#^en-Q0787-answer|Compare the answer]]
^en-Q0787

**en-Q0788 · Choose the form**

Do you think that Tom ____ the truth?

तुम्हारे विचार में क्या टॉम ने सच कहा?

Choices: claimed / told / said / suggested

[[English#^en-Q0788-answer|Compare the answer]]
^en-Q0788

**en-Q0789 · Edit the changed sentence**

He 【told】 he would write to me, but he hasn't.

उसने कहा था कि वह मुझे चिट्ठी लिखेगा, पर उसने अभी तक एक भी चिट्ठी नहीं भेजी है।

[[English#^en-Q0789-answer|Compare the answer]]
^en-Q0789

**en-Q0790 · Build the sentence**

Arrange: would / to / hasn't. / he / write / He / but / he / said / me,

उसने कहा था कि वह मुझे चिट्ठी लिखेगा, पर उसने अभी तक एक भी चिट्ठी नहीं भेजी है।

[[English#^en-Q0790-answer|Compare the answer]]
^en-Q0790

**en-Q0791 · Write a translation**

Write this in English: कोलम्बस ने सोचा कि वह पश्चिम दिशा में जाकर भारत पहुँच सकता था।

[[English#^en-Q0791-answer|Compare the answer]]
^en-Q0791

**en-Q0792 · Explain the grammar**

Columbus 【argued】 that he could reach India by going west.

कोलम्बस ने सोचा कि वह पश्चिम दिशा में जाकर भारत पहुँच सकता था।

[[English#^en-Q0792-answer|Compare the answer]]
^en-Q0792

**en-Q0793 · Fill the gap**

Kenji ____ his friends a story about his trip to India.

केनजी ने उसके दोस्तों को उसके भारत के सफ़र की कहानी सुनाई।

[[English#^en-Q0793-answer|Compare the answer]]
^en-Q0793

**en-Q0794 · Choose the form**

Kenji ____ his friends a story about his trip to India.

केनजी ने उसके दोस्तों को उसके भारत के सफ़र की कहानी सुनाई।

Choices: claimed / suggested / said / told

[[English#^en-Q0794-answer|Compare the answer]]
^en-Q0794

**en-Q0795 · Edit the changed sentence**

My father 【said】 me not to read books in bed.

मेरे पिता ने मुझसे बिस्तर में किताबें पढ़ने से मना किया।

[[English#^en-Q0795-answer|Compare the answer]]
^en-Q0795

**en-Q0796 · Build the sentence**

Arrange: father / read / me / to / told / bed. / in / books / My / not

मेरे पिता ने मुझसे बिस्तर में किताबें पढ़ने से मना किया।

[[English#^en-Q0796-answer|Compare the answer]]
^en-Q0796

**en-Q0797 · Write a translation**

Write this in English: डॉक्टर ने उसे सिगरेट कम पीने को कहा।

[[English#^en-Q0797-answer|Compare the answer]]
^en-Q0797

**en-Q0798 · Explain the grammar**

The doctor 【told】 him to cut down on smoking.

डॉक्टर ने उसे सिगरेट कम पीने को कहा।

[[English#^en-Q0798-answer|Compare the answer]]
^en-Q0798

**en-Q0799 · Fill the gap**

He ____ he would see me the next day.

उसने कहा था कि वह मुझसे अगले दिन मिलेगा।

[[English#^en-Q0799-answer|Compare the answer]]
^en-Q0799

**en-Q0800 · Choose the form**

He ____ he would see me the next day.

उसने कहा था कि वह मुझसे अगले दिन मिलेगा।

Choices: told / suggested / claimed / said

[[English#^en-Q0800-answer|Compare the answer]]
^en-Q0800

**en-Q0801 · Edit the changed sentence**

My companion 【told】 that she was too tired to walk, let alone run.

मेरी साथी ने कहा भागना तो छोड़ो, वह चलने ले किये भी थकी हुई है.

[[English#^en-Q0801-answer|Compare the answer]]
^en-Q0801

**en-Q0802 · Build the sentence**

Arrange: was / walk, / tired / that / to / run. / companion / said / too / let / alone / My / she

मेरी साथी ने कहा भागना तो छोड़ो, वह चलने ले किये भी थकी हुई है.

[[English#^en-Q0802-answer|Compare the answer]]
^en-Q0802

**en-Q0803 · Write a translation**

Write this in English: मेरी माँ ने मुझसे घास काटने के लिए कहा।

[[English#^en-Q0803-answer|Compare the answer]]
^en-Q0803

**en-Q0804 · Explain the grammar**

My mother 【told】 me to do a careless job of it.

मेरी माँ ने मुझसे घास काटने के लिए कहा।

[[English#^en-Q0804-answer|Compare the answer]]
^en-Q0804

**en-Q0805 · Fill the gap**

He is ____ to know a lot about Spain.

कहते है वह स्पेन के बारे में बहुत कुछ जानता है।

[[English#^en-Q0805-answer|Compare the answer]]
^en-Q0805

**en-Q0806 · Choose the form**

He is ____ to know a lot about Spain.

कहते है वह स्पेन के बारे में बहुत कुछ जानता है।

Choices: suggested / told / said / claimed

[[English#^en-Q0806-answer|Compare the answer]]
^en-Q0806

**en-Q0807 · Edit the changed sentence**

They 【told】 Anderson and his men must leave the fort.

उन्होंने कहां के अॅन्डर्सन और उसके आदमियों को गढ़ छोड़ना पड़ेगा।

[[English#^en-Q0807-answer|Compare the answer]]
^en-Q0807

**en-Q0808 · Build the sentence**

Arrange: fort. / the / must / They / Anderson / his / leave / and / said / men

उन्होंने कहां के अॅन्डर्सन और उसके आदमियों को गढ़ छोड़ना पड़ेगा।

[[English#^en-Q0808-answer|Compare the answer]]
^en-Q0808

**en-Q0809 · Write a translation**

Write this in English: उसने वह बात बहुत हल्की आवाज़ में कही।

[[English#^en-Q0809-answer|Compare the answer]]
^en-Q0809

**en-Q0810 · Explain the grammar**

He 【said】 the words in a very small voice.

उसने वह बात बहुत हल्की आवाज़ में कही।

[[English#^en-Q0810-answer|Compare the answer]]
^en-Q0810

**en-Q0811 · Fill the gap**

Take back what you ____ about me being stingy.

जो तुमने मेरे कंजूस होने के बारे में कहा था, उस बात को वापस लो।

[[English#^en-Q0811-answer|Compare the answer]]
^en-Q0811

**en-Q0812 · Choose the form**

Take back what you ____ about me being stingy.

जो तुमने मेरे कंजूस होने के बारे में कहा था, उस बात को वापस लो।

Choices: suggested / told / claimed / said

[[English#^en-Q0812-answer|Compare the answer]]
^en-Q0812

**en-Q0813 · Edit the changed sentence**

The father 【said】 his son that his studies had been completed then so he should go outside and work instead of getting food at home for free.

पिता ने अपने बेटे से कहा कि अब तुम्हारी पढ़ाई पूरी हो गई है। बाहर जाकर नौकरी करो, घर में मुफ्त की रोटियां मत तोड़ो।

[[English#^en-Q0813-answer|Compare the answer]]
^en-Q0813

**en-Q0814 · Build the sentence**

Arrange: free. / so / of / completed / studies / home / told / father / and / he / for / food / his / getting / that / instead / then / go / should / had / work / at / son / The / his / been / outside

पिता ने अपने बेटे से कहा कि अब तुम्हारी पढ़ाई पूरी हो गई है। बाहर जाकर नौकरी करो, घर में मुफ्त की रोटियां मत तोड़ो।

[[English#^en-Q0814-answer|Compare the answer]]
^en-Q0814

**en-Q0815 · Write a translation**

Write this in English: उसने वैसा करा जैसे उसे बताया गया था।

[[English#^en-Q0815-answer|Compare the answer]]
^en-Q0815

**en-Q0816 · Explain the grammar**

He did it as he had been 【told】.

उसने वैसा करा जैसे उसे बताया गया था।

[[English#^en-Q0816-answer|Compare the answer]]
^en-Q0816

**en-Q0817 · Fill the gap**

This is the book about which I ____ you.

यह वह किताब है जिसके बारे में मैंने तुम्हें बताया था।

[[English#^en-Q0817-answer|Compare the answer]]
^en-Q0817

**en-Q0818 · Choose the form**

This is the book about which I ____ you.

यह वह किताब है जिसके बारे में मैंने तुम्हें बताया था।

Choices: suggested / told / said / claimed

[[English#^en-Q0818-answer|Compare the answer]]
^en-Q0818


### Hedging and professional modality · 50 questions

**en-Q0819 · Edit the changed sentence**

When he 【possibly】 not give them higher pay, they went on strike.

जब उसने उनके वेतन बढ़ाने से इनकार कर दिया, उन्होंने हड़ताल कर दी।

[[English#^en-Q0819-answer|Compare the answer]]
^en-Q0819

**en-Q0820 · Build the sentence**

Arrange: them / they / pay, / would / When / higher / on / not / went / give / strike. / he

जब उसने उनके वेतन बढ़ाने से इनकार कर दिया, उन्होंने हड़ताल कर दी।

[[English#^en-Q0820-answer|Compare the answer]]
^en-Q0820

**en-Q0821 · Write a translation**

Write this in English: हमको इस घटना की तहकीकात करने में कम-से-कम तीन हफ़्ते लगेंगे।

[[English#^en-Q0821-answer|Compare the answer]]
^en-Q0821

**en-Q0822 · Explain the grammar**

To investigate the incident 【would】 take us at least three weeks.

हमको इस घटना की तहकीकात करने में कम-से-कम तीन हफ़्ते लगेंगे।

[[English#^en-Q0822-answer|Compare the answer]]
^en-Q0822

**en-Q0823 · Fill the gap**

You ____ not speak of others behind their backs.

तुम्हे लोगों की पीठ-पीछे बात नहीं करनी चाहिए।

[[English#^en-Q0823-answer|Compare the answer]]
^en-Q0823

**en-Q0824 · Choose the form**

You ____ not speak of others behind their backs.

तुम्हे लोगों की पीठ-पीछे बात नहीं करनी चाहिए।

Choices: probably / perhaps / should / possibly

[[English#^en-Q0824-answer|Compare the answer]]
^en-Q0824

**en-Q0825 · Edit the changed sentence**

You can't have everything. Where 【possibly】 you put it?

आप को सब कुछ नहीं मिल सकता। आप इसे रखेंगे कहां?

[[English#^en-Q0825-answer|Compare the answer]]
^en-Q0825

**en-Q0826 · Build the sentence**

Arrange: everything. / put / can't / Where / it? / you / would / You / have

आप को सब कुछ नहीं मिल सकता। आप इसे रखेंगे कहां?

[[English#^en-Q0826-answer|Compare the answer]]
^en-Q0826

**en-Q0827 · Write a translation**

Write this in English: तुमको लोगों कि पीठ के पीछे उनकी बुराई नहीं करनी चाहिए।

[[English#^en-Q0827-answer|Compare the answer]]
^en-Q0827

**en-Q0828 · Explain the grammar**

You 【should】 not speak ill of others behind their backs.

तुमको लोगों कि पीठ के पीछे उनकी बुराई नहीं करनी चाहिए।

[[English#^en-Q0828-answer|Compare the answer]]
^en-Q0828

**en-Q0829 · Fill the gap**

The king ordered that the prisoner ____ be set free.

राजा ने हुक़्म दिया कि क़ैदी को रिहा कर दिया जाए।

[[English#^en-Q0829-answer|Compare the answer]]
^en-Q0829

**en-Q0830 · Choose the form**

The king ordered that the prisoner ____ be set free.

राजा ने हुक़्म दिया कि क़ैदी को रिहा कर दिया जाए।

Choices: probably / should / possibly / perhaps

[[English#^en-Q0830-answer|Compare the answer]]
^en-Q0830

**en-Q0831 · Edit the changed sentence**

Russia 【possibly】 give the Kuril Islands back to Japan.

रूस ने कुरील द्वीप जापान को लौटाने चाहिए।

[[English#^en-Q0831-answer|Compare the answer]]
^en-Q0831

**en-Q0832 · Build the sentence**

Arrange: give / Russia / Kuril / Islands / Japan. / back / should / the / to

रूस ने कुरील द्वीप जापान को लौटाने चाहिए।

[[English#^en-Q0832-answer|Compare the answer]]
^en-Q0832

**en-Q0833 · Write a translation**

Write this in English: कोई भी सुशील इनसान सड़क पर थूकेगा नहीं।

[[English#^en-Q0833-answer|Compare the answer]]
^en-Q0833

**en-Q0834 · Explain the grammar**

A gentleman 【would】 not spit on the street.

कोई भी सुशील इनसान सड़क पर थूकेगा नहीं।

[[English#^en-Q0834-answer|Compare the answer]]
^en-Q0834

**en-Q0835 · Fill the gap**

Where do you think we ____ pitch our tent?

आपके विचार में हमें अपना तम्बू कहाँ गाड़ना चाहिए?

[[English#^en-Q0835-answer|Compare the answer]]
^en-Q0835

**en-Q0836 · Choose the form**

Where do you think we ____ pitch our tent?

आपके विचार में हमें अपना तम्बू कहाँ गाड़ना चाहिए?

Choices: probably / possibly / perhaps / should

[[English#^en-Q0836-answer|Compare the answer]]
^en-Q0836

**en-Q0837 · Edit the changed sentence**

What 【possibly】 you do to decrease your debt?

अपने ऋण को कम करने के लिये क्या करना चाहिए?

[[English#^en-Q0837-answer|Compare the answer]]
^en-Q0837

**en-Q0838 · Build the sentence**

Arrange: decrease / to / you / What / debt? / your / should / do

अपने ऋण को कम करने के लिये क्या करना चाहिए?

[[English#^en-Q0838-answer|Compare the answer]]
^en-Q0838

**en-Q0839 · Write a translation**

Write this in English: जवान हो तब तक तुम्हें कड़ी मेहनत से काम करना चाहिए।

[[English#^en-Q0839-answer|Compare the answer]]
^en-Q0839

**en-Q0840 · Explain the grammar**

You 【should】 work hard while you are young.

जवान हो तब तक तुम्हें कड़ी मेहनत से काम करना चाहिए।

[[English#^en-Q0840-answer|Compare the answer]]
^en-Q0840

**en-Q0841 · Fill the gap**

From what you can tell, what subject ____ he have interest in?

तुम्हारे हिसाब से उसे किस विषय में दिलचस्पी होगी?

[[English#^en-Q0841-answer|Compare the answer]]
^en-Q0841

**en-Q0842 · Choose the form**

From what you can tell, what subject ____ he have interest in?

तुम्हारे हिसाब से उसे किस विषय में दिलचस्पी होगी?

Choices: perhaps / possibly / probably / would

[[English#^en-Q0842-answer|Compare the answer]]
^en-Q0842

**en-Q0843 · Edit the changed sentence**

【possibly】 you please explain the rules to me?

आप मुझे नियम समझा सकते हैं क्या?

[[English#^en-Q0843-answer|Compare the answer]]
^en-Q0843

**en-Q0844 · Build the sentence**

Arrange: explain / you / Would / the / to / me? / please / rules

आप मुझे नियम समझा सकते हैं क्या?

[[English#^en-Q0844-answer|Compare the answer]]
^en-Q0844

**en-Q0845 · Write a translation**

Write this in English: मैं वह द्रिश्य देख नहीं सका।

[[English#^en-Q0845-answer|Compare the answer]]
^en-Q0845

**en-Q0846 · Explain the grammar**

I 【could】 not bear to see the scene.

मैं वह द्रिश्य देख नहीं सका।

[[English#^en-Q0846-answer|Compare the answer]]
^en-Q0846

**en-Q0847 · Fill the gap**

It's gotten too late, I ____ go back.

बहुत देर हो गई है, मुझे वापस जाना चहिए।

[[English#^en-Q0847-answer|Compare the answer]]
^en-Q0847

**en-Q0848 · Choose the form**

It's gotten too late, I ____ go back.

बहुत देर हो गई है, मुझे वापस जाना चहिए।

Choices: perhaps / possibly / should / probably

[[English#^en-Q0848-answer|Compare the answer]]
^en-Q0848

**en-Q0849 · Edit the changed sentence**

【possibly】 I be going soft in the head? I forget things so easily these days.

शायद मैं सटिया गया हूँ। आजकल चीज़ें इतनी आसानी से भूल जाता हूँ।

[[English#^en-Q0849-answer|Compare the answer]]
^en-Q0849

**en-Q0850 · Build the sentence**

Arrange: head? / soft / easily / in / I / things / I / be / going / forget / the / Could / so / these / days.

शायद मैं सटिया गया हूँ। आजकल चीज़ें इतनी आसानी से भूल जाता हूँ।

[[English#^en-Q0850-answer|Compare the answer]]
^en-Q0850

**en-Q0851 · Write a translation**

Write this in English: क्या हिन्दी भारत भर की पाठशालाओं में सिखाई जानी चाहिए?

[[English#^en-Q0851-answer|Compare the answer]]
^en-Q0851

**en-Q0852 · Explain the grammar**

【Should】 Hindi be taught in schools across India?

क्या हिन्दी भारत भर की पाठशालाओं में सिखाई जानी चाहिए?

[[English#^en-Q0852-answer|Compare the answer]]
^en-Q0852

**en-Q0853 · Fill the gap**

I thought you two ____ have a lot in common.

मैं सोचता था कि तुम दोनो में बहुत सी बातें एक दुसरे से मिलती जुलती होगी।

[[English#^en-Q0853-answer|Compare the answer]]
^en-Q0853

**en-Q0854 · Choose the form**

I thought you two ____ have a lot in common.

मैं सोचता था कि तुम दोनो में बहुत सी बातें एक दुसरे से मिलती जुलती होगी।

Choices: would / probably / perhaps / possibly

[[English#^en-Q0854-answer|Compare the answer]]
^en-Q0854

**en-Q0855 · Edit the changed sentence**

We hurried for fear we 【possibly】 be late for school.

हमने जल्दी करी क्योंकि हमें डर था कि हमें स्कूल पहुँचने में देरी होजाएगी।

[[English#^en-Q0855-answer|Compare the answer]]
^en-Q0855

**en-Q0856 · Build the sentence**

Arrange: we / should / school. / fear / for / be / We / late / for / hurried

हमने जल्दी करी क्योंकि हमें डर था कि हमें स्कूल पहुँचने में देरी होजाएगी।

[[English#^en-Q0856-answer|Compare the answer]]
^en-Q0856

**en-Q0857 · Write a translation**

Write this in English: आप किसी चीज़ का विशद ज्ञान हासिल करना चाहते हैं तो इसे दूसरों को सिखाने लगिए

[[English#^en-Q0857-answer|Compare the answer]]
^en-Q0857

**en-Q0858 · Explain the grammar**

If you 【would】 thoroughly know anything, teach it to others.

आप किसी चीज़ का विशद ज्ञान हासिल करना चाहते हैं तो इसे दूसरों को सिखाने लगिए

[[English#^en-Q0858-answer|Compare the answer]]
^en-Q0858

**en-Q0859 · Fill the gap**

And they ____ play hide and go seek.

और फिर वे लुका-छुप्पी खेलने जाया करते थे।

[[English#^en-Q0859-answer|Compare the answer]]
^en-Q0859

**en-Q0860 · Choose the form**

And they ____ play hide and go seek.

और फिर वे लुका-छुप्पी खेलने जाया करते थे।

Choices: probably / possibly / perhaps / would

[[English#^en-Q0860-answer|Compare the answer]]
^en-Q0860

**en-Q0861 · Edit the changed sentence**

What 【possibly】 you do if you met a lion here?

अगर यहां तुम्हें शेर मिला तो तुम क्या करोगे?

[[English#^en-Q0861-answer|Compare the answer]]
^en-Q0861

**en-Q0862 · Build the sentence**

Arrange: do / you / a / What / lion / if / here? / met / would / you

अगर यहां तुम्हें शेर मिला तो तुम क्या करोगे?

[[English#^en-Q0862-answer|Compare the answer]]
^en-Q0862

**en-Q0863 · Write a translation**

Write this in English: हमने मान लिया था कि वह हमारे साथ आएगा।

[[English#^en-Q0863-answer|Compare the answer]]
^en-Q0863

**en-Q0864 · Explain the grammar**

We took it for granted that he 【would】 join us.

हमने मान लिया था कि वह हमारे साथ आएगा।

[[English#^en-Q0864-answer|Compare the answer]]
^en-Q0864

**en-Q0865 · Fill the gap**

You ____ try to conquer your smoking habit.

तुम्हें अपने सिगरेट पीने पर रोक लगाने की कोशिश करनी चाहिए।

[[English#^en-Q0865-answer|Compare the answer]]
^en-Q0865

**en-Q0866 · Choose the form**

You ____ try to conquer your smoking habit.

तुम्हें अपने सिगरेट पीने पर रोक लगाने की कोशिश करनी चाहिए।

Choices: probably / possibly / should / perhaps

[[English#^en-Q0866-answer|Compare the answer]]
^en-Q0866

**en-Q0867 · Edit the changed sentence**

You 【possibly】 take care of your sick mother.

तुम्हे अपनी बीमार माँ का ख़याल रखना चाहिए।

[[English#^en-Q0867-answer|Compare the answer]]
^en-Q0867

**en-Q0868 · Build the sentence**

Arrange: take / care / You / sick / your / mother. / should / of

तुम्हे अपनी बीमार माँ का ख़याल रखना चाहिए।

[[English#^en-Q0868-answer|Compare the answer]]
^en-Q0868


## Answers

The full sentence is a model. For translation, judge whether meaning and grammar are preserved. Each grammar rule above explains the form.

### Answers 1–50

**en-Q0001** — This is the opposite of what I expected.

मुझे जो अपेक्षा थी उसके यह विपरीत है।

Expected form: **the**

Why: Articles, countability and reference. [[English#^en-Q0001|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=This%20is%20the%20opposite%20of%20what%20I%20expected.)
^en-Q0001-answer

**en-Q0002** — This is the opposite of what I expected.

मुझे जो अपेक्षा थी उसके यह विपरीत है।

Expected form: **the**

Why: Articles, countability and reference. [[English#^en-Q0002|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=This%20is%20the%20opposite%20of%20what%20I%20expected.)
^en-Q0002-answer

**en-Q0003** — My grandfather was murdered during the Second World War.

दूसरे विश्वयुद्ध के दौरान मेरे दादा का खून हुआ था।

Expected form: **the**

Why: Articles, countability and reference. [[English#^en-Q0003|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=My%20grandfather%20was%20murdered%20during%20the%20Second%20World%20War.)
^en-Q0003-answer

**en-Q0004** — My grandfather was murdered during the Second World War.

दूसरे विश्वयुद्ध के दौरान मेरे दादा का खून हुआ था।

Why: Articles, countability and reference. [[English#^en-Q0004|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=My%20grandfather%20was%20murdered%20during%20the%20Second%20World%20War.)
^en-Q0004-answer

**en-Q0005** — He entered the room slowly by that door.

वह उस दरवाज़े से धीरे से कमरे में घुसा।

Why: Articles, countability and reference. [[English#^en-Q0005|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%20entered%20the%20room%20slowly%20by%20that%20door.)
^en-Q0005-answer

**en-Q0006** — He entered the room slowly by that door.

वह उस दरवाज़े से धीरे से कमरे में घुसा।

Article choice reflects reference and countability. A/an selects a singular countable noun and follows the initial sound, not the first letter. Research and evidence are normally uncountable in academic uses; experience can change countability with meaning.

Why: Articles, countability and reference. [[English#^en-Q0006|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%20entered%20the%20room%20slowly%20by%20that%20door.)
^en-Q0006-answer

**en-Q0007** — Men whose mothers had breast cancer run a higher risk of developing prostate cancer.

जिन मर्दों की माताओं को छाती का कैंसर था उनको प्रोस्ट्रेट कैंसर होने का अधिक खदशा रहता है |

Expected form: **a**

Why: Articles, countability and reference. [[English#^en-Q0007|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Men%20whose%20mothers%20had%20breast%20cancer%20run%20a%20higher%20risk%20of%20developing%20prostate%20cancer.)
^en-Q0007-answer

**en-Q0008** — Men whose mothers had breast cancer run a higher risk of developing prostate cancer.

जिन मर्दों की माताओं को छाती का कैंसर था उनको प्रोस्ट्रेट कैंसर होने का अधिक खदशा रहता है |

Expected form: **a**

Why: Articles, countability and reference. [[English#^en-Q0008|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Men%20whose%20mothers%20had%20breast%20cancer%20run%20a%20higher%20risk%20of%20developing%20prostate%20cancer.)
^en-Q0008-answer

**en-Q0009** — Terrorists attacked the World Trade Center in New York City in 2001.

२००१ में न्यूयॉर्क शहर में आतंकवादियों वर्ल्ड ट्रेड सेंटर पर हमला किया।

Expected form: **the**

Why: Articles, countability and reference. [[English#^en-Q0009|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Terrorists%20attacked%20the%20World%20Trade%20Center%20in%20New%20York%20City%20in%202001.)
^en-Q0009-answer

**en-Q0010** — Terrorists attacked the World Trade Center in New York City in 2001.

२००१ में न्यूयॉर्क शहर में आतंकवादियों वर्ल्ड ट्रेड सेंटर पर हमला किया।

Why: Articles, countability and reference. [[English#^en-Q0010|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Terrorists%20attacked%20the%20World%20Trade%20Center%20in%20New%20York%20City%20in%202001.)
^en-Q0010-answer

**en-Q0011** — The heron had to hunt for food every day.

बगुले को हर दिन भोजन के लिए शिकार करना पड़ता था।

Why: Articles, countability and reference. [[English#^en-Q0011|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20heron%20had%20to%20hunt%20for%20food%20every%20day.)
^en-Q0011-answer

**en-Q0012** — The heron had to hunt for food every day.

बगुले को हर दिन भोजन के लिए शिकार करना पड़ता था।

Article choice reflects reference and countability. A/an selects a singular countable noun and follows the initial sound, not the first letter. Research and evidence are normally uncountable in academic uses; experience can change countability with meaning.

Why: Articles, countability and reference. [[English#^en-Q0012|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20heron%20had%20to%20hunt%20for%20food%20every%20day.)
^en-Q0012-answer

**en-Q0013** — Opening the door, I found a stranger standing there.

मैंने जब दरवाज़ा खोला, मुझे एक अजनबी वहाँ खड़ा मिला।

Expected form: **the**

Why: Articles, countability and reference. [[English#^en-Q0013|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Opening%20the%20door%2C%20I%20found%20a%20stranger%20standing%20there.)
^en-Q0013-answer

**en-Q0014** — Opening the door, I found a stranger standing there.

मैंने जब दरवाज़ा खोला, मुझे एक अजनबी वहाँ खड़ा मिला।

Expected form: **the**

Why: Articles, countability and reference. [[English#^en-Q0014|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Opening%20the%20door%2C%20I%20found%20a%20stranger%20standing%20there.)
^en-Q0014-answer

**en-Q0015** — Do you keep your money in a bank?

क्या आप अपने पैसे बैंक में रखते हैं?

Expected form: **a**

Why: Articles, countability and reference. [[English#^en-Q0015|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Do%20you%20keep%20your%20money%20in%20a%20bank%3F)
^en-Q0015-answer

**en-Q0016** — Do you keep your money in a bank?

क्या आप अपने पैसे बैंक में रखते हैं?

Why: Articles, countability and reference. [[English#^en-Q0016|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Do%20you%20keep%20your%20money%20in%20a%20bank%3F)
^en-Q0016-answer

**en-Q0017** — She will become a doctor in two years.

वह दो सालों में डॉक्टर बन जाएगी।

Why: Articles, countability and reference. [[English#^en-Q0017|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=She%20will%20become%20a%20doctor%20in%20two%20years.)
^en-Q0017-answer

**en-Q0018** — She will become a doctor in two years.

वह दो सालों में डॉक्टर बन जाएगी।

Article choice reflects reference and countability. A/an selects a singular countable noun and follows the initial sound, not the first letter. Research and evidence are normally uncountable in academic uses; experience can change countability with meaning.

Why: Articles, countability and reference. [[English#^en-Q0018|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=She%20will%20become%20a%20doctor%20in%20two%20years.)
^en-Q0018-answer

**en-Q0019** — Who were you waiting for at the station?

तुम स्टेशन पर किसका इंतज़ार कर रहे थे?

Expected form: **the**

Why: Articles, countability and reference. [[English#^en-Q0019|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Who%20were%20you%20waiting%20for%20at%20the%20station%3F)
^en-Q0019-answer

**en-Q0020** — Who were you waiting for at the station?

तुम स्टेशन पर किसका इंतज़ार कर रहे थे?

Expected form: **the**

Why: Articles, countability and reference. [[English#^en-Q0020|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Who%20were%20you%20waiting%20for%20at%20the%20station%3F)
^en-Q0020-answer

**en-Q0021** — I haven't had a chance to see the movie yet.

मुझे अभी तक उस फ़िल्म को देखने का मौका नहीं मिला है।

Expected form: **a**

Why: Articles, countability and reference. [[English#^en-Q0021|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20haven%27t%20had%20a%20chance%20to%20see%20the%20movie%20yet.)
^en-Q0021-answer

**en-Q0022** — I haven't had a chance to see the movie yet.

मुझे अभी तक उस फ़िल्म को देखने का मौका नहीं मिला है।

Why: Articles, countability and reference. [[English#^en-Q0022|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20haven%27t%20had%20a%20chance%20to%20see%20the%20movie%20yet.)
^en-Q0022-answer

**en-Q0023** — Why do you talk about him as if he were an old man?

तुम उसके बारे में ऐसे बात क्यों करते हो जैसे कि वह बूढ़ा आदमी हो?

Why: Articles, countability and reference. [[English#^en-Q0023|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Why%20do%20you%20talk%20about%20him%20as%20if%20he%20were%20an%20old%20man%3F)
^en-Q0023-answer

**en-Q0024** — Why do you talk about him as if he were an old man?

तुम उसके बारे में ऐसे बात क्यों करते हो जैसे कि वह बूढ़ा आदमी हो?

Article choice reflects reference and countability. A/an selects a singular countable noun and follows the initial sound, not the first letter. Research and evidence are normally uncountable in academic uses; experience can change countability with meaning.

Why: Articles, countability and reference. [[English#^en-Q0024|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Why%20do%20you%20talk%20about%20him%20as%20if%20he%20were%20an%20old%20man%3F)
^en-Q0024-answer

**en-Q0025** — She reproached me for not answering the letter.

उसने मुझे चिट्ठी का जवाब न देने के लिए डाँटा।

Expected form: **the**

Why: Articles, countability and reference. [[English#^en-Q0025|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=She%20reproached%20me%20for%20not%20answering%20the%20letter.)
^en-Q0025-answer

**en-Q0026** — She reproached me for not answering the letter.

उसने मुझे चिट्ठी का जवाब न देने के लिए डाँटा।

Expected form: **the**

Why: Articles, countability and reference. [[English#^en-Q0026|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=She%20reproached%20me%20for%20not%20answering%20the%20letter.)
^en-Q0026-answer

**en-Q0027** — The people of Boston hated the British soldiers.

बॉस्टन के लोग ब्रिटिश सैनिकों से नफ़रत करते थें।

Expected form: **The**

Why: Articles, countability and reference. [[English#^en-Q0027|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20people%20of%20Boston%20hated%20the%20British%20soldiers.)
^en-Q0027-answer

**en-Q0028** — The people of Boston hated the British soldiers.

बॉस्टन के लोग ब्रिटिश सैनिकों से नफ़रत करते थें।

Why: Articles, countability and reference. [[English#^en-Q0028|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20people%20of%20Boston%20hated%20the%20British%20soldiers.)
^en-Q0028-answer

**en-Q0029** — You'll have to work hard if you want to pass the exam.

अगर तुम्हे परीक्षा पास करनी है तो मन लगाकर काम करना होगा।

Why: Articles, countability and reference. [[English#^en-Q0029|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=You%27ll%20have%20to%20work%20hard%20if%20you%20want%20to%20pass%20the%20exam.)
^en-Q0029-answer

**en-Q0030** — You'll have to work hard if you want to pass the exam.

अगर तुम्हे परीक्षा पास करनी है तो मन लगाकर काम करना होगा।

Article choice reflects reference and countability. A/an selects a singular countable noun and follows the initial sound, not the first letter. Research and evidence are normally uncountable in academic uses; experience can change countability with meaning.

Why: Articles, countability and reference. [[English#^en-Q0030|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=You%27ll%20have%20to%20work%20hard%20if%20you%20want%20to%20pass%20the%20exam.)
^en-Q0030-answer

**en-Q0031** — For once in my life I'm doing a good deed... And it is useless.

मैंने ज़िन्दगी में पहली बार कोई अच्छा काम किया पर वह भी बेकार निकला।

Expected form: **a**

Why: Articles, countability and reference. [[English#^en-Q0031|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=For%20once%20in%20my%20life%20I%27m%20doing%20a%20good%20deed...%20And%20it%20is%20useless.)
^en-Q0031-answer

**en-Q0032** — For once in my life I'm doing a good deed... And it is useless.

मैंने ज़िन्दगी में पहली बार कोई अच्छा काम किया पर वह भी बेकार निकला।

Expected form: **a**

Why: Articles, countability and reference. [[English#^en-Q0032|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=For%20once%20in%20my%20life%20I%27m%20doing%20a%20good%20deed...%20And%20it%20is%20useless.)
^en-Q0032-answer

**en-Q0033** — He ran away in the direction of the wood.

वह जंगल की दिशा में भाग गया।

Expected form: **the**

Why: Articles, countability and reference. [[English#^en-Q0033|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%20ran%20away%20in%20the%20direction%20of%20the%20wood.)
^en-Q0033-answer

**en-Q0034** — He ran away in the direction of the wood.

वह जंगल की दिशा में भाग गया।

Why: Articles, countability and reference. [[English#^en-Q0034|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%20ran%20away%20in%20the%20direction%20of%20the%20wood.)
^en-Q0034-answer

**en-Q0035** — The purest affection the heart can hold is the honest love of a nine-year-old.

मन जो स्नेह संजो सकता है उन में से सबसे पवित्र है किसी नौ वर्षीय का निश्छल प्रेम।

Why: Articles, countability and reference. [[English#^en-Q0035|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20purest%20affection%20the%20heart%20can%20hold%20is%20the%20honest%20love%20of%20a%20nine-year-old.)
^en-Q0035-answer

**en-Q0036** — The purest affection the heart can hold is the honest love of a nine-year-old.

मन जो स्नेह संजो सकता है उन में से सबसे पवित्र है किसी नौ वर्षीय का निश्छल प्रेम।

Article choice reflects reference and countability. A/an selects a singular countable noun and follows the initial sound, not the first letter. Research and evidence are normally uncountable in academic uses; experience can change countability with meaning.

Why: Articles, countability and reference. [[English#^en-Q0036|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20purest%20affection%20the%20heart%20can%20hold%20is%20the%20honest%20love%20of%20a%20nine-year-old.)
^en-Q0036-answer

**en-Q0037** — What's the height of the Empire State Building?

एम्पायर स्टेट बिल्डिंग की ऊँचाई कितनी है?

Expected form: **the**

Why: Articles, countability and reference. [[English#^en-Q0037|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=What%27s%20the%20height%20of%20the%20Empire%20State%20Building%3F)
^en-Q0037-answer

**en-Q0038** — What's the height of the Empire State Building?

एम्पायर स्टेट बिल्डिंग की ऊँचाई कितनी है?

Expected form: **the**

Why: Articles, countability and reference. [[English#^en-Q0038|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=What%27s%20the%20height%20of%20the%20Empire%20State%20Building%3F)
^en-Q0038-answer

**en-Q0039** — I have lots of work to clear up by the weekend.

मुझे इस हफ़्ते बहुत सारा काम कर के खतम करना है।

Expected form: **the**

Why: Articles, countability and reference. [[English#^en-Q0039|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20have%20lots%20of%20work%20to%20clear%20up%20by%20the%20weekend.)
^en-Q0039-answer

**en-Q0040** — I have lots of work to clear up by the weekend.

मुझे इस हफ़्ते बहुत सारा काम कर के खतम करना है।

Why: Articles, countability and reference. [[English#^en-Q0040|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20have%20lots%20of%20work%20to%20clear%20up%20by%20the%20weekend.)
^en-Q0040-answer

**en-Q0041** — You had better chain up the dog so that he won't bite.

तुम्हें कुत्ते को बांध देना चाहिए जिससे कि वह किसी को काट न ले।

Why: Articles, countability and reference. [[English#^en-Q0041|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=You%20had%20better%20chain%20up%20the%20dog%20so%20that%20he%20won%27t%20bite.)
^en-Q0041-answer

**en-Q0042** — You had better chain up the dog so that he won't bite.

तुम्हें कुत्ते को बांध देना चाहिए जिससे कि वह किसी को काट न ले।

Article choice reflects reference and countability. A/an selects a singular countable noun and follows the initial sound, not the first letter. Research and evidence are normally uncountable in academic uses; experience can change countability with meaning.

Why: Articles, countability and reference. [[English#^en-Q0042|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=You%20had%20better%20chain%20up%20the%20dog%20so%20that%20he%20won%27t%20bite.)
^en-Q0042-answer

**en-Q0043** — The bat was stolen yesterday, along with the balls.

बैट और बॉल दोनो कल एकसाथ चोरी हो गए।

Expected form: **The**

Why: Articles, countability and reference. [[English#^en-Q0043|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20bat%20was%20stolen%20yesterday%2C%20along%20with%20the%20balls.)
^en-Q0043-answer

**en-Q0044** — The bat was stolen yesterday, along with the balls.

बैट और बॉल दोनो कल एकसाथ चोरी हो गए।

Expected form: **The**

Why: Articles, countability and reference. [[English#^en-Q0044|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20bat%20was%20stolen%20yesterday%2C%20along%20with%20the%20balls.)
^en-Q0044-answer

**en-Q0045** — Even Japanese people make mistakes using the prefixes 'o' and 'go'.

"ओ" और "गो" इन उपसर्गों के उपयोग में जापानी लोग भी गलतीयाँ करते हैं।

Expected form: **the**

Why: Articles, countability and reference. [[English#^en-Q0045|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Even%20Japanese%20people%20make%20mistakes%20using%20the%20prefixes%20%27o%27%20and%20%27go%27.)
^en-Q0045-answer

**en-Q0046** — Even Japanese people make mistakes using the prefixes 'o' and 'go'.

"ओ" और "गो" इन उपसर्गों के उपयोग में जापानी लोग भी गलतीयाँ करते हैं।

Why: Articles, countability and reference. [[English#^en-Q0046|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Even%20Japanese%20people%20make%20mistakes%20using%20the%20prefixes%20%27o%27%20and%20%27go%27.)
^en-Q0046-answer

**en-Q0047** — I have no time to help you with the work.

मेरे पास तुम्हारी काम में मदद करने के लिए समय नहीं है।

Why: Articles, countability and reference. [[English#^en-Q0047|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20have%20no%20time%20to%20help%20you%20with%20the%20work.)
^en-Q0047-answer

**en-Q0048** — I have no time to help you with the work.

मेरे पास तुम्हारी काम में मदद करने के लिए समय नहीं है।

Article choice reflects reference and countability. A/an selects a singular countable noun and follows the initial sound, not the first letter. Research and evidence are normally uncountable in academic uses; experience can change countability with meaning.

Why: Articles, countability and reference. [[English#^en-Q0048|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20have%20no%20time%20to%20help%20you%20with%20the%20work.)
^en-Q0048-answer

**en-Q0049** — The novel is centered on the Civil War.

यह उपन्यास सिविल वॉर के बारे में है।

Expected form: **The**

Why: Articles, countability and reference. [[English#^en-Q0049|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20novel%20is%20centered%20on%20the%20Civil%20War.)
^en-Q0049-answer

**en-Q0050** — The novel is centered on the Civil War.

यह उपन्यास सिविल वॉर के बारे में है।

Expected form: **The**

Why: Articles, countability and reference. [[English#^en-Q0050|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20novel%20is%20centered%20on%20the%20Civil%20War.)
^en-Q0050-answer


### Answers 51–100

**en-Q0051** — Please give me the paper when you have done with it.

जब आपने अखबार पढ़ लिया हो तो मुझे दे दीजिएगा।

Expected form: **have**

Why: Perfect auxiliaries and reference time. [[English#^en-Q0051|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Please%20give%20me%20the%20paper%20when%20you%20have%20done%20with%20it.)
^en-Q0051-answer

**en-Q0052** — Please give me the paper when you have done with it.

जब आपने अखबार पढ़ लिया हो तो मुझे दे दीजिएगा।

Why: Perfect auxiliaries and reference time. [[English#^en-Q0052|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Please%20give%20me%20the%20paper%20when%20you%20have%20done%20with%20it.)
^en-Q0052-answer

**en-Q0053** — His health has enabled him to succeed in life.

उसके स्वास्थ्य ने उसको ज़िन्दगी में कामयाब होने दिया है।

Why: Perfect auxiliaries and reference time. [[English#^en-Q0053|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=His%20health%20has%20enabled%20him%20to%20succeed%20in%20life.)
^en-Q0053-answer

**en-Q0054** — His health has enabled him to succeed in life.

उसके स्वास्थ्य ने उसको ज़िन्दगी में कामयाब होने दिया है।

A perfect relates an earlier situation to a reference time. Have/has normally anchors the present; had anchors a past reference point. The auxiliary can also be ordinary possession, so inspect the participle and time phrase.

Why: Perfect auxiliaries and reference time. [[English#^en-Q0054|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=His%20health%20has%20enabled%20him%20to%20succeed%20in%20life.)
^en-Q0054-answer

**en-Q0055** — My pen has run out of ink! Can I borrow your pen?

मेरी कलम में स्याही खतम हो गई है। मैं तुम्हारी कलम ले सकता हूँ क्या?

Expected form: **has**

Why: Perfect auxiliaries and reference time. [[English#^en-Q0055|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=My%20pen%20has%20run%20out%20of%20ink%21%20Can%20I%20borrow%20your%20pen%3F)
^en-Q0055-answer

**en-Q0056** — My pen has run out of ink! Can I borrow your pen?

मेरी कलम में स्याही खतम हो गई है। मैं तुम्हारी कलम ले सकता हूँ क्या?

Expected form: **has**

Why: Perfect auxiliaries and reference time. [[English#^en-Q0056|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=My%20pen%20has%20run%20out%20of%20ink%21%20Can%20I%20borrow%20your%20pen%3F)
^en-Q0056-answer

**en-Q0057** — This museum has been closed for five years.

यह म्युज़ियम पाँच साल से बंद है।

Expected form: **has**

Why: Perfect auxiliaries and reference time. [[English#^en-Q0057|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=This%20museum%20has%20been%20closed%20for%20five%20years.)
^en-Q0057-answer

**en-Q0058** — This museum has been closed for five years.

यह म्युज़ियम पाँच साल से बंद है।

Why: Perfect auxiliaries and reference time. [[English#^en-Q0058|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=This%20museum%20has%20been%20closed%20for%20five%20years.)
^en-Q0058-answer

**en-Q0059** — Out of the students, only one had read that book.

विद्यार्थियों में से केवल एक ही ने किताब को पढ़ा था।

Why: Perfect auxiliaries and reference time. [[English#^en-Q0059|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Out%20of%20the%20students%2C%20only%20one%20had%20read%20that%20book.)
^en-Q0059-answer

**en-Q0060** — Out of the students, only one had read that book.

विद्यार्थियों में से केवल एक ही ने किताब को पढ़ा था।

A perfect relates an earlier situation to a reference time. Have/has normally anchors the present; had anchors a past reference point. The auxiliary can also be ordinary possession, so inspect the participle and time phrase.

Why: Perfect auxiliaries and reference time. [[English#^en-Q0060|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Out%20of%20the%20students%2C%20only%20one%20had%20read%20that%20book.)
^en-Q0060-answer

**en-Q0061** — I have been learning English for five years.

मैं पाँच साल से अंग्रेज़ी सीख रहा हूँ।

Expected form: **have**

Why: Perfect auxiliaries and reference time. [[English#^en-Q0061|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20have%20been%20learning%20English%20for%20five%20years.)
^en-Q0061-answer

**en-Q0062** — I have been learning English for five years.

मैं पाँच साल से अंग्रेज़ी सीख रहा हूँ।

Expected form: **have**

Why: Perfect auxiliaries and reference time. [[English#^en-Q0062|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20have%20been%20learning%20English%20for%20five%20years.)
^en-Q0062-answer

**en-Q0063** — They have demanded that all copies of the book be destroyed.

उन्होंने मांग करी है कि इस किताब की सारी कॉपियाँ नष्ट कर दीं जाएं।

Expected form: **have**

Why: Perfect auxiliaries and reference time. [[English#^en-Q0063|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=They%20have%20demanded%20that%20all%20copies%20of%20the%20book%20be%20destroyed.)
^en-Q0063-answer

**en-Q0064** — They have demanded that all copies of the book be destroyed.

उन्होंने मांग करी है कि इस किताब की सारी कॉपियाँ नष्ट कर दीं जाएं।

Why: Perfect auxiliaries and reference time. [[English#^en-Q0064|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=They%20have%20demanded%20that%20all%20copies%20of%20the%20book%20be%20destroyed.)
^en-Q0064-answer

**en-Q0065** — One minute earlier, and they could have caught the bus.

अगर वे एक और मिनट जल्दी पहुँचा होता तो उनकी बस छूट नहीं गई हुई होती।

Why: Perfect auxiliaries and reference time. [[English#^en-Q0065|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=One%20minute%20earlier%2C%20and%20they%20could%20have%20caught%20the%20bus.)
^en-Q0065-answer

**en-Q0066** — One minute earlier, and they could have caught the bus.

अगर वे एक और मिनट जल्दी पहुँचा होता तो उनकी बस छूट नहीं गई हुई होती।

A perfect relates an earlier situation to a reference time. Have/has normally anchors the present; had anchors a past reference point. The auxiliary can also be ordinary possession, so inspect the participle and time phrase.

Why: Perfect auxiliaries and reference time. [[English#^en-Q0066|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=One%20minute%20earlier%2C%20and%20they%20could%20have%20caught%20the%20bus.)
^en-Q0066-answer

**en-Q0067** — Until yesterday, I had known nothing about it.

मुझे कल तक इसके बारे में कुछ भी नहीं पता था।

Expected form: **had**

Why: Perfect auxiliaries and reference time. [[English#^en-Q0067|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Until%20yesterday%2C%20I%20had%20known%20nothing%20about%20it.)
^en-Q0067-answer

**en-Q0068** — Until yesterday, I had known nothing about it.

मुझे कल तक इसके बारे में कुछ भी नहीं पता था।

Expected form: **had**

Why: Perfect auxiliaries and reference time. [[English#^en-Q0068|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Until%20yesterday%2C%20I%20had%20known%20nothing%20about%20it.)
^en-Q0068-answer

**en-Q0069** — I have tried innumerable times to contact him.

मैं बहुत बार उससे सम्पर्क करने की कोशिश कर चुकी हूँ।

Expected form: **have**

Why: Perfect auxiliaries and reference time. [[English#^en-Q0069|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20have%20tried%20innumerable%20times%20to%20contact%20him.)
^en-Q0069-answer

**en-Q0070** — I have tried innumerable times to contact him.

मैं बहुत बार उससे सम्पर्क करने की कोशिश कर चुकी हूँ।

Why: Perfect auxiliaries and reference time. [[English#^en-Q0070|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20have%20tried%20innumerable%20times%20to%20contact%20him.)
^en-Q0070-answer

**en-Q0071** — Democracy is the worst form of government, except all the others that have been tried.

लोकतंत्र सरकार का सबसे घिनौना रूप है, अगर बाकी सारी तरह की सरकारों को अंदेखा किया जाए तो।

Why: Perfect auxiliaries and reference time. [[English#^en-Q0071|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Democracy%20is%20the%20worst%20form%20of%20government%2C%20except%20all%20the%20others%20that%20have%20been%20tried.)
^en-Q0071-answer

**en-Q0072** — Democracy is the worst form of government, except all the others that have been tried.

लोकतंत्र सरकार का सबसे घिनौना रूप है, अगर बाकी सारी तरह की सरकारों को अंदेखा किया जाए तो।

A perfect relates an earlier situation to a reference time. Have/has normally anchors the present; had anchors a past reference point. The auxiliary can also be ordinary possession, so inspect the participle and time phrase.

Why: Perfect auxiliaries and reference time. [[English#^en-Q0072|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Democracy%20is%20the%20worst%20form%20of%20government%2C%20except%20all%20the%20others%20that%20have%20been%20tried.)
^en-Q0072-answer

**en-Q0073** — I have been living here for three years.

मैं यहां तीन सोलों से रहते आया हूं।

Expected form: **have**

Why: Perfect auxiliaries and reference time. [[English#^en-Q0073|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20have%20been%20living%20here%20for%20three%20years.)
^en-Q0073-answer

**en-Q0074** — I have been living here for three years.

मैं यहां तीन सोलों से रहते आया हूं।

Expected form: **have**

Why: Perfect auxiliaries and reference time. [[English#^en-Q0074|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20have%20been%20living%20here%20for%20three%20years.)
^en-Q0074-answer

**en-Q0075** — Carol has been studying Spanish for three years.

कैरल तीन साल से स्पैनिश पढ़ रही है।

Expected form: **has**

Why: Perfect auxiliaries and reference time. [[English#^en-Q0075|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Carol%20has%20been%20studying%20Spanish%20for%20three%20years.)
^en-Q0075-answer

**en-Q0076** — Carol has been studying Spanish for three years.

कैरल तीन साल से स्पैनिश पढ़ रही है।

Why: Perfect auxiliaries and reference time. [[English#^en-Q0076|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Carol%20has%20been%20studying%20Spanish%20for%20three%20years.)
^en-Q0076-answer

**en-Q0077** — Japan had defeated Russia in a war in 1905.

१९०५ में जापान ने रूस को एक युद्ध में हराया था।

Why: Perfect auxiliaries and reference time. [[English#^en-Q0077|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Japan%20had%20defeated%20Russia%20in%20a%20war%20in%201905.)
^en-Q0077-answer

**en-Q0078** — Japan had defeated Russia in a war in 1905.

१९०५ में जापान ने रूस को एक युद्ध में हराया था।

A perfect relates an earlier situation to a reference time. Have/has normally anchors the present; had anchors a past reference point. The auxiliary can also be ordinary possession, so inspect the participle and time phrase.

Why: Perfect auxiliaries and reference time. [[English#^en-Q0078|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Japan%20had%20defeated%20Russia%20in%20a%20war%20in%201905.)
^en-Q0078-answer

**en-Q0079** — You ought not to have spent so much money on your hobby.

तुम्हें अपने शौक पर इतने सारे पैसे खर्च नहीं करने चाहिए थे।

Expected form: **have**

Why: Perfect auxiliaries and reference time. [[English#^en-Q0079|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=You%20ought%20not%20to%20have%20spent%20so%20much%20money%20on%20your%20hobby.)
^en-Q0079-answer

**en-Q0080** — You ought not to have spent so much money on your hobby.

तुम्हें अपने शौक पर इतने सारे पैसे खर्च नहीं करने चाहिए थे।

Expected form: **have**

Why: Perfect auxiliaries and reference time. [[English#^en-Q0080|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=You%20ought%20not%20to%20have%20spent%20so%20much%20money%20on%20your%20hobby.)
^en-Q0080-answer

**en-Q0081** — She has been with me through the ebb and flow of my fortunes.

वे मेरी किस्मत के उतार चढ़ाव में लगातार मेरे साथ रहीं हैं।

Expected form: **has**

Why: Perfect auxiliaries and reference time. [[English#^en-Q0081|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=She%20has%20been%20with%20me%20through%20the%20ebb%20and%20flow%20of%20my%20fortunes.)
^en-Q0081-answer

**en-Q0082** — She has been with me through the ebb and flow of my fortunes.

वे मेरी किस्मत के उतार चढ़ाव में लगातार मेरे साथ रहीं हैं।

Why: Perfect auxiliaries and reference time. [[English#^en-Q0082|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=She%20has%20been%20with%20me%20through%20the%20ebb%20and%20flow%20of%20my%20fortunes.)
^en-Q0082-answer

**en-Q0083** — If it had not been for her help, you would never have done it.

उसकी मदद के बिना तुम नहीं कर पाते।

Why: Perfect auxiliaries and reference time. [[English#^en-Q0083|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=If%20it%20had%20not%20been%20for%20her%20help%2C%20you%20would%20never%20have%20done%20it.)
^en-Q0083-answer

**en-Q0084** — If it had not been for her help, you would never have done it.

उसकी मदद के बिना तुम नहीं कर पाते।

A perfect relates an earlier situation to a reference time. Have/has normally anchors the present; had anchors a past reference point. The auxiliary can also be ordinary possession, so inspect the participle and time phrase.

Why: Perfect auxiliaries and reference time. [[English#^en-Q0084|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=If%20it%20had%20not%20been%20for%20her%20help%2C%20you%20would%20never%20have%20done%20it.)
^en-Q0084-answer

**en-Q0085** — The depredations of human hunters are thought to have been the key factor that pushed many species to extinction.

ऐसा माना जाता है कि मानव शिकारियों द्वारा की गई लूटमार ही अनेक प्रजातियों के लुप्त होने का बड़ा कारण है।

Expected form: **have**

Why: Perfect auxiliaries and reference time. [[English#^en-Q0085|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20depredations%20of%20human%20hunters%20are%20thought%20to%20have%20been%20the%20key%20factor%20that%20pushed%20many%20species%20to%20extinction.)
^en-Q0085-answer

**en-Q0086** — The depredations of human hunters are thought to have been the key factor that pushed many species to extinction.

ऐसा माना जाता है कि मानव शिकारियों द्वारा की गई लूटमार ही अनेक प्रजातियों के लुप्त होने का बड़ा कारण है।

Expected form: **have**

Why: Perfect auxiliaries and reference time. [[English#^en-Q0086|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20depredations%20of%20human%20hunters%20are%20thought%20to%20have%20been%20the%20key%20factor%20that%20pushed%20many%20species%20to%20extinction.)
^en-Q0086-answer

**en-Q0087** — Kate has been given an opportunity to play a major role in a movie.

केट को एक फ़िल्म में प्रमुख भूमिका निभाने का मौका दिया गया गै।

Expected form: **has**

Why: Perfect auxiliaries and reference time. [[English#^en-Q0087|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Kate%20has%20been%20given%20an%20opportunity%20to%20play%20a%20major%20role%20in%20a%20movie.)
^en-Q0087-answer

**en-Q0088** — Kate has been given an opportunity to play a major role in a movie.

केट को एक फ़िल्म में प्रमुख भूमिका निभाने का मौका दिया गया गै।

Why: Perfect auxiliaries and reference time. [[English#^en-Q0088|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Kate%20has%20been%20given%20an%20opportunity%20to%20play%20a%20major%20role%20in%20a%20movie.)
^en-Q0088-answer

**en-Q0089** — Jack may have taken my umbrella by mistake.

जैक ने मेरा छाता शायद ग़लती से ले लिया है।

Why: Perfect auxiliaries and reference time. [[English#^en-Q0089|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Jack%20may%20have%20taken%20my%20umbrella%20by%20mistake.)
^en-Q0089-answer

**en-Q0090** — Jack may have taken my umbrella by mistake.

जैक ने मेरा छाता शायद ग़लती से ले लिया है।

A perfect relates an earlier situation to a reference time. Have/has normally anchors the present; had anchors a past reference point. The auxiliary can also be ordinary possession, so inspect the participle and time phrase.

Why: Perfect auxiliaries and reference time. [[English#^en-Q0090|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Jack%20may%20have%20taken%20my%20umbrella%20by%20mistake.)
^en-Q0090-answer

**en-Q0091** — The authorities have been hiding the facts from the public.

अधिकारियों ने सच्चाई को आम जनता से छिपा कर रखा हुआ है।

Expected form: **have**

Why: Perfect auxiliaries and reference time. [[English#^en-Q0091|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20authorities%20have%20been%20hiding%20the%20facts%20from%20the%20public.)
^en-Q0091-answer

**en-Q0092** — The authorities have been hiding the facts from the public.

अधिकारियों ने सच्चाई को आम जनता से छिपा कर रखा हुआ है।

Expected form: **have**

Why: Perfect auxiliaries and reference time. [[English#^en-Q0092|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20authorities%20have%20been%20hiding%20the%20facts%20from%20the%20public.)
^en-Q0092-answer

**en-Q0093** — A committee has been set up to investigate the problem.

इस समस्या की तहकीकात करने के लिए एक समिति स्थापित करी गई है।

Expected form: **has**

Why: Perfect auxiliaries and reference time. [[English#^en-Q0093|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=A%20committee%20has%20been%20set%20up%20to%20investigate%20the%20problem.)
^en-Q0093-answer

**en-Q0094** — A committee has been set up to investigate the problem.

इस समस्या की तहकीकात करने के लिए एक समिति स्थापित करी गई है।

Why: Perfect auxiliaries and reference time. [[English#^en-Q0094|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=A%20committee%20has%20been%20set%20up%20to%20investigate%20the%20problem.)
^en-Q0094-answer

**en-Q0095** — I'll never forget how kind you have been.

मैं आपके अच्छेपन को कभी नहीं भूलूँगा।

Why: Perfect auxiliaries and reference time. [[English#^en-Q0095|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%27ll%20never%20forget%20how%20kind%20you%20have%20been.)
^en-Q0095-answer

**en-Q0096** — I'll never forget how kind you have been.

मैं आपके अच्छेपन को कभी नहीं भूलूँगा।

A perfect relates an earlier situation to a reference time. Have/has normally anchors the present; had anchors a past reference point. The auxiliary can also be ordinary possession, so inspect the participle and time phrase.

Why: Perfect auxiliaries and reference time. [[English#^en-Q0096|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%27ll%20never%20forget%20how%20kind%20you%20have%20been.)
^en-Q0096-answer

**en-Q0097** — The police arrested the man who had murdered the girl.

पुलिस ने उस लड़की के क़ातिल को हरासत में ले लिया।

Expected form: **had**

Why: Perfect auxiliaries and reference time. [[English#^en-Q0097|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20police%20arrested%20the%20man%20who%20had%20murdered%20the%20girl.)
^en-Q0097-answer

**en-Q0098** — The police arrested the man who had murdered the girl.

पुलिस ने उस लड़की के क़ातिल को हरासत में ले लिया।

Expected form: **had**

Why: Perfect auxiliaries and reference time. [[English#^en-Q0098|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20police%20arrested%20the%20man%20who%20had%20murdered%20the%20girl.)
^en-Q0098-answer

**en-Q0099** — I had met him many times before then.

मैं उससे पहले कई बार मिल चुका था।

Expected form: **had**

Why: Perfect auxiliaries and reference time. [[English#^en-Q0099|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20had%20met%20him%20many%20times%20before%20then.)
^en-Q0099-answer

**en-Q0100** — I had met him many times before then.

मैं उससे पहले कई बार मिल चुका था।

Why: Perfect auxiliaries and reference time. [[English#^en-Q0100|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20had%20met%20him%20many%20times%20before%20then.)
^en-Q0100-answer


### Answers 101–150

**en-Q0101** — One of the lights is not working. Do you think you could come take a look?

एक बत्ती नहीं जल रही है। तुम ज़रा आकर देख सकते हो क्या?

Why: Progressive perspective. [[English#^en-Q0101|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=One%20of%20the%20lights%20is%20not%20working.%20Do%20you%20think%20you%20could%20come%20take%20a%20look%3F)
^en-Q0101-answer

**en-Q0102** — One of the lights is not working. Do you think you could come take a look?

एक बत्ती नहीं जल रही है। तुम ज़रा आकर देख सकते हो क्या?

A progressive presents a situation from within its unfolding. Stative versus dynamic interpretations matter. The -ing form also serves in non-finite clauses and noun-like uses, so an -ing word alone does not prove a progressive.

Why: Progressive perspective. [[English#^en-Q0102|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=One%20of%20the%20lights%20is%20not%20working.%20Do%20you%20think%20you%20could%20come%20take%20a%20look%3F)
^en-Q0102-answer

**en-Q0103** — Are these the glasses you were looking for?

क्या यह वह ऐनक है जिसे आप ढूँढ रहे थे ?

Expected form: **looking**

Why: Progressive perspective. [[English#^en-Q0103|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Are%20these%20the%20glasses%20you%20were%20looking%20for%3F)
^en-Q0103-answer

**en-Q0104** — Are these the glasses you were looking for?

क्या यह वह ऐनक है जिसे आप ढूँढ रहे थे ?

Expected form: **looking**

Why: Progressive perspective. [[English#^en-Q0104|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Are%20these%20the%20glasses%20you%20were%20looking%20for%3F)
^en-Q0104-answer

**en-Q0105** — The scientists are working on a new experiment.

वैज्ञानिक नए प्रयोग पर काम कर रहे है I

Expected form: **working**

Why: Progressive perspective. [[English#^en-Q0105|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20scientists%20are%20working%20on%20a%20new%20experiment.)
^en-Q0105-answer

**en-Q0106** — The scientists are working on a new experiment.

वैज्ञानिक नए प्रयोग पर काम कर रहे है I

Why: Progressive perspective. [[English#^en-Q0106|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20scientists%20are%20working%20on%20a%20new%20experiment.)
^en-Q0106-answer

**en-Q0107** — We are working against an enemy who is very insidious in his methods.

हम एक ऐसे दुश्मन के विरुद्ध काम कर रहे हैं जो कपटपूर्ण विधियां अपनाने में प्रवीण है।

Why: Progressive perspective. [[English#^en-Q0107|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=We%20are%20working%20against%20an%20enemy%20who%20is%20very%20insidious%20in%20his%20methods.)
^en-Q0107-answer

**en-Q0108** — We are working against an enemy who is very insidious in his methods.

हम एक ऐसे दुश्मन के विरुद्ध काम कर रहे हैं जो कपटपूर्ण विधियां अपनाने में प्रवीण है।

A progressive presents a situation from within its unfolding. Stative versus dynamic interpretations matter. The -ing form also serves in non-finite clauses and noun-like uses, so an -ing word alone does not prove a progressive.

Why: Progressive perspective. [[English#^en-Q0108|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=We%20are%20working%20against%20an%20enemy%20who%20is%20very%20insidious%20in%20his%20methods.)
^en-Q0108-answer

**en-Q0109** — A new building is being built in front of my house.

मेरे घर के सामने एक नई ईमारत बन रही है।

Expected form: **being**

Why: Progressive perspective. [[English#^en-Q0109|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=A%20new%20building%20is%20being%20built%20in%20front%20of%20my%20house.)
^en-Q0109-answer

**en-Q0110** — A new building is being built in front of my house.

मेरे घर के सामने एक नई ईमारत बन रही है।

Expected form: **being**

Why: Progressive perspective. [[English#^en-Q0110|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=A%20new%20building%20is%20being%20built%20in%20front%20of%20my%20house.)
^en-Q0110-answer

**en-Q0111** — I am looking for a present for my mother.

मैं अपनी मम्मी के लिए तोह्फ़ा ढूँढ रहा हूँ।

Expected form: **looking**

Why: Progressive perspective. [[English#^en-Q0111|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20am%20looking%20for%20a%20present%20for%20my%20mother.)
^en-Q0111-answer

**en-Q0112** — I am looking for a present for my mother.

मैं अपनी मम्मी के लिए तोह्फ़ा ढूँढ रहा हूँ।

Why: Progressive perspective. [[English#^en-Q0112|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20am%20looking%20for%20a%20present%20for%20my%20mother.)
^en-Q0112-answer

**en-Q0113** — When she was reading the letter, she looked sad.

वह चिट्ठी पढ़ने के समय दुखी लग रही थी।

Why: Progressive perspective. [[English#^en-Q0113|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=When%20she%20was%20reading%20the%20letter%2C%20she%20looked%20sad.)
^en-Q0113-answer

**en-Q0114** — When she was reading the letter, she looked sad.

वह चिट्ठी पढ़ने के समय दुखी लग रही थी।

A progressive presents a situation from within its unfolding. Stative versus dynamic interpretations matter. The -ing form also serves in non-finite clauses and noun-like uses, so an -ing word alone does not prove a progressive.

Why: Progressive perspective. [[English#^en-Q0114|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=When%20she%20was%20reading%20the%20letter%2C%20she%20looked%20sad.)
^en-Q0114-answer

**en-Q0115** — I am doing business on a large scale.

मैं बड़े पैमाने पर व्यापार कर रहा हूँ।

Expected form: **doing**

Why: Progressive perspective. [[English#^en-Q0115|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20am%20doing%20business%20on%20a%20large%20scale.)
^en-Q0115-answer

**en-Q0116** — I am doing business on a large scale.

मैं बड़े पैमाने पर व्यापार कर रहा हूँ।

Expected form: **doing**

Why: Progressive perspective. [[English#^en-Q0116|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20am%20doing%20business%20on%20a%20large%20scale.)
^en-Q0116-answer

**en-Q0117** — What do you think she is doing now?

तुम्हारे हिसाब से वह अभी क्या कर रही होगी?

Expected form: **doing**

Why: Progressive perspective. [[English#^en-Q0117|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=What%20do%20you%20think%20she%20is%20doing%20now%3F)
^en-Q0117-answer

**en-Q0118** — What do you think she is doing now?

तुम्हारे हिसाब से वह अभी क्या कर रही होगी?

Why: Progressive perspective. [[English#^en-Q0118|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=What%20do%20you%20think%20she%20is%20doing%20now%3F)
^en-Q0118-answer

**en-Q0119** — What will you be doing at this time tomorrow?

तुम कल इस समय क्या कर रहे होगे?

Why: Progressive perspective. [[English#^en-Q0119|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=What%20will%20you%20be%20doing%20at%20this%20time%20tomorrow%3F)
^en-Q0119-answer

**en-Q0120** — What will you be doing at this time tomorrow?

तुम कल इस समय क्या कर रहे होगे?

A progressive presents a situation from within its unfolding. Stative versus dynamic interpretations matter. The -ing form also serves in non-finite clauses and noun-like uses, so an -ing word alone does not prove a progressive.

Why: Progressive perspective. [[English#^en-Q0120|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=What%20will%20you%20be%20doing%20at%20this%20time%20tomorrow%3F)
^en-Q0120-answer

**en-Q0121** — I am trying to memorise the names of constellations.

मैं सभी नक्षत्रों के नाम याद रखने की कोशिश कर रहा हूं।

Expected form: **trying**

Why: Progressive perspective. [[English#^en-Q0121|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20am%20trying%20to%20memorise%20the%20names%20of%20constellations.)
^en-Q0121-answer

**en-Q0122** — I am trying to memorise the names of constellations.

मैं सभी नक्षत्रों के नाम याद रखने की कोशिश कर रहा हूं।

Expected form: **trying**

Why: Progressive perspective. [[English#^en-Q0122|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20am%20trying%20to%20memorise%20the%20names%20of%20constellations.)
^en-Q0122-answer

**en-Q0123** — You are doing very well. Keep it up.

तुम अच्छा काम कर रहे हो। ऐसे ही करते रहो।

Expected form: **doing**

Why: Progressive perspective. [[English#^en-Q0123|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=You%20are%20doing%20very%20well.%20Keep%20it%20up.)
^en-Q0123-answer

**en-Q0124** — You are doing very well. Keep it up.

तुम अच्छा काम कर रहे हो। ऐसे ही करते रहो।

Why: Progressive perspective. [[English#^en-Q0124|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=You%20are%20doing%20very%20well.%20Keep%20it%20up.)
^en-Q0124-answer

**en-Q0125** — I want to know why Tom is doing this.

मुझे यह बताओ, कि टॉम ऐसा कर क्यों रहा है।

Why: Progressive perspective. [[English#^en-Q0125|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20want%20to%20know%20why%20Tom%20is%20doing%20this.)
^en-Q0125-answer

**en-Q0126** — I want to know why Tom is doing this.

मुझे यह बताओ, कि टॉम ऐसा कर क्यों रहा है।

A progressive presents a situation from within its unfolding. Stative versus dynamic interpretations matter. The -ing form also serves in non-finite clauses and noun-like uses, so an -ing word alone does not prove a progressive.

Why: Progressive perspective. [[English#^en-Q0126|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20want%20to%20know%20why%20Tom%20is%20doing%20this.)
^en-Q0126-answer

**en-Q0127** — Someone called Mr Dell is waiting for you in your office, Mrs Stevens.

श्री स्टीवन्स, आपके दफ़्तर में श्री डेल नाम के कोई व्यक्ती आपकी प्रतिक्षा कर रहे हैं।

Expected form: **waiting**

Why: Progressive perspective. [[English#^en-Q0127|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Someone%20called%20Mr%20Dell%20is%20waiting%20for%20you%20in%20your%20office%2C%20Mrs%20Stevens.)
^en-Q0127-answer

**en-Q0128** — Someone called Mr Dell is waiting for you in your office, Mrs Stevens.

श्री स्टीवन्स, आपके दफ़्तर में श्री डेल नाम के कोई व्यक्ती आपकी प्रतिक्षा कर रहे हैं।

Expected form: **waiting**

Why: Progressive perspective. [[English#^en-Q0128|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Someone%20called%20Mr%20Dell%20is%20waiting%20for%20you%20in%20your%20office%2C%20Mrs%20Stevens.)
^en-Q0128-answer

**en-Q0129** — What'll you be doing at this time tomorrow?

तुम कल इस समय क्या कर रहे होगे?

Expected form: **doing**

Why: Progressive perspective. [[English#^en-Q0129|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=What%27ll%20you%20be%20doing%20at%20this%20time%20tomorrow%3F)
^en-Q0129-answer

**en-Q0130** — What'll you be doing at this time tomorrow?

तुम कल इस समय क्या कर रहे होगे?

Why: Progressive perspective. [[English#^en-Q0130|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=What%27ll%20you%20be%20doing%20at%20this%20time%20tomorrow%3F)
^en-Q0130-answer

**en-Q0131** — Mary was looking for you at that time.

मेरी उस समय तुम्हें ढूँढ रही थी।

Why: Progressive perspective. [[English#^en-Q0131|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Mary%20was%20looking%20for%20you%20at%20that%20time.)
^en-Q0131-answer

**en-Q0132** — Mary was looking for you at that time.

मेरी उस समय तुम्हें ढूँढ रही थी।

A progressive presents a situation from within its unfolding. Stative versus dynamic interpretations matter. The -ing form also serves in non-finite clauses and noun-like uses, so an -ing word alone does not prove a progressive.

Why: Progressive perspective. [[English#^en-Q0132|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Mary%20was%20looking%20for%20you%20at%20that%20time.)
^en-Q0132-answer

**en-Q0133** — Tell me what you are looking forward to.

मुझे बताओ तुम किस चीज़ की आशा कर रहे हो।

Expected form: **looking**

Why: Progressive perspective. [[English#^en-Q0133|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Tell%20me%20what%20you%20are%20looking%20forward%20to.)
^en-Q0133-answer

**en-Q0134** — Tell me what you are looking forward to.

मुझे बताओ तुम किस चीज़ की आशा कर रहे हो।

Expected form: **looking**

Why: Progressive perspective. [[English#^en-Q0134|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Tell%20me%20what%20you%20are%20looking%20forward%20to.)
^en-Q0134-answer

**en-Q0135** — In order to stay awake I may have to drink more coffee.

मुझे जगे रहने के लिए शायद और कॉफ़ी पीनी पड़ेगी।

Expected form: **may**

Why: Modal inference. [[English#^en-Q0135|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=In%20order%20to%20stay%20awake%20I%20may%20have%20to%20drink%20more%20coffee.)
^en-Q0135-answer

**en-Q0136** — In order to stay awake I may have to drink more coffee.

मुझे जगे रहने के लिए शायद और कॉफ़ी पीनी पड़ेगी।

Why: Modal inference. [[English#^en-Q0136|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=In%20order%20to%20stay%20awake%20I%20may%20have%20to%20drink%20more%20coffee.)
^en-Q0136-answer

**en-Q0137** — I was scared that you might leave me.

मुझे डर था कि तुम मुझे छोड़ दोगे।

Why: Modal inference. [[English#^en-Q0137|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20was%20scared%20that%20you%20might%20leave%20me.)
^en-Q0137-answer

**en-Q0138** — I was scared that you might leave me.

मुझे डर था कि तुम मुझे छोड़ दोगे।

Modal meaning depends on context: inference, permission, ability and obligation differ. Must have + participle commonly makes a past inference; might have leaves alternatives open. Absence of necessity is not prohibition.

Why: Modal inference. [[English#^en-Q0138|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20was%20scared%20that%20you%20might%20leave%20me.)
^en-Q0138-answer

**en-Q0139** — Oh, I do wish I could go to France.

ओह, काश मैं फ़्रान्स जा सकती!

Expected form: **could**

Why: Modal inference. [[English#^en-Q0139|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Oh%2C%20I%20do%20wish%20I%20could%20go%20to%20France.)
^en-Q0139-answer

**en-Q0140** — Oh, I do wish I could go to France.

ओह, काश मैं फ़्रान्स जा सकती!

Expected form: **could**

Why: Modal inference. [[English#^en-Q0140|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Oh%2C%20I%20do%20wish%20I%20could%20go%20to%20France.)
^en-Q0140-answer

**en-Q0141** — You must get rid of such a habit.

तुम्हे इस तरह की आदत तोड़ देनी चाहिए।

Expected form: **must**

Why: Modal inference. [[English#^en-Q0141|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=You%20must%20get%20rid%20of%20such%20a%20habit.)
^en-Q0141-answer

**en-Q0142** — You must get rid of such a habit.

तुम्हे इस तरह की आदत तोड़ देनी चाहिए।

Why: Modal inference. [[English#^en-Q0142|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=You%20must%20get%20rid%20of%20such%20a%20habit.)
^en-Q0142-answer

**en-Q0143** — Could you send someone up to make the bed?

आप किसी को बिस्तर बनाने के लिए भेज सकते हैं क्या?

Why: Modal inference. [[English#^en-Q0143|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Could%20you%20send%20someone%20up%20to%20make%20the%20bed%3F)
^en-Q0143-answer

**en-Q0144** — Could you send someone up to make the bed?

आप किसी को बिस्तर बनाने के लिए भेज सकते हैं क्या?

Modal meaning depends on context: inference, permission, ability and obligation differ. Must have + participle commonly makes a past inference; might have leaves alternatives open. Absence of necessity is not prohibition.

Why: Modal inference. [[English#^en-Q0144|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Could%20you%20send%20someone%20up%20to%20make%20the%20bed%3F)
^en-Q0144-answer

**en-Q0145** — He could not come because of his illness.

वह बीमारी की वजह से नहीं आ सका।

Expected form: **could**

Why: Modal inference. [[English#^en-Q0145|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%20could%20not%20come%20because%20of%20his%20illness.)
^en-Q0145-answer

**en-Q0146** — He could not come because of his illness.

वह बीमारी की वजह से नहीं आ सका।

Expected form: **could**

Why: Modal inference. [[English#^en-Q0146|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%20could%20not%20come%20because%20of%20his%20illness.)
^en-Q0146-answer

**en-Q0147** — However hard it may rain, we will start tomorrow.

चाहे जितनी भी ज़ोर से बारिश हो, हम कल निकल चलेंगे।

Expected form: **may**

Why: Modal inference. [[English#^en-Q0147|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=However%20hard%20it%20may%20rain%2C%20we%20will%20start%20tomorrow.)
^en-Q0147-answer

**en-Q0148** — However hard it may rain, we will start tomorrow.

चाहे जितनी भी ज़ोर से बारिश हो, हम कल निकल चलेंगे।

Why: Modal inference. [[English#^en-Q0148|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=However%20hard%20it%20may%20rain%2C%20we%20will%20start%20tomorrow.)
^en-Q0148-answer

**en-Q0149** — On no account must you go out today.

तुम किसी भी हालत में आज बाहर नहीं जा सकते।

Why: Modal inference. [[English#^en-Q0149|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=On%20no%20account%20must%20you%20go%20out%20today.)
^en-Q0149-answer

**en-Q0150** — On no account must you go out today.

तुम किसी भी हालत में आज बाहर नहीं जा सकते।

Modal meaning depends on context: inference, permission, ability and obligation differ. Must have + participle commonly makes a past inference; might have leaves alternatives open. Absence of necessity is not prohibition.

Why: Modal inference. [[English#^en-Q0150|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=On%20no%20account%20must%20you%20go%20out%20today.)
^en-Q0150-answer


### Answers 151–200

**en-Q0151** — You cannot eat your cake and have it too.

तुम "चित भी मेरी पट भी मेरी" नहीं कर सकते।

Expected form: **cannot**

Why: Modal inference. [[English#^en-Q0151|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=You%20cannot%20eat%20your%20cake%20and%20have%20it%20too.)
^en-Q0151-answer

**en-Q0152** — You cannot eat your cake and have it too.

तुम "चित भी मेरी पट भी मेरी" नहीं कर सकते।

Expected form: **cannot**

Why: Modal inference. [[English#^en-Q0152|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=You%20cannot%20eat%20your%20cake%20and%20have%20it%20too.)
^en-Q0152-answer

**en-Q0153** — She cannot attend school on account of illness.

वह बीमारी की वजह से स्कूल नहीं जा सकती।

Expected form: **cannot**

Why: Modal inference. [[English#^en-Q0153|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=She%20cannot%20attend%20school%20on%20account%20of%20illness.)
^en-Q0153-answer

**en-Q0154** — She cannot attend school on account of illness.

वह बीमारी की वजह से स्कूल नहीं जा सकती।

Why: Modal inference. [[English#^en-Q0154|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=She%20cannot%20attend%20school%20on%20account%20of%20illness.)
^en-Q0154-answer

**en-Q0155** — I could not but laugh at his joke.

मैं उसके मज़ाक पर बस हँस पड़ा।

Why: Modal inference. [[English#^en-Q0155|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20could%20not%20but%20laugh%20at%20his%20joke.)
^en-Q0155-answer

**en-Q0156** — I could not but laugh at his joke.

मैं उसके मज़ाक पर बस हँस पड़ा।

Modal meaning depends on context: inference, permission, ability and obligation differ. Must have + participle commonly makes a past inference; might have leaves alternatives open. Absence of necessity is not prohibition.

Why: Modal inference. [[English#^en-Q0156|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20could%20not%20but%20laugh%20at%20his%20joke.)
^en-Q0156-answer

**en-Q0157** — He cannot buy a car, still less a house.

मकान की बात तो छोड़ो वह तो गाड़ी भी नहीं ख़रीद सकता।

Expected form: **cannot**

Why: Modal inference. [[English#^en-Q0157|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%20cannot%20buy%20a%20car%2C%20still%20less%20a%20house.)
^en-Q0157-answer

**en-Q0158** — He cannot buy a car, still less a house.

मकान की बात तो छोड़ो वह तो गाड़ी भी नहीं ख़रीद सकता।

Expected form: **cannot**

Why: Modal inference. [[English#^en-Q0158|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%20cannot%20buy%20a%20car%2C%20still%20less%20a%20house.)
^en-Q0158-answer

**en-Q0159** — It's been nice talking to you, but I really must go now.

आपसे बात करके खुशी हुई, पर अब मुझे जाना पड़ेगा।

Expected form: **must**

Why: Modal inference. [[English#^en-Q0159|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=It%27s%20been%20nice%20talking%20to%20you%2C%20but%20I%20really%20must%20go%20now.)
^en-Q0159-answer

**en-Q0160** — It's been nice talking to you, but I really must go now.

आपसे बात करके खुशी हुई, पर अब मुझे जाना पड़ेगा।

Why: Modal inference. [[English#^en-Q0160|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=It%27s%20been%20nice%20talking%20to%20you%2C%20but%20I%20really%20must%20go%20now.)
^en-Q0160-answer

**en-Q0161** — You must have such friends as will help you.

तुम्हारे ऐसे दोस्त होने चाहिए के जो तुम्हारी मदद करें।

Why: Modal inference. [[English#^en-Q0161|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=You%20must%20have%20such%20friends%20as%20will%20help%20you.)
^en-Q0161-answer

**en-Q0162** — You must have such friends as will help you.

तुम्हारे ऐसे दोस्त होने चाहिए के जो तुम्हारी मदद करें।

Modal meaning depends on context: inference, permission, ability and obligation differ. Must have + participle commonly makes a past inference; might have leaves alternatives open. Absence of necessity is not prohibition.

Why: Modal inference. [[English#^en-Q0162|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=You%20must%20have%20such%20friends%20as%20will%20help%20you.)
^en-Q0162-answer

**en-Q0163** — We cannot decide whether to go to college or not.

हम यह फ़ैसला नहीं ले पा रहें हैं कि कॉलेज जाएं या न जाएं।

Expected form: **cannot**

Why: Modal inference. [[English#^en-Q0163|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=We%20cannot%20decide%20whether%20to%20go%20to%20college%20or%20not.)
^en-Q0163-answer

**en-Q0164** — We cannot decide whether to go to college or not.

हम यह फ़ैसला नहीं ले पा रहें हैं कि कॉलेज जाएं या न जाएं।

Expected form: **cannot**

Why: Modal inference. [[English#^en-Q0164|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=We%20cannot%20decide%20whether%20to%20go%20to%20college%20or%20not.)
^en-Q0164-answer

**en-Q0165** — All trees and shrubs must be trimmed so that their branches are no closer than one metre from a power line.

सभी व्रक्ष व झाड़ियाँ इस प्रकार काटी जाएं ताकि उनकी शाखाएं बिजली की तार से एक मीटर की दूरी से अधिक नज़दीक न हों |

Expected form: **must**

Why: Modal inference. [[English#^en-Q0165|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=All%20trees%20and%20shrubs%20must%20be%20trimmed%20so%20that%20their%20branches%20are%20no%20closer%20than%20one%20metre%20from%20a%20power%20line.)
^en-Q0165-answer

**en-Q0166** — All trees and shrubs must be trimmed so that their branches are no closer than one metre from a power line.

सभी व्रक्ष व झाड़ियाँ इस प्रकार काटी जाएं ताकि उनकी शाखाएं बिजली की तार से एक मीटर की दूरी से अधिक नज़दीक न हों |

Why: Modal inference. [[English#^en-Q0166|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=All%20trees%20and%20shrubs%20must%20be%20trimmed%20so%20that%20their%20branches%20are%20no%20closer%20than%20one%20metre%20from%20a%20power%20line.)
^en-Q0166-answer

**en-Q0167** — In India, you can find many saints in the Himalayan region who could be called prescient.

भारत में आप हिमालय क्षेत्र में ऐसे अनेक साधुओं को देख सकते हैं जिन्हें भविष्यदर्शी कहा जा सकता है।

Why: Modal inference. [[English#^en-Q0167|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=In%20India%2C%20you%20can%20find%20many%20saints%20in%20the%20Himalayan%20region%20who%20could%20be%20called%20prescient.)
^en-Q0167-answer

**en-Q0168** — In India, you can find many saints in the Himalayan region who could be called prescient.

भारत में आप हिमालय क्षेत्र में ऐसे अनेक साधुओं को देख सकते हैं जिन्हें भविष्यदर्शी कहा जा सकता है।

Modal meaning depends on context: inference, permission, ability and obligation differ. Must have + participle commonly makes a past inference; might have leaves alternatives open. Absence of necessity is not prohibition.

Why: Modal inference. [[English#^en-Q0168|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=In%20India%2C%20you%20can%20find%20many%20saints%20in%20the%20Himalayan%20region%20who%20could%20be%20called%20prescient.)
^en-Q0168-answer

**en-Q0169** — Strange as it may sound, this is true.

चाहे सुनने में जितना भी अजीब लगे, यह सच है।

Expected form: **may**

Why: Modal inference. [[English#^en-Q0169|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Strange%20as%20it%20may%20sound%2C%20this%20is%20true.)
^en-Q0169-answer

**en-Q0170** — Strange as it may sound, this is true.

चाहे सुनने में जितना भी अजीब लगे, यह सच है।

Expected form: **may**

Why: Modal inference. [[English#^en-Q0170|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Strange%20as%20it%20may%20sound%2C%20this%20is%20true.)
^en-Q0170-answer

**en-Q0171** — We calculated that we could reach the place within two weeks.

हमने हिसाब लगाया कि हम वहाँ दो हफ़्तों में पहुँच सकते थे।

Expected form: **could**

Why: Modal inference. [[English#^en-Q0171|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=We%20calculated%20that%20we%20could%20reach%20the%20place%20within%20two%20weeks.)
^en-Q0171-answer

**en-Q0172** — We calculated that we could reach the place within two weeks.

हमने हिसाब लगाया कि हम वहाँ दो हफ़्तों में पहुँच सकते थे।

Why: Modal inference. [[English#^en-Q0172|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=We%20calculated%20that%20we%20could%20reach%20the%20place%20within%20two%20weeks.)
^en-Q0172-answer

**en-Q0173** — To my surprise, she could not answer the question.

मैं हैरान था कि वह सवाल का जवाब नहीं दे पाई।

Why: Modal inference. [[English#^en-Q0173|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=To%20my%20surprise%2C%20she%20could%20not%20answer%20the%20question.)
^en-Q0173-answer

**en-Q0174** — To my surprise, she could not answer the question.

मैं हैरान था कि वह सवाल का जवाब नहीं दे पाई।

Modal meaning depends on context: inference, permission, ability and obligation differ. Must have + participle commonly makes a past inference; might have leaves alternatives open. Absence of necessity is not prohibition.

Why: Modal inference. [[English#^en-Q0174|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=To%20my%20surprise%2C%20she%20could%20not%20answer%20the%20question.)
^en-Q0174-answer

**en-Q0175** — You might as well read a novel instead of staring at the ceiling.

छत पर घूरने के बजाए उपन्यास ही पढ़लो।

Expected form: **might**

Why: Modal inference. [[English#^en-Q0175|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=You%20might%20as%20well%20read%20a%20novel%20instead%20of%20staring%20at%20the%20ceiling.)
^en-Q0175-answer

**en-Q0176** — You might as well read a novel instead of staring at the ceiling.

छत पर घूरने के बजाए उपन्यास ही पढ़लो।

Expected form: **might**

Why: Modal inference. [[English#^en-Q0176|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=You%20might%20as%20well%20read%20a%20novel%20instead%20of%20staring%20at%20the%20ceiling.)
^en-Q0176-answer

**en-Q0177** — They wanted to get married as soon as they could.

वे जल्द-से-जल्द शादी करना चाहते थे।

Expected form: **could**

Why: Modal inference. [[English#^en-Q0177|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=They%20wanted%20to%20get%20married%20as%20soon%20as%20they%20could.)
^en-Q0177-answer

**en-Q0178** — They wanted to get married as soon as they could.

वे जल्द-से-जल्द शादी करना चाहते थे।

Why: Modal inference. [[English#^en-Q0178|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=They%20wanted%20to%20get%20married%20as%20soon%20as%20they%20could.)
^en-Q0178-answer

**en-Q0179** — Tom could never forget the terror of war.

युद्ध का आतंक टॉम कभी नहीं भूल पाया।

Why: Modal inference. [[English#^en-Q0179|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Tom%20could%20never%20forget%20the%20terror%20of%20war.)
^en-Q0179-answer

**en-Q0180** — Tom could never forget the terror of war.

युद्ध का आतंक टॉम कभी नहीं भूल पाया।

Modal meaning depends on context: inference, permission, ability and obligation differ. Must have + participle commonly makes a past inference; might have leaves alternatives open. Absence of necessity is not prohibition.

Why: Modal inference. [[English#^en-Q0180|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Tom%20could%20never%20forget%20the%20terror%20of%20war.)
^en-Q0180-answer

**en-Q0181** — If you have a time, could you translate some sentences below, please?

अगर आपके पास थोड़ा समय हो, तो कृपया निम्न वाक्यों का अनुवाद करेंगे?

Expected form: **could**

Why: Modal inference. [[English#^en-Q0181|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=If%20you%20have%20a%20time%2C%20could%20you%20translate%20some%20sentences%20below%2C%20please%3F)
^en-Q0181-answer

**en-Q0182** — If you have a time, could you translate some sentences below, please?

अगर आपके पास थोड़ा समय हो, तो कृपया निम्न वाक्यों का अनुवाद करेंगे?

Expected form: **could**

Why: Modal inference. [[English#^en-Q0182|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=If%20you%20have%20a%20time%2C%20could%20you%20translate%20some%20sentences%20below%2C%20please%3F)
^en-Q0182-answer

**en-Q0183** — I cannot dance one single step of Salsa.

मुझे साल्सा नाचना बिलकुल नहीं आता।

Expected form: **cannot**

Why: Modal inference. [[English#^en-Q0183|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20cannot%20dance%20one%20single%20step%20of%20Salsa.)
^en-Q0183-answer

**en-Q0184** — I cannot dance one single step of Salsa.

मुझे साल्सा नाचना बिलकुल नहीं आता।

Why: Modal inference. [[English#^en-Q0184|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20cannot%20dance%20one%20single%20step%20of%20Salsa.)
^en-Q0184-answer

**en-Q0185** — Something must have happened to him on the way.

उसके साथ रास्ते पर कुछ हुआ होगा।

Why: Past modal constructions. [[English#^en-Q0185|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Something%20must%20have%20happened%20to%20him%20on%20the%20way.)
^en-Q0185-answer

**en-Q0186** — Something must have happened to him on the way.

उसके साथ रास्ते पर कुछ हुआ होगा।

Modal + have + participle relates modality to a prior event. Could have can mean unrealised opportunity or uncertain explanation. Match the speaker’s commitment and the intended timeline.

Why: Past modal constructions. [[English#^en-Q0186|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Something%20must%20have%20happened%20to%20him%20on%20the%20way.)
^en-Q0186-answer

**en-Q0187** — If I had known her address, I would have written to her.

अगर मुझे उसका पता पता होता, तो मैंने उसे चिट्ठी लिखी हुई होती।

Expected form: **would have**

Why: Past modal constructions. [[English#^en-Q0187|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=If%20I%20had%20known%20her%20address%2C%20I%20would%20have%20written%20to%20her.)
^en-Q0187-answer

**en-Q0188** — If I had known her address, I would have written to her.

अगर मुझे उसका पता पता होता, तो मैंने उसे चिट्ठी लिखी हुई होती।

Expected form: **would have**

Why: Past modal constructions. [[English#^en-Q0188|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=If%20I%20had%20known%20her%20address%2C%20I%20would%20have%20written%20to%20her.)
^en-Q0188-answer

**en-Q0189** — With a little more patience, you would have succeeded.

अगर तुममें थोड़ा और सब्र होता तो तुम कामयाब हो जाते।

Expected form: **would have**

Why: Past modal constructions. [[English#^en-Q0189|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=With%20a%20little%20more%20patience%2C%20you%20would%20have%20succeeded.)
^en-Q0189-answer

**en-Q0190** — With a little more patience, you would have succeeded.

अगर तुममें थोड़ा और सब्र होता तो तुम कामयाब हो जाते।

Why: Past modal constructions. [[English#^en-Q0190|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=With%20a%20little%20more%20patience%2C%20you%20would%20have%20succeeded.)
^en-Q0190-answer

**en-Q0191** — I must have left it on the bus.

मैंने उसे बस में छोड़ दिया होगा।

Why: Past modal constructions. [[English#^en-Q0191|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20must%20have%20left%20it%20on%20the%20bus.)
^en-Q0191-answer

**en-Q0192** — I must have left it on the bus.

मैंने उसे बस में छोड़ दिया होगा।

Modal + have + participle relates modality to a prior event. Could have can mean unrealised opportunity or uncertain explanation. Match the speaker’s commitment and the intended timeline.

Why: Past modal constructions. [[English#^en-Q0192|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20must%20have%20left%20it%20on%20the%20bus.)
^en-Q0192-answer

**en-Q0193** — Had he tried it once more, he would have succeeded in it.

अगर उसने और एक बार कोशिश की होती, तो शायद वह सफल हो जाता.

Expected form: **would have**

Why: Past modal constructions. [[English#^en-Q0193|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Had%20he%20tried%20it%20once%20more%2C%20he%20would%20have%20succeeded%20in%20it.)
^en-Q0193-answer

**en-Q0194** — Had he tried it once more, he would have succeeded in it.

अगर उसने और एक बार कोशिश की होती, तो शायद वह सफल हो जाता.

Expected form: **would have**

Why: Past modal constructions. [[English#^en-Q0194|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Had%20he%20tried%20it%20once%20more%2C%20he%20would%20have%20succeeded%20in%20it.)
^en-Q0194-answer

**en-Q0195** — He told the truth, otherwise he would have been punished.

उसने सच बताया, वरना उसे सज़ा होती।

Expected form: **would have**

Why: Past modal constructions. [[English#^en-Q0195|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%20told%20the%20truth%2C%20otherwise%20he%20would%20have%20been%20punished.)
^en-Q0195-answer

**en-Q0196** — He told the truth, otherwise he would have been punished.

उसने सच बताया, वरना उसे सज़ा होती।

Why: Past modal constructions. [[English#^en-Q0196|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%20told%20the%20truth%2C%20otherwise%20he%20would%20have%20been%20punished.)
^en-Q0196-answer

**en-Q0197** — Keep hold of my hand if you're afraid.

मेरा हाथ पकड़लो अगर तुम्हे डर लग रहा है तो।

Why: Conditional relationships. [[English#^en-Q0197|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Keep%20hold%20of%20my%20hand%20if%20you%27re%20afraid.)
^en-Q0197-answer

**en-Q0198** — Keep hold of my hand if you're afraid.

मेरा हाथ पकड़लो अगर तुम्हे डर लग रहा है तो।

Choose tense and modal forms according to reality and temporal relation. If + past perfect can describe an unreal past condition; a present consequence creates a mixed conditional. Unless is not a free substitute for every if not.

Why: Conditional relationships. [[English#^en-Q0198|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Keep%20hold%20of%20my%20hand%20if%20you%27re%20afraid.)
^en-Q0198-answer

**en-Q0199** — Tom wouldn't be here if it wasn't for me.

मैं ना होता तो टॉम आज यहाँ नहीं होता।

Expected form: **if**

Why: Conditional relationships. [[English#^en-Q0199|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Tom%20wouldn%27t%20be%20here%20if%20it%20wasn%27t%20for%20me.)
^en-Q0199-answer

**en-Q0200** — Tom wouldn't be here if it wasn't for me.

मैं ना होता तो टॉम आज यहाँ नहीं होता।

Expected form: **if**

Why: Conditional relationships. [[English#^en-Q0200|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Tom%20wouldn%27t%20be%20here%20if%20it%20wasn%27t%20for%20me.)
^en-Q0200-answer


### Answers 201–250

**en-Q0201** — You will get fat if you eat too much.

बहुत ज़्यादा खा लिया तो मोटे हो जाओगे।

Expected form: **if**

Why: Conditional relationships. [[English#^en-Q0201|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=You%20will%20get%20fat%20if%20you%20eat%20too%20much.)
^en-Q0201-answer

**en-Q0202** — You will get fat if you eat too much.

बहुत ज़्यादा खा लिया तो मोटे हो जाओगे।

Why: Conditional relationships. [[English#^en-Q0202|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=You%20will%20get%20fat%20if%20you%20eat%20too%20much.)
^en-Q0202-answer

**en-Q0203** — What would Tom say if he were alive today?

टॉम आज ज़िंदा होता तो वह क्या कहता?

Why: Conditional relationships. [[English#^en-Q0203|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=What%20would%20Tom%20say%20if%20he%20were%20alive%20today%3F)
^en-Q0203-answer

**en-Q0204** — What would Tom say if he were alive today?

टॉम आज ज़िंदा होता तो वह क्या कहता?

Choose tense and modal forms according to reality and temporal relation. If + past perfect can describe an unreal past condition; a present consequence creates a mixed conditional. Unless is not a free substitute for every if not.

Why: Conditional relationships. [[English#^en-Q0204|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=What%20would%20Tom%20say%20if%20he%20were%20alive%20today%3F)
^en-Q0204-answer

**en-Q0205** — If it isn't a bad, dirty, or wrong thing, then it's alright.

यदि वह बुरा, गंदा या गलत न हो तो ठीक है।

Expected form: **If**

Why: Conditional relationships. [[English#^en-Q0205|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=If%20it%20isn%27t%20a%20bad%2C%20dirty%2C%20or%20wrong%20thing%2C%20then%20it%27s%20alright.)
^en-Q0205-answer

**en-Q0206** — If it isn't a bad, dirty, or wrong thing, then it's alright.

यदि वह बुरा, गंदा या गलत न हो तो ठीक है।

Expected form: **If**

Why: Conditional relationships. [[English#^en-Q0206|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=If%20it%20isn%27t%20a%20bad%2C%20dirty%2C%20or%20wrong%20thing%2C%20then%20it%27s%20alright.)
^en-Q0206-answer

**en-Q0207** — I don't see any point in going if the party is almost over.

मुझे जाने मेँ कोई तुक नहिं लगता अगर पीृतिभोज लगभग समापत हो चुका हो ।

Expected form: **if**

Why: Conditional relationships. [[English#^en-Q0207|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20don%27t%20see%20any%20point%20in%20going%20if%20the%20party%20is%20almost%20over.)
^en-Q0207-answer

**en-Q0208** — I don't see any point in going if the party is almost over.

मुझे जाने मेँ कोई तुक नहिं लगता अगर पीृतिभोज लगभग समापत हो चुका हो ।

Why: Conditional relationships. [[English#^en-Q0208|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20don%27t%20see%20any%20point%20in%20going%20if%20the%20party%20is%20almost%20over.)
^en-Q0208-answer

**en-Q0209** — If it snows tomorrow, I'll build a snowman.

अगर कल बर्फ़ गिरी तो मैं स्नोमैन बनाऊंगा।

Why: Conditional relationships. [[English#^en-Q0209|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=If%20it%20snows%20tomorrow%2C%20I%27ll%20build%20a%20snowman.)
^en-Q0209-answer

**en-Q0210** — If it snows tomorrow, I'll build a snowman.

अगर कल बर्फ़ गिरी तो मैं स्नोमैन बनाऊंगा।

Choose tense and modal forms according to reality and temporal relation. If + past perfect can describe an unreal past condition; a present consequence creates a mixed conditional. Unless is not a free substitute for every if not.

Why: Conditional relationships. [[English#^en-Q0210|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=If%20it%20snows%20tomorrow%2C%20I%27ll%20build%20a%20snowman.)
^en-Q0210-answer

**en-Q0211** — He will commit suicide if he can't see his son.

वह अपने बेटे को नहीं देख पाया तो वह आत्महत्या कर लेगा।

Expected form: **if**

Why: Conditional relationships. [[English#^en-Q0211|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%20will%20commit%20suicide%20if%20he%20can%27t%20see%20his%20son.)
^en-Q0211-answer

**en-Q0212** — He will commit suicide if he can't see his son.

वह अपने बेटे को नहीं देख पाया तो वह आत्महत्या कर लेगा।

Expected form: **if**

Why: Conditional relationships. [[English#^en-Q0212|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%20will%20commit%20suicide%20if%20he%20can%27t%20see%20his%20son.)
^en-Q0212-answer

**en-Q0213** — Nothing happens unless it is preceded by a dream.

कोई सपना देखे बिना कुछ नहीं होता।

Expected form: **unless**

Why: Conditional relationships. [[English#^en-Q0213|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Nothing%20happens%20unless%20it%20is%20preceded%20by%20a%20dream.)
^en-Q0213-answer

**en-Q0214** — Nothing happens unless it is preceded by a dream.

कोई सपना देखे बिना कुछ नहीं होता।

Why: Conditional relationships. [[English#^en-Q0214|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Nothing%20happens%20unless%20it%20is%20preceded%20by%20a%20dream.)
^en-Q0214-answer

**en-Q0215** — I play mahjong only now and then, because if I made a habit of it, I'd end up wasting all my time on it.

माज्याँग मैं केवल कभी-कभार ही खेलती हूँ, क्योंकि अगर आदत लग गई तो सारा समय उसी पर बरबाद कर दूँगी।

Why: Conditional relationships. [[English#^en-Q0215|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20play%20mahjong%20only%20now%20and%20then%2C%20because%20if%20I%20made%20a%20habit%20of%20it%2C%20I%27d%20end%20up%20wasting%20all%20my%20time%20on%20it.)
^en-Q0215-answer

**en-Q0216** — I play mahjong only now and then, because if I made a habit of it, I'd end up wasting all my time on it.

माज्याँग मैं केवल कभी-कभार ही खेलती हूँ, क्योंकि अगर आदत लग गई तो सारा समय उसी पर बरबाद कर दूँगी।

Choose tense and modal forms according to reality and temporal relation. If + past perfect can describe an unreal past condition; a present consequence creates a mixed conditional. Unless is not a free substitute for every if not.

Why: Conditional relationships. [[English#^en-Q0216|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20play%20mahjong%20only%20now%20and%20then%2C%20because%20if%20I%20made%20a%20habit%20of%20it%2C%20I%27d%20end%20up%20wasting%20all%20my%20time%20on%20it.)
^en-Q0216-answer

**en-Q0217** — If you do anything at all, do it well.

अगर कुछ करना है तो ढंग से करो।

Expected form: **If**

Why: Conditional relationships. [[English#^en-Q0217|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=If%20you%20do%20anything%20at%20all%2C%20do%20it%20well.)
^en-Q0217-answer

**en-Q0218** — If you do anything at all, do it well.

अगर कुछ करना है तो ढंग से करो।

Expected form: **If**

Why: Conditional relationships. [[English#^en-Q0218|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=If%20you%20do%20anything%20at%20all%2C%20do%20it%20well.)
^en-Q0218-answer

**en-Q0219** — If Tom doesn't help us, we'll never be able to finish this on time.

अगर टॉम हमारी मदद नहीं करेगा तो हम ये समय पर कभी नहीं कर पायेंगे।

Expected form: **If**

Why: Conditional relationships. [[English#^en-Q0219|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=If%20Tom%20doesn%27t%20help%20us%2C%20we%27ll%20never%20be%20able%20to%20finish%20this%20on%20time.)
^en-Q0219-answer

**en-Q0220** — If Tom doesn't help us, we'll never be able to finish this on time.

अगर टॉम हमारी मदद नहीं करेगा तो हम ये समय पर कभी नहीं कर पायेंगे।

Why: Conditional relationships. [[English#^en-Q0220|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=If%20Tom%20doesn%27t%20help%20us%2C%20we%27ll%20never%20be%20able%20to%20finish%20this%20on%20time.)
^en-Q0220-answer

**en-Q0221** — You'll be punished if you break the law.

अगर तुम कानून तोड़ोगे तो तुम्हे सज़ा मिलेगी।

Why: Conditional relationships. [[English#^en-Q0221|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=You%27ll%20be%20punished%20if%20you%20break%20the%20law.)
^en-Q0221-answer

**en-Q0222** — You'll be punished if you break the law.

अगर तुम कानून तोड़ोगे तो तुम्हे सज़ा मिलेगी।

Choose tense and modal forms according to reality and temporal relation. If + past perfect can describe an unreal past condition; a present consequence creates a mixed conditional. Unless is not a free substitute for every if not.

Why: Conditional relationships. [[English#^en-Q0222|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=You%27ll%20be%20punished%20if%20you%20break%20the%20law.)
^en-Q0222-answer

**en-Q0223** — The way I see it, if you want the rainbow, you gotta put up with the rain.

मेरे विचार से यदि आप इन्द्रधनुष चाहते हैं, तो आपको वर्षा को सहना होगा।

Expected form: **if**

Why: Conditional relationships. [[English#^en-Q0223|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20way%20I%20see%20it%2C%20if%20you%20want%20the%20rainbow%2C%20you%20gotta%20put%20up%20with%20the%20rain.)
^en-Q0223-answer

**en-Q0224** — The way I see it, if you want the rainbow, you gotta put up with the rain.

मेरे विचार से यदि आप इन्द्रधनुष चाहते हैं, तो आपको वर्षा को सहना होगा।

Expected form: **if**

Why: Conditional relationships. [[English#^en-Q0224|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20way%20I%20see%20it%2C%20if%20you%20want%20the%20rainbow%2C%20you%20gotta%20put%20up%20with%20the%20rain.)
^en-Q0224-answer

**en-Q0225** — I don't know if I'll have time to do it.

मुझे नहीं पता मेरे पास यह करने के लिए समय होगा कि नहीं।

Expected form: **if**

Why: Conditional relationships. [[English#^en-Q0225|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20don%27t%20know%20if%20I%27ll%20have%20time%20to%20do%20it.)
^en-Q0225-answer

**en-Q0226** — I don't know if I'll have time to do it.

मुझे नहीं पता मेरे पास यह करने के लिए समय होगा कि नहीं।

Why: Conditional relationships. [[English#^en-Q0226|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20don%27t%20know%20if%20I%27ll%20have%20time%20to%20do%20it.)
^en-Q0226-answer

**en-Q0227** — If you go to that supermarket, you can buy most things you use in your daily life.

उस सूपरमार्केट में तुम लगभग कोई भी रोजाने में इस्तेमाल होने वाला सामान ख़रीद सकते हो।

Why: Conditional relationships. [[English#^en-Q0227|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=If%20you%20go%20to%20that%20supermarket%2C%20you%20can%20buy%20most%20things%20you%20use%20in%20your%20daily%20life.)
^en-Q0227-answer

**en-Q0228** — If you go to that supermarket, you can buy most things you use in your daily life.

उस सूपरमार्केट में तुम लगभग कोई भी रोजाने में इस्तेमाल होने वाला सामान ख़रीद सकते हो।

Choose tense and modal forms according to reality and temporal relation. If + past perfect can describe an unreal past condition; a present consequence creates a mixed conditional. Unless is not a free substitute for every if not.

Why: Conditional relationships. [[English#^en-Q0228|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=If%20you%20go%20to%20that%20supermarket%2C%20you%20can%20buy%20most%20things%20you%20use%20in%20your%20daily%20life.)
^en-Q0228-answer

**en-Q0229** — Tom won't do that unless you ask him.

जब तक तुम टॉम को नहीं पूछोगे, तब तक वह उसे नहीं करेगा।

Expected form: **unless**

Why: Conditional relationships. [[English#^en-Q0229|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Tom%20won%27t%20do%20that%20unless%20you%20ask%20him.)
^en-Q0229-answer

**en-Q0230** — Tom won't do that unless you ask him.

जब तक तुम टॉम को नहीं पूछोगे, तब तक वह उसे नहीं करेगा।

Expected form: **unless**

Why: Conditional relationships. [[English#^en-Q0230|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Tom%20won%27t%20do%20that%20unless%20you%20ask%20him.)
^en-Q0230-answer

**en-Q0231** — Tom won't do that even if you ask him.

यदि तुम उसे पूछो तो भी टॉम उसे नहीं करेगा।

Expected form: **if**

Why: Conditional relationships. [[English#^en-Q0231|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Tom%20won%27t%20do%20that%20even%20if%20you%20ask%20him.)
^en-Q0231-answer

**en-Q0232** — Tom won't do that even if you ask him.

यदि तुम उसे पूछो तो भी टॉम उसे नहीं करेगा।

Why: Conditional relationships. [[English#^en-Q0232|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Tom%20won%27t%20do%20that%20even%20if%20you%20ask%20him.)
^en-Q0232-answer

**en-Q0233** — Cancer can be cured if discovered in time.

कैंसर का अगर समय में पता चल जाए, तो उसका इलाज हो सकता है।

Why: Conditional relationships. [[English#^en-Q0233|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Cancer%20can%20be%20cured%20if%20discovered%20in%20time.)
^en-Q0233-answer

**en-Q0234** — Cancer can be cured if discovered in time.

कैंसर का अगर समय में पता चल जाए, तो उसका इलाज हो सकता है।

Choose tense and modal forms according to reality and temporal relation. If + past perfect can describe an unreal past condition; a present consequence creates a mixed conditional. Unless is not a free substitute for every if not.

Why: Conditional relationships. [[English#^en-Q0234|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Cancer%20can%20be%20cured%20if%20discovered%20in%20time.)
^en-Q0234-answer

**en-Q0235** — If I want to go, I'll let you know.

यदि मैने जाना हुआ तो आपको बता दूँगी।

Expected form: **If**

Why: Conditional relationships. [[English#^en-Q0235|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=If%20I%20want%20to%20go%2C%20I%27ll%20let%20you%20know.)
^en-Q0235-answer

**en-Q0236** — If I want to go, I'll let you know.

यदि मैने जाना हुआ तो आपको बता दूँगी।

Expected form: **If**

Why: Conditional relationships. [[English#^en-Q0236|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=If%20I%20want%20to%20go%2C%20I%27ll%20let%20you%20know.)
^en-Q0236-answer

**en-Q0237** — So what if I am gay? Is it a crime?

तो क्या अगर मैं गे हूँ? कोई अपराध है क्या?

Expected form: **if**

Why: Conditional relationships. [[English#^en-Q0237|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=So%20what%20if%20I%20am%20gay%3F%20Is%20it%20a%20crime%3F)
^en-Q0237-answer

**en-Q0238** — So what if I am gay? Is it a crime?

तो क्या अगर मैं गे हूँ? कोई अपराध है क्या?

Why: Conditional relationships. [[English#^en-Q0238|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=So%20what%20if%20I%20am%20gay%3F%20Is%20it%20a%20crime%3F)
^en-Q0238-answer

**en-Q0239** — Give up smoking if you want to live long.

अगर लम्बी ज़िन्दगी जीना चाहते हो तो सिगरेट पीना छोड़ दो।

Why: Conditional relationships. [[English#^en-Q0239|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Give%20up%20smoking%20if%20you%20want%20to%20live%20long.)
^en-Q0239-answer

**en-Q0240** — Give up smoking if you want to live long.

अगर लम्बी ज़िन्दगी जीना चाहते हो तो सिगरेट पीना छोड़ दो।

Choose tense and modal forms according to reality and temporal relation. If + past perfect can describe an unreal past condition; a present consequence creates a mixed conditional. Unless is not a free substitute for every if not.

Why: Conditional relationships. [[English#^en-Q0240|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Give%20up%20smoking%20if%20you%20want%20to%20live%20long.)
^en-Q0240-answer

**en-Q0241** — If I had wings, I would fly to you.

अगर मेरे पास पंख होते तो मैं उड़कर तुम्हारे पास चला आता।

Expected form: **If**

Why: Conditional relationships. [[English#^en-Q0241|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=If%20I%20had%20wings%2C%20I%20would%20fly%20to%20you.)
^en-Q0241-answer

**en-Q0242** — If I had wings, I would fly to you.

अगर मेरे पास पंख होते तो मैं उड़कर तुम्हारे पास चला आता।

Expected form: **If**

Why: Conditional relationships. [[English#^en-Q0242|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=If%20I%20had%20wings%2C%20I%20would%20fly%20to%20you.)
^en-Q0242-answer

**en-Q0243** — If you help me learn English, I'll help you learn Japanese.

अगर तुम ने मेरी अंग्रेज़ी सीखने में मदद की तो में तुम्हारी जापानी सीखने में मदद करूँगा।

Expected form: **If**

Why: Conditional relationships. [[English#^en-Q0243|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=If%20you%20help%20me%20learn%20English%2C%20I%27ll%20help%20you%20learn%20Japanese.)
^en-Q0243-answer

**en-Q0244** — If you help me learn English, I'll help you learn Japanese.

अगर तुम ने मेरी अंग्रेज़ी सीखने में मदद की तो में तुम्हारी जापानी सीखने में मदद करूँगा।

Why: Conditional relationships. [[English#^en-Q0244|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=If%20you%20help%20me%20learn%20English%2C%20I%27ll%20help%20you%20learn%20Japanese.)
^en-Q0244-answer

**en-Q0245** — He asked me if I could do him a favor.

उसने मुझसे एक एहसान माँगा।

Why: Conditional relationships. [[English#^en-Q0245|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%20asked%20me%20if%20I%20could%20do%20him%20a%20favor.)
^en-Q0245-answer

**en-Q0246** — He asked me if I could do him a favor.

उसने मुझसे एक एहसान माँगा।

Choose tense and modal forms according to reality and temporal relation. If + past perfect can describe an unreal past condition; a present consequence creates a mixed conditional. Unless is not a free substitute for every if not.

Why: Conditional relationships. [[English#^en-Q0246|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%20asked%20me%20if%20I%20could%20do%20him%20a%20favor.)
^en-Q0246-answer

**en-Q0247** — The capital of Himachal Pradesh, Shimla, is only 115 kilometres away from Chandigarh.

हिमाचल प्रदेश की राजधानी, शिमला, चण्डीगढ़ से केवल ११५ किलोमीटर की दूरी पर है।

Expected form: **only**

Why: Negative and restrictive emphasis. [[English#^en-Q0247|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20capital%20of%20Himachal%20Pradesh%2C%20Shimla%2C%20is%20only%20115%20kilometres%20away%20from%20Chandigarh.)
^en-Q0247-answer

**en-Q0248** — The capital of Himachal Pradesh, Shimla, is only 115 kilometres away from Chandigarh.

हिमाचल प्रदेश की राजधानी, शिमला, चण्डीगढ़ से केवल ११५ किलोमीटर की दूरी पर है।

Expected form: **only**

Why: Negative and restrictive emphasis. [[English#^en-Q0248|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20capital%20of%20Himachal%20Pradesh%2C%20Shimla%2C%20is%20only%20115%20kilometres%20away%20from%20Chandigarh.)
^en-Q0248-answer

**en-Q0249** — No matter what happens, I will never betray my friend.

चाहे जो भी हो, मैं कभी भी अपने दोस्त को धोखा नहीं दूँगा।

Expected form: **never**

Why: Negative and restrictive emphasis. [[English#^en-Q0249|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=No%20matter%20what%20happens%2C%20I%20will%20never%20betray%20my%20friend.)
^en-Q0249-answer

**en-Q0250** — No matter what happens, I will never betray my friend.

चाहे जो भी हो, मैं कभी भी अपने दोस्त को धोखा नहीं दूँगा।

Why: Negative and restrictive emphasis. [[English#^en-Q0250|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=No%20matter%20what%20happens%2C%20I%20will%20never%20betray%20my%20friend.)
^en-Q0250-answer


### Answers 251–300

**en-Q0251** — He'll never admit to being in the wrong.

वह कभी अपनी ग़लती नहीं मानेगा।

Why: Negative and restrictive emphasis. [[English#^en-Q0251|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%27ll%20never%20admit%20to%20being%20in%20the%20wrong.)
^en-Q0251-answer

**en-Q0252** — He'll never admit to being in the wrong.

वह कभी अपनी ग़लती नहीं मानेगा।

Fronted negative/restrictive adverbials can trigger subject–auxiliary inversion. Only before the subject does not: Only Anna agreed. Scope and placement decide what the restriction actually excludes.

Why: Negative and restrictive emphasis. [[English#^en-Q0252|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%27ll%20never%20admit%20to%20being%20in%20the%20wrong.)
^en-Q0252-answer

**en-Q0253** — The spaceship was never to return to the earth.

वह हवाई जहाज़ पृथ्वीपर वापस लौटनेवाला नहीं था.

Expected form: **never**

Why: Negative and restrictive emphasis. [[English#^en-Q0253|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20spaceship%20was%20never%20to%20return%20to%20the%20earth.)
^en-Q0253-answer

**en-Q0254** — The spaceship was never to return to the earth.

वह हवाई जहाज़ पृथ्वीपर वापस लौटनेवाला नहीं था.

Expected form: **never**

Why: Negative and restrictive emphasis. [[English#^en-Q0254|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20spaceship%20was%20never%20to%20return%20to%20the%20earth.)
^en-Q0254-answer

**en-Q0255** — I've never met him, but I recognize him.

मैं उसे पहचानता हूँ पर मैं उससे कभी मिला नहीं हूँ।

Expected form: **never**

Why: Negative and restrictive emphasis. [[English#^en-Q0255|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%27ve%20never%20met%20him%2C%20but%20I%20recognize%20him.)
^en-Q0255-answer

**en-Q0256** — I've never met him, but I recognize him.

मैं उसे पहचानता हूँ पर मैं उससे कभी मिला नहीं हूँ।

Why: Negative and restrictive emphasis. [[English#^en-Q0256|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%27ve%20never%20met%20him%2C%20but%20I%20recognize%20him.)
^en-Q0256-answer

**en-Q0257** — Not only does a rock drown, but it drowns others with it.

ख़ुद डूब कर पत्थर दूसरे को डुबो देता है।

Why: Negative and restrictive emphasis. [[English#^en-Q0257|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Not%20only%20does%20a%20rock%20drown%2C%20but%20it%20drowns%20others%20with%20it.)
^en-Q0257-answer

**en-Q0258** — Not only does a rock drown, but it drowns others with it.

ख़ुद डूब कर पत्थर दूसरे को डुबो देता है।

Fronted negative/restrictive adverbials can trigger subject–auxiliary inversion. Only before the subject does not: Only Anna agreed. Scope and placement decide what the restriction actually excludes.

Why: Negative and restrictive emphasis. [[English#^en-Q0258|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Not%20only%20does%20a%20rock%20drown%2C%20but%20it%20drowns%20others%20with%20it.)
^en-Q0258-answer

**en-Q0259** — The pulao with meat is eight yuan. The vegetarian pulao is only four yuan.

मांस वाला पुलाव आठ युएन का है। बिना मांस वाला पुलाव केवल चार युएन का है।

Expected form: **only**

Why: Negative and restrictive emphasis. [[English#^en-Q0259|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20pulao%20with%20meat%20is%20eight%20yuan.%20The%20vegetarian%20pulao%20is%20only%20four%20yuan.)
^en-Q0259-answer

**en-Q0260** — The pulao with meat is eight yuan. The vegetarian pulao is only four yuan.

मांस वाला पुलाव आठ युएन का है। बिना मांस वाला पुलाव केवल चार युएन का है।

Expected form: **only**

Why: Negative and restrictive emphasis. [[English#^en-Q0260|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20pulao%20with%20meat%20is%20eight%20yuan.%20The%20vegetarian%20pulao%20is%20only%20four%20yuan.)
^en-Q0260-answer

**en-Q0261** — He was destined never to meet her again.

उसके नसीब में उससे फिरसे मिलना नहीं लिखा हुआ था।

Expected form: **never**

Why: Negative and restrictive emphasis. [[English#^en-Q0261|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%20was%20destined%20never%20to%20meet%20her%20again.)
^en-Q0261-answer

**en-Q0262** — He was destined never to meet her again.

उसके नसीब में उससे फिरसे मिलना नहीं लिखा हुआ था।

Why: Negative and restrictive emphasis. [[English#^en-Q0262|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%20was%20destined%20never%20to%20meet%20her%20again.)
^en-Q0262-answer

**en-Q0263** — Not only did I eat pulao, but I also ate kebabs.

मैंने पुलाव ही नहीं, बल्कि कबाब भी खाए।

Why: Negative and restrictive emphasis. [[English#^en-Q0263|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Not%20only%20did%20I%20eat%20pulao%2C%20but%20I%20also%20ate%20kebabs.)
^en-Q0263-answer

**en-Q0264** — Not only did I eat pulao, but I also ate kebabs.

मैंने पुलाव ही नहीं, बल्कि कबाब भी खाए।

Fronted negative/restrictive adverbials can trigger subject–auxiliary inversion. Only before the subject does not: Only Anna agreed. Scope and placement decide what the restriction actually excludes.

Why: Negative and restrictive emphasis. [[English#^en-Q0264|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Not%20only%20did%20I%20eat%20pulao%2C%20but%20I%20also%20ate%20kebabs.)
^en-Q0264-answer

**en-Q0265** — There are only two kind of people in the world.

दुनिया में बस दो तरह के लोग होते हैं।

Expected form: **only**

Why: Negative and restrictive emphasis. [[English#^en-Q0265|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=There%20are%20only%20two%20kind%20of%20people%20in%20the%20world.)
^en-Q0265-answer

**en-Q0266** — There are only two kind of people in the world.

दुनिया में बस दो तरह के लोग होते हैं।

Expected form: **only**

Why: Negative and restrictive emphasis. [[English#^en-Q0266|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=There%20are%20only%20two%20kind%20of%20people%20in%20the%20world.)
^en-Q0266-answer

**en-Q0267** — He went to China as a soldier, never to come back.

वह सिपाही के रूप में चीन गया, और कभी लौटकर नहीं आया।

Expected form: **never**

Why: Negative and restrictive emphasis. [[English#^en-Q0267|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%20went%20to%20China%20as%20a%20soldier%2C%20never%20to%20come%20back.)
^en-Q0267-answer

**en-Q0268** — He went to China as a soldier, never to come back.

वह सिपाही के रूप में चीन गया, और कभी लौटकर नहीं आया।

Why: Negative and restrictive emphasis. [[English#^en-Q0268|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%20went%20to%20China%20as%20a%20soldier%2C%20never%20to%20come%20back.)
^en-Q0268-answer

**en-Q0269** — Some people, no matter how old they get, never lose their beauty.

कुछ लोग, चाहे जितने बूढ़े हो जाएं, उन की सुंदरता नहीं मिटती।

Why: Negative and restrictive emphasis. [[English#^en-Q0269|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Some%20people%2C%20no%20matter%20how%20old%20they%20get%2C%20never%20lose%20their%20beauty.)
^en-Q0269-answer

**en-Q0270** — Some people, no matter how old they get, never lose their beauty.

कुछ लोग, चाहे जितने बूढ़े हो जाएं, उन की सुंदरता नहीं मिटती।

Fronted negative/restrictive adverbials can trigger subject–auxiliary inversion. Only before the subject does not: Only Anna agreed. Scope and placement decide what the restriction actually excludes.

Why: Negative and restrictive emphasis. [[English#^en-Q0270|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Some%20people%2C%20no%20matter%20how%20old%20they%20get%2C%20never%20lose%20their%20beauty.)
^en-Q0270-answer

**en-Q0271** — We should not fret for what is past, nor should we be anxious about the future; men of discernment deal only with the present moment.

हमें न अतीत पर कुढ़ना चाहिए और न ही हमें भविष्य के बारे में चिंतित होना चाहिए; विवेकी व्यक्ति केवल वर्तमान क्षण में ही जीते हैं।

Expected form: **only**

Why: Negative and restrictive emphasis. [[English#^en-Q0271|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=We%20should%20not%20fret%20for%20what%20is%20past%2C%20nor%20should%20we%20be%20anxious%20about%20the%20future%3B%20men%20of%20discernment%20deal%20only%20with%20the%20present%20moment.)
^en-Q0271-answer

**en-Q0272** — We should not fret for what is past, nor should we be anxious about the future; men of discernment deal only with the present moment.

हमें न अतीत पर कुढ़ना चाहिए और न ही हमें भविष्य के बारे में चिंतित होना चाहिए; विवेकी व्यक्ति केवल वर्तमान क्षण में ही जीते हैं।

Expected form: **only**

Why: Negative and restrictive emphasis. [[English#^en-Q0272|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=We%20should%20not%20fret%20for%20what%20is%20past%2C%20nor%20should%20we%20be%20anxious%20about%20the%20future%3B%20men%20of%20discernment%20deal%20only%20with%20the%20present%20moment.)
^en-Q0272-answer

**en-Q0273** — I had hardly reached the school when the bell rang.

मैं बस स्कूल पहुँचा ही था कि घंटी बज गई।

Expected form: **hardly**

Why: Negative and restrictive emphasis. [[English#^en-Q0273|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20had%20hardly%20reached%20the%20school%20when%20the%20bell%20rang.)
^en-Q0273-answer

**en-Q0274** — I had hardly reached the school when the bell rang.

मैं बस स्कूल पहुँचा ही था कि घंटी बज गई।

Why: Negative and restrictive emphasis. [[English#^en-Q0274|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20had%20hardly%20reached%20the%20school%20when%20the%20bell%20rang.)
^en-Q0274-answer

**en-Q0275** — I will never sell my friend down the river for anything in the world.

मैं दुनिया में किसी भी चीज़ के लिए अपने दोस्त को धोखा नहीं दूँगा।

Why: Negative and restrictive emphasis. [[English#^en-Q0275|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20will%20never%20sell%20my%20friend%20down%20the%20river%20for%20anything%20in%20the%20world.)
^en-Q0275-answer

**en-Q0276** — I will never sell my friend down the river for anything in the world.

मैं दुनिया में किसी भी चीज़ के लिए अपने दोस्त को धोखा नहीं दूँगा।

Fronted negative/restrictive adverbials can trigger subject–auxiliary inversion. Only before the subject does not: Only Anna agreed. Scope and placement decide what the restriction actually excludes.

Why: Negative and restrictive emphasis. [[English#^en-Q0276|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20will%20never%20sell%20my%20friend%20down%20the%20river%20for%20anything%20in%20the%20world.)
^en-Q0276-answer

**en-Q0277** — Not only did I eat pilaf, but I also ate kebabs.

मैंने पुलाव ही नहीं, बल्कि कबाब भी खाए।

Expected form: **only**

Why: Negative and restrictive emphasis. [[English#^en-Q0277|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Not%20only%20did%20I%20eat%20pilaf%2C%20but%20I%20also%20ate%20kebabs.)
^en-Q0277-answer

**en-Q0278** — Not only did I eat pilaf, but I also ate kebabs.

मैंने पुलाव ही नहीं, बल्कि कबाब भी खाए।

Expected form: **only**

Why: Negative and restrictive emphasis. [[English#^en-Q0278|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Not%20only%20did%20I%20eat%20pilaf%2C%20but%20I%20also%20ate%20kebabs.)
^en-Q0278-answer

**en-Q0279** — You have only to study hard, and you will pass the test.

तुम्हें टेस्ट पास करने के लिए बस मन लगाकर पढ़ना होगा।

Expected form: **only**

Why: Negative and restrictive emphasis. [[English#^en-Q0279|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=You%20have%20only%20to%20study%20hard%2C%20and%20you%20will%20pass%20the%20test.)
^en-Q0279-answer

**en-Q0280** — You have only to study hard, and you will pass the test.

तुम्हें टेस्ट पास करने के लिए बस मन लगाकर पढ़ना होगा।

Why: Negative and restrictive emphasis. [[English#^en-Q0280|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=You%20have%20only%20to%20study%20hard%2C%20and%20you%20will%20pass%20the%20test.)
^en-Q0280-answer

**en-Q0281** — I have never come across such a stubborn person.

इतने अड़ियल व्यक्ति से मेरी कभी भी मुलाकात नहीं हुई है।

Why: Negative and restrictive emphasis. [[English#^en-Q0281|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20have%20never%20come%20across%20such%20a%20stubborn%20person.)
^en-Q0281-answer

**en-Q0282** — I have never come across such a stubborn person.

इतने अड़ियल व्यक्ति से मेरी कभी भी मुलाकात नहीं हुई है।

Fronted negative/restrictive adverbials can trigger subject–auxiliary inversion. Only before the subject does not: Only Anna agreed. Scope and placement decide what the restriction actually excludes.

Why: Negative and restrictive emphasis. [[English#^en-Q0282|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20have%20never%20come%20across%20such%20a%20stubborn%20person.)
^en-Q0282-answer

**en-Q0283** — I know her by sight, but I've never spoken to her.

मैं उसे पहचानता हूँ पर मैंने उससे कभी बात नहीं करी है।

Expected form: **never**

Why: Negative and restrictive emphasis. [[English#^en-Q0283|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20know%20her%20by%20sight%2C%20but%20I%27ve%20never%20spoken%20to%20her.)
^en-Q0283-answer

**en-Q0284** — I know her by sight, but I've never spoken to her.

मैं उसे पहचानता हूँ पर मैंने उससे कभी बात नहीं करी है।

Expected form: **never**

Why: Negative and restrictive emphasis. [[English#^en-Q0284|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20know%20her%20by%20sight%2C%20but%20I%27ve%20never%20spoken%20to%20her.)
^en-Q0284-answer

**en-Q0285** — I'm only doing this for your own good.

मैं यह बस तुम्हारे ही भले के लिये कर रहा हूं।

Expected form: **only**

Why: Negative and restrictive emphasis. [[English#^en-Q0285|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%27m%20only%20doing%20this%20for%20your%20own%20good.)
^en-Q0285-answer

**en-Q0286** — I'm only doing this for your own good.

मैं यह बस तुम्हारे ही भले के लिये कर रहा हूं।

Why: Negative and restrictive emphasis. [[English#^en-Q0286|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%27m%20only%20doing%20this%20for%20your%20own%20good.)
^en-Q0286-answer

**en-Q0287** — Even the blackest cow only gives white milk.

सबसे काली गाय भी सफ़ेद दूध ही देती।

Why: Negative and restrictive emphasis. [[English#^en-Q0287|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Even%20the%20blackest%20cow%20only%20gives%20white%20milk.)
^en-Q0287-answer

**en-Q0288** — Even the blackest cow only gives white milk.

सबसे काली गाय भी सफ़ेद दूध ही देती।

Fronted negative/restrictive adverbials can trigger subject–auxiliary inversion. Only before the subject does not: Only Anna agreed. Scope and placement decide what the restriction actually excludes.

Why: Negative and restrictive emphasis. [[English#^en-Q0288|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Even%20the%20blackest%20cow%20only%20gives%20white%20milk.)
^en-Q0288-answer

**en-Q0289** — He likes not only music but sports as well.

संगीत के अलावा उसे खेल भी पसंद है।

Expected form: **only**

Why: Negative and restrictive emphasis. [[English#^en-Q0289|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%20likes%20not%20only%20music%20but%20sports%20as%20well.)
^en-Q0289-answer

**en-Q0290** — He likes not only music but sports as well.

संगीत के अलावा उसे खेल भी पसंद है।

Expected form: **only**

Why: Negative and restrictive emphasis. [[English#^en-Q0290|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%20likes%20not%20only%20music%20but%20sports%20as%20well.)
^en-Q0290-answer

**en-Q0291** — I had never seen her before that time.

मैंने उसे पहले कभी नहीं देखा था।

Expected form: **never**

Why: Negative and restrictive emphasis. [[English#^en-Q0291|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20had%20never%20seen%20her%20before%20that%20time.)
^en-Q0291-answer

**en-Q0292** — I had never seen her before that time.

मैंने उसे पहले कभी नहीं देखा था।

Why: Negative and restrictive emphasis. [[English#^en-Q0292|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20had%20never%20seen%20her%20before%20that%20time.)
^en-Q0292-answer

**en-Q0293** — Her only interest is the accumulation of money.

उसको एक ही काम से दिलचस्पी है, और वह है पैसा इकट्ठा करना।

Why: Negative and restrictive emphasis. [[English#^en-Q0293|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Her%20only%20interest%20is%20the%20accumulation%20of%20money.)
^en-Q0293-answer

**en-Q0294** — Her only interest is the accumulation of money.

उसको एक ही काम से दिलचस्पी है, और वह है पैसा इकट्ठा करना।

Fronted negative/restrictive adverbials can trigger subject–auxiliary inversion. Only before the subject does not: Only Anna agreed. Scope and placement decide what the restriction actually excludes.

Why: Negative and restrictive emphasis. [[English#^en-Q0294|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Her%20only%20interest%20is%20the%20accumulation%20of%20money.)
^en-Q0294-answer

**en-Q0295** — Anger is never without a reason, but seldom with a good one.

क्रोध कभी भी बिना कारण नहीं होता, लेकिन कदाचित ही यह कारण सार्थक होता है।

Expected form: **never**

Why: Negative and restrictive emphasis. [[English#^en-Q0295|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Anger%20is%20never%20without%20a%20reason%2C%20but%20seldom%20with%20a%20good%20one.)
^en-Q0295-answer

**en-Q0296** — Anger is never without a reason, but seldom with a good one.

क्रोध कभी भी बिना कारण नहीं होता, लेकिन कदाचित ही यह कारण सार्थक होता है।

Expected form: **never**

Why: Negative and restrictive emphasis. [[English#^en-Q0296|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Anger%20is%20never%20without%20a%20reason%2C%20but%20seldom%20with%20a%20good%20one.)
^en-Q0296-answer

**en-Q0297** — It was the window that Tom broke yesterday.

वह वह खिड़की है जिसको टॉम ने कल थोड़ा था।

Expected form: **It was**

Why: Cleft and focus structures. [[English#^en-Q0297|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=It%20was%20the%20window%20that%20Tom%20broke%20yesterday.)
^en-Q0297-answer

**en-Q0298** — It was the window that Tom broke yesterday.

वह वह खिड़की है जिसको टॉम ने कल थोड़ा था।

Why: Cleft and focus structures. [[English#^en-Q0298|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=It%20was%20the%20window%20that%20Tom%20broke%20yesterday.)
^en-Q0298-answer

**en-Q0299** — What were you and Tom doing in the attic?

तुम और टौम पडछत्ती पर क्या कर रहे थे?

Why: Cleft and focus structures. [[English#^en-Q0299|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=What%20were%20you%20and%20Tom%20doing%20in%20the%20attic%3F)
^en-Q0299-answer

**en-Q0300** — What were you and Tom doing in the attic?

तुम और टौम पडछत्ती पर क्या कर रहे थे?

Clefts and related constructions organise focus: What matters is accuracy. A form such as what can also introduce a question or relative structure, so identify what the sentence highlights and its grammatical frame.

Why: Cleft and focus structures. [[English#^en-Q0300|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=What%20were%20you%20and%20Tom%20doing%20in%20the%20attic%3F)
^en-Q0300-answer


### Answers 301–350

**en-Q0301** — What he did was nothing less than madness.

उसने जो किया वह पागलपन से कुछ कम नहीं था।

Expected form: **What**

Why: Cleft and focus structures. [[English#^en-Q0301|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=What%20he%20did%20was%20nothing%20less%20than%20madness.)
^en-Q0301-answer

**en-Q0302** — What he did was nothing less than madness.

उसने जो किया वह पागलपन से कुछ कम नहीं था।

Expected form: **What**

Why: Cleft and focus structures. [[English#^en-Q0302|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=What%20he%20did%20was%20nothing%20less%20than%20madness.)
^en-Q0302-answer

**en-Q0303** — Almost everything you do will seem insignificant, but it is important that you do it.

आप का कोई भी काम महत्वहीन हो सकता है, किंतु महत्वपूर्ण तो यह है कि आप कुछ करें।

Expected form: **it is**

Why: Cleft and focus structures. [[English#^en-Q0303|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Almost%20everything%20you%20do%20will%20seem%20insignificant%2C%20but%20it%20is%20important%20that%20you%20do%20it.)
^en-Q0303-answer

**en-Q0304** — Almost everything you do will seem insignificant, but it is important that you do it.

आप का कोई भी काम महत्वहीन हो सकता है, किंतु महत्वपूर्ण तो यह है कि आप कुछ करें।

Why: Cleft and focus structures. [[English#^en-Q0304|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Almost%20everything%20you%20do%20will%20seem%20insignificant%2C%20but%20it%20is%20important%20that%20you%20do%20it.)
^en-Q0304-answer

**en-Q0305** — It is not walls that protect men but men that protect walls.

दीवारें इंसानों को नहीं बचातीं, बल्कि इंसान दीवारों को बचाते हैं.

Why: Cleft and focus structures. [[English#^en-Q0305|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=It%20is%20not%20walls%20that%20protect%20men%20but%20men%20that%20protect%20walls.)
^en-Q0305-answer

**en-Q0306** — It is not walls that protect men but men that protect walls.

दीवारें इंसानों को नहीं बचातीं, बल्कि इंसान दीवारों को बचाते हैं.

Clefts and related constructions organise focus: What matters is accuracy. A form such as what can also introduce a question or relative structure, so identify what the sentence highlights and its grammatical frame.

Why: Cleft and focus structures. [[English#^en-Q0306|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=It%20is%20not%20walls%20that%20protect%20men%20but%20men%20that%20protect%20walls.)
^en-Q0306-answer

**en-Q0307** — What is it you want to ask me?

तुम मुझसे क्या पूछना चाहते हो?

Expected form: **What**

Why: Cleft and focus structures. [[English#^en-Q0307|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=What%20is%20it%20you%20want%20to%20ask%20me%3F)
^en-Q0307-answer

**en-Q0308** — What is it you want to ask me?

तुम मुझसे क्या पूछना चाहते हो?

Expected form: **What**

Why: Cleft and focus structures. [[English#^en-Q0308|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=What%20is%20it%20you%20want%20to%20ask%20me%3F)
^en-Q0308-answer

**en-Q0309** — What are you going to do with this car?

तुम इस गाड़ी के साथ क्या करने वाले हो?

Expected form: **What**

Why: Cleft and focus structures. [[English#^en-Q0309|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=What%20are%20you%20going%20to%20do%20with%20this%20car%3F)
^en-Q0309-answer

**en-Q0310** — What are you going to do with this car?

तुम इस गाड़ी के साथ क्या करने वाले हो?

Why: Cleft and focus structures. [[English#^en-Q0310|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=What%20are%20you%20going%20to%20do%20with%20this%20car%3F)
^en-Q0310-answer

**en-Q0311** — It is said that he is the richest man in the world.

कहा जाता है कि वह दुनिया में सबसे अमीर आदमी है।

Why: Cleft and focus structures. [[English#^en-Q0311|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=It%20is%20said%20that%20he%20is%20the%20richest%20man%20in%20the%20world.)
^en-Q0311-answer

**en-Q0312** — It is said that he is the richest man in the world.

कहा जाता है कि वह दुनिया में सबसे अमीर आदमी है।

Clefts and related constructions organise focus: What matters is accuracy. A form such as what can also introduce a question or relative structure, so identify what the sentence highlights and its grammatical frame.

Why: Cleft and focus structures. [[English#^en-Q0312|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=It%20is%20said%20that%20he%20is%20the%20richest%20man%20in%20the%20world.)
^en-Q0312-answer

**en-Q0313** — What time does your watch say it is now?

तुम्हारी घड़ी अब क्या समय बता रही है?

Expected form: **What**

Why: Cleft and focus structures. [[English#^en-Q0313|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=What%20time%20does%20your%20watch%20say%20it%20is%20now%3F)
^en-Q0313-answer

**en-Q0314** — What time does your watch say it is now?

तुम्हारी घड़ी अब क्या समय बता रही है?

Expected form: **What**

Why: Cleft and focus structures. [[English#^en-Q0314|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=What%20time%20does%20your%20watch%20say%20it%20is%20now%3F)
^en-Q0314-answer

**en-Q0315** — It is said that she is a good cook.

कहते हैं की वह अच्छी बावर्ची है।

Expected form: **It is**

Why: Cleft and focus structures. [[English#^en-Q0315|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=It%20is%20said%20that%20she%20is%20a%20good%20cook.)
^en-Q0315-answer

**en-Q0316** — It is said that she is a good cook.

कहते हैं की वह अच्छी बावर्ची है।

Why: Cleft and focus structures. [[English#^en-Q0316|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=It%20is%20said%20that%20she%20is%20a%20good%20cook.)
^en-Q0316-answer

**en-Q0317** — What were you doing at 9 o'clock last night?

तुम कल रात ९ बजे क्या कर रहे थे?

Why: Cleft and focus structures. [[English#^en-Q0317|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=What%20were%20you%20doing%20at%209%20o%27clock%20last%20night%3F)
^en-Q0317-answer

**en-Q0318** — What were you doing at 9 o'clock last night?

तुम कल रात ९ बजे क्या कर रहे थे?

Clefts and related constructions organise focus: What matters is accuracy. A form such as what can also introduce a question or relative structure, so identify what the sentence highlights and its grammatical frame.

Why: Cleft and focus structures. [[English#^en-Q0318|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=What%20were%20you%20doing%20at%209%20o%27clock%20last%20night%3F)
^en-Q0318-answer

**en-Q0319** — What are you going to do with this money?

तुम इन पैसों के साथ क्या करोगे?

Expected form: **What**

Why: Cleft and focus structures. [[English#^en-Q0319|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=What%20are%20you%20going%20to%20do%20with%20this%20money%3F)
^en-Q0319-answer

**en-Q0320** — What are you going to do with this money?

तुम इन पैसों के साथ क्या करोगे?

Expected form: **What**

Why: Cleft and focus structures. [[English#^en-Q0320|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=What%20are%20you%20going%20to%20do%20with%20this%20money%3F)
^en-Q0320-answer

**en-Q0321** — What we are seeking so frantically elsewhere may turn out to be the horse we have been riding all along.

हम जिस चीज़ की तलाश कहीं और कर रहे होते हैं वह हो सकता है कि हमारे पास ही हो।

Expected form: **What**

Why: Cleft and focus structures. [[English#^en-Q0321|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=What%20we%20are%20seeking%20so%20frantically%20elsewhere%20may%20turn%20out%20to%20be%20the%20horse%20we%20have%20been%20riding%20all%20along.)
^en-Q0321-answer

**en-Q0322** — What we are seeking so frantically elsewhere may turn out to be the horse we have been riding all along.

हम जिस चीज़ की तलाश कहीं और कर रहे होते हैं वह हो सकता है कि हमारे पास ही हो।

Why: Cleft and focus structures. [[English#^en-Q0322|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=What%20we%20are%20seeking%20so%20frantically%20elsewhere%20may%20turn%20out%20to%20be%20the%20horse%20we%20have%20been%20riding%20all%20along.)
^en-Q0322-answer

**en-Q0323** — The reason which he gave is hard to understand.

उसके दिए गए कारण को समझना मुश्किल है।

Why: Cleft and focus structures. [[English#^en-Q0323|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20reason%20which%20he%20gave%20is%20hard%20to%20understand.)
^en-Q0323-answer

**en-Q0324** — The reason which he gave is hard to understand.

उसके दिए गए कारण को समझना मुश्किल है।

Clefts and related constructions organise focus: What matters is accuracy. A form such as what can also introduce a question or relative structure, so identify what the sentence highlights and its grammatical frame.

Why: Cleft and focus structures. [[English#^en-Q0324|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20reason%20which%20he%20gave%20is%20hard%20to%20understand.)
^en-Q0324-answer

**en-Q0325** — It is definite that he will go to America.

कि वह अम्रीका जाएगा, यह तो पक्का है।

Expected form: **It is**

Why: Cleft and focus structures. [[English#^en-Q0325|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=It%20is%20definite%20that%20he%20will%20go%20to%20America.)
^en-Q0325-answer

**en-Q0326** — It is definite that he will go to America.

कि वह अम्रीका जाएगा, यह तो पक्का है।

Expected form: **It is**

Why: Cleft and focus structures. [[English#^en-Q0326|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=It%20is%20definite%20that%20he%20will%20go%20to%20America.)
^en-Q0326-answer

**en-Q0327** — It was my brother that made the mistake.

वह ग़लती मेरे भ्राता की थी.

Expected form: **It was**

Why: Cleft and focus structures. [[English#^en-Q0327|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=It%20was%20my%20brother%20that%20made%20the%20mistake.)
^en-Q0327-answer

**en-Q0328** — It was my brother that made the mistake.

वह ग़लती मेरे भ्राता की थी.

Why: Cleft and focus structures. [[English#^en-Q0328|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=It%20was%20my%20brother%20that%20made%20the%20mistake.)
^en-Q0328-answer

**en-Q0329** — It is said that women live longer than men.

कहा जाता है कि औरतों की उम्र आदमियों से ज़्यादा लम्बी होती है।

Why: Cleft and focus structures. [[English#^en-Q0329|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=It%20is%20said%20that%20women%20live%20longer%20than%20men.)
^en-Q0329-answer

**en-Q0330** — It is said that women live longer than men.

कहा जाता है कि औरतों की उम्र आदमियों से ज़्यादा लम्बी होती है।

Clefts and related constructions organise focus: What matters is accuracy. A form such as what can also introduce a question or relative structure, so identify what the sentence highlights and its grammatical frame.

Why: Cleft and focus structures. [[English#^en-Q0330|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=It%20is%20said%20that%20women%20live%20longer%20than%20men.)
^en-Q0330-answer

**en-Q0331** — The reason for declaring war is not certain.

जंग के ऐलान का कारण साफ़ नहीं है।

Expected form: **The reason**

Why: Cleft and focus structures. [[English#^en-Q0331|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20reason%20for%20declaring%20war%20is%20not%20certain.)
^en-Q0331-answer

**en-Q0332** — The reason for declaring war is not certain.

जंग के ऐलान का कारण साफ़ नहीं है।

Expected form: **The reason**

Why: Cleft and focus structures. [[English#^en-Q0332|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20reason%20for%20declaring%20war%20is%20not%20certain.)
^en-Q0332-answer

**en-Q0333** — It was cold that day, and moreover it began to rain.

उस दिन ठंड थी, और ऊपर से बारिश होने लगी।

Expected form: **It was**

Why: Cleft and focus structures. [[English#^en-Q0333|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=It%20was%20cold%20that%20day%2C%20and%20moreover%20it%20began%20to%20rain.)
^en-Q0333-answer

**en-Q0334** — It was cold that day, and moreover it began to rain.

उस दिन ठंड थी, और ऊपर से बारिश होने लगी।

Why: Cleft and focus structures. [[English#^en-Q0334|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=It%20was%20cold%20that%20day%2C%20and%20moreover%20it%20began%20to%20rain.)
^en-Q0334-answer

**en-Q0335** — What did you say? I'm sorry, I was lost in thought.

आपने क्या कहा? माफ़ करें, मैं सोच में डूबा था इसलिए मैंने सुना नहीं।

Why: Cleft and focus structures. [[English#^en-Q0335|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=What%20did%20you%20say%3F%20I%27m%20sorry%2C%20I%20was%20lost%20in%20thought.)
^en-Q0335-answer

**en-Q0336** — What did you say? I'm sorry, I was lost in thought.

आपने क्या कहा? माफ़ करें, मैं सोच में डूबा था इसलिए मैंने सुना नहीं।

Clefts and related constructions organise focus: What matters is accuracy. A form such as what can also introduce a question or relative structure, so identify what the sentence highlights and its grammatical frame.

Why: Cleft and focus structures. [[English#^en-Q0336|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=What%20did%20you%20say%3F%20I%27m%20sorry%2C%20I%20was%20lost%20in%20thought.)
^en-Q0336-answer

**en-Q0337** — It is necessary that she should go herself.

उसका अकेला जाना ज़रूरी है।

Expected form: **It is**

Why: Cleft and focus structures. [[English#^en-Q0337|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=It%20is%20necessary%20that%20she%20should%20go%20herself.)
^en-Q0337-answer

**en-Q0338** — It is necessary that she should go herself.

उसका अकेला जाना ज़रूरी है।

Expected form: **It is**

Why: Cleft and focus structures. [[English#^en-Q0338|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=It%20is%20necessary%20that%20she%20should%20go%20herself.)
^en-Q0338-answer

**en-Q0339** — The reason why you failed is you did not try hard enough.

तुम नाकामयाब इसलिए रहे क्योंकि तुमने पूरी तरह मेहनत नहीं लगाई।

Expected form: **The reason**

Why: Cleft and focus structures. [[English#^en-Q0339|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20reason%20why%20you%20failed%20is%20you%20did%20not%20try%20hard%20enough.)
^en-Q0339-answer

**en-Q0340** — The reason why you failed is you did not try hard enough.

तुम नाकामयाब इसलिए रहे क्योंकि तुमने पूरी तरह मेहनत नहीं लगाई।

Why: Cleft and focus structures. [[English#^en-Q0340|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20reason%20why%20you%20failed%20is%20you%20did%20not%20try%20hard%20enough.)
^en-Q0340-answer

**en-Q0341** — It was so noisy that I couldn't make myself heard.

इतना शोर था कि किसी को भी मेरी आवाज़ सुनाई नहीं दे रही थी।

Why: Cleft and focus structures. [[English#^en-Q0341|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=It%20was%20so%20noisy%20that%20I%20couldn%27t%20make%20myself%20heard.)
^en-Q0341-answer

**en-Q0342** — It was so noisy that I couldn't make myself heard.

इतना शोर था कि किसी को भी मेरी आवाज़ सुनाई नहीं दे रही थी।

Clefts and related constructions organise focus: What matters is accuracy. A form such as what can also introduce a question or relative structure, so identify what the sentence highlights and its grammatical frame.

Why: Cleft and focus structures. [[English#^en-Q0342|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=It%20was%20so%20noisy%20that%20I%20couldn%27t%20make%20myself%20heard.)
^en-Q0342-answer

**en-Q0343** — It is not the man who has too little, but the man who craves more, that is poor.

वह व्यक्ति ग़रीब नहीं है जिस के पास थोड़ा बहुत ही है। ग़रीब तो वह है जो ज़्यादा के लिए मरा जा रहा है।

Expected form: **It is**

Why: Cleft and focus structures. [[English#^en-Q0343|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=It%20is%20not%20the%20man%20who%20has%20too%20little%2C%20but%20the%20man%20who%20craves%20more%2C%20that%20is%20poor.)
^en-Q0343-answer

**en-Q0344** — It is not the man who has too little, but the man who craves more, that is poor.

वह व्यक्ति ग़रीब नहीं है जिस के पास थोड़ा बहुत ही है। ग़रीब तो वह है जो ज़्यादा के लिए मरा जा रहा है।

Expected form: **It is**

Why: Cleft and focus structures. [[English#^en-Q0344|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=It%20is%20not%20the%20man%20who%20has%20too%20little%2C%20but%20the%20man%20who%20craves%20more%2C%20that%20is%20poor.)
^en-Q0344-answer

**en-Q0345** — It is often said that the best way to learn a foreign language is to go to the country where it is spoken.

अक्सर कहा जाता है कि किसी भी विदेशी भाषा को सीखने का सबसे अच्छा तरीका उस देश में जाकर रहना होता है।

Expected form: **It is**

Why: Cleft and focus structures. [[English#^en-Q0345|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=It%20is%20often%20said%20that%20the%20best%20way%20to%20learn%20a%20foreign%20language%20is%20to%20go%20to%20the%20country%20where%20it%20is%20spoken.)
^en-Q0345-answer

**en-Q0346** — It is often said that the best way to learn a foreign language is to go to the country where it is spoken.

अक्सर कहा जाता है कि किसी भी विदेशी भाषा को सीखने का सबसे अच्छा तरीका उस देश में जाकर रहना होता है।

Why: Cleft and focus structures. [[English#^en-Q0346|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=It%20is%20often%20said%20that%20the%20best%20way%20to%20learn%20a%20foreign%20language%20is%20to%20go%20to%20the%20country%20where%20it%20is%20spoken.)
^en-Q0346-answer

**en-Q0347** — The passengers who were injured in the accident were taken to the nearest hospital.

जिन यात्रियों को दुर्घटना मे चोट आई थी उन्हे अस्पताल ले जाया गया।

Why: Relative clauses. [[English#^en-Q0347|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20passengers%20who%20were%20injured%20in%20the%20accident%20were%20taken%20to%20the%20nearest%20hospital.)
^en-Q0347-answer

**en-Q0348** — The passengers who were injured in the accident were taken to the nearest hospital.

जिन यात्रियों को दुर्घटना मे चोट आई थी उन्हे अस्पताल ले जाया गया।

Relative forms connect an antecedent to a clause. Restrictive and supplementary clauses differ in punctuation and meaning. Whose expresses a possessive relation; whom is an object form mainly retained in formal contexts.

Why: Relative clauses. [[English#^en-Q0348|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20passengers%20who%20were%20injured%20in%20the%20accident%20were%20taken%20to%20the%20nearest%20hospital.)
^en-Q0348-answer

**en-Q0349** — Mother Teresa was a Catholic nun who lived and worked in Calcutta, India.

मदर टेरेसा एक कैथोलिक नन थीं जो कलकत्ता में रहतीं और काम करतीं थीं।

Expected form: **who**

Why: Relative clauses. [[English#^en-Q0349|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Mother%20Teresa%20was%20a%20Catholic%20nun%20who%20lived%20and%20worked%20in%20Calcutta%2C%20India.)
^en-Q0349-answer

**en-Q0350** — Mother Teresa was a Catholic nun who lived and worked in Calcutta, India.

मदर टेरेसा एक कैथोलिक नन थीं जो कलकत्ता में रहतीं और काम करतीं थीं।

Expected form: **who**

Why: Relative clauses. [[English#^en-Q0350|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Mother%20Teresa%20was%20a%20Catholic%20nun%20who%20lived%20and%20worked%20in%20Calcutta%2C%20India.)
^en-Q0350-answer


### Answers 351–400

**en-Q0351** — I know a girl who can ride a unicycle.

मेरे जान-पहचान की एक लड़की को युनिसायकल चलाना आता है।

Expected form: **who**

Why: Relative clauses. [[English#^en-Q0351|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20know%20a%20girl%20who%20can%20ride%20a%20unicycle.)
^en-Q0351-answer

**en-Q0352** — I know a girl who can ride a unicycle.

मेरे जान-पहचान की एक लड़की को युनिसायकल चलाना आता है।

Why: Relative clauses. [[English#^en-Q0352|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20know%20a%20girl%20who%20can%20ride%20a%20unicycle.)
^en-Q0352-answer

**en-Q0353** — The girl who works at that bakery is cute.

बेकरी में काम करनेवाली वह लड़की प्यारी है।

Why: Relative clauses. [[English#^en-Q0353|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20girl%20who%20works%20at%20that%20bakery%20is%20cute.)
^en-Q0353-answer

**en-Q0354** — The girl who works at that bakery is cute.

बेकरी में काम करनेवाली वह लड़की प्यारी है।

Relative forms connect an antecedent to a clause. Restrictive and supplementary clauses differ in punctuation and meaning. Whose expresses a possessive relation; whom is an object form mainly retained in formal contexts.

Why: Relative clauses. [[English#^en-Q0354|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20girl%20who%20works%20at%20that%20bakery%20is%20cute.)
^en-Q0354-answer

**en-Q0355** — I have an uncle who lives in Kyoto.

मेरे क्योतो में रहने वाले एक चाचा हैं।

Expected form: **who**

Why: Relative clauses. [[English#^en-Q0355|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20have%20an%20uncle%20who%20lives%20in%20Kyoto.)
^en-Q0355-answer

**en-Q0356** — I have an uncle who lives in Kyoto.

मेरे क्योतो में रहने वाले एक चाचा हैं।

Expected form: **who**

Why: Relative clauses. [[English#^en-Q0356|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20have%20an%20uncle%20who%20lives%20in%20Kyoto.)
^en-Q0356-answer

**en-Q0357** — He who starts ten tasks won't finish a single one.

जो दस काम शुरू करता है वह एक भी खत्म नहीं करेगा।

Expected form: **who**

Why: Relative clauses. [[English#^en-Q0357|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%20who%20starts%20ten%20tasks%20won%27t%20finish%20a%20single%20one.)
^en-Q0357-answer

**en-Q0358** — He who starts ten tasks won't finish a single one.

जो दस काम शुरू करता है वह एक भी खत्म नहीं करेगा।

Why: Relative clauses. [[English#^en-Q0358|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%20who%20starts%20ten%20tasks%20won%27t%20finish%20a%20single%20one.)
^en-Q0358-answer

**en-Q0359** — I was searching for something that didn't exist.

मैं एक ऐसी चीज़ ढूँढ रहा था जिसका अस्तित्व कभी था ही नहीं।

Why: Relative clauses. [[English#^en-Q0359|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20was%20searching%20for%20something%20that%20didn%27t%20exist.)
^en-Q0359-answer

**en-Q0360** — I was searching for something that didn't exist.

मैं एक ऐसी चीज़ ढूँढ रहा था जिसका अस्तित्व कभी था ही नहीं।

Relative forms connect an antecedent to a clause. Restrictive and supplementary clauses differ in punctuation and meaning. Whose expresses a possessive relation; whom is an object form mainly retained in formal contexts.

Why: Relative clauses. [[English#^en-Q0360|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20was%20searching%20for%20something%20that%20didn%27t%20exist.)
^en-Q0360-answer

**en-Q0361** — Children whose parents are dead are referred to as "orphans".

जिन बच्चों के माता-पिता की मृत्यु हो गई होती है उने "अनाथ" बुलाया जाता है।

Expected form: **whose**

Why: Relative clauses. [[English#^en-Q0361|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Children%20whose%20parents%20are%20dead%20are%20referred%20to%20as%20%22orphans%22.)
^en-Q0361-answer

**en-Q0362** — Children whose parents are dead are referred to as "orphans".

जिन बच्चों के माता-पिता की मृत्यु हो गई होती है उने "अनाथ" बुलाया जाता है।

Expected form: **whose**

Why: Relative clauses. [[English#^en-Q0362|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Children%20whose%20parents%20are%20dead%20are%20referred%20to%20as%20%22orphans%22.)
^en-Q0362-answer

**en-Q0363** — John, who is the youngest in a family of seven, is the apple of his parents' eyes.

जॉन, जो सात बच्चों के परिवार में सबसे छोटा है, वह अपने माता-पिता के आँखों का तारा है.

Expected form: **who**

Why: Relative clauses. [[English#^en-Q0363|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=John%2C%20who%20is%20the%20youngest%20in%20a%20family%20of%20seven%2C%20is%20the%20apple%20of%20his%20parents%27%20eyes.)
^en-Q0363-answer

**en-Q0364** — John, who is the youngest in a family of seven, is the apple of his parents' eyes.

जॉन, जो सात बच्चों के परिवार में सबसे छोटा है, वह अपने माता-पिता के आँखों का तारा है.

Why: Relative clauses. [[English#^en-Q0364|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=John%2C%20who%20is%20the%20youngest%20in%20a%20family%20of%20seven%2C%20is%20the%20apple%20of%20his%20parents%27%20eyes.)
^en-Q0364-answer

**en-Q0365** — No circumstance, no purpose, no law whatsoever can ever make licit an act which is intrinsically illicit.

कोई परिस्थिति, कोई उद्देश्य, किसी भी प्रकार का कोई कानून, किसी अंतर्निहित रूप से अवैध कार्य को कभी वैध नहीं बना सकता है।

Why: Relative clauses. [[English#^en-Q0365|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=No%20circumstance%2C%20no%20purpose%2C%20no%20law%20whatsoever%20can%20ever%20make%20licit%20an%20act%20which%20is%20intrinsically%20illicit.)
^en-Q0365-answer

**en-Q0366** — No circumstance, no purpose, no law whatsoever can ever make licit an act which is intrinsically illicit.

कोई परिस्थिति, कोई उद्देश्य, किसी भी प्रकार का कोई कानून, किसी अंतर्निहित रूप से अवैध कार्य को कभी वैध नहीं बना सकता है।

Relative forms connect an antecedent to a clause. Restrictive and supplementary clauses differ in punctuation and meaning. Whose expresses a possessive relation; whom is an object form mainly retained in formal contexts.

Why: Relative clauses. [[English#^en-Q0366|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=No%20circumstance%2C%20no%20purpose%2C%20no%20law%20whatsoever%20can%20ever%20make%20licit%20an%20act%20which%20is%20intrinsically%20illicit.)
^en-Q0366-answer

**en-Q0367** — I have a friend who lives in England.

मेरा एक दोस्त है जो इंग्लैंड में रहता है।

Expected form: **who**

Why: Relative clauses. [[English#^en-Q0367|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20have%20a%20friend%20who%20lives%20in%20England.)
^en-Q0367-answer

**en-Q0368** — I have a friend who lives in England.

मेरा एक दोस्त है जो इंग्लैंड में रहता है।

Expected form: **who**

Why: Relative clauses. [[English#^en-Q0368|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20have%20a%20friend%20who%20lives%20in%20England.)
^en-Q0368-answer

**en-Q0369** — There was a man who had three sons.

एक आदमी था जिसके तीन बेटे थे।

Expected form: **who**

Why: Relative clauses. [[English#^en-Q0369|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=There%20was%20a%20man%20who%20had%20three%20sons.)
^en-Q0369-answer

**en-Q0370** — There was a man who had three sons.

एक आदमी था जिसके तीन बेटे थे।

Why: Relative clauses. [[English#^en-Q0370|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=There%20was%20a%20man%20who%20had%20three%20sons.)
^en-Q0370-answer

**en-Q0371** — The police still can't point out who committed the crime.

पुलिस को अब तक इस बात की जानकारी नहीं है कि जुर्म किसने किया है।

Why: Relative clauses. [[English#^en-Q0371|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20police%20still%20can%27t%20point%20out%20who%20committed%20the%20crime.)
^en-Q0371-answer

**en-Q0372** — The police still can't point out who committed the crime.

पुलिस को अब तक इस बात की जानकारी नहीं है कि जुर्म किसने किया है।

Relative forms connect an antecedent to a clause. Restrictive and supplementary clauses differ in punctuation and meaning. Whose expresses a possessive relation; whom is an object form mainly retained in formal contexts.

Why: Relative clauses. [[English#^en-Q0372|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20police%20still%20can%27t%20point%20out%20who%20committed%20the%20crime.)
^en-Q0372-answer

**en-Q0373** — Don't meddle in things that are none of your business.

तुम दूसरों के मसलों में अपनी नाक मत घुसाओ।

Expected form: **that**

Why: Relative clauses. [[English#^en-Q0373|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Don%27t%20meddle%20in%20things%20that%20are%20none%20of%20your%20business.)
^en-Q0373-answer

**en-Q0374** — Don't meddle in things that are none of your business.

तुम दूसरों के मसलों में अपनी नाक मत घुसाओ।

Expected form: **that**

Why: Relative clauses. [[English#^en-Q0374|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Don%27t%20meddle%20in%20things%20that%20are%20none%20of%20your%20business.)
^en-Q0374-answer

**en-Q0375** — I saw a girl whose hair came down to her waist.

मैंने एक लड़की को देखा जिसके बाल उसकी कमर तक आते थे।

Expected form: **whose**

Why: Relative clauses. [[English#^en-Q0375|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20saw%20a%20girl%20whose%20hair%20came%20down%20to%20her%20waist.)
^en-Q0375-answer

**en-Q0376** — I saw a girl whose hair came down to her waist.

मैंने एक लड़की को देखा जिसके बाल उसकी कमर तक आते थे।

Why: Relative clauses. [[English#^en-Q0376|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20saw%20a%20girl%20whose%20hair%20came%20down%20to%20her%20waist.)
^en-Q0376-answer

**en-Q0377** — I have two sisters, both of whom are married.

मेरी दो बहनें हैं और दोनो की शादी हो चुकी है।

Why: Relative clauses. [[English#^en-Q0377|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20have%20two%20sisters%2C%20both%20of%20whom%20are%20married.)
^en-Q0377-answer

**en-Q0378** — I have two sisters, both of whom are married.

मेरी दो बहनें हैं और दोनो की शादी हो चुकी है।

Relative forms connect an antecedent to a clause. Restrictive and supplementary clauses differ in punctuation and meaning. Whose expresses a possessive relation; whom is an object form mainly retained in formal contexts.

Why: Relative clauses. [[English#^en-Q0378|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20have%20two%20sisters%2C%20both%20of%20whom%20are%20married.)
^en-Q0378-answer

**en-Q0379** — This is the very book that I wanted to read.

यह वही किताब है जिसे मैं पढ़ना चाह्ता था।

Expected form: **that**

Why: Relative clauses. [[English#^en-Q0379|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=This%20is%20the%20very%20book%20that%20I%20wanted%20to%20read.)
^en-Q0379-answer

**en-Q0380** — This is the very book that I wanted to read.

यह वही किताब है जिसे मैं पढ़ना चाह्ता था।

Expected form: **that**

Why: Relative clauses. [[English#^en-Q0380|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=This%20is%20the%20very%20book%20that%20I%20wanted%20to%20read.)
^en-Q0380-answer

**en-Q0381** — The man who is standing there is my father.

वहाँ पर खड़े हुए वे मेरे पिता हैं।

Expected form: **who**

Why: Relative clauses. [[English#^en-Q0381|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20man%20who%20is%20standing%20there%20is%20my%20father.)
^en-Q0381-answer

**en-Q0382** — The man who is standing there is my father.

वहाँ पर खड़े हुए वे मेरे पिता हैं।

Why: Relative clauses. [[English#^en-Q0382|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20man%20who%20is%20standing%20there%20is%20my%20father.)
^en-Q0382-answer

**en-Q0383** — Ninety-nine percent of all failures come from people who have the habit of making excuses.

असफल व्यक्तियों में से निन्यानवे प्रतिशत वे लोग होते हैं जिन की आदत बहाने बनाने की होती है।

Why: Relative clauses. [[English#^en-Q0383|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Ninety-nine%20percent%20of%20all%20failures%20come%20from%20people%20who%20have%20the%20habit%20of%20making%20excuses.)
^en-Q0383-answer

**en-Q0384** — Ninety-nine percent of all failures come from people who have the habit of making excuses.

असफल व्यक्तियों में से निन्यानवे प्रतिशत वे लोग होते हैं जिन की आदत बहाने बनाने की होती है।

Relative forms connect an antecedent to a clause. Restrictive and supplementary clauses differ in punctuation and meaning. Whose expresses a possessive relation; whom is an object form mainly retained in formal contexts.

Why: Relative clauses. [[English#^en-Q0384|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Ninety-nine%20percent%20of%20all%20failures%20come%20from%20people%20who%20have%20the%20habit%20of%20making%20excuses.)
^en-Q0384-answer

**en-Q0385** — Cross off the names of the people who have paid their dues.

जो पैसे भर चुकें हैं, उनके नाम काट दो।

Expected form: **who**

Why: Relative clauses. [[English#^en-Q0385|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Cross%20off%20the%20names%20of%20the%20people%20who%20have%20paid%20their%20dues.)
^en-Q0385-answer

**en-Q0386** — Cross off the names of the people who have paid their dues.

जो पैसे भर चुकें हैं, उनके नाम काट दो।

Expected form: **who**

Why: Relative clauses. [[English#^en-Q0386|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Cross%20off%20the%20names%20of%20the%20people%20who%20have%20paid%20their%20dues.)
^en-Q0386-answer

**en-Q0387** — I don't like teachers who like students who don't like asking questions.

सवाल पूछना न पसंद करने वाले विद्यार्थियों को पसंद करने वाले शिक्षक मुझे पसंद नहीं।

Expected form: **who**

Why: Relative clauses. [[English#^en-Q0387|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20don%27t%20like%20teachers%20who%20like%20students%20who%20don%27t%20like%20asking%20questions.)
^en-Q0387-answer

**en-Q0388** — I don't like teachers who like students who don't like asking questions.

सवाल पूछना न पसंद करने वाले विद्यार्थियों को पसंद करने वाले शिक्षक मुझे पसंद नहीं।

Why: Relative clauses. [[English#^en-Q0388|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20don%27t%20like%20teachers%20who%20like%20students%20who%20don%27t%20like%20asking%20questions.)
^en-Q0388-answer

**en-Q0389** — My wardrobe has four doors and two mirrors. It was manufactured by a Swedish company, whose name contains three vowels and a consonant.

मेरी अलमारी में चार पट और दो आईनें हैं. उसको एक स्वीडिश कंपनी ने बनाया है, जिसके नाम में तीन स्वर और एक व्यंजन है.

Why: Relative clauses. [[English#^en-Q0389|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=My%20wardrobe%20has%20four%20doors%20and%20two%20mirrors.%20It%20was%20manufactured%20by%20a%20Swedish%20company%2C%20whose%20name%20contains%20three%20vowels%20and%20a%20consonant.)
^en-Q0389-answer

**en-Q0390** — My wardrobe has four doors and two mirrors. It was manufactured by a Swedish company, whose name contains three vowels and a consonant.

मेरी अलमारी में चार पट और दो आईनें हैं. उसको एक स्वीडिश कंपनी ने बनाया है, जिसके नाम में तीन स्वर और एक व्यंजन है.

Relative forms connect an antecedent to a clause. Restrictive and supplementary clauses differ in punctuation and meaning. Whose expresses a possessive relation; whom is an object form mainly retained in formal contexts.

Why: Relative clauses. [[English#^en-Q0390|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=My%20wardrobe%20has%20four%20doors%20and%20two%20mirrors.%20It%20was%20manufactured%20by%20a%20Swedish%20company%2C%20whose%20name%20contains%20three%20vowels%20and%20a%20consonant.)
^en-Q0390-answer

**en-Q0391** — He never takes into account the fact that I am very busy.

वह कभी भी इस बात का खयाल नहीं करता है कि मैं कितना व्यस्थ हूँ।

Expected form: **that**

Why: Relative clauses. [[English#^en-Q0391|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%20never%20takes%20into%20account%20the%20fact%20that%20I%20am%20very%20busy.)
^en-Q0391-answer

**en-Q0392** — He never takes into account the fact that I am very busy.

वह कभी भी इस बात का खयाल नहीं करता है कि मैं कितना व्यस्थ हूँ।

Expected form: **that**

Why: Relative clauses. [[English#^en-Q0392|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%20never%20takes%20into%20account%20the%20fact%20that%20I%20am%20very%20busy.)
^en-Q0392-answer

**en-Q0393** — In baseball, the pitcher is the player who throws the ball.

बेसबॉल में गेंद फेंकने वाले को "पिचर" कहते है।

Expected form: **who**

Why: Relative clauses. [[English#^en-Q0393|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=In%20baseball%2C%20the%20pitcher%20is%20the%20player%20who%20throws%20the%20ball.)
^en-Q0393-answer

**en-Q0394** — In baseball, the pitcher is the player who throws the ball.

बेसबॉल में गेंद फेंकने वाले को "पिचर" कहते है।

Why: Relative clauses. [[English#^en-Q0394|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=In%20baseball%2C%20the%20pitcher%20is%20the%20player%20who%20throws%20the%20ball.)
^en-Q0394-answer

**en-Q0395** — Is it fine if I explain in English? Anyone who wouldn't be comfortable with English, please raise your hand.

अंग्रेज़ी में समझाया तो चलेगा क्या? जिन्हें अंग्रेज़ी से तकलीफ़ है वो हाथ उठाएँ।

Why: Relative clauses. [[English#^en-Q0395|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Is%20it%20fine%20if%20I%20explain%20in%20English%3F%20Anyone%20who%20wouldn%27t%20be%20comfortable%20with%20English%2C%20please%20raise%20your%20hand.)
^en-Q0395-answer

**en-Q0396** — Is it fine if I explain in English? Anyone who wouldn't be comfortable with English, please raise your hand.

अंग्रेज़ी में समझाया तो चलेगा क्या? जिन्हें अंग्रेज़ी से तकलीफ़ है वो हाथ उठाएँ।

Relative forms connect an antecedent to a clause. Restrictive and supplementary clauses differ in punctuation and meaning. Whose expresses a possessive relation; whom is an object form mainly retained in formal contexts.

Why: Relative clauses. [[English#^en-Q0396|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Is%20it%20fine%20if%20I%20explain%20in%20English%3F%20Anyone%20who%20wouldn%27t%20be%20comfortable%20with%20English%2C%20please%20raise%20your%20hand.)
^en-Q0396-answer

**en-Q0397** — I don't know how to operate this computer.

मुझे यह कम्प्यूटर चलाना नहीं आता।

Expected form: **how**

Why: Embedded questions. [[English#^en-Q0397|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20don%27t%20know%20how%20to%20operate%20this%20computer.)
^en-Q0397-answer

**en-Q0398** — I don't know how to operate this computer.

मुझे यह कम्प्यूटर चलाना नहीं आता।

Expected form: **how**

Why: Embedded questions. [[English#^en-Q0398|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20don%27t%20know%20how%20to%20operate%20this%20computer.)
^en-Q0398-answer

**en-Q0399** — She's trying to whistle, but she doesn't know how.

वह सीटी बजाने की कोशिश कर रही है, मगर उसे बजाने नहीं आती।

Expected form: **how**

Why: Embedded questions. [[English#^en-Q0399|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=She%27s%20trying%20to%20whistle%2C%20but%20she%20doesn%27t%20know%20how.)
^en-Q0399-answer

**en-Q0400** — She's trying to whistle, but she doesn't know how.

वह सीटी बजाने की कोशिश कर रही है, मगर उसे बजाने नहीं आती।

Why: Embedded questions. [[English#^en-Q0400|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=She%27s%20trying%20to%20whistle%2C%20but%20she%20doesn%27t%20know%20how.)
^en-Q0400-answer


### Answers 401–450

**en-Q0401** — Tom wants to know why you didn't call him back.

टॉम पूछ रहा है कि तुमने उसे कॉल बैक क्यों नहीं किया।

Why: Embedded questions. [[English#^en-Q0401|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Tom%20wants%20to%20know%20why%20you%20didn%27t%20call%20him%20back.)
^en-Q0401-answer

**en-Q0402** — Tom wants to know why you didn't call him back.

टॉम पूछ रहा है कि तुमने उसे कॉल बैक क्यों नहीं किया।

Embedded questions ordinarily have statement order: I wonder where she is. Whether can introduce explicit alternatives. Do not carry direct-question inversion into an ordinary embedded question.

Why: Embedded questions. [[English#^en-Q0402|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Tom%20wants%20to%20know%20why%20you%20didn%27t%20call%20him%20back.)
^en-Q0402-answer

**en-Q0403** — Can you tell me when to switch the machine off?

क्या मुझे बता सकते हो कि मशीन को कब बंद करना है?

Expected form: **when**

Why: Embedded questions. [[English#^en-Q0403|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Can%20you%20tell%20me%20when%20to%20switch%20the%20machine%20off%3F)
^en-Q0403-answer

**en-Q0404** — Can you tell me when to switch the machine off?

क्या मुझे बता सकते हो कि मशीन को कब बंद करना है?

Expected form: **when**

Why: Embedded questions. [[English#^en-Q0404|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Can%20you%20tell%20me%20when%20to%20switch%20the%20machine%20off%3F)
^en-Q0404-answer

**en-Q0405** — But I don't know how to cook kebabs!

पर मुझे कबाब पकाना नहीं आता!

Expected form: **how**

Why: Embedded questions. [[English#^en-Q0405|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=But%20I%20don%27t%20know%20how%20to%20cook%20kebabs%21)
^en-Q0405-answer

**en-Q0406** — But I don't know how to cook kebabs!

पर मुझे कबाब पकाना नहीं आता!

Why: Embedded questions. [[English#^en-Q0406|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=But%20I%20don%27t%20know%20how%20to%20cook%20kebabs%21)
^en-Q0406-answer

**en-Q0407** — Tom doesn't yet know how to do that.

टॉम अभी तक नहीं जानता कि ऐसा कैसे करना है।

Why: Embedded questions. [[English#^en-Q0407|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Tom%20doesn%27t%20yet%20know%20how%20to%20do%20that.)
^en-Q0407-answer

**en-Q0408** — Tom doesn't yet know how to do that.

टॉम अभी तक नहीं जानता कि ऐसा कैसे करना है।

Embedded questions ordinarily have statement order: I wonder where she is. Whether can introduce explicit alternatives. Do not carry direct-question inversion into an ordinary embedded question.

Why: Embedded questions. [[English#^en-Q0408|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Tom%20doesn%27t%20yet%20know%20how%20to%20do%20that.)
^en-Q0408-answer

**en-Q0409** — I will tell him about it when he comes next time.

जब वह अगली बार आएगा, मैं उसे इसके बारे में बाताऊँगा।

Expected form: **when**

Why: Embedded questions. [[English#^en-Q0409|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20will%20tell%20him%20about%20it%20when%20he%20comes%20next%20time.)
^en-Q0409-answer

**en-Q0410** — I will tell him about it when he comes next time.

जब वह अगली बार आएगा, मैं उसे इसके बारे में बाताऊँगा।

Expected form: **when**

Why: Embedded questions. [[English#^en-Q0410|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20will%20tell%20him%20about%20it%20when%20he%20comes%20next%20time.)
^en-Q0410-answer

**en-Q0411** — I am not sure how to pronounce the word.

मुझे ठीक से नहीं पता इस शब्द को कैसे पढ़ा जाता है।

Expected form: **how**

Why: Embedded questions. [[English#^en-Q0411|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20am%20not%20sure%20how%20to%20pronounce%20the%20word.)
^en-Q0411-answer

**en-Q0412** — I am not sure how to pronounce the word.

मुझे ठीक से नहीं पता इस शब्द को कैसे पढ़ा जाता है।

Why: Embedded questions. [[English#^en-Q0412|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20am%20not%20sure%20how%20to%20pronounce%20the%20word.)
^en-Q0412-answer

**en-Q0413** — Do you know how to use a computer?

क्या आपको कम्प्यूटर का इस्तेमाल करना आता है?

Why: Embedded questions. [[English#^en-Q0413|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Do%20you%20know%20how%20to%20use%20a%20computer%3F)
^en-Q0413-answer

**en-Q0414** — Do you know how to use a computer?

क्या आपको कम्प्यूटर का इस्तेमाल करना आता है?

Embedded questions ordinarily have statement order: I wonder where she is. Whether can introduce explicit alternatives. Do not carry direct-question inversion into an ordinary embedded question.

Why: Embedded questions. [[English#^en-Q0414|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Do%20you%20know%20how%20to%20use%20a%20computer%3F)
^en-Q0414-answer

**en-Q0415** — Don't ask me why but, he ran away when he saw me.

मुझे यह मत पूछना क्यूँ, किन्तु वह मुझे देख कर भाग गया.

Expected form: **why**

Why: Embedded questions. [[English#^en-Q0415|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Don%27t%20ask%20me%20why%20but%2C%20he%20ran%20away%20when%20he%20saw%20me.)
^en-Q0415-answer

**en-Q0416** — Don't ask me why but, he ran away when he saw me.

मुझे यह मत पूछना क्यूँ, किन्तु वह मुझे देख कर भाग गया.

Expected form: **why**

Why: Embedded questions. [[English#^en-Q0416|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Don%27t%20ask%20me%20why%20but%2C%20he%20ran%20away%20when%20he%20saw%20me.)
^en-Q0416-answer

**en-Q0417** — Tom doesn't know how to do that yet.

टॉम अभी तक नहीं जानता कि यह कैसे करना है।

Expected form: **how**

Why: Embedded questions. [[English#^en-Q0417|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Tom%20doesn%27t%20know%20how%20to%20do%20that%20yet.)
^en-Q0417-answer

**en-Q0418** — Tom doesn't know how to do that yet.

टॉम अभी तक नहीं जानता कि यह कैसे करना है।

Why: Embedded questions. [[English#^en-Q0418|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Tom%20doesn%27t%20know%20how%20to%20do%20that%20yet.)
^en-Q0418-answer

**en-Q0419** — I don't know how, but she did it.

पता नहीं कैसे पर उसने कर दिया।

Why: Embedded questions. [[English#^en-Q0419|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20don%27t%20know%20how%2C%20but%20she%20did%20it.)
^en-Q0419-answer

**en-Q0420** — I don't know how, but she did it.

पता नहीं कैसे पर उसने कर दिया।

Embedded questions ordinarily have statement order: I wonder where she is. Whether can introduce explicit alternatives. Do not carry direct-question inversion into an ordinary embedded question.

Why: Embedded questions. [[English#^en-Q0420|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20don%27t%20know%20how%2C%20but%20she%20did%20it.)
^en-Q0420-answer

**en-Q0421** — I'm not sure how much we should wait.

मुझे नहीं पता हमे कितनी देर इंतेज़ार करना चाहिए।

Expected form: **how**

Why: Embedded questions. [[English#^en-Q0421|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%27m%20not%20sure%20how%20much%20we%20should%20wait.)
^en-Q0421-answer

**en-Q0422** — I'm not sure how much we should wait.

मुझे नहीं पता हमे कितनी देर इंतेज़ार करना चाहिए।

Expected form: **how**

Why: Embedded questions. [[English#^en-Q0422|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%27m%20not%20sure%20how%20much%20we%20should%20wait.)
^en-Q0422-answer

**en-Q0423** — Do you know how to drive a car?

क्या आपको गाड़ी चलाना आता है?

Expected form: **how**

Why: Embedded questions. [[English#^en-Q0423|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Do%20you%20know%20how%20to%20drive%20a%20car%3F)
^en-Q0423-answer

**en-Q0424** — Do you know how to drive a car?

क्या आपको गाड़ी चलाना आता है?

Why: Embedded questions. [[English#^en-Q0424|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Do%20you%20know%20how%20to%20drive%20a%20car%3F)
^en-Q0424-answer

**en-Q0425** — I don't know how, but Tom did it.

पता नहीं कैसे पर टॉम ने कर दिया।

Why: Embedded questions. [[English#^en-Q0425|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20don%27t%20know%20how%2C%20but%20Tom%20did%20it.)
^en-Q0425-answer

**en-Q0426** — I don't know how, but Tom did it.

पता नहीं कैसे पर टॉम ने कर दिया।

Embedded questions ordinarily have statement order: I wonder where she is. Whether can introduce explicit alternatives. Do not carry direct-question inversion into an ordinary embedded question.

Why: Embedded questions. [[English#^en-Q0426|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20don%27t%20know%20how%2C%20but%20Tom%20did%20it.)
^en-Q0426-answer

**en-Q0427** — Tell me, why do you want to do something like this?

बोलो तुम ऐसा क्यों करना चाहते हो।

Expected form: **why**

Why: Embedded questions. [[English#^en-Q0427|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Tell%20me%2C%20why%20do%20you%20want%20to%20do%20something%20like%20this%3F)
^en-Q0427-answer

**en-Q0428** — Tell me, why do you want to do something like this?

बोलो तुम ऐसा क्यों करना चाहते हो।

Expected form: **why**

Why: Embedded questions. [[English#^en-Q0428|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Tell%20me%2C%20why%20do%20you%20want%20to%20do%20something%20like%20this%3F)
^en-Q0428-answer

**en-Q0429** — I don't know when Bob came to Japan.

बॉब जापान कब आया मुझे पता नही।

Expected form: **when**

Why: Embedded questions. [[English#^en-Q0429|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20don%27t%20know%20when%20Bob%20came%20to%20Japan.)
^en-Q0429-answer

**en-Q0430** — I don't know when Bob came to Japan.

बॉब जापान कब आया मुझे पता नही।

Why: Embedded questions. [[English#^en-Q0430|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20don%27t%20know%20when%20Bob%20came%20to%20Japan.)
^en-Q0430-answer

**en-Q0431** — John asked Mary whether she would like to go shopping in the afternoon.

जॉन ने मेरी से पूछा कि वह दोपहर में उसके साथ बाज़ार जाना चाह्ती है क्या।

Why: Embedded questions. [[English#^en-Q0431|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=John%20asked%20Mary%20whether%20she%20would%20like%20to%20go%20shopping%20in%20the%20afternoon.)
^en-Q0431-answer

**en-Q0432** — John asked Mary whether she would like to go shopping in the afternoon.

जॉन ने मेरी से पूछा कि वह दोपहर में उसके साथ बाज़ार जाना चाह्ती है क्या।

Embedded questions ordinarily have statement order: I wonder where she is. Whether can introduce explicit alternatives. Do not carry direct-question inversion into an ordinary embedded question.

Why: Embedded questions. [[English#^en-Q0432|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=John%20asked%20Mary%20whether%20she%20would%20like%20to%20go%20shopping%20in%20the%20afternoon.)
^en-Q0432-answer

**en-Q0433** — Tom didn't know whether to laugh or cry.

टॉम को सूझ नहीं रहा था के वह हँसे या रोये.

Expected form: **whether**

Why: Embedded questions. [[English#^en-Q0433|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Tom%20didn%27t%20know%20whether%20to%20laugh%20or%20cry.)
^en-Q0433-answer

**en-Q0434** — Tom didn't know whether to laugh or cry.

टॉम को सूझ नहीं रहा था के वह हँसे या रोये.

Expected form: **whether**

Why: Embedded questions. [[English#^en-Q0434|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Tom%20didn%27t%20know%20whether%20to%20laugh%20or%20cry.)
^en-Q0434-answer

**en-Q0435** — I don't know when she will leave for London.

मुझे नहीं पता वह लंदन के लिए रवाना कब होएगी।

Expected form: **when**

Why: Embedded questions. [[English#^en-Q0435|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20don%27t%20know%20when%20she%20will%20leave%20for%20London.)
^en-Q0435-answer

**en-Q0436** — I don't know when she will leave for London.

मुझे नहीं पता वह लंदन के लिए रवाना कब होएगी।

Why: Embedded questions. [[English#^en-Q0436|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20don%27t%20know%20when%20she%20will%20leave%20for%20London.)
^en-Q0436-answer

**en-Q0437** — I wonder where to hang the picture he gave me.

सोच रही हूँ उसकी दी हुई तस्वीर को कहाँ टाँगा जाए।

Why: Embedded questions. [[English#^en-Q0437|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20wonder%20where%20to%20hang%20the%20picture%20he%20gave%20me.)
^en-Q0437-answer

**en-Q0438** — I wonder where to hang the picture he gave me.

सोच रही हूँ उसकी दी हुई तस्वीर को कहाँ टाँगा जाए।

Embedded questions ordinarily have statement order: I wonder where she is. Whether can introduce explicit alternatives. Do not carry direct-question inversion into an ordinary embedded question.

Why: Embedded questions. [[English#^en-Q0438|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20wonder%20where%20to%20hang%20the%20picture%20he%20gave%20me.)
^en-Q0438-answer

**en-Q0439** — I'll let you know when it has been decided.

वो तए किये जाने पर मैं तुम्हे बता दूंगा।

Expected form: **when**

Why: Embedded questions. [[English#^en-Q0439|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%27ll%20let%20you%20know%20when%20it%20has%20been%20decided.)
^en-Q0439-answer

**en-Q0440** — I'll let you know when it has been decided.

वो तए किये जाने पर मैं तुम्हे बता दूंगा।

Expected form: **when**

Why: Embedded questions. [[English#^en-Q0440|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%27ll%20let%20you%20know%20when%20it%20has%20been%20decided.)
^en-Q0440-answer

**en-Q0441** — Friends are those rare people who ask how we are and then wait to hear the answer.

मित्र वे दुर्लभ लोग होते हैं जो हमारा हालचाल पूछते हैं और उत्तर सुनने को रुकते भी हैं।

Expected form: **how**

Why: Embedded questions. [[English#^en-Q0441|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Friends%20are%20those%20rare%20people%20who%20ask%20how%20we%20are%20and%20then%20wait%20to%20hear%20the%20answer.)
^en-Q0441-answer

**en-Q0442** — Friends are those rare people who ask how we are and then wait to hear the answer.

मित्र वे दुर्लभ लोग होते हैं जो हमारा हालचाल पूछते हैं और उत्तर सुनने को रुकते भी हैं।

Why: Embedded questions. [[English#^en-Q0442|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Friends%20are%20those%20rare%20people%20who%20ask%20how%20we%20are%20and%20then%20wait%20to%20hear%20the%20answer.)
^en-Q0442-answer

**en-Q0443** — After you're done cutting up the vegetables, put them there. Don't know when I'll be back to cook them.

सब्ज़ियाँ काटने के बाद वहाँ रख दो। पता नहीं इन्हें कब आ कर पकाऊँगी।

Why: Embedded questions. [[English#^en-Q0443|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=After%20you%27re%20done%20cutting%20up%20the%20vegetables%2C%20put%20them%20there.%20Don%27t%20know%20when%20I%27ll%20be%20back%20to%20cook%20them.)
^en-Q0443-answer

**en-Q0444** — After you're done cutting up the vegetables, put them there. Don't know when I'll be back to cook them.

सब्ज़ियाँ काटने के बाद वहाँ रख दो। पता नहीं इन्हें कब आ कर पकाऊँगी।

Embedded questions ordinarily have statement order: I wonder where she is. Whether can introduce explicit alternatives. Do not carry direct-question inversion into an ordinary embedded question.

Why: Embedded questions. [[English#^en-Q0444|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=After%20you%27re%20done%20cutting%20up%20the%20vegetables%2C%20put%20them%20there.%20Don%27t%20know%20when%20I%27ll%20be%20back%20to%20cook%20them.)
^en-Q0444-answer

**en-Q0445** — I don't know how, but you did it.

पता नहीं कैसे पर तुमने कर दिया।

Expected form: **how**

Why: Embedded questions. [[English#^en-Q0445|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20don%27t%20know%20how%2C%20but%20you%20did%20it.)
^en-Q0445-answer

**en-Q0446** — I don't know how, but you did it.

पता नहीं कैसे पर तुमने कर दिया।

Expected form: **how**

Why: Embedded questions. [[English#^en-Q0446|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20don%27t%20know%20how%2C%20but%20you%20did%20it.)
^en-Q0446-answer

**en-Q0447** — Although fatalities tend to be rare, many people died as a result of volcanic eruptions during the last quarter century.

घायलो की संख्या कम है पर पिछले सवा सौ वर्षों में ज्वालामुखी विस्फोटो के कारण बहुत लोग मरे है ।

Expected form: **Although**

Why: Concession and limits on claims. [[English#^en-Q0447|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Although%20fatalities%20tend%20to%20be%20rare%2C%20many%20people%20died%20as%20a%20result%20of%20volcanic%20eruptions%20during%20the%20last%20quarter%20century.)
^en-Q0447-answer

**en-Q0448** — Although fatalities tend to be rare, many people died as a result of volcanic eruptions during the last quarter century.

घायलो की संख्या कम है पर पिछले सवा सौ वर्षों में ज्वालामुखी विस्फोटो के कारण बहुत लोग मरे है ।

Why: Concession and limits on claims. [[English#^en-Q0448|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Although%20fatalities%20tend%20to%20be%20rare%2C%20many%20people%20died%20as%20a%20result%20of%20volcanic%20eruptions%20during%20the%20last%20quarter%20century.)
^en-Q0448-answer

**en-Q0449** — Though he is rich, he is not happy.

वह अमीर हो कर भी ख़ुश नहीं है।

Why: Concession and limits on claims. [[English#^en-Q0449|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Though%20he%20is%20rich%2C%20he%20is%20not%20happy.)
^en-Q0449-answer

**en-Q0450** — Though he is rich, he is not happy.

वह अमीर हो कर भी ख़ुश नहीं है।

Although introduces a finite concessive clause; despite usually takes a noun phrase or -ing construction. However/nevertheless link discourse differently. A concessive sentence can accept evidence while limiting the conclusion.

Why: Concession and limits on claims. [[English#^en-Q0450|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Though%20he%20is%20rich%2C%20he%20is%20not%20happy.)
^en-Q0450-answer


### Answers 451–500

**en-Q0451** — It is, however, apposite to note that this process will continue in the year ahead.

तथापि, यह नोट करना उपयुक्त है कि यह प्रक्रिया अगले वर्ष जारी रहेगी।

Expected form: **however**

Why: Concession and limits on claims. [[English#^en-Q0451|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=It%20is%2C%20however%2C%20apposite%20to%20note%20that%20this%20process%20will%20continue%20in%20the%20year%20ahead.)
^en-Q0451-answer

**en-Q0452** — It is, however, apposite to note that this process will continue in the year ahead.

तथापि, यह नोट करना उपयुक्त है कि यह प्रक्रिया अगले वर्ष जारी रहेगी।

Expected form: **however**

Why: Concession and limits on claims. [[English#^en-Q0452|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=It%20is%2C%20however%2C%20apposite%20to%20note%20that%20this%20process%20will%20continue%20in%20the%20year%20ahead.)
^en-Q0452-answer

**en-Q0453** — Although they are twins, they have few interests in common.

वे हालांकि जुड़वा हैं, उनके शोक एक-दूसरे से बहुत अलग हैं।

Expected form: **Although**

Why: Concession and limits on claims. [[English#^en-Q0453|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Although%20they%20are%20twins%2C%20they%20have%20few%20interests%20in%20common.)
^en-Q0453-answer

**en-Q0454** — Although they are twins, they have few interests in common.

वे हालांकि जुड़वा हैं, उनके शोक एक-दूसरे से बहुत अलग हैं।

Why: Concession and limits on claims. [[English#^en-Q0454|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Although%20they%20are%20twins%2C%20they%20have%20few%20interests%20in%20common.)
^en-Q0454-answer

**en-Q0455** — I love life because what more is there.

मैं जीवन से प्यार करता हूँ क्योंकि और है ही क्या।

Why: Cause, purpose and consequence. [[English#^en-Q0455|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20love%20life%20because%20what%20more%20is%20there.)
^en-Q0455-answer

**en-Q0456** — I love life because what more is there.

मैं जीवन से प्यार करता हूँ क्योंकि और है ही क्या।

Distinguish a reason, a purpose and an outcome. Since can be temporal or causal. Therefore signals a supported consequence; it does not itself prove a causal mechanism.

Why: Cause, purpose and consequence. [[English#^en-Q0456|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20love%20life%20because%20what%20more%20is%20there.)
^en-Q0456-answer

**en-Q0457** — Because of his advice, I was able to succeed.

मैं उसकी सलाह की वजह से कामयाब हो गया।

Expected form: **Because**

Why: Cause, purpose and consequence. [[English#^en-Q0457|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Because%20of%20his%20advice%2C%20I%20was%20able%20to%20succeed.)
^en-Q0457-answer

**en-Q0458** — Because of his advice, I was able to succeed.

मैं उसकी सलाह की वजह से कामयाब हो गया।

Expected form: **Because**

Why: Cause, purpose and consequence. [[English#^en-Q0458|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Because%20of%20his%20advice%2C%20I%20was%20able%20to%20succeed.)
^en-Q0458-answer

**en-Q0459** — Because of the rain they had to cancel the game.

बारिश की वजह से उन्हें खेल रद्द करना पड़ा।

Expected form: **Because**

Why: Cause, purpose and consequence. [[English#^en-Q0459|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Because%20of%20the%20rain%20they%20had%20to%20cancel%20the%20game.)
^en-Q0459-answer

**en-Q0460** — Because of the rain they had to cancel the game.

बारिश की वजह से उन्हें खेल रद्द करना पड़ा।

Why: Cause, purpose and consequence. [[English#^en-Q0460|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Because%20of%20the%20rain%20they%20had%20to%20cancel%20the%20game.)
^en-Q0460-answer

**en-Q0461** — He couldn't sleep because of the noise outside his window.

उसकी खिड़की के बाहर इतना शोर हो रहा था कि वह सो नहीं पा रहा था।

Why: Cause, purpose and consequence. [[English#^en-Q0461|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%20couldn%27t%20sleep%20because%20of%20the%20noise%20outside%20his%20window.)
^en-Q0461-answer

**en-Q0462** — He couldn't sleep because of the noise outside his window.

उसकी खिड़की के बाहर इतना शोर हो रहा था कि वह सो नहीं पा रहा था।

Distinguish a reason, a purpose and an outcome. Since can be temporal or causal. Therefore signals a supported consequence; it does not itself prove a causal mechanism.

Why: Cause, purpose and consequence. [[English#^en-Q0462|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%20couldn%27t%20sleep%20because%20of%20the%20noise%20outside%20his%20window.)
^en-Q0462-answer

**en-Q0463** — We need to look for a gas station because this car will soon run out of gas.

हमे पेट्रोल पम्प ढूँढना चाहिए क्योंकि गाड़ी में पेट्रोल खतम होने वाला है।

Expected form: **because**

Why: Cause, purpose and consequence. [[English#^en-Q0463|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=We%20need%20to%20look%20for%20a%20gas%20station%20because%20this%20car%20will%20soon%20run%20out%20of%20gas.)
^en-Q0463-answer

**en-Q0464** — We need to look for a gas station because this car will soon run out of gas.

हमे पेट्रोल पम्प ढूँढना चाहिए क्योंकि गाड़ी में पेट्रोल खतम होने वाला है।

Expected form: **because**

Why: Cause, purpose and consequence. [[English#^en-Q0464|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=We%20need%20to%20look%20for%20a%20gas%20station%20because%20this%20car%20will%20soon%20run%20out%20of%20gas.)
^en-Q0464-answer

**en-Q0465** — The Indian flag is called the tricolour because it has stripes of three colours – saffron, white and green.

भारत का झंडा तिरंगा कहलाया जाता है क्योंकि उसमें तीन रंगों की पट्टियाँ हैं - केसरी, सफ़ेद और हरा।

Expected form: **because**

Why: Cause, purpose and consequence. [[English#^en-Q0465|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20Indian%20flag%20is%20called%20the%20tricolour%20because%20it%20has%20stripes%20of%20three%20colours%20%E2%80%93%20saffron%2C%20white%20and%20green.)
^en-Q0465-answer

**en-Q0466** — The Indian flag is called the tricolour because it has stripes of three colours – saffron, white and green.

भारत का झंडा तिरंगा कहलाया जाता है क्योंकि उसमें तीन रंगों की पट्टियाँ हैं - केसरी, सफ़ेद और हरा।

Why: Cause, purpose and consequence. [[English#^en-Q0466|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20Indian%20flag%20is%20called%20the%20tricolour%20because%20it%20has%20stripes%20of%20three%20colours%20%E2%80%93%20saffron%2C%20white%20and%20green.)
^en-Q0466-answer

**en-Q0467** — I slept all day yesterday, because it was Sunday.

कल रविवार था, तो मैं पूरे दिन सोते रहा।

Why: Cause, purpose and consequence. [[English#^en-Q0467|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20slept%20all%20day%20yesterday%2C%20because%20it%20was%20Sunday.)
^en-Q0467-answer

**en-Q0468** — I slept all day yesterday, because it was Sunday.

कल रविवार था, तो मैं पूरे दिन सोते रहा।

Distinguish a reason, a purpose and an outcome. Since can be temporal or causal. Therefore signals a supported consequence; it does not itself prove a causal mechanism.

Why: Cause, purpose and consequence. [[English#^en-Q0468|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20slept%20all%20day%20yesterday%2C%20because%20it%20was%20Sunday.)
^en-Q0468-answer

**en-Q0469** — He finished his dinner because he didn't like to waste food.

उसे खाने की बर्बादी करना पसंद नहीं था, तो उसने अपना खाना खाकर खतम किया।

Expected form: **because**

Why: Cause, purpose and consequence. [[English#^en-Q0469|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%20finished%20his%20dinner%20because%20he%20didn%27t%20like%20to%20waste%20food.)
^en-Q0469-answer

**en-Q0470** — He finished his dinner because he didn't like to waste food.

उसे खाने की बर्बादी करना पसंद नहीं था, तो उसने अपना खाना खाकर खतम किया।

Expected form: **because**

Why: Cause, purpose and consequence. [[English#^en-Q0470|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%20finished%20his%20dinner%20because%20he%20didn%27t%20like%20to%20waste%20food.)
^en-Q0470-answer

**en-Q0471** — Since happiness doesn't exist, we have to strive to be happy without it.

क्योंकि ख़ुशी का कोई अस्तित्व नहीं है, हमें उसके बिना खुश रहने का प्रयत्न करना चाहिए |

Expected form: **Since**

Why: Cause, purpose and consequence. [[English#^en-Q0471|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Since%20happiness%20doesn%27t%20exist%2C%20we%20have%20to%20strive%20to%20be%20happy%20without%20it.)
^en-Q0471-answer

**en-Q0472** — Since happiness doesn't exist, we have to strive to be happy without it.

क्योंकि ख़ुशी का कोई अस्तित्व नहीं है, हमें उसके बिना खुश रहने का प्रयत्न करना चाहिए |

Why: Cause, purpose and consequence. [[English#^en-Q0472|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Since%20happiness%20doesn%27t%20exist%2C%20we%20have%20to%20strive%20to%20be%20happy%20without%20it.)
^en-Q0472-answer

**en-Q0473** — He is very strong--so much so that no one can defeat him.

वह अत्यंत बलवान है, इतना अधिक बलवान के उसे कोई पछाड़ नहीं सकता.

Why: Cause, purpose and consequence. [[English#^en-Q0473|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%20is%20very%20strong--so%20much%20so%20that%20no%20one%20can%20defeat%20him.)
^en-Q0473-answer

**en-Q0474** — He is very strong--so much so that no one can defeat him.

वह अत्यंत बलवान है, इतना अधिक बलवान के उसे कोई पछाड़ नहीं सकता.

Distinguish a reason, a purpose and an outcome. Since can be temporal or causal. Therefore signals a supported consequence; it does not itself prove a causal mechanism.

Why: Cause, purpose and consequence. [[English#^en-Q0474|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%20is%20very%20strong--so%20much%20so%20that%20no%20one%20can%20defeat%20him.)
^en-Q0474-answer

**en-Q0475** — How long has it been since you gave up teaching at that school?

तुम्हे स्कूल में पढ़ाना छोड़े हुए कितना समय हो गया है?

Expected form: **since**

Why: Cause, purpose and consequence. [[English#^en-Q0475|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=How%20long%20has%20it%20been%20since%20you%20gave%20up%20teaching%20at%20that%20school%3F)
^en-Q0475-answer

**en-Q0476** — How long has it been since you gave up teaching at that school?

तुम्हे स्कूल में पढ़ाना छोड़े हुए कितना समय हो गया है?

Expected form: **since**

Why: Cause, purpose and consequence. [[English#^en-Q0476|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=How%20long%20has%20it%20been%20since%20you%20gave%20up%20teaching%20at%20that%20school%3F)
^en-Q0476-answer

**en-Q0477** — I got up early, so that I could catch the first train.

मैं जल्दी उठा था, क्योंकि मुझे पहली ट्रेन पकड़नी थी।

Expected form: **so that**

Why: Cause, purpose and consequence. [[English#^en-Q0477|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20got%20up%20early%2C%20so%20that%20I%20could%20catch%20the%20first%20train.)
^en-Q0477-answer

**en-Q0478** — I got up early, so that I could catch the first train.

मैं जल्दी उठा था, क्योंकि मुझे पहली ट्रेन पकड़नी थी।

Why: Cause, purpose and consequence. [[English#^en-Q0478|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20got%20up%20early%2C%20so%20that%20I%20could%20catch%20the%20first%20train.)
^en-Q0478-answer

**en-Q0479** — I can't turn my neck, because it hurts a lot.

मैं अपनी गर्दन नहीं घुमा सकता क्योंकि बहुत दर्द होता है।

Why: Cause, purpose and consequence. [[English#^en-Q0479|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20can%27t%20turn%20my%20neck%2C%20because%20it%20hurts%20a%20lot.)
^en-Q0479-answer

**en-Q0480** — I can't turn my neck, because it hurts a lot.

मैं अपनी गर्दन नहीं घुमा सकता क्योंकि बहुत दर्द होता है।

Distinguish a reason, a purpose and an outcome. Since can be temporal or causal. Therefore signals a supported consequence; it does not itself prove a causal mechanism.

Why: Cause, purpose and consequence. [[English#^en-Q0480|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20can%27t%20turn%20my%20neck%2C%20because%20it%20hurts%20a%20lot.)
^en-Q0480-answer

**en-Q0481** — Since he was tired, he went to bed.

वह थक गया था, तो सोने चला गया।

Expected form: **Since**

Why: Cause, purpose and consequence. [[English#^en-Q0481|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Since%20he%20was%20tired%2C%20he%20went%20to%20bed.)
^en-Q0481-answer

**en-Q0482** — Since he was tired, he went to bed.

वह थक गया था, तो सोने चला गया।

Expected form: **Since**

Why: Cause, purpose and consequence. [[English#^en-Q0482|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Since%20he%20was%20tired%2C%20he%20went%20to%20bed.)
^en-Q0482-answer

**en-Q0483** — As a result of the war, many people died.

जंग की वजह से बहुत सारे लोग मर गए।

Expected form: **As a result**

Why: Cause, purpose and consequence. [[English#^en-Q0483|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=As%20a%20result%20of%20the%20war%2C%20many%20people%20died.)
^en-Q0483-answer

**en-Q0484** — As a result of the war, many people died.

जंग की वजह से बहुत सारे लोग मर गए।

Why: Cause, purpose and consequence. [[English#^en-Q0484|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=As%20a%20result%20of%20the%20war%2C%20many%20people%20died.)
^en-Q0484-answer

**en-Q0485** — I've known Jim since I was a child.

मैं जिम को बचपन से जानता हूँ।

Why: Cause, purpose and consequence. [[English#^en-Q0485|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%27ve%20known%20Jim%20since%20I%20was%20a%20child.)
^en-Q0485-answer

**en-Q0486** — I've known Jim since I was a child.

मैं जिम को बचपन से जानता हूँ।

Distinguish a reason, a purpose and an outcome. Since can be temporal or causal. Therefore signals a supported consequence; it does not itself prove a causal mechanism.

Why: Cause, purpose and consequence. [[English#^en-Q0486|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%27ve%20known%20Jim%20since%20I%20was%20a%20child.)
^en-Q0486-answer

**en-Q0487** — He could not join us because he was ill.

वह बीमारी की वजह से हमारे साथ नहीं आ सका।

Expected form: **because**

Why: Cause, purpose and consequence. [[English#^en-Q0487|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%20could%20not%20join%20us%20because%20he%20was%20ill.)
^en-Q0487-answer

**en-Q0488** — He could not join us because he was ill.

वह बीमारी की वजह से हमारे साथ नहीं आ सका।

Expected form: **because**

Why: Cause, purpose and consequence. [[English#^en-Q0488|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%20could%20not%20join%20us%20because%20he%20was%20ill.)
^en-Q0488-answer

**en-Q0489** — Nobody likes him, because he is always blowing his own horn.

उसे कोई भी पसंद नहीं करता क्योंकि वह सारे टाईम अपनी बड़ाई करता रहता है।

Expected form: **because**

Why: Cause, purpose and consequence. [[English#^en-Q0489|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Nobody%20likes%20him%2C%20because%20he%20is%20always%20blowing%20his%20own%20horn.)
^en-Q0489-answer

**en-Q0490** — Nobody likes him, because he is always blowing his own horn.

उसे कोई भी पसंद नहीं करता क्योंकि वह सारे टाईम अपनी बड़ाई करता रहता है।

Why: Cause, purpose and consequence. [[English#^en-Q0490|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Nobody%20likes%20him%2C%20because%20he%20is%20always%20blowing%20his%20own%20horn.)
^en-Q0490-answer

**en-Q0491** — Since the Industrial Revolution, the world population has more than tripled.

औद्योगिक क्रांति के बाद से दुनिया की आबादी तीन गुना से भी ज़्यादा बढ़ गयी है।

Why: Cause, purpose and consequence. [[English#^en-Q0491|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Since%20the%20Industrial%20Revolution%2C%20the%20world%20population%20has%20more%20than%20tripled.)
^en-Q0491-answer

**en-Q0492** — Since the Industrial Revolution, the world population has more than tripled.

औद्योगिक क्रांति के बाद से दुनिया की आबादी तीन गुना से भी ज़्यादा बढ़ गयी है।

Distinguish a reason, a purpose and an outcome. Since can be temporal or causal. Therefore signals a supported consequence; it does not itself prove a causal mechanism.

Why: Cause, purpose and consequence. [[English#^en-Q0492|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Since%20the%20Industrial%20Revolution%2C%20the%20world%20population%20has%20more%20than%20tripled.)
^en-Q0492-answer

**en-Q0493** — It is forty years since I began the study of Japanese.

अब चालीस साल हो गए हैं मेरी जापानी की पढ़ाई को शुरू किए हुए।

Expected form: **since**

Why: Cause, purpose and consequence. [[English#^en-Q0493|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=It%20is%20forty%20years%20since%20I%20began%20the%20study%20of%20Japanese.)
^en-Q0493-answer

**en-Q0494** — It is forty years since I began the study of Japanese.

अब चालीस साल हो गए हैं मेरी जापानी की पढ़ाई को शुरू किए हुए।

Expected form: **since**

Why: Cause, purpose and consequence. [[English#^en-Q0494|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=It%20is%20forty%20years%20since%20I%20began%20the%20study%20of%20Japanese.)
^en-Q0494-answer

**en-Q0495** — He was arrested because he stole the money.

उसे पैसे चुराने के लिए गिरफ़्तार कर लिया गया।

Expected form: **because**

Why: Cause, purpose and consequence. [[English#^en-Q0495|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%20was%20arrested%20because%20he%20stole%20the%20money.)
^en-Q0495-answer

**en-Q0496** — He was arrested because he stole the money.

उसे पैसे चुराने के लिए गिरफ़्तार कर लिया गया।

Why: Cause, purpose and consequence. [[English#^en-Q0496|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%20was%20arrested%20because%20he%20stole%20the%20money.)
^en-Q0496-answer

**en-Q0497** — It has been six years since I started to study English.

मुझे अंग्रेजी की पढाई शुरू किये हुए छह महिने हुए हैं।

Why: Cause, purpose and consequence. [[English#^en-Q0497|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=It%20has%20been%20six%20years%20since%20I%20started%20to%20study%20English.)
^en-Q0497-answer

**en-Q0498** — It has been six years since I started to study English.

मुझे अंग्रेजी की पढाई शुरू किये हुए छह महिने हुए हैं।

Distinguish a reason, a purpose and an outcome. Since can be temporal or causal. Therefore signals a supported consequence; it does not itself prove a causal mechanism.

Why: Cause, purpose and consequence. [[English#^en-Q0498|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=It%20has%20been%20six%20years%20since%20I%20started%20to%20study%20English.)
^en-Q0498-answer

**en-Q0499** — Your feet are swollen because your shoes are too small.

तुम्हारे पैर सूज गए हैं क्योंकि तुम्हारे जूते बहुत छोटे हैं।

Expected form: **because**

Why: Cause, purpose and consequence. [[English#^en-Q0499|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Your%20feet%20are%20swollen%20because%20your%20shoes%20are%20too%20small.)
^en-Q0499-answer

**en-Q0500** — Your feet are swollen because your shoes are too small.

तुम्हारे पैर सूज गए हैं क्योंकि तुम्हारे जूते बहुत छोटे हैं।

Expected form: **because**

Why: Cause, purpose and consequence. [[English#^en-Q0500|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Your%20feet%20are%20swollen%20because%20your%20shoes%20are%20too%20small.)
^en-Q0500-answer


### Answers 501–550

**en-Q0501** — My daughter is in hospital because she was injured in a traffic accident.

मेरी बेटी हस्पताल में है क्योंकि उसे यातायात दुर्घटना में चोट पहुँची है।

Expected form: **because**

Why: Cause, purpose and consequence. [[English#^en-Q0501|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=My%20daughter%20is%20in%20hospital%20because%20she%20was%20injured%20in%20a%20traffic%20accident.)
^en-Q0501-answer

**en-Q0502** — My daughter is in hospital because she was injured in a traffic accident.

मेरी बेटी हस्पताल में है क्योंकि उसे यातायात दुर्घटना में चोट पहुँची है।

Why: Cause, purpose and consequence. [[English#^en-Q0502|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=My%20daughter%20is%20in%20hospital%20because%20she%20was%20injured%20in%20a%20traffic%20accident.)
^en-Q0502-answer

**en-Q0503** — He worked hard in order to get the prize.

उसने इनाम पाने के लिए कड़ी मेहनत की।

Why: Cause, purpose and consequence. [[English#^en-Q0503|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%20worked%20hard%20in%20order%20to%20get%20the%20prize.)
^en-Q0503-answer

**en-Q0504** — He worked hard in order to get the prize.

उसने इनाम पाने के लिए कड़ी मेहनत की।

Distinguish a reason, a purpose and an outcome. Since can be temporal or causal. Therefore signals a supported consequence; it does not itself prove a causal mechanism.

Why: Cause, purpose and consequence. [[English#^en-Q0504|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%20worked%20hard%20in%20order%20to%20get%20the%20prize.)
^en-Q0504-answer

**en-Q0505** — These texts were written in Hebrew, not in Aramaic.

यह पाठ्य इब्रानी में लिखे थे, आरामाईक में नहीं।

Expected form: **were**

Why: Passive and agency. [[English#^en-Q0505|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=These%20texts%20were%20written%20in%20Hebrew%2C%20not%20in%20Aramaic.)
^en-Q0505-answer

**en-Q0506** — These texts were written in Hebrew, not in Aramaic.

यह पाठ्य इब्रानी में लिखे थे, आरामाईक में नहीं।

Expected form: **were**

Why: Passive and agency. [[English#^en-Q0506|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=These%20texts%20were%20written%20in%20Hebrew%2C%20not%20in%20Aramaic.)
^en-Q0506-answer

**en-Q0507** — Their conversation was carried on for about an hour.

उनकी बातचीत लगभग एक घंटे तक चलती रही।

Expected form: **was**

Why: Passive and agency. [[English#^en-Q0507|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Their%20conversation%20was%20carried%20on%20for%20about%20an%20hour.)
^en-Q0507-answer

**en-Q0508** — Their conversation was carried on for about an hour.

उनकी बातचीत लगभग एक घंटे तक चलती रही।

Why: Passive and agency. [[English#^en-Q0508|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Their%20conversation%20was%20carried%20on%20for%20about%20an%20hour.)
^en-Q0508-answer

**en-Q0509** — Sam joined the army when he was eighteen.

सैम अठारह साल की उम्र में आर्मी में भर्ती हुआ था।

Why: Passive and agency. [[English#^en-Q0509|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Sam%20joined%20the%20army%20when%20he%20was%20eighteen.)
^en-Q0509-answer

**en-Q0510** — Sam joined the army when he was eighteen.

सैम अठारह साल की उम्र में आर्मी में भर्ती हुआ था।

A be form plus a past participle can build a passive; a be form alone can be a copula/progressive auxiliary. Passive voice helps manage focus but can also hide an agent. Restore the agent when responsibility matters.

Why: Passive and agency. [[English#^en-Q0510|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Sam%20joined%20the%20army%20when%20he%20was%20eighteen.)
^en-Q0510-answer

**en-Q0511** — A strange car was parked in front of my house.

मेरे घर के सामने एक अजीब सी गाड़ी पार्क की गयी थी।

Expected form: **was**

Why: Passive and agency. [[English#^en-Q0511|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=A%20strange%20car%20was%20parked%20in%20front%20of%20my%20house.)
^en-Q0511-answer

**en-Q0512** — A strange car was parked in front of my house.

मेरे घर के सामने एक अजीब सी गाड़ी पार्क की गयी थी।

Expected form: **was**

Why: Passive and agency. [[English#^en-Q0512|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=A%20strange%20car%20was%20parked%20in%20front%20of%20my%20house.)
^en-Q0512-answer

**en-Q0513** — He was respected both as a teacher and as a man.

उसको दोनो एक अध्यापक और एक इनसान के रूप में सम्मान मिला।

Expected form: **was**

Why: Passive and agency. [[English#^en-Q0513|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%20was%20respected%20both%20as%20a%20teacher%20and%20as%20a%20man.)
^en-Q0513-answer

**en-Q0514** — He was respected both as a teacher and as a man.

उसको दोनो एक अध्यापक और एक इनसान के रूप में सम्मान मिला।

Why: Passive and agency. [[English#^en-Q0514|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%20was%20respected%20both%20as%20a%20teacher%20and%20as%20a%20man.)
^en-Q0514-answer

**en-Q0515** — The Durrani Empire was established in Afghanistan by Ahmad Shah Durrani in 1747.

दुर्रानी साम्राज्य १७४७ में अफगानिस्तान में अहमद शाह दुर्रानी ने स्थापित किया था।

Why: Passive and agency. [[English#^en-Q0515|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20Durrani%20Empire%20was%20established%20in%20Afghanistan%20by%20Ahmad%20Shah%20Durrani%20in%201747.)
^en-Q0515-answer

**en-Q0516** — The Durrani Empire was established in Afghanistan by Ahmad Shah Durrani in 1747.

दुर्रानी साम्राज्य १७४७ में अफगानिस्तान में अहमद शाह दुर्रानी ने स्थापित किया था।

A be form plus a past participle can build a passive; a be form alone can be a copula/progressive auxiliary. Passive voice helps manage focus but can also hide an agent. Restore the agent when responsibility matters.

Why: Passive and agency. [[English#^en-Q0516|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20Durrani%20Empire%20was%20established%20in%20Afghanistan%20by%20Ahmad%20Shah%20Durrani%20in%201747.)
^en-Q0516-answer

**en-Q0517** — This poem was written by a nameless poet.

यह कविता किसी बेनाम कवी ने लिखी थी।

Expected form: **was**

Why: Passive and agency. [[English#^en-Q0517|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=This%20poem%20was%20written%20by%20a%20nameless%20poet.)
^en-Q0517-answer

**en-Q0518** — This poem was written by a nameless poet.

यह कविता किसी बेनाम कवी ने लिखी थी।

Expected form: **was**

Why: Passive and agency. [[English#^en-Q0518|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=This%20poem%20was%20written%20by%20a%20nameless%20poet.)
^en-Q0518-answer

**en-Q0519** — The jeans looked none the cleaner for having been washed.

जीन्ज़ धुलकर भी साफ़ नहीं लग रहीं थीं।

Expected form: **been**

Why: Passive and agency. [[English#^en-Q0519|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20jeans%20looked%20none%20the%20cleaner%20for%20having%20been%20washed.)
^en-Q0519-answer

**en-Q0520** — The jeans looked none the cleaner for having been washed.

जीन्ज़ धुलकर भी साफ़ नहीं लग रहीं थीं।

Why: Passive and agency. [[English#^en-Q0520|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20jeans%20looked%20none%20the%20cleaner%20for%20having%20been%20washed.)
^en-Q0520-answer

**en-Q0521** — Antoine Lavoisier was beheaded during the French revolution.

फ़्रांसीसी क्रांति के दौरान आँत्वाँ लाव्वाज़्ये का सिर काट दिया गया।

Why: Passive and agency. [[English#^en-Q0521|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Antoine%20Lavoisier%20was%20beheaded%20during%20the%20French%20revolution.)
^en-Q0521-answer

**en-Q0522** — Antoine Lavoisier was beheaded during the French revolution.

फ़्रांसीसी क्रांति के दौरान आँत्वाँ लाव्वाज़्ये का सिर काट दिया गया।

A be form plus a past participle can build a passive; a be form alone can be a copula/progressive auxiliary. Passive voice helps manage focus but can also hide an agent. Restore the agent when responsibility matters.

Why: Passive and agency. [[English#^en-Q0522|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Antoine%20Lavoisier%20was%20beheaded%20during%20the%20French%20revolution.)
^en-Q0522-answer

**en-Q0523** — I was amazed at the speed of the car.

मैं उस गाड़ी की रफ़तार देखकर हैरान रह गया।

Expected form: **was**

Why: Passive and agency. [[English#^en-Q0523|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20was%20amazed%20at%20the%20speed%20of%20the%20car.)
^en-Q0523-answer

**en-Q0524** — I was amazed at the speed of the car.

मैं उस गाड़ी की रफ़तार देखकर हैरान रह गया।

Expected form: **was**

Why: Passive and agency. [[English#^en-Q0524|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20was%20amazed%20at%20the%20speed%20of%20the%20car.)
^en-Q0524-answer

**en-Q0525** — India was governed by Great Britain for many years.

भारत पर बहुत सालों तक ग्रेट ब्रिटेन राज करता था।

Expected form: **was**

Why: Passive and agency. [[English#^en-Q0525|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=India%20was%20governed%20by%20Great%20Britain%20for%20many%20years.)
^en-Q0525-answer

**en-Q0526** — India was governed by Great Britain for many years.

भारत पर बहुत सालों तक ग्रेट ब्रिटेन राज करता था।

Why: Passive and agency. [[English#^en-Q0526|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=India%20was%20governed%20by%20Great%20Britain%20for%20many%20years.)
^en-Q0526-answer

**en-Q0527** — Japan is not what it was ten years ago.

जापान दस साल पहले जैसे था वैसा अब नहीं रहा।

Why: Passive and agency. [[English#^en-Q0527|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Japan%20is%20not%20what%20it%20was%20ten%20years%20ago.)
^en-Q0527-answer

**en-Q0528** — Japan is not what it was ten years ago.

जापान दस साल पहले जैसे था वैसा अब नहीं रहा।

A be form plus a past participle can build a passive; a be form alone can be a copula/progressive auxiliary. Passive voice helps manage focus but can also hide an agent. Restore the agent when responsibility matters.

Why: Passive and agency. [[English#^en-Q0528|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Japan%20is%20not%20what%20it%20was%20ten%20years%20ago.)
^en-Q0528-answer

**en-Q0529** — I was asked to give you a message.

मुझसे आपको यह संदेश देने के लिए बताया गया था।

Expected form: **was**

Why: Passive and agency. [[English#^en-Q0529|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20was%20asked%20to%20give%20you%20a%20message.)
^en-Q0529-answer

**en-Q0530** — I was asked to give you a message.

मुझसे आपको यह संदेश देने के लिए बताया गया था।

Expected form: **was**

Why: Passive and agency. [[English#^en-Q0530|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20was%20asked%20to%20give%20you%20a%20message.)
^en-Q0530-answer

**en-Q0531** — I've been given until tomorrow to finish this.

मुझे ये कल तक खतम करना है ।

Expected form: **been**

Why: Passive and agency. [[English#^en-Q0531|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%27ve%20been%20given%20until%20tomorrow%20to%20finish%20this.)
^en-Q0531-answer

**en-Q0532** — I've been given until tomorrow to finish this.

मुझे ये कल तक खतम करना है ।

Why: Passive and agency. [[English#^en-Q0532|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%27ve%20been%20given%20until%20tomorrow%20to%20finish%20this.)
^en-Q0532-answer

**en-Q0533** — They were caught in a shower on the way.

वे रास्ते में बारिश में फँस गए।

Why: Passive and agency. [[English#^en-Q0533|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=They%20were%20caught%20in%20a%20shower%20on%20the%20way.)
^en-Q0533-answer

**en-Q0534** — They were caught in a shower on the way.

वे रास्ते में बारिश में फँस गए।

A be form plus a past participle can build a passive; a be form alone can be a copula/progressive auxiliary. Passive voice helps manage focus but can also hide an agent. Restore the agent when responsibility matters.

Why: Passive and agency. [[English#^en-Q0534|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=They%20were%20caught%20in%20a%20shower%20on%20the%20way.)
^en-Q0534-answer

**en-Q0535** — Last night I was caught in a shower and got wet to the skin.

कल रात मैं बारिश में फंस गया और तर तर भीग गया।

Expected form: **was**

Why: Passive and agency. [[English#^en-Q0535|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Last%20night%20I%20was%20caught%20in%20a%20shower%20and%20got%20wet%20to%20the%20skin.)
^en-Q0535-answer

**en-Q0536** — Last night I was caught in a shower and got wet to the skin.

कल रात मैं बारिश में फंस गया और तर तर भीग गया।

Expected form: **was**

Why: Passive and agency. [[English#^en-Q0536|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Last%20night%20I%20was%20caught%20in%20a%20shower%20and%20got%20wet%20to%20the%20skin.)
^en-Q0536-answer

**en-Q0537** — In the 1600s, tea was introduced into Europe from India.

१६०० की शतक में चाय को भारत से यूरोप में लाया गया था।

Expected form: **was**

Why: Passive and agency. [[English#^en-Q0537|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=In%20the%201600s%2C%20tea%20was%20introduced%20into%20Europe%20from%20India.)
^en-Q0537-answer

**en-Q0538** — In the 1600s, tea was introduced into Europe from India.

१६०० की शतक में चाय को भारत से यूरोप में लाया गया था।

Why: Passive and agency. [[English#^en-Q0538|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=In%20the%201600s%2C%20tea%20was%20introduced%20into%20Europe%20from%20India.)
^en-Q0538-answer

**en-Q0539** — Hyderabad was ruled by a nizam until 1948.

हैदराबाद पर १९४८ तक निज़ाम का राज था।

Why: Passive and agency. [[English#^en-Q0539|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Hyderabad%20was%20ruled%20by%20a%20nizam%20until%201948.)
^en-Q0539-answer

**en-Q0540** — Hyderabad was ruled by a nizam until 1948.

हैदराबाद पर १९४८ तक निज़ाम का राज था।

A be form plus a past participle can build a passive; a be form alone can be a copula/progressive auxiliary. Passive voice helps manage focus but can also hide an agent. Restore the agent when responsibility matters.

Why: Passive and agency. [[English#^en-Q0540|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Hyderabad%20was%20ruled%20by%20a%20nizam%20until%201948.)
^en-Q0540-answer

**en-Q0541** — If my boy had not been killed in the traffic accident, he would be a college student now.

अगर मेरा बेटा ट्रेफ़िक हादसे में नहीं मारा गया होता, तो वह अभी कॉलेज जा रहा होता।

Expected form: **been**

Why: Passive and agency. [[English#^en-Q0541|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=If%20my%20boy%20had%20not%20been%20killed%20in%20the%20traffic%20accident%2C%20he%20would%20be%20a%20college%20student%20now.)
^en-Q0541-answer

**en-Q0542** — If my boy had not been killed in the traffic accident, he would be a college student now.

अगर मेरा बेटा ट्रेफ़िक हादसे में नहीं मारा गया होता, तो वह अभी कॉलेज जा रहा होता।

Expected form: **been**

Why: Passive and agency. [[English#^en-Q0542|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=If%20my%20boy%20had%20not%20been%20killed%20in%20the%20traffic%20accident%2C%20he%20would%20be%20a%20college%20student%20now.)
^en-Q0542-answer

**en-Q0543** — The drug smuggler was arrested at the airport.

दवा तस्कर हवाई अड्डे पर गिरफ्तार किया गया था।

Expected form: **was**

Why: Passive and agency. [[English#^en-Q0543|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20drug%20smuggler%20was%20arrested%20at%20the%20airport.)
^en-Q0543-answer

**en-Q0544** — The drug smuggler was arrested at the airport.

दवा तस्कर हवाई अड्डे पर गिरफ्तार किया गया था।

Why: Passive and agency. [[English#^en-Q0544|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20drug%20smuggler%20was%20arrested%20at%20the%20airport.)
^en-Q0544-answer

**en-Q0545** — Actinium was discovered by André-Louis Debierne in 1899.

ऐक्टिनियम का खोज आंड्रे-लूई डेबिएर्न ने साल १८९९ में किया था।

Why: Passive and agency. [[English#^en-Q0545|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Actinium%20was%20discovered%20by%20Andr%C3%A9-Louis%20Debierne%20in%201899.)
^en-Q0545-answer

**en-Q0546** — Actinium was discovered by André-Louis Debierne in 1899.

ऐक्टिनियम का खोज आंड्रे-लूई डेबिएर्न ने साल १८९९ में किया था।

A be form plus a past participle can build a passive; a be form alone can be a copula/progressive auxiliary. Passive voice helps manage focus but can also hide an agent. Restore the agent when responsibility matters.

Why: Passive and agency. [[English#^en-Q0546|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Actinium%20was%20discovered%20by%20Andr%C3%A9-Louis%20Debierne%20in%201899.)
^en-Q0546-answer

**en-Q0547** — The date has been appointed but the place has not.

तारीख चुन ली गई है पर जगह नहीं।

Expected form: **been**

Why: Passive and agency. [[English#^en-Q0547|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20date%20has%20been%20appointed%20but%20the%20place%20has%20not.)
^en-Q0547-answer

**en-Q0548** — The date has been appointed but the place has not.

तारीख चुन ली गई है पर जगह नहीं।

Expected form: **been**

Why: Passive and agency. [[English#^en-Q0548|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20date%20has%20been%20appointed%20but%20the%20place%20has%20not.)
^en-Q0548-answer

**en-Q0549** — The Sikh Empire was established in 1799 by Ranjit Singh.

सिख साम्राज्य १७९९ में रणजीत सिंह ने स्थापित किया था।

Expected form: **was**

Why: Passive and agency. [[English#^en-Q0549|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20Sikh%20Empire%20was%20established%20in%201799%20by%20Ranjit%20Singh.)
^en-Q0549-answer

**en-Q0550** — The Sikh Empire was established in 1799 by Ranjit Singh.

सिख साम्राज्य १७९९ में रणजीत सिंह ने स्थापित किया था।

Why: Passive and agency. [[English#^en-Q0550|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20Sikh%20Empire%20was%20established%20in%201799%20by%20Ranjit%20Singh.)
^en-Q0550-answer


### Answers 551–600

**en-Q0551** — The conditions that lead to my parents' divorce were engendered by their obsessive attitude toward work.

मेरे माता-पिता के विवाह विच्छेद के हालात उनके काम के प्रति अत्याधिक लगाव से पैदा हुए थे।

Why: Passive and agency. [[English#^en-Q0551|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20conditions%20that%20lead%20to%20my%20parents%27%20divorce%20were%20engendered%20by%20their%20obsessive%20attitude%20toward%20work.)
^en-Q0551-answer

**en-Q0552** — The conditions that lead to my parents' divorce were engendered by their obsessive attitude toward work.

मेरे माता-पिता के विवाह विच्छेद के हालात उनके काम के प्रति अत्याधिक लगाव से पैदा हुए थे।

A be form plus a past participle can build a passive; a be form alone can be a copula/progressive auxiliary. Passive voice helps manage focus but can also hide an agent. Restore the agent when responsibility matters.

Why: Passive and agency. [[English#^en-Q0552|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20conditions%20that%20lead%20to%20my%20parents%27%20divorce%20were%20engendered%20by%20their%20obsessive%20attitude%20toward%20work.)
^en-Q0552-answer

**en-Q0553** — I learned to drive a car and got a driver's license when I was eighteen.

जब मैं अठारह साल का था मैंने गाड़ी चलानी सीखी और लाईसेंस बनवालिया।

Expected form: **was**

Why: Passive and agency. [[English#^en-Q0553|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20learned%20to%20drive%20a%20car%20and%20got%20a%20driver%27s%20license%20when%20I%20was%20eighteen.)
^en-Q0553-answer

**en-Q0554** — I learned to drive a car and got a driver's license when I was eighteen.

जब मैं अठारह साल का था मैंने गाड़ी चलानी सीखी और लाईसेंस बनवालिया।

Expected form: **was**

Why: Passive and agency. [[English#^en-Q0554|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20learned%20to%20drive%20a%20car%20and%20got%20a%20driver%27s%20license%20when%20I%20was%20eighteen.)
^en-Q0554-answer

**en-Q0555** — Traveling by boat takes longer than going by car.

नाव के सफ़र में कार से ज्यादा समय लगता है.

Expected form: **by**

Why: Non-finite complements. [[English#^en-Q0555|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Traveling%20by%20boat%20takes%20longer%20than%20going%20by%20car.)
^en-Q0555-answer

**en-Q0556** — Traveling by boat takes longer than going by car.

नाव के सफ़र में कार से ज्यादा समय लगता है.

Why: Non-finite complements. [[English#^en-Q0556|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Traveling%20by%20boat%20takes%20longer%20than%20going%20by%20car.)
^en-Q0556-answer

**en-Q0557** — Goals determine what you are going to be.

हमारे लक्ष्य निर्धारित करते हैं कि हम क्या बनने जा रहे हैं।

Why: Non-finite complements. [[English#^en-Q0557|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Goals%20determine%20what%20you%20are%20going%20to%20be.)
^en-Q0557-answer

**en-Q0558** — Goals determine what you are going to be.

हमारे लक्ष्य निर्धारित करते हैं कि हम क्या बनने जा रहे हैं।

Complement patterns belong to the governing word: decide to act, avoid acting, insist on acting. To can be infinitive marker or preposition. Do not assume a synonym accepts the same complement pattern.

Why: Non-finite complements. [[English#^en-Q0558|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Goals%20determine%20what%20you%20are%20going%20to%20be.)
^en-Q0558-answer

**en-Q0559** — This is Tom speaking. I'd like to speak to Ann.

मैं टॉम बोल रहा हूँ। मुझे ऐन से बात करनी है।

Expected form: **to**

Why: Non-finite complements. [[English#^en-Q0559|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=This%20is%20Tom%20speaking.%20I%27d%20like%20to%20speak%20to%20Ann.)
^en-Q0559-answer

**en-Q0560** — This is Tom speaking. I'd like to speak to Ann.

मैं टॉम बोल रहा हूँ। मुझे ऐन से बात करनी है।

Expected form: **to**

Why: Non-finite complements. [[English#^en-Q0560|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=This%20is%20Tom%20speaking.%20I%27d%20like%20to%20speak%20to%20Ann.)
^en-Q0560-answer

**en-Q0561** — It's impossible for me to explain it to you.

मुझे तुमको यह बात समझाना नामुमकिन है।

Expected form: **for**

Why: Non-finite complements. [[English#^en-Q0561|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=It%27s%20impossible%20for%20me%20to%20explain%20it%20to%20you.)
^en-Q0561-answer

**en-Q0562** — It's impossible for me to explain it to you.

मुझे तुमको यह बात समझाना नामुमकिन है।

Why: Non-finite complements. [[English#^en-Q0562|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=It%27s%20impossible%20for%20me%20to%20explain%20it%20to%20you.)
^en-Q0562-answer

**en-Q0563** — I wonder what I should get you for your birthday.

मैं सोच रही हूँ तुम्हारे जन्मदिव्स पर तुम्हे क्या उपहार दूँ।

Why: Non-finite complements. [[English#^en-Q0563|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20wonder%20what%20I%20should%20get%20you%20for%20your%20birthday.)
^en-Q0563-answer

**en-Q0564** — I wonder what I should get you for your birthday.

मैं सोच रही हूँ तुम्हारे जन्मदिव्स पर तुम्हे क्या उपहार दूँ।

Complement patterns belong to the governing word: decide to act, avoid acting, insist on acting. To can be infinitive marker or preposition. Do not assume a synonym accepts the same complement pattern.

Why: Non-finite complements. [[English#^en-Q0564|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20wonder%20what%20I%20should%20get%20you%20for%20your%20birthday.)
^en-Q0564-answer

**en-Q0565** — Come on! I will show you the taste of defeat.

आओ! मैं तुम्हें हार का स्वाद चखाऊँगा।

Expected form: **of**

Why: Non-finite complements. [[English#^en-Q0565|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Come%20on%21%20I%20will%20show%20you%20the%20taste%20of%20defeat.)
^en-Q0565-answer

**en-Q0566** — Come on! I will show you the taste of defeat.

आओ! मैं तुम्हें हार का स्वाद चखाऊँगा।

Expected form: **of**

Why: Non-finite complements. [[English#^en-Q0566|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Come%20on%21%20I%20will%20show%20you%20the%20taste%20of%20defeat.)
^en-Q0566-answer

**en-Q0567** — I thought Tom would bring us something to eat.

मैंने सोचा टॉम हमारे खाने के लिए कुछ लाएगा.

Expected form: **to**

Why: Non-finite complements. [[English#^en-Q0567|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20thought%20Tom%20would%20bring%20us%20something%20to%20eat.)
^en-Q0567-answer

**en-Q0568** — I thought Tom would bring us something to eat.

मैंने सोचा टॉम हमारे खाने के लिए कुछ लाएगा.

Why: Non-finite complements. [[English#^en-Q0568|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20thought%20Tom%20would%20bring%20us%20something%20to%20eat.)
^en-Q0568-answer

**en-Q0569** — How many strokes does the kanji for "michi" have?

"मिचि" के कान्जी में किती रेखाएं होती हैं?

Why: Non-finite complements. [[English#^en-Q0569|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=How%20many%20strokes%20does%20the%20kanji%20for%20%22michi%22%20have%3F)
^en-Q0569-answer

**en-Q0570** — How many strokes does the kanji for "michi" have?

"मिचि" के कान्जी में किती रेखाएं होती हैं?

Complement patterns belong to the governing word: decide to act, avoid acting, insist on acting. To can be infinitive marker or preposition. Do not assume a synonym accepts the same complement pattern.

Why: Non-finite complements. [[English#^en-Q0570|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=How%20many%20strokes%20does%20the%20kanji%20for%20%22michi%22%20have%3F)
^en-Q0570-answer

**en-Q0571** — It is better to live rich, than to die rich.

अमीर हो कर मरने से बेहतर है अमीर हो कर जीना।

Expected form: **to**

Why: Non-finite complements. [[English#^en-Q0571|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=It%20is%20better%20to%20live%20rich%2C%20than%20to%20die%20rich.)
^en-Q0571-answer

**en-Q0572** — It is better to live rich, than to die rich.

अमीर हो कर मरने से बेहतर है अमीर हो कर जीना।

Expected form: **to**

Why: Non-finite complements. [[English#^en-Q0572|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=It%20is%20better%20to%20live%20rich%2C%20than%20to%20die%20rich.)
^en-Q0572-answer

**en-Q0573** — It's all the same to me whether you go or stay.

तुम जाओ या रहो, मुझे कोई फ़र्क नहीं पड़ता।

Expected form: **to**

Why: Non-finite complements. [[English#^en-Q0573|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=It%27s%20all%20the%20same%20to%20me%20whether%20you%20go%20or%20stay.)
^en-Q0573-answer

**en-Q0574** — It's all the same to me whether you go or stay.

तुम जाओ या रहो, मुझे कोई फ़र्क नहीं पड़ता।

Why: Non-finite complements. [[English#^en-Q0574|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=It%27s%20all%20the%20same%20to%20me%20whether%20you%20go%20or%20stay.)
^en-Q0574-answer

**en-Q0575** — Thank you for your interest in our language.

हमारी भाषा में रूचि रखने के लिए धन्यवाद्।

Why: Non-finite complements. [[English#^en-Q0575|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Thank%20you%20for%20your%20interest%20in%20our%20language.)
^en-Q0575-answer

**en-Q0576** — Thank you for your interest in our language.

हमारी भाषा में रूचि रखने के लिए धन्यवाद्।

Complement patterns belong to the governing word: decide to act, avoid acting, insist on acting. To can be infinitive marker or preposition. Do not assume a synonym accepts the same complement pattern.

Why: Non-finite complements. [[English#^en-Q0576|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Thank%20you%20for%20your%20interest%20in%20our%20language.)
^en-Q0576-answer

**en-Q0577** — What kind of people do you like best?

तुम्हें किस तरह के लोग सबसे ज़्यादा पसंद हैं?

Expected form: **of**

Why: Non-finite complements. [[English#^en-Q0577|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=What%20kind%20of%20people%20do%20you%20like%20best%3F)
^en-Q0577-answer

**en-Q0578** — What kind of people do you like best?

तुम्हें किस तरह के लोग सबसे ज़्यादा पसंद हैं?

Expected form: **of**

Why: Non-finite complements. [[English#^en-Q0578|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=What%20kind%20of%20people%20do%20you%20like%20best%3F)
^en-Q0578-answer

**en-Q0579** — Their manners and customs are different from those of this country.

उनके रीति-रिवाज़ इस देश के से अलग हैं।

Expected form: **of**

Why: Non-finite complements. [[English#^en-Q0579|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Their%20manners%20and%20customs%20are%20different%20from%20those%20of%20this%20country.)
^en-Q0579-answer

**en-Q0580** — Their manners and customs are different from those of this country.

उनके रीति-रिवाज़ इस देश के से अलग हैं।

Why: Non-finite complements. [[English#^en-Q0580|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Their%20manners%20and%20customs%20are%20different%20from%20those%20of%20this%20country.)
^en-Q0580-answer

**en-Q0581** — His doctor told him not to drink alcohol.

उसके डाक्टर ने उसे मद्य पीने से मना किया।

Why: Non-finite complements. [[English#^en-Q0581|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=His%20doctor%20told%20him%20not%20to%20drink%20alcohol.)
^en-Q0581-answer

**en-Q0582** — His doctor told him not to drink alcohol.

उसके डाक्टर ने उसे मद्य पीने से मना किया।

Complement patterns belong to the governing word: decide to act, avoid acting, insist on acting. To can be infinitive marker or preposition. Do not assume a synonym accepts the same complement pattern.

Why: Non-finite complements. [[English#^en-Q0582|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=His%20doctor%20told%20him%20not%20to%20drink%20alcohol.)
^en-Q0582-answer

**en-Q0583** — The secret of longevity is to choose your parents carefully.

धीर्ग आयु का राज़ अपने माता पिता का सतर्क चुनाव में है |

Expected form: **of**

Why: Non-finite complements. [[English#^en-Q0583|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20secret%20of%20longevity%20is%20to%20choose%20your%20parents%20carefully.)
^en-Q0583-answer

**en-Q0584** — The secret of longevity is to choose your parents carefully.

धीर्ग आयु का राज़ अपने माता पिता का सतर्क चुनाव में है |

Expected form: **of**

Why: Non-finite complements. [[English#^en-Q0584|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20secret%20of%20longevity%20is%20to%20choose%20your%20parents%20carefully.)
^en-Q0584-answer

**en-Q0585** — It would be better for you not to ask him for advice.

बहतर होगा कि तुम उससे सलाह न माँगो।

Expected form: **for**

Why: Non-finite complements. [[English#^en-Q0585|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=It%20would%20be%20better%20for%20you%20not%20to%20ask%20him%20for%20advice.)
^en-Q0585-answer

**en-Q0586** — It would be better for you not to ask him for advice.

बहतर होगा कि तुम उससे सलाह न माँगो।

Why: Non-finite complements. [[English#^en-Q0586|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=It%20would%20be%20better%20for%20you%20not%20to%20ask%20him%20for%20advice.)
^en-Q0586-answer

**en-Q0587** — I know that you don't want to talk to me.

मुझे मालूम है आप मेरे साथ बात नहीं करना चाहते।

Why: Non-finite complements. [[English#^en-Q0587|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20know%20that%20you%20don%27t%20want%20to%20talk%20to%20me.)
^en-Q0587-answer

**en-Q0588** — I know that you don't want to talk to me.

मुझे मालूम है आप मेरे साथ बात नहीं करना चाहते।

Complement patterns belong to the governing word: decide to act, avoid acting, insist on acting. To can be infinitive marker or preposition. Do not assume a synonym accepts the same complement pattern.

Why: Non-finite complements. [[English#^en-Q0588|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20know%20that%20you%20don%27t%20want%20to%20talk%20to%20me.)
^en-Q0588-answer

**en-Q0589** — Write back to me as soon as you get this letter.

तुम्हें जैसे ही यह पत्र मिले मुझे लिखकर जवाब देना।

Expected form: **to**

Why: Non-finite complements. [[English#^en-Q0589|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Write%20back%20to%20me%20as%20soon%20as%20you%20get%20this%20letter.)
^en-Q0589-answer

**en-Q0590** — Write back to me as soon as you get this letter.

तुम्हें जैसे ही यह पत्र मिले मुझे लिखकर जवाब देना।

Expected form: **to**

Why: Non-finite complements. [[English#^en-Q0590|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Write%20back%20to%20me%20as%20soon%20as%20you%20get%20this%20letter.)
^en-Q0590-answer

**en-Q0591** — As a matter of fact, I dislike him.

दरअसल मुझे वह पसंद नहीं है।

Expected form: **of**

Why: Non-finite complements. [[English#^en-Q0591|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=As%20a%20matter%20of%20fact%2C%20I%20dislike%20him.)
^en-Q0591-answer

**en-Q0592** — As a matter of fact, I dislike him.

दरअसल मुझे वह पसंद नहीं है।

Why: Non-finite complements. [[English#^en-Q0592|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=As%20a%20matter%20of%20fact%2C%20I%20dislike%20him.)
^en-Q0592-answer

**en-Q0593** — We simply didn't expect to see such filth on the family shopping site.

हमने पारिवारिक शापिंग साइट पर इस प्रकार की अश्लीलता देखने की कभी कल्पना नहीं की थी।

Why: Non-finite complements. [[English#^en-Q0593|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=We%20simply%20didn%27t%20expect%20to%20see%20such%20filth%20on%20the%20family%20shopping%20site.)
^en-Q0593-answer

**en-Q0594** — We simply didn't expect to see such filth on the family shopping site.

हमने पारिवारिक शापिंग साइट पर इस प्रकार की अश्लीलता देखने की कभी कल्पना नहीं की थी।

Complement patterns belong to the governing word: decide to act, avoid acting, insist on acting. To can be infinitive marker or preposition. Do not assume a synonym accepts the same complement pattern.

Why: Non-finite complements. [[English#^en-Q0594|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=We%20simply%20didn%27t%20expect%20to%20see%20such%20filth%20on%20the%20family%20shopping%20site.)
^en-Q0594-answer

**en-Q0595** — I have to put the baby to bed.

मुझे बच्चे को सुलाना है।

Expected form: **to**

Why: Non-finite complements. [[English#^en-Q0595|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20have%20to%20put%20the%20baby%20to%20bed.)
^en-Q0595-answer

**en-Q0596** — I have to put the baby to bed.

मुझे बच्चे को सुलाना है।

Expected form: **to**

Why: Non-finite complements. [[English#^en-Q0596|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20have%20to%20put%20the%20baby%20to%20bed.)
^en-Q0596-answer

**en-Q0597** — I am connecting this computer to the Internet.

मैं इस कम्प्यूटर को इंटरनेट से जोड़ रहा हूं।

Expected form: **to**

Why: Non-finite complements. [[English#^en-Q0597|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20am%20connecting%20this%20computer%20to%20the%20Internet.)
^en-Q0597-answer

**en-Q0598** — I am connecting this computer to the Internet.

मैं इस कम्प्यूटर को इंटरनेट से जोड़ रहा हूं।

Why: Non-finite complements. [[English#^en-Q0598|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20am%20connecting%20this%20computer%20to%20the%20Internet.)
^en-Q0598-answer

**en-Q0599** — Do we have to get up early tomorrow morning?

क्या हमे कल सुबह जल्दी उठना है?

Why: Non-finite complements. [[English#^en-Q0599|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Do%20we%20have%20to%20get%20up%20early%20tomorrow%20morning%3F)
^en-Q0599-answer

**en-Q0600** — Do we have to get up early tomorrow morning?

क्या हमे कल सुबह जल्दी उठना है?

Complement patterns belong to the governing word: decide to act, avoid acting, insist on acting. To can be infinitive marker or preposition. Do not assume a synonym accepts the same complement pattern.

Why: Non-finite complements. [[English#^en-Q0600|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Do%20we%20have%20to%20get%20up%20early%20tomorrow%20morning%3F)
^en-Q0600-answer


### Answers 601–650

**en-Q0601** — Susan is older than me by 2 years.

सूज़ैन मुझसे दो साल बड़ी है।

Expected form: **by**

Why: Non-finite complements. [[English#^en-Q0601|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Susan%20is%20older%20than%20me%20by%202%20years.)
^en-Q0601-answer

**en-Q0602** — Susan is older than me by 2 years.

सूज़ैन मुझसे दो साल बड़ी है।

Expected form: **by**

Why: Non-finite complements. [[English#^en-Q0602|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Susan%20is%20older%20than%20me%20by%202%20years.)
^en-Q0602-answer

**en-Q0603** — A madman is not accountable for his actions.

एक पागल इनसान को अपने किये-धरे के लिए ज़िम्मेदार नहीं ठहराया जा सकता।

Expected form: **for**

Why: Non-finite complements. [[English#^en-Q0603|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=A%20madman%20is%20not%20accountable%20for%20his%20actions.)
^en-Q0603-answer

**en-Q0604** — A madman is not accountable for his actions.

एक पागल इनसान को अपने किये-धरे के लिए ज़िम्मेदार नहीं ठहराया जा सकता।

Why: Non-finite complements. [[English#^en-Q0604|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=A%20madman%20is%20not%20accountable%20for%20his%20actions.)
^en-Q0604-answer

**en-Q0605** — Maybe I am unhappy, but I don't intend to kill myself.

हाँ शायद मैं दुखी हूँ, पर मुझे अपनी जान लेने का इरादा नहीं है।

Why: Pronoun reference and reflexives. [[English#^en-Q0605|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Maybe%20I%20am%20unhappy%2C%20but%20I%20don%27t%20intend%20to%20kill%20myself.)
^en-Q0605-answer

**en-Q0606** — Maybe I am unhappy, but I don't intend to kill myself.

हाँ शायद मैं दुखी हूँ, पर मुझे अपनी जान लेने का इरादा नहीं है।

A reflexive typically refers back to an appropriate antecedent. It can also add emphasis. Professional style does not require replacing me with myself when no reflexive relation exists.

Why: Pronoun reference and reflexives. [[English#^en-Q0606|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Maybe%20I%20am%20unhappy%2C%20but%20I%20don%27t%20intend%20to%20kill%20myself.)
^en-Q0606-answer

**en-Q0607** — When you betray somebody else, you also betray yourself.

आप किसी व्यक्ति को धोखा देते हैं तो आप अपने आप को भी धोखा देते हैं।

Expected form: **yourself**

Why: Pronoun reference and reflexives. [[English#^en-Q0607|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=When%20you%20betray%20somebody%20else%2C%20you%20also%20betray%20yourself.)
^en-Q0607-answer

**en-Q0608** — When you betray somebody else, you also betray yourself.

आप किसी व्यक्ति को धोखा देते हैं तो आप अपने आप को भी धोखा देते हैं।

Expected form: **yourself**

Why: Pronoun reference and reflexives. [[English#^en-Q0608|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=When%20you%20betray%20somebody%20else%2C%20you%20also%20betray%20yourself.)
^en-Q0608-answer

**en-Q0609** — You need to be attentive during the interview and grab any opportunity that presents itself.

इंटरव्यू के दौरान तुम्हें सतर्क रहना होगा और मौक़ा दिखते ही उसे हाथ ले लेना होगा।

Expected form: **itself**

Why: Pronoun reference and reflexives. [[English#^en-Q0609|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=You%20need%20to%20be%20attentive%20during%20the%20interview%20and%20grab%20any%20opportunity%20that%20presents%20itself.)
^en-Q0609-answer

**en-Q0610** — You need to be attentive during the interview and grab any opportunity that presents itself.

इंटरव्यू के दौरान तुम्हें सतर्क रहना होगा और मौक़ा दिखते ही उसे हाथ ले लेना होगा।

Why: Pronoun reference and reflexives. [[English#^en-Q0610|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=You%20need%20to%20be%20attentive%20during%20the%20interview%20and%20grab%20any%20opportunity%20that%20presents%20itself.)
^en-Q0610-answer

**en-Q0611** — We never know the love of a parent till we become parents ourselves.

हम जब तक खुद मां बाप नहीं बन जाएं, मां बाप का प्यार कभी नहीं जान पाते।

Why: Pronoun reference and reflexives. [[English#^en-Q0611|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=We%20never%20know%20the%20love%20of%20a%20parent%20till%20we%20become%20parents%20ourselves.)
^en-Q0611-answer

**en-Q0612** — We never know the love of a parent till we become parents ourselves.

हम जब तक खुद मां बाप नहीं बन जाएं, मां बाप का प्यार कभी नहीं जान पाते।

A reflexive typically refers back to an appropriate antecedent. It can also add emphasis. Professional style does not require replacing me with myself when no reflexive relation exists.

Why: Pronoun reference and reflexives. [[English#^en-Q0612|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=We%20never%20know%20the%20love%20of%20a%20parent%20till%20we%20become%20parents%20ourselves.)
^en-Q0612-answer

**en-Q0613** — She said to herself, "I am very happy."

उसने अपने आप से कहा: "मैं बहुत खुश हूँ"

Expected form: **herself**

Why: Pronoun reference and reflexives. [[English#^en-Q0613|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=She%20said%20to%20herself%2C%20%22I%20am%20very%20happy.%22)
^en-Q0613-answer

**en-Q0614** — She said to herself, "I am very happy."

उसने अपने आप से कहा: "मैं बहुत खुश हूँ"

Expected form: **herself**

Why: Pronoun reference and reflexives. [[English#^en-Q0614|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=She%20said%20to%20herself%2C%20%22I%20am%20very%20happy.%22)
^en-Q0614-answer

**en-Q0615** — "What shall I do?" I said to myself.

"क्या करूँ?" मैंने अपने-आप से पूछा।

Expected form: **myself**

Why: Pronoun reference and reflexives. [[English#^en-Q0615|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=%22What%20shall%20I%20do%3F%22%20I%20said%20to%20myself.)
^en-Q0615-answer

**en-Q0616** — "What shall I do?" I said to myself.

"क्या करूँ?" मैंने अपने-आप से पूछा।

Why: Pronoun reference and reflexives. [[English#^en-Q0616|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=%22What%20shall%20I%20do%3F%22%20I%20said%20to%20myself.)
^en-Q0616-answer

**en-Q0617** — He is brave enough to go there by himself.

वह वहाँ अकेले जाने लायक बहादुर है।

Why: Pronoun reference and reflexives. [[English#^en-Q0617|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%20is%20brave%20enough%20to%20go%20there%20by%20himself.)
^en-Q0617-answer

**en-Q0618** — He is brave enough to go there by himself.

वह वहाँ अकेले जाने लायक बहादुर है।

A reflexive typically refers back to an appropriate antecedent. It can also add emphasis. Professional style does not require replacing me with myself when no reflexive relation exists.

Why: Pronoun reference and reflexives. [[English#^en-Q0618|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%20is%20brave%20enough%20to%20go%20there%20by%20himself.)
^en-Q0618-answer

**en-Q0619** — He is now old enough to travel by himself.

उसकी अकेले सफ़र करने की उम्र हो गयी है।

Expected form: **himself**

Why: Pronoun reference and reflexives. [[English#^en-Q0619|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%20is%20now%20old%20enough%20to%20travel%20by%20himself.)
^en-Q0619-answer

**en-Q0620** — He is now old enough to travel by himself.

उसकी अकेले सफ़र करने की उम्र हो गयी है।

Expected form: **himself**

Why: Pronoun reference and reflexives. [[English#^en-Q0620|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%20is%20now%20old%20enough%20to%20travel%20by%20himself.)
^en-Q0620-answer

**en-Q0621** — It will go away by itself in two weeks.

वह दो हफ़्तों में अपने-आप चला जाएगा।

Expected form: **itself**

Why: Pronoun reference and reflexives. [[English#^en-Q0621|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=It%20will%20go%20away%20by%20itself%20in%20two%20weeks.)
^en-Q0621-answer

**en-Q0622** — It will go away by itself in two weeks.

वह दो हफ़्तों में अपने-आप चला जाएगा।

Why: Pronoun reference and reflexives. [[English#^en-Q0622|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=It%20will%20go%20away%20by%20itself%20in%20two%20weeks.)
^en-Q0622-answer

**en-Q0623** — Please keep your ludicrous accusations to yourself in future.

कृपया भविष्य में अपने बेतुके दोषारोपणों को अपने पास ही रखें।

Why: Pronoun reference and reflexives. [[English#^en-Q0623|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Please%20keep%20your%20ludicrous%20accusations%20to%20yourself%20in%20future.)
^en-Q0623-answer

**en-Q0624** — Please keep your ludicrous accusations to yourself in future.

कृपया भविष्य में अपने बेतुके दोषारोपणों को अपने पास ही रखें।

A reflexive typically refers back to an appropriate antecedent. It can also add emphasis. Professional style does not require replacing me with myself when no reflexive relation exists.

Why: Pronoun reference and reflexives. [[English#^en-Q0624|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Please%20keep%20your%20ludicrous%20accusations%20to%20yourself%20in%20future.)
^en-Q0624-answer

**en-Q0625** — I was a fool to have tried explaining something to you that I don't understand myself.

मैं अक्ल का मारा था जो तुम्हें वह समझाने की कोशिश करने बैठा जिसकी मुझे खुद ही समझ नहीं थी।

Expected form: **myself**

Why: Pronoun reference and reflexives. [[English#^en-Q0625|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20was%20a%20fool%20to%20have%20tried%20explaining%20something%20to%20you%20that%20I%20don%27t%20understand%20myself.)
^en-Q0625-answer

**en-Q0626** — I was a fool to have tried explaining something to you that I don't understand myself.

मैं अक्ल का मारा था जो तुम्हें वह समझाने की कोशिश करने बैठा जिसकी मुझे खुद ही समझ नहीं थी।

Expected form: **myself**

Why: Pronoun reference and reflexives. [[English#^en-Q0626|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20was%20a%20fool%20to%20have%20tried%20explaining%20something%20to%20you%20that%20I%20don%27t%20understand%20myself.)
^en-Q0626-answer

**en-Q0627** — He broke himself of the bad habit of smoking.

उसने अपनी सिगरेट पीने की बुरी आदत छोड़ दी।

Expected form: **himself**

Why: Pronoun reference and reflexives. [[English#^en-Q0627|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%20broke%20himself%20of%20the%20bad%20habit%20of%20smoking.)
^en-Q0627-answer

**en-Q0628** — He broke himself of the bad habit of smoking.

उसने अपनी सिगरेट पीने की बुरी आदत छोड़ दी।

Why: Pronoun reference and reflexives. [[English#^en-Q0628|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%20broke%20himself%20of%20the%20bad%20habit%20of%20smoking.)
^en-Q0628-answer

**en-Q0629** — I drank too much. My face is swollen!

मैंने कुछ ज़्यादा ही पी लिया है। मेरा पूरा चेहरा सूज गया है!

Why: Quantifiers and agreement. [[English#^en-Q0629|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20drank%20too%20much.%20My%20face%20is%20swollen%21)
^en-Q0629-answer

**en-Q0630** — I drank too much. My face is swollen!

मैंने कुछ ज़्यादा ही पी लिया है। मेरा पूरा चेहरा सूज गया है!

Quantifiers interact with countability and agreement. Much/little often pair with uncountables, many/few with count plurals. Each/every usually selects singular agreement, while usage around either/neither can depend on the full construction.

Why: Quantifiers and agreement. [[English#^en-Q0630|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20drank%20too%20much.%20My%20face%20is%20swollen%21)
^en-Q0630-answer

**en-Q0631** — How many letters does the Russian alphabet have?

रूसी वर्णमाला में कितने अक्षर हैं?

Expected form: **many**

Why: Quantifiers and agreement. [[English#^en-Q0631|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=How%20many%20letters%20does%20the%20Russian%20alphabet%20have%3F)
^en-Q0631-answer

**en-Q0632** — How many letters does the Russian alphabet have?

रूसी वर्णमाला में कितने अक्षर हैं?

Expected form: **many**

Why: Quantifiers and agreement. [[English#^en-Q0632|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=How%20many%20letters%20does%20the%20Russian%20alphabet%20have%3F)
^en-Q0632-answer

**en-Q0633** — We can hear the church bell every morning.

हमें हर सुबह चर्च की घंटी सुनाई देती है।

Expected form: **every**

Why: Quantifiers and agreement. [[English#^en-Q0633|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=We%20can%20hear%20the%20church%20bell%20every%20morning.)
^en-Q0633-answer

**en-Q0634** — We can hear the church bell every morning.

हमें हर सुबह चर्च की घंटी सुनाई देती है।

Why: Quantifiers and agreement. [[English#^en-Q0634|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=We%20can%20hear%20the%20church%20bell%20every%20morning.)
^en-Q0634-answer

**en-Q0635** — Cows are sacred to many people in India.

भारत में कई लोग गाय को पूज्य मानते हैं।

Why: Quantifiers and agreement. [[English#^en-Q0635|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Cows%20are%20sacred%20to%20many%20people%20in%20India.)
^en-Q0635-answer

**en-Q0636** — Cows are sacred to many people in India.

भारत में कई लोग गाय को पूज्य मानते हैं।

Quantifiers interact with countability and agreement. Much/little often pair with uncountables, many/few with count plurals. Each/every usually selects singular agreement, while usage around either/neither can depend on the full construction.

Why: Quantifiers and agreement. [[English#^en-Q0636|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Cows%20are%20sacred%20to%20many%20people%20in%20India.)
^en-Q0636-answer

**en-Q0637** — Many great men went through hardship during their youth.

कई महान पुरुषों को अपने जवानी में कठिनाई का सामना करना पड़ा।

Expected form: **Many**

Why: Quantifiers and agreement. [[English#^en-Q0637|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Many%20great%20men%20went%20through%20hardship%20during%20their%20youth.)
^en-Q0637-answer

**en-Q0638** — Many great men went through hardship during their youth.

कई महान पुरुषों को अपने जवानी में कठिनाई का सामना करना पड़ा।

Expected form: **Many**

Why: Quantifiers and agreement. [[English#^en-Q0638|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Many%20great%20men%20went%20through%20hardship%20during%20their%20youth.)
^en-Q0638-answer

**en-Q0639** — Many people encouraged me to fulfill my ambitions.

अपनी अभिलाषाओं को पूरी करने के लिए मुझे बहुत से लोगों ने बढ़ावा दिया।

Expected form: **Many**

Why: Quantifiers and agreement. [[English#^en-Q0639|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Many%20people%20encouraged%20me%20to%20fulfill%20my%20ambitions.)
^en-Q0639-answer

**en-Q0640** — Many people encouraged me to fulfill my ambitions.

अपनी अभिलाषाओं को पूरी करने के लिए मुझे बहुत से लोगों ने बढ़ावा दिया।

Why: Quantifiers and agreement. [[English#^en-Q0640|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Many%20people%20encouraged%20me%20to%20fulfill%20my%20ambitions.)
^en-Q0640-answer

**en-Q0641** — We love each other, but we don't have sex anymore.

हम एक दूसरे से प्यार करते हैं, मगर अब हम सेक्स नहीं करते।

Why: Quantifiers and agreement. [[English#^en-Q0641|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=We%20love%20each%20other%2C%20but%20we%20don%27t%20have%20sex%20anymore.)
^en-Q0641-answer

**en-Q0642** — We love each other, but we don't have sex anymore.

हम एक दूसरे से प्यार करते हैं, मगर अब हम सेक्स नहीं करते।

Quantifiers interact with countability and agreement. Much/little often pair with uncountables, many/few with count plurals. Each/every usually selects singular agreement, while usage around either/neither can depend on the full construction.

Why: Quantifiers and agreement. [[English#^en-Q0642|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=We%20love%20each%20other%2C%20but%20we%20don%27t%20have%20sex%20anymore.)
^en-Q0642-answer

**en-Q0643** — Each member has to pay a membership fee.

हर सदस्य को सदस्यता शुल्क भरना होगा।

Expected form: **Each**

Why: Quantifiers and agreement. [[English#^en-Q0643|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Each%20member%20has%20to%20pay%20a%20membership%20fee.)
^en-Q0643-answer

**en-Q0644** — Each member has to pay a membership fee.

हर सदस्य को सदस्यता शुल्क भरना होगा।

Expected form: **Each**

Why: Quantifiers and agreement. [[English#^en-Q0644|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Each%20member%20has%20to%20pay%20a%20membership%20fee.)
^en-Q0644-answer

**en-Q0645** — Tom has two sons. Both of them live in Boston.

टॉम के दो बेटे हैं। दोनों बॉस्टन में रहते हैं।

Expected form: **Both**

Why: Quantifiers and agreement. [[English#^en-Q0645|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Tom%20has%20two%20sons.%20Both%20of%20them%20live%20in%20Boston.)
^en-Q0645-answer

**en-Q0646** — Tom has two sons. Both of them live in Boston.

टॉम के दो बेटे हैं। दोनों बॉस्टन में रहते हैं।

Why: Quantifiers and agreement. [[English#^en-Q0646|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Tom%20has%20two%20sons.%20Both%20of%20them%20live%20in%20Boston.)
^en-Q0646-answer

**en-Q0647** — His success is the result of many years of perseverance.

उसकी सफ़लता सालों की मेहनत का फल है।

Why: Quantifiers and agreement. [[English#^en-Q0647|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=His%20success%20is%20the%20result%20of%20many%20years%20of%20perseverance.)
^en-Q0647-answer

**en-Q0648** — His success is the result of many years of perseverance.

उसकी सफ़लता सालों की मेहनत का फल है।

Quantifiers interact with countability and agreement. Much/little often pair with uncountables, many/few with count plurals. Each/every usually selects singular agreement, while usage around either/neither can depend on the full construction.

Why: Quantifiers and agreement. [[English#^en-Q0648|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=His%20success%20is%20the%20result%20of%20many%20years%20of%20perseverance.)
^en-Q0648-answer

**en-Q0649** — We communicate with each other by telephone every day.

हम रोज़ एक-दूसरे से फ़ोन पर बात करते हैं।

Expected form: **each**

Why: Quantifiers and agreement. [[English#^en-Q0649|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=We%20communicate%20with%20each%20other%20by%20telephone%20every%20day.)
^en-Q0649-answer

**en-Q0650** — We communicate with each other by telephone every day.

हम रोज़ एक-दूसरे से फ़ोन पर बात करते हैं।

Expected form: **each**

Why: Quantifiers and agreement. [[English#^en-Q0650|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=We%20communicate%20with%20each%20other%20by%20telephone%20every%20day.)
^en-Q0650-answer


### Answers 651–700

**en-Q0651** — My father stayed a few days in Frankfurt.

मेरे पिता फ़्रैंकफुर्ट में कुछ दिन रहें।

Expected form: **few**

Why: Quantifiers and agreement. [[English#^en-Q0651|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=My%20father%20stayed%20a%20few%20days%20in%20Frankfurt.)
^en-Q0651-answer

**en-Q0652** — My father stayed a few days in Frankfurt.

मेरे पिता फ़्रैंकफुर्ट में कुछ दिन रहें।

Why: Quantifiers and agreement. [[English#^en-Q0652|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=My%20father%20stayed%20a%20few%20days%20in%20Frankfurt.)
^en-Q0652-answer

**en-Q0653** — Much as I admire him as a writer, I don't like him as a man.

मैं लेखक के तौर पर उनका आदर करता हूँ, पर इनसान के तौर पर उन्हें पसंद नहीं करता।

Why: Quantifiers and agreement. [[English#^en-Q0653|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Much%20as%20I%20admire%20him%20as%20a%20writer%2C%20I%20don%27t%20like%20him%20as%20a%20man.)
^en-Q0653-answer

**en-Q0654** — Much as I admire him as a writer, I don't like him as a man.

मैं लेखक के तौर पर उनका आदर करता हूँ, पर इनसान के तौर पर उन्हें पसंद नहीं करता।

Quantifiers interact with countability and agreement. Much/little often pair with uncountables, many/few with count plurals. Each/every usually selects singular agreement, while usage around either/neither can depend on the full construction.

Why: Quantifiers and agreement. [[English#^en-Q0654|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Much%20as%20I%20admire%20him%20as%20a%20writer%2C%20I%20don%27t%20like%20him%20as%20a%20man.)
^en-Q0654-answer

**en-Q0655** — How many people were present at the meeting?

बैठक मैं कितने लोग मौजूद थे ?

Expected form: **many**

Why: Quantifiers and agreement. [[English#^en-Q0655|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=How%20many%20people%20were%20present%20at%20the%20meeting%3F)
^en-Q0655-answer

**en-Q0656** — How many people were present at the meeting?

बैठक मैं कितने लोग मौजूद थे ?

Expected form: **many**

Why: Quantifiers and agreement. [[English#^en-Q0656|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=How%20many%20people%20were%20present%20at%20the%20meeting%3F)
^en-Q0656-answer

**en-Q0657** — Have you spoke to him in the past few days?

क्या तुमने उस से बीते दिनों में वार्तालाप की है?

Expected form: **few**

Why: Quantifiers and agreement. [[English#^en-Q0657|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Have%20you%20spoke%20to%20him%20in%20the%20past%20few%20days%3F)
^en-Q0657-answer

**en-Q0658** — Have you spoke to him in the past few days?

क्या तुमने उस से बीते दिनों में वार्तालाप की है?

Why: Quantifiers and agreement. [[English#^en-Q0658|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Have%20you%20spoke%20to%20him%20in%20the%20past%20few%20days%3F)
^en-Q0658-answer

**en-Q0659** — Neither wild nor domestic animals appear to have any premonition of death.

न तो वन्य जीवों और न ही घरेलू जीवों को मृत्यु का पूर्वाभास होता है।

Why: Quantifiers and agreement. [[English#^en-Q0659|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Neither%20wild%20nor%20domestic%20animals%20appear%20to%20have%20any%20premonition%20of%20death.)
^en-Q0659-answer

**en-Q0660** — Neither wild nor domestic animals appear to have any premonition of death.

न तो वन्य जीवों और न ही घरेलू जीवों को मृत्यु का पूर्वाभास होता है।

Quantifiers interact with countability and agreement. Much/little often pair with uncountables, many/few with count plurals. Each/every usually selects singular agreement, while usage around either/neither can depend on the full construction.

Why: Quantifiers and agreement. [[English#^en-Q0660|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Neither%20wild%20nor%20domestic%20animals%20appear%20to%20have%20any%20premonition%20of%20death.)
^en-Q0660-answer

**en-Q0661** — It's good now; neither too heavy nor too light.

अब ठीक है। न ज़्यादा भारी है न ज़्यादा हल्का है।

Expected form: **neither**

Why: Quantifiers and agreement. [[English#^en-Q0661|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=It%27s%20good%20now%3B%20neither%20too%20heavy%20nor%20too%20light.)
^en-Q0661-answer

**en-Q0662** — It's good now; neither too heavy nor too light.

अब ठीक है। न ज़्यादा भारी है न ज़्यादा हल्का है।

Expected form: **neither**

Why: Quantifiers and agreement. [[English#^en-Q0662|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=It%27s%20good%20now%3B%20neither%20too%20heavy%20nor%20too%20light.)
^en-Q0662-answer

**en-Q0663** — She is capable of teaching both English and French.

उसके पास अंग्रेज़ी और फ़्रांसीसी सिखाने की काबिलियत है।

Expected form: **both**

Why: Quantifiers and agreement. [[English#^en-Q0663|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=She%20is%20capable%20of%20teaching%20both%20English%20and%20French.)
^en-Q0663-answer

**en-Q0664** — She is capable of teaching both English and French.

उसके पास अंग्रेज़ी और फ़्रांसीसी सिखाने की काबिलियत है।

Why: Quantifiers and agreement. [[English#^en-Q0664|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=She%20is%20capable%20of%20teaching%20both%20English%20and%20French.)
^en-Q0664-answer

**en-Q0665** — He has every reason for getting angry with you.

उसके पास तुमसे नाराज़ होने का पूरा हक है।

Why: Quantifiers and agreement. [[English#^en-Q0665|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%20has%20every%20reason%20for%20getting%20angry%20with%20you.)
^en-Q0665-answer

**en-Q0666** — He has every reason for getting angry with you.

उसके पास तुमसे नाराज़ होने का पूरा हक है।

Quantifiers interact with countability and agreement. Much/little often pair with uncountables, many/few with count plurals. Each/every usually selects singular agreement, while usage around either/neither can depend on the full construction.

Why: Quantifiers and agreement. [[English#^en-Q0666|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%20has%20every%20reason%20for%20getting%20angry%20with%20you.)
^en-Q0666-answer

**en-Q0667** — How many books do you read a month?

तुम एक महीने में कितनी किताबें पढ़ते हो?

Expected form: **many**

Why: Quantifiers and agreement. [[English#^en-Q0667|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=How%20many%20books%20do%20you%20read%20a%20month%3F)
^en-Q0667-answer

**en-Q0668** — How many books do you read a month?

तुम एक महीने में कितनी किताबें पढ़ते हो?

Expected form: **many**

Why: Quantifiers and agreement. [[English#^en-Q0668|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=How%20many%20books%20do%20you%20read%20a%20month%3F)
^en-Q0668-answer

**en-Q0669** — He goes with his mother to Russia every year.

वह हर साल अपनी माँ के साथ रूस जाता है।

Expected form: **every**

Why: Quantifiers and agreement. [[English#^en-Q0669|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%20goes%20with%20his%20mother%20to%20Russia%20every%20year.)
^en-Q0669-answer

**en-Q0670** — He goes with his mother to Russia every year.

वह हर साल अपनी माँ के साथ रूस जाता है।

Why: Quantifiers and agreement. [[English#^en-Q0670|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%20goes%20with%20his%20mother%20to%20Russia%20every%20year.)
^en-Q0670-answer

**en-Q0671** — He is a nice man, except that he talks too much.

वह आदमी तो भला है, पर बात बहुत ज़्यादा करता है।

Why: Quantifiers and agreement. [[English#^en-Q0671|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%20is%20a%20nice%20man%2C%20except%20that%20he%20talks%20too%20much.)
^en-Q0671-answer

**en-Q0672** — He is a nice man, except that he talks too much.

वह आदमी तो भला है, पर बात बहुत ज़्यादा करता है।

Quantifiers interact with countability and agreement. Much/little often pair with uncountables, many/few with count plurals. Each/every usually selects singular agreement, while usage around either/neither can depend on the full construction.

Why: Quantifiers and agreement. [[English#^en-Q0672|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%20is%20a%20nice%20man%2C%20except%20that%20he%20talks%20too%20much.)
^en-Q0672-answer

**en-Q0673** — We talked to each other for a while.

हमने थोड़ी देर के लिए एक-दूसरे के साथ बात करी।

Expected form: **each**

Why: Quantifiers and agreement. [[English#^en-Q0673|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=We%20talked%20to%20each%20other%20for%20a%20while.)
^en-Q0673-answer

**en-Q0674** — We talked to each other for a while.

हमने थोड़ी देर के लिए एक-दूसरे के साथ बात करी।

Expected form: **each**

Why: Quantifiers and agreement. [[English#^en-Q0674|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=We%20talked%20to%20each%20other%20for%20a%20while.)
^en-Q0674-answer

**en-Q0675** — Mom, add a little more salt to the soup.

मम्मी, सूप में थोड़ा और नमक डालो।

Expected form: **little**

Why: Quantifiers and agreement. [[English#^en-Q0675|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Mom%2C%20add%20a%20little%20more%20salt%20to%20the%20soup.)
^en-Q0675-answer

**en-Q0676** — Mom, add a little more salt to the soup.

मम्मी, सूप में थोड़ा और नमक डालो।

Why: Quantifiers and agreement. [[English#^en-Q0676|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Mom%2C%20add%20a%20little%20more%20salt%20to%20the%20soup.)
^en-Q0676-answer

**en-Q0677** — It is very important for us to know each other.

हमारे लिए एक-दूसरे को समझना बहुत ज़रूरी है।

Why: Quantifiers and agreement. [[English#^en-Q0677|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=It%20is%20very%20important%20for%20us%20to%20know%20each%20other.)
^en-Q0677-answer

**en-Q0678** — It is very important for us to know each other.

हमारे लिए एक-दूसरे को समझना बहुत ज़रूरी है।

Quantifiers interact with countability and agreement. Much/little often pair with uncountables, many/few with count plurals. Each/every usually selects singular agreement, while usage around either/neither can depend on the full construction.

Why: Quantifiers and agreement. [[English#^en-Q0678|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=It%20is%20very%20important%20for%20us%20to%20know%20each%20other.)
^en-Q0678-answer

**en-Q0679** — That was just the trailer, the movie's yet to come, my friend!

यह तो बस ट्रेलर है, पिक्चर अभी बाकी है, मेरे दोस्त!

Expected form: **yet**

Why: Time-frame control. [[English#^en-Q0679|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=That%20was%20just%20the%20trailer%2C%20the%20movie%27s%20yet%20to%20come%2C%20my%20friend%21)
^en-Q0679-answer

**en-Q0680** — That was just the trailer, the movie's yet to come, my friend!

यह तो बस ट्रेलर है, पिक्चर अभी बाकी है, मेरे दोस्त!

Expected form: **yet**

Why: Time-frame control. [[English#^en-Q0680|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=That%20was%20just%20the%20trailer%2C%20the%20movie%27s%20yet%20to%20come%2C%20my%20friend%21)
^en-Q0680-answer

**en-Q0681** — The workers were laid off for three weeks.

कर्मचारियों को तीन हफ़्तों के लिए काम से निकाल दिया गया।

Expected form: **for**

Why: Time-frame control. [[English#^en-Q0681|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20workers%20were%20laid%20off%20for%20three%20weeks.)
^en-Q0681-answer

**en-Q0682** — The workers were laid off for three weeks.

कर्मचारियों को तीन हफ़्तों के लिए काम से निकाल दिया गया।

Why: Time-frame control. [[English#^en-Q0682|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20workers%20were%20laid%20off%20for%20three%20weeks.)
^en-Q0682-answer

**en-Q0683** — As far as I know, she's not yet married.

जहाँ तक की मुझे पता है, उसने अभी तक शादी नहीं की है।

Why: Time-frame control. [[English#^en-Q0683|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=As%20far%20as%20I%20know%2C%20she%27s%20not%20yet%20married.)
^en-Q0683-answer

**en-Q0684** — As far as I know, she's not yet married.

जहाँ तक की मुझे पता है, उसने अभी तक शादी नहीं की है।

Time expressions help establish an interval/reference point but do not select a tense mechanically. Ago normally locates a finished past time. Since marks a starting point; for a duration in relevant uses.

Why: Time-frame control. [[English#^en-Q0684|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=As%20far%20as%20I%20know%2C%20she%27s%20not%20yet%20married.)
^en-Q0684-answer

**en-Q0685** — Add the rice and cook gently until the grains begin to turn translucent.

चावल डालें और धीरे-धीरे उस समय तक पकाएं जब तक कि दानें पारभासी (स्वच्छ) न हो जाएं।

Expected form: **until**

Why: Time-frame control. [[English#^en-Q0685|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Add%20the%20rice%20and%20cook%20gently%20until%20the%20grains%20begin%20to%20turn%20translucent.)
^en-Q0685-answer

**en-Q0686** — Add the rice and cook gently until the grains begin to turn translucent.

चावल डालें और धीरे-धीरे उस समय तक पकाएं जब तक कि दानें पारभासी (स्वच्छ) न हो जाएं।

Expected form: **until**

Why: Time-frame control. [[English#^en-Q0686|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Add%20the%20rice%20and%20cook%20gently%20until%20the%20grains%20begin%20to%20turn%20translucent.)
^en-Q0686-answer

**en-Q0687** — I'll wait here until my medicine is ready.

जब तक मेरी दवाई तैयार नहीं होती मैं यहीं इंतेज़ार करूंगी।

Expected form: **until**

Why: Time-frame control. [[English#^en-Q0687|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%27ll%20wait%20here%20until%20my%20medicine%20is%20ready.)
^en-Q0687-answer

**en-Q0688** — I'll wait here until my medicine is ready.

जब तक मेरी दवाई तैयार नहीं होती मैं यहीं इंतेज़ार करूंगी।

Why: Time-frame control. [[English#^en-Q0688|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%27ll%20wait%20here%20until%20my%20medicine%20is%20ready.)
^en-Q0688-answer

**en-Q0689** — Be like a postage stamp. Stick to one thing until you get there.

डाक टिकट की तरह बनिए, मंजिल पर जब तक न पहुंच जाएं उसी चीज़ पर जमे रहिए।

Why: Time-frame control. [[English#^en-Q0689|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Be%20like%20a%20postage%20stamp.%20Stick%20to%20one%20thing%20until%20you%20get%20there.)
^en-Q0689-answer

**en-Q0690** — Be like a postage stamp. Stick to one thing until you get there.

डाक टिकट की तरह बनिए, मंजिल पर जब तक न पहुंच जाएं उसी चीज़ पर जमे रहिए।

Time expressions help establish an interval/reference point but do not select a tense mechanically. Ago normally locates a finished past time. Since marks a starting point; for a duration in relevant uses.

Why: Time-frame control. [[English#^en-Q0690|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Be%20like%20a%20postage%20stamp.%20Stick%20to%20one%20thing%20until%20you%20get%20there.)
^en-Q0690-answer

**en-Q0691** — Will you exchange this sweater for a larger one?

आप यह स्वेटर बड़े नाप वाले के लिए बदल देंगे क्या?

Expected form: **for**

Why: Time-frame control. [[English#^en-Q0691|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Will%20you%20exchange%20this%20sweater%20for%20a%20larger%20one%3F)
^en-Q0691-answer

**en-Q0692** — Will you exchange this sweater for a larger one?

आप यह स्वेटर बड़े नाप वाले के लिए बदल देंगे क्या?

Expected form: **for**

Why: Time-frame control. [[English#^en-Q0692|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Will%20you%20exchange%20this%20sweater%20for%20a%20larger%20one%3F)
^en-Q0692-answer

**en-Q0693** — Facebook will buy WhatsApp for 19 billion dollars.

फ़ेसबुक वॉट्सएप को १९ अरब डॉलरों में खरीद लेगा।

Expected form: **for**

Why: Time-frame control. [[English#^en-Q0693|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Facebook%20will%20buy%20WhatsApp%20for%2019%20billion%20dollars.)
^en-Q0693-answer

**en-Q0694** — Facebook will buy WhatsApp for 19 billion dollars.

फ़ेसबुक वॉट्सएप को १९ अरब डॉलरों में खरीद लेगा।

Why: Time-frame control. [[English#^en-Q0694|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Facebook%20will%20buy%20WhatsApp%20for%2019%20billion%20dollars.)
^en-Q0694-answer

**en-Q0695** — There is no more room for a TV set.

टीवी सेट के लिए और जगह नहीं है।

Why: Time-frame control. [[English#^en-Q0695|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=There%20is%20no%20more%20room%20for%20a%20TV%20set.)
^en-Q0695-answer

**en-Q0696** — There is no more room for a TV set.

टीवी सेट के लिए और जगह नहीं है।

Time expressions help establish an interval/reference point but do not select a tense mechanically. Ago normally locates a finished past time. Since marks a starting point; for a duration in relevant uses.

Why: Time-frame control. [[English#^en-Q0696|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=There%20is%20no%20more%20room%20for%20a%20TV%20set.)
^en-Q0696-answer

**en-Q0697** — It will not be long before we know the result.

नतीजा जानने में अब ज़्यादा देर नहीं लगेगी।

Expected form: **before**

Why: Time-frame control. [[English#^en-Q0697|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=It%20will%20not%20be%20long%20before%20we%20know%20the%20result.)
^en-Q0697-answer

**en-Q0698** — It will not be long before we know the result.

नतीजा जानने में अब ज़्यादा देर नहीं लगेगी।

Expected form: **before**

Why: Time-frame control. [[English#^en-Q0698|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=It%20will%20not%20be%20long%20before%20we%20know%20the%20result.)
^en-Q0698-answer

**en-Q0699** — He went outside for a breath of fresh air.

वह थोड़ी ताज़ा हवा खाने के लिए बाहर गया।

Expected form: **for**

Why: Time-frame control. [[English#^en-Q0699|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%20went%20outside%20for%20a%20breath%20of%20fresh%20air.)
^en-Q0699-answer

**en-Q0700** — He went outside for a breath of fresh air.

वह थोड़ी ताज़ा हवा खाने के लिए बाहर गया।

Why: Time-frame control. [[English#^en-Q0700|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%20went%20outside%20for%20a%20breath%20of%20fresh%20air.)
^en-Q0700-answer


### Answers 701–750

**en-Q0701** — I got married five years ago on this very day.

मेरी शादी पाँच साल पहले इसी दिन पर हुई थी।

Why: Time-frame control. [[English#^en-Q0701|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20got%20married%20five%20years%20ago%20on%20this%20very%20day.)
^en-Q0701-answer

**en-Q0702** — I got married five years ago on this very day.

मेरी शादी पाँच साल पहले इसी दिन पर हुई थी।

Time expressions help establish an interval/reference point but do not select a tense mechanically. Ago normally locates a finished past time. Since marks a starting point; for a duration in relevant uses.

Why: Time-frame control. [[English#^en-Q0702|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20got%20married%20five%20years%20ago%20on%20this%20very%20day.)
^en-Q0702-answer

**en-Q0703** — The law kept people from playing football for a while.

क़ानून ने लोगों को फ़ुटबॉल खेलने से बहुत देर तक रोका।

Expected form: **for**

Why: Time-frame control. [[English#^en-Q0703|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20law%20kept%20people%20from%20playing%20football%20for%20a%20while.)
^en-Q0703-answer

**en-Q0704** — The law kept people from playing football for a while.

क़ानून ने लोगों को फ़ुटबॉल खेलने से बहुत देर तक रोका।

Expected form: **for**

Why: Time-frame control. [[English#^en-Q0704|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20law%20kept%20people%20from%20playing%20football%20for%20a%20while.)
^en-Q0704-answer

**en-Q0705** — I haven't got in touch with him for a long time.

मेरा उसके साथ काफ़ी देर से सम्पर्क नहीं हुआ है।

Expected form: **for**

Why: Time-frame control. [[English#^en-Q0705|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20haven%27t%20got%20in%20touch%20with%20him%20for%20a%20long%20time.)
^en-Q0705-answer

**en-Q0706** — I haven't got in touch with him for a long time.

मेरा उसके साथ काफ़ी देर से सम्पर्क नहीं हुआ है।

Why: Time-frame control. [[English#^en-Q0706|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20haven%27t%20got%20in%20touch%20with%20him%20for%20a%20long%20time.)
^en-Q0706-answer

**en-Q0707** — I've been studying Uighur for two years now.

मैं अभी दो सालों से उइघुर भाषा सीख रहा हूं।

Why: Time-frame control. [[English#^en-Q0707|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%27ve%20been%20studying%20Uighur%20for%20two%20years%20now.)
^en-Q0707-answer

**en-Q0708** — I've been studying Uighur for two years now.

मैं अभी दो सालों से उइघुर भाषा सीख रहा हूं।

Time expressions help establish an interval/reference point but do not select a tense mechanically. Ago normally locates a finished past time. Since marks a starting point; for a duration in relevant uses.

Why: Time-frame control. [[English#^en-Q0708|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%27ve%20been%20studying%20Uighur%20for%20two%20years%20now.)
^en-Q0708-answer

**en-Q0709** — I am going to stay here for a couple of days.

मैं यहाँ एक-दो दिन रहूँगा।

Expected form: **for**

Why: Time-frame control. [[English#^en-Q0709|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20am%20going%20to%20stay%20here%20for%20a%20couple%20of%20days.)
^en-Q0709-answer

**en-Q0710** — I am going to stay here for a couple of days.

मैं यहाँ एक-दो दिन रहूँगा।

Expected form: **for**

Why: Time-frame control. [[English#^en-Q0710|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20am%20going%20to%20stay%20here%20for%20a%20couple%20of%20days.)
^en-Q0710-answer

**en-Q0711** — I had met her many times before then.

मैं उससे पहले कई बार मिल चुका था।

Expected form: **before**

Why: Time-frame control. [[English#^en-Q0711|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20had%20met%20her%20many%20times%20before%20then.)
^en-Q0711-answer

**en-Q0712** — I had met her many times before then.

मैं उससे पहले कई बार मिल चुका था।

Why: Time-frame control. [[English#^en-Q0712|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20had%20met%20her%20many%20times%20before%20then.)
^en-Q0712-answer

**en-Q0713** — That child is only four, but he can already count to 100.

वह बच्चा हालांकि केवल चार साल का ही है, वह अभी से ही सौ तक गिनती कर सकता है।

Why: Time-frame control. [[English#^en-Q0713|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=That%20child%20is%20only%20four%2C%20but%20he%20can%20already%20count%20to%20100.)
^en-Q0713-answer

**en-Q0714** — That child is only four, but he can already count to 100.

वह बच्चा हालांकि केवल चार साल का ही है, वह अभी से ही सौ तक गिनती कर सकता है।

Time expressions help establish an interval/reference point but do not select a tense mechanically. Ago normally locates a finished past time. Since marks a starting point; for a duration in relevant uses.

Why: Time-frame control. [[English#^en-Q0714|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=That%20child%20is%20only%20four%2C%20but%20he%20can%20already%20count%20to%20100.)
^en-Q0714-answer

**en-Q0715** — Before I joined the army, I was a doctor.

सेना में दाखिल होने से पहले में एक वैद्य था।

Expected form: **Before**

Why: Time-frame control. [[English#^en-Q0715|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Before%20I%20joined%20the%20army%2C%20I%20was%20a%20doctor.)
^en-Q0715-answer

**en-Q0716** — Before I joined the army, I was a doctor.

सेना में दाखिल होने से पहले में एक वैद्य था।

Expected form: **Before**

Why: Time-frame control. [[English#^en-Q0716|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Before%20I%20joined%20the%20army%2C%20I%20was%20a%20doctor.)
^en-Q0716-answer

**en-Q0717** — Will you take us for a drive next Sunday?

हमें अगले हफ़्ते ड्राईव पर लेजाओगे क्या?

Expected form: **for**

Why: Time-frame control. [[English#^en-Q0717|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Will%20you%20take%20us%20for%20a%20drive%20next%20Sunday%3F)
^en-Q0717-answer

**en-Q0718** — Will you take us for a drive next Sunday?

हमें अगले हफ़्ते ड्राईव पर लेजाओगे क्या?

Why: Time-frame control. [[English#^en-Q0718|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Will%20you%20take%20us%20for%20a%20drive%20next%20Sunday%3F)
^en-Q0718-answer

**en-Q0719** — I haven't seen him for a long time.

मैंने उसे बहुत दिनों से नहीं देखा है।

Why: Time-frame control. [[English#^en-Q0719|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20haven%27t%20seen%20him%20for%20a%20long%20time.)
^en-Q0719-answer

**en-Q0720** — I haven't seen him for a long time.

मैंने उसे बहुत दिनों से नहीं देखा है।

Time expressions help establish an interval/reference point but do not select a tense mechanically. Ago normally locates a finished past time. Since marks a starting point; for a duration in relevant uses.

Why: Time-frame control. [[English#^en-Q0720|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20haven%27t%20seen%20him%20for%20a%20long%20time.)
^en-Q0720-answer

**en-Q0721** — We will have to take off our shoes before going in.

हमे अंदर जाने से पहले जूते उतारने होंगे।

Expected form: **before**

Why: Time-frame control. [[English#^en-Q0721|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=We%20will%20have%20to%20take%20off%20our%20shoes%20before%20going%20in.)
^en-Q0721-answer

**en-Q0722** — We will have to take off our shoes before going in.

हमे अंदर जाने से पहले जूते उतारने होंगे।

Expected form: **before**

Why: Time-frame control. [[English#^en-Q0722|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=We%20will%20have%20to%20take%20off%20our%20shoes%20before%20going%20in.)
^en-Q0722-answer

**en-Q0723** — She has worn the same hat for a month.

उसने एक महीने से वही टोपी पहन रखी है.

Expected form: **for**

Why: Time-frame control. [[English#^en-Q0723|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=She%20has%20worn%20the%20same%20hat%20for%20a%20month.)
^en-Q0723-answer

**en-Q0724** — She has worn the same hat for a month.

उसने एक महीने से वही टोपी पहन रखी है.

Why: Time-frame control. [[English#^en-Q0724|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=She%20has%20worn%20the%20same%20hat%20for%20a%20month.)
^en-Q0724-answer

**en-Q0725** — He sent out the parcel the day before yesterday.

उसने पार्सल को परसों भेजा था।

Why: Time-frame control. [[English#^en-Q0725|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%20sent%20out%20the%20parcel%20the%20day%20before%20yesterday.)
^en-Q0725-answer

**en-Q0726** — He sent out the parcel the day before yesterday.

उसने पार्सल को परसों भेजा था।

Time expressions help establish an interval/reference point but do not select a tense mechanically. Ago normally locates a finished past time. Since marks a starting point; for a duration in relevant uses.

Why: Time-frame control. [[English#^en-Q0726|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%20sent%20out%20the%20parcel%20the%20day%20before%20yesterday.)
^en-Q0726-answer

**en-Q0727** — He took great care, yet he made a mistake.

उसने बहुत ध्यान लगाकर काम किया, पर फिर भी ग़लती कर बैठा।

Expected form: **yet**

Why: Time-frame control. [[English#^en-Q0727|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%20took%20great%20care%2C%20yet%20he%20made%20a%20mistake.)
^en-Q0727-answer

**en-Q0728** — He took great care, yet he made a mistake.

उसने बहुत ध्यान लगाकर काम किया, पर फिर भी ग़लती कर बैठा।

Expected form: **yet**

Why: Time-frame control. [[English#^en-Q0728|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%20took%20great%20care%2C%20yet%20he%20made%20a%20mistake.)
^en-Q0728-answer

**en-Q0729** — One thought driven home is better than three left on base.

एक क्रियान्वित विचार तीन अधूरे विचारों से कहीं बेहतर है।

Expected form: **better**

Why: Comparison and parallel structure. [[English#^en-Q0729|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=One%20thought%20driven%20home%20is%20better%20than%20three%20left%20on%20base.)
^en-Q0729-answer

**en-Q0730** — One thought driven home is better than three left on base.

एक क्रियान्वित विचार तीन अधूरे विचारों से कहीं बेहतर है।

Why: Comparison and parallel structure. [[English#^en-Q0730|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=One%20thought%20driven%20home%20is%20better%20than%20three%20left%20on%20base.)
^en-Q0730-answer

**en-Q0731** — The rich are not always happier than the poor.

अमीर हमेशा गरीबों से ज़्यादा ख़ुश नहीं होते।

Why: Comparison and parallel structure. [[English#^en-Q0731|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20rich%20are%20not%20always%20happier%20than%20the%20poor.)
^en-Q0731-answer

**en-Q0732** — The rich are not always happier than the poor.

अमीर हमेशा गरीबों से ज़्यादा ख़ुश नहीं होते।

A comparison needs a clear standard and comparable structures. As ... as expresses equality; more/less ... than inequality. Ellipsis can omit understood material but should not create ambiguity.

Why: Comparison and parallel structure. [[English#^en-Q0732|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20rich%20are%20not%20always%20happier%20than%20the%20poor.)
^en-Q0732-answer

**en-Q0733** — Tatoeba is currently unavailable. We are sorry for the inconvenience. You can check our blog or Twitter for more information.

तातोएबा इस वक़्त अनुपलब्ध है। असुविधा के लिए हमें खेद है। अधिक जानकारी के लिये आप हमारा ब्लॉग या ट्विटर देख सकते हैं।

Expected form: **more**

Why: Comparison and parallel structure. [[English#^en-Q0733|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Tatoeba%20is%20currently%20unavailable.%20We%20are%20sorry%20for%20the%20inconvenience.%20You%20can%20check%20our%20blog%20or%20Twitter%20for%20more%20information.)
^en-Q0733-answer

**en-Q0734** — Tatoeba is currently unavailable. We are sorry for the inconvenience. You can check our blog or Twitter for more information.

तातोएबा इस वक़्त अनुपलब्ध है। असुविधा के लिए हमें खेद है। अधिक जानकारी के लिये आप हमारा ब्लॉग या ट्विटर देख सकते हैं।

Expected form: **more**

Why: Comparison and parallel structure. [[English#^en-Q0734|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Tatoeba%20is%20currently%20unavailable.%20We%20are%20sorry%20for%20the%20inconvenience.%20You%20can%20check%20our%20blog%20or%20Twitter%20for%20more%20information.)
^en-Q0734-answer

**en-Q0735** — They say that Firefox is downloaded more than 8 million times a day.

कहते हैं के फ़ायरफ़ॉक्स प्रतिदिन ८ मिलियन से ज़्यादा बार डाउनलोड किया जाता है।

Expected form: **more**

Why: Comparison and parallel structure. [[English#^en-Q0735|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=They%20say%20that%20Firefox%20is%20downloaded%20more%20than%208%20million%20times%20a%20day.)
^en-Q0735-answer

**en-Q0736** — They say that Firefox is downloaded more than 8 million times a day.

कहते हैं के फ़ायरफ़ॉक्स प्रतिदिन ८ मिलियन से ज़्यादा बार डाउनलोड किया जाता है।

Why: Comparison and parallel structure. [[English#^en-Q0736|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=They%20say%20that%20Firefox%20is%20downloaded%20more%20than%208%20million%20times%20a%20day.)
^en-Q0736-answer

**en-Q0737** — I saw a red car and a white one. The red one was nicer looking than the white one.

मैंने एक लाल कार और सफ़ेद कार देखि. लाल कार सफ़ेद कार से दिखने में ज्यादा अछी थी.

Why: Comparison and parallel structure. [[English#^en-Q0737|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20saw%20a%20red%20car%20and%20a%20white%20one.%20The%20red%20one%20was%20nicer%20looking%20than%20the%20white%20one.)
^en-Q0737-answer

**en-Q0738** — I saw a red car and a white one. The red one was nicer looking than the white one.

मैंने एक लाल कार और सफ़ेद कार देखि. लाल कार सफ़ेद कार से दिखने में ज्यादा अछी थी.

A comparison needs a clear standard and comparable structures. As ... as expresses equality; more/less ... than inequality. Ellipsis can omit understood material but should not create ambiguity.

Why: Comparison and parallel structure. [[English#^en-Q0738|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20saw%20a%20red%20car%20and%20a%20white%20one.%20The%20red%20one%20was%20nicer%20looking%20than%20the%20white%20one.)
^en-Q0738-answer

**en-Q0739** — For some reason I feel more alive at night.

पता नहीं क्यों मुझे रात में ज़्यादा ज़िन्दा महसूस होता है।

Expected form: **more**

Why: Comparison and parallel structure. [[English#^en-Q0739|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=For%20some%20reason%20I%20feel%20more%20alive%20at%20night.)
^en-Q0739-answer

**en-Q0740** — For some reason I feel more alive at night.

पता नहीं क्यों मुझे रात में ज़्यादा ज़िन्दा महसूस होता है।

Expected form: **more**

Why: Comparison and parallel structure. [[English#^en-Q0740|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=For%20some%20reason%20I%20feel%20more%20alive%20at%20night.)
^en-Q0740-answer

**en-Q0741** — I didn't want to spend any more time in jail.

मैं जेल में और वक्त नहीं बिताना चाहता था।

Expected form: **more**

Why: Comparison and parallel structure. [[English#^en-Q0741|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20didn%27t%20want%20to%20spend%20any%20more%20time%20in%20jail.)
^en-Q0741-answer

**en-Q0742** — I didn't want to spend any more time in jail.

मैं जेल में और वक्त नहीं बिताना चाहता था।

Why: Comparison and parallel structure. [[English#^en-Q0742|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20didn%27t%20want%20to%20spend%20any%20more%20time%20in%20jail.)
^en-Q0742-answer

**en-Q0743** — You are allowed to check out not more than five books at a time.

आपको एक समय में केवल पांच पुस्तकों को ले जाने की इजाज़त है.

Why: Comparison and parallel structure. [[English#^en-Q0743|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=You%20are%20allowed%20to%20check%20out%20not%20more%20than%20five%20books%20at%20a%20time.)
^en-Q0743-answer

**en-Q0744** — You are allowed to check out not more than five books at a time.

आपको एक समय में केवल पांच पुस्तकों को ले जाने की इजाज़त है.

A comparison needs a clear standard and comparable structures. As ... as expresses equality; more/less ... than inequality. Ellipsis can omit understood material but should not create ambiguity.

Why: Comparison and parallel structure. [[English#^en-Q0744|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=You%20are%20allowed%20to%20check%20out%20not%20more%20than%20five%20books%20at%20a%20time.)
^en-Q0744-answer

**en-Q0745** — Can I extend my stay one more night?

मैं एक रात और रह सकता हूँ क्या?

Expected form: **more**

Why: Comparison and parallel structure. [[English#^en-Q0745|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Can%20I%20extend%20my%20stay%20one%20more%20night%3F)
^en-Q0745-answer

**en-Q0746** — Can I extend my stay one more night?

मैं एक रात और रह सकता हूँ क्या?

Expected form: **more**

Why: Comparison and parallel structure. [[English#^en-Q0746|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Can%20I%20extend%20my%20stay%20one%20more%20night%3F)
^en-Q0746-answer

**en-Q0747** — I guess I'm not as smart as you.

मुझे लगता है मैं आपकी तरह चुस्त नहीं हूँ.

Expected form: **as**

Why: Comparison and parallel structure. [[English#^en-Q0747|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20guess%20I%27m%20not%20as%20smart%20as%20you.)
^en-Q0747-answer

**en-Q0748** — I guess I'm not as smart as you.

मुझे लगता है मैं आपकी तरह चुस्त नहीं हूँ.

Why: Comparison and parallel structure. [[English#^en-Q0748|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20guess%20I%27m%20not%20as%20smart%20as%20you.)
^en-Q0748-answer

**en-Q0749** — The villagers regarded the stranger as their enemy.

गांववालें अजनबी को अपना दुश्मन मानते थे।

Why: Comparison and parallel structure. [[English#^en-Q0749|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20villagers%20regarded%20the%20stranger%20as%20their%20enemy.)
^en-Q0749-answer

**en-Q0750** — The villagers regarded the stranger as their enemy.

गांववालें अजनबी को अपना दुश्मन मानते थे।

A comparison needs a clear standard and comparable structures. As ... as expresses equality; more/less ... than inequality. Ellipsis can omit understood material but should not create ambiguity.

Why: Comparison and parallel structure. [[English#^en-Q0750|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20villagers%20regarded%20the%20stranger%20as%20their%20enemy.)
^en-Q0750-answer


### Answers 751–800

**en-Q0751** — Natural mineral water contains calcium, magnesium, sodium, potassium as well as nitrate.

प्राकृतिक खनिज पानी में समाहित है चूर्णातु, भ्राजातु, क्षारातु, दहातु, व भूयीयों भी।

Expected form: **as**

Why: Comparison and parallel structure. [[English#^en-Q0751|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Natural%20mineral%20water%20contains%20calcium%2C%20magnesium%2C%20sodium%2C%20potassium%20as%20well%20as%20nitrate.)
^en-Q0751-answer

**en-Q0752** — Natural mineral water contains calcium, magnesium, sodium, potassium as well as nitrate.

प्राकृतिक खनिज पानी में समाहित है चूर्णातु, भ्राजातु, क्षारातु, दहातु, व भूयीयों भी।

Expected form: **as**

Why: Comparison and parallel structure. [[English#^en-Q0752|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Natural%20mineral%20water%20contains%20calcium%2C%20magnesium%2C%20sodium%2C%20potassium%20as%20well%20as%20nitrate.)
^en-Q0752-answer

**en-Q0753** — I want to get to know you better.

मैं तुम्हे और अच्छी तरह से जानना चाहता हूं।

Expected form: **better**

Why: Comparison and parallel structure. [[English#^en-Q0753|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20want%20to%20get%20to%20know%20you%20better.)
^en-Q0753-answer

**en-Q0754** — I want to get to know you better.

मैं तुम्हे और अच्छी तरह से जानना चाहता हूं।

Why: Comparison and parallel structure. [[English#^en-Q0754|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20want%20to%20get%20to%20know%20you%20better.)
^en-Q0754-answer

**en-Q0755** — As a light goes out, so a man dies.

जैसे दीपक बुझता है, वैसे ही आदमी मरता है।

Why: Comparison and parallel structure. [[English#^en-Q0755|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=As%20a%20light%20goes%20out%2C%20so%20a%20man%20dies.)
^en-Q0755-answer

**en-Q0756** — As a light goes out, so a man dies.

जैसे दीपक बुझता है, वैसे ही आदमी मरता है।

A comparison needs a clear standard and comparable structures. As ... as expresses equality; more/less ... than inequality. Ellipsis can omit understood material but should not create ambiguity.

Why: Comparison and parallel structure. [[English#^en-Q0756|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=As%20a%20light%20goes%20out%2C%20so%20a%20man%20dies.)
^en-Q0756-answer

**en-Q0757** — He earns more money than he can spend.

वह ज़रूरत से ज़्यादा पैसे कमाता है।

Expected form: **more**

Why: Comparison and parallel structure. [[English#^en-Q0757|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%20earns%20more%20money%20than%20he%20can%20spend.)
^en-Q0757-answer

**en-Q0758** — He earns more money than he can spend.

वह ज़रूरत से ज़्यादा पैसे कमाता है।

Expected form: **more**

Why: Comparison and parallel structure. [[English#^en-Q0758|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%20earns%20more%20money%20than%20he%20can%20spend.)
^en-Q0758-answer

**en-Q0759** — The older you are, the more difficult it is to learn a language.

तुम्हारी उम्र जितनी बड़ी होती है, तुम्हारे लिए कोई भाषा सीखना उतना ही कठिन होता है।

Expected form: **more**

Why: Comparison and parallel structure. [[English#^en-Q0759|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20older%20you%20are%2C%20the%20more%20difficult%20it%20is%20to%20learn%20a%20language.)
^en-Q0759-answer

**en-Q0760** — The older you are, the more difficult it is to learn a language.

तुम्हारी उम्र जितनी बड़ी होती है, तुम्हारे लिए कोई भाषा सीखना उतना ही कठिन होता है।

Why: Comparison and parallel structure. [[English#^en-Q0760|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20older%20you%20are%2C%20the%20more%20difficult%20it%20is%20to%20learn%20a%20language.)
^en-Q0760-answer

**en-Q0761** — I wish I had more time to talk with you.

काश मेरे पास और समय होता तुम्हारे साथ बात करने के लिए।

Why: Comparison and parallel structure. [[English#^en-Q0761|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20wish%20I%20had%20more%20time%20to%20talk%20with%20you.)
^en-Q0761-answer

**en-Q0762** — I wish I had more time to talk with you.

काश मेरे पास और समय होता तुम्हारे साथ बात करने के लिए।

A comparison needs a clear standard and comparable structures. As ... as expresses equality; more/less ... than inequality. Ellipsis can omit understood material but should not create ambiguity.

Why: Comparison and parallel structure. [[English#^en-Q0762|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20wish%20I%20had%20more%20time%20to%20talk%20with%20you.)
^en-Q0762-answer

**en-Q0763** — I will help you as far as I can.

मैं तुम्हारा जितना हो सकेगा उतना मदद करूँगा।

Expected form: **as**

Why: Comparison and parallel structure. [[English#^en-Q0763|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20will%20help%20you%20as%20far%20as%20I%20can.)
^en-Q0763-answer

**en-Q0764** — I will help you as far as I can.

मैं तुम्हारा जितना हो सकेगा उतना मदद करूँगा।

Expected form: **as**

Why: Comparison and parallel structure. [[English#^en-Q0764|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20will%20help%20you%20as%20far%20as%20I%20can.)
^en-Q0764-answer

**en-Q0765** — I make a lot more money than he does.

मैं उससे बहुत ज़्यादा कमाता हूँ।

Expected form: **more**

Why: Comparison and parallel structure. [[English#^en-Q0765|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20make%20a%20lot%20more%20money%20than%20he%20does.)
^en-Q0765-answer

**en-Q0766** — I make a lot more money than he does.

मैं उससे बहुत ज़्यादा कमाता हूँ।

Why: Comparison and parallel structure. [[English#^en-Q0766|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20make%20a%20lot%20more%20money%20than%20he%20does.)
^en-Q0766-answer

**en-Q0767** — When in Rome, do as the Romans do.

जैसा देस, वैसा भेस।

Why: Comparison and parallel structure. [[English#^en-Q0767|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=When%20in%20Rome%2C%20do%20as%20the%20Romans%20do.)
^en-Q0767-answer

**en-Q0768** — When in Rome, do as the Romans do.

जैसा देस, वैसा भेस।

A comparison needs a clear standard and comparable structures. As ... as expresses equality; more/less ... than inequality. Ellipsis can omit understood material but should not create ambiguity.

Why: Comparison and parallel structure. [[English#^en-Q0768|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=When%20in%20Rome%2C%20do%20as%20the%20Romans%20do.)
^en-Q0768-answer

**en-Q0769** — In Japan there aren't any lakes bigger than Lake Biwa.

जापान में बीवा झील से बड़ी और कोई झील नहीं है।

Expected form: **than**

Why: Comparison and parallel structure. [[English#^en-Q0769|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=In%20Japan%20there%20aren%27t%20any%20lakes%20bigger%20than%20Lake%20Biwa.)
^en-Q0769-answer

**en-Q0770** — In Japan there aren't any lakes bigger than Lake Biwa.

जापान में बीवा झील से बड़ी और कोई झील नहीं है।

Expected form: **than**

Why: Comparison and parallel structure. [[English#^en-Q0770|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=In%20Japan%20there%20aren%27t%20any%20lakes%20bigger%20than%20Lake%20Biwa.)
^en-Q0770-answer

**en-Q0771** — It looks like rain. You had better take an umbrella with you.

लगता है कि बारिश होगी। तुम्हे छाता लेकर जाना चाहिए।

Expected form: **better**

Why: Comparison and parallel structure. [[English#^en-Q0771|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=It%20looks%20like%20rain.%20You%20had%20better%20take%20an%20umbrella%20with%20you.)
^en-Q0771-answer

**en-Q0772** — It looks like rain. You had better take an umbrella with you.

लगता है कि बारिश होगी। तुम्हे छाता लेकर जाना चाहिए।

Why: Comparison and parallel structure. [[English#^en-Q0772|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=It%20looks%20like%20rain.%20You%20had%20better%20take%20an%20umbrella%20with%20you.)
^en-Q0772-answer

**en-Q0773** — I had a part-time job as a hotel maid, but I didn't like it very much.

में होटेल मे पार्ट-टाइम नौकरानी थी, पर मुज़े वो पसंद नहीं था

Why: Comparison and parallel structure. [[English#^en-Q0773|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20had%20a%20part-time%20job%20as%20a%20hotel%20maid%2C%20but%20I%20didn%27t%20like%20it%20very%20much.)
^en-Q0773-answer

**en-Q0774** — I had a part-time job as a hotel maid, but I didn't like it very much.

में होटेल मे पार्ट-टाइम नौकरानी थी, पर मुज़े वो पसंद नहीं था

A comparison needs a clear standard and comparable structures. As ... as expresses equality; more/less ... than inequality. Ellipsis can omit understood material but should not create ambiguity.

Why: Comparison and parallel structure. [[English#^en-Q0774|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20had%20a%20part-time%20job%20as%20a%20hotel%20maid%2C%20but%20I%20didn%27t%20like%20it%20very%20much.)
^en-Q0774-answer

**en-Q0775** — Saudi Arabia is called "Al-Mamlakah Al-‘Arabiyyah As-Sa‘ūdiyyah" in Arabic.

सऊदी अरब को अरबी में "अल-मामलकह अल-अरबिय्यह अस-सऊदिय्याह" कहते हैं।

Expected form: **As**

Why: Comparison and parallel structure. [[English#^en-Q0775|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Saudi%20Arabia%20is%20called%20%22Al-Mamlakah%20Al-%E2%80%98Arabiyyah%20As-Sa%E2%80%98%C5%ABdiyyah%22%20in%20Arabic.)
^en-Q0775-answer

**en-Q0776** — Saudi Arabia is called "Al-Mamlakah Al-‘Arabiyyah As-Sa‘ūdiyyah" in Arabic.

सऊदी अरब को अरबी में "अल-मामलकह अल-अरबिय्यह अस-सऊदिय्याह" कहते हैं।

Expected form: **As**

Why: Comparison and parallel structure. [[English#^en-Q0776|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Saudi%20Arabia%20is%20called%20%22Al-Mamlakah%20Al-%E2%80%98Arabiyyah%20As-Sa%E2%80%98%C5%ABdiyyah%22%20in%20Arabic.)
^en-Q0776-answer

**en-Q0777** — As he was an honest man, I employed him.

वह ईमानदार इनसान था, इसलिए मैंने उसे नौकरी पर रख लिया।

Expected form: **As**

Why: Comparison and parallel structure. [[English#^en-Q0777|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=As%20he%20was%20an%20honest%20man%2C%20I%20employed%20him.)
^en-Q0777-answer

**en-Q0778** — As he was an honest man, I employed him.

वह ईमानदार इनसान था, इसलिए मैंने उसे नौकरी पर रख लिया।

Why: Comparison and parallel structure. [[English#^en-Q0778|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=As%20he%20was%20an%20honest%20man%2C%20I%20employed%20him.)
^en-Q0778-answer

**en-Q0779** — The doctor told her that she should take a rest.

डॉक्टर ने उससे कहा कि उसे आराम लेना चाहिए।

Why: Reported speech and stance. [[English#^en-Q0779|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20doctor%20told%20her%20that%20she%20should%20take%20a%20rest.)
^en-Q0779-answer

**en-Q0780** — The doctor told her that she should take a rest.

डॉक्टर ने उससे कहा कि उसे आराम लेना चाहिए।

Reporting verbs encode stance and govern distinct complements. Say and tell differ in object requirements; suggest does not accept every pattern that advise accepts. Reporting a claim is not endorsing it.

Why: Reported speech and stance. [[English#^en-Q0780|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20doctor%20told%20her%20that%20she%20should%20take%20a%20rest.)
^en-Q0780-answer

**en-Q0781** — She told me that she wanted a pet dog.

उसने मुझसे कहा कि उसे कुत्ता पालने का मन था।

Expected form: **told**

Why: Reported speech and stance. [[English#^en-Q0781|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=She%20told%20me%20that%20she%20wanted%20a%20pet%20dog.)
^en-Q0781-answer

**en-Q0782** — She told me that she wanted a pet dog.

उसने मुझसे कहा कि उसे कुत्ता पालने का मन था।

Expected form: **told**

Why: Reported speech and stance. [[English#^en-Q0782|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=She%20told%20me%20that%20she%20wanted%20a%20pet%20dog.)
^en-Q0782-answer

**en-Q0783** — Aksai Chin is claimed by India, but controlled by China.

अक्साई चिन पर भारत का दावा है, मगर वह चीन के नियंत्रण में है।

Expected form: **claimed**

Why: Reported speech and stance. [[English#^en-Q0783|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Aksai%20Chin%20is%20claimed%20by%20India%2C%20but%20controlled%20by%20China.)
^en-Q0783-answer

**en-Q0784** — Aksai Chin is claimed by India, but controlled by China.

अक्साई चिन पर भारत का दावा है, मगर वह चीन के नियंत्रण में है।

Why: Reported speech and stance. [[English#^en-Q0784|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Aksai%20Chin%20is%20claimed%20by%20India%2C%20but%20controlled%20by%20China.)
^en-Q0784-answer

**en-Q0785** — I did it the way he told me to.

उसने जैसे बताया था मैंने वैसे किया।

Why: Reported speech and stance. [[English#^en-Q0785|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20did%20it%20the%20way%20he%20told%20me%20to.)
^en-Q0785-answer

**en-Q0786** — I did it the way he told me to.

उसने जैसे बताया था मैंने वैसे किया।

Reporting verbs encode stance and govern distinct complements. Say and tell differ in object requirements; suggest does not accept every pattern that advise accepts. Reporting a claim is not endorsing it.

Why: Reported speech and stance. [[English#^en-Q0786|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20did%20it%20the%20way%20he%20told%20me%20to.)
^en-Q0786-answer

**en-Q0787** — Do you think that Tom told the truth?

तुम्हारे विचार में क्या टॉम ने सच कहा?

Expected form: **told**

Why: Reported speech and stance. [[English#^en-Q0787|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Do%20you%20think%20that%20Tom%20told%20the%20truth%3F)
^en-Q0787-answer

**en-Q0788** — Do you think that Tom told the truth?

तुम्हारे विचार में क्या टॉम ने सच कहा?

Expected form: **told**

Why: Reported speech and stance. [[English#^en-Q0788|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Do%20you%20think%20that%20Tom%20told%20the%20truth%3F)
^en-Q0788-answer

**en-Q0789** — He said he would write to me, but he hasn't.

उसने कहा था कि वह मुझे चिट्ठी लिखेगा, पर उसने अभी तक एक भी चिट्ठी नहीं भेजी है।

Expected form: **said**

Why: Reported speech and stance. [[English#^en-Q0789|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%20said%20he%20would%20write%20to%20me%2C%20but%20he%20hasn%27t.)
^en-Q0789-answer

**en-Q0790** — He said he would write to me, but he hasn't.

उसने कहा था कि वह मुझे चिट्ठी लिखेगा, पर उसने अभी तक एक भी चिट्ठी नहीं भेजी है।

Why: Reported speech and stance. [[English#^en-Q0790|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%20said%20he%20would%20write%20to%20me%2C%20but%20he%20hasn%27t.)
^en-Q0790-answer

**en-Q0791** — Columbus argued that he could reach India by going west.

कोलम्बस ने सोचा कि वह पश्चिम दिशा में जाकर भारत पहुँच सकता था।

Why: Reported speech and stance. [[English#^en-Q0791|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Columbus%20argued%20that%20he%20could%20reach%20India%20by%20going%20west.)
^en-Q0791-answer

**en-Q0792** — Columbus argued that he could reach India by going west.

कोलम्बस ने सोचा कि वह पश्चिम दिशा में जाकर भारत पहुँच सकता था।

Reporting verbs encode stance and govern distinct complements. Say and tell differ in object requirements; suggest does not accept every pattern that advise accepts. Reporting a claim is not endorsing it.

Why: Reported speech and stance. [[English#^en-Q0792|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Columbus%20argued%20that%20he%20could%20reach%20India%20by%20going%20west.)
^en-Q0792-answer

**en-Q0793** — Kenji told his friends a story about his trip to India.

केनजी ने उसके दोस्तों को उसके भारत के सफ़र की कहानी सुनाई।

Expected form: **told**

Why: Reported speech and stance. [[English#^en-Q0793|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Kenji%20told%20his%20friends%20a%20story%20about%20his%20trip%20to%20India.)
^en-Q0793-answer

**en-Q0794** — Kenji told his friends a story about his trip to India.

केनजी ने उसके दोस्तों को उसके भारत के सफ़र की कहानी सुनाई।

Expected form: **told**

Why: Reported speech and stance. [[English#^en-Q0794|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Kenji%20told%20his%20friends%20a%20story%20about%20his%20trip%20to%20India.)
^en-Q0794-answer

**en-Q0795** — My father told me not to read books in bed.

मेरे पिता ने मुझसे बिस्तर में किताबें पढ़ने से मना किया।

Expected form: **told**

Why: Reported speech and stance. [[English#^en-Q0795|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=My%20father%20told%20me%20not%20to%20read%20books%20in%20bed.)
^en-Q0795-answer

**en-Q0796** — My father told me not to read books in bed.

मेरे पिता ने मुझसे बिस्तर में किताबें पढ़ने से मना किया।

Why: Reported speech and stance. [[English#^en-Q0796|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=My%20father%20told%20me%20not%20to%20read%20books%20in%20bed.)
^en-Q0796-answer

**en-Q0797** — The doctor told him to cut down on smoking.

डॉक्टर ने उसे सिगरेट कम पीने को कहा।

Why: Reported speech and stance. [[English#^en-Q0797|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20doctor%20told%20him%20to%20cut%20down%20on%20smoking.)
^en-Q0797-answer

**en-Q0798** — The doctor told him to cut down on smoking.

डॉक्टर ने उसे सिगरेट कम पीने को कहा।

Reporting verbs encode stance and govern distinct complements. Say and tell differ in object requirements; suggest does not accept every pattern that advise accepts. Reporting a claim is not endorsing it.

Why: Reported speech and stance. [[English#^en-Q0798|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20doctor%20told%20him%20to%20cut%20down%20on%20smoking.)
^en-Q0798-answer

**en-Q0799** — He said he would see me the next day.

उसने कहा था कि वह मुझसे अगले दिन मिलेगा।

Expected form: **said**

Why: Reported speech and stance. [[English#^en-Q0799|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%20said%20he%20would%20see%20me%20the%20next%20day.)
^en-Q0799-answer

**en-Q0800** — He said he would see me the next day.

उसने कहा था कि वह मुझसे अगले दिन मिलेगा।

Expected form: **said**

Why: Reported speech and stance. [[English#^en-Q0800|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%20said%20he%20would%20see%20me%20the%20next%20day.)
^en-Q0800-answer


### Answers 801–850

**en-Q0801** — My companion said that she was too tired to walk, let alone run.

मेरी साथी ने कहा भागना तो छोड़ो, वह चलने ले किये भी थकी हुई है.

Expected form: **said**

Why: Reported speech and stance. [[English#^en-Q0801|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=My%20companion%20said%20that%20she%20was%20too%20tired%20to%20walk%2C%20let%20alone%20run.)
^en-Q0801-answer

**en-Q0802** — My companion said that she was too tired to walk, let alone run.

मेरी साथी ने कहा भागना तो छोड़ो, वह चलने ले किये भी थकी हुई है.

Why: Reported speech and stance. [[English#^en-Q0802|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=My%20companion%20said%20that%20she%20was%20too%20tired%20to%20walk%2C%20let%20alone%20run.)
^en-Q0802-answer

**en-Q0803** — My mother told me to do a careless job of it.

मेरी माँ ने मुझसे घास काटने के लिए कहा।

Why: Reported speech and stance. [[English#^en-Q0803|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=My%20mother%20told%20me%20to%20do%20a%20careless%20job%20of%20it.)
^en-Q0803-answer

**en-Q0804** — My mother told me to do a careless job of it.

मेरी माँ ने मुझसे घास काटने के लिए कहा।

Reporting verbs encode stance and govern distinct complements. Say and tell differ in object requirements; suggest does not accept every pattern that advise accepts. Reporting a claim is not endorsing it.

Why: Reported speech and stance. [[English#^en-Q0804|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=My%20mother%20told%20me%20to%20do%20a%20careless%20job%20of%20it.)
^en-Q0804-answer

**en-Q0805** — He is said to know a lot about Spain.

कहते है वह स्पेन के बारे में बहुत कुछ जानता है।

Expected form: **said**

Why: Reported speech and stance. [[English#^en-Q0805|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%20is%20said%20to%20know%20a%20lot%20about%20Spain.)
^en-Q0805-answer

**en-Q0806** — He is said to know a lot about Spain.

कहते है वह स्पेन के बारे में बहुत कुछ जानता है।

Expected form: **said**

Why: Reported speech and stance. [[English#^en-Q0806|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%20is%20said%20to%20know%20a%20lot%20about%20Spain.)
^en-Q0806-answer

**en-Q0807** — They said Anderson and his men must leave the fort.

उन्होंने कहां के अॅन्डर्सन और उसके आदमियों को गढ़ छोड़ना पड़ेगा।

Expected form: **said**

Why: Reported speech and stance. [[English#^en-Q0807|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=They%20said%20Anderson%20and%20his%20men%20must%20leave%20the%20fort.)
^en-Q0807-answer

**en-Q0808** — They said Anderson and his men must leave the fort.

उन्होंने कहां के अॅन्डर्सन और उसके आदमियों को गढ़ छोड़ना पड़ेगा।

Why: Reported speech and stance. [[English#^en-Q0808|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=They%20said%20Anderson%20and%20his%20men%20must%20leave%20the%20fort.)
^en-Q0808-answer

**en-Q0809** — He said the words in a very small voice.

उसने वह बात बहुत हल्की आवाज़ में कही।

Why: Reported speech and stance. [[English#^en-Q0809|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%20said%20the%20words%20in%20a%20very%20small%20voice.)
^en-Q0809-answer

**en-Q0810** — He said the words in a very small voice.

उसने वह बात बहुत हल्की आवाज़ में कही।

Reporting verbs encode stance and govern distinct complements. Say and tell differ in object requirements; suggest does not accept every pattern that advise accepts. Reporting a claim is not endorsing it.

Why: Reported speech and stance. [[English#^en-Q0810|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%20said%20the%20words%20in%20a%20very%20small%20voice.)
^en-Q0810-answer

**en-Q0811** — Take back what you said about me being stingy.

जो तुमने मेरे कंजूस होने के बारे में कहा था, उस बात को वापस लो।

Expected form: **said**

Why: Reported speech and stance. [[English#^en-Q0811|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Take%20back%20what%20you%20said%20about%20me%20being%20stingy.)
^en-Q0811-answer

**en-Q0812** — Take back what you said about me being stingy.

जो तुमने मेरे कंजूस होने के बारे में कहा था, उस बात को वापस लो।

Expected form: **said**

Why: Reported speech and stance. [[English#^en-Q0812|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Take%20back%20what%20you%20said%20about%20me%20being%20stingy.)
^en-Q0812-answer

**en-Q0813** — The father told his son that his studies had been completed then so he should go outside and work instead of getting food at home for free.

पिता ने अपने बेटे से कहा कि अब तुम्हारी पढ़ाई पूरी हो गई है। बाहर जाकर नौकरी करो, घर में मुफ्त की रोटियां मत तोड़ो।

Expected form: **told**

Why: Reported speech and stance. [[English#^en-Q0813|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20father%20told%20his%20son%20that%20his%20studies%20had%20been%20completed%20then%20so%20he%20should%20go%20outside%20and%20work%20instead%20of%20getting%20food%20at%20home%20for%20free.)
^en-Q0813-answer

**en-Q0814** — The father told his son that his studies had been completed then so he should go outside and work instead of getting food at home for free.

पिता ने अपने बेटे से कहा कि अब तुम्हारी पढ़ाई पूरी हो गई है। बाहर जाकर नौकरी करो, घर में मुफ्त की रोटियां मत तोड़ो।

Why: Reported speech and stance. [[English#^en-Q0814|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20father%20told%20his%20son%20that%20his%20studies%20had%20been%20completed%20then%20so%20he%20should%20go%20outside%20and%20work%20instead%20of%20getting%20food%20at%20home%20for%20free.)
^en-Q0814-answer

**en-Q0815** — He did it as he had been told.

उसने वैसा करा जैसे उसे बताया गया था।

Why: Reported speech and stance. [[English#^en-Q0815|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%20did%20it%20as%20he%20had%20been%20told.)
^en-Q0815-answer

**en-Q0816** — He did it as he had been told.

उसने वैसा करा जैसे उसे बताया गया था।

Reporting verbs encode stance and govern distinct complements. Say and tell differ in object requirements; suggest does not accept every pattern that advise accepts. Reporting a claim is not endorsing it.

Why: Reported speech and stance. [[English#^en-Q0816|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%20did%20it%20as%20he%20had%20been%20told.)
^en-Q0816-answer

**en-Q0817** — This is the book about which I told you.

यह वह किताब है जिसके बारे में मैंने तुम्हें बताया था।

Expected form: **told**

Why: Reported speech and stance. [[English#^en-Q0817|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=This%20is%20the%20book%20about%20which%20I%20told%20you.)
^en-Q0817-answer

**en-Q0818** — This is the book about which I told you.

यह वह किताब है जिसके बारे में मैंने तुम्हें बताया था।

Expected form: **told**

Why: Reported speech and stance. [[English#^en-Q0818|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=This%20is%20the%20book%20about%20which%20I%20told%20you.)
^en-Q0818-answer

**en-Q0819** — When he would not give them higher pay, they went on strike.

जब उसने उनके वेतन बढ़ाने से इनकार कर दिया, उन्होंने हड़ताल कर दी।

Expected form: **would**

Why: Hedging and professional modality. [[English#^en-Q0819|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=When%20he%20would%20not%20give%20them%20higher%20pay%2C%20they%20went%20on%20strike.)
^en-Q0819-answer

**en-Q0820** — When he would not give them higher pay, they went on strike.

जब उसने उनके वेतन बढ़ाने से इनकार कर दिया, उन्होंने हड़ताल कर दी।

Why: Hedging and professional modality. [[English#^en-Q0820|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=When%20he%20would%20not%20give%20them%20higher%20pay%2C%20they%20went%20on%20strike.)
^en-Q0820-answer

**en-Q0821** — To investigate the incident would take us at least three weeks.

हमको इस घटना की तहकीकात करने में कम-से-कम तीन हफ़्ते लगेंगे।

Why: Hedging and professional modality. [[English#^en-Q0821|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=To%20investigate%20the%20incident%20would%20take%20us%20at%20least%20three%20weeks.)
^en-Q0821-answer

**en-Q0822** — To investigate the incident would take us at least three weeks.

हमको इस घटना की तहकीकात करने में कम-से-कम तीन हफ़्ते लगेंगे।

Hedges express different strengths and types of commitment. Could you is often a request, not a question about physical ability. Pair a precise request with a practical reason; avoid stacking several courtesy formulas.

Why: Hedging and professional modality. [[English#^en-Q0822|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=To%20investigate%20the%20incident%20would%20take%20us%20at%20least%20three%20weeks.)
^en-Q0822-answer

**en-Q0823** — You should not speak of others behind their backs.

तुम्हे लोगों की पीठ-पीछे बात नहीं करनी चाहिए।

Expected form: **should**

Why: Hedging and professional modality. [[English#^en-Q0823|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=You%20should%20not%20speak%20of%20others%20behind%20their%20backs.)
^en-Q0823-answer

**en-Q0824** — You should not speak of others behind their backs.

तुम्हे लोगों की पीठ-पीछे बात नहीं करनी चाहिए।

Expected form: **should**

Why: Hedging and professional modality. [[English#^en-Q0824|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=You%20should%20not%20speak%20of%20others%20behind%20their%20backs.)
^en-Q0824-answer

**en-Q0825** — You can't have everything. Where would you put it?

आप को सब कुछ नहीं मिल सकता। आप इसे रखेंगे कहां?

Expected form: **would**

Why: Hedging and professional modality. [[English#^en-Q0825|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=You%20can%27t%20have%20everything.%20Where%20would%20you%20put%20it%3F)
^en-Q0825-answer

**en-Q0826** — You can't have everything. Where would you put it?

आप को सब कुछ नहीं मिल सकता। आप इसे रखेंगे कहां?

Why: Hedging and professional modality. [[English#^en-Q0826|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=You%20can%27t%20have%20everything.%20Where%20would%20you%20put%20it%3F)
^en-Q0826-answer

**en-Q0827** — You should not speak ill of others behind their backs.

तुमको लोगों कि पीठ के पीछे उनकी बुराई नहीं करनी चाहिए।

Why: Hedging and professional modality. [[English#^en-Q0827|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=You%20should%20not%20speak%20ill%20of%20others%20behind%20their%20backs.)
^en-Q0827-answer

**en-Q0828** — You should not speak ill of others behind their backs.

तुमको लोगों कि पीठ के पीछे उनकी बुराई नहीं करनी चाहिए।

Hedges express different strengths and types of commitment. Could you is often a request, not a question about physical ability. Pair a precise request with a practical reason; avoid stacking several courtesy formulas.

Why: Hedging and professional modality. [[English#^en-Q0828|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=You%20should%20not%20speak%20ill%20of%20others%20behind%20their%20backs.)
^en-Q0828-answer

**en-Q0829** — The king ordered that the prisoner should be set free.

राजा ने हुक़्म दिया कि क़ैदी को रिहा कर दिया जाए।

Expected form: **should**

Why: Hedging and professional modality. [[English#^en-Q0829|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20king%20ordered%20that%20the%20prisoner%20should%20be%20set%20free.)
^en-Q0829-answer

**en-Q0830** — The king ordered that the prisoner should be set free.

राजा ने हुक़्म दिया कि क़ैदी को रिहा कर दिया जाए।

Expected form: **should**

Why: Hedging and professional modality. [[English#^en-Q0830|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20king%20ordered%20that%20the%20prisoner%20should%20be%20set%20free.)
^en-Q0830-answer

**en-Q0831** — Russia should give the Kuril Islands back to Japan.

रूस ने कुरील द्वीप जापान को लौटाने चाहिए।

Expected form: **should**

Why: Hedging and professional modality. [[English#^en-Q0831|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Russia%20should%20give%20the%20Kuril%20Islands%20back%20to%20Japan.)
^en-Q0831-answer

**en-Q0832** — Russia should give the Kuril Islands back to Japan.

रूस ने कुरील द्वीप जापान को लौटाने चाहिए।

Why: Hedging and professional modality. [[English#^en-Q0832|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Russia%20should%20give%20the%20Kuril%20Islands%20back%20to%20Japan.)
^en-Q0832-answer

**en-Q0833** — A gentleman would not spit on the street.

कोई भी सुशील इनसान सड़क पर थूकेगा नहीं।

Why: Hedging and professional modality. [[English#^en-Q0833|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=A%20gentleman%20would%20not%20spit%20on%20the%20street.)
^en-Q0833-answer

**en-Q0834** — A gentleman would not spit on the street.

कोई भी सुशील इनसान सड़क पर थूकेगा नहीं।

Hedges express different strengths and types of commitment. Could you is often a request, not a question about physical ability. Pair a precise request with a practical reason; avoid stacking several courtesy formulas.

Why: Hedging and professional modality. [[English#^en-Q0834|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=A%20gentleman%20would%20not%20spit%20on%20the%20street.)
^en-Q0834-answer

**en-Q0835** — Where do you think we should pitch our tent?

आपके विचार में हमें अपना तम्बू कहाँ गाड़ना चाहिए?

Expected form: **should**

Why: Hedging and professional modality. [[English#^en-Q0835|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Where%20do%20you%20think%20we%20should%20pitch%20our%20tent%3F)
^en-Q0835-answer

**en-Q0836** — Where do you think we should pitch our tent?

आपके विचार में हमें अपना तम्बू कहाँ गाड़ना चाहिए?

Expected form: **should**

Why: Hedging and professional modality. [[English#^en-Q0836|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Where%20do%20you%20think%20we%20should%20pitch%20our%20tent%3F)
^en-Q0836-answer

**en-Q0837** — What should you do to decrease your debt?

अपने ऋण को कम करने के लिये क्या करना चाहिए?

Expected form: **should**

Why: Hedging and professional modality. [[English#^en-Q0837|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=What%20should%20you%20do%20to%20decrease%20your%20debt%3F)
^en-Q0837-answer

**en-Q0838** — What should you do to decrease your debt?

अपने ऋण को कम करने के लिये क्या करना चाहिए?

Why: Hedging and professional modality. [[English#^en-Q0838|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=What%20should%20you%20do%20to%20decrease%20your%20debt%3F)
^en-Q0838-answer

**en-Q0839** — You should work hard while you are young.

जवान हो तब तक तुम्हें कड़ी मेहनत से काम करना चाहिए।

Why: Hedging and professional modality. [[English#^en-Q0839|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=You%20should%20work%20hard%20while%20you%20are%20young.)
^en-Q0839-answer

**en-Q0840** — You should work hard while you are young.

जवान हो तब तक तुम्हें कड़ी मेहनत से काम करना चाहिए।

Hedges express different strengths and types of commitment. Could you is often a request, not a question about physical ability. Pair a precise request with a practical reason; avoid stacking several courtesy formulas.

Why: Hedging and professional modality. [[English#^en-Q0840|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=You%20should%20work%20hard%20while%20you%20are%20young.)
^en-Q0840-answer

**en-Q0841** — From what you can tell, what subject would he have interest in?

तुम्हारे हिसाब से उसे किस विषय में दिलचस्पी होगी?

Expected form: **would**

Why: Hedging and professional modality. [[English#^en-Q0841|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=From%20what%20you%20can%20tell%2C%20what%20subject%20would%20he%20have%20interest%20in%3F)
^en-Q0841-answer

**en-Q0842** — From what you can tell, what subject would he have interest in?

तुम्हारे हिसाब से उसे किस विषय में दिलचस्पी होगी?

Expected form: **would**

Why: Hedging and professional modality. [[English#^en-Q0842|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=From%20what%20you%20can%20tell%2C%20what%20subject%20would%20he%20have%20interest%20in%3F)
^en-Q0842-answer

**en-Q0843** — Would you please explain the rules to me?

आप मुझे नियम समझा सकते हैं क्या?

Expected form: **Would**

Why: Hedging and professional modality. [[English#^en-Q0843|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Would%20you%20please%20explain%20the%20rules%20to%20me%3F)
^en-Q0843-answer

**en-Q0844** — Would you please explain the rules to me?

आप मुझे नियम समझा सकते हैं क्या?

Why: Hedging and professional modality. [[English#^en-Q0844|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Would%20you%20please%20explain%20the%20rules%20to%20me%3F)
^en-Q0844-answer

**en-Q0845** — I could not bear to see the scene.

मैं वह द्रिश्य देख नहीं सका।

Why: Hedging and professional modality. [[English#^en-Q0845|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20could%20not%20bear%20to%20see%20the%20scene.)
^en-Q0845-answer

**en-Q0846** — I could not bear to see the scene.

मैं वह द्रिश्य देख नहीं सका।

Hedges express different strengths and types of commitment. Could you is often a request, not a question about physical ability. Pair a precise request with a practical reason; avoid stacking several courtesy formulas.

Why: Hedging and professional modality. [[English#^en-Q0846|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20could%20not%20bear%20to%20see%20the%20scene.)
^en-Q0846-answer

**en-Q0847** — It's gotten too late, I should go back.

बहुत देर हो गई है, मुझे वापस जाना चहिए।

Expected form: **should**

Why: Hedging and professional modality. [[English#^en-Q0847|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=It%27s%20gotten%20too%20late%2C%20I%20should%20go%20back.)
^en-Q0847-answer

**en-Q0848** — It's gotten too late, I should go back.

बहुत देर हो गई है, मुझे वापस जाना चहिए।

Expected form: **should**

Why: Hedging and professional modality. [[English#^en-Q0848|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=It%27s%20gotten%20too%20late%2C%20I%20should%20go%20back.)
^en-Q0848-answer

**en-Q0849** — Could I be going soft in the head? I forget things so easily these days.

शायद मैं सटिया गया हूँ। आजकल चीज़ें इतनी आसानी से भूल जाता हूँ।

Expected form: **Could**

Why: Hedging and professional modality. [[English#^en-Q0849|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Could%20I%20be%20going%20soft%20in%20the%20head%3F%20I%20forget%20things%20so%20easily%20these%20days.)
^en-Q0849-answer

**en-Q0850** — Could I be going soft in the head? I forget things so easily these days.

शायद मैं सटिया गया हूँ। आजकल चीज़ें इतनी आसानी से भूल जाता हूँ।

Why: Hedging and professional modality. [[English#^en-Q0850|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Could%20I%20be%20going%20soft%20in%20the%20head%3F%20I%20forget%20things%20so%20easily%20these%20days.)
^en-Q0850-answer


### Answers 851–900

**en-Q0851** — Should Hindi be taught in schools across India?

क्या हिन्दी भारत भर की पाठशालाओं में सिखाई जानी चाहिए?

Why: Hedging and professional modality. [[English#^en-Q0851|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Should%20Hindi%20be%20taught%20in%20schools%20across%20India%3F)
^en-Q0851-answer

**en-Q0852** — Should Hindi be taught in schools across India?

क्या हिन्दी भारत भर की पाठशालाओं में सिखाई जानी चाहिए?

Hedges express different strengths and types of commitment. Could you is often a request, not a question about physical ability. Pair a precise request with a practical reason; avoid stacking several courtesy formulas.

Why: Hedging and professional modality. [[English#^en-Q0852|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Should%20Hindi%20be%20taught%20in%20schools%20across%20India%3F)
^en-Q0852-answer

**en-Q0853** — I thought you two would have a lot in common.

मैं सोचता था कि तुम दोनो में बहुत सी बातें एक दुसरे से मिलती जुलती होगी।

Expected form: **would**

Why: Hedging and professional modality. [[English#^en-Q0853|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20thought%20you%20two%20would%20have%20a%20lot%20in%20common.)
^en-Q0853-answer

**en-Q0854** — I thought you two would have a lot in common.

मैं सोचता था कि तुम दोनो में बहुत सी बातें एक दुसरे से मिलती जुलती होगी।

Expected form: **would**

Why: Hedging and professional modality. [[English#^en-Q0854|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20thought%20you%20two%20would%20have%20a%20lot%20in%20common.)
^en-Q0854-answer

**en-Q0855** — We hurried for fear we should be late for school.

हमने जल्दी करी क्योंकि हमें डर था कि हमें स्कूल पहुँचने में देरी होजाएगी।

Expected form: **should**

Why: Hedging and professional modality. [[English#^en-Q0855|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=We%20hurried%20for%20fear%20we%20should%20be%20late%20for%20school.)
^en-Q0855-answer

**en-Q0856** — We hurried for fear we should be late for school.

हमने जल्दी करी क्योंकि हमें डर था कि हमें स्कूल पहुँचने में देरी होजाएगी।

Why: Hedging and professional modality. [[English#^en-Q0856|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=We%20hurried%20for%20fear%20we%20should%20be%20late%20for%20school.)
^en-Q0856-answer

**en-Q0857** — If you would thoroughly know anything, teach it to others.

आप किसी चीज़ का विशद ज्ञान हासिल करना चाहते हैं तो इसे दूसरों को सिखाने लगिए

Why: Hedging and professional modality. [[English#^en-Q0857|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=If%20you%20would%20thoroughly%20know%20anything%2C%20teach%20it%20to%20others.)
^en-Q0857-answer

**en-Q0858** — If you would thoroughly know anything, teach it to others.

आप किसी चीज़ का विशद ज्ञान हासिल करना चाहते हैं तो इसे दूसरों को सिखाने लगिए

Hedges express different strengths and types of commitment. Could you is often a request, not a question about physical ability. Pair a precise request with a practical reason; avoid stacking several courtesy formulas.

Why: Hedging and professional modality. [[English#^en-Q0858|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=If%20you%20would%20thoroughly%20know%20anything%2C%20teach%20it%20to%20others.)
^en-Q0858-answer

**en-Q0859** — And they would play hide and go seek.

और फिर वे लुका-छुप्पी खेलने जाया करते थे।

Expected form: **would**

Why: Hedging and professional modality. [[English#^en-Q0859|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=And%20they%20would%20play%20hide%20and%20go%20seek.)
^en-Q0859-answer

**en-Q0860** — And they would play hide and go seek.

और फिर वे लुका-छुप्पी खेलने जाया करते थे।

Expected form: **would**

Why: Hedging and professional modality. [[English#^en-Q0860|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=And%20they%20would%20play%20hide%20and%20go%20seek.)
^en-Q0860-answer

**en-Q0861** — What would you do if you met a lion here?

अगर यहां तुम्हें शेर मिला तो तुम क्या करोगे?

Expected form: **would**

Why: Hedging and professional modality. [[English#^en-Q0861|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=What%20would%20you%20do%20if%20you%20met%20a%20lion%20here%3F)
^en-Q0861-answer

**en-Q0862** — What would you do if you met a lion here?

अगर यहां तुम्हें शेर मिला तो तुम क्या करोगे?

Why: Hedging and professional modality. [[English#^en-Q0862|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=What%20would%20you%20do%20if%20you%20met%20a%20lion%20here%3F)
^en-Q0862-answer

**en-Q0863** — We took it for granted that he would join us.

हमने मान लिया था कि वह हमारे साथ आएगा।

Why: Hedging and professional modality. [[English#^en-Q0863|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=We%20took%20it%20for%20granted%20that%20he%20would%20join%20us.)
^en-Q0863-answer

**en-Q0864** — We took it for granted that he would join us.

हमने मान लिया था कि वह हमारे साथ आएगा।

Hedges express different strengths and types of commitment. Could you is often a request, not a question about physical ability. Pair a precise request with a practical reason; avoid stacking several courtesy formulas.

Why: Hedging and professional modality. [[English#^en-Q0864|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=We%20took%20it%20for%20granted%20that%20he%20would%20join%20us.)
^en-Q0864-answer

**en-Q0865** — You should try to conquer your smoking habit.

तुम्हें अपने सिगरेट पीने पर रोक लगाने की कोशिश करनी चाहिए।

Expected form: **should**

Why: Hedging and professional modality. [[English#^en-Q0865|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=You%20should%20try%20to%20conquer%20your%20smoking%20habit.)
^en-Q0865-answer

**en-Q0866** — You should try to conquer your smoking habit.

तुम्हें अपने सिगरेट पीने पर रोक लगाने की कोशिश करनी चाहिए।

Expected form: **should**

Why: Hedging and professional modality. [[English#^en-Q0866|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=You%20should%20try%20to%20conquer%20your%20smoking%20habit.)
^en-Q0866-answer

**en-Q0867** — You should take care of your sick mother.

तुम्हे अपनी बीमार माँ का ख़याल रखना चाहिए।

Expected form: **should**

Why: Hedging and professional modality. [[English#^en-Q0867|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=You%20should%20take%20care%20of%20your%20sick%20mother.)
^en-Q0867-answer

**en-Q0868** — You should take care of your sick mother.

तुम्हे अपनी बीमार माँ का ख़याल रखना चाहिए।

Why: Hedging and professional modality. [[English#^en-Q0868|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=You%20should%20take%20care%20of%20your%20sick%20mother.)
^en-Q0868-answer

**en-Q0869** — The capital of Himachal Pradesh, Shimla, is only 115 kilometres away from Chandigarh.

हिमाचल प्रदेश की राजधानी, शिमला, चण्डीगढ़ से केवल ११५ किलोमीटर की दूरी पर है।

Why: Articles, countability and reference. [[English#^en-Q0869|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20capital%20of%20Himachal%20Pradesh%2C%20Shimla%2C%20is%20only%20115%20kilometres%20away%20from%20Chandigarh.)
^en-Q0869-answer

**en-Q0870** — The capital of Himachal Pradesh, Shimla, is only 115 kilometres away from Chandigarh.

हिमाचल प्रदेश की राजधानी, शिमला, चण्डीगढ़ से केवल ११५ किलोमीटर की दूरी पर है।

Article choice reflects reference and countability. A/an selects a singular countable noun and follows the initial sound, not the first letter. Research and evidence are normally uncountable in academic uses; experience can change countability with meaning.

Why: Articles, countability and reference. [[English#^en-Q0870|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20capital%20of%20Himachal%20Pradesh%2C%20Shimla%2C%20is%20only%20115%20kilometres%20away%20from%20Chandigarh.)
^en-Q0870-answer

**en-Q0871** — Come on! I will show you the taste of defeat.

आओ! मैं तुम्हें हार का स्वाद चखाऊँगा।

Expected form: **the**

Why: Articles, countability and reference. [[English#^en-Q0871|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Come%20on%21%20I%20will%20show%20you%20the%20taste%20of%20defeat.)
^en-Q0871-answer

**en-Q0872** — Come on! I will show you the taste of defeat.

आओ! मैं तुम्हें हार का स्वाद चखाऊँगा।

Expected form: **the**

Why: Articles, countability and reference. [[English#^en-Q0872|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Come%20on%21%20I%20will%20show%20you%20the%20taste%20of%20defeat.)
^en-Q0872-answer

**en-Q0873** — The children built a sand castle on the beach.

बच्चों ने बीच पर रेत का किला बनाया।

Expected form: **The**

Why: Articles, countability and reference. [[English#^en-Q0873|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20children%20built%20a%20sand%20castle%20on%20the%20beach.)
^en-Q0873-answer

**en-Q0874** — The children built a sand castle on the beach.

बच्चों ने बीच पर रेत का किला बनाया।

Why: Articles, countability and reference. [[English#^en-Q0874|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20children%20built%20a%20sand%20castle%20on%20the%20beach.)
^en-Q0874-answer

**en-Q0875** — It was the window that Tom broke yesterday.

वह वह खिड़की है जिसको टॉम ने कल थोड़ा था।

Why: Articles, countability and reference. [[English#^en-Q0875|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=It%20was%20the%20window%20that%20Tom%20broke%20yesterday.)
^en-Q0875-answer

**en-Q0876** — It was the window that Tom broke yesterday.

वह वह खिड़की है जिसको टॉम ने कल थोड़ा था।

Article choice reflects reference and countability. A/an selects a singular countable noun and follows the initial sound, not the first letter. Research and evidence are normally uncountable in academic uses; experience can change countability with meaning.

Why: Articles, countability and reference. [[English#^en-Q0876|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=It%20was%20the%20window%20that%20Tom%20broke%20yesterday.)
^en-Q0876-answer

**en-Q0877** — How many strokes does the kanji for "michi" have?

"मिचि" के कान्जी में किती रेखाएं होती हैं?

Expected form: **the**

Why: Articles, countability and reference. [[English#^en-Q0877|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=How%20many%20strokes%20does%20the%20kanji%20for%20%22michi%22%20have%3F)
^en-Q0877-answer

**en-Q0878** — How many strokes does the kanji for "michi" have?

"मिचि" के कान्जी में किती रेखाएं होती हैं?

Expected form: **the**

Why: Articles, countability and reference. [[English#^en-Q0878|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=How%20many%20strokes%20does%20the%20kanji%20for%20%22michi%22%20have%3F)
^en-Q0878-answer

**en-Q0879** — She burst into tears when she heard the news.

वह खबर सुनते ही रो पड़ी।

Expected form: **the**

Why: Articles, countability and reference. [[English#^en-Q0879|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=She%20burst%20into%20tears%20when%20she%20heard%20the%20news.)
^en-Q0879-answer

**en-Q0880** — She burst into tears when she heard the news.

वह खबर सुनते ही रो पड़ी।

Why: Articles, countability and reference. [[English#^en-Q0880|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=She%20burst%20into%20tears%20when%20she%20heard%20the%20news.)
^en-Q0880-answer

**en-Q0881** — He's not a scientist, but he is our friend.

वोह एक वैज्ञानिक न ही है, पर हमारा दोस्त जरूर है |

Why: Articles, countability and reference. [[English#^en-Q0881|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%27s%20not%20a%20scientist%2C%20but%20he%20is%20our%20friend.)
^en-Q0881-answer

**en-Q0882** — He's not a scientist, but he is our friend.

वोह एक वैज्ञानिक न ही है, पर हमारा दोस्त जरूर है |

Article choice reflects reference and countability. A/an selects a singular countable noun and follows the initial sound, not the first letter. Research and evidence are normally uncountable in academic uses; experience can change countability with meaning.

Why: Articles, countability and reference. [[English#^en-Q0882|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%27s%20not%20a%20scientist%2C%20but%20he%20is%20our%20friend.)
^en-Q0882-answer

**en-Q0883** — It's all the same to me whether you go or stay.

तुम जाओ या रहो, मुझे कोई फ़र्क नहीं पड़ता।

Expected form: **the**

Why: Articles, countability and reference. [[English#^en-Q0883|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=It%27s%20all%20the%20same%20to%20me%20whether%20you%20go%20or%20stay.)
^en-Q0883-answer

**en-Q0884** — It's all the same to me whether you go or stay.

तुम जाओ या रहो, मुझे कोई फ़र्क नहीं पड़ता।

Expected form: **the**

Why: Articles, countability and reference. [[English#^en-Q0884|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=It%27s%20all%20the%20same%20to%20me%20whether%20you%20go%20or%20stay.)
^en-Q0884-answer

**en-Q0885** — Which is the best hotel in the town?

शहर में सबसे अच्छा होटल कौन सा है?

Expected form: **the**

Why: Articles, countability and reference. [[English#^en-Q0885|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Which%20is%20the%20best%20hotel%20in%20the%20town%3F)
^en-Q0885-answer

**en-Q0886** — Which is the best hotel in the town?

शहर में सबसे अच्छा होटल कौन सा है?

Why: Articles, countability and reference. [[English#^en-Q0886|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Which%20is%20the%20best%20hotel%20in%20the%20town%3F)
^en-Q0886-answer

**en-Q0887** — Take a chance! All life is a chance.

जोखिम उठाइये! पूरी जिंदगी एक जोखिम है।

Why: Articles, countability and reference. [[English#^en-Q0887|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Take%20a%20chance%21%20All%20life%20is%20a%20chance.)
^en-Q0887-answer

**en-Q0888** — Take a chance! All life is a chance.

जोखिम उठाइये! पूरी जिंदगी एक जोखिम है।

Article choice reflects reference and countability. A/an selects a singular countable noun and follows the initial sound, not the first letter. Research and evidence are normally uncountable in academic uses; experience can change countability with meaning.

Why: Articles, countability and reference. [[English#^en-Q0888|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Take%20a%20chance%21%20All%20life%20is%20a%20chance.)
^en-Q0888-answer

**en-Q0889** — She cried out the moment she saw her mother.

उसने जैसे ही अपनी मम्मी को देखा, वह चिल्ला उठी।

Expected form: **the**

Why: Articles, countability and reference. [[English#^en-Q0889|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=She%20cried%20out%20the%20moment%20she%20saw%20her%20mother.)
^en-Q0889-answer

**en-Q0890** — She cried out the moment she saw her mother.

उसने जैसे ही अपनी मम्मी को देखा, वह चिल्ला उठी।

Expected form: **the**

Why: Articles, countability and reference. [[English#^en-Q0890|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=She%20cried%20out%20the%20moment%20she%20saw%20her%20mother.)
^en-Q0890-answer

**en-Q0891** — A man like that gets on my nerves.

उस तरह का आदमी मुझसे झिलता नहीं है।

Expected form: **A**

Why: Articles, countability and reference. [[English#^en-Q0891|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=A%20man%20like%20that%20gets%20on%20my%20nerves.)
^en-Q0891-answer

**en-Q0892** — A man like that gets on my nerves.

उस तरह का आदमी मुझसे झिलता नहीं है।

Why: Articles, countability and reference. [[English#^en-Q0892|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=A%20man%20like%20that%20gets%20on%20my%20nerves.)
^en-Q0892-answer

**en-Q0893** — The secret of longevity is to choose your parents carefully.

धीर्ग आयु का राज़ अपने माता पिता का सतर्क चुनाव में है |

Why: Articles, countability and reference. [[English#^en-Q0893|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20secret%20of%20longevity%20is%20to%20choose%20your%20parents%20carefully.)
^en-Q0893-answer

**en-Q0894** — The secret of longevity is to choose your parents carefully.

धीर्ग आयु का राज़ अपने माता पिता का सतर्क चुनाव में है |

Article choice reflects reference and countability. A/an selects a singular countable noun and follows the initial sound, not the first letter. Research and evidence are normally uncountable in academic uses; experience can change countability with meaning.

Why: Articles, countability and reference. [[English#^en-Q0894|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20secret%20of%20longevity%20is%20to%20choose%20your%20parents%20carefully.)
^en-Q0894-answer

**en-Q0895** — As a matter of fact, I dislike him.

दरअसल मुझे वह पसंद नहीं है।

Expected form: **a**

Why: Articles, countability and reference. [[English#^en-Q0895|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=As%20a%20matter%20of%20fact%2C%20I%20dislike%20him.)
^en-Q0895-answer

**en-Q0896** — As a matter of fact, I dislike him.

दरअसल मुझे वह पसंद नहीं है।

Expected form: **a**

Why: Articles, countability and reference. [[English#^en-Q0896|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=As%20a%20matter%20of%20fact%2C%20I%20dislike%20him.)
^en-Q0896-answer

**en-Q0897** — We simply didn't expect to see such filth on the family shopping site.

हमने पारिवारिक शापिंग साइट पर इस प्रकार की अश्लीलता देखने की कभी कल्पना नहीं की थी।

Expected form: **the**

Why: Articles, countability and reference. [[English#^en-Q0897|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=We%20simply%20didn%27t%20expect%20to%20see%20such%20filth%20on%20the%20family%20shopping%20site.)
^en-Q0897-answer

**en-Q0898** — We simply didn't expect to see such filth on the family shopping site.

हमने पारिवारिक शापिंग साइट पर इस प्रकार की अश्लीलता देखने की कभी कल्पना नहीं की थी।

Why: Articles, countability and reference. [[English#^en-Q0898|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=We%20simply%20didn%27t%20expect%20to%20see%20such%20filth%20on%20the%20family%20shopping%20site.)
^en-Q0898-answer

**en-Q0899** — I have to put the baby to bed.

मुझे बच्चे को सुलाना है।

Why: Articles, countability and reference. [[English#^en-Q0899|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20have%20to%20put%20the%20baby%20to%20bed.)
^en-Q0899-answer

**en-Q0900** — I have to put the baby to bed.

मुझे बच्चे को सुलाना है।

Article choice reflects reference and countability. A/an selects a singular countable noun and follows the initial sound, not the first letter. Research and evidence are normally uncountable in academic uses; experience can change countability with meaning.

Why: Articles, countability and reference. [[English#^en-Q0900|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20have%20to%20put%20the%20baby%20to%20bed.)
^en-Q0900-answer


### Answers 901–950

**en-Q0901** — I am connecting this computer to the Internet.

मैं इस कम्प्यूटर को इंटरनेट से जोड़ रहा हूं।

Expected form: **the**

Why: Articles, countability and reference. [[English#^en-Q0901|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20am%20connecting%20this%20computer%20to%20the%20Internet.)
^en-Q0901-answer

**en-Q0902** — I am connecting this computer to the Internet.

मैं इस कम्प्यूटर को इंटरनेट से जोड़ रहा हूं।

Expected form: **the**

Why: Articles, countability and reference. [[English#^en-Q0902|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20am%20connecting%20this%20computer%20to%20the%20Internet.)
^en-Q0902-answer

**en-Q0903** — The passengers who were injured in the accident were taken to the nearest hospital.

जिन यात्रियों को दुर्घटना मे चोट आई थी उन्हे अस्पताल ले जाया गया।

Expected form: **The**

Why: Articles, countability and reference. [[English#^en-Q0903|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20passengers%20who%20were%20injured%20in%20the%20accident%20were%20taken%20to%20the%20nearest%20hospital.)
^en-Q0903-answer

**en-Q0904** — The passengers who were injured in the accident were taken to the nearest hospital.

जिन यात्रियों को दुर्घटना मे चोट आई थी उन्हे अस्पताल ले जाया गया।

Why: Articles, countability and reference. [[English#^en-Q0904|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20passengers%20who%20were%20injured%20in%20the%20accident%20were%20taken%20to%20the%20nearest%20hospital.)
^en-Q0904-answer

**en-Q0905** — One of the lights is not working. Do you think you could come take a look?

एक बत्ती नहीं जल रही है। तुम ज़रा आकर देख सकते हो क्या?

Why: Articles, countability and reference. [[English#^en-Q0905|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=One%20of%20the%20lights%20is%20not%20working.%20Do%20you%20think%20you%20could%20come%20take%20a%20look%3F)
^en-Q0905-answer

**en-Q0906** — One of the lights is not working. Do you think you could come take a look?

एक बत्ती नहीं जल रही है। तुम ज़रा आकर देख सकते हो क्या?

Article choice reflects reference and countability. A/an selects a singular countable noun and follows the initial sound, not the first letter. Research and evidence are normally uncountable in academic uses; experience can change countability with meaning.

Why: Articles, countability and reference. [[English#^en-Q0906|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=One%20of%20the%20lights%20is%20not%20working.%20Do%20you%20think%20you%20could%20come%20take%20a%20look%3F)
^en-Q0906-answer

**en-Q0907** — A madman is not accountable for his actions.

एक पागल इनसान को अपने किये-धरे के लिए ज़िम्मेदार नहीं ठहराया जा सकता।

Expected form: **A**

Why: Articles, countability and reference. [[English#^en-Q0907|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=A%20madman%20is%20not%20accountable%20for%20his%20actions.)
^en-Q0907-answer

**en-Q0908** — A madman is not accountable for his actions.

एक पागल इनसान को अपने किये-धरे के लिए ज़िम्मेदार नहीं ठहराया जा सकता।

Expected form: **A**

Why: Articles, countability and reference. [[English#^en-Q0908|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=A%20madman%20is%20not%20accountable%20for%20his%20actions.)
^en-Q0908-answer

**en-Q0909** — The population of Sweden is on the increase.

स्वीडन की जनसंख्या बढ़ रही है।

Expected form: **The**

Why: Articles, countability and reference. [[English#^en-Q0909|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20population%20of%20Sweden%20is%20on%20the%20increase.)
^en-Q0909-answer

**en-Q0910** — The population of Sweden is on the increase.

स्वीडन की जनसंख्या बढ़ रही है।

Why: Articles, countability and reference. [[English#^en-Q0910|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20population%20of%20Sweden%20is%20on%20the%20increase.)
^en-Q0910-answer

**en-Q0911** — Please give me the paper when you have done with it.

जब आपने अखबार पढ़ लिया हो तो मुझे दे दीजिएगा।

Why: Articles, countability and reference. [[English#^en-Q0911|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Please%20give%20me%20the%20paper%20when%20you%20have%20done%20with%20it.)
^en-Q0911-answer

**en-Q0912** — Please give me the paper when you have done with it.

जब आपने अखबार पढ़ लिया हो तो मुझे दे दीजिएगा।

Article choice reflects reference and countability. A/an selects a singular countable noun and follows the initial sound, not the first letter. Research and evidence are normally uncountable in academic uses; experience can change countability with meaning.

Why: Articles, countability and reference. [[English#^en-Q0912|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Please%20give%20me%20the%20paper%20when%20you%20have%20done%20with%20it.)
^en-Q0912-answer

**en-Q0913** — The rich are not always happier than the poor.

अमीर हमेशा गरीबों से ज़्यादा ख़ुश नहीं होते।

Expected form: **The**

Why: Articles, countability and reference. [[English#^en-Q0913|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20rich%20are%20not%20always%20happier%20than%20the%20poor.)
^en-Q0913-answer

**en-Q0914** — The rich are not always happier than the poor.

अमीर हमेशा गरीबों से ज़्यादा ख़ुश नहीं होते।

Expected form: **The**

Why: Articles, countability and reference. [[English#^en-Q0914|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20rich%20are%20not%20always%20happier%20than%20the%20poor.)
^en-Q0914-answer

**en-Q0915** — Tatoeba is currently unavailable. We are sorry for the inconvenience. You can check our blog or Twitter for more information.

तातोएबा इस वक़्त अनुपलब्ध है। असुविधा के लिए हमें खेद है। अधिक जानकारी के लिये आप हमारा ब्लॉग या ट्विटर देख सकते हैं।

Expected form: **the**

Why: Articles, countability and reference. [[English#^en-Q0915|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Tatoeba%20is%20currently%20unavailable.%20We%20are%20sorry%20for%20the%20inconvenience.%20You%20can%20check%20our%20blog%20or%20Twitter%20for%20more%20information.)
^en-Q0915-answer

**en-Q0916** — Tatoeba is currently unavailable. We are sorry for the inconvenience. You can check our blog or Twitter for more information.

तातोएबा इस वक़्त अनुपलब्ध है। असुविधा के लिए हमें खेद है। अधिक जानकारी के लिये आप हमारा ब्लॉग या ट्विटर देख सकते हैं।

Why: Articles, countability and reference. [[English#^en-Q0916|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Tatoeba%20is%20currently%20unavailable.%20We%20are%20sorry%20for%20the%20inconvenience.%20You%20can%20check%20our%20blog%20or%20Twitter%20for%20more%20information.)
^en-Q0916-answer

**en-Q0917** — Mother Teresa was a Catholic nun who lived and worked in Calcutta, India.

मदर टेरेसा एक कैथोलिक नन थीं जो कलकत्ता में रहतीं और काम करतीं थीं।

Why: Articles, countability and reference. [[English#^en-Q0917|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Mother%20Teresa%20was%20a%20Catholic%20nun%20who%20lived%20and%20worked%20in%20Calcutta%2C%20India.)
^en-Q0917-answer

**en-Q0918** — Mother Teresa was a Catholic nun who lived and worked in Calcutta, India.

मदर टेरेसा एक कैथोलिक नन थीं जो कलकत्ता में रहतीं और काम करतीं थीं।

Article choice reflects reference and countability. A/an selects a singular countable noun and follows the initial sound, not the first letter. Research and evidence are normally uncountable in academic uses; experience can change countability with meaning.

Why: Articles, countability and reference. [[English#^en-Q0918|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Mother%20Teresa%20was%20a%20Catholic%20nun%20who%20lived%20and%20worked%20in%20Calcutta%2C%20India.)
^en-Q0918-answer

**en-Q0919** — Do you want me to open the windows?

क्या आप चाहते हैं कि मैं खिड़कियाँ खोलूँ?

Expected form: **the**

Why: Articles, countability and reference. [[English#^en-Q0919|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Do%20you%20want%20me%20to%20open%20the%20windows%3F)
^en-Q0919-answer

**en-Q0920** — Do you want me to open the windows?

क्या आप चाहते हैं कि मैं खिड़कियाँ खोलूँ?

Expected form: **the**

Why: Articles, countability and reference. [[English#^en-Q0920|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Do%20you%20want%20me%20to%20open%20the%20windows%3F)
^en-Q0920-answer

**en-Q0921** — Let me give you a piece of advice.

मैं तुम्हें एक बात की सलाह देता हूँ।

Expected form: **a**

Why: Articles, countability and reference. [[English#^en-Q0921|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Let%20me%20give%20you%20a%20piece%20of%20advice.)
^en-Q0921-answer

**en-Q0922** — Let me give you a piece of advice.

मैं तुम्हें एक बात की सलाह देता हूँ।

Why: Articles, countability and reference. [[English#^en-Q0922|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Let%20me%20give%20you%20a%20piece%20of%20advice.)
^en-Q0922-answer

**en-Q0923** — He'll never admit to being in the wrong.

वह कभी अपनी ग़लती नहीं मानेगा।

Why: Articles, countability and reference. [[English#^en-Q0923|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%27ll%20never%20admit%20to%20being%20in%20the%20wrong.)
^en-Q0923-answer

**en-Q0924** — He'll never admit to being in the wrong.

वह कभी अपनी ग़लती नहीं मानेगा।

Article choice reflects reference and countability. A/an selects a singular countable noun and follows the initial sound, not the first letter. Research and evidence are normally uncountable in academic uses; experience can change countability with meaning.

Why: Articles, countability and reference. [[English#^en-Q0924|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%27ll%20never%20admit%20to%20being%20in%20the%20wrong.)
^en-Q0924-answer

**en-Q0925** — That was just the trailer, the movie's yet to come, my friend!

यह तो बस ट्रेलर है, पिक्चर अभी बाकी है, मेरे दोस्त!

Expected form: **the**

Why: Articles, countability and reference. [[English#^en-Q0925|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=That%20was%20just%20the%20trailer%2C%20the%20movie%27s%20yet%20to%20come%2C%20my%20friend%21)
^en-Q0925-answer

**en-Q0926** — That was just the trailer, the movie's yet to come, my friend!

यह तो बस ट्रेलर है, पिक्चर अभी बाकी है, मेरे दोस्त!

Expected form: **the**

Why: Articles, countability and reference. [[English#^en-Q0926|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=That%20was%20just%20the%20trailer%2C%20the%20movie%27s%20yet%20to%20come%2C%20my%20friend%21)
^en-Q0926-answer

**en-Q0927** — They say that Firefox is downloaded more than 8 million times a day.

कहते हैं के फ़ायरफ़ॉक्स प्रतिदिन ८ मिलियन से ज़्यादा बार डाउनलोड किया जाता है।

Expected form: **a**

Why: Articles, countability and reference. [[English#^en-Q0927|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=They%20say%20that%20Firefox%20is%20downloaded%20more%20than%208%20million%20times%20a%20day.)
^en-Q0927-answer

**en-Q0928** — They say that Firefox is downloaded more than 8 million times a day.

कहते हैं के फ़ायरफ़ॉक्स प्रतिदिन ८ मिलियन से ज़्यादा बार डाउनलोड किया जाता है।

Why: Articles, countability and reference. [[English#^en-Q0928|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=They%20say%20that%20Firefox%20is%20downloaded%20more%20than%208%20million%20times%20a%20day.)
^en-Q0928-answer

**en-Q0929** — Because of the rain they had to cancel the game.

बारिश की वजह से उन्हें खेल रद्द करना पड़ा।

Why: Articles, countability and reference. [[English#^en-Q0929|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Because%20of%20the%20rain%20they%20had%20to%20cancel%20the%20game.)
^en-Q0929-answer

**en-Q0930** — Because of the rain they had to cancel the game.

बारिश की वजह से उन्हें खेल रद्द करना पड़ा।

Article choice reflects reference and countability. A/an selects a singular countable noun and follows the initial sound, not the first letter. Research and evidence are normally uncountable in academic uses; experience can change countability with meaning.

Why: Articles, countability and reference. [[English#^en-Q0930|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Because%20of%20the%20rain%20they%20had%20to%20cancel%20the%20game.)
^en-Q0930-answer

**en-Q0931** — Did you have a good sleep last night?

तुम कल रात अच्छे से सोये क्या?

Expected form: **a**

Why: Articles, countability and reference. [[English#^en-Q0931|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Did%20you%20have%20a%20good%20sleep%20last%20night%3F)
^en-Q0931-answer

**en-Q0932** — Did you have a good sleep last night?

तुम कल रात अच्छे से सोये क्या?

Expected form: **a**

Why: Articles, countability and reference. [[English#^en-Q0932|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Did%20you%20have%20a%20good%20sleep%20last%20night%3F)
^en-Q0932-answer

**en-Q0933** — Is it necessary for me to attend the party?

मेरा पार्टी में आना ज़रूरी है क्या?

Expected form: **the**

Why: Articles, countability and reference. [[English#^en-Q0933|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Is%20it%20necessary%20for%20me%20to%20attend%20the%20party%3F)
^en-Q0933-answer

**en-Q0934** — Is it necessary for me to attend the party?

मेरा पार्टी में आना ज़रूरी है क्या?

Why: Articles, countability and reference. [[English#^en-Q0934|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Is%20it%20necessary%20for%20me%20to%20attend%20the%20party%3F)
^en-Q0934-answer

**en-Q0935** — They translated the novel from Russian into Armenian.

उन्होंने वह उपन्यास का रूसी से आर्मीनियाई में भाषांतर किया।

Why: Articles, countability and reference. [[English#^en-Q0935|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=They%20translated%20the%20novel%20from%20Russian%20into%20Armenian.)
^en-Q0935-answer

**en-Q0936** — They translated the novel from Russian into Armenian.

उन्होंने वह उपन्यास का रूसी से आर्मीनियाई में भाषांतर किया।

Article choice reflects reference and countability. A/an selects a singular countable noun and follows the initial sound, not the first letter. Research and evidence are normally uncountable in academic uses; experience can change countability with meaning.

Why: Articles, countability and reference. [[English#^en-Q0936|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=They%20translated%20the%20novel%20from%20Russian%20into%20Armenian.)
^en-Q0936-answer

**en-Q0937** — You must get rid of such a habit.

तुम्हे इस तरह की आदत तोड़ देनी चाहिए।

Expected form: **a**

Why: Articles, countability and reference. [[English#^en-Q0937|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=You%20must%20get%20rid%20of%20such%20a%20habit.)
^en-Q0937-answer

**en-Q0938** — You must get rid of such a habit.

तुम्हे इस तरह की आदत तोड़ देनी चाहिए।

Expected form: **a**

Why: Articles, countability and reference. [[English#^en-Q0938|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=You%20must%20get%20rid%20of%20such%20a%20habit.)
^en-Q0938-answer

**en-Q0939** — How many letters does the Russian alphabet have?

रूसी वर्णमाला में कितने अक्षर हैं?

Expected form: **the**

Why: Articles, countability and reference. [[English#^en-Q0939|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=How%20many%20letters%20does%20the%20Russian%20alphabet%20have%3F)
^en-Q0939-answer

**en-Q0940** — How many letters does the Russian alphabet have?

रूसी वर्णमाला में कितने अक्षर हैं?

Why: Articles, countability and reference. [[English#^en-Q0940|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=How%20many%20letters%20does%20the%20Russian%20alphabet%20have%3F)
^en-Q0940-answer

**en-Q0941** — To investigate the incident would take us at least three weeks.

हमको इस घटना की तहकीकात करने में कम-से-कम तीन हफ़्ते लगेंगे।

Why: Articles, countability and reference. [[English#^en-Q0941|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=To%20investigate%20the%20incident%20would%20take%20us%20at%20least%20three%20weeks.)
^en-Q0941-answer

**en-Q0942** — To investigate the incident would take us at least three weeks.

हमको इस घटना की तहकीकात करने में कम-से-कम तीन हफ़्ते लगेंगे।

Article choice reflects reference and countability. A/an selects a singular countable noun and follows the initial sound, not the first letter. Research and evidence are normally uncountable in academic uses; experience can change countability with meaning.

Why: Articles, countability and reference. [[English#^en-Q0942|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=To%20investigate%20the%20incident%20would%20take%20us%20at%20least%20three%20weeks.)
^en-Q0942-answer

**en-Q0943** — I know a girl who can ride a unicycle.

मेरे जान-पहचान की एक लड़की को युनिसायकल चलाना आता है।

Expected form: **a**

Why: Articles, countability and reference. [[English#^en-Q0943|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20know%20a%20girl%20who%20can%20ride%20a%20unicycle.)
^en-Q0943-answer

**en-Q0944** — I know a girl who can ride a unicycle.

मेरे जान-पहचान की एक लड़की को युनिसायकल चलाना आता है।

Expected form: **a**

Why: Articles, countability and reference. [[English#^en-Q0944|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20know%20a%20girl%20who%20can%20ride%20a%20unicycle.)
^en-Q0944-answer

**en-Q0945** — One lives in Fukuoka, and the others live in Niigata.

एक फ़ुकुओका में रहता है, और बाकी निइगाता में रहते हैं।

Expected form: **the**

Why: Articles, countability and reference. [[English#^en-Q0945|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=One%20lives%20in%20Fukuoka%2C%20and%20the%20others%20live%20in%20Niigata.)
^en-Q0945-answer

**en-Q0946** — One lives in Fukuoka, and the others live in Niigata.

एक फ़ुकुओका में रहता है, और बाकी निइगाता में रहते हैं।

Why: Articles, countability and reference. [[English#^en-Q0946|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=One%20lives%20in%20Fukuoka%2C%20and%20the%20others%20live%20in%20Niigata.)
^en-Q0946-answer

**en-Q0947** — Smoking will do you a lot of harm.

धूम्रपान आपको हानि पहुँचाएगा।

Why: Articles, countability and reference. [[English#^en-Q0947|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Smoking%20will%20do%20you%20a%20lot%20of%20harm.)
^en-Q0947-answer

**en-Q0948** — Smoking will do you a lot of harm.

धूम्रपान आपको हानि पहुँचाएगा।

Article choice reflects reference and countability. A/an selects a singular countable noun and follows the initial sound, not the first letter. Research and evidence are normally uncountable in academic uses; experience can change countability with meaning.

Why: Articles, countability and reference. [[English#^en-Q0948|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Smoking%20will%20do%20you%20a%20lot%20of%20harm.)
^en-Q0948-answer

**en-Q0949** — A man is great by deeds, not by birth.

“व्यक्ति कर्मों से महान बनता है, जन्म से नहीं।

Expected form: **A**

Why: Articles, countability and reference. [[English#^en-Q0949|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=A%20man%20is%20great%20by%20deeds%2C%20not%20by%20birth.)
^en-Q0949-answer

**en-Q0950** — A man is great by deeds, not by birth.

“व्यक्ति कर्मों से महान बनता है, जन्म से नहीं।

Expected form: **A**

Why: Articles, countability and reference. [[English#^en-Q0950|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=A%20man%20is%20great%20by%20deeds%2C%20not%20by%20birth.)
^en-Q0950-answer


### Answers 951–1000

**en-Q0951** — The walls in the old house were not straight.

उस पुराने घर की दीवारें सीधी नहीं थी।

Expected form: **The**

Why: Articles, countability and reference. [[English#^en-Q0951|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20walls%20in%20the%20old%20house%20were%20not%20straight.)
^en-Q0951-answer

**en-Q0952** — The walls in the old house were not straight.

उस पुराने घर की दीवारें सीधी नहीं थी।

Why: Articles, countability and reference. [[English#^en-Q0952|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20walls%20in%20the%20old%20house%20were%20not%20straight.)
^en-Q0952-answer

**en-Q0953** — Can you tell the difference between these two pictures?

तुम इन दो तस्वीरों में अंतर बता सकते हो?

Why: Articles, countability and reference. [[English#^en-Q0953|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Can%20you%20tell%20the%20difference%20between%20these%20two%20pictures%3F)
^en-Q0953-answer

**en-Q0954** — Can you tell the difference between these two pictures?

तुम इन दो तस्वीरों में अंतर बता सकते हो?

Article choice reflects reference and countability. A/an selects a singular countable noun and follows the initial sound, not the first letter. Research and evidence are normally uncountable in academic uses; experience can change countability with meaning.

Why: Articles, countability and reference. [[English#^en-Q0954|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Can%20you%20tell%20the%20difference%20between%20these%20two%20pictures%3F)
^en-Q0954-answer

**en-Q0955** — I saw a red car and a white one. The red one was nicer looking than the white one.

मैंने एक लाल कार और सफ़ेद कार देखि. लाल कार सफ़ेद कार से दिखने में ज्यादा अछी थी.

Expected form: **a**

Why: Articles, countability and reference. [[English#^en-Q0955|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20saw%20a%20red%20car%20and%20a%20white%20one.%20The%20red%20one%20was%20nicer%20looking%20than%20the%20white%20one.)
^en-Q0955-answer

**en-Q0956** — I saw a red car and a white one. The red one was nicer looking than the white one.

मैंने एक लाल कार और सफ़ेद कार देखि. लाल कार सफ़ेद कार से दिखने में ज्यादा अछी थी.

Expected form: **a**

Why: Articles, countability and reference. [[English#^en-Q0956|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20saw%20a%20red%20car%20and%20a%20white%20one.%20The%20red%20one%20was%20nicer%20looking%20than%20the%20white%20one.)
^en-Q0956-answer

**en-Q0957** — Egyptian began to be written using the Greek alphabet in the 1st century.

पहले शतक से मिस्री भाषा यूनानी अक्षरों में लिखी जाने लगी।

Expected form: **the**

Why: Articles, countability and reference. [[English#^en-Q0957|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Egyptian%20began%20to%20be%20written%20using%20the%20Greek%20alphabet%20in%20the%201st%20century.)
^en-Q0957-answer

**en-Q0958** — Egyptian began to be written using the Greek alphabet in the 1st century.

पहले शतक से मिस्री भाषा यूनानी अक्षरों में लिखी जाने लगी।

Why: Articles, countability and reference. [[English#^en-Q0958|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Egyptian%20began%20to%20be%20written%20using%20the%20Greek%20alphabet%20in%20the%201st%20century.)
^en-Q0958-answer

**en-Q0959** — For some reason I feel more alive at night.

पता नहीं क्यों मुझे रात में ज़्यादा ज़िन्दा महसूस होता है।

Why: Articles, countability and reference. [[English#^en-Q0959|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=For%20some%20reason%20I%20feel%20more%20alive%20at%20night.)
^en-Q0959-answer

**en-Q0960** — For some reason I feel more alive at night.

पता नहीं क्यों मुझे रात में ज़्यादा ज़िन्दा महसूस होता है।

Article choice reflects reference and countability. A/an selects a singular countable noun and follows the initial sound, not the first letter. Research and evidence are normally uncountable in academic uses; experience can change countability with meaning.

Why: Articles, countability and reference. [[English#^en-Q0960|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=For%20some%20reason%20I%20feel%20more%20alive%20at%20night.)
^en-Q0960-answer

**en-Q0961** — This car has enough power to go up the mountain easily.

गाड़ी में आसानी से पहाड़ चढ़ने लायक जान है।

Expected form: **the**

Why: Articles, countability and reference. [[English#^en-Q0961|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=This%20car%20has%20enough%20power%20to%20go%20up%20the%20mountain%20easily.)
^en-Q0961-answer

**en-Q0962** — This car has enough power to go up the mountain easily.

गाड़ी में आसानी से पहाड़ चढ़ने लायक जान है।

Expected form: **the**

Why: Articles, countability and reference. [[English#^en-Q0962|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=This%20car%20has%20enough%20power%20to%20go%20up%20the%20mountain%20easily.)
^en-Q0962-answer

**en-Q0963** — If it isn't a bad, dirty, or wrong thing, then it's alright.

यदि वह बुरा, गंदा या गलत न हो तो ठीक है।

Expected form: **a**

Why: Articles, countability and reference. [[English#^en-Q0963|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=If%20it%20isn%27t%20a%20bad%2C%20dirty%2C%20or%20wrong%20thing%2C%20then%20it%27s%20alright.)
^en-Q0963-answer

**en-Q0964** — If it isn't a bad, dirty, or wrong thing, then it's alright.

यदि वह बुरा, गंदा या गलत न हो तो ठीक है।

Why: Articles, countability and reference. [[English#^en-Q0964|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=If%20it%20isn%27t%20a%20bad%2C%20dirty%2C%20or%20wrong%20thing%2C%20then%20it%27s%20alright.)
^en-Q0964-answer

**en-Q0965** — The spaceship was never to return to the earth.

वह हवाई जहाज़ पृथ्वीपर वापस लौटनेवाला नहीं था.

Why: Articles, countability and reference. [[English#^en-Q0965|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20spaceship%20was%20never%20to%20return%20to%20the%20earth.)
^en-Q0965-answer

**en-Q0966** — The spaceship was never to return to the earth.

वह हवाई जहाज़ पृथ्वीपर वापस लौटनेवाला नहीं था.

Article choice reflects reference and countability. A/an selects a singular countable noun and follows the initial sound, not the first letter. Research and evidence are normally uncountable in academic uses; experience can change countability with meaning.

Why: Articles, countability and reference. [[English#^en-Q0966|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=The%20spaceship%20was%20never%20to%20return%20to%20the%20earth.)
^en-Q0966-answer

**en-Q0967** — He couldn't sleep because of the noise outside his window.

उसकी खिड़की के बाहर इतना शोर हो रहा था कि वह सो नहीं पा रहा था।

Expected form: **the**

Why: Articles, countability and reference. [[English#^en-Q0967|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%20couldn%27t%20sleep%20because%20of%20the%20noise%20outside%20his%20window.)
^en-Q0967-answer

**en-Q0968** — He couldn't sleep because of the noise outside his window.

उसकी खिड़की के बाहर इतना शोर हो रहा था कि वह सो नहीं पा रहा था।

Expected form: **the**

Why: Articles, countability and reference. [[English#^en-Q0968|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%20couldn%27t%20sleep%20because%20of%20the%20noise%20outside%20his%20window.)
^en-Q0968-answer

**en-Q0969** — Do you feel any pain in your stomach?

क्या आपको पेट में दर्द महसूस हो रहा है?

Expected form: **any**

Why: Articles, countability and reference. [[English#^en-Q0969|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Do%20you%20feel%20any%20pain%20in%20your%20stomach%3F)
^en-Q0969-answer

**en-Q0970** — Do you feel any pain in your stomach?

क्या आपको पेट में दर्द महसूस हो रहा है?

Why: Articles, countability and reference. [[English#^en-Q0970|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Do%20you%20feel%20any%20pain%20in%20your%20stomach%3F)
^en-Q0970-answer

**en-Q0971** — Their conversation was carried on for about an hour.

उनकी बातचीत लगभग एक घंटे तक चलती रही।

Why: Articles, countability and reference. [[English#^en-Q0971|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Their%20conversation%20was%20carried%20on%20for%20about%20an%20hour.)
^en-Q0971-answer

**en-Q0972** — Their conversation was carried on for about an hour.

उनकी बातचीत लगभग एक घंटे तक चलती रही।

Article choice reflects reference and countability. A/an selects a singular countable noun and follows the initial sound, not the first letter. Research and evidence are normally uncountable in academic uses; experience can change countability with meaning.

Why: Articles, countability and reference. [[English#^en-Q0972|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Their%20conversation%20was%20carried%20on%20for%20about%20an%20hour.)
^en-Q0972-answer

**en-Q0973** — We need to look for a gas station because this car will soon run out of gas.

हमे पेट्रोल पम्प ढूँढना चाहिए क्योंकि गाड़ी में पेट्रोल खतम होने वाला है।

Expected form: **a**

Why: Articles, countability and reference. [[English#^en-Q0973|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=We%20need%20to%20look%20for%20a%20gas%20station%20because%20this%20car%20will%20soon%20run%20out%20of%20gas.)
^en-Q0973-answer

**en-Q0974** — We need to look for a gas station because this car will soon run out of gas.

हमे पेट्रोल पम्प ढूँढना चाहिए क्योंकि गाड़ी में पेट्रोल खतम होने वाला है।

Expected form: **a**

Why: Articles, countability and reference. [[English#^en-Q0974|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=We%20need%20to%20look%20for%20a%20gas%20station%20because%20this%20car%20will%20soon%20run%20out%20of%20gas.)
^en-Q0974-answer

**en-Q0975** — Barcelona is the capital city of Catalonia and the second largest city in Spain.

बार्सेलोना केटलोनिआ की राजधानी और स्पेन का दूसरा सबसे बड़ा शहर है।

Expected form: **the**

Why: Articles, countability and reference. [[English#^en-Q0975|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Barcelona%20is%20the%20capital%20city%20of%20Catalonia%20and%20the%20second%20largest%20city%20in%20Spain.)
^en-Q0975-answer

**en-Q0976** — Barcelona is the capital city of Catalonia and the second largest city in Spain.

बार्सेलोना केटलोनिआ की राजधानी और स्पेन का दूसरा सबसे बड़ा शहर है।

Why: Articles, countability and reference. [[English#^en-Q0976|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Barcelona%20is%20the%20capital%20city%20of%20Catalonia%20and%20the%20second%20largest%20city%20in%20Spain.)
^en-Q0976-answer

**en-Q0977** — Could you send someone up to make the bed?

आप किसी को बिस्तर बनाने के लिए भेज सकते हैं क्या?

Why: Articles, countability and reference. [[English#^en-Q0977|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Could%20you%20send%20someone%20up%20to%20make%20the%20bed%3F)
^en-Q0977-answer

**en-Q0978** — Could you send someone up to make the bed?

आप किसी को बिस्तर बनाने के लिए भेज सकते हैं क्या?

Article choice reflects reference and countability. A/an selects a singular countable noun and follows the initial sound, not the first letter. Research and evidence are normally uncountable in academic uses; experience can change countability with meaning.

Why: Articles, countability and reference. [[English#^en-Q0978|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Could%20you%20send%20someone%20up%20to%20make%20the%20bed%3F)
^en-Q0978-answer

**en-Q0979** — It's an absolute waste of time to wait any longer.

और इंतेज़ार करना समय की सरासर बर्बादी होगी।

Expected form: **an**

Why: Articles, countability and reference. [[English#^en-Q0979|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=It%27s%20an%20absolute%20waste%20of%20time%20to%20wait%20any%20longer.)
^en-Q0979-answer

**en-Q0980** — It's an absolute waste of time to wait any longer.

और इंतेज़ार करना समय की सरासर बर्बादी होगी।

Expected form: **an**

Why: Articles, countability and reference. [[English#^en-Q0980|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=It%27s%20an%20absolute%20waste%20of%20time%20to%20wait%20any%20longer.)
^en-Q0980-answer

**en-Q0981** — He had nothing to do with the case.

उसका इस केस के साथ कोई लेना-देना नहीं था।

Expected form: **the**

Why: Articles, countability and reference. [[English#^en-Q0981|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%20had%20nothing%20to%20do%20with%20the%20case.)
^en-Q0981-answer

**en-Q0982** — He had nothing to do with the case.

उसका इस केस के साथ कोई लेना-देना नहीं था।

Why: Articles, countability and reference. [[English#^en-Q0982|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%20had%20nothing%20to%20do%20with%20the%20case.)
^en-Q0982-answer

**en-Q0983** — Tom was in New York at the time.

उस समय टॉम न्यूयॉर्क में था।

Why: Articles, countability and reference. [[English#^en-Q0983|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Tom%20was%20in%20New%20York%20at%20the%20time.)
^en-Q0983-answer

**en-Q0984** — Tom was in New York at the time.

उस समय टॉम न्यूयॉर्क में था।

Article choice reflects reference and countability. A/an selects a singular countable noun and follows the initial sound, not the first letter. Research and evidence are normally uncountable in academic uses; experience can change countability with meaning.

Why: Articles, countability and reference. [[English#^en-Q0984|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Tom%20was%20in%20New%20York%20at%20the%20time.)
^en-Q0984-answer

**en-Q0985** — This is a plant unique to this country.

यह पौधा केवल इस देश में ही पाया जाता है।

Expected form: **a**

Why: Articles, countability and reference. [[English#^en-Q0985|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=This%20is%20a%20plant%20unique%20to%20this%20country.)
^en-Q0985-answer

**en-Q0986** — This is a plant unique to this country.

यह पौधा केवल इस देश में ही पाया जाता है।

Expected form: **a**

Why: Articles, countability and reference. [[English#^en-Q0986|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=This%20is%20a%20plant%20unique%20to%20this%20country.)
^en-Q0986-answer

**en-Q0987** — Did you give the money back to your mother?

क्या तुमने अपनी माँ को पैसे लौटा दिए?

Expected form: **the**

Why: Articles, countability and reference. [[English#^en-Q0987|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Did%20you%20give%20the%20money%20back%20to%20your%20mother%3F)
^en-Q0987-answer

**en-Q0988** — Did you give the money back to your mother?

क्या तुमने अपनी माँ को पैसे लौटा दिए?

Why: Articles, countability and reference. [[English#^en-Q0988|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=Did%20you%20give%20the%20money%20back%20to%20your%20mother%3F)
^en-Q0988-answer

**en-Q0989** — And what will be the result of that?

और उसका नतीजा क्या होगा?

Why: Articles, countability and reference. [[English#^en-Q0989|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=And%20what%20will%20be%20the%20result%20of%20that%3F)
^en-Q0989-answer

**en-Q0990** — And what will be the result of that?

और उसका नतीजा क्या होगा?

Article choice reflects reference and countability. A/an selects a singular countable noun and follows the initial sound, not the first letter. Research and evidence are normally uncountable in academic uses; experience can change countability with meaning.

Why: Articles, countability and reference. [[English#^en-Q0990|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=And%20what%20will%20be%20the%20result%20of%20that%3F)
^en-Q0990-answer

**en-Q0991** — His younger sister is a well-known TV star.

उसकी छोटी बहन बहुत जानीमानी टीवी स्टार है।

Expected form: **a**

Why: Articles, countability and reference. [[English#^en-Q0991|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=His%20younger%20sister%20is%20a%20well-known%20TV%20star.)
^en-Q0991-answer

**en-Q0992** — His younger sister is a well-known TV star.

उसकी छोटी बहन बहुत जानीमानी टीवी स्टार है।

Expected form: **a**

Why: Articles, countability and reference. [[English#^en-Q0992|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=His%20younger%20sister%20is%20a%20well-known%20TV%20star.)
^en-Q0992-answer

**en-Q0993** — In Greek mythology, Hermes, the son of Zeus, is the messenger of the gods.

यूनानी पुराणों में, ज़्यूस के पुत्र, हरमीस, देवताओं के दूत थे।

Expected form: **the**

Why: Articles, countability and reference. [[English#^en-Q0993|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=In%20Greek%20mythology%2C%20Hermes%2C%20the%20son%20of%20Zeus%2C%20is%20the%20messenger%20of%20the%20gods.)
^en-Q0993-answer

**en-Q0994** — In Greek mythology, Hermes, the son of Zeus, is the messenger of the gods.

यूनानी पुराणों में, ज़्यूस के पुत्र, हरमीस, देवताओं के दूत थे।

Why: Articles, countability and reference. [[English#^en-Q0994|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=In%20Greek%20mythology%2C%20Hermes%2C%20the%20son%20of%20Zeus%2C%20is%20the%20messenger%20of%20the%20gods.)
^en-Q0994-answer

**en-Q0995** — He went to Rome, where he saw a lot of old buildings.

वह रोम गया, जहां उसे कई पुरानी इमारतें दिखीं।

Why: Articles, countability and reference. [[English#^en-Q0995|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%20went%20to%20Rome%2C%20where%20he%20saw%20a%20lot%20of%20old%20buildings.)
^en-Q0995-answer

**en-Q0996** — He went to Rome, where he saw a lot of old buildings.

वह रोम गया, जहां उसे कई पुरानी इमारतें दिखीं।

Article choice reflects reference and countability. A/an selects a singular countable noun and follows the initial sound, not the first letter. Research and evidence are normally uncountable in academic uses; experience can change countability with meaning.

Why: Articles, countability and reference. [[English#^en-Q0996|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=He%20went%20to%20Rome%2C%20where%20he%20saw%20a%20lot%20of%20old%20buildings.)
^en-Q0996-answer

**en-Q0997** — We can hear the church bell every morning.

हमें हर सुबह चर्च की घंटी सुनाई देती है।

Expected form: **the**

Why: Articles, countability and reference. [[English#^en-Q0997|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=We%20can%20hear%20the%20church%20bell%20every%20morning.)
^en-Q0997-answer

**en-Q0998** — We can hear the church bell every morning.

हमें हर सुबह चर्च की घंटी सुनाई देती है।

Expected form: **the**

Why: Articles, countability and reference. [[English#^en-Q0998|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=We%20can%20hear%20the%20church%20bell%20every%20morning.)
^en-Q0998-answer

**en-Q0999** — I missed my stop. How long does it take to reach the next stop?

मेरा स्टॉप छूट गया। अगला स्टॉप कितनी देर में आएगा?

Expected form: **the**

Why: Articles, countability and reference. [[English#^en-Q0999|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20missed%20my%20stop.%20How%20long%20does%20it%20take%20to%20reach%20the%20next%20stop%3F)
^en-Q0999-answer

**en-Q1000** — I missed my stop. How long does it take to reach the next stop?

मेरा स्टॉप छूट गया। अगला स्टॉप कितनी देर में आएगा?

Why: Articles, countability and reference. [[English#^en-Q1000|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=eng&query=I%20missed%20my%20stop.%20How%20long%20does%20it%20take%20to%20reach%20the%20next%20stop%3F)
^en-Q1000-answer


## Read and speak

Read the native sentence first, identify its predicate and one grammar form, then check the translation. Say it aloud and change one detail.

### Learning with a clear purpose

I am learning a new language. Each day, I read a short text and listen to clear examples. I write useful words in a notebook. When I make a mistake, I check the rule and try again. My goal is to understand people and express my ideas clearly.

Read the paragraph as a foundation example. Notice present habits, conditional time reference and infinitive purpose.

### History: evidence and perspective

Two accounts of the same event need not differ because one author is dishonest. Each may have had access to different evidence, written for a different audience or considered a different question important. A historian compares sources before choosing an interpretation. The date of a document, its intended reader and the circumstances of its production help establish what it can reveal. Silence is also difficult to interpret: the absence of a statement is not necessarily evidence that an event never occurred. A careful account distinguishes what is directly documented from what is inferred.

Identify how the writer distinguishes evidence, interpretation and uncertainty. Summarise the reasoning in your own words.

![[Resources/Audio/en/Reading passage.mp3]]

**This is the opposite of what I expected.**

मुझे जो अपेक्षा थी उसके यह विपरीत है।

**My grandfather was murdered during the Second World War.**

दूसरे विश्वयुद्ध के दौरान मेरे दादा का खून हुआ था।

**I became friends with him while I was in Taiwan.**

तैवान में रहते समय मेरी उससे दोस्ती हुई।

**He entered the room slowly by that door.**

वह उस दरवाज़े से धीरे से कमरे में घुसा।

**Traveling by boat takes longer than going by car.**

नाव के सफ़र में कार से ज्यादा समय लगता है.

**Are you saying my life is in danger?**

क्या तुम कह रहे हो कि मेरी जान ख़तरे में है?

**Men whose mothers had breast cancer run a higher risk of developing prostate cancer.**

जिन मर्दों की माताओं को छाती का कैंसर था उनको प्रोस्ट्रेट कैंसर होने का अधिक खदशा रहता है |

**Terrorists attacked the World Trade Center in New York City in 2001.**

२००१ में न्यूयॉर्क शहर में आतंकवादियों वर्ल्ड ट्रेड सेंटर पर हमला किया।

**I'm not saying that your answers are always wrong.**

मैं यह नहीं कह रही हूँ कि तुम्हारे उत्तर हमेशा ग़लत होते हैं।

**The heron had to hunt for food every day.**

बगुले को हर दिन भोजन के लिए शिकार करना पड़ता था।

**Goals determine what you are going to be.**

हमारे लक्ष्य निर्धारित करते हैं कि हम क्या बनने जा रहे हैं।

**Opening the door, I found a stranger standing there.**

मैंने जब दरवाज़ा खोला, मुझे एक अजनबी वहाँ खड़ा मिला।

**Do you keep your money in a bank?**

क्या आप अपने पैसे बैंक में रखते हैं?

**Keep hold of my hand if you're afraid.**

मेरा हाथ पकड़लो अगर तुम्हे डर लग रहा है तो।

**She will become a doctor in two years.**

वह दो सालों में डॉक्टर बन जाएगी।

## Professional writing

Write an introduction, a polite request, an explanation of a finding, a summary of a passage and a tactful disagreement. Use the professional/advanced lessons for models.

## PDF edition

[[Resources/PDFs/English.pdf|Open the complete printable book]]
