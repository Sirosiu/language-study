# Mandarin Chinese study

[[Mandarin Chinese|Open the complete Mandarin Chinese course note]]

Audio and the printable PDF are in Resources. This vault contains one language.

[[Sources and licenses]]
