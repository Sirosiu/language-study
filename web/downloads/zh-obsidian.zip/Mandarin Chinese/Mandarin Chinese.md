# Mandarin Chinese

Near-native ambition - advanced Mandarin and written Chinese

Everything for this language is in this note. Open a rule, read its examples and follow its practice link. Answers stay in this same note.

[[Start Here|All languages]] · [[Sources and licenses|Sources]]

## Start reading

### 汉字、拼音 (Hànzì / Pīnyīn)

| Written form | Name / reading | Related forms |
|---|---|---|
| b | unaspirated p  |  ·  ·  |
| p | aspirated p  |  ·  ·  |
| m | m  |  ·  ·  |
| f | f  |  ·  ·  |
| d | unaspirated t  |  ·  ·  |
| t | aspirated t  |  ·  ·  |
| n | n  |  ·  ·  |
| l | l  |  ·  ·  |
| g | unaspirated k  |  ·  ·  |
| k | aspirated k  |  ·  ·  |
| h | fricative, often /x/  |  ·  ·  |
| j | unaspirated palatal affricate  |  ·  ·  |
| q | aspirated palatal affricate  |  ·  ·  |
| x | palatal fricative  |  ·  ·  |
| zh | retroflex affricate  |  ·  ·  |
| ch | aspirated retroflex affricate  |  ·  ·  |
| sh | retroflex fricative  |  ·  ·  |
| r | retroflex sound  |  ·  ·  |
| z | unaspirated /ts/  |  ·  ·  |
| c | aspirated /ts/  |  ·  ·  |
| s | s  |  ·  ·  |
| a | a  |  ·  ·  |
| o | o  |  ·  ·  |
| e | unrounded back vowel in many syllables  |  ·  ·  |
| i | i; syllabic values after z/c/s/zh/ch/sh/r  |  ·  ·  |
| u | u  |  ·  ·  |
| ü | front rounded /y/  |  ·  ·  |
| ā á ǎ à a | first, second, third, fourth, neutral tone  |  ·  ·  |

![[Resources/Audio/zh/Script and first phrases.mp3]]

The player above is synthetic speech. Word tracks below work offline.

### Characters are not an alphabet

Mandarin writing uses characters. Pinyin is a Roman-letter pronunciation notation, not the usual replacement for characters. Begin with both. This course uses simplified characters; traditional counterparts are a separate recognition extension.

### Build a pinyin syllable

An initial combines with a final and a tone: m + a + first tone → mā. Finals can contain more than one vowel or a nasal: ai, ei, ao, ou, an, en, ang, eng, ong. y/w often spell syllables with no consonantal initial. After j/q/x/y, written u normally represents ü.

### Learn tones in phrases

mā 妈 = mother; má 麻 = hemp; mǎ 马 = horse; mà 骂 = scold. Third tone is often low without a full rise in connected speech; before another third tone it commonly becomes rising. 一 and 不 change tone in predictable contexts. Written pinyin usually shows citation tones; audio carries connected-speech changes.

### Combine character components

氵 often suggests water: 河 = river. A component may hint at meaning, pronunciation, both or neither clearly in modern use. Learn a character’s components without assuming a component guarantees its pronunciation.

### Make words from characters

学 = learn; 生 = life/birth; 学生 = student. 学校 = school; 大学 = university. A character can occur in many words; the word’s meaning is not always a literal sum.

### Use stroke principles

Practise horizontal before vertical, left before right, and top before bottom as general guides. Enclosures have special sequences and exceptions. Check an actual stroke-order reference for each new character; these rules do not determine every stroke order.

### Common character components

Learn a component as a recognition aid: 氵 water; 亻 person; 扌 hand; 口 mouth; 心/忄 heart or feelings; 木 wood; 日 sun/day; 月 moon or flesh in different histories; 女 woman; 宀 roof; 艹 plants; 讠 speech; 钅 metal; 饣 food; 火/灬 fire; 土 earth; 足 foot; 目 eye; 耳 ear; 门 gate; 纟 silk/thread; 辶 movement; 贝 shell/money; 车 vehicle. A component is not a guaranteed definition, and the dictionary radical used for lookup can differ from the most memorable component.

**你好。**

Hello.

**我在学中文。**

I am learning Chinese.

**请再说一遍。**

Please say it again.

**这个词是什么意思？**

What does this word mean?

### Grammar terms in plain English

**Noun** — A word naming a person, thing or idea: student, book, freedom.

**Verb** — A word describing an action or state: read, know, be.

**Subject** — The participant linked to the main verb’s subject pattern. In The student reads a book, the student is the subject.

**Object** — A participant selected by a verb. In The student reads a book, a book is the direct object.

**Agreement** — One word changes to match another, for example an adjective matching a noun’s gender and number.

**Case** — A noun/pronoun form marking its relationship in a sentence. Cases can mark subjects, objects, possession or relations usually expressed by English prepositions.

**Gender** — A grammatical noun class. It does not always describe the sex of a person or any physical property.

**Tense** — A verb system that relates a situation to a time, often past or non-past.

**Aspect** — How a situation is viewed: unfolding, completed, habitual, experienced or in a resulting state.

**Infinitive** — A non-finite verb form often used for a dictionary entry or a complement. It does not by itself give the ordinary person/tense pattern.

**Participle** — A verb-derived form used in compound predicates or as a modifier; its exact function depends on the language and construction.

**Clause** — A unit organised around a predicate. One sentence can contain several clauses.

**Register** — Language choices suited to a situation: casual conversation, polite requests, academic writing or another context.

## Grammar, examples and practice

### Pinyin, tones and character learning

Pinyin represents Mandarin sounds; English letter values are unreliable guides. The four lexical tones and neutral tone need audio practice. Third tone is frequently low in connected speech rather than a full isolated dip and rise. Before another third tone, the first commonly changes to a rising contour; spelling usually preserves the underlying third-tone marks. 一 and 不 have context-dependent tone changes.
Learn characters as meaningful components and words, not as arbitrary pictures. A radical helps classification and lookup; a phonetic component can suggest pronunciation imperfectly. 学, 学生 and 学习 should be learned as related but distinct entries. Stroke order generally follows top-to-bottom and left-to-right patterns with exceptions; use a reliable animated model when practising an unfamiliar character. Do not mistake knowledge of a character's English gloss for knowledge of every word containing it.

**你好 nǐ hǎo**

Hello. The first underlying third tone is commonly realised with a rising contour before the second third tone.

**学习 xuéxí / 学生 xuésheng**

to study / student Word boundaries and readings matter; components are not a complete translation method.

<details><summary>Why should pinyin be reduced gradually?</summary>

It can support pronunciation initially, but continuous dependence prevents fluent character recognition. Preserve it on vocabulary cards while reading simple native-script sentences.

</details>

<details><summary>Does a radical reliably determine the modern meaning and pronunciation?</summary>

No. Radicals are useful clues and indexing tools; historical development and sound change make many relationships imperfect.

</details>

### Sentence order, topic and omitted arguments

A basic sentence often follows subject + verb + object, but Mandarin frequently organises information as topic + comment. 这本书，我看过 presents the book as what the comment is about. A topic need not be the grammatical subject. Subjects and objects can be omitted when recoverable; identify their referents from discourse rather than inserting an English pronoun mechanically.
Time expressions usually precede the verb, and place expressions commonly appear before the main verb with 在. 是 identifies or classifies but is not inserted before every adjective. 很 often occurs before a simple adjectival predicate without necessarily meaning an emphatic very. Negation and questions interact with the predicate: 不 often negates habitual or general situations; 没 or 没有 denies occurrence or possession in appropriate contexts.

**这本书，我已经看过了。 Zhè běn shū, wǒ yǐjīng kàn guo le.**

I have already read this book. The book is the topic; 过 marks experience and 了 contributes current relevance or a changed situation.

**他今天在图书馆学习。 Tā jīntiān zài túshūguǎn xuéxí.**

He is studying in the library today. Time and location precede the lexical verb.

#### Personal pronouns

Mandarin pronouns do not conjugate a verb. 他 and 她 differ in writing but share spoken tā. Context can omit a known subject; omission is a discourse choice rather than a new verb ending.

**他们不会找到汤姆。**

They won't find Tom.

**来吧，我们一起去。**

Come on, let's go.

![[Resources/Audio/zh/Rule 01.mp3]]

[[Mandarin Chinese#^zh-Q0001|Practise this rule (50 questions)]]

#### Identity with 是

是 commonly links identity or classification. Ordinary adjectival predicates do not require 是 merely because English uses be. 是 also appears in focus constructions, so read the whole predicate.

**莎士比亞是一位作家的名字。**

Shakespeare is the name of a writer.

**哪個比較重，鉛還是黃金？**

Which is heavier, lead or gold?

![[Resources/Audio/zh/Rule 02.mp3]]

[[Mandarin Chinese#^zh-Q0051|Practise this rule (50 questions)]]

#### Possession and existence 有

有 expresses possession or existence. Its common negation is 没有, not 不有. A location phrase can precede an existence statement to introduce a new referent.

**汤姆有玛丽的地址。**

Tom has Mary's address.

**他的英文作文沒有甚麼錯處。**

Errors are few, if any, in his English composition.

![[Resources/Audio/zh/Rule 03.mp3]]

[[Mandarin Chinese#^zh-Q0101|Practise this rule (50 questions)]]

#### Location and ongoing 在

在 can locate an entity or precede a verb for an ongoing action. It also appears in pre-verbal location phrases. The following phrase and predicate determine its role.

**实在抱歉，老板在睡觉。请您明天再来。**

I'm sorry, my boss is sleeping right now. Please come back tomorrow.

**汽车尾气在城镇里造成了严重的污染。**

Car exhaust causes serious pollution in towns.

![[Resources/Audio/zh/Rule 04.mp3]]

[[Mandarin Chinese#^zh-Q0151|Practise this rule (50 questions)]]

<details><summary>Correct the idea that 是 is required before every adjective.</summary>

她很忙 is a normal predicate: she is busy. 她是忙 requires a special contrastive context rather than functioning as a default translation of is.

</details>

<details><summary>Ask Have you read this book? using 过.</summary>

你看过这本书吗？ Nǐ kàn guo zhè běn shū ma? 过 asks about experience.

</details>

### Aspect: 了, 过, 着 and ongoing activity

Mandarin does not conjugate verbs for past tense. Aspect presents how a situation unfolds. Verb-suffix 了 often marks a bounded or completed event; sentence-final 了 often signals a changed situation or new relevance. They can coexist, and their interpretation depends on context. A sentence in the past does not automatically require 了.
过 marks experiential occurrence, 着 often a continuing state, and 在 or 正在 an ongoing action. 他坐着 describes a sitting posture; 他正在坐下 describes an action of sitting down. Negating an event often uses 没有 and omits event-perfective 了. Duration and result structures determine placement; avoid treating these particles as English tense endings.

**我以前住在北京。 Wǒ yǐqián zhù zài Běijīng.**

I used to live in Beijing. 以前 provides the past frame; no automatic past-tense suffix is needed.

**门开着。 Mén kāi zhe.**

The door is open. 着 presents a continuing state.

#### Negation 不 and 没

不 commonly negates habits, states and many intentions; 没/没有 commonly negates occurrence or possession. A completed-event 了 is normally not retained mechanically in a 没 negative.

**你千萬不要和你父母說這件事。**

You mustn't tell that to your parents.

**汤姆不能告诉玛丽他知道的所有事。**

Tom couldn't tell Mary everything he knew.

![[Resources/Audio/zh/Rule 05.mp3]]

[[Mandarin Chinese#^zh-Q0201|Practise this rule (50 questions)]]

#### Completion and change 了

了 can mark a completed/bounded event or a change of situation. Its position and surrounding structure matter. It is not a universal past-tense ending and can occur in future contexts.

**今天出现了很多问题。**

Today, many problems were encountered.

**我给了汤姆其中之一。**

I gave Tom one of those.

![[Resources/Audio/zh/Rule 09.mp3]]

[[Mandarin Chinese#^zh-Q0401|Practise this rule (50 questions)]]

#### Experience 过

Aspectual 过 indicates prior experience in suitable verb constructions. The same character can have lexical or complement uses. Negated experience commonly uses 没 ... 过.

**今晚我将在朋友家过夜。**

I will put up at my friend's tonight.

**我有些年没见过他了。**

I haven't seen him for years.

![[Resources/Audio/zh/Rule 10.mp3]]

[[Mandarin Chinese#^zh-Q0451|Practise this rule (50 questions)]]

#### State 着

Aspectual 着 often marks a maintained state or accompanying posture. It differs from pre-verbal 在 for a dynamic ongoing activity. Read its relation to the verb rather than treating every occurrence identically.

**水面浮着一片落葉。**

A fallen leaf floated on the surface of the water.

**汤姆试着杀死玛丽。**

Tom tried to kill Mary.

![[Resources/Audio/zh/Rule 11.mp3]]

[[Mandarin Chinese#^zh-Q0501|Practise this rule (50 questions)]]

<details><summary>Distinguish 我看了这本书 and 我看过这本书.</summary>

The first presents reading as a bounded event in context; the second foregrounds having the experience of reading it. Neither maps mechanically to one English tense.

</details>

<details><summary>Negate 我买了票.</summary>

我没买票。 Wǒ méi mǎi piào. 没 negates the occurrence, and event-perfective 了 is normally absent.

</details>

### Classifiers, quantification and noun modification

A numeral or demonstrative normally combines with a classifier before a count noun: 一本书, 这位老师. 个 is widespread but is not a universal replacement in careful usage. Learn classifier-noun combinations and meaningful contrasts, such as a sheet, volume, unit or person. Measure expressions can quantify mass nouns.
的 commonly links modifiers to nouns. A relative-like modifier precedes the head noun: 我昨天买的书, the book I bought yesterday. Complex noun phrases can contain several layers; find the final head first. 的, 地 and 得 have distinct functions in standard writing: nominal modification, adverbial modification and complements after predicates. Contemporary usage and fixed expressions create exceptions; their shared pronunciation does not make them interchangeable.

**我昨天买的那本书 Wǒ zuótiān mǎi de nà běn shū**

that book I bought yesterday The clause modifies the final noun; 那 + 本 identifies the book.

**他认真地解释，解释得很清楚。 Tā rènzhēn de jiěshì, jiěshì de hěn qīngchu.**

He explains carefully and makes the explanation clear. 地 marks adverbial manner; 得 introduces the degree/result-like complement.

#### Attributive 的

的 commonly links a modifier to a noun and marks possession. Mandarin modifiers precede their head noun. The written homophones 的/地/得 have distinct conventional functions.

**那个男孩子见到鬼的时候吓了一跳。**

The boy fell of fright when he saw a ghost.

**國際間的紛爭一定要用和平的方法來解決。**

International disputes must be settled peacefully.

![[Resources/Audio/zh/Rule 06.mp3]]

[[Mandarin Chinese#^zh-Q0251|Practise this rule (50 questions)]]

#### Classifiers

A numeral/demonstrative commonly combines with a classifier before a counted noun. 本 is common for books, 张 for flat objects, 位 for people respectfully. Classifier choice is lexical and meaning-dependent.

**汤姆犯了个大失误。**

Tom has made a big mistake.

**我们已经等了好几个小时了。**

We’ve been waiting for hours.

![[Resources/Audio/zh/Rule 07.mp3]]

[[Mandarin Chinese#^zh-Q0301|Practise this rule (50 questions)]]

#### Demonstratives

Demonstratives distinguish near/far or discourse reference. Counted noun phrases usually include the appropriate classifier. 这/那 also occur in other constructions, so determine whether a noun phrase follows.

**汤姆如果想通过这门课，就需要加劲学习。**

Tom needs to study more if he hopes to pass this class.

**这件事他铭记于心。**

The incident was etched in his memory.

![[Resources/Audio/zh/Rule 08.mp3]]

[[Mandarin Chinese#^zh-Q0351|Practise this rule (50 questions)]]

<details><summary>Build three books with the common classifier for books.</summary>

三本书 sān běn shū. 本 classifies bound volumes.

</details>

<details><summary>Translate the method we used.</summary>

我们使用的方法 wǒmen shǐyòng de fāngfǎ. The modifying clause precedes 方法.

</details>

### Complements, 把 and 被

Result complements express the result of an action: 看懂 understand by reading, 写完 finish writing. Potential complements indicate whether that result can be achieved: 看得懂 / 看不懂. Direction complements can be spatial or extended metaphorically. Identify the whole verb-complement construction before translating.
把 places an affected, identifiable object before the verb and normally requires a predicate that says what happens to it, rather than a bare undifferentiated verb. 我把报告写完了 specifies completion. 被 introduces a passive perspective; negative effects are common but not obligatory. Passive and 把 sentences are discourse choices, not stylistic upgrades to every basic sentence.

**这个句子我看不懂。 Zhège jùzi wǒ kàn bu dǒng.**

I cannot understand this sentence by reading it. Potential negative complement focuses on failure to achieve understanding.

**请把结果写在这里。 Qǐng bǎ jiéguǒ xiě zài zhèlǐ.**

Please write the results here. 把 foregrounds the affected object; location completes the predicate.

#### Disposal 把

A 把 construction places a disposal-affected object before the verb. It commonly needs a suitably specific object and a predicate describing its handling/result. 把 is also a classifier in other contexts.

**把椅子挪一挪靠近桌子。**

Move the chair nearer to the desk.

**可以把新地址告訴我嗎？**

Please let me know your new address.

![[Resources/Audio/zh/Rule 12.mp3]]

[[Mandarin Chinese#^zh-Q0551|Practise this rule (50 questions)]]

#### Passive 被

被 introduces a passive-like affected-participant construction. The agent can be expressed or omitted. Passive meaning does not automatically imply the same word order as English.

**道路法规必须被严格遵守。**

The rule of the road must be strictly observed.

**人类登上月球、柏林墙倒下，世界被我们的科学和想像被连接在一起。**

A man touched down on the moon. A wall came down in Berlin. A world was connected by our own science and imagination.

![[Resources/Audio/zh/Rule 13.mp3]]

[[Mandarin Chinese#^zh-Q0601|Practise this rule (50 questions)]]

#### Result and degree 得

得 can introduce degree/manner complements after a verb; it also occurs in potential and lexical constructions. A complement may require repeating a verb when an object is present.

**瑪麗長得像她媽媽。**

Mary looks like her mother.

**他晚上回來得很晚。**

He returned very late at night.

![[Resources/Audio/zh/Rule 14.mp3]]

[[Mandarin Chinese#^zh-Q0651|Practise this rule (50 questions)]]

#### Ability and intention

会, 能 and 可以 differ in learned ability, possibility and permission, with overlap in context. 要 and 想 express different strengths of intention/desire. These words do not trigger verb conjugation.

**這台相機至少要花費500美元。**

The camera will cost at least $500.

**步行到車站要花十分鐘。**

It's ten minutes' walk to the station.

![[Resources/Audio/zh/Rule 20.mp3]]

[[Mandarin Chinese#^zh-Q0951|Practise this rule (50 questions)]]

<details><summary>Express I finished reading the report.</summary>

我看完报告了。 Wǒ kàn wán bàogào le. 看完 supplies the completion result.

</details>

<details><summary>Why is 我把书看 usually incomplete as a neutral sentence?</summary>

A 把 predicate normally specifies an effect, result, location or comparable development. 我把书看完了 supplies the missing result.

</details>

### Comparison, condition and logical scope

比 introduces comparison: A 比 B 更清楚. 没有 can express being less than a comparator; 不比 does not assert a simple less-than relation in the same way. 越……越…… expresses a proportional relationship. Condition pairs include 如果……就……, 只要……就…… and 只有……才……; sufficient and necessary conditions are not equivalent.
Learn the scope of 都, 也, 只, 不 and other operators. 不都 means not all, while 都不 means all not or none, with context. Formal argument uses 虽然……但是…… for concession and 因为……所以…… for cause and consequence. English often avoids using both although and but in one structure, but paired Chinese connectors are conventional.

**只有证据充分，才能得出结论。 Zhǐyǒu zhèngjù chōngfèn, cái néng déchū jiélùn.**

Only with sufficient evidence can a conclusion be drawn. 只有 ... 才 presents a necessary condition.

**这些结果不都可靠。 Zhèxiē jiéguǒ bù dōu kěkào.**

Not all these results are reliable. Negation scopes over the universal quantifier.

#### Comparison 比

比 introduces a comparison standard. The adjective does not generally need 更 in the simplest pattern. Compare equality with 跟/和 ... 一样 rather than mechanically adding 比 to every comparison.

**信濃川比日本的任何一條河川更長。**

The Shinano River is longer than any river in Japan.

**她的氣色看起來比以前好。**

She looks better than before.

![[Resources/Audio/zh/Rule 15.mp3]]

[[Mandarin Chinese#^zh-Q0701|Practise this rule (50 questions)]]

#### Question particles

吗 commonly turns a statement into a yes/no question. 呢 can ask about a topic or continuation. Question-word questions ordinarily do not add 吗 merely because they are questions.

**抱歉，你能再说一遍吗？**

I'm sorry, could you say that again?

**您想知道为什么我要离开吗？**

Do you want to know why I quit?

![[Resources/Audio/zh/Rule 16.mp3]]

[[Mandarin Chinese#^zh-Q0751|Practise this rule (50 questions)]]

#### Question words

Mandarin question words commonly stay in the position of the unknown information. 谁 asks a person, 哪里 a place, and 几/多少 quantities. No English-style subject-auxiliary inversion is required.

**你为什么为我担忧？**

Why are you worried about me?

**你觉得对此该做什么？**

What do you think should be done about it?

![[Resources/Audio/zh/Rule 17.mp3]]

[[Mandarin Chinese#^zh-Q0801|Practise this rule (50 questions)]]

#### Conditions and concession

如果/要是 introduce conditions; 虽然 presents concession, often paired with 但是. 的话 can frame an if scenario. Connectors express relationships, not tense inflections.

**虽然听起来很奇怪，但是她说的的确是真的。**

Even though it sounds strange, what she said is true.

**如果你想使他人相信你的话，那就只说他已经相信的东西吧。**

If you want to be credible, tell people only what they believe.

![[Resources/Audio/zh/Rule 18.mp3]]

[[Mandarin Chinese#^zh-Q0851|Practise this rule (50 questions)]]

<details><summary>Contrast 只要 with 只有.</summary>

只要 typically introduces a sufficient condition; 只有 introduces a necessary condition followed by 才. Do not substitute one for the other mechanically.

</details>

<details><summary>Translate The more carefully we check, the easier it is to find errors.</summary>

我们检查得越仔细，就越容易发现错误。 Wǒmen jiǎnchá de yuè zǐxì, jiù yuè róngyì fāxiàn cuòwù. Other natural wordings are possible.

</details>

### Formal written Chinese and academic vocabulary

Formal written Chinese uses compact nominal expressions and discourse markers such as 然而, 因此, 此外 and 综上所述. 关于 introduces a topic concerning; 对于 frames a relation to a matter or participant; their distributions overlap but are not universally interchangeable. 所 structures and compact relative modification are frequent in formal prose. Classical Chinese is a separate long-term study area, not automatically mastered through modern Mandarin.
Common research terms include 研究 study, 方法 method, 结果 result, 证据 evidence, 假设 hypothesis, 结论 conclusion and 局限 limitation. Translation depends on domain: significant may be 重要 for importance or 显著 for statistical significance in context. Keep technical terms in collocations and check a specialist source.

**现有证据尚不足以支持这一结论。 Xiànyǒu zhèngjù shàng bù zú yǐ zhīchí zhè yī jiélùn.**

The current evidence is not yet sufficient to support this conclusion. 尚, 不足以 and 这一 contribute formal register and evidential limitation.

**所采用的方法 suǒ cǎiyòng de fāngfǎ**

the method adopted 所 + verb + 的 forms a formal modifying expression.

#### Cause and inference

因为 supplies a reason; 所以/因此 supply a consequence. 可能 limits certainty and 应该 can indicate expectation or obligation. Translate the force of the claim, not just the dictionary gloss.

**你自己应该知道吧。**

You must know yourself.

**因为下雨了，球场上没有很多观众。**

There weren't many spectators at the game because of the rain.

![[Resources/Audio/zh/Rule 19.mp3]]

[[Mandarin Chinese#^zh-Q0901|Practise this rule (50 questions)]]

<details><summary>Distinguish 重要 from 显著 in a research context.</summary>

重要 concerns importance; 显著 can denote a marked difference or statistical significance. The latter does not automatically imply practical importance.

</details>

<details><summary>Write a cautious conclusion with 可能.</summary>

这些结果可能反映了样本之间的差异。 These results may reflect differences between samples. Preserve possibility rather than claiming proof.

</details>

### Advanced reading, pragmatics and revision

Original teaching passage: 一种解释即使听起来合理，也未必得到充分的证据支持。研究者不仅需要说明自己的假设如何解释观察结果，还需要考虑其他解释是否同样成立。因此，阅读研究报告时，应当区分数据本身、作者的推断以及尚未解决的问题。
Translation: Even if an explanation sounds reasonable, it is not necessarily supported by sufficient evidence. Researchers need not only explain how their hypothesis accounts for observations, but also consider whether other explanations are equally valid. Therefore, when reading a research report, one should distinguish the data themselves, the author's inferences and unresolved questions.
Notice the concession 即使 ... 也, the limitation 未必, the additive 不仅 ... 还 and the embedded 是否. In everyday communication, requests and refusals also depend on relationship and context. Politeness cannot be reduced to adding 请 before every sentence. Revise a translation for natural topic flow and conventional collocations, not just character-by-character fidelity.

**未必得到充分的证据支持**

not necessarily supported by sufficient evidence 未必 denies necessity, not every possibility of support.

**尚未解决的问题**

questions that have not yet been resolved A pre-nominal modifier compresses the temporal qualification.

<details><summary>Identify three different objects of 区分 in the passage.</summary>

数据本身, 作者的推断 and 尚未解决的问题: data, author inference and unresolved questions.

</details>

<details><summary>Write a 100-character summary without repeating whole sentences.</summary>

Preserve the distinction between plausibility and evidence, include alternative explanations and avoid turning 未必 into an absolute denial. Use the guide's accuracy and coherence rubric.

</details>

## Word bank and recordings

1,000 study entries, based on dictionary selections and authored teaching glosses. Learn a word in a phrase; consult the linked entry for additional senses.

<details><summary>Words 1–50</summary>

![[Resources/Audio/zh/Words 0001-0050.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [可以](https://en.wiktionary.org/wiki/%E5%8F%AF%E4%BB%A5#Chinese) | can; may | kě yǐ · verb |
| [自己](https://en.wiktionary.org/wiki/%E8%87%AA%E5%B7%B1#Chinese) | self; oneself | zì jǐ · pron |
| [不是](https://en.wiktionary.org/wiki/%E4%B8%8D%E6%98%AF#Chinese) | to not be | bú shì · verb |
| [公司](https://en.wiktionary.org/wiki/%E5%85%AC%E5%8F%B8#Chinese) | company; firm; corporation (Classifier: 個／个; 家; 間／间) | gōng sī · noun |
| [政府](https://en.wiktionary.org/wiki/%E6%94%BF%E5%BA%9C#Chinese) | government | zhèng fǔ · noun |
| [可能](https://en.wiktionary.org/wiki/%E5%8F%AF%E8%83%BD#Chinese) | possible; probable; likely | kě néng · adj |
| [工作](https://en.wiktionary.org/wiki/%E5%B7%A5%E4%BD%9C#Chinese) | to work (to be engaged in a mental or physical activity) | gōng zuò · verb |
| [如果](https://en.wiktionary.org/wiki/%E5%A6%82%E6%9E%9C#Chinese) | if | rú guǒ · conj |
| [知道](https://en.wiktionary.org/wiki/%E7%9F%A5%E9%81%93#Chinese) | to know (something); to be aware of | zhī dào · verb |
| [世界](https://en.wiktionary.org/wiki/%E4%B8%96%E7%95%8C#Chinese) | world | shì jiè · noun |
| [不能](https://en.wiktionary.org/wiki/%E4%B8%8D%E8%83%BD#Chinese) | cannot; must not; should not | bù néng · verb |
| [使用](https://en.wiktionary.org/wiki/%E4%BD%BF%E7%94%A8#Chinese) | to use; to utilize; to employ; to apply | shǐ yòng · verb |
| [但是](https://en.wiktionary.org/wiki/%E4%BD%86%E6%98%AF#Chinese) | but; however | dàn shì · conj |
| [政治](https://en.wiktionary.org/wiki/%E6%94%BF%E6%B2%BB#Chinese) | politics | zhèng zhì · noun |
| [人民](https://en.wiktionary.org/wiki/%E4%BA%BA%E6%B0%91#Chinese) | people (collectively, as members of society) | rén mín · noun |
| [其他](https://en.wiktionary.org/wiki/%E5%85%B6%E4%BB%96#Chinese) | other; else | qí tā · adj |
| [地方](https://en.wiktionary.org/wiki/%E5%9C%B0%E6%96%B9#Chinese) | place; region; area (Classifier: 個／个 m; 笪 c) | dì fāng · noun |
| [生活](https://en.wiktionary.org/wiki/%E7%94%9F%E6%B4%BB#Chinese) | life (activities in life) | shēng huó · noun |
| [所以](https://en.wiktionary.org/wiki/%E6%89%80%E4%BB%A5#Chinese) | therefore; so; consequently | suǒ yǐ · conj |
| [所有](https://en.wiktionary.org/wiki/%E6%89%80%E6%9C%89#Chinese) | all | suǒ yǒu · adj |
| [包括](https://en.wiktionary.org/wiki/%E5%8C%85%E6%8B%AC#Chinese) | to include; to consist of | bāo kuò · verb |
| [如何](https://en.wiktionary.org/wiki/%E5%A6%82%E4%BD%95#Chinese) | how; what; in what way | rú hé · adv |
| [A](https://en.wiktionary.org/wiki/A#Chinese) | to attack; to assault | A · verb |
| [重要](https://en.wiktionary.org/wiki/%E9%87%8D%E8%A6%81#Chinese) | important; significant; major | zhòng yào · adj |
| [文化](https://en.wiktionary.org/wiki/%E6%96%87%E5%8C%96#Chinese) | culture (Classifier: 個／个; 種／种) | wén huà · noun |
| [希望](https://en.wiktionary.org/wiki/%E5%B8%8C%E6%9C%9B#Chinese) | hope; wish (feeling of desire for something to happen) | xī wàng · noun |
| [提供](https://en.wiktionary.org/wiki/%E6%8F%90%E4%BE%9B#Chinese) | to provide; to offer; to supply | tí gōng · verb |
| [一定](https://en.wiktionary.org/wiki/%E4%B8%80%E5%AE%9A#Chinese) | fixed; specific; regular | yí dìng · adj |
| [不同](https://en.wiktionary.org/wiki/%E4%B8%8D%E5%90%8C#Chinese) | to be different; to differ; to disagree | bù tóng · verb |
| [不要](https://en.wiktionary.org/wiki/%E4%B8%8D%E8%A6%81#Chinese) | to not want | bú yào · verb |
| [研究](https://en.wiktionary.org/wiki/%E7%A0%94%E7%A9%B6#Chinese) | to research; to study | yán jiū · verb |
| [任何](https://en.wiktionary.org/wiki/%E4%BB%BB%E4%BD%95#Chinese) | any; all | rèn hé · adj |
| [因此](https://en.wiktionary.org/wiki/%E5%9B%A0%E6%AD%A4#Chinese) | because of this; thus; consequently | yīn cǐ · conj |
| [中心](https://en.wiktionary.org/wiki/%E4%B8%AD%E5%BF%83#Chinese) | center (point in the interior of a circle or sphere) | zhōng xīn · noun |
| [今天](https://en.wiktionary.org/wiki/%E4%BB%8A%E5%A4%A9#Chinese) | today | jīn tiān · noun |
| [代表](https://en.wiktionary.org/wiki/%E4%BB%A3%E8%A1%A8#Chinese) | to represent (to stand or act in place of, or be a political representative) | dài biǎo · verb |
| [支持](https://en.wiktionary.org/wiki/%E6%94%AF%E6%8C%81#Chinese) | to support; to back | zhī chí · verb |
| [而且](https://en.wiktionary.org/wiki/%E8%80%8C%E4%B8%94#Chinese) | furthermore; in addition; moreover | ér qiě · conj |
| [城市](https://en.wiktionary.org/wiki/%E5%9F%8E%E5%B8%82#Chinese) | city; town (Classifier: 個／个; 座) | chéng shì · noun |
| [教育](https://en.wiktionary.org/wiki/%E6%95%99%E8%82%B2#Chinese) | education; instruction; schooling | jiào yù · noun |
| [朋友](https://en.wiktionary.org/wiki/%E6%9C%8B%E5%8F%8B#Chinese) | friend (Classifier: 個／个 m c; 位 m c) | péng yǒu · noun |
| [目前](https://en.wiktionary.org/wiki/%E7%9B%AE%E5%89%8D#Chinese) | the present time; the current time; the current moment | mù qián · noun |
| [表示](https://en.wiktionary.org/wiki/%E8%A1%A8%E7%A4%BA#Chinese) | to express; to state; to indicate; to opine; to declare | biǎo shì · verb |
| [孩子](https://en.wiktionary.org/wiki/%E5%AD%A9%E5%AD%90#Chinese) | child (person who has not yet reached adulthood); children; kid (Classifier: 個／个) | hái zi · noun |
| [安全](https://en.wiktionary.org/wiki/%E5%AE%89%E5%85%A8#Chinese) | safe; secure | ān quán · adj |
| [大家](https://en.wiktionary.org/wiki/%E5%A4%A7%E5%AE%B6#Chinese) | everyone; everybody; all of us | dà jiā · pron |
| [部分](https://en.wiktionary.org/wiki/%E9%83%A8%E5%88%86#Chinese) | part; section; segment; portion (Classifier: 個／个 m) | bù fèn · noun |
| [非常](https://en.wiktionary.org/wiki/%E9%9D%9E%E5%B8%B8#Chinese) | extremely; very; highly | fēi cháng · adv |
| [自由](https://en.wiktionary.org/wiki/%E8%87%AA%E7%94%B1#Chinese) | free; unconstrained | zì yóu · adj |
| [那些](https://en.wiktionary.org/wiki/%E9%82%A3%E4%BA%9B#Chinese) | those | nà xiē · pron |

</details>

<details><summary>Words 51–100</summary>

![[Resources/Audio/zh/Words 0051-0100.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [完全](https://en.wiktionary.org/wiki/%E5%AE%8C%E5%85%A8#Chinese) | completely; absolutely; entirely | wán quán · adv |
| [得到](https://en.wiktionary.org/wiki/%E5%BE%97%E5%88%B0#Chinese) | to obtain; to acquire; to get; to win; to achieve; to receive | verb-complement · verb |
| [一次](https://en.wiktionary.org/wiki/%E4%B8%80%E6%AC%A1#Chinese) | one time | yī cì · noun |
| [人口](https://en.wiktionary.org/wiki/%E4%BA%BA%E5%8F%A3#Chinese) | population (people living within a political or geographical boundary) | rén kǒu · noun |
| [管理](https://en.wiktionary.org/wiki/%E7%AE%A1%E7%90%86#Chinese) | to manage; to administer; to supervise; to regulate; to oversee | guǎn lǐ · verb |
| [一般](https://en.wiktionary.org/wiki/%E4%B8%80%E8%88%AC#Chinese) | general; generic; typical | yì bān · adj |
| [完成](https://en.wiktionary.org/wiki/%E5%AE%8C%E6%88%90#Chinese) | to complete; to finish; to fulfill | wán chéng · verb |
| [事件](https://en.wiktionary.org/wiki/%E4%BA%8B%E4%BB%B6#Chinese) | event; incident; occurrence (Classifier: 個／个 m; 起 m) | shì jiàn · noun |
| [法律](https://en.wiktionary.org/wiki/%E6%B3%95%E5%BE%8B#Chinese) | law (body of binding rules and regulations) (Classifier: 部 m) | fǎ lǜ · noun |
| [事情](https://en.wiktionary.org/wiki/%E4%BA%8B%E6%83%85#Chinese) | matter; affair; something; business; thing; stuff (Classifier: 件) | shì qíng · noun |
| [存在](https://en.wiktionary.org/wiki/%E5%AD%98%E5%9C%A8#Chinese) | to exist; to be; to be present | cún zài · verb |
| [成功](https://en.wiktionary.org/wiki/%E6%88%90%E5%8A%9F#Chinese) | to succeed; to achieve success; to be successful | chéng gōng · verb |
| [或者](https://en.wiktionary.org/wiki/%E6%88%96%E8%80%85#Chinese) | or | huò zhě · conj |
| [最大](https://en.wiktionary.org/wiki/%E6%9C%80%E5%A4%A7#Chinese) | largest; biggest; greatest; maximum; maximal | zuì dà · noun |
| [照片](https://en.wiktionary.org/wiki/%E7%85%A7%E7%89%87#Chinese) | photograph; picture (Classifier: 張／张; 套; 幅) | zhào piān · noun |
| [政策](https://en.wiktionary.org/wiki/%E6%94%BF%E7%AD%96#Chinese) | policy (principle of behaviour expressed by a government or other authoritative body) (Classifier: 項／项 m) | zhèng cè · noun |
| [方法](https://en.wiktionary.org/wiki/%E6%96%B9%E6%B3%95#Chinese) | method; way; means; manner (Classifier: 個／个 m) | fāng fǎ · noun |
| [故事](https://en.wiktionary.org/wiki/%E6%95%85%E4%BA%8B#Chinese) | story (sequence of real or fictional events, or an account of such a sequence); tale; narrative; plot (Classifier: 個／个 m c; 段 m; 篇 m; 塊／块 mn) | gù shì · noun |
| [方面](https://en.wiktionary.org/wiki/%E6%96%B9%E9%9D%A2#Chinese) | aspect; side; (on the one) hand; facet; respect (Classifier: 個／个 m) | fāng miàn · noun |
| [原因](https://en.wiktionary.org/wiki/%E5%8E%9F%E5%9B%A0#Chinese) | cause; reason (for something happening) (Classifier: 個／个 m) | yuán yīn · noun |
| [女人](https://en.wiktionary.org/wiki/%E5%A5%B3%E4%BA%BA#Chinese) | woman; adult female (Classifier: 個／个) | nǚ rén · noun |
| [了解](https://en.wiktionary.org/wiki/%E4%BA%86%E8%A7%A3#Chinese) | to understand; to comprehend; to learn; to know | liǎo jiě · verb |
| [多少](https://en.wiktionary.org/wiki/%E5%A4%9A%E5%B0%91#Chinese) | how many; how much | duō shǎo · adj |
| [能力](https://en.wiktionary.org/wiki/%E8%83%BD%E5%8A%9B#Chinese) | ability; capability; capacity; faculty; competence | néng lì · noun |
| [分析](https://en.wiktionary.org/wiki/%E5%88%86%E6%9E%90#Chinese) | to analyze; to review | fēn xī · verb |
| [作品](https://en.wiktionary.org/wiki/%E4%BD%9C%E5%93%81#Chinese) | work (literary, artistic, or intellectual production); composition | zuò pǐn · noun |
| [家庭](https://en.wiktionary.org/wiki/%E5%AE%B6%E5%BA%AD#Chinese) | family; household (Classifier: 戶／户; 個／个) | jiā tíng · noun |
| [相信](https://en.wiktionary.org/wiki/%E7%9B%B8%E4%BF%A1#Chinese) | to believe (in); to trust; to have faith (in) | xiāng xìn · verb |
| [第一](https://en.wiktionary.org/wiki/%E7%AC%AC%E4%B8%80#Chinese) | first; 1st | dì yī · noun |
| [T](https://en.wiktionary.org/wiki/T#Chinese) | butch lesbian | T · noun |
| [努力](https://en.wiktionary.org/wiki/%E5%8A%AA%E5%8A%9B#Chinese) | to make an effort; to strive; to endeavor; to work hard | nǔ lì · verb |
| [如此](https://en.wiktionary.org/wiki/%E5%A6%82%E6%AD%A4#Chinese) | like this; so; such; the case; this way | rú cǐ · adv |
| [才能](https://en.wiktionary.org/wiki/%E6%89%8D%E8%83%BD#Chinese) | ability; talent; competence | cái néng · noun |
| [以下](https://en.wiktionary.org/wiki/%E4%BB%A5%E4%B8%8B#Chinese) | below; under | yǐ xià · noun |
| [利用](https://en.wiktionary.org/wiki/%E5%88%A9%E7%94%A8#Chinese) | to use; to utilise; to make use of | lì yòng · verb |
| [制度](https://en.wiktionary.org/wiki/%E5%88%B6%E5%BA%A6#Chinese) | system; institution | zhì dù · noun |
| [以上](https://en.wiktionary.org/wiki/%E4%BB%A5%E4%B8%8A#Chinese) | above; more than; over | yǐ shàng · noun |
| [革命](https://en.wiktionary.org/wiki/%E9%9D%A9%E5%91%BD#Chinese) | to revolt; to start a revolution | gé mìng · verb |
| [基本](https://en.wiktionary.org/wiki/%E5%9F%BA%E6%9C%AC#Chinese) | basis; root; fundament | jī běn · noun |
| [注意](https://en.wiktionary.org/wiki/%E6%B3%A8%E6%84%8F#Chinese) | to pay attention to; to take note of; to require attention; to notice; to mind; to watch for | zhù yì · verb |
| [M](https://en.wiktionary.org/wiki/M#Chinese) | menstruation | M · noun |
| [可是](https://en.wiktionary.org/wiki/%E5%8F%AF%E6%98%AF#Chinese) | however; but | kě shì · conj |
| [警察](https://en.wiktionary.org/wiki/%E8%AD%A6%E5%AF%9F#Chinese) | police; police force | jǐng chá · noun |
| [人物](https://en.wiktionary.org/wiki/%E4%BA%BA%E7%89%A9#Chinese) | figure; personage | rén wù · noun |
| [女性](https://en.wiktionary.org/wiki/%E5%A5%B3%E6%80%A7#Chinese) | the female sex; female | nǚ xìng · noun |
| [中央](https://en.wiktionary.org/wiki/%E4%B8%AD%E5%A4%AE#Chinese) | centre (of all sides, ends, surfaces, etc.); middle (of a road) | zhōng yāng · noun |
| [以前](https://en.wiktionary.org/wiki/%E4%BB%A5%E5%89%8D#Chinese) | earlier times; formerly; previously | yǐ qián · noun |
| [先生](https://en.wiktionary.org/wiki/%E5%85%88%E7%94%9F#Chinese) | mister; sir; gentleman | xiān shēng · noun |
| [in](https://en.wiktionary.org/wiki/in#Chinese) | in fashion; popular | in · adj |
| [全部](https://en.wiktionary.org/wiki/%E5%85%A8%E9%83%A8#Chinese) | all; everything; whole; entirety | quán bù · noun |

</details>

<details><summary>Words 101–150</summary>

![[Resources/Audio/zh/Words 0101-0150.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [最近](https://en.wiktionary.org/wiki/%E6%9C%80%E8%BF%91#Chinese) | recently; lately; of late | zuì jìn · adv |
| [自然](https://en.wiktionary.org/wiki/%E8%87%AA%E7%84%B6#Chinese) | nature; the natural world | zì rán · noun |
| [今年](https://en.wiktionary.org/wiki/%E4%BB%8A%E5%B9%B4#Chinese) | this year | jīn nián · noun |
| [意思](https://en.wiktionary.org/wiki/%E6%84%8F%E6%80%9D#Chinese) | meaning (of words, symbols, or concepts); significance | yì si · noun |
| [提高](https://en.wiktionary.org/wiki/%E6%8F%90%E9%AB%98#Chinese) | to raise; to improve; to heighten; to enhance; to increase | verb-complement · verb |
| [B](https://en.wiktionary.org/wiki/B#Chinese) | baby (Classifier: 個／个 c) | B · noun |
| [例如](https://en.wiktionary.org/wiki/%E4%BE%8B%E5%A6%82#Chinese) | to take for example; for example; for instance; such as | lì rú · verb |
| [取得](https://en.wiktionary.org/wiki/%E5%8F%96%E5%BE%97#Chinese) | to gain; to obtain | qǔ dé · verb |
| [土地](https://en.wiktionary.org/wiki/%E5%9C%9F%E5%9C%B0#Chinese) | ground; soil; land | tǔ dì · noun |
| [正式](https://en.wiktionary.org/wiki/%E6%AD%A3%E5%BC%8F#Chinese) | official | zhèng shì · adj |
| [民族](https://en.wiktionary.org/wiki/%E6%B0%91%E6%97%8F#Chinese) | people; nation; nationality; ethnic group; minority; ethnos; race (Classifier: 個／个) | mín zú · noun |
| [健康](https://en.wiktionary.org/wiki/%E5%81%A5%E5%BA%B7#Chinese) | healthy (free from disease or disorder); good; well | jiàn kāng · adj |
| [容易](https://en.wiktionary.org/wiki/%E5%AE%B9%E6%98%93#Chinese) | easy; simple | róng yì · adj |
| [消息](https://en.wiktionary.org/wiki/%E6%B6%88%E6%81%AF#Chinese) | message; news; information (Classifier: 條／条; 個／个) | xiāo xī · noun |
| [精神](https://en.wiktionary.org/wiki/%E7%B2%BE%E7%A5%9E#Chinese) | spirit; soul; will | jīng shén · noun |
| [明白](https://en.wiktionary.org/wiki/%E6%98%8E%E7%99%BD#Chinese) | to understand; to know | míng bái · verb |
| [足球](https://en.wiktionary.org/wiki/%E8%B6%B3%E7%90%83#Chinese) | football (sport); association football; soccer | zú qiú · noun |
| [十分](https://en.wiktionary.org/wiki/%E5%8D%81%E5%88%86#Chinese) | very; extremely; utterly; absolutely | shí fēn · adv |
| [文章](https://en.wiktionary.org/wiki/%E6%96%87%E7%AB%A0#Chinese) | essay; composition; article (in a newspaper, magazine, on the Internet, etc.) (Classifier: 篇) | wén zhāng · noun |
| [名字](https://en.wiktionary.org/wiki/%E5%90%8D%E5%AD%97#Chinese) | name | míng zì · noun |
| [唯一](https://en.wiktionary.org/wiki/%E5%94%AF%E4%B8%80#Chinese) | only; sole; unique | wéi yī · adj |
| [居民](https://en.wiktionary.org/wiki/%E5%B1%85%E6%B0%91#Chinese) | resident; inhabitant (Classifier: 名 m; 位 m) | jū mín · noun |
| [C](https://en.wiktionary.org/wiki/C#Chinese) | USB-C | C · noun |
| [com](https://en.wiktionary.org/wiki/com#Chinese) | to reach consensus; to agree on common terms; to discuss | com · verb |
| [人士](https://en.wiktionary.org/wiki/%E4%BA%BA%E5%A3%AB#Chinese) | public figure; personage | rén shì · noun |
| [死亡](https://en.wiktionary.org/wiki/%E6%AD%BB%E4%BA%A1#Chinese) | to die | sǐ wáng · verb |
| [每天](https://en.wiktionary.org/wiki/%E6%AF%8F%E5%A4%A9#Chinese) | every day; daily | měi tiān · adv |
| [感到](https://en.wiktionary.org/wiki/%E6%84%9F%E5%88%B0#Chinese) | to feel; to sense; to have a feeling that | verb-complement · verb |
| [理解](https://en.wiktionary.org/wiki/%E7%90%86%E8%A7%A3#Chinese) | to understand; to comprehend | lǐ jiě · verb |
| [思想](https://en.wiktionary.org/wiki/%E6%80%9D%E6%83%B3#Chinese) | idea; intention; thought | sī xiǎng · noun |
| [清楚](https://en.wiktionary.org/wiki/%E6%B8%85%E6%A5%9A#Chinese) | clear; lucid | qīng chǔ · adj |
| [一名](https://en.wiktionary.org/wiki/%E4%B8%80%E5%90%8D#Chinese) | one person | yī míng · noun |
| [到底](https://en.wiktionary.org/wiki/%E5%88%B0%E5%BA%95#Chinese) | actually; exactly | dào dǐ · adv |
| [同意](https://en.wiktionary.org/wiki/%E5%90%8C%E6%84%8F#Chinese) | to agree with (sth.); to consent to; to concur with (sth.) | tóng yì · verb |
| [和平](https://en.wiktionary.org/wiki/%E5%92%8C%E5%B9%B3#Chinese) | peace (state free of war or animosity) | hé píng · noun |
| [好像](https://en.wiktionary.org/wiki/%E5%A5%BD%E5%83%8F#Chinese) | to seem; to be like; as if | hǎo xiàng · verb |
| [尤其](https://en.wiktionary.org/wiki/%E5%B0%A4%E5%85%B6#Chinese) | especially; particularly | yóu qí · adv |
| [每年](https://en.wiktionary.org/wiki/%E6%AF%8F%E5%B9%B4#Chinese) | every year; yearly | měi nián · adv |
| [青年](https://en.wiktionary.org/wiki/%E9%9D%92%E5%B9%B4#Chinese) | youth; adolescence (period) | qīng nián · noun |
| [晚上](https://en.wiktionary.org/wiki/%E6%99%9A%E4%B8%8A#Chinese) | evening; night (Classifier: 個／个) | wǎn shàng · noun |
| [正常](https://en.wiktionary.org/wiki/%E6%AD%A3%E5%B8%B8#Chinese) | normal; regular; ordinary | zhèng cháng · adj |
| [交通](https://en.wiktionary.org/wiki/%E4%BA%A4%E9%80%9A#Chinese) | transportation; transport; traffic | jiāo tōng · noun |
| [利益](https://en.wiktionary.org/wiki/%E5%88%A9%E7%9B%8A#Chinese) | benefit; advantage; good; interest | lì yì · noun |
| [加拿大](https://en.wiktionary.org/wiki/%E5%8A%A0%E6%8B%BF%E5%A4%A7#Chinese) | armpit (Classifier: 個／个 c) | jiā ná dà · noun |
| [方向](https://en.wiktionary.org/wiki/%E6%96%B9%E5%90%91#Chinese) | direction; orientation | fāng xiàng · noun |
| [突然](https://en.wiktionary.org/wiki/%E7%AA%81%E7%84%B6#Chinese) | sudden; abrupt | tū rán · adj |
| [作者](https://en.wiktionary.org/wiki/%E4%BD%9C%E8%80%85#Chinese) | author; writer | zuò zhě · noun |
| [同志](https://en.wiktionary.org/wiki/%E5%90%8C%E5%BF%97#Chinese) | someone sharing similar interests or aspirations; kindred spirit | tóng zhì · noun |
| [宗教](https://en.wiktionary.org/wiki/%E5%AE%97%E6%95%99#Chinese) | religion; the sacred | zōng jiào · noun |
| [附近](https://en.wiktionary.org/wiki/%E9%99%84%E8%BF%91#Chinese) | nearby; vicinity; proximity | fù jìn · noun |

</details>

<details><summary>Words 151–200</summary>

![[Resources/Audio/zh/Words 0151-0200.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [教授](https://en.wiktionary.org/wiki/%E6%95%99%E6%8E%88#Chinese) | professor | jiào shòu · noun |
| [程度](https://en.wiktionary.org/wiki/%E7%A8%8B%E5%BA%A6#Chinese) | degree; extent; level; standard | chéng dù · noun |
| [水平](https://en.wiktionary.org/wiki/%E6%B0%B4%E5%B9%B3#Chinese) | horizontal; level | shuǐ píng · adj |
| [首先](https://en.wiktionary.org/wiki/%E9%A6%96%E5%85%88#Chinese) | first of all; first; firstly | shǒu xiān · adv |
| [N](https://en.wiktionary.org/wiki/N#Chinese) | countless; several | N · num |
| [左右](https://en.wiktionary.org/wiki/%E5%B7%A6%E5%8F%B3#Chinese) | left and right | zuǒ yòu · noun |
| [速度](https://en.wiktionary.org/wiki/%E9%80%9F%E5%BA%A6#Chinese) | velocity | sù dù · noun |
| [作家](https://en.wiktionary.org/wiki/%E4%BD%9C%E5%AE%B6#Chinese) | author; writer | zuò jiā · noun |
| [多年](https://en.wiktionary.org/wiki/%E5%A4%9A%E5%B9%B4#Chinese) | many years | duō nián · noun |
| [平均](https://en.wiktionary.org/wiki/%E5%B9%B3%E5%9D%87#Chinese) | average; mean | píng jūn · noun |
| [明天](https://en.wiktionary.org/wiki/%E6%98%8E%E5%A4%A9#Chinese) | tomorrow | míng tiān · noun |
| [不用](https://en.wiktionary.org/wiki/%E4%B8%8D%E7%94%A8#Chinese) | not necessary; don't; no need to | bù yòng · adv |
| [兄弟](https://en.wiktionary.org/wiki/%E5%85%84%E5%BC%9F#Chinese) | brother | xiōng dì · noun |
| [妻子](https://en.wiktionary.org/wiki/%E5%A6%BB%E5%AD%90#Chinese) | wife | qī zǐ · noun |
| [父母](https://en.wiktionary.org/wiki/%E7%88%B6%E6%AF%8D#Chinese) | parents; mother and father; mum and dad | fù mǔ · noun |
| [重大](https://en.wiktionary.org/wiki/%E9%87%8D%E5%A4%A7#Chinese) | important; significant; great; major | zhòng dà · adj |
| [O](https://en.wiktionary.org/wiki/O#Chinese) | in a relationship | O · adj |
| [o](https://en.wiktionary.org/wiki/o#Chinese) | to overdose | o · verb |
| [直到](https://en.wiktionary.org/wiki/%E7%9B%B4%E5%88%B0#Chinese) | until; up to | zhí dào · prep |
| [道路](https://en.wiktionary.org/wiki/%E9%81%93%E8%B7%AF#Chinese) | road | dào lù · noun |
| [去年](https://en.wiktionary.org/wiki/%E5%8E%BB%E5%B9%B4#Chinese) | last year | qù nián · noun |
| [地位](https://en.wiktionary.org/wiki/%E5%9C%B0%E4%BD%8D#Chinese) | position (in society, the world, etc.); standing; status (Classifier: 個／个 m) | dì wèi · noun |
| [工人](https://en.wiktionary.org/wiki/%E5%B7%A5%E4%BA%BA#Chinese) | worker; laborer | gōng rén · noun |
| [位置](https://en.wiktionary.org/wiki/%E4%BD%8D%E7%BD%AE#Chinese) | location; position; place (Classifier: 個／个 m c) | wèi zhì · noun |
| [回答](https://en.wiktionary.org/wiki/%E5%9B%9E%E7%AD%94#Chinese) | to reply; to answer; to respond | huí dá · verb |
| [必要](https://en.wiktionary.org/wiki/%E5%BF%85%E8%A6%81#Chinese) | necessary, essential | bì yào · adj |
| [P](https://en.wiktionary.org/wiki/P#Chinese) | to photoshop | P · verb |
| [一家](https://en.wiktionary.org/wiki/%E4%B8%80%E5%AE%B6#Chinese) | entire family | yī jiā · noun |
| [一部分](https://en.wiktionary.org/wiki/%E4%B8%80%E9%83%A8%E5%88%86#Chinese) | a part (of); a portion (of); some (of) | yī bù fèn · noun |
| [安排](https://en.wiktionary.org/wiki/%E5%AE%89%E6%8E%92#Chinese) | to arrange; to plan; to make arrangements | ān pái · verb |
| [普通](https://en.wiktionary.org/wiki/%E6%99%AE%E9%80%9A#Chinese) | ordinary, plain, average, nothing special, general | pǔ tōng · adj |
| [D](https://en.wiktionary.org/wiki/D#Chinese) | to DDOS | D · verb |
| [d](https://en.wiktionary.org/wiki/d#Chinese) | to differentiate | d · verb |
| [漂亮](https://en.wiktionary.org/wiki/%E6%BC%82%E4%BA%AE#Chinese) | pretty; beautiful; handsome | piào liàng · adj |
| [秘密](https://en.wiktionary.org/wiki/%E7%A7%98%E5%AF%86#Chinese) | secret (knowledge that is hidden) | mì mì · noun |
| [不可](https://en.wiktionary.org/wiki/%E4%B8%8D%E5%8F%AF#Chinese) | cannot | bù kě · verb |
| [男子](https://en.wiktionary.org/wiki/%E7%94%B7%E5%AD%90#Chinese) | man; male (Classifier: 個／个 m c; 名 m c) | nán zi · noun |
| [通知](https://en.wiktionary.org/wiki/%E9%80%9A%E7%9F%A5#Chinese) | to notify; to inform | tōng zhī · verb |
| [H](https://en.wiktionary.org/wiki/H#Chinese) | dirty; lewd; perverted | H · adj |
| [女子](https://en.wiktionary.org/wiki/%E5%A5%B3%E5%AD%90#Chinese) | woman; female (Classifier: 名 m; 個／个 m) | nǚ zǐ · noun |
| [犯罪](https://en.wiktionary.org/wiki/%E7%8A%AF%E7%BD%AA#Chinese) | to commit a crime | fàn zuì · verb |
| [理由](https://en.wiktionary.org/wiki/%E7%90%86%E7%94%B1#Chinese) | reason; grounds; justification | lǐ yóu · noun |
| [表演](https://en.wiktionary.org/wiki/%E8%A1%A8%E6%BC%94#Chinese) | to perform; to act; to play | biǎo yǎn · verb |
| [for](https://en.wiktionary.org/wiki/for#Chinese) | for; for the purpose of | for · prep |
| [不得](https://en.wiktionary.org/wiki/%E4%B8%8D%E5%BE%97#Chinese) | must not; should not; not be allowed | bù dé · verb |
| [特殊](https://en.wiktionary.org/wiki/%E7%89%B9%E6%AE%8A#Chinese) | special; exceptional | tè shū · adj |
| [e](https://en.wiktionary.org/wiki/e#Chinese) | to email | e · verb |
| [人生](https://en.wiktionary.org/wiki/%E4%BA%BA%E7%94%9F#Chinese) | life (i.e. human life) (Classifier: 段 m) | rén shēng · noun |
| [手段](https://en.wiktionary.org/wiki/%E6%89%8B%E6%AE%B5#Chinese) | procedure; method; means (to an end) | shǒu duàn · noun |
| [老婆](https://en.wiktionary.org/wiki/%E8%80%81%E5%A9%86#Chinese) | wife | lǎo pó · noun |

</details>

<details><summary>Words 201–250</summary>

![[Resources/Audio/zh/Words 0201-0250.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [食品](https://en.wiktionary.org/wiki/%E9%A3%9F%E5%93%81#Chinese) | food; foodstuff (Classifier: 個／个 m; 種／种 m) | shí pǐn · noun |
| [出口](https://en.wiktionary.org/wiki/%E5%87%BA%E5%8F%A3#Chinese) | exit (including outlets, escapes, vents, highway offramps, etc.) | chū kǒu · noun |
| [博士](https://en.wiktionary.org/wiki/%E5%8D%9A%E5%A3%AB#Chinese) | doctorate; Ph.D. | bó shì · noun |
| [害怕](https://en.wiktionary.org/wiki/%E5%AE%B3%E6%80%95#Chinese) | to be afraid; to be scared; to be frightened | hài pà · verb |
| [生物](https://en.wiktionary.org/wiki/%E7%94%9F%E7%89%A9#Chinese) | organism; living being; lifeform (Classifier: 個／个) | shēng wù · noun |
| [英雄](https://en.wiktionary.org/wiki/%E8%8B%B1%E9%9B%84#Chinese) | hero | yīng xióng · noun |
| [中文](https://en.wiktionary.org/wiki/%E4%B8%AD%E6%96%87#Chinese) | Chinese (language) | zhōng wén · noun |
| [人人](https://en.wiktionary.org/wiki/%E4%BA%BA%E4%BA%BA#Chinese) | everyone; everybody; all of us | rén rén · noun |
| [最新](https://en.wiktionary.org/wiki/%E6%9C%80%E6%96%B0#Chinese) | the newest; the latest; the most recent; up-to-date | zuì xīn · adj |
| [男性](https://en.wiktionary.org/wiki/%E7%94%B7%E6%80%A7#Chinese) | the male sex; male | nán xìng · noun |
| [人才](https://en.wiktionary.org/wiki/%E4%BA%BA%E6%89%8D#Chinese) | talent; abilities that make one an asset | rén cái · noun |
| [命令](https://en.wiktionary.org/wiki/%E5%91%BD%E4%BB%A4#Chinese) | order; command; directive | mìng lìng · noun |
| [商品](https://en.wiktionary.org/wiki/%E5%95%86%E5%93%81#Chinese) | good; commodity (Classifier: 件 m) | shāng pǐn · noun |
| [文字](https://en.wiktionary.org/wiki/%E6%96%87%E5%AD%97#Chinese) | written symbols; writing; script; text; characters (Classifier: 種／种; 個／个) | wén zì · noun |
| [海外](https://en.wiktionary.org/wiki/%E6%B5%B7%E5%A4%96#Chinese) | overseas; abroad | hǎi wài · noun |
| [眼睛](https://en.wiktionary.org/wiki/%E7%9C%BC%E7%9D%9B#Chinese) | eye; eyes (Classifier: 隻／只 m; 雙／双 m; 對／对 m) | yǎn jīng · noun |
| [食物](https://en.wiktionary.org/wiki/%E9%A3%9F%E7%89%A9#Chinese) | food | shí wù · noun |
| [不知](https://en.wiktionary.org/wiki/%E4%B8%8D%E7%9F%A5#Chinese) | to not know; to have no idea of; to be ignorant of | bù zhī · verb |
| [不足](https://en.wiktionary.org/wiki/%E4%B8%8D%E8%B6%B3#Chinese) | insufficient; inadequate; lacking | bù zú · adj |
| [出去](https://en.wiktionary.org/wiki/%E5%87%BA%E5%8E%BB#Chinese) | to go out | verb-complement · verb |
| [哥哥](https://en.wiktionary.org/wiki/%E5%93%A5%E5%93%A5#Chinese) | elder brother; big brother (Classifier: 個／个; 位) | gē gē · noun |
| [家人](https://en.wiktionary.org/wiki/%E5%AE%B6%E4%BA%BA#Chinese) | one's family or family members | jiā rén · noun |
| [形象](https://en.wiktionary.org/wiki/%E5%BD%A2%E8%B1%A1#Chinese) | image (visual appearance, or public perception) | xíng xiàng · noun |
| [打算](https://en.wiktionary.org/wiki/%E6%89%93%E7%AE%97#Chinese) | to plan; to intend | dǎ suàn · verb |
| [昨天](https://en.wiktionary.org/wiki/%E6%98%A8%E5%A4%A9#Chinese) | yesterday | zuó tiān · noun |
| [非洲](https://en.wiktionary.org/wiki/%E9%9D%9E%E6%B4%B2#Chinese) | of bad luck | fēi zhōu · adj |
| [早上](https://en.wiktionary.org/wiki/%E6%97%A9%E4%B8%8A#Chinese) | early morning | zǎo shàng · noun |
| [天下](https://en.wiktionary.org/wiki/%E5%A4%A9%E4%B8%8B#Chinese) | the world; everything under the sky; all under heaven | tiān xià · noun |
| [完美](https://en.wiktionary.org/wiki/%E5%AE%8C%E7%BE%8E#Chinese) | perfect; consummate; flawless | wán měi · adj |
| [正是](https://en.wiktionary.org/wiki/%E6%AD%A3%E6%98%AF#Chinese) | to be precisely; to just happen to be; to be exactly; to be none other than | zhèng shì · verb |
| [一旦](https://en.wiktionary.org/wiki/%E4%B8%80%E6%97%A6#Chinese) | once; as soon as | yí dàn · adv |
| [消失](https://en.wiktionary.org/wiki/%E6%B6%88%E5%A4%B1#Chinese) | to disappear; to vanish | xiāo shī · verb |
| [禁止](https://en.wiktionary.org/wiki/%E7%A6%81%E6%AD%A2#Chinese) | to prohibit; to forbid | jìn zhǐ · verb |
| [衣服](https://en.wiktionary.org/wiki/%E8%A1%A3%E6%9C%8D#Chinese) | clothing; clothes; laundry (Classifier: 件 m) | yī fú · noun |
| [依然](https://en.wiktionary.org/wiki/%E4%BE%9D%E7%84%B6#Chinese) | as it was before; still | yī rán · adv |
| [少女](https://en.wiktionary.org/wiki/%E5%B0%91%E5%A5%B3#Chinese) | young woman; girl | shào nǚ · noun |
| [投票](https://en.wiktionary.org/wiki/%E6%8A%95%E7%A5%A8#Chinese) | to vote; to cast a vote; to cast a ballot; to poll | tóu piào · verb |
| [日子](https://en.wiktionary.org/wiki/%E6%97%A5%E5%AD%90#Chinese) | date; day | rì zi · noun |
| [石油](https://en.wiktionary.org/wiki/%E7%9F%B3%E6%B2%B9#Chinese) | oil; petroleum | shí yóu · noun |
| [V](https://en.wiktionary.org/wiki/V#Chinese) | virtual YouTuber; VTuber | V · noun |
| [大概](https://en.wiktionary.org/wiki/%E5%A4%A7%E6%A6%82#Chinese) | approximately; roughly; about | dà gài · adv |
| [少年](https://en.wiktionary.org/wiki/%E5%B0%91%E5%B9%B4#Chinese) | early youth (from ten to sixteen years old) | shào nián · noun |
| [爸爸](https://en.wiktionary.org/wiki/%E7%88%B8%E7%88%B8#Chinese) | dad; papa (Classifier: 個／个 m c; 位 m c) | bà bà · noun |
| [w](https://en.wiktionary.org/wiki/w#Chinese) | myriad, ten thousand | w · num |
| [一部](https://en.wiktionary.org/wiki/%E4%B8%80%E9%83%A8#Chinese) | Used other than figuratively or idiomatically: see 一, 部 (bù) (a book, film, vehicle, machine, etc.) | yī bù · noun |
| [姐姐](https://en.wiktionary.org/wiki/%E5%A7%90%E5%A7%90#Chinese) | elder sister; big sister (Classifier: 個／个; 位) | jiě jiě · noun |
| [家族](https://en.wiktionary.org/wiki/%E5%AE%B6%E6%97%8F#Chinese) | family; household; clan | jiā zú · noun |
| [地震](https://en.wiktionary.org/wiki/%E5%9C%B0%E9%9C%87#Chinese) | earthquake (Classifier: 場／场 m; 次 m c) | dì zhèn · noun |
| [森林](https://en.wiktionary.org/wiki/%E6%A3%AE%E6%9E%97#Chinese) | forest; trees (Classifier: 片 m) | sēn lín · noun |
| [他人](https://en.wiktionary.org/wiki/%E4%BB%96%E4%BA%BA#Chinese) | another person; other people; others | tā rén · noun |

</details>

<details><summary>Words 251–300</summary>

![[Resources/Audio/zh/Words 0251-0300.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [幸福](https://en.wiktionary.org/wiki/%E5%B9%B8%E7%A6%8F#Chinese) | blessed and satisfactory; consummate; joyful; (of a person) living a blessed and contented life | xìng fú · adj |
| [演出](https://en.wiktionary.org/wiki/%E6%BC%94%E5%87%BA#Chinese) | to perform; to put on a show | yǎn chū · verb |
| [by](https://en.wiktionary.org/wiki/by#Chinese) | according to | by · prep |
| [丈夫](https://en.wiktionary.org/wiki/%E4%B8%88%E5%A4%AB#Chinese) | husband | zhàng fū · noun |
| [不行](https://en.wiktionary.org/wiki/%E4%B8%8D%E8%A1%8C#Chinese) | unacceptable; out of the question; won't do | bù xíng · adj |
| [天天](https://en.wiktionary.org/wiki/%E5%A4%A9%E5%A4%A9#Chinese) | every day; day by day | tiān tiān · adv |
| [有趣](https://en.wiktionary.org/wiki/%E6%9C%89%E8%B6%A3#Chinese) | interesting; absorbing; engaging; delightful | yǒu qù · adj |
| [G](https://en.wiktionary.org/wiki/G#Chinese) | gigabyte | G · noun |
| [一群](https://en.wiktionary.org/wiki/%E4%B8%80%E7%BE%A4#Chinese) | a group | yī qún · noun |
| [房子](https://en.wiktionary.org/wiki/%E6%88%BF%E5%AD%90#Chinese) | house; home; apartment (Classifier: 所 m; 棟／栋 m; 幢 m; 座 m; 套 m) | fáng zi · noun |
| [方便](https://en.wiktionary.org/wiki/%E6%96%B9%E4%BE%BF#Chinese) | convenient | fāng biàn · adj |
| [病毒](https://en.wiktionary.org/wiki/%E7%97%85%E6%AF%92#Chinese) | virus | bìng dú · noun |
| [首都](https://en.wiktionary.org/wiki/%E9%A6%96%E9%83%BD#Chinese) | capital; capital city (of a country) (Classifier: 個／个) | shǒu dū · noun |
| [黑人](https://en.wiktionary.org/wiki/%E9%BB%91%E4%BA%BA#Chinese) | black person (e.g. African-American) | hēi rén · noun |
| [互相](https://en.wiktionary.org/wiki/%E4%BA%92%E7%9B%B8#Chinese) | mutually; each other; one another | hù xiāng · adv |
| [出生](https://en.wiktionary.org/wiki/%E5%87%BA%E7%94%9F#Chinese) | to be born | chū shēng · verb |
| [司法](https://en.wiktionary.org/wiki/%E5%8F%B8%E6%B3%95#Chinese) | administration of justice; judiciary; judicature | sī fǎ · noun |
| [感情](https://en.wiktionary.org/wiki/%E6%84%9F%E6%83%85#Chinese) | feeling; emotion | gǎn qíng · noun |
| [疾病](https://en.wiktionary.org/wiki/%E7%96%BE%E7%97%85#Chinese) | disease; illness; disorder | jí bìng · noun |
| [不久](https://en.wiktionary.org/wiki/%E4%B8%8D%E4%B9%85#Chinese) | soon; before long; not long (after) | bù jiǔ · adv |
| [信仰](https://en.wiktionary.org/wiki/%E4%BF%A1%E4%BB%B0#Chinese) | to believe in (an ideology, faith or religion); to have faith in | xìn yǎng · verb |
| [妹妹](https://en.wiktionary.org/wiki/%E5%A6%B9%E5%A6%B9#Chinese) | younger sister | mèi mèi · noun |
| [掌握](https://en.wiktionary.org/wiki/%E6%8E%8C%E6%8F%A1#Chinese) | to be in control of; to take charge of; to hold | zhǎng wò · verb |
| [暴力](https://en.wiktionary.org/wiki/%E6%9A%B4%E5%8A%9B#Chinese) | violence; brutality; force | bào lì · noun |
| [期待](https://en.wiktionary.org/wiki/%E6%9C%9F%E5%BE%85#Chinese) | to look forward to; to await | qī dài · verb |
| [分子](https://en.wiktionary.org/wiki/%E5%88%86%E5%AD%90#Chinese) | side branch in a family tree | fèn zǐ · noun |
| [地理](https://en.wiktionary.org/wiki/%E5%9C%B0%E7%90%86#Chinese) | geography | dì lǐ · noun |
| [大小](https://en.wiktionary.org/wiki/%E5%A4%A7%E5%B0%8F#Chinese) | big and small | dà xiǎo · noun |
| [植物](https://en.wiktionary.org/wiki/%E6%A4%8D%E7%89%A9#Chinese) | plant; vegetation; flora (Classifier: 棵 m; 樖 c) | zhí wù · noun |
| [人家](https://en.wiktionary.org/wiki/%E4%BA%BA%E5%AE%B6#Chinese) | family; household | rén jiā · noun |
| [歌](https://en.wiktionary.org/wiki/%E6%AD%8C#Chinese) | song; tune (Classifier: 首 m c mn; 支 m c; 闋／阕 m; 隻／只 c w; 條／条 h mn mn-t; 塊／块 mn) | gē · noun |
| [一致](https://en.wiktionary.org/wiki/%E4%B8%80%E8%87%B4#Chinese) | in agreement; identical; in unanimity; in chorus; consistent; same | yí zhì · adj |
| [奇怪](https://en.wiktionary.org/wiki/%E5%A5%87%E6%80%AA#Chinese) | odd; strange; surprising; unexpected | qí guài · adj |
| [日常](https://en.wiktionary.org/wiki/%E6%97%A5%E5%B8%B8#Chinese) | everyday; daily; day-to-day; ordinary | rì cháng · adj |
| [星期](https://en.wiktionary.org/wiki/%E6%98%9F%E6%9C%9F#Chinese) | week (Classifier: 個／个 m c) | xīng qī · noun |
| [理想](https://en.wiktionary.org/wiki/%E7%90%86%E6%83%B3#Chinese) | ideal; dream | lǐ xiǎng · noun |
| [以外](https://en.wiktionary.org/wiki/%E4%BB%A5%E5%A4%96#Chinese) | apart from; other than; except for; beyond; excluding; in addition | yǐ wài · postp |
| [明星](https://en.wiktionary.org/wiki/%E6%98%8E%E6%98%9F#Chinese) | celebrity; star (Classifier: 個／个 m c; 位 m c; 名 m c) | míng xīng · noun |
| [皇帝](https://en.wiktionary.org/wiki/%E7%9A%87%E5%B8%9D#Chinese) | emperor (any monarch ruling an empire, irrespective of gender) | huáng dì · noun |
| [立刻](https://en.wiktionary.org/wiki/%E7%AB%8B%E5%88%BB#Chinese) | immediately; at once | lì kè · adv |
| [app](https://en.wiktionary.org/wiki/app#Chinese) | app (Classifier: 個／个 c; 隻／只 c) | app · noun |
| [一生](https://en.wiktionary.org/wiki/%E4%B8%80%E7%94%9F#Chinese) | lifetime; all one's life; one's whole life | yī shēng · noun |
| [事故](https://en.wiktionary.org/wiki/%E4%BA%8B%E6%95%85#Chinese) | accident; mishap (Classifier: 個／个 m; 起 m) | shì gù · noun |
| [街道](https://en.wiktionary.org/wiki/%E8%A1%97%E9%81%93#Chinese) | street; road (Classifier: 條／条) | jiē dào · noun |
| [垃圾](https://en.wiktionary.org/wiki/%E5%9E%83%E5%9C%BE#Chinese) | garbage; rubbish; trash; waste; refuse; junk | lā jī · noun |
| [好看](https://en.wiktionary.org/wiki/%E5%A5%BD%E7%9C%8B#Chinese) | good-looking; beautiful; pretty | hǎo kàn · adj |
| [常常](https://en.wiktionary.org/wiki/%E5%B8%B8%E5%B8%B8#Chinese) | frequently; often | cháng cháng · adv |
| [旅行](https://en.wiktionary.org/wiki/%E6%97%85%E8%A1%8C#Chinese) | to go on a trip; to travel; to tour | lǚ xíng · verb |
| [矛盾](https://en.wiktionary.org/wiki/%E7%9F%9B%E7%9B%BE#Chinese) | contradiction; inconsistency; disagreement; incongruity | máo dùn · noun |
| [高速](https://en.wiktionary.org/wiki/%E9%AB%98%E9%80%9F#Chinese) | high-speed | gāo sù · adj |

</details>

<details><summary>Words 301–350</summary>

![[Resources/Audio/zh/Words 0301-0350.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [黑暗](https://en.wiktionary.org/wiki/%E9%BB%91%E6%9A%97#Chinese) | dark; unlighted | hēi àn · adj |
| [K](https://en.wiktionary.org/wiki/K#Chinese) | to repost | K · verb |
| [休息](https://en.wiktionary.org/wiki/%E4%BC%91%E6%81%AF#Chinese) | to rest; to take a break | xiū xī · verb |
| [夫人](https://en.wiktionary.org/wiki/%E5%A4%AB%E4%BA%BA#Chinese) | lady; madam; Mrs. (Classifier: 位) | fū rén · noun |
| [探索](https://en.wiktionary.org/wiki/%E6%8E%A2%E7%B4%A2#Chinese) | to explore; to probe | tàn suǒ · verb |
| [搜索](https://en.wiktionary.org/wiki/%E6%90%9C%E7%B4%A2#Chinese) | to search; to look for | sōu suǒ · verb |
| [海洋](https://en.wiktionary.org/wiki/%E6%B5%B7%E6%B4%8B#Chinese) | ocean; sea (as a whole) (Classifier: 個／个 m) | hǎi yáng · noun |
| [能量](https://en.wiktionary.org/wiki/%E8%83%BD%E9%87%8F#Chinese) | energy | néng liàng · noun |
| [分配](https://en.wiktionary.org/wiki/%E5%88%86%E9%85%8D#Chinese) | to distribute; to hand out; to issue; to dispense; to allocate | fēn pèi · verb |
| [回去](https://en.wiktionary.org/wiki/%E5%9B%9E%E5%8E%BB#Chinese) | to return; to go back; to go; to leave | huí qù · verb |
| [姑娘](https://en.wiktionary.org/wiki/%E5%A7%91%E5%A8%98#Chinese) | girl; maiden; unmarried woman | gū niáng · noun |
| [必然](https://en.wiktionary.org/wiki/%E5%BF%85%E7%84%B6#Chinese) | inevitable; certain | bì rán · adj |
| [流行](https://en.wiktionary.org/wiki/%E6%B5%81%E8%A1%8C#Chinese) | prevalent; widespread | liú xíng · adj |
| [知名](https://en.wiktionary.org/wiki/%E7%9F%A5%E5%90%8D#Chinese) | well-known; famous; noted; renowned | zhī míng · adj |
| [一面](https://en.wiktionary.org/wiki/%E4%B8%80%E9%9D%A2#Chinese) | at the same time; simultaneously | yí miàn · adv |
| [不必](https://en.wiktionary.org/wiki/%E4%B8%8D%E5%BF%85#Chinese) | no need to; not necessary to; don't have to | bù bì · adv |
| [加速](https://en.wiktionary.org/wiki/%E5%8A%A0%E9%80%9F#Chinese) | to accelerate; to speed up; to expedite; to hasten; to quicken | jiā sù · verb |
| [印象](https://en.wiktionary.org/wiki/%E5%8D%B0%E8%B1%A1#Chinese) | impression (feeling left on someone about someone or something) | yìn xiàng · noun |
| [可惜](https://en.wiktionary.org/wiki/%E5%8F%AF%E6%83%9C#Chinese) | regrettable; too bad; a pity; a shame | kě xī · adj |
| [哈](https://en.wiktionary.org/wiki/%E5%93%88#Chinese) | Used to indicate confusion or pondering when the speaker did not hear or comprehend clearly: huh; hmm; what; pardon?; what did (they/you/he/she) say? | hā · intj |
| [老人](https://en.wiktionary.org/wiki/%E8%80%81%E4%BA%BA#Chinese) | old person; the old; the elderly | lǎo rén · noun |
| [弟弟](https://en.wiktionary.org/wiki/%E5%BC%9F%E5%BC%9F#Chinese) | younger brother | dì di · noun |
| [房屋](https://en.wiktionary.org/wiki/%E6%88%BF%E5%B1%8B#Chinese) | house; building; (collective) housing (Classifier: 所 m; 套 m) | fáng wū · noun |
| [主人](https://en.wiktionary.org/wiki/%E4%B8%BB%E4%BA%BA#Chinese) | master; owner | zhǔ rén · noun |
| [你好](https://en.wiktionary.org/wiki/%E4%BD%A0%E5%A5%BD#Chinese) | hello; hi | nǐ hǎo · intj |
| [模型](https://en.wiktionary.org/wiki/%E6%A8%A1%E5%9E%8B#Chinese) | model (representation of a physical object, usually in miniature); mockup | mó xíng · noun |
| [一路](https://en.wiktionary.org/wiki/%E4%B8%80%E8%B7%AF#Chinese) | the road to; the way to; on the way to | yī lù · noun |
| [上午](https://en.wiktionary.org/wiki/%E4%B8%8A%E5%8D%88#Chinese) | morning; a.m. | shàng wǔ · noun |
| [大大](https://en.wiktionary.org/wiki/%E5%A4%A7%E5%A4%A7#Chinese) | greatly; hugely; enormously; significantly; considerably | dà dà · adv |
| [最低](https://en.wiktionary.org/wiki/%E6%9C%80%E4%BD%8E#Chinese) | lowest, minimum | zuì dī · adj |
| [激烈](https://en.wiktionary.org/wiki/%E6%BF%80%E7%83%88#Chinese) | intense; acute; sharp; fierce; spirited; strong; violent; harsh | jī liè · adj |
| [老公](https://en.wiktionary.org/wiki/%E8%80%81%E5%85%AC#Chinese) | husband | lǎo gōng · noun |
| [自行](https://en.wiktionary.org/wiki/%E8%87%AA%E8%A1%8C#Chinese) | by oneself; on one's own | zì xíng · adv |
| [不但](https://en.wiktionary.org/wiki/%E4%B8%8D%E4%BD%86#Chinese) | not only | bù dàn · conj |
| [宇宙](https://en.wiktionary.org/wiki/%E5%AE%87%E5%AE%99#Chinese) | universe; cosmos; macrocosm; space | yǔ zhòu · noun |
| [批判](https://en.wiktionary.org/wiki/%E6%89%B9%E5%88%A4#Chinese) | to critique; to comment; to criticise | pī pàn · verb |
| [男女](https://en.wiktionary.org/wiki/%E7%94%B7%E5%A5%B3#Chinese) | man and woman; men and women; both sexes | nán nǚ · noun |
| [加油](https://en.wiktionary.org/wiki/%E5%8A%A0%E6%B2%B9#Chinese) | to oil; to lubricate | jiā yóu · verb |
| [咖啡](https://en.wiktionary.org/wiki/%E5%92%96%E5%95%A1#Chinese) | coffee (Classifier: 杯) | kā fēi · noun |
| [感染](https://en.wiktionary.org/wiki/%E6%84%9F%E6%9F%93#Chinese) | to infect or be infected by; to have an infection; to contract (a contagion) | gǎn rǎn · verb |
| [生日](https://en.wiktionary.org/wiki/%E7%94%9F%E6%97%A5#Chinese) | birthday | shēng rì · noun |
| [神秘](https://en.wiktionary.org/wiki/%E7%A5%9E%E7%A7%98#Chinese) | mysterious; mystical | shén mì · adj |
| [五月](https://en.wiktionary.org/wiki/%E4%BA%94%E6%9C%88#Chinese) | May | wǔ yuè · noun |
| [地下](https://en.wiktionary.org/wiki/%E5%9C%B0%E4%B8%8B#Chinese) | underground | dì xià · noun |
| [大道](https://en.wiktionary.org/wiki/%E5%A4%A7%E9%81%93#Chinese) | avenue (four-lane street); boulevard (multi-lane arterial thoroughfare) | dà dào · noun |
| [技能](https://en.wiktionary.org/wiki/%E6%8A%80%E8%83%BD#Chinese) | occupational skill; technical ability | jì néng · noun |
| [歌手](https://en.wiktionary.org/wiki/%E6%AD%8C%E6%89%8B#Chinese) | singer; vocalist; artist (recording artist) | gē shǒu · noun |
| [突出](https://en.wiktionary.org/wiki/%E7%AA%81%E5%87%BA#Chinese) | to burst out; to break through | tū chū · verb |
| [大使](https://en.wiktionary.org/wiki/%E5%A4%A7%E4%BD%BF#Chinese) | ambassador (minister, messenger or corporate representative) (Classifier: 名 m; 位 m) | dà shǐ · noun |
| [新型](https://en.wiktionary.org/wiki/%E6%96%B0%E5%9E%8B#Chinese) | new-style; new-type; new | xīn xíng · adj |

</details>

<details><summary>Words 351–400</summary>

![[Resources/Audio/zh/Words 0351-0400.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [高校](https://en.wiktionary.org/wiki/%E9%AB%98%E6%A0%A1#Chinese) | Japanese high schools | gāo xiào · noun |
| [博客](https://en.wiktionary.org/wiki/%E5%8D%9A%E5%AE%A2#Chinese) | blog | bó kè · noun |
| [J](https://en.wiktionary.org/wiki/J#Chinese) | penis (Classifier: 條／条 c) | J · noun |
| [人工](https://en.wiktionary.org/wiki/%E4%BA%BA%E5%B7%A5#Chinese) | man-made; artificial | rén gōng · adj |
| [加以](https://en.wiktionary.org/wiki/%E5%8A%A0%E4%BB%A5#Chinese) | in addition; moreover; further | jiā yǐ · conj |
| [道理](https://en.wiktionary.org/wiki/%E9%81%93%E7%90%86#Chinese) | reason; argument; sense; logic | dào lǐ · noun |
| [U](https://en.wiktionary.org/wiki/U#Chinese) | university (Classifier: 間／间 c) | U · noun |
| [上班](https://en.wiktionary.org/wiki/%E4%B8%8A%E7%8F%AD#Chinese) | to be on duty; to go to work; to begin one's work day; to begin one's shift | shàng bān · verb |
| [反抗](https://en.wiktionary.org/wiki/%E5%8F%8D%E6%8A%97#Chinese) | to revolt; to resist; to rebel | fǎn kàng · verb |
| [天使](https://en.wiktionary.org/wiki/%E5%A4%A9%E4%BD%BF#Chinese) | angel | tiān shǐ · noun |
| [天空](https://en.wiktionary.org/wiki/%E5%A4%A9%E7%A9%BA#Chinese) | sky; heavens; firmament | tiān kōng · noun |
| [差不多](https://en.wiktionary.org/wiki/%E5%B7%AE%E4%B8%8D%E5%A4%9A#Chinese) | similar; about the same; good enough | chà bu duō · adj |
| [引用](https://en.wiktionary.org/wiki/%E5%BC%95%E7%94%A8#Chinese) | to quote; to cite | yǐn yòng · verb |
| [最初](https://en.wiktionary.org/wiki/%E6%9C%80%E5%88%9D#Chinese) | beginning; outset; start | zuì chū · noun |
| [物理](https://en.wiktionary.org/wiki/%E7%89%A9%E7%90%86#Chinese) | physics | wù lǐ · noun |
| [商店](https://en.wiktionary.org/wiki/%E5%95%86%E5%BA%97#Chinese) | shop; store (establishment that sells goods) (Classifier: 家 m; 間／间 c) | shāng diàn · noun |
| [外面](https://en.wiktionary.org/wiki/%E5%A4%96%E9%9D%A2#Chinese) | outside; out | wài miàn · noun |
| [成人](https://en.wiktionary.org/wiki/%E6%88%90%E4%BA%BA#Chinese) | adult; grown-up | chéng rén · noun |
| [最早](https://en.wiktionary.org/wiki/%E6%9C%80%E6%97%A9#Chinese) | earliest | zuì zǎo · adj |
| [通信](https://en.wiktionary.org/wiki/%E9%80%9A%E4%BF%A1#Chinese) | to correspond (communicate by exchanging letters); to communicate | tōng xìn · verb |
| [Q](https://en.wiktionary.org/wiki/Q#Chinese) | cute | Q · adj |
| [一把](https://en.wiktionary.org/wiki/%E4%B8%80%E6%8A%8A#Chinese) | a bunch of; a bundle of | yī bǎ · noun |
| [商人](https://en.wiktionary.org/wiki/%E5%95%86%E4%BA%BA#Chinese) | merchant; businessperson | shāng rén · noun |
| [月份](https://en.wiktionary.org/wiki/%E6%9C%88%E4%BB%BD#Chinese) | month | yuè fèn · noun |
| [都市](https://en.wiktionary.org/wiki/%E9%83%BD%E5%B8%82#Chinese) | metropolis; major city | dū shì · noun |
| [幻想](https://en.wiktionary.org/wiki/%E5%B9%BB%E6%83%B3#Chinese) | to have illusions; to have delusions | huàn xiǎng · verb |
| [便宜](https://en.wiktionary.org/wiki/%E4%BE%BF%E5%AE%9C#Chinese) | cheap; inexpensive | pián yi · adj |
| [精彩](https://en.wiktionary.org/wiki/%E7%B2%BE%E5%BD%A9#Chinese) | brilliant; splendid; outstanding; exquisite; amazing | jīng cǎi · adj |
| [一人](https://en.wiktionary.org/wiki/%E4%B8%80%E4%BA%BA#Chinese) | a person; one person; someone | yī rén · noun |
| [大人](https://en.wiktionary.org/wiki/%E5%A4%A7%E4%BA%BA#Chinese) | adult; grown-up | dà rén · noun |
| [舒服](https://en.wiktionary.org/wiki/%E8%88%92%E6%9C%8D#Chinese) | comfortable; relaxed and happy; providing ease and relaxation | shū fú · adj |
| [上去](https://en.wiktionary.org/wiki/%E4%B8%8A%E5%8E%BB#Chinese) | to go up | shàng qù · verb |
| [北方](https://en.wiktionary.org/wiki/%E5%8C%97%E6%96%B9#Chinese) | north | běi fāng · noun |
| [可靠](https://en.wiktionary.org/wiki/%E5%8F%AF%E9%9D%A0#Chinese) | dependable; reliable | kě kào · adj |
| [坦克](https://en.wiktionary.org/wiki/%E5%9D%A6%E5%85%8B#Chinese) | tank (armoured fighting vehicle) (Classifier: 輛／辆 m; 部 m c; 臺／台 m; 架 c) | tǎn kè · noun |
| [空中](https://en.wiktionary.org/wiki/%E7%A9%BA%E4%B8%AD#Chinese) | aerial; in the air; in the sky | kōng zhōng · adj |
| [指示](https://en.wiktionary.org/wiki/%E6%8C%87%E7%A4%BA#Chinese) | to show clearly; to point out; to indicate; to demonstrate | zhǐ shì · verb |
| [秩序](https://en.wiktionary.org/wiki/%E7%A7%A9%E5%BA%8F#Chinese) | order; law and order | zhì xù · noun |
| [女神](https://en.wiktionary.org/wiki/%E5%A5%B3%E7%A5%9E#Chinese) | goddess | nǚ shén · noun |
| [特性](https://en.wiktionary.org/wiki/%E7%89%B9%E6%80%A7#Chinese) | special property, characteristic or trait; peculiarity | tè xìng · noun |
| [百姓](https://en.wiktionary.org/wiki/%E7%99%BE%E5%A7%93#Chinese) | the common people; the masses; ordinary citizens | bǎi xìng · noun |
| [青少年](https://en.wiktionary.org/wiki/%E9%9D%92%E5%B0%91%E5%B9%B4#Chinese) | young person; youth; adolescent; teenager | qīng shào nián · noun |
| [do](https://en.wiktionary.org/wiki/do#Chinese) | to do | do · verb |
| [一方](https://en.wiktionary.org/wiki/%E4%B8%80%E6%96%B9#Chinese) | one side | yī fāng · noun |
| [前提](https://en.wiktionary.org/wiki/%E5%89%8D%E6%8F%90#Chinese) | premise | qián tí · noun |
| [微笑](https://en.wiktionary.org/wiki/%E5%BE%AE%E7%AC%91#Chinese) | to smile | wēi xiào · verb |
| [火箭](https://en.wiktionary.org/wiki/%E7%81%AB%E7%AE%AD#Chinese) | rocket (non-guided missile or vehicle propelled by a rocket engine) (shape resembles arrow) (Classifier: 枚 m) | huǒ jiàn · noun |
| [玻璃](https://en.wiktionary.org/wiki/%E7%8E%BB%E7%92%83#Chinese) | glass (Classifier: 張／张 m; 塊／块 m c) | bō lí · noun |
| [西北](https://en.wiktionary.org/wiki/%E8%A5%BF%E5%8C%97#Chinese) | northwest | xī běi · noun |
| [中部](https://en.wiktionary.org/wiki/%E4%B8%AD%E9%83%A8#Chinese) | middle; middle part | zhōng bù · noun |

</details>

<details><summary>Words 401–450</summary>

![[Resources/Audio/zh/Words 0401-0450.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [入口](https://en.wiktionary.org/wiki/%E5%85%A5%E5%8F%A3#Chinese) | entrance; the "in" door; access | rù kǒu · noun |
| [大事](https://en.wiktionary.org/wiki/%E5%A4%A7%E4%BA%8B#Chinese) | important matter; big deal; major event; great thing | dà shì · noun |
| [大臣](https://en.wiktionary.org/wiki/%E5%A4%A7%E8%87%A3#Chinese) | minister (of an imperial regime, cabinet, etc.); high-level official (of a monarchy); secretary; chancellor | dà chén · noun |
| [夫妻](https://en.wiktionary.org/wiki/%E5%A4%AB%E5%A6%BB#Chinese) | husband and wife; married couple (Classifier: 對／对) | fū qī · noun |
| [一本](https://en.wiktionary.org/wiki/%E4%B8%80%E6%9C%AC#Chinese) | having the same origin | yī běn · adj |
| [佛教](https://en.wiktionary.org/wiki/%E4%BD%9B%E6%95%99#Chinese) | Buddhism | fó jiào · noun |
| [百科](https://en.wiktionary.org/wiki/%E7%99%BE%E7%A7%91#Chinese) | all subjects; miscellaneous disciplines | bǎi kē · noun |
| [元素](https://en.wiktionary.org/wiki/%E5%85%83%E7%B4%A0#Chinese) | element | yuán sù · noun |
| [制裁](https://en.wiktionary.org/wiki/%E5%88%B6%E8%A3%81#Chinese) | to impose legal sanctions | zhì cái · verb |
| [女朋友](https://en.wiktionary.org/wiki/%E5%A5%B3%E6%9C%8B%E5%8F%8B#Chinese) | girlfriend (Classifier: 個／个 m c) | nǚ péng yǒu · noun |
| [好吃](https://en.wiktionary.org/wiki/%E5%A5%BD%E5%90%83#Chinese) | delicious; delectable; tasty; scrumptious; yummy | hǎo chī · adj |
| [打造](https://en.wiktionary.org/wiki/%E6%89%93%E9%80%A0#Chinese) | to make by hand; to forge (metal) | dǎ zào · verb |
| [游泳](https://en.wiktionary.org/wiki/%E6%B8%B8%E6%B3%B3#Chinese) | to swim | yóu yǒng · verb |
| [其次](https://en.wiktionary.org/wiki/%E5%85%B6%E6%AC%A1#Chinese) | next or second in the sequence | qí cì · pron |
| [玩具](https://en.wiktionary.org/wiki/%E7%8E%A9%E5%85%B7#Chinese) | toy (Classifier: 個／个 m c; 件 m c) | wán jù · noun |
| [男朋友](https://en.wiktionary.org/wiki/%E7%94%B7%E6%9C%8B%E5%8F%8B#Chinese) | boyfriend (Classifier: 個／个 m c) | nán péng yǒu · noun |
| [西南](https://en.wiktionary.org/wiki/%E8%A5%BF%E5%8D%97#Chinese) | southwest | xī nán · noun |
| [全身](https://en.wiktionary.org/wiki/%E5%85%A8%E8%BA%AB#Chinese) | full body; the whole body | quán shēn · noun |
| [客人](https://en.wiktionary.org/wiki/%E5%AE%A2%E4%BA%BA#Chinese) | guest; visitor (Classifier: 位 m c; 幫／帮 m; 撥／拨 m) | kè rén · noun |
| [巴士](https://en.wiktionary.org/wiki/%E5%B7%B4%E5%A3%AB#Chinese) | bus (Classifier: 輛／辆 m; 架 c; 部 c) | bā shì · noun |
| [愉快](https://en.wiktionary.org/wiki/%E6%84%89%E5%BF%AB#Chinese) | happy; pleasant; enjoyable | yú kuài · adj |
| [正好](https://en.wiktionary.org/wiki/%E6%AD%A3%E5%A5%BD#Chinese) | just right; just in time; just at the right moment | zhèng hǎo · adj |
| [透明](https://en.wiktionary.org/wiki/%E9%80%8F%E6%98%8E#Chinese) | transparent (allowing light to pass through) | tòu míng · adj |
| [iPhone](https://en.wiktionary.org/wiki/iPhone#Chinese) | iPhone (the Apple iPhone) | iPhone · noun |
| [世上](https://en.wiktionary.org/wiki/%E4%B8%96%E4%B8%8A#Chinese) | in all of the world; in the whole world; on earth | shì shàng · noun |
| [以便](https://en.wiktionary.org/wiki/%E4%BB%A5%E4%BE%BF#Chinese) | in order to | yǐ biàn · conj |
| [只好](https://en.wiktionary.org/wiki/%E5%8F%AA%E5%A5%BD#Chinese) | have to; can only; have no choice but to; be forced to | zhǐ hǎo · adv |
| [姓名](https://en.wiktionary.org/wiki/%E5%A7%93%E5%90%8D#Chinese) | full name (of a person) | xìng míng · noun |
| [水果](https://en.wiktionary.org/wiki/%E6%B0%B4%E6%9E%9C#Chinese) | fruit (a juicy or fleshy one, like an apple or banana) | shuǐ guǒ · noun |
| [出身](https://en.wiktionary.org/wiki/%E5%87%BA%E8%BA%AB#Chinese) | to devote oneself (to); to give up one's life (for) | chū shēn · verb |
| [原料](https://en.wiktionary.org/wiki/%E5%8E%9F%E6%96%99#Chinese) | raw material | yuán liào · noun |
| [太太](https://en.wiktionary.org/wiki/%E5%A4%AA%E5%A4%AA#Chinese) | An honorific for adults, usually conferred on married women following the surname of their husband: Mrs | tài tài · noun |
| [聚集](https://en.wiktionary.org/wiki/%E8%81%9A%E9%9B%86#Chinese) | to gather; to assemble; to collect | jù jí · verb |
| [色情](https://en.wiktionary.org/wiki/%E8%89%B2%E6%83%85#Chinese) | lust; sexual desire; sexuality | sè qíng · noun |
| [一度](https://en.wiktionary.org/wiki/%E4%B8%80%E5%BA%A6#Chinese) | once (one time) | yí dù · noun |
| [同年](https://en.wiktionary.org/wiki/%E5%90%8C%E5%B9%B4#Chinese) | of the same age | tóng nián · adj |
| [意志](https://en.wiktionary.org/wiki/%E6%84%8F%E5%BF%97#Chinese) | will; determination; volition; intent | yì zhì · noun |
| [死刑](https://en.wiktionary.org/wiki/%E6%AD%BB%E5%88%91#Chinese) | death penalty; capital punishment | sǐ xíng · noun |
| [首相](https://en.wiktionary.org/wiki/%E9%A6%96%E7%9B%B8#Chinese) | prime minister | shǒu xiàng · noun |
| [一日](https://en.wiktionary.org/wiki/%E4%B8%80%E6%97%A5#Chinese) | another day in the future | yī rì · noun |
| [抵抗](https://en.wiktionary.org/wiki/%E6%8A%B5%E6%8A%97#Chinese) | to resist; to take up resistance against | dǐ kàng · verb |
| [迎接](https://en.wiktionary.org/wiki/%E8%BF%8E%E6%8E%A5#Chinese) | to meet, greet and welcome (someone); to pick up (a person) | yíng jiē · verb |
| [高潮](https://en.wiktionary.org/wiki/%E9%AB%98%E6%BD%AE#Chinese) | high tide; high water (Classifier: 個／个; 次) | gāo cháo · noun |
| [人力](https://en.wiktionary.org/wiki/%E4%BA%BA%E5%8A%9B#Chinese) | manpower; human power | rén lì · noun |
| [六月](https://en.wiktionary.org/wiki/%E5%85%AD%E6%9C%88#Chinese) | June | liù yuè · noun |
| [喂](https://en.wiktionary.org/wiki/%E5%96%82#Chinese) | hello?; yes? (greeting, used when responding to a call, such as a phone call) | wèi · intj |
| [喔](https://en.wiktionary.org/wiki/%E5%96%94#Chinese) | Particle conveying realization or surprise. | ō · intj |
| [大哥](https://en.wiktionary.org/wiki/%E5%A4%A7%E5%93%A5#Chinese) | eldest brother | dà gē · noun |
| [姐妹](https://en.wiktionary.org/wiki/%E5%A7%90%E5%A6%B9#Chinese) | elder sister and younger sister; sisters | jiě mèi · noun |
| [平安](https://en.wiktionary.org/wiki/%E5%B9%B3%E5%AE%89#Chinese) | safe and sound; safe; peaceful | píng ān · adj |

</details>

<details><summary>Words 451–500</summary>

![[Resources/Audio/zh/Words 0451-0500.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [投降](https://en.wiktionary.org/wiki/%E6%8A%95%E9%99%8D#Chinese) | to surrender; to capitulate | tóu xiáng · verb |
| [死者](https://en.wiktionary.org/wiki/%E6%AD%BB%E8%80%85#Chinese) | the dead; the deceased; the departed | sǐ zhě · noun |
| [不明](https://en.wiktionary.org/wiki/%E4%B8%8D%E6%98%8E#Chinese) | to not understand | bù míng · verb |
| [沿海](https://en.wiktionary.org/wiki/%E6%B2%BF%E6%B5%B7#Chinese) | coastal areas; (along the) coast | yán hǎi · noun |
| [淘汰](https://en.wiktionary.org/wiki/%E6%B7%98%E6%B1%B0#Chinese) | to rinse; to wash away | táo tài · verb |
| [王子](https://en.wiktionary.org/wiki/%E7%8E%8B%E5%AD%90#Chinese) | prince (son of a monarch) | wáng zǐ · noun |
| [皇后](https://en.wiktionary.org/wiki/%E7%9A%87%E5%90%8E#Chinese) | empress, particularly an empress consort | huáng hòu · noun |
| [集合](https://en.wiktionary.org/wiki/%E9%9B%86%E5%90%88#Chinese) | to assemble; to gather | jí hé · verb |
| [面包](https://en.wiktionary.org/wiki/%E9%9D%A2%E5%8C%85#Chinese) | face | miàn bāo · noun |
| [印刷](https://en.wiktionary.org/wiki/%E5%8D%B0%E5%88%B7#Chinese) | to print (to produce one or more copies of a text or image on a surface by machine) | yìn shuā · verb |
| [手指](https://en.wiktionary.org/wiki/%E6%89%8B%E6%8C%87#Chinese) | finger (Classifier: 根 m; 隻／只 m c) | shǒu zhǐ · noun |
| [春天](https://en.wiktionary.org/wiki/%E6%98%A5%E5%A4%A9#Chinese) | spring (season) | chūn tiān · noun |
| [自信](https://en.wiktionary.org/wiki/%E8%87%AA%E4%BF%A1#Chinese) | to have confidence in oneself; to be self-confident | zì xìn · verb |
| [街上](https://en.wiktionary.org/wiki/%E8%A1%97%E4%B8%8A#Chinese) | on the street | jiē shàng · noun |
| [任意](https://en.wiktionary.org/wiki/%E4%BB%BB%E6%84%8F#Chinese) | as one pleases; as one likes; whatever one wants | rèn yì · adv |
| [功夫](https://en.wiktionary.org/wiki/%E5%8A%9F%E5%A4%AB#Chinese) | time available, required, or spent doing something | gōng fu · noun |
| [沙漠](https://en.wiktionary.org/wiki/%E6%B2%99%E6%BC%A0#Chinese) | desert (barren area) | shā mò · noun |
| [癌症](https://en.wiktionary.org/wiki/%E7%99%8C%E7%97%87#Chinese) | cancer (disease in which the cells of a tissue undergo proliferation) | ái zhèng · noun |
| [三月](https://en.wiktionary.org/wiki/%E4%B8%89%E6%9C%88#Chinese) | March, the third month of the Gregorian solar calendar. | sān yuè · noun |
| [使命](https://en.wiktionary.org/wiki/%E4%BD%BF%E5%91%BD#Chinese) | mission; set task; assignment | shǐ mìng · noun |
| [同胞](https://en.wiktionary.org/wiki/%E5%90%8C%E8%83%9E#Chinese) | offspring born from the same parents; siblings | tóng bāo · noun |
| [名人](https://en.wiktionary.org/wiki/%E5%90%8D%E4%BA%BA#Chinese) | well-known person; celebrity; figure | míng rén · noun |
| [救援](https://en.wiktionary.org/wiki/%E6%95%91%E6%8F%B4#Chinese) | to rescue; to come to someone's rescue; to come to someone's aid; to provide relief | jiù yuán · verb |
| [有意思](https://en.wiktionary.org/wiki/%E6%9C%89%E6%84%8F%E6%80%9D#Chinese) | interesting; absorbing; engaging; delightful | yǒu yì si · adj |
| [物流](https://en.wiktionary.org/wiki/%E7%89%A9%E6%B5%81#Chinese) | logistics; physical distribution | wù liú · noun |
| [不利](https://en.wiktionary.org/wiki/%E4%B8%8D%E5%88%A9#Chinese) | unfavorable; disadvantageous; harmful; detrimental; adverse | bù lì · adj |
| [四月](https://en.wiktionary.org/wiki/%E5%9B%9B%E6%9C%88#Chinese) | April | sì yuè · noun |
| [常用](https://en.wiktionary.org/wiki/%E5%B8%B8%E7%94%A8#Chinese) | commonly used; in common use | cháng yòng · adj |
| [明年](https://en.wiktionary.org/wiki/%E6%98%8E%E5%B9%B4#Chinese) | next year | míng nián · noun |
| [殖民地](https://en.wiktionary.org/wiki/%E6%AE%96%E6%B0%91%E5%9C%B0#Chinese) | colony | zhí mín dì · noun |
| [治安](https://en.wiktionary.org/wiki/%E6%B2%BB%E5%AE%89#Chinese) | public security; public order; the peace | zhì ān · noun |
| [海岸](https://en.wiktionary.org/wiki/%E6%B5%B7%E5%B2%B8#Chinese) | coast; seashore | hǎi àn · noun |
| [超市](https://en.wiktionary.org/wiki/%E8%B6%85%E5%B8%82#Chinese) | supermarket (Classifier: 家 m; 間／间 c) | chāo shì · noun |
| [足以](https://en.wiktionary.org/wiki/%E8%B6%B3%E4%BB%A5#Chinese) | sufficient to; enough to | zú yǐ · adv |
| [天地](https://en.wiktionary.org/wiki/%E5%A4%A9%E5%9C%B0#Chinese) | sky and ground; heaven and earth | tiān dì · noun |
| [激情](https://en.wiktionary.org/wiki/%E6%BF%80%E6%83%85#Chinese) | passion; fervor; enthusiasm; intense emotion; ardor; electricity | jī qíng · noun |
| [老百姓](https://en.wiktionary.org/wiki/%E8%80%81%E7%99%BE%E5%A7%93#Chinese) | ordinary citizen; the common people; the masses (Classifier: 個／个 m c mn) | lǎo bǎi xìng · noun |
| [血液](https://en.wiktionary.org/wiki/%E8%A1%80%E6%B6%B2#Chinese) | blood | xuè yè · noun |
| [否定](https://en.wiktionary.org/wiki/%E5%90%A6%E5%AE%9A#Chinese) | to negate; to deny | fǒu dìng · verb |
| [宣告](https://en.wiktionary.org/wiki/%E5%AE%A3%E5%91%8A#Chinese) | to issue a proclamation; to make a declaration | xuān gào · verb |
| [尊敬](https://en.wiktionary.org/wiki/%E5%B0%8A%E6%95%AC#Chinese) | to respect; to honour; to hold in high esteem | zūn jìng · verb |
| [披露](https://en.wiktionary.org/wiki/%E6%8A%AB%E9%9C%B2#Chinese) | to make public | pī lù · verb |
| [海拔](https://en.wiktionary.org/wiki/%E6%B5%B7%E6%8B%94#Chinese) | altitude; height above sea level | hǎi bá · noun |
| [跳舞](https://en.wiktionary.org/wiki/%E8%B7%B3%E8%88%9E#Chinese) | to dance (move rhythmically) | tiào wǔ · verb |
| [GDP](https://en.wiktionary.org/wiki/GDP#Chinese) | GDP (“gross domestic product”); synonym of 國內生產總值 /国内生产总值 (guónèi shēngchǎn zǒngzhí) | GDP · noun |
| [玫瑰](https://en.wiktionary.org/wiki/%E7%8E%AB%E7%91%B0#Chinese) | rugosa rose (Rosa rugosa) | méi guī · noun |
| [人格](https://en.wiktionary.org/wiki/%E4%BA%BA%E6%A0%BC#Chinese) | personality; character | rén gé · noun |
| [八月](https://en.wiktionary.org/wiki/%E5%85%AB%E6%9C%88#Chinese) | August | bā yuè · noun |
| [字母](https://en.wiktionary.org/wiki/%E5%AD%97%E6%AF%8D#Chinese) | letter (of an alphabet) | zì mǔ · noun |
| [情人](https://en.wiktionary.org/wiki/%E6%83%85%E4%BA%BA#Chinese) | lover; sweetheart | qíng rén · noun |

</details>

<details><summary>Words 501–550</summary>

![[Resources/Audio/zh/Words 0501-0550.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [七月](https://en.wiktionary.org/wiki/%E4%B8%83%E6%9C%88#Chinese) | July | qī yuè · noun |
| [不安](https://en.wiktionary.org/wiki/%E4%B8%8D%E5%AE%89#Chinese) | uneasy; disturbed; restless; anxious | bù ān · adj |
| [九月](https://en.wiktionary.org/wiki/%E4%B9%9D%E6%9C%88#Chinese) | September | jiǔ yuè · noun |
| [哈哈](https://en.wiktionary.org/wiki/%E5%93%88%E5%93%88#Chinese) | the sound of someone laughing out loud | hā hā · adj |
| [唱歌](https://en.wiktionary.org/wiki/%E5%94%B1%E6%AD%8C#Chinese) | to sing (songs) | chàng gē · verb |
| [地域](https://en.wiktionary.org/wiki/%E5%9C%B0%E5%9F%9F#Chinese) | area; district; geographic region | dì yù · noun |
| [弟子](https://en.wiktionary.org/wiki/%E5%BC%9F%E5%AD%90#Chinese) | disciple; follower | dì zǐ · noun |
| [抱歉](https://en.wiktionary.org/wiki/%E6%8A%B1%E6%AD%89#Chinese) | to be sorry; to feel apologetic | bào qiàn · verb |
| [指令](https://en.wiktionary.org/wiki/%E6%8C%87%E4%BB%A4#Chinese) | to instruct; to direct; to order | zhǐ lìng · verb |
| [提案](https://en.wiktionary.org/wiki/%E6%8F%90%E6%A1%88#Chinese) | proposal; motion | tí àn · noun |
| [窗口](https://en.wiktionary.org/wiki/%E7%AA%97%E5%8F%A3#Chinese) | window (opening in a wall or roof) | chuāng kǒu · noun |
| [阿姨](https://en.wiktionary.org/wiki/%E9%98%BF%E5%A7%A8#Chinese) | maternal aunt (mother's sister or female cousin) | ā yí · noun |
| [冬天](https://en.wiktionary.org/wiki/%E5%86%AC%E5%A4%A9#Chinese) | winter | dōng tiān · noun |
| [和尚](https://en.wiktionary.org/wiki/%E5%92%8C%E5%B0%9A#Chinese) | preceptor; high priest; head monk | hé shàng · noun |
| [器官](https://en.wiktionary.org/wiki/%E5%99%A8%E5%AE%98#Chinese) | organ | qì guān · noun |
| [天才](https://en.wiktionary.org/wiki/%E5%A4%A9%E6%89%8D#Chinese) | talent; gift; genius | tiān cái · noun |
| [宿舍](https://en.wiktionary.org/wiki/%E5%AE%BF%E8%88%8D#Chinese) | dormitory; living quarters (Classifier: 間／间) | sù shè · noun |
| [教室](https://en.wiktionary.org/wiki/%E6%95%99%E5%AE%A4#Chinese) | classroom (Classifier: 間／间) | jiào shì · noun |
| [新年](https://en.wiktionary.org/wiki/%E6%96%B0%E5%B9%B4#Chinese) | New Year (in the Gregorian calendar or Chinese calendar) | xīn nián · noun |
| [牛奶](https://en.wiktionary.org/wiki/%E7%89%9B%E5%A5%B6#Chinese) | cow's milk | niú nǎi · noun |
| [蛋糕](https://en.wiktionary.org/wiki/%E8%9B%8B%E7%B3%95#Chinese) | cake (Western sweet food made from flour, eggs, etc.) (Classifier: 個／个 m c; 塊／块 m) | dàn gāo · noun |
| [live](https://en.wiktionary.org/wiki/live#Chinese) | to broadcast live; to stream | live · verb |
| [人心](https://en.wiktionary.org/wiki/%E4%BA%BA%E5%BF%83#Chinese) | people's thoughts; public feeling | rén xīn · noun |
| [冬季](https://en.wiktionary.org/wiki/%E5%86%AC%E5%AD%A3#Chinese) | winter | dōng jì · noun |
| [安置](https://en.wiktionary.org/wiki/%E5%AE%89%E7%BD%AE#Chinese) | to arrange for; to help settle down; to find a place for | ān zhì · verb |
| [性命](https://en.wiktionary.org/wiki/%E6%80%A7%E5%91%BD#Chinese) | life; survival | xìng mìng · noun |
| [有名](https://en.wiktionary.org/wiki/%E6%9C%89%E5%90%8D#Chinese) | famous; well-known; noted; renowned | yǒu míng · adj |
| [精英](https://en.wiktionary.org/wiki/%E7%B2%BE%E8%8B%B1#Chinese) | best feature or most important part (of something); essence; quintessence | jīng yīng · noun |
| [夏季](https://en.wiktionary.org/wiki/%E5%A4%8F%E5%AD%A3#Chinese) | summer | xià jì · noun |
| [字幕](https://en.wiktionary.org/wiki/%E5%AD%97%E5%B9%95#Chinese) | subtitle; caption | zì mù · noun |
| [生理](https://en.wiktionary.org/wiki/%E7%94%9F%E7%90%86#Chinese) | physiology; normal functioning of living organisms and their parts | shēng lǐ · noun |
| [老虎](https://en.wiktionary.org/wiki/%E8%80%81%E8%99%8E#Chinese) | tiger (Classifier: 隻／只 m c j; 頭／头 m; 匹 m) | lǎo hǔ · noun |
| [耳朵](https://en.wiktionary.org/wiki/%E8%80%B3%E6%9C%B5#Chinese) | ear (organ of hearing) | ěr duǒ · noun |
| [CD](https://en.wiktionary.org/wiki/CD#Chinese) | CD, compact disk (Classifier: 張／张 m c; 隻／只 c) | CD · noun |
| [便利](https://en.wiktionary.org/wiki/%E4%BE%BF%E5%88%A9#Chinese) | convenient; handy | biàn lì · adj |
| [改名](https://en.wiktionary.org/wiki/%E6%94%B9%E5%90%8D#Chinese) | to change names; to be renamed | gǎi míng · verb |
| [洪水](https://en.wiktionary.org/wiki/%E6%B4%AA%E6%B0%B4#Chinese) | flood (usually disastrous overflow from a body of water); flooding; floodwater | hóng shuǐ · noun |
| [白天](https://en.wiktionary.org/wiki/%E7%99%BD%E5%A4%A9#Chinese) | daytime; day | bái tiān · noun |
| [真人](https://en.wiktionary.org/wiki/%E7%9C%9F%E4%BA%BA#Chinese) | real person; real people | zhēn rén · noun |
| [一共](https://en.wiktionary.org/wiki/%E4%B8%80%E5%85%B1#Chinese) | altogether; in total; in all; in sum | yī gòng · adv |
| [十月](https://en.wiktionary.org/wiki/%E5%8D%81%E6%9C%88#Chinese) | October | shí yuè · noun |
| [武士](https://en.wiktionary.org/wiki/%E6%AD%A6%E5%A3%AB#Chinese) | warrior; fighter | wǔ shì · noun |
| [火山](https://en.wiktionary.org/wiki/%E7%81%AB%E5%B1%B1#Chinese) | volcano (Classifier: 座) | huǒ shān · noun |
| [起源](https://en.wiktionary.org/wiki/%E8%B5%B7%E6%BA%90#Chinese) | to originate; to come from | qǐ yuán · verb |
| [OK](https://en.wiktionary.org/wiki/OK#Chinese) | moderately; fairly | OK · adv |
| [不止](https://en.wiktionary.org/wiki/%E4%B8%8D%E6%AD%A2#Chinese) | to not stop | bù zhǐ · verb |
| [世人](https://en.wiktionary.org/wiki/%E4%B8%96%E4%BA%BA#Chinese) | ordinary person; average person; common people | shì rén · noun |
| [作物](https://en.wiktionary.org/wiki/%E4%BD%9C%E7%89%A9#Chinese) | crop (anything that is planted for its yield) (Classifier: 種／种) | zuò wù · noun |
| [侮辱](https://en.wiktionary.org/wiki/%E4%BE%AE%E8%BE%B1#Chinese) | to insult; to humiliate | wǔ rǔ · verb |
| [妓女](https://en.wiktionary.org/wiki/%E5%A6%93%E5%A5%B3#Chinese) | female prostitute | jì nǚ · noun |

</details>

<details><summary>Words 551–600</summary>

![[Resources/Audio/zh/Words 0551-0600.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [平原](https://en.wiktionary.org/wiki/%E5%B9%B3%E5%8E%9F#Chinese) | plain (large area of flat land with no trees); flatland (Classifier: 片 m) | píng yuán · noun |
| [星期一](https://en.wiktionary.org/wiki/%E6%98%9F%E6%9C%9F%E4%B8%80#Chinese) | Monday | xīng qī yī · noun |
| [昨日](https://en.wiktionary.org/wiki/%E6%98%A8%E6%97%A5#Chinese) | day before yesterday | zuó rì · noun |
| [月亮](https://en.wiktionary.org/wiki/%E6%9C%88%E4%BA%AE#Chinese) | moon | yuè liàng · noun |
| [脖子](https://en.wiktionary.org/wiki/%E8%84%96%E5%AD%90#Chinese) | neck | bó zi · noun |
| [一流](https://en.wiktionary.org/wiki/%E4%B8%80%E6%B5%81#Chinese) | first-class; first-rate | yì liú · adj |
| [不肯](https://en.wiktionary.org/wiki/%E4%B8%8D%E8%82%AF#Chinese) | to be unwilling to | bù kěn · verb |
| [二十](https://en.wiktionary.org/wiki/%E4%BA%8C%E5%8D%81#Chinese) | twenty; 20 | èr shí · num |
| [分解](https://en.wiktionary.org/wiki/%E5%88%86%E8%A7%A3#Chinese) | to decompose; to break down | fēn jiě · verb |
| [可笑](https://en.wiktionary.org/wiki/%E5%8F%AF%E7%AC%91#Chinese) | funny; hilarious | kě xiào · adj |
| [啤酒](https://en.wiktionary.org/wiki/%E5%95%A4%E9%85%92#Chinese) | beer | pí jiǔ · noun |
| [太子](https://en.wiktionary.org/wiki/%E5%A4%AA%E5%AD%90#Chinese) | crown prince; heir to a throne (Classifier: 位) | tài zi · noun |
| [打死](https://en.wiktionary.org/wiki/%E6%89%93%E6%AD%BB#Chinese) | to kill by beating; to beat to death | verb-complement · verb |
| [收拾](https://en.wiktionary.org/wiki/%E6%94%B6%E6%8B%BE#Chinese) | to tidy (a table, room, etc.); to put in order; to clean up; to clear; to pack (one’s bags) | shōu shí · verb |
| [政治家](https://en.wiktionary.org/wiki/%E6%94%BF%E6%B2%BB%E5%AE%B6#Chinese) | politician | zhèng zhì jiā · noun |
| [演奏](https://en.wiktionary.org/wiki/%E6%BC%94%E5%A5%8F#Chinese) | to play a musical instrument; to perform music; to give an instrumental performance | yǎn zòu · verb |
| [一番](https://en.wiktionary.org/wiki/%E4%B8%80%E7%95%AA#Chinese) | one time; once | yī fān · noun |
| [帽子](https://en.wiktionary.org/wiki/%E5%B8%BD%E5%AD%90#Chinese) | hat; cap; headgear; hood (of a jacket) (Classifier: 頂／顶 m; 摞 m) | mào zi · noun |
| [料理](https://en.wiktionary.org/wiki/%E6%96%99%E7%90%86#Chinese) | to arrange; to handle | liào lǐ · verb |
| [是非](https://en.wiktionary.org/wiki/%E6%98%AF%E9%9D%9E#Chinese) | right and wrong | shì fēi · noun |
| [最小](https://en.wiktionary.org/wiki/%E6%9C%80%E5%B0%8F#Chinese) | smallest; youngest; least; minimum; minimal | zuì xiǎo · noun |
| [朝廷](https://en.wiktionary.org/wiki/%E6%9C%9D%E5%BB%B7#Chinese) | royal court; imperial court; imperial household; imperial government | cháo tíng · noun |
| [up](https://en.wiktionary.org/wiki/up#Chinese) | to update | up · verb |
| [一股](https://en.wiktionary.org/wiki/%E4%B8%80%E8%82%A1#Chinese) | a clump of; a bunch of | yī gǔ · noun |
| [不及](https://en.wiktionary.org/wiki/%E4%B8%8D%E5%8F%8A#Chinese) | to not do something in time; to be too late | bù jí · verb |
| [主意](https://en.wiktionary.org/wiki/%E4%B8%BB%E6%84%8F#Chinese) | idea; plan | zhǔ yì · noun |
| [同盟](https://en.wiktionary.org/wiki/%E5%90%8C%E7%9B%9F#Chinese) | to form an alliance or league | tóng méng · verb |
| [巧克力](https://en.wiktionary.org/wiki/%E5%B7%A7%E5%85%8B%E5%8A%9B#Chinese) | chocolate | qiǎo kè lì · noun |
| [星期六](https://en.wiktionary.org/wiki/%E6%98%9F%E6%9C%9F%E5%85%AD#Chinese) | Saturday | xīng qī liù · noun |
| [犯人](https://en.wiktionary.org/wiki/%E7%8A%AF%E4%BA%BA#Chinese) | criminal (Classifier: 名 m) | fàn rén · noun |
| [起床](https://en.wiktionary.org/wiki/%E8%B5%B7%E5%BA%8A#Chinese) | to get up; to get out of bed; to wake up | qǐ chuáng · verb |
| [二月](https://en.wiktionary.org/wiki/%E4%BA%8C%E6%9C%88#Chinese) | February | èr yuè · noun |
| [偶然](https://en.wiktionary.org/wiki/%E5%81%B6%E7%84%B6#Chinese) | accidental; coincidental; by chance; random; fortuitous | ǒu rán · adj |
| [出租](https://en.wiktionary.org/wiki/%E5%87%BA%E7%A7%9F#Chinese) | to rent out | chū zū · verb |
| [忽然](https://en.wiktionary.org/wiki/%E5%BF%BD%E7%84%B6#Chinese) | suddenly | hū rán · adv |
| [救助](https://en.wiktionary.org/wiki/%E6%95%91%E5%8A%A9#Chinese) | to render assistance (in times of distress); to help (somebody in trouble); to rescue; to save; to aid; to provide relief | jiù zhù · verb |
| [草原](https://en.wiktionary.org/wiki/%E8%8D%89%E5%8E%9F#Chinese) | grassland; prairie; steppe; savanna | cǎo yuán · noun |
| [不好意思](https://en.wiktionary.org/wiki/%E4%B8%8D%E5%A5%BD%E6%84%8F%E6%80%9D#Chinese) | embarrassed; shy; ill at ease | bù hǎo yì sī · adj |
| [元年](https://en.wiktionary.org/wiki/%E5%85%83%E5%B9%B4#Chinese) | first year (of any period) | yuán nián · noun |
| [湖泊](https://en.wiktionary.org/wiki/%E6%B9%96%E6%B3%8A#Chinese) | lake (large, landlocked stretch of water) | hú pō · noun |
| [隧道](https://en.wiktionary.org/wiki/%E9%9A%A7%E9%81%93#Chinese) | tunnel (underground or underwater passage) | suì dào · noun |
| [鼻子](https://en.wiktionary.org/wiki/%E9%BC%BB%E5%AD%90#Chinese) | nose | bí zi · noun |
| [DNA](https://en.wiktionary.org/wiki/DNA#Chinese) | DNA | DNA · noun |
| [pro](https://en.wiktionary.org/wiki/pro#Chinese) | professional | pro · adj |
| [刑法](https://en.wiktionary.org/wiki/%E5%88%91%E6%B3%95#Chinese) | criminal law | xíng fǎ · noun |
| [勇士](https://en.wiktionary.org/wiki/%E5%8B%87%E5%A3%AB#Chinese) | brave person | yǒng shì · noun |
| [十一](https://en.wiktionary.org/wiki/%E5%8D%81%E4%B8%80#Chinese) | eleven; 11 | shí yī · num |
| [唱片](https://en.wiktionary.org/wiki/%E5%94%B1%E7%89%87#Chinese) | phonograph record; vinyl disc (Classifier: 張／张 m c; 隻／只 c h; 塊／块 mn) | chàng piàn · noun |
| [嘲笑](https://en.wiktionary.org/wiki/%E5%98%B2%E7%AC%91#Chinese) | to laugh at; to deride; to jeer; to mock; to ridicule | cháo xiào · verb |
| [大火](https://en.wiktionary.org/wiki/%E5%A4%A7%E7%81%AB#Chinese) | large fire; inferno; conflagration | dà huǒ · noun |

</details>

<details><summary>Words 601–650</summary>

![[Resources/Audio/zh/Words 0601-0650.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [消防](https://en.wiktionary.org/wiki/%E6%B6%88%E9%98%B2#Chinese) | to prevent and fight fire | xiāo fáng · verb |
| [火星](https://en.wiktionary.org/wiki/%E7%81%AB%E6%98%9F#Chinese) | to be outdated and unaware; to not know something that everyone else knows | huǒ xīng · verb |
| [SM](https://en.wiktionary.org/wiki/SM#Chinese) | S&M | SM · noun |
| [so](https://en.wiktionary.org/wiki/so#Chinese) | benefit; advantage; bargain; discount | so · noun |
| [全集](https://en.wiktionary.org/wiki/%E5%85%A8%E9%9B%86#Chinese) | complete works (of a writer or artist) | quán jí · noun |
| [此地](https://en.wiktionary.org/wiki/%E6%AD%A4%E5%9C%B0#Chinese) | this place; here | cǐ dì · noun |
| [浴室](https://en.wiktionary.org/wiki/%E6%B5%B4%E5%AE%A4#Chinese) | bathroom (room used for bathing) | yù shì · noun |
| [裁判](https://en.wiktionary.org/wiki/%E8%A3%81%E5%88%A4#Chinese) | to act as umpire or referee | cái pàn · verb |
| [man](https://en.wiktionary.org/wiki/man#Chinese) | manly; masculine | man · adj |
| [上任](https://en.wiktionary.org/wiki/%E4%B8%8A%E4%BB%BB#Chinese) | to take up a new post; to assume a new position | shàng rèn · verb |
| [口袋](https://en.wiktionary.org/wiki/%E5%8F%A3%E8%A2%8B#Chinese) | pocket (bag sewn into clothing) | kǒu dài · noun |
| [大夫](https://en.wiktionary.org/wiki/%E5%A4%A7%E5%A4%AB#Chinese) | (medical) doctor | dà fū · noun |
| [安定](https://en.wiktionary.org/wiki/%E5%AE%89%E5%AE%9A#Chinese) | stable; settled; secured | ān dìng · adj |
| [每人](https://en.wiktionary.org/wiki/%E6%AF%8F%E4%BA%BA#Chinese) | each person; everybody; per person | měi rén · noun |
| [短信](https://en.wiktionary.org/wiki/%E7%9F%AD%E4%BF%A1#Chinese) | text message; SMS (Classifier: 條／条 m) | duǎn xìn · noun |
| [原文](https://en.wiktionary.org/wiki/%E5%8E%9F%E6%96%87#Chinese) | source text; original text | yuán wén · noun |
| [坐下](https://en.wiktionary.org/wiki/%E5%9D%90%E4%B8%8B#Chinese) | to sit down | verb-complement · verb |
| [威力](https://en.wiktionary.org/wiki/%E5%A8%81%E5%8A%9B#Chinese) | power; might | wēi lì · noun |
| [意味](https://en.wiktionary.org/wiki/%E6%84%8F%E5%91%B3#Chinese) | significance; meaning; implication | yì wèi · noun |
| [上映](https://en.wiktionary.org/wiki/%E4%B8%8A%E6%98%A0#Chinese) | to be screened; to be shown | shàng yìng · verb |
| [上街](https://en.wiktionary.org/wiki/%E4%B8%8A%E8%A1%97#Chinese) | to go out onto the streets; to wander out onto the streets | shàng jiē · verb |
| [免疫](https://en.wiktionary.org/wiki/%E5%85%8D%E7%96%AB#Chinese) | immunity (from disease); immunization | miǎn yì · noun |
| [打工](https://en.wiktionary.org/wiki/%E6%89%93%E5%B7%A5#Chinese) | to work on a part-time, casual or temporary basis | dǎ gōng · verb |
| [星期五](https://en.wiktionary.org/wiki/%E6%98%9F%E6%9C%9F%E4%BA%94#Chinese) | Friday | xīng qī wǔ · noun |
| [牛肉](https://en.wiktionary.org/wiki/%E7%89%9B%E8%82%89#Chinese) | beef | niú ròu · noun |
| [生死](https://en.wiktionary.org/wiki/%E7%94%9F%E6%AD%BB#Chinese) | to live and die | shēng sǐ · verb |
| [睡眠](https://en.wiktionary.org/wiki/%E7%9D%A1%E7%9C%A0#Chinese) | sleep | shuì mián · noun |
| [香蕉](https://en.wiktionary.org/wiki/%E9%A6%99%E8%95%89#Chinese) | banana (fruit) (Classifier: 隻／只 m c; 根 m; 條／条 m c; 串 m; 把 m; 梳 c) | xiāng jiāo · noun |
| [怪物](https://en.wiktionary.org/wiki/%E6%80%AA%E7%89%A9#Chinese) | monster | guài wù · noun |
| [按摩](https://en.wiktionary.org/wiki/%E6%8C%89%E6%91%A9#Chinese) | to massage | àn mó · verb |
| [撤退](https://en.wiktionary.org/wiki/%E6%92%A4%E9%80%80#Chinese) | to withdraw; to pull out | chè tuì · verb |
| [民兵](https://en.wiktionary.org/wiki/%E6%B0%91%E5%85%B5#Chinese) | militia (army of trained civilians called upon in time of need) | mín bīng · noun |
| [行列](https://en.wiktionary.org/wiki/%E8%A1%8C%E5%88%97#Chinese) | row or column | háng liè · noun |
| [原子](https://en.wiktionary.org/wiki/%E5%8E%9F%E5%AD%90#Chinese) | atom (Classifier: 個／个 m) | yuán zi · noun |
| [多大](https://en.wiktionary.org/wiki/%E5%A4%9A%E5%A4%A7#Chinese) | how big; how large | duō dà · adj |
| [天生](https://en.wiktionary.org/wiki/%E5%A4%A9%E7%94%9F#Chinese) | innate; inborn; inherent; natural; intrinsic | tiān shēng · adj |
| [奠定](https://en.wiktionary.org/wiki/%E5%A5%A0%E5%AE%9A#Chinese) | to establish; to settle; to lay (e.g. a foundation for) | diàn dìng · verb |
| [流氓](https://en.wiktionary.org/wiki/%E6%B5%81%E6%B0%93#Chinese) | hooligan; scumbag; scoundrel | liú máng · noun |
| [艾滋病](https://en.wiktionary.org/wiki/%E8%89%BE%E6%BB%8B%E7%97%85#Chinese) | AIDS | ài zī bìng · noun |
| [解析](https://en.wiktionary.org/wiki/%E8%A7%A3%E6%9E%90#Chinese) | to analyze; to dissect; to deconstruct; to review | jiě xī · verb |
| [what](https://en.wiktionary.org/wiki/what#Chinese) | to WhatsApp; to send via WhatsApp | what · verb |
| [原油](https://en.wiktionary.org/wiki/%E5%8E%9F%E6%B2%B9#Chinese) | crude oil; crude | yuán yóu · noun |
| [大麻](https://en.wiktionary.org/wiki/%E5%A4%A7%E9%BA%BB#Chinese) | hemp (Cannabis sativa) | dà má · noun |
| [法人](https://en.wiktionary.org/wiki/%E6%B3%95%E4%BA%BA#Chinese) | corporate person; legal entity; legal person; juridical person | fǎ rén · noun |
| [海水](https://en.wiktionary.org/wiki/%E6%B5%B7%E6%B0%B4#Chinese) | seawater; ocean water | hǎi shuǐ · noun |
| [神父](https://en.wiktionary.org/wiki/%E7%A5%9E%E7%88%B6#Chinese) | father; priest | shén fù · noun |
| [蝴蝶](https://en.wiktionary.org/wiki/%E8%9D%B4%E8%9D%B6#Chinese) | butterfly (Classifier: 隻／只) | hú dié · noun |
| [一月](https://en.wiktionary.org/wiki/%E4%B8%80%E6%9C%88#Chinese) | January | yí yuè · noun |
| [影子](https://en.wiktionary.org/wiki/%E5%BD%B1%E5%AD%90#Chinese) | shadow | yǐng zi · noun |
| [解答](https://en.wiktionary.org/wiki/%E8%A7%A3%E7%AD%94#Chinese) | to answer | jiě dá · verb |

</details>

<details><summary>Words 651–700</summary>

![[Resources/Audio/zh/Words 0651-0700.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [陷阱](https://en.wiktionary.org/wiki/%E9%99%B7%E9%98%B1#Chinese) | trap (device designed to catch animals) | xiàn jǐng · noun |
| [house](https://en.wiktionary.org/wiki/house#Chinese) | mansion; large house (Classifier: 間／间 c) | house · noun |
| [中立](https://en.wiktionary.org/wiki/%E4%B8%AD%E7%AB%8B#Chinese) | to be neutral | zhōng lì · verb |
| [先行](https://en.wiktionary.org/wiki/%E5%85%88%E8%A1%8C#Chinese) | to advance; to move forward | xiān xíng · verb |
| [十二月](https://en.wiktionary.org/wiki/%E5%8D%81%E4%BA%8C%E6%9C%88#Chinese) | December | shí èr yuè · noun |
| [半天](https://en.wiktionary.org/wiki/%E5%8D%8A%E5%A4%A9#Chinese) | half a day | bàn tiān · noun |
| [得分](https://en.wiktionary.org/wiki/%E5%BE%97%E5%88%86#Chinese) | to score (e.g. score goals, score points) | dé fēn · verb |
| [明日](https://en.wiktionary.org/wiki/%E6%98%8E%E6%97%A5#Chinese) | future | míng rì · noun |
| [水晶](https://en.wiktionary.org/wiki/%E6%B0%B4%E6%99%B6#Chinese) | crystal | shuǐ jīng · noun |
| [消化](https://en.wiktionary.org/wiki/%E6%B6%88%E5%8C%96#Chinese) | to digest (food) | xiāo huà · verb |
| [老鼠](https://en.wiktionary.org/wiki/%E8%80%81%E9%BC%A0#Chinese) | mouse and rat in general (Classifier: 隻／只 m c h) | lǎo shǔ · noun |
| [自私](https://en.wiktionary.org/wiki/%E8%87%AA%E7%A7%81#Chinese) | selfish | zì sī · adj |
| [葡萄](https://en.wiktionary.org/wiki/%E8%91%A1%E8%90%84#Chinese) | grape (Classifier: 顆／颗 m; 串 m; 嘟嚕／嘟噜 m; 粒; 抽 c; 捾 mn) | pú táo · noun |
| [墓地](https://en.wiktionary.org/wiki/%E5%A2%93%E5%9C%B0#Chinese) | cemetery; graveyard; necropolis | mù dì · noun |
| [未成年](https://en.wiktionary.org/wiki/%E6%9C%AA%E6%88%90%E5%B9%B4#Chinese) | underage | wèi chéng nián · adj |
| [桌子](https://en.wiktionary.org/wiki/%E6%A1%8C%E5%AD%90#Chinese) | table; desk (Classifier: 張／张; 套) | zhuō zi · noun |
| [火焰](https://en.wiktionary.org/wiki/%E7%81%AB%E7%84%B0#Chinese) | flame | huǒ yàn · noun |
| [道具](https://en.wiktionary.org/wiki/%E9%81%93%E5%85%B7#Chinese) | prop; theatrical property | dào jù · noun |
| [show](https://en.wiktionary.org/wiki/show#Chinese) | to show; to display | show · verb |
| [一期](https://en.wiktionary.org/wiki/%E4%B8%80%E6%9C%9F#Chinese) | first phase (of a project) | yī qī · noun |
| [了不起](https://en.wiktionary.org/wiki/%E4%BA%86%E4%B8%8D%E8%B5%B7#Chinese) | amazing; terrific; extraordinary | liǎo bù qǐ · adj |
| [出路](https://en.wiktionary.org/wiki/%E5%87%BA%E8%B7%AF#Chinese) | way out | chū lù · noun |
| [家具](https://en.wiktionary.org/wiki/%E5%AE%B6%E5%85%B7#Chinese) | furniture (Classifier: 件 m; 套 m) | jiā jù · noun |
| [招募](https://en.wiktionary.org/wiki/%E6%8B%9B%E5%8B%9F#Chinese) | to enlist; to recruit; to hire | zhāo mù · verb |
| [摩擦](https://en.wiktionary.org/wiki/%E6%91%A9%E6%93%A6#Chinese) | to rub; to chafe; to press together | mó cā · verb |
| [棒球](https://en.wiktionary.org/wiki/%E6%A3%92%E7%90%83#Chinese) | baseball (sport common in North America, the Caribbean, and East Asia) | bàng qiú · noun |
| [椅子](https://en.wiktionary.org/wiki/%E6%A4%85%E5%AD%90#Chinese) | chair (Classifier: 把 m; 張／张 m) | yǐ zi · noun |
| [正要](https://en.wiktionary.org/wiki/%E6%AD%A3%E8%A6%81#Chinese) | to be just about to (do something); to be on the point of | zhèng yào · verb |
| [激光](https://en.wiktionary.org/wiki/%E6%BF%80%E5%85%89#Chinese) | laser | jī guāng · noun |
| [蜘蛛](https://en.wiktionary.org/wiki/%E8%9C%98%E8%9B%9B#Chinese) | spider | zhī zhū · noun |
| [II](https://en.wiktionary.org/wiki/II#Chinese) | illegal immigrant | II · noun |
| [以致](https://en.wiktionary.org/wiki/%E4%BB%A5%E8%87%B4#Chinese) | resulting in; so that | yǐ zhì · conj |
| [土豆](https://en.wiktionary.org/wiki/%E5%9C%9F%E8%B1%86#Chinese) | potato | tǔ dòu · noun |
| [安心](https://en.wiktionary.org/wiki/%E5%AE%89%E5%BF%83#Chinese) | to be relieved; to feel at ease | ān xīn · verb |
| [官兵](https://en.wiktionary.org/wiki/%E5%AE%98%E5%85%B5#Chinese) | officers and enlisted | guān bīng · noun |
| [江湖](https://en.wiktionary.org/wiki/%E6%B1%9F%E6%B9%96#Chinese) | rivers and lakes | jiāng hú · noun |
| [爵士](https://en.wiktionary.org/wiki/%E7%88%B5%E5%A3%AB#Chinese) | knight; sir | jué shì · noun |
| [良心](https://en.wiktionary.org/wiki/%E8%89%AF%E5%BF%83#Chinese) | conscience | liáng xīn · noun |
| [陛下](https://en.wiktionary.org/wiki/%E9%99%9B%E4%B8%8B#Chinese) | Your Majesty; His Majesty; Her Majesty | bì xià · noun |
| [中旬](https://en.wiktionary.org/wiki/%E4%B8%AD%E6%97%AC#Chinese) | middle 10 days of the month | zhōng xún · noun |
| [何必](https://en.wiktionary.org/wiki/%E4%BD%95%E5%BF%85#Chinese) | why; why on earth (i.e. there is no need); why bother | hé bì · adv |
| [十一月](https://en.wiktionary.org/wiki/%E5%8D%81%E4%B8%80%E6%9C%88#Chinese) | November | shí yī yuè · noun |
| [大雨](https://en.wiktionary.org/wiki/%E5%A4%A7%E9%9B%A8#Chinese) | heavy rain; downpour (Classifier: 場／场) | dà yǔ · noun |
| [心意](https://en.wiktionary.org/wiki/%E5%BF%83%E6%84%8F#Chinese) | one's feelings | xīn yì · noun |
| [灰色](https://en.wiktionary.org/wiki/%E7%81%B0%E8%89%B2#Chinese) | gray (color) | huī sè · noun |
| [猴子](https://en.wiktionary.org/wiki/%E7%8C%B4%E5%AD%90#Chinese) | monkey (Classifier: 隻／只 m) | hóu zi · noun |
| [秋天](https://en.wiktionary.org/wiki/%E7%A7%8B%E5%A4%A9#Chinese) | autumn; fall | qiū tiān · noun |
| [低下](https://en.wiktionary.org/wiki/%E4%BD%8E%E4%B8%8B#Chinese) | below average; mediocre; inferior | dī xià · adj |
| [屋子](https://en.wiktionary.org/wiki/%E5%B1%8B%E5%AD%90#Chinese) | room (in a building or house) (Classifier: 間／间 m) | wū zi · noun |
| [感冒](https://en.wiktionary.org/wiki/%E6%84%9F%E5%86%92#Chinese) | cold (common viral illness); common cold | gǎn mào · noun |

</details>

<details><summary>Words 701–750</summary>

![[Resources/Audio/zh/Words 0701-0750.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [星期日](https://en.wiktionary.org/wiki/%E6%98%9F%E6%9C%9F%E6%97%A5#Chinese) | Sunday | xīng qī rì · noun |
| [警官](https://en.wiktionary.org/wiki/%E8%AD%A6%E5%AE%98#Chinese) | police officer; constable | jǐng guān · noun |
| [量子](https://en.wiktionary.org/wiki/%E9%87%8F%E5%AD%90#Chinese) | quantum | liàng zǐ · noun |
| [住院](https://en.wiktionary.org/wiki/%E4%BD%8F%E9%99%A2#Chinese) | to stay in hospital; to be hospitalized | zhù yuàn · verb |
| [兔子](https://en.wiktionary.org/wiki/%E5%85%94%E5%AD%90#Chinese) | rabbit; hare (Classifier: 隻／只 m j) | tù zi · noun |
| [句子](https://en.wiktionary.org/wiki/%E5%8F%A5%E5%AD%90#Chinese) | sentence; phrase (Classifier: 個／个 m) | jù zi · noun |
| [衍生](https://en.wiktionary.org/wiki/%E8%A1%8D%E7%94%9F#Chinese) | to derive | yǎn shēng · verb |
| [首府](https://en.wiktionary.org/wiki/%E9%A6%96%E5%BA%9C#Chinese) | capital (of a state, autonomous region, etc.) | shǒu fǔ · noun |
| [三角](https://en.wiktionary.org/wiki/%E4%B8%89%E8%A7%92#Chinese) | triangle | sān jiǎo · noun |
| [不便](https://en.wiktionary.org/wiki/%E4%B8%8D%E4%BE%BF#Chinese) | inconvenient; having difficulty | bù biàn · adj |
| [作法](https://en.wiktionary.org/wiki/%E4%BD%9C%E6%B3%95#Chinese) | method; way of doing things | zuò fǎ · noun |
| [公子](https://en.wiktionary.org/wiki/%E5%85%AC%E5%AD%90#Chinese) | your son | gōng zi · noun |
| [友人](https://en.wiktionary.org/wiki/%E5%8F%8B%E4%BA%BA#Chinese) | friend | yǒu rén · noun |
| [咯](https://en.wiktionary.org/wiki/%E5%92%AF#Chinese) | this | gē · pron |
| [放入](https://en.wiktionary.org/wiki/%E6%94%BE%E5%85%A5#Chinese) | to place inside | fàng rù · verb |
| [放置](https://en.wiktionary.org/wiki/%E6%94%BE%E7%BD%AE#Chinese) | to put (in a certain place); to lay; to place; to set aside; to shelve | fàng zhì · verb |
| [月光](https://en.wiktionary.org/wiki/%E6%9C%88%E5%85%89#Chinese) | moonlight | yuè guāng · noun |
| [le](https://en.wiktionary.org/wiki/le#Chinese) | lesbian | le · noun |
| [人造](https://en.wiktionary.org/wiki/%E4%BA%BA%E9%80%A0#Chinese) | artificial; man-made | rén zào · noun |
| [吉他](https://en.wiktionary.org/wiki/%E5%90%89%E4%BB%96#Chinese) | guitar (Classifier: 把 m) | jí tā · noun |
| [吵架](https://en.wiktionary.org/wiki/%E5%90%B5%E6%9E%B6#Chinese) | to quarrel; to argue; to have a row | chǎo jià · verb |
| [地中海](https://en.wiktionary.org/wiki/%E5%9C%B0%E4%B8%AD%E6%B5%B7#Chinese) | crown baldness | dì zhōng hǎi · noun |
| [嫉妒](https://en.wiktionary.org/wiki/%E5%AB%89%E5%A6%92#Chinese) | to be jealous; to envy; to be envious | jí dù · verb |
| [延期](https://en.wiktionary.org/wiki/%E5%BB%B6%E6%9C%9F#Chinese) | to postpone; to defer; to delay; to extend; to put off; to prolong | yán qī · verb |
| [滴](https://en.wiktionary.org/wiki/%E6%BB%B4#Chinese) | to bounce against a surface | dī · verb |
| [祖父](https://en.wiktionary.org/wiki/%E7%A5%96%E7%88%B6#Chinese) | paternal grandfather (one's father's father) | zǔ fù · noun |
| [血管](https://en.wiktionary.org/wiki/%E8%A1%80%E7%AE%A1#Chinese) | blood vessel (Classifier: 根 m; 條／条 m c mn) | xuè guǎn · noun |
| [豆腐](https://en.wiktionary.org/wiki/%E8%B1%86%E8%85%90#Chinese) | tofu; bean curd (Classifier: 塊／块 m c; 嚿 c; 磚／砖 c) | dòu fǔ · noun |
| [词汇](https://en.wiktionary.org/wiki/%E8%AF%8D%E6%B1%87) | vocabulary | cí huì · noun |
| [下手](https://en.wiktionary.org/wiki/%E4%B8%8B%E6%89%8B#Chinese) | player whose turn comes next | xià shǒu · noun |
| [中毒](https://en.wiktionary.org/wiki/%E4%B8%AD%E6%AF%92#Chinese) | to be poisoned | zhòng dú · verb |
| [前去](https://en.wiktionary.org/wiki/%E5%89%8D%E5%8E%BB#Chinese) | to advance on; to move toward; to go to | qián qù · verb |
| [大象](https://en.wiktionary.org/wiki/%E5%A4%A7%E8%B1%A1#Chinese) | elephant (Classifier: 頭／头 m; 隻／只 m) | dà xiàng · noun |
| [打架](https://en.wiktionary.org/wiki/%E6%89%93%E6%9E%B6#Chinese) | to come to blows; to fight; to scuffle | dǎ jià · verb |
| [拼命](https://en.wiktionary.org/wiki/%E6%8B%BC%E5%91%BD#Chinese) | to risk one's life | pīn mìng · verb |
| [星座](https://en.wiktionary.org/wiki/%E6%98%9F%E5%BA%A7#Chinese) | constellation | xīng zuò · noun |
| [不宜](https://en.wiktionary.org/wiki/%E4%B8%8D%E5%AE%9C#Chinese) | not suitable; inadvisable | bù yí · adj |
| [不惜](https://en.wiktionary.org/wiki/%E4%B8%8D%E6%83%9C#Chinese) | to not care about; to not fret about; to not begrudge; to not spare | bù xī · verb |
| [信奉](https://en.wiktionary.org/wiki/%E4%BF%A1%E5%A5%89#Chinese) | to believe in; to have faith in | xìn fèng · verb |
| [升高](https://en.wiktionary.org/wiki/%E5%8D%87%E9%AB%98#Chinese) | to climb; to ascend | shēng gāo · verb |
| [反省](https://en.wiktionary.org/wiki/%E5%8F%8D%E7%9C%81#Chinese) | to reflect on one's actions; to engage in self-examination; to do some soul-searching | fǎn xǐng · verb |
| [呵呵](https://en.wiktionary.org/wiki/%E5%91%B5%E5%91%B5#Chinese) | sound of laughter | hē hē · intj |
| [大王](https://en.wiktionary.org/wiki/%E5%A4%A7%E7%8E%8B#Chinese) | king (of) | dà wáng · noun |
| [清真寺](https://en.wiktionary.org/wiki/%E6%B8%85%E7%9C%9F%E5%AF%BA#Chinese) | mosque (Classifier: 座 m c; 間／间 c) | qīng zhēn sì · noun |
| [糖尿病](https://en.wiktionary.org/wiki/%E7%B3%96%E5%B0%BF%E7%97%85#Chinese) | diabetes mellitus; diabetes | táng niào bìng · noun |
| [逃走](https://en.wiktionary.org/wiki/%E9%80%83%E8%B5%B0#Chinese) | to run away; to flee; to escape | táo zǒu · verb |
| [面子](https://en.wiktionary.org/wiki/%E9%9D%A2%E5%AD%90#Chinese) | outer part; outside; face | miàn zi · noun |
| [BB](https://en.wiktionary.org/wiki/BB#Chinese) | baby | BB · noun |
| [ED](https://en.wiktionary.org/wiki/ED#Chinese) | ending theme (end title sequence) | ED · noun |
| [can](https://en.wiktionary.org/wiki/can#Chinese) | canteen; restaurant (in a university campus) | can · noun |

</details>

<details><summary>Words 751–800</summary>

![[Resources/Audio/zh/Words 0751-0800.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [ed](https://en.wiktionary.org/wiki/ed#Chinese) | Used to denote an action which has been completed. | ed · particle |
| [捕捉](https://en.wiktionary.org/wiki/%E6%8D%95%E6%8D%89#Chinese) | to catch (an animal); to hunt | bǔ zhuō · verb |
| [水源](https://en.wiktionary.org/wiki/%E6%B0%B4%E6%BA%90#Chinese) | source of a river; headwaters; headspring; fountainhead | shuǐ yuán · noun |
| [粒子](https://en.wiktionary.org/wiki/%E7%B2%92%E5%AD%90#Chinese) | particle (Classifier: 粒; 顆／颗) | lì zi · noun |
| [行星](https://en.wiktionary.org/wiki/%E8%A1%8C%E6%98%9F#Chinese) | planet (Classifier: 顆／颗 m; 粒 c mn; 個／个 c) | xíng xīng · noun |
| [out](https://en.wiktionary.org/wiki/out#Chinese) | to be outdated | out · verb |
| [中止](https://en.wiktionary.org/wiki/%E4%B8%AD%E6%AD%A2#Chinese) | to break off; to terminate; to discontinue | zhōng zhǐ · verb |
| [妖精](https://en.wiktionary.org/wiki/%E5%A6%96%E7%B2%BE#Chinese) | monster; demon; spirit; apparition | yāo jīng · noun |
| [招待](https://en.wiktionary.org/wiki/%E6%8B%9B%E5%BE%85#Chinese) | to entertain; to host; to receive; to serve | zhāo dài · verb |
| [星期二](https://en.wiktionary.org/wiki/%E6%98%9F%E6%9C%9F%E4%BA%8C#Chinese) | Tuesday | xīng qī èr · noun |
| [百合](https://en.wiktionary.org/wiki/%E7%99%BE%E5%90%88#Chinese) | lily (flower or bulb) | bǎi hé · noun |
| [祖母](https://en.wiktionary.org/wiki/%E7%A5%96%E6%AF%8D#Chinese) | paternal grandmother | zǔ mǔ · noun |
| [翅膀](https://en.wiktionary.org/wiki/%E7%BF%85%E8%86%80#Chinese) | wing (of a bird or insect) | chì bǎng · noun |
| [老外](https://en.wiktionary.org/wiki/%E8%80%81%E5%A4%96#Chinese) | foreigner, particularly a white Westerner (Classifier: 個／个 m) | lǎo wài · noun |
| [high](https://en.wiktionary.org/wiki/high#Chinese) | high (intoxicated) | high · adj |
| [super](https://en.wiktionary.org/wiki/super#Chinese) | Used when a tied or draw situation occurs, or when one is suggesting a draw. | super · intj |
| [君子](https://en.wiktionary.org/wiki/%E5%90%9B%E5%AD%90#Chinese) | junzi; man of virtue; high-minded person; noble person; superior person | jūn zǐ · noun |
| [太平](https://en.wiktionary.org/wiki/%E5%A4%AA%E5%B9%B3#Chinese) | peaceful and tranquil | tài píng · adj |
| [左手](https://en.wiktionary.org/wiki/%E5%B7%A6%E6%89%8B#Chinese) | left hand | zuǒ shǒu · noun |
| [性交](https://en.wiktionary.org/wiki/%E6%80%A7%E4%BA%A4#Chinese) | to have sex; to have sexual intercourse | xìng jiāo · verb |
| [星期四](https://en.wiktionary.org/wiki/%E6%98%9F%E6%9C%9F%E5%9B%9B#Chinese) | Thursday | xīng qī sì · noun |
| [主人公](https://en.wiktionary.org/wiki/%E4%B8%BB%E4%BA%BA%E5%85%AC#Chinese) | protagonist (main character) | zhǔ rén gōng · noun |
| [京都](https://en.wiktionary.org/wiki/%E4%BA%AC%E9%83%BD#Chinese) | capital city (of a country) | jīng dū · noun |
| [天皇](https://en.wiktionary.org/wiki/%E5%A4%A9%E7%9A%87#Chinese) | king of heaven; heavenly sovereign; (figurative) emperor | tiān huáng · noun |
| [星期天](https://en.wiktionary.org/wiki/%E6%98%9F%E6%9C%9F%E5%A4%A9#Chinese) | Sunday | xīng qī tiān · noun |
| [老爸](https://en.wiktionary.org/wiki/%E8%80%81%E7%88%B8#Chinese) | dad; father | lǎo bà · noun |
| [葡萄酒](https://en.wiktionary.org/wiki/%E8%91%A1%E8%90%84%E9%85%92#Chinese) | wine | pú táo jiǔ · noun |
| [不容](https://en.wiktionary.org/wiki/%E4%B8%8D%E5%AE%B9#Chinese) | to not allow | bù róng · verb |
| [冰淇淋](https://en.wiktionary.org/wiki/%E5%86%B0%E6%B7%87%E6%B7%8B#Chinese) | ice cream | bīng qí lín · noun |
| [友善](https://en.wiktionary.org/wiki/%E5%8F%8B%E5%96%84#Chinese) | amiable; friendly | yǒu shàn · adj |
| [反射](https://en.wiktionary.org/wiki/%E5%8F%8D%E5%B0%84#Chinese) | to reflect | fǎn shè · verb |
| [影展](https://en.wiktionary.org/wiki/%E5%BD%B1%E5%B1%95#Chinese) | film festival | yǐng zhǎn · noun |
| [徒刑](https://en.wiktionary.org/wiki/%E5%BE%92%E5%88%91#Chinese) | imprisonment; prison sentence | tú xíng · noun |
| [破裂](https://en.wiktionary.org/wiki/%E7%A0%B4%E8%A3%82#Chinese) | to burst; to rupture; to break | pò liè · verb |
| [食堂](https://en.wiktionary.org/wiki/%E9%A3%9F%E5%A0%82#Chinese) | cafeteria; canteen; dining hall; dining room | shí táng · noun |
| [cm](https://en.wiktionary.org/wiki/cm#Chinese) | comment | cm · noun |
| [happy](https://en.wiktionary.org/wiki/happy#Chinese) | to amuse oneself | happy · verb |
| [交涉](https://en.wiktionary.org/wiki/%E4%BA%A4%E6%B6%89#Chinese) | to negotiate; to discuss how to resolve issues with another party; to make representations | jiāo shè · verb |
| [兵器](https://en.wiktionary.org/wiki/%E5%85%B5%E5%99%A8#Chinese) | weaponry; weapons; arms | bīng qì · noun |
| [宣誓](https://en.wiktionary.org/wiki/%E5%AE%A3%E8%AA%93#Chinese) | oath | xuān shì · noun |
| [接著](https://en.wiktionary.org/wiki/%E6%8E%A5%E8%91%97#Chinese) | to receive (with one's hands or a container) | jiē zhù · verb |
| [放假](https://en.wiktionary.org/wiki/%E6%94%BE%E5%81%87#Chinese) | to have time off; to go on holidays | fàng jià · verb |
| [草莓](https://en.wiktionary.org/wiki/%E8%8D%89%E8%8E%93#Chinese) | strawberry (fruit, or plant) (Classifier: 顆／颗 m) | cǎo méi · noun |
| [起身](https://en.wiktionary.org/wiki/%E8%B5%B7%E8%BA%AB#Chinese) | to set out (on a journey); to leave for; to set off; to depart; to leave (for a place) | qǐ shēn · verb |
| [雨水](https://en.wiktionary.org/wiki/%E9%9B%A8%E6%B0%B4#Chinese) | rainwater | yǔ shuǐ · noun |
| [AV](https://en.wiktionary.org/wiki/AV#Chinese) | audiovisual | AV · adj |
| [Apple](https://en.wiktionary.org/wiki/Apple#Chinese) | product of the company Apple Inc., especially iPhone (Classifier: 部 c) | Apple · noun |
| [GV](https://en.wiktionary.org/wiki/GV#Chinese) | gay porn video | GV · noun |
| [last](https://en.wiktionary.org/wiki/last#Chinese) | last (final; ultimate) | last · adj |
| [您好](https://en.wiktionary.org/wiki/%E6%82%A8%E5%A5%BD#Chinese) | hello | nín hǎo · intj |

</details>

<details><summary>Words 801–850</summary>

![[Resources/Audio/zh/Words 0801-0850.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [散步](https://en.wiktionary.org/wiki/%E6%95%A3%E6%AD%A5#Chinese) | to take a walk; to stroll | sàn bù · verb |
| [狐狸](https://en.wiktionary.org/wiki/%E7%8B%90%E7%8B%B8#Chinese) | fox (Classifier: 隻／只 m c mn) | hú lí · noun |
| [get](https://en.wiktionary.org/wiki/get#Chinese) | to understand | get · verb |
| [group](https://en.wiktionary.org/wiki/group#Chinese) | group of people or objects (Classifier: 個／个 c) | group · noun |
| [咳嗽](https://en.wiktionary.org/wiki/%E5%92%B3%E5%97%BD#Chinese) | to cough | ké sòu · verb |
| [外人](https://en.wiktionary.org/wiki/%E5%A4%96%E4%BA%BA#Chinese) | non-family member | wài rén · noun |
| [天文](https://en.wiktionary.org/wiki/%E5%A4%A9%E6%96%87#Chinese) | astronomy | tiān wén · noun |
| [奔跑](https://en.wiktionary.org/wiki/%E5%A5%94%E8%B7%91#Chinese) | to run (fast); to dash; to scamper | bēn pǎo · verb |
| [巧妙](https://en.wiktionary.org/wiki/%E5%B7%A7%E5%A6%99#Chinese) | ingenious; clever | qiǎo miào · adj |
| [帝王](https://en.wiktionary.org/wiki/%E5%B8%9D%E7%8E%8B#Chinese) | monarch; emperor | dì wáng · noun |
| [平方](https://en.wiktionary.org/wiki/%E5%B9%B3%E6%96%B9#Chinese) | square (as in square foot, square mile, square root); second power | píng fāng · noun |
| [微生物](https://en.wiktionary.org/wiki/%E5%BE%AE%E7%94%9F%E7%89%A9#Chinese) | microorganism; microbe | wēi shēng wù · noun |
| [戒指](https://en.wiktionary.org/wiki/%E6%88%92%E6%8C%87#Chinese) | finger ring; ring (Classifier: 隻／只 m c; 枚 m; 顆／颗 m) | jiè zhǐ · noun |
| [房租](https://en.wiktionary.org/wiki/%E6%88%BF%E7%A7%9F#Chinese) | rent (regular payments made to the owner of a property to secure its use) | fáng zū · noun |
| [拼音](https://en.wiktionary.org/wiki/%E6%8B%BC%E9%9F%B3#Chinese) | romanisation system; transcription system | pīn yīn · noun |
| [路面](https://en.wiktionary.org/wiki/%E8%B7%AF%E9%9D%A2#Chinese) | road surface; pavement | lù miàn · noun |
| [PS](https://en.wiktionary.org/wiki/PS#Chinese) | to photoshop | PS · verb |
| [hi](https://en.wiktionary.org/wiki/hi#Chinese) | hi (interjection) | hi · intj |
| [like](https://en.wiktionary.org/wiki/like#Chinese) | like | like · noun |
| [party](https://en.wiktionary.org/wiki/party#Chinese) | party | party · noun |
| [文盲](https://en.wiktionary.org/wiki/%E6%96%87%E7%9B%B2#Chinese) | illiterate (person unable to read) | wén máng · noun |
| [死神](https://en.wiktionary.org/wiki/%E6%AD%BB%E7%A5%9E#Chinese) | Death; Grim Reaper | sǐ shén · noun |
| [激怒](https://en.wiktionary.org/wiki/%E6%BF%80%E6%80%92#Chinese) | to anger; to enrage | jī nù · verb |
| [秋季](https://en.wiktionary.org/wiki/%E7%A7%8B%E5%AD%A3#Chinese) | autumn | qiū jì · noun |
| [西瓜](https://en.wiktionary.org/wiki/%E8%A5%BF%E7%93%9C#Chinese) | watermelon (Classifier: 個／个 m c; 隻／只 c) | xī guā · noun |
| [迷惑](https://en.wiktionary.org/wiki/%E8%BF%B7%E6%83%91#Chinese) | confused; confounded | mí huò · adj |
| [二氧化碳](https://en.wiktionary.org/wiki/%E4%BA%8C%E6%B0%A7%E5%8C%96%E7%A2%B3#Chinese) | carbon dioxide | èr yǎng huà tàn · noun |
| [容器](https://en.wiktionary.org/wiki/%E5%AE%B9%E5%99%A8#Chinese) | container; vessel; receptacle (Classifier: 個／个; 隻／只) | róng qì · noun |
| [栽培](https://en.wiktionary.org/wiki/%E6%A0%BD%E5%9F%B9#Chinese) | to cultivate (plants); to grow | zāi péi · verb |
| [水分](https://en.wiktionary.org/wiki/%E6%B0%B4%E5%88%86#Chinese) | moisture content | shuǐ fèn · noun |
| [OS](https://en.wiktionary.org/wiki/OS#Chinese) | internal monologue | OS · noun |
| [game](https://en.wiktionary.org/wiki/game#Chinese) | game (especially video games and online games) (Classifier: 隻／只 c) | game · noun |
| [part](https://en.wiktionary.org/wiki/part#Chinese) | part, portion, or component of the whole | part · noun |
| [中型](https://en.wiktionary.org/wiki/%E4%B8%AD%E5%9E%8B#Chinese) | medium-size; mid-size | zhōng xíng · adj |
| [吉利](https://en.wiktionary.org/wiki/%E5%90%89%E5%88%A9#Chinese) | auspicious; lucky; fortunate; propitious | jí lì · adj |
| [四季](https://en.wiktionary.org/wiki/%E5%9B%9B%E5%AD%A3#Chinese) | the four seasons | sì jì · noun |
| [徒弟](https://en.wiktionary.org/wiki/%E5%BE%92%E5%BC%9F#Chinese) | follower; apprentice; disciple | tú dì · noun |
| [招呼](https://en.wiktionary.org/wiki/%E6%8B%9B%E5%91%BC#Chinese) | to greet; to hail; to say hello to | zhāo hū · verb |
| [握手](https://en.wiktionary.org/wiki/%E6%8F%A1%E6%89%8B#Chinese) | to shake hands | wò shǒu · verb |
| [精液](https://en.wiktionary.org/wiki/%E7%B2%BE%E6%B6%B2#Chinese) | semen | jīng yè · noun |
| [造反](https://en.wiktionary.org/wiki/%E9%80%A0%E5%8F%8D#Chinese) | to rebel; to rise up in rebellion; to revolt | zào fǎn · verb |
| [heart](https://en.wiktionary.org/wiki/heart#Chinese) | passion; determination (Classifier: 個／个 c) | heart · noun |
| [作文](https://en.wiktionary.org/wiki/%E4%BD%9C%E6%96%87#Chinese) | essay; composition | zuò wén · noun |
| [出血](https://en.wiktionary.org/wiki/%E5%87%BA%E8%A1%80#Chinese) | to bleed; to haemorrhage | chū xiě · verb |
| [天涯](https://en.wiktionary.org/wiki/%E5%A4%A9%E6%B6%AF#Chinese) | far corners of the world; distant lands | tiān yá · noun |
| [好感](https://en.wiktionary.org/wiki/%E5%A5%BD%E6%84%9F#Chinese) | good feeling; goodwill; favor (as in, to be in favor with someone) | hǎo gǎn · noun |
| [室友](https://en.wiktionary.org/wiki/%E5%AE%A4%E5%8F%8B#Chinese) | roommate | shì yǒu · noun |
| [改正](https://en.wiktionary.org/wiki/%E6%94%B9%E6%AD%A3#Chinese) | to correct; to amend; to rectify | gǎi zhèng · verb |
| [立方](https://en.wiktionary.org/wiki/%E7%AB%8B%E6%96%B9#Chinese) | cube | lì fāng · noun |
| [保姆](https://en.wiktionary.org/wiki/%E4%BF%9D%E5%A7%86#Chinese) | nursemaid; nanny; housekeeper; babysitter | bǎo mǔ · noun |

</details>

<details><summary>Words 851–900</summary>

![[Resources/Audio/zh/Words 0851-0900.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [急救](https://en.wiktionary.org/wiki/%E6%80%A5%E6%95%91#Chinese) | to provide emergency medical treatment | modifier-verb · verb |
| [慢性](https://en.wiktionary.org/wiki/%E6%85%A2%E6%80%A7#Chinese) | chronic | màn xìng · adj |
| [星期三](https://en.wiktionary.org/wiki/%E6%98%9F%E6%9C%9F%E4%B8%89#Chinese) | Wednesday | xīng qī sān · noun |
| [次日](https://en.wiktionary.org/wiki/%E6%AC%A1%E6%97%A5#Chinese) | the next day; the following day | cì rì · noun |
| [花生](https://en.wiktionary.org/wiki/%E8%8A%B1%E7%94%9F#Chinese) | peanut (Arachis hypogaea) (Classifier: 粒 m c; 顆／颗 m) | huā shēng · noun |
| [草地](https://en.wiktionary.org/wiki/%E8%8D%89%E5%9C%B0#Chinese) | lawn; grass | cǎo dì · noun |
| [菊花](https://en.wiktionary.org/wiki/%E8%8F%8A%E8%8A%B1#Chinese) | chrysanthemum (plant or flower) | jú huā · noun |
| [AB](https://en.wiktionary.org/wiki/AB#Chinese) | two separate (instances) | AB · det |
| [京城](https://en.wiktionary.org/wiki/%E4%BA%AC%E5%9F%8E#Chinese) | capital city (of a country) | jīng chéng · noun |
| [保育](https://en.wiktionary.org/wiki/%E4%BF%9D%E8%82%B2#Chinese) | to provide childcare | bǎo yù · verb |
| [信封](https://en.wiktionary.org/wiki/%E4%BF%A1%E5%B0%81#Chinese) | envelope (Classifier: 個／个 m c) | xìn fēng · noun |
| [天亮](https://en.wiktionary.org/wiki/%E5%A4%A9%E4%BA%AE#Chinese) | to break (of dawn) | tiān liàng · verb |
| [妄想](https://en.wiktionary.org/wiki/%E5%A6%84%E6%83%B3#Chinese) | to vainly hope to (do something); to attempt in vain | wàng xiǎng · verb |
| [平和](https://en.wiktionary.org/wiki/%E5%B9%B3%E5%92%8C#Chinese) | having a mild temperament; polite | píng hé · adj |
| [慈悲](https://en.wiktionary.org/wiki/%E6%85%88%E6%82%B2#Chinese) | merciful; benevolent; pitying | cí bēi · adj |
| [明智](https://en.wiktionary.org/wiki/%E6%98%8E%E6%99%BA#Chinese) | wise; smart; sensible | míng zhì · adj |
| [某某](https://en.wiktionary.org/wiki/%E6%9F%90%E6%9F%90#Chinese) | someone; so-and-so | mǒu mǒu · noun |
| [航海](https://en.wiktionary.org/wiki/%E8%88%AA%E6%B5%B7#Chinese) | to sail the seas; to navigate; to take a voyage by sea | háng hǎi · verb |
| [配偶](https://en.wiktionary.org/wiki/%E9%85%8D%E5%81%B6#Chinese) | spouse; partner | pèi ǒu · noun |
| [重力](https://en.wiktionary.org/wiki/%E9%87%8D%E5%8A%9B#Chinese) | earth's gravity | zhòng lì · noun |
| [data](https://en.wiktionary.org/wiki/data#Chinese) | data (information) | data · noun |
| [四方](https://en.wiktionary.org/wiki/%E5%9B%9B%E6%96%B9#Chinese) | the four directions (north, south, east and west) | sì fāng · noun |
| [小妹](https://en.wiktionary.org/wiki/%E5%B0%8F%E5%A6%B9#Chinese) | youngest sister | xiǎo mèi · noun |
| [海豚](https://en.wiktionary.org/wiki/%E6%B5%B7%E8%B1%9A#Chinese) | dolphin | hǎi tún · noun |
| [生平](https://en.wiktionary.org/wiki/%E7%94%9F%E5%B9%B3#Chinese) | lifetime; all one's life; one's whole life | shēng píng · noun |
| [索引](https://en.wiktionary.org/wiki/%E7%B4%A2%E5%BC%95#Chinese) | index | suǒ yǐn · noun |
| [Richard](https://en.wiktionary.org/wiki/Richard#Chinese) | synonym of 碌柒 | Richard · noun |
| [van](https://en.wiktionary.org/wiki/van#Chinese) | van; minibus; vehicle (Classifier: 架 c) | van · noun |
| [人情](https://en.wiktionary.org/wiki/%E4%BA%BA%E6%83%85#Chinese) | human sentiment; natural human feelings; inherent goodness of human nature | rén qíng · noun |
| [偏差](https://en.wiktionary.org/wiki/%E5%81%8F%E5%B7%AE#Chinese) | deviation | piān chā · noun |
| [只得](https://en.wiktionary.org/wiki/%E5%8F%AA%E5%BE%97#Chinese) | have to; can only; have no choice but to; be forced to | zhǐ dé · adv |
| [大豆](https://en.wiktionary.org/wiki/%E5%A4%A7%E8%B1%86#Chinese) | soybean (Glycine max) | dà dòu · noun |
| [精子](https://en.wiktionary.org/wiki/%E7%B2%BE%E5%AD%90#Chinese) | sperm cell; spermatozoon | jīng zi · noun |
| [美人](https://en.wiktionary.org/wiki/%E7%BE%8E%E4%BA%BA#Chinese) | beautiful woman; beauty; lovely lady | měi rén · noun |
| [蝙蝠](https://en.wiktionary.org/wiki/%E8%9D%99%E8%9D%A0#Chinese) | bat (small flying mammal of order Chiroptera) (Classifier: 隻／只 m c mn) | biān fú · noun |
| [跑步](https://en.wiktionary.org/wiki/%E8%B7%91%E6%AD%A5#Chinese) | to run; to jog | pǎo bù · verb |
| [不定](https://en.wiktionary.org/wiki/%E4%B8%8D%E5%AE%9A#Chinese) | uncertain | bù dìng · adj |
| [何不](https://en.wiktionary.org/wiki/%E4%BD%95%E4%B8%8D#Chinese) | why not | hé bù · adv |
| [水稻](https://en.wiktionary.org/wiki/%E6%B0%B4%E7%A8%BB#Chinese) | rice (planted in a water-logged paddy) | shuǐ dào · noun |
| [鼓掌](https://en.wiktionary.org/wiki/%E9%BC%93%E6%8E%8C#Chinese) | to applaud; to clap; to put one's hands together | gǔ zhǎng · verb |
| [list](https://en.wiktionary.org/wiki/list#Chinese) | list; enumeration or compilation of items; the paper or document of which the list is written or printed on (Classifier: 個／个 c; 張／张 c; 條／条 c) | list · noun |
| [talk](https://en.wiktionary.org/wiki/talk#Chinese) | talk; lecture; seminar | talk · noun |
| [危急](https://en.wiktionary.org/wiki/%E5%8D%B1%E6%80%A5#Chinese) | critical; desperate | wēi jí · adj |
| [大阪](https://en.wiktionary.org/wiki/%E5%A4%A7%E9%98%AA#Chinese) | great hill; great mountain; great slope | dà bǎn · noun |
| [小弟](https://en.wiktionary.org/wiki/%E5%B0%8F%E5%BC%9F#Chinese) | little brother; younger brother | xiǎo dì · noun |
| [新世界](https://en.wiktionary.org/wiki/%E6%96%B0%E4%B8%96%E7%95%8C#Chinese) | new world | xīn shì jiè · noun |
| [杯子](https://en.wiktionary.org/wiki/%E6%9D%AF%E5%AD%90#Chinese) | drinkware; cup; glass (Classifier: 個／个 m; 隻／只 m) | bēi zi · noun |
| [水位](https://en.wiktionary.org/wiki/%E6%B0%B4%E4%BD%8D#Chinese) | water level | shuǐ wèi · noun |
| [瑜伽](https://en.wiktionary.org/wiki/%E7%91%9C%E4%BC%BD#Chinese) | yoga (physical, mental, and spiritual practice or discipline) | yú jiā · noun |
| [留守](https://en.wiktionary.org/wiki/%E7%95%99%E5%AE%88#Chinese) | to stay behind; to remain for military duty while the main forces depart | liú shǒu · verb |

</details>

<details><summary>Words 901–950</summary>

![[Resources/Audio/zh/Words 0901-0950.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [off](https://en.wiktionary.org/wiki/off#Chinese) | to have day off | off · verb |
| [over](https://en.wiktionary.org/wiki/over#Chinese) | over the top; extreme; overdone | over · adj |
| [傻瓜](https://en.wiktionary.org/wiki/%E5%82%BB%E7%93%9C#Chinese) | silly person; fool; idiot (Classifier: 個／个 m) | shǎ guā · noun |
| [僧人](https://en.wiktionary.org/wiki/%E5%83%A7%E4%BA%BA#Chinese) | bhikkhu; Buddhist monk | sēng rén · noun |
| [大帝](https://en.wiktionary.org/wiki/%E5%A4%A7%E5%B8%9D#Chinese) | a title of some Taoist deities | dà dì · noun |
| [打球](https://en.wiktionary.org/wiki/%E6%89%93%E7%90%83#Chinese) | to play a ball game | dǎ qiú · verb |
| [早晚](https://en.wiktionary.org/wiki/%E6%97%A9%E6%99%9A#Chinese) | morning and evening | zǎo wǎn · noun |
| [民心](https://en.wiktionary.org/wiki/%E6%B0%91%E5%BF%83#Chinese) | the will of the people; popular sentiment | mín xīn · noun |
| [生殖器](https://en.wiktionary.org/wiki/%E7%94%9F%E6%AE%96%E5%99%A8#Chinese) | sex organ; genitals | shēng zhí qì · noun |
| [登山](https://en.wiktionary.org/wiki/%E7%99%BB%E5%B1%B1#Chinese) | to climb a mountain | dēng shān · verb |
| [神器](https://en.wiktionary.org/wiki/%E7%A5%9E%E5%99%A8#Chinese) | magic weapon; amazing tool; best device | shén qì · noun |
| [call](https://en.wiktionary.org/wiki/call#Chinese) | radio call; phone call (Classifier: 個／个 c) | call · noun |
| [供奉](https://en.wiktionary.org/wiki/%E4%BE%9B%E5%A5%89#Chinese) | to enshrine and worship; to consecrate | gòng fèng · verb |
| [激素](https://en.wiktionary.org/wiki/%E6%BF%80%E7%B4%A0#Chinese) | hormone | jī sù · noun |
| [阿拉伯人](https://en.wiktionary.org/wiki/%E9%98%BF%E6%8B%89%E4%BC%AF%E4%BA%BA#Chinese) | person of Arab origin; Arab | ā lā bó rén · noun |
| [boss](https://en.wiktionary.org/wiki/boss#Chinese) | boss | boss · noun |
| [con](https://en.wiktionary.org/wiki/con#Chinese) | contact lens (Classifier: 隻／只 c; 粒 c; 副 c) | con · noun |
| [down](https://en.wiktionary.org/wiki/down#Chinese) | sad; depressed | down · adj |
| [un](https://en.wiktionary.org/wiki/un#Chinese) | to understand | un · verb |
| [大笑](https://en.wiktionary.org/wiki/%E5%A4%A7%E7%AC%91#Chinese) | to laugh uproariously; to burst out laughing | dà xiào · verb |
| [攻打](https://en.wiktionary.org/wiki/%E6%94%BB%E6%89%93#Chinese) | to attack (an enemy); to mount an offensive | gōng dǎ · verb |
| [歌舞](https://en.wiktionary.org/wiki/%E6%AD%8C%E8%88%9E#Chinese) | to sing and dance | gē wǔ · verb |
| [牛仔](https://en.wiktionary.org/wiki/%E7%89%9B%E4%BB%94#Chinese) | cowboy (Classifier: 個／个 m c) | niú zǎi · noun |
| [部下](https://en.wiktionary.org/wiki/%E9%83%A8%E4%B8%8B#Chinese) | troops under one's command | bù xià · noun |
| [骨折](https://en.wiktionary.org/wiki/%E9%AA%A8%E6%8A%98#Chinese) | to break a bone; to fracture | gǔ zhé · verb |
| [ex](https://en.wiktionary.org/wiki/ex#Chinese) | ex (former partner) | ex · noun |
| [太后](https://en.wiktionary.org/wiki/%E5%A4%AA%E5%90%8E#Chinese) | empress dowager | tài hòu · noun |
| [姓氏](https://en.wiktionary.org/wiki/%E5%A7%93%E6%B0%8F#Chinese) | family name; surname | xìng shì · noun |
| [月刊](https://en.wiktionary.org/wiki/%E6%9C%88%E5%88%8A#Chinese) | monthly publication | yuè kān · noun |
| [一心](https://en.wiktionary.org/wiki/%E4%B8%80%E5%BF%83#Chinese) | heart and soul; wholeheartedly | yī xīn · adv |
| [作曲家](https://en.wiktionary.org/wiki/%E4%BD%9C%E6%9B%B2%E5%AE%B6#Chinese) | composer | zuò qǔ jiā · noun |
| [出示](https://en.wiktionary.org/wiki/%E5%87%BA%E7%A4%BA#Chinese) | to show (a passport, identity card, etc.) to someone; to let someone see; to present | chū shì · verb |
| [地名](https://en.wiktionary.org/wiki/%E5%9C%B0%E5%90%8D#Chinese) | placename; toponym | dì míng · noun |
| [大便](https://en.wiktionary.org/wiki/%E5%A4%A7%E4%BE%BF#Chinese) | to defecate; to empty one's bowels | dà biàn · verb |
| [字典](https://en.wiktionary.org/wiki/%E5%AD%97%E5%85%B8#Chinese) | dictionary of Chinese characters; Han character dictionary (Classifier: 本; 部) | zì diǎn · noun |
| [火花](https://en.wiktionary.org/wiki/%E7%81%AB%E8%8A%B1#Chinese) | spark | huǒ huā · noun |
| [眼球](https://en.wiktionary.org/wiki/%E7%9C%BC%E7%90%83#Chinese) | eyeball | yǎn qiú · noun |
| [蜂蜜](https://en.wiktionary.org/wiki/%E8%9C%82%E8%9C%9C#Chinese) | honey (sweet fluid produced from plant nectar by bees) | fēng mì · noun |
| [金星](https://en.wiktionary.org/wiki/%E9%87%91%E6%98%9F#Chinese) | golden star | jīn xīng · noun |
| [JJ](https://en.wiktionary.org/wiki/JJ#Chinese) | person; people | JJ · noun |
| [under](https://en.wiktionary.org/wiki/under#Chinese) | underwear (Classifier: 條／条 c) | under · noun |
| [哎呀](https://en.wiktionary.org/wiki/%E5%93%8E%E5%91%80#Chinese) | aiya; aiyo; alas; ah; oh; ugh; ouch (expressing surprise, annoyance, pain, frustration, sarcasm, etc.) | āi yā · intj |
| [大洋](https://en.wiktionary.org/wiki/%E5%A4%A7%E6%B4%8B#Chinese) | ocean; sea (as a whole) | dà yáng · noun |
| [字符](https://en.wiktionary.org/wiki/%E5%AD%97%E7%AC%A6#Chinese) | character | zì fú · noun |
| [心得](https://en.wiktionary.org/wiki/%E5%BF%83%E5%BE%97#Chinese) | what one has learnt from study, work or experience; knowledge gained | xīn dé · noun |
| [感慨](https://en.wiktionary.org/wiki/%E6%84%9F%E6%85%A8#Chinese) | to have a stirring of emotion and sigh with regret | gǎn kǎi · verb |
| [橘子](https://en.wiktionary.org/wiki/%E6%A9%98%E5%AD%90#Chinese) | mandarin orange (Classifier: 個／个; 瓣) | jú zi · noun |
| [神像](https://en.wiktionary.org/wiki/%E7%A5%9E%E5%83%8F#Chinese) | statue | shén xiàng · noun |
| [Mary](https://en.wiktionary.org/wiki/Mary#Chinese) | sex doll; love doll (Classifier: 隻／只 c) | Mary · noun |
| [PK](https://en.wiktionary.org/wiki/PK#Chinese) | player killing (player-versus-player conflict in MMORPGs and MUDs) | PK · noun |

</details>

<details><summary>Words 951–1000</summary>

![[Resources/Audio/zh/Words 0951-1000.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [TA](https://en.wiktionary.org/wiki/TA#Chinese) | An alternative spelling of the third-person pronoun 他 (tā)/她 (tā) that is explicitly gender-neutral: they; them | TA · pron |
| [告白](https://en.wiktionary.org/wiki/%E5%91%8A%E7%99%BD#Chinese) | to confess | gào bái · verb |
| [大名](https://en.wiktionary.org/wiki/%E5%A4%A7%E5%90%8D#Chinese) | formal name of a person (as opposed to a nickname) | dà míng · noun |
| [日程](https://en.wiktionary.org/wiki/%E6%97%A5%E7%A8%8B#Chinese) | daily schedule; agenda | rì chéng · noun |
| [民法](https://en.wiktionary.org/wiki/%E6%B0%91%E6%B3%95#Chinese) | civil law (the body of law dealing with the private relations between members of a community) | mín fǎ · noun |
| [痛快](https://en.wiktionary.org/wiki/%E7%97%9B%E5%BF%AB#Chinese) | joyful | tòng kuài · adj |
| [痛恨](https://en.wiktionary.org/wiki/%E7%97%9B%E6%81%A8#Chinese) | utter hatred; abhorrence | tòng hèn · noun |
| [立委](https://en.wiktionary.org/wiki/%E7%AB%8B%E5%A7%94#Chinese) | legislator | lì wěi · noun |
| [美德](https://en.wiktionary.org/wiki/%E7%BE%8E%E5%BE%B7#Chinese) | virtue (behaviour of a high moral standard); noble attribute | měi dé · noun |
| [logo](https://en.wiktionary.org/wiki/logo#Chinese) | logo | logo · noun |
| [moon](https://en.wiktionary.org/wiki/moon#Chinese) | synonym of mon (Classifier: 隻／只 c) | moon · noun |
| [不能不](https://en.wiktionary.org/wiki/%E4%B8%8D%E8%83%BD%E4%B8%8D#Chinese) | to have to; cannot but | bù néng bù · verb |
| [修道院](https://en.wiktionary.org/wiki/%E4%BF%AE%E9%81%93%E9%99%A2#Chinese) | convent; monastery | xiū dào yuàn · noun |
| [屁眼](https://en.wiktionary.org/wiki/%E5%B1%81%E7%9C%BC#Chinese) | anus; butthole; asshole | pì yǎn · noun |
| [早上好](https://en.wiktionary.org/wiki/%E6%97%A9%E4%B8%8A%E5%A5%BD#Chinese) | good morning | zǎo shàng hǎo · intj |
| [植被](https://en.wiktionary.org/wiki/%E6%A4%8D%E8%A2%AB#Chinese) | vegetation; plants; greenery | zhí bèi · noun |
| [正值](https://en.wiktionary.org/wiki/%E6%AD%A3%E5%80%BC#Chinese) | just happen (e.g. just happen to be a Sunday); just at the time of | zhèng zhí · adv |
| [赤道](https://en.wiktionary.org/wiki/%E8%B5%A4%E9%81%93#Chinese) | celestial equator | chì dào · noun |
| [赦免](https://en.wiktionary.org/wiki/%E8%B5%A6%E5%85%8D#Chinese) | to grant a pardon; to pardon | shè miǎn · verb |
| [重任](https://en.wiktionary.org/wiki/%E9%87%8D%E4%BB%BB#Chinese) | important task; heavy responsibility | zhòng rèn · noun |
| [bug](https://en.wiktionary.org/wiki/bug#Chinese) | bug of programme (Classifier: 個／个 c; 隻／只 c) | bug · noun |
| [point](https://en.wiktionary.org/wiki/point#Chinese) | point (of an argument); main idea; argument | point · noun |
| [上岸](https://en.wiktionary.org/wiki/%E4%B8%8A%E5%B2%B8#Chinese) | to go ashore; to climb ashore | shàng àn · verb |
| [作曲](https://en.wiktionary.org/wiki/%E4%BD%9C%E6%9B%B2#Chinese) | to compose; to write music | zuò qǔ · verb |
| [元旦](https://en.wiktionary.org/wiki/%E5%85%83%E6%97%A6#Chinese) | the first day of a year | yuán dàn · noun |
| [古今](https://en.wiktionary.org/wiki/%E5%8F%A4%E4%BB%8A#Chinese) | ancient and modern; past and present; then and now | gǔ jīn · noun |
| [山村](https://en.wiktionary.org/wiki/%E5%B1%B1%E6%9D%91#Chinese) | mountain village | shān cūn · noun |
| [棘手](https://en.wiktionary.org/wiki/%E6%A3%98%E6%89%8B#Chinese) | thorny | jí shǒu · adj |
| [水深](https://en.wiktionary.org/wiki/%E6%B0%B4%E6%B7%B1#Chinese) | depth of water; depth (of a water body) | shuǐ shēn · noun |
| [畜生](https://en.wiktionary.org/wiki/%E7%95%9C%E7%94%9F#Chinese) | domestic animal; livestock; brute | chù sheng · noun |
| [看病](https://en.wiktionary.org/wiki/%E7%9C%8B%E7%97%85#Chinese) | to see a patient; to treat an illness | kàn bìng · verb |
| [莫名其妙](https://en.wiktionary.org/wiki/%E8%8E%AB%E5%90%8D%E5%85%B6%E5%A6%99#Chinese) | puzzling; baffling; inexplicable | mò míng qí miào · phrase |
| [陷害](https://en.wiktionary.org/wiki/%E9%99%B7%E5%AE%B3#Chinese) | to frame; to entrap; to set up; to bring up someone on false charges | xiàn hài · verb |
| [feel](https://en.wiktionary.org/wiki/feel#Chinese) | emotional attraction or desire | feel · noun |
| [全然](https://en.wiktionary.org/wiki/%E5%85%A8%E7%84%B6#Chinese) | completely, entirely, utterly | quán rán · adv |
| [揪](https://en.wiktionary.org/wiki/%E6%8F%AA#Chinese) | to gather; to arrange a gathering | jiū · verb |
| [有幸](https://en.wiktionary.org/wiki/%E6%9C%89%E5%B9%B8#Chinese) | lucky; fortunate; having the honour (of doing something) | yǒu xìng · adj |
| [次要](https://en.wiktionary.org/wiki/%E6%AC%A1%E8%A6%81#Chinese) | secondary; of lesser importance | cì yào · adj |
| [沉浸](https://en.wiktionary.org/wiki/%E6%B2%89%E6%B5%B8#Chinese) | to immerse; to submerge; to dip in water | chén jìn · verb |
| [翻身](https://en.wiktionary.org/wiki/%E7%BF%BB%E8%BA%AB#Chinese) | to turn over; to double over | fān shēn · verb |
| [花瓣](https://en.wiktionary.org/wiki/%E8%8A%B1%E7%93%A3#Chinese) | petal (Classifier: 片 m) | huā bàn · noun |
| [跳出](https://en.wiktionary.org/wiki/%E8%B7%B3%E5%87%BA#Chinese) | to jump out of; to free oneself from; to quit | verb-complement · verb |
| [case](https://en.wiktionary.org/wiki/case#Chinese) | case (container; box) (Classifier: 個／个 c) | case · noun |
| [work](https://en.wiktionary.org/wiki/work#Chinese) | working as intended; functioning | work · adj |
| [感想](https://en.wiktionary.org/wiki/%E6%84%9F%E6%83%B3#Chinese) | thoughts; impressions; reflections | gǎn xiǎng · noun |
| [本子](https://en.wiktionary.org/wiki/%E6%9C%AC%E5%AD%90#Chinese) | book | běn zi · noun |
| [段落](https://en.wiktionary.org/wiki/%E6%AE%B5%E8%90%BD#Chinese) | paragraph | duàn luò · noun |
| [白白](https://en.wiktionary.org/wiki/%E7%99%BD%E7%99%BD#Chinese) | in vain; to no purpose; for nothing; unsuccessfully | bái bái · adv |
| [白金](https://en.wiktionary.org/wiki/%E7%99%BD%E9%87%91#Chinese) | platinum (metal) | bái jīn · noun |
| [竭力](https://en.wiktionary.org/wiki/%E7%AB%AD%E5%8A%9B#Chinese) | to strive; to try one's hardest; to do one's utmost | jié lì · verb |

</details>

## Question bank

Try before opening the answers. Different tasks use the same sentence to practise complementary skills. Open translation and explanation tasks can have valid alternatives.

### Personal pronouns · 50 questions

**zh-Q0001 · Fill the gap**

____们不会找到汤姆。

They won't find Tom.

[[Mandarin Chinese#^zh-Q0001-answer|Compare the answer]]
^zh-Q0001

**zh-Q0002 · Choose the form**

____们不会找到汤姆。

They won't find Tom.

Choices: 你 / 他 / 我 / 她

[[Mandarin Chinese#^zh-Q0002-answer|Compare the answer]]
^zh-Q0002

**zh-Q0003 · Edit the changed sentence**

来吧，【你】们一起去。

Come on, let's go.

[[Mandarin Chinese#^zh-Q0003-answer|Compare the answer]]
^zh-Q0003

**zh-Q0004 · Build the sentence**

Arrange: 我 / 们一起去。 / 来吧，

Come on, let's go.

[[Mandarin Chinese#^zh-Q0004-answer|Compare the answer]]
^zh-Q0004

**zh-Q0005 · Write a translation**

Write this in Mandarin Chinese: If you prick us, do we not bleed?

[[Mandarin Chinese#^zh-Q0005-answer|Compare the answer]]
^zh-Q0005

**zh-Q0006 · Explain the grammar**

【你】們要是用刀劍刺我們，我們不是也會出血嗎？

If you prick us, do we not bleed?

[[Mandarin Chinese#^zh-Q0006-answer|Compare the answer]]
^zh-Q0006

**zh-Q0007 · Fill the gap**

____吹次中音薩克斯風。

I play the tenor saxophone.

[[Mandarin Chinese#^zh-Q0007-answer|Compare the answer]]
^zh-Q0007

**zh-Q0008 · Choose the form**

____吹次中音薩克斯風。

I play the tenor saxophone.

Choices: 她 / 我 / 他 / 你

[[Mandarin Chinese#^zh-Q0008-answer|Compare the answer]]
^zh-Q0008

**zh-Q0009 · Edit the changed sentence**

【我】已經成為了棒球隊員。

He has made the baseball team.

[[Mandarin Chinese#^zh-Q0009-answer|Compare the answer]]
^zh-Q0009

**zh-Q0010 · Build the sentence**

Arrange: 已經成為了棒球隊員。 / 他

He has made the baseball team.

[[Mandarin Chinese#^zh-Q0010-answer|Compare the answer]]
^zh-Q0010

**zh-Q0011 · Write a translation**

Write this in Mandarin Chinese: Why did you show me this?

[[Mandarin Chinese#^zh-Q0011-answer|Compare the answer]]
^zh-Q0011

**zh-Q0012 · Explain the grammar**

【你】为什么让我看这个？

Why did you show me this?

[[Mandarin Chinese#^zh-Q0012-answer|Compare the answer]]
^zh-Q0012

**zh-Q0013 · Fill the gap**

幫____看著我的相機。

Watch my camera for me.

[[Mandarin Chinese#^zh-Q0013-answer|Compare the answer]]
^zh-Q0013

**zh-Q0014 · Choose the form**

幫____看著我的相機。

Watch my camera for me.

Choices: 她 / 他 / 你 / 我

[[Mandarin Chinese#^zh-Q0014-answer|Compare the answer]]
^zh-Q0014

**zh-Q0015 · Edit the changed sentence**

【你】以前在這條河裡游泳。

I used to swim in this river.

[[Mandarin Chinese#^zh-Q0015-answer|Compare the answer]]
^zh-Q0015

**zh-Q0016 · Build the sentence**

Arrange: 以前在這條河裡游泳。 / 我

I used to swim in this river.

[[Mandarin Chinese#^zh-Q0016-answer|Compare the answer]]
^zh-Q0016

**zh-Q0017 · Write a translation**

Write this in Mandarin Chinese: Jane is no less beautiful than her mother.

[[Mandarin Chinese#^zh-Q0017-answer|Compare the answer]]
^zh-Q0017

**zh-Q0018 · Explain the grammar**

简的美丽丝毫不逊色于【她】母亲。

Jane is no less beautiful than her mother.

[[Mandarin Chinese#^zh-Q0018-answer|Compare the answer]]
^zh-Q0018

**zh-Q0019 · Fill the gap**

____們該吃午飯了吧？

Should we have some lunch?

[[Mandarin Chinese#^zh-Q0019-answer|Compare the answer]]
^zh-Q0019

**zh-Q0020 · Choose the form**

____們該吃午飯了吧？

Should we have some lunch?

Choices: 我 / 你 / 他 / 她

[[Mandarin Chinese#^zh-Q0020-answer|Compare the answer]]
^zh-Q0020

**zh-Q0021 · Edit the changed sentence**

【我】明天的行程安排是什麼？

What's your schedule for tomorrow?

[[Mandarin Chinese#^zh-Q0021-answer|Compare the answer]]
^zh-Q0021

**zh-Q0022 · Build the sentence**

Arrange: 明天的行程安排是什麼？ / 你

What's your schedule for tomorrow?

[[Mandarin Chinese#^zh-Q0022-answer|Compare the answer]]
^zh-Q0022

**zh-Q0023 · Write a translation**

Write this in Mandarin Chinese: The movie was interesting, as I had expected.

[[Mandarin Chinese#^zh-Q0023-answer|Compare the answer]]
^zh-Q0023

**zh-Q0024 · Explain the grammar**

不出【我】所料，那部電影相當有趣。

The movie was interesting, as I had expected.

[[Mandarin Chinese#^zh-Q0024-answer|Compare the answer]]
^zh-Q0024

**zh-Q0025 · Fill the gap**

____不喜欢这个操作系统的页面。

I didn't like the interface of that operating system.

[[Mandarin Chinese#^zh-Q0025-answer|Compare the answer]]
^zh-Q0025

**zh-Q0026 · Choose the form**

____不喜欢这个操作系统的页面。

I didn't like the interface of that operating system.

Choices: 我 / 他 / 你 / 她

[[Mandarin Chinese#^zh-Q0026-answer|Compare the answer]]
^zh-Q0026

**zh-Q0027 · Edit the changed sentence**

【我】到意大利學習意大利語。

She went to Italy to learn Italian.

[[Mandarin Chinese#^zh-Q0027-answer|Compare the answer]]
^zh-Q0027

**zh-Q0028 · Build the sentence**

Arrange: 到意大利學習意大利語。 / 她

She went to Italy to learn Italian.

[[Mandarin Chinese#^zh-Q0028-answer|Compare the answer]]
^zh-Q0028

**zh-Q0029 · Write a translation**

Write this in Mandarin Chinese: Do you have difficulty understanding what women or small children say to you?

[[Mandarin Chinese#^zh-Q0029-answer|Compare the answer]]
^zh-Q0029

**zh-Q0030 · Explain the grammar**

【你】难以理解女人和小孩子对你说的话吗？

Do you have difficulty understanding what women or small children say to you?

[[Mandarin Chinese#^zh-Q0030-answer|Compare the answer]]
^zh-Q0030

**zh-Q0031 · Fill the gap**

____的英語進步了很多。

Your English has improved a lot.

[[Mandarin Chinese#^zh-Q0031-answer|Compare the answer]]
^zh-Q0031

**zh-Q0032 · Choose the form**

____的英語進步了很多。

Your English has improved a lot.

Choices: 她 / 他 / 你 / 我

[[Mandarin Chinese#^zh-Q0032-answer|Compare the answer]]
^zh-Q0032

**zh-Q0033 · Edit the changed sentence**

如果【你】了解這件事, 我就會告訴你。

If I could understand it, I would tell you so.

[[Mandarin Chinese#^zh-Q0033-answer|Compare the answer]]
^zh-Q0033

**zh-Q0034 · Build the sentence**

Arrange: 了解這件事, 我就會告訴你。 / 如果 / 我

If I could understand it, I would tell you so.

[[Mandarin Chinese#^zh-Q0034-answer|Compare the answer]]
^zh-Q0034

**zh-Q0035 · Write a translation**

Write this in Mandarin Chinese: We're amazed by the rapid growth in import quantities.

[[Mandarin Chinese#^zh-Q0035-answer|Compare the answer]]
^zh-Q0035

**zh-Q0036 · Explain the grammar**

进口数量的急速增长让【我】们感到惊讶。

We're amazed by the rapid growth in import quantities.

[[Mandarin Chinese#^zh-Q0036-answer|Compare the answer]]
^zh-Q0036

**zh-Q0037 · Fill the gap**

____父亲可能会乘下一列火车来。

My father will possibly come on the next train.

[[Mandarin Chinese#^zh-Q0037-answer|Compare the answer]]
^zh-Q0037

**zh-Q0038 · Choose the form**

____父亲可能会乘下一列火车来。

My father will possibly come on the next train.

Choices: 他 / 她 / 我 / 你

[[Mandarin Chinese#^zh-Q0038-answer|Compare the answer]]
^zh-Q0038

**zh-Q0039 · Edit the changed sentence**

【你】要你把窗戶打開。

I want you to open the window.

[[Mandarin Chinese#^zh-Q0039-answer|Compare the answer]]
^zh-Q0039

**zh-Q0040 · Build the sentence**

Arrange: 要你把窗戶打開。 / 我

I want you to open the window.

[[Mandarin Chinese#^zh-Q0040-answer|Compare the answer]]
^zh-Q0040

**zh-Q0041 · Write a translation**

Write this in Mandarin Chinese: We can find similar situations in these next few cases.

[[Mandarin Chinese#^zh-Q0041-answer|Compare the answer]]
^zh-Q0041

**zh-Q0042 · Explain the grammar**

同樣的情況【我】們還能在下面這幾個例子中找到。

We can find similar situations in these next few cases.

[[Mandarin Chinese#^zh-Q0042-answer|Compare the answer]]
^zh-Q0042

**zh-Q0043 · Fill the gap**

____说的东西是胡扯。

What you said is baloney.

[[Mandarin Chinese#^zh-Q0043-answer|Compare the answer]]
^zh-Q0043

**zh-Q0044 · Choose the form**

____说的东西是胡扯。

What you said is baloney.

Choices: 你 / 他 / 她 / 我

[[Mandarin Chinese#^zh-Q0044-answer|Compare the answer]]
^zh-Q0044

**zh-Q0045 · Edit the changed sentence**

【我】的文法比你的呼吸好。

Your grammar is better than your breath.

[[Mandarin Chinese#^zh-Q0045-answer|Compare the answer]]
^zh-Q0045

**zh-Q0046 · Build the sentence**

Arrange: 的文法比你的呼吸好。 / 你

Your grammar is better than your breath.

[[Mandarin Chinese#^zh-Q0046-answer|Compare the answer]]
^zh-Q0046

**zh-Q0047 · Write a translation**

Write this in Mandarin Chinese: I can answer your question.

[[Mandarin Chinese#^zh-Q0047-answer|Compare the answer]]
^zh-Q0047

**zh-Q0048 · Explain the grammar**

【我】能回答您的问题。

I can answer your question.

[[Mandarin Chinese#^zh-Q0048-answer|Compare the answer]]
^zh-Q0048

**zh-Q0049 · Fill the gap**

____對這個計劃表示了興趣。

He showed interest in the plan.

[[Mandarin Chinese#^zh-Q0049-answer|Compare the answer]]
^zh-Q0049

**zh-Q0050 · Choose the form**

____對這個計劃表示了興趣。

He showed interest in the plan.

Choices: 我 / 他 / 你 / 她

[[Mandarin Chinese#^zh-Q0050-answer|Compare the answer]]
^zh-Q0050


### Identity with 是 · 50 questions

**zh-Q0051 · Edit the changed sentence**

莎士比亞【有】一位作家的名字。

Shakespeare is the name of a writer.

[[Mandarin Chinese#^zh-Q0051-answer|Compare the answer]]
^zh-Q0051

**zh-Q0052 · Build the sentence**

Arrange: 是 / 莎士比亞 / 一位作家的名字。

Shakespeare is the name of a writer.

[[Mandarin Chinese#^zh-Q0052-answer|Compare the answer]]
^zh-Q0052

**zh-Q0053 · Write a translation**

Write this in Mandarin Chinese: Which is heavier, lead or gold?

[[Mandarin Chinese#^zh-Q0053-answer|Compare the answer]]
^zh-Q0053

**zh-Q0054 · Explain the grammar**

哪個比較重，鉛還【是】黃金？

Which is heavier, lead or gold?

[[Mandarin Chinese#^zh-Q0054-answer|Compare the answer]]
^zh-Q0054

**zh-Q0055 · Fill the gap**

勇气____一个奇怪的东西：没有任何人对它有把握

Courage is a strange thing: One can never be sure of it.

[[Mandarin Chinese#^zh-Q0055-answer|Compare the answer]]
^zh-Q0055

**zh-Q0056 · Choose the form**

勇气____一个奇怪的东西：没有任何人对它有把握

Courage is a strange thing: One can never be sure of it.

Choices: 是 / 有 / 在

[[Mandarin Chinese#^zh-Q0056-answer|Compare the answer]]
^zh-Q0056

**zh-Q0057 · Edit the changed sentence**

這【有】湯姆叔叔的農場。

This is Uncle Tom's farm.

[[Mandarin Chinese#^zh-Q0057-answer|Compare the answer]]
^zh-Q0057

**zh-Q0058 · Build the sentence**

Arrange: 是 / 湯姆叔叔的農場。 / 這

This is Uncle Tom's farm.

[[Mandarin Chinese#^zh-Q0058-answer|Compare the answer]]
^zh-Q0058

**zh-Q0059 · Write a translation**

Write this in Mandarin Chinese: That was an evil bunny.

[[Mandarin Chinese#^zh-Q0059-answer|Compare the answer]]
^zh-Q0059

**zh-Q0060 · Explain the grammar**

那【是】一隻有惡意的兔子。

That was an evil bunny.

[[Mandarin Chinese#^zh-Q0060-answer|Compare the answer]]
^zh-Q0060

**zh-Q0061 · Fill the gap**

這____無可否認的事實。

There is no denying the fact.

[[Mandarin Chinese#^zh-Q0061-answer|Compare the answer]]
^zh-Q0061

**zh-Q0062 · Choose the form**

這____無可否認的事實。

There is no denying the fact.

Choices: 是 / 有 / 在

[[Mandarin Chinese#^zh-Q0062-answer|Compare the answer]]
^zh-Q0062

**zh-Q0063 · Edit the changed sentence**

不【有】所有的临床研究都是假设驱动的。

Not all clinical studies are hypothesis-driven.

[[Mandarin Chinese#^zh-Q0063-answer|Compare the answer]]
^zh-Q0063

**zh-Q0064 · Build the sentence**

Arrange: 是 / 不 / 所有的临床研究都是假设驱动的。

Not all clinical studies are hypothesis-driven.

[[Mandarin Chinese#^zh-Q0064-answer|Compare the answer]]
^zh-Q0064

**zh-Q0065 · Write a translation**

Write this in Mandarin Chinese: Are you Chinese or Japanese?

[[Mandarin Chinese#^zh-Q0065-answer|Compare the answer]]
^zh-Q0065

**zh-Q0066 · Explain the grammar**

你【是】中国人还是日本人？

Are you Chinese or Japanese?

[[Mandarin Chinese#^zh-Q0066-answer|Compare the answer]]
^zh-Q0066

**zh-Q0067 · Fill the gap**

歐盟盟旗的十二顆星代表的不____創立聯盟的十二個會員國，而是十二門徒。

The twelve stars on the flag of the European Union do not symbolize the twelve founding members of the union. They symbolize the Twelve Apostles.

[[Mandarin Chinese#^zh-Q0067-answer|Compare the answer]]
^zh-Q0067

**zh-Q0068 · Choose the form**

歐盟盟旗的十二顆星代表的不____創立聯盟的十二個會員國，而是十二門徒。

The twelve stars on the flag of the European Union do not symbolize the twelve founding members of the union. They symbolize the Twelve Apostles.

Choices: 有 / 是 / 在

[[Mandarin Chinese#^zh-Q0068-answer|Compare the answer]]
^zh-Q0068

**zh-Q0069 · Edit the changed sentence**

爱和被爱【有】最大的幸福。

To love and to be loved is the greatest happiness.

[[Mandarin Chinese#^zh-Q0069-answer|Compare the answer]]
^zh-Q0069

**zh-Q0070 · Build the sentence**

Arrange: 爱和被爱 / 最大的幸福。 / 是

To love and to be loved is the greatest happiness.

[[Mandarin Chinese#^zh-Q0070-answer|Compare the answer]]
^zh-Q0070

**zh-Q0071 · Write a translation**

Write this in Mandarin Chinese: Who is your favourite singer?

[[Mandarin Chinese#^zh-Q0071-answer|Compare the answer]]
^zh-Q0071

**zh-Q0072 · Explain the grammar**

你喜欢的歌手【是】谁？

Who is your favourite singer?

[[Mandarin Chinese#^zh-Q0072-answer|Compare the answer]]
^zh-Q0072

**zh-Q0073 · Fill the gap**

太棒了！____毛坯房还是装修房？

Great! Is the apartment bought as a concrete shell, or is it ready to move into?

[[Mandarin Chinese#^zh-Q0073-answer|Compare the answer]]
^zh-Q0073

**zh-Q0074 · Choose the form**

太棒了！____毛坯房还是装修房？

Great! Is the apartment bought as a concrete shell, or is it ready to move into?

Choices: 在 / 是 / 有

[[Mandarin Chinese#^zh-Q0074-answer|Compare the answer]]
^zh-Q0074

**zh-Q0075 · Edit the changed sentence**

那件事【有】在十五年前發生的。

That event happened 15 years ago.

[[Mandarin Chinese#^zh-Q0075-answer|Compare the answer]]
^zh-Q0075

**zh-Q0076 · Build the sentence**

Arrange: 是 / 在十五年前發生的。 / 那件事

That event happened 15 years ago.

[[Mandarin Chinese#^zh-Q0076-answer|Compare the answer]]
^zh-Q0076

**zh-Q0077 · Write a translation**

Write this in Mandarin Chinese: When does Tom get here?

[[Mandarin Chinese#^zh-Q0077-answer|Compare the answer]]
^zh-Q0077

**zh-Q0078 · Explain the grammar**

湯姆【是】甚麼時候來到這裡的？

When does Tom get here?

[[Mandarin Chinese#^zh-Q0078-answer|Compare the answer]]
^zh-Q0078

**zh-Q0079 · Fill the gap**

她____一位真正的美人。

She is a real beauty.

[[Mandarin Chinese#^zh-Q0079-answer|Compare the answer]]
^zh-Q0079

**zh-Q0080 · Choose the form**

她____一位真正的美人。

She is a real beauty.

Choices: 在 / 有 / 是

[[Mandarin Chinese#^zh-Q0080-answer|Compare the answer]]
^zh-Q0080

**zh-Q0081 · Edit the changed sentence**

數學【有】所有科學的基礎。

Mathematics is basic to all sciences.

[[Mandarin Chinese#^zh-Q0081-answer|Compare the answer]]
^zh-Q0081

**zh-Q0082 · Build the sentence**

Arrange: 所有科學的基礎。 / 數學 / 是

Mathematics is basic to all sciences.

[[Mandarin Chinese#^zh-Q0082-answer|Compare the answer]]
^zh-Q0082

**zh-Q0083 · Write a translation**

Write this in Mandarin Chinese: Tatoeba is back, but not everything will be working perfectly.

[[Mandarin Chinese#^zh-Q0083-answer|Compare the answer]]
^zh-Q0083

**zh-Q0084 · Explain the grammar**

Tatoeba回來了，但不【是】每樣東西都會正常運作。

Tatoeba is back, but not everything will be working perfectly.

[[Mandarin Chinese#^zh-Q0084-answer|Compare the answer]]
^zh-Q0084

**zh-Q0085 · Fill the gap**

在20世紀期間，滿洲國____一個傀儡國家。

During the 20th century, Manchukuo was a puppet state.

[[Mandarin Chinese#^zh-Q0085-answer|Compare the answer]]
^zh-Q0085

**zh-Q0086 · Choose the form**

在20世紀期間，滿洲國____一個傀儡國家。

During the 20th century, Manchukuo was a puppet state.

Choices: 有 / 是 / 在

[[Mandarin Chinese#^zh-Q0086-answer|Compare the answer]]
^zh-Q0086

**zh-Q0087 · Edit the changed sentence**

哈里发塔【有】现时世界上最高的摩天大楼。

Burj Khalifa is currently the tallest skyscraper in the world.

[[Mandarin Chinese#^zh-Q0087-answer|Compare the answer]]
^zh-Q0087

**zh-Q0088 · Build the sentence**

Arrange: 是 / 哈里发塔 / 现时世界上最高的摩天大楼。

Burj Khalifa is currently the tallest skyscraper in the world.

[[Mandarin Chinese#^zh-Q0088-answer|Compare the answer]]
^zh-Q0088

**zh-Q0089 · Write a translation**

Write this in Mandarin Chinese: It's a good deal.

[[Mandarin Chinese#^zh-Q0089-answer|Compare the answer]]
^zh-Q0089

**zh-Q0090 · Explain the grammar**

这【是】一笔不错的交易。

It's a good deal.

[[Mandarin Chinese#^zh-Q0090-answer|Compare the answer]]
^zh-Q0090

**zh-Q0091 · Fill the gap**

月饼____中国点心的一种。

The mooncake is a kind of Chinese snack.

[[Mandarin Chinese#^zh-Q0091-answer|Compare the answer]]
^zh-Q0091

**zh-Q0092 · Choose the form**

月饼____中国点心的一种。

The mooncake is a kind of Chinese snack.

Choices: 是 / 在 / 有

[[Mandarin Chinese#^zh-Q0092-answer|Compare the answer]]
^zh-Q0092

**zh-Q0093 · Edit the changed sentence**

他還沒有來，不知道【有】不是發生了甚麼意外？

He has not come yet. Something may have happened to him.

[[Mandarin Chinese#^zh-Q0093-answer|Compare the answer]]
^zh-Q0093

**zh-Q0094 · Build the sentence**

Arrange: 他還沒有來，不知道 / 不是發生了甚麼意外？ / 是

He has not come yet. Something may have happened to him.

[[Mandarin Chinese#^zh-Q0094-answer|Compare the answer]]
^zh-Q0094

**zh-Q0095 · Write a translation**

Write this in Mandarin Chinese: When we started, we thought that we knew everything, but we later discovered that we did not.

[[Mandarin Chinese#^zh-Q0095-answer|Compare the answer]]
^zh-Q0095

**zh-Q0096 · Explain the grammar**

开始的时候，我们以为我们什么都知道，但后来发现，事实【是】我们什么都不知道。

When we started, we thought that we knew everything, but we later discovered that we did not.

[[Mandarin Chinese#^zh-Q0096-answer|Compare the answer]]
^zh-Q0096

**zh-Q0097 · Fill the gap**

现在中国公认的标准旗袍的现代版本____首先在上海发展起来的。

The modern version, which is now popularly recognized in China as the standard qipao, was first developed in Shanghai after 1900.

[[Mandarin Chinese#^zh-Q0097-answer|Compare the answer]]
^zh-Q0097

**zh-Q0098 · Choose the form**

现在中国公认的标准旗袍的现代版本____首先在上海发展起来的。

The modern version, which is now popularly recognized in China as the standard qipao, was first developed in Shanghai after 1900.

Choices: 是 / 有 / 在

[[Mandarin Chinese#^zh-Q0098-answer|Compare the answer]]
^zh-Q0098

**zh-Q0099 · Edit the changed sentence**

美国【有】一个自称没有社会阶层的国家。

America likes to claim that it is a "classless" society.

[[Mandarin Chinese#^zh-Q0099-answer|Compare the answer]]
^zh-Q0099

**zh-Q0100 · Build the sentence**

Arrange: 美国 / 一个自称没有社会阶层的国家。 / 是

America likes to claim that it is a "classless" society.

[[Mandarin Chinese#^zh-Q0100-answer|Compare the answer]]
^zh-Q0100


### Possession and existence 有 · 50 questions

**zh-Q0101 · Write a translation**

Write this in Mandarin Chinese: Tom has Mary's address.

[[Mandarin Chinese#^zh-Q0101-answer|Compare the answer]]
^zh-Q0101

**zh-Q0102 · Explain the grammar**

汤姆【有】玛丽的地址。

Tom has Mary's address.

[[Mandarin Chinese#^zh-Q0102-answer|Compare the answer]]
^zh-Q0102

**zh-Q0103 · Fill the gap**

他的英文作文沒____甚麼錯處。

Errors are few, if any, in his English composition.

[[Mandarin Chinese#^zh-Q0103-answer|Compare the answer]]
^zh-Q0103

**zh-Q0104 · Choose the form**

他的英文作文沒____甚麼錯處。

Errors are few, if any, in his English composition.

Choices: 是 / 在 / 有

[[Mandarin Chinese#^zh-Q0104-answer|Compare the answer]]
^zh-Q0104

**zh-Q0105 · Edit the changed sentence**

上海这个地方，海内海外什么菜肴都【是】。

Shanghai has everything under the sun when it comes to food.

[[Mandarin Chinese#^zh-Q0105-answer|Compare the answer]]
^zh-Q0105

**zh-Q0106 · Build the sentence**

Arrange: 上海这个地方，海内海外什么菜肴都 / 。 / 有

Shanghai has everything under the sun when it comes to food.

[[Mandarin Chinese#^zh-Q0106-answer|Compare the answer]]
^zh-Q0106

**zh-Q0107 · Write a translation**

Write this in Mandarin Chinese: I thought I told you that you should get to the concert early.

[[Mandarin Chinese#^zh-Q0107-answer|Compare the answer]]
^zh-Q0107

**zh-Q0108 · Explain the grammar**

难道我没【有】告诉你演唱会的时候要早点去吗？

I thought I told you that you should get to the concert early.

[[Mandarin Chinese#^zh-Q0108-answer|Compare the answer]]
^zh-Q0108

**zh-Q0109 · Fill the gap**

Tatoeba：加入黑暗的一面。我们____巧克力曲奇饼。

Tatoeba: Join the dark side. We have chocolate cookies.

[[Mandarin Chinese#^zh-Q0109-answer|Compare the answer]]
^zh-Q0109

**zh-Q0110 · Choose the form**

Tatoeba：加入黑暗的一面。我们____巧克力曲奇饼。

Tatoeba: Join the dark side. We have chocolate cookies.

Choices: 在 / 是 / 有

[[Mandarin Chinese#^zh-Q0110-answer|Compare the answer]]
^zh-Q0110

**zh-Q0111 · Edit the changed sentence**

我居然忘记了今天【是】课！

I completely forgot that there was class today!

[[Mandarin Chinese#^zh-Q0111-answer|Compare the answer]]
^zh-Q0111

**zh-Q0112 · Build the sentence**

Arrange: 课！ / 有 / 我居然忘记了今天

I completely forgot that there was class today!

[[Mandarin Chinese#^zh-Q0112-answer|Compare the answer]]
^zh-Q0112

**zh-Q0113 · Write a translation**

Write this in Mandarin Chinese: I am interested in Japanese history.

[[Mandarin Chinese#^zh-Q0113-answer|Compare the answer]]
^zh-Q0113

**zh-Q0114 · Explain the grammar**

我對日本歷史【有】興趣。

I am interested in Japanese history.

[[Mandarin Chinese#^zh-Q0114-answer|Compare the answer]]
^zh-Q0114

**zh-Q0115 · Fill the gap**

汤姆____一辆灰色的车。

Tom has a gray car.

[[Mandarin Chinese#^zh-Q0115-answer|Compare the answer]]
^zh-Q0115

**zh-Q0116 · Choose the form**

汤姆____一辆灰色的车。

Tom has a gray car.

Choices: 在 / 是 / 有

[[Mandarin Chinese#^zh-Q0116-answer|Compare the answer]]
^zh-Q0116

**zh-Q0117 · Edit the changed sentence**

我曾【是】个朋友叫汤姆。

I used to have a friend named Tom.

[[Mandarin Chinese#^zh-Q0117-answer|Compare the answer]]
^zh-Q0117

**zh-Q0118 · Build the sentence**

Arrange: 个朋友叫汤姆。 / 有 / 我曾

I used to have a friend named Tom.

[[Mandarin Chinese#^zh-Q0118-answer|Compare the answer]]
^zh-Q0118

**zh-Q0119 · Write a translation**

Write this in Mandarin Chinese: She was seen at a restaurant with her lover.

[[Mandarin Chinese#^zh-Q0119-answer|Compare the answer]]
^zh-Q0119

**zh-Q0120 · Explain the grammar**

【有】人看到了她在饭馆跟她爱人在一起。

She was seen at a restaurant with her lover.

[[Mandarin Chinese#^zh-Q0120-answer|Compare the answer]]
^zh-Q0120

**zh-Q0121 · Fill the gap**

沒____水，沒有東西能生活在這個地球上。

Without water, nothing could live on this earth.

[[Mandarin Chinese#^zh-Q0121-answer|Compare the answer]]
^zh-Q0121

**zh-Q0122 · Choose the form**

沒____水，沒有東西能生活在這個地球上。

Without water, nothing could live on this earth.

Choices: 有 / 在 / 是

[[Mandarin Chinese#^zh-Q0122-answer|Compare the answer]]
^zh-Q0122

**zh-Q0123 · Edit the changed sentence**

这种说法其实【是】点可疑。

This statement is actually kind of suspicious.

[[Mandarin Chinese#^zh-Q0123-answer|Compare the answer]]
^zh-Q0123

**zh-Q0124 · Build the sentence**

Arrange: 这种说法其实 / 点可疑。 / 有

This statement is actually kind of suspicious.

[[Mandarin Chinese#^zh-Q0124-answer|Compare the answer]]
^zh-Q0124

**zh-Q0125 · Write a translation**

Write this in Mandarin Chinese: The policeman didn't tow your car away.

[[Mandarin Chinese#^zh-Q0125-answer|Compare the answer]]
^zh-Q0125

**zh-Q0126 · Explain the grammar**

警察沒【有】拖走你的車。

The policeman didn't tow your car away.

[[Mandarin Chinese#^zh-Q0126-answer|Compare the answer]]
^zh-Q0126

**zh-Q0127 · Fill the gap**

他沒____遵循我們的忠告。

He failed to follow our advice.

[[Mandarin Chinese#^zh-Q0127-answer|Compare the answer]]
^zh-Q0127

**zh-Q0128 · Choose the form**

他沒____遵循我們的忠告。

He failed to follow our advice.

Choices: 有 / 在 / 是

[[Mandarin Chinese#^zh-Q0128-answer|Compare the answer]]
^zh-Q0128

**zh-Q0129 · Edit the changed sentence**

沒【是】必要回那封信。

It isn't necessary to answer that letter.

[[Mandarin Chinese#^zh-Q0129-answer|Compare the answer]]
^zh-Q0129

**zh-Q0130 · Build the sentence**

Arrange: 有 / 沒 / 必要回那封信。

It isn't necessary to answer that letter.

[[Mandarin Chinese#^zh-Q0130-answer|Compare the answer]]
^zh-Q0130

**zh-Q0131 · Write a translation**

Write this in Mandarin Chinese: Would you ever consider dating your best friend's ex-boyfriend?

[[Mandarin Chinese#^zh-Q0131-answer|Compare the answer]]
^zh-Q0131

**zh-Q0132 · Explain the grammar**

你【有】没有想过跟朋友的前男友约会？

Would you ever consider dating your best friend's ex-boyfriend?

[[Mandarin Chinese#^zh-Q0132-answer|Compare the answer]]
^zh-Q0132

**zh-Q0133 · Fill the gap**

你給我的資料沒____多大的用處。

The information you gave me is of little use.

[[Mandarin Chinese#^zh-Q0133-answer|Compare the answer]]
^zh-Q0133

**zh-Q0134 · Choose the form**

你給我的資料沒____多大的用處。

The information you gave me is of little use.

Choices: 在 / 是 / 有

[[Mandarin Chinese#^zh-Q0134-answer|Compare the answer]]
^zh-Q0134

**zh-Q0135 · Edit the changed sentence**

这个教授对他的学生【是】很大的影响力。

The teacher has a great influence on his pupils.

[[Mandarin Chinese#^zh-Q0135-answer|Compare the answer]]
^zh-Q0135

**zh-Q0136 · Build the sentence**

Arrange: 很大的影响力。 / 这个教授对他的学生 / 有

The teacher has a great influence on his pupils.

[[Mandarin Chinese#^zh-Q0136-answer|Compare the answer]]
^zh-Q0136

**zh-Q0137 · Write a translation**

Write this in Mandarin Chinese: The organization is not connected with any political parties.

[[Mandarin Chinese#^zh-Q0137-answer|Compare the answer]]
^zh-Q0137

**zh-Q0138 · Explain the grammar**

这个组织跟任何政党没【有】联系。

The organization is not connected with any political parties.

[[Mandarin Chinese#^zh-Q0138-answer|Compare the answer]]
^zh-Q0138

**zh-Q0139 · Fill the gap**

我的三明治里____肉，奶酪和番茄。

In my sandwich there is meat, cheese and tomatoes.

[[Mandarin Chinese#^zh-Q0139-answer|Compare the answer]]
^zh-Q0139

**zh-Q0140 · Choose the form**

我的三明治里____肉，奶酪和番茄。

In my sandwich there is meat, cheese and tomatoes.

Choices: 是 / 有 / 在

[[Mandarin Chinese#^zh-Q0140-answer|Compare the answer]]
^zh-Q0140

**zh-Q0141 · Edit the changed sentence**

約翰感覺到那黑漆漆的房間裏【是】鬼。

John felt the presence of a ghost in the dark room.

[[Mandarin Chinese#^zh-Q0141-answer|Compare the answer]]
^zh-Q0141

**zh-Q0142 · Build the sentence**

Arrange: 有 / 約翰感覺到那黑漆漆的房間裏 / 鬼。

John felt the presence of a ghost in the dark room.

[[Mandarin Chinese#^zh-Q0142-answer|Compare the answer]]
^zh-Q0142

**zh-Q0143 · Write a translation**

Write this in Mandarin Chinese: She is almost 20 years old.

[[Mandarin Chinese#^zh-Q0143-answer|Compare the answer]]
^zh-Q0143

**zh-Q0144 · Explain the grammar**

她差不多【有】20岁。

She is almost 20 years old.

[[Mandarin Chinese#^zh-Q0144-answer|Compare the answer]]
^zh-Q0144

**zh-Q0145 · Fill the gap**

今天穿了这件____点儿红的衬衫，我能走出去吗？

Can I go out today wearing this shirt that has a little bit of red?

[[Mandarin Chinese#^zh-Q0145-answer|Compare the answer]]
^zh-Q0145

**zh-Q0146 · Choose the form**

今天穿了这件____点儿红的衬衫，我能走出去吗？

Can I go out today wearing this shirt that has a little bit of red?

Choices: 是 / 在 / 有

[[Mandarin Chinese#^zh-Q0146-answer|Compare the answer]]
^zh-Q0146

**zh-Q0147 · Edit the changed sentence**

你能猜到我【是】什么吗？

Can you guess what I have here?

[[Mandarin Chinese#^zh-Q0147-answer|Compare the answer]]
^zh-Q0147

**zh-Q0148 · Build the sentence**

Arrange: 有 / 什么吗？ / 你能猜到我

Can you guess what I have here?

[[Mandarin Chinese#^zh-Q0148-answer|Compare the answer]]
^zh-Q0148

**zh-Q0149 · Write a translation**

Write this in Mandarin Chinese: I don't like novels without heroes.

[[Mandarin Chinese#^zh-Q0149-answer|Compare the answer]]
^zh-Q0149

**zh-Q0150 · Explain the grammar**

我不喜欢没【有】英雄的小说。

I don't like novels without heroes.

[[Mandarin Chinese#^zh-Q0150-answer|Compare the answer]]
^zh-Q0150


### Location and ongoing 在 · 50 questions

**zh-Q0151 · Fill the gap**

实____抱歉，老板在睡觉。请您明天再来。

I'm sorry, my boss is sleeping right now. Please come back tomorrow.

[[Mandarin Chinese#^zh-Q0151-answer|Compare the answer]]
^zh-Q0151

**zh-Q0152 · Choose the form**

实____抱歉，老板在睡觉。请您明天再来。

I'm sorry, my boss is sleeping right now. Please come back tomorrow.

Choices: 在 / 是 / 有

[[Mandarin Chinese#^zh-Q0152-answer|Compare the answer]]
^zh-Q0152

**zh-Q0153 · Edit the changed sentence**

汽车尾气【有】城镇里造成了严重的污染。

Car exhaust causes serious pollution in towns.

[[Mandarin Chinese#^zh-Q0153-answer|Compare the answer]]
^zh-Q0153

**zh-Q0154 · Build the sentence**

Arrange: 城镇里造成了严重的污染。 / 在 / 汽车尾气

Car exhaust causes serious pollution in towns.

[[Mandarin Chinese#^zh-Q0154-answer|Compare the answer]]
^zh-Q0154

**zh-Q0155 · Write a translation**

Write this in Mandarin Chinese: The papers that were in the safe are gone.

[[Mandarin Chinese#^zh-Q0155-answer|Compare the answer]]
^zh-Q0155

**zh-Q0156 · Explain the grammar**

放【在】保險箱裏面的文件不見了。

The papers that were in the safe are gone.

[[Mandarin Chinese#^zh-Q0156-answer|Compare the answer]]
^zh-Q0156

**zh-Q0157 · Fill the gap**

“哈哈哈！我们要让它下雨，小子们！下周这时候，我们就____钱里游泳了！”

"Hahaha! We're going to make it rain, boys! By this time next week, we'll be swimming in cash!"

[[Mandarin Chinese#^zh-Q0157-answer|Compare the answer]]
^zh-Q0157

**zh-Q0158 · Choose the form**

“哈哈哈！我们要让它下雨，小子们！下周这时候，我们就____钱里游泳了！”

"Hahaha! We're going to make it rain, boys! By this time next week, we'll be swimming in cash!"

Choices: 有 / 是 / 在

[[Mandarin Chinese#^zh-Q0158-answer|Compare the answer]]
^zh-Q0158

**zh-Q0159 · Edit the changed sentence**

我不喜欢【有】银行工作.

I don't like working at the bank.

[[Mandarin Chinese#^zh-Q0159-answer|Compare the answer]]
^zh-Q0159

**zh-Q0160 · Build the sentence**

Arrange: 银行工作. / 我不喜欢 / 在

I don't like working at the bank.

[[Mandarin Chinese#^zh-Q0160-answer|Compare the answer]]
^zh-Q0160

**zh-Q0161 · Write a translation**

Write this in Mandarin Chinese: She lives in a huge house.

[[Mandarin Chinese#^zh-Q0161-answer|Compare the answer]]
^zh-Q0161

**zh-Q0162 · Explain the grammar**

她住【在】一個很大的房子裡。

She lives in a huge house.

[[Mandarin Chinese#^zh-Q0162-answer|Compare the answer]]
^zh-Q0162

**zh-Q0163 · Fill the gap**

上個星期四你____他馬德里的家嗎？

Were you in his house in Madrid last Thursday?

[[Mandarin Chinese#^zh-Q0163-answer|Compare the answer]]
^zh-Q0163

**zh-Q0164 · Choose the form**

上個星期四你____他馬德里的家嗎？

Were you in his house in Madrid last Thursday?

Choices: 在 / 有 / 是

[[Mandarin Chinese#^zh-Q0164-answer|Compare the answer]]
^zh-Q0164

**zh-Q0165 · Edit the changed sentence**

他們都【有】尋找這個失蹤的孩子。

They all looked for the lost child.

[[Mandarin Chinese#^zh-Q0165-answer|Compare the answer]]
^zh-Q0165

**zh-Q0166 · Build the sentence**

Arrange: 尋找這個失蹤的孩子。 / 在 / 他們都

They all looked for the lost child.

[[Mandarin Chinese#^zh-Q0166-answer|Compare the answer]]
^zh-Q0166

**zh-Q0167 · Write a translation**

Write this in Mandarin Chinese: Tom and I see each other every day at school.

[[Mandarin Chinese#^zh-Q0167-answer|Compare the answer]]
^zh-Q0167

**zh-Q0168 · Explain the grammar**

汤姆和我每天都【在】学校见面。

Tom and I see each other every day at school.

[[Mandarin Chinese#^zh-Q0168-answer|Compare the answer]]
^zh-Q0168

**zh-Q0169 · Fill the gap**

我____那一個觀點上同意他。

I agree with him on that point.

[[Mandarin Chinese#^zh-Q0169-answer|Compare the answer]]
^zh-Q0169

**zh-Q0170 · Choose the form**

我____那一個觀點上同意他。

I agree with him on that point.

Choices: 在 / 有 / 是

[[Mandarin Chinese#^zh-Q0170-answer|Compare the answer]]
^zh-Q0170

**zh-Q0171 · Edit the changed sentence**

我的母親【有】做蛋糕。

My mother is making a cake.

[[Mandarin Chinese#^zh-Q0171-answer|Compare the answer]]
^zh-Q0171

**zh-Q0172 · Build the sentence**

Arrange: 在 / 做蛋糕。 / 我的母親

My mother is making a cake.

[[Mandarin Chinese#^zh-Q0172-answer|Compare the answer]]
^zh-Q0172

**zh-Q0173 · Write a translation**

Write this in Mandarin Chinese: One million people lost their lives in the war.

[[Mandarin Chinese#^zh-Q0173-answer|Compare the answer]]
^zh-Q0173

**zh-Q0174 · Explain the grammar**

100万人【在】战争中失去了生命。

One million people lost their lives in the war.

[[Mandarin Chinese#^zh-Q0174-answer|Compare the answer]]
^zh-Q0174

**zh-Q0175 · Fill the gap**

我们学校____市中心。

Our school is in the center of the town.

[[Mandarin Chinese#^zh-Q0175-answer|Compare the answer]]
^zh-Q0175

**zh-Q0176 · Choose the form**

我们学校____市中心。

Our school is in the center of the town.

Choices: 有 / 是 / 在

[[Mandarin Chinese#^zh-Q0176-answer|Compare the answer]]
^zh-Q0176

**zh-Q0177 · Edit the changed sentence**

我们应该【有】今天下班前解决所有bug。

We shall fix all bugs today before leaving the office.

[[Mandarin Chinese#^zh-Q0177-answer|Compare the answer]]
^zh-Q0177

**zh-Q0178 · Build the sentence**

Arrange: 今天下班前解决所有bug。 / 我们应该 / 在

We shall fix all bugs today before leaving the office.

[[Mandarin Chinese#^zh-Q0178-answer|Compare the answer]]
^zh-Q0178

**zh-Q0179 · Write a translation**

Write this in Mandarin Chinese: Miss Baker knew that the young man would have to leave very soon, so she decided to ask him to move his car a bit, so that she could park hers in the proper place for the night before going to bed.

[[Mandarin Chinese#^zh-Q0179-answer|Compare the answer]]
^zh-Q0179

**zh-Q0180 · Explain the grammar**

貝克小姐知道那個年輕男子很快就要離開了，所以決定請求他將車稍微移開，如此一來她就能【在】夜間入睡前將她的車停到正確的位置。

Miss Baker knew that the young man would have to leave very soon, so she decided to ask him to move his car a bit, so that she could park hers in the proper place for the night before going to bed.

[[Mandarin Chinese#^zh-Q0180-answer|Compare the answer]]
^zh-Q0180

**zh-Q0181 · Fill the gap**

如果明天下雨，我就待____家。

If it rains tomorrow, I'll just stay at home.

[[Mandarin Chinese#^zh-Q0181-answer|Compare the answer]]
^zh-Q0181

**zh-Q0182 · Choose the form**

如果明天下雨，我就待____家。

If it rains tomorrow, I'll just stay at home.

Choices: 有 / 是 / 在

[[Mandarin Chinese#^zh-Q0182-answer|Compare the answer]]
^zh-Q0182

**zh-Q0183 · Edit the changed sentence**

我們不【有】乎他做什麼。

We don't care what he does.

[[Mandarin Chinese#^zh-Q0183-answer|Compare the answer]]
^zh-Q0183

**zh-Q0184 · Build the sentence**

Arrange: 在 / 我們不 / 乎他做什麼。

We don't care what he does.

[[Mandarin Chinese#^zh-Q0184-answer|Compare the answer]]
^zh-Q0184

**zh-Q0185 · Write a translation**

Write this in Mandarin Chinese: Jane is talking with somebody.

[[Mandarin Chinese#^zh-Q0185-answer|Compare the answer]]
^zh-Q0185

**zh-Q0186 · Explain the grammar**

珍正【在】和某人交談。

Jane is talking with somebody.

[[Mandarin Chinese#^zh-Q0186-answer|Compare the answer]]
^zh-Q0186

**zh-Q0187 · Fill the gap**

你什麼時候會____線上？

When will you be online?

[[Mandarin Chinese#^zh-Q0187-answer|Compare the answer]]
^zh-Q0187

**zh-Q0188 · Choose the form**

你什麼時候會____線上？

When will you be online?

Choices: 在 / 是 / 有

[[Mandarin Chinese#^zh-Q0188-answer|Compare the answer]]
^zh-Q0188

**zh-Q0189 · Edit the changed sentence**

节日和考试碰巧【有】同一天。

The date of the festival coincides with that of the exam.

[[Mandarin Chinese#^zh-Q0189-answer|Compare the answer]]
^zh-Q0189

**zh-Q0190 · Build the sentence**

Arrange: 在 / 同一天。 / 节日和考试碰巧

The date of the festival coincides with that of the exam.

[[Mandarin Chinese#^zh-Q0190-answer|Compare the answer]]
^zh-Q0190

**zh-Q0191 · Write a translation**

Write this in Mandarin Chinese: All essays must be handed in on time.

[[Mandarin Chinese#^zh-Q0191-answer|Compare the answer]]
^zh-Q0191

**zh-Q0192 · Explain the grammar**

所有文章都必须【在】规定时间内交上来。

All essays must be handed in on time.

[[Mandarin Chinese#^zh-Q0192-answer|Compare the answer]]
^zh-Q0192

**zh-Q0193 · Fill the gap**

不____祖国的时候我很想家，但是在家的时候我又想旅游

When I'm away from home, I miss it dearly, but when I am at home, I want to travel.

[[Mandarin Chinese#^zh-Q0193-answer|Compare the answer]]
^zh-Q0193

**zh-Q0194 · Choose the form**

不____祖国的时候我很想家，但是在家的时候我又想旅游

When I'm away from home, I miss it dearly, but when I am at home, I want to travel.

Choices: 在 / 是 / 有

[[Mandarin Chinese#^zh-Q0194-answer|Compare the answer]]
^zh-Q0194

**zh-Q0195 · Edit the changed sentence**

我們可以【有】這個公園裡玩四輪溜冰嗎?

Can we roller-skate in this park?

[[Mandarin Chinese#^zh-Q0195-answer|Compare the answer]]
^zh-Q0195

**zh-Q0196 · Build the sentence**

Arrange: 這個公園裡玩四輪溜冰嗎? / 在 / 我們可以

Can we roller-skate in this park?

[[Mandarin Chinese#^zh-Q0196-answer|Compare the answer]]
^zh-Q0196

**zh-Q0197 · Write a translation**

Write this in Mandarin Chinese: This movie is very popular among young people.

[[Mandarin Chinese#^zh-Q0197-answer|Compare the answer]]
^zh-Q0197

**zh-Q0198 · Explain the grammar**

這部電影【在】年輕人之間很流行。

This movie is very popular among young people.

[[Mandarin Chinese#^zh-Q0198-answer|Compare the answer]]
^zh-Q0198

**zh-Q0199 · Fill the gap**

我____两年前吃过一次。

I ate it once two years ago.

[[Mandarin Chinese#^zh-Q0199-answer|Compare the answer]]
^zh-Q0199

**zh-Q0200 · Choose the form**

我____两年前吃过一次。

I ate it once two years ago.

Choices: 在 / 是 / 有

[[Mandarin Chinese#^zh-Q0200-answer|Compare the answer]]
^zh-Q0200


### Negation 不 and 没 · 50 questions

**zh-Q0201 · Edit the changed sentence**

你千萬【没】要和你父母說這件事。

You mustn't tell that to your parents.

[[Mandarin Chinese#^zh-Q0201-answer|Compare the answer]]
^zh-Q0201

**zh-Q0202 · Build the sentence**

Arrange: 你千萬 / 要和你父母說這件事。 / 不

You mustn't tell that to your parents.

[[Mandarin Chinese#^zh-Q0202-answer|Compare the answer]]
^zh-Q0202

**zh-Q0203 · Write a translation**

Write this in Mandarin Chinese: Tom couldn't tell Mary everything he knew.

[[Mandarin Chinese#^zh-Q0203-answer|Compare the answer]]
^zh-Q0203

**zh-Q0204 · Explain the grammar**

汤姆【不】能告诉玛丽他知道的所有事。

Tom couldn't tell Mary everything he knew.

[[Mandarin Chinese#^zh-Q0204-answer|Compare the answer]]
^zh-Q0204

**zh-Q0205 · Fill the gap**

雖然肉比魚昂貴，但是兩者的營養價值其實是差____多的。

Fish and meat are both nourishing, but the latter is more expensive than the former.

[[Mandarin Chinese#^zh-Q0205-answer|Compare the answer]]
^zh-Q0205

**zh-Q0206 · Choose the form**

雖然肉比魚昂貴，但是兩者的營養價值其實是差____多的。

Fish and meat are both nourishing, but the latter is more expensive than the former.

Choices: 没有 / 没 / 不

[[Mandarin Chinese#^zh-Q0206-answer|Compare the answer]]
^zh-Q0206

**zh-Q0207 · Edit the changed sentence**

我恐怕【没】能幫你了。

I am afraid I can't help you.

[[Mandarin Chinese#^zh-Q0207-answer|Compare the answer]]
^zh-Q0207

**zh-Q0208 · Build the sentence**

Arrange: 能幫你了。 / 我恐怕 / 不

I am afraid I can't help you.

[[Mandarin Chinese#^zh-Q0208-answer|Compare the answer]]
^zh-Q0208

**zh-Q0209 · Write a translation**

Write this in Mandarin Chinese: See no evil, Hear no evil, Speak no evil.

[[Mandarin Chinese#^zh-Q0209-answer|Compare the answer]]
^zh-Q0209

**zh-Q0210 · Explain the grammar**

【不】見、不聞、不言。

See no evil, Hear no evil, Speak no evil.

[[Mandarin Chinese#^zh-Q0210-answer|Compare the answer]]
^zh-Q0210

**zh-Q0211 · Fill the gap**

這碗湯大鹹了，喝____下。

This soup is too salty to eat.

[[Mandarin Chinese#^zh-Q0211-answer|Compare the answer]]
^zh-Q0211

**zh-Q0212 · Choose the form**

這碗湯大鹹了，喝____下。

This soup is too salty to eat.

Choices: 不 / 没 / 没有

[[Mandarin Chinese#^zh-Q0212-answer|Compare the answer]]
^zh-Q0212

**zh-Q0213 · Edit the changed sentence**

湯姆【没】再相信瑪麗了。

Tom no longer trusts Mary.

[[Mandarin Chinese#^zh-Q0213-answer|Compare the answer]]
^zh-Q0213

**zh-Q0214 · Build the sentence**

Arrange: 不 / 再相信瑪麗了。 / 湯姆

Tom no longer trusts Mary.

[[Mandarin Chinese#^zh-Q0214-answer|Compare the answer]]
^zh-Q0214

**zh-Q0215 · Write a translation**

Write this in Mandarin Chinese: I didn't know that dogs swim well.

[[Mandarin Chinese#^zh-Q0215-answer|Compare the answer]]
^zh-Q0215

**zh-Q0216 · Explain the grammar**

我【不】知道狗游泳游得好。

I didn't know that dogs swim well.

[[Mandarin Chinese#^zh-Q0216-answer|Compare the answer]]
^zh-Q0216

**zh-Q0217 · Fill the gap**

世事變幻無常，人____能因循守舊、一成不變。

Things change from time to time, and one should change with them.

[[Mandarin Chinese#^zh-Q0217-answer|Compare the answer]]
^zh-Q0217

**zh-Q0218 · Choose the form**

世事變幻無常，人____能因循守舊、一成不變。

Things change from time to time, and one should change with them.

Choices: 没 / 没有 / 不

[[Mandarin Chinese#^zh-Q0218-answer|Compare the answer]]
^zh-Q0218

**zh-Q0219 · Edit the changed sentence**

你会【没】会教我学吹气风笛？

Can you teach me how to play the bagpipes?

[[Mandarin Chinese#^zh-Q0219-answer|Compare the answer]]
^zh-Q0219

**zh-Q0220 · Build the sentence**

Arrange: 不 / 会教我学吹气风笛？ / 你会

Can you teach me how to play the bagpipes?

[[Mandarin Chinese#^zh-Q0220-answer|Compare the answer]]
^zh-Q0220

**zh-Q0221 · Write a translation**

Write this in Mandarin Chinese: Tom is not easily satisfied.

[[Mandarin Chinese#^zh-Q0221-answer|Compare the answer]]
^zh-Q0221

**zh-Q0222 · Explain the grammar**

Tom【不】容易被滿足。

Tom is not easily satisfied.

[[Mandarin Chinese#^zh-Q0222-answer|Compare the answer]]
^zh-Q0222

**zh-Q0223 · Fill the gap**

你搬____動那台鋼琴。

You can't lift the piano.

[[Mandarin Chinese#^zh-Q0223-answer|Compare the answer]]
^zh-Q0223

**zh-Q0224 · Choose the form**

你搬____動那台鋼琴。

You can't lift the piano.

Choices: 没有 / 没 / 不

[[Mandarin Chinese#^zh-Q0224-answer|Compare the answer]]
^zh-Q0224

**zh-Q0225 · Edit the changed sentence**

我【没】能把我的車託付給約翰。

I can't trust John with my car.

[[Mandarin Chinese#^zh-Q0225-answer|Compare the answer]]
^zh-Q0225

**zh-Q0226 · Build the sentence**

Arrange: 不 / 能把我的車託付給約翰。 / 我

I can't trust John with my car.

[[Mandarin Chinese#^zh-Q0226-answer|Compare the answer]]
^zh-Q0226

**zh-Q0227 · Write a translation**

Write this in Mandarin Chinese: She's busy now and can't speak to you.

[[Mandarin Chinese#^zh-Q0227-answer|Compare the answer]]
^zh-Q0227

**zh-Q0228 · Explain the grammar**

她现在忙，【不】能跟你说话。

She's busy now and can't speak to you.

[[Mandarin Chinese#^zh-Q0228-answer|Compare the answer]]
^zh-Q0228

**zh-Q0229 · Fill the gap**

攪拌機對真的喜歡冰沙的人來說很____錯。

Blenders are nice for people who really like smoothies.

[[Mandarin Chinese#^zh-Q0229-answer|Compare the answer]]
^zh-Q0229

**zh-Q0230 · Choose the form**

攪拌機對真的喜歡冰沙的人來說很____錯。

Blenders are nice for people who really like smoothies.

Choices: 没 / 没有 / 不

[[Mandarin Chinese#^zh-Q0230-answer|Compare the answer]]
^zh-Q0230

**zh-Q0231 · Edit the changed sentence**

【没】好意思，我把方向搞錯了。

I'm sorry I've mistaken the direction.

[[Mandarin Chinese#^zh-Q0231-answer|Compare the answer]]
^zh-Q0231

**zh-Q0232 · Build the sentence**

Arrange: 好意思，我把方向搞錯了。 / 不

I'm sorry I've mistaken the direction.

[[Mandarin Chinese#^zh-Q0232-answer|Compare the answer]]
^zh-Q0232

**zh-Q0233 · Write a translation**

Write this in Mandarin Chinese: I don't eat supper because I want to lose some weight.

[[Mandarin Chinese#^zh-Q0233-answer|Compare the answer]]
^zh-Q0233

**zh-Q0234 · Explain the grammar**

我【不】吃晚饭因为我想减肥。

I don't eat supper because I want to lose some weight.

[[Mandarin Chinese#^zh-Q0234-answer|Compare the answer]]
^zh-Q0234

**zh-Q0235 · Fill the gap**

赚再多的钱也____为过

One can't earn too much money.

[[Mandarin Chinese#^zh-Q0235-answer|Compare the answer]]
^zh-Q0235

**zh-Q0236 · Choose the form**

赚再多的钱也____为过

One can't earn too much money.

Choices: 没 / 没有 / 不

[[Mandarin Chinese#^zh-Q0236-answer|Compare the answer]]
^zh-Q0236

**zh-Q0237 · Edit the changed sentence**

哇! 好久【没】見了。

Wow! It's been a long time.

[[Mandarin Chinese#^zh-Q0237-answer|Compare the answer]]
^zh-Q0237

**zh-Q0238 · Build the sentence**

Arrange: 不 / 見了。 / 哇! 好久

Wow! It's been a long time.

[[Mandarin Chinese#^zh-Q0238-answer|Compare the answer]]
^zh-Q0238

**zh-Q0239 · Write a translation**

Write this in Mandarin Chinese: Tom doesn't trust the police.

[[Mandarin Chinese#^zh-Q0239-answer|Compare the answer]]
^zh-Q0239

**zh-Q0240 · Explain the grammar**

湯姆並【不】信任警察。

Tom doesn't trust the police.

[[Mandarin Chinese#^zh-Q0240-answer|Compare the answer]]
^zh-Q0240

**zh-Q0241 · Fill the gap**

我____太適應在這間公司工作。

I felt like a fish out of water at this firm.

[[Mandarin Chinese#^zh-Q0241-answer|Compare the answer]]
^zh-Q0241

**zh-Q0242 · Choose the form**

我____太適應在這間公司工作。

I felt like a fish out of water at this firm.

Choices: 没 / 不 / 没有

[[Mandarin Chinese#^zh-Q0242-answer|Compare the answer]]
^zh-Q0242

**zh-Q0243 · Edit the changed sentence**

她【没】論黨派把票投給了西岡先生。

She voted for Mr Nishioka irrespective of party lines.

[[Mandarin Chinese#^zh-Q0243-answer|Compare the answer]]
^zh-Q0243

**zh-Q0244 · Build the sentence**

Arrange: 論黨派把票投給了西岡先生。 / 她 / 不

She voted for Mr Nishioka irrespective of party lines.

[[Mandarin Chinese#^zh-Q0244-answer|Compare the answer]]
^zh-Q0244

**zh-Q0245 · Write a translation**

Write this in Mandarin Chinese: It was a pleasant day, but there were few people in the park.

[[Mandarin Chinese#^zh-Q0245-answer|Compare the answer]]
^zh-Q0245

**zh-Q0246 · Explain the grammar**

那天天氣很好，但公園裏人並【不】多。

It was a pleasant day, but there were few people in the park.

[[Mandarin Chinese#^zh-Q0246-answer|Compare the answer]]
^zh-Q0246

**zh-Q0247 · Fill the gap**

我____是一個厭惡女性的人; 但如果我是, 我會為你而破例。

I'm not a woman hater; and if I were, I would make an exception for you.

[[Mandarin Chinese#^zh-Q0247-answer|Compare the answer]]
^zh-Q0247

**zh-Q0248 · Choose the form**

我____是一個厭惡女性的人; 但如果我是, 我會為你而破例。

I'm not a woman hater; and if I were, I would make an exception for you.

Choices: 没有 / 没 / 不

[[Mandarin Chinese#^zh-Q0248-answer|Compare the answer]]
^zh-Q0248

**zh-Q0249 · Edit the changed sentence**

天气热点儿【不】关系。

I don't mind if the weather is hot.

[[Mandarin Chinese#^zh-Q0249-answer|Compare the answer]]
^zh-Q0249

**zh-Q0250 · Build the sentence**

Arrange: 没 / 关系。 / 天气热点儿

I don't mind if the weather is hot.

[[Mandarin Chinese#^zh-Q0250-answer|Compare the answer]]
^zh-Q0250


### Attributive 的 · 50 questions

**zh-Q0251 · Write a translation**

Write this in Mandarin Chinese: The boy fell of fright when he saw a ghost.

[[Mandarin Chinese#^zh-Q0251-answer|Compare the answer]]
^zh-Q0251

**zh-Q0252 · Explain the grammar**

那个男孩子见到鬼【的】时候吓了一跳。

The boy fell of fright when he saw a ghost.

[[Mandarin Chinese#^zh-Q0252-answer|Compare the answer]]
^zh-Q0252

**zh-Q0253 · Fill the gap**

國際間____紛爭一定要用和平的方法來解決。

International disputes must be settled peacefully.

[[Mandarin Chinese#^zh-Q0253-answer|Compare the answer]]
^zh-Q0253

**zh-Q0254 · Choose the form**

國際間____紛爭一定要用和平的方法來解決。

International disputes must be settled peacefully.

Choices: 地 / 的 / 得

[[Mandarin Chinese#^zh-Q0254-answer|Compare the answer]]
^zh-Q0254

**zh-Q0255 · Edit the changed sentence**

你應該諮詢你【地】醫生。

You should consult your doctor.

[[Mandarin Chinese#^zh-Q0255-answer|Compare the answer]]
^zh-Q0255

**zh-Q0256 · Build the sentence**

Arrange: 的 / 你應該諮詢你 / 醫生。

You should consult your doctor.

[[Mandarin Chinese#^zh-Q0256-answer|Compare the answer]]
^zh-Q0256

**zh-Q0257 · Write a translation**

Write this in Mandarin Chinese: This is difficult to believe.

[[Mandarin Chinese#^zh-Q0257-answer|Compare the answer]]
^zh-Q0257

**zh-Q0258 · Explain the grammar**

这件事很难以相信【的】。

This is difficult to believe.

[[Mandarin Chinese#^zh-Q0258-answer|Compare the answer]]
^zh-Q0258

**zh-Q0259 · Fill the gap**

他说话时，显然带着高兴____表情。

He spoke with evident glee.

[[Mandarin Chinese#^zh-Q0259-answer|Compare the answer]]
^zh-Q0259

**zh-Q0260 · Choose the form**

他说话时，显然带着高兴____表情。

He spoke with evident glee.

Choices: 的 / 地 / 得

[[Mandarin Chinese#^zh-Q0260-answer|Compare the answer]]
^zh-Q0260

**zh-Q0261 · Edit the changed sentence**

那裏【地】景色美得無法以筆墨形容。

The beauty of the scene was beyond description.

[[Mandarin Chinese#^zh-Q0261-answer|Compare the answer]]
^zh-Q0261

**zh-Q0262 · Build the sentence**

Arrange: 的 / 那裏 / 景色美得無法以筆墨形容。

The beauty of the scene was beyond description.

[[Mandarin Chinese#^zh-Q0262-answer|Compare the answer]]
^zh-Q0262

**zh-Q0263 · Write a translation**

Write this in Mandarin Chinese: Your soul has been condemned to hell.

[[Mandarin Chinese#^zh-Q0263-answer|Compare the answer]]
^zh-Q0263

**zh-Q0264 · Explain the grammar**

你【的】靈魂已墜進了地獄。

Your soul has been condemned to hell.

[[Mandarin Chinese#^zh-Q0264-answer|Compare the answer]]
^zh-Q0264

**zh-Q0265 · Fill the gap**

每个人都知道汤姆____法语很好。

Everyone knows Tom speaks good French.

[[Mandarin Chinese#^zh-Q0265-answer|Compare the answer]]
^zh-Q0265

**zh-Q0266 · Choose the form**

每个人都知道汤姆____法语很好。

Everyone knows Tom speaks good French.

Choices: 得 / 的 / 地

[[Mandarin Chinese#^zh-Q0266-answer|Compare the answer]]
^zh-Q0266

**zh-Q0267 · Edit the changed sentence**

她被视为日本【地】毕加索。

She is known as the Japanese Picasso.

[[Mandarin Chinese#^zh-Q0267-answer|Compare the answer]]
^zh-Q0267

**zh-Q0268 · Build the sentence**

Arrange: 毕加索。 / 的 / 她被视为日本

She is known as the Japanese Picasso.

[[Mandarin Chinese#^zh-Q0268-answer|Compare the answer]]
^zh-Q0268

**zh-Q0269 · Write a translation**

Write this in Mandarin Chinese: She is wearing a white dress today.

[[Mandarin Chinese#^zh-Q0269-answer|Compare the answer]]
^zh-Q0269

**zh-Q0270 · Explain the grammar**

她今天穿著白色【的】衣服。

She is wearing a white dress today.

[[Mandarin Chinese#^zh-Q0270-answer|Compare the answer]]
^zh-Q0270

**zh-Q0271 · Fill the gap**

那超出了我____理解。

That was beyond my comprehension.

[[Mandarin Chinese#^zh-Q0271-answer|Compare the answer]]
^zh-Q0271

**zh-Q0272 · Choose the form**

那超出了我____理解。

That was beyond my comprehension.

Choices: 的 / 地 / 得

[[Mandarin Chinese#^zh-Q0272-answer|Compare the answer]]
^zh-Q0272

**zh-Q0273 · Edit the changed sentence**

请过目25页【地】地图。

Please look over the map on page 25.

[[Mandarin Chinese#^zh-Q0273-answer|Compare the answer]]
^zh-Q0273

**zh-Q0274 · Build the sentence**

Arrange: 的 / 地图。 / 请过目25页

Please look over the map on page 25.

[[Mandarin Chinese#^zh-Q0274-answer|Compare the answer]]
^zh-Q0274

**zh-Q0275 · Write a translation**

Write this in Mandarin Chinese: I tried to draw a stick figure, but I failed when I started to draw the circle. It looked like a loop-sided oval.

[[Mandarin Chinese#^zh-Q0275-answer|Compare the answer]]
^zh-Q0275

**zh-Q0276 · Explain the grammar**

我试图画条纹图形，但是当我画圆【的】时候我失败了。它看起来像一个椭圆的圆环。

I tried to draw a stick figure, but I failed when I started to draw the circle. It looked like a loop-sided oval.

[[Mandarin Chinese#^zh-Q0276-answer|Compare the answer]]
^zh-Q0276

**zh-Q0277 · Fill the gap**

我希望我能买下你想要____所有东西。

I wish I could buy you everything you wanted.

[[Mandarin Chinese#^zh-Q0277-answer|Compare the answer]]
^zh-Q0277

**zh-Q0278 · Choose the form**

我希望我能买下你想要____所有东西。

I wish I could buy you everything you wanted.

Choices: 得 / 地 / 的

[[Mandarin Chinese#^zh-Q0278-answer|Compare the answer]]
^zh-Q0278

**zh-Q0279 · Edit the changed sentence**

克里斯扬起他【地】剑。

Chris swung his sword!

[[Mandarin Chinese#^zh-Q0279-answer|Compare the answer]]
^zh-Q0279

**zh-Q0280 · Build the sentence**

Arrange: 克里斯扬起他 / 剑。 / 的

Chris swung his sword!

[[Mandarin Chinese#^zh-Q0280-answer|Compare the answer]]
^zh-Q0280

**zh-Q0281 · Write a translation**

Write this in Mandarin Chinese: A burglar broke into his house.

[[Mandarin Chinese#^zh-Q0281-answer|Compare the answer]]
^zh-Q0281

**zh-Q0282 · Explain the grammar**

一個竊賊闖進了他【的】房子。

A burglar broke into his house.

[[Mandarin Chinese#^zh-Q0282-answer|Compare the answer]]
^zh-Q0282

**zh-Q0283 · Fill the gap**

他可能喜欢他____工作。

It may be that he likes his job.

[[Mandarin Chinese#^zh-Q0283-answer|Compare the answer]]
^zh-Q0283

**zh-Q0284 · Choose the form**

他可能喜欢他____工作。

It may be that he likes his job.

Choices: 地 / 的 / 得

[[Mandarin Chinese#^zh-Q0284-answer|Compare the answer]]
^zh-Q0284

**zh-Q0285 · Edit the changed sentence**

她嘗試把老師說【地】每一句話都記下來。

She tried to take down every word the teacher said.

[[Mandarin Chinese#^zh-Q0285-answer|Compare the answer]]
^zh-Q0285

**zh-Q0286 · Build the sentence**

Arrange: 她嘗試把老師說 / 每一句話都記下來。 / 的

She tried to take down every word the teacher said.

[[Mandarin Chinese#^zh-Q0286-answer|Compare the answer]]
^zh-Q0286

**zh-Q0287 · Write a translation**

Write this in Mandarin Chinese: Open your eyes, people!

[[Mandarin Chinese#^zh-Q0287-answer|Compare the answer]]
^zh-Q0287

**zh-Q0288 · Explain the grammar**

人们啊，擦亮你【的】眼睛吧！

Open your eyes, people!

[[Mandarin Chinese#^zh-Q0288-answer|Compare the answer]]
^zh-Q0288

**zh-Q0289 · Fill the gap**

清理____时候，我们看到了些他的东西。

While cleaning, we saw some of his things.

[[Mandarin Chinese#^zh-Q0289-answer|Compare the answer]]
^zh-Q0289

**zh-Q0290 · Choose the form**

清理____时候，我们看到了些他的东西。

While cleaning, we saw some of his things.

Choices: 得 / 的 / 地

[[Mandarin Chinese#^zh-Q0290-answer|Compare the answer]]
^zh-Q0290

**zh-Q0291 · Edit the changed sentence**

他【地】辦公室離車站很近。

His office is near the train station.

[[Mandarin Chinese#^zh-Q0291-answer|Compare the answer]]
^zh-Q0291

**zh-Q0292 · Build the sentence**

Arrange: 的 / 辦公室離車站很近。 / 他

His office is near the train station.

[[Mandarin Chinese#^zh-Q0292-answer|Compare the answer]]
^zh-Q0292

**zh-Q0293 · Write a translation**

Write this in Mandarin Chinese: He bought a Honda.

[[Mandarin Chinese#^zh-Q0293-answer|Compare the answer]]
^zh-Q0293

**zh-Q0294 · Explain the grammar**

他賣了一台豐田【的】車。

He bought a Honda.

[[Mandarin Chinese#^zh-Q0294-answer|Compare the answer]]
^zh-Q0294

**zh-Q0295 · Fill the gap**

许多人拒绝了欢迎会____邀请。

Many people rejected the invitation to the welcome party.

[[Mandarin Chinese#^zh-Q0295-answer|Compare the answer]]
^zh-Q0295

**zh-Q0296 · Choose the form**

许多人拒绝了欢迎会____邀请。

Many people rejected the invitation to the welcome party.

Choices: 地 / 的 / 得

[[Mandarin Chinese#^zh-Q0296-answer|Compare the answer]]
^zh-Q0296

**zh-Q0297 · Edit the changed sentence**

这个国家【地】军事力量很先进。

The military power of this country is very advanced.

[[Mandarin Chinese#^zh-Q0297-answer|Compare the answer]]
^zh-Q0297

**zh-Q0298 · Build the sentence**

Arrange: 的 / 军事力量很先进。 / 这个国家

The military power of this country is very advanced.

[[Mandarin Chinese#^zh-Q0298-answer|Compare the answer]]
^zh-Q0298

**zh-Q0299 · Write a translation**

Write this in Mandarin Chinese: We bought a comfortable new armchair.

[[Mandarin Chinese#^zh-Q0299-answer|Compare the answer]]
^zh-Q0299

**zh-Q0300 · Explain the grammar**

我們買了張舒適【的】扶手椅。

We bought a comfortable new armchair.

[[Mandarin Chinese#^zh-Q0300-answer|Compare the answer]]
^zh-Q0300


### Classifiers · 50 questions

**zh-Q0301 · Fill the gap**

汤姆犯了____大失误。

Tom has made a big mistake.

[[Mandarin Chinese#^zh-Q0301-answer|Compare the answer]]
^zh-Q0301

**zh-Q0302 · Choose the form**

汤姆犯了____大失误。

Tom has made a big mistake.

Choices: 只 / 个 / 本 / 张

[[Mandarin Chinese#^zh-Q0302-answer|Compare the answer]]
^zh-Q0302

**zh-Q0303 · Edit the changed sentence**

我们已经等了好几【本】小时了。

We’ve been waiting for hours.

[[Mandarin Chinese#^zh-Q0303-answer|Compare the answer]]
^zh-Q0303

**zh-Q0304 · Build the sentence**

Arrange: 我们已经等了好几 / 小时了。 / 个

We’ve been waiting for hours.

[[Mandarin Chinese#^zh-Q0304-answer|Compare the answer]]
^zh-Q0304

**zh-Q0305 · Write a translation**

Write this in Mandarin Chinese: I beg you, give me a bottle!

[[Mandarin Chinese#^zh-Q0305-answer|Compare the answer]]
^zh-Q0305

**zh-Q0306 · Explain the grammar**

求你了，给我一【个】瓶子吧！

I beg you, give me a bottle!

[[Mandarin Chinese#^zh-Q0306-answer|Compare the answer]]
^zh-Q0306

**zh-Q0307 · Fill the gap**

我要把这____书留给自己。

I'll keep that book for myself.

[[Mandarin Chinese#^zh-Q0307-answer|Compare the answer]]
^zh-Q0307

**zh-Q0308 · Choose the form**

我要把这____书留给自己。

I'll keep that book for myself.

Choices: 个 / 张 / 本 / 只

[[Mandarin Chinese#^zh-Q0308-answer|Compare the answer]]
^zh-Q0308

**zh-Q0309 · Edit the changed sentence**

我们应该往哪【本】方向走？

Which way should we go?

[[Mandarin Chinese#^zh-Q0309-answer|Compare the answer]]
^zh-Q0309

**zh-Q0310 · Build the sentence**

Arrange: 个 / 方向走？ / 我们应该往哪

Which way should we go?

[[Mandarin Chinese#^zh-Q0310-answer|Compare the answer]]
^zh-Q0310

**zh-Q0311 · Write a translation**

Write this in Mandarin Chinese: This book will awaken your imagination.

[[Mandarin Chinese#^zh-Q0311-answer|Compare the answer]]
^zh-Q0311

**zh-Q0312 · Explain the grammar**

這【本】書會讓你發揮想像力。

This book will awaken your imagination.

[[Mandarin Chinese#^zh-Q0312-answer|Compare the answer]]
^zh-Q0312

**zh-Q0313 · Fill the gap**

这____家庭非常贫穷以至于无法偿还贷款。

The family is too poor to pay back the debts.

[[Mandarin Chinese#^zh-Q0313-answer|Compare the answer]]
^zh-Q0313

**zh-Q0314 · Choose the form**

这____家庭非常贫穷以至于无法偿还贷款。

The family is too poor to pay back the debts.

Choices: 张 / 个 / 本 / 只

[[Mandarin Chinese#^zh-Q0314-answer|Compare the answer]]
^zh-Q0314

**zh-Q0315 · Edit the changed sentence**

这【本】娃娃是你自己做的吗？

Did you make this doll by yourself?

[[Mandarin Chinese#^zh-Q0315-answer|Compare the answer]]
^zh-Q0315

**zh-Q0316 · Build the sentence**

Arrange: 个 / 这 / 娃娃是你自己做的吗？

Did you make this doll by yourself?

[[Mandarin Chinese#^zh-Q0316-answer|Compare the answer]]
^zh-Q0316

**zh-Q0317 · Write a translation**

Write this in Mandarin Chinese: She gulped down half her tea in one mouthful.

[[Mandarin Chinese#^zh-Q0317-answer|Compare the answer]]
^zh-Q0317

**zh-Q0318 · Explain the grammar**

她一口气喝下多半【杯】凉茶。

She gulped down half her tea in one mouthful.

[[Mandarin Chinese#^zh-Q0318-answer|Compare the answer]]
^zh-Q0318

**zh-Q0319 · Fill the gap**

她喜欢网球并成为了一____网球教练。

She liked tennis and became a tennis coach.

[[Mandarin Chinese#^zh-Q0319-answer|Compare the answer]]
^zh-Q0319

**zh-Q0320 · Choose the form**

她喜欢网球并成为了一____网球教练。

She liked tennis and became a tennis coach.

Choices: 张 / 本 / 个 / 只

[[Mandarin Chinese#^zh-Q0320-answer|Compare the answer]]
^zh-Q0320

**zh-Q0321 · Edit the changed sentence**

不下50【本】乘客死了。

No fewer than 50 passengers were killed.

[[Mandarin Chinese#^zh-Q0321-answer|Compare the answer]]
^zh-Q0321

**zh-Q0322 · Build the sentence**

Arrange: 个 / 不下50 / 乘客死了。

No fewer than 50 passengers were killed.

[[Mandarin Chinese#^zh-Q0322-answer|Compare the answer]]
^zh-Q0322

**zh-Q0323 · Write a translation**

Write this in Mandarin Chinese: An elderly person in the street fell and broke a leg.

[[Mandarin Chinese#^zh-Q0323-answer|Compare the answer]]
^zh-Q0323

**zh-Q0324 · Explain the grammar**

一【位】老人在街上摔斷了腿。

An elderly person in the street fell and broke a leg.

[[Mandarin Chinese#^zh-Q0324-answer|Compare the answer]]
^zh-Q0324

**zh-Q0325 · Fill the gap**

在厦威夷，一____人可以一年到头享受海水浴的乐趣。

In Hawaii, one can swim in the ocean all year round.

[[Mandarin Chinese#^zh-Q0325-answer|Compare the answer]]
^zh-Q0325

**zh-Q0326 · Choose the form**

在厦威夷，一____人可以一年到头享受海水浴的乐趣。

In Hawaii, one can swim in the ocean all year round.

Choices: 本 / 只 / 张 / 个

[[Mandarin Chinese#^zh-Q0326-answer|Compare the answer]]
^zh-Q0326

**zh-Q0327 · Edit the changed sentence**

那【本】护士人很好，又有礼貌。

That nurse is very kind and polite.

[[Mandarin Chinese#^zh-Q0327-answer|Compare the answer]]
^zh-Q0327

**zh-Q0328 · Build the sentence**

Arrange: 个 / 那 / 护士人很好，又有礼貌。

That nurse is very kind and polite.

[[Mandarin Chinese#^zh-Q0328-answer|Compare the answer]]
^zh-Q0328

**zh-Q0329 · Write a translation**

Write this in Mandarin Chinese: There is a big supermarket in my neighborhood.

[[Mandarin Chinese#^zh-Q0329-answer|Compare the answer]]
^zh-Q0329

**zh-Q0330 · Explain the grammar**

在我的邻近区域有一【个】大超市。

There is a big supermarket in my neighborhood.

[[Mandarin Chinese#^zh-Q0330-answer|Compare the answer]]
^zh-Q0330

**zh-Q0331 · Fill the gap**

那____男人年纪很大。

The man is old.

[[Mandarin Chinese#^zh-Q0331-answer|Compare the answer]]
^zh-Q0331

**zh-Q0332 · Choose the form**

那____男人年纪很大。

The man is old.

Choices: 张 / 本 / 只 / 个

[[Mandarin Chinese#^zh-Q0332-answer|Compare the answer]]
^zh-Q0332

**zh-Q0333 · Edit the changed sentence**

里约热内卢的一【个】自行车道倒塌了。

A bike path collapsed in Rio.

[[Mandarin Chinese#^zh-Q0333-answer|Compare the answer]]
^zh-Q0333

**zh-Q0334 · Build the sentence**

Arrange: 条 / 里约热内卢的一 / 自行车道倒塌了。

A bike path collapsed in Rio.

[[Mandarin Chinese#^zh-Q0334-answer|Compare the answer]]
^zh-Q0334

**zh-Q0335 · Write a translation**

Write this in Mandarin Chinese: He's a quiet man, a little bald on top.

[[Mandarin Chinese#^zh-Q0335-answer|Compare the answer]]
^zh-Q0335

**zh-Q0336 · Explain the grammar**

他是【个】很安静的人，头顶有点秃。

He's a quiet man, a little bald on top.

[[Mandarin Chinese#^zh-Q0336-answer|Compare the answer]]
^zh-Q0336

**zh-Q0337 · Fill the gap**

这____书是不是他一直用的？

Is this book the one he always uses?

[[Mandarin Chinese#^zh-Q0337-answer|Compare the answer]]
^zh-Q0337

**zh-Q0338 · Choose the form**

这____书是不是他一直用的？

Is this book the one he always uses?

Choices: 只 / 个 / 张 / 本

[[Mandarin Chinese#^zh-Q0338-answer|Compare the answer]]
^zh-Q0338

**zh-Q0339 · Edit the changed sentence**

你的学校在这【本】城市吗？

Is your school in this town?

[[Mandarin Chinese#^zh-Q0339-answer|Compare the answer]]
^zh-Q0339

**zh-Q0340 · Build the sentence**

Arrange: 个 / 城市吗？ / 你的学校在这

Is your school in this town?

[[Mandarin Chinese#^zh-Q0340-answer|Compare the answer]]
^zh-Q0340

**zh-Q0341 · Write a translation**

Write this in Mandarin Chinese: Every time I read this book, I find something new.

[[Mandarin Chinese#^zh-Q0341-answer|Compare the answer]]
^zh-Q0341

**zh-Q0342 · Explain the grammar**

我每次讀這【本】書都會有新發現。

Every time I read this book, I find something new.

[[Mandarin Chinese#^zh-Q0342-answer|Compare the answer]]
^zh-Q0342

**zh-Q0343 · Fill the gap**

为躲避风暴，我们躲到了附近的一____谷仓内。

We took refuge from the storm in a nearby barn.

[[Mandarin Chinese#^zh-Q0343-answer|Compare the answer]]
^zh-Q0343

**zh-Q0344 · Choose the form**

为躲避风暴，我们躲到了附近的一____谷仓内。

We took refuge from the storm in a nearby barn.

Choices: 张 / 个 / 本 / 只

[[Mandarin Chinese#^zh-Q0344-answer|Compare the answer]]
^zh-Q0344

**zh-Q0345 · Edit the changed sentence**

我们像澄清这【本】问题

We want to clear up this problem.

[[Mandarin Chinese#^zh-Q0345-answer|Compare the answer]]
^zh-Q0345

**zh-Q0346 · Build the sentence**

Arrange: 个 / 问题 / 我们像澄清这

We want to clear up this problem.

[[Mandarin Chinese#^zh-Q0346-answer|Compare the answer]]
^zh-Q0346

**zh-Q0347 · Write a translation**

Write this in Mandarin Chinese: Their contract is to run out at the end of this month.

[[Mandarin Chinese#^zh-Q0347-answer|Compare the answer]]
^zh-Q0347

**zh-Q0348 · Explain the grammar**

他们的合同在这【个】月底到期。

Their contract is to run out at the end of this month.

[[Mandarin Chinese#^zh-Q0348-answer|Compare the answer]]
^zh-Q0348

**zh-Q0349 · Fill the gap**

我想到那____當記者的女人。

I think of the woman as a journalist.

[[Mandarin Chinese#^zh-Q0349-answer|Compare the answer]]
^zh-Q0349

**zh-Q0350 · Choose the form**

我想到那____當記者的女人。

I think of the woman as a journalist.

Choices: 本 / 张 / 个 / 位

[[Mandarin Chinese#^zh-Q0350-answer|Compare the answer]]
^zh-Q0350


### Demonstratives · 50 questions

**zh-Q0351 · Edit the changed sentence**

汤姆如果想通过【那】门课，就需要加劲学习。

Tom needs to study more if he hopes to pass this class.

[[Mandarin Chinese#^zh-Q0351-answer|Compare the answer]]
^zh-Q0351

**zh-Q0352 · Build the sentence**

Arrange: 这 / 门课，就需要加劲学习。 / 汤姆如果想通过

Tom needs to study more if he hopes to pass this class.

[[Mandarin Chinese#^zh-Q0352-answer|Compare the answer]]
^zh-Q0352

**zh-Q0353 · Write a translation**

Write this in Mandarin Chinese: The incident was etched in his memory.

[[Mandarin Chinese#^zh-Q0353-answer|Compare the answer]]
^zh-Q0353

**zh-Q0354 · Explain the grammar**

【这】件事他铭记于心。

The incident was etched in his memory.

[[Mandarin Chinese#^zh-Q0354-answer|Compare the answer]]
^zh-Q0354

**zh-Q0355 · Fill the gap**

____房子比他那座好得多了。

That house is much better than his house.

[[Mandarin Chinese#^zh-Q0355-answer|Compare the answer]]
^zh-Q0355

**zh-Q0356 · Choose the form**

____房子比他那座好得多了。

That house is much better than his house.

Choices: 那 / 这些 / 那些 / 这

[[Mandarin Chinese#^zh-Q0356-answer|Compare the answer]]
^zh-Q0356

**zh-Q0357 · Edit the changed sentence**

从【那】里到那里驾车一小时。

It is an hour's drive from here to there.

[[Mandarin Chinese#^zh-Q0357-answer|Compare the answer]]
^zh-Q0357

**zh-Q0358 · Build the sentence**

Arrange: 这 / 从 / 里到那里驾车一小时。

It is an hour's drive from here to there.

[[Mandarin Chinese#^zh-Q0358-answer|Compare the answer]]
^zh-Q0358

**zh-Q0359 · Write a translation**

Write this in Mandarin Chinese: After that his life got even tougher.

[[Mandarin Chinese#^zh-Q0359-answer|Compare the answer]]
^zh-Q0359

**zh-Q0360 · Explain the grammar**

自【那】以后他便过起了艰难的生活。

After that his life got even tougher.

[[Mandarin Chinese#^zh-Q0360-answer|Compare the answer]]
^zh-Q0360

**zh-Q0361 · Fill the gap**

對了，就用____個吧！

Alright, let's settle on that one!

[[Mandarin Chinese#^zh-Q0361-answer|Compare the answer]]
^zh-Q0361

**zh-Q0362 · Choose the form**

對了，就用____個吧！

Alright, let's settle on that one!

Choices: 那些 / 这些 / 那 / 这

[[Mandarin Chinese#^zh-Q0362-answer|Compare the answer]]
^zh-Q0362

**zh-Q0363 · Edit the changed sentence**

让我像【那】样继续下去是绝对不可能的。

It's absolutely impossible for me to go on like this.

[[Mandarin Chinese#^zh-Q0363-answer|Compare the answer]]
^zh-Q0363

**zh-Q0364 · Build the sentence**

Arrange: 样继续下去是绝对不可能的。 / 让我像 / 这

It's absolutely impossible for me to go on like this.

[[Mandarin Chinese#^zh-Q0364-answer|Compare the answer]]
^zh-Q0364

**zh-Q0365 · Write a translation**

Write this in Mandarin Chinese: It is really marvelous of you to remember my birthday.

[[Mandarin Chinese#^zh-Q0365-answer|Compare the answer]]
^zh-Q0365

**zh-Q0366 · Explain the grammar**

你還記得我的生日，【那】真是太好了。

It is really marvelous of you to remember my birthday.

[[Mandarin Chinese#^zh-Q0366-answer|Compare the answer]]
^zh-Q0366

**zh-Q0367 · Fill the gap**

对于____份工作来说，我的年龄太老了。

I'm getting too old for this job.

[[Mandarin Chinese#^zh-Q0367-answer|Compare the answer]]
^zh-Q0367

**zh-Q0368 · Choose the form**

对于____份工作来说，我的年龄太老了。

I'm getting too old for this job.

Choices: 那 / 这些 / 那些 / 这

[[Mandarin Chinese#^zh-Q0368-answer|Compare the answer]]
^zh-Q0368

**zh-Q0369 · Edit the changed sentence**

【这】是我最喜歡的部分。

That's the part I liked best.

[[Mandarin Chinese#^zh-Q0369-answer|Compare the answer]]
^zh-Q0369

**zh-Q0370 · Build the sentence**

Arrange: 是我最喜歡的部分。 / 那

That's the part I liked best.

[[Mandarin Chinese#^zh-Q0370-answer|Compare the answer]]
^zh-Q0370

**zh-Q0371 · Write a translation**

Write this in Mandarin Chinese: I don't know the translation of the word 'oindre'.

[[Mandarin Chinese#^zh-Q0371-answer|Compare the answer]]
^zh-Q0371

**zh-Q0372 · Explain the grammar**

我不知道“oindre”【这】词的翻译。

I don't know the translation of the word 'oindre'.

[[Mandarin Chinese#^zh-Q0372-answer|Compare the answer]]
^zh-Q0372

**zh-Q0373 · Fill the gap**

____餐巾颜色相同，但大小不同。

The colours of the napkins are the same, but the sizes are not.

[[Mandarin Chinese#^zh-Q0373-answer|Compare the answer]]
^zh-Q0373

**zh-Q0374 · Choose the form**

____餐巾颜色相同，但大小不同。

The colours of the napkins are the same, but the sizes are not.

Choices: 这些 / 这 / 那些 / 那

[[Mandarin Chinese#^zh-Q0374-answer|Compare the answer]]
^zh-Q0374

**zh-Q0375 · Edit the changed sentence**

我想知道为什么汤姆要我们【这】样做。

I want to know why Tom wants us to do that.

[[Mandarin Chinese#^zh-Q0375-answer|Compare the answer]]
^zh-Q0375

**zh-Q0376 · Build the sentence**

Arrange: 样做。 / 我想知道为什么汤姆要我们 / 那

I want to know why Tom wants us to do that.

[[Mandarin Chinese#^zh-Q0376-answer|Compare the answer]]
^zh-Q0376

**zh-Q0377 · Write a translation**

Write this in Mandarin Chinese: I was frightened by the sight.

[[Mandarin Chinese#^zh-Q0377-answer|Compare the answer]]
^zh-Q0377

**zh-Q0378 · Explain the grammar**

我被【这】情景吓到了。

I was frightened by the sight.

[[Mandarin Chinese#^zh-Q0378-answer|Compare the answer]]
^zh-Q0378

**zh-Q0379 · Fill the gap**

我们在____里下车吧。

Let's get off here.

[[Mandarin Chinese#^zh-Q0379-answer|Compare the answer]]
^zh-Q0379

**zh-Q0380 · Choose the form**

我们在____里下车吧。

Let's get off here.

Choices: 这 / 那 / 这些 / 那些

[[Mandarin Chinese#^zh-Q0380-answer|Compare the answer]]
^zh-Q0380

**zh-Q0381 · Edit the changed sentence**

善待【这】恨你们的人.

Do good to those who hate you.

[[Mandarin Chinese#^zh-Q0381-answer|Compare the answer]]
^zh-Q0381

**zh-Q0382 · Build the sentence**

Arrange: 恨你们的人. / 那些 / 善待

Do good to those who hate you.

[[Mandarin Chinese#^zh-Q0382-answer|Compare the answer]]
^zh-Q0382

**zh-Q0383 · Write a translation**

Write this in Mandarin Chinese: The journalist wanted to write an article that would draw public attention to the issue.

[[Mandarin Chinese#^zh-Q0383-answer|Compare the answer]]
^zh-Q0383

**zh-Q0384 · Explain the grammar**

記者想寫一篇文章，以便吸引公眾對【那】件事情的注意。

The journalist wanted to write an article that would draw public attention to the issue.

[[Mandarin Chinese#^zh-Q0384-answer|Compare the answer]]
^zh-Q0384

**zh-Q0385 · Fill the gap**

关于____件事你之前怎么想的？

How did you feel about that?

[[Mandarin Chinese#^zh-Q0385-answer|Compare the answer]]
^zh-Q0385

**zh-Q0386 · Choose the form**

关于____件事你之前怎么想的？

How did you feel about that?

Choices: 那些 / 那 / 这 / 这些

[[Mandarin Chinese#^zh-Q0386-answer|Compare the answer]]
^zh-Q0386

**zh-Q0387 · Edit the changed sentence**

他以牺牲自己的健康为代价完成了【那】项工作。

He did it at the expense of his health.

[[Mandarin Chinese#^zh-Q0387-answer|Compare the answer]]
^zh-Q0387

**zh-Q0388 · Build the sentence**

Arrange: 这 / 项工作。 / 他以牺牲自己的健康为代价完成了

He did it at the expense of his health.

[[Mandarin Chinese#^zh-Q0388-answer|Compare the answer]]
^zh-Q0388

**zh-Q0389 · Write a translation**

Write this in Mandarin Chinese: See how much more carefully made these are compared to those?

[[Mandarin Chinese#^zh-Q0389-answer|Compare the answer]]
^zh-Q0389

**zh-Q0390 · Explain the grammar**

你看【这】两件做工要比那些讲究。

See how much more carefully made these are compared to those?

[[Mandarin Chinese#^zh-Q0390-answer|Compare the answer]]
^zh-Q0390

**zh-Q0391 · Fill the gap**

我们今天所认识的工业在____时代不存在。

Industry as we know it today didn't exist in those days.

[[Mandarin Chinese#^zh-Q0391-answer|Compare the answer]]
^zh-Q0391

**zh-Q0392 · Choose the form**

我们今天所认识的工业在____时代不存在。

Industry as we know it today didn't exist in those days.

Choices: 这 / 那 / 那个 / 这些

[[Mandarin Chinese#^zh-Q0392-answer|Compare the answer]]
^zh-Q0392

**zh-Q0393 · Edit the changed sentence**

我希望所有【这】想要修訂現行著作權法的人一個從容不迫的夜晚，但實際上所有其他的人也一樣。

I wish all those an unhurried night who want a revision of the existing copyright laws, but actually all the others too.

[[Mandarin Chinese#^zh-Q0393-answer|Compare the answer]]
^zh-Q0393

**zh-Q0394 · Build the sentence**

Arrange: 我希望所有 / 想要修訂現行著作權法的人一個從容不迫的夜晚，但實際上所有其他的人也一樣。 / 那些

I wish all those an unhurried night who want a revision of the existing copyright laws, but actually all the others too.

[[Mandarin Chinese#^zh-Q0394-answer|Compare the answer]]
^zh-Q0394

**zh-Q0395 · Write a translation**

Write this in Mandarin Chinese: It isn't anything like as cold as it was yesterday.

[[Mandarin Chinese#^zh-Q0395-answer|Compare the answer]]
^zh-Q0395

**zh-Q0396 · Explain the grammar**

今天沒有像昨天【那】麼冷。

It isn't anything like as cold as it was yesterday.

[[Mandarin Chinese#^zh-Q0396-answer|Compare the answer]]
^zh-Q0396

**zh-Q0397 · Fill the gap**

____部电影很无聊，最好的部分是结局。

This film is really boring - the best bit is when it finishes.

[[Mandarin Chinese#^zh-Q0397-answer|Compare the answer]]
^zh-Q0397

**zh-Q0398 · Choose the form**

____部电影很无聊，最好的部分是结局。

This film is really boring - the best bit is when it finishes.

Choices: 那些 / 那 / 这些 / 这

[[Mandarin Chinese#^zh-Q0398-answer|Compare the answer]]
^zh-Q0398

**zh-Q0399 · Edit the changed sentence**

【这】個節目現在正在播出。

That program is now being broadcast.

[[Mandarin Chinese#^zh-Q0399-answer|Compare the answer]]
^zh-Q0399

**zh-Q0400 · Build the sentence**

Arrange: 個節目現在正在播出。 / 那

That program is now being broadcast.

[[Mandarin Chinese#^zh-Q0400-answer|Compare the answer]]
^zh-Q0400


### Completion and change 了 · 50 questions

**zh-Q0401 · Write a translation**

Write this in Mandarin Chinese: Today, many problems were encountered.

[[Mandarin Chinese#^zh-Q0401-answer|Compare the answer]]
^zh-Q0401

**zh-Q0402 · Explain the grammar**

今天出现【了】很多问题。

Today, many problems were encountered.

[[Mandarin Chinese#^zh-Q0402-answer|Compare the answer]]
^zh-Q0402

**zh-Q0403 · Fill the gap**

我给____汤姆其中之一。

I gave Tom one of those.

[[Mandarin Chinese#^zh-Q0403-answer|Compare the answer]]
^zh-Q0403

**zh-Q0404 · Choose the form**

我给____汤姆其中之一。

I gave Tom one of those.

Choices: 着 / 过 / 了

[[Mandarin Chinese#^zh-Q0404-answer|Compare the answer]]
^zh-Q0404

**zh-Q0405 · Edit the changed sentence**

我找工作已经很久【过】。

I've been looking for a new job for a long time.

[[Mandarin Chinese#^zh-Q0405-answer|Compare the answer]]
^zh-Q0405

**zh-Q0406 · Build the sentence**

Arrange: 了 / 我找工作已经很久 / 。

I've been looking for a new job for a long time.

[[Mandarin Chinese#^zh-Q0406-answer|Compare the answer]]
^zh-Q0406

**zh-Q0407 · Write a translation**

Write this in Mandarin Chinese: It stopped snowing an hour ago.

[[Mandarin Chinese#^zh-Q0407-answer|Compare the answer]]
^zh-Q0407

**zh-Q0408 · Explain the grammar**

一個小時前雪停【了】。

It stopped snowing an hour ago.

[[Mandarin Chinese#^zh-Q0408-answer|Compare the answer]]
^zh-Q0408

**zh-Q0409 · Fill the gap**

昨天發生____一場車禍。

There was a car accident yesterday.

[[Mandarin Chinese#^zh-Q0409-answer|Compare the answer]]
^zh-Q0409

**zh-Q0410 · Choose the form**

昨天發生____一場車禍。

There was a car accident yesterday.

Choices: 着 / 了 / 过

[[Mandarin Chinese#^zh-Q0410-answer|Compare the answer]]
^zh-Q0410

**zh-Q0411 · Edit the changed sentence**

她十八岁就大学毕业【过】。

She was only 18 when she graduated from university.

[[Mandarin Chinese#^zh-Q0411-answer|Compare the answer]]
^zh-Q0411

**zh-Q0412 · Build the sentence**

Arrange: 了 / 。 / 她十八岁就大学毕业

She was only 18 when she graduated from university.

[[Mandarin Chinese#^zh-Q0412-answer|Compare the answer]]
^zh-Q0412

**zh-Q0413 · Write a translation**

Write this in Mandarin Chinese: Tom and Mary went deer hunting.

[[Mandarin Chinese#^zh-Q0413-answer|Compare the answer]]
^zh-Q0413

**zh-Q0414 · Explain the grammar**

汤姆和玛丽猎鹿去【了】。

Tom and Mary went deer hunting.

[[Mandarin Chinese#^zh-Q0414-answer|Compare the answer]]
^zh-Q0414

**zh-Q0415 · Fill the gap**

我走之后他到达____。

He arrived after I had left.

[[Mandarin Chinese#^zh-Q0415-answer|Compare the answer]]
^zh-Q0415

**zh-Q0416 · Choose the form**

我走之后他到达____。

He arrived after I had left.

Choices: 过 / 了 / 着

[[Mandarin Chinese#^zh-Q0416-answer|Compare the answer]]
^zh-Q0416

**zh-Q0417 · Edit the changed sentence**

她和她父亲的争吵爆发【过】。

An argument erupted between her and her father.

[[Mandarin Chinese#^zh-Q0417-answer|Compare the answer]]
^zh-Q0417

**zh-Q0418 · Build the sentence**

Arrange: 了 / 。 / 她和她父亲的争吵爆发

An argument erupted between her and her father.

[[Mandarin Chinese#^zh-Q0418-answer|Compare the answer]]
^zh-Q0418

**zh-Q0419 · Write a translation**

Write this in Mandarin Chinese: English has become my favorite subject.

[[Mandarin Chinese#^zh-Q0419-answer|Compare the answer]]
^zh-Q0419

**zh-Q0420 · Explain the grammar**

英语变成【了】我最喜欢的学科。

English has become my favorite subject.

[[Mandarin Chinese#^zh-Q0420-answer|Compare the answer]]
^zh-Q0420

**zh-Q0421 · Fill the gap**

搭帳篷花____我們半小時。

It took us half an hour to set up the tent.

[[Mandarin Chinese#^zh-Q0421-answer|Compare the answer]]
^zh-Q0421

**zh-Q0422 · Choose the form**

搭帳篷花____我們半小時。

It took us half an hour to set up the tent.

Choices: 着 / 了 / 过

[[Mandarin Chinese#^zh-Q0422-answer|Compare the answer]]
^zh-Q0422

**zh-Q0423 · Edit the changed sentence**

我們都想知道她為什麼甩【过】這麼好的一個男人。

We all wondered why she had dumped such a nice man.

[[Mandarin Chinese#^zh-Q0423-answer|Compare the answer]]
^zh-Q0423

**zh-Q0424 · Build the sentence**

Arrange: 這麼好的一個男人。 / 我們都想知道她為什麼甩 / 了

We all wondered why she had dumped such a nice man.

[[Mandarin Chinese#^zh-Q0424-answer|Compare the answer]]
^zh-Q0424

**zh-Q0425 · Write a translation**

Write this in Mandarin Chinese: The multinational corporation has forecast the implementation of economies of scale.

[[Mandarin Chinese#^zh-Q0425-answer|Compare the answer]]
^zh-Q0425

**zh-Q0426 · Explain the grammar**

跨国公司预料到【了】规模经济的实行。

The multinational corporation has forecast the implementation of economies of scale.

[[Mandarin Chinese#^zh-Q0426-answer|Compare the answer]]
^zh-Q0426

**zh-Q0427 · Fill the gap**

我又去爬____一次富士山。

I want to climb Mt. Fuji again.

[[Mandarin Chinese#^zh-Q0427-answer|Compare the answer]]
^zh-Q0427

**zh-Q0428 · Choose the form**

我又去爬____一次富士山。

I want to climb Mt. Fuji again.

Choices: 着 / 过 / 了

[[Mandarin Chinese#^zh-Q0428-answer|Compare the answer]]
^zh-Q0428

**zh-Q0429 · Edit the changed sentence**

Muiriel现在20岁【过】。

Muiriel is 20 now.

[[Mandarin Chinese#^zh-Q0429-answer|Compare the answer]]
^zh-Q0429

**zh-Q0430 · Build the sentence**

Arrange: 。 / 了 / Muiriel现在20岁

Muiriel is 20 now.

[[Mandarin Chinese#^zh-Q0430-answer|Compare the answer]]
^zh-Q0430

**zh-Q0431 · Write a translation**

Write this in Mandarin Chinese: Who saw the funeral today?

[[Mandarin Chinese#^zh-Q0431-answer|Compare the answer]]
^zh-Q0431

**zh-Q0432 · Explain the grammar**

谁去看【了】今天的葬礼？

Who saw the funeral today?

[[Mandarin Chinese#^zh-Q0432-answer|Compare the answer]]
^zh-Q0432

**zh-Q0433 · Fill the gap**

房子被大火烧成____灰烬。

The fire reduced the house to ashes.

[[Mandarin Chinese#^zh-Q0433-answer|Compare the answer]]
^zh-Q0433

**zh-Q0434 · Choose the form**

房子被大火烧成____灰烬。

The fire reduced the house to ashes.

Choices: 过 / 着 / 了

[[Mandarin Chinese#^zh-Q0434-answer|Compare the answer]]
^zh-Q0434

**zh-Q0435 · Edit the changed sentence**

鮑伯把這個壺裝滿【过】水。

Bob filled the pot with water.

[[Mandarin Chinese#^zh-Q0435-answer|Compare the answer]]
^zh-Q0435

**zh-Q0436 · Build the sentence**

Arrange: 鮑伯把這個壺裝滿 / 水。 / 了

Bob filled the pot with water.

[[Mandarin Chinese#^zh-Q0436-answer|Compare the answer]]
^zh-Q0436

**zh-Q0437 · Write a translation**

Write this in Mandarin Chinese: You were at my wedding.

[[Mandarin Chinese#^zh-Q0437-answer|Compare the answer]]
^zh-Q0437

**zh-Q0438 · Explain the grammar**

你出席【了】我的婚礼。

You were at my wedding.

[[Mandarin Chinese#^zh-Q0438-answer|Compare the answer]]
^zh-Q0438

**zh-Q0439 · Fill the gap**

Jessie立刻接收____邀请。

Jessie accepted the invitation at once.

[[Mandarin Chinese#^zh-Q0439-answer|Compare the answer]]
^zh-Q0439

**zh-Q0440 · Choose the form**

Jessie立刻接收____邀请。

Jessie accepted the invitation at once.

Choices: 了 / 过 / 着

[[Mandarin Chinese#^zh-Q0440-answer|Compare the answer]]
^zh-Q0440

**zh-Q0441 · Edit the changed sentence**

她在大街上看见我的时候冲我笑【过】笑。

She smiled at me as she passed me in the street.

[[Mandarin Chinese#^zh-Q0441-answer|Compare the answer]]
^zh-Q0441

**zh-Q0442 · Build the sentence**

Arrange: 她在大街上看见我的时候冲我笑 / 笑。 / 了

She smiled at me as she passed me in the street.

[[Mandarin Chinese#^zh-Q0442-answer|Compare the answer]]
^zh-Q0442

**zh-Q0443 · Write a translation**

Write this in Mandarin Chinese: I received your letter yesterday.

[[Mandarin Chinese#^zh-Q0443-answer|Compare the answer]]
^zh-Q0443

**zh-Q0444 · Explain the grammar**

我昨天收到【了】你的信。

I received your letter yesterday.

[[Mandarin Chinese#^zh-Q0444-answer|Compare the answer]]
^zh-Q0444

**zh-Q0445 · Fill the gap**

如果湯姆不能告訴我，就沒人能____。

If Tom can't tell me, then no one can.

[[Mandarin Chinese#^zh-Q0445-answer|Compare the answer]]
^zh-Q0445

**zh-Q0446 · Choose the form**

如果湯姆不能告訴我，就沒人能____。

If Tom can't tell me, then no one can.

Choices: 过 / 着 / 了

[[Mandarin Chinese#^zh-Q0446-answer|Compare the answer]]
^zh-Q0446

**zh-Q0447 · Edit the changed sentence**

棒球比賽因為天雨取消【过】。

The baseball game was called off due to rain.

[[Mandarin Chinese#^zh-Q0447-answer|Compare the answer]]
^zh-Q0447

**zh-Q0448 · Build the sentence**

Arrange: 棒球比賽因為天雨取消 / 。 / 了

The baseball game was called off due to rain.

[[Mandarin Chinese#^zh-Q0448-answer|Compare the answer]]
^zh-Q0448

**zh-Q0449 · Write a translation**

Write this in Mandarin Chinese: It seems the rural area will be developed on a large scale.

[[Mandarin Chinese#^zh-Q0449-answer|Compare the answer]]
^zh-Q0449

**zh-Q0450 · Explain the grammar**

农村好像要大规模发展【了】。

It seems the rural area will be developed on a large scale.

[[Mandarin Chinese#^zh-Q0450-answer|Compare the answer]]
^zh-Q0450


### Experience 过 · 50 questions

**zh-Q0451 · Fill the gap**

今晚我将在朋友家____夜。

I will put up at my friend's tonight.

[[Mandarin Chinese#^zh-Q0451-answer|Compare the answer]]
^zh-Q0451

**zh-Q0452 · Choose the form**

今晚我将在朋友家____夜。

I will put up at my friend's tonight.

Choices: 了 / 过 / 着

[[Mandarin Chinese#^zh-Q0452-answer|Compare the answer]]
^zh-Q0452

**zh-Q0453 · Edit the changed sentence**

我有些年没见【了】他了。

I haven't seen him for years.

[[Mandarin Chinese#^zh-Q0453-answer|Compare the answer]]
^zh-Q0453

**zh-Q0454 · Build the sentence**

Arrange: 我有些年没见 / 他了。 / 过

I haven't seen him for years.

[[Mandarin Chinese#^zh-Q0454-answer|Compare the answer]]
^zh-Q0454

**zh-Q0455 · Write a translation**

Write this in Mandarin Chinese: When did you tell me?

[[Mandarin Chinese#^zh-Q0455-answer|Compare the answer]]
^zh-Q0455

**zh-Q0456 · Explain the grammar**

你什么时候告诉【过】我？

When did you tell me?

[[Mandarin Chinese#^zh-Q0456-answer|Compare the answer]]
^zh-Q0456

**zh-Q0457 · Fill the gap**

我以一分之差错____了那趟火车。

I missed the train by a hair's breadth.

[[Mandarin Chinese#^zh-Q0457-answer|Compare the answer]]
^zh-Q0457

**zh-Q0458 · Choose the form**

我以一分之差错____了那趟火车。

I missed the train by a hair's breadth.

Choices: 了 / 过 / 着

[[Mandarin Chinese#^zh-Q0458-answer|Compare the answer]]
^zh-Q0458

**zh-Q0459 · Edit the changed sentence**

我父母那一代经历【了】战争。

My parents' generation went through the war.

[[Mandarin Chinese#^zh-Q0459-answer|Compare the answer]]
^zh-Q0459

**zh-Q0460 · Build the sentence**

Arrange: 过 / 战争。 / 我父母那一代经历

My parents' generation went through the war.

[[Mandarin Chinese#^zh-Q0460-answer|Compare the answer]]
^zh-Q0460

**zh-Q0461 · Write a translation**

Write this in Mandarin Chinese: Have you listened to this song?

[[Mandarin Chinese#^zh-Q0461-answer|Compare the answer]]
^zh-Q0461

**zh-Q0462 · Explain the grammar**

你听【过】这首曲子吗？

Have you listened to this song?

[[Mandarin Chinese#^zh-Q0462-answer|Compare the answer]]
^zh-Q0462

**zh-Q0463 · Fill the gap**

汤姆死于服药____量。

Tom died of a drug overdose.

[[Mandarin Chinese#^zh-Q0463-answer|Compare the answer]]
^zh-Q0463

**zh-Q0464 · Choose the form**

汤姆死于服药____量。

Tom died of a drug overdose.

Choices: 了 / 着 / 过

[[Mandarin Chinese#^zh-Q0464-answer|Compare the answer]]
^zh-Q0464

**zh-Q0465 · Edit the changed sentence**

我在派对上度【了】了一段快乐的时光。

I had a good time at the party.

[[Mandarin Chinese#^zh-Q0465-answer|Compare the answer]]
^zh-Q0465

**zh-Q0466 · Build the sentence**

Arrange: 过 / 了一段快乐的时光。 / 我在派对上度

I had a good time at the party.

[[Mandarin Chinese#^zh-Q0466-answer|Compare the answer]]
^zh-Q0466

**zh-Q0467 · Write a translation**

Write this in Mandarin Chinese: She probably studied in France, as she speaks French fluently.

[[Mandarin Chinese#^zh-Q0467-answer|Compare the answer]]
^zh-Q0467

**zh-Q0468 · Explain the grammar**

她可能在法国留【过】学，因为她说法语很流畅。

She probably studied in France, as she speaks French fluently.

[[Mandarin Chinese#^zh-Q0468-answer|Compare the answer]]
^zh-Q0468

**zh-Q0469 · Fill the gap**

一条狗被卡车碾____。

A dog was run over by a truck.

[[Mandarin Chinese#^zh-Q0469-answer|Compare the answer]]
^zh-Q0469

**zh-Q0470 · Choose the form**

一条狗被卡车碾____。

A dog was run over by a truck.

Choices: 过 / 着 / 了

[[Mandarin Chinese#^zh-Q0470-answer|Compare the answer]]
^zh-Q0470

**zh-Q0471 · Edit the changed sentence**

如果你没有尝试【了】失败的角色，那么人们也就不会相信你。

If you have no character to lose, people will have no faith in you.

[[Mandarin Chinese#^zh-Q0471-answer|Compare the answer]]
^zh-Q0471

**zh-Q0472 · Build the sentence**

Arrange: 过 / 失败的角色，那么人们也就不会相信你。 / 如果你没有尝试

If you have no character to lose, people will have no faith in you.

[[Mandarin Chinese#^zh-Q0472-answer|Compare the answer]]
^zh-Q0472

**zh-Q0473 · Write a translation**

Write this in Mandarin Chinese: Have a nice day.

[[Mandarin Chinese#^zh-Q0473-answer|Compare the answer]]
^zh-Q0473

**zh-Q0474 · Explain the grammar**

祝你一天【过】得愉快。

Have a nice day.

[[Mandarin Chinese#^zh-Q0474-answer|Compare the answer]]
^zh-Q0474

**zh-Q0475 · Fill the gap**

我现在还没有吃____午饭。

I haven't eaten lunch yet.

[[Mandarin Chinese#^zh-Q0475-answer|Compare the answer]]
^zh-Q0475

**zh-Q0476 · Choose the form**

我现在还没有吃____午饭。

I haven't eaten lunch yet.

Choices: 过 / 了 / 着

[[Mandarin Chinese#^zh-Q0476-answer|Compare the answer]]
^zh-Q0476

**zh-Q0477 · Edit the changed sentence**

他保证【了】会来却没有来。

He promised to come, but he didn't come.

[[Mandarin Chinese#^zh-Q0477-answer|Compare the answer]]
^zh-Q0477

**zh-Q0478 · Build the sentence**

Arrange: 过 / 会来却没有来。 / 他保证

He promised to come, but he didn't come.

[[Mandarin Chinese#^zh-Q0478-answer|Compare the answer]]
^zh-Q0478

**zh-Q0479 · Write a translation**

Write this in Mandarin Chinese: By the way, have you ever been to Hokkaido?

[[Mandarin Chinese#^zh-Q0479-answer|Compare the answer]]
^zh-Q0479

**zh-Q0480 · Explain the grammar**

顺便问一句，你们已经去【过】北海道了吗？

By the way, have you ever been to Hokkaido?

[[Mandarin Chinese#^zh-Q0480-answer|Compare the answer]]
^zh-Q0480

**zh-Q0481 · Fill the gap**

汤姆试____还回泳衣来换成更大一号的，但是员工告诉他那是不被允许的。

Tom tried to return the swimsuit for a larger size, but the clerk told him that wasn't allowed.

[[Mandarin Chinese#^zh-Q0481-answer|Compare the answer]]
^zh-Q0481

**zh-Q0482 · Choose the form**

汤姆试____还回泳衣来换成更大一号的，但是员工告诉他那是不被允许的。

Tom tried to return the swimsuit for a larger size, but the clerk told him that wasn't allowed.

Choices: 了 / 过 / 着

[[Mandarin Chinese#^zh-Q0482-answer|Compare the answer]]
^zh-Q0482

**zh-Q0483 · Edit the changed sentence**

Yanni没看【了】这部电影。

Yanni hasn't seen this movie.

[[Mandarin Chinese#^zh-Q0483-answer|Compare the answer]]
^zh-Q0483

**zh-Q0484 · Build the sentence**

Arrange: Yanni没看 / 这部电影。 / 过

Yanni hasn't seen this movie.

[[Mandarin Chinese#^zh-Q0484-answer|Compare the answer]]
^zh-Q0484

**zh-Q0485 · Write a translation**

Write this in Mandarin Chinese: Have you ever heard someone speaking Esperanto?

[[Mandarin Chinese#^zh-Q0485-answer|Compare the answer]]
^zh-Q0485

**zh-Q0486 · Explain the grammar**

你听【过】别人说世界语吗？

Have you ever heard someone speaking Esperanto?

[[Mandarin Chinese#^zh-Q0486-answer|Compare the answer]]
^zh-Q0486

**zh-Q0487 · Fill the gap**

之后我再也没跟他说____话。

I never spoke to him after that.

[[Mandarin Chinese#^zh-Q0487-answer|Compare the answer]]
^zh-Q0487

**zh-Q0488 · Choose the form**

之后我再也没跟他说____话。

I never spoke to him after that.

Choices: 过 / 了 / 着

[[Mandarin Chinese#^zh-Q0488-answer|Compare the answer]]
^zh-Q0488

**zh-Q0489 · Edit the changed sentence**

我不想【了】这样的生活。

I don't want to live like this.

[[Mandarin Chinese#^zh-Q0489-answer|Compare the answer]]
^zh-Q0489

**zh-Q0490 · Build the sentence**

Arrange: 这样的生活。 / 过 / 我不想

I don't want to live like this.

[[Mandarin Chinese#^zh-Q0490-answer|Compare the answer]]
^zh-Q0490

**zh-Q0491 · Write a translation**

Write this in Mandarin Chinese: I never played golf.

[[Mandarin Chinese#^zh-Q0491-answer|Compare the answer]]
^zh-Q0491

**zh-Q0492 · Explain the grammar**

我从没玩【过】高尔夫。

I never played golf.

[[Mandarin Chinese#^zh-Q0492-answer|Compare the answer]]
^zh-Q0492

**zh-Q0493 · Fill the gap**

他还没有去____法国,他很想明年去.

He still hasn't been to France; he really wants to go next year.

[[Mandarin Chinese#^zh-Q0493-answer|Compare the answer]]
^zh-Q0493

**zh-Q0494 · Choose the form**

他还没有去____法国,他很想明年去.

He still hasn't been to France; he really wants to go next year.

Choices: 着 / 了 / 过

[[Mandarin Chinese#^zh-Q0494-answer|Compare the answer]]
^zh-Q0494

**zh-Q0495 · Edit the changed sentence**

我看孩子们【了】了马路。

I saw the children walk across the street.

[[Mandarin Chinese#^zh-Q0495-answer|Compare the answer]]
^zh-Q0495

**zh-Q0496 · Build the sentence**

Arrange: 我看孩子们 / 了马路。 / 过

I saw the children walk across the street.

[[Mandarin Chinese#^zh-Q0496-answer|Compare the answer]]
^zh-Q0496

**zh-Q0497 · Write a translation**

Write this in Mandarin Chinese: We are spending the night at my uncle's house.

[[Mandarin Chinese#^zh-Q0497-answer|Compare the answer]]
^zh-Q0497

**zh-Q0498 · Explain the grammar**

我们在我的叔叔家【过】夜。

We are spending the night at my uncle's house.

[[Mandarin Chinese#^zh-Q0498-answer|Compare the answer]]
^zh-Q0498

**zh-Q0499 · Fill the gap**

我想呆在家多____钓鱼。

I prefer staying at home to going fishing.

[[Mandarin Chinese#^zh-Q0499-answer|Compare the answer]]
^zh-Q0499

**zh-Q0500 · Choose the form**

我想呆在家多____钓鱼。

I prefer staying at home to going fishing.

Choices: 过 / 着 / 了

[[Mandarin Chinese#^zh-Q0500-answer|Compare the answer]]
^zh-Q0500


### State 着 · 50 questions

**zh-Q0501 · Edit the changed sentence**

水面浮【了】一片落葉。

A fallen leaf floated on the surface of the water.

[[Mandarin Chinese#^zh-Q0501-answer|Compare the answer]]
^zh-Q0501

**zh-Q0502 · Build the sentence**

Arrange: 一片落葉。 / 着 / 水面浮

A fallen leaf floated on the surface of the water.

[[Mandarin Chinese#^zh-Q0502-answer|Compare the answer]]
^zh-Q0502

**zh-Q0503 · Write a translation**

Write this in Mandarin Chinese: Tom tried to kill Mary.

[[Mandarin Chinese#^zh-Q0503-answer|Compare the answer]]
^zh-Q0503

**zh-Q0504 · Explain the grammar**

汤姆试【着】杀死玛丽。

Tom tried to kill Mary.

[[Mandarin Chinese#^zh-Q0504-answer|Compare the answer]]
^zh-Q0504

**zh-Q0505 · Fill the gap**

中国的经济随____时间的推移而变得越来越好。

As time goes on, China's economy gets stronger and stronger.

[[Mandarin Chinese#^zh-Q0505-answer|Compare the answer]]
^zh-Q0505

**zh-Q0506 · Choose the form**

中国的经济随____时间的推移而变得越来越好。

As time goes on, China's economy gets stronger and stronger.

Choices: 了 / 着 / 过

[[Mandarin Chinese#^zh-Q0506-answer|Compare the answer]]
^zh-Q0506

**zh-Q0507 · Edit the changed sentence**

我的朋友相信阴谋论，我该试【了】向他指出他错了吗？

My friend believes conspiracy theories; should I try to prove him wrong?

[[Mandarin Chinese#^zh-Q0507-answer|Compare the answer]]
^zh-Q0507

**zh-Q0508 · Build the sentence**

Arrange: 向他指出他错了吗？ / 着 / 我的朋友相信阴谋论，我该试

My friend believes conspiracy theories; should I try to prove him wrong?

[[Mandarin Chinese#^zh-Q0508-answer|Compare the answer]]
^zh-Q0508

**zh-Q0509 · Write a translation**

Write this in Mandarin Chinese: Tom and I sat on a bench in the park and talked while we fed pigeons.

[[Mandarin Chinese#^zh-Q0509-answer|Compare the answer]]
^zh-Q0509

**zh-Q0510 · Explain the grammar**

我和汤姆在公园的长椅上坐【着】，一边聊天一边喂着鸽子。

Tom and I sat on a bench in the park and talked while we fed pigeons.

[[Mandarin Chinese#^zh-Q0510-answer|Compare the answer]]
^zh-Q0510

**zh-Q0511 · Fill the gap**

那个胖女人拿____一只猴子。

The fat woman was holding a monkey.

[[Mandarin Chinese#^zh-Q0511-answer|Compare the answer]]
^zh-Q0511

**zh-Q0512 · Choose the form**

那个胖女人拿____一只猴子。

The fat woman was holding a monkey.

Choices: 过 / 了 / 着

[[Mandarin Chinese#^zh-Q0512-answer|Compare the answer]]
^zh-Q0512

**zh-Q0513 · Edit the changed sentence**

学友的手里正拿【了】北京地图呢。

My schoolmate is holding a map of Beijing in his hand.

[[Mandarin Chinese#^zh-Q0513-answer|Compare the answer]]
^zh-Q0513

**zh-Q0514 · Build the sentence**

Arrange: 着 / 学友的手里正拿 / 北京地图呢。

My schoolmate is holding a map of Beijing in his hand.

[[Mandarin Chinese#^zh-Q0514-answer|Compare the answer]]
^zh-Q0514

**zh-Q0515 · Write a translation**

Write this in Mandarin Chinese: I was planning on going to the beach today, but then it started to rain.

[[Mandarin Chinese#^zh-Q0515-answer|Compare the answer]]
^zh-Q0515

**zh-Q0516 · Explain the grammar**

我本来预备今天去海滩的，但接【着】天就开始下雨了。

I was planning on going to the beach today, but then it started to rain.

[[Mandarin Chinese#^zh-Q0516-answer|Compare the answer]]
^zh-Q0516

**zh-Q0517 · Fill the gap**

玛丽穿____深蓝色的裙子。

Mary was wearing a navy blue skirt.

[[Mandarin Chinese#^zh-Q0517-answer|Compare the answer]]
^zh-Q0517

**zh-Q0518 · Choose the form**

玛丽穿____深蓝色的裙子。

Mary was wearing a navy blue skirt.

Choices: 了 / 着 / 过

[[Mandarin Chinese#^zh-Q0518-answer|Compare the answer]]
^zh-Q0518

**zh-Q0519 · Edit the changed sentence**

我试【了】考虑更好的计划。

I'm trying to think of better plan.

[[Mandarin Chinese#^zh-Q0519-answer|Compare the answer]]
^zh-Q0519

**zh-Q0520 · Build the sentence**

Arrange: 着 / 考虑更好的计划。 / 我试

I'm trying to think of better plan.

[[Mandarin Chinese#^zh-Q0520-answer|Compare the answer]]
^zh-Q0520

**zh-Q0521 · Write a translation**

Write this in Mandarin Chinese: There are daisies around the steel building.

[[Mandarin Chinese#^zh-Q0521-answer|Compare the answer]]
^zh-Q0521

**zh-Q0522 · Explain the grammar**

那里有许多雏菊围绕【着】钢铁大厦。

There are daisies around the steel building.

[[Mandarin Chinese#^zh-Q0522-answer|Compare the answer]]
^zh-Q0522

**zh-Q0523 · Fill the gap**

爸爸说，最重要的是我活____。

Dad says the most important thing is that I'm alive.

[[Mandarin Chinese#^zh-Q0523-answer|Compare the answer]]
^zh-Q0523

**zh-Q0524 · Choose the form**

爸爸说，最重要的是我活____。

Dad says the most important thing is that I'm alive.

Choices: 过 / 着 / 了

[[Mandarin Chinese#^zh-Q0524-answer|Compare the answer]]
^zh-Q0524

**zh-Q0525 · Edit the changed sentence**

学友看【了】人美在北京照的新照片。

Xueyou is looking at the new pictures Renmei took in Beijing.

[[Mandarin Chinese#^zh-Q0525-answer|Compare the answer]]
^zh-Q0525

**zh-Q0526 · Build the sentence**

Arrange: 学友看 / 人美在北京照的新照片。 / 着

Xueyou is looking at the new pictures Renmei took in Beijing.

[[Mandarin Chinese#^zh-Q0526-answer|Compare the answer]]
^zh-Q0526

**zh-Q0527 · Write a translation**

Write this in Mandarin Chinese: She has a rose in her hand.

[[Mandarin Chinese#^zh-Q0527-answer|Compare the answer]]
^zh-Q0527

**zh-Q0528 · Explain the grammar**

她手里拿【着】一朵玫瑰。

She has a rose in her hand.

[[Mandarin Chinese#^zh-Q0528-answer|Compare the answer]]
^zh-Q0528

**zh-Q0529 · Fill the gap**

一个牧羊人把赶____全身盖白雪的山羊进去被遗弃的山洞躲避暴风雪。

A goatherd drove his goats, all white with snow, into a deserted cave for shelter.

[[Mandarin Chinese#^zh-Q0529-answer|Compare the answer]]
^zh-Q0529

**zh-Q0530 · Choose the form**

一个牧羊人把赶____全身盖白雪的山羊进去被遗弃的山洞躲避暴风雪。

A goatherd drove his goats, all white with snow, into a deserted cave for shelter.

Choices: 着 / 了 / 过

[[Mandarin Chinese#^zh-Q0530-answer|Compare the answer]]
^zh-Q0530

**zh-Q0531 · Edit the changed sentence**

他带【了】雨伞因为下雨了。

He's carrying an umbrella because it's raining.

[[Mandarin Chinese#^zh-Q0531-answer|Compare the answer]]
^zh-Q0531

**zh-Q0532 · Build the sentence**

Arrange: 雨伞因为下雨了。 / 着 / 他带

He's carrying an umbrella because it's raining.

[[Mandarin Chinese#^zh-Q0532-answer|Compare the answer]]
^zh-Q0532

**zh-Q0533 · Write a translation**

Write this in Mandarin Chinese: She was holding a small parasol in her hand.

[[Mandarin Chinese#^zh-Q0533-answer|Compare the answer]]
^zh-Q0533

**zh-Q0534 · Explain the grammar**

她手里握【着】一把小阳伞。

She was holding a small parasol in her hand.

[[Mandarin Chinese#^zh-Q0534-answer|Compare the answer]]
^zh-Q0534

**zh-Q0535 · Fill the gap**

婴儿被志愿者们照顾____。

The babies are taken care of by volunteers.

[[Mandarin Chinese#^zh-Q0535-answer|Compare the answer]]
^zh-Q0535

**zh-Q0536 · Choose the form**

婴儿被志愿者们照顾____。

The babies are taken care of by volunteers.

Choices: 了 / 过 / 着

[[Mandarin Chinese#^zh-Q0536-answer|Compare the answer]]
^zh-Q0536

**zh-Q0537 · Edit the changed sentence**

你最好照【了】医生的建议做。

You had better do as the doctor advised you.

[[Mandarin Chinese#^zh-Q0537-answer|Compare the answer]]
^zh-Q0537

**zh-Q0538 · Build the sentence**

Arrange: 医生的建议做。 / 你最好照 / 着

You had better do as the doctor advised you.

[[Mandarin Chinese#^zh-Q0538-answer|Compare the answer]]
^zh-Q0538

**zh-Q0539 · Write a translation**

Write this in Mandarin Chinese: Tom is asleep. Should I wake him up?

[[Mandarin Chinese#^zh-Q0539-answer|Compare the answer]]
^zh-Q0539

**zh-Q0540 · Explain the grammar**

汤姆睡【着】了。我应该叫醒他吗？

Tom is asleep. Should I wake him up?

[[Mandarin Chinese#^zh-Q0540-answer|Compare the answer]]
^zh-Q0540

**zh-Q0541 · Fill the gap**

我们一字不落的，专心致志的听____。

We listened with great care, not missing a single word.

[[Mandarin Chinese#^zh-Q0541-answer|Compare the answer]]
^zh-Q0541

**zh-Q0542 · Choose the form**

我们一字不落的，专心致志的听____。

We listened with great care, not missing a single word.

Choices: 过 / 了 / 着

[[Mandarin Chinese#^zh-Q0542-answer|Compare the answer]]
^zh-Q0542

**zh-Q0543 · Edit the changed sentence**

走【了】去火车站要多久？

How long does it take to walk to the station?

[[Mandarin Chinese#^zh-Q0543-answer|Compare the answer]]
^zh-Q0543

**zh-Q0544 · Build the sentence**

Arrange: 着 / 去火车站要多久？ / 走

How long does it take to walk to the station?

[[Mandarin Chinese#^zh-Q0544-answer|Compare the answer]]
^zh-Q0544

**zh-Q0545 · Write a translation**

Write this in Mandarin Chinese: As North Korea displays aggression, South Korea concentrates its forces near the border.

[[Mandarin Chinese#^zh-Q0545-answer|Compare the answer]]
^zh-Q0545

**zh-Q0546 · Explain the grammar**

韩国随【着】朝鲜的外患而在边界附近集结军队。

As North Korea displays aggression, South Korea concentrates its forces near the border.

[[Mandarin Chinese#^zh-Q0546-answer|Compare the answer]]
^zh-Q0546

**zh-Q0547 · Fill the gap**

箱子的内容在标签上面写____。

The contents of the box are listed on the label.

[[Mandarin Chinese#^zh-Q0547-answer|Compare the answer]]
^zh-Q0547

**zh-Q0548 · Choose the form**

箱子的内容在标签上面写____。

The contents of the box are listed on the label.

Choices: 了 / 过 / 着

[[Mandarin Chinese#^zh-Q0548-answer|Compare the answer]]
^zh-Q0548

**zh-Q0549 · Edit the changed sentence**

如果你能将它读出来，那就意味【了】你会说这门语言。

If you can read this, it means that you can speak one language!

[[Mandarin Chinese#^zh-Q0549-answer|Compare the answer]]
^zh-Q0549

**zh-Q0550 · Build the sentence**

Arrange: 你会说这门语言。 / 着 / 如果你能将它读出来，那就意味

If you can read this, it means that you can speak one language!

[[Mandarin Chinese#^zh-Q0550-answer|Compare the answer]]
^zh-Q0550


### Disposal 把 · 50 questions

**zh-Q0551 · Write a translation**

Write this in Mandarin Chinese: Move the chair nearer to the desk.

[[Mandarin Chinese#^zh-Q0551-answer|Compare the answer]]
^zh-Q0551

**zh-Q0552 · Explain the grammar**

【把】椅子挪一挪靠近桌子。

Move the chair nearer to the desk.

[[Mandarin Chinese#^zh-Q0552-answer|Compare the answer]]
^zh-Q0552

**zh-Q0553 · Fill the gap**

可以____新地址告訴我嗎？

Please let me know your new address.

[[Mandarin Chinese#^zh-Q0553-answer|Compare the answer]]
^zh-Q0553

**zh-Q0554 · Choose the form**

可以____新地址告訴我嗎？

Please let me know your new address.

Choices: 给 / 把 / 被

[[Mandarin Chinese#^zh-Q0554-answer|Compare the answer]]
^zh-Q0554

**zh-Q0555 · Edit the changed sentence**

我保證在一個星期內【被】這盤錄影帶還給你。

I promise to return this videotape within a week.

[[Mandarin Chinese#^zh-Q0555-answer|Compare the answer]]
^zh-Q0555

**zh-Q0556 · Build the sentence**

Arrange: 把 / 這盤錄影帶還給你。 / 我保證在一個星期內

I promise to return this videotape within a week.

[[Mandarin Chinese#^zh-Q0556-answer|Compare the answer]]
^zh-Q0556

**zh-Q0557 · Write a translation**

Write this in Mandarin Chinese: We painted the house green.

[[Mandarin Chinese#^zh-Q0557-answer|Compare the answer]]
^zh-Q0557

**zh-Q0558 · Explain the grammar**

我们【把】屋子漆成绿色。

We painted the house green.

[[Mandarin Chinese#^zh-Q0558-answer|Compare the answer]]
^zh-Q0558

**zh-Q0559 · Fill the gap**

____她哭的理由告诉我。

Tell me why she is crying.

[[Mandarin Chinese#^zh-Q0559-answer|Compare the answer]]
^zh-Q0559

**zh-Q0560 · Choose the form**

____她哭的理由告诉我。

Tell me why she is crying.

Choices: 把 / 给 / 被

[[Mandarin Chinese#^zh-Q0560-answer|Compare the answer]]
^zh-Q0560

**zh-Q0561 · Edit the changed sentence**

我必須【被】文身去掉。

I had to get my tattoo removed.

[[Mandarin Chinese#^zh-Q0561-answer|Compare the answer]]
^zh-Q0561

**zh-Q0562 · Build the sentence**

Arrange: 我必須 / 文身去掉。 / 把

I had to get my tattoo removed.

[[Mandarin Chinese#^zh-Q0562-answer|Compare the answer]]
^zh-Q0562

**zh-Q0563 · Write a translation**

Write this in Mandarin Chinese: He wrenched the letter from my hand.

[[Mandarin Chinese#^zh-Q0563-answer|Compare the answer]]
^zh-Q0563

**zh-Q0564 · Explain the grammar**

他【把】信從我的手中搶了過去。

He wrenched the letter from my hand.

[[Mandarin Chinese#^zh-Q0564-answer|Compare the answer]]
^zh-Q0564

**zh-Q0565 · Fill the gap**

那場火災____郵車上的郵件燒掉了一大半。

The mail train lost most of its mail in the fire.

[[Mandarin Chinese#^zh-Q0565-answer|Compare the answer]]
^zh-Q0565

**zh-Q0566 · Choose the form**

那場火災____郵車上的郵件燒掉了一大半。

The mail train lost most of its mail in the fire.

Choices: 被 / 把 / 给

[[Mandarin Chinese#^zh-Q0566-answer|Compare the answer]]
^zh-Q0566

**zh-Q0567 · Edit the changed sentence**

他給我們做了一張桌子和兩【被】長椅。

He made a desk and two benches for us.

[[Mandarin Chinese#^zh-Q0567-answer|Compare the answer]]
^zh-Q0567

**zh-Q0568 · Build the sentence**

Arrange: 長椅。 / 把 / 他給我們做了一張桌子和兩

He made a desk and two benches for us.

[[Mandarin Chinese#^zh-Q0568-answer|Compare the answer]]
^zh-Q0568

**zh-Q0569 · Write a translation**

Write this in Mandarin Chinese: He saved the drowning boy at the risk of his own life.

[[Mandarin Chinese#^zh-Q0569-answer|Compare the answer]]
^zh-Q0569

**zh-Q0570 · Explain the grammar**

他奮不顧身地【把】遇溺的男孩救了起來。

He saved the drowning boy at the risk of his own life.

[[Mandarin Chinese#^zh-Q0570-answer|Compare the answer]]
^zh-Q0570

**zh-Q0571 · Fill the gap**

进教室的时候请____帽子摘了。

Take off your hat when you enter a classroom.

[[Mandarin Chinese#^zh-Q0571-answer|Compare the answer]]
^zh-Q0571

**zh-Q0572 · Choose the form**

进教室的时候请____帽子摘了。

Take off your hat when you enter a classroom.

Choices: 把 / 被 / 给

[[Mandarin Chinese#^zh-Q0572-answer|Compare the answer]]
^zh-Q0572

**zh-Q0573 · Edit the changed sentence**

請記得【被】信寄出去。

Please remember to mail the letter.

[[Mandarin Chinese#^zh-Q0573-answer|Compare the answer]]
^zh-Q0573

**zh-Q0574 · Build the sentence**

Arrange: 信寄出去。 / 請記得 / 把

Please remember to mail the letter.

[[Mandarin Chinese#^zh-Q0574-answer|Compare the answer]]
^zh-Q0574

**zh-Q0575 · Write a translation**

Write this in Mandarin Chinese: You definitely can't compare Marseilles and Lyons.

[[Mandarin Chinese#^zh-Q0575-answer|Compare the answer]]
^zh-Q0575

**zh-Q0576 · Explain the grammar**

你绝不可【把】马赛和里昂相比。

You definitely can't compare Marseilles and Lyons.

[[Mandarin Chinese#^zh-Q0576-answer|Compare the answer]]
^zh-Q0576

**zh-Q0577 · Fill the gap**

她慢慢转动门____手。

She turned the doorknob slowly.

[[Mandarin Chinese#^zh-Q0577-answer|Compare the answer]]
^zh-Q0577

**zh-Q0578 · Choose the form**

她慢慢转动门____手。

She turned the doorknob slowly.

Choices: 把 / 给 / 被

[[Mandarin Chinese#^zh-Q0578-answer|Compare the answer]]
^zh-Q0578

**zh-Q0579 · Edit the changed sentence**

我【被】你视为我最要好的朋友之一。

I consider you one of my closest friends.

[[Mandarin Chinese#^zh-Q0579-answer|Compare the answer]]
^zh-Q0579

**zh-Q0580 · Build the sentence**

Arrange: 你视为我最要好的朋友之一。 / 我 / 把

I consider you one of my closest friends.

[[Mandarin Chinese#^zh-Q0580-answer|Compare the answer]]
^zh-Q0580

**zh-Q0581 · Write a translation**

Write this in Mandarin Chinese: We've got to get you out of here.

[[Mandarin Chinese#^zh-Q0581-answer|Compare the answer]]
^zh-Q0581

**zh-Q0582 · Explain the grammar**

我們必須【把】你带走。

We've got to get you out of here.

[[Mandarin Chinese#^zh-Q0582-answer|Compare the answer]]
^zh-Q0582

**zh-Q0583 · Fill the gap**

汤姆____手伸向了书架上最高的一本词典。

Tom reached for a dictionary that was on the very top of the shelf.

[[Mandarin Chinese#^zh-Q0583-answer|Compare the answer]]
^zh-Q0583

**zh-Q0584 · Choose the form**

汤姆____手伸向了书架上最高的一本词典。

Tom reached for a dictionary that was on the very top of the shelf.

Choices: 把 / 被 / 给

[[Mandarin Chinese#^zh-Q0584-answer|Compare the answer]]
^zh-Q0584

**zh-Q0585 · Edit the changed sentence**

她【被】书带回了图书馆。

She took the book back to the library.

[[Mandarin Chinese#^zh-Q0585-answer|Compare the answer]]
^zh-Q0585

**zh-Q0586 · Build the sentence**

Arrange: 把 / 她 / 书带回了图书馆。

She took the book back to the library.

[[Mandarin Chinese#^zh-Q0586-answer|Compare the answer]]
^zh-Q0586

**zh-Q0587 · Write a translation**

Write this in Mandarin Chinese: She left her umbrella in the train.

[[Mandarin Chinese#^zh-Q0587-answer|Compare the answer]]
^zh-Q0587

**zh-Q0588 · Explain the grammar**

她【把】她的雨傘留在火車上了。

She left her umbrella in the train.

[[Mandarin Chinese#^zh-Q0588-answer|Compare the answer]]
^zh-Q0588

**zh-Q0589 · Fill the gap**

你____书拿反了，这是反面，这才是正面。

You're holding the book upside-down. This is upside-down and this is right-side up.

[[Mandarin Chinese#^zh-Q0589-answer|Compare the answer]]
^zh-Q0589

**zh-Q0590 · Choose the form**

你____书拿反了，这是反面，这才是正面。

You're holding the book upside-down. This is upside-down and this is right-side up.

Choices: 被 / 给 / 把

[[Mandarin Chinese#^zh-Q0590-answer|Compare the answer]]
^zh-Q0590

**zh-Q0591 · Edit the changed sentence**

Mary试图【被】围裙围在腰上，然后把烤鸡从炉子里拿出来。

Mary tied an apron around her waist and then took the turkey out of the oven.

[[Mandarin Chinese#^zh-Q0591-answer|Compare the answer]]
^zh-Q0591

**zh-Q0592 · Build the sentence**

Arrange: 围裙围在腰上，然后把烤鸡从炉子里拿出来。 / 把 / Mary试图

Mary tied an apron around her waist and then took the turkey out of the oven.

[[Mandarin Chinese#^zh-Q0592-answer|Compare the answer]]
^zh-Q0592

**zh-Q0593 · Write a translation**

Write this in Mandarin Chinese: He painted the ceiling blue.

[[Mandarin Chinese#^zh-Q0593-answer|Compare the answer]]
^zh-Q0593

**zh-Q0594 · Explain the grammar**

他【把】天花板刷成了蓝色。

He painted the ceiling blue.

[[Mandarin Chinese#^zh-Q0594-answer|Compare the answer]]
^zh-Q0594

**zh-Q0595 · Fill the gap**

我想他得花兩個小時才能____工作做完。

It will take him two hours to finish the work.

[[Mandarin Chinese#^zh-Q0595-answer|Compare the answer]]
^zh-Q0595

**zh-Q0596 · Choose the form**

我想他得花兩個小時才能____工作做完。

It will take him two hours to finish the work.

Choices: 把 / 被 / 给

[[Mandarin Chinese#^zh-Q0596-answer|Compare the answer]]
^zh-Q0596

**zh-Q0597 · Edit the changed sentence**

我並不打算【被】結果告訴你。

I have no intention of telling you the result.

[[Mandarin Chinese#^zh-Q0597-answer|Compare the answer]]
^zh-Q0597

**zh-Q0598 · Build the sentence**

Arrange: 我並不打算 / 結果告訴你。 / 把

I have no intention of telling you the result.

[[Mandarin Chinese#^zh-Q0598-answer|Compare the answer]]
^zh-Q0598

**zh-Q0599 · Write a translation**

Write this in Mandarin Chinese: He placed the ladder against the fence.

[[Mandarin Chinese#^zh-Q0599-answer|Compare the answer]]
^zh-Q0599

**zh-Q0600 · Explain the grammar**

他【把】梯子倚著柵欄放。

He placed the ladder against the fence.

[[Mandarin Chinese#^zh-Q0600-answer|Compare the answer]]
^zh-Q0600


### Passive 被 · 50 questions

**zh-Q0601 · Fill the gap**

道路法规必须____严格遵守。

The rule of the road must be strictly observed.

[[Mandarin Chinese#^zh-Q0601-answer|Compare the answer]]
^zh-Q0601

**zh-Q0602 · Choose the form**

道路法规必须____严格遵守。

The rule of the road must be strictly observed.

Choices: 被 / 把 / 让

[[Mandarin Chinese#^zh-Q0602-answer|Compare the answer]]
^zh-Q0602

**zh-Q0603 · Edit the changed sentence**

人类登上月球、柏林墙倒下，世界【把】我们的科学和想像被连接在一起。

A man touched down on the moon. A wall came down in Berlin. A world was connected by our own science and imagination.

[[Mandarin Chinese#^zh-Q0603-answer|Compare the answer]]
^zh-Q0603

**zh-Q0604 · Build the sentence**

Arrange: 我们的科学和想像被连接在一起。 / 被 / 人类登上月球、柏林墙倒下，世界

A man touched down on the moon. A wall came down in Berlin. A world was connected by our own science and imagination.

[[Mandarin Chinese#^zh-Q0604-answer|Compare the answer]]
^zh-Q0604

**zh-Q0605 · Write a translation**

Write this in Mandarin Chinese: The novel has been translated into many languages.

[[Mandarin Chinese#^zh-Q0605-answer|Compare the answer]]
^zh-Q0605

**zh-Q0606 · Explain the grammar**

這本小說已【被】翻譯成多國語言。

The novel has been translated into many languages.

[[Mandarin Chinese#^zh-Q0606-answer|Compare the answer]]
^zh-Q0606

**zh-Q0607 · Fill the gap**

这水____石油污染了。

This water was polluted by oil.

[[Mandarin Chinese#^zh-Q0607-answer|Compare the answer]]
^zh-Q0607

**zh-Q0608 · Choose the form**

这水____石油污染了。

This water was polluted by oil.

Choices: 把 / 让 / 被

[[Mandarin Chinese#^zh-Q0608-answer|Compare the answer]]
^zh-Q0608

**zh-Q0609 · Edit the changed sentence**

Tom【把】蛇咬到了。

Tom was bitten by a snake.

[[Mandarin Chinese#^zh-Q0609-answer|Compare the answer]]
^zh-Q0609

**zh-Q0610 · Build the sentence**

Arrange: 被 / 蛇咬到了。 / Tom

Tom was bitten by a snake.

[[Mandarin Chinese#^zh-Q0610-answer|Compare the answer]]
^zh-Q0610

**zh-Q0611 · Write a translation**

Write this in Mandarin Chinese: I just got bitten by a mosquito.

[[Mandarin Chinese#^zh-Q0611-answer|Compare the answer]]
^zh-Q0611

**zh-Q0612 · Explain the grammar**

我刚刚【被】蚊子咬了。

I just got bitten by a mosquito.

[[Mandarin Chinese#^zh-Q0612-answer|Compare the answer]]
^zh-Q0612

**zh-Q0613 · Fill the gap**

侵略者注定要____打败。

The aggressors are bound to be defeated.

[[Mandarin Chinese#^zh-Q0613-answer|Compare the answer]]
^zh-Q0613

**zh-Q0614 · Choose the form**

侵略者注定要____打败。

The aggressors are bound to be defeated.

Choices: 让 / 被 / 把

[[Mandarin Chinese#^zh-Q0614-answer|Compare the answer]]
^zh-Q0614

**zh-Q0615 · Edit the changed sentence**

觀光客【把】獨特的景致所吸引。

The tourists were fascinated with the exquisite scenery.

[[Mandarin Chinese#^zh-Q0615-answer|Compare the answer]]
^zh-Q0615

**zh-Q0616 · Build the sentence**

Arrange: 獨特的景致所吸引。 / 被 / 觀光客

The tourists were fascinated with the exquisite scenery.

[[Mandarin Chinese#^zh-Q0616-answer|Compare the answer]]
^zh-Q0616

**zh-Q0617 · Write a translation**

Write this in Mandarin Chinese: Water evaporates when it is heated.

[[Mandarin Chinese#^zh-Q0617-answer|Compare the answer]]
^zh-Q0617

**zh-Q0618 · Explain the grammar**

當水【被】加熱時，水汽蒸發。

Water evaporates when it is heated.

[[Mandarin Chinese#^zh-Q0618-answer|Compare the answer]]
^zh-Q0618

**zh-Q0619 · Fill the gap**

我无法不去想____偷掉的钱。

I cannot stop thinking of the stolen money.

[[Mandarin Chinese#^zh-Q0619-answer|Compare the answer]]
^zh-Q0619

**zh-Q0620 · Choose the form**

我无法不去想____偷掉的钱。

I cannot stop thinking of the stolen money.

Choices: 让 / 把 / 被

[[Mandarin Chinese#^zh-Q0620-answer|Compare the answer]]
^zh-Q0620

**zh-Q0621 · Edit the changed sentence**

他因酒後駕駛而【把】捕。

He was arrested for drunken driving.

[[Mandarin Chinese#^zh-Q0621-answer|Compare the answer]]
^zh-Q0621

**zh-Q0622 · Build the sentence**

Arrange: 被 / 捕。 / 他因酒後駕駛而

He was arrested for drunken driving.

[[Mandarin Chinese#^zh-Q0622-answer|Compare the answer]]
^zh-Q0622

**zh-Q0623 · Write a translation**

Write this in Mandarin Chinese: To love and to be loved is the greatest happiness.

[[Mandarin Chinese#^zh-Q0623-answer|Compare the answer]]
^zh-Q0623

**zh-Q0624 · Explain the grammar**

愛和【被】愛是人生最大的樂事。

To love and to be loved is the greatest happiness.

[[Mandarin Chinese#^zh-Q0624-answer|Compare the answer]]
^zh-Q0624

**zh-Q0625 · Fill the gap**

除了我每個人都____邀請了。

Everyone was invited, except for me.

[[Mandarin Chinese#^zh-Q0625-answer|Compare the answer]]
^zh-Q0625

**zh-Q0626 · Choose the form**

除了我每個人都____邀請了。

Everyone was invited, except for me.

Choices: 把 / 被 / 让

[[Mandarin Chinese#^zh-Q0626-answer|Compare the answer]]
^zh-Q0626

**zh-Q0627 · Edit the changed sentence**

上海【把】称为东方的巴黎。

Shanghai is referred to as the Paris of the East.

[[Mandarin Chinese#^zh-Q0627-answer|Compare the answer]]
^zh-Q0627

**zh-Q0628 · Build the sentence**

Arrange: 上海 / 称为东方的巴黎。 / 被

Shanghai is referred to as the Paris of the East.

[[Mandarin Chinese#^zh-Q0628-answer|Compare the answer]]
^zh-Q0628

**zh-Q0629 · Write a translation**

Write this in Mandarin Chinese: Youths who are caught violating the new rules on behaviour will lose their right to free travel, and will have to complete unpaid community work to earn it back.

[[Mandarin Chinese#^zh-Q0629-answer|Compare the answer]]
^zh-Q0629

**zh-Q0630 · Explain the grammar**

【被】判严重违反新的行为准则的青少年将失去免费乘坐公交车的权利，如果想重新取得必须做无报酬的社区工作。

Youths who are caught violating the new rules on behaviour will lose their right to free travel, and will have to complete unpaid community work to earn it back.

[[Mandarin Chinese#^zh-Q0630-answer|Compare the answer]]
^zh-Q0630

**zh-Q0631 · Fill the gap**

我的腳踏車____偷了。

My bike is stolen.

[[Mandarin Chinese#^zh-Q0631-answer|Compare the answer]]
^zh-Q0631

**zh-Q0632 · Choose the form**

我的腳踏車____偷了。

My bike is stolen.

Choices: 被 / 让 / 把

[[Mandarin Chinese#^zh-Q0632-answer|Compare the answer]]
^zh-Q0632

**zh-Q0633 · Edit the changed sentence**

他常常【把】誤認為是個學生。

He's often mistaken for a student.

[[Mandarin Chinese#^zh-Q0633-answer|Compare the answer]]
^zh-Q0633

**zh-Q0634 · Build the sentence**

Arrange: 他常常 / 誤認為是個學生。 / 被

He's often mistaken for a student.

[[Mandarin Chinese#^zh-Q0634-answer|Compare the answer]]
^zh-Q0634

**zh-Q0635 · Write a translation**

Write this in Mandarin Chinese: People are not remembered by the number of times they fail but for the number of times they succeed.

[[Mandarin Chinese#^zh-Q0635-answer|Compare the answer]]
^zh-Q0635

**zh-Q0636 · Explain the grammar**

人們【被】記得不是因失敗的次數，而是成功的次數。

People are not remembered by the number of times they fail but for the number of times they succeed.

[[Mandarin Chinese#^zh-Q0636-answer|Compare the answer]]
^zh-Q0636

**zh-Q0637 · Fill the gap**

燕大侠发现自己____骗了他飞到了江枫的旁边，他抱走江枫的儿子。燕大侠誓言报复，他把男孩给了一个香料商人。

Yan Daxia realised he had been lied to and flew to Jiang Feng's side. He took Jiang Feng's son and left. Yan Daxia vowed revenge and left the boy with a spice merchant.

[[Mandarin Chinese#^zh-Q0637-answer|Compare the answer]]
^zh-Q0637

**zh-Q0638 · Choose the form**

燕大侠发现自己____骗了他飞到了江枫的旁边，他抱走江枫的儿子。燕大侠誓言报复，他把男孩给了一个香料商人。

Yan Daxia realised he had been lied to and flew to Jiang Feng's side. He took Jiang Feng's son and left. Yan Daxia vowed revenge and left the boy with a spice merchant.

Choices: 把 / 被 / 让

[[Mandarin Chinese#^zh-Q0638-answer|Compare the answer]]
^zh-Q0638

**zh-Q0639 · Edit the changed sentence**

否则，用左手传递食物会【把】认为是不礼貌的，因为左手是用来洗澡的。

Otherwise, it is considered impolite to pass food with the left hand, because the left hand is used for bathing.

[[Mandarin Chinese#^zh-Q0639-answer|Compare the answer]]
^zh-Q0639

**zh-Q0640 · Build the sentence**

Arrange: 认为是不礼貌的，因为左手是用来洗澡的。 / 否则，用左手传递食物会 / 被

Otherwise, it is considered impolite to pass food with the left hand, because the left hand is used for bathing.

[[Mandarin Chinese#^zh-Q0640-answer|Compare the answer]]
^zh-Q0640

**zh-Q0641 · Write a translation**

Write this in Mandarin Chinese: He was attracted by her smile.

[[Mandarin Chinese#^zh-Q0641-answer|Compare the answer]]
^zh-Q0641

**zh-Q0642 · Explain the grammar**

他【被】她的笑容吸引住了。

He was attracted by her smile.

[[Mandarin Chinese#^zh-Q0642-answer|Compare the answer]]
^zh-Q0642

**zh-Q0643 · Fill the gap**

就算我的家發生火災，也會很快就____撲熄的。

Even if my house catches fire it would soon be put out.

[[Mandarin Chinese#^zh-Q0643-answer|Compare the answer]]
^zh-Q0643

**zh-Q0644 · Choose the form**

就算我的家發生火災，也會很快就____撲熄的。

Even if my house catches fire it would soon be put out.

Choices: 被 / 让 / 把

[[Mandarin Chinese#^zh-Q0644-answer|Compare the answer]]
^zh-Q0644

**zh-Q0645 · Edit the changed sentence**

好几间小屋【把】洪水孤立起来了。

Several cottages have been isolated by the flood water.

[[Mandarin Chinese#^zh-Q0645-answer|Compare the answer]]
^zh-Q0645

**zh-Q0646 · Build the sentence**

Arrange: 被 / 洪水孤立起来了。 / 好几间小屋

Several cottages have been isolated by the flood water.

[[Mandarin Chinese#^zh-Q0646-answer|Compare the answer]]
^zh-Q0646

**zh-Q0647 · Write a translation**

Write this in Mandarin Chinese: He was almost hit by a car.

[[Mandarin Chinese#^zh-Q0647-answer|Compare the answer]]
^zh-Q0647

**zh-Q0648 · Explain the grammar**

他差點【被】一輛汽車撞上了。

He was almost hit by a car.

[[Mandarin Chinese#^zh-Q0648-answer|Compare the answer]]
^zh-Q0648

**zh-Q0649 · Fill the gap**

他____任命為駐英國大使。

He was appointed ambassador to Britain.

[[Mandarin Chinese#^zh-Q0649-answer|Compare the answer]]
^zh-Q0649

**zh-Q0650 · Choose the form**

他____任命為駐英國大使。

He was appointed ambassador to Britain.

Choices: 把 / 被 / 让

[[Mandarin Chinese#^zh-Q0650-answer|Compare the answer]]
^zh-Q0650


### Result and degree 得 · 50 questions

**zh-Q0651 · Edit the changed sentence**

瑪麗長【的】像她媽媽。

Mary looks like her mother.

[[Mandarin Chinese#^zh-Q0651-answer|Compare the answer]]
^zh-Q0651

**zh-Q0652 · Build the sentence**

Arrange: 得 / 瑪麗長 / 像她媽媽。

Mary looks like her mother.

[[Mandarin Chinese#^zh-Q0652-answer|Compare the answer]]
^zh-Q0652

**zh-Q0653 · Write a translation**

Write this in Mandarin Chinese: He returned very late at night.

[[Mandarin Chinese#^zh-Q0653-answer|Compare the answer]]
^zh-Q0653

**zh-Q0654 · Explain the grammar**

他晚上回來【得】很晚。

He returned very late at night.

[[Mandarin Chinese#^zh-Q0654-answer|Compare the answer]]
^zh-Q0654

**zh-Q0655 · Fill the gap**

女人往往比男人活____更長。

Women tend to live longer than men.

[[Mandarin Chinese#^zh-Q0655-answer|Compare the answer]]
^zh-Q0655

**zh-Q0656 · Choose the form**

女人往往比男人活____更長。

Women tend to live longer than men.

Choices: 地 / 的 / 得

[[Mandarin Chinese#^zh-Q0656-answer|Compare the answer]]
^zh-Q0656

**zh-Q0657 · Edit the changed sentence**

我在医院的任期完全记【的】，为什么你没有想起我。

My appointment at the hospital completely slipped my mind. Why didn't you remind me?

[[Mandarin Chinese#^zh-Q0657-answer|Compare the answer]]
^zh-Q0657

**zh-Q0658 · Build the sentence**

Arrange: ，为什么你没有想起我。 / 得 / 我在医院的任期完全记

My appointment at the hospital completely slipped my mind. Why didn't you remind me?

[[Mandarin Chinese#^zh-Q0658-answer|Compare the answer]]
^zh-Q0658

**zh-Q0659 · Write a translation**

Write this in Mandarin Chinese: We should take into account she is still young.

[[Mandarin Chinese#^zh-Q0659-answer|Compare the answer]]
^zh-Q0659

**zh-Q0660 · Explain the grammar**

我們【得】體諒她年輕。

We should take into account she is still young.

[[Mandarin Chinese#^zh-Q0660-answer|Compare the answer]]
^zh-Q0660

**zh-Q0661 · Fill the gap**

春天大家起____都很早。

In spring, everyone wakes up early.

[[Mandarin Chinese#^zh-Q0661-answer|Compare the answer]]
^zh-Q0661

**zh-Q0662 · Choose the form**

春天大家起____都很早。

In spring, everyone wakes up early.

Choices: 的 / 得 / 地

[[Mandarin Chinese#^zh-Q0662-answer|Compare the answer]]
^zh-Q0662

**zh-Q0663 · Edit the changed sentence**

今天晚上我玩【的】很開心。

I had a good time this evening.

[[Mandarin Chinese#^zh-Q0663-answer|Compare the answer]]
^zh-Q0663

**zh-Q0664 · Build the sentence**

Arrange: 得 / 很開心。 / 今天晚上我玩

I had a good time this evening.

[[Mandarin Chinese#^zh-Q0664-answer|Compare the answer]]
^zh-Q0664

**zh-Q0665 · Write a translation**

Write this in Mandarin Chinese: Honey, don't forget to wake me up for work at 11 o'clock.

[[Mandarin Chinese#^zh-Q0665-answer|Compare the answer]]
^zh-Q0665

**zh-Q0666 · Explain the grammar**

亲爱的，记【得】11点喊我起床工作。

Honey, don't forget to wake me up for work at 11 o'clock.

[[Mandarin Chinese#^zh-Q0666-answer|Compare the answer]]
^zh-Q0666

**zh-Q0667 · Fill the gap**

我們已經贏____了這場戰鬥。

We have already won this battle.

[[Mandarin Chinese#^zh-Q0667-answer|Compare the answer]]
^zh-Q0667

**zh-Q0668 · Choose the form**

我們已經贏____了這場戰鬥。

We have already won this battle.

Choices: 得 / 的 / 地

[[Mandarin Chinese#^zh-Q0668-answer|Compare the answer]]
^zh-Q0668

**zh-Q0669 · Edit the changed sentence**

我想我現在【的】走了。

I guess I'll have to leave now.

[[Mandarin Chinese#^zh-Q0669-answer|Compare the answer]]
^zh-Q0669

**zh-Q0670 · Build the sentence**

Arrange: 得 / 走了。 / 我想我現在

I guess I'll have to leave now.

[[Mandarin Chinese#^zh-Q0670-answer|Compare the answer]]
^zh-Q0670

**zh-Q0671 · Write a translation**

Write this in Mandarin Chinese: She can assess investments very accurately.

[[Mandarin Chinese#^zh-Q0671-answer|Compare the answer]]
^zh-Q0671

**zh-Q0672 · Explain the grammar**

投资她能判断【得】很正确。

She can assess investments very accurately.

[[Mandarin Chinese#^zh-Q0672-answer|Compare the answer]]
^zh-Q0672

**zh-Q0673 · Fill the gap**

言歸正傳，事情進展____怎麼樣了？

Joking aside, how are things going?

[[Mandarin Chinese#^zh-Q0673-answer|Compare the answer]]
^zh-Q0673

**zh-Q0674 · Choose the form**

言歸正傳，事情進展____怎麼樣了？

Joking aside, how are things going?

Choices: 的 / 地 / 得

[[Mandarin Chinese#^zh-Q0674-answer|Compare the answer]]
^zh-Q0674

**zh-Q0675 · Edit the changed sentence**

我的記性不好。我簡直不記【的】他的名字了。

My memory failed me. I just could not remember his name.

[[Mandarin Chinese#^zh-Q0675-answer|Compare the answer]]
^zh-Q0675

**zh-Q0676 · Build the sentence**

Arrange: 他的名字了。 / 我的記性不好。我簡直不記 / 得

My memory failed me. I just could not remember his name.

[[Mandarin Chinese#^zh-Q0676-answer|Compare the answer]]
^zh-Q0676

**zh-Q0677 · Write a translation**

Write this in Mandarin Chinese: How do you like Japan?

[[Mandarin Chinese#^zh-Q0677-answer|Compare the answer]]
^zh-Q0677

**zh-Q0678 · Explain the grammar**

你覺【得】日本怎麼樣？

How do you like Japan?

[[Mandarin Chinese#^zh-Q0678-answer|Compare the answer]]
^zh-Q0678

**zh-Q0679 · Fill the gap**

你不覺____這個名字很諷刺嗎，「神聖的戰爭」？

Don't you think the name "The Sacred War" sounds a bit sarcastic?

[[Mandarin Chinese#^zh-Q0679-answer|Compare the answer]]
^zh-Q0679

**zh-Q0680 · Choose the form**

你不覺____這個名字很諷刺嗎，「神聖的戰爭」？

Don't you think the name "The Sacred War" sounds a bit sarcastic?

Choices: 的 / 地 / 得

[[Mandarin Chinese#^zh-Q0680-answer|Compare the answer]]
^zh-Q0680

**zh-Q0681 · Edit the changed sentence**

我記【的】你。三年前我們見過面。

I remember you. We met three years ago.

[[Mandarin Chinese#^zh-Q0681-answer|Compare the answer]]
^zh-Q0681

**zh-Q0682 · Build the sentence**

Arrange: 我記 / 你。三年前我們見過面。 / 得

I remember you. We met three years ago.

[[Mandarin Chinese#^zh-Q0682-answer|Compare the answer]]
^zh-Q0682

**zh-Q0683 · Write a translation**

Write this in Mandarin Chinese: I had a nice chat with her.

[[Mandarin Chinese#^zh-Q0683-answer|Compare the answer]]
^zh-Q0683

**zh-Q0684 · Explain the grammar**

我和她聊【得】很愉快。

I had a nice chat with her.

[[Mandarin Chinese#^zh-Q0684-answer|Compare the answer]]
^zh-Q0684

**zh-Q0685 · Fill the gap**

Sean 和 Conner 長____真像！

Sean really greatly resembles Conner!

[[Mandarin Chinese#^zh-Q0685-answer|Compare the answer]]
^zh-Q0685

**zh-Q0686 · Choose the form**

Sean 和 Conner 長____真像！

Sean really greatly resembles Conner!

Choices: 的 / 地 / 得

[[Mandarin Chinese#^zh-Q0686-answer|Compare the answer]]
^zh-Q0686

**zh-Q0687 · Edit the changed sentence**

我游泳可以游【的】很好。

I can swim well.

[[Mandarin Chinese#^zh-Q0687-answer|Compare the answer]]
^zh-Q0687

**zh-Q0688 · Build the sentence**

Arrange: 很好。 / 我游泳可以游 / 得

I can swim well.

[[Mandarin Chinese#^zh-Q0688-answer|Compare the answer]]
^zh-Q0688

**zh-Q0689 · Write a translation**

Write this in Mandarin Chinese: My French isn't good enough.

[[Mandarin Chinese#^zh-Q0689-answer|Compare the answer]]
^zh-Q0689

**zh-Q0690 · Explain the grammar**

我的法语说【得】不够好。

My French isn't good enough.

[[Mandarin Chinese#^zh-Q0690-answer|Compare the answer]]
^zh-Q0690

**zh-Q0691 · Fill the gap**

你记____这是在哪一年发生的吗？

Do you remember which year it happened?

[[Mandarin Chinese#^zh-Q0691-answer|Compare the answer]]
^zh-Q0691

**zh-Q0692 · Choose the form**

你记____这是在哪一年发生的吗？

Do you remember which year it happened?

Choices: 地 / 得 / 的

[[Mandarin Chinese#^zh-Q0692-answer|Compare the answer]]
^zh-Q0692

**zh-Q0693 · Edit the changed sentence**

最後笑的人，才是笑【的】最得意的人。

He laughs best who laughs last.

[[Mandarin Chinese#^zh-Q0693-answer|Compare the answer]]
^zh-Q0693

**zh-Q0694 · Build the sentence**

Arrange: 得 / 最得意的人。 / 最後笑的人，才是笑

He laughs best who laughs last.

[[Mandarin Chinese#^zh-Q0694-answer|Compare the answer]]
^zh-Q0694

**zh-Q0695 · Write a translation**

Write this in Mandarin Chinese: I feel very sick.

[[Mandarin Chinese#^zh-Q0695-answer|Compare the answer]]
^zh-Q0695

**zh-Q0696 · Explain the grammar**

我覺【得】我病得很厲害。

I feel very sick.

[[Mandarin Chinese#^zh-Q0696-answer|Compare the answer]]
^zh-Q0696

**zh-Q0697 · Fill the gap**

我的电视机出故障了，所以我不____不拿去修。

My television was broken down, so I had to get it repaired.

[[Mandarin Chinese#^zh-Q0697-answer|Compare the answer]]
^zh-Q0697

**zh-Q0698 · Choose the form**

我的电视机出故障了，所以我不____不拿去修。

My television was broken down, so I had to get it repaired.

Choices: 地 / 得 / 的

[[Mandarin Chinese#^zh-Q0698-answer|Compare the answer]]
^zh-Q0698

**zh-Q0699 · Edit the changed sentence**

要变【的】完美，她就是少了一个缺点。

To be perfect she lacked just one defect.

[[Mandarin Chinese#^zh-Q0699-answer|Compare the answer]]
^zh-Q0699

**zh-Q0700 · Build the sentence**

Arrange: 完美，她就是少了一个缺点。 / 得 / 要变

To be perfect she lacked just one defect.

[[Mandarin Chinese#^zh-Q0700-answer|Compare the answer]]
^zh-Q0700


### Comparison 比 · 50 questions

**zh-Q0701 · Write a translation**

Write this in Mandarin Chinese: The Shinano River is longer than any river in Japan.

[[Mandarin Chinese#^zh-Q0701-answer|Compare the answer]]
^zh-Q0701

**zh-Q0702 · Explain the grammar**

信濃川【比】日本的任何一條河川更長。

The Shinano River is longer than any river in Japan.

[[Mandarin Chinese#^zh-Q0702-answer|Compare the answer]]
^zh-Q0702

**zh-Q0703 · Fill the gap**

她的氣色看起來____以前好。

She looks better than before.

[[Mandarin Chinese#^zh-Q0703-answer|Compare the answer]]
^zh-Q0703

**zh-Q0704 · Choose the form**

她的氣色看起來____以前好。

She looks better than before.

Choices: 比 / 跟 / 和

[[Mandarin Chinese#^zh-Q0704-answer|Compare the answer]]
^zh-Q0704

**zh-Q0705 · Edit the changed sentence**

巧克力的鐵質含量【跟】菠菜還要多。

Chocolate's iron content is higher than spinach's.

[[Mandarin Chinese#^zh-Q0705-answer|Compare the answer]]
^zh-Q0705

**zh-Q0706 · Build the sentence**

Arrange: 比 / 菠菜還要多。 / 巧克力的鐵質含量

Chocolate's iron content is higher than spinach's.

[[Mandarin Chinese#^zh-Q0706-answer|Compare the answer]]
^zh-Q0706

**zh-Q0707 · Write a translation**

Write this in Mandarin Chinese: Most developers hate debugging; it's more fun to create bugs than to correct them.

[[Mandarin Chinese#^zh-Q0707-answer|Compare the answer]]
^zh-Q0707

**zh-Q0708 · Explain the grammar**

大部分程序员讨厌调试，设置故障【比】纠正它们有意思多了。

Most developers hate debugging; it's more fun to create bugs than to correct them.

[[Mandarin Chinese#^zh-Q0708-answer|Compare the answer]]
^zh-Q0708

**zh-Q0709 · Fill the gap**

关于财务方面的事项，公司里没有人____琼斯先生更了解。

With respect to financial matters, Mr Jones knows more than anyone else in the company.

[[Mandarin Chinese#^zh-Q0709-answer|Compare the answer]]
^zh-Q0709

**zh-Q0710 · Choose the form**

关于财务方面的事项，公司里没有人____琼斯先生更了解。

With respect to financial matters, Mr Jones knows more than anyone else in the company.

Choices: 跟 / 和 / 比

[[Mandarin Chinese#^zh-Q0710-answer|Compare the answer]]
^zh-Q0710

**zh-Q0711 · Edit the changed sentence**

我喜歡看棒球【跟】賽。

I like to watch baseball games.

[[Mandarin Chinese#^zh-Q0711-answer|Compare the answer]]
^zh-Q0711

**zh-Q0712 · Build the sentence**

Arrange: 比 / 賽。 / 我喜歡看棒球

I like to watch baseball games.

[[Mandarin Chinese#^zh-Q0712-answer|Compare the answer]]
^zh-Q0712

**zh-Q0713 · Write a translation**

Write this in Mandarin Chinese: I enjoy watching soccer on TV.

[[Mandarin Chinese#^zh-Q0713-answer|Compare the answer]]
^zh-Q0713

**zh-Q0714 · Explain the grammar**

我喜歡在電視上看足球【比】賽。

I enjoy watching soccer on TV.

[[Mandarin Chinese#^zh-Q0714-answer|Compare the answer]]
^zh-Q0714

**zh-Q0715 · Fill the gap**

不管是谁总____没人好。

Anybody would be better than nobody.

[[Mandarin Chinese#^zh-Q0715-answer|Compare the answer]]
^zh-Q0715

**zh-Q0716 · Choose the form**

不管是谁总____没人好。

Anybody would be better than nobody.

Choices: 和 / 跟 / 比

[[Mandarin Chinese#^zh-Q0716-answer|Compare the answer]]
^zh-Q0716

**zh-Q0717 · Edit the changed sentence**

我曾與他的【跟】賽網球。

I had a tennis match with him.

[[Mandarin Chinese#^zh-Q0717-answer|Compare the answer]]
^zh-Q0717

**zh-Q0718 · Build the sentence**

Arrange: 比 / 賽網球。 / 我曾與他的

I had a tennis match with him.

[[Mandarin Chinese#^zh-Q0718-answer|Compare the answer]]
^zh-Q0718

**zh-Q0719 · Write a translation**

Write this in Mandarin Chinese: We watched the soccer game on TV.

[[Mandarin Chinese#^zh-Q0719-answer|Compare the answer]]
^zh-Q0719

**zh-Q0720 · Explain the grammar**

我們看了電視上的足球【比】賽。

We watched the soccer game on TV.

[[Mandarin Chinese#^zh-Q0720-answer|Compare the answer]]
^zh-Q0720

**zh-Q0721 · Fill the gap**

恐惧____利剑更伤人。

Fear is more harmful than the sharpest of swords.

[[Mandarin Chinese#^zh-Q0721-answer|Compare the answer]]
^zh-Q0721

**zh-Q0722 · Choose the form**

恐惧____利剑更伤人。

Fear is more harmful than the sharpest of swords.

Choices: 和 / 跟 / 比

[[Mandarin Chinese#^zh-Q0722-answer|Compare the answer]]
^zh-Q0722

**zh-Q0723 · Edit the changed sentence**

仅太平洋的面积就【跟】所有的大陆的总和面积还要大。

The Pacific Ocean alone covers an area larger than that of all continents put together.

[[Mandarin Chinese#^zh-Q0723-answer|Compare the answer]]
^zh-Q0723

**zh-Q0724 · Build the sentence**

Arrange: 比 / 所有的大陆的总和面积还要大。 / 仅太平洋的面积就

The Pacific Ocean alone covers an area larger than that of all continents put together.

[[Mandarin Chinese#^zh-Q0724-answer|Compare the answer]]
^zh-Q0724

**zh-Q0725 · Write a translation**

Write this in Mandarin Chinese: English is spoken by more people than any other language.

[[Mandarin Chinese#^zh-Q0725-answer|Compare the answer]]
^zh-Q0725

**zh-Q0726 · Explain the grammar**

說英語的人【比】說任何其他語言的人多。

English is spoken by more people than any other language.

[[Mandarin Chinese#^zh-Q0726-answer|Compare the answer]]
^zh-Q0726

**zh-Q0727 · Fill the gap**

她没有____她妈妈更漂亮。

She's not prettier than her mother.

[[Mandarin Chinese#^zh-Q0727-answer|Compare the answer]]
^zh-Q0727

**zh-Q0728 · Choose the form**

她没有____她妈妈更漂亮。

She's not prettier than her mother.

Choices: 跟 / 和 / 比

[[Mandarin Chinese#^zh-Q0728-answer|Compare the answer]]
^zh-Q0728

**zh-Q0729 · Edit the changed sentence**

我喜歡住在科【跟】的郊區。

I'd like to live in the suburbs of Kobe.

[[Mandarin Chinese#^zh-Q0729-answer|Compare the answer]]
^zh-Q0729

**zh-Q0730 · Build the sentence**

Arrange: 我喜歡住在科 / 的郊區。 / 比

I'd like to live in the suburbs of Kobe.

[[Mandarin Chinese#^zh-Q0730-answer|Compare the answer]]
^zh-Q0730

**zh-Q0731 · Write a translation**

Write this in Mandarin Chinese: I prefer cakes or candies to alcohol, but I do drink.

[[Mandarin Chinese#^zh-Q0731-answer|Compare the answer]]
^zh-Q0731

**zh-Q0732 · Explain the grammar**

【比】起酒來，我比較喜歡蛋糕、糖果，可是酒我也不是完全不喝的。

I prefer cakes or candies to alcohol, but I do drink.

[[Mandarin Chinese#^zh-Q0732-answer|Compare the answer]]
^zh-Q0732

**zh-Q0733 · Fill the gap**

中文____其它外語難多了。

Chinese is much more difficult than other foreign languages.

[[Mandarin Chinese#^zh-Q0733-answer|Compare the answer]]
^zh-Q0733

**zh-Q0734 · Choose the form**

中文____其它外語難多了。

Chinese is much more difficult than other foreign languages.

Choices: 和 / 跟 / 比

[[Mandarin Chinese#^zh-Q0734-answer|Compare the answer]]
^zh-Q0734

**zh-Q0735 · Edit the changed sentence**

笔记本电脑【跟】台式电脑好。

A laptop is better than a desktop.

[[Mandarin Chinese#^zh-Q0735-answer|Compare the answer]]
^zh-Q0735

**zh-Q0736 · Build the sentence**

Arrange: 笔记本电脑 / 台式电脑好。 / 比

A laptop is better than a desktop.

[[Mandarin Chinese#^zh-Q0736-answer|Compare the answer]]
^zh-Q0736

**zh-Q0737 · Write a translation**

Write this in Mandarin Chinese: He is sure of winning the game.

[[Mandarin Chinese#^zh-Q0737-answer|Compare the answer]]
^zh-Q0737

**zh-Q0738 · Explain the grammar**

他很有信心贏這場【比】賽。

He is sure of winning the game.

[[Mandarin Chinese#^zh-Q0738-answer|Compare the answer]]
^zh-Q0738

**zh-Q0739 · Fill the gap**

____爾一如往常上學遲到。

Bill was late for school as usual.

[[Mandarin Chinese#^zh-Q0739-answer|Compare the answer]]
^zh-Q0739

**zh-Q0740 · Choose the form**

____爾一如往常上學遲到。

Bill was late for school as usual.

Choices: 比 / 和 / 跟

[[Mandarin Chinese#^zh-Q0740-answer|Compare the answer]]
^zh-Q0740

**zh-Q0741 · Edit the changed sentence**

湯姆跑得不如【跟】爾快。

Tom doesn't run as fast as Bill.

[[Mandarin Chinese#^zh-Q0741-answer|Compare the answer]]
^zh-Q0741

**zh-Q0742 · Build the sentence**

Arrange: 爾快。 / 湯姆跑得不如 / 比

Tom doesn't run as fast as Bill.

[[Mandarin Chinese#^zh-Q0742-answer|Compare the answer]]
^zh-Q0742

**zh-Q0743 · Write a translation**

Write this in Mandarin Chinese: I have the complete works of Shakespeare.

[[Mandarin Chinese#^zh-Q0743-answer|Compare the answer]]
^zh-Q0743

**zh-Q0744 · Explain the grammar**

我有莎士【比】亞的作品全集。

I have the complete works of Shakespeare.

[[Mandarin Chinese#^zh-Q0744-answer|Compare the answer]]
^zh-Q0744

**zh-Q0745 · Fill the gap**

相____第二本，我更喜欢汤姆的第一本书。

I liked Tom's first book more than the second.

[[Mandarin Chinese#^zh-Q0745-answer|Compare the answer]]
^zh-Q0745

**zh-Q0746 · Choose the form**

相____第二本，我更喜欢汤姆的第一本书。

I liked Tom's first book more than the second.

Choices: 和 / 跟 / 比

[[Mandarin Chinese#^zh-Q0746-answer|Compare the answer]]
^zh-Q0746

**zh-Q0747 · Edit the changed sentence**

上大學的時候，你得到的【跟】付出的還多。

You gain more than you spend when you go to college.

[[Mandarin Chinese#^zh-Q0747-answer|Compare the answer]]
^zh-Q0747

**zh-Q0748 · Build the sentence**

Arrange: 付出的還多。 / 比 / 上大學的時候，你得到的

You gain more than you spend when you go to college.

[[Mandarin Chinese#^zh-Q0748-answer|Compare the answer]]
^zh-Q0748

**zh-Q0749 · Write a translation**

Write this in Mandarin Chinese: Man differs from animals in that he can speak and think.

[[Mandarin Chinese#^zh-Q0749-answer|Compare the answer]]
^zh-Q0749

**zh-Q0750 · Explain the grammar**

人【比】动物会讲话和想。

Man differs from animals in that he can speak and think.

[[Mandarin Chinese#^zh-Q0750-answer|Compare the answer]]
^zh-Q0750


### Question particles · 50 questions

**zh-Q0751 · Fill the gap**

抱歉，你能再说一遍____？

I'm sorry, could you say that again?

[[Mandarin Chinese#^zh-Q0751-answer|Compare the answer]]
^zh-Q0751

**zh-Q0752 · Choose the form**

抱歉，你能再说一遍____？

I'm sorry, could you say that again?

Choices: 吧 / 呢 / 吗

[[Mandarin Chinese#^zh-Q0752-answer|Compare the answer]]
^zh-Q0752

**zh-Q0753 · Edit the changed sentence**

您想知道为什么我要离开【呢】？

Do you want to know why I quit?

[[Mandarin Chinese#^zh-Q0753-answer|Compare the answer]]
^zh-Q0753

**zh-Q0754 · Build the sentence**

Arrange: 吗 / 您想知道为什么我要离开 / ？

Do you want to know why I quit?

[[Mandarin Chinese#^zh-Q0754-answer|Compare the answer]]
^zh-Q0754

**zh-Q0755 · Write a translation**

Write this in Mandarin Chinese: Can I enter a sentence in French?

[[Mandarin Chinese#^zh-Q0755-answer|Compare the answer]]
^zh-Q0755

**zh-Q0756 · Explain the grammar**

我能用法语加一句句子【吗】？

Can I enter a sentence in French?

[[Mandarin Chinese#^zh-Q0756-answer|Compare the answer]]
^zh-Q0756

**zh-Q0757 · Fill the gap**

我还什么都没找到____。

I still haven't found anything.

[[Mandarin Chinese#^zh-Q0757-answer|Compare the answer]]
^zh-Q0757

**zh-Q0758 · Choose the form**

我还什么都没找到____。

I still haven't found anything.

Choices: 吧 / 吗 / 呢

[[Mandarin Chinese#^zh-Q0758-answer|Compare the answer]]
^zh-Q0758

**zh-Q0759 · Edit the changed sentence**

我还以为我在做梦【吗】。

I thought I was dreaming.

[[Mandarin Chinese#^zh-Q0759-answer|Compare the answer]]
^zh-Q0759

**zh-Q0760 · Build the sentence**

Arrange: 。 / 呢 / 我还以为我在做梦

I thought I was dreaming.

[[Mandarin Chinese#^zh-Q0760-answer|Compare the answer]]
^zh-Q0760

**zh-Q0761 · Write a translation**

Write this in Mandarin Chinese: Are we going out for lunch today?

[[Mandarin Chinese#^zh-Q0761-answer|Compare the answer]]
^zh-Q0761

**zh-Q0762 · Explain the grammar**

今天中午我们出去吃饭【吗】？

Are we going out for lunch today?

[[Mandarin Chinese#^zh-Q0762-answer|Compare the answer]]
^zh-Q0762

**zh-Q0763 · Fill the gap**

世界上是不是真的有鬼____？

Do ghosts really exist?

[[Mandarin Chinese#^zh-Q0763-answer|Compare the answer]]
^zh-Q0763

**zh-Q0764 · Choose the form**

世界上是不是真的有鬼____？

Do ghosts really exist?

Choices: 呢 / 吧 / 吗

[[Mandarin Chinese#^zh-Q0764-answer|Compare the answer]]
^zh-Q0764

**zh-Q0765 · Edit the changed sentence**

你放假打算去甚麼地方玩【吗】？

Where are you going to go on your vacation?

[[Mandarin Chinese#^zh-Q0765-answer|Compare the answer]]
^zh-Q0765

**zh-Q0766 · Build the sentence**

Arrange: 呢 / ？ / 你放假打算去甚麼地方玩

Where are you going to go on your vacation?

[[Mandarin Chinese#^zh-Q0766-answer|Compare the answer]]
^zh-Q0766

**zh-Q0767 · Write a translation**

Write this in Mandarin Chinese: Is there anything I can do?

[[Mandarin Chinese#^zh-Q0767-answer|Compare the answer]]
^zh-Q0767

**zh-Q0768 · Explain the grammar**

有什么事我可以做【吗】？

Is there anything I can do?

[[Mandarin Chinese#^zh-Q0768-answer|Compare the answer]]
^zh-Q0768

**zh-Q0769 · Fill the gap**

你能告诉我红茶和绿茶的区别____？

Can you describe to me the difference between black tea and green tea?

[[Mandarin Chinese#^zh-Q0769-answer|Compare the answer]]
^zh-Q0769

**zh-Q0770 · Choose the form**

你能告诉我红茶和绿茶的区别____？

Can you describe to me the difference between black tea and green tea?

Choices: 吗 / 呢 / 吧

[[Mandarin Chinese#^zh-Q0770-answer|Compare the answer]]
^zh-Q0770

**zh-Q0771 · Edit the changed sentence**

假如你有1000美元，你会用它做什么【吗】？

Suppose you had a thousand dollars, what would you do with it?

[[Mandarin Chinese#^zh-Q0771-answer|Compare the answer]]
^zh-Q0771

**zh-Q0772 · Build the sentence**

Arrange: ？ / 假如你有1000美元，你会用它做什么 / 呢

Suppose you had a thousand dollars, what would you do with it?

[[Mandarin Chinese#^zh-Q0772-answer|Compare the answer]]
^zh-Q0772

**zh-Q0773 · Write a translation**

Write this in Mandarin Chinese: Can't you reach the book on the shelf?

[[Mandarin Chinese#^zh-Q0773-answer|Compare the answer]]
^zh-Q0773

**zh-Q0774 · Explain the grammar**

你能拿到架子上的书【吗】？

Can't you reach the book on the shelf?

[[Mandarin Chinese#^zh-Q0774-answer|Compare the answer]]
^zh-Q0774

**zh-Q0775 · Fill the gap**

事情真的已经了结了____？

Is it really all over?

[[Mandarin Chinese#^zh-Q0775-answer|Compare the answer]]
^zh-Q0775

**zh-Q0776 · Choose the form**

事情真的已经了结了____？

Is it really all over?

Choices: 吧 / 吗 / 呢

[[Mandarin Chinese#^zh-Q0776-answer|Compare the answer]]
^zh-Q0776

**zh-Q0777 · Edit the changed sentence**

这个我们明天能解决【呢】？

Can we take care of this tomorrow?

[[Mandarin Chinese#^zh-Q0777-answer|Compare the answer]]
^zh-Q0777

**zh-Q0778 · Build the sentence**

Arrange: 吗 / 这个我们明天能解决 / ？

Can we take care of this tomorrow?

[[Mandarin Chinese#^zh-Q0778-answer|Compare the answer]]
^zh-Q0778

**zh-Q0779 · Write a translation**

Write this in Mandarin Chinese: But where do we get those sentences? And how do we translate them?

[[Mandarin Chinese#^zh-Q0779-answer|Compare the answer]]
^zh-Q0779

**zh-Q0780 · Explain the grammar**

但我们从哪儿弄到那些句子？我们又要如何翻译【呢】？

But where do we get those sentences? And how do we translate them?

[[Mandarin Chinese#^zh-Q0780-answer|Compare the answer]]
^zh-Q0780

**zh-Q0781 · Fill the gap**

你知道去哪找汤姆____？

Do you know where to find Tom?

[[Mandarin Chinese#^zh-Q0781-answer|Compare the answer]]
^zh-Q0781

**zh-Q0782 · Choose the form**

你知道去哪找汤姆____？

Do you know where to find Tom?

Choices: 呢 / 吗 / 吧

[[Mandarin Chinese#^zh-Q0782-answer|Compare the answer]]
^zh-Q0782

**zh-Q0783 · Edit the changed sentence**

这个面包的保质期可以【呢】？

Is this bread's best-by OK?

[[Mandarin Chinese#^zh-Q0783-answer|Compare the answer]]
^zh-Q0783

**zh-Q0784 · Build the sentence**

Arrange: 这个面包的保质期可以 / ？ / 吗

Is this bread's best-by OK?

[[Mandarin Chinese#^zh-Q0784-answer|Compare the answer]]
^zh-Q0784

**zh-Q0785 · Write a translation**

Write this in Mandarin Chinese: Could you stop saying that?

[[Mandarin Chinese#^zh-Q0785-answer|Compare the answer]]
^zh-Q0785

**zh-Q0786 · Explain the grammar**

你能不说那个了【吗】？

Could you stop saying that?

[[Mandarin Chinese#^zh-Q0786-answer|Compare the answer]]
^zh-Q0786

**zh-Q0787 · Fill the gap**

告诉她我在法国____。

Tell her that I am in France.

[[Mandarin Chinese#^zh-Q0787-answer|Compare the answer]]
^zh-Q0787

**zh-Q0788 · Choose the form**

告诉她我在法国____。

Tell her that I am in France.

Choices: 呢 / 吧 / 吗

[[Mandarin Chinese#^zh-Q0788-answer|Compare the answer]]
^zh-Q0788

**zh-Q0789 · Edit the changed sentence**

你是不是有能力做到你想要完成的所有事情【吗】？

Were you able to do everything you wanted to get done?

[[Mandarin Chinese#^zh-Q0789-answer|Compare the answer]]
^zh-Q0789

**zh-Q0790 · Build the sentence**

Arrange: ？ / 你是不是有能力做到你想要完成的所有事情 / 呢

Were you able to do everything you wanted to get done?

[[Mandarin Chinese#^zh-Q0790-answer|Compare the answer]]
^zh-Q0790

**zh-Q0791 · Write a translation**

Write this in Mandarin Chinese: Do you know anything about Tom's parents?

[[Mandarin Chinese#^zh-Q0791-answer|Compare the answer]]
^zh-Q0791

**zh-Q0792 · Explain the grammar**

你知道任何关于汤姆父母的事【吗】？

Do you know anything about Tom's parents?

[[Mandarin Chinese#^zh-Q0792-answer|Compare the answer]]
^zh-Q0792

**zh-Q0793 · Fill the gap**

社会保障____？他们在说什么笑话？

Social security? Who do they think they're kidding.

[[Mandarin Chinese#^zh-Q0793-answer|Compare the answer]]
^zh-Q0793

**zh-Q0794 · Choose the form**

社会保障____？他们在说什么笑话？

Social security? Who do they think they're kidding.

Choices: 吧 / 呢 / 吗

[[Mandarin Chinese#^zh-Q0794-answer|Compare the answer]]
^zh-Q0794

**zh-Q0795 · Edit the changed sentence**

所有人都去哪儿了？有集市【呢】？

Where are all the people going? Is there a fair?

[[Mandarin Chinese#^zh-Q0795-answer|Compare the answer]]
^zh-Q0795

**zh-Q0796 · Build the sentence**

Arrange: ？ / 所有人都去哪儿了？有集市 / 吗

Where are all the people going? Is there a fair?

[[Mandarin Chinese#^zh-Q0796-answer|Compare the answer]]
^zh-Q0796

**zh-Q0797 · Write a translation**

Write this in Mandarin Chinese: Excuse me, could you pass me the sugar?

[[Mandarin Chinese#^zh-Q0797-answer|Compare the answer]]
^zh-Q0797

**zh-Q0798 · Explain the grammar**

打扰一下，你能把糖递给我【吗】？

Excuse me, could you pass me the sugar?

[[Mandarin Chinese#^zh-Q0798-answer|Compare the answer]]
^zh-Q0798

**zh-Q0799 · Fill the gap**

那是你昨天买的毛衣____？

Is that the sweater you bought yesterday?

[[Mandarin Chinese#^zh-Q0799-answer|Compare the answer]]
^zh-Q0799

**zh-Q0800 · Choose the form**

那是你昨天买的毛衣____？

Is that the sweater you bought yesterday?

Choices: 呢 / 吧 / 吗

[[Mandarin Chinese#^zh-Q0800-answer|Compare the answer]]
^zh-Q0800


### Question words · 50 questions

**zh-Q0801 · Edit the changed sentence**

你【什么】为我担忧？

Why are you worried about me?

[[Mandarin Chinese#^zh-Q0801-answer|Compare the answer]]
^zh-Q0801

**zh-Q0802 · Build the sentence**

Arrange: 为我担忧？ / 你 / 为什么

Why are you worried about me?

[[Mandarin Chinese#^zh-Q0802-answer|Compare the answer]]
^zh-Q0802

**zh-Q0803 · Write a translation**

Write this in Mandarin Chinese: What do you think should be done about it?

[[Mandarin Chinese#^zh-Q0803-answer|Compare the answer]]
^zh-Q0803

**zh-Q0804 · Explain the grammar**

你觉得对此该做【什么】？

What do you think should be done about it?

[[Mandarin Chinese#^zh-Q0804-answer|Compare the answer]]
^zh-Q0804

**zh-Q0805 · Fill the gap**

告诉我____玩游戏。

Tell me how to play the game.

[[Mandarin Chinese#^zh-Q0805-answer|Compare the answer]]
^zh-Q0805

**zh-Q0806 · Choose the form**

告诉我____玩游戏。

Tell me how to play the game.

Choices: 谁 / 什么 / 怎么 / 哪里

[[Mandarin Chinese#^zh-Q0806-answer|Compare the answer]]
^zh-Q0806

**zh-Q0807 · Edit the changed sentence**

最近的電話亭在【什么】裡？

Where is the nearest telephone box?

[[Mandarin Chinese#^zh-Q0807-answer|Compare the answer]]
^zh-Q0807

**zh-Q0808 · Build the sentence**

Arrange: 裡？ / 最近的電話亭在 / 哪

Where is the nearest telephone box?

[[Mandarin Chinese#^zh-Q0808-answer|Compare the answer]]
^zh-Q0808

**zh-Q0809 · Write a translation**

Write this in Mandarin Chinese: Let's go to the field and fly kites, what do you say?

[[Mandarin Chinese#^zh-Q0809-answer|Compare the answer]]
^zh-Q0809

**zh-Q0810 · Explain the grammar**

咱们到田园去放风筝【怎么】样？

Let's go to the field and fly kites, what do you say?

[[Mandarin Chinese#^zh-Q0810-answer|Compare the answer]]
^zh-Q0810

**zh-Q0811 · Fill the gap**

在埃及说____语言？

What language is spoken in Egypt?

[[Mandarin Chinese#^zh-Q0811-answer|Compare the answer]]
^zh-Q0811

**zh-Q0812 · Choose the form**

在埃及说____语言？

What language is spoken in Egypt?

Choices: 哪里 / 谁 / 怎么 / 什么

[[Mandarin Chinese#^zh-Q0812-answer|Compare the answer]]
^zh-Q0812

**zh-Q0813 · Edit the changed sentence**

你【谁】时候开始工作?

What time do you start work?

[[Mandarin Chinese#^zh-Q0813-answer|Compare the answer]]
^zh-Q0813

**zh-Q0814 · Build the sentence**

Arrange: 什么 / 时候开始工作? / 你

What time do you start work?

[[Mandarin Chinese#^zh-Q0814-answer|Compare the answer]]
^zh-Q0814

**zh-Q0815 · Write a translation**

Write this in Mandarin Chinese: How does she bring up her children?

[[Mandarin Chinese#^zh-Q0815-answer|Compare the answer]]
^zh-Q0815

**zh-Q0816 · Explain the grammar**

她是【怎么】抚养孩子的？

How does she bring up her children?

[[Mandarin Chinese#^zh-Q0816-answer|Compare the answer]]
^zh-Q0816

**zh-Q0817 · Fill the gap**

他似乎____都知道。

It seems to have that he knows everything.

[[Mandarin Chinese#^zh-Q0817-answer|Compare the answer]]
^zh-Q0817

**zh-Q0818 · Choose the form**

他似乎____都知道。

It seems to have that he knows everything.

Choices: 哪里 / 什么 / 谁 / 怎么

[[Mandarin Chinese#^zh-Q0818-answer|Compare the answer]]
^zh-Q0818

**zh-Q0819 · Edit the changed sentence**

你的电脑有【谁】问题？

What's the problem with your computer?

[[Mandarin Chinese#^zh-Q0819-answer|Compare the answer]]
^zh-Q0819

**zh-Q0820 · Build the sentence**

Arrange: 什么 / 问题？ / 你的电脑有

What's the problem with your computer?

[[Mandarin Chinese#^zh-Q0820-answer|Compare the answer]]
^zh-Q0820

**zh-Q0821 · Write a translation**

Write this in Mandarin Chinese: Who is your favorite composer?

[[Mandarin Chinese#^zh-Q0821-answer|Compare the answer]]
^zh-Q0821

**zh-Q0822 · Explain the grammar**

你最喜歡【哪】一個作曲家？

Who is your favorite composer?

[[Mandarin Chinese#^zh-Q0822-answer|Compare the answer]]
^zh-Q0822

**zh-Q0823 · Fill the gap**

汤姆说他不确定玛丽想做____。

Tom said he wasn't sure what Mary wanted to do.

[[Mandarin Chinese#^zh-Q0823-answer|Compare the answer]]
^zh-Q0823

**zh-Q0824 · Choose the form**

汤姆说他不确定玛丽想做____。

Tom said he wasn't sure what Mary wanted to do.

Choices: 哪里 / 怎么 / 什么 / 谁

[[Mandarin Chinese#^zh-Q0824-answer|Compare the answer]]
^zh-Q0824

**zh-Q0825 · Edit the changed sentence**

他跟你说【谁】，你就做什么。

Do whatever he tells you.

[[Mandarin Chinese#^zh-Q0825-answer|Compare the answer]]
^zh-Q0825

**zh-Q0826 · Build the sentence**

Arrange: 什么 / ，你就做什么。 / 他跟你说

Do whatever he tells you.

[[Mandarin Chinese#^zh-Q0826-answer|Compare the answer]]
^zh-Q0826

**zh-Q0827 · Write a translation**

Write this in Mandarin Chinese: What exactly are you doing?

[[Mandarin Chinese#^zh-Q0827-answer|Compare the answer]]
^zh-Q0827

**zh-Q0828 · Explain the grammar**

你到底在这做【什么】？

What exactly are you doing?

[[Mandarin Chinese#^zh-Q0828-answer|Compare the answer]]
^zh-Q0828

**zh-Q0829 · Fill the gap**

我不知道现在应该做____。

I don't know what I should do now.

[[Mandarin Chinese#^zh-Q0829-answer|Compare the answer]]
^zh-Q0829

**zh-Q0830 · Choose the form**

我不知道现在应该做____。

I don't know what I should do now.

Choices: 哪里 / 什么 / 谁 / 怎么

[[Mandarin Chinese#^zh-Q0830-answer|Compare the answer]]
^zh-Q0830

**zh-Q0831 · Edit the changed sentence**

【什么】你企图逃走？

Why did you try to run away?

[[Mandarin Chinese#^zh-Q0831-answer|Compare the answer]]
^zh-Q0831

**zh-Q0832 · Build the sentence**

Arrange: 你企图逃走？ / 为什么

Why did you try to run away?

[[Mandarin Chinese#^zh-Q0832-answer|Compare the answer]]
^zh-Q0832

**zh-Q0833 · Write a translation**

Write this in Mandarin Chinese: We can't choose where we come from, but we can choose where we go from there.

[[Mandarin Chinese#^zh-Q0833-answer|Compare the answer]]
^zh-Q0833

**zh-Q0834 · Explain the grammar**

我们不能选择从【哪】里来，却能选择往哪里去。

We can't choose where we come from, but we can choose where we go from there.

[[Mandarin Chinese#^zh-Q0834-answer|Compare the answer]]
^zh-Q0834

**zh-Q0835 · Fill the gap**

最大可能假想事故____时候会发生？

When will the most probable hypothetical accident occur?

[[Mandarin Chinese#^zh-Q0835-answer|Compare the answer]]
^zh-Q0835

**zh-Q0836 · Choose the form**

最大可能假想事故____时候会发生？

When will the most probable hypothetical accident occur?

Choices: 哪里 / 谁 / 怎么 / 什么

[[Mandarin Chinese#^zh-Q0836-answer|Compare the answer]]
^zh-Q0836

**zh-Q0837 · Edit the changed sentence**

不管我跟她说了【什么】次，她还是继续犯同样的错误。

No matter how often I tell her, she keeps making the same mistake.

[[Mandarin Chinese#^zh-Q0837-answer|Compare the answer]]
^zh-Q0837

**zh-Q0838 · Build the sentence**

Arrange: 多少 / 次，她还是继续犯同样的错误。 / 不管我跟她说了

No matter how often I tell her, she keeps making the same mistake.

[[Mandarin Chinese#^zh-Q0838-answer|Compare the answer]]
^zh-Q0838

**zh-Q0839 · Write a translation**

Write this in Mandarin Chinese: How do you relieve stress?

[[Mandarin Chinese#^zh-Q0839-answer|Compare the answer]]
^zh-Q0839

**zh-Q0840 · Explain the grammar**

你用【什么】方式减压？

How do you relieve stress?

[[Mandarin Chinese#^zh-Q0840-answer|Compare the answer]]
^zh-Q0840

**zh-Q0841 · Fill the gap**

我不知道该说____。

I don't know what to say.

[[Mandarin Chinese#^zh-Q0841-answer|Compare the answer]]
^zh-Q0841

**zh-Q0842 · Choose the form**

我不知道该说____。

I don't know what to say.

Choices: 怎么 / 谁 / 哪里 / 什么

[[Mandarin Chinese#^zh-Q0842-answer|Compare the answer]]
^zh-Q0842

**zh-Q0843 · Edit the changed sentence**

我不懂你在说【谁】。

I don't understand what you are saying.

[[Mandarin Chinese#^zh-Q0843-answer|Compare the answer]]
^zh-Q0843

**zh-Q0844 · Build the sentence**

Arrange: 我不懂你在说 / 。 / 什么

I don't understand what you are saying.

[[Mandarin Chinese#^zh-Q0844-answer|Compare the answer]]
^zh-Q0844

**zh-Q0845 · Write a translation**

Write this in Mandarin Chinese: Don't get agitated. It's nothing.

[[Mandarin Chinese#^zh-Q0845-answer|Compare the answer]]
^zh-Q0845

**zh-Q0846 · Explain the grammar**

别慌。这没【什么】的。

Don't get agitated. It's nothing.

[[Mandarin Chinese#^zh-Q0846-answer|Compare the answer]]
^zh-Q0846

**zh-Q0847 · Fill the gap**

选择____是“对”或“错”是一项艰难的任务，我们却必须要完成它。

It is a difficult task, choosing what is "right" or "wrong", but you have to do it.

[[Mandarin Chinese#^zh-Q0847-answer|Compare the answer]]
^zh-Q0847

**zh-Q0848 · Choose the form**

选择____是“对”或“错”是一项艰难的任务，我们却必须要完成它。

It is a difficult task, choosing what is "right" or "wrong", but you have to do it.

Choices: 怎么 / 谁 / 什么 / 哪里

[[Mandarin Chinese#^zh-Q0848-answer|Compare the answer]]
^zh-Q0848

**zh-Q0849 · Edit the changed sentence**

湯姆不能決定從【什么】裡開始。

Tom couldn't decide where to begin.

[[Mandarin Chinese#^zh-Q0849-answer|Compare the answer]]
^zh-Q0849

**zh-Q0850 · Build the sentence**

Arrange: 哪 / 湯姆不能決定從 / 裡開始。

Tom couldn't decide where to begin.

[[Mandarin Chinese#^zh-Q0850-answer|Compare the answer]]
^zh-Q0850


### Conditions and concession · 50 questions

**zh-Q0851 · Write a translation**

Write this in Mandarin Chinese: Even though it sounds strange, what she said is true.

[[Mandarin Chinese#^zh-Q0851-answer|Compare the answer]]
^zh-Q0851

**zh-Q0852 · Explain the grammar**

【虽然】听起来很奇怪，但是她说的的确是真的。

Even though it sounds strange, what she said is true.

[[Mandarin Chinese#^zh-Q0852-answer|Compare the answer]]
^zh-Q0852

**zh-Q0853 · Fill the gap**

____你想使他人相信你的话，那就只说他已经相信的东西吧。

If you want to be credible, tell people only what they believe.

[[Mandarin Chinese#^zh-Q0853-answer|Compare the answer]]
^zh-Q0853

**zh-Q0854 · Choose the form**

____你想使他人相信你的话，那就只说他已经相信的东西吧。

If you want to be credible, tell people only what they believe.

Choices: 如果 / 但是 / 要是 / 虽然

[[Mandarin Chinese#^zh-Q0854-answer|Compare the answer]]
^zh-Q0854

**zh-Q0855 · Edit the changed sentence**

根据你所说【如果】，我认为我们应该重新审视我们的计划。

In the light of what you told us, I think we should revise our plan.

[[Mandarin Chinese#^zh-Q0855-answer|Compare the answer]]
^zh-Q0855

**zh-Q0856 · Build the sentence**

Arrange: ，我认为我们应该重新审视我们的计划。 / 的话 / 根据你所说

In the light of what you told us, I think we should revise our plan.

[[Mandarin Chinese#^zh-Q0856-answer|Compare the answer]]
^zh-Q0856

**zh-Q0857 · Write a translation**

Write this in Mandarin Chinese: You may come if you like.

[[Mandarin Chinese#^zh-Q0857-answer|Compare the answer]]
^zh-Q0857

**zh-Q0858 · Explain the grammar**

【如果】你想，你可以來。

You may come if you like.

[[Mandarin Chinese#^zh-Q0858-answer|Compare the answer]]
^zh-Q0858

**zh-Q0859 · Fill the gap**

____發生了甚麼事，馬上打電話給我。

In case anything happens, call me immediately.

[[Mandarin Chinese#^zh-Q0859-answer|Compare the answer]]
^zh-Q0859

**zh-Q0860 · Choose the form**

____發生了甚麼事，馬上打電話給我。

In case anything happens, call me immediately.

Choices: 但是 / 虽然 / 要是 / 如果

[[Mandarin Chinese#^zh-Q0860-answer|Compare the answer]]
^zh-Q0860

**zh-Q0861 · Edit the changed sentence**

【虽然】明天下雨，我们就坐车去那儿。

If it's raining tomorrow, then we'll go there in the car.

[[Mandarin Chinese#^zh-Q0861-answer|Compare the answer]]
^zh-Q0861

**zh-Q0862 · Build the sentence**

Arrange: 明天下雨，我们就坐车去那儿。 / 如果

If it's raining tomorrow, then we'll go there in the car.

[[Mandarin Chinese#^zh-Q0862-answer|Compare the answer]]
^zh-Q0862

**zh-Q0863 · Write a translation**

Write this in Mandarin Chinese: If the weather is nice tomorrow, we will have a picnic.

[[Mandarin Chinese#^zh-Q0863-answer|Compare the answer]]
^zh-Q0863

**zh-Q0864 · Explain the grammar**

【如果】明天天氣好，我們就去野餐。

If the weather is nice tomorrow, we will have a picnic.

[[Mandarin Chinese#^zh-Q0864-answer|Compare the answer]]
^zh-Q0864

**zh-Q0865 · Fill the gap**

____你想考試合格的話，就要努力溫習了。

You'll have to work hard if you want to pass the exam.

[[Mandarin Chinese#^zh-Q0865-answer|Compare the answer]]
^zh-Q0865

**zh-Q0866 · Choose the form**

____你想考試合格的話，就要努力溫習了。

You'll have to work hard if you want to pass the exam.

Choices: 但是 / 虽然 / 如果 / 要是

[[Mandarin Chinese#^zh-Q0866-answer|Compare the answer]]
^zh-Q0866

**zh-Q0867 · Edit the changed sentence**

你【虽然】有疑问，就问汤姆吧。

Ask Tom if you have any doubt.

[[Mandarin Chinese#^zh-Q0867-answer|Compare the answer]]
^zh-Q0867

**zh-Q0868 · Build the sentence**

Arrange: 有疑问，就问汤姆吧。 / 你 / 如果

Ask Tom if you have any doubt.

[[Mandarin Chinese#^zh-Q0868-answer|Compare the answer]]
^zh-Q0868

**zh-Q0869 · Write a translation**

Write this in Mandarin Chinese: Tom didn't need to stay if he didn't want to.

[[Mandarin Chinese#^zh-Q0869-answer|Compare the answer]]
^zh-Q0869

**zh-Q0870 · Explain the grammar**

汤姆不想【的话】他是没必要留下的。

Tom didn't need to stay if he didn't want to.

[[Mandarin Chinese#^zh-Q0870-answer|Compare the answer]]
^zh-Q0870

**zh-Q0871 · Fill the gap**

____我知道的话，我早就已经告诉你了。

Had I known about it, I would have told you.

[[Mandarin Chinese#^zh-Q0871-answer|Compare the answer]]
^zh-Q0871

**zh-Q0872 · Choose the form**

____我知道的话，我早就已经告诉你了。

Had I known about it, I would have told you.

Choices: 如果 / 要是 / 但是 / 虽然

[[Mandarin Chinese#^zh-Q0872-answer|Compare the answer]]
^zh-Q0872

**zh-Q0873 · Edit the changed sentence**

【虽然】你想去，就去好了。如果你不想去，那也没什么大不了的。

If you want to go, then go. If you don't want to, then it's no big deal.

[[Mandarin Chinese#^zh-Q0873-answer|Compare the answer]]
^zh-Q0873

**zh-Q0874 · Build the sentence**

Arrange: 你想去，就去好了。如果你不想去，那也没什么大不了的。 / 如果

If you want to go, then go. If you don't want to, then it's no big deal.

[[Mandarin Chinese#^zh-Q0874-answer|Compare the answer]]
^zh-Q0874

**zh-Q0875 · Write a translation**

Write this in Mandarin Chinese: I know that downloading music from the internet without paying is wrong, but I do it anyway.

[[Mandarin Chinese#^zh-Q0875-answer|Compare the answer]]
^zh-Q0875

**zh-Q0876 · Explain the grammar**

【虽然】我知道从网上免费下载音乐是不对的，但我还是照样下载。

I know that downloading music from the internet without paying is wrong, but I do it anyway.

[[Mandarin Chinese#^zh-Q0876-answer|Compare the answer]]
^zh-Q0876

**zh-Q0877 · Fill the gap**

____你尝试的话，你会成功的。

You'll succeed if you try.

[[Mandarin Chinese#^zh-Q0877-answer|Compare the answer]]
^zh-Q0877

**zh-Q0878 · Choose the form**

____你尝试的话，你会成功的。

You'll succeed if you try.

Choices: 要是 / 如果 / 但是 / 虽然

[[Mandarin Chinese#^zh-Q0878-answer|Compare the answer]]
^zh-Q0878

**zh-Q0879 · Edit the changed sentence**

【虽然】你认真学习，就有希望通过考试。

If you study earnestly, you can expect to pass the exam.

[[Mandarin Chinese#^zh-Q0879-answer|Compare the answer]]
^zh-Q0879

**zh-Q0880 · Build the sentence**

Arrange: 你认真学习，就有希望通过考试。 / 如果

If you study earnestly, you can expect to pass the exam.

[[Mandarin Chinese#^zh-Q0880-answer|Compare the answer]]
^zh-Q0880

**zh-Q0881 · Write a translation**

Write this in Mandarin Chinese: You can use my car if you like.

[[Mandarin Chinese#^zh-Q0881-answer|Compare the answer]]
^zh-Q0881

**zh-Q0882 · Explain the grammar**

【如果】你喜歡你可以用我的車。

You can use my car if you like.

[[Mandarin Chinese#^zh-Q0882-answer|Compare the answer]]
^zh-Q0882

**zh-Q0883 · Fill the gap**

搞这狗屁玩意，我____老人家了。

I'm too old for that shit.

[[Mandarin Chinese#^zh-Q0883-answer|Compare the answer]]
^zh-Q0883

**zh-Q0884 · Choose the form**

搞这狗屁玩意，我____老人家了。

I'm too old for that shit.

Choices: 虽然 / 可是 / 但是 / 如果

[[Mandarin Chinese#^zh-Q0884-answer|Compare the answer]]
^zh-Q0884

**zh-Q0885 · Edit the changed sentence**

他把她【如果】当作是一种赞美。

He took her words as a compliment.

[[Mandarin Chinese#^zh-Q0885-answer|Compare the answer]]
^zh-Q0885

**zh-Q0886 · Build the sentence**

Arrange: 他把她 / 当作是一种赞美。 / 的话

He took her words as a compliment.

[[Mandarin Chinese#^zh-Q0886-answer|Compare the answer]]
^zh-Q0886

**zh-Q0887 · Write a translation**

Write this in Mandarin Chinese: If you take my advice, you'll see a doctor.

[[Mandarin Chinese#^zh-Q0887-answer|Compare the answer]]
^zh-Q0887

**zh-Q0888 · Explain the grammar**

你【要是】听我的意见就去看医生。

If you take my advice, you'll see a doctor.

[[Mandarin Chinese#^zh-Q0888-answer|Compare the answer]]
^zh-Q0888

**zh-Q0889 · Fill the gap**

____时髦一点，但是价钱太大！

It's kind of in vogue, but the price is too much!

[[Mandarin Chinese#^zh-Q0889-answer|Compare the answer]]
^zh-Q0889

**zh-Q0890 · Choose the form**

____时髦一点，但是价钱太大！

It's kind of in vogue, but the price is too much!

Choices: 要是 / 虽然 / 如果 / 但是

[[Mandarin Chinese#^zh-Q0890-answer|Compare the answer]]
^zh-Q0890

**zh-Q0891 · Edit the changed sentence**

她佷美， 【如果】看起來不健康。

She is quite pretty, but looks unhealthy.

[[Mandarin Chinese#^zh-Q0891-answer|Compare the answer]]
^zh-Q0891

**zh-Q0892 · Build the sentence**

Arrange: 她佷美，  / 看起來不健康。 / 可是

She is quite pretty, but looks unhealthy.

[[Mandarin Chinese#^zh-Q0892-answer|Compare the answer]]
^zh-Q0892

**zh-Q0893 · Write a translation**

Write this in Mandarin Chinese: If there are 1000 steps between us, you only need to take one step, and I will take the other 999 to you.

[[Mandarin Chinese#^zh-Q0893-answer|Compare the answer]]
^zh-Q0893

**zh-Q0894 · Explain the grammar**

【如果】我們之間有1000步的距離，你只要跨出第1步，我就會朝著你的方向走其餘的999步。

If there are 1000 steps between us, you only need to take one step, and I will take the other 999 to you.

[[Mandarin Chinese#^zh-Q0894-answer|Compare the answer]]
^zh-Q0894

**zh-Q0895 · Fill the gap**

____我可以把英文字母重新排序，我會把「U」和「I」放在一起。

If I could rearrange the alphabet, I would put U and I together.

[[Mandarin Chinese#^zh-Q0895-answer|Compare the answer]]
^zh-Q0895

**zh-Q0896 · Choose the form**

____我可以把英文字母重新排序，我會把「U」和「I」放在一起。

If I could rearrange the alphabet, I would put U and I together.

Choices: 虽然 / 如果 / 但是 / 要是

[[Mandarin Chinese#^zh-Q0896-answer|Compare the answer]]
^zh-Q0896

**zh-Q0897 · Edit the changed sentence**

【虽然】我是你，我不会想去知道Tom现在正在做什么。

If I were you, I'd want to know what Tom is doing right now.

[[Mandarin Chinese#^zh-Q0897-answer|Compare the answer]]
^zh-Q0897

**zh-Q0898 · Build the sentence**

Arrange: 我是你，我不会想去知道Tom现在正在做什么。 / 如果

If I were you, I'd want to know what Tom is doing right now.

[[Mandarin Chinese#^zh-Q0898-answer|Compare the answer]]
^zh-Q0898

**zh-Q0899 · Write a translation**

Write this in Mandarin Chinese: I can speak Chinese, but I can't read it.

[[Mandarin Chinese#^zh-Q0899-answer|Compare the answer]]
^zh-Q0899

**zh-Q0900 · Explain the grammar**

我會說中文，【但是】我不會讀中文。

I can speak Chinese, but I can't read it.

[[Mandarin Chinese#^zh-Q0900-answer|Compare the answer]]
^zh-Q0900


### Cause and inference · 50 questions

**zh-Q0901 · Fill the gap**

你自己____知道吧。

You must know yourself.

[[Mandarin Chinese#^zh-Q0901-answer|Compare the answer]]
^zh-Q0901

**zh-Q0902 · Choose the form**

你自己____知道吧。

You must know yourself.

Choices: 所以 / 可能 / 因为 / 应该

[[Mandarin Chinese#^zh-Q0902-answer|Compare the answer]]
^zh-Q0902

**zh-Q0903 · Edit the changed sentence**

【所以】下雨了，球场上没有很多观众。

There weren't many spectators at the game because of the rain.

[[Mandarin Chinese#^zh-Q0903-answer|Compare the answer]]
^zh-Q0903

**zh-Q0904 · Build the sentence**

Arrange: 下雨了，球场上没有很多观众。 / 因为

There weren't many spectators at the game because of the rain.

[[Mandarin Chinese#^zh-Q0904-answer|Compare the answer]]
^zh-Q0904

**zh-Q0905 · Write a translation**

Write this in Mandarin Chinese: Her mom is from Spain and her dad is from Italy, that's why she can speak both Spanish and Italian.

[[Mandarin Chinese#^zh-Q0905-answer|Compare the answer]]
^zh-Q0905

**zh-Q0906 · Explain the grammar**

她妈妈来自西班牙，她爸爸来自意大利，【所以】她会讲西班牙语和意大利语。

Her mom is from Spain and her dad is from Italy, that's why she can speak both Spanish and Italian.

[[Mandarin Chinese#^zh-Q0906-answer|Compare the answer]]
^zh-Q0906

**zh-Q0907 · Fill the gap**

他本____成为一个律师。

He should have been a lawyer.

[[Mandarin Chinese#^zh-Q0907-answer|Compare the answer]]
^zh-Q0907

**zh-Q0908 · Choose the form**

他本____成为一个律师。

He should have been a lawyer.

Choices: 应该 / 所以 / 可能 / 因为

[[Mandarin Chinese#^zh-Q0908-answer|Compare the answer]]
^zh-Q0908

**zh-Q0909 · Edit the changed sentence**

【所以】有些公司对待雇员和顾客的态度可以随时影响它们的股价，所以對公司的成功或失敗不可避免地有巨大的影響。

For some companies their treatment of their employees or clients at any given time could affect their share prices and so inevitably have a great influence on the company’s success or failure.

[[Mandarin Chinese#^zh-Q0909-answer|Compare the answer]]
^zh-Q0909

**zh-Q0910 · Build the sentence**

Arrange: 有些公司对待雇员和顾客的态度可以随时影响它们的股价，所以對公司的成功或失敗不可避免地有巨大的影響。 / 因为

For some companies their treatment of their employees or clients at any given time could affect their share prices and so inevitably have a great influence on the company’s success or failure.

[[Mandarin Chinese#^zh-Q0910-answer|Compare the answer]]
^zh-Q0910

**zh-Q0911 · Write a translation**

Write this in Mandarin Chinese: The teacher should be very patient with her students.

[[Mandarin Chinese#^zh-Q0911-answer|Compare the answer]]
^zh-Q0911

**zh-Q0912 · Explain the grammar**

老师【应该】对学生非常耐心。

The teacher should be very patient with her students.

[[Mandarin Chinese#^zh-Q0912-answer|Compare the answer]]
^zh-Q0912

**zh-Q0913 · Fill the gap**

她很有____会有所成就。

It's likely that she'll succeed.

[[Mandarin Chinese#^zh-Q0913-answer|Compare the answer]]
^zh-Q0913

**zh-Q0914 · Choose the form**

她很有____会有所成就。

It's likely that she'll succeed.

Choices: 可能 / 所以 / 因为 / 应该

[[Mandarin Chinese#^zh-Q0914-answer|Compare the answer]]
^zh-Q0914

**zh-Q0915 · Edit the changed sentence**

等你到的时候【因为】已经散会了。

The meeting will have broken up by the time you arrive there.

[[Mandarin Chinese#^zh-Q0915-answer|Compare the answer]]
^zh-Q0915

**zh-Q0916 · Build the sentence**

Arrange: 已经散会了。 / 应该 / 等你到的时候

The meeting will have broken up by the time you arrive there.

[[Mandarin Chinese#^zh-Q0916-answer|Compare the answer]]
^zh-Q0916

**zh-Q0917 · Write a translation**

Write this in Mandarin Chinese: It's in the internet, so it must be true.

[[Mandarin Chinese#^zh-Q0917-answer|Compare the answer]]
^zh-Q0917

**zh-Q0918 · Explain the grammar**

它在網際網路上，【所以】它一定是真實的。

It's in the internet, so it must be true.

[[Mandarin Chinese#^zh-Q0918-answer|Compare the answer]]
^zh-Q0918

**zh-Q0919 · Fill the gap**

我認為我____已經犯了大錯。

I think I may have made a big mistake.

[[Mandarin Chinese#^zh-Q0919-answer|Compare the answer]]
^zh-Q0919

**zh-Q0920 · Choose the form**

我認為我____已經犯了大錯。

I think I may have made a big mistake.

Choices: 所以 / 可能 / 应该 / 因为

[[Mandarin Chinese#^zh-Q0920-answer|Compare the answer]]
^zh-Q0920

**zh-Q0921 · Edit the changed sentence**

失業者渴望工作，【因为】任何有助於養家糊口的工作都可以。

The jobless became desperate for work – any work that would help them to support their families.

[[Mandarin Chinese#^zh-Q0921-answer|Compare the answer]]
^zh-Q0921

**zh-Q0922 · Build the sentence**

Arrange: 失業者渴望工作， / 任何有助於養家糊口的工作都可以。 / 所以

The jobless became desperate for work – any work that would help them to support their families.

[[Mandarin Chinese#^zh-Q0922-answer|Compare the answer]]
^zh-Q0922

**zh-Q0923 · Write a translation**

Write this in Mandarin Chinese: They didn't swim because it was cold.

[[Mandarin Chinese#^zh-Q0923-answer|Compare the answer]]
^zh-Q0923

**zh-Q0924 · Explain the grammar**

他们之【所以】没有游泳，就因为天气很冷。

They didn't swim because it was cold.

[[Mandarin Chinese#^zh-Q0924-answer|Compare the answer]]
^zh-Q0924

**zh-Q0925 · Fill the gap**

因為你不夠努力，____才會失敗。

The reason why you failed is you did not try hard enough.

[[Mandarin Chinese#^zh-Q0925-answer|Compare the answer]]
^zh-Q0925

**zh-Q0926 · Choose the form**

因為你不夠努力，____才會失敗。

The reason why you failed is you did not try hard enough.

Choices: 可能 / 应该 / 因为 / 所以

[[Mandarin Chinese#^zh-Q0926-answer|Compare the answer]]
^zh-Q0926

**zh-Q0927 · Edit the changed sentence**

就是【所以】他不成材他爸看不起他。

It's just that because he hasn't made something of himself, his father won't look at him.

[[Mandarin Chinese#^zh-Q0927-answer|Compare the answer]]
^zh-Q0927

**zh-Q0928 · Build the sentence**

Arrange: 因为 / 就是 / 他不成材他爸看不起他。

It's just that because he hasn't made something of himself, his father won't look at him.

[[Mandarin Chinese#^zh-Q0928-answer|Compare the answer]]
^zh-Q0928

**zh-Q0929 · Write a translation**

Write this in Mandarin Chinese: It is not because I hate him, but because I love him.

[[Mandarin Chinese#^zh-Q0929-answer|Compare the answer]]
^zh-Q0929

**zh-Q0930 · Explain the grammar**

这并不是【因为】我恨他，相反我爱他。

It is not because I hate him, but because I love him.

[[Mandarin Chinese#^zh-Q0930-answer|Compare the answer]]
^zh-Q0930

**zh-Q0931 · Fill the gap**

汤姆今天不舒服____没来上班。

Tom can't come to work today because he doesn't feel well.

[[Mandarin Chinese#^zh-Q0931-answer|Compare the answer]]
^zh-Q0931

**zh-Q0932 · Choose the form**

汤姆今天不舒服____没来上班。

Tom can't come to work today because he doesn't feel well.

Choices: 应该 / 可能 / 所以 / 因为

[[Mandarin Chinese#^zh-Q0932-answer|Compare the answer]]
^zh-Q0932

**zh-Q0933 · Edit the changed sentence**

她【因为】錯過了七點的火車。

She may have missed the 7:00 train.

[[Mandarin Chinese#^zh-Q0933-answer|Compare the answer]]
^zh-Q0933

**zh-Q0934 · Build the sentence**

Arrange: 錯過了七點的火車。 / 她 / 可能

She may have missed the 7:00 train.

[[Mandarin Chinese#^zh-Q0934-answer|Compare the answer]]
^zh-Q0934

**zh-Q0935 · Write a translation**

Write this in Mandarin Chinese: I had a feeling this might happen.

[[Mandarin Chinese#^zh-Q0935-answer|Compare the answer]]
^zh-Q0935

**zh-Q0936 · Explain the grammar**

我早就有感覺到這【可能】會發生。

I had a feeling this might happen.

[[Mandarin Chinese#^zh-Q0936-answer|Compare the answer]]
^zh-Q0936

**zh-Q0937 · Fill the gap**

我们____尊敬父母。

We should respect our parents.

[[Mandarin Chinese#^zh-Q0937-answer|Compare the answer]]
^zh-Q0937

**zh-Q0938 · Choose the form**

我们____尊敬父母。

We should respect our parents.

Choices: 所以 / 应该 / 可能 / 因为

[[Mandarin Chinese#^zh-Q0938-answer|Compare the answer]]
^zh-Q0938

**zh-Q0939 · Edit the changed sentence**

你有【因为】不知道这事。

It's possible that you don't know this.

[[Mandarin Chinese#^zh-Q0939-answer|Compare the answer]]
^zh-Q0939

**zh-Q0940 · Build the sentence**

Arrange: 你有 / 不知道这事。 / 可能

It's possible that you don't know this.

[[Mandarin Chinese#^zh-Q0940-answer|Compare the answer]]
^zh-Q0940

**zh-Q0941 · Write a translation**

Write this in Mandarin Chinese: Jack always finds fault with others. That's why everybody avoids him.

[[Mandarin Chinese#^zh-Q0941-answer|Compare the answer]]
^zh-Q0941

**zh-Q0942 · Explain the grammar**

傑克很喜歡挑別人的毛病，【所以】沒有人願意和他交朋友。

Jack always finds fault with others. That's why everybody avoids him.

[[Mandarin Chinese#^zh-Q0942-answer|Compare the answer]]
^zh-Q0942

**zh-Q0943 · Fill the gap**

不是____某人不理事实它们就会不复存在了。

Facts do not cease to exist because they are ignored.

[[Mandarin Chinese#^zh-Q0943-answer|Compare the answer]]
^zh-Q0943

**zh-Q0944 · Choose the form**

不是____某人不理事实它们就会不复存在了。

Facts do not cease to exist because they are ignored.

Choices: 应该 / 所以 / 可能 / 因为

[[Mandarin Chinese#^zh-Q0944-answer|Compare the answer]]
^zh-Q0944

**zh-Q0945 · Edit the changed sentence**

我要坚持学习拉丁语，【所以】它非常有趣。

I will continue to study Latin, because it is really interesting.

[[Mandarin Chinese#^zh-Q0945-answer|Compare the answer]]
^zh-Q0945

**zh-Q0946 · Build the sentence**

Arrange: 因为 / 它非常有趣。 / 我要坚持学习拉丁语，

I will continue to study Latin, because it is really interesting.

[[Mandarin Chinese#^zh-Q0946-answer|Compare the answer]]
^zh-Q0946

**zh-Q0947 · Write a translation**

Write this in Mandarin Chinese: Normally I might study Chinese characters for an hour a day.

[[Mandarin Chinese#^zh-Q0947-answer|Compare the answer]]
^zh-Q0947

**zh-Q0948 · Explain the grammar**

我平时每天【可能】练习一个小时汉字。

Normally I might study Chinese characters for an hour a day.

[[Mandarin Chinese#^zh-Q0948-answer|Compare the answer]]
^zh-Q0948

**zh-Q0949 · Fill the gap**

你____多接触本文化，多了解一些传统习俗。

You should interact with the local culture more, to better understand some traditions.

[[Mandarin Chinese#^zh-Q0949-answer|Compare the answer]]
^zh-Q0949

**zh-Q0950 · Choose the form**

你____多接触本文化，多了解一些传统习俗。

You should interact with the local culture more, to better understand some traditions.

Choices: 所以 / 因为 / 可能 / 应该

[[Mandarin Chinese#^zh-Q0950-answer|Compare the answer]]
^zh-Q0950


### Ability and intention · 50 questions

**zh-Q0951 · Edit the changed sentence**

這台相機至少【会】花費500美元。

The camera will cost at least $500.

[[Mandarin Chinese#^zh-Q0951-answer|Compare the answer]]
^zh-Q0951

**zh-Q0952 · Build the sentence**

Arrange: 這台相機至少 / 花費500美元。 / 要

The camera will cost at least $500.

[[Mandarin Chinese#^zh-Q0952-answer|Compare the answer]]
^zh-Q0952

**zh-Q0953 · Write a translation**

Write this in Mandarin Chinese: It's ten minutes' walk to the station.

[[Mandarin Chinese#^zh-Q0953-answer|Compare the answer]]
^zh-Q0953

**zh-Q0954 · Explain the grammar**

步行到車站【要】花十分鐘。

It's ten minutes' walk to the station.

[[Mandarin Chinese#^zh-Q0954-answer|Compare the answer]]
^zh-Q0954

**zh-Q0955 · Fill the gap**

我認為我____幫點忙。

I thought I could be of some help.

[[Mandarin Chinese#^zh-Q0955-answer|Compare the answer]]
^zh-Q0955

**zh-Q0956 · Choose the form**

我認為我____幫點忙。

I thought I could be of some help.

Choices: 可以 / 会 / 能 / 要

[[Mandarin Chinese#^zh-Q0956-answer|Compare the answer]]
^zh-Q0956

**zh-Q0957 · Edit the changed sentence**

我中午十二点半还【会】去浦东。

I still need to go to Pudong at 12:30.

[[Mandarin Chinese#^zh-Q0957-answer|Compare the answer]]
^zh-Q0957

**zh-Q0958 · Build the sentence**

Arrange: 要 / 去浦东。 / 我中午十二点半还

I still need to go to Pudong at 12:30.

[[Mandarin Chinese#^zh-Q0958-answer|Compare the answer]]
^zh-Q0958

**zh-Q0959 · Write a translation**

Write this in Mandarin Chinese: Do you want to be an actor in a movie?

[[Mandarin Chinese#^zh-Q0959-answer|Compare the answer]]
^zh-Q0959

**zh-Q0960 · Explain the grammar**

你【想】成為一名電影演員嗎？

Do you want to be an actor in a movie?

[[Mandarin Chinese#^zh-Q0960-answer|Compare the answer]]
^zh-Q0960

**zh-Q0961 · Fill the gap**

無論如何我一定____在明天前完成這工作。

In any case, I must finish this work by tomorrow.

[[Mandarin Chinese#^zh-Q0961-answer|Compare the answer]]
^zh-Q0961

**zh-Q0962 · Choose the form**

無論如何我一定____在明天前完成這工作。

In any case, I must finish this work by tomorrow.

Choices: 要 / 会 / 能 / 可以

[[Mandarin Chinese#^zh-Q0962-answer|Compare the answer]]
^zh-Q0962

**zh-Q0963 · Edit the changed sentence**

我也和你【会】的一样。

We think alike.

[[Mandarin Chinese#^zh-Q0963-answer|Compare the answer]]
^zh-Q0963

**zh-Q0964 · Build the sentence**

Arrange: 的一样。 / 想 / 我也和你

We think alike.

[[Mandarin Chinese#^zh-Q0964-answer|Compare the answer]]
^zh-Q0964

**zh-Q0965 · Write a translation**

Write this in Mandarin Chinese: I think it will be hot today.

[[Mandarin Chinese#^zh-Q0965-answer|Compare the answer]]
^zh-Q0965

**zh-Q0966 · Explain the grammar**

我觉得今天【会】很热。

I think it will be hot today.

[[Mandarin Chinese#^zh-Q0966-answer|Compare the answer]]
^zh-Q0966

**zh-Q0967 · Fill the gap**

我____向你学习很多。

I have a lot to learn from you.

[[Mandarin Chinese#^zh-Q0967-answer|Compare the answer]]
^zh-Q0967

**zh-Q0968 · Choose the form**

我____向你学习很多。

I have a lot to learn from you.

Choices: 可以 / 要 / 会 / 能

[[Mandarin Chinese#^zh-Q0968-answer|Compare the answer]]
^zh-Q0968

**zh-Q0969 · Edit the changed sentence**

他會做任何你【会】求他做的事。

He'll do whatever you ask him to.

[[Mandarin Chinese#^zh-Q0969-answer|Compare the answer]]
^zh-Q0969

**zh-Q0970 · Build the sentence**

Arrange: 求他做的事。 / 要 / 他會做任何你

He'll do whatever you ask him to.

[[Mandarin Chinese#^zh-Q0970-answer|Compare the answer]]
^zh-Q0970

**zh-Q0971 · Write a translation**

Write this in Mandarin Chinese: You can trust him with any job.

[[Mandarin Chinese#^zh-Q0971-answer|Compare the answer]]
^zh-Q0971

**zh-Q0972 · Explain the grammar**

任何工作你都【可以】放心的交给他。

You can trust him with any job.

[[Mandarin Chinese#^zh-Q0972-answer|Compare the answer]]
^zh-Q0972

**zh-Q0973 · Fill the gap**

不____在冰上滑倒啊。

Don't slip on the ice.

[[Mandarin Chinese#^zh-Q0973-answer|Compare the answer]]
^zh-Q0973

**zh-Q0974 · Choose the form**

不____在冰上滑倒啊。

Don't slip on the ice.

Choices: 能 / 可以 / 要 / 会

[[Mandarin Chinese#^zh-Q0974-answer|Compare the answer]]
^zh-Q0974

**zh-Q0975 · Edit the changed sentence**

在句子中不【会】写入额外信息，比如作者姓名。

Don't write extra information, such as the name of the author, within the sentence.

[[Mandarin Chinese#^zh-Q0975-answer|Compare the answer]]
^zh-Q0975

**zh-Q0976 · Build the sentence**

Arrange: 在句子中不 / 写入额外信息，比如作者姓名。 / 要

Don't write extra information, such as the name of the author, within the sentence.

[[Mandarin Chinese#^zh-Q0976-answer|Compare the answer]]
^zh-Q0976

**zh-Q0977 · Write a translation**

Write this in Mandarin Chinese: My parents teach me to abide by my promises.

[[Mandarin Chinese#^zh-Q0977-answer|Compare the answer]]
^zh-Q0977

**zh-Q0978 · Explain the grammar**

父母教育我【要】遵守承诺。

My parents teach me to abide by my promises.

[[Mandarin Chinese#^zh-Q0978-answer|Compare the answer]]
^zh-Q0978

**zh-Q0979 · Fill the gap**

听说适时地补充水分____预防中暑。

I hear that keeping yourself hydrated at appropriate times can help prevent heatstroke.

[[Mandarin Chinese#^zh-Q0979-answer|Compare the answer]]
^zh-Q0979

**zh-Q0980 · Choose the form**

听说适时地补充水分____预防中暑。

I hear that keeping yourself hydrated at appropriate times can help prevent heatstroke.

Choices: 可以 / 要 / 能 / 会

[[Mandarin Chinese#^zh-Q0980-answer|Compare the answer]]
^zh-Q0980

**zh-Q0981 · Edit the changed sentence**

我寧願到不喜歡的公司工作，也不【会】渾渾噩噩的又過一年。

I would rather work for any company than waste another year.

[[Mandarin Chinese#^zh-Q0981-answer|Compare the answer]]
^zh-Q0981

**zh-Q0982 · Build the sentence**

Arrange: 想 / 渾渾噩噩的又過一年。 / 我寧願到不喜歡的公司工作，也不

I would rather work for any company than waste another year.

[[Mandarin Chinese#^zh-Q0982-answer|Compare the answer]]
^zh-Q0982

**zh-Q0983 · Write a translation**

Write this in Mandarin Chinese: We must not laugh at the poor.

[[Mandarin Chinese#^zh-Q0983-answer|Compare the answer]]
^zh-Q0983

**zh-Q0984 · Explain the grammar**

我们不【能】嘲笑穷人。

We must not laugh at the poor.

[[Mandarin Chinese#^zh-Q0984-answer|Compare the answer]]
^zh-Q0984

**zh-Q0985 · Fill the gap**

我们____么喝葡萄酒，要么喝啤酒。

Let’s drink wine or beer.

[[Mandarin Chinese#^zh-Q0985-answer|Compare the answer]]
^zh-Q0985

**zh-Q0986 · Choose the form**

我们____么喝葡萄酒，要么喝啤酒。

Let’s drink wine or beer.

Choices: 可以 / 能 / 会 / 要

[[Mandarin Chinese#^zh-Q0986-answer|Compare the answer]]
^zh-Q0986

**zh-Q0987 · Edit the changed sentence**

【会】否请您给我看一下您的护照？

Will you show me your passport, please?

[[Mandarin Chinese#^zh-Q0987-answer|Compare the answer]]
^zh-Q0987

**zh-Q0988 · Build the sentence**

Arrange: 否请您给我看一下您的护照？ / 能

Will you show me your passport, please?

[[Mandarin Chinese#^zh-Q0988-answer|Compare the answer]]
^zh-Q0988

**zh-Q0989 · Write a translation**

Write this in Mandarin Chinese: We went to the dance.

[[Mandarin Chinese#^zh-Q0989-answer|Compare the answer]]
^zh-Q0989

**zh-Q0990 · Explain the grammar**

我们去参加舞【会】了。

We went to the dance.

[[Mandarin Chinese#^zh-Q0990-answer|Compare the answer]]
^zh-Q0990

**zh-Q0991 · Fill the gap**

我____要一點柳橙汁。

I want some orange juice.

[[Mandarin Chinese#^zh-Q0991-answer|Compare the answer]]
^zh-Q0991

**zh-Q0992 · Choose the form**

我____要一點柳橙汁。

I want some orange juice.

Choices: 可以 / 能 / 想 / 会

[[Mandarin Chinese#^zh-Q0992-answer|Compare the answer]]
^zh-Q0992

**zh-Q0993 · Edit the changed sentence**

我們沒有必【会】出席這個講座。

It is not necessary for us to attend this lecture.

[[Mandarin Chinese#^zh-Q0993-answer|Compare the answer]]
^zh-Q0993

**zh-Q0994 · Build the sentence**

Arrange: 我們沒有必 / 出席這個講座。 / 要

It is not necessary for us to attend this lecture.

[[Mandarin Chinese#^zh-Q0994-answer|Compare the answer]]
^zh-Q0994

**zh-Q0995 · Write a translation**

Write this in Mandarin Chinese: I'm old enough to live by myself.

[[Mandarin Chinese#^zh-Q0995-answer|Compare the answer]]
^zh-Q0995

**zh-Q0996 · Explain the grammar**

我年紀夠大了【可以】自己一個人住。

I'm old enough to live by myself.

[[Mandarin Chinese#^zh-Q0996-answer|Compare the answer]]
^zh-Q0996

**zh-Q0997 · Fill the gap**

我需____购买新的镜架。

I need to buy new spectacle frames.

[[Mandarin Chinese#^zh-Q0997-answer|Compare the answer]]
^zh-Q0997

**zh-Q0998 · Choose the form**

我需____购买新的镜架。

I need to buy new spectacle frames.

Choices: 能 / 要 / 会 / 可以

[[Mandarin Chinese#^zh-Q0998-answer|Compare the answer]]
^zh-Q0998

**zh-Q0999 · Edit the changed sentence**

我昨天非常【会】念你。

I missed you very much yesterday.

[[Mandarin Chinese#^zh-Q0999-answer|Compare the answer]]
^zh-Q0999

**zh-Q1000 · Build the sentence**

Arrange: 念你。 / 我昨天非常 / 想

I missed you very much yesterday.

[[Mandarin Chinese#^zh-Q1000-answer|Compare the answer]]
^zh-Q1000


## Answers

The full sentence is a model. For translation, judge whether meaning and grammar are preserved. Each grammar rule above explains the form.

### Answers 1–50

**zh-Q0001** — 他们不会找到汤姆。

They won't find Tom.

Expected form: **他**

Why: Personal pronouns. [[Mandarin Chinese#^zh-Q0001|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%96%E4%BB%AC%E4%B8%8D%E4%BC%9A%E6%89%BE%E5%88%B0%E6%B1%A4%E5%A7%86%E3%80%82)
^zh-Q0001-answer

**zh-Q0002** — 他们不会找到汤姆。

They won't find Tom.

Expected form: **他**

Why: Personal pronouns. [[Mandarin Chinese#^zh-Q0002|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%96%E4%BB%AC%E4%B8%8D%E4%BC%9A%E6%89%BE%E5%88%B0%E6%B1%A4%E5%A7%86%E3%80%82)
^zh-Q0002-answer

**zh-Q0003** — 来吧，我们一起去。

Come on, let's go.

Expected form: **我**

Why: Personal pronouns. [[Mandarin Chinese#^zh-Q0003|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%9D%A5%E5%90%A7%EF%BC%8C%E6%88%91%E4%BB%AC%E4%B8%80%E8%B5%B7%E5%8E%BB%E3%80%82)
^zh-Q0003-answer

**zh-Q0004** — 来吧，我们一起去。

Come on, let's go.

Why: Personal pronouns. [[Mandarin Chinese#^zh-Q0004|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%9D%A5%E5%90%A7%EF%BC%8C%E6%88%91%E4%BB%AC%E4%B8%80%E8%B5%B7%E5%8E%BB%E3%80%82)
^zh-Q0004-answer

**zh-Q0005** — 你們要是用刀劍刺我們，我們不是也會出血嗎？

If you prick us, do we not bleed?

Why: Personal pronouns. [[Mandarin Chinese#^zh-Q0005|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E5%80%91%E8%A6%81%E6%98%AF%E7%94%A8%E5%88%80%E5%8A%8D%E5%88%BA%E6%88%91%E5%80%91%EF%BC%8C%E6%88%91%E5%80%91%E4%B8%8D%E6%98%AF%E4%B9%9F%E6%9C%83%E5%87%BA%E8%A1%80%E5%97%8E%EF%BC%9F)
^zh-Q0005-answer

**zh-Q0006** — 你們要是用刀劍刺我們，我們不是也會出血嗎？

If you prick us, do we not bleed?

Mandarin pronouns do not conjugate a verb. 他 and 她 differ in writing but share spoken tā. Context can omit a known subject; omission is a discourse choice rather than a new verb ending.

Why: Personal pronouns. [[Mandarin Chinese#^zh-Q0006|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E5%80%91%E8%A6%81%E6%98%AF%E7%94%A8%E5%88%80%E5%8A%8D%E5%88%BA%E6%88%91%E5%80%91%EF%BC%8C%E6%88%91%E5%80%91%E4%B8%8D%E6%98%AF%E4%B9%9F%E6%9C%83%E5%87%BA%E8%A1%80%E5%97%8E%EF%BC%9F)
^zh-Q0006-answer

**zh-Q0007** — 我吹次中音薩克斯風。

I play the tenor saxophone.

Expected form: **我**

Why: Personal pronouns. [[Mandarin Chinese#^zh-Q0007|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E5%90%B9%E6%AC%A1%E4%B8%AD%E9%9F%B3%E8%96%A9%E5%85%8B%E6%96%AF%E9%A2%A8%E3%80%82)
^zh-Q0007-answer

**zh-Q0008** — 我吹次中音薩克斯風。

I play the tenor saxophone.

Expected form: **我**

Why: Personal pronouns. [[Mandarin Chinese#^zh-Q0008|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E5%90%B9%E6%AC%A1%E4%B8%AD%E9%9F%B3%E8%96%A9%E5%85%8B%E6%96%AF%E9%A2%A8%E3%80%82)
^zh-Q0008-answer

**zh-Q0009** — 他已經成為了棒球隊員。

He has made the baseball team.

Expected form: **他**

Why: Personal pronouns. [[Mandarin Chinese#^zh-Q0009|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%96%E5%B7%B2%E7%B6%93%E6%88%90%E7%82%BA%E4%BA%86%E6%A3%92%E7%90%83%E9%9A%8A%E5%93%A1%E3%80%82)
^zh-Q0009-answer

**zh-Q0010** — 他已經成為了棒球隊員。

He has made the baseball team.

Why: Personal pronouns. [[Mandarin Chinese#^zh-Q0010|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%96%E5%B7%B2%E7%B6%93%E6%88%90%E7%82%BA%E4%BA%86%E6%A3%92%E7%90%83%E9%9A%8A%E5%93%A1%E3%80%82)
^zh-Q0010-answer

**zh-Q0011** — 你为什么让我看这个？

Why did you show me this?

Why: Personal pronouns. [[Mandarin Chinese#^zh-Q0011|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E4%B8%BA%E4%BB%80%E4%B9%88%E8%AE%A9%E6%88%91%E7%9C%8B%E8%BF%99%E4%B8%AA%EF%BC%9F)
^zh-Q0011-answer

**zh-Q0012** — 你为什么让我看这个？

Why did you show me this?

Mandarin pronouns do not conjugate a verb. 他 and 她 differ in writing but share spoken tā. Context can omit a known subject; omission is a discourse choice rather than a new verb ending.

Why: Personal pronouns. [[Mandarin Chinese#^zh-Q0012|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E4%B8%BA%E4%BB%80%E4%B9%88%E8%AE%A9%E6%88%91%E7%9C%8B%E8%BF%99%E4%B8%AA%EF%BC%9F)
^zh-Q0012-answer

**zh-Q0013** — 幫我看著我的相機。

Watch my camera for me.

Expected form: **我**

Why: Personal pronouns. [[Mandarin Chinese#^zh-Q0013|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%B9%AB%E6%88%91%E7%9C%8B%E8%91%97%E6%88%91%E7%9A%84%E7%9B%B8%E6%A9%9F%E3%80%82)
^zh-Q0013-answer

**zh-Q0014** — 幫我看著我的相機。

Watch my camera for me.

Expected form: **我**

Why: Personal pronouns. [[Mandarin Chinese#^zh-Q0014|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%B9%AB%E6%88%91%E7%9C%8B%E8%91%97%E6%88%91%E7%9A%84%E7%9B%B8%E6%A9%9F%E3%80%82)
^zh-Q0014-answer

**zh-Q0015** — 我以前在這條河裡游泳。

I used to swim in this river.

Expected form: **我**

Why: Personal pronouns. [[Mandarin Chinese#^zh-Q0015|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E4%BB%A5%E5%89%8D%E5%9C%A8%E9%80%99%E6%A2%9D%E6%B2%B3%E8%A3%A1%E6%B8%B8%E6%B3%B3%E3%80%82)
^zh-Q0015-answer

**zh-Q0016** — 我以前在這條河裡游泳。

I used to swim in this river.

Why: Personal pronouns. [[Mandarin Chinese#^zh-Q0016|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E4%BB%A5%E5%89%8D%E5%9C%A8%E9%80%99%E6%A2%9D%E6%B2%B3%E8%A3%A1%E6%B8%B8%E6%B3%B3%E3%80%82)
^zh-Q0016-answer

**zh-Q0017** — 简的美丽丝毫不逊色于她母亲。

Jane is no less beautiful than her mother.

Why: Personal pronouns. [[Mandarin Chinese#^zh-Q0017|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E7%AE%80%E7%9A%84%E7%BE%8E%E4%B8%BD%E4%B8%9D%E6%AF%AB%E4%B8%8D%E9%80%8A%E8%89%B2%E4%BA%8E%E5%A5%B9%E6%AF%8D%E4%BA%B2%E3%80%82)
^zh-Q0017-answer

**zh-Q0018** — 简的美丽丝毫不逊色于她母亲。

Jane is no less beautiful than her mother.

Mandarin pronouns do not conjugate a verb. 他 and 她 differ in writing but share spoken tā. Context can omit a known subject; omission is a discourse choice rather than a new verb ending.

Why: Personal pronouns. [[Mandarin Chinese#^zh-Q0018|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E7%AE%80%E7%9A%84%E7%BE%8E%E4%B8%BD%E4%B8%9D%E6%AF%AB%E4%B8%8D%E9%80%8A%E8%89%B2%E4%BA%8E%E5%A5%B9%E6%AF%8D%E4%BA%B2%E3%80%82)
^zh-Q0018-answer

**zh-Q0019** — 我們該吃午飯了吧？

Should we have some lunch?

Expected form: **我**

Why: Personal pronouns. [[Mandarin Chinese#^zh-Q0019|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E5%80%91%E8%A9%B2%E5%90%83%E5%8D%88%E9%A3%AF%E4%BA%86%E5%90%A7%EF%BC%9F)
^zh-Q0019-answer

**zh-Q0020** — 我們該吃午飯了吧？

Should we have some lunch?

Expected form: **我**

Why: Personal pronouns. [[Mandarin Chinese#^zh-Q0020|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E5%80%91%E8%A9%B2%E5%90%83%E5%8D%88%E9%A3%AF%E4%BA%86%E5%90%A7%EF%BC%9F)
^zh-Q0020-answer

**zh-Q0021** — 你明天的行程安排是什麼？

What's your schedule for tomorrow?

Expected form: **你**

Why: Personal pronouns. [[Mandarin Chinese#^zh-Q0021|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E6%98%8E%E5%A4%A9%E7%9A%84%E8%A1%8C%E7%A8%8B%E5%AE%89%E6%8E%92%E6%98%AF%E4%BB%80%E9%BA%BC%EF%BC%9F)
^zh-Q0021-answer

**zh-Q0022** — 你明天的行程安排是什麼？

What's your schedule for tomorrow?

Why: Personal pronouns. [[Mandarin Chinese#^zh-Q0022|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E6%98%8E%E5%A4%A9%E7%9A%84%E8%A1%8C%E7%A8%8B%E5%AE%89%E6%8E%92%E6%98%AF%E4%BB%80%E9%BA%BC%EF%BC%9F)
^zh-Q0022-answer

**zh-Q0023** — 不出我所料，那部電影相當有趣。

The movie was interesting, as I had expected.

Why: Personal pronouns. [[Mandarin Chinese#^zh-Q0023|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%B8%8D%E5%87%BA%E6%88%91%E6%89%80%E6%96%99%EF%BC%8C%E9%82%A3%E9%83%A8%E9%9B%BB%E5%BD%B1%E7%9B%B8%E7%95%B6%E6%9C%89%E8%B6%A3%E3%80%82)
^zh-Q0023-answer

**zh-Q0024** — 不出我所料，那部電影相當有趣。

The movie was interesting, as I had expected.

Mandarin pronouns do not conjugate a verb. 他 and 她 differ in writing but share spoken tā. Context can omit a known subject; omission is a discourse choice rather than a new verb ending.

Why: Personal pronouns. [[Mandarin Chinese#^zh-Q0024|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%B8%8D%E5%87%BA%E6%88%91%E6%89%80%E6%96%99%EF%BC%8C%E9%82%A3%E9%83%A8%E9%9B%BB%E5%BD%B1%E7%9B%B8%E7%95%B6%E6%9C%89%E8%B6%A3%E3%80%82)
^zh-Q0024-answer

**zh-Q0025** — 我不喜欢这个操作系统的页面。

I didn't like the interface of that operating system.

Expected form: **我**

Why: Personal pronouns. [[Mandarin Chinese#^zh-Q0025|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E4%B8%8D%E5%96%9C%E6%AC%A2%E8%BF%99%E4%B8%AA%E6%93%8D%E4%BD%9C%E7%B3%BB%E7%BB%9F%E7%9A%84%E9%A1%B5%E9%9D%A2%E3%80%82)
^zh-Q0025-answer

**zh-Q0026** — 我不喜欢这个操作系统的页面。

I didn't like the interface of that operating system.

Expected form: **我**

Why: Personal pronouns. [[Mandarin Chinese#^zh-Q0026|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E4%B8%8D%E5%96%9C%E6%AC%A2%E8%BF%99%E4%B8%AA%E6%93%8D%E4%BD%9C%E7%B3%BB%E7%BB%9F%E7%9A%84%E9%A1%B5%E9%9D%A2%E3%80%82)
^zh-Q0026-answer

**zh-Q0027** — 她到意大利學習意大利語。

She went to Italy to learn Italian.

Expected form: **她**

Why: Personal pronouns. [[Mandarin Chinese#^zh-Q0027|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A5%B9%E5%88%B0%E6%84%8F%E5%A4%A7%E5%88%A9%E5%AD%B8%E7%BF%92%E6%84%8F%E5%A4%A7%E5%88%A9%E8%AA%9E%E3%80%82)
^zh-Q0027-answer

**zh-Q0028** — 她到意大利學習意大利語。

She went to Italy to learn Italian.

Why: Personal pronouns. [[Mandarin Chinese#^zh-Q0028|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A5%B9%E5%88%B0%E6%84%8F%E5%A4%A7%E5%88%A9%E5%AD%B8%E7%BF%92%E6%84%8F%E5%A4%A7%E5%88%A9%E8%AA%9E%E3%80%82)
^zh-Q0028-answer

**zh-Q0029** — 你难以理解女人和小孩子对你说的话吗？

Do you have difficulty understanding what women or small children say to you?

Why: Personal pronouns. [[Mandarin Chinese#^zh-Q0029|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E9%9A%BE%E4%BB%A5%E7%90%86%E8%A7%A3%E5%A5%B3%E4%BA%BA%E5%92%8C%E5%B0%8F%E5%AD%A9%E5%AD%90%E5%AF%B9%E4%BD%A0%E8%AF%B4%E7%9A%84%E8%AF%9D%E5%90%97%EF%BC%9F)
^zh-Q0029-answer

**zh-Q0030** — 你难以理解女人和小孩子对你说的话吗？

Do you have difficulty understanding what women or small children say to you?

Mandarin pronouns do not conjugate a verb. 他 and 她 differ in writing but share spoken tā. Context can omit a known subject; omission is a discourse choice rather than a new verb ending.

Why: Personal pronouns. [[Mandarin Chinese#^zh-Q0030|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E9%9A%BE%E4%BB%A5%E7%90%86%E8%A7%A3%E5%A5%B3%E4%BA%BA%E5%92%8C%E5%B0%8F%E5%AD%A9%E5%AD%90%E5%AF%B9%E4%BD%A0%E8%AF%B4%E7%9A%84%E8%AF%9D%E5%90%97%EF%BC%9F)
^zh-Q0030-answer

**zh-Q0031** — 你的英語進步了很多。

Your English has improved a lot.

Expected form: **你**

Why: Personal pronouns. [[Mandarin Chinese#^zh-Q0031|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E7%9A%84%E8%8B%B1%E8%AA%9E%E9%80%B2%E6%AD%A5%E4%BA%86%E5%BE%88%E5%A4%9A%E3%80%82)
^zh-Q0031-answer

**zh-Q0032** — 你的英語進步了很多。

Your English has improved a lot.

Expected form: **你**

Why: Personal pronouns. [[Mandarin Chinese#^zh-Q0032|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E7%9A%84%E8%8B%B1%E8%AA%9E%E9%80%B2%E6%AD%A5%E4%BA%86%E5%BE%88%E5%A4%9A%E3%80%82)
^zh-Q0032-answer

**zh-Q0033** — 如果我了解這件事, 我就會告訴你。

If I could understand it, I would tell you so.

Expected form: **我**

Why: Personal pronouns. [[Mandarin Chinese#^zh-Q0033|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A6%82%E6%9E%9C%E6%88%91%E4%BA%86%E8%A7%A3%E9%80%99%E4%BB%B6%E4%BA%8B%2C%20%E6%88%91%E5%B0%B1%E6%9C%83%E5%91%8A%E8%A8%B4%E4%BD%A0%E3%80%82)
^zh-Q0033-answer

**zh-Q0034** — 如果我了解這件事, 我就會告訴你。

If I could understand it, I would tell you so.

Why: Personal pronouns. [[Mandarin Chinese#^zh-Q0034|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A6%82%E6%9E%9C%E6%88%91%E4%BA%86%E8%A7%A3%E9%80%99%E4%BB%B6%E4%BA%8B%2C%20%E6%88%91%E5%B0%B1%E6%9C%83%E5%91%8A%E8%A8%B4%E4%BD%A0%E3%80%82)
^zh-Q0034-answer

**zh-Q0035** — 进口数量的急速增长让我们感到惊讶。

We're amazed by the rapid growth in import quantities.

Why: Personal pronouns. [[Mandarin Chinese#^zh-Q0035|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%BF%9B%E5%8F%A3%E6%95%B0%E9%87%8F%E7%9A%84%E6%80%A5%E9%80%9F%E5%A2%9E%E9%95%BF%E8%AE%A9%E6%88%91%E4%BB%AC%E6%84%9F%E5%88%B0%E6%83%8A%E8%AE%B6%E3%80%82)
^zh-Q0035-answer

**zh-Q0036** — 进口数量的急速增长让我们感到惊讶。

We're amazed by the rapid growth in import quantities.

Mandarin pronouns do not conjugate a verb. 他 and 她 differ in writing but share spoken tā. Context can omit a known subject; omission is a discourse choice rather than a new verb ending.

Why: Personal pronouns. [[Mandarin Chinese#^zh-Q0036|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%BF%9B%E5%8F%A3%E6%95%B0%E9%87%8F%E7%9A%84%E6%80%A5%E9%80%9F%E5%A2%9E%E9%95%BF%E8%AE%A9%E6%88%91%E4%BB%AC%E6%84%9F%E5%88%B0%E6%83%8A%E8%AE%B6%E3%80%82)
^zh-Q0036-answer

**zh-Q0037** — 我父亲可能会乘下一列火车来。

My father will possibly come on the next train.

Expected form: **我**

Why: Personal pronouns. [[Mandarin Chinese#^zh-Q0037|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E7%88%B6%E4%BA%B2%E5%8F%AF%E8%83%BD%E4%BC%9A%E4%B9%98%E4%B8%8B%E4%B8%80%E5%88%97%E7%81%AB%E8%BD%A6%E6%9D%A5%E3%80%82)
^zh-Q0037-answer

**zh-Q0038** — 我父亲可能会乘下一列火车来。

My father will possibly come on the next train.

Expected form: **我**

Why: Personal pronouns. [[Mandarin Chinese#^zh-Q0038|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E7%88%B6%E4%BA%B2%E5%8F%AF%E8%83%BD%E4%BC%9A%E4%B9%98%E4%B8%8B%E4%B8%80%E5%88%97%E7%81%AB%E8%BD%A6%E6%9D%A5%E3%80%82)
^zh-Q0038-answer

**zh-Q0039** — 我要你把窗戶打開。

I want you to open the window.

Expected form: **我**

Why: Personal pronouns. [[Mandarin Chinese#^zh-Q0039|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E8%A6%81%E4%BD%A0%E6%8A%8A%E7%AA%97%E6%88%B6%E6%89%93%E9%96%8B%E3%80%82)
^zh-Q0039-answer

**zh-Q0040** — 我要你把窗戶打開。

I want you to open the window.

Why: Personal pronouns. [[Mandarin Chinese#^zh-Q0040|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E8%A6%81%E4%BD%A0%E6%8A%8A%E7%AA%97%E6%88%B6%E6%89%93%E9%96%8B%E3%80%82)
^zh-Q0040-answer

**zh-Q0041** — 同樣的情況我們還能在下面這幾個例子中找到。

We can find similar situations in these next few cases.

Why: Personal pronouns. [[Mandarin Chinese#^zh-Q0041|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%90%8C%E6%A8%A3%E7%9A%84%E6%83%85%E6%B3%81%E6%88%91%E5%80%91%E9%82%84%E8%83%BD%E5%9C%A8%E4%B8%8B%E9%9D%A2%E9%80%99%E5%B9%BE%E5%80%8B%E4%BE%8B%E5%AD%90%E4%B8%AD%E6%89%BE%E5%88%B0%E3%80%82)
^zh-Q0041-answer

**zh-Q0042** — 同樣的情況我們還能在下面這幾個例子中找到。

We can find similar situations in these next few cases.

Mandarin pronouns do not conjugate a verb. 他 and 她 differ in writing but share spoken tā. Context can omit a known subject; omission is a discourse choice rather than a new verb ending.

Why: Personal pronouns. [[Mandarin Chinese#^zh-Q0042|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%90%8C%E6%A8%A3%E7%9A%84%E6%83%85%E6%B3%81%E6%88%91%E5%80%91%E9%82%84%E8%83%BD%E5%9C%A8%E4%B8%8B%E9%9D%A2%E9%80%99%E5%B9%BE%E5%80%8B%E4%BE%8B%E5%AD%90%E4%B8%AD%E6%89%BE%E5%88%B0%E3%80%82)
^zh-Q0042-answer

**zh-Q0043** — 你说的东西是胡扯。

What you said is baloney.

Expected form: **你**

Why: Personal pronouns. [[Mandarin Chinese#^zh-Q0043|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E8%AF%B4%E7%9A%84%E4%B8%9C%E8%A5%BF%E6%98%AF%E8%83%A1%E6%89%AF%E3%80%82)
^zh-Q0043-answer

**zh-Q0044** — 你说的东西是胡扯。

What you said is baloney.

Expected form: **你**

Why: Personal pronouns. [[Mandarin Chinese#^zh-Q0044|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E8%AF%B4%E7%9A%84%E4%B8%9C%E8%A5%BF%E6%98%AF%E8%83%A1%E6%89%AF%E3%80%82)
^zh-Q0044-answer

**zh-Q0045** — 你的文法比你的呼吸好。

Your grammar is better than your breath.

Expected form: **你**

Why: Personal pronouns. [[Mandarin Chinese#^zh-Q0045|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E7%9A%84%E6%96%87%E6%B3%95%E6%AF%94%E4%BD%A0%E7%9A%84%E5%91%BC%E5%90%B8%E5%A5%BD%E3%80%82)
^zh-Q0045-answer

**zh-Q0046** — 你的文法比你的呼吸好。

Your grammar is better than your breath.

Why: Personal pronouns. [[Mandarin Chinese#^zh-Q0046|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E7%9A%84%E6%96%87%E6%B3%95%E6%AF%94%E4%BD%A0%E7%9A%84%E5%91%BC%E5%90%B8%E5%A5%BD%E3%80%82)
^zh-Q0046-answer

**zh-Q0047** — 我能回答您的问题。

I can answer your question.

Why: Personal pronouns. [[Mandarin Chinese#^zh-Q0047|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E8%83%BD%E5%9B%9E%E7%AD%94%E6%82%A8%E7%9A%84%E9%97%AE%E9%A2%98%E3%80%82)
^zh-Q0047-answer

**zh-Q0048** — 我能回答您的问题。

I can answer your question.

Mandarin pronouns do not conjugate a verb. 他 and 她 differ in writing but share spoken tā. Context can omit a known subject; omission is a discourse choice rather than a new verb ending.

Why: Personal pronouns. [[Mandarin Chinese#^zh-Q0048|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E8%83%BD%E5%9B%9E%E7%AD%94%E6%82%A8%E7%9A%84%E9%97%AE%E9%A2%98%E3%80%82)
^zh-Q0048-answer

**zh-Q0049** — 他對這個計劃表示了興趣。

He showed interest in the plan.

Expected form: **他**

Why: Personal pronouns. [[Mandarin Chinese#^zh-Q0049|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%96%E5%B0%8D%E9%80%99%E5%80%8B%E8%A8%88%E5%8A%83%E8%A1%A8%E7%A4%BA%E4%BA%86%E8%88%88%E8%B6%A3%E3%80%82)
^zh-Q0049-answer

**zh-Q0050** — 他對這個計劃表示了興趣。

He showed interest in the plan.

Expected form: **他**

Why: Personal pronouns. [[Mandarin Chinese#^zh-Q0050|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%96%E5%B0%8D%E9%80%99%E5%80%8B%E8%A8%88%E5%8A%83%E8%A1%A8%E7%A4%BA%E4%BA%86%E8%88%88%E8%B6%A3%E3%80%82)
^zh-Q0050-answer


### Answers 51–100

**zh-Q0051** — 莎士比亞是一位作家的名字。

Shakespeare is the name of a writer.

Expected form: **是**

Why: Identity with 是. [[Mandarin Chinese#^zh-Q0051|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%8E%8E%E5%A3%AB%E6%AF%94%E4%BA%9E%E6%98%AF%E4%B8%80%E4%BD%8D%E4%BD%9C%E5%AE%B6%E7%9A%84%E5%90%8D%E5%AD%97%E3%80%82)
^zh-Q0051-answer

**zh-Q0052** — 莎士比亞是一位作家的名字。

Shakespeare is the name of a writer.

Why: Identity with 是. [[Mandarin Chinese#^zh-Q0052|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%8E%8E%E5%A3%AB%E6%AF%94%E4%BA%9E%E6%98%AF%E4%B8%80%E4%BD%8D%E4%BD%9C%E5%AE%B6%E7%9A%84%E5%90%8D%E5%AD%97%E3%80%82)
^zh-Q0052-answer

**zh-Q0053** — 哪個比較重，鉛還是黃金？

Which is heavier, lead or gold?

Why: Identity with 是. [[Mandarin Chinese#^zh-Q0053|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%93%AA%E5%80%8B%E6%AF%94%E8%BC%83%E9%87%8D%EF%BC%8C%E9%89%9B%E9%82%84%E6%98%AF%E9%BB%83%E9%87%91%EF%BC%9F)
^zh-Q0053-answer

**zh-Q0054** — 哪個比較重，鉛還是黃金？

Which is heavier, lead or gold?

是 commonly links identity or classification. Ordinary adjectival predicates do not require 是 merely because English uses be. 是 also appears in focus constructions, so read the whole predicate.

Why: Identity with 是. [[Mandarin Chinese#^zh-Q0054|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%93%AA%E5%80%8B%E6%AF%94%E8%BC%83%E9%87%8D%EF%BC%8C%E9%89%9B%E9%82%84%E6%98%AF%E9%BB%83%E9%87%91%EF%BC%9F)
^zh-Q0054-answer

**zh-Q0055** — 勇气是一个奇怪的东西：没有任何人对它有把握

Courage is a strange thing: One can never be sure of it.

Expected form: **是**

Why: Identity with 是. [[Mandarin Chinese#^zh-Q0055|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%8B%87%E6%B0%94%E6%98%AF%E4%B8%80%E4%B8%AA%E5%A5%87%E6%80%AA%E7%9A%84%E4%B8%9C%E8%A5%BF%EF%BC%9A%E6%B2%A1%E6%9C%89%E4%BB%BB%E4%BD%95%E4%BA%BA%E5%AF%B9%E5%AE%83%E6%9C%89%E6%8A%8A%E6%8F%A1)
^zh-Q0055-answer

**zh-Q0056** — 勇气是一个奇怪的东西：没有任何人对它有把握

Courage is a strange thing: One can never be sure of it.

Expected form: **是**

Why: Identity with 是. [[Mandarin Chinese#^zh-Q0056|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%8B%87%E6%B0%94%E6%98%AF%E4%B8%80%E4%B8%AA%E5%A5%87%E6%80%AA%E7%9A%84%E4%B8%9C%E8%A5%BF%EF%BC%9A%E6%B2%A1%E6%9C%89%E4%BB%BB%E4%BD%95%E4%BA%BA%E5%AF%B9%E5%AE%83%E6%9C%89%E6%8A%8A%E6%8F%A1)
^zh-Q0056-answer

**zh-Q0057** — 這是湯姆叔叔的農場。

This is Uncle Tom's farm.

Expected form: **是**

Why: Identity with 是. [[Mandarin Chinese#^zh-Q0057|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E9%80%99%E6%98%AF%E6%B9%AF%E5%A7%86%E5%8F%94%E5%8F%94%E7%9A%84%E8%BE%B2%E5%A0%B4%E3%80%82)
^zh-Q0057-answer

**zh-Q0058** — 這是湯姆叔叔的農場。

This is Uncle Tom's farm.

Why: Identity with 是. [[Mandarin Chinese#^zh-Q0058|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E9%80%99%E6%98%AF%E6%B9%AF%E5%A7%86%E5%8F%94%E5%8F%94%E7%9A%84%E8%BE%B2%E5%A0%B4%E3%80%82)
^zh-Q0058-answer

**zh-Q0059** — 那是一隻有惡意的兔子。

That was an evil bunny.

Why: Identity with 是. [[Mandarin Chinese#^zh-Q0059|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E9%82%A3%E6%98%AF%E4%B8%80%E9%9A%BB%E6%9C%89%E6%83%A1%E6%84%8F%E7%9A%84%E5%85%94%E5%AD%90%E3%80%82)
^zh-Q0059-answer

**zh-Q0060** — 那是一隻有惡意的兔子。

That was an evil bunny.

是 commonly links identity or classification. Ordinary adjectival predicates do not require 是 merely because English uses be. 是 also appears in focus constructions, so read the whole predicate.

Why: Identity with 是. [[Mandarin Chinese#^zh-Q0060|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E9%82%A3%E6%98%AF%E4%B8%80%E9%9A%BB%E6%9C%89%E6%83%A1%E6%84%8F%E7%9A%84%E5%85%94%E5%AD%90%E3%80%82)
^zh-Q0060-answer

**zh-Q0061** — 這是無可否認的事實。

There is no denying the fact.

Expected form: **是**

Why: Identity with 是. [[Mandarin Chinese#^zh-Q0061|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E9%80%99%E6%98%AF%E7%84%A1%E5%8F%AF%E5%90%A6%E8%AA%8D%E7%9A%84%E4%BA%8B%E5%AF%A6%E3%80%82)
^zh-Q0061-answer

**zh-Q0062** — 這是無可否認的事實。

There is no denying the fact.

Expected form: **是**

Why: Identity with 是. [[Mandarin Chinese#^zh-Q0062|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E9%80%99%E6%98%AF%E7%84%A1%E5%8F%AF%E5%90%A6%E8%AA%8D%E7%9A%84%E4%BA%8B%E5%AF%A6%E3%80%82)
^zh-Q0062-answer

**zh-Q0063** — 不是所有的临床研究都是假设驱动的。

Not all clinical studies are hypothesis-driven.

Expected form: **是**

Why: Identity with 是. [[Mandarin Chinese#^zh-Q0063|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%B8%8D%E6%98%AF%E6%89%80%E6%9C%89%E7%9A%84%E4%B8%B4%E5%BA%8A%E7%A0%94%E7%A9%B6%E9%83%BD%E6%98%AF%E5%81%87%E8%AE%BE%E9%A9%B1%E5%8A%A8%E7%9A%84%E3%80%82)
^zh-Q0063-answer

**zh-Q0064** — 不是所有的临床研究都是假设驱动的。

Not all clinical studies are hypothesis-driven.

Why: Identity with 是. [[Mandarin Chinese#^zh-Q0064|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%B8%8D%E6%98%AF%E6%89%80%E6%9C%89%E7%9A%84%E4%B8%B4%E5%BA%8A%E7%A0%94%E7%A9%B6%E9%83%BD%E6%98%AF%E5%81%87%E8%AE%BE%E9%A9%B1%E5%8A%A8%E7%9A%84%E3%80%82)
^zh-Q0064-answer

**zh-Q0065** — 你是中国人还是日本人？

Are you Chinese or Japanese?

Why: Identity with 是. [[Mandarin Chinese#^zh-Q0065|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E6%98%AF%E4%B8%AD%E5%9B%BD%E4%BA%BA%E8%BF%98%E6%98%AF%E6%97%A5%E6%9C%AC%E4%BA%BA%EF%BC%9F)
^zh-Q0065-answer

**zh-Q0066** — 你是中国人还是日本人？

Are you Chinese or Japanese?

是 commonly links identity or classification. Ordinary adjectival predicates do not require 是 merely because English uses be. 是 also appears in focus constructions, so read the whole predicate.

Why: Identity with 是. [[Mandarin Chinese#^zh-Q0066|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E6%98%AF%E4%B8%AD%E5%9B%BD%E4%BA%BA%E8%BF%98%E6%98%AF%E6%97%A5%E6%9C%AC%E4%BA%BA%EF%BC%9F)
^zh-Q0066-answer

**zh-Q0067** — 歐盟盟旗的十二顆星代表的不是創立聯盟的十二個會員國，而是十二門徒。

The twelve stars on the flag of the European Union do not symbolize the twelve founding members of the union. They symbolize the Twelve Apostles.

Expected form: **是**

Why: Identity with 是. [[Mandarin Chinese#^zh-Q0067|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%AD%90%E7%9B%9F%E7%9B%9F%E6%97%97%E7%9A%84%E5%8D%81%E4%BA%8C%E9%A1%86%E6%98%9F%E4%BB%A3%E8%A1%A8%E7%9A%84%E4%B8%8D%E6%98%AF%E5%89%B5%E7%AB%8B%E8%81%AF%E7%9B%9F%E7%9A%84%E5%8D%81%E4%BA%8C%E5%80%8B%E6%9C%83%E5%93%A1%E5%9C%8B%EF%BC%8C%E8%80%8C%E6%98%AF%E5%8D%81%E4%BA%8C%E9%96%80%E5%BE%92%E3%80%82)
^zh-Q0067-answer

**zh-Q0068** — 歐盟盟旗的十二顆星代表的不是創立聯盟的十二個會員國，而是十二門徒。

The twelve stars on the flag of the European Union do not symbolize the twelve founding members of the union. They symbolize the Twelve Apostles.

Expected form: **是**

Why: Identity with 是. [[Mandarin Chinese#^zh-Q0068|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%AD%90%E7%9B%9F%E7%9B%9F%E6%97%97%E7%9A%84%E5%8D%81%E4%BA%8C%E9%A1%86%E6%98%9F%E4%BB%A3%E8%A1%A8%E7%9A%84%E4%B8%8D%E6%98%AF%E5%89%B5%E7%AB%8B%E8%81%AF%E7%9B%9F%E7%9A%84%E5%8D%81%E4%BA%8C%E5%80%8B%E6%9C%83%E5%93%A1%E5%9C%8B%EF%BC%8C%E8%80%8C%E6%98%AF%E5%8D%81%E4%BA%8C%E9%96%80%E5%BE%92%E3%80%82)
^zh-Q0068-answer

**zh-Q0069** — 爱和被爱是最大的幸福。

To love and to be loved is the greatest happiness.

Expected form: **是**

Why: Identity with 是. [[Mandarin Chinese#^zh-Q0069|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E7%88%B1%E5%92%8C%E8%A2%AB%E7%88%B1%E6%98%AF%E6%9C%80%E5%A4%A7%E7%9A%84%E5%B9%B8%E7%A6%8F%E3%80%82)
^zh-Q0069-answer

**zh-Q0070** — 爱和被爱是最大的幸福。

To love and to be loved is the greatest happiness.

Why: Identity with 是. [[Mandarin Chinese#^zh-Q0070|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E7%88%B1%E5%92%8C%E8%A2%AB%E7%88%B1%E6%98%AF%E6%9C%80%E5%A4%A7%E7%9A%84%E5%B9%B8%E7%A6%8F%E3%80%82)
^zh-Q0070-answer

**zh-Q0071** — 你喜欢的歌手是谁？

Who is your favourite singer?

Why: Identity with 是. [[Mandarin Chinese#^zh-Q0071|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E5%96%9C%E6%AC%A2%E7%9A%84%E6%AD%8C%E6%89%8B%E6%98%AF%E8%B0%81%EF%BC%9F)
^zh-Q0071-answer

**zh-Q0072** — 你喜欢的歌手是谁？

Who is your favourite singer?

是 commonly links identity or classification. Ordinary adjectival predicates do not require 是 merely because English uses be. 是 also appears in focus constructions, so read the whole predicate.

Why: Identity with 是. [[Mandarin Chinese#^zh-Q0072|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E5%96%9C%E6%AC%A2%E7%9A%84%E6%AD%8C%E6%89%8B%E6%98%AF%E8%B0%81%EF%BC%9F)
^zh-Q0072-answer

**zh-Q0073** — 太棒了！是毛坯房还是装修房？

Great! Is the apartment bought as a concrete shell, or is it ready to move into?

Expected form: **是**

Why: Identity with 是. [[Mandarin Chinese#^zh-Q0073|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A4%AA%E6%A3%92%E4%BA%86%EF%BC%81%E6%98%AF%E6%AF%9B%E5%9D%AF%E6%88%BF%E8%BF%98%E6%98%AF%E8%A3%85%E4%BF%AE%E6%88%BF%EF%BC%9F)
^zh-Q0073-answer

**zh-Q0074** — 太棒了！是毛坯房还是装修房？

Great! Is the apartment bought as a concrete shell, or is it ready to move into?

Expected form: **是**

Why: Identity with 是. [[Mandarin Chinese#^zh-Q0074|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A4%AA%E6%A3%92%E4%BA%86%EF%BC%81%E6%98%AF%E6%AF%9B%E5%9D%AF%E6%88%BF%E8%BF%98%E6%98%AF%E8%A3%85%E4%BF%AE%E6%88%BF%EF%BC%9F)
^zh-Q0074-answer

**zh-Q0075** — 那件事是在十五年前發生的。

That event happened 15 years ago.

Expected form: **是**

Why: Identity with 是. [[Mandarin Chinese#^zh-Q0075|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E9%82%A3%E4%BB%B6%E4%BA%8B%E6%98%AF%E5%9C%A8%E5%8D%81%E4%BA%94%E5%B9%B4%E5%89%8D%E7%99%BC%E7%94%9F%E7%9A%84%E3%80%82)
^zh-Q0075-answer

**zh-Q0076** — 那件事是在十五年前發生的。

That event happened 15 years ago.

Why: Identity with 是. [[Mandarin Chinese#^zh-Q0076|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E9%82%A3%E4%BB%B6%E4%BA%8B%E6%98%AF%E5%9C%A8%E5%8D%81%E4%BA%94%E5%B9%B4%E5%89%8D%E7%99%BC%E7%94%9F%E7%9A%84%E3%80%82)
^zh-Q0076-answer

**zh-Q0077** — 湯姆是甚麼時候來到這裡的？

When does Tom get here?

Why: Identity with 是. [[Mandarin Chinese#^zh-Q0077|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%B9%AF%E5%A7%86%E6%98%AF%E7%94%9A%E9%BA%BC%E6%99%82%E5%80%99%E4%BE%86%E5%88%B0%E9%80%99%E8%A3%A1%E7%9A%84%EF%BC%9F)
^zh-Q0077-answer

**zh-Q0078** — 湯姆是甚麼時候來到這裡的？

When does Tom get here?

是 commonly links identity or classification. Ordinary adjectival predicates do not require 是 merely because English uses be. 是 also appears in focus constructions, so read the whole predicate.

Why: Identity with 是. [[Mandarin Chinese#^zh-Q0078|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%B9%AF%E5%A7%86%E6%98%AF%E7%94%9A%E9%BA%BC%E6%99%82%E5%80%99%E4%BE%86%E5%88%B0%E9%80%99%E8%A3%A1%E7%9A%84%EF%BC%9F)
^zh-Q0078-answer

**zh-Q0079** — 她是一位真正的美人。

She is a real beauty.

Expected form: **是**

Why: Identity with 是. [[Mandarin Chinese#^zh-Q0079|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A5%B9%E6%98%AF%E4%B8%80%E4%BD%8D%E7%9C%9F%E6%AD%A3%E7%9A%84%E7%BE%8E%E4%BA%BA%E3%80%82)
^zh-Q0079-answer

**zh-Q0080** — 她是一位真正的美人。

She is a real beauty.

Expected form: **是**

Why: Identity with 是. [[Mandarin Chinese#^zh-Q0080|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A5%B9%E6%98%AF%E4%B8%80%E4%BD%8D%E7%9C%9F%E6%AD%A3%E7%9A%84%E7%BE%8E%E4%BA%BA%E3%80%82)
^zh-Q0080-answer

**zh-Q0081** — 數學是所有科學的基礎。

Mathematics is basic to all sciences.

Expected form: **是**

Why: Identity with 是. [[Mandarin Chinese#^zh-Q0081|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%95%B8%E5%AD%B8%E6%98%AF%E6%89%80%E6%9C%89%E7%A7%91%E5%AD%B8%E7%9A%84%E5%9F%BA%E7%A4%8E%E3%80%82)
^zh-Q0081-answer

**zh-Q0082** — 數學是所有科學的基礎。

Mathematics is basic to all sciences.

Why: Identity with 是. [[Mandarin Chinese#^zh-Q0082|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%95%B8%E5%AD%B8%E6%98%AF%E6%89%80%E6%9C%89%E7%A7%91%E5%AD%B8%E7%9A%84%E5%9F%BA%E7%A4%8E%E3%80%82)
^zh-Q0082-answer

**zh-Q0083** — Tatoeba回來了，但不是每樣東西都會正常運作。

Tatoeba is back, but not everything will be working perfectly.

Why: Identity with 是. [[Mandarin Chinese#^zh-Q0083|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=Tatoeba%E5%9B%9E%E4%BE%86%E4%BA%86%EF%BC%8C%E4%BD%86%E4%B8%8D%E6%98%AF%E6%AF%8F%E6%A8%A3%E6%9D%B1%E8%A5%BF%E9%83%BD%E6%9C%83%E6%AD%A3%E5%B8%B8%E9%81%8B%E4%BD%9C%E3%80%82)
^zh-Q0083-answer

**zh-Q0084** — Tatoeba回來了，但不是每樣東西都會正常運作。

Tatoeba is back, but not everything will be working perfectly.

是 commonly links identity or classification. Ordinary adjectival predicates do not require 是 merely because English uses be. 是 also appears in focus constructions, so read the whole predicate.

Why: Identity with 是. [[Mandarin Chinese#^zh-Q0084|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=Tatoeba%E5%9B%9E%E4%BE%86%E4%BA%86%EF%BC%8C%E4%BD%86%E4%B8%8D%E6%98%AF%E6%AF%8F%E6%A8%A3%E6%9D%B1%E8%A5%BF%E9%83%BD%E6%9C%83%E6%AD%A3%E5%B8%B8%E9%81%8B%E4%BD%9C%E3%80%82)
^zh-Q0084-answer

**zh-Q0085** — 在20世紀期間，滿洲國是一個傀儡國家。

During the 20th century, Manchukuo was a puppet state.

Expected form: **是**

Why: Identity with 是. [[Mandarin Chinese#^zh-Q0085|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%9C%A820%E4%B8%96%E7%B4%80%E6%9C%9F%E9%96%93%EF%BC%8C%E6%BB%BF%E6%B4%B2%E5%9C%8B%E6%98%AF%E4%B8%80%E5%80%8B%E5%82%80%E5%84%A1%E5%9C%8B%E5%AE%B6%E3%80%82)
^zh-Q0085-answer

**zh-Q0086** — 在20世紀期間，滿洲國是一個傀儡國家。

During the 20th century, Manchukuo was a puppet state.

Expected form: **是**

Why: Identity with 是. [[Mandarin Chinese#^zh-Q0086|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%9C%A820%E4%B8%96%E7%B4%80%E6%9C%9F%E9%96%93%EF%BC%8C%E6%BB%BF%E6%B4%B2%E5%9C%8B%E6%98%AF%E4%B8%80%E5%80%8B%E5%82%80%E5%84%A1%E5%9C%8B%E5%AE%B6%E3%80%82)
^zh-Q0086-answer

**zh-Q0087** — 哈里发塔是现时世界上最高的摩天大楼。

Burj Khalifa is currently the tallest skyscraper in the world.

Expected form: **是**

Why: Identity with 是. [[Mandarin Chinese#^zh-Q0087|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%93%88%E9%87%8C%E5%8F%91%E5%A1%94%E6%98%AF%E7%8E%B0%E6%97%B6%E4%B8%96%E7%95%8C%E4%B8%8A%E6%9C%80%E9%AB%98%E7%9A%84%E6%91%A9%E5%A4%A9%E5%A4%A7%E6%A5%BC%E3%80%82)
^zh-Q0087-answer

**zh-Q0088** — 哈里发塔是现时世界上最高的摩天大楼。

Burj Khalifa is currently the tallest skyscraper in the world.

Why: Identity with 是. [[Mandarin Chinese#^zh-Q0088|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%93%88%E9%87%8C%E5%8F%91%E5%A1%94%E6%98%AF%E7%8E%B0%E6%97%B6%E4%B8%96%E7%95%8C%E4%B8%8A%E6%9C%80%E9%AB%98%E7%9A%84%E6%91%A9%E5%A4%A9%E5%A4%A7%E6%A5%BC%E3%80%82)
^zh-Q0088-answer

**zh-Q0089** — 这是一笔不错的交易。

It's a good deal.

Why: Identity with 是. [[Mandarin Chinese#^zh-Q0089|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%BF%99%E6%98%AF%E4%B8%80%E7%AC%94%E4%B8%8D%E9%94%99%E7%9A%84%E4%BA%A4%E6%98%93%E3%80%82)
^zh-Q0089-answer

**zh-Q0090** — 这是一笔不错的交易。

It's a good deal.

是 commonly links identity or classification. Ordinary adjectival predicates do not require 是 merely because English uses be. 是 also appears in focus constructions, so read the whole predicate.

Why: Identity with 是. [[Mandarin Chinese#^zh-Q0090|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%BF%99%E6%98%AF%E4%B8%80%E7%AC%94%E4%B8%8D%E9%94%99%E7%9A%84%E4%BA%A4%E6%98%93%E3%80%82)
^zh-Q0090-answer

**zh-Q0091** — 月饼是中国点心的一种。

The mooncake is a kind of Chinese snack.

Expected form: **是**

Why: Identity with 是. [[Mandarin Chinese#^zh-Q0091|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%9C%88%E9%A5%BC%E6%98%AF%E4%B8%AD%E5%9B%BD%E7%82%B9%E5%BF%83%E7%9A%84%E4%B8%80%E7%A7%8D%E3%80%82)
^zh-Q0091-answer

**zh-Q0092** — 月饼是中国点心的一种。

The mooncake is a kind of Chinese snack.

Expected form: **是**

Why: Identity with 是. [[Mandarin Chinese#^zh-Q0092|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%9C%88%E9%A5%BC%E6%98%AF%E4%B8%AD%E5%9B%BD%E7%82%B9%E5%BF%83%E7%9A%84%E4%B8%80%E7%A7%8D%E3%80%82)
^zh-Q0092-answer

**zh-Q0093** — 他還沒有來，不知道是不是發生了甚麼意外？

He has not come yet. Something may have happened to him.

Expected form: **是**

Why: Identity with 是. [[Mandarin Chinese#^zh-Q0093|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%96%E9%82%84%E6%B2%92%E6%9C%89%E4%BE%86%EF%BC%8C%E4%B8%8D%E7%9F%A5%E9%81%93%E6%98%AF%E4%B8%8D%E6%98%AF%E7%99%BC%E7%94%9F%E4%BA%86%E7%94%9A%E9%BA%BC%E6%84%8F%E5%A4%96%EF%BC%9F)
^zh-Q0093-answer

**zh-Q0094** — 他還沒有來，不知道是不是發生了甚麼意外？

He has not come yet. Something may have happened to him.

Why: Identity with 是. [[Mandarin Chinese#^zh-Q0094|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%96%E9%82%84%E6%B2%92%E6%9C%89%E4%BE%86%EF%BC%8C%E4%B8%8D%E7%9F%A5%E9%81%93%E6%98%AF%E4%B8%8D%E6%98%AF%E7%99%BC%E7%94%9F%E4%BA%86%E7%94%9A%E9%BA%BC%E6%84%8F%E5%A4%96%EF%BC%9F)
^zh-Q0094-answer

**zh-Q0095** — 开始的时候，我们以为我们什么都知道，但后来发现，事实是我们什么都不知道。

When we started, we thought that we knew everything, but we later discovered that we did not.

Why: Identity with 是. [[Mandarin Chinese#^zh-Q0095|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%BC%80%E5%A7%8B%E7%9A%84%E6%97%B6%E5%80%99%EF%BC%8C%E6%88%91%E4%BB%AC%E4%BB%A5%E4%B8%BA%E6%88%91%E4%BB%AC%E4%BB%80%E4%B9%88%E9%83%BD%E7%9F%A5%E9%81%93%EF%BC%8C%E4%BD%86%E5%90%8E%E6%9D%A5%E5%8F%91%E7%8E%B0%EF%BC%8C%E4%BA%8B%E5%AE%9E%E6%98%AF%E6%88%91%E4%BB%AC%E4%BB%80%E4%B9%88%E9%83%BD%E4%B8%8D%E7%9F%A5%E9%81%93%E3%80%82)
^zh-Q0095-answer

**zh-Q0096** — 开始的时候，我们以为我们什么都知道，但后来发现，事实是我们什么都不知道。

When we started, we thought that we knew everything, but we later discovered that we did not.

是 commonly links identity or classification. Ordinary adjectival predicates do not require 是 merely because English uses be. 是 also appears in focus constructions, so read the whole predicate.

Why: Identity with 是. [[Mandarin Chinese#^zh-Q0096|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%BC%80%E5%A7%8B%E7%9A%84%E6%97%B6%E5%80%99%EF%BC%8C%E6%88%91%E4%BB%AC%E4%BB%A5%E4%B8%BA%E6%88%91%E4%BB%AC%E4%BB%80%E4%B9%88%E9%83%BD%E7%9F%A5%E9%81%93%EF%BC%8C%E4%BD%86%E5%90%8E%E6%9D%A5%E5%8F%91%E7%8E%B0%EF%BC%8C%E4%BA%8B%E5%AE%9E%E6%98%AF%E6%88%91%E4%BB%AC%E4%BB%80%E4%B9%88%E9%83%BD%E4%B8%8D%E7%9F%A5%E9%81%93%E3%80%82)
^zh-Q0096-answer

**zh-Q0097** — 现在中国公认的标准旗袍的现代版本是首先在上海发展起来的。

The modern version, which is now popularly recognized in China as the standard qipao, was first developed in Shanghai after 1900.

Expected form: **是**

Why: Identity with 是. [[Mandarin Chinese#^zh-Q0097|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E7%8E%B0%E5%9C%A8%E4%B8%AD%E5%9B%BD%E5%85%AC%E8%AE%A4%E7%9A%84%E6%A0%87%E5%87%86%E6%97%97%E8%A2%8D%E7%9A%84%E7%8E%B0%E4%BB%A3%E7%89%88%E6%9C%AC%E6%98%AF%E9%A6%96%E5%85%88%E5%9C%A8%E4%B8%8A%E6%B5%B7%E5%8F%91%E5%B1%95%E8%B5%B7%E6%9D%A5%E7%9A%84%E3%80%82)
^zh-Q0097-answer

**zh-Q0098** — 现在中国公认的标准旗袍的现代版本是首先在上海发展起来的。

The modern version, which is now popularly recognized in China as the standard qipao, was first developed in Shanghai after 1900.

Expected form: **是**

Why: Identity with 是. [[Mandarin Chinese#^zh-Q0098|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E7%8E%B0%E5%9C%A8%E4%B8%AD%E5%9B%BD%E5%85%AC%E8%AE%A4%E7%9A%84%E6%A0%87%E5%87%86%E6%97%97%E8%A2%8D%E7%9A%84%E7%8E%B0%E4%BB%A3%E7%89%88%E6%9C%AC%E6%98%AF%E9%A6%96%E5%85%88%E5%9C%A8%E4%B8%8A%E6%B5%B7%E5%8F%91%E5%B1%95%E8%B5%B7%E6%9D%A5%E7%9A%84%E3%80%82)
^zh-Q0098-answer

**zh-Q0099** — 美国是一个自称没有社会阶层的国家。

America likes to claim that it is a "classless" society.

Expected form: **是**

Why: Identity with 是. [[Mandarin Chinese#^zh-Q0099|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E7%BE%8E%E5%9B%BD%E6%98%AF%E4%B8%80%E4%B8%AA%E8%87%AA%E7%A7%B0%E6%B2%A1%E6%9C%89%E7%A4%BE%E4%BC%9A%E9%98%B6%E5%B1%82%E7%9A%84%E5%9B%BD%E5%AE%B6%E3%80%82)
^zh-Q0099-answer

**zh-Q0100** — 美国是一个自称没有社会阶层的国家。

America likes to claim that it is a "classless" society.

Why: Identity with 是. [[Mandarin Chinese#^zh-Q0100|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E7%BE%8E%E5%9B%BD%E6%98%AF%E4%B8%80%E4%B8%AA%E8%87%AA%E7%A7%B0%E6%B2%A1%E6%9C%89%E7%A4%BE%E4%BC%9A%E9%98%B6%E5%B1%82%E7%9A%84%E5%9B%BD%E5%AE%B6%E3%80%82)
^zh-Q0100-answer


### Answers 101–150

**zh-Q0101** — 汤姆有玛丽的地址。

Tom has Mary's address.

Why: Possession and existence 有. [[Mandarin Chinese#^zh-Q0101|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%B1%A4%E5%A7%86%E6%9C%89%E7%8E%9B%E4%B8%BD%E7%9A%84%E5%9C%B0%E5%9D%80%E3%80%82)
^zh-Q0101-answer

**zh-Q0102** — 汤姆有玛丽的地址。

Tom has Mary's address.

有 expresses possession or existence. Its common negation is 没有, not 不有. A location phrase can precede an existence statement to introduce a new referent.

Why: Possession and existence 有. [[Mandarin Chinese#^zh-Q0102|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%B1%A4%E5%A7%86%E6%9C%89%E7%8E%9B%E4%B8%BD%E7%9A%84%E5%9C%B0%E5%9D%80%E3%80%82)
^zh-Q0102-answer

**zh-Q0103** — 他的英文作文沒有甚麼錯處。

Errors are few, if any, in his English composition.

Expected form: **有**

Why: Possession and existence 有. [[Mandarin Chinese#^zh-Q0103|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%96%E7%9A%84%E8%8B%B1%E6%96%87%E4%BD%9C%E6%96%87%E6%B2%92%E6%9C%89%E7%94%9A%E9%BA%BC%E9%8C%AF%E8%99%95%E3%80%82)
^zh-Q0103-answer

**zh-Q0104** — 他的英文作文沒有甚麼錯處。

Errors are few, if any, in his English composition.

Expected form: **有**

Why: Possession and existence 有. [[Mandarin Chinese#^zh-Q0104|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%96%E7%9A%84%E8%8B%B1%E6%96%87%E4%BD%9C%E6%96%87%E6%B2%92%E6%9C%89%E7%94%9A%E9%BA%BC%E9%8C%AF%E8%99%95%E3%80%82)
^zh-Q0104-answer

**zh-Q0105** — 上海这个地方，海内海外什么菜肴都有。

Shanghai has everything under the sun when it comes to food.

Expected form: **有**

Why: Possession and existence 有. [[Mandarin Chinese#^zh-Q0105|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%B8%8A%E6%B5%B7%E8%BF%99%E4%B8%AA%E5%9C%B0%E6%96%B9%EF%BC%8C%E6%B5%B7%E5%86%85%E6%B5%B7%E5%A4%96%E4%BB%80%E4%B9%88%E8%8F%9C%E8%82%B4%E9%83%BD%E6%9C%89%E3%80%82)
^zh-Q0105-answer

**zh-Q0106** — 上海这个地方，海内海外什么菜肴都有。

Shanghai has everything under the sun when it comes to food.

Why: Possession and existence 有. [[Mandarin Chinese#^zh-Q0106|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%B8%8A%E6%B5%B7%E8%BF%99%E4%B8%AA%E5%9C%B0%E6%96%B9%EF%BC%8C%E6%B5%B7%E5%86%85%E6%B5%B7%E5%A4%96%E4%BB%80%E4%B9%88%E8%8F%9C%E8%82%B4%E9%83%BD%E6%9C%89%E3%80%82)
^zh-Q0106-answer

**zh-Q0107** — 难道我没有告诉你演唱会的时候要早点去吗？

I thought I told you that you should get to the concert early.

Why: Possession and existence 有. [[Mandarin Chinese#^zh-Q0107|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E9%9A%BE%E9%81%93%E6%88%91%E6%B2%A1%E6%9C%89%E5%91%8A%E8%AF%89%E4%BD%A0%E6%BC%94%E5%94%B1%E4%BC%9A%E7%9A%84%E6%97%B6%E5%80%99%E8%A6%81%E6%97%A9%E7%82%B9%E5%8E%BB%E5%90%97%EF%BC%9F)
^zh-Q0107-answer

**zh-Q0108** — 难道我没有告诉你演唱会的时候要早点去吗？

I thought I told you that you should get to the concert early.

有 expresses possession or existence. Its common negation is 没有, not 不有. A location phrase can precede an existence statement to introduce a new referent.

Why: Possession and existence 有. [[Mandarin Chinese#^zh-Q0108|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E9%9A%BE%E9%81%93%E6%88%91%E6%B2%A1%E6%9C%89%E5%91%8A%E8%AF%89%E4%BD%A0%E6%BC%94%E5%94%B1%E4%BC%9A%E7%9A%84%E6%97%B6%E5%80%99%E8%A6%81%E6%97%A9%E7%82%B9%E5%8E%BB%E5%90%97%EF%BC%9F)
^zh-Q0108-answer

**zh-Q0109** — Tatoeba：加入黑暗的一面。我们有巧克力曲奇饼。

Tatoeba: Join the dark side. We have chocolate cookies.

Expected form: **有**

Why: Possession and existence 有. [[Mandarin Chinese#^zh-Q0109|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=Tatoeba%EF%BC%9A%E5%8A%A0%E5%85%A5%E9%BB%91%E6%9A%97%E7%9A%84%E4%B8%80%E9%9D%A2%E3%80%82%E6%88%91%E4%BB%AC%E6%9C%89%E5%B7%A7%E5%85%8B%E5%8A%9B%E6%9B%B2%E5%A5%87%E9%A5%BC%E3%80%82)
^zh-Q0109-answer

**zh-Q0110** — Tatoeba：加入黑暗的一面。我们有巧克力曲奇饼。

Tatoeba: Join the dark side. We have chocolate cookies.

Expected form: **有**

Why: Possession and existence 有. [[Mandarin Chinese#^zh-Q0110|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=Tatoeba%EF%BC%9A%E5%8A%A0%E5%85%A5%E9%BB%91%E6%9A%97%E7%9A%84%E4%B8%80%E9%9D%A2%E3%80%82%E6%88%91%E4%BB%AC%E6%9C%89%E5%B7%A7%E5%85%8B%E5%8A%9B%E6%9B%B2%E5%A5%87%E9%A5%BC%E3%80%82)
^zh-Q0110-answer

**zh-Q0111** — 我居然忘记了今天有课！

I completely forgot that there was class today!

Expected form: **有**

Why: Possession and existence 有. [[Mandarin Chinese#^zh-Q0111|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E5%B1%85%E7%84%B6%E5%BF%98%E8%AE%B0%E4%BA%86%E4%BB%8A%E5%A4%A9%E6%9C%89%E8%AF%BE%EF%BC%81)
^zh-Q0111-answer

**zh-Q0112** — 我居然忘记了今天有课！

I completely forgot that there was class today!

Why: Possession and existence 有. [[Mandarin Chinese#^zh-Q0112|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E5%B1%85%E7%84%B6%E5%BF%98%E8%AE%B0%E4%BA%86%E4%BB%8A%E5%A4%A9%E6%9C%89%E8%AF%BE%EF%BC%81)
^zh-Q0112-answer

**zh-Q0113** — 我對日本歷史有興趣。

I am interested in Japanese history.

Why: Possession and existence 有. [[Mandarin Chinese#^zh-Q0113|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E5%B0%8D%E6%97%A5%E6%9C%AC%E6%AD%B7%E5%8F%B2%E6%9C%89%E8%88%88%E8%B6%A3%E3%80%82)
^zh-Q0113-answer

**zh-Q0114** — 我對日本歷史有興趣。

I am interested in Japanese history.

有 expresses possession or existence. Its common negation is 没有, not 不有. A location phrase can precede an existence statement to introduce a new referent.

Why: Possession and existence 有. [[Mandarin Chinese#^zh-Q0114|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E5%B0%8D%E6%97%A5%E6%9C%AC%E6%AD%B7%E5%8F%B2%E6%9C%89%E8%88%88%E8%B6%A3%E3%80%82)
^zh-Q0114-answer

**zh-Q0115** — 汤姆有一辆灰色的车。

Tom has a gray car.

Expected form: **有**

Why: Possession and existence 有. [[Mandarin Chinese#^zh-Q0115|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%B1%A4%E5%A7%86%E6%9C%89%E4%B8%80%E8%BE%86%E7%81%B0%E8%89%B2%E7%9A%84%E8%BD%A6%E3%80%82)
^zh-Q0115-answer

**zh-Q0116** — 汤姆有一辆灰色的车。

Tom has a gray car.

Expected form: **有**

Why: Possession and existence 有. [[Mandarin Chinese#^zh-Q0116|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%B1%A4%E5%A7%86%E6%9C%89%E4%B8%80%E8%BE%86%E7%81%B0%E8%89%B2%E7%9A%84%E8%BD%A6%E3%80%82)
^zh-Q0116-answer

**zh-Q0117** — 我曾有个朋友叫汤姆。

I used to have a friend named Tom.

Expected form: **有**

Why: Possession and existence 有. [[Mandarin Chinese#^zh-Q0117|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E6%9B%BE%E6%9C%89%E4%B8%AA%E6%9C%8B%E5%8F%8B%E5%8F%AB%E6%B1%A4%E5%A7%86%E3%80%82)
^zh-Q0117-answer

**zh-Q0118** — 我曾有个朋友叫汤姆。

I used to have a friend named Tom.

Why: Possession and existence 有. [[Mandarin Chinese#^zh-Q0118|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E6%9B%BE%E6%9C%89%E4%B8%AA%E6%9C%8B%E5%8F%8B%E5%8F%AB%E6%B1%A4%E5%A7%86%E3%80%82)
^zh-Q0118-answer

**zh-Q0119** — 有人看到了她在饭馆跟她爱人在一起。

She was seen at a restaurant with her lover.

Why: Possession and existence 有. [[Mandarin Chinese#^zh-Q0119|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%9C%89%E4%BA%BA%E7%9C%8B%E5%88%B0%E4%BA%86%E5%A5%B9%E5%9C%A8%E9%A5%AD%E9%A6%86%E8%B7%9F%E5%A5%B9%E7%88%B1%E4%BA%BA%E5%9C%A8%E4%B8%80%E8%B5%B7%E3%80%82)
^zh-Q0119-answer

**zh-Q0120** — 有人看到了她在饭馆跟她爱人在一起。

She was seen at a restaurant with her lover.

有 expresses possession or existence. Its common negation is 没有, not 不有. A location phrase can precede an existence statement to introduce a new referent.

Why: Possession and existence 有. [[Mandarin Chinese#^zh-Q0120|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%9C%89%E4%BA%BA%E7%9C%8B%E5%88%B0%E4%BA%86%E5%A5%B9%E5%9C%A8%E9%A5%AD%E9%A6%86%E8%B7%9F%E5%A5%B9%E7%88%B1%E4%BA%BA%E5%9C%A8%E4%B8%80%E8%B5%B7%E3%80%82)
^zh-Q0120-answer

**zh-Q0121** — 沒有水，沒有東西能生活在這個地球上。

Without water, nothing could live on this earth.

Expected form: **有**

Why: Possession and existence 有. [[Mandarin Chinese#^zh-Q0121|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%B2%92%E6%9C%89%E6%B0%B4%EF%BC%8C%E6%B2%92%E6%9C%89%E6%9D%B1%E8%A5%BF%E8%83%BD%E7%94%9F%E6%B4%BB%E5%9C%A8%E9%80%99%E5%80%8B%E5%9C%B0%E7%90%83%E4%B8%8A%E3%80%82)
^zh-Q0121-answer

**zh-Q0122** — 沒有水，沒有東西能生活在這個地球上。

Without water, nothing could live on this earth.

Expected form: **有**

Why: Possession and existence 有. [[Mandarin Chinese#^zh-Q0122|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%B2%92%E6%9C%89%E6%B0%B4%EF%BC%8C%E6%B2%92%E6%9C%89%E6%9D%B1%E8%A5%BF%E8%83%BD%E7%94%9F%E6%B4%BB%E5%9C%A8%E9%80%99%E5%80%8B%E5%9C%B0%E7%90%83%E4%B8%8A%E3%80%82)
^zh-Q0122-answer

**zh-Q0123** — 这种说法其实有点可疑。

This statement is actually kind of suspicious.

Expected form: **有**

Why: Possession and existence 有. [[Mandarin Chinese#^zh-Q0123|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%BF%99%E7%A7%8D%E8%AF%B4%E6%B3%95%E5%85%B6%E5%AE%9E%E6%9C%89%E7%82%B9%E5%8F%AF%E7%96%91%E3%80%82)
^zh-Q0123-answer

**zh-Q0124** — 这种说法其实有点可疑。

This statement is actually kind of suspicious.

Why: Possession and existence 有. [[Mandarin Chinese#^zh-Q0124|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%BF%99%E7%A7%8D%E8%AF%B4%E6%B3%95%E5%85%B6%E5%AE%9E%E6%9C%89%E7%82%B9%E5%8F%AF%E7%96%91%E3%80%82)
^zh-Q0124-answer

**zh-Q0125** — 警察沒有拖走你的車。

The policeman didn't tow your car away.

Why: Possession and existence 有. [[Mandarin Chinese#^zh-Q0125|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%AD%A6%E5%AF%9F%E6%B2%92%E6%9C%89%E6%8B%96%E8%B5%B0%E4%BD%A0%E7%9A%84%E8%BB%8A%E3%80%82)
^zh-Q0125-answer

**zh-Q0126** — 警察沒有拖走你的車。

The policeman didn't tow your car away.

有 expresses possession or existence. Its common negation is 没有, not 不有. A location phrase can precede an existence statement to introduce a new referent.

Why: Possession and existence 有. [[Mandarin Chinese#^zh-Q0126|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%AD%A6%E5%AF%9F%E6%B2%92%E6%9C%89%E6%8B%96%E8%B5%B0%E4%BD%A0%E7%9A%84%E8%BB%8A%E3%80%82)
^zh-Q0126-answer

**zh-Q0127** — 他沒有遵循我們的忠告。

He failed to follow our advice.

Expected form: **有**

Why: Possession and existence 有. [[Mandarin Chinese#^zh-Q0127|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%96%E6%B2%92%E6%9C%89%E9%81%B5%E5%BE%AA%E6%88%91%E5%80%91%E7%9A%84%E5%BF%A0%E5%91%8A%E3%80%82)
^zh-Q0127-answer

**zh-Q0128** — 他沒有遵循我們的忠告。

He failed to follow our advice.

Expected form: **有**

Why: Possession and existence 有. [[Mandarin Chinese#^zh-Q0128|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%96%E6%B2%92%E6%9C%89%E9%81%B5%E5%BE%AA%E6%88%91%E5%80%91%E7%9A%84%E5%BF%A0%E5%91%8A%E3%80%82)
^zh-Q0128-answer

**zh-Q0129** — 沒有必要回那封信。

It isn't necessary to answer that letter.

Expected form: **有**

Why: Possession and existence 有. [[Mandarin Chinese#^zh-Q0129|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%B2%92%E6%9C%89%E5%BF%85%E8%A6%81%E5%9B%9E%E9%82%A3%E5%B0%81%E4%BF%A1%E3%80%82)
^zh-Q0129-answer

**zh-Q0130** — 沒有必要回那封信。

It isn't necessary to answer that letter.

Why: Possession and existence 有. [[Mandarin Chinese#^zh-Q0130|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%B2%92%E6%9C%89%E5%BF%85%E8%A6%81%E5%9B%9E%E9%82%A3%E5%B0%81%E4%BF%A1%E3%80%82)
^zh-Q0130-answer

**zh-Q0131** — 你有没有想过跟朋友的前男友约会？

Would you ever consider dating your best friend's ex-boyfriend?

Why: Possession and existence 有. [[Mandarin Chinese#^zh-Q0131|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E6%9C%89%E6%B2%A1%E6%9C%89%E6%83%B3%E8%BF%87%E8%B7%9F%E6%9C%8B%E5%8F%8B%E7%9A%84%E5%89%8D%E7%94%B7%E5%8F%8B%E7%BA%A6%E4%BC%9A%EF%BC%9F)
^zh-Q0131-answer

**zh-Q0132** — 你有没有想过跟朋友的前男友约会？

Would you ever consider dating your best friend's ex-boyfriend?

有 expresses possession or existence. Its common negation is 没有, not 不有. A location phrase can precede an existence statement to introduce a new referent.

Why: Possession and existence 有. [[Mandarin Chinese#^zh-Q0132|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E6%9C%89%E6%B2%A1%E6%9C%89%E6%83%B3%E8%BF%87%E8%B7%9F%E6%9C%8B%E5%8F%8B%E7%9A%84%E5%89%8D%E7%94%B7%E5%8F%8B%E7%BA%A6%E4%BC%9A%EF%BC%9F)
^zh-Q0132-answer

**zh-Q0133** — 你給我的資料沒有多大的用處。

The information you gave me is of little use.

Expected form: **有**

Why: Possession and existence 有. [[Mandarin Chinese#^zh-Q0133|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E7%B5%A6%E6%88%91%E7%9A%84%E8%B3%87%E6%96%99%E6%B2%92%E6%9C%89%E5%A4%9A%E5%A4%A7%E7%9A%84%E7%94%A8%E8%99%95%E3%80%82)
^zh-Q0133-answer

**zh-Q0134** — 你給我的資料沒有多大的用處。

The information you gave me is of little use.

Expected form: **有**

Why: Possession and existence 有. [[Mandarin Chinese#^zh-Q0134|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E7%B5%A6%E6%88%91%E7%9A%84%E8%B3%87%E6%96%99%E6%B2%92%E6%9C%89%E5%A4%9A%E5%A4%A7%E7%9A%84%E7%94%A8%E8%99%95%E3%80%82)
^zh-Q0134-answer

**zh-Q0135** — 这个教授对他的学生有很大的影响力。

The teacher has a great influence on his pupils.

Expected form: **有**

Why: Possession and existence 有. [[Mandarin Chinese#^zh-Q0135|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%BF%99%E4%B8%AA%E6%95%99%E6%8E%88%E5%AF%B9%E4%BB%96%E7%9A%84%E5%AD%A6%E7%94%9F%E6%9C%89%E5%BE%88%E5%A4%A7%E7%9A%84%E5%BD%B1%E5%93%8D%E5%8A%9B%E3%80%82)
^zh-Q0135-answer

**zh-Q0136** — 这个教授对他的学生有很大的影响力。

The teacher has a great influence on his pupils.

Why: Possession and existence 有. [[Mandarin Chinese#^zh-Q0136|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%BF%99%E4%B8%AA%E6%95%99%E6%8E%88%E5%AF%B9%E4%BB%96%E7%9A%84%E5%AD%A6%E7%94%9F%E6%9C%89%E5%BE%88%E5%A4%A7%E7%9A%84%E5%BD%B1%E5%93%8D%E5%8A%9B%E3%80%82)
^zh-Q0136-answer

**zh-Q0137** — 这个组织跟任何政党没有联系。

The organization is not connected with any political parties.

Why: Possession and existence 有. [[Mandarin Chinese#^zh-Q0137|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%BF%99%E4%B8%AA%E7%BB%84%E7%BB%87%E8%B7%9F%E4%BB%BB%E4%BD%95%E6%94%BF%E5%85%9A%E6%B2%A1%E6%9C%89%E8%81%94%E7%B3%BB%E3%80%82)
^zh-Q0137-answer

**zh-Q0138** — 这个组织跟任何政党没有联系。

The organization is not connected with any political parties.

有 expresses possession or existence. Its common negation is 没有, not 不有. A location phrase can precede an existence statement to introduce a new referent.

Why: Possession and existence 有. [[Mandarin Chinese#^zh-Q0138|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%BF%99%E4%B8%AA%E7%BB%84%E7%BB%87%E8%B7%9F%E4%BB%BB%E4%BD%95%E6%94%BF%E5%85%9A%E6%B2%A1%E6%9C%89%E8%81%94%E7%B3%BB%E3%80%82)
^zh-Q0138-answer

**zh-Q0139** — 我的三明治里有肉，奶酪和番茄。

In my sandwich there is meat, cheese and tomatoes.

Expected form: **有**

Why: Possession and existence 有. [[Mandarin Chinese#^zh-Q0139|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E7%9A%84%E4%B8%89%E6%98%8E%E6%B2%BB%E9%87%8C%E6%9C%89%E8%82%89%EF%BC%8C%E5%A5%B6%E9%85%AA%E5%92%8C%E7%95%AA%E8%8C%84%E3%80%82)
^zh-Q0139-answer

**zh-Q0140** — 我的三明治里有肉，奶酪和番茄。

In my sandwich there is meat, cheese and tomatoes.

Expected form: **有**

Why: Possession and existence 有. [[Mandarin Chinese#^zh-Q0140|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E7%9A%84%E4%B8%89%E6%98%8E%E6%B2%BB%E9%87%8C%E6%9C%89%E8%82%89%EF%BC%8C%E5%A5%B6%E9%85%AA%E5%92%8C%E7%95%AA%E8%8C%84%E3%80%82)
^zh-Q0140-answer

**zh-Q0141** — 約翰感覺到那黑漆漆的房間裏有鬼。

John felt the presence of a ghost in the dark room.

Expected form: **有**

Why: Possession and existence 有. [[Mandarin Chinese#^zh-Q0141|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E7%B4%84%E7%BF%B0%E6%84%9F%E8%A6%BA%E5%88%B0%E9%82%A3%E9%BB%91%E6%BC%86%E6%BC%86%E7%9A%84%E6%88%BF%E9%96%93%E8%A3%8F%E6%9C%89%E9%AC%BC%E3%80%82)
^zh-Q0141-answer

**zh-Q0142** — 約翰感覺到那黑漆漆的房間裏有鬼。

John felt the presence of a ghost in the dark room.

Why: Possession and existence 有. [[Mandarin Chinese#^zh-Q0142|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E7%B4%84%E7%BF%B0%E6%84%9F%E8%A6%BA%E5%88%B0%E9%82%A3%E9%BB%91%E6%BC%86%E6%BC%86%E7%9A%84%E6%88%BF%E9%96%93%E8%A3%8F%E6%9C%89%E9%AC%BC%E3%80%82)
^zh-Q0142-answer

**zh-Q0143** — 她差不多有20岁。

She is almost 20 years old.

Why: Possession and existence 有. [[Mandarin Chinese#^zh-Q0143|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A5%B9%E5%B7%AE%E4%B8%8D%E5%A4%9A%E6%9C%8920%E5%B2%81%E3%80%82)
^zh-Q0143-answer

**zh-Q0144** — 她差不多有20岁。

She is almost 20 years old.

有 expresses possession or existence. Its common negation is 没有, not 不有. A location phrase can precede an existence statement to introduce a new referent.

Why: Possession and existence 有. [[Mandarin Chinese#^zh-Q0144|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A5%B9%E5%B7%AE%E4%B8%8D%E5%A4%9A%E6%9C%8920%E5%B2%81%E3%80%82)
^zh-Q0144-answer

**zh-Q0145** — 今天穿了这件有点儿红的衬衫，我能走出去吗？

Can I go out today wearing this shirt that has a little bit of red?

Expected form: **有**

Why: Possession and existence 有. [[Mandarin Chinese#^zh-Q0145|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%8A%E5%A4%A9%E7%A9%BF%E4%BA%86%E8%BF%99%E4%BB%B6%E6%9C%89%E7%82%B9%E5%84%BF%E7%BA%A2%E7%9A%84%E8%A1%AC%E8%A1%AB%EF%BC%8C%E6%88%91%E8%83%BD%E8%B5%B0%E5%87%BA%E5%8E%BB%E5%90%97%EF%BC%9F)
^zh-Q0145-answer

**zh-Q0146** — 今天穿了这件有点儿红的衬衫，我能走出去吗？

Can I go out today wearing this shirt that has a little bit of red?

Expected form: **有**

Why: Possession and existence 有. [[Mandarin Chinese#^zh-Q0146|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%8A%E5%A4%A9%E7%A9%BF%E4%BA%86%E8%BF%99%E4%BB%B6%E6%9C%89%E7%82%B9%E5%84%BF%E7%BA%A2%E7%9A%84%E8%A1%AC%E8%A1%AB%EF%BC%8C%E6%88%91%E8%83%BD%E8%B5%B0%E5%87%BA%E5%8E%BB%E5%90%97%EF%BC%9F)
^zh-Q0146-answer

**zh-Q0147** — 你能猜到我有什么吗？

Can you guess what I have here?

Expected form: **有**

Why: Possession and existence 有. [[Mandarin Chinese#^zh-Q0147|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E8%83%BD%E7%8C%9C%E5%88%B0%E6%88%91%E6%9C%89%E4%BB%80%E4%B9%88%E5%90%97%EF%BC%9F)
^zh-Q0147-answer

**zh-Q0148** — 你能猜到我有什么吗？

Can you guess what I have here?

Why: Possession and existence 有. [[Mandarin Chinese#^zh-Q0148|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E8%83%BD%E7%8C%9C%E5%88%B0%E6%88%91%E6%9C%89%E4%BB%80%E4%B9%88%E5%90%97%EF%BC%9F)
^zh-Q0148-answer

**zh-Q0149** — 我不喜欢没有英雄的小说。

I don't like novels without heroes.

Why: Possession and existence 有. [[Mandarin Chinese#^zh-Q0149|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E4%B8%8D%E5%96%9C%E6%AC%A2%E6%B2%A1%E6%9C%89%E8%8B%B1%E9%9B%84%E7%9A%84%E5%B0%8F%E8%AF%B4%E3%80%82)
^zh-Q0149-answer

**zh-Q0150** — 我不喜欢没有英雄的小说。

I don't like novels without heroes.

有 expresses possession or existence. Its common negation is 没有, not 不有. A location phrase can precede an existence statement to introduce a new referent.

Why: Possession and existence 有. [[Mandarin Chinese#^zh-Q0150|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E4%B8%8D%E5%96%9C%E6%AC%A2%E6%B2%A1%E6%9C%89%E8%8B%B1%E9%9B%84%E7%9A%84%E5%B0%8F%E8%AF%B4%E3%80%82)
^zh-Q0150-answer


### Answers 151–200

**zh-Q0151** — 实在抱歉，老板在睡觉。请您明天再来。

I'm sorry, my boss is sleeping right now. Please come back tomorrow.

Expected form: **在**

Why: Location and ongoing 在. [[Mandarin Chinese#^zh-Q0151|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%AE%9E%E5%9C%A8%E6%8A%B1%E6%AD%89%EF%BC%8C%E8%80%81%E6%9D%BF%E5%9C%A8%E7%9D%A1%E8%A7%89%E3%80%82%E8%AF%B7%E6%82%A8%E6%98%8E%E5%A4%A9%E5%86%8D%E6%9D%A5%E3%80%82)
^zh-Q0151-answer

**zh-Q0152** — 实在抱歉，老板在睡觉。请您明天再来。

I'm sorry, my boss is sleeping right now. Please come back tomorrow.

Expected form: **在**

Why: Location and ongoing 在. [[Mandarin Chinese#^zh-Q0152|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%AE%9E%E5%9C%A8%E6%8A%B1%E6%AD%89%EF%BC%8C%E8%80%81%E6%9D%BF%E5%9C%A8%E7%9D%A1%E8%A7%89%E3%80%82%E8%AF%B7%E6%82%A8%E6%98%8E%E5%A4%A9%E5%86%8D%E6%9D%A5%E3%80%82)
^zh-Q0152-answer

**zh-Q0153** — 汽车尾气在城镇里造成了严重的污染。

Car exhaust causes serious pollution in towns.

Expected form: **在**

Why: Location and ongoing 在. [[Mandarin Chinese#^zh-Q0153|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%B1%BD%E8%BD%A6%E5%B0%BE%E6%B0%94%E5%9C%A8%E5%9F%8E%E9%95%87%E9%87%8C%E9%80%A0%E6%88%90%E4%BA%86%E4%B8%A5%E9%87%8D%E7%9A%84%E6%B1%A1%E6%9F%93%E3%80%82)
^zh-Q0153-answer

**zh-Q0154** — 汽车尾气在城镇里造成了严重的污染。

Car exhaust causes serious pollution in towns.

Why: Location and ongoing 在. [[Mandarin Chinese#^zh-Q0154|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%B1%BD%E8%BD%A6%E5%B0%BE%E6%B0%94%E5%9C%A8%E5%9F%8E%E9%95%87%E9%87%8C%E9%80%A0%E6%88%90%E4%BA%86%E4%B8%A5%E9%87%8D%E7%9A%84%E6%B1%A1%E6%9F%93%E3%80%82)
^zh-Q0154-answer

**zh-Q0155** — 放在保險箱裏面的文件不見了。

The papers that were in the safe are gone.

Why: Location and ongoing 在. [[Mandarin Chinese#^zh-Q0155|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%94%BE%E5%9C%A8%E4%BF%9D%E9%9A%AA%E7%AE%B1%E8%A3%8F%E9%9D%A2%E7%9A%84%E6%96%87%E4%BB%B6%E4%B8%8D%E8%A6%8B%E4%BA%86%E3%80%82)
^zh-Q0155-answer

**zh-Q0156** — 放在保險箱裏面的文件不見了。

The papers that were in the safe are gone.

在 can locate an entity or precede a verb for an ongoing action. It also appears in pre-verbal location phrases. The following phrase and predicate determine its role.

Why: Location and ongoing 在. [[Mandarin Chinese#^zh-Q0156|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%94%BE%E5%9C%A8%E4%BF%9D%E9%9A%AA%E7%AE%B1%E8%A3%8F%E9%9D%A2%E7%9A%84%E6%96%87%E4%BB%B6%E4%B8%8D%E8%A6%8B%E4%BA%86%E3%80%82)
^zh-Q0156-answer

**zh-Q0157** — “哈哈哈！我们要让它下雨，小子们！下周这时候，我们就在钱里游泳了！”

"Hahaha! We're going to make it rain, boys! By this time next week, we'll be swimming in cash!"

Expected form: **在**

Why: Location and ongoing 在. [[Mandarin Chinese#^zh-Q0157|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E2%80%9C%E5%93%88%E5%93%88%E5%93%88%EF%BC%81%E6%88%91%E4%BB%AC%E8%A6%81%E8%AE%A9%E5%AE%83%E4%B8%8B%E9%9B%A8%EF%BC%8C%E5%B0%8F%E5%AD%90%E4%BB%AC%EF%BC%81%E4%B8%8B%E5%91%A8%E8%BF%99%E6%97%B6%E5%80%99%EF%BC%8C%E6%88%91%E4%BB%AC%E5%B0%B1%E5%9C%A8%E9%92%B1%E9%87%8C%E6%B8%B8%E6%B3%B3%E4%BA%86%EF%BC%81%E2%80%9D)
^zh-Q0157-answer

**zh-Q0158** — “哈哈哈！我们要让它下雨，小子们！下周这时候，我们就在钱里游泳了！”

"Hahaha! We're going to make it rain, boys! By this time next week, we'll be swimming in cash!"

Expected form: **在**

Why: Location and ongoing 在. [[Mandarin Chinese#^zh-Q0158|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E2%80%9C%E5%93%88%E5%93%88%E5%93%88%EF%BC%81%E6%88%91%E4%BB%AC%E8%A6%81%E8%AE%A9%E5%AE%83%E4%B8%8B%E9%9B%A8%EF%BC%8C%E5%B0%8F%E5%AD%90%E4%BB%AC%EF%BC%81%E4%B8%8B%E5%91%A8%E8%BF%99%E6%97%B6%E5%80%99%EF%BC%8C%E6%88%91%E4%BB%AC%E5%B0%B1%E5%9C%A8%E9%92%B1%E9%87%8C%E6%B8%B8%E6%B3%B3%E4%BA%86%EF%BC%81%E2%80%9D)
^zh-Q0158-answer

**zh-Q0159** — 我不喜欢在银行工作.

I don't like working at the bank.

Expected form: **在**

Why: Location and ongoing 在. [[Mandarin Chinese#^zh-Q0159|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E4%B8%8D%E5%96%9C%E6%AC%A2%E5%9C%A8%E9%93%B6%E8%A1%8C%E5%B7%A5%E4%BD%9C.)
^zh-Q0159-answer

**zh-Q0160** — 我不喜欢在银行工作.

I don't like working at the bank.

Why: Location and ongoing 在. [[Mandarin Chinese#^zh-Q0160|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E4%B8%8D%E5%96%9C%E6%AC%A2%E5%9C%A8%E9%93%B6%E8%A1%8C%E5%B7%A5%E4%BD%9C.)
^zh-Q0160-answer

**zh-Q0161** — 她住在一個很大的房子裡。

She lives in a huge house.

Why: Location and ongoing 在. [[Mandarin Chinese#^zh-Q0161|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A5%B9%E4%BD%8F%E5%9C%A8%E4%B8%80%E5%80%8B%E5%BE%88%E5%A4%A7%E7%9A%84%E6%88%BF%E5%AD%90%E8%A3%A1%E3%80%82)
^zh-Q0161-answer

**zh-Q0162** — 她住在一個很大的房子裡。

She lives in a huge house.

在 can locate an entity or precede a verb for an ongoing action. It also appears in pre-verbal location phrases. The following phrase and predicate determine its role.

Why: Location and ongoing 在. [[Mandarin Chinese#^zh-Q0162|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A5%B9%E4%BD%8F%E5%9C%A8%E4%B8%80%E5%80%8B%E5%BE%88%E5%A4%A7%E7%9A%84%E6%88%BF%E5%AD%90%E8%A3%A1%E3%80%82)
^zh-Q0162-answer

**zh-Q0163** — 上個星期四你在他馬德里的家嗎？

Were you in his house in Madrid last Thursday?

Expected form: **在**

Why: Location and ongoing 在. [[Mandarin Chinese#^zh-Q0163|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%B8%8A%E5%80%8B%E6%98%9F%E6%9C%9F%E5%9B%9B%E4%BD%A0%E5%9C%A8%E4%BB%96%E9%A6%AC%E5%BE%B7%E9%87%8C%E7%9A%84%E5%AE%B6%E5%97%8E%EF%BC%9F)
^zh-Q0163-answer

**zh-Q0164** — 上個星期四你在他馬德里的家嗎？

Were you in his house in Madrid last Thursday?

Expected form: **在**

Why: Location and ongoing 在. [[Mandarin Chinese#^zh-Q0164|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%B8%8A%E5%80%8B%E6%98%9F%E6%9C%9F%E5%9B%9B%E4%BD%A0%E5%9C%A8%E4%BB%96%E9%A6%AC%E5%BE%B7%E9%87%8C%E7%9A%84%E5%AE%B6%E5%97%8E%EF%BC%9F)
^zh-Q0164-answer

**zh-Q0165** — 他們都在尋找這個失蹤的孩子。

They all looked for the lost child.

Expected form: **在**

Why: Location and ongoing 在. [[Mandarin Chinese#^zh-Q0165|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%96%E5%80%91%E9%83%BD%E5%9C%A8%E5%B0%8B%E6%89%BE%E9%80%99%E5%80%8B%E5%A4%B1%E8%B9%A4%E7%9A%84%E5%AD%A9%E5%AD%90%E3%80%82)
^zh-Q0165-answer

**zh-Q0166** — 他們都在尋找這個失蹤的孩子。

They all looked for the lost child.

Why: Location and ongoing 在. [[Mandarin Chinese#^zh-Q0166|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%96%E5%80%91%E9%83%BD%E5%9C%A8%E5%B0%8B%E6%89%BE%E9%80%99%E5%80%8B%E5%A4%B1%E8%B9%A4%E7%9A%84%E5%AD%A9%E5%AD%90%E3%80%82)
^zh-Q0166-answer

**zh-Q0167** — 汤姆和我每天都在学校见面。

Tom and I see each other every day at school.

Why: Location and ongoing 在. [[Mandarin Chinese#^zh-Q0167|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%B1%A4%E5%A7%86%E5%92%8C%E6%88%91%E6%AF%8F%E5%A4%A9%E9%83%BD%E5%9C%A8%E5%AD%A6%E6%A0%A1%E8%A7%81%E9%9D%A2%E3%80%82)
^zh-Q0167-answer

**zh-Q0168** — 汤姆和我每天都在学校见面。

Tom and I see each other every day at school.

在 can locate an entity or precede a verb for an ongoing action. It also appears in pre-verbal location phrases. The following phrase and predicate determine its role.

Why: Location and ongoing 在. [[Mandarin Chinese#^zh-Q0168|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%B1%A4%E5%A7%86%E5%92%8C%E6%88%91%E6%AF%8F%E5%A4%A9%E9%83%BD%E5%9C%A8%E5%AD%A6%E6%A0%A1%E8%A7%81%E9%9D%A2%E3%80%82)
^zh-Q0168-answer

**zh-Q0169** — 我在那一個觀點上同意他。

I agree with him on that point.

Expected form: **在**

Why: Location and ongoing 在. [[Mandarin Chinese#^zh-Q0169|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E5%9C%A8%E9%82%A3%E4%B8%80%E5%80%8B%E8%A7%80%E9%BB%9E%E4%B8%8A%E5%90%8C%E6%84%8F%E4%BB%96%E3%80%82)
^zh-Q0169-answer

**zh-Q0170** — 我在那一個觀點上同意他。

I agree with him on that point.

Expected form: **在**

Why: Location and ongoing 在. [[Mandarin Chinese#^zh-Q0170|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E5%9C%A8%E9%82%A3%E4%B8%80%E5%80%8B%E8%A7%80%E9%BB%9E%E4%B8%8A%E5%90%8C%E6%84%8F%E4%BB%96%E3%80%82)
^zh-Q0170-answer

**zh-Q0171** — 我的母親在做蛋糕。

My mother is making a cake.

Expected form: **在**

Why: Location and ongoing 在. [[Mandarin Chinese#^zh-Q0171|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E7%9A%84%E6%AF%8D%E8%A6%AA%E5%9C%A8%E5%81%9A%E8%9B%8B%E7%B3%95%E3%80%82)
^zh-Q0171-answer

**zh-Q0172** — 我的母親在做蛋糕。

My mother is making a cake.

Why: Location and ongoing 在. [[Mandarin Chinese#^zh-Q0172|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E7%9A%84%E6%AF%8D%E8%A6%AA%E5%9C%A8%E5%81%9A%E8%9B%8B%E7%B3%95%E3%80%82)
^zh-Q0172-answer

**zh-Q0173** — 100万人在战争中失去了生命。

One million people lost their lives in the war.

Why: Location and ongoing 在. [[Mandarin Chinese#^zh-Q0173|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=100%E4%B8%87%E4%BA%BA%E5%9C%A8%E6%88%98%E4%BA%89%E4%B8%AD%E5%A4%B1%E5%8E%BB%E4%BA%86%E7%94%9F%E5%91%BD%E3%80%82)
^zh-Q0173-answer

**zh-Q0174** — 100万人在战争中失去了生命。

One million people lost their lives in the war.

在 can locate an entity or precede a verb for an ongoing action. It also appears in pre-verbal location phrases. The following phrase and predicate determine its role.

Why: Location and ongoing 在. [[Mandarin Chinese#^zh-Q0174|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=100%E4%B8%87%E4%BA%BA%E5%9C%A8%E6%88%98%E4%BA%89%E4%B8%AD%E5%A4%B1%E5%8E%BB%E4%BA%86%E7%94%9F%E5%91%BD%E3%80%82)
^zh-Q0174-answer

**zh-Q0175** — 我们学校在市中心。

Our school is in the center of the town.

Expected form: **在**

Why: Location and ongoing 在. [[Mandarin Chinese#^zh-Q0175|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E4%BB%AC%E5%AD%A6%E6%A0%A1%E5%9C%A8%E5%B8%82%E4%B8%AD%E5%BF%83%E3%80%82)
^zh-Q0175-answer

**zh-Q0176** — 我们学校在市中心。

Our school is in the center of the town.

Expected form: **在**

Why: Location and ongoing 在. [[Mandarin Chinese#^zh-Q0176|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E4%BB%AC%E5%AD%A6%E6%A0%A1%E5%9C%A8%E5%B8%82%E4%B8%AD%E5%BF%83%E3%80%82)
^zh-Q0176-answer

**zh-Q0177** — 我们应该在今天下班前解决所有bug。

We shall fix all bugs today before leaving the office.

Expected form: **在**

Why: Location and ongoing 在. [[Mandarin Chinese#^zh-Q0177|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E4%BB%AC%E5%BA%94%E8%AF%A5%E5%9C%A8%E4%BB%8A%E5%A4%A9%E4%B8%8B%E7%8F%AD%E5%89%8D%E8%A7%A3%E5%86%B3%E6%89%80%E6%9C%89bug%E3%80%82)
^zh-Q0177-answer

**zh-Q0178** — 我们应该在今天下班前解决所有bug。

We shall fix all bugs today before leaving the office.

Why: Location and ongoing 在. [[Mandarin Chinese#^zh-Q0178|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E4%BB%AC%E5%BA%94%E8%AF%A5%E5%9C%A8%E4%BB%8A%E5%A4%A9%E4%B8%8B%E7%8F%AD%E5%89%8D%E8%A7%A3%E5%86%B3%E6%89%80%E6%9C%89bug%E3%80%82)
^zh-Q0178-answer

**zh-Q0179** — 貝克小姐知道那個年輕男子很快就要離開了，所以決定請求他將車稍微移開，如此一來她就能在夜間入睡前將她的車停到正確的位置。

Miss Baker knew that the young man would have to leave very soon, so she decided to ask him to move his car a bit, so that she could park hers in the proper place for the night before going to bed.

Why: Location and ongoing 在. [[Mandarin Chinese#^zh-Q0179|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%B2%9D%E5%85%8B%E5%B0%8F%E5%A7%90%E7%9F%A5%E9%81%93%E9%82%A3%E5%80%8B%E5%B9%B4%E8%BC%95%E7%94%B7%E5%AD%90%E5%BE%88%E5%BF%AB%E5%B0%B1%E8%A6%81%E9%9B%A2%E9%96%8B%E4%BA%86%EF%BC%8C%E6%89%80%E4%BB%A5%E6%B1%BA%E5%AE%9A%E8%AB%8B%E6%B1%82%E4%BB%96%E5%B0%87%E8%BB%8A%E7%A8%8D%E5%BE%AE%E7%A7%BB%E9%96%8B%EF%BC%8C%E5%A6%82%E6%AD%A4%E4%B8%80%E4%BE%86%E5%A5%B9%E5%B0%B1%E8%83%BD%E5%9C%A8%E5%A4%9C%E9%96%93%E5%85%A5%E7%9D%A1%E5%89%8D%E5%B0%87%E5%A5%B9%E7%9A%84%E8%BB%8A%E5%81%9C%E5%88%B0%E6%AD%A3%E7%A2%BA%E7%9A%84%E4%BD%8D%E7%BD%AE%E3%80%82)
^zh-Q0179-answer

**zh-Q0180** — 貝克小姐知道那個年輕男子很快就要離開了，所以決定請求他將車稍微移開，如此一來她就能在夜間入睡前將她的車停到正確的位置。

Miss Baker knew that the young man would have to leave very soon, so she decided to ask him to move his car a bit, so that she could park hers in the proper place for the night before going to bed.

在 can locate an entity or precede a verb for an ongoing action. It also appears in pre-verbal location phrases. The following phrase and predicate determine its role.

Why: Location and ongoing 在. [[Mandarin Chinese#^zh-Q0180|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%B2%9D%E5%85%8B%E5%B0%8F%E5%A7%90%E7%9F%A5%E9%81%93%E9%82%A3%E5%80%8B%E5%B9%B4%E8%BC%95%E7%94%B7%E5%AD%90%E5%BE%88%E5%BF%AB%E5%B0%B1%E8%A6%81%E9%9B%A2%E9%96%8B%E4%BA%86%EF%BC%8C%E6%89%80%E4%BB%A5%E6%B1%BA%E5%AE%9A%E8%AB%8B%E6%B1%82%E4%BB%96%E5%B0%87%E8%BB%8A%E7%A8%8D%E5%BE%AE%E7%A7%BB%E9%96%8B%EF%BC%8C%E5%A6%82%E6%AD%A4%E4%B8%80%E4%BE%86%E5%A5%B9%E5%B0%B1%E8%83%BD%E5%9C%A8%E5%A4%9C%E9%96%93%E5%85%A5%E7%9D%A1%E5%89%8D%E5%B0%87%E5%A5%B9%E7%9A%84%E8%BB%8A%E5%81%9C%E5%88%B0%E6%AD%A3%E7%A2%BA%E7%9A%84%E4%BD%8D%E7%BD%AE%E3%80%82)
^zh-Q0180-answer

**zh-Q0181** — 如果明天下雨，我就待在家。

If it rains tomorrow, I'll just stay at home.

Expected form: **在**

Why: Location and ongoing 在. [[Mandarin Chinese#^zh-Q0181|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A6%82%E6%9E%9C%E6%98%8E%E5%A4%A9%E4%B8%8B%E9%9B%A8%EF%BC%8C%E6%88%91%E5%B0%B1%E5%BE%85%E5%9C%A8%E5%AE%B6%E3%80%82)
^zh-Q0181-answer

**zh-Q0182** — 如果明天下雨，我就待在家。

If it rains tomorrow, I'll just stay at home.

Expected form: **在**

Why: Location and ongoing 在. [[Mandarin Chinese#^zh-Q0182|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A6%82%E6%9E%9C%E6%98%8E%E5%A4%A9%E4%B8%8B%E9%9B%A8%EF%BC%8C%E6%88%91%E5%B0%B1%E5%BE%85%E5%9C%A8%E5%AE%B6%E3%80%82)
^zh-Q0182-answer

**zh-Q0183** — 我們不在乎他做什麼。

We don't care what he does.

Expected form: **在**

Why: Location and ongoing 在. [[Mandarin Chinese#^zh-Q0183|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E5%80%91%E4%B8%8D%E5%9C%A8%E4%B9%8E%E4%BB%96%E5%81%9A%E4%BB%80%E9%BA%BC%E3%80%82)
^zh-Q0183-answer

**zh-Q0184** — 我們不在乎他做什麼。

We don't care what he does.

Why: Location and ongoing 在. [[Mandarin Chinese#^zh-Q0184|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E5%80%91%E4%B8%8D%E5%9C%A8%E4%B9%8E%E4%BB%96%E5%81%9A%E4%BB%80%E9%BA%BC%E3%80%82)
^zh-Q0184-answer

**zh-Q0185** — 珍正在和某人交談。

Jane is talking with somebody.

Why: Location and ongoing 在. [[Mandarin Chinese#^zh-Q0185|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E7%8F%8D%E6%AD%A3%E5%9C%A8%E5%92%8C%E6%9F%90%E4%BA%BA%E4%BA%A4%E8%AB%87%E3%80%82)
^zh-Q0185-answer

**zh-Q0186** — 珍正在和某人交談。

Jane is talking with somebody.

在 can locate an entity or precede a verb for an ongoing action. It also appears in pre-verbal location phrases. The following phrase and predicate determine its role.

Why: Location and ongoing 在. [[Mandarin Chinese#^zh-Q0186|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E7%8F%8D%E6%AD%A3%E5%9C%A8%E5%92%8C%E6%9F%90%E4%BA%BA%E4%BA%A4%E8%AB%87%E3%80%82)
^zh-Q0186-answer

**zh-Q0187** — 你什麼時候會在線上？

When will you be online?

Expected form: **在**

Why: Location and ongoing 在. [[Mandarin Chinese#^zh-Q0187|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E4%BB%80%E9%BA%BC%E6%99%82%E5%80%99%E6%9C%83%E5%9C%A8%E7%B7%9A%E4%B8%8A%EF%BC%9F)
^zh-Q0187-answer

**zh-Q0188** — 你什麼時候會在線上？

When will you be online?

Expected form: **在**

Why: Location and ongoing 在. [[Mandarin Chinese#^zh-Q0188|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E4%BB%80%E9%BA%BC%E6%99%82%E5%80%99%E6%9C%83%E5%9C%A8%E7%B7%9A%E4%B8%8A%EF%BC%9F)
^zh-Q0188-answer

**zh-Q0189** — 节日和考试碰巧在同一天。

The date of the festival coincides with that of the exam.

Expected form: **在**

Why: Location and ongoing 在. [[Mandarin Chinese#^zh-Q0189|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%8A%82%E6%97%A5%E5%92%8C%E8%80%83%E8%AF%95%E7%A2%B0%E5%B7%A7%E5%9C%A8%E5%90%8C%E4%B8%80%E5%A4%A9%E3%80%82)
^zh-Q0189-answer

**zh-Q0190** — 节日和考试碰巧在同一天。

The date of the festival coincides with that of the exam.

Why: Location and ongoing 在. [[Mandarin Chinese#^zh-Q0190|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%8A%82%E6%97%A5%E5%92%8C%E8%80%83%E8%AF%95%E7%A2%B0%E5%B7%A7%E5%9C%A8%E5%90%8C%E4%B8%80%E5%A4%A9%E3%80%82)
^zh-Q0190-answer

**zh-Q0191** — 所有文章都必须在规定时间内交上来。

All essays must be handed in on time.

Why: Location and ongoing 在. [[Mandarin Chinese#^zh-Q0191|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%89%80%E6%9C%89%E6%96%87%E7%AB%A0%E9%83%BD%E5%BF%85%E9%A1%BB%E5%9C%A8%E8%A7%84%E5%AE%9A%E6%97%B6%E9%97%B4%E5%86%85%E4%BA%A4%E4%B8%8A%E6%9D%A5%E3%80%82)
^zh-Q0191-answer

**zh-Q0192** — 所有文章都必须在规定时间内交上来。

All essays must be handed in on time.

在 can locate an entity or precede a verb for an ongoing action. It also appears in pre-verbal location phrases. The following phrase and predicate determine its role.

Why: Location and ongoing 在. [[Mandarin Chinese#^zh-Q0192|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%89%80%E6%9C%89%E6%96%87%E7%AB%A0%E9%83%BD%E5%BF%85%E9%A1%BB%E5%9C%A8%E8%A7%84%E5%AE%9A%E6%97%B6%E9%97%B4%E5%86%85%E4%BA%A4%E4%B8%8A%E6%9D%A5%E3%80%82)
^zh-Q0192-answer

**zh-Q0193** — 不在祖国的时候我很想家，但是在家的时候我又想旅游

When I'm away from home, I miss it dearly, but when I am at home, I want to travel.

Expected form: **在**

Why: Location and ongoing 在. [[Mandarin Chinese#^zh-Q0193|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%B8%8D%E5%9C%A8%E7%A5%96%E5%9B%BD%E7%9A%84%E6%97%B6%E5%80%99%E6%88%91%E5%BE%88%E6%83%B3%E5%AE%B6%EF%BC%8C%E4%BD%86%E6%98%AF%E5%9C%A8%E5%AE%B6%E7%9A%84%E6%97%B6%E5%80%99%E6%88%91%E5%8F%88%E6%83%B3%E6%97%85%E6%B8%B8)
^zh-Q0193-answer

**zh-Q0194** — 不在祖国的时候我很想家，但是在家的时候我又想旅游

When I'm away from home, I miss it dearly, but when I am at home, I want to travel.

Expected form: **在**

Why: Location and ongoing 在. [[Mandarin Chinese#^zh-Q0194|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%B8%8D%E5%9C%A8%E7%A5%96%E5%9B%BD%E7%9A%84%E6%97%B6%E5%80%99%E6%88%91%E5%BE%88%E6%83%B3%E5%AE%B6%EF%BC%8C%E4%BD%86%E6%98%AF%E5%9C%A8%E5%AE%B6%E7%9A%84%E6%97%B6%E5%80%99%E6%88%91%E5%8F%88%E6%83%B3%E6%97%85%E6%B8%B8)
^zh-Q0194-answer

**zh-Q0195** — 我們可以在這個公園裡玩四輪溜冰嗎?

Can we roller-skate in this park?

Expected form: **在**

Why: Location and ongoing 在. [[Mandarin Chinese#^zh-Q0195|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E5%80%91%E5%8F%AF%E4%BB%A5%E5%9C%A8%E9%80%99%E5%80%8B%E5%85%AC%E5%9C%92%E8%A3%A1%E7%8E%A9%E5%9B%9B%E8%BC%AA%E6%BA%9C%E5%86%B0%E5%97%8E%3F)
^zh-Q0195-answer

**zh-Q0196** — 我們可以在這個公園裡玩四輪溜冰嗎?

Can we roller-skate in this park?

Why: Location and ongoing 在. [[Mandarin Chinese#^zh-Q0196|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E5%80%91%E5%8F%AF%E4%BB%A5%E5%9C%A8%E9%80%99%E5%80%8B%E5%85%AC%E5%9C%92%E8%A3%A1%E7%8E%A9%E5%9B%9B%E8%BC%AA%E6%BA%9C%E5%86%B0%E5%97%8E%3F)
^zh-Q0196-answer

**zh-Q0197** — 這部電影在年輕人之間很流行。

This movie is very popular among young people.

Why: Location and ongoing 在. [[Mandarin Chinese#^zh-Q0197|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E9%80%99%E9%83%A8%E9%9B%BB%E5%BD%B1%E5%9C%A8%E5%B9%B4%E8%BC%95%E4%BA%BA%E4%B9%8B%E9%96%93%E5%BE%88%E6%B5%81%E8%A1%8C%E3%80%82)
^zh-Q0197-answer

**zh-Q0198** — 這部電影在年輕人之間很流行。

This movie is very popular among young people.

在 can locate an entity or precede a verb for an ongoing action. It also appears in pre-verbal location phrases. The following phrase and predicate determine its role.

Why: Location and ongoing 在. [[Mandarin Chinese#^zh-Q0198|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E9%80%99%E9%83%A8%E9%9B%BB%E5%BD%B1%E5%9C%A8%E5%B9%B4%E8%BC%95%E4%BA%BA%E4%B9%8B%E9%96%93%E5%BE%88%E6%B5%81%E8%A1%8C%E3%80%82)
^zh-Q0198-answer

**zh-Q0199** — 我在两年前吃过一次。

I ate it once two years ago.

Expected form: **在**

Why: Location and ongoing 在. [[Mandarin Chinese#^zh-Q0199|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E5%9C%A8%E4%B8%A4%E5%B9%B4%E5%89%8D%E5%90%83%E8%BF%87%E4%B8%80%E6%AC%A1%E3%80%82)
^zh-Q0199-answer

**zh-Q0200** — 我在两年前吃过一次。

I ate it once two years ago.

Expected form: **在**

Why: Location and ongoing 在. [[Mandarin Chinese#^zh-Q0200|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E5%9C%A8%E4%B8%A4%E5%B9%B4%E5%89%8D%E5%90%83%E8%BF%87%E4%B8%80%E6%AC%A1%E3%80%82)
^zh-Q0200-answer


### Answers 201–250

**zh-Q0201** — 你千萬不要和你父母說這件事。

You mustn't tell that to your parents.

Expected form: **不**

Why: Negation 不 and 没. [[Mandarin Chinese#^zh-Q0201|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E5%8D%83%E8%90%AC%E4%B8%8D%E8%A6%81%E5%92%8C%E4%BD%A0%E7%88%B6%E6%AF%8D%E8%AA%AA%E9%80%99%E4%BB%B6%E4%BA%8B%E3%80%82)
^zh-Q0201-answer

**zh-Q0202** — 你千萬不要和你父母說這件事。

You mustn't tell that to your parents.

Why: Negation 不 and 没. [[Mandarin Chinese#^zh-Q0202|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E5%8D%83%E8%90%AC%E4%B8%8D%E8%A6%81%E5%92%8C%E4%BD%A0%E7%88%B6%E6%AF%8D%E8%AA%AA%E9%80%99%E4%BB%B6%E4%BA%8B%E3%80%82)
^zh-Q0202-answer

**zh-Q0203** — 汤姆不能告诉玛丽他知道的所有事。

Tom couldn't tell Mary everything he knew.

Why: Negation 不 and 没. [[Mandarin Chinese#^zh-Q0203|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%B1%A4%E5%A7%86%E4%B8%8D%E8%83%BD%E5%91%8A%E8%AF%89%E7%8E%9B%E4%B8%BD%E4%BB%96%E7%9F%A5%E9%81%93%E7%9A%84%E6%89%80%E6%9C%89%E4%BA%8B%E3%80%82)
^zh-Q0203-answer

**zh-Q0204** — 汤姆不能告诉玛丽他知道的所有事。

Tom couldn't tell Mary everything he knew.

不 commonly negates habits, states and many intentions; 没/没有 commonly negates occurrence or possession. A completed-event 了 is normally not retained mechanically in a 没 negative.

Why: Negation 不 and 没. [[Mandarin Chinese#^zh-Q0204|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%B1%A4%E5%A7%86%E4%B8%8D%E8%83%BD%E5%91%8A%E8%AF%89%E7%8E%9B%E4%B8%BD%E4%BB%96%E7%9F%A5%E9%81%93%E7%9A%84%E6%89%80%E6%9C%89%E4%BA%8B%E3%80%82)
^zh-Q0204-answer

**zh-Q0205** — 雖然肉比魚昂貴，但是兩者的營養價值其實是差不多的。

Fish and meat are both nourishing, but the latter is more expensive than the former.

Expected form: **不**

Why: Negation 不 and 没. [[Mandarin Chinese#^zh-Q0205|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E9%9B%96%E7%84%B6%E8%82%89%E6%AF%94%E9%AD%9A%E6%98%82%E8%B2%B4%EF%BC%8C%E4%BD%86%E6%98%AF%E5%85%A9%E8%80%85%E7%9A%84%E7%87%9F%E9%A4%8A%E5%83%B9%E5%80%BC%E5%85%B6%E5%AF%A6%E6%98%AF%E5%B7%AE%E4%B8%8D%E5%A4%9A%E7%9A%84%E3%80%82)
^zh-Q0205-answer

**zh-Q0206** — 雖然肉比魚昂貴，但是兩者的營養價值其實是差不多的。

Fish and meat are both nourishing, but the latter is more expensive than the former.

Expected form: **不**

Why: Negation 不 and 没. [[Mandarin Chinese#^zh-Q0206|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E9%9B%96%E7%84%B6%E8%82%89%E6%AF%94%E9%AD%9A%E6%98%82%E8%B2%B4%EF%BC%8C%E4%BD%86%E6%98%AF%E5%85%A9%E8%80%85%E7%9A%84%E7%87%9F%E9%A4%8A%E5%83%B9%E5%80%BC%E5%85%B6%E5%AF%A6%E6%98%AF%E5%B7%AE%E4%B8%8D%E5%A4%9A%E7%9A%84%E3%80%82)
^zh-Q0206-answer

**zh-Q0207** — 我恐怕不能幫你了。

I am afraid I can't help you.

Expected form: **不**

Why: Negation 不 and 没. [[Mandarin Chinese#^zh-Q0207|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E6%81%90%E6%80%95%E4%B8%8D%E8%83%BD%E5%B9%AB%E4%BD%A0%E4%BA%86%E3%80%82)
^zh-Q0207-answer

**zh-Q0208** — 我恐怕不能幫你了。

I am afraid I can't help you.

Why: Negation 不 and 没. [[Mandarin Chinese#^zh-Q0208|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E6%81%90%E6%80%95%E4%B8%8D%E8%83%BD%E5%B9%AB%E4%BD%A0%E4%BA%86%E3%80%82)
^zh-Q0208-answer

**zh-Q0209** — 不見、不聞、不言。

See no evil, Hear no evil, Speak no evil.

Why: Negation 不 and 没. [[Mandarin Chinese#^zh-Q0209|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%B8%8D%E8%A6%8B%E3%80%81%E4%B8%8D%E8%81%9E%E3%80%81%E4%B8%8D%E8%A8%80%E3%80%82)
^zh-Q0209-answer

**zh-Q0210** — 不見、不聞、不言。

See no evil, Hear no evil, Speak no evil.

不 commonly negates habits, states and many intentions; 没/没有 commonly negates occurrence or possession. A completed-event 了 is normally not retained mechanically in a 没 negative.

Why: Negation 不 and 没. [[Mandarin Chinese#^zh-Q0210|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%B8%8D%E8%A6%8B%E3%80%81%E4%B8%8D%E8%81%9E%E3%80%81%E4%B8%8D%E8%A8%80%E3%80%82)
^zh-Q0210-answer

**zh-Q0211** — 這碗湯大鹹了，喝不下。

This soup is too salty to eat.

Expected form: **不**

Why: Negation 不 and 没. [[Mandarin Chinese#^zh-Q0211|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E9%80%99%E7%A2%97%E6%B9%AF%E5%A4%A7%E9%B9%B9%E4%BA%86%EF%BC%8C%E5%96%9D%E4%B8%8D%E4%B8%8B%E3%80%82)
^zh-Q0211-answer

**zh-Q0212** — 這碗湯大鹹了，喝不下。

This soup is too salty to eat.

Expected form: **不**

Why: Negation 不 and 没. [[Mandarin Chinese#^zh-Q0212|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E9%80%99%E7%A2%97%E6%B9%AF%E5%A4%A7%E9%B9%B9%E4%BA%86%EF%BC%8C%E5%96%9D%E4%B8%8D%E4%B8%8B%E3%80%82)
^zh-Q0212-answer

**zh-Q0213** — 湯姆不再相信瑪麗了。

Tom no longer trusts Mary.

Expected form: **不**

Why: Negation 不 and 没. [[Mandarin Chinese#^zh-Q0213|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%B9%AF%E5%A7%86%E4%B8%8D%E5%86%8D%E7%9B%B8%E4%BF%A1%E7%91%AA%E9%BA%97%E4%BA%86%E3%80%82)
^zh-Q0213-answer

**zh-Q0214** — 湯姆不再相信瑪麗了。

Tom no longer trusts Mary.

Why: Negation 不 and 没. [[Mandarin Chinese#^zh-Q0214|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%B9%AF%E5%A7%86%E4%B8%8D%E5%86%8D%E7%9B%B8%E4%BF%A1%E7%91%AA%E9%BA%97%E4%BA%86%E3%80%82)
^zh-Q0214-answer

**zh-Q0215** — 我不知道狗游泳游得好。

I didn't know that dogs swim well.

Why: Negation 不 and 没. [[Mandarin Chinese#^zh-Q0215|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E4%B8%8D%E7%9F%A5%E9%81%93%E7%8B%97%E6%B8%B8%E6%B3%B3%E6%B8%B8%E5%BE%97%E5%A5%BD%E3%80%82)
^zh-Q0215-answer

**zh-Q0216** — 我不知道狗游泳游得好。

I didn't know that dogs swim well.

不 commonly negates habits, states and many intentions; 没/没有 commonly negates occurrence or possession. A completed-event 了 is normally not retained mechanically in a 没 negative.

Why: Negation 不 and 没. [[Mandarin Chinese#^zh-Q0216|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E4%B8%8D%E7%9F%A5%E9%81%93%E7%8B%97%E6%B8%B8%E6%B3%B3%E6%B8%B8%E5%BE%97%E5%A5%BD%E3%80%82)
^zh-Q0216-answer

**zh-Q0217** — 世事變幻無常，人不能因循守舊、一成不變。

Things change from time to time, and one should change with them.

Expected form: **不**

Why: Negation 不 and 没. [[Mandarin Chinese#^zh-Q0217|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%B8%96%E4%BA%8B%E8%AE%8A%E5%B9%BB%E7%84%A1%E5%B8%B8%EF%BC%8C%E4%BA%BA%E4%B8%8D%E8%83%BD%E5%9B%A0%E5%BE%AA%E5%AE%88%E8%88%8A%E3%80%81%E4%B8%80%E6%88%90%E4%B8%8D%E8%AE%8A%E3%80%82)
^zh-Q0217-answer

**zh-Q0218** — 世事變幻無常，人不能因循守舊、一成不變。

Things change from time to time, and one should change with them.

Expected form: **不**

Why: Negation 不 and 没. [[Mandarin Chinese#^zh-Q0218|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%B8%96%E4%BA%8B%E8%AE%8A%E5%B9%BB%E7%84%A1%E5%B8%B8%EF%BC%8C%E4%BA%BA%E4%B8%8D%E8%83%BD%E5%9B%A0%E5%BE%AA%E5%AE%88%E8%88%8A%E3%80%81%E4%B8%80%E6%88%90%E4%B8%8D%E8%AE%8A%E3%80%82)
^zh-Q0218-answer

**zh-Q0219** — 你会不会教我学吹气风笛？

Can you teach me how to play the bagpipes?

Expected form: **不**

Why: Negation 不 and 没. [[Mandarin Chinese#^zh-Q0219|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E4%BC%9A%E4%B8%8D%E4%BC%9A%E6%95%99%E6%88%91%E5%AD%A6%E5%90%B9%E6%B0%94%E9%A3%8E%E7%AC%9B%EF%BC%9F)
^zh-Q0219-answer

**zh-Q0220** — 你会不会教我学吹气风笛？

Can you teach me how to play the bagpipes?

Why: Negation 不 and 没. [[Mandarin Chinese#^zh-Q0220|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E4%BC%9A%E4%B8%8D%E4%BC%9A%E6%95%99%E6%88%91%E5%AD%A6%E5%90%B9%E6%B0%94%E9%A3%8E%E7%AC%9B%EF%BC%9F)
^zh-Q0220-answer

**zh-Q0221** — Tom不容易被滿足。

Tom is not easily satisfied.

Why: Negation 不 and 没. [[Mandarin Chinese#^zh-Q0221|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=Tom%E4%B8%8D%E5%AE%B9%E6%98%93%E8%A2%AB%E6%BB%BF%E8%B6%B3%E3%80%82)
^zh-Q0221-answer

**zh-Q0222** — Tom不容易被滿足。

Tom is not easily satisfied.

不 commonly negates habits, states and many intentions; 没/没有 commonly negates occurrence or possession. A completed-event 了 is normally not retained mechanically in a 没 negative.

Why: Negation 不 and 没. [[Mandarin Chinese#^zh-Q0222|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=Tom%E4%B8%8D%E5%AE%B9%E6%98%93%E8%A2%AB%E6%BB%BF%E8%B6%B3%E3%80%82)
^zh-Q0222-answer

**zh-Q0223** — 你搬不動那台鋼琴。

You can't lift the piano.

Expected form: **不**

Why: Negation 不 and 没. [[Mandarin Chinese#^zh-Q0223|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E6%90%AC%E4%B8%8D%E5%8B%95%E9%82%A3%E5%8F%B0%E9%8B%BC%E7%90%B4%E3%80%82)
^zh-Q0223-answer

**zh-Q0224** — 你搬不動那台鋼琴。

You can't lift the piano.

Expected form: **不**

Why: Negation 不 and 没. [[Mandarin Chinese#^zh-Q0224|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E6%90%AC%E4%B8%8D%E5%8B%95%E9%82%A3%E5%8F%B0%E9%8B%BC%E7%90%B4%E3%80%82)
^zh-Q0224-answer

**zh-Q0225** — 我不能把我的車託付給約翰。

I can't trust John with my car.

Expected form: **不**

Why: Negation 不 and 没. [[Mandarin Chinese#^zh-Q0225|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E4%B8%8D%E8%83%BD%E6%8A%8A%E6%88%91%E7%9A%84%E8%BB%8A%E8%A8%97%E4%BB%98%E7%B5%A6%E7%B4%84%E7%BF%B0%E3%80%82)
^zh-Q0225-answer

**zh-Q0226** — 我不能把我的車託付給約翰。

I can't trust John with my car.

Why: Negation 不 and 没. [[Mandarin Chinese#^zh-Q0226|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E4%B8%8D%E8%83%BD%E6%8A%8A%E6%88%91%E7%9A%84%E8%BB%8A%E8%A8%97%E4%BB%98%E7%B5%A6%E7%B4%84%E7%BF%B0%E3%80%82)
^zh-Q0226-answer

**zh-Q0227** — 她现在忙，不能跟你说话。

She's busy now and can't speak to you.

Why: Negation 不 and 没. [[Mandarin Chinese#^zh-Q0227|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A5%B9%E7%8E%B0%E5%9C%A8%E5%BF%99%EF%BC%8C%E4%B8%8D%E8%83%BD%E8%B7%9F%E4%BD%A0%E8%AF%B4%E8%AF%9D%E3%80%82)
^zh-Q0227-answer

**zh-Q0228** — 她现在忙，不能跟你说话。

She's busy now and can't speak to you.

不 commonly negates habits, states and many intentions; 没/没有 commonly negates occurrence or possession. A completed-event 了 is normally not retained mechanically in a 没 negative.

Why: Negation 不 and 没. [[Mandarin Chinese#^zh-Q0228|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A5%B9%E7%8E%B0%E5%9C%A8%E5%BF%99%EF%BC%8C%E4%B8%8D%E8%83%BD%E8%B7%9F%E4%BD%A0%E8%AF%B4%E8%AF%9D%E3%80%82)
^zh-Q0228-answer

**zh-Q0229** — 攪拌機對真的喜歡冰沙的人來說很不錯。

Blenders are nice for people who really like smoothies.

Expected form: **不**

Why: Negation 不 and 没. [[Mandarin Chinese#^zh-Q0229|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%94%AA%E6%8B%8C%E6%A9%9F%E5%B0%8D%E7%9C%9F%E7%9A%84%E5%96%9C%E6%AD%A1%E5%86%B0%E6%B2%99%E7%9A%84%E4%BA%BA%E4%BE%86%E8%AA%AA%E5%BE%88%E4%B8%8D%E9%8C%AF%E3%80%82)
^zh-Q0229-answer

**zh-Q0230** — 攪拌機對真的喜歡冰沙的人來說很不錯。

Blenders are nice for people who really like smoothies.

Expected form: **不**

Why: Negation 不 and 没. [[Mandarin Chinese#^zh-Q0230|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%94%AA%E6%8B%8C%E6%A9%9F%E5%B0%8D%E7%9C%9F%E7%9A%84%E5%96%9C%E6%AD%A1%E5%86%B0%E6%B2%99%E7%9A%84%E4%BA%BA%E4%BE%86%E8%AA%AA%E5%BE%88%E4%B8%8D%E9%8C%AF%E3%80%82)
^zh-Q0230-answer

**zh-Q0231** — 不好意思，我把方向搞錯了。

I'm sorry I've mistaken the direction.

Expected form: **不**

Why: Negation 不 and 没. [[Mandarin Chinese#^zh-Q0231|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%B8%8D%E5%A5%BD%E6%84%8F%E6%80%9D%EF%BC%8C%E6%88%91%E6%8A%8A%E6%96%B9%E5%90%91%E6%90%9E%E9%8C%AF%E4%BA%86%E3%80%82)
^zh-Q0231-answer

**zh-Q0232** — 不好意思，我把方向搞錯了。

I'm sorry I've mistaken the direction.

Why: Negation 不 and 没. [[Mandarin Chinese#^zh-Q0232|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%B8%8D%E5%A5%BD%E6%84%8F%E6%80%9D%EF%BC%8C%E6%88%91%E6%8A%8A%E6%96%B9%E5%90%91%E6%90%9E%E9%8C%AF%E4%BA%86%E3%80%82)
^zh-Q0232-answer

**zh-Q0233** — 我不吃晚饭因为我想减肥。

I don't eat supper because I want to lose some weight.

Why: Negation 不 and 没. [[Mandarin Chinese#^zh-Q0233|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E4%B8%8D%E5%90%83%E6%99%9A%E9%A5%AD%E5%9B%A0%E4%B8%BA%E6%88%91%E6%83%B3%E5%87%8F%E8%82%A5%E3%80%82)
^zh-Q0233-answer

**zh-Q0234** — 我不吃晚饭因为我想减肥。

I don't eat supper because I want to lose some weight.

不 commonly negates habits, states and many intentions; 没/没有 commonly negates occurrence or possession. A completed-event 了 is normally not retained mechanically in a 没 negative.

Why: Negation 不 and 没. [[Mandarin Chinese#^zh-Q0234|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E4%B8%8D%E5%90%83%E6%99%9A%E9%A5%AD%E5%9B%A0%E4%B8%BA%E6%88%91%E6%83%B3%E5%87%8F%E8%82%A5%E3%80%82)
^zh-Q0234-answer

**zh-Q0235** — 赚再多的钱也不为过

One can't earn too much money.

Expected form: **不**

Why: Negation 不 and 没. [[Mandarin Chinese#^zh-Q0235|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%B5%9A%E5%86%8D%E5%A4%9A%E7%9A%84%E9%92%B1%E4%B9%9F%E4%B8%8D%E4%B8%BA%E8%BF%87)
^zh-Q0235-answer

**zh-Q0236** — 赚再多的钱也不为过

One can't earn too much money.

Expected form: **不**

Why: Negation 不 and 没. [[Mandarin Chinese#^zh-Q0236|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%B5%9A%E5%86%8D%E5%A4%9A%E7%9A%84%E9%92%B1%E4%B9%9F%E4%B8%8D%E4%B8%BA%E8%BF%87)
^zh-Q0236-answer

**zh-Q0237** — 哇! 好久不見了。

Wow! It's been a long time.

Expected form: **不**

Why: Negation 不 and 没. [[Mandarin Chinese#^zh-Q0237|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%93%87%21%20%E5%A5%BD%E4%B9%85%E4%B8%8D%E8%A6%8B%E4%BA%86%E3%80%82)
^zh-Q0237-answer

**zh-Q0238** — 哇! 好久不見了。

Wow! It's been a long time.

Why: Negation 不 and 没. [[Mandarin Chinese#^zh-Q0238|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%93%87%21%20%E5%A5%BD%E4%B9%85%E4%B8%8D%E8%A6%8B%E4%BA%86%E3%80%82)
^zh-Q0238-answer

**zh-Q0239** — 湯姆並不信任警察。

Tom doesn't trust the police.

Why: Negation 不 and 没. [[Mandarin Chinese#^zh-Q0239|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%B9%AF%E5%A7%86%E4%B8%A6%E4%B8%8D%E4%BF%A1%E4%BB%BB%E8%AD%A6%E5%AF%9F%E3%80%82)
^zh-Q0239-answer

**zh-Q0240** — 湯姆並不信任警察。

Tom doesn't trust the police.

不 commonly negates habits, states and many intentions; 没/没有 commonly negates occurrence or possession. A completed-event 了 is normally not retained mechanically in a 没 negative.

Why: Negation 不 and 没. [[Mandarin Chinese#^zh-Q0240|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%B9%AF%E5%A7%86%E4%B8%A6%E4%B8%8D%E4%BF%A1%E4%BB%BB%E8%AD%A6%E5%AF%9F%E3%80%82)
^zh-Q0240-answer

**zh-Q0241** — 我不太適應在這間公司工作。

I felt like a fish out of water at this firm.

Expected form: **不**

Why: Negation 不 and 没. [[Mandarin Chinese#^zh-Q0241|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E4%B8%8D%E5%A4%AA%E9%81%A9%E6%87%89%E5%9C%A8%E9%80%99%E9%96%93%E5%85%AC%E5%8F%B8%E5%B7%A5%E4%BD%9C%E3%80%82)
^zh-Q0241-answer

**zh-Q0242** — 我不太適應在這間公司工作。

I felt like a fish out of water at this firm.

Expected form: **不**

Why: Negation 不 and 没. [[Mandarin Chinese#^zh-Q0242|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E4%B8%8D%E5%A4%AA%E9%81%A9%E6%87%89%E5%9C%A8%E9%80%99%E9%96%93%E5%85%AC%E5%8F%B8%E5%B7%A5%E4%BD%9C%E3%80%82)
^zh-Q0242-answer

**zh-Q0243** — 她不論黨派把票投給了西岡先生。

She voted for Mr Nishioka irrespective of party lines.

Expected form: **不**

Why: Negation 不 and 没. [[Mandarin Chinese#^zh-Q0243|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A5%B9%E4%B8%8D%E8%AB%96%E9%BB%A8%E6%B4%BE%E6%8A%8A%E7%A5%A8%E6%8A%95%E7%B5%A6%E4%BA%86%E8%A5%BF%E5%B2%A1%E5%85%88%E7%94%9F%E3%80%82)
^zh-Q0243-answer

**zh-Q0244** — 她不論黨派把票投給了西岡先生。

She voted for Mr Nishioka irrespective of party lines.

Why: Negation 不 and 没. [[Mandarin Chinese#^zh-Q0244|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A5%B9%E4%B8%8D%E8%AB%96%E9%BB%A8%E6%B4%BE%E6%8A%8A%E7%A5%A8%E6%8A%95%E7%B5%A6%E4%BA%86%E8%A5%BF%E5%B2%A1%E5%85%88%E7%94%9F%E3%80%82)
^zh-Q0244-answer

**zh-Q0245** — 那天天氣很好，但公園裏人並不多。

It was a pleasant day, but there were few people in the park.

Why: Negation 不 and 没. [[Mandarin Chinese#^zh-Q0245|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E9%82%A3%E5%A4%A9%E5%A4%A9%E6%B0%A3%E5%BE%88%E5%A5%BD%EF%BC%8C%E4%BD%86%E5%85%AC%E5%9C%92%E8%A3%8F%E4%BA%BA%E4%B8%A6%E4%B8%8D%E5%A4%9A%E3%80%82)
^zh-Q0245-answer

**zh-Q0246** — 那天天氣很好，但公園裏人並不多。

It was a pleasant day, but there were few people in the park.

不 commonly negates habits, states and many intentions; 没/没有 commonly negates occurrence or possession. A completed-event 了 is normally not retained mechanically in a 没 negative.

Why: Negation 不 and 没. [[Mandarin Chinese#^zh-Q0246|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E9%82%A3%E5%A4%A9%E5%A4%A9%E6%B0%A3%E5%BE%88%E5%A5%BD%EF%BC%8C%E4%BD%86%E5%85%AC%E5%9C%92%E8%A3%8F%E4%BA%BA%E4%B8%A6%E4%B8%8D%E5%A4%9A%E3%80%82)
^zh-Q0246-answer

**zh-Q0247** — 我不是一個厭惡女性的人; 但如果我是, 我會為你而破例。

I'm not a woman hater; and if I were, I would make an exception for you.

Expected form: **不**

Why: Negation 不 and 没. [[Mandarin Chinese#^zh-Q0247|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E4%B8%8D%E6%98%AF%E4%B8%80%E5%80%8B%E5%8E%AD%E6%83%A1%E5%A5%B3%E6%80%A7%E7%9A%84%E4%BA%BA%3B%20%E4%BD%86%E5%A6%82%E6%9E%9C%E6%88%91%E6%98%AF%2C%20%E6%88%91%E6%9C%83%E7%82%BA%E4%BD%A0%E8%80%8C%E7%A0%B4%E4%BE%8B%E3%80%82)
^zh-Q0247-answer

**zh-Q0248** — 我不是一個厭惡女性的人; 但如果我是, 我會為你而破例。

I'm not a woman hater; and if I were, I would make an exception for you.

Expected form: **不**

Why: Negation 不 and 没. [[Mandarin Chinese#^zh-Q0248|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E4%B8%8D%E6%98%AF%E4%B8%80%E5%80%8B%E5%8E%AD%E6%83%A1%E5%A5%B3%E6%80%A7%E7%9A%84%E4%BA%BA%3B%20%E4%BD%86%E5%A6%82%E6%9E%9C%E6%88%91%E6%98%AF%2C%20%E6%88%91%E6%9C%83%E7%82%BA%E4%BD%A0%E8%80%8C%E7%A0%B4%E4%BE%8B%E3%80%82)
^zh-Q0248-answer

**zh-Q0249** — 天气热点儿没关系。

I don't mind if the weather is hot.

Expected form: **没**

Why: Negation 不 and 没. [[Mandarin Chinese#^zh-Q0249|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A4%A9%E6%B0%94%E7%83%AD%E7%82%B9%E5%84%BF%E6%B2%A1%E5%85%B3%E7%B3%BB%E3%80%82)
^zh-Q0249-answer

**zh-Q0250** — 天气热点儿没关系。

I don't mind if the weather is hot.

Why: Negation 不 and 没. [[Mandarin Chinese#^zh-Q0250|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A4%A9%E6%B0%94%E7%83%AD%E7%82%B9%E5%84%BF%E6%B2%A1%E5%85%B3%E7%B3%BB%E3%80%82)
^zh-Q0250-answer


### Answers 251–300

**zh-Q0251** — 那个男孩子见到鬼的时候吓了一跳。

The boy fell of fright when he saw a ghost.

Why: Attributive 的. [[Mandarin Chinese#^zh-Q0251|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E9%82%A3%E4%B8%AA%E7%94%B7%E5%AD%A9%E5%AD%90%E8%A7%81%E5%88%B0%E9%AC%BC%E7%9A%84%E6%97%B6%E5%80%99%E5%90%93%E4%BA%86%E4%B8%80%E8%B7%B3%E3%80%82)
^zh-Q0251-answer

**zh-Q0252** — 那个男孩子见到鬼的时候吓了一跳。

The boy fell of fright when he saw a ghost.

的 commonly links a modifier to a noun and marks possession. Mandarin modifiers precede their head noun. The written homophones 的/地/得 have distinct conventional functions.

Why: Attributive 的. [[Mandarin Chinese#^zh-Q0252|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E9%82%A3%E4%B8%AA%E7%94%B7%E5%AD%A9%E5%AD%90%E8%A7%81%E5%88%B0%E9%AC%BC%E7%9A%84%E6%97%B6%E5%80%99%E5%90%93%E4%BA%86%E4%B8%80%E8%B7%B3%E3%80%82)
^zh-Q0252-answer

**zh-Q0253** — 國際間的紛爭一定要用和平的方法來解決。

International disputes must be settled peacefully.

Expected form: **的**

Why: Attributive 的. [[Mandarin Chinese#^zh-Q0253|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%9C%8B%E9%9A%9B%E9%96%93%E7%9A%84%E7%B4%9B%E7%88%AD%E4%B8%80%E5%AE%9A%E8%A6%81%E7%94%A8%E5%92%8C%E5%B9%B3%E7%9A%84%E6%96%B9%E6%B3%95%E4%BE%86%E8%A7%A3%E6%B1%BA%E3%80%82)
^zh-Q0253-answer

**zh-Q0254** — 國際間的紛爭一定要用和平的方法來解決。

International disputes must be settled peacefully.

Expected form: **的**

Why: Attributive 的. [[Mandarin Chinese#^zh-Q0254|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%9C%8B%E9%9A%9B%E9%96%93%E7%9A%84%E7%B4%9B%E7%88%AD%E4%B8%80%E5%AE%9A%E8%A6%81%E7%94%A8%E5%92%8C%E5%B9%B3%E7%9A%84%E6%96%B9%E6%B3%95%E4%BE%86%E8%A7%A3%E6%B1%BA%E3%80%82)
^zh-Q0254-answer

**zh-Q0255** — 你應該諮詢你的醫生。

You should consult your doctor.

Expected form: **的**

Why: Attributive 的. [[Mandarin Chinese#^zh-Q0255|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E6%87%89%E8%A9%B2%E8%AB%AE%E8%A9%A2%E4%BD%A0%E7%9A%84%E9%86%AB%E7%94%9F%E3%80%82)
^zh-Q0255-answer

**zh-Q0256** — 你應該諮詢你的醫生。

You should consult your doctor.

Why: Attributive 的. [[Mandarin Chinese#^zh-Q0256|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E6%87%89%E8%A9%B2%E8%AB%AE%E8%A9%A2%E4%BD%A0%E7%9A%84%E9%86%AB%E7%94%9F%E3%80%82)
^zh-Q0256-answer

**zh-Q0257** — 这件事很难以相信的。

This is difficult to believe.

Why: Attributive 的. [[Mandarin Chinese#^zh-Q0257|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%BF%99%E4%BB%B6%E4%BA%8B%E5%BE%88%E9%9A%BE%E4%BB%A5%E7%9B%B8%E4%BF%A1%E7%9A%84%E3%80%82)
^zh-Q0257-answer

**zh-Q0258** — 这件事很难以相信的。

This is difficult to believe.

的 commonly links a modifier to a noun and marks possession. Mandarin modifiers precede their head noun. The written homophones 的/地/得 have distinct conventional functions.

Why: Attributive 的. [[Mandarin Chinese#^zh-Q0258|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%BF%99%E4%BB%B6%E4%BA%8B%E5%BE%88%E9%9A%BE%E4%BB%A5%E7%9B%B8%E4%BF%A1%E7%9A%84%E3%80%82)
^zh-Q0258-answer

**zh-Q0259** — 他说话时，显然带着高兴的表情。

He spoke with evident glee.

Expected form: **的**

Why: Attributive 的. [[Mandarin Chinese#^zh-Q0259|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%96%E8%AF%B4%E8%AF%9D%E6%97%B6%EF%BC%8C%E6%98%BE%E7%84%B6%E5%B8%A6%E7%9D%80%E9%AB%98%E5%85%B4%E7%9A%84%E8%A1%A8%E6%83%85%E3%80%82)
^zh-Q0259-answer

**zh-Q0260** — 他说话时，显然带着高兴的表情。

He spoke with evident glee.

Expected form: **的**

Why: Attributive 的. [[Mandarin Chinese#^zh-Q0260|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%96%E8%AF%B4%E8%AF%9D%E6%97%B6%EF%BC%8C%E6%98%BE%E7%84%B6%E5%B8%A6%E7%9D%80%E9%AB%98%E5%85%B4%E7%9A%84%E8%A1%A8%E6%83%85%E3%80%82)
^zh-Q0260-answer

**zh-Q0261** — 那裏的景色美得無法以筆墨形容。

The beauty of the scene was beyond description.

Expected form: **的**

Why: Attributive 的. [[Mandarin Chinese#^zh-Q0261|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E9%82%A3%E8%A3%8F%E7%9A%84%E6%99%AF%E8%89%B2%E7%BE%8E%E5%BE%97%E7%84%A1%E6%B3%95%E4%BB%A5%E7%AD%86%E5%A2%A8%E5%BD%A2%E5%AE%B9%E3%80%82)
^zh-Q0261-answer

**zh-Q0262** — 那裏的景色美得無法以筆墨形容。

The beauty of the scene was beyond description.

Why: Attributive 的. [[Mandarin Chinese#^zh-Q0262|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E9%82%A3%E8%A3%8F%E7%9A%84%E6%99%AF%E8%89%B2%E7%BE%8E%E5%BE%97%E7%84%A1%E6%B3%95%E4%BB%A5%E7%AD%86%E5%A2%A8%E5%BD%A2%E5%AE%B9%E3%80%82)
^zh-Q0262-answer

**zh-Q0263** — 你的靈魂已墜進了地獄。

Your soul has been condemned to hell.

Why: Attributive 的. [[Mandarin Chinese#^zh-Q0263|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E7%9A%84%E9%9D%88%E9%AD%82%E5%B7%B2%E5%A2%9C%E9%80%B2%E4%BA%86%E5%9C%B0%E7%8D%84%E3%80%82)
^zh-Q0263-answer

**zh-Q0264** — 你的靈魂已墜進了地獄。

Your soul has been condemned to hell.

的 commonly links a modifier to a noun and marks possession. Mandarin modifiers precede their head noun. The written homophones 的/地/得 have distinct conventional functions.

Why: Attributive 的. [[Mandarin Chinese#^zh-Q0264|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E7%9A%84%E9%9D%88%E9%AD%82%E5%B7%B2%E5%A2%9C%E9%80%B2%E4%BA%86%E5%9C%B0%E7%8D%84%E3%80%82)
^zh-Q0264-answer

**zh-Q0265** — 每个人都知道汤姆的法语很好。

Everyone knows Tom speaks good French.

Expected form: **的**

Why: Attributive 的. [[Mandarin Chinese#^zh-Q0265|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%AF%8F%E4%B8%AA%E4%BA%BA%E9%83%BD%E7%9F%A5%E9%81%93%E6%B1%A4%E5%A7%86%E7%9A%84%E6%B3%95%E8%AF%AD%E5%BE%88%E5%A5%BD%E3%80%82)
^zh-Q0265-answer

**zh-Q0266** — 每个人都知道汤姆的法语很好。

Everyone knows Tom speaks good French.

Expected form: **的**

Why: Attributive 的. [[Mandarin Chinese#^zh-Q0266|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%AF%8F%E4%B8%AA%E4%BA%BA%E9%83%BD%E7%9F%A5%E9%81%93%E6%B1%A4%E5%A7%86%E7%9A%84%E6%B3%95%E8%AF%AD%E5%BE%88%E5%A5%BD%E3%80%82)
^zh-Q0266-answer

**zh-Q0267** — 她被视为日本的毕加索。

She is known as the Japanese Picasso.

Expected form: **的**

Why: Attributive 的. [[Mandarin Chinese#^zh-Q0267|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A5%B9%E8%A2%AB%E8%A7%86%E4%B8%BA%E6%97%A5%E6%9C%AC%E7%9A%84%E6%AF%95%E5%8A%A0%E7%B4%A2%E3%80%82)
^zh-Q0267-answer

**zh-Q0268** — 她被视为日本的毕加索。

She is known as the Japanese Picasso.

Why: Attributive 的. [[Mandarin Chinese#^zh-Q0268|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A5%B9%E8%A2%AB%E8%A7%86%E4%B8%BA%E6%97%A5%E6%9C%AC%E7%9A%84%E6%AF%95%E5%8A%A0%E7%B4%A2%E3%80%82)
^zh-Q0268-answer

**zh-Q0269** — 她今天穿著白色的衣服。

She is wearing a white dress today.

Why: Attributive 的. [[Mandarin Chinese#^zh-Q0269|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A5%B9%E4%BB%8A%E5%A4%A9%E7%A9%BF%E8%91%97%E7%99%BD%E8%89%B2%E7%9A%84%E8%A1%A3%E6%9C%8D%E3%80%82)
^zh-Q0269-answer

**zh-Q0270** — 她今天穿著白色的衣服。

She is wearing a white dress today.

的 commonly links a modifier to a noun and marks possession. Mandarin modifiers precede their head noun. The written homophones 的/地/得 have distinct conventional functions.

Why: Attributive 的. [[Mandarin Chinese#^zh-Q0270|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A5%B9%E4%BB%8A%E5%A4%A9%E7%A9%BF%E8%91%97%E7%99%BD%E8%89%B2%E7%9A%84%E8%A1%A3%E6%9C%8D%E3%80%82)
^zh-Q0270-answer

**zh-Q0271** — 那超出了我的理解。

That was beyond my comprehension.

Expected form: **的**

Why: Attributive 的. [[Mandarin Chinese#^zh-Q0271|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E9%82%A3%E8%B6%85%E5%87%BA%E4%BA%86%E6%88%91%E7%9A%84%E7%90%86%E8%A7%A3%E3%80%82)
^zh-Q0271-answer

**zh-Q0272** — 那超出了我的理解。

That was beyond my comprehension.

Expected form: **的**

Why: Attributive 的. [[Mandarin Chinese#^zh-Q0272|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E9%82%A3%E8%B6%85%E5%87%BA%E4%BA%86%E6%88%91%E7%9A%84%E7%90%86%E8%A7%A3%E3%80%82)
^zh-Q0272-answer

**zh-Q0273** — 请过目25页的地图。

Please look over the map on page 25.

Expected form: **的**

Why: Attributive 的. [[Mandarin Chinese#^zh-Q0273|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%AF%B7%E8%BF%87%E7%9B%AE25%E9%A1%B5%E7%9A%84%E5%9C%B0%E5%9B%BE%E3%80%82)
^zh-Q0273-answer

**zh-Q0274** — 请过目25页的地图。

Please look over the map on page 25.

Why: Attributive 的. [[Mandarin Chinese#^zh-Q0274|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%AF%B7%E8%BF%87%E7%9B%AE25%E9%A1%B5%E7%9A%84%E5%9C%B0%E5%9B%BE%E3%80%82)
^zh-Q0274-answer

**zh-Q0275** — 我试图画条纹图形，但是当我画圆的时候我失败了。它看起来像一个椭圆的圆环。

I tried to draw a stick figure, but I failed when I started to draw the circle. It looked like a loop-sided oval.

Why: Attributive 的. [[Mandarin Chinese#^zh-Q0275|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E8%AF%95%E5%9B%BE%E7%94%BB%E6%9D%A1%E7%BA%B9%E5%9B%BE%E5%BD%A2%EF%BC%8C%E4%BD%86%E6%98%AF%E5%BD%93%E6%88%91%E7%94%BB%E5%9C%86%E7%9A%84%E6%97%B6%E5%80%99%E6%88%91%E5%A4%B1%E8%B4%A5%E4%BA%86%E3%80%82%E5%AE%83%E7%9C%8B%E8%B5%B7%E6%9D%A5%E5%83%8F%E4%B8%80%E4%B8%AA%E6%A4%AD%E5%9C%86%E7%9A%84%E5%9C%86%E7%8E%AF%E3%80%82)
^zh-Q0275-answer

**zh-Q0276** — 我试图画条纹图形，但是当我画圆的时候我失败了。它看起来像一个椭圆的圆环。

I tried to draw a stick figure, but I failed when I started to draw the circle. It looked like a loop-sided oval.

的 commonly links a modifier to a noun and marks possession. Mandarin modifiers precede their head noun. The written homophones 的/地/得 have distinct conventional functions.

Why: Attributive 的. [[Mandarin Chinese#^zh-Q0276|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E8%AF%95%E5%9B%BE%E7%94%BB%E6%9D%A1%E7%BA%B9%E5%9B%BE%E5%BD%A2%EF%BC%8C%E4%BD%86%E6%98%AF%E5%BD%93%E6%88%91%E7%94%BB%E5%9C%86%E7%9A%84%E6%97%B6%E5%80%99%E6%88%91%E5%A4%B1%E8%B4%A5%E4%BA%86%E3%80%82%E5%AE%83%E7%9C%8B%E8%B5%B7%E6%9D%A5%E5%83%8F%E4%B8%80%E4%B8%AA%E6%A4%AD%E5%9C%86%E7%9A%84%E5%9C%86%E7%8E%AF%E3%80%82)
^zh-Q0276-answer

**zh-Q0277** — 我希望我能买下你想要的所有东西。

I wish I could buy you everything you wanted.

Expected form: **的**

Why: Attributive 的. [[Mandarin Chinese#^zh-Q0277|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E5%B8%8C%E6%9C%9B%E6%88%91%E8%83%BD%E4%B9%B0%E4%B8%8B%E4%BD%A0%E6%83%B3%E8%A6%81%E7%9A%84%E6%89%80%E6%9C%89%E4%B8%9C%E8%A5%BF%E3%80%82)
^zh-Q0277-answer

**zh-Q0278** — 我希望我能买下你想要的所有东西。

I wish I could buy you everything you wanted.

Expected form: **的**

Why: Attributive 的. [[Mandarin Chinese#^zh-Q0278|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E5%B8%8C%E6%9C%9B%E6%88%91%E8%83%BD%E4%B9%B0%E4%B8%8B%E4%BD%A0%E6%83%B3%E8%A6%81%E7%9A%84%E6%89%80%E6%9C%89%E4%B8%9C%E8%A5%BF%E3%80%82)
^zh-Q0278-answer

**zh-Q0279** — 克里斯扬起他的剑。

Chris swung his sword!

Expected form: **的**

Why: Attributive 的. [[Mandarin Chinese#^zh-Q0279|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%85%8B%E9%87%8C%E6%96%AF%E6%89%AC%E8%B5%B7%E4%BB%96%E7%9A%84%E5%89%91%E3%80%82)
^zh-Q0279-answer

**zh-Q0280** — 克里斯扬起他的剑。

Chris swung his sword!

Why: Attributive 的. [[Mandarin Chinese#^zh-Q0280|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%85%8B%E9%87%8C%E6%96%AF%E6%89%AC%E8%B5%B7%E4%BB%96%E7%9A%84%E5%89%91%E3%80%82)
^zh-Q0280-answer

**zh-Q0281** — 一個竊賊闖進了他的房子。

A burglar broke into his house.

Why: Attributive 的. [[Mandarin Chinese#^zh-Q0281|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%B8%80%E5%80%8B%E7%AB%8A%E8%B3%8A%E9%97%96%E9%80%B2%E4%BA%86%E4%BB%96%E7%9A%84%E6%88%BF%E5%AD%90%E3%80%82)
^zh-Q0281-answer

**zh-Q0282** — 一個竊賊闖進了他的房子。

A burglar broke into his house.

的 commonly links a modifier to a noun and marks possession. Mandarin modifiers precede their head noun. The written homophones 的/地/得 have distinct conventional functions.

Why: Attributive 的. [[Mandarin Chinese#^zh-Q0282|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%B8%80%E5%80%8B%E7%AB%8A%E8%B3%8A%E9%97%96%E9%80%B2%E4%BA%86%E4%BB%96%E7%9A%84%E6%88%BF%E5%AD%90%E3%80%82)
^zh-Q0282-answer

**zh-Q0283** — 他可能喜欢他的工作。

It may be that he likes his job.

Expected form: **的**

Why: Attributive 的. [[Mandarin Chinese#^zh-Q0283|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%96%E5%8F%AF%E8%83%BD%E5%96%9C%E6%AC%A2%E4%BB%96%E7%9A%84%E5%B7%A5%E4%BD%9C%E3%80%82)
^zh-Q0283-answer

**zh-Q0284** — 他可能喜欢他的工作。

It may be that he likes his job.

Expected form: **的**

Why: Attributive 的. [[Mandarin Chinese#^zh-Q0284|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%96%E5%8F%AF%E8%83%BD%E5%96%9C%E6%AC%A2%E4%BB%96%E7%9A%84%E5%B7%A5%E4%BD%9C%E3%80%82)
^zh-Q0284-answer

**zh-Q0285** — 她嘗試把老師說的每一句話都記下來。

She tried to take down every word the teacher said.

Expected form: **的**

Why: Attributive 的. [[Mandarin Chinese#^zh-Q0285|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A5%B9%E5%98%97%E8%A9%A6%E6%8A%8A%E8%80%81%E5%B8%AB%E8%AA%AA%E7%9A%84%E6%AF%8F%E4%B8%80%E5%8F%A5%E8%A9%B1%E9%83%BD%E8%A8%98%E4%B8%8B%E4%BE%86%E3%80%82)
^zh-Q0285-answer

**zh-Q0286** — 她嘗試把老師說的每一句話都記下來。

She tried to take down every word the teacher said.

Why: Attributive 的. [[Mandarin Chinese#^zh-Q0286|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A5%B9%E5%98%97%E8%A9%A6%E6%8A%8A%E8%80%81%E5%B8%AB%E8%AA%AA%E7%9A%84%E6%AF%8F%E4%B8%80%E5%8F%A5%E8%A9%B1%E9%83%BD%E8%A8%98%E4%B8%8B%E4%BE%86%E3%80%82)
^zh-Q0286-answer

**zh-Q0287** — 人们啊，擦亮你的眼睛吧！

Open your eyes, people!

Why: Attributive 的. [[Mandarin Chinese#^zh-Q0287|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BA%BA%E4%BB%AC%E5%95%8A%EF%BC%8C%E6%93%A6%E4%BA%AE%E4%BD%A0%E7%9A%84%E7%9C%BC%E7%9D%9B%E5%90%A7%EF%BC%81)
^zh-Q0287-answer

**zh-Q0288** — 人们啊，擦亮你的眼睛吧！

Open your eyes, people!

的 commonly links a modifier to a noun and marks possession. Mandarin modifiers precede their head noun. The written homophones 的/地/得 have distinct conventional functions.

Why: Attributive 的. [[Mandarin Chinese#^zh-Q0288|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BA%BA%E4%BB%AC%E5%95%8A%EF%BC%8C%E6%93%A6%E4%BA%AE%E4%BD%A0%E7%9A%84%E7%9C%BC%E7%9D%9B%E5%90%A7%EF%BC%81)
^zh-Q0288-answer

**zh-Q0289** — 清理的时候，我们看到了些他的东西。

While cleaning, we saw some of his things.

Expected form: **的**

Why: Attributive 的. [[Mandarin Chinese#^zh-Q0289|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%B8%85%E7%90%86%E7%9A%84%E6%97%B6%E5%80%99%EF%BC%8C%E6%88%91%E4%BB%AC%E7%9C%8B%E5%88%B0%E4%BA%86%E4%BA%9B%E4%BB%96%E7%9A%84%E4%B8%9C%E8%A5%BF%E3%80%82)
^zh-Q0289-answer

**zh-Q0290** — 清理的时候，我们看到了些他的东西。

While cleaning, we saw some of his things.

Expected form: **的**

Why: Attributive 的. [[Mandarin Chinese#^zh-Q0290|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%B8%85%E7%90%86%E7%9A%84%E6%97%B6%E5%80%99%EF%BC%8C%E6%88%91%E4%BB%AC%E7%9C%8B%E5%88%B0%E4%BA%86%E4%BA%9B%E4%BB%96%E7%9A%84%E4%B8%9C%E8%A5%BF%E3%80%82)
^zh-Q0290-answer

**zh-Q0291** — 他的辦公室離車站很近。

His office is near the train station.

Expected form: **的**

Why: Attributive 的. [[Mandarin Chinese#^zh-Q0291|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%96%E7%9A%84%E8%BE%A6%E5%85%AC%E5%AE%A4%E9%9B%A2%E8%BB%8A%E7%AB%99%E5%BE%88%E8%BF%91%E3%80%82)
^zh-Q0291-answer

**zh-Q0292** — 他的辦公室離車站很近。

His office is near the train station.

Why: Attributive 的. [[Mandarin Chinese#^zh-Q0292|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%96%E7%9A%84%E8%BE%A6%E5%85%AC%E5%AE%A4%E9%9B%A2%E8%BB%8A%E7%AB%99%E5%BE%88%E8%BF%91%E3%80%82)
^zh-Q0292-answer

**zh-Q0293** — 他賣了一台豐田的車。

He bought a Honda.

Why: Attributive 的. [[Mandarin Chinese#^zh-Q0293|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%96%E8%B3%A3%E4%BA%86%E4%B8%80%E5%8F%B0%E8%B1%90%E7%94%B0%E7%9A%84%E8%BB%8A%E3%80%82)
^zh-Q0293-answer

**zh-Q0294** — 他賣了一台豐田的車。

He bought a Honda.

的 commonly links a modifier to a noun and marks possession. Mandarin modifiers precede their head noun. The written homophones 的/地/得 have distinct conventional functions.

Why: Attributive 的. [[Mandarin Chinese#^zh-Q0294|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%96%E8%B3%A3%E4%BA%86%E4%B8%80%E5%8F%B0%E8%B1%90%E7%94%B0%E7%9A%84%E8%BB%8A%E3%80%82)
^zh-Q0294-answer

**zh-Q0295** — 许多人拒绝了欢迎会的邀请。

Many people rejected the invitation to the welcome party.

Expected form: **的**

Why: Attributive 的. [[Mandarin Chinese#^zh-Q0295|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%AE%B8%E5%A4%9A%E4%BA%BA%E6%8B%92%E7%BB%9D%E4%BA%86%E6%AC%A2%E8%BF%8E%E4%BC%9A%E7%9A%84%E9%82%80%E8%AF%B7%E3%80%82)
^zh-Q0295-answer

**zh-Q0296** — 许多人拒绝了欢迎会的邀请。

Many people rejected the invitation to the welcome party.

Expected form: **的**

Why: Attributive 的. [[Mandarin Chinese#^zh-Q0296|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%AE%B8%E5%A4%9A%E4%BA%BA%E6%8B%92%E7%BB%9D%E4%BA%86%E6%AC%A2%E8%BF%8E%E4%BC%9A%E7%9A%84%E9%82%80%E8%AF%B7%E3%80%82)
^zh-Q0296-answer

**zh-Q0297** — 这个国家的军事力量很先进。

The military power of this country is very advanced.

Expected form: **的**

Why: Attributive 的. [[Mandarin Chinese#^zh-Q0297|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%BF%99%E4%B8%AA%E5%9B%BD%E5%AE%B6%E7%9A%84%E5%86%9B%E4%BA%8B%E5%8A%9B%E9%87%8F%E5%BE%88%E5%85%88%E8%BF%9B%E3%80%82)
^zh-Q0297-answer

**zh-Q0298** — 这个国家的军事力量很先进。

The military power of this country is very advanced.

Why: Attributive 的. [[Mandarin Chinese#^zh-Q0298|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%BF%99%E4%B8%AA%E5%9B%BD%E5%AE%B6%E7%9A%84%E5%86%9B%E4%BA%8B%E5%8A%9B%E9%87%8F%E5%BE%88%E5%85%88%E8%BF%9B%E3%80%82)
^zh-Q0298-answer

**zh-Q0299** — 我們買了張舒適的扶手椅。

We bought a comfortable new armchair.

Why: Attributive 的. [[Mandarin Chinese#^zh-Q0299|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E5%80%91%E8%B2%B7%E4%BA%86%E5%BC%B5%E8%88%92%E9%81%A9%E7%9A%84%E6%89%B6%E6%89%8B%E6%A4%85%E3%80%82)
^zh-Q0299-answer

**zh-Q0300** — 我們買了張舒適的扶手椅。

We bought a comfortable new armchair.

的 commonly links a modifier to a noun and marks possession. Mandarin modifiers precede their head noun. The written homophones 的/地/得 have distinct conventional functions.

Why: Attributive 的. [[Mandarin Chinese#^zh-Q0300|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E5%80%91%E8%B2%B7%E4%BA%86%E5%BC%B5%E8%88%92%E9%81%A9%E7%9A%84%E6%89%B6%E6%89%8B%E6%A4%85%E3%80%82)
^zh-Q0300-answer


### Answers 301–350

**zh-Q0301** — 汤姆犯了个大失误。

Tom has made a big mistake.

Expected form: **个**

Why: Classifiers. [[Mandarin Chinese#^zh-Q0301|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%B1%A4%E5%A7%86%E7%8A%AF%E4%BA%86%E4%B8%AA%E5%A4%A7%E5%A4%B1%E8%AF%AF%E3%80%82)
^zh-Q0301-answer

**zh-Q0302** — 汤姆犯了个大失误。

Tom has made a big mistake.

Expected form: **个**

Why: Classifiers. [[Mandarin Chinese#^zh-Q0302|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%B1%A4%E5%A7%86%E7%8A%AF%E4%BA%86%E4%B8%AA%E5%A4%A7%E5%A4%B1%E8%AF%AF%E3%80%82)
^zh-Q0302-answer

**zh-Q0303** — 我们已经等了好几个小时了。

We’ve been waiting for hours.

Expected form: **个**

Why: Classifiers. [[Mandarin Chinese#^zh-Q0303|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E4%BB%AC%E5%B7%B2%E7%BB%8F%E7%AD%89%E4%BA%86%E5%A5%BD%E5%87%A0%E4%B8%AA%E5%B0%8F%E6%97%B6%E4%BA%86%E3%80%82)
^zh-Q0303-answer

**zh-Q0304** — 我们已经等了好几个小时了。

We’ve been waiting for hours.

Why: Classifiers. [[Mandarin Chinese#^zh-Q0304|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E4%BB%AC%E5%B7%B2%E7%BB%8F%E7%AD%89%E4%BA%86%E5%A5%BD%E5%87%A0%E4%B8%AA%E5%B0%8F%E6%97%B6%E4%BA%86%E3%80%82)
^zh-Q0304-answer

**zh-Q0305** — 求你了，给我一个瓶子吧！

I beg you, give me a bottle!

Why: Classifiers. [[Mandarin Chinese#^zh-Q0305|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%B1%82%E4%BD%A0%E4%BA%86%EF%BC%8C%E7%BB%99%E6%88%91%E4%B8%80%E4%B8%AA%E7%93%B6%E5%AD%90%E5%90%A7%EF%BC%81)
^zh-Q0305-answer

**zh-Q0306** — 求你了，给我一个瓶子吧！

I beg you, give me a bottle!

A numeral/demonstrative commonly combines with a classifier before a counted noun. 本 is common for books, 张 for flat objects, 位 for people respectfully. Classifier choice is lexical and meaning-dependent.

Why: Classifiers. [[Mandarin Chinese#^zh-Q0306|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%B1%82%E4%BD%A0%E4%BA%86%EF%BC%8C%E7%BB%99%E6%88%91%E4%B8%80%E4%B8%AA%E7%93%B6%E5%AD%90%E5%90%A7%EF%BC%81)
^zh-Q0306-answer

**zh-Q0307** — 我要把这本书留给自己。

I'll keep that book for myself.

Expected form: **本**

Why: Classifiers. [[Mandarin Chinese#^zh-Q0307|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E8%A6%81%E6%8A%8A%E8%BF%99%E6%9C%AC%E4%B9%A6%E7%95%99%E7%BB%99%E8%87%AA%E5%B7%B1%E3%80%82)
^zh-Q0307-answer

**zh-Q0308** — 我要把这本书留给自己。

I'll keep that book for myself.

Expected form: **本**

Why: Classifiers. [[Mandarin Chinese#^zh-Q0308|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E8%A6%81%E6%8A%8A%E8%BF%99%E6%9C%AC%E4%B9%A6%E7%95%99%E7%BB%99%E8%87%AA%E5%B7%B1%E3%80%82)
^zh-Q0308-answer

**zh-Q0309** — 我们应该往哪个方向走？

Which way should we go?

Expected form: **个**

Why: Classifiers. [[Mandarin Chinese#^zh-Q0309|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E4%BB%AC%E5%BA%94%E8%AF%A5%E5%BE%80%E5%93%AA%E4%B8%AA%E6%96%B9%E5%90%91%E8%B5%B0%EF%BC%9F)
^zh-Q0309-answer

**zh-Q0310** — 我们应该往哪个方向走？

Which way should we go?

Why: Classifiers. [[Mandarin Chinese#^zh-Q0310|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E4%BB%AC%E5%BA%94%E8%AF%A5%E5%BE%80%E5%93%AA%E4%B8%AA%E6%96%B9%E5%90%91%E8%B5%B0%EF%BC%9F)
^zh-Q0310-answer

**zh-Q0311** — 這本書會讓你發揮想像力。

This book will awaken your imagination.

Why: Classifiers. [[Mandarin Chinese#^zh-Q0311|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E9%80%99%E6%9C%AC%E6%9B%B8%E6%9C%83%E8%AE%93%E4%BD%A0%E7%99%BC%E6%8F%AE%E6%83%B3%E5%83%8F%E5%8A%9B%E3%80%82)
^zh-Q0311-answer

**zh-Q0312** — 這本書會讓你發揮想像力。

This book will awaken your imagination.

A numeral/demonstrative commonly combines with a classifier before a counted noun. 本 is common for books, 张 for flat objects, 位 for people respectfully. Classifier choice is lexical and meaning-dependent.

Why: Classifiers. [[Mandarin Chinese#^zh-Q0312|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E9%80%99%E6%9C%AC%E6%9B%B8%E6%9C%83%E8%AE%93%E4%BD%A0%E7%99%BC%E6%8F%AE%E6%83%B3%E5%83%8F%E5%8A%9B%E3%80%82)
^zh-Q0312-answer

**zh-Q0313** — 这个家庭非常贫穷以至于无法偿还贷款。

The family is too poor to pay back the debts.

Expected form: **个**

Why: Classifiers. [[Mandarin Chinese#^zh-Q0313|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%BF%99%E4%B8%AA%E5%AE%B6%E5%BA%AD%E9%9D%9E%E5%B8%B8%E8%B4%AB%E7%A9%B7%E4%BB%A5%E8%87%B3%E4%BA%8E%E6%97%A0%E6%B3%95%E5%81%BF%E8%BF%98%E8%B4%B7%E6%AC%BE%E3%80%82)
^zh-Q0313-answer

**zh-Q0314** — 这个家庭非常贫穷以至于无法偿还贷款。

The family is too poor to pay back the debts.

Expected form: **个**

Why: Classifiers. [[Mandarin Chinese#^zh-Q0314|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%BF%99%E4%B8%AA%E5%AE%B6%E5%BA%AD%E9%9D%9E%E5%B8%B8%E8%B4%AB%E7%A9%B7%E4%BB%A5%E8%87%B3%E4%BA%8E%E6%97%A0%E6%B3%95%E5%81%BF%E8%BF%98%E8%B4%B7%E6%AC%BE%E3%80%82)
^zh-Q0314-answer

**zh-Q0315** — 这个娃娃是你自己做的吗？

Did you make this doll by yourself?

Expected form: **个**

Why: Classifiers. [[Mandarin Chinese#^zh-Q0315|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%BF%99%E4%B8%AA%E5%A8%83%E5%A8%83%E6%98%AF%E4%BD%A0%E8%87%AA%E5%B7%B1%E5%81%9A%E7%9A%84%E5%90%97%EF%BC%9F)
^zh-Q0315-answer

**zh-Q0316** — 这个娃娃是你自己做的吗？

Did you make this doll by yourself?

Why: Classifiers. [[Mandarin Chinese#^zh-Q0316|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%BF%99%E4%B8%AA%E5%A8%83%E5%A8%83%E6%98%AF%E4%BD%A0%E8%87%AA%E5%B7%B1%E5%81%9A%E7%9A%84%E5%90%97%EF%BC%9F)
^zh-Q0316-answer

**zh-Q0317** — 她一口气喝下多半杯凉茶。

She gulped down half her tea in one mouthful.

Why: Classifiers. [[Mandarin Chinese#^zh-Q0317|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A5%B9%E4%B8%80%E5%8F%A3%E6%B0%94%E5%96%9D%E4%B8%8B%E5%A4%9A%E5%8D%8A%E6%9D%AF%E5%87%89%E8%8C%B6%E3%80%82)
^zh-Q0317-answer

**zh-Q0318** — 她一口气喝下多半杯凉茶。

She gulped down half her tea in one mouthful.

A numeral/demonstrative commonly combines with a classifier before a counted noun. 本 is common for books, 张 for flat objects, 位 for people respectfully. Classifier choice is lexical and meaning-dependent.

Why: Classifiers. [[Mandarin Chinese#^zh-Q0318|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A5%B9%E4%B8%80%E5%8F%A3%E6%B0%94%E5%96%9D%E4%B8%8B%E5%A4%9A%E5%8D%8A%E6%9D%AF%E5%87%89%E8%8C%B6%E3%80%82)
^zh-Q0318-answer

**zh-Q0319** — 她喜欢网球并成为了一个网球教练。

She liked tennis and became a tennis coach.

Expected form: **个**

Why: Classifiers. [[Mandarin Chinese#^zh-Q0319|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A5%B9%E5%96%9C%E6%AC%A2%E7%BD%91%E7%90%83%E5%B9%B6%E6%88%90%E4%B8%BA%E4%BA%86%E4%B8%80%E4%B8%AA%E7%BD%91%E7%90%83%E6%95%99%E7%BB%83%E3%80%82)
^zh-Q0319-answer

**zh-Q0320** — 她喜欢网球并成为了一个网球教练。

She liked tennis and became a tennis coach.

Expected form: **个**

Why: Classifiers. [[Mandarin Chinese#^zh-Q0320|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A5%B9%E5%96%9C%E6%AC%A2%E7%BD%91%E7%90%83%E5%B9%B6%E6%88%90%E4%B8%BA%E4%BA%86%E4%B8%80%E4%B8%AA%E7%BD%91%E7%90%83%E6%95%99%E7%BB%83%E3%80%82)
^zh-Q0320-answer

**zh-Q0321** — 不下50个乘客死了。

No fewer than 50 passengers were killed.

Expected form: **个**

Why: Classifiers. [[Mandarin Chinese#^zh-Q0321|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%B8%8D%E4%B8%8B50%E4%B8%AA%E4%B9%98%E5%AE%A2%E6%AD%BB%E4%BA%86%E3%80%82)
^zh-Q0321-answer

**zh-Q0322** — 不下50个乘客死了。

No fewer than 50 passengers were killed.

Why: Classifiers. [[Mandarin Chinese#^zh-Q0322|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%B8%8D%E4%B8%8B50%E4%B8%AA%E4%B9%98%E5%AE%A2%E6%AD%BB%E4%BA%86%E3%80%82)
^zh-Q0322-answer

**zh-Q0323** — 一位老人在街上摔斷了腿。

An elderly person in the street fell and broke a leg.

Why: Classifiers. [[Mandarin Chinese#^zh-Q0323|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%B8%80%E4%BD%8D%E8%80%81%E4%BA%BA%E5%9C%A8%E8%A1%97%E4%B8%8A%E6%91%94%E6%96%B7%E4%BA%86%E8%85%BF%E3%80%82)
^zh-Q0323-answer

**zh-Q0324** — 一位老人在街上摔斷了腿。

An elderly person in the street fell and broke a leg.

A numeral/demonstrative commonly combines with a classifier before a counted noun. 本 is common for books, 张 for flat objects, 位 for people respectfully. Classifier choice is lexical and meaning-dependent.

Why: Classifiers. [[Mandarin Chinese#^zh-Q0324|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%B8%80%E4%BD%8D%E8%80%81%E4%BA%BA%E5%9C%A8%E8%A1%97%E4%B8%8A%E6%91%94%E6%96%B7%E4%BA%86%E8%85%BF%E3%80%82)
^zh-Q0324-answer

**zh-Q0325** — 在厦威夷，一个人可以一年到头享受海水浴的乐趣。

In Hawaii, one can swim in the ocean all year round.

Expected form: **个**

Why: Classifiers. [[Mandarin Chinese#^zh-Q0325|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%9C%A8%E5%8E%A6%E5%A8%81%E5%A4%B7%EF%BC%8C%E4%B8%80%E4%B8%AA%E4%BA%BA%E5%8F%AF%E4%BB%A5%E4%B8%80%E5%B9%B4%E5%88%B0%E5%A4%B4%E4%BA%AB%E5%8F%97%E6%B5%B7%E6%B0%B4%E6%B5%B4%E7%9A%84%E4%B9%90%E8%B6%A3%E3%80%82)
^zh-Q0325-answer

**zh-Q0326** — 在厦威夷，一个人可以一年到头享受海水浴的乐趣。

In Hawaii, one can swim in the ocean all year round.

Expected form: **个**

Why: Classifiers. [[Mandarin Chinese#^zh-Q0326|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%9C%A8%E5%8E%A6%E5%A8%81%E5%A4%B7%EF%BC%8C%E4%B8%80%E4%B8%AA%E4%BA%BA%E5%8F%AF%E4%BB%A5%E4%B8%80%E5%B9%B4%E5%88%B0%E5%A4%B4%E4%BA%AB%E5%8F%97%E6%B5%B7%E6%B0%B4%E6%B5%B4%E7%9A%84%E4%B9%90%E8%B6%A3%E3%80%82)
^zh-Q0326-answer

**zh-Q0327** — 那个护士人很好，又有礼貌。

That nurse is very kind and polite.

Expected form: **个**

Why: Classifiers. [[Mandarin Chinese#^zh-Q0327|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E9%82%A3%E4%B8%AA%E6%8A%A4%E5%A3%AB%E4%BA%BA%E5%BE%88%E5%A5%BD%EF%BC%8C%E5%8F%88%E6%9C%89%E7%A4%BC%E8%B2%8C%E3%80%82)
^zh-Q0327-answer

**zh-Q0328** — 那个护士人很好，又有礼貌。

That nurse is very kind and polite.

Why: Classifiers. [[Mandarin Chinese#^zh-Q0328|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E9%82%A3%E4%B8%AA%E6%8A%A4%E5%A3%AB%E4%BA%BA%E5%BE%88%E5%A5%BD%EF%BC%8C%E5%8F%88%E6%9C%89%E7%A4%BC%E8%B2%8C%E3%80%82)
^zh-Q0328-answer

**zh-Q0329** — 在我的邻近区域有一个大超市。

There is a big supermarket in my neighborhood.

Why: Classifiers. [[Mandarin Chinese#^zh-Q0329|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%9C%A8%E6%88%91%E7%9A%84%E9%82%BB%E8%BF%91%E5%8C%BA%E5%9F%9F%E6%9C%89%E4%B8%80%E4%B8%AA%E5%A4%A7%E8%B6%85%E5%B8%82%E3%80%82)
^zh-Q0329-answer

**zh-Q0330** — 在我的邻近区域有一个大超市。

There is a big supermarket in my neighborhood.

A numeral/demonstrative commonly combines with a classifier before a counted noun. 本 is common for books, 张 for flat objects, 位 for people respectfully. Classifier choice is lexical and meaning-dependent.

Why: Classifiers. [[Mandarin Chinese#^zh-Q0330|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%9C%A8%E6%88%91%E7%9A%84%E9%82%BB%E8%BF%91%E5%8C%BA%E5%9F%9F%E6%9C%89%E4%B8%80%E4%B8%AA%E5%A4%A7%E8%B6%85%E5%B8%82%E3%80%82)
^zh-Q0330-answer

**zh-Q0331** — 那个男人年纪很大。

The man is old.

Expected form: **个**

Why: Classifiers. [[Mandarin Chinese#^zh-Q0331|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E9%82%A3%E4%B8%AA%E7%94%B7%E4%BA%BA%E5%B9%B4%E7%BA%AA%E5%BE%88%E5%A4%A7%E3%80%82)
^zh-Q0331-answer

**zh-Q0332** — 那个男人年纪很大。

The man is old.

Expected form: **个**

Why: Classifiers. [[Mandarin Chinese#^zh-Q0332|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E9%82%A3%E4%B8%AA%E7%94%B7%E4%BA%BA%E5%B9%B4%E7%BA%AA%E5%BE%88%E5%A4%A7%E3%80%82)
^zh-Q0332-answer

**zh-Q0333** — 里约热内卢的一条自行车道倒塌了。

A bike path collapsed in Rio.

Expected form: **条**

Why: Classifiers. [[Mandarin Chinese#^zh-Q0333|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E9%87%8C%E7%BA%A6%E7%83%AD%E5%86%85%E5%8D%A2%E7%9A%84%E4%B8%80%E6%9D%A1%E8%87%AA%E8%A1%8C%E8%BD%A6%E9%81%93%E5%80%92%E5%A1%8C%E4%BA%86%E3%80%82)
^zh-Q0333-answer

**zh-Q0334** — 里约热内卢的一条自行车道倒塌了。

A bike path collapsed in Rio.

Why: Classifiers. [[Mandarin Chinese#^zh-Q0334|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E9%87%8C%E7%BA%A6%E7%83%AD%E5%86%85%E5%8D%A2%E7%9A%84%E4%B8%80%E6%9D%A1%E8%87%AA%E8%A1%8C%E8%BD%A6%E9%81%93%E5%80%92%E5%A1%8C%E4%BA%86%E3%80%82)
^zh-Q0334-answer

**zh-Q0335** — 他是个很安静的人，头顶有点秃。

He's a quiet man, a little bald on top.

Why: Classifiers. [[Mandarin Chinese#^zh-Q0335|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%96%E6%98%AF%E4%B8%AA%E5%BE%88%E5%AE%89%E9%9D%99%E7%9A%84%E4%BA%BA%EF%BC%8C%E5%A4%B4%E9%A1%B6%E6%9C%89%E7%82%B9%E7%A7%83%E3%80%82)
^zh-Q0335-answer

**zh-Q0336** — 他是个很安静的人，头顶有点秃。

He's a quiet man, a little bald on top.

A numeral/demonstrative commonly combines with a classifier before a counted noun. 本 is common for books, 张 for flat objects, 位 for people respectfully. Classifier choice is lexical and meaning-dependent.

Why: Classifiers. [[Mandarin Chinese#^zh-Q0336|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%96%E6%98%AF%E4%B8%AA%E5%BE%88%E5%AE%89%E9%9D%99%E7%9A%84%E4%BA%BA%EF%BC%8C%E5%A4%B4%E9%A1%B6%E6%9C%89%E7%82%B9%E7%A7%83%E3%80%82)
^zh-Q0336-answer

**zh-Q0337** — 这本书是不是他一直用的？

Is this book the one he always uses?

Expected form: **本**

Why: Classifiers. [[Mandarin Chinese#^zh-Q0337|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%BF%99%E6%9C%AC%E4%B9%A6%E6%98%AF%E4%B8%8D%E6%98%AF%E4%BB%96%E4%B8%80%E7%9B%B4%E7%94%A8%E7%9A%84%EF%BC%9F)
^zh-Q0337-answer

**zh-Q0338** — 这本书是不是他一直用的？

Is this book the one he always uses?

Expected form: **本**

Why: Classifiers. [[Mandarin Chinese#^zh-Q0338|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%BF%99%E6%9C%AC%E4%B9%A6%E6%98%AF%E4%B8%8D%E6%98%AF%E4%BB%96%E4%B8%80%E7%9B%B4%E7%94%A8%E7%9A%84%EF%BC%9F)
^zh-Q0338-answer

**zh-Q0339** — 你的学校在这个城市吗？

Is your school in this town?

Expected form: **个**

Why: Classifiers. [[Mandarin Chinese#^zh-Q0339|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E7%9A%84%E5%AD%A6%E6%A0%A1%E5%9C%A8%E8%BF%99%E4%B8%AA%E5%9F%8E%E5%B8%82%E5%90%97%EF%BC%9F)
^zh-Q0339-answer

**zh-Q0340** — 你的学校在这个城市吗？

Is your school in this town?

Why: Classifiers. [[Mandarin Chinese#^zh-Q0340|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E7%9A%84%E5%AD%A6%E6%A0%A1%E5%9C%A8%E8%BF%99%E4%B8%AA%E5%9F%8E%E5%B8%82%E5%90%97%EF%BC%9F)
^zh-Q0340-answer

**zh-Q0341** — 我每次讀這本書都會有新發現。

Every time I read this book, I find something new.

Why: Classifiers. [[Mandarin Chinese#^zh-Q0341|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E6%AF%8F%E6%AC%A1%E8%AE%80%E9%80%99%E6%9C%AC%E6%9B%B8%E9%83%BD%E6%9C%83%E6%9C%89%E6%96%B0%E7%99%BC%E7%8F%BE%E3%80%82)
^zh-Q0341-answer

**zh-Q0342** — 我每次讀這本書都會有新發現。

Every time I read this book, I find something new.

A numeral/demonstrative commonly combines with a classifier before a counted noun. 本 is common for books, 张 for flat objects, 位 for people respectfully. Classifier choice is lexical and meaning-dependent.

Why: Classifiers. [[Mandarin Chinese#^zh-Q0342|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E6%AF%8F%E6%AC%A1%E8%AE%80%E9%80%99%E6%9C%AC%E6%9B%B8%E9%83%BD%E6%9C%83%E6%9C%89%E6%96%B0%E7%99%BC%E7%8F%BE%E3%80%82)
^zh-Q0342-answer

**zh-Q0343** — 为躲避风暴，我们躲到了附近的一个谷仓内。

We took refuge from the storm in a nearby barn.

Expected form: **个**

Why: Classifiers. [[Mandarin Chinese#^zh-Q0343|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%B8%BA%E8%BA%B2%E9%81%BF%E9%A3%8E%E6%9A%B4%EF%BC%8C%E6%88%91%E4%BB%AC%E8%BA%B2%E5%88%B0%E4%BA%86%E9%99%84%E8%BF%91%E7%9A%84%E4%B8%80%E4%B8%AA%E8%B0%B7%E4%BB%93%E5%86%85%E3%80%82)
^zh-Q0343-answer

**zh-Q0344** — 为躲避风暴，我们躲到了附近的一个谷仓内。

We took refuge from the storm in a nearby barn.

Expected form: **个**

Why: Classifiers. [[Mandarin Chinese#^zh-Q0344|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%B8%BA%E8%BA%B2%E9%81%BF%E9%A3%8E%E6%9A%B4%EF%BC%8C%E6%88%91%E4%BB%AC%E8%BA%B2%E5%88%B0%E4%BA%86%E9%99%84%E8%BF%91%E7%9A%84%E4%B8%80%E4%B8%AA%E8%B0%B7%E4%BB%93%E5%86%85%E3%80%82)
^zh-Q0344-answer

**zh-Q0345** — 我们像澄清这个问题

We want to clear up this problem.

Expected form: **个**

Why: Classifiers. [[Mandarin Chinese#^zh-Q0345|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E4%BB%AC%E5%83%8F%E6%BE%84%E6%B8%85%E8%BF%99%E4%B8%AA%E9%97%AE%E9%A2%98)
^zh-Q0345-answer

**zh-Q0346** — 我们像澄清这个问题

We want to clear up this problem.

Why: Classifiers. [[Mandarin Chinese#^zh-Q0346|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E4%BB%AC%E5%83%8F%E6%BE%84%E6%B8%85%E8%BF%99%E4%B8%AA%E9%97%AE%E9%A2%98)
^zh-Q0346-answer

**zh-Q0347** — 他们的合同在这个月底到期。

Their contract is to run out at the end of this month.

Why: Classifiers. [[Mandarin Chinese#^zh-Q0347|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%96%E4%BB%AC%E7%9A%84%E5%90%88%E5%90%8C%E5%9C%A8%E8%BF%99%E4%B8%AA%E6%9C%88%E5%BA%95%E5%88%B0%E6%9C%9F%E3%80%82)
^zh-Q0347-answer

**zh-Q0348** — 他们的合同在这个月底到期。

Their contract is to run out at the end of this month.

A numeral/demonstrative commonly combines with a classifier before a counted noun. 本 is common for books, 张 for flat objects, 位 for people respectfully. Classifier choice is lexical and meaning-dependent.

Why: Classifiers. [[Mandarin Chinese#^zh-Q0348|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%96%E4%BB%AC%E7%9A%84%E5%90%88%E5%90%8C%E5%9C%A8%E8%BF%99%E4%B8%AA%E6%9C%88%E5%BA%95%E5%88%B0%E6%9C%9F%E3%80%82)
^zh-Q0348-answer

**zh-Q0349** — 我想到那位當記者的女人。

I think of the woman as a journalist.

Expected form: **位**

Why: Classifiers. [[Mandarin Chinese#^zh-Q0349|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E6%83%B3%E5%88%B0%E9%82%A3%E4%BD%8D%E7%95%B6%E8%A8%98%E8%80%85%E7%9A%84%E5%A5%B3%E4%BA%BA%E3%80%82)
^zh-Q0349-answer

**zh-Q0350** — 我想到那位當記者的女人。

I think of the woman as a journalist.

Expected form: **位**

Why: Classifiers. [[Mandarin Chinese#^zh-Q0350|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E6%83%B3%E5%88%B0%E9%82%A3%E4%BD%8D%E7%95%B6%E8%A8%98%E8%80%85%E7%9A%84%E5%A5%B3%E4%BA%BA%E3%80%82)
^zh-Q0350-answer


### Answers 351–400

**zh-Q0351** — 汤姆如果想通过这门课，就需要加劲学习。

Tom needs to study more if he hopes to pass this class.

Expected form: **这**

Why: Demonstratives. [[Mandarin Chinese#^zh-Q0351|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%B1%A4%E5%A7%86%E5%A6%82%E6%9E%9C%E6%83%B3%E9%80%9A%E8%BF%87%E8%BF%99%E9%97%A8%E8%AF%BE%EF%BC%8C%E5%B0%B1%E9%9C%80%E8%A6%81%E5%8A%A0%E5%8A%B2%E5%AD%A6%E4%B9%A0%E3%80%82)
^zh-Q0351-answer

**zh-Q0352** — 汤姆如果想通过这门课，就需要加劲学习。

Tom needs to study more if he hopes to pass this class.

Why: Demonstratives. [[Mandarin Chinese#^zh-Q0352|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%B1%A4%E5%A7%86%E5%A6%82%E6%9E%9C%E6%83%B3%E9%80%9A%E8%BF%87%E8%BF%99%E9%97%A8%E8%AF%BE%EF%BC%8C%E5%B0%B1%E9%9C%80%E8%A6%81%E5%8A%A0%E5%8A%B2%E5%AD%A6%E4%B9%A0%E3%80%82)
^zh-Q0352-answer

**zh-Q0353** — 这件事他铭记于心。

The incident was etched in his memory.

Why: Demonstratives. [[Mandarin Chinese#^zh-Q0353|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%BF%99%E4%BB%B6%E4%BA%8B%E4%BB%96%E9%93%AD%E8%AE%B0%E4%BA%8E%E5%BF%83%E3%80%82)
^zh-Q0353-answer

**zh-Q0354** — 这件事他铭记于心。

The incident was etched in his memory.

Demonstratives distinguish near/far or discourse reference. Counted noun phrases usually include the appropriate classifier. 这/那 also occur in other constructions, so determine whether a noun phrase follows.

Why: Demonstratives. [[Mandarin Chinese#^zh-Q0354|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%BF%99%E4%BB%B6%E4%BA%8B%E4%BB%96%E9%93%AD%E8%AE%B0%E4%BA%8E%E5%BF%83%E3%80%82)
^zh-Q0354-answer

**zh-Q0355** — 那房子比他那座好得多了。

That house is much better than his house.

Expected form: **那**

Why: Demonstratives. [[Mandarin Chinese#^zh-Q0355|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E9%82%A3%E6%88%BF%E5%AD%90%E6%AF%94%E4%BB%96%E9%82%A3%E5%BA%A7%E5%A5%BD%E5%BE%97%E5%A4%9A%E4%BA%86%E3%80%82)
^zh-Q0355-answer

**zh-Q0356** — 那房子比他那座好得多了。

That house is much better than his house.

Expected form: **那**

Why: Demonstratives. [[Mandarin Chinese#^zh-Q0356|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E9%82%A3%E6%88%BF%E5%AD%90%E6%AF%94%E4%BB%96%E9%82%A3%E5%BA%A7%E5%A5%BD%E5%BE%97%E5%A4%9A%E4%BA%86%E3%80%82)
^zh-Q0356-answer

**zh-Q0357** — 从这里到那里驾车一小时。

It is an hour's drive from here to there.

Expected form: **这**

Why: Demonstratives. [[Mandarin Chinese#^zh-Q0357|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%8E%E8%BF%99%E9%87%8C%E5%88%B0%E9%82%A3%E9%87%8C%E9%A9%BE%E8%BD%A6%E4%B8%80%E5%B0%8F%E6%97%B6%E3%80%82)
^zh-Q0357-answer

**zh-Q0358** — 从这里到那里驾车一小时。

It is an hour's drive from here to there.

Why: Demonstratives. [[Mandarin Chinese#^zh-Q0358|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%8E%E8%BF%99%E9%87%8C%E5%88%B0%E9%82%A3%E9%87%8C%E9%A9%BE%E8%BD%A6%E4%B8%80%E5%B0%8F%E6%97%B6%E3%80%82)
^zh-Q0358-answer

**zh-Q0359** — 自那以后他便过起了艰难的生活。

After that his life got even tougher.

Why: Demonstratives. [[Mandarin Chinese#^zh-Q0359|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%87%AA%E9%82%A3%E4%BB%A5%E5%90%8E%E4%BB%96%E4%BE%BF%E8%BF%87%E8%B5%B7%E4%BA%86%E8%89%B0%E9%9A%BE%E7%9A%84%E7%94%9F%E6%B4%BB%E3%80%82)
^zh-Q0359-answer

**zh-Q0360** — 自那以后他便过起了艰难的生活。

After that his life got even tougher.

Demonstratives distinguish near/far or discourse reference. Counted noun phrases usually include the appropriate classifier. 这/那 also occur in other constructions, so determine whether a noun phrase follows.

Why: Demonstratives. [[Mandarin Chinese#^zh-Q0360|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%87%AA%E9%82%A3%E4%BB%A5%E5%90%8E%E4%BB%96%E4%BE%BF%E8%BF%87%E8%B5%B7%E4%BA%86%E8%89%B0%E9%9A%BE%E7%9A%84%E7%94%9F%E6%B4%BB%E3%80%82)
^zh-Q0360-answer

**zh-Q0361** — 對了，就用那個吧！

Alright, let's settle on that one!

Expected form: **那**

Why: Demonstratives. [[Mandarin Chinese#^zh-Q0361|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%B0%8D%E4%BA%86%EF%BC%8C%E5%B0%B1%E7%94%A8%E9%82%A3%E5%80%8B%E5%90%A7%EF%BC%81)
^zh-Q0361-answer

**zh-Q0362** — 對了，就用那個吧！

Alright, let's settle on that one!

Expected form: **那**

Why: Demonstratives. [[Mandarin Chinese#^zh-Q0362|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%B0%8D%E4%BA%86%EF%BC%8C%E5%B0%B1%E7%94%A8%E9%82%A3%E5%80%8B%E5%90%A7%EF%BC%81)
^zh-Q0362-answer

**zh-Q0363** — 让我像这样继续下去是绝对不可能的。

It's absolutely impossible for me to go on like this.

Expected form: **这**

Why: Demonstratives. [[Mandarin Chinese#^zh-Q0363|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%AE%A9%E6%88%91%E5%83%8F%E8%BF%99%E6%A0%B7%E7%BB%A7%E7%BB%AD%E4%B8%8B%E5%8E%BB%E6%98%AF%E7%BB%9D%E5%AF%B9%E4%B8%8D%E5%8F%AF%E8%83%BD%E7%9A%84%E3%80%82)
^zh-Q0363-answer

**zh-Q0364** — 让我像这样继续下去是绝对不可能的。

It's absolutely impossible for me to go on like this.

Why: Demonstratives. [[Mandarin Chinese#^zh-Q0364|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%AE%A9%E6%88%91%E5%83%8F%E8%BF%99%E6%A0%B7%E7%BB%A7%E7%BB%AD%E4%B8%8B%E5%8E%BB%E6%98%AF%E7%BB%9D%E5%AF%B9%E4%B8%8D%E5%8F%AF%E8%83%BD%E7%9A%84%E3%80%82)
^zh-Q0364-answer

**zh-Q0365** — 你還記得我的生日，那真是太好了。

It is really marvelous of you to remember my birthday.

Why: Demonstratives. [[Mandarin Chinese#^zh-Q0365|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E9%82%84%E8%A8%98%E5%BE%97%E6%88%91%E7%9A%84%E7%94%9F%E6%97%A5%EF%BC%8C%E9%82%A3%E7%9C%9F%E6%98%AF%E5%A4%AA%E5%A5%BD%E4%BA%86%E3%80%82)
^zh-Q0365-answer

**zh-Q0366** — 你還記得我的生日，那真是太好了。

It is really marvelous of you to remember my birthday.

Demonstratives distinguish near/far or discourse reference. Counted noun phrases usually include the appropriate classifier. 这/那 also occur in other constructions, so determine whether a noun phrase follows.

Why: Demonstratives. [[Mandarin Chinese#^zh-Q0366|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E9%82%84%E8%A8%98%E5%BE%97%E6%88%91%E7%9A%84%E7%94%9F%E6%97%A5%EF%BC%8C%E9%82%A3%E7%9C%9F%E6%98%AF%E5%A4%AA%E5%A5%BD%E4%BA%86%E3%80%82)
^zh-Q0366-answer

**zh-Q0367** — 对于这份工作来说，我的年龄太老了。

I'm getting too old for this job.

Expected form: **这**

Why: Demonstratives. [[Mandarin Chinese#^zh-Q0367|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%AF%B9%E4%BA%8E%E8%BF%99%E4%BB%BD%E5%B7%A5%E4%BD%9C%E6%9D%A5%E8%AF%B4%EF%BC%8C%E6%88%91%E7%9A%84%E5%B9%B4%E9%BE%84%E5%A4%AA%E8%80%81%E4%BA%86%E3%80%82)
^zh-Q0367-answer

**zh-Q0368** — 对于这份工作来说，我的年龄太老了。

I'm getting too old for this job.

Expected form: **这**

Why: Demonstratives. [[Mandarin Chinese#^zh-Q0368|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%AF%B9%E4%BA%8E%E8%BF%99%E4%BB%BD%E5%B7%A5%E4%BD%9C%E6%9D%A5%E8%AF%B4%EF%BC%8C%E6%88%91%E7%9A%84%E5%B9%B4%E9%BE%84%E5%A4%AA%E8%80%81%E4%BA%86%E3%80%82)
^zh-Q0368-answer

**zh-Q0369** — 那是我最喜歡的部分。

That's the part I liked best.

Expected form: **那**

Why: Demonstratives. [[Mandarin Chinese#^zh-Q0369|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E9%82%A3%E6%98%AF%E6%88%91%E6%9C%80%E5%96%9C%E6%AD%A1%E7%9A%84%E9%83%A8%E5%88%86%E3%80%82)
^zh-Q0369-answer

**zh-Q0370** — 那是我最喜歡的部分。

That's the part I liked best.

Why: Demonstratives. [[Mandarin Chinese#^zh-Q0370|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E9%82%A3%E6%98%AF%E6%88%91%E6%9C%80%E5%96%9C%E6%AD%A1%E7%9A%84%E9%83%A8%E5%88%86%E3%80%82)
^zh-Q0370-answer

**zh-Q0371** — 我不知道“oindre”这词的翻译。

I don't know the translation of the word 'oindre'.

Why: Demonstratives. [[Mandarin Chinese#^zh-Q0371|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E4%B8%8D%E7%9F%A5%E9%81%93%E2%80%9Coindre%E2%80%9D%E8%BF%99%E8%AF%8D%E7%9A%84%E7%BF%BB%E8%AF%91%E3%80%82)
^zh-Q0371-answer

**zh-Q0372** — 我不知道“oindre”这词的翻译。

I don't know the translation of the word 'oindre'.

Demonstratives distinguish near/far or discourse reference. Counted noun phrases usually include the appropriate classifier. 这/那 also occur in other constructions, so determine whether a noun phrase follows.

Why: Demonstratives. [[Mandarin Chinese#^zh-Q0372|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E4%B8%8D%E7%9F%A5%E9%81%93%E2%80%9Coindre%E2%80%9D%E8%BF%99%E8%AF%8D%E7%9A%84%E7%BF%BB%E8%AF%91%E3%80%82)
^zh-Q0372-answer

**zh-Q0373** — 这些餐巾颜色相同，但大小不同。

The colours of the napkins are the same, but the sizes are not.

Expected form: **这些**

Why: Demonstratives. [[Mandarin Chinese#^zh-Q0373|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%BF%99%E4%BA%9B%E9%A4%90%E5%B7%BE%E9%A2%9C%E8%89%B2%E7%9B%B8%E5%90%8C%EF%BC%8C%E4%BD%86%E5%A4%A7%E5%B0%8F%E4%B8%8D%E5%90%8C%E3%80%82)
^zh-Q0373-answer

**zh-Q0374** — 这些餐巾颜色相同，但大小不同。

The colours of the napkins are the same, but the sizes are not.

Expected form: **这些**

Why: Demonstratives. [[Mandarin Chinese#^zh-Q0374|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%BF%99%E4%BA%9B%E9%A4%90%E5%B7%BE%E9%A2%9C%E8%89%B2%E7%9B%B8%E5%90%8C%EF%BC%8C%E4%BD%86%E5%A4%A7%E5%B0%8F%E4%B8%8D%E5%90%8C%E3%80%82)
^zh-Q0374-answer

**zh-Q0375** — 我想知道为什么汤姆要我们那样做。

I want to know why Tom wants us to do that.

Expected form: **那**

Why: Demonstratives. [[Mandarin Chinese#^zh-Q0375|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E6%83%B3%E7%9F%A5%E9%81%93%E4%B8%BA%E4%BB%80%E4%B9%88%E6%B1%A4%E5%A7%86%E8%A6%81%E6%88%91%E4%BB%AC%E9%82%A3%E6%A0%B7%E5%81%9A%E3%80%82)
^zh-Q0375-answer

**zh-Q0376** — 我想知道为什么汤姆要我们那样做。

I want to know why Tom wants us to do that.

Why: Demonstratives. [[Mandarin Chinese#^zh-Q0376|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E6%83%B3%E7%9F%A5%E9%81%93%E4%B8%BA%E4%BB%80%E4%B9%88%E6%B1%A4%E5%A7%86%E8%A6%81%E6%88%91%E4%BB%AC%E9%82%A3%E6%A0%B7%E5%81%9A%E3%80%82)
^zh-Q0376-answer

**zh-Q0377** — 我被这情景吓到了。

I was frightened by the sight.

Why: Demonstratives. [[Mandarin Chinese#^zh-Q0377|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E8%A2%AB%E8%BF%99%E6%83%85%E6%99%AF%E5%90%93%E5%88%B0%E4%BA%86%E3%80%82)
^zh-Q0377-answer

**zh-Q0378** — 我被这情景吓到了。

I was frightened by the sight.

Demonstratives distinguish near/far or discourse reference. Counted noun phrases usually include the appropriate classifier. 这/那 also occur in other constructions, so determine whether a noun phrase follows.

Why: Demonstratives. [[Mandarin Chinese#^zh-Q0378|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E8%A2%AB%E8%BF%99%E6%83%85%E6%99%AF%E5%90%93%E5%88%B0%E4%BA%86%E3%80%82)
^zh-Q0378-answer

**zh-Q0379** — 我们在这里下车吧。

Let's get off here.

Expected form: **这**

Why: Demonstratives. [[Mandarin Chinese#^zh-Q0379|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E4%BB%AC%E5%9C%A8%E8%BF%99%E9%87%8C%E4%B8%8B%E8%BD%A6%E5%90%A7%E3%80%82)
^zh-Q0379-answer

**zh-Q0380** — 我们在这里下车吧。

Let's get off here.

Expected form: **这**

Why: Demonstratives. [[Mandarin Chinese#^zh-Q0380|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E4%BB%AC%E5%9C%A8%E8%BF%99%E9%87%8C%E4%B8%8B%E8%BD%A6%E5%90%A7%E3%80%82)
^zh-Q0380-answer

**zh-Q0381** — 善待那些恨你们的人.

Do good to those who hate you.

Expected form: **那些**

Why: Demonstratives. [[Mandarin Chinese#^zh-Q0381|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%96%84%E5%BE%85%E9%82%A3%E4%BA%9B%E6%81%A8%E4%BD%A0%E4%BB%AC%E7%9A%84%E4%BA%BA.)
^zh-Q0381-answer

**zh-Q0382** — 善待那些恨你们的人.

Do good to those who hate you.

Why: Demonstratives. [[Mandarin Chinese#^zh-Q0382|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%96%84%E5%BE%85%E9%82%A3%E4%BA%9B%E6%81%A8%E4%BD%A0%E4%BB%AC%E7%9A%84%E4%BA%BA.)
^zh-Q0382-answer

**zh-Q0383** — 記者想寫一篇文章，以便吸引公眾對那件事情的注意。

The journalist wanted to write an article that would draw public attention to the issue.

Why: Demonstratives. [[Mandarin Chinese#^zh-Q0383|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%A8%98%E8%80%85%E6%83%B3%E5%AF%AB%E4%B8%80%E7%AF%87%E6%96%87%E7%AB%A0%EF%BC%8C%E4%BB%A5%E4%BE%BF%E5%90%B8%E5%BC%95%E5%85%AC%E7%9C%BE%E5%B0%8D%E9%82%A3%E4%BB%B6%E4%BA%8B%E6%83%85%E7%9A%84%E6%B3%A8%E6%84%8F%E3%80%82)
^zh-Q0383-answer

**zh-Q0384** — 記者想寫一篇文章，以便吸引公眾對那件事情的注意。

The journalist wanted to write an article that would draw public attention to the issue.

Demonstratives distinguish near/far or discourse reference. Counted noun phrases usually include the appropriate classifier. 这/那 also occur in other constructions, so determine whether a noun phrase follows.

Why: Demonstratives. [[Mandarin Chinese#^zh-Q0384|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%A8%98%E8%80%85%E6%83%B3%E5%AF%AB%E4%B8%80%E7%AF%87%E6%96%87%E7%AB%A0%EF%BC%8C%E4%BB%A5%E4%BE%BF%E5%90%B8%E5%BC%95%E5%85%AC%E7%9C%BE%E5%B0%8D%E9%82%A3%E4%BB%B6%E4%BA%8B%E6%83%85%E7%9A%84%E6%B3%A8%E6%84%8F%E3%80%82)
^zh-Q0384-answer

**zh-Q0385** — 关于那件事你之前怎么想的？

How did you feel about that?

Expected form: **那**

Why: Demonstratives. [[Mandarin Chinese#^zh-Q0385|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%85%B3%E4%BA%8E%E9%82%A3%E4%BB%B6%E4%BA%8B%E4%BD%A0%E4%B9%8B%E5%89%8D%E6%80%8E%E4%B9%88%E6%83%B3%E7%9A%84%EF%BC%9F)
^zh-Q0385-answer

**zh-Q0386** — 关于那件事你之前怎么想的？

How did you feel about that?

Expected form: **那**

Why: Demonstratives. [[Mandarin Chinese#^zh-Q0386|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%85%B3%E4%BA%8E%E9%82%A3%E4%BB%B6%E4%BA%8B%E4%BD%A0%E4%B9%8B%E5%89%8D%E6%80%8E%E4%B9%88%E6%83%B3%E7%9A%84%EF%BC%9F)
^zh-Q0386-answer

**zh-Q0387** — 他以牺牲自己的健康为代价完成了这项工作。

He did it at the expense of his health.

Expected form: **这**

Why: Demonstratives. [[Mandarin Chinese#^zh-Q0387|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%96%E4%BB%A5%E7%89%BA%E7%89%B2%E8%87%AA%E5%B7%B1%E7%9A%84%E5%81%A5%E5%BA%B7%E4%B8%BA%E4%BB%A3%E4%BB%B7%E5%AE%8C%E6%88%90%E4%BA%86%E8%BF%99%E9%A1%B9%E5%B7%A5%E4%BD%9C%E3%80%82)
^zh-Q0387-answer

**zh-Q0388** — 他以牺牲自己的健康为代价完成了这项工作。

He did it at the expense of his health.

Why: Demonstratives. [[Mandarin Chinese#^zh-Q0388|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%96%E4%BB%A5%E7%89%BA%E7%89%B2%E8%87%AA%E5%B7%B1%E7%9A%84%E5%81%A5%E5%BA%B7%E4%B8%BA%E4%BB%A3%E4%BB%B7%E5%AE%8C%E6%88%90%E4%BA%86%E8%BF%99%E9%A1%B9%E5%B7%A5%E4%BD%9C%E3%80%82)
^zh-Q0388-answer

**zh-Q0389** — 你看这两件做工要比那些讲究。

See how much more carefully made these are compared to those?

Why: Demonstratives. [[Mandarin Chinese#^zh-Q0389|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E7%9C%8B%E8%BF%99%E4%B8%A4%E4%BB%B6%E5%81%9A%E5%B7%A5%E8%A6%81%E6%AF%94%E9%82%A3%E4%BA%9B%E8%AE%B2%E7%A9%B6%E3%80%82)
^zh-Q0389-answer

**zh-Q0390** — 你看这两件做工要比那些讲究。

See how much more carefully made these are compared to those?

Demonstratives distinguish near/far or discourse reference. Counted noun phrases usually include the appropriate classifier. 这/那 also occur in other constructions, so determine whether a noun phrase follows.

Why: Demonstratives. [[Mandarin Chinese#^zh-Q0390|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E7%9C%8B%E8%BF%99%E4%B8%A4%E4%BB%B6%E5%81%9A%E5%B7%A5%E8%A6%81%E6%AF%94%E9%82%A3%E4%BA%9B%E8%AE%B2%E7%A9%B6%E3%80%82)
^zh-Q0390-answer

**zh-Q0391** — 我们今天所认识的工业在那个时代不存在。

Industry as we know it today didn't exist in those days.

Expected form: **那个**

Why: Demonstratives. [[Mandarin Chinese#^zh-Q0391|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E4%BB%AC%E4%BB%8A%E5%A4%A9%E6%89%80%E8%AE%A4%E8%AF%86%E7%9A%84%E5%B7%A5%E4%B8%9A%E5%9C%A8%E9%82%A3%E4%B8%AA%E6%97%B6%E4%BB%A3%E4%B8%8D%E5%AD%98%E5%9C%A8%E3%80%82)
^zh-Q0391-answer

**zh-Q0392** — 我们今天所认识的工业在那个时代不存在。

Industry as we know it today didn't exist in those days.

Expected form: **那个**

Why: Demonstratives. [[Mandarin Chinese#^zh-Q0392|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E4%BB%AC%E4%BB%8A%E5%A4%A9%E6%89%80%E8%AE%A4%E8%AF%86%E7%9A%84%E5%B7%A5%E4%B8%9A%E5%9C%A8%E9%82%A3%E4%B8%AA%E6%97%B6%E4%BB%A3%E4%B8%8D%E5%AD%98%E5%9C%A8%E3%80%82)
^zh-Q0392-answer

**zh-Q0393** — 我希望所有那些想要修訂現行著作權法的人一個從容不迫的夜晚，但實際上所有其他的人也一樣。

I wish all those an unhurried night who want a revision of the existing copyright laws, but actually all the others too.

Expected form: **那些**

Why: Demonstratives. [[Mandarin Chinese#^zh-Q0393|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E5%B8%8C%E6%9C%9B%E6%89%80%E6%9C%89%E9%82%A3%E4%BA%9B%E6%83%B3%E8%A6%81%E4%BF%AE%E8%A8%82%E7%8F%BE%E8%A1%8C%E8%91%97%E4%BD%9C%E6%AC%8A%E6%B3%95%E7%9A%84%E4%BA%BA%E4%B8%80%E5%80%8B%E5%BE%9E%E5%AE%B9%E4%B8%8D%E8%BF%AB%E7%9A%84%E5%A4%9C%E6%99%9A%EF%BC%8C%E4%BD%86%E5%AF%A6%E9%9A%9B%E4%B8%8A%E6%89%80%E6%9C%89%E5%85%B6%E4%BB%96%E7%9A%84%E4%BA%BA%E4%B9%9F%E4%B8%80%E6%A8%A3%E3%80%82)
^zh-Q0393-answer

**zh-Q0394** — 我希望所有那些想要修訂現行著作權法的人一個從容不迫的夜晚，但實際上所有其他的人也一樣。

I wish all those an unhurried night who want a revision of the existing copyright laws, but actually all the others too.

Why: Demonstratives. [[Mandarin Chinese#^zh-Q0394|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E5%B8%8C%E6%9C%9B%E6%89%80%E6%9C%89%E9%82%A3%E4%BA%9B%E6%83%B3%E8%A6%81%E4%BF%AE%E8%A8%82%E7%8F%BE%E8%A1%8C%E8%91%97%E4%BD%9C%E6%AC%8A%E6%B3%95%E7%9A%84%E4%BA%BA%E4%B8%80%E5%80%8B%E5%BE%9E%E5%AE%B9%E4%B8%8D%E8%BF%AB%E7%9A%84%E5%A4%9C%E6%99%9A%EF%BC%8C%E4%BD%86%E5%AF%A6%E9%9A%9B%E4%B8%8A%E6%89%80%E6%9C%89%E5%85%B6%E4%BB%96%E7%9A%84%E4%BA%BA%E4%B9%9F%E4%B8%80%E6%A8%A3%E3%80%82)
^zh-Q0394-answer

**zh-Q0395** — 今天沒有像昨天那麼冷。

It isn't anything like as cold as it was yesterday.

Why: Demonstratives. [[Mandarin Chinese#^zh-Q0395|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%8A%E5%A4%A9%E6%B2%92%E6%9C%89%E5%83%8F%E6%98%A8%E5%A4%A9%E9%82%A3%E9%BA%BC%E5%86%B7%E3%80%82)
^zh-Q0395-answer

**zh-Q0396** — 今天沒有像昨天那麼冷。

It isn't anything like as cold as it was yesterday.

Demonstratives distinguish near/far or discourse reference. Counted noun phrases usually include the appropriate classifier. 这/那 also occur in other constructions, so determine whether a noun phrase follows.

Why: Demonstratives. [[Mandarin Chinese#^zh-Q0396|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%8A%E5%A4%A9%E6%B2%92%E6%9C%89%E5%83%8F%E6%98%A8%E5%A4%A9%E9%82%A3%E9%BA%BC%E5%86%B7%E3%80%82)
^zh-Q0396-answer

**zh-Q0397** — 这部电影很无聊，最好的部分是结局。

This film is really boring - the best bit is when it finishes.

Expected form: **这**

Why: Demonstratives. [[Mandarin Chinese#^zh-Q0397|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%BF%99%E9%83%A8%E7%94%B5%E5%BD%B1%E5%BE%88%E6%97%A0%E8%81%8A%EF%BC%8C%E6%9C%80%E5%A5%BD%E7%9A%84%E9%83%A8%E5%88%86%E6%98%AF%E7%BB%93%E5%B1%80%E3%80%82)
^zh-Q0397-answer

**zh-Q0398** — 这部电影很无聊，最好的部分是结局。

This film is really boring - the best bit is when it finishes.

Expected form: **这**

Why: Demonstratives. [[Mandarin Chinese#^zh-Q0398|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%BF%99%E9%83%A8%E7%94%B5%E5%BD%B1%E5%BE%88%E6%97%A0%E8%81%8A%EF%BC%8C%E6%9C%80%E5%A5%BD%E7%9A%84%E9%83%A8%E5%88%86%E6%98%AF%E7%BB%93%E5%B1%80%E3%80%82)
^zh-Q0398-answer

**zh-Q0399** — 那個節目現在正在播出。

That program is now being broadcast.

Expected form: **那**

Why: Demonstratives. [[Mandarin Chinese#^zh-Q0399|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E9%82%A3%E5%80%8B%E7%AF%80%E7%9B%AE%E7%8F%BE%E5%9C%A8%E6%AD%A3%E5%9C%A8%E6%92%AD%E5%87%BA%E3%80%82)
^zh-Q0399-answer

**zh-Q0400** — 那個節目現在正在播出。

That program is now being broadcast.

Why: Demonstratives. [[Mandarin Chinese#^zh-Q0400|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E9%82%A3%E5%80%8B%E7%AF%80%E7%9B%AE%E7%8F%BE%E5%9C%A8%E6%AD%A3%E5%9C%A8%E6%92%AD%E5%87%BA%E3%80%82)
^zh-Q0400-answer


### Answers 401–450

**zh-Q0401** — 今天出现了很多问题。

Today, many problems were encountered.

Why: Completion and change 了. [[Mandarin Chinese#^zh-Q0401|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%8A%E5%A4%A9%E5%87%BA%E7%8E%B0%E4%BA%86%E5%BE%88%E5%A4%9A%E9%97%AE%E9%A2%98%E3%80%82)
^zh-Q0401-answer

**zh-Q0402** — 今天出现了很多问题。

Today, many problems were encountered.

了 can mark a completed/bounded event or a change of situation. Its position and surrounding structure matter. It is not a universal past-tense ending and can occur in future contexts.

Why: Completion and change 了. [[Mandarin Chinese#^zh-Q0402|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%8A%E5%A4%A9%E5%87%BA%E7%8E%B0%E4%BA%86%E5%BE%88%E5%A4%9A%E9%97%AE%E9%A2%98%E3%80%82)
^zh-Q0402-answer

**zh-Q0403** — 我给了汤姆其中之一。

I gave Tom one of those.

Expected form: **了**

Why: Completion and change 了. [[Mandarin Chinese#^zh-Q0403|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E7%BB%99%E4%BA%86%E6%B1%A4%E5%A7%86%E5%85%B6%E4%B8%AD%E4%B9%8B%E4%B8%80%E3%80%82)
^zh-Q0403-answer

**zh-Q0404** — 我给了汤姆其中之一。

I gave Tom one of those.

Expected form: **了**

Why: Completion and change 了. [[Mandarin Chinese#^zh-Q0404|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E7%BB%99%E4%BA%86%E6%B1%A4%E5%A7%86%E5%85%B6%E4%B8%AD%E4%B9%8B%E4%B8%80%E3%80%82)
^zh-Q0404-answer

**zh-Q0405** — 我找工作已经很久了。

I've been looking for a new job for a long time.

Expected form: **了**

Why: Completion and change 了. [[Mandarin Chinese#^zh-Q0405|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E6%89%BE%E5%B7%A5%E4%BD%9C%E5%B7%B2%E7%BB%8F%E5%BE%88%E4%B9%85%E4%BA%86%E3%80%82)
^zh-Q0405-answer

**zh-Q0406** — 我找工作已经很久了。

I've been looking for a new job for a long time.

Why: Completion and change 了. [[Mandarin Chinese#^zh-Q0406|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E6%89%BE%E5%B7%A5%E4%BD%9C%E5%B7%B2%E7%BB%8F%E5%BE%88%E4%B9%85%E4%BA%86%E3%80%82)
^zh-Q0406-answer

**zh-Q0407** — 一個小時前雪停了。

It stopped snowing an hour ago.

Why: Completion and change 了. [[Mandarin Chinese#^zh-Q0407|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%B8%80%E5%80%8B%E5%B0%8F%E6%99%82%E5%89%8D%E9%9B%AA%E5%81%9C%E4%BA%86%E3%80%82)
^zh-Q0407-answer

**zh-Q0408** — 一個小時前雪停了。

It stopped snowing an hour ago.

了 can mark a completed/bounded event or a change of situation. Its position and surrounding structure matter. It is not a universal past-tense ending and can occur in future contexts.

Why: Completion and change 了. [[Mandarin Chinese#^zh-Q0408|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%B8%80%E5%80%8B%E5%B0%8F%E6%99%82%E5%89%8D%E9%9B%AA%E5%81%9C%E4%BA%86%E3%80%82)
^zh-Q0408-answer

**zh-Q0409** — 昨天發生了一場車禍。

There was a car accident yesterday.

Expected form: **了**

Why: Completion and change 了. [[Mandarin Chinese#^zh-Q0409|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%98%A8%E5%A4%A9%E7%99%BC%E7%94%9F%E4%BA%86%E4%B8%80%E5%A0%B4%E8%BB%8A%E7%A6%8D%E3%80%82)
^zh-Q0409-answer

**zh-Q0410** — 昨天發生了一場車禍。

There was a car accident yesterday.

Expected form: **了**

Why: Completion and change 了. [[Mandarin Chinese#^zh-Q0410|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%98%A8%E5%A4%A9%E7%99%BC%E7%94%9F%E4%BA%86%E4%B8%80%E5%A0%B4%E8%BB%8A%E7%A6%8D%E3%80%82)
^zh-Q0410-answer

**zh-Q0411** — 她十八岁就大学毕业了。

She was only 18 when she graduated from university.

Expected form: **了**

Why: Completion and change 了. [[Mandarin Chinese#^zh-Q0411|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A5%B9%E5%8D%81%E5%85%AB%E5%B2%81%E5%B0%B1%E5%A4%A7%E5%AD%A6%E6%AF%95%E4%B8%9A%E4%BA%86%E3%80%82)
^zh-Q0411-answer

**zh-Q0412** — 她十八岁就大学毕业了。

She was only 18 when she graduated from university.

Why: Completion and change 了. [[Mandarin Chinese#^zh-Q0412|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A5%B9%E5%8D%81%E5%85%AB%E5%B2%81%E5%B0%B1%E5%A4%A7%E5%AD%A6%E6%AF%95%E4%B8%9A%E4%BA%86%E3%80%82)
^zh-Q0412-answer

**zh-Q0413** — 汤姆和玛丽猎鹿去了。

Tom and Mary went deer hunting.

Why: Completion and change 了. [[Mandarin Chinese#^zh-Q0413|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%B1%A4%E5%A7%86%E5%92%8C%E7%8E%9B%E4%B8%BD%E7%8C%8E%E9%B9%BF%E5%8E%BB%E4%BA%86%E3%80%82)
^zh-Q0413-answer

**zh-Q0414** — 汤姆和玛丽猎鹿去了。

Tom and Mary went deer hunting.

了 can mark a completed/bounded event or a change of situation. Its position and surrounding structure matter. It is not a universal past-tense ending and can occur in future contexts.

Why: Completion and change 了. [[Mandarin Chinese#^zh-Q0414|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%B1%A4%E5%A7%86%E5%92%8C%E7%8E%9B%E4%B8%BD%E7%8C%8E%E9%B9%BF%E5%8E%BB%E4%BA%86%E3%80%82)
^zh-Q0414-answer

**zh-Q0415** — 我走之后他到达了。

He arrived after I had left.

Expected form: **了**

Why: Completion and change 了. [[Mandarin Chinese#^zh-Q0415|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E8%B5%B0%E4%B9%8B%E5%90%8E%E4%BB%96%E5%88%B0%E8%BE%BE%E4%BA%86%E3%80%82)
^zh-Q0415-answer

**zh-Q0416** — 我走之后他到达了。

He arrived after I had left.

Expected form: **了**

Why: Completion and change 了. [[Mandarin Chinese#^zh-Q0416|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E8%B5%B0%E4%B9%8B%E5%90%8E%E4%BB%96%E5%88%B0%E8%BE%BE%E4%BA%86%E3%80%82)
^zh-Q0416-answer

**zh-Q0417** — 她和她父亲的争吵爆发了。

An argument erupted between her and her father.

Expected form: **了**

Why: Completion and change 了. [[Mandarin Chinese#^zh-Q0417|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A5%B9%E5%92%8C%E5%A5%B9%E7%88%B6%E4%BA%B2%E7%9A%84%E4%BA%89%E5%90%B5%E7%88%86%E5%8F%91%E4%BA%86%E3%80%82)
^zh-Q0417-answer

**zh-Q0418** — 她和她父亲的争吵爆发了。

An argument erupted between her and her father.

Why: Completion and change 了. [[Mandarin Chinese#^zh-Q0418|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A5%B9%E5%92%8C%E5%A5%B9%E7%88%B6%E4%BA%B2%E7%9A%84%E4%BA%89%E5%90%B5%E7%88%86%E5%8F%91%E4%BA%86%E3%80%82)
^zh-Q0418-answer

**zh-Q0419** — 英语变成了我最喜欢的学科。

English has become my favorite subject.

Why: Completion and change 了. [[Mandarin Chinese#^zh-Q0419|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%8B%B1%E8%AF%AD%E5%8F%98%E6%88%90%E4%BA%86%E6%88%91%E6%9C%80%E5%96%9C%E6%AC%A2%E7%9A%84%E5%AD%A6%E7%A7%91%E3%80%82)
^zh-Q0419-answer

**zh-Q0420** — 英语变成了我最喜欢的学科。

English has become my favorite subject.

了 can mark a completed/bounded event or a change of situation. Its position and surrounding structure matter. It is not a universal past-tense ending and can occur in future contexts.

Why: Completion and change 了. [[Mandarin Chinese#^zh-Q0420|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%8B%B1%E8%AF%AD%E5%8F%98%E6%88%90%E4%BA%86%E6%88%91%E6%9C%80%E5%96%9C%E6%AC%A2%E7%9A%84%E5%AD%A6%E7%A7%91%E3%80%82)
^zh-Q0420-answer

**zh-Q0421** — 搭帳篷花了我們半小時。

It took us half an hour to set up the tent.

Expected form: **了**

Why: Completion and change 了. [[Mandarin Chinese#^zh-Q0421|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%90%AD%E5%B8%B3%E7%AF%B7%E8%8A%B1%E4%BA%86%E6%88%91%E5%80%91%E5%8D%8A%E5%B0%8F%E6%99%82%E3%80%82)
^zh-Q0421-answer

**zh-Q0422** — 搭帳篷花了我們半小時。

It took us half an hour to set up the tent.

Expected form: **了**

Why: Completion and change 了. [[Mandarin Chinese#^zh-Q0422|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%90%AD%E5%B8%B3%E7%AF%B7%E8%8A%B1%E4%BA%86%E6%88%91%E5%80%91%E5%8D%8A%E5%B0%8F%E6%99%82%E3%80%82)
^zh-Q0422-answer

**zh-Q0423** — 我們都想知道她為什麼甩了這麼好的一個男人。

We all wondered why she had dumped such a nice man.

Expected form: **了**

Why: Completion and change 了. [[Mandarin Chinese#^zh-Q0423|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E5%80%91%E9%83%BD%E6%83%B3%E7%9F%A5%E9%81%93%E5%A5%B9%E7%82%BA%E4%BB%80%E9%BA%BC%E7%94%A9%E4%BA%86%E9%80%99%E9%BA%BC%E5%A5%BD%E7%9A%84%E4%B8%80%E5%80%8B%E7%94%B7%E4%BA%BA%E3%80%82)
^zh-Q0423-answer

**zh-Q0424** — 我們都想知道她為什麼甩了這麼好的一個男人。

We all wondered why she had dumped such a nice man.

Why: Completion and change 了. [[Mandarin Chinese#^zh-Q0424|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E5%80%91%E9%83%BD%E6%83%B3%E7%9F%A5%E9%81%93%E5%A5%B9%E7%82%BA%E4%BB%80%E9%BA%BC%E7%94%A9%E4%BA%86%E9%80%99%E9%BA%BC%E5%A5%BD%E7%9A%84%E4%B8%80%E5%80%8B%E7%94%B7%E4%BA%BA%E3%80%82)
^zh-Q0424-answer

**zh-Q0425** — 跨国公司预料到了规模经济的实行。

The multinational corporation has forecast the implementation of economies of scale.

Why: Completion and change 了. [[Mandarin Chinese#^zh-Q0425|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%B7%A8%E5%9B%BD%E5%85%AC%E5%8F%B8%E9%A2%84%E6%96%99%E5%88%B0%E4%BA%86%E8%A7%84%E6%A8%A1%E7%BB%8F%E6%B5%8E%E7%9A%84%E5%AE%9E%E8%A1%8C%E3%80%82)
^zh-Q0425-answer

**zh-Q0426** — 跨国公司预料到了规模经济的实行。

The multinational corporation has forecast the implementation of economies of scale.

了 can mark a completed/bounded event or a change of situation. Its position and surrounding structure matter. It is not a universal past-tense ending and can occur in future contexts.

Why: Completion and change 了. [[Mandarin Chinese#^zh-Q0426|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%B7%A8%E5%9B%BD%E5%85%AC%E5%8F%B8%E9%A2%84%E6%96%99%E5%88%B0%E4%BA%86%E8%A7%84%E6%A8%A1%E7%BB%8F%E6%B5%8E%E7%9A%84%E5%AE%9E%E8%A1%8C%E3%80%82)
^zh-Q0426-answer

**zh-Q0427** — 我又去爬了一次富士山。

I want to climb Mt. Fuji again.

Expected form: **了**

Why: Completion and change 了. [[Mandarin Chinese#^zh-Q0427|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E5%8F%88%E5%8E%BB%E7%88%AC%E4%BA%86%E4%B8%80%E6%AC%A1%E5%AF%8C%E5%A3%AB%E5%B1%B1%E3%80%82)
^zh-Q0427-answer

**zh-Q0428** — 我又去爬了一次富士山。

I want to climb Mt. Fuji again.

Expected form: **了**

Why: Completion and change 了. [[Mandarin Chinese#^zh-Q0428|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E5%8F%88%E5%8E%BB%E7%88%AC%E4%BA%86%E4%B8%80%E6%AC%A1%E5%AF%8C%E5%A3%AB%E5%B1%B1%E3%80%82)
^zh-Q0428-answer

**zh-Q0429** — Muiriel现在20岁了。

Muiriel is 20 now.

Expected form: **了**

Why: Completion and change 了. [[Mandarin Chinese#^zh-Q0429|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=Muiriel%E7%8E%B0%E5%9C%A820%E5%B2%81%E4%BA%86%E3%80%82)
^zh-Q0429-answer

**zh-Q0430** — Muiriel现在20岁了。

Muiriel is 20 now.

Why: Completion and change 了. [[Mandarin Chinese#^zh-Q0430|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=Muiriel%E7%8E%B0%E5%9C%A820%E5%B2%81%E4%BA%86%E3%80%82)
^zh-Q0430-answer

**zh-Q0431** — 谁去看了今天的葬礼？

Who saw the funeral today?

Why: Completion and change 了. [[Mandarin Chinese#^zh-Q0431|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%B0%81%E5%8E%BB%E7%9C%8B%E4%BA%86%E4%BB%8A%E5%A4%A9%E7%9A%84%E8%91%AC%E7%A4%BC%EF%BC%9F)
^zh-Q0431-answer

**zh-Q0432** — 谁去看了今天的葬礼？

Who saw the funeral today?

了 can mark a completed/bounded event or a change of situation. Its position and surrounding structure matter. It is not a universal past-tense ending and can occur in future contexts.

Why: Completion and change 了. [[Mandarin Chinese#^zh-Q0432|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%B0%81%E5%8E%BB%E7%9C%8B%E4%BA%86%E4%BB%8A%E5%A4%A9%E7%9A%84%E8%91%AC%E7%A4%BC%EF%BC%9F)
^zh-Q0432-answer

**zh-Q0433** — 房子被大火烧成了灰烬。

The fire reduced the house to ashes.

Expected form: **了**

Why: Completion and change 了. [[Mandarin Chinese#^zh-Q0433|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%BF%E5%AD%90%E8%A2%AB%E5%A4%A7%E7%81%AB%E7%83%A7%E6%88%90%E4%BA%86%E7%81%B0%E7%83%AC%E3%80%82)
^zh-Q0433-answer

**zh-Q0434** — 房子被大火烧成了灰烬。

The fire reduced the house to ashes.

Expected form: **了**

Why: Completion and change 了. [[Mandarin Chinese#^zh-Q0434|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%BF%E5%AD%90%E8%A2%AB%E5%A4%A7%E7%81%AB%E7%83%A7%E6%88%90%E4%BA%86%E7%81%B0%E7%83%AC%E3%80%82)
^zh-Q0434-answer

**zh-Q0435** — 鮑伯把這個壺裝滿了水。

Bob filled the pot with water.

Expected form: **了**

Why: Completion and change 了. [[Mandarin Chinese#^zh-Q0435|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E9%AE%91%E4%BC%AF%E6%8A%8A%E9%80%99%E5%80%8B%E5%A3%BA%E8%A3%9D%E6%BB%BF%E4%BA%86%E6%B0%B4%E3%80%82)
^zh-Q0435-answer

**zh-Q0436** — 鮑伯把這個壺裝滿了水。

Bob filled the pot with water.

Why: Completion and change 了. [[Mandarin Chinese#^zh-Q0436|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E9%AE%91%E4%BC%AF%E6%8A%8A%E9%80%99%E5%80%8B%E5%A3%BA%E8%A3%9D%E6%BB%BF%E4%BA%86%E6%B0%B4%E3%80%82)
^zh-Q0436-answer

**zh-Q0437** — 你出席了我的婚礼。

You were at my wedding.

Why: Completion and change 了. [[Mandarin Chinese#^zh-Q0437|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E5%87%BA%E5%B8%AD%E4%BA%86%E6%88%91%E7%9A%84%E5%A9%9A%E7%A4%BC%E3%80%82)
^zh-Q0437-answer

**zh-Q0438** — 你出席了我的婚礼。

You were at my wedding.

了 can mark a completed/bounded event or a change of situation. Its position and surrounding structure matter. It is not a universal past-tense ending and can occur in future contexts.

Why: Completion and change 了. [[Mandarin Chinese#^zh-Q0438|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E5%87%BA%E5%B8%AD%E4%BA%86%E6%88%91%E7%9A%84%E5%A9%9A%E7%A4%BC%E3%80%82)
^zh-Q0438-answer

**zh-Q0439** — Jessie立刻接收了邀请。

Jessie accepted the invitation at once.

Expected form: **了**

Why: Completion and change 了. [[Mandarin Chinese#^zh-Q0439|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=Jessie%E7%AB%8B%E5%88%BB%E6%8E%A5%E6%94%B6%E4%BA%86%E9%82%80%E8%AF%B7%E3%80%82)
^zh-Q0439-answer

**zh-Q0440** — Jessie立刻接收了邀请。

Jessie accepted the invitation at once.

Expected form: **了**

Why: Completion and change 了. [[Mandarin Chinese#^zh-Q0440|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=Jessie%E7%AB%8B%E5%88%BB%E6%8E%A5%E6%94%B6%E4%BA%86%E9%82%80%E8%AF%B7%E3%80%82)
^zh-Q0440-answer

**zh-Q0441** — 她在大街上看见我的时候冲我笑了笑。

She smiled at me as she passed me in the street.

Expected form: **了**

Why: Completion and change 了. [[Mandarin Chinese#^zh-Q0441|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A5%B9%E5%9C%A8%E5%A4%A7%E8%A1%97%E4%B8%8A%E7%9C%8B%E8%A7%81%E6%88%91%E7%9A%84%E6%97%B6%E5%80%99%E5%86%B2%E6%88%91%E7%AC%91%E4%BA%86%E7%AC%91%E3%80%82)
^zh-Q0441-answer

**zh-Q0442** — 她在大街上看见我的时候冲我笑了笑。

She smiled at me as she passed me in the street.

Why: Completion and change 了. [[Mandarin Chinese#^zh-Q0442|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A5%B9%E5%9C%A8%E5%A4%A7%E8%A1%97%E4%B8%8A%E7%9C%8B%E8%A7%81%E6%88%91%E7%9A%84%E6%97%B6%E5%80%99%E5%86%B2%E6%88%91%E7%AC%91%E4%BA%86%E7%AC%91%E3%80%82)
^zh-Q0442-answer

**zh-Q0443** — 我昨天收到了你的信。

I received your letter yesterday.

Why: Completion and change 了. [[Mandarin Chinese#^zh-Q0443|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E6%98%A8%E5%A4%A9%E6%94%B6%E5%88%B0%E4%BA%86%E4%BD%A0%E7%9A%84%E4%BF%A1%E3%80%82)
^zh-Q0443-answer

**zh-Q0444** — 我昨天收到了你的信。

I received your letter yesterday.

了 can mark a completed/bounded event or a change of situation. Its position and surrounding structure matter. It is not a universal past-tense ending and can occur in future contexts.

Why: Completion and change 了. [[Mandarin Chinese#^zh-Q0444|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E6%98%A8%E5%A4%A9%E6%94%B6%E5%88%B0%E4%BA%86%E4%BD%A0%E7%9A%84%E4%BF%A1%E3%80%82)
^zh-Q0444-answer

**zh-Q0445** — 如果湯姆不能告訴我，就沒人能了。

If Tom can't tell me, then no one can.

Expected form: **了**

Why: Completion and change 了. [[Mandarin Chinese#^zh-Q0445|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A6%82%E6%9E%9C%E6%B9%AF%E5%A7%86%E4%B8%8D%E8%83%BD%E5%91%8A%E8%A8%B4%E6%88%91%EF%BC%8C%E5%B0%B1%E6%B2%92%E4%BA%BA%E8%83%BD%E4%BA%86%E3%80%82)
^zh-Q0445-answer

**zh-Q0446** — 如果湯姆不能告訴我，就沒人能了。

If Tom can't tell me, then no one can.

Expected form: **了**

Why: Completion and change 了. [[Mandarin Chinese#^zh-Q0446|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A6%82%E6%9E%9C%E6%B9%AF%E5%A7%86%E4%B8%8D%E8%83%BD%E5%91%8A%E8%A8%B4%E6%88%91%EF%BC%8C%E5%B0%B1%E6%B2%92%E4%BA%BA%E8%83%BD%E4%BA%86%E3%80%82)
^zh-Q0446-answer

**zh-Q0447** — 棒球比賽因為天雨取消了。

The baseball game was called off due to rain.

Expected form: **了**

Why: Completion and change 了. [[Mandarin Chinese#^zh-Q0447|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%A3%92%E7%90%83%E6%AF%94%E8%B3%BD%E5%9B%A0%E7%82%BA%E5%A4%A9%E9%9B%A8%E5%8F%96%E6%B6%88%E4%BA%86%E3%80%82)
^zh-Q0447-answer

**zh-Q0448** — 棒球比賽因為天雨取消了。

The baseball game was called off due to rain.

Why: Completion and change 了. [[Mandarin Chinese#^zh-Q0448|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%A3%92%E7%90%83%E6%AF%94%E8%B3%BD%E5%9B%A0%E7%82%BA%E5%A4%A9%E9%9B%A8%E5%8F%96%E6%B6%88%E4%BA%86%E3%80%82)
^zh-Q0448-answer

**zh-Q0449** — 农村好像要大规模发展了。

It seems the rural area will be developed on a large scale.

Why: Completion and change 了. [[Mandarin Chinese#^zh-Q0449|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%86%9C%E6%9D%91%E5%A5%BD%E5%83%8F%E8%A6%81%E5%A4%A7%E8%A7%84%E6%A8%A1%E5%8F%91%E5%B1%95%E4%BA%86%E3%80%82)
^zh-Q0449-answer

**zh-Q0450** — 农村好像要大规模发展了。

It seems the rural area will be developed on a large scale.

了 can mark a completed/bounded event or a change of situation. Its position and surrounding structure matter. It is not a universal past-tense ending and can occur in future contexts.

Why: Completion and change 了. [[Mandarin Chinese#^zh-Q0450|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%86%9C%E6%9D%91%E5%A5%BD%E5%83%8F%E8%A6%81%E5%A4%A7%E8%A7%84%E6%A8%A1%E5%8F%91%E5%B1%95%E4%BA%86%E3%80%82)
^zh-Q0450-answer


### Answers 451–500

**zh-Q0451** — 今晚我将在朋友家过夜。

I will put up at my friend's tonight.

Expected form: **过**

Why: Experience 过. [[Mandarin Chinese#^zh-Q0451|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%8A%E6%99%9A%E6%88%91%E5%B0%86%E5%9C%A8%E6%9C%8B%E5%8F%8B%E5%AE%B6%E8%BF%87%E5%A4%9C%E3%80%82)
^zh-Q0451-answer

**zh-Q0452** — 今晚我将在朋友家过夜。

I will put up at my friend's tonight.

Expected form: **过**

Why: Experience 过. [[Mandarin Chinese#^zh-Q0452|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%8A%E6%99%9A%E6%88%91%E5%B0%86%E5%9C%A8%E6%9C%8B%E5%8F%8B%E5%AE%B6%E8%BF%87%E5%A4%9C%E3%80%82)
^zh-Q0452-answer

**zh-Q0453** — 我有些年没见过他了。

I haven't seen him for years.

Expected form: **过**

Why: Experience 过. [[Mandarin Chinese#^zh-Q0453|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E6%9C%89%E4%BA%9B%E5%B9%B4%E6%B2%A1%E8%A7%81%E8%BF%87%E4%BB%96%E4%BA%86%E3%80%82)
^zh-Q0453-answer

**zh-Q0454** — 我有些年没见过他了。

I haven't seen him for years.

Why: Experience 过. [[Mandarin Chinese#^zh-Q0454|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E6%9C%89%E4%BA%9B%E5%B9%B4%E6%B2%A1%E8%A7%81%E8%BF%87%E4%BB%96%E4%BA%86%E3%80%82)
^zh-Q0454-answer

**zh-Q0455** — 你什么时候告诉过我？

When did you tell me?

Why: Experience 过. [[Mandarin Chinese#^zh-Q0455|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E4%BB%80%E4%B9%88%E6%97%B6%E5%80%99%E5%91%8A%E8%AF%89%E8%BF%87%E6%88%91%EF%BC%9F)
^zh-Q0455-answer

**zh-Q0456** — 你什么时候告诉过我？

When did you tell me?

Aspectual 过 indicates prior experience in suitable verb constructions. The same character can have lexical or complement uses. Negated experience commonly uses 没 ... 过.

Why: Experience 过. [[Mandarin Chinese#^zh-Q0456|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E4%BB%80%E4%B9%88%E6%97%B6%E5%80%99%E5%91%8A%E8%AF%89%E8%BF%87%E6%88%91%EF%BC%9F)
^zh-Q0456-answer

**zh-Q0457** — 我以一分之差错过了那趟火车。

I missed the train by a hair's breadth.

Expected form: **过**

Why: Experience 过. [[Mandarin Chinese#^zh-Q0457|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E4%BB%A5%E4%B8%80%E5%88%86%E4%B9%8B%E5%B7%AE%E9%94%99%E8%BF%87%E4%BA%86%E9%82%A3%E8%B6%9F%E7%81%AB%E8%BD%A6%E3%80%82)
^zh-Q0457-answer

**zh-Q0458** — 我以一分之差错过了那趟火车。

I missed the train by a hair's breadth.

Expected form: **过**

Why: Experience 过. [[Mandarin Chinese#^zh-Q0458|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E4%BB%A5%E4%B8%80%E5%88%86%E4%B9%8B%E5%B7%AE%E9%94%99%E8%BF%87%E4%BA%86%E9%82%A3%E8%B6%9F%E7%81%AB%E8%BD%A6%E3%80%82)
^zh-Q0458-answer

**zh-Q0459** — 我父母那一代经历过战争。

My parents' generation went through the war.

Expected form: **过**

Why: Experience 过. [[Mandarin Chinese#^zh-Q0459|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E7%88%B6%E6%AF%8D%E9%82%A3%E4%B8%80%E4%BB%A3%E7%BB%8F%E5%8E%86%E8%BF%87%E6%88%98%E4%BA%89%E3%80%82)
^zh-Q0459-answer

**zh-Q0460** — 我父母那一代经历过战争。

My parents' generation went through the war.

Why: Experience 过. [[Mandarin Chinese#^zh-Q0460|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E7%88%B6%E6%AF%8D%E9%82%A3%E4%B8%80%E4%BB%A3%E7%BB%8F%E5%8E%86%E8%BF%87%E6%88%98%E4%BA%89%E3%80%82)
^zh-Q0460-answer

**zh-Q0461** — 你听过这首曲子吗？

Have you listened to this song?

Why: Experience 过. [[Mandarin Chinese#^zh-Q0461|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E5%90%AC%E8%BF%87%E8%BF%99%E9%A6%96%E6%9B%B2%E5%AD%90%E5%90%97%EF%BC%9F)
^zh-Q0461-answer

**zh-Q0462** — 你听过这首曲子吗？

Have you listened to this song?

Aspectual 过 indicates prior experience in suitable verb constructions. The same character can have lexical or complement uses. Negated experience commonly uses 没 ... 过.

Why: Experience 过. [[Mandarin Chinese#^zh-Q0462|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E5%90%AC%E8%BF%87%E8%BF%99%E9%A6%96%E6%9B%B2%E5%AD%90%E5%90%97%EF%BC%9F)
^zh-Q0462-answer

**zh-Q0463** — 汤姆死于服药过量。

Tom died of a drug overdose.

Expected form: **过**

Why: Experience 过. [[Mandarin Chinese#^zh-Q0463|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%B1%A4%E5%A7%86%E6%AD%BB%E4%BA%8E%E6%9C%8D%E8%8D%AF%E8%BF%87%E9%87%8F%E3%80%82)
^zh-Q0463-answer

**zh-Q0464** — 汤姆死于服药过量。

Tom died of a drug overdose.

Expected form: **过**

Why: Experience 过. [[Mandarin Chinese#^zh-Q0464|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%B1%A4%E5%A7%86%E6%AD%BB%E4%BA%8E%E6%9C%8D%E8%8D%AF%E8%BF%87%E9%87%8F%E3%80%82)
^zh-Q0464-answer

**zh-Q0465** — 我在派对上度过了一段快乐的时光。

I had a good time at the party.

Expected form: **过**

Why: Experience 过. [[Mandarin Chinese#^zh-Q0465|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E5%9C%A8%E6%B4%BE%E5%AF%B9%E4%B8%8A%E5%BA%A6%E8%BF%87%E4%BA%86%E4%B8%80%E6%AE%B5%E5%BF%AB%E4%B9%90%E7%9A%84%E6%97%B6%E5%85%89%E3%80%82)
^zh-Q0465-answer

**zh-Q0466** — 我在派对上度过了一段快乐的时光。

I had a good time at the party.

Why: Experience 过. [[Mandarin Chinese#^zh-Q0466|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E5%9C%A8%E6%B4%BE%E5%AF%B9%E4%B8%8A%E5%BA%A6%E8%BF%87%E4%BA%86%E4%B8%80%E6%AE%B5%E5%BF%AB%E4%B9%90%E7%9A%84%E6%97%B6%E5%85%89%E3%80%82)
^zh-Q0466-answer

**zh-Q0467** — 她可能在法国留过学，因为她说法语很流畅。

She probably studied in France, as she speaks French fluently.

Why: Experience 过. [[Mandarin Chinese#^zh-Q0467|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A5%B9%E5%8F%AF%E8%83%BD%E5%9C%A8%E6%B3%95%E5%9B%BD%E7%95%99%E8%BF%87%E5%AD%A6%EF%BC%8C%E5%9B%A0%E4%B8%BA%E5%A5%B9%E8%AF%B4%E6%B3%95%E8%AF%AD%E5%BE%88%E6%B5%81%E7%95%85%E3%80%82)
^zh-Q0467-answer

**zh-Q0468** — 她可能在法国留过学，因为她说法语很流畅。

She probably studied in France, as she speaks French fluently.

Aspectual 过 indicates prior experience in suitable verb constructions. The same character can have lexical or complement uses. Negated experience commonly uses 没 ... 过.

Why: Experience 过. [[Mandarin Chinese#^zh-Q0468|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A5%B9%E5%8F%AF%E8%83%BD%E5%9C%A8%E6%B3%95%E5%9B%BD%E7%95%99%E8%BF%87%E5%AD%A6%EF%BC%8C%E5%9B%A0%E4%B8%BA%E5%A5%B9%E8%AF%B4%E6%B3%95%E8%AF%AD%E5%BE%88%E6%B5%81%E7%95%85%E3%80%82)
^zh-Q0468-answer

**zh-Q0469** — 一条狗被卡车碾过。

A dog was run over by a truck.

Expected form: **过**

Why: Experience 过. [[Mandarin Chinese#^zh-Q0469|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%B8%80%E6%9D%A1%E7%8B%97%E8%A2%AB%E5%8D%A1%E8%BD%A6%E7%A2%BE%E8%BF%87%E3%80%82)
^zh-Q0469-answer

**zh-Q0470** — 一条狗被卡车碾过。

A dog was run over by a truck.

Expected form: **过**

Why: Experience 过. [[Mandarin Chinese#^zh-Q0470|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%B8%80%E6%9D%A1%E7%8B%97%E8%A2%AB%E5%8D%A1%E8%BD%A6%E7%A2%BE%E8%BF%87%E3%80%82)
^zh-Q0470-answer

**zh-Q0471** — 如果你没有尝试过失败的角色，那么人们也就不会相信你。

If you have no character to lose, people will have no faith in you.

Expected form: **过**

Why: Experience 过. [[Mandarin Chinese#^zh-Q0471|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A6%82%E6%9E%9C%E4%BD%A0%E6%B2%A1%E6%9C%89%E5%B0%9D%E8%AF%95%E8%BF%87%E5%A4%B1%E8%B4%A5%E7%9A%84%E8%A7%92%E8%89%B2%EF%BC%8C%E9%82%A3%E4%B9%88%E4%BA%BA%E4%BB%AC%E4%B9%9F%E5%B0%B1%E4%B8%8D%E4%BC%9A%E7%9B%B8%E4%BF%A1%E4%BD%A0%E3%80%82)
^zh-Q0471-answer

**zh-Q0472** — 如果你没有尝试过失败的角色，那么人们也就不会相信你。

If you have no character to lose, people will have no faith in you.

Why: Experience 过. [[Mandarin Chinese#^zh-Q0472|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A6%82%E6%9E%9C%E4%BD%A0%E6%B2%A1%E6%9C%89%E5%B0%9D%E8%AF%95%E8%BF%87%E5%A4%B1%E8%B4%A5%E7%9A%84%E8%A7%92%E8%89%B2%EF%BC%8C%E9%82%A3%E4%B9%88%E4%BA%BA%E4%BB%AC%E4%B9%9F%E5%B0%B1%E4%B8%8D%E4%BC%9A%E7%9B%B8%E4%BF%A1%E4%BD%A0%E3%80%82)
^zh-Q0472-answer

**zh-Q0473** — 祝你一天过得愉快。

Have a nice day.

Why: Experience 过. [[Mandarin Chinese#^zh-Q0473|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E7%A5%9D%E4%BD%A0%E4%B8%80%E5%A4%A9%E8%BF%87%E5%BE%97%E6%84%89%E5%BF%AB%E3%80%82)
^zh-Q0473-answer

**zh-Q0474** — 祝你一天过得愉快。

Have a nice day.

Aspectual 过 indicates prior experience in suitable verb constructions. The same character can have lexical or complement uses. Negated experience commonly uses 没 ... 过.

Why: Experience 过. [[Mandarin Chinese#^zh-Q0474|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E7%A5%9D%E4%BD%A0%E4%B8%80%E5%A4%A9%E8%BF%87%E5%BE%97%E6%84%89%E5%BF%AB%E3%80%82)
^zh-Q0474-answer

**zh-Q0475** — 我现在还没有吃过午饭。

I haven't eaten lunch yet.

Expected form: **过**

Why: Experience 过. [[Mandarin Chinese#^zh-Q0475|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E7%8E%B0%E5%9C%A8%E8%BF%98%E6%B2%A1%E6%9C%89%E5%90%83%E8%BF%87%E5%8D%88%E9%A5%AD%E3%80%82)
^zh-Q0475-answer

**zh-Q0476** — 我现在还没有吃过午饭。

I haven't eaten lunch yet.

Expected form: **过**

Why: Experience 过. [[Mandarin Chinese#^zh-Q0476|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E7%8E%B0%E5%9C%A8%E8%BF%98%E6%B2%A1%E6%9C%89%E5%90%83%E8%BF%87%E5%8D%88%E9%A5%AD%E3%80%82)
^zh-Q0476-answer

**zh-Q0477** — 他保证过会来却没有来。

He promised to come, but he didn't come.

Expected form: **过**

Why: Experience 过. [[Mandarin Chinese#^zh-Q0477|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%96%E4%BF%9D%E8%AF%81%E8%BF%87%E4%BC%9A%E6%9D%A5%E5%8D%B4%E6%B2%A1%E6%9C%89%E6%9D%A5%E3%80%82)
^zh-Q0477-answer

**zh-Q0478** — 他保证过会来却没有来。

He promised to come, but he didn't come.

Why: Experience 过. [[Mandarin Chinese#^zh-Q0478|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%96%E4%BF%9D%E8%AF%81%E8%BF%87%E4%BC%9A%E6%9D%A5%E5%8D%B4%E6%B2%A1%E6%9C%89%E6%9D%A5%E3%80%82)
^zh-Q0478-answer

**zh-Q0479** — 顺便问一句，你们已经去过北海道了吗？

By the way, have you ever been to Hokkaido?

Why: Experience 过. [[Mandarin Chinese#^zh-Q0479|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E9%A1%BA%E4%BE%BF%E9%97%AE%E4%B8%80%E5%8F%A5%EF%BC%8C%E4%BD%A0%E4%BB%AC%E5%B7%B2%E7%BB%8F%E5%8E%BB%E8%BF%87%E5%8C%97%E6%B5%B7%E9%81%93%E4%BA%86%E5%90%97%EF%BC%9F)
^zh-Q0479-answer

**zh-Q0480** — 顺便问一句，你们已经去过北海道了吗？

By the way, have you ever been to Hokkaido?

Aspectual 过 indicates prior experience in suitable verb constructions. The same character can have lexical or complement uses. Negated experience commonly uses 没 ... 过.

Why: Experience 过. [[Mandarin Chinese#^zh-Q0480|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E9%A1%BA%E4%BE%BF%E9%97%AE%E4%B8%80%E5%8F%A5%EF%BC%8C%E4%BD%A0%E4%BB%AC%E5%B7%B2%E7%BB%8F%E5%8E%BB%E8%BF%87%E5%8C%97%E6%B5%B7%E9%81%93%E4%BA%86%E5%90%97%EF%BC%9F)
^zh-Q0480-answer

**zh-Q0481** — 汤姆试过还回泳衣来换成更大一号的，但是员工告诉他那是不被允许的。

Tom tried to return the swimsuit for a larger size, but the clerk told him that wasn't allowed.

Expected form: **过**

Why: Experience 过. [[Mandarin Chinese#^zh-Q0481|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%B1%A4%E5%A7%86%E8%AF%95%E8%BF%87%E8%BF%98%E5%9B%9E%E6%B3%B3%E8%A1%A3%E6%9D%A5%E6%8D%A2%E6%88%90%E6%9B%B4%E5%A4%A7%E4%B8%80%E5%8F%B7%E7%9A%84%EF%BC%8C%E4%BD%86%E6%98%AF%E5%91%98%E5%B7%A5%E5%91%8A%E8%AF%89%E4%BB%96%E9%82%A3%E6%98%AF%E4%B8%8D%E8%A2%AB%E5%85%81%E8%AE%B8%E7%9A%84%E3%80%82)
^zh-Q0481-answer

**zh-Q0482** — 汤姆试过还回泳衣来换成更大一号的，但是员工告诉他那是不被允许的。

Tom tried to return the swimsuit for a larger size, but the clerk told him that wasn't allowed.

Expected form: **过**

Why: Experience 过. [[Mandarin Chinese#^zh-Q0482|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%B1%A4%E5%A7%86%E8%AF%95%E8%BF%87%E8%BF%98%E5%9B%9E%E6%B3%B3%E8%A1%A3%E6%9D%A5%E6%8D%A2%E6%88%90%E6%9B%B4%E5%A4%A7%E4%B8%80%E5%8F%B7%E7%9A%84%EF%BC%8C%E4%BD%86%E6%98%AF%E5%91%98%E5%B7%A5%E5%91%8A%E8%AF%89%E4%BB%96%E9%82%A3%E6%98%AF%E4%B8%8D%E8%A2%AB%E5%85%81%E8%AE%B8%E7%9A%84%E3%80%82)
^zh-Q0482-answer

**zh-Q0483** — Yanni没看过这部电影。

Yanni hasn't seen this movie.

Expected form: **过**

Why: Experience 过. [[Mandarin Chinese#^zh-Q0483|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=Yanni%E6%B2%A1%E7%9C%8B%E8%BF%87%E8%BF%99%E9%83%A8%E7%94%B5%E5%BD%B1%E3%80%82)
^zh-Q0483-answer

**zh-Q0484** — Yanni没看过这部电影。

Yanni hasn't seen this movie.

Why: Experience 过. [[Mandarin Chinese#^zh-Q0484|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=Yanni%E6%B2%A1%E7%9C%8B%E8%BF%87%E8%BF%99%E9%83%A8%E7%94%B5%E5%BD%B1%E3%80%82)
^zh-Q0484-answer

**zh-Q0485** — 你听过别人说世界语吗？

Have you ever heard someone speaking Esperanto?

Why: Experience 过. [[Mandarin Chinese#^zh-Q0485|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E5%90%AC%E8%BF%87%E5%88%AB%E4%BA%BA%E8%AF%B4%E4%B8%96%E7%95%8C%E8%AF%AD%E5%90%97%EF%BC%9F)
^zh-Q0485-answer

**zh-Q0486** — 你听过别人说世界语吗？

Have you ever heard someone speaking Esperanto?

Aspectual 过 indicates prior experience in suitable verb constructions. The same character can have lexical or complement uses. Negated experience commonly uses 没 ... 过.

Why: Experience 过. [[Mandarin Chinese#^zh-Q0486|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E5%90%AC%E8%BF%87%E5%88%AB%E4%BA%BA%E8%AF%B4%E4%B8%96%E7%95%8C%E8%AF%AD%E5%90%97%EF%BC%9F)
^zh-Q0486-answer

**zh-Q0487** — 之后我再也没跟他说过话。

I never spoke to him after that.

Expected form: **过**

Why: Experience 过. [[Mandarin Chinese#^zh-Q0487|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%B9%8B%E5%90%8E%E6%88%91%E5%86%8D%E4%B9%9F%E6%B2%A1%E8%B7%9F%E4%BB%96%E8%AF%B4%E8%BF%87%E8%AF%9D%E3%80%82)
^zh-Q0487-answer

**zh-Q0488** — 之后我再也没跟他说过话。

I never spoke to him after that.

Expected form: **过**

Why: Experience 过. [[Mandarin Chinese#^zh-Q0488|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%B9%8B%E5%90%8E%E6%88%91%E5%86%8D%E4%B9%9F%E6%B2%A1%E8%B7%9F%E4%BB%96%E8%AF%B4%E8%BF%87%E8%AF%9D%E3%80%82)
^zh-Q0488-answer

**zh-Q0489** — 我不想过这样的生活。

I don't want to live like this.

Expected form: **过**

Why: Experience 过. [[Mandarin Chinese#^zh-Q0489|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E4%B8%8D%E6%83%B3%E8%BF%87%E8%BF%99%E6%A0%B7%E7%9A%84%E7%94%9F%E6%B4%BB%E3%80%82)
^zh-Q0489-answer

**zh-Q0490** — 我不想过这样的生活。

I don't want to live like this.

Why: Experience 过. [[Mandarin Chinese#^zh-Q0490|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E4%B8%8D%E6%83%B3%E8%BF%87%E8%BF%99%E6%A0%B7%E7%9A%84%E7%94%9F%E6%B4%BB%E3%80%82)
^zh-Q0490-answer

**zh-Q0491** — 我从没玩过高尔夫。

I never played golf.

Why: Experience 过. [[Mandarin Chinese#^zh-Q0491|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E4%BB%8E%E6%B2%A1%E7%8E%A9%E8%BF%87%E9%AB%98%E5%B0%94%E5%A4%AB%E3%80%82)
^zh-Q0491-answer

**zh-Q0492** — 我从没玩过高尔夫。

I never played golf.

Aspectual 过 indicates prior experience in suitable verb constructions. The same character can have lexical or complement uses. Negated experience commonly uses 没 ... 过.

Why: Experience 过. [[Mandarin Chinese#^zh-Q0492|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E4%BB%8E%E6%B2%A1%E7%8E%A9%E8%BF%87%E9%AB%98%E5%B0%94%E5%A4%AB%E3%80%82)
^zh-Q0492-answer

**zh-Q0493** — 他还没有去过法国,他很想明年去.

He still hasn't been to France; he really wants to go next year.

Expected form: **过**

Why: Experience 过. [[Mandarin Chinese#^zh-Q0493|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%96%E8%BF%98%E6%B2%A1%E6%9C%89%E5%8E%BB%E8%BF%87%E6%B3%95%E5%9B%BD%2C%E4%BB%96%E5%BE%88%E6%83%B3%E6%98%8E%E5%B9%B4%E5%8E%BB.)
^zh-Q0493-answer

**zh-Q0494** — 他还没有去过法国,他很想明年去.

He still hasn't been to France; he really wants to go next year.

Expected form: **过**

Why: Experience 过. [[Mandarin Chinese#^zh-Q0494|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%96%E8%BF%98%E6%B2%A1%E6%9C%89%E5%8E%BB%E8%BF%87%E6%B3%95%E5%9B%BD%2C%E4%BB%96%E5%BE%88%E6%83%B3%E6%98%8E%E5%B9%B4%E5%8E%BB.)
^zh-Q0494-answer

**zh-Q0495** — 我看孩子们过了马路。

I saw the children walk across the street.

Expected form: **过**

Why: Experience 过. [[Mandarin Chinese#^zh-Q0495|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E7%9C%8B%E5%AD%A9%E5%AD%90%E4%BB%AC%E8%BF%87%E4%BA%86%E9%A9%AC%E8%B7%AF%E3%80%82)
^zh-Q0495-answer

**zh-Q0496** — 我看孩子们过了马路。

I saw the children walk across the street.

Why: Experience 过. [[Mandarin Chinese#^zh-Q0496|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E7%9C%8B%E5%AD%A9%E5%AD%90%E4%BB%AC%E8%BF%87%E4%BA%86%E9%A9%AC%E8%B7%AF%E3%80%82)
^zh-Q0496-answer

**zh-Q0497** — 我们在我的叔叔家过夜。

We are spending the night at my uncle's house.

Why: Experience 过. [[Mandarin Chinese#^zh-Q0497|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E4%BB%AC%E5%9C%A8%E6%88%91%E7%9A%84%E5%8F%94%E5%8F%94%E5%AE%B6%E8%BF%87%E5%A4%9C%E3%80%82)
^zh-Q0497-answer

**zh-Q0498** — 我们在我的叔叔家过夜。

We are spending the night at my uncle's house.

Aspectual 过 indicates prior experience in suitable verb constructions. The same character can have lexical or complement uses. Negated experience commonly uses 没 ... 过.

Why: Experience 过. [[Mandarin Chinese#^zh-Q0498|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E4%BB%AC%E5%9C%A8%E6%88%91%E7%9A%84%E5%8F%94%E5%8F%94%E5%AE%B6%E8%BF%87%E5%A4%9C%E3%80%82)
^zh-Q0498-answer

**zh-Q0499** — 我想呆在家多过钓鱼。

I prefer staying at home to going fishing.

Expected form: **过**

Why: Experience 过. [[Mandarin Chinese#^zh-Q0499|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E6%83%B3%E5%91%86%E5%9C%A8%E5%AE%B6%E5%A4%9A%E8%BF%87%E9%92%93%E9%B1%BC%E3%80%82)
^zh-Q0499-answer

**zh-Q0500** — 我想呆在家多过钓鱼。

I prefer staying at home to going fishing.

Expected form: **过**

Why: Experience 过. [[Mandarin Chinese#^zh-Q0500|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E6%83%B3%E5%91%86%E5%9C%A8%E5%AE%B6%E5%A4%9A%E8%BF%87%E9%92%93%E9%B1%BC%E3%80%82)
^zh-Q0500-answer


### Answers 501–550

**zh-Q0501** — 水面浮着一片落葉。

A fallen leaf floated on the surface of the water.

Expected form: **着**

Why: State 着. [[Mandarin Chinese#^zh-Q0501|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%B0%B4%E9%9D%A2%E6%B5%AE%E7%9D%80%E4%B8%80%E7%89%87%E8%90%BD%E8%91%89%E3%80%82)
^zh-Q0501-answer

**zh-Q0502** — 水面浮着一片落葉。

A fallen leaf floated on the surface of the water.

Why: State 着. [[Mandarin Chinese#^zh-Q0502|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%B0%B4%E9%9D%A2%E6%B5%AE%E7%9D%80%E4%B8%80%E7%89%87%E8%90%BD%E8%91%89%E3%80%82)
^zh-Q0502-answer

**zh-Q0503** — 汤姆试着杀死玛丽。

Tom tried to kill Mary.

Why: State 着. [[Mandarin Chinese#^zh-Q0503|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%B1%A4%E5%A7%86%E8%AF%95%E7%9D%80%E6%9D%80%E6%AD%BB%E7%8E%9B%E4%B8%BD%E3%80%82)
^zh-Q0503-answer

**zh-Q0504** — 汤姆试着杀死玛丽。

Tom tried to kill Mary.

Aspectual 着 often marks a maintained state or accompanying posture. It differs from pre-verbal 在 for a dynamic ongoing activity. Read its relation to the verb rather than treating every occurrence identically.

Why: State 着. [[Mandarin Chinese#^zh-Q0504|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%B1%A4%E5%A7%86%E8%AF%95%E7%9D%80%E6%9D%80%E6%AD%BB%E7%8E%9B%E4%B8%BD%E3%80%82)
^zh-Q0504-answer

**zh-Q0505** — 中国的经济随着时间的推移而变得越来越好。

As time goes on, China's economy gets stronger and stronger.

Expected form: **着**

Why: State 着. [[Mandarin Chinese#^zh-Q0505|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%B8%AD%E5%9B%BD%E7%9A%84%E7%BB%8F%E6%B5%8E%E9%9A%8F%E7%9D%80%E6%97%B6%E9%97%B4%E7%9A%84%E6%8E%A8%E7%A7%BB%E8%80%8C%E5%8F%98%E5%BE%97%E8%B6%8A%E6%9D%A5%E8%B6%8A%E5%A5%BD%E3%80%82)
^zh-Q0505-answer

**zh-Q0506** — 中国的经济随着时间的推移而变得越来越好。

As time goes on, China's economy gets stronger and stronger.

Expected form: **着**

Why: State 着. [[Mandarin Chinese#^zh-Q0506|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%B8%AD%E5%9B%BD%E7%9A%84%E7%BB%8F%E6%B5%8E%E9%9A%8F%E7%9D%80%E6%97%B6%E9%97%B4%E7%9A%84%E6%8E%A8%E7%A7%BB%E8%80%8C%E5%8F%98%E5%BE%97%E8%B6%8A%E6%9D%A5%E8%B6%8A%E5%A5%BD%E3%80%82)
^zh-Q0506-answer

**zh-Q0507** — 我的朋友相信阴谋论，我该试着向他指出他错了吗？

My friend believes conspiracy theories; should I try to prove him wrong?

Expected form: **着**

Why: State 着. [[Mandarin Chinese#^zh-Q0507|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E7%9A%84%E6%9C%8B%E5%8F%8B%E7%9B%B8%E4%BF%A1%E9%98%B4%E8%B0%8B%E8%AE%BA%EF%BC%8C%E6%88%91%E8%AF%A5%E8%AF%95%E7%9D%80%E5%90%91%E4%BB%96%E6%8C%87%E5%87%BA%E4%BB%96%E9%94%99%E4%BA%86%E5%90%97%EF%BC%9F)
^zh-Q0507-answer

**zh-Q0508** — 我的朋友相信阴谋论，我该试着向他指出他错了吗？

My friend believes conspiracy theories; should I try to prove him wrong?

Why: State 着. [[Mandarin Chinese#^zh-Q0508|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E7%9A%84%E6%9C%8B%E5%8F%8B%E7%9B%B8%E4%BF%A1%E9%98%B4%E8%B0%8B%E8%AE%BA%EF%BC%8C%E6%88%91%E8%AF%A5%E8%AF%95%E7%9D%80%E5%90%91%E4%BB%96%E6%8C%87%E5%87%BA%E4%BB%96%E9%94%99%E4%BA%86%E5%90%97%EF%BC%9F)
^zh-Q0508-answer

**zh-Q0509** — 我和汤姆在公园的长椅上坐着，一边聊天一边喂着鸽子。

Tom and I sat on a bench in the park and talked while we fed pigeons.

Why: State 着. [[Mandarin Chinese#^zh-Q0509|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E5%92%8C%E6%B1%A4%E5%A7%86%E5%9C%A8%E5%85%AC%E5%9B%AD%E7%9A%84%E9%95%BF%E6%A4%85%E4%B8%8A%E5%9D%90%E7%9D%80%EF%BC%8C%E4%B8%80%E8%BE%B9%E8%81%8A%E5%A4%A9%E4%B8%80%E8%BE%B9%E5%96%82%E7%9D%80%E9%B8%BD%E5%AD%90%E3%80%82)
^zh-Q0509-answer

**zh-Q0510** — 我和汤姆在公园的长椅上坐着，一边聊天一边喂着鸽子。

Tom and I sat on a bench in the park and talked while we fed pigeons.

Aspectual 着 often marks a maintained state or accompanying posture. It differs from pre-verbal 在 for a dynamic ongoing activity. Read its relation to the verb rather than treating every occurrence identically.

Why: State 着. [[Mandarin Chinese#^zh-Q0510|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E5%92%8C%E6%B1%A4%E5%A7%86%E5%9C%A8%E5%85%AC%E5%9B%AD%E7%9A%84%E9%95%BF%E6%A4%85%E4%B8%8A%E5%9D%90%E7%9D%80%EF%BC%8C%E4%B8%80%E8%BE%B9%E8%81%8A%E5%A4%A9%E4%B8%80%E8%BE%B9%E5%96%82%E7%9D%80%E9%B8%BD%E5%AD%90%E3%80%82)
^zh-Q0510-answer

**zh-Q0511** — 那个胖女人拿着一只猴子。

The fat woman was holding a monkey.

Expected form: **着**

Why: State 着. [[Mandarin Chinese#^zh-Q0511|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E9%82%A3%E4%B8%AA%E8%83%96%E5%A5%B3%E4%BA%BA%E6%8B%BF%E7%9D%80%E4%B8%80%E5%8F%AA%E7%8C%B4%E5%AD%90%E3%80%82)
^zh-Q0511-answer

**zh-Q0512** — 那个胖女人拿着一只猴子。

The fat woman was holding a monkey.

Expected form: **着**

Why: State 着. [[Mandarin Chinese#^zh-Q0512|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E9%82%A3%E4%B8%AA%E8%83%96%E5%A5%B3%E4%BA%BA%E6%8B%BF%E7%9D%80%E4%B8%80%E5%8F%AA%E7%8C%B4%E5%AD%90%E3%80%82)
^zh-Q0512-answer

**zh-Q0513** — 学友的手里正拿着北京地图呢。

My schoolmate is holding a map of Beijing in his hand.

Expected form: **着**

Why: State 着. [[Mandarin Chinese#^zh-Q0513|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%AD%A6%E5%8F%8B%E7%9A%84%E6%89%8B%E9%87%8C%E6%AD%A3%E6%8B%BF%E7%9D%80%E5%8C%97%E4%BA%AC%E5%9C%B0%E5%9B%BE%E5%91%A2%E3%80%82)
^zh-Q0513-answer

**zh-Q0514** — 学友的手里正拿着北京地图呢。

My schoolmate is holding a map of Beijing in his hand.

Why: State 着. [[Mandarin Chinese#^zh-Q0514|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%AD%A6%E5%8F%8B%E7%9A%84%E6%89%8B%E9%87%8C%E6%AD%A3%E6%8B%BF%E7%9D%80%E5%8C%97%E4%BA%AC%E5%9C%B0%E5%9B%BE%E5%91%A2%E3%80%82)
^zh-Q0514-answer

**zh-Q0515** — 我本来预备今天去海滩的，但接着天就开始下雨了。

I was planning on going to the beach today, but then it started to rain.

Why: State 着. [[Mandarin Chinese#^zh-Q0515|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E6%9C%AC%E6%9D%A5%E9%A2%84%E5%A4%87%E4%BB%8A%E5%A4%A9%E5%8E%BB%E6%B5%B7%E6%BB%A9%E7%9A%84%EF%BC%8C%E4%BD%86%E6%8E%A5%E7%9D%80%E5%A4%A9%E5%B0%B1%E5%BC%80%E5%A7%8B%E4%B8%8B%E9%9B%A8%E4%BA%86%E3%80%82)
^zh-Q0515-answer

**zh-Q0516** — 我本来预备今天去海滩的，但接着天就开始下雨了。

I was planning on going to the beach today, but then it started to rain.

Aspectual 着 often marks a maintained state or accompanying posture. It differs from pre-verbal 在 for a dynamic ongoing activity. Read its relation to the verb rather than treating every occurrence identically.

Why: State 着. [[Mandarin Chinese#^zh-Q0516|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E6%9C%AC%E6%9D%A5%E9%A2%84%E5%A4%87%E4%BB%8A%E5%A4%A9%E5%8E%BB%E6%B5%B7%E6%BB%A9%E7%9A%84%EF%BC%8C%E4%BD%86%E6%8E%A5%E7%9D%80%E5%A4%A9%E5%B0%B1%E5%BC%80%E5%A7%8B%E4%B8%8B%E9%9B%A8%E4%BA%86%E3%80%82)
^zh-Q0516-answer

**zh-Q0517** — 玛丽穿着深蓝色的裙子。

Mary was wearing a navy blue skirt.

Expected form: **着**

Why: State 着. [[Mandarin Chinese#^zh-Q0517|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E7%8E%9B%E4%B8%BD%E7%A9%BF%E7%9D%80%E6%B7%B1%E8%93%9D%E8%89%B2%E7%9A%84%E8%A3%99%E5%AD%90%E3%80%82)
^zh-Q0517-answer

**zh-Q0518** — 玛丽穿着深蓝色的裙子。

Mary was wearing a navy blue skirt.

Expected form: **着**

Why: State 着. [[Mandarin Chinese#^zh-Q0518|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E7%8E%9B%E4%B8%BD%E7%A9%BF%E7%9D%80%E6%B7%B1%E8%93%9D%E8%89%B2%E7%9A%84%E8%A3%99%E5%AD%90%E3%80%82)
^zh-Q0518-answer

**zh-Q0519** — 我试着考虑更好的计划。

I'm trying to think of better plan.

Expected form: **着**

Why: State 着. [[Mandarin Chinese#^zh-Q0519|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E8%AF%95%E7%9D%80%E8%80%83%E8%99%91%E6%9B%B4%E5%A5%BD%E7%9A%84%E8%AE%A1%E5%88%92%E3%80%82)
^zh-Q0519-answer

**zh-Q0520** — 我试着考虑更好的计划。

I'm trying to think of better plan.

Why: State 着. [[Mandarin Chinese#^zh-Q0520|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E8%AF%95%E7%9D%80%E8%80%83%E8%99%91%E6%9B%B4%E5%A5%BD%E7%9A%84%E8%AE%A1%E5%88%92%E3%80%82)
^zh-Q0520-answer

**zh-Q0521** — 那里有许多雏菊围绕着钢铁大厦。

There are daisies around the steel building.

Why: State 着. [[Mandarin Chinese#^zh-Q0521|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E9%82%A3%E9%87%8C%E6%9C%89%E8%AE%B8%E5%A4%9A%E9%9B%8F%E8%8F%8A%E5%9B%B4%E7%BB%95%E7%9D%80%E9%92%A2%E9%93%81%E5%A4%A7%E5%8E%A6%E3%80%82)
^zh-Q0521-answer

**zh-Q0522** — 那里有许多雏菊围绕着钢铁大厦。

There are daisies around the steel building.

Aspectual 着 often marks a maintained state or accompanying posture. It differs from pre-verbal 在 for a dynamic ongoing activity. Read its relation to the verb rather than treating every occurrence identically.

Why: State 着. [[Mandarin Chinese#^zh-Q0522|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E9%82%A3%E9%87%8C%E6%9C%89%E8%AE%B8%E5%A4%9A%E9%9B%8F%E8%8F%8A%E5%9B%B4%E7%BB%95%E7%9D%80%E9%92%A2%E9%93%81%E5%A4%A7%E5%8E%A6%E3%80%82)
^zh-Q0522-answer

**zh-Q0523** — 爸爸说，最重要的是我活着。

Dad says the most important thing is that I'm alive.

Expected form: **着**

Why: State 着. [[Mandarin Chinese#^zh-Q0523|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E7%88%B8%E7%88%B8%E8%AF%B4%EF%BC%8C%E6%9C%80%E9%87%8D%E8%A6%81%E7%9A%84%E6%98%AF%E6%88%91%E6%B4%BB%E7%9D%80%E3%80%82)
^zh-Q0523-answer

**zh-Q0524** — 爸爸说，最重要的是我活着。

Dad says the most important thing is that I'm alive.

Expected form: **着**

Why: State 着. [[Mandarin Chinese#^zh-Q0524|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E7%88%B8%E7%88%B8%E8%AF%B4%EF%BC%8C%E6%9C%80%E9%87%8D%E8%A6%81%E7%9A%84%E6%98%AF%E6%88%91%E6%B4%BB%E7%9D%80%E3%80%82)
^zh-Q0524-answer

**zh-Q0525** — 学友看着人美在北京照的新照片。

Xueyou is looking at the new pictures Renmei took in Beijing.

Expected form: **着**

Why: State 着. [[Mandarin Chinese#^zh-Q0525|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%AD%A6%E5%8F%8B%E7%9C%8B%E7%9D%80%E4%BA%BA%E7%BE%8E%E5%9C%A8%E5%8C%97%E4%BA%AC%E7%85%A7%E7%9A%84%E6%96%B0%E7%85%A7%E7%89%87%E3%80%82)
^zh-Q0525-answer

**zh-Q0526** — 学友看着人美在北京照的新照片。

Xueyou is looking at the new pictures Renmei took in Beijing.

Why: State 着. [[Mandarin Chinese#^zh-Q0526|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%AD%A6%E5%8F%8B%E7%9C%8B%E7%9D%80%E4%BA%BA%E7%BE%8E%E5%9C%A8%E5%8C%97%E4%BA%AC%E7%85%A7%E7%9A%84%E6%96%B0%E7%85%A7%E7%89%87%E3%80%82)
^zh-Q0526-answer

**zh-Q0527** — 她手里拿着一朵玫瑰。

She has a rose in her hand.

Why: State 着. [[Mandarin Chinese#^zh-Q0527|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A5%B9%E6%89%8B%E9%87%8C%E6%8B%BF%E7%9D%80%E4%B8%80%E6%9C%B5%E7%8E%AB%E7%91%B0%E3%80%82)
^zh-Q0527-answer

**zh-Q0528** — 她手里拿着一朵玫瑰。

She has a rose in her hand.

Aspectual 着 often marks a maintained state or accompanying posture. It differs from pre-verbal 在 for a dynamic ongoing activity. Read its relation to the verb rather than treating every occurrence identically.

Why: State 着. [[Mandarin Chinese#^zh-Q0528|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A5%B9%E6%89%8B%E9%87%8C%E6%8B%BF%E7%9D%80%E4%B8%80%E6%9C%B5%E7%8E%AB%E7%91%B0%E3%80%82)
^zh-Q0528-answer

**zh-Q0529** — 一个牧羊人把赶着全身盖白雪的山羊进去被遗弃的山洞躲避暴风雪。

A goatherd drove his goats, all white with snow, into a deserted cave for shelter.

Expected form: **着**

Why: State 着. [[Mandarin Chinese#^zh-Q0529|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%B8%80%E4%B8%AA%E7%89%A7%E7%BE%8A%E4%BA%BA%E6%8A%8A%E8%B5%B6%E7%9D%80%E5%85%A8%E8%BA%AB%E7%9B%96%E7%99%BD%E9%9B%AA%E7%9A%84%E5%B1%B1%E7%BE%8A%E8%BF%9B%E5%8E%BB%E8%A2%AB%E9%81%97%E5%BC%83%E7%9A%84%E5%B1%B1%E6%B4%9E%E8%BA%B2%E9%81%BF%E6%9A%B4%E9%A3%8E%E9%9B%AA%E3%80%82)
^zh-Q0529-answer

**zh-Q0530** — 一个牧羊人把赶着全身盖白雪的山羊进去被遗弃的山洞躲避暴风雪。

A goatherd drove his goats, all white with snow, into a deserted cave for shelter.

Expected form: **着**

Why: State 着. [[Mandarin Chinese#^zh-Q0530|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%B8%80%E4%B8%AA%E7%89%A7%E7%BE%8A%E4%BA%BA%E6%8A%8A%E8%B5%B6%E7%9D%80%E5%85%A8%E8%BA%AB%E7%9B%96%E7%99%BD%E9%9B%AA%E7%9A%84%E5%B1%B1%E7%BE%8A%E8%BF%9B%E5%8E%BB%E8%A2%AB%E9%81%97%E5%BC%83%E7%9A%84%E5%B1%B1%E6%B4%9E%E8%BA%B2%E9%81%BF%E6%9A%B4%E9%A3%8E%E9%9B%AA%E3%80%82)
^zh-Q0530-answer

**zh-Q0531** — 他带着雨伞因为下雨了。

He's carrying an umbrella because it's raining.

Expected form: **着**

Why: State 着. [[Mandarin Chinese#^zh-Q0531|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%96%E5%B8%A6%E7%9D%80%E9%9B%A8%E4%BC%9E%E5%9B%A0%E4%B8%BA%E4%B8%8B%E9%9B%A8%E4%BA%86%E3%80%82)
^zh-Q0531-answer

**zh-Q0532** — 他带着雨伞因为下雨了。

He's carrying an umbrella because it's raining.

Why: State 着. [[Mandarin Chinese#^zh-Q0532|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%96%E5%B8%A6%E7%9D%80%E9%9B%A8%E4%BC%9E%E5%9B%A0%E4%B8%BA%E4%B8%8B%E9%9B%A8%E4%BA%86%E3%80%82)
^zh-Q0532-answer

**zh-Q0533** — 她手里握着一把小阳伞。

She was holding a small parasol in her hand.

Why: State 着. [[Mandarin Chinese#^zh-Q0533|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A5%B9%E6%89%8B%E9%87%8C%E6%8F%A1%E7%9D%80%E4%B8%80%E6%8A%8A%E5%B0%8F%E9%98%B3%E4%BC%9E%E3%80%82)
^zh-Q0533-answer

**zh-Q0534** — 她手里握着一把小阳伞。

She was holding a small parasol in her hand.

Aspectual 着 often marks a maintained state or accompanying posture. It differs from pre-verbal 在 for a dynamic ongoing activity. Read its relation to the verb rather than treating every occurrence identically.

Why: State 着. [[Mandarin Chinese#^zh-Q0534|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A5%B9%E6%89%8B%E9%87%8C%E6%8F%A1%E7%9D%80%E4%B8%80%E6%8A%8A%E5%B0%8F%E9%98%B3%E4%BC%9E%E3%80%82)
^zh-Q0534-answer

**zh-Q0535** — 婴儿被志愿者们照顾着。

The babies are taken care of by volunteers.

Expected form: **着**

Why: State 着. [[Mandarin Chinese#^zh-Q0535|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A9%B4%E5%84%BF%E8%A2%AB%E5%BF%97%E6%84%BF%E8%80%85%E4%BB%AC%E7%85%A7%E9%A1%BE%E7%9D%80%E3%80%82)
^zh-Q0535-answer

**zh-Q0536** — 婴儿被志愿者们照顾着。

The babies are taken care of by volunteers.

Expected form: **着**

Why: State 着. [[Mandarin Chinese#^zh-Q0536|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A9%B4%E5%84%BF%E8%A2%AB%E5%BF%97%E6%84%BF%E8%80%85%E4%BB%AC%E7%85%A7%E9%A1%BE%E7%9D%80%E3%80%82)
^zh-Q0536-answer

**zh-Q0537** — 你最好照着医生的建议做。

You had better do as the doctor advised you.

Expected form: **着**

Why: State 着. [[Mandarin Chinese#^zh-Q0537|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E6%9C%80%E5%A5%BD%E7%85%A7%E7%9D%80%E5%8C%BB%E7%94%9F%E7%9A%84%E5%BB%BA%E8%AE%AE%E5%81%9A%E3%80%82)
^zh-Q0537-answer

**zh-Q0538** — 你最好照着医生的建议做。

You had better do as the doctor advised you.

Why: State 着. [[Mandarin Chinese#^zh-Q0538|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E6%9C%80%E5%A5%BD%E7%85%A7%E7%9D%80%E5%8C%BB%E7%94%9F%E7%9A%84%E5%BB%BA%E8%AE%AE%E5%81%9A%E3%80%82)
^zh-Q0538-answer

**zh-Q0539** — 汤姆睡着了。我应该叫醒他吗？

Tom is asleep. Should I wake him up?

Why: State 着. [[Mandarin Chinese#^zh-Q0539|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%B1%A4%E5%A7%86%E7%9D%A1%E7%9D%80%E4%BA%86%E3%80%82%E6%88%91%E5%BA%94%E8%AF%A5%E5%8F%AB%E9%86%92%E4%BB%96%E5%90%97%EF%BC%9F)
^zh-Q0539-answer

**zh-Q0540** — 汤姆睡着了。我应该叫醒他吗？

Tom is asleep. Should I wake him up?

Aspectual 着 often marks a maintained state or accompanying posture. It differs from pre-verbal 在 for a dynamic ongoing activity. Read its relation to the verb rather than treating every occurrence identically.

Why: State 着. [[Mandarin Chinese#^zh-Q0540|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%B1%A4%E5%A7%86%E7%9D%A1%E7%9D%80%E4%BA%86%E3%80%82%E6%88%91%E5%BA%94%E8%AF%A5%E5%8F%AB%E9%86%92%E4%BB%96%E5%90%97%EF%BC%9F)
^zh-Q0540-answer

**zh-Q0541** — 我们一字不落的，专心致志的听着。

We listened with great care, not missing a single word.

Expected form: **着**

Why: State 着. [[Mandarin Chinese#^zh-Q0541|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E4%BB%AC%E4%B8%80%E5%AD%97%E4%B8%8D%E8%90%BD%E7%9A%84%EF%BC%8C%E4%B8%93%E5%BF%83%E8%87%B4%E5%BF%97%E7%9A%84%E5%90%AC%E7%9D%80%E3%80%82)
^zh-Q0541-answer

**zh-Q0542** — 我们一字不落的，专心致志的听着。

We listened with great care, not missing a single word.

Expected form: **着**

Why: State 着. [[Mandarin Chinese#^zh-Q0542|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E4%BB%AC%E4%B8%80%E5%AD%97%E4%B8%8D%E8%90%BD%E7%9A%84%EF%BC%8C%E4%B8%93%E5%BF%83%E8%87%B4%E5%BF%97%E7%9A%84%E5%90%AC%E7%9D%80%E3%80%82)
^zh-Q0542-answer

**zh-Q0543** — 走着去火车站要多久？

How long does it take to walk to the station?

Expected form: **着**

Why: State 着. [[Mandarin Chinese#^zh-Q0543|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%B5%B0%E7%9D%80%E5%8E%BB%E7%81%AB%E8%BD%A6%E7%AB%99%E8%A6%81%E5%A4%9A%E4%B9%85%EF%BC%9F)
^zh-Q0543-answer

**zh-Q0544** — 走着去火车站要多久？

How long does it take to walk to the station?

Why: State 着. [[Mandarin Chinese#^zh-Q0544|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%B5%B0%E7%9D%80%E5%8E%BB%E7%81%AB%E8%BD%A6%E7%AB%99%E8%A6%81%E5%A4%9A%E4%B9%85%EF%BC%9F)
^zh-Q0544-answer

**zh-Q0545** — 韩国随着朝鲜的外患而在边界附近集结军队。

As North Korea displays aggression, South Korea concentrates its forces near the border.

Why: State 着. [[Mandarin Chinese#^zh-Q0545|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E9%9F%A9%E5%9B%BD%E9%9A%8F%E7%9D%80%E6%9C%9D%E9%B2%9C%E7%9A%84%E5%A4%96%E6%82%A3%E8%80%8C%E5%9C%A8%E8%BE%B9%E7%95%8C%E9%99%84%E8%BF%91%E9%9B%86%E7%BB%93%E5%86%9B%E9%98%9F%E3%80%82)
^zh-Q0545-answer

**zh-Q0546** — 韩国随着朝鲜的外患而在边界附近集结军队。

As North Korea displays aggression, South Korea concentrates its forces near the border.

Aspectual 着 often marks a maintained state or accompanying posture. It differs from pre-verbal 在 for a dynamic ongoing activity. Read its relation to the verb rather than treating every occurrence identically.

Why: State 着. [[Mandarin Chinese#^zh-Q0546|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E9%9F%A9%E5%9B%BD%E9%9A%8F%E7%9D%80%E6%9C%9D%E9%B2%9C%E7%9A%84%E5%A4%96%E6%82%A3%E8%80%8C%E5%9C%A8%E8%BE%B9%E7%95%8C%E9%99%84%E8%BF%91%E9%9B%86%E7%BB%93%E5%86%9B%E9%98%9F%E3%80%82)
^zh-Q0546-answer

**zh-Q0547** — 箱子的内容在标签上面写着。

The contents of the box are listed on the label.

Expected form: **着**

Why: State 着. [[Mandarin Chinese#^zh-Q0547|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E7%AE%B1%E5%AD%90%E7%9A%84%E5%86%85%E5%AE%B9%E5%9C%A8%E6%A0%87%E7%AD%BE%E4%B8%8A%E9%9D%A2%E5%86%99%E7%9D%80%E3%80%82)
^zh-Q0547-answer

**zh-Q0548** — 箱子的内容在标签上面写着。

The contents of the box are listed on the label.

Expected form: **着**

Why: State 着. [[Mandarin Chinese#^zh-Q0548|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E7%AE%B1%E5%AD%90%E7%9A%84%E5%86%85%E5%AE%B9%E5%9C%A8%E6%A0%87%E7%AD%BE%E4%B8%8A%E9%9D%A2%E5%86%99%E7%9D%80%E3%80%82)
^zh-Q0548-answer

**zh-Q0549** — 如果你能将它读出来，那就意味着你会说这门语言。

If you can read this, it means that you can speak one language!

Expected form: **着**

Why: State 着. [[Mandarin Chinese#^zh-Q0549|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A6%82%E6%9E%9C%E4%BD%A0%E8%83%BD%E5%B0%86%E5%AE%83%E8%AF%BB%E5%87%BA%E6%9D%A5%EF%BC%8C%E9%82%A3%E5%B0%B1%E6%84%8F%E5%91%B3%E7%9D%80%E4%BD%A0%E4%BC%9A%E8%AF%B4%E8%BF%99%E9%97%A8%E8%AF%AD%E8%A8%80%E3%80%82)
^zh-Q0549-answer

**zh-Q0550** — 如果你能将它读出来，那就意味着你会说这门语言。

If you can read this, it means that you can speak one language!

Why: State 着. [[Mandarin Chinese#^zh-Q0550|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A6%82%E6%9E%9C%E4%BD%A0%E8%83%BD%E5%B0%86%E5%AE%83%E8%AF%BB%E5%87%BA%E6%9D%A5%EF%BC%8C%E9%82%A3%E5%B0%B1%E6%84%8F%E5%91%B3%E7%9D%80%E4%BD%A0%E4%BC%9A%E8%AF%B4%E8%BF%99%E9%97%A8%E8%AF%AD%E8%A8%80%E3%80%82)
^zh-Q0550-answer


### Answers 551–600

**zh-Q0551** — 把椅子挪一挪靠近桌子。

Move the chair nearer to the desk.

Why: Disposal 把. [[Mandarin Chinese#^zh-Q0551|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%8A%8A%E6%A4%85%E5%AD%90%E6%8C%AA%E4%B8%80%E6%8C%AA%E9%9D%A0%E8%BF%91%E6%A1%8C%E5%AD%90%E3%80%82)
^zh-Q0551-answer

**zh-Q0552** — 把椅子挪一挪靠近桌子。

Move the chair nearer to the desk.

A 把 construction places a disposal-affected object before the verb. It commonly needs a suitably specific object and a predicate describing its handling/result. 把 is also a classifier in other contexts.

Why: Disposal 把. [[Mandarin Chinese#^zh-Q0552|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%8A%8A%E6%A4%85%E5%AD%90%E6%8C%AA%E4%B8%80%E6%8C%AA%E9%9D%A0%E8%BF%91%E6%A1%8C%E5%AD%90%E3%80%82)
^zh-Q0552-answer

**zh-Q0553** — 可以把新地址告訴我嗎？

Please let me know your new address.

Expected form: **把**

Why: Disposal 把. [[Mandarin Chinese#^zh-Q0553|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%8F%AF%E4%BB%A5%E6%8A%8A%E6%96%B0%E5%9C%B0%E5%9D%80%E5%91%8A%E8%A8%B4%E6%88%91%E5%97%8E%EF%BC%9F)
^zh-Q0553-answer

**zh-Q0554** — 可以把新地址告訴我嗎？

Please let me know your new address.

Expected form: **把**

Why: Disposal 把. [[Mandarin Chinese#^zh-Q0554|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%8F%AF%E4%BB%A5%E6%8A%8A%E6%96%B0%E5%9C%B0%E5%9D%80%E5%91%8A%E8%A8%B4%E6%88%91%E5%97%8E%EF%BC%9F)
^zh-Q0554-answer

**zh-Q0555** — 我保證在一個星期內把這盤錄影帶還給你。

I promise to return this videotape within a week.

Expected form: **把**

Why: Disposal 把. [[Mandarin Chinese#^zh-Q0555|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E4%BF%9D%E8%AD%89%E5%9C%A8%E4%B8%80%E5%80%8B%E6%98%9F%E6%9C%9F%E5%85%A7%E6%8A%8A%E9%80%99%E7%9B%A4%E9%8C%84%E5%BD%B1%E5%B8%B6%E9%82%84%E7%B5%A6%E4%BD%A0%E3%80%82)
^zh-Q0555-answer

**zh-Q0556** — 我保證在一個星期內把這盤錄影帶還給你。

I promise to return this videotape within a week.

Why: Disposal 把. [[Mandarin Chinese#^zh-Q0556|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E4%BF%9D%E8%AD%89%E5%9C%A8%E4%B8%80%E5%80%8B%E6%98%9F%E6%9C%9F%E5%85%A7%E6%8A%8A%E9%80%99%E7%9B%A4%E9%8C%84%E5%BD%B1%E5%B8%B6%E9%82%84%E7%B5%A6%E4%BD%A0%E3%80%82)
^zh-Q0556-answer

**zh-Q0557** — 我们把屋子漆成绿色。

We painted the house green.

Why: Disposal 把. [[Mandarin Chinese#^zh-Q0557|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E4%BB%AC%E6%8A%8A%E5%B1%8B%E5%AD%90%E6%BC%86%E6%88%90%E7%BB%BF%E8%89%B2%E3%80%82)
^zh-Q0557-answer

**zh-Q0558** — 我们把屋子漆成绿色。

We painted the house green.

A 把 construction places a disposal-affected object before the verb. It commonly needs a suitably specific object and a predicate describing its handling/result. 把 is also a classifier in other contexts.

Why: Disposal 把. [[Mandarin Chinese#^zh-Q0558|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E4%BB%AC%E6%8A%8A%E5%B1%8B%E5%AD%90%E6%BC%86%E6%88%90%E7%BB%BF%E8%89%B2%E3%80%82)
^zh-Q0558-answer

**zh-Q0559** — 把她哭的理由告诉我。

Tell me why she is crying.

Expected form: **把**

Why: Disposal 把. [[Mandarin Chinese#^zh-Q0559|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%8A%8A%E5%A5%B9%E5%93%AD%E7%9A%84%E7%90%86%E7%94%B1%E5%91%8A%E8%AF%89%E6%88%91%E3%80%82)
^zh-Q0559-answer

**zh-Q0560** — 把她哭的理由告诉我。

Tell me why she is crying.

Expected form: **把**

Why: Disposal 把. [[Mandarin Chinese#^zh-Q0560|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%8A%8A%E5%A5%B9%E5%93%AD%E7%9A%84%E7%90%86%E7%94%B1%E5%91%8A%E8%AF%89%E6%88%91%E3%80%82)
^zh-Q0560-answer

**zh-Q0561** — 我必須把文身去掉。

I had to get my tattoo removed.

Expected form: **把**

Why: Disposal 把. [[Mandarin Chinese#^zh-Q0561|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E5%BF%85%E9%A0%88%E6%8A%8A%E6%96%87%E8%BA%AB%E5%8E%BB%E6%8E%89%E3%80%82)
^zh-Q0561-answer

**zh-Q0562** — 我必須把文身去掉。

I had to get my tattoo removed.

Why: Disposal 把. [[Mandarin Chinese#^zh-Q0562|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E5%BF%85%E9%A0%88%E6%8A%8A%E6%96%87%E8%BA%AB%E5%8E%BB%E6%8E%89%E3%80%82)
^zh-Q0562-answer

**zh-Q0563** — 他把信從我的手中搶了過去。

He wrenched the letter from my hand.

Why: Disposal 把. [[Mandarin Chinese#^zh-Q0563|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%96%E6%8A%8A%E4%BF%A1%E5%BE%9E%E6%88%91%E7%9A%84%E6%89%8B%E4%B8%AD%E6%90%B6%E4%BA%86%E9%81%8E%E5%8E%BB%E3%80%82)
^zh-Q0563-answer

**zh-Q0564** — 他把信從我的手中搶了過去。

He wrenched the letter from my hand.

A 把 construction places a disposal-affected object before the verb. It commonly needs a suitably specific object and a predicate describing its handling/result. 把 is also a classifier in other contexts.

Why: Disposal 把. [[Mandarin Chinese#^zh-Q0564|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%96%E6%8A%8A%E4%BF%A1%E5%BE%9E%E6%88%91%E7%9A%84%E6%89%8B%E4%B8%AD%E6%90%B6%E4%BA%86%E9%81%8E%E5%8E%BB%E3%80%82)
^zh-Q0564-answer

**zh-Q0565** — 那場火災把郵車上的郵件燒掉了一大半。

The mail train lost most of its mail in the fire.

Expected form: **把**

Why: Disposal 把. [[Mandarin Chinese#^zh-Q0565|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E9%82%A3%E5%A0%B4%E7%81%AB%E7%81%BD%E6%8A%8A%E9%83%B5%E8%BB%8A%E4%B8%8A%E7%9A%84%E9%83%B5%E4%BB%B6%E7%87%92%E6%8E%89%E4%BA%86%E4%B8%80%E5%A4%A7%E5%8D%8A%E3%80%82)
^zh-Q0565-answer

**zh-Q0566** — 那場火災把郵車上的郵件燒掉了一大半。

The mail train lost most of its mail in the fire.

Expected form: **把**

Why: Disposal 把. [[Mandarin Chinese#^zh-Q0566|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E9%82%A3%E5%A0%B4%E7%81%AB%E7%81%BD%E6%8A%8A%E9%83%B5%E8%BB%8A%E4%B8%8A%E7%9A%84%E9%83%B5%E4%BB%B6%E7%87%92%E6%8E%89%E4%BA%86%E4%B8%80%E5%A4%A7%E5%8D%8A%E3%80%82)
^zh-Q0566-answer

**zh-Q0567** — 他給我們做了一張桌子和兩把長椅。

He made a desk and two benches for us.

Expected form: **把**

Why: Disposal 把. [[Mandarin Chinese#^zh-Q0567|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%96%E7%B5%A6%E6%88%91%E5%80%91%E5%81%9A%E4%BA%86%E4%B8%80%E5%BC%B5%E6%A1%8C%E5%AD%90%E5%92%8C%E5%85%A9%E6%8A%8A%E9%95%B7%E6%A4%85%E3%80%82)
^zh-Q0567-answer

**zh-Q0568** — 他給我們做了一張桌子和兩把長椅。

He made a desk and two benches for us.

Why: Disposal 把. [[Mandarin Chinese#^zh-Q0568|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%96%E7%B5%A6%E6%88%91%E5%80%91%E5%81%9A%E4%BA%86%E4%B8%80%E5%BC%B5%E6%A1%8C%E5%AD%90%E5%92%8C%E5%85%A9%E6%8A%8A%E9%95%B7%E6%A4%85%E3%80%82)
^zh-Q0568-answer

**zh-Q0569** — 他奮不顧身地把遇溺的男孩救了起來。

He saved the drowning boy at the risk of his own life.

Why: Disposal 把. [[Mandarin Chinese#^zh-Q0569|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%96%E5%A5%AE%E4%B8%8D%E9%A1%A7%E8%BA%AB%E5%9C%B0%E6%8A%8A%E9%81%87%E6%BA%BA%E7%9A%84%E7%94%B7%E5%AD%A9%E6%95%91%E4%BA%86%E8%B5%B7%E4%BE%86%E3%80%82)
^zh-Q0569-answer

**zh-Q0570** — 他奮不顧身地把遇溺的男孩救了起來。

He saved the drowning boy at the risk of his own life.

A 把 construction places a disposal-affected object before the verb. It commonly needs a suitably specific object and a predicate describing its handling/result. 把 is also a classifier in other contexts.

Why: Disposal 把. [[Mandarin Chinese#^zh-Q0570|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%96%E5%A5%AE%E4%B8%8D%E9%A1%A7%E8%BA%AB%E5%9C%B0%E6%8A%8A%E9%81%87%E6%BA%BA%E7%9A%84%E7%94%B7%E5%AD%A9%E6%95%91%E4%BA%86%E8%B5%B7%E4%BE%86%E3%80%82)
^zh-Q0570-answer

**zh-Q0571** — 进教室的时候请把帽子摘了。

Take off your hat when you enter a classroom.

Expected form: **把**

Why: Disposal 把. [[Mandarin Chinese#^zh-Q0571|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%BF%9B%E6%95%99%E5%AE%A4%E7%9A%84%E6%97%B6%E5%80%99%E8%AF%B7%E6%8A%8A%E5%B8%BD%E5%AD%90%E6%91%98%E4%BA%86%E3%80%82)
^zh-Q0571-answer

**zh-Q0572** — 进教室的时候请把帽子摘了。

Take off your hat when you enter a classroom.

Expected form: **把**

Why: Disposal 把. [[Mandarin Chinese#^zh-Q0572|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%BF%9B%E6%95%99%E5%AE%A4%E7%9A%84%E6%97%B6%E5%80%99%E8%AF%B7%E6%8A%8A%E5%B8%BD%E5%AD%90%E6%91%98%E4%BA%86%E3%80%82)
^zh-Q0572-answer

**zh-Q0573** — 請記得把信寄出去。

Please remember to mail the letter.

Expected form: **把**

Why: Disposal 把. [[Mandarin Chinese#^zh-Q0573|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%AB%8B%E8%A8%98%E5%BE%97%E6%8A%8A%E4%BF%A1%E5%AF%84%E5%87%BA%E5%8E%BB%E3%80%82)
^zh-Q0573-answer

**zh-Q0574** — 請記得把信寄出去。

Please remember to mail the letter.

Why: Disposal 把. [[Mandarin Chinese#^zh-Q0574|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%AB%8B%E8%A8%98%E5%BE%97%E6%8A%8A%E4%BF%A1%E5%AF%84%E5%87%BA%E5%8E%BB%E3%80%82)
^zh-Q0574-answer

**zh-Q0575** — 你绝不可把马赛和里昂相比。

You definitely can't compare Marseilles and Lyons.

Why: Disposal 把. [[Mandarin Chinese#^zh-Q0575|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E7%BB%9D%E4%B8%8D%E5%8F%AF%E6%8A%8A%E9%A9%AC%E8%B5%9B%E5%92%8C%E9%87%8C%E6%98%82%E7%9B%B8%E6%AF%94%E3%80%82)
^zh-Q0575-answer

**zh-Q0576** — 你绝不可把马赛和里昂相比。

You definitely can't compare Marseilles and Lyons.

A 把 construction places a disposal-affected object before the verb. It commonly needs a suitably specific object and a predicate describing its handling/result. 把 is also a classifier in other contexts.

Why: Disposal 把. [[Mandarin Chinese#^zh-Q0576|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E7%BB%9D%E4%B8%8D%E5%8F%AF%E6%8A%8A%E9%A9%AC%E8%B5%9B%E5%92%8C%E9%87%8C%E6%98%82%E7%9B%B8%E6%AF%94%E3%80%82)
^zh-Q0576-answer

**zh-Q0577** — 她慢慢转动门把手。

She turned the doorknob slowly.

Expected form: **把**

Why: Disposal 把. [[Mandarin Chinese#^zh-Q0577|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A5%B9%E6%85%A2%E6%85%A2%E8%BD%AC%E5%8A%A8%E9%97%A8%E6%8A%8A%E6%89%8B%E3%80%82)
^zh-Q0577-answer

**zh-Q0578** — 她慢慢转动门把手。

She turned the doorknob slowly.

Expected form: **把**

Why: Disposal 把. [[Mandarin Chinese#^zh-Q0578|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A5%B9%E6%85%A2%E6%85%A2%E8%BD%AC%E5%8A%A8%E9%97%A8%E6%8A%8A%E6%89%8B%E3%80%82)
^zh-Q0578-answer

**zh-Q0579** — 我把你视为我最要好的朋友之一。

I consider you one of my closest friends.

Expected form: **把**

Why: Disposal 把. [[Mandarin Chinese#^zh-Q0579|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E6%8A%8A%E4%BD%A0%E8%A7%86%E4%B8%BA%E6%88%91%E6%9C%80%E8%A6%81%E5%A5%BD%E7%9A%84%E6%9C%8B%E5%8F%8B%E4%B9%8B%E4%B8%80%E3%80%82)
^zh-Q0579-answer

**zh-Q0580** — 我把你视为我最要好的朋友之一。

I consider you one of my closest friends.

Why: Disposal 把. [[Mandarin Chinese#^zh-Q0580|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E6%8A%8A%E4%BD%A0%E8%A7%86%E4%B8%BA%E6%88%91%E6%9C%80%E8%A6%81%E5%A5%BD%E7%9A%84%E6%9C%8B%E5%8F%8B%E4%B9%8B%E4%B8%80%E3%80%82)
^zh-Q0580-answer

**zh-Q0581** — 我們必須把你带走。

We've got to get you out of here.

Why: Disposal 把. [[Mandarin Chinese#^zh-Q0581|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E5%80%91%E5%BF%85%E9%A0%88%E6%8A%8A%E4%BD%A0%E5%B8%A6%E8%B5%B0%E3%80%82)
^zh-Q0581-answer

**zh-Q0582** — 我們必須把你带走。

We've got to get you out of here.

A 把 construction places a disposal-affected object before the verb. It commonly needs a suitably specific object and a predicate describing its handling/result. 把 is also a classifier in other contexts.

Why: Disposal 把. [[Mandarin Chinese#^zh-Q0582|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E5%80%91%E5%BF%85%E9%A0%88%E6%8A%8A%E4%BD%A0%E5%B8%A6%E8%B5%B0%E3%80%82)
^zh-Q0582-answer

**zh-Q0583** — 汤姆把手伸向了书架上最高的一本词典。

Tom reached for a dictionary that was on the very top of the shelf.

Expected form: **把**

Why: Disposal 把. [[Mandarin Chinese#^zh-Q0583|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%B1%A4%E5%A7%86%E6%8A%8A%E6%89%8B%E4%BC%B8%E5%90%91%E4%BA%86%E4%B9%A6%E6%9E%B6%E4%B8%8A%E6%9C%80%E9%AB%98%E7%9A%84%E4%B8%80%E6%9C%AC%E8%AF%8D%E5%85%B8%E3%80%82)
^zh-Q0583-answer

**zh-Q0584** — 汤姆把手伸向了书架上最高的一本词典。

Tom reached for a dictionary that was on the very top of the shelf.

Expected form: **把**

Why: Disposal 把. [[Mandarin Chinese#^zh-Q0584|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%B1%A4%E5%A7%86%E6%8A%8A%E6%89%8B%E4%BC%B8%E5%90%91%E4%BA%86%E4%B9%A6%E6%9E%B6%E4%B8%8A%E6%9C%80%E9%AB%98%E7%9A%84%E4%B8%80%E6%9C%AC%E8%AF%8D%E5%85%B8%E3%80%82)
^zh-Q0584-answer

**zh-Q0585** — 她把书带回了图书馆。

She took the book back to the library.

Expected form: **把**

Why: Disposal 把. [[Mandarin Chinese#^zh-Q0585|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A5%B9%E6%8A%8A%E4%B9%A6%E5%B8%A6%E5%9B%9E%E4%BA%86%E5%9B%BE%E4%B9%A6%E9%A6%86%E3%80%82)
^zh-Q0585-answer

**zh-Q0586** — 她把书带回了图书馆。

She took the book back to the library.

Why: Disposal 把. [[Mandarin Chinese#^zh-Q0586|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A5%B9%E6%8A%8A%E4%B9%A6%E5%B8%A6%E5%9B%9E%E4%BA%86%E5%9B%BE%E4%B9%A6%E9%A6%86%E3%80%82)
^zh-Q0586-answer

**zh-Q0587** — 她把她的雨傘留在火車上了。

She left her umbrella in the train.

Why: Disposal 把. [[Mandarin Chinese#^zh-Q0587|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A5%B9%E6%8A%8A%E5%A5%B9%E7%9A%84%E9%9B%A8%E5%82%98%E7%95%99%E5%9C%A8%E7%81%AB%E8%BB%8A%E4%B8%8A%E4%BA%86%E3%80%82)
^zh-Q0587-answer

**zh-Q0588** — 她把她的雨傘留在火車上了。

She left her umbrella in the train.

A 把 construction places a disposal-affected object before the verb. It commonly needs a suitably specific object and a predicate describing its handling/result. 把 is also a classifier in other contexts.

Why: Disposal 把. [[Mandarin Chinese#^zh-Q0588|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A5%B9%E6%8A%8A%E5%A5%B9%E7%9A%84%E9%9B%A8%E5%82%98%E7%95%99%E5%9C%A8%E7%81%AB%E8%BB%8A%E4%B8%8A%E4%BA%86%E3%80%82)
^zh-Q0588-answer

**zh-Q0589** — 你把书拿反了，这是反面，这才是正面。

You're holding the book upside-down. This is upside-down and this is right-side up.

Expected form: **把**

Why: Disposal 把. [[Mandarin Chinese#^zh-Q0589|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E6%8A%8A%E4%B9%A6%E6%8B%BF%E5%8F%8D%E4%BA%86%EF%BC%8C%E8%BF%99%E6%98%AF%E5%8F%8D%E9%9D%A2%EF%BC%8C%E8%BF%99%E6%89%8D%E6%98%AF%E6%AD%A3%E9%9D%A2%E3%80%82)
^zh-Q0589-answer

**zh-Q0590** — 你把书拿反了，这是反面，这才是正面。

You're holding the book upside-down. This is upside-down and this is right-side up.

Expected form: **把**

Why: Disposal 把. [[Mandarin Chinese#^zh-Q0590|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E6%8A%8A%E4%B9%A6%E6%8B%BF%E5%8F%8D%E4%BA%86%EF%BC%8C%E8%BF%99%E6%98%AF%E5%8F%8D%E9%9D%A2%EF%BC%8C%E8%BF%99%E6%89%8D%E6%98%AF%E6%AD%A3%E9%9D%A2%E3%80%82)
^zh-Q0590-answer

**zh-Q0591** — Mary试图把围裙围在腰上，然后把烤鸡从炉子里拿出来。

Mary tied an apron around her waist and then took the turkey out of the oven.

Expected form: **把**

Why: Disposal 把. [[Mandarin Chinese#^zh-Q0591|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=Mary%E8%AF%95%E5%9B%BE%E6%8A%8A%E5%9B%B4%E8%A3%99%E5%9B%B4%E5%9C%A8%E8%85%B0%E4%B8%8A%EF%BC%8C%E7%84%B6%E5%90%8E%E6%8A%8A%E7%83%A4%E9%B8%A1%E4%BB%8E%E7%82%89%E5%AD%90%E9%87%8C%E6%8B%BF%E5%87%BA%E6%9D%A5%E3%80%82)
^zh-Q0591-answer

**zh-Q0592** — Mary试图把围裙围在腰上，然后把烤鸡从炉子里拿出来。

Mary tied an apron around her waist and then took the turkey out of the oven.

Why: Disposal 把. [[Mandarin Chinese#^zh-Q0592|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=Mary%E8%AF%95%E5%9B%BE%E6%8A%8A%E5%9B%B4%E8%A3%99%E5%9B%B4%E5%9C%A8%E8%85%B0%E4%B8%8A%EF%BC%8C%E7%84%B6%E5%90%8E%E6%8A%8A%E7%83%A4%E9%B8%A1%E4%BB%8E%E7%82%89%E5%AD%90%E9%87%8C%E6%8B%BF%E5%87%BA%E6%9D%A5%E3%80%82)
^zh-Q0592-answer

**zh-Q0593** — 他把天花板刷成了蓝色。

He painted the ceiling blue.

Why: Disposal 把. [[Mandarin Chinese#^zh-Q0593|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%96%E6%8A%8A%E5%A4%A9%E8%8A%B1%E6%9D%BF%E5%88%B7%E6%88%90%E4%BA%86%E8%93%9D%E8%89%B2%E3%80%82)
^zh-Q0593-answer

**zh-Q0594** — 他把天花板刷成了蓝色。

He painted the ceiling blue.

A 把 construction places a disposal-affected object before the verb. It commonly needs a suitably specific object and a predicate describing its handling/result. 把 is also a classifier in other contexts.

Why: Disposal 把. [[Mandarin Chinese#^zh-Q0594|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%96%E6%8A%8A%E5%A4%A9%E8%8A%B1%E6%9D%BF%E5%88%B7%E6%88%90%E4%BA%86%E8%93%9D%E8%89%B2%E3%80%82)
^zh-Q0594-answer

**zh-Q0595** — 我想他得花兩個小時才能把工作做完。

It will take him two hours to finish the work.

Expected form: **把**

Why: Disposal 把. [[Mandarin Chinese#^zh-Q0595|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E6%83%B3%E4%BB%96%E5%BE%97%E8%8A%B1%E5%85%A9%E5%80%8B%E5%B0%8F%E6%99%82%E6%89%8D%E8%83%BD%E6%8A%8A%E5%B7%A5%E4%BD%9C%E5%81%9A%E5%AE%8C%E3%80%82)
^zh-Q0595-answer

**zh-Q0596** — 我想他得花兩個小時才能把工作做完。

It will take him two hours to finish the work.

Expected form: **把**

Why: Disposal 把. [[Mandarin Chinese#^zh-Q0596|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E6%83%B3%E4%BB%96%E5%BE%97%E8%8A%B1%E5%85%A9%E5%80%8B%E5%B0%8F%E6%99%82%E6%89%8D%E8%83%BD%E6%8A%8A%E5%B7%A5%E4%BD%9C%E5%81%9A%E5%AE%8C%E3%80%82)
^zh-Q0596-answer

**zh-Q0597** — 我並不打算把結果告訴你。

I have no intention of telling you the result.

Expected form: **把**

Why: Disposal 把. [[Mandarin Chinese#^zh-Q0597|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E4%B8%A6%E4%B8%8D%E6%89%93%E7%AE%97%E6%8A%8A%E7%B5%90%E6%9E%9C%E5%91%8A%E8%A8%B4%E4%BD%A0%E3%80%82)
^zh-Q0597-answer

**zh-Q0598** — 我並不打算把結果告訴你。

I have no intention of telling you the result.

Why: Disposal 把. [[Mandarin Chinese#^zh-Q0598|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E4%B8%A6%E4%B8%8D%E6%89%93%E7%AE%97%E6%8A%8A%E7%B5%90%E6%9E%9C%E5%91%8A%E8%A8%B4%E4%BD%A0%E3%80%82)
^zh-Q0598-answer

**zh-Q0599** — 他把梯子倚著柵欄放。

He placed the ladder against the fence.

Why: Disposal 把. [[Mandarin Chinese#^zh-Q0599|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%96%E6%8A%8A%E6%A2%AF%E5%AD%90%E5%80%9A%E8%91%97%E6%9F%B5%E6%AC%84%E6%94%BE%E3%80%82)
^zh-Q0599-answer

**zh-Q0600** — 他把梯子倚著柵欄放。

He placed the ladder against the fence.

A 把 construction places a disposal-affected object before the verb. It commonly needs a suitably specific object and a predicate describing its handling/result. 把 is also a classifier in other contexts.

Why: Disposal 把. [[Mandarin Chinese#^zh-Q0600|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%96%E6%8A%8A%E6%A2%AF%E5%AD%90%E5%80%9A%E8%91%97%E6%9F%B5%E6%AC%84%E6%94%BE%E3%80%82)
^zh-Q0600-answer


### Answers 601–650

**zh-Q0601** — 道路法规必须被严格遵守。

The rule of the road must be strictly observed.

Expected form: **被**

Why: Passive 被. [[Mandarin Chinese#^zh-Q0601|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E9%81%93%E8%B7%AF%E6%B3%95%E8%A7%84%E5%BF%85%E9%A1%BB%E8%A2%AB%E4%B8%A5%E6%A0%BC%E9%81%B5%E5%AE%88%E3%80%82)
^zh-Q0601-answer

**zh-Q0602** — 道路法规必须被严格遵守。

The rule of the road must be strictly observed.

Expected form: **被**

Why: Passive 被. [[Mandarin Chinese#^zh-Q0602|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E9%81%93%E8%B7%AF%E6%B3%95%E8%A7%84%E5%BF%85%E9%A1%BB%E8%A2%AB%E4%B8%A5%E6%A0%BC%E9%81%B5%E5%AE%88%E3%80%82)
^zh-Q0602-answer

**zh-Q0603** — 人类登上月球、柏林墙倒下，世界被我们的科学和想像被连接在一起。

A man touched down on the moon. A wall came down in Berlin. A world was connected by our own science and imagination.

Expected form: **被**

Why: Passive 被. [[Mandarin Chinese#^zh-Q0603|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BA%BA%E7%B1%BB%E7%99%BB%E4%B8%8A%E6%9C%88%E7%90%83%E3%80%81%E6%9F%8F%E6%9E%97%E5%A2%99%E5%80%92%E4%B8%8B%EF%BC%8C%E4%B8%96%E7%95%8C%E8%A2%AB%E6%88%91%E4%BB%AC%E7%9A%84%E7%A7%91%E5%AD%A6%E5%92%8C%E6%83%B3%E5%83%8F%E8%A2%AB%E8%BF%9E%E6%8E%A5%E5%9C%A8%E4%B8%80%E8%B5%B7%E3%80%82)
^zh-Q0603-answer

**zh-Q0604** — 人类登上月球、柏林墙倒下，世界被我们的科学和想像被连接在一起。

A man touched down on the moon. A wall came down in Berlin. A world was connected by our own science and imagination.

Why: Passive 被. [[Mandarin Chinese#^zh-Q0604|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BA%BA%E7%B1%BB%E7%99%BB%E4%B8%8A%E6%9C%88%E7%90%83%E3%80%81%E6%9F%8F%E6%9E%97%E5%A2%99%E5%80%92%E4%B8%8B%EF%BC%8C%E4%B8%96%E7%95%8C%E8%A2%AB%E6%88%91%E4%BB%AC%E7%9A%84%E7%A7%91%E5%AD%A6%E5%92%8C%E6%83%B3%E5%83%8F%E8%A2%AB%E8%BF%9E%E6%8E%A5%E5%9C%A8%E4%B8%80%E8%B5%B7%E3%80%82)
^zh-Q0604-answer

**zh-Q0605** — 這本小說已被翻譯成多國語言。

The novel has been translated into many languages.

Why: Passive 被. [[Mandarin Chinese#^zh-Q0605|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E9%80%99%E6%9C%AC%E5%B0%8F%E8%AA%AA%E5%B7%B2%E8%A2%AB%E7%BF%BB%E8%AD%AF%E6%88%90%E5%A4%9A%E5%9C%8B%E8%AA%9E%E8%A8%80%E3%80%82)
^zh-Q0605-answer

**zh-Q0606** — 這本小說已被翻譯成多國語言。

The novel has been translated into many languages.

被 introduces a passive-like affected-participant construction. The agent can be expressed or omitted. Passive meaning does not automatically imply the same word order as English.

Why: Passive 被. [[Mandarin Chinese#^zh-Q0606|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E9%80%99%E6%9C%AC%E5%B0%8F%E8%AA%AA%E5%B7%B2%E8%A2%AB%E7%BF%BB%E8%AD%AF%E6%88%90%E5%A4%9A%E5%9C%8B%E8%AA%9E%E8%A8%80%E3%80%82)
^zh-Q0606-answer

**zh-Q0607** — 这水被石油污染了。

This water was polluted by oil.

Expected form: **被**

Why: Passive 被. [[Mandarin Chinese#^zh-Q0607|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%BF%99%E6%B0%B4%E8%A2%AB%E7%9F%B3%E6%B2%B9%E6%B1%A1%E6%9F%93%E4%BA%86%E3%80%82)
^zh-Q0607-answer

**zh-Q0608** — 这水被石油污染了。

This water was polluted by oil.

Expected form: **被**

Why: Passive 被. [[Mandarin Chinese#^zh-Q0608|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%BF%99%E6%B0%B4%E8%A2%AB%E7%9F%B3%E6%B2%B9%E6%B1%A1%E6%9F%93%E4%BA%86%E3%80%82)
^zh-Q0608-answer

**zh-Q0609** — Tom被蛇咬到了。

Tom was bitten by a snake.

Expected form: **被**

Why: Passive 被. [[Mandarin Chinese#^zh-Q0609|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=Tom%E8%A2%AB%E8%9B%87%E5%92%AC%E5%88%B0%E4%BA%86%E3%80%82)
^zh-Q0609-answer

**zh-Q0610** — Tom被蛇咬到了。

Tom was bitten by a snake.

Why: Passive 被. [[Mandarin Chinese#^zh-Q0610|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=Tom%E8%A2%AB%E8%9B%87%E5%92%AC%E5%88%B0%E4%BA%86%E3%80%82)
^zh-Q0610-answer

**zh-Q0611** — 我刚刚被蚊子咬了。

I just got bitten by a mosquito.

Why: Passive 被. [[Mandarin Chinese#^zh-Q0611|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E5%88%9A%E5%88%9A%E8%A2%AB%E8%9A%8A%E5%AD%90%E5%92%AC%E4%BA%86%E3%80%82)
^zh-Q0611-answer

**zh-Q0612** — 我刚刚被蚊子咬了。

I just got bitten by a mosquito.

被 introduces a passive-like affected-participant construction. The agent can be expressed or omitted. Passive meaning does not automatically imply the same word order as English.

Why: Passive 被. [[Mandarin Chinese#^zh-Q0612|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E5%88%9A%E5%88%9A%E8%A2%AB%E8%9A%8A%E5%AD%90%E5%92%AC%E4%BA%86%E3%80%82)
^zh-Q0612-answer

**zh-Q0613** — 侵略者注定要被打败。

The aggressors are bound to be defeated.

Expected form: **被**

Why: Passive 被. [[Mandarin Chinese#^zh-Q0613|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BE%B5%E7%95%A5%E8%80%85%E6%B3%A8%E5%AE%9A%E8%A6%81%E8%A2%AB%E6%89%93%E8%B4%A5%E3%80%82)
^zh-Q0613-answer

**zh-Q0614** — 侵略者注定要被打败。

The aggressors are bound to be defeated.

Expected form: **被**

Why: Passive 被. [[Mandarin Chinese#^zh-Q0614|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BE%B5%E7%95%A5%E8%80%85%E6%B3%A8%E5%AE%9A%E8%A6%81%E8%A2%AB%E6%89%93%E8%B4%A5%E3%80%82)
^zh-Q0614-answer

**zh-Q0615** — 觀光客被獨特的景致所吸引。

The tourists were fascinated with the exquisite scenery.

Expected form: **被**

Why: Passive 被. [[Mandarin Chinese#^zh-Q0615|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%A7%80%E5%85%89%E5%AE%A2%E8%A2%AB%E7%8D%A8%E7%89%B9%E7%9A%84%E6%99%AF%E8%87%B4%E6%89%80%E5%90%B8%E5%BC%95%E3%80%82)
^zh-Q0615-answer

**zh-Q0616** — 觀光客被獨特的景致所吸引。

The tourists were fascinated with the exquisite scenery.

Why: Passive 被. [[Mandarin Chinese#^zh-Q0616|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%A7%80%E5%85%89%E5%AE%A2%E8%A2%AB%E7%8D%A8%E7%89%B9%E7%9A%84%E6%99%AF%E8%87%B4%E6%89%80%E5%90%B8%E5%BC%95%E3%80%82)
^zh-Q0616-answer

**zh-Q0617** — 當水被加熱時，水汽蒸發。

Water evaporates when it is heated.

Why: Passive 被. [[Mandarin Chinese#^zh-Q0617|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E7%95%B6%E6%B0%B4%E8%A2%AB%E5%8A%A0%E7%86%B1%E6%99%82%EF%BC%8C%E6%B0%B4%E6%B1%BD%E8%92%B8%E7%99%BC%E3%80%82)
^zh-Q0617-answer

**zh-Q0618** — 當水被加熱時，水汽蒸發。

Water evaporates when it is heated.

被 introduces a passive-like affected-participant construction. The agent can be expressed or omitted. Passive meaning does not automatically imply the same word order as English.

Why: Passive 被. [[Mandarin Chinese#^zh-Q0618|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E7%95%B6%E6%B0%B4%E8%A2%AB%E5%8A%A0%E7%86%B1%E6%99%82%EF%BC%8C%E6%B0%B4%E6%B1%BD%E8%92%B8%E7%99%BC%E3%80%82)
^zh-Q0618-answer

**zh-Q0619** — 我无法不去想被偷掉的钱。

I cannot stop thinking of the stolen money.

Expected form: **被**

Why: Passive 被. [[Mandarin Chinese#^zh-Q0619|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E6%97%A0%E6%B3%95%E4%B8%8D%E5%8E%BB%E6%83%B3%E8%A2%AB%E5%81%B7%E6%8E%89%E7%9A%84%E9%92%B1%E3%80%82)
^zh-Q0619-answer

**zh-Q0620** — 我无法不去想被偷掉的钱。

I cannot stop thinking of the stolen money.

Expected form: **被**

Why: Passive 被. [[Mandarin Chinese#^zh-Q0620|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E6%97%A0%E6%B3%95%E4%B8%8D%E5%8E%BB%E6%83%B3%E8%A2%AB%E5%81%B7%E6%8E%89%E7%9A%84%E9%92%B1%E3%80%82)
^zh-Q0620-answer

**zh-Q0621** — 他因酒後駕駛而被捕。

He was arrested for drunken driving.

Expected form: **被**

Why: Passive 被. [[Mandarin Chinese#^zh-Q0621|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%96%E5%9B%A0%E9%85%92%E5%BE%8C%E9%A7%95%E9%A7%9B%E8%80%8C%E8%A2%AB%E6%8D%95%E3%80%82)
^zh-Q0621-answer

**zh-Q0622** — 他因酒後駕駛而被捕。

He was arrested for drunken driving.

Why: Passive 被. [[Mandarin Chinese#^zh-Q0622|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%96%E5%9B%A0%E9%85%92%E5%BE%8C%E9%A7%95%E9%A7%9B%E8%80%8C%E8%A2%AB%E6%8D%95%E3%80%82)
^zh-Q0622-answer

**zh-Q0623** — 愛和被愛是人生最大的樂事。

To love and to be loved is the greatest happiness.

Why: Passive 被. [[Mandarin Chinese#^zh-Q0623|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%84%9B%E5%92%8C%E8%A2%AB%E6%84%9B%E6%98%AF%E4%BA%BA%E7%94%9F%E6%9C%80%E5%A4%A7%E7%9A%84%E6%A8%82%E4%BA%8B%E3%80%82)
^zh-Q0623-answer

**zh-Q0624** — 愛和被愛是人生最大的樂事。

To love and to be loved is the greatest happiness.

被 introduces a passive-like affected-participant construction. The agent can be expressed or omitted. Passive meaning does not automatically imply the same word order as English.

Why: Passive 被. [[Mandarin Chinese#^zh-Q0624|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%84%9B%E5%92%8C%E8%A2%AB%E6%84%9B%E6%98%AF%E4%BA%BA%E7%94%9F%E6%9C%80%E5%A4%A7%E7%9A%84%E6%A8%82%E4%BA%8B%E3%80%82)
^zh-Q0624-answer

**zh-Q0625** — 除了我每個人都被邀請了。

Everyone was invited, except for me.

Expected form: **被**

Why: Passive 被. [[Mandarin Chinese#^zh-Q0625|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E9%99%A4%E4%BA%86%E6%88%91%E6%AF%8F%E5%80%8B%E4%BA%BA%E9%83%BD%E8%A2%AB%E9%82%80%E8%AB%8B%E4%BA%86%E3%80%82)
^zh-Q0625-answer

**zh-Q0626** — 除了我每個人都被邀請了。

Everyone was invited, except for me.

Expected form: **被**

Why: Passive 被. [[Mandarin Chinese#^zh-Q0626|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E9%99%A4%E4%BA%86%E6%88%91%E6%AF%8F%E5%80%8B%E4%BA%BA%E9%83%BD%E8%A2%AB%E9%82%80%E8%AB%8B%E4%BA%86%E3%80%82)
^zh-Q0626-answer

**zh-Q0627** — 上海被称为东方的巴黎。

Shanghai is referred to as the Paris of the East.

Expected form: **被**

Why: Passive 被. [[Mandarin Chinese#^zh-Q0627|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%B8%8A%E6%B5%B7%E8%A2%AB%E7%A7%B0%E4%B8%BA%E4%B8%9C%E6%96%B9%E7%9A%84%E5%B7%B4%E9%BB%8E%E3%80%82)
^zh-Q0627-answer

**zh-Q0628** — 上海被称为东方的巴黎。

Shanghai is referred to as the Paris of the East.

Why: Passive 被. [[Mandarin Chinese#^zh-Q0628|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%B8%8A%E6%B5%B7%E8%A2%AB%E7%A7%B0%E4%B8%BA%E4%B8%9C%E6%96%B9%E7%9A%84%E5%B7%B4%E9%BB%8E%E3%80%82)
^zh-Q0628-answer

**zh-Q0629** — 被判严重违反新的行为准则的青少年将失去免费乘坐公交车的权利，如果想重新取得必须做无报酬的社区工作。

Youths who are caught violating the new rules on behaviour will lose their right to free travel, and will have to complete unpaid community work to earn it back.

Why: Passive 被. [[Mandarin Chinese#^zh-Q0629|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%A2%AB%E5%88%A4%E4%B8%A5%E9%87%8D%E8%BF%9D%E5%8F%8D%E6%96%B0%E7%9A%84%E8%A1%8C%E4%B8%BA%E5%87%86%E5%88%99%E7%9A%84%E9%9D%92%E5%B0%91%E5%B9%B4%E5%B0%86%E5%A4%B1%E5%8E%BB%E5%85%8D%E8%B4%B9%E4%B9%98%E5%9D%90%E5%85%AC%E4%BA%A4%E8%BD%A6%E7%9A%84%E6%9D%83%E5%88%A9%EF%BC%8C%E5%A6%82%E6%9E%9C%E6%83%B3%E9%87%8D%E6%96%B0%E5%8F%96%E5%BE%97%E5%BF%85%E9%A1%BB%E5%81%9A%E6%97%A0%E6%8A%A5%E9%85%AC%E7%9A%84%E7%A4%BE%E5%8C%BA%E5%B7%A5%E4%BD%9C%E3%80%82)
^zh-Q0629-answer

**zh-Q0630** — 被判严重违反新的行为准则的青少年将失去免费乘坐公交车的权利，如果想重新取得必须做无报酬的社区工作。

Youths who are caught violating the new rules on behaviour will lose their right to free travel, and will have to complete unpaid community work to earn it back.

被 introduces a passive-like affected-participant construction. The agent can be expressed or omitted. Passive meaning does not automatically imply the same word order as English.

Why: Passive 被. [[Mandarin Chinese#^zh-Q0630|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%A2%AB%E5%88%A4%E4%B8%A5%E9%87%8D%E8%BF%9D%E5%8F%8D%E6%96%B0%E7%9A%84%E8%A1%8C%E4%B8%BA%E5%87%86%E5%88%99%E7%9A%84%E9%9D%92%E5%B0%91%E5%B9%B4%E5%B0%86%E5%A4%B1%E5%8E%BB%E5%85%8D%E8%B4%B9%E4%B9%98%E5%9D%90%E5%85%AC%E4%BA%A4%E8%BD%A6%E7%9A%84%E6%9D%83%E5%88%A9%EF%BC%8C%E5%A6%82%E6%9E%9C%E6%83%B3%E9%87%8D%E6%96%B0%E5%8F%96%E5%BE%97%E5%BF%85%E9%A1%BB%E5%81%9A%E6%97%A0%E6%8A%A5%E9%85%AC%E7%9A%84%E7%A4%BE%E5%8C%BA%E5%B7%A5%E4%BD%9C%E3%80%82)
^zh-Q0630-answer

**zh-Q0631** — 我的腳踏車被偷了。

My bike is stolen.

Expected form: **被**

Why: Passive 被. [[Mandarin Chinese#^zh-Q0631|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E7%9A%84%E8%85%B3%E8%B8%8F%E8%BB%8A%E8%A2%AB%E5%81%B7%E4%BA%86%E3%80%82)
^zh-Q0631-answer

**zh-Q0632** — 我的腳踏車被偷了。

My bike is stolen.

Expected form: **被**

Why: Passive 被. [[Mandarin Chinese#^zh-Q0632|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E7%9A%84%E8%85%B3%E8%B8%8F%E8%BB%8A%E8%A2%AB%E5%81%B7%E4%BA%86%E3%80%82)
^zh-Q0632-answer

**zh-Q0633** — 他常常被誤認為是個學生。

He's often mistaken for a student.

Expected form: **被**

Why: Passive 被. [[Mandarin Chinese#^zh-Q0633|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%96%E5%B8%B8%E5%B8%B8%E8%A2%AB%E8%AA%A4%E8%AA%8D%E7%82%BA%E6%98%AF%E5%80%8B%E5%AD%B8%E7%94%9F%E3%80%82)
^zh-Q0633-answer

**zh-Q0634** — 他常常被誤認為是個學生。

He's often mistaken for a student.

Why: Passive 被. [[Mandarin Chinese#^zh-Q0634|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%96%E5%B8%B8%E5%B8%B8%E8%A2%AB%E8%AA%A4%E8%AA%8D%E7%82%BA%E6%98%AF%E5%80%8B%E5%AD%B8%E7%94%9F%E3%80%82)
^zh-Q0634-answer

**zh-Q0635** — 人們被記得不是因失敗的次數，而是成功的次數。

People are not remembered by the number of times they fail but for the number of times they succeed.

Why: Passive 被. [[Mandarin Chinese#^zh-Q0635|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BA%BA%E5%80%91%E8%A2%AB%E8%A8%98%E5%BE%97%E4%B8%8D%E6%98%AF%E5%9B%A0%E5%A4%B1%E6%95%97%E7%9A%84%E6%AC%A1%E6%95%B8%EF%BC%8C%E8%80%8C%E6%98%AF%E6%88%90%E5%8A%9F%E7%9A%84%E6%AC%A1%E6%95%B8%E3%80%82)
^zh-Q0635-answer

**zh-Q0636** — 人們被記得不是因失敗的次數，而是成功的次數。

People are not remembered by the number of times they fail but for the number of times they succeed.

被 introduces a passive-like affected-participant construction. The agent can be expressed or omitted. Passive meaning does not automatically imply the same word order as English.

Why: Passive 被. [[Mandarin Chinese#^zh-Q0636|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BA%BA%E5%80%91%E8%A2%AB%E8%A8%98%E5%BE%97%E4%B8%8D%E6%98%AF%E5%9B%A0%E5%A4%B1%E6%95%97%E7%9A%84%E6%AC%A1%E6%95%B8%EF%BC%8C%E8%80%8C%E6%98%AF%E6%88%90%E5%8A%9F%E7%9A%84%E6%AC%A1%E6%95%B8%E3%80%82)
^zh-Q0636-answer

**zh-Q0637** — 燕大侠发现自己被骗了他飞到了江枫的旁边，他抱走江枫的儿子。燕大侠誓言报复，他把男孩给了一个香料商人。

Yan Daxia realised he had been lied to and flew to Jiang Feng's side. He took Jiang Feng's son and left. Yan Daxia vowed revenge and left the boy with a spice merchant.

Expected form: **被**

Why: Passive 被. [[Mandarin Chinese#^zh-Q0637|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E7%87%95%E5%A4%A7%E4%BE%A0%E5%8F%91%E7%8E%B0%E8%87%AA%E5%B7%B1%E8%A2%AB%E9%AA%97%E4%BA%86%E4%BB%96%E9%A3%9E%E5%88%B0%E4%BA%86%E6%B1%9F%E6%9E%AB%E7%9A%84%E6%97%81%E8%BE%B9%EF%BC%8C%E4%BB%96%E6%8A%B1%E8%B5%B0%E6%B1%9F%E6%9E%AB%E7%9A%84%E5%84%BF%E5%AD%90%E3%80%82%E7%87%95%E5%A4%A7%E4%BE%A0%E8%AA%93%E8%A8%80%E6%8A%A5%E5%A4%8D%EF%BC%8C%E4%BB%96%E6%8A%8A%E7%94%B7%E5%AD%A9%E7%BB%99%E4%BA%86%E4%B8%80%E4%B8%AA%E9%A6%99%E6%96%99%E5%95%86%E4%BA%BA%E3%80%82)
^zh-Q0637-answer

**zh-Q0638** — 燕大侠发现自己被骗了他飞到了江枫的旁边，他抱走江枫的儿子。燕大侠誓言报复，他把男孩给了一个香料商人。

Yan Daxia realised he had been lied to and flew to Jiang Feng's side. He took Jiang Feng's son and left. Yan Daxia vowed revenge and left the boy with a spice merchant.

Expected form: **被**

Why: Passive 被. [[Mandarin Chinese#^zh-Q0638|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E7%87%95%E5%A4%A7%E4%BE%A0%E5%8F%91%E7%8E%B0%E8%87%AA%E5%B7%B1%E8%A2%AB%E9%AA%97%E4%BA%86%E4%BB%96%E9%A3%9E%E5%88%B0%E4%BA%86%E6%B1%9F%E6%9E%AB%E7%9A%84%E6%97%81%E8%BE%B9%EF%BC%8C%E4%BB%96%E6%8A%B1%E8%B5%B0%E6%B1%9F%E6%9E%AB%E7%9A%84%E5%84%BF%E5%AD%90%E3%80%82%E7%87%95%E5%A4%A7%E4%BE%A0%E8%AA%93%E8%A8%80%E6%8A%A5%E5%A4%8D%EF%BC%8C%E4%BB%96%E6%8A%8A%E7%94%B7%E5%AD%A9%E7%BB%99%E4%BA%86%E4%B8%80%E4%B8%AA%E9%A6%99%E6%96%99%E5%95%86%E4%BA%BA%E3%80%82)
^zh-Q0638-answer

**zh-Q0639** — 否则，用左手传递食物会被认为是不礼貌的，因为左手是用来洗澡的。

Otherwise, it is considered impolite to pass food with the left hand, because the left hand is used for bathing.

Expected form: **被**

Why: Passive 被. [[Mandarin Chinese#^zh-Q0639|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%90%A6%E5%88%99%EF%BC%8C%E7%94%A8%E5%B7%A6%E6%89%8B%E4%BC%A0%E9%80%92%E9%A3%9F%E7%89%A9%E4%BC%9A%E8%A2%AB%E8%AE%A4%E4%B8%BA%E6%98%AF%E4%B8%8D%E7%A4%BC%E8%B2%8C%E7%9A%84%EF%BC%8C%E5%9B%A0%E4%B8%BA%E5%B7%A6%E6%89%8B%E6%98%AF%E7%94%A8%E6%9D%A5%E6%B4%97%E6%BE%A1%E7%9A%84%E3%80%82)
^zh-Q0639-answer

**zh-Q0640** — 否则，用左手传递食物会被认为是不礼貌的，因为左手是用来洗澡的。

Otherwise, it is considered impolite to pass food with the left hand, because the left hand is used for bathing.

Why: Passive 被. [[Mandarin Chinese#^zh-Q0640|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%90%A6%E5%88%99%EF%BC%8C%E7%94%A8%E5%B7%A6%E6%89%8B%E4%BC%A0%E9%80%92%E9%A3%9F%E7%89%A9%E4%BC%9A%E8%A2%AB%E8%AE%A4%E4%B8%BA%E6%98%AF%E4%B8%8D%E7%A4%BC%E8%B2%8C%E7%9A%84%EF%BC%8C%E5%9B%A0%E4%B8%BA%E5%B7%A6%E6%89%8B%E6%98%AF%E7%94%A8%E6%9D%A5%E6%B4%97%E6%BE%A1%E7%9A%84%E3%80%82)
^zh-Q0640-answer

**zh-Q0641** — 他被她的笑容吸引住了。

He was attracted by her smile.

Why: Passive 被. [[Mandarin Chinese#^zh-Q0641|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%96%E8%A2%AB%E5%A5%B9%E7%9A%84%E7%AC%91%E5%AE%B9%E5%90%B8%E5%BC%95%E4%BD%8F%E4%BA%86%E3%80%82)
^zh-Q0641-answer

**zh-Q0642** — 他被她的笑容吸引住了。

He was attracted by her smile.

被 introduces a passive-like affected-participant construction. The agent can be expressed or omitted. Passive meaning does not automatically imply the same word order as English.

Why: Passive 被. [[Mandarin Chinese#^zh-Q0642|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%96%E8%A2%AB%E5%A5%B9%E7%9A%84%E7%AC%91%E5%AE%B9%E5%90%B8%E5%BC%95%E4%BD%8F%E4%BA%86%E3%80%82)
^zh-Q0642-answer

**zh-Q0643** — 就算我的家發生火災，也會很快就被撲熄的。

Even if my house catches fire it would soon be put out.

Expected form: **被**

Why: Passive 被. [[Mandarin Chinese#^zh-Q0643|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%B0%B1%E7%AE%97%E6%88%91%E7%9A%84%E5%AE%B6%E7%99%BC%E7%94%9F%E7%81%AB%E7%81%BD%EF%BC%8C%E4%B9%9F%E6%9C%83%E5%BE%88%E5%BF%AB%E5%B0%B1%E8%A2%AB%E6%92%B2%E7%86%84%E7%9A%84%E3%80%82)
^zh-Q0643-answer

**zh-Q0644** — 就算我的家發生火災，也會很快就被撲熄的。

Even if my house catches fire it would soon be put out.

Expected form: **被**

Why: Passive 被. [[Mandarin Chinese#^zh-Q0644|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%B0%B1%E7%AE%97%E6%88%91%E7%9A%84%E5%AE%B6%E7%99%BC%E7%94%9F%E7%81%AB%E7%81%BD%EF%BC%8C%E4%B9%9F%E6%9C%83%E5%BE%88%E5%BF%AB%E5%B0%B1%E8%A2%AB%E6%92%B2%E7%86%84%E7%9A%84%E3%80%82)
^zh-Q0644-answer

**zh-Q0645** — 好几间小屋被洪水孤立起来了。

Several cottages have been isolated by the flood water.

Expected form: **被**

Why: Passive 被. [[Mandarin Chinese#^zh-Q0645|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A5%BD%E5%87%A0%E9%97%B4%E5%B0%8F%E5%B1%8B%E8%A2%AB%E6%B4%AA%E6%B0%B4%E5%AD%A4%E7%AB%8B%E8%B5%B7%E6%9D%A5%E4%BA%86%E3%80%82)
^zh-Q0645-answer

**zh-Q0646** — 好几间小屋被洪水孤立起来了。

Several cottages have been isolated by the flood water.

Why: Passive 被. [[Mandarin Chinese#^zh-Q0646|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A5%BD%E5%87%A0%E9%97%B4%E5%B0%8F%E5%B1%8B%E8%A2%AB%E6%B4%AA%E6%B0%B4%E5%AD%A4%E7%AB%8B%E8%B5%B7%E6%9D%A5%E4%BA%86%E3%80%82)
^zh-Q0646-answer

**zh-Q0647** — 他差點被一輛汽車撞上了。

He was almost hit by a car.

Why: Passive 被. [[Mandarin Chinese#^zh-Q0647|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%96%E5%B7%AE%E9%BB%9E%E8%A2%AB%E4%B8%80%E8%BC%9B%E6%B1%BD%E8%BB%8A%E6%92%9E%E4%B8%8A%E4%BA%86%E3%80%82)
^zh-Q0647-answer

**zh-Q0648** — 他差點被一輛汽車撞上了。

He was almost hit by a car.

被 introduces a passive-like affected-participant construction. The agent can be expressed or omitted. Passive meaning does not automatically imply the same word order as English.

Why: Passive 被. [[Mandarin Chinese#^zh-Q0648|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%96%E5%B7%AE%E9%BB%9E%E8%A2%AB%E4%B8%80%E8%BC%9B%E6%B1%BD%E8%BB%8A%E6%92%9E%E4%B8%8A%E4%BA%86%E3%80%82)
^zh-Q0648-answer

**zh-Q0649** — 他被任命為駐英國大使。

He was appointed ambassador to Britain.

Expected form: **被**

Why: Passive 被. [[Mandarin Chinese#^zh-Q0649|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%96%E8%A2%AB%E4%BB%BB%E5%91%BD%E7%82%BA%E9%A7%90%E8%8B%B1%E5%9C%8B%E5%A4%A7%E4%BD%BF%E3%80%82)
^zh-Q0649-answer

**zh-Q0650** — 他被任命為駐英國大使。

He was appointed ambassador to Britain.

Expected form: **被**

Why: Passive 被. [[Mandarin Chinese#^zh-Q0650|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%96%E8%A2%AB%E4%BB%BB%E5%91%BD%E7%82%BA%E9%A7%90%E8%8B%B1%E5%9C%8B%E5%A4%A7%E4%BD%BF%E3%80%82)
^zh-Q0650-answer


### Answers 651–700

**zh-Q0651** — 瑪麗長得像她媽媽。

Mary looks like her mother.

Expected form: **得**

Why: Result and degree 得. [[Mandarin Chinese#^zh-Q0651|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E7%91%AA%E9%BA%97%E9%95%B7%E5%BE%97%E5%83%8F%E5%A5%B9%E5%AA%BD%E5%AA%BD%E3%80%82)
^zh-Q0651-answer

**zh-Q0652** — 瑪麗長得像她媽媽。

Mary looks like her mother.

Why: Result and degree 得. [[Mandarin Chinese#^zh-Q0652|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E7%91%AA%E9%BA%97%E9%95%B7%E5%BE%97%E5%83%8F%E5%A5%B9%E5%AA%BD%E5%AA%BD%E3%80%82)
^zh-Q0652-answer

**zh-Q0653** — 他晚上回來得很晚。

He returned very late at night.

Why: Result and degree 得. [[Mandarin Chinese#^zh-Q0653|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%96%E6%99%9A%E4%B8%8A%E5%9B%9E%E4%BE%86%E5%BE%97%E5%BE%88%E6%99%9A%E3%80%82)
^zh-Q0653-answer

**zh-Q0654** — 他晚上回來得很晚。

He returned very late at night.

得 can introduce degree/manner complements after a verb; it also occurs in potential and lexical constructions. A complement may require repeating a verb when an object is present.

Why: Result and degree 得. [[Mandarin Chinese#^zh-Q0654|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%96%E6%99%9A%E4%B8%8A%E5%9B%9E%E4%BE%86%E5%BE%97%E5%BE%88%E6%99%9A%E3%80%82)
^zh-Q0654-answer

**zh-Q0655** — 女人往往比男人活得更長。

Women tend to live longer than men.

Expected form: **得**

Why: Result and degree 得. [[Mandarin Chinese#^zh-Q0655|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A5%B3%E4%BA%BA%E5%BE%80%E5%BE%80%E6%AF%94%E7%94%B7%E4%BA%BA%E6%B4%BB%E5%BE%97%E6%9B%B4%E9%95%B7%E3%80%82)
^zh-Q0655-answer

**zh-Q0656** — 女人往往比男人活得更長。

Women tend to live longer than men.

Expected form: **得**

Why: Result and degree 得. [[Mandarin Chinese#^zh-Q0656|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A5%B3%E4%BA%BA%E5%BE%80%E5%BE%80%E6%AF%94%E7%94%B7%E4%BA%BA%E6%B4%BB%E5%BE%97%E6%9B%B4%E9%95%B7%E3%80%82)
^zh-Q0656-answer

**zh-Q0657** — 我在医院的任期完全记得，为什么你没有想起我。

My appointment at the hospital completely slipped my mind. Why didn't you remind me?

Expected form: **得**

Why: Result and degree 得. [[Mandarin Chinese#^zh-Q0657|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E5%9C%A8%E5%8C%BB%E9%99%A2%E7%9A%84%E4%BB%BB%E6%9C%9F%E5%AE%8C%E5%85%A8%E8%AE%B0%E5%BE%97%EF%BC%8C%E4%B8%BA%E4%BB%80%E4%B9%88%E4%BD%A0%E6%B2%A1%E6%9C%89%E6%83%B3%E8%B5%B7%E6%88%91%E3%80%82)
^zh-Q0657-answer

**zh-Q0658** — 我在医院的任期完全记得，为什么你没有想起我。

My appointment at the hospital completely slipped my mind. Why didn't you remind me?

Why: Result and degree 得. [[Mandarin Chinese#^zh-Q0658|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E5%9C%A8%E5%8C%BB%E9%99%A2%E7%9A%84%E4%BB%BB%E6%9C%9F%E5%AE%8C%E5%85%A8%E8%AE%B0%E5%BE%97%EF%BC%8C%E4%B8%BA%E4%BB%80%E4%B9%88%E4%BD%A0%E6%B2%A1%E6%9C%89%E6%83%B3%E8%B5%B7%E6%88%91%E3%80%82)
^zh-Q0658-answer

**zh-Q0659** — 我們得體諒她年輕。

We should take into account she is still young.

Why: Result and degree 得. [[Mandarin Chinese#^zh-Q0659|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E5%80%91%E5%BE%97%E9%AB%94%E8%AB%92%E5%A5%B9%E5%B9%B4%E8%BC%95%E3%80%82)
^zh-Q0659-answer

**zh-Q0660** — 我們得體諒她年輕。

We should take into account she is still young.

得 can introduce degree/manner complements after a verb; it also occurs in potential and lexical constructions. A complement may require repeating a verb when an object is present.

Why: Result and degree 得. [[Mandarin Chinese#^zh-Q0660|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E5%80%91%E5%BE%97%E9%AB%94%E8%AB%92%E5%A5%B9%E5%B9%B4%E8%BC%95%E3%80%82)
^zh-Q0660-answer

**zh-Q0661** — 春天大家起得都很早。

In spring, everyone wakes up early.

Expected form: **得**

Why: Result and degree 得. [[Mandarin Chinese#^zh-Q0661|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%98%A5%E5%A4%A9%E5%A4%A7%E5%AE%B6%E8%B5%B7%E5%BE%97%E9%83%BD%E5%BE%88%E6%97%A9%E3%80%82)
^zh-Q0661-answer

**zh-Q0662** — 春天大家起得都很早。

In spring, everyone wakes up early.

Expected form: **得**

Why: Result and degree 得. [[Mandarin Chinese#^zh-Q0662|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%98%A5%E5%A4%A9%E5%A4%A7%E5%AE%B6%E8%B5%B7%E5%BE%97%E9%83%BD%E5%BE%88%E6%97%A9%E3%80%82)
^zh-Q0662-answer

**zh-Q0663** — 今天晚上我玩得很開心。

I had a good time this evening.

Expected form: **得**

Why: Result and degree 得. [[Mandarin Chinese#^zh-Q0663|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%8A%E5%A4%A9%E6%99%9A%E4%B8%8A%E6%88%91%E7%8E%A9%E5%BE%97%E5%BE%88%E9%96%8B%E5%BF%83%E3%80%82)
^zh-Q0663-answer

**zh-Q0664** — 今天晚上我玩得很開心。

I had a good time this evening.

Why: Result and degree 得. [[Mandarin Chinese#^zh-Q0664|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%8A%E5%A4%A9%E6%99%9A%E4%B8%8A%E6%88%91%E7%8E%A9%E5%BE%97%E5%BE%88%E9%96%8B%E5%BF%83%E3%80%82)
^zh-Q0664-answer

**zh-Q0665** — 亲爱的，记得11点喊我起床工作。

Honey, don't forget to wake me up for work at 11 o'clock.

Why: Result and degree 得. [[Mandarin Chinese#^zh-Q0665|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BA%B2%E7%88%B1%E7%9A%84%EF%BC%8C%E8%AE%B0%E5%BE%9711%E7%82%B9%E5%96%8A%E6%88%91%E8%B5%B7%E5%BA%8A%E5%B7%A5%E4%BD%9C%E3%80%82)
^zh-Q0665-answer

**zh-Q0666** — 亲爱的，记得11点喊我起床工作。

Honey, don't forget to wake me up for work at 11 o'clock.

得 can introduce degree/manner complements after a verb; it also occurs in potential and lexical constructions. A complement may require repeating a verb when an object is present.

Why: Result and degree 得. [[Mandarin Chinese#^zh-Q0666|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BA%B2%E7%88%B1%E7%9A%84%EF%BC%8C%E8%AE%B0%E5%BE%9711%E7%82%B9%E5%96%8A%E6%88%91%E8%B5%B7%E5%BA%8A%E5%B7%A5%E4%BD%9C%E3%80%82)
^zh-Q0666-answer

**zh-Q0667** — 我們已經贏得了這場戰鬥。

We have already won this battle.

Expected form: **得**

Why: Result and degree 得. [[Mandarin Chinese#^zh-Q0667|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E5%80%91%E5%B7%B2%E7%B6%93%E8%B4%8F%E5%BE%97%E4%BA%86%E9%80%99%E5%A0%B4%E6%88%B0%E9%AC%A5%E3%80%82)
^zh-Q0667-answer

**zh-Q0668** — 我們已經贏得了這場戰鬥。

We have already won this battle.

Expected form: **得**

Why: Result and degree 得. [[Mandarin Chinese#^zh-Q0668|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E5%80%91%E5%B7%B2%E7%B6%93%E8%B4%8F%E5%BE%97%E4%BA%86%E9%80%99%E5%A0%B4%E6%88%B0%E9%AC%A5%E3%80%82)
^zh-Q0668-answer

**zh-Q0669** — 我想我現在得走了。

I guess I'll have to leave now.

Expected form: **得**

Why: Result and degree 得. [[Mandarin Chinese#^zh-Q0669|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E6%83%B3%E6%88%91%E7%8F%BE%E5%9C%A8%E5%BE%97%E8%B5%B0%E4%BA%86%E3%80%82)
^zh-Q0669-answer

**zh-Q0670** — 我想我現在得走了。

I guess I'll have to leave now.

Why: Result and degree 得. [[Mandarin Chinese#^zh-Q0670|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E6%83%B3%E6%88%91%E7%8F%BE%E5%9C%A8%E5%BE%97%E8%B5%B0%E4%BA%86%E3%80%82)
^zh-Q0670-answer

**zh-Q0671** — 投资她能判断得很正确。

She can assess investments very accurately.

Why: Result and degree 得. [[Mandarin Chinese#^zh-Q0671|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%8A%95%E8%B5%84%E5%A5%B9%E8%83%BD%E5%88%A4%E6%96%AD%E5%BE%97%E5%BE%88%E6%AD%A3%E7%A1%AE%E3%80%82)
^zh-Q0671-answer

**zh-Q0672** — 投资她能判断得很正确。

She can assess investments very accurately.

得 can introduce degree/manner complements after a verb; it also occurs in potential and lexical constructions. A complement may require repeating a verb when an object is present.

Why: Result and degree 得. [[Mandarin Chinese#^zh-Q0672|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%8A%95%E8%B5%84%E5%A5%B9%E8%83%BD%E5%88%A4%E6%96%AD%E5%BE%97%E5%BE%88%E6%AD%A3%E7%A1%AE%E3%80%82)
^zh-Q0672-answer

**zh-Q0673** — 言歸正傳，事情進展得怎麼樣了？

Joking aside, how are things going?

Expected form: **得**

Why: Result and degree 得. [[Mandarin Chinese#^zh-Q0673|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%A8%80%E6%AD%B8%E6%AD%A3%E5%82%B3%EF%BC%8C%E4%BA%8B%E6%83%85%E9%80%B2%E5%B1%95%E5%BE%97%E6%80%8E%E9%BA%BC%E6%A8%A3%E4%BA%86%EF%BC%9F)
^zh-Q0673-answer

**zh-Q0674** — 言歸正傳，事情進展得怎麼樣了？

Joking aside, how are things going?

Expected form: **得**

Why: Result and degree 得. [[Mandarin Chinese#^zh-Q0674|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%A8%80%E6%AD%B8%E6%AD%A3%E5%82%B3%EF%BC%8C%E4%BA%8B%E6%83%85%E9%80%B2%E5%B1%95%E5%BE%97%E6%80%8E%E9%BA%BC%E6%A8%A3%E4%BA%86%EF%BC%9F)
^zh-Q0674-answer

**zh-Q0675** — 我的記性不好。我簡直不記得他的名字了。

My memory failed me. I just could not remember his name.

Expected form: **得**

Why: Result and degree 得. [[Mandarin Chinese#^zh-Q0675|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E7%9A%84%E8%A8%98%E6%80%A7%E4%B8%8D%E5%A5%BD%E3%80%82%E6%88%91%E7%B0%A1%E7%9B%B4%E4%B8%8D%E8%A8%98%E5%BE%97%E4%BB%96%E7%9A%84%E5%90%8D%E5%AD%97%E4%BA%86%E3%80%82)
^zh-Q0675-answer

**zh-Q0676** — 我的記性不好。我簡直不記得他的名字了。

My memory failed me. I just could not remember his name.

Why: Result and degree 得. [[Mandarin Chinese#^zh-Q0676|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E7%9A%84%E8%A8%98%E6%80%A7%E4%B8%8D%E5%A5%BD%E3%80%82%E6%88%91%E7%B0%A1%E7%9B%B4%E4%B8%8D%E8%A8%98%E5%BE%97%E4%BB%96%E7%9A%84%E5%90%8D%E5%AD%97%E4%BA%86%E3%80%82)
^zh-Q0676-answer

**zh-Q0677** — 你覺得日本怎麼樣？

How do you like Japan?

Why: Result and degree 得. [[Mandarin Chinese#^zh-Q0677|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E8%A6%BA%E5%BE%97%E6%97%A5%E6%9C%AC%E6%80%8E%E9%BA%BC%E6%A8%A3%EF%BC%9F)
^zh-Q0677-answer

**zh-Q0678** — 你覺得日本怎麼樣？

How do you like Japan?

得 can introduce degree/manner complements after a verb; it also occurs in potential and lexical constructions. A complement may require repeating a verb when an object is present.

Why: Result and degree 得. [[Mandarin Chinese#^zh-Q0678|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E8%A6%BA%E5%BE%97%E6%97%A5%E6%9C%AC%E6%80%8E%E9%BA%BC%E6%A8%A3%EF%BC%9F)
^zh-Q0678-answer

**zh-Q0679** — 你不覺得這個名字很諷刺嗎，「神聖的戰爭」？

Don't you think the name "The Sacred War" sounds a bit sarcastic?

Expected form: **得**

Why: Result and degree 得. [[Mandarin Chinese#^zh-Q0679|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E4%B8%8D%E8%A6%BA%E5%BE%97%E9%80%99%E5%80%8B%E5%90%8D%E5%AD%97%E5%BE%88%E8%AB%B7%E5%88%BA%E5%97%8E%EF%BC%8C%E3%80%8C%E7%A5%9E%E8%81%96%E7%9A%84%E6%88%B0%E7%88%AD%E3%80%8D%EF%BC%9F)
^zh-Q0679-answer

**zh-Q0680** — 你不覺得這個名字很諷刺嗎，「神聖的戰爭」？

Don't you think the name "The Sacred War" sounds a bit sarcastic?

Expected form: **得**

Why: Result and degree 得. [[Mandarin Chinese#^zh-Q0680|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E4%B8%8D%E8%A6%BA%E5%BE%97%E9%80%99%E5%80%8B%E5%90%8D%E5%AD%97%E5%BE%88%E8%AB%B7%E5%88%BA%E5%97%8E%EF%BC%8C%E3%80%8C%E7%A5%9E%E8%81%96%E7%9A%84%E6%88%B0%E7%88%AD%E3%80%8D%EF%BC%9F)
^zh-Q0680-answer

**zh-Q0681** — 我記得你。三年前我們見過面。

I remember you. We met three years ago.

Expected form: **得**

Why: Result and degree 得. [[Mandarin Chinese#^zh-Q0681|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E8%A8%98%E5%BE%97%E4%BD%A0%E3%80%82%E4%B8%89%E5%B9%B4%E5%89%8D%E6%88%91%E5%80%91%E8%A6%8B%E9%81%8E%E9%9D%A2%E3%80%82)
^zh-Q0681-answer

**zh-Q0682** — 我記得你。三年前我們見過面。

I remember you. We met three years ago.

Why: Result and degree 得. [[Mandarin Chinese#^zh-Q0682|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E8%A8%98%E5%BE%97%E4%BD%A0%E3%80%82%E4%B8%89%E5%B9%B4%E5%89%8D%E6%88%91%E5%80%91%E8%A6%8B%E9%81%8E%E9%9D%A2%E3%80%82)
^zh-Q0682-answer

**zh-Q0683** — 我和她聊得很愉快。

I had a nice chat with her.

Why: Result and degree 得. [[Mandarin Chinese#^zh-Q0683|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E5%92%8C%E5%A5%B9%E8%81%8A%E5%BE%97%E5%BE%88%E6%84%89%E5%BF%AB%E3%80%82)
^zh-Q0683-answer

**zh-Q0684** — 我和她聊得很愉快。

I had a nice chat with her.

得 can introduce degree/manner complements after a verb; it also occurs in potential and lexical constructions. A complement may require repeating a verb when an object is present.

Why: Result and degree 得. [[Mandarin Chinese#^zh-Q0684|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E5%92%8C%E5%A5%B9%E8%81%8A%E5%BE%97%E5%BE%88%E6%84%89%E5%BF%AB%E3%80%82)
^zh-Q0684-answer

**zh-Q0685** — Sean 和 Conner 長得真像！

Sean really greatly resembles Conner!

Expected form: **得**

Why: Result and degree 得. [[Mandarin Chinese#^zh-Q0685|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=Sean%20%E5%92%8C%20Conner%20%E9%95%B7%E5%BE%97%E7%9C%9F%E5%83%8F%EF%BC%81)
^zh-Q0685-answer

**zh-Q0686** — Sean 和 Conner 長得真像！

Sean really greatly resembles Conner!

Expected form: **得**

Why: Result and degree 得. [[Mandarin Chinese#^zh-Q0686|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=Sean%20%E5%92%8C%20Conner%20%E9%95%B7%E5%BE%97%E7%9C%9F%E5%83%8F%EF%BC%81)
^zh-Q0686-answer

**zh-Q0687** — 我游泳可以游得很好。

I can swim well.

Expected form: **得**

Why: Result and degree 得. [[Mandarin Chinese#^zh-Q0687|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E6%B8%B8%E6%B3%B3%E5%8F%AF%E4%BB%A5%E6%B8%B8%E5%BE%97%E5%BE%88%E5%A5%BD%E3%80%82)
^zh-Q0687-answer

**zh-Q0688** — 我游泳可以游得很好。

I can swim well.

Why: Result and degree 得. [[Mandarin Chinese#^zh-Q0688|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E6%B8%B8%E6%B3%B3%E5%8F%AF%E4%BB%A5%E6%B8%B8%E5%BE%97%E5%BE%88%E5%A5%BD%E3%80%82)
^zh-Q0688-answer

**zh-Q0689** — 我的法语说得不够好。

My French isn't good enough.

Why: Result and degree 得. [[Mandarin Chinese#^zh-Q0689|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E7%9A%84%E6%B3%95%E8%AF%AD%E8%AF%B4%E5%BE%97%E4%B8%8D%E5%A4%9F%E5%A5%BD%E3%80%82)
^zh-Q0689-answer

**zh-Q0690** — 我的法语说得不够好。

My French isn't good enough.

得 can introduce degree/manner complements after a verb; it also occurs in potential and lexical constructions. A complement may require repeating a verb when an object is present.

Why: Result and degree 得. [[Mandarin Chinese#^zh-Q0690|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E7%9A%84%E6%B3%95%E8%AF%AD%E8%AF%B4%E5%BE%97%E4%B8%8D%E5%A4%9F%E5%A5%BD%E3%80%82)
^zh-Q0690-answer

**zh-Q0691** — 你记得这是在哪一年发生的吗？

Do you remember which year it happened?

Expected form: **得**

Why: Result and degree 得. [[Mandarin Chinese#^zh-Q0691|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E8%AE%B0%E5%BE%97%E8%BF%99%E6%98%AF%E5%9C%A8%E5%93%AA%E4%B8%80%E5%B9%B4%E5%8F%91%E7%94%9F%E7%9A%84%E5%90%97%EF%BC%9F)
^zh-Q0691-answer

**zh-Q0692** — 你记得这是在哪一年发生的吗？

Do you remember which year it happened?

Expected form: **得**

Why: Result and degree 得. [[Mandarin Chinese#^zh-Q0692|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E8%AE%B0%E5%BE%97%E8%BF%99%E6%98%AF%E5%9C%A8%E5%93%AA%E4%B8%80%E5%B9%B4%E5%8F%91%E7%94%9F%E7%9A%84%E5%90%97%EF%BC%9F)
^zh-Q0692-answer

**zh-Q0693** — 最後笑的人，才是笑得最得意的人。

He laughs best who laughs last.

Expected form: **得**

Why: Result and degree 得. [[Mandarin Chinese#^zh-Q0693|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%9C%80%E5%BE%8C%E7%AC%91%E7%9A%84%E4%BA%BA%EF%BC%8C%E6%89%8D%E6%98%AF%E7%AC%91%E5%BE%97%E6%9C%80%E5%BE%97%E6%84%8F%E7%9A%84%E4%BA%BA%E3%80%82)
^zh-Q0693-answer

**zh-Q0694** — 最後笑的人，才是笑得最得意的人。

He laughs best who laughs last.

Why: Result and degree 得. [[Mandarin Chinese#^zh-Q0694|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%9C%80%E5%BE%8C%E7%AC%91%E7%9A%84%E4%BA%BA%EF%BC%8C%E6%89%8D%E6%98%AF%E7%AC%91%E5%BE%97%E6%9C%80%E5%BE%97%E6%84%8F%E7%9A%84%E4%BA%BA%E3%80%82)
^zh-Q0694-answer

**zh-Q0695** — 我覺得我病得很厲害。

I feel very sick.

Why: Result and degree 得. [[Mandarin Chinese#^zh-Q0695|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E8%A6%BA%E5%BE%97%E6%88%91%E7%97%85%E5%BE%97%E5%BE%88%E5%8E%B2%E5%AE%B3%E3%80%82)
^zh-Q0695-answer

**zh-Q0696** — 我覺得我病得很厲害。

I feel very sick.

得 can introduce degree/manner complements after a verb; it also occurs in potential and lexical constructions. A complement may require repeating a verb when an object is present.

Why: Result and degree 得. [[Mandarin Chinese#^zh-Q0696|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E8%A6%BA%E5%BE%97%E6%88%91%E7%97%85%E5%BE%97%E5%BE%88%E5%8E%B2%E5%AE%B3%E3%80%82)
^zh-Q0696-answer

**zh-Q0697** — 我的电视机出故障了，所以我不得不拿去修。

My television was broken down, so I had to get it repaired.

Expected form: **得**

Why: Result and degree 得. [[Mandarin Chinese#^zh-Q0697|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E7%9A%84%E7%94%B5%E8%A7%86%E6%9C%BA%E5%87%BA%E6%95%85%E9%9A%9C%E4%BA%86%EF%BC%8C%E6%89%80%E4%BB%A5%E6%88%91%E4%B8%8D%E5%BE%97%E4%B8%8D%E6%8B%BF%E5%8E%BB%E4%BF%AE%E3%80%82)
^zh-Q0697-answer

**zh-Q0698** — 我的电视机出故障了，所以我不得不拿去修。

My television was broken down, so I had to get it repaired.

Expected form: **得**

Why: Result and degree 得. [[Mandarin Chinese#^zh-Q0698|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E7%9A%84%E7%94%B5%E8%A7%86%E6%9C%BA%E5%87%BA%E6%95%85%E9%9A%9C%E4%BA%86%EF%BC%8C%E6%89%80%E4%BB%A5%E6%88%91%E4%B8%8D%E5%BE%97%E4%B8%8D%E6%8B%BF%E5%8E%BB%E4%BF%AE%E3%80%82)
^zh-Q0698-answer

**zh-Q0699** — 要变得完美，她就是少了一个缺点。

To be perfect she lacked just one defect.

Expected form: **得**

Why: Result and degree 得. [[Mandarin Chinese#^zh-Q0699|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%A6%81%E5%8F%98%E5%BE%97%E5%AE%8C%E7%BE%8E%EF%BC%8C%E5%A5%B9%E5%B0%B1%E6%98%AF%E5%B0%91%E4%BA%86%E4%B8%80%E4%B8%AA%E7%BC%BA%E7%82%B9%E3%80%82)
^zh-Q0699-answer

**zh-Q0700** — 要变得完美，她就是少了一个缺点。

To be perfect she lacked just one defect.

Why: Result and degree 得. [[Mandarin Chinese#^zh-Q0700|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%A6%81%E5%8F%98%E5%BE%97%E5%AE%8C%E7%BE%8E%EF%BC%8C%E5%A5%B9%E5%B0%B1%E6%98%AF%E5%B0%91%E4%BA%86%E4%B8%80%E4%B8%AA%E7%BC%BA%E7%82%B9%E3%80%82)
^zh-Q0700-answer


### Answers 701–750

**zh-Q0701** — 信濃川比日本的任何一條河川更長。

The Shinano River is longer than any river in Japan.

Why: Comparison 比. [[Mandarin Chinese#^zh-Q0701|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BF%A1%E6%BF%83%E5%B7%9D%E6%AF%94%E6%97%A5%E6%9C%AC%E7%9A%84%E4%BB%BB%E4%BD%95%E4%B8%80%E6%A2%9D%E6%B2%B3%E5%B7%9D%E6%9B%B4%E9%95%B7%E3%80%82)
^zh-Q0701-answer

**zh-Q0702** — 信濃川比日本的任何一條河川更長。

The Shinano River is longer than any river in Japan.

比 introduces a comparison standard. The adjective does not generally need 更 in the simplest pattern. Compare equality with 跟/和 ... 一样 rather than mechanically adding 比 to every comparison.

Why: Comparison 比. [[Mandarin Chinese#^zh-Q0702|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BF%A1%E6%BF%83%E5%B7%9D%E6%AF%94%E6%97%A5%E6%9C%AC%E7%9A%84%E4%BB%BB%E4%BD%95%E4%B8%80%E6%A2%9D%E6%B2%B3%E5%B7%9D%E6%9B%B4%E9%95%B7%E3%80%82)
^zh-Q0702-answer

**zh-Q0703** — 她的氣色看起來比以前好。

She looks better than before.

Expected form: **比**

Why: Comparison 比. [[Mandarin Chinese#^zh-Q0703|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A5%B9%E7%9A%84%E6%B0%A3%E8%89%B2%E7%9C%8B%E8%B5%B7%E4%BE%86%E6%AF%94%E4%BB%A5%E5%89%8D%E5%A5%BD%E3%80%82)
^zh-Q0703-answer

**zh-Q0704** — 她的氣色看起來比以前好。

She looks better than before.

Expected form: **比**

Why: Comparison 比. [[Mandarin Chinese#^zh-Q0704|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A5%B9%E7%9A%84%E6%B0%A3%E8%89%B2%E7%9C%8B%E8%B5%B7%E4%BE%86%E6%AF%94%E4%BB%A5%E5%89%8D%E5%A5%BD%E3%80%82)
^zh-Q0704-answer

**zh-Q0705** — 巧克力的鐵質含量比菠菜還要多。

Chocolate's iron content is higher than spinach's.

Expected form: **比**

Why: Comparison 比. [[Mandarin Chinese#^zh-Q0705|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%B7%A7%E5%85%8B%E5%8A%9B%E7%9A%84%E9%90%B5%E8%B3%AA%E5%90%AB%E9%87%8F%E6%AF%94%E8%8F%A0%E8%8F%9C%E9%82%84%E8%A6%81%E5%A4%9A%E3%80%82)
^zh-Q0705-answer

**zh-Q0706** — 巧克力的鐵質含量比菠菜還要多。

Chocolate's iron content is higher than spinach's.

Why: Comparison 比. [[Mandarin Chinese#^zh-Q0706|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%B7%A7%E5%85%8B%E5%8A%9B%E7%9A%84%E9%90%B5%E8%B3%AA%E5%90%AB%E9%87%8F%E6%AF%94%E8%8F%A0%E8%8F%9C%E9%82%84%E8%A6%81%E5%A4%9A%E3%80%82)
^zh-Q0706-answer

**zh-Q0707** — 大部分程序员讨厌调试，设置故障比纠正它们有意思多了。

Most developers hate debugging; it's more fun to create bugs than to correct them.

Why: Comparison 比. [[Mandarin Chinese#^zh-Q0707|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A4%A7%E9%83%A8%E5%88%86%E7%A8%8B%E5%BA%8F%E5%91%98%E8%AE%A8%E5%8E%8C%E8%B0%83%E8%AF%95%EF%BC%8C%E8%AE%BE%E7%BD%AE%E6%95%85%E9%9A%9C%E6%AF%94%E7%BA%A0%E6%AD%A3%E5%AE%83%E4%BB%AC%E6%9C%89%E6%84%8F%E6%80%9D%E5%A4%9A%E4%BA%86%E3%80%82)
^zh-Q0707-answer

**zh-Q0708** — 大部分程序员讨厌调试，设置故障比纠正它们有意思多了。

Most developers hate debugging; it's more fun to create bugs than to correct them.

比 introduces a comparison standard. The adjective does not generally need 更 in the simplest pattern. Compare equality with 跟/和 ... 一样 rather than mechanically adding 比 to every comparison.

Why: Comparison 比. [[Mandarin Chinese#^zh-Q0708|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A4%A7%E9%83%A8%E5%88%86%E7%A8%8B%E5%BA%8F%E5%91%98%E8%AE%A8%E5%8E%8C%E8%B0%83%E8%AF%95%EF%BC%8C%E8%AE%BE%E7%BD%AE%E6%95%85%E9%9A%9C%E6%AF%94%E7%BA%A0%E6%AD%A3%E5%AE%83%E4%BB%AC%E6%9C%89%E6%84%8F%E6%80%9D%E5%A4%9A%E4%BA%86%E3%80%82)
^zh-Q0708-answer

**zh-Q0709** — 关于财务方面的事项，公司里没有人比琼斯先生更了解。

With respect to financial matters, Mr Jones knows more than anyone else in the company.

Expected form: **比**

Why: Comparison 比. [[Mandarin Chinese#^zh-Q0709|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%85%B3%E4%BA%8E%E8%B4%A2%E5%8A%A1%E6%96%B9%E9%9D%A2%E7%9A%84%E4%BA%8B%E9%A1%B9%EF%BC%8C%E5%85%AC%E5%8F%B8%E9%87%8C%E6%B2%A1%E6%9C%89%E4%BA%BA%E6%AF%94%E7%90%BC%E6%96%AF%E5%85%88%E7%94%9F%E6%9B%B4%E4%BA%86%E8%A7%A3%E3%80%82)
^zh-Q0709-answer

**zh-Q0710** — 关于财务方面的事项，公司里没有人比琼斯先生更了解。

With respect to financial matters, Mr Jones knows more than anyone else in the company.

Expected form: **比**

Why: Comparison 比. [[Mandarin Chinese#^zh-Q0710|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%85%B3%E4%BA%8E%E8%B4%A2%E5%8A%A1%E6%96%B9%E9%9D%A2%E7%9A%84%E4%BA%8B%E9%A1%B9%EF%BC%8C%E5%85%AC%E5%8F%B8%E9%87%8C%E6%B2%A1%E6%9C%89%E4%BA%BA%E6%AF%94%E7%90%BC%E6%96%AF%E5%85%88%E7%94%9F%E6%9B%B4%E4%BA%86%E8%A7%A3%E3%80%82)
^zh-Q0710-answer

**zh-Q0711** — 我喜歡看棒球比賽。

I like to watch baseball games.

Expected form: **比**

Why: Comparison 比. [[Mandarin Chinese#^zh-Q0711|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E5%96%9C%E6%AD%A1%E7%9C%8B%E6%A3%92%E7%90%83%E6%AF%94%E8%B3%BD%E3%80%82)
^zh-Q0711-answer

**zh-Q0712** — 我喜歡看棒球比賽。

I like to watch baseball games.

Why: Comparison 比. [[Mandarin Chinese#^zh-Q0712|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E5%96%9C%E6%AD%A1%E7%9C%8B%E6%A3%92%E7%90%83%E6%AF%94%E8%B3%BD%E3%80%82)
^zh-Q0712-answer

**zh-Q0713** — 我喜歡在電視上看足球比賽。

I enjoy watching soccer on TV.

Why: Comparison 比. [[Mandarin Chinese#^zh-Q0713|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E5%96%9C%E6%AD%A1%E5%9C%A8%E9%9B%BB%E8%A6%96%E4%B8%8A%E7%9C%8B%E8%B6%B3%E7%90%83%E6%AF%94%E8%B3%BD%E3%80%82)
^zh-Q0713-answer

**zh-Q0714** — 我喜歡在電視上看足球比賽。

I enjoy watching soccer on TV.

比 introduces a comparison standard. The adjective does not generally need 更 in the simplest pattern. Compare equality with 跟/和 ... 一样 rather than mechanically adding 比 to every comparison.

Why: Comparison 比. [[Mandarin Chinese#^zh-Q0714|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E5%96%9C%E6%AD%A1%E5%9C%A8%E9%9B%BB%E8%A6%96%E4%B8%8A%E7%9C%8B%E8%B6%B3%E7%90%83%E6%AF%94%E8%B3%BD%E3%80%82)
^zh-Q0714-answer

**zh-Q0715** — 不管是谁总比没人好。

Anybody would be better than nobody.

Expected form: **比**

Why: Comparison 比. [[Mandarin Chinese#^zh-Q0715|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%B8%8D%E7%AE%A1%E6%98%AF%E8%B0%81%E6%80%BB%E6%AF%94%E6%B2%A1%E4%BA%BA%E5%A5%BD%E3%80%82)
^zh-Q0715-answer

**zh-Q0716** — 不管是谁总比没人好。

Anybody would be better than nobody.

Expected form: **比**

Why: Comparison 比. [[Mandarin Chinese#^zh-Q0716|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%B8%8D%E7%AE%A1%E6%98%AF%E8%B0%81%E6%80%BB%E6%AF%94%E6%B2%A1%E4%BA%BA%E5%A5%BD%E3%80%82)
^zh-Q0716-answer

**zh-Q0717** — 我曾與他的比賽網球。

I had a tennis match with him.

Expected form: **比**

Why: Comparison 比. [[Mandarin Chinese#^zh-Q0717|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E6%9B%BE%E8%88%87%E4%BB%96%E7%9A%84%E6%AF%94%E8%B3%BD%E7%B6%B2%E7%90%83%E3%80%82)
^zh-Q0717-answer

**zh-Q0718** — 我曾與他的比賽網球。

I had a tennis match with him.

Why: Comparison 比. [[Mandarin Chinese#^zh-Q0718|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E6%9B%BE%E8%88%87%E4%BB%96%E7%9A%84%E6%AF%94%E8%B3%BD%E7%B6%B2%E7%90%83%E3%80%82)
^zh-Q0718-answer

**zh-Q0719** — 我們看了電視上的足球比賽。

We watched the soccer game on TV.

Why: Comparison 比. [[Mandarin Chinese#^zh-Q0719|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E5%80%91%E7%9C%8B%E4%BA%86%E9%9B%BB%E8%A6%96%E4%B8%8A%E7%9A%84%E8%B6%B3%E7%90%83%E6%AF%94%E8%B3%BD%E3%80%82)
^zh-Q0719-answer

**zh-Q0720** — 我們看了電視上的足球比賽。

We watched the soccer game on TV.

比 introduces a comparison standard. The adjective does not generally need 更 in the simplest pattern. Compare equality with 跟/和 ... 一样 rather than mechanically adding 比 to every comparison.

Why: Comparison 比. [[Mandarin Chinese#^zh-Q0720|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E5%80%91%E7%9C%8B%E4%BA%86%E9%9B%BB%E8%A6%96%E4%B8%8A%E7%9A%84%E8%B6%B3%E7%90%83%E6%AF%94%E8%B3%BD%E3%80%82)
^zh-Q0720-answer

**zh-Q0721** — 恐惧比利剑更伤人。

Fear is more harmful than the sharpest of swords.

Expected form: **比**

Why: Comparison 比. [[Mandarin Chinese#^zh-Q0721|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%81%90%E6%83%A7%E6%AF%94%E5%88%A9%E5%89%91%E6%9B%B4%E4%BC%A4%E4%BA%BA%E3%80%82)
^zh-Q0721-answer

**zh-Q0722** — 恐惧比利剑更伤人。

Fear is more harmful than the sharpest of swords.

Expected form: **比**

Why: Comparison 比. [[Mandarin Chinese#^zh-Q0722|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%81%90%E6%83%A7%E6%AF%94%E5%88%A9%E5%89%91%E6%9B%B4%E4%BC%A4%E4%BA%BA%E3%80%82)
^zh-Q0722-answer

**zh-Q0723** — 仅太平洋的面积就比所有的大陆的总和面积还要大。

The Pacific Ocean alone covers an area larger than that of all continents put together.

Expected form: **比**

Why: Comparison 比. [[Mandarin Chinese#^zh-Q0723|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%85%E5%A4%AA%E5%B9%B3%E6%B4%8B%E7%9A%84%E9%9D%A2%E7%A7%AF%E5%B0%B1%E6%AF%94%E6%89%80%E6%9C%89%E7%9A%84%E5%A4%A7%E9%99%86%E7%9A%84%E6%80%BB%E5%92%8C%E9%9D%A2%E7%A7%AF%E8%BF%98%E8%A6%81%E5%A4%A7%E3%80%82)
^zh-Q0723-answer

**zh-Q0724** — 仅太平洋的面积就比所有的大陆的总和面积还要大。

The Pacific Ocean alone covers an area larger than that of all continents put together.

Why: Comparison 比. [[Mandarin Chinese#^zh-Q0724|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%85%E5%A4%AA%E5%B9%B3%E6%B4%8B%E7%9A%84%E9%9D%A2%E7%A7%AF%E5%B0%B1%E6%AF%94%E6%89%80%E6%9C%89%E7%9A%84%E5%A4%A7%E9%99%86%E7%9A%84%E6%80%BB%E5%92%8C%E9%9D%A2%E7%A7%AF%E8%BF%98%E8%A6%81%E5%A4%A7%E3%80%82)
^zh-Q0724-answer

**zh-Q0725** — 說英語的人比說任何其他語言的人多。

English is spoken by more people than any other language.

Why: Comparison 比. [[Mandarin Chinese#^zh-Q0725|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%AA%AA%E8%8B%B1%E8%AA%9E%E7%9A%84%E4%BA%BA%E6%AF%94%E8%AA%AA%E4%BB%BB%E4%BD%95%E5%85%B6%E4%BB%96%E8%AA%9E%E8%A8%80%E7%9A%84%E4%BA%BA%E5%A4%9A%E3%80%82)
^zh-Q0725-answer

**zh-Q0726** — 說英語的人比說任何其他語言的人多。

English is spoken by more people than any other language.

比 introduces a comparison standard. The adjective does not generally need 更 in the simplest pattern. Compare equality with 跟/和 ... 一样 rather than mechanically adding 比 to every comparison.

Why: Comparison 比. [[Mandarin Chinese#^zh-Q0726|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%AA%AA%E8%8B%B1%E8%AA%9E%E7%9A%84%E4%BA%BA%E6%AF%94%E8%AA%AA%E4%BB%BB%E4%BD%95%E5%85%B6%E4%BB%96%E8%AA%9E%E8%A8%80%E7%9A%84%E4%BA%BA%E5%A4%9A%E3%80%82)
^zh-Q0726-answer

**zh-Q0727** — 她没有比她妈妈更漂亮。

She's not prettier than her mother.

Expected form: **比**

Why: Comparison 比. [[Mandarin Chinese#^zh-Q0727|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A5%B9%E6%B2%A1%E6%9C%89%E6%AF%94%E5%A5%B9%E5%A6%88%E5%A6%88%E6%9B%B4%E6%BC%82%E4%BA%AE%E3%80%82)
^zh-Q0727-answer

**zh-Q0728** — 她没有比她妈妈更漂亮。

She's not prettier than her mother.

Expected form: **比**

Why: Comparison 比. [[Mandarin Chinese#^zh-Q0728|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A5%B9%E6%B2%A1%E6%9C%89%E6%AF%94%E5%A5%B9%E5%A6%88%E5%A6%88%E6%9B%B4%E6%BC%82%E4%BA%AE%E3%80%82)
^zh-Q0728-answer

**zh-Q0729** — 我喜歡住在科比的郊區。

I'd like to live in the suburbs of Kobe.

Expected form: **比**

Why: Comparison 比. [[Mandarin Chinese#^zh-Q0729|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E5%96%9C%E6%AD%A1%E4%BD%8F%E5%9C%A8%E7%A7%91%E6%AF%94%E7%9A%84%E9%83%8A%E5%8D%80%E3%80%82)
^zh-Q0729-answer

**zh-Q0730** — 我喜歡住在科比的郊區。

I'd like to live in the suburbs of Kobe.

Why: Comparison 比. [[Mandarin Chinese#^zh-Q0730|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E5%96%9C%E6%AD%A1%E4%BD%8F%E5%9C%A8%E7%A7%91%E6%AF%94%E7%9A%84%E9%83%8A%E5%8D%80%E3%80%82)
^zh-Q0730-answer

**zh-Q0731** — 比起酒來，我比較喜歡蛋糕、糖果，可是酒我也不是完全不喝的。

I prefer cakes or candies to alcohol, but I do drink.

Why: Comparison 比. [[Mandarin Chinese#^zh-Q0731|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%AF%94%E8%B5%B7%E9%85%92%E4%BE%86%EF%BC%8C%E6%88%91%E6%AF%94%E8%BC%83%E5%96%9C%E6%AD%A1%E8%9B%8B%E7%B3%95%E3%80%81%E7%B3%96%E6%9E%9C%EF%BC%8C%E5%8F%AF%E6%98%AF%E9%85%92%E6%88%91%E4%B9%9F%E4%B8%8D%E6%98%AF%E5%AE%8C%E5%85%A8%E4%B8%8D%E5%96%9D%E7%9A%84%E3%80%82)
^zh-Q0731-answer

**zh-Q0732** — 比起酒來，我比較喜歡蛋糕、糖果，可是酒我也不是完全不喝的。

I prefer cakes or candies to alcohol, but I do drink.

比 introduces a comparison standard. The adjective does not generally need 更 in the simplest pattern. Compare equality with 跟/和 ... 一样 rather than mechanically adding 比 to every comparison.

Why: Comparison 比. [[Mandarin Chinese#^zh-Q0732|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%AF%94%E8%B5%B7%E9%85%92%E4%BE%86%EF%BC%8C%E6%88%91%E6%AF%94%E8%BC%83%E5%96%9C%E6%AD%A1%E8%9B%8B%E7%B3%95%E3%80%81%E7%B3%96%E6%9E%9C%EF%BC%8C%E5%8F%AF%E6%98%AF%E9%85%92%E6%88%91%E4%B9%9F%E4%B8%8D%E6%98%AF%E5%AE%8C%E5%85%A8%E4%B8%8D%E5%96%9D%E7%9A%84%E3%80%82)
^zh-Q0732-answer

**zh-Q0733** — 中文比其它外語難多了。

Chinese is much more difficult than other foreign languages.

Expected form: **比**

Why: Comparison 比. [[Mandarin Chinese#^zh-Q0733|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%B8%AD%E6%96%87%E6%AF%94%E5%85%B6%E5%AE%83%E5%A4%96%E8%AA%9E%E9%9B%A3%E5%A4%9A%E4%BA%86%E3%80%82)
^zh-Q0733-answer

**zh-Q0734** — 中文比其它外語難多了。

Chinese is much more difficult than other foreign languages.

Expected form: **比**

Why: Comparison 比. [[Mandarin Chinese#^zh-Q0734|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%B8%AD%E6%96%87%E6%AF%94%E5%85%B6%E5%AE%83%E5%A4%96%E8%AA%9E%E9%9B%A3%E5%A4%9A%E4%BA%86%E3%80%82)
^zh-Q0734-answer

**zh-Q0735** — 笔记本电脑比台式电脑好。

A laptop is better than a desktop.

Expected form: **比**

Why: Comparison 比. [[Mandarin Chinese#^zh-Q0735|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E7%AC%94%E8%AE%B0%E6%9C%AC%E7%94%B5%E8%84%91%E6%AF%94%E5%8F%B0%E5%BC%8F%E7%94%B5%E8%84%91%E5%A5%BD%E3%80%82)
^zh-Q0735-answer

**zh-Q0736** — 笔记本电脑比台式电脑好。

A laptop is better than a desktop.

Why: Comparison 比. [[Mandarin Chinese#^zh-Q0736|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E7%AC%94%E8%AE%B0%E6%9C%AC%E7%94%B5%E8%84%91%E6%AF%94%E5%8F%B0%E5%BC%8F%E7%94%B5%E8%84%91%E5%A5%BD%E3%80%82)
^zh-Q0736-answer

**zh-Q0737** — 他很有信心贏這場比賽。

He is sure of winning the game.

Why: Comparison 比. [[Mandarin Chinese#^zh-Q0737|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%96%E5%BE%88%E6%9C%89%E4%BF%A1%E5%BF%83%E8%B4%8F%E9%80%99%E5%A0%B4%E6%AF%94%E8%B3%BD%E3%80%82)
^zh-Q0737-answer

**zh-Q0738** — 他很有信心贏這場比賽。

He is sure of winning the game.

比 introduces a comparison standard. The adjective does not generally need 更 in the simplest pattern. Compare equality with 跟/和 ... 一样 rather than mechanically adding 比 to every comparison.

Why: Comparison 比. [[Mandarin Chinese#^zh-Q0738|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%96%E5%BE%88%E6%9C%89%E4%BF%A1%E5%BF%83%E8%B4%8F%E9%80%99%E5%A0%B4%E6%AF%94%E8%B3%BD%E3%80%82)
^zh-Q0738-answer

**zh-Q0739** — 比爾一如往常上學遲到。

Bill was late for school as usual.

Expected form: **比**

Why: Comparison 比. [[Mandarin Chinese#^zh-Q0739|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%AF%94%E7%88%BE%E4%B8%80%E5%A6%82%E5%BE%80%E5%B8%B8%E4%B8%8A%E5%AD%B8%E9%81%B2%E5%88%B0%E3%80%82)
^zh-Q0739-answer

**zh-Q0740** — 比爾一如往常上學遲到。

Bill was late for school as usual.

Expected form: **比**

Why: Comparison 比. [[Mandarin Chinese#^zh-Q0740|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%AF%94%E7%88%BE%E4%B8%80%E5%A6%82%E5%BE%80%E5%B8%B8%E4%B8%8A%E5%AD%B8%E9%81%B2%E5%88%B0%E3%80%82)
^zh-Q0740-answer

**zh-Q0741** — 湯姆跑得不如比爾快。

Tom doesn't run as fast as Bill.

Expected form: **比**

Why: Comparison 比. [[Mandarin Chinese#^zh-Q0741|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%B9%AF%E5%A7%86%E8%B7%91%E5%BE%97%E4%B8%8D%E5%A6%82%E6%AF%94%E7%88%BE%E5%BF%AB%E3%80%82)
^zh-Q0741-answer

**zh-Q0742** — 湯姆跑得不如比爾快。

Tom doesn't run as fast as Bill.

Why: Comparison 比. [[Mandarin Chinese#^zh-Q0742|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%B9%AF%E5%A7%86%E8%B7%91%E5%BE%97%E4%B8%8D%E5%A6%82%E6%AF%94%E7%88%BE%E5%BF%AB%E3%80%82)
^zh-Q0742-answer

**zh-Q0743** — 我有莎士比亞的作品全集。

I have the complete works of Shakespeare.

Why: Comparison 比. [[Mandarin Chinese#^zh-Q0743|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E6%9C%89%E8%8E%8E%E5%A3%AB%E6%AF%94%E4%BA%9E%E7%9A%84%E4%BD%9C%E5%93%81%E5%85%A8%E9%9B%86%E3%80%82)
^zh-Q0743-answer

**zh-Q0744** — 我有莎士比亞的作品全集。

I have the complete works of Shakespeare.

比 introduces a comparison standard. The adjective does not generally need 更 in the simplest pattern. Compare equality with 跟/和 ... 一样 rather than mechanically adding 比 to every comparison.

Why: Comparison 比. [[Mandarin Chinese#^zh-Q0744|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E6%9C%89%E8%8E%8E%E5%A3%AB%E6%AF%94%E4%BA%9E%E7%9A%84%E4%BD%9C%E5%93%81%E5%85%A8%E9%9B%86%E3%80%82)
^zh-Q0744-answer

**zh-Q0745** — 相比第二本，我更喜欢汤姆的第一本书。

I liked Tom's first book more than the second.

Expected form: **比**

Why: Comparison 比. [[Mandarin Chinese#^zh-Q0745|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E7%9B%B8%E6%AF%94%E7%AC%AC%E4%BA%8C%E6%9C%AC%EF%BC%8C%E6%88%91%E6%9B%B4%E5%96%9C%E6%AC%A2%E6%B1%A4%E5%A7%86%E7%9A%84%E7%AC%AC%E4%B8%80%E6%9C%AC%E4%B9%A6%E3%80%82)
^zh-Q0745-answer

**zh-Q0746** — 相比第二本，我更喜欢汤姆的第一本书。

I liked Tom's first book more than the second.

Expected form: **比**

Why: Comparison 比. [[Mandarin Chinese#^zh-Q0746|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E7%9B%B8%E6%AF%94%E7%AC%AC%E4%BA%8C%E6%9C%AC%EF%BC%8C%E6%88%91%E6%9B%B4%E5%96%9C%E6%AC%A2%E6%B1%A4%E5%A7%86%E7%9A%84%E7%AC%AC%E4%B8%80%E6%9C%AC%E4%B9%A6%E3%80%82)
^zh-Q0746-answer

**zh-Q0747** — 上大學的時候，你得到的比付出的還多。

You gain more than you spend when you go to college.

Expected form: **比**

Why: Comparison 比. [[Mandarin Chinese#^zh-Q0747|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%B8%8A%E5%A4%A7%E5%AD%B8%E7%9A%84%E6%99%82%E5%80%99%EF%BC%8C%E4%BD%A0%E5%BE%97%E5%88%B0%E7%9A%84%E6%AF%94%E4%BB%98%E5%87%BA%E7%9A%84%E9%82%84%E5%A4%9A%E3%80%82)
^zh-Q0747-answer

**zh-Q0748** — 上大學的時候，你得到的比付出的還多。

You gain more than you spend when you go to college.

Why: Comparison 比. [[Mandarin Chinese#^zh-Q0748|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%B8%8A%E5%A4%A7%E5%AD%B8%E7%9A%84%E6%99%82%E5%80%99%EF%BC%8C%E4%BD%A0%E5%BE%97%E5%88%B0%E7%9A%84%E6%AF%94%E4%BB%98%E5%87%BA%E7%9A%84%E9%82%84%E5%A4%9A%E3%80%82)
^zh-Q0748-answer

**zh-Q0749** — 人比动物会讲话和想。

Man differs from animals in that he can speak and think.

Why: Comparison 比. [[Mandarin Chinese#^zh-Q0749|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BA%BA%E6%AF%94%E5%8A%A8%E7%89%A9%E4%BC%9A%E8%AE%B2%E8%AF%9D%E5%92%8C%E6%83%B3%E3%80%82)
^zh-Q0749-answer

**zh-Q0750** — 人比动物会讲话和想。

Man differs from animals in that he can speak and think.

比 introduces a comparison standard. The adjective does not generally need 更 in the simplest pattern. Compare equality with 跟/和 ... 一样 rather than mechanically adding 比 to every comparison.

Why: Comparison 比. [[Mandarin Chinese#^zh-Q0750|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BA%BA%E6%AF%94%E5%8A%A8%E7%89%A9%E4%BC%9A%E8%AE%B2%E8%AF%9D%E5%92%8C%E6%83%B3%E3%80%82)
^zh-Q0750-answer


### Answers 751–800

**zh-Q0751** — 抱歉，你能再说一遍吗？

I'm sorry, could you say that again?

Expected form: **吗**

Why: Question particles. [[Mandarin Chinese#^zh-Q0751|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%8A%B1%E6%AD%89%EF%BC%8C%E4%BD%A0%E8%83%BD%E5%86%8D%E8%AF%B4%E4%B8%80%E9%81%8D%E5%90%97%EF%BC%9F)
^zh-Q0751-answer

**zh-Q0752** — 抱歉，你能再说一遍吗？

I'm sorry, could you say that again?

Expected form: **吗**

Why: Question particles. [[Mandarin Chinese#^zh-Q0752|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%8A%B1%E6%AD%89%EF%BC%8C%E4%BD%A0%E8%83%BD%E5%86%8D%E8%AF%B4%E4%B8%80%E9%81%8D%E5%90%97%EF%BC%9F)
^zh-Q0752-answer

**zh-Q0753** — 您想知道为什么我要离开吗？

Do you want to know why I quit?

Expected form: **吗**

Why: Question particles. [[Mandarin Chinese#^zh-Q0753|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%82%A8%E6%83%B3%E7%9F%A5%E9%81%93%E4%B8%BA%E4%BB%80%E4%B9%88%E6%88%91%E8%A6%81%E7%A6%BB%E5%BC%80%E5%90%97%EF%BC%9F)
^zh-Q0753-answer

**zh-Q0754** — 您想知道为什么我要离开吗？

Do you want to know why I quit?

Why: Question particles. [[Mandarin Chinese#^zh-Q0754|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%82%A8%E6%83%B3%E7%9F%A5%E9%81%93%E4%B8%BA%E4%BB%80%E4%B9%88%E6%88%91%E8%A6%81%E7%A6%BB%E5%BC%80%E5%90%97%EF%BC%9F)
^zh-Q0754-answer

**zh-Q0755** — 我能用法语加一句句子吗？

Can I enter a sentence in French?

Why: Question particles. [[Mandarin Chinese#^zh-Q0755|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E8%83%BD%E7%94%A8%E6%B3%95%E8%AF%AD%E5%8A%A0%E4%B8%80%E5%8F%A5%E5%8F%A5%E5%AD%90%E5%90%97%EF%BC%9F)
^zh-Q0755-answer

**zh-Q0756** — 我能用法语加一句句子吗？

Can I enter a sentence in French?

吗 commonly turns a statement into a yes/no question. 呢 can ask about a topic or continuation. Question-word questions ordinarily do not add 吗 merely because they are questions.

Why: Question particles. [[Mandarin Chinese#^zh-Q0756|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E8%83%BD%E7%94%A8%E6%B3%95%E8%AF%AD%E5%8A%A0%E4%B8%80%E5%8F%A5%E5%8F%A5%E5%AD%90%E5%90%97%EF%BC%9F)
^zh-Q0756-answer

**zh-Q0757** — 我还什么都没找到呢。

I still haven't found anything.

Expected form: **呢**

Why: Question particles. [[Mandarin Chinese#^zh-Q0757|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E8%BF%98%E4%BB%80%E4%B9%88%E9%83%BD%E6%B2%A1%E6%89%BE%E5%88%B0%E5%91%A2%E3%80%82)
^zh-Q0757-answer

**zh-Q0758** — 我还什么都没找到呢。

I still haven't found anything.

Expected form: **呢**

Why: Question particles. [[Mandarin Chinese#^zh-Q0758|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E8%BF%98%E4%BB%80%E4%B9%88%E9%83%BD%E6%B2%A1%E6%89%BE%E5%88%B0%E5%91%A2%E3%80%82)
^zh-Q0758-answer

**zh-Q0759** — 我还以为我在做梦呢。

I thought I was dreaming.

Expected form: **呢**

Why: Question particles. [[Mandarin Chinese#^zh-Q0759|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E8%BF%98%E4%BB%A5%E4%B8%BA%E6%88%91%E5%9C%A8%E5%81%9A%E6%A2%A6%E5%91%A2%E3%80%82)
^zh-Q0759-answer

**zh-Q0760** — 我还以为我在做梦呢。

I thought I was dreaming.

Why: Question particles. [[Mandarin Chinese#^zh-Q0760|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E8%BF%98%E4%BB%A5%E4%B8%BA%E6%88%91%E5%9C%A8%E5%81%9A%E6%A2%A6%E5%91%A2%E3%80%82)
^zh-Q0760-answer

**zh-Q0761** — 今天中午我们出去吃饭吗？

Are we going out for lunch today?

Why: Question particles. [[Mandarin Chinese#^zh-Q0761|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%8A%E5%A4%A9%E4%B8%AD%E5%8D%88%E6%88%91%E4%BB%AC%E5%87%BA%E5%8E%BB%E5%90%83%E9%A5%AD%E5%90%97%EF%BC%9F)
^zh-Q0761-answer

**zh-Q0762** — 今天中午我们出去吃饭吗？

Are we going out for lunch today?

吗 commonly turns a statement into a yes/no question. 呢 can ask about a topic or continuation. Question-word questions ordinarily do not add 吗 merely because they are questions.

Why: Question particles. [[Mandarin Chinese#^zh-Q0762|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%8A%E5%A4%A9%E4%B8%AD%E5%8D%88%E6%88%91%E4%BB%AC%E5%87%BA%E5%8E%BB%E5%90%83%E9%A5%AD%E5%90%97%EF%BC%9F)
^zh-Q0762-answer

**zh-Q0763** — 世界上是不是真的有鬼呢？

Do ghosts really exist?

Expected form: **呢**

Why: Question particles. [[Mandarin Chinese#^zh-Q0763|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%B8%96%E7%95%8C%E4%B8%8A%E6%98%AF%E4%B8%8D%E6%98%AF%E7%9C%9F%E7%9A%84%E6%9C%89%E9%AC%BC%E5%91%A2%EF%BC%9F)
^zh-Q0763-answer

**zh-Q0764** — 世界上是不是真的有鬼呢？

Do ghosts really exist?

Expected form: **呢**

Why: Question particles. [[Mandarin Chinese#^zh-Q0764|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%B8%96%E7%95%8C%E4%B8%8A%E6%98%AF%E4%B8%8D%E6%98%AF%E7%9C%9F%E7%9A%84%E6%9C%89%E9%AC%BC%E5%91%A2%EF%BC%9F)
^zh-Q0764-answer

**zh-Q0765** — 你放假打算去甚麼地方玩呢？

Where are you going to go on your vacation?

Expected form: **呢**

Why: Question particles. [[Mandarin Chinese#^zh-Q0765|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E6%94%BE%E5%81%87%E6%89%93%E7%AE%97%E5%8E%BB%E7%94%9A%E9%BA%BC%E5%9C%B0%E6%96%B9%E7%8E%A9%E5%91%A2%EF%BC%9F)
^zh-Q0765-answer

**zh-Q0766** — 你放假打算去甚麼地方玩呢？

Where are you going to go on your vacation?

Why: Question particles. [[Mandarin Chinese#^zh-Q0766|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E6%94%BE%E5%81%87%E6%89%93%E7%AE%97%E5%8E%BB%E7%94%9A%E9%BA%BC%E5%9C%B0%E6%96%B9%E7%8E%A9%E5%91%A2%EF%BC%9F)
^zh-Q0766-answer

**zh-Q0767** — 有什么事我可以做吗？

Is there anything I can do?

Why: Question particles. [[Mandarin Chinese#^zh-Q0767|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%9C%89%E4%BB%80%E4%B9%88%E4%BA%8B%E6%88%91%E5%8F%AF%E4%BB%A5%E5%81%9A%E5%90%97%EF%BC%9F)
^zh-Q0767-answer

**zh-Q0768** — 有什么事我可以做吗？

Is there anything I can do?

吗 commonly turns a statement into a yes/no question. 呢 can ask about a topic or continuation. Question-word questions ordinarily do not add 吗 merely because they are questions.

Why: Question particles. [[Mandarin Chinese#^zh-Q0768|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%9C%89%E4%BB%80%E4%B9%88%E4%BA%8B%E6%88%91%E5%8F%AF%E4%BB%A5%E5%81%9A%E5%90%97%EF%BC%9F)
^zh-Q0768-answer

**zh-Q0769** — 你能告诉我红茶和绿茶的区别吗？

Can you describe to me the difference between black tea and green tea?

Expected form: **吗**

Why: Question particles. [[Mandarin Chinese#^zh-Q0769|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E8%83%BD%E5%91%8A%E8%AF%89%E6%88%91%E7%BA%A2%E8%8C%B6%E5%92%8C%E7%BB%BF%E8%8C%B6%E7%9A%84%E5%8C%BA%E5%88%AB%E5%90%97%EF%BC%9F)
^zh-Q0769-answer

**zh-Q0770** — 你能告诉我红茶和绿茶的区别吗？

Can you describe to me the difference between black tea and green tea?

Expected form: **吗**

Why: Question particles. [[Mandarin Chinese#^zh-Q0770|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E8%83%BD%E5%91%8A%E8%AF%89%E6%88%91%E7%BA%A2%E8%8C%B6%E5%92%8C%E7%BB%BF%E8%8C%B6%E7%9A%84%E5%8C%BA%E5%88%AB%E5%90%97%EF%BC%9F)
^zh-Q0770-answer

**zh-Q0771** — 假如你有1000美元，你会用它做什么呢？

Suppose you had a thousand dollars, what would you do with it?

Expected form: **呢**

Why: Question particles. [[Mandarin Chinese#^zh-Q0771|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%81%87%E5%A6%82%E4%BD%A0%E6%9C%891000%E7%BE%8E%E5%85%83%EF%BC%8C%E4%BD%A0%E4%BC%9A%E7%94%A8%E5%AE%83%E5%81%9A%E4%BB%80%E4%B9%88%E5%91%A2%EF%BC%9F)
^zh-Q0771-answer

**zh-Q0772** — 假如你有1000美元，你会用它做什么呢？

Suppose you had a thousand dollars, what would you do with it?

Why: Question particles. [[Mandarin Chinese#^zh-Q0772|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%81%87%E5%A6%82%E4%BD%A0%E6%9C%891000%E7%BE%8E%E5%85%83%EF%BC%8C%E4%BD%A0%E4%BC%9A%E7%94%A8%E5%AE%83%E5%81%9A%E4%BB%80%E4%B9%88%E5%91%A2%EF%BC%9F)
^zh-Q0772-answer

**zh-Q0773** — 你能拿到架子上的书吗？

Can't you reach the book on the shelf?

Why: Question particles. [[Mandarin Chinese#^zh-Q0773|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E8%83%BD%E6%8B%BF%E5%88%B0%E6%9E%B6%E5%AD%90%E4%B8%8A%E7%9A%84%E4%B9%A6%E5%90%97%EF%BC%9F)
^zh-Q0773-answer

**zh-Q0774** — 你能拿到架子上的书吗？

Can't you reach the book on the shelf?

吗 commonly turns a statement into a yes/no question. 呢 can ask about a topic or continuation. Question-word questions ordinarily do not add 吗 merely because they are questions.

Why: Question particles. [[Mandarin Chinese#^zh-Q0774|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E8%83%BD%E6%8B%BF%E5%88%B0%E6%9E%B6%E5%AD%90%E4%B8%8A%E7%9A%84%E4%B9%A6%E5%90%97%EF%BC%9F)
^zh-Q0774-answer

**zh-Q0775** — 事情真的已经了结了吗？

Is it really all over?

Expected form: **吗**

Why: Question particles. [[Mandarin Chinese#^zh-Q0775|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BA%8B%E6%83%85%E7%9C%9F%E7%9A%84%E5%B7%B2%E7%BB%8F%E4%BA%86%E7%BB%93%E4%BA%86%E5%90%97%EF%BC%9F)
^zh-Q0775-answer

**zh-Q0776** — 事情真的已经了结了吗？

Is it really all over?

Expected form: **吗**

Why: Question particles. [[Mandarin Chinese#^zh-Q0776|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BA%8B%E6%83%85%E7%9C%9F%E7%9A%84%E5%B7%B2%E7%BB%8F%E4%BA%86%E7%BB%93%E4%BA%86%E5%90%97%EF%BC%9F)
^zh-Q0776-answer

**zh-Q0777** — 这个我们明天能解决吗？

Can we take care of this tomorrow?

Expected form: **吗**

Why: Question particles. [[Mandarin Chinese#^zh-Q0777|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%BF%99%E4%B8%AA%E6%88%91%E4%BB%AC%E6%98%8E%E5%A4%A9%E8%83%BD%E8%A7%A3%E5%86%B3%E5%90%97%EF%BC%9F)
^zh-Q0777-answer

**zh-Q0778** — 这个我们明天能解决吗？

Can we take care of this tomorrow?

Why: Question particles. [[Mandarin Chinese#^zh-Q0778|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%BF%99%E4%B8%AA%E6%88%91%E4%BB%AC%E6%98%8E%E5%A4%A9%E8%83%BD%E8%A7%A3%E5%86%B3%E5%90%97%EF%BC%9F)
^zh-Q0778-answer

**zh-Q0779** — 但我们从哪儿弄到那些句子？我们又要如何翻译呢？

But where do we get those sentences? And how do we translate them?

Why: Question particles. [[Mandarin Chinese#^zh-Q0779|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%86%E6%88%91%E4%BB%AC%E4%BB%8E%E5%93%AA%E5%84%BF%E5%BC%84%E5%88%B0%E9%82%A3%E4%BA%9B%E5%8F%A5%E5%AD%90%EF%BC%9F%E6%88%91%E4%BB%AC%E5%8F%88%E8%A6%81%E5%A6%82%E4%BD%95%E7%BF%BB%E8%AF%91%E5%91%A2%EF%BC%9F)
^zh-Q0779-answer

**zh-Q0780** — 但我们从哪儿弄到那些句子？我们又要如何翻译呢？

But where do we get those sentences? And how do we translate them?

吗 commonly turns a statement into a yes/no question. 呢 can ask about a topic or continuation. Question-word questions ordinarily do not add 吗 merely because they are questions.

Why: Question particles. [[Mandarin Chinese#^zh-Q0780|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%86%E6%88%91%E4%BB%AC%E4%BB%8E%E5%93%AA%E5%84%BF%E5%BC%84%E5%88%B0%E9%82%A3%E4%BA%9B%E5%8F%A5%E5%AD%90%EF%BC%9F%E6%88%91%E4%BB%AC%E5%8F%88%E8%A6%81%E5%A6%82%E4%BD%95%E7%BF%BB%E8%AF%91%E5%91%A2%EF%BC%9F)
^zh-Q0780-answer

**zh-Q0781** — 你知道去哪找汤姆吗？

Do you know where to find Tom?

Expected form: **吗**

Why: Question particles. [[Mandarin Chinese#^zh-Q0781|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E7%9F%A5%E9%81%93%E5%8E%BB%E5%93%AA%E6%89%BE%E6%B1%A4%E5%A7%86%E5%90%97%EF%BC%9F)
^zh-Q0781-answer

**zh-Q0782** — 你知道去哪找汤姆吗？

Do you know where to find Tom?

Expected form: **吗**

Why: Question particles. [[Mandarin Chinese#^zh-Q0782|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E7%9F%A5%E9%81%93%E5%8E%BB%E5%93%AA%E6%89%BE%E6%B1%A4%E5%A7%86%E5%90%97%EF%BC%9F)
^zh-Q0782-answer

**zh-Q0783** — 这个面包的保质期可以吗？

Is this bread's best-by OK?

Expected form: **吗**

Why: Question particles. [[Mandarin Chinese#^zh-Q0783|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%BF%99%E4%B8%AA%E9%9D%A2%E5%8C%85%E7%9A%84%E4%BF%9D%E8%B4%A8%E6%9C%9F%E5%8F%AF%E4%BB%A5%E5%90%97%EF%BC%9F)
^zh-Q0783-answer

**zh-Q0784** — 这个面包的保质期可以吗？

Is this bread's best-by OK?

Why: Question particles. [[Mandarin Chinese#^zh-Q0784|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%BF%99%E4%B8%AA%E9%9D%A2%E5%8C%85%E7%9A%84%E4%BF%9D%E8%B4%A8%E6%9C%9F%E5%8F%AF%E4%BB%A5%E5%90%97%EF%BC%9F)
^zh-Q0784-answer

**zh-Q0785** — 你能不说那个了吗？

Could you stop saying that?

Why: Question particles. [[Mandarin Chinese#^zh-Q0785|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E8%83%BD%E4%B8%8D%E8%AF%B4%E9%82%A3%E4%B8%AA%E4%BA%86%E5%90%97%EF%BC%9F)
^zh-Q0785-answer

**zh-Q0786** — 你能不说那个了吗？

Could you stop saying that?

吗 commonly turns a statement into a yes/no question. 呢 can ask about a topic or continuation. Question-word questions ordinarily do not add 吗 merely because they are questions.

Why: Question particles. [[Mandarin Chinese#^zh-Q0786|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E8%83%BD%E4%B8%8D%E8%AF%B4%E9%82%A3%E4%B8%AA%E4%BA%86%E5%90%97%EF%BC%9F)
^zh-Q0786-answer

**zh-Q0787** — 告诉她我在法国呢。

Tell her that I am in France.

Expected form: **呢**

Why: Question particles. [[Mandarin Chinese#^zh-Q0787|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%91%8A%E8%AF%89%E5%A5%B9%E6%88%91%E5%9C%A8%E6%B3%95%E5%9B%BD%E5%91%A2%E3%80%82)
^zh-Q0787-answer

**zh-Q0788** — 告诉她我在法国呢。

Tell her that I am in France.

Expected form: **呢**

Why: Question particles. [[Mandarin Chinese#^zh-Q0788|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%91%8A%E8%AF%89%E5%A5%B9%E6%88%91%E5%9C%A8%E6%B3%95%E5%9B%BD%E5%91%A2%E3%80%82)
^zh-Q0788-answer

**zh-Q0789** — 你是不是有能力做到你想要完成的所有事情呢？

Were you able to do everything you wanted to get done?

Expected form: **呢**

Why: Question particles. [[Mandarin Chinese#^zh-Q0789|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E6%98%AF%E4%B8%8D%E6%98%AF%E6%9C%89%E8%83%BD%E5%8A%9B%E5%81%9A%E5%88%B0%E4%BD%A0%E6%83%B3%E8%A6%81%E5%AE%8C%E6%88%90%E7%9A%84%E6%89%80%E6%9C%89%E4%BA%8B%E6%83%85%E5%91%A2%EF%BC%9F)
^zh-Q0789-answer

**zh-Q0790** — 你是不是有能力做到你想要完成的所有事情呢？

Were you able to do everything you wanted to get done?

Why: Question particles. [[Mandarin Chinese#^zh-Q0790|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E6%98%AF%E4%B8%8D%E6%98%AF%E6%9C%89%E8%83%BD%E5%8A%9B%E5%81%9A%E5%88%B0%E4%BD%A0%E6%83%B3%E8%A6%81%E5%AE%8C%E6%88%90%E7%9A%84%E6%89%80%E6%9C%89%E4%BA%8B%E6%83%85%E5%91%A2%EF%BC%9F)
^zh-Q0790-answer

**zh-Q0791** — 你知道任何关于汤姆父母的事吗？

Do you know anything about Tom's parents?

Why: Question particles. [[Mandarin Chinese#^zh-Q0791|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E7%9F%A5%E9%81%93%E4%BB%BB%E4%BD%95%E5%85%B3%E4%BA%8E%E6%B1%A4%E5%A7%86%E7%88%B6%E6%AF%8D%E7%9A%84%E4%BA%8B%E5%90%97%EF%BC%9F)
^zh-Q0791-answer

**zh-Q0792** — 你知道任何关于汤姆父母的事吗？

Do you know anything about Tom's parents?

吗 commonly turns a statement into a yes/no question. 呢 can ask about a topic or continuation. Question-word questions ordinarily do not add 吗 merely because they are questions.

Why: Question particles. [[Mandarin Chinese#^zh-Q0792|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E7%9F%A5%E9%81%93%E4%BB%BB%E4%BD%95%E5%85%B3%E4%BA%8E%E6%B1%A4%E5%A7%86%E7%88%B6%E6%AF%8D%E7%9A%84%E4%BA%8B%E5%90%97%EF%BC%9F)
^zh-Q0792-answer

**zh-Q0793** — 社会保障吗？他们在说什么笑话？

Social security? Who do they think they're kidding.

Expected form: **吗**

Why: Question particles. [[Mandarin Chinese#^zh-Q0793|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E7%A4%BE%E4%BC%9A%E4%BF%9D%E9%9A%9C%E5%90%97%EF%BC%9F%E4%BB%96%E4%BB%AC%E5%9C%A8%E8%AF%B4%E4%BB%80%E4%B9%88%E7%AC%91%E8%AF%9D%EF%BC%9F)
^zh-Q0793-answer

**zh-Q0794** — 社会保障吗？他们在说什么笑话？

Social security? Who do they think they're kidding.

Expected form: **吗**

Why: Question particles. [[Mandarin Chinese#^zh-Q0794|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E7%A4%BE%E4%BC%9A%E4%BF%9D%E9%9A%9C%E5%90%97%EF%BC%9F%E4%BB%96%E4%BB%AC%E5%9C%A8%E8%AF%B4%E4%BB%80%E4%B9%88%E7%AC%91%E8%AF%9D%EF%BC%9F)
^zh-Q0794-answer

**zh-Q0795** — 所有人都去哪儿了？有集市吗？

Where are all the people going? Is there a fair?

Expected form: **吗**

Why: Question particles. [[Mandarin Chinese#^zh-Q0795|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%89%80%E6%9C%89%E4%BA%BA%E9%83%BD%E5%8E%BB%E5%93%AA%E5%84%BF%E4%BA%86%EF%BC%9F%E6%9C%89%E9%9B%86%E5%B8%82%E5%90%97%EF%BC%9F)
^zh-Q0795-answer

**zh-Q0796** — 所有人都去哪儿了？有集市吗？

Where are all the people going? Is there a fair?

Why: Question particles. [[Mandarin Chinese#^zh-Q0796|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%89%80%E6%9C%89%E4%BA%BA%E9%83%BD%E5%8E%BB%E5%93%AA%E5%84%BF%E4%BA%86%EF%BC%9F%E6%9C%89%E9%9B%86%E5%B8%82%E5%90%97%EF%BC%9F)
^zh-Q0796-answer

**zh-Q0797** — 打扰一下，你能把糖递给我吗？

Excuse me, could you pass me the sugar?

Why: Question particles. [[Mandarin Chinese#^zh-Q0797|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%89%93%E6%89%B0%E4%B8%80%E4%B8%8B%EF%BC%8C%E4%BD%A0%E8%83%BD%E6%8A%8A%E7%B3%96%E9%80%92%E7%BB%99%E6%88%91%E5%90%97%EF%BC%9F)
^zh-Q0797-answer

**zh-Q0798** — 打扰一下，你能把糖递给我吗？

Excuse me, could you pass me the sugar?

吗 commonly turns a statement into a yes/no question. 呢 can ask about a topic or continuation. Question-word questions ordinarily do not add 吗 merely because they are questions.

Why: Question particles. [[Mandarin Chinese#^zh-Q0798|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%89%93%E6%89%B0%E4%B8%80%E4%B8%8B%EF%BC%8C%E4%BD%A0%E8%83%BD%E6%8A%8A%E7%B3%96%E9%80%92%E7%BB%99%E6%88%91%E5%90%97%EF%BC%9F)
^zh-Q0798-answer

**zh-Q0799** — 那是你昨天买的毛衣吗？

Is that the sweater you bought yesterday?

Expected form: **吗**

Why: Question particles. [[Mandarin Chinese#^zh-Q0799|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E9%82%A3%E6%98%AF%E4%BD%A0%E6%98%A8%E5%A4%A9%E4%B9%B0%E7%9A%84%E6%AF%9B%E8%A1%A3%E5%90%97%EF%BC%9F)
^zh-Q0799-answer

**zh-Q0800** — 那是你昨天买的毛衣吗？

Is that the sweater you bought yesterday?

Expected form: **吗**

Why: Question particles. [[Mandarin Chinese#^zh-Q0800|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E9%82%A3%E6%98%AF%E4%BD%A0%E6%98%A8%E5%A4%A9%E4%B9%B0%E7%9A%84%E6%AF%9B%E8%A1%A3%E5%90%97%EF%BC%9F)
^zh-Q0800-answer


### Answers 801–850

**zh-Q0801** — 你为什么为我担忧？

Why are you worried about me?

Expected form: **为什么**

Why: Question words. [[Mandarin Chinese#^zh-Q0801|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E4%B8%BA%E4%BB%80%E4%B9%88%E4%B8%BA%E6%88%91%E6%8B%85%E5%BF%A7%EF%BC%9F)
^zh-Q0801-answer

**zh-Q0802** — 你为什么为我担忧？

Why are you worried about me?

Why: Question words. [[Mandarin Chinese#^zh-Q0802|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E4%B8%BA%E4%BB%80%E4%B9%88%E4%B8%BA%E6%88%91%E6%8B%85%E5%BF%A7%EF%BC%9F)
^zh-Q0802-answer

**zh-Q0803** — 你觉得对此该做什么？

What do you think should be done about it?

Why: Question words. [[Mandarin Chinese#^zh-Q0803|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E8%A7%89%E5%BE%97%E5%AF%B9%E6%AD%A4%E8%AF%A5%E5%81%9A%E4%BB%80%E4%B9%88%EF%BC%9F)
^zh-Q0803-answer

**zh-Q0804** — 你觉得对此该做什么？

What do you think should be done about it?

Mandarin question words commonly stay in the position of the unknown information. 谁 asks a person, 哪里 a place, and 几/多少 quantities. No English-style subject-auxiliary inversion is required.

Why: Question words. [[Mandarin Chinese#^zh-Q0804|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E8%A7%89%E5%BE%97%E5%AF%B9%E6%AD%A4%E8%AF%A5%E5%81%9A%E4%BB%80%E4%B9%88%EF%BC%9F)
^zh-Q0804-answer

**zh-Q0805** — 告诉我怎么玩游戏。

Tell me how to play the game.

Expected form: **怎么**

Why: Question words. [[Mandarin Chinese#^zh-Q0805|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%91%8A%E8%AF%89%E6%88%91%E6%80%8E%E4%B9%88%E7%8E%A9%E6%B8%B8%E6%88%8F%E3%80%82)
^zh-Q0805-answer

**zh-Q0806** — 告诉我怎么玩游戏。

Tell me how to play the game.

Expected form: **怎么**

Why: Question words. [[Mandarin Chinese#^zh-Q0806|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%91%8A%E8%AF%89%E6%88%91%E6%80%8E%E4%B9%88%E7%8E%A9%E6%B8%B8%E6%88%8F%E3%80%82)
^zh-Q0806-answer

**zh-Q0807** — 最近的電話亭在哪裡？

Where is the nearest telephone box?

Expected form: **哪**

Why: Question words. [[Mandarin Chinese#^zh-Q0807|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%9C%80%E8%BF%91%E7%9A%84%E9%9B%BB%E8%A9%B1%E4%BA%AD%E5%9C%A8%E5%93%AA%E8%A3%A1%EF%BC%9F)
^zh-Q0807-answer

**zh-Q0808** — 最近的電話亭在哪裡？

Where is the nearest telephone box?

Why: Question words. [[Mandarin Chinese#^zh-Q0808|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%9C%80%E8%BF%91%E7%9A%84%E9%9B%BB%E8%A9%B1%E4%BA%AD%E5%9C%A8%E5%93%AA%E8%A3%A1%EF%BC%9F)
^zh-Q0808-answer

**zh-Q0809** — 咱们到田园去放风筝怎么样？

Let's go to the field and fly kites, what do you say?

Why: Question words. [[Mandarin Chinese#^zh-Q0809|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%92%B1%E4%BB%AC%E5%88%B0%E7%94%B0%E5%9B%AD%E5%8E%BB%E6%94%BE%E9%A3%8E%E7%AD%9D%E6%80%8E%E4%B9%88%E6%A0%B7%EF%BC%9F)
^zh-Q0809-answer

**zh-Q0810** — 咱们到田园去放风筝怎么样？

Let's go to the field and fly kites, what do you say?

Mandarin question words commonly stay in the position of the unknown information. 谁 asks a person, 哪里 a place, and 几/多少 quantities. No English-style subject-auxiliary inversion is required.

Why: Question words. [[Mandarin Chinese#^zh-Q0810|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%92%B1%E4%BB%AC%E5%88%B0%E7%94%B0%E5%9B%AD%E5%8E%BB%E6%94%BE%E9%A3%8E%E7%AD%9D%E6%80%8E%E4%B9%88%E6%A0%B7%EF%BC%9F)
^zh-Q0810-answer

**zh-Q0811** — 在埃及说什么语言？

What language is spoken in Egypt?

Expected form: **什么**

Why: Question words. [[Mandarin Chinese#^zh-Q0811|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%9C%A8%E5%9F%83%E5%8F%8A%E8%AF%B4%E4%BB%80%E4%B9%88%E8%AF%AD%E8%A8%80%EF%BC%9F)
^zh-Q0811-answer

**zh-Q0812** — 在埃及说什么语言？

What language is spoken in Egypt?

Expected form: **什么**

Why: Question words. [[Mandarin Chinese#^zh-Q0812|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%9C%A8%E5%9F%83%E5%8F%8A%E8%AF%B4%E4%BB%80%E4%B9%88%E8%AF%AD%E8%A8%80%EF%BC%9F)
^zh-Q0812-answer

**zh-Q0813** — 你什么时候开始工作?

What time do you start work?

Expected form: **什么**

Why: Question words. [[Mandarin Chinese#^zh-Q0813|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E4%BB%80%E4%B9%88%E6%97%B6%E5%80%99%E5%BC%80%E5%A7%8B%E5%B7%A5%E4%BD%9C%3F)
^zh-Q0813-answer

**zh-Q0814** — 你什么时候开始工作?

What time do you start work?

Why: Question words. [[Mandarin Chinese#^zh-Q0814|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E4%BB%80%E4%B9%88%E6%97%B6%E5%80%99%E5%BC%80%E5%A7%8B%E5%B7%A5%E4%BD%9C%3F)
^zh-Q0814-answer

**zh-Q0815** — 她是怎么抚养孩子的？

How does she bring up her children?

Why: Question words. [[Mandarin Chinese#^zh-Q0815|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A5%B9%E6%98%AF%E6%80%8E%E4%B9%88%E6%8A%9A%E5%85%BB%E5%AD%A9%E5%AD%90%E7%9A%84%EF%BC%9F)
^zh-Q0815-answer

**zh-Q0816** — 她是怎么抚养孩子的？

How does she bring up her children?

Mandarin question words commonly stay in the position of the unknown information. 谁 asks a person, 哪里 a place, and 几/多少 quantities. No English-style subject-auxiliary inversion is required.

Why: Question words. [[Mandarin Chinese#^zh-Q0816|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A5%B9%E6%98%AF%E6%80%8E%E4%B9%88%E6%8A%9A%E5%85%BB%E5%AD%A9%E5%AD%90%E7%9A%84%EF%BC%9F)
^zh-Q0816-answer

**zh-Q0817** — 他似乎什么都知道。

It seems to have that he knows everything.

Expected form: **什么**

Why: Question words. [[Mandarin Chinese#^zh-Q0817|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%96%E4%BC%BC%E4%B9%8E%E4%BB%80%E4%B9%88%E9%83%BD%E7%9F%A5%E9%81%93%E3%80%82)
^zh-Q0817-answer

**zh-Q0818** — 他似乎什么都知道。

It seems to have that he knows everything.

Expected form: **什么**

Why: Question words. [[Mandarin Chinese#^zh-Q0818|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%96%E4%BC%BC%E4%B9%8E%E4%BB%80%E4%B9%88%E9%83%BD%E7%9F%A5%E9%81%93%E3%80%82)
^zh-Q0818-answer

**zh-Q0819** — 你的电脑有什么问题？

What's the problem with your computer?

Expected form: **什么**

Why: Question words. [[Mandarin Chinese#^zh-Q0819|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E7%9A%84%E7%94%B5%E8%84%91%E6%9C%89%E4%BB%80%E4%B9%88%E9%97%AE%E9%A2%98%EF%BC%9F)
^zh-Q0819-answer

**zh-Q0820** — 你的电脑有什么问题？

What's the problem with your computer?

Why: Question words. [[Mandarin Chinese#^zh-Q0820|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E7%9A%84%E7%94%B5%E8%84%91%E6%9C%89%E4%BB%80%E4%B9%88%E9%97%AE%E9%A2%98%EF%BC%9F)
^zh-Q0820-answer

**zh-Q0821** — 你最喜歡哪一個作曲家？

Who is your favorite composer?

Why: Question words. [[Mandarin Chinese#^zh-Q0821|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E6%9C%80%E5%96%9C%E6%AD%A1%E5%93%AA%E4%B8%80%E5%80%8B%E4%BD%9C%E6%9B%B2%E5%AE%B6%EF%BC%9F)
^zh-Q0821-answer

**zh-Q0822** — 你最喜歡哪一個作曲家？

Who is your favorite composer?

Mandarin question words commonly stay in the position of the unknown information. 谁 asks a person, 哪里 a place, and 几/多少 quantities. No English-style subject-auxiliary inversion is required.

Why: Question words. [[Mandarin Chinese#^zh-Q0822|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E6%9C%80%E5%96%9C%E6%AD%A1%E5%93%AA%E4%B8%80%E5%80%8B%E4%BD%9C%E6%9B%B2%E5%AE%B6%EF%BC%9F)
^zh-Q0822-answer

**zh-Q0823** — 汤姆说他不确定玛丽想做什么。

Tom said he wasn't sure what Mary wanted to do.

Expected form: **什么**

Why: Question words. [[Mandarin Chinese#^zh-Q0823|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%B1%A4%E5%A7%86%E8%AF%B4%E4%BB%96%E4%B8%8D%E7%A1%AE%E5%AE%9A%E7%8E%9B%E4%B8%BD%E6%83%B3%E5%81%9A%E4%BB%80%E4%B9%88%E3%80%82)
^zh-Q0823-answer

**zh-Q0824** — 汤姆说他不确定玛丽想做什么。

Tom said he wasn't sure what Mary wanted to do.

Expected form: **什么**

Why: Question words. [[Mandarin Chinese#^zh-Q0824|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%B1%A4%E5%A7%86%E8%AF%B4%E4%BB%96%E4%B8%8D%E7%A1%AE%E5%AE%9A%E7%8E%9B%E4%B8%BD%E6%83%B3%E5%81%9A%E4%BB%80%E4%B9%88%E3%80%82)
^zh-Q0824-answer

**zh-Q0825** — 他跟你说什么，你就做什么。

Do whatever he tells you.

Expected form: **什么**

Why: Question words. [[Mandarin Chinese#^zh-Q0825|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%96%E8%B7%9F%E4%BD%A0%E8%AF%B4%E4%BB%80%E4%B9%88%EF%BC%8C%E4%BD%A0%E5%B0%B1%E5%81%9A%E4%BB%80%E4%B9%88%E3%80%82)
^zh-Q0825-answer

**zh-Q0826** — 他跟你说什么，你就做什么。

Do whatever he tells you.

Why: Question words. [[Mandarin Chinese#^zh-Q0826|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%96%E8%B7%9F%E4%BD%A0%E8%AF%B4%E4%BB%80%E4%B9%88%EF%BC%8C%E4%BD%A0%E5%B0%B1%E5%81%9A%E4%BB%80%E4%B9%88%E3%80%82)
^zh-Q0826-answer

**zh-Q0827** — 你到底在这做什么？

What exactly are you doing?

Why: Question words. [[Mandarin Chinese#^zh-Q0827|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E5%88%B0%E5%BA%95%E5%9C%A8%E8%BF%99%E5%81%9A%E4%BB%80%E4%B9%88%EF%BC%9F)
^zh-Q0827-answer

**zh-Q0828** — 你到底在这做什么？

What exactly are you doing?

Mandarin question words commonly stay in the position of the unknown information. 谁 asks a person, 哪里 a place, and 几/多少 quantities. No English-style subject-auxiliary inversion is required.

Why: Question words. [[Mandarin Chinese#^zh-Q0828|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E5%88%B0%E5%BA%95%E5%9C%A8%E8%BF%99%E5%81%9A%E4%BB%80%E4%B9%88%EF%BC%9F)
^zh-Q0828-answer

**zh-Q0829** — 我不知道现在应该做什么。

I don't know what I should do now.

Expected form: **什么**

Why: Question words. [[Mandarin Chinese#^zh-Q0829|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E4%B8%8D%E7%9F%A5%E9%81%93%E7%8E%B0%E5%9C%A8%E5%BA%94%E8%AF%A5%E5%81%9A%E4%BB%80%E4%B9%88%E3%80%82)
^zh-Q0829-answer

**zh-Q0830** — 我不知道现在应该做什么。

I don't know what I should do now.

Expected form: **什么**

Why: Question words. [[Mandarin Chinese#^zh-Q0830|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E4%B8%8D%E7%9F%A5%E9%81%93%E7%8E%B0%E5%9C%A8%E5%BA%94%E8%AF%A5%E5%81%9A%E4%BB%80%E4%B9%88%E3%80%82)
^zh-Q0830-answer

**zh-Q0831** — 为什么你企图逃走？

Why did you try to run away?

Expected form: **为什么**

Why: Question words. [[Mandarin Chinese#^zh-Q0831|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%B8%BA%E4%BB%80%E4%B9%88%E4%BD%A0%E4%BC%81%E5%9B%BE%E9%80%83%E8%B5%B0%EF%BC%9F)
^zh-Q0831-answer

**zh-Q0832** — 为什么你企图逃走？

Why did you try to run away?

Why: Question words. [[Mandarin Chinese#^zh-Q0832|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%B8%BA%E4%BB%80%E4%B9%88%E4%BD%A0%E4%BC%81%E5%9B%BE%E9%80%83%E8%B5%B0%EF%BC%9F)
^zh-Q0832-answer

**zh-Q0833** — 我们不能选择从哪里来，却能选择往哪里去。

We can't choose where we come from, but we can choose where we go from there.

Why: Question words. [[Mandarin Chinese#^zh-Q0833|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E4%BB%AC%E4%B8%8D%E8%83%BD%E9%80%89%E6%8B%A9%E4%BB%8E%E5%93%AA%E9%87%8C%E6%9D%A5%EF%BC%8C%E5%8D%B4%E8%83%BD%E9%80%89%E6%8B%A9%E5%BE%80%E5%93%AA%E9%87%8C%E5%8E%BB%E3%80%82)
^zh-Q0833-answer

**zh-Q0834** — 我们不能选择从哪里来，却能选择往哪里去。

We can't choose where we come from, but we can choose where we go from there.

Mandarin question words commonly stay in the position of the unknown information. 谁 asks a person, 哪里 a place, and 几/多少 quantities. No English-style subject-auxiliary inversion is required.

Why: Question words. [[Mandarin Chinese#^zh-Q0834|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E4%BB%AC%E4%B8%8D%E8%83%BD%E9%80%89%E6%8B%A9%E4%BB%8E%E5%93%AA%E9%87%8C%E6%9D%A5%EF%BC%8C%E5%8D%B4%E8%83%BD%E9%80%89%E6%8B%A9%E5%BE%80%E5%93%AA%E9%87%8C%E5%8E%BB%E3%80%82)
^zh-Q0834-answer

**zh-Q0835** — 最大可能假想事故什么时候会发生？

When will the most probable hypothetical accident occur?

Expected form: **什么**

Why: Question words. [[Mandarin Chinese#^zh-Q0835|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%9C%80%E5%A4%A7%E5%8F%AF%E8%83%BD%E5%81%87%E6%83%B3%E4%BA%8B%E6%95%85%E4%BB%80%E4%B9%88%E6%97%B6%E5%80%99%E4%BC%9A%E5%8F%91%E7%94%9F%EF%BC%9F)
^zh-Q0835-answer

**zh-Q0836** — 最大可能假想事故什么时候会发生？

When will the most probable hypothetical accident occur?

Expected form: **什么**

Why: Question words. [[Mandarin Chinese#^zh-Q0836|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%9C%80%E5%A4%A7%E5%8F%AF%E8%83%BD%E5%81%87%E6%83%B3%E4%BA%8B%E6%95%85%E4%BB%80%E4%B9%88%E6%97%B6%E5%80%99%E4%BC%9A%E5%8F%91%E7%94%9F%EF%BC%9F)
^zh-Q0836-answer

**zh-Q0837** — 不管我跟她说了多少次，她还是继续犯同样的错误。

No matter how often I tell her, she keeps making the same mistake.

Expected form: **多少**

Why: Question words. [[Mandarin Chinese#^zh-Q0837|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%B8%8D%E7%AE%A1%E6%88%91%E8%B7%9F%E5%A5%B9%E8%AF%B4%E4%BA%86%E5%A4%9A%E5%B0%91%E6%AC%A1%EF%BC%8C%E5%A5%B9%E8%BF%98%E6%98%AF%E7%BB%A7%E7%BB%AD%E7%8A%AF%E5%90%8C%E6%A0%B7%E7%9A%84%E9%94%99%E8%AF%AF%E3%80%82)
^zh-Q0837-answer

**zh-Q0838** — 不管我跟她说了多少次，她还是继续犯同样的错误。

No matter how often I tell her, she keeps making the same mistake.

Why: Question words. [[Mandarin Chinese#^zh-Q0838|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%B8%8D%E7%AE%A1%E6%88%91%E8%B7%9F%E5%A5%B9%E8%AF%B4%E4%BA%86%E5%A4%9A%E5%B0%91%E6%AC%A1%EF%BC%8C%E5%A5%B9%E8%BF%98%E6%98%AF%E7%BB%A7%E7%BB%AD%E7%8A%AF%E5%90%8C%E6%A0%B7%E7%9A%84%E9%94%99%E8%AF%AF%E3%80%82)
^zh-Q0838-answer

**zh-Q0839** — 你用什么方式减压？

How do you relieve stress?

Why: Question words. [[Mandarin Chinese#^zh-Q0839|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E7%94%A8%E4%BB%80%E4%B9%88%E6%96%B9%E5%BC%8F%E5%87%8F%E5%8E%8B%EF%BC%9F)
^zh-Q0839-answer

**zh-Q0840** — 你用什么方式减压？

How do you relieve stress?

Mandarin question words commonly stay in the position of the unknown information. 谁 asks a person, 哪里 a place, and 几/多少 quantities. No English-style subject-auxiliary inversion is required.

Why: Question words. [[Mandarin Chinese#^zh-Q0840|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E7%94%A8%E4%BB%80%E4%B9%88%E6%96%B9%E5%BC%8F%E5%87%8F%E5%8E%8B%EF%BC%9F)
^zh-Q0840-answer

**zh-Q0841** — 我不知道该说什么。

I don't know what to say.

Expected form: **什么**

Why: Question words. [[Mandarin Chinese#^zh-Q0841|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E4%B8%8D%E7%9F%A5%E9%81%93%E8%AF%A5%E8%AF%B4%E4%BB%80%E4%B9%88%E3%80%82)
^zh-Q0841-answer

**zh-Q0842** — 我不知道该说什么。

I don't know what to say.

Expected form: **什么**

Why: Question words. [[Mandarin Chinese#^zh-Q0842|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E4%B8%8D%E7%9F%A5%E9%81%93%E8%AF%A5%E8%AF%B4%E4%BB%80%E4%B9%88%E3%80%82)
^zh-Q0842-answer

**zh-Q0843** — 我不懂你在说什么。

I don't understand what you are saying.

Expected form: **什么**

Why: Question words. [[Mandarin Chinese#^zh-Q0843|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E4%B8%8D%E6%87%82%E4%BD%A0%E5%9C%A8%E8%AF%B4%E4%BB%80%E4%B9%88%E3%80%82)
^zh-Q0843-answer

**zh-Q0844** — 我不懂你在说什么。

I don't understand what you are saying.

Why: Question words. [[Mandarin Chinese#^zh-Q0844|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E4%B8%8D%E6%87%82%E4%BD%A0%E5%9C%A8%E8%AF%B4%E4%BB%80%E4%B9%88%E3%80%82)
^zh-Q0844-answer

**zh-Q0845** — 别慌。这没什么的。

Don't get agitated. It's nothing.

Why: Question words. [[Mandarin Chinese#^zh-Q0845|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%88%AB%E6%85%8C%E3%80%82%E8%BF%99%E6%B2%A1%E4%BB%80%E4%B9%88%E7%9A%84%E3%80%82)
^zh-Q0845-answer

**zh-Q0846** — 别慌。这没什么的。

Don't get agitated. It's nothing.

Mandarin question words commonly stay in the position of the unknown information. 谁 asks a person, 哪里 a place, and 几/多少 quantities. No English-style subject-auxiliary inversion is required.

Why: Question words. [[Mandarin Chinese#^zh-Q0846|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%88%AB%E6%85%8C%E3%80%82%E8%BF%99%E6%B2%A1%E4%BB%80%E4%B9%88%E7%9A%84%E3%80%82)
^zh-Q0846-answer

**zh-Q0847** — 选择什么是“对”或“错”是一项艰难的任务，我们却必须要完成它。

It is a difficult task, choosing what is "right" or "wrong", but you have to do it.

Expected form: **什么**

Why: Question words. [[Mandarin Chinese#^zh-Q0847|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E9%80%89%E6%8B%A9%E4%BB%80%E4%B9%88%E6%98%AF%E2%80%9C%E5%AF%B9%E2%80%9D%E6%88%96%E2%80%9C%E9%94%99%E2%80%9D%E6%98%AF%E4%B8%80%E9%A1%B9%E8%89%B0%E9%9A%BE%E7%9A%84%E4%BB%BB%E5%8A%A1%EF%BC%8C%E6%88%91%E4%BB%AC%E5%8D%B4%E5%BF%85%E9%A1%BB%E8%A6%81%E5%AE%8C%E6%88%90%E5%AE%83%E3%80%82)
^zh-Q0847-answer

**zh-Q0848** — 选择什么是“对”或“错”是一项艰难的任务，我们却必须要完成它。

It is a difficult task, choosing what is "right" or "wrong", but you have to do it.

Expected form: **什么**

Why: Question words. [[Mandarin Chinese#^zh-Q0848|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E9%80%89%E6%8B%A9%E4%BB%80%E4%B9%88%E6%98%AF%E2%80%9C%E5%AF%B9%E2%80%9D%E6%88%96%E2%80%9C%E9%94%99%E2%80%9D%E6%98%AF%E4%B8%80%E9%A1%B9%E8%89%B0%E9%9A%BE%E7%9A%84%E4%BB%BB%E5%8A%A1%EF%BC%8C%E6%88%91%E4%BB%AC%E5%8D%B4%E5%BF%85%E9%A1%BB%E8%A6%81%E5%AE%8C%E6%88%90%E5%AE%83%E3%80%82)
^zh-Q0848-answer

**zh-Q0849** — 湯姆不能決定從哪裡開始。

Tom couldn't decide where to begin.

Expected form: **哪**

Why: Question words. [[Mandarin Chinese#^zh-Q0849|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%B9%AF%E5%A7%86%E4%B8%8D%E8%83%BD%E6%B1%BA%E5%AE%9A%E5%BE%9E%E5%93%AA%E8%A3%A1%E9%96%8B%E5%A7%8B%E3%80%82)
^zh-Q0849-answer

**zh-Q0850** — 湯姆不能決定從哪裡開始。

Tom couldn't decide where to begin.

Why: Question words. [[Mandarin Chinese#^zh-Q0850|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%B9%AF%E5%A7%86%E4%B8%8D%E8%83%BD%E6%B1%BA%E5%AE%9A%E5%BE%9E%E5%93%AA%E8%A3%A1%E9%96%8B%E5%A7%8B%E3%80%82)
^zh-Q0850-answer


### Answers 851–900

**zh-Q0851** — 虽然听起来很奇怪，但是她说的的确是真的。

Even though it sounds strange, what she said is true.

Why: Conditions and concession. [[Mandarin Chinese#^zh-Q0851|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%99%BD%E7%84%B6%E5%90%AC%E8%B5%B7%E6%9D%A5%E5%BE%88%E5%A5%87%E6%80%AA%EF%BC%8C%E4%BD%86%E6%98%AF%E5%A5%B9%E8%AF%B4%E7%9A%84%E7%9A%84%E7%A1%AE%E6%98%AF%E7%9C%9F%E7%9A%84%E3%80%82)
^zh-Q0851-answer

**zh-Q0852** — 虽然听起来很奇怪，但是她说的的确是真的。

Even though it sounds strange, what she said is true.

如果/要是 introduce conditions; 虽然 presents concession, often paired with 但是. 的话 can frame an if scenario. Connectors express relationships, not tense inflections.

Why: Conditions and concession. [[Mandarin Chinese#^zh-Q0852|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%99%BD%E7%84%B6%E5%90%AC%E8%B5%B7%E6%9D%A5%E5%BE%88%E5%A5%87%E6%80%AA%EF%BC%8C%E4%BD%86%E6%98%AF%E5%A5%B9%E8%AF%B4%E7%9A%84%E7%9A%84%E7%A1%AE%E6%98%AF%E7%9C%9F%E7%9A%84%E3%80%82)
^zh-Q0852-answer

**zh-Q0853** — 如果你想使他人相信你的话，那就只说他已经相信的东西吧。

If you want to be credible, tell people only what they believe.

Expected form: **如果**

Why: Conditions and concession. [[Mandarin Chinese#^zh-Q0853|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A6%82%E6%9E%9C%E4%BD%A0%E6%83%B3%E4%BD%BF%E4%BB%96%E4%BA%BA%E7%9B%B8%E4%BF%A1%E4%BD%A0%E7%9A%84%E8%AF%9D%EF%BC%8C%E9%82%A3%E5%B0%B1%E5%8F%AA%E8%AF%B4%E4%BB%96%E5%B7%B2%E7%BB%8F%E7%9B%B8%E4%BF%A1%E7%9A%84%E4%B8%9C%E8%A5%BF%E5%90%A7%E3%80%82)
^zh-Q0853-answer

**zh-Q0854** — 如果你想使他人相信你的话，那就只说他已经相信的东西吧。

If you want to be credible, tell people only what they believe.

Expected form: **如果**

Why: Conditions and concession. [[Mandarin Chinese#^zh-Q0854|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A6%82%E6%9E%9C%E4%BD%A0%E6%83%B3%E4%BD%BF%E4%BB%96%E4%BA%BA%E7%9B%B8%E4%BF%A1%E4%BD%A0%E7%9A%84%E8%AF%9D%EF%BC%8C%E9%82%A3%E5%B0%B1%E5%8F%AA%E8%AF%B4%E4%BB%96%E5%B7%B2%E7%BB%8F%E7%9B%B8%E4%BF%A1%E7%9A%84%E4%B8%9C%E8%A5%BF%E5%90%A7%E3%80%82)
^zh-Q0854-answer

**zh-Q0855** — 根据你所说的话，我认为我们应该重新审视我们的计划。

In the light of what you told us, I think we should revise our plan.

Expected form: **的话**

Why: Conditions and concession. [[Mandarin Chinese#^zh-Q0855|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%A0%B9%E6%8D%AE%E4%BD%A0%E6%89%80%E8%AF%B4%E7%9A%84%E8%AF%9D%EF%BC%8C%E6%88%91%E8%AE%A4%E4%B8%BA%E6%88%91%E4%BB%AC%E5%BA%94%E8%AF%A5%E9%87%8D%E6%96%B0%E5%AE%A1%E8%A7%86%E6%88%91%E4%BB%AC%E7%9A%84%E8%AE%A1%E5%88%92%E3%80%82)
^zh-Q0855-answer

**zh-Q0856** — 根据你所说的话，我认为我们应该重新审视我们的计划。

In the light of what you told us, I think we should revise our plan.

Why: Conditions and concession. [[Mandarin Chinese#^zh-Q0856|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%A0%B9%E6%8D%AE%E4%BD%A0%E6%89%80%E8%AF%B4%E7%9A%84%E8%AF%9D%EF%BC%8C%E6%88%91%E8%AE%A4%E4%B8%BA%E6%88%91%E4%BB%AC%E5%BA%94%E8%AF%A5%E9%87%8D%E6%96%B0%E5%AE%A1%E8%A7%86%E6%88%91%E4%BB%AC%E7%9A%84%E8%AE%A1%E5%88%92%E3%80%82)
^zh-Q0856-answer

**zh-Q0857** — 如果你想，你可以來。

You may come if you like.

Why: Conditions and concession. [[Mandarin Chinese#^zh-Q0857|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A6%82%E6%9E%9C%E4%BD%A0%E6%83%B3%EF%BC%8C%E4%BD%A0%E5%8F%AF%E4%BB%A5%E4%BE%86%E3%80%82)
^zh-Q0857-answer

**zh-Q0858** — 如果你想，你可以來。

You may come if you like.

如果/要是 introduce conditions; 虽然 presents concession, often paired with 但是. 的话 can frame an if scenario. Connectors express relationships, not tense inflections.

Why: Conditions and concession. [[Mandarin Chinese#^zh-Q0858|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A6%82%E6%9E%9C%E4%BD%A0%E6%83%B3%EF%BC%8C%E4%BD%A0%E5%8F%AF%E4%BB%A5%E4%BE%86%E3%80%82)
^zh-Q0858-answer

**zh-Q0859** — 如果發生了甚麼事，馬上打電話給我。

In case anything happens, call me immediately.

Expected form: **如果**

Why: Conditions and concession. [[Mandarin Chinese#^zh-Q0859|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A6%82%E6%9E%9C%E7%99%BC%E7%94%9F%E4%BA%86%E7%94%9A%E9%BA%BC%E4%BA%8B%EF%BC%8C%E9%A6%AC%E4%B8%8A%E6%89%93%E9%9B%BB%E8%A9%B1%E7%B5%A6%E6%88%91%E3%80%82)
^zh-Q0859-answer

**zh-Q0860** — 如果發生了甚麼事，馬上打電話給我。

In case anything happens, call me immediately.

Expected form: **如果**

Why: Conditions and concession. [[Mandarin Chinese#^zh-Q0860|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A6%82%E6%9E%9C%E7%99%BC%E7%94%9F%E4%BA%86%E7%94%9A%E9%BA%BC%E4%BA%8B%EF%BC%8C%E9%A6%AC%E4%B8%8A%E6%89%93%E9%9B%BB%E8%A9%B1%E7%B5%A6%E6%88%91%E3%80%82)
^zh-Q0860-answer

**zh-Q0861** — 如果明天下雨，我们就坐车去那儿。

If it's raining tomorrow, then we'll go there in the car.

Expected form: **如果**

Why: Conditions and concession. [[Mandarin Chinese#^zh-Q0861|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A6%82%E6%9E%9C%E6%98%8E%E5%A4%A9%E4%B8%8B%E9%9B%A8%EF%BC%8C%E6%88%91%E4%BB%AC%E5%B0%B1%E5%9D%90%E8%BD%A6%E5%8E%BB%E9%82%A3%E5%84%BF%E3%80%82)
^zh-Q0861-answer

**zh-Q0862** — 如果明天下雨，我们就坐车去那儿。

If it's raining tomorrow, then we'll go there in the car.

Why: Conditions and concession. [[Mandarin Chinese#^zh-Q0862|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A6%82%E6%9E%9C%E6%98%8E%E5%A4%A9%E4%B8%8B%E9%9B%A8%EF%BC%8C%E6%88%91%E4%BB%AC%E5%B0%B1%E5%9D%90%E8%BD%A6%E5%8E%BB%E9%82%A3%E5%84%BF%E3%80%82)
^zh-Q0862-answer

**zh-Q0863** — 如果明天天氣好，我們就去野餐。

If the weather is nice tomorrow, we will have a picnic.

Why: Conditions and concession. [[Mandarin Chinese#^zh-Q0863|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A6%82%E6%9E%9C%E6%98%8E%E5%A4%A9%E5%A4%A9%E6%B0%A3%E5%A5%BD%EF%BC%8C%E6%88%91%E5%80%91%E5%B0%B1%E5%8E%BB%E9%87%8E%E9%A4%90%E3%80%82)
^zh-Q0863-answer

**zh-Q0864** — 如果明天天氣好，我們就去野餐。

If the weather is nice tomorrow, we will have a picnic.

如果/要是 introduce conditions; 虽然 presents concession, often paired with 但是. 的话 can frame an if scenario. Connectors express relationships, not tense inflections.

Why: Conditions and concession. [[Mandarin Chinese#^zh-Q0864|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A6%82%E6%9E%9C%E6%98%8E%E5%A4%A9%E5%A4%A9%E6%B0%A3%E5%A5%BD%EF%BC%8C%E6%88%91%E5%80%91%E5%B0%B1%E5%8E%BB%E9%87%8E%E9%A4%90%E3%80%82)
^zh-Q0864-answer

**zh-Q0865** — 如果你想考試合格的話，就要努力溫習了。

You'll have to work hard if you want to pass the exam.

Expected form: **如果**

Why: Conditions and concession. [[Mandarin Chinese#^zh-Q0865|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A6%82%E6%9E%9C%E4%BD%A0%E6%83%B3%E8%80%83%E8%A9%A6%E5%90%88%E6%A0%BC%E7%9A%84%E8%A9%B1%EF%BC%8C%E5%B0%B1%E8%A6%81%E5%8A%AA%E5%8A%9B%E6%BA%AB%E7%BF%92%E4%BA%86%E3%80%82)
^zh-Q0865-answer

**zh-Q0866** — 如果你想考試合格的話，就要努力溫習了。

You'll have to work hard if you want to pass the exam.

Expected form: **如果**

Why: Conditions and concession. [[Mandarin Chinese#^zh-Q0866|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A6%82%E6%9E%9C%E4%BD%A0%E6%83%B3%E8%80%83%E8%A9%A6%E5%90%88%E6%A0%BC%E7%9A%84%E8%A9%B1%EF%BC%8C%E5%B0%B1%E8%A6%81%E5%8A%AA%E5%8A%9B%E6%BA%AB%E7%BF%92%E4%BA%86%E3%80%82)
^zh-Q0866-answer

**zh-Q0867** — 你如果有疑问，就问汤姆吧。

Ask Tom if you have any doubt.

Expected form: **如果**

Why: Conditions and concession. [[Mandarin Chinese#^zh-Q0867|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E5%A6%82%E6%9E%9C%E6%9C%89%E7%96%91%E9%97%AE%EF%BC%8C%E5%B0%B1%E9%97%AE%E6%B1%A4%E5%A7%86%E5%90%A7%E3%80%82)
^zh-Q0867-answer

**zh-Q0868** — 你如果有疑问，就问汤姆吧。

Ask Tom if you have any doubt.

Why: Conditions and concession. [[Mandarin Chinese#^zh-Q0868|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E5%A6%82%E6%9E%9C%E6%9C%89%E7%96%91%E9%97%AE%EF%BC%8C%E5%B0%B1%E9%97%AE%E6%B1%A4%E5%A7%86%E5%90%A7%E3%80%82)
^zh-Q0868-answer

**zh-Q0869** — 汤姆不想的话他是没必要留下的。

Tom didn't need to stay if he didn't want to.

Why: Conditions and concession. [[Mandarin Chinese#^zh-Q0869|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%B1%A4%E5%A7%86%E4%B8%8D%E6%83%B3%E7%9A%84%E8%AF%9D%E4%BB%96%E6%98%AF%E6%B2%A1%E5%BF%85%E8%A6%81%E7%95%99%E4%B8%8B%E7%9A%84%E3%80%82)
^zh-Q0869-answer

**zh-Q0870** — 汤姆不想的话他是没必要留下的。

Tom didn't need to stay if he didn't want to.

如果/要是 introduce conditions; 虽然 presents concession, often paired with 但是. 的话 can frame an if scenario. Connectors express relationships, not tense inflections.

Why: Conditions and concession. [[Mandarin Chinese#^zh-Q0870|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%B1%A4%E5%A7%86%E4%B8%8D%E6%83%B3%E7%9A%84%E8%AF%9D%E4%BB%96%E6%98%AF%E6%B2%A1%E5%BF%85%E8%A6%81%E7%95%99%E4%B8%8B%E7%9A%84%E3%80%82)
^zh-Q0870-answer

**zh-Q0871** — 如果我知道的话，我早就已经告诉你了。

Had I known about it, I would have told you.

Expected form: **如果**

Why: Conditions and concession. [[Mandarin Chinese#^zh-Q0871|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A6%82%E6%9E%9C%E6%88%91%E7%9F%A5%E9%81%93%E7%9A%84%E8%AF%9D%EF%BC%8C%E6%88%91%E6%97%A9%E5%B0%B1%E5%B7%B2%E7%BB%8F%E5%91%8A%E8%AF%89%E4%BD%A0%E4%BA%86%E3%80%82)
^zh-Q0871-answer

**zh-Q0872** — 如果我知道的话，我早就已经告诉你了。

Had I known about it, I would have told you.

Expected form: **如果**

Why: Conditions and concession. [[Mandarin Chinese#^zh-Q0872|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A6%82%E6%9E%9C%E6%88%91%E7%9F%A5%E9%81%93%E7%9A%84%E8%AF%9D%EF%BC%8C%E6%88%91%E6%97%A9%E5%B0%B1%E5%B7%B2%E7%BB%8F%E5%91%8A%E8%AF%89%E4%BD%A0%E4%BA%86%E3%80%82)
^zh-Q0872-answer

**zh-Q0873** — 如果你想去，就去好了。如果你不想去，那也没什么大不了的。

If you want to go, then go. If you don't want to, then it's no big deal.

Expected form: **如果**

Why: Conditions and concession. [[Mandarin Chinese#^zh-Q0873|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A6%82%E6%9E%9C%E4%BD%A0%E6%83%B3%E5%8E%BB%EF%BC%8C%E5%B0%B1%E5%8E%BB%E5%A5%BD%E4%BA%86%E3%80%82%E5%A6%82%E6%9E%9C%E4%BD%A0%E4%B8%8D%E6%83%B3%E5%8E%BB%EF%BC%8C%E9%82%A3%E4%B9%9F%E6%B2%A1%E4%BB%80%E4%B9%88%E5%A4%A7%E4%B8%8D%E4%BA%86%E7%9A%84%E3%80%82)
^zh-Q0873-answer

**zh-Q0874** — 如果你想去，就去好了。如果你不想去，那也没什么大不了的。

If you want to go, then go. If you don't want to, then it's no big deal.

Why: Conditions and concession. [[Mandarin Chinese#^zh-Q0874|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A6%82%E6%9E%9C%E4%BD%A0%E6%83%B3%E5%8E%BB%EF%BC%8C%E5%B0%B1%E5%8E%BB%E5%A5%BD%E4%BA%86%E3%80%82%E5%A6%82%E6%9E%9C%E4%BD%A0%E4%B8%8D%E6%83%B3%E5%8E%BB%EF%BC%8C%E9%82%A3%E4%B9%9F%E6%B2%A1%E4%BB%80%E4%B9%88%E5%A4%A7%E4%B8%8D%E4%BA%86%E7%9A%84%E3%80%82)
^zh-Q0874-answer

**zh-Q0875** — 虽然我知道从网上免费下载音乐是不对的，但我还是照样下载。

I know that downloading music from the internet without paying is wrong, but I do it anyway.

Why: Conditions and concession. [[Mandarin Chinese#^zh-Q0875|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%99%BD%E7%84%B6%E6%88%91%E7%9F%A5%E9%81%93%E4%BB%8E%E7%BD%91%E4%B8%8A%E5%85%8D%E8%B4%B9%E4%B8%8B%E8%BD%BD%E9%9F%B3%E4%B9%90%E6%98%AF%E4%B8%8D%E5%AF%B9%E7%9A%84%EF%BC%8C%E4%BD%86%E6%88%91%E8%BF%98%E6%98%AF%E7%85%A7%E6%A0%B7%E4%B8%8B%E8%BD%BD%E3%80%82)
^zh-Q0875-answer

**zh-Q0876** — 虽然我知道从网上免费下载音乐是不对的，但我还是照样下载。

I know that downloading music from the internet without paying is wrong, but I do it anyway.

如果/要是 introduce conditions; 虽然 presents concession, often paired with 但是. 的话 can frame an if scenario. Connectors express relationships, not tense inflections.

Why: Conditions and concession. [[Mandarin Chinese#^zh-Q0876|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%99%BD%E7%84%B6%E6%88%91%E7%9F%A5%E9%81%93%E4%BB%8E%E7%BD%91%E4%B8%8A%E5%85%8D%E8%B4%B9%E4%B8%8B%E8%BD%BD%E9%9F%B3%E4%B9%90%E6%98%AF%E4%B8%8D%E5%AF%B9%E7%9A%84%EF%BC%8C%E4%BD%86%E6%88%91%E8%BF%98%E6%98%AF%E7%85%A7%E6%A0%B7%E4%B8%8B%E8%BD%BD%E3%80%82)
^zh-Q0876-answer

**zh-Q0877** — 如果你尝试的话，你会成功的。

You'll succeed if you try.

Expected form: **如果**

Why: Conditions and concession. [[Mandarin Chinese#^zh-Q0877|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A6%82%E6%9E%9C%E4%BD%A0%E5%B0%9D%E8%AF%95%E7%9A%84%E8%AF%9D%EF%BC%8C%E4%BD%A0%E4%BC%9A%E6%88%90%E5%8A%9F%E7%9A%84%E3%80%82)
^zh-Q0877-answer

**zh-Q0878** — 如果你尝试的话，你会成功的。

You'll succeed if you try.

Expected form: **如果**

Why: Conditions and concession. [[Mandarin Chinese#^zh-Q0878|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A6%82%E6%9E%9C%E4%BD%A0%E5%B0%9D%E8%AF%95%E7%9A%84%E8%AF%9D%EF%BC%8C%E4%BD%A0%E4%BC%9A%E6%88%90%E5%8A%9F%E7%9A%84%E3%80%82)
^zh-Q0878-answer

**zh-Q0879** — 如果你认真学习，就有希望通过考试。

If you study earnestly, you can expect to pass the exam.

Expected form: **如果**

Why: Conditions and concession. [[Mandarin Chinese#^zh-Q0879|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A6%82%E6%9E%9C%E4%BD%A0%E8%AE%A4%E7%9C%9F%E5%AD%A6%E4%B9%A0%EF%BC%8C%E5%B0%B1%E6%9C%89%E5%B8%8C%E6%9C%9B%E9%80%9A%E8%BF%87%E8%80%83%E8%AF%95%E3%80%82)
^zh-Q0879-answer

**zh-Q0880** — 如果你认真学习，就有希望通过考试。

If you study earnestly, you can expect to pass the exam.

Why: Conditions and concession. [[Mandarin Chinese#^zh-Q0880|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A6%82%E6%9E%9C%E4%BD%A0%E8%AE%A4%E7%9C%9F%E5%AD%A6%E4%B9%A0%EF%BC%8C%E5%B0%B1%E6%9C%89%E5%B8%8C%E6%9C%9B%E9%80%9A%E8%BF%87%E8%80%83%E8%AF%95%E3%80%82)
^zh-Q0880-answer

**zh-Q0881** — 如果你喜歡你可以用我的車。

You can use my car if you like.

Why: Conditions and concession. [[Mandarin Chinese#^zh-Q0881|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A6%82%E6%9E%9C%E4%BD%A0%E5%96%9C%E6%AD%A1%E4%BD%A0%E5%8F%AF%E4%BB%A5%E7%94%A8%E6%88%91%E7%9A%84%E8%BB%8A%E3%80%82)
^zh-Q0881-answer

**zh-Q0882** — 如果你喜歡你可以用我的車。

You can use my car if you like.

如果/要是 introduce conditions; 虽然 presents concession, often paired with 但是. 的话 can frame an if scenario. Connectors express relationships, not tense inflections.

Why: Conditions and concession. [[Mandarin Chinese#^zh-Q0882|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A6%82%E6%9E%9C%E4%BD%A0%E5%96%9C%E6%AD%A1%E4%BD%A0%E5%8F%AF%E4%BB%A5%E7%94%A8%E6%88%91%E7%9A%84%E8%BB%8A%E3%80%82)
^zh-Q0882-answer

**zh-Q0883** — 搞这狗屁玩意，我可是老人家了。

I'm too old for that shit.

Expected form: **可是**

Why: Conditions and concession. [[Mandarin Chinese#^zh-Q0883|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%90%9E%E8%BF%99%E7%8B%97%E5%B1%81%E7%8E%A9%E6%84%8F%EF%BC%8C%E6%88%91%E5%8F%AF%E6%98%AF%E8%80%81%E4%BA%BA%E5%AE%B6%E4%BA%86%E3%80%82)
^zh-Q0883-answer

**zh-Q0884** — 搞这狗屁玩意，我可是老人家了。

I'm too old for that shit.

Expected form: **可是**

Why: Conditions and concession. [[Mandarin Chinese#^zh-Q0884|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%90%9E%E8%BF%99%E7%8B%97%E5%B1%81%E7%8E%A9%E6%84%8F%EF%BC%8C%E6%88%91%E5%8F%AF%E6%98%AF%E8%80%81%E4%BA%BA%E5%AE%B6%E4%BA%86%E3%80%82)
^zh-Q0884-answer

**zh-Q0885** — 他把她的话当作是一种赞美。

He took her words as a compliment.

Expected form: **的话**

Why: Conditions and concession. [[Mandarin Chinese#^zh-Q0885|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%96%E6%8A%8A%E5%A5%B9%E7%9A%84%E8%AF%9D%E5%BD%93%E4%BD%9C%E6%98%AF%E4%B8%80%E7%A7%8D%E8%B5%9E%E7%BE%8E%E3%80%82)
^zh-Q0885-answer

**zh-Q0886** — 他把她的话当作是一种赞美。

He took her words as a compliment.

Why: Conditions and concession. [[Mandarin Chinese#^zh-Q0886|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%96%E6%8A%8A%E5%A5%B9%E7%9A%84%E8%AF%9D%E5%BD%93%E4%BD%9C%E6%98%AF%E4%B8%80%E7%A7%8D%E8%B5%9E%E7%BE%8E%E3%80%82)
^zh-Q0886-answer

**zh-Q0887** — 你要是听我的意见就去看医生。

If you take my advice, you'll see a doctor.

Why: Conditions and concession. [[Mandarin Chinese#^zh-Q0887|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E8%A6%81%E6%98%AF%E5%90%AC%E6%88%91%E7%9A%84%E6%84%8F%E8%A7%81%E5%B0%B1%E5%8E%BB%E7%9C%8B%E5%8C%BB%E7%94%9F%E3%80%82)
^zh-Q0887-answer

**zh-Q0888** — 你要是听我的意见就去看医生。

If you take my advice, you'll see a doctor.

如果/要是 introduce conditions; 虽然 presents concession, often paired with 但是. 的话 can frame an if scenario. Connectors express relationships, not tense inflections.

Why: Conditions and concession. [[Mandarin Chinese#^zh-Q0888|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E8%A6%81%E6%98%AF%E5%90%AC%E6%88%91%E7%9A%84%E6%84%8F%E8%A7%81%E5%B0%B1%E5%8E%BB%E7%9C%8B%E5%8C%BB%E7%94%9F%E3%80%82)
^zh-Q0888-answer

**zh-Q0889** — 虽然时髦一点，但是价钱太大！

It's kind of in vogue, but the price is too much!

Expected form: **虽然**

Why: Conditions and concession. [[Mandarin Chinese#^zh-Q0889|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%99%BD%E7%84%B6%E6%97%B6%E9%AB%A6%E4%B8%80%E7%82%B9%EF%BC%8C%E4%BD%86%E6%98%AF%E4%BB%B7%E9%92%B1%E5%A4%AA%E5%A4%A7%EF%BC%81)
^zh-Q0889-answer

**zh-Q0890** — 虽然时髦一点，但是价钱太大！

It's kind of in vogue, but the price is too much!

Expected form: **虽然**

Why: Conditions and concession. [[Mandarin Chinese#^zh-Q0890|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%99%BD%E7%84%B6%E6%97%B6%E9%AB%A6%E4%B8%80%E7%82%B9%EF%BC%8C%E4%BD%86%E6%98%AF%E4%BB%B7%E9%92%B1%E5%A4%AA%E5%A4%A7%EF%BC%81)
^zh-Q0890-answer

**zh-Q0891** — 她佷美， 可是看起來不健康。

She is quite pretty, but looks unhealthy.

Expected form: **可是**

Why: Conditions and concession. [[Mandarin Chinese#^zh-Q0891|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A5%B9%E4%BD%B7%E7%BE%8E%EF%BC%8C%20%E5%8F%AF%E6%98%AF%E7%9C%8B%E8%B5%B7%E4%BE%86%E4%B8%8D%E5%81%A5%E5%BA%B7%E3%80%82)
^zh-Q0891-answer

**zh-Q0892** — 她佷美， 可是看起來不健康。

She is quite pretty, but looks unhealthy.

Why: Conditions and concession. [[Mandarin Chinese#^zh-Q0892|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A5%B9%E4%BD%B7%E7%BE%8E%EF%BC%8C%20%E5%8F%AF%E6%98%AF%E7%9C%8B%E8%B5%B7%E4%BE%86%E4%B8%8D%E5%81%A5%E5%BA%B7%E3%80%82)
^zh-Q0892-answer

**zh-Q0893** — 如果我們之間有1000步的距離，你只要跨出第1步，我就會朝著你的方向走其餘的999步。

If there are 1000 steps between us, you only need to take one step, and I will take the other 999 to you.

Why: Conditions and concession. [[Mandarin Chinese#^zh-Q0893|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A6%82%E6%9E%9C%E6%88%91%E5%80%91%E4%B9%8B%E9%96%93%E6%9C%891000%E6%AD%A5%E7%9A%84%E8%B7%9D%E9%9B%A2%EF%BC%8C%E4%BD%A0%E5%8F%AA%E8%A6%81%E8%B7%A8%E5%87%BA%E7%AC%AC1%E6%AD%A5%EF%BC%8C%E6%88%91%E5%B0%B1%E6%9C%83%E6%9C%9D%E8%91%97%E4%BD%A0%E7%9A%84%E6%96%B9%E5%90%91%E8%B5%B0%E5%85%B6%E9%A4%98%E7%9A%84999%E6%AD%A5%E3%80%82)
^zh-Q0893-answer

**zh-Q0894** — 如果我們之間有1000步的距離，你只要跨出第1步，我就會朝著你的方向走其餘的999步。

If there are 1000 steps between us, you only need to take one step, and I will take the other 999 to you.

如果/要是 introduce conditions; 虽然 presents concession, often paired with 但是. 的话 can frame an if scenario. Connectors express relationships, not tense inflections.

Why: Conditions and concession. [[Mandarin Chinese#^zh-Q0894|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A6%82%E6%9E%9C%E6%88%91%E5%80%91%E4%B9%8B%E9%96%93%E6%9C%891000%E6%AD%A5%E7%9A%84%E8%B7%9D%E9%9B%A2%EF%BC%8C%E4%BD%A0%E5%8F%AA%E8%A6%81%E8%B7%A8%E5%87%BA%E7%AC%AC1%E6%AD%A5%EF%BC%8C%E6%88%91%E5%B0%B1%E6%9C%83%E6%9C%9D%E8%91%97%E4%BD%A0%E7%9A%84%E6%96%B9%E5%90%91%E8%B5%B0%E5%85%B6%E9%A4%98%E7%9A%84999%E6%AD%A5%E3%80%82)
^zh-Q0894-answer

**zh-Q0895** — 如果我可以把英文字母重新排序，我會把「U」和「I」放在一起。

If I could rearrange the alphabet, I would put U and I together.

Expected form: **如果**

Why: Conditions and concession. [[Mandarin Chinese#^zh-Q0895|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A6%82%E6%9E%9C%E6%88%91%E5%8F%AF%E4%BB%A5%E6%8A%8A%E8%8B%B1%E6%96%87%E5%AD%97%E6%AF%8D%E9%87%8D%E6%96%B0%E6%8E%92%E5%BA%8F%EF%BC%8C%E6%88%91%E6%9C%83%E6%8A%8A%E3%80%8CU%E3%80%8D%E5%92%8C%E3%80%8CI%E3%80%8D%E6%94%BE%E5%9C%A8%E4%B8%80%E8%B5%B7%E3%80%82)
^zh-Q0895-answer

**zh-Q0896** — 如果我可以把英文字母重新排序，我會把「U」和「I」放在一起。

If I could rearrange the alphabet, I would put U and I together.

Expected form: **如果**

Why: Conditions and concession. [[Mandarin Chinese#^zh-Q0896|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A6%82%E6%9E%9C%E6%88%91%E5%8F%AF%E4%BB%A5%E6%8A%8A%E8%8B%B1%E6%96%87%E5%AD%97%E6%AF%8D%E9%87%8D%E6%96%B0%E6%8E%92%E5%BA%8F%EF%BC%8C%E6%88%91%E6%9C%83%E6%8A%8A%E3%80%8CU%E3%80%8D%E5%92%8C%E3%80%8CI%E3%80%8D%E6%94%BE%E5%9C%A8%E4%B8%80%E8%B5%B7%E3%80%82)
^zh-Q0896-answer

**zh-Q0897** — 如果我是你，我不会想去知道Tom现在正在做什么。

If I were you, I'd want to know what Tom is doing right now.

Expected form: **如果**

Why: Conditions and concession. [[Mandarin Chinese#^zh-Q0897|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A6%82%E6%9E%9C%E6%88%91%E6%98%AF%E4%BD%A0%EF%BC%8C%E6%88%91%E4%B8%8D%E4%BC%9A%E6%83%B3%E5%8E%BB%E7%9F%A5%E9%81%93Tom%E7%8E%B0%E5%9C%A8%E6%AD%A3%E5%9C%A8%E5%81%9A%E4%BB%80%E4%B9%88%E3%80%82)
^zh-Q0897-answer

**zh-Q0898** — 如果我是你，我不会想去知道Tom现在正在做什么。

If I were you, I'd want to know what Tom is doing right now.

Why: Conditions and concession. [[Mandarin Chinese#^zh-Q0898|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A6%82%E6%9E%9C%E6%88%91%E6%98%AF%E4%BD%A0%EF%BC%8C%E6%88%91%E4%B8%8D%E4%BC%9A%E6%83%B3%E5%8E%BB%E7%9F%A5%E9%81%93Tom%E7%8E%B0%E5%9C%A8%E6%AD%A3%E5%9C%A8%E5%81%9A%E4%BB%80%E4%B9%88%E3%80%82)
^zh-Q0898-answer

**zh-Q0899** — 我會說中文，但是我不會讀中文。

I can speak Chinese, but I can't read it.

Why: Conditions and concession. [[Mandarin Chinese#^zh-Q0899|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E6%9C%83%E8%AA%AA%E4%B8%AD%E6%96%87%EF%BC%8C%E4%BD%86%E6%98%AF%E6%88%91%E4%B8%8D%E6%9C%83%E8%AE%80%E4%B8%AD%E6%96%87%E3%80%82)
^zh-Q0899-answer

**zh-Q0900** — 我會說中文，但是我不會讀中文。

I can speak Chinese, but I can't read it.

如果/要是 introduce conditions; 虽然 presents concession, often paired with 但是. 的话 can frame an if scenario. Connectors express relationships, not tense inflections.

Why: Conditions and concession. [[Mandarin Chinese#^zh-Q0900|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E6%9C%83%E8%AA%AA%E4%B8%AD%E6%96%87%EF%BC%8C%E4%BD%86%E6%98%AF%E6%88%91%E4%B8%8D%E6%9C%83%E8%AE%80%E4%B8%AD%E6%96%87%E3%80%82)
^zh-Q0900-answer


### Answers 901–950

**zh-Q0901** — 你自己应该知道吧。

You must know yourself.

Expected form: **应该**

Why: Cause and inference. [[Mandarin Chinese#^zh-Q0901|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E8%87%AA%E5%B7%B1%E5%BA%94%E8%AF%A5%E7%9F%A5%E9%81%93%E5%90%A7%E3%80%82)
^zh-Q0901-answer

**zh-Q0902** — 你自己应该知道吧。

You must know yourself.

Expected form: **应该**

Why: Cause and inference. [[Mandarin Chinese#^zh-Q0902|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E8%87%AA%E5%B7%B1%E5%BA%94%E8%AF%A5%E7%9F%A5%E9%81%93%E5%90%A7%E3%80%82)
^zh-Q0902-answer

**zh-Q0903** — 因为下雨了，球场上没有很多观众。

There weren't many spectators at the game because of the rain.

Expected form: **因为**

Why: Cause and inference. [[Mandarin Chinese#^zh-Q0903|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%9B%A0%E4%B8%BA%E4%B8%8B%E9%9B%A8%E4%BA%86%EF%BC%8C%E7%90%83%E5%9C%BA%E4%B8%8A%E6%B2%A1%E6%9C%89%E5%BE%88%E5%A4%9A%E8%A7%82%E4%BC%97%E3%80%82)
^zh-Q0903-answer

**zh-Q0904** — 因为下雨了，球场上没有很多观众。

There weren't many spectators at the game because of the rain.

Why: Cause and inference. [[Mandarin Chinese#^zh-Q0904|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%9B%A0%E4%B8%BA%E4%B8%8B%E9%9B%A8%E4%BA%86%EF%BC%8C%E7%90%83%E5%9C%BA%E4%B8%8A%E6%B2%A1%E6%9C%89%E5%BE%88%E5%A4%9A%E8%A7%82%E4%BC%97%E3%80%82)
^zh-Q0904-answer

**zh-Q0905** — 她妈妈来自西班牙，她爸爸来自意大利，所以她会讲西班牙语和意大利语。

Her mom is from Spain and her dad is from Italy, that's why she can speak both Spanish and Italian.

Why: Cause and inference. [[Mandarin Chinese#^zh-Q0905|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A5%B9%E5%A6%88%E5%A6%88%E6%9D%A5%E8%87%AA%E8%A5%BF%E7%8F%AD%E7%89%99%EF%BC%8C%E5%A5%B9%E7%88%B8%E7%88%B8%E6%9D%A5%E8%87%AA%E6%84%8F%E5%A4%A7%E5%88%A9%EF%BC%8C%E6%89%80%E4%BB%A5%E5%A5%B9%E4%BC%9A%E8%AE%B2%E8%A5%BF%E7%8F%AD%E7%89%99%E8%AF%AD%E5%92%8C%E6%84%8F%E5%A4%A7%E5%88%A9%E8%AF%AD%E3%80%82)
^zh-Q0905-answer

**zh-Q0906** — 她妈妈来自西班牙，她爸爸来自意大利，所以她会讲西班牙语和意大利语。

Her mom is from Spain and her dad is from Italy, that's why she can speak both Spanish and Italian.

因为 supplies a reason; 所以/因此 supply a consequence. 可能 limits certainty and 应该 can indicate expectation or obligation. Translate the force of the claim, not just the dictionary gloss.

Why: Cause and inference. [[Mandarin Chinese#^zh-Q0906|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A5%B9%E5%A6%88%E5%A6%88%E6%9D%A5%E8%87%AA%E8%A5%BF%E7%8F%AD%E7%89%99%EF%BC%8C%E5%A5%B9%E7%88%B8%E7%88%B8%E6%9D%A5%E8%87%AA%E6%84%8F%E5%A4%A7%E5%88%A9%EF%BC%8C%E6%89%80%E4%BB%A5%E5%A5%B9%E4%BC%9A%E8%AE%B2%E8%A5%BF%E7%8F%AD%E7%89%99%E8%AF%AD%E5%92%8C%E6%84%8F%E5%A4%A7%E5%88%A9%E8%AF%AD%E3%80%82)
^zh-Q0906-answer

**zh-Q0907** — 他本应该成为一个律师。

He should have been a lawyer.

Expected form: **应该**

Why: Cause and inference. [[Mandarin Chinese#^zh-Q0907|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%96%E6%9C%AC%E5%BA%94%E8%AF%A5%E6%88%90%E4%B8%BA%E4%B8%80%E4%B8%AA%E5%BE%8B%E5%B8%88%E3%80%82)
^zh-Q0907-answer

**zh-Q0908** — 他本应该成为一个律师。

He should have been a lawyer.

Expected form: **应该**

Why: Cause and inference. [[Mandarin Chinese#^zh-Q0908|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%96%E6%9C%AC%E5%BA%94%E8%AF%A5%E6%88%90%E4%B8%BA%E4%B8%80%E4%B8%AA%E5%BE%8B%E5%B8%88%E3%80%82)
^zh-Q0908-answer

**zh-Q0909** — 因为有些公司对待雇员和顾客的态度可以随时影响它们的股价，所以對公司的成功或失敗不可避免地有巨大的影響。

For some companies their treatment of their employees or clients at any given time could affect their share prices and so inevitably have a great influence on the company’s success or failure.

Expected form: **因为**

Why: Cause and inference. [[Mandarin Chinese#^zh-Q0909|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%9B%A0%E4%B8%BA%E6%9C%89%E4%BA%9B%E5%85%AC%E5%8F%B8%E5%AF%B9%E5%BE%85%E9%9B%87%E5%91%98%E5%92%8C%E9%A1%BE%E5%AE%A2%E7%9A%84%E6%80%81%E5%BA%A6%E5%8F%AF%E4%BB%A5%E9%9A%8F%E6%97%B6%E5%BD%B1%E5%93%8D%E5%AE%83%E4%BB%AC%E7%9A%84%E8%82%A1%E4%BB%B7%EF%BC%8C%E6%89%80%E4%BB%A5%E5%B0%8D%E5%85%AC%E5%8F%B8%E7%9A%84%E6%88%90%E5%8A%9F%E6%88%96%E5%A4%B1%E6%95%97%E4%B8%8D%E5%8F%AF%E9%81%BF%E5%85%8D%E5%9C%B0%E6%9C%89%E5%B7%A8%E5%A4%A7%E7%9A%84%E5%BD%B1%E9%9F%BF%E3%80%82)
^zh-Q0909-answer

**zh-Q0910** — 因为有些公司对待雇员和顾客的态度可以随时影响它们的股价，所以對公司的成功或失敗不可避免地有巨大的影響。

For some companies their treatment of their employees or clients at any given time could affect their share prices and so inevitably have a great influence on the company’s success or failure.

Why: Cause and inference. [[Mandarin Chinese#^zh-Q0910|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%9B%A0%E4%B8%BA%E6%9C%89%E4%BA%9B%E5%85%AC%E5%8F%B8%E5%AF%B9%E5%BE%85%E9%9B%87%E5%91%98%E5%92%8C%E9%A1%BE%E5%AE%A2%E7%9A%84%E6%80%81%E5%BA%A6%E5%8F%AF%E4%BB%A5%E9%9A%8F%E6%97%B6%E5%BD%B1%E5%93%8D%E5%AE%83%E4%BB%AC%E7%9A%84%E8%82%A1%E4%BB%B7%EF%BC%8C%E6%89%80%E4%BB%A5%E5%B0%8D%E5%85%AC%E5%8F%B8%E7%9A%84%E6%88%90%E5%8A%9F%E6%88%96%E5%A4%B1%E6%95%97%E4%B8%8D%E5%8F%AF%E9%81%BF%E5%85%8D%E5%9C%B0%E6%9C%89%E5%B7%A8%E5%A4%A7%E7%9A%84%E5%BD%B1%E9%9F%BF%E3%80%82)
^zh-Q0910-answer

**zh-Q0911** — 老师应该对学生非常耐心。

The teacher should be very patient with her students.

Why: Cause and inference. [[Mandarin Chinese#^zh-Q0911|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%80%81%E5%B8%88%E5%BA%94%E8%AF%A5%E5%AF%B9%E5%AD%A6%E7%94%9F%E9%9D%9E%E5%B8%B8%E8%80%90%E5%BF%83%E3%80%82)
^zh-Q0911-answer

**zh-Q0912** — 老师应该对学生非常耐心。

The teacher should be very patient with her students.

因为 supplies a reason; 所以/因此 supply a consequence. 可能 limits certainty and 应该 can indicate expectation or obligation. Translate the force of the claim, not just the dictionary gloss.

Why: Cause and inference. [[Mandarin Chinese#^zh-Q0912|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%80%81%E5%B8%88%E5%BA%94%E8%AF%A5%E5%AF%B9%E5%AD%A6%E7%94%9F%E9%9D%9E%E5%B8%B8%E8%80%90%E5%BF%83%E3%80%82)
^zh-Q0912-answer

**zh-Q0913** — 她很有可能会有所成就。

It's likely that she'll succeed.

Expected form: **可能**

Why: Cause and inference. [[Mandarin Chinese#^zh-Q0913|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A5%B9%E5%BE%88%E6%9C%89%E5%8F%AF%E8%83%BD%E4%BC%9A%E6%9C%89%E6%89%80%E6%88%90%E5%B0%B1%E3%80%82)
^zh-Q0913-answer

**zh-Q0914** — 她很有可能会有所成就。

It's likely that she'll succeed.

Expected form: **可能**

Why: Cause and inference. [[Mandarin Chinese#^zh-Q0914|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A5%B9%E5%BE%88%E6%9C%89%E5%8F%AF%E8%83%BD%E4%BC%9A%E6%9C%89%E6%89%80%E6%88%90%E5%B0%B1%E3%80%82)
^zh-Q0914-answer

**zh-Q0915** — 等你到的时候应该已经散会了。

The meeting will have broken up by the time you arrive there.

Expected form: **应该**

Why: Cause and inference. [[Mandarin Chinese#^zh-Q0915|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E7%AD%89%E4%BD%A0%E5%88%B0%E7%9A%84%E6%97%B6%E5%80%99%E5%BA%94%E8%AF%A5%E5%B7%B2%E7%BB%8F%E6%95%A3%E4%BC%9A%E4%BA%86%E3%80%82)
^zh-Q0915-answer

**zh-Q0916** — 等你到的时候应该已经散会了。

The meeting will have broken up by the time you arrive there.

Why: Cause and inference. [[Mandarin Chinese#^zh-Q0916|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E7%AD%89%E4%BD%A0%E5%88%B0%E7%9A%84%E6%97%B6%E5%80%99%E5%BA%94%E8%AF%A5%E5%B7%B2%E7%BB%8F%E6%95%A3%E4%BC%9A%E4%BA%86%E3%80%82)
^zh-Q0916-answer

**zh-Q0917** — 它在網際網路上，所以它一定是真實的。

It's in the internet, so it must be true.

Why: Cause and inference. [[Mandarin Chinese#^zh-Q0917|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%AE%83%E5%9C%A8%E7%B6%B2%E9%9A%9B%E7%B6%B2%E8%B7%AF%E4%B8%8A%EF%BC%8C%E6%89%80%E4%BB%A5%E5%AE%83%E4%B8%80%E5%AE%9A%E6%98%AF%E7%9C%9F%E5%AF%A6%E7%9A%84%E3%80%82)
^zh-Q0917-answer

**zh-Q0918** — 它在網際網路上，所以它一定是真實的。

It's in the internet, so it must be true.

因为 supplies a reason; 所以/因此 supply a consequence. 可能 limits certainty and 应该 can indicate expectation or obligation. Translate the force of the claim, not just the dictionary gloss.

Why: Cause and inference. [[Mandarin Chinese#^zh-Q0918|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%AE%83%E5%9C%A8%E7%B6%B2%E9%9A%9B%E7%B6%B2%E8%B7%AF%E4%B8%8A%EF%BC%8C%E6%89%80%E4%BB%A5%E5%AE%83%E4%B8%80%E5%AE%9A%E6%98%AF%E7%9C%9F%E5%AF%A6%E7%9A%84%E3%80%82)
^zh-Q0918-answer

**zh-Q0919** — 我認為我可能已經犯了大錯。

I think I may have made a big mistake.

Expected form: **可能**

Why: Cause and inference. [[Mandarin Chinese#^zh-Q0919|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E8%AA%8D%E7%82%BA%E6%88%91%E5%8F%AF%E8%83%BD%E5%B7%B2%E7%B6%93%E7%8A%AF%E4%BA%86%E5%A4%A7%E9%8C%AF%E3%80%82)
^zh-Q0919-answer

**zh-Q0920** — 我認為我可能已經犯了大錯。

I think I may have made a big mistake.

Expected form: **可能**

Why: Cause and inference. [[Mandarin Chinese#^zh-Q0920|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E8%AA%8D%E7%82%BA%E6%88%91%E5%8F%AF%E8%83%BD%E5%B7%B2%E7%B6%93%E7%8A%AF%E4%BA%86%E5%A4%A7%E9%8C%AF%E3%80%82)
^zh-Q0920-answer

**zh-Q0921** — 失業者渴望工作，所以任何有助於養家糊口的工作都可以。

The jobless became desperate for work – any work that would help them to support their families.

Expected form: **所以**

Why: Cause and inference. [[Mandarin Chinese#^zh-Q0921|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A4%B1%E6%A5%AD%E8%80%85%E6%B8%B4%E6%9C%9B%E5%B7%A5%E4%BD%9C%EF%BC%8C%E6%89%80%E4%BB%A5%E4%BB%BB%E4%BD%95%E6%9C%89%E5%8A%A9%E6%96%BC%E9%A4%8A%E5%AE%B6%E7%B3%8A%E5%8F%A3%E7%9A%84%E5%B7%A5%E4%BD%9C%E9%83%BD%E5%8F%AF%E4%BB%A5%E3%80%82)
^zh-Q0921-answer

**zh-Q0922** — 失業者渴望工作，所以任何有助於養家糊口的工作都可以。

The jobless became desperate for work – any work that would help them to support their families.

Why: Cause and inference. [[Mandarin Chinese#^zh-Q0922|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A4%B1%E6%A5%AD%E8%80%85%E6%B8%B4%E6%9C%9B%E5%B7%A5%E4%BD%9C%EF%BC%8C%E6%89%80%E4%BB%A5%E4%BB%BB%E4%BD%95%E6%9C%89%E5%8A%A9%E6%96%BC%E9%A4%8A%E5%AE%B6%E7%B3%8A%E5%8F%A3%E7%9A%84%E5%B7%A5%E4%BD%9C%E9%83%BD%E5%8F%AF%E4%BB%A5%E3%80%82)
^zh-Q0922-answer

**zh-Q0923** — 他们之所以没有游泳，就因为天气很冷。

They didn't swim because it was cold.

Why: Cause and inference. [[Mandarin Chinese#^zh-Q0923|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%96%E4%BB%AC%E4%B9%8B%E6%89%80%E4%BB%A5%E6%B2%A1%E6%9C%89%E6%B8%B8%E6%B3%B3%EF%BC%8C%E5%B0%B1%E5%9B%A0%E4%B8%BA%E5%A4%A9%E6%B0%94%E5%BE%88%E5%86%B7%E3%80%82)
^zh-Q0923-answer

**zh-Q0924** — 他们之所以没有游泳，就因为天气很冷。

They didn't swim because it was cold.

因为 supplies a reason; 所以/因此 supply a consequence. 可能 limits certainty and 应该 can indicate expectation or obligation. Translate the force of the claim, not just the dictionary gloss.

Why: Cause and inference. [[Mandarin Chinese#^zh-Q0924|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%96%E4%BB%AC%E4%B9%8B%E6%89%80%E4%BB%A5%E6%B2%A1%E6%9C%89%E6%B8%B8%E6%B3%B3%EF%BC%8C%E5%B0%B1%E5%9B%A0%E4%B8%BA%E5%A4%A9%E6%B0%94%E5%BE%88%E5%86%B7%E3%80%82)
^zh-Q0924-answer

**zh-Q0925** — 因為你不夠努力，所以才會失敗。

The reason why you failed is you did not try hard enough.

Expected form: **所以**

Why: Cause and inference. [[Mandarin Chinese#^zh-Q0925|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%9B%A0%E7%82%BA%E4%BD%A0%E4%B8%8D%E5%A4%A0%E5%8A%AA%E5%8A%9B%EF%BC%8C%E6%89%80%E4%BB%A5%E6%89%8D%E6%9C%83%E5%A4%B1%E6%95%97%E3%80%82)
^zh-Q0925-answer

**zh-Q0926** — 因為你不夠努力，所以才會失敗。

The reason why you failed is you did not try hard enough.

Expected form: **所以**

Why: Cause and inference. [[Mandarin Chinese#^zh-Q0926|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%9B%A0%E7%82%BA%E4%BD%A0%E4%B8%8D%E5%A4%A0%E5%8A%AA%E5%8A%9B%EF%BC%8C%E6%89%80%E4%BB%A5%E6%89%8D%E6%9C%83%E5%A4%B1%E6%95%97%E3%80%82)
^zh-Q0926-answer

**zh-Q0927** — 就是因为他不成材他爸看不起他。

It's just that because he hasn't made something of himself, his father won't look at him.

Expected form: **因为**

Why: Cause and inference. [[Mandarin Chinese#^zh-Q0927|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%B0%B1%E6%98%AF%E5%9B%A0%E4%B8%BA%E4%BB%96%E4%B8%8D%E6%88%90%E6%9D%90%E4%BB%96%E7%88%B8%E7%9C%8B%E4%B8%8D%E8%B5%B7%E4%BB%96%E3%80%82)
^zh-Q0927-answer

**zh-Q0928** — 就是因为他不成材他爸看不起他。

It's just that because he hasn't made something of himself, his father won't look at him.

Why: Cause and inference. [[Mandarin Chinese#^zh-Q0928|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%B0%B1%E6%98%AF%E5%9B%A0%E4%B8%BA%E4%BB%96%E4%B8%8D%E6%88%90%E6%9D%90%E4%BB%96%E7%88%B8%E7%9C%8B%E4%B8%8D%E8%B5%B7%E4%BB%96%E3%80%82)
^zh-Q0928-answer

**zh-Q0929** — 这并不是因为我恨他，相反我爱他。

It is not because I hate him, but because I love him.

Why: Cause and inference. [[Mandarin Chinese#^zh-Q0929|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%BF%99%E5%B9%B6%E4%B8%8D%E6%98%AF%E5%9B%A0%E4%B8%BA%E6%88%91%E6%81%A8%E4%BB%96%EF%BC%8C%E7%9B%B8%E5%8F%8D%E6%88%91%E7%88%B1%E4%BB%96%E3%80%82)
^zh-Q0929-answer

**zh-Q0930** — 这并不是因为我恨他，相反我爱他。

It is not because I hate him, but because I love him.

因为 supplies a reason; 所以/因此 supply a consequence. 可能 limits certainty and 应该 can indicate expectation or obligation. Translate the force of the claim, not just the dictionary gloss.

Why: Cause and inference. [[Mandarin Chinese#^zh-Q0930|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%BF%99%E5%B9%B6%E4%B8%8D%E6%98%AF%E5%9B%A0%E4%B8%BA%E6%88%91%E6%81%A8%E4%BB%96%EF%BC%8C%E7%9B%B8%E5%8F%8D%E6%88%91%E7%88%B1%E4%BB%96%E3%80%82)
^zh-Q0930-answer

**zh-Q0931** — 汤姆今天不舒服所以没来上班。

Tom can't come to work today because he doesn't feel well.

Expected form: **所以**

Why: Cause and inference. [[Mandarin Chinese#^zh-Q0931|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%B1%A4%E5%A7%86%E4%BB%8A%E5%A4%A9%E4%B8%8D%E8%88%92%E6%9C%8D%E6%89%80%E4%BB%A5%E6%B2%A1%E6%9D%A5%E4%B8%8A%E7%8F%AD%E3%80%82)
^zh-Q0931-answer

**zh-Q0932** — 汤姆今天不舒服所以没来上班。

Tom can't come to work today because he doesn't feel well.

Expected form: **所以**

Why: Cause and inference. [[Mandarin Chinese#^zh-Q0932|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%B1%A4%E5%A7%86%E4%BB%8A%E5%A4%A9%E4%B8%8D%E8%88%92%E6%9C%8D%E6%89%80%E4%BB%A5%E6%B2%A1%E6%9D%A5%E4%B8%8A%E7%8F%AD%E3%80%82)
^zh-Q0932-answer

**zh-Q0933** — 她可能錯過了七點的火車。

She may have missed the 7:00 train.

Expected form: **可能**

Why: Cause and inference. [[Mandarin Chinese#^zh-Q0933|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A5%B9%E5%8F%AF%E8%83%BD%E9%8C%AF%E9%81%8E%E4%BA%86%E4%B8%83%E9%BB%9E%E7%9A%84%E7%81%AB%E8%BB%8A%E3%80%82)
^zh-Q0933-answer

**zh-Q0934** — 她可能錯過了七點的火車。

She may have missed the 7:00 train.

Why: Cause and inference. [[Mandarin Chinese#^zh-Q0934|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%A5%B9%E5%8F%AF%E8%83%BD%E9%8C%AF%E9%81%8E%E4%BA%86%E4%B8%83%E9%BB%9E%E7%9A%84%E7%81%AB%E8%BB%8A%E3%80%82)
^zh-Q0934-answer

**zh-Q0935** — 我早就有感覺到這可能會發生。

I had a feeling this might happen.

Why: Cause and inference. [[Mandarin Chinese#^zh-Q0935|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E6%97%A9%E5%B0%B1%E6%9C%89%E6%84%9F%E8%A6%BA%E5%88%B0%E9%80%99%E5%8F%AF%E8%83%BD%E6%9C%83%E7%99%BC%E7%94%9F%E3%80%82)
^zh-Q0935-answer

**zh-Q0936** — 我早就有感覺到這可能會發生。

I had a feeling this might happen.

因为 supplies a reason; 所以/因此 supply a consequence. 可能 limits certainty and 应该 can indicate expectation or obligation. Translate the force of the claim, not just the dictionary gloss.

Why: Cause and inference. [[Mandarin Chinese#^zh-Q0936|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E6%97%A9%E5%B0%B1%E6%9C%89%E6%84%9F%E8%A6%BA%E5%88%B0%E9%80%99%E5%8F%AF%E8%83%BD%E6%9C%83%E7%99%BC%E7%94%9F%E3%80%82)
^zh-Q0936-answer

**zh-Q0937** — 我们应该尊敬父母。

We should respect our parents.

Expected form: **应该**

Why: Cause and inference. [[Mandarin Chinese#^zh-Q0937|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E4%BB%AC%E5%BA%94%E8%AF%A5%E5%B0%8A%E6%95%AC%E7%88%B6%E6%AF%8D%E3%80%82)
^zh-Q0937-answer

**zh-Q0938** — 我们应该尊敬父母。

We should respect our parents.

Expected form: **应该**

Why: Cause and inference. [[Mandarin Chinese#^zh-Q0938|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E4%BB%AC%E5%BA%94%E8%AF%A5%E5%B0%8A%E6%95%AC%E7%88%B6%E6%AF%8D%E3%80%82)
^zh-Q0938-answer

**zh-Q0939** — 你有可能不知道这事。

It's possible that you don't know this.

Expected form: **可能**

Why: Cause and inference. [[Mandarin Chinese#^zh-Q0939|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E6%9C%89%E5%8F%AF%E8%83%BD%E4%B8%8D%E7%9F%A5%E9%81%93%E8%BF%99%E4%BA%8B%E3%80%82)
^zh-Q0939-answer

**zh-Q0940** — 你有可能不知道这事。

It's possible that you don't know this.

Why: Cause and inference. [[Mandarin Chinese#^zh-Q0940|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E6%9C%89%E5%8F%AF%E8%83%BD%E4%B8%8D%E7%9F%A5%E9%81%93%E8%BF%99%E4%BA%8B%E3%80%82)
^zh-Q0940-answer

**zh-Q0941** — 傑克很喜歡挑別人的毛病，所以沒有人願意和他交朋友。

Jack always finds fault with others. That's why everybody avoids him.

Why: Cause and inference. [[Mandarin Chinese#^zh-Q0941|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%82%91%E5%85%8B%E5%BE%88%E5%96%9C%E6%AD%A1%E6%8C%91%E5%88%A5%E4%BA%BA%E7%9A%84%E6%AF%9B%E7%97%85%EF%BC%8C%E6%89%80%E4%BB%A5%E6%B2%92%E6%9C%89%E4%BA%BA%E9%A1%98%E6%84%8F%E5%92%8C%E4%BB%96%E4%BA%A4%E6%9C%8B%E5%8F%8B%E3%80%82)
^zh-Q0941-answer

**zh-Q0942** — 傑克很喜歡挑別人的毛病，所以沒有人願意和他交朋友。

Jack always finds fault with others. That's why everybody avoids him.

因为 supplies a reason; 所以/因此 supply a consequence. 可能 limits certainty and 应该 can indicate expectation or obligation. Translate the force of the claim, not just the dictionary gloss.

Why: Cause and inference. [[Mandarin Chinese#^zh-Q0942|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%82%91%E5%85%8B%E5%BE%88%E5%96%9C%E6%AD%A1%E6%8C%91%E5%88%A5%E4%BA%BA%E7%9A%84%E6%AF%9B%E7%97%85%EF%BC%8C%E6%89%80%E4%BB%A5%E6%B2%92%E6%9C%89%E4%BA%BA%E9%A1%98%E6%84%8F%E5%92%8C%E4%BB%96%E4%BA%A4%E6%9C%8B%E5%8F%8B%E3%80%82)
^zh-Q0942-answer

**zh-Q0943** — 不是因为某人不理事实它们就会不复存在了。

Facts do not cease to exist because they are ignored.

Expected form: **因为**

Why: Cause and inference. [[Mandarin Chinese#^zh-Q0943|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%B8%8D%E6%98%AF%E5%9B%A0%E4%B8%BA%E6%9F%90%E4%BA%BA%E4%B8%8D%E7%90%86%E4%BA%8B%E5%AE%9E%E5%AE%83%E4%BB%AC%E5%B0%B1%E4%BC%9A%E4%B8%8D%E5%A4%8D%E5%AD%98%E5%9C%A8%E4%BA%86%E3%80%82)
^zh-Q0943-answer

**zh-Q0944** — 不是因为某人不理事实它们就会不复存在了。

Facts do not cease to exist because they are ignored.

Expected form: **因为**

Why: Cause and inference. [[Mandarin Chinese#^zh-Q0944|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%B8%8D%E6%98%AF%E5%9B%A0%E4%B8%BA%E6%9F%90%E4%BA%BA%E4%B8%8D%E7%90%86%E4%BA%8B%E5%AE%9E%E5%AE%83%E4%BB%AC%E5%B0%B1%E4%BC%9A%E4%B8%8D%E5%A4%8D%E5%AD%98%E5%9C%A8%E4%BA%86%E3%80%82)
^zh-Q0944-answer

**zh-Q0945** — 我要坚持学习拉丁语，因为它非常有趣。

I will continue to study Latin, because it is really interesting.

Expected form: **因为**

Why: Cause and inference. [[Mandarin Chinese#^zh-Q0945|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E8%A6%81%E5%9D%9A%E6%8C%81%E5%AD%A6%E4%B9%A0%E6%8B%89%E4%B8%81%E8%AF%AD%EF%BC%8C%E5%9B%A0%E4%B8%BA%E5%AE%83%E9%9D%9E%E5%B8%B8%E6%9C%89%E8%B6%A3%E3%80%82)
^zh-Q0945-answer

**zh-Q0946** — 我要坚持学习拉丁语，因为它非常有趣。

I will continue to study Latin, because it is really interesting.

Why: Cause and inference. [[Mandarin Chinese#^zh-Q0946|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E8%A6%81%E5%9D%9A%E6%8C%81%E5%AD%A6%E4%B9%A0%E6%8B%89%E4%B8%81%E8%AF%AD%EF%BC%8C%E5%9B%A0%E4%B8%BA%E5%AE%83%E9%9D%9E%E5%B8%B8%E6%9C%89%E8%B6%A3%E3%80%82)
^zh-Q0946-answer

**zh-Q0947** — 我平时每天可能练习一个小时汉字。

Normally I might study Chinese characters for an hour a day.

Why: Cause and inference. [[Mandarin Chinese#^zh-Q0947|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E5%B9%B3%E6%97%B6%E6%AF%8F%E5%A4%A9%E5%8F%AF%E8%83%BD%E7%BB%83%E4%B9%A0%E4%B8%80%E4%B8%AA%E5%B0%8F%E6%97%B6%E6%B1%89%E5%AD%97%E3%80%82)
^zh-Q0947-answer

**zh-Q0948** — 我平时每天可能练习一个小时汉字。

Normally I might study Chinese characters for an hour a day.

因为 supplies a reason; 所以/因此 supply a consequence. 可能 limits certainty and 应该 can indicate expectation or obligation. Translate the force of the claim, not just the dictionary gloss.

Why: Cause and inference. [[Mandarin Chinese#^zh-Q0948|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E5%B9%B3%E6%97%B6%E6%AF%8F%E5%A4%A9%E5%8F%AF%E8%83%BD%E7%BB%83%E4%B9%A0%E4%B8%80%E4%B8%AA%E5%B0%8F%E6%97%B6%E6%B1%89%E5%AD%97%E3%80%82)
^zh-Q0948-answer

**zh-Q0949** — 你应该多接触本文化，多了解一些传统习俗。

You should interact with the local culture more, to better understand some traditions.

Expected form: **应该**

Why: Cause and inference. [[Mandarin Chinese#^zh-Q0949|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E5%BA%94%E8%AF%A5%E5%A4%9A%E6%8E%A5%E8%A7%A6%E6%9C%AC%E6%96%87%E5%8C%96%EF%BC%8C%E5%A4%9A%E4%BA%86%E8%A7%A3%E4%B8%80%E4%BA%9B%E4%BC%A0%E7%BB%9F%E4%B9%A0%E4%BF%97%E3%80%82)
^zh-Q0949-answer

**zh-Q0950** — 你应该多接触本文化，多了解一些传统习俗。

You should interact with the local culture more, to better understand some traditions.

Expected form: **应该**

Why: Cause and inference. [[Mandarin Chinese#^zh-Q0950|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E5%BA%94%E8%AF%A5%E5%A4%9A%E6%8E%A5%E8%A7%A6%E6%9C%AC%E6%96%87%E5%8C%96%EF%BC%8C%E5%A4%9A%E4%BA%86%E8%A7%A3%E4%B8%80%E4%BA%9B%E4%BC%A0%E7%BB%9F%E4%B9%A0%E4%BF%97%E3%80%82)
^zh-Q0950-answer


### Answers 951–1000

**zh-Q0951** — 這台相機至少要花費500美元。

The camera will cost at least $500.

Expected form: **要**

Why: Ability and intention. [[Mandarin Chinese#^zh-Q0951|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E9%80%99%E5%8F%B0%E7%9B%B8%E6%A9%9F%E8%87%B3%E5%B0%91%E8%A6%81%E8%8A%B1%E8%B2%BB500%E7%BE%8E%E5%85%83%E3%80%82)
^zh-Q0951-answer

**zh-Q0952** — 這台相機至少要花費500美元。

The camera will cost at least $500.

Why: Ability and intention. [[Mandarin Chinese#^zh-Q0952|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E9%80%99%E5%8F%B0%E7%9B%B8%E6%A9%9F%E8%87%B3%E5%B0%91%E8%A6%81%E8%8A%B1%E8%B2%BB500%E7%BE%8E%E5%85%83%E3%80%82)
^zh-Q0952-answer

**zh-Q0953** — 步行到車站要花十分鐘。

It's ten minutes' walk to the station.

Why: Ability and intention. [[Mandarin Chinese#^zh-Q0953|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%AD%A5%E8%A1%8C%E5%88%B0%E8%BB%8A%E7%AB%99%E8%A6%81%E8%8A%B1%E5%8D%81%E5%88%86%E9%90%98%E3%80%82)
^zh-Q0953-answer

**zh-Q0954** — 步行到車站要花十分鐘。

It's ten minutes' walk to the station.

会, 能 and 可以 differ in learned ability, possibility and permission, with overlap in context. 要 and 想 express different strengths of intention/desire. These words do not trigger verb conjugation.

Why: Ability and intention. [[Mandarin Chinese#^zh-Q0954|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%AD%A5%E8%A1%8C%E5%88%B0%E8%BB%8A%E7%AB%99%E8%A6%81%E8%8A%B1%E5%8D%81%E5%88%86%E9%90%98%E3%80%82)
^zh-Q0954-answer

**zh-Q0955** — 我認為我能幫點忙。

I thought I could be of some help.

Expected form: **能**

Why: Ability and intention. [[Mandarin Chinese#^zh-Q0955|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E8%AA%8D%E7%82%BA%E6%88%91%E8%83%BD%E5%B9%AB%E9%BB%9E%E5%BF%99%E3%80%82)
^zh-Q0955-answer

**zh-Q0956** — 我認為我能幫點忙。

I thought I could be of some help.

Expected form: **能**

Why: Ability and intention. [[Mandarin Chinese#^zh-Q0956|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E8%AA%8D%E7%82%BA%E6%88%91%E8%83%BD%E5%B9%AB%E9%BB%9E%E5%BF%99%E3%80%82)
^zh-Q0956-answer

**zh-Q0957** — 我中午十二点半还要去浦东。

I still need to go to Pudong at 12:30.

Expected form: **要**

Why: Ability and intention. [[Mandarin Chinese#^zh-Q0957|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E4%B8%AD%E5%8D%88%E5%8D%81%E4%BA%8C%E7%82%B9%E5%8D%8A%E8%BF%98%E8%A6%81%E5%8E%BB%E6%B5%A6%E4%B8%9C%E3%80%82)
^zh-Q0957-answer

**zh-Q0958** — 我中午十二点半还要去浦东。

I still need to go to Pudong at 12:30.

Why: Ability and intention. [[Mandarin Chinese#^zh-Q0958|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E4%B8%AD%E5%8D%88%E5%8D%81%E4%BA%8C%E7%82%B9%E5%8D%8A%E8%BF%98%E8%A6%81%E5%8E%BB%E6%B5%A6%E4%B8%9C%E3%80%82)
^zh-Q0958-answer

**zh-Q0959** — 你想成為一名電影演員嗎？

Do you want to be an actor in a movie?

Why: Ability and intention. [[Mandarin Chinese#^zh-Q0959|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E6%83%B3%E6%88%90%E7%82%BA%E4%B8%80%E5%90%8D%E9%9B%BB%E5%BD%B1%E6%BC%94%E5%93%A1%E5%97%8E%EF%BC%9F)
^zh-Q0959-answer

**zh-Q0960** — 你想成為一名電影演員嗎？

Do you want to be an actor in a movie?

会, 能 and 可以 differ in learned ability, possibility and permission, with overlap in context. 要 and 想 express different strengths of intention/desire. These words do not trigger verb conjugation.

Why: Ability and intention. [[Mandarin Chinese#^zh-Q0960|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BD%A0%E6%83%B3%E6%88%90%E7%82%BA%E4%B8%80%E5%90%8D%E9%9B%BB%E5%BD%B1%E6%BC%94%E5%93%A1%E5%97%8E%EF%BC%9F)
^zh-Q0960-answer

**zh-Q0961** — 無論如何我一定要在明天前完成這工作。

In any case, I must finish this work by tomorrow.

Expected form: **要**

Why: Ability and intention. [[Mandarin Chinese#^zh-Q0961|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E7%84%A1%E8%AB%96%E5%A6%82%E4%BD%95%E6%88%91%E4%B8%80%E5%AE%9A%E8%A6%81%E5%9C%A8%E6%98%8E%E5%A4%A9%E5%89%8D%E5%AE%8C%E6%88%90%E9%80%99%E5%B7%A5%E4%BD%9C%E3%80%82)
^zh-Q0961-answer

**zh-Q0962** — 無論如何我一定要在明天前完成這工作。

In any case, I must finish this work by tomorrow.

Expected form: **要**

Why: Ability and intention. [[Mandarin Chinese#^zh-Q0962|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E7%84%A1%E8%AB%96%E5%A6%82%E4%BD%95%E6%88%91%E4%B8%80%E5%AE%9A%E8%A6%81%E5%9C%A8%E6%98%8E%E5%A4%A9%E5%89%8D%E5%AE%8C%E6%88%90%E9%80%99%E5%B7%A5%E4%BD%9C%E3%80%82)
^zh-Q0962-answer

**zh-Q0963** — 我也和你想的一样。

We think alike.

Expected form: **想**

Why: Ability and intention. [[Mandarin Chinese#^zh-Q0963|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E4%B9%9F%E5%92%8C%E4%BD%A0%E6%83%B3%E7%9A%84%E4%B8%80%E6%A0%B7%E3%80%82)
^zh-Q0963-answer

**zh-Q0964** — 我也和你想的一样。

We think alike.

Why: Ability and intention. [[Mandarin Chinese#^zh-Q0964|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E4%B9%9F%E5%92%8C%E4%BD%A0%E6%83%B3%E7%9A%84%E4%B8%80%E6%A0%B7%E3%80%82)
^zh-Q0964-answer

**zh-Q0965** — 我觉得今天会很热。

I think it will be hot today.

Why: Ability and intention. [[Mandarin Chinese#^zh-Q0965|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E8%A7%89%E5%BE%97%E4%BB%8A%E5%A4%A9%E4%BC%9A%E5%BE%88%E7%83%AD%E3%80%82)
^zh-Q0965-answer

**zh-Q0966** — 我觉得今天会很热。

I think it will be hot today.

会, 能 and 可以 differ in learned ability, possibility and permission, with overlap in context. 要 and 想 express different strengths of intention/desire. These words do not trigger verb conjugation.

Why: Ability and intention. [[Mandarin Chinese#^zh-Q0966|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E8%A7%89%E5%BE%97%E4%BB%8A%E5%A4%A9%E4%BC%9A%E5%BE%88%E7%83%AD%E3%80%82)
^zh-Q0966-answer

**zh-Q0967** — 我要向你学习很多。

I have a lot to learn from you.

Expected form: **要**

Why: Ability and intention. [[Mandarin Chinese#^zh-Q0967|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E8%A6%81%E5%90%91%E4%BD%A0%E5%AD%A6%E4%B9%A0%E5%BE%88%E5%A4%9A%E3%80%82)
^zh-Q0967-answer

**zh-Q0968** — 我要向你学习很多。

I have a lot to learn from you.

Expected form: **要**

Why: Ability and intention. [[Mandarin Chinese#^zh-Q0968|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E8%A6%81%E5%90%91%E4%BD%A0%E5%AD%A6%E4%B9%A0%E5%BE%88%E5%A4%9A%E3%80%82)
^zh-Q0968-answer

**zh-Q0969** — 他會做任何你要求他做的事。

He'll do whatever you ask him to.

Expected form: **要**

Why: Ability and intention. [[Mandarin Chinese#^zh-Q0969|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%96%E6%9C%83%E5%81%9A%E4%BB%BB%E4%BD%95%E4%BD%A0%E8%A6%81%E6%B1%82%E4%BB%96%E5%81%9A%E7%9A%84%E4%BA%8B%E3%80%82)
^zh-Q0969-answer

**zh-Q0970** — 他會做任何你要求他做的事。

He'll do whatever you ask him to.

Why: Ability and intention. [[Mandarin Chinese#^zh-Q0970|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%96%E6%9C%83%E5%81%9A%E4%BB%BB%E4%BD%95%E4%BD%A0%E8%A6%81%E6%B1%82%E4%BB%96%E5%81%9A%E7%9A%84%E4%BA%8B%E3%80%82)
^zh-Q0970-answer

**zh-Q0971** — 任何工作你都可以放心的交给他。

You can trust him with any job.

Why: Ability and intention. [[Mandarin Chinese#^zh-Q0971|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%BB%E4%BD%95%E5%B7%A5%E4%BD%9C%E4%BD%A0%E9%83%BD%E5%8F%AF%E4%BB%A5%E6%94%BE%E5%BF%83%E7%9A%84%E4%BA%A4%E7%BB%99%E4%BB%96%E3%80%82)
^zh-Q0971-answer

**zh-Q0972** — 任何工作你都可以放心的交给他。

You can trust him with any job.

会, 能 and 可以 differ in learned ability, possibility and permission, with overlap in context. 要 and 想 express different strengths of intention/desire. These words do not trigger verb conjugation.

Why: Ability and intention. [[Mandarin Chinese#^zh-Q0972|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%BB%BB%E4%BD%95%E5%B7%A5%E4%BD%9C%E4%BD%A0%E9%83%BD%E5%8F%AF%E4%BB%A5%E6%94%BE%E5%BF%83%E7%9A%84%E4%BA%A4%E7%BB%99%E4%BB%96%E3%80%82)
^zh-Q0972-answer

**zh-Q0973** — 不要在冰上滑倒啊。

Don't slip on the ice.

Expected form: **要**

Why: Ability and intention. [[Mandarin Chinese#^zh-Q0973|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%B8%8D%E8%A6%81%E5%9C%A8%E5%86%B0%E4%B8%8A%E6%BB%91%E5%80%92%E5%95%8A%E3%80%82)
^zh-Q0973-answer

**zh-Q0974** — 不要在冰上滑倒啊。

Don't slip on the ice.

Expected form: **要**

Why: Ability and intention. [[Mandarin Chinese#^zh-Q0974|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E4%B8%8D%E8%A6%81%E5%9C%A8%E5%86%B0%E4%B8%8A%E6%BB%91%E5%80%92%E5%95%8A%E3%80%82)
^zh-Q0974-answer

**zh-Q0975** — 在句子中不要写入额外信息，比如作者姓名。

Don't write extra information, such as the name of the author, within the sentence.

Expected form: **要**

Why: Ability and intention. [[Mandarin Chinese#^zh-Q0975|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%9C%A8%E5%8F%A5%E5%AD%90%E4%B8%AD%E4%B8%8D%E8%A6%81%E5%86%99%E5%85%A5%E9%A2%9D%E5%A4%96%E4%BF%A1%E6%81%AF%EF%BC%8C%E6%AF%94%E5%A6%82%E4%BD%9C%E8%80%85%E5%A7%93%E5%90%8D%E3%80%82)
^zh-Q0975-answer

**zh-Q0976** — 在句子中不要写入额外信息，比如作者姓名。

Don't write extra information, such as the name of the author, within the sentence.

Why: Ability and intention. [[Mandarin Chinese#^zh-Q0976|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%9C%A8%E5%8F%A5%E5%AD%90%E4%B8%AD%E4%B8%8D%E8%A6%81%E5%86%99%E5%85%A5%E9%A2%9D%E5%A4%96%E4%BF%A1%E6%81%AF%EF%BC%8C%E6%AF%94%E5%A6%82%E4%BD%9C%E8%80%85%E5%A7%93%E5%90%8D%E3%80%82)
^zh-Q0976-answer

**zh-Q0977** — 父母教育我要遵守承诺。

My parents teach me to abide by my promises.

Why: Ability and intention. [[Mandarin Chinese#^zh-Q0977|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E7%88%B6%E6%AF%8D%E6%95%99%E8%82%B2%E6%88%91%E8%A6%81%E9%81%B5%E5%AE%88%E6%89%BF%E8%AF%BA%E3%80%82)
^zh-Q0977-answer

**zh-Q0978** — 父母教育我要遵守承诺。

My parents teach me to abide by my promises.

会, 能 and 可以 differ in learned ability, possibility and permission, with overlap in context. 要 and 想 express different strengths of intention/desire. These words do not trigger verb conjugation.

Why: Ability and intention. [[Mandarin Chinese#^zh-Q0978|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E7%88%B6%E6%AF%8D%E6%95%99%E8%82%B2%E6%88%91%E8%A6%81%E9%81%B5%E5%AE%88%E6%89%BF%E8%AF%BA%E3%80%82)
^zh-Q0978-answer

**zh-Q0979** — 听说适时地补充水分可以预防中暑。

I hear that keeping yourself hydrated at appropriate times can help prevent heatstroke.

Expected form: **可以**

Why: Ability and intention. [[Mandarin Chinese#^zh-Q0979|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%90%AC%E8%AF%B4%E9%80%82%E6%97%B6%E5%9C%B0%E8%A1%A5%E5%85%85%E6%B0%B4%E5%88%86%E5%8F%AF%E4%BB%A5%E9%A2%84%E9%98%B2%E4%B8%AD%E6%9A%91%E3%80%82)
^zh-Q0979-answer

**zh-Q0980** — 听说适时地补充水分可以预防中暑。

I hear that keeping yourself hydrated at appropriate times can help prevent heatstroke.

Expected form: **可以**

Why: Ability and intention. [[Mandarin Chinese#^zh-Q0980|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E5%90%AC%E8%AF%B4%E9%80%82%E6%97%B6%E5%9C%B0%E8%A1%A5%E5%85%85%E6%B0%B4%E5%88%86%E5%8F%AF%E4%BB%A5%E9%A2%84%E9%98%B2%E4%B8%AD%E6%9A%91%E3%80%82)
^zh-Q0980-answer

**zh-Q0981** — 我寧願到不喜歡的公司工作，也不想渾渾噩噩的又過一年。

I would rather work for any company than waste another year.

Expected form: **想**

Why: Ability and intention. [[Mandarin Chinese#^zh-Q0981|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E5%AF%A7%E9%A1%98%E5%88%B0%E4%B8%8D%E5%96%9C%E6%AD%A1%E7%9A%84%E5%85%AC%E5%8F%B8%E5%B7%A5%E4%BD%9C%EF%BC%8C%E4%B9%9F%E4%B8%8D%E6%83%B3%E6%B8%BE%E6%B8%BE%E5%99%A9%E5%99%A9%E7%9A%84%E5%8F%88%E9%81%8E%E4%B8%80%E5%B9%B4%E3%80%82)
^zh-Q0981-answer

**zh-Q0982** — 我寧願到不喜歡的公司工作，也不想渾渾噩噩的又過一年。

I would rather work for any company than waste another year.

Why: Ability and intention. [[Mandarin Chinese#^zh-Q0982|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E5%AF%A7%E9%A1%98%E5%88%B0%E4%B8%8D%E5%96%9C%E6%AD%A1%E7%9A%84%E5%85%AC%E5%8F%B8%E5%B7%A5%E4%BD%9C%EF%BC%8C%E4%B9%9F%E4%B8%8D%E6%83%B3%E6%B8%BE%E6%B8%BE%E5%99%A9%E5%99%A9%E7%9A%84%E5%8F%88%E9%81%8E%E4%B8%80%E5%B9%B4%E3%80%82)
^zh-Q0982-answer

**zh-Q0983** — 我们不能嘲笑穷人。

We must not laugh at the poor.

Why: Ability and intention. [[Mandarin Chinese#^zh-Q0983|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E4%BB%AC%E4%B8%8D%E8%83%BD%E5%98%B2%E7%AC%91%E7%A9%B7%E4%BA%BA%E3%80%82)
^zh-Q0983-answer

**zh-Q0984** — 我们不能嘲笑穷人。

We must not laugh at the poor.

会, 能 and 可以 differ in learned ability, possibility and permission, with overlap in context. 要 and 想 express different strengths of intention/desire. These words do not trigger verb conjugation.

Why: Ability and intention. [[Mandarin Chinese#^zh-Q0984|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E4%BB%AC%E4%B8%8D%E8%83%BD%E5%98%B2%E7%AC%91%E7%A9%B7%E4%BA%BA%E3%80%82)
^zh-Q0984-answer

**zh-Q0985** — 我们要么喝葡萄酒，要么喝啤酒。

Let’s drink wine or beer.

Expected form: **要**

Why: Ability and intention. [[Mandarin Chinese#^zh-Q0985|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E4%BB%AC%E8%A6%81%E4%B9%88%E5%96%9D%E8%91%A1%E8%90%84%E9%85%92%EF%BC%8C%E8%A6%81%E4%B9%88%E5%96%9D%E5%95%A4%E9%85%92%E3%80%82)
^zh-Q0985-answer

**zh-Q0986** — 我们要么喝葡萄酒，要么喝啤酒。

Let’s drink wine or beer.

Expected form: **要**

Why: Ability and intention. [[Mandarin Chinese#^zh-Q0986|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E4%BB%AC%E8%A6%81%E4%B9%88%E5%96%9D%E8%91%A1%E8%90%84%E9%85%92%EF%BC%8C%E8%A6%81%E4%B9%88%E5%96%9D%E5%95%A4%E9%85%92%E3%80%82)
^zh-Q0986-answer

**zh-Q0987** — 能否请您给我看一下您的护照？

Will you show me your passport, please?

Expected form: **能**

Why: Ability and intention. [[Mandarin Chinese#^zh-Q0987|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%83%BD%E5%90%A6%E8%AF%B7%E6%82%A8%E7%BB%99%E6%88%91%E7%9C%8B%E4%B8%80%E4%B8%8B%E6%82%A8%E7%9A%84%E6%8A%A4%E7%85%A7%EF%BC%9F)
^zh-Q0987-answer

**zh-Q0988** — 能否请您给我看一下您的护照？

Will you show me your passport, please?

Why: Ability and intention. [[Mandarin Chinese#^zh-Q0988|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E8%83%BD%E5%90%A6%E8%AF%B7%E6%82%A8%E7%BB%99%E6%88%91%E7%9C%8B%E4%B8%80%E4%B8%8B%E6%82%A8%E7%9A%84%E6%8A%A4%E7%85%A7%EF%BC%9F)
^zh-Q0988-answer

**zh-Q0989** — 我们去参加舞会了。

We went to the dance.

Why: Ability and intention. [[Mandarin Chinese#^zh-Q0989|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E4%BB%AC%E5%8E%BB%E5%8F%82%E5%8A%A0%E8%88%9E%E4%BC%9A%E4%BA%86%E3%80%82)
^zh-Q0989-answer

**zh-Q0990** — 我们去参加舞会了。

We went to the dance.

会, 能 and 可以 differ in learned ability, possibility and permission, with overlap in context. 要 and 想 express different strengths of intention/desire. These words do not trigger verb conjugation.

Why: Ability and intention. [[Mandarin Chinese#^zh-Q0990|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E4%BB%AC%E5%8E%BB%E5%8F%82%E5%8A%A0%E8%88%9E%E4%BC%9A%E4%BA%86%E3%80%82)
^zh-Q0990-answer

**zh-Q0991** — 我想要一點柳橙汁。

I want some orange juice.

Expected form: **想**

Why: Ability and intention. [[Mandarin Chinese#^zh-Q0991|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E6%83%B3%E8%A6%81%E4%B8%80%E9%BB%9E%E6%9F%B3%E6%A9%99%E6%B1%81%E3%80%82)
^zh-Q0991-answer

**zh-Q0992** — 我想要一點柳橙汁。

I want some orange juice.

Expected form: **想**

Why: Ability and intention. [[Mandarin Chinese#^zh-Q0992|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E6%83%B3%E8%A6%81%E4%B8%80%E9%BB%9E%E6%9F%B3%E6%A9%99%E6%B1%81%E3%80%82)
^zh-Q0992-answer

**zh-Q0993** — 我們沒有必要出席這個講座。

It is not necessary for us to attend this lecture.

Expected form: **要**

Why: Ability and intention. [[Mandarin Chinese#^zh-Q0993|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E5%80%91%E6%B2%92%E6%9C%89%E5%BF%85%E8%A6%81%E5%87%BA%E5%B8%AD%E9%80%99%E5%80%8B%E8%AC%9B%E5%BA%A7%E3%80%82)
^zh-Q0993-answer

**zh-Q0994** — 我們沒有必要出席這個講座。

It is not necessary for us to attend this lecture.

Why: Ability and intention. [[Mandarin Chinese#^zh-Q0994|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E5%80%91%E6%B2%92%E6%9C%89%E5%BF%85%E8%A6%81%E5%87%BA%E5%B8%AD%E9%80%99%E5%80%8B%E8%AC%9B%E5%BA%A7%E3%80%82)
^zh-Q0994-answer

**zh-Q0995** — 我年紀夠大了可以自己一個人住。

I'm old enough to live by myself.

Why: Ability and intention. [[Mandarin Chinese#^zh-Q0995|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E5%B9%B4%E7%B4%80%E5%A4%A0%E5%A4%A7%E4%BA%86%E5%8F%AF%E4%BB%A5%E8%87%AA%E5%B7%B1%E4%B8%80%E5%80%8B%E4%BA%BA%E4%BD%8F%E3%80%82)
^zh-Q0995-answer

**zh-Q0996** — 我年紀夠大了可以自己一個人住。

I'm old enough to live by myself.

会, 能 and 可以 differ in learned ability, possibility and permission, with overlap in context. 要 and 想 express different strengths of intention/desire. These words do not trigger verb conjugation.

Why: Ability and intention. [[Mandarin Chinese#^zh-Q0996|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E5%B9%B4%E7%B4%80%E5%A4%A0%E5%A4%A7%E4%BA%86%E5%8F%AF%E4%BB%A5%E8%87%AA%E5%B7%B1%E4%B8%80%E5%80%8B%E4%BA%BA%E4%BD%8F%E3%80%82)
^zh-Q0996-answer

**zh-Q0997** — 我需要购买新的镜架。

I need to buy new spectacle frames.

Expected form: **要**

Why: Ability and intention. [[Mandarin Chinese#^zh-Q0997|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E9%9C%80%E8%A6%81%E8%B4%AD%E4%B9%B0%E6%96%B0%E7%9A%84%E9%95%9C%E6%9E%B6%E3%80%82)
^zh-Q0997-answer

**zh-Q0998** — 我需要购买新的镜架。

I need to buy new spectacle frames.

Expected form: **要**

Why: Ability and intention. [[Mandarin Chinese#^zh-Q0998|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E9%9C%80%E8%A6%81%E8%B4%AD%E4%B9%B0%E6%96%B0%E7%9A%84%E9%95%9C%E6%9E%B6%E3%80%82)
^zh-Q0998-answer

**zh-Q0999** — 我昨天非常想念你。

I missed you very much yesterday.

Expected form: **想**

Why: Ability and intention. [[Mandarin Chinese#^zh-Q0999|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E6%98%A8%E5%A4%A9%E9%9D%9E%E5%B8%B8%E6%83%B3%E5%BF%B5%E4%BD%A0%E3%80%82)
^zh-Q0999-answer

**zh-Q1000** — 我昨天非常想念你。

I missed you very much yesterday.

Why: Ability and intention. [[Mandarin Chinese#^zh-Q1000|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=cmn&query=%E6%88%91%E6%98%A8%E5%A4%A9%E9%9D%9E%E5%B8%B8%E6%83%B3%E5%BF%B5%E4%BD%A0%E3%80%82)
^zh-Q1000-answer


## Read and speak

Read the native sentence first, identify its predicate and one grammar form, then check the translation. Say it aloud and change one detail.

### Learning with a clear purpose

我在学习一门新的语言。每天，我读一篇短文，听一些清楚的例句。我把有用的词写在笔记本里。如果我犯了错误，我会查看语法规则，然后再试一次。我的目标是理解别人，并清楚地表达自己的想法。

I am learning a new language. Each day, I read a short text and listen to clear examples. I write useful words in a notebook. When I make a mistake, I check the rule and try again. My goal is to understand people and express my ideas clearly.

### Environment: making trade-offs explicit

保护环境的措施往往同时带来收益和成本。一项政策可能减少污染，却增加某些家庭的支出。讨论这类问题时，不能只问总收益是否大于总成本，还应当考虑哪些人获得收益，哪些人承担成本。不同地区的情况也可能不同。因此，合理的评估需要说明比较的范围、使用的数据以及尚未解决的不确定性。把这些条件说清楚，并不意味着反对环境保护，而是为了让选择更加透明。

Environmental measures often bring both benefits and costs. A policy may reduce pollution but increase some households' spending. Evaluation must consider not only total benefits and costs, but also who receives the benefits and bears the costs. Regional conditions can differ. A sound assessment states scope, evidence and unresolved uncertainty. Making these conditions explicit supports transparent choices rather than opposing environmental protection.

![[Resources/Audio/zh/Reading passage.mp3]]

**他们不会找到汤姆。**

They won't find Tom.

**来吧，我们一起去。**

Come on, let's go.

**你們要是用刀劍刺我們，我們不是也會出血嗎？**

If you prick us, do we not bleed?

**我吹次中音薩克斯風。**

I play the tenor saxophone.

**实在抱歉，老板在睡觉。请您明天再来。**

I'm sorry, my boss is sleeping right now. Please come back tomorrow.

**莎士比亞是一位作家的名字。**

Shakespeare is the name of a writer.

**今天出现了很多问题。**

Today, many problems were encountered.

**他已經成為了棒球隊員。**

He has made the baseball team.

**你为什么让我看这个？**

Why did you show me this?

**那个男孩子见到鬼的时候吓了一跳。**

The boy fell of fright when he saw a ghost.

**幫我看著我的相機。**

Watch my camera for me.

**我以前在這條河裡游泳。**

I used to swim in this river.

**哪個比較重，鉛還是黃金？**

Which is heavier, lead or gold?

**勇气是一个奇怪的东西：没有任何人对它有把握**

Courage is a strange thing: One can never be sure of it.

**简的美丽丝毫不逊色于她母亲。**

Jane is no less beautiful than her mother.

## Professional writing

Write an introduction, a polite request, an explanation of a finding, a summary of a passage and a tactful disagreement. Use the professional/advanced lessons for models.

## PDF edition

[[Resources/PDFs/Mandarin Chinese.pdf|Open the complete printable book]]


<!-- individual-letter-audio -->
## Hear each letter separately

These recordings demonstrate labelled pinyin syllables, including tone contrasts. They are syllable examples, not English-style letter names.

### b · bō · 波

![[Resources/Audio/zh/Letters/001.mp3]]

### p · pō · 坡

![[Resources/Audio/zh/Letters/002.mp3]]

### m · mō · 摸

![[Resources/Audio/zh/Letters/003.mp3]]

### f · fó · 佛

![[Resources/Audio/zh/Letters/004.mp3]]

### d · dé · 德

![[Resources/Audio/zh/Letters/005.mp3]]

### t · tè · 特

![[Resources/Audio/zh/Letters/006.mp3]]

### n · ne · 呢

![[Resources/Audio/zh/Letters/007.mp3]]

### l · lè · 乐

![[Resources/Audio/zh/Letters/008.mp3]]

### g · gē · 哥

![[Resources/Audio/zh/Letters/009.mp3]]

### k · kē · 科

![[Resources/Audio/zh/Letters/010.mp3]]

### h · hē · 喝

![[Resources/Audio/zh/Letters/011.mp3]]

### j · jī · 鸡

![[Resources/Audio/zh/Letters/012.mp3]]

### q · qī · 七

![[Resources/Audio/zh/Letters/013.mp3]]

### x · xī · 西

![[Resources/Audio/zh/Letters/014.mp3]]

### zh · zhī · 知

![[Resources/Audio/zh/Letters/015.mp3]]

### ch · chī · 吃

![[Resources/Audio/zh/Letters/016.mp3]]

### sh · shī · 诗

![[Resources/Audio/zh/Letters/017.mp3]]

### r · rì · 日

![[Resources/Audio/zh/Letters/018.mp3]]

### z · zī · 资

![[Resources/Audio/zh/Letters/019.mp3]]

### c · cí · 词

![[Resources/Audio/zh/Letters/020.mp3]]

### s · sī · 丝

![[Resources/Audio/zh/Letters/021.mp3]]

### a · ā · 阿

![[Resources/Audio/zh/Letters/022.mp3]]

### o · ó · 哦

![[Resources/Audio/zh/Letters/023.mp3]]

### e · é · 鹅

![[Resources/Audio/zh/Letters/024.mp3]]

### i · yī · 衣

![[Resources/Audio/zh/Letters/025.mp3]]

### u · wū · 乌

![[Resources/Audio/zh/Letters/026.mp3]]

### ü · yú · 鱼

![[Resources/Audio/zh/Letters/027.mp3]]

### ā á ǎ à a · mā, má, mǎ, mà; neutral second syllable in māma

![[Resources/Audio/zh/Letters/028.mp3]]
<!-- /individual-letter-audio -->
