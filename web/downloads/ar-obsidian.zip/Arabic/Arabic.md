# Arabic

Professional ambition - C1-oriented study

Everything for this language is in this note. Open a rule, read its examples and follow its practice link. Answers stay in this same note.

[[Start Here|All languages]] · [[Sources and licenses|Sources]]

## Start reading

### الأَبْجَدِيَّة / الحُرُوف الهِجَائِيَّة

| Written form | Name / reading | Related forms |
|---|---|---|
| ا | أَلِف alif | ا · ـا · ـا |
| ب | بَاء bāʾ | بـ · ـبـ · ـب |
| ت | تَاء tāʾ | تـ · ـتـ · ـت |
| ث | ثَاء thāʾ | ثـ · ـثـ · ـث |
| ج | جِيم jīm | جـ · ـجـ · ـج |
| ح | حَاء ḥāʾ | حـ · ـحـ · ـح |
| خ | خَاء khāʾ | خـ · ـخـ · ـخ |
| د | دَال dāl | د · ـد · ـد |
| ذ | ذَال dhāl | ذ · ـذ · ـذ |
| ر | رَاء rāʾ | ر · ـر · ـر |
| ز | زَاي zāy | ز · ـز · ـز |
| س | سِين sīn | سـ · ـسـ · ـس |
| ش | شِين shīn | شـ · ـشـ · ـش |
| ص | صَاد ṣād | صـ · ـصـ · ـص |
| ض | ضَاد ḍād | ضـ · ـضـ · ـض |
| ط | طَاء ṭāʾ | طـ · ـطـ · ـط |
| ظ | ظَاء ẓāʾ | ظـ · ـظـ · ـظ |
| ع | عَيْن ʿayn | عـ · ـعـ · ـع |
| غ | غَيْن ghayn | غـ · ـغـ · ـغ |
| ف | فَاء fāʾ | فـ · ـفـ · ـف |
| ق | قَاف qāf | قـ · ـقـ · ـق |
| ك | كَاف kāf | كـ · ـكـ · ـك |
| ل | لَام lām | لـ · ـلـ · ـل |
| م | مِيم mīm | مـ · ـمـ · ـم |
| ن | نُون nūn | نـ · ـنـ · ـن |
| ه | هَاء hāʾ | هـ · ـهـ · ـه |
| و | وَاو wāw | و · ـو · ـو |
| ي | يَاء yāʾ | يـ · ـيـ · ـي |

![[Resources/Audio/ar/Script and first phrases.mp3]]

The player above is synthetic speech. Word tracks below work offline.

### Read and write right to left

Arabic has 28 core letters. Many change appearance according to position. The chart shows forms using connection strokes. ا د ذ ر ز و do not join to the letter following them on the left; a word can therefore contain a visible gap without a space.

### Vowels and extra signs

Short vowels are fatḥa َ /a/, kasra ِ /i/ and ḍamma ُ /u/. Sukūn ْ marks no following short vowel; shadda ّ marks consonant doubling. Long vowels use ا و ي in appropriate contexts. Hamza ء is a glottal stop with several written seats. ة is tāʾ marbūṭa, and ى is alif maqṣūra.

### Hear contrasts before speeding up

ح/ه, ع/ء, س/ص, ت/ط and د/ض require separate listening practice. MSA pronunciation differs from dialect pronunciation. Learn short versus long vowels and consonant doubling: they can distinguish words. Vowel marks are useful initially, but ordinary adult texts are largely unvowelled.

### Sun and moon letters

Sun letters: ت ث د ذ ر ز س ش ص ض ط ظ ل ن. After ال, their first sound is doubled and l is not separately pronounced: الشَّمْس (ash-shams), the sun. Moon letters: ا ب ج ح خ ع غ ف ق ك م ه و ي. The l is heard before them: القَمَر (al-qamar), the moon. This pronunciation distinction does not remove ل from the written article.

### Join letters into a word

ك + ت + ا + ب → كتاب = book (kitāb). Alif does not join onward, so the final ب is visually separated while remaining in the same word.

### Use roots and patterns

ك ت ب is a writing-related root: كَتَبَ = he wrote; كِتَاب = book; كَاتِب = writer; مَكْتَب = office/desk. The root guides recognition but does not guarantee an exact meaning for every pattern.

### Build definiteness and possession

كتاب → الكتاب = a book → the book. كتاب الطالب = the student’s book. In this iḍāfa possession construction, the first noun normally has neither ال nor tanwīn.

**مرحبًا.**

Hello.

**أنا أتعلم العربية.**

I am learning Arabic.

**هل يمكنك أن تكرر، من فضلك؟**

Can you repeat, please?

**ماذا تعني هذه الكلمة؟**

What does this word mean?

### Grammar terms in plain English

**Noun** — A word naming a person, thing or idea: student, book, freedom.

**Verb** — A word describing an action or state: read, know, be.

**Subject** — The participant linked to the main verb’s subject pattern. In The student reads a book, the student is the subject.

**Object** — A participant selected by a verb. In The student reads a book, a book is the direct object.

**Agreement** — One word changes to match another, for example an adjective matching a noun’s gender and number.

**Case** — A noun/pronoun form marking its relationship in a sentence. Cases can mark subjects, objects, possession or relations usually expressed by English prepositions.

**Gender** — A grammatical noun class. It does not always describe the sex of a person or any physical property.

**Tense** — A verb system that relates a situation to a time, often past or non-past.

**Aspect** — How a situation is viewed: unfolding, completed, habitual, experienced or in a resulting state.

**Infinitive** — A non-finite verb form often used for a dictionary entry or a complement. It does not by itself give the ordinary person/tense pattern.

**Participle** — A verb-derived form used in compound predicates or as a modifier; its exact function depends on the language and construction.

**Clause** — A unit organised around a predicate. One sentence can contain several clauses.

**Register** — Language choices suited to a situation: casual conversation, polite requests, academic writing or another context.

## Grammar, examples and practice

### Script, sounds and word structure

Arabic is written right-to-left, while numbers and embedded Latin text need careful directional handling. Letters have contextual shapes; some do not join to the following letter. Short vowels are often omitted outside teaching and special texts. Long vowels, pharyngeal sounds, emphatic consonants and gemination require audio. A root supplies a lexical family and a pattern shapes a word, but not every meaning is predictable from morphology alone.

**كتاب / كتب**

book / books A broken plural must be learned, not generated by one suffix.

**كاتب / مكتبة**

writer / library Related lexical family; meaning depends on the complete form.

<details><summary>What belongs on an Arabic noun card?</summary>

Vowelled singular, plural, gender, root where useful, meaning and an example.

</details>

<details><summary>Can every plural be formed by adding ون?</summary>

No. Sound plurals and many broken-plural patterns have distinct distributions.

</details>

### Nominal sentences, agreement and definiteness

Present nominal sentences can omit an English-style is: التقرير مهم. The definite article ال attaches to the noun and participates in pronunciation assimilation before sun letters. Adjectives follow nouns and agree in relevant features. Nonhuman plurals commonly take feminine singular agreement in standard patterns. An إضافة possession construction links nouns, with definiteness and case relationships determined by the whole phrase.

**التقرير مهم.**

The report is important. Nominal sentence without a present copula.

**نتائج الدراسة**

the results of the study An إضافة relationship.

#### Independent pronouns

Independent pronouns identify person and number; Arabic also distinguishes gender and dual forms. A present nominal sentence normally has no expressed be verb. Standard and dialect pronoun systems differ.

**أنا آسف، ولكن هذا لم يعد متاحاً.**

I'm sorry, but it's no longer available.

**أنا أعرف أين يعمل توم.**

I know where Tom works.

![[Resources/Audio/ar/Rule 01.mp3]]

[[Arabic#^ar-Q0001|Practise this rule (50 questions)]]

#### Demonstratives

Demonstratives agree in relevant gender/number distinctions. هذا كتاب is this is a book, whereas هذا الكتاب refers to this book as a phrase. Definiteness affects the structure.

**هذا أغبى ما قُلتُه على الإطلاق.**

That's the stupidest thing I've ever said.

**أداء هذه السيارة أفضل من تلك.**

This car has a better performance than that one.

![[Resources/Audio/ar/Rule 02.mp3]]

[[Arabic#^ar-Q0051|Practise this rule (50 questions)]]

#### Definite article

الـ marks definiteness and is written attached. Before sun letters its l sound assimilates to the following consonant, which is doubled in pronunciation. Written spelling still retains ال.

**لا شيئَ مثالي.**

Nothing's perfect.

**صديق في اليد خير من اثنين على الشجرة!**

A friend in hand is worth two in the bush!

![[Resources/Audio/ar/Rule 03.mp3]]

[[Arabic#^ar-Q0101|Practise this rule (50 questions)]]

#### Adjective and noun agreement

Attributive adjectives generally follow the noun and agree in gender, definiteness, case and relevant number patterns. Non-human plurals commonly take feminine singular agreement in MSA.

**ذكر تقرير جديد أن احتمال أن تواجه الفتيات سوء التغذية والفقرَ والعنف والحرمان من التعليم أكثرُ من الأولاد.**

Girls are more likely than boys to be malnourished, suffer poverty, face violence and be refused an education, according to a new report.

**يريد الناس استخدام التقنية الجديد التي توفرت.**

People want to use the new technology which is available.

![[Resources/Audio/ar/Rule 04.mp3]]

[[Arabic#^ar-Q0151|Practise this rule (50 questions)]]

#### Possession and iḍāfa

Possessive suffixes attach to nouns. An iḍāfa noun chain expresses another possession relation; its first noun normally has neither the definite article nor tanwīn. Pronunciation differs by dialect and register.

**هىَ ليست أختي.**

She's not my sister.

**أنا آسف يا محمد، لقد نسيت اسمك!**

I'm sorry Mohammed, I forgot your name!

![[Resources/Audio/ar/Rule 05.mp3]]

[[Arabic#^ar-Q0201|Practise this rule (50 questions)]]

#### Prepositions

Prepositions mark relations and govern genitive in fully inflected MSA. Their complements can be nouns or pronominal suffixes. English in/on/to choices do not map one-to-one.

**نشأ سامي في مجتمع مسلم.**

Sami grew up in a Muslim community.

**بإمكانك استخدامها في أي وقت.**

You can use it anytime.

![[Resources/Audio/ar/Rule 13.mp3]]

[[Arabic#^ar-Q0601|Practise this rule (50 questions)]]

#### Coordination and quantification

و is usually attached to the following written word; أو marks alternatives. كل/بعض create quantity phrases with their own agreement and possession-like relations. A separate single و is not the normal spelling in connected prose.

**لقد وصلتَ للتّو.**

You have only just arrived.

**كلا سامي و ليلى مسلمين.**

Sami and Layla are both Muslim.

![[Resources/Audio/ar/Rule 19.mp3]]

[[Arabic#^ar-Q0901|Practise this rule (50 questions)]]

<details><summary>Why is translating every English is as a separate verb wrong?</summary>

Present nominal Arabic predicates normally do not require that copula.

</details>

<details><summary>Explain بيانات جديدة.</summary>

New data. Nonhuman plural agreement commonly uses a feminine singular adjective.

</details>

### Verbs, negation and mood

Learn perfect and imperfect stems with person, gender and number patterns. Standard negation includes لا for many nonpast statements, لم with a jussive imperfect for past denial, لن with a subjunctive imperfect for future denial, and ليس for many nominal predicates. Verb-derived forms add semantic relationships but must be learned lexically. Root knowledge does not automatically determine vowel patterns.

**لم أقرأ التقرير.**

I did not read the report. لم governs a jussive imperfect in standard Arabic.

**لن نستخدم هذه الطريقة.**

We will not use this method. لن governs the subjunctive imperfect.

#### Past kāna

كان and its forms establish a past state and participate in other constructions. In fully inflected MSA, kāna affects the case pattern of a nominal predicate. Gender/person distinctions matter.

**كان سامي يريد شخصا يعتني به.**

Sami wanted someone to watch over him.

**كان فاضل يتمنّى أن يكون ليده ما كان عند ليلى.**

Fadil wanted what Layla had.

![[Resources/Audio/ar/Rule 06.mp3]]

[[Arabic#^ar-Q0251|Practise this rule (50 questions)]]

#### Negation lā and laysa

لا negates various verbal/general constructions; ليس negates many nominal predicates. Their grammar is not identical. Dialects use different combinations and should be practised in their own section.

**توم ليس وحيداً الآن.**

Tom isn't lonely now.

**لا أريد وظيفة بدوام كامل.**

I don't want a full-time job.

![[Resources/Audio/ar/Rule 07.mp3]]

[[Arabic#^ar-Q0301|Practise this rule (50 questions)]]

#### Past negation lam

لم normally negates a past occurrence using a jussive imperfect verb. It is not followed mechanically by an ordinary past form. Unvowelled text hides some mood distinctions.

**لم يتزوج سامي قطّ.**

Sami never married.

**لم نكن نتقاتل**

We weren't fighting.

![[Resources/Audio/ar/Rule 08.mp3]]

[[Arabic#^ar-Q0351|Practise this rule (50 questions)]]

#### Future negation lan

لن normally introduces future-oriented negation with a subjunctive imperfect form in MSA. The written particle is separate from the verb. Contrast its time relation with لم.

**لن أنس مراسلة أمّي.**

I will not forget to write to my mother.

**لن تؤذي ذبابة.**

It wouldn't harm a fly.

![[Resources/Audio/ar/Rule 09.mp3]]

[[Arabic#^ar-Q0401|Practise this rule (50 questions)]]

#### Ma and other negatives

ما has several functions, including negation, interrogation and relative/content uses. A form match alone cannot decide the function. Inspect the surrounding predicate and the translation.

**ما زال ذراعي يؤلمني.**

My arm still hurts.

**ما اسم صديقك؟**

What's your friend's name?

![[Resources/Audio/ar/Rule 10.mp3]]

[[Arabic#^ar-Q0451|Practise this rule (50 questions)]]

#### Common verbal predicates

Arabic verbs encode person, gender, number and aspect/tense series. Imperfect prefixes are part of the agreement pattern. Record a verb’s past, imperfect and verbal noun with a sentence.

**يريد سامي أن يتقدّم في حياته.**

Sami wants to move on with his life.

**سامي يحبّ رسوم الأنمي الإباحيّة.**

Sami likes anime porn.

![[Resources/Audio/ar/Rule 11.mp3]]

[[Arabic#^ar-Q0501|Practise this rule (50 questions)]]

#### Future markers

MSA uses سوف or prefixed سـ in common future constructions. A prefixed marker is not a separate word in spelling. Dialect future markers differ and belong in the dialect material.

**سوف يكون عندنا الكثير من الطعام.**

We'll have plenty of food.

**سوف أشتري هديّة لتوم.**

I'll buy a gift for Tom.

![[Resources/Audio/ar/Rule 12.mp3]]

[[Arabic#^ar-Q0551|Practise this rule (50 questions)]]

<details><summary>Distinguish لم and لن.</summary>

لم denies a past occurrence; لن denies a future one, with different mood government.

</details>

<details><summary>What should a verb card include?</summary>

Perfect/imperfect forms, verbal noun where useful, government, derived family and examples.

</details>

### Relatives, formal compression and case

Standard Arabic has grammatical case and mood endings that may be absent in ordinary unvowelled writing and are often reduced at pauses. Relative pronouns agree with antecedents, while indefinite noun modifiers can use clause patterns without the same explicit relative marker. Long formal sentences require tracking pronoun reference and agreement. MSA production and dialect speech should be kept as distinct register systems.

**الطريقة التي نستخدمها**

the method we use Feminine relative التي; object suffix ها resumes the method.

**تشير النتائج إلى ...**

The results indicate ... تشير إلى is weaker than proving.

#### Relative forms

Definite relative constructions use forms agreeing with the antecedent. Indefinite noun modification can use a relative-like clause without this same overt relative word. Agreement and referential status both matter.

**قام توم بنفس الشيء الذي قامت به ماريا**

Tom did the same thing Mary did.

**أراني توم القصائد التي كتبها حين كان مراهقا.**

Tom showed me the poems that he'd written when he was a teenager.

![[Resources/Audio/ar/Rule 14.mp3]]

[[Arabic#^ar-Q0651|Practise this rule (50 questions)]]

#### Content and purpose

أن before a verb and أنّ before a nominal clause belong to distinct complement patterns. Purpose can use كي or related structures. Unvowelled أن requires contextual interpretation.

**هل سبق و أن قمتِ بعرض للتّعرّي؟**

Have you ever stripped before?

**إنه خطر أن تقود بتهور.**

It is dangerous to drive so fast.

![[Resources/Audio/ar/Rule 15.mp3]]

[[Arabic#^ar-Q0701|Practise this rule (50 questions)]]

#### Questions

هل forms many yes/no questions; other words request specific information. من can be who or from, depending on structure and pronunciation. Preserve the intended question relation.

**"هل قبلتها؟" "نعم، قبلتها.**

"Did you kiss her?" "Yes, I kissed her."

**متى يمكننا الأكل؟**

When can we eat?

![[Resources/Audio/ar/Rule 16.mp3]]

[[Arabic#^ar-Q0751|Practise this rule (50 questions)]]

#### Conditions

إذا commonly frames expected/real conditions, إن conditional patterns with specific MSA mood rules, and لو many counterfactuals. These are not freely interchangeable English if equivalents.

**غيري العلم، لو سمحت.**

Change the flag, please.

**”أنا أكرهكِ.“ ”طلّقني إذا. “**

"I hate you." "Divorce me then."

![[Resources/Audio/ar/Rule 17.mp3]]

[[Arabic#^ar-Q0801|Practise this rule (50 questions)]]

<details><summary>Identify the resumptive reference in نستخدمها.</summary>

ها refers to الطريقة, the object of using.

</details>

<details><summary>Should dialect negation automatically replace MSA negation in a formal paper?</summary>

No. Register and grammatical systems differ.

</details>

### Research reading and professional courtesy

Teaching passage: تشير النتائج إلى علاقة بين عاملين. لكنها لا تثبت أن أحدهما يسبب الآخر. يجب مراعاة ظروف الدراسة عند تقييم الاستنتاج.
Translation: The results indicate a relationship between two factors. But they do not prove that one causes the other. The study conditions must be considered when assessing the conclusion. The passage is formal MSA; spoken companions have their own grammar and idiom.

**هل يمكنك توضيح هذه النقطة؟**

Could you clarify this point? A clear formal request.

**هذا الاستنتاج ليس نهائيا.**

This conclusion is not final. ليس negates the nominal predicate; full vowel notation would expose case endings.

#### Cause and concession

لأن supplies a reason; لكن introduces contrast; لذلك a consequence. Attached pronouns and nominal clauses affect the surrounding grammar. Distinguish argument relationships carefully.

**لكن لديك أطفال.**

But you have kids.

**كان سامي بحاجة لذلك المال.**

Sami needed the money.

![[Resources/Audio/ar/Rule 18.mp3]]

[[Arabic#^ar-Q0851|Practise this rule (50 questions)]]

#### Courtesy and certainty

ربما limits certainty, يمكن expresses possibility/ability in suitable constructions, and يجب expresses obligation/necessity. Professional Arabic distinguishes a supported claim from a proposed explanation.

**يجب ان تذهب للبيت ؟**

Shouldn't you go home?

**اتصل بي حين تأتي إلى طوكيو رجاءً.**

Please get in touch with me when you come to Tokyo.

![[Resources/Audio/ar/Rule 20.mp3]]

[[Arabic#^ar-Q0951|Practise this rule (50 questions)]]

<details><summary>What should a summary preserve?</summary>

Indication of a relationship, denial of causal proof and a requirement to consider conditions.

</details>

<details><summary>Write a 100-word formal request.</summary>

Use MSA throughout, correct agreement, clear pronoun references and an appropriate salutation.

</details>

### Arabic - Egyptian

This companion uses broadly Cairene Egyptian as a starting model. It does not represent every Egyptian variety. Arabic-script examples have common teaching spellings rather than a single official dialect orthography. Romanised reading aids are optional personal notes. Use MSA for formal research writing and Egyptian for its appropriate spoken contexts.

![[Resources/Audio/ar/Egyptian examples.mp3]]

#### Pronunciation and local vocabulary

Cairene ج commonly corresponds to /g/, and ق can be a glottal stop in many everyday words, with lexical and social exceptions. Emphatic and pharyngeal consonants still need careful practice. Egyptian vocabulary and pronunciation are not generated by replacing two letters in an MSA sentence.

**إزيك؟**

How are you? A common Egyptian greeting; add appropriate endings for the addressee.

**دلوقتي**

now Everyday Egyptian vocabulary.

<details><summary>Is every Egyptian ق automatically a glottal stop?</summary>

No. Register, word and speaker can affect realisation.

</details>

<details><summary>What should a dialect phrase card record?</summary>

Location, addressee, pronunciation model and context.

</details>

#### Aspect and negation

A b-prefix often marks ordinary indicative/habitual present forms; ongoing activity and future reference have dialect-specific patterns. Egyptian verbal negation commonly surrounds the verb with ما ... ش. مش often negates nominal predicates and appears in other constructions. Do not paste this circumfix onto every MSA verb and assume the result is idiomatic Egyptian.

**ما فهمتش.**

I did not understand. A common first-person past negative.

**أنا مش جاهز.**

I am not ready. Male speaker, nominal negation with مش.

<details><summary>Contrast مش and ما ... ش in the examples.</summary>

مش negates a nominal predicate here; the circumfix negates the past verbal form.

</details>

<details><summary>What changes for a female speaker saying ready?</summary>

جاهزة is the usual feminine adjective form.

</details>

#### Requests and spoken professional interaction

Learn real exchanges: asking for repetition, checking an appointment, clarifying a price and explaining a delay. Formal workplaces may mix MSA-derived vocabulary with dialect grammar. Choose a natural register from a local model rather than reading a formal MSA email aloud and labelling it Egyptian.

**ممكن توضح النقطة دي؟**

Could you clarify this point? Spoken request with post-nominal demonstrative دي.

**أنا محتاج معلومات أكتر.**

I need more information. Male speaker; محتاجة for a female speaker.

<details><summary>Role-play a clarification exchange.</summary>

Use the request, repeat your understanding and ask whether it is correct. Record it with a model speaker.

</details>

<details><summary>Should this dialect replace MSA in all reading?</summary>

No. Formal written resources mostly require MSA; dialect texts and speech have their own place.

</details>

### Arabic - Levantine

Levantine covers several communities across Syria, Lebanon, Jordan and Palestine. Examples here are broadly compatible teaching forms, with an initial urban central-Levantine orientation. Select a specific community for pronunciation and advanced production. Regional disagreement is not automatically an error.

![[Resources/Audio/ar/Levantine examples.mp3]]

#### Variation, sounds and everyday expressions

Realisation of ق varies across urban, rural and other communities. The same regional label contains different vowels and vocabulary. كيفك and هلّق are common in many central-Levantine models; other communities use alternatives. Learn complete audio-backed exchanges rather than treating Levantine as one uniform accent.

**كيفك؟**

How are you? Pronunciation and addressee endings vary.

**هلّق**

now Common in many Syrian/Lebanese contexts; not universal throughout the region.

<details><summary>What should you choose before advanced accent imitation?</summary>

A specific community and model speaker.

</details>

<details><summary>Why is a vocabulary difference within Levantine not necessarily wrong?</summary>

The regional family includes several established local systems.

</details>

#### Aspect, future and negation

Many Levantine varieties use b- for indicative/habitual present and عم for ongoing action in appropriate patterns. رح commonly introduces future reference. Negation varies: ما for many verbs, and مو or مش for nominal predicates according to community. Southern varieties can use -ش patterns. Keep one chosen system consistent before expanding comprehension.

**ما فهمت.**

I did not understand. A common verbal negative.

**رح أقرأ التقرير.**

I will read the report. Future marker رح with a verb form appropriate to the speaker.

<details><summary>Should مو and مش be treated as interchangeable in every community?</summary>

No. Their distribution depends on locality and construction.

</details>

<details><summary>How should an ongoing-action pattern be learned?</summary>

From complete local examples with audio and the appropriate use of عم and verb form.

</details>

#### Requests and interaction

Professional dialect interaction still requires precise clarification and tact. Spoken grammar can carry technical vocabulary from MSA. Use a local request form, check the interlocutor's meaning and state your proposed next step. Formal documents generally remain in MSA.

**ممكن توضّح هالنقطة؟**

Could you clarify this point? A common spoken request; local pronunciation differs.

**بدي معلومات أكتر.**

I want/need more information. بدي is common in several central-Levantine models.

<details><summary>Write and record a short clarification dialogue.</summary>

Ask, paraphrase, confirm and thank. Keep your chosen community's negation and future patterns consistent.

</details>

<details><summary>Does learning this companion cover every Levantine variety?</summary>

No. Extend listening systematically to the actual community you need.

</details>

### Arabic - Gulf

Gulf Arabic includes several communities and overlaps with other Arabian varieties. Saudi Arabic is not one homogeneous dialect, and Gulf, Hijazi and Najdi are not interchangeable labels. These notes introduce common Gulf teaching patterns; choose a particular country/community for advanced production. The historical Saudi course in Resources is a separate labelled resource.

![[Resources/Audio/ar/Gulf examples.mp3]]

#### Variation, sounds and everyday words

Realisation of ق can be /g/ in many Gulf speech contexts, with other realisations and formal pronunciations also present. Some communities have affricated realisations of certain consonants in specific contexts. Do not imitate these features from spelling alone. Vocabulary such as الحين for now is common, but not unique or universal across all Arabian speech.

**شلونك؟**

How are you? Common in some Gulf communities; alternatives occur.

**الحين**

now A common Gulf everyday expression.

<details><summary>Is one Gulf greeting universal in every country?</summary>

No. Choose a local model and learn alternative forms for comprehension.

</details>

<details><summary>What belongs in a pronunciation note?</summary>

Community, word, recorded model and the exact feature being practised.

</details>

#### Verb systems and negation

Many Gulf systems do not use the Levantine b-prefix as a universal present-tense marker. ما commonly negates verbal predicates, while مب or مو can occur in nominal negation depending on locality. Future markers and ongoing-action constructions differ across communities. MSA-derived words can coexist with dialect morphology.

**ما فهمت.**

I did not understand. Common past verbal negative; pronunciation varies.

**هذا مب واضح.**

This is not clear. A nominal negative found in some Gulf systems, not every community.

<details><summary>Why should you not import Egyptian ما ... ش into every Gulf sentence?</summary>

The negative systems differ. Learn the chosen local construction.

</details>

<details><summary>How should future reference be studied?</summary>

Use an attested local pattern and record its distribution rather than inventing a uniform Gulf rule.

</details>

#### Professional interaction and register

A clear spoken request can be less formal than its MSA counterpart while remaining courteous. Relationships, workplace culture and community norms determine address and directness. Learn to clarify documents in dialect, but retain MSA competence for the documents themselves.

**ممكن توضّح هالنقطة؟**

Could you clarify this point? A widely recognisable spoken pattern with local variation.

**أحتاج معلومات أكثر.**

I need more information. A usable request with broadly formal-compatible vocabulary.

<details><summary>Role-play clarification of an appointment.</summary>

Ask for the time, repeat it and confirm location. Match your model community's pronunciation.

</details>

<details><summary>What is the distinction between the companion and the historical Saudi course?</summary>

The companion maps selected Gulf variation; the source course represents its own explicitly labelled historical variety.

</details>

## Word bank and recordings

1,000 study entries, based on dictionary selections and authored teaching glosses. Learn a word in a phrase; consult the linked entry for additional senses.

<details><summary>Words 1–50</summary>

![[Resources/Audio/ar/Words 0001-0050.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [في](https://en.wiktionary.org/wiki/%D9%81%D9%8A#Arabic) | in, within | fī · prep |
| [من](https://en.wiktionary.org/wiki/%D9%85%D9%86#Arabic) | from; of; who (depending on vowels and context) | min · prep |
| [على](https://en.wiktionary.org/wiki/%D8%B9%D9%84%D9%89#Arabic) | on, over | ʕalā · prep |
| [أن](https://en.wiktionary.org/wiki/%D8%A3%D9%86#Arabic) | to, that; introduces a subjunctive verb (often corresponding to the English infinitive) | ʔan · conj |
| [لا](https://en.wiktionary.org/wiki/%D9%84%D8%A7#Arabic) | no | lā · particle |
| [إلى](https://en.wiktionary.org/wiki/%D8%A5%D9%84%D9%89#Arabic) | to, towards | ʔilā · prep |
| [و](https://en.wiktionary.org/wiki/%D9%88#Arabic) | and | wa · conj |
| [ما](https://en.wiktionary.org/wiki/%D9%85%D8%A7#Arabic) | what; a negation word in some constructions | mā · pron |
| [عن](https://en.wiktionary.org/wiki/%D8%B9%D9%86#Arabic) | off, away from | ʕan · prep |
| [هذا](https://en.wiktionary.org/wiki/%D9%87%D8%B0%D8%A7#Arabic) | this | hāḏā · pron |
| [مع](https://en.wiktionary.org/wiki/%D9%85%D8%B9#Arabic) | with, together with, accompanied by, in the company of | maʕa · prep |
| [كل](https://en.wiktionary.org/wiki/%D9%83%D9%84#Arabic) | each one, everyone | kull · noun |
| [أو](https://en.wiktionary.org/wiki/%D8%A3%D9%88#Arabic) | indicates an inclusive disjunction | ʔaw · conj |
| [هو](https://en.wiktionary.org/wiki/%D9%87%D9%88#Arabic) | he (subject pronoun) | huwa · pron |
| [كان](https://en.wiktionary.org/wiki/%D9%83%D8%A7%D9%86#Arabic) | to be | kāna · verb |
| [ذلك](https://en.wiktionary.org/wiki/%D8%B0%D9%84%D9%83#Arabic) | that (demonstrative pronoun) | ḏālika · pron |
| [بعد](https://en.wiktionary.org/wiki/%D8%A8%D8%B9%D8%AF#Arabic) | to be distant, afar, to become distant, go away (مِنْ (min) or عَنْ (ʕan) from) | baʕuda · verb |
| [لم](https://en.wiktionary.org/wiki/%D9%84%D9%85#Arabic) | to gather, to collect, to bring together | lamma · verb |
| [بين](https://en.wiktionary.org/wiki/%D8%A8%D9%8A%D9%86#Arabic) | between (“in the position or interval that separates two things”) | bayna · prep |
| [قبل](https://en.wiktionary.org/wiki/%D9%82%D8%A8%D9%84#Arabic) | to accept | qabila · verb |
| [قد](https://en.wiktionary.org/wiki/%D9%82%D8%AF#Arabic) | to cut into strips | qadda · verb |
| [هي](https://en.wiktionary.org/wiki/%D9%87%D9%8A#Arabic) | she (subject pronoun). | hiya · pron |
| [إن](https://en.wiktionary.org/wiki/%D8%A5%D9%86#Arabic) | if (possible, not contrary to fact) | ʔin · conj |
| [كما](https://en.wiktionary.org/wiki/%D9%83%D9%85%D8%A7#Arabic) | like, as | kamā · conj |
| [خلال](https://en.wiktionary.org/wiki/%D8%AE%D9%84%D8%A7%D9%84#Arabic) | during, in the course of | ḵilāla · prep |
| [غير](https://en.wiktionary.org/wiki/%D8%BA%D9%8A%D8%B1#Arabic) | other than, different from, unlike | ḡayr · noun |
| [تم](https://en.wiktionary.org/wiki/%D8%AA%D9%85#Arabic) | to be fulfilled, to be completed | tamma · verb |
| [مثل](https://en.wiktionary.org/wiki/%D9%85%D8%AB%D9%84#Arabic) | to attribute, | maṯala · verb |
| [محمد](https://en.wiktionary.org/wiki/%D9%85%D8%AD%D9%85%D8%AF#Arabic) | commendable, laudable, praised, praiseworthy | muḥammad · adj |
| [هناك](https://en.wiktionary.org/wiki/%D9%87%D9%86%D8%A7%D9%83#Arabic) | there | hunāka · adv |
| [يوم](https://en.wiktionary.org/wiki/%D9%8A%D9%88%D9%85#Arabic) | day, period from sunrise to sunset | yawm · noun |
| [ولا](https://en.wiktionary.org/wiki/%D9%88%D9%84%D8%A7#Arabic) | For non-idiomatic uses, see وَ (wa) and لَا (lā). | wa-lā · conj |
| [ثم](https://en.wiktionary.org/wiki/%D8%AB%D9%85#Arabic) | then, afterward, subsequently; used to indicate order of time, being later occurring, or even in lesser degree of impressiveness | ṯumma · conj |
| [بن](https://en.wiktionary.org/wiki/%D8%A8%D9%86#Arabic) | coffee beans, coffee | bunn · noun |
| [شيء](https://en.wiktionary.org/wiki/%D8%B4%D9%8A%D8%A1#Arabic) | thing | šayʔ · noun |
| [قال](https://en.wiktionary.org/wiki/%D9%82%D8%A7%D9%84#Arabic) | to say | qāla · verb |
| [منذ](https://en.wiktionary.org/wiki/%D9%85%D9%86%D8%B0#Arabic) | denotes the time at which an occurrence started | munḏu · prep |
| [إلا](https://en.wiktionary.org/wiki/%D8%A5%D9%84%D8%A7#Arabic) | except (for), save (for), but (for), barring; other than, besides, apart from | ʔillā · conj |
| [فقط](https://en.wiktionary.org/wiki/%D9%81%D9%82%D8%B7#Arabic) | only, no more | faqaṭ · adv |
| [الآن](https://en.wiktionary.org/wiki/%D8%A7%D9%84%D8%A2%D9%86#Arabic) | now | al-ʔāna · adv |
| [عدد](https://en.wiktionary.org/wiki/%D8%B9%D8%AF%D8%AF#Arabic) | number | ʕadad · noun |
| [هنا](https://en.wiktionary.org/wiki/%D9%87%D9%86%D8%A7#Arabic) | here, in this place | hunā · adv |
| [ليس](https://en.wiktionary.org/wiki/%D9%84%D9%8A%D8%B3#Arabic) | not to be | laysa · verb |
| [هل](https://en.wiktionary.org/wiki/%D9%87%D9%84#Arabic) | introduces a positive yes-no question | hal · particle |
| [عند](https://en.wiktionary.org/wiki/%D8%B9%D9%86%D8%AF#Arabic) | near, with, at the house of | ʕinda · prep |
| [أنا](https://en.wiktionary.org/wiki/%D8%A3%D9%86%D8%A7#Arabic) | I (first person singular subject pronoun) | ʔana · pron |
| [عبد](https://en.wiktionary.org/wiki/%D8%B9%D8%A8%D8%AF#Arabic) | a person who is under the ownership of another, a slave, a bondservant | ʕabd · noun |
| [تحت](https://en.wiktionary.org/wiki/%D8%AA%D8%AD%D8%AA#Arabic) | below | taḥtu · adv |
| [حول](https://en.wiktionary.org/wiki/%D8%AD%D9%88%D9%84#Arabic) | power, might | ḥawl · noun |
| [ب](https://en.wiktionary.org/wiki/%D8%A8#Arabic) | denotes an instrument or tool, with, by (a means) | bi- · prep |

</details>

<details><summary>Words 51–100</summary>

![[Resources/Audio/ar/Words 0051-0100.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [آخر](https://en.wiktionary.org/wiki/%D8%A2%D8%AE%D8%B1#Arabic) | last, ultimate, utmost, extreme | ʔāḵir · adj |
| [جدا](https://en.wiktionary.org/wiki/%D8%AC%D8%AF%D8%A7#Arabic) | very | jiddan · adv |
| [واحد](https://en.wiktionary.org/wiki/%D9%88%D8%A7%D8%AD%D8%AF#Arabic) | one | wāḥid · num |
| [لن](https://en.wiktionary.org/wiki/%D9%84%D9%86#Arabic) | not (future) | lan · adv |
| [مدينة](https://en.wiktionary.org/wiki/%D9%85%D8%AF%D9%8A%D9%86%D8%A9#Arabic) | town, city | madīna · noun |
| [مصر](https://en.wiktionary.org/wiki/%D9%85%D8%B5%D8%B1#Arabic) | to make Egyptian, to Egyptianize | maṣṣara · verb |
| [شخص](https://en.wiktionary.org/wiki/%D8%B4%D8%AE%D8%B5#Arabic) | to rise, to tower up | šaḵaṣa · verb |
| [مما](https://en.wiktionary.org/wiki/%D9%85%D9%85%D8%A7#Arabic) | from what | mimmā · pron |
| [عمل](https://en.wiktionary.org/wiki/%D8%B9%D9%85%D9%84#Arabic) | to work, to perform | ʕamila · verb |
| [بل](https://en.wiktionary.org/wiki/%D8%A8%D9%84#Arabic) | but; rather | bal · conj |
| [هم](https://en.wiktionary.org/wiki/%D9%87%D9%85#Arabic) | they (masculine plural subject pronoun) | hum · pron |
| [ل](https://en.wiktionary.org/wiki/%D9%84#Arabic) | to, for, belonging to | li- · prep |
| [أكبر](https://en.wiktionary.org/wiki/%D8%A3%D9%83%D8%A8%D8%B1#Arabic) | greater; greatest | ʔakbar · adj |
| [رئيس](https://en.wiktionary.org/wiki/%D8%B1%D8%A6%D9%8A%D8%B3#Arabic) | boss, chief, leader | raʔīs · noun |
| [لهم](https://en.wiktionary.org/wiki/%D9%84%D9%87%D9%85#Arabic) | greedy, covetous, voracious, gluttonous | lahim · adj |
| [موقع](https://en.wiktionary.org/wiki/%D9%85%D9%88%D9%82%D8%B9#Arabic) | site, position, emplacement, place, spot, scene, locus, locale, locality, location, venue | mawqiʕ · noun |
| [سنة](https://en.wiktionary.org/wiki/%D8%B3%D9%86%D8%A9#Arabic) | year | sana · noun |
| [لما](https://en.wiktionary.org/wiki/%D9%84%D9%85%D8%A7#Arabic) | not yet, but not, yet not; (governs a jussive verb) | lammā · particle |
| [مجموعة](https://en.wiktionary.org/wiki/%D9%85%D8%AC%D9%85%D9%88%D8%B9%D8%A9#Arabic) | collection, compilation, anthology | majmūʕa · noun |
| [ضد](https://en.wiktionary.org/wiki/%D8%B6%D8%AF#Arabic) | opposite, contrast | ḍidd · noun |
| [كبير](https://en.wiktionary.org/wiki/%D9%83%D8%A8%D9%8A%D8%B1#Arabic) | big, large | kabīr · adj |
| [طريق](https://en.wiktionary.org/wiki/%D8%B7%D8%B1%D9%8A%D9%82#Arabic) | way, road, path, track, street | ṭarīq · noun |
| [وقت](https://en.wiktionary.org/wiki/%D9%88%D9%82%D8%AA#Arabic) | time (as an abstract concept) | waqt · noun |
| [أما](https://en.wiktionary.org/wiki/%D8%A3%D9%85%D8%A7#Arabic) | as for; followed by a noun or pronoun, itself followed by the particle فَـ (fa-) | ʔammā · conj |
| [نحن](https://en.wiktionary.org/wiki/%D9%86%D8%AD%D9%86#Arabic) | we (subject pronoun) | naḥnu · pron |
| [يعني](https://en.wiktionary.org/wiki/%D9%8A%D8%B9%D9%86%D9%8A#Arabic) | in other words, actually, namely, to wit, kind of, somewhat, id est, that is, meaning, you know | yaʕnī · intj |
| [بدون](https://en.wiktionary.org/wiki/%D8%A8%D8%AF%D9%88%D9%86#Arabic) | without | bidūni · prep |
| [نفس](https://en.wiktionary.org/wiki/%D9%86%D9%81%D8%B3#Arabic) | to be priceless, to be precious, to be valuable | nafusa · verb |
| [أم](https://en.wiktionary.org/wiki/%D8%A3%D9%85#Arabic) | mother | ʔumm · noun |
| [جديد](https://en.wiktionary.org/wiki/%D8%AC%D8%AF%D9%8A%D8%AF#Arabic) | new | jadīd · adj |
| [الله أكبر](https://en.wiktionary.org/wiki/%D8%A7%D9%84%D9%84%D9%87%20%D8%A3%D9%83%D8%A8%D8%B1#Arabic) | God is greater | allāhu ʔakbar · phrase |
| [مجلس](https://en.wiktionary.org/wiki/%D9%85%D8%AC%D9%84%D8%B3#Arabic) | seat | majlis · noun |
| [أحمد](https://en.wiktionary.org/wiki/%D8%A3%D8%AD%D9%85%D8%AF#Arabic) | to show oneself praiseworthy | ʔaḥmada · verb |
| [وجود](https://en.wiktionary.org/wiki/%D9%88%D8%AC%D9%88%D8%AF#Arabic) | existence | wujūd · noun |
| [شركة](https://en.wiktionary.org/wiki/%D8%B4%D8%B1%D9%83%D8%A9#Arabic) | company (a business) | šarika · noun |
| [قام](https://en.wiktionary.org/wiki/%D9%82%D8%A7%D9%85#Arabic) | to stand up (to rise from lying or sitting position); to get up | qāma · verb |
| [ابن](https://en.wiktionary.org/wiki/%D8%A7%D8%A8%D9%86#Arabic) | son | ibn · noun |
| [بينما](https://en.wiktionary.org/wiki/%D8%A8%D9%8A%D9%86%D9%85%D8%A7#Arabic) | while | baynamā · conj |
| [دولار](https://en.wiktionary.org/wiki/%D8%AF%D9%88%D9%84%D8%A7%D8%B1#Arabic) | dollar | dōlār · noun |
| [ذات](https://en.wiktionary.org/wiki/%D8%B0%D8%A7%D8%AA#Arabic) | spontaneousness | ḏāt · noun |
| [منطقة](https://en.wiktionary.org/wiki/%D9%85%D9%86%D8%B7%D9%82%D8%A9#Arabic) | zone | minṭaqa · noun |
| [داخل](https://en.wiktionary.org/wiki/%D8%AF%D8%A7%D8%AE%D9%84#Arabic) | to befall, to seize, to come over | dāḵala · verb |
| [مرة أخرى](https://en.wiktionary.org/wiki/%D9%85%D8%B1%D8%A9%20%D8%A3%D8%AE%D8%B1%D9%89#Arabic) | again | marratan ʔuḵrā · adv |
| [ثلاثة](https://en.wiktionary.org/wiki/%D8%AB%D9%84%D8%A7%D8%AB%D8%A9#Arabic) | three | ṯalāṯa · num |
| [صلى](https://en.wiktionary.org/wiki/%D8%B5%D9%84%D9%89#Arabic) | to pray | ṣallā · verb |
| [أمام](https://en.wiktionary.org/wiki/%D8%A3%D9%85%D8%A7%D9%85#Arabic) | before, in front of, in the presence of | ʔamāma · prep |
| [نظام](https://en.wiktionary.org/wiki/%D9%86%D8%B8%D8%A7%D9%85#Arabic) | system | niẓām · noun |
| [فوق](https://en.wiktionary.org/wiki/%D9%81%D9%88%D9%82#Arabic) | above | fawqu · adv |
| [نهاية](https://en.wiktionary.org/wiki/%D9%86%D9%87%D8%A7%D9%8A%D8%A9#Arabic) | end (“extreme part of something”) | nihāya · noun |
| [أحد عشر](https://en.wiktionary.org/wiki/%D8%A3%D8%AD%D8%AF%20%D8%B9%D8%B4%D8%B1#Arabic) | eleven | ʔaḥada ʕašara · num |

</details>

<details><summary>Words 101–150</summary>

![[Resources/Audio/ar/Words 0101-0150.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [عمر](https://en.wiktionary.org/wiki/%D8%B9%D9%85%D8%B1#Arabic) | to live long, to be long-lived | ʕamara · verb |
| [رجل](https://en.wiktionary.org/wiki/%D8%B1%D8%AC%D9%84#Arabic) | to go on foot, to walk | rajila · verb |
| [فيلم](https://en.wiktionary.org/wiki/%D9%81%D9%8A%D9%84%D9%85#Arabic) | film, movie | fīlm · noun |
| [ولد](https://en.wiktionary.org/wiki/%D9%88%D9%84%D8%AF#Arabic) | to bear, to beget | walada · verb |
| [أمر](https://en.wiktionary.org/wiki/%D8%A3%D9%85%D8%B1#Arabic) | to order, to command, to bid, to instruct | ʔamara · verb |
| [حال](https://en.wiktionary.org/wiki/%D8%AD%D8%A7%D9%84#Arabic) | to change, to be transformed | ḥāla · verb |
| [خارج](https://en.wiktionary.org/wiki/%D8%AE%D8%A7%D8%B1%D8%AC#Arabic) | outside, exterior | ḵārij · noun |
| [كتب](https://en.wiktionary.org/wiki/%D9%83%D8%AA%D8%A8#Arabic) | to draw (figures) | kataba · verb |
| [بدأ](https://en.wiktionary.org/wiki/%D8%A8%D8%AF%D8%A3#Arabic) | to begin | badaʔa · verb |
| [شهر](https://en.wiktionary.org/wiki/%D8%B4%D9%87%D8%B1#Arabic) | month (unit of time) | šahr · noun |
| [صورة](https://en.wiktionary.org/wiki/%D8%B5%D9%88%D8%B1%D8%A9#Arabic) | form, shape, figure | ṣūra · noun |
| [كم](https://en.wiktionary.org/wiki/%D9%83%D9%85#Arabic) | how many?, how much? (used with accusative noun in singular; if preceded by genitive particle, can be optionally used with genitive noun in singular (which, in turn, can be optionally accompanied by مِنْ (min))) | kam · adv |
| [ماذا](https://en.wiktionary.org/wiki/%D9%85%D8%A7%D8%B0%D8%A7#Arabic) | what | māḏā · pron |
| [حد](https://en.wiktionary.org/wiki/%D8%AD%D8%AF#Arabic) | to prevent, to restrain, to check, to hinder | ḥadda · verb |
| [حق](https://en.wiktionary.org/wiki/%D8%AD%D9%82#Arabic) | to be true, to be confirmed | ḥaqqa · verb |
| [قتل](https://en.wiktionary.org/wiki/%D9%82%D8%AA%D9%84#Arabic) | to kill, to slay, to murder | qatala · verb |
| [حسن](https://en.wiktionary.org/wiki/%D8%AD%D8%B3%D9%86#Arabic) | to be or become good, to better, to improve | ḥasuna · verb |
| [دولة](https://en.wiktionary.org/wiki/%D8%AF%D9%88%D9%84%D8%A9#Arabic) | state (sovereign polity) | dawla · noun |
| [مارس](https://en.wiktionary.org/wiki/%D9%85%D8%A7%D8%B1%D8%B3#Arabic) | to practice (to engage in) | mārasa · verb |
| [اسم](https://en.wiktionary.org/wiki/%D8%A7%D8%B3%D9%85#Arabic) | name | ism · noun |
| [تاريخ](https://en.wiktionary.org/wiki/%D8%AA%D8%A7%D8%B1%D9%8A%D8%AE#Arabic) | date, time | tārīḵ · noun |
| [ذكر](https://en.wiktionary.org/wiki/%D8%B0%D9%83%D8%B1#Arabic) | to mention | ḏakara · verb |
| [ربما](https://en.wiktionary.org/wiki/%D8%B1%D8%A8%D9%85%D8%A7#Arabic) | perhaps, maybe | rubbamā · adv |
| [رقم](https://en.wiktionary.org/wiki/%D8%B1%D9%82%D9%85#Arabic) | numeral, number, figure | raqm · noun |
| [ساعة](https://en.wiktionary.org/wiki/%D8%B3%D8%A7%D8%B9%D8%A9#Arabic) | hour (unit of time) | sāʕa · noun |
| [وضع](https://en.wiktionary.org/wiki/%D9%88%D8%B6%D8%B9#Arabic) | to put; to lay; to place; to set; to position; to install; to implant | waḍaʕa · verb |
| [حسب](https://en.wiktionary.org/wiki/%D8%AD%D8%B3%D8%A8#Arabic) | to calculate, to compute | ḥasaba · verb |
| [فريق](https://en.wiktionary.org/wiki/%D9%81%D8%B1%D9%8A%D9%82#Arabic) | team | farīq · noun |
| [كتاب](https://en.wiktionary.org/wiki/%D9%83%D8%AA%D8%A7%D8%A8#Arabic) | book | kitāb · noun |
| [نوع](https://en.wiktionary.org/wiki/%D9%86%D9%88%D8%B9#Arabic) | to diversify | nawwaʕa · verb |
| [وزير](https://en.wiktionary.org/wiki/%D9%88%D8%B2%D9%8A%D8%B1#Arabic) | minister, cabinet minister | wazīr · noun |
| [إدارة](https://en.wiktionary.org/wiki/%D8%A5%D8%AF%D8%A7%D8%B1%D8%A9#Arabic) | turning, turning around, turning over | ʔidāra · noun |
| [بلا](https://en.wiktionary.org/wiki/%D8%A8%D9%84%D8%A7#Arabic) | to test, to try | balā · verb |
| [جنوب](https://en.wiktionary.org/wiki/%D8%AC%D9%86%D9%88%D8%A8#Arabic) | south | janūb · noun |
| [علم](https://en.wiktionary.org/wiki/%D8%B9%D9%84%D9%85#Arabic) | to know, to have knowledge, to be cognizant, to be aware | ʕalima · verb |
| [فعل](https://en.wiktionary.org/wiki/%D9%81%D8%B9%D9%84#Arabic) | to do | faʕala · verb |
| [كلمة](https://en.wiktionary.org/wiki/%D9%83%D9%84%D9%85%D8%A9#Arabic) | speech, utterance, statement | kalima · noun |
| [بداية](https://en.wiktionary.org/wiki/%D8%A8%D8%AF%D8%A7%D9%8A%D8%A9#Arabic) | beginning, start | bidāya · noun |
| [حياة](https://en.wiktionary.org/wiki/%D8%AD%D9%8A%D8%A7%D8%A9#Arabic) | life | ḥayāh · noun |
| [صباح](https://en.wiktionary.org/wiki/%D8%B5%D8%A8%D8%A7%D8%AD#Arabic) | the time from sunrise to noon, morning | ṣabāḥ · noun |
| [طريقة](https://en.wiktionary.org/wiki/%D8%B7%D8%B1%D9%8A%D9%82%D8%A9#Arabic) | manner, mode, means | ṭarīqa · noun |
| [جامعة](https://en.wiktionary.org/wiki/%D8%AC%D8%A7%D9%85%D8%B9%D8%A9#Arabic) | university, academy | jāmiʕa · noun |
| [دور](https://en.wiktionary.org/wiki/%D8%AF%D9%88%D8%B1#Arabic) | to turn in a circle, to spin, to whirl, to revolve, to rotate | dawwara · verb |
| [حركة](https://en.wiktionary.org/wiki/%D8%AD%D8%B1%D9%83%D8%A9#Arabic) | instance noun of حَرُكَ (ḥaruka): an instance of movement | ḥaraka · noun |
| [حزب](https://en.wiktionary.org/wiki/%D8%AD%D8%B2%D8%A8#Arabic) | political party | ḥizb · noun |
| [عالم](https://en.wiktionary.org/wiki/%D8%B9%D8%A7%D9%84%D9%85#Arabic) | world | ʕālam · noun |
| [تعلم](https://en.wiktionary.org/wiki/%D8%AA%D8%B9%D9%84%D9%85#Arabic) | to learn (something) | taʕallama · verb |
| [دول](https://en.wiktionary.org/wiki/%D8%AF%D9%88%D9%84#Arabic) | to internationalize | dawwala · verb |
| [قائمة](https://en.wiktionary.org/wiki/%D9%82%D8%A7%D8%A6%D9%85%D8%A9#Arabic) | list (“enumeration or compilation of a set of possible items”) | qāʔima · noun |
| [وهم](https://en.wiktionary.org/wiki/%D9%88%D9%87%D9%85#Arabic) | to conjecture, to guess, to presume, to ween, to surmise, to fancy, to assume on ill grounds | wahama · verb |

</details>

<details><summary>Words 151–200</summary>

![[Resources/Audio/ar/Words 0151-0200.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [رسول](https://en.wiktionary.org/wiki/%D8%B1%D8%B3%D9%88%D9%84#Arabic) | messenger; emissary; envoy; delegate | rasūl · noun |
| [كثير](https://en.wiktionary.org/wiki/%D9%83%D8%AB%D9%8A%D8%B1#Arabic) | many, much, numerous | kaṯīr · adj |
| [مشروع](https://en.wiktionary.org/wiki/%D9%85%D8%B4%D8%B1%D9%88%D8%B9#Arabic) | kosher | mašrūʕ · adj |
| [جزء](https://en.wiktionary.org/wiki/%D8%AC%D8%B2%D8%A1#Arabic) | component, constituent | juzʔ · noun |
| [مختلف](https://en.wiktionary.org/wiki/%D9%85%D8%AE%D8%AA%D9%84%D9%81#Arabic) | different | muḵtalif · adj |
| [سبب](https://en.wiktionary.org/wiki/%D8%B3%D8%A8%D8%A8#Arabic) | to cause, to effect, to trigger, to generate | sabbaba · verb |
| [أبدا](https://en.wiktionary.org/wiki/%D8%A3%D8%A8%D8%AF%D8%A7#Arabic) | forever, always | ʔabadan · adv |
| [ألا](https://en.wiktionary.org/wiki/%D8%A3%D9%84%D8%A7#Arabic) | negate a verb if the following verb is in subjunctive | ʔallā · conj |
| [فرصة](https://en.wiktionary.org/wiki/%D9%81%D8%B1%D8%B5%D8%A9#Arabic) | chance, occasion, opportunity | furṣa · noun |
| [قانون](https://en.wiktionary.org/wiki/%D9%82%D8%A7%D9%86%D9%88%D9%86#Arabic) | canon | qānūn · noun |
| [بيت](https://en.wiktionary.org/wiki/%D8%A8%D9%8A%D8%AA#Arabic) | house, building | bayt · noun |
| [ثلاثة عشر](https://en.wiktionary.org/wiki/%D8%AB%D9%84%D8%A7%D8%AB%D8%A9%20%D8%B9%D8%B4%D8%B1#Arabic) | thirteen | ṯalāṯata ʕašara · num |
| [جون](https://en.wiktionary.org/wiki/%D8%AC%D9%88%D9%86#Arabic) | bay, inlet, gulf, lagoon | jūn · noun |
| [حوالي](https://en.wiktionary.org/wiki/%D8%AD%D9%88%D8%A7%D9%84%D9%8A#Arabic) | around | ḥawālay · prep |
| [عيد](https://en.wiktionary.org/wiki/%D8%B9%D9%8A%D8%AF#Arabic) | feast; holiday; festival | ʕīd · noun |
| [كامل](https://en.wiktionary.org/wiki/%D9%83%D8%A7%D9%85%D9%84#Arabic) | complete, full | kāmil · adj |
| [مساء](https://en.wiktionary.org/wiki/%D9%85%D8%B3%D8%A7%D8%A1#Arabic) | evening | masāʔ · noun |
| [حكم](https://en.wiktionary.org/wiki/%D8%AD%D9%83%D9%85#Arabic) | to exercise authority, command, bid, over | ḥakama · verb |
| [خاص](https://en.wiktionary.org/wiki/%D8%AE%D8%A7%D8%B5#Arabic) | special | ḵāṣṣ · adj |
| [شكرا](https://en.wiktionary.org/wiki/%D8%B4%D9%83%D8%B1%D8%A7#Arabic) | thanks | šukran · intj |
| [قوة](https://en.wiktionary.org/wiki/%D9%82%D9%88%D8%A9#Arabic) | power, strength, might, force | quwwa · noun |
| [مني](https://en.wiktionary.org/wiki/%D9%85%D9%86%D9%8A#Arabic) | male ejaculate, semen; sperm | maniyy · noun |
| [طلب](https://en.wiktionary.org/wiki/%D8%B7%D9%84%D8%A8#Arabic) | to search, to look | ṭalaba · verb |
| [نعم](https://en.wiktionary.org/wiki/%D9%86%D8%B9%D9%85#Arabic) | to live in comfort, to be pleased | naʕama · verb |
| [جميل](https://en.wiktionary.org/wiki/%D8%AC%D9%85%D9%8A%D9%84#Arabic) | beautiful | jamīl · adj |
| [قرار](https://en.wiktionary.org/wiki/%D9%82%D8%B1%D8%A7%D8%B1#Arabic) | decision | qarār · noun |
| [نسبة](https://en.wiktionary.org/wiki/%D9%86%D8%B3%D8%A8%D8%A9#Arabic) | relationship, affiliation | nisba · noun |
| [دخل](https://en.wiktionary.org/wiki/%D8%AF%D8%AE%D9%84#Arabic) | to enter, go in, come in | daḵala · verb |
| [وجه](https://en.wiktionary.org/wiki/%D9%88%D8%AC%D9%87#Arabic) | to be a man of distinction, to be notable | wajuha · verb |
| [حرب](https://en.wiktionary.org/wiki/%D8%AD%D8%B1%D8%A8#Arabic) | to be enraged, to be furious, to be angry | ḥariba · verb |
| [حساب](https://en.wiktionary.org/wiki/%D8%AD%D8%B3%D8%A7%D8%A8#Arabic) | account | ḥisāb · noun |
| [شمال](https://en.wiktionary.org/wiki/%D8%B4%D9%85%D8%A7%D9%84#Arabic) | left hand | šimāl · noun |
| [نصف](https://en.wiktionary.org/wiki/%D9%86%D8%B5%D9%81#Arabic) | half, a half, semi-, hemi- | niṣf · noun |
| [أربعة](https://en.wiktionary.org/wiki/%D8%A3%D8%B1%D8%A8%D8%B9%D8%A9#Arabic) | four | ʔarbaʕa · num |
| [أعلم](https://en.wiktionary.org/wiki/%D8%A3%D8%B9%D9%84%D9%85#Arabic) | to inform, to notify (construed with a direct object of the person notified and either a second direct object of the thing notified about or through بِ (bi)) | ʔaʕlama · verb |
| [خمسة](https://en.wiktionary.org/wiki/%D8%AE%D9%85%D8%B3%D8%A9#Arabic) | five | ḵamsa · num |
| [عادة](https://en.wiktionary.org/wiki/%D8%B9%D8%A7%D8%AF%D8%A9#Arabic) | custom, habit, manner, wont | ʕāda · noun |
| [عشرة](https://en.wiktionary.org/wiki/%D8%B9%D8%B4%D8%B1%D8%A9#Arabic) | ten | ʕašara · num |
| [قدم](https://en.wiktionary.org/wiki/%D9%82%D8%AF%D9%85#Arabic) | to precede | qadama · verb |
| [حكومة](https://en.wiktionary.org/wiki/%D8%AD%D9%83%D9%88%D9%85%D8%A9#Arabic) | government | ḥukūma · noun |
| [صوت](https://en.wiktionary.org/wiki/%D8%B5%D9%88%D8%AA#Arabic) | a sound (of a thing, an animal, and so on) | ṣawt · noun |
| [قطر](https://en.wiktionary.org/wiki/%D9%82%D8%B7%D8%B1#Arabic) | to drip, to dribble, to trickle | qaṭara · verb |
| [إضافة](https://en.wiktionary.org/wiki/%D8%A5%D8%B6%D8%A7%D9%81%D8%A9#Arabic) | genitive/possessive construction, ʾiḍāfa | ʔiḍāfa · noun |
| [حقيقة](https://en.wiktionary.org/wiki/%D8%AD%D9%82%D9%8A%D9%82%D8%A9#Arabic) | truth, reality | ḥaqīqa · noun |
| [عين](https://en.wiktionary.org/wiki/%D8%B9%D9%8A%D9%86#Arabic) | eye (organ) | ʕayn · noun |
| [الله أعلم](https://en.wiktionary.org/wiki/%D8%A7%D9%84%D9%84%D9%87%20%D8%A3%D8%B9%D9%84%D9%85#Arabic) | God knows | allāhu ʔaʕlam · phrase |
| [امرأة](https://en.wiktionary.org/wiki/%D8%A7%D9%85%D8%B1%D8%A3%D8%A9#Arabic) | woman | imraʔa · noun |
| [جمال](https://en.wiktionary.org/wiki/%D8%AC%D9%85%D8%A7%D9%84#Arabic) | beauty | jamāl · noun |
| [سلسلة](https://en.wiktionary.org/wiki/%D8%B3%D9%84%D8%B3%D9%84%D8%A9#Arabic) | iron chain | silsila · noun |
| [متى](https://en.wiktionary.org/wiki/%D9%85%D8%AA%D9%89#Arabic) | when (at what time?) | matā · adv |

</details>

<details><summary>Words 201–250</summary>

![[Resources/Audio/ar/Words 0201-0250.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [معلومات](https://en.wiktionary.org/wiki/%D9%85%D8%B9%D9%84%D9%88%D9%85%D8%A7%D8%AA#Arabic) | information, data, facts, details | maʕlūmāt · noun |
| [نقل](https://en.wiktionary.org/wiki/%D9%86%D9%82%D9%84#Arabic) | to transport, bring from one place to another | naqala · verb |
| [صاحب](https://en.wiktionary.org/wiki/%D8%B5%D8%A7%D8%AD%D8%A8#Arabic) | associate, companion, comrade, friend | ṣāḥib · noun |
| [لمن](https://en.wiktionary.org/wiki/%D9%84%D9%85%D9%86#Arabic) | whose | liman · det |
| [مهمة](https://en.wiktionary.org/wiki/%D9%85%D9%87%D9%85%D8%A9#Arabic) | job, task, function, duty | mahamma · noun |
| [ديسمبر](https://en.wiktionary.org/wiki/%D8%AF%D9%8A%D8%B3%D9%85%D8%A8%D8%B1#Arabic) | December (the twelfth and last month of the Gregorian calendar, following November and preceding the January of the following year, containing the southern solstice) | dīsimbir · noun |
| [ليلة](https://en.wiktionary.org/wiki/%D9%84%D9%8A%D9%84%D8%A9#Arabic) | a night | layla · noun |
| [مدرسة](https://en.wiktionary.org/wiki/%D9%85%D8%AF%D8%B1%D8%B3%D8%A9#Arabic) | school, academy | madrasa · noun |
| [ملك](https://en.wiktionary.org/wiki/%D9%85%D9%84%D9%83#Arabic) | angel | malak · noun |
| [باب](https://en.wiktionary.org/wiki/%D8%A8%D8%A7%D8%A8#Arabic) | door, gate | bāb · noun |
| [سكان](https://en.wiktionary.org/wiki/%D8%B3%D9%83%D8%A7%D9%86#Arabic) | rudder, helm, steering wheel of a ship | sukkān · noun |
| [سيارة](https://en.wiktionary.org/wiki/%D8%B3%D9%8A%D8%A7%D8%B1%D8%A9#Arabic) | automobile, car, motorcar | sayyāra · noun |
| [صلى الله عليه وسلم](https://en.wiktionary.org/wiki/%D8%B5%D9%84%D9%89%20%D8%A7%D9%84%D9%84%D9%87%20%D8%B9%D9%84%D9%8A%D9%87%20%D9%88%D8%B3%D9%84%D9%85#Arabic) | God shower blessing and well-being upon him and grant him peace | ṣallā llāhu ʕalayhi wasallama · phrase |
| [محمود](https://en.wiktionary.org/wiki/%D9%85%D8%AD%D9%85%D9%88%D8%AF#Arabic) | praised | maḥmūd · adj |
| [يد](https://en.wiktionary.org/wiki/%D9%8A%D8%AF#Arabic) | an appendage of a body (as of an animal) | yad · noun |
| [لعبة](https://en.wiktionary.org/wiki/%D9%84%D8%B9%D8%A8%D8%A9#Arabic) | toy, plaything | luʕba · noun |
| [منزل](https://en.wiktionary.org/wiki/%D9%85%D9%86%D8%B2%D9%84#Arabic) | house, dwelling | manzil · noun |
| [نقطة](https://en.wiktionary.org/wiki/%D9%86%D9%82%D8%B7%D8%A9#Arabic) | dot, point | nuqṭa · noun |
| [أين](https://en.wiktionary.org/wiki/%D8%A3%D9%8A%D9%86#Arabic) | where, at which place, whence | ʔayna · adv |
| [جهاز](https://en.wiktionary.org/wiki/%D8%AC%D9%87%D8%A7%D8%B2#Arabic) | equipment, device, appliances, outfit, gear, rig | jihāz · noun |
| [ريال](https://en.wiktionary.org/wiki/%D8%B1%D9%8A%D8%A7%D9%84#Arabic) | riyal (the official currency of Saudi Arabia and Qatar). | riyāl · noun |
| [فهم](https://en.wiktionary.org/wiki/%D9%81%D9%87%D9%85#Arabic) | to understand | fahima · verb |
| [حاجة](https://en.wiktionary.org/wiki/%D8%AD%D8%A7%D8%AC%D8%A9#Arabic) | need, necessity (act of needing something) | ḥāja · noun |
| [رد](https://en.wiktionary.org/wiki/%D8%B1%D8%AF#Arabic) | to return, to bring back, to put back | radda · verb |
| [ستة](https://en.wiktionary.org/wiki/%D8%B3%D8%AA%D8%A9#Arabic) | six | sitta · num |
| [سجل](https://en.wiktionary.org/wiki/%D8%B3%D8%AC%D9%84#Arabic) | to register, enter, make an entry | sajjala · verb |
| [مش](https://en.wiktionary.org/wiki/%D9%85%D8%B4#Arabic) | to suck the marrow from (a bone) | mašša · verb |
| [وصل](https://en.wiktionary.org/wiki/%D9%88%D8%B5%D9%84#Arabic) | to unite, to join; to combine | waṣala · verb |
| [يوم الجمعة](https://en.wiktionary.org/wiki/%D9%8A%D9%88%D9%85%20%D8%A7%D9%84%D8%AC%D9%85%D8%B9%D8%A9#Arabic) | Friday | yawmu l-jumʕati · noun |
| [دار](https://en.wiktionary.org/wiki/%D8%AF%D8%A7%D8%B1#Arabic) | flowing copiously | dārr · adj |
| [دقيقة](https://en.wiktionary.org/wiki/%D8%AF%D9%82%D9%8A%D9%82%D8%A9#Arabic) | minute (unit of time) | daqīqa · noun |
| [ظهر](https://en.wiktionary.org/wiki/%D8%B8%D9%87%D8%B1#Arabic) | to be outward, to be external, on the surface | ẓahara · verb |
| [عبارة](https://en.wiktionary.org/wiki/%D8%B9%D8%A8%D8%A7%D8%B1%D8%A9#Arabic) | expression | ʕibāra · noun |
| [كم الساعة](https://en.wiktionary.org/wiki/%D9%83%D9%85%20%D8%A7%D9%84%D8%B3%D8%A7%D8%B9%D8%A9#Arabic) | what time is it? | kami s-sāʕatu? · phrase |
| [رأس](https://en.wiktionary.org/wiki/%D8%B1%D8%A3%D8%B3#Arabic) | head | raʔs · noun |
| [طول](https://en.wiktionary.org/wiki/%D8%B7%D9%88%D9%84#Arabic) | length | ṭūl · noun |
| [لله](https://en.wiktionary.org/wiki/%D9%84%D9%84%D9%87#Arabic) | Used other than figuratively or idiomatically: see لِـ (li-), الله (allāh). | li-llāhi · phrase |
| [مدير](https://en.wiktionary.org/wiki/%D9%85%D8%AF%D9%8A%D8%B1#Arabic) | manager, head, chief, director, administrator, headmaster, boss | mudīr · noun |
| [وراء](https://en.wiktionary.org/wiki/%D9%88%D8%B1%D8%A7%D8%A1#Arabic) | behind | warāʔa · prep |
| [جيد](https://en.wiktionary.org/wiki/%D8%AC%D9%8A%D8%AF#Arabic) | of good quality, excellent, approvable | jayyid · adj |
| [علم اللغة](https://en.wiktionary.org/wiki/%D8%B9%D9%84%D9%85%20%D8%A7%D9%84%D9%84%D8%BA%D8%A9#Arabic) | linguistics (the study of langauges) | ʕilm al-luḡa · noun |
| [قول](https://en.wiktionary.org/wiki/%D9%82%D9%88%D9%84#Arabic) | a saying; a declaration; a statement; an assertion | qawl · noun |
| [هدف](https://en.wiktionary.org/wiki/%D9%87%D8%AF%D9%81#Arabic) | to approach, to draw near, to be near | hadafa · verb |
| [أربعة عشر](https://en.wiktionary.org/wiki/%D8%A3%D8%B1%D8%A8%D8%B9%D8%A9%20%D8%B9%D8%B4%D8%B1#Arabic) | fourteen | ʔarbaʕata ʕašara · num |
| [خمسة عشر](https://en.wiktionary.org/wiki/%D8%AE%D9%85%D8%B3%D8%A9%20%D8%B9%D8%B4%D8%B1#Arabic) | fifteen | ḵamsata ʕašara · num |
| [شرق](https://en.wiktionary.org/wiki/%D8%B4%D8%B1%D9%82#Arabic) | east; Orient | šarq · noun |
| [لا يزال](https://en.wiktionary.org/wiki/%D9%84%D8%A7%20%D9%8A%D8%B2%D8%A7%D9%84#Arabic) | still (up to this time) |  · verb |
| [رمضان](https://en.wiktionary.org/wiki/%D8%B1%D9%85%D8%B6%D8%A7%D9%86#Arabic) | Ramadan (the holy ninth month of the Islamic lunar calendar, during which Muslims fast between the break of dawn until sunset; they also refrain from drinking liquids, smoking and having sexual relations) | ramaḍān · noun |
| [طالب](https://en.wiktionary.org/wiki/%D8%B7%D8%A7%D9%84%D8%A8#Arabic) | seeker, pursuer | ṭālib · noun |
| [قرية](https://en.wiktionary.org/wiki/%D9%82%D8%B1%D9%8A%D8%A9#Arabic) | any populated area or the community thereof | qarya · noun |

</details>

<details><summary>Words 251–300</summary>

![[Resources/Audio/ar/Words 0251-0300.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [مصدر](https://en.wiktionary.org/wiki/%D9%85%D8%B5%D8%AF%D8%B1#Arabic) | starting point, point of origin | maṣdar · noun |
| [ولاية](https://en.wiktionary.org/wiki/%D9%88%D9%84%D8%A7%D9%8A%D8%A9#Arabic) | province, governorate | wilāya · noun |
| [رفع](https://en.wiktionary.org/wiki/%D8%B1%D9%81%D8%B9#Arabic) | to lift, to raise aloft, to hoist up, to heave up | rafaʕa · verb |
| [صدر](https://en.wiktionary.org/wiki/%D8%B5%D8%AF%D8%B1#Arabic) | to emerge; to come up; to spring; to issue; to rise | ṣadara · verb |
| [فلم](https://en.wiktionary.org/wiki/%D9%81%D9%84%D9%85#Arabic) | film, motion picture | /film/ · noun |
| [بحسب](https://en.wiktionary.org/wiki/%D8%A8%D8%AD%D8%B3%D8%A8#Arabic) | according to | bi-ḥasabi · prep |
| [معنى](https://en.wiktionary.org/wiki/%D9%85%D8%B9%D9%86%D9%89#Arabic) | meaning, import, sense | maʕnan · noun |
| [أرض](https://en.wiktionary.org/wiki/%D8%A3%D8%B1%D8%B6#Arabic) | earth, land | ʔarḍ · noun |
| [القاعدة](https://en.wiktionary.org/wiki/%D8%A7%D9%84%D9%82%D8%A7%D8%B9%D8%AF%D8%A9#Arabic) | the toilet, a Western-style sitting toilet as opposed to a squatting toilet. | al-qāʕida · noun |
| [بنت](https://en.wiktionary.org/wiki/%D8%A8%D9%86%D8%AA#Arabic) | daughter | bint · noun |
| [غرفة](https://en.wiktionary.org/wiki/%D8%BA%D8%B1%D9%81%D8%A9#Arabic) | room, compartment, cell, chamber | ḡurfa · noun |
| [فتح](https://en.wiktionary.org/wiki/%D9%81%D8%AA%D8%AD#Arabic) | to open (“to make something accessible”) | fataḥa · verb |
| [قطع](https://en.wiktionary.org/wiki/%D9%82%D8%B7%D8%B9#Arabic) | to cut, to break | qaṭaʕa · verb |
| [لغة](https://en.wiktionary.org/wiki/%D9%84%D8%BA%D8%A9#Arabic) | language | luḡa · noun |
| [بس](https://en.wiktionary.org/wiki/%D8%A8%D8%B3#Arabic) | to crush | bassa · verb |
| [خط](https://en.wiktionary.org/wiki/%D8%AE%D8%B7#Arabic) | to draw a line | ḵaṭṭa · verb |
| [قلب](https://en.wiktionary.org/wiki/%D9%82%D9%84%D8%A8#Arabic) | heart (organ) | qalb · noun |
| [خطر](https://en.wiktionary.org/wiki/%D8%AE%D8%B7%D8%B1#Arabic) | danger, risk, hazard, peril, calamity, jeopardy | ḵaṭar · noun |
| [رحلة](https://en.wiktionary.org/wiki/%D8%B1%D8%AD%D9%84%D8%A9#Arabic) | trip, voyage, tour | riḥla · noun |
| [سؤال](https://en.wiktionary.org/wiki/%D8%B3%D8%A4%D8%A7%D9%84#Arabic) | question | suʔāl · noun |
| [طفل](https://en.wiktionary.org/wiki/%D8%B7%D9%81%D9%84#Arabic) | child (a minor) | ṭifl · noun |
| [عربية](https://en.wiktionary.org/wiki/%D8%B9%D8%B1%D8%A8%D9%8A%D8%A9#Arabic) | Arab woman | ʕarabiyya · noun |
| [مسلسل](https://en.wiktionary.org/wiki/%D9%85%D8%B3%D9%84%D8%B3%D9%84#Arabic) | striped | musalsal · adj |
| [أصل](https://en.wiktionary.org/wiki/%D8%A3%D8%B5%D9%84#Arabic) | ground | ʔaṣl · noun |
| [جمع](https://en.wiktionary.org/wiki/%D8%AC%D9%85%D8%B9#Arabic) | to gather, to assemble, to keep together, to collect | jamaʕa · verb |
| [ستة عشر](https://en.wiktionary.org/wiki/%D8%B3%D8%AA%D8%A9%20%D8%B9%D8%B4%D8%B1#Arabic) | sixteen | sittata ʕašara · num |
| [سوق](https://en.wiktionary.org/wiki/%D8%B3%D9%88%D9%82#Arabic) | market | sūq · noun |
| [شارع](https://en.wiktionary.org/wiki/%D8%B4%D8%A7%D8%B1%D8%B9#Arabic) | street | šāriʕ · noun |
| [صباح الخير](https://en.wiktionary.org/wiki/%D8%B5%D8%A8%D8%A7%D8%AD%20%D8%A7%D9%84%D8%AE%D9%8A%D8%B1#Arabic) | good morning | ṣabāḥ al-ḵayr · intj |
| [طويل](https://en.wiktionary.org/wiki/%D8%B7%D9%88%D9%8A%D9%84#Arabic) | long, tall | ṭawīl · adj |
| [والله](https://en.wiktionary.org/wiki/%D9%88%D8%A7%D9%84%D9%84%D9%87#Arabic) | by God! | wal-lāhi · intj |
| [أ](https://en.wiktionary.org/wiki/%D8%A3#Arabic) | introduces a positive yes-no question | ʔa- · particle |
| [تجمع](https://en.wiktionary.org/wiki/%D8%AA%D8%AC%D9%85%D8%B9#Arabic) | to gather up; to pile up, to heap up | tajammaʕa · verb |
| [ثانية](https://en.wiktionary.org/wiki/%D8%AB%D8%A7%D9%86%D9%8A%D8%A9#Arabic) | second (unit of time) | ṯāniya · noun |
| [سياسة](https://en.wiktionary.org/wiki/%D8%B3%D9%8A%D8%A7%D8%B3%D8%A9#Arabic) | administration, management | siyāsa · noun |
| [مات](https://en.wiktionary.org/wiki/%D9%85%D8%A7%D8%AA#Arabic) | to die | māta · verb |
| [مثلا](https://en.wiktionary.org/wiki/%D9%85%D8%AB%D9%84%D8%A7#Arabic) | for example | maṯalan · adv |
| [صغير](https://en.wiktionary.org/wiki/%D8%B5%D8%BA%D9%8A%D8%B1#Arabic) | small | ṣaḡīr · adj |
| [قائد](https://en.wiktionary.org/wiki/%D9%82%D8%A7%D8%A6%D8%AF#Arabic) | leader | qāʔid · noun |
| [كن](https://en.wiktionary.org/wiki/%D9%83%D9%86#Arabic) | to cover, to veil, to conceal, to hide | kanna · verb |
| [مجلة](https://en.wiktionary.org/wiki/%D9%85%D8%AC%D9%84%D8%A9#Arabic) | magazine (periodical), publication | majalla · noun |
| [السلام عليكم](https://en.wiktionary.org/wiki/%D8%A7%D9%84%D8%B3%D9%84%D8%A7%D9%85%20%D8%B9%D9%84%D9%8A%D9%83%D9%85#Arabic) | peace be upon you; good day; hello; hail, salaam alaikum, assalamu alaikum | as-salāmu ʕalaykum · intj |
| [شعر](https://en.wiktionary.org/wiki/%D8%B4%D8%B9%D8%B1#Arabic) | to know, to have knowledge, to be cognizant | šaʕara · verb |
| [عربي](https://en.wiktionary.org/wiki/%D8%B9%D8%B1%D8%A8%D9%8A#Arabic) | Arab | ʕarabiyy · adj |
| [وجد](https://en.wiktionary.org/wiki/%D9%88%D8%AC%D8%AF#Arabic) | to find, to hit upon, to come across | wajada · verb |
| [يوم الأحد](https://en.wiktionary.org/wiki/%D9%8A%D9%88%D9%85%20%D8%A7%D9%84%D8%A3%D8%AD%D8%AF#Arabic) | Sunday | yawm al-ʔaḥad · noun |
| [أمس](https://en.wiktionary.org/wiki/%D8%A3%D9%85%D8%B3#Arabic) | yesterday | ʔamsi · adv |
| [صفحة](https://en.wiktionary.org/wiki/%D8%B5%D9%81%D8%AD%D8%A9#Arabic) | page | ṣafḥa · noun |
| [محطة](https://en.wiktionary.org/wiki/%D9%85%D8%AD%D8%B7%D8%A9#Arabic) | station | maḥaṭṭa · noun |
| [مساء الخير](https://en.wiktionary.org/wiki/%D9%85%D8%B3%D8%A7%D8%A1%20%D8%A7%D9%84%D8%AE%D9%8A%D8%B1#Arabic) | good evening | masāʔ al-ḵayr · intj |

</details>

<details><summary>Words 301–350</summary>

![[Resources/Audio/ar/Words 0301-0350.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [مهم](https://en.wiktionary.org/wiki/%D9%85%D9%87%D9%85#Arabic) | important | muhimm · adj |
| [نور](https://en.wiktionary.org/wiki/%D9%86%D9%88%D8%B1#Arabic) | to flower, to blossom | nawwara · verb |
| [ارتفاع](https://en.wiktionary.org/wiki/%D8%A7%D8%B1%D8%AA%D9%81%D8%A7%D8%B9#Arabic) | being or becoming high in stature or station | irtifāʕ · noun |
| [قاعدة](https://en.wiktionary.org/wiki/%D9%82%D8%A7%D8%B9%D8%AF%D8%A9#Arabic) | foundation, groundwork, fundament, basis | qāʕida · noun |
| [كلية](https://en.wiktionary.org/wiki/%D9%83%D9%84%D9%8A%D8%A9#Arabic) | college, academy, school, secondary school | kulliyya · noun |
| [مسلم](https://en.wiktionary.org/wiki/%D9%85%D8%B3%D9%84%D9%85#Arabic) | Muslim | muslim · noun |
| [وقع](https://en.wiktionary.org/wiki/%D9%88%D9%82%D8%B9#Arabic) | to fall down, to fall | waqaʕa · verb |
| [حلب](https://en.wiktionary.org/wiki/%D8%AD%D9%84%D8%A8#Arabic) | to milk | ḥalaba · verb |
| [دين](https://en.wiktionary.org/wiki/%D8%AF%D9%8A%D9%86#Arabic) | religion, creed, credo, faith, conviction, belief, tenet, rite | dīn · noun |
| [فان](https://en.wiktionary.org/wiki/%D9%81%D8%A7%D9%86#Arabic) | evanescent, transitory, transient, ephemeral | fānin · adj |
| [ترجمة](https://en.wiktionary.org/wiki/%D8%AA%D8%B1%D8%AC%D9%85%D8%A9#Arabic) | translation | tarjama · noun |
| [سن](https://en.wiktionary.org/wiki/%D8%B3%D9%86#Arabic) | to sharpen, to whet, to hone, to grind | sanna · verb |
| [شاهد](https://en.wiktionary.org/wiki/%D8%B4%D8%A7%D9%87%D8%AF#Arabic) | to see (with one’s own eyes), to view, to inspect, to watch, to observe, to witness | šāhada · verb |
| [كرة القدم](https://en.wiktionary.org/wiki/%D9%83%D8%B1%D8%A9%20%D8%A7%D9%84%D9%82%D8%AF%D9%85#Arabic) | football, soccer | kurat al-qadam · noun |
| [أحبك](https://en.wiktionary.org/wiki/%D8%A3%D8%AD%D8%A8%D9%83#Arabic) | I love you (to a male) | ʔuḥibbuka · phrase |
| [زمن](https://en.wiktionary.org/wiki/%D8%B2%D9%85%D9%86#Arabic) | time | zaman · noun |
| [صديق](https://en.wiktionary.org/wiki/%D8%B5%D8%AF%D9%8A%D9%82#Arabic) | friend | ṣadīq · noun |
| [علاج](https://en.wiktionary.org/wiki/%D8%B9%D9%84%D8%A7%D8%AC#Arabic) | remedy, cure | ʕilāj · noun |
| [كلام](https://en.wiktionary.org/wiki/%D9%83%D9%84%D8%A7%D9%85#Arabic) | talking, speaking | kalām · noun |
| [جزيرة](https://en.wiktionary.org/wiki/%D8%AC%D8%B2%D9%8A%D8%B1%D8%A9#Arabic) | island | jazīra · noun |
| [ذهب](https://en.wiktionary.org/wiki/%D8%B0%D9%87%D8%A8#Arabic) | to go, to travel | ḏahaba · verb |
| [فرق](https://en.wiktionary.org/wiki/%D9%81%D8%B1%D9%82#Arabic) | to split, to separate | faraqa · verb |
| [كتابة](https://en.wiktionary.org/wiki/%D9%83%D8%AA%D8%A7%D8%A8%D8%A9#Arabic) | writing | kitāba · noun |
| [مطار](https://en.wiktionary.org/wiki/%D9%85%D8%B7%D8%A7%D8%B1#Arabic) | airport, airfield | maṭār · noun |
| [مستشفى](https://en.wiktionary.org/wiki/%D9%85%D8%B3%D8%AA%D8%B4%D9%81%D9%89#Arabic) | hospital | mustašfan · noun |
| [مفهوم](https://en.wiktionary.org/wiki/%D9%85%D9%81%D9%87%D9%88%D9%85#Arabic) | concept; notion; idea | mafhūm · noun |
| [نساء](https://en.wiktionary.org/wiki/%D9%86%D8%B3%D8%A7%D8%A1#Arabic) | longevity, long life | nasāʔ · noun |
| [هما](https://en.wiktionary.org/wiki/%D9%87%D9%85%D8%A7#Arabic) | they both, the two of them (masculine or feminine dual subject pronoun) | humā · pron |
| [روح](https://en.wiktionary.org/wiki/%D8%B1%D9%88%D8%AD#Arabic) | spirit (all senses), ghost | rūḥ · noun |
| [سبعة](https://en.wiktionary.org/wiki/%D8%B3%D8%A8%D8%B9%D8%A9#Arabic) | seven | sabʕa · num |
| [صلاة](https://en.wiktionary.org/wiki/%D8%B5%D9%84%D8%A7%D8%A9#Arabic) | prayer | ṣalāh · noun |
| [غرب](https://en.wiktionary.org/wiki/%D8%BA%D8%B1%D8%A8#Arabic) | to go away, to depart, to withdraw, to leave | ḡaraba · verb |
| [قوي](https://en.wiktionary.org/wiki/%D9%82%D9%88%D9%8A#Arabic) | to be or become strong, powerful | qawiya · verb |
| [ك](https://en.wiktionary.org/wiki/%D9%83#Arabic) | like, as (followed by a genitive case) | ka- · prep |
| [محل](https://en.wiktionary.org/wiki/%D9%85%D8%AD%D9%84#Arabic) | place, location, spot, station | maḥall · noun |
| [موت](https://en.wiktionary.org/wiki/%D9%85%D9%88%D8%AA#Arabic) | death | mawt · noun |
| [وقف](https://en.wiktionary.org/wiki/%D9%88%D9%82%D9%81#Arabic) | to come to a stop, to come to a standstill | waqafa · verb |
| [يوم الخميس](https://en.wiktionary.org/wiki/%D9%8A%D9%88%D9%85%20%D8%A7%D9%84%D8%AE%D9%85%D9%8A%D8%B3#Arabic) | Thursday | yawm al-ḵamīs · noun |
| [السبت](https://en.wiktionary.org/wiki/%D8%A7%D9%84%D8%B3%D8%A8%D8%AA#Arabic) | Saturday, the cessation or last day of the week | as-sabt · noun |
| [بان](https://en.wiktionary.org/wiki/%D8%A8%D8%A7%D9%86#Arabic) | to separate, to become distinct, to sunder | bāna · verb |
| [بجانب](https://en.wiktionary.org/wiki/%D8%A8%D8%AC%D8%A7%D9%86%D8%A8#Arabic) | along, side by side with | bi-jānibi · prep |
| [بحث](https://en.wiktionary.org/wiki/%D8%A8%D8%AD%D8%AB#Arabic) | to search | baḥaṯa · verb |
| [خبر](https://en.wiktionary.org/wiki/%D8%AE%D8%A8%D8%B1#Arabic) | to try, to test | ḵabara · verb |
| [طيب](https://en.wiktionary.org/wiki/%D8%B7%D9%8A%D8%A8#Arabic) | good, wholesome, nice, fine (for example, beneficial, favorable, advantageous; moral, pure, clean; nutritious, nourishing, healthy; tasty, delicious, pleasant, etc.) | ṭayyib · adj |
| [مبارك](https://en.wiktionary.org/wiki/%D9%85%D8%A8%D8%A7%D8%B1%D9%83#Arabic) | blesser | mubārik · noun |
| [مصري](https://en.wiktionary.org/wiki/%D9%85%D8%B5%D8%B1%D9%8A#Arabic) | Egyptian | miṣriyy · adj |
| [تحول](https://en.wiktionary.org/wiki/%D8%AA%D8%AD%D9%88%D9%84#Arabic) | to shift, to change, to become different | taḥawwala · verb |
| [سلام](https://en.wiktionary.org/wiki/%D8%B3%D9%84%D8%A7%D9%85#Arabic) | peace | salām · noun |
| [شهادة](https://en.wiktionary.org/wiki/%D8%B4%D9%87%D8%A7%D8%AF%D8%A9#Arabic) | testimony, witness | šahāda · noun |
| [عباس](https://en.wiktionary.org/wiki/%D8%B9%D8%A8%D8%A7%D8%B3#Arabic) | grim, glowering, frowning, stern, scowling, surly | ʕabbās · adj |

</details>

<details><summary>Words 351–400</summary>

![[Resources/Audio/ar/Words 0351-0400.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [متر](https://en.wiktionary.org/wiki/%D9%85%D8%AA%D8%B1#Arabic) | metre (SI unit of length) | mitr · noun |
| [معركة](https://en.wiktionary.org/wiki/%D9%85%D8%B9%D8%B1%D9%83%D8%A9#Arabic) | battle | maʕraka · noun |
| [موسى](https://en.wiktionary.org/wiki/%D9%85%D9%88%D8%B3%D9%89#Arabic) | razor, blade | mūsā · noun |
| [ه](https://en.wiktionary.org/wiki/%D9%87#Arabic) | him, his, it, its (bound object pronoun, referring to inanimate nouns of masculine gender) | -hu · pron |
| [أمل](https://en.wiktionary.org/wiki/%D8%A3%D9%85%D9%84#Arabic) | to hope for | ʔamala · verb |
| [بد](https://en.wiktionary.org/wiki/%D8%A8%D8%AF#Arabic) | escape, means of avoiding something | budd · noun |
| [رواية](https://en.wiktionary.org/wiki/%D8%B1%D9%88%D8%A7%D9%8A%D8%A9#Arabic) | novel, story | riwāya · noun |
| [مسجد](https://en.wiktionary.org/wiki/%D9%85%D8%B3%D8%AC%D8%AF#Arabic) | mosque | masjid · noun |
| [نظر](https://en.wiktionary.org/wiki/%D9%86%D8%B8%D8%B1#Arabic) | to look, to gaze, to glance | naẓara · verb |
| [نهر](https://en.wiktionary.org/wiki/%D9%86%D9%87%D8%B1#Arabic) | river | nahr · noun |
| [يوم السبت](https://en.wiktionary.org/wiki/%D9%8A%D9%88%D9%85%20%D8%A7%D9%84%D8%B3%D8%A8%D8%AA#Arabic) | Saturday | yawmu s-sabti · noun |
| [أمير](https://en.wiktionary.org/wiki/%D8%A3%D9%85%D9%8A%D8%B1#Arabic) | prince | ʔamīr · noun |
| [الطب](https://en.wiktionary.org/wiki/%D8%A7%D9%84%D8%B7%D8%A8#Arabic) | medicine (field of study), medical science | aṭ-ṭibb · noun |
| [بلد](https://en.wiktionary.org/wiki/%D8%A8%D9%84%D8%AF#Arabic) | country, land, homeland | balad · noun |
| [جدة](https://en.wiktionary.org/wiki/%D8%AC%D8%AF%D8%A9#Arabic) | grandmother | jadda · noun |
| [صندوق](https://en.wiktionary.org/wiki/%D8%B5%D9%86%D8%AF%D9%88%D9%82#Arabic) | chest, box, trunk, crate | ṣundūq · noun |
| [عامل](https://en.wiktionary.org/wiki/%D8%B9%D8%A7%D9%85%D9%84#Arabic) | to do business with | ʕāmala · verb |
| [غريب](https://en.wiktionary.org/wiki/%D8%BA%D8%B1%D9%8A%D8%A8#Arabic) | strange, peculiar, unusual | ḡarīb · adj |
| [ماء](https://en.wiktionary.org/wiki/%D9%85%D8%A7%D8%A1#Arabic) | water | māʔ · noun |
| [مياه](https://en.wiktionary.org/wiki/%D9%85%D9%8A%D8%A7%D9%87#Arabic) | territorial waters, coastal waters | miyāh · noun |
| [عم](https://en.wiktionary.org/wiki/%D8%B9%D9%85#Arabic) | from what? | ʕamma · particle |
| [ها](https://en.wiktionary.org/wiki/%D9%87%D8%A7#Arabic) | behold, look, lo! | hā · particle |
| [أسبوع](https://en.wiktionary.org/wiki/%D8%A3%D8%B3%D8%A8%D9%88%D8%B9#Arabic) | week (unit of time) | ʔusbūʕ · noun |
| [بلغ](https://en.wiktionary.org/wiki/%D8%A8%D9%84%D8%BA#Arabic) | to reach, to arrive at | balaḡa · verb |
| [ثقافة](https://en.wiktionary.org/wiki/%D8%AB%D9%82%D8%A7%D9%81%D8%A9#Arabic) | sagacity, intelligence, wit, refinement, culture | ṯaqāfa · noun |
| [جمهورية](https://en.wiktionary.org/wiki/%D8%AC%D9%85%D9%87%D9%88%D8%B1%D9%8A%D8%A9#Arabic) | republicanism | jumhūriyya · noun |
| [ظهور](https://en.wiktionary.org/wiki/%D8%B8%D9%87%D9%88%D8%B1#Arabic) | rise, emergence | ẓuhūr · noun |
| [عاصمة](https://en.wiktionary.org/wiki/%D8%B9%D8%A7%D8%B5%D9%85%D8%A9#Arabic) | capital city | ʕāṣima · noun |
| [عيد الميلاد](https://en.wiktionary.org/wiki/%D8%B9%D9%8A%D8%AF%20%D8%A7%D9%84%D9%85%D9%8A%D9%84%D8%A7%D8%AF#Arabic) | Christmas (Christian holiday) | ʕīd al-mīlād · noun |
| [فصل](https://en.wiktionary.org/wiki/%D9%81%D8%B5%D9%84#Arabic) | separation, division, partition | faṣl · noun |
| [مادة](https://en.wiktionary.org/wiki/%D9%85%D8%A7%D8%AF%D8%A9#Arabic) | matter, stuff, material, substance | mādda · noun |
| [آن](https://en.wiktionary.org/wiki/%D8%A2%D9%86#Arabic) | time | ʔān · noun |
| [بلدة](https://en.wiktionary.org/wiki/%D8%A8%D9%84%D8%AF%D8%A9#Arabic) | town, city | balda · noun |
| [رب](https://en.wiktionary.org/wiki/%D8%B1%D8%A8#Arabic) | to be master, to be lord | rabba · verb |
| [سبعة عشر](https://en.wiktionary.org/wiki/%D8%B3%D8%A8%D8%B9%D8%A9%20%D8%B9%D8%B4%D8%B1#Arabic) | seventeen | sabʕata ʕašara · num |
| [كون](https://en.wiktionary.org/wiki/%D9%83%D9%88%D9%86#Arabic) | being, essence | kawn · noun |
| [أغنية](https://en.wiktionary.org/wiki/%D8%A3%D8%BA%D9%86%D9%8A%D8%A9#Arabic) | song, melody, tune | ʔuḡniyya · noun |
| [تمر](https://en.wiktionary.org/wiki/%D8%AA%D9%85%D8%B1#Arabic) | date (fruit) | tamr · noun |
| [جريدة](https://en.wiktionary.org/wiki/%D8%AC%D8%B1%D9%8A%D8%AF%D8%A9#Arabic) | detachment of horsemen | jarīda · noun |
| [حمل](https://en.wiktionary.org/wiki/%D8%AD%D9%85%D9%84#Arabic) | to carry (to transport by lifting), to transport, to convey | ḥamala · verb |
| [سلاح](https://en.wiktionary.org/wiki/%D8%B3%D9%84%D8%A7%D8%AD#Arabic) | weapon, arm | silāḥ · noun |
| [شيخ](https://en.wiktionary.org/wiki/%D8%B4%D9%8A%D8%AE#Arabic) | old man | šayḵ · noun |
| [لعب](https://en.wiktionary.org/wiki/%D9%84%D8%B9%D8%A8#Arabic) | to play | laʕiba · verb |
| [مبنى](https://en.wiktionary.org/wiki/%D9%85%D8%A8%D9%86%D9%89#Arabic) | building | mabnan · noun |
| [يوم الاثنين](https://en.wiktionary.org/wiki/%D9%8A%D9%88%D9%85%20%D8%A7%D9%84%D8%A7%D8%AB%D9%86%D9%8A%D9%86#Arabic) | Monday | yawm al-iṯnayn · noun |
| [تابع](https://en.wiktionary.org/wiki/%D8%AA%D8%A7%D8%A8%D8%B9#Arabic) | to continue, carry on | tābaʕa · verb |
| [خرج](https://en.wiktionary.org/wiki/%D8%AE%D8%B1%D8%AC#Arabic) | to move [with مِنْ (min) ‘from inside’] (somewhere) to outside; to leave; to exit; to get out | ḵaraja · verb |
| [زوجة](https://en.wiktionary.org/wiki/%D8%B2%D9%88%D8%AC%D8%A9#Arabic) | wife | zawja · noun |
| [زي](https://en.wiktionary.org/wiki/%D8%B2%D9%8A#Arabic) | costume, uniform, suit, dress | ziyy · noun |
| [سهل](https://en.wiktionary.org/wiki/%D8%B3%D9%87%D9%84#Arabic) | easy | sahl · adj |

</details>

<details><summary>Words 401–450</summary>

![[Resources/Audio/ar/Words 0401-0450.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [عرب](https://en.wiktionary.org/wiki/%D8%B9%D8%B1%D8%A8#Arabic) | Arabs | ʕarab · noun |
| [عرف](https://en.wiktionary.org/wiki/%D8%B9%D8%B1%D9%81#Arabic) | to be familiar with (a person, a place, a piece of news or information, and so on); to know | ʕarafa · verb |
| [نجم](https://en.wiktionary.org/wiki/%D9%86%D8%AC%D9%85#Arabic) | to appear | najama · verb |
| [اجتماع](https://en.wiktionary.org/wiki/%D8%A7%D8%AC%D8%AA%D9%85%D8%A7%D8%B9#Arabic) | meeting (بِ (bi) with someone), assembly | ijtimāʕ · noun |
| [ثمانية](https://en.wiktionary.org/wiki/%D8%AB%D9%85%D8%A7%D9%86%D9%8A%D8%A9#Arabic) | eight | ṯamāniya · num |
| [جو](https://en.wiktionary.org/wiki/%D8%AC%D9%88#Arabic) | air (the apparently open space above the ground) | jaww · noun |
| [س](https://en.wiktionary.org/wiki/%D8%B3#Arabic) | will (prefix indicating the future tense) | sa- · particle |
| [صعب](https://en.wiktionary.org/wiki/%D8%B5%D8%B9%D8%A8#Arabic) | to be hard, difficult | ṣaʕuba · verb |
| [قادر](https://en.wiktionary.org/wiki/%D9%82%D8%A7%D8%AF%D8%B1#Arabic) | powerful | qādir · adj |
| [من فضلك](https://en.wiktionary.org/wiki/%D9%85%D9%86%20%D9%81%D8%B6%D9%84%D9%83#Arabic) | please (“interjection to make commands polite”) | min faḍlika · adv |
| [جنس](https://en.wiktionary.org/wiki/%D8%AC%D9%86%D8%B3#Arabic) | a kind; a variety; a breed | jins · noun |
| [سرعة](https://en.wiktionary.org/wiki/%D8%B3%D8%B1%D8%B9%D8%A9#Arabic) | speed | surʕa · noun |
| [قطعة](https://en.wiktionary.org/wiki/%D9%82%D8%B7%D8%B9%D8%A9#Arabic) | piece, fragment, chunk | qiṭʕa · noun |
| [مرتين](https://en.wiktionary.org/wiki/%D9%85%D8%B1%D8%AA%D9%8A%D9%86#Arabic) | twice | marratayni · adv |
| [تحسين](https://en.wiktionary.org/wiki/%D8%AA%D8%AD%D8%B3%D9%8A%D9%86#Arabic) | amelioration, betterment, improvement, beautification | taḥsīn · noun |
| [سالم](https://en.wiktionary.org/wiki/%D8%B3%D8%A7%D9%84%D9%85#Arabic) | to make peace with, to treat peaceably, to make up with | sālama · verb |
| [سلطان](https://en.wiktionary.org/wiki/%D8%B3%D9%84%D8%B7%D8%A7%D9%86#Arabic) | power, strength | sulṭān · noun |
| [أمين](https://en.wiktionary.org/wiki/%D8%A3%D9%85%D9%8A%D9%86#Arabic) | reliable, trustworthy, loyal, responsible | ʔamīn · adj |
| [أنتم](https://en.wiktionary.org/wiki/%D8%A3%D9%86%D8%AA%D9%85#Arabic) | you, ye (masculine plural subject pronoun) | ʔantum · pron |
| [شعار](https://en.wiktionary.org/wiki/%D8%B4%D8%B9%D8%A7%D8%B1#Arabic) | password, watchword | šiʕār · noun |
| [ضرب](https://en.wiktionary.org/wiki/%D8%B6%D8%B1%D8%A8#Arabic) | to strike, to beat, to hit | ḍaraba · verb |
| [ضوء](https://en.wiktionary.org/wiki/%D8%B6%D9%88%D8%A1#Arabic) | light | ḍawʔ · noun |
| [عكس](https://en.wiktionary.org/wiki/%D8%B9%D9%83%D8%B3#Arabic) | to overturn | ʕakasa · verb |
| [كاتب](https://en.wiktionary.org/wiki/%D9%83%D8%A7%D8%AA%D8%A8#Arabic) | to keep up a correspondence, to correspond with | kātaba · verb |
| [ما شاء الله](https://en.wiktionary.org/wiki/%D9%85%D8%A7%20%D8%B4%D8%A7%D8%A1%20%D8%A7%D9%84%D9%84%D9%87#Arabic) | Expressing the speaker's gratitude for a blessing or their recognition of divine intervention in its occurrence. God willed it. | mā šāʔa llāhu · phrase |
| [موسم](https://en.wiktionary.org/wiki/%D9%85%D9%88%D8%B3%D9%85#Arabic) | season | mawsim · noun |
| [يوم الثلاثاء](https://en.wiktionary.org/wiki/%D9%8A%D9%88%D9%85%20%D8%A7%D9%84%D8%AB%D9%84%D8%A7%D8%AB%D8%A7%D8%A1#Arabic) | Tuesday | yawmu ṯ-ṯulāṯāʔi · noun |
| [آدم](https://en.wiktionary.org/wiki/%D8%A2%D8%AF%D9%85#Arabic) | human | ʔādam · noun |
| [إن شاء الله](https://en.wiktionary.org/wiki/%D8%A5%D9%86%20%D8%B4%D8%A7%D8%A1%20%D8%A7%D9%84%D9%84%D9%87#Arabic) | God willing; inshallah, if it is God’s will (literally, “if God has willed [it]”) | ʔin šāʔa llāhu · intj |
| [إنسان](https://en.wiktionary.org/wiki/%D8%A5%D9%86%D8%B3%D8%A7%D9%86#Arabic) | human | ʔinsān · noun |
| [اتصال](https://en.wiktionary.org/wiki/%D8%A7%D8%AA%D8%B5%D8%A7%D9%84#Arabic) | union | ittiṣāl · noun |
| [تعليم](https://en.wiktionary.org/wiki/%D8%AA%D8%B9%D9%84%D9%8A%D9%85#Arabic) | teaching, education | taʕlīm · noun |
| [حماس](https://en.wiktionary.org/wiki/%D8%AD%D9%85%D8%A7%D8%B3#Arabic) | excitement; enthusiasm; zeal | ḥamās · noun |
| [خان](https://en.wiktionary.org/wiki/%D8%AE%D8%A7%D9%86#Arabic) | hostel, caravanserai, inn | ḵān · noun |
| [ف](https://en.wiktionary.org/wiki/%D9%81#Arabic) | then, and then | fa- · conj |
| [فرض](https://en.wiktionary.org/wiki/%D9%81%D8%B1%D8%B6#Arabic) | to ordain | faraḍa · verb |
| [فندق](https://en.wiktionary.org/wiki/%D9%81%D9%86%D8%AF%D9%82#Arabic) | inn, hotel | funduq · noun |
| [نار](https://en.wiktionary.org/wiki/%D9%86%D8%A7%D8%B1#Arabic) | fire | nār · noun |
| [ناس](https://en.wiktionary.org/wiki/%D9%86%D8%A7%D8%B3#Arabic) | people, humans | nās · noun |
| [جرى](https://en.wiktionary.org/wiki/%D8%AC%D8%B1%D9%89#Arabic) | to run (to move quickly on two feet) | jarā · verb |
| [حلم](https://en.wiktionary.org/wiki/%D8%AD%D9%84%D9%85#Arabic) | to dream (something) or about [with بِ (bi)] (something) while asleep | ḥalama · verb |
| [رسم](https://en.wiktionary.org/wiki/%D8%B1%D8%B3%D9%85#Arabic) | to draw, to trace, to sketch, to depict, to portray, to outline, to paint | rasama · verb |
| [سريع](https://en.wiktionary.org/wiki/%D8%B3%D8%B1%D9%8A%D8%B9#Arabic) | fast (capable of moving with speed), quick (moving with speed) | sarīʕ · adj |
| [عادي](https://en.wiktionary.org/wiki/%D8%B9%D8%A7%D8%AF%D9%8A#Arabic) | normal, regular, ordinary, usual | ʕādiyy · adj |
| [عيد مبارك](https://en.wiktionary.org/wiki/%D8%B9%D9%8A%D8%AF%20%D9%85%D8%A8%D8%A7%D8%B1%D9%83#Arabic) | eid mubarak | ʕīd mubārak · phrase |
| [لون](https://en.wiktionary.org/wiki/%D9%84%D9%88%D9%86#Arabic) | color | lawn · noun |
| [ثمانية عشر](https://en.wiktionary.org/wiki/%D8%AB%D9%85%D8%A7%D9%86%D9%8A%D8%A9%20%D8%B9%D8%B4%D8%B1#Arabic) | eighteen | ṯamāniyata ʕašara · num |
| [سيف](https://en.wiktionary.org/wiki/%D8%B3%D9%8A%D9%81#Arabic) | sword, sabre, foil, rapier, scimitar | sayf · noun |
| [عسكري](https://en.wiktionary.org/wiki/%D8%B9%D8%B3%D9%83%D8%B1%D9%8A#Arabic) | military | ʕaskariyy · adj |
| [عصر](https://en.wiktionary.org/wiki/%D8%B9%D8%B5%D8%B1#Arabic) | to press, to squeeze, to wring | ʕaṣara · verb |

</details>

<details><summary>Words 451–500</summary>

![[Resources/Audio/ar/Words 0451-0500.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [فارس](https://en.wiktionary.org/wiki/%D9%81%D8%A7%D8%B1%D8%B3#Arabic) | horseman, rider | fāris · noun |
| [معهد](https://en.wiktionary.org/wiki/%D9%85%D8%B9%D9%87%D8%AF#Arabic) | institute | maʕhad · noun |
| [آلة](https://en.wiktionary.org/wiki/%D8%A2%D9%84%D8%A9#Arabic) | instrument, utensil | ʔāla · noun |
| [خليفة](https://en.wiktionary.org/wiki/%D8%AE%D9%84%D9%8A%D9%81%D8%A9#Arabic) | a successor | ḵalīfa · noun |
| [طبيب](https://en.wiktionary.org/wiki/%D8%B7%D8%A8%D9%8A%D8%A8#Arabic) | doctor, physician | ṭabīb · noun |
| [مال](https://en.wiktionary.org/wiki/%D9%85%D8%A7%D9%84#Arabic) | property, possessions, chattels, goods | māl · noun |
| [مرحبا](https://en.wiktionary.org/wiki/%D9%85%D8%B1%D8%AD%D8%A8%D8%A7#Arabic) | hello, welcome | marḥaban · intj |
| [إله](https://en.wiktionary.org/wiki/%D8%A5%D9%84%D9%87#Arabic) | a god; a deity; a divinity | ʔilāh · noun |
| [جبل](https://en.wiktionary.org/wiki/%D8%AC%D8%A8%D9%84#Arabic) | mountain | jabal · noun |
| [اتفاق](https://en.wiktionary.org/wiki/%D8%A7%D8%AA%D9%81%D8%A7%D9%82#Arabic) | agreement, union, concord, harmony | ittifāq · noun |
| [حفظ](https://en.wiktionary.org/wiki/%D8%AD%D9%81%D8%B8#Arabic) | to preserve, to conserve | ḥafiẓa · verb |
| [رأى](https://en.wiktionary.org/wiki/%D8%B1%D8%A3%D9%89#Arabic) | to see (to perceive with the eyes) | raʔā · verb |
| [سر](https://en.wiktionary.org/wiki/%D8%B3%D8%B1#Arabic) | to gladden, to make happy, to delight, to cheer, to rejoice | sarra · verb |
| [سطح](https://en.wiktionary.org/wiki/%D8%B3%D8%B7%D8%AD#Arabic) | to spread forth, to unroll | saṭaḥa · verb |
| [سفر](https://en.wiktionary.org/wiki/%D8%B3%D9%81%D8%B1#Arabic) | departure, journey, travel | safar · noun |
| [طب](https://en.wiktionary.org/wiki/%D8%B7%D8%A8#Arabic) | medicine (field of study) | ṭibb · noun |
| [منى](https://en.wiktionary.org/wiki/%D9%85%D9%86%D9%89#Arabic) | human sperm | minan · noun |
| [حسنا](https://en.wiktionary.org/wiki/%D8%AD%D8%B3%D9%86%D8%A7#Arabic) | well, fine, okay, good | ḥasanan · adv |
| [درجة الحرارة](https://en.wiktionary.org/wiki/%D8%AF%D8%B1%D8%AC%D8%A9%20%D8%A7%D9%84%D8%AD%D8%B1%D8%A7%D8%B1%D8%A9#Arabic) | temperature | darajat al-ḥarāra · noun |
| [سلم](https://en.wiktionary.org/wiki/%D8%B3%D9%84%D9%85#Arabic) | peace | silm · noun |
| [صلاح](https://en.wiktionary.org/wiki/%D8%B5%D9%84%D8%A7%D8%AD#Arabic) | goodness, righteousness | ṣalāḥ · noun |
| [كوني](https://en.wiktionary.org/wiki/%D9%83%D9%88%D9%86%D9%8A#Arabic) | cosmic, universal, cosmo- | kawniyy · adj |
| [بابا](https://en.wiktionary.org/wiki/%D8%A8%D8%A7%D8%A8%D8%A7#Arabic) | pope, patriarch | bābā · noun |
| [برج](https://en.wiktionary.org/wiki/%D8%A8%D8%B1%D8%AC#Arabic) | tower | burj · noun |
| [تسعة](https://en.wiktionary.org/wiki/%D8%AA%D8%B3%D8%B9%D8%A9#Arabic) | nine | tisʕa · num |
| [حبيب](https://en.wiktionary.org/wiki/%D8%AD%D8%A8%D9%8A%D8%A8#Arabic) | beloved | ḥabīb · adj |
| [خيار](https://en.wiktionary.org/wiki/%D8%AE%D9%8A%D8%A7%D8%B1#Arabic) | cucumber | ḵiyār · noun |
| [رأي](https://en.wiktionary.org/wiki/%D8%B1%D8%A3%D9%8A#Arabic) | an idea, a notion, a concept, a conception; a particular way of thinking, an ideology; a philosophy | raʔy · noun |
| [زوج](https://en.wiktionary.org/wiki/%D8%B2%D9%88%D8%AC#Arabic) | one of a pair | zawj · noun |
| [زين](https://en.wiktionary.org/wiki/%D8%B2%D9%8A%D9%86#Arabic) | to adorn, to decorate, to embellish, to ornament, to garnish | zayyana · verb |
| [شرف](https://en.wiktionary.org/wiki/%D8%B4%D8%B1%D9%81#Arabic) | to be noble, to be highborn, to be illustrious, to be eminent, to be distinguished, to be high-ranking | šarufa · verb |
| [شهد](https://en.wiktionary.org/wiki/%D8%B4%D9%87%D8%AF#Arabic) | to witness, to be a witness | šahida · verb |
| [ظاهرة](https://en.wiktionary.org/wiki/%D8%B8%D8%A7%D9%87%D8%B1%D8%A9#Arabic) | phenomenon | ẓāhira · noun |
| [فرد](https://en.wiktionary.org/wiki/%D9%81%D8%B1%D8%AF#Arabic) | to be single, be alone | farada · verb |
| [مريض](https://en.wiktionary.org/wiki/%D9%85%D8%B1%D9%8A%D8%B6#Arabic) | sick, ill (in poor health) | marīḍ · adj |
| [موسيقى](https://en.wiktionary.org/wiki/%D9%85%D9%88%D8%B3%D9%8A%D9%82%D9%89#Arabic) | music | mūsīqā · noun |
| [يوم الأربعاء](https://en.wiktionary.org/wiki/%D9%8A%D9%88%D9%85%20%D8%A7%D9%84%D8%A3%D8%B1%D8%A8%D8%B9%D8%A7%D8%A1#Arabic) | Wednesday | yawm al-ʔarbaʕāʔ · noun |
| [جبهة](https://en.wiktionary.org/wiki/%D8%AC%D8%A8%D9%87%D8%A9#Arabic) | forehead, brow | jabha · noun |
| [دكتور](https://en.wiktionary.org/wiki/%D8%AF%D9%83%D8%AA%D9%88%D8%B1#Arabic) | doctor | duktūr · noun |
| [رضا](https://en.wiktionary.org/wiki/%D8%B1%D8%B6%D8%A7#Arabic) | contentedness, satisfaction, fulfillment, being well pleased | riḍan · noun |
| [فجأة](https://en.wiktionary.org/wiki/%D9%81%D8%AC%D8%A3%D8%A9#Arabic) | suddenly, unexpectedly, inadvertently, unawares | fajʔatan · adv |
| [أحسن](https://en.wiktionary.org/wiki/%D8%A3%D8%AD%D8%B3%D9%86#Arabic) | to do or act well, to do or act right; to do or act good | ʔaḥsana · verb |
| [ت](https://en.wiktionary.org/wiki/%D8%AA#Arabic) | particle denoting an oath, used only in تَٱللّٰهِ (tal-lāhi) | ta · prep |
| [حديقة](https://en.wiktionary.org/wiki/%D8%AD%D8%AF%D9%8A%D9%82%D8%A9#Arabic) | garden (decorative piece of land outside) | ḥadīqa · noun |
| [مكتبة](https://en.wiktionary.org/wiki/%D9%85%D9%83%D8%AA%D8%A8%D8%A9#Arabic) | library | maktaba · noun |
| [أسود](https://en.wiktionary.org/wiki/%D8%A3%D8%B3%D9%88%D8%AF#Arabic) | black | ʔaswad · adj |
| [شجرة](https://en.wiktionary.org/wiki/%D8%B4%D8%AC%D8%B1%D8%A9#Arabic) | tree | šajara · noun |
| [شمس](https://en.wiktionary.org/wiki/%D8%B4%D9%85%D8%B3#Arabic) | sun | šams · noun |
| [نظام تشغيل](https://en.wiktionary.org/wiki/%D9%86%D8%B8%D8%A7%D9%85%20%D8%AA%D8%B4%D8%BA%D9%8A%D9%84#Arabic) | operating system | niẓām tašḡīl · noun |
| [بحر](https://en.wiktionary.org/wiki/%D8%A8%D8%AD%D8%B1#Arabic) | sea | baḥr · noun |

</details>

<details><summary>Words 501–550</summary>

![[Resources/Audio/ar/Words 0501-0550.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [تسعة عشر](https://en.wiktionary.org/wiki/%D8%AA%D8%B3%D8%B9%D8%A9%20%D8%B9%D8%B4%D8%B1#Arabic) | nineteen | tisʕata ʕašara · num |
| [جزر](https://en.wiktionary.org/wiki/%D8%AC%D8%B2%D8%B1#Arabic) | carrots | jazar · noun |
| [رئيس وزراء](https://en.wiktionary.org/wiki/%D8%B1%D8%A6%D9%8A%D8%B3%20%D9%88%D8%B2%D8%B1%D8%A7%D8%A1#Arabic) | prime minister | raʔīs wuzarāʔ · noun |
| [عدن](https://en.wiktionary.org/wiki/%D8%B9%D8%AF%D9%86#Arabic) | to stay, to bide, to remain | ʕadana · verb |
| [ملكة](https://en.wiktionary.org/wiki/%D9%85%D9%84%D9%83%D8%A9#Arabic) | queen | malika · noun |
| [هاتف](https://en.wiktionary.org/wiki/%D9%87%D8%A7%D8%AA%D9%81#Arabic) | shouting, calling loudly | hātif · noun |
| [ورقة](https://en.wiktionary.org/wiki/%D9%88%D8%B1%D9%82%D8%A9#Arabic) | leaf | waraqa · noun |
| [استطاع](https://en.wiktionary.org/wiki/%D8%A7%D8%B3%D8%AA%D8%B7%D8%A7%D8%B9#Arabic) | to be able to, to be capable of, can | istaṭāʕa · verb |
| [استعمال](https://en.wiktionary.org/wiki/%D8%A7%D8%B3%D8%AA%D8%B9%D9%85%D8%A7%D9%84#Arabic) | use | istiʕmāl · noun |
| [تحليل](https://en.wiktionary.org/wiki/%D8%AA%D8%AD%D9%84%D9%8A%D9%84#Arabic) | dissolution, resolution, breaking up, decomposition | taḥlīl · noun |
| [عامر](https://en.wiktionary.org/wiki/%D8%B9%D8%A7%D9%85%D8%B1#Arabic) | inhabited, peopled, populated | ʕāmir · adj |
| [وطني](https://en.wiktionary.org/wiki/%D9%88%D8%B7%D9%86%D9%8A#Arabic) | national | waṭaniyy · adj |
| [آب](https://en.wiktionary.org/wiki/%D8%A2%D8%A8#Arabic) | to return, to come back | ʔāba · verb |
| [تركي](https://en.wiktionary.org/wiki/%D8%AA%D8%B1%D9%83%D9%8A#Arabic) | Turkish | turkiyy · adj |
| [حر](https://en.wiktionary.org/wiki/%D8%AD%D8%B1#Arabic) | free | ḥurr · adj |
| [عالي](https://en.wiktionary.org/wiki/%D8%B9%D8%A7%D9%84%D9%8A#Arabic) | over, upon, above | ʕālī · adv |
| [متن](https://en.wiktionary.org/wiki/%D9%85%D8%AA%D9%86#Arabic) | to be firm, to be solid, to be sturdy | matuna · verb |
| [مثلي](https://en.wiktionary.org/wiki/%D9%85%D8%AB%D9%84%D9%8A#Arabic) | sexually attracted to the same sex, homosexual | miṯliyy · adj |
| [مع السلامة](https://en.wiktionary.org/wiki/%D9%85%D8%B9%20%D8%A7%D9%84%D8%B3%D9%84%D8%A7%D9%85%D8%A9#Arabic) | goodbye, farewell | maʕa s-salāmati · intj |
| [ممثل](https://en.wiktionary.org/wiki/%D9%85%D9%85%D8%AB%D9%84#Arabic) | actor | mumaṯṯil · noun |
| [أصغر](https://en.wiktionary.org/wiki/%D8%A3%D8%B5%D8%BA%D8%B1#Arabic) | smaller; smallest | ʔaṣḡar · adj |
| [إقليم](https://en.wiktionary.org/wiki/%D8%A5%D9%82%D9%84%D9%8A%D9%85#Arabic) | region, climate (geographical area of the earth, particularly a zone of latitude) | ʔiqlīm · noun |
| [الحمد لله](https://en.wiktionary.org/wiki/%D8%A7%D9%84%D8%AD%D9%85%D8%AF%20%D9%84%D9%84%D9%87#Arabic) | praise be to God, thank God; alhamdulillah | al-ḥamdu li-llāhi · phrase |
| [تأمين](https://en.wiktionary.org/wiki/%D8%AA%D8%A3%D9%85%D9%8A%D9%86#Arabic) | protection, securing, ensuring | taʔmīn · noun |
| [درس](https://en.wiktionary.org/wiki/%D8%AF%D8%B1%D8%B3#Arabic) | to erase, to efface, to obliterate, to wipe out, to make hard to see | darasa · verb |
| [دم](https://en.wiktionary.org/wiki/%D8%AF%D9%85#Arabic) | to coat, to smear | damma · verb |
| [بلدية](https://en.wiktionary.org/wiki/%D8%A8%D9%84%D8%AF%D9%8A%D8%A9#Arabic) | township, rural community | baladiyya · noun |
| [ثالث](https://en.wiktionary.org/wiki/%D8%AB%D8%A7%D9%84%D8%AB#Arabic) | third | ṯāliṯ · adj |
| [جابر](https://en.wiktionary.org/wiki/%D8%AC%D8%A7%D8%A8%D8%B1#Arabic) | to treat with kindness, to be nice | jābara · verb |
| [حرف](https://en.wiktionary.org/wiki/%D8%AD%D8%B1%D9%81#Arabic) | to turn to the opposite side | ḥarafa · verb |
| [فريد](https://en.wiktionary.org/wiki/%D9%81%D8%B1%D9%8A%D8%AF#Arabic) | alone, single | farīd · adj |
| [لازم](https://en.wiktionary.org/wiki/%D9%84%D8%A7%D8%B2%D9%85#Arabic) | necessary, urgent, unavoidable | lāzim · adj |
| [مطعم](https://en.wiktionary.org/wiki/%D9%85%D8%B7%D8%B9%D9%85#Arabic) | restaurant | maṭʕam · noun |
| [أليس كذلك](https://en.wiktionary.org/wiki/%D8%A3%D9%84%D9%8A%D8%B3%20%D9%83%D8%B0%D9%84%D9%83#Arabic) | isn't it?, isn't it so? | /ʔa.laj.sa ka.ðaː.li.ka/ · intj |
| [انتظار](https://en.wiktionary.org/wiki/%D8%A7%D9%86%D8%AA%D8%B8%D8%A7%D8%B1#Arabic) | waiting | intiẓār · noun |
| [جدول](https://en.wiktionary.org/wiki/%D8%AC%D8%AF%D9%88%D9%84#Arabic) | creek, brook, little stream | jadwal · noun |
| [جنيه](https://en.wiktionary.org/wiki/%D8%AC%D9%86%D9%8A%D9%87#Arabic) | pound (unit of currency) | junayh · noun |
| [حوار](https://en.wiktionary.org/wiki/%D8%AD%D9%88%D8%A7%D8%B1#Arabic) | dialogue, conversation | ḥiwār · noun |
| [دام](https://en.wiktionary.org/wiki/%D8%AF%D8%A7%D9%85#Arabic) | to last, to endure | dāma · verb |
| [دعا](https://en.wiktionary.org/wiki/%D8%AF%D8%B9%D8%A7#Arabic) | to call | daʕā · verb |
| [رابط](https://en.wiktionary.org/wiki/%D8%B1%D8%A7%D8%A8%D8%B7#Arabic) | link, linkage | rābiṭ · noun |
| [راح](https://en.wiktionary.org/wiki/%D8%B1%D8%A7%D8%AD#Arabic) | to go in the evening | rāḥa · verb |
| [شغل](https://en.wiktionary.org/wiki/%D8%B4%D8%BA%D9%84#Arabic) | to occupy, to keep busy | šaḡala · verb |
| [كنيسة](https://en.wiktionary.org/wiki/%D9%83%D9%86%D9%8A%D8%B3%D8%A9#Arabic) | church (building and organization) | kanīsa · noun |
| [مسؤولية](https://en.wiktionary.org/wiki/%D9%85%D8%B3%D8%A4%D9%88%D9%84%D9%8A%D8%A9#Arabic) | responsibility | masʔūliyya · noun |
| [تل](https://en.wiktionary.org/wiki/%D8%AA%D9%84#Arabic) | heap of sand, hillock, mound, knob | tall · noun |
| [جندي](https://en.wiktionary.org/wiki/%D8%AC%D9%86%D8%AF%D9%8A#Arabic) | soldier | jundiyy · noun |
| [صباح النور](https://en.wiktionary.org/wiki/%D8%B5%D8%A8%D8%A7%D8%AD%20%D8%A7%D9%84%D9%86%D9%88%D8%B1#Arabic) | good morning (in answer to صَبَاح الخَيْر (ṣabāḥ al-ḵayr)) | ṣabāḥ an-nūr · intj |
| [طاقة](https://en.wiktionary.org/wiki/%D8%B7%D8%A7%D9%82%D8%A9#Arabic) | power, strength; fortitude, endurance | ṭāqa · noun |
| [مفتوح](https://en.wiktionary.org/wiki/%D9%85%D9%81%D8%AA%D9%88%D8%AD#Arabic) | open | maftūḥ · adj |

</details>

<details><summary>Words 551–600</summary>

![[Resources/Audio/ar/Words 0551-0600.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [مقال](https://en.wiktionary.org/wiki/%D9%85%D9%82%D8%A7%D9%84#Arabic) | speech, utterance; words | maqāl · noun |
| [أداة](https://en.wiktionary.org/wiki/%D8%A3%D8%AF%D8%A7%D8%A9#Arabic) | device, tool, instrument | ʔadāh · noun |
| [اثنان](https://en.wiktionary.org/wiki/%D8%A7%D8%AB%D9%86%D8%A7%D9%86#Arabic) | two | iṯnān · num |
| [اسمي](https://en.wiktionary.org/wiki/%D8%A7%D8%B3%D9%85%D9%8A#Arabic) | my name is ... | ismī ... · phrase |
| [بلدي](https://en.wiktionary.org/wiki/%D8%A8%D9%84%D8%AF%D9%8A#Arabic) | native, indigenous | baladiyy · adj |
| [بوابة](https://en.wiktionary.org/wiki/%D8%A8%D9%88%D8%A7%D8%A8%D8%A9#Arabic) | gate | bawwāba · noun |
| [تمام](https://en.wiktionary.org/wiki/%D8%AA%D9%85%D8%A7%D9%85#Arabic) | completeness, wholeness, entirety | tamām · noun |
| [لا إله إلا الله محمد رسول الله](https://en.wiktionary.org/wiki/%D9%84%D8%A7%20%D8%A5%D9%84%D9%87%20%D8%A5%D9%84%D8%A7%20%D8%A7%D9%84%D9%84%D9%87%20%D9%85%D8%AD%D9%85%D8%AF%20%D8%B1%D8%B3%D9%88%D9%84%20%D8%A7%D9%84%D9%84%D9%87#Arabic) | There is no deity but God; Muhammad is the messenger of God. | lā ʔilāha ʔillā llāhu muḥammadun rasūlu llāhi · phrase |
| [مساء النور](https://en.wiktionary.org/wiki/%D9%85%D8%B3%D8%A7%D8%A1%20%D8%A7%D9%84%D9%86%D9%88%D8%B1#Arabic) | good evening, answer to مَسَاء الخَيْر (masāʔ al-ḵayr) | masāʔ an-nūr · intj |
| [ملف](https://en.wiktionary.org/wiki/%D9%85%D9%84%D9%81#Arabic) | file (“a collection of papers”), dossier | milaff · noun |
| [ممثلة](https://en.wiktionary.org/wiki/%D9%85%D9%85%D8%AB%D9%84%D8%A9#Arabic) | actress | mumaṯṯila · noun |
| [نظرية](https://en.wiktionary.org/wiki/%D9%86%D8%B8%D8%B1%D9%8A%D8%A9#Arabic) | theory | naẓariyya · noun |
| [احتمال](https://en.wiktionary.org/wiki/%D8%A7%D8%AD%D8%AA%D9%85%D8%A7%D9%84#Arabic) | possibility, likelihood, chance, eventuality | iḥtimāl · noun |
| [علوم](https://en.wiktionary.org/wiki/%D8%B9%D9%84%D9%88%D9%85#Arabic) | science | ʕulūm · noun |
| [غضب](https://en.wiktionary.org/wiki/%D8%BA%D8%B6%D8%A8#Arabic) | to become angry, to be angry | ḡaḍiba · verb |
| [قبيلة](https://en.wiktionary.org/wiki/%D9%82%D8%A8%D9%8A%D9%84%D8%A9#Arabic) | tribe | qabīla · noun |
| [ميدان](https://en.wiktionary.org/wiki/%D9%85%D9%8A%D8%AF%D8%A7%D9%86#Arabic) | square (open space in a city) | maydān · noun |
| [نوم](https://en.wiktionary.org/wiki/%D9%86%D9%88%D9%85#Arabic) | to lull to sleep, to put to bed, to put to sleep, to make lie down | nawwama · verb |
| [حجر](https://en.wiktionary.org/wiki/%D8%AD%D8%AC%D8%B1#Arabic) | to stop, to hinder | ḥajara · verb |
| [حرارة](https://en.wiktionary.org/wiki/%D8%AD%D8%B1%D8%A7%D8%B1%D8%A9#Arabic) | heat | ḥarāra · noun |
| [عزيز](https://en.wiktionary.org/wiki/%D8%B9%D8%B2%D9%8A%D8%B2#Arabic) | powerful, mighty | ʕazīz · adj |
| [فؤاد](https://en.wiktionary.org/wiki/%D9%81%D8%A4%D8%A7%D8%AF#Arabic) | heart | fuʔād · noun |
| [قابل](https://en.wiktionary.org/wiki/%D9%82%D8%A7%D8%A8%D9%84#Arabic) | to stand exactly opposite, to be opposite, to be face to face | qābala · verb |
| [أب](https://en.wiktionary.org/wiki/%D8%A3%D8%A8#Arabic) | father | ʔab · noun |
| [بات](https://en.wiktionary.org/wiki/%D8%A8%D8%A7%D8%AA#Arabic) | definite, definitive | bātt · adj |
| [بال](https://en.wiktionary.org/wiki/%D8%A8%D8%A7%D9%84#Arabic) | mind, heart | bāl · noun |
| [جان](https://en.wiktionary.org/wiki/%D8%AC%D8%A7%D9%86#Arabic) | guilty, delinquent, criminal, flagrant, vicious, evil | jānin · adj |
| [دير](https://en.wiktionary.org/wiki/%D8%AF%D9%8A%D8%B1#Arabic) | monastery, convent, cloister | dayr · noun |
| [زيت](https://en.wiktionary.org/wiki/%D8%B2%D9%8A%D8%AA#Arabic) | oil (all types of oil, edible, fuel, motor oil, etc.) | zayt · noun |
| [سوداء](https://en.wiktionary.org/wiki/%D8%B3%D9%88%D8%AF%D8%A7%D8%A1#Arabic) | black bile, as one of the four liquids of ancient humor medical theory | sawdāʔ · noun |
| [مشهد](https://en.wiktionary.org/wiki/%D9%85%D8%B4%D9%87%D8%AF#Arabic) | place of assembly, meeting, meeting place | mašhad · noun |
| [مناقشة](https://en.wiktionary.org/wiki/%D9%85%D9%86%D8%A7%D9%82%D8%B4%D8%A9#Arabic) | argument, controversy, dispute, debate, discussion | munāqaša · noun |
| [أحمر](https://en.wiktionary.org/wiki/%D8%A3%D8%AD%D9%85%D8%B1#Arabic) | red | ʔaḥmar · adj |
| [اعتبار](https://en.wiktionary.org/wiki/%D8%A7%D8%B9%D8%AA%D8%A8%D8%A7%D8%B1#Arabic) | regard, respect | iʕtibār · noun |
| [حافظ](https://en.wiktionary.org/wiki/%D8%AD%D8%A7%D9%81%D8%B8#Arabic) | to preserve, to maintain, to keep up, to uphold, to sustain | ḥāfaẓa · verb |
| [حاكم](https://en.wiktionary.org/wiki/%D8%AD%D8%A7%D9%83%D9%85#Arabic) | ruling, governing | ḥākim · adj |
| [طرح](https://en.wiktionary.org/wiki/%D8%B7%D8%B1%D8%AD#Arabic) | to throw, to cast, to fling, to toss | ṭaraḥa · verb |
| [فجر](https://en.wiktionary.org/wiki/%D9%81%D8%AC%D8%B1#Arabic) | sinning, committing adultery | fajr · noun |
| [كانا](https://en.wiktionary.org/wiki/%D9%83%D8%A7%D9%86%D8%A7#Arabic) | kana (japanese syllabaries) | kānā · noun |
| [مو](https://en.wiktionary.org/wiki/%D9%85%D9%88#Arabic) | meu, baldmoney (Meum athamanticum) | mū · noun |
| [وافق](https://en.wiktionary.org/wiki/%D9%88%D8%A7%D9%81%D9%82#Arabic) | to succeed, to go well | wāfaqa · verb |
| [احترام](https://en.wiktionary.org/wiki/%D8%A7%D8%AD%D8%AA%D8%B1%D8%A7%D9%85#Arabic) | respect | iḥtirām · noun |
| [تحكم](https://en.wiktionary.org/wiki/%D8%AA%D8%AD%D9%83%D9%85#Arabic) | to have one's own way; to domineer | taḥakkama · verb |
| [قابلة](https://en.wiktionary.org/wiki/%D9%82%D8%A7%D8%A8%D9%84%D8%A9#Arabic) | midwife, accoucheuse, obstetrician | qābila · noun |
| [جهد](https://en.wiktionary.org/wiki/%D8%AC%D9%87%D8%AF#Arabic) | to strive, to struggle, to labour, to exert oneself, to take pains, to endeavor (especially in the sense of strenuously, to the utmost of one's ability, etc.) | jahada · verb |
| [مربع](https://en.wiktionary.org/wiki/%D9%85%D8%B1%D8%A8%D8%B9#Arabic) | square, quadrangular piece | murabbaʕ · noun |
| [واجب](https://en.wiktionary.org/wiki/%D9%88%D8%A7%D8%AC%D8%A8#Arabic) | necessary, indispensable, unavoidable, essential, inevitable, inescapable, requisite | wājib · adj |
| [ثابت](https://en.wiktionary.org/wiki/%D8%AB%D8%A7%D8%A8%D8%AA#Arabic) | constant | ṯābit · adj |
| [زار](https://en.wiktionary.org/wiki/%D8%B2%D8%A7%D8%B1#Arabic) | to incline towards, to repair to the direction of | zāra · verb |
| [عزل](https://en.wiktionary.org/wiki/%D8%B9%D8%B2%D9%84#Arabic) | to remove, to set aside, to isolate, to separate, to segregate, to detach, to cut off | ʕazala · verb |

</details>

<details><summary>Words 601–650</summary>

![[Resources/Audio/ar/Words 0601-0650.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [غاز](https://en.wiktionary.org/wiki/%D8%BA%D8%A7%D8%B2#Arabic) | raider, invader, conqueror | ḡāzin · noun |
| [كلب](https://en.wiktionary.org/wiki/%D9%83%D9%84%D8%A8#Arabic) | dog | kalb · noun |
| [مصنع](https://en.wiktionary.org/wiki/%D9%85%D8%B5%D9%86%D8%B9#Arabic) | factory; plant | maṣnaʕ · noun |
| [استعداد](https://en.wiktionary.org/wiki/%D8%A7%D8%B3%D8%AA%D8%B9%D8%AF%D8%A7%D8%AF#Arabic) | preparation | istiʕdād · noun |
| [بغير](https://en.wiktionary.org/wiki/%D8%A8%D8%BA%D9%8A%D8%B1#Arabic) | without | bi-ḡayri · prep |
| [جمهور](https://en.wiktionary.org/wiki/%D8%AC%D9%85%D9%87%D9%88%D8%B1#Arabic) | the majority | jumhūr · noun |
| [حمص](https://en.wiktionary.org/wiki/%D8%AD%D9%85%D8%B5#Arabic) | to roast (coffee or meat), toast (bread) | ḥammaṣa · verb |
| [رياضة](https://en.wiktionary.org/wiki/%D8%B1%D9%8A%D8%A7%D8%B6%D8%A9#Arabic) | sport (physical activity) | riyāḍa · noun |
| [قوم](https://en.wiktionary.org/wiki/%D9%82%D9%88%D9%85#Arabic) | to raise | qawwama · verb |
| [محسن](https://en.wiktionary.org/wiki/%D9%85%D8%AD%D8%B3%D9%86#Arabic) | improving, enhancing | muḥassin · adj |
| [محيط](https://en.wiktionary.org/wiki/%D9%85%D8%AD%D9%8A%D8%B7#Arabic) | whole | muḥīṭ · adj |
| [اختلاف](https://en.wiktionary.org/wiki/%D8%A7%D8%AE%D8%AA%D9%84%D8%A7%D9%81#Arabic) | disagreement | iḵtilāf · noun |
| [حرام](https://en.wiktionary.org/wiki/%D8%AD%D8%B1%D8%A7%D9%85#Arabic) | forbidden, interdicted, unlawful, illegitimate, haram | ḥarām · adj |
| [دولي](https://en.wiktionary.org/wiki/%D8%AF%D9%88%D9%84%D9%8A#Arabic) | international | duwaliyy · adj |
| [علق](https://en.wiktionary.org/wiki/%D8%B9%D9%84%D9%82#Arabic) | to hang on, to be suspended | ʕaliqa · verb |
| [عيد ميلاد سعيد](https://en.wiktionary.org/wiki/%D8%B9%D9%8A%D8%AF%20%D9%85%D9%8A%D9%84%D8%A7%D8%AF%20%D8%B3%D8%B9%D9%8A%D8%AF#Arabic) | happy birthday! | ʕīd mīlād saʕīd! · intj |
| [قبول](https://en.wiktionary.org/wiki/%D9%82%D8%A8%D9%88%D9%84#Arabic) | acceptance | qabūl · noun |
| [كوكب](https://en.wiktionary.org/wiki/%D9%83%D9%88%D9%83%D8%A8#Arabic) | planet | kawkab · noun |
| [مئة](https://en.wiktionary.org/wiki/%D9%85%D8%A6%D8%A9#Arabic) | hundred | miʔa · num |
| [مخرج](https://en.wiktionary.org/wiki/%D9%85%D8%AE%D8%B1%D8%AC#Arabic) | exit, place of issue | maḵraj · noun |
| [يسير](https://en.wiktionary.org/wiki/%D9%8A%D8%B3%D9%8A%D8%B1#Arabic) | easy | yasīr · adj |
| [انتظر](https://en.wiktionary.org/wiki/%D8%A7%D9%86%D8%AA%D8%B8%D8%B1#Arabic) | to wait for (delay until some event), to await | intaẓara · verb |
| [بشر](https://en.wiktionary.org/wiki/%D8%A8%D8%B4%D8%B1#Arabic) | human | bašar · noun |
| [جسد](https://en.wiktionary.org/wiki/%D8%AC%D8%B3%D8%AF#Arabic) | body | jasad · noun |
| [جملة](https://en.wiktionary.org/wiki/%D8%AC%D9%85%D9%84%D8%A9#Arabic) | series, whole range, collectivity | jumla · noun |
| [طبق](https://en.wiktionary.org/wiki/%D8%B7%D8%A8%D9%82#Arabic) | plate (serving dish) | ṭabaq · noun |
| [كأن](https://en.wiktionary.org/wiki/%D9%83%D8%A3%D9%86#Arabic) | as if | kaʔanna · conj |
| [اختار](https://en.wiktionary.org/wiki/%D8%A7%D8%AE%D8%AA%D8%A7%D8%B1#Arabic) | to choose, to make one’s choice | iḵtāra · verb |
| [بنى](https://en.wiktionary.org/wiki/%D8%A8%D9%86%D9%89#Arabic) | to build, to construct, to raise | banā · verb |
| [ثبت](https://en.wiktionary.org/wiki/%D8%AB%D8%A8%D8%AA#Arabic) | proof | ṯabat · noun |
| [حمام](https://en.wiktionary.org/wiki/%D8%AD%D9%85%D8%A7%D9%85#Arabic) | a bathhouse, a spa | ḥammām · noun |
| [سم](https://en.wiktionary.org/wiki/%D8%B3%D9%85#Arabic) | to poison (someone, something) | samma · verb |
| [شرب](https://en.wiktionary.org/wiki/%D8%B4%D8%B1%D8%A8#Arabic) | to drink | šariba · verb |
| [شين](https://en.wiktionary.org/wiki/%D8%B4%D9%8A%D9%86#Arabic) | disfigurement | šayn · noun |
| [صادق](https://en.wiktionary.org/wiki/%D8%B5%D8%A7%D8%AF%D9%82#Arabic) | telling the truth, truthful, veracious | ṣādiq · adj |
| [صدام](https://en.wiktionary.org/wiki/%D8%B5%D8%AF%D8%A7%D9%85#Arabic) | collision, crash | ṣidām · noun |
| [ضعيف](https://en.wiktionary.org/wiki/%D8%B6%D8%B9%D9%8A%D9%81#Arabic) | weak | ḍaʕīf · adj |
| [قط](https://en.wiktionary.org/wiki/%D9%82%D8%B7#Arabic) | ever, never | qaṭṭu · adv |
| [حيوان](https://en.wiktionary.org/wiki/%D8%AD%D9%8A%D9%88%D8%A7%D9%86#Arabic) | animal, beast | ḥayawān · noun |
| [سرطان](https://en.wiktionary.org/wiki/%D8%B3%D8%B1%D8%B7%D8%A7%D9%86#Arabic) | crab | saraṭān · noun |
| [سمع](https://en.wiktionary.org/wiki/%D8%B3%D9%85%D8%B9#Arabic) | to hear | samiʕa · verb |
| [شاعر](https://en.wiktionary.org/wiki/%D8%B4%D8%A7%D8%B9%D8%B1#Arabic) | poet | šāʕir · noun |
| [لسان](https://en.wiktionary.org/wiki/%D9%84%D8%B3%D8%A7%D9%86#Arabic) | tongue | lisān · noun |
| [لطيف](https://en.wiktionary.org/wiki/%D9%84%D8%B7%D9%8A%D9%81#Arabic) | thin, fine, delicate, dainty | laṭīf · adj |
| [نسخ](https://en.wiktionary.org/wiki/%D9%86%D8%B3%D8%AE#Arabic) | to transcribe, to copy | nasaḵa · verb |
| [حكاية](https://en.wiktionary.org/wiki/%D8%AD%D9%83%D8%A7%D9%8A%D8%A9#Arabic) | story, tale | ḥikāya · noun |
| [روس](https://en.wiktionary.org/wiki/%D8%B1%D9%88%D8%B3#Arabic) | Russians (plural) | rūs · noun |
| [شقة](https://en.wiktionary.org/wiki/%D8%B4%D9%82%D8%A9#Arabic) | apartment, flat (domicile occupying part of a building) | šaqqa · noun |
| [محاكمة](https://en.wiktionary.org/wiki/%D9%85%D8%AD%D8%A7%D9%83%D9%85%D8%A9#Arabic) | trial | muḥākama · noun |
| [معلم](https://en.wiktionary.org/wiki/%D9%85%D8%B9%D9%84%D9%85#Arabic) | taught, schooled, instructed, educated, trained | muʕallam · adj |

</details>

<details><summary>Words 651–700</summary>

![[Resources/Audio/ar/Words 0651-0700.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [موضع](https://en.wiktionary.org/wiki/%D9%85%D9%88%D8%B6%D8%B9#Arabic) | position | mawḍiʕ · noun |
| [وطن](https://en.wiktionary.org/wiki/%D9%88%D8%B7%D9%86#Arabic) | birthplace | waṭan · noun |
| [استقبال](https://en.wiktionary.org/wiki/%D8%A7%D8%B3%D8%AA%D9%82%D8%A8%D8%A7%D9%84#Arabic) | reception | istiqbāl · noun |
| [جبل نار](https://en.wiktionary.org/wiki/%D8%AC%D8%A8%D9%84%20%D9%86%D8%A7%D8%B1#Arabic) | volcano | jabal nār · noun |
| [حفلة](https://en.wiktionary.org/wiki/%D8%AD%D9%81%D9%84%D8%A9#Arabic) | gathering, meeting, assembly | ḥafla · noun |
| [شرط](https://en.wiktionary.org/wiki/%D8%B4%D8%B1%D8%B7#Arabic) | to make a condition, to stipulate | šaraṭa · verb |
| [غرفة نوم](https://en.wiktionary.org/wiki/%D8%BA%D8%B1%D9%81%D8%A9%20%D9%86%D9%88%D9%85#Arabic) | bedroom | ḡurfat nawm · noun |
| [مستقل](https://en.wiktionary.org/wiki/%D9%85%D8%B3%D8%AA%D9%82%D9%84#Arabic) | independent | mustaqill · adj |
| [هل تتكلم الإنجليزية](https://en.wiktionary.org/wiki/%D9%87%D9%84%20%D8%AA%D8%AA%D9%83%D9%84%D9%85%20%D8%A7%D9%84%D8%A5%D9%86%D8%AC%D9%84%D9%8A%D8%B2%D9%8A%D8%A9#Arabic) | do you speak English? | hal tatakallamu l-ʔinglīziyya? · phrase |
| [حرم](https://en.wiktionary.org/wiki/%D8%AD%D8%B1%D9%85#Arabic) | to be sacred, to be sacrosanct, to be inviolable | ḥaruma · verb |
| [خوان](https://en.wiktionary.org/wiki/%D8%AE%D9%88%D8%A7%D9%86#Arabic) | unreliable, faithless, disloyal, treacherous, perfidious | ḵawwān · adj |
| [دان](https://en.wiktionary.org/wiki/%D8%AF%D8%A7%D9%86#Arabic) | to owe (money) | dāna · verb |
| [دستور](https://en.wiktionary.org/wiki/%D8%AF%D8%B3%D8%AA%D9%88%D8%B1#Arabic) | constitution | dustūr · noun |
| [سحر](https://en.wiktionary.org/wiki/%D8%B3%D8%AD%D8%B1#Arabic) | predawn | saḥar · noun |
| [سرعان ما](https://en.wiktionary.org/wiki/%D8%B3%D8%B1%D8%B9%D8%A7%D9%86%20%D9%85%D8%A7#Arabic) | soon, how quickly..!, before long |  · adv |
| [صفر](https://en.wiktionary.org/wiki/%D8%B5%D9%81%D8%B1#Arabic) | to be empty, to be devoid, to be vacant | ṣafira · verb |
| [مسقط](https://en.wiktionary.org/wiki/%D9%85%D8%B3%D9%82%D8%B7#Arabic) | place of birth, birthplace (when combined with the word رَأْس (raʔs, “head”)) | masqaṭ · noun |
| [ترفع](https://en.wiktionary.org/wiki/%D8%AA%D8%B1%D9%81%D8%B9#Arabic) | to deem oneself above something, to look down on | taraffaʕa · verb |
| [تقسيم](https://en.wiktionary.org/wiki/%D8%AA%D9%82%D8%B3%D9%8A%D9%85#Arabic) | division | taqsīm · noun |
| [جثة](https://en.wiktionary.org/wiki/%D8%AC%D8%AB%D8%A9#Arabic) | corpse, cadaver | juṯṯa · noun |
| [دواء](https://en.wiktionary.org/wiki/%D8%AF%D9%88%D8%A7%D8%A1#Arabic) | remedy, medicine, medication, drug | dawāʔ · noun |
| [زهرة](https://en.wiktionary.org/wiki/%D8%B2%D9%87%D8%B1%D8%A9#Arabic) | flower, blossom | zahra · noun |
| [شكر](https://en.wiktionary.org/wiki/%D8%B4%D9%83%D8%B1#Arabic) | to thank, to be thankful, to be grateful | šakara · verb |
| [شهيد](https://en.wiktionary.org/wiki/%D8%B4%D9%87%D9%8A%D8%AF#Arabic) | martyr | šahīd · noun |
| [اقتصاد](https://en.wiktionary.org/wiki/%D8%A7%D9%82%D8%AA%D8%B5%D8%A7%D8%AF#Arabic) | economy (“frugal use of resources”) | iqtiṣād · noun |
| [انقلاب](https://en.wiktionary.org/wiki/%D8%A7%D9%86%D9%82%D9%84%D8%A7%D8%A8#Arabic) | coup d'état | inqilāb · noun |
| [تاج](https://en.wiktionary.org/wiki/%D8%AA%D8%A7%D8%AC#Arabic) | crown | tāj · noun |
| [جامع](https://en.wiktionary.org/wiki/%D8%AC%D8%A7%D9%85%D8%B9#Arabic) | comprehensive, extensive, broad, general, universal | jāmiʕ · adj |
| [جدار](https://en.wiktionary.org/wiki/%D8%AC%D8%AF%D8%A7%D8%B1#Arabic) | wall (division in a building) | jidār · noun |
| [قبيل](https://en.wiktionary.org/wiki/%D9%82%D8%A8%D9%8A%D9%84#Arabic) | guarantor | qabīl · noun |
| [كمان](https://en.wiktionary.org/wiki/%D9%83%D9%85%D8%A7%D9%86#Arabic) | violin | kamān · noun |
| [لبناني](https://en.wiktionary.org/wiki/%D9%84%D8%A8%D9%86%D8%A7%D9%86%D9%8A#Arabic) | Lebanese | lubnāniyy · adj |
| [أكل](https://en.wiktionary.org/wiki/%D8%A3%D9%83%D9%84#Arabic) | to eat; to consume (food) | ʔakala · verb |
| [تعلق](https://en.wiktionary.org/wiki/%D8%AA%D8%B9%D9%84%D9%82#Arabic) | to be suspended, to hang (بِ (bi) from) | taʕallaqa · verb |
| [صاروخ](https://en.wiktionary.org/wiki/%D8%B5%D8%A7%D8%B1%D9%88%D8%AE#Arabic) | rocket | ṣārūḵ · noun |
| [قاتل](https://en.wiktionary.org/wiki/%D9%82%D8%A7%D8%AA%D9%84#Arabic) | to combat, to battle, to fight | qātala · verb |
| [مطر](https://en.wiktionary.org/wiki/%D9%85%D8%B7%D8%B1#Arabic) | to rain (“to have rain fall from the sky”) | maṭara · verb |
| [مهندس](https://en.wiktionary.org/wiki/%D9%85%D9%87%D9%86%D8%AF%D8%B3#Arabic) | geometer | muhandis · noun |
| [بحيرة](https://en.wiktionary.org/wiki/%D8%A8%D8%AD%D9%8A%D8%B1%D8%A9#Arabic) | lake | buḥayra · noun |
| [شر](https://en.wiktionary.org/wiki/%D8%B4%D8%B1#Arabic) | to be bad, to be evil, to act badly | šarra · verb |
| [صمت](https://en.wiktionary.org/wiki/%D8%B5%D9%85%D8%AA#Arabic) | to be silent, to be taciturn, to hold one's tongue, to hush up, to be quiet, to become quiet | ṣamata · verb |
| [فرنسي](https://en.wiktionary.org/wiki/%D9%81%D8%B1%D9%86%D8%B3%D9%8A#Arabic) | French | faransiyy · adj |
| [ليل](https://en.wiktionary.org/wiki/%D9%84%D9%8A%D9%84#Arabic) | nighttime, night | layl · noun |
| [جناح](https://en.wiktionary.org/wiki/%D8%AC%D9%86%D8%A7%D8%AD#Arabic) | wing (organ of flight) | janāḥ · noun |
| [زمان](https://en.wiktionary.org/wiki/%D8%B2%D9%85%D8%A7%D9%86#Arabic) | time | zamān · noun |
| [مجهول](https://en.wiktionary.org/wiki/%D9%85%D8%AC%D9%87%D9%88%D9%84#Arabic) | unknown | majhūl · adj |
| [مفيد](https://en.wiktionary.org/wiki/%D9%85%D9%81%D9%8A%D8%AF#Arabic) | useful, beneficial | mufīd · adj |
| [تحذير](https://en.wiktionary.org/wiki/%D8%AA%D8%AD%D8%B0%D9%8A%D8%B1#Arabic) | warning (“instance of warning someone”) | taḥḏīr · noun |
| [ساحل](https://en.wiktionary.org/wiki/%D8%B3%D8%A7%D8%AD%D9%84#Arabic) | coast | sāḥil · noun |
| [قبر](https://en.wiktionary.org/wiki/%D9%82%D8%A8%D8%B1#Arabic) | to bury, to entomb | qabara · verb |

</details>

<details><summary>Words 701–750</summary>

![[Resources/Audio/ar/Words 0701-0750.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [نافذة](https://en.wiktionary.org/wiki/%D9%86%D8%A7%D9%81%D8%B0%D8%A9#Arabic) | opening in a wall, air hole | nāfiḏa · noun |
| [انتخاب](https://en.wiktionary.org/wiki/%D8%A7%D9%86%D8%AA%D8%AE%D8%A7%D8%A8#Arabic) | election | intiḵāb · noun |
| [دعاء](https://en.wiktionary.org/wiki/%D8%AF%D8%B9%D8%A7%D8%A1#Arabic) | call, prayer, invocation, supplication | duʕāʔ · noun |
| [دقيق](https://en.wiktionary.org/wiki/%D8%AF%D9%82%D9%8A%D9%82#Arabic) | precise, accurate, exact | daqīq · adj |
| [روسي](https://en.wiktionary.org/wiki/%D8%B1%D9%88%D8%B3%D9%8A#Arabic) | Russian | rūsiyy · adj |
| [سأل](https://en.wiktionary.org/wiki/%D8%B3%D8%A3%D9%84#Arabic) | to ask, inquire | saʔala · verb |
| [قرن](https://en.wiktionary.org/wiki/%D9%82%D8%B1%D9%86#Arabic) | century (a period of a hundred years) | qarn · noun |
| [مؤمن](https://en.wiktionary.org/wiki/%D9%85%D8%A4%D9%85%D9%86#Arabic) | faithful, believing | muʔmin · adj |
| [هلال](https://en.wiktionary.org/wiki/%D9%87%D9%84%D8%A7%D9%84#Arabic) | crescent, crescent moon | hilāl · noun |
| [ولادة](https://en.wiktionary.org/wiki/%D9%88%D9%84%D8%A7%D8%AF%D8%A9#Arabic) | birth (process of childbearing) | wilāda · noun |
| [أنثى](https://en.wiktionary.org/wiki/%D8%A3%D9%86%D8%AB%D9%89#Arabic) | a female | ʔunṯā · noun |
| [روسية](https://en.wiktionary.org/wiki/%D8%B1%D9%88%D8%B3%D9%8A%D8%A9#Arabic) | the Russian language, Russian | rūsiyya · noun |
| [زر](https://en.wiktionary.org/wiki/%D8%B2%D8%B1#Arabic) | to encroach upon one's enemy | zarra · verb |
| [كرسي](https://en.wiktionary.org/wiki/%D9%83%D8%B1%D8%B3%D9%8A#Arabic) | chair, seat | kursiyy · noun |
| [مان](https://en.wiktionary.org/wiki/%D9%85%D8%A7%D9%86#Arabic) | to lie | māna · verb |
| [مترو](https://en.wiktionary.org/wiki/%D9%85%D8%AA%D8%B1%D9%88#Arabic) | metro, underground | mitrū · noun |
| [إجازة](https://en.wiktionary.org/wiki/%D8%A5%D8%AC%D8%A7%D8%B2%D8%A9#Arabic) | permission, authorization | ʔijāza · noun |
| [إمام](https://en.wiktionary.org/wiki/%D8%A5%D9%85%D8%A7%D9%85#Arabic) | leader, example, exemplar, paragon | ʔimām · noun |
| [جلد](https://en.wiktionary.org/wiki/%D8%AC%D9%84%D8%AF#Arabic) | skin, hide | jild · noun |
| [حديد](https://en.wiktionary.org/wiki/%D8%AD%D8%AF%D9%8A%D8%AF#Arabic) | armor, helmet | ḥadīd · noun |
| [سماء](https://en.wiktionary.org/wiki/%D8%B3%D9%85%D8%A7%D8%A1#Arabic) | the sky/skies; the heaven(s) (figurative, simile), space, the sphere(s), the cosmos(es), the lift(s). | samāʔ · noun |
| [صيد](https://en.wiktionary.org/wiki/%D8%B5%D9%8A%D8%AF#Arabic) | hunt, hunting, fishing | ṣayd · noun |
| [مترجم](https://en.wiktionary.org/wiki/%D9%85%D8%AA%D8%B1%D8%AC%D9%85#Arabic) | translator; interpreter | mutarjim · noun |
| [مفاجأة](https://en.wiktionary.org/wiki/%D9%85%D9%81%D8%A7%D8%AC%D8%A3%D8%A9#Arabic) | surprise | mufājaʔa · noun |
| [انتصار](https://en.wiktionary.org/wiki/%D8%A7%D9%86%D8%AA%D8%B5%D8%A7%D8%B1#Arabic) | victory, triumph | intiṣār · noun |
| [جنون](https://en.wiktionary.org/wiki/%D8%AC%D9%86%D9%88%D9%86#Arabic) | madness, insanity | junūn · noun |
| [زراعة الأعضاء](https://en.wiktionary.org/wiki/%D8%B2%D8%B1%D8%A7%D8%B9%D8%A9%20%D8%A7%D9%84%D8%A3%D8%B9%D8%B6%D8%A7%D8%A1#Arabic) | organ transplant | zirāʕat al-ʔaʕḍāʔi · noun |
| [شاهين](https://en.wiktionary.org/wiki/%D8%B4%D8%A7%D9%87%D9%8A%D9%86#Arabic) | Indian falcon, especially the peregrine falcon | šāhīn · noun |
| [شاي](https://en.wiktionary.org/wiki/%D8%B4%D8%A7%D9%8A#Arabic) | tea (plant and beverage) | šāy · noun |
| [طاولة](https://en.wiktionary.org/wiki/%D8%B7%D8%A7%D9%88%D9%84%D8%A9#Arabic) | table | ṭāwila · noun |
| [قرأ](https://en.wiktionary.org/wiki/%D9%82%D8%B1%D8%A3#Arabic) | to read | qaraʔa · verb |
| [قمر](https://en.wiktionary.org/wiki/%D9%82%D9%85%D8%B1#Arabic) | to gamble | qamara · verb |
| [كهرباء](https://en.wiktionary.org/wiki/%D9%83%D9%87%D8%B1%D8%A8%D8%A7%D8%A1#Arabic) | electricity | kahrabāʔ · noun |
| [محلي](https://en.wiktionary.org/wiki/%D9%85%D8%AD%D9%84%D9%8A#Arabic) | local, regional, native, national | maḥalliyy · adj |
| [مطبخ](https://en.wiktionary.org/wiki/%D9%85%D8%B7%D8%A8%D8%AE#Arabic) | kitchen | maṭbaḵ · noun |
| [هندي](https://en.wiktionary.org/wiki/%D9%87%D9%86%D8%AF%D9%8A#Arabic) | Indian (from India) | hindiyy · adj |
| [ورق](https://en.wiktionary.org/wiki/%D9%88%D8%B1%D9%82#Arabic) | foliage, leaves | waraq · noun |
| [وضع اجتماعي](https://en.wiktionary.org/wiki/%D9%88%D8%B6%D8%B9%20%D8%A7%D8%AC%D8%AA%D9%85%D8%A7%D8%B9%D9%8A#Arabic) | status, legal status, social status | waḍʕ ijtimāʕiyy · noun |
| [أدب](https://en.wiktionary.org/wiki/%D8%A3%D8%AF%D8%A8#Arabic) | discipline | ʔadab · noun |
| [برمجيات](https://en.wiktionary.org/wiki/%D8%A8%D8%B1%D9%85%D8%AC%D9%8A%D8%A7%D8%AA#Arabic) | software | barmajiyyāt · noun |
| [جرح](https://en.wiktionary.org/wiki/%D8%AC%D8%B1%D8%AD#Arabic) | wound | jurḥ · noun |
| [سمك](https://en.wiktionary.org/wiki/%D8%B3%D9%85%D9%83#Arabic) | fish | samak · noun |
| [عدو](https://en.wiktionary.org/wiki/%D8%B9%D8%AF%D9%88#Arabic) | enemy; foe | ʕaduww · noun |
| [قصد](https://en.wiktionary.org/wiki/%D9%82%D8%B5%D8%AF#Arabic) | to mean, to intend | qaṣada · verb |
| [مرشح](https://en.wiktionary.org/wiki/%D9%85%D8%B1%D8%B4%D8%AD#Arabic) | candidate (in an election), nominee | muraššaḥ · noun |
| [هرب](https://en.wiktionary.org/wiki/%D9%87%D8%B1%D8%A8#Arabic) | to flee, to escape | haraba · verb |
| [وزن](https://en.wiktionary.org/wiki/%D9%88%D8%B2%D9%86#Arabic) | to weigh (“to determine the weight of an object”) | wazana · verb |
| [أهلا](https://en.wiktionary.org/wiki/%D8%A3%D9%87%D9%84%D8%A7#Arabic) | as a kin, as a member of my kinfolk, in kindness | ʔahlan · adv |
| [بالغ](https://en.wiktionary.org/wiki/%D8%A8%D8%A7%D9%84%D8%BA#Arabic) | to exaggerate | bālaḡa · verb |
| [بركة](https://en.wiktionary.org/wiki/%D8%A8%D8%B1%D9%83%D8%A9#Arabic) | bliss, blessing, boon | baraka · noun |

</details>

<details><summary>Words 751–800</summary>

![[Resources/Audio/ar/Words 0751-0800.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [حصان](https://en.wiktionary.org/wiki/%D8%AD%D8%B5%D8%A7%D9%86#Arabic) | horse | ḥiṣān · noun |
| [حكيم](https://en.wiktionary.org/wiki/%D8%AD%D9%83%D9%8A%D9%85#Arabic) | wise | ḥakīm · adj |
| [سينما](https://en.wiktionary.org/wiki/%D8%B3%D9%8A%D9%86%D9%85%D8%A7#Arabic) | cinema | sīnamā · noun |
| [شن](https://en.wiktionary.org/wiki/%D8%B4%D9%86#Arabic) | to launch (war; campaign) | šanna · verb |
| [صينية](https://en.wiktionary.org/wiki/%D8%B5%D9%8A%D9%86%D9%8A%D8%A9#Arabic) | Chinese language | ṣīniyya · noun |
| [فيل](https://en.wiktionary.org/wiki/%D9%81%D9%8A%D9%84#Arabic) | elephant | fīl · noun |
| [قهوة](https://en.wiktionary.org/wiki/%D9%82%D9%87%D9%88%D8%A9#Arabic) | coffee (the drink) | qahwa · noun |
| [مقبرة](https://en.wiktionary.org/wiki/%D9%85%D9%82%D8%A8%D8%B1%D8%A9#Arabic) | cemetery, graveyard, burial ground | maqbara · noun |
| [إسلام](https://en.wiktionary.org/wiki/%D8%A5%D8%B3%D9%84%D8%A7%D9%85#Arabic) | religious submission to God, piety | ʔislām · noun |
| [حاد](https://en.wiktionary.org/wiki/%D8%AD%D8%A7%D8%AF#Arabic) | sharp, pointed | ḥādd · adj |
| [ستون](https://en.wiktionary.org/wiki/%D8%B3%D8%AA%D9%88%D9%86#Arabic) | sixty | sittūna · num |
| [سقف](https://en.wiktionary.org/wiki/%D8%B3%D9%82%D9%81#Arabic) | ceiling | saqf · noun |
| [سنا](https://en.wiktionary.org/wiki/%D8%B3%D9%86%D8%A7#Arabic) | to irrigate, to water | sanā · verb |
| [شاطئ](https://en.wiktionary.org/wiki/%D8%B4%D8%A7%D8%B7%D8%A6#Arabic) | shore, coast, seacoast, beach, strand | šāṭiʔ · noun |
| [صفة](https://en.wiktionary.org/wiki/%D8%B5%D9%81%D8%A9#Arabic) | quality, feature, characteristic | ṣifa · noun |
| [قلم](https://en.wiktionary.org/wiki/%D9%82%D9%84%D9%85#Arabic) | to cut, to clip, to pare, to prune, to trim, to lop, to truncate, to snip, to cut back, to cut down | qalama · verb |
| [كمبيوتر](https://en.wiktionary.org/wiki/%D9%83%D9%85%D8%A8%D9%8A%D9%88%D8%AA%D8%B1#Arabic) | computer | kambyūtar · noun |
| [مقعد](https://en.wiktionary.org/wiki/%D9%85%D9%82%D8%B9%D8%AF#Arabic) | seat | maqʕad · noun |
| [نبي](https://en.wiktionary.org/wiki/%D9%86%D8%A8%D9%8A#Arabic) | prophet | nabiyy · noun |
| [نجمة](https://en.wiktionary.org/wiki/%D9%86%D8%AC%D9%85%D8%A9#Arabic) | star | najma · noun |
| [نقاش](https://en.wiktionary.org/wiki/%D9%86%D9%82%D8%A7%D8%B4#Arabic) | discussion | niqāš · noun |
| [نوح](https://en.wiktionary.org/wiki/%D9%86%D9%88%D8%AD#Arabic) | crying out in grief, wailing, sobbing, loud weeping, lamentation, lamenting, ululation | nawḥ · noun |
| [أميرة](https://en.wiktionary.org/wiki/%D8%A3%D9%85%D9%8A%D8%B1%D8%A9#Arabic) | princess | ʔamīra · noun |
| [ارتفع](https://en.wiktionary.org/wiki/%D8%A7%D8%B1%D8%AA%D9%81%D8%B9#Arabic) | to lift, to rise, to ascend, to go higher | irtafaʕa · verb |
| [بنت الأخ](https://en.wiktionary.org/wiki/%D8%A8%D9%86%D8%AA%20%D8%A7%D9%84%D8%A3%D8%AE#Arabic) | fraternal niece |  · noun |
| [عصير](https://en.wiktionary.org/wiki/%D8%B9%D8%B5%D9%8A%D8%B1#Arabic) | juice | ʕaṣīr · noun |
| [فرنسية](https://en.wiktionary.org/wiki/%D9%81%D8%B1%D9%86%D8%B3%D9%8A%D8%A9#Arabic) | the French language, French | faransiyya · noun |
| [أرضية](https://en.wiktionary.org/wiki/%D8%A3%D8%B1%D8%B6%D9%8A%D8%A9#Arabic) | floor (“lower part of a room”) | ʔarḍiyya · noun |
| [درب](https://en.wiktionary.org/wiki/%D8%AF%D8%B1%D8%A8#Arabic) | path, pass, way | darb · noun |
| [سكن](https://en.wiktionary.org/wiki/%D8%B3%D9%83%D9%86#Arabic) | to be still, to be tranquil, to be peaceful | sakana · verb |
| [ظن](https://en.wiktionary.org/wiki/%D8%B8%D9%86#Arabic) | to think, to opine, to suppose, to conjecture | ẓanna · verb |
| [منخفض](https://en.wiktionary.org/wiki/%D9%85%D9%86%D8%AE%D9%81%D8%B6#Arabic) | low (altitude, frequency, price, etc.) | munḵafiḍ · adj |
| [هدوء](https://en.wiktionary.org/wiki/%D9%87%D8%AF%D9%88%D8%A1#Arabic) | calming down, quieting, subsiding | hudūʔ · noun |
| [شعبي](https://en.wiktionary.org/wiki/%D8%B4%D8%B9%D8%A8%D9%8A#Arabic) | national, people’s | šaʕbiyy · adj |
| [عفوا](https://en.wiktionary.org/wiki/%D8%B9%D9%81%D9%88%D8%A7#Arabic) | you're welcome, don't mention it, not at all | ʕafwan · intj |
| [كف](https://en.wiktionary.org/wiki/%D9%83%D9%81#Arabic) | to desist or to cease | kaffa · verb |
| [كيف حالك](https://en.wiktionary.org/wiki/%D9%83%D9%8A%D9%81%20%D8%AD%D8%A7%D9%84%D9%83#Arabic) | how are you? (when addressing a male) | kayfa ḥāluka? · phrase |
| [أسر](https://en.wiktionary.org/wiki/%D8%A3%D8%B3%D8%B1#Arabic) | to bind; to fetter | ʔasara · verb |
| [تحسن](https://en.wiktionary.org/wiki/%D8%AA%D8%AD%D8%B3%D9%86#Arabic) | to improve, to get better, to ameliorate | taḥassana · verb |
| [حزام](https://en.wiktionary.org/wiki/%D8%AD%D8%B2%D8%A7%D9%85#Arabic) | belt, girth, waistband | ḥizām · noun |
| [ركز](https://en.wiktionary.org/wiki/%D8%B1%D9%83%D8%B2#Arabic) | to plant into the ground, to embed | rakaza · verb |
| [شهري](https://en.wiktionary.org/wiki/%D8%B4%D9%87%D8%B1%D9%8A#Arabic) | monthly | šahriyy · adj |
| [صيني](https://en.wiktionary.org/wiki/%D8%B5%D9%8A%D9%86%D9%8A#Arabic) | Chinese | ṣīniyy · adj |
| [فقر](https://en.wiktionary.org/wiki/%D9%81%D9%82%D8%B1#Arabic) | to dig | faqara · verb |
| [لواء](https://en.wiktionary.org/wiki/%D9%84%D9%88%D8%A7%D8%A1#Arabic) | banner, flag, standard | liwāʔ · noun |
| [مجنون](https://en.wiktionary.org/wiki/%D9%85%D8%AC%D9%86%D9%88%D9%86#Arabic) | mad, crazy, insane, possessed | majnūn · adj |
| [نهار](https://en.wiktionary.org/wiki/%D9%86%D9%87%D8%A7%D8%B1#Arabic) | daytime, day | nahār · noun |
| [آمين](https://en.wiktionary.org/wiki/%D8%A2%D9%85%D9%8A%D9%86#Arabic) | amen | ʔāmīna · intj |
| [أجر](https://en.wiktionary.org/wiki/%D8%A3%D8%AC%D8%B1#Arabic) | to reward, to pay, to compensate | ʔajara · verb |
| [بسم الله](https://en.wiktionary.org/wiki/%D8%A8%D8%B3%D9%85%20%D8%A7%D9%84%D9%84%D9%87#Arabic) | bismillah, in the name of God | bi-smi llāh · phrase |

</details>

<details><summary>Words 801–850</summary>

![[Resources/Audio/ar/Words 0801-0850.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [جزاء](https://en.wiktionary.org/wiki/%D8%AC%D8%B2%D8%A7%D8%A1#Arabic) | repayment | jazāʔ · noun |
| [ذرة](https://en.wiktionary.org/wiki/%D8%B0%D8%B1%D8%A9#Arabic) | tiny particle, speck, mote | ḏarra · noun |
| [رقص](https://en.wiktionary.org/wiki/%D8%B1%D9%82%D8%B5#Arabic) | to dance | raqaṣa · verb |
| [كلم](https://en.wiktionary.org/wiki/%D9%83%D9%84%D9%85#Arabic) | to speak, to talk, to address | kallama · verb |
| [مصرف](https://en.wiktionary.org/wiki/%D9%85%D8%B5%D8%B1%D9%81#Arabic) | bank (institution) | maṣrif · noun |
| [منظر](https://en.wiktionary.org/wiki/%D9%85%D9%86%D8%B8%D8%B1#Arabic) | sight | manẓar · noun |
| [أسد](https://en.wiktionary.org/wiki/%D8%A3%D8%B3%D8%AF#Arabic) | lion | ʔasad · noun |
| [تركية](https://en.wiktionary.org/wiki/%D8%AA%D8%B1%D9%83%D9%8A%D8%A9#Arabic) | Turkish woman | turkiyya · noun |
| [خلية](https://en.wiktionary.org/wiki/%D8%AE%D9%84%D9%8A%D8%A9#Arabic) | cell (basic unit of a living organism) | ḵaliyya · noun |
| [صحراء](https://en.wiktionary.org/wiki/%D8%B5%D8%AD%D8%B1%D8%A7%D8%A1#Arabic) | desert | ṣaḥrāʔ · noun |
| [محرم](https://en.wiktionary.org/wiki/%D9%85%D8%AD%D8%B1%D9%85#Arabic) | mahram, unmarriageable relative | maḥram · noun |
| [مقام](https://en.wiktionary.org/wiki/%D9%85%D9%82%D8%A7%D9%85#Arabic) | place, spot | maqām · noun |
| [آلة الفم](https://en.wiktionary.org/wiki/%D8%A2%D9%84%D8%A9%20%D8%A7%D9%84%D9%81%D9%85#Arabic) | wind instrument | ʔālatu l-fami · noun |
| [إسرائيلي](https://en.wiktionary.org/wiki/%D8%A5%D8%B3%D8%B1%D8%A7%D8%A6%D9%8A%D9%84%D9%8A#Arabic) | Israeli | ʔisrāʔīliyy · adj |
| [حليب](https://en.wiktionary.org/wiki/%D8%AD%D9%84%D9%8A%D8%A8#Arabic) | milk | ḥalīb · noun |
| [درويش](https://en.wiktionary.org/wiki/%D8%AF%D8%B1%D9%88%D9%8A%D8%B4#Arabic) | dervish | darwīš · noun |
| [ديمقراطية](https://en.wiktionary.org/wiki/%D8%AF%D9%8A%D9%85%D9%82%D8%B1%D8%A7%D8%B7%D9%8A%D8%A9#Arabic) | democracy | dīmuqrāṭiyya · noun |
| [رجع](https://en.wiktionary.org/wiki/%D8%B1%D8%AC%D8%B9#Arabic) | to return, to come back | rajaʕa · verb |
| [عدل](https://en.wiktionary.org/wiki/%D8%B9%D8%AF%D9%84#Arabic) | to act justly | ʕadala · verb |
| [عمارة](https://en.wiktionary.org/wiki/%D8%B9%D9%85%D8%A7%D8%B1%D8%A9#Arabic) | tribe, clan | ʕamāra · noun |
| [متعب](https://en.wiktionary.org/wiki/%D9%85%D8%AA%D8%B9%D8%A8#Arabic) | tiring | mutʕib · adj |
| [منهج](https://en.wiktionary.org/wiki/%D9%85%D9%86%D9%87%D8%AC#Arabic) | specific manner of doing something; methodology; system; programme | minhaj · noun |
| [أخضر](https://en.wiktionary.org/wiki/%D8%A3%D8%AE%D8%B6%D8%B1#Arabic) | green; verdant | ʔaḵḍar · adj |
| [تو](https://en.wiktionary.org/wiki/%D8%AA%D9%88#Arabic) | instantaneousness, immediacy, onlyness, the condition of having been present just i.e. recently and/or alone | taww · noun |
| [جيب](https://en.wiktionary.org/wiki/%D8%AC%D9%8A%D8%A8#Arabic) | neckline, collar | jayb · noun |
| [حسنة](https://en.wiktionary.org/wiki/%D8%AD%D8%B3%D9%86%D8%A9#Arabic) | good deed, benefaction | ḥasana · noun |
| [رزق](https://en.wiktionary.org/wiki/%D8%B1%D8%B2%D9%82#Arabic) | daily wage, livelihood, subsistence | rizq · noun |
| [قبلة](https://en.wiktionary.org/wiki/%D9%82%D8%A8%D9%84%D8%A9#Arabic) | kiss | qubla · noun |
| [أخ](https://en.wiktionary.org/wiki/%D8%A3%D8%AE#Arabic) | brother | ʔaḵ · noun |
| [أزرق](https://en.wiktionary.org/wiki/%D8%A3%D8%B2%D8%B1%D9%82#Arabic) | blue, blue-coloured | ʔazraq · adj |
| [تمثال](https://en.wiktionary.org/wiki/%D8%AA%D9%85%D8%AB%D8%A7%D9%84#Arabic) | sculpture, statue | timṯāl · noun |
| [سور](https://en.wiktionary.org/wiki/%D8%B3%D9%88%D8%B1#Arabic) | wall that encloses and protects a building | sūr · noun |
| [شيعة](https://en.wiktionary.org/wiki/%D8%B4%D9%8A%D8%B9%D8%A9#Arabic) | cult, sect | šīʕa · noun |
| [طائفة](https://en.wiktionary.org/wiki/%D8%B7%D8%A7%D8%A6%D9%81%D8%A9#Arabic) | band, bevy, covey, drove, group, swarm, troop | ṭāʔifa · noun |
| [نهج](https://en.wiktionary.org/wiki/%D9%86%D9%87%D8%AC#Arabic) | to follow | nahaja · verb |
| [أذن](https://en.wiktionary.org/wiki/%D8%A3%D8%B0%D9%86#Arabic) | ear | ʔuḏun · noun |
| [بندر](https://en.wiktionary.org/wiki/%D8%A8%D9%86%D8%AF%D8%B1#Arabic) | port | bandar · noun |
| [تقليد](https://en.wiktionary.org/wiki/%D8%AA%D9%82%D9%84%D9%8A%D8%AF#Arabic) | imitation, copying | taqlīd · noun |
| [جنوبي](https://en.wiktionary.org/wiki/%D8%AC%D9%86%D9%88%D8%A8%D9%8A#Arabic) | southern | janūbiyy · adj |
| [حنا](https://en.wiktionary.org/wiki/%D8%AD%D9%86%D8%A7#Arabic) | to bend, to curve | ḥanā · verb |
| [دمر](https://en.wiktionary.org/wiki/%D8%AF%D9%85%D8%B1#Arabic) | to destroy | dammara · verb |
| [شاه](https://en.wiktionary.org/wiki/%D8%B4%D8%A7%D9%87#Arabic) | to be or become ugly, misshapen | šāha · verb |
| [شيطان](https://en.wiktionary.org/wiki/%D8%B4%D9%8A%D8%B7%D8%A7%D9%86#Arabic) | Satan, shaitan, the Devil | šayṭān · noun |
| [غبي](https://en.wiktionary.org/wiki/%D8%BA%D8%A8%D9%8A#Arabic) | to be ignorant, to not understand | ḡabiya · verb |
| [قبض](https://en.wiktionary.org/wiki/%D9%82%D8%A8%D8%B6#Arabic) | to seize, to take, to grab | qabaḍa · verb |
| [لبس](https://en.wiktionary.org/wiki/%D9%84%D8%A8%D8%B3#Arabic) | to wear; to put on (clothing) | labisa · verb |
| [مظهر](https://en.wiktionary.org/wiki/%D9%85%D8%B8%D9%87%D8%B1#Arabic) | appearance, look | maẓhar · noun |
| [أخت](https://en.wiktionary.org/wiki/%D8%A3%D8%AE%D8%AA#Arabic) | sister | ʔuḵt · noun |
| [أقدم مهنة](https://en.wiktionary.org/wiki/%D8%A3%D9%82%D8%AF%D9%85%20%D9%85%D9%87%D9%86%D8%A9#Arabic) | world's oldest profession, prostitution | ʔaqdam mihna · noun |
| [إلكتروني](https://en.wiktionary.org/wiki/%D8%A5%D9%84%D9%83%D8%AA%D8%B1%D9%88%D9%86%D9%8A#Arabic) | electronic | ʔiliktrūniyy · adj |

</details>

<details><summary>Words 851–900</summary>

![[Resources/Audio/ar/Words 0851-0900.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [بار](https://en.wiktionary.org/wiki/%D8%A8%D8%A7%D8%B1#Arabic) | to perish | bāra · verb |
| [شاحنة](https://en.wiktionary.org/wiki/%D8%B4%D8%A7%D8%AD%D9%86%D8%A9#Arabic) | truck, lorry | šāḥina · noun |
| [عربة](https://en.wiktionary.org/wiki/%D8%B9%D8%B1%D8%A8%D8%A9#Arabic) | river with a strong current | ʕaraba · noun |
| [مسلح](https://en.wiktionary.org/wiki/%D9%85%D8%B3%D9%84%D8%AD#Arabic) | armed | musallaḥ · adj |
| [بارز](https://en.wiktionary.org/wiki/%D8%A8%D8%A7%D8%B1%D8%B2#Arabic) | prominent | bāriz · adj |
| [بالكاد](https://en.wiktionary.org/wiki/%D8%A8%D8%A7%D9%84%D9%83%D8%A7%D8%AF#Arabic) | almost, nearly | bi-l-kād · adv |
| [خال](https://en.wiktionary.org/wiki/%D8%AE%D8%A7%D9%84#Arabic) | empty, void | ḵālin · adj |
| [دنيا](https://en.wiktionary.org/wiki/%D8%AF%D9%86%D9%8A%D8%A7#Arabic) | this mortal life; life in this world | dunyā · noun |
| [ذنب](https://en.wiktionary.org/wiki/%D8%B0%D9%86%D8%A8#Arabic) | tail, end | ḏanab · noun |
| [زينة](https://en.wiktionary.org/wiki/%D8%B2%D9%8A%D9%86%D8%A9#Arabic) | embellishment, adornment, ornament, decoration, garnish, decor | zīna · noun |
| [لفت](https://en.wiktionary.org/wiki/%D9%84%D9%81%D8%AA#Arabic) | to bend, to crook | lafata · verb |
| [أنور](https://en.wiktionary.org/wiki/%D8%A3%D9%86%D9%88%D8%B1#Arabic) | elative degree of نَيِّر (nayyir) | ʔanwar · adj |
| [حضارة](https://en.wiktionary.org/wiki/%D8%AD%D8%B6%D8%A7%D8%B1%D8%A9#Arabic) | civilization | ḥaḍāra · noun |
| [رحم](https://en.wiktionary.org/wiki/%D8%B1%D8%AD%D9%85#Arabic) | to have mercy (upon), have compassion | raḥima · verb |
| [زائر](https://en.wiktionary.org/wiki/%D8%B2%D8%A7%D8%A6%D8%B1#Arabic) | visitor, guest, caller | zāʔir · noun |
| [شباك](https://en.wiktionary.org/wiki/%D8%B4%D8%A8%D8%A7%D9%83#Arabic) | netting, network, plaitwork | šubbāk · noun |
| [صقر](https://en.wiktionary.org/wiki/%D8%B5%D9%82%D8%B1#Arabic) | falcon | ṣaqr · noun |
| [مذهب](https://en.wiktionary.org/wiki/%D9%85%D8%B0%D9%87%D8%A8#Arabic) | going, leaving, departure | maḏhab · noun |
| [امتحان](https://en.wiktionary.org/wiki/%D8%A7%D9%85%D8%AA%D8%AD%D8%A7%D9%86#Arabic) | examination | imtiḥān · noun |
| [تقويم](https://en.wiktionary.org/wiki/%D8%AA%D9%82%D9%88%D9%8A%D9%85#Arabic) | calendar | taqwīm · noun |
| [جنسي](https://en.wiktionary.org/wiki/%D8%AC%D9%86%D8%B3%D9%8A#Arabic) | generic | jinsiyy · adj |
| [حاسوب](https://en.wiktionary.org/wiki/%D8%AD%D8%A7%D8%B3%D9%88%D8%A8#Arabic) | computer | ḥāsūb · noun |
| [حشد](https://en.wiktionary.org/wiki/%D8%AD%D8%B4%D8%AF#Arabic) | to gather, to concentrate, to mass, to assemble | ḥašada · verb |
| [حقيبة سفر](https://en.wiktionary.org/wiki/%D8%AD%D9%82%D9%8A%D8%A8%D8%A9%20%D8%B3%D9%81%D8%B1#Arabic) | portmanteau, suitcase, travel bag | ḥaqībat safar · noun |
| [حمى](https://en.wiktionary.org/wiki/%D8%AD%D9%85%D9%89#Arabic) | to protect, to defend | ḥamā · verb |
| [دوار](https://en.wiktionary.org/wiki/%D8%AF%D9%88%D8%A7%D8%B1#Arabic) | vertigo, dizziness, giddiness | duwār · noun |
| [روحاني](https://en.wiktionary.org/wiki/%D8%B1%D9%88%D8%AD%D8%A7%D9%86%D9%8A#Arabic) | alcoholic, spirituous, spiritous, vinous | rūḥāniyy · adj |
| [سرير](https://en.wiktionary.org/wiki/%D8%B3%D8%B1%D9%8A%D8%B1#Arabic) | bed, bedstead | sarīr · noun |
| [شق](https://en.wiktionary.org/wiki/%D8%B4%D9%82#Arabic) | to cut into or through (something hard or rigid, for example, a skull, a roof, and so on, or a mass, for example, a rock), to bore through; to crack, to fissure | šaqqa · verb |
| [عظم](https://en.wiktionary.org/wiki/%D8%B9%D8%B8%D9%85#Arabic) | bone | ʕaẓm · noun |
| [فرعون](https://en.wiktionary.org/wiki/%D9%81%D8%B1%D8%B9%D9%88%D9%86#Arabic) | a pharaoh (an ancient Egyptian ruler) | firʕawn · noun |
| [يهودي](https://en.wiktionary.org/wiki/%D9%8A%D9%87%D9%88%D8%AF%D9%8A#Arabic) | Jewish | yahūdiyy · adj |
| [انسحاب](https://en.wiktionary.org/wiki/%D8%A7%D9%86%D8%B3%D8%AD%D8%A7%D8%A8#Arabic) | retreat, evacuation, withdrawal | insiḥāb · noun |
| [بر](https://en.wiktionary.org/wiki/%D8%A8%D8%B1#Arabic) | land, dry land (as opposed to sea) | barr · noun |
| [تاجر](https://en.wiktionary.org/wiki/%D8%AA%D8%A7%D8%AC%D8%B1#Arabic) | merchant, trader, businessman, dealer | tājir · noun |
| [تونسي](https://en.wiktionary.org/wiki/%D8%AA%D9%88%D9%86%D8%B3%D9%8A#Arabic) | Tunisian (of, from or relating to Tunisia) | tūnusiyy · adj |
| [جنة](https://en.wiktionary.org/wiki/%D8%AC%D9%86%D8%A9#Arabic) | garden | janna · noun |
| [جوهر](https://en.wiktionary.org/wiki/%D8%AC%D9%88%D9%87%D8%B1#Arabic) | jewel(s) | jawhar · noun |
| [عجلة](https://en.wiktionary.org/wiki/%D8%B9%D8%AC%D9%84%D8%A9#Arabic) | haste, hurry, speed, speediness, celerity | ʕajala · noun |
| [عربة نقل](https://en.wiktionary.org/wiki/%D8%B9%D8%B1%D8%A8%D8%A9%20%D9%86%D9%82%D9%84#Arabic) | cart |  · noun |
| [فتنة](https://en.wiktionary.org/wiki/%D9%81%D8%AA%D9%86%D8%A9#Arabic) | trial | fitna · noun |
| [جار](https://en.wiktionary.org/wiki/%D8%AC%D8%A7%D8%B1#Arabic) | to deviate, to stray | jāra · verb |
| [حبل](https://en.wiktionary.org/wiki/%D8%AD%D8%A8%D9%84#Arabic) | a rope, a cable; a hawser; a cord; a string; a thread | ḥabl · noun |
| [حفلة استقبال](https://en.wiktionary.org/wiki/%D8%AD%D9%81%D9%84%D8%A9%20%D8%A7%D8%B3%D8%AA%D9%82%D8%A8%D8%A7%D9%84#Arabic) | reception (“social engagement”) |  · noun |
| [حكمة](https://en.wiktionary.org/wiki/%D8%AD%D9%83%D9%85%D8%A9#Arabic) | wisdom | ḥikma · noun |
| [ديك](https://en.wiktionary.org/wiki/%D8%AF%D9%8A%D9%83#Arabic) | rooster; cock | dīk · noun |
| [عداد](https://en.wiktionary.org/wiki/%D8%B9%D8%AF%D8%A7%D8%AF#Arabic) | number, amount | ʕidād · noun |
| [قميص](https://en.wiktionary.org/wiki/%D9%82%D9%85%D9%8A%D8%B5#Arabic) | a short and usually form-fitting upper-body outer garment; a sleeved top; a shirt (such as a T-shirt or a dress shirt) | qamīṣ · noun |
| [مرحلة زمنية](https://en.wiktionary.org/wiki/%D9%85%D8%B1%D8%AD%D9%84%D8%A9%20%D8%B2%D9%85%D9%86%D9%8A%D8%A9#Arabic) | period, epoch | marḥala zamniyya · noun |
| [حار](https://en.wiktionary.org/wiki/%D8%AD%D8%A7%D8%B1#Arabic) | hot, burning | ḥārr · adj |

</details>

<details><summary>Words 901–950</summary>

![[Resources/Audio/ar/Words 0901-0950.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [راتب](https://en.wiktionary.org/wiki/%D8%B1%D8%A7%D8%AA%D8%A8#Arabic) | monotonous, dull, humdrum | rātib · adj |
| [عذاب](https://en.wiktionary.org/wiki/%D8%B9%D8%B0%D8%A7%D8%A8#Arabic) | torture, torment, punishment | ʕaḏāb · noun |
| [عقاب](https://en.wiktionary.org/wiki/%D8%B9%D9%82%D8%A7%D8%A8#Arabic) | punishment, infliction of punishment | ʕiqāb · noun |
| [كبر](https://en.wiktionary.org/wiki/%D9%83%D8%A8%D8%B1#Arabic) | to be or become big | kabura · verb |
| [نوبة](https://en.wiktionary.org/wiki/%D9%86%D9%88%D8%A8%D8%A9#Arabic) | change, alteration, shift, rotation | nawba · noun |
| [جهاد](https://en.wiktionary.org/wiki/%D8%AC%D9%87%D8%A7%D8%AF#Arabic) | struggle, effort | jihād · noun |
| [ذكي](https://en.wiktionary.org/wiki/%D8%B0%D9%83%D9%8A#Arabic) | intelligent, smart | ḏakiyy · adj |
| [زلزال](https://en.wiktionary.org/wiki/%D8%B2%D9%84%D8%B2%D8%A7%D9%84#Arabic) | earthquake, seism | zalzāl · noun |
| [فرج](https://en.wiktionary.org/wiki/%D9%81%D8%B1%D8%AC#Arabic) | to open, to part, to separate | faraja · verb |
| [مشغول](https://en.wiktionary.org/wiki/%D9%85%D8%B4%D8%BA%D9%88%D9%84#Arabic) | busy | mašḡūl · adj |
| [يهود](https://en.wiktionary.org/wiki/%D9%8A%D9%87%D9%88%D8%AF#Arabic) | Jews; Jewry | yahūd · noun |
| [أنمي](https://en.wiktionary.org/wiki/%D8%A3%D9%86%D9%85%D9%8A#Arabic) | anime (Animated works that originated in Japan) | ʔanimī · noun |
| [اعتراض](https://en.wiktionary.org/wiki/%D8%A7%D8%B9%D8%AA%D8%B1%D8%A7%D8%B6#Arabic) | demure, rebuke, disagreement, reproval, censure | iʕtirāḍ · noun |
| [انتفاضة](https://en.wiktionary.org/wiki/%D8%A7%D9%86%D8%AA%D9%81%D8%A7%D8%B6%D8%A9#Arabic) | instance noun of اِنْتَفَضَ (intafaḍa) | intifāḍa · noun |
| [بت](https://en.wiktionary.org/wiki/%D8%A8%D8%AA#Arabic) | to cut off, to sever | batta · verb |
| [شبح](https://en.wiktionary.org/wiki/%D8%B4%D8%A8%D8%AD#Arabic) | specter, ghost, apparition, phantom, spirit | šabaḥ · noun |
| [عشاء](https://en.wiktionary.org/wiki/%D8%B9%D8%B4%D8%A7%D8%A1#Arabic) | supper, dinner | ʕašāʔ · noun |
| [مار](https://en.wiktionary.org/wiki/%D9%85%D8%A7%D8%B1#Arabic) | Lord; Saint; Mar (honorific title for a man of religion, most often a saint) | mār · noun |
| [نقطة مزدوجة](https://en.wiktionary.org/wiki/%D9%86%D9%82%D8%B7%D8%A9%20%D9%85%D8%B2%D8%AF%D9%88%D8%AC%D8%A9#Arabic) | colon, " : " | nuqṭa muzdawija · noun |
| [هواء](https://en.wiktionary.org/wiki/%D9%87%D9%88%D8%A7%D8%A1#Arabic) | air | hawāʔ · noun |
| [خبز](https://en.wiktionary.org/wiki/%D8%AE%D8%A8%D8%B2#Arabic) | to bake | ḵabaza · verb |
| [سلك](https://en.wiktionary.org/wiki/%D8%B3%D9%84%D9%83#Arabic) | to follow a road, to wend, to travel along | salaka · verb |
| [فقير](https://en.wiktionary.org/wiki/%D9%81%D9%82%D9%8A%D8%B1#Arabic) | penniless, poverty-stricken | faqīr · adj |
| [كره](https://en.wiktionary.org/wiki/%D9%83%D8%B1%D9%87#Arabic) | to hate, to dislike, to detest, to loathe, to abhor | kariha · verb |
| [مناخ](https://en.wiktionary.org/wiki/%D9%85%D9%86%D8%A7%D8%AE#Arabic) | climate (“long term atmospheric conditions”) | munāḵ · noun |
| [منطق](https://en.wiktionary.org/wiki/%D9%85%D9%86%D8%B7%D9%82#Arabic) | logic, dialectic | manṭiq · noun |
| [آت](https://en.wiktionary.org/wiki/%D8%A2%D8%AA#Arabic) | coming, next | ʔātin · adj |
| [تحليل رياضي](https://en.wiktionary.org/wiki/%D8%AA%D8%AD%D9%84%D9%8A%D9%84%20%D8%B1%D9%8A%D8%A7%D8%B6%D9%8A#Arabic) | mathematical analysis | taḥlīl riyāḍiyy · noun |
| [جواب](https://en.wiktionary.org/wiki/%D8%AC%D9%88%D8%A7%D8%A8#Arabic) | answer, reply | jawāb · noun |
| [رابع](https://en.wiktionary.org/wiki/%D8%B1%D8%A7%D8%A8%D8%B9#Arabic) | fourth | rābiʕ · adj |
| [شقق](https://en.wiktionary.org/wiki/%D8%B4%D9%82%D9%82#Arabic) | to split, to tear open | šaqqaqa · verb |
| [عملاق](https://en.wiktionary.org/wiki/%D8%B9%D9%85%D9%84%D8%A7%D9%82#Arabic) | huge, giant, gigantic, mammoth | ʕimlāq · adj |
| [مدونة إلكترونية](https://en.wiktionary.org/wiki/%D9%85%D8%AF%D9%88%D9%86%D8%A9%20%D8%A5%D9%84%D9%83%D8%AA%D8%B1%D9%88%D9%86%D9%8A%D8%A9#Arabic) | blog | mudawwana ʔiliktrūniyya · noun |
| [نام](https://en.wiktionary.org/wiki/%D9%86%D8%A7%D9%85#Arabic) | to sleep | nāma · verb |
| [هن](https://en.wiktionary.org/wiki/%D9%87%D9%86#Arabic) | they (feminine plural subject pronoun) | hunna · pron |
| [هند](https://en.wiktionary.org/wiki/%D9%87%D9%86%D8%AF#Arabic) | to hoot like an owl | hannada · verb |
| [راية](https://en.wiktionary.org/wiki/%D8%B1%D8%A7%D9%8A%D8%A9#Arabic) | banner, ensign, an army's battle standard | rāya · noun |
| [عجل](https://en.wiktionary.org/wiki/%D8%B9%D8%AC%D9%84#Arabic) | calf (young head of cattle) | ʕijl · noun |
| [عجوز](https://en.wiktionary.org/wiki/%D8%B9%D8%AC%D9%88%D8%B2#Arabic) | old woman | ʕajūz · noun |
| [عديد](https://en.wiktionary.org/wiki/%D8%B9%D8%AF%D9%8A%D8%AF#Arabic) | numerous, many | ʕadīd · adj |
| [علية القوم](https://en.wiktionary.org/wiki/%D8%B9%D9%84%D9%8A%D8%A9%20%D8%A7%D9%84%D9%82%D9%88%D9%85#Arabic) | upper class, elite, prominent people, VIPs | ʕilyat al-qawm · noun |
| [قرص](https://en.wiktionary.org/wiki/%D9%82%D8%B1%D8%B5#Arabic) | to pinch | qaraṣa · verb |
| [وصفة](https://en.wiktionary.org/wiki/%D9%88%D8%B5%D9%81%D8%A9#Arabic) | prescription | waṣfa · noun |
| [خيانة](https://en.wiktionary.org/wiki/%D8%AE%D9%8A%D8%A7%D9%86%D8%A9#Arabic) | faithlessness, falseness, disloyalty, treachery, perfidy | ḵiyāna · noun |
| [دبلوماسي](https://en.wiktionary.org/wiki/%D8%AF%D8%A8%D9%84%D9%88%D9%85%D8%A7%D8%B3%D9%8A#Arabic) | diplomatic | diblūmāsiyy · adj |
| [شبح ظل](https://en.wiktionary.org/wiki/%D8%B4%D8%A8%D8%AD%20%D8%B8%D9%84#Arabic) | spirit of shadow | šabaḥ ẓill · noun |
| [عطر](https://en.wiktionary.org/wiki/%D8%B9%D8%B7%D8%B1#Arabic) | perfume, scent | ʕiṭr · noun |
| [فخور](https://en.wiktionary.org/wiki/%D9%81%D8%AE%D9%88%D8%B1#Arabic) | proud | faḵūr · adj |
| [فلسفة](https://en.wiktionary.org/wiki/%D9%81%D9%84%D8%B3%D9%81%D8%A9#Arabic) | philosophy | falsafa · noun |
| [باع](https://en.wiktionary.org/wiki/%D8%A8%D8%A7%D8%B9#Arabic) | to sell (to agree to transfer goods or provide services) | bāʕa · verb |

</details>

<details><summary>Words 951–1000</summary>

![[Resources/Audio/ar/Words 0951-1000.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [حفرة](https://en.wiktionary.org/wiki/%D8%AD%D9%81%D8%B1%D8%A9#Arabic) | hole | ḥufra · noun |
| [خلت](https://en.wiktionary.org/wiki/%D8%AE%D9%84%D8%AA#Arabic) | ago | ḵilt · particle |
| [عسل](https://en.wiktionary.org/wiki/%D8%B9%D8%B3%D9%84#Arabic) | to move, to vibrate, to shake | ʕasala · verb |
| [فلك](https://en.wiktionary.org/wiki/%D9%81%D9%84%D9%83#Arabic) | orbit, rounded course | falak · noun |
| [كثافة](https://en.wiktionary.org/wiki/%D9%83%D8%AB%D8%A7%D9%81%D8%A9#Arabic) | density, thickness | kaṯāfa · noun |
| [مزدوج](https://en.wiktionary.org/wiki/%D9%85%D8%B2%D8%AF%D9%88%D8%AC#Arabic) | double, twofold, two- | muzdawij · adj |
| [مفصل](https://en.wiktionary.org/wiki/%D9%85%D9%81%D8%B5%D9%84#Arabic) | knuckle | mafṣil · noun |
| [نمر](https://en.wiktionary.org/wiki/%D9%86%D9%85%D8%B1#Arabic) | tiger | namir · noun |
| [وردة](https://en.wiktionary.org/wiki/%D9%88%D8%B1%D8%AF%D8%A9#Arabic) | an imitation of a rose used for decoration, such as a rosette or cockade | warda · noun |
| [ياسمين](https://en.wiktionary.org/wiki/%D9%8A%D8%A7%D8%B3%D9%85%D9%8A%D9%86#Arabic) | jasmine | yāsamīn · noun |
| [يلا](https://en.wiktionary.org/wiki/%D9%8A%D9%84%D8%A7#Arabic) | come on, c’mon | yallā · intj |
| [اسود](https://en.wiktionary.org/wiki/%D8%A7%D8%B3%D9%88%D8%AF#Arabic) | to become black, to blacken | iswadda · verb |
| [باز](https://en.wiktionary.org/wiki/%D8%A8%D8%A7%D8%B2#Arabic) | hawk | bāz · noun |
| [تولد](https://en.wiktionary.org/wiki/%D8%AA%D9%88%D9%84%D8%AF#Arabic) | to be born, to originate | tawallada · verb |
| [دجاج](https://en.wiktionary.org/wiki/%D8%AF%D8%AC%D8%A7%D8%AC#Arabic) | chickens, poultry, fowl | basilectal · noun |
| [فرحة](https://en.wiktionary.org/wiki/%D9%81%D8%B1%D8%AD%D8%A9#Arabic) | joy, mirth, cheerfulness | farḥa · noun |
| [فم](https://en.wiktionary.org/wiki/%D9%81%D9%85#Arabic) | mouth | fam · noun |
| [معجزة](https://en.wiktionary.org/wiki/%D9%85%D8%B9%D8%AC%D8%B2%D8%A9#Arabic) | miracle | muʕjiza · noun |
| [حلال](https://en.wiktionary.org/wiki/%D8%AD%D9%84%D8%A7%D9%84#Arabic) | allowed, permitted, allowable, admissible, permissible. | ḥalāl · adj |
| [رحب](https://en.wiktionary.org/wiki/%D8%B1%D8%AD%D8%A8#Arabic) | to be wide, to be spacious, to be roomy | raḥiba · verb |
| [صيام](https://en.wiktionary.org/wiki/%D8%B5%D9%8A%D8%A7%D9%85#Arabic) | fast, sawm (period of abstainment, usually from food and drink) | ṣiyām · noun |
| [عشرون](https://en.wiktionary.org/wiki/%D8%B9%D8%B4%D8%B1%D9%88%D9%86#Arabic) | twenty | ʕišrūna · num |
| [فر](https://en.wiktionary.org/wiki/%D9%81%D8%B1#Arabic) | to flee, to run away, to run off, to escape | farra · verb |
| [ابتعد](https://en.wiktionary.org/wiki/%D8%A7%D8%A8%D8%AA%D8%B9%D8%AF#Arabic) | to move away from, to distance oneself from | ibtaʕada · verb |
| [اشترى](https://en.wiktionary.org/wiki/%D8%A7%D8%B4%D8%AA%D8%B1%D9%89#Arabic) | to buy, to purchase | ištarā · verb |
| [بسم الله الرحمن الرحيم](https://en.wiktionary.org/wiki/%D8%A8%D8%B3%D9%85%20%D8%A7%D9%84%D9%84%D9%87%20%D8%A7%D9%84%D8%B1%D8%AD%D9%85%D9%86%20%D8%A7%D9%84%D8%B1%D8%AD%D9%8A%D9%85#Arabic) | "In the name of God, the Most Merciful, the Most Compassionate"; basmala; ﷽ | bi-smi llāhi r-raḥmāni r-raḥīmi · phrase |
| [ترجم](https://en.wiktionary.org/wiki/%D8%AA%D8%B1%D8%AC%D9%85#Arabic) | to translate | tarjama · verb |
| [تعب](https://en.wiktionary.org/wiki/%D8%AA%D8%B9%D8%A8#Arabic) | to get tired, to wear oneself out | taʕiba · verb |
| [ثان](https://en.wiktionary.org/wiki/%D8%AB%D8%A7%D9%86#Arabic) | second | ṯānin · adj |
| [حالا](https://en.wiktionary.org/wiki/%D8%AD%D8%A7%D9%84%D8%A7#Arabic) | presently, immediately, at once, right away, without delay | ḥālan · adv |
| [عرق](https://en.wiktionary.org/wiki/%D8%B9%D8%B1%D9%82#Arabic) | to strip of flesh, to nibble | ʕaraqa · verb |
| [عفو](https://en.wiktionary.org/wiki/%D8%B9%D9%81%D9%88#Arabic) | pardon, forgiveness, remission of sins, amnesty, absolution | ʕafw · noun |
| [فتوى](https://en.wiktionary.org/wiki/%D9%81%D8%AA%D9%88%D9%89#Arabic) | fatwa, formal legal opinion | fatwā · noun |
| [معلقة](https://en.wiktionary.org/wiki/%D9%85%D8%B9%D9%84%D9%82%D8%A9#Arabic) | poster, placard | muʕallaqa · noun |
| [ميزان](https://en.wiktionary.org/wiki/%D9%85%D9%8A%D8%B2%D8%A7%D9%86#Arabic) | balance | mīzān · noun |
| [نبيه](https://en.wiktionary.org/wiki/%D9%86%D8%A8%D9%8A%D9%87#Arabic) | righteous, more righteous, patrician, more upright, nobler | nabīh · adj |
| [تبع](https://en.wiktionary.org/wiki/%D8%AA%D8%A8%D8%B9#Arabic) | to follow, to succeed, to come after in a sequence | tabiʕa · verb |
| [خشب](https://en.wiktionary.org/wiki/%D8%AE%D8%B4%D8%A8#Arabic) | wood, lumber, timber | ḵašab · noun |
| [خلاص](https://en.wiktionary.org/wiki/%D8%AE%D9%84%D8%A7%D8%B5#Arabic) | liberation, deliverance, riddance | ḵalāṣ · noun |
| [سرور](https://en.wiktionary.org/wiki/%D8%B3%D8%B1%D9%88%D8%B1#Arabic) | joy, pleasure, satisfaction | surūr · noun |
| [عشوائي](https://en.wiktionary.org/wiki/%D8%B9%D8%B4%D9%88%D8%A7%D8%A6%D9%8A#Arabic) | random, stochastic | ʕašwāʔiyy · adj |
| [نقود](https://en.wiktionary.org/wiki/%D9%86%D9%82%D9%88%D8%AF#Arabic) | cash, ready money | nuqūd · noun |
| [إعجاب](https://en.wiktionary.org/wiki/%D8%A5%D8%B9%D8%AC%D8%A7%D8%A8#Arabic) | admiration | ʔiʕjāb · noun |
| [بقعة](https://en.wiktionary.org/wiki/%D8%A8%D9%82%D8%B9%D8%A9#Arabic) | spot, stain, smudge | buqʕa · noun |
| [ذراع](https://en.wiktionary.org/wiki/%D8%B0%D8%B1%D8%A7%D8%B9#Arabic) | the limb of any animal, an arm or leg | ḏirāʕ · noun |
| [سرد](https://en.wiktionary.org/wiki/%D8%B3%D8%B1%D8%AF#Arabic) | to arrange one after the other | sarada · verb |
| [سود](https://en.wiktionary.org/wiki/%D8%B3%D9%88%D8%AF#Arabic) | to be black | sawida · verb |
| [عروس](https://en.wiktionary.org/wiki/%D8%B9%D8%B1%D9%88%D8%B3#Arabic) | bridegroom | ʕarūs · noun |
| [كعب](https://en.wiktionary.org/wiki/%D9%83%D8%B9%D8%A8#Arabic) | to be full and round, to be swelling (of the breasts) | kaʕaba · verb |
| [مفردات](https://en.wiktionary.org/wiki/%D9%85%D9%81%D8%B1%D8%AF%D8%A7%D8%AA) | vocabulary |  · noun |

</details>

## Question bank

Try before opening the answers. Different tasks use the same sentence to practise complementary skills. Open translation and explanation tasks can have valid alternatives.

### Independent pronouns · 50 questions

**ar-Q0001 · Fill the gap**

____ آسف، ولكن هذا لم يعد متاحاً.

I'm sorry, but it's no longer available.

[[Arabic#^ar-Q0001-answer|Compare the answer]]
^ar-Q0001

**ar-Q0002 · Choose the form**

____ آسف، ولكن هذا لم يعد متاحاً.

I'm sorry, but it's no longer available.

Choices: هو / أنا / أنت / هي

[[Arabic#^ar-Q0002-answer|Compare the answer]]
^ar-Q0002

**ar-Q0003 · Edit the changed sentence**

【أنت】 أعرف أين يعمل توم.

I know where Tom works.

[[Arabic#^ar-Q0003-answer|Compare the answer]]
^ar-Q0003

**ar-Q0004 · Build the sentence**

Arrange: أين / يعمل / توم. / أعرف / أنا

I know where Tom works.

[[Arabic#^ar-Q0004-answer|Compare the answer]]
^ar-Q0004

**ar-Q0005 · Write a translation**

Write this in Arabic: I'm eating an apple.

[[Arabic#^ar-Q0005-answer|Compare the answer]]
^ar-Q0005

**ar-Q0006 · Explain the grammar**

【أنا】 آكل تفاحةً.

I'm eating an apple.

[[Arabic#^ar-Q0006-answer|Compare the answer]]
^ar-Q0006

**ar-Q0007 · Fill the gap**

____ في الطابق الثامن

We are on the eighth floor.

[[Arabic#^ar-Q0007-answer|Compare the answer]]
^ar-Q0007

**ar-Q0008 · Choose the form**

____ في الطابق الثامن

We are on the eighth floor.

Choices: هو / نحن / أنت / أنا

[[Arabic#^ar-Q0008-answer|Compare the answer]]
^ar-Q0008

**ar-Q0009 · Edit the changed sentence**

هذا بسببك 【أنا】.

This is because of you.

[[Arabic#^ar-Q0009-answer|Compare the answer]]
^ar-Q0009

**ar-Q0010 · Build the sentence**

Arrange: بسببك / أنت. / هذا

This is because of you.

[[Arabic#^ar-Q0010-answer|Compare the answer]]
^ar-Q0010

**ar-Q0011 · Write a translation**

Write this in Arabic: She doesn't want me to speak about this matter.

[[Arabic#^ar-Q0011-answer|Compare the answer]]
^ar-Q0011

**ar-Q0012 · Explain the grammar**

【هي】 لا تريدني أن أتحدث حول هذه المسألة.

She doesn't want me to speak about this matter.

[[Arabic#^ar-Q0012-answer|Compare the answer]]
^ar-Q0012

**ar-Q0013 · Fill the gap**

لا أصدق أن توم ____ القاتل.

I don't believe that Tom is the killer.

[[Arabic#^ar-Q0013-answer|Compare the answer]]
^ar-Q0013

**ar-Q0014 · Choose the form**

لا أصدق أن توم ____ القاتل.

I don't believe that Tom is the killer.

Choices: هي / أنت / أنا / هو

[[Arabic#^ar-Q0014-answer|Compare the answer]]
^ar-Q0014

**ar-Q0015 · Edit the changed sentence**

هتف ديما: "【أنت】 ديما! ألا يعمل كاشف المتصل عندك أم ماذا؟"

"It's Dima!" Dima exclaimed. "Is your caller ID not working or something?"

[[Arabic#^ar-Q0015-answer|Compare the answer]]
^ar-Q0015

**ar-Q0016 · Build the sentence**

Arrange: المتصل / ألا / عندك / يعمل / ديما! / "أنا / هتف / ديما: / أم / كاشف / ماذا؟"

"It's Dima!" Dima exclaimed. "Is your caller ID not working or something?"

[[Arabic#^ar-Q0016-answer|Compare the answer]]
^ar-Q0016

**ar-Q0017 · Write a translation**

Write this in Arabic: I'm looking forward to spending time with my family.

[[Arabic#^ar-Q0017-answer|Compare the answer]]
^ar-Q0017

**ar-Q0018 · Explain the grammar**

【أنا】 أتتطلع لقضاء وقت مع عائلتي.

I'm looking forward to spending time with my family.

[[Arabic#^ar-Q0018-answer|Compare the answer]]
^ar-Q0018

**ar-Q0019 · Fill the gap**

____ نتعلم العربي

We learn Arabic.

[[Arabic#^ar-Q0019-answer|Compare the answer]]
^ar-Q0019

**ar-Q0020 · Choose the form**

____ نتعلم العربي

We learn Arabic.

Choices: نحن / أنا / أنت / هو

[[Arabic#^ar-Q0020-answer|Compare the answer]]
^ar-Q0020

**ar-Q0021 · Edit the changed sentence**

【أنا】 في الخدمة.

He is on duty.

[[Arabic#^ar-Q0021-answer|Compare the answer]]
^ar-Q0021

**ar-Q0022 · Build the sentence**

Arrange: هو / الخدمة. / في

He is on duty.

[[Arabic#^ar-Q0022-answer|Compare the answer]]
^ar-Q0022

**ar-Q0023 · Write a translation**

Write this in Arabic: You and I make a good team.

[[Arabic#^ar-Q0023-answer|Compare the answer]]
^ar-Q0023

**ar-Q0024 · Explain the grammar**

【أنا】 وأنت نشكل فريقا جيدا.

You and I make a good team.

[[Arabic#^ar-Q0024-answer|Compare the answer]]
^ar-Q0024

**ar-Q0025 · Fill the gap**

____ أحبّها كأخت.

I love her like a sister.

[[Arabic#^ar-Q0025-answer|Compare the answer]]
^ar-Q0025

**ar-Q0026 · Choose the form**

____ أحبّها كأخت.

I love her like a sister.

Choices: أنا / هو / أنت / هي

[[Arabic#^ar-Q0026-answer|Compare the answer]]
^ar-Q0026

**ar-Q0027 · Edit the changed sentence**

【أنت】 أشعر بالعطش.

I'm thirsty.

[[Arabic#^ar-Q0027-answer|Compare the answer]]
^ar-Q0027

**ar-Q0028 · Build the sentence**

Arrange: بالعطش. / أنا / أشعر

I'm thirsty.

[[Arabic#^ar-Q0028-answer|Compare the answer]]
^ar-Q0028

**ar-Q0029 · Write a translation**

Write this in Arabic: I need medicine. Where is the pharmacy?

[[Arabic#^ar-Q0029-answer|Compare the answer]]
^ar-Q0029

**ar-Q0030 · Explain the grammar**

أحتاج لدواء. أين 【هي】 الصّيدليّة؟

I need medicine. Where is the pharmacy?

[[Arabic#^ar-Q0030-answer|Compare the answer]]
^ar-Q0030

**ar-Q0031 · Fill the gap**

____ تحب الحيوانات.

She is fond of animals.

[[Arabic#^ar-Q0031-answer|Compare the answer]]
^ar-Q0031

**ar-Q0032 · Choose the form**

____ تحب الحيوانات.

She is fond of animals.

Choices: هو / أنت / هي / أنا

[[Arabic#^ar-Q0032-answer|Compare the answer]]
^ar-Q0032

**ar-Q0033 · Edit the changed sentence**

【أنت】 أستطيع أن أعيش بدون ماء.

I can live without water.

[[Arabic#^ar-Q0033-answer|Compare the answer]]
^ar-Q0033

**ar-Q0034 · Build the sentence**

Arrange: بدون / أستطيع / ماء. / أعيش / أنا / أن

I can live without water.

[[Arabic#^ar-Q0034-answer|Compare the answer]]
^ar-Q0034

**ar-Q0035 · Write a translation**

Write this in Arabic: I'm in the bath.

[[Arabic#^ar-Q0035-answer|Compare the answer]]
^ar-Q0035

**ar-Q0036 · Explain the grammar**

【أنا】 في المغسل.

I'm in the bath.

[[Arabic#^ar-Q0036-answer|Compare the answer]]
^ar-Q0036

**ar-Q0037 · Fill the gap**

الاثنين -بالنسبة لي- ____ أكثر الأيام انشغالًا.

Monday is my busiest day.

[[Arabic#^ar-Q0037-answer|Compare the answer]]
^ar-Q0037

**ar-Q0038 · Choose the form**

الاثنين -بالنسبة لي- ____ أكثر الأيام انشغالًا.

Monday is my busiest day.

Choices: أنت / هي / هو / أنا

[[Arabic#^ar-Q0038-answer|Compare the answer]]
^ar-Q0038

**ar-Q0039 · Edit the changed sentence**

هذه 【أنا】 الساعة التي اشتريتها امس .

This is the watch I bought yesterday.

[[Arabic#^ar-Q0039-answer|Compare the answer]]
^ar-Q0039

**ar-Q0040 · Build the sentence**

Arrange: هذه / . / اشتريتها / هي / امس / الساعة / التي

This is the watch I bought yesterday.

[[Arabic#^ar-Q0040-answer|Compare the answer]]
^ar-Q0040

**ar-Q0041 · Write a translation**

Write this in Arabic: I'm the one who loves you.

[[Arabic#^ar-Q0041-answer|Compare the answer]]
^ar-Q0041

**ar-Q0042 · Explain the grammar**

【أنا】 هو الشخص الذي يحبك.

I'm the one who loves you.

[[Arabic#^ar-Q0042-answer|Compare the answer]]
^ar-Q0042

**ar-Q0043 · Fill the gap**

حقا، ____ لست غبيا.

You're really not stupid.

[[Arabic#^ar-Q0043-answer|Compare the answer]]
^ar-Q0043

**ar-Q0044 · Choose the form**

حقا، ____ لست غبيا.

You're really not stupid.

Choices: أنت / هو / هي / أنا

[[Arabic#^ar-Q0044-answer|Compare the answer]]
^ar-Q0044

**ar-Q0045 · Edit the changed sentence**

ما 【أنا】 الجزء الأهم في التعليم الجيد؟

What's the most important part of a good education?

[[Arabic#^ar-Q0045-answer|Compare the answer]]
^ar-Q0045

**ar-Q0046 · Build the sentence**

Arrange: ما / التعليم / الجزء / الجيد؟ / الأهم / هو / في

What's the most important part of a good education?

[[Arabic#^ar-Q0046-answer|Compare the answer]]
^ar-Q0046

**ar-Q0047 · Write a translation**

Write this in Arabic: You are a good student.

[[Arabic#^ar-Q0047-answer|Compare the answer]]
^ar-Q0047

**ar-Q0048 · Explain the grammar**

【أنت】 طالب جيد.

You are a good student.

[[Arabic#^ar-Q0048-answer|Compare the answer]]
^ar-Q0048

**ar-Q0049 · Fill the gap**

____ ستكون دائماً معك.

She will always be with you.

[[Arabic#^ar-Q0049-answer|Compare the answer]]
^ar-Q0049

**ar-Q0050 · Choose the form**

____ ستكون دائماً معك.

She will always be with you.

Choices: أنا / هي / أنت / هو

[[Arabic#^ar-Q0050-answer|Compare the answer]]
^ar-Q0050


### Demonstratives · 50 questions

**ar-Q0051 · Edit the changed sentence**

【هذه】 أغبى ما قُلتُه على الإطلاق.

That's the stupidest thing I've ever said.

[[Arabic#^ar-Q0051-answer|Compare the answer]]
^ar-Q0051

**ar-Q0052 · Build the sentence**

Arrange: الإطلاق. / أغبى / ما / قُلتُه / هذا / على

That's the stupidest thing I've ever said.

[[Arabic#^ar-Q0052-answer|Compare the answer]]
^ar-Q0052

**ar-Q0053 · Write a translation**

Write this in Arabic: This car has a better performance than that one.

[[Arabic#^ar-Q0053-answer|Compare the answer]]
^ar-Q0053

**ar-Q0054 · Explain the grammar**

أداء 【هذه】 السيارة أفضل من تلك.

This car has a better performance than that one.

[[Arabic#^ar-Q0054-answer|Compare the answer]]
^ar-Q0054

**ar-Q0055 · Fill the gap**

لا يعيش أحد في ____ المنزل.

Nobody lives in this house.

[[Arabic#^ar-Q0055-answer|Compare the answer]]
^ar-Q0055

**ar-Q0056 · Choose the form**

لا يعيش أحد في ____ المنزل.

Nobody lives in this house.

Choices: هذا / هذه / هؤلاء / ذلك

[[Arabic#^ar-Q0056-answer|Compare the answer]]
^ar-Q0056

**ar-Q0057 · Edit the changed sentence**

وافق سامي 【هذه】.

Sami agreed to that.

[[Arabic#^ar-Q0057-answer|Compare the answer]]
^ar-Q0057

**ar-Q0058 · Build the sentence**

Arrange: سامي / هذا. / وافق

Sami agreed to that.

[[Arabic#^ar-Q0058-answer|Compare the answer]]
^ar-Q0058

**ar-Q0059 · Write a translation**

Write this in Arabic: I can't put up with this noise.

[[Arabic#^ar-Q0059-answer|Compare the answer]]
^ar-Q0059

**ar-Q0060 · Explain the grammar**

لا أستطيع أن أتحمل 【هذا】 الصوت.

I can't put up with this noise.

[[Arabic#^ar-Q0060-answer|Compare the answer]]
^ar-Q0060

**ar-Q0061 · Fill the gap**

متأكد أن توم لن يفعل ____.

I'm sure Tom would never do that.

[[Arabic#^ar-Q0061-answer|Compare the answer]]
^ar-Q0061

**ar-Q0062 · Choose the form**

متأكد أن توم لن يفعل ____.

I'm sure Tom would never do that.

Choices: هذا / ذلك / هؤلاء / هذه

[[Arabic#^ar-Q0062-answer|Compare the answer]]
^ar-Q0062

**ar-Q0063 · Edit the changed sentence**

هل لديك أي فكرة عن من يستطيع فعل مِثل 【هذه】 الشيء؟

Do you have any idea who would do this kind of thing?

[[Arabic#^ar-Q0063-answer|Compare the answer]]
^ar-Q0063

**ar-Q0064 · Build the sentence**

Arrange: يستطيع / هل / عن / مِثل / من / الشيء؟ / فعل / فكرة / لديك / أي / هذا

Do you have any idea who would do this kind of thing?

[[Arabic#^ar-Q0064-answer|Compare the answer]]
^ar-Q0064

**ar-Q0065 · Write a translation**

Write this in Arabic: If you don't know anything about the matter, it's better that you keep quiet.

[[Arabic#^ar-Q0065-answer|Compare the answer]]
^ar-Q0065

**ar-Q0066 · Explain the grammar**

من الافضل أن تبقی صامتا إذا لم تكن تعلم شيئا عن 【هذا】 الأمر

If you don't know anything about the matter, it's better that you keep quiet.

[[Arabic#^ar-Q0066-answer|Compare the answer]]
^ar-Q0066

**ar-Q0067 · Fill the gap**

____ الطائر لا يمكنه الطيران.

This bird cannot fly.

[[Arabic#^ar-Q0067-answer|Compare the answer]]
^ar-Q0067

**ar-Q0068 · Choose the form**

____ الطائر لا يمكنه الطيران.

This bird cannot fly.

Choices: ذلك / هذا / هؤلاء / هذه

[[Arabic#^ar-Q0068-answer|Compare the answer]]
^ar-Q0068

**ar-Q0069 · Edit the changed sentence**

لا يبدو 【هذه】 عادلا إطلاقا.

That doesn't seem right at all.

[[Arabic#^ar-Q0069-answer|Compare the answer]]
^ar-Q0069

**ar-Q0070 · Build the sentence**

Arrange: إطلاقا. / لا / يبدو / هذا / عادلا

That doesn't seem right at all.

[[Arabic#^ar-Q0070-answer|Compare the answer]]
^ar-Q0070

**ar-Q0071 · Write a translation**

Write this in Arabic: This book will do.

[[Arabic#^ar-Q0071-answer|Compare the answer]]
^ar-Q0071

**ar-Q0072 · Explain the grammar**

【هذا】 الكتاب سيفي بالغرض.

This book will do.

[[Arabic#^ar-Q0072-answer|Compare the answer]]
^ar-Q0072

**ar-Q0073 · Fill the gap**

أنی لك ____ ؟

Where did you get this?

[[Arabic#^ar-Q0073-answer|Compare the answer]]
^ar-Q0073

**ar-Q0074 · Choose the form**

أنی لك ____ ؟

Where did you get this?

Choices: هذه / ذلك / هذا / هؤلاء

[[Arabic#^ar-Q0074-answer|Compare the answer]]
^ar-Q0074

**ar-Q0075 · Edit the changed sentence**

علينا عمل 【هذه】 بأنفسنا.

We have to do this by ourselves.

[[Arabic#^ar-Q0075-answer|Compare the answer]]
^ar-Q0075

**ar-Q0076 · Build the sentence**

Arrange: عمل / علينا / هذا / بأنفسنا.

We have to do this by ourselves.

[[Arabic#^ar-Q0076-answer|Compare the answer]]
^ar-Q0076

**ar-Q0077 · Write a translation**

Write this in Arabic: I just got my textbooks for this semester.

[[Arabic#^ar-Q0077-answer|Compare the answer]]
^ar-Q0077

**ar-Q0078 · Explain the grammar**

الآن حصلت على كتب 【هذا】 الفصل.

I just got my textbooks for this semester.

[[Arabic#^ar-Q0078-answer|Compare the answer]]
^ar-Q0078

**ar-Q0079 · Fill the gap**

____ صفحتي على الفيسبوك.

This is my page on Facebook.

[[Arabic#^ar-Q0079-answer|Compare the answer]]
^ar-Q0079

**ar-Q0080 · Choose the form**

____ صفحتي على الفيسبوك.

This is my page on Facebook.

Choices: هذه / هؤلاء / ذلك / هذا

[[Arabic#^ar-Q0080-answer|Compare the answer]]
^ar-Q0080

**ar-Q0081 · Edit the changed sentence**

يجب عليك فعل 【هذا】 بنفسك.

You must do it yourself.

[[Arabic#^ar-Q0081-answer|Compare the answer]]
^ar-Q0081

**ar-Q0082 · Build the sentence**

Arrange: بنفسك. / ذلك / عليك / يجب / فعل

You must do it yourself.

[[Arabic#^ar-Q0082-answer|Compare the answer]]
^ar-Q0082

**ar-Q0083 · Write a translation**

Write this in Arabic: Here's my telephone number.

[[Arabic#^ar-Q0083-answer|Compare the answer]]
^ar-Q0083

**ar-Q0084 · Explain the grammar**

【هذا】 رقم هاتفي.

Here's my telephone number.

[[Arabic#^ar-Q0084-answer|Compare the answer]]
^ar-Q0084

**ar-Q0085 · Fill the gap**

____ القاعة لا تتسع لذاك المكتب.

That desk does not fit in this room.

[[Arabic#^ar-Q0085-answer|Compare the answer]]
^ar-Q0085

**ar-Q0086 · Choose the form**

____ القاعة لا تتسع لذاك المكتب.

That desk does not fit in this room.

Choices: هؤلاء / هذا / ذلك / هذه

[[Arabic#^ar-Q0086-answer|Compare the answer]]
^ar-Q0086

**ar-Q0087 · Edit the changed sentence**

لم أكن أريد أن أفعل 【هذه】 بهذه الطريقة.

I didn't want to do it this way.

[[Arabic#^ar-Q0087-answer|Compare the answer]]
^ar-Q0087

**ar-Q0088 · Build the sentence**

Arrange: أفعل / أن / هذا / الطريقة. / بهذه / لم / أريد / أكن

I didn't want to do it this way.

[[Arabic#^ar-Q0088-answer|Compare the answer]]
^ar-Q0088

**ar-Q0089 · Write a translation**

Write this in Arabic: I got scolded severely by that teacher.

[[Arabic#^ar-Q0089-answer|Compare the answer]]
^ar-Q0089

**ar-Q0090 · Explain the grammar**

وبخني 【ذلك】 المعلم كثيرًا.

I got scolded severely by that teacher.

[[Arabic#^ar-Q0090-answer|Compare the answer]]
^ar-Q0090

**ar-Q0091 · Fill the gap**

يصعب عليّ تصديق ____.

I find it difficult to believe.

[[Arabic#^ar-Q0091-answer|Compare the answer]]
^ar-Q0091

**ar-Q0092 · Choose the form**

يصعب عليّ تصديق ____.

I find it difficult to believe.

Choices: ذلك / هؤلاء / هذا / هذه

[[Arabic#^ar-Q0092-answer|Compare the answer]]
^ar-Q0092

**ar-Q0093 · Edit the changed sentence**

【هذه】 قائمة ما نحتاج.

This is a list of what we need.

[[Arabic#^ar-Q0093-answer|Compare the answer]]
^ar-Q0093

**ar-Q0094 · Build the sentence**

Arrange: نحتاج. / هذا / قائمة / ما

This is a list of what we need.

[[Arabic#^ar-Q0094-answer|Compare the answer]]
^ar-Q0094

**ar-Q0095 · Write a translation**

Write this in Arabic: Sami didn't want to argue with that guy.

[[Arabic#^ar-Q0095-answer|Compare the answer]]
^ar-Q0095

**ar-Q0096 · Explain the grammar**

لم يرد سامي أن يتخاصم مع 【ذلك】 الرّجل.

Sami didn't want to argue with that guy.

[[Arabic#^ar-Q0096-answer|Compare the answer]]
^ar-Q0096

**ar-Q0097 · Fill the gap**

قتل ____ الرجل.

He killed that man.

[[Arabic#^ar-Q0097-answer|Compare the answer]]
^ar-Q0097

**ar-Q0098 · Choose the form**

قتل ____ الرجل.

He killed that man.

Choices: هؤلاء / هذا / ذلك / هذه

[[Arabic#^ar-Q0098-answer|Compare the answer]]
^ar-Q0098

**ar-Q0099 · Edit the changed sentence**

دائماً ما اصادف سياح يابانيين في 【هذا】 المنطقة .

We often come across Japanese tourists in this area.

[[Arabic#^ar-Q0099-answer|Compare the answer]]
^ar-Q0099

**ar-Q0100 · Build the sentence**

Arrange: دائماً / المنطقة / ما / اصادف / سياح / في / . / هذه / يابانيين

We often come across Japanese tourists in this area.

[[Arabic#^ar-Q0100-answer|Compare the answer]]
^ar-Q0100


### Definite article · 50 questions

**ar-Q0101 · Write a translation**

Write this in Arabic: Nothing's perfect.

[[Arabic#^ar-Q0101-answer|Compare the answer]]
^ar-Q0101

**ar-Q0102 · Explain the grammar**

لا شيئَ مث【الي】.

Nothing's perfect.

[[Arabic#^ar-Q0102-answer|Compare the answer]]
^ar-Q0102

**ar-Q0103 · Fill the gap**

صديق في ____ خير من اثنين على الشجرة!

A friend in hand is worth two in the bush!

[[Arabic#^ar-Q0103-answer|Compare the answer]]
^ar-Q0103

**ar-Q0104 · Choose the form**

صديق في ____ خير من اثنين على الشجرة!

A friend in hand is worth two in the bush!

Choices: اللغة / اليد / البيت / الكتاب

[[Arabic#^ar-Q0104-answer|Compare the answer]]
^ar-Q0104

**ar-Q0105 · Edit the changed sentence**

تسلّقت ليلى 【الكتاب】.

Layla climbed the ladder.

[[Arabic#^ar-Q0105-answer|Compare the answer]]
^ar-Q0105

**ar-Q0106 · Build the sentence**

Arrange: تسلّقت / السّلّم. / ليلى

Layla climbed the ladder.

[[Arabic#^ar-Q0106-answer|Compare the answer]]
^ar-Q0106

**ar-Q0107 · Write a translation**

Write this in Arabic: You put in too much pepper.

[[Arabic#^ar-Q0107-answer|Compare the answer]]
^ar-Q0107

**ar-Q0108 · Explain the grammar**

لقد أضفت فلفلاً أكثر من 【اللازم】.

You put in too much pepper.

[[Arabic#^ar-Q0108-answer|Compare the answer]]
^ar-Q0108

**ar-Q0109 · Fill the gap**

اتهمته ____ بالقتل.

The police accused him of murder.

[[Arabic#^ar-Q0109-answer|Compare the answer]]
^ar-Q0109

**ar-Q0110 · Choose the form**

اتهمته ____ بالقتل.

The police accused him of murder.

Choices: الشرطة / البيت / اللغة / الكتاب

[[Arabic#^ar-Q0110-answer|Compare the answer]]
^ar-Q0110

**ar-Q0111 · Edit the changed sentence**

دفعت ليلى بسامي إلى 【الكتاب】.

Layla pushed Sami to the wall.

[[Arabic#^ar-Q0111-answer|Compare the answer]]
^ar-Q0111

**ar-Q0112 · Build the sentence**

Arrange: ليلى / الحائط. / إلى / بسامي / دفعت

Layla pushed Sami to the wall.

[[Arabic#^ar-Q0112-answer|Compare the answer]]
^ar-Q0112

**ar-Q0113 · Write a translation**

Write this in Arabic: I have the impression that he knows the secret.

[[Arabic#^ar-Q0113-answer|Compare the answer]]
^ar-Q0113

**ar-Q0114 · Explain the grammar**

يبدوا لي أنه يعلم 【السر】

I have the impression that he knows the secret.

[[Arabic#^ar-Q0114-answer|Compare the answer]]
^ar-Q0114

**ar-Q0115 · Fill the gap**

يبدو ____ الأحمر جميلاً عليك.

That red sweater looks good on you.

[[Arabic#^ar-Q0115-answer|Compare the answer]]
^ar-Q0115

**ar-Q0116 · Choose the form**

يبدو ____ الأحمر جميلاً عليك.

That red sweater looks good on you.

Choices: البيت / اللغة / الكتاب / المعطف

[[Arabic#^ar-Q0116-answer|Compare the answer]]
^ar-Q0116

**ar-Q0117 · Edit the changed sentence**

حتى لو سارت 【الكتاب】 على ما يرام، ما زلنا غير قادرين على الانتهاء قبل السبت.

Even if all goes well, we still can't finish before Saturday.

[[Arabic#^ar-Q0117-answer|Compare the answer]]
^ar-Q0117

**ar-Q0118 · Build the sentence**

Arrange: حتى / قادرين / زلنا / يرام، / قبل / الأمور / ما / السبت. / ما / سارت / على / على / غير / الانتهاء / لو

Even if all goes well, we still can't finish before Saturday.

[[Arabic#^ar-Q0118-answer|Compare the answer]]
^ar-Q0118

**ar-Q0119 · Write a translation**

Write this in Arabic: Everyone has both strong and weak points.

[[Arabic#^ar-Q0119-answer|Compare the answer]]
^ar-Q0119

**ar-Q0120 · Explain the grammar**

كل شخص لديه كلاً من نقاط 【الضعف】 والقوة.

Everyone has both strong and weak points.

[[Arabic#^ar-Q0120-answer|Compare the answer]]
^ar-Q0120

**ar-Q0121 · Fill the gap**

كلفونا بهذا ____.

They assigned the task to us.

[[Arabic#^ar-Q0121-answer|Compare the answer]]
^ar-Q0121

**ar-Q0122 · Choose the form**

كلفونا بهذا ____.

They assigned the task to us.

Choices: اللغة / العمل / الكتاب / البيت

[[Arabic#^ar-Q0122-answer|Compare the answer]]
^ar-Q0122

**ar-Q0123 · Edit the changed sentence**

يمكنك فتح 【الكتاب】.

You may open the window.

[[Arabic#^ar-Q0123-answer|Compare the answer]]
^ar-Q0123

**ar-Q0124 · Build the sentence**

Arrange: يمكنك / النافذة. / فتح

You may open the window.

[[Arabic#^ar-Q0124-answer|Compare the answer]]
^ar-Q0124

**ar-Q0125 · Write a translation**

Write this in Arabic: Many people don't know that antibiotics are ineffective against viral diseases.

[[Arabic#^ar-Q0125-answer|Compare the answer]]
^ar-Q0125

**ar-Q0126 · Explain the grammar**

【الكثير】 من الناس يجهلون أن المضادات الحيوية ليست لديها تأثير على الأمراض الفيروسية.

Many people don't know that antibiotics are ineffective against viral diseases.

[[Arabic#^ar-Q0126-answer|Compare the answer]]
^ar-Q0126

**ar-Q0127 · Fill the gap**

وضع سامي جثة ليلى في قعر ____

Sami placed Layla's body on the bottom of the boat.

[[Arabic#^ar-Q0127-answer|Compare the answer]]
^ar-Q0127

**ar-Q0128 · Choose the form**

وضع سامي جثة ليلى في قعر ____

Sami placed Layla's body on the bottom of the boat.

Choices: القارب / البيت / الكتاب / اللغة

[[Arabic#^ar-Q0128-answer|Compare the answer]]
^ar-Q0128

**ar-Q0129 · Edit the changed sentence**

في سبتمبر/أيلول، توجد كثير من قناديل 【الكتاب】 في المحيط.

There are lots of jellyfish in the ocean in September.

[[Arabic#^ar-Q0129-answer|Compare the answer]]
^ar-Q0129

**ar-Q0130 · Build the sentence**

Arrange: من / البحر / في / قناديل / سبتمبر/أيلول، / في / كثير / توجد / المحيط.

There are lots of jellyfish in the ocean in September.

[[Arabic#^ar-Q0130-answer|Compare the answer]]
^ar-Q0130

**ar-Q0131 · Write a translation**

Write this in Arabic: Most people don't drink enough water.

[[Arabic#^ar-Q0131-answer|Compare the answer]]
^ar-Q0131

**ar-Q0132 · Explain the grammar**

لا يشرب أغلب 【الناس】 ما يكفيهم من المياه.

Most people don't drink enough water.

[[Arabic#^ar-Q0132-answer|Compare the answer]]
^ar-Q0132

**ar-Q0133 · Fill the gap**

تناول سامي بعض ____ النّوم.

Sami took some sleeping pills.

[[Arabic#^ar-Q0133-answer|Compare the answer]]
^ar-Q0133

**ar-Q0134 · Choose the form**

تناول سامي بعض ____ النّوم.

Sami took some sleeping pills.

Choices: اللغة / البيت / الكتاب / الأقراص

[[Arabic#^ar-Q0134-answer|Compare the answer]]
^ar-Q0134

**ar-Q0135 · Edit the changed sentence**

فكّر سامي أنّه ربّما لهذا 【الكتاب】 علاقة بوفاة ليلى.

Sami thought maybe this had something to do with Layla's death.

[[Arabic#^ar-Q0135-answer|Compare the answer]]
^ar-Q0135

**ar-Q0136 · Build the sentence**

Arrange: علاقة / لهذا / سامي / ليلى. / بوفاة / ربّما / أنّه / فكّر / الأمر

Sami thought maybe this had something to do with Layla's death.

[[Arabic#^ar-Q0136-answer|Compare the answer]]
^ar-Q0136

**ar-Q0137 · Write a translation**

Write this in Arabic: Sami was murdered by Farid's best friend, Rami.

[[Arabic#^ar-Q0137-answer|Compare the answer]]
^ar-Q0137

**ar-Q0138 · Explain the grammar**

قُتِلَ سامي من طرف صديق فريد 【المقرّب】، رامي.

Sami was murdered by Farid's best friend, Rami.

[[Arabic#^ar-Q0138-answer|Compare the answer]]
^ar-Q0138

**ar-Q0139 · Fill the gap**

لا تستطيع ليلى ____ بذلك.

Layla can't tell.

[[Arabic#^ar-Q0139-answer|Compare the answer]]
^ar-Q0139

**ar-Q0140 · Choose the form**

لا تستطيع ليلى ____ بذلك.

Layla can't tell.

Choices: الكتاب / البيت / اللغة / الإخبار

[[Arabic#^ar-Q0140-answer|Compare the answer]]
^ar-Q0140

**ar-Q0141 · Edit the changed sentence**

تعتبر 【الكتاب】 الدولة الرائدة عالميا في صناعة التكنولوجيا المتقدمة.

Japan is the leader of the world's high-tech industry.

[[Arabic#^ar-Q0141-answer|Compare the answer]]
^ar-Q0141

**ar-Q0142 · Build the sentence**

Arrange: صناعة / التكنولوجيا / الدولة / اليابان / عالميا / تعتبر / المتقدمة. / في / الرائدة

Japan is the leader of the world's high-tech industry.

[[Arabic#^ar-Q0142-answer|Compare the answer]]
^ar-Q0142

**ar-Q0143 · Write a translation**

Write this in Arabic: Jamal always lies his way out.

[[Arabic#^ar-Q0143-answer|Compare the answer]]
^ar-Q0143

**ar-Q0144 · Explain the grammar**

دائما ما يكذب جمال ليخرج نفسه من 【المواقف】 الصعبة.

Jamal always lies his way out.

[[Arabic#^ar-Q0144-answer|Compare the answer]]
^ar-Q0144

**ar-Q0145 · Fill the gap**

قاس طول ____.

He measured the length of the bed.

[[Arabic#^ar-Q0145-answer|Compare the answer]]
^ar-Q0145

**ar-Q0146 · Choose the form**

قاس طول ____.

He measured the length of the bed.

Choices: الكتاب / اللغة / البيت / السرير

[[Arabic#^ar-Q0146-answer|Compare the answer]]
^ar-Q0146

**ar-Q0147 · Edit the changed sentence**

كان فاضل يريد أن يتحكّم في 【الكتاب】.

Fadil wanted to control everybody.

[[Arabic#^ar-Q0147-answer|Compare the answer]]
^ar-Q0147

**ar-Q0148 · Build the sentence**

Arrange: يريد / الجميع. / يتحكّم / أن / في / فاضل / كان

Fadil wanted to control everybody.

[[Arabic#^ar-Q0148-answer|Compare the answer]]
^ar-Q0148

**ar-Q0149 · Write a translation**

Write this in Arabic: Sami was climbing the ladder.

[[Arabic#^ar-Q0149-answer|Compare the answer]]
^ar-Q0149

**ar-Q0150 · Explain the grammar**

كان سامي يتسلّق 【السّلّم】.

Sami was climbing the ladder.

[[Arabic#^ar-Q0150-answer|Compare the answer]]
^ar-Q0150


### Adjective and noun agreement · 50 questions

**ar-Q0151 · Fill the gap**

ذكر تقرير ____ أن احتمال أن تواجه الفتيات سوء التغذية والفقرَ والعنف والحرمان من التعليم أكثرُ من الأولاد.

Girls are more likely than boys to be malnourished, suffer poverty, face violence and be refused an education, according to a new report.

[[Arabic#^ar-Q0151-answer|Compare the answer]]
^ar-Q0151

**ar-Q0152 · Choose the form**

ذكر تقرير ____ أن احتمال أن تواجه الفتيات سوء التغذية والفقرَ والعنف والحرمان من التعليم أكثرُ من الأولاد.

Girls are more likely than boys to be malnourished, suffer poverty, face violence and be refused an education, according to a new report.

Choices: جديد / جيد / جيدة / جديدة

[[Arabic#^ar-Q0152-answer|Compare the answer]]
^ar-Q0152

**ar-Q0153 · Edit the changed sentence**

يريد الناس استخدام التقنية ال【جيد】 التي توفرت.

People want to use the new technology which is available.

[[Arabic#^ar-Q0153-answer|Compare the answer]]
^ar-Q0153

**ar-Q0154 · Build the sentence**

Arrange: يريد / استخدام / توفرت. / التقنية / التي / الجديد / الناس

People want to use the new technology which is available.

[[Arabic#^ar-Q0154-answer|Compare the answer]]
^ar-Q0154

**ar-Q0155 · Write a translation**

Write this in Arabic: You are a good customer.

[[Arabic#^ar-Q0155-answer|Compare the answer]]
^ar-Q0155

**ar-Q0156 · Explain the grammar**

أنت مشتر 【جيد】.

You are a good customer.

[[Arabic#^ar-Q0156-answer|Compare the answer]]
^ar-Q0156

**ar-Q0157 · Fill the gap**

أنا متأكد أني سأجد هدية ____ة لتوم.

I'm sure I'll find a good gift for Tom.

[[Arabic#^ar-Q0157-answer|Compare the answer]]
^ar-Q0157

**ar-Q0158 · Choose the form**

أنا متأكد أني سأجد هدية ____ة لتوم.

I'm sure I'll find a good gift for Tom.

Choices: جديد / جديدة / جيد / جيدة

[[Arabic#^ar-Q0158-answer|Compare the answer]]
^ar-Q0158

**ar-Q0159 · Edit the changed sentence**

لدى سامي غسّالة أطباق 【جيد】ة.

Sami has a new dishwasher.

[[Arabic#^ar-Q0159-answer|Compare the answer]]
^ar-Q0159

**ar-Q0160 · Build the sentence**

Arrange: لدى / غسّالة / جديدة. / سامي / أطباق

Sami has a new dishwasher.

[[Arabic#^ar-Q0160-answer|Compare the answer]]
^ar-Q0160

**ar-Q0161 · Write a translation**

Write this in Arabic: John has been collecting stamps since he was a child.

[[Arabic#^ar-Q0161-answer|Compare the answer]]
^ar-Q0161

**ar-Q0162 · Explain the grammar**

كان جون يجمع الطوابع مذ كان 【صغير】ًا.

John has been collecting stamps since he was a child.

[[Arabic#^ar-Q0162-answer|Compare the answer]]
^ar-Q0162

**ar-Q0163 · Fill the gap**

طفلي ال____ وصل!

My new baby arrived!

[[Arabic#^ar-Q0163-answer|Compare the answer]]
^ar-Q0163

**ar-Q0164 · Choose the form**

طفلي ال____ وصل!

My new baby arrived!

Choices: جديد / جيدة / جيد / جديدة

[[Arabic#^ar-Q0164-answer|Compare the answer]]
^ar-Q0164

**ar-Q0165 · Edit the changed sentence**

أنا أطهو, ولكن لا أفعل هذا بمتعة 【جيد】ة.

I cook, but I don't do that with much pleasure.

[[Arabic#^ar-Q0165-answer|Compare the answer]]
^ar-Q0165

**ar-Q0166 · Build the sentence**

Arrange: لا / أفعل / أطهو, / كبيرة. / ولكن / بمتعة / هذا / أنا

I cook, but I don't do that with much pleasure.

[[Arabic#^ar-Q0166-answer|Compare the answer]]
^ar-Q0166

**ar-Q0167 · Write a translation**

Write this in Arabic: She rides a motorcycle well.

[[Arabic#^ar-Q0167-answer|Compare the answer]]
^ar-Q0167

**ar-Q0168 · Explain the grammar**

قيادتها للدراجة النارية 【جيد】ة.

She rides a motorcycle well.

[[Arabic#^ar-Q0168-answer|Compare the answer]]
^ar-Q0168

**ar-Q0169 · Fill the gap**

أنا راضٍ تماما ببيتي ال____.

I am very pleased with my new house.

[[Arabic#^ar-Q0169-answer|Compare the answer]]
^ar-Q0169

**ar-Q0170 · Choose the form**

أنا راضٍ تماما ببيتي ال____.

I am very pleased with my new house.

Choices: جديدة / جيد / جديد / جيدة

[[Arabic#^ar-Q0170-answer|Compare the answer]]
^ar-Q0170

**ar-Q0171 · Edit the changed sentence**

لا تكن سخيفا! فنحن أصدقاء 【جيدة】ون.

Don't be silly! We're just friends. Good friends.

[[Arabic#^ar-Q0171-answer|Compare the answer]]
^ar-Q0171

**ar-Q0172 · Build the sentence**

Arrange: تكن / فنحن / لا / سخيفا! / أصدقاء / جيدون.

Don't be silly! We're just friends. Good friends.

[[Arabic#^ar-Q0172-answer|Compare the answer]]
^ar-Q0172

**ar-Q0173 · Write a translation**

Write this in Arabic: Tom liked Mary's new hairstyle.

[[Arabic#^ar-Q0173-answer|Compare the answer]]
^ar-Q0173

**ar-Q0174 · Explain the grammar**

أحب توم تسريحة شعر ماري ال【جديد】ة.

Tom liked Mary's new hairstyle.

[[Arabic#^ar-Q0174-answer|Compare the answer]]
^ar-Q0174

**ar-Q0175 · Fill the gap**

أنا أُحب أن أُجرب لأفعل أشياء ____ة.

I love trying to do new things.

[[Arabic#^ar-Q0175-answer|Compare the answer]]
^ar-Q0175

**ar-Q0176 · Choose the form**

أنا أُحب أن أُجرب لأفعل أشياء ____ة.

I love trying to do new things.

Choices: جديدة / جديد / جيدة / جيد

[[Arabic#^ar-Q0176-answer|Compare the answer]]
^ar-Q0176

**ar-Q0177 · Edit the changed sentence**

هلّا اقترحت مكانا 【جيدة】ا لأكل الطعام الكوري؟

Can you recommend a good place to eat Korean food?

[[Arabic#^ar-Q0177-answer|Compare the answer]]
^ar-Q0177

**ar-Q0178 · Build the sentence**

Arrange: الطعام / الكوري؟ / هلّا / جيدا / لأكل / اقترحت / مكانا

Can you recommend a good place to eat Korean food?

[[Arabic#^ar-Q0178-answer|Compare the answer]]
^ar-Q0178

**ar-Q0179 · Write a translation**

Write this in Arabic: Mrs. Wood was a very good cook.

[[Arabic#^ar-Q0179-answer|Compare the answer]]
^ar-Q0179

**ar-Q0180 · Explain the grammar**

السيدة وود طباخة 【جيد】ة.

Mrs. Wood was a very good cook.

[[Arabic#^ar-Q0180-answer|Compare the answer]]
^ar-Q0180

**ar-Q0181 · Fill the gap**

لدي سيارة حمراء ____ة.

I have a new red car.

[[Arabic#^ar-Q0181-answer|Compare the answer]]
^ar-Q0181

**ar-Q0182 · Choose the form**

لدي سيارة حمراء ____ة.

I have a new red car.

Choices: جديدة / جديد / جيدة / جيد

[[Arabic#^ar-Q0182-answer|Compare the answer]]
^ar-Q0182

**ar-Q0183 · Edit the changed sentence**

اللّغة مجرّد خريطة للتّفكير و المشاعر و الذّكريات البشريّة. و مثل جميع الخرائط، فإنّ اللّغة أيقونة 【جيد】ة أصغر بمائة ألف مرّة من الشّيء الذي تمثّله.

Language is just a map of human thoughts, feelings and memories. And like all maps, language is a thumbnail image a hundred thousand times smaller than what it is trying to convey.

[[Arabic#^ar-Q0183-answer|Compare the answer]]
^ar-Q0183

**ar-Q0184 · Build the sentence**

Arrange: أصغر / مجرّد / اللّغة / الخرائط، / تمثّله. / فإنّ / مثل / مرّة / من / الذي / البشريّة. / أيقونة / الشّيء / بمائة / و / للتّفكير / المشاعر / اللّغة / الذّكريات / جميع / خريطة / و / ألف / و / صغيرة

Language is just a map of human thoughts, feelings and memories. And like all maps, language is a thumbnail image a hundred thousand times smaller than what it is trying to convey.

[[Arabic#^ar-Q0184-answer|Compare the answer]]
^ar-Q0184

**ar-Q0185 · Write a translation**

Write this in Arabic: It's very good.

[[Arabic#^ar-Q0185-answer|Compare the answer]]
^ar-Q0185

**ar-Q0186 · Explain the grammar**

هذا 【جيد】 جدا

It's very good.

[[Arabic#^ar-Q0186-answer|Compare the answer]]
^ar-Q0186

**ar-Q0187 · Fill the gap**

نريد شيئاً ____اً.

We want something new.

[[Arabic#^ar-Q0187-answer|Compare the answer]]
^ar-Q0187

**ar-Q0188 · Choose the form**

نريد شيئاً ____اً.

We want something new.

Choices: جديد / جيد / جيدة / جديدة

[[Arabic#^ar-Q0188-answer|Compare the answer]]
^ar-Q0188

**ar-Q0189 · Edit the changed sentence**

أريد أن أراك من 【جيد】.

I want to see you again.

[[Arabic#^ar-Q0189-answer|Compare the answer]]
^ar-Q0189

**ar-Q0190 · Build the sentence**

Arrange: أريد / من / أراك / جديد. / أن

I want to see you again.

[[Arabic#^ar-Q0190-answer|Compare the answer]]
^ar-Q0190

**ar-Q0191 · Write a translation**

Write this in Arabic: Fadil was a little boy with a sunny smile.

[[Arabic#^ar-Q0191-answer|Compare the answer]]
^ar-Q0191

**ar-Q0192 · Explain the grammar**

كان فاضل طفلا 【صغير】ا ذو ابتسامة مشعّة.

Fadil was a little boy with a sunny smile.

[[Arabic#^ar-Q0192-answer|Compare the answer]]
^ar-Q0192

**ar-Q0193 · Fill the gap**

توم ليس ____ للحديث مع الاطفال

Tom isn't good at talking to children.

[[Arabic#^ar-Q0193-answer|Compare the answer]]
^ar-Q0193

**ar-Q0194 · Choose the form**

توم ليس ____ للحديث مع الاطفال

Tom isn't good at talking to children.

Choices: جيد / جديدة / جيدة / جديد

[[Arabic#^ar-Q0194-answer|Compare the answer]]
^ar-Q0194

**ar-Q0195 · Edit the changed sentence**

توجد غرفة المعيشة في الطابق الأرضي من منزلي ال【جيد】 بينما غرفة النوم في الطابق الأول.

In my new house, the living room is on the ground floor and the bedroom is on the first floor.

[[Arabic#^ar-Q0195-answer|Compare the answer]]
^ar-Q0195

**ar-Q0196 · Build the sentence**

Arrange: النوم / في / الأول. / غرفة / الطابق / بينما / غرفة / توجد / منزلي / المعيشة / الأرضي / الجديد / من / في / الطابق

In my new house, the living room is on the ground floor and the bedroom is on the first floor.

[[Arabic#^ar-Q0196-answer|Compare the answer]]
^ar-Q0196

**ar-Q0197 · Write a translation**

Write this in Arabic: It's good seeing you.

[[Arabic#^ar-Q0197-answer|Compare the answer]]
^ar-Q0197

**ar-Q0198 · Explain the grammar**

من ال【جيد】 رؤيتك

It's good seeing you.

[[Arabic#^ar-Q0198-answer|Compare the answer]]
^ar-Q0198

**ar-Q0199 · Fill the gap**

يبدو ____اً، ولكن في الواقع هو فوقَ الأربعين.

He looks young, but actually he is over forty.

[[Arabic#^ar-Q0199-answer|Compare the answer]]
^ar-Q0199

**ar-Q0200 · Choose the form**

يبدو ____اً، ولكن في الواقع هو فوقَ الأربعين.

He looks young, but actually he is over forty.

Choices: جيدة / صغير / جيد / جديد

[[Arabic#^ar-Q0200-answer|Compare the answer]]
^ar-Q0200


### Possession and iḍāfa · 50 questions

**ar-Q0201 · Edit the changed sentence**

هىَ ليست 【كتابي】.

She's not my sister.

[[Arabic#^ar-Q0201-answer|Compare the answer]]
^ar-Q0201

**ar-Q0202 · Build the sentence**

Arrange: هىَ / أختي. / ليست

She's not my sister.

[[Arabic#^ar-Q0202-answer|Compare the answer]]
^ar-Q0202

**ar-Q0203 · Write a translation**

Write this in Arabic: I'm sorry Mohammed, I forgot your name!

[[Arabic#^ar-Q0203-answer|Compare the answer]]
^ar-Q0203

**ar-Q0204 · Explain the grammar**

أنا آسف يا محمد، لقد نسيت 【اسمك】!

I'm sorry Mohammed, I forgot your name!

[[Arabic#^ar-Q0204-answer|Compare the answer]]
^ar-Q0204

**ar-Q0205 · Fill the gap**

هل أستطيع أن أسألك عن ____؟

May I ask your name?

[[Arabic#^ar-Q0205-answer|Compare the answer]]
^ar-Q0205

**ar-Q0206 · Choose the form**

هل أستطيع أن أسألك عن ____؟

May I ask your name?

Choices: اسمك / بيتي / كتابك / كتابي

[[Arabic#^ar-Q0206-answer|Compare the answer]]
^ar-Q0206

**ar-Q0207 · Edit the changed sentence**

لا تنسى أن تأتي إلى 【كتابي】.

Be sure to drop in at my house.

[[Arabic#^ar-Q0207-answer|Compare the answer]]
^ar-Q0207

**ar-Q0208 · Build the sentence**

Arrange: بيتي. / لا / أن / تنسى / إلى / تأتي

Be sure to drop in at my house.

[[Arabic#^ar-Q0208-answer|Compare the answer]]
^ar-Q0208

**ar-Q0209 · Write a translation**

Write this in Arabic: My older sister often drinks tea with milk.

[[Arabic#^ar-Q0209-answer|Compare the answer]]
^ar-Q0209

**ar-Q0210 · Explain the grammar**

كثيراً ما تشرب 【أختي】 الكبرى الشاي بالحليب.

My older sister often drinks tea with milk.

[[Arabic#^ar-Q0210-answer|Compare the answer]]
^ar-Q0210

**ar-Q0211 · Fill the gap**

____ أقصر منك.

My sister is shorter than you.

[[Arabic#^ar-Q0211-answer|Compare the answer]]
^ar-Q0211

**ar-Q0212 · Choose the form**

____ أقصر منك.

My sister is shorter than you.

Choices: كتابي / أختي / بيتي / كتابك

[[Arabic#^ar-Q0212-answer|Compare the answer]]
^ar-Q0212

**ar-Q0213 · Edit the changed sentence**

【كتابي】 بارد جدا.

It's very cold in my house.

[[Arabic#^ar-Q0213-answer|Compare the answer]]
^ar-Q0213

**ar-Q0214 · Build the sentence**

Arrange: بارد / جدا. / بيتي

It's very cold in my house.

[[Arabic#^ar-Q0214-answer|Compare the answer]]
^ar-Q0214

**ar-Q0215 · Write a translation**

Write this in Arabic: Is that your new book?

[[Arabic#^ar-Q0215-answer|Compare the answer]]
^ar-Q0215

**ar-Q0216 · Explain the grammar**

أذلك 【كتابك】 الجديد؟

Is that your new book?

[[Arabic#^ar-Q0216-answer|Compare the answer]]
^ar-Q0216

**ar-Q0217 · Fill the gap**

____ ساعدني في حل واجبي.

My brother helped me with my homework.

[[Arabic#^ar-Q0217-answer|Compare the answer]]
^ar-Q0217

**ar-Q0218 · Choose the form**

____ ساعدني في حل واجبي.

My brother helped me with my homework.

Choices: بيتي / أخي / كتابك / كتابي

[[Arabic#^ar-Q0218-answer|Compare the answer]]
^ar-Q0218

**ar-Q0219 · Edit the changed sentence**

عادةً ما تشرب 【كتابي】 الكبيرة الشاي مع الحليب.

My older sister often drinks tea with milk.

[[Arabic#^ar-Q0219-answer|Compare the answer]]
^ar-Q0219

**ar-Q0220 · Build the sentence**

Arrange: الحليب. / أختي / الشاي / الكبيرة / مع / تشرب / عادةً / ما

My older sister often drinks tea with milk.

[[Arabic#^ar-Q0220-answer|Compare the answer]]
^ar-Q0220

**ar-Q0221 · Write a translation**

Write this in Arabic: I went home.

[[Arabic#^ar-Q0221-answer|Compare the answer]]
^ar-Q0221

**ar-Q0222 · Explain the grammar**

ذهبت إلى 【بيتي】.

I went home.

[[Arabic#^ar-Q0222-answer|Compare the answer]]
^ar-Q0222

**ar-Q0223 · Fill the gap**

____ سريعة التفكير.

My sister is quick-thinking.

[[Arabic#^ar-Q0223-answer|Compare the answer]]
^ar-Q0223

**ar-Q0224 · Choose the form**

____ سريعة التفكير.

My sister is quick-thinking.

Choices: أختي / كتابك / بيتي / كتابي

[[Arabic#^ar-Q0224-answer|Compare the answer]]
^ar-Q0224

**ar-Q0225 · Edit the changed sentence**

【كتابي】 الأكبر مدرس.

My older brother is a teacher.

[[Arabic#^ar-Q0225-answer|Compare the answer]]
^ar-Q0225

**ar-Q0226 · Build the sentence**

Arrange: الأكبر / مدرس. / أخي

My older brother is a teacher.

[[Arabic#^ar-Q0226-answer|Compare the answer]]
^ar-Q0226

**ar-Q0227 · Write a translation**

Write this in Arabic: She told me she knew my brother.

[[Arabic#^ar-Q0227-answer|Compare the answer]]
^ar-Q0227

**ar-Q0228 · Explain the grammar**

أخبرتني بأنها تعرف 【أخي】.

She told me she knew my brother.

[[Arabic#^ar-Q0228-answer|Compare the answer]]
^ar-Q0228

**ar-Q0229 · Fill the gap**

لم تقول هذا يا ____؟

Why do you say these things, brother?

[[Arabic#^ar-Q0229-answer|Compare the answer]]
^ar-Q0229

**ar-Q0230 · Choose the form**

لم تقول هذا يا ____؟

Why do you say these things, brother?

Choices: بيتي / أخي / كتابك / كتابي

[[Arabic#^ar-Q0230-answer|Compare the answer]]
^ar-Q0230

**ar-Q0231 · Edit the changed sentence**

【كتابي】 معروف لدى الجميع في مدرستي.

My name is known to everybody in my school.

[[Arabic#^ar-Q0231-answer|Compare the answer]]
^ar-Q0231

**ar-Q0232 · Build the sentence**

Arrange: في / الجميع / اسمي / لدى / مدرستي. / معروف

My name is known to everybody in my school.

[[Arabic#^ar-Q0232-answer|Compare the answer]]
^ar-Q0232

**ar-Q0233 · Write a translation**

Write this in Arabic: My sister made me a beautiful doll.

[[Arabic#^ar-Q0233-answer|Compare the answer]]
^ar-Q0233

**ar-Q0234 · Explain the grammar**

صنعت لي 【أختي】 دميةً جميلة.

My sister made me a beautiful doll.

[[Arabic#^ar-Q0234-answer|Compare the answer]]
^ar-Q0234

**ar-Q0235 · Fill the gap**

____ الأكبر طويل القامة حقاً، يبلغ حوالي 1.8 متر.

My elder brother is really tall, about 1.8m.

[[Arabic#^ar-Q0235-answer|Compare the answer]]
^ar-Q0235

**ar-Q0236 · Choose the form**

____ الأكبر طويل القامة حقاً، يبلغ حوالي 1.8 متر.

My elder brother is really tall, about 1.8m.

Choices: بيتي / كتابك / أخي / كتابي

[[Arabic#^ar-Q0236-answer|Compare the answer]]
^ar-Q0236

**ar-Q0237 · Edit the changed sentence**

【كتابي】 صغير لكنه قوي.

My brother is small but strong.

[[Arabic#^ar-Q0237-answer|Compare the answer]]
^ar-Q0237

**ar-Q0238 · Build the sentence**

Arrange: لكنه / صغير / قوي. / أخي

My brother is small but strong.

[[Arabic#^ar-Q0238-answer|Compare the answer]]
^ar-Q0238

**ar-Q0239 · Write a translation**

Write this in Arabic: My sister lives near Yokohama.

[[Arabic#^ar-Q0239-answer|Compare the answer]]
^ar-Q0239

**ar-Q0240 · Explain the grammar**

【أختي】 تسكن بالقرب من يوكوهاما.

My sister lives near Yokohama.

[[Arabic#^ar-Q0240-answer|Compare the answer]]
^ar-Q0240

**ar-Q0241 · Fill the gap**

بيت السيد جونسون بالقرب من ____.

Mr Johnson's house is next to my house.

[[Arabic#^ar-Q0241-answer|Compare the answer]]
^ar-Q0241

**ar-Q0242 · Choose the form**

بيت السيد جونسون بالقرب من ____.

Mr Johnson's house is next to my house.

Choices: كتابي / بيتي / كتابك

[[Arabic#^ar-Q0242-answer|Compare the answer]]
^ar-Q0242

**ar-Q0243 · Edit the changed sentence**

اكتب 【كتابي】 كاملاً

Write your name in full.

[[Arabic#^ar-Q0243-answer|Compare the answer]]
^ar-Q0243

**ar-Q0244 · Build the sentence**

Arrange: كاملاً / اكتب / اسمك

Write your name in full.

[[Arabic#^ar-Q0244-answer|Compare the answer]]
^ar-Q0244

**ar-Q0245 · Write a translation**

Write this in Arabic: Tom got into a fight with Mary's brother and got his nose broken.

[[Arabic#^ar-Q0245-answer|Compare the answer]]
^ar-Q0245

**ar-Q0246 · Explain the grammar**

تعارك توم مع 【أخي】 ماري فانكسر أنفه.

Tom got into a fight with Mary's brother and got his nose broken.

[[Arabic#^ar-Q0246-answer|Compare the answer]]
^ar-Q0246

**ar-Q0247 · Fill the gap**

ترتاد ____ الجامعة.

My sister goes to a university.

[[Arabic#^ar-Q0247-answer|Compare the answer]]
^ar-Q0247

**ar-Q0248 · Choose the form**

ترتاد ____ الجامعة.

My sister goes to a university.

Choices: كتابك / بيتي / كتابي / أختي

[[Arabic#^ar-Q0248-answer|Compare the answer]]
^ar-Q0248

**ar-Q0249 · Edit the changed sentence**

أتتني وسألتني عن 【كتابي】.

She came up to me and asked my name.

[[Arabic#^ar-Q0249-answer|Compare the answer]]
^ar-Q0249

**ar-Q0250 · Build the sentence**

Arrange: أتتني / وسألتني / اسمي. / عن

She came up to me and asked my name.

[[Arabic#^ar-Q0250-answer|Compare the answer]]
^ar-Q0250


### Past kāna · 50 questions

**ar-Q0251 · Write a translation**

Write this in Arabic: Sami wanted someone to watch over him.

[[Arabic#^ar-Q0251-answer|Compare the answer]]
^ar-Q0251

**ar-Q0252 · Explain the grammar**

【كان】 سامي يريد شخصا يعتني به.

Sami wanted someone to watch over him.

[[Arabic#^ar-Q0252-answer|Compare the answer]]
^ar-Q0252

**ar-Q0253 · Fill the gap**

____ فاضل يتمنّى أن يكون ليده ما كان عند ليلى.

Fadil wanted what Layla had.

[[Arabic#^ar-Q0253-answer|Compare the answer]]
^ar-Q0253

**ar-Q0254 · Choose the form**

____ فاضل يتمنّى أن يكون ليده ما كان عند ليلى.

Fadil wanted what Layla had.

Choices: كنت / كانت / كنا / كان

[[Arabic#^ar-Q0254-answer|Compare the answer]]
^ar-Q0254

**ar-Q0255 · Edit the changed sentence**

【كانت】 سامي يحبّ مساعدة أبي.

Sami liked helping Dad.

[[Arabic#^ar-Q0255-answer|Compare the answer]]
^ar-Q0255

**ar-Q0256 · Build the sentence**

Arrange: يحبّ / أبي. / مساعدة / كان / سامي

Sami liked helping Dad.

[[Arabic#^ar-Q0256-answer|Compare the answer]]
^ar-Q0256

**ar-Q0257 · Write a translation**

Write this in Arabic: Sami was staring.

[[Arabic#^ar-Q0257-answer|Compare the answer]]
^ar-Q0257

**ar-Q0258 · Explain the grammar**

【كان】 سامي يحدّق.

Sami was staring.

[[Arabic#^ar-Q0258-answer|Compare the answer]]
^ar-Q0258

**ar-Q0259 · Fill the gap**

توم ____ قلبه مكسور عندما مات كلبه

Tom was heartbroken when his dog died.

[[Arabic#^ar-Q0259-answer|Compare the answer]]
^ar-Q0259

**ar-Q0260 · Choose the form**

توم ____ قلبه مكسور عندما مات كلبه

Tom was heartbroken when his dog died.

Choices: كنت / كانت / كان / كنا

[[Arabic#^ar-Q0260-answer|Compare the answer]]
^ar-Q0260

**ar-Q0261 · Edit the changed sentence**

【كان】 هنا البارحة.

I came here yesterday.

[[Arabic#^ar-Q0261-answer|Compare the answer]]
^ar-Q0261

**ar-Q0262 · Build the sentence**

Arrange: هنا / كنت / البارحة.

I came here yesterday.

[[Arabic#^ar-Q0262-answer|Compare the answer]]
^ar-Q0262

**ar-Q0263 · Write a translation**

Write this in Arabic: Layla was socially isolated.

[[Arabic#^ar-Q0263-answer|Compare the answer]]
^ar-Q0263

**ar-Q0264 · Explain the grammar**

【كانت】 ليلى معزولة اجتماعيّا.

Layla was socially isolated.

[[Arabic#^ar-Q0264-answer|Compare the answer]]
^ar-Q0264

**ar-Q0265 · Fill the gap**

ولما ____ شابا عملت في المجتمعات المحلية بمدينة شيكاغو حيث وجد الكثير من المسلمين في عقيدتهم روح الكرامة والسلام

As a young man, I worked in Chicago communities where many found dignity and peace in their Muslim faith.

[[Arabic#^ar-Q0265-answer|Compare the answer]]
^ar-Q0265

**ar-Q0266 · Choose the form**

ولما ____ شابا عملت في المجتمعات المحلية بمدينة شيكاغو حيث وجد الكثير من المسلمين في عقيدتهم روح الكرامة والسلام

As a young man, I worked in Chicago communities where many found dignity and peace in their Muslim faith.

Choices: كانت / كان / كنت / كنا

[[Arabic#^ar-Q0266-answer|Compare the answer]]
^ar-Q0266

**ar-Q0267 · Edit the changed sentence**

【كان】ُ أريدُ أن أصبحَ قادرا على قراءة الشعر الأمازيغي بالأمازيغيّة.

I wanted to be able to read Berber poetry in Berber.

[[Arabic#^ar-Q0267-answer|Compare the answer]]
^ar-Q0267

**ar-Q0268 · Build the sentence**

Arrange: بالأمازيغيّة. / أن / كنتُ / على / الشعر / قراءة / أصبحَ / الأمازيغي / قادرا / أريدُ

I wanted to be able to read Berber poetry in Berber.

[[Arabic#^ar-Q0268-answer|Compare the answer]]
^ar-Q0268

**ar-Q0269 · Write a translation**

Write this in Arabic: Sami had another woman in his life.

[[Arabic#^ar-Q0269-answer|Compare the answer]]
^ar-Q0269

**ar-Q0270 · Explain the grammar**

【كان】 لدى سامي امرأة أخرى في حياته.

Sami had another woman in his life.

[[Arabic#^ar-Q0270-answer|Compare the answer]]
^ar-Q0270

**ar-Q0271 · Fill the gap**

____ على وشك أن تخرج.

She was about to go out.

[[Arabic#^ar-Q0271-answer|Compare the answer]]
^ar-Q0271

**ar-Q0272 · Choose the form**

____ على وشك أن تخرج.

She was about to go out.

Choices: كانت / كان / كنت / كنا

[[Arabic#^ar-Q0272-answer|Compare the answer]]
^ar-Q0272

**ar-Q0273 · Edit the changed sentence**

【كانت】 سامي أحمقا.

Sami was an idiot.

[[Arabic#^ar-Q0273-answer|Compare the answer]]
^ar-Q0273

**ar-Q0274 · Build the sentence**

Arrange: سامي / أحمقا. / كان

Sami was an idiot.

[[Arabic#^ar-Q0274-answer|Compare the answer]]
^ar-Q0274

**ar-Q0275 · Write a translation**

Write this in Arabic: Sami killed for greed.

[[Arabic#^ar-Q0275-answer|Compare the answer]]
^ar-Q0275

**ar-Q0276 · Explain the grammar**

【كان】 سامي يقتل جشعا.

Sami killed for greed.

[[Arabic#^ar-Q0276-answer|Compare the answer]]
^ar-Q0276

**ar-Q0277 · Fill the gap**

هل ____ تأكل الشّكلاطة؟

Have you been eating chocolate?

[[Arabic#^ar-Q0277-answer|Compare the answer]]
^ar-Q0277

**ar-Q0278 · Choose the form**

هل ____ تأكل الشّكلاطة؟

Have you been eating chocolate?

Choices: كنت / كانت / كنا / كان

[[Arabic#^ar-Q0278-answer|Compare the answer]]
^ar-Q0278

**ar-Q0279 · Edit the changed sentence**

اكتشف سامي أين 【كان】 تسكن ليلى.

Sami found out where Layla lived.

[[Arabic#^ar-Q0279-answer|Compare the answer]]
^ar-Q0279

**ar-Q0280 · Build the sentence**

Arrange: كانت / اكتشف / سامي / ليلى. / تسكن / أين

Sami found out where Layla lived.

[[Arabic#^ar-Q0280-answer|Compare the answer]]
^ar-Q0280

**ar-Q0281 · Write a translation**

Write this in Arabic: Mary was proud of her beauty.

[[Arabic#^ar-Q0281-answer|Compare the answer]]
^ar-Q0281

**ar-Q0282 · Explain the grammar**

ماري 【كانت】 فخورة بجمالها.

Mary was proud of her beauty.

[[Arabic#^ar-Q0282-answer|Compare the answer]]
^ar-Q0282

**ar-Q0283 · Fill the gap**

____ من الممكن أن أرى كيلي، لو أنني وصلت مبكرا.

Had I arrived earlier, I could have seen Kelly.

[[Arabic#^ar-Q0283-answer|Compare the answer]]
^ar-Q0283

**ar-Q0284 · Choose the form**

____ من الممكن أن أرى كيلي، لو أنني وصلت مبكرا.

Had I arrived earlier, I could have seen Kelly.

Choices: كنت / كانت / كنا / كان

[[Arabic#^ar-Q0284-answer|Compare the answer]]
^ar-Q0284

**ar-Q0285 · Edit the changed sentence**

【كانت】 مدرّسنا في العلوم.

He was our science teacher.

[[Arabic#^ar-Q0285-answer|Compare the answer]]
^ar-Q0285

**ar-Q0286 · Build the sentence**

Arrange: كان / العلوم. / مدرّسنا / في

He was our science teacher.

[[Arabic#^ar-Q0286-answer|Compare the answer]]
^ar-Q0286

**ar-Q0287 · Write a translation**

Write this in Arabic: The bus was very crowded. I wish I had taken a taxi.

[[Arabic#^ar-Q0287-answer|Compare the answer]]
^ar-Q0287

**ar-Q0288 · Explain the grammar**

【كانت】 الحافلة مزدحمة جداً. تمنيت لو اخذت سيارة الأجرة.

The bus was very crowded. I wish I had taken a taxi.

[[Arabic#^ar-Q0288-answer|Compare the answer]]
^ar-Q0288

**ar-Q0289 · Fill the gap**

____ تمطر عند إقلاعنا، لكن، عندما وصلنا، كان الجو مشمسا.

It was raining when we left, but by the time we arrived, it was sunny.

[[Arabic#^ar-Q0289-answer|Compare the answer]]
^ar-Q0289

**ar-Q0290 · Choose the form**

____ تمطر عند إقلاعنا، لكن، عندما وصلنا، كان الجو مشمسا.

It was raining when we left, but by the time we arrived, it was sunny.

Choices: كنا / كان / كانت / كنت

[[Arabic#^ar-Q0290-answer|Compare the answer]]
^ar-Q0290

**ar-Q0291 · Edit the changed sentence**

ياني 【كانت】َ قذِر للغاية لدرجة أن بعض الأشخاص ظنّوه مجنوناً.

Yanni was so scruffy that people thought he was crazy.

[[Arabic#^ar-Q0291-answer|Compare the answer]]
^ar-Q0291

**ar-Q0292 · Build the sentence**

Arrange: أن / كانَ / لدرجة / قذِر / الأشخاص / ظنّوه / بعض / للغاية / مجنوناً. / ياني

Yanni was so scruffy that people thought he was crazy.

[[Arabic#^ar-Q0292-answer|Compare the answer]]
^ar-Q0292

**ar-Q0293 · Write a translation**

Write this in Arabic: Sami was sneezing.

[[Arabic#^ar-Q0293-answer|Compare the answer]]
^ar-Q0293

**ar-Q0294 · Explain the grammar**

【كان】 سامي يعطس.

Sami was sneezing.

[[Arabic#^ar-Q0294-answer|Compare the answer]]
^ar-Q0294

**ar-Q0295 · Fill the gap**

____ فخورة للغاية بوالدها.

She was very proud of her father.

[[Arabic#^ar-Q0295-answer|Compare the answer]]
^ar-Q0295

**ar-Q0296 · Choose the form**

____ فخورة للغاية بوالدها.

She was very proud of her father.

Choices: كانت / كنا / كنت / كان

[[Arabic#^ar-Q0296-answer|Compare the answer]]
^ar-Q0296

**ar-Q0297 · Edit the changed sentence**

【كانت】 سامي ينتظر اتّصال ليلى.

Sami waited for Layla's call.

[[Arabic#^ar-Q0297-answer|Compare the answer]]
^ar-Q0297

**ar-Q0298 · Build the sentence**

Arrange: ليلى. / ينتظر / اتّصال / كان / سامي

Sami waited for Layla's call.

[[Arabic#^ar-Q0298-answer|Compare the answer]]
^ar-Q0298

**ar-Q0299 · Write a translation**

Write this in Arabic: Sami liked the party life.

[[Arabic#^ar-Q0299-answer|Compare the answer]]
^ar-Q0299

**ar-Q0300 · Explain the grammar**

【كان】 سامي يحبّ حياة الحفلات.

Sami liked the party life.

[[Arabic#^ar-Q0300-answer|Compare the answer]]
^ar-Q0300


### Negation lā and laysa · 50 questions

**ar-Q0301 · Fill the gap**

توم ____ وحيداً الآن.

Tom isn't lonely now.

[[Arabic#^ar-Q0301-answer|Compare the answer]]
^ar-Q0301

**ar-Q0302 · Choose the form**

توم ____ وحيداً الآن.

Tom isn't lonely now.

Choices: ليس / ليست / لا

[[Arabic#^ar-Q0302-answer|Compare the answer]]
^ar-Q0302

**ar-Q0303 · Edit the changed sentence**

【ليس】 أريد وظيفة بدوام كامل.

I don't want a full-time job.

[[Arabic#^ar-Q0303-answer|Compare the answer]]
^ar-Q0303

**ar-Q0304 · Build the sentence**

Arrange: أريد / كامل. / لا / وظيفة / بدوام

I don't want a full-time job.

[[Arabic#^ar-Q0304-answer|Compare the answer]]
^ar-Q0304

**ar-Q0305 · Write a translation**

Write this in Arabic: There is no time for explanation.

[[Arabic#^ar-Q0305-answer|Compare the answer]]
^ar-Q0305

**ar-Q0306 · Explain the grammar**

【لا】 وقت للشرح.

There is no time for explanation.

[[Arabic#^ar-Q0306-answer|Compare the answer]]
^ar-Q0306

**ar-Q0307 · Fill the gap**

____ تزال ليلى تعمل من أجل استعادة قدرتها على الكلام.

Layla is still working to regain her ability to speak.

[[Arabic#^ar-Q0307-answer|Compare the answer]]
^ar-Q0307

**ar-Q0308 · Choose the form**

____ تزال ليلى تعمل من أجل استعادة قدرتها على الكلام.

Layla is still working to regain her ability to speak.

Choices: ليست / لا / ليس

[[Arabic#^ar-Q0308-answer|Compare the answer]]
^ar-Q0308

**ar-Q0309 · Edit the changed sentence**

بقدر ما 【ليس】 تمثّل المملكة العربيّة السّعوديّة المسلمين، فإنّ إسرائيل لا تمثّل و لا ينبغي أن تمثّل الدّين اليهودي.

As much as Saudi Arabia is not Islam and doesn't represent Muslims, Israel is neither the Jewish people nor does it or should it represent the Jewish religion.

[[Arabic#^ar-Q0309-answer|Compare the answer]]
^ar-Q0309

**ar-Q0310 · Build the sentence**

Arrange: ما / فإنّ / تمثّل / تمثّل / ينبغي / العربيّة / لا / اليهودي. / بقدر / لا / السّعوديّة / و / المسلمين، / أن / لا / إسرائيل / الدّين / المملكة / تمثّل

As much as Saudi Arabia is not Islam and doesn't represent Muslims, Israel is neither the Jewish people nor does it or should it represent the Jewish religion.

[[Arabic#^ar-Q0310-answer|Compare the answer]]
^ar-Q0310

**ar-Q0311 · Write a translation**

Write this in Arabic: I can't remember the moment my husband put his hands around my neck and hugged me tightly.

[[Arabic#^ar-Q0311-answer|Compare the answer]]
^ar-Q0311

**ar-Q0312 · Explain the grammar**

【لا】 أستطيع تذكر اللحظة التي وضع زوجي يديه على عنقي و ضمّني بقوة.

I can't remember the moment my husband put his hands around my neck and hugged me tightly.

[[Arabic#^ar-Q0312-answer|Compare the answer]]
^ar-Q0312

**ar-Q0313 · Fill the gap**

____ أحد أعرفهُ يرتدي ربطة العُنُق بعد الآن.

No one I know wears a tie anymore.

[[Arabic#^ar-Q0313-answer|Compare the answer]]
^ar-Q0313

**ar-Q0314 · Choose the form**

____ أحد أعرفهُ يرتدي ربطة العُنُق بعد الآن.

No one I know wears a tie anymore.

Choices: لا / ليست / ليس

[[Arabic#^ar-Q0314-answer|Compare the answer]]
^ar-Q0314

**ar-Q0315 · Edit the changed sentence**

المكتب لي و 【لا】 له.

This office belongs to me, not him.

[[Arabic#^ar-Q0315-answer|Compare the answer]]
^ar-Q0315

**ar-Q0316 · Build the sentence**

Arrange: له. / ليس / المكتب / و / لي

This office belongs to me, not him.

[[Arabic#^ar-Q0316-answer|Compare the answer]]
^ar-Q0316

**ar-Q0317 · Write a translation**

Write this in Arabic: "Dima?" the man that Dima called "Al-Sayib" asked. "I don't know any Dima. Sorry. I think you've got the wrong number."

[[Arabic#^ar-Q0317-answer|Compare the answer]]
^ar-Q0317

**ar-Q0318 · Explain the grammar**

"ديما؟" سأل الرجل الذي أسماه ديما "الصائب". "【لا】 أعرف أحدًا باسم ديما. آسف. أظنك قد حصلت على الرقم الخطأ".

"Dima?" the man that Dima called "Al-Sayib" asked. "I don't know any Dima. Sorry. I think you've got the wrong number."

[[Arabic#^ar-Q0318-answer|Compare the answer]]
^ar-Q0318

**ar-Q0319 · Fill the gap**

هل أنت من كوكب ____ تعيش فيه إلا النساء؟

Are you from a planet solely populated by women?

[[Arabic#^ar-Q0319-answer|Compare the answer]]
^ar-Q0319

**ar-Q0320 · Choose the form**

هل أنت من كوكب ____ تعيش فيه إلا النساء؟

Are you from a planet solely populated by women?

Choices: ليست / لا / ليس

[[Arabic#^ar-Q0320-answer|Compare the answer]]
^ar-Q0320

**ar-Q0321 · Edit the changed sentence**

【ليس】 أستطيع تحمّل نفاقها.

I can't stand her hypocrisy.

[[Arabic#^ar-Q0321-answer|Compare the answer]]
^ar-Q0321

**ar-Q0322 · Build the sentence**

Arrange: لا / تحمّل / نفاقها. / أستطيع

I can't stand her hypocrisy.

[[Arabic#^ar-Q0322-answer|Compare the answer]]
^ar-Q0322

**ar-Q0323 · Write a translation**

Write this in Arabic: I can't accept your gift.

[[Arabic#^ar-Q0323-answer|Compare the answer]]
^ar-Q0323

**ar-Q0324 · Explain the grammar**

【لا】 أستطيع قبول هديتِكَ.

I can't accept your gift.

[[Arabic#^ar-Q0324-answer|Compare the answer]]
^ar-Q0324

**ar-Q0325 · Fill the gap**

____ يمكنني أن أقبل هديّتك.

I cannot accept your gift.

[[Arabic#^ar-Q0325-answer|Compare the answer]]
^ar-Q0325

**ar-Q0326 · Choose the form**

____ يمكنني أن أقبل هديّتك.

I cannot accept your gift.

Choices: ليس / ليست / لا

[[Arabic#^ar-Q0326-answer|Compare the answer]]
^ar-Q0326

**ar-Q0327 · Edit the changed sentence**

لم 【ليس】 نفعل ذلك؟

Why wouldn't we do that?

[[Arabic#^ar-Q0327-answer|Compare the answer]]
^ar-Q0327

**ar-Q0328 · Build the sentence**

Arrange: لا / ذلك؟ / نفعل / لم

Why wouldn't we do that?

[[Arabic#^ar-Q0328-answer|Compare the answer]]
^ar-Q0328

**ar-Q0329 · Write a translation**

Write this in Arabic: Sami's family must be missing him.

[[Arabic#^ar-Q0329-answer|Compare the answer]]
^ar-Q0329

**ar-Q0330 · Explain the grammar**

【لا】 شكّ أنّ عائلة سامي مشتاقة إليه.

Sami's family must be missing him.

[[Arabic#^ar-Q0330-answer|Compare the answer]]
^ar-Q0330

**ar-Q0331 · Fill the gap**

الحجارة ____ تطفو.

A stone does not float.

[[Arabic#^ar-Q0331-answer|Compare the answer]]
^ar-Q0331

**ar-Q0332 · Choose the form**

الحجارة ____ تطفو.

A stone does not float.

Choices: ليس / ليست / لا

[[Arabic#^ar-Q0332-answer|Compare the answer]]
^ar-Q0332

**ar-Q0333 · Edit the changed sentence**

هناك الكثير من الأمور التي 【ليس】 تعرفها عن شخصيتي.

There are a lot of things you don't know about my personality.

[[Arabic#^ar-Q0333-answer|Compare the answer]]
^ar-Q0333

**ar-Q0334 · Build the sentence**

Arrange: الأمور / التي / من / لا / عن / تعرفها / الكثير / هناك / شخصيتي.

There are a lot of things you don't know about my personality.

[[Arabic#^ar-Q0334-answer|Compare the answer]]
^ar-Q0334

**ar-Q0335 · Write a translation**

Write this in Arabic: No one could have predicted this.

[[Arabic#^ar-Q0335-answer|Compare the answer]]
^ar-Q0335

**ar-Q0336 · Explain the grammar**

【لا】 أحد كان قادرا على التّنبّؤ بذلك.

No one could have predicted this.

[[Arabic#^ar-Q0336-answer|Compare the answer]]
^ar-Q0336

**ar-Q0337 · Fill the gap**

سأكرّر كي ____ تنسى ذلك.

I will repeat so that you will not forget it.

[[Arabic#^ar-Q0337-answer|Compare the answer]]
^ar-Q0337

**ar-Q0338 · Choose the form**

سأكرّر كي ____ تنسى ذلك.

I will repeat so that you will not forget it.

Choices: ليس / لا / ليست

[[Arabic#^ar-Q0338-answer|Compare the answer]]
^ar-Q0338

**ar-Q0339 · Edit the changed sentence**

ما حدث لهم 【ليس】 يزال لغزا.

What happened to them is still a mystery.

[[Arabic#^ar-Q0339-answer|Compare the answer]]
^ar-Q0339

**ar-Q0340 · Build the sentence**

Arrange: لهم / يزال / لا / لغزا. / حدث / ما

What happened to them is still a mystery.

[[Arabic#^ar-Q0340-answer|Compare the answer]]
^ar-Q0340

**ar-Q0341 · Write a translation**

Write this in Arabic: His clothes are out of fashion.

[[Arabic#^ar-Q0341-answer|Compare the answer]]
^ar-Q0341

**ar-Q0342 · Explain the grammar**

ثيابه 【لا】 تتماشى مع الموضة.

His clothes are out of fashion.

[[Arabic#^ar-Q0342-answer|Compare the answer]]
^ar-Q0342

**ar-Q0343 · Fill the gap**

____ بإمكان الشرطة أن تستجوبه لهذا السّبب.

Cops can't question him because of that.

[[Arabic#^ar-Q0343-answer|Compare the answer]]
^ar-Q0343

**ar-Q0344 · Choose the form**

____ بإمكان الشرطة أن تستجوبه لهذا السّبب.

Cops can't question him because of that.

Choices: ليس / لا / ليست

[[Arabic#^ar-Q0344-answer|Compare the answer]]
^ar-Q0344

**ar-Q0345 · Edit the changed sentence**

أرغم فاضل دانية على أن تمارس معه أفعالا جنسيّة 【ليس】 تُوصف.

Fadil forced Dania to perform unspeakable acts on him.

[[Arabic#^ar-Q0345-answer|Compare the answer]]
^ar-Q0345

**ar-Q0346 · Build the sentence**

Arrange: جنسيّة / معه / تمارس / تُوصف. / دانية / أن / لا / على / أفعالا / أرغم / فاضل

Fadil forced Dania to perform unspeakable acts on him.

[[Arabic#^ar-Q0346-answer|Compare the answer]]
^ar-Q0346

**ar-Q0347 · Write a translation**

Write this in Arabic: I don't think he'll come.

[[Arabic#^ar-Q0347-answer|Compare the answer]]
^ar-Q0347

**ar-Q0348 · Explain the grammar**

【لا】 أظن أنه سيأتي.

I don't think he'll come.

[[Arabic#^ar-Q0348-answer|Compare the answer]]
^ar-Q0348

**ar-Q0349 · Fill the gap**

____ نستطيع الرجوع لهناك.

We can't go back there.

[[Arabic#^ar-Q0349-answer|Compare the answer]]
^ar-Q0349

**ar-Q0350 · Choose the form**

____ نستطيع الرجوع لهناك.

We can't go back there.

Choices: ليست / ليس / لا

[[Arabic#^ar-Q0350-answer|Compare the answer]]
^ar-Q0350


### Past negation lam · 50 questions

**ar-Q0351 · Edit the changed sentence**

【لن】 يتزوج سامي قطّ.

Sami never married.

[[Arabic#^ar-Q0351-answer|Compare the answer]]
^ar-Q0351

**ar-Q0352 · Build the sentence**

Arrange: سامي / يتزوج / قطّ. / لم

Sami never married.

[[Arabic#^ar-Q0352-answer|Compare the answer]]
^ar-Q0352

**ar-Q0353 · Write a translation**

Write this in Arabic: We weren't fighting.

[[Arabic#^ar-Q0353-answer|Compare the answer]]
^ar-Q0353

**ar-Q0354 · Explain the grammar**

【لم】 نكن نتقاتل

We weren't fighting.

[[Arabic#^ar-Q0354-answer|Compare the answer]]
^ar-Q0354

**ar-Q0355 · Fill the gap**

إذا ____ تسرع سيفوتك القطار.

If you don't hurry, you'll miss the train.

[[Arabic#^ar-Q0355-answer|Compare the answer]]
^ar-Q0355

**ar-Q0356 · Choose the form**

إذا ____ تسرع سيفوتك القطار.

If you don't hurry, you'll miss the train.

Choices: لم / لا / ما / لن

[[Arabic#^ar-Q0356-answer|Compare the answer]]
^ar-Q0356

**ar-Q0357 · Edit the changed sentence**

وقبل أكثر من سبع سنوات قامت الولايات المتحدة بملاحقة تنظيم القاعدة ونظام طالبان بدعم دولي واسع النطاق. 【لن】 نذهب إلى هناك باختيارنا وإنما بسبب الضرورة

Over seven years ago, the United States pursued al Qaeda and the Taliban with broad international support. We did not go by choice, we went because of necessity.

[[Arabic#^ar-Q0357-answer|Compare the answer]]
^ar-Q0357

**ar-Q0358 · Build the sentence**

Arrange: أكثر / المتحدة / بدعم / إلى / القاعدة / بملاحقة / وإنما / سنوات / طالبان / دولي / الضرورة / الولايات / سبع / واسع / النطاق. / ونظام / هناك / بسبب / من / تنظيم / نذهب / قامت / وقبل / باختيارنا / لم

Over seven years ago, the United States pursued al Qaeda and the Taliban with broad international support. We did not go by choice, we went because of necessity.

[[Arabic#^ar-Q0358-answer|Compare the answer]]
^ar-Q0358

**ar-Q0359 · Write a translation**

Write this in Arabic: Why didn't you tell us you knew French?

[[Arabic#^ar-Q0359-answer|Compare the answer]]
^ar-Q0359

**ar-Q0360 · Explain the grammar**

لماذا 【لم】 تخبرنا بانك تعرف الفرنسية؟

Why didn't you tell us you knew French?

[[Arabic#^ar-Q0360-answer|Compare the answer]]
^ar-Q0360

**ar-Q0361 · Fill the gap**

____ يعد لدينا سكر.

We're out of sugar.

[[Arabic#^ar-Q0361-answer|Compare the answer]]
^ar-Q0361

**ar-Q0362 · Choose the form**

____ يعد لدينا سكر.

We're out of sugar.

Choices: ما / لا / لم / لن

[[Arabic#^ar-Q0362-answer|Compare the answer]]
^ar-Q0362

**ar-Q0363 · Edit the changed sentence**

【لن】 يكن عليّ فعل شيء.

I didn't have to do anything.

[[Arabic#^ar-Q0363-answer|Compare the answer]]
^ar-Q0363

**ar-Q0364 · Build the sentence**

Arrange: يكن / شيء. / عليّ / لم / فعل

I didn't have to do anything.

[[Arabic#^ar-Q0364-answer|Compare the answer]]
^ar-Q0364

**ar-Q0365 · Write a translation**

Write this in Arabic: Why do you lie for her?

[[Arabic#^ar-Q0365-answer|Compare the answer]]
^ar-Q0365

**ar-Q0366 · Explain the grammar**

【لم】 تكذب من أجلها؟

Why do you lie for her?

[[Arabic#^ar-Q0366-answer|Compare the answer]]
^ar-Q0366

**ar-Q0367 · Fill the gap**

____ يأذني أحد.

Nobody hurt me.

[[Arabic#^ar-Q0367-answer|Compare the answer]]
^ar-Q0367

**ar-Q0368 · Choose the form**

____ يأذني أحد.

Nobody hurt me.

Choices: لن / لا / ما / لم

[[Arabic#^ar-Q0368-answer|Compare the answer]]
^ar-Q0368

**ar-Q0369 · Edit the changed sentence**

توم 【لن】 يذهب ابدا الى المدرسة

Tom has never gone to school.

[[Arabic#^ar-Q0369-answer|Compare the answer]]
^ar-Q0369

**ar-Q0370 · Build the sentence**

Arrange: الى / ابدا / لم / المدرسة / يذهب / توم

Tom has never gone to school.

[[Arabic#^ar-Q0370-answer|Compare the answer]]
^ar-Q0370

**ar-Q0371 · Write a translation**

Write this in Arabic: Sami never felt Christian.

[[Arabic#^ar-Q0371-answer|Compare the answer]]
^ar-Q0371

**ar-Q0372 · Explain the grammar**

【لم】 يشعر سامي قطّ بأنّه مسيحي.

Sami never felt Christian.

[[Arabic#^ar-Q0372-answer|Compare the answer]]
^ar-Q0372

**ar-Q0373 · Fill the gap**

____ يجد أحد قطها أبدا.

Nobody ever found her cat.

[[Arabic#^ar-Q0373-answer|Compare the answer]]
^ar-Q0373

**ar-Q0374 · Choose the form**

____ يجد أحد قطها أبدا.

Nobody ever found her cat.

Choices: لم / لن / ما / لا

[[Arabic#^ar-Q0374-answer|Compare the answer]]
^ar-Q0374

**ar-Q0375 · Edit the changed sentence**

【لن】 تحاول حتى ان تفعل الشيء الصحيح

She didn't even try to do the right thing.

[[Arabic#^ar-Q0375-answer|Compare the answer]]
^ar-Q0375

**ar-Q0376 · Build the sentence**

Arrange: ان / تفعل / الشيء / الصحيح / لم / تحاول / حتى

She didn't even try to do the right thing.

[[Arabic#^ar-Q0376-answer|Compare the answer]]
^ar-Q0376

**ar-Q0377 · Write a translation**

Write this in Arabic: As if I didn't know that!

[[Arabic#^ar-Q0377-answer|Compare the answer]]
^ar-Q0377

**ar-Q0378 · Explain the grammar**

كأنني 【لم】 أعرف هذا!

As if I didn't know that!

[[Arabic#^ar-Q0378-answer|Compare the answer]]
^ar-Q0378

**ar-Q0379 · Fill the gap**

إن ____ يكن معطلا، فلا داعي لأن تصلحه.

If it ain't broke, don't fix it.

[[Arabic#^ar-Q0379-answer|Compare the answer]]
^ar-Q0379

**ar-Q0380 · Choose the form**

إن ____ يكن معطلا، فلا داعي لأن تصلحه.

If it ain't broke, don't fix it.

Choices: لم / لن / لا / ما

[[Arabic#^ar-Q0380-answer|Compare the answer]]
^ar-Q0380

**ar-Q0381 · Edit the changed sentence**

تعلم 【لن】 أنا لست مضطرّا للقيام بهذا، أليس كذلك؟

You know why I don't have to do that, don't you?

[[Arabic#^ar-Q0381-answer|Compare the answer]]
^ar-Q0381

**ar-Q0382 · Build the sentence**

Arrange: أليس / مضطرّا / للقيام / لم / أنا / كذلك؟ / تعلم / بهذا، / لست

You know why I don't have to do that, don't you?

[[Arabic#^ar-Q0382-answer|Compare the answer]]
^ar-Q0382

**ar-Q0383 · Write a translation**

Write this in Arabic: Layla and Sami didn't want their marriage to be made public.

[[Arabic#^ar-Q0383-answer|Compare the answer]]
^ar-Q0383

**ar-Q0384 · Explain the grammar**

【لم】 تكن ليلى و سامي راغبين أن يعلم النّاس بزواجهما.

Layla and Sami didn't want their marriage to be made public.

[[Arabic#^ar-Q0384-answer|Compare the answer]]
^ar-Q0384

**ar-Q0385 · Fill the gap**

____ لم تتّصل بي مسبّقا؟

Why didn't you call me earlier?

[[Arabic#^ar-Q0385-answer|Compare the answer]]
^ar-Q0385

**ar-Q0386 · Choose the form**

____ لم تتّصل بي مسبّقا؟

Why didn't you call me earlier?

Choices: ما / لم / لن / لا

[[Arabic#^ar-Q0386-answer|Compare the answer]]
^ar-Q0386

**ar-Q0387 · Edit the changed sentence**

【لن】 يُعامَل سامي بنفس الطّريقة.

Sami didn't get the same treatment.

[[Arabic#^ar-Q0387-answer|Compare the answer]]
^ar-Q0387

**ar-Q0388 · Build the sentence**

Arrange: سامي / الطّريقة. / بنفس / يُعامَل / لم

Sami didn't get the same treatment.

[[Arabic#^ar-Q0388-answer|Compare the answer]]
^ar-Q0388

**ar-Q0389 · Write a translation**

Write this in Arabic: I no longer live here.

[[Arabic#^ar-Q0389-answer|Compare the answer]]
^ar-Q0389

**ar-Q0390 · Explain the grammar**

أنا 【لم】 أعد أعيش هنا.

I no longer live here.

[[Arabic#^ar-Q0390-answer|Compare the answer]]
^ar-Q0390

**ar-Q0391 · Fill the gap**

____ يجد توم مفتاحه في أي مكان.

Tom couldn't find his key anywhere.

[[Arabic#^ar-Q0391-answer|Compare the answer]]
^ar-Q0391

**ar-Q0392 · Choose the form**

____ يجد توم مفتاحه في أي مكان.

Tom couldn't find his key anywhere.

Choices: لن / لا / لم / ما

[[Arabic#^ar-Q0392-answer|Compare the answer]]
^ar-Q0392

**ar-Q0393 · Edit the changed sentence**

【لن】 يسبق لي و أن رأيت فتاة جميلة مثل هذه.

I had never seen such a beautiful girl before.

[[Arabic#^ar-Q0393-answer|Compare the answer]]
^ar-Q0393

**ar-Q0394 · Build the sentence**

Arrange: مثل / لي / لم / أن / هذه. / جميلة / و / يسبق / رأيت / فتاة

I had never seen such a beautiful girl before.

[[Arabic#^ar-Q0394-answer|Compare the answer]]
^ar-Q0394

**ar-Q0395 · Write a translation**

Write this in Arabic: Why quit now?

[[Arabic#^ar-Q0395-answer|Compare the answer]]
^ar-Q0395

**ar-Q0396 · Explain the grammar**

【لم】 الإستسلام الآن؟

Why quit now?

[[Arabic#^ar-Q0396-answer|Compare the answer]]
^ar-Q0396

**ar-Q0397 · Fill the gap**

____ يفهم معنى الجملة.

He couldn't understand the sentence.

[[Arabic#^ar-Q0397-answer|Compare the answer]]
^ar-Q0397

**ar-Q0398 · Choose the form**

____ يفهم معنى الجملة.

He couldn't understand the sentence.

Choices: ما / لن / لا / لم

[[Arabic#^ar-Q0398-answer|Compare the answer]]
^ar-Q0398

**ar-Q0399 · Edit the changed sentence**

【لن】 يسبق لنا و أن قمنا بهذا من قبل.

We have never done it before.

[[Arabic#^ar-Q0399-answer|Compare the answer]]
^ar-Q0399

**ar-Q0400 · Build the sentence**

Arrange: و / يسبق / قبل. / لم / من / قمنا / بهذا / أن / لنا

We have never done it before.

[[Arabic#^ar-Q0400-answer|Compare the answer]]
^ar-Q0400


### Future negation lan · 50 questions

**ar-Q0401 · Write a translation**

Write this in Arabic: I will not forget to write to my mother.

[[Arabic#^ar-Q0401-answer|Compare the answer]]
^ar-Q0401

**ar-Q0402 · Explain the grammar**

【لن】 أنس مراسلة أمّي.

I will not forget to write to my mother.

[[Arabic#^ar-Q0402-answer|Compare the answer]]
^ar-Q0402

**ar-Q0403 · Fill the gap**

____ تؤذي ذبابة.

It wouldn't harm a fly.

[[Arabic#^ar-Q0403-answer|Compare the answer]]
^ar-Q0403

**ar-Q0404 · Choose the form**

____ تؤذي ذبابة.

It wouldn't harm a fly.

Choices: لا / لم / لن

[[Arabic#^ar-Q0404-answer|Compare the answer]]
^ar-Q0404

**ar-Q0405 · Edit the changed sentence**

【لم】 يأتي أليس كذلك؟

He won't come, will he?

[[Arabic#^ar-Q0405-answer|Compare the answer]]
^ar-Q0405

**ar-Q0406 · Build the sentence**

Arrange: كذلك؟ / لن / أليس / يأتي

He won't come, will he?

[[Arabic#^ar-Q0406-answer|Compare the answer]]
^ar-Q0406

**ar-Q0407 · Write a translation**

Write this in Arabic: Hurry up, and you will be in time for school.

[[Arabic#^ar-Q0407-answer|Compare the answer]]
^ar-Q0407

**ar-Q0408 · Explain the grammar**

أسرع و 【لن】 تتأخر على المدرسة.

Hurry up, and you will be in time for school.

[[Arabic#^ar-Q0408-answer|Compare the answer]]
^ar-Q0408

**ar-Q0409 · Fill the gap**

____ أنس أبدا ما قلته لي.

I'll never forget what you told me.

[[Arabic#^ar-Q0409-answer|Compare the answer]]
^ar-Q0409

**ar-Q0410 · Choose the form**

____ أنس أبدا ما قلته لي.

I'll never forget what you told me.

Choices: لا / لن / لم

[[Arabic#^ar-Q0410-answer|Compare the answer]]
^ar-Q0410

**ar-Q0411 · Edit the changed sentence**

يجب أن تدرك بأننا 【لم】 نستطيع تقديم يد العون.

You must realize that I can't help you.

[[Arabic#^ar-Q0411-answer|Compare the answer]]
^ar-Q0411

**ar-Q0412 · Build the sentence**

Arrange: أن / لن / تقديم / بأننا / يجب / تدرك / العون. / يد / نستطيع

You must realize that I can't help you.

[[Arabic#^ar-Q0412-answer|Compare the answer]]
^ar-Q0412

**ar-Q0413 · Write a translation**

Write this in Arabic: I'm not likely to forget to do that.

[[Arabic#^ar-Q0413-answer|Compare the answer]]
^ar-Q0413

**ar-Q0414 · Explain the grammar**

من الأرجح أنّني 【لن】 أنس ذلك.

I'm not likely to forget to do that.

[[Arabic#^ar-Q0414-answer|Compare the answer]]
^ar-Q0414

**ar-Q0415 · Fill the gap**

____ تسطيع أمي القدوم.

My mother can't come.

[[Arabic#^ar-Q0415-answer|Compare the answer]]
^ar-Q0415

**ar-Q0416 · Choose the form**

____ تسطيع أمي القدوم.

My mother can't come.

Choices: لم / لن / لا

[[Arabic#^ar-Q0416-answer|Compare the answer]]
^ar-Q0416

**ar-Q0417 · Edit the changed sentence**

【لم】 يُغَيِّرَ ذلك شيئًا.

That won't change anything.

[[Arabic#^ar-Q0417-answer|Compare the answer]]
^ar-Q0417

**ar-Q0418 · Build the sentence**

Arrange: يُغَيِّرَ / ذلك / شيئًا. / لن

That won't change anything.

[[Arabic#^ar-Q0418-answer|Compare the answer]]
^ar-Q0418

**ar-Q0419 · Write a translation**

Write this in Arabic: I would never question his honesty.

[[Arabic#^ar-Q0419-answer|Compare the answer]]
^ar-Q0419

**ar-Q0420 · Explain the grammar**

أبدأ 【لن】 أشك في صدقه.

I would never question his honesty.

[[Arabic#^ar-Q0420-answer|Compare the answer]]
^ar-Q0420

**ar-Q0421 · Fill the gap**

____ُلقِ نظرة عليه.

Let's have a look at it.

[[Arabic#^ar-Q0421-answer|Compare the answer]]
^ar-Q0421

**ar-Q0422 · Choose the form**

____ُلقِ نظرة عليه.

Let's have a look at it.

Choices: لا / لن / لم

[[Arabic#^ar-Q0422-answer|Compare the answer]]
^ar-Q0422

**ar-Q0423 · Edit the changed sentence**

أصر ديما: "لكنه صحيح! 【لم】 يجعلوني أشتري البذلة ما لم أعطهم 99 كوبيكًا! ألا تستطيع أن ترسل لي بعض المال؟"

"But it's true!" Dima insisted. "They won't let me buy the suit unless I give them another 99 kopeks! Can't you wire me some money?"

[[Arabic#^ar-Q0423-answer|Compare the answer]]
^ar-Q0423

**ar-Q0424 · Build the sentence**

Arrange: يجعلوني / أشتري / ألا / المال؟" / البذلة / تستطيع / ديما: / لم / لن / صحيح! / بعض / "لكنه / كوبيكًا! / 99 / ما / لي / ترسل / أن / أصر / أعطهم

"But it's true!" Dima insisted. "They won't let me buy the suit unless I give them another 99 kopeks! Can't you wire me some money?"

[[Arabic#^ar-Q0424-answer|Compare the answer]]
^ar-Q0424

**ar-Q0425 · Write a translation**

Write this in Arabic: Nobody is going to hurt you.

[[Arabic#^ar-Q0425-answer|Compare the answer]]
^ar-Q0425

**ar-Q0426 · Explain the grammar**

【لن】 يصبكن أحد بالأذى.

Nobody is going to hurt you.

[[Arabic#^ar-Q0426-answer|Compare the answer]]
^ar-Q0426

**ar-Q0427 · Fill the gap**

____ أطّلع على تقرير توم على الأرجح.

I probably won't read Tom's report.

[[Arabic#^ar-Q0427-answer|Compare the answer]]
^ar-Q0427

**ar-Q0428 · Choose the form**

____ أطّلع على تقرير توم على الأرجح.

I probably won't read Tom's report.

Choices: لا / لم / لن

[[Arabic#^ar-Q0428-answer|Compare the answer]]
^ar-Q0428

**ar-Q0429 · Edit the changed sentence**

【لم】 أدعها تذهب إلى هناك.

I won't let her go there.

[[Arabic#^ar-Q0429-answer|Compare the answer]]
^ar-Q0429

**ar-Q0430 · Build the sentence**

Arrange: إلى / لن / هناك. / تذهب / أدعها

I won't let her go there.

[[Arabic#^ar-Q0430-answer|Compare the answer]]
^ar-Q0430

**ar-Q0431 · Write a translation**

Write this in Arabic: Emily would never slap me in the face.

[[Arabic#^ar-Q0431-answer|Compare the answer]]
^ar-Q0431

**ar-Q0432 · Explain the grammar**

【لن】 تصفعني إميلي أبدا في الوجه.

Emily would never slap me in the face.

[[Arabic#^ar-Q0432-answer|Compare the answer]]
^ar-Q0432

**ar-Q0433 · Fill the gap**

____ أذهب إلى المدرسة اليوم.

I'm not going to go to school today.

[[Arabic#^ar-Q0433-answer|Compare the answer]]
^ar-Q0433

**ar-Q0434 · Choose the form**

____ أذهب إلى المدرسة اليوم.

I'm not going to go to school today.

Choices: لم / لا / لن

[[Arabic#^ar-Q0434-answer|Compare the answer]]
^ar-Q0434

**ar-Q0435 · Edit the changed sentence**

من دون الهواء ، 【لم】 يبقى شيء على قيد الحياة.

Without air, nothing could live.

[[Arabic#^ar-Q0435-answer|Compare the answer]]
^ar-Q0435

**ar-Q0436 · Build the sentence**

Arrange: لن / الحياة. / دون / الهواء / من / قيد / يبقى / ، / على / شيء

Without air, nothing could live.

[[Arabic#^ar-Q0436-answer|Compare the answer]]
^ar-Q0436

**ar-Q0437 · Write a translation**

Write this in Arabic: You will never see Egypt again.

[[Arabic#^ar-Q0437-answer|Compare the answer]]
^ar-Q0437

**ar-Q0438 · Explain the grammar**

【لن】 ترى مصر مجدّدا.

You will never see Egypt again.

[[Arabic#^ar-Q0438-answer|Compare the answer]]
^ar-Q0438

**ar-Q0439 · Fill the gap**

____ تستطيع أي من أجهزة الحاسوب الاستمرار في العمل مع بطاقة محروقة.

None of the computers can continue to run with a burnt card.

[[Arabic#^ar-Q0439-answer|Compare the answer]]
^ar-Q0439

**ar-Q0440 · Choose the form**

____ تستطيع أي من أجهزة الحاسوب الاستمرار في العمل مع بطاقة محروقة.

None of the computers can continue to run with a burnt card.

Choices: لن / لم / لا

[[Arabic#^ar-Q0440-answer|Compare the answer]]
^ar-Q0440

**ar-Q0441 · Edit the changed sentence**

وعدني جيم أنه 【لم】 يعود.

Jim promised me not to come again.

[[Arabic#^ar-Q0441-answer|Compare the answer]]
^ar-Q0441

**ar-Q0442 · Build the sentence**

Arrange: وعدني / جيم / أنه / يعود. / لن

Jim promised me not to come again.

[[Arabic#^ar-Q0442-answer|Compare the answer]]
^ar-Q0442

**ar-Q0443 · Write a translation**

Write this in Arabic: That wouldn't surprise me.

[[Arabic#^ar-Q0443-answer|Compare the answer]]
^ar-Q0443

**ar-Q0444 · Explain the grammar**

【لن】 يفاجئني ذلك.

That wouldn't surprise me.

[[Arabic#^ar-Q0444-answer|Compare the answer]]
^ar-Q0444

**ar-Q0445 · Fill the gap**

____ أجرح مشاعرك أبدا

I will never hurt you.

[[Arabic#^ar-Q0445-answer|Compare the answer]]
^ar-Q0445

**ar-Q0446 · Choose the form**

____ أجرح مشاعرك أبدا

I will never hurt you.

Choices: لم / لا / لن

[[Arabic#^ar-Q0446-answer|Compare the answer]]
^ar-Q0446

**ar-Q0447 · Edit the changed sentence**

【لم】 أكلمه من الآن فصاعداً.

I won't talk to him anymore.

[[Arabic#^ar-Q0447-answer|Compare the answer]]
^ar-Q0447

**ar-Q0448 · Build the sentence**

Arrange: لن / الآن / أكلمه / فصاعداً. / من

I won't talk to him anymore.

[[Arabic#^ar-Q0448-answer|Compare the answer]]
^ar-Q0448

**ar-Q0449 · Write a translation**

Write this in Arabic: I'm not leaving until you tell me where I can find Tom.

[[Arabic#^ar-Q0449-answer|Compare the answer]]
^ar-Q0449

**ar-Q0450 · Explain the grammar**

【لن】 أذهب ما لم تخبرني أين أجد توم.

I'm not leaving until you tell me where I can find Tom.

[[Arabic#^ar-Q0450-answer|Compare the answer]]
^ar-Q0450


### Ma and other negatives · 50 questions

**ar-Q0451 · Fill the gap**

____ زال ذراعي يؤلمني.

My arm still hurts.

[[Arabic#^ar-Q0451-answer|Compare the answer]]
^ar-Q0451

**ar-Q0452 · Choose the form**

____ زال ذراعي يؤلمني.

My arm still hurts.

Choices: لم / ما / لا

[[Arabic#^ar-Q0452-answer|Compare the answer]]
^ar-Q0452

**ar-Q0453 · Edit the changed sentence**

【لم】 اسم صديقك؟

What's your friend's name?

[[Arabic#^ar-Q0453-answer|Compare the answer]]
^ar-Q0453

**ar-Q0454 · Build the sentence**

Arrange: ما / صديقك؟ / اسم

What's your friend's name?

[[Arabic#^ar-Q0454-answer|Compare the answer]]
^ar-Q0454

**ar-Q0455 · Write a translation**

Write this in Arabic: Sami took what I told him to heart.

[[Arabic#^ar-Q0455-answer|Compare the answer]]
^ar-Q0455

**ar-Q0456 · Explain the grammar**

أخذ سامي 【ما】 قلته له على محمل الجدّ.

Sami took what I told him to heart.

[[Arabic#^ar-Q0456-answer|Compare the answer]]
^ar-Q0456

**ar-Q0457 · Fill the gap**

هل توم على ____ يرام؟

Is Tom alright?

[[Arabic#^ar-Q0457-answer|Compare the answer]]
^ar-Q0457

**ar-Q0458 · Choose the form**

هل توم على ____ يرام؟

Is Tom alright?

Choices: لم / ما / لا

[[Arabic#^ar-Q0458-answer|Compare the answer]]
^ar-Q0458

**ar-Q0459 · Edit the changed sentence**

【لم】 أقدر أتذكر اسمها .

I can't remember her name.

[[Arabic#^ar-Q0459-answer|Compare the answer]]
^ar-Q0459

**ar-Q0460 · Build the sentence**

Arrange: اسمها / أتذكر / . / ما / أقدر

I can't remember her name.

[[Arabic#^ar-Q0460-answer|Compare the answer]]
^ar-Q0460

**ar-Q0461 · Write a translation**

Write this in Arabic: Can you explain what do you want actually?

[[Arabic#^ar-Q0461-answer|Compare the answer]]
^ar-Q0461

**ar-Q0462 · Explain the grammar**

هل بإمكانك تفسير 【ما】 تريده؟

Can you explain what do you want actually?

[[Arabic#^ar-Q0462-answer|Compare the answer]]
^ar-Q0462

**ar-Q0463 · Fill the gap**

كان هناك ____ يكفينا من الطعام.

There was food enough for us all.

[[Arabic#^ar-Q0463-answer|Compare the answer]]
^ar-Q0463

**ar-Q0464 · Choose the form**

كان هناك ____ يكفينا من الطعام.

There was food enough for us all.

Choices: لم / لا / ما

[[Arabic#^ar-Q0464-answer|Compare the answer]]
^ar-Q0464

**ar-Q0465 · Edit the changed sentence**

هل يذكّر هذا بشخص 【لم】؟

Does this remind you of anybody?

[[Arabic#^ar-Q0465-answer|Compare the answer]]
^ar-Q0465

**ar-Q0466 · Build the sentence**

Arrange: هل / يذكّر / ما؟ / هذا / بشخص

Does this remind you of anybody?

[[Arabic#^ar-Q0466-answer|Compare the answer]]
^ar-Q0466

**ar-Q0467 · Write a translation**

Write this in Arabic: These are Sami's life savings.

[[Arabic#^ar-Q0467-answer|Compare the answer]]
^ar-Q0467

**ar-Q0468 · Explain the grammar**

هذا كلّ 【ما】 ادّخره سامي في حياته.

These are Sami's life savings.

[[Arabic#^ar-Q0468-answer|Compare the answer]]
^ar-Q0468

**ar-Q0469 · Fill the gap**

لكل فرد حق التمتع بجنسية ____.

Everyone has the right to a nationality.

[[Arabic#^ar-Q0469-answer|Compare the answer]]
^ar-Q0469

**ar-Q0470 · Choose the form**

لكل فرد حق التمتع بجنسية ____.

Everyone has the right to a nationality.

Choices: ما / لا / لم

[[Arabic#^ar-Q0470-answer|Compare the answer]]
^ar-Q0470

**ar-Q0471 · Edit the changed sentence**

تحصّل فاضل على 【لم】 استحقّه تماما.

Fadil got exactly what he deserved.

[[Arabic#^ar-Q0471-answer|Compare the answer]]
^ar-Q0471

**ar-Q0472 · Build the sentence**

Arrange: على / ما / فاضل / تماما. / استحقّه / تحصّل

Fadil got exactly what he deserved.

[[Arabic#^ar-Q0472-answer|Compare the answer]]
^ar-Q0472

**ar-Q0473 · Write a translation**

Write this in Arabic: What's Ken doing now?

[[Arabic#^ar-Q0473-answer|Compare the answer]]
^ar-Q0473

**ar-Q0474 · Explain the grammar**

【ما】 الذي يفعله كين الآن؟

What's Ken doing now?

[[Arabic#^ar-Q0474-answer|Compare the answer]]
^ar-Q0474

**ar-Q0475 · Fill the gap**

لربّ____ عليك إطفاء التلفاز.

Maybe you should turn off the TV.

[[Arabic#^ar-Q0475-answer|Compare the answer]]
^ar-Q0475

**ar-Q0476 · Choose the form**

لربّ____ عليك إطفاء التلفاز.

Maybe you should turn off the TV.

Choices: ما / لم / لا

[[Arabic#^ar-Q0476-answer|Compare the answer]]
^ar-Q0476

**ar-Q0477 · Edit the changed sentence**

دائما 【لم】 كان سامي يرتدي خواتما.

Sami always wore rings.

[[Arabic#^ar-Q0477-answer|Compare the answer]]
^ar-Q0477

**ar-Q0478 · Build the sentence**

Arrange: سامي / ما / كان / يرتدي / خواتما. / دائما

Sami always wore rings.

[[Arabic#^ar-Q0478-answer|Compare the answer]]
^ar-Q0478

**ar-Q0479 · Write a translation**

Write this in Arabic: What time does your plane leave?

[[Arabic#^ar-Q0479-answer|Compare the answer]]
^ar-Q0479

**ar-Q0480 · Explain the grammar**

【ما】 ميعاد إقلاع طائرتك؟

What time does your plane leave?

[[Arabic#^ar-Q0480-answer|Compare the answer]]
^ar-Q0480

**ar-Q0481 · Fill the gap**

هل كل شيء على ____ يرام؟

Is everything all right?

[[Arabic#^ar-Q0481-answer|Compare the answer]]
^ar-Q0481

**ar-Q0482 · Choose the form**

هل كل شيء على ____ يرام؟

Is everything all right?

Choices: لم / ما / لا

[[Arabic#^ar-Q0482-answer|Compare the answer]]
^ar-Q0482

**ar-Q0483 · Edit the changed sentence**

هذا بالضبط 【لم】 كنت أحتاج إليه.

I needed just that.

[[Arabic#^ar-Q0483-answer|Compare the answer]]
^ar-Q0483

**ar-Q0484 · Build the sentence**

Arrange: إليه. / بالضبط / أحتاج / هذا / ما / كنت

I needed just that.

[[Arabic#^ar-Q0484-answer|Compare the answer]]
^ar-Q0484

**ar-Q0485 · Write a translation**

Write this in Arabic: Do what Tom says.

[[Arabic#^ar-Q0485-answer|Compare the answer]]
^ar-Q0485

**ar-Q0486 · Explain the grammar**

إفعل 【ما】 يقوله توم.

Do what Tom says.

[[Arabic#^ar-Q0486-answer|Compare the answer]]
^ar-Q0486

**ar-Q0487 · Fill the gap**

لا يستطيعُ توم شراء ____ يريد لأنه لا يملك ما يكفي من النقود.

Tom can't buy what he needs because he doesn't have enough money.

[[Arabic#^ar-Q0487-answer|Compare the answer]]
^ar-Q0487

**ar-Q0488 · Choose the form**

لا يستطيعُ توم شراء ____ يريد لأنه لا يملك ما يكفي من النقود.

Tom can't buy what he needs because he doesn't have enough money.

Choices: ما / لم / لا

[[Arabic#^ar-Q0488-answer|Compare the answer]]
^ar-Q0488

**ar-Q0489 · Edit the changed sentence**

ربّ【لم】 تخبرينني عن مكانٍ أجد فيه توم.

Maybe you can tell me where I can find Tom.

[[Arabic#^ar-Q0489-answer|Compare the answer]]
^ar-Q0489

**ar-Q0490 · Build the sentence**

Arrange: فيه / تخبرينني / مكانٍ / عن / أجد / ربّما / توم.

Maybe you can tell me where I can find Tom.

[[Arabic#^ar-Q0490-answer|Compare the answer]]
^ar-Q0490

**ar-Q0491 · Write a translation**

Write this in Arabic: Sami never cooked.

[[Arabic#^ar-Q0491-answer|Compare the answer]]
^ar-Q0491

**ar-Q0492 · Explain the grammar**

لم يكن سامي يطبخ 【أبدا】.

Sami never cooked.

[[Arabic#^ar-Q0492-answer|Compare the answer]]
^ar-Q0492

**ar-Q0493 · Fill the gap**

كل شيء على ____ يرام.

Everything is fine.

[[Arabic#^ar-Q0493-answer|Compare the answer]]
^ar-Q0493

**ar-Q0494 · Choose the form**

كل شيء على ____ يرام.

Everything is fine.

Choices: لا / لم / ما

[[Arabic#^ar-Q0494-answer|Compare the answer]]
^ar-Q0494

**ar-Q0495 · Edit the changed sentence**

حان الوقت لفعل شيئاً 【لم】.

It's time to do something.

[[Arabic#^ar-Q0495-answer|Compare the answer]]
^ar-Q0495

**ar-Q0496 · Build the sentence**

Arrange: ما. / حان / الوقت / شيئاً / لفعل

It's time to do something.

[[Arabic#^ar-Q0496-answer|Compare the answer]]
^ar-Q0496

**ar-Q0497 · Write a translation**

Write this in Arabic: How beautiful this flower is!

[[Arabic#^ar-Q0497-answer|Compare the answer]]
^ar-Q0497

**ar-Q0498 · Explain the grammar**

【ما】 أجمل هذه الزهرة!

How beautiful this flower is!

[[Arabic#^ar-Q0498-answer|Compare the answer]]
^ar-Q0498

**ar-Q0499 · Fill the gap**

____ هو رقم هاتف ليلى؟

What's Layla's phone number?

[[Arabic#^ar-Q0499-answer|Compare the answer]]
^ar-Q0499

**ar-Q0500 · Choose the form**

____ هو رقم هاتف ليلى؟

What's Layla's phone number?

Choices: ما / لا / لم

[[Arabic#^ar-Q0500-answer|Compare the answer]]
^ar-Q0500


### Common verbal predicates · 50 questions

**ar-Q0501 · Edit the changed sentence**

【أريد】 سامي أن يتقدّم في حياته.

Sami wants to move on with his life.

[[Arabic#^ar-Q0501-answer|Compare the answer]]
^ar-Q0501

**ar-Q0502 · Build the sentence**

Arrange: يتقدّم / سامي / حياته. / في / أن / يريد

Sami wants to move on with his life.

[[Arabic#^ar-Q0502-answer|Compare the answer]]
^ar-Q0502

**ar-Q0503 · Write a translation**

Write this in Arabic: Sami likes anime porn.

[[Arabic#^ar-Q0503-answer|Compare the answer]]
^ar-Q0503

**ar-Q0504 · Explain the grammar**

سامي 【يحب】ّ رسوم الأنمي الإباحيّة.

Sami likes anime porn.

[[Arabic#^ar-Q0504-answer|Compare the answer]]
^ar-Q0504

**ar-Q0505 · Fill the gap**

____ سامي أن يمضي بعض الوقت لوحده.

Sami wants to spend some time alone.

[[Arabic#^ar-Q0505-answer|Compare the answer]]
^ar-Q0505

**ar-Q0506 · Choose the form**

____ سامي أن يمضي بعض الوقت لوحده.

Sami wants to spend some time alone.

Choices: يعرف / أريد / أعرف / يريد

[[Arabic#^ar-Q0506-answer|Compare the answer]]
^ar-Q0506

**ar-Q0507 · Edit the changed sentence**

【أريد】ُ كَم يعني لكِ.

I know how much he means to you.

[[Arabic#^ar-Q0507-answer|Compare the answer]]
^ar-Q0507

**ar-Q0508 · Build the sentence**

Arrange: لكِ. / يعني / كَم / أعرفُ

I know how much he means to you.

[[Arabic#^ar-Q0508-answer|Compare the answer]]
^ar-Q0508

**ar-Q0509 · Write a translation**

Write this in Arabic: I have something to tell you.

[[Arabic#^ar-Q0509-answer|Compare the answer]]
^ar-Q0509

**ar-Q0510 · Explain the grammar**

【أريد】 أن أقول لك شيئاً.

I have something to tell you.

[[Arabic#^ar-Q0510-answer|Compare the answer]]
^ar-Q0510

**ar-Q0511 · Fill the gap**

لأني ____ أن أصير معلمة لغة إنجليزية.

The reason is that I want to be an English teacher.

[[Arabic#^ar-Q0511-answer|Compare the answer]]
^ar-Q0511

**ar-Q0512 · Choose the form**

لأني ____ أن أصير معلمة لغة إنجليزية.

The reason is that I want to be an English teacher.

Choices: أعرف / يعرف / يريد / أريد

[[Arabic#^ar-Q0512-answer|Compare the answer]]
^ar-Q0512

**ar-Q0513 · Edit the changed sentence**

【أريد】 لي كل شيء.

He told me everything.

[[Arabic#^ar-Q0513-answer|Compare the answer]]
^ar-Q0513

**ar-Q0514 · Build the sentence**

Arrange: شيء. / كل / لي / قال

He told me everything.

[[Arabic#^ar-Q0514-answer|Compare the answer]]
^ar-Q0514

**ar-Q0515 · Write a translation**

Write this in Arabic: I want to learn Romanian.

[[Arabic#^ar-Q0515-answer|Compare the answer]]
^ar-Q0515

**ar-Q0516 · Explain the grammar**

【أريد】 تعلم الرومانية.

I want to learn Romanian.

[[Arabic#^ar-Q0516-answer|Compare the answer]]
^ar-Q0516

**ar-Q0517 · Fill the gap**

هل ____ أن تفعلها الآن؟

Do you want to do it right now?

[[Arabic#^ar-Q0517-answer|Compare the answer]]
^ar-Q0517

**ar-Q0518 · Choose the form**

هل ____ أن تفعلها الآن؟

Do you want to do it right now?

Choices: يريد / أريد / أعرف / تريد

[[Arabic#^ar-Q0518-answer|Compare the answer]]
^ar-Q0518

**ar-Q0519 · Edit the changed sentence**

أحبك و 【يريد】 أن أتزوجك.

I'm in love with you and I want to marry you.

[[Arabic#^ar-Q0519-answer|Compare the answer]]
^ar-Q0519

**ar-Q0520 · Build the sentence**

Arrange: أن / أحبك / و / أريد / أتزوجك.

I'm in love with you and I want to marry you.

[[Arabic#^ar-Q0520-answer|Compare the answer]]
^ar-Q0520

**ar-Q0521 · Write a translation**

Write this in Arabic: Sami doesn't even know Layla.

[[Arabic#^ar-Q0521-answer|Compare the answer]]
^ar-Q0521

**ar-Q0522 · Explain the grammar**

سامي لا 【يعرف】 ليلى حتّى.

Sami doesn't even know Layla.

[[Arabic#^ar-Q0522-answer|Compare the answer]]
^ar-Q0522

**ar-Q0523 · Fill the gap**

أنا ____ السباحة, ولكن لا أحب أن أسبح هنا.

I like swimming, but I don't like to swim here.

[[Arabic#^ar-Q0523-answer|Compare the answer]]
^ar-Q0523

**ar-Q0524 · Choose the form**

أنا ____ السباحة, ولكن لا أحب أن أسبح هنا.

I like swimming, but I don't like to swim here.

Choices: أريد / يريد / أحب / أعرف

[[Arabic#^ar-Q0524-answer|Compare the answer]]
^ar-Q0524

**ar-Q0525 · Edit the changed sentence**

【أريد】 فيليب: تعال و تحقق بنفسك.

"Come and see", said Philip.

[[Arabic#^ar-Q0525-answer|Compare the answer]]
^ar-Q0525

**ar-Q0526 · Build the sentence**

Arrange: تعال / فيليب: / تحقق / قال / بنفسك. / و

"Come and see", said Philip.

[[Arabic#^ar-Q0526-answer|Compare the answer]]
^ar-Q0526

**ar-Q0527 · Write a translation**

Write this in Arabic: I think that he's the world's most courageous fire fighter.

[[Arabic#^ar-Q0527-answer|Compare the answer]]
^ar-Q0527

**ar-Q0528 · Explain the grammar**

【أعتقد】 أنّه أكثر رجال الإطفاء شجاعة في العالم.

I think that he's the world's most courageous fire fighter.

[[Arabic#^ar-Q0528-answer|Compare the answer]]
^ar-Q0528

**ar-Q0529 · Fill the gap**

____ أن أصير دكتورًا.

I want to become a doctor.

[[Arabic#^ar-Q0529-answer|Compare the answer]]
^ar-Q0529

**ar-Q0530 · Choose the form**

____ أن أصير دكتورًا.

I want to become a doctor.

Choices: يريد / أريد / يعرف / أعرف

[[Arabic#^ar-Q0530-answer|Compare the answer]]
^ar-Q0530

**ar-Q0531 · Edit the changed sentence**

لا 【يريد】 أن ينتهي زواجنا.

I don't want our marriage to end.

[[Arabic#^ar-Q0531-answer|Compare the answer]]
^ar-Q0531

**ar-Q0532 · Build the sentence**

Arrange: ينتهي / زواجنا. / أريد / أن / لا

I don't want our marriage to end.

[[Arabic#^ar-Q0532-answer|Compare the answer]]
^ar-Q0532

**ar-Q0533 · Write a translation**

Write this in Arabic: I want to forget about it.

[[Arabic#^ar-Q0533-answer|Compare the answer]]
^ar-Q0533

**ar-Q0534 · Explain the grammar**

【أريد】 أن أنسى الأمر.

I want to forget about it.

[[Arabic#^ar-Q0534-answer|Compare the answer]]
^ar-Q0534

**ar-Q0535 · Fill the gap**

____ رؤية توم قبل مغادرتي.

I want to see Tom before I leave.

[[Arabic#^ar-Q0535-answer|Compare the answer]]
^ar-Q0535

**ar-Q0536 · Choose the form**

____ رؤية توم قبل مغادرتي.

I want to see Tom before I leave.

Choices: أعرف / يعرف / أريد / يريد

[[Arabic#^ar-Q0536-answer|Compare the answer]]
^ar-Q0536

**ar-Q0537 · Edit the changed sentence**

【يريد】 أن أتعلّم الأمازيغية و العربية.

I want to learn Berber and Arabic.

[[Arabic#^ar-Q0537-answer|Compare the answer]]
^ar-Q0537

**ar-Q0538 · Build the sentence**

Arrange: العربية. / الأمازيغية / أريد / أن / و / أتعلّم

I want to learn Berber and Arabic.

[[Arabic#^ar-Q0538-answer|Compare the answer]]
^ar-Q0538

**ar-Q0539 · Write a translation**

Write this in Arabic: After Jamal, I don't think she has had any other boyfriend.

[[Arabic#^ar-Q0539-answer|Compare the answer]]
^ar-Q0539

**ar-Q0540 · Explain the grammar**

لا 【أعتقد】 أنه كان لديها صديق آخر بعد أن فارقت جمال.

After Jamal, I don't think she has had any other boyfriend.

[[Arabic#^ar-Q0540-answer|Compare the answer]]
^ar-Q0540

**ar-Q0541 · Fill the gap**

أي شخص ____ القدوم فهو مدعوّ.

Anybody who wants to come is invited.

[[Arabic#^ar-Q0541-answer|Compare the answer]]
^ar-Q0541

**ar-Q0542 · Choose the form**

أي شخص ____ القدوم فهو مدعوّ.

Anybody who wants to come is invited.

Choices: أعرف / يريد / يعرف / أريد

[[Arabic#^ar-Q0542-answer|Compare the answer]]
^ar-Q0542

**ar-Q0543 · Edit the changed sentence**

لا 【يريد】 أن أعمل.

I don't want to work.

[[Arabic#^ar-Q0543-answer|Compare the answer]]
^ar-Q0543

**ar-Q0544 · Build the sentence**

Arrange: أن / لا / أريد / أعمل.

I don't want to work.

[[Arabic#^ar-Q0544-answer|Compare the answer]]
^ar-Q0544

**ar-Q0545 · Write a translation**

Write this in Arabic: I don't want Sami here.

[[Arabic#^ar-Q0545-answer|Compare the answer]]
^ar-Q0545

**ar-Q0546 · Explain the grammar**

لا 【أريد】 سامي هنا.

I don't want Sami here.

[[Arabic#^ar-Q0546-answer|Compare the answer]]
^ar-Q0546

**ar-Q0547 · Fill the gap**

سامي ____ّ ليلى.

Sami likes Layla.

[[Arabic#^ar-Q0547-answer|Compare the answer]]
^ar-Q0547

**ar-Q0548 · Choose the form**

سامي ____ّ ليلى.

Sami likes Layla.

Choices: أعرف / يحب / يريد / أريد

[[Arabic#^ar-Q0548-answer|Compare the answer]]
^ar-Q0548

**ar-Q0549 · Edit the changed sentence**

إنها 【أريد】 أن تعمل في المستشفى.

She wants to work at the hospital.

[[Arabic#^ar-Q0549-answer|Compare the answer]]
^ar-Q0549

**ar-Q0550 · Build the sentence**

Arrange: إنها / المستشفى. / أن / تعمل / في / تريد

She wants to work at the hospital.

[[Arabic#^ar-Q0550-answer|Compare the answer]]
^ar-Q0550


### Future markers · 50 questions

**ar-Q0551 · Write a translation**

Write this in Arabic: We'll have plenty of food.

[[Arabic#^ar-Q0551-answer|Compare the answer]]
^ar-Q0551

**ar-Q0552 · Explain the grammar**

【سوف】 يكون عندنا الكثير من الطعام.

We'll have plenty of food.

[[Arabic#^ar-Q0552-answer|Compare the answer]]
^ar-Q0552

**ar-Q0553 · Fill the gap**

____ أشتري هديّة لتوم.

I'll buy a gift for Tom.

[[Arabic#^ar-Q0553-answer|Compare the answer]]
^ar-Q0553

**ar-Q0554 · Choose the form**

____ أشتري هديّة لتوم.

I'll buy a gift for Tom.

Choices: سي / سوف / سأ

[[Arabic#^ar-Q0554-answer|Compare the answer]]
^ar-Q0554

**ar-Q0555 · Edit the changed sentence**

لقد وعدني أنه 【سوف】 على الساعة الرابعة.

He promised me that he would come at four.

[[Arabic#^ar-Q0555-answer|Compare the answer]]
^ar-Q0555

**ar-Q0556 · Build the sentence**

Arrange: لقد / على / الساعة / أنه / سيأتي / الرابعة. / وعدني

He promised me that he would come at four.

[[Arabic#^ar-Q0556-answer|Compare the answer]]
^ar-Q0556

**ar-Q0557 · Write a translation**

Write this in Arabic: I will be back soon.

[[Arabic#^ar-Q0557-answer|Compare the answer]]
^ar-Q0557

**ar-Q0558 · Explain the grammar**

【سوف】 أعود بعد قليل.

I will be back soon.

[[Arabic#^ar-Q0558-answer|Compare the answer]]
^ar-Q0558

**ar-Q0559 · Fill the gap**

____ اقابله غدا.

I'll meet him tomorrow.

[[Arabic#^ar-Q0559-answer|Compare the answer]]
^ar-Q0559

**ar-Q0560 · Choose the form**

____ اقابله غدا.

I'll meet him tomorrow.

Choices: سوف / سي / سأ

[[Arabic#^ar-Q0560-answer|Compare the answer]]
^ar-Q0560

**ar-Q0561 · Edit the changed sentence**

أين 【سوف】 في الأوّل من جانفي 2016؟

Where will you be on January 1st, 2016?

[[Arabic#^ar-Q0561-answer|Compare the answer]]
^ar-Q0561

**ar-Q0562 · Build the sentence**

Arrange: الأوّل / من / ستكون / أين / جانفي / في / 2016؟

Where will you be on January 1st, 2016?

[[Arabic#^ar-Q0562-answer|Compare the answer]]
^ar-Q0562

**ar-Q0563 · Write a translation**

Write this in Arabic: The program will finish with the national anthem.

[[Arabic#^ar-Q0563-answer|Compare the answer]]
^ar-Q0563

**ar-Q0564 · Explain the grammar**

البرنامج 【سوف】 ينتهي بالنشيد الوطني .

The program will finish with the national anthem.

[[Arabic#^ar-Q0564-answer|Compare the answer]]
^ar-Q0564

**ar-Q0565 · Fill the gap**

____ وآخذ حمّاما.

I'm going to go take a shower.

[[Arabic#^ar-Q0565-answer|Compare the answer]]
^ar-Q0565

**ar-Q0566 · Choose the form**

____ وآخذ حمّاما.

I'm going to go take a shower.

Choices: سي / سوف / سأ / سأذهب

[[Arabic#^ar-Q0566-answer|Compare the answer]]
^ar-Q0566

**ar-Q0567 · Edit the changed sentence**

【سوف】 سامي على ما يرام.

Sami is going to be OK.

[[Arabic#^ar-Q0567-answer|Compare the answer]]
^ar-Q0567

**ar-Q0568 · Build the sentence**

Arrange: يرام. / على / سيكون / ما / سامي

Sami is going to be OK.

[[Arabic#^ar-Q0568-answer|Compare the answer]]
^ar-Q0568

**ar-Q0569 · Write a translation**

Write this in Arabic: Most of us will do that.

[[Arabic#^ar-Q0569-answer|Compare the answer]]
^ar-Q0569

**ar-Q0570 · Explain the grammar**

أغلبنا 【سيفعل】 هذا.

Most of us will do that.

[[Arabic#^ar-Q0570-answer|Compare the answer]]
^ar-Q0570

**ar-Q0571 · Fill the gap**

هل ____ غداً؟

Will he come tomorrow?

[[Arabic#^ar-Q0571-answer|Compare the answer]]
^ar-Q0571

**ar-Q0572 · Choose the form**

هل ____ غداً؟

Will he come tomorrow?

Choices: سيأتي / سي / سوف / سأ

[[Arabic#^ar-Q0572-answer|Compare the answer]]
^ar-Q0572

**ar-Q0573 · Edit the changed sentence**

【سوف】 مشغولاً في الغد.

You will be busy tomorrow.

[[Arabic#^ar-Q0573-answer|Compare the answer]]
^ar-Q0573

**ar-Q0574 · Build the sentence**

Arrange: في / مشغولاً / ستكون / الغد.

You will be busy tomorrow.

[[Arabic#^ar-Q0574-answer|Compare the answer]]
^ar-Q0574

**ar-Q0575 · Write a translation**

Write this in Arabic: I am going to do it whether you agree or not.

[[Arabic#^ar-Q0575-answer|Compare the answer]]
^ar-Q0575

**ar-Q0576 · Explain the grammar**

【سوف】 أفعلها سواءاً وافقت أم لم توافق.

I am going to do it whether you agree or not.

[[Arabic#^ar-Q0576-answer|Compare the answer]]
^ar-Q0576

**ar-Q0577 · Fill the gap**

خمسة عشر في المئة من المساكن ____ بأسعار معقولة، بحيث أن الأسر ذات الدخل المنخفض سوف تصبح قادرة على شراء أو استئجار المنازل في المنطقة.

Fifteen per cent of the housing will be affordable, so that low-income families will be able to buy or rent homes in the area.

[[Arabic#^ar-Q0577-answer|Compare the answer]]
^ar-Q0577

**ar-Q0578 · Choose the form**

خمسة عشر في المئة من المساكن ____ بأسعار معقولة، بحيث أن الأسر ذات الدخل المنخفض سوف تصبح قادرة على شراء أو استئجار المنازل في المنطقة.

Fifteen per cent of the housing will be affordable, so that low-income families will be able to buy or rent homes in the area.

Choices: ستكون / سي / سوف / سأ

[[Arabic#^ar-Q0578-answer|Compare the answer]]
^ar-Q0578

**ar-Q0579 · Edit the changed sentence**

حتى و لو أمطرت، 【سوف】 للسباحة غدا.

Even if it rains, I'll go swimming tomorrow.

[[Arabic#^ar-Q0579-answer|Compare the answer]]
^ar-Q0579

**ar-Q0580 · Build the sentence**

Arrange: للسباحة / و / لو / غدا. / حتى / سأذهب / أمطرت،

Even if it rains, I'll go swimming tomorrow.

[[Arabic#^ar-Q0580-answer|Compare the answer]]
^ar-Q0580

**ar-Q0581 · Write a translation**

Write this in Arabic: I'm going to be in the bathroom.

[[Arabic#^ar-Q0581-answer|Compare the answer]]
^ar-Q0581

**ar-Q0582 · Explain the grammar**

【سأكون】 في الحمام.

I'm going to be in the bathroom.

[[Arabic#^ar-Q0582-answer|Compare the answer]]
^ar-Q0582

**ar-Q0583 · Fill the gap**

إن كنت ستبدأ عملا جديدا، ف____ عليك تجهيز خطة.

If you're going to start a new business, you need a business plan.

[[Arabic#^ar-Q0583-answer|Compare the answer]]
^ar-Q0583

**ar-Q0584 · Choose the form**

إن كنت ستبدأ عملا جديدا، ف____ عليك تجهيز خطة.

If you're going to start a new business, you need a business plan.

Choices: سوف / سيكون / سأ / سي

[[Arabic#^ar-Q0584-answer|Compare the answer]]
^ar-Q0584

**ar-Q0585 · Edit the changed sentence**

【سأ】 يكون في البيت غداً.

He will be at home tomorrow.

[[Arabic#^ar-Q0585-answer|Compare the answer]]
^ar-Q0585

**ar-Q0586 · Build the sentence**

Arrange: غداً. / البيت / في / يكون / سوف

He will be at home tomorrow.

[[Arabic#^ar-Q0586-answer|Compare the answer]]
^ar-Q0586

**ar-Q0587 · Write a translation**

Write this in Arabic: If the weather is good, I'll go to the park.

[[Arabic#^ar-Q0587-answer|Compare the answer]]
^ar-Q0587

**ar-Q0588 · Explain the grammar**

لو كان الجو جيدا 【سأذهب】 إلى الحديقة

If the weather is good, I'll go to the park.

[[Arabic#^ar-Q0588-answer|Compare the answer]]
^ar-Q0588

**ar-Q0589 · Fill the gap**

أنا لست متأكّداً أنّني ____ قادراً على القدوم معك

I am not sure whether I will be able to come with you.

[[Arabic#^ar-Q0589-answer|Compare the answer]]
^ar-Q0589

**ar-Q0590 · Choose the form**

أنا لست متأكّداً أنّني ____ قادراً على القدوم معك

I am not sure whether I will be able to come with you.

Choices: سأ / سي / سأكون / سوف

[[Arabic#^ar-Q0590-answer|Compare the answer]]
^ar-Q0590

**ar-Q0591 · Edit the changed sentence**

【سوف】 حسنًا منك أن تخبره مقدمًا.

You would do well to tell it to him in advance.

[[Arabic#^ar-Q0591-answer|Compare the answer]]
^ar-Q0591

**ar-Q0592 · Build the sentence**

Arrange: تخبره / حسنًا / مقدمًا. / منك / أن / سيكون

You would do well to tell it to him in advance.

[[Arabic#^ar-Q0592-answer|Compare the answer]]
^ar-Q0592

**ar-Q0593 · Write a translation**

Write this in Arabic: I'm going to pick up Sami at Layla's house.

[[Arabic#^ar-Q0593-answer|Compare the answer]]
^ar-Q0593

**ar-Q0594 · Explain the grammar**

【سأذهب】 لإقلال سامي من منزل ليلى.

I'm going to pick up Sami at Layla's house.

[[Arabic#^ar-Q0594-answer|Compare the answer]]
^ar-Q0594

**ar-Q0595 · Fill the gap**

____ يتوقف المطر قريبا

It'll stop raining before long.

[[Arabic#^ar-Q0595-answer|Compare the answer]]
^ar-Q0595

**ar-Q0596 · Choose the form**

____ يتوقف المطر قريبا

It'll stop raining before long.

Choices: سوف / سأ / سي

[[Arabic#^ar-Q0596-answer|Compare the answer]]
^ar-Q0596

**ar-Q0597 · Edit the changed sentence**

【سوف】 على سامي المغادرة.

Sami will have to leave.

[[Arabic#^ar-Q0597-answer|Compare the answer]]
^ar-Q0597

**ar-Q0598 · Build the sentence**

Arrange: سيكون / سامي / على / المغادرة.

Sami will have to leave.

[[Arabic#^ar-Q0598-answer|Compare the answer]]
^ar-Q0598

**ar-Q0599 · Write a translation**

Write this in Arabic: I'll eat the apple.

[[Arabic#^ar-Q0599-answer|Compare the answer]]
^ar-Q0599

**ar-Q0600 · Explain the grammar**

【سوف】 آكل التفاحة.

I'll eat the apple.

[[Arabic#^ar-Q0600-answer|Compare the answer]]
^ar-Q0600


### Prepositions · 50 questions

**ar-Q0601 · Fill the gap**

نشأ سامي ____ مجتمع مسلم.

Sami grew up in a Muslim community.

[[Arabic#^ar-Q0601-answer|Compare the answer]]
^ar-Q0601

**ar-Q0602 · Choose the form**

نشأ سامي ____ مجتمع مسلم.

Sami grew up in a Muslim community.

Choices: إلى / في / على / من

[[Arabic#^ar-Q0602-answer|Compare the answer]]
^ar-Q0602

**ar-Q0603 · Edit the changed sentence**

بإمكانك استخدامها 【على】 أي وقت.

You can use it anytime.

[[Arabic#^ar-Q0603-answer|Compare the answer]]
^ar-Q0603

**ar-Q0604 · Build the sentence**

Arrange: بإمكانك / وقت. / في / أي / استخدامها

You can use it anytime.

[[Arabic#^ar-Q0604-answer|Compare the answer]]
^ar-Q0604

**ar-Q0605 · Write a translation**

Write this in Arabic: I was invited to Sachiko's party.

[[Arabic#^ar-Q0605-answer|Compare the answer]]
^ar-Q0605

**ar-Q0606 · Explain the grammar**

دُعيتُ 【إلى】 حفلة ساتشِكو.

I was invited to Sachiko's party.

[[Arabic#^ar-Q0606-answer|Compare the answer]]
^ar-Q0606

**ar-Q0607 · Fill the gap**

سامي ____ مصر.

Sami is from Egypt.

[[Arabic#^ar-Q0607-answer|Compare the answer]]
^ar-Q0607

**ar-Q0608 · Choose the form**

سامي ____ مصر.

Sami is from Egypt.

Choices: في / على / إلى / من

[[Arabic#^ar-Q0608-answer|Compare the answer]]
^ar-Q0608

**ar-Q0609 · Edit the changed sentence**

【في】ّاد يقطن في منزل رائع.

Sami lives in a wonderful house.

[[Arabic#^ar-Q0609-answer|Compare the answer]]
^ar-Q0609

**ar-Q0610 · Build the sentence**

Arrange: منزل / في / رائع. / منّاد / يقطن

Sami lives in a wonderful house.

[[Arabic#^ar-Q0610-answer|Compare the answer]]
^ar-Q0610

**ar-Q0611 · Write a translation**

Write this in Arabic: In 1948, a Jewish state was founded.

[[Arabic#^ar-Q0611-answer|Compare the answer]]
^ar-Q0611

**ar-Q0612 · Explain the grammar**

【في】 عام ١٩٤٨م ، تأسست دولة يهودية.

In 1948, a Jewish state was founded.

[[Arabic#^ar-Q0612-answer|Compare the answer]]
^ar-Q0612

**ar-Q0613 · Fill the gap**

ضحّت ليلى بسامي كي تخرج نفسها ____ المأزق.

Layla threw Sami under the bus.

[[Arabic#^ar-Q0613-answer|Compare the answer]]
^ar-Q0613

**ar-Q0614 · Choose the form**

ضحّت ليلى بسامي كي تخرج نفسها ____ المأزق.

Layla threw Sami under the bus.

Choices: في / من / على / إلى

[[Arabic#^ar-Q0614-answer|Compare the answer]]
^ar-Q0614

**ar-Q0615 · Edit the changed sentence**

أختك تحب مشاهدة مبارزة السومو 【في】 التلفاز.

Your sister enjoys watching sumo wrestling on TV.

[[Arabic#^ar-Q0615-answer|Compare the answer]]
^ar-Q0615

**ar-Q0616 · Build the sentence**

Arrange: السومو / التلفاز. / تحب / على / مشاهدة / مبارزة / أختك

Your sister enjoys watching sumo wrestling on TV.

[[Arabic#^ar-Q0616-answer|Compare the answer]]
^ar-Q0616

**ar-Q0617 · Write a translation**

Write this in Arabic: Sometimes you scare me.

[[Arabic#^ar-Q0617-answer|Compare the answer]]
^ar-Q0617

**ar-Q0618 · Explain the grammar**

إنك تخيفني 【في】 بعض الأحيان.

Sometimes you scare me.

[[Arabic#^ar-Q0618-answer|Compare the answer]]
^ar-Q0618

**ar-Q0619 · Fill the gap**

صعدت ____ الحافلة الخطأ.

I got on the wrong bus.

[[Arabic#^ar-Q0619-answer|Compare the answer]]
^ar-Q0619

**ar-Q0620 · Choose the form**

صعدت ____ الحافلة الخطأ.

I got on the wrong bus.

Choices: على / من / في / إلى

[[Arabic#^ar-Q0620-answer|Compare the answer]]
^ar-Q0620

**ar-Q0621 · Edit the changed sentence**

وضع فاضل جثة دانية 【على】 مزبلة.

Fadil stuffed Dania's body into a trash can.

[[Arabic#^ar-Q0621-answer|Compare the answer]]
^ar-Q0621

**ar-Q0622 · Build the sentence**

Arrange: دانية / مزبلة. / وضع / فاضل / جثة / في

Fadil stuffed Dania's body into a trash can.

[[Arabic#^ar-Q0622-answer|Compare the answer]]
^ar-Q0622

**ar-Q0623 · Write a translation**

Write this in Arabic: He looked up at the sky.

[[Arabic#^ar-Q0623-answer|Compare the answer]]
^ar-Q0623

**ar-Q0624 · Explain the grammar**

نظر 【إلى】 السماء.

He looked up at the sky.

[[Arabic#^ar-Q0624-answer|Compare the answer]]
^ar-Q0624

**ar-Q0625 · Fill the gap**

واصل سامي بناء مشواره الفنّي ____ موسيقى الهيبهوب.

Sami continued building his hiphop musical career.

[[Arabic#^ar-Q0625-answer|Compare the answer]]
^ar-Q0625

**ar-Q0626 · Choose the form**

واصل سامي بناء مشواره الفنّي ____ موسيقى الهيبهوب.

Sami continued building his hiphop musical career.

Choices: في / إلى / من / على

[[Arabic#^ar-Q0626-answer|Compare the answer]]
^ar-Q0626

**ar-Q0627 · Edit the changed sentence**

اثنان وخمسون بالمئة 【في】 النساء البريطانيات يفضلن الشوكولاته على الجنس.

Fifty-two per cent of British women prefer chocolate to sex.

[[Arabic#^ar-Q0627-answer|Compare the answer]]
^ar-Q0627

**ar-Q0628 · Build the sentence**

Arrange: اثنان / من / الشوكولاته / على / النساء / البريطانيات / بالمئة / وخمسون / الجنس. / يفضلن

Fifty-two per cent of British women prefer chocolate to sex.

[[Arabic#^ar-Q0628-answer|Compare the answer]]
^ar-Q0628

**ar-Q0629 · Write a translation**

Write this in Arabic: Will you help me with my homework?

[[Arabic#^ar-Q0629-answer|Compare the answer]]
^ar-Q0629

**ar-Q0630 · Explain the grammar**

هل تساعدني 【في】 حل واجبي؟

Will you help me with my homework?

[[Arabic#^ar-Q0630-answer|Compare the answer]]
^ar-Q0630

**ar-Q0631 · Fill the gap**

انتقل ____ منزلي.

Move in here.

[[Arabic#^ar-Q0631-answer|Compare the answer]]
^ar-Q0631

**ar-Q0632 · Choose the form**

انتقل ____ منزلي.

Move in here.

Choices: إلى / في / على / من

[[Arabic#^ar-Q0632-answer|Compare the answer]]
^ar-Q0632

**ar-Q0633 · Edit the changed sentence**

انظر إليّ 【في】 فضلك.

Please look at me.

[[Arabic#^ar-Q0633-answer|Compare the answer]]
^ar-Q0633

**ar-Q0634 · Build the sentence**

Arrange: انظر / إليّ / فضلك. / من

Please look at me.

[[Arabic#^ar-Q0634-answer|Compare the answer]]
^ar-Q0634

**ar-Q0635 · Write a translation**

Write this in Arabic: Mt. Fuji is covered with snow in winter.

[[Arabic#^ar-Q0635-answer|Compare the answer]]
^ar-Q0635

**ar-Q0636 · Explain the grammar**

يصبح جبل فوجي مغطًى بالثلج 【في】 الشتاء.

Mt. Fuji is covered with snow in winter.

[[Arabic#^ar-Q0636-answer|Compare the answer]]
^ar-Q0636

**ar-Q0637 · Fill the gap**

سامي ____ سوق والمارت.

Sami is at Walmart.

[[Arabic#^ar-Q0637-answer|Compare the answer]]
^ar-Q0637

**ar-Q0638 · Choose the form**

سامي ____ سوق والمارت.

Sami is at Walmart.

Choices: إلى / من / على / في

[[Arabic#^ar-Q0638-answer|Compare the answer]]
^ar-Q0638

**ar-Q0639 · Edit the changed sentence**

【في】 الصعب أن تستيقظ بدون أن تتناول فنجانا من القهوة المركزة.

It is hard to wake up without a strong cup of coffee.

[[Arabic#^ar-Q0639-answer|Compare the answer]]
^ar-Q0639

**ar-Q0640 · Build the sentence**

Arrange: من / تستيقظ / بدون / الصعب / من / القهوة / فنجانا / المركزة. / تتناول / أن / أن

It is hard to wake up without a strong cup of coffee.

[[Arabic#^ar-Q0640-answer|Compare the answer]]
^ar-Q0640

**ar-Q0641 · Write a translation**

Write this in Arabic: Do your best in everything.

[[Arabic#^ar-Q0641-answer|Compare the answer]]
^ar-Q0641

**ar-Q0642 · Explain the grammar**

ابذل وسعك 【في】 كل شيء .

Do your best in everything.

[[Arabic#^ar-Q0642-answer|Compare the answer]]
^ar-Q0642

**ar-Q0643 · Fill the gap**

أعلم ____ من تكلم توم.

I knew who Tom had talked to.

[[Arabic#^ar-Q0643-answer|Compare the answer]]
^ar-Q0643

**ar-Q0644 · Choose the form**

أعلم ____ من تكلم توم.

I knew who Tom had talked to.

Choices: من / مع / في / على

[[Arabic#^ar-Q0644-answer|Compare the answer]]
^ar-Q0644

**ar-Q0645 · Edit the changed sentence**

【في】 حظنا وجود توم هنا ليساعدنا.

We're lucky Tom is here to help us.

[[Arabic#^ar-Q0645-answer|Compare the answer]]
^ar-Q0645

**ar-Q0646 · Build the sentence**

Arrange: حظنا / هنا / وجود / توم / ليساعدنا. / من

We're lucky Tom is here to help us.

[[Arabic#^ar-Q0646-answer|Compare the answer]]
^ar-Q0646

**ar-Q0647 · Write a translation**

Write this in Arabic: Sami is watching Layla's YouTube video.

[[Arabic#^ar-Q0647-answer|Compare the answer]]
^ar-Q0647

**ar-Q0648 · Explain the grammar**

سامي يشاهد فيديو ليلى 【على】 اليوتوب.

Sami is watching Layla's YouTube video.

[[Arabic#^ar-Q0648-answer|Compare the answer]]
^ar-Q0648

**ar-Q0649 · Fill the gap**

____ فضلك رتب السرير.

Please make the bed.

[[Arabic#^ar-Q0649-answer|Compare the answer]]
^ar-Q0649

**ar-Q0650 · Choose the form**

____ فضلك رتب السرير.

Please make the bed.

Choices: من / إلى / على / في

[[Arabic#^ar-Q0650-answer|Compare the answer]]
^ar-Q0650


### Relative forms · 50 questions

**ar-Q0651 · Edit the changed sentence**

قام توم بنفس الشيء 【التي】 قامت به ماريا

Tom did the same thing Mary did.

[[Arabic#^ar-Q0651-answer|Compare the answer]]
^ar-Q0651

**ar-Q0652 · Build the sentence**

Arrange: ماريا / توم / قامت / الذي / به / بنفس / الشيء / قام

Tom did the same thing Mary did.

[[Arabic#^ar-Q0652-answer|Compare the answer]]
^ar-Q0652

**ar-Q0653 · Write a translation**

Write this in Arabic: Tom showed me the poems that he'd written when he was a teenager.

[[Arabic#^ar-Q0653-answer|Compare the answer]]
^ar-Q0653

**ar-Q0654 · Explain the grammar**

أراني توم القصائد 【التي】 كتبها حين كان مراهقا.

Tom showed me the poems that he'd written when he was a teenager.

[[Arabic#^ar-Q0654-answer|Compare the answer]]
^ar-Q0654

**ar-Q0655 · Fill the gap**

العباقرة من الناس كالشهبُ ____ قُدِّر لها أن تحترق لتضيء زمنها.

Men of genius are meteors destined to burn in order to illuminate their century.

[[Arabic#^ar-Q0655-answer|Compare the answer]]
^ar-Q0655

**ar-Q0656 · Choose the form**

العباقرة من الناس كالشهبُ ____ قُدِّر لها أن تحترق لتضيء زمنها.

Men of genius are meteors destined to burn in order to illuminate their century.

Choices: الذين / الذي / التي

[[Arabic#^ar-Q0656-answer|Compare the answer]]
^ar-Q0656

**ar-Q0657 · Edit the changed sentence**

أيمكنك قراءة اللافتة 【الذي】 أمامنا؟

Can you read that sign ahead of us?

[[Arabic#^ar-Q0657-answer|Compare the answer]]
^ar-Q0657

**ar-Q0658 · Build the sentence**

Arrange: أمامنا؟ / قراءة / اللافتة / التي / أيمكنك

Can you read that sign ahead of us?

[[Arabic#^ar-Q0658-answer|Compare the answer]]
^ar-Q0658

**ar-Q0659 · Write a translation**

Write this in Arabic: Look at the instructions on the package of tapioca that you buy.

[[Arabic#^ar-Q0659-answer|Compare the answer]]
^ar-Q0659

**ar-Q0660 · Explain the grammar**

أنظر على التعليمات الموجودة على عبوة التابيوكا 【التي】 تشتريها.

Look at the instructions on the package of tapioca that you buy.

[[Arabic#^ar-Q0660-answer|Compare the answer]]
^ar-Q0660

**ar-Q0661 · Fill the gap**

طالت الخسائر ____ خلفها الإعصار الكثير من المحافظات.

The damage of the typhoon spread over several prefectures.

[[Arabic#^ar-Q0661-answer|Compare the answer]]
^ar-Q0661

**ar-Q0662 · Choose the form**

طالت الخسائر ____ خلفها الإعصار الكثير من المحافظات.

The damage of the typhoon spread over several prefectures.

Choices: الذي / التي / الذين

[[Arabic#^ar-Q0662-answer|Compare the answer]]
^ar-Q0662

**ar-Q0663 · Edit the changed sentence**

لهذا فإن تتويبا متعدد اللغات. لكن ليس ذلك النوع من تعدد اللغات، ليس النوع 【التي】 يُزَاوج فيه بين اللغات، ببساطة، وتُهْمَلُ بعض الأزواج.

This is why Tatoeba is multilingual. But not that kind of multilingual. Not the kind where languages are simply being paired up together, and where some pairs are left behind.

[[Arabic#^ar-Q0663-answer|Compare the answer]]
^ar-Q0663

**ar-Q0664 · Build the sentence**

Arrange: ليس / تتويبا / لهذا / بين / النوع / فإن / ليس / النوع / متعدد / تعدد / يُزَاوج / الذي / اللغات، / اللغات. / لكن / من / وتُهْمَلُ / بعض / ذلك / اللغات، / ببساطة، / الأزواج. / فيه

This is why Tatoeba is multilingual. But not that kind of multilingual. Not the kind where languages are simply being paired up together, and where some pairs are left behind.

[[Arabic#^ar-Q0664-answer|Compare the answer]]
^ar-Q0664

**ar-Q0665 · Write a translation**

Write this in Arabic: Change is the only constant.

[[Arabic#^ar-Q0665-answer|Compare the answer]]
^ar-Q0665

**ar-Q0666 · Explain the grammar**

التغيير هو الشيء الوحيد 【الذي】 لا يتغير.

Change is the only constant.

[[Arabic#^ar-Q0666-answer|Compare the answer]]
^ar-Q0666

**ar-Q0667 · Fill the gap**

لم أفهم الطرفة ____ قصها علينا.

I couldn't catch on to the joke he told us.

[[Arabic#^ar-Q0667-answer|Compare the answer]]
^ar-Q0667

**ar-Q0668 · Choose the form**

لم أفهم الطرفة ____ قصها علينا.

I couldn't catch on to the joke he told us.

Choices: التي / الذي / الذين

[[Arabic#^ar-Q0668-answer|Compare the answer]]
^ar-Q0668

**ar-Q0669 · Edit the changed sentence**

فتّشت الشّرطة حاوية النّفايات 【الذي】 كانت خلف مكتب سامي.

Police searched the dumpster behind Sami's office.

[[Arabic#^ar-Q0669-answer|Compare the answer]]
^ar-Q0669

**ar-Q0670 · Build the sentence**

Arrange: فتّشت / كانت / خلف / النّفايات / الشّرطة / سامي. / مكتب / حاوية / التي

Police searched the dumpster behind Sami's office.

[[Arabic#^ar-Q0670-answer|Compare the answer]]
^ar-Q0670

**ar-Q0671 · Write a translation**

Write this in Arabic: This is where she lives.

[[Arabic#^ar-Q0671-answer|Compare the answer]]
^ar-Q0671

**ar-Q0672 · Explain the grammar**

هذا هو المكان 【الذي】 تسكن فيه.

This is where she lives.

[[Arabic#^ar-Q0672-answer|Compare the answer]]
^ar-Q0672

**ar-Q0673 · Fill the gap**

ما ____ تفعله بوقت فراغك؟

What do you do in your free time?

[[Arabic#^ar-Q0673-answer|Compare the answer]]
^ar-Q0673

**ar-Q0674 · Choose the form**

ما ____ تفعله بوقت فراغك؟

What do you do in your free time?

Choices: التي / الذين / الذي

[[Arabic#^ar-Q0674-answer|Compare the answer]]
^ar-Q0674

**ar-Q0675 · Edit the changed sentence**

أتذكر البيت 【التي】 نشأت فيه

I remember the house where I grew up.

[[Arabic#^ar-Q0675-answer|Compare the answer]]
^ar-Q0675

**ar-Q0676 · Build the sentence**

Arrange: البيت / الذي / فيه / أتذكر / نشأت

I remember the house where I grew up.

[[Arabic#^ar-Q0676-answer|Compare the answer]]
^ar-Q0676

**ar-Q0677 · Write a translation**

Write this in Arabic: Sami's life is scarred for ever by the day his mom didn't come home.

[[Arabic#^ar-Q0677-answer|Compare the answer]]
^ar-Q0677

**ar-Q0678 · Explain the grammar**

تأثّرت حياة سامي للأبد منذ اليوم 【الذي】 لم تعد فيه أمّه إلى المنزل.

Sami's life is scarred for ever by the day his mom didn't come home.

[[Arabic#^ar-Q0678-answer|Compare the answer]]
^ar-Q0678

**ar-Q0679 · Fill the gap**

من ____ يتولى الزعامة؟

Who has leadership?

[[Arabic#^ar-Q0679-answer|Compare the answer]]
^ar-Q0679

**ar-Q0680 · Choose the form**

من ____ يتولى الزعامة؟

Who has leadership?

Choices: التي / الذين / الذي

[[Arabic#^ar-Q0680-answer|Compare the answer]]
^ar-Q0680

**ar-Q0681 · Edit the changed sentence**

ما 【التي】 تعنيه كلمة "get" في هذه الجملة؟

What does the word "get" mean in this sentence?

[[Arabic#^ar-Q0681-answer|Compare the answer]]
^ar-Q0681

**ar-Q0682 · Build the sentence**

Arrange: تعنيه / الذي / هذه / ما / في / كلمة / الجملة؟ / "get"

What does the word "get" mean in this sentence?

[[Arabic#^ar-Q0682-answer|Compare the answer]]
^ar-Q0682

**ar-Q0683 · Write a translation**

Write this in Arabic: Israel should lift the blockade it imposed on Gaza.

[[Arabic#^ar-Q0683-answer|Compare the answer]]
^ar-Q0683

**ar-Q0684 · Explain the grammar**

على إسرائيل أن ترفع الحصال 【الذي】 فرضته على غزّة.

Israel should lift the blockade it imposed on Gaza.

[[Arabic#^ar-Q0684-answer|Compare the answer]]
^ar-Q0684

**ar-Q0685 · Fill the gap**

لم يُعذّب أحد بالطّريقة ____ عُذّب بها سامي.

No one has ever been tortured the way Sami was.

[[Arabic#^ar-Q0685-answer|Compare the answer]]
^ar-Q0685

**ar-Q0686 · Choose the form**

لم يُعذّب أحد بالطّريقة ____ عُذّب بها سامي.

No one has ever been tortured the way Sami was.

Choices: الذي / الذين / التي

[[Arabic#^ar-Q0686-answer|Compare the answer]]
^ar-Q0686

**ar-Q0687 · Edit the changed sentence**

【التي】 يؤمن به لا يدان.

Whoever believes in him is not condemned.

[[Arabic#^ar-Q0687-answer|Compare the answer]]
^ar-Q0687

**ar-Q0688 · Build the sentence**

Arrange: لا / الذي / يدان. / يؤمن / به

Whoever believes in him is not condemned.

[[Arabic#^ar-Q0688-answer|Compare the answer]]
^ar-Q0688

**ar-Q0689 · Write a translation**

Write this in Arabic: What're you saying?

[[Arabic#^ar-Q0689-answer|Compare the answer]]
^ar-Q0689

**ar-Q0690 · Explain the grammar**

ما 【الذي】 تقوله؟

What're you saying?

[[Arabic#^ar-Q0690-answer|Compare the answer]]
^ar-Q0690

**ar-Q0691 · Fill the gap**

تحوّل فاضل من ذلك الطّفل السّاذج ____ كان يُضايَق في المدرسة إلى مجرم خطير.

Fadil has changed from the naive kid who was abused at school to a dangerous criminal.

[[Arabic#^ar-Q0691-answer|Compare the answer]]
^ar-Q0691

**ar-Q0692 · Choose the form**

تحوّل فاضل من ذلك الطّفل السّاذج ____ كان يُضايَق في المدرسة إلى مجرم خطير.

Fadil has changed from the naive kid who was abused at school to a dangerous criminal.

Choices: الذين / الذي / التي

[[Arabic#^ar-Q0692-answer|Compare the answer]]
^ar-Q0692

**ar-Q0693 · Edit the changed sentence**

النّاس مثلنا، أي 【الذي】 يؤمنون بالفزياء، يعلمون أنّ التّمييز بين الماضي و الحاضر و المستقبل ما هو إلاّ وهم يستمرّ بشكل مستحكم.

People like us, who believe in physics, know that the distinction between past, present, and future is only a stubbornly persistent illusion.

[[Arabic#^ar-Q0693-answer|Compare the answer]]
^ar-Q0693

**ar-Q0694 · Build the sentence**

Arrange: بين / المستقبل / مثلنا، / يعلمون / و / الحاضر / بشكل / يؤمنون / التّمييز / و / إلاّ / الماضي / وهم / بالفزياء، / يستمرّ / ما / النّاس / أي / مستحكم. / الذين / هو / أنّ

People like us, who believe in physics, know that the distinction between past, present, and future is only a stubbornly persistent illusion.

[[Arabic#^ar-Q0694-answer|Compare the answer]]
^ar-Q0694

**ar-Q0695 · Write a translation**

Write this in Arabic: This medicine cured me of my cold.

[[Arabic#^ar-Q0695-answer|Compare the answer]]
^ar-Q0695

**ar-Q0696 · Explain the grammar**

عالج هذا الدواء البرد 【الذي】 أصابني.

This medicine cured me of my cold.

[[Arabic#^ar-Q0696-answer|Compare the answer]]
^ar-Q0696

**ar-Q0697 · Fill the gap**

أين هي الفواتير ____ تريد أن أدفعها؟

Where are the bills that you want me to pay?

[[Arabic#^ar-Q0697-answer|Compare the answer]]
^ar-Q0697

**ar-Q0698 · Choose the form**

أين هي الفواتير ____ تريد أن أدفعها؟

Where are the bills that you want me to pay?

Choices: الذين / التي / الذي

[[Arabic#^ar-Q0698-answer|Compare the answer]]
^ar-Q0698

**ar-Q0699 · Edit the changed sentence**

أضعت الساعة 【الذي】 أعطاني إياها والدي.

I lost the watch Father had given me.

[[Arabic#^ar-Q0699-answer|Compare the answer]]
^ar-Q0699

**ar-Q0700 · Build the sentence**

Arrange: أضعت / والدي. / إياها / أعطاني / التي / الساعة

I lost the watch Father had given me.

[[Arabic#^ar-Q0700-answer|Compare the answer]]
^ar-Q0700


### Content and purpose · 50 questions

**ar-Q0701 · Write a translation**

Write this in Arabic: Have you ever stripped before?

[[Arabic#^ar-Q0701-answer|Compare the answer]]
^ar-Q0701

**ar-Q0702 · Explain the grammar**

هل سبق و 【أن】 قمتِ بعرض للتّعرّي؟

Have you ever stripped before?

[[Arabic#^ar-Q0702-answer|Compare the answer]]
^ar-Q0702

**ar-Q0703 · Fill the gap**

إنه خطر ____ تقود بتهور.

It is dangerous to drive so fast.

[[Arabic#^ar-Q0703-answer|Compare the answer]]
^ar-Q0703

**ar-Q0704 · Choose the form**

إنه خطر ____ تقود بتهور.

It is dangerous to drive so fast.

Choices: أن / أنّ / كي

[[Arabic#^ar-Q0704-answer|Compare the answer]]
^ar-Q0704

**ar-Q0705 · Edit the changed sentence**

لكل فرد الحق 【أنّ】 يلجأ إلى بلاد أخرى أو يحاول الاتجاء إليها هربا من الاضطهاد.

Everyone has the right to seek and to enjoy in other countries asylum from persecution.

[[Arabic#^ar-Q0705-answer|Compare the answer]]
^ar-Q0705

**ar-Q0706 · Build the sentence**

Arrange: هربا / لكل / يحاول / يلجأ / الاتجاء / إلى / إليها / فرد / أخرى / أن / الحق / بلاد / الاضطهاد. / من / أو

Everyone has the right to seek and to enjoy in other countries asylum from persecution.

[[Arabic#^ar-Q0706-answer|Compare the answer]]
^ar-Q0706

**ar-Q0707 · Write a translation**

Write this in Arabic: Sami wanted to meet Muslims.

[[Arabic#^ar-Q0707-answer|Compare the answer]]
^ar-Q0707

**ar-Q0708 · Explain the grammar**

أراد سامي 【أن】 يتعرّف بمسلمين.

Sami wanted to meet Muslims.

[[Arabic#^ar-Q0708-answer|Compare the answer]]
^ar-Q0708

**ar-Q0709 · Fill the gap**

المسلمون يؤمنون ____ محمّدا رسول من الله.

Muslims believe that Muhammad is God's messenger.

[[Arabic#^ar-Q0709-answer|Compare the answer]]
^ar-Q0709

**ar-Q0710 · Choose the form**

المسلمون يؤمنون ____ محمّدا رسول من الله.

Muslims believe that Muhammad is God's messenger.

Choices: أنّ / كي / أن

[[Arabic#^ar-Q0710-answer|Compare the answer]]
^ar-Q0710

**ar-Q0711 · Edit the changed sentence**

يجب 【أنّ】 تشارك أعمالك مع الآخرين.

You must share your jobs with others.

[[Arabic#^ar-Q0711-answer|Compare the answer]]
^ar-Q0711

**ar-Q0712 · Build the sentence**

Arrange: يجب / أن / الآخرين. / أعمالك / تشارك / مع

You must share your jobs with others.

[[Arabic#^ar-Q0712-answer|Compare the answer]]
^ar-Q0712

**ar-Q0713 · Write a translation**

Write this in Arabic: Have you been to London?

[[Arabic#^ar-Q0713-answer|Compare the answer]]
^ar-Q0713

**ar-Q0714 · Explain the grammar**

هل سبق لك 【أن】 ذهبت إلى لندن؟

Have you been to London?

[[Arabic#^ar-Q0714-answer|Compare the answer]]
^ar-Q0714

**ar-Q0715 · Fill the gap**

يستطيع الواحد ____ يجد الوقتَ دائمًا.

One can always find time.

[[Arabic#^ar-Q0715-answer|Compare the answer]]
^ar-Q0715

**ar-Q0716 · Choose the form**

يستطيع الواحد ____ يجد الوقتَ دائمًا.

One can always find time.

Choices: كي / أنّ / أن

[[Arabic#^ar-Q0716-answer|Compare the answer]]
^ar-Q0716

**ar-Q0717 · Edit the changed sentence**

لننسى 【أنّ】ّ شيئا كهذا قد حصل.

Let's forget that this whole thing happened.

[[Arabic#^ar-Q0717-answer|Compare the answer]]
^ar-Q0717

**ar-Q0718 · Build the sentence**

Arrange: أنّ / لننسى / قد / كهذا / شيئا / حصل.

Let's forget that this whole thing happened.

[[Arabic#^ar-Q0718-answer|Compare the answer]]
^ar-Q0718

**ar-Q0719 · Write a translation**

Write this in Arabic: Love can turn toxic.

[[Arabic#^ar-Q0719-answer|Compare the answer]]
^ar-Q0719

**ar-Q0720 · Explain the grammar**

يمكن لعلاقة حبّ 【أن】 تصبح علاقة غير سليمة.

Love can turn toxic.

[[Arabic#^ar-Q0720-answer|Compare the answer]]
^ar-Q0720

**ar-Q0721 · Fill the gap**

دعى سامي لله ____ يغفر له.

Sami asked the Lord to forgive him.

[[Arabic#^ar-Q0721-answer|Compare the answer]]
^ar-Q0721

**ar-Q0722 · Choose the form**

دعى سامي لله ____ يغفر له.

Sami asked the Lord to forgive him.

Choices: أنّ / أن / كي

[[Arabic#^ar-Q0722-answer|Compare the answer]]
^ar-Q0722

**ar-Q0723 · Edit the changed sentence**

من الأفضل لك 【أنّ】 تبقى بعيداً عن توم.

It's better for you to stay away from Tom.

[[Arabic#^ar-Q0723-answer|Compare the answer]]
^ar-Q0723

**ar-Q0724 · Build the sentence**

Arrange: لك / بعيداً / من / عن / الأفضل / تبقى / أن / توم.

It's better for you to stay away from Tom.

[[Arabic#^ar-Q0724-answer|Compare the answer]]
^ar-Q0724

**ar-Q0725 · Write a translation**

Write this in Arabic: Her ambition is to become an ambassador.

[[Arabic#^ar-Q0725-answer|Compare the answer]]
^ar-Q0725

**ar-Q0726 · Explain the grammar**

طموحه 【أن】 يصبح سفيرا.

Her ambition is to become an ambassador.

[[Arabic#^ar-Q0726-answer|Compare the answer]]
^ar-Q0726

**ar-Q0727 · Fill the gap**

____ّا لديها شعر بُني كستنائي, ولكن ماجدالينا لديها شعر أشقر.

Anna has chestnut brown hair, but Magdalena has blonde hair.

[[Arabic#^ar-Q0727-answer|Compare the answer]]
^ar-Q0727

**ar-Q0728 · Choose the form**

____ّا لديها شعر بُني كستنائي, ولكن ماجدالينا لديها شعر أشقر.

Anna has chestnut brown hair, but Magdalena has blonde hair.

Choices: أنّ / كي / أن

[[Arabic#^ar-Q0728-answer|Compare the answer]]
^ar-Q0728

**ar-Q0729 · Edit the changed sentence**

يستطيع طفلهم 【أنّ】 يسير.

Their baby can walk.

[[Arabic#^ar-Q0729-answer|Compare the answer]]
^ar-Q0729

**ar-Q0730 · Build the sentence**

Arrange: يسير. / يستطيع / طفلهم / أن

Their baby can walk.

[[Arabic#^ar-Q0730-answer|Compare the answer]]
^ar-Q0730

**ar-Q0731 · Write a translation**

Write this in Arabic: He decided to be a lawyer.

[[Arabic#^ar-Q0731-answer|Compare the answer]]
^ar-Q0731

**ar-Q0732 · Explain the grammar**

قرر 【أن】 يصبح محامياً

He decided to be a lawyer.

[[Arabic#^ar-Q0732-answer|Compare the answer]]
^ar-Q0732

**ar-Q0733 · Fill the gap**

هل سبق ____ زرت بريطانيا؟

Have you ever been to Britain?

[[Arabic#^ar-Q0733-answer|Compare the answer]]
^ar-Q0733

**ar-Q0734 · Choose the form**

هل سبق ____ زرت بريطانيا؟

Have you ever been to Britain?

Choices: كي / أنّ / أن

[[Arabic#^ar-Q0734-answer|Compare the answer]]
^ar-Q0734

**ar-Q0735 · Edit the changed sentence**

رفض توم 【أنّ】 يفعل أي شيء قذر مع ماري.

Tom refused to soil his hands for Mary.

[[Arabic#^ar-Q0735-answer|Compare the answer]]
^ar-Q0735

**ar-Q0736 · Build the sentence**

Arrange: شيء / رفض / مع / أن / يفعل / أي / توم / ماري. / قذر

Tom refused to soil his hands for Mary.

[[Arabic#^ar-Q0736-answer|Compare the answer]]
^ar-Q0736

**ar-Q0737 · Write a translation**

Write this in Arabic: I think I'd better go back to the shop.

[[Arabic#^ar-Q0737-answer|Compare the answer]]
^ar-Q0737

**ar-Q0738 · Explain the grammar**

أظن 【أنه】 من الأفضل أن أعود إلى المتجر.

I think I'd better go back to the shop.

[[Arabic#^ar-Q0738-answer|Compare the answer]]
^ar-Q0738

**ar-Q0739 · Fill the gap**

أراد سامي ____ يتزوّج من امرأة مسلمة.

Sami wanted to marry a Muslim woman.

[[Arabic#^ar-Q0739-answer|Compare the answer]]
^ar-Q0739

**ar-Q0740 · Choose the form**

أراد سامي ____ يتزوّج من امرأة مسلمة.

Sami wanted to marry a Muslim woman.

Choices: أن / كي / أنّ

[[Arabic#^ar-Q0740-answer|Compare the answer]]
^ar-Q0740

**ar-Q0741 · Edit the changed sentence**

من المحتمل 【أنّ】 تكون ليلى قد فرّت من المنزل مرّة أخرى.

Layla has probably run off again.

[[Arabic#^ar-Q0741-answer|Compare the answer]]
^ar-Q0741

**ar-Q0742 · Build the sentence**

Arrange: أن / من / مرّة / قد / تكون / أخرى. / المنزل / ليلى / فرّت / المحتمل / من

Layla has probably run off again.

[[Arabic#^ar-Q0742-answer|Compare the answer]]
^ar-Q0742

**ar-Q0743 · Write a translation**

Write this in Arabic: Muslims believe that Jesus was one of God's messengers.

[[Arabic#^ar-Q0743-answer|Compare the answer]]
^ar-Q0743

**ar-Q0744 · Explain the grammar**

يؤمن المسلمون 【أن】ّ يسوع واحد من رسل الله.

Muslims believe that Jesus was one of God's messengers.

[[Arabic#^ar-Q0744-answer|Compare the answer]]
^ar-Q0744

**ar-Q0745 · Fill the gap**

هل لي ____ أتحدث مع الطبيب؟

Can I speak to the doctor?

[[Arabic#^ar-Q0745-answer|Compare the answer]]
^ar-Q0745

**ar-Q0746 · Choose the form**

هل لي ____ أتحدث مع الطبيب؟

Can I speak to the doctor?

Choices: كي / أنّ / أن

[[Arabic#^ar-Q0746-answer|Compare the answer]]
^ar-Q0746

**ar-Q0747 · Edit the changed sentence**

قالت له 【أن】 كان محقا.

She told him that he was right.

[[Arabic#^ar-Q0747-answer|Compare the answer]]
^ar-Q0747

**ar-Q0748 · Build the sentence**

Arrange: له / أنه / محقا. / كان / قالت

She told him that he was right.

[[Arabic#^ar-Q0748-answer|Compare the answer]]
^ar-Q0748

**ar-Q0749 · Write a translation**

Write this in Arabic: Not everything on the web can be found through Google.

[[Arabic#^ar-Q0749-answer|Compare the answer]]
^ar-Q0749

**ar-Q0750 · Explain the grammar**

ليس بإمكان جوجل 【أن】 يجد كل شيء على الإنترنت.

Not everything on the web can be found through Google.

[[Arabic#^ar-Q0750-answer|Compare the answer]]
^ar-Q0750


### Questions · 50 questions

**ar-Q0751 · Fill the gap**

"____ قبلتها؟" "نعم، قبلتها.

"Did you kiss her?" "Yes, I kissed her."

[[Arabic#^ar-Q0751-answer|Compare the answer]]
^ar-Q0751

**ar-Q0752 · Choose the form**

"____ قبلتها؟" "نعم، قبلتها.

"Did you kiss her?" "Yes, I kissed her."

Choices: أين / هل / كيف / ماذا

[[Arabic#^ar-Q0752-answer|Compare the answer]]
^ar-Q0752

**ar-Q0753 · Edit the changed sentence**

【هل】 يمكننا الأكل؟

When can we eat?

[[Arabic#^ar-Q0753-answer|Compare the answer]]
^ar-Q0753

**ar-Q0754 · Build the sentence**

Arrange: يمكننا / متى / الأكل؟

When can we eat?

[[Arabic#^ar-Q0754-answer|Compare the answer]]
^ar-Q0754

**ar-Q0755 · Write a translation**

Write this in Arabic: Did you go out last night?

[[Arabic#^ar-Q0755-answer|Compare the answer]]
^ar-Q0755

**ar-Q0756 · Explain the grammar**

【هل】 خرجت ليلة الأمس؟

Did you go out last night?

[[Arabic#^ar-Q0756-answer|Compare the answer]]
^ar-Q0756

**ar-Q0757 · Fill the gap**

____ سينتهي العالم؟

When will the world come to an end?

[[Arabic#^ar-Q0757-answer|Compare the answer]]
^ar-Q0757

**ar-Q0758 · Choose the form**

____ سينتهي العالم؟

When will the world come to an end?

Choices: أين / ماذا / هل / متى

[[Arabic#^ar-Q0758-answer|Compare the answer]]
^ar-Q0758

**ar-Q0759 · Edit the changed sentence**

【ماذا】 الجميع جاهز؟

Are you all ready?

[[Arabic#^ar-Q0759-answer|Compare the answer]]
^ar-Q0759

**ar-Q0760 · Build the sentence**

Arrange: جاهز؟ / الجميع / هل

Are you all ready?

[[Arabic#^ar-Q0760-answer|Compare the answer]]
^ar-Q0760

**ar-Q0761 · Write a translation**

Write this in Arabic: How many episodes of One Piece have you watched?

[[Arabic#^ar-Q0761-answer|Compare the answer]]
^ar-Q0761

**ar-Q0762 · Explain the grammar**

【كم】 من حلقة من وان بيس شاهدت؟

How many episodes of One Piece have you watched?

[[Arabic#^ar-Q0762-answer|Compare the answer]]
^ar-Q0762

**ar-Q0763 · Fill the gap**

قابل سامي مسلمين ____ بلدان مختلفة.

Sami met Muslims from various countries.

[[Arabic#^ar-Q0763-answer|Compare the answer]]
^ar-Q0763

**ar-Q0764 · Choose the form**

قابل سامي مسلمين ____ بلدان مختلفة.

Sami met Muslims from various countries.

Choices: ماذا / من / هل / أين

[[Arabic#^ar-Q0764-answer|Compare the answer]]
^ar-Q0764

**ar-Q0765 · Edit the changed sentence**

【هل】 تركت عملك في المزرعة؟

Why did you leave your job on the farm?

[[Arabic#^ar-Q0765-answer|Compare the answer]]
^ar-Q0765

**ar-Q0766 · Build the sentence**

Arrange: عملك / المزرعة؟ / لماذا / تركت / في

Why did you leave your job on the farm?

[[Arabic#^ar-Q0766-answer|Compare the answer]]
^ar-Q0766

**ar-Q0767 · Write a translation**

Write this in Arabic: The washbasin is made of granite.

[[Arabic#^ar-Q0767-answer|Compare the answer]]
^ar-Q0767

**ar-Q0768 · Explain the grammar**

المغسلة صنعت 【من】 الجرانيت

The washbasin is made of granite.

[[Arabic#^ar-Q0768-answer|Compare the answer]]
^ar-Q0768

**ar-Q0769 · Fill the gap**

____ تستطيع السباحة؟

Are you able to swim?

[[Arabic#^ar-Q0769-answer|Compare the answer]]
^ar-Q0769

**ar-Q0770 · Choose the form**

____ تستطيع السباحة؟

Are you able to swim?

Choices: ماذا / أين / هل / كيف

[[Arabic#^ar-Q0770-answer|Compare the answer]]
^ar-Q0770

**ar-Q0771 · Edit the changed sentence**

【هل】 الأفضل لك التوقف عن التدخين.

You had better stop smoking.

[[Arabic#^ar-Q0771-answer|Compare the answer]]
^ar-Q0771

**ar-Q0772 · Build the sentence**

Arrange: عن / الأفضل / التوقف / التدخين. / من / لك

You had better stop smoking.

[[Arabic#^ar-Q0772-answer|Compare the answer]]
^ar-Q0772

**ar-Q0773 · Write a translation**

Write this in Arabic: Do you have the berber keyboard on your computer?

[[Arabic#^ar-Q0773-answer|Compare the answer]]
^ar-Q0773

**ar-Q0774 · Explain the grammar**

【هل】 تملِكينَ لوحة المفاتيح الأمازيغية على حاسوبِكِ؟

Do you have the berber keyboard on your computer?

[[Arabic#^ar-Q0774-answer|Compare the answer]]
^ar-Q0774

**ar-Q0775 · Fill the gap**

اضطرّ سامي على حذف الفيديو ____ يوتوب.

Sami had to take his YouTube video down.

[[Arabic#^ar-Q0775-answer|Compare the answer]]
^ar-Q0775

**ar-Q0776 · Choose the form**

اضطرّ سامي على حذف الفيديو ____ يوتوب.

Sami had to take his YouTube video down.

Choices: هل / ماذا / من / أين

[[Arabic#^ar-Q0776-answer|Compare the answer]]
^ar-Q0776

**ar-Q0777 · Edit the changed sentence**

【هل】 سيتحمل المسؤولية بالنسبة لهذا الأمر؟

Who's taking responsibility for this?

[[Arabic#^ar-Q0777-answer|Compare the answer]]
^ar-Q0777

**ar-Q0778 · Build the sentence**

Arrange: من / المسؤولية / بالنسبة / الأمر؟ / سيتحمل / لهذا

Who's taking responsibility for this?

[[Arabic#^ar-Q0778-answer|Compare the answer]]
^ar-Q0778

**ar-Q0779 · Write a translation**

Write this in Arabic: Is she Japanese?

[[Arabic#^ar-Q0779-answer|Compare the answer]]
^ar-Q0779

**ar-Q0780 · Explain the grammar**

【هل】 هي يابانية؟

Is she Japanese?

[[Arabic#^ar-Q0780-answer|Compare the answer]]
^ar-Q0780

**ar-Q0781 · Fill the gap**

____ تعرف أخاهم؟

Do you know their brother?

[[Arabic#^ar-Q0781-answer|Compare the answer]]
^ar-Q0781

**ar-Q0782 · Choose the form**

____ تعرف أخاهم؟

Do you know their brother?

Choices: كيف / ماذا / أين / هل

[[Arabic#^ar-Q0782-answer|Compare the answer]]
^ar-Q0782

**ar-Q0783 · Edit the changed sentence**

زوجتي و ماري كانوا في الجزء الخلفي 【هل】 الطائرة .

My wife and Mary were in the rear of the aircraft.

[[Arabic#^ar-Q0783-answer|Compare the answer]]
^ar-Q0783

**ar-Q0784 · Build the sentence**

Arrange: و / كانوا / . / من / الجزء / الطائرة / ماري / زوجتي / في / الخلفي

My wife and Mary were in the rear of the aircraft.

[[Arabic#^ar-Q0784-answer|Compare the answer]]
^ar-Q0784

**ar-Q0785 · Write a translation**

Write this in Arabic: What time is it, anyway?

[[Arabic#^ar-Q0785-answer|Compare the answer]]
^ar-Q0785

**ar-Q0786 · Explain the grammar**

【كم】 الساعة على أي حال؟

What time is it, anyway?

[[Arabic#^ar-Q0786-answer|Compare the answer]]
^ar-Q0786

**ar-Q0787 · Fill the gap**

____ زرت أمريكا من قبل؟

Have you ever been to America?

[[Arabic#^ar-Q0787-answer|Compare the answer]]
^ar-Q0787

**ar-Q0788 · Choose the form**

____ زرت أمريكا من قبل؟

Have you ever been to America?

Choices: كيف / هل / ماذا / أين

[[Arabic#^ar-Q0788-answer|Compare the answer]]
^ar-Q0788

**ar-Q0789 · Edit the changed sentence**

هناك العديد 【هل】 السياح الصينيين بالقرب من هنا.

There are a lot of Chinese tourists around here.

[[Arabic#^ar-Q0789-answer|Compare the answer]]
^ar-Q0789

**ar-Q0790 · Build the sentence**

Arrange: بالقرب / السياح / الصينيين / هنا. / من / العديد / هناك / من

There are a lot of Chinese tourists around here.

[[Arabic#^ar-Q0790-answer|Compare the answer]]
^ar-Q0790

**ar-Q0791 · Write a translation**

Write this in Arabic: Is this book yours?

[[Arabic#^ar-Q0791-answer|Compare the answer]]
^ar-Q0791

**ar-Q0792 · Explain the grammar**

【هل】 ذاك الكتاب لك؟

Is this book yours?

[[Arabic#^ar-Q0792-answer|Compare the answer]]
^ar-Q0792

**ar-Q0793 · Fill the gap**

شرب سامي قارورة كاملة ____ الأقراص.

Sami swallowed a whole bottle of pills.

[[Arabic#^ar-Q0793-answer|Compare the answer]]
^ar-Q0793

**ar-Q0794 · Choose the form**

شرب سامي قارورة كاملة ____ الأقراص.

Sami swallowed a whole bottle of pills.

Choices: أين / ماذا / هل / من

[[Arabic#^ar-Q0794-answer|Compare the answer]]
^ar-Q0794

**ar-Q0795 · Edit the changed sentence**

【هل】 سنقيم الحفلة؟

When shall we have the party?

[[Arabic#^ar-Q0795-answer|Compare the answer]]
^ar-Q0795

**ar-Q0796 · Build the sentence**

Arrange: الحفلة؟ / متى / سنقيم

When shall we have the party?

[[Arabic#^ar-Q0796-answer|Compare the answer]]
^ar-Q0796

**ar-Q0797 · Write a translation**

Write this in Arabic: How do I get to Park Street?

[[Arabic#^ar-Q0797-answer|Compare the answer]]
^ar-Q0797

**ar-Q0798 · Explain the grammar**

【كيف】 أصل إلى شارع بارك؟

How do I get to Park Street?

[[Arabic#^ar-Q0798-answer|Compare the answer]]
^ar-Q0798

**ar-Q0799 · Fill the gap**

____ هو المرحاض، من فضلك؟

Where are the toilets, please?

[[Arabic#^ar-Q0799-answer|Compare the answer]]
^ar-Q0799

**ar-Q0800 · Choose the form**

____ هو المرحاض، من فضلك؟

Where are the toilets, please?

Choices: هل / ماذا / كيف / أين

[[Arabic#^ar-Q0800-answer|Compare the answer]]
^ar-Q0800


### Conditions · 50 questions

**ar-Q0801 · Edit the changed sentence**

غيري العلم، 【إذا】 سمحت.

Change the flag, please.

[[Arabic#^ar-Q0801-answer|Compare the answer]]
^ar-Q0801

**ar-Q0802 · Build the sentence**

Arrange: العلم، / سمحت. / غيري / لو

Change the flag, please.

[[Arabic#^ar-Q0802-answer|Compare the answer]]
^ar-Q0802

**ar-Q0803 · Write a translation**

Write this in Arabic: "I hate you." "Divorce me then."

[[Arabic#^ar-Q0803-answer|Compare the answer]]
^ar-Q0803

**ar-Q0804 · Explain the grammar**

”أنا أكرهكِ.“ ”طلّقني 【إذا】. “

"I hate you." "Divorce me then."

[[Arabic#^ar-Q0804-answer|Compare the answer]]
^ar-Q0804

**ar-Q0805 · Fill the gap**

الأعداد الأولية مثل الحياة، منطقية تمامًا، لكن يستحيل إيجاد القواعد لها، حتى ____ أمضيت وقتك كله تفكر فيها.

Prime numbers are like life; they are completely logical, but impossible to find the rules for, even if you spend all your time thinking about it.

[[Arabic#^ar-Q0805-answer|Compare the answer]]
^ar-Q0805

**ar-Q0806 · Choose the form**

الأعداد الأولية مثل الحياة، منطقية تمامًا، لكن يستحيل إيجاد القواعد لها، حتى ____ أمضيت وقتك كله تفكر فيها.

Prime numbers are like life; they are completely logical, but impossible to find the rules for, even if you spend all your time thinking about it.

Choices: إن / لو / إذا

[[Arabic#^ar-Q0806-answer|Compare the answer]]
^ar-Q0806

**ar-Q0807 · Edit the changed sentence**

أتمنى 【إذا】 كان هناك المزيد من الناس مثلك.

I wish there were more people like you.

[[Arabic#^ar-Q0807-answer|Compare the answer]]
^ar-Q0807

**ar-Q0808 · Build the sentence**

Arrange: الناس / مثلك. / كان / هناك / لو / المزيد / أتمنى / من

I wish there were more people like you.

[[Arabic#^ar-Q0808-answer|Compare the answer]]
^ar-Q0808

**ar-Q0809 · Write a translation**

Write this in Arabic: Were it not for your help, I could never succeed.

[[Arabic#^ar-Q0809-answer|Compare the answer]]
^ar-Q0809

**ar-Q0810 · Explain the grammar**

【لو】 لم تساعدني، لما كنت سأنجح.

Were it not for your help, I could never succeed.

[[Arabic#^ar-Q0810-answer|Compare the answer]]
^ar-Q0810

**ar-Q0811 · Fill the gap**

تعال معي ____ سمحت.

Come with me, will you?

[[Arabic#^ar-Q0811-answer|Compare the answer]]
^ar-Q0811

**ar-Q0812 · Choose the form**

تعال معي ____ سمحت.

Come with me, will you?

Choices: إن / لو / إذا

[[Arabic#^ar-Q0812-answer|Compare the answer]]
^ar-Q0812

**ar-Q0813 · Edit the changed sentence**

لا أعلم 【إن】 كان توم جائعاً أم لا

I don't know whether Tom is hungry or not.

[[Arabic#^ar-Q0813-answer|Compare the answer]]
^ar-Q0813

**ar-Q0814 · Build the sentence**

Arrange: كان / لا / إذا / جائعاً / أعلم / أم / لا / توم

I don't know whether Tom is hungry or not.

[[Arabic#^ar-Q0814-answer|Compare the answer]]
^ar-Q0814

**ar-Q0815 · Write a translation**

Write this in Arabic: Please leave a message after the beep or drop some candies in our mailbox.

[[Arabic#^ar-Q0815-answer|Compare the answer]]
^ar-Q0815

**ar-Q0816 · Explain the grammar**

【لو】 سمحت، اترك رسالةً بعد الصفير، أو ألقِ بعض الحلوى في صندوق بريدنا.

Please leave a message after the beep or drop some candies in our mailbox.

[[Arabic#^ar-Q0816-answer|Compare the answer]]
^ar-Q0816

**ar-Q0817 · Fill the gap**

____ المكان مُزدحم، دعنا نستقل القطار القادم.

It's crowded, so let's take the next train.

[[Arabic#^ar-Q0817-answer|Compare the answer]]
^ar-Q0817

**ar-Q0818 · Choose the form**

____ المكان مُزدحم، دعنا نستقل القطار القادم.

It's crowded, so let's take the next train.

Choices: إن / إذا / لو

[[Arabic#^ar-Q0818-answer|Compare the answer]]
^ar-Q0818

**ar-Q0819 · Edit the changed sentence**

أنا 【إذا】 كنت غنياً, كنت أود أن أعطيكِ مال.

If I were rich, I'd give you money.

[[Arabic#^ar-Q0819-answer|Compare the answer]]
^ar-Q0819

**ar-Q0820 · Build the sentence**

Arrange: غنياً, / كنت / أنا / أعطيكِ / أود / كنت / أن / مال. / لو

If I were rich, I'd give you money.

[[Arabic#^ar-Q0820-answer|Compare the answer]]
^ar-Q0820

**ar-Q0821 · Write a translation**

Write this in Arabic: If I had had enough money, I would have bought the bag.

[[Arabic#^ar-Q0821-answer|Compare the answer]]
^ar-Q0821

**ar-Q0822 · Explain the grammar**

【لو】 كان لدي ما يكفي من المال لاشتريت تلك الحقيبة.

If I had had enough money, I would have bought the bag.

[[Arabic#^ar-Q0822-answer|Compare the answer]]
^ar-Q0822

**ar-Q0823 · Fill the gap**

____ لم يكن لديك أولاد بإمكانك دائماً أن تتبنى.

If you can't have children, you could always adopt.

[[Arabic#^ar-Q0823-answer|Compare the answer]]
^ar-Q0823

**ar-Q0824 · Choose the form**

____ لم يكن لديك أولاد بإمكانك دائماً أن تتبنى.

If you can't have children, you could always adopt.

Choices: إن / لو / إذا

[[Arabic#^ar-Q0824-answer|Compare the answer]]
^ar-Q0824

**ar-Q0825 · Edit the changed sentence**

【إذا】 كان لديك ما تقول، فقُله.

If you've got something to say, just say it.

[[Arabic#^ar-Q0825-answer|Compare the answer]]
^ar-Q0825

**ar-Q0826 · Build the sentence**

Arrange: تقول، / ما / فقُله. / لديك / إن / كان

If you've got something to say, just say it.

[[Arabic#^ar-Q0826-answer|Compare the answer]]
^ar-Q0826

**ar-Q0827 · Write a translation**

Write this in Arabic: If you want a new bike, you'd better start saving up.

[[Arabic#^ar-Q0827-answer|Compare the answer]]
^ar-Q0827

**ar-Q0828 · Explain the grammar**

【إذا】 أردت الحصول على دراجة جديدة، من الفضل لك أن تبدأ بتوفير النقود.

If you want a new bike, you'd better start saving up.

[[Arabic#^ar-Q0828-answer|Compare the answer]]
^ar-Q0828

**ar-Q0829 · Fill the gap**

”أنا أكرهكِ.“ ”طلّقني ____.“

"I hate you." "Divorce me then."

[[Arabic#^ar-Q0829-answer|Compare the answer]]
^ar-Q0829

**ar-Q0830 · Choose the form**

”أنا أكرهكِ.“ ”طلّقني ____.“

"I hate you." "Divorce me then."

Choices: إذا / لو / إن

[[Arabic#^ar-Q0830-answer|Compare the answer]]
^ar-Q0830

**ar-Q0831 · Edit the changed sentence**

【إذا】َّها تَعتَقِدُ أنَّهَا أعْلَمْ.

She thinks she knows best.

[[Arabic#^ar-Q0831-answer|Compare the answer]]
^ar-Q0831

**ar-Q0832 · Build the sentence**

Arrange: تَعتَقِدُ / إنَّها / أنَّهَا / أعْلَمْ.

She thinks she knows best.

[[Arabic#^ar-Q0832-answer|Compare the answer]]
^ar-Q0832

**ar-Q0833 · Write a translation**

Write this in Arabic: Sami understands Layla's concerns.

[[Arabic#^ar-Q0833-answer|Compare the answer]]
^ar-Q0833

**ar-Q0834 · Explain the grammar**

【إن】ّ سامي يتفهّم انشغالات ليلى.

Sami understands Layla's concerns.

[[Arabic#^ar-Q0834-answer|Compare the answer]]
^ar-Q0834

**ar-Q0835 · Fill the gap**

أتساءل فقط ____ كان الأمر مشابهًا بالنسبة للآخرين.

I can only wonder if this is the same for everyone else.

[[Arabic#^ar-Q0835-answer|Compare the answer]]
^ar-Q0835

**ar-Q0836 · Choose the form**

أتساءل فقط ____ كان الأمر مشابهًا بالنسبة للآخرين.

I can only wonder if this is the same for everyone else.

Choices: إذا / إن / لو

[[Arabic#^ar-Q0836-answer|Compare the answer]]
^ar-Q0836

**ar-Q0837 · Edit the changed sentence**

"من يقرع؟" "【إذا】ّه زوجي!"

"Who's knocking?" "It's my husband!"

[[Arabic#^ar-Q0837-answer|Compare the answer]]
^ar-Q0837

**ar-Q0838 · Build the sentence**

Arrange: زوجي!" / "إنّه / "من / يقرع؟"

"Who's knocking?" "It's my husband!"

[[Arabic#^ar-Q0838-answer|Compare the answer]]
^ar-Q0838

**ar-Q0839 · Write a translation**

Write this in Arabic: Tom can't decide whether to buy a Toyota or a Ford.

[[Arabic#^ar-Q0839-answer|Compare the answer]]
^ar-Q0839

**ar-Q0840 · Explain the grammar**

توم لا يستطيع أن يقرر في ما 【لو】 يشتري سيارة تيوتا أو فورد.

Tom can't decide whether to buy a Toyota or a Ford.

[[Arabic#^ar-Q0840-answer|Compare the answer]]
^ar-Q0840

**ar-Q0841 · Fill the gap**

ماذا ____ فشِل؟

What if he fails?

[[Arabic#^ar-Q0841-answer|Compare the answer]]
^ar-Q0841

**ar-Q0842 · Choose the form**

ماذا ____ فشِل؟

What if he fails?

Choices: إن / إذا / لو

[[Arabic#^ar-Q0842-answer|Compare the answer]]
^ar-Q0842

**ar-Q0843 · Edit the changed sentence**

في فرنسا إما يقولون تليفون أو يقولون محمول ، لكن - الكلمة - الأخيرة غامضة ، لأن من الصعب عادة تحديد ما 【إن】 كان المقصود تليفونا أو حاسبا أو جهازا محمولا آخر.

In France they say either "(téléphone) mobile" or "portable", but the latter is ambiguous, because you often cannot tell whether it refers to a telephone, a computer, or another portable device.

[[Arabic#^ar-Q0843-answer|Compare the answer]]
^ar-Q0843

**ar-Q0844 · Build the sentence**

Arrange: أو / في / يقولون / محمولا / محمول / الصعب / - / ، / تليفونا / غامضة / أو / الأخيرة / حاسبا / تليفون / إذا / تحديد / فرنسا / ، / عادة / لأن / من / يقولون / المقصود / أو / إما / - / لكن / كان / جهازا / آخر. / الكلمة / ما

In France they say either "(téléphone) mobile" or "portable", but the latter is ambiguous, because you often cannot tell whether it refers to a telephone, a computer, or another portable device.

[[Arabic#^ar-Q0844-answer|Compare the answer]]
^ar-Q0844

**ar-Q0845 · Write a translation**

Write this in Arabic: It's so painful. Stop it!

[[Arabic#^ar-Q0845-answer|Compare the answer]]
^ar-Q0845

**ar-Q0846 · Explain the grammar**

【إن】 ذلك مؤلم ، توقف.

It's so painful. Stop it!

[[Arabic#^ar-Q0846-answer|Compare the answer]]
^ar-Q0846

**ar-Q0847 · Fill the gap**

____ أردت أن أخيفك لحكيت لك ما حلمت به منذ بضعة أسابيع.

If I wanted to scare you, I would have told you about what I dreamt about a few weeks ago.

[[Arabic#^ar-Q0847-answer|Compare the answer]]
^ar-Q0847

**ar-Q0848 · Choose the form**

____ أردت أن أخيفك لحكيت لك ما حلمت به منذ بضعة أسابيع.

If I wanted to scare you, I would have told you about what I dreamt about a few weeks ago.

Choices: إن / لو / إذا

[[Arabic#^ar-Q0848-answer|Compare the answer]]
^ar-Q0848

**ar-Q0849 · Edit the changed sentence**

توم يريد أن يعرف م 【إن】 كانت تؤلِم.

Tom wants to know if it hurts.

[[Arabic#^ar-Q0849-answer|Compare the answer]]
^ar-Q0849

**ar-Q0850 · Build the sentence**

Arrange: كانت / أن / تؤلِم. / إذا / يريد / م / يعرف / توم

Tom wants to know if it hurts.

[[Arabic#^ar-Q0850-answer|Compare the answer]]
^ar-Q0850


### Cause and concession · 50 questions

**ar-Q0851 · Write a translation**

Write this in Arabic: But you have kids.

[[Arabic#^ar-Q0851-answer|Compare the answer]]
^ar-Q0851

**ar-Q0852 · Explain the grammar**

【لكن】 لديك أطفال.

But you have kids.

[[Arabic#^ar-Q0852-answer|Compare the answer]]
^ar-Q0852

**ar-Q0853 · Fill the gap**

كان سامي بحاجة ____ المال.

Sami needed the money.

[[Arabic#^ar-Q0853-answer|Compare the answer]]
^ar-Q0853

**ar-Q0854 · Choose the form**

كان سامي بحاجة ____ المال.

Sami needed the money.

Choices: لكن / لأن / لذلك

[[Arabic#^ar-Q0854-answer|Compare the answer]]
^ar-Q0854

**ar-Q0855 · Edit the changed sentence**

أنا تلميذ، 【لأن】 هو ليس بواحد.

I am a student, but he isn't.

[[Arabic#^ar-Q0855-answer|Compare the answer]]
^ar-Q0855

**ar-Q0856 · Build the sentence**

Arrange: تلميذ، / ولكن / بواحد. / هو / ليس / أنا

I am a student, but he isn't.

[[Arabic#^ar-Q0856-answer|Compare the answer]]
^ar-Q0856

**ar-Q0857 · Write a translation**

Write this in Arabic: He's cute but stupid.

[[Arabic#^ar-Q0857-answer|Compare the answer]]
^ar-Q0857

**ar-Q0858 · Explain the grammar**

إنهُ ظريف, 【ولكن】 غبي.

He's cute but stupid.

[[Arabic#^ar-Q0858-answer|Compare the answer]]
^ar-Q0858

**ar-Q0859 · Fill the gap**

ليس "هو إبني" ____ " أنا والده".

Not "he is my son" but " I am his father".

[[Arabic#^ar-Q0859-answer|Compare the answer]]
^ar-Q0859

**ar-Q0860 · Choose the form**

ليس "هو إبني" ____ " أنا والده".

Not "he is my son" but " I am his father".

Choices: لكن / لأن / لذلك / ولكن

[[Arabic#^ar-Q0860-answer|Compare the answer]]
^ar-Q0860

**ar-Q0861 · Edit the changed sentence**

أنا حزين 【لكن】 الجميع غادر و تركني لوحدي.

I'm sad because everyone went away and left me alone.

[[Arabic#^ar-Q0861-answer|Compare the answer]]
^ar-Q0861

**ar-Q0862 · Build the sentence**

Arrange: حزين / لوحدي. / لأن / الجميع / غادر / أنا / تركني / و

I'm sad because everyone went away and left me alone.

[[Arabic#^ar-Q0862-answer|Compare the answer]]
^ar-Q0862

**ar-Q0863 · Write a translation**

Write this in Arabic: Sorry, but I can't hear you very well.

[[Arabic#^ar-Q0863-answer|Compare the answer]]
^ar-Q0863

**ar-Q0864 · Explain the grammar**

المعذرة 【لكن】ّي لا أستطيع سماعك جيّداً.

Sorry, but I can't hear you very well.

[[Arabic#^ar-Q0864-answer|Compare the answer]]
^ar-Q0864

**ar-Q0865 · Fill the gap**

بكيت ____ الجميع غيري بكى.

I just cried because all the others did.

[[Arabic#^ar-Q0865-answer|Compare the answer]]
^ar-Q0865

**ar-Q0866 · Choose the form**

بكيت ____ الجميع غيري بكى.

I just cried because all the others did.

Choices: لأن / لكن / لذلك

[[Arabic#^ar-Q0866-answer|Compare the answer]]
^ar-Q0866

**ar-Q0867 · Edit the changed sentence**

كانا سامي و ليلى أصدقاءا 【لأن】 الطّفل.

Sami and Layla were friends with that kid.

[[Arabic#^ar-Q0867-answer|Compare the answer]]
^ar-Q0867

**ar-Q0868 · Build the sentence**

Arrange: الطّفل. / ليلى / كانا / لذلك / أصدقاءا / سامي / و

Sami and Layla were friends with that kid.

[[Arabic#^ar-Q0868-answer|Compare the answer]]
^ar-Q0868

**ar-Q0869 · Write a translation**

Write this in Arabic: I don't know anybody in this area, So you have to try making friends.

[[Arabic#^ar-Q0869-answer|Compare the answer]]
^ar-Q0869

**ar-Q0870 · Explain the grammar**

لا أعرف أحد في هذه المنطقة 【لذلك】 عليك المحاولة بتشكيل صدقات.

I don't know anybody in this area, So you have to try making friends.

[[Arabic#^ar-Q0870-answer|Compare the answer]]
^ar-Q0870

**ar-Q0871 · Fill the gap**

المسلمون لا يأكلون الخنزير ____ّه لحم فيه خطر.

Muslims don't eat pork because it's dangerous meat.

[[Arabic#^ar-Q0871-answer|Compare the answer]]
^ar-Q0871

**ar-Q0872 · Choose the form**

المسلمون لا يأكلون الخنزير ____ّه لحم فيه خطر.

Muslims don't eat pork because it's dangerous meat.

Choices: لذلك / لكن / لأن

[[Arabic#^ar-Q0872-answer|Compare the answer]]
^ar-Q0872

**ar-Q0873 · Edit the changed sentence**

【لأن】 أنا خرجت

That's why I quit.

[[Arabic#^ar-Q0873-answer|Compare the answer]]
^ar-Q0873

**ar-Q0874 · Build the sentence**

Arrange: لذلك / خرجت / أنا

That's why I quit.

[[Arabic#^ar-Q0874-answer|Compare the answer]]
^ar-Q0874

**ar-Q0875 · Write a translation**

Write this in Arabic: But when I tried to turn the shower faucet, this black bubbly liquid came out.

[[Arabic#^ar-Q0875-answer|Compare the answer]]
^ar-Q0875

**ar-Q0876 · Explain the grammar**

【لكن】 عندما فتحت حنفية الحمام، خرج سائل أسود مليء بالفقاعات.

But when I tried to turn the shower faucet, this black bubbly liquid came out.

[[Arabic#^ar-Q0876-answer|Compare the answer]]
^ar-Q0876

**ar-Q0877 · Fill the gap**

يذهب الرجال وياتون ____ الارض تبقى ثابتة

Men go and come, but earth abides.

[[Arabic#^ar-Q0877-answer|Compare the answer]]
^ar-Q0877

**ar-Q0878 · Choose the form**

يذهب الرجال وياتون ____ الارض تبقى ثابتة

Men go and come, but earth abides.

Choices: لأن / لذلك / لكن

[[Arabic#^ar-Q0878-answer|Compare the answer]]
^ar-Q0878

**ar-Q0879 · Edit the changed sentence**

يمكننا أن نعرِف ما قد حصل في الماضي، 【لأن】 لا يمكننا تغييره. ويمكننا أن نغير المستقبل، لكن لا يمكننا أن نعرف ما سيحصل فيه.

The past can only be known, not changed. The future can only be changed, not known.

[[Arabic#^ar-Q0879-answer|Compare the answer]]
^ar-Q0879

**ar-Q0880 · Build the sentence**

Arrange: في / الماضي، / سيحصل / يمكننا / نعرف / نعرِف / ولكن / لا / فيه. / يمكننا / أن / لا / نغير / ما / يمكننا / أن / ويمكننا / ما / المستقبل، / لكن / قد / حصل / تغييره. / أن

The past can only be known, not changed. The future can only be changed, not known.

[[Arabic#^ar-Q0880-answer|Compare the answer]]
^ar-Q0880

**ar-Q0881 · Write a translation**

Write this in Arabic: She is poor, but happy.

[[Arabic#^ar-Q0881-answer|Compare the answer]]
^ar-Q0881

**ar-Q0882 · Explain the grammar**

هي فقيرة، 【لكن】 سعيدة.

She is poor, but happy.

[[Arabic#^ar-Q0882-answer|Compare the answer]]
^ar-Q0882

**ar-Q0883 · Fill the gap**

أحب تقدير الكمية التي أحتاجها من المكونات، غالبًا ____ لا أرغب بغسل أكواب القياس مرة تلو الأخرى.

I like to eyeball my ingredients, mostly because I don't feel like washing my measuring cups over and over.

[[Arabic#^ar-Q0883-answer|Compare the answer]]
^ar-Q0883

**ar-Q0884 · Choose the form**

أحب تقدير الكمية التي أحتاجها من المكونات، غالبًا ____ لا أرغب بغسل أكواب القياس مرة تلو الأخرى.

I like to eyeball my ingredients, mostly because I don't feel like washing my measuring cups over and over.

Choices: لكن / لأنني / لذلك / لأن

[[Arabic#^ar-Q0884-answer|Compare the answer]]
^ar-Q0884

**ar-Q0885 · Edit the changed sentence**

السوشي جيد، 【لأن】 الأطباق التايلاندية أفضل.

Sushi is good, but Thai dishes are better.

[[Arabic#^ar-Q0885-answer|Compare the answer]]
^ar-Q0885

**ar-Q0886 · Build the sentence**

Arrange: التايلاندية / جيد، / الأطباق / السوشي / أفضل. / لكن

Sushi is good, but Thai dishes are better.

[[Arabic#^ar-Q0886-answer|Compare the answer]]
^ar-Q0886

**ar-Q0887 · Write a translation**

Write this in Arabic: I look forward to it.

[[Arabic#^ar-Q0887-answer|Compare the answer]]
^ar-Q0887

**ar-Q0888 · Explain the grammar**

اني اتطلع 【لذلك】.

I look forward to it.

[[Arabic#^ar-Q0888-answer|Compare the answer]]
^ar-Q0888

**ar-Q0889 · Fill the gap**

ربما تسأل، لمَ الجمل؟ هذا ____ الجمل مثيرة للاهتمام أكثر.

Why sentences? …you may ask. Well, because sentences are more interesting.

[[Arabic#^ar-Q0889-answer|Compare the answer]]
^ar-Q0889

**ar-Q0890 · Choose the form**

ربما تسأل، لمَ الجمل؟ هذا ____ الجمل مثيرة للاهتمام أكثر.

Why sentences? …you may ask. Well, because sentences are more interesting.

Choices: لأن / لذلك / لكن

[[Arabic#^ar-Q0890-answer|Compare the answer]]
^ar-Q0890

**ar-Q0891 · Edit the changed sentence**

مع انني كنت جالساً تحت الشمس، 【لأن】 كنت أشعر بالبرد.

Even though I was sitting in the sun, I still felt chilly.

[[Arabic#^ar-Q0891-answer|Compare the answer]]
^ar-Q0891

**ar-Q0892 · Build the sentence**

Arrange: بالبرد. / انني / مع / ولكن / جالساً / كنت / أشعر / الشمس، / تحت / كنت

Even though I was sitting in the sun, I still felt chilly.

[[Arabic#^ar-Q0892-answer|Compare the answer]]
^ar-Q0892

**ar-Q0893 · Write a translation**

Write this in Arabic: After all she did not come.

[[Arabic#^ar-Q0893-answer|Compare the answer]]
^ar-Q0893

**ar-Q0894 · Explain the grammar**

【رغم】 كل شيء فهي لم تأتي.

After all she did not come.

[[Arabic#^ar-Q0894-answer|Compare the answer]]
^ar-Q0894

**ar-Q0895 · Fill the gap**

ما هو مهم ليس الهدف, ____ الرحلة.

What's important is not the goal, but the journey.

[[Arabic#^ar-Q0895-answer|Compare the answer]]
^ar-Q0895

**ar-Q0896 · Choose the form**

ما هو مهم ليس الهدف, ____ الرحلة.

What's important is not the goal, but the journey.

Choices: لأن / ولكن / لكن / لذلك

[[Arabic#^ar-Q0896-answer|Compare the answer]]
^ar-Q0896

**ar-Q0897 · Edit the changed sentence**

قد لا أملك الكثير من المال، 【لأن】 علي الاقل أنا أعيش بشروطي الخاصة

I may not have a lot of money, but at least I live on my own terms.

[[Arabic#^ar-Q0897-answer|Compare the answer]]
^ar-Q0897

**ar-Q0898 · Build the sentence**

Arrange: الكثير / علي / قد / المال، / لا / من / بشروطي / أملك / أنا / أعيش / الاقل / لكن / الخاصة

I may not have a lot of money, but at least I live on my own terms.

[[Arabic#^ar-Q0898-answer|Compare the answer]]
^ar-Q0898

**ar-Q0899 · Write a translation**

Write this in Arabic: Horses are bigger than dogs, but cats are smaller than dogs.

[[Arabic#^ar-Q0899-answer|Compare the answer]]
^ar-Q0899

**ar-Q0900 · Explain the grammar**

الخيول أكبر من الكلاب، 【ولكن】 القطط أصغر من الكلاب.

Horses are bigger than dogs, but cats are smaller than dogs.

[[Arabic#^ar-Q0900-answer|Compare the answer]]
^ar-Q0900


### Coordination and quantification · 50 questions

**ar-Q0901 · Fill the gap**

لقد وصلتَ للتّ____.

You have only just arrived.

[[Arabic#^ar-Q0901-answer|Compare the answer]]
^ar-Q0901

**ar-Q0902 · Choose the form**

لقد وصلتَ للتّ____.

You have only just arrived.

Choices: كل / بعض / أو / و

[[Arabic#^ar-Q0902-answer|Compare the answer]]
^ar-Q0902

**ar-Q0903 · Edit the changed sentence**

كلا سامي 【أو】 ليلى مسلمين.

Sami and Layla are both Muslim.

[[Arabic#^ar-Q0903-answer|Compare the answer]]
^ar-Q0903

**ar-Q0904 · Build the sentence**

Arrange: ليلى / كلا / سامي / و / مسلمين.

Sami and Layla are both Muslim.

[[Arabic#^ar-Q0904-answer|Compare the answer]]
^ar-Q0904

**ar-Q0905 · Write a translation**

Write this in Arabic: Everything's done.

[[Arabic#^ar-Q0905-answer|Compare the answer]]
^ar-Q0905

**ar-Q0906 · Explain the grammar**

انتهى 【كل】 شيء.

Everything's done.

[[Arabic#^ar-Q0906-answer|Compare the answer]]
^ar-Q0906

**ar-Q0907 · Fill the gap**

فقد فاضل ____ّ مدخراته.

Fadil's life savings were gone.

[[Arabic#^ar-Q0907-answer|Compare the answer]]
^ar-Q0907

**ar-Q0908 · Choose the form**

فقد فاضل ____ّ مدخراته.

Fadil's life savings were gone.

Choices: كل / أو / بعض / و

[[Arabic#^ar-Q0908-answer|Compare the answer]]
^ar-Q0908

**ar-Q0909 · Edit the changed sentence**

أمضى سامي 【أو】 ليلى بعض الوقت معا في مطعم محليّ للوجبات الخفيفة.

Sami and Layla hung out at the local diner.

[[Arabic#^ar-Q0909-answer|Compare the answer]]
^ar-Q0909

**ar-Q0910 · Build the sentence**

Arrange: سامي / أمضى / معا / بعض / مطعم / ليلى / محليّ / الوقت / في / للوجبات / الخفيفة. / و

Sami and Layla hung out at the local diner.

[[Arabic#^ar-Q0910-answer|Compare the answer]]
^ar-Q0910

**ar-Q0911 · Write a translation**

Write this in Arabic: Every morning, she helps her mother make breakfast in the kitchen.

[[Arabic#^ar-Q0911-answer|Compare the answer]]
^ar-Q0911

**ar-Q0912 · Explain the grammar**

تساعد أمها 【كل】 صباح في المطبخ لإعداد الفطور.

Every morning, she helps her mother make breakfast in the kitchen.

[[Arabic#^ar-Q0912-answer|Compare the answer]]
^ar-Q0912

**ar-Q0913 · Fill the gap**

أراد سامي ____ الماء.

Sami wanted some water.

[[Arabic#^ar-Q0913-answer|Compare the answer]]
^ar-Q0913

**ar-Q0914 · Choose the form**

أراد سامي ____ الماء.

Sami wanted some water.

Choices: بعض / أو / و / كل

[[Arabic#^ar-Q0914-answer|Compare the answer]]
^ar-Q0914

**ar-Q0915 · Edit the changed sentence**

تحليت بكل شجاعتي 【أو】 ذهبت إلى هناك.

I screwed up my courage and went there.

[[Arabic#^ar-Q0915-answer|Compare the answer]]
^ar-Q0915

**ar-Q0916 · Build the sentence**

Arrange: هناك. / إلى / بكل / و / شجاعتي / ذهبت / تحليت

I screwed up my courage and went there.

[[Arabic#^ar-Q0916-answer|Compare the answer]]
^ar-Q0916

**ar-Q0917 · Write a translation**

Write this in Arabic: Sami changed clothes on a daily basis.

[[Arabic#^ar-Q0917-answer|Compare the answer]]
^ar-Q0917

**ar-Q0918 · Explain the grammar**

كان سامي يبدّل ملابسه 【كل】ّ يوم.

Sami changed clothes on a daily basis.

[[Arabic#^ar-Q0918-answer|Compare the answer]]
^ar-Q0918

**ar-Q0919 · Fill the gap**

____ أخيراً وصلنا.

Well, here we are!

[[Arabic#^ar-Q0919-answer|Compare the answer]]
^ar-Q0919

**ar-Q0920 · Choose the form**

____ أخيراً وصلنا.

Well, here we are!

Choices: كل / و / بعض / أو

[[Arabic#^ar-Q0920-answer|Compare the answer]]
^ar-Q0920

**ar-Q0921 · Edit the changed sentence**

كانت هناك حديقة عند 【و】 بيت.

Every house had a garden.

[[Arabic#^ar-Q0921-answer|Compare the answer]]
^ar-Q0921

**ar-Q0922 · Build the sentence**

Arrange: كانت / هناك / حديقة / كل / بيت. / عند

Every house had a garden.

[[Arabic#^ar-Q0922-answer|Compare the answer]]
^ar-Q0922

**ar-Q0923 · Write a translation**

Write this in Arabic: Come and have some.

[[Arabic#^ar-Q0923-answer|Compare the answer]]
^ar-Q0923

**ar-Q0924 · Explain the grammar**

تعال 【و】 تناول منه قليلا.

Come and have some.

[[Arabic#^ar-Q0924-answer|Compare the answer]]
^ar-Q0924

**ar-Q0925 · Fill the gap**

مشيا سامي ____ ليلى على طول الشّاطئ.

Sami and Layla walked down along the beach.

[[Arabic#^ar-Q0925-answer|Compare the answer]]
^ar-Q0925

**ar-Q0926 · Choose the form**

مشيا سامي ____ ليلى على طول الشّاطئ.

Sami and Layla walked down along the beach.

Choices: كل / بعض / أو / و

[[Arabic#^ar-Q0926-answer|Compare the answer]]
^ar-Q0926

**ar-Q0927 · Edit the changed sentence**

لديك 【و】 الكتب.

You have some books.

[[Arabic#^ar-Q0927-answer|Compare the answer]]
^ar-Q0927

**ar-Q0928 · Build the sentence**

Arrange: بعض / لديك / الكتب.

You have some books.

[[Arabic#^ar-Q0928-answer|Compare the answer]]
^ar-Q0928

**ar-Q0929 · Write a translation**

Write this in Arabic: I take light exercise every morning.

[[Arabic#^ar-Q0929-answer|Compare the answer]]
^ar-Q0929

**ar-Q0930 · Explain the grammar**

أقوم ببعض التمارين الخفيفة 【كل】 صباح.

I take light exercise every morning.

[[Arabic#^ar-Q0930-answer|Compare the answer]]
^ar-Q0930

**ar-Q0931 · Fill the gap**

اليابان بلد يحيط به البحر ____ ليده مناخ معتدل.

Surrounded by the sea, Japan has a mild climate.

[[Arabic#^ar-Q0931-answer|Compare the answer]]
^ar-Q0931

**ar-Q0932 · Choose the form**

اليابان بلد يحيط به البحر ____ ليده مناخ معتدل.

Surrounded by the sea, Japan has a mild climate.

Choices: بعض / كل / و / أو

[[Arabic#^ar-Q0932-answer|Compare the answer]]
^ar-Q0932

**ar-Q0933 · Edit the changed sentence**

نطقا سامي 【أو】 ليلى بالشّهادة معا.

Sami and Layla took their shahada together.

[[Arabic#^ar-Q0933-answer|Compare the answer]]
^ar-Q0933

**ar-Q0934 · Build the sentence**

Arrange: معا. / نطقا / ليلى / سامي / بالشّهادة / و

Sami and Layla took their shahada together.

[[Arabic#^ar-Q0934-answer|Compare the answer]]
^ar-Q0934

**ar-Q0935 · Write a translation**

Write this in Arabic: It took a national TV campaign to finally track Sami down.

[[Arabic#^ar-Q0935-answer|Compare the answer]]
^ar-Q0935

**ar-Q0936 · Explain the grammar**

لقد احتاج الأمر لحملة تلفزيونيّة وطنيّة من أجل تعقّب سامي 【و】 العثور عليه أخيرا.

It took a national TV campaign to finally track Sami down.

[[Arabic#^ar-Q0936-answer|Compare the answer]]
^ar-Q0936

**ar-Q0937 · Fill the gap**

كانت ليلى غاضبة ____ مشوّشة.

Layla was angry and confused.

[[Arabic#^ar-Q0937-answer|Compare the answer]]
^ar-Q0937

**ar-Q0938 · Choose the form**

كانت ليلى غاضبة ____ مشوّشة.

Layla was angry and confused.

Choices: كل / و / بعض / أو

[[Arabic#^ar-Q0938-answer|Compare the answer]]
^ar-Q0938

**ar-Q0939 · Edit the changed sentence**

أنا 【أو】 أنت في نفس العمر.

You and I are the same age.

[[Arabic#^ar-Q0939-answer|Compare the answer]]
^ar-Q0939

**ar-Q0940 · Build the sentence**

Arrange: أنا / أنت / و / العمر. / نفس / في

You and I are the same age.

[[Arabic#^ar-Q0940-answer|Compare the answer]]
^ar-Q0940

**ar-Q0941 · Write a translation**

Write this in Arabic: Only a few people understood me.

[[Arabic#^ar-Q0941-answer|Compare the answer]]
^ar-Q0941

**ar-Q0942 · Explain the grammar**

【كل】 من فهمني هم حفنة من الناس.

Only a few people understood me.

[[Arabic#^ar-Q0942-answer|Compare the answer]]
^ar-Q0942

**ar-Q0943 · Fill the gap**

ينبغي لها أن تستمع إلى آراء الآخرين ____.

She should listen more to other people.

[[Arabic#^ar-Q0943-answer|Compare the answer]]
^ar-Q0943

**ar-Q0944 · Choose the form**

ينبغي لها أن تستمع إلى آراء الآخرين ____.

She should listen more to other people.

Choices: كل / و / أو / أكثر

[[Arabic#^ar-Q0944-answer|Compare the answer]]
^ar-Q0944

**ar-Q0945 · Edit the changed sentence**

دع كاميرتي 【أو】 شأنها.

Leave my camera alone.

[[Arabic#^ar-Q0945-answer|Compare the answer]]
^ar-Q0945

**ar-Q0946 · Build the sentence**

Arrange: و / شأنها. / دع / كاميرتي

Leave my camera alone.

[[Arabic#^ar-Q0946-answer|Compare the answer]]
^ar-Q0946

**ar-Q0947 · Write a translation**

Write this in Arabic: Any activity you need to accomplish will take more time than you have.

[[Arabic#^ar-Q0947-answer|Compare the answer]]
^ar-Q0947

**ar-Q0948 · Explain the grammar**

أي نشاط تحتاج لتحقيقه ستحتاج إلى وقت 【أكثر】 مما تملكه.

Any activity you need to accomplish will take more time than you have.

[[Arabic#^ar-Q0948-answer|Compare the answer]]
^ar-Q0948

**ar-Q0949 · Fill the gap**

____ الأطعمة تسبب لي الحساسية.

Some foods cause me an allergic reaction.

[[Arabic#^ar-Q0949-answer|Compare the answer]]
^ar-Q0949

**ar-Q0950 · Choose the form**

____ الأطعمة تسبب لي الحساسية.

Some foods cause me an allergic reaction.

Choices: أو / و / كل / بعض

[[Arabic#^ar-Q0950-answer|Compare the answer]]
^ar-Q0950


### Courtesy and certainty · 50 questions

**ar-Q0951 · Edit the changed sentence**

【ربما】 ان تذهب للبيت ؟

Shouldn't you go home?

[[Arabic#^ar-Q0951-answer|Compare the answer]]
^ar-Q0951

**ar-Q0952 · Build the sentence**

Arrange: يجب / ؟ / ان / تذهب / للبيت

Shouldn't you go home?

[[Arabic#^ar-Q0952-answer|Compare the answer]]
^ar-Q0952

**ar-Q0953 · Write a translation**

Write this in Arabic: Please get in touch with me when you come to Tokyo.

[[Arabic#^ar-Q0953-answer|Compare the answer]]
^ar-Q0953

**ar-Q0954 · Explain the grammar**

اتصل بي حين تأتي إلى طوكيو 【رجاء】ً.

Please get in touch with me when you come to Tokyo.

[[Arabic#^ar-Q0954-answer|Compare the answer]]
^ar-Q0954

**ar-Q0955 · Fill the gap**

مازال ____ دفع الفاتورة اليوم.

The bill still has to be paid today.

[[Arabic#^ar-Q0955-answer|Compare the answer]]
^ar-Q0955

**ar-Q0956 · Choose the form**

مازال ____ دفع الفاتورة اليوم.

The bill still has to be paid today.

Choices: يجب / ربما / يمكن

[[Arabic#^ar-Q0956-answer|Compare the answer]]
^ar-Q0956

**ar-Q0957 · Edit the changed sentence**

【ربما】 أن تتم هذا التقرير قبل يوم الأثنين.

You must have the report done by Monday.

[[Arabic#^ar-Q0957-answer|Compare the answer]]
^ar-Q0957

**ar-Q0958 · Build the sentence**

Arrange: هذا / التقرير / تتم / يجب / قبل / الأثنين. / أن / يوم

You must have the report done by Monday.

[[Arabic#^ar-Q0958-answer|Compare the answer]]
^ar-Q0958

**ar-Q0959 · Write a translation**

Write this in Arabic: You should talk to them.

[[Arabic#^ar-Q0959-answer|Compare the answer]]
^ar-Q0959

**ar-Q0960 · Explain the grammar**

【يجب】 عليك أن تُكَلّمَهُم.

You should talk to them.

[[Arabic#^ar-Q0960-answer|Compare the answer]]
^ar-Q0960

**ar-Q0961 · Fill the gap**

____ً لا ترسل أي صور عارية لك حتى لا أرفض طلبك.

Please don't send me any nude pictures or I will reject your request.

[[Arabic#^ar-Q0961-answer|Compare the answer]]
^ar-Q0961

**ar-Q0962 · Choose the form**

____ً لا ترسل أي صور عارية لك حتى لا أرفض طلبك.

Please don't send me any nude pictures or I will reject your request.

Choices: رجاء / ربما / يمكن / يجب

[[Arabic#^ar-Q0962-answer|Compare the answer]]
^ar-Q0962

**ar-Q0963 · Edit the changed sentence**

تعال 【ربما】

Please come.

[[Arabic#^ar-Q0963-answer|Compare the answer]]
^ar-Q0963

**ar-Q0964 · Build the sentence**

Arrange: فضلك / من / تعال

Please come.

[[Arabic#^ar-Q0964-answer|Compare the answer]]
^ar-Q0964

**ar-Q0965 · Write a translation**

Write this in Arabic: Maybe you're right.

[[Arabic#^ar-Q0965-answer|Compare the answer]]
^ar-Q0965

**ar-Q0966 · Explain the grammar**

【ربما】 أنت محق.

Maybe you're right.

[[Arabic#^ar-Q0966-answer|Compare the answer]]
^ar-Q0966

**ar-Q0967 · Fill the gap**

كان ____ أن تكون في الحفلة الليلة الماضية. كان هناك الكثير من المتعة.

You should have been at the party last night. It was a lot of fun.

[[Arabic#^ar-Q0967-answer|Compare the answer]]
^ar-Q0967

**ar-Q0968 · Choose the form**

كان ____ أن تكون في الحفلة الليلة الماضية. كان هناك الكثير من المتعة.

You should have been at the party last night. It was a lot of fun.

Choices: يجب / ربما / يمكن

[[Arabic#^ar-Q0968-answer|Compare the answer]]
^ar-Q0968

**ar-Q0969 · Edit the changed sentence**

لا 【ربما】 عليك أن تتقن لغات عديدة.

It doesn't require you to be a polyglot.

[[Arabic#^ar-Q0969-answer|Compare the answer]]
^ar-Q0969

**ar-Q0970 · Build the sentence**

Arrange: أن / تتقن / لا / عديدة. / لغات / عليك / يجب

It doesn't require you to be a polyglot.

[[Arabic#^ar-Q0970-answer|Compare the answer]]
^ar-Q0970

**ar-Q0971 · Write a translation**

Write this in Arabic: Would you please pour me a cup of coffee?

[[Arabic#^ar-Q0971-answer|Compare the answer]]
^ar-Q0971

**ar-Q0972 · Explain the grammar**

هل لك أن تصبّ لي كأساً من القهوة 【من فضلك】؟

Would you please pour me a cup of coffee?

[[Arabic#^ar-Q0972-answer|Compare the answer]]
^ar-Q0972

**ar-Q0973 · Fill the gap**

____ أجب على كل الأسئلة.

Please answer all the questions.

[[Arabic#^ar-Q0973-answer|Compare the answer]]
^ar-Q0973

**ar-Q0974 · Choose the form**

____ أجب على كل الأسئلة.

Please answer all the questions.

Choices: يمكن / يجب / من فضلك / ربما

[[Arabic#^ar-Q0974-answer|Compare the answer]]
^ar-Q0974

**ar-Q0975 · Edit the changed sentence**

【ربما】 ساعدني.

Could you help me?

[[Arabic#^ar-Q0975-answer|Compare the answer]]
^ar-Q0975

**ar-Q0976 · Build the sentence**

Arrange: من / ساعدني. / فضلك

Could you help me?

[[Arabic#^ar-Q0976-answer|Compare the answer]]
^ar-Q0976

**ar-Q0977 · Write a translation**

Write this in Arabic: You must build up your courage.

[[Arabic#^ar-Q0977-answer|Compare the answer]]
^ar-Q0977

**ar-Q0978 · Explain the grammar**

【يجب】 أن تُنَمِّيَ شجاعتك.

You must build up your courage.

[[Arabic#^ar-Q0978-answer|Compare the answer]]
^ar-Q0978

**ar-Q0979 · Fill the gap**

أعطني كأساً من الماء ____.

Please give me a glass of water.

[[Arabic#^ar-Q0979-answer|Compare the answer]]
^ar-Q0979

**ar-Q0980 · Choose the form**

أعطني كأساً من الماء ____.

Please give me a glass of water.

Choices: من فضلك / يجب / يمكن / ربما

[[Arabic#^ar-Q0980-answer|Compare the answer]]
^ar-Q0980

**ar-Q0981 · Edit the changed sentence**

【ربما】 لتوم أن يقول شيئا.

Tom could've said something.

[[Arabic#^ar-Q0981-answer|Compare the answer]]
^ar-Q0981

**ar-Q0982 · Build the sentence**

Arrange: يقول / أن / لتوم / شيئا. / يمكن

Tom could've said something.

[[Arabic#^ar-Q0982-answer|Compare the answer]]
^ar-Q0982

**ar-Q0983 · Write a translation**

Write this in Arabic: Fadil knew that police could show up at any second.

[[Arabic#^ar-Q0983-answer|Compare the answer]]
^ar-Q0983

**ar-Q0984 · Explain the grammar**

كان فاضل يعلم أنّ الشّرطة 【يمكن】 أن تصل في أية لحظة.

Fadil knew that police could show up at any second.

[[Arabic#^ar-Q0984-answer|Compare the answer]]
^ar-Q0984

**ar-Q0985 · Fill the gap**

____ أن أشتري الطعام.

I need to buy the food.

[[Arabic#^ar-Q0985-answer|Compare the answer]]
^ar-Q0985

**ar-Q0986 · Choose the form**

____ أن أشتري الطعام.

I need to buy the food.

Choices: ربما / يجب / يمكن

[[Arabic#^ar-Q0986-answer|Compare the answer]]
^ar-Q0986

**ar-Q0987 · Edit the changed sentence**

المسؤولون 【ربما】 أن يأسيسوا لا تواصل وطيد بين الموظّفين.

Administrators need to establish close contact with employees.

[[Arabic#^ar-Q0987-answer|Compare the answer]]
^ar-Q0987

**ar-Q0988 · Build the sentence**

Arrange: وطيد / يجب / بين / تواصل / الموظّفين. / أن / لا / المسؤولون / يأسيسوا

Administrators need to establish close contact with employees.

[[Arabic#^ar-Q0988-answer|Compare the answer]]
^ar-Q0988

**ar-Q0989 · Write a translation**

Write this in Arabic: Stones don't swim.

[[Arabic#^ar-Q0989-answer|Compare the answer]]
^ar-Q0989

**ar-Q0990 · Explain the grammar**

لا 【يمكن】 للحجارة أن تسبح.

Stones don't swim.

[[Arabic#^ar-Q0990-answer|Compare the answer]]
^ar-Q0990

**ar-Q0991 · Fill the gap**

____ أن يكون فاضل قد مات.

Fadil might be dead.

[[Arabic#^ar-Q0991-answer|Compare the answer]]
^ar-Q0991

**ar-Q0992 · Choose the form**

____ أن يكون فاضل قد مات.

Fadil might be dead.

Choices: ربما / يمكن / يجب

[[Arabic#^ar-Q0992-answer|Compare the answer]]
^ar-Q0992

**ar-Q0993 · Edit the changed sentence**

【ربما】 أرسلها عن طريق الفاكس.

Please send it to me by fax.

[[Arabic#^ar-Q0993-answer|Compare the answer]]
^ar-Q0993

**ar-Q0994 · Build the sentence**

Arrange: طريق / من / الفاكس. / فضلك / أرسلها / عن

Please send it to me by fax.

[[Arabic#^ar-Q0994-answer|Compare the answer]]
^ar-Q0994

**ar-Q0995 · Write a translation**

Write this in Arabic: Please leave me alone.

[[Arabic#^ar-Q0995-answer|Compare the answer]]
^ar-Q0995

**ar-Q0996 · Explain the grammar**

【من فضلك】 اتركني وحدي.

Please leave me alone.

[[Arabic#^ar-Q0996-answer|Compare the answer]]
^ar-Q0996

**ar-Q0997 · Fill the gap**

____ عمله، لكنه ليس سهلا.

It's doable, but not easy.

[[Arabic#^ar-Q0997-answer|Compare the answer]]
^ar-Q0997

**ar-Q0998 · Choose the form**

____ عمله، لكنه ليس سهلا.

It's doable, but not easy.

Choices: يمكن / يجب / ربما

[[Arabic#^ar-Q0998-answer|Compare the answer]]
^ar-Q0998

**ar-Q0999 · Edit the changed sentence**

【ربما】 لا تبكِ.

Please don't cry.

[[Arabic#^ar-Q0999-answer|Compare the answer]]
^ar-Q0999

**ar-Q1000 · Build the sentence**

Arrange: فضلك / تبكِ. / من / لا

Please don't cry.

[[Arabic#^ar-Q1000-answer|Compare the answer]]
^ar-Q1000


## Answers

The full sentence is a model. For translation, judge whether meaning and grammar are preserved. Each grammar rule above explains the form.

### Answers 1–50

**ar-Q0001** — أنا آسف، ولكن هذا لم يعد متاحاً.

I'm sorry, but it's no longer available.

Expected form: **أنا**

Why: Independent pronouns. [[Arabic#^ar-Q0001|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D9%86%D8%A7%20%D8%A2%D8%B3%D9%81%D8%8C%20%D9%88%D9%84%D9%83%D9%86%20%D9%87%D8%B0%D8%A7%20%D9%84%D9%85%20%D9%8A%D8%B9%D8%AF%20%D9%85%D8%AA%D8%A7%D8%AD%D8%A7%D9%8B.)
^ar-Q0001-answer

**ar-Q0002** — أنا آسف، ولكن هذا لم يعد متاحاً.

I'm sorry, but it's no longer available.

Expected form: **أنا**

Why: Independent pronouns. [[Arabic#^ar-Q0002|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D9%86%D8%A7%20%D8%A2%D8%B3%D9%81%D8%8C%20%D9%88%D9%84%D9%83%D9%86%20%D9%87%D8%B0%D8%A7%20%D9%84%D9%85%20%D9%8A%D8%B9%D8%AF%20%D9%85%D8%AA%D8%A7%D8%AD%D8%A7%D9%8B.)
^ar-Q0002-answer

**ar-Q0003** — أنا أعرف أين يعمل توم.

I know where Tom works.

Expected form: **أنا**

Why: Independent pronouns. [[Arabic#^ar-Q0003|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D9%86%D8%A7%20%D8%A3%D8%B9%D8%B1%D9%81%20%D8%A3%D9%8A%D9%86%20%D9%8A%D8%B9%D9%85%D9%84%20%D8%AA%D9%88%D9%85.)
^ar-Q0003-answer

**ar-Q0004** — أنا أعرف أين يعمل توم.

I know where Tom works.

Why: Independent pronouns. [[Arabic#^ar-Q0004|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D9%86%D8%A7%20%D8%A3%D8%B9%D8%B1%D9%81%20%D8%A3%D9%8A%D9%86%20%D9%8A%D8%B9%D9%85%D9%84%20%D8%AA%D9%88%D9%85.)
^ar-Q0004-answer

**ar-Q0005** — أنا آكل تفاحةً.

I'm eating an apple.

Why: Independent pronouns. [[Arabic#^ar-Q0005|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D9%86%D8%A7%20%D8%A2%D9%83%D9%84%20%D8%AA%D9%81%D8%A7%D8%AD%D8%A9%D9%8B.)
^ar-Q0005-answer

**ar-Q0006** — أنا آكل تفاحةً.

I'm eating an apple.

Independent pronouns identify person and number; Arabic also distinguishes gender and dual forms. A present nominal sentence normally has no expressed be verb. Standard and dialect pronoun systems differ.

Why: Independent pronouns. [[Arabic#^ar-Q0006|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D9%86%D8%A7%20%D8%A2%D9%83%D9%84%20%D8%AA%D9%81%D8%A7%D8%AD%D8%A9%D9%8B.)
^ar-Q0006-answer

**ar-Q0007** — نحن في الطابق الثامن

We are on the eighth floor.

Expected form: **نحن**

Why: Independent pronouns. [[Arabic#^ar-Q0007|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%86%D8%AD%D9%86%20%D9%81%D9%8A%20%D8%A7%D9%84%D8%B7%D8%A7%D8%A8%D9%82%20%D8%A7%D9%84%D8%AB%D8%A7%D9%85%D9%86)
^ar-Q0007-answer

**ar-Q0008** — نحن في الطابق الثامن

We are on the eighth floor.

Expected form: **نحن**

Why: Independent pronouns. [[Arabic#^ar-Q0008|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%86%D8%AD%D9%86%20%D9%81%D9%8A%20%D8%A7%D9%84%D8%B7%D8%A7%D8%A8%D9%82%20%D8%A7%D9%84%D8%AB%D8%A7%D9%85%D9%86)
^ar-Q0008-answer

**ar-Q0009** — هذا بسببك أنت.

This is because of you.

Expected form: **أنت**

Why: Independent pronouns. [[Arabic#^ar-Q0009|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D8%B0%D8%A7%20%D8%A8%D8%B3%D8%A8%D8%A8%D9%83%20%D8%A3%D9%86%D8%AA.)
^ar-Q0009-answer

**ar-Q0010** — هذا بسببك أنت.

This is because of you.

Why: Independent pronouns. [[Arabic#^ar-Q0010|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D8%B0%D8%A7%20%D8%A8%D8%B3%D8%A8%D8%A8%D9%83%20%D8%A3%D9%86%D8%AA.)
^ar-Q0010-answer

**ar-Q0011** — هي لا تريدني أن أتحدث حول هذه المسألة.

She doesn't want me to speak about this matter.

Why: Independent pronouns. [[Arabic#^ar-Q0011|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D9%8A%20%D9%84%D8%A7%20%D8%AA%D8%B1%D9%8A%D8%AF%D9%86%D9%8A%20%D8%A3%D9%86%20%D8%A3%D8%AA%D8%AD%D8%AF%D8%AB%20%D8%AD%D9%88%D9%84%20%D9%87%D8%B0%D9%87%20%D8%A7%D9%84%D9%85%D8%B3%D8%A3%D9%84%D8%A9.)
^ar-Q0011-answer

**ar-Q0012** — هي لا تريدني أن أتحدث حول هذه المسألة.

She doesn't want me to speak about this matter.

Independent pronouns identify person and number; Arabic also distinguishes gender and dual forms. A present nominal sentence normally has no expressed be verb. Standard and dialect pronoun systems differ.

Why: Independent pronouns. [[Arabic#^ar-Q0012|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D9%8A%20%D9%84%D8%A7%20%D8%AA%D8%B1%D9%8A%D8%AF%D9%86%D9%8A%20%D8%A3%D9%86%20%D8%A3%D8%AA%D8%AD%D8%AF%D8%AB%20%D8%AD%D9%88%D9%84%20%D9%87%D8%B0%D9%87%20%D8%A7%D9%84%D9%85%D8%B3%D8%A3%D9%84%D8%A9.)
^ar-Q0012-answer

**ar-Q0013** — لا أصدق أن توم هو القاتل.

I don't believe that Tom is the killer.

Expected form: **هو**

Why: Independent pronouns. [[Arabic#^ar-Q0013|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D8%A7%20%D8%A3%D8%B5%D8%AF%D9%82%20%D8%A3%D9%86%20%D8%AA%D9%88%D9%85%20%D9%87%D9%88%20%D8%A7%D9%84%D9%82%D8%A7%D8%AA%D9%84.)
^ar-Q0013-answer

**ar-Q0014** — لا أصدق أن توم هو القاتل.

I don't believe that Tom is the killer.

Expected form: **هو**

Why: Independent pronouns. [[Arabic#^ar-Q0014|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D8%A7%20%D8%A3%D8%B5%D8%AF%D9%82%20%D8%A3%D9%86%20%D8%AA%D9%88%D9%85%20%D9%87%D9%88%20%D8%A7%D9%84%D9%82%D8%A7%D8%AA%D9%84.)
^ar-Q0014-answer

**ar-Q0015** — هتف ديما: "أنا ديما! ألا يعمل كاشف المتصل عندك أم ماذا؟"

"It's Dima!" Dima exclaimed. "Is your caller ID not working or something?"

Expected form: **أنا**

Why: Independent pronouns. [[Arabic#^ar-Q0015|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D8%AA%D9%81%20%D8%AF%D9%8A%D9%85%D8%A7%3A%20%22%D8%A3%D9%86%D8%A7%20%D8%AF%D9%8A%D9%85%D8%A7%21%20%D8%A3%D9%84%D8%A7%20%D9%8A%D8%B9%D9%85%D9%84%20%D9%83%D8%A7%D8%B4%D9%81%20%D8%A7%D9%84%D9%85%D8%AA%D8%B5%D9%84%20%D8%B9%D9%86%D8%AF%D9%83%20%D8%A3%D9%85%20%D9%85%D8%A7%D8%B0%D8%A7%D8%9F%22)
^ar-Q0015-answer

**ar-Q0016** — هتف ديما: "أنا ديما! ألا يعمل كاشف المتصل عندك أم ماذا؟"

"It's Dima!" Dima exclaimed. "Is your caller ID not working or something?"

Why: Independent pronouns. [[Arabic#^ar-Q0016|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D8%AA%D9%81%20%D8%AF%D9%8A%D9%85%D8%A7%3A%20%22%D8%A3%D9%86%D8%A7%20%D8%AF%D9%8A%D9%85%D8%A7%21%20%D8%A3%D9%84%D8%A7%20%D9%8A%D8%B9%D9%85%D9%84%20%D9%83%D8%A7%D8%B4%D9%81%20%D8%A7%D9%84%D9%85%D8%AA%D8%B5%D9%84%20%D8%B9%D9%86%D8%AF%D9%83%20%D8%A3%D9%85%20%D9%85%D8%A7%D8%B0%D8%A7%D8%9F%22)
^ar-Q0016-answer

**ar-Q0017** — أنا أتتطلع لقضاء وقت مع عائلتي.

I'm looking forward to spending time with my family.

Why: Independent pronouns. [[Arabic#^ar-Q0017|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D9%86%D8%A7%20%D8%A3%D8%AA%D8%AA%D8%B7%D9%84%D8%B9%20%D9%84%D9%82%D8%B6%D8%A7%D8%A1%20%D9%88%D9%82%D8%AA%20%D9%85%D8%B9%20%D8%B9%D8%A7%D8%A6%D9%84%D8%AA%D9%8A.)
^ar-Q0017-answer

**ar-Q0018** — أنا أتتطلع لقضاء وقت مع عائلتي.

I'm looking forward to spending time with my family.

Independent pronouns identify person and number; Arabic also distinguishes gender and dual forms. A present nominal sentence normally has no expressed be verb. Standard and dialect pronoun systems differ.

Why: Independent pronouns. [[Arabic#^ar-Q0018|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D9%86%D8%A7%20%D8%A3%D8%AA%D8%AA%D8%B7%D9%84%D8%B9%20%D9%84%D9%82%D8%B6%D8%A7%D8%A1%20%D9%88%D9%82%D8%AA%20%D9%85%D8%B9%20%D8%B9%D8%A7%D8%A6%D9%84%D8%AA%D9%8A.)
^ar-Q0018-answer

**ar-Q0019** — نحن نتعلم العربي

We learn Arabic.

Expected form: **نحن**

Why: Independent pronouns. [[Arabic#^ar-Q0019|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%86%D8%AD%D9%86%20%D9%86%D8%AA%D8%B9%D9%84%D9%85%20%D8%A7%D9%84%D8%B9%D8%B1%D8%A8%D9%8A)
^ar-Q0019-answer

**ar-Q0020** — نحن نتعلم العربي

We learn Arabic.

Expected form: **نحن**

Why: Independent pronouns. [[Arabic#^ar-Q0020|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%86%D8%AD%D9%86%20%D9%86%D8%AA%D8%B9%D9%84%D9%85%20%D8%A7%D9%84%D8%B9%D8%B1%D8%A8%D9%8A)
^ar-Q0020-answer

**ar-Q0021** — هو في الخدمة.

He is on duty.

Expected form: **هو**

Why: Independent pronouns. [[Arabic#^ar-Q0021|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D9%88%20%D9%81%D9%8A%20%D8%A7%D9%84%D8%AE%D8%AF%D9%85%D8%A9.)
^ar-Q0021-answer

**ar-Q0022** — هو في الخدمة.

He is on duty.

Why: Independent pronouns. [[Arabic#^ar-Q0022|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D9%88%20%D9%81%D9%8A%20%D8%A7%D9%84%D8%AE%D8%AF%D9%85%D8%A9.)
^ar-Q0022-answer

**ar-Q0023** — أنا وأنت نشكل فريقا جيدا.

You and I make a good team.

Why: Independent pronouns. [[Arabic#^ar-Q0023|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D9%86%D8%A7%20%D9%88%D8%A3%D9%86%D8%AA%20%D9%86%D8%B4%D9%83%D9%84%20%D9%81%D8%B1%D9%8A%D9%82%D8%A7%20%D8%AC%D9%8A%D8%AF%D8%A7.)
^ar-Q0023-answer

**ar-Q0024** — أنا وأنت نشكل فريقا جيدا.

You and I make a good team.

Independent pronouns identify person and number; Arabic also distinguishes gender and dual forms. A present nominal sentence normally has no expressed be verb. Standard and dialect pronoun systems differ.

Why: Independent pronouns. [[Arabic#^ar-Q0024|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D9%86%D8%A7%20%D9%88%D8%A3%D9%86%D8%AA%20%D9%86%D8%B4%D9%83%D9%84%20%D9%81%D8%B1%D9%8A%D9%82%D8%A7%20%D8%AC%D9%8A%D8%AF%D8%A7.)
^ar-Q0024-answer

**ar-Q0025** — أنا أحبّها كأخت.

I love her like a sister.

Expected form: **أنا**

Why: Independent pronouns. [[Arabic#^ar-Q0025|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D9%86%D8%A7%20%D8%A3%D8%AD%D8%A8%D9%91%D9%87%D8%A7%20%D9%83%D8%A3%D8%AE%D8%AA.)
^ar-Q0025-answer

**ar-Q0026** — أنا أحبّها كأخت.

I love her like a sister.

Expected form: **أنا**

Why: Independent pronouns. [[Arabic#^ar-Q0026|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D9%86%D8%A7%20%D8%A3%D8%AD%D8%A8%D9%91%D9%87%D8%A7%20%D9%83%D8%A3%D8%AE%D8%AA.)
^ar-Q0026-answer

**ar-Q0027** — أنا أشعر بالعطش.

I'm thirsty.

Expected form: **أنا**

Why: Independent pronouns. [[Arabic#^ar-Q0027|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D9%86%D8%A7%20%D8%A3%D8%B4%D8%B9%D8%B1%20%D8%A8%D8%A7%D9%84%D8%B9%D8%B7%D8%B4.)
^ar-Q0027-answer

**ar-Q0028** — أنا أشعر بالعطش.

I'm thirsty.

Why: Independent pronouns. [[Arabic#^ar-Q0028|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D9%86%D8%A7%20%D8%A3%D8%B4%D8%B9%D8%B1%20%D8%A8%D8%A7%D9%84%D8%B9%D8%B7%D8%B4.)
^ar-Q0028-answer

**ar-Q0029** — أحتاج لدواء. أين هي الصّيدليّة؟

I need medicine. Where is the pharmacy?

Why: Independent pronouns. [[Arabic#^ar-Q0029|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%AD%D8%AA%D8%A7%D8%AC%20%D9%84%D8%AF%D9%88%D8%A7%D8%A1.%20%D8%A3%D9%8A%D9%86%20%D9%87%D9%8A%20%D8%A7%D9%84%D8%B5%D9%91%D9%8A%D8%AF%D9%84%D9%8A%D9%91%D8%A9%D8%9F)
^ar-Q0029-answer

**ar-Q0030** — أحتاج لدواء. أين هي الصّيدليّة؟

I need medicine. Where is the pharmacy?

Independent pronouns identify person and number; Arabic also distinguishes gender and dual forms. A present nominal sentence normally has no expressed be verb. Standard and dialect pronoun systems differ.

Why: Independent pronouns. [[Arabic#^ar-Q0030|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%AD%D8%AA%D8%A7%D8%AC%20%D9%84%D8%AF%D9%88%D8%A7%D8%A1.%20%D8%A3%D9%8A%D9%86%20%D9%87%D9%8A%20%D8%A7%D9%84%D8%B5%D9%91%D9%8A%D8%AF%D9%84%D9%8A%D9%91%D8%A9%D8%9F)
^ar-Q0030-answer

**ar-Q0031** — هي تحب الحيوانات.

She is fond of animals.

Expected form: **هي**

Why: Independent pronouns. [[Arabic#^ar-Q0031|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D9%8A%20%D8%AA%D8%AD%D8%A8%20%D8%A7%D9%84%D8%AD%D9%8A%D9%88%D8%A7%D9%86%D8%A7%D8%AA.)
^ar-Q0031-answer

**ar-Q0032** — هي تحب الحيوانات.

She is fond of animals.

Expected form: **هي**

Why: Independent pronouns. [[Arabic#^ar-Q0032|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D9%8A%20%D8%AA%D8%AD%D8%A8%20%D8%A7%D9%84%D8%AD%D9%8A%D9%88%D8%A7%D9%86%D8%A7%D8%AA.)
^ar-Q0032-answer

**ar-Q0033** — أنا أستطيع أن أعيش بدون ماء.

I can live without water.

Expected form: **أنا**

Why: Independent pronouns. [[Arabic#^ar-Q0033|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D9%86%D8%A7%20%D8%A3%D8%B3%D8%AA%D8%B7%D9%8A%D8%B9%20%D8%A3%D9%86%20%D8%A3%D8%B9%D9%8A%D8%B4%20%D8%A8%D8%AF%D9%88%D9%86%20%D9%85%D8%A7%D8%A1.)
^ar-Q0033-answer

**ar-Q0034** — أنا أستطيع أن أعيش بدون ماء.

I can live without water.

Why: Independent pronouns. [[Arabic#^ar-Q0034|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D9%86%D8%A7%20%D8%A3%D8%B3%D8%AA%D8%B7%D9%8A%D8%B9%20%D8%A3%D9%86%20%D8%A3%D8%B9%D9%8A%D8%B4%20%D8%A8%D8%AF%D9%88%D9%86%20%D9%85%D8%A7%D8%A1.)
^ar-Q0034-answer

**ar-Q0035** — أنا في المغسل.

I'm in the bath.

Why: Independent pronouns. [[Arabic#^ar-Q0035|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D9%86%D8%A7%20%D9%81%D9%8A%20%D8%A7%D9%84%D9%85%D8%BA%D8%B3%D9%84.)
^ar-Q0035-answer

**ar-Q0036** — أنا في المغسل.

I'm in the bath.

Independent pronouns identify person and number; Arabic also distinguishes gender and dual forms. A present nominal sentence normally has no expressed be verb. Standard and dialect pronoun systems differ.

Why: Independent pronouns. [[Arabic#^ar-Q0036|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D9%86%D8%A7%20%D9%81%D9%8A%20%D8%A7%D9%84%D9%85%D8%BA%D8%B3%D9%84.)
^ar-Q0036-answer

**ar-Q0037** — الاثنين -بالنسبة لي- هو أكثر الأيام انشغالًا.

Monday is my busiest day.

Expected form: **هو**

Why: Independent pronouns. [[Arabic#^ar-Q0037|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A7%D9%84%D8%A7%D8%AB%D9%86%D9%8A%D9%86%20-%D8%A8%D8%A7%D9%84%D9%86%D8%B3%D8%A8%D8%A9%20%D9%84%D9%8A-%20%D9%87%D9%88%20%D8%A3%D9%83%D8%AB%D8%B1%20%D8%A7%D9%84%D8%A3%D9%8A%D8%A7%D9%85%20%D8%A7%D9%86%D8%B4%D8%BA%D8%A7%D9%84%D9%8B%D8%A7.)
^ar-Q0037-answer

**ar-Q0038** — الاثنين -بالنسبة لي- هو أكثر الأيام انشغالًا.

Monday is my busiest day.

Expected form: **هو**

Why: Independent pronouns. [[Arabic#^ar-Q0038|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A7%D9%84%D8%A7%D8%AB%D9%86%D9%8A%D9%86%20-%D8%A8%D8%A7%D9%84%D9%86%D8%B3%D8%A8%D8%A9%20%D9%84%D9%8A-%20%D9%87%D9%88%20%D8%A3%D9%83%D8%AB%D8%B1%20%D8%A7%D9%84%D8%A3%D9%8A%D8%A7%D9%85%20%D8%A7%D9%86%D8%B4%D8%BA%D8%A7%D9%84%D9%8B%D8%A7.)
^ar-Q0038-answer

**ar-Q0039** — هذه هي الساعة التي اشتريتها امس .

This is the watch I bought yesterday.

Expected form: **هي**

Why: Independent pronouns. [[Arabic#^ar-Q0039|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D8%B0%D9%87%20%D9%87%D9%8A%20%D8%A7%D9%84%D8%B3%D8%A7%D8%B9%D8%A9%20%D8%A7%D9%84%D8%AA%D9%8A%20%D8%A7%D8%B4%D8%AA%D8%B1%D9%8A%D8%AA%D9%87%D8%A7%20%D8%A7%D9%85%D8%B3%20.)
^ar-Q0039-answer

**ar-Q0040** — هذه هي الساعة التي اشتريتها امس .

This is the watch I bought yesterday.

Why: Independent pronouns. [[Arabic#^ar-Q0040|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D8%B0%D9%87%20%D9%87%D9%8A%20%D8%A7%D9%84%D8%B3%D8%A7%D8%B9%D8%A9%20%D8%A7%D9%84%D8%AA%D9%8A%20%D8%A7%D8%B4%D8%AA%D8%B1%D9%8A%D8%AA%D9%87%D8%A7%20%D8%A7%D9%85%D8%B3%20.)
^ar-Q0040-answer

**ar-Q0041** — أنا هو الشخص الذي يحبك.

I'm the one who loves you.

Why: Independent pronouns. [[Arabic#^ar-Q0041|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D9%86%D8%A7%20%D9%87%D9%88%20%D8%A7%D9%84%D8%B4%D8%AE%D8%B5%20%D8%A7%D9%84%D8%B0%D9%8A%20%D9%8A%D8%AD%D8%A8%D9%83.)
^ar-Q0041-answer

**ar-Q0042** — أنا هو الشخص الذي يحبك.

I'm the one who loves you.

Independent pronouns identify person and number; Arabic also distinguishes gender and dual forms. A present nominal sentence normally has no expressed be verb. Standard and dialect pronoun systems differ.

Why: Independent pronouns. [[Arabic#^ar-Q0042|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D9%86%D8%A7%20%D9%87%D9%88%20%D8%A7%D9%84%D8%B4%D8%AE%D8%B5%20%D8%A7%D9%84%D8%B0%D9%8A%20%D9%8A%D8%AD%D8%A8%D9%83.)
^ar-Q0042-answer

**ar-Q0043** — حقا، أنت لست غبيا.

You're really not stupid.

Expected form: **أنت**

Why: Independent pronouns. [[Arabic#^ar-Q0043|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%AD%D9%82%D8%A7%D8%8C%20%D8%A3%D9%86%D8%AA%20%D9%84%D8%B3%D8%AA%20%D8%BA%D8%A8%D9%8A%D8%A7.)
^ar-Q0043-answer

**ar-Q0044** — حقا، أنت لست غبيا.

You're really not stupid.

Expected form: **أنت**

Why: Independent pronouns. [[Arabic#^ar-Q0044|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%AD%D9%82%D8%A7%D8%8C%20%D8%A3%D9%86%D8%AA%20%D9%84%D8%B3%D8%AA%20%D8%BA%D8%A8%D9%8A%D8%A7.)
^ar-Q0044-answer

**ar-Q0045** — ما هو الجزء الأهم في التعليم الجيد؟

What's the most important part of a good education?

Expected form: **هو**

Why: Independent pronouns. [[Arabic#^ar-Q0045|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D8%A7%20%D9%87%D9%88%20%D8%A7%D9%84%D8%AC%D8%B2%D8%A1%20%D8%A7%D9%84%D8%A3%D9%87%D9%85%20%D9%81%D9%8A%20%D8%A7%D9%84%D8%AA%D8%B9%D9%84%D9%8A%D9%85%20%D8%A7%D9%84%D8%AC%D9%8A%D8%AF%D8%9F)
^ar-Q0045-answer

**ar-Q0046** — ما هو الجزء الأهم في التعليم الجيد؟

What's the most important part of a good education?

Why: Independent pronouns. [[Arabic#^ar-Q0046|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D8%A7%20%D9%87%D9%88%20%D8%A7%D9%84%D8%AC%D8%B2%D8%A1%20%D8%A7%D9%84%D8%A3%D9%87%D9%85%20%D9%81%D9%8A%20%D8%A7%D9%84%D8%AA%D8%B9%D9%84%D9%8A%D9%85%20%D8%A7%D9%84%D8%AC%D9%8A%D8%AF%D8%9F)
^ar-Q0046-answer

**ar-Q0047** — أنت طالب جيد.

You are a good student.

Why: Independent pronouns. [[Arabic#^ar-Q0047|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D9%86%D8%AA%20%D8%B7%D8%A7%D9%84%D8%A8%20%D8%AC%D9%8A%D8%AF.)
^ar-Q0047-answer

**ar-Q0048** — أنت طالب جيد.

You are a good student.

Independent pronouns identify person and number; Arabic also distinguishes gender and dual forms. A present nominal sentence normally has no expressed be verb. Standard and dialect pronoun systems differ.

Why: Independent pronouns. [[Arabic#^ar-Q0048|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D9%86%D8%AA%20%D8%B7%D8%A7%D9%84%D8%A8%20%D8%AC%D9%8A%D8%AF.)
^ar-Q0048-answer

**ar-Q0049** — هي ستكون دائماً معك.

She will always be with you.

Expected form: **هي**

Why: Independent pronouns. [[Arabic#^ar-Q0049|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D9%8A%20%D8%B3%D8%AA%D9%83%D9%88%D9%86%20%D8%AF%D8%A7%D8%A6%D9%85%D8%A7%D9%8B%20%D9%85%D8%B9%D9%83.)
^ar-Q0049-answer

**ar-Q0050** — هي ستكون دائماً معك.

She will always be with you.

Expected form: **هي**

Why: Independent pronouns. [[Arabic#^ar-Q0050|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D9%8A%20%D8%B3%D8%AA%D9%83%D9%88%D9%86%20%D8%AF%D8%A7%D8%A6%D9%85%D8%A7%D9%8B%20%D9%85%D8%B9%D9%83.)
^ar-Q0050-answer


### Answers 51–100

**ar-Q0051** — هذا أغبى ما قُلتُه على الإطلاق.

That's the stupidest thing I've ever said.

Expected form: **هذا**

Why: Demonstratives. [[Arabic#^ar-Q0051|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D8%B0%D8%A7%20%D8%A3%D8%BA%D8%A8%D9%89%20%D9%85%D8%A7%20%D9%82%D9%8F%D9%84%D8%AA%D9%8F%D9%87%20%D8%B9%D9%84%D9%89%20%D8%A7%D9%84%D8%A5%D8%B7%D9%84%D8%A7%D9%82.)
^ar-Q0051-answer

**ar-Q0052** — هذا أغبى ما قُلتُه على الإطلاق.

That's the stupidest thing I've ever said.

Why: Demonstratives. [[Arabic#^ar-Q0052|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D8%B0%D8%A7%20%D8%A3%D8%BA%D8%A8%D9%89%20%D9%85%D8%A7%20%D9%82%D9%8F%D9%84%D8%AA%D9%8F%D9%87%20%D8%B9%D9%84%D9%89%20%D8%A7%D9%84%D8%A5%D8%B7%D9%84%D8%A7%D9%82.)
^ar-Q0052-answer

**ar-Q0053** — أداء هذه السيارة أفضل من تلك.

This car has a better performance than that one.

Why: Demonstratives. [[Arabic#^ar-Q0053|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%AF%D8%A7%D8%A1%20%D9%87%D8%B0%D9%87%20%D8%A7%D9%84%D8%B3%D9%8A%D8%A7%D8%B1%D8%A9%20%D8%A3%D9%81%D8%B6%D9%84%20%D9%85%D9%86%20%D8%AA%D9%84%D9%83.)
^ar-Q0053-answer

**ar-Q0054** — أداء هذه السيارة أفضل من تلك.

This car has a better performance than that one.

Demonstratives agree in relevant gender/number distinctions. هذا كتاب is this is a book, whereas هذا الكتاب refers to this book as a phrase. Definiteness affects the structure.

Why: Demonstratives. [[Arabic#^ar-Q0054|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%AF%D8%A7%D8%A1%20%D9%87%D8%B0%D9%87%20%D8%A7%D9%84%D8%B3%D9%8A%D8%A7%D8%B1%D8%A9%20%D8%A3%D9%81%D8%B6%D9%84%20%D9%85%D9%86%20%D8%AA%D9%84%D9%83.)
^ar-Q0054-answer

**ar-Q0055** — لا يعيش أحد في هذا المنزل.

Nobody lives in this house.

Expected form: **هذا**

Why: Demonstratives. [[Arabic#^ar-Q0055|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D8%A7%20%D9%8A%D8%B9%D9%8A%D8%B4%20%D8%A3%D8%AD%D8%AF%20%D9%81%D9%8A%20%D9%87%D8%B0%D8%A7%20%D8%A7%D9%84%D9%85%D9%86%D8%B2%D9%84.)
^ar-Q0055-answer

**ar-Q0056** — لا يعيش أحد في هذا المنزل.

Nobody lives in this house.

Expected form: **هذا**

Why: Demonstratives. [[Arabic#^ar-Q0056|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D8%A7%20%D9%8A%D8%B9%D9%8A%D8%B4%20%D8%A3%D8%AD%D8%AF%20%D9%81%D9%8A%20%D9%87%D8%B0%D8%A7%20%D8%A7%D9%84%D9%85%D9%86%D8%B2%D9%84.)
^ar-Q0056-answer

**ar-Q0057** — وافق سامي هذا.

Sami agreed to that.

Expected form: **هذا**

Why: Demonstratives. [[Arabic#^ar-Q0057|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%88%D8%A7%D9%81%D9%82%20%D8%B3%D8%A7%D9%85%D9%8A%20%D9%87%D8%B0%D8%A7.)
^ar-Q0057-answer

**ar-Q0058** — وافق سامي هذا.

Sami agreed to that.

Why: Demonstratives. [[Arabic#^ar-Q0058|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%88%D8%A7%D9%81%D9%82%20%D8%B3%D8%A7%D9%85%D9%8A%20%D9%87%D8%B0%D8%A7.)
^ar-Q0058-answer

**ar-Q0059** — لا أستطيع أن أتحمل هذا الصوت.

I can't put up with this noise.

Why: Demonstratives. [[Arabic#^ar-Q0059|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D8%A7%20%D8%A3%D8%B3%D8%AA%D8%B7%D9%8A%D8%B9%20%D8%A3%D9%86%20%D8%A3%D8%AA%D8%AD%D9%85%D9%84%20%D9%87%D8%B0%D8%A7%20%D8%A7%D9%84%D8%B5%D9%88%D8%AA.)
^ar-Q0059-answer

**ar-Q0060** — لا أستطيع أن أتحمل هذا الصوت.

I can't put up with this noise.

Demonstratives agree in relevant gender/number distinctions. هذا كتاب is this is a book, whereas هذا الكتاب refers to this book as a phrase. Definiteness affects the structure.

Why: Demonstratives. [[Arabic#^ar-Q0060|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D8%A7%20%D8%A3%D8%B3%D8%AA%D8%B7%D9%8A%D8%B9%20%D8%A3%D9%86%20%D8%A3%D8%AA%D8%AD%D9%85%D9%84%20%D9%87%D8%B0%D8%A7%20%D8%A7%D9%84%D8%B5%D9%88%D8%AA.)
^ar-Q0060-answer

**ar-Q0061** — متأكد أن توم لن يفعل ذلك.

I'm sure Tom would never do that.

Expected form: **ذلك**

Why: Demonstratives. [[Arabic#^ar-Q0061|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D8%AA%D8%A3%D9%83%D8%AF%20%D8%A3%D9%86%20%D8%AA%D9%88%D9%85%20%D9%84%D9%86%20%D9%8A%D9%81%D8%B9%D9%84%20%D8%B0%D9%84%D9%83.)
^ar-Q0061-answer

**ar-Q0062** — متأكد أن توم لن يفعل ذلك.

I'm sure Tom would never do that.

Expected form: **ذلك**

Why: Demonstratives. [[Arabic#^ar-Q0062|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D8%AA%D8%A3%D9%83%D8%AF%20%D8%A3%D9%86%20%D8%AA%D9%88%D9%85%20%D9%84%D9%86%20%D9%8A%D9%81%D8%B9%D9%84%20%D8%B0%D9%84%D9%83.)
^ar-Q0062-answer

**ar-Q0063** — هل لديك أي فكرة عن من يستطيع فعل مِثل هذا الشيء؟

Do you have any idea who would do this kind of thing?

Expected form: **هذا**

Why: Demonstratives. [[Arabic#^ar-Q0063|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D9%84%20%D9%84%D8%AF%D9%8A%D9%83%20%D8%A3%D9%8A%20%D9%81%D9%83%D8%B1%D8%A9%20%D8%B9%D9%86%20%D9%85%D9%86%20%D9%8A%D8%B3%D8%AA%D8%B7%D9%8A%D8%B9%20%D9%81%D8%B9%D9%84%20%D9%85%D9%90%D8%AB%D9%84%20%D9%87%D8%B0%D8%A7%20%D8%A7%D9%84%D8%B4%D9%8A%D8%A1%D8%9F)
^ar-Q0063-answer

**ar-Q0064** — هل لديك أي فكرة عن من يستطيع فعل مِثل هذا الشيء؟

Do you have any idea who would do this kind of thing?

Why: Demonstratives. [[Arabic#^ar-Q0064|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D9%84%20%D9%84%D8%AF%D9%8A%D9%83%20%D8%A3%D9%8A%20%D9%81%D9%83%D8%B1%D8%A9%20%D8%B9%D9%86%20%D9%85%D9%86%20%D9%8A%D8%B3%D8%AA%D8%B7%D9%8A%D8%B9%20%D9%81%D8%B9%D9%84%20%D9%85%D9%90%D8%AB%D9%84%20%D9%87%D8%B0%D8%A7%20%D8%A7%D9%84%D8%B4%D9%8A%D8%A1%D8%9F)
^ar-Q0064-answer

**ar-Q0065** — من الافضل أن تبقی صامتا إذا لم تكن تعلم شيئا عن هذا الأمر

If you don't know anything about the matter, it's better that you keep quiet.

Why: Demonstratives. [[Arabic#^ar-Q0065|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D9%86%20%D8%A7%D9%84%D8%A7%D9%81%D8%B6%D9%84%20%D8%A3%D9%86%20%D8%AA%D8%A8%D9%82%DB%8C%20%D8%B5%D8%A7%D9%85%D8%AA%D8%A7%20%D8%A5%D8%B0%D8%A7%20%D9%84%D9%85%20%D8%AA%D9%83%D9%86%20%D8%AA%D8%B9%D9%84%D9%85%20%D8%B4%D9%8A%D8%A6%D8%A7%20%D8%B9%D9%86%20%D9%87%D8%B0%D8%A7%20%D8%A7%D9%84%D8%A3%D9%85%D8%B1)
^ar-Q0065-answer

**ar-Q0066** — من الافضل أن تبقی صامتا إذا لم تكن تعلم شيئا عن هذا الأمر

If you don't know anything about the matter, it's better that you keep quiet.

Demonstratives agree in relevant gender/number distinctions. هذا كتاب is this is a book, whereas هذا الكتاب refers to this book as a phrase. Definiteness affects the structure.

Why: Demonstratives. [[Arabic#^ar-Q0066|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D9%86%20%D8%A7%D9%84%D8%A7%D9%81%D8%B6%D9%84%20%D8%A3%D9%86%20%D8%AA%D8%A8%D9%82%DB%8C%20%D8%B5%D8%A7%D9%85%D8%AA%D8%A7%20%D8%A5%D8%B0%D8%A7%20%D9%84%D9%85%20%D8%AA%D9%83%D9%86%20%D8%AA%D8%B9%D9%84%D9%85%20%D8%B4%D9%8A%D8%A6%D8%A7%20%D8%B9%D9%86%20%D9%87%D8%B0%D8%A7%20%D8%A7%D9%84%D8%A3%D9%85%D8%B1)
^ar-Q0066-answer

**ar-Q0067** — هذا الطائر لا يمكنه الطيران.

This bird cannot fly.

Expected form: **هذا**

Why: Demonstratives. [[Arabic#^ar-Q0067|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D8%B0%D8%A7%20%D8%A7%D9%84%D8%B7%D8%A7%D8%A6%D8%B1%20%D9%84%D8%A7%20%D9%8A%D9%85%D9%83%D9%86%D9%87%20%D8%A7%D9%84%D8%B7%D9%8A%D8%B1%D8%A7%D9%86.)
^ar-Q0067-answer

**ar-Q0068** — هذا الطائر لا يمكنه الطيران.

This bird cannot fly.

Expected form: **هذا**

Why: Demonstratives. [[Arabic#^ar-Q0068|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D8%B0%D8%A7%20%D8%A7%D9%84%D8%B7%D8%A7%D8%A6%D8%B1%20%D9%84%D8%A7%20%D9%8A%D9%85%D9%83%D9%86%D9%87%20%D8%A7%D9%84%D8%B7%D9%8A%D8%B1%D8%A7%D9%86.)
^ar-Q0068-answer

**ar-Q0069** — لا يبدو هذا عادلا إطلاقا.

That doesn't seem right at all.

Expected form: **هذا**

Why: Demonstratives. [[Arabic#^ar-Q0069|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D8%A7%20%D9%8A%D8%A8%D8%AF%D9%88%20%D9%87%D8%B0%D8%A7%20%D8%B9%D8%A7%D8%AF%D9%84%D8%A7%20%D8%A5%D8%B7%D9%84%D8%A7%D9%82%D8%A7.)
^ar-Q0069-answer

**ar-Q0070** — لا يبدو هذا عادلا إطلاقا.

That doesn't seem right at all.

Why: Demonstratives. [[Arabic#^ar-Q0070|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D8%A7%20%D9%8A%D8%A8%D8%AF%D9%88%20%D9%87%D8%B0%D8%A7%20%D8%B9%D8%A7%D8%AF%D9%84%D8%A7%20%D8%A5%D8%B7%D9%84%D8%A7%D9%82%D8%A7.)
^ar-Q0070-answer

**ar-Q0071** — هذا الكتاب سيفي بالغرض.

This book will do.

Why: Demonstratives. [[Arabic#^ar-Q0071|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D8%B0%D8%A7%20%D8%A7%D9%84%D9%83%D8%AA%D8%A7%D8%A8%20%D8%B3%D9%8A%D9%81%D9%8A%20%D8%A8%D8%A7%D9%84%D8%BA%D8%B1%D8%B6.)
^ar-Q0071-answer

**ar-Q0072** — هذا الكتاب سيفي بالغرض.

This book will do.

Demonstratives agree in relevant gender/number distinctions. هذا كتاب is this is a book, whereas هذا الكتاب refers to this book as a phrase. Definiteness affects the structure.

Why: Demonstratives. [[Arabic#^ar-Q0072|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D8%B0%D8%A7%20%D8%A7%D9%84%D9%83%D8%AA%D8%A7%D8%A8%20%D8%B3%D9%8A%D9%81%D9%8A%20%D8%A8%D8%A7%D9%84%D8%BA%D8%B1%D8%B6.)
^ar-Q0072-answer

**ar-Q0073** — أنی لك هذا ؟

Where did you get this?

Expected form: **هذا**

Why: Demonstratives. [[Arabic#^ar-Q0073|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D9%86%DB%8C%20%D9%84%D9%83%20%D9%87%D8%B0%D8%A7%20%D8%9F)
^ar-Q0073-answer

**ar-Q0074** — أنی لك هذا ؟

Where did you get this?

Expected form: **هذا**

Why: Demonstratives. [[Arabic#^ar-Q0074|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D9%86%DB%8C%20%D9%84%D9%83%20%D9%87%D8%B0%D8%A7%20%D8%9F)
^ar-Q0074-answer

**ar-Q0075** — علينا عمل هذا بأنفسنا.

We have to do this by ourselves.

Expected form: **هذا**

Why: Demonstratives. [[Arabic#^ar-Q0075|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B9%D9%84%D9%8A%D9%86%D8%A7%20%D8%B9%D9%85%D9%84%20%D9%87%D8%B0%D8%A7%20%D8%A8%D8%A3%D9%86%D9%81%D8%B3%D9%86%D8%A7.)
^ar-Q0075-answer

**ar-Q0076** — علينا عمل هذا بأنفسنا.

We have to do this by ourselves.

Why: Demonstratives. [[Arabic#^ar-Q0076|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B9%D9%84%D9%8A%D9%86%D8%A7%20%D8%B9%D9%85%D9%84%20%D9%87%D8%B0%D8%A7%20%D8%A8%D8%A3%D9%86%D9%81%D8%B3%D9%86%D8%A7.)
^ar-Q0076-answer

**ar-Q0077** — الآن حصلت على كتب هذا الفصل.

I just got my textbooks for this semester.

Why: Demonstratives. [[Arabic#^ar-Q0077|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A7%D9%84%D8%A2%D9%86%20%D8%AD%D8%B5%D9%84%D8%AA%20%D8%B9%D9%84%D9%89%20%D9%83%D8%AA%D8%A8%20%D9%87%D8%B0%D8%A7%20%D8%A7%D9%84%D9%81%D8%B5%D9%84.)
^ar-Q0077-answer

**ar-Q0078** — الآن حصلت على كتب هذا الفصل.

I just got my textbooks for this semester.

Demonstratives agree in relevant gender/number distinctions. هذا كتاب is this is a book, whereas هذا الكتاب refers to this book as a phrase. Definiteness affects the structure.

Why: Demonstratives. [[Arabic#^ar-Q0078|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A7%D9%84%D8%A2%D9%86%20%D8%AD%D8%B5%D9%84%D8%AA%20%D8%B9%D9%84%D9%89%20%D9%83%D8%AA%D8%A8%20%D9%87%D8%B0%D8%A7%20%D8%A7%D9%84%D9%81%D8%B5%D9%84.)
^ar-Q0078-answer

**ar-Q0079** — هذه صفحتي على الفيسبوك.

This is my page on Facebook.

Expected form: **هذه**

Why: Demonstratives. [[Arabic#^ar-Q0079|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D8%B0%D9%87%20%D8%B5%D9%81%D8%AD%D8%AA%D9%8A%20%D8%B9%D9%84%D9%89%20%D8%A7%D9%84%D9%81%D9%8A%D8%B3%D8%A8%D9%88%D9%83.)
^ar-Q0079-answer

**ar-Q0080** — هذه صفحتي على الفيسبوك.

This is my page on Facebook.

Expected form: **هذه**

Why: Demonstratives. [[Arabic#^ar-Q0080|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D8%B0%D9%87%20%D8%B5%D9%81%D8%AD%D8%AA%D9%8A%20%D8%B9%D9%84%D9%89%20%D8%A7%D9%84%D9%81%D9%8A%D8%B3%D8%A8%D9%88%D9%83.)
^ar-Q0080-answer

**ar-Q0081** — يجب عليك فعل ذلك بنفسك.

You must do it yourself.

Expected form: **ذلك**

Why: Demonstratives. [[Arabic#^ar-Q0081|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%8A%D8%AC%D8%A8%20%D8%B9%D9%84%D9%8A%D9%83%20%D9%81%D8%B9%D9%84%20%D8%B0%D9%84%D9%83%20%D8%A8%D9%86%D9%81%D8%B3%D9%83.)
^ar-Q0081-answer

**ar-Q0082** — يجب عليك فعل ذلك بنفسك.

You must do it yourself.

Why: Demonstratives. [[Arabic#^ar-Q0082|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%8A%D8%AC%D8%A8%20%D8%B9%D9%84%D9%8A%D9%83%20%D9%81%D8%B9%D9%84%20%D8%B0%D9%84%D9%83%20%D8%A8%D9%86%D9%81%D8%B3%D9%83.)
^ar-Q0082-answer

**ar-Q0083** — هذا رقم هاتفي.

Here's my telephone number.

Why: Demonstratives. [[Arabic#^ar-Q0083|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D8%B0%D8%A7%20%D8%B1%D9%82%D9%85%20%D9%87%D8%A7%D8%AA%D9%81%D9%8A.)
^ar-Q0083-answer

**ar-Q0084** — هذا رقم هاتفي.

Here's my telephone number.

Demonstratives agree in relevant gender/number distinctions. هذا كتاب is this is a book, whereas هذا الكتاب refers to this book as a phrase. Definiteness affects the structure.

Why: Demonstratives. [[Arabic#^ar-Q0084|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D8%B0%D8%A7%20%D8%B1%D9%82%D9%85%20%D9%87%D8%A7%D8%AA%D9%81%D9%8A.)
^ar-Q0084-answer

**ar-Q0085** — هذه القاعة لا تتسع لذاك المكتب.

That desk does not fit in this room.

Expected form: **هذه**

Why: Demonstratives. [[Arabic#^ar-Q0085|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D8%B0%D9%87%20%D8%A7%D9%84%D9%82%D8%A7%D8%B9%D8%A9%20%D9%84%D8%A7%20%D8%AA%D8%AA%D8%B3%D8%B9%20%D9%84%D8%B0%D8%A7%D9%83%20%D8%A7%D9%84%D9%85%D9%83%D8%AA%D8%A8.)
^ar-Q0085-answer

**ar-Q0086** — هذه القاعة لا تتسع لذاك المكتب.

That desk does not fit in this room.

Expected form: **هذه**

Why: Demonstratives. [[Arabic#^ar-Q0086|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D8%B0%D9%87%20%D8%A7%D9%84%D9%82%D8%A7%D8%B9%D8%A9%20%D9%84%D8%A7%20%D8%AA%D8%AA%D8%B3%D8%B9%20%D9%84%D8%B0%D8%A7%D9%83%20%D8%A7%D9%84%D9%85%D9%83%D8%AA%D8%A8.)
^ar-Q0086-answer

**ar-Q0087** — لم أكن أريد أن أفعل هذا بهذه الطريقة.

I didn't want to do it this way.

Expected form: **هذا**

Why: Demonstratives. [[Arabic#^ar-Q0087|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%85%20%D8%A3%D9%83%D9%86%20%D8%A3%D8%B1%D9%8A%D8%AF%20%D8%A3%D9%86%20%D8%A3%D9%81%D8%B9%D9%84%20%D9%87%D8%B0%D8%A7%20%D8%A8%D9%87%D8%B0%D9%87%20%D8%A7%D9%84%D8%B7%D8%B1%D9%8A%D9%82%D8%A9.)
^ar-Q0087-answer

**ar-Q0088** — لم أكن أريد أن أفعل هذا بهذه الطريقة.

I didn't want to do it this way.

Why: Demonstratives. [[Arabic#^ar-Q0088|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%85%20%D8%A3%D9%83%D9%86%20%D8%A3%D8%B1%D9%8A%D8%AF%20%D8%A3%D9%86%20%D8%A3%D9%81%D8%B9%D9%84%20%D9%87%D8%B0%D8%A7%20%D8%A8%D9%87%D8%B0%D9%87%20%D8%A7%D9%84%D8%B7%D8%B1%D9%8A%D9%82%D8%A9.)
^ar-Q0088-answer

**ar-Q0089** — وبخني ذلك المعلم كثيرًا.

I got scolded severely by that teacher.

Why: Demonstratives. [[Arabic#^ar-Q0089|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%88%D8%A8%D8%AE%D9%86%D9%8A%20%D8%B0%D9%84%D9%83%20%D8%A7%D9%84%D9%85%D8%B9%D9%84%D9%85%20%D9%83%D8%AB%D9%8A%D8%B1%D9%8B%D8%A7.)
^ar-Q0089-answer

**ar-Q0090** — وبخني ذلك المعلم كثيرًا.

I got scolded severely by that teacher.

Demonstratives agree in relevant gender/number distinctions. هذا كتاب is this is a book, whereas هذا الكتاب refers to this book as a phrase. Definiteness affects the structure.

Why: Demonstratives. [[Arabic#^ar-Q0090|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%88%D8%A8%D8%AE%D9%86%D9%8A%20%D8%B0%D9%84%D9%83%20%D8%A7%D9%84%D9%85%D8%B9%D9%84%D9%85%20%D9%83%D8%AB%D9%8A%D8%B1%D9%8B%D8%A7.)
^ar-Q0090-answer

**ar-Q0091** — يصعب عليّ تصديق ذلك.

I find it difficult to believe.

Expected form: **ذلك**

Why: Demonstratives. [[Arabic#^ar-Q0091|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%8A%D8%B5%D8%B9%D8%A8%20%D8%B9%D9%84%D9%8A%D9%91%20%D8%AA%D8%B5%D8%AF%D9%8A%D9%82%20%D8%B0%D9%84%D9%83.)
^ar-Q0091-answer

**ar-Q0092** — يصعب عليّ تصديق ذلك.

I find it difficult to believe.

Expected form: **ذلك**

Why: Demonstratives. [[Arabic#^ar-Q0092|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%8A%D8%B5%D8%B9%D8%A8%20%D8%B9%D9%84%D9%8A%D9%91%20%D8%AA%D8%B5%D8%AF%D9%8A%D9%82%20%D8%B0%D9%84%D9%83.)
^ar-Q0092-answer

**ar-Q0093** — هذا قائمة ما نحتاج.

This is a list of what we need.

Expected form: **هذا**

Why: Demonstratives. [[Arabic#^ar-Q0093|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D8%B0%D8%A7%20%D9%82%D8%A7%D8%A6%D9%85%D8%A9%20%D9%85%D8%A7%20%D9%86%D8%AD%D8%AA%D8%A7%D8%AC.)
^ar-Q0093-answer

**ar-Q0094** — هذا قائمة ما نحتاج.

This is a list of what we need.

Why: Demonstratives. [[Arabic#^ar-Q0094|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D8%B0%D8%A7%20%D9%82%D8%A7%D8%A6%D9%85%D8%A9%20%D9%85%D8%A7%20%D9%86%D8%AD%D8%AA%D8%A7%D8%AC.)
^ar-Q0094-answer

**ar-Q0095** — لم يرد سامي أن يتخاصم مع ذلك الرّجل.

Sami didn't want to argue with that guy.

Why: Demonstratives. [[Arabic#^ar-Q0095|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%85%20%D9%8A%D8%B1%D8%AF%20%D8%B3%D8%A7%D9%85%D9%8A%20%D8%A3%D9%86%20%D9%8A%D8%AA%D8%AE%D8%A7%D8%B5%D9%85%20%D9%85%D8%B9%20%D8%B0%D9%84%D9%83%20%D8%A7%D9%84%D8%B1%D9%91%D8%AC%D9%84.)
^ar-Q0095-answer

**ar-Q0096** — لم يرد سامي أن يتخاصم مع ذلك الرّجل.

Sami didn't want to argue with that guy.

Demonstratives agree in relevant gender/number distinctions. هذا كتاب is this is a book, whereas هذا الكتاب refers to this book as a phrase. Definiteness affects the structure.

Why: Demonstratives. [[Arabic#^ar-Q0096|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%85%20%D9%8A%D8%B1%D8%AF%20%D8%B3%D8%A7%D9%85%D9%8A%20%D8%A3%D9%86%20%D9%8A%D8%AA%D8%AE%D8%A7%D8%B5%D9%85%20%D9%85%D8%B9%20%D8%B0%D9%84%D9%83%20%D8%A7%D9%84%D8%B1%D9%91%D8%AC%D9%84.)
^ar-Q0096-answer

**ar-Q0097** — قتل ذلك الرجل.

He killed that man.

Expected form: **ذلك**

Why: Demonstratives. [[Arabic#^ar-Q0097|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%82%D8%AA%D9%84%20%D8%B0%D9%84%D9%83%20%D8%A7%D9%84%D8%B1%D8%AC%D9%84.)
^ar-Q0097-answer

**ar-Q0098** — قتل ذلك الرجل.

He killed that man.

Expected form: **ذلك**

Why: Demonstratives. [[Arabic#^ar-Q0098|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%82%D8%AA%D9%84%20%D8%B0%D9%84%D9%83%20%D8%A7%D9%84%D8%B1%D8%AC%D9%84.)
^ar-Q0098-answer

**ar-Q0099** — دائماً ما اصادف سياح يابانيين في هذه المنطقة .

We often come across Japanese tourists in this area.

Expected form: **هذه**

Why: Demonstratives. [[Arabic#^ar-Q0099|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%AF%D8%A7%D8%A6%D9%85%D8%A7%D9%8B%20%D9%85%D8%A7%20%D8%A7%D8%B5%D8%A7%D8%AF%D9%81%20%D8%B3%D9%8A%D8%A7%D8%AD%20%D9%8A%D8%A7%D8%A8%D8%A7%D9%86%D9%8A%D9%8A%D9%86%20%D9%81%D9%8A%20%D9%87%D8%B0%D9%87%20%D8%A7%D9%84%D9%85%D9%86%D8%B7%D9%82%D8%A9%20.)
^ar-Q0099-answer

**ar-Q0100** — دائماً ما اصادف سياح يابانيين في هذه المنطقة .

We often come across Japanese tourists in this area.

Why: Demonstratives. [[Arabic#^ar-Q0100|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%AF%D8%A7%D8%A6%D9%85%D8%A7%D9%8B%20%D9%85%D8%A7%20%D8%A7%D8%B5%D8%A7%D8%AF%D9%81%20%D8%B3%D9%8A%D8%A7%D8%AD%20%D9%8A%D8%A7%D8%A8%D8%A7%D9%86%D9%8A%D9%8A%D9%86%20%D9%81%D9%8A%20%D9%87%D8%B0%D9%87%20%D8%A7%D9%84%D9%85%D9%86%D8%B7%D9%82%D8%A9%20.)
^ar-Q0100-answer


### Answers 101–150

**ar-Q0101** — لا شيئَ مثالي.

Nothing's perfect.

Why: Definite article. [[Arabic#^ar-Q0101|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D8%A7%20%D8%B4%D9%8A%D8%A6%D9%8E%20%D9%85%D8%AB%D8%A7%D9%84%D9%8A.)
^ar-Q0101-answer

**ar-Q0102** — لا شيئَ مثالي.

Nothing's perfect.

الـ marks definiteness and is written attached. Before sun letters its l sound assimilates to the following consonant, which is doubled in pronunciation. Written spelling still retains ال.

Why: Definite article. [[Arabic#^ar-Q0102|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D8%A7%20%D8%B4%D9%8A%D8%A6%D9%8E%20%D9%85%D8%AB%D8%A7%D9%84%D9%8A.)
^ar-Q0102-answer

**ar-Q0103** — صديق في اليد خير من اثنين على الشجرة!

A friend in hand is worth two in the bush!

Expected form: **اليد**

Why: Definite article. [[Arabic#^ar-Q0103|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B5%D8%AF%D9%8A%D9%82%20%D9%81%D9%8A%20%D8%A7%D9%84%D9%8A%D8%AF%20%D8%AE%D9%8A%D8%B1%20%D9%85%D9%86%20%D8%A7%D8%AB%D9%86%D9%8A%D9%86%20%D8%B9%D9%84%D9%89%20%D8%A7%D9%84%D8%B4%D8%AC%D8%B1%D8%A9%21)
^ar-Q0103-answer

**ar-Q0104** — صديق في اليد خير من اثنين على الشجرة!

A friend in hand is worth two in the bush!

Expected form: **اليد**

Why: Definite article. [[Arabic#^ar-Q0104|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B5%D8%AF%D9%8A%D9%82%20%D9%81%D9%8A%20%D8%A7%D9%84%D9%8A%D8%AF%20%D8%AE%D9%8A%D8%B1%20%D9%85%D9%86%20%D8%A7%D8%AB%D9%86%D9%8A%D9%86%20%D8%B9%D9%84%D9%89%20%D8%A7%D9%84%D8%B4%D8%AC%D8%B1%D8%A9%21)
^ar-Q0104-answer

**ar-Q0105** — تسلّقت ليلى السّلّم.

Layla climbed the ladder.

Expected form: **السّلّم**

Why: Definite article. [[Arabic#^ar-Q0105|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%AA%D8%B3%D9%84%D9%91%D9%82%D8%AA%20%D9%84%D9%8A%D9%84%D9%89%20%D8%A7%D9%84%D8%B3%D9%91%D9%84%D9%91%D9%85.)
^ar-Q0105-answer

**ar-Q0106** — تسلّقت ليلى السّلّم.

Layla climbed the ladder.

Why: Definite article. [[Arabic#^ar-Q0106|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%AA%D8%B3%D9%84%D9%91%D9%82%D8%AA%20%D9%84%D9%8A%D9%84%D9%89%20%D8%A7%D9%84%D8%B3%D9%91%D9%84%D9%91%D9%85.)
^ar-Q0106-answer

**ar-Q0107** — لقد أضفت فلفلاً أكثر من اللازم.

You put in too much pepper.

Why: Definite article. [[Arabic#^ar-Q0107|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%82%D8%AF%20%D8%A3%D8%B6%D9%81%D8%AA%20%D9%81%D9%84%D9%81%D9%84%D8%A7%D9%8B%20%D8%A3%D9%83%D8%AB%D8%B1%20%D9%85%D9%86%20%D8%A7%D9%84%D9%84%D8%A7%D8%B2%D9%85.)
^ar-Q0107-answer

**ar-Q0108** — لقد أضفت فلفلاً أكثر من اللازم.

You put in too much pepper.

الـ marks definiteness and is written attached. Before sun letters its l sound assimilates to the following consonant, which is doubled in pronunciation. Written spelling still retains ال.

Why: Definite article. [[Arabic#^ar-Q0108|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%82%D8%AF%20%D8%A3%D8%B6%D9%81%D8%AA%20%D9%81%D9%84%D9%81%D9%84%D8%A7%D9%8B%20%D8%A3%D9%83%D8%AB%D8%B1%20%D9%85%D9%86%20%D8%A7%D9%84%D9%84%D8%A7%D8%B2%D9%85.)
^ar-Q0108-answer

**ar-Q0109** — اتهمته الشرطة بالقتل.

The police accused him of murder.

Expected form: **الشرطة**

Why: Definite article. [[Arabic#^ar-Q0109|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A7%D8%AA%D9%87%D9%85%D8%AA%D9%87%20%D8%A7%D9%84%D8%B4%D8%B1%D8%B7%D8%A9%20%D8%A8%D8%A7%D9%84%D9%82%D8%AA%D9%84.)
^ar-Q0109-answer

**ar-Q0110** — اتهمته الشرطة بالقتل.

The police accused him of murder.

Expected form: **الشرطة**

Why: Definite article. [[Arabic#^ar-Q0110|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A7%D8%AA%D9%87%D9%85%D8%AA%D9%87%20%D8%A7%D9%84%D8%B4%D8%B1%D8%B7%D8%A9%20%D8%A8%D8%A7%D9%84%D9%82%D8%AA%D9%84.)
^ar-Q0110-answer

**ar-Q0111** — دفعت ليلى بسامي إلى الحائط.

Layla pushed Sami to the wall.

Expected form: **الحائط**

Why: Definite article. [[Arabic#^ar-Q0111|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%AF%D9%81%D8%B9%D8%AA%20%D9%84%D9%8A%D9%84%D9%89%20%D8%A8%D8%B3%D8%A7%D9%85%D9%8A%20%D8%A5%D9%84%D9%89%20%D8%A7%D9%84%D8%AD%D8%A7%D8%A6%D8%B7.)
^ar-Q0111-answer

**ar-Q0112** — دفعت ليلى بسامي إلى الحائط.

Layla pushed Sami to the wall.

Why: Definite article. [[Arabic#^ar-Q0112|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%AF%D9%81%D8%B9%D8%AA%20%D9%84%D9%8A%D9%84%D9%89%20%D8%A8%D8%B3%D8%A7%D9%85%D9%8A%20%D8%A5%D9%84%D9%89%20%D8%A7%D9%84%D8%AD%D8%A7%D8%A6%D8%B7.)
^ar-Q0112-answer

**ar-Q0113** — يبدوا لي أنه يعلم السر

I have the impression that he knows the secret.

Why: Definite article. [[Arabic#^ar-Q0113|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%8A%D8%A8%D8%AF%D9%88%D8%A7%20%D9%84%D9%8A%20%D8%A3%D9%86%D9%87%20%D9%8A%D8%B9%D9%84%D9%85%20%D8%A7%D9%84%D8%B3%D8%B1)
^ar-Q0113-answer

**ar-Q0114** — يبدوا لي أنه يعلم السر

I have the impression that he knows the secret.

الـ marks definiteness and is written attached. Before sun letters its l sound assimilates to the following consonant, which is doubled in pronunciation. Written spelling still retains ال.

Why: Definite article. [[Arabic#^ar-Q0114|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%8A%D8%A8%D8%AF%D9%88%D8%A7%20%D9%84%D9%8A%20%D8%A3%D9%86%D9%87%20%D9%8A%D8%B9%D9%84%D9%85%20%D8%A7%D9%84%D8%B3%D8%B1)
^ar-Q0114-answer

**ar-Q0115** — يبدو المعطف الأحمر جميلاً عليك.

That red sweater looks good on you.

Expected form: **المعطف**

Why: Definite article. [[Arabic#^ar-Q0115|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%8A%D8%A8%D8%AF%D9%88%20%D8%A7%D9%84%D9%85%D8%B9%D8%B7%D9%81%20%D8%A7%D9%84%D8%A3%D8%AD%D9%85%D8%B1%20%D8%AC%D9%85%D9%8A%D9%84%D8%A7%D9%8B%20%D8%B9%D9%84%D9%8A%D9%83.)
^ar-Q0115-answer

**ar-Q0116** — يبدو المعطف الأحمر جميلاً عليك.

That red sweater looks good on you.

Expected form: **المعطف**

Why: Definite article. [[Arabic#^ar-Q0116|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%8A%D8%A8%D8%AF%D9%88%20%D8%A7%D9%84%D9%85%D8%B9%D8%B7%D9%81%20%D8%A7%D9%84%D8%A3%D8%AD%D9%85%D8%B1%20%D8%AC%D9%85%D9%8A%D9%84%D8%A7%D9%8B%20%D8%B9%D9%84%D9%8A%D9%83.)
^ar-Q0116-answer

**ar-Q0117** — حتى لو سارت الأمور على ما يرام، ما زلنا غير قادرين على الانتهاء قبل السبت.

Even if all goes well, we still can't finish before Saturday.

Expected form: **الأمور**

Why: Definite article. [[Arabic#^ar-Q0117|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%AD%D8%AA%D9%89%20%D9%84%D9%88%20%D8%B3%D8%A7%D8%B1%D8%AA%20%D8%A7%D9%84%D8%A3%D9%85%D9%88%D8%B1%20%D8%B9%D9%84%D9%89%20%D9%85%D8%A7%20%D9%8A%D8%B1%D8%A7%D9%85%D8%8C%20%D9%85%D8%A7%20%D8%B2%D9%84%D9%86%D8%A7%20%D8%BA%D9%8A%D8%B1%20%D9%82%D8%A7%D8%AF%D8%B1%D9%8A%D9%86%20%D8%B9%D9%84%D9%89%20%D8%A7%D9%84%D8%A7%D9%86%D8%AA%D9%87%D8%A7%D8%A1%20%D9%82%D8%A8%D9%84%20%D8%A7%D9%84%D8%B3%D8%A8%D8%AA.)
^ar-Q0117-answer

**ar-Q0118** — حتى لو سارت الأمور على ما يرام، ما زلنا غير قادرين على الانتهاء قبل السبت.

Even if all goes well, we still can't finish before Saturday.

Why: Definite article. [[Arabic#^ar-Q0118|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%AD%D8%AA%D9%89%20%D9%84%D9%88%20%D8%B3%D8%A7%D8%B1%D8%AA%20%D8%A7%D9%84%D8%A3%D9%85%D9%88%D8%B1%20%D8%B9%D9%84%D9%89%20%D9%85%D8%A7%20%D9%8A%D8%B1%D8%A7%D9%85%D8%8C%20%D9%85%D8%A7%20%D8%B2%D9%84%D9%86%D8%A7%20%D8%BA%D9%8A%D8%B1%20%D9%82%D8%A7%D8%AF%D8%B1%D9%8A%D9%86%20%D8%B9%D9%84%D9%89%20%D8%A7%D9%84%D8%A7%D9%86%D8%AA%D9%87%D8%A7%D8%A1%20%D9%82%D8%A8%D9%84%20%D8%A7%D9%84%D8%B3%D8%A8%D8%AA.)
^ar-Q0118-answer

**ar-Q0119** — كل شخص لديه كلاً من نقاط الضعف والقوة.

Everyone has both strong and weak points.

Why: Definite article. [[Arabic#^ar-Q0119|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D9%84%20%D8%B4%D8%AE%D8%B5%20%D9%84%D8%AF%D9%8A%D9%87%20%D9%83%D9%84%D8%A7%D9%8B%20%D9%85%D9%86%20%D9%86%D9%82%D8%A7%D8%B7%20%D8%A7%D9%84%D8%B6%D8%B9%D9%81%20%D9%88%D8%A7%D9%84%D9%82%D9%88%D8%A9.)
^ar-Q0119-answer

**ar-Q0120** — كل شخص لديه كلاً من نقاط الضعف والقوة.

Everyone has both strong and weak points.

الـ marks definiteness and is written attached. Before sun letters its l sound assimilates to the following consonant, which is doubled in pronunciation. Written spelling still retains ال.

Why: Definite article. [[Arabic#^ar-Q0120|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D9%84%20%D8%B4%D8%AE%D8%B5%20%D9%84%D8%AF%D9%8A%D9%87%20%D9%83%D9%84%D8%A7%D9%8B%20%D9%85%D9%86%20%D9%86%D9%82%D8%A7%D8%B7%20%D8%A7%D9%84%D8%B6%D8%B9%D9%81%20%D9%88%D8%A7%D9%84%D9%82%D9%88%D8%A9.)
^ar-Q0120-answer

**ar-Q0121** — كلفونا بهذا العمل.

They assigned the task to us.

Expected form: **العمل**

Why: Definite article. [[Arabic#^ar-Q0121|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D9%84%D9%81%D9%88%D9%86%D8%A7%20%D8%A8%D9%87%D8%B0%D8%A7%20%D8%A7%D9%84%D8%B9%D9%85%D9%84.)
^ar-Q0121-answer

**ar-Q0122** — كلفونا بهذا العمل.

They assigned the task to us.

Expected form: **العمل**

Why: Definite article. [[Arabic#^ar-Q0122|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D9%84%D9%81%D9%88%D9%86%D8%A7%20%D8%A8%D9%87%D8%B0%D8%A7%20%D8%A7%D9%84%D8%B9%D9%85%D9%84.)
^ar-Q0122-answer

**ar-Q0123** — يمكنك فتح النافذة.

You may open the window.

Expected form: **النافذة**

Why: Definite article. [[Arabic#^ar-Q0123|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%8A%D9%85%D9%83%D9%86%D9%83%20%D9%81%D8%AA%D8%AD%20%D8%A7%D9%84%D9%86%D8%A7%D9%81%D8%B0%D8%A9.)
^ar-Q0123-answer

**ar-Q0124** — يمكنك فتح النافذة.

You may open the window.

Why: Definite article. [[Arabic#^ar-Q0124|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%8A%D9%85%D9%83%D9%86%D9%83%20%D9%81%D8%AA%D8%AD%20%D8%A7%D9%84%D9%86%D8%A7%D9%81%D8%B0%D8%A9.)
^ar-Q0124-answer

**ar-Q0125** — الكثير من الناس يجهلون أن المضادات الحيوية ليست لديها تأثير على الأمراض الفيروسية.

Many people don't know that antibiotics are ineffective against viral diseases.

Why: Definite article. [[Arabic#^ar-Q0125|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A7%D9%84%D9%83%D8%AB%D9%8A%D8%B1%20%D9%85%D9%86%20%D8%A7%D9%84%D9%86%D8%A7%D8%B3%20%D9%8A%D8%AC%D9%87%D9%84%D9%88%D9%86%20%D8%A3%D9%86%20%D8%A7%D9%84%D9%85%D8%B6%D8%A7%D8%AF%D8%A7%D8%AA%20%D8%A7%D9%84%D8%AD%D9%8A%D9%88%D9%8A%D8%A9%20%D9%84%D9%8A%D8%B3%D8%AA%20%D9%84%D8%AF%D9%8A%D9%87%D8%A7%20%D8%AA%D8%A3%D8%AB%D9%8A%D8%B1%20%D8%B9%D9%84%D9%89%20%D8%A7%D9%84%D8%A3%D9%85%D8%B1%D8%A7%D8%B6%20%D8%A7%D9%84%D9%81%D9%8A%D8%B1%D9%88%D8%B3%D9%8A%D8%A9.)
^ar-Q0125-answer

**ar-Q0126** — الكثير من الناس يجهلون أن المضادات الحيوية ليست لديها تأثير على الأمراض الفيروسية.

Many people don't know that antibiotics are ineffective against viral diseases.

الـ marks definiteness and is written attached. Before sun letters its l sound assimilates to the following consonant, which is doubled in pronunciation. Written spelling still retains ال.

Why: Definite article. [[Arabic#^ar-Q0126|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A7%D9%84%D9%83%D8%AB%D9%8A%D8%B1%20%D9%85%D9%86%20%D8%A7%D9%84%D9%86%D8%A7%D8%B3%20%D9%8A%D8%AC%D9%87%D9%84%D9%88%D9%86%20%D8%A3%D9%86%20%D8%A7%D9%84%D9%85%D8%B6%D8%A7%D8%AF%D8%A7%D8%AA%20%D8%A7%D9%84%D8%AD%D9%8A%D9%88%D9%8A%D8%A9%20%D9%84%D9%8A%D8%B3%D8%AA%20%D9%84%D8%AF%D9%8A%D9%87%D8%A7%20%D8%AA%D8%A3%D8%AB%D9%8A%D8%B1%20%D8%B9%D9%84%D9%89%20%D8%A7%D9%84%D8%A3%D9%85%D8%B1%D8%A7%D8%B6%20%D8%A7%D9%84%D9%81%D9%8A%D8%B1%D9%88%D8%B3%D9%8A%D8%A9.)
^ar-Q0126-answer

**ar-Q0127** — وضع سامي جثة ليلى في قعر القارب

Sami placed Layla's body on the bottom of the boat.

Expected form: **القارب**

Why: Definite article. [[Arabic#^ar-Q0127|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%88%D8%B6%D8%B9%20%D8%B3%D8%A7%D9%85%D9%8A%20%D8%AC%D8%AB%D8%A9%20%D9%84%D9%8A%D9%84%D9%89%20%D9%81%D9%8A%20%D9%82%D8%B9%D8%B1%20%D8%A7%D9%84%D9%82%D8%A7%D8%B1%D8%A8)
^ar-Q0127-answer

**ar-Q0128** — وضع سامي جثة ليلى في قعر القارب

Sami placed Layla's body on the bottom of the boat.

Expected form: **القارب**

Why: Definite article. [[Arabic#^ar-Q0128|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%88%D8%B6%D8%B9%20%D8%B3%D8%A7%D9%85%D9%8A%20%D8%AC%D8%AB%D8%A9%20%D9%84%D9%8A%D9%84%D9%89%20%D9%81%D9%8A%20%D9%82%D8%B9%D8%B1%20%D8%A7%D9%84%D9%82%D8%A7%D8%B1%D8%A8)
^ar-Q0128-answer

**ar-Q0129** — في سبتمبر/أيلول، توجد كثير من قناديل البحر في المحيط.

There are lots of jellyfish in the ocean in September.

Expected form: **البحر**

Why: Definite article. [[Arabic#^ar-Q0129|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%81%D9%8A%20%D8%B3%D8%A8%D8%AA%D9%85%D8%A8%D8%B1/%D8%A3%D9%8A%D9%84%D9%88%D9%84%D8%8C%20%D8%AA%D9%88%D8%AC%D8%AF%20%D9%83%D8%AB%D9%8A%D8%B1%20%D9%85%D9%86%20%D9%82%D9%86%D8%A7%D8%AF%D9%8A%D9%84%20%D8%A7%D9%84%D8%A8%D8%AD%D8%B1%20%D9%81%D9%8A%20%D8%A7%D9%84%D9%85%D8%AD%D9%8A%D8%B7.)
^ar-Q0129-answer

**ar-Q0130** — في سبتمبر/أيلول، توجد كثير من قناديل البحر في المحيط.

There are lots of jellyfish in the ocean in September.

Why: Definite article. [[Arabic#^ar-Q0130|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%81%D9%8A%20%D8%B3%D8%A8%D8%AA%D9%85%D8%A8%D8%B1/%D8%A3%D9%8A%D9%84%D9%88%D9%84%D8%8C%20%D8%AA%D9%88%D8%AC%D8%AF%20%D9%83%D8%AB%D9%8A%D8%B1%20%D9%85%D9%86%20%D9%82%D9%86%D8%A7%D8%AF%D9%8A%D9%84%20%D8%A7%D9%84%D8%A8%D8%AD%D8%B1%20%D9%81%D9%8A%20%D8%A7%D9%84%D9%85%D8%AD%D9%8A%D8%B7.)
^ar-Q0130-answer

**ar-Q0131** — لا يشرب أغلب الناس ما يكفيهم من المياه.

Most people don't drink enough water.

Why: Definite article. [[Arabic#^ar-Q0131|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D8%A7%20%D9%8A%D8%B4%D8%B1%D8%A8%20%D8%A3%D8%BA%D9%84%D8%A8%20%D8%A7%D9%84%D9%86%D8%A7%D8%B3%20%D9%85%D8%A7%20%D9%8A%D9%83%D9%81%D9%8A%D9%87%D9%85%20%D9%85%D9%86%20%D8%A7%D9%84%D9%85%D9%8A%D8%A7%D9%87.)
^ar-Q0131-answer

**ar-Q0132** — لا يشرب أغلب الناس ما يكفيهم من المياه.

Most people don't drink enough water.

الـ marks definiteness and is written attached. Before sun letters its l sound assimilates to the following consonant, which is doubled in pronunciation. Written spelling still retains ال.

Why: Definite article. [[Arabic#^ar-Q0132|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D8%A7%20%D9%8A%D8%B4%D8%B1%D8%A8%20%D8%A3%D8%BA%D9%84%D8%A8%20%D8%A7%D9%84%D9%86%D8%A7%D8%B3%20%D9%85%D8%A7%20%D9%8A%D9%83%D9%81%D9%8A%D9%87%D9%85%20%D9%85%D9%86%20%D8%A7%D9%84%D9%85%D9%8A%D8%A7%D9%87.)
^ar-Q0132-answer

**ar-Q0133** — تناول سامي بعض الأقراص النّوم.

Sami took some sleeping pills.

Expected form: **الأقراص**

Why: Definite article. [[Arabic#^ar-Q0133|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%AA%D9%86%D8%A7%D9%88%D9%84%20%D8%B3%D8%A7%D9%85%D9%8A%20%D8%A8%D8%B9%D8%B6%20%D8%A7%D9%84%D8%A3%D9%82%D8%B1%D8%A7%D8%B5%20%D8%A7%D9%84%D9%86%D9%91%D9%88%D9%85.)
^ar-Q0133-answer

**ar-Q0134** — تناول سامي بعض الأقراص النّوم.

Sami took some sleeping pills.

Expected form: **الأقراص**

Why: Definite article. [[Arabic#^ar-Q0134|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%AA%D9%86%D8%A7%D9%88%D9%84%20%D8%B3%D8%A7%D9%85%D9%8A%20%D8%A8%D8%B9%D8%B6%20%D8%A7%D9%84%D8%A3%D9%82%D8%B1%D8%A7%D8%B5%20%D8%A7%D9%84%D9%86%D9%91%D9%88%D9%85.)
^ar-Q0134-answer

**ar-Q0135** — فكّر سامي أنّه ربّما لهذا الأمر علاقة بوفاة ليلى.

Sami thought maybe this had something to do with Layla's death.

Expected form: **الأمر**

Why: Definite article. [[Arabic#^ar-Q0135|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%81%D9%83%D9%91%D8%B1%20%D8%B3%D8%A7%D9%85%D9%8A%20%D8%A3%D9%86%D9%91%D9%87%20%D8%B1%D8%A8%D9%91%D9%85%D8%A7%20%D9%84%D9%87%D8%B0%D8%A7%20%D8%A7%D9%84%D8%A3%D9%85%D8%B1%20%D8%B9%D9%84%D8%A7%D9%82%D8%A9%20%D8%A8%D9%88%D9%81%D8%A7%D8%A9%20%D9%84%D9%8A%D9%84%D9%89.)
^ar-Q0135-answer

**ar-Q0136** — فكّر سامي أنّه ربّما لهذا الأمر علاقة بوفاة ليلى.

Sami thought maybe this had something to do with Layla's death.

Why: Definite article. [[Arabic#^ar-Q0136|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%81%D9%83%D9%91%D8%B1%20%D8%B3%D8%A7%D9%85%D9%8A%20%D8%A3%D9%86%D9%91%D9%87%20%D8%B1%D8%A8%D9%91%D9%85%D8%A7%20%D9%84%D9%87%D8%B0%D8%A7%20%D8%A7%D9%84%D8%A3%D9%85%D8%B1%20%D8%B9%D9%84%D8%A7%D9%82%D8%A9%20%D8%A8%D9%88%D9%81%D8%A7%D8%A9%20%D9%84%D9%8A%D9%84%D9%89.)
^ar-Q0136-answer

**ar-Q0137** — قُتِلَ سامي من طرف صديق فريد المقرّب، رامي.

Sami was murdered by Farid's best friend, Rami.

Why: Definite article. [[Arabic#^ar-Q0137|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%82%D9%8F%D8%AA%D9%90%D9%84%D9%8E%20%D8%B3%D8%A7%D9%85%D9%8A%20%D9%85%D9%86%20%D8%B7%D8%B1%D9%81%20%D8%B5%D8%AF%D9%8A%D9%82%20%D9%81%D8%B1%D9%8A%D8%AF%20%D8%A7%D9%84%D9%85%D9%82%D8%B1%D9%91%D8%A8%D8%8C%20%D8%B1%D8%A7%D9%85%D9%8A.)
^ar-Q0137-answer

**ar-Q0138** — قُتِلَ سامي من طرف صديق فريد المقرّب، رامي.

Sami was murdered by Farid's best friend, Rami.

الـ marks definiteness and is written attached. Before sun letters its l sound assimilates to the following consonant, which is doubled in pronunciation. Written spelling still retains ال.

Why: Definite article. [[Arabic#^ar-Q0138|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%82%D9%8F%D8%AA%D9%90%D9%84%D9%8E%20%D8%B3%D8%A7%D9%85%D9%8A%20%D9%85%D9%86%20%D8%B7%D8%B1%D9%81%20%D8%B5%D8%AF%D9%8A%D9%82%20%D9%81%D8%B1%D9%8A%D8%AF%20%D8%A7%D9%84%D9%85%D9%82%D8%B1%D9%91%D8%A8%D8%8C%20%D8%B1%D8%A7%D9%85%D9%8A.)
^ar-Q0138-answer

**ar-Q0139** — لا تستطيع ليلى الإخبار بذلك.

Layla can't tell.

Expected form: **الإخبار**

Why: Definite article. [[Arabic#^ar-Q0139|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D8%A7%20%D8%AA%D8%B3%D8%AA%D8%B7%D9%8A%D8%B9%20%D9%84%D9%8A%D9%84%D9%89%20%D8%A7%D9%84%D8%A5%D8%AE%D8%A8%D8%A7%D8%B1%20%D8%A8%D8%B0%D9%84%D9%83.)
^ar-Q0139-answer

**ar-Q0140** — لا تستطيع ليلى الإخبار بذلك.

Layla can't tell.

Expected form: **الإخبار**

Why: Definite article. [[Arabic#^ar-Q0140|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D8%A7%20%D8%AA%D8%B3%D8%AA%D8%B7%D9%8A%D8%B9%20%D9%84%D9%8A%D9%84%D9%89%20%D8%A7%D9%84%D8%A5%D8%AE%D8%A8%D8%A7%D8%B1%20%D8%A8%D8%B0%D9%84%D9%83.)
^ar-Q0140-answer

**ar-Q0141** — تعتبر اليابان الدولة الرائدة عالميا في صناعة التكنولوجيا المتقدمة.

Japan is the leader of the world's high-tech industry.

Expected form: **اليابان**

Why: Definite article. [[Arabic#^ar-Q0141|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%AA%D8%B9%D8%AA%D8%A8%D8%B1%20%D8%A7%D9%84%D9%8A%D8%A7%D8%A8%D8%A7%D9%86%20%D8%A7%D9%84%D8%AF%D9%88%D9%84%D8%A9%20%D8%A7%D9%84%D8%B1%D8%A7%D8%A6%D8%AF%D8%A9%20%D8%B9%D8%A7%D9%84%D9%85%D9%8A%D8%A7%20%D9%81%D9%8A%20%D8%B5%D9%86%D8%A7%D8%B9%D8%A9%20%D8%A7%D9%84%D8%AA%D9%83%D9%86%D9%88%D9%84%D9%88%D8%AC%D9%8A%D8%A7%20%D8%A7%D9%84%D9%85%D8%AA%D9%82%D8%AF%D9%85%D8%A9.)
^ar-Q0141-answer

**ar-Q0142** — تعتبر اليابان الدولة الرائدة عالميا في صناعة التكنولوجيا المتقدمة.

Japan is the leader of the world's high-tech industry.

Why: Definite article. [[Arabic#^ar-Q0142|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%AA%D8%B9%D8%AA%D8%A8%D8%B1%20%D8%A7%D9%84%D9%8A%D8%A7%D8%A8%D8%A7%D9%86%20%D8%A7%D9%84%D8%AF%D9%88%D9%84%D8%A9%20%D8%A7%D9%84%D8%B1%D8%A7%D8%A6%D8%AF%D8%A9%20%D8%B9%D8%A7%D9%84%D9%85%D9%8A%D8%A7%20%D9%81%D9%8A%20%D8%B5%D9%86%D8%A7%D8%B9%D8%A9%20%D8%A7%D9%84%D8%AA%D9%83%D9%86%D9%88%D9%84%D9%88%D8%AC%D9%8A%D8%A7%20%D8%A7%D9%84%D9%85%D8%AA%D9%82%D8%AF%D9%85%D8%A9.)
^ar-Q0142-answer

**ar-Q0143** — دائما ما يكذب جمال ليخرج نفسه من المواقف الصعبة.

Jamal always lies his way out.

Why: Definite article. [[Arabic#^ar-Q0143|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%AF%D8%A7%D8%A6%D9%85%D8%A7%20%D9%85%D8%A7%20%D9%8A%D9%83%D8%B0%D8%A8%20%D8%AC%D9%85%D8%A7%D9%84%20%D9%84%D9%8A%D8%AE%D8%B1%D8%AC%20%D9%86%D9%81%D8%B3%D9%87%20%D9%85%D9%86%20%D8%A7%D9%84%D9%85%D9%88%D8%A7%D9%82%D9%81%20%D8%A7%D9%84%D8%B5%D8%B9%D8%A8%D8%A9.)
^ar-Q0143-answer

**ar-Q0144** — دائما ما يكذب جمال ليخرج نفسه من المواقف الصعبة.

Jamal always lies his way out.

الـ marks definiteness and is written attached. Before sun letters its l sound assimilates to the following consonant, which is doubled in pronunciation. Written spelling still retains ال.

Why: Definite article. [[Arabic#^ar-Q0144|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%AF%D8%A7%D8%A6%D9%85%D8%A7%20%D9%85%D8%A7%20%D9%8A%D9%83%D8%B0%D8%A8%20%D8%AC%D9%85%D8%A7%D9%84%20%D9%84%D9%8A%D8%AE%D8%B1%D8%AC%20%D9%86%D9%81%D8%B3%D9%87%20%D9%85%D9%86%20%D8%A7%D9%84%D9%85%D9%88%D8%A7%D9%82%D9%81%20%D8%A7%D9%84%D8%B5%D8%B9%D8%A8%D8%A9.)
^ar-Q0144-answer

**ar-Q0145** — قاس طول السرير.

He measured the length of the bed.

Expected form: **السرير**

Why: Definite article. [[Arabic#^ar-Q0145|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%82%D8%A7%D8%B3%20%D8%B7%D9%88%D9%84%20%D8%A7%D9%84%D8%B3%D8%B1%D9%8A%D8%B1.)
^ar-Q0145-answer

**ar-Q0146** — قاس طول السرير.

He measured the length of the bed.

Expected form: **السرير**

Why: Definite article. [[Arabic#^ar-Q0146|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%82%D8%A7%D8%B3%20%D8%B7%D9%88%D9%84%20%D8%A7%D9%84%D8%B3%D8%B1%D9%8A%D8%B1.)
^ar-Q0146-answer

**ar-Q0147** — كان فاضل يريد أن يتحكّم في الجميع.

Fadil wanted to control everybody.

Expected form: **الجميع**

Why: Definite article. [[Arabic#^ar-Q0147|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D8%A7%D9%86%20%D9%81%D8%A7%D8%B6%D9%84%20%D9%8A%D8%B1%D9%8A%D8%AF%20%D8%A3%D9%86%20%D9%8A%D8%AA%D8%AD%D9%83%D9%91%D9%85%20%D9%81%D9%8A%20%D8%A7%D9%84%D8%AC%D9%85%D9%8A%D8%B9.)
^ar-Q0147-answer

**ar-Q0148** — كان فاضل يريد أن يتحكّم في الجميع.

Fadil wanted to control everybody.

Why: Definite article. [[Arabic#^ar-Q0148|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D8%A7%D9%86%20%D9%81%D8%A7%D8%B6%D9%84%20%D9%8A%D8%B1%D9%8A%D8%AF%20%D8%A3%D9%86%20%D9%8A%D8%AA%D8%AD%D9%83%D9%91%D9%85%20%D9%81%D9%8A%20%D8%A7%D9%84%D8%AC%D9%85%D9%8A%D8%B9.)
^ar-Q0148-answer

**ar-Q0149** — كان سامي يتسلّق السّلّم.

Sami was climbing the ladder.

Why: Definite article. [[Arabic#^ar-Q0149|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D8%A7%D9%86%20%D8%B3%D8%A7%D9%85%D9%8A%20%D9%8A%D8%AA%D8%B3%D9%84%D9%91%D9%82%20%D8%A7%D9%84%D8%B3%D9%91%D9%84%D9%91%D9%85.)
^ar-Q0149-answer

**ar-Q0150** — كان سامي يتسلّق السّلّم.

Sami was climbing the ladder.

الـ marks definiteness and is written attached. Before sun letters its l sound assimilates to the following consonant, which is doubled in pronunciation. Written spelling still retains ال.

Why: Definite article. [[Arabic#^ar-Q0150|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D8%A7%D9%86%20%D8%B3%D8%A7%D9%85%D9%8A%20%D9%8A%D8%AA%D8%B3%D9%84%D9%91%D9%82%20%D8%A7%D9%84%D8%B3%D9%91%D9%84%D9%91%D9%85.)
^ar-Q0150-answer


### Answers 151–200

**ar-Q0151** — ذكر تقرير جديد أن احتمال أن تواجه الفتيات سوء التغذية والفقرَ والعنف والحرمان من التعليم أكثرُ من الأولاد.

Girls are more likely than boys to be malnourished, suffer poverty, face violence and be refused an education, according to a new report.

Expected form: **جديد**

Why: Adjective and noun agreement. [[Arabic#^ar-Q0151|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B0%D9%83%D8%B1%20%D8%AA%D9%82%D8%B1%D9%8A%D8%B1%20%D8%AC%D8%AF%D9%8A%D8%AF%20%D8%A3%D9%86%20%D8%A7%D8%AD%D8%AA%D9%85%D8%A7%D9%84%20%D8%A3%D9%86%20%D8%AA%D9%88%D8%A7%D8%AC%D9%87%20%D8%A7%D9%84%D9%81%D8%AA%D9%8A%D8%A7%D8%AA%20%D8%B3%D9%88%D8%A1%20%D8%A7%D9%84%D8%AA%D8%BA%D8%B0%D9%8A%D8%A9%20%D9%88%D8%A7%D9%84%D9%81%D9%82%D8%B1%D9%8E%20%D9%88%D8%A7%D9%84%D8%B9%D9%86%D9%81%20%D9%88%D8%A7%D9%84%D8%AD%D8%B1%D9%85%D8%A7%D9%86%20%D9%85%D9%86%20%D8%A7%D9%84%D8%AA%D8%B9%D9%84%D9%8A%D9%85%20%D8%A3%D9%83%D8%AB%D8%B1%D9%8F%20%D9%85%D9%86%20%D8%A7%D9%84%D8%A3%D9%88%D9%84%D8%A7%D8%AF.)
^ar-Q0151-answer

**ar-Q0152** — ذكر تقرير جديد أن احتمال أن تواجه الفتيات سوء التغذية والفقرَ والعنف والحرمان من التعليم أكثرُ من الأولاد.

Girls are more likely than boys to be malnourished, suffer poverty, face violence and be refused an education, according to a new report.

Expected form: **جديد**

Why: Adjective and noun agreement. [[Arabic#^ar-Q0152|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B0%D9%83%D8%B1%20%D8%AA%D9%82%D8%B1%D9%8A%D8%B1%20%D8%AC%D8%AF%D9%8A%D8%AF%20%D8%A3%D9%86%20%D8%A7%D8%AD%D8%AA%D9%85%D8%A7%D9%84%20%D8%A3%D9%86%20%D8%AA%D9%88%D8%A7%D8%AC%D9%87%20%D8%A7%D9%84%D9%81%D8%AA%D9%8A%D8%A7%D8%AA%20%D8%B3%D9%88%D8%A1%20%D8%A7%D9%84%D8%AA%D8%BA%D8%B0%D9%8A%D8%A9%20%D9%88%D8%A7%D9%84%D9%81%D9%82%D8%B1%D9%8E%20%D9%88%D8%A7%D9%84%D8%B9%D9%86%D9%81%20%D9%88%D8%A7%D9%84%D8%AD%D8%B1%D9%85%D8%A7%D9%86%20%D9%85%D9%86%20%D8%A7%D9%84%D8%AA%D8%B9%D9%84%D9%8A%D9%85%20%D8%A3%D9%83%D8%AB%D8%B1%D9%8F%20%D9%85%D9%86%20%D8%A7%D9%84%D8%A3%D9%88%D9%84%D8%A7%D8%AF.)
^ar-Q0152-answer

**ar-Q0153** — يريد الناس استخدام التقنية الجديد التي توفرت.

People want to use the new technology which is available.

Expected form: **جديد**

Why: Adjective and noun agreement. [[Arabic#^ar-Q0153|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%8A%D8%B1%D9%8A%D8%AF%20%D8%A7%D9%84%D9%86%D8%A7%D8%B3%20%D8%A7%D8%B3%D8%AA%D8%AE%D8%AF%D8%A7%D9%85%20%D8%A7%D9%84%D8%AA%D9%82%D9%86%D9%8A%D8%A9%20%D8%A7%D9%84%D8%AC%D8%AF%D9%8A%D8%AF%20%D8%A7%D9%84%D8%AA%D9%8A%20%D8%AA%D9%88%D9%81%D8%B1%D8%AA.)
^ar-Q0153-answer

**ar-Q0154** — يريد الناس استخدام التقنية الجديد التي توفرت.

People want to use the new technology which is available.

Why: Adjective and noun agreement. [[Arabic#^ar-Q0154|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%8A%D8%B1%D9%8A%D8%AF%20%D8%A7%D9%84%D9%86%D8%A7%D8%B3%20%D8%A7%D8%B3%D8%AA%D8%AE%D8%AF%D8%A7%D9%85%20%D8%A7%D9%84%D8%AA%D9%82%D9%86%D9%8A%D8%A9%20%D8%A7%D9%84%D8%AC%D8%AF%D9%8A%D8%AF%20%D8%A7%D9%84%D8%AA%D9%8A%20%D8%AA%D9%88%D9%81%D8%B1%D8%AA.)
^ar-Q0154-answer

**ar-Q0155** — أنت مشتر جيد.

You are a good customer.

Why: Adjective and noun agreement. [[Arabic#^ar-Q0155|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D9%86%D8%AA%20%D9%85%D8%B4%D8%AA%D8%B1%20%D8%AC%D9%8A%D8%AF.)
^ar-Q0155-answer

**ar-Q0156** — أنت مشتر جيد.

You are a good customer.

Attributive adjectives generally follow the noun and agree in gender, definiteness, case and relevant number patterns. Non-human plurals commonly take feminine singular agreement in MSA.

Why: Adjective and noun agreement. [[Arabic#^ar-Q0156|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D9%86%D8%AA%20%D9%85%D8%B4%D8%AA%D8%B1%20%D8%AC%D9%8A%D8%AF.)
^ar-Q0156-answer

**ar-Q0157** — أنا متأكد أني سأجد هدية جيدة لتوم.

I'm sure I'll find a good gift for Tom.

Expected form: **جيد**

Why: Adjective and noun agreement. [[Arabic#^ar-Q0157|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D9%86%D8%A7%20%D9%85%D8%AA%D8%A3%D9%83%D8%AF%20%D8%A3%D9%86%D9%8A%20%D8%B3%D8%A3%D8%AC%D8%AF%20%D9%87%D8%AF%D9%8A%D8%A9%20%D8%AC%D9%8A%D8%AF%D8%A9%20%D9%84%D8%AA%D9%88%D9%85.)
^ar-Q0157-answer

**ar-Q0158** — أنا متأكد أني سأجد هدية جيدة لتوم.

I'm sure I'll find a good gift for Tom.

Expected form: **جيد**

Why: Adjective and noun agreement. [[Arabic#^ar-Q0158|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D9%86%D8%A7%20%D9%85%D8%AA%D8%A3%D9%83%D8%AF%20%D8%A3%D9%86%D9%8A%20%D8%B3%D8%A3%D8%AC%D8%AF%20%D9%87%D8%AF%D9%8A%D8%A9%20%D8%AC%D9%8A%D8%AF%D8%A9%20%D9%84%D8%AA%D9%88%D9%85.)
^ar-Q0158-answer

**ar-Q0159** — لدى سامي غسّالة أطباق جديدة.

Sami has a new dishwasher.

Expected form: **جديد**

Why: Adjective and noun agreement. [[Arabic#^ar-Q0159|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D8%AF%D9%89%20%D8%B3%D8%A7%D9%85%D9%8A%20%D8%BA%D8%B3%D9%91%D8%A7%D9%84%D8%A9%20%D8%A3%D8%B7%D8%A8%D8%A7%D9%82%20%D8%AC%D8%AF%D9%8A%D8%AF%D8%A9.)
^ar-Q0159-answer

**ar-Q0160** — لدى سامي غسّالة أطباق جديدة.

Sami has a new dishwasher.

Why: Adjective and noun agreement. [[Arabic#^ar-Q0160|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D8%AF%D9%89%20%D8%B3%D8%A7%D9%85%D9%8A%20%D8%BA%D8%B3%D9%91%D8%A7%D9%84%D8%A9%20%D8%A3%D8%B7%D8%A8%D8%A7%D9%82%20%D8%AC%D8%AF%D9%8A%D8%AF%D8%A9.)
^ar-Q0160-answer

**ar-Q0161** — كان جون يجمع الطوابع مذ كان صغيرًا.

John has been collecting stamps since he was a child.

Why: Adjective and noun agreement. [[Arabic#^ar-Q0161|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D8%A7%D9%86%20%D8%AC%D9%88%D9%86%20%D9%8A%D8%AC%D9%85%D8%B9%20%D8%A7%D9%84%D8%B7%D9%88%D8%A7%D8%A8%D8%B9%20%D9%85%D8%B0%20%D9%83%D8%A7%D9%86%20%D8%B5%D8%BA%D9%8A%D8%B1%D9%8B%D8%A7.)
^ar-Q0161-answer

**ar-Q0162** — كان جون يجمع الطوابع مذ كان صغيرًا.

John has been collecting stamps since he was a child.

Attributive adjectives generally follow the noun and agree in gender, definiteness, case and relevant number patterns. Non-human plurals commonly take feminine singular agreement in MSA.

Why: Adjective and noun agreement. [[Arabic#^ar-Q0162|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D8%A7%D9%86%20%D8%AC%D9%88%D9%86%20%D9%8A%D8%AC%D9%85%D8%B9%20%D8%A7%D9%84%D8%B7%D9%88%D8%A7%D8%A8%D8%B9%20%D9%85%D8%B0%20%D9%83%D8%A7%D9%86%20%D8%B5%D8%BA%D9%8A%D8%B1%D9%8B%D8%A7.)
^ar-Q0162-answer

**ar-Q0163** — طفلي الجديد وصل!

My new baby arrived!

Expected form: **جديد**

Why: Adjective and noun agreement. [[Arabic#^ar-Q0163|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B7%D9%81%D9%84%D9%8A%20%D8%A7%D9%84%D8%AC%D8%AF%D9%8A%D8%AF%20%D9%88%D8%B5%D9%84%21)
^ar-Q0163-answer

**ar-Q0164** — طفلي الجديد وصل!

My new baby arrived!

Expected form: **جديد**

Why: Adjective and noun agreement. [[Arabic#^ar-Q0164|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B7%D9%81%D9%84%D9%8A%20%D8%A7%D9%84%D8%AC%D8%AF%D9%8A%D8%AF%20%D9%88%D8%B5%D9%84%21)
^ar-Q0164-answer

**ar-Q0165** — أنا أطهو, ولكن لا أفعل هذا بمتعة كبيرة.

I cook, but I don't do that with much pleasure.

Expected form: **كبير**

Why: Adjective and noun agreement. [[Arabic#^ar-Q0165|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D9%86%D8%A7%20%D8%A3%D8%B7%D9%87%D9%88%2C%20%D9%88%D9%84%D9%83%D9%86%20%D9%84%D8%A7%20%D8%A3%D9%81%D8%B9%D9%84%20%D9%87%D8%B0%D8%A7%20%D8%A8%D9%85%D8%AA%D8%B9%D8%A9%20%D9%83%D8%A8%D9%8A%D8%B1%D8%A9.)
^ar-Q0165-answer

**ar-Q0166** — أنا أطهو, ولكن لا أفعل هذا بمتعة كبيرة.

I cook, but I don't do that with much pleasure.

Why: Adjective and noun agreement. [[Arabic#^ar-Q0166|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D9%86%D8%A7%20%D8%A3%D8%B7%D9%87%D9%88%2C%20%D9%88%D9%84%D9%83%D9%86%20%D9%84%D8%A7%20%D8%A3%D9%81%D8%B9%D9%84%20%D9%87%D8%B0%D8%A7%20%D8%A8%D9%85%D8%AA%D8%B9%D8%A9%20%D9%83%D8%A8%D9%8A%D8%B1%D8%A9.)
^ar-Q0166-answer

**ar-Q0167** — قيادتها للدراجة النارية جيدة.

She rides a motorcycle well.

Why: Adjective and noun agreement. [[Arabic#^ar-Q0167|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%82%D9%8A%D8%A7%D8%AF%D8%AA%D9%87%D8%A7%20%D9%84%D9%84%D8%AF%D8%B1%D8%A7%D8%AC%D8%A9%20%D8%A7%D9%84%D9%86%D8%A7%D8%B1%D9%8A%D8%A9%20%D8%AC%D9%8A%D8%AF%D8%A9.)
^ar-Q0167-answer

**ar-Q0168** — قيادتها للدراجة النارية جيدة.

She rides a motorcycle well.

Attributive adjectives generally follow the noun and agree in gender, definiteness, case and relevant number patterns. Non-human plurals commonly take feminine singular agreement in MSA.

Why: Adjective and noun agreement. [[Arabic#^ar-Q0168|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%82%D9%8A%D8%A7%D8%AF%D8%AA%D9%87%D8%A7%20%D9%84%D9%84%D8%AF%D8%B1%D8%A7%D8%AC%D8%A9%20%D8%A7%D9%84%D9%86%D8%A7%D8%B1%D9%8A%D8%A9%20%D8%AC%D9%8A%D8%AF%D8%A9.)
^ar-Q0168-answer

**ar-Q0169** — أنا راضٍ تماما ببيتي الجديد.

I am very pleased with my new house.

Expected form: **جديد**

Why: Adjective and noun agreement. [[Arabic#^ar-Q0169|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D9%86%D8%A7%20%D8%B1%D8%A7%D8%B6%D9%8D%20%D8%AA%D9%85%D8%A7%D9%85%D8%A7%20%D8%A8%D8%A8%D9%8A%D8%AA%D9%8A%20%D8%A7%D9%84%D8%AC%D8%AF%D9%8A%D8%AF.)
^ar-Q0169-answer

**ar-Q0170** — أنا راضٍ تماما ببيتي الجديد.

I am very pleased with my new house.

Expected form: **جديد**

Why: Adjective and noun agreement. [[Arabic#^ar-Q0170|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D9%86%D8%A7%20%D8%B1%D8%A7%D8%B6%D9%8D%20%D8%AA%D9%85%D8%A7%D9%85%D8%A7%20%D8%A8%D8%A8%D9%8A%D8%AA%D9%8A%20%D8%A7%D9%84%D8%AC%D8%AF%D9%8A%D8%AF.)
^ar-Q0170-answer

**ar-Q0171** — لا تكن سخيفا! فنحن أصدقاء جيدون.

Don't be silly! We're just friends. Good friends.

Expected form: **جيد**

Why: Adjective and noun agreement. [[Arabic#^ar-Q0171|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D8%A7%20%D8%AA%D9%83%D9%86%20%D8%B3%D8%AE%D9%8A%D9%81%D8%A7%21%20%D9%81%D9%86%D8%AD%D9%86%20%D8%A3%D8%B5%D8%AF%D9%82%D8%A7%D8%A1%20%D8%AC%D9%8A%D8%AF%D9%88%D9%86.)
^ar-Q0171-answer

**ar-Q0172** — لا تكن سخيفا! فنحن أصدقاء جيدون.

Don't be silly! We're just friends. Good friends.

Why: Adjective and noun agreement. [[Arabic#^ar-Q0172|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D8%A7%20%D8%AA%D9%83%D9%86%20%D8%B3%D8%AE%D9%8A%D9%81%D8%A7%21%20%D9%81%D9%86%D8%AD%D9%86%20%D8%A3%D8%B5%D8%AF%D9%82%D8%A7%D8%A1%20%D8%AC%D9%8A%D8%AF%D9%88%D9%86.)
^ar-Q0172-answer

**ar-Q0173** — أحب توم تسريحة شعر ماري الجديدة.

Tom liked Mary's new hairstyle.

Why: Adjective and noun agreement. [[Arabic#^ar-Q0173|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%AD%D8%A8%20%D8%AA%D9%88%D9%85%20%D8%AA%D8%B3%D8%B1%D9%8A%D8%AD%D8%A9%20%D8%B4%D8%B9%D8%B1%20%D9%85%D8%A7%D8%B1%D9%8A%20%D8%A7%D9%84%D8%AC%D8%AF%D9%8A%D8%AF%D8%A9.)
^ar-Q0173-answer

**ar-Q0174** — أحب توم تسريحة شعر ماري الجديدة.

Tom liked Mary's new hairstyle.

Attributive adjectives generally follow the noun and agree in gender, definiteness, case and relevant number patterns. Non-human plurals commonly take feminine singular agreement in MSA.

Why: Adjective and noun agreement. [[Arabic#^ar-Q0174|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%AD%D8%A8%20%D8%AA%D9%88%D9%85%20%D8%AA%D8%B3%D8%B1%D9%8A%D8%AD%D8%A9%20%D8%B4%D8%B9%D8%B1%20%D9%85%D8%A7%D8%B1%D9%8A%20%D8%A7%D9%84%D8%AC%D8%AF%D9%8A%D8%AF%D8%A9.)
^ar-Q0174-answer

**ar-Q0175** — أنا أُحب أن أُجرب لأفعل أشياء جديدة.

I love trying to do new things.

Expected form: **جديد**

Why: Adjective and noun agreement. [[Arabic#^ar-Q0175|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D9%86%D8%A7%20%D8%A3%D9%8F%D8%AD%D8%A8%20%D8%A3%D9%86%20%D8%A3%D9%8F%D8%AC%D8%B1%D8%A8%20%D9%84%D8%A3%D9%81%D8%B9%D9%84%20%D8%A3%D8%B4%D9%8A%D8%A7%D8%A1%20%D8%AC%D8%AF%D9%8A%D8%AF%D8%A9.)
^ar-Q0175-answer

**ar-Q0176** — أنا أُحب أن أُجرب لأفعل أشياء جديدة.

I love trying to do new things.

Expected form: **جديد**

Why: Adjective and noun agreement. [[Arabic#^ar-Q0176|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D9%86%D8%A7%20%D8%A3%D9%8F%D8%AD%D8%A8%20%D8%A3%D9%86%20%D8%A3%D9%8F%D8%AC%D8%B1%D8%A8%20%D9%84%D8%A3%D9%81%D8%B9%D9%84%20%D8%A3%D8%B4%D9%8A%D8%A7%D8%A1%20%D8%AC%D8%AF%D9%8A%D8%AF%D8%A9.)
^ar-Q0176-answer

**ar-Q0177** — هلّا اقترحت مكانا جيدا لأكل الطعام الكوري؟

Can you recommend a good place to eat Korean food?

Expected form: **جيد**

Why: Adjective and noun agreement. [[Arabic#^ar-Q0177|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D9%84%D9%91%D8%A7%20%D8%A7%D9%82%D8%AA%D8%B1%D8%AD%D8%AA%20%D9%85%D9%83%D8%A7%D9%86%D8%A7%20%D8%AC%D9%8A%D8%AF%D8%A7%20%D9%84%D8%A3%D9%83%D9%84%20%D8%A7%D9%84%D8%B7%D8%B9%D8%A7%D9%85%20%D8%A7%D9%84%D9%83%D9%88%D8%B1%D9%8A%D8%9F)
^ar-Q0177-answer

**ar-Q0178** — هلّا اقترحت مكانا جيدا لأكل الطعام الكوري؟

Can you recommend a good place to eat Korean food?

Why: Adjective and noun agreement. [[Arabic#^ar-Q0178|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D9%84%D9%91%D8%A7%20%D8%A7%D9%82%D8%AA%D8%B1%D8%AD%D8%AA%20%D9%85%D9%83%D8%A7%D9%86%D8%A7%20%D8%AC%D9%8A%D8%AF%D8%A7%20%D9%84%D8%A3%D9%83%D9%84%20%D8%A7%D9%84%D8%B7%D8%B9%D8%A7%D9%85%20%D8%A7%D9%84%D9%83%D9%88%D8%B1%D9%8A%D8%9F)
^ar-Q0178-answer

**ar-Q0179** — السيدة وود طباخة جيدة.

Mrs. Wood was a very good cook.

Why: Adjective and noun agreement. [[Arabic#^ar-Q0179|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A7%D9%84%D8%B3%D9%8A%D8%AF%D8%A9%20%D9%88%D9%88%D8%AF%20%D8%B7%D8%A8%D8%A7%D8%AE%D8%A9%20%D8%AC%D9%8A%D8%AF%D8%A9.)
^ar-Q0179-answer

**ar-Q0180** — السيدة وود طباخة جيدة.

Mrs. Wood was a very good cook.

Attributive adjectives generally follow the noun and agree in gender, definiteness, case and relevant number patterns. Non-human plurals commonly take feminine singular agreement in MSA.

Why: Adjective and noun agreement. [[Arabic#^ar-Q0180|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A7%D9%84%D8%B3%D9%8A%D8%AF%D8%A9%20%D9%88%D9%88%D8%AF%20%D8%B7%D8%A8%D8%A7%D8%AE%D8%A9%20%D8%AC%D9%8A%D8%AF%D8%A9.)
^ar-Q0180-answer

**ar-Q0181** — لدي سيارة حمراء جديدة.

I have a new red car.

Expected form: **جديد**

Why: Adjective and noun agreement. [[Arabic#^ar-Q0181|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D8%AF%D9%8A%20%D8%B3%D9%8A%D8%A7%D8%B1%D8%A9%20%D8%AD%D9%85%D8%B1%D8%A7%D8%A1%20%D8%AC%D8%AF%D9%8A%D8%AF%D8%A9.)
^ar-Q0181-answer

**ar-Q0182** — لدي سيارة حمراء جديدة.

I have a new red car.

Expected form: **جديد**

Why: Adjective and noun agreement. [[Arabic#^ar-Q0182|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D8%AF%D9%8A%20%D8%B3%D9%8A%D8%A7%D8%B1%D8%A9%20%D8%AD%D9%85%D8%B1%D8%A7%D8%A1%20%D8%AC%D8%AF%D9%8A%D8%AF%D8%A9.)
^ar-Q0182-answer

**ar-Q0183** — اللّغة مجرّد خريطة للتّفكير و المشاعر و الذّكريات البشريّة. و مثل جميع الخرائط، فإنّ اللّغة أيقونة صغيرة أصغر بمائة ألف مرّة من الشّيء الذي تمثّله.

Language is just a map of human thoughts, feelings and memories. And like all maps, language is a thumbnail image a hundred thousand times smaller than what it is trying to convey.

Expected form: **صغير**

Why: Adjective and noun agreement. [[Arabic#^ar-Q0183|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A7%D9%84%D9%84%D9%91%D8%BA%D8%A9%20%D9%85%D8%AC%D8%B1%D9%91%D8%AF%20%D8%AE%D8%B1%D9%8A%D8%B7%D8%A9%20%D9%84%D9%84%D8%AA%D9%91%D9%81%D9%83%D9%8A%D8%B1%20%D9%88%20%D8%A7%D9%84%D9%85%D8%B4%D8%A7%D8%B9%D8%B1%20%D9%88%20%D8%A7%D9%84%D8%B0%D9%91%D9%83%D8%B1%D9%8A%D8%A7%D8%AA%20%D8%A7%D9%84%D8%A8%D8%B4%D8%B1%D9%8A%D9%91%D8%A9.%20%D9%88%20%D9%85%D8%AB%D9%84%20%D8%AC%D9%85%D9%8A%D8%B9%20%D8%A7%D9%84%D8%AE%D8%B1%D8%A7%D8%A6%D8%B7%D8%8C%20%D9%81%D8%A5%D9%86%D9%91%20%D8%A7%D9%84%D9%84%D9%91%D8%BA%D8%A9%20%D8%A3%D9%8A%D9%82%D9%88%D9%86%D8%A9%20%D8%B5%D8%BA%D9%8A%D8%B1%D8%A9%20%D8%A3%D8%B5%D8%BA%D8%B1%20%D8%A8%D9%85%D8%A7%D8%A6%D8%A9%20%D8%A3%D9%84%D9%81%20%D9%85%D8%B1%D9%91%D8%A9%20%D9%85%D9%86%20%D8%A7%D9%84%D8%B4%D9%91%D9%8A%D8%A1%20%D8%A7%D9%84%D8%B0%D9%8A%20%D8%AA%D9%85%D8%AB%D9%91%D9%84%D9%87.)
^ar-Q0183-answer

**ar-Q0184** — اللّغة مجرّد خريطة للتّفكير و المشاعر و الذّكريات البشريّة. و مثل جميع الخرائط، فإنّ اللّغة أيقونة صغيرة أصغر بمائة ألف مرّة من الشّيء الذي تمثّله.

Language is just a map of human thoughts, feelings and memories. And like all maps, language is a thumbnail image a hundred thousand times smaller than what it is trying to convey.

Why: Adjective and noun agreement. [[Arabic#^ar-Q0184|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A7%D9%84%D9%84%D9%91%D8%BA%D8%A9%20%D9%85%D8%AC%D8%B1%D9%91%D8%AF%20%D8%AE%D8%B1%D9%8A%D8%B7%D8%A9%20%D9%84%D9%84%D8%AA%D9%91%D9%81%D9%83%D9%8A%D8%B1%20%D9%88%20%D8%A7%D9%84%D9%85%D8%B4%D8%A7%D8%B9%D8%B1%20%D9%88%20%D8%A7%D9%84%D8%B0%D9%91%D9%83%D8%B1%D9%8A%D8%A7%D8%AA%20%D8%A7%D9%84%D8%A8%D8%B4%D8%B1%D9%8A%D9%91%D8%A9.%20%D9%88%20%D9%85%D8%AB%D9%84%20%D8%AC%D9%85%D9%8A%D8%B9%20%D8%A7%D9%84%D8%AE%D8%B1%D8%A7%D8%A6%D8%B7%D8%8C%20%D9%81%D8%A5%D9%86%D9%91%20%D8%A7%D9%84%D9%84%D9%91%D8%BA%D8%A9%20%D8%A3%D9%8A%D9%82%D9%88%D9%86%D8%A9%20%D8%B5%D8%BA%D9%8A%D8%B1%D8%A9%20%D8%A3%D8%B5%D8%BA%D8%B1%20%D8%A8%D9%85%D8%A7%D8%A6%D8%A9%20%D8%A3%D9%84%D9%81%20%D9%85%D8%B1%D9%91%D8%A9%20%D9%85%D9%86%20%D8%A7%D9%84%D8%B4%D9%91%D9%8A%D8%A1%20%D8%A7%D9%84%D8%B0%D9%8A%20%D8%AA%D9%85%D8%AB%D9%91%D9%84%D9%87.)
^ar-Q0184-answer

**ar-Q0185** — هذا جيد جدا

It's very good.

Why: Adjective and noun agreement. [[Arabic#^ar-Q0185|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D8%B0%D8%A7%20%D8%AC%D9%8A%D8%AF%20%D8%AC%D8%AF%D8%A7)
^ar-Q0185-answer

**ar-Q0186** — هذا جيد جدا

It's very good.

Attributive adjectives generally follow the noun and agree in gender, definiteness, case and relevant number patterns. Non-human plurals commonly take feminine singular agreement in MSA.

Why: Adjective and noun agreement. [[Arabic#^ar-Q0186|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D8%B0%D8%A7%20%D8%AC%D9%8A%D8%AF%20%D8%AC%D8%AF%D8%A7)
^ar-Q0186-answer

**ar-Q0187** — نريد شيئاً جديداً.

We want something new.

Expected form: **جديد**

Why: Adjective and noun agreement. [[Arabic#^ar-Q0187|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%86%D8%B1%D9%8A%D8%AF%20%D8%B4%D9%8A%D8%A6%D8%A7%D9%8B%20%D8%AC%D8%AF%D9%8A%D8%AF%D8%A7%D9%8B.)
^ar-Q0187-answer

**ar-Q0188** — نريد شيئاً جديداً.

We want something new.

Expected form: **جديد**

Why: Adjective and noun agreement. [[Arabic#^ar-Q0188|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%86%D8%B1%D9%8A%D8%AF%20%D8%B4%D9%8A%D8%A6%D8%A7%D9%8B%20%D8%AC%D8%AF%D9%8A%D8%AF%D8%A7%D9%8B.)
^ar-Q0188-answer

**ar-Q0189** — أريد أن أراك من جديد.

I want to see you again.

Expected form: **جديد**

Why: Adjective and noun agreement. [[Arabic#^ar-Q0189|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%B1%D9%8A%D8%AF%20%D8%A3%D9%86%20%D8%A3%D8%B1%D8%A7%D9%83%20%D9%85%D9%86%20%D8%AC%D8%AF%D9%8A%D8%AF.)
^ar-Q0189-answer

**ar-Q0190** — أريد أن أراك من جديد.

I want to see you again.

Why: Adjective and noun agreement. [[Arabic#^ar-Q0190|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%B1%D9%8A%D8%AF%20%D8%A3%D9%86%20%D8%A3%D8%B1%D8%A7%D9%83%20%D9%85%D9%86%20%D8%AC%D8%AF%D9%8A%D8%AF.)
^ar-Q0190-answer

**ar-Q0191** — كان فاضل طفلا صغيرا ذو ابتسامة مشعّة.

Fadil was a little boy with a sunny smile.

Why: Adjective and noun agreement. [[Arabic#^ar-Q0191|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D8%A7%D9%86%20%D9%81%D8%A7%D8%B6%D9%84%20%D8%B7%D9%81%D9%84%D8%A7%20%D8%B5%D8%BA%D9%8A%D8%B1%D8%A7%20%D8%B0%D9%88%20%D8%A7%D8%A8%D8%AA%D8%B3%D8%A7%D9%85%D8%A9%20%D9%85%D8%B4%D8%B9%D9%91%D8%A9.)
^ar-Q0191-answer

**ar-Q0192** — كان فاضل طفلا صغيرا ذو ابتسامة مشعّة.

Fadil was a little boy with a sunny smile.

Attributive adjectives generally follow the noun and agree in gender, definiteness, case and relevant number patterns. Non-human plurals commonly take feminine singular agreement in MSA.

Why: Adjective and noun agreement. [[Arabic#^ar-Q0192|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D8%A7%D9%86%20%D9%81%D8%A7%D8%B6%D9%84%20%D8%B7%D9%81%D9%84%D8%A7%20%D8%B5%D8%BA%D9%8A%D8%B1%D8%A7%20%D8%B0%D9%88%20%D8%A7%D8%A8%D8%AA%D8%B3%D8%A7%D9%85%D8%A9%20%D9%85%D8%B4%D8%B9%D9%91%D8%A9.)
^ar-Q0192-answer

**ar-Q0193** — توم ليس جيد للحديث مع الاطفال

Tom isn't good at talking to children.

Expected form: **جيد**

Why: Adjective and noun agreement. [[Arabic#^ar-Q0193|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%AA%D9%88%D9%85%20%D9%84%D9%8A%D8%B3%20%D8%AC%D9%8A%D8%AF%20%D9%84%D9%84%D8%AD%D8%AF%D9%8A%D8%AB%20%D9%85%D8%B9%20%D8%A7%D9%84%D8%A7%D8%B7%D9%81%D8%A7%D9%84)
^ar-Q0193-answer

**ar-Q0194** — توم ليس جيد للحديث مع الاطفال

Tom isn't good at talking to children.

Expected form: **جيد**

Why: Adjective and noun agreement. [[Arabic#^ar-Q0194|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%AA%D9%88%D9%85%20%D9%84%D9%8A%D8%B3%20%D8%AC%D9%8A%D8%AF%20%D9%84%D9%84%D8%AD%D8%AF%D9%8A%D8%AB%20%D9%85%D8%B9%20%D8%A7%D9%84%D8%A7%D8%B7%D9%81%D8%A7%D9%84)
^ar-Q0194-answer

**ar-Q0195** — توجد غرفة المعيشة في الطابق الأرضي من منزلي الجديد بينما غرفة النوم في الطابق الأول.

In my new house, the living room is on the ground floor and the bedroom is on the first floor.

Expected form: **جديد**

Why: Adjective and noun agreement. [[Arabic#^ar-Q0195|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%AA%D9%88%D8%AC%D8%AF%20%D8%BA%D8%B1%D9%81%D8%A9%20%D8%A7%D9%84%D9%85%D8%B9%D9%8A%D8%B4%D8%A9%20%D9%81%D9%8A%20%D8%A7%D9%84%D8%B7%D8%A7%D8%A8%D9%82%20%D8%A7%D9%84%D8%A3%D8%B1%D8%B6%D9%8A%20%D9%85%D9%86%20%D9%85%D9%86%D8%B2%D9%84%D9%8A%20%D8%A7%D9%84%D8%AC%D8%AF%D9%8A%D8%AF%20%D8%A8%D9%8A%D9%86%D9%85%D8%A7%20%D8%BA%D8%B1%D9%81%D8%A9%20%D8%A7%D9%84%D9%86%D9%88%D9%85%20%D9%81%D9%8A%20%D8%A7%D9%84%D8%B7%D8%A7%D8%A8%D9%82%20%D8%A7%D9%84%D8%A3%D9%88%D9%84.)
^ar-Q0195-answer

**ar-Q0196** — توجد غرفة المعيشة في الطابق الأرضي من منزلي الجديد بينما غرفة النوم في الطابق الأول.

In my new house, the living room is on the ground floor and the bedroom is on the first floor.

Why: Adjective and noun agreement. [[Arabic#^ar-Q0196|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%AA%D9%88%D8%AC%D8%AF%20%D8%BA%D8%B1%D9%81%D8%A9%20%D8%A7%D9%84%D9%85%D8%B9%D9%8A%D8%B4%D8%A9%20%D9%81%D9%8A%20%D8%A7%D9%84%D8%B7%D8%A7%D8%A8%D9%82%20%D8%A7%D9%84%D8%A3%D8%B1%D8%B6%D9%8A%20%D9%85%D9%86%20%D9%85%D9%86%D8%B2%D9%84%D9%8A%20%D8%A7%D9%84%D8%AC%D8%AF%D9%8A%D8%AF%20%D8%A8%D9%8A%D9%86%D9%85%D8%A7%20%D8%BA%D8%B1%D9%81%D8%A9%20%D8%A7%D9%84%D9%86%D9%88%D9%85%20%D9%81%D9%8A%20%D8%A7%D9%84%D8%B7%D8%A7%D8%A8%D9%82%20%D8%A7%D9%84%D8%A3%D9%88%D9%84.)
^ar-Q0196-answer

**ar-Q0197** — من الجيد رؤيتك

It's good seeing you.

Why: Adjective and noun agreement. [[Arabic#^ar-Q0197|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D9%86%20%D8%A7%D9%84%D8%AC%D9%8A%D8%AF%20%D8%B1%D8%A4%D9%8A%D8%AA%D9%83)
^ar-Q0197-answer

**ar-Q0198** — من الجيد رؤيتك

It's good seeing you.

Attributive adjectives generally follow the noun and agree in gender, definiteness, case and relevant number patterns. Non-human plurals commonly take feminine singular agreement in MSA.

Why: Adjective and noun agreement. [[Arabic#^ar-Q0198|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D9%86%20%D8%A7%D9%84%D8%AC%D9%8A%D8%AF%20%D8%B1%D8%A4%D9%8A%D8%AA%D9%83)
^ar-Q0198-answer

**ar-Q0199** — يبدو صغيراً، ولكن في الواقع هو فوقَ الأربعين.

He looks young, but actually he is over forty.

Expected form: **صغير**

Why: Adjective and noun agreement. [[Arabic#^ar-Q0199|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%8A%D8%A8%D8%AF%D9%88%20%D8%B5%D8%BA%D9%8A%D8%B1%D8%A7%D9%8B%D8%8C%20%D9%88%D9%84%D9%83%D9%86%20%D9%81%D9%8A%20%D8%A7%D9%84%D9%88%D8%A7%D9%82%D8%B9%20%D9%87%D9%88%20%D9%81%D9%88%D9%82%D9%8E%20%D8%A7%D9%84%D8%A3%D8%B1%D8%A8%D8%B9%D9%8A%D9%86.)
^ar-Q0199-answer

**ar-Q0200** — يبدو صغيراً، ولكن في الواقع هو فوقَ الأربعين.

He looks young, but actually he is over forty.

Expected form: **صغير**

Why: Adjective and noun agreement. [[Arabic#^ar-Q0200|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%8A%D8%A8%D8%AF%D9%88%20%D8%B5%D8%BA%D9%8A%D8%B1%D8%A7%D9%8B%D8%8C%20%D9%88%D9%84%D9%83%D9%86%20%D9%81%D9%8A%20%D8%A7%D9%84%D9%88%D8%A7%D9%82%D8%B9%20%D9%87%D9%88%20%D9%81%D9%88%D9%82%D9%8E%20%D8%A7%D9%84%D8%A3%D8%B1%D8%A8%D8%B9%D9%8A%D9%86.)
^ar-Q0200-answer


### Answers 201–250

**ar-Q0201** — هىَ ليست أختي.

She's not my sister.

Expected form: **أختي**

Why: Possession and iḍāfa. [[Arabic#^ar-Q0201|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D9%89%D9%8E%20%D9%84%D9%8A%D8%B3%D8%AA%20%D8%A3%D8%AE%D8%AA%D9%8A.)
^ar-Q0201-answer

**ar-Q0202** — هىَ ليست أختي.

She's not my sister.

Why: Possession and iḍāfa. [[Arabic#^ar-Q0202|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D9%89%D9%8E%20%D9%84%D9%8A%D8%B3%D8%AA%20%D8%A3%D8%AE%D8%AA%D9%8A.)
^ar-Q0202-answer

**ar-Q0203** — أنا آسف يا محمد، لقد نسيت اسمك!

I'm sorry Mohammed, I forgot your name!

Why: Possession and iḍāfa. [[Arabic#^ar-Q0203|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D9%86%D8%A7%20%D8%A2%D8%B3%D9%81%20%D9%8A%D8%A7%20%D9%85%D8%AD%D9%85%D8%AF%D8%8C%20%D9%84%D9%82%D8%AF%20%D9%86%D8%B3%D9%8A%D8%AA%20%D8%A7%D8%B3%D9%85%D9%83%21)
^ar-Q0203-answer

**ar-Q0204** — أنا آسف يا محمد، لقد نسيت اسمك!

I'm sorry Mohammed, I forgot your name!

Possessive suffixes attach to nouns. An iḍāfa noun chain expresses another possession relation; its first noun normally has neither the definite article nor tanwīn. Pronunciation differs by dialect and register.

Why: Possession and iḍāfa. [[Arabic#^ar-Q0204|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D9%86%D8%A7%20%D8%A2%D8%B3%D9%81%20%D9%8A%D8%A7%20%D9%85%D8%AD%D9%85%D8%AF%D8%8C%20%D9%84%D9%82%D8%AF%20%D9%86%D8%B3%D9%8A%D8%AA%20%D8%A7%D8%B3%D9%85%D9%83%21)
^ar-Q0204-answer

**ar-Q0205** — هل أستطيع أن أسألك عن اسمك؟

May I ask your name?

Expected form: **اسمك**

Why: Possession and iḍāfa. [[Arabic#^ar-Q0205|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D9%84%20%D8%A3%D8%B3%D8%AA%D8%B7%D9%8A%D8%B9%20%D8%A3%D9%86%20%D8%A3%D8%B3%D8%A3%D9%84%D9%83%20%D8%B9%D9%86%20%D8%A7%D8%B3%D9%85%D9%83%D8%9F)
^ar-Q0205-answer

**ar-Q0206** — هل أستطيع أن أسألك عن اسمك؟

May I ask your name?

Expected form: **اسمك**

Why: Possession and iḍāfa. [[Arabic#^ar-Q0206|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D9%84%20%D8%A3%D8%B3%D8%AA%D8%B7%D9%8A%D8%B9%20%D8%A3%D9%86%20%D8%A3%D8%B3%D8%A3%D9%84%D9%83%20%D8%B9%D9%86%20%D8%A7%D8%B3%D9%85%D9%83%D8%9F)
^ar-Q0206-answer

**ar-Q0207** — لا تنسى أن تأتي إلى بيتي.

Be sure to drop in at my house.

Expected form: **بيتي**

Why: Possession and iḍāfa. [[Arabic#^ar-Q0207|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D8%A7%20%D8%AA%D9%86%D8%B3%D9%89%20%D8%A3%D9%86%20%D8%AA%D8%A3%D8%AA%D9%8A%20%D8%A5%D9%84%D9%89%20%D8%A8%D9%8A%D8%AA%D9%8A.)
^ar-Q0207-answer

**ar-Q0208** — لا تنسى أن تأتي إلى بيتي.

Be sure to drop in at my house.

Why: Possession and iḍāfa. [[Arabic#^ar-Q0208|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D8%A7%20%D8%AA%D9%86%D8%B3%D9%89%20%D8%A3%D9%86%20%D8%AA%D8%A3%D8%AA%D9%8A%20%D8%A5%D9%84%D9%89%20%D8%A8%D9%8A%D8%AA%D9%8A.)
^ar-Q0208-answer

**ar-Q0209** — كثيراً ما تشرب أختي الكبرى الشاي بالحليب.

My older sister often drinks tea with milk.

Why: Possession and iḍāfa. [[Arabic#^ar-Q0209|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D8%AB%D9%8A%D8%B1%D8%A7%D9%8B%20%D9%85%D8%A7%20%D8%AA%D8%B4%D8%B1%D8%A8%20%D8%A3%D8%AE%D8%AA%D9%8A%20%D8%A7%D9%84%D9%83%D8%A8%D8%B1%D9%89%20%D8%A7%D9%84%D8%B4%D8%A7%D9%8A%20%D8%A8%D8%A7%D9%84%D8%AD%D9%84%D9%8A%D8%A8.)
^ar-Q0209-answer

**ar-Q0210** — كثيراً ما تشرب أختي الكبرى الشاي بالحليب.

My older sister often drinks tea with milk.

Possessive suffixes attach to nouns. An iḍāfa noun chain expresses another possession relation; its first noun normally has neither the definite article nor tanwīn. Pronunciation differs by dialect and register.

Why: Possession and iḍāfa. [[Arabic#^ar-Q0210|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D8%AB%D9%8A%D8%B1%D8%A7%D9%8B%20%D9%85%D8%A7%20%D8%AA%D8%B4%D8%B1%D8%A8%20%D8%A3%D8%AE%D8%AA%D9%8A%20%D8%A7%D9%84%D9%83%D8%A8%D8%B1%D9%89%20%D8%A7%D9%84%D8%B4%D8%A7%D9%8A%20%D8%A8%D8%A7%D9%84%D8%AD%D9%84%D9%8A%D8%A8.)
^ar-Q0210-answer

**ar-Q0211** — أختي أقصر منك.

My sister is shorter than you.

Expected form: **أختي**

Why: Possession and iḍāfa. [[Arabic#^ar-Q0211|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%AE%D8%AA%D9%8A%20%D8%A3%D9%82%D8%B5%D8%B1%20%D9%85%D9%86%D9%83.)
^ar-Q0211-answer

**ar-Q0212** — أختي أقصر منك.

My sister is shorter than you.

Expected form: **أختي**

Why: Possession and iḍāfa. [[Arabic#^ar-Q0212|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%AE%D8%AA%D9%8A%20%D8%A3%D9%82%D8%B5%D8%B1%20%D9%85%D9%86%D9%83.)
^ar-Q0212-answer

**ar-Q0213** — بيتي بارد جدا.

It's very cold in my house.

Expected form: **بيتي**

Why: Possession and iḍāfa. [[Arabic#^ar-Q0213|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A8%D9%8A%D8%AA%D9%8A%20%D8%A8%D8%A7%D8%B1%D8%AF%20%D8%AC%D8%AF%D8%A7.)
^ar-Q0213-answer

**ar-Q0214** — بيتي بارد جدا.

It's very cold in my house.

Why: Possession and iḍāfa. [[Arabic#^ar-Q0214|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A8%D9%8A%D8%AA%D9%8A%20%D8%A8%D8%A7%D8%B1%D8%AF%20%D8%AC%D8%AF%D8%A7.)
^ar-Q0214-answer

**ar-Q0215** — أذلك كتابك الجديد؟

Is that your new book?

Why: Possession and iḍāfa. [[Arabic#^ar-Q0215|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%B0%D9%84%D9%83%20%D9%83%D8%AA%D8%A7%D8%A8%D9%83%20%D8%A7%D9%84%D8%AC%D8%AF%D9%8A%D8%AF%D8%9F)
^ar-Q0215-answer

**ar-Q0216** — أذلك كتابك الجديد؟

Is that your new book?

Possessive suffixes attach to nouns. An iḍāfa noun chain expresses another possession relation; its first noun normally has neither the definite article nor tanwīn. Pronunciation differs by dialect and register.

Why: Possession and iḍāfa. [[Arabic#^ar-Q0216|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%B0%D9%84%D9%83%20%D9%83%D8%AA%D8%A7%D8%A8%D9%83%20%D8%A7%D9%84%D8%AC%D8%AF%D9%8A%D8%AF%D8%9F)
^ar-Q0216-answer

**ar-Q0217** — أخي ساعدني في حل واجبي.

My brother helped me with my homework.

Expected form: **أخي**

Why: Possession and iḍāfa. [[Arabic#^ar-Q0217|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%AE%D9%8A%20%D8%B3%D8%A7%D8%B9%D8%AF%D9%86%D9%8A%20%D9%81%D9%8A%20%D8%AD%D9%84%20%D9%88%D8%A7%D8%AC%D8%A8%D9%8A.)
^ar-Q0217-answer

**ar-Q0218** — أخي ساعدني في حل واجبي.

My brother helped me with my homework.

Expected form: **أخي**

Why: Possession and iḍāfa. [[Arabic#^ar-Q0218|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%AE%D9%8A%20%D8%B3%D8%A7%D8%B9%D8%AF%D9%86%D9%8A%20%D9%81%D9%8A%20%D8%AD%D9%84%20%D9%88%D8%A7%D8%AC%D8%A8%D9%8A.)
^ar-Q0218-answer

**ar-Q0219** — عادةً ما تشرب أختي الكبيرة الشاي مع الحليب.

My older sister often drinks tea with milk.

Expected form: **أختي**

Why: Possession and iḍāfa. [[Arabic#^ar-Q0219|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B9%D8%A7%D8%AF%D8%A9%D9%8B%20%D9%85%D8%A7%20%D8%AA%D8%B4%D8%B1%D8%A8%20%D8%A3%D8%AE%D8%AA%D9%8A%20%D8%A7%D9%84%D9%83%D8%A8%D9%8A%D8%B1%D8%A9%20%D8%A7%D9%84%D8%B4%D8%A7%D9%8A%20%D9%85%D8%B9%20%D8%A7%D9%84%D8%AD%D9%84%D9%8A%D8%A8.)
^ar-Q0219-answer

**ar-Q0220** — عادةً ما تشرب أختي الكبيرة الشاي مع الحليب.

My older sister often drinks tea with milk.

Why: Possession and iḍāfa. [[Arabic#^ar-Q0220|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B9%D8%A7%D8%AF%D8%A9%D9%8B%20%D9%85%D8%A7%20%D8%AA%D8%B4%D8%B1%D8%A8%20%D8%A3%D8%AE%D8%AA%D9%8A%20%D8%A7%D9%84%D9%83%D8%A8%D9%8A%D8%B1%D8%A9%20%D8%A7%D9%84%D8%B4%D8%A7%D9%8A%20%D9%85%D8%B9%20%D8%A7%D9%84%D8%AD%D9%84%D9%8A%D8%A8.)
^ar-Q0220-answer

**ar-Q0221** — ذهبت إلى بيتي.

I went home.

Why: Possession and iḍāfa. [[Arabic#^ar-Q0221|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B0%D9%87%D8%A8%D8%AA%20%D8%A5%D9%84%D9%89%20%D8%A8%D9%8A%D8%AA%D9%8A.)
^ar-Q0221-answer

**ar-Q0222** — ذهبت إلى بيتي.

I went home.

Possessive suffixes attach to nouns. An iḍāfa noun chain expresses another possession relation; its first noun normally has neither the definite article nor tanwīn. Pronunciation differs by dialect and register.

Why: Possession and iḍāfa. [[Arabic#^ar-Q0222|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B0%D9%87%D8%A8%D8%AA%20%D8%A5%D9%84%D9%89%20%D8%A8%D9%8A%D8%AA%D9%8A.)
^ar-Q0222-answer

**ar-Q0223** — أختي سريعة التفكير.

My sister is quick-thinking.

Expected form: **أختي**

Why: Possession and iḍāfa. [[Arabic#^ar-Q0223|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%AE%D8%AA%D9%8A%20%D8%B3%D8%B1%D9%8A%D8%B9%D8%A9%20%D8%A7%D9%84%D8%AA%D9%81%D9%83%D9%8A%D8%B1.)
^ar-Q0223-answer

**ar-Q0224** — أختي سريعة التفكير.

My sister is quick-thinking.

Expected form: **أختي**

Why: Possession and iḍāfa. [[Arabic#^ar-Q0224|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%AE%D8%AA%D9%8A%20%D8%B3%D8%B1%D9%8A%D8%B9%D8%A9%20%D8%A7%D9%84%D8%AA%D9%81%D9%83%D9%8A%D8%B1.)
^ar-Q0224-answer

**ar-Q0225** — أخي الأكبر مدرس.

My older brother is a teacher.

Expected form: **أخي**

Why: Possession and iḍāfa. [[Arabic#^ar-Q0225|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%AE%D9%8A%20%D8%A7%D9%84%D8%A3%D9%83%D8%A8%D8%B1%20%D9%85%D8%AF%D8%B1%D8%B3.)
^ar-Q0225-answer

**ar-Q0226** — أخي الأكبر مدرس.

My older brother is a teacher.

Why: Possession and iḍāfa. [[Arabic#^ar-Q0226|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%AE%D9%8A%20%D8%A7%D9%84%D8%A3%D9%83%D8%A8%D8%B1%20%D9%85%D8%AF%D8%B1%D8%B3.)
^ar-Q0226-answer

**ar-Q0227** — أخبرتني بأنها تعرف أخي.

She told me she knew my brother.

Why: Possession and iḍāfa. [[Arabic#^ar-Q0227|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%AE%D8%A8%D8%B1%D8%AA%D9%86%D9%8A%20%D8%A8%D8%A3%D9%86%D9%87%D8%A7%20%D8%AA%D8%B9%D8%B1%D9%81%20%D8%A3%D8%AE%D9%8A.)
^ar-Q0227-answer

**ar-Q0228** — أخبرتني بأنها تعرف أخي.

She told me she knew my brother.

Possessive suffixes attach to nouns. An iḍāfa noun chain expresses another possession relation; its first noun normally has neither the definite article nor tanwīn. Pronunciation differs by dialect and register.

Why: Possession and iḍāfa. [[Arabic#^ar-Q0228|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%AE%D8%A8%D8%B1%D8%AA%D9%86%D9%8A%20%D8%A8%D8%A3%D9%86%D9%87%D8%A7%20%D8%AA%D8%B9%D8%B1%D9%81%20%D8%A3%D8%AE%D9%8A.)
^ar-Q0228-answer

**ar-Q0229** — لم تقول هذا يا أخي؟

Why do you say these things, brother?

Expected form: **أخي**

Why: Possession and iḍāfa. [[Arabic#^ar-Q0229|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%85%20%D8%AA%D9%82%D9%88%D9%84%20%D9%87%D8%B0%D8%A7%20%D9%8A%D8%A7%20%D8%A3%D8%AE%D9%8A%D8%9F)
^ar-Q0229-answer

**ar-Q0230** — لم تقول هذا يا أخي؟

Why do you say these things, brother?

Expected form: **أخي**

Why: Possession and iḍāfa. [[Arabic#^ar-Q0230|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%85%20%D8%AA%D9%82%D9%88%D9%84%20%D9%87%D8%B0%D8%A7%20%D9%8A%D8%A7%20%D8%A3%D8%AE%D9%8A%D8%9F)
^ar-Q0230-answer

**ar-Q0231** — اسمي معروف لدى الجميع في مدرستي.

My name is known to everybody in my school.

Expected form: **اسمي**

Why: Possession and iḍāfa. [[Arabic#^ar-Q0231|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A7%D8%B3%D9%85%D9%8A%20%D9%85%D8%B9%D8%B1%D9%88%D9%81%20%D9%84%D8%AF%D9%89%20%D8%A7%D9%84%D8%AC%D9%85%D9%8A%D8%B9%20%D9%81%D9%8A%20%D9%85%D8%AF%D8%B1%D8%B3%D8%AA%D9%8A.)
^ar-Q0231-answer

**ar-Q0232** — اسمي معروف لدى الجميع في مدرستي.

My name is known to everybody in my school.

Why: Possession and iḍāfa. [[Arabic#^ar-Q0232|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A7%D8%B3%D9%85%D9%8A%20%D9%85%D8%B9%D8%B1%D9%88%D9%81%20%D9%84%D8%AF%D9%89%20%D8%A7%D9%84%D8%AC%D9%85%D9%8A%D8%B9%20%D9%81%D9%8A%20%D9%85%D8%AF%D8%B1%D8%B3%D8%AA%D9%8A.)
^ar-Q0232-answer

**ar-Q0233** — صنعت لي أختي دميةً جميلة.

My sister made me a beautiful doll.

Why: Possession and iḍāfa. [[Arabic#^ar-Q0233|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B5%D9%86%D8%B9%D8%AA%20%D9%84%D9%8A%20%D8%A3%D8%AE%D8%AA%D9%8A%20%D8%AF%D9%85%D9%8A%D8%A9%D9%8B%20%D8%AC%D9%85%D9%8A%D9%84%D8%A9.)
^ar-Q0233-answer

**ar-Q0234** — صنعت لي أختي دميةً جميلة.

My sister made me a beautiful doll.

Possessive suffixes attach to nouns. An iḍāfa noun chain expresses another possession relation; its first noun normally has neither the definite article nor tanwīn. Pronunciation differs by dialect and register.

Why: Possession and iḍāfa. [[Arabic#^ar-Q0234|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B5%D9%86%D8%B9%D8%AA%20%D9%84%D9%8A%20%D8%A3%D8%AE%D8%AA%D9%8A%20%D8%AF%D9%85%D9%8A%D8%A9%D9%8B%20%D8%AC%D9%85%D9%8A%D9%84%D8%A9.)
^ar-Q0234-answer

**ar-Q0235** — أخي الأكبر طويل القامة حقاً، يبلغ حوالي 1.8 متر.

My elder brother is really tall, about 1.8m.

Expected form: **أخي**

Why: Possession and iḍāfa. [[Arabic#^ar-Q0235|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%AE%D9%8A%20%D8%A7%D9%84%D8%A3%D9%83%D8%A8%D8%B1%20%D8%B7%D9%88%D9%8A%D9%84%20%D8%A7%D9%84%D9%82%D8%A7%D9%85%D8%A9%20%D8%AD%D9%82%D8%A7%D9%8B%D8%8C%20%D9%8A%D8%A8%D9%84%D8%BA%20%D8%AD%D9%88%D8%A7%D9%84%D9%8A%201.8%20%D9%85%D8%AA%D8%B1.)
^ar-Q0235-answer

**ar-Q0236** — أخي الأكبر طويل القامة حقاً، يبلغ حوالي 1.8 متر.

My elder brother is really tall, about 1.8m.

Expected form: **أخي**

Why: Possession and iḍāfa. [[Arabic#^ar-Q0236|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%AE%D9%8A%20%D8%A7%D9%84%D8%A3%D9%83%D8%A8%D8%B1%20%D8%B7%D9%88%D9%8A%D9%84%20%D8%A7%D9%84%D9%82%D8%A7%D9%85%D8%A9%20%D8%AD%D9%82%D8%A7%D9%8B%D8%8C%20%D9%8A%D8%A8%D9%84%D8%BA%20%D8%AD%D9%88%D8%A7%D9%84%D9%8A%201.8%20%D9%85%D8%AA%D8%B1.)
^ar-Q0236-answer

**ar-Q0237** — أخي صغير لكنه قوي.

My brother is small but strong.

Expected form: **أخي**

Why: Possession and iḍāfa. [[Arabic#^ar-Q0237|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%AE%D9%8A%20%D8%B5%D8%BA%D9%8A%D8%B1%20%D9%84%D9%83%D9%86%D9%87%20%D9%82%D9%88%D9%8A.)
^ar-Q0237-answer

**ar-Q0238** — أخي صغير لكنه قوي.

My brother is small but strong.

Why: Possession and iḍāfa. [[Arabic#^ar-Q0238|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%AE%D9%8A%20%D8%B5%D8%BA%D9%8A%D8%B1%20%D9%84%D9%83%D9%86%D9%87%20%D9%82%D9%88%D9%8A.)
^ar-Q0238-answer

**ar-Q0239** — أختي تسكن بالقرب من يوكوهاما.

My sister lives near Yokohama.

Why: Possession and iḍāfa. [[Arabic#^ar-Q0239|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%AE%D8%AA%D9%8A%20%D8%AA%D8%B3%D9%83%D9%86%20%D8%A8%D8%A7%D9%84%D9%82%D8%B1%D8%A8%20%D9%85%D9%86%20%D9%8A%D9%88%D9%83%D9%88%D9%87%D8%A7%D9%85%D8%A7.)
^ar-Q0239-answer

**ar-Q0240** — أختي تسكن بالقرب من يوكوهاما.

My sister lives near Yokohama.

Possessive suffixes attach to nouns. An iḍāfa noun chain expresses another possession relation; its first noun normally has neither the definite article nor tanwīn. Pronunciation differs by dialect and register.

Why: Possession and iḍāfa. [[Arabic#^ar-Q0240|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%AE%D8%AA%D9%8A%20%D8%AA%D8%B3%D9%83%D9%86%20%D8%A8%D8%A7%D9%84%D9%82%D8%B1%D8%A8%20%D9%85%D9%86%20%D9%8A%D9%88%D9%83%D9%88%D9%87%D8%A7%D9%85%D8%A7.)
^ar-Q0240-answer

**ar-Q0241** — بيت السيد جونسون بالقرب من بيتي.

Mr Johnson's house is next to my house.

Expected form: **بيتي**

Why: Possession and iḍāfa. [[Arabic#^ar-Q0241|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A8%D9%8A%D8%AA%20%D8%A7%D9%84%D8%B3%D9%8A%D8%AF%20%D8%AC%D9%88%D9%86%D8%B3%D9%88%D9%86%20%D8%A8%D8%A7%D9%84%D9%82%D8%B1%D8%A8%20%D9%85%D9%86%20%D8%A8%D9%8A%D8%AA%D9%8A.)
^ar-Q0241-answer

**ar-Q0242** — بيت السيد جونسون بالقرب من بيتي.

Mr Johnson's house is next to my house.

Expected form: **بيتي**

Why: Possession and iḍāfa. [[Arabic#^ar-Q0242|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A8%D9%8A%D8%AA%20%D8%A7%D9%84%D8%B3%D9%8A%D8%AF%20%D8%AC%D9%88%D9%86%D8%B3%D9%88%D9%86%20%D8%A8%D8%A7%D9%84%D9%82%D8%B1%D8%A8%20%D9%85%D9%86%20%D8%A8%D9%8A%D8%AA%D9%8A.)
^ar-Q0242-answer

**ar-Q0243** — اكتب اسمك كاملاً

Write your name in full.

Expected form: **اسمك**

Why: Possession and iḍāfa. [[Arabic#^ar-Q0243|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A7%D9%83%D8%AA%D8%A8%20%D8%A7%D8%B3%D9%85%D9%83%20%D9%83%D8%A7%D9%85%D9%84%D8%A7%D9%8B)
^ar-Q0243-answer

**ar-Q0244** — اكتب اسمك كاملاً

Write your name in full.

Why: Possession and iḍāfa. [[Arabic#^ar-Q0244|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A7%D9%83%D8%AA%D8%A8%20%D8%A7%D8%B3%D9%85%D9%83%20%D9%83%D8%A7%D9%85%D9%84%D8%A7%D9%8B)
^ar-Q0244-answer

**ar-Q0245** — تعارك توم مع أخي ماري فانكسر أنفه.

Tom got into a fight with Mary's brother and got his nose broken.

Why: Possession and iḍāfa. [[Arabic#^ar-Q0245|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%AA%D8%B9%D8%A7%D8%B1%D9%83%20%D8%AA%D9%88%D9%85%20%D9%85%D8%B9%20%D8%A3%D8%AE%D9%8A%20%D9%85%D8%A7%D8%B1%D9%8A%20%D9%81%D8%A7%D9%86%D9%83%D8%B3%D8%B1%20%D8%A3%D9%86%D9%81%D9%87.)
^ar-Q0245-answer

**ar-Q0246** — تعارك توم مع أخي ماري فانكسر أنفه.

Tom got into a fight with Mary's brother and got his nose broken.

Possessive suffixes attach to nouns. An iḍāfa noun chain expresses another possession relation; its first noun normally has neither the definite article nor tanwīn. Pronunciation differs by dialect and register.

Why: Possession and iḍāfa. [[Arabic#^ar-Q0246|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%AA%D8%B9%D8%A7%D8%B1%D9%83%20%D8%AA%D9%88%D9%85%20%D9%85%D8%B9%20%D8%A3%D8%AE%D9%8A%20%D9%85%D8%A7%D8%B1%D9%8A%20%D9%81%D8%A7%D9%86%D9%83%D8%B3%D8%B1%20%D8%A3%D9%86%D9%81%D9%87.)
^ar-Q0246-answer

**ar-Q0247** — ترتاد أختي الجامعة.

My sister goes to a university.

Expected form: **أختي**

Why: Possession and iḍāfa. [[Arabic#^ar-Q0247|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%AA%D8%B1%D8%AA%D8%A7%D8%AF%20%D8%A3%D8%AE%D8%AA%D9%8A%20%D8%A7%D9%84%D8%AC%D8%A7%D9%85%D8%B9%D8%A9.)
^ar-Q0247-answer

**ar-Q0248** — ترتاد أختي الجامعة.

My sister goes to a university.

Expected form: **أختي**

Why: Possession and iḍāfa. [[Arabic#^ar-Q0248|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%AA%D8%B1%D8%AA%D8%A7%D8%AF%20%D8%A3%D8%AE%D8%AA%D9%8A%20%D8%A7%D9%84%D8%AC%D8%A7%D9%85%D8%B9%D8%A9.)
^ar-Q0248-answer

**ar-Q0249** — أتتني وسألتني عن اسمي.

She came up to me and asked my name.

Expected form: **اسمي**

Why: Possession and iḍāfa. [[Arabic#^ar-Q0249|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%AA%D8%AA%D9%86%D9%8A%20%D9%88%D8%B3%D8%A3%D9%84%D8%AA%D9%86%D9%8A%20%D8%B9%D9%86%20%D8%A7%D8%B3%D9%85%D9%8A.)
^ar-Q0249-answer

**ar-Q0250** — أتتني وسألتني عن اسمي.

She came up to me and asked my name.

Why: Possession and iḍāfa. [[Arabic#^ar-Q0250|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%AA%D8%AA%D9%86%D9%8A%20%D9%88%D8%B3%D8%A3%D9%84%D8%AA%D9%86%D9%8A%20%D8%B9%D9%86%20%D8%A7%D8%B3%D9%85%D9%8A.)
^ar-Q0250-answer


### Answers 251–300

**ar-Q0251** — كان سامي يريد شخصا يعتني به.

Sami wanted someone to watch over him.

Why: Past kāna. [[Arabic#^ar-Q0251|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D8%A7%D9%86%20%D8%B3%D8%A7%D9%85%D9%8A%20%D9%8A%D8%B1%D9%8A%D8%AF%20%D8%B4%D8%AE%D8%B5%D8%A7%20%D9%8A%D8%B9%D8%AA%D9%86%D9%8A%20%D8%A8%D9%87.)
^ar-Q0251-answer

**ar-Q0252** — كان سامي يريد شخصا يعتني به.

Sami wanted someone to watch over him.

كان and its forms establish a past state and participate in other constructions. In fully inflected MSA, kāna affects the case pattern of a nominal predicate. Gender/person distinctions matter.

Why: Past kāna. [[Arabic#^ar-Q0252|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D8%A7%D9%86%20%D8%B3%D8%A7%D9%85%D9%8A%20%D9%8A%D8%B1%D9%8A%D8%AF%20%D8%B4%D8%AE%D8%B5%D8%A7%20%D9%8A%D8%B9%D8%AA%D9%86%D9%8A%20%D8%A8%D9%87.)
^ar-Q0252-answer

**ar-Q0253** — كان فاضل يتمنّى أن يكون ليده ما كان عند ليلى.

Fadil wanted what Layla had.

Expected form: **كان**

Why: Past kāna. [[Arabic#^ar-Q0253|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D8%A7%D9%86%20%D9%81%D8%A7%D8%B6%D9%84%20%D9%8A%D8%AA%D9%85%D9%86%D9%91%D9%89%20%D8%A3%D9%86%20%D9%8A%D9%83%D9%88%D9%86%20%D9%84%D9%8A%D8%AF%D9%87%20%D9%85%D8%A7%20%D9%83%D8%A7%D9%86%20%D8%B9%D9%86%D8%AF%20%D9%84%D9%8A%D9%84%D9%89.)
^ar-Q0253-answer

**ar-Q0254** — كان فاضل يتمنّى أن يكون ليده ما كان عند ليلى.

Fadil wanted what Layla had.

Expected form: **كان**

Why: Past kāna. [[Arabic#^ar-Q0254|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D8%A7%D9%86%20%D9%81%D8%A7%D8%B6%D9%84%20%D9%8A%D8%AA%D9%85%D9%86%D9%91%D9%89%20%D8%A3%D9%86%20%D9%8A%D9%83%D9%88%D9%86%20%D9%84%D9%8A%D8%AF%D9%87%20%D9%85%D8%A7%20%D9%83%D8%A7%D9%86%20%D8%B9%D9%86%D8%AF%20%D9%84%D9%8A%D9%84%D9%89.)
^ar-Q0254-answer

**ar-Q0255** — كان سامي يحبّ مساعدة أبي.

Sami liked helping Dad.

Expected form: **كان**

Why: Past kāna. [[Arabic#^ar-Q0255|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D8%A7%D9%86%20%D8%B3%D8%A7%D9%85%D9%8A%20%D9%8A%D8%AD%D8%A8%D9%91%20%D9%85%D8%B3%D8%A7%D8%B9%D8%AF%D8%A9%20%D8%A3%D8%A8%D9%8A.)
^ar-Q0255-answer

**ar-Q0256** — كان سامي يحبّ مساعدة أبي.

Sami liked helping Dad.

Why: Past kāna. [[Arabic#^ar-Q0256|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D8%A7%D9%86%20%D8%B3%D8%A7%D9%85%D9%8A%20%D9%8A%D8%AD%D8%A8%D9%91%20%D9%85%D8%B3%D8%A7%D8%B9%D8%AF%D8%A9%20%D8%A3%D8%A8%D9%8A.)
^ar-Q0256-answer

**ar-Q0257** — كان سامي يحدّق.

Sami was staring.

Why: Past kāna. [[Arabic#^ar-Q0257|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D8%A7%D9%86%20%D8%B3%D8%A7%D9%85%D9%8A%20%D9%8A%D8%AD%D8%AF%D9%91%D9%82.)
^ar-Q0257-answer

**ar-Q0258** — كان سامي يحدّق.

Sami was staring.

كان and its forms establish a past state and participate in other constructions. In fully inflected MSA, kāna affects the case pattern of a nominal predicate. Gender/person distinctions matter.

Why: Past kāna. [[Arabic#^ar-Q0258|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D8%A7%D9%86%20%D8%B3%D8%A7%D9%85%D9%8A%20%D9%8A%D8%AD%D8%AF%D9%91%D9%82.)
^ar-Q0258-answer

**ar-Q0259** — توم كان قلبه مكسور عندما مات كلبه

Tom was heartbroken when his dog died.

Expected form: **كان**

Why: Past kāna. [[Arabic#^ar-Q0259|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%AA%D9%88%D9%85%20%D9%83%D8%A7%D9%86%20%D9%82%D9%84%D8%A8%D9%87%20%D9%85%D9%83%D8%B3%D9%88%D8%B1%20%D8%B9%D9%86%D8%AF%D9%85%D8%A7%20%D9%85%D8%A7%D8%AA%20%D9%83%D9%84%D8%A8%D9%87)
^ar-Q0259-answer

**ar-Q0260** — توم كان قلبه مكسور عندما مات كلبه

Tom was heartbroken when his dog died.

Expected form: **كان**

Why: Past kāna. [[Arabic#^ar-Q0260|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%AA%D9%88%D9%85%20%D9%83%D8%A7%D9%86%20%D9%82%D9%84%D8%A8%D9%87%20%D9%85%D9%83%D8%B3%D9%88%D8%B1%20%D8%B9%D9%86%D8%AF%D9%85%D8%A7%20%D9%85%D8%A7%D8%AA%20%D9%83%D9%84%D8%A8%D9%87)
^ar-Q0260-answer

**ar-Q0261** — كنت هنا البارحة.

I came here yesterday.

Expected form: **كنت**

Why: Past kāna. [[Arabic#^ar-Q0261|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D9%86%D8%AA%20%D9%87%D9%86%D8%A7%20%D8%A7%D9%84%D8%A8%D8%A7%D8%B1%D8%AD%D8%A9.)
^ar-Q0261-answer

**ar-Q0262** — كنت هنا البارحة.

I came here yesterday.

Why: Past kāna. [[Arabic#^ar-Q0262|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D9%86%D8%AA%20%D9%87%D9%86%D8%A7%20%D8%A7%D9%84%D8%A8%D8%A7%D8%B1%D8%AD%D8%A9.)
^ar-Q0262-answer

**ar-Q0263** — كانت ليلى معزولة اجتماعيّا.

Layla was socially isolated.

Why: Past kāna. [[Arabic#^ar-Q0263|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D8%A7%D9%86%D8%AA%20%D9%84%D9%8A%D9%84%D9%89%20%D9%85%D8%B9%D8%B2%D9%88%D9%84%D8%A9%20%D8%A7%D8%AC%D8%AA%D9%85%D8%A7%D8%B9%D9%8A%D9%91%D8%A7.)
^ar-Q0263-answer

**ar-Q0264** — كانت ليلى معزولة اجتماعيّا.

Layla was socially isolated.

كان and its forms establish a past state and participate in other constructions. In fully inflected MSA, kāna affects the case pattern of a nominal predicate. Gender/person distinctions matter.

Why: Past kāna. [[Arabic#^ar-Q0264|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D8%A7%D9%86%D8%AA%20%D9%84%D9%8A%D9%84%D9%89%20%D9%85%D8%B9%D8%B2%D9%88%D9%84%D8%A9%20%D8%A7%D8%AC%D8%AA%D9%85%D8%A7%D8%B9%D9%8A%D9%91%D8%A7.)
^ar-Q0264-answer

**ar-Q0265** — ولما كنت شابا عملت في المجتمعات المحلية بمدينة شيكاغو حيث وجد الكثير من المسلمين في عقيدتهم روح الكرامة والسلام

As a young man, I worked in Chicago communities where many found dignity and peace in their Muslim faith.

Expected form: **كنت**

Why: Past kāna. [[Arabic#^ar-Q0265|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%88%D9%84%D9%85%D8%A7%20%D9%83%D9%86%D8%AA%20%D8%B4%D8%A7%D8%A8%D8%A7%20%D8%B9%D9%85%D9%84%D8%AA%20%D9%81%D9%8A%20%D8%A7%D9%84%D9%85%D8%AC%D8%AA%D9%85%D8%B9%D8%A7%D8%AA%20%D8%A7%D9%84%D9%85%D8%AD%D9%84%D9%8A%D8%A9%20%D8%A8%D9%85%D8%AF%D9%8A%D9%86%D8%A9%20%D8%B4%D9%8A%D9%83%D8%A7%D8%BA%D9%88%20%D8%AD%D9%8A%D8%AB%20%D9%88%D8%AC%D8%AF%20%D8%A7%D9%84%D9%83%D8%AB%D9%8A%D8%B1%20%D9%85%D9%86%20%D8%A7%D9%84%D9%85%D8%B3%D9%84%D9%85%D9%8A%D9%86%20%D9%81%D9%8A%20%D8%B9%D9%82%D9%8A%D8%AF%D8%AA%D9%87%D9%85%20%D8%B1%D9%88%D8%AD%20%D8%A7%D9%84%D9%83%D8%B1%D8%A7%D9%85%D8%A9%20%D9%88%D8%A7%D9%84%D8%B3%D9%84%D8%A7%D9%85)
^ar-Q0265-answer

**ar-Q0266** — ولما كنت شابا عملت في المجتمعات المحلية بمدينة شيكاغو حيث وجد الكثير من المسلمين في عقيدتهم روح الكرامة والسلام

As a young man, I worked in Chicago communities where many found dignity and peace in their Muslim faith.

Expected form: **كنت**

Why: Past kāna. [[Arabic#^ar-Q0266|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%88%D9%84%D9%85%D8%A7%20%D9%83%D9%86%D8%AA%20%D8%B4%D8%A7%D8%A8%D8%A7%20%D8%B9%D9%85%D9%84%D8%AA%20%D9%81%D9%8A%20%D8%A7%D9%84%D9%85%D8%AC%D8%AA%D9%85%D8%B9%D8%A7%D8%AA%20%D8%A7%D9%84%D9%85%D8%AD%D9%84%D9%8A%D8%A9%20%D8%A8%D9%85%D8%AF%D9%8A%D9%86%D8%A9%20%D8%B4%D9%8A%D9%83%D8%A7%D8%BA%D9%88%20%D8%AD%D9%8A%D8%AB%20%D9%88%D8%AC%D8%AF%20%D8%A7%D9%84%D9%83%D8%AB%D9%8A%D8%B1%20%D9%85%D9%86%20%D8%A7%D9%84%D9%85%D8%B3%D9%84%D9%85%D9%8A%D9%86%20%D9%81%D9%8A%20%D8%B9%D9%82%D9%8A%D8%AF%D8%AA%D9%87%D9%85%20%D8%B1%D9%88%D8%AD%20%D8%A7%D9%84%D9%83%D8%B1%D8%A7%D9%85%D8%A9%20%D9%88%D8%A7%D9%84%D8%B3%D9%84%D8%A7%D9%85)
^ar-Q0266-answer

**ar-Q0267** — كنتُ أريدُ أن أصبحَ قادرا على قراءة الشعر الأمازيغي بالأمازيغيّة.

I wanted to be able to read Berber poetry in Berber.

Expected form: **كنت**

Why: Past kāna. [[Arabic#^ar-Q0267|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D9%86%D8%AA%D9%8F%20%D8%A3%D8%B1%D9%8A%D8%AF%D9%8F%20%D8%A3%D9%86%20%D8%A3%D8%B5%D8%A8%D8%AD%D9%8E%20%D9%82%D8%A7%D8%AF%D8%B1%D8%A7%20%D8%B9%D9%84%D9%89%20%D9%82%D8%B1%D8%A7%D8%A1%D8%A9%20%D8%A7%D9%84%D8%B4%D8%B9%D8%B1%20%D8%A7%D9%84%D8%A3%D9%85%D8%A7%D8%B2%D9%8A%D8%BA%D9%8A%20%D8%A8%D8%A7%D9%84%D8%A3%D9%85%D8%A7%D8%B2%D9%8A%D8%BA%D9%8A%D9%91%D8%A9.)
^ar-Q0267-answer

**ar-Q0268** — كنتُ أريدُ أن أصبحَ قادرا على قراءة الشعر الأمازيغي بالأمازيغيّة.

I wanted to be able to read Berber poetry in Berber.

Why: Past kāna. [[Arabic#^ar-Q0268|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D9%86%D8%AA%D9%8F%20%D8%A3%D8%B1%D9%8A%D8%AF%D9%8F%20%D8%A3%D9%86%20%D8%A3%D8%B5%D8%A8%D8%AD%D9%8E%20%D9%82%D8%A7%D8%AF%D8%B1%D8%A7%20%D8%B9%D9%84%D9%89%20%D9%82%D8%B1%D8%A7%D8%A1%D8%A9%20%D8%A7%D9%84%D8%B4%D8%B9%D8%B1%20%D8%A7%D9%84%D8%A3%D9%85%D8%A7%D8%B2%D9%8A%D8%BA%D9%8A%20%D8%A8%D8%A7%D9%84%D8%A3%D9%85%D8%A7%D8%B2%D9%8A%D8%BA%D9%8A%D9%91%D8%A9.)
^ar-Q0268-answer

**ar-Q0269** — كان لدى سامي امرأة أخرى في حياته.

Sami had another woman in his life.

Why: Past kāna. [[Arabic#^ar-Q0269|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D8%A7%D9%86%20%D9%84%D8%AF%D9%89%20%D8%B3%D8%A7%D9%85%D9%8A%20%D8%A7%D9%85%D8%B1%D8%A3%D8%A9%20%D8%A3%D8%AE%D8%B1%D9%89%20%D9%81%D9%8A%20%D8%AD%D9%8A%D8%A7%D8%AA%D9%87.)
^ar-Q0269-answer

**ar-Q0270** — كان لدى سامي امرأة أخرى في حياته.

Sami had another woman in his life.

كان and its forms establish a past state and participate in other constructions. In fully inflected MSA, kāna affects the case pattern of a nominal predicate. Gender/person distinctions matter.

Why: Past kāna. [[Arabic#^ar-Q0270|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D8%A7%D9%86%20%D9%84%D8%AF%D9%89%20%D8%B3%D8%A7%D9%85%D9%8A%20%D8%A7%D9%85%D8%B1%D8%A3%D8%A9%20%D8%A3%D8%AE%D8%B1%D9%89%20%D9%81%D9%8A%20%D8%AD%D9%8A%D8%A7%D8%AA%D9%87.)
^ar-Q0270-answer

**ar-Q0271** — كانت على وشك أن تخرج.

She was about to go out.

Expected form: **كانت**

Why: Past kāna. [[Arabic#^ar-Q0271|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D8%A7%D9%86%D8%AA%20%D8%B9%D9%84%D9%89%20%D9%88%D8%B4%D9%83%20%D8%A3%D9%86%20%D8%AA%D8%AE%D8%B1%D8%AC.)
^ar-Q0271-answer

**ar-Q0272** — كانت على وشك أن تخرج.

She was about to go out.

Expected form: **كانت**

Why: Past kāna. [[Arabic#^ar-Q0272|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D8%A7%D9%86%D8%AA%20%D8%B9%D9%84%D9%89%20%D9%88%D8%B4%D9%83%20%D8%A3%D9%86%20%D8%AA%D8%AE%D8%B1%D8%AC.)
^ar-Q0272-answer

**ar-Q0273** — كان سامي أحمقا.

Sami was an idiot.

Expected form: **كان**

Why: Past kāna. [[Arabic#^ar-Q0273|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D8%A7%D9%86%20%D8%B3%D8%A7%D9%85%D9%8A%20%D8%A3%D8%AD%D9%85%D9%82%D8%A7.)
^ar-Q0273-answer

**ar-Q0274** — كان سامي أحمقا.

Sami was an idiot.

Why: Past kāna. [[Arabic#^ar-Q0274|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D8%A7%D9%86%20%D8%B3%D8%A7%D9%85%D9%8A%20%D8%A3%D8%AD%D9%85%D9%82%D8%A7.)
^ar-Q0274-answer

**ar-Q0275** — كان سامي يقتل جشعا.

Sami killed for greed.

Why: Past kāna. [[Arabic#^ar-Q0275|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D8%A7%D9%86%20%D8%B3%D8%A7%D9%85%D9%8A%20%D9%8A%D9%82%D8%AA%D9%84%20%D8%AC%D8%B4%D8%B9%D8%A7.)
^ar-Q0275-answer

**ar-Q0276** — كان سامي يقتل جشعا.

Sami killed for greed.

كان and its forms establish a past state and participate in other constructions. In fully inflected MSA, kāna affects the case pattern of a nominal predicate. Gender/person distinctions matter.

Why: Past kāna. [[Arabic#^ar-Q0276|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D8%A7%D9%86%20%D8%B3%D8%A7%D9%85%D9%8A%20%D9%8A%D9%82%D8%AA%D9%84%20%D8%AC%D8%B4%D8%B9%D8%A7.)
^ar-Q0276-answer

**ar-Q0277** — هل كنت تأكل الشّكلاطة؟

Have you been eating chocolate?

Expected form: **كنت**

Why: Past kāna. [[Arabic#^ar-Q0277|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D9%84%20%D9%83%D9%86%D8%AA%20%D8%AA%D8%A3%D9%83%D9%84%20%D8%A7%D9%84%D8%B4%D9%91%D9%83%D9%84%D8%A7%D8%B7%D8%A9%D8%9F)
^ar-Q0277-answer

**ar-Q0278** — هل كنت تأكل الشّكلاطة؟

Have you been eating chocolate?

Expected form: **كنت**

Why: Past kāna. [[Arabic#^ar-Q0278|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D9%84%20%D9%83%D9%86%D8%AA%20%D8%AA%D8%A3%D9%83%D9%84%20%D8%A7%D9%84%D8%B4%D9%91%D9%83%D9%84%D8%A7%D8%B7%D8%A9%D8%9F)
^ar-Q0278-answer

**ar-Q0279** — اكتشف سامي أين كانت تسكن ليلى.

Sami found out where Layla lived.

Expected form: **كانت**

Why: Past kāna. [[Arabic#^ar-Q0279|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A7%D9%83%D8%AA%D8%B4%D9%81%20%D8%B3%D8%A7%D9%85%D9%8A%20%D8%A3%D9%8A%D9%86%20%D9%83%D8%A7%D9%86%D8%AA%20%D8%AA%D8%B3%D9%83%D9%86%20%D9%84%D9%8A%D9%84%D9%89.)
^ar-Q0279-answer

**ar-Q0280** — اكتشف سامي أين كانت تسكن ليلى.

Sami found out where Layla lived.

Why: Past kāna. [[Arabic#^ar-Q0280|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A7%D9%83%D8%AA%D8%B4%D9%81%20%D8%B3%D8%A7%D9%85%D9%8A%20%D8%A3%D9%8A%D9%86%20%D9%83%D8%A7%D9%86%D8%AA%20%D8%AA%D8%B3%D9%83%D9%86%20%D9%84%D9%8A%D9%84%D9%89.)
^ar-Q0280-answer

**ar-Q0281** — ماري كانت فخورة بجمالها.

Mary was proud of her beauty.

Why: Past kāna. [[Arabic#^ar-Q0281|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D8%A7%D8%B1%D9%8A%20%D9%83%D8%A7%D9%86%D8%AA%20%D9%81%D8%AE%D9%88%D8%B1%D8%A9%20%D8%A8%D8%AC%D9%85%D8%A7%D9%84%D9%87%D8%A7.)
^ar-Q0281-answer

**ar-Q0282** — ماري كانت فخورة بجمالها.

Mary was proud of her beauty.

كان and its forms establish a past state and participate in other constructions. In fully inflected MSA, kāna affects the case pattern of a nominal predicate. Gender/person distinctions matter.

Why: Past kāna. [[Arabic#^ar-Q0282|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D8%A7%D8%B1%D9%8A%20%D9%83%D8%A7%D9%86%D8%AA%20%D9%81%D8%AE%D9%88%D8%B1%D8%A9%20%D8%A8%D8%AC%D9%85%D8%A7%D9%84%D9%87%D8%A7.)
^ar-Q0282-answer

**ar-Q0283** — كان من الممكن أن أرى كيلي، لو أنني وصلت مبكرا.

Had I arrived earlier, I could have seen Kelly.

Expected form: **كان**

Why: Past kāna. [[Arabic#^ar-Q0283|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D8%A7%D9%86%20%D9%85%D9%86%20%D8%A7%D9%84%D9%85%D9%85%D9%83%D9%86%20%D8%A3%D9%86%20%D8%A3%D8%B1%D9%89%20%D9%83%D9%8A%D9%84%D9%8A%D8%8C%20%D9%84%D9%88%20%D8%A3%D9%86%D9%86%D9%8A%20%D9%88%D8%B5%D9%84%D8%AA%20%D9%85%D8%A8%D9%83%D8%B1%D8%A7.)
^ar-Q0283-answer

**ar-Q0284** — كان من الممكن أن أرى كيلي، لو أنني وصلت مبكرا.

Had I arrived earlier, I could have seen Kelly.

Expected form: **كان**

Why: Past kāna. [[Arabic#^ar-Q0284|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D8%A7%D9%86%20%D9%85%D9%86%20%D8%A7%D9%84%D9%85%D9%85%D9%83%D9%86%20%D8%A3%D9%86%20%D8%A3%D8%B1%D9%89%20%D9%83%D9%8A%D9%84%D9%8A%D8%8C%20%D9%84%D9%88%20%D8%A3%D9%86%D9%86%D9%8A%20%D9%88%D8%B5%D9%84%D8%AA%20%D9%85%D8%A8%D9%83%D8%B1%D8%A7.)
^ar-Q0284-answer

**ar-Q0285** — كان مدرّسنا في العلوم.

He was our science teacher.

Expected form: **كان**

Why: Past kāna. [[Arabic#^ar-Q0285|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D8%A7%D9%86%20%D9%85%D8%AF%D8%B1%D9%91%D8%B3%D9%86%D8%A7%20%D9%81%D9%8A%20%D8%A7%D9%84%D8%B9%D9%84%D9%88%D9%85.)
^ar-Q0285-answer

**ar-Q0286** — كان مدرّسنا في العلوم.

He was our science teacher.

Why: Past kāna. [[Arabic#^ar-Q0286|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D8%A7%D9%86%20%D9%85%D8%AF%D8%B1%D9%91%D8%B3%D9%86%D8%A7%20%D9%81%D9%8A%20%D8%A7%D9%84%D8%B9%D9%84%D9%88%D9%85.)
^ar-Q0286-answer

**ar-Q0287** — كانت الحافلة مزدحمة جداً. تمنيت لو اخذت سيارة الأجرة.

The bus was very crowded. I wish I had taken a taxi.

Why: Past kāna. [[Arabic#^ar-Q0287|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D8%A7%D9%86%D8%AA%20%D8%A7%D9%84%D8%AD%D8%A7%D9%81%D9%84%D8%A9%20%D9%85%D8%B2%D8%AF%D8%AD%D9%85%D8%A9%20%D8%AC%D8%AF%D8%A7%D9%8B.%20%D8%AA%D9%85%D9%86%D9%8A%D8%AA%20%D9%84%D9%88%20%D8%A7%D8%AE%D8%B0%D8%AA%20%D8%B3%D9%8A%D8%A7%D8%B1%D8%A9%20%D8%A7%D9%84%D8%A3%D8%AC%D8%B1%D8%A9.)
^ar-Q0287-answer

**ar-Q0288** — كانت الحافلة مزدحمة جداً. تمنيت لو اخذت سيارة الأجرة.

The bus was very crowded. I wish I had taken a taxi.

كان and its forms establish a past state and participate in other constructions. In fully inflected MSA, kāna affects the case pattern of a nominal predicate. Gender/person distinctions matter.

Why: Past kāna. [[Arabic#^ar-Q0288|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D8%A7%D9%86%D8%AA%20%D8%A7%D9%84%D8%AD%D8%A7%D9%81%D9%84%D8%A9%20%D9%85%D8%B2%D8%AF%D8%AD%D9%85%D8%A9%20%D8%AC%D8%AF%D8%A7%D9%8B.%20%D8%AA%D9%85%D9%86%D9%8A%D8%AA%20%D9%84%D9%88%20%D8%A7%D8%AE%D8%B0%D8%AA%20%D8%B3%D9%8A%D8%A7%D8%B1%D8%A9%20%D8%A7%D9%84%D8%A3%D8%AC%D8%B1%D8%A9.)
^ar-Q0288-answer

**ar-Q0289** — كانت تمطر عند إقلاعنا، لكن، عندما وصلنا، كان الجو مشمسا.

It was raining when we left, but by the time we arrived, it was sunny.

Expected form: **كانت**

Why: Past kāna. [[Arabic#^ar-Q0289|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D8%A7%D9%86%D8%AA%20%D8%AA%D9%85%D8%B7%D8%B1%20%D8%B9%D9%86%D8%AF%20%D8%A5%D9%82%D9%84%D8%A7%D8%B9%D9%86%D8%A7%D8%8C%20%D9%84%D9%83%D9%86%D8%8C%20%D8%B9%D9%86%D8%AF%D9%85%D8%A7%20%D9%88%D8%B5%D9%84%D9%86%D8%A7%D8%8C%20%D9%83%D8%A7%D9%86%20%D8%A7%D9%84%D8%AC%D9%88%20%D9%85%D8%B4%D9%85%D8%B3%D8%A7.)
^ar-Q0289-answer

**ar-Q0290** — كانت تمطر عند إقلاعنا، لكن، عندما وصلنا، كان الجو مشمسا.

It was raining when we left, but by the time we arrived, it was sunny.

Expected form: **كانت**

Why: Past kāna. [[Arabic#^ar-Q0290|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D8%A7%D9%86%D8%AA%20%D8%AA%D9%85%D8%B7%D8%B1%20%D8%B9%D9%86%D8%AF%20%D8%A5%D9%82%D9%84%D8%A7%D8%B9%D9%86%D8%A7%D8%8C%20%D9%84%D9%83%D9%86%D8%8C%20%D8%B9%D9%86%D8%AF%D9%85%D8%A7%20%D9%88%D8%B5%D9%84%D9%86%D8%A7%D8%8C%20%D9%83%D8%A7%D9%86%20%D8%A7%D9%84%D8%AC%D9%88%20%D9%85%D8%B4%D9%85%D8%B3%D8%A7.)
^ar-Q0290-answer

**ar-Q0291** — ياني كانَ قذِر للغاية لدرجة أن بعض الأشخاص ظنّوه مجنوناً.

Yanni was so scruffy that people thought he was crazy.

Expected form: **كان**

Why: Past kāna. [[Arabic#^ar-Q0291|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%8A%D8%A7%D9%86%D9%8A%20%D9%83%D8%A7%D9%86%D9%8E%20%D9%82%D8%B0%D9%90%D8%B1%20%D9%84%D9%84%D8%BA%D8%A7%D9%8A%D8%A9%20%D9%84%D8%AF%D8%B1%D8%AC%D8%A9%20%D8%A3%D9%86%20%D8%A8%D8%B9%D8%B6%20%D8%A7%D9%84%D8%A3%D8%B4%D8%AE%D8%A7%D8%B5%20%D8%B8%D9%86%D9%91%D9%88%D9%87%20%D9%85%D8%AC%D9%86%D9%88%D9%86%D8%A7%D9%8B.)
^ar-Q0291-answer

**ar-Q0292** — ياني كانَ قذِر للغاية لدرجة أن بعض الأشخاص ظنّوه مجنوناً.

Yanni was so scruffy that people thought he was crazy.

Why: Past kāna. [[Arabic#^ar-Q0292|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%8A%D8%A7%D9%86%D9%8A%20%D9%83%D8%A7%D9%86%D9%8E%20%D9%82%D8%B0%D9%90%D8%B1%20%D9%84%D9%84%D8%BA%D8%A7%D9%8A%D8%A9%20%D9%84%D8%AF%D8%B1%D8%AC%D8%A9%20%D8%A3%D9%86%20%D8%A8%D8%B9%D8%B6%20%D8%A7%D9%84%D8%A3%D8%B4%D8%AE%D8%A7%D8%B5%20%D8%B8%D9%86%D9%91%D9%88%D9%87%20%D9%85%D8%AC%D9%86%D9%88%D9%86%D8%A7%D9%8B.)
^ar-Q0292-answer

**ar-Q0293** — كان سامي يعطس.

Sami was sneezing.

Why: Past kāna. [[Arabic#^ar-Q0293|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D8%A7%D9%86%20%D8%B3%D8%A7%D9%85%D9%8A%20%D9%8A%D8%B9%D8%B7%D8%B3.)
^ar-Q0293-answer

**ar-Q0294** — كان سامي يعطس.

Sami was sneezing.

كان and its forms establish a past state and participate in other constructions. In fully inflected MSA, kāna affects the case pattern of a nominal predicate. Gender/person distinctions matter.

Why: Past kāna. [[Arabic#^ar-Q0294|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D8%A7%D9%86%20%D8%B3%D8%A7%D9%85%D9%8A%20%D9%8A%D8%B9%D8%B7%D8%B3.)
^ar-Q0294-answer

**ar-Q0295** — كانت فخورة للغاية بوالدها.

She was very proud of her father.

Expected form: **كانت**

Why: Past kāna. [[Arabic#^ar-Q0295|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D8%A7%D9%86%D8%AA%20%D9%81%D8%AE%D9%88%D8%B1%D8%A9%20%D9%84%D9%84%D8%BA%D8%A7%D9%8A%D8%A9%20%D8%A8%D9%88%D8%A7%D9%84%D8%AF%D9%87%D8%A7.)
^ar-Q0295-answer

**ar-Q0296** — كانت فخورة للغاية بوالدها.

She was very proud of her father.

Expected form: **كانت**

Why: Past kāna. [[Arabic#^ar-Q0296|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D8%A7%D9%86%D8%AA%20%D9%81%D8%AE%D9%88%D8%B1%D8%A9%20%D9%84%D9%84%D8%BA%D8%A7%D9%8A%D8%A9%20%D8%A8%D9%88%D8%A7%D9%84%D8%AF%D9%87%D8%A7.)
^ar-Q0296-answer

**ar-Q0297** — كان سامي ينتظر اتّصال ليلى.

Sami waited for Layla's call.

Expected form: **كان**

Why: Past kāna. [[Arabic#^ar-Q0297|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D8%A7%D9%86%20%D8%B3%D8%A7%D9%85%D9%8A%20%D9%8A%D9%86%D8%AA%D8%B8%D8%B1%20%D8%A7%D8%AA%D9%91%D8%B5%D8%A7%D9%84%20%D9%84%D9%8A%D9%84%D9%89.)
^ar-Q0297-answer

**ar-Q0298** — كان سامي ينتظر اتّصال ليلى.

Sami waited for Layla's call.

Why: Past kāna. [[Arabic#^ar-Q0298|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D8%A7%D9%86%20%D8%B3%D8%A7%D9%85%D9%8A%20%D9%8A%D9%86%D8%AA%D8%B8%D8%B1%20%D8%A7%D8%AA%D9%91%D8%B5%D8%A7%D9%84%20%D9%84%D9%8A%D9%84%D9%89.)
^ar-Q0298-answer

**ar-Q0299** — كان سامي يحبّ حياة الحفلات.

Sami liked the party life.

Why: Past kāna. [[Arabic#^ar-Q0299|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D8%A7%D9%86%20%D8%B3%D8%A7%D9%85%D9%8A%20%D9%8A%D8%AD%D8%A8%D9%91%20%D8%AD%D9%8A%D8%A7%D8%A9%20%D8%A7%D9%84%D8%AD%D9%81%D9%84%D8%A7%D8%AA.)
^ar-Q0299-answer

**ar-Q0300** — كان سامي يحبّ حياة الحفلات.

Sami liked the party life.

كان and its forms establish a past state and participate in other constructions. In fully inflected MSA, kāna affects the case pattern of a nominal predicate. Gender/person distinctions matter.

Why: Past kāna. [[Arabic#^ar-Q0300|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D8%A7%D9%86%20%D8%B3%D8%A7%D9%85%D9%8A%20%D9%8A%D8%AD%D8%A8%D9%91%20%D8%AD%D9%8A%D8%A7%D8%A9%20%D8%A7%D9%84%D8%AD%D9%81%D9%84%D8%A7%D8%AA.)
^ar-Q0300-answer


### Answers 301–350

**ar-Q0301** — توم ليس وحيداً الآن.

Tom isn't lonely now.

Expected form: **ليس**

Why: Negation lā and laysa. [[Arabic#^ar-Q0301|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%AA%D9%88%D9%85%20%D9%84%D9%8A%D8%B3%20%D9%88%D8%AD%D9%8A%D8%AF%D8%A7%D9%8B%20%D8%A7%D9%84%D8%A2%D9%86.)
^ar-Q0301-answer

**ar-Q0302** — توم ليس وحيداً الآن.

Tom isn't lonely now.

Expected form: **ليس**

Why: Negation lā and laysa. [[Arabic#^ar-Q0302|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%AA%D9%88%D9%85%20%D9%84%D9%8A%D8%B3%20%D9%88%D8%AD%D9%8A%D8%AF%D8%A7%D9%8B%20%D8%A7%D9%84%D8%A2%D9%86.)
^ar-Q0302-answer

**ar-Q0303** — لا أريد وظيفة بدوام كامل.

I don't want a full-time job.

Expected form: **لا**

Why: Negation lā and laysa. [[Arabic#^ar-Q0303|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D8%A7%20%D8%A3%D8%B1%D9%8A%D8%AF%20%D9%88%D8%B8%D9%8A%D9%81%D8%A9%20%D8%A8%D8%AF%D9%88%D8%A7%D9%85%20%D9%83%D8%A7%D9%85%D9%84.)
^ar-Q0303-answer

**ar-Q0304** — لا أريد وظيفة بدوام كامل.

I don't want a full-time job.

Why: Negation lā and laysa. [[Arabic#^ar-Q0304|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D8%A7%20%D8%A3%D8%B1%D9%8A%D8%AF%20%D9%88%D8%B8%D9%8A%D9%81%D8%A9%20%D8%A8%D8%AF%D9%88%D8%A7%D9%85%20%D9%83%D8%A7%D9%85%D9%84.)
^ar-Q0304-answer

**ar-Q0305** — لا وقت للشرح.

There is no time for explanation.

Why: Negation lā and laysa. [[Arabic#^ar-Q0305|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D8%A7%20%D9%88%D9%82%D8%AA%20%D9%84%D9%84%D8%B4%D8%B1%D8%AD.)
^ar-Q0305-answer

**ar-Q0306** — لا وقت للشرح.

There is no time for explanation.

لا negates various verbal/general constructions; ليس negates many nominal predicates. Their grammar is not identical. Dialects use different combinations and should be practised in their own section.

Why: Negation lā and laysa. [[Arabic#^ar-Q0306|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D8%A7%20%D9%88%D9%82%D8%AA%20%D9%84%D9%84%D8%B4%D8%B1%D8%AD.)
^ar-Q0306-answer

**ar-Q0307** — لا تزال ليلى تعمل من أجل استعادة قدرتها على الكلام.

Layla is still working to regain her ability to speak.

Expected form: **لا**

Why: Negation lā and laysa. [[Arabic#^ar-Q0307|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D8%A7%20%D8%AA%D8%B2%D8%A7%D9%84%20%D9%84%D9%8A%D9%84%D9%89%20%D8%AA%D8%B9%D9%85%D9%84%20%D9%85%D9%86%20%D8%A3%D8%AC%D9%84%20%D8%A7%D8%B3%D8%AA%D8%B9%D8%A7%D8%AF%D8%A9%20%D9%82%D8%AF%D8%B1%D8%AA%D9%87%D8%A7%20%D8%B9%D9%84%D9%89%20%D8%A7%D9%84%D9%83%D9%84%D8%A7%D9%85.)
^ar-Q0307-answer

**ar-Q0308** — لا تزال ليلى تعمل من أجل استعادة قدرتها على الكلام.

Layla is still working to regain her ability to speak.

Expected form: **لا**

Why: Negation lā and laysa. [[Arabic#^ar-Q0308|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D8%A7%20%D8%AA%D8%B2%D8%A7%D9%84%20%D9%84%D9%8A%D9%84%D9%89%20%D8%AA%D8%B9%D9%85%D9%84%20%D9%85%D9%86%20%D8%A3%D8%AC%D9%84%20%D8%A7%D8%B3%D8%AA%D8%B9%D8%A7%D8%AF%D8%A9%20%D9%82%D8%AF%D8%B1%D8%AA%D9%87%D8%A7%20%D8%B9%D9%84%D9%89%20%D8%A7%D9%84%D9%83%D9%84%D8%A7%D9%85.)
^ar-Q0308-answer

**ar-Q0309** — بقدر ما لا تمثّل المملكة العربيّة السّعوديّة المسلمين، فإنّ إسرائيل لا تمثّل و لا ينبغي أن تمثّل الدّين اليهودي.

As much as Saudi Arabia is not Islam and doesn't represent Muslims, Israel is neither the Jewish people nor does it or should it represent the Jewish religion.

Expected form: **لا**

Why: Negation lā and laysa. [[Arabic#^ar-Q0309|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A8%D9%82%D8%AF%D8%B1%20%D9%85%D8%A7%20%D9%84%D8%A7%20%D8%AA%D9%85%D8%AB%D9%91%D9%84%20%D8%A7%D9%84%D9%85%D9%85%D9%84%D9%83%D8%A9%20%D8%A7%D9%84%D8%B9%D8%B1%D8%A8%D9%8A%D9%91%D8%A9%20%D8%A7%D9%84%D8%B3%D9%91%D8%B9%D9%88%D8%AF%D9%8A%D9%91%D8%A9%20%D8%A7%D9%84%D9%85%D8%B3%D9%84%D9%85%D9%8A%D9%86%D8%8C%20%D9%81%D8%A5%D9%86%D9%91%20%D8%A5%D8%B3%D8%B1%D8%A7%D8%A6%D9%8A%D9%84%20%D9%84%D8%A7%20%D8%AA%D9%85%D8%AB%D9%91%D9%84%20%D9%88%20%D9%84%D8%A7%20%D9%8A%D9%86%D8%A8%D8%BA%D9%8A%20%D8%A3%D9%86%20%D8%AA%D9%85%D8%AB%D9%91%D9%84%20%D8%A7%D9%84%D8%AF%D9%91%D9%8A%D9%86%20%D8%A7%D9%84%D9%8A%D9%87%D9%88%D8%AF%D9%8A.)
^ar-Q0309-answer

**ar-Q0310** — بقدر ما لا تمثّل المملكة العربيّة السّعوديّة المسلمين، فإنّ إسرائيل لا تمثّل و لا ينبغي أن تمثّل الدّين اليهودي.

As much as Saudi Arabia is not Islam and doesn't represent Muslims, Israel is neither the Jewish people nor does it or should it represent the Jewish religion.

Why: Negation lā and laysa. [[Arabic#^ar-Q0310|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A8%D9%82%D8%AF%D8%B1%20%D9%85%D8%A7%20%D9%84%D8%A7%20%D8%AA%D9%85%D8%AB%D9%91%D9%84%20%D8%A7%D9%84%D9%85%D9%85%D9%84%D9%83%D8%A9%20%D8%A7%D9%84%D8%B9%D8%B1%D8%A8%D9%8A%D9%91%D8%A9%20%D8%A7%D9%84%D8%B3%D9%91%D8%B9%D9%88%D8%AF%D9%8A%D9%91%D8%A9%20%D8%A7%D9%84%D9%85%D8%B3%D9%84%D9%85%D9%8A%D9%86%D8%8C%20%D9%81%D8%A5%D9%86%D9%91%20%D8%A5%D8%B3%D8%B1%D8%A7%D8%A6%D9%8A%D9%84%20%D9%84%D8%A7%20%D8%AA%D9%85%D8%AB%D9%91%D9%84%20%D9%88%20%D9%84%D8%A7%20%D9%8A%D9%86%D8%A8%D8%BA%D9%8A%20%D8%A3%D9%86%20%D8%AA%D9%85%D8%AB%D9%91%D9%84%20%D8%A7%D9%84%D8%AF%D9%91%D9%8A%D9%86%20%D8%A7%D9%84%D9%8A%D9%87%D9%88%D8%AF%D9%8A.)
^ar-Q0310-answer

**ar-Q0311** — لا أستطيع تذكر اللحظة التي وضع زوجي يديه على عنقي و ضمّني بقوة.

I can't remember the moment my husband put his hands around my neck and hugged me tightly.

Why: Negation lā and laysa. [[Arabic#^ar-Q0311|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D8%A7%20%D8%A3%D8%B3%D8%AA%D8%B7%D9%8A%D8%B9%20%D8%AA%D8%B0%D9%83%D8%B1%20%D8%A7%D9%84%D9%84%D8%AD%D8%B8%D8%A9%20%D8%A7%D9%84%D8%AA%D9%8A%20%D9%88%D8%B6%D8%B9%20%D8%B2%D9%88%D8%AC%D9%8A%20%D9%8A%D8%AF%D9%8A%D9%87%20%D8%B9%D9%84%D9%89%20%D8%B9%D9%86%D9%82%D9%8A%20%D9%88%20%D8%B6%D9%85%D9%91%D9%86%D9%8A%20%D8%A8%D9%82%D9%88%D8%A9.)
^ar-Q0311-answer

**ar-Q0312** — لا أستطيع تذكر اللحظة التي وضع زوجي يديه على عنقي و ضمّني بقوة.

I can't remember the moment my husband put his hands around my neck and hugged me tightly.

لا negates various verbal/general constructions; ليس negates many nominal predicates. Their grammar is not identical. Dialects use different combinations and should be practised in their own section.

Why: Negation lā and laysa. [[Arabic#^ar-Q0312|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D8%A7%20%D8%A3%D8%B3%D8%AA%D8%B7%D9%8A%D8%B9%20%D8%AA%D8%B0%D9%83%D8%B1%20%D8%A7%D9%84%D9%84%D8%AD%D8%B8%D8%A9%20%D8%A7%D9%84%D8%AA%D9%8A%20%D9%88%D8%B6%D8%B9%20%D8%B2%D9%88%D8%AC%D9%8A%20%D9%8A%D8%AF%D9%8A%D9%87%20%D8%B9%D9%84%D9%89%20%D8%B9%D9%86%D9%82%D9%8A%20%D9%88%20%D8%B6%D9%85%D9%91%D9%86%D9%8A%20%D8%A8%D9%82%D9%88%D8%A9.)
^ar-Q0312-answer

**ar-Q0313** — لا أحد أعرفهُ يرتدي ربطة العُنُق بعد الآن.

No one I know wears a tie anymore.

Expected form: **لا**

Why: Negation lā and laysa. [[Arabic#^ar-Q0313|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D8%A7%20%D8%A3%D8%AD%D8%AF%20%D8%A3%D8%B9%D8%B1%D9%81%D9%87%D9%8F%20%D9%8A%D8%B1%D8%AA%D8%AF%D9%8A%20%D8%B1%D8%A8%D8%B7%D8%A9%20%D8%A7%D9%84%D8%B9%D9%8F%D9%86%D9%8F%D9%82%20%D8%A8%D8%B9%D8%AF%20%D8%A7%D9%84%D8%A2%D9%86.)
^ar-Q0313-answer

**ar-Q0314** — لا أحد أعرفهُ يرتدي ربطة العُنُق بعد الآن.

No one I know wears a tie anymore.

Expected form: **لا**

Why: Negation lā and laysa. [[Arabic#^ar-Q0314|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D8%A7%20%D8%A3%D8%AD%D8%AF%20%D8%A3%D8%B9%D8%B1%D9%81%D9%87%D9%8F%20%D9%8A%D8%B1%D8%AA%D8%AF%D9%8A%20%D8%B1%D8%A8%D8%B7%D8%A9%20%D8%A7%D9%84%D8%B9%D9%8F%D9%86%D9%8F%D9%82%20%D8%A8%D8%B9%D8%AF%20%D8%A7%D9%84%D8%A2%D9%86.)
^ar-Q0314-answer

**ar-Q0315** — المكتب لي و ليس له.

This office belongs to me, not him.

Expected form: **ليس**

Why: Negation lā and laysa. [[Arabic#^ar-Q0315|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A7%D9%84%D9%85%D9%83%D8%AA%D8%A8%20%D9%84%D9%8A%20%D9%88%20%D9%84%D9%8A%D8%B3%20%D9%84%D9%87.)
^ar-Q0315-answer

**ar-Q0316** — المكتب لي و ليس له.

This office belongs to me, not him.

Why: Negation lā and laysa. [[Arabic#^ar-Q0316|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A7%D9%84%D9%85%D9%83%D8%AA%D8%A8%20%D9%84%D9%8A%20%D9%88%20%D9%84%D9%8A%D8%B3%20%D9%84%D9%87.)
^ar-Q0316-answer

**ar-Q0317** — "ديما؟" سأل الرجل الذي أسماه ديما "الصائب". "لا أعرف أحدًا باسم ديما. آسف. أظنك قد حصلت على الرقم الخطأ".

"Dima?" the man that Dima called "Al-Sayib" asked. "I don't know any Dima. Sorry. I think you've got the wrong number."

Why: Negation lā and laysa. [[Arabic#^ar-Q0317|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%22%D8%AF%D9%8A%D9%85%D8%A7%D8%9F%22%20%D8%B3%D8%A3%D9%84%20%D8%A7%D9%84%D8%B1%D8%AC%D9%84%20%D8%A7%D9%84%D8%B0%D9%8A%20%D8%A3%D8%B3%D9%85%D8%A7%D9%87%20%D8%AF%D9%8A%D9%85%D8%A7%20%22%D8%A7%D9%84%D8%B5%D8%A7%D8%A6%D8%A8%22.%20%22%D9%84%D8%A7%20%D8%A3%D8%B9%D8%B1%D9%81%20%D8%A3%D8%AD%D8%AF%D9%8B%D8%A7%20%D8%A8%D8%A7%D8%B3%D9%85%20%D8%AF%D9%8A%D9%85%D8%A7.%20%D8%A2%D8%B3%D9%81.%20%D8%A3%D8%B8%D9%86%D9%83%20%D9%82%D8%AF%20%D8%AD%D8%B5%D9%84%D8%AA%20%D8%B9%D9%84%D9%89%20%D8%A7%D9%84%D8%B1%D9%82%D9%85%20%D8%A7%D9%84%D8%AE%D8%B7%D8%A3%22.)
^ar-Q0317-answer

**ar-Q0318** — "ديما؟" سأل الرجل الذي أسماه ديما "الصائب". "لا أعرف أحدًا باسم ديما. آسف. أظنك قد حصلت على الرقم الخطأ".

"Dima?" the man that Dima called "Al-Sayib" asked. "I don't know any Dima. Sorry. I think you've got the wrong number."

لا negates various verbal/general constructions; ليس negates many nominal predicates. Their grammar is not identical. Dialects use different combinations and should be practised in their own section.

Why: Negation lā and laysa. [[Arabic#^ar-Q0318|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%22%D8%AF%D9%8A%D9%85%D8%A7%D8%9F%22%20%D8%B3%D8%A3%D9%84%20%D8%A7%D9%84%D8%B1%D8%AC%D9%84%20%D8%A7%D9%84%D8%B0%D9%8A%20%D8%A3%D8%B3%D9%85%D8%A7%D9%87%20%D8%AF%D9%8A%D9%85%D8%A7%20%22%D8%A7%D9%84%D8%B5%D8%A7%D8%A6%D8%A8%22.%20%22%D9%84%D8%A7%20%D8%A3%D8%B9%D8%B1%D9%81%20%D8%A3%D8%AD%D8%AF%D9%8B%D8%A7%20%D8%A8%D8%A7%D8%B3%D9%85%20%D8%AF%D9%8A%D9%85%D8%A7.%20%D8%A2%D8%B3%D9%81.%20%D8%A3%D8%B8%D9%86%D9%83%20%D9%82%D8%AF%20%D8%AD%D8%B5%D9%84%D8%AA%20%D8%B9%D9%84%D9%89%20%D8%A7%D9%84%D8%B1%D9%82%D9%85%20%D8%A7%D9%84%D8%AE%D8%B7%D8%A3%22.)
^ar-Q0318-answer

**ar-Q0319** — هل أنت من كوكب لا تعيش فيه إلا النساء؟

Are you from a planet solely populated by women?

Expected form: **لا**

Why: Negation lā and laysa. [[Arabic#^ar-Q0319|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D9%84%20%D8%A3%D9%86%D8%AA%20%D9%85%D9%86%20%D9%83%D9%88%D9%83%D8%A8%20%D9%84%D8%A7%20%D8%AA%D8%B9%D9%8A%D8%B4%20%D9%81%D9%8A%D9%87%20%D8%A5%D9%84%D8%A7%20%D8%A7%D9%84%D9%86%D8%B3%D8%A7%D8%A1%D8%9F)
^ar-Q0319-answer

**ar-Q0320** — هل أنت من كوكب لا تعيش فيه إلا النساء؟

Are you from a planet solely populated by women?

Expected form: **لا**

Why: Negation lā and laysa. [[Arabic#^ar-Q0320|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D9%84%20%D8%A3%D9%86%D8%AA%20%D9%85%D9%86%20%D9%83%D9%88%D9%83%D8%A8%20%D9%84%D8%A7%20%D8%AA%D8%B9%D9%8A%D8%B4%20%D9%81%D9%8A%D9%87%20%D8%A5%D9%84%D8%A7%20%D8%A7%D9%84%D9%86%D8%B3%D8%A7%D8%A1%D8%9F)
^ar-Q0320-answer

**ar-Q0321** — لا أستطيع تحمّل نفاقها.

I can't stand her hypocrisy.

Expected form: **لا**

Why: Negation lā and laysa. [[Arabic#^ar-Q0321|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D8%A7%20%D8%A3%D8%B3%D8%AA%D8%B7%D9%8A%D8%B9%20%D8%AA%D8%AD%D9%85%D9%91%D9%84%20%D9%86%D9%81%D8%A7%D9%82%D9%87%D8%A7.)
^ar-Q0321-answer

**ar-Q0322** — لا أستطيع تحمّل نفاقها.

I can't stand her hypocrisy.

Why: Negation lā and laysa. [[Arabic#^ar-Q0322|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D8%A7%20%D8%A3%D8%B3%D8%AA%D8%B7%D9%8A%D8%B9%20%D8%AA%D8%AD%D9%85%D9%91%D9%84%20%D9%86%D9%81%D8%A7%D9%82%D9%87%D8%A7.)
^ar-Q0322-answer

**ar-Q0323** — لا أستطيع قبول هديتِكَ.

I can't accept your gift.

Why: Negation lā and laysa. [[Arabic#^ar-Q0323|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D8%A7%20%D8%A3%D8%B3%D8%AA%D8%B7%D9%8A%D8%B9%20%D9%82%D8%A8%D9%88%D9%84%20%D9%87%D8%AF%D9%8A%D8%AA%D9%90%D9%83%D9%8E.)
^ar-Q0323-answer

**ar-Q0324** — لا أستطيع قبول هديتِكَ.

I can't accept your gift.

لا negates various verbal/general constructions; ليس negates many nominal predicates. Their grammar is not identical. Dialects use different combinations and should be practised in their own section.

Why: Negation lā and laysa. [[Arabic#^ar-Q0324|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D8%A7%20%D8%A3%D8%B3%D8%AA%D8%B7%D9%8A%D8%B9%20%D9%82%D8%A8%D9%88%D9%84%20%D9%87%D8%AF%D9%8A%D8%AA%D9%90%D9%83%D9%8E.)
^ar-Q0324-answer

**ar-Q0325** — لا يمكنني أن أقبل هديّتك.

I cannot accept your gift.

Expected form: **لا**

Why: Negation lā and laysa. [[Arabic#^ar-Q0325|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D8%A7%20%D9%8A%D9%85%D9%83%D9%86%D9%86%D9%8A%20%D8%A3%D9%86%20%D8%A3%D9%82%D8%A8%D9%84%20%D9%87%D8%AF%D9%8A%D9%91%D8%AA%D9%83.)
^ar-Q0325-answer

**ar-Q0326** — لا يمكنني أن أقبل هديّتك.

I cannot accept your gift.

Expected form: **لا**

Why: Negation lā and laysa. [[Arabic#^ar-Q0326|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D8%A7%20%D9%8A%D9%85%D9%83%D9%86%D9%86%D9%8A%20%D8%A3%D9%86%20%D8%A3%D9%82%D8%A8%D9%84%20%D9%87%D8%AF%D9%8A%D9%91%D8%AA%D9%83.)
^ar-Q0326-answer

**ar-Q0327** — لم لا نفعل ذلك؟

Why wouldn't we do that?

Expected form: **لا**

Why: Negation lā and laysa. [[Arabic#^ar-Q0327|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%85%20%D9%84%D8%A7%20%D9%86%D9%81%D8%B9%D9%84%20%D8%B0%D9%84%D9%83%D8%9F)
^ar-Q0327-answer

**ar-Q0328** — لم لا نفعل ذلك؟

Why wouldn't we do that?

Why: Negation lā and laysa. [[Arabic#^ar-Q0328|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%85%20%D9%84%D8%A7%20%D9%86%D9%81%D8%B9%D9%84%20%D8%B0%D9%84%D9%83%D8%9F)
^ar-Q0328-answer

**ar-Q0329** — لا شكّ أنّ عائلة سامي مشتاقة إليه.

Sami's family must be missing him.

Why: Negation lā and laysa. [[Arabic#^ar-Q0329|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D8%A7%20%D8%B4%D9%83%D9%91%20%D8%A3%D9%86%D9%91%20%D8%B9%D8%A7%D8%A6%D9%84%D8%A9%20%D8%B3%D8%A7%D9%85%D9%8A%20%D9%85%D8%B4%D8%AA%D8%A7%D9%82%D8%A9%20%D8%A5%D9%84%D9%8A%D9%87.)
^ar-Q0329-answer

**ar-Q0330** — لا شكّ أنّ عائلة سامي مشتاقة إليه.

Sami's family must be missing him.

لا negates various verbal/general constructions; ليس negates many nominal predicates. Their grammar is not identical. Dialects use different combinations and should be practised in their own section.

Why: Negation lā and laysa. [[Arabic#^ar-Q0330|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D8%A7%20%D8%B4%D9%83%D9%91%20%D8%A3%D9%86%D9%91%20%D8%B9%D8%A7%D8%A6%D9%84%D8%A9%20%D8%B3%D8%A7%D9%85%D9%8A%20%D9%85%D8%B4%D8%AA%D8%A7%D9%82%D8%A9%20%D8%A5%D9%84%D9%8A%D9%87.)
^ar-Q0330-answer

**ar-Q0331** — الحجارة لا تطفو.

A stone does not float.

Expected form: **لا**

Why: Negation lā and laysa. [[Arabic#^ar-Q0331|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A7%D9%84%D8%AD%D8%AC%D8%A7%D8%B1%D8%A9%20%D9%84%D8%A7%20%D8%AA%D8%B7%D9%81%D9%88.)
^ar-Q0331-answer

**ar-Q0332** — الحجارة لا تطفو.

A stone does not float.

Expected form: **لا**

Why: Negation lā and laysa. [[Arabic#^ar-Q0332|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A7%D9%84%D8%AD%D8%AC%D8%A7%D8%B1%D8%A9%20%D9%84%D8%A7%20%D8%AA%D8%B7%D9%81%D9%88.)
^ar-Q0332-answer

**ar-Q0333** — هناك الكثير من الأمور التي لا تعرفها عن شخصيتي.

There are a lot of things you don't know about my personality.

Expected form: **لا**

Why: Negation lā and laysa. [[Arabic#^ar-Q0333|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D9%86%D8%A7%D9%83%20%D8%A7%D9%84%D9%83%D8%AB%D9%8A%D8%B1%20%D9%85%D9%86%20%D8%A7%D9%84%D8%A3%D9%85%D9%88%D8%B1%20%D8%A7%D9%84%D8%AA%D9%8A%20%D9%84%D8%A7%20%D8%AA%D8%B9%D8%B1%D9%81%D9%87%D8%A7%20%D8%B9%D9%86%20%D8%B4%D8%AE%D8%B5%D9%8A%D8%AA%D9%8A.)
^ar-Q0333-answer

**ar-Q0334** — هناك الكثير من الأمور التي لا تعرفها عن شخصيتي.

There are a lot of things you don't know about my personality.

Why: Negation lā and laysa. [[Arabic#^ar-Q0334|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D9%86%D8%A7%D9%83%20%D8%A7%D9%84%D9%83%D8%AB%D9%8A%D8%B1%20%D9%85%D9%86%20%D8%A7%D9%84%D8%A3%D9%85%D9%88%D8%B1%20%D8%A7%D9%84%D8%AA%D9%8A%20%D9%84%D8%A7%20%D8%AA%D8%B9%D8%B1%D9%81%D9%87%D8%A7%20%D8%B9%D9%86%20%D8%B4%D8%AE%D8%B5%D9%8A%D8%AA%D9%8A.)
^ar-Q0334-answer

**ar-Q0335** — لا أحد كان قادرا على التّنبّؤ بذلك.

No one could have predicted this.

Why: Negation lā and laysa. [[Arabic#^ar-Q0335|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D8%A7%20%D8%A3%D8%AD%D8%AF%20%D9%83%D8%A7%D9%86%20%D9%82%D8%A7%D8%AF%D8%B1%D8%A7%20%D8%B9%D9%84%D9%89%20%D8%A7%D9%84%D8%AA%D9%91%D9%86%D8%A8%D9%91%D8%A4%20%D8%A8%D8%B0%D9%84%D9%83.)
^ar-Q0335-answer

**ar-Q0336** — لا أحد كان قادرا على التّنبّؤ بذلك.

No one could have predicted this.

لا negates various verbal/general constructions; ليس negates many nominal predicates. Their grammar is not identical. Dialects use different combinations and should be practised in their own section.

Why: Negation lā and laysa. [[Arabic#^ar-Q0336|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D8%A7%20%D8%A3%D8%AD%D8%AF%20%D9%83%D8%A7%D9%86%20%D9%82%D8%A7%D8%AF%D8%B1%D8%A7%20%D8%B9%D9%84%D9%89%20%D8%A7%D9%84%D8%AA%D9%91%D9%86%D8%A8%D9%91%D8%A4%20%D8%A8%D8%B0%D9%84%D9%83.)
^ar-Q0336-answer

**ar-Q0337** — سأكرّر كي لا تنسى ذلك.

I will repeat so that you will not forget it.

Expected form: **لا**

Why: Negation lā and laysa. [[Arabic#^ar-Q0337|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B3%D8%A3%D9%83%D8%B1%D9%91%D8%B1%20%D9%83%D9%8A%20%D9%84%D8%A7%20%D8%AA%D9%86%D8%B3%D9%89%20%D8%B0%D9%84%D9%83.)
^ar-Q0337-answer

**ar-Q0338** — سأكرّر كي لا تنسى ذلك.

I will repeat so that you will not forget it.

Expected form: **لا**

Why: Negation lā and laysa. [[Arabic#^ar-Q0338|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B3%D8%A3%D9%83%D8%B1%D9%91%D8%B1%20%D9%83%D9%8A%20%D9%84%D8%A7%20%D8%AA%D9%86%D8%B3%D9%89%20%D8%B0%D9%84%D9%83.)
^ar-Q0338-answer

**ar-Q0339** — ما حدث لهم لا يزال لغزا.

What happened to them is still a mystery.

Expected form: **لا**

Why: Negation lā and laysa. [[Arabic#^ar-Q0339|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D8%A7%20%D8%AD%D8%AF%D8%AB%20%D9%84%D9%87%D9%85%20%D9%84%D8%A7%20%D9%8A%D8%B2%D8%A7%D9%84%20%D9%84%D8%BA%D8%B2%D8%A7.)
^ar-Q0339-answer

**ar-Q0340** — ما حدث لهم لا يزال لغزا.

What happened to them is still a mystery.

Why: Negation lā and laysa. [[Arabic#^ar-Q0340|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D8%A7%20%D8%AD%D8%AF%D8%AB%20%D9%84%D9%87%D9%85%20%D9%84%D8%A7%20%D9%8A%D8%B2%D8%A7%D9%84%20%D9%84%D8%BA%D8%B2%D8%A7.)
^ar-Q0340-answer

**ar-Q0341** — ثيابه لا تتماشى مع الموضة.

His clothes are out of fashion.

Why: Negation lā and laysa. [[Arabic#^ar-Q0341|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%AB%D9%8A%D8%A7%D8%A8%D9%87%20%D9%84%D8%A7%20%D8%AA%D8%AA%D9%85%D8%A7%D8%B4%D9%89%20%D9%85%D8%B9%20%D8%A7%D9%84%D9%85%D9%88%D8%B6%D8%A9.)
^ar-Q0341-answer

**ar-Q0342** — ثيابه لا تتماشى مع الموضة.

His clothes are out of fashion.

لا negates various verbal/general constructions; ليس negates many nominal predicates. Their grammar is not identical. Dialects use different combinations and should be practised in their own section.

Why: Negation lā and laysa. [[Arabic#^ar-Q0342|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%AB%D9%8A%D8%A7%D8%A8%D9%87%20%D9%84%D8%A7%20%D8%AA%D8%AA%D9%85%D8%A7%D8%B4%D9%89%20%D9%85%D8%B9%20%D8%A7%D9%84%D9%85%D9%88%D8%B6%D8%A9.)
^ar-Q0342-answer

**ar-Q0343** — ليس بإمكان الشرطة أن تستجوبه لهذا السّبب.

Cops can't question him because of that.

Expected form: **ليس**

Why: Negation lā and laysa. [[Arabic#^ar-Q0343|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%8A%D8%B3%20%D8%A8%D8%A5%D9%85%D9%83%D8%A7%D9%86%20%D8%A7%D9%84%D8%B4%D8%B1%D8%B7%D8%A9%20%D8%A3%D9%86%20%D8%AA%D8%B3%D8%AA%D8%AC%D9%88%D8%A8%D9%87%20%D9%84%D9%87%D8%B0%D8%A7%20%D8%A7%D9%84%D8%B3%D9%91%D8%A8%D8%A8.)
^ar-Q0343-answer

**ar-Q0344** — ليس بإمكان الشرطة أن تستجوبه لهذا السّبب.

Cops can't question him because of that.

Expected form: **ليس**

Why: Negation lā and laysa. [[Arabic#^ar-Q0344|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%8A%D8%B3%20%D8%A8%D8%A5%D9%85%D9%83%D8%A7%D9%86%20%D8%A7%D9%84%D8%B4%D8%B1%D8%B7%D8%A9%20%D8%A3%D9%86%20%D8%AA%D8%B3%D8%AA%D8%AC%D9%88%D8%A8%D9%87%20%D9%84%D9%87%D8%B0%D8%A7%20%D8%A7%D9%84%D8%B3%D9%91%D8%A8%D8%A8.)
^ar-Q0344-answer

**ar-Q0345** — أرغم فاضل دانية على أن تمارس معه أفعالا جنسيّة لا تُوصف.

Fadil forced Dania to perform unspeakable acts on him.

Expected form: **لا**

Why: Negation lā and laysa. [[Arabic#^ar-Q0345|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%B1%D8%BA%D9%85%20%D9%81%D8%A7%D8%B6%D9%84%20%D8%AF%D8%A7%D9%86%D9%8A%D8%A9%20%D8%B9%D9%84%D9%89%20%D8%A3%D9%86%20%D8%AA%D9%85%D8%A7%D8%B1%D8%B3%20%D9%85%D8%B9%D9%87%20%D8%A3%D9%81%D8%B9%D8%A7%D9%84%D8%A7%20%D8%AC%D9%86%D8%B3%D9%8A%D9%91%D8%A9%20%D9%84%D8%A7%20%D8%AA%D9%8F%D9%88%D8%B5%D9%81.)
^ar-Q0345-answer

**ar-Q0346** — أرغم فاضل دانية على أن تمارس معه أفعالا جنسيّة لا تُوصف.

Fadil forced Dania to perform unspeakable acts on him.

Why: Negation lā and laysa. [[Arabic#^ar-Q0346|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%B1%D8%BA%D9%85%20%D9%81%D8%A7%D8%B6%D9%84%20%D8%AF%D8%A7%D9%86%D9%8A%D8%A9%20%D8%B9%D9%84%D9%89%20%D8%A3%D9%86%20%D8%AA%D9%85%D8%A7%D8%B1%D8%B3%20%D9%85%D8%B9%D9%87%20%D8%A3%D9%81%D8%B9%D8%A7%D9%84%D8%A7%20%D8%AC%D9%86%D8%B3%D9%8A%D9%91%D8%A9%20%D9%84%D8%A7%20%D8%AA%D9%8F%D9%88%D8%B5%D9%81.)
^ar-Q0346-answer

**ar-Q0347** — لا أظن أنه سيأتي.

I don't think he'll come.

Why: Negation lā and laysa. [[Arabic#^ar-Q0347|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D8%A7%20%D8%A3%D8%B8%D9%86%20%D8%A3%D9%86%D9%87%20%D8%B3%D9%8A%D8%A3%D8%AA%D9%8A.)
^ar-Q0347-answer

**ar-Q0348** — لا أظن أنه سيأتي.

I don't think he'll come.

لا negates various verbal/general constructions; ليس negates many nominal predicates. Their grammar is not identical. Dialects use different combinations and should be practised in their own section.

Why: Negation lā and laysa. [[Arabic#^ar-Q0348|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D8%A7%20%D8%A3%D8%B8%D9%86%20%D8%A3%D9%86%D9%87%20%D8%B3%D9%8A%D8%A3%D8%AA%D9%8A.)
^ar-Q0348-answer

**ar-Q0349** — لا نستطيع الرجوع لهناك.

We can't go back there.

Expected form: **لا**

Why: Negation lā and laysa. [[Arabic#^ar-Q0349|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D8%A7%20%D9%86%D8%B3%D8%AA%D8%B7%D9%8A%D8%B9%20%D8%A7%D9%84%D8%B1%D8%AC%D9%88%D8%B9%20%D9%84%D9%87%D9%86%D8%A7%D9%83.)
^ar-Q0349-answer

**ar-Q0350** — لا نستطيع الرجوع لهناك.

We can't go back there.

Expected form: **لا**

Why: Negation lā and laysa. [[Arabic#^ar-Q0350|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D8%A7%20%D9%86%D8%B3%D8%AA%D8%B7%D9%8A%D8%B9%20%D8%A7%D9%84%D8%B1%D8%AC%D9%88%D8%B9%20%D9%84%D9%87%D9%86%D8%A7%D9%83.)
^ar-Q0350-answer


### Answers 351–400

**ar-Q0351** — لم يتزوج سامي قطّ.

Sami never married.

Expected form: **لم**

Why: Past negation lam. [[Arabic#^ar-Q0351|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%85%20%D9%8A%D8%AA%D8%B2%D9%88%D8%AC%20%D8%B3%D8%A7%D9%85%D9%8A%20%D9%82%D8%B7%D9%91.)
^ar-Q0351-answer

**ar-Q0352** — لم يتزوج سامي قطّ.

Sami never married.

Why: Past negation lam. [[Arabic#^ar-Q0352|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%85%20%D9%8A%D8%AA%D8%B2%D9%88%D8%AC%20%D8%B3%D8%A7%D9%85%D9%8A%20%D9%82%D8%B7%D9%91.)
^ar-Q0352-answer

**ar-Q0353** — لم نكن نتقاتل

We weren't fighting.

Why: Past negation lam. [[Arabic#^ar-Q0353|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%85%20%D9%86%D9%83%D9%86%20%D9%86%D8%AA%D9%82%D8%A7%D8%AA%D9%84)
^ar-Q0353-answer

**ar-Q0354** — لم نكن نتقاتل

We weren't fighting.

لم normally negates a past occurrence using a jussive imperfect verb. It is not followed mechanically by an ordinary past form. Unvowelled text hides some mood distinctions.

Why: Past negation lam. [[Arabic#^ar-Q0354|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%85%20%D9%86%D9%83%D9%86%20%D9%86%D8%AA%D9%82%D8%A7%D8%AA%D9%84)
^ar-Q0354-answer

**ar-Q0355** — إذا لم تسرع سيفوتك القطار.

If you don't hurry, you'll miss the train.

Expected form: **لم**

Why: Past negation lam. [[Arabic#^ar-Q0355|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A5%D8%B0%D8%A7%20%D9%84%D9%85%20%D8%AA%D8%B3%D8%B1%D8%B9%20%D8%B3%D9%8A%D9%81%D9%88%D8%AA%D9%83%20%D8%A7%D9%84%D9%82%D8%B7%D8%A7%D8%B1.)
^ar-Q0355-answer

**ar-Q0356** — إذا لم تسرع سيفوتك القطار.

If you don't hurry, you'll miss the train.

Expected form: **لم**

Why: Past negation lam. [[Arabic#^ar-Q0356|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A5%D8%B0%D8%A7%20%D9%84%D9%85%20%D8%AA%D8%B3%D8%B1%D8%B9%20%D8%B3%D9%8A%D9%81%D9%88%D8%AA%D9%83%20%D8%A7%D9%84%D9%82%D8%B7%D8%A7%D8%B1.)
^ar-Q0356-answer

**ar-Q0357** — وقبل أكثر من سبع سنوات قامت الولايات المتحدة بملاحقة تنظيم القاعدة ونظام طالبان بدعم دولي واسع النطاق. لم نذهب إلى هناك باختيارنا وإنما بسبب الضرورة

Over seven years ago, the United States pursued al Qaeda and the Taliban with broad international support. We did not go by choice, we went because of necessity.

Expected form: **لم**

Why: Past negation lam. [[Arabic#^ar-Q0357|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%88%D9%82%D8%A8%D9%84%20%D8%A3%D9%83%D8%AB%D8%B1%20%D9%85%D9%86%20%D8%B3%D8%A8%D8%B9%20%D8%B3%D9%86%D9%88%D8%A7%D8%AA%20%D9%82%D8%A7%D9%85%D8%AA%20%D8%A7%D9%84%D9%88%D9%84%D8%A7%D9%8A%D8%A7%D8%AA%20%D8%A7%D9%84%D9%85%D8%AA%D8%AD%D8%AF%D8%A9%20%D8%A8%D9%85%D9%84%D8%A7%D8%AD%D9%82%D8%A9%20%D8%AA%D9%86%D8%B8%D9%8A%D9%85%20%D8%A7%D9%84%D9%82%D8%A7%D8%B9%D8%AF%D8%A9%20%D9%88%D9%86%D8%B8%D8%A7%D9%85%20%D8%B7%D8%A7%D9%84%D8%A8%D8%A7%D9%86%20%D8%A8%D8%AF%D8%B9%D9%85%20%D8%AF%D9%88%D9%84%D9%8A%20%D9%88%D8%A7%D8%B3%D8%B9%20%D8%A7%D9%84%D9%86%D8%B7%D8%A7%D9%82.%20%D9%84%D9%85%20%D9%86%D8%B0%D9%87%D8%A8%20%D8%A5%D9%84%D9%89%20%D9%87%D9%86%D8%A7%D9%83%20%D8%A8%D8%A7%D8%AE%D8%AA%D9%8A%D8%A7%D8%B1%D9%86%D8%A7%20%D9%88%D8%A5%D9%86%D9%85%D8%A7%20%D8%A8%D8%B3%D8%A8%D8%A8%20%D8%A7%D9%84%D8%B6%D8%B1%D9%88%D8%B1%D8%A9)
^ar-Q0357-answer

**ar-Q0358** — وقبل أكثر من سبع سنوات قامت الولايات المتحدة بملاحقة تنظيم القاعدة ونظام طالبان بدعم دولي واسع النطاق. لم نذهب إلى هناك باختيارنا وإنما بسبب الضرورة

Over seven years ago, the United States pursued al Qaeda and the Taliban with broad international support. We did not go by choice, we went because of necessity.

Why: Past negation lam. [[Arabic#^ar-Q0358|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%88%D9%82%D8%A8%D9%84%20%D8%A3%D9%83%D8%AB%D8%B1%20%D9%85%D9%86%20%D8%B3%D8%A8%D8%B9%20%D8%B3%D9%86%D9%88%D8%A7%D8%AA%20%D9%82%D8%A7%D9%85%D8%AA%20%D8%A7%D9%84%D9%88%D9%84%D8%A7%D9%8A%D8%A7%D8%AA%20%D8%A7%D9%84%D9%85%D8%AA%D8%AD%D8%AF%D8%A9%20%D8%A8%D9%85%D9%84%D8%A7%D8%AD%D9%82%D8%A9%20%D8%AA%D9%86%D8%B8%D9%8A%D9%85%20%D8%A7%D9%84%D9%82%D8%A7%D8%B9%D8%AF%D8%A9%20%D9%88%D9%86%D8%B8%D8%A7%D9%85%20%D8%B7%D8%A7%D9%84%D8%A8%D8%A7%D9%86%20%D8%A8%D8%AF%D8%B9%D9%85%20%D8%AF%D9%88%D9%84%D9%8A%20%D9%88%D8%A7%D8%B3%D8%B9%20%D8%A7%D9%84%D9%86%D8%B7%D8%A7%D9%82.%20%D9%84%D9%85%20%D9%86%D8%B0%D9%87%D8%A8%20%D8%A5%D9%84%D9%89%20%D9%87%D9%86%D8%A7%D9%83%20%D8%A8%D8%A7%D8%AE%D8%AA%D9%8A%D8%A7%D8%B1%D9%86%D8%A7%20%D9%88%D8%A5%D9%86%D9%85%D8%A7%20%D8%A8%D8%B3%D8%A8%D8%A8%20%D8%A7%D9%84%D8%B6%D8%B1%D9%88%D8%B1%D8%A9)
^ar-Q0358-answer

**ar-Q0359** — لماذا لم تخبرنا بانك تعرف الفرنسية؟

Why didn't you tell us you knew French?

Why: Past negation lam. [[Arabic#^ar-Q0359|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%85%D8%A7%D8%B0%D8%A7%20%D9%84%D9%85%20%D8%AA%D8%AE%D8%A8%D8%B1%D9%86%D8%A7%20%D8%A8%D8%A7%D9%86%D9%83%20%D8%AA%D8%B9%D8%B1%D9%81%20%D8%A7%D9%84%D9%81%D8%B1%D9%86%D8%B3%D9%8A%D8%A9%D8%9F)
^ar-Q0359-answer

**ar-Q0360** — لماذا لم تخبرنا بانك تعرف الفرنسية؟

Why didn't you tell us you knew French?

لم normally negates a past occurrence using a jussive imperfect verb. It is not followed mechanically by an ordinary past form. Unvowelled text hides some mood distinctions.

Why: Past negation lam. [[Arabic#^ar-Q0360|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%85%D8%A7%D8%B0%D8%A7%20%D9%84%D9%85%20%D8%AA%D8%AE%D8%A8%D8%B1%D9%86%D8%A7%20%D8%A8%D8%A7%D9%86%D9%83%20%D8%AA%D8%B9%D8%B1%D9%81%20%D8%A7%D9%84%D9%81%D8%B1%D9%86%D8%B3%D9%8A%D8%A9%D8%9F)
^ar-Q0360-answer

**ar-Q0361** — لم يعد لدينا سكر.

We're out of sugar.

Expected form: **لم**

Why: Past negation lam. [[Arabic#^ar-Q0361|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%85%20%D9%8A%D8%B9%D8%AF%20%D9%84%D8%AF%D9%8A%D9%86%D8%A7%20%D8%B3%D9%83%D8%B1.)
^ar-Q0361-answer

**ar-Q0362** — لم يعد لدينا سكر.

We're out of sugar.

Expected form: **لم**

Why: Past negation lam. [[Arabic#^ar-Q0362|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%85%20%D9%8A%D8%B9%D8%AF%20%D9%84%D8%AF%D9%8A%D9%86%D8%A7%20%D8%B3%D9%83%D8%B1.)
^ar-Q0362-answer

**ar-Q0363** — لم يكن عليّ فعل شيء.

I didn't have to do anything.

Expected form: **لم**

Why: Past negation lam. [[Arabic#^ar-Q0363|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%85%20%D9%8A%D9%83%D9%86%20%D8%B9%D9%84%D9%8A%D9%91%20%D9%81%D8%B9%D9%84%20%D8%B4%D9%8A%D8%A1.)
^ar-Q0363-answer

**ar-Q0364** — لم يكن عليّ فعل شيء.

I didn't have to do anything.

Why: Past negation lam. [[Arabic#^ar-Q0364|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%85%20%D9%8A%D9%83%D9%86%20%D8%B9%D9%84%D9%8A%D9%91%20%D9%81%D8%B9%D9%84%20%D8%B4%D9%8A%D8%A1.)
^ar-Q0364-answer

**ar-Q0365** — لم تكذب من أجلها؟

Why do you lie for her?

Why: Past negation lam. [[Arabic#^ar-Q0365|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%85%20%D8%AA%D9%83%D8%B0%D8%A8%20%D9%85%D9%86%20%D8%A3%D8%AC%D9%84%D9%87%D8%A7%D8%9F)
^ar-Q0365-answer

**ar-Q0366** — لم تكذب من أجلها؟

Why do you lie for her?

لم normally negates a past occurrence using a jussive imperfect verb. It is not followed mechanically by an ordinary past form. Unvowelled text hides some mood distinctions.

Why: Past negation lam. [[Arabic#^ar-Q0366|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%85%20%D8%AA%D9%83%D8%B0%D8%A8%20%D9%85%D9%86%20%D8%A3%D8%AC%D9%84%D9%87%D8%A7%D8%9F)
^ar-Q0366-answer

**ar-Q0367** — لم يأذني أحد.

Nobody hurt me.

Expected form: **لم**

Why: Past negation lam. [[Arabic#^ar-Q0367|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%85%20%D9%8A%D8%A3%D8%B0%D9%86%D9%8A%20%D8%A3%D8%AD%D8%AF.)
^ar-Q0367-answer

**ar-Q0368** — لم يأذني أحد.

Nobody hurt me.

Expected form: **لم**

Why: Past negation lam. [[Arabic#^ar-Q0368|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%85%20%D9%8A%D8%A3%D8%B0%D9%86%D9%8A%20%D8%A3%D8%AD%D8%AF.)
^ar-Q0368-answer

**ar-Q0369** — توم لم يذهب ابدا الى المدرسة

Tom has never gone to school.

Expected form: **لم**

Why: Past negation lam. [[Arabic#^ar-Q0369|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%AA%D9%88%D9%85%20%D9%84%D9%85%20%D9%8A%D8%B0%D9%87%D8%A8%20%D8%A7%D8%A8%D8%AF%D8%A7%20%D8%A7%D9%84%D9%89%20%D8%A7%D9%84%D9%85%D8%AF%D8%B1%D8%B3%D8%A9)
^ar-Q0369-answer

**ar-Q0370** — توم لم يذهب ابدا الى المدرسة

Tom has never gone to school.

Why: Past negation lam. [[Arabic#^ar-Q0370|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%AA%D9%88%D9%85%20%D9%84%D9%85%20%D9%8A%D8%B0%D9%87%D8%A8%20%D8%A7%D8%A8%D8%AF%D8%A7%20%D8%A7%D9%84%D9%89%20%D8%A7%D9%84%D9%85%D8%AF%D8%B1%D8%B3%D8%A9)
^ar-Q0370-answer

**ar-Q0371** — لم يشعر سامي قطّ بأنّه مسيحي.

Sami never felt Christian.

Why: Past negation lam. [[Arabic#^ar-Q0371|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%85%20%D9%8A%D8%B4%D8%B9%D8%B1%20%D8%B3%D8%A7%D9%85%D9%8A%20%D9%82%D8%B7%D9%91%20%D8%A8%D8%A3%D9%86%D9%91%D9%87%20%D9%85%D8%B3%D9%8A%D8%AD%D9%8A.)
^ar-Q0371-answer

**ar-Q0372** — لم يشعر سامي قطّ بأنّه مسيحي.

Sami never felt Christian.

لم normally negates a past occurrence using a jussive imperfect verb. It is not followed mechanically by an ordinary past form. Unvowelled text hides some mood distinctions.

Why: Past negation lam. [[Arabic#^ar-Q0372|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%85%20%D9%8A%D8%B4%D8%B9%D8%B1%20%D8%B3%D8%A7%D9%85%D9%8A%20%D9%82%D8%B7%D9%91%20%D8%A8%D8%A3%D9%86%D9%91%D9%87%20%D9%85%D8%B3%D9%8A%D8%AD%D9%8A.)
^ar-Q0372-answer

**ar-Q0373** — لم يجد أحد قطها أبدا.

Nobody ever found her cat.

Expected form: **لم**

Why: Past negation lam. [[Arabic#^ar-Q0373|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%85%20%D9%8A%D8%AC%D8%AF%20%D8%A3%D8%AD%D8%AF%20%D9%82%D8%B7%D9%87%D8%A7%20%D8%A3%D8%A8%D8%AF%D8%A7.)
^ar-Q0373-answer

**ar-Q0374** — لم يجد أحد قطها أبدا.

Nobody ever found her cat.

Expected form: **لم**

Why: Past negation lam. [[Arabic#^ar-Q0374|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%85%20%D9%8A%D8%AC%D8%AF%20%D8%A3%D8%AD%D8%AF%20%D9%82%D8%B7%D9%87%D8%A7%20%D8%A3%D8%A8%D8%AF%D8%A7.)
^ar-Q0374-answer

**ar-Q0375** — لم تحاول حتى ان تفعل الشيء الصحيح

She didn't even try to do the right thing.

Expected form: **لم**

Why: Past negation lam. [[Arabic#^ar-Q0375|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%85%20%D8%AA%D8%AD%D8%A7%D9%88%D9%84%20%D8%AD%D8%AA%D9%89%20%D8%A7%D9%86%20%D8%AA%D9%81%D8%B9%D9%84%20%D8%A7%D9%84%D8%B4%D9%8A%D8%A1%20%D8%A7%D9%84%D8%B5%D8%AD%D9%8A%D8%AD)
^ar-Q0375-answer

**ar-Q0376** — لم تحاول حتى ان تفعل الشيء الصحيح

She didn't even try to do the right thing.

Why: Past negation lam. [[Arabic#^ar-Q0376|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%85%20%D8%AA%D8%AD%D8%A7%D9%88%D9%84%20%D8%AD%D8%AA%D9%89%20%D8%A7%D9%86%20%D8%AA%D9%81%D8%B9%D9%84%20%D8%A7%D9%84%D8%B4%D9%8A%D8%A1%20%D8%A7%D9%84%D8%B5%D8%AD%D9%8A%D8%AD)
^ar-Q0376-answer

**ar-Q0377** — كأنني لم أعرف هذا!

As if I didn't know that!

Why: Past negation lam. [[Arabic#^ar-Q0377|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D8%A3%D9%86%D9%86%D9%8A%20%D9%84%D9%85%20%D8%A3%D8%B9%D8%B1%D9%81%20%D9%87%D8%B0%D8%A7%21)
^ar-Q0377-answer

**ar-Q0378** — كأنني لم أعرف هذا!

As if I didn't know that!

لم normally negates a past occurrence using a jussive imperfect verb. It is not followed mechanically by an ordinary past form. Unvowelled text hides some mood distinctions.

Why: Past negation lam. [[Arabic#^ar-Q0378|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D8%A3%D9%86%D9%86%D9%8A%20%D9%84%D9%85%20%D8%A3%D8%B9%D8%B1%D9%81%20%D9%87%D8%B0%D8%A7%21)
^ar-Q0378-answer

**ar-Q0379** — إن لم يكن معطلا، فلا داعي لأن تصلحه.

If it ain't broke, don't fix it.

Expected form: **لم**

Why: Past negation lam. [[Arabic#^ar-Q0379|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A5%D9%86%20%D9%84%D9%85%20%D9%8A%D9%83%D9%86%20%D9%85%D8%B9%D8%B7%D9%84%D8%A7%D8%8C%20%D9%81%D9%84%D8%A7%20%D8%AF%D8%A7%D8%B9%D9%8A%20%D9%84%D8%A3%D9%86%20%D8%AA%D8%B5%D9%84%D8%AD%D9%87.)
^ar-Q0379-answer

**ar-Q0380** — إن لم يكن معطلا، فلا داعي لأن تصلحه.

If it ain't broke, don't fix it.

Expected form: **لم**

Why: Past negation lam. [[Arabic#^ar-Q0380|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A5%D9%86%20%D9%84%D9%85%20%D9%8A%D9%83%D9%86%20%D9%85%D8%B9%D8%B7%D9%84%D8%A7%D8%8C%20%D9%81%D9%84%D8%A7%20%D8%AF%D8%A7%D8%B9%D9%8A%20%D9%84%D8%A3%D9%86%20%D8%AA%D8%B5%D9%84%D8%AD%D9%87.)
^ar-Q0380-answer

**ar-Q0381** — تعلم لم أنا لست مضطرّا للقيام بهذا، أليس كذلك؟

You know why I don't have to do that, don't you?

Expected form: **لم**

Why: Past negation lam. [[Arabic#^ar-Q0381|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%AA%D8%B9%D9%84%D9%85%20%D9%84%D9%85%20%D8%A3%D9%86%D8%A7%20%D9%84%D8%B3%D8%AA%20%D9%85%D8%B6%D8%B7%D8%B1%D9%91%D8%A7%20%D9%84%D9%84%D9%82%D9%8A%D8%A7%D9%85%20%D8%A8%D9%87%D8%B0%D8%A7%D8%8C%20%D8%A3%D9%84%D9%8A%D8%B3%20%D9%83%D8%B0%D9%84%D9%83%D8%9F)
^ar-Q0381-answer

**ar-Q0382** — تعلم لم أنا لست مضطرّا للقيام بهذا، أليس كذلك؟

You know why I don't have to do that, don't you?

Why: Past negation lam. [[Arabic#^ar-Q0382|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%AA%D8%B9%D9%84%D9%85%20%D9%84%D9%85%20%D8%A3%D9%86%D8%A7%20%D9%84%D8%B3%D8%AA%20%D9%85%D8%B6%D8%B7%D8%B1%D9%91%D8%A7%20%D9%84%D9%84%D9%82%D9%8A%D8%A7%D9%85%20%D8%A8%D9%87%D8%B0%D8%A7%D8%8C%20%D8%A3%D9%84%D9%8A%D8%B3%20%D9%83%D8%B0%D9%84%D9%83%D8%9F)
^ar-Q0382-answer

**ar-Q0383** — لم تكن ليلى و سامي راغبين أن يعلم النّاس بزواجهما.

Layla and Sami didn't want their marriage to be made public.

Why: Past negation lam. [[Arabic#^ar-Q0383|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%85%20%D8%AA%D9%83%D9%86%20%D9%84%D9%8A%D9%84%D9%89%20%D9%88%20%D8%B3%D8%A7%D9%85%D9%8A%20%D8%B1%D8%A7%D8%BA%D8%A8%D9%8A%D9%86%20%D8%A3%D9%86%20%D9%8A%D8%B9%D9%84%D9%85%20%D8%A7%D9%84%D9%86%D9%91%D8%A7%D8%B3%20%D8%A8%D8%B2%D9%88%D8%A7%D8%AC%D9%87%D9%85%D8%A7.)
^ar-Q0383-answer

**ar-Q0384** — لم تكن ليلى و سامي راغبين أن يعلم النّاس بزواجهما.

Layla and Sami didn't want their marriage to be made public.

لم normally negates a past occurrence using a jussive imperfect verb. It is not followed mechanically by an ordinary past form. Unvowelled text hides some mood distinctions.

Why: Past negation lam. [[Arabic#^ar-Q0384|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%85%20%D8%AA%D9%83%D9%86%20%D9%84%D9%8A%D9%84%D9%89%20%D9%88%20%D8%B3%D8%A7%D9%85%D9%8A%20%D8%B1%D8%A7%D8%BA%D8%A8%D9%8A%D9%86%20%D8%A3%D9%86%20%D9%8A%D8%B9%D9%84%D9%85%20%D8%A7%D9%84%D9%86%D9%91%D8%A7%D8%B3%20%D8%A8%D8%B2%D9%88%D8%A7%D8%AC%D9%87%D9%85%D8%A7.)
^ar-Q0384-answer

**ar-Q0385** — لم لم تتّصل بي مسبّقا؟

Why didn't you call me earlier?

Expected form: **لم**

Why: Past negation lam. [[Arabic#^ar-Q0385|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%85%20%D9%84%D9%85%20%D8%AA%D8%AA%D9%91%D8%B5%D9%84%20%D8%A8%D9%8A%20%D9%85%D8%B3%D8%A8%D9%91%D9%82%D8%A7%D8%9F)
^ar-Q0385-answer

**ar-Q0386** — لم لم تتّصل بي مسبّقا؟

Why didn't you call me earlier?

Expected form: **لم**

Why: Past negation lam. [[Arabic#^ar-Q0386|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%85%20%D9%84%D9%85%20%D8%AA%D8%AA%D9%91%D8%B5%D9%84%20%D8%A8%D9%8A%20%D9%85%D8%B3%D8%A8%D9%91%D9%82%D8%A7%D8%9F)
^ar-Q0386-answer

**ar-Q0387** — لم يُعامَل سامي بنفس الطّريقة.

Sami didn't get the same treatment.

Expected form: **لم**

Why: Past negation lam. [[Arabic#^ar-Q0387|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%85%20%D9%8A%D9%8F%D8%B9%D8%A7%D9%85%D9%8E%D9%84%20%D8%B3%D8%A7%D9%85%D9%8A%20%D8%A8%D9%86%D9%81%D8%B3%20%D8%A7%D9%84%D8%B7%D9%91%D8%B1%D9%8A%D9%82%D8%A9.)
^ar-Q0387-answer

**ar-Q0388** — لم يُعامَل سامي بنفس الطّريقة.

Sami didn't get the same treatment.

Why: Past negation lam. [[Arabic#^ar-Q0388|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%85%20%D9%8A%D9%8F%D8%B9%D8%A7%D9%85%D9%8E%D9%84%20%D8%B3%D8%A7%D9%85%D9%8A%20%D8%A8%D9%86%D9%81%D8%B3%20%D8%A7%D9%84%D8%B7%D9%91%D8%B1%D9%8A%D9%82%D8%A9.)
^ar-Q0388-answer

**ar-Q0389** — أنا لم أعد أعيش هنا.

I no longer live here.

Why: Past negation lam. [[Arabic#^ar-Q0389|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D9%86%D8%A7%20%D9%84%D9%85%20%D8%A3%D8%B9%D8%AF%20%D8%A3%D8%B9%D9%8A%D8%B4%20%D9%87%D9%86%D8%A7.)
^ar-Q0389-answer

**ar-Q0390** — أنا لم أعد أعيش هنا.

I no longer live here.

لم normally negates a past occurrence using a jussive imperfect verb. It is not followed mechanically by an ordinary past form. Unvowelled text hides some mood distinctions.

Why: Past negation lam. [[Arabic#^ar-Q0390|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D9%86%D8%A7%20%D9%84%D9%85%20%D8%A3%D8%B9%D8%AF%20%D8%A3%D8%B9%D9%8A%D8%B4%20%D9%87%D9%86%D8%A7.)
^ar-Q0390-answer

**ar-Q0391** — لم يجد توم مفتاحه في أي مكان.

Tom couldn't find his key anywhere.

Expected form: **لم**

Why: Past negation lam. [[Arabic#^ar-Q0391|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%85%20%D9%8A%D8%AC%D8%AF%20%D8%AA%D9%88%D9%85%20%D9%85%D9%81%D8%AA%D8%A7%D8%AD%D9%87%20%D9%81%D9%8A%20%D8%A3%D9%8A%20%D9%85%D9%83%D8%A7%D9%86.)
^ar-Q0391-answer

**ar-Q0392** — لم يجد توم مفتاحه في أي مكان.

Tom couldn't find his key anywhere.

Expected form: **لم**

Why: Past negation lam. [[Arabic#^ar-Q0392|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%85%20%D9%8A%D8%AC%D8%AF%20%D8%AA%D9%88%D9%85%20%D9%85%D9%81%D8%AA%D8%A7%D8%AD%D9%87%20%D9%81%D9%8A%20%D8%A3%D9%8A%20%D9%85%D9%83%D8%A7%D9%86.)
^ar-Q0392-answer

**ar-Q0393** — لم يسبق لي و أن رأيت فتاة جميلة مثل هذه.

I had never seen such a beautiful girl before.

Expected form: **لم**

Why: Past negation lam. [[Arabic#^ar-Q0393|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%85%20%D9%8A%D8%B3%D8%A8%D9%82%20%D9%84%D9%8A%20%D9%88%20%D8%A3%D9%86%20%D8%B1%D8%A3%D9%8A%D8%AA%20%D9%81%D8%AA%D8%A7%D8%A9%20%D8%AC%D9%85%D9%8A%D9%84%D8%A9%20%D9%85%D8%AB%D9%84%20%D9%87%D8%B0%D9%87.)
^ar-Q0393-answer

**ar-Q0394** — لم يسبق لي و أن رأيت فتاة جميلة مثل هذه.

I had never seen such a beautiful girl before.

Why: Past negation lam. [[Arabic#^ar-Q0394|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%85%20%D9%8A%D8%B3%D8%A8%D9%82%20%D9%84%D9%8A%20%D9%88%20%D8%A3%D9%86%20%D8%B1%D8%A3%D9%8A%D8%AA%20%D9%81%D8%AA%D8%A7%D8%A9%20%D8%AC%D9%85%D9%8A%D9%84%D8%A9%20%D9%85%D8%AB%D9%84%20%D9%87%D8%B0%D9%87.)
^ar-Q0394-answer

**ar-Q0395** — لم الإستسلام الآن؟

Why quit now?

Why: Past negation lam. [[Arabic#^ar-Q0395|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%85%20%D8%A7%D9%84%D8%A5%D8%B3%D8%AA%D8%B3%D9%84%D8%A7%D9%85%20%D8%A7%D9%84%D8%A2%D9%86%D8%9F)
^ar-Q0395-answer

**ar-Q0396** — لم الإستسلام الآن؟

Why quit now?

لم normally negates a past occurrence using a jussive imperfect verb. It is not followed mechanically by an ordinary past form. Unvowelled text hides some mood distinctions.

Why: Past negation lam. [[Arabic#^ar-Q0396|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%85%20%D8%A7%D9%84%D8%A5%D8%B3%D8%AA%D8%B3%D9%84%D8%A7%D9%85%20%D8%A7%D9%84%D8%A2%D9%86%D8%9F)
^ar-Q0396-answer

**ar-Q0397** — لم يفهم معنى الجملة.

He couldn't understand the sentence.

Expected form: **لم**

Why: Past negation lam. [[Arabic#^ar-Q0397|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%85%20%D9%8A%D9%81%D9%87%D9%85%20%D9%85%D8%B9%D9%86%D9%89%20%D8%A7%D9%84%D8%AC%D9%85%D9%84%D8%A9.)
^ar-Q0397-answer

**ar-Q0398** — لم يفهم معنى الجملة.

He couldn't understand the sentence.

Expected form: **لم**

Why: Past negation lam. [[Arabic#^ar-Q0398|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%85%20%D9%8A%D9%81%D9%87%D9%85%20%D9%85%D8%B9%D9%86%D9%89%20%D8%A7%D9%84%D8%AC%D9%85%D9%84%D8%A9.)
^ar-Q0398-answer

**ar-Q0399** — لم يسبق لنا و أن قمنا بهذا من قبل.

We have never done it before.

Expected form: **لم**

Why: Past negation lam. [[Arabic#^ar-Q0399|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%85%20%D9%8A%D8%B3%D8%A8%D9%82%20%D9%84%D9%86%D8%A7%20%D9%88%20%D8%A3%D9%86%20%D9%82%D9%85%D9%86%D8%A7%20%D8%A8%D9%87%D8%B0%D8%A7%20%D9%85%D9%86%20%D9%82%D8%A8%D9%84.)
^ar-Q0399-answer

**ar-Q0400** — لم يسبق لنا و أن قمنا بهذا من قبل.

We have never done it before.

Why: Past negation lam. [[Arabic#^ar-Q0400|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%85%20%D9%8A%D8%B3%D8%A8%D9%82%20%D9%84%D9%86%D8%A7%20%D9%88%20%D8%A3%D9%86%20%D9%82%D9%85%D9%86%D8%A7%20%D8%A8%D9%87%D8%B0%D8%A7%20%D9%85%D9%86%20%D9%82%D8%A8%D9%84.)
^ar-Q0400-answer


### Answers 401–450

**ar-Q0401** — لن أنس مراسلة أمّي.

I will not forget to write to my mother.

Why: Future negation lan. [[Arabic#^ar-Q0401|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%86%20%D8%A3%D9%86%D8%B3%20%D9%85%D8%B1%D8%A7%D8%B3%D9%84%D8%A9%20%D8%A3%D9%85%D9%91%D9%8A.)
^ar-Q0401-answer

**ar-Q0402** — لن أنس مراسلة أمّي.

I will not forget to write to my mother.

لن normally introduces future-oriented negation with a subjunctive imperfect form in MSA. The written particle is separate from the verb. Contrast its time relation with لم.

Why: Future negation lan. [[Arabic#^ar-Q0402|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%86%20%D8%A3%D9%86%D8%B3%20%D9%85%D8%B1%D8%A7%D8%B3%D9%84%D8%A9%20%D8%A3%D9%85%D9%91%D9%8A.)
^ar-Q0402-answer

**ar-Q0403** — لن تؤذي ذبابة.

It wouldn't harm a fly.

Expected form: **لن**

Why: Future negation lan. [[Arabic#^ar-Q0403|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%86%20%D8%AA%D8%A4%D8%B0%D9%8A%20%D8%B0%D8%A8%D8%A7%D8%A8%D8%A9.)
^ar-Q0403-answer

**ar-Q0404** — لن تؤذي ذبابة.

It wouldn't harm a fly.

Expected form: **لن**

Why: Future negation lan. [[Arabic#^ar-Q0404|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%86%20%D8%AA%D8%A4%D8%B0%D9%8A%20%D8%B0%D8%A8%D8%A7%D8%A8%D8%A9.)
^ar-Q0404-answer

**ar-Q0405** — لن يأتي أليس كذلك؟

He won't come, will he?

Expected form: **لن**

Why: Future negation lan. [[Arabic#^ar-Q0405|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%86%20%D9%8A%D8%A3%D8%AA%D9%8A%20%D8%A3%D9%84%D9%8A%D8%B3%20%D9%83%D8%B0%D9%84%D9%83%D8%9F)
^ar-Q0405-answer

**ar-Q0406** — لن يأتي أليس كذلك؟

He won't come, will he?

Why: Future negation lan. [[Arabic#^ar-Q0406|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%86%20%D9%8A%D8%A3%D8%AA%D9%8A%20%D8%A3%D9%84%D9%8A%D8%B3%20%D9%83%D8%B0%D9%84%D9%83%D8%9F)
^ar-Q0406-answer

**ar-Q0407** — أسرع و لن تتأخر على المدرسة.

Hurry up, and you will be in time for school.

Why: Future negation lan. [[Arabic#^ar-Q0407|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%B3%D8%B1%D8%B9%20%D9%88%20%D9%84%D9%86%20%D8%AA%D8%AA%D8%A3%D8%AE%D8%B1%20%D8%B9%D9%84%D9%89%20%D8%A7%D9%84%D9%85%D8%AF%D8%B1%D8%B3%D8%A9.)
^ar-Q0407-answer

**ar-Q0408** — أسرع و لن تتأخر على المدرسة.

Hurry up, and you will be in time for school.

لن normally introduces future-oriented negation with a subjunctive imperfect form in MSA. The written particle is separate from the verb. Contrast its time relation with لم.

Why: Future negation lan. [[Arabic#^ar-Q0408|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%B3%D8%B1%D8%B9%20%D9%88%20%D9%84%D9%86%20%D8%AA%D8%AA%D8%A3%D8%AE%D8%B1%20%D8%B9%D9%84%D9%89%20%D8%A7%D9%84%D9%85%D8%AF%D8%B1%D8%B3%D8%A9.)
^ar-Q0408-answer

**ar-Q0409** — لن أنس أبدا ما قلته لي.

I'll never forget what you told me.

Expected form: **لن**

Why: Future negation lan. [[Arabic#^ar-Q0409|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%86%20%D8%A3%D9%86%D8%B3%20%D8%A3%D8%A8%D8%AF%D8%A7%20%D9%85%D8%A7%20%D9%82%D9%84%D8%AA%D9%87%20%D9%84%D9%8A.)
^ar-Q0409-answer

**ar-Q0410** — لن أنس أبدا ما قلته لي.

I'll never forget what you told me.

Expected form: **لن**

Why: Future negation lan. [[Arabic#^ar-Q0410|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%86%20%D8%A3%D9%86%D8%B3%20%D8%A3%D8%A8%D8%AF%D8%A7%20%D9%85%D8%A7%20%D9%82%D9%84%D8%AA%D9%87%20%D9%84%D9%8A.)
^ar-Q0410-answer

**ar-Q0411** — يجب أن تدرك بأننا لن نستطيع تقديم يد العون.

You must realize that I can't help you.

Expected form: **لن**

Why: Future negation lan. [[Arabic#^ar-Q0411|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%8A%D8%AC%D8%A8%20%D8%A3%D9%86%20%D8%AA%D8%AF%D8%B1%D9%83%20%D8%A8%D8%A3%D9%86%D9%86%D8%A7%20%D9%84%D9%86%20%D9%86%D8%B3%D8%AA%D8%B7%D9%8A%D8%B9%20%D8%AA%D9%82%D8%AF%D9%8A%D9%85%20%D9%8A%D8%AF%20%D8%A7%D9%84%D8%B9%D9%88%D9%86.)
^ar-Q0411-answer

**ar-Q0412** — يجب أن تدرك بأننا لن نستطيع تقديم يد العون.

You must realize that I can't help you.

Why: Future negation lan. [[Arabic#^ar-Q0412|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%8A%D8%AC%D8%A8%20%D8%A3%D9%86%20%D8%AA%D8%AF%D8%B1%D9%83%20%D8%A8%D8%A3%D9%86%D9%86%D8%A7%20%D9%84%D9%86%20%D9%86%D8%B3%D8%AA%D8%B7%D9%8A%D8%B9%20%D8%AA%D9%82%D8%AF%D9%8A%D9%85%20%D9%8A%D8%AF%20%D8%A7%D9%84%D8%B9%D9%88%D9%86.)
^ar-Q0412-answer

**ar-Q0413** — من الأرجح أنّني لن أنس ذلك.

I'm not likely to forget to do that.

Why: Future negation lan. [[Arabic#^ar-Q0413|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D9%86%20%D8%A7%D9%84%D8%A3%D8%B1%D8%AC%D8%AD%20%D8%A3%D9%86%D9%91%D9%86%D9%8A%20%D9%84%D9%86%20%D8%A3%D9%86%D8%B3%20%D8%B0%D9%84%D9%83.)
^ar-Q0413-answer

**ar-Q0414** — من الأرجح أنّني لن أنس ذلك.

I'm not likely to forget to do that.

لن normally introduces future-oriented negation with a subjunctive imperfect form in MSA. The written particle is separate from the verb. Contrast its time relation with لم.

Why: Future negation lan. [[Arabic#^ar-Q0414|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D9%86%20%D8%A7%D9%84%D8%A3%D8%B1%D8%AC%D8%AD%20%D8%A3%D9%86%D9%91%D9%86%D9%8A%20%D9%84%D9%86%20%D8%A3%D9%86%D8%B3%20%D8%B0%D9%84%D9%83.)
^ar-Q0414-answer

**ar-Q0415** — لن تسطيع أمي القدوم.

My mother can't come.

Expected form: **لن**

Why: Future negation lan. [[Arabic#^ar-Q0415|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%86%20%D8%AA%D8%B3%D8%B7%D9%8A%D8%B9%20%D8%A3%D9%85%D9%8A%20%D8%A7%D9%84%D9%82%D8%AF%D9%88%D9%85.)
^ar-Q0415-answer

**ar-Q0416** — لن تسطيع أمي القدوم.

My mother can't come.

Expected form: **لن**

Why: Future negation lan. [[Arabic#^ar-Q0416|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%86%20%D8%AA%D8%B3%D8%B7%D9%8A%D8%B9%20%D8%A3%D9%85%D9%8A%20%D8%A7%D9%84%D9%82%D8%AF%D9%88%D9%85.)
^ar-Q0416-answer

**ar-Q0417** — لن يُغَيِّرَ ذلك شيئًا.

That won't change anything.

Expected form: **لن**

Why: Future negation lan. [[Arabic#^ar-Q0417|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%86%20%D9%8A%D9%8F%D8%BA%D9%8E%D9%8A%D9%90%D9%91%D8%B1%D9%8E%20%D8%B0%D9%84%D9%83%20%D8%B4%D9%8A%D8%A6%D9%8B%D8%A7.)
^ar-Q0417-answer

**ar-Q0418** — لن يُغَيِّرَ ذلك شيئًا.

That won't change anything.

Why: Future negation lan. [[Arabic#^ar-Q0418|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%86%20%D9%8A%D9%8F%D8%BA%D9%8E%D9%8A%D9%90%D9%91%D8%B1%D9%8E%20%D8%B0%D9%84%D9%83%20%D8%B4%D9%8A%D8%A6%D9%8B%D8%A7.)
^ar-Q0418-answer

**ar-Q0419** — أبدأ لن أشك في صدقه.

I would never question his honesty.

Why: Future negation lan. [[Arabic#^ar-Q0419|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%A8%D8%AF%D8%A3%20%D9%84%D9%86%20%D8%A3%D8%B4%D9%83%20%D9%81%D9%8A%20%D8%B5%D8%AF%D9%82%D9%87.)
^ar-Q0419-answer

**ar-Q0420** — أبدأ لن أشك في صدقه.

I would never question his honesty.

لن normally introduces future-oriented negation with a subjunctive imperfect form in MSA. The written particle is separate from the verb. Contrast its time relation with لم.

Why: Future negation lan. [[Arabic#^ar-Q0420|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%A8%D8%AF%D8%A3%20%D9%84%D9%86%20%D8%A3%D8%B4%D9%83%20%D9%81%D9%8A%20%D8%B5%D8%AF%D9%82%D9%87.)
^ar-Q0420-answer

**ar-Q0421** — لنُلقِ نظرة عليه.

Let's have a look at it.

Expected form: **لن**

Why: Future negation lan. [[Arabic#^ar-Q0421|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%86%D9%8F%D9%84%D9%82%D9%90%20%D9%86%D8%B8%D8%B1%D8%A9%20%D8%B9%D9%84%D9%8A%D9%87.)
^ar-Q0421-answer

**ar-Q0422** — لنُلقِ نظرة عليه.

Let's have a look at it.

Expected form: **لن**

Why: Future negation lan. [[Arabic#^ar-Q0422|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%86%D9%8F%D9%84%D9%82%D9%90%20%D9%86%D8%B8%D8%B1%D8%A9%20%D8%B9%D9%84%D9%8A%D9%87.)
^ar-Q0422-answer

**ar-Q0423** — أصر ديما: "لكنه صحيح! لن يجعلوني أشتري البذلة ما لم أعطهم 99 كوبيكًا! ألا تستطيع أن ترسل لي بعض المال؟"

"But it's true!" Dima insisted. "They won't let me buy the suit unless I give them another 99 kopeks! Can't you wire me some money?"

Expected form: **لن**

Why: Future negation lan. [[Arabic#^ar-Q0423|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%B5%D8%B1%20%D8%AF%D9%8A%D9%85%D8%A7%3A%20%22%D9%84%D9%83%D9%86%D9%87%20%D8%B5%D8%AD%D9%8A%D8%AD%21%20%D9%84%D9%86%20%D9%8A%D8%AC%D8%B9%D9%84%D9%88%D9%86%D9%8A%20%D8%A3%D8%B4%D8%AA%D8%B1%D9%8A%20%D8%A7%D9%84%D8%A8%D8%B0%D9%84%D8%A9%20%D9%85%D8%A7%20%D9%84%D9%85%20%D8%A3%D8%B9%D8%B7%D9%87%D9%85%2099%20%D9%83%D9%88%D8%A8%D9%8A%D9%83%D9%8B%D8%A7%21%20%D8%A3%D9%84%D8%A7%20%D8%AA%D8%B3%D8%AA%D8%B7%D9%8A%D8%B9%20%D8%A3%D9%86%20%D8%AA%D8%B1%D8%B3%D9%84%20%D9%84%D9%8A%20%D8%A8%D8%B9%D8%B6%20%D8%A7%D9%84%D9%85%D8%A7%D9%84%D8%9F%22)
^ar-Q0423-answer

**ar-Q0424** — أصر ديما: "لكنه صحيح! لن يجعلوني أشتري البذلة ما لم أعطهم 99 كوبيكًا! ألا تستطيع أن ترسل لي بعض المال؟"

"But it's true!" Dima insisted. "They won't let me buy the suit unless I give them another 99 kopeks! Can't you wire me some money?"

Why: Future negation lan. [[Arabic#^ar-Q0424|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%B5%D8%B1%20%D8%AF%D9%8A%D9%85%D8%A7%3A%20%22%D9%84%D9%83%D9%86%D9%87%20%D8%B5%D8%AD%D9%8A%D8%AD%21%20%D9%84%D9%86%20%D9%8A%D8%AC%D8%B9%D9%84%D9%88%D9%86%D9%8A%20%D8%A3%D8%B4%D8%AA%D8%B1%D9%8A%20%D8%A7%D9%84%D8%A8%D8%B0%D9%84%D8%A9%20%D9%85%D8%A7%20%D9%84%D9%85%20%D8%A3%D8%B9%D8%B7%D9%87%D9%85%2099%20%D9%83%D9%88%D8%A8%D9%8A%D9%83%D9%8B%D8%A7%21%20%D8%A3%D9%84%D8%A7%20%D8%AA%D8%B3%D8%AA%D8%B7%D9%8A%D8%B9%20%D8%A3%D9%86%20%D8%AA%D8%B1%D8%B3%D9%84%20%D9%84%D9%8A%20%D8%A8%D8%B9%D8%B6%20%D8%A7%D9%84%D9%85%D8%A7%D9%84%D8%9F%22)
^ar-Q0424-answer

**ar-Q0425** — لن يصبكن أحد بالأذى.

Nobody is going to hurt you.

Why: Future negation lan. [[Arabic#^ar-Q0425|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%86%20%D9%8A%D8%B5%D8%A8%D9%83%D9%86%20%D8%A3%D8%AD%D8%AF%20%D8%A8%D8%A7%D9%84%D8%A3%D8%B0%D9%89.)
^ar-Q0425-answer

**ar-Q0426** — لن يصبكن أحد بالأذى.

Nobody is going to hurt you.

لن normally introduces future-oriented negation with a subjunctive imperfect form in MSA. The written particle is separate from the verb. Contrast its time relation with لم.

Why: Future negation lan. [[Arabic#^ar-Q0426|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%86%20%D9%8A%D8%B5%D8%A8%D9%83%D9%86%20%D8%A3%D8%AD%D8%AF%20%D8%A8%D8%A7%D9%84%D8%A3%D8%B0%D9%89.)
^ar-Q0426-answer

**ar-Q0427** — لن أطّلع على تقرير توم على الأرجح.

I probably won't read Tom's report.

Expected form: **لن**

Why: Future negation lan. [[Arabic#^ar-Q0427|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%86%20%D8%A3%D8%B7%D9%91%D9%84%D8%B9%20%D8%B9%D9%84%D9%89%20%D8%AA%D9%82%D8%B1%D9%8A%D8%B1%20%D8%AA%D9%88%D9%85%20%D8%B9%D9%84%D9%89%20%D8%A7%D9%84%D8%A3%D8%B1%D8%AC%D8%AD.)
^ar-Q0427-answer

**ar-Q0428** — لن أطّلع على تقرير توم على الأرجح.

I probably won't read Tom's report.

Expected form: **لن**

Why: Future negation lan. [[Arabic#^ar-Q0428|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%86%20%D8%A3%D8%B7%D9%91%D9%84%D8%B9%20%D8%B9%D9%84%D9%89%20%D8%AA%D9%82%D8%B1%D9%8A%D8%B1%20%D8%AA%D9%88%D9%85%20%D8%B9%D9%84%D9%89%20%D8%A7%D9%84%D8%A3%D8%B1%D8%AC%D8%AD.)
^ar-Q0428-answer

**ar-Q0429** — لن أدعها تذهب إلى هناك.

I won't let her go there.

Expected form: **لن**

Why: Future negation lan. [[Arabic#^ar-Q0429|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%86%20%D8%A3%D8%AF%D8%B9%D9%87%D8%A7%20%D8%AA%D8%B0%D9%87%D8%A8%20%D8%A5%D9%84%D9%89%20%D9%87%D9%86%D8%A7%D9%83.)
^ar-Q0429-answer

**ar-Q0430** — لن أدعها تذهب إلى هناك.

I won't let her go there.

Why: Future negation lan. [[Arabic#^ar-Q0430|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%86%20%D8%A3%D8%AF%D8%B9%D9%87%D8%A7%20%D8%AA%D8%B0%D9%87%D8%A8%20%D8%A5%D9%84%D9%89%20%D9%87%D9%86%D8%A7%D9%83.)
^ar-Q0430-answer

**ar-Q0431** — لن تصفعني إميلي أبدا في الوجه.

Emily would never slap me in the face.

Why: Future negation lan. [[Arabic#^ar-Q0431|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%86%20%D8%AA%D8%B5%D9%81%D8%B9%D9%86%D9%8A%20%D8%A5%D9%85%D9%8A%D9%84%D9%8A%20%D8%A3%D8%A8%D8%AF%D8%A7%20%D9%81%D9%8A%20%D8%A7%D9%84%D9%88%D8%AC%D9%87.)
^ar-Q0431-answer

**ar-Q0432** — لن تصفعني إميلي أبدا في الوجه.

Emily would never slap me in the face.

لن normally introduces future-oriented negation with a subjunctive imperfect form in MSA. The written particle is separate from the verb. Contrast its time relation with لم.

Why: Future negation lan. [[Arabic#^ar-Q0432|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%86%20%D8%AA%D8%B5%D9%81%D8%B9%D9%86%D9%8A%20%D8%A5%D9%85%D9%8A%D9%84%D9%8A%20%D8%A3%D8%A8%D8%AF%D8%A7%20%D9%81%D9%8A%20%D8%A7%D9%84%D9%88%D8%AC%D9%87.)
^ar-Q0432-answer

**ar-Q0433** — لن أذهب إلى المدرسة اليوم.

I'm not going to go to school today.

Expected form: **لن**

Why: Future negation lan. [[Arabic#^ar-Q0433|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%86%20%D8%A3%D8%B0%D9%87%D8%A8%20%D8%A5%D9%84%D9%89%20%D8%A7%D9%84%D9%85%D8%AF%D8%B1%D8%B3%D8%A9%20%D8%A7%D9%84%D9%8A%D9%88%D9%85.)
^ar-Q0433-answer

**ar-Q0434** — لن أذهب إلى المدرسة اليوم.

I'm not going to go to school today.

Expected form: **لن**

Why: Future negation lan. [[Arabic#^ar-Q0434|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%86%20%D8%A3%D8%B0%D9%87%D8%A8%20%D8%A5%D9%84%D9%89%20%D8%A7%D9%84%D9%85%D8%AF%D8%B1%D8%B3%D8%A9%20%D8%A7%D9%84%D9%8A%D9%88%D9%85.)
^ar-Q0434-answer

**ar-Q0435** — من دون الهواء ، لن يبقى شيء على قيد الحياة.

Without air, nothing could live.

Expected form: **لن**

Why: Future negation lan. [[Arabic#^ar-Q0435|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D9%86%20%D8%AF%D9%88%D9%86%20%D8%A7%D9%84%D9%87%D9%88%D8%A7%D8%A1%20%D8%8C%20%D9%84%D9%86%20%D9%8A%D8%A8%D9%82%D9%89%20%D8%B4%D9%8A%D8%A1%20%D8%B9%D9%84%D9%89%20%D9%82%D9%8A%D8%AF%20%D8%A7%D9%84%D8%AD%D9%8A%D8%A7%D8%A9.)
^ar-Q0435-answer

**ar-Q0436** — من دون الهواء ، لن يبقى شيء على قيد الحياة.

Without air, nothing could live.

Why: Future negation lan. [[Arabic#^ar-Q0436|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D9%86%20%D8%AF%D9%88%D9%86%20%D8%A7%D9%84%D9%87%D9%88%D8%A7%D8%A1%20%D8%8C%20%D9%84%D9%86%20%D9%8A%D8%A8%D9%82%D9%89%20%D8%B4%D9%8A%D8%A1%20%D8%B9%D9%84%D9%89%20%D9%82%D9%8A%D8%AF%20%D8%A7%D9%84%D8%AD%D9%8A%D8%A7%D8%A9.)
^ar-Q0436-answer

**ar-Q0437** — لن ترى مصر مجدّدا.

You will never see Egypt again.

Why: Future negation lan. [[Arabic#^ar-Q0437|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%86%20%D8%AA%D8%B1%D9%89%20%D9%85%D8%B5%D8%B1%20%D9%85%D8%AC%D8%AF%D9%91%D8%AF%D8%A7.)
^ar-Q0437-answer

**ar-Q0438** — لن ترى مصر مجدّدا.

You will never see Egypt again.

لن normally introduces future-oriented negation with a subjunctive imperfect form in MSA. The written particle is separate from the verb. Contrast its time relation with لم.

Why: Future negation lan. [[Arabic#^ar-Q0438|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%86%20%D8%AA%D8%B1%D9%89%20%D9%85%D8%B5%D8%B1%20%D9%85%D8%AC%D8%AF%D9%91%D8%AF%D8%A7.)
^ar-Q0438-answer

**ar-Q0439** — لن تستطيع أي من أجهزة الحاسوب الاستمرار في العمل مع بطاقة محروقة.

None of the computers can continue to run with a burnt card.

Expected form: **لن**

Why: Future negation lan. [[Arabic#^ar-Q0439|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%86%20%D8%AA%D8%B3%D8%AA%D8%B7%D9%8A%D8%B9%20%D8%A3%D9%8A%20%D9%85%D9%86%20%D8%A3%D8%AC%D9%87%D8%B2%D8%A9%20%D8%A7%D9%84%D8%AD%D8%A7%D8%B3%D9%88%D8%A8%20%D8%A7%D9%84%D8%A7%D8%B3%D8%AA%D9%85%D8%B1%D8%A7%D8%B1%20%D9%81%D9%8A%20%D8%A7%D9%84%D8%B9%D9%85%D9%84%20%D9%85%D8%B9%20%D8%A8%D8%B7%D8%A7%D9%82%D8%A9%20%D9%85%D8%AD%D8%B1%D9%88%D9%82%D8%A9.)
^ar-Q0439-answer

**ar-Q0440** — لن تستطيع أي من أجهزة الحاسوب الاستمرار في العمل مع بطاقة محروقة.

None of the computers can continue to run with a burnt card.

Expected form: **لن**

Why: Future negation lan. [[Arabic#^ar-Q0440|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%86%20%D8%AA%D8%B3%D8%AA%D8%B7%D9%8A%D8%B9%20%D8%A3%D9%8A%20%D9%85%D9%86%20%D8%A3%D8%AC%D9%87%D8%B2%D8%A9%20%D8%A7%D9%84%D8%AD%D8%A7%D8%B3%D9%88%D8%A8%20%D8%A7%D9%84%D8%A7%D8%B3%D8%AA%D9%85%D8%B1%D8%A7%D8%B1%20%D9%81%D9%8A%20%D8%A7%D9%84%D8%B9%D9%85%D9%84%20%D9%85%D8%B9%20%D8%A8%D8%B7%D8%A7%D9%82%D8%A9%20%D9%85%D8%AD%D8%B1%D9%88%D9%82%D8%A9.)
^ar-Q0440-answer

**ar-Q0441** — وعدني جيم أنه لن يعود.

Jim promised me not to come again.

Expected form: **لن**

Why: Future negation lan. [[Arabic#^ar-Q0441|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%88%D8%B9%D8%AF%D9%86%D9%8A%20%D8%AC%D9%8A%D9%85%20%D8%A3%D9%86%D9%87%20%D9%84%D9%86%20%D9%8A%D8%B9%D9%88%D8%AF.)
^ar-Q0441-answer

**ar-Q0442** — وعدني جيم أنه لن يعود.

Jim promised me not to come again.

Why: Future negation lan. [[Arabic#^ar-Q0442|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%88%D8%B9%D8%AF%D9%86%D9%8A%20%D8%AC%D9%8A%D9%85%20%D8%A3%D9%86%D9%87%20%D9%84%D9%86%20%D9%8A%D8%B9%D9%88%D8%AF.)
^ar-Q0442-answer

**ar-Q0443** — لن يفاجئني ذلك.

That wouldn't surprise me.

Why: Future negation lan. [[Arabic#^ar-Q0443|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%86%20%D9%8A%D9%81%D8%A7%D8%AC%D8%A6%D9%86%D9%8A%20%D8%B0%D9%84%D9%83.)
^ar-Q0443-answer

**ar-Q0444** — لن يفاجئني ذلك.

That wouldn't surprise me.

لن normally introduces future-oriented negation with a subjunctive imperfect form in MSA. The written particle is separate from the verb. Contrast its time relation with لم.

Why: Future negation lan. [[Arabic#^ar-Q0444|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%86%20%D9%8A%D9%81%D8%A7%D8%AC%D8%A6%D9%86%D9%8A%20%D8%B0%D9%84%D9%83.)
^ar-Q0444-answer

**ar-Q0445** — لن أجرح مشاعرك أبدا

I will never hurt you.

Expected form: **لن**

Why: Future negation lan. [[Arabic#^ar-Q0445|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%86%20%D8%A3%D8%AC%D8%B1%D8%AD%20%D9%85%D8%B4%D8%A7%D8%B9%D8%B1%D9%83%20%D8%A3%D8%A8%D8%AF%D8%A7)
^ar-Q0445-answer

**ar-Q0446** — لن أجرح مشاعرك أبدا

I will never hurt you.

Expected form: **لن**

Why: Future negation lan. [[Arabic#^ar-Q0446|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%86%20%D8%A3%D8%AC%D8%B1%D8%AD%20%D9%85%D8%B4%D8%A7%D8%B9%D8%B1%D9%83%20%D8%A3%D8%A8%D8%AF%D8%A7)
^ar-Q0446-answer

**ar-Q0447** — لن أكلمه من الآن فصاعداً.

I won't talk to him anymore.

Expected form: **لن**

Why: Future negation lan. [[Arabic#^ar-Q0447|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%86%20%D8%A3%D9%83%D9%84%D9%85%D9%87%20%D9%85%D9%86%20%D8%A7%D9%84%D8%A2%D9%86%20%D9%81%D8%B5%D8%A7%D8%B9%D8%AF%D8%A7%D9%8B.)
^ar-Q0447-answer

**ar-Q0448** — لن أكلمه من الآن فصاعداً.

I won't talk to him anymore.

Why: Future negation lan. [[Arabic#^ar-Q0448|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%86%20%D8%A3%D9%83%D9%84%D9%85%D9%87%20%D9%85%D9%86%20%D8%A7%D9%84%D8%A2%D9%86%20%D9%81%D8%B5%D8%A7%D8%B9%D8%AF%D8%A7%D9%8B.)
^ar-Q0448-answer

**ar-Q0449** — لن أذهب ما لم تخبرني أين أجد توم.

I'm not leaving until you tell me where I can find Tom.

Why: Future negation lan. [[Arabic#^ar-Q0449|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%86%20%D8%A3%D8%B0%D9%87%D8%A8%20%D9%85%D8%A7%20%D9%84%D9%85%20%D8%AA%D8%AE%D8%A8%D8%B1%D9%86%D9%8A%20%D8%A3%D9%8A%D9%86%20%D8%A3%D8%AC%D8%AF%20%D8%AA%D9%88%D9%85.)
^ar-Q0449-answer

**ar-Q0450** — لن أذهب ما لم تخبرني أين أجد توم.

I'm not leaving until you tell me where I can find Tom.

لن normally introduces future-oriented negation with a subjunctive imperfect form in MSA. The written particle is separate from the verb. Contrast its time relation with لم.

Why: Future negation lan. [[Arabic#^ar-Q0450|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%86%20%D8%A3%D8%B0%D9%87%D8%A8%20%D9%85%D8%A7%20%D9%84%D9%85%20%D8%AA%D8%AE%D8%A8%D8%B1%D9%86%D9%8A%20%D8%A3%D9%8A%D9%86%20%D8%A3%D8%AC%D8%AF%20%D8%AA%D9%88%D9%85.)
^ar-Q0450-answer


### Answers 451–500

**ar-Q0451** — ما زال ذراعي يؤلمني.

My arm still hurts.

Expected form: **ما**

Why: Ma and other negatives. [[Arabic#^ar-Q0451|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D8%A7%20%D8%B2%D8%A7%D9%84%20%D8%B0%D8%B1%D8%A7%D8%B9%D9%8A%20%D9%8A%D8%A4%D9%84%D9%85%D9%86%D9%8A.)
^ar-Q0451-answer

**ar-Q0452** — ما زال ذراعي يؤلمني.

My arm still hurts.

Expected form: **ما**

Why: Ma and other negatives. [[Arabic#^ar-Q0452|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D8%A7%20%D8%B2%D8%A7%D9%84%20%D8%B0%D8%B1%D8%A7%D8%B9%D9%8A%20%D9%8A%D8%A4%D9%84%D9%85%D9%86%D9%8A.)
^ar-Q0452-answer

**ar-Q0453** — ما اسم صديقك؟

What's your friend's name?

Expected form: **ما**

Why: Ma and other negatives. [[Arabic#^ar-Q0453|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D8%A7%20%D8%A7%D8%B3%D9%85%20%D8%B5%D8%AF%D9%8A%D9%82%D9%83%D8%9F)
^ar-Q0453-answer

**ar-Q0454** — ما اسم صديقك؟

What's your friend's name?

Why: Ma and other negatives. [[Arabic#^ar-Q0454|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D8%A7%20%D8%A7%D8%B3%D9%85%20%D8%B5%D8%AF%D9%8A%D9%82%D9%83%D8%9F)
^ar-Q0454-answer

**ar-Q0455** — أخذ سامي ما قلته له على محمل الجدّ.

Sami took what I told him to heart.

Why: Ma and other negatives. [[Arabic#^ar-Q0455|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%AE%D8%B0%20%D8%B3%D8%A7%D9%85%D9%8A%20%D9%85%D8%A7%20%D9%82%D9%84%D8%AA%D9%87%20%D9%84%D9%87%20%D8%B9%D9%84%D9%89%20%D9%85%D8%AD%D9%85%D9%84%20%D8%A7%D9%84%D8%AC%D8%AF%D9%91.)
^ar-Q0455-answer

**ar-Q0456** — أخذ سامي ما قلته له على محمل الجدّ.

Sami took what I told him to heart.

ما has several functions, including negation, interrogation and relative/content uses. A form match alone cannot decide the function. Inspect the surrounding predicate and the translation.

Why: Ma and other negatives. [[Arabic#^ar-Q0456|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%AE%D8%B0%20%D8%B3%D8%A7%D9%85%D9%8A%20%D9%85%D8%A7%20%D9%82%D9%84%D8%AA%D9%87%20%D9%84%D9%87%20%D8%B9%D9%84%D9%89%20%D9%85%D8%AD%D9%85%D9%84%20%D8%A7%D9%84%D8%AC%D8%AF%D9%91.)
^ar-Q0456-answer

**ar-Q0457** — هل توم على ما يرام؟

Is Tom alright?

Expected form: **ما**

Why: Ma and other negatives. [[Arabic#^ar-Q0457|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D9%84%20%D8%AA%D9%88%D9%85%20%D8%B9%D9%84%D9%89%20%D9%85%D8%A7%20%D9%8A%D8%B1%D8%A7%D9%85%D8%9F)
^ar-Q0457-answer

**ar-Q0458** — هل توم على ما يرام؟

Is Tom alright?

Expected form: **ما**

Why: Ma and other negatives. [[Arabic#^ar-Q0458|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D9%84%20%D8%AA%D9%88%D9%85%20%D8%B9%D9%84%D9%89%20%D9%85%D8%A7%20%D9%8A%D8%B1%D8%A7%D9%85%D8%9F)
^ar-Q0458-answer

**ar-Q0459** — ما أقدر أتذكر اسمها .

I can't remember her name.

Expected form: **ما**

Why: Ma and other negatives. [[Arabic#^ar-Q0459|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D8%A7%20%D8%A3%D9%82%D8%AF%D8%B1%20%D8%A3%D8%AA%D8%B0%D9%83%D8%B1%20%D8%A7%D8%B3%D9%85%D9%87%D8%A7%20.)
^ar-Q0459-answer

**ar-Q0460** — ما أقدر أتذكر اسمها .

I can't remember her name.

Why: Ma and other negatives. [[Arabic#^ar-Q0460|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D8%A7%20%D8%A3%D9%82%D8%AF%D8%B1%20%D8%A3%D8%AA%D8%B0%D9%83%D8%B1%20%D8%A7%D8%B3%D9%85%D9%87%D8%A7%20.)
^ar-Q0460-answer

**ar-Q0461** — هل بإمكانك تفسير ما تريده؟

Can you explain what do you want actually?

Why: Ma and other negatives. [[Arabic#^ar-Q0461|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D9%84%20%D8%A8%D8%A5%D9%85%D9%83%D8%A7%D9%86%D9%83%20%D8%AA%D9%81%D8%B3%D9%8A%D8%B1%20%D9%85%D8%A7%20%D8%AA%D8%B1%D9%8A%D8%AF%D9%87%D8%9F)
^ar-Q0461-answer

**ar-Q0462** — هل بإمكانك تفسير ما تريده؟

Can you explain what do you want actually?

ما has several functions, including negation, interrogation and relative/content uses. A form match alone cannot decide the function. Inspect the surrounding predicate and the translation.

Why: Ma and other negatives. [[Arabic#^ar-Q0462|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D9%84%20%D8%A8%D8%A5%D9%85%D9%83%D8%A7%D9%86%D9%83%20%D8%AA%D9%81%D8%B3%D9%8A%D8%B1%20%D9%85%D8%A7%20%D8%AA%D8%B1%D9%8A%D8%AF%D9%87%D8%9F)
^ar-Q0462-answer

**ar-Q0463** — كان هناك ما يكفينا من الطعام.

There was food enough for us all.

Expected form: **ما**

Why: Ma and other negatives. [[Arabic#^ar-Q0463|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D8%A7%D9%86%20%D9%87%D9%86%D8%A7%D9%83%20%D9%85%D8%A7%20%D9%8A%D9%83%D9%81%D9%8A%D9%86%D8%A7%20%D9%85%D9%86%20%D8%A7%D9%84%D8%B7%D8%B9%D8%A7%D9%85.)
^ar-Q0463-answer

**ar-Q0464** — كان هناك ما يكفينا من الطعام.

There was food enough for us all.

Expected form: **ما**

Why: Ma and other negatives. [[Arabic#^ar-Q0464|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D8%A7%D9%86%20%D9%87%D9%86%D8%A7%D9%83%20%D9%85%D8%A7%20%D9%8A%D9%83%D9%81%D9%8A%D9%86%D8%A7%20%D9%85%D9%86%20%D8%A7%D9%84%D8%B7%D8%B9%D8%A7%D9%85.)
^ar-Q0464-answer

**ar-Q0465** — هل يذكّر هذا بشخص ما؟

Does this remind you of anybody?

Expected form: **ما**

Why: Ma and other negatives. [[Arabic#^ar-Q0465|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D9%84%20%D9%8A%D8%B0%D9%83%D9%91%D8%B1%20%D9%87%D8%B0%D8%A7%20%D8%A8%D8%B4%D8%AE%D8%B5%20%D9%85%D8%A7%D8%9F)
^ar-Q0465-answer

**ar-Q0466** — هل يذكّر هذا بشخص ما؟

Does this remind you of anybody?

Why: Ma and other negatives. [[Arabic#^ar-Q0466|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D9%84%20%D9%8A%D8%B0%D9%83%D9%91%D8%B1%20%D9%87%D8%B0%D8%A7%20%D8%A8%D8%B4%D8%AE%D8%B5%20%D9%85%D8%A7%D8%9F)
^ar-Q0466-answer

**ar-Q0467** — هذا كلّ ما ادّخره سامي في حياته.

These are Sami's life savings.

Why: Ma and other negatives. [[Arabic#^ar-Q0467|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D8%B0%D8%A7%20%D9%83%D9%84%D9%91%20%D9%85%D8%A7%20%D8%A7%D8%AF%D9%91%D8%AE%D8%B1%D9%87%20%D8%B3%D8%A7%D9%85%D9%8A%20%D9%81%D9%8A%20%D8%AD%D9%8A%D8%A7%D8%AA%D9%87.)
^ar-Q0467-answer

**ar-Q0468** — هذا كلّ ما ادّخره سامي في حياته.

These are Sami's life savings.

ما has several functions, including negation, interrogation and relative/content uses. A form match alone cannot decide the function. Inspect the surrounding predicate and the translation.

Why: Ma and other negatives. [[Arabic#^ar-Q0468|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D8%B0%D8%A7%20%D9%83%D9%84%D9%91%20%D9%85%D8%A7%20%D8%A7%D8%AF%D9%91%D8%AE%D8%B1%D9%87%20%D8%B3%D8%A7%D9%85%D9%8A%20%D9%81%D9%8A%20%D8%AD%D9%8A%D8%A7%D8%AA%D9%87.)
^ar-Q0468-answer

**ar-Q0469** — لكل فرد حق التمتع بجنسية ما.

Everyone has the right to a nationality.

Expected form: **ما**

Why: Ma and other negatives. [[Arabic#^ar-Q0469|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%83%D9%84%20%D9%81%D8%B1%D8%AF%20%D8%AD%D9%82%20%D8%A7%D9%84%D8%AA%D9%85%D8%AA%D8%B9%20%D8%A8%D8%AC%D9%86%D8%B3%D9%8A%D8%A9%20%D9%85%D8%A7.)
^ar-Q0469-answer

**ar-Q0470** — لكل فرد حق التمتع بجنسية ما.

Everyone has the right to a nationality.

Expected form: **ما**

Why: Ma and other negatives. [[Arabic#^ar-Q0470|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%83%D9%84%20%D9%81%D8%B1%D8%AF%20%D8%AD%D9%82%20%D8%A7%D9%84%D8%AA%D9%85%D8%AA%D8%B9%20%D8%A8%D8%AC%D9%86%D8%B3%D9%8A%D8%A9%20%D9%85%D8%A7.)
^ar-Q0470-answer

**ar-Q0471** — تحصّل فاضل على ما استحقّه تماما.

Fadil got exactly what he deserved.

Expected form: **ما**

Why: Ma and other negatives. [[Arabic#^ar-Q0471|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%AA%D8%AD%D8%B5%D9%91%D9%84%20%D9%81%D8%A7%D8%B6%D9%84%20%D8%B9%D9%84%D9%89%20%D9%85%D8%A7%20%D8%A7%D8%B3%D8%AA%D8%AD%D9%82%D9%91%D9%87%20%D8%AA%D9%85%D8%A7%D9%85%D8%A7.)
^ar-Q0471-answer

**ar-Q0472** — تحصّل فاضل على ما استحقّه تماما.

Fadil got exactly what he deserved.

Why: Ma and other negatives. [[Arabic#^ar-Q0472|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%AA%D8%AD%D8%B5%D9%91%D9%84%20%D9%81%D8%A7%D8%B6%D9%84%20%D8%B9%D9%84%D9%89%20%D9%85%D8%A7%20%D8%A7%D8%B3%D8%AA%D8%AD%D9%82%D9%91%D9%87%20%D8%AA%D9%85%D8%A7%D9%85%D8%A7.)
^ar-Q0472-answer

**ar-Q0473** — ما الذي يفعله كين الآن؟

What's Ken doing now?

Why: Ma and other negatives. [[Arabic#^ar-Q0473|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D8%A7%20%D8%A7%D9%84%D8%B0%D9%8A%20%D9%8A%D9%81%D8%B9%D9%84%D9%87%20%D9%83%D9%8A%D9%86%20%D8%A7%D9%84%D8%A2%D9%86%D8%9F)
^ar-Q0473-answer

**ar-Q0474** — ما الذي يفعله كين الآن؟

What's Ken doing now?

ما has several functions, including negation, interrogation and relative/content uses. A form match alone cannot decide the function. Inspect the surrounding predicate and the translation.

Why: Ma and other negatives. [[Arabic#^ar-Q0474|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D8%A7%20%D8%A7%D9%84%D8%B0%D9%8A%20%D9%8A%D9%81%D8%B9%D9%84%D9%87%20%D9%83%D9%8A%D9%86%20%D8%A7%D9%84%D8%A2%D9%86%D8%9F)
^ar-Q0474-answer

**ar-Q0475** — لربّما عليك إطفاء التلفاز.

Maybe you should turn off the TV.

Expected form: **ما**

Why: Ma and other negatives. [[Arabic#^ar-Q0475|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D8%B1%D8%A8%D9%91%D9%85%D8%A7%20%D8%B9%D9%84%D9%8A%D9%83%20%D8%A5%D8%B7%D9%81%D8%A7%D8%A1%20%D8%A7%D9%84%D8%AA%D9%84%D9%81%D8%A7%D8%B2.)
^ar-Q0475-answer

**ar-Q0476** — لربّما عليك إطفاء التلفاز.

Maybe you should turn off the TV.

Expected form: **ما**

Why: Ma and other negatives. [[Arabic#^ar-Q0476|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D8%B1%D8%A8%D9%91%D9%85%D8%A7%20%D8%B9%D9%84%D9%8A%D9%83%20%D8%A5%D8%B7%D9%81%D8%A7%D8%A1%20%D8%A7%D9%84%D8%AA%D9%84%D9%81%D8%A7%D8%B2.)
^ar-Q0476-answer

**ar-Q0477** — دائما ما كان سامي يرتدي خواتما.

Sami always wore rings.

Expected form: **ما**

Why: Ma and other negatives. [[Arabic#^ar-Q0477|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%AF%D8%A7%D8%A6%D9%85%D8%A7%20%D9%85%D8%A7%20%D9%83%D8%A7%D9%86%20%D8%B3%D8%A7%D9%85%D9%8A%20%D9%8A%D8%B1%D8%AA%D8%AF%D9%8A%20%D8%AE%D9%88%D8%A7%D8%AA%D9%85%D8%A7.)
^ar-Q0477-answer

**ar-Q0478** — دائما ما كان سامي يرتدي خواتما.

Sami always wore rings.

Why: Ma and other negatives. [[Arabic#^ar-Q0478|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%AF%D8%A7%D8%A6%D9%85%D8%A7%20%D9%85%D8%A7%20%D9%83%D8%A7%D9%86%20%D8%B3%D8%A7%D9%85%D9%8A%20%D9%8A%D8%B1%D8%AA%D8%AF%D9%8A%20%D8%AE%D9%88%D8%A7%D8%AA%D9%85%D8%A7.)
^ar-Q0478-answer

**ar-Q0479** — ما ميعاد إقلاع طائرتك؟

What time does your plane leave?

Why: Ma and other negatives. [[Arabic#^ar-Q0479|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D8%A7%20%D9%85%D9%8A%D8%B9%D8%A7%D8%AF%20%D8%A5%D9%82%D9%84%D8%A7%D8%B9%20%D8%B7%D8%A7%D8%A6%D8%B1%D8%AA%D9%83%D8%9F)
^ar-Q0479-answer

**ar-Q0480** — ما ميعاد إقلاع طائرتك؟

What time does your plane leave?

ما has several functions, including negation, interrogation and relative/content uses. A form match alone cannot decide the function. Inspect the surrounding predicate and the translation.

Why: Ma and other negatives. [[Arabic#^ar-Q0480|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D8%A7%20%D9%85%D9%8A%D8%B9%D8%A7%D8%AF%20%D8%A5%D9%82%D9%84%D8%A7%D8%B9%20%D8%B7%D8%A7%D8%A6%D8%B1%D8%AA%D9%83%D8%9F)
^ar-Q0480-answer

**ar-Q0481** — هل كل شيء على ما يرام؟

Is everything all right?

Expected form: **ما**

Why: Ma and other negatives. [[Arabic#^ar-Q0481|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D9%84%20%D9%83%D9%84%20%D8%B4%D9%8A%D8%A1%20%D8%B9%D9%84%D9%89%20%D9%85%D8%A7%20%D9%8A%D8%B1%D8%A7%D9%85%D8%9F)
^ar-Q0481-answer

**ar-Q0482** — هل كل شيء على ما يرام؟

Is everything all right?

Expected form: **ما**

Why: Ma and other negatives. [[Arabic#^ar-Q0482|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D9%84%20%D9%83%D9%84%20%D8%B4%D9%8A%D8%A1%20%D8%B9%D9%84%D9%89%20%D9%85%D8%A7%20%D9%8A%D8%B1%D8%A7%D9%85%D8%9F)
^ar-Q0482-answer

**ar-Q0483** — هذا بالضبط ما كنت أحتاج إليه.

I needed just that.

Expected form: **ما**

Why: Ma and other negatives. [[Arabic#^ar-Q0483|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D8%B0%D8%A7%20%D8%A8%D8%A7%D9%84%D8%B6%D8%A8%D8%B7%20%D9%85%D8%A7%20%D9%83%D9%86%D8%AA%20%D8%A3%D8%AD%D8%AA%D8%A7%D8%AC%20%D8%A5%D9%84%D9%8A%D9%87.)
^ar-Q0483-answer

**ar-Q0484** — هذا بالضبط ما كنت أحتاج إليه.

I needed just that.

Why: Ma and other negatives. [[Arabic#^ar-Q0484|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D8%B0%D8%A7%20%D8%A8%D8%A7%D9%84%D8%B6%D8%A8%D8%B7%20%D9%85%D8%A7%20%D9%83%D9%86%D8%AA%20%D8%A3%D8%AD%D8%AA%D8%A7%D8%AC%20%D8%A5%D9%84%D9%8A%D9%87.)
^ar-Q0484-answer

**ar-Q0485** — إفعل ما يقوله توم.

Do what Tom says.

Why: Ma and other negatives. [[Arabic#^ar-Q0485|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A5%D9%81%D8%B9%D9%84%20%D9%85%D8%A7%20%D9%8A%D9%82%D9%88%D9%84%D9%87%20%D8%AA%D9%88%D9%85.)
^ar-Q0485-answer

**ar-Q0486** — إفعل ما يقوله توم.

Do what Tom says.

ما has several functions, including negation, interrogation and relative/content uses. A form match alone cannot decide the function. Inspect the surrounding predicate and the translation.

Why: Ma and other negatives. [[Arabic#^ar-Q0486|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A5%D9%81%D8%B9%D9%84%20%D9%85%D8%A7%20%D9%8A%D9%82%D9%88%D9%84%D9%87%20%D8%AA%D9%88%D9%85.)
^ar-Q0486-answer

**ar-Q0487** — لا يستطيعُ توم شراء ما يريد لأنه لا يملك ما يكفي من النقود.

Tom can't buy what he needs because he doesn't have enough money.

Expected form: **ما**

Why: Ma and other negatives. [[Arabic#^ar-Q0487|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D8%A7%20%D9%8A%D8%B3%D8%AA%D8%B7%D9%8A%D8%B9%D9%8F%20%D8%AA%D9%88%D9%85%20%D8%B4%D8%B1%D8%A7%D8%A1%20%D9%85%D8%A7%20%D9%8A%D8%B1%D9%8A%D8%AF%20%D9%84%D8%A3%D9%86%D9%87%20%D9%84%D8%A7%20%D9%8A%D9%85%D9%84%D9%83%20%D9%85%D8%A7%20%D9%8A%D9%83%D9%81%D9%8A%20%D9%85%D9%86%20%D8%A7%D9%84%D9%86%D9%82%D9%88%D8%AF.)
^ar-Q0487-answer

**ar-Q0488** — لا يستطيعُ توم شراء ما يريد لأنه لا يملك ما يكفي من النقود.

Tom can't buy what he needs because he doesn't have enough money.

Expected form: **ما**

Why: Ma and other negatives. [[Arabic#^ar-Q0488|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D8%A7%20%D9%8A%D8%B3%D8%AA%D8%B7%D9%8A%D8%B9%D9%8F%20%D8%AA%D9%88%D9%85%20%D8%B4%D8%B1%D8%A7%D8%A1%20%D9%85%D8%A7%20%D9%8A%D8%B1%D9%8A%D8%AF%20%D9%84%D8%A3%D9%86%D9%87%20%D9%84%D8%A7%20%D9%8A%D9%85%D9%84%D9%83%20%D9%85%D8%A7%20%D9%8A%D9%83%D9%81%D9%8A%20%D9%85%D9%86%20%D8%A7%D9%84%D9%86%D9%82%D9%88%D8%AF.)
^ar-Q0488-answer

**ar-Q0489** — ربّما تخبرينني عن مكانٍ أجد فيه توم.

Maybe you can tell me where I can find Tom.

Expected form: **ما**

Why: Ma and other negatives. [[Arabic#^ar-Q0489|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B1%D8%A8%D9%91%D9%85%D8%A7%20%D8%AA%D8%AE%D8%A8%D8%B1%D9%8A%D9%86%D9%86%D9%8A%20%D8%B9%D9%86%20%D9%85%D9%83%D8%A7%D9%86%D9%8D%20%D8%A3%D8%AC%D8%AF%20%D9%81%D9%8A%D9%87%20%D8%AA%D9%88%D9%85.)
^ar-Q0489-answer

**ar-Q0490** — ربّما تخبرينني عن مكانٍ أجد فيه توم.

Maybe you can tell me where I can find Tom.

Why: Ma and other negatives. [[Arabic#^ar-Q0490|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B1%D8%A8%D9%91%D9%85%D8%A7%20%D8%AA%D8%AE%D8%A8%D8%B1%D9%8A%D9%86%D9%86%D9%8A%20%D8%B9%D9%86%20%D9%85%D9%83%D8%A7%D9%86%D9%8D%20%D8%A3%D8%AC%D8%AF%20%D9%81%D9%8A%D9%87%20%D8%AA%D9%88%D9%85.)
^ar-Q0490-answer

**ar-Q0491** — لم يكن سامي يطبخ أبدا.

Sami never cooked.

Why: Ma and other negatives. [[Arabic#^ar-Q0491|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%85%20%D9%8A%D9%83%D9%86%20%D8%B3%D8%A7%D9%85%D9%8A%20%D9%8A%D8%B7%D8%A8%D8%AE%20%D8%A3%D8%A8%D8%AF%D8%A7.)
^ar-Q0491-answer

**ar-Q0492** — لم يكن سامي يطبخ أبدا.

Sami never cooked.

ما has several functions, including negation, interrogation and relative/content uses. A form match alone cannot decide the function. Inspect the surrounding predicate and the translation.

Why: Ma and other negatives. [[Arabic#^ar-Q0492|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%85%20%D9%8A%D9%83%D9%86%20%D8%B3%D8%A7%D9%85%D9%8A%20%D9%8A%D8%B7%D8%A8%D8%AE%20%D8%A3%D8%A8%D8%AF%D8%A7.)
^ar-Q0492-answer

**ar-Q0493** — كل شيء على ما يرام.

Everything is fine.

Expected form: **ما**

Why: Ma and other negatives. [[Arabic#^ar-Q0493|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D9%84%20%D8%B4%D9%8A%D8%A1%20%D8%B9%D9%84%D9%89%20%D9%85%D8%A7%20%D9%8A%D8%B1%D8%A7%D9%85.)
^ar-Q0493-answer

**ar-Q0494** — كل شيء على ما يرام.

Everything is fine.

Expected form: **ما**

Why: Ma and other negatives. [[Arabic#^ar-Q0494|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D9%84%20%D8%B4%D9%8A%D8%A1%20%D8%B9%D9%84%D9%89%20%D9%85%D8%A7%20%D9%8A%D8%B1%D8%A7%D9%85.)
^ar-Q0494-answer

**ar-Q0495** — حان الوقت لفعل شيئاً ما.

It's time to do something.

Expected form: **ما**

Why: Ma and other negatives. [[Arabic#^ar-Q0495|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%AD%D8%A7%D9%86%20%D8%A7%D9%84%D9%88%D9%82%D8%AA%20%D9%84%D9%81%D8%B9%D9%84%20%D8%B4%D9%8A%D8%A6%D8%A7%D9%8B%20%D9%85%D8%A7.)
^ar-Q0495-answer

**ar-Q0496** — حان الوقت لفعل شيئاً ما.

It's time to do something.

Why: Ma and other negatives. [[Arabic#^ar-Q0496|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%AD%D8%A7%D9%86%20%D8%A7%D9%84%D9%88%D9%82%D8%AA%20%D9%84%D9%81%D8%B9%D9%84%20%D8%B4%D9%8A%D8%A6%D8%A7%D9%8B%20%D9%85%D8%A7.)
^ar-Q0496-answer

**ar-Q0497** — ما أجمل هذه الزهرة!

How beautiful this flower is!

Why: Ma and other negatives. [[Arabic#^ar-Q0497|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D8%A7%20%D8%A3%D8%AC%D9%85%D9%84%20%D9%87%D8%B0%D9%87%20%D8%A7%D9%84%D8%B2%D9%87%D8%B1%D8%A9%21)
^ar-Q0497-answer

**ar-Q0498** — ما أجمل هذه الزهرة!

How beautiful this flower is!

ما has several functions, including negation, interrogation and relative/content uses. A form match alone cannot decide the function. Inspect the surrounding predicate and the translation.

Why: Ma and other negatives. [[Arabic#^ar-Q0498|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D8%A7%20%D8%A3%D8%AC%D9%85%D9%84%20%D9%87%D8%B0%D9%87%20%D8%A7%D9%84%D8%B2%D9%87%D8%B1%D8%A9%21)
^ar-Q0498-answer

**ar-Q0499** — ما هو رقم هاتف ليلى؟

What's Layla's phone number?

Expected form: **ما**

Why: Ma and other negatives. [[Arabic#^ar-Q0499|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D8%A7%20%D9%87%D9%88%20%D8%B1%D9%82%D9%85%20%D9%87%D8%A7%D8%AA%D9%81%20%D9%84%D9%8A%D9%84%D9%89%D8%9F)
^ar-Q0499-answer

**ar-Q0500** — ما هو رقم هاتف ليلى؟

What's Layla's phone number?

Expected form: **ما**

Why: Ma and other negatives. [[Arabic#^ar-Q0500|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D8%A7%20%D9%87%D9%88%20%D8%B1%D9%82%D9%85%20%D9%87%D8%A7%D8%AA%D9%81%20%D9%84%D9%8A%D9%84%D9%89%D8%9F)
^ar-Q0500-answer


### Answers 501–550

**ar-Q0501** — يريد سامي أن يتقدّم في حياته.

Sami wants to move on with his life.

Expected form: **يريد**

Why: Common verbal predicates. [[Arabic#^ar-Q0501|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%8A%D8%B1%D9%8A%D8%AF%20%D8%B3%D8%A7%D9%85%D9%8A%20%D8%A3%D9%86%20%D9%8A%D8%AA%D9%82%D8%AF%D9%91%D9%85%20%D9%81%D9%8A%20%D8%AD%D9%8A%D8%A7%D8%AA%D9%87.)
^ar-Q0501-answer

**ar-Q0502** — يريد سامي أن يتقدّم في حياته.

Sami wants to move on with his life.

Why: Common verbal predicates. [[Arabic#^ar-Q0502|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%8A%D8%B1%D9%8A%D8%AF%20%D8%B3%D8%A7%D9%85%D9%8A%20%D8%A3%D9%86%20%D9%8A%D8%AA%D9%82%D8%AF%D9%91%D9%85%20%D9%81%D9%8A%20%D8%AD%D9%8A%D8%A7%D8%AA%D9%87.)
^ar-Q0502-answer

**ar-Q0503** — سامي يحبّ رسوم الأنمي الإباحيّة.

Sami likes anime porn.

Why: Common verbal predicates. [[Arabic#^ar-Q0503|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B3%D8%A7%D9%85%D9%8A%20%D9%8A%D8%AD%D8%A8%D9%91%20%D8%B1%D8%B3%D9%88%D9%85%20%D8%A7%D9%84%D8%A3%D9%86%D9%85%D9%8A%20%D8%A7%D9%84%D8%A5%D8%A8%D8%A7%D8%AD%D9%8A%D9%91%D8%A9.)
^ar-Q0503-answer

**ar-Q0504** — سامي يحبّ رسوم الأنمي الإباحيّة.

Sami likes anime porn.

Arabic verbs encode person, gender, number and aspect/tense series. Imperfect prefixes are part of the agreement pattern. Record a verb’s past, imperfect and verbal noun with a sentence.

Why: Common verbal predicates. [[Arabic#^ar-Q0504|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B3%D8%A7%D9%85%D9%8A%20%D9%8A%D8%AD%D8%A8%D9%91%20%D8%B1%D8%B3%D9%88%D9%85%20%D8%A7%D9%84%D8%A3%D9%86%D9%85%D9%8A%20%D8%A7%D9%84%D8%A5%D8%A8%D8%A7%D8%AD%D9%8A%D9%91%D8%A9.)
^ar-Q0504-answer

**ar-Q0505** — يريد سامي أن يمضي بعض الوقت لوحده.

Sami wants to spend some time alone.

Expected form: **يريد**

Why: Common verbal predicates. [[Arabic#^ar-Q0505|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%8A%D8%B1%D9%8A%D8%AF%20%D8%B3%D8%A7%D9%85%D9%8A%20%D8%A3%D9%86%20%D9%8A%D9%85%D8%B6%D9%8A%20%D8%A8%D8%B9%D8%B6%20%D8%A7%D9%84%D9%88%D9%82%D8%AA%20%D9%84%D9%88%D8%AD%D8%AF%D9%87.)
^ar-Q0505-answer

**ar-Q0506** — يريد سامي أن يمضي بعض الوقت لوحده.

Sami wants to spend some time alone.

Expected form: **يريد**

Why: Common verbal predicates. [[Arabic#^ar-Q0506|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%8A%D8%B1%D9%8A%D8%AF%20%D8%B3%D8%A7%D9%85%D9%8A%20%D8%A3%D9%86%20%D9%8A%D9%85%D8%B6%D9%8A%20%D8%A8%D8%B9%D8%B6%20%D8%A7%D9%84%D9%88%D9%82%D8%AA%20%D9%84%D9%88%D8%AD%D8%AF%D9%87.)
^ar-Q0506-answer

**ar-Q0507** — أعرفُ كَم يعني لكِ.

I know how much he means to you.

Expected form: **أعرف**

Why: Common verbal predicates. [[Arabic#^ar-Q0507|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%B9%D8%B1%D9%81%D9%8F%20%D9%83%D9%8E%D9%85%20%D9%8A%D8%B9%D9%86%D9%8A%20%D9%84%D9%83%D9%90.)
^ar-Q0507-answer

**ar-Q0508** — أعرفُ كَم يعني لكِ.

I know how much he means to you.

Why: Common verbal predicates. [[Arabic#^ar-Q0508|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%B9%D8%B1%D9%81%D9%8F%20%D9%83%D9%8E%D9%85%20%D9%8A%D8%B9%D9%86%D9%8A%20%D9%84%D9%83%D9%90.)
^ar-Q0508-answer

**ar-Q0509** — أريد أن أقول لك شيئاً.

I have something to tell you.

Why: Common verbal predicates. [[Arabic#^ar-Q0509|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%B1%D9%8A%D8%AF%20%D8%A3%D9%86%20%D8%A3%D9%82%D9%88%D9%84%20%D9%84%D9%83%20%D8%B4%D9%8A%D8%A6%D8%A7%D9%8B.)
^ar-Q0509-answer

**ar-Q0510** — أريد أن أقول لك شيئاً.

I have something to tell you.

Arabic verbs encode person, gender, number and aspect/tense series. Imperfect prefixes are part of the agreement pattern. Record a verb’s past, imperfect and verbal noun with a sentence.

Why: Common verbal predicates. [[Arabic#^ar-Q0510|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%B1%D9%8A%D8%AF%20%D8%A3%D9%86%20%D8%A3%D9%82%D9%88%D9%84%20%D9%84%D9%83%20%D8%B4%D9%8A%D8%A6%D8%A7%D9%8B.)
^ar-Q0510-answer

**ar-Q0511** — لأني أريد أن أصير معلمة لغة إنجليزية.

The reason is that I want to be an English teacher.

Expected form: **أريد**

Why: Common verbal predicates. [[Arabic#^ar-Q0511|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D8%A3%D9%86%D9%8A%20%D8%A3%D8%B1%D9%8A%D8%AF%20%D8%A3%D9%86%20%D8%A3%D8%B5%D9%8A%D8%B1%20%D9%85%D8%B9%D9%84%D9%85%D8%A9%20%D9%84%D8%BA%D8%A9%20%D8%A5%D9%86%D8%AC%D9%84%D9%8A%D8%B2%D9%8A%D8%A9.)
^ar-Q0511-answer

**ar-Q0512** — لأني أريد أن أصير معلمة لغة إنجليزية.

The reason is that I want to be an English teacher.

Expected form: **أريد**

Why: Common verbal predicates. [[Arabic#^ar-Q0512|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D8%A3%D9%86%D9%8A%20%D8%A3%D8%B1%D9%8A%D8%AF%20%D8%A3%D9%86%20%D8%A3%D8%B5%D9%8A%D8%B1%20%D9%85%D8%B9%D9%84%D9%85%D8%A9%20%D9%84%D8%BA%D8%A9%20%D8%A5%D9%86%D8%AC%D9%84%D9%8A%D8%B2%D9%8A%D8%A9.)
^ar-Q0512-answer

**ar-Q0513** — قال لي كل شيء.

He told me everything.

Expected form: **قال**

Why: Common verbal predicates. [[Arabic#^ar-Q0513|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%82%D8%A7%D9%84%20%D9%84%D9%8A%20%D9%83%D9%84%20%D8%B4%D9%8A%D8%A1.)
^ar-Q0513-answer

**ar-Q0514** — قال لي كل شيء.

He told me everything.

Why: Common verbal predicates. [[Arabic#^ar-Q0514|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%82%D8%A7%D9%84%20%D9%84%D9%8A%20%D9%83%D9%84%20%D8%B4%D9%8A%D8%A1.)
^ar-Q0514-answer

**ar-Q0515** — أريد تعلم الرومانية.

I want to learn Romanian.

Why: Common verbal predicates. [[Arabic#^ar-Q0515|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%B1%D9%8A%D8%AF%20%D8%AA%D8%B9%D9%84%D9%85%20%D8%A7%D9%84%D8%B1%D9%88%D9%85%D8%A7%D9%86%D9%8A%D8%A9.)
^ar-Q0515-answer

**ar-Q0516** — أريد تعلم الرومانية.

I want to learn Romanian.

Arabic verbs encode person, gender, number and aspect/tense series. Imperfect prefixes are part of the agreement pattern. Record a verb’s past, imperfect and verbal noun with a sentence.

Why: Common verbal predicates. [[Arabic#^ar-Q0516|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%B1%D9%8A%D8%AF%20%D8%AA%D8%B9%D9%84%D9%85%20%D8%A7%D9%84%D8%B1%D9%88%D9%85%D8%A7%D9%86%D9%8A%D8%A9.)
^ar-Q0516-answer

**ar-Q0517** — هل تريد أن تفعلها الآن؟

Do you want to do it right now?

Expected form: **تريد**

Why: Common verbal predicates. [[Arabic#^ar-Q0517|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D9%84%20%D8%AA%D8%B1%D9%8A%D8%AF%20%D8%A3%D9%86%20%D8%AA%D9%81%D8%B9%D9%84%D9%87%D8%A7%20%D8%A7%D9%84%D8%A2%D9%86%D8%9F)
^ar-Q0517-answer

**ar-Q0518** — هل تريد أن تفعلها الآن؟

Do you want to do it right now?

Expected form: **تريد**

Why: Common verbal predicates. [[Arabic#^ar-Q0518|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D9%84%20%D8%AA%D8%B1%D9%8A%D8%AF%20%D8%A3%D9%86%20%D8%AA%D9%81%D8%B9%D9%84%D9%87%D8%A7%20%D8%A7%D9%84%D8%A2%D9%86%D8%9F)
^ar-Q0518-answer

**ar-Q0519** — أحبك و أريد أن أتزوجك.

I'm in love with you and I want to marry you.

Expected form: **أريد**

Why: Common verbal predicates. [[Arabic#^ar-Q0519|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%AD%D8%A8%D9%83%20%D9%88%20%D8%A3%D8%B1%D9%8A%D8%AF%20%D8%A3%D9%86%20%D8%A3%D8%AA%D8%B2%D9%88%D8%AC%D9%83.)
^ar-Q0519-answer

**ar-Q0520** — أحبك و أريد أن أتزوجك.

I'm in love with you and I want to marry you.

Why: Common verbal predicates. [[Arabic#^ar-Q0520|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%AD%D8%A8%D9%83%20%D9%88%20%D8%A3%D8%B1%D9%8A%D8%AF%20%D8%A3%D9%86%20%D8%A3%D8%AA%D8%B2%D9%88%D8%AC%D9%83.)
^ar-Q0520-answer

**ar-Q0521** — سامي لا يعرف ليلى حتّى.

Sami doesn't even know Layla.

Why: Common verbal predicates. [[Arabic#^ar-Q0521|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B3%D8%A7%D9%85%D9%8A%20%D9%84%D8%A7%20%D9%8A%D8%B9%D8%B1%D9%81%20%D9%84%D9%8A%D9%84%D9%89%20%D8%AD%D8%AA%D9%91%D9%89.)
^ar-Q0521-answer

**ar-Q0522** — سامي لا يعرف ليلى حتّى.

Sami doesn't even know Layla.

Arabic verbs encode person, gender, number and aspect/tense series. Imperfect prefixes are part of the agreement pattern. Record a verb’s past, imperfect and verbal noun with a sentence.

Why: Common verbal predicates. [[Arabic#^ar-Q0522|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B3%D8%A7%D9%85%D9%8A%20%D9%84%D8%A7%20%D9%8A%D8%B9%D8%B1%D9%81%20%D9%84%D9%8A%D9%84%D9%89%20%D8%AD%D8%AA%D9%91%D9%89.)
^ar-Q0522-answer

**ar-Q0523** — أنا أحب السباحة, ولكن لا أحب أن أسبح هنا.

I like swimming, but I don't like to swim here.

Expected form: **أحب**

Why: Common verbal predicates. [[Arabic#^ar-Q0523|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D9%86%D8%A7%20%D8%A3%D8%AD%D8%A8%20%D8%A7%D9%84%D8%B3%D8%A8%D8%A7%D8%AD%D8%A9%2C%20%D9%88%D9%84%D9%83%D9%86%20%D9%84%D8%A7%20%D8%A3%D8%AD%D8%A8%20%D8%A3%D9%86%20%D8%A3%D8%B3%D8%A8%D8%AD%20%D9%87%D9%86%D8%A7.)
^ar-Q0523-answer

**ar-Q0524** — أنا أحب السباحة, ولكن لا أحب أن أسبح هنا.

I like swimming, but I don't like to swim here.

Expected form: **أحب**

Why: Common verbal predicates. [[Arabic#^ar-Q0524|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D9%86%D8%A7%20%D8%A3%D8%AD%D8%A8%20%D8%A7%D9%84%D8%B3%D8%A8%D8%A7%D8%AD%D8%A9%2C%20%D9%88%D9%84%D9%83%D9%86%20%D9%84%D8%A7%20%D8%A3%D8%AD%D8%A8%20%D8%A3%D9%86%20%D8%A3%D8%B3%D8%A8%D8%AD%20%D9%87%D9%86%D8%A7.)
^ar-Q0524-answer

**ar-Q0525** — قال فيليب: تعال و تحقق بنفسك.

"Come and see", said Philip.

Expected form: **قال**

Why: Common verbal predicates. [[Arabic#^ar-Q0525|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%82%D8%A7%D9%84%20%D9%81%D9%8A%D9%84%D9%8A%D8%A8%3A%20%D8%AA%D8%B9%D8%A7%D9%84%20%D9%88%20%D8%AA%D8%AD%D9%82%D9%82%20%D8%A8%D9%86%D9%81%D8%B3%D9%83.)
^ar-Q0525-answer

**ar-Q0526** — قال فيليب: تعال و تحقق بنفسك.

"Come and see", said Philip.

Why: Common verbal predicates. [[Arabic#^ar-Q0526|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%82%D8%A7%D9%84%20%D9%81%D9%8A%D9%84%D9%8A%D8%A8%3A%20%D8%AA%D8%B9%D8%A7%D9%84%20%D9%88%20%D8%AA%D8%AD%D9%82%D9%82%20%D8%A8%D9%86%D9%81%D8%B3%D9%83.)
^ar-Q0526-answer

**ar-Q0527** — أعتقد أنّه أكثر رجال الإطفاء شجاعة في العالم.

I think that he's the world's most courageous fire fighter.

Why: Common verbal predicates. [[Arabic#^ar-Q0527|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%B9%D8%AA%D9%82%D8%AF%20%D8%A3%D9%86%D9%91%D9%87%20%D8%A3%D9%83%D8%AB%D8%B1%20%D8%B1%D8%AC%D8%A7%D9%84%20%D8%A7%D9%84%D8%A5%D8%B7%D9%81%D8%A7%D8%A1%20%D8%B4%D8%AC%D8%A7%D8%B9%D8%A9%20%D9%81%D9%8A%20%D8%A7%D9%84%D8%B9%D8%A7%D9%84%D9%85.)
^ar-Q0527-answer

**ar-Q0528** — أعتقد أنّه أكثر رجال الإطفاء شجاعة في العالم.

I think that he's the world's most courageous fire fighter.

Arabic verbs encode person, gender, number and aspect/tense series. Imperfect prefixes are part of the agreement pattern. Record a verb’s past, imperfect and verbal noun with a sentence.

Why: Common verbal predicates. [[Arabic#^ar-Q0528|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%B9%D8%AA%D9%82%D8%AF%20%D8%A3%D9%86%D9%91%D9%87%20%D8%A3%D9%83%D8%AB%D8%B1%20%D8%B1%D8%AC%D8%A7%D9%84%20%D8%A7%D9%84%D8%A5%D8%B7%D9%81%D8%A7%D8%A1%20%D8%B4%D8%AC%D8%A7%D8%B9%D8%A9%20%D9%81%D9%8A%20%D8%A7%D9%84%D8%B9%D8%A7%D9%84%D9%85.)
^ar-Q0528-answer

**ar-Q0529** — أريد أن أصير دكتورًا.

I want to become a doctor.

Expected form: **أريد**

Why: Common verbal predicates. [[Arabic#^ar-Q0529|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%B1%D9%8A%D8%AF%20%D8%A3%D9%86%20%D8%A3%D8%B5%D9%8A%D8%B1%20%D8%AF%D9%83%D8%AA%D9%88%D8%B1%D9%8B%D8%A7.)
^ar-Q0529-answer

**ar-Q0530** — أريد أن أصير دكتورًا.

I want to become a doctor.

Expected form: **أريد**

Why: Common verbal predicates. [[Arabic#^ar-Q0530|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%B1%D9%8A%D8%AF%20%D8%A3%D9%86%20%D8%A3%D8%B5%D9%8A%D8%B1%20%D8%AF%D9%83%D8%AA%D9%88%D8%B1%D9%8B%D8%A7.)
^ar-Q0530-answer

**ar-Q0531** — لا أريد أن ينتهي زواجنا.

I don't want our marriage to end.

Expected form: **أريد**

Why: Common verbal predicates. [[Arabic#^ar-Q0531|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D8%A7%20%D8%A3%D8%B1%D9%8A%D8%AF%20%D8%A3%D9%86%20%D9%8A%D9%86%D8%AA%D9%87%D9%8A%20%D8%B2%D9%88%D8%A7%D8%AC%D9%86%D8%A7.)
^ar-Q0531-answer

**ar-Q0532** — لا أريد أن ينتهي زواجنا.

I don't want our marriage to end.

Why: Common verbal predicates. [[Arabic#^ar-Q0532|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D8%A7%20%D8%A3%D8%B1%D9%8A%D8%AF%20%D8%A3%D9%86%20%D9%8A%D9%86%D8%AA%D9%87%D9%8A%20%D8%B2%D9%88%D8%A7%D8%AC%D9%86%D8%A7.)
^ar-Q0532-answer

**ar-Q0533** — أريد أن أنسى الأمر.

I want to forget about it.

Why: Common verbal predicates. [[Arabic#^ar-Q0533|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%B1%D9%8A%D8%AF%20%D8%A3%D9%86%20%D8%A3%D9%86%D8%B3%D9%89%20%D8%A7%D9%84%D8%A3%D9%85%D8%B1.)
^ar-Q0533-answer

**ar-Q0534** — أريد أن أنسى الأمر.

I want to forget about it.

Arabic verbs encode person, gender, number and aspect/tense series. Imperfect prefixes are part of the agreement pattern. Record a verb’s past, imperfect and verbal noun with a sentence.

Why: Common verbal predicates. [[Arabic#^ar-Q0534|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%B1%D9%8A%D8%AF%20%D8%A3%D9%86%20%D8%A3%D9%86%D8%B3%D9%89%20%D8%A7%D9%84%D8%A3%D9%85%D8%B1.)
^ar-Q0534-answer

**ar-Q0535** — أريد رؤية توم قبل مغادرتي.

I want to see Tom before I leave.

Expected form: **أريد**

Why: Common verbal predicates. [[Arabic#^ar-Q0535|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%B1%D9%8A%D8%AF%20%D8%B1%D8%A4%D9%8A%D8%A9%20%D8%AA%D9%88%D9%85%20%D9%82%D8%A8%D9%84%20%D9%85%D8%BA%D8%A7%D8%AF%D8%B1%D8%AA%D9%8A.)
^ar-Q0535-answer

**ar-Q0536** — أريد رؤية توم قبل مغادرتي.

I want to see Tom before I leave.

Expected form: **أريد**

Why: Common verbal predicates. [[Arabic#^ar-Q0536|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%B1%D9%8A%D8%AF%20%D8%B1%D8%A4%D9%8A%D8%A9%20%D8%AA%D9%88%D9%85%20%D9%82%D8%A8%D9%84%20%D9%85%D8%BA%D8%A7%D8%AF%D8%B1%D8%AA%D9%8A.)
^ar-Q0536-answer

**ar-Q0537** — أريد أن أتعلّم الأمازيغية و العربية.

I want to learn Berber and Arabic.

Expected form: **أريد**

Why: Common verbal predicates. [[Arabic#^ar-Q0537|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%B1%D9%8A%D8%AF%20%D8%A3%D9%86%20%D8%A3%D8%AA%D8%B9%D9%84%D9%91%D9%85%20%D8%A7%D9%84%D8%A3%D9%85%D8%A7%D8%B2%D9%8A%D8%BA%D9%8A%D8%A9%20%D9%88%20%D8%A7%D9%84%D8%B9%D8%B1%D8%A8%D9%8A%D8%A9.)
^ar-Q0537-answer

**ar-Q0538** — أريد أن أتعلّم الأمازيغية و العربية.

I want to learn Berber and Arabic.

Why: Common verbal predicates. [[Arabic#^ar-Q0538|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%B1%D9%8A%D8%AF%20%D8%A3%D9%86%20%D8%A3%D8%AA%D8%B9%D9%84%D9%91%D9%85%20%D8%A7%D9%84%D8%A3%D9%85%D8%A7%D8%B2%D9%8A%D8%BA%D9%8A%D8%A9%20%D9%88%20%D8%A7%D9%84%D8%B9%D8%B1%D8%A8%D9%8A%D8%A9.)
^ar-Q0538-answer

**ar-Q0539** — لا أعتقد أنه كان لديها صديق آخر بعد أن فارقت جمال.

After Jamal, I don't think she has had any other boyfriend.

Why: Common verbal predicates. [[Arabic#^ar-Q0539|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D8%A7%20%D8%A3%D8%B9%D8%AA%D9%82%D8%AF%20%D8%A3%D9%86%D9%87%20%D9%83%D8%A7%D9%86%20%D9%84%D8%AF%D9%8A%D9%87%D8%A7%20%D8%B5%D8%AF%D9%8A%D9%82%20%D8%A2%D8%AE%D8%B1%20%D8%A8%D8%B9%D8%AF%20%D8%A3%D9%86%20%D9%81%D8%A7%D8%B1%D9%82%D8%AA%20%D8%AC%D9%85%D8%A7%D9%84.)
^ar-Q0539-answer

**ar-Q0540** — لا أعتقد أنه كان لديها صديق آخر بعد أن فارقت جمال.

After Jamal, I don't think she has had any other boyfriend.

Arabic verbs encode person, gender, number and aspect/tense series. Imperfect prefixes are part of the agreement pattern. Record a verb’s past, imperfect and verbal noun with a sentence.

Why: Common verbal predicates. [[Arabic#^ar-Q0540|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D8%A7%20%D8%A3%D8%B9%D8%AA%D9%82%D8%AF%20%D8%A3%D9%86%D9%87%20%D9%83%D8%A7%D9%86%20%D9%84%D8%AF%D9%8A%D9%87%D8%A7%20%D8%B5%D8%AF%D9%8A%D9%82%20%D8%A2%D8%AE%D8%B1%20%D8%A8%D8%B9%D8%AF%20%D8%A3%D9%86%20%D9%81%D8%A7%D8%B1%D9%82%D8%AA%20%D8%AC%D9%85%D8%A7%D9%84.)
^ar-Q0540-answer

**ar-Q0541** — أي شخص يريد القدوم فهو مدعوّ.

Anybody who wants to come is invited.

Expected form: **يريد**

Why: Common verbal predicates. [[Arabic#^ar-Q0541|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D9%8A%20%D8%B4%D8%AE%D8%B5%20%D9%8A%D8%B1%D9%8A%D8%AF%20%D8%A7%D9%84%D9%82%D8%AF%D9%88%D9%85%20%D9%81%D9%87%D9%88%20%D9%85%D8%AF%D8%B9%D9%88%D9%91.)
^ar-Q0541-answer

**ar-Q0542** — أي شخص يريد القدوم فهو مدعوّ.

Anybody who wants to come is invited.

Expected form: **يريد**

Why: Common verbal predicates. [[Arabic#^ar-Q0542|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D9%8A%20%D8%B4%D8%AE%D8%B5%20%D9%8A%D8%B1%D9%8A%D8%AF%20%D8%A7%D9%84%D9%82%D8%AF%D9%88%D9%85%20%D9%81%D9%87%D9%88%20%D9%85%D8%AF%D8%B9%D9%88%D9%91.)
^ar-Q0542-answer

**ar-Q0543** — لا أريد أن أعمل.

I don't want to work.

Expected form: **أريد**

Why: Common verbal predicates. [[Arabic#^ar-Q0543|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D8%A7%20%D8%A3%D8%B1%D9%8A%D8%AF%20%D8%A3%D9%86%20%D8%A3%D8%B9%D9%85%D9%84.)
^ar-Q0543-answer

**ar-Q0544** — لا أريد أن أعمل.

I don't want to work.

Why: Common verbal predicates. [[Arabic#^ar-Q0544|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D8%A7%20%D8%A3%D8%B1%D9%8A%D8%AF%20%D8%A3%D9%86%20%D8%A3%D8%B9%D9%85%D9%84.)
^ar-Q0544-answer

**ar-Q0545** — لا أريد سامي هنا.

I don't want Sami here.

Why: Common verbal predicates. [[Arabic#^ar-Q0545|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D8%A7%20%D8%A3%D8%B1%D9%8A%D8%AF%20%D8%B3%D8%A7%D9%85%D9%8A%20%D9%87%D9%86%D8%A7.)
^ar-Q0545-answer

**ar-Q0546** — لا أريد سامي هنا.

I don't want Sami here.

Arabic verbs encode person, gender, number and aspect/tense series. Imperfect prefixes are part of the agreement pattern. Record a verb’s past, imperfect and verbal noun with a sentence.

Why: Common verbal predicates. [[Arabic#^ar-Q0546|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D8%A7%20%D8%A3%D8%B1%D9%8A%D8%AF%20%D8%B3%D8%A7%D9%85%D9%8A%20%D9%87%D9%86%D8%A7.)
^ar-Q0546-answer

**ar-Q0547** — سامي يحبّ ليلى.

Sami likes Layla.

Expected form: **يحب**

Why: Common verbal predicates. [[Arabic#^ar-Q0547|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B3%D8%A7%D9%85%D9%8A%20%D9%8A%D8%AD%D8%A8%D9%91%20%D9%84%D9%8A%D9%84%D9%89.)
^ar-Q0547-answer

**ar-Q0548** — سامي يحبّ ليلى.

Sami likes Layla.

Expected form: **يحب**

Why: Common verbal predicates. [[Arabic#^ar-Q0548|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B3%D8%A7%D9%85%D9%8A%20%D9%8A%D8%AD%D8%A8%D9%91%20%D9%84%D9%8A%D9%84%D9%89.)
^ar-Q0548-answer

**ar-Q0549** — إنها تريد أن تعمل في المستشفى.

She wants to work at the hospital.

Expected form: **تريد**

Why: Common verbal predicates. [[Arabic#^ar-Q0549|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A5%D9%86%D9%87%D8%A7%20%D8%AA%D8%B1%D9%8A%D8%AF%20%D8%A3%D9%86%20%D8%AA%D8%B9%D9%85%D9%84%20%D9%81%D9%8A%20%D8%A7%D9%84%D9%85%D8%B3%D8%AA%D8%B4%D9%81%D9%89.)
^ar-Q0549-answer

**ar-Q0550** — إنها تريد أن تعمل في المستشفى.

She wants to work at the hospital.

Why: Common verbal predicates. [[Arabic#^ar-Q0550|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A5%D9%86%D9%87%D8%A7%20%D8%AA%D8%B1%D9%8A%D8%AF%20%D8%A3%D9%86%20%D8%AA%D8%B9%D9%85%D9%84%20%D9%81%D9%8A%20%D8%A7%D9%84%D9%85%D8%B3%D8%AA%D8%B4%D9%81%D9%89.)
^ar-Q0550-answer


### Answers 551–600

**ar-Q0551** — سوف يكون عندنا الكثير من الطعام.

We'll have plenty of food.

Why: Future markers. [[Arabic#^ar-Q0551|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B3%D9%88%D9%81%20%D9%8A%D9%83%D9%88%D9%86%20%D8%B9%D9%86%D8%AF%D9%86%D8%A7%20%D8%A7%D9%84%D9%83%D8%AB%D9%8A%D8%B1%20%D9%85%D9%86%20%D8%A7%D9%84%D8%B7%D8%B9%D8%A7%D9%85.)
^ar-Q0551-answer

**ar-Q0552** — سوف يكون عندنا الكثير من الطعام.

We'll have plenty of food.

MSA uses سوف or prefixed سـ in common future constructions. A prefixed marker is not a separate word in spelling. Dialect future markers differ and belong in the dialect material.

Why: Future markers. [[Arabic#^ar-Q0552|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B3%D9%88%D9%81%20%D9%8A%D9%83%D9%88%D9%86%20%D8%B9%D9%86%D8%AF%D9%86%D8%A7%20%D8%A7%D9%84%D9%83%D8%AB%D9%8A%D8%B1%20%D9%85%D9%86%20%D8%A7%D9%84%D8%B7%D8%B9%D8%A7%D9%85.)
^ar-Q0552-answer

**ar-Q0553** — سوف أشتري هديّة لتوم.

I'll buy a gift for Tom.

Expected form: **سوف**

Why: Future markers. [[Arabic#^ar-Q0553|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B3%D9%88%D9%81%20%D8%A3%D8%B4%D8%AA%D8%B1%D9%8A%20%D9%87%D8%AF%D9%8A%D9%91%D8%A9%20%D9%84%D8%AA%D9%88%D9%85.)
^ar-Q0553-answer

**ar-Q0554** — سوف أشتري هديّة لتوم.

I'll buy a gift for Tom.

Expected form: **سوف**

Why: Future markers. [[Arabic#^ar-Q0554|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B3%D9%88%D9%81%20%D8%A3%D8%B4%D8%AA%D8%B1%D9%8A%20%D9%87%D8%AF%D9%8A%D9%91%D8%A9%20%D9%84%D8%AA%D9%88%D9%85.)
^ar-Q0554-answer

**ar-Q0555** — لقد وعدني أنه سيأتي على الساعة الرابعة.

He promised me that he would come at four.

Expected form: **سيأتي**

Why: Future markers. [[Arabic#^ar-Q0555|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%82%D8%AF%20%D9%88%D8%B9%D8%AF%D9%86%D9%8A%20%D8%A3%D9%86%D9%87%20%D8%B3%D9%8A%D8%A3%D8%AA%D9%8A%20%D8%B9%D9%84%D9%89%20%D8%A7%D9%84%D8%B3%D8%A7%D8%B9%D8%A9%20%D8%A7%D9%84%D8%B1%D8%A7%D8%A8%D8%B9%D8%A9.)
^ar-Q0555-answer

**ar-Q0556** — لقد وعدني أنه سيأتي على الساعة الرابعة.

He promised me that he would come at four.

Why: Future markers. [[Arabic#^ar-Q0556|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%82%D8%AF%20%D9%88%D8%B9%D8%AF%D9%86%D9%8A%20%D8%A3%D9%86%D9%87%20%D8%B3%D9%8A%D8%A3%D8%AA%D9%8A%20%D8%B9%D9%84%D9%89%20%D8%A7%D9%84%D8%B3%D8%A7%D8%B9%D8%A9%20%D8%A7%D9%84%D8%B1%D8%A7%D8%A8%D8%B9%D8%A9.)
^ar-Q0556-answer

**ar-Q0557** — سوف أعود بعد قليل.

I will be back soon.

Why: Future markers. [[Arabic#^ar-Q0557|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B3%D9%88%D9%81%20%D8%A3%D8%B9%D9%88%D8%AF%20%D8%A8%D8%B9%D8%AF%20%D9%82%D9%84%D9%8A%D9%84.)
^ar-Q0557-answer

**ar-Q0558** — سوف أعود بعد قليل.

I will be back soon.

MSA uses سوف or prefixed سـ in common future constructions. A prefixed marker is not a separate word in spelling. Dialect future markers differ and belong in the dialect material.

Why: Future markers. [[Arabic#^ar-Q0558|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B3%D9%88%D9%81%20%D8%A3%D8%B9%D9%88%D8%AF%20%D8%A8%D8%B9%D8%AF%20%D9%82%D9%84%D9%8A%D9%84.)
^ar-Q0558-answer

**ar-Q0559** — سوف اقابله غدا.

I'll meet him tomorrow.

Expected form: **سوف**

Why: Future markers. [[Arabic#^ar-Q0559|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B3%D9%88%D9%81%20%D8%A7%D9%82%D8%A7%D8%A8%D9%84%D9%87%20%D8%BA%D8%AF%D8%A7.)
^ar-Q0559-answer

**ar-Q0560** — سوف اقابله غدا.

I'll meet him tomorrow.

Expected form: **سوف**

Why: Future markers. [[Arabic#^ar-Q0560|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B3%D9%88%D9%81%20%D8%A7%D9%82%D8%A7%D8%A8%D9%84%D9%87%20%D8%BA%D8%AF%D8%A7.)
^ar-Q0560-answer

**ar-Q0561** — أين ستكون في الأوّل من جانفي 2016؟

Where will you be on January 1st, 2016?

Expected form: **ستكون**

Why: Future markers. [[Arabic#^ar-Q0561|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D9%8A%D9%86%20%D8%B3%D8%AA%D9%83%D9%88%D9%86%20%D9%81%D9%8A%20%D8%A7%D9%84%D8%A3%D9%88%D9%91%D9%84%20%D9%85%D9%86%20%D8%AC%D8%A7%D9%86%D9%81%D9%8A%202016%D8%9F)
^ar-Q0561-answer

**ar-Q0562** — أين ستكون في الأوّل من جانفي 2016؟

Where will you be on January 1st, 2016?

Why: Future markers. [[Arabic#^ar-Q0562|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D9%8A%D9%86%20%D8%B3%D8%AA%D9%83%D9%88%D9%86%20%D9%81%D9%8A%20%D8%A7%D9%84%D8%A3%D9%88%D9%91%D9%84%20%D9%85%D9%86%20%D8%AC%D8%A7%D9%86%D9%81%D9%8A%202016%D8%9F)
^ar-Q0562-answer

**ar-Q0563** — البرنامج سوف ينتهي بالنشيد الوطني .

The program will finish with the national anthem.

Why: Future markers. [[Arabic#^ar-Q0563|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A7%D9%84%D8%A8%D8%B1%D9%86%D8%A7%D9%85%D8%AC%20%D8%B3%D9%88%D9%81%20%D9%8A%D9%86%D8%AA%D9%87%D9%8A%20%D8%A8%D8%A7%D9%84%D9%86%D8%B4%D9%8A%D8%AF%20%D8%A7%D9%84%D9%88%D8%B7%D9%86%D9%8A%20.)
^ar-Q0563-answer

**ar-Q0564** — البرنامج سوف ينتهي بالنشيد الوطني .

The program will finish with the national anthem.

MSA uses سوف or prefixed سـ in common future constructions. A prefixed marker is not a separate word in spelling. Dialect future markers differ and belong in the dialect material.

Why: Future markers. [[Arabic#^ar-Q0564|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A7%D9%84%D8%A8%D8%B1%D9%86%D8%A7%D9%85%D8%AC%20%D8%B3%D9%88%D9%81%20%D9%8A%D9%86%D8%AA%D9%87%D9%8A%20%D8%A8%D8%A7%D9%84%D9%86%D8%B4%D9%8A%D8%AF%20%D8%A7%D9%84%D9%88%D8%B7%D9%86%D9%8A%20.)
^ar-Q0564-answer

**ar-Q0565** — سأذهب وآخذ حمّاما.

I'm going to go take a shower.

Expected form: **سأذهب**

Why: Future markers. [[Arabic#^ar-Q0565|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B3%D8%A3%D8%B0%D9%87%D8%A8%20%D9%88%D8%A2%D8%AE%D8%B0%20%D8%AD%D9%85%D9%91%D8%A7%D9%85%D8%A7.)
^ar-Q0565-answer

**ar-Q0566** — سأذهب وآخذ حمّاما.

I'm going to go take a shower.

Expected form: **سأذهب**

Why: Future markers. [[Arabic#^ar-Q0566|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B3%D8%A3%D8%B0%D9%87%D8%A8%20%D9%88%D8%A2%D8%AE%D8%B0%20%D8%AD%D9%85%D9%91%D8%A7%D9%85%D8%A7.)
^ar-Q0566-answer

**ar-Q0567** — سيكون سامي على ما يرام.

Sami is going to be OK.

Expected form: **سيكون**

Why: Future markers. [[Arabic#^ar-Q0567|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B3%D9%8A%D9%83%D9%88%D9%86%20%D8%B3%D8%A7%D9%85%D9%8A%20%D8%B9%D9%84%D9%89%20%D9%85%D8%A7%20%D9%8A%D8%B1%D8%A7%D9%85.)
^ar-Q0567-answer

**ar-Q0568** — سيكون سامي على ما يرام.

Sami is going to be OK.

Why: Future markers. [[Arabic#^ar-Q0568|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B3%D9%8A%D9%83%D9%88%D9%86%20%D8%B3%D8%A7%D9%85%D9%8A%20%D8%B9%D9%84%D9%89%20%D9%85%D8%A7%20%D9%8A%D8%B1%D8%A7%D9%85.)
^ar-Q0568-answer

**ar-Q0569** — أغلبنا سيفعل هذا.

Most of us will do that.

Why: Future markers. [[Arabic#^ar-Q0569|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%BA%D9%84%D8%A8%D9%86%D8%A7%20%D8%B3%D9%8A%D9%81%D8%B9%D9%84%20%D9%87%D8%B0%D8%A7.)
^ar-Q0569-answer

**ar-Q0570** — أغلبنا سيفعل هذا.

Most of us will do that.

MSA uses سوف or prefixed سـ in common future constructions. A prefixed marker is not a separate word in spelling. Dialect future markers differ and belong in the dialect material.

Why: Future markers. [[Arabic#^ar-Q0570|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%BA%D9%84%D8%A8%D9%86%D8%A7%20%D8%B3%D9%8A%D9%81%D8%B9%D9%84%20%D9%87%D8%B0%D8%A7.)
^ar-Q0570-answer

**ar-Q0571** — هل سيأتي غداً؟

Will he come tomorrow?

Expected form: **سيأتي**

Why: Future markers. [[Arabic#^ar-Q0571|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D9%84%20%D8%B3%D9%8A%D8%A3%D8%AA%D9%8A%20%D8%BA%D8%AF%D8%A7%D9%8B%D8%9F)
^ar-Q0571-answer

**ar-Q0572** — هل سيأتي غداً؟

Will he come tomorrow?

Expected form: **سيأتي**

Why: Future markers. [[Arabic#^ar-Q0572|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D9%84%20%D8%B3%D9%8A%D8%A3%D8%AA%D9%8A%20%D8%BA%D8%AF%D8%A7%D9%8B%D8%9F)
^ar-Q0572-answer

**ar-Q0573** — ستكون مشغولاً في الغد.

You will be busy tomorrow.

Expected form: **ستكون**

Why: Future markers. [[Arabic#^ar-Q0573|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B3%D8%AA%D9%83%D9%88%D9%86%20%D9%85%D8%B4%D8%BA%D9%88%D9%84%D8%A7%D9%8B%20%D9%81%D9%8A%20%D8%A7%D9%84%D8%BA%D8%AF.)
^ar-Q0573-answer

**ar-Q0574** — ستكون مشغولاً في الغد.

You will be busy tomorrow.

Why: Future markers. [[Arabic#^ar-Q0574|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B3%D8%AA%D9%83%D9%88%D9%86%20%D9%85%D8%B4%D8%BA%D9%88%D9%84%D8%A7%D9%8B%20%D9%81%D9%8A%20%D8%A7%D9%84%D8%BA%D8%AF.)
^ar-Q0574-answer

**ar-Q0575** — سوف أفعلها سواءاً وافقت أم لم توافق.

I am going to do it whether you agree or not.

Why: Future markers. [[Arabic#^ar-Q0575|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B3%D9%88%D9%81%20%D8%A3%D9%81%D8%B9%D9%84%D9%87%D8%A7%20%D8%B3%D9%88%D8%A7%D8%A1%D8%A7%D9%8B%20%D9%88%D8%A7%D9%81%D9%82%D8%AA%20%D8%A3%D9%85%20%D9%84%D9%85%20%D8%AA%D9%88%D8%A7%D9%81%D9%82.)
^ar-Q0575-answer

**ar-Q0576** — سوف أفعلها سواءاً وافقت أم لم توافق.

I am going to do it whether you agree or not.

MSA uses سوف or prefixed سـ in common future constructions. A prefixed marker is not a separate word in spelling. Dialect future markers differ and belong in the dialect material.

Why: Future markers. [[Arabic#^ar-Q0576|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B3%D9%88%D9%81%20%D8%A3%D9%81%D8%B9%D9%84%D9%87%D8%A7%20%D8%B3%D9%88%D8%A7%D8%A1%D8%A7%D9%8B%20%D9%88%D8%A7%D9%81%D9%82%D8%AA%20%D8%A3%D9%85%20%D9%84%D9%85%20%D8%AA%D9%88%D8%A7%D9%81%D9%82.)
^ar-Q0576-answer

**ar-Q0577** — خمسة عشر في المئة من المساكن ستكون بأسعار معقولة، بحيث أن الأسر ذات الدخل المنخفض سوف تصبح قادرة على شراء أو استئجار المنازل في المنطقة.

Fifteen per cent of the housing will be affordable, so that low-income families will be able to buy or rent homes in the area.

Expected form: **ستكون**

Why: Future markers. [[Arabic#^ar-Q0577|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%AE%D9%85%D8%B3%D8%A9%20%D8%B9%D8%B4%D8%B1%20%D9%81%D9%8A%20%D8%A7%D9%84%D9%85%D8%A6%D8%A9%20%D9%85%D9%86%20%D8%A7%D9%84%D9%85%D8%B3%D8%A7%D9%83%D9%86%20%D8%B3%D8%AA%D9%83%D9%88%D9%86%20%D8%A8%D8%A3%D8%B3%D8%B9%D8%A7%D8%B1%20%D9%85%D8%B9%D9%82%D9%88%D9%84%D8%A9%D8%8C%20%D8%A8%D8%AD%D9%8A%D8%AB%20%D8%A3%D9%86%20%D8%A7%D9%84%D8%A3%D8%B3%D8%B1%20%D8%B0%D8%A7%D8%AA%20%D8%A7%D9%84%D8%AF%D8%AE%D9%84%20%D8%A7%D9%84%D9%85%D9%86%D8%AE%D9%81%D8%B6%20%D8%B3%D9%88%D9%81%20%D8%AA%D8%B5%D8%A8%D8%AD%20%D9%82%D8%A7%D8%AF%D8%B1%D8%A9%20%D8%B9%D9%84%D9%89%20%D8%B4%D8%B1%D8%A7%D8%A1%20%D8%A3%D9%88%20%D8%A7%D8%B3%D8%AA%D8%A6%D8%AC%D8%A7%D8%B1%20%D8%A7%D9%84%D9%85%D9%86%D8%A7%D8%B2%D9%84%20%D9%81%D9%8A%20%D8%A7%D9%84%D9%85%D9%86%D8%B7%D9%82%D8%A9.)
^ar-Q0577-answer

**ar-Q0578** — خمسة عشر في المئة من المساكن ستكون بأسعار معقولة، بحيث أن الأسر ذات الدخل المنخفض سوف تصبح قادرة على شراء أو استئجار المنازل في المنطقة.

Fifteen per cent of the housing will be affordable, so that low-income families will be able to buy or rent homes in the area.

Expected form: **ستكون**

Why: Future markers. [[Arabic#^ar-Q0578|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%AE%D9%85%D8%B3%D8%A9%20%D8%B9%D8%B4%D8%B1%20%D9%81%D9%8A%20%D8%A7%D9%84%D9%85%D8%A6%D8%A9%20%D9%85%D9%86%20%D8%A7%D9%84%D9%85%D8%B3%D8%A7%D9%83%D9%86%20%D8%B3%D8%AA%D9%83%D9%88%D9%86%20%D8%A8%D8%A3%D8%B3%D8%B9%D8%A7%D8%B1%20%D9%85%D8%B9%D9%82%D9%88%D9%84%D8%A9%D8%8C%20%D8%A8%D8%AD%D9%8A%D8%AB%20%D8%A3%D9%86%20%D8%A7%D9%84%D8%A3%D8%B3%D8%B1%20%D8%B0%D8%A7%D8%AA%20%D8%A7%D9%84%D8%AF%D8%AE%D9%84%20%D8%A7%D9%84%D9%85%D9%86%D8%AE%D9%81%D8%B6%20%D8%B3%D9%88%D9%81%20%D8%AA%D8%B5%D8%A8%D8%AD%20%D9%82%D8%A7%D8%AF%D8%B1%D8%A9%20%D8%B9%D9%84%D9%89%20%D8%B4%D8%B1%D8%A7%D8%A1%20%D8%A3%D9%88%20%D8%A7%D8%B3%D8%AA%D8%A6%D8%AC%D8%A7%D8%B1%20%D8%A7%D9%84%D9%85%D9%86%D8%A7%D8%B2%D9%84%20%D9%81%D9%8A%20%D8%A7%D9%84%D9%85%D9%86%D8%B7%D9%82%D8%A9.)
^ar-Q0578-answer

**ar-Q0579** — حتى و لو أمطرت، سأذهب للسباحة غدا.

Even if it rains, I'll go swimming tomorrow.

Expected form: **سأذهب**

Why: Future markers. [[Arabic#^ar-Q0579|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%AD%D8%AA%D9%89%20%D9%88%20%D9%84%D9%88%20%D8%A3%D9%85%D8%B7%D8%B1%D8%AA%D8%8C%20%D8%B3%D8%A3%D8%B0%D9%87%D8%A8%20%D9%84%D9%84%D8%B3%D8%A8%D8%A7%D8%AD%D8%A9%20%D8%BA%D8%AF%D8%A7.)
^ar-Q0579-answer

**ar-Q0580** — حتى و لو أمطرت، سأذهب للسباحة غدا.

Even if it rains, I'll go swimming tomorrow.

Why: Future markers. [[Arabic#^ar-Q0580|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%AD%D8%AA%D9%89%20%D9%88%20%D9%84%D9%88%20%D8%A3%D9%85%D8%B7%D8%B1%D8%AA%D8%8C%20%D8%B3%D8%A3%D8%B0%D9%87%D8%A8%20%D9%84%D9%84%D8%B3%D8%A8%D8%A7%D8%AD%D8%A9%20%D8%BA%D8%AF%D8%A7.)
^ar-Q0580-answer

**ar-Q0581** — سأكون في الحمام.

I'm going to be in the bathroom.

Why: Future markers. [[Arabic#^ar-Q0581|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B3%D8%A3%D9%83%D9%88%D9%86%20%D9%81%D9%8A%20%D8%A7%D9%84%D8%AD%D9%85%D8%A7%D9%85.)
^ar-Q0581-answer

**ar-Q0582** — سأكون في الحمام.

I'm going to be in the bathroom.

MSA uses سوف or prefixed سـ in common future constructions. A prefixed marker is not a separate word in spelling. Dialect future markers differ and belong in the dialect material.

Why: Future markers. [[Arabic#^ar-Q0582|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B3%D8%A3%D9%83%D9%88%D9%86%20%D9%81%D9%8A%20%D8%A7%D9%84%D8%AD%D9%85%D8%A7%D9%85.)
^ar-Q0582-answer

**ar-Q0583** — إن كنت ستبدأ عملا جديدا، فسيكون عليك تجهيز خطة.

If you're going to start a new business, you need a business plan.

Expected form: **سيكون**

Why: Future markers. [[Arabic#^ar-Q0583|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A5%D9%86%20%D9%83%D9%86%D8%AA%20%D8%B3%D8%AA%D8%A8%D8%AF%D8%A3%20%D8%B9%D9%85%D9%84%D8%A7%20%D8%AC%D8%AF%D9%8A%D8%AF%D8%A7%D8%8C%20%D9%81%D8%B3%D9%8A%D9%83%D9%88%D9%86%20%D8%B9%D9%84%D9%8A%D9%83%20%D8%AA%D8%AC%D9%87%D9%8A%D8%B2%20%D8%AE%D8%B7%D8%A9.)
^ar-Q0583-answer

**ar-Q0584** — إن كنت ستبدأ عملا جديدا، فسيكون عليك تجهيز خطة.

If you're going to start a new business, you need a business plan.

Expected form: **سيكون**

Why: Future markers. [[Arabic#^ar-Q0584|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A5%D9%86%20%D9%83%D9%86%D8%AA%20%D8%B3%D8%AA%D8%A8%D8%AF%D8%A3%20%D8%B9%D9%85%D9%84%D8%A7%20%D8%AC%D8%AF%D9%8A%D8%AF%D8%A7%D8%8C%20%D9%81%D8%B3%D9%8A%D9%83%D9%88%D9%86%20%D8%B9%D9%84%D9%8A%D9%83%20%D8%AA%D8%AC%D9%87%D9%8A%D8%B2%20%D8%AE%D8%B7%D8%A9.)
^ar-Q0584-answer

**ar-Q0585** — سوف يكون في البيت غداً.

He will be at home tomorrow.

Expected form: **سوف**

Why: Future markers. [[Arabic#^ar-Q0585|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B3%D9%88%D9%81%20%D9%8A%D9%83%D9%88%D9%86%20%D9%81%D9%8A%20%D8%A7%D9%84%D8%A8%D9%8A%D8%AA%20%D8%BA%D8%AF%D8%A7%D9%8B.)
^ar-Q0585-answer

**ar-Q0586** — سوف يكون في البيت غداً.

He will be at home tomorrow.

Why: Future markers. [[Arabic#^ar-Q0586|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B3%D9%88%D9%81%20%D9%8A%D9%83%D9%88%D9%86%20%D9%81%D9%8A%20%D8%A7%D9%84%D8%A8%D9%8A%D8%AA%20%D8%BA%D8%AF%D8%A7%D9%8B.)
^ar-Q0586-answer

**ar-Q0587** — لو كان الجو جيدا سأذهب إلى الحديقة

If the weather is good, I'll go to the park.

Why: Future markers. [[Arabic#^ar-Q0587|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%88%20%D9%83%D8%A7%D9%86%20%D8%A7%D9%84%D8%AC%D9%88%20%D8%AC%D9%8A%D8%AF%D8%A7%20%D8%B3%D8%A3%D8%B0%D9%87%D8%A8%20%D8%A5%D9%84%D9%89%20%D8%A7%D9%84%D8%AD%D8%AF%D9%8A%D9%82%D8%A9)
^ar-Q0587-answer

**ar-Q0588** — لو كان الجو جيدا سأذهب إلى الحديقة

If the weather is good, I'll go to the park.

MSA uses سوف or prefixed سـ in common future constructions. A prefixed marker is not a separate word in spelling. Dialect future markers differ and belong in the dialect material.

Why: Future markers. [[Arabic#^ar-Q0588|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%88%20%D9%83%D8%A7%D9%86%20%D8%A7%D9%84%D8%AC%D9%88%20%D8%AC%D9%8A%D8%AF%D8%A7%20%D8%B3%D8%A3%D8%B0%D9%87%D8%A8%20%D8%A5%D9%84%D9%89%20%D8%A7%D9%84%D8%AD%D8%AF%D9%8A%D9%82%D8%A9)
^ar-Q0588-answer

**ar-Q0589** — أنا لست متأكّداً أنّني سأكون قادراً على القدوم معك

I am not sure whether I will be able to come with you.

Expected form: **سأكون**

Why: Future markers. [[Arabic#^ar-Q0589|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D9%86%D8%A7%20%D9%84%D8%B3%D8%AA%20%D9%85%D8%AA%D8%A3%D9%83%D9%91%D8%AF%D8%A7%D9%8B%20%D8%A3%D9%86%D9%91%D9%86%D9%8A%20%D8%B3%D8%A3%D9%83%D9%88%D9%86%20%D9%82%D8%A7%D8%AF%D8%B1%D8%A7%D9%8B%20%D8%B9%D9%84%D9%89%20%D8%A7%D9%84%D9%82%D8%AF%D9%88%D9%85%20%D9%85%D8%B9%D9%83)
^ar-Q0589-answer

**ar-Q0590** — أنا لست متأكّداً أنّني سأكون قادراً على القدوم معك

I am not sure whether I will be able to come with you.

Expected form: **سأكون**

Why: Future markers. [[Arabic#^ar-Q0590|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D9%86%D8%A7%20%D9%84%D8%B3%D8%AA%20%D9%85%D8%AA%D8%A3%D9%83%D9%91%D8%AF%D8%A7%D9%8B%20%D8%A3%D9%86%D9%91%D9%86%D9%8A%20%D8%B3%D8%A3%D9%83%D9%88%D9%86%20%D9%82%D8%A7%D8%AF%D8%B1%D8%A7%D9%8B%20%D8%B9%D9%84%D9%89%20%D8%A7%D9%84%D9%82%D8%AF%D9%88%D9%85%20%D9%85%D8%B9%D9%83)
^ar-Q0590-answer

**ar-Q0591** — سيكون حسنًا منك أن تخبره مقدمًا.

You would do well to tell it to him in advance.

Expected form: **سيكون**

Why: Future markers. [[Arabic#^ar-Q0591|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B3%D9%8A%D9%83%D9%88%D9%86%20%D8%AD%D8%B3%D9%86%D9%8B%D8%A7%20%D9%85%D9%86%D9%83%20%D8%A3%D9%86%20%D8%AA%D8%AE%D8%A8%D8%B1%D9%87%20%D9%85%D9%82%D8%AF%D9%85%D9%8B%D8%A7.)
^ar-Q0591-answer

**ar-Q0592** — سيكون حسنًا منك أن تخبره مقدمًا.

You would do well to tell it to him in advance.

Why: Future markers. [[Arabic#^ar-Q0592|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B3%D9%8A%D9%83%D9%88%D9%86%20%D8%AD%D8%B3%D9%86%D9%8B%D8%A7%20%D9%85%D9%86%D9%83%20%D8%A3%D9%86%20%D8%AA%D8%AE%D8%A8%D8%B1%D9%87%20%D9%85%D9%82%D8%AF%D9%85%D9%8B%D8%A7.)
^ar-Q0592-answer

**ar-Q0593** — سأذهب لإقلال سامي من منزل ليلى.

I'm going to pick up Sami at Layla's house.

Why: Future markers. [[Arabic#^ar-Q0593|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B3%D8%A3%D8%B0%D9%87%D8%A8%20%D9%84%D8%A5%D9%82%D9%84%D8%A7%D9%84%20%D8%B3%D8%A7%D9%85%D9%8A%20%D9%85%D9%86%20%D9%85%D9%86%D8%B2%D9%84%20%D9%84%D9%8A%D9%84%D9%89.)
^ar-Q0593-answer

**ar-Q0594** — سأذهب لإقلال سامي من منزل ليلى.

I'm going to pick up Sami at Layla's house.

MSA uses سوف or prefixed سـ in common future constructions. A prefixed marker is not a separate word in spelling. Dialect future markers differ and belong in the dialect material.

Why: Future markers. [[Arabic#^ar-Q0594|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B3%D8%A3%D8%B0%D9%87%D8%A8%20%D9%84%D8%A5%D9%82%D9%84%D8%A7%D9%84%20%D8%B3%D8%A7%D9%85%D9%8A%20%D9%85%D9%86%20%D9%85%D9%86%D8%B2%D9%84%20%D9%84%D9%8A%D9%84%D9%89.)
^ar-Q0594-answer

**ar-Q0595** — سوف يتوقف المطر قريبا

It'll stop raining before long.

Expected form: **سوف**

Why: Future markers. [[Arabic#^ar-Q0595|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B3%D9%88%D9%81%20%D9%8A%D8%AA%D9%88%D9%82%D9%81%20%D8%A7%D9%84%D9%85%D8%B7%D8%B1%20%D9%82%D8%B1%D9%8A%D8%A8%D8%A7)
^ar-Q0595-answer

**ar-Q0596** — سوف يتوقف المطر قريبا

It'll stop raining before long.

Expected form: **سوف**

Why: Future markers. [[Arabic#^ar-Q0596|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B3%D9%88%D9%81%20%D9%8A%D8%AA%D9%88%D9%82%D9%81%20%D8%A7%D9%84%D9%85%D8%B7%D8%B1%20%D9%82%D8%B1%D9%8A%D8%A8%D8%A7)
^ar-Q0596-answer

**ar-Q0597** — سيكون على سامي المغادرة.

Sami will have to leave.

Expected form: **سيكون**

Why: Future markers. [[Arabic#^ar-Q0597|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B3%D9%8A%D9%83%D9%88%D9%86%20%D8%B9%D9%84%D9%89%20%D8%B3%D8%A7%D9%85%D9%8A%20%D8%A7%D9%84%D9%85%D8%BA%D8%A7%D8%AF%D8%B1%D8%A9.)
^ar-Q0597-answer

**ar-Q0598** — سيكون على سامي المغادرة.

Sami will have to leave.

Why: Future markers. [[Arabic#^ar-Q0598|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B3%D9%8A%D9%83%D9%88%D9%86%20%D8%B9%D9%84%D9%89%20%D8%B3%D8%A7%D9%85%D9%8A%20%D8%A7%D9%84%D9%85%D8%BA%D8%A7%D8%AF%D8%B1%D8%A9.)
^ar-Q0598-answer

**ar-Q0599** — سوف آكل التفاحة.

I'll eat the apple.

Why: Future markers. [[Arabic#^ar-Q0599|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B3%D9%88%D9%81%20%D8%A2%D9%83%D9%84%20%D8%A7%D9%84%D8%AA%D9%81%D8%A7%D8%AD%D8%A9.)
^ar-Q0599-answer

**ar-Q0600** — سوف آكل التفاحة.

I'll eat the apple.

MSA uses سوف or prefixed سـ in common future constructions. A prefixed marker is not a separate word in spelling. Dialect future markers differ and belong in the dialect material.

Why: Future markers. [[Arabic#^ar-Q0600|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B3%D9%88%D9%81%20%D8%A2%D9%83%D9%84%20%D8%A7%D9%84%D8%AA%D9%81%D8%A7%D8%AD%D8%A9.)
^ar-Q0600-answer


### Answers 601–650

**ar-Q0601** — نشأ سامي في مجتمع مسلم.

Sami grew up in a Muslim community.

Expected form: **في**

Why: Prepositions. [[Arabic#^ar-Q0601|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%86%D8%B4%D8%A3%20%D8%B3%D8%A7%D9%85%D9%8A%20%D9%81%D9%8A%20%D9%85%D8%AC%D8%AA%D9%85%D8%B9%20%D9%85%D8%B3%D9%84%D9%85.)
^ar-Q0601-answer

**ar-Q0602** — نشأ سامي في مجتمع مسلم.

Sami grew up in a Muslim community.

Expected form: **في**

Why: Prepositions. [[Arabic#^ar-Q0602|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%86%D8%B4%D8%A3%20%D8%B3%D8%A7%D9%85%D9%8A%20%D9%81%D9%8A%20%D9%85%D8%AC%D8%AA%D9%85%D8%B9%20%D9%85%D8%B3%D9%84%D9%85.)
^ar-Q0602-answer

**ar-Q0603** — بإمكانك استخدامها في أي وقت.

You can use it anytime.

Expected form: **في**

Why: Prepositions. [[Arabic#^ar-Q0603|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A8%D8%A5%D9%85%D9%83%D8%A7%D9%86%D9%83%20%D8%A7%D8%B3%D8%AA%D8%AE%D8%AF%D8%A7%D9%85%D9%87%D8%A7%20%D9%81%D9%8A%20%D8%A3%D9%8A%20%D9%88%D9%82%D8%AA.)
^ar-Q0603-answer

**ar-Q0604** — بإمكانك استخدامها في أي وقت.

You can use it anytime.

Why: Prepositions. [[Arabic#^ar-Q0604|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A8%D8%A5%D9%85%D9%83%D8%A7%D9%86%D9%83%20%D8%A7%D8%B3%D8%AA%D8%AE%D8%AF%D8%A7%D9%85%D9%87%D8%A7%20%D9%81%D9%8A%20%D8%A3%D9%8A%20%D9%88%D9%82%D8%AA.)
^ar-Q0604-answer

**ar-Q0605** — دُعيتُ إلى حفلة ساتشِكو.

I was invited to Sachiko's party.

Why: Prepositions. [[Arabic#^ar-Q0605|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%AF%D9%8F%D8%B9%D9%8A%D8%AA%D9%8F%20%D8%A5%D9%84%D9%89%20%D8%AD%D9%81%D9%84%D8%A9%20%D8%B3%D8%A7%D8%AA%D8%B4%D9%90%D9%83%D9%88.)
^ar-Q0605-answer

**ar-Q0606** — دُعيتُ إلى حفلة ساتشِكو.

I was invited to Sachiko's party.

Prepositions mark relations and govern genitive in fully inflected MSA. Their complements can be nouns or pronominal suffixes. English in/on/to choices do not map one-to-one.

Why: Prepositions. [[Arabic#^ar-Q0606|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%AF%D9%8F%D8%B9%D9%8A%D8%AA%D9%8F%20%D8%A5%D9%84%D9%89%20%D8%AD%D9%81%D9%84%D8%A9%20%D8%B3%D8%A7%D8%AA%D8%B4%D9%90%D9%83%D9%88.)
^ar-Q0606-answer

**ar-Q0607** — سامي من مصر.

Sami is from Egypt.

Expected form: **من**

Why: Prepositions. [[Arabic#^ar-Q0607|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B3%D8%A7%D9%85%D9%8A%20%D9%85%D9%86%20%D9%85%D8%B5%D8%B1.)
^ar-Q0607-answer

**ar-Q0608** — سامي من مصر.

Sami is from Egypt.

Expected form: **من**

Why: Prepositions. [[Arabic#^ar-Q0608|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B3%D8%A7%D9%85%D9%8A%20%D9%85%D9%86%20%D9%85%D8%B5%D8%B1.)
^ar-Q0608-answer

**ar-Q0609** — منّاد يقطن في منزل رائع.

Sami lives in a wonderful house.

Expected form: **من**

Why: Prepositions. [[Arabic#^ar-Q0609|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D9%86%D9%91%D8%A7%D8%AF%20%D9%8A%D9%82%D8%B7%D9%86%20%D9%81%D9%8A%20%D9%85%D9%86%D8%B2%D9%84%20%D8%B1%D8%A7%D8%A6%D8%B9.)
^ar-Q0609-answer

**ar-Q0610** — منّاد يقطن في منزل رائع.

Sami lives in a wonderful house.

Why: Prepositions. [[Arabic#^ar-Q0610|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D9%86%D9%91%D8%A7%D8%AF%20%D9%8A%D9%82%D8%B7%D9%86%20%D9%81%D9%8A%20%D9%85%D9%86%D8%B2%D9%84%20%D8%B1%D8%A7%D8%A6%D8%B9.)
^ar-Q0610-answer

**ar-Q0611** — في عام ١٩٤٨م ، تأسست دولة يهودية.

In 1948, a Jewish state was founded.

Why: Prepositions. [[Arabic#^ar-Q0611|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%81%D9%8A%20%D8%B9%D8%A7%D9%85%20%D9%A1%D9%A9%D9%A4%D9%A8%D9%85%20%D8%8C%20%D8%AA%D8%A3%D8%B3%D8%B3%D8%AA%20%D8%AF%D9%88%D9%84%D8%A9%20%D9%8A%D9%87%D9%88%D8%AF%D9%8A%D8%A9.)
^ar-Q0611-answer

**ar-Q0612** — في عام ١٩٤٨م ، تأسست دولة يهودية.

In 1948, a Jewish state was founded.

Prepositions mark relations and govern genitive in fully inflected MSA. Their complements can be nouns or pronominal suffixes. English in/on/to choices do not map one-to-one.

Why: Prepositions. [[Arabic#^ar-Q0612|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%81%D9%8A%20%D8%B9%D8%A7%D9%85%20%D9%A1%D9%A9%D9%A4%D9%A8%D9%85%20%D8%8C%20%D8%AA%D8%A3%D8%B3%D8%B3%D8%AA%20%D8%AF%D9%88%D9%84%D8%A9%20%D9%8A%D9%87%D9%88%D8%AF%D9%8A%D8%A9.)
^ar-Q0612-answer

**ar-Q0613** — ضحّت ليلى بسامي كي تخرج نفسها من المأزق.

Layla threw Sami under the bus.

Expected form: **من**

Why: Prepositions. [[Arabic#^ar-Q0613|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B6%D8%AD%D9%91%D8%AA%20%D9%84%D9%8A%D9%84%D9%89%20%D8%A8%D8%B3%D8%A7%D9%85%D9%8A%20%D9%83%D9%8A%20%D8%AA%D8%AE%D8%B1%D8%AC%20%D9%86%D9%81%D8%B3%D9%87%D8%A7%20%D9%85%D9%86%20%D8%A7%D9%84%D9%85%D8%A3%D8%B2%D9%82.)
^ar-Q0613-answer

**ar-Q0614** — ضحّت ليلى بسامي كي تخرج نفسها من المأزق.

Layla threw Sami under the bus.

Expected form: **من**

Why: Prepositions. [[Arabic#^ar-Q0614|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B6%D8%AD%D9%91%D8%AA%20%D9%84%D9%8A%D9%84%D9%89%20%D8%A8%D8%B3%D8%A7%D9%85%D9%8A%20%D9%83%D9%8A%20%D8%AA%D8%AE%D8%B1%D8%AC%20%D9%86%D9%81%D8%B3%D9%87%D8%A7%20%D9%85%D9%86%20%D8%A7%D9%84%D9%85%D8%A3%D8%B2%D9%82.)
^ar-Q0614-answer

**ar-Q0615** — أختك تحب مشاهدة مبارزة السومو على التلفاز.

Your sister enjoys watching sumo wrestling on TV.

Expected form: **على**

Why: Prepositions. [[Arabic#^ar-Q0615|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%AE%D8%AA%D9%83%20%D8%AA%D8%AD%D8%A8%20%D9%85%D8%B4%D8%A7%D9%87%D8%AF%D8%A9%20%D9%85%D8%A8%D8%A7%D8%B1%D8%B2%D8%A9%20%D8%A7%D9%84%D8%B3%D9%88%D9%85%D9%88%20%D8%B9%D9%84%D9%89%20%D8%A7%D9%84%D8%AA%D9%84%D9%81%D8%A7%D8%B2.)
^ar-Q0615-answer

**ar-Q0616** — أختك تحب مشاهدة مبارزة السومو على التلفاز.

Your sister enjoys watching sumo wrestling on TV.

Why: Prepositions. [[Arabic#^ar-Q0616|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%AE%D8%AA%D9%83%20%D8%AA%D8%AD%D8%A8%20%D9%85%D8%B4%D8%A7%D9%87%D8%AF%D8%A9%20%D9%85%D8%A8%D8%A7%D8%B1%D8%B2%D8%A9%20%D8%A7%D9%84%D8%B3%D9%88%D9%85%D9%88%20%D8%B9%D9%84%D9%89%20%D8%A7%D9%84%D8%AA%D9%84%D9%81%D8%A7%D8%B2.)
^ar-Q0616-answer

**ar-Q0617** — إنك تخيفني في بعض الأحيان.

Sometimes you scare me.

Why: Prepositions. [[Arabic#^ar-Q0617|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A5%D9%86%D9%83%20%D8%AA%D8%AE%D9%8A%D9%81%D9%86%D9%8A%20%D9%81%D9%8A%20%D8%A8%D8%B9%D8%B6%20%D8%A7%D9%84%D8%A3%D8%AD%D9%8A%D8%A7%D9%86.)
^ar-Q0617-answer

**ar-Q0618** — إنك تخيفني في بعض الأحيان.

Sometimes you scare me.

Prepositions mark relations and govern genitive in fully inflected MSA. Their complements can be nouns or pronominal suffixes. English in/on/to choices do not map one-to-one.

Why: Prepositions. [[Arabic#^ar-Q0618|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A5%D9%86%D9%83%20%D8%AA%D8%AE%D9%8A%D9%81%D9%86%D9%8A%20%D9%81%D9%8A%20%D8%A8%D8%B9%D8%B6%20%D8%A7%D9%84%D8%A3%D8%AD%D9%8A%D8%A7%D9%86.)
^ar-Q0618-answer

**ar-Q0619** — صعدت إلى الحافلة الخطأ.

I got on the wrong bus.

Expected form: **إلى**

Why: Prepositions. [[Arabic#^ar-Q0619|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B5%D8%B9%D8%AF%D8%AA%20%D8%A5%D9%84%D9%89%20%D8%A7%D9%84%D8%AD%D8%A7%D9%81%D9%84%D8%A9%20%D8%A7%D9%84%D8%AE%D8%B7%D8%A3.)
^ar-Q0619-answer

**ar-Q0620** — صعدت إلى الحافلة الخطأ.

I got on the wrong bus.

Expected form: **إلى**

Why: Prepositions. [[Arabic#^ar-Q0620|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B5%D8%B9%D8%AF%D8%AA%20%D8%A5%D9%84%D9%89%20%D8%A7%D9%84%D8%AD%D8%A7%D9%81%D9%84%D8%A9%20%D8%A7%D9%84%D8%AE%D8%B7%D8%A3.)
^ar-Q0620-answer

**ar-Q0621** — وضع فاضل جثة دانية في مزبلة.

Fadil stuffed Dania's body into a trash can.

Expected form: **في**

Why: Prepositions. [[Arabic#^ar-Q0621|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%88%D8%B6%D8%B9%20%D9%81%D8%A7%D8%B6%D9%84%20%D8%AC%D8%AB%D8%A9%20%D8%AF%D8%A7%D9%86%D9%8A%D8%A9%20%D9%81%D9%8A%20%D9%85%D8%B2%D8%A8%D9%84%D8%A9.)
^ar-Q0621-answer

**ar-Q0622** — وضع فاضل جثة دانية في مزبلة.

Fadil stuffed Dania's body into a trash can.

Why: Prepositions. [[Arabic#^ar-Q0622|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%88%D8%B6%D8%B9%20%D9%81%D8%A7%D8%B6%D9%84%20%D8%AC%D8%AB%D8%A9%20%D8%AF%D8%A7%D9%86%D9%8A%D8%A9%20%D9%81%D9%8A%20%D9%85%D8%B2%D8%A8%D9%84%D8%A9.)
^ar-Q0622-answer

**ar-Q0623** — نظر إلى السماء.

He looked up at the sky.

Why: Prepositions. [[Arabic#^ar-Q0623|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%86%D8%B8%D8%B1%20%D8%A5%D9%84%D9%89%20%D8%A7%D9%84%D8%B3%D9%85%D8%A7%D8%A1.)
^ar-Q0623-answer

**ar-Q0624** — نظر إلى السماء.

He looked up at the sky.

Prepositions mark relations and govern genitive in fully inflected MSA. Their complements can be nouns or pronominal suffixes. English in/on/to choices do not map one-to-one.

Why: Prepositions. [[Arabic#^ar-Q0624|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%86%D8%B8%D8%B1%20%D8%A5%D9%84%D9%89%20%D8%A7%D9%84%D8%B3%D9%85%D8%A7%D8%A1.)
^ar-Q0624-answer

**ar-Q0625** — واصل سامي بناء مشواره الفنّي في موسيقى الهيبهوب.

Sami continued building his hiphop musical career.

Expected form: **في**

Why: Prepositions. [[Arabic#^ar-Q0625|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%88%D8%A7%D8%B5%D9%84%20%D8%B3%D8%A7%D9%85%D9%8A%20%D8%A8%D9%86%D8%A7%D8%A1%20%D9%85%D8%B4%D9%88%D8%A7%D8%B1%D9%87%20%D8%A7%D9%84%D9%81%D9%86%D9%91%D9%8A%20%D9%81%D9%8A%20%D9%85%D9%88%D8%B3%D9%8A%D9%82%D9%89%20%D8%A7%D9%84%D9%87%D9%8A%D8%A8%D9%87%D9%88%D8%A8.)
^ar-Q0625-answer

**ar-Q0626** — واصل سامي بناء مشواره الفنّي في موسيقى الهيبهوب.

Sami continued building his hiphop musical career.

Expected form: **في**

Why: Prepositions. [[Arabic#^ar-Q0626|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%88%D8%A7%D8%B5%D9%84%20%D8%B3%D8%A7%D9%85%D9%8A%20%D8%A8%D9%86%D8%A7%D8%A1%20%D9%85%D8%B4%D9%88%D8%A7%D8%B1%D9%87%20%D8%A7%D9%84%D9%81%D9%86%D9%91%D9%8A%20%D9%81%D9%8A%20%D9%85%D9%88%D8%B3%D9%8A%D9%82%D9%89%20%D8%A7%D9%84%D9%87%D9%8A%D8%A8%D9%87%D9%88%D8%A8.)
^ar-Q0626-answer

**ar-Q0627** — اثنان وخمسون بالمئة من النساء البريطانيات يفضلن الشوكولاته على الجنس.

Fifty-two per cent of British women prefer chocolate to sex.

Expected form: **من**

Why: Prepositions. [[Arabic#^ar-Q0627|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A7%D8%AB%D9%86%D8%A7%D9%86%20%D9%88%D8%AE%D9%85%D8%B3%D9%88%D9%86%20%D8%A8%D8%A7%D9%84%D9%85%D8%A6%D8%A9%20%D9%85%D9%86%20%D8%A7%D9%84%D9%86%D8%B3%D8%A7%D8%A1%20%D8%A7%D9%84%D8%A8%D8%B1%D9%8A%D8%B7%D8%A7%D9%86%D9%8A%D8%A7%D8%AA%20%D9%8A%D9%81%D8%B6%D9%84%D9%86%20%D8%A7%D9%84%D8%B4%D9%88%D9%83%D9%88%D9%84%D8%A7%D8%AA%D9%87%20%D8%B9%D9%84%D9%89%20%D8%A7%D9%84%D8%AC%D9%86%D8%B3.)
^ar-Q0627-answer

**ar-Q0628** — اثنان وخمسون بالمئة من النساء البريطانيات يفضلن الشوكولاته على الجنس.

Fifty-two per cent of British women prefer chocolate to sex.

Why: Prepositions. [[Arabic#^ar-Q0628|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A7%D8%AB%D9%86%D8%A7%D9%86%20%D9%88%D8%AE%D9%85%D8%B3%D9%88%D9%86%20%D8%A8%D8%A7%D9%84%D9%85%D8%A6%D8%A9%20%D9%85%D9%86%20%D8%A7%D9%84%D9%86%D8%B3%D8%A7%D8%A1%20%D8%A7%D9%84%D8%A8%D8%B1%D9%8A%D8%B7%D8%A7%D9%86%D9%8A%D8%A7%D8%AA%20%D9%8A%D9%81%D8%B6%D9%84%D9%86%20%D8%A7%D9%84%D8%B4%D9%88%D9%83%D9%88%D9%84%D8%A7%D8%AA%D9%87%20%D8%B9%D9%84%D9%89%20%D8%A7%D9%84%D8%AC%D9%86%D8%B3.)
^ar-Q0628-answer

**ar-Q0629** — هل تساعدني في حل واجبي؟

Will you help me with my homework?

Why: Prepositions. [[Arabic#^ar-Q0629|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D9%84%20%D8%AA%D8%B3%D8%A7%D8%B9%D8%AF%D9%86%D9%8A%20%D9%81%D9%8A%20%D8%AD%D9%84%20%D9%88%D8%A7%D8%AC%D8%A8%D9%8A%D8%9F)
^ar-Q0629-answer

**ar-Q0630** — هل تساعدني في حل واجبي؟

Will you help me with my homework?

Prepositions mark relations and govern genitive in fully inflected MSA. Their complements can be nouns or pronominal suffixes. English in/on/to choices do not map one-to-one.

Why: Prepositions. [[Arabic#^ar-Q0630|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D9%84%20%D8%AA%D8%B3%D8%A7%D8%B9%D8%AF%D9%86%D9%8A%20%D9%81%D9%8A%20%D8%AD%D9%84%20%D9%88%D8%A7%D8%AC%D8%A8%D9%8A%D8%9F)
^ar-Q0630-answer

**ar-Q0631** — انتقل إلى منزلي.

Move in here.

Expected form: **إلى**

Why: Prepositions. [[Arabic#^ar-Q0631|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A7%D9%86%D8%AA%D9%82%D9%84%20%D8%A5%D9%84%D9%89%20%D9%85%D9%86%D8%B2%D9%84%D9%8A.)
^ar-Q0631-answer

**ar-Q0632** — انتقل إلى منزلي.

Move in here.

Expected form: **إلى**

Why: Prepositions. [[Arabic#^ar-Q0632|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A7%D9%86%D8%AA%D9%82%D9%84%20%D8%A5%D9%84%D9%89%20%D9%85%D9%86%D8%B2%D9%84%D9%8A.)
^ar-Q0632-answer

**ar-Q0633** — انظر إليّ من فضلك.

Please look at me.

Expected form: **من**

Why: Prepositions. [[Arabic#^ar-Q0633|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A7%D9%86%D8%B8%D8%B1%20%D8%A5%D9%84%D9%8A%D9%91%20%D9%85%D9%86%20%D9%81%D8%B6%D9%84%D9%83.)
^ar-Q0633-answer

**ar-Q0634** — انظر إليّ من فضلك.

Please look at me.

Why: Prepositions. [[Arabic#^ar-Q0634|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A7%D9%86%D8%B8%D8%B1%20%D8%A5%D9%84%D9%8A%D9%91%20%D9%85%D9%86%20%D9%81%D8%B6%D9%84%D9%83.)
^ar-Q0634-answer

**ar-Q0635** — يصبح جبل فوجي مغطًى بالثلج في الشتاء.

Mt. Fuji is covered with snow in winter.

Why: Prepositions. [[Arabic#^ar-Q0635|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%8A%D8%B5%D8%A8%D8%AD%20%D8%AC%D8%A8%D9%84%20%D9%81%D9%88%D8%AC%D9%8A%20%D9%85%D8%BA%D8%B7%D9%8B%D9%89%20%D8%A8%D8%A7%D9%84%D8%AB%D9%84%D8%AC%20%D9%81%D9%8A%20%D8%A7%D9%84%D8%B4%D8%AA%D8%A7%D8%A1.)
^ar-Q0635-answer

**ar-Q0636** — يصبح جبل فوجي مغطًى بالثلج في الشتاء.

Mt. Fuji is covered with snow in winter.

Prepositions mark relations and govern genitive in fully inflected MSA. Their complements can be nouns or pronominal suffixes. English in/on/to choices do not map one-to-one.

Why: Prepositions. [[Arabic#^ar-Q0636|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%8A%D8%B5%D8%A8%D8%AD%20%D8%AC%D8%A8%D9%84%20%D9%81%D9%88%D8%AC%D9%8A%20%D9%85%D8%BA%D8%B7%D9%8B%D9%89%20%D8%A8%D8%A7%D9%84%D8%AB%D9%84%D8%AC%20%D9%81%D9%8A%20%D8%A7%D9%84%D8%B4%D8%AA%D8%A7%D8%A1.)
^ar-Q0636-answer

**ar-Q0637** — سامي في سوق والمارت.

Sami is at Walmart.

Expected form: **في**

Why: Prepositions. [[Arabic#^ar-Q0637|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B3%D8%A7%D9%85%D9%8A%20%D9%81%D9%8A%20%D8%B3%D9%88%D9%82%20%D9%88%D8%A7%D9%84%D9%85%D8%A7%D8%B1%D8%AA.)
^ar-Q0637-answer

**ar-Q0638** — سامي في سوق والمارت.

Sami is at Walmart.

Expected form: **في**

Why: Prepositions. [[Arabic#^ar-Q0638|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B3%D8%A7%D9%85%D9%8A%20%D9%81%D9%8A%20%D8%B3%D9%88%D9%82%20%D9%88%D8%A7%D9%84%D9%85%D8%A7%D8%B1%D8%AA.)
^ar-Q0638-answer

**ar-Q0639** — من الصعب أن تستيقظ بدون أن تتناول فنجانا من القهوة المركزة.

It is hard to wake up without a strong cup of coffee.

Expected form: **من**

Why: Prepositions. [[Arabic#^ar-Q0639|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D9%86%20%D8%A7%D9%84%D8%B5%D8%B9%D8%A8%20%D8%A3%D9%86%20%D8%AA%D8%B3%D8%AA%D9%8A%D9%82%D8%B8%20%D8%A8%D8%AF%D9%88%D9%86%20%D8%A3%D9%86%20%D8%AA%D8%AA%D9%86%D8%A7%D9%88%D9%84%20%D9%81%D9%86%D8%AC%D8%A7%D9%86%D8%A7%20%D9%85%D9%86%20%D8%A7%D9%84%D9%82%D9%87%D9%88%D8%A9%20%D8%A7%D9%84%D9%85%D8%B1%D9%83%D8%B2%D8%A9.)
^ar-Q0639-answer

**ar-Q0640** — من الصعب أن تستيقظ بدون أن تتناول فنجانا من القهوة المركزة.

It is hard to wake up without a strong cup of coffee.

Why: Prepositions. [[Arabic#^ar-Q0640|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D9%86%20%D8%A7%D9%84%D8%B5%D8%B9%D8%A8%20%D8%A3%D9%86%20%D8%AA%D8%B3%D8%AA%D9%8A%D9%82%D8%B8%20%D8%A8%D8%AF%D9%88%D9%86%20%D8%A3%D9%86%20%D8%AA%D8%AA%D9%86%D8%A7%D9%88%D9%84%20%D9%81%D9%86%D8%AC%D8%A7%D9%86%D8%A7%20%D9%85%D9%86%20%D8%A7%D9%84%D9%82%D9%87%D9%88%D8%A9%20%D8%A7%D9%84%D9%85%D8%B1%D9%83%D8%B2%D8%A9.)
^ar-Q0640-answer

**ar-Q0641** — ابذل وسعك في كل شيء .

Do your best in everything.

Why: Prepositions. [[Arabic#^ar-Q0641|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A7%D8%A8%D8%B0%D9%84%20%D9%88%D8%B3%D8%B9%D9%83%20%D9%81%D9%8A%20%D9%83%D9%84%20%D8%B4%D9%8A%D8%A1%20.)
^ar-Q0641-answer

**ar-Q0642** — ابذل وسعك في كل شيء .

Do your best in everything.

Prepositions mark relations and govern genitive in fully inflected MSA. Their complements can be nouns or pronominal suffixes. English in/on/to choices do not map one-to-one.

Why: Prepositions. [[Arabic#^ar-Q0642|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A7%D8%A8%D8%B0%D9%84%20%D9%88%D8%B3%D8%B9%D9%83%20%D9%81%D9%8A%20%D9%83%D9%84%20%D8%B4%D9%8A%D8%A1%20.)
^ar-Q0642-answer

**ar-Q0643** — أعلم مع من تكلم توم.

I knew who Tom had talked to.

Expected form: **مع**

Why: Prepositions. [[Arabic#^ar-Q0643|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%B9%D9%84%D9%85%20%D9%85%D8%B9%20%D9%85%D9%86%20%D8%AA%D9%83%D9%84%D9%85%20%D8%AA%D9%88%D9%85.)
^ar-Q0643-answer

**ar-Q0644** — أعلم مع من تكلم توم.

I knew who Tom had talked to.

Expected form: **مع**

Why: Prepositions. [[Arabic#^ar-Q0644|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%B9%D9%84%D9%85%20%D9%85%D8%B9%20%D9%85%D9%86%20%D8%AA%D9%83%D9%84%D9%85%20%D8%AA%D9%88%D9%85.)
^ar-Q0644-answer

**ar-Q0645** — من حظنا وجود توم هنا ليساعدنا.

We're lucky Tom is here to help us.

Expected form: **من**

Why: Prepositions. [[Arabic#^ar-Q0645|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D9%86%20%D8%AD%D8%B8%D9%86%D8%A7%20%D9%88%D8%AC%D9%88%D8%AF%20%D8%AA%D9%88%D9%85%20%D9%87%D9%86%D8%A7%20%D9%84%D9%8A%D8%B3%D8%A7%D8%B9%D8%AF%D9%86%D8%A7.)
^ar-Q0645-answer

**ar-Q0646** — من حظنا وجود توم هنا ليساعدنا.

We're lucky Tom is here to help us.

Why: Prepositions. [[Arabic#^ar-Q0646|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D9%86%20%D8%AD%D8%B8%D9%86%D8%A7%20%D9%88%D8%AC%D9%88%D8%AF%20%D8%AA%D9%88%D9%85%20%D9%87%D9%86%D8%A7%20%D9%84%D9%8A%D8%B3%D8%A7%D8%B9%D8%AF%D9%86%D8%A7.)
^ar-Q0646-answer

**ar-Q0647** — سامي يشاهد فيديو ليلى على اليوتوب.

Sami is watching Layla's YouTube video.

Why: Prepositions. [[Arabic#^ar-Q0647|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B3%D8%A7%D9%85%D9%8A%20%D9%8A%D8%B4%D8%A7%D9%87%D8%AF%20%D9%81%D9%8A%D8%AF%D9%8A%D9%88%20%D9%84%D9%8A%D9%84%D9%89%20%D8%B9%D9%84%D9%89%20%D8%A7%D9%84%D9%8A%D9%88%D8%AA%D9%88%D8%A8.)
^ar-Q0647-answer

**ar-Q0648** — سامي يشاهد فيديو ليلى على اليوتوب.

Sami is watching Layla's YouTube video.

Prepositions mark relations and govern genitive in fully inflected MSA. Their complements can be nouns or pronominal suffixes. English in/on/to choices do not map one-to-one.

Why: Prepositions. [[Arabic#^ar-Q0648|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B3%D8%A7%D9%85%D9%8A%20%D9%8A%D8%B4%D8%A7%D9%87%D8%AF%20%D9%81%D9%8A%D8%AF%D9%8A%D9%88%20%D9%84%D9%8A%D9%84%D9%89%20%D8%B9%D9%84%D9%89%20%D8%A7%D9%84%D9%8A%D9%88%D8%AA%D9%88%D8%A8.)
^ar-Q0648-answer

**ar-Q0649** — من فضلك رتب السرير.

Please make the bed.

Expected form: **من**

Why: Prepositions. [[Arabic#^ar-Q0649|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D9%86%20%D9%81%D8%B6%D9%84%D9%83%20%D8%B1%D8%AA%D8%A8%20%D8%A7%D9%84%D8%B3%D8%B1%D9%8A%D8%B1.)
^ar-Q0649-answer

**ar-Q0650** — من فضلك رتب السرير.

Please make the bed.

Expected form: **من**

Why: Prepositions. [[Arabic#^ar-Q0650|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D9%86%20%D9%81%D8%B6%D9%84%D9%83%20%D8%B1%D8%AA%D8%A8%20%D8%A7%D9%84%D8%B3%D8%B1%D9%8A%D8%B1.)
^ar-Q0650-answer


### Answers 651–700

**ar-Q0651** — قام توم بنفس الشيء الذي قامت به ماريا

Tom did the same thing Mary did.

Expected form: **الذي**

Why: Relative forms. [[Arabic#^ar-Q0651|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%82%D8%A7%D9%85%20%D8%AA%D9%88%D9%85%20%D8%A8%D9%86%D9%81%D8%B3%20%D8%A7%D9%84%D8%B4%D9%8A%D8%A1%20%D8%A7%D9%84%D8%B0%D9%8A%20%D9%82%D8%A7%D9%85%D8%AA%20%D8%A8%D9%87%20%D9%85%D8%A7%D8%B1%D9%8A%D8%A7)
^ar-Q0651-answer

**ar-Q0652** — قام توم بنفس الشيء الذي قامت به ماريا

Tom did the same thing Mary did.

Why: Relative forms. [[Arabic#^ar-Q0652|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%82%D8%A7%D9%85%20%D8%AA%D9%88%D9%85%20%D8%A8%D9%86%D9%81%D8%B3%20%D8%A7%D9%84%D8%B4%D9%8A%D8%A1%20%D8%A7%D9%84%D8%B0%D9%8A%20%D9%82%D8%A7%D9%85%D8%AA%20%D8%A8%D9%87%20%D9%85%D8%A7%D8%B1%D9%8A%D8%A7)
^ar-Q0652-answer

**ar-Q0653** — أراني توم القصائد التي كتبها حين كان مراهقا.

Tom showed me the poems that he'd written when he was a teenager.

Why: Relative forms. [[Arabic#^ar-Q0653|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%B1%D8%A7%D9%86%D9%8A%20%D8%AA%D9%88%D9%85%20%D8%A7%D9%84%D9%82%D8%B5%D8%A7%D8%A6%D8%AF%20%D8%A7%D9%84%D8%AA%D9%8A%20%D9%83%D8%AA%D8%A8%D9%87%D8%A7%20%D8%AD%D9%8A%D9%86%20%D9%83%D8%A7%D9%86%20%D9%85%D8%B1%D8%A7%D9%87%D9%82%D8%A7.)
^ar-Q0653-answer

**ar-Q0654** — أراني توم القصائد التي كتبها حين كان مراهقا.

Tom showed me the poems that he'd written when he was a teenager.

Definite relative constructions use forms agreeing with the antecedent. Indefinite noun modification can use a relative-like clause without this same overt relative word. Agreement and referential status both matter.

Why: Relative forms. [[Arabic#^ar-Q0654|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%B1%D8%A7%D9%86%D9%8A%20%D8%AA%D9%88%D9%85%20%D8%A7%D9%84%D9%82%D8%B5%D8%A7%D8%A6%D8%AF%20%D8%A7%D9%84%D8%AA%D9%8A%20%D9%83%D8%AA%D8%A8%D9%87%D8%A7%20%D8%AD%D9%8A%D9%86%20%D9%83%D8%A7%D9%86%20%D9%85%D8%B1%D8%A7%D9%87%D9%82%D8%A7.)
^ar-Q0654-answer

**ar-Q0655** — العباقرة من الناس كالشهبُ التي قُدِّر لها أن تحترق لتضيء زمنها.

Men of genius are meteors destined to burn in order to illuminate their century.

Expected form: **التي**

Why: Relative forms. [[Arabic#^ar-Q0655|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A7%D9%84%D8%B9%D8%A8%D8%A7%D9%82%D8%B1%D8%A9%20%D9%85%D9%86%20%D8%A7%D9%84%D9%86%D8%A7%D8%B3%20%D9%83%D8%A7%D9%84%D8%B4%D9%87%D8%A8%D9%8F%20%D8%A7%D9%84%D8%AA%D9%8A%20%D9%82%D9%8F%D8%AF%D9%90%D9%91%D8%B1%20%D9%84%D9%87%D8%A7%20%D8%A3%D9%86%20%D8%AA%D8%AD%D8%AA%D8%B1%D9%82%20%D9%84%D8%AA%D8%B6%D9%8A%D8%A1%20%D8%B2%D9%85%D9%86%D9%87%D8%A7.)
^ar-Q0655-answer

**ar-Q0656** — العباقرة من الناس كالشهبُ التي قُدِّر لها أن تحترق لتضيء زمنها.

Men of genius are meteors destined to burn in order to illuminate their century.

Expected form: **التي**

Why: Relative forms. [[Arabic#^ar-Q0656|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A7%D9%84%D8%B9%D8%A8%D8%A7%D9%82%D8%B1%D8%A9%20%D9%85%D9%86%20%D8%A7%D9%84%D9%86%D8%A7%D8%B3%20%D9%83%D8%A7%D9%84%D8%B4%D9%87%D8%A8%D9%8F%20%D8%A7%D9%84%D8%AA%D9%8A%20%D9%82%D9%8F%D8%AF%D9%90%D9%91%D8%B1%20%D9%84%D9%87%D8%A7%20%D8%A3%D9%86%20%D8%AA%D8%AD%D8%AA%D8%B1%D9%82%20%D9%84%D8%AA%D8%B6%D9%8A%D8%A1%20%D8%B2%D9%85%D9%86%D9%87%D8%A7.)
^ar-Q0656-answer

**ar-Q0657** — أيمكنك قراءة اللافتة التي أمامنا؟

Can you read that sign ahead of us?

Expected form: **التي**

Why: Relative forms. [[Arabic#^ar-Q0657|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D9%8A%D9%85%D9%83%D9%86%D9%83%20%D9%82%D8%B1%D8%A7%D8%A1%D8%A9%20%D8%A7%D9%84%D9%84%D8%A7%D9%81%D8%AA%D8%A9%20%D8%A7%D9%84%D8%AA%D9%8A%20%D8%A3%D9%85%D8%A7%D9%85%D9%86%D8%A7%D8%9F)
^ar-Q0657-answer

**ar-Q0658** — أيمكنك قراءة اللافتة التي أمامنا؟

Can you read that sign ahead of us?

Why: Relative forms. [[Arabic#^ar-Q0658|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D9%8A%D9%85%D9%83%D9%86%D9%83%20%D9%82%D8%B1%D8%A7%D8%A1%D8%A9%20%D8%A7%D9%84%D9%84%D8%A7%D9%81%D8%AA%D8%A9%20%D8%A7%D9%84%D8%AA%D9%8A%20%D8%A3%D9%85%D8%A7%D9%85%D9%86%D8%A7%D8%9F)
^ar-Q0658-answer

**ar-Q0659** — أنظر على التعليمات الموجودة على عبوة التابيوكا التي تشتريها.

Look at the instructions on the package of tapioca that you buy.

Why: Relative forms. [[Arabic#^ar-Q0659|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D9%86%D8%B8%D8%B1%20%D8%B9%D9%84%D9%89%20%D8%A7%D9%84%D8%AA%D8%B9%D9%84%D9%8A%D9%85%D8%A7%D8%AA%20%D8%A7%D9%84%D9%85%D9%88%D8%AC%D9%88%D8%AF%D8%A9%20%D8%B9%D9%84%D9%89%20%D8%B9%D8%A8%D9%88%D8%A9%20%D8%A7%D9%84%D8%AA%D8%A7%D8%A8%D9%8A%D9%88%D9%83%D8%A7%20%D8%A7%D9%84%D8%AA%D9%8A%20%D8%AA%D8%B4%D8%AA%D8%B1%D9%8A%D9%87%D8%A7.)
^ar-Q0659-answer

**ar-Q0660** — أنظر على التعليمات الموجودة على عبوة التابيوكا التي تشتريها.

Look at the instructions on the package of tapioca that you buy.

Definite relative constructions use forms agreeing with the antecedent. Indefinite noun modification can use a relative-like clause without this same overt relative word. Agreement and referential status both matter.

Why: Relative forms. [[Arabic#^ar-Q0660|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D9%86%D8%B8%D8%B1%20%D8%B9%D9%84%D9%89%20%D8%A7%D9%84%D8%AA%D8%B9%D9%84%D9%8A%D9%85%D8%A7%D8%AA%20%D8%A7%D9%84%D9%85%D9%88%D8%AC%D9%88%D8%AF%D8%A9%20%D8%B9%D9%84%D9%89%20%D8%B9%D8%A8%D9%88%D8%A9%20%D8%A7%D9%84%D8%AA%D8%A7%D8%A8%D9%8A%D9%88%D9%83%D8%A7%20%D8%A7%D9%84%D8%AA%D9%8A%20%D8%AA%D8%B4%D8%AA%D8%B1%D9%8A%D9%87%D8%A7.)
^ar-Q0660-answer

**ar-Q0661** — طالت الخسائر التي خلفها الإعصار الكثير من المحافظات.

The damage of the typhoon spread over several prefectures.

Expected form: **التي**

Why: Relative forms. [[Arabic#^ar-Q0661|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B7%D8%A7%D9%84%D8%AA%20%D8%A7%D9%84%D8%AE%D8%B3%D8%A7%D8%A6%D8%B1%20%D8%A7%D9%84%D8%AA%D9%8A%20%D8%AE%D9%84%D9%81%D9%87%D8%A7%20%D8%A7%D9%84%D8%A5%D8%B9%D8%B5%D8%A7%D8%B1%20%D8%A7%D9%84%D9%83%D8%AB%D9%8A%D8%B1%20%D9%85%D9%86%20%D8%A7%D9%84%D9%85%D8%AD%D8%A7%D9%81%D8%B8%D8%A7%D8%AA.)
^ar-Q0661-answer

**ar-Q0662** — طالت الخسائر التي خلفها الإعصار الكثير من المحافظات.

The damage of the typhoon spread over several prefectures.

Expected form: **التي**

Why: Relative forms. [[Arabic#^ar-Q0662|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B7%D8%A7%D9%84%D8%AA%20%D8%A7%D9%84%D8%AE%D8%B3%D8%A7%D8%A6%D8%B1%20%D8%A7%D9%84%D8%AA%D9%8A%20%D8%AE%D9%84%D9%81%D9%87%D8%A7%20%D8%A7%D9%84%D8%A5%D8%B9%D8%B5%D8%A7%D8%B1%20%D8%A7%D9%84%D9%83%D8%AB%D9%8A%D8%B1%20%D9%85%D9%86%20%D8%A7%D9%84%D9%85%D8%AD%D8%A7%D9%81%D8%B8%D8%A7%D8%AA.)
^ar-Q0662-answer

**ar-Q0663** — لهذا فإن تتويبا متعدد اللغات. لكن ليس ذلك النوع من تعدد اللغات، ليس النوع الذي يُزَاوج فيه بين اللغات، ببساطة، وتُهْمَلُ بعض الأزواج.

This is why Tatoeba is multilingual. But not that kind of multilingual. Not the kind where languages are simply being paired up together, and where some pairs are left behind.

Expected form: **الذي**

Why: Relative forms. [[Arabic#^ar-Q0663|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%87%D8%B0%D8%A7%20%D9%81%D8%A5%D9%86%20%D8%AA%D8%AA%D9%88%D9%8A%D8%A8%D8%A7%20%D9%85%D8%AA%D8%B9%D8%AF%D8%AF%20%D8%A7%D9%84%D9%84%D8%BA%D8%A7%D8%AA.%20%D9%84%D9%83%D9%86%20%D9%84%D9%8A%D8%B3%20%D8%B0%D9%84%D9%83%20%D8%A7%D9%84%D9%86%D9%88%D8%B9%20%D9%85%D9%86%20%D8%AA%D8%B9%D8%AF%D8%AF%20%D8%A7%D9%84%D9%84%D8%BA%D8%A7%D8%AA%D8%8C%20%D9%84%D9%8A%D8%B3%20%D8%A7%D9%84%D9%86%D9%88%D8%B9%20%D8%A7%D9%84%D8%B0%D9%8A%20%D9%8A%D9%8F%D8%B2%D9%8E%D8%A7%D9%88%D8%AC%20%D9%81%D9%8A%D9%87%20%D8%A8%D9%8A%D9%86%20%D8%A7%D9%84%D9%84%D8%BA%D8%A7%D8%AA%D8%8C%20%D8%A8%D8%A8%D8%B3%D8%A7%D8%B7%D8%A9%D8%8C%20%D9%88%D8%AA%D9%8F%D9%87%D9%92%D9%85%D9%8E%D9%84%D9%8F%20%D8%A8%D8%B9%D8%B6%20%D8%A7%D9%84%D8%A3%D8%B2%D9%88%D8%A7%D8%AC.)
^ar-Q0663-answer

**ar-Q0664** — لهذا فإن تتويبا متعدد اللغات. لكن ليس ذلك النوع من تعدد اللغات، ليس النوع الذي يُزَاوج فيه بين اللغات، ببساطة، وتُهْمَلُ بعض الأزواج.

This is why Tatoeba is multilingual. But not that kind of multilingual. Not the kind where languages are simply being paired up together, and where some pairs are left behind.

Why: Relative forms. [[Arabic#^ar-Q0664|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%87%D8%B0%D8%A7%20%D9%81%D8%A5%D9%86%20%D8%AA%D8%AA%D9%88%D9%8A%D8%A8%D8%A7%20%D9%85%D8%AA%D8%B9%D8%AF%D8%AF%20%D8%A7%D9%84%D9%84%D8%BA%D8%A7%D8%AA.%20%D9%84%D9%83%D9%86%20%D9%84%D9%8A%D8%B3%20%D8%B0%D9%84%D9%83%20%D8%A7%D9%84%D9%86%D9%88%D8%B9%20%D9%85%D9%86%20%D8%AA%D8%B9%D8%AF%D8%AF%20%D8%A7%D9%84%D9%84%D8%BA%D8%A7%D8%AA%D8%8C%20%D9%84%D9%8A%D8%B3%20%D8%A7%D9%84%D9%86%D9%88%D8%B9%20%D8%A7%D9%84%D8%B0%D9%8A%20%D9%8A%D9%8F%D8%B2%D9%8E%D8%A7%D9%88%D8%AC%20%D9%81%D9%8A%D9%87%20%D8%A8%D9%8A%D9%86%20%D8%A7%D9%84%D9%84%D8%BA%D8%A7%D8%AA%D8%8C%20%D8%A8%D8%A8%D8%B3%D8%A7%D8%B7%D8%A9%D8%8C%20%D9%88%D8%AA%D9%8F%D9%87%D9%92%D9%85%D9%8E%D9%84%D9%8F%20%D8%A8%D8%B9%D8%B6%20%D8%A7%D9%84%D8%A3%D8%B2%D9%88%D8%A7%D8%AC.)
^ar-Q0664-answer

**ar-Q0665** — التغيير هو الشيء الوحيد الذي لا يتغير.

Change is the only constant.

Why: Relative forms. [[Arabic#^ar-Q0665|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A7%D9%84%D8%AA%D8%BA%D9%8A%D9%8A%D8%B1%20%D9%87%D9%88%20%D8%A7%D9%84%D8%B4%D9%8A%D8%A1%20%D8%A7%D9%84%D9%88%D8%AD%D9%8A%D8%AF%20%D8%A7%D9%84%D8%B0%D9%8A%20%D9%84%D8%A7%20%D9%8A%D8%AA%D8%BA%D9%8A%D8%B1.)
^ar-Q0665-answer

**ar-Q0666** — التغيير هو الشيء الوحيد الذي لا يتغير.

Change is the only constant.

Definite relative constructions use forms agreeing with the antecedent. Indefinite noun modification can use a relative-like clause without this same overt relative word. Agreement and referential status both matter.

Why: Relative forms. [[Arabic#^ar-Q0666|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A7%D9%84%D8%AA%D8%BA%D9%8A%D9%8A%D8%B1%20%D9%87%D9%88%20%D8%A7%D9%84%D8%B4%D9%8A%D8%A1%20%D8%A7%D9%84%D9%88%D8%AD%D9%8A%D8%AF%20%D8%A7%D9%84%D8%B0%D9%8A%20%D9%84%D8%A7%20%D9%8A%D8%AA%D8%BA%D9%8A%D8%B1.)
^ar-Q0666-answer

**ar-Q0667** — لم أفهم الطرفة التي قصها علينا.

I couldn't catch on to the joke he told us.

Expected form: **التي**

Why: Relative forms. [[Arabic#^ar-Q0667|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%85%20%D8%A3%D9%81%D9%87%D9%85%20%D8%A7%D9%84%D8%B7%D8%B1%D9%81%D8%A9%20%D8%A7%D9%84%D8%AA%D9%8A%20%D9%82%D8%B5%D9%87%D8%A7%20%D8%B9%D9%84%D9%8A%D9%86%D8%A7.)
^ar-Q0667-answer

**ar-Q0668** — لم أفهم الطرفة التي قصها علينا.

I couldn't catch on to the joke he told us.

Expected form: **التي**

Why: Relative forms. [[Arabic#^ar-Q0668|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%85%20%D8%A3%D9%81%D9%87%D9%85%20%D8%A7%D9%84%D8%B7%D8%B1%D9%81%D8%A9%20%D8%A7%D9%84%D8%AA%D9%8A%20%D9%82%D8%B5%D9%87%D8%A7%20%D8%B9%D9%84%D9%8A%D9%86%D8%A7.)
^ar-Q0668-answer

**ar-Q0669** — فتّشت الشّرطة حاوية النّفايات التي كانت خلف مكتب سامي.

Police searched the dumpster behind Sami's office.

Expected form: **التي**

Why: Relative forms. [[Arabic#^ar-Q0669|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%81%D8%AA%D9%91%D8%B4%D8%AA%20%D8%A7%D9%84%D8%B4%D9%91%D8%B1%D8%B7%D8%A9%20%D8%AD%D8%A7%D9%88%D9%8A%D8%A9%20%D8%A7%D9%84%D9%86%D9%91%D9%81%D8%A7%D9%8A%D8%A7%D8%AA%20%D8%A7%D9%84%D8%AA%D9%8A%20%D9%83%D8%A7%D9%86%D8%AA%20%D8%AE%D9%84%D9%81%20%D9%85%D9%83%D8%AA%D8%A8%20%D8%B3%D8%A7%D9%85%D9%8A.)
^ar-Q0669-answer

**ar-Q0670** — فتّشت الشّرطة حاوية النّفايات التي كانت خلف مكتب سامي.

Police searched the dumpster behind Sami's office.

Why: Relative forms. [[Arabic#^ar-Q0670|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%81%D8%AA%D9%91%D8%B4%D8%AA%20%D8%A7%D9%84%D8%B4%D9%91%D8%B1%D8%B7%D8%A9%20%D8%AD%D8%A7%D9%88%D9%8A%D8%A9%20%D8%A7%D9%84%D9%86%D9%91%D9%81%D8%A7%D9%8A%D8%A7%D8%AA%20%D8%A7%D9%84%D8%AA%D9%8A%20%D9%83%D8%A7%D9%86%D8%AA%20%D8%AE%D9%84%D9%81%20%D9%85%D9%83%D8%AA%D8%A8%20%D8%B3%D8%A7%D9%85%D9%8A.)
^ar-Q0670-answer

**ar-Q0671** — هذا هو المكان الذي تسكن فيه.

This is where she lives.

Why: Relative forms. [[Arabic#^ar-Q0671|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D8%B0%D8%A7%20%D9%87%D9%88%20%D8%A7%D9%84%D9%85%D9%83%D8%A7%D9%86%20%D8%A7%D9%84%D8%B0%D9%8A%20%D8%AA%D8%B3%D9%83%D9%86%20%D9%81%D9%8A%D9%87.)
^ar-Q0671-answer

**ar-Q0672** — هذا هو المكان الذي تسكن فيه.

This is where she lives.

Definite relative constructions use forms agreeing with the antecedent. Indefinite noun modification can use a relative-like clause without this same overt relative word. Agreement and referential status both matter.

Why: Relative forms. [[Arabic#^ar-Q0672|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D8%B0%D8%A7%20%D9%87%D9%88%20%D8%A7%D9%84%D9%85%D9%83%D8%A7%D9%86%20%D8%A7%D9%84%D8%B0%D9%8A%20%D8%AA%D8%B3%D9%83%D9%86%20%D9%81%D9%8A%D9%87.)
^ar-Q0672-answer

**ar-Q0673** — ما الذي تفعله بوقت فراغك؟

What do you do in your free time?

Expected form: **الذي**

Why: Relative forms. [[Arabic#^ar-Q0673|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D8%A7%20%D8%A7%D9%84%D8%B0%D9%8A%20%D8%AA%D9%81%D8%B9%D9%84%D9%87%20%D8%A8%D9%88%D9%82%D8%AA%20%D9%81%D8%B1%D8%A7%D8%BA%D9%83%D8%9F)
^ar-Q0673-answer

**ar-Q0674** — ما الذي تفعله بوقت فراغك؟

What do you do in your free time?

Expected form: **الذي**

Why: Relative forms. [[Arabic#^ar-Q0674|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D8%A7%20%D8%A7%D9%84%D8%B0%D9%8A%20%D8%AA%D9%81%D8%B9%D9%84%D9%87%20%D8%A8%D9%88%D9%82%D8%AA%20%D9%81%D8%B1%D8%A7%D8%BA%D9%83%D8%9F)
^ar-Q0674-answer

**ar-Q0675** — أتذكر البيت الذي نشأت فيه

I remember the house where I grew up.

Expected form: **الذي**

Why: Relative forms. [[Arabic#^ar-Q0675|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%AA%D8%B0%D9%83%D8%B1%20%D8%A7%D9%84%D8%A8%D9%8A%D8%AA%20%D8%A7%D9%84%D8%B0%D9%8A%20%D9%86%D8%B4%D8%A3%D8%AA%20%D9%81%D9%8A%D9%87)
^ar-Q0675-answer

**ar-Q0676** — أتذكر البيت الذي نشأت فيه

I remember the house where I grew up.

Why: Relative forms. [[Arabic#^ar-Q0676|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%AA%D8%B0%D9%83%D8%B1%20%D8%A7%D9%84%D8%A8%D9%8A%D8%AA%20%D8%A7%D9%84%D8%B0%D9%8A%20%D9%86%D8%B4%D8%A3%D8%AA%20%D9%81%D9%8A%D9%87)
^ar-Q0676-answer

**ar-Q0677** — تأثّرت حياة سامي للأبد منذ اليوم الذي لم تعد فيه أمّه إلى المنزل.

Sami's life is scarred for ever by the day his mom didn't come home.

Why: Relative forms. [[Arabic#^ar-Q0677|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%AA%D8%A3%D8%AB%D9%91%D8%B1%D8%AA%20%D8%AD%D9%8A%D8%A7%D8%A9%20%D8%B3%D8%A7%D9%85%D9%8A%20%D9%84%D9%84%D8%A3%D8%A8%D8%AF%20%D9%85%D9%86%D8%B0%20%D8%A7%D9%84%D9%8A%D9%88%D9%85%20%D8%A7%D9%84%D8%B0%D9%8A%20%D9%84%D9%85%20%D8%AA%D8%B9%D8%AF%20%D9%81%D9%8A%D9%87%20%D8%A3%D9%85%D9%91%D9%87%20%D8%A5%D9%84%D9%89%20%D8%A7%D9%84%D9%85%D9%86%D8%B2%D9%84.)
^ar-Q0677-answer

**ar-Q0678** — تأثّرت حياة سامي للأبد منذ اليوم الذي لم تعد فيه أمّه إلى المنزل.

Sami's life is scarred for ever by the day his mom didn't come home.

Definite relative constructions use forms agreeing with the antecedent. Indefinite noun modification can use a relative-like clause without this same overt relative word. Agreement and referential status both matter.

Why: Relative forms. [[Arabic#^ar-Q0678|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%AA%D8%A3%D8%AB%D9%91%D8%B1%D8%AA%20%D8%AD%D9%8A%D8%A7%D8%A9%20%D8%B3%D8%A7%D9%85%D9%8A%20%D9%84%D9%84%D8%A3%D8%A8%D8%AF%20%D9%85%D9%86%D8%B0%20%D8%A7%D9%84%D9%8A%D9%88%D9%85%20%D8%A7%D9%84%D8%B0%D9%8A%20%D9%84%D9%85%20%D8%AA%D8%B9%D8%AF%20%D9%81%D9%8A%D9%87%20%D8%A3%D9%85%D9%91%D9%87%20%D8%A5%D9%84%D9%89%20%D8%A7%D9%84%D9%85%D9%86%D8%B2%D9%84.)
^ar-Q0678-answer

**ar-Q0679** — من الذي يتولى الزعامة؟

Who has leadership?

Expected form: **الذي**

Why: Relative forms. [[Arabic#^ar-Q0679|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D9%86%20%D8%A7%D9%84%D8%B0%D9%8A%20%D9%8A%D8%AA%D9%88%D9%84%D9%89%20%D8%A7%D9%84%D8%B2%D8%B9%D8%A7%D9%85%D8%A9%D8%9F)
^ar-Q0679-answer

**ar-Q0680** — من الذي يتولى الزعامة؟

Who has leadership?

Expected form: **الذي**

Why: Relative forms. [[Arabic#^ar-Q0680|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D9%86%20%D8%A7%D9%84%D8%B0%D9%8A%20%D9%8A%D8%AA%D9%88%D9%84%D9%89%20%D8%A7%D9%84%D8%B2%D8%B9%D8%A7%D9%85%D8%A9%D8%9F)
^ar-Q0680-answer

**ar-Q0681** — ما الذي تعنيه كلمة "get" في هذه الجملة؟

What does the word "get" mean in this sentence?

Expected form: **الذي**

Why: Relative forms. [[Arabic#^ar-Q0681|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D8%A7%20%D8%A7%D9%84%D8%B0%D9%8A%20%D8%AA%D8%B9%D9%86%D9%8A%D9%87%20%D9%83%D9%84%D9%85%D8%A9%20%22get%22%20%D9%81%D9%8A%20%D9%87%D8%B0%D9%87%20%D8%A7%D9%84%D8%AC%D9%85%D9%84%D8%A9%D8%9F)
^ar-Q0681-answer

**ar-Q0682** — ما الذي تعنيه كلمة "get" في هذه الجملة؟

What does the word "get" mean in this sentence?

Why: Relative forms. [[Arabic#^ar-Q0682|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D8%A7%20%D8%A7%D9%84%D8%B0%D9%8A%20%D8%AA%D8%B9%D9%86%D9%8A%D9%87%20%D9%83%D9%84%D9%85%D8%A9%20%22get%22%20%D9%81%D9%8A%20%D9%87%D8%B0%D9%87%20%D8%A7%D9%84%D8%AC%D9%85%D9%84%D8%A9%D8%9F)
^ar-Q0682-answer

**ar-Q0683** — على إسرائيل أن ترفع الحصال الذي فرضته على غزّة.

Israel should lift the blockade it imposed on Gaza.

Why: Relative forms. [[Arabic#^ar-Q0683|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B9%D9%84%D9%89%20%D8%A5%D8%B3%D8%B1%D8%A7%D8%A6%D9%8A%D9%84%20%D8%A3%D9%86%20%D8%AA%D8%B1%D9%81%D8%B9%20%D8%A7%D9%84%D8%AD%D8%B5%D8%A7%D9%84%20%D8%A7%D9%84%D8%B0%D9%8A%20%D9%81%D8%B1%D8%B6%D8%AA%D9%87%20%D8%B9%D9%84%D9%89%20%D8%BA%D8%B2%D9%91%D8%A9.)
^ar-Q0683-answer

**ar-Q0684** — على إسرائيل أن ترفع الحصال الذي فرضته على غزّة.

Israel should lift the blockade it imposed on Gaza.

Definite relative constructions use forms agreeing with the antecedent. Indefinite noun modification can use a relative-like clause without this same overt relative word. Agreement and referential status both matter.

Why: Relative forms. [[Arabic#^ar-Q0684|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B9%D9%84%D9%89%20%D8%A5%D8%B3%D8%B1%D8%A7%D8%A6%D9%8A%D9%84%20%D8%A3%D9%86%20%D8%AA%D8%B1%D9%81%D8%B9%20%D8%A7%D9%84%D8%AD%D8%B5%D8%A7%D9%84%20%D8%A7%D9%84%D8%B0%D9%8A%20%D9%81%D8%B1%D8%B6%D8%AA%D9%87%20%D8%B9%D9%84%D9%89%20%D8%BA%D8%B2%D9%91%D8%A9.)
^ar-Q0684-answer

**ar-Q0685** — لم يُعذّب أحد بالطّريقة التي عُذّب بها سامي.

No one has ever been tortured the way Sami was.

Expected form: **التي**

Why: Relative forms. [[Arabic#^ar-Q0685|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%85%20%D9%8A%D9%8F%D8%B9%D8%B0%D9%91%D8%A8%20%D8%A3%D8%AD%D8%AF%20%D8%A8%D8%A7%D9%84%D8%B7%D9%91%D8%B1%D9%8A%D9%82%D8%A9%20%D8%A7%D9%84%D8%AA%D9%8A%20%D8%B9%D9%8F%D8%B0%D9%91%D8%A8%20%D8%A8%D9%87%D8%A7%20%D8%B3%D8%A7%D9%85%D9%8A.)
^ar-Q0685-answer

**ar-Q0686** — لم يُعذّب أحد بالطّريقة التي عُذّب بها سامي.

No one has ever been tortured the way Sami was.

Expected form: **التي**

Why: Relative forms. [[Arabic#^ar-Q0686|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%85%20%D9%8A%D9%8F%D8%B9%D8%B0%D9%91%D8%A8%20%D8%A3%D8%AD%D8%AF%20%D8%A8%D8%A7%D9%84%D8%B7%D9%91%D8%B1%D9%8A%D9%82%D8%A9%20%D8%A7%D9%84%D8%AA%D9%8A%20%D8%B9%D9%8F%D8%B0%D9%91%D8%A8%20%D8%A8%D9%87%D8%A7%20%D8%B3%D8%A7%D9%85%D9%8A.)
^ar-Q0686-answer

**ar-Q0687** — الذي يؤمن به لا يدان.

Whoever believes in him is not condemned.

Expected form: **الذي**

Why: Relative forms. [[Arabic#^ar-Q0687|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A7%D9%84%D8%B0%D9%8A%20%D9%8A%D8%A4%D9%85%D9%86%20%D8%A8%D9%87%20%D9%84%D8%A7%20%D9%8A%D8%AF%D8%A7%D9%86.)
^ar-Q0687-answer

**ar-Q0688** — الذي يؤمن به لا يدان.

Whoever believes in him is not condemned.

Why: Relative forms. [[Arabic#^ar-Q0688|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A7%D9%84%D8%B0%D9%8A%20%D9%8A%D8%A4%D9%85%D9%86%20%D8%A8%D9%87%20%D9%84%D8%A7%20%D9%8A%D8%AF%D8%A7%D9%86.)
^ar-Q0688-answer

**ar-Q0689** — ما الذي تقوله؟

What're you saying?

Why: Relative forms. [[Arabic#^ar-Q0689|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D8%A7%20%D8%A7%D9%84%D8%B0%D9%8A%20%D8%AA%D9%82%D9%88%D9%84%D9%87%D8%9F)
^ar-Q0689-answer

**ar-Q0690** — ما الذي تقوله؟

What're you saying?

Definite relative constructions use forms agreeing with the antecedent. Indefinite noun modification can use a relative-like clause without this same overt relative word. Agreement and referential status both matter.

Why: Relative forms. [[Arabic#^ar-Q0690|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D8%A7%20%D8%A7%D9%84%D8%B0%D9%8A%20%D8%AA%D9%82%D9%88%D9%84%D9%87%D8%9F)
^ar-Q0690-answer

**ar-Q0691** — تحوّل فاضل من ذلك الطّفل السّاذج الذي كان يُضايَق في المدرسة إلى مجرم خطير.

Fadil has changed from the naive kid who was abused at school to a dangerous criminal.

Expected form: **الذي**

Why: Relative forms. [[Arabic#^ar-Q0691|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%AA%D8%AD%D9%88%D9%91%D9%84%20%D9%81%D8%A7%D8%B6%D9%84%20%D9%85%D9%86%20%D8%B0%D9%84%D9%83%20%D8%A7%D9%84%D8%B7%D9%91%D9%81%D9%84%20%D8%A7%D9%84%D8%B3%D9%91%D8%A7%D8%B0%D8%AC%20%D8%A7%D9%84%D8%B0%D9%8A%20%D9%83%D8%A7%D9%86%20%D9%8A%D9%8F%D8%B6%D8%A7%D9%8A%D9%8E%D9%82%20%D9%81%D9%8A%20%D8%A7%D9%84%D9%85%D8%AF%D8%B1%D8%B3%D8%A9%20%D8%A5%D9%84%D9%89%20%D9%85%D8%AC%D8%B1%D9%85%20%D8%AE%D8%B7%D9%8A%D8%B1.)
^ar-Q0691-answer

**ar-Q0692** — تحوّل فاضل من ذلك الطّفل السّاذج الذي كان يُضايَق في المدرسة إلى مجرم خطير.

Fadil has changed from the naive kid who was abused at school to a dangerous criminal.

Expected form: **الذي**

Why: Relative forms. [[Arabic#^ar-Q0692|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%AA%D8%AD%D9%88%D9%91%D9%84%20%D9%81%D8%A7%D8%B6%D9%84%20%D9%85%D9%86%20%D8%B0%D9%84%D9%83%20%D8%A7%D9%84%D8%B7%D9%91%D9%81%D9%84%20%D8%A7%D9%84%D8%B3%D9%91%D8%A7%D8%B0%D8%AC%20%D8%A7%D9%84%D8%B0%D9%8A%20%D9%83%D8%A7%D9%86%20%D9%8A%D9%8F%D8%B6%D8%A7%D9%8A%D9%8E%D9%82%20%D9%81%D9%8A%20%D8%A7%D9%84%D9%85%D8%AF%D8%B1%D8%B3%D8%A9%20%D8%A5%D9%84%D9%89%20%D9%85%D8%AC%D8%B1%D9%85%20%D8%AE%D8%B7%D9%8A%D8%B1.)
^ar-Q0692-answer

**ar-Q0693** — النّاس مثلنا، أي الذين يؤمنون بالفزياء، يعلمون أنّ التّمييز بين الماضي و الحاضر و المستقبل ما هو إلاّ وهم يستمرّ بشكل مستحكم.

People like us, who believe in physics, know that the distinction between past, present, and future is only a stubbornly persistent illusion.

Expected form: **الذين**

Why: Relative forms. [[Arabic#^ar-Q0693|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A7%D9%84%D9%86%D9%91%D8%A7%D8%B3%20%D9%85%D8%AB%D9%84%D9%86%D8%A7%D8%8C%20%D8%A3%D9%8A%20%D8%A7%D9%84%D8%B0%D9%8A%D9%86%20%D9%8A%D8%A4%D9%85%D9%86%D9%88%D9%86%20%D8%A8%D8%A7%D9%84%D9%81%D8%B2%D9%8A%D8%A7%D8%A1%D8%8C%20%D9%8A%D8%B9%D9%84%D9%85%D9%88%D9%86%20%D8%A3%D9%86%D9%91%20%D8%A7%D9%84%D8%AA%D9%91%D9%85%D9%8A%D9%8A%D8%B2%20%D8%A8%D9%8A%D9%86%20%D8%A7%D9%84%D9%85%D8%A7%D8%B6%D9%8A%20%D9%88%20%D8%A7%D9%84%D8%AD%D8%A7%D8%B6%D8%B1%20%D9%88%20%D8%A7%D9%84%D9%85%D8%B3%D8%AA%D9%82%D8%A8%D9%84%20%D9%85%D8%A7%20%D9%87%D9%88%20%D8%A5%D9%84%D8%A7%D9%91%20%D9%88%D9%87%D9%85%20%D9%8A%D8%B3%D8%AA%D9%85%D8%B1%D9%91%20%D8%A8%D8%B4%D9%83%D9%84%20%D9%85%D8%B3%D8%AA%D8%AD%D9%83%D9%85.)
^ar-Q0693-answer

**ar-Q0694** — النّاس مثلنا، أي الذين يؤمنون بالفزياء، يعلمون أنّ التّمييز بين الماضي و الحاضر و المستقبل ما هو إلاّ وهم يستمرّ بشكل مستحكم.

People like us, who believe in physics, know that the distinction between past, present, and future is only a stubbornly persistent illusion.

Why: Relative forms. [[Arabic#^ar-Q0694|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A7%D9%84%D9%86%D9%91%D8%A7%D8%B3%20%D9%85%D8%AB%D9%84%D9%86%D8%A7%D8%8C%20%D8%A3%D9%8A%20%D8%A7%D9%84%D8%B0%D9%8A%D9%86%20%D9%8A%D8%A4%D9%85%D9%86%D9%88%D9%86%20%D8%A8%D8%A7%D9%84%D9%81%D8%B2%D9%8A%D8%A7%D8%A1%D8%8C%20%D9%8A%D8%B9%D9%84%D9%85%D9%88%D9%86%20%D8%A3%D9%86%D9%91%20%D8%A7%D9%84%D8%AA%D9%91%D9%85%D9%8A%D9%8A%D8%B2%20%D8%A8%D9%8A%D9%86%20%D8%A7%D9%84%D9%85%D8%A7%D8%B6%D9%8A%20%D9%88%20%D8%A7%D9%84%D8%AD%D8%A7%D8%B6%D8%B1%20%D9%88%20%D8%A7%D9%84%D9%85%D8%B3%D8%AA%D9%82%D8%A8%D9%84%20%D9%85%D8%A7%20%D9%87%D9%88%20%D8%A5%D9%84%D8%A7%D9%91%20%D9%88%D9%87%D9%85%20%D9%8A%D8%B3%D8%AA%D9%85%D8%B1%D9%91%20%D8%A8%D8%B4%D9%83%D9%84%20%D9%85%D8%B3%D8%AA%D8%AD%D9%83%D9%85.)
^ar-Q0694-answer

**ar-Q0695** — عالج هذا الدواء البرد الذي أصابني.

This medicine cured me of my cold.

Why: Relative forms. [[Arabic#^ar-Q0695|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B9%D8%A7%D9%84%D8%AC%20%D9%87%D8%B0%D8%A7%20%D8%A7%D9%84%D8%AF%D9%88%D8%A7%D8%A1%20%D8%A7%D9%84%D8%A8%D8%B1%D8%AF%20%D8%A7%D9%84%D8%B0%D9%8A%20%D8%A3%D8%B5%D8%A7%D8%A8%D9%86%D9%8A.)
^ar-Q0695-answer

**ar-Q0696** — عالج هذا الدواء البرد الذي أصابني.

This medicine cured me of my cold.

Definite relative constructions use forms agreeing with the antecedent. Indefinite noun modification can use a relative-like clause without this same overt relative word. Agreement and referential status both matter.

Why: Relative forms. [[Arabic#^ar-Q0696|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B9%D8%A7%D9%84%D8%AC%20%D9%87%D8%B0%D8%A7%20%D8%A7%D9%84%D8%AF%D9%88%D8%A7%D8%A1%20%D8%A7%D9%84%D8%A8%D8%B1%D8%AF%20%D8%A7%D9%84%D8%B0%D9%8A%20%D8%A3%D8%B5%D8%A7%D8%A8%D9%86%D9%8A.)
^ar-Q0696-answer

**ar-Q0697** — أين هي الفواتير التي تريد أن أدفعها؟

Where are the bills that you want me to pay?

Expected form: **التي**

Why: Relative forms. [[Arabic#^ar-Q0697|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D9%8A%D9%86%20%D9%87%D9%8A%20%D8%A7%D9%84%D9%81%D9%88%D8%A7%D8%AA%D9%8A%D8%B1%20%D8%A7%D9%84%D8%AA%D9%8A%20%D8%AA%D8%B1%D9%8A%D8%AF%20%D8%A3%D9%86%20%D8%A3%D8%AF%D9%81%D8%B9%D9%87%D8%A7%D8%9F)
^ar-Q0697-answer

**ar-Q0698** — أين هي الفواتير التي تريد أن أدفعها؟

Where are the bills that you want me to pay?

Expected form: **التي**

Why: Relative forms. [[Arabic#^ar-Q0698|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D9%8A%D9%86%20%D9%87%D9%8A%20%D8%A7%D9%84%D9%81%D9%88%D8%A7%D8%AA%D9%8A%D8%B1%20%D8%A7%D9%84%D8%AA%D9%8A%20%D8%AA%D8%B1%D9%8A%D8%AF%20%D8%A3%D9%86%20%D8%A3%D8%AF%D9%81%D8%B9%D9%87%D8%A7%D8%9F)
^ar-Q0698-answer

**ar-Q0699** — أضعت الساعة التي أعطاني إياها والدي.

I lost the watch Father had given me.

Expected form: **التي**

Why: Relative forms. [[Arabic#^ar-Q0699|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%B6%D8%B9%D8%AA%20%D8%A7%D9%84%D8%B3%D8%A7%D8%B9%D8%A9%20%D8%A7%D9%84%D8%AA%D9%8A%20%D8%A3%D8%B9%D8%B7%D8%A7%D9%86%D9%8A%20%D8%A5%D9%8A%D8%A7%D9%87%D8%A7%20%D9%88%D8%A7%D9%84%D8%AF%D9%8A.)
^ar-Q0699-answer

**ar-Q0700** — أضعت الساعة التي أعطاني إياها والدي.

I lost the watch Father had given me.

Why: Relative forms. [[Arabic#^ar-Q0700|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%B6%D8%B9%D8%AA%20%D8%A7%D9%84%D8%B3%D8%A7%D8%B9%D8%A9%20%D8%A7%D9%84%D8%AA%D9%8A%20%D8%A3%D8%B9%D8%B7%D8%A7%D9%86%D9%8A%20%D8%A5%D9%8A%D8%A7%D9%87%D8%A7%20%D9%88%D8%A7%D9%84%D8%AF%D9%8A.)
^ar-Q0700-answer


### Answers 701–750

**ar-Q0701** — هل سبق و أن قمتِ بعرض للتّعرّي؟

Have you ever stripped before?

Why: Content and purpose. [[Arabic#^ar-Q0701|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D9%84%20%D8%B3%D8%A8%D9%82%20%D9%88%20%D8%A3%D9%86%20%D9%82%D9%85%D8%AA%D9%90%20%D8%A8%D8%B9%D8%B1%D8%B6%20%D9%84%D9%84%D8%AA%D9%91%D8%B9%D8%B1%D9%91%D9%8A%D8%9F)
^ar-Q0701-answer

**ar-Q0702** — هل سبق و أن قمتِ بعرض للتّعرّي؟

Have you ever stripped before?

أن before a verb and أنّ before a nominal clause belong to distinct complement patterns. Purpose can use كي or related structures. Unvowelled أن requires contextual interpretation.

Why: Content and purpose. [[Arabic#^ar-Q0702|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D9%84%20%D8%B3%D8%A8%D9%82%20%D9%88%20%D8%A3%D9%86%20%D9%82%D9%85%D8%AA%D9%90%20%D8%A8%D8%B9%D8%B1%D8%B6%20%D9%84%D9%84%D8%AA%D9%91%D8%B9%D8%B1%D9%91%D9%8A%D8%9F)
^ar-Q0702-answer

**ar-Q0703** — إنه خطر أن تقود بتهور.

It is dangerous to drive so fast.

Expected form: **أن**

Why: Content and purpose. [[Arabic#^ar-Q0703|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A5%D9%86%D9%87%20%D8%AE%D8%B7%D8%B1%20%D8%A3%D9%86%20%D8%AA%D9%82%D9%88%D8%AF%20%D8%A8%D8%AA%D9%87%D9%88%D8%B1.)
^ar-Q0703-answer

**ar-Q0704** — إنه خطر أن تقود بتهور.

It is dangerous to drive so fast.

Expected form: **أن**

Why: Content and purpose. [[Arabic#^ar-Q0704|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A5%D9%86%D9%87%20%D8%AE%D8%B7%D8%B1%20%D8%A3%D9%86%20%D8%AA%D9%82%D9%88%D8%AF%20%D8%A8%D8%AA%D9%87%D9%88%D8%B1.)
^ar-Q0704-answer

**ar-Q0705** — لكل فرد الحق أن يلجأ إلى بلاد أخرى أو يحاول الاتجاء إليها هربا من الاضطهاد.

Everyone has the right to seek and to enjoy in other countries asylum from persecution.

Expected form: **أن**

Why: Content and purpose. [[Arabic#^ar-Q0705|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%83%D9%84%20%D9%81%D8%B1%D8%AF%20%D8%A7%D9%84%D8%AD%D9%82%20%D8%A3%D9%86%20%D9%8A%D9%84%D8%AC%D8%A3%20%D8%A5%D9%84%D9%89%20%D8%A8%D9%84%D8%A7%D8%AF%20%D8%A3%D8%AE%D8%B1%D9%89%20%D8%A3%D9%88%20%D9%8A%D8%AD%D8%A7%D9%88%D9%84%20%D8%A7%D9%84%D8%A7%D8%AA%D8%AC%D8%A7%D8%A1%20%D8%A5%D9%84%D9%8A%D9%87%D8%A7%20%D9%87%D8%B1%D8%A8%D8%A7%20%D9%85%D9%86%20%D8%A7%D9%84%D8%A7%D8%B6%D8%B7%D9%87%D8%A7%D8%AF.)
^ar-Q0705-answer

**ar-Q0706** — لكل فرد الحق أن يلجأ إلى بلاد أخرى أو يحاول الاتجاء إليها هربا من الاضطهاد.

Everyone has the right to seek and to enjoy in other countries asylum from persecution.

Why: Content and purpose. [[Arabic#^ar-Q0706|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%83%D9%84%20%D9%81%D8%B1%D8%AF%20%D8%A7%D9%84%D8%AD%D9%82%20%D8%A3%D9%86%20%D9%8A%D9%84%D8%AC%D8%A3%20%D8%A5%D9%84%D9%89%20%D8%A8%D9%84%D8%A7%D8%AF%20%D8%A3%D8%AE%D8%B1%D9%89%20%D8%A3%D9%88%20%D9%8A%D8%AD%D8%A7%D9%88%D9%84%20%D8%A7%D9%84%D8%A7%D8%AA%D8%AC%D8%A7%D8%A1%20%D8%A5%D9%84%D9%8A%D9%87%D8%A7%20%D9%87%D8%B1%D8%A8%D8%A7%20%D9%85%D9%86%20%D8%A7%D9%84%D8%A7%D8%B6%D8%B7%D9%87%D8%A7%D8%AF.)
^ar-Q0706-answer

**ar-Q0707** — أراد سامي أن يتعرّف بمسلمين.

Sami wanted to meet Muslims.

Why: Content and purpose. [[Arabic#^ar-Q0707|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%B1%D8%A7%D8%AF%20%D8%B3%D8%A7%D9%85%D9%8A%20%D8%A3%D9%86%20%D9%8A%D8%AA%D8%B9%D8%B1%D9%91%D9%81%20%D8%A8%D9%85%D8%B3%D9%84%D9%85%D9%8A%D9%86.)
^ar-Q0707-answer

**ar-Q0708** — أراد سامي أن يتعرّف بمسلمين.

Sami wanted to meet Muslims.

أن before a verb and أنّ before a nominal clause belong to distinct complement patterns. Purpose can use كي or related structures. Unvowelled أن requires contextual interpretation.

Why: Content and purpose. [[Arabic#^ar-Q0708|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%B1%D8%A7%D8%AF%20%D8%B3%D8%A7%D9%85%D9%8A%20%D8%A3%D9%86%20%D9%8A%D8%AA%D8%B9%D8%B1%D9%91%D9%81%20%D8%A8%D9%85%D8%B3%D9%84%D9%85%D9%8A%D9%86.)
^ar-Q0708-answer

**ar-Q0709** — المسلمون يؤمنون أن محمّدا رسول من الله.

Muslims believe that Muhammad is God's messenger.

Expected form: **أن**

Why: Content and purpose. [[Arabic#^ar-Q0709|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A7%D9%84%D9%85%D8%B3%D9%84%D9%85%D9%88%D9%86%20%D9%8A%D8%A4%D9%85%D9%86%D9%88%D9%86%20%D8%A3%D9%86%20%D9%85%D8%AD%D9%85%D9%91%D8%AF%D8%A7%20%D8%B1%D8%B3%D9%88%D9%84%20%D9%85%D9%86%20%D8%A7%D9%84%D9%84%D9%87.)
^ar-Q0709-answer

**ar-Q0710** — المسلمون يؤمنون أن محمّدا رسول من الله.

Muslims believe that Muhammad is God's messenger.

Expected form: **أن**

Why: Content and purpose. [[Arabic#^ar-Q0710|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A7%D9%84%D9%85%D8%B3%D9%84%D9%85%D9%88%D9%86%20%D9%8A%D8%A4%D9%85%D9%86%D9%88%D9%86%20%D8%A3%D9%86%20%D9%85%D8%AD%D9%85%D9%91%D8%AF%D8%A7%20%D8%B1%D8%B3%D9%88%D9%84%20%D9%85%D9%86%20%D8%A7%D9%84%D9%84%D9%87.)
^ar-Q0710-answer

**ar-Q0711** — يجب أن تشارك أعمالك مع الآخرين.

You must share your jobs with others.

Expected form: **أن**

Why: Content and purpose. [[Arabic#^ar-Q0711|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%8A%D8%AC%D8%A8%20%D8%A3%D9%86%20%D8%AA%D8%B4%D8%A7%D8%B1%D9%83%20%D8%A3%D8%B9%D9%85%D8%A7%D9%84%D9%83%20%D9%85%D8%B9%20%D8%A7%D9%84%D8%A2%D8%AE%D8%B1%D9%8A%D9%86.)
^ar-Q0711-answer

**ar-Q0712** — يجب أن تشارك أعمالك مع الآخرين.

You must share your jobs with others.

Why: Content and purpose. [[Arabic#^ar-Q0712|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%8A%D8%AC%D8%A8%20%D8%A3%D9%86%20%D8%AA%D8%B4%D8%A7%D8%B1%D9%83%20%D8%A3%D8%B9%D9%85%D8%A7%D9%84%D9%83%20%D9%85%D8%B9%20%D8%A7%D9%84%D8%A2%D8%AE%D8%B1%D9%8A%D9%86.)
^ar-Q0712-answer

**ar-Q0713** — هل سبق لك أن ذهبت إلى لندن؟

Have you been to London?

Why: Content and purpose. [[Arabic#^ar-Q0713|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D9%84%20%D8%B3%D8%A8%D9%82%20%D9%84%D9%83%20%D8%A3%D9%86%20%D8%B0%D9%87%D8%A8%D8%AA%20%D8%A5%D9%84%D9%89%20%D9%84%D9%86%D8%AF%D9%86%D8%9F)
^ar-Q0713-answer

**ar-Q0714** — هل سبق لك أن ذهبت إلى لندن؟

Have you been to London?

أن before a verb and أنّ before a nominal clause belong to distinct complement patterns. Purpose can use كي or related structures. Unvowelled أن requires contextual interpretation.

Why: Content and purpose. [[Arabic#^ar-Q0714|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D9%84%20%D8%B3%D8%A8%D9%82%20%D9%84%D9%83%20%D8%A3%D9%86%20%D8%B0%D9%87%D8%A8%D8%AA%20%D8%A5%D9%84%D9%89%20%D9%84%D9%86%D8%AF%D9%86%D8%9F)
^ar-Q0714-answer

**ar-Q0715** — يستطيع الواحد أن يجد الوقتَ دائمًا.

One can always find time.

Expected form: **أن**

Why: Content and purpose. [[Arabic#^ar-Q0715|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%8A%D8%B3%D8%AA%D8%B7%D9%8A%D8%B9%20%D8%A7%D9%84%D9%88%D8%A7%D8%AD%D8%AF%20%D8%A3%D9%86%20%D9%8A%D8%AC%D8%AF%20%D8%A7%D9%84%D9%88%D9%82%D8%AA%D9%8E%20%D8%AF%D8%A7%D8%A6%D9%85%D9%8B%D8%A7.)
^ar-Q0715-answer

**ar-Q0716** — يستطيع الواحد أن يجد الوقتَ دائمًا.

One can always find time.

Expected form: **أن**

Why: Content and purpose. [[Arabic#^ar-Q0716|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%8A%D8%B3%D8%AA%D8%B7%D9%8A%D8%B9%20%D8%A7%D9%84%D9%88%D8%A7%D8%AD%D8%AF%20%D8%A3%D9%86%20%D9%8A%D8%AC%D8%AF%20%D8%A7%D9%84%D9%88%D9%82%D8%AA%D9%8E%20%D8%AF%D8%A7%D8%A6%D9%85%D9%8B%D8%A7.)
^ar-Q0716-answer

**ar-Q0717** — لننسى أنّ شيئا كهذا قد حصل.

Let's forget that this whole thing happened.

Expected form: **أن**

Why: Content and purpose. [[Arabic#^ar-Q0717|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%86%D9%86%D8%B3%D9%89%20%D8%A3%D9%86%D9%91%20%D8%B4%D9%8A%D8%A6%D8%A7%20%D9%83%D9%87%D8%B0%D8%A7%20%D9%82%D8%AF%20%D8%AD%D8%B5%D9%84.)
^ar-Q0717-answer

**ar-Q0718** — لننسى أنّ شيئا كهذا قد حصل.

Let's forget that this whole thing happened.

Why: Content and purpose. [[Arabic#^ar-Q0718|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%86%D9%86%D8%B3%D9%89%20%D8%A3%D9%86%D9%91%20%D8%B4%D9%8A%D8%A6%D8%A7%20%D9%83%D9%87%D8%B0%D8%A7%20%D9%82%D8%AF%20%D8%AD%D8%B5%D9%84.)
^ar-Q0718-answer

**ar-Q0719** — يمكن لعلاقة حبّ أن تصبح علاقة غير سليمة.

Love can turn toxic.

Why: Content and purpose. [[Arabic#^ar-Q0719|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%8A%D9%85%D9%83%D9%86%20%D9%84%D8%B9%D9%84%D8%A7%D9%82%D8%A9%20%D8%AD%D8%A8%D9%91%20%D8%A3%D9%86%20%D8%AA%D8%B5%D8%A8%D8%AD%20%D8%B9%D9%84%D8%A7%D9%82%D8%A9%20%D8%BA%D9%8A%D8%B1%20%D8%B3%D9%84%D9%8A%D9%85%D8%A9.)
^ar-Q0719-answer

**ar-Q0720** — يمكن لعلاقة حبّ أن تصبح علاقة غير سليمة.

Love can turn toxic.

أن before a verb and أنّ before a nominal clause belong to distinct complement patterns. Purpose can use كي or related structures. Unvowelled أن requires contextual interpretation.

Why: Content and purpose. [[Arabic#^ar-Q0720|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%8A%D9%85%D9%83%D9%86%20%D9%84%D8%B9%D9%84%D8%A7%D9%82%D8%A9%20%D8%AD%D8%A8%D9%91%20%D8%A3%D9%86%20%D8%AA%D8%B5%D8%A8%D8%AD%20%D8%B9%D9%84%D8%A7%D9%82%D8%A9%20%D8%BA%D9%8A%D8%B1%20%D8%B3%D9%84%D9%8A%D9%85%D8%A9.)
^ar-Q0720-answer

**ar-Q0721** — دعى سامي لله كي يغفر له.

Sami asked the Lord to forgive him.

Expected form: **كي**

Why: Content and purpose. [[Arabic#^ar-Q0721|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%AF%D8%B9%D9%89%20%D8%B3%D8%A7%D9%85%D9%8A%20%D9%84%D9%84%D9%87%20%D9%83%D9%8A%20%D9%8A%D8%BA%D9%81%D8%B1%20%D9%84%D9%87.)
^ar-Q0721-answer

**ar-Q0722** — دعى سامي لله كي يغفر له.

Sami asked the Lord to forgive him.

Expected form: **كي**

Why: Content and purpose. [[Arabic#^ar-Q0722|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%AF%D8%B9%D9%89%20%D8%B3%D8%A7%D9%85%D9%8A%20%D9%84%D9%84%D9%87%20%D9%83%D9%8A%20%D9%8A%D8%BA%D9%81%D8%B1%20%D9%84%D9%87.)
^ar-Q0722-answer

**ar-Q0723** — من الأفضل لك أن تبقى بعيداً عن توم.

It's better for you to stay away from Tom.

Expected form: **أن**

Why: Content and purpose. [[Arabic#^ar-Q0723|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D9%86%20%D8%A7%D9%84%D8%A3%D9%81%D8%B6%D9%84%20%D9%84%D9%83%20%D8%A3%D9%86%20%D8%AA%D8%A8%D9%82%D9%89%20%D8%A8%D8%B9%D9%8A%D8%AF%D8%A7%D9%8B%20%D8%B9%D9%86%20%D8%AA%D9%88%D9%85.)
^ar-Q0723-answer

**ar-Q0724** — من الأفضل لك أن تبقى بعيداً عن توم.

It's better for you to stay away from Tom.

Why: Content and purpose. [[Arabic#^ar-Q0724|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D9%86%20%D8%A7%D9%84%D8%A3%D9%81%D8%B6%D9%84%20%D9%84%D9%83%20%D8%A3%D9%86%20%D8%AA%D8%A8%D9%82%D9%89%20%D8%A8%D8%B9%D9%8A%D8%AF%D8%A7%D9%8B%20%D8%B9%D9%86%20%D8%AA%D9%88%D9%85.)
^ar-Q0724-answer

**ar-Q0725** — طموحه أن يصبح سفيرا.

Her ambition is to become an ambassador.

Why: Content and purpose. [[Arabic#^ar-Q0725|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B7%D9%85%D9%88%D8%AD%D9%87%20%D8%A3%D9%86%20%D9%8A%D8%B5%D8%A8%D8%AD%20%D8%B3%D9%81%D9%8A%D8%B1%D8%A7.)
^ar-Q0725-answer

**ar-Q0726** — طموحه أن يصبح سفيرا.

Her ambition is to become an ambassador.

أن before a verb and أنّ before a nominal clause belong to distinct complement patterns. Purpose can use كي or related structures. Unvowelled أن requires contextual interpretation.

Why: Content and purpose. [[Arabic#^ar-Q0726|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B7%D9%85%D9%88%D8%AD%D9%87%20%D8%A3%D9%86%20%D9%8A%D8%B5%D8%A8%D8%AD%20%D8%B3%D9%81%D9%8A%D8%B1%D8%A7.)
^ar-Q0726-answer

**ar-Q0727** — أنّا لديها شعر بُني كستنائي, ولكن ماجدالينا لديها شعر أشقر.

Anna has chestnut brown hair, but Magdalena has blonde hair.

Expected form: **أن**

Why: Content and purpose. [[Arabic#^ar-Q0727|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D9%86%D9%91%D8%A7%20%D9%84%D8%AF%D9%8A%D9%87%D8%A7%20%D8%B4%D8%B9%D8%B1%20%D8%A8%D9%8F%D9%86%D9%8A%20%D9%83%D8%B3%D8%AA%D9%86%D8%A7%D8%A6%D9%8A%2C%20%D9%88%D9%84%D9%83%D9%86%20%D9%85%D8%A7%D8%AC%D8%AF%D8%A7%D9%84%D9%8A%D9%86%D8%A7%20%D9%84%D8%AF%D9%8A%D9%87%D8%A7%20%D8%B4%D8%B9%D8%B1%20%D8%A3%D8%B4%D9%82%D8%B1.)
^ar-Q0727-answer

**ar-Q0728** — أنّا لديها شعر بُني كستنائي, ولكن ماجدالينا لديها شعر أشقر.

Anna has chestnut brown hair, but Magdalena has blonde hair.

Expected form: **أن**

Why: Content and purpose. [[Arabic#^ar-Q0728|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D9%86%D9%91%D8%A7%20%D9%84%D8%AF%D9%8A%D9%87%D8%A7%20%D8%B4%D8%B9%D8%B1%20%D8%A8%D9%8F%D9%86%D9%8A%20%D9%83%D8%B3%D8%AA%D9%86%D8%A7%D8%A6%D9%8A%2C%20%D9%88%D9%84%D9%83%D9%86%20%D9%85%D8%A7%D8%AC%D8%AF%D8%A7%D9%84%D9%8A%D9%86%D8%A7%20%D9%84%D8%AF%D9%8A%D9%87%D8%A7%20%D8%B4%D8%B9%D8%B1%20%D8%A3%D8%B4%D9%82%D8%B1.)
^ar-Q0728-answer

**ar-Q0729** — يستطيع طفلهم أن يسير.

Their baby can walk.

Expected form: **أن**

Why: Content and purpose. [[Arabic#^ar-Q0729|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%8A%D8%B3%D8%AA%D8%B7%D9%8A%D8%B9%20%D8%B7%D9%81%D9%84%D9%87%D9%85%20%D8%A3%D9%86%20%D9%8A%D8%B3%D9%8A%D8%B1.)
^ar-Q0729-answer

**ar-Q0730** — يستطيع طفلهم أن يسير.

Their baby can walk.

Why: Content and purpose. [[Arabic#^ar-Q0730|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%8A%D8%B3%D8%AA%D8%B7%D9%8A%D8%B9%20%D8%B7%D9%81%D9%84%D9%87%D9%85%20%D8%A3%D9%86%20%D9%8A%D8%B3%D9%8A%D8%B1.)
^ar-Q0730-answer

**ar-Q0731** — قرر أن يصبح محامياً

He decided to be a lawyer.

Why: Content and purpose. [[Arabic#^ar-Q0731|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%82%D8%B1%D8%B1%20%D8%A3%D9%86%20%D9%8A%D8%B5%D8%A8%D8%AD%20%D9%85%D8%AD%D8%A7%D9%85%D9%8A%D8%A7%D9%8B)
^ar-Q0731-answer

**ar-Q0732** — قرر أن يصبح محامياً

He decided to be a lawyer.

أن before a verb and أنّ before a nominal clause belong to distinct complement patterns. Purpose can use كي or related structures. Unvowelled أن requires contextual interpretation.

Why: Content and purpose. [[Arabic#^ar-Q0732|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%82%D8%B1%D8%B1%20%D8%A3%D9%86%20%D9%8A%D8%B5%D8%A8%D8%AD%20%D9%85%D8%AD%D8%A7%D9%85%D9%8A%D8%A7%D9%8B)
^ar-Q0732-answer

**ar-Q0733** — هل سبق أن زرت بريطانيا؟

Have you ever been to Britain?

Expected form: **أن**

Why: Content and purpose. [[Arabic#^ar-Q0733|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D9%84%20%D8%B3%D8%A8%D9%82%20%D8%A3%D9%86%20%D8%B2%D8%B1%D8%AA%20%D8%A8%D8%B1%D9%8A%D8%B7%D8%A7%D9%86%D9%8A%D8%A7%D8%9F)
^ar-Q0733-answer

**ar-Q0734** — هل سبق أن زرت بريطانيا؟

Have you ever been to Britain?

Expected form: **أن**

Why: Content and purpose. [[Arabic#^ar-Q0734|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D9%84%20%D8%B3%D8%A8%D9%82%20%D8%A3%D9%86%20%D8%B2%D8%B1%D8%AA%20%D8%A8%D8%B1%D9%8A%D8%B7%D8%A7%D9%86%D9%8A%D8%A7%D8%9F)
^ar-Q0734-answer

**ar-Q0735** — رفض توم أن يفعل أي شيء قذر مع ماري.

Tom refused to soil his hands for Mary.

Expected form: **أن**

Why: Content and purpose. [[Arabic#^ar-Q0735|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B1%D9%81%D8%B6%20%D8%AA%D9%88%D9%85%20%D8%A3%D9%86%20%D9%8A%D9%81%D8%B9%D9%84%20%D8%A3%D9%8A%20%D8%B4%D9%8A%D8%A1%20%D9%82%D8%B0%D8%B1%20%D9%85%D8%B9%20%D9%85%D8%A7%D8%B1%D9%8A.)
^ar-Q0735-answer

**ar-Q0736** — رفض توم أن يفعل أي شيء قذر مع ماري.

Tom refused to soil his hands for Mary.

Why: Content and purpose. [[Arabic#^ar-Q0736|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B1%D9%81%D8%B6%20%D8%AA%D9%88%D9%85%20%D8%A3%D9%86%20%D9%8A%D9%81%D8%B9%D9%84%20%D8%A3%D9%8A%20%D8%B4%D9%8A%D8%A1%20%D9%82%D8%B0%D8%B1%20%D9%85%D8%B9%20%D9%85%D8%A7%D8%B1%D9%8A.)
^ar-Q0736-answer

**ar-Q0737** — أظن أنه من الأفضل أن أعود إلى المتجر.

I think I'd better go back to the shop.

Why: Content and purpose. [[Arabic#^ar-Q0737|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%B8%D9%86%20%D8%A3%D9%86%D9%87%20%D9%85%D9%86%20%D8%A7%D9%84%D8%A3%D9%81%D8%B6%D9%84%20%D8%A3%D9%86%20%D8%A3%D8%B9%D9%88%D8%AF%20%D8%A5%D9%84%D9%89%20%D8%A7%D9%84%D9%85%D8%AA%D8%AC%D8%B1.)
^ar-Q0737-answer

**ar-Q0738** — أظن أنه من الأفضل أن أعود إلى المتجر.

I think I'd better go back to the shop.

أن before a verb and أنّ before a nominal clause belong to distinct complement patterns. Purpose can use كي or related structures. Unvowelled أن requires contextual interpretation.

Why: Content and purpose. [[Arabic#^ar-Q0738|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%B8%D9%86%20%D8%A3%D9%86%D9%87%20%D9%85%D9%86%20%D8%A7%D9%84%D8%A3%D9%81%D8%B6%D9%84%20%D8%A3%D9%86%20%D8%A3%D8%B9%D9%88%D8%AF%20%D8%A5%D9%84%D9%89%20%D8%A7%D9%84%D9%85%D8%AA%D8%AC%D8%B1.)
^ar-Q0738-answer

**ar-Q0739** — أراد سامي أن يتزوّج من امرأة مسلمة.

Sami wanted to marry a Muslim woman.

Expected form: **أن**

Why: Content and purpose. [[Arabic#^ar-Q0739|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%B1%D8%A7%D8%AF%20%D8%B3%D8%A7%D9%85%D9%8A%20%D8%A3%D9%86%20%D9%8A%D8%AA%D8%B2%D9%88%D9%91%D8%AC%20%D9%85%D9%86%20%D8%A7%D9%85%D8%B1%D8%A3%D8%A9%20%D9%85%D8%B3%D9%84%D9%85%D8%A9.)
^ar-Q0739-answer

**ar-Q0740** — أراد سامي أن يتزوّج من امرأة مسلمة.

Sami wanted to marry a Muslim woman.

Expected form: **أن**

Why: Content and purpose. [[Arabic#^ar-Q0740|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%B1%D8%A7%D8%AF%20%D8%B3%D8%A7%D9%85%D9%8A%20%D8%A3%D9%86%20%D9%8A%D8%AA%D8%B2%D9%88%D9%91%D8%AC%20%D9%85%D9%86%20%D8%A7%D9%85%D8%B1%D8%A3%D8%A9%20%D9%85%D8%B3%D9%84%D9%85%D8%A9.)
^ar-Q0740-answer

**ar-Q0741** — من المحتمل أن تكون ليلى قد فرّت من المنزل مرّة أخرى.

Layla has probably run off again.

Expected form: **أن**

Why: Content and purpose. [[Arabic#^ar-Q0741|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D9%86%20%D8%A7%D9%84%D9%85%D8%AD%D8%AA%D9%85%D9%84%20%D8%A3%D9%86%20%D8%AA%D9%83%D9%88%D9%86%20%D9%84%D9%8A%D9%84%D9%89%20%D9%82%D8%AF%20%D9%81%D8%B1%D9%91%D8%AA%20%D9%85%D9%86%20%D8%A7%D9%84%D9%85%D9%86%D8%B2%D9%84%20%D9%85%D8%B1%D9%91%D8%A9%20%D8%A3%D8%AE%D8%B1%D9%89.)
^ar-Q0741-answer

**ar-Q0742** — من المحتمل أن تكون ليلى قد فرّت من المنزل مرّة أخرى.

Layla has probably run off again.

Why: Content and purpose. [[Arabic#^ar-Q0742|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D9%86%20%D8%A7%D9%84%D9%85%D8%AD%D8%AA%D9%85%D9%84%20%D8%A3%D9%86%20%D8%AA%D9%83%D9%88%D9%86%20%D9%84%D9%8A%D9%84%D9%89%20%D9%82%D8%AF%20%D9%81%D8%B1%D9%91%D8%AA%20%D9%85%D9%86%20%D8%A7%D9%84%D9%85%D9%86%D8%B2%D9%84%20%D9%85%D8%B1%D9%91%D8%A9%20%D8%A3%D8%AE%D8%B1%D9%89.)
^ar-Q0742-answer

**ar-Q0743** — يؤمن المسلمون أنّ يسوع واحد من رسل الله.

Muslims believe that Jesus was one of God's messengers.

Why: Content and purpose. [[Arabic#^ar-Q0743|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%8A%D8%A4%D9%85%D9%86%20%D8%A7%D9%84%D9%85%D8%B3%D9%84%D9%85%D9%88%D9%86%20%D8%A3%D9%86%D9%91%20%D9%8A%D8%B3%D9%88%D8%B9%20%D9%88%D8%A7%D8%AD%D8%AF%20%D9%85%D9%86%20%D8%B1%D8%B3%D9%84%20%D8%A7%D9%84%D9%84%D9%87.)
^ar-Q0743-answer

**ar-Q0744** — يؤمن المسلمون أنّ يسوع واحد من رسل الله.

Muslims believe that Jesus was one of God's messengers.

أن before a verb and أنّ before a nominal clause belong to distinct complement patterns. Purpose can use كي or related structures. Unvowelled أن requires contextual interpretation.

Why: Content and purpose. [[Arabic#^ar-Q0744|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%8A%D8%A4%D9%85%D9%86%20%D8%A7%D9%84%D9%85%D8%B3%D9%84%D9%85%D9%88%D9%86%20%D8%A3%D9%86%D9%91%20%D9%8A%D8%B3%D9%88%D8%B9%20%D9%88%D8%A7%D8%AD%D8%AF%20%D9%85%D9%86%20%D8%B1%D8%B3%D9%84%20%D8%A7%D9%84%D9%84%D9%87.)
^ar-Q0744-answer

**ar-Q0745** — هل لي أن أتحدث مع الطبيب؟

Can I speak to the doctor?

Expected form: **أن**

Why: Content and purpose. [[Arabic#^ar-Q0745|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D9%84%20%D9%84%D9%8A%20%D8%A3%D9%86%20%D8%A3%D8%AA%D8%AD%D8%AF%D8%AB%20%D9%85%D8%B9%20%D8%A7%D9%84%D8%B7%D8%A8%D9%8A%D8%A8%D8%9F)
^ar-Q0745-answer

**ar-Q0746** — هل لي أن أتحدث مع الطبيب؟

Can I speak to the doctor?

Expected form: **أن**

Why: Content and purpose. [[Arabic#^ar-Q0746|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D9%84%20%D9%84%D9%8A%20%D8%A3%D9%86%20%D8%A3%D8%AA%D8%AD%D8%AF%D8%AB%20%D9%85%D8%B9%20%D8%A7%D9%84%D8%B7%D8%A8%D9%8A%D8%A8%D8%9F)
^ar-Q0746-answer

**ar-Q0747** — قالت له أنه كان محقا.

She told him that he was right.

Expected form: **أنه**

Why: Content and purpose. [[Arabic#^ar-Q0747|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%82%D8%A7%D9%84%D8%AA%20%D9%84%D9%87%20%D8%A3%D9%86%D9%87%20%D9%83%D8%A7%D9%86%20%D9%85%D8%AD%D9%82%D8%A7.)
^ar-Q0747-answer

**ar-Q0748** — قالت له أنه كان محقا.

She told him that he was right.

Why: Content and purpose. [[Arabic#^ar-Q0748|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%82%D8%A7%D9%84%D8%AA%20%D9%84%D9%87%20%D8%A3%D9%86%D9%87%20%D9%83%D8%A7%D9%86%20%D9%85%D8%AD%D9%82%D8%A7.)
^ar-Q0748-answer

**ar-Q0749** — ليس بإمكان جوجل أن يجد كل شيء على الإنترنت.

Not everything on the web can be found through Google.

Why: Content and purpose. [[Arabic#^ar-Q0749|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%8A%D8%B3%20%D8%A8%D8%A5%D9%85%D9%83%D8%A7%D9%86%20%D8%AC%D9%88%D8%AC%D9%84%20%D8%A3%D9%86%20%D9%8A%D8%AC%D8%AF%20%D9%83%D9%84%20%D8%B4%D9%8A%D8%A1%20%D8%B9%D9%84%D9%89%20%D8%A7%D9%84%D8%A5%D9%86%D8%AA%D8%B1%D9%86%D8%AA.)
^ar-Q0749-answer

**ar-Q0750** — ليس بإمكان جوجل أن يجد كل شيء على الإنترنت.

Not everything on the web can be found through Google.

أن before a verb and أنّ before a nominal clause belong to distinct complement patterns. Purpose can use كي or related structures. Unvowelled أن requires contextual interpretation.

Why: Content and purpose. [[Arabic#^ar-Q0750|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%8A%D8%B3%20%D8%A8%D8%A5%D9%85%D9%83%D8%A7%D9%86%20%D8%AC%D9%88%D8%AC%D9%84%20%D8%A3%D9%86%20%D9%8A%D8%AC%D8%AF%20%D9%83%D9%84%20%D8%B4%D9%8A%D8%A1%20%D8%B9%D9%84%D9%89%20%D8%A7%D9%84%D8%A5%D9%86%D8%AA%D8%B1%D9%86%D8%AA.)
^ar-Q0750-answer


### Answers 751–800

**ar-Q0751** — "هل قبلتها؟" "نعم، قبلتها.

"Did you kiss her?" "Yes, I kissed her."

Expected form: **هل**

Why: Questions. [[Arabic#^ar-Q0751|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%22%D9%87%D9%84%20%D9%82%D8%A8%D9%84%D8%AA%D9%87%D8%A7%D8%9F%22%20%22%D9%86%D8%B9%D9%85%D8%8C%20%D9%82%D8%A8%D9%84%D8%AA%D9%87%D8%A7.)
^ar-Q0751-answer

**ar-Q0752** — "هل قبلتها؟" "نعم، قبلتها.

"Did you kiss her?" "Yes, I kissed her."

Expected form: **هل**

Why: Questions. [[Arabic#^ar-Q0752|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%22%D9%87%D9%84%20%D9%82%D8%A8%D9%84%D8%AA%D9%87%D8%A7%D8%9F%22%20%22%D9%86%D8%B9%D9%85%D8%8C%20%D9%82%D8%A8%D9%84%D8%AA%D9%87%D8%A7.)
^ar-Q0752-answer

**ar-Q0753** — متى يمكننا الأكل؟

When can we eat?

Expected form: **متى**

Why: Questions. [[Arabic#^ar-Q0753|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D8%AA%D9%89%20%D9%8A%D9%85%D9%83%D9%86%D9%86%D8%A7%20%D8%A7%D9%84%D8%A3%D9%83%D9%84%D8%9F)
^ar-Q0753-answer

**ar-Q0754** — متى يمكننا الأكل؟

When can we eat?

Why: Questions. [[Arabic#^ar-Q0754|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D8%AA%D9%89%20%D9%8A%D9%85%D9%83%D9%86%D9%86%D8%A7%20%D8%A7%D9%84%D8%A3%D9%83%D9%84%D8%9F)
^ar-Q0754-answer

**ar-Q0755** — هل خرجت ليلة الأمس؟

Did you go out last night?

Why: Questions. [[Arabic#^ar-Q0755|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D9%84%20%D8%AE%D8%B1%D8%AC%D8%AA%20%D9%84%D9%8A%D9%84%D8%A9%20%D8%A7%D9%84%D8%A3%D9%85%D8%B3%D8%9F)
^ar-Q0755-answer

**ar-Q0756** — هل خرجت ليلة الأمس؟

Did you go out last night?

هل forms many yes/no questions; other words request specific information. من can be who or from, depending on structure and pronunciation. Preserve the intended question relation.

Why: Questions. [[Arabic#^ar-Q0756|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D9%84%20%D8%AE%D8%B1%D8%AC%D8%AA%20%D9%84%D9%8A%D9%84%D8%A9%20%D8%A7%D9%84%D8%A3%D9%85%D8%B3%D8%9F)
^ar-Q0756-answer

**ar-Q0757** — متى سينتهي العالم؟

When will the world come to an end?

Expected form: **متى**

Why: Questions. [[Arabic#^ar-Q0757|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D8%AA%D9%89%20%D8%B3%D9%8A%D9%86%D8%AA%D9%87%D9%8A%20%D8%A7%D9%84%D8%B9%D8%A7%D9%84%D9%85%D8%9F)
^ar-Q0757-answer

**ar-Q0758** — متى سينتهي العالم؟

When will the world come to an end?

Expected form: **متى**

Why: Questions. [[Arabic#^ar-Q0758|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D8%AA%D9%89%20%D8%B3%D9%8A%D9%86%D8%AA%D9%87%D9%8A%20%D8%A7%D9%84%D8%B9%D8%A7%D9%84%D9%85%D8%9F)
^ar-Q0758-answer

**ar-Q0759** — هل الجميع جاهز؟

Are you all ready?

Expected form: **هل**

Why: Questions. [[Arabic#^ar-Q0759|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D9%84%20%D8%A7%D9%84%D8%AC%D9%85%D9%8A%D8%B9%20%D8%AC%D8%A7%D9%87%D8%B2%D8%9F)
^ar-Q0759-answer

**ar-Q0760** — هل الجميع جاهز؟

Are you all ready?

Why: Questions. [[Arabic#^ar-Q0760|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D9%84%20%D8%A7%D9%84%D8%AC%D9%85%D9%8A%D8%B9%20%D8%AC%D8%A7%D9%87%D8%B2%D8%9F)
^ar-Q0760-answer

**ar-Q0761** — كم من حلقة من وان بيس شاهدت؟

How many episodes of One Piece have you watched?

Why: Questions. [[Arabic#^ar-Q0761|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D9%85%20%D9%85%D9%86%20%D8%AD%D9%84%D9%82%D8%A9%20%D9%85%D9%86%20%D9%88%D8%A7%D9%86%20%D8%A8%D9%8A%D8%B3%20%D8%B4%D8%A7%D9%87%D8%AF%D8%AA%D8%9F)
^ar-Q0761-answer

**ar-Q0762** — كم من حلقة من وان بيس شاهدت؟

How many episodes of One Piece have you watched?

هل forms many yes/no questions; other words request specific information. من can be who or from, depending on structure and pronunciation. Preserve the intended question relation.

Why: Questions. [[Arabic#^ar-Q0762|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D9%85%20%D9%85%D9%86%20%D8%AD%D9%84%D9%82%D8%A9%20%D9%85%D9%86%20%D9%88%D8%A7%D9%86%20%D8%A8%D9%8A%D8%B3%20%D8%B4%D8%A7%D9%87%D8%AF%D8%AA%D8%9F)
^ar-Q0762-answer

**ar-Q0763** — قابل سامي مسلمين من بلدان مختلفة.

Sami met Muslims from various countries.

Expected form: **من**

Why: Questions. [[Arabic#^ar-Q0763|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%82%D8%A7%D8%A8%D9%84%20%D8%B3%D8%A7%D9%85%D9%8A%20%D9%85%D8%B3%D9%84%D9%85%D9%8A%D9%86%20%D9%85%D9%86%20%D8%A8%D9%84%D8%AF%D8%A7%D9%86%20%D9%85%D8%AE%D8%AA%D9%84%D9%81%D8%A9.)
^ar-Q0763-answer

**ar-Q0764** — قابل سامي مسلمين من بلدان مختلفة.

Sami met Muslims from various countries.

Expected form: **من**

Why: Questions. [[Arabic#^ar-Q0764|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%82%D8%A7%D8%A8%D9%84%20%D8%B3%D8%A7%D9%85%D9%8A%20%D9%85%D8%B3%D9%84%D9%85%D9%8A%D9%86%20%D9%85%D9%86%20%D8%A8%D9%84%D8%AF%D8%A7%D9%86%20%D9%85%D8%AE%D8%AA%D9%84%D9%81%D8%A9.)
^ar-Q0764-answer

**ar-Q0765** — لماذا تركت عملك في المزرعة؟

Why did you leave your job on the farm?

Expected form: **لماذا**

Why: Questions. [[Arabic#^ar-Q0765|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%85%D8%A7%D8%B0%D8%A7%20%D8%AA%D8%B1%D9%83%D8%AA%20%D8%B9%D9%85%D9%84%D9%83%20%D9%81%D9%8A%20%D8%A7%D9%84%D9%85%D8%B2%D8%B1%D8%B9%D8%A9%D8%9F)
^ar-Q0765-answer

**ar-Q0766** — لماذا تركت عملك في المزرعة؟

Why did you leave your job on the farm?

Why: Questions. [[Arabic#^ar-Q0766|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%85%D8%A7%D8%B0%D8%A7%20%D8%AA%D8%B1%D9%83%D8%AA%20%D8%B9%D9%85%D9%84%D9%83%20%D9%81%D9%8A%20%D8%A7%D9%84%D9%85%D8%B2%D8%B1%D8%B9%D8%A9%D8%9F)
^ar-Q0766-answer

**ar-Q0767** — المغسلة صنعت من الجرانيت

The washbasin is made of granite.

Why: Questions. [[Arabic#^ar-Q0767|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A7%D9%84%D9%85%D8%BA%D8%B3%D9%84%D8%A9%20%D8%B5%D9%86%D8%B9%D8%AA%20%D9%85%D9%86%20%D8%A7%D9%84%D8%AC%D8%B1%D8%A7%D9%86%D9%8A%D8%AA)
^ar-Q0767-answer

**ar-Q0768** — المغسلة صنعت من الجرانيت

The washbasin is made of granite.

هل forms many yes/no questions; other words request specific information. من can be who or from, depending on structure and pronunciation. Preserve the intended question relation.

Why: Questions. [[Arabic#^ar-Q0768|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A7%D9%84%D9%85%D8%BA%D8%B3%D9%84%D8%A9%20%D8%B5%D9%86%D8%B9%D8%AA%20%D9%85%D9%86%20%D8%A7%D9%84%D8%AC%D8%B1%D8%A7%D9%86%D9%8A%D8%AA)
^ar-Q0768-answer

**ar-Q0769** — هل تستطيع السباحة؟

Are you able to swim?

Expected form: **هل**

Why: Questions. [[Arabic#^ar-Q0769|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D9%84%20%D8%AA%D8%B3%D8%AA%D8%B7%D9%8A%D8%B9%20%D8%A7%D9%84%D8%B3%D8%A8%D8%A7%D8%AD%D8%A9%D8%9F)
^ar-Q0769-answer

**ar-Q0770** — هل تستطيع السباحة؟

Are you able to swim?

Expected form: **هل**

Why: Questions. [[Arabic#^ar-Q0770|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D9%84%20%D8%AA%D8%B3%D8%AA%D8%B7%D9%8A%D8%B9%20%D8%A7%D9%84%D8%B3%D8%A8%D8%A7%D8%AD%D8%A9%D8%9F)
^ar-Q0770-answer

**ar-Q0771** — من الأفضل لك التوقف عن التدخين.

You had better stop smoking.

Expected form: **من**

Why: Questions. [[Arabic#^ar-Q0771|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D9%86%20%D8%A7%D9%84%D8%A3%D9%81%D8%B6%D9%84%20%D9%84%D9%83%20%D8%A7%D9%84%D8%AA%D9%88%D9%82%D9%81%20%D8%B9%D9%86%20%D8%A7%D9%84%D8%AA%D8%AF%D8%AE%D9%8A%D9%86.)
^ar-Q0771-answer

**ar-Q0772** — من الأفضل لك التوقف عن التدخين.

You had better stop smoking.

Why: Questions. [[Arabic#^ar-Q0772|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D9%86%20%D8%A7%D9%84%D8%A3%D9%81%D8%B6%D9%84%20%D9%84%D9%83%20%D8%A7%D9%84%D8%AA%D9%88%D9%82%D9%81%20%D8%B9%D9%86%20%D8%A7%D9%84%D8%AA%D8%AF%D8%AE%D9%8A%D9%86.)
^ar-Q0772-answer

**ar-Q0773** — هل تملِكينَ لوحة المفاتيح الأمازيغية على حاسوبِكِ؟

Do you have the berber keyboard on your computer?

Why: Questions. [[Arabic#^ar-Q0773|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D9%84%20%D8%AA%D9%85%D9%84%D9%90%D9%83%D9%8A%D9%86%D9%8E%20%D9%84%D9%88%D8%AD%D8%A9%20%D8%A7%D9%84%D9%85%D9%81%D8%A7%D8%AA%D9%8A%D8%AD%20%D8%A7%D9%84%D8%A3%D9%85%D8%A7%D8%B2%D9%8A%D8%BA%D9%8A%D8%A9%20%D8%B9%D9%84%D9%89%20%D8%AD%D8%A7%D8%B3%D9%88%D8%A8%D9%90%D9%83%D9%90%D8%9F)
^ar-Q0773-answer

**ar-Q0774** — هل تملِكينَ لوحة المفاتيح الأمازيغية على حاسوبِكِ؟

Do you have the berber keyboard on your computer?

هل forms many yes/no questions; other words request specific information. من can be who or from, depending on structure and pronunciation. Preserve the intended question relation.

Why: Questions. [[Arabic#^ar-Q0774|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D9%84%20%D8%AA%D9%85%D9%84%D9%90%D9%83%D9%8A%D9%86%D9%8E%20%D9%84%D9%88%D8%AD%D8%A9%20%D8%A7%D9%84%D9%85%D9%81%D8%A7%D8%AA%D9%8A%D8%AD%20%D8%A7%D9%84%D8%A3%D9%85%D8%A7%D8%B2%D9%8A%D8%BA%D9%8A%D8%A9%20%D8%B9%D9%84%D9%89%20%D8%AD%D8%A7%D8%B3%D9%88%D8%A8%D9%90%D9%83%D9%90%D8%9F)
^ar-Q0774-answer

**ar-Q0775** — اضطرّ سامي على حذف الفيديو من يوتوب.

Sami had to take his YouTube video down.

Expected form: **من**

Why: Questions. [[Arabic#^ar-Q0775|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A7%D8%B6%D8%B7%D8%B1%D9%91%20%D8%B3%D8%A7%D9%85%D9%8A%20%D8%B9%D9%84%D9%89%20%D8%AD%D8%B0%D9%81%20%D8%A7%D9%84%D9%81%D9%8A%D8%AF%D9%8A%D9%88%20%D9%85%D9%86%20%D9%8A%D9%88%D8%AA%D9%88%D8%A8.)
^ar-Q0775-answer

**ar-Q0776** — اضطرّ سامي على حذف الفيديو من يوتوب.

Sami had to take his YouTube video down.

Expected form: **من**

Why: Questions. [[Arabic#^ar-Q0776|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A7%D8%B6%D8%B7%D8%B1%D9%91%20%D8%B3%D8%A7%D9%85%D9%8A%20%D8%B9%D9%84%D9%89%20%D8%AD%D8%B0%D9%81%20%D8%A7%D9%84%D9%81%D9%8A%D8%AF%D9%8A%D9%88%20%D9%85%D9%86%20%D9%8A%D9%88%D8%AA%D9%88%D8%A8.)
^ar-Q0776-answer

**ar-Q0777** — من سيتحمل المسؤولية بالنسبة لهذا الأمر؟

Who's taking responsibility for this?

Expected form: **من**

Why: Questions. [[Arabic#^ar-Q0777|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D9%86%20%D8%B3%D9%8A%D8%AA%D8%AD%D9%85%D9%84%20%D8%A7%D9%84%D9%85%D8%B3%D8%A4%D9%88%D9%84%D9%8A%D8%A9%20%D8%A8%D8%A7%D9%84%D9%86%D8%B3%D8%A8%D8%A9%20%D9%84%D9%87%D8%B0%D8%A7%20%D8%A7%D9%84%D8%A3%D9%85%D8%B1%D8%9F)
^ar-Q0777-answer

**ar-Q0778** — من سيتحمل المسؤولية بالنسبة لهذا الأمر؟

Who's taking responsibility for this?

Why: Questions. [[Arabic#^ar-Q0778|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D9%86%20%D8%B3%D9%8A%D8%AA%D8%AD%D9%85%D9%84%20%D8%A7%D9%84%D9%85%D8%B3%D8%A4%D9%88%D9%84%D9%8A%D8%A9%20%D8%A8%D8%A7%D9%84%D9%86%D8%B3%D8%A8%D8%A9%20%D9%84%D9%87%D8%B0%D8%A7%20%D8%A7%D9%84%D8%A3%D9%85%D8%B1%D8%9F)
^ar-Q0778-answer

**ar-Q0779** — هل هي يابانية؟

Is she Japanese?

Why: Questions. [[Arabic#^ar-Q0779|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D9%84%20%D9%87%D9%8A%20%D9%8A%D8%A7%D8%A8%D8%A7%D9%86%D9%8A%D8%A9%D8%9F)
^ar-Q0779-answer

**ar-Q0780** — هل هي يابانية؟

Is she Japanese?

هل forms many yes/no questions; other words request specific information. من can be who or from, depending on structure and pronunciation. Preserve the intended question relation.

Why: Questions. [[Arabic#^ar-Q0780|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D9%84%20%D9%87%D9%8A%20%D9%8A%D8%A7%D8%A8%D8%A7%D9%86%D9%8A%D8%A9%D8%9F)
^ar-Q0780-answer

**ar-Q0781** — هل تعرف أخاهم؟

Do you know their brother?

Expected form: **هل**

Why: Questions. [[Arabic#^ar-Q0781|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D9%84%20%D8%AA%D8%B9%D8%B1%D9%81%20%D8%A3%D8%AE%D8%A7%D9%87%D9%85%D8%9F)
^ar-Q0781-answer

**ar-Q0782** — هل تعرف أخاهم؟

Do you know their brother?

Expected form: **هل**

Why: Questions. [[Arabic#^ar-Q0782|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D9%84%20%D8%AA%D8%B9%D8%B1%D9%81%20%D8%A3%D8%AE%D8%A7%D9%87%D9%85%D8%9F)
^ar-Q0782-answer

**ar-Q0783** — زوجتي و ماري كانوا في الجزء الخلفي من الطائرة .

My wife and Mary were in the rear of the aircraft.

Expected form: **من**

Why: Questions. [[Arabic#^ar-Q0783|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B2%D9%88%D8%AC%D8%AA%D9%8A%20%D9%88%20%D9%85%D8%A7%D8%B1%D9%8A%20%D9%83%D8%A7%D9%86%D9%88%D8%A7%20%D9%81%D9%8A%20%D8%A7%D9%84%D8%AC%D8%B2%D8%A1%20%D8%A7%D9%84%D8%AE%D9%84%D9%81%D9%8A%20%D9%85%D9%86%20%D8%A7%D9%84%D8%B7%D8%A7%D8%A6%D8%B1%D8%A9%20.)
^ar-Q0783-answer

**ar-Q0784** — زوجتي و ماري كانوا في الجزء الخلفي من الطائرة .

My wife and Mary were in the rear of the aircraft.

Why: Questions. [[Arabic#^ar-Q0784|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B2%D9%88%D8%AC%D8%AA%D9%8A%20%D9%88%20%D9%85%D8%A7%D8%B1%D9%8A%20%D9%83%D8%A7%D9%86%D9%88%D8%A7%20%D9%81%D9%8A%20%D8%A7%D9%84%D8%AC%D8%B2%D8%A1%20%D8%A7%D9%84%D8%AE%D9%84%D9%81%D9%8A%20%D9%85%D9%86%20%D8%A7%D9%84%D8%B7%D8%A7%D8%A6%D8%B1%D8%A9%20.)
^ar-Q0784-answer

**ar-Q0785** — كم الساعة على أي حال؟

What time is it, anyway?

Why: Questions. [[Arabic#^ar-Q0785|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D9%85%20%D8%A7%D9%84%D8%B3%D8%A7%D8%B9%D8%A9%20%D8%B9%D9%84%D9%89%20%D8%A3%D9%8A%20%D8%AD%D8%A7%D9%84%D8%9F)
^ar-Q0785-answer

**ar-Q0786** — كم الساعة على أي حال؟

What time is it, anyway?

هل forms many yes/no questions; other words request specific information. من can be who or from, depending on structure and pronunciation. Preserve the intended question relation.

Why: Questions. [[Arabic#^ar-Q0786|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D9%85%20%D8%A7%D9%84%D8%B3%D8%A7%D8%B9%D8%A9%20%D8%B9%D9%84%D9%89%20%D8%A3%D9%8A%20%D8%AD%D8%A7%D9%84%D8%9F)
^ar-Q0786-answer

**ar-Q0787** — هل زرت أمريكا من قبل؟

Have you ever been to America?

Expected form: **هل**

Why: Questions. [[Arabic#^ar-Q0787|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D9%84%20%D8%B2%D8%B1%D8%AA%20%D8%A3%D9%85%D8%B1%D9%8A%D9%83%D8%A7%20%D9%85%D9%86%20%D9%82%D8%A8%D9%84%D8%9F)
^ar-Q0787-answer

**ar-Q0788** — هل زرت أمريكا من قبل؟

Have you ever been to America?

Expected form: **هل**

Why: Questions. [[Arabic#^ar-Q0788|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D9%84%20%D8%B2%D8%B1%D8%AA%20%D8%A3%D9%85%D8%B1%D9%8A%D9%83%D8%A7%20%D9%85%D9%86%20%D9%82%D8%A8%D9%84%D8%9F)
^ar-Q0788-answer

**ar-Q0789** — هناك العديد من السياح الصينيين بالقرب من هنا.

There are a lot of Chinese tourists around here.

Expected form: **من**

Why: Questions. [[Arabic#^ar-Q0789|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D9%86%D8%A7%D9%83%20%D8%A7%D9%84%D8%B9%D8%AF%D9%8A%D8%AF%20%D9%85%D9%86%20%D8%A7%D9%84%D8%B3%D9%8A%D8%A7%D8%AD%20%D8%A7%D9%84%D8%B5%D9%8A%D9%86%D9%8A%D9%8A%D9%86%20%D8%A8%D8%A7%D9%84%D9%82%D8%B1%D8%A8%20%D9%85%D9%86%20%D9%87%D9%86%D8%A7.)
^ar-Q0789-answer

**ar-Q0790** — هناك العديد من السياح الصينيين بالقرب من هنا.

There are a lot of Chinese tourists around here.

Why: Questions. [[Arabic#^ar-Q0790|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D9%86%D8%A7%D9%83%20%D8%A7%D9%84%D8%B9%D8%AF%D9%8A%D8%AF%20%D9%85%D9%86%20%D8%A7%D9%84%D8%B3%D9%8A%D8%A7%D8%AD%20%D8%A7%D9%84%D8%B5%D9%8A%D9%86%D9%8A%D9%8A%D9%86%20%D8%A8%D8%A7%D9%84%D9%82%D8%B1%D8%A8%20%D9%85%D9%86%20%D9%87%D9%86%D8%A7.)
^ar-Q0790-answer

**ar-Q0791** — هل ذاك الكتاب لك؟

Is this book yours?

Why: Questions. [[Arabic#^ar-Q0791|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D9%84%20%D8%B0%D8%A7%D9%83%20%D8%A7%D9%84%D9%83%D8%AA%D8%A7%D8%A8%20%D9%84%D9%83%D8%9F)
^ar-Q0791-answer

**ar-Q0792** — هل ذاك الكتاب لك؟

Is this book yours?

هل forms many yes/no questions; other words request specific information. من can be who or from, depending on structure and pronunciation. Preserve the intended question relation.

Why: Questions. [[Arabic#^ar-Q0792|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D9%84%20%D8%B0%D8%A7%D9%83%20%D8%A7%D9%84%D9%83%D8%AA%D8%A7%D8%A8%20%D9%84%D9%83%D8%9F)
^ar-Q0792-answer

**ar-Q0793** — شرب سامي قارورة كاملة من الأقراص.

Sami swallowed a whole bottle of pills.

Expected form: **من**

Why: Questions. [[Arabic#^ar-Q0793|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B4%D8%B1%D8%A8%20%D8%B3%D8%A7%D9%85%D9%8A%20%D9%82%D8%A7%D8%B1%D9%88%D8%B1%D8%A9%20%D9%83%D8%A7%D9%85%D9%84%D8%A9%20%D9%85%D9%86%20%D8%A7%D9%84%D8%A3%D9%82%D8%B1%D8%A7%D8%B5.)
^ar-Q0793-answer

**ar-Q0794** — شرب سامي قارورة كاملة من الأقراص.

Sami swallowed a whole bottle of pills.

Expected form: **من**

Why: Questions. [[Arabic#^ar-Q0794|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B4%D8%B1%D8%A8%20%D8%B3%D8%A7%D9%85%D9%8A%20%D9%82%D8%A7%D8%B1%D9%88%D8%B1%D8%A9%20%D9%83%D8%A7%D9%85%D9%84%D8%A9%20%D9%85%D9%86%20%D8%A7%D9%84%D8%A3%D9%82%D8%B1%D8%A7%D8%B5.)
^ar-Q0794-answer

**ar-Q0795** — متى سنقيم الحفلة؟

When shall we have the party?

Expected form: **متى**

Why: Questions. [[Arabic#^ar-Q0795|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D8%AA%D9%89%20%D8%B3%D9%86%D9%82%D9%8A%D9%85%20%D8%A7%D9%84%D8%AD%D9%81%D9%84%D8%A9%D8%9F)
^ar-Q0795-answer

**ar-Q0796** — متى سنقيم الحفلة؟

When shall we have the party?

Why: Questions. [[Arabic#^ar-Q0796|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D8%AA%D9%89%20%D8%B3%D9%86%D9%82%D9%8A%D9%85%20%D8%A7%D9%84%D8%AD%D9%81%D9%84%D8%A9%D8%9F)
^ar-Q0796-answer

**ar-Q0797** — كيف أصل إلى شارع بارك؟

How do I get to Park Street?

Why: Questions. [[Arabic#^ar-Q0797|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D9%8A%D9%81%20%D8%A3%D8%B5%D9%84%20%D8%A5%D9%84%D9%89%20%D8%B4%D8%A7%D8%B1%D8%B9%20%D8%A8%D8%A7%D8%B1%D9%83%D8%9F)
^ar-Q0797-answer

**ar-Q0798** — كيف أصل إلى شارع بارك؟

How do I get to Park Street?

هل forms many yes/no questions; other words request specific information. من can be who or from, depending on structure and pronunciation. Preserve the intended question relation.

Why: Questions. [[Arabic#^ar-Q0798|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D9%8A%D9%81%20%D8%A3%D8%B5%D9%84%20%D8%A5%D9%84%D9%89%20%D8%B4%D8%A7%D8%B1%D8%B9%20%D8%A8%D8%A7%D8%B1%D9%83%D8%9F)
^ar-Q0798-answer

**ar-Q0799** — أين هو المرحاض، من فضلك؟

Where are the toilets, please?

Expected form: **أين**

Why: Questions. [[Arabic#^ar-Q0799|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D9%8A%D9%86%20%D9%87%D9%88%20%D8%A7%D9%84%D9%85%D8%B1%D8%AD%D8%A7%D8%B6%D8%8C%20%D9%85%D9%86%20%D9%81%D8%B6%D9%84%D9%83%D8%9F)
^ar-Q0799-answer

**ar-Q0800** — أين هو المرحاض، من فضلك؟

Where are the toilets, please?

Expected form: **أين**

Why: Questions. [[Arabic#^ar-Q0800|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D9%8A%D9%86%20%D9%87%D9%88%20%D8%A7%D9%84%D9%85%D8%B1%D8%AD%D8%A7%D8%B6%D8%8C%20%D9%85%D9%86%20%D9%81%D8%B6%D9%84%D9%83%D8%9F)
^ar-Q0800-answer


### Answers 801–850

**ar-Q0801** — غيري العلم، لو سمحت.

Change the flag, please.

Expected form: **لو**

Why: Conditions. [[Arabic#^ar-Q0801|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%BA%D9%8A%D8%B1%D9%8A%20%D8%A7%D9%84%D8%B9%D9%84%D9%85%D8%8C%20%D9%84%D9%88%20%D8%B3%D9%85%D8%AD%D8%AA.)
^ar-Q0801-answer

**ar-Q0802** — غيري العلم، لو سمحت.

Change the flag, please.

Why: Conditions. [[Arabic#^ar-Q0802|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%BA%D9%8A%D8%B1%D9%8A%20%D8%A7%D9%84%D8%B9%D9%84%D9%85%D8%8C%20%D9%84%D9%88%20%D8%B3%D9%85%D8%AD%D8%AA.)
^ar-Q0802-answer

**ar-Q0803** — ”أنا أكرهكِ.“ ”طلّقني إذا. “

"I hate you." "Divorce me then."

Why: Conditions. [[Arabic#^ar-Q0803|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%E2%80%9D%D8%A3%D9%86%D8%A7%20%D8%A3%D9%83%D8%B1%D9%87%D9%83%D9%90.%E2%80%9C%20%E2%80%9D%D8%B7%D9%84%D9%91%D9%82%D9%86%D9%8A%20%D8%A5%D8%B0%D8%A7.%20%E2%80%9C)
^ar-Q0803-answer

**ar-Q0804** — ”أنا أكرهكِ.“ ”طلّقني إذا. “

"I hate you." "Divorce me then."

إذا commonly frames expected/real conditions, إن conditional patterns with specific MSA mood rules, and لو many counterfactuals. These are not freely interchangeable English if equivalents.

Why: Conditions. [[Arabic#^ar-Q0804|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%E2%80%9D%D8%A3%D9%86%D8%A7%20%D8%A3%D9%83%D8%B1%D9%87%D9%83%D9%90.%E2%80%9C%20%E2%80%9D%D8%B7%D9%84%D9%91%D9%82%D9%86%D9%8A%20%D8%A5%D8%B0%D8%A7.%20%E2%80%9C)
^ar-Q0804-answer

**ar-Q0805** — الأعداد الأولية مثل الحياة، منطقية تمامًا، لكن يستحيل إيجاد القواعد لها، حتى لو أمضيت وقتك كله تفكر فيها.

Prime numbers are like life; they are completely logical, but impossible to find the rules for, even if you spend all your time thinking about it.

Expected form: **لو**

Why: Conditions. [[Arabic#^ar-Q0805|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A7%D9%84%D8%A3%D8%B9%D8%AF%D8%A7%D8%AF%20%D8%A7%D9%84%D8%A3%D9%88%D9%84%D9%8A%D8%A9%20%D9%85%D8%AB%D9%84%20%D8%A7%D9%84%D8%AD%D9%8A%D8%A7%D8%A9%D8%8C%20%D9%85%D9%86%D8%B7%D9%82%D9%8A%D8%A9%20%D8%AA%D9%85%D8%A7%D9%85%D9%8B%D8%A7%D8%8C%20%D9%84%D9%83%D9%86%20%D9%8A%D8%B3%D8%AA%D8%AD%D9%8A%D9%84%20%D8%A5%D9%8A%D8%AC%D8%A7%D8%AF%20%D8%A7%D9%84%D9%82%D9%88%D8%A7%D8%B9%D8%AF%20%D9%84%D9%87%D8%A7%D8%8C%20%D8%AD%D8%AA%D9%89%20%D9%84%D9%88%20%D8%A3%D9%85%D8%B6%D9%8A%D8%AA%20%D9%88%D9%82%D8%AA%D9%83%20%D9%83%D9%84%D9%87%20%D8%AA%D9%81%D9%83%D8%B1%20%D9%81%D9%8A%D9%87%D8%A7.)
^ar-Q0805-answer

**ar-Q0806** — الأعداد الأولية مثل الحياة، منطقية تمامًا، لكن يستحيل إيجاد القواعد لها، حتى لو أمضيت وقتك كله تفكر فيها.

Prime numbers are like life; they are completely logical, but impossible to find the rules for, even if you spend all your time thinking about it.

Expected form: **لو**

Why: Conditions. [[Arabic#^ar-Q0806|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A7%D9%84%D8%A3%D8%B9%D8%AF%D8%A7%D8%AF%20%D8%A7%D9%84%D8%A3%D9%88%D9%84%D9%8A%D8%A9%20%D9%85%D8%AB%D9%84%20%D8%A7%D9%84%D8%AD%D9%8A%D8%A7%D8%A9%D8%8C%20%D9%85%D9%86%D8%B7%D9%82%D9%8A%D8%A9%20%D8%AA%D9%85%D8%A7%D9%85%D9%8B%D8%A7%D8%8C%20%D9%84%D9%83%D9%86%20%D9%8A%D8%B3%D8%AA%D8%AD%D9%8A%D9%84%20%D8%A5%D9%8A%D8%AC%D8%A7%D8%AF%20%D8%A7%D9%84%D9%82%D9%88%D8%A7%D8%B9%D8%AF%20%D9%84%D9%87%D8%A7%D8%8C%20%D8%AD%D8%AA%D9%89%20%D9%84%D9%88%20%D8%A3%D9%85%D8%B6%D9%8A%D8%AA%20%D9%88%D9%82%D8%AA%D9%83%20%D9%83%D9%84%D9%87%20%D8%AA%D9%81%D9%83%D8%B1%20%D9%81%D9%8A%D9%87%D8%A7.)
^ar-Q0806-answer

**ar-Q0807** — أتمنى لو كان هناك المزيد من الناس مثلك.

I wish there were more people like you.

Expected form: **لو**

Why: Conditions. [[Arabic#^ar-Q0807|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%AA%D9%85%D9%86%D9%89%20%D9%84%D9%88%20%D9%83%D8%A7%D9%86%20%D9%87%D9%86%D8%A7%D9%83%20%D8%A7%D9%84%D9%85%D8%B2%D9%8A%D8%AF%20%D9%85%D9%86%20%D8%A7%D9%84%D9%86%D8%A7%D8%B3%20%D9%85%D8%AB%D9%84%D9%83.)
^ar-Q0807-answer

**ar-Q0808** — أتمنى لو كان هناك المزيد من الناس مثلك.

I wish there were more people like you.

Why: Conditions. [[Arabic#^ar-Q0808|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%AA%D9%85%D9%86%D9%89%20%D9%84%D9%88%20%D9%83%D8%A7%D9%86%20%D9%87%D9%86%D8%A7%D9%83%20%D8%A7%D9%84%D9%85%D8%B2%D9%8A%D8%AF%20%D9%85%D9%86%20%D8%A7%D9%84%D9%86%D8%A7%D8%B3%20%D9%85%D8%AB%D9%84%D9%83.)
^ar-Q0808-answer

**ar-Q0809** — لو لم تساعدني، لما كنت سأنجح.

Were it not for your help, I could never succeed.

Why: Conditions. [[Arabic#^ar-Q0809|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%88%20%D9%84%D9%85%20%D8%AA%D8%B3%D8%A7%D8%B9%D8%AF%D9%86%D9%8A%D8%8C%20%D9%84%D9%85%D8%A7%20%D9%83%D9%86%D8%AA%20%D8%B3%D8%A3%D9%86%D8%AC%D8%AD.)
^ar-Q0809-answer

**ar-Q0810** — لو لم تساعدني، لما كنت سأنجح.

Were it not for your help, I could never succeed.

إذا commonly frames expected/real conditions, إن conditional patterns with specific MSA mood rules, and لو many counterfactuals. These are not freely interchangeable English if equivalents.

Why: Conditions. [[Arabic#^ar-Q0810|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%88%20%D9%84%D9%85%20%D8%AA%D8%B3%D8%A7%D8%B9%D8%AF%D9%86%D9%8A%D8%8C%20%D9%84%D9%85%D8%A7%20%D9%83%D9%86%D8%AA%20%D8%B3%D8%A3%D9%86%D8%AC%D8%AD.)
^ar-Q0810-answer

**ar-Q0811** — تعال معي إذا سمحت.

Come with me, will you?

Expected form: **إذا**

Why: Conditions. [[Arabic#^ar-Q0811|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%AA%D8%B9%D8%A7%D9%84%20%D9%85%D8%B9%D9%8A%20%D8%A5%D8%B0%D8%A7%20%D8%B3%D9%85%D8%AD%D8%AA.)
^ar-Q0811-answer

**ar-Q0812** — تعال معي إذا سمحت.

Come with me, will you?

Expected form: **إذا**

Why: Conditions. [[Arabic#^ar-Q0812|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%AA%D8%B9%D8%A7%D9%84%20%D9%85%D8%B9%D9%8A%20%D8%A5%D8%B0%D8%A7%20%D8%B3%D9%85%D8%AD%D8%AA.)
^ar-Q0812-answer

**ar-Q0813** — لا أعلم إذا كان توم جائعاً أم لا

I don't know whether Tom is hungry or not.

Expected form: **إذا**

Why: Conditions. [[Arabic#^ar-Q0813|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D8%A7%20%D8%A3%D8%B9%D9%84%D9%85%20%D8%A5%D8%B0%D8%A7%20%D9%83%D8%A7%D9%86%20%D8%AA%D9%88%D9%85%20%D8%AC%D8%A7%D8%A6%D8%B9%D8%A7%D9%8B%20%D8%A3%D9%85%20%D9%84%D8%A7)
^ar-Q0813-answer

**ar-Q0814** — لا أعلم إذا كان توم جائعاً أم لا

I don't know whether Tom is hungry or not.

Why: Conditions. [[Arabic#^ar-Q0814|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D8%A7%20%D8%A3%D8%B9%D9%84%D9%85%20%D8%A5%D8%B0%D8%A7%20%D9%83%D8%A7%D9%86%20%D8%AA%D9%88%D9%85%20%D8%AC%D8%A7%D8%A6%D8%B9%D8%A7%D9%8B%20%D8%A3%D9%85%20%D9%84%D8%A7)
^ar-Q0814-answer

**ar-Q0815** — لو سمحت، اترك رسالةً بعد الصفير، أو ألقِ بعض الحلوى في صندوق بريدنا.

Please leave a message after the beep or drop some candies in our mailbox.

Why: Conditions. [[Arabic#^ar-Q0815|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%88%20%D8%B3%D9%85%D8%AD%D8%AA%D8%8C%20%D8%A7%D8%AA%D8%B1%D9%83%20%D8%B1%D8%B3%D8%A7%D9%84%D8%A9%D9%8B%20%D8%A8%D8%B9%D8%AF%20%D8%A7%D9%84%D8%B5%D9%81%D9%8A%D8%B1%D8%8C%20%D8%A3%D9%88%20%D8%A3%D9%84%D9%82%D9%90%20%D8%A8%D8%B9%D8%B6%20%D8%A7%D9%84%D8%AD%D9%84%D9%88%D9%89%20%D9%81%D9%8A%20%D8%B5%D9%86%D8%AF%D9%88%D9%82%20%D8%A8%D8%B1%D9%8A%D8%AF%D9%86%D8%A7.)
^ar-Q0815-answer

**ar-Q0816** — لو سمحت، اترك رسالةً بعد الصفير، أو ألقِ بعض الحلوى في صندوق بريدنا.

Please leave a message after the beep or drop some candies in our mailbox.

إذا commonly frames expected/real conditions, إن conditional patterns with specific MSA mood rules, and لو many counterfactuals. These are not freely interchangeable English if equivalents.

Why: Conditions. [[Arabic#^ar-Q0816|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%88%20%D8%B3%D9%85%D8%AD%D8%AA%D8%8C%20%D8%A7%D8%AA%D8%B1%D9%83%20%D8%B1%D8%B3%D8%A7%D9%84%D8%A9%D9%8B%20%D8%A8%D8%B9%D8%AF%20%D8%A7%D9%84%D8%B5%D9%81%D9%8A%D8%B1%D8%8C%20%D8%A3%D9%88%20%D8%A3%D9%84%D9%82%D9%90%20%D8%A8%D8%B9%D8%B6%20%D8%A7%D9%84%D8%AD%D9%84%D9%88%D9%89%20%D9%81%D9%8A%20%D8%B5%D9%86%D8%AF%D9%88%D9%82%20%D8%A8%D8%B1%D9%8A%D8%AF%D9%86%D8%A7.)
^ar-Q0816-answer

**ar-Q0817** — إن المكان مُزدحم، دعنا نستقل القطار القادم.

It's crowded, so let's take the next train.

Expected form: **إن**

Why: Conditions. [[Arabic#^ar-Q0817|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A5%D9%86%20%D8%A7%D9%84%D9%85%D9%83%D8%A7%D9%86%20%D9%85%D9%8F%D8%B2%D8%AF%D8%AD%D9%85%D8%8C%20%D8%AF%D8%B9%D9%86%D8%A7%20%D9%86%D8%B3%D8%AA%D9%82%D9%84%20%D8%A7%D9%84%D9%82%D8%B7%D8%A7%D8%B1%20%D8%A7%D9%84%D9%82%D8%A7%D8%AF%D9%85.)
^ar-Q0817-answer

**ar-Q0818** — إن المكان مُزدحم، دعنا نستقل القطار القادم.

It's crowded, so let's take the next train.

Expected form: **إن**

Why: Conditions. [[Arabic#^ar-Q0818|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A5%D9%86%20%D8%A7%D9%84%D9%85%D9%83%D8%A7%D9%86%20%D9%85%D9%8F%D8%B2%D8%AF%D8%AD%D9%85%D8%8C%20%D8%AF%D8%B9%D9%86%D8%A7%20%D9%86%D8%B3%D8%AA%D9%82%D9%84%20%D8%A7%D9%84%D9%82%D8%B7%D8%A7%D8%B1%20%D8%A7%D9%84%D9%82%D8%A7%D8%AF%D9%85.)
^ar-Q0818-answer

**ar-Q0819** — أنا لو كنت غنياً, كنت أود أن أعطيكِ مال.

If I were rich, I'd give you money.

Expected form: **لو**

Why: Conditions. [[Arabic#^ar-Q0819|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D9%86%D8%A7%20%D9%84%D9%88%20%D9%83%D9%86%D8%AA%20%D8%BA%D9%86%D9%8A%D8%A7%D9%8B%2C%20%D9%83%D9%86%D8%AA%20%D8%A3%D9%88%D8%AF%20%D8%A3%D9%86%20%D8%A3%D8%B9%D8%B7%D9%8A%D9%83%D9%90%20%D9%85%D8%A7%D9%84.)
^ar-Q0819-answer

**ar-Q0820** — أنا لو كنت غنياً, كنت أود أن أعطيكِ مال.

If I were rich, I'd give you money.

Why: Conditions. [[Arabic#^ar-Q0820|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D9%86%D8%A7%20%D9%84%D9%88%20%D9%83%D9%86%D8%AA%20%D8%BA%D9%86%D9%8A%D8%A7%D9%8B%2C%20%D9%83%D9%86%D8%AA%20%D8%A3%D9%88%D8%AF%20%D8%A3%D9%86%20%D8%A3%D8%B9%D8%B7%D9%8A%D9%83%D9%90%20%D9%85%D8%A7%D9%84.)
^ar-Q0820-answer

**ar-Q0821** — لو كان لدي ما يكفي من المال لاشتريت تلك الحقيبة.

If I had had enough money, I would have bought the bag.

Why: Conditions. [[Arabic#^ar-Q0821|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%88%20%D9%83%D8%A7%D9%86%20%D9%84%D8%AF%D9%8A%20%D9%85%D8%A7%20%D9%8A%D9%83%D9%81%D9%8A%20%D9%85%D9%86%20%D8%A7%D9%84%D9%85%D8%A7%D9%84%20%D9%84%D8%A7%D8%B4%D8%AA%D8%B1%D9%8A%D8%AA%20%D8%AA%D9%84%D9%83%20%D8%A7%D9%84%D8%AD%D9%82%D9%8A%D8%A8%D8%A9.)
^ar-Q0821-answer

**ar-Q0822** — لو كان لدي ما يكفي من المال لاشتريت تلك الحقيبة.

If I had had enough money, I would have bought the bag.

إذا commonly frames expected/real conditions, إن conditional patterns with specific MSA mood rules, and لو many counterfactuals. These are not freely interchangeable English if equivalents.

Why: Conditions. [[Arabic#^ar-Q0822|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%88%20%D9%83%D8%A7%D9%86%20%D9%84%D8%AF%D9%8A%20%D9%85%D8%A7%20%D9%8A%D9%83%D9%81%D9%8A%20%D9%85%D9%86%20%D8%A7%D9%84%D9%85%D8%A7%D9%84%20%D9%84%D8%A7%D8%B4%D8%AA%D8%B1%D9%8A%D8%AA%20%D8%AA%D9%84%D9%83%20%D8%A7%D9%84%D8%AD%D9%82%D9%8A%D8%A8%D8%A9.)
^ar-Q0822-answer

**ar-Q0823** — إذا لم يكن لديك أولاد بإمكانك دائماً أن تتبنى.

If you can't have children, you could always adopt.

Expected form: **إذا**

Why: Conditions. [[Arabic#^ar-Q0823|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A5%D8%B0%D8%A7%20%D9%84%D9%85%20%D9%8A%D9%83%D9%86%20%D9%84%D8%AF%D9%8A%D9%83%20%D8%A3%D9%88%D9%84%D8%A7%D8%AF%20%D8%A8%D8%A5%D9%85%D9%83%D8%A7%D9%86%D9%83%20%D8%AF%D8%A7%D8%A6%D9%85%D8%A7%D9%8B%20%D8%A3%D9%86%20%D8%AA%D8%AA%D8%A8%D9%86%D9%89.)
^ar-Q0823-answer

**ar-Q0824** — إذا لم يكن لديك أولاد بإمكانك دائماً أن تتبنى.

If you can't have children, you could always adopt.

Expected form: **إذا**

Why: Conditions. [[Arabic#^ar-Q0824|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A5%D8%B0%D8%A7%20%D9%84%D9%85%20%D9%8A%D9%83%D9%86%20%D9%84%D8%AF%D9%8A%D9%83%20%D8%A3%D9%88%D9%84%D8%A7%D8%AF%20%D8%A8%D8%A5%D9%85%D9%83%D8%A7%D9%86%D9%83%20%D8%AF%D8%A7%D8%A6%D9%85%D8%A7%D9%8B%20%D8%A3%D9%86%20%D8%AA%D8%AA%D8%A8%D9%86%D9%89.)
^ar-Q0824-answer

**ar-Q0825** — إن كان لديك ما تقول، فقُله.

If you've got something to say, just say it.

Expected form: **إن**

Why: Conditions. [[Arabic#^ar-Q0825|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A5%D9%86%20%D9%83%D8%A7%D9%86%20%D9%84%D8%AF%D9%8A%D9%83%20%D9%85%D8%A7%20%D8%AA%D9%82%D9%88%D9%84%D8%8C%20%D9%81%D9%82%D9%8F%D9%84%D9%87.)
^ar-Q0825-answer

**ar-Q0826** — إن كان لديك ما تقول، فقُله.

If you've got something to say, just say it.

Why: Conditions. [[Arabic#^ar-Q0826|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A5%D9%86%20%D9%83%D8%A7%D9%86%20%D9%84%D8%AF%D9%8A%D9%83%20%D9%85%D8%A7%20%D8%AA%D9%82%D9%88%D9%84%D8%8C%20%D9%81%D9%82%D9%8F%D9%84%D9%87.)
^ar-Q0826-answer

**ar-Q0827** — إذا أردت الحصول على دراجة جديدة، من الفضل لك أن تبدأ بتوفير النقود.

If you want a new bike, you'd better start saving up.

Why: Conditions. [[Arabic#^ar-Q0827|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A5%D8%B0%D8%A7%20%D8%A3%D8%B1%D8%AF%D8%AA%20%D8%A7%D9%84%D8%AD%D8%B5%D9%88%D9%84%20%D8%B9%D9%84%D9%89%20%D8%AF%D8%B1%D8%A7%D8%AC%D8%A9%20%D8%AC%D8%AF%D9%8A%D8%AF%D8%A9%D8%8C%20%D9%85%D9%86%20%D8%A7%D9%84%D9%81%D8%B6%D9%84%20%D9%84%D9%83%20%D8%A3%D9%86%20%D8%AA%D8%A8%D8%AF%D8%A3%20%D8%A8%D8%AA%D9%88%D9%81%D9%8A%D8%B1%20%D8%A7%D9%84%D9%86%D9%82%D9%88%D8%AF.)
^ar-Q0827-answer

**ar-Q0828** — إذا أردت الحصول على دراجة جديدة، من الفضل لك أن تبدأ بتوفير النقود.

If you want a new bike, you'd better start saving up.

إذا commonly frames expected/real conditions, إن conditional patterns with specific MSA mood rules, and لو many counterfactuals. These are not freely interchangeable English if equivalents.

Why: Conditions. [[Arabic#^ar-Q0828|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A5%D8%B0%D8%A7%20%D8%A3%D8%B1%D8%AF%D8%AA%20%D8%A7%D9%84%D8%AD%D8%B5%D9%88%D9%84%20%D8%B9%D9%84%D9%89%20%D8%AF%D8%B1%D8%A7%D8%AC%D8%A9%20%D8%AC%D8%AF%D9%8A%D8%AF%D8%A9%D8%8C%20%D9%85%D9%86%20%D8%A7%D9%84%D9%81%D8%B6%D9%84%20%D9%84%D9%83%20%D8%A3%D9%86%20%D8%AA%D8%A8%D8%AF%D8%A3%20%D8%A8%D8%AA%D9%88%D9%81%D9%8A%D8%B1%20%D8%A7%D9%84%D9%86%D9%82%D9%88%D8%AF.)
^ar-Q0828-answer

**ar-Q0829** — ”أنا أكرهكِ.“ ”طلّقني إذا.“

"I hate you." "Divorce me then."

Expected form: **إذا**

Why: Conditions. [[Arabic#^ar-Q0829|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%E2%80%9D%D8%A3%D9%86%D8%A7%20%D8%A3%D9%83%D8%B1%D9%87%D9%83%D9%90.%E2%80%9C%20%E2%80%9D%D8%B7%D9%84%D9%91%D9%82%D9%86%D9%8A%20%D8%A5%D8%B0%D8%A7.%E2%80%9C)
^ar-Q0829-answer

**ar-Q0830** — ”أنا أكرهكِ.“ ”طلّقني إذا.“

"I hate you." "Divorce me then."

Expected form: **إذا**

Why: Conditions. [[Arabic#^ar-Q0830|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%E2%80%9D%D8%A3%D9%86%D8%A7%20%D8%A3%D9%83%D8%B1%D9%87%D9%83%D9%90.%E2%80%9C%20%E2%80%9D%D8%B7%D9%84%D9%91%D9%82%D9%86%D9%8A%20%D8%A5%D8%B0%D8%A7.%E2%80%9C)
^ar-Q0830-answer

**ar-Q0831** — إنَّها تَعتَقِدُ أنَّهَا أعْلَمْ.

She thinks she knows best.

Expected form: **إن**

Why: Conditions. [[Arabic#^ar-Q0831|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A5%D9%86%D9%8E%D9%91%D9%87%D8%A7%20%D8%AA%D9%8E%D8%B9%D8%AA%D9%8E%D9%82%D9%90%D8%AF%D9%8F%20%D8%A3%D9%86%D9%8E%D9%91%D9%87%D9%8E%D8%A7%20%D8%A3%D8%B9%D9%92%D9%84%D9%8E%D9%85%D9%92.)
^ar-Q0831-answer

**ar-Q0832** — إنَّها تَعتَقِدُ أنَّهَا أعْلَمْ.

She thinks she knows best.

Why: Conditions. [[Arabic#^ar-Q0832|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A5%D9%86%D9%8E%D9%91%D9%87%D8%A7%20%D8%AA%D9%8E%D8%B9%D8%AA%D9%8E%D9%82%D9%90%D8%AF%D9%8F%20%D8%A3%D9%86%D9%8E%D9%91%D9%87%D9%8E%D8%A7%20%D8%A3%D8%B9%D9%92%D9%84%D9%8E%D9%85%D9%92.)
^ar-Q0832-answer

**ar-Q0833** — إنّ سامي يتفهّم انشغالات ليلى.

Sami understands Layla's concerns.

Why: Conditions. [[Arabic#^ar-Q0833|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A5%D9%86%D9%91%20%D8%B3%D8%A7%D9%85%D9%8A%20%D9%8A%D8%AA%D9%81%D9%87%D9%91%D9%85%20%D8%A7%D9%86%D8%B4%D8%BA%D8%A7%D9%84%D8%A7%D8%AA%20%D9%84%D9%8A%D9%84%D9%89.)
^ar-Q0833-answer

**ar-Q0834** — إنّ سامي يتفهّم انشغالات ليلى.

Sami understands Layla's concerns.

إذا commonly frames expected/real conditions, إن conditional patterns with specific MSA mood rules, and لو many counterfactuals. These are not freely interchangeable English if equivalents.

Why: Conditions. [[Arabic#^ar-Q0834|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A5%D9%86%D9%91%20%D8%B3%D8%A7%D9%85%D9%8A%20%D9%8A%D8%AA%D9%81%D9%87%D9%91%D9%85%20%D8%A7%D9%86%D8%B4%D8%BA%D8%A7%D9%84%D8%A7%D8%AA%20%D9%84%D9%8A%D9%84%D9%89.)
^ar-Q0834-answer

**ar-Q0835** — أتساءل فقط إن كان الأمر مشابهًا بالنسبة للآخرين.

I can only wonder if this is the same for everyone else.

Expected form: **إن**

Why: Conditions. [[Arabic#^ar-Q0835|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%AA%D8%B3%D8%A7%D8%A1%D9%84%20%D9%81%D9%82%D8%B7%20%D8%A5%D9%86%20%D9%83%D8%A7%D9%86%20%D8%A7%D9%84%D8%A3%D9%85%D8%B1%20%D9%85%D8%B4%D8%A7%D8%A8%D9%87%D9%8B%D8%A7%20%D8%A8%D8%A7%D9%84%D9%86%D8%B3%D8%A8%D8%A9%20%D9%84%D9%84%D8%A2%D8%AE%D8%B1%D9%8A%D9%86.)
^ar-Q0835-answer

**ar-Q0836** — أتساءل فقط إن كان الأمر مشابهًا بالنسبة للآخرين.

I can only wonder if this is the same for everyone else.

Expected form: **إن**

Why: Conditions. [[Arabic#^ar-Q0836|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%AA%D8%B3%D8%A7%D8%A1%D9%84%20%D9%81%D9%82%D8%B7%20%D8%A5%D9%86%20%D9%83%D8%A7%D9%86%20%D8%A7%D9%84%D8%A3%D9%85%D8%B1%20%D9%85%D8%B4%D8%A7%D8%A8%D9%87%D9%8B%D8%A7%20%D8%A8%D8%A7%D9%84%D9%86%D8%B3%D8%A8%D8%A9%20%D9%84%D9%84%D8%A2%D8%AE%D8%B1%D9%8A%D9%86.)
^ar-Q0836-answer

**ar-Q0837** — "من يقرع؟" "إنّه زوجي!"

"Who's knocking?" "It's my husband!"

Expected form: **إن**

Why: Conditions. [[Arabic#^ar-Q0837|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%22%D9%85%D9%86%20%D9%8A%D9%82%D8%B1%D8%B9%D8%9F%22%20%22%D8%A5%D9%86%D9%91%D9%87%20%D8%B2%D9%88%D8%AC%D9%8A%21%22)
^ar-Q0837-answer

**ar-Q0838** — "من يقرع؟" "إنّه زوجي!"

"Who's knocking?" "It's my husband!"

Why: Conditions. [[Arabic#^ar-Q0838|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%22%D9%85%D9%86%20%D9%8A%D9%82%D8%B1%D8%B9%D8%9F%22%20%22%D8%A5%D9%86%D9%91%D9%87%20%D8%B2%D9%88%D8%AC%D9%8A%21%22)
^ar-Q0838-answer

**ar-Q0839** — توم لا يستطيع أن يقرر في ما لو يشتري سيارة تيوتا أو فورد.

Tom can't decide whether to buy a Toyota or a Ford.

Why: Conditions. [[Arabic#^ar-Q0839|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%AA%D9%88%D9%85%20%D9%84%D8%A7%20%D9%8A%D8%B3%D8%AA%D8%B7%D9%8A%D8%B9%20%D8%A3%D9%86%20%D9%8A%D9%82%D8%B1%D8%B1%20%D9%81%D9%8A%20%D9%85%D8%A7%20%D9%84%D9%88%20%D9%8A%D8%B4%D8%AA%D8%B1%D9%8A%20%D8%B3%D9%8A%D8%A7%D8%B1%D8%A9%20%D8%AA%D9%8A%D9%88%D8%AA%D8%A7%20%D8%A3%D9%88%20%D9%81%D9%88%D8%B1%D8%AF.)
^ar-Q0839-answer

**ar-Q0840** — توم لا يستطيع أن يقرر في ما لو يشتري سيارة تيوتا أو فورد.

Tom can't decide whether to buy a Toyota or a Ford.

إذا commonly frames expected/real conditions, إن conditional patterns with specific MSA mood rules, and لو many counterfactuals. These are not freely interchangeable English if equivalents.

Why: Conditions. [[Arabic#^ar-Q0840|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%AA%D9%88%D9%85%20%D9%84%D8%A7%20%D9%8A%D8%B3%D8%AA%D8%B7%D9%8A%D8%B9%20%D8%A3%D9%86%20%D9%8A%D9%82%D8%B1%D8%B1%20%D9%81%D9%8A%20%D9%85%D8%A7%20%D9%84%D9%88%20%D9%8A%D8%B4%D8%AA%D8%B1%D9%8A%20%D8%B3%D9%8A%D8%A7%D8%B1%D8%A9%20%D8%AA%D9%8A%D9%88%D8%AA%D8%A7%20%D8%A3%D9%88%20%D9%81%D9%88%D8%B1%D8%AF.)
^ar-Q0840-answer

**ar-Q0841** — ماذا لو فشِل؟

What if he fails?

Expected form: **لو**

Why: Conditions. [[Arabic#^ar-Q0841|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D8%A7%D8%B0%D8%A7%20%D9%84%D9%88%20%D9%81%D8%B4%D9%90%D9%84%D8%9F)
^ar-Q0841-answer

**ar-Q0842** — ماذا لو فشِل؟

What if he fails?

Expected form: **لو**

Why: Conditions. [[Arabic#^ar-Q0842|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D8%A7%D8%B0%D8%A7%20%D9%84%D9%88%20%D9%81%D8%B4%D9%90%D9%84%D8%9F)
^ar-Q0842-answer

**ar-Q0843** — في فرنسا إما يقولون تليفون أو يقولون محمول ، لكن - الكلمة - الأخيرة غامضة ، لأن من الصعب عادة تحديد ما إذا كان المقصود تليفونا أو حاسبا أو جهازا محمولا آخر.

In France they say either "(téléphone) mobile" or "portable", but the latter is ambiguous, because you often cannot tell whether it refers to a telephone, a computer, or another portable device.

Expected form: **إذا**

Why: Conditions. [[Arabic#^ar-Q0843|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%81%D9%8A%20%D9%81%D8%B1%D9%86%D8%B3%D8%A7%20%D8%A5%D9%85%D8%A7%20%D9%8A%D9%82%D9%88%D9%84%D9%88%D9%86%20%D8%AA%D9%84%D9%8A%D9%81%D9%88%D9%86%20%D8%A3%D9%88%20%D9%8A%D9%82%D9%88%D9%84%D9%88%D9%86%20%D9%85%D8%AD%D9%85%D9%88%D9%84%20%D8%8C%20%D9%84%D9%83%D9%86%20-%20%D8%A7%D9%84%D9%83%D9%84%D9%85%D8%A9%20-%20%D8%A7%D9%84%D8%A3%D8%AE%D9%8A%D8%B1%D8%A9%20%D8%BA%D8%A7%D9%85%D8%B6%D8%A9%20%D8%8C%20%D9%84%D8%A3%D9%86%20%D9%85%D9%86%20%D8%A7%D9%84%D8%B5%D8%B9%D8%A8%20%D8%B9%D8%A7%D8%AF%D8%A9%20%D8%AA%D8%AD%D8%AF%D9%8A%D8%AF%20%D9%85%D8%A7%20%D8%A5%D8%B0%D8%A7%20%D9%83%D8%A7%D9%86%20%D8%A7%D9%84%D9%85%D9%82%D8%B5%D9%88%D8%AF%20%D8%AA%D9%84%D9%8A%D9%81%D9%88%D9%86%D8%A7%20%D8%A3%D9%88%20%D8%AD%D8%A7%D8%B3%D8%A8%D8%A7%20%D8%A3%D9%88%20%D8%AC%D9%87%D8%A7%D8%B2%D8%A7%20%D9%85%D8%AD%D9%85%D9%88%D9%84%D8%A7%20%D8%A2%D8%AE%D8%B1.)
^ar-Q0843-answer

**ar-Q0844** — في فرنسا إما يقولون تليفون أو يقولون محمول ، لكن - الكلمة - الأخيرة غامضة ، لأن من الصعب عادة تحديد ما إذا كان المقصود تليفونا أو حاسبا أو جهازا محمولا آخر.

In France they say either "(téléphone) mobile" or "portable", but the latter is ambiguous, because you often cannot tell whether it refers to a telephone, a computer, or another portable device.

Why: Conditions. [[Arabic#^ar-Q0844|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%81%D9%8A%20%D9%81%D8%B1%D9%86%D8%B3%D8%A7%20%D8%A5%D9%85%D8%A7%20%D9%8A%D9%82%D9%88%D9%84%D9%88%D9%86%20%D8%AA%D9%84%D9%8A%D9%81%D9%88%D9%86%20%D8%A3%D9%88%20%D9%8A%D9%82%D9%88%D9%84%D9%88%D9%86%20%D9%85%D8%AD%D9%85%D9%88%D9%84%20%D8%8C%20%D9%84%D9%83%D9%86%20-%20%D8%A7%D9%84%D9%83%D9%84%D9%85%D8%A9%20-%20%D8%A7%D9%84%D8%A3%D8%AE%D9%8A%D8%B1%D8%A9%20%D8%BA%D8%A7%D9%85%D8%B6%D8%A9%20%D8%8C%20%D9%84%D8%A3%D9%86%20%D9%85%D9%86%20%D8%A7%D9%84%D8%B5%D8%B9%D8%A8%20%D8%B9%D8%A7%D8%AF%D8%A9%20%D8%AA%D8%AD%D8%AF%D9%8A%D8%AF%20%D9%85%D8%A7%20%D8%A5%D8%B0%D8%A7%20%D9%83%D8%A7%D9%86%20%D8%A7%D9%84%D9%85%D9%82%D8%B5%D9%88%D8%AF%20%D8%AA%D9%84%D9%8A%D9%81%D9%88%D9%86%D8%A7%20%D8%A3%D9%88%20%D8%AD%D8%A7%D8%B3%D8%A8%D8%A7%20%D8%A3%D9%88%20%D8%AC%D9%87%D8%A7%D8%B2%D8%A7%20%D9%85%D8%AD%D9%85%D9%88%D9%84%D8%A7%20%D8%A2%D8%AE%D8%B1.)
^ar-Q0844-answer

**ar-Q0845** — إن ذلك مؤلم ، توقف.

It's so painful. Stop it!

Why: Conditions. [[Arabic#^ar-Q0845|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A5%D9%86%20%D8%B0%D9%84%D9%83%20%D9%85%D8%A4%D9%84%D9%85%20%D8%8C%20%D8%AA%D9%88%D9%82%D9%81.)
^ar-Q0845-answer

**ar-Q0846** — إن ذلك مؤلم ، توقف.

It's so painful. Stop it!

إذا commonly frames expected/real conditions, إن conditional patterns with specific MSA mood rules, and لو many counterfactuals. These are not freely interchangeable English if equivalents.

Why: Conditions. [[Arabic#^ar-Q0846|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A5%D9%86%20%D8%B0%D9%84%D9%83%20%D9%85%D8%A4%D9%84%D9%85%20%D8%8C%20%D8%AA%D9%88%D9%82%D9%81.)
^ar-Q0846-answer

**ar-Q0847** — لو أردت أن أخيفك لحكيت لك ما حلمت به منذ بضعة أسابيع.

If I wanted to scare you, I would have told you about what I dreamt about a few weeks ago.

Expected form: **لو**

Why: Conditions. [[Arabic#^ar-Q0847|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%88%20%D8%A3%D8%B1%D8%AF%D8%AA%20%D8%A3%D9%86%20%D8%A3%D8%AE%D9%8A%D9%81%D9%83%20%D9%84%D8%AD%D9%83%D9%8A%D8%AA%20%D9%84%D9%83%20%D9%85%D8%A7%20%D8%AD%D9%84%D9%85%D8%AA%20%D8%A8%D9%87%20%D9%85%D9%86%D8%B0%20%D8%A8%D8%B6%D8%B9%D8%A9%20%D8%A3%D8%B3%D8%A7%D8%A8%D9%8A%D8%B9.)
^ar-Q0847-answer

**ar-Q0848** — لو أردت أن أخيفك لحكيت لك ما حلمت به منذ بضعة أسابيع.

If I wanted to scare you, I would have told you about what I dreamt about a few weeks ago.

Expected form: **لو**

Why: Conditions. [[Arabic#^ar-Q0848|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%88%20%D8%A3%D8%B1%D8%AF%D8%AA%20%D8%A3%D9%86%20%D8%A3%D8%AE%D9%8A%D9%81%D9%83%20%D9%84%D8%AD%D9%83%D9%8A%D8%AA%20%D9%84%D9%83%20%D9%85%D8%A7%20%D8%AD%D9%84%D9%85%D8%AA%20%D8%A8%D9%87%20%D9%85%D9%86%D8%B0%20%D8%A8%D8%B6%D8%B9%D8%A9%20%D8%A3%D8%B3%D8%A7%D8%A8%D9%8A%D8%B9.)
^ar-Q0848-answer

**ar-Q0849** — توم يريد أن يعرف م إذا كانت تؤلِم.

Tom wants to know if it hurts.

Expected form: **إذا**

Why: Conditions. [[Arabic#^ar-Q0849|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%AA%D9%88%D9%85%20%D9%8A%D8%B1%D9%8A%D8%AF%20%D8%A3%D9%86%20%D9%8A%D8%B9%D8%B1%D9%81%20%D9%85%20%D8%A5%D8%B0%D8%A7%20%D9%83%D8%A7%D9%86%D8%AA%20%D8%AA%D8%A4%D9%84%D9%90%D9%85.)
^ar-Q0849-answer

**ar-Q0850** — توم يريد أن يعرف م إذا كانت تؤلِم.

Tom wants to know if it hurts.

Why: Conditions. [[Arabic#^ar-Q0850|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%AA%D9%88%D9%85%20%D9%8A%D8%B1%D9%8A%D8%AF%20%D8%A3%D9%86%20%D9%8A%D8%B9%D8%B1%D9%81%20%D9%85%20%D8%A5%D8%B0%D8%A7%20%D9%83%D8%A7%D9%86%D8%AA%20%D8%AA%D8%A4%D9%84%D9%90%D9%85.)
^ar-Q0850-answer


### Answers 851–900

**ar-Q0851** — لكن لديك أطفال.

But you have kids.

Why: Cause and concession. [[Arabic#^ar-Q0851|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%83%D9%86%20%D9%84%D8%AF%D9%8A%D9%83%20%D8%A3%D8%B7%D9%81%D8%A7%D9%84.)
^ar-Q0851-answer

**ar-Q0852** — لكن لديك أطفال.

But you have kids.

لأن supplies a reason; لكن introduces contrast; لذلك a consequence. Attached pronouns and nominal clauses affect the surrounding grammar. Distinguish argument relationships carefully.

Why: Cause and concession. [[Arabic#^ar-Q0852|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%83%D9%86%20%D9%84%D8%AF%D9%8A%D9%83%20%D8%A3%D8%B7%D9%81%D8%A7%D9%84.)
^ar-Q0852-answer

**ar-Q0853** — كان سامي بحاجة لذلك المال.

Sami needed the money.

Expected form: **لذلك**

Why: Cause and concession. [[Arabic#^ar-Q0853|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D8%A7%D9%86%20%D8%B3%D8%A7%D9%85%D9%8A%20%D8%A8%D8%AD%D8%A7%D8%AC%D8%A9%20%D9%84%D8%B0%D9%84%D9%83%20%D8%A7%D9%84%D9%85%D8%A7%D9%84.)
^ar-Q0853-answer

**ar-Q0854** — كان سامي بحاجة لذلك المال.

Sami needed the money.

Expected form: **لذلك**

Why: Cause and concession. [[Arabic#^ar-Q0854|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D8%A7%D9%86%20%D8%B3%D8%A7%D9%85%D9%8A%20%D8%A8%D8%AD%D8%A7%D8%AC%D8%A9%20%D9%84%D8%B0%D9%84%D9%83%20%D8%A7%D9%84%D9%85%D8%A7%D9%84.)
^ar-Q0854-answer

**ar-Q0855** — أنا تلميذ، ولكن هو ليس بواحد.

I am a student, but he isn't.

Expected form: **ولكن**

Why: Cause and concession. [[Arabic#^ar-Q0855|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D9%86%D8%A7%20%D8%AA%D9%84%D9%85%D9%8A%D8%B0%D8%8C%20%D9%88%D9%84%D9%83%D9%86%20%D9%87%D9%88%20%D9%84%D9%8A%D8%B3%20%D8%A8%D9%88%D8%A7%D8%AD%D8%AF.)
^ar-Q0855-answer

**ar-Q0856** — أنا تلميذ، ولكن هو ليس بواحد.

I am a student, but he isn't.

Why: Cause and concession. [[Arabic#^ar-Q0856|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D9%86%D8%A7%20%D8%AA%D9%84%D9%85%D9%8A%D8%B0%D8%8C%20%D9%88%D9%84%D9%83%D9%86%20%D9%87%D9%88%20%D9%84%D9%8A%D8%B3%20%D8%A8%D9%88%D8%A7%D8%AD%D8%AF.)
^ar-Q0856-answer

**ar-Q0857** — إنهُ ظريف, ولكن غبي.

He's cute but stupid.

Why: Cause and concession. [[Arabic#^ar-Q0857|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A5%D9%86%D9%87%D9%8F%20%D8%B8%D8%B1%D9%8A%D9%81%2C%20%D9%88%D9%84%D9%83%D9%86%20%D8%BA%D8%A8%D9%8A.)
^ar-Q0857-answer

**ar-Q0858** — إنهُ ظريف, ولكن غبي.

He's cute but stupid.

لأن supplies a reason; لكن introduces contrast; لذلك a consequence. Attached pronouns and nominal clauses affect the surrounding grammar. Distinguish argument relationships carefully.

Why: Cause and concession. [[Arabic#^ar-Q0858|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A5%D9%86%D9%87%D9%8F%20%D8%B8%D8%B1%D9%8A%D9%81%2C%20%D9%88%D9%84%D9%83%D9%86%20%D8%BA%D8%A8%D9%8A.)
^ar-Q0858-answer

**ar-Q0859** — ليس "هو إبني" ولكن " أنا والده".

Not "he is my son" but " I am his father".

Expected form: **ولكن**

Why: Cause and concession. [[Arabic#^ar-Q0859|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%8A%D8%B3%20%22%D9%87%D9%88%20%D8%A5%D8%A8%D9%86%D9%8A%22%20%D9%88%D9%84%D9%83%D9%86%20%22%20%D8%A3%D9%86%D8%A7%20%D9%88%D8%A7%D9%84%D8%AF%D9%87%22.)
^ar-Q0859-answer

**ar-Q0860** — ليس "هو إبني" ولكن " أنا والده".

Not "he is my son" but " I am his father".

Expected form: **ولكن**

Why: Cause and concession. [[Arabic#^ar-Q0860|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%8A%D8%B3%20%22%D9%87%D9%88%20%D8%A5%D8%A8%D9%86%D9%8A%22%20%D9%88%D9%84%D9%83%D9%86%20%22%20%D8%A3%D9%86%D8%A7%20%D9%88%D8%A7%D9%84%D8%AF%D9%87%22.)
^ar-Q0860-answer

**ar-Q0861** — أنا حزين لأن الجميع غادر و تركني لوحدي.

I'm sad because everyone went away and left me alone.

Expected form: **لأن**

Why: Cause and concession. [[Arabic#^ar-Q0861|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D9%86%D8%A7%20%D8%AD%D8%B2%D9%8A%D9%86%20%D9%84%D8%A3%D9%86%20%D8%A7%D9%84%D8%AC%D9%85%D9%8A%D8%B9%20%D8%BA%D8%A7%D8%AF%D8%B1%20%D9%88%20%D8%AA%D8%B1%D9%83%D9%86%D9%8A%20%D9%84%D9%88%D8%AD%D8%AF%D9%8A.)
^ar-Q0861-answer

**ar-Q0862** — أنا حزين لأن الجميع غادر و تركني لوحدي.

I'm sad because everyone went away and left me alone.

Why: Cause and concession. [[Arabic#^ar-Q0862|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D9%86%D8%A7%20%D8%AD%D8%B2%D9%8A%D9%86%20%D9%84%D8%A3%D9%86%20%D8%A7%D9%84%D8%AC%D9%85%D9%8A%D8%B9%20%D8%BA%D8%A7%D8%AF%D8%B1%20%D9%88%20%D8%AA%D8%B1%D9%83%D9%86%D9%8A%20%D9%84%D9%88%D8%AD%D8%AF%D9%8A.)
^ar-Q0862-answer

**ar-Q0863** — المعذرة لكنّي لا أستطيع سماعك جيّداً.

Sorry, but I can't hear you very well.

Why: Cause and concession. [[Arabic#^ar-Q0863|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A7%D9%84%D9%85%D8%B9%D8%B0%D8%B1%D8%A9%20%D9%84%D9%83%D9%86%D9%91%D9%8A%20%D9%84%D8%A7%20%D8%A3%D8%B3%D8%AA%D8%B7%D9%8A%D8%B9%20%D8%B3%D9%85%D8%A7%D8%B9%D9%83%20%D8%AC%D9%8A%D9%91%D8%AF%D8%A7%D9%8B.)
^ar-Q0863-answer

**ar-Q0864** — المعذرة لكنّي لا أستطيع سماعك جيّداً.

Sorry, but I can't hear you very well.

لأن supplies a reason; لكن introduces contrast; لذلك a consequence. Attached pronouns and nominal clauses affect the surrounding grammar. Distinguish argument relationships carefully.

Why: Cause and concession. [[Arabic#^ar-Q0864|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A7%D9%84%D9%85%D8%B9%D8%B0%D8%B1%D8%A9%20%D9%84%D9%83%D9%86%D9%91%D9%8A%20%D9%84%D8%A7%20%D8%A3%D8%B3%D8%AA%D8%B7%D9%8A%D8%B9%20%D8%B3%D9%85%D8%A7%D8%B9%D9%83%20%D8%AC%D9%8A%D9%91%D8%AF%D8%A7%D9%8B.)
^ar-Q0864-answer

**ar-Q0865** — بكيت لأن الجميع غيري بكى.

I just cried because all the others did.

Expected form: **لأن**

Why: Cause and concession. [[Arabic#^ar-Q0865|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A8%D9%83%D9%8A%D8%AA%20%D9%84%D8%A3%D9%86%20%D8%A7%D9%84%D8%AC%D9%85%D9%8A%D8%B9%20%D8%BA%D9%8A%D8%B1%D9%8A%20%D8%A8%D9%83%D9%89.)
^ar-Q0865-answer

**ar-Q0866** — بكيت لأن الجميع غيري بكى.

I just cried because all the others did.

Expected form: **لأن**

Why: Cause and concession. [[Arabic#^ar-Q0866|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A8%D9%83%D9%8A%D8%AA%20%D9%84%D8%A3%D9%86%20%D8%A7%D9%84%D8%AC%D9%85%D9%8A%D8%B9%20%D8%BA%D9%8A%D8%B1%D9%8A%20%D8%A8%D9%83%D9%89.)
^ar-Q0866-answer

**ar-Q0867** — كانا سامي و ليلى أصدقاءا لذلك الطّفل.

Sami and Layla were friends with that kid.

Expected form: **لذلك**

Why: Cause and concession. [[Arabic#^ar-Q0867|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D8%A7%D9%86%D8%A7%20%D8%B3%D8%A7%D9%85%D9%8A%20%D9%88%20%D9%84%D9%8A%D9%84%D9%89%20%D8%A3%D8%B5%D8%AF%D9%82%D8%A7%D8%A1%D8%A7%20%D9%84%D8%B0%D9%84%D9%83%20%D8%A7%D9%84%D8%B7%D9%91%D9%81%D9%84.)
^ar-Q0867-answer

**ar-Q0868** — كانا سامي و ليلى أصدقاءا لذلك الطّفل.

Sami and Layla were friends with that kid.

Why: Cause and concession. [[Arabic#^ar-Q0868|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D8%A7%D9%86%D8%A7%20%D8%B3%D8%A7%D9%85%D9%8A%20%D9%88%20%D9%84%D9%8A%D9%84%D9%89%20%D8%A3%D8%B5%D8%AF%D9%82%D8%A7%D8%A1%D8%A7%20%D9%84%D8%B0%D9%84%D9%83%20%D8%A7%D9%84%D8%B7%D9%91%D9%81%D9%84.)
^ar-Q0868-answer

**ar-Q0869** — لا أعرف أحد في هذه المنطقة لذلك عليك المحاولة بتشكيل صدقات.

I don't know anybody in this area, So you have to try making friends.

Why: Cause and concession. [[Arabic#^ar-Q0869|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D8%A7%20%D8%A3%D8%B9%D8%B1%D9%81%20%D8%A3%D8%AD%D8%AF%20%D9%81%D9%8A%20%D9%87%D8%B0%D9%87%20%D8%A7%D9%84%D9%85%D9%86%D8%B7%D9%82%D8%A9%20%D9%84%D8%B0%D9%84%D9%83%20%D8%B9%D9%84%D9%8A%D9%83%20%D8%A7%D9%84%D9%85%D8%AD%D8%A7%D9%88%D9%84%D8%A9%20%D8%A8%D8%AA%D8%B4%D9%83%D9%8A%D9%84%20%D8%B5%D8%AF%D9%82%D8%A7%D8%AA.)
^ar-Q0869-answer

**ar-Q0870** — لا أعرف أحد في هذه المنطقة لذلك عليك المحاولة بتشكيل صدقات.

I don't know anybody in this area, So you have to try making friends.

لأن supplies a reason; لكن introduces contrast; لذلك a consequence. Attached pronouns and nominal clauses affect the surrounding grammar. Distinguish argument relationships carefully.

Why: Cause and concession. [[Arabic#^ar-Q0870|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D8%A7%20%D8%A3%D8%B9%D8%B1%D9%81%20%D8%A3%D8%AD%D8%AF%20%D9%81%D9%8A%20%D9%87%D8%B0%D9%87%20%D8%A7%D9%84%D9%85%D9%86%D8%B7%D9%82%D8%A9%20%D9%84%D8%B0%D9%84%D9%83%20%D8%B9%D9%84%D9%8A%D9%83%20%D8%A7%D9%84%D9%85%D8%AD%D8%A7%D9%88%D9%84%D8%A9%20%D8%A8%D8%AA%D8%B4%D9%83%D9%8A%D9%84%20%D8%B5%D8%AF%D9%82%D8%A7%D8%AA.)
^ar-Q0870-answer

**ar-Q0871** — المسلمون لا يأكلون الخنزير لأنّه لحم فيه خطر.

Muslims don't eat pork because it's dangerous meat.

Expected form: **لأن**

Why: Cause and concession. [[Arabic#^ar-Q0871|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A7%D9%84%D9%85%D8%B3%D9%84%D9%85%D9%88%D9%86%20%D9%84%D8%A7%20%D9%8A%D8%A3%D9%83%D9%84%D9%88%D9%86%20%D8%A7%D9%84%D8%AE%D9%86%D8%B2%D9%8A%D8%B1%20%D9%84%D8%A3%D9%86%D9%91%D9%87%20%D9%84%D8%AD%D9%85%20%D9%81%D9%8A%D9%87%20%D8%AE%D8%B7%D8%B1.)
^ar-Q0871-answer

**ar-Q0872** — المسلمون لا يأكلون الخنزير لأنّه لحم فيه خطر.

Muslims don't eat pork because it's dangerous meat.

Expected form: **لأن**

Why: Cause and concession. [[Arabic#^ar-Q0872|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A7%D9%84%D9%85%D8%B3%D9%84%D9%85%D9%88%D9%86%20%D9%84%D8%A7%20%D9%8A%D8%A3%D9%83%D9%84%D9%88%D9%86%20%D8%A7%D9%84%D8%AE%D9%86%D8%B2%D9%8A%D8%B1%20%D9%84%D8%A3%D9%86%D9%91%D9%87%20%D9%84%D8%AD%D9%85%20%D9%81%D9%8A%D9%87%20%D8%AE%D8%B7%D8%B1.)
^ar-Q0872-answer

**ar-Q0873** — لذلك أنا خرجت

That's why I quit.

Expected form: **لذلك**

Why: Cause and concession. [[Arabic#^ar-Q0873|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D8%B0%D9%84%D9%83%20%D8%A3%D9%86%D8%A7%20%D8%AE%D8%B1%D8%AC%D8%AA)
^ar-Q0873-answer

**ar-Q0874** — لذلك أنا خرجت

That's why I quit.

Why: Cause and concession. [[Arabic#^ar-Q0874|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D8%B0%D9%84%D9%83%20%D8%A3%D9%86%D8%A7%20%D8%AE%D8%B1%D8%AC%D8%AA)
^ar-Q0874-answer

**ar-Q0875** — لكن عندما فتحت حنفية الحمام، خرج سائل أسود مليء بالفقاعات.

But when I tried to turn the shower faucet, this black bubbly liquid came out.

Why: Cause and concession. [[Arabic#^ar-Q0875|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%83%D9%86%20%D8%B9%D9%86%D8%AF%D9%85%D8%A7%20%D9%81%D8%AA%D8%AD%D8%AA%20%D8%AD%D9%86%D9%81%D9%8A%D8%A9%20%D8%A7%D9%84%D8%AD%D9%85%D8%A7%D9%85%D8%8C%20%D8%AE%D8%B1%D8%AC%20%D8%B3%D8%A7%D8%A6%D9%84%20%D8%A3%D8%B3%D9%88%D8%AF%20%D9%85%D9%84%D9%8A%D8%A1%20%D8%A8%D8%A7%D9%84%D9%81%D9%82%D8%A7%D8%B9%D8%A7%D8%AA.)
^ar-Q0875-answer

**ar-Q0876** — لكن عندما فتحت حنفية الحمام، خرج سائل أسود مليء بالفقاعات.

But when I tried to turn the shower faucet, this black bubbly liquid came out.

لأن supplies a reason; لكن introduces contrast; لذلك a consequence. Attached pronouns and nominal clauses affect the surrounding grammar. Distinguish argument relationships carefully.

Why: Cause and concession. [[Arabic#^ar-Q0876|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%83%D9%86%20%D8%B9%D9%86%D8%AF%D9%85%D8%A7%20%D9%81%D8%AA%D8%AD%D8%AA%20%D8%AD%D9%86%D9%81%D9%8A%D8%A9%20%D8%A7%D9%84%D8%AD%D9%85%D8%A7%D9%85%D8%8C%20%D8%AE%D8%B1%D8%AC%20%D8%B3%D8%A7%D8%A6%D9%84%20%D8%A3%D8%B3%D9%88%D8%AF%20%D9%85%D9%84%D9%8A%D8%A1%20%D8%A8%D8%A7%D9%84%D9%81%D9%82%D8%A7%D8%B9%D8%A7%D8%AA.)
^ar-Q0876-answer

**ar-Q0877** — يذهب الرجال وياتون لكن الارض تبقى ثابتة

Men go and come, but earth abides.

Expected form: **لكن**

Why: Cause and concession. [[Arabic#^ar-Q0877|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%8A%D8%B0%D9%87%D8%A8%20%D8%A7%D9%84%D8%B1%D8%AC%D8%A7%D9%84%20%D9%88%D9%8A%D8%A7%D8%AA%D9%88%D9%86%20%D9%84%D9%83%D9%86%20%D8%A7%D9%84%D8%A7%D8%B1%D8%B6%20%D8%AA%D8%A8%D9%82%D9%89%20%D8%AB%D8%A7%D8%A8%D8%AA%D8%A9)
^ar-Q0877-answer

**ar-Q0878** — يذهب الرجال وياتون لكن الارض تبقى ثابتة

Men go and come, but earth abides.

Expected form: **لكن**

Why: Cause and concession. [[Arabic#^ar-Q0878|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%8A%D8%B0%D9%87%D8%A8%20%D8%A7%D9%84%D8%B1%D8%AC%D8%A7%D9%84%20%D9%88%D9%8A%D8%A7%D8%AA%D9%88%D9%86%20%D9%84%D9%83%D9%86%20%D8%A7%D9%84%D8%A7%D8%B1%D8%B6%20%D8%AA%D8%A8%D9%82%D9%89%20%D8%AB%D8%A7%D8%A8%D8%AA%D8%A9)
^ar-Q0878-answer

**ar-Q0879** — يمكننا أن نعرِف ما قد حصل في الماضي، ولكن لا يمكننا تغييره. ويمكننا أن نغير المستقبل، لكن لا يمكننا أن نعرف ما سيحصل فيه.

The past can only be known, not changed. The future can only be changed, not known.

Expected form: **ولكن**

Why: Cause and concession. [[Arabic#^ar-Q0879|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%8A%D9%85%D9%83%D9%86%D9%86%D8%A7%20%D8%A3%D9%86%20%D9%86%D8%B9%D8%B1%D9%90%D9%81%20%D9%85%D8%A7%20%D9%82%D8%AF%20%D8%AD%D8%B5%D9%84%20%D9%81%D9%8A%20%D8%A7%D9%84%D9%85%D8%A7%D8%B6%D9%8A%D8%8C%20%D9%88%D9%84%D9%83%D9%86%20%D9%84%D8%A7%20%D9%8A%D9%85%D9%83%D9%86%D9%86%D8%A7%20%D8%AA%D8%BA%D9%8A%D9%8A%D8%B1%D9%87.%20%D9%88%D9%8A%D9%85%D9%83%D9%86%D9%86%D8%A7%20%D8%A3%D9%86%20%D9%86%D8%BA%D9%8A%D8%B1%20%D8%A7%D9%84%D9%85%D8%B3%D8%AA%D9%82%D8%A8%D9%84%D8%8C%20%D9%84%D9%83%D9%86%20%D9%84%D8%A7%20%D9%8A%D9%85%D9%83%D9%86%D9%86%D8%A7%20%D8%A3%D9%86%20%D9%86%D8%B9%D8%B1%D9%81%20%D9%85%D8%A7%20%D8%B3%D9%8A%D8%AD%D8%B5%D9%84%20%D9%81%D9%8A%D9%87.)
^ar-Q0879-answer

**ar-Q0880** — يمكننا أن نعرِف ما قد حصل في الماضي، ولكن لا يمكننا تغييره. ويمكننا أن نغير المستقبل، لكن لا يمكننا أن نعرف ما سيحصل فيه.

The past can only be known, not changed. The future can only be changed, not known.

Why: Cause and concession. [[Arabic#^ar-Q0880|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%8A%D9%85%D9%83%D9%86%D9%86%D8%A7%20%D8%A3%D9%86%20%D9%86%D8%B9%D8%B1%D9%90%D9%81%20%D9%85%D8%A7%20%D9%82%D8%AF%20%D8%AD%D8%B5%D9%84%20%D9%81%D9%8A%20%D8%A7%D9%84%D9%85%D8%A7%D8%B6%D9%8A%D8%8C%20%D9%88%D9%84%D9%83%D9%86%20%D9%84%D8%A7%20%D9%8A%D9%85%D9%83%D9%86%D9%86%D8%A7%20%D8%AA%D8%BA%D9%8A%D9%8A%D8%B1%D9%87.%20%D9%88%D9%8A%D9%85%D9%83%D9%86%D9%86%D8%A7%20%D8%A3%D9%86%20%D9%86%D8%BA%D9%8A%D8%B1%20%D8%A7%D9%84%D9%85%D8%B3%D8%AA%D9%82%D8%A8%D9%84%D8%8C%20%D9%84%D9%83%D9%86%20%D9%84%D8%A7%20%D9%8A%D9%85%D9%83%D9%86%D9%86%D8%A7%20%D8%A3%D9%86%20%D9%86%D8%B9%D8%B1%D9%81%20%D9%85%D8%A7%20%D8%B3%D9%8A%D8%AD%D8%B5%D9%84%20%D9%81%D9%8A%D9%87.)
^ar-Q0880-answer

**ar-Q0881** — هي فقيرة، لكن سعيدة.

She is poor, but happy.

Why: Cause and concession. [[Arabic#^ar-Q0881|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D9%8A%20%D9%81%D9%82%D9%8A%D8%B1%D8%A9%D8%8C%20%D9%84%D9%83%D9%86%20%D8%B3%D8%B9%D9%8A%D8%AF%D8%A9.)
^ar-Q0881-answer

**ar-Q0882** — هي فقيرة، لكن سعيدة.

She is poor, but happy.

لأن supplies a reason; لكن introduces contrast; لذلك a consequence. Attached pronouns and nominal clauses affect the surrounding grammar. Distinguish argument relationships carefully.

Why: Cause and concession. [[Arabic#^ar-Q0882|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D9%8A%20%D9%81%D9%82%D9%8A%D8%B1%D8%A9%D8%8C%20%D9%84%D9%83%D9%86%20%D8%B3%D8%B9%D9%8A%D8%AF%D8%A9.)
^ar-Q0882-answer

**ar-Q0883** — أحب تقدير الكمية التي أحتاجها من المكونات، غالبًا لأنني لا أرغب بغسل أكواب القياس مرة تلو الأخرى.

I like to eyeball my ingredients, mostly because I don't feel like washing my measuring cups over and over.

Expected form: **لأنني**

Why: Cause and concession. [[Arabic#^ar-Q0883|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%AD%D8%A8%20%D8%AA%D9%82%D8%AF%D9%8A%D8%B1%20%D8%A7%D9%84%D9%83%D9%85%D9%8A%D8%A9%20%D8%A7%D9%84%D8%AA%D9%8A%20%D8%A3%D8%AD%D8%AA%D8%A7%D8%AC%D9%87%D8%A7%20%D9%85%D9%86%20%D8%A7%D9%84%D9%85%D9%83%D9%88%D9%86%D8%A7%D8%AA%D8%8C%20%D8%BA%D8%A7%D9%84%D8%A8%D9%8B%D8%A7%20%D9%84%D8%A3%D9%86%D9%86%D9%8A%20%D9%84%D8%A7%20%D8%A3%D8%B1%D8%BA%D8%A8%20%D8%A8%D8%BA%D8%B3%D9%84%20%D8%A3%D9%83%D9%88%D8%A7%D8%A8%20%D8%A7%D9%84%D9%82%D9%8A%D8%A7%D8%B3%20%D9%85%D8%B1%D8%A9%20%D8%AA%D9%84%D9%88%20%D8%A7%D9%84%D8%A3%D8%AE%D8%B1%D9%89.)
^ar-Q0883-answer

**ar-Q0884** — أحب تقدير الكمية التي أحتاجها من المكونات، غالبًا لأنني لا أرغب بغسل أكواب القياس مرة تلو الأخرى.

I like to eyeball my ingredients, mostly because I don't feel like washing my measuring cups over and over.

Expected form: **لأنني**

Why: Cause and concession. [[Arabic#^ar-Q0884|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%AD%D8%A8%20%D8%AA%D9%82%D8%AF%D9%8A%D8%B1%20%D8%A7%D9%84%D9%83%D9%85%D9%8A%D8%A9%20%D8%A7%D9%84%D8%AA%D9%8A%20%D8%A3%D8%AD%D8%AA%D8%A7%D8%AC%D9%87%D8%A7%20%D9%85%D9%86%20%D8%A7%D9%84%D9%85%D9%83%D9%88%D9%86%D8%A7%D8%AA%D8%8C%20%D8%BA%D8%A7%D9%84%D8%A8%D9%8B%D8%A7%20%D9%84%D8%A3%D9%86%D9%86%D9%8A%20%D9%84%D8%A7%20%D8%A3%D8%B1%D8%BA%D8%A8%20%D8%A8%D8%BA%D8%B3%D9%84%20%D8%A3%D9%83%D9%88%D8%A7%D8%A8%20%D8%A7%D9%84%D9%82%D9%8A%D8%A7%D8%B3%20%D9%85%D8%B1%D8%A9%20%D8%AA%D9%84%D9%88%20%D8%A7%D9%84%D8%A3%D8%AE%D8%B1%D9%89.)
^ar-Q0884-answer

**ar-Q0885** — السوشي جيد، لكن الأطباق التايلاندية أفضل.

Sushi is good, but Thai dishes are better.

Expected form: **لكن**

Why: Cause and concession. [[Arabic#^ar-Q0885|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A7%D9%84%D8%B3%D9%88%D8%B4%D9%8A%20%D8%AC%D9%8A%D8%AF%D8%8C%20%D9%84%D9%83%D9%86%20%D8%A7%D9%84%D8%A3%D8%B7%D8%A8%D8%A7%D9%82%20%D8%A7%D9%84%D8%AA%D8%A7%D9%8A%D9%84%D8%A7%D9%86%D8%AF%D9%8A%D8%A9%20%D8%A3%D9%81%D8%B6%D9%84.)
^ar-Q0885-answer

**ar-Q0886** — السوشي جيد، لكن الأطباق التايلاندية أفضل.

Sushi is good, but Thai dishes are better.

Why: Cause and concession. [[Arabic#^ar-Q0886|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A7%D9%84%D8%B3%D9%88%D8%B4%D9%8A%20%D8%AC%D9%8A%D8%AF%D8%8C%20%D9%84%D9%83%D9%86%20%D8%A7%D9%84%D8%A3%D8%B7%D8%A8%D8%A7%D9%82%20%D8%A7%D9%84%D8%AA%D8%A7%D9%8A%D9%84%D8%A7%D9%86%D8%AF%D9%8A%D8%A9%20%D8%A3%D9%81%D8%B6%D9%84.)
^ar-Q0886-answer

**ar-Q0887** — اني اتطلع لذلك.

I look forward to it.

Why: Cause and concession. [[Arabic#^ar-Q0887|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A7%D9%86%D9%8A%20%D8%A7%D8%AA%D8%B7%D9%84%D8%B9%20%D9%84%D8%B0%D9%84%D9%83.)
^ar-Q0887-answer

**ar-Q0888** — اني اتطلع لذلك.

I look forward to it.

لأن supplies a reason; لكن introduces contrast; لذلك a consequence. Attached pronouns and nominal clauses affect the surrounding grammar. Distinguish argument relationships carefully.

Why: Cause and concession. [[Arabic#^ar-Q0888|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A7%D9%86%D9%8A%20%D8%A7%D8%AA%D8%B7%D9%84%D8%B9%20%D9%84%D8%B0%D9%84%D9%83.)
^ar-Q0888-answer

**ar-Q0889** — ربما تسأل، لمَ الجمل؟ هذا لأن الجمل مثيرة للاهتمام أكثر.

Why sentences? …you may ask. Well, because sentences are more interesting.

Expected form: **لأن**

Why: Cause and concession. [[Arabic#^ar-Q0889|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B1%D8%A8%D9%85%D8%A7%20%D8%AA%D8%B3%D8%A3%D9%84%D8%8C%20%D9%84%D9%85%D9%8E%20%D8%A7%D9%84%D8%AC%D9%85%D9%84%D8%9F%20%D9%87%D8%B0%D8%A7%20%D9%84%D8%A3%D9%86%20%D8%A7%D9%84%D8%AC%D9%85%D9%84%20%D9%85%D8%AB%D9%8A%D8%B1%D8%A9%20%D9%84%D9%84%D8%A7%D9%87%D8%AA%D9%85%D8%A7%D9%85%20%D8%A3%D9%83%D8%AB%D8%B1.)
^ar-Q0889-answer

**ar-Q0890** — ربما تسأل، لمَ الجمل؟ هذا لأن الجمل مثيرة للاهتمام أكثر.

Why sentences? …you may ask. Well, because sentences are more interesting.

Expected form: **لأن**

Why: Cause and concession. [[Arabic#^ar-Q0890|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B1%D8%A8%D9%85%D8%A7%20%D8%AA%D8%B3%D8%A3%D9%84%D8%8C%20%D9%84%D9%85%D9%8E%20%D8%A7%D9%84%D8%AC%D9%85%D9%84%D8%9F%20%D9%87%D8%B0%D8%A7%20%D9%84%D8%A3%D9%86%20%D8%A7%D9%84%D8%AC%D9%85%D9%84%20%D9%85%D8%AB%D9%8A%D8%B1%D8%A9%20%D9%84%D9%84%D8%A7%D9%87%D8%AA%D9%85%D8%A7%D9%85%20%D8%A3%D9%83%D8%AB%D8%B1.)
^ar-Q0890-answer

**ar-Q0891** — مع انني كنت جالساً تحت الشمس، ولكن كنت أشعر بالبرد.

Even though I was sitting in the sun, I still felt chilly.

Expected form: **ولكن**

Why: Cause and concession. [[Arabic#^ar-Q0891|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D8%B9%20%D8%A7%D9%86%D9%86%D9%8A%20%D9%83%D9%86%D8%AA%20%D8%AC%D8%A7%D9%84%D8%B3%D8%A7%D9%8B%20%D8%AA%D8%AD%D8%AA%20%D8%A7%D9%84%D8%B4%D9%85%D8%B3%D8%8C%20%D9%88%D9%84%D9%83%D9%86%20%D9%83%D9%86%D8%AA%20%D8%A3%D8%B4%D8%B9%D8%B1%20%D8%A8%D8%A7%D9%84%D8%A8%D8%B1%D8%AF.)
^ar-Q0891-answer

**ar-Q0892** — مع انني كنت جالساً تحت الشمس، ولكن كنت أشعر بالبرد.

Even though I was sitting in the sun, I still felt chilly.

Why: Cause and concession. [[Arabic#^ar-Q0892|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D8%B9%20%D8%A7%D9%86%D9%86%D9%8A%20%D9%83%D9%86%D8%AA%20%D8%AC%D8%A7%D9%84%D8%B3%D8%A7%D9%8B%20%D8%AA%D8%AD%D8%AA%20%D8%A7%D9%84%D8%B4%D9%85%D8%B3%D8%8C%20%D9%88%D9%84%D9%83%D9%86%20%D9%83%D9%86%D8%AA%20%D8%A3%D8%B4%D8%B9%D8%B1%20%D8%A8%D8%A7%D9%84%D8%A8%D8%B1%D8%AF.)
^ar-Q0892-answer

**ar-Q0893** — رغم كل شيء فهي لم تأتي.

After all she did not come.

Why: Cause and concession. [[Arabic#^ar-Q0893|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B1%D8%BA%D9%85%20%D9%83%D9%84%20%D8%B4%D9%8A%D8%A1%20%D9%81%D9%87%D9%8A%20%D9%84%D9%85%20%D8%AA%D8%A3%D8%AA%D9%8A.)
^ar-Q0893-answer

**ar-Q0894** — رغم كل شيء فهي لم تأتي.

After all she did not come.

لأن supplies a reason; لكن introduces contrast; لذلك a consequence. Attached pronouns and nominal clauses affect the surrounding grammar. Distinguish argument relationships carefully.

Why: Cause and concession. [[Arabic#^ar-Q0894|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B1%D8%BA%D9%85%20%D9%83%D9%84%20%D8%B4%D9%8A%D8%A1%20%D9%81%D9%87%D9%8A%20%D9%84%D9%85%20%D8%AA%D8%A3%D8%AA%D9%8A.)
^ar-Q0894-answer

**ar-Q0895** — ما هو مهم ليس الهدف, ولكن الرحلة.

What's important is not the goal, but the journey.

Expected form: **ولكن**

Why: Cause and concession. [[Arabic#^ar-Q0895|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D8%A7%20%D9%87%D9%88%20%D9%85%D9%87%D9%85%20%D9%84%D9%8A%D8%B3%20%D8%A7%D9%84%D9%87%D8%AF%D9%81%2C%20%D9%88%D9%84%D9%83%D9%86%20%D8%A7%D9%84%D8%B1%D8%AD%D9%84%D8%A9.)
^ar-Q0895-answer

**ar-Q0896** — ما هو مهم ليس الهدف, ولكن الرحلة.

What's important is not the goal, but the journey.

Expected form: **ولكن**

Why: Cause and concession. [[Arabic#^ar-Q0896|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D8%A7%20%D9%87%D9%88%20%D9%85%D9%87%D9%85%20%D9%84%D9%8A%D8%B3%20%D8%A7%D9%84%D9%87%D8%AF%D9%81%2C%20%D9%88%D9%84%D9%83%D9%86%20%D8%A7%D9%84%D8%B1%D8%AD%D9%84%D8%A9.)
^ar-Q0896-answer

**ar-Q0897** — قد لا أملك الكثير من المال، لكن علي الاقل أنا أعيش بشروطي الخاصة

I may not have a lot of money, but at least I live on my own terms.

Expected form: **لكن**

Why: Cause and concession. [[Arabic#^ar-Q0897|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%82%D8%AF%20%D9%84%D8%A7%20%D8%A3%D9%85%D9%84%D9%83%20%D8%A7%D9%84%D9%83%D8%AB%D9%8A%D8%B1%20%D9%85%D9%86%20%D8%A7%D9%84%D9%85%D8%A7%D9%84%D8%8C%20%D9%84%D9%83%D9%86%20%D8%B9%D9%84%D9%8A%20%D8%A7%D9%84%D8%A7%D9%82%D9%84%20%D8%A3%D9%86%D8%A7%20%D8%A3%D8%B9%D9%8A%D8%B4%20%D8%A8%D8%B4%D8%B1%D9%88%D8%B7%D9%8A%20%D8%A7%D9%84%D8%AE%D8%A7%D8%B5%D8%A9)
^ar-Q0897-answer

**ar-Q0898** — قد لا أملك الكثير من المال، لكن علي الاقل أنا أعيش بشروطي الخاصة

I may not have a lot of money, but at least I live on my own terms.

Why: Cause and concession. [[Arabic#^ar-Q0898|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%82%D8%AF%20%D9%84%D8%A7%20%D8%A3%D9%85%D9%84%D9%83%20%D8%A7%D9%84%D9%83%D8%AB%D9%8A%D8%B1%20%D9%85%D9%86%20%D8%A7%D9%84%D9%85%D8%A7%D9%84%D8%8C%20%D9%84%D9%83%D9%86%20%D8%B9%D9%84%D9%8A%20%D8%A7%D9%84%D8%A7%D9%82%D9%84%20%D8%A3%D9%86%D8%A7%20%D8%A3%D8%B9%D9%8A%D8%B4%20%D8%A8%D8%B4%D8%B1%D9%88%D8%B7%D9%8A%20%D8%A7%D9%84%D8%AE%D8%A7%D8%B5%D8%A9)
^ar-Q0898-answer

**ar-Q0899** — الخيول أكبر من الكلاب، ولكن القطط أصغر من الكلاب.

Horses are bigger than dogs, but cats are smaller than dogs.

Why: Cause and concession. [[Arabic#^ar-Q0899|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A7%D9%84%D8%AE%D9%8A%D9%88%D9%84%20%D8%A3%D9%83%D8%A8%D8%B1%20%D9%85%D9%86%20%D8%A7%D9%84%D9%83%D9%84%D8%A7%D8%A8%D8%8C%20%D9%88%D9%84%D9%83%D9%86%20%D8%A7%D9%84%D9%82%D8%B7%D8%B7%20%D8%A3%D8%B5%D8%BA%D8%B1%20%D9%85%D9%86%20%D8%A7%D9%84%D9%83%D9%84%D8%A7%D8%A8.)
^ar-Q0899-answer

**ar-Q0900** — الخيول أكبر من الكلاب، ولكن القطط أصغر من الكلاب.

Horses are bigger than dogs, but cats are smaller than dogs.

لأن supplies a reason; لكن introduces contrast; لذلك a consequence. Attached pronouns and nominal clauses affect the surrounding grammar. Distinguish argument relationships carefully.

Why: Cause and concession. [[Arabic#^ar-Q0900|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A7%D9%84%D8%AE%D9%8A%D9%88%D9%84%20%D8%A3%D9%83%D8%A8%D8%B1%20%D9%85%D9%86%20%D8%A7%D9%84%D9%83%D9%84%D8%A7%D8%A8%D8%8C%20%D9%88%D9%84%D9%83%D9%86%20%D8%A7%D9%84%D9%82%D8%B7%D8%B7%20%D8%A3%D8%B5%D8%BA%D8%B1%20%D9%85%D9%86%20%D8%A7%D9%84%D9%83%D9%84%D8%A7%D8%A8.)
^ar-Q0900-answer


### Answers 901–950

**ar-Q0901** — لقد وصلتَ للتّو.

You have only just arrived.

Expected form: **و**

Why: Coordination and quantification. [[Arabic#^ar-Q0901|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%82%D8%AF%20%D9%88%D8%B5%D9%84%D8%AA%D9%8E%20%D9%84%D9%84%D8%AA%D9%91%D9%88.)
^ar-Q0901-answer

**ar-Q0902** — لقد وصلتَ للتّو.

You have only just arrived.

Expected form: **و**

Why: Coordination and quantification. [[Arabic#^ar-Q0902|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%82%D8%AF%20%D9%88%D8%B5%D9%84%D8%AA%D9%8E%20%D9%84%D9%84%D8%AA%D9%91%D9%88.)
^ar-Q0902-answer

**ar-Q0903** — كلا سامي و ليلى مسلمين.

Sami and Layla are both Muslim.

Expected form: **و**

Why: Coordination and quantification. [[Arabic#^ar-Q0903|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D9%84%D8%A7%20%D8%B3%D8%A7%D9%85%D9%8A%20%D9%88%20%D9%84%D9%8A%D9%84%D9%89%20%D9%85%D8%B3%D9%84%D9%85%D9%8A%D9%86.)
^ar-Q0903-answer

**ar-Q0904** — كلا سامي و ليلى مسلمين.

Sami and Layla are both Muslim.

Why: Coordination and quantification. [[Arabic#^ar-Q0904|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D9%84%D8%A7%20%D8%B3%D8%A7%D9%85%D9%8A%20%D9%88%20%D9%84%D9%8A%D9%84%D9%89%20%D9%85%D8%B3%D9%84%D9%85%D9%8A%D9%86.)
^ar-Q0904-answer

**ar-Q0905** — انتهى كل شيء.

Everything's done.

Why: Coordination and quantification. [[Arabic#^ar-Q0905|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A7%D9%86%D8%AA%D9%87%D9%89%20%D9%83%D9%84%20%D8%B4%D9%8A%D8%A1.)
^ar-Q0905-answer

**ar-Q0906** — انتهى كل شيء.

Everything's done.

و is usually attached to the following written word; أو marks alternatives. كل/بعض create quantity phrases with their own agreement and possession-like relations. A separate single و is not the normal spelling in connected prose.

Why: Coordination and quantification. [[Arabic#^ar-Q0906|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A7%D9%86%D8%AA%D9%87%D9%89%20%D9%83%D9%84%20%D8%B4%D9%8A%D8%A1.)
^ar-Q0906-answer

**ar-Q0907** — فقد فاضل كلّ مدخراته.

Fadil's life savings were gone.

Expected form: **كل**

Why: Coordination and quantification. [[Arabic#^ar-Q0907|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%81%D9%82%D8%AF%20%D9%81%D8%A7%D8%B6%D9%84%20%D9%83%D9%84%D9%91%20%D9%85%D8%AF%D8%AE%D8%B1%D8%A7%D8%AA%D9%87.)
^ar-Q0907-answer

**ar-Q0908** — فقد فاضل كلّ مدخراته.

Fadil's life savings were gone.

Expected form: **كل**

Why: Coordination and quantification. [[Arabic#^ar-Q0908|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%81%D9%82%D8%AF%20%D9%81%D8%A7%D8%B6%D9%84%20%D9%83%D9%84%D9%91%20%D9%85%D8%AF%D8%AE%D8%B1%D8%A7%D8%AA%D9%87.)
^ar-Q0908-answer

**ar-Q0909** — أمضى سامي و ليلى بعض الوقت معا في مطعم محليّ للوجبات الخفيفة.

Sami and Layla hung out at the local diner.

Expected form: **و**

Why: Coordination and quantification. [[Arabic#^ar-Q0909|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D9%85%D8%B6%D9%89%20%D8%B3%D8%A7%D9%85%D9%8A%20%D9%88%20%D9%84%D9%8A%D9%84%D9%89%20%D8%A8%D8%B9%D8%B6%20%D8%A7%D9%84%D9%88%D9%82%D8%AA%20%D9%85%D8%B9%D8%A7%20%D9%81%D9%8A%20%D9%85%D8%B7%D8%B9%D9%85%20%D9%85%D8%AD%D9%84%D9%8A%D9%91%20%D9%84%D9%84%D9%88%D8%AC%D8%A8%D8%A7%D8%AA%20%D8%A7%D9%84%D8%AE%D9%81%D9%8A%D9%81%D8%A9.)
^ar-Q0909-answer

**ar-Q0910** — أمضى سامي و ليلى بعض الوقت معا في مطعم محليّ للوجبات الخفيفة.

Sami and Layla hung out at the local diner.

Why: Coordination and quantification. [[Arabic#^ar-Q0910|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D9%85%D8%B6%D9%89%20%D8%B3%D8%A7%D9%85%D9%8A%20%D9%88%20%D9%84%D9%8A%D9%84%D9%89%20%D8%A8%D8%B9%D8%B6%20%D8%A7%D9%84%D9%88%D9%82%D8%AA%20%D9%85%D8%B9%D8%A7%20%D9%81%D9%8A%20%D9%85%D8%B7%D8%B9%D9%85%20%D9%85%D8%AD%D9%84%D9%8A%D9%91%20%D9%84%D9%84%D9%88%D8%AC%D8%A8%D8%A7%D8%AA%20%D8%A7%D9%84%D8%AE%D9%81%D9%8A%D9%81%D8%A9.)
^ar-Q0910-answer

**ar-Q0911** — تساعد أمها كل صباح في المطبخ لإعداد الفطور.

Every morning, she helps her mother make breakfast in the kitchen.

Why: Coordination and quantification. [[Arabic#^ar-Q0911|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%AA%D8%B3%D8%A7%D8%B9%D8%AF%20%D8%A3%D9%85%D9%87%D8%A7%20%D9%83%D9%84%20%D8%B5%D8%A8%D8%A7%D8%AD%20%D9%81%D9%8A%20%D8%A7%D9%84%D9%85%D8%B7%D8%A8%D8%AE%20%D9%84%D8%A5%D8%B9%D8%AF%D8%A7%D8%AF%20%D8%A7%D9%84%D9%81%D8%B7%D9%88%D8%B1.)
^ar-Q0911-answer

**ar-Q0912** — تساعد أمها كل صباح في المطبخ لإعداد الفطور.

Every morning, she helps her mother make breakfast in the kitchen.

و is usually attached to the following written word; أو marks alternatives. كل/بعض create quantity phrases with their own agreement and possession-like relations. A separate single و is not the normal spelling in connected prose.

Why: Coordination and quantification. [[Arabic#^ar-Q0912|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%AA%D8%B3%D8%A7%D8%B9%D8%AF%20%D8%A3%D9%85%D9%87%D8%A7%20%D9%83%D9%84%20%D8%B5%D8%A8%D8%A7%D8%AD%20%D9%81%D9%8A%20%D8%A7%D9%84%D9%85%D8%B7%D8%A8%D8%AE%20%D9%84%D8%A5%D8%B9%D8%AF%D8%A7%D8%AF%20%D8%A7%D9%84%D9%81%D8%B7%D9%88%D8%B1.)
^ar-Q0912-answer

**ar-Q0913** — أراد سامي بعض الماء.

Sami wanted some water.

Expected form: **بعض**

Why: Coordination and quantification. [[Arabic#^ar-Q0913|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%B1%D8%A7%D8%AF%20%D8%B3%D8%A7%D9%85%D9%8A%20%D8%A8%D8%B9%D8%B6%20%D8%A7%D9%84%D9%85%D8%A7%D8%A1.)
^ar-Q0913-answer

**ar-Q0914** — أراد سامي بعض الماء.

Sami wanted some water.

Expected form: **بعض**

Why: Coordination and quantification. [[Arabic#^ar-Q0914|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%B1%D8%A7%D8%AF%20%D8%B3%D8%A7%D9%85%D9%8A%20%D8%A8%D8%B9%D8%B6%20%D8%A7%D9%84%D9%85%D8%A7%D8%A1.)
^ar-Q0914-answer

**ar-Q0915** — تحليت بكل شجاعتي و ذهبت إلى هناك.

I screwed up my courage and went there.

Expected form: **و**

Why: Coordination and quantification. [[Arabic#^ar-Q0915|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%AA%D8%AD%D9%84%D9%8A%D8%AA%20%D8%A8%D9%83%D9%84%20%D8%B4%D8%AC%D8%A7%D8%B9%D8%AA%D9%8A%20%D9%88%20%D8%B0%D9%87%D8%A8%D8%AA%20%D8%A5%D9%84%D9%89%20%D9%87%D9%86%D8%A7%D9%83.)
^ar-Q0915-answer

**ar-Q0916** — تحليت بكل شجاعتي و ذهبت إلى هناك.

I screwed up my courage and went there.

Why: Coordination and quantification. [[Arabic#^ar-Q0916|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%AA%D8%AD%D9%84%D9%8A%D8%AA%20%D8%A8%D9%83%D9%84%20%D8%B4%D8%AC%D8%A7%D8%B9%D8%AA%D9%8A%20%D9%88%20%D8%B0%D9%87%D8%A8%D8%AA%20%D8%A5%D9%84%D9%89%20%D9%87%D9%86%D8%A7%D9%83.)
^ar-Q0916-answer

**ar-Q0917** — كان سامي يبدّل ملابسه كلّ يوم.

Sami changed clothes on a daily basis.

Why: Coordination and quantification. [[Arabic#^ar-Q0917|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D8%A7%D9%86%20%D8%B3%D8%A7%D9%85%D9%8A%20%D9%8A%D8%A8%D8%AF%D9%91%D9%84%20%D9%85%D9%84%D8%A7%D8%A8%D8%B3%D9%87%20%D9%83%D9%84%D9%91%20%D9%8A%D9%88%D9%85.)
^ar-Q0917-answer

**ar-Q0918** — كان سامي يبدّل ملابسه كلّ يوم.

Sami changed clothes on a daily basis.

و is usually attached to the following written word; أو marks alternatives. كل/بعض create quantity phrases with their own agreement and possession-like relations. A separate single و is not the normal spelling in connected prose.

Why: Coordination and quantification. [[Arabic#^ar-Q0918|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D8%A7%D9%86%20%D8%B3%D8%A7%D9%85%D9%8A%20%D9%8A%D8%A8%D8%AF%D9%91%D9%84%20%D9%85%D9%84%D8%A7%D8%A8%D8%B3%D9%87%20%D9%83%D9%84%D9%91%20%D9%8A%D9%88%D9%85.)
^ar-Q0918-answer

**ar-Q0919** — و أخيراً وصلنا.

Well, here we are!

Expected form: **و**

Why: Coordination and quantification. [[Arabic#^ar-Q0919|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%88%20%D8%A3%D8%AE%D9%8A%D8%B1%D8%A7%D9%8B%20%D9%88%D8%B5%D9%84%D9%86%D8%A7.)
^ar-Q0919-answer

**ar-Q0920** — و أخيراً وصلنا.

Well, here we are!

Expected form: **و**

Why: Coordination and quantification. [[Arabic#^ar-Q0920|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%88%20%D8%A3%D8%AE%D9%8A%D8%B1%D8%A7%D9%8B%20%D9%88%D8%B5%D9%84%D9%86%D8%A7.)
^ar-Q0920-answer

**ar-Q0921** — كانت هناك حديقة عند كل بيت.

Every house had a garden.

Expected form: **كل**

Why: Coordination and quantification. [[Arabic#^ar-Q0921|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D8%A7%D9%86%D8%AA%20%D9%87%D9%86%D8%A7%D9%83%20%D8%AD%D8%AF%D9%8A%D9%82%D8%A9%20%D8%B9%D9%86%D8%AF%20%D9%83%D9%84%20%D8%A8%D9%8A%D8%AA.)
^ar-Q0921-answer

**ar-Q0922** — كانت هناك حديقة عند كل بيت.

Every house had a garden.

Why: Coordination and quantification. [[Arabic#^ar-Q0922|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D8%A7%D9%86%D8%AA%20%D9%87%D9%86%D8%A7%D9%83%20%D8%AD%D8%AF%D9%8A%D9%82%D8%A9%20%D8%B9%D9%86%D8%AF%20%D9%83%D9%84%20%D8%A8%D9%8A%D8%AA.)
^ar-Q0922-answer

**ar-Q0923** — تعال و تناول منه قليلا.

Come and have some.

Why: Coordination and quantification. [[Arabic#^ar-Q0923|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%AA%D8%B9%D8%A7%D9%84%20%D9%88%20%D8%AA%D9%86%D8%A7%D9%88%D9%84%20%D9%85%D9%86%D9%87%20%D9%82%D9%84%D9%8A%D9%84%D8%A7.)
^ar-Q0923-answer

**ar-Q0924** — تعال و تناول منه قليلا.

Come and have some.

و is usually attached to the following written word; أو marks alternatives. كل/بعض create quantity phrases with their own agreement and possession-like relations. A separate single و is not the normal spelling in connected prose.

Why: Coordination and quantification. [[Arabic#^ar-Q0924|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%AA%D8%B9%D8%A7%D9%84%20%D9%88%20%D8%AA%D9%86%D8%A7%D9%88%D9%84%20%D9%85%D9%86%D9%87%20%D9%82%D9%84%D9%8A%D9%84%D8%A7.)
^ar-Q0924-answer

**ar-Q0925** — مشيا سامي و ليلى على طول الشّاطئ.

Sami and Layla walked down along the beach.

Expected form: **و**

Why: Coordination and quantification. [[Arabic#^ar-Q0925|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D8%B4%D9%8A%D8%A7%20%D8%B3%D8%A7%D9%85%D9%8A%20%D9%88%20%D9%84%D9%8A%D9%84%D9%89%20%D8%B9%D9%84%D9%89%20%D8%B7%D9%88%D9%84%20%D8%A7%D9%84%D8%B4%D9%91%D8%A7%D8%B7%D8%A6.)
^ar-Q0925-answer

**ar-Q0926** — مشيا سامي و ليلى على طول الشّاطئ.

Sami and Layla walked down along the beach.

Expected form: **و**

Why: Coordination and quantification. [[Arabic#^ar-Q0926|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D8%B4%D9%8A%D8%A7%20%D8%B3%D8%A7%D9%85%D9%8A%20%D9%88%20%D9%84%D9%8A%D9%84%D9%89%20%D8%B9%D9%84%D9%89%20%D8%B7%D9%88%D9%84%20%D8%A7%D9%84%D8%B4%D9%91%D8%A7%D8%B7%D8%A6.)
^ar-Q0926-answer

**ar-Q0927** — لديك بعض الكتب.

You have some books.

Expected form: **بعض**

Why: Coordination and quantification. [[Arabic#^ar-Q0927|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D8%AF%D9%8A%D9%83%20%D8%A8%D8%B9%D8%B6%20%D8%A7%D9%84%D9%83%D8%AA%D8%A8.)
^ar-Q0927-answer

**ar-Q0928** — لديك بعض الكتب.

You have some books.

Why: Coordination and quantification. [[Arabic#^ar-Q0928|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D8%AF%D9%8A%D9%83%20%D8%A8%D8%B9%D8%B6%20%D8%A7%D9%84%D9%83%D8%AA%D8%A8.)
^ar-Q0928-answer

**ar-Q0929** — أقوم ببعض التمارين الخفيفة كل صباح.

I take light exercise every morning.

Why: Coordination and quantification. [[Arabic#^ar-Q0929|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D9%82%D9%88%D9%85%20%D8%A8%D8%A8%D8%B9%D8%B6%20%D8%A7%D9%84%D8%AA%D9%85%D8%A7%D8%B1%D9%8A%D9%86%20%D8%A7%D9%84%D8%AE%D9%81%D9%8A%D9%81%D8%A9%20%D9%83%D9%84%20%D8%B5%D8%A8%D8%A7%D8%AD.)
^ar-Q0929-answer

**ar-Q0930** — أقوم ببعض التمارين الخفيفة كل صباح.

I take light exercise every morning.

و is usually attached to the following written word; أو marks alternatives. كل/بعض create quantity phrases with their own agreement and possession-like relations. A separate single و is not the normal spelling in connected prose.

Why: Coordination and quantification. [[Arabic#^ar-Q0930|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D9%82%D9%88%D9%85%20%D8%A8%D8%A8%D8%B9%D8%B6%20%D8%A7%D9%84%D8%AA%D9%85%D8%A7%D8%B1%D9%8A%D9%86%20%D8%A7%D9%84%D8%AE%D9%81%D9%8A%D9%81%D8%A9%20%D9%83%D9%84%20%D8%B5%D8%A8%D8%A7%D8%AD.)
^ar-Q0930-answer

**ar-Q0931** — اليابان بلد يحيط به البحر و ليده مناخ معتدل.

Surrounded by the sea, Japan has a mild climate.

Expected form: **و**

Why: Coordination and quantification. [[Arabic#^ar-Q0931|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A7%D9%84%D9%8A%D8%A7%D8%A8%D8%A7%D9%86%20%D8%A8%D9%84%D8%AF%20%D9%8A%D8%AD%D9%8A%D8%B7%20%D8%A8%D9%87%20%D8%A7%D9%84%D8%A8%D8%AD%D8%B1%20%D9%88%20%D9%84%D9%8A%D8%AF%D9%87%20%D9%85%D9%86%D8%A7%D8%AE%20%D9%85%D8%B9%D8%AA%D8%AF%D9%84.)
^ar-Q0931-answer

**ar-Q0932** — اليابان بلد يحيط به البحر و ليده مناخ معتدل.

Surrounded by the sea, Japan has a mild climate.

Expected form: **و**

Why: Coordination and quantification. [[Arabic#^ar-Q0932|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A7%D9%84%D9%8A%D8%A7%D8%A8%D8%A7%D9%86%20%D8%A8%D9%84%D8%AF%20%D9%8A%D8%AD%D9%8A%D8%B7%20%D8%A8%D9%87%20%D8%A7%D9%84%D8%A8%D8%AD%D8%B1%20%D9%88%20%D9%84%D9%8A%D8%AF%D9%87%20%D9%85%D9%86%D8%A7%D8%AE%20%D9%85%D8%B9%D8%AA%D8%AF%D9%84.)
^ar-Q0932-answer

**ar-Q0933** — نطقا سامي و ليلى بالشّهادة معا.

Sami and Layla took their shahada together.

Expected form: **و**

Why: Coordination and quantification. [[Arabic#^ar-Q0933|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%86%D8%B7%D9%82%D8%A7%20%D8%B3%D8%A7%D9%85%D9%8A%20%D9%88%20%D9%84%D9%8A%D9%84%D9%89%20%D8%A8%D8%A7%D9%84%D8%B4%D9%91%D9%87%D8%A7%D8%AF%D8%A9%20%D9%85%D8%B9%D8%A7.)
^ar-Q0933-answer

**ar-Q0934** — نطقا سامي و ليلى بالشّهادة معا.

Sami and Layla took their shahada together.

Why: Coordination and quantification. [[Arabic#^ar-Q0934|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%86%D8%B7%D9%82%D8%A7%20%D8%B3%D8%A7%D9%85%D9%8A%20%D9%88%20%D9%84%D9%8A%D9%84%D9%89%20%D8%A8%D8%A7%D9%84%D8%B4%D9%91%D9%87%D8%A7%D8%AF%D8%A9%20%D9%85%D8%B9%D8%A7.)
^ar-Q0934-answer

**ar-Q0935** — لقد احتاج الأمر لحملة تلفزيونيّة وطنيّة من أجل تعقّب سامي و العثور عليه أخيرا.

It took a national TV campaign to finally track Sami down.

Why: Coordination and quantification. [[Arabic#^ar-Q0935|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%82%D8%AF%20%D8%A7%D8%AD%D8%AA%D8%A7%D8%AC%20%D8%A7%D9%84%D8%A3%D9%85%D8%B1%20%D9%84%D8%AD%D9%85%D9%84%D8%A9%20%D8%AA%D9%84%D9%81%D8%B2%D9%8A%D9%88%D9%86%D9%8A%D9%91%D8%A9%20%D9%88%D8%B7%D9%86%D9%8A%D9%91%D8%A9%20%D9%85%D9%86%20%D8%A3%D8%AC%D9%84%20%D8%AA%D8%B9%D9%82%D9%91%D8%A8%20%D8%B3%D8%A7%D9%85%D9%8A%20%D9%88%20%D8%A7%D9%84%D8%B9%D8%AB%D9%88%D8%B1%20%D8%B9%D9%84%D9%8A%D9%87%20%D8%A3%D8%AE%D9%8A%D8%B1%D8%A7.)
^ar-Q0935-answer

**ar-Q0936** — لقد احتاج الأمر لحملة تلفزيونيّة وطنيّة من أجل تعقّب سامي و العثور عليه أخيرا.

It took a national TV campaign to finally track Sami down.

و is usually attached to the following written word; أو marks alternatives. كل/بعض create quantity phrases with their own agreement and possession-like relations. A separate single و is not the normal spelling in connected prose.

Why: Coordination and quantification. [[Arabic#^ar-Q0936|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D9%82%D8%AF%20%D8%A7%D8%AD%D8%AA%D8%A7%D8%AC%20%D8%A7%D9%84%D8%A3%D9%85%D8%B1%20%D9%84%D8%AD%D9%85%D9%84%D8%A9%20%D8%AA%D9%84%D9%81%D8%B2%D9%8A%D9%88%D9%86%D9%8A%D9%91%D8%A9%20%D9%88%D8%B7%D9%86%D9%8A%D9%91%D8%A9%20%D9%85%D9%86%20%D8%A3%D8%AC%D9%84%20%D8%AA%D8%B9%D9%82%D9%91%D8%A8%20%D8%B3%D8%A7%D9%85%D9%8A%20%D9%88%20%D8%A7%D9%84%D8%B9%D8%AB%D9%88%D8%B1%20%D8%B9%D9%84%D9%8A%D9%87%20%D8%A3%D8%AE%D9%8A%D8%B1%D8%A7.)
^ar-Q0936-answer

**ar-Q0937** — كانت ليلى غاضبة و مشوّشة.

Layla was angry and confused.

Expected form: **و**

Why: Coordination and quantification. [[Arabic#^ar-Q0937|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D8%A7%D9%86%D8%AA%20%D9%84%D9%8A%D9%84%D9%89%20%D8%BA%D8%A7%D8%B6%D8%A8%D8%A9%20%D9%88%20%D9%85%D8%B4%D9%88%D9%91%D8%B4%D8%A9.)
^ar-Q0937-answer

**ar-Q0938** — كانت ليلى غاضبة و مشوّشة.

Layla was angry and confused.

Expected form: **و**

Why: Coordination and quantification. [[Arabic#^ar-Q0938|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D8%A7%D9%86%D8%AA%20%D9%84%D9%8A%D9%84%D9%89%20%D8%BA%D8%A7%D8%B6%D8%A8%D8%A9%20%D9%88%20%D9%85%D8%B4%D9%88%D9%91%D8%B4%D8%A9.)
^ar-Q0938-answer

**ar-Q0939** — أنا و أنت في نفس العمر.

You and I are the same age.

Expected form: **و**

Why: Coordination and quantification. [[Arabic#^ar-Q0939|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D9%86%D8%A7%20%D9%88%20%D8%A3%D9%86%D8%AA%20%D9%81%D9%8A%20%D9%86%D9%81%D8%B3%20%D8%A7%D9%84%D8%B9%D9%85%D8%B1.)
^ar-Q0939-answer

**ar-Q0940** — أنا و أنت في نفس العمر.

You and I are the same age.

Why: Coordination and quantification. [[Arabic#^ar-Q0940|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D9%86%D8%A7%20%D9%88%20%D8%A3%D9%86%D8%AA%20%D9%81%D9%8A%20%D9%86%D9%81%D8%B3%20%D8%A7%D9%84%D8%B9%D9%85%D8%B1.)
^ar-Q0940-answer

**ar-Q0941** — كل من فهمني هم حفنة من الناس.

Only a few people understood me.

Why: Coordination and quantification. [[Arabic#^ar-Q0941|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D9%84%20%D9%85%D9%86%20%D9%81%D9%87%D9%85%D9%86%D9%8A%20%D9%87%D9%85%20%D8%AD%D9%81%D9%86%D8%A9%20%D9%85%D9%86%20%D8%A7%D9%84%D9%86%D8%A7%D8%B3.)
^ar-Q0941-answer

**ar-Q0942** — كل من فهمني هم حفنة من الناس.

Only a few people understood me.

و is usually attached to the following written word; أو marks alternatives. كل/بعض create quantity phrases with their own agreement and possession-like relations. A separate single و is not the normal spelling in connected prose.

Why: Coordination and quantification. [[Arabic#^ar-Q0942|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D9%84%20%D9%85%D9%86%20%D9%81%D9%87%D9%85%D9%86%D9%8A%20%D9%87%D9%85%20%D8%AD%D9%81%D9%86%D8%A9%20%D9%85%D9%86%20%D8%A7%D9%84%D9%86%D8%A7%D8%B3.)
^ar-Q0942-answer

**ar-Q0943** — ينبغي لها أن تستمع إلى آراء الآخرين أكثر.

She should listen more to other people.

Expected form: **أكثر**

Why: Coordination and quantification. [[Arabic#^ar-Q0943|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%8A%D9%86%D8%A8%D8%BA%D9%8A%20%D9%84%D9%87%D8%A7%20%D8%A3%D9%86%20%D8%AA%D8%B3%D8%AA%D9%85%D8%B9%20%D8%A5%D9%84%D9%89%20%D8%A2%D8%B1%D8%A7%D8%A1%20%D8%A7%D9%84%D8%A2%D8%AE%D8%B1%D9%8A%D9%86%20%D8%A3%D9%83%D8%AB%D8%B1.)
^ar-Q0943-answer

**ar-Q0944** — ينبغي لها أن تستمع إلى آراء الآخرين أكثر.

She should listen more to other people.

Expected form: **أكثر**

Why: Coordination and quantification. [[Arabic#^ar-Q0944|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%8A%D9%86%D8%A8%D8%BA%D9%8A%20%D9%84%D9%87%D8%A7%20%D8%A3%D9%86%20%D8%AA%D8%B3%D8%AA%D9%85%D8%B9%20%D8%A5%D9%84%D9%89%20%D8%A2%D8%B1%D8%A7%D8%A1%20%D8%A7%D9%84%D8%A2%D8%AE%D8%B1%D9%8A%D9%86%20%D8%A3%D9%83%D8%AB%D8%B1.)
^ar-Q0944-answer

**ar-Q0945** — دع كاميرتي و شأنها.

Leave my camera alone.

Expected form: **و**

Why: Coordination and quantification. [[Arabic#^ar-Q0945|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%AF%D8%B9%20%D9%83%D8%A7%D9%85%D9%8A%D8%B1%D8%AA%D9%8A%20%D9%88%20%D8%B4%D8%A3%D9%86%D9%87%D8%A7.)
^ar-Q0945-answer

**ar-Q0946** — دع كاميرتي و شأنها.

Leave my camera alone.

Why: Coordination and quantification. [[Arabic#^ar-Q0946|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%AF%D8%B9%20%D9%83%D8%A7%D9%85%D9%8A%D8%B1%D8%AA%D9%8A%20%D9%88%20%D8%B4%D8%A3%D9%86%D9%87%D8%A7.)
^ar-Q0946-answer

**ar-Q0947** — أي نشاط تحتاج لتحقيقه ستحتاج إلى وقت أكثر مما تملكه.

Any activity you need to accomplish will take more time than you have.

Why: Coordination and quantification. [[Arabic#^ar-Q0947|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D9%8A%20%D9%86%D8%B4%D8%A7%D8%B7%20%D8%AA%D8%AD%D8%AA%D8%A7%D8%AC%20%D9%84%D8%AA%D8%AD%D9%82%D9%8A%D9%82%D9%87%20%D8%B3%D8%AA%D8%AD%D8%AA%D8%A7%D8%AC%20%D8%A5%D9%84%D9%89%20%D9%88%D9%82%D8%AA%20%D8%A3%D9%83%D8%AB%D8%B1%20%D9%85%D9%85%D8%A7%20%D8%AA%D9%85%D9%84%D9%83%D9%87.)
^ar-Q0947-answer

**ar-Q0948** — أي نشاط تحتاج لتحقيقه ستحتاج إلى وقت أكثر مما تملكه.

Any activity you need to accomplish will take more time than you have.

و is usually attached to the following written word; أو marks alternatives. كل/بعض create quantity phrases with their own agreement and possession-like relations. A separate single و is not the normal spelling in connected prose.

Why: Coordination and quantification. [[Arabic#^ar-Q0948|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D9%8A%20%D9%86%D8%B4%D8%A7%D8%B7%20%D8%AA%D8%AD%D8%AA%D8%A7%D8%AC%20%D9%84%D8%AA%D8%AD%D9%82%D9%8A%D9%82%D9%87%20%D8%B3%D8%AA%D8%AD%D8%AA%D8%A7%D8%AC%20%D8%A5%D9%84%D9%89%20%D9%88%D9%82%D8%AA%20%D8%A3%D9%83%D8%AB%D8%B1%20%D9%85%D9%85%D8%A7%20%D8%AA%D9%85%D9%84%D9%83%D9%87.)
^ar-Q0948-answer

**ar-Q0949** — بعض الأطعمة تسبب لي الحساسية.

Some foods cause me an allergic reaction.

Expected form: **بعض**

Why: Coordination and quantification. [[Arabic#^ar-Q0949|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A8%D8%B9%D8%B6%20%D8%A7%D9%84%D8%A3%D8%B7%D8%B9%D9%85%D8%A9%20%D8%AA%D8%B3%D8%A8%D8%A8%20%D9%84%D9%8A%20%D8%A7%D9%84%D8%AD%D8%B3%D8%A7%D8%B3%D9%8A%D8%A9.)
^ar-Q0949-answer

**ar-Q0950** — بعض الأطعمة تسبب لي الحساسية.

Some foods cause me an allergic reaction.

Expected form: **بعض**

Why: Coordination and quantification. [[Arabic#^ar-Q0950|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A8%D8%B9%D8%B6%20%D8%A7%D9%84%D8%A3%D8%B7%D8%B9%D9%85%D8%A9%20%D8%AA%D8%B3%D8%A8%D8%A8%20%D9%84%D9%8A%20%D8%A7%D9%84%D8%AD%D8%B3%D8%A7%D8%B3%D9%8A%D8%A9.)
^ar-Q0950-answer


### Answers 951–1000

**ar-Q0951** — يجب ان تذهب للبيت ؟

Shouldn't you go home?

Expected form: **يجب**

Why: Courtesy and certainty. [[Arabic#^ar-Q0951|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%8A%D8%AC%D8%A8%20%D8%A7%D9%86%20%D8%AA%D8%B0%D9%87%D8%A8%20%D9%84%D9%84%D8%A8%D9%8A%D8%AA%20%D8%9F)
^ar-Q0951-answer

**ar-Q0952** — يجب ان تذهب للبيت ؟

Shouldn't you go home?

Why: Courtesy and certainty. [[Arabic#^ar-Q0952|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%8A%D8%AC%D8%A8%20%D8%A7%D9%86%20%D8%AA%D8%B0%D9%87%D8%A8%20%D9%84%D9%84%D8%A8%D9%8A%D8%AA%20%D8%9F)
^ar-Q0952-answer

**ar-Q0953** — اتصل بي حين تأتي إلى طوكيو رجاءً.

Please get in touch with me when you come to Tokyo.

Why: Courtesy and certainty. [[Arabic#^ar-Q0953|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A7%D8%AA%D8%B5%D9%84%20%D8%A8%D9%8A%20%D8%AD%D9%8A%D9%86%20%D8%AA%D8%A3%D8%AA%D9%8A%20%D8%A5%D9%84%D9%89%20%D8%B7%D9%88%D9%83%D9%8A%D9%88%20%D8%B1%D8%AC%D8%A7%D8%A1%D9%8B.)
^ar-Q0953-answer

**ar-Q0954** — اتصل بي حين تأتي إلى طوكيو رجاءً.

Please get in touch with me when you come to Tokyo.

ربما limits certainty, يمكن expresses possibility/ability in suitable constructions, and يجب expresses obligation/necessity. Professional Arabic distinguishes a supported claim from a proposed explanation.

Why: Courtesy and certainty. [[Arabic#^ar-Q0954|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A7%D8%AA%D8%B5%D9%84%20%D8%A8%D9%8A%20%D8%AD%D9%8A%D9%86%20%D8%AA%D8%A3%D8%AA%D9%8A%20%D8%A5%D9%84%D9%89%20%D8%B7%D9%88%D9%83%D9%8A%D9%88%20%D8%B1%D8%AC%D8%A7%D8%A1%D9%8B.)
^ar-Q0954-answer

**ar-Q0955** — مازال يجب دفع الفاتورة اليوم.

The bill still has to be paid today.

Expected form: **يجب**

Why: Courtesy and certainty. [[Arabic#^ar-Q0955|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D8%A7%D8%B2%D8%A7%D9%84%20%D9%8A%D8%AC%D8%A8%20%D8%AF%D9%81%D8%B9%20%D8%A7%D9%84%D9%81%D8%A7%D8%AA%D9%88%D8%B1%D8%A9%20%D8%A7%D9%84%D9%8A%D9%88%D9%85.)
^ar-Q0955-answer

**ar-Q0956** — مازال يجب دفع الفاتورة اليوم.

The bill still has to be paid today.

Expected form: **يجب**

Why: Courtesy and certainty. [[Arabic#^ar-Q0956|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D8%A7%D8%B2%D8%A7%D9%84%20%D9%8A%D8%AC%D8%A8%20%D8%AF%D9%81%D8%B9%20%D8%A7%D9%84%D9%81%D8%A7%D8%AA%D9%88%D8%B1%D8%A9%20%D8%A7%D9%84%D9%8A%D9%88%D9%85.)
^ar-Q0956-answer

**ar-Q0957** — يجب أن تتم هذا التقرير قبل يوم الأثنين.

You must have the report done by Monday.

Expected form: **يجب**

Why: Courtesy and certainty. [[Arabic#^ar-Q0957|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%8A%D8%AC%D8%A8%20%D8%A3%D9%86%20%D8%AA%D8%AA%D9%85%20%D9%87%D8%B0%D8%A7%20%D8%A7%D9%84%D8%AA%D9%82%D8%B1%D9%8A%D8%B1%20%D9%82%D8%A8%D9%84%20%D9%8A%D9%88%D9%85%20%D8%A7%D9%84%D8%A3%D8%AB%D9%86%D9%8A%D9%86.)
^ar-Q0957-answer

**ar-Q0958** — يجب أن تتم هذا التقرير قبل يوم الأثنين.

You must have the report done by Monday.

Why: Courtesy and certainty. [[Arabic#^ar-Q0958|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%8A%D8%AC%D8%A8%20%D8%A3%D9%86%20%D8%AA%D8%AA%D9%85%20%D9%87%D8%B0%D8%A7%20%D8%A7%D9%84%D8%AA%D9%82%D8%B1%D9%8A%D8%B1%20%D9%82%D8%A8%D9%84%20%D9%8A%D9%88%D9%85%20%D8%A7%D9%84%D8%A3%D8%AB%D9%86%D9%8A%D9%86.)
^ar-Q0958-answer

**ar-Q0959** — يجب عليك أن تُكَلّمَهُم.

You should talk to them.

Why: Courtesy and certainty. [[Arabic#^ar-Q0959|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%8A%D8%AC%D8%A8%20%D8%B9%D9%84%D9%8A%D9%83%20%D8%A3%D9%86%20%D8%AA%D9%8F%D9%83%D9%8E%D9%84%D9%91%D9%85%D9%8E%D9%87%D9%8F%D9%85.)
^ar-Q0959-answer

**ar-Q0960** — يجب عليك أن تُكَلّمَهُم.

You should talk to them.

ربما limits certainty, يمكن expresses possibility/ability in suitable constructions, and يجب expresses obligation/necessity. Professional Arabic distinguishes a supported claim from a proposed explanation.

Why: Courtesy and certainty. [[Arabic#^ar-Q0960|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%8A%D8%AC%D8%A8%20%D8%B9%D9%84%D9%8A%D9%83%20%D8%A3%D9%86%20%D8%AA%D9%8F%D9%83%D9%8E%D9%84%D9%91%D9%85%D9%8E%D9%87%D9%8F%D9%85.)
^ar-Q0960-answer

**ar-Q0961** — رجاءً لا ترسل أي صور عارية لك حتى لا أرفض طلبك.

Please don't send me any nude pictures or I will reject your request.

Expected form: **رجاء**

Why: Courtesy and certainty. [[Arabic#^ar-Q0961|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B1%D8%AC%D8%A7%D8%A1%D9%8B%20%D9%84%D8%A7%20%D8%AA%D8%B1%D8%B3%D9%84%20%D8%A3%D9%8A%20%D8%B5%D9%88%D8%B1%20%D8%B9%D8%A7%D8%B1%D9%8A%D8%A9%20%D9%84%D9%83%20%D8%AD%D8%AA%D9%89%20%D9%84%D8%A7%20%D8%A3%D8%B1%D9%81%D8%B6%20%D8%B7%D9%84%D8%A8%D9%83.)
^ar-Q0961-answer

**ar-Q0962** — رجاءً لا ترسل أي صور عارية لك حتى لا أرفض طلبك.

Please don't send me any nude pictures or I will reject your request.

Expected form: **رجاء**

Why: Courtesy and certainty. [[Arabic#^ar-Q0962|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B1%D8%AC%D8%A7%D8%A1%D9%8B%20%D9%84%D8%A7%20%D8%AA%D8%B1%D8%B3%D9%84%20%D8%A3%D9%8A%20%D8%B5%D9%88%D8%B1%20%D8%B9%D8%A7%D8%B1%D9%8A%D8%A9%20%D9%84%D9%83%20%D8%AD%D8%AA%D9%89%20%D9%84%D8%A7%20%D8%A3%D8%B1%D9%81%D8%B6%20%D8%B7%D9%84%D8%A8%D9%83.)
^ar-Q0962-answer

**ar-Q0963** — تعال من فضلك

Please come.

Expected form: **من فضلك**

Why: Courtesy and certainty. [[Arabic#^ar-Q0963|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%AA%D8%B9%D8%A7%D9%84%20%D9%85%D9%86%20%D9%81%D8%B6%D9%84%D9%83)
^ar-Q0963-answer

**ar-Q0964** — تعال من فضلك

Please come.

Why: Courtesy and certainty. [[Arabic#^ar-Q0964|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%AA%D8%B9%D8%A7%D9%84%20%D9%85%D9%86%20%D9%81%D8%B6%D9%84%D9%83)
^ar-Q0964-answer

**ar-Q0965** — ربما أنت محق.

Maybe you're right.

Why: Courtesy and certainty. [[Arabic#^ar-Q0965|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B1%D8%A8%D9%85%D8%A7%20%D8%A3%D9%86%D8%AA%20%D9%85%D8%AD%D9%82.)
^ar-Q0965-answer

**ar-Q0966** — ربما أنت محق.

Maybe you're right.

ربما limits certainty, يمكن expresses possibility/ability in suitable constructions, and يجب expresses obligation/necessity. Professional Arabic distinguishes a supported claim from a proposed explanation.

Why: Courtesy and certainty. [[Arabic#^ar-Q0966|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%B1%D8%A8%D9%85%D8%A7%20%D8%A3%D9%86%D8%AA%20%D9%85%D8%AD%D9%82.)
^ar-Q0966-answer

**ar-Q0967** — كان يجب أن تكون في الحفلة الليلة الماضية. كان هناك الكثير من المتعة.

You should have been at the party last night. It was a lot of fun.

Expected form: **يجب**

Why: Courtesy and certainty. [[Arabic#^ar-Q0967|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D8%A7%D9%86%20%D9%8A%D8%AC%D8%A8%20%D8%A3%D9%86%20%D8%AA%D9%83%D9%88%D9%86%20%D9%81%D9%8A%20%D8%A7%D9%84%D8%AD%D9%81%D9%84%D8%A9%20%D8%A7%D9%84%D9%84%D9%8A%D9%84%D8%A9%20%D8%A7%D9%84%D9%85%D8%A7%D8%B6%D9%8A%D8%A9.%20%D9%83%D8%A7%D9%86%20%D9%87%D9%86%D8%A7%D9%83%20%D8%A7%D9%84%D9%83%D8%AB%D9%8A%D8%B1%20%D9%85%D9%86%20%D8%A7%D9%84%D9%85%D8%AA%D8%B9%D8%A9.)
^ar-Q0967-answer

**ar-Q0968** — كان يجب أن تكون في الحفلة الليلة الماضية. كان هناك الكثير من المتعة.

You should have been at the party last night. It was a lot of fun.

Expected form: **يجب**

Why: Courtesy and certainty. [[Arabic#^ar-Q0968|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D8%A7%D9%86%20%D9%8A%D8%AC%D8%A8%20%D8%A3%D9%86%20%D8%AA%D9%83%D9%88%D9%86%20%D9%81%D9%8A%20%D8%A7%D9%84%D8%AD%D9%81%D9%84%D8%A9%20%D8%A7%D9%84%D9%84%D9%8A%D9%84%D8%A9%20%D8%A7%D9%84%D9%85%D8%A7%D8%B6%D9%8A%D8%A9.%20%D9%83%D8%A7%D9%86%20%D9%87%D9%86%D8%A7%D9%83%20%D8%A7%D9%84%D9%83%D8%AB%D9%8A%D8%B1%20%D9%85%D9%86%20%D8%A7%D9%84%D9%85%D8%AA%D8%B9%D8%A9.)
^ar-Q0968-answer

**ar-Q0969** — لا يجب عليك أن تتقن لغات عديدة.

It doesn't require you to be a polyglot.

Expected form: **يجب**

Why: Courtesy and certainty. [[Arabic#^ar-Q0969|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D8%A7%20%D9%8A%D8%AC%D8%A8%20%D8%B9%D9%84%D9%8A%D9%83%20%D8%A3%D9%86%20%D8%AA%D8%AA%D9%82%D9%86%20%D9%84%D8%BA%D8%A7%D8%AA%20%D8%B9%D8%AF%D9%8A%D8%AF%D8%A9.)
^ar-Q0969-answer

**ar-Q0970** — لا يجب عليك أن تتقن لغات عديدة.

It doesn't require you to be a polyglot.

Why: Courtesy and certainty. [[Arabic#^ar-Q0970|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D8%A7%20%D9%8A%D8%AC%D8%A8%20%D8%B9%D9%84%D9%8A%D9%83%20%D8%A3%D9%86%20%D8%AA%D8%AA%D9%82%D9%86%20%D9%84%D8%BA%D8%A7%D8%AA%20%D8%B9%D8%AF%D9%8A%D8%AF%D8%A9.)
^ar-Q0970-answer

**ar-Q0971** — هل لك أن تصبّ لي كأساً من القهوة من فضلك؟

Would you please pour me a cup of coffee?

Why: Courtesy and certainty. [[Arabic#^ar-Q0971|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D9%84%20%D9%84%D9%83%20%D8%A3%D9%86%20%D8%AA%D8%B5%D8%A8%D9%91%20%D9%84%D9%8A%20%D9%83%D8%A3%D8%B3%D8%A7%D9%8B%20%D9%85%D9%86%20%D8%A7%D9%84%D9%82%D9%87%D9%88%D8%A9%20%D9%85%D9%86%20%D9%81%D8%B6%D9%84%D9%83%D8%9F)
^ar-Q0971-answer

**ar-Q0972** — هل لك أن تصبّ لي كأساً من القهوة من فضلك؟

Would you please pour me a cup of coffee?

ربما limits certainty, يمكن expresses possibility/ability in suitable constructions, and يجب expresses obligation/necessity. Professional Arabic distinguishes a supported claim from a proposed explanation.

Why: Courtesy and certainty. [[Arabic#^ar-Q0972|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%87%D9%84%20%D9%84%D9%83%20%D8%A3%D9%86%20%D8%AA%D8%B5%D8%A8%D9%91%20%D9%84%D9%8A%20%D9%83%D8%A3%D8%B3%D8%A7%D9%8B%20%D9%85%D9%86%20%D8%A7%D9%84%D9%82%D9%87%D9%88%D8%A9%20%D9%85%D9%86%20%D9%81%D8%B6%D9%84%D9%83%D8%9F)
^ar-Q0972-answer

**ar-Q0973** — من فضلك أجب على كل الأسئلة.

Please answer all the questions.

Expected form: **من فضلك**

Why: Courtesy and certainty. [[Arabic#^ar-Q0973|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D9%86%20%D9%81%D8%B6%D9%84%D9%83%20%D8%A3%D8%AC%D8%A8%20%D8%B9%D9%84%D9%89%20%D9%83%D9%84%20%D8%A7%D9%84%D8%A3%D8%B3%D8%A6%D9%84%D8%A9.)
^ar-Q0973-answer

**ar-Q0974** — من فضلك أجب على كل الأسئلة.

Please answer all the questions.

Expected form: **من فضلك**

Why: Courtesy and certainty. [[Arabic#^ar-Q0974|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D9%86%20%D9%81%D8%B6%D9%84%D9%83%20%D8%A3%D8%AC%D8%A8%20%D8%B9%D9%84%D9%89%20%D9%83%D9%84%20%D8%A7%D9%84%D8%A3%D8%B3%D8%A6%D9%84%D8%A9.)
^ar-Q0974-answer

**ar-Q0975** — من فضلك ساعدني.

Could you help me?

Expected form: **من فضلك**

Why: Courtesy and certainty. [[Arabic#^ar-Q0975|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D9%86%20%D9%81%D8%B6%D9%84%D9%83%20%D8%B3%D8%A7%D8%B9%D8%AF%D9%86%D9%8A.)
^ar-Q0975-answer

**ar-Q0976** — من فضلك ساعدني.

Could you help me?

Why: Courtesy and certainty. [[Arabic#^ar-Q0976|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D9%86%20%D9%81%D8%B6%D9%84%D9%83%20%D8%B3%D8%A7%D8%B9%D8%AF%D9%86%D9%8A.)
^ar-Q0976-answer

**ar-Q0977** — يجب أن تُنَمِّيَ شجاعتك.

You must build up your courage.

Why: Courtesy and certainty. [[Arabic#^ar-Q0977|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%8A%D8%AC%D8%A8%20%D8%A3%D9%86%20%D8%AA%D9%8F%D9%86%D9%8E%D9%85%D9%90%D9%91%D9%8A%D9%8E%20%D8%B4%D8%AC%D8%A7%D8%B9%D8%AA%D9%83.)
^ar-Q0977-answer

**ar-Q0978** — يجب أن تُنَمِّيَ شجاعتك.

You must build up your courage.

ربما limits certainty, يمكن expresses possibility/ability in suitable constructions, and يجب expresses obligation/necessity. Professional Arabic distinguishes a supported claim from a proposed explanation.

Why: Courtesy and certainty. [[Arabic#^ar-Q0978|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%8A%D8%AC%D8%A8%20%D8%A3%D9%86%20%D8%AA%D9%8F%D9%86%D9%8E%D9%85%D9%90%D9%91%D9%8A%D9%8E%20%D8%B4%D8%AC%D8%A7%D8%B9%D8%AA%D9%83.)
^ar-Q0978-answer

**ar-Q0979** — أعطني كأساً من الماء من فضلك.

Please give me a glass of water.

Expected form: **من فضلك**

Why: Courtesy and certainty. [[Arabic#^ar-Q0979|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%B9%D8%B7%D9%86%D9%8A%20%D9%83%D8%A3%D8%B3%D8%A7%D9%8B%20%D9%85%D9%86%20%D8%A7%D9%84%D9%85%D8%A7%D8%A1%20%D9%85%D9%86%20%D9%81%D8%B6%D9%84%D9%83.)
^ar-Q0979-answer

**ar-Q0980** — أعطني كأساً من الماء من فضلك.

Please give me a glass of water.

Expected form: **من فضلك**

Why: Courtesy and certainty. [[Arabic#^ar-Q0980|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A3%D8%B9%D8%B7%D9%86%D9%8A%20%D9%83%D8%A3%D8%B3%D8%A7%D9%8B%20%D9%85%D9%86%20%D8%A7%D9%84%D9%85%D8%A7%D8%A1%20%D9%85%D9%86%20%D9%81%D8%B6%D9%84%D9%83.)
^ar-Q0980-answer

**ar-Q0981** — يمكن لتوم أن يقول شيئا.

Tom could've said something.

Expected form: **يمكن**

Why: Courtesy and certainty. [[Arabic#^ar-Q0981|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%8A%D9%85%D9%83%D9%86%20%D9%84%D8%AA%D9%88%D9%85%20%D8%A3%D9%86%20%D9%8A%D9%82%D9%88%D9%84%20%D8%B4%D9%8A%D8%A6%D8%A7.)
^ar-Q0981-answer

**ar-Q0982** — يمكن لتوم أن يقول شيئا.

Tom could've said something.

Why: Courtesy and certainty. [[Arabic#^ar-Q0982|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%8A%D9%85%D9%83%D9%86%20%D9%84%D8%AA%D9%88%D9%85%20%D8%A3%D9%86%20%D9%8A%D9%82%D9%88%D9%84%20%D8%B4%D9%8A%D8%A6%D8%A7.)
^ar-Q0982-answer

**ar-Q0983** — كان فاضل يعلم أنّ الشّرطة يمكن أن تصل في أية لحظة.

Fadil knew that police could show up at any second.

Why: Courtesy and certainty. [[Arabic#^ar-Q0983|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D8%A7%D9%86%20%D9%81%D8%A7%D8%B6%D9%84%20%D9%8A%D8%B9%D9%84%D9%85%20%D8%A3%D9%86%D9%91%20%D8%A7%D9%84%D8%B4%D9%91%D8%B1%D8%B7%D8%A9%20%D9%8A%D9%85%D9%83%D9%86%20%D8%A3%D9%86%20%D8%AA%D8%B5%D9%84%20%D9%81%D9%8A%20%D8%A3%D9%8A%D8%A9%20%D9%84%D8%AD%D8%B8%D8%A9.)
^ar-Q0983-answer

**ar-Q0984** — كان فاضل يعلم أنّ الشّرطة يمكن أن تصل في أية لحظة.

Fadil knew that police could show up at any second.

ربما limits certainty, يمكن expresses possibility/ability in suitable constructions, and يجب expresses obligation/necessity. Professional Arabic distinguishes a supported claim from a proposed explanation.

Why: Courtesy and certainty. [[Arabic#^ar-Q0984|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%83%D8%A7%D9%86%20%D9%81%D8%A7%D8%B6%D9%84%20%D9%8A%D8%B9%D9%84%D9%85%20%D8%A3%D9%86%D9%91%20%D8%A7%D9%84%D8%B4%D9%91%D8%B1%D8%B7%D8%A9%20%D9%8A%D9%85%D9%83%D9%86%20%D8%A3%D9%86%20%D8%AA%D8%B5%D9%84%20%D9%81%D9%8A%20%D8%A3%D9%8A%D8%A9%20%D9%84%D8%AD%D8%B8%D8%A9.)
^ar-Q0984-answer

**ar-Q0985** — يجب أن أشتري الطعام.

I need to buy the food.

Expected form: **يجب**

Why: Courtesy and certainty. [[Arabic#^ar-Q0985|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%8A%D8%AC%D8%A8%20%D8%A3%D9%86%20%D8%A3%D8%B4%D8%AA%D8%B1%D9%8A%20%D8%A7%D9%84%D8%B7%D8%B9%D8%A7%D9%85.)
^ar-Q0985-answer

**ar-Q0986** — يجب أن أشتري الطعام.

I need to buy the food.

Expected form: **يجب**

Why: Courtesy and certainty. [[Arabic#^ar-Q0986|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%8A%D8%AC%D8%A8%20%D8%A3%D9%86%20%D8%A3%D8%B4%D8%AA%D8%B1%D9%8A%20%D8%A7%D9%84%D8%B7%D8%B9%D8%A7%D9%85.)
^ar-Q0986-answer

**ar-Q0987** — المسؤولون يجب أن يأسيسوا لا تواصل وطيد بين الموظّفين.

Administrators need to establish close contact with employees.

Expected form: **يجب**

Why: Courtesy and certainty. [[Arabic#^ar-Q0987|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A7%D9%84%D9%85%D8%B3%D8%A4%D9%88%D9%84%D9%88%D9%86%20%D9%8A%D8%AC%D8%A8%20%D8%A3%D9%86%20%D9%8A%D8%A3%D8%B3%D9%8A%D8%B3%D9%88%D8%A7%20%D9%84%D8%A7%20%D8%AA%D9%88%D8%A7%D8%B5%D9%84%20%D9%88%D8%B7%D9%8A%D8%AF%20%D8%A8%D9%8A%D9%86%20%D8%A7%D9%84%D9%85%D9%88%D8%B8%D9%91%D9%81%D9%8A%D9%86.)
^ar-Q0987-answer

**ar-Q0988** — المسؤولون يجب أن يأسيسوا لا تواصل وطيد بين الموظّفين.

Administrators need to establish close contact with employees.

Why: Courtesy and certainty. [[Arabic#^ar-Q0988|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D8%A7%D9%84%D9%85%D8%B3%D8%A4%D9%88%D9%84%D9%88%D9%86%20%D9%8A%D8%AC%D8%A8%20%D8%A3%D9%86%20%D9%8A%D8%A3%D8%B3%D9%8A%D8%B3%D9%88%D8%A7%20%D9%84%D8%A7%20%D8%AA%D9%88%D8%A7%D8%B5%D9%84%20%D9%88%D8%B7%D9%8A%D8%AF%20%D8%A8%D9%8A%D9%86%20%D8%A7%D9%84%D9%85%D9%88%D8%B8%D9%91%D9%81%D9%8A%D9%86.)
^ar-Q0988-answer

**ar-Q0989** — لا يمكن للحجارة أن تسبح.

Stones don't swim.

Why: Courtesy and certainty. [[Arabic#^ar-Q0989|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D8%A7%20%D9%8A%D9%85%D9%83%D9%86%20%D9%84%D9%84%D8%AD%D8%AC%D8%A7%D8%B1%D8%A9%20%D8%A3%D9%86%20%D8%AA%D8%B3%D8%A8%D8%AD.)
^ar-Q0989-answer

**ar-Q0990** — لا يمكن للحجارة أن تسبح.

Stones don't swim.

ربما limits certainty, يمكن expresses possibility/ability in suitable constructions, and يجب expresses obligation/necessity. Professional Arabic distinguishes a supported claim from a proposed explanation.

Why: Courtesy and certainty. [[Arabic#^ar-Q0990|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%84%D8%A7%20%D9%8A%D9%85%D9%83%D9%86%20%D9%84%D9%84%D8%AD%D8%AC%D8%A7%D8%B1%D8%A9%20%D8%A3%D9%86%20%D8%AA%D8%B3%D8%A8%D8%AD.)
^ar-Q0990-answer

**ar-Q0991** — يمكن أن يكون فاضل قد مات.

Fadil might be dead.

Expected form: **يمكن**

Why: Courtesy and certainty. [[Arabic#^ar-Q0991|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%8A%D9%85%D9%83%D9%86%20%D8%A3%D9%86%20%D9%8A%D9%83%D9%88%D9%86%20%D9%81%D8%A7%D8%B6%D9%84%20%D9%82%D8%AF%20%D9%85%D8%A7%D8%AA.)
^ar-Q0991-answer

**ar-Q0992** — يمكن أن يكون فاضل قد مات.

Fadil might be dead.

Expected form: **يمكن**

Why: Courtesy and certainty. [[Arabic#^ar-Q0992|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%8A%D9%85%D9%83%D9%86%20%D8%A3%D9%86%20%D9%8A%D9%83%D9%88%D9%86%20%D9%81%D8%A7%D8%B6%D9%84%20%D9%82%D8%AF%20%D9%85%D8%A7%D8%AA.)
^ar-Q0992-answer

**ar-Q0993** — من فضلك أرسلها عن طريق الفاكس.

Please send it to me by fax.

Expected form: **من فضلك**

Why: Courtesy and certainty. [[Arabic#^ar-Q0993|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D9%86%20%D9%81%D8%B6%D9%84%D9%83%20%D8%A3%D8%B1%D8%B3%D9%84%D9%87%D8%A7%20%D8%B9%D9%86%20%D8%B7%D8%B1%D9%8A%D9%82%20%D8%A7%D9%84%D9%81%D8%A7%D9%83%D8%B3.)
^ar-Q0993-answer

**ar-Q0994** — من فضلك أرسلها عن طريق الفاكس.

Please send it to me by fax.

Why: Courtesy and certainty. [[Arabic#^ar-Q0994|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D9%86%20%D9%81%D8%B6%D9%84%D9%83%20%D8%A3%D8%B1%D8%B3%D9%84%D9%87%D8%A7%20%D8%B9%D9%86%20%D8%B7%D8%B1%D9%8A%D9%82%20%D8%A7%D9%84%D9%81%D8%A7%D9%83%D8%B3.)
^ar-Q0994-answer

**ar-Q0995** — من فضلك اتركني وحدي.

Please leave me alone.

Why: Courtesy and certainty. [[Arabic#^ar-Q0995|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D9%86%20%D9%81%D8%B6%D9%84%D9%83%20%D8%A7%D8%AA%D8%B1%D9%83%D9%86%D9%8A%20%D9%88%D8%AD%D8%AF%D9%8A.)
^ar-Q0995-answer

**ar-Q0996** — من فضلك اتركني وحدي.

Please leave me alone.

ربما limits certainty, يمكن expresses possibility/ability in suitable constructions, and يجب expresses obligation/necessity. Professional Arabic distinguishes a supported claim from a proposed explanation.

Why: Courtesy and certainty. [[Arabic#^ar-Q0996|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D9%86%20%D9%81%D8%B6%D9%84%D9%83%20%D8%A7%D8%AA%D8%B1%D9%83%D9%86%D9%8A%20%D9%88%D8%AD%D8%AF%D9%8A.)
^ar-Q0996-answer

**ar-Q0997** — يمكن عمله، لكنه ليس سهلا.

It's doable, but not easy.

Expected form: **يمكن**

Why: Courtesy and certainty. [[Arabic#^ar-Q0997|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%8A%D9%85%D9%83%D9%86%20%D8%B9%D9%85%D9%84%D9%87%D8%8C%20%D9%84%D9%83%D9%86%D9%87%20%D9%84%D9%8A%D8%B3%20%D8%B3%D9%87%D9%84%D8%A7.)
^ar-Q0997-answer

**ar-Q0998** — يمكن عمله، لكنه ليس سهلا.

It's doable, but not easy.

Expected form: **يمكن**

Why: Courtesy and certainty. [[Arabic#^ar-Q0998|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%8A%D9%85%D9%83%D9%86%20%D8%B9%D9%85%D9%84%D9%87%D8%8C%20%D9%84%D9%83%D9%86%D9%87%20%D9%84%D9%8A%D8%B3%20%D8%B3%D9%87%D9%84%D8%A7.)
^ar-Q0998-answer

**ar-Q0999** — من فضلك لا تبكِ.

Please don't cry.

Expected form: **من فضلك**

Why: Courtesy and certainty. [[Arabic#^ar-Q0999|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D9%86%20%D9%81%D8%B6%D9%84%D9%83%20%D9%84%D8%A7%20%D8%AA%D8%A8%D9%83%D9%90.)
^ar-Q0999-answer

**ar-Q1000** — من فضلك لا تبكِ.

Please don't cry.

Why: Courtesy and certainty. [[Arabic#^ar-Q1000|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ara&query=%D9%85%D9%86%20%D9%81%D8%B6%D9%84%D9%83%20%D9%84%D8%A7%20%D8%AA%D8%A8%D9%83%D9%90.)
^ar-Q1000-answer


## Read and speak

Read the native sentence first, identify its predicate and one grammar form, then check the translation. Say it aloud and change one detail.

### Learning with a clear purpose

أنا أتعلم لغة جديدة. أقرأ كل يوم نصًا قصيرًا وأستمع إلى أمثلة واضحة. أكتب كلمات مفيدة في دفتر. عندما أرتكب خطأ، أراجع القاعدة وأحاول مرة أخرى. هدفي هو فهم الناس والتعبير عن أفكاري بوضوح.

I am learning a new language. Each day, I read a short text and listen to clear examples. I write useful words in a notebook. When I make a mistake, I check the rule and try again. My goal is to understand people and express my ideas clearly.

![[Resources/Audio/ar/Reading passage.mp3]]

**لا شيئَ مثالي.**

Nothing's perfect.

**صديق في اليد خير من اثنين على الشجرة!**

A friend in hand is worth two in the bush!

**تسلّقت ليلى السّلّم.**

Layla climbed the ladder.

**لقد أضفت فلفلاً أكثر من اللازم.**

You put in too much pepper.

**إنني سعيد بلقائك.**

I'm very glad to meet you.

**هذا أغبى ما قُلتُه على الإطلاق.**

That's the stupidest thing I've ever said.

**اتهمته الشرطة بالقتل.**

The police accused him of murder.

**أنا آسف، ولكن هذا لم يعد متاحاً.**

I'm sorry, but it's no longer available.

**دفعت ليلى بسامي إلى الحائط.**

Layla pushed Sami to the wall.

**لم يتزوج سامي قطّ.**

Sami never married.

**يبدوا لي أنه يعلم السر**

I have the impression that he knows the secret.

**يبدو المعطف الأحمر جميلاً عليك.**

That red sweater looks good on you.

**حتى لو سارت الأمور على ما يرام، ما زلنا غير قادرين على الانتهاء قبل السبت.**

Even if all goes well, we still can't finish before Saturday.

**بدت قبعتها مضحكة جداً.**

Her hat looked very funny.

**كل شخص لديه كلاً من نقاط الضعف والقوة.**

Everyone has both strong and weak points.

## Professional writing

Write an introduction, a polite request, an explanation of a finding, a summary of a passage and a tactful disagreement. Use the professional/advanced lessons for models.

## PDF edition

[[Resources/PDFs/Arabic.pdf|Open the complete printable book]]


<!-- individual-letter-audio -->
## Hear each letter separately

Play each letter’s own synthetic recording. English has separate US and UK models.

### ا · أَلِف

![[Resources/Audio/ar/Letters/001.mp3]]

### ب · بَاء

![[Resources/Audio/ar/Letters/002.mp3]]

### ت · تَاء

![[Resources/Audio/ar/Letters/003.mp3]]

### ث · ثَاء

![[Resources/Audio/ar/Letters/004.mp3]]

### ج · جِيم

![[Resources/Audio/ar/Letters/005.mp3]]

### ح · حَاء

![[Resources/Audio/ar/Letters/006.mp3]]

### خ · خَاء

![[Resources/Audio/ar/Letters/007.mp3]]

### د · دَال

![[Resources/Audio/ar/Letters/008.mp3]]

### ذ · ذَال

![[Resources/Audio/ar/Letters/009.mp3]]

### ر · رَاء

![[Resources/Audio/ar/Letters/010.mp3]]

### ز · زَاي

![[Resources/Audio/ar/Letters/011.mp3]]

### س · سِين

![[Resources/Audio/ar/Letters/012.mp3]]

### ش · شِين

![[Resources/Audio/ar/Letters/013.mp3]]

### ص · صَاد

![[Resources/Audio/ar/Letters/014.mp3]]

### ض · ضَاد

![[Resources/Audio/ar/Letters/015.mp3]]

### ط · طَاء

![[Resources/Audio/ar/Letters/016.mp3]]

### ظ · ظَاء

![[Resources/Audio/ar/Letters/017.mp3]]

### ع · عَيْن

![[Resources/Audio/ar/Letters/018.mp3]]

### غ · غَيْن

![[Resources/Audio/ar/Letters/019.mp3]]

### ف · فَاء

![[Resources/Audio/ar/Letters/020.mp3]]

### ق · قَاف

![[Resources/Audio/ar/Letters/021.mp3]]

### ك · كَاف

![[Resources/Audio/ar/Letters/022.mp3]]

### ل · لَام

![[Resources/Audio/ar/Letters/023.mp3]]

### م · مِيم

![[Resources/Audio/ar/Letters/024.mp3]]

### ن · نُون

![[Resources/Audio/ar/Letters/025.mp3]]

### ه · هَاء

![[Resources/Audio/ar/Letters/026.mp3]]

### و · وَاو

![[Resources/Audio/ar/Letters/027.mp3]]

### ي · يَاء

![[Resources/Audio/ar/Letters/028.mp3]]
<!-- /individual-letter-audio -->
