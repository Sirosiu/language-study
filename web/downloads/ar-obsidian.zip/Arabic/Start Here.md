# Arabic study

[[Arabic|Open the complete Arabic course note]]

Audio and the printable PDF are in Resources. This vault contains one language.

[[Sources and licenses]]
