# Turkish

Professional ambition - C1-oriented study

Everything for this language is in this note. Open a rule, read its examples and follow its practice link. Answers stay in this same note.

[[Start Here|All languages]] · [[Sources and licenses|Sources]]

## Start reading

### alfabe

| Written form | Name / reading | Related forms |
|---|---|---|
| A a | a  |  ·  ·  |
| B b | be  |  ·  ·  |
| C c | ce  |  ·  ·  |
| Ç ç | çe  |  ·  ·  |
| D d | de  |  ·  ·  |
| E e | e  |  ·  ·  |
| F f | fe  |  ·  ·  |
| G g | ge  |  ·  ·  |
| Ğ ğ | yumuşak ge  |  ·  ·  |
| H h | he  |  ·  ·  |
| I ı | ı  |  ·  ·  |
| İ i | i  |  ·  ·  |
| J j | je  |  ·  ·  |
| K k | ke  |  ·  ·  |
| L l | le  |  ·  ·  |
| M m | me  |  ·  ·  |
| N n | ne  |  ·  ·  |
| O o | o  |  ·  ·  |
| Ö ö | ö  |  ·  ·  |
| P p | pe  |  ·  ·  |
| R r | re  |  ·  ·  |
| S s | se  |  ·  ·  |
| Ş ş | şe  |  ·  ·  |
| T t | te  |  ·  ·  |
| U u | u  |  ·  ·  |
| Ü ü | ü  |  ·  ·  |
| V v | ve  |  ·  ·  |
| Y y | ye  |  ·  ·  |
| Z z | ze  |  ·  ·  |

![[Resources/Audio/tr/Script and first phrases.mp3]]

The player above is synthetic speech. Word tracks below work offline.

### All 29 letters

Turkish distinguishes dotless ı from dotted i, including capitals I and İ. Q, W and X are not core Turkish letters. c is /dʒ/, ç /tʃ/, ş /ʃ/, j /ʒ/. ğ generally modifies adjoining vowels rather than having one fixed consonant sound.

### Vowel harmony

Back vowels a/ı/o/u contrast with front e/i/ö/ü. A two-way suffix alternates a/e; a four-way suffix often alternates ı/i/u/ü, following backness and rounding. Harmony is a productive guide, with lexical exceptions.

### Hear stress and consonant changes

Stress is often final but place names, loans and some suffixes differ. A final voiceless consonant can select a voiceless suffix consonant: kitapta. Some stems voice before a vowel suffix: kitap → kitabı.

### Stack suffixes in order

ev → evler → evlerimiz → evlerimizde = house → houses → our houses → in our houses. Plural, possession and case follow a fixed sequence.

### Apply harmony

ev + ler → evler; kitap + lar → kitaplar. ev + de → evde; kitap + ta → kitapta. Both vowel and consonant harmony matter.

### Build a predicate

Türkçe öğreniyorum. = I am learning Turkish. Türkçe öğrenmiyorum. = I am not learning Turkish. Negation, tense/aspect and person are expressed within the verb.

**Merhaba.**

Hello.

**Türkçe öğreniyorum.**

I am learning Turkish.

**Tekrar eder misiniz?**

Could you repeat?

**Bu kelime ne demek?**

What does this word mean?

### Grammar terms in plain English

**Noun** — A word naming a person, thing or idea: student, book, freedom.

**Verb** — A word describing an action or state: read, know, be.

**Subject** — The participant linked to the main verb’s subject pattern. In The student reads a book, the student is the subject.

**Object** — A participant selected by a verb. In The student reads a book, a book is the direct object.

**Agreement** — One word changes to match another, for example an adjective matching a noun’s gender and number.

**Case** — A noun/pronoun form marking its relationship in a sentence. Cases can mark subjects, objects, possession or relations usually expressed by English prepositions.

**Gender** — A grammatical noun class. It does not always describe the sex of a person or any physical property.

**Tense** — A verb system that relates a situation to a time, often past or non-past.

**Aspect** — How a situation is viewed: unfolding, completed, habitual, experienced or in a resulting state.

**Infinitive** — A non-finite verb form often used for a dictionary entry or a complement. It does not by itself give the ordinary person/tense pattern.

**Participle** — A verb-derived form used in compound predicates or as a modifier; its exact function depends on the language and construction.

**Clause** — A unit organised around a predicate. One sentence can contain several clauses.

**Register** — Language choices suited to a situation: casual conversation, polite requests, academic writing or another context.

## Grammar, examples and practice

### Vowel harmony and noun morphology

Many suffixes use two-way or four-way vowel harmony. Back/front and rounded/unrounded vowels guide selection. Evler and kitaplar show plural harmony. Accusative often marks a specific/identifiable direct object; an unmarked object can be indefinite. Possession and case combine in an ordered sequence. Buffer consonants and changes such as kitap/kitabı require lexical pattern learning.

**kitap / kitabı**

book / the book as a specific object Consonant alternation and accusative marking.

**evlerimizde**

in our houses Ev + plural + first-person plural possession + locative.

#### Pronouns

Subject pronouns can be omitted when verbal endings identify the subject. O does not distinguish he/she/it. Case suffixes create object and other pronoun forms with some irregular stems.

**O, ekmeği yedi.**

She ate the bread.

**Ben McDonald's'ta için çalışıyorum.**

I work for McDonald's.

![[Resources/Audio/tr/Rule 01.mp3]]

[[Turkish#^tr-Q0001|Practise this rule (50 questions)]]

#### Demonstratives

Bu/şu/o encode distinctions of reference and distance. Their pronoun inflections use a buffer n in relevant forms. Context, not English this/that alone, determines the best choice.

**Neden herkes için yeterli yiyeceğimiz yok ? Bu öğleden sonra alışverişe gittiğinizi sanıyordum.**

Why don't we have enough food for everyone? I thought you went shopping this afternoon.

**Bu işi yapabiliriz.**

We can make this work.

![[Resources/Audio/tr/Rule 02.mp3]]

[[Turkish#^tr-Q0051|Practise this rule (50 questions)]]

#### Plural nouns

Plural -lar/-ler follows two-way vowel harmony. Numerals commonly precede an unmarked counted noun, so do not add a plural suffix automatically after every number.

**İnsanlar Tom'a benzediğimi söylüyorlar.**

People say that I look like Tom.

**Arıcılar balı toplamak için peteği kaldırdılar.**

Beekeepers remove the honeycomb to collect the honey.

![[Resources/Audio/tr/Rule 03.mp3]]

[[Turkish#^tr-Q0101|Practise this rule (50 questions)]]

<details><summary>Segment evlerimizde.</summary>

Ev-ler-imiz-de: house-plural-our-in.

</details>

<details><summary>Why should every direct object not automatically receive accusative?</summary>

Specificity/identifiability and construction determine marking; bare indefinite objects occur.

</details>

### Verb tense, evidentiality and negation

Turkish distinguishes forms including -DI past and -mIş, often associated with inference or reported information. Their interpretation depends on context and narrative conventions. Progressive -(I)yor, future -(y)AcAk and aorist forms have distinct uses. Negation is usually built into the verb through -mA before other suffixes. Person marking differs across tense patterns.

**Raporu okudum.**

I read the report. Specific object plus -DI past and first-person marking.

**Raporu yazmış.**

Apparently/he or she has written the report. -mIş can present reported/inferred information; context determines nuance.

#### Progressive verbs

The -Iyor construction marks a progressive/current pattern and takes personal endings. Vowel interactions can change the stem surface. Learn negative -mIyor separately from a mechanical -ma + ıyor spelling.

**Ödülü kimin aldığını biliyorum.**

I know who got the prize.

**Hâlâ eğleniyor musunuz?**

Are you still having fun?

![[Resources/Audio/tr/Rule 09.mp3]]

[[Turkish#^tr-Q0401|Practise this rule (50 questions)]]

#### Past forms

The -DI past uses vowel/consonant harmony and personal endings. Its evidential orientation contrasts with common -mIş forms, though discourse can refine the contrast.

**Jane kızgın bir jest yaptı.**

Jane made an angry gesture.

**Buraya otuz dakika önce geldim.**

I got here about thirty minutes ago.

![[Resources/Audio/tr/Rule 10.mp3]]

[[Turkish#^tr-Q0451|Practise this rule (50 questions)]]

#### Reported/evidential forms

The -mIş series often presents information as inferred, discovered or reported. It is not exclusively hearsay. Possessive and verbal morphology may add further endings.

**Yağmur yağmış olsaydı gitmezdik.**

We wouldn't have gone if it had rained.

**Sen muhtemelen daha önce bu parka hiç gelmemiş Boston'daki tek kişisin.**

You're probably the only person in Boston who has never been to this park before.

![[Resources/Audio/tr/Rule 11.mp3]]

[[Turkish#^tr-Q0501|Practise this rule (50 questions)]]

#### Future forms

Future -AcAk harmonises and combines with person endings. Intervocalic k can become ğ before a vowel suffix. The same form can also participate in a nominal or adjective construction.

**Annesi çalışmaya devam edecek.**

Her mother will continue to work.

**Tom asla gitmene izin vermeyecek.**

Tom will never allow you to go.

![[Resources/Audio/tr/Rule 12.mp3]]

[[Turkish#^tr-Q0551|Practise this rule (50 questions)]]

#### Negation and absence

Değil negates many non-verbal predicates; yok expresses absence; hayır is a response no. Verbal negation usually belongs inside the verb. Hiç often works with a negative construction.

**Tom çok ağzı sıkı değil.**

Tom isn't very secretive.

**Tüm nedenimizi izlemek için yeterli gücümüz yok.**

We do not have enough strength to follow our reason completely.

![[Resources/Audio/tr/Rule 13.mp3]]

[[Turkish#^tr-Q0601|Practise this rule (50 questions)]]

#### Question particle

The question particle is written separately and follows harmony. It attaches in position to the focused element; personal endings can follow it. A question word does not normally need an extra question particle.

**Kabak çorbasını sever misin?**

Do you like squash soup?

**Hala ikna olmadınız mı?**

Are you still not convinced?

![[Resources/Audio/tr/Rule 14.mp3]]

[[Turkish#^tr-Q0651|Practise this rule (50 questions)]]

<details><summary>Is -mIş merely the English perfect tense?</summary>

No. Evidential and narrative meanings can be central.

</details>

<details><summary>Translate I am not reading.</summary>

Okumuyorum. Negative vowel interaction occurs before progressive and person suffixes.

</details>

### Cases, postpositions and predicates

Dative -(y)A, locative -DA, ablative -DAn and genitive -(n)In express governed relationships. Postpositions can require a particular case. Nominal predicates take person marking or copular constructions without an English-style verb in every present clause. Değil negates many nominal predicates; yok denies existence or possession in suitable patterns.

**Bu yöntem uygun değil.**

This method is not suitable. Nominal/adjectival predicate negated by değil.

**Bu konuda bilgiye ihtiyacım var.**

I need information on this topic. A possession/need construction rather than English subject-verb mapping.

#### Location suffix

Locative -DA combines vowel harmony and consonant assimilation. The capital notation stands for alternatives, not a written capital suffix. Lexical words can end similarly; inspect their stem.

**Bütün onları yapmak zorunda mıyız?**

Do we have to do all that?

**Akşam yemeğinde ne yemek istersiniz?**

What would you like to have for dinner?

![[Resources/Audio/tr/Rule 04.mp3]]

[[Turkish#^tr-Q0151|Practise this rule (50 questions)]]

#### Source suffix

Ablative -DAn expresses many source/from relations and governed complements. A final voiceless stem consonant commonly selects t. Meaning depends on the governing phrase.

**Sabahtan beri öksürüyorum.**

I've been coughing since this morning.

**Krizlerden mutlaka nemalanmaya bak.**

Never let a crisis go to waste.

![[Resources/Audio/tr/Rule 05.mp3]]

[[Turkish#^tr-Q0201|Practise this rule (50 questions)]]

#### Accusative objects

Accusative commonly marks a specific/definite direct object. The suffix follows four-way harmony with a buffer y after a vowel in applicable nouns. Bare objects have different interpretations and positions.

**Onları bulmak için sana ihtiyacım var.**

I need you to find them.

**Beni takip etmemeliydin.**

You shouldn't have followed me.

![[Resources/Audio/tr/Rule 06.mp3]]

[[Turkish#^tr-Q0251|Practise this rule (50 questions)]]

#### Dative direction

Dative -A marks many destinations and recipients. Ben/sen have irregular bana/sana forms. English to maps to several Turkish constructions, so learn verb government.

**Bir daha bana asla dokunma.**

Don't you ever touch me again.

**Bana dinlenmek için zaman verin.**

Give me time to relax.

![[Resources/Audio/tr/Rule 07.mp3]]

[[Turkish#^tr-Q0301|Practise this rule (50 questions)]]

#### Possession and genitive

A genitive possessor commonly pairs with a possessive suffix on the possessed noun. Benim kitabım means my book. A possessive relationship is not expressed just by juxtaposing two unchanged nouns.

**Onun tekrar olmasına izin vermeyeceğine güveniyorum.**

I trust you won't let that happen again.

**Benim bir atım var.**

I own a horse.

![[Resources/Audio/tr/Rule 08.mp3]]

[[Turkish#^tr-Q0351|Practise this rule (50 questions)]]

#### Question words

Location, destination and source have different question forms. Question words take relevant case morphology. Context and focus govern their placement.

**Oo! Ne büyük bir kutu!**

Wow! What a big box!

**Ne zaman Boston'a gitsek Tom'la kalırız.**

We stay with Tom whenever we go to Boston.

![[Resources/Audio/tr/Rule 15.mp3]]

[[Turkish#^tr-Q0701|Practise this rule (50 questions)]]

#### Postpositions

Postpositions follow a complement and may require a particular case. Bana göre uses dative; benden sonra uses ablative. Learn the whole governed phrase.

**Diğer üç kişi özel övgü için seçildi.**

Three other people were singled out for special praise.

**Bugün için işimiz bitti.**

We're done for today.

![[Resources/Audio/tr/Rule 16.mp3]]

[[Turkish#^tr-Q0751|Practise this rule (50 questions)]]

<details><summary>Distinguish değil and yok.</summary>

Değil denies a predicate relation; yok states absence/nonexistence in its relevant construction.

</details>

<details><summary>What belongs with a postposition entry?</summary>

Required case, meaning, usage and a full example.

</details>

### Participles and nominalised clauses

Turkish frequently places a clause-like modifier before its noun. -(y)An commonly forms subject-related modifiers, while -DIK and -(y)AcAk with possessive marking support other clause relations. Okuduğum kitap means the book I read; the first-person relationship is inside the modifier. Nominalised clauses can take case and act as arguments. Long words must be segmented without assuming every suffix keeps one constant English meaning.

**okuduğum kitap**

the book I read Participial/nominal modifier with first-person possessive marking.

**geldiğini biliyorum**

I know that he/she came/has come Nominalised subordinate proposition as object.

#### Conditions

Conditional suffix -sA and related forms encode different time and reality relationships. Eğer can introduce a condition but is not necessary in every conditional sentence.

**Eğer isteseydi Tom Mary'ye yardım edebilirdi.**

Tom could help Mary if he wanted to.

**Eğer Tom Mary'ye yardım edebiliyorsa, neden John'a da yardım edemiyor?**

If Tom can help Mary, why can't he help John, too?

![[Resources/Audio/tr/Rule 17.mp3]]

[[Turkish#^tr-Q0801|Practise this rule (50 questions)]]

#### Clause linking

Connectors mark cause, contrast and coordination. Turkish also uses suffix-based non-finite clauses extensively; do not assume every English connector needs a separate Turkish word.

**Tom ve arkadaşı plastik kılıçlarla düello ediyorlardı.**

Tom and his friend were duelling with plastic swords.

**Tom ve Mary birbiriyle evliydi.**

Tom and Mary used to be married to each other.

![[Resources/Audio/tr/Rule 18.mp3]]

[[Turkish#^tr-Q0851|Practise this rule (50 questions)]]

#### Participles and nominal clauses

Participles modify nouns before them; nominalised clauses can take possessive and case endings. The form records relationships that English often expresses in a separate relative/content clause.

**Tom'un erkek arkadaşın olduğunu sandım.**

I assumed Tom was your boyfriend.

**Daha fazla zamana ihtiyacın olduğunu söyledin.**

You said you needed more time.

![[Resources/Audio/tr/Rule 19.mp3]]

[[Turkish#^tr-Q0901|Practise this rule (50 questions)]]

<details><summary>Locate the head of okuduğum kitap.</summary>

Kitap. The modifier precedes it.

</details>

<details><summary>Why does geldiğini need context for person interpretation?</summary>

Pronouns are often omitted, and morphology must be read with the discourse and nominalisation pattern.

</details>

### Professional reading and polite requests

Teaching passage: Sonuçlar iki etken arasında bir ilişki olduğunu gösteriyor. Ancak bir etkenin diğerine neden olduğunu kanıtlamıyor. Sonucu değerlendirirken araştırmanın koşullarını dikkate almak gerekir.
Translation: The results show that there is a relationship between two factors. However, they do not prove that one causes the other. The study conditions must be considered when evaluating the conclusion.

**Bu noktayı açıklayabilir misiniz?**

Could you explain this point? Ability plus polite plural/person question pattern.

**Bu sonuç kesin değildir.**

This conclusion is not certain. Formal nominal negation.

#### Ability, necessity and courtesy

Lütfen marks a polite request; belki limits certainty; gerek/lazım often express necessity. Daha/en participate in comparison and degree. Use the full construction to identify their role.

**Lütfen dürüst davran.**

Please behave honestly.

**O, takımımızdaki en değerli oyuncudur.**

He is the most valuable player in our team.

![[Resources/Audio/tr/Rule 20.mp3]]

[[Turkish#^tr-Q0951|Practise this rule (50 questions)]]

<details><summary>What does olduğunu do in the passage?</summary>

It nominalises a subordinate proposition so it can be the object of showing or proving.

</details>

<details><summary>Write a professional summary.</summary>

Preserve evidential strength, suffix harmony and clause relationships.

</details>

## Word bank and recordings

1,000 study entries, based on dictionary selections and authored teaching glosses. Learn a word in a phrase; consult the linked entry for additional senses.

<details><summary>Words 1–50</summary>

![[Resources/Audio/tr/Words 0001-0050.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [ve](https://en.wiktionary.org/wiki/ve#Turkish) | and | /ve/ · conj |
| [bir](https://en.wiktionary.org/wiki/bir#Turkish) | one; a/an | /bir/ · det |
| [bu](https://en.wiktionary.org/wiki/bu#Turkish) | this | /bu/ · pron |
| [de](https://en.wiktionary.org/wiki/de#Turkish) | also; too (written separately) | /dɛ/ · particle |
| [da](https://en.wiktionary.org/wiki/da#Turkish) | also; too (written separately) | /da/ · particle |
| [ile](https://en.wiktionary.org/wiki/ile#Turkish) | with; and in some uses | /iˈle/ · postp |
| [ne](https://en.wiktionary.org/wiki/ne#Turkish) | what | /nɛ/ · pron |
| [en](https://en.wiktionary.org/wiki/en#Turkish) | most; width in another sense | /en/ · adv |
| [gibi](https://en.wiktionary.org/wiki/gibi#Turkish) | like, similar to | /ɡiˈbi/ · postp |
| [her](https://en.wiktionary.org/wiki/her#Turkish) | every | /ˈheɾ/ · det |
| [kadar](https://en.wiktionary.org/wiki/kadar#Turkish) | Equal in amount or quantity; as much as. | /kɑˈdɑɾ/ · postp |
| [o](https://en.wiktionary.org/wiki/o#Turkish) | he, she, it | /o/ · pron |
| [ben](https://en.wiktionary.org/wiki/ben#Turkish) | I, me | /ˈben/ · pron |
| [var](https://en.wiktionary.org/wiki/var#Turkish) | there is, there are (not a verb) | /vɑɾ/ · adj |
| [ama](https://en.wiktionary.org/wiki/ama#Turkish) | but; however | /ˈa.ma/ · conj |
| [ki](https://en.wiktionary.org/wiki/ki#Turkish) | so that, so | /ci/ · conj |
| [ya](https://en.wiktionary.org/wiki/ya#Turkish) | Expression of surprise or confusion. | /ja/ · intj |
| [sen](https://en.wiktionary.org/wiki/sen#Turkish) | you (singular, informal), thou | /sæn/ · pron |
| [büyük](https://en.wiktionary.org/wiki/b%C3%BCy%C3%BCk#Turkish) | big, grand, large | [byˈjyc] · adj |
| [yeni](https://en.wiktionary.org/wiki/yeni#Turkish) | new | /jeˈni/ · adj |
| [güzel](https://en.wiktionary.org/wiki/g%C3%BCzel#Turkish) | beautiful | /ɟyˈzel/ · adj |
| [zaman](https://en.wiktionary.org/wiki/zaman#Turkish) | time (progression into the future with the passing of present and past events) | /zaˈman/ · noun |
| [ilk](https://en.wiktionary.org/wiki/ilk#Turkish) | first | /ˈilc/ · adj |
| [iki](https://en.wiktionary.org/wiki/iki#Turkish) | two | /iˈci/ · num |
| [mi](https://en.wiktionary.org/wiki/mi#Turkish) | Used to form interrogatives. |  · particle |
| [bile](https://en.wiktionary.org/wiki/bile#Turkish) | even | /biˈle/ · conj |
| [şey](https://en.wiktionary.org/wiki/%C5%9Fey#Turkish) | thing | /ˈʃej/ · noun |
| [benim](https://en.wiktionary.org/wiki/benim#Turkish) | I am me | /bé.nim/ · pron |
| [son](https://en.wiktionary.org/wiki/son#Turkish) | last, final | /ˈson/ · adj |
| [tek](https://en.wiktionary.org/wiki/tek#Turkish) | single, sole, only | /ˈtec/ · adj |
| [gün](https://en.wiktionary.org/wiki/g%C3%BCn#Turkish) | day | /ˈɟyn/ · noun |
| [yer](https://en.wiktionary.org/wiki/yer#Turkish) | place, location | /ˈjeɾ/ · noun |
| [önce](https://en.wiktionary.org/wiki/%C3%B6nce#Turkish) | before | [øn.d͡ʒe] · adv |
| [beni](https://en.wiktionary.org/wiki/beni#Turkish) | me | /beni/ · pron |
| [Türk](https://en.wiktionary.org/wiki/T%C3%BCrk#Turkish) | Turk (ethnically Turkish person) | /ˈtyɾc/ · noun |
| [bana](https://en.wiktionary.org/wiki/bana#Turkish) | me, to me, for me (dative of ben) |  · pron |
| [biz](https://en.wiktionary.org/wiki/biz#Turkish) | we (subject form) | /biz/ · pron |
| [şu](https://en.wiktionary.org/wiki/%C5%9Fu#Turkish) | that, that over there | /ʃu/ · det |
| [sana](https://en.wiktionary.org/wiki/sana#Turkish) | you, to you, for you (dative of sen) |  · pron |
| [telaffuz](https://en.wiktionary.org/wiki/telaffuz) | pronunciation |  · noun |
| [yıl](https://en.wiktionary.org/wiki/y%C4%B1l#Turkish) | year | /ˈjɯɫ/ · noun |
| [olmak](https://en.wiktionary.org/wiki/olmak#Turkish) | to become, come to exist, come into being | /oɫˈmak/ · verb |
| [biri](https://en.wiktionary.org/wiki/biri#Turkish) | someone |  · pron |
| [iş](https://en.wiktionary.org/wiki/i%C5%9F#Turkish) | work, task, deed | /iʃ/ · noun |
| [dünya](https://en.wiktionary.org/wiki/d%C3%BCnya#Turkish) | world | /dyn.jaː/ · noun |
| [genel](https://en.wiktionary.org/wiki/genel#Turkish) | general, broad, universal | /ɟeˈnel/ · adj |
| [adam](https://en.wiktionary.org/wiki/adam#Turkish) | human | /aˈdam/ · noun |
| [siz](https://en.wiktionary.org/wiki/siz#Turkish) | you (plural subject pronoun: the group being addressed); you guys, y'all, yous, youse | /siz/ · pron |
| [tam](https://en.wiktionary.org/wiki/tam#Turkish) | exactly | /tam/ · adv |
| [saat](https://en.wiktionary.org/wiki/saat#Turkish) | time (referring the type of time that one reads from a watch or a clock, it does not have the same meaning as zaman) | /saˈatʲ/ · noun |

</details>

<details><summary>Words 51–100</summary>

![[Resources/Audio/tr/Words 0051-0100.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [az](https://en.wiktionary.org/wiki/az#Turkish) | few, little | /ˈaz/ · det |
| [küçük](https://en.wiktionary.org/wiki/k%C3%BC%C3%A7%C3%BCk#Turkish) | small, little | /cyˈtʃyc/ · adj |
| [alan](https://en.wiktionary.org/wiki/alan#Turkish) | area, square as for place. | /ɑˈɫɑn/ · noun |
| [geri](https://en.wiktionary.org/wiki/geri#Turkish) | back | [ɟeɾi] · adj |
| [insan](https://en.wiktionary.org/wiki/insan#Turkish) | human | /inˈsan/ · noun |
| [üç](https://en.wiktionary.org/wiki/%C3%BC%C3%A7#Turkish) | three | /ˈyt͡ʃ/ · num |
| [gece](https://en.wiktionary.org/wiki/gece#Turkish) | night | [ɟe̞ˈd͡ʒɛ] · noun |
| [hem](https://en.wiktionary.org/wiki/hem#Turkish) | and also | /hæm/ · adv |
| [eski](https://en.wiktionary.org/wiki/eski#Turkish) | old (for objects) | [esˈki] · adj |
| [kabul](https://en.wiktionary.org/wiki/kabul#Turkish) | acceptation | /kɑˈbul/ · noun |
| [özel](https://en.wiktionary.org/wiki/%C3%B6zel#Turkish) | special | /øˈzel/ · adj |
| [evet](https://en.wiktionary.org/wiki/evet#Turkish) | yes | /ˈe.vet/ · intj |
| [kelime](https://en.wiktionary.org/wiki/kelime) | word |  · noun |
| [kim](https://en.wiktionary.org/wiki/kim#Turkish) | who | /ˈcim/ · pron |
| [mu](https://en.wiktionary.org/wiki/mu#Turkish) | Used to form interrogatives. |  · particle |
| [hep](https://en.wiktionary.org/wiki/hep#Turkish) | altogether | /hep/ · adv |
| [kız](https://en.wiktionary.org/wiki/k%C4%B1z#Turkish) | girl | /kɯz/ · noun |
| [hala](https://en.wiktionary.org/wiki/hala#Turkish) | paternal aunt (father’s sister) | /hɑˈɫɑ/ · noun |
| [çocuk](https://en.wiktionary.org/wiki/%C3%A7ocuk#Turkish) | child | /t͡ʃoˈd͡ʒuk/ · noun |
| [para](https://en.wiktionary.org/wiki/para#Turkish) | money | /paˈɾa/ · noun |
| [su](https://en.wiktionary.org/wiki/su#Turkish) | water; H₂O | /su/ · noun |
| [an](https://en.wiktionary.org/wiki/an#Turkish) | moment | /ɑn/ · noun |
| [bin](https://en.wiktionary.org/wiki/bin#Turkish) | thousand | /ˈbin/ · num |
| [el](https://en.wiktionary.org/wiki/el#Turkish) | hand | /ˈel/ · noun |
| [etmek](https://en.wiktionary.org/wiki/etmek#Turkish) | to do; to make | /etˈmec/ · verb |
| [in](https://en.wiktionary.org/wiki/in#Turkish) | lair, den, burrow | /in/ · noun |
| [hayır](https://en.wiktionary.org/wiki/hay%C4%B1r#Turkish) | no | /ˈhɑ.jɯɾ/ · intj |
| [kötü](https://en.wiktionary.org/wiki/k%C3%B6t%C3%BC#Turkish) | bad | /cøˈty/ · adj |
| [demek](https://en.wiktionary.org/wiki/demek#Turkish) | to say |  · verb |
| [bak](https://en.wiktionary.org/wiki/bak#Turkish) | watch out, beware |  · intj |
| [zor](https://en.wiktionary.org/wiki/zor#Turkish) | hard, difficult | /ˈzoɾ/ · adj |
| [ay](https://en.wiktionary.org/wiki/ay#Turkish) | moon | /ɑj/ · noun |
| [belki](https://en.wiktionary.org/wiki/belki#Turkish) | maybe, possibly, probably | /bɛlˈci/ · adv |
| [hafta](https://en.wiktionary.org/wiki/hafta#Turkish) | week | /hafˈta/ · noun |
| [süre](https://en.wiktionary.org/wiki/s%C3%BCre#Turkish) | duration | /syˈɾe/ · noun |
| [haber](https://en.wiktionary.org/wiki/haber#Turkish) | news | /haˈbeɾ/ · noun |
| [gramer](https://en.wiktionary.org/wiki/gramer) | grammar |  · noun |
| [al](https://en.wiktionary.org/wiki/al#Turkish) | blood red | /ɑɫ/ · adj |
| [ev](https://en.wiktionary.org/wiki/ev#Turkish) | A building for a family to reside in; house, home, abode. | /ˈev/ · noun |
| [hava](https://en.wiktionary.org/wiki/hava#Turkish) | weather | /hɑˈvɑ/ · noun |
| [karar](https://en.wiktionary.org/wiki/karar#Turkish) | decision | /ka.ɾaɾ/ · noun |
| [ait](https://en.wiktionary.org/wiki/ait#Turkish) | [with dative] concerning, relating (to) |  · postp |
| [dakika](https://en.wiktionary.org/wiki/dakika#Turkish) | minute (unit of time) | /da.ciːˈka/ · noun |
| [hızlı](https://en.wiktionary.org/wiki/h%C4%B1zl%C4%B1#Turkish) | fast, rapid, quick | /hɯzˈɫɯ/ · adj |
| [il](https://en.wiktionary.org/wiki/il#Turkish) | province | /il/ · noun |
| [hadi](https://en.wiktionary.org/wiki/hadi#Turkish) | come on | /ˈha.di/ · intj |
| [ana](https://en.wiktionary.org/wiki/ana#Turkish) | mother | /a.na/ · noun |
| [dört](https://en.wiktionary.org/wiki/d%C3%B6rt#Turkish) | four | /ˈdøɾt/ · num |
| [bilgi](https://en.wiktionary.org/wiki/bilgi#Turkish) | information | /bilˈɟi/ · noun |
| [merak](https://en.wiktionary.org/wiki/merak#Turkish) | curiosity | /meɾɑːk/ · noun |

</details>

<details><summary>Words 101–150</summary>

![[Resources/Audio/tr/Words 0101-0150.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [sabah](https://en.wiktionary.org/wiki/sabah#Turkish) | in the morning | /sa.ˈbah/ · adv |
| [et](https://en.wiktionary.org/wiki/et#Turkish) | The muscle and fat tissue in humans and animals; meat, flesh. | /et/ · noun |
| [kontrol](https://en.wiktionary.org/wiki/kontrol#Turkish) | control, check | /kon.tɾol/ · noun |
| [parti](https://en.wiktionary.org/wiki/parti#Turkish) | party (social gathering) | /paɾ.ti/ · noun |
| [beri](https://en.wiktionary.org/wiki/beri#Turkish) | since | /beˈɾi/ · postp |
| [film](https://en.wiktionary.org/wiki/film#Turkish) | a medium used to capture images in a camera | /fil(i)m/ · noun |
| [gelecek](https://en.wiktionary.org/wiki/gelecek#Turkish) | future | /ɟe.leˈd͡ʒec/ · adj |
| [göz](https://en.wiktionary.org/wiki/g%C3%B6z#Turkish) | eye | /ˈɟøz/ · noun |
| [spor](https://en.wiktionary.org/wiki/spor#Turkish) | sport | /s(ɯ)poɾ/ · noun |
| [yaz](https://en.wiktionary.org/wiki/yaz#Turkish) | summer | /jaz/ · noun |
| [almak](https://en.wiktionary.org/wiki/almak#Turkish) | to take | /aɫˈmak/ · verb |
| [bazen](https://en.wiktionary.org/wiki/bazen#Turkish) | every now and then | /ˈbaː.zen/ · adv |
| [belli](https://en.wiktionary.org/wiki/belli#Turkish) | known | /belˈli/ · adj |
| [halk](https://en.wiktionary.org/wiki/halk#Turkish) | people | /ˈhaɫk/ · noun |
| [on](https://en.wiktionary.org/wiki/on#Turkish) | ten | /on/ · num |
| [polis](https://en.wiktionary.org/wiki/polis#Turkish) | police (an organisation that enforces the law) | /poˈlis/ · noun |
| [temmuz](https://en.wiktionary.org/wiki/temmuz#Turkish) | July | /temˈmuz/ · noun |
| [yardım](https://en.wiktionary.org/wiki/yard%C4%B1m#Turkish) | help | /jaɾˈdɯm/ · noun |
| [anne](https://en.wiktionary.org/wiki/anne#Turkish) | mother | /ɑnːe/ · noun |
| [on bir](https://en.wiktionary.org/wiki/on%20bir#Turkish) | eleven | /ˈon biɾ/ · num |
| [beyaz](https://en.wiktionary.org/wiki/beyaz#Turkish) | white | /beˈjɑz/ · adj |
| [durum](https://en.wiktionary.org/wiki/durum#Turkish) | situation; status, condition | /duˈɾum/ · noun |
| [eylül](https://en.wiktionary.org/wiki/eyl%C3%BCl#Turkish) | September |  · noun |
| [kabul etmek](https://en.wiktionary.org/wiki/kabul%20etmek#Turkish) | to accept, to agree | /kaˈbuːl et.mec/ · verb |
| [kan](https://en.wiktionary.org/wiki/kan#Turkish) | blood | /ˈkan/ · noun |
| [beş](https://en.wiktionary.org/wiki/be%C5%9F#Turkish) | five | /beʃ/ · num |
| [dün](https://en.wiktionary.org/wiki/d%C3%BCn#Turkish) | yesterday |  · adv |
| [kalan](https://en.wiktionary.org/wiki/kalan#Turkish) | remaining, staying | [kʰäˈɫän] · adj |
| [kitap](https://en.wiktionary.org/wiki/kitap#Turkish) | book | /ciˈtap/ · noun |
| [sıra](https://en.wiktionary.org/wiki/s%C4%B1ra#Turkish) | row | /sɯ.ɾɐ/ · noun |
| [yaş](https://en.wiktionary.org/wiki/ya%C5%9F#Turkish) | fresh, wet, moist | /jɑʃ/ · adj |
| [çeviri](https://en.wiktionary.org/wiki/%C3%A7eviri) | translation |  · noun |
| [deniz](https://en.wiktionary.org/wiki/deniz#Turkish) | sea | /deˈniz/ · noun |
| [seni seviyorum](https://en.wiktionary.org/wiki/seni%20seviyorum#Turkish) | I love you |  · phrase |
| [üst](https://en.wiktionary.org/wiki/%C3%BCst#Turkish) | something's face or side looking upwards or towards the sky | /ˈyst/ · noun |
| [ara](https://en.wiktionary.org/wiki/ara#Turkish) | space or time between two things | /aˈɾa/ · noun |
| [at](https://en.wiktionary.org/wiki/at#Turkish) | horse | /ˈat/ · noun |
| [başkan](https://en.wiktionary.org/wiki/ba%C5%9Fkan#Turkish) | president | /bɑʃˈkɑn/ · noun |
| [ses](https://en.wiktionary.org/wiki/ses#Turkish) | voice, sound | /ˈses/ · noun |
| [video](https://en.wiktionary.org/wiki/video#Turkish) | video | /viˈde.o/ · noun |
| [altı](https://en.wiktionary.org/wiki/alt%C4%B1#Turkish) | six | [ɑ̈l̪ˠ.t̪ʰɯ̽] · num |
| [fark](https://en.wiktionary.org/wiki/fark#Turkish) | difference | /faɾk/ · noun |
| [hak](https://en.wiktionary.org/wiki/hak#Turkish) | justice, fairness | /hak/ · noun |
| [müzik](https://en.wiktionary.org/wiki/m%C3%BCzik#Turkish) | music | /myˈzic/ · noun |
| [tür](https://en.wiktionary.org/wiki/t%C3%BCr#Turkish) | kind, variety | /tyɾ/ · noun |
| [boş](https://en.wiktionary.org/wiki/bo%C5%9F#Turkish) | empty, unoccupied, blank | /ˈboʃ/ · adj |
| [hatta](https://en.wiktionary.org/wiki/hatta#Turkish) | moreover, additionally, furthermore, what is more, even | /ˈhat.taː/ · adv |
| [rahat](https://en.wiktionary.org/wiki/rahat#Turkish) | comfort, ease, peace of mind | [ɾ̞äˈhätʰ] · noun |
| [dolu](https://en.wiktionary.org/wiki/dolu#Turkish) | full |  · adj |
| [alıştırma](https://en.wiktionary.org/wiki/al%C4%B1%C5%9Ft%C4%B1rma) | exercise; practice |  · noun |

</details>

<details><summary>Words 151–200</summary>

![[Resources/Audio/tr/Words 0151-0200.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [öğrenmek](https://en.wiktionary.org/wiki/%C3%B6%C4%9Frenmek) | to learn |  · verb |
| [mart](https://en.wiktionary.org/wiki/mart#Turkish) | March |  · noun |
| [sayın](https://en.wiktionary.org/wiki/say%C4%B1n#Turkish) | A formal way of addressing a person or people in a formal context or in a starting of a speech, letter, message, memo, etc., honorable, dear, esteemed, fellow | /sɑˈjɯn/ · adj |
| [nisan](https://en.wiktionary.org/wiki/nisan#Turkish) | April |  · noun |
| [telefon](https://en.wiktionary.org/wiki/telefon#Turkish) | telephone | /te.le.fon/ · noun |
| [alt](https://en.wiktionary.org/wiki/alt#Turkish) | bottom | /ɑɫt/ · noun |
| [dahil](https://en.wiktionary.org/wiki/dahil#Turkish) | involvement | /daˈhil/ · noun |
| [okul](https://en.wiktionary.org/wiki/okul#Turkish) | school | /oˈkuɫ/ · noun |
| [hayal](https://en.wiktionary.org/wiki/hayal#Turkish) | dream, wish | /haˈjæl/ · noun |
| [resim](https://en.wiktionary.org/wiki/resim#Turkish) | picture | /ɾe.ˈsim/ · noun |
| [sanat](https://en.wiktionary.org/wiki/sanat#Turkish) | art | /sa.nat/ · noun |
| [adım](https://en.wiktionary.org/wiki/ad%C4%B1m#Turkish) | step (pace) | /aˈdɯm/ · noun |
| [peki](https://en.wiktionary.org/wiki/peki#Turkish) | okay | /ˈpe.ci/ · intj |
| [nefret](https://en.wiktionary.org/wiki/nefret#Turkish) | hate, hatred |  · noun |
| [on üç](https://en.wiktionary.org/wiki/on%20%C3%BC%C3%A7#Turkish) | thirteen |  · num |
| [acaba](https://en.wiktionary.org/wiki/acaba#Turkish) | Used to add a meaning of curiosity, indecision or doubt, and sometimes courtesy. Roughly equivalent to “I wonder (if/whether)”, “Would you please...”, “May I...”, "by any chance". | /ˈɑ.d͡ʒɑ.bɑː/ · adv |
| [aile](https://en.wiktionary.org/wiki/aile#Turkish) | family | /ɑː.i.ˈle/ · noun |
| [ak](https://en.wiktionary.org/wiki/ak#Turkish) | white | /ˈɑk/ · adj |
| [ağustos](https://en.wiktionary.org/wiki/a%C4%9Fustos#Turkish) | August | /a.usˈtos/ · noun |
| [dolar](https://en.wiktionary.org/wiki/dolar#Turkish) | dollar | /do.lɑɾ/ · noun |
| [normal](https://en.wiktionary.org/wiki/normal#Turkish) | normal | /noɾˈmɑl/ · adj |
| [baş](https://en.wiktionary.org/wiki/ba%C5%9F#Turkish) | head | /ˈbaʃ/ · noun |
| [elektrik](https://en.wiktionary.org/wiki/elektrik#Turkish) | electricity | /e.lecˈtɾic/ · noun |
| [konu](https://en.wiktionary.org/wiki/konu#Turkish) | topic, subject, issue | /koˈnu/ · noun |
| [vermek](https://en.wiktionary.org/wiki/vermek#Turkish) | to give | /veɾˈmek/ · verb |
| [ölüm](https://en.wiktionary.org/wiki/%C3%B6l%C3%BCm#Turkish) | death | /øˈlym/ · noun |
| [gol](https://en.wiktionary.org/wiki/gol#Turkish) | goal (act of placing the object into the goal) | /ˈɡoɫ/ · noun |
| [sene](https://en.wiktionary.org/wiki/sene#Turkish) | year | /se.ne/ · noun |
| [bey](https://en.wiktionary.org/wiki/bey#Turkish) | gentleman, mister | /ˈbej/ · noun |
| [merhaba](https://en.wiktionary.org/wiki/merhaba#Turkish) | hello, hi | /ˈmæɾ.ha.baː/ · intj |
| [ön](https://en.wiktionary.org/wiki/%C3%B6n#Turkish) | front |  · noun |
| [dil](https://en.wiktionary.org/wiki/dil#Turkish) | language | /ˈdil/ · noun |
| [kasım](https://en.wiktionary.org/wiki/kas%C4%B1m#Turkish) | November | /kaˈsɯm/ · noun |
| [kırmızı](https://en.wiktionary.org/wiki/k%C4%B1rm%C4%B1z%C4%B1#Turkish) | red | /kɯɾ.mɯˈzɯ/ · noun |
| [altın](https://en.wiktionary.org/wiki/alt%C4%B1n#Turkish) | gold, a yellow, elemental metal of great value, with atomic number 79 | /ɑlˈtɯn/ · noun |
| [baba](https://en.wiktionary.org/wiki/baba#Turkish) | father | /baˈba/ · noun |
| [haziran](https://en.wiktionary.org/wiki/haziran#Turkish) | June | /hɑzi(ː)ˈrɑn/ · noun |
| [henüz](https://en.wiktionary.org/wiki/hen%C3%BCz#Turkish) | just, just now | /ˈhe.nyz/ · adv |
| [mayıs](https://en.wiktionary.org/wiki/may%C4%B1s#Turkish) | May |  · noun |
| [mümkün](https://en.wiktionary.org/wiki/m%C3%BCmk%C3%BCn#Turkish) | possible | /mymˈcyn/ · adj |
| [teşekkür ederim](https://en.wiktionary.org/wiki/te%C5%9Fekk%C3%BCr%20ederim#Turkish) | thank you | /te.ʃec.cyɾ e.deˈɾim/ · phrase |
| [şubat](https://en.wiktionary.org/wiki/%C5%9Fubat#Turkish) | February | /ʃuˈbat/ · noun |
| [cumhuriyet](https://en.wiktionary.org/wiki/cumhuriyet#Turkish) | republic | /d͡ʒum.huː.ɾi.jet/ · noun |
| [futbol](https://en.wiktionary.org/wiki/futbol#Turkish) | football (soccer) | /ˈfut̚.bɔɫ/ · noun |
| [kere](https://en.wiktionary.org/wiki/kere#Turkish) | time, occasion (an instance or occurrence) | /ceˈɾe/ · noun |
| [yüz](https://en.wiktionary.org/wiki/y%C3%BCz#Turkish) | hundred | /jyz/ · num |
| [Can](https://en.wiktionary.org/wiki/Can#Turkish) | a male given name from Persian | /ˈd͡ʒan/ · noun |
| [can](https://en.wiktionary.org/wiki/can#Turkish) | soul, life, being | /ˈd͡ʒan/ · noun |
| [ekim](https://en.wiktionary.org/wiki/ekim#Turkish) | October | /eˈcim/ · noun |
| [internet](https://en.wiktionary.org/wiki/internet#Turkish) | internet | /intæɾˈnet/ · noun |

</details>

<details><summary>Words 201–250</summary>

![[Resources/Audio/tr/Words 0201-0250.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [kara](https://en.wiktionary.org/wiki/kara#Turkish) | black, dark | /kaˈɾa/ · adj |
| [of](https://en.wiktionary.org/wiki/of#Turkish) | oof (often expressing that some task requires great effort) |  · intj |
| [seks](https://en.wiktionary.org/wiki/seks#Turkish) | sex (sexual category) | /ˈsecs/ · noun |
| [hale](https://en.wiktionary.org/wiki/hale#Turkish) | halo (atmospheric phenomenon) | /haːˈle/ · noun |
| [sağ](https://en.wiktionary.org/wiki/sa%C4%9F#Turkish) | right (side) | /ˈsaː/ · adj |
| [din](https://en.wiktionary.org/wiki/din#Turkish) | System of beliefs dealing with soul, deity or life after death. |  · noun |
| [millet](https://en.wiktionary.org/wiki/millet#Turkish) | nation | /milˈlet/ · noun |
| [oy](https://en.wiktionary.org/wiki/oy#Turkish) | vote | /oj/ · noun |
| [site](https://en.wiktionary.org/wiki/site#Turkish) | gated community | [siˈte] · noun |
| [bebek](https://en.wiktionary.org/wiki/bebek#Turkish) | baby | [be.ˈbec] · noun |
| [emin](https://en.wiktionary.org/wiki/emin#Turkish) | secure | /e.min/ · adj |
| [on dört](https://en.wiktionary.org/wiki/on%20d%C3%B6rt#Turkish) | fourteen |  · num |
| [siyah](https://en.wiktionary.org/wiki/siyah#Turkish) | black | /siˈjah/ · noun |
| [ek](https://en.wiktionary.org/wiki/ek#Turkish) | annex |  · noun |
| [hasta](https://en.wiktionary.org/wiki/hasta#Turkish) | ill, sick | /hasˈta/ · adj |
| [ocak](https://en.wiktionary.org/wiki/ocak#Turkish) | stove, oven, fireplace | /oˈd͡ʒɑk/ · noun |
| [online](https://en.wiktionary.org/wiki/online#Turkish) | online | /ˈon.ɫajn/ · adj |
| [hukuk](https://en.wiktionary.org/wiki/hukuk#Turkish) | law | /huˈkuk/ · noun |
| [isim](https://en.wiktionary.org/wiki/isim#Turkish) | name (word or phrase indicating a particular person, place, class or thing) | /iˈsim/ · noun |
| [öğretmek](https://en.wiktionary.org/wiki/%C3%B6%C4%9Fretmek) | to teach |  · verb |
| [yıldız](https://en.wiktionary.org/wiki/y%C4%B1ld%C4%B1z#Turkish) | star | /jɯɫˈdɯz/ · noun |
| [ölü](https://en.wiktionary.org/wiki/%C3%B6l%C3%BC#Turkish) | dead | /øˈly/ · adj |
| [adet](https://en.wiktionary.org/wiki/adet#Turkish) | amount | /ˈɑ.det/ · noun |
| [aralık](https://en.wiktionary.org/wiki/aral%C4%B1k#Turkish) | December | [ɑ.ɾɑ.ˈlɯc] · noun |
| [nefret etmek](https://en.wiktionary.org/wiki/nefret%20etmek#Turkish) | to hate, abhor |  · verb |
| [sebep](https://en.wiktionary.org/wiki/sebep#Turkish) | reason | /seˈbep/ · noun |
| [sevgili](https://en.wiktionary.org/wiki/sevgili#Turkish) | beloved, lover, darling | /sev.ɟiˈli/ · noun |
| [arka](https://en.wiktionary.org/wiki/arka#Turkish) | back | /aɾˈka/ · adj |
| [değerli](https://en.wiktionary.org/wiki/de%C4%9Ferli#Turkish) | valuable, precious, prized | /deːeɾˈli/ · adj |
| [nefes](https://en.wiktionary.org/wiki/nefes#Turkish) | breath |  · noun |
| [taş](https://en.wiktionary.org/wiki/ta%C5%9F#Turkish) | stone, rock (aggregate of solid mineral matter) | /ˈtaʃ/ · noun |
| [yedi](https://en.wiktionary.org/wiki/yedi#Turkish) | seven | /je.di/ · num |
| [ateş](https://en.wiktionary.org/wiki/ate%C5%9F#Turkish) | fire | /aˈteʃ/ · noun |
| [bilgisayar](https://en.wiktionary.org/wiki/bilgisayar#Turkish) | computer | /bil.ɟi.saˈjaɾ/ · noun |
| [gitmek](https://en.wiktionary.org/wiki/gitmek#Turkish) | to go | /ɟitˈmec/ · verb |
| [on beş](https://en.wiktionary.org/wiki/on%20be%C5%9F#Turkish) | fifteen |  · num |
| [pazar](https://en.wiktionary.org/wiki/pazar#Turkish) | Sunday | /pɑ.zɑɾ/ · noun |
| [sol](https://en.wiktionary.org/wiki/sol#Turkish) | left (side) | [soɫ] · adj |
| [üç yüz](https://en.wiktionary.org/wiki/%C3%BC%C3%A7%20y%C3%BCz#Turkish) | three hundred |  · num |
| [mal](https://en.wiktionary.org/wiki/mal#Turkish) | cattle | /ˈmɑɫ/ · noun |
| [deli](https://en.wiktionary.org/wiki/deli#Turkish) | crazy, mad, insane | /deˈli/ · adj |
| [doğan](https://en.wiktionary.org/wiki/do%C4%9Fan#Turkish) | hawk, falcon, peregrine falcon | /doˈan/ · noun |
| [oda](https://en.wiktionary.org/wiki/oda#Turkish) | room, chamber |  · noun |
| [on altı](https://en.wiktionary.org/wiki/on%20alt%C4%B1#Turkish) | sixteen |  · num |
| [sert](https://en.wiktionary.org/wiki/sert#Turkish) | hard | /ˈseɾt/ · adj |
| [ha](https://en.wiktionary.org/wiki/ha#Turkish) | yea, uh-huh; understood, got it |  · intj |
| [kahve](https://en.wiktionary.org/wiki/kahve#Turkish) | coffee | /kahˈve/ · noun |
| [mavi](https://en.wiktionary.org/wiki/mavi#Turkish) | blue | [mɑːˈvɪ] · adj |
| [kimi](https://en.wiktionary.org/wiki/kimi#Turkish) | some; an unspecified quantity or number of. | [ˈcimi] · adj |
| [park](https://en.wiktionary.org/wiki/park#Turkish) | park | /pɑɾk/ · noun |

</details>

<details><summary>Words 251–300</summary>

![[Resources/Audio/tr/Words 0251-0300.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [parça](https://en.wiktionary.org/wiki/par%C3%A7a#Turkish) | component | /pɑɾˈtʃɑ/ · noun |
| [bol](https://en.wiktionary.org/wiki/bol#Turkish) | loose |  · adj |
| [net](https://en.wiktionary.org/wiki/net#Turkish) | clear | /net/ · adj |
| [yeşil](https://en.wiktionary.org/wiki/ye%C5%9Fil#Turkish) | green | /jeˈʃil/ · noun |
| [aç](https://en.wiktionary.org/wiki/a%C3%A7#Turkish) | hungry person | [ɑt͡ʃ] · noun |
| [balık](https://en.wiktionary.org/wiki/bal%C4%B1k#Turkish) | fish | /baˈɫɯk/ · noun |
| [dalga](https://en.wiktionary.org/wiki/dalga#Turkish) | wave, a moving disturbance in the level of a body of liquid | /dɑɫˈɡɑ/ · noun |
| [derin](https://en.wiktionary.org/wiki/derin#Turkish) | deep | [deˈɾin] · adj |
| [metre](https://en.wiktionary.org/wiki/metre#Turkish) | metre, meter (unit of measure, 100 cm) | /ˈmetɾe/ · noun |
| [modern](https://en.wiktionary.org/wiki/modern#Turkish) | modern | /moˈdæɾn/ · adj |
| [san](https://en.wiktionary.org/wiki/san#Turkish) | name |  · noun |
| [sarı](https://en.wiktionary.org/wiki/sar%C4%B1#Turkish) | yellow | /sɑˈɾɯ/ · adj |
| [yan](https://en.wiktionary.org/wiki/yan#Turkish) | side |  · noun |
| [çay](https://en.wiktionary.org/wiki/%C3%A7ay#Turkish) | tea (plant) | /ˈt͡ʃaj/ · noun |
| [doktor](https://en.wiktionary.org/wiki/doktor#Turkish) | doctor, physician | /dokˈtoɾ/ · noun |
| [bakan](https://en.wiktionary.org/wiki/bakan#Turkish) | minister | /baˈkan/ · noun |
| [dört yüz](https://en.wiktionary.org/wiki/d%C3%B6rt%20y%C3%BCz#Turkish) | four hundred |  · num |
| [kapı](https://en.wiktionary.org/wiki/kap%C4%B1#Turkish) | door | /kɑˈpɯ/ · noun |
| [kral](https://en.wiktionary.org/wiki/kral#Turkish) | king (head of a country) | [kɾɑɫ] · noun |
| [sultan](https://en.wiktionary.org/wiki/sultan#Turkish) | A monarchic title for Sunni Muslim monarchs. | /suɫˈtɑ(ː)n/ · noun |
| [araba](https://en.wiktionary.org/wiki/araba#Turkish) | car | /ɑ.ɾɑ.ˈbɑ/ · noun |
| [birlik](https://en.wiktionary.org/wiki/birlik#Turkish) | unity | /biɾ.lic/ · noun |
| [dava](https://en.wiktionary.org/wiki/dava#Turkish) | suit, action | /daːvaː/ · noun |
| [dua](https://en.wiktionary.org/wiki/dua#Turkish) | prayer (practice of communicating with one's God) | /duˈɑː/ · noun |
| [hata](https://en.wiktionary.org/wiki/hata#Turkish) | error, fault, mistake | /ha.taː/ · noun |
| [hayvan](https://en.wiktionary.org/wiki/hayvan#Turkish) | animal (organism; organism other than human) | /hajˈvan/ · noun |
| [ta](https://en.wiktionary.org/wiki/ta#Turkish) | Used with postpositions like dek, değin, kadar, beri etc. to emphasize the beginning or the end of a thing with regards to time or distance. | /ˈtaː/ · adv |
| [transfer](https://en.wiktionary.org/wiki/transfer#Turkish) | transfer | /tɾɑns.fɛɾ/ · noun |
| [şiir](https://en.wiktionary.org/wiki/%C5%9Fiir#Turkish) | poem | [ʃiːɾ] · noun |
| [cuma](https://en.wiktionary.org/wiki/cuma#Turkish) | Friday | /d͡ʒu.mɑː/ · noun |
| [not](https://en.wiktionary.org/wiki/not#Turkish) | a short message; note | /ˈnot/ · noun |
| [sefer](https://en.wiktionary.org/wiki/sefer#Turkish) | journey, trip | /seˈfeɾ/ · noun |
| [koca](https://en.wiktionary.org/wiki/koca#Turkish) | large, big | /koˈd͡ʒa/ · adj |
| [beş yüz](https://en.wiktionary.org/wiki/be%C5%9F%20y%C3%BCz#Turkish) | five hundred |  · num |
| [ekonomi](https://en.wiktionary.org/wiki/ekonomi#Turkish) | economy |  · noun |
| [sınıf](https://en.wiktionary.org/wiki/s%C4%B1n%C4%B1f#Turkish) | class (group, collection, category or set sharing characteristics or attributes) | /sɯˈnɯf/ · noun |
| [uçak](https://en.wiktionary.org/wiki/u%C3%A7ak#Turkish) | aeroplane | /uˈt͡ʃak/ · noun |
| [altı yüz](https://en.wiktionary.org/wiki/alt%C4%B1%20y%C3%BCz#Turkish) | six hundred |  · num |
| [demir](https://en.wiktionary.org/wiki/demir#Turkish) | iron | /deˈmiɾ/ · noun |
| [kamu](https://en.wiktionary.org/wiki/kamu#Turkish) | public | /ˈkamu/ · noun |
| [ayak](https://en.wiktionary.org/wiki/ayak#Turkish) | foot | /aˈjak/ · noun |
| [dahi](https://en.wiktionary.org/wiki/dahi#Turkish) | even | /da.hi/ · adv |
| [fikir](https://en.wiktionary.org/wiki/fikir#Turkish) | thought, idea | /fiˈciɾ/ · noun |
| [iken](https://en.wiktionary.org/wiki/iken#Turkish) | while, whilst, when, as | /iˈcæn/ · adv |
| [köpek](https://en.wiktionary.org/wiki/k%C3%B6pek#Turkish) | dog | /cøˈpec/ · noun |
| [lig](https://en.wiktionary.org/wiki/lig#Turkish) | league (organization of sports teams) | /liɟ/ · noun |
| [test](https://en.wiktionary.org/wiki/test#Turkish) | test | /ˈtest/ · noun |
| [plan](https://en.wiktionary.org/wiki/plan#Turkish) | plan | /p(i)ˈlɑn/ · noun |
| [terk etmek](https://en.wiktionary.org/wiki/terk%20etmek#Turkish) | to abandon |  · verb |
| [un](https://en.wiktionary.org/wiki/un#Turkish) | flour, powder obtained by grinding or milling cereal grains and used to bake bread, cakes, and pastry | /ˈun/ · noun |

</details>

<details><summary>Words 301–350</summary>

![[Resources/Audio/tr/Words 0301-0350.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [dans](https://en.wiktionary.org/wiki/dans#Turkish) | dance (movements to music) | /dɑns/ · noun |
| [gaz](https://en.wiktionary.org/wiki/gaz#Turkish) | gas, matter in an intermediate state between liquid and plasma |  · noun |
| [kurban](https://en.wiktionary.org/wiki/kurban#Turkish) | victim | /kuɾˈban/ · noun |
| [model](https://en.wiktionary.org/wiki/model#Turkish) | model (person who serves as a human template for artwork; person who is hired to show fashion items to the public) | /moˈdel/ · noun |
| [on yedi](https://en.wiktionary.org/wiki/on%20yedi#Turkish) | seventeen | [ˈo̞n je̞.d̪ɪ] · num |
| [top](https://en.wiktionary.org/wiki/top#Turkish) | ball | /ˈtop/ · noun |
| [burda](https://en.wiktionary.org/wiki/burda#Turkish) | synonym of burada (“here”) | /ˈbuɾ.da/ · adv |
| [rol](https://en.wiktionary.org/wiki/rol#Turkish) | role | /ˈɾol/ · noun |
| [Rus](https://en.wiktionary.org/wiki/Rus#Turkish) | A Russian person (nationality) |  · noun |
| [kat](https://en.wiktionary.org/wiki/kat#Turkish) | floor, storey, level |  · noun |
| [sekiz](https://en.wiktionary.org/wiki/sekiz#Turkish) | eight | /seˈciz/ · num |
| [tatil](https://en.wiktionary.org/wiki/tatil#Turkish) | vacation | /taːtil/ · noun |
| [veri](https://en.wiktionary.org/wiki/veri#Turkish) | data | /veˈɾi/ · noun |
| [yurt](https://en.wiktionary.org/wiki/yurt#Turkish) | A piece of land on which a nation resides and which forms its culture; homeland. | /ˈjuɾt/ · noun |
| [alacak](https://en.wiktionary.org/wiki/alacak#Turkish) | credit, money owed |  · noun |
| [engel](https://en.wiktionary.org/wiki/engel#Turkish) | obstacle |  · noun |
| [general](https://en.wiktionary.org/wiki/general#Turkish) | general | /ɟe.neˈɾal/ · noun |
| [hani](https://en.wiktionary.org/wiki/hani#Turkish) | where | /ha.ni/ · adv |
| [kafa](https://en.wiktionary.org/wiki/kafa#Turkish) | head | /kɑfɑ/ · noun |
| [kredi](https://en.wiktionary.org/wiki/kredi#Turkish) | credit | /k(ɯ)ˈɾe.di/ · noun |
| [madde](https://en.wiktionary.org/wiki/madde#Turkish) | article (section of a legal document) | /madːe/ · noun |
| [sevgi](https://en.wiktionary.org/wiki/sevgi#Turkish) | love (strong affection) | /sevˈɟi/ · noun |
| [televizyon](https://en.wiktionary.org/wiki/televizyon#Turkish) | television | /te.le.vizˈjon/ · noun |
| [yaşlı](https://en.wiktionary.org/wiki/ya%C5%9Fl%C4%B1#Turkish) | old (for people, animals etc.) | /jaʃˈɫɯ/ · adj |
| [çabuk](https://en.wiktionary.org/wiki/%C3%A7abuk#Turkish) | quick, fast | /t͡ʃaˈbuk/ · adj |
| [dinlemek](https://en.wiktionary.org/wiki/dinlemek) | to listen |  · verb |
| [aziz](https://en.wiktionary.org/wiki/aziz#Turkish) | dear |  · adj |
| [si](https://en.wiktionary.org/wiki/si#Turkish) | si (musical note B) | /ˈsi/ · noun |
| [çiçek](https://en.wiktionary.org/wiki/%C3%A7i%C3%A7ek#Turkish) | flower | /t͡ʃiˈt͡ʃec/ · noun |
| [şaka](https://en.wiktionary.org/wiki/%C5%9Faka#Turkish) | joke | /ʃaˈka/ · noun |
| [alma](https://en.wiktionary.org/wiki/alma#Turkish) | taking, picking up, buying |  · noun |
| [boy](https://en.wiktionary.org/wiki/boy#Turkish) | stature, height | /ˈboj/ · noun |
| [cumartesi](https://en.wiktionary.org/wiki/cumartesi#Turkish) | Saturday | /d͡ʒuˈmaɾ.te.si/ · noun |
| [gemi](https://en.wiktionary.org/wiki/gemi#Turkish) | ship | [ɟeˈmi] · noun |
| [kar](https://en.wiktionary.org/wiki/kar#Turkish) | snow | /ˈkaɾ/ · noun |
| [ruh](https://en.wiktionary.org/wiki/ruh#Turkish) | soul, spirit | /ɾuh/ · noun |
| [tip](https://en.wiktionary.org/wiki/tip#Turkish) | type | /tip/ · noun |
| [köy](https://en.wiktionary.org/wiki/k%C3%B6y#Turkish) | village, settlement (a rural habitation of a size between a hamlet and a town) | /ˈcøj/ · noun |
| [renk](https://en.wiktionary.org/wiki/renk#Turkish) | color, shade | /ˈɾenc/ · noun |
| [seksi](https://en.wiktionary.org/wiki/seksi#Turkish) | sexy | /sec.siː/ · adj |
| [seri](https://en.wiktionary.org/wiki/seri#Turkish) | series | /seˈɾi/ · noun |
| [zevk](https://en.wiktionary.org/wiki/zevk#Turkish) | pleasure | /ˈzevc/ · noun |
| [kaya](https://en.wiktionary.org/wiki/kaya#Turkish) | huge rock; large rock mass | /kaˈja/ · noun |
| [kent](https://en.wiktionary.org/wiki/kent#Turkish) | city | /cænt/ · noun |
| [yağmur](https://en.wiktionary.org/wiki/ya%C4%9Fmur#Turkish) | rain | /jɑːˈmur/ · noun |
| [çek](https://en.wiktionary.org/wiki/%C3%A7ek#Turkish) | check, cheque |  · noun |
| [dek](https://en.wiktionary.org/wiki/dek#Turkish) | until, till, up to | /dec/ · postp |
| [şeker](https://en.wiktionary.org/wiki/%C5%9Feker#Turkish) | amiable, cute | /ʃeˈcæɾ/ · adj |
| [demokrasi](https://en.wiktionary.org/wiki/demokrasi#Turkish) | democracy | /de.mok.ɾaˈsi/ · noun |
| [düşman](https://en.wiktionary.org/wiki/d%C3%BC%C5%9Fman#Turkish) | enemy | /dyʃˈman/ · adj |

</details>

<details><summary>Words 351–400</summary>

![[Resources/Audio/tr/Words 0351-0400.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [fırsat](https://en.wiktionary.org/wiki/f%C4%B1rsat#Turkish) | opportunity, chance, occasion |  · noun |
| [korku](https://en.wiktionary.org/wiki/korku#Turkish) | fear, horror, scare, dread, trepidation | /koɾˈku/ · noun |
| [matematik](https://en.wiktionary.org/wiki/matematik#Turkish) | mathematics | /mɑtemɑˈtic/ · noun |
| [sinema](https://en.wiktionary.org/wiki/sinema#Turkish) | cinema; movie theater | /siˈne.mɑ/ · noun |
| [sokak](https://en.wiktionary.org/wiki/sokak#Turkish) | street, alley | [soˈkɑk] · noun |
| [yedi yüz](https://en.wiktionary.org/wiki/yedi%20y%C3%BCz#Turkish) | seven hundred |  · num |
| [bok](https://en.wiktionary.org/wiki/bok#Turkish) | slag, dross | /bok/ · noun |
| [lider](https://en.wiktionary.org/wiki/lider#Turkish) | leader | /liːdæɾ/ · noun |
| [nokta](https://en.wiktionary.org/wiki/nokta#Turkish) | dot | /nok.tɑ/ · noun |
| [ordu](https://en.wiktionary.org/wiki/ordu#Turkish) | army | /oɾˈdu/ · noun |
| [saha](https://en.wiktionary.org/wiki/saha#Turkish) | area | /saː.ˈhaː/ · noun |
| [söylemek](https://en.wiktionary.org/wiki/s%C3%B6ylemek#Turkish) | to say, to tell | /søj.leˈmec/ · verb |
| [tipi](https://en.wiktionary.org/wiki/tipi#Turkish) | blizzard |  · noun |
| [bayanlar](https://en.wiktionary.org/wiki/bayanlar#Turkish) | mesdames |  · noun |
| [metal](https://en.wiktionary.org/wiki/metal#Turkish) | metal | /me.tal/ · noun |
| [motor](https://en.wiktionary.org/wiki/motor#Turkish) | engine (mechanical device) | /moˈtoɾ/ · noun |
| [orman](https://en.wiktionary.org/wiki/orman#Turkish) | forest, wood | /oɾˈman/ · noun |
| [program](https://en.wiktionary.org/wiki/program#Turkish) | program | /pɾɔɡˈɾam/ · noun |
| [saniye](https://en.wiktionary.org/wiki/saniye#Turkish) | second (unit of time) | /saː.ni.je/ · noun |
| [sağlamak](https://en.wiktionary.org/wiki/sa%C4%9Flamak#Turkish) | to provide, ensure, supply |  · verb |
| [usta](https://en.wiktionary.org/wiki/usta#Turkish) | master, expert | /usˈta/ · noun |
| [ayı](https://en.wiktionary.org/wiki/ay%C4%B1#Turkish) | bear | [ɑˈjɯ] · noun |
| [ilaç](https://en.wiktionary.org/wiki/ila%C3%A7#Turkish) | medicine | /iˈlat͡ʃ/ · noun |
| [rüya](https://en.wiktionary.org/wiki/r%C3%BCya#Turkish) | dream | /ɾyˈjaː/ · noun |
| [yasal](https://en.wiktionary.org/wiki/yasal#Turkish) | lawful, legal | /jaˈsaɫ/ · adj |
| [AB](https://en.wiktionary.org/wiki/AB#Turkish) | the blood type AB | /aːˈbeː/ · noun |
| [buz](https://en.wiktionary.org/wiki/buz#Turkish) | ice | /ˈbuz/ · noun |
| [eş](https://en.wiktionary.org/wiki/e%C5%9F#Turkish) | as, like, kind of | /ˈeʃ/ · adv |
| [imam](https://en.wiktionary.org/wiki/imam#Turkish) | imam |  · noun |
| [kedi](https://en.wiktionary.org/wiki/kedi#Turkish) | cat | /ceˈdi/ · noun |
| [lira](https://en.wiktionary.org/wiki/lira#Turkish) | lira (currency of Turkey) | [l̠ʲí.ɾä] · noun |
| [lise](https://en.wiktionary.org/wiki/lise#Turkish) | high school | /ˈli.se/ · noun |
| [pazartesi](https://en.wiktionary.org/wiki/pazartesi#Turkish) | Monday | /paˈzaɾ.te.si/ · noun |
| [petrol](https://en.wiktionary.org/wiki/petrol#Turkish) | petroleum, oil | /pet.ɾɔl/ · noun |
| [posta](https://en.wiktionary.org/wiki/posta#Turkish) | mail, post | /posˈta/ · noun |
| [bomba](https://en.wiktionary.org/wiki/bomba#Turkish) | bomb (explosive device used or intended as a weapon) |  · noun |
| [dokuz](https://en.wiktionary.org/wiki/dokuz#Turkish) | nine | /doˈkuz/ · num |
| [final](https://en.wiktionary.org/wiki/final#Turkish) | the end | /fiˈnal/ · noun |
| [kazanmak](https://en.wiktionary.org/wiki/kazanmak#Turkish) | to win, gain, acquire | /kɑzɑnˈmɑk/ · verb |
| [kulak](https://en.wiktionary.org/wiki/kulak#Turkish) | ear | /kuˈɫak/ · noun |
| [on sekiz](https://en.wiktionary.org/wiki/on%20sekiz#Turkish) | eighteen |  · num |
| [parlak](https://en.wiktionary.org/wiki/parlak#Turkish) | bright (as in light) | /paɾˈɫak/ · adj |
| [rica](https://en.wiktionary.org/wiki/rica#Turkish) | request | /ɾiˈd͡ʒaː/ · noun |
| [saç](https://en.wiktionary.org/wiki/sa%C3%A7#Turkish) | hair (growth on the human head) | /sat͡ʃ/ · noun |
| [yasa](https://en.wiktionary.org/wiki/yasa#Turkish) | law, statute, code, written set of rules | /jaˈsa/ · noun |
| [ekmek](https://en.wiktionary.org/wiki/ekmek#Turkish) | bread | /ecˈmec/ · noun |
| [aman](https://en.wiktionary.org/wiki/aman#Turkish) | mercy |  · noun |
| [kilometre](https://en.wiktionary.org/wiki/kilometre#Turkish) | kilometer/kilometre (unit of length) | /ci.lo.met.ɾe/ · noun |
| [cep](https://en.wiktionary.org/wiki/cep#Turkish) | pocket | /d͡ʒep/ · noun |
| [emir](https://en.wiktionary.org/wiki/emir#Turkish) | command | /e.miɾ/ · noun |

</details>

<details><summary>Words 401–450</summary>

![[Resources/Audio/tr/Words 0401-0450.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [mısır](https://en.wiktionary.org/wiki/m%C4%B1s%C4%B1r#Turkish) | maize, corn | [mɯˈsɯɾ] · noun |
| [radyo](https://en.wiktionary.org/wiki/radyo#Turkish) | radio | /ɾɑdjo/ · noun |
| [ten](https://en.wiktionary.org/wiki/ten#Turkish) | skin | /tɛn/ · noun |
| [tren](https://en.wiktionary.org/wiki/tren#Turkish) | train | /tɾɛn/ · noun |
| [dost](https://en.wiktionary.org/wiki/dost#Turkish) | friend |  · noun |
| [seyahat](https://en.wiktionary.org/wiki/seyahat#Turkish) | voyage | /se.ja.ˈhat/ · noun |
| [tur](https://en.wiktionary.org/wiki/tur#Turkish) | tour, a journey through a building, estate, country etc. | /ˈtuɾ/ · noun |
| [dev](https://en.wiktionary.org/wiki/dev#Turkish) | giant | /ˈdev/ · noun |
| [dönüş](https://en.wiktionary.org/wiki/d%C3%B6n%C3%BC%C5%9F#Turkish) | return | [dønyʃ] · noun |
| [hele](https://en.wiktionary.org/wiki/hele#Turkish) | especially | [heˈle] · adv |
| [kamera](https://en.wiktionary.org/wiki/kamera#Turkish) | video camera | /kɑˈmeɾɑ/ · noun |
| [konuşmak](https://en.wiktionary.org/wiki/konu%C5%9Fmak) | to speak |  · verb |
| [sürü](https://en.wiktionary.org/wiki/s%C3%BCr%C3%BC#Turkish) | herd | /syɾy/ · noun |
| [terk edilmiş](https://en.wiktionary.org/wiki/terk%20edilmi%C5%9F#Turkish) | abandoned | /ˈteɾc e.dil.miʃ/ · adj |
| [ağaç](https://en.wiktionary.org/wiki/a%C4%9Fa%C3%A7#Turkish) | tree | /aˈat͡ʃ/ · noun |
| [bina](https://en.wiktionary.org/wiki/bina#Turkish) | building | /bi.naː/ · noun |
| [sekiz yüz](https://en.wiktionary.org/wiki/sekiz%20y%C3%BCz#Turkish) | eight hundred |  · num |
| [tel](https://en.wiktionary.org/wiki/tel#Turkish) | wire | /tel/ · noun |
| [vali](https://en.wiktionary.org/wiki/vali#Turkish) | governor | /vaː.li/ · noun |
| [çelik](https://en.wiktionary.org/wiki/%C3%A7elik#Turkish) | steel | /tʃe.lic/ · noun |
| [ada](https://en.wiktionary.org/wiki/ada#Turkish) | island, isle, a contiguous area of land totally surrounded by water | [ada] · noun |
| [cami](https://en.wiktionary.org/wiki/cami#Turkish) | mosque | [dʒaːˈmi] · noun |
| [dar](https://en.wiktionary.org/wiki/dar#Turkish) | narrow |  · adj |
| [esas](https://en.wiktionary.org/wiki/esas#Turkish) | foundation, basis | [eˈsas] · noun |
| [ey](https://en.wiktionary.org/wiki/ey#Turkish) | vocative particle O, hey | /ˈej/ · intj |
| [heyecan](https://en.wiktionary.org/wiki/heyecan#Turkish) | excitement, thrill, stir, a strong and temporary emotional state | /he.jeˈd͡ʒan/ · noun |
| [abi](https://en.wiktionary.org/wiki/abi#Turkish) | elder brother | /aːˈbi/ · noun |
| [er](https://en.wiktionary.org/wiki/er#Turkish) | suhur | /ɛɾ/ · adv |
| [koç](https://en.wiktionary.org/wiki/ko%C3%A7#Turkish) | ram |  · noun |
| [öz](https://en.wiktionary.org/wiki/%C3%B6z#Turkish) | gist, essence, core, kernel | /ˈøz/ · noun |
| [aslan](https://en.wiktionary.org/wiki/aslan#Turkish) | lion, any large felid of the species Panthera leo | /asˈɫan/ · noun |
| [bilmek](https://en.wiktionary.org/wiki/bilmek#Turkish) | to know, be informed of, be aware of; to understand | /bilˈmec/ · verb |
| [is](https://en.wiktionary.org/wiki/is#Turkish) | soot, lampblack, particles of amorphous carbon and tar produced by the incomplete combustion of coal | /ˈis/ · noun |
| [kullanıcı](https://en.wiktionary.org/wiki/kullan%C4%B1c%C4%B1#Turkish) | user | /kuɫːanɯd͡ʒɯ/ · noun |
| [kupa](https://en.wiktionary.org/wiki/kupa#Turkish) | cup, goblet |  · noun |
| [kurt](https://en.wiktionary.org/wiki/kurt#Turkish) | A wolf; Canis lupus or any of several related canines resembling in appearance, especially those of the genus Canis. | /ˈkuɾt/ · noun |
| [servis](https://en.wiktionary.org/wiki/servis#Turkish) | service | /sæɾˈvis/ · noun |
| [vatan](https://en.wiktionary.org/wiki/vatan#Turkish) | homeland, home country | /vaˈtan/ · noun |
| [yavuz](https://en.wiktionary.org/wiki/yavuz#Turkish) | stern, tough | /jaˈvuz/ · adj |
| [basketbol](https://en.wiktionary.org/wiki/basketbol#Turkish) | basketball (sports) |  · noun |
| [bay](https://en.wiktionary.org/wiki/bay#Turkish) | gentleman | /ˈbaj/ · noun |
| [diş](https://en.wiktionary.org/wiki/di%C5%9F#Turkish) | tooth | /ˈdiʃ/ · noun |
| [meydan](https://en.wiktionary.org/wiki/meydan#Turkish) | square, piazza, esplanade |  · noun |
| [seven](https://en.wiktionary.org/wiki/seven#Turkish) | loving, affectionate | /seˈven/ · adj |
| [süt](https://en.wiktionary.org/wiki/s%C3%BCt#Turkish) | milk | /ˈsyt/ · noun |
| [anlamak](https://en.wiktionary.org/wiki/anlamak#Turkish) | To understand, to comprehend, to get. | /an.ɫaˈmak/ · verb |
| [aptal](https://en.wiktionary.org/wiki/aptal#Turkish) | dumb | /apˈtaɫ/ · adj |
| [kuru](https://en.wiktionary.org/wiki/kuru#Turkish) | dry, arid | /kuˈɾu/ · adj |
| [kör](https://en.wiktionary.org/wiki/k%C3%B6r#Turkish) | blind | /ˈcøɾ/ · adj |
| [banka](https://en.wiktionary.org/wiki/banka#Turkish) | bank | /ˈban.ka/ · noun |

</details>

<details><summary>Words 451–500</summary>

![[Resources/Audio/tr/Words 0451-0500.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [bilet](https://en.wiktionary.org/wiki/bilet#Turkish) | ticket | /biˈlet/ · noun |
| [bitki](https://en.wiktionary.org/wiki/bitki#Turkish) | plant, vegetable | /bitˈci/ · noun |
| [ekran](https://en.wiktionary.org/wiki/ekran#Turkish) | screen (display of a technological device) | /ecˈɾan/ · noun |
| [gelmek](https://en.wiktionary.org/wiki/gelmek#Turkish) | to come, move closer | /ɟelˈmec/ · verb |
| [gene](https://en.wiktionary.org/wiki/gene#Turkish) | again | /ˈɟe.ne/ · adv |
| [kart](https://en.wiktionary.org/wiki/kart#Turkish) | hoary, old | /kɑɾt/ · adj |
| [sıfır](https://en.wiktionary.org/wiki/s%C4%B1f%C4%B1r#Turkish) | nonexistent, no | /ˈsɯ.fɯɾ/ · adj |
| [varken](https://en.wiktionary.org/wiki/varken#Turkish) | while there is; while having, when having | /vaɾˈcen/ · adv |
| [şeytan](https://en.wiktionary.org/wiki/%C5%9Feytan#Turkish) | devil, satan | /ʃejˈtan/ · noun |
| [bahar](https://en.wiktionary.org/wiki/bahar#Turkish) | spring, springtime | /bɑ.hɑɾ/ · noun |
| [bakmak](https://en.wiktionary.org/wiki/bakmak#Turkish) | to look (at), gaze | /bakˈmak/ · verb |
| [forma](https://en.wiktionary.org/wiki/forma#Turkish) | form, shape | /foɾˈma/ · noun |
| [kullanmak](https://en.wiktionary.org/wiki/kullanmak#Turkish) | to use, to utilize, to employ | /kuɫ.ɫanˈmak/ · verb |
| [kurşun](https://en.wiktionary.org/wiki/kur%C5%9Fun#Turkish) | leaden | /kuɾˈʃun/ · adj |
| [kılıç](https://en.wiktionary.org/wiki/k%C4%B1l%C4%B1%C3%A7#Turkish) | sword | /kɯˈɫɯt͡ʃ/ · noun |
| [pis](https://en.wiktionary.org/wiki/pis#Turkish) | dirty | /pis/ · adj |
| [kartal](https://en.wiktionary.org/wiki/kartal#Turkish) | eagle, any of several large carnivorous and carrion-eating birds in the family Accipitridae | /kɐɾˈtɐɫ/ · noun |
| [meyve](https://en.wiktionary.org/wiki/meyve#Turkish) | fruit |  · noun |
| [moda](https://en.wiktionary.org/wiki/moda#Turkish) | fashion | /mɔda/ · noun |
| [problem](https://en.wiktionary.org/wiki/problem#Turkish) | problem | /pɾob.lɛm/ · noun |
| [veda](https://en.wiktionary.org/wiki/veda#Turkish) | farewell, goodbye | /veˈdɑː/ · noun |
| [Japon](https://en.wiktionary.org/wiki/Japon#Turkish) | Japanese (of, from or relating to Japan) | /ʒɑˈpon/ · adj |
| [cam](https://en.wiktionary.org/wiki/cam#Turkish) | glass | /ˈd͡ʒam/ · noun |
| [pahalı](https://en.wiktionary.org/wiki/pahal%C4%B1#Turkish) | expensive | /pa.haˈɫɯ/ · adj |
| [roman](https://en.wiktionary.org/wiki/roman#Turkish) | A novel (work of fiction). | /ɾoˈman/ · noun |
| [yumurta](https://en.wiktionary.org/wiki/yumurta#Turkish) | egg | /ju.muɾˈta/ · noun |
| [Yahudi](https://en.wiktionary.org/wiki/Yahudi#Turkish) | Jew, adherent of Judaism. | /jɑ.huˈdi/ · noun |
| [anlatmak](https://en.wiktionary.org/wiki/anlatmak#Turkish) | to tell | /ɑn.ɫɑt.ˈmɑk/ · verb |
| [atmak](https://en.wiktionary.org/wiki/atmak#Turkish) | to throw, cast, fire | /atˈmak/ · verb |
| [bisiklet](https://en.wiktionary.org/wiki/bisiklet#Turkish) | bicycle |  · noun |
| [cinsel ilişki](https://en.wiktionary.org/wiki/cinsel%20ili%C5%9Fki#Turkish) | coupling, sex, sexual intercourse |  · noun |
| [deprem](https://en.wiktionary.org/wiki/deprem#Turkish) | earthquake, quake, seism, a shaking of the ground, caused by volcanic activity or movement around geologic faults | /depˈɾem/ · noun |
| [dik](https://en.wiktionary.org/wiki/dik#Turkish) | vertical |  · adj |
| [itiraf etmek](https://en.wiktionary.org/wiki/itiraf%20etmek#Turkish) | to confess |  · verb |
| [köşe](https://en.wiktionary.org/wiki/k%C3%B6%C5%9Fe#Turkish) | corner, angle; nook; bend (of a road, etc.) | /cœˈʃe/ · noun |
| [oh](https://en.wiktionary.org/wiki/oh#Turkish) | exclamation of relief, joy, admiration, liking, etc. | /ˈoh/ · intj |
| [parmak](https://en.wiktionary.org/wiki/parmak#Turkish) | finger, toe, digit | /paɾˈmak/ · noun |
| [anı](https://en.wiktionary.org/wiki/an%C4%B1#Turkish) | memory, | /aˈnɯ/ · noun |
| [bas](https://en.wiktionary.org/wiki/bas#Turkish) | bass | /ˈbas/ · noun |
| [me](https://en.wiktionary.org/wiki/me#Turkish) | baa (sound of a sheep) | /ˈme/ · noun |
| [yağ](https://en.wiktionary.org/wiki/ya%C4%9F#Turkish) | oil | /ˈjaː/ · noun |
| [analiz](https://en.wiktionary.org/wiki/analiz#Turkish) | analysis | /anaˈliz/ · noun |
| [don](https://en.wiktionary.org/wiki/don#Turkish) | underpants |  · noun |
| [organize](https://en.wiktionary.org/wiki/organize#Turkish) | organized | /oɾ.ɡa.niˈze/ · adj |
| [protesto](https://en.wiktionary.org/wiki/protesto#Turkish) | protest | /pɾoˈtes.to/ · noun |
| [romantik](https://en.wiktionary.org/wiki/romantik#Turkish) | romantic |  · adj |
| [salı](https://en.wiktionary.org/wiki/sal%C4%B1#Turkish) | Tuesday | /saˈɫɯ/ · noun |
| [tan](https://en.wiktionary.org/wiki/tan#Turkish) | dawn, twilight |  · noun |
| [ton](https://en.wiktionary.org/wiki/ton#Turkish) | tone, the character of a sound, especially the timbre of an instrument or voice | /ton/ · noun |
| [şok](https://en.wiktionary.org/wiki/%C5%9Fok#Turkish) | shock | [ʃɔk] · noun |

</details>

<details><summary>Words 501–550</summary>

![[Resources/Audio/tr/Words 0501-0550.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [bal](https://en.wiktionary.org/wiki/bal#Turkish) | honey | /ˈbaɫ/ · noun |
| [dağ](https://en.wiktionary.org/wiki/da%C4%9F#Turkish) | mountain, mount, an elevation of land of considerable dimensions rising more or less abruptly, usually higher than a hill | /ˈdaː/ · noun |
| [hal](https://en.wiktionary.org/wiki/hal#Turkish) | covered market | /hal/ · noun |
| [kod](https://en.wiktionary.org/wiki/kod#Turkish) | symbol, sign |  · noun |
| [mali](https://en.wiktionary.org/wiki/mali#Turkish) | financial, fiscal | /maːˈliː/ · adj |
| [politik](https://en.wiktionary.org/wiki/politik#Turkish) | political | /ˈpo.li.tic/ · adj |
| [saray](https://en.wiktionary.org/wiki/saray#Turkish) | palace |  · noun |
| [ölmek](https://en.wiktionary.org/wiki/%C3%B6lmek#Turkish) | to die | /ølˈmec/ · verb |
| [deri](https://en.wiktionary.org/wiki/deri#Turkish) | skin |  · noun |
| [pes](https://en.wiktionary.org/wiki/pes#Turkish) | Used when accepting defeat; "I yield!" or "Uncle!" | /ˈpes/ · intj |
| [ad](https://en.wiktionary.org/wiki/ad#Turkish) | name, first name, last name | /ɑd/ · noun |
| [köprü](https://en.wiktionary.org/wiki/k%C3%B6pr%C3%BC#Turkish) | bridge | /cøpˈɾy/ · noun |
| [namaz](https://en.wiktionary.org/wiki/namaz#Turkish) | salat, prayer | /na.maz/ · noun |
| [nur](https://en.wiktionary.org/wiki/nur#Turkish) | light | /nuɾ/ · noun |
| [yara](https://en.wiktionary.org/wiki/yara#Turkish) | wound, injury | [jɑɾɑ] · noun |
| [direkt](https://en.wiktionary.org/wiki/direkt#Turkish) | directly, straight | /ˈdi.ɾɛct/ · adv |
| [tavuk](https://en.wiktionary.org/wiki/tavuk#Turkish) | hen | /tɑˈvuk/ · noun |
| [testi](https://en.wiktionary.org/wiki/testi#Turkish) | earthenware water jug | /tesˈti/ · noun |
| [ısı](https://en.wiktionary.org/wiki/%C4%B1s%C4%B1#Turkish) | hot, spicy | /ɯˈsɯ/ · adj |
| [ani](https://en.wiktionary.org/wiki/ani#Turkish) | sudden (happening quickly and with little or no warning) | /aːˈniː/ · adj |
| [hat](https://en.wiktionary.org/wiki/hat#Turkish) | line |  · noun |
| [iman](https://en.wiktionary.org/wiki/iman#Turkish) | faith |  · noun |
| [pardon](https://en.wiktionary.org/wiki/pardon#Turkish) | pardon!, pardon me!, excuse me!, I beg your pardon!, sorry! | /ˈpaɾ.don/ · intj |
| [pasta](https://en.wiktionary.org/wiki/pasta#Turkish) | cake | /pɑs.tɑ/ · noun |
| [perşembe](https://en.wiktionary.org/wiki/per%C5%9Fembe#Turkish) | Thursday | /pæɾʃæmˈbe/ · noun |
| [risk](https://en.wiktionary.org/wiki/risk#Turkish) | risk (all senses) | /risc/ · noun |
| [tamir](https://en.wiktionary.org/wiki/tamir#Turkish) | repair, mending, reparation, restoration, the act of repairing or restoring something | /taˈmiɾ/ · noun |
| [fen](https://en.wiktionary.org/wiki/fen#Turkish) | science (only referring to biology, chemistry, physics, and mathematics) | /ˈfen/ · noun |
| [kapak](https://en.wiktionary.org/wiki/kapak#Turkish) | lid, cover |  · noun |
| [paket](https://en.wiktionary.org/wiki/paket#Turkish) | packet | /paˈcet/ · noun |
| [antik](https://en.wiktionary.org/wiki/antik#Turkish) | antique | /anˈtic/ · adj |
| [bırakmak](https://en.wiktionary.org/wiki/b%C4%B1rakmak#Turkish) | to let go, release, relinquish | /bɯ.ɾakˈmak/ · verb |
| [kalem](https://en.wiktionary.org/wiki/kalem#Turkish) | pen, pencil, or any similar writing tool | /kaˈlem/ · noun |
| [kare](https://en.wiktionary.org/wiki/kare#Turkish) | square | /ka.ɾe/ · noun |
| [kol](https://en.wiktionary.org/wiki/kol#Turkish) | arm | /koɫ/ · noun |
| [melek](https://en.wiktionary.org/wiki/melek#Turkish) | angel, an incorporeal and holy messenger from a deity, traditionally depicted as a youthful, winged figure | /meˈlec/ · noun |
| [patates](https://en.wiktionary.org/wiki/patates#Turkish) | potato | /pa.taˈtes/ · noun |
| [sus](https://en.wiktionary.org/wiki/sus#Turkish) | Used to show agreement, that the addressee need not say any more | /ˈsus/ · intj |
| [temas](https://en.wiktionary.org/wiki/temas#Turkish) | contact | /teˈmas/ · noun |
| [yapay](https://en.wiktionary.org/wiki/yapay#Turkish) | artificial, man-made, synthetic | /jaˈpaj/ · adj |
| [Rum](https://en.wiktionary.org/wiki/Rum#Turkish) | Turco-Greek, of or related to the Rumlar, ethnic Greeks living in Turkey and Cyprus |  · adj |
| [gök](https://en.wiktionary.org/wiki/g%C3%B6k#Turkish) | sky | /ˈɟøc/ · noun |
| [marka](https://en.wiktionary.org/wiki/marka#Turkish) | brand | /ˈmɑɾ.kɑ/ · noun |
| [masa](https://en.wiktionary.org/wiki/masa#Turkish) | table | [mɑˈsɑ] · noun |
| [metro](https://en.wiktionary.org/wiki/metro#Turkish) | subway |  · noun |
| [politika](https://en.wiktionary.org/wiki/politika#Turkish) | politics | /po.li.tiˈka/ · noun |
| [ray](https://en.wiktionary.org/wiki/ray#Turkish) | rail |  · noun |
| [sıcaklık](https://en.wiktionary.org/wiki/s%C4%B1cakl%C4%B1k#Turkish) | fever, warmth, temperature | [sɯ.ˈdʒɑk.ɫɯk] · noun |
| [tamir etmek](https://en.wiktionary.org/wiki/tamir%20etmek#Turkish) | to repair, fix, mend, tinker, to restore to good working order | /taːˈmiɾ et.mec/ · verb |
| [yazmak](https://en.wiktionary.org/wiki/yazmak#Turkish) | to write, write down, inscribe | [jɑzmɑk] · verb |

</details>

<details><summary>Words 551–600</summary>

![[Resources/Audio/tr/Words 0551-0600.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [çarşamba](https://en.wiktionary.org/wiki/%C3%A7ar%C5%9Famba#Turkish) | Wednesday | /tʃɑɾʃɑmˈbɑ/ · noun |
| [açmak](https://en.wiktionary.org/wiki/a%C3%A7mak#Turkish) | to open | /ɑt͡ʃˈmɑk/ · verb |
| [beden](https://en.wiktionary.org/wiki/beden#Turkish) | body | /beˈdɛn/ · noun |
| [bira](https://en.wiktionary.org/wiki/bira#Turkish) | beer | [ˈbi.ɾɑ] · noun |
| [davranış](https://en.wiktionary.org/wiki/davran%C4%B1%C5%9F#Turkish) | behaviour, behavior | /dav.ɾɐ.nɯʃ/ · noun |
| [han](https://en.wiktionary.org/wiki/han#Turkish) | khan | /ˈhan/ · noun |
| [kale](https://en.wiktionary.org/wiki/kale#Turkish) | fort; castle; fortress; stronghold | /kɑˈle/ · noun |
| [kurmak](https://en.wiktionary.org/wiki/kurmak#Turkish) | to assemble | /kuɾˈmak/ · verb |
| [laf](https://en.wiktionary.org/wiki/laf#Turkish) | word, speech (something said) | /ˈlaf/ · noun |
| [ok](https://en.wiktionary.org/wiki/ok#Turkish) | arrow |  · noun |
| [oynamak](https://en.wiktionary.org/wiki/oynamak#Turkish) | to play, amuse oneself, fool around | /oj.naˈmak/ · verb |
| [pembe](https://en.wiktionary.org/wiki/pembe#Turkish) | pink | /pæmˈbe/ · noun |
| [tablo](https://en.wiktionary.org/wiki/tablo#Turkish) | painting, picture | /ˈtablo/ · noun |
| [yay](https://en.wiktionary.org/wiki/yay#Turkish) | bow (weapon) |  · noun |
| [bar](https://en.wiktionary.org/wiki/bar#Turkish) | bar, pub | /ˈbaɾ/ · noun |
| [boya](https://en.wiktionary.org/wiki/boya#Turkish) | color | /boˈja/ · noun |
| [do](https://en.wiktionary.org/wiki/do#Turkish) | C (musical note) |  · noun |
| [engin](https://en.wiktionary.org/wiki/engin#Turkish) | vast | /eɲˈɟin/ · adj |
| [has](https://en.wiktionary.org/wiki/has#Turkish) | inherent in | /has/ · adj |
| [inci](https://en.wiktionary.org/wiki/inci#Turkish) | pearl | /inˈd͡ʒi/ · noun |
| [tahliye etmek](https://en.wiktionary.org/wiki/tahliye%20etmek#Turkish) | to release, discharge |  · verb |
| [aniden](https://en.wiktionary.org/wiki/aniden#Turkish) | suddenly | /aː.niˈden/ · adv |
| [av](https://en.wiktionary.org/wiki/av#Turkish) | hunting | /aβ/ · noun |
| [bari](https://en.wiktionary.org/wiki/bari#Turkish) | at least |  · adv |
| [his](https://en.wiktionary.org/wiki/his#Turkish) | feeling, sensation, emotion | /his/ · noun |
| [liste](https://en.wiktionary.org/wiki/liste#Turkish) | list | /lisˈte/ · noun |
| [nun](https://en.wiktionary.org/wiki/nun#Turkish) | Letter of the Arabic alphabet: ن |  · noun |
| [pilot](https://en.wiktionary.org/wiki/pilot#Turkish) | pilot | /piˈlot/ · adj |
| [prenses](https://en.wiktionary.org/wiki/prenses#Turkish) | princess | [pɾɛn.se̞s] · noun |
| [as](https://en.wiktionary.org/wiki/as#Turkish) | ermine |  · noun |
| [diz](https://en.wiktionary.org/wiki/diz#Turkish) | knee |  · noun |
| [maaş](https://en.wiktionary.org/wiki/maa%C5%9F#Turkish) | salary | /maˈaʃ/ · noun |
| [maden](https://en.wiktionary.org/wiki/maden#Turkish) | mine | /maːdɛn/ · noun |
| [zeynep](https://en.wiktionary.org/wiki/zeynep#Turkish) | precious gemstone |  · noun |
| [banyo](https://en.wiktionary.org/wiki/banyo#Turkish) | bathroom | /bɑɲ.jo/ · noun |
| [beşinci](https://en.wiktionary.org/wiki/be%C5%9Finci#Turkish) | fifth | /beʃinˈdʒi/ · adj |
| [dar sokak](https://en.wiktionary.org/wiki/dar%20sokak#Turkish) | alley |  · noun |
| [kemik](https://en.wiktionary.org/wiki/kemik#Turkish) | bone | /ceˈmic/ · noun |
| [kum](https://en.wiktionary.org/wiki/kum#Turkish) | sand | /ˈkum/ · noun |
| [nadir](https://en.wiktionary.org/wiki/nadir#Turkish) | rare | /naːˈdiɾ/ · adj |
| [otuz](https://en.wiktionary.org/wiki/otuz#Turkish) | thirty | /oˈtuz/ · num |
| [tarif](https://en.wiktionary.org/wiki/tarif#Turkish) | definition |  · noun |
| [ziyade](https://en.wiktionary.org/wiki/ziyade#Turkish) | many, much |  · adj |
| [adres](https://en.wiktionary.org/wiki/adres#Turkish) | address (direction for letters) | /ɑd(ɯ)ɾes/ · noun |
| [ata](https://en.wiktionary.org/wiki/ata#Turkish) | ancestor, forefather | /aˈta/ · noun |
| [hain](https://en.wiktionary.org/wiki/hain#Turkish) | perfidious | [haːin] · adj |
| [mimar](https://en.wiktionary.org/wiki/mimar#Turkish) | architect | /miːmɑr/ · noun |
| [nice](https://en.wiktionary.org/wiki/nice#Turkish) | many | /ˈni.d͡ʒe/ · adj |
| [art](https://en.wiktionary.org/wiki/art#Turkish) | hind, rear | /ˈaɾt/ · adj |
| [felsefe](https://en.wiktionary.org/wiki/felsefe#Turkish) | philosophy | /fælseˈfe/ · noun |

</details>

<details><summary>Words 601–650</summary>

![[Resources/Audio/tr/Words 0601-0650.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [harita](https://en.wiktionary.org/wiki/harita#Turkish) | map (visual representation of an area) | /hɑ.ɾi.tɑ/ · noun |
| [insani](https://en.wiktionary.org/wiki/insani#Turkish) | humane |  · adj |
| [mil](https://en.wiktionary.org/wiki/mil#Turkish) | mile (measure of length) | /ˈmil/ · noun |
| [porno](https://en.wiktionary.org/wiki/porno#Turkish) | porn | [ˈpoɾno] · noun |
| [sır](https://en.wiktionary.org/wiki/s%C4%B1r#Turkish) | secret | /sɯɾ/ · noun |
| [amca](https://en.wiktionary.org/wiki/amca#Turkish) | paternal uncle, one's father's brother | /amˈd͡ʒa/ · noun |
| [açlık](https://en.wiktionary.org/wiki/a%C3%A7l%C4%B1k#Turkish) | hunger | [ɑtʃɫɯk] · noun |
| [bela](https://en.wiktionary.org/wiki/bela#Turkish) | affliction, trouble | /be.laː/ · noun |
| [dişi](https://en.wiktionary.org/wiki/di%C5%9Fi#Turkish) | female | /diˈʃi/ · adj |
| [jüri](https://en.wiktionary.org/wiki/j%C3%BCri#Turkish) | jury | /ʒy.ɾi/ · noun |
| [kazan](https://en.wiktionary.org/wiki/kazan#Turkish) | kettle |  · noun |
| [nakit](https://en.wiktionary.org/wiki/nakit#Turkish) | cash | /nɑˈcit/ · noun |
| [tuz](https://en.wiktionary.org/wiki/tuz#Turkish) | salt | /ˈtuz/ · noun |
| [belge](https://en.wiktionary.org/wiki/belge#Turkish) | document | /belˈɟe/ · noun |
| [burun](https://en.wiktionary.org/wiki/burun#Turkish) | nose | /buˈɾun/ · noun |
| [endişe](https://en.wiktionary.org/wiki/endi%C5%9Fe#Turkish) | anxiety, worry, solicitude | /en.di(ː)ˈʃe/ · noun |
| [evvel](https://en.wiktionary.org/wiki/evvel#Turkish) | beginning | /evːæl/ · noun |
| [okumak](https://en.wiktionary.org/wiki/okumak) | to read |  · verb |
| [iklim](https://en.wiktionary.org/wiki/iklim#Turkish) | climate |  · noun |
| [ila](https://en.wiktionary.org/wiki/ila#Turkish) | to, up to, until, between | /iˈɫa/ · postp |
| [karı](https://en.wiktionary.org/wiki/kar%C4%B1#Turkish) | wife |  · noun |
| [lakin](https://en.wiktionary.org/wiki/lakin#Turkish) | but, however | /laːcin/ · conj |
| [perde](https://en.wiktionary.org/wiki/perde#Turkish) | curtain | /pæɾˈde/ · noun |
| [biber](https://en.wiktionary.org/wiki/biber#Turkish) | pepper (vegetable, plant, and spice) |  · noun |
| [blok](https://en.wiktionary.org/wiki/blok#Turkish) | bloc | /ˈb(ɯ)lok/ · noun |
| [esir](https://en.wiktionary.org/wiki/esir#Turkish) | prisoner of war; captive | /e.siɾ/ · noun |
| [set](https://en.wiktionary.org/wiki/set#Turkish) | dam, floodwall (barrier to prevent flooding) | /ˈset/ · noun |
| [yılan](https://en.wiktionary.org/wiki/y%C4%B1lan#Turkish) | snake, any legless reptile of the suborder Serpentes | /jɯ.ˈɫɑn/ · noun |
| [kur](https://en.wiktionary.org/wiki/kur#Turkish) | exchange rate |  · noun |
| [kutu](https://en.wiktionary.org/wiki/kutu#Turkish) | box | /kuˈtu/ · noun |
| [çaba](https://en.wiktionary.org/wiki/%C3%A7aba#Turkish) | effort, exertion | /t͡ʃaˈba/ · noun |
| [alet](https://en.wiktionary.org/wiki/alet#Turkish) | tool | /ɑːˈlet/ · noun |
| [ar](https://en.wiktionary.org/wiki/ar#Turkish) | shame, the feeling of shame | /ˈaɾ/ · noun |
| [protein](https://en.wiktionary.org/wiki/protein#Turkish) | protein | /pɾo.te.in/ · noun |
| [salon](https://en.wiktionary.org/wiki/salon#Turkish) | living room | /saˈɫon/ · noun |
| [teker](https://en.wiktionary.org/wiki/teker#Turkish) | wheel |  · noun |
| [veli](https://en.wiktionary.org/wiki/veli#Turkish) | custodian, guardian | /veˈli(ː)/ · noun |
| [virüs](https://en.wiktionary.org/wiki/vir%C3%BCs#Turkish) | virus | /viˈɾys/ · noun |
| [duş](https://en.wiktionary.org/wiki/du%C5%9F#Turkish) | shower | /ˈduʃ/ · noun |
| [lord](https://en.wiktionary.org/wiki/lord#Turkish) | English lord or nobleman | [ɫoɾd] · noun |
| [maya](https://en.wiktionary.org/wiki/maya#Turkish) | yeast (fungus; froth used in medicine, baking and brewing; cake or dried granules used to make bread dough rise) | /maˈja/ · noun |
| [mezar](https://en.wiktionary.org/wiki/mezar#Turkish) | grave | /meˈzɑɾ/ · noun |
| [mor](https://en.wiktionary.org/wiki/mor#Turkish) | purple | /moɾ/ · noun |
| [tuvalet](https://en.wiktionary.org/wiki/tuvalet#Turkish) | toilet, lavatory, privy, w.c., a (bath)room containing a toilet | /tuvɑlet/ · noun |
| [duman](https://en.wiktionary.org/wiki/duman#Turkish) | smoke, roke | /duˈman/ · noun |
| [elma](https://en.wiktionary.org/wiki/elma#Turkish) | apple tree | /elˈma/ · noun |
| [af](https://en.wiktionary.org/wiki/af#Turkish) | pardon | /ɑf/ · noun |
| [aramak](https://en.wiktionary.org/wiki/aramak#Turkish) | to seek, to look for, to search | /ɑɾɑmɑk/ · verb |
| [elle](https://en.wiktionary.org/wiki/elle#Turkish) | by hand, manually |  · adv |
| [fakir](https://en.wiktionary.org/wiki/fakir#Turkish) | fakir (an ascetic mendicant) | /fɑcir/ · noun |

</details>

<details><summary>Words 651–700</summary>

![[Resources/Audio/tr/Words 0651-0700.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [festival](https://en.wiktionary.org/wiki/festival#Turkish) | festival | [festiˈval] · noun |
| [holding](https://en.wiktionary.org/wiki/holding#Turkish) | holding company | /hɔl.diɲɟ/ · noun |
| [pamuk](https://en.wiktionary.org/wiki/pamuk#Turkish) | cotton |  · noun |
| [zam](https://en.wiktionary.org/wiki/zam#Turkish) | surcharge | [zɑm] · noun |
| [böcek](https://en.wiktionary.org/wiki/b%C3%B6cek#Turkish) | bug, insect | /bøˈd͡ʒec/ · noun |
| [tekrarlamak](https://en.wiktionary.org/wiki/tekrarlamak) | to repeat |  · verb |
| [kahverengi](https://en.wiktionary.org/wiki/kahverengi#Turkish) | brown | /kɑhˈve.ɾen.ɟi/ · noun |
| [kömür](https://en.wiktionary.org/wiki/k%C3%B6m%C3%BCr#Turkish) | coal | /cø.myɾ/ · noun |
| [macera](https://en.wiktionary.org/wiki/macera#Turkish) | adventure |  · noun |
| [meydan okuma](https://en.wiktionary.org/wiki/meydan%20okuma#Turkish) | challenge, defiance |  · noun |
| [miras](https://en.wiktionary.org/wiki/miras#Turkish) | inheritance | /miː.ɾas/ · noun |
| [tavan](https://en.wiktionary.org/wiki/tavan#Turkish) | ceiling | /tɑvɑn/ · noun |
| [villa](https://en.wiktionary.org/wiki/villa#Turkish) | mansion |  · noun |
| [ıslak](https://en.wiktionary.org/wiki/%C4%B1slak#Turkish) | wet | /ɯsˈɫak/ · adj |
| [alarm](https://en.wiktionary.org/wiki/alarm#Turkish) | alarm | /a.laɾm/ · noun |
| [hesap makinesi](https://en.wiktionary.org/wiki/hesap%20makinesi#Turkish) | calculator (electronic device that performs mathematical calculations) | /heˈsap ma.ci.ne.si/ · noun |
| [pas](https://en.wiktionary.org/wiki/pas#Turkish) | rust (oxidation of metal) | /ˈpas/ · noun |
| [CD](https://en.wiktionary.org/wiki/CD#Turkish) | CD, compact disc | /siːˈdiː/ · noun |
| [bank](https://en.wiktionary.org/wiki/bank#Turkish) | bench (long seat) | /ˈbank/ · noun |
| [kanat](https://en.wiktionary.org/wiki/kanat#Turkish) | wing (part of an animal) | /kaˈnat/ · noun |
| [kek](https://en.wiktionary.org/wiki/kek#Turkish) | cake |  · noun |
| [koru](https://en.wiktionary.org/wiki/koru#Turkish) | grove |  · noun |
| [liman](https://en.wiktionary.org/wiki/liman#Turkish) | port, haven, harbor | /liˈman/ · noun |
| [ezberlemek](https://en.wiktionary.org/wiki/ezberlemek) | to memorise |  · verb |
| [sel](https://en.wiktionary.org/wiki/sel#Turkish) | flood | /ˈsæl/ · noun |
| [çatı](https://en.wiktionary.org/wiki/%C3%A7at%C4%B1#Turkish) | roof |  · noun |
| [bahçe](https://en.wiktionary.org/wiki/bah%C3%A7e#Turkish) | garden | [bɑhˈtʃe] · noun |
| [cinsiyet](https://en.wiktionary.org/wiki/cinsiyet#Turkish) | sexuality | /d͡ʒin.siˈjet/ · noun |
| [iri](https://en.wiktionary.org/wiki/iri#Turkish) | large | /iˈɾi/ · adj |
| [men](https://en.wiktionary.org/wiki/men#Turkish) | An act of prohibiting, forbidding | /ˈmɛn/ · noun |
| [ramazan](https://en.wiktionary.org/wiki/ramazan#Turkish) | Ramadan (the holy ninth month of the Islamic lunar calendar, during which Muslims fast between the break of dawn until sunset; they also refrain from drinking liquids, smoking and having sexual relations) | /ɾɑmɑˈzɑn/ · noun |
| [sonbahar](https://en.wiktionary.org/wiki/sonbahar#Turkish) | autumn, fall | /ˈsɔnˌbɑhɑɾ/ · noun |
| [sırt](https://en.wiktionary.org/wiki/s%C4%B1rt#Turkish) | back (the rear of body) |  · noun |
| [ulu](https://en.wiktionary.org/wiki/ulu#Turkish) | elder | /uˈɫu/ · noun |
| [kas](https://en.wiktionary.org/wiki/kas#Turkish) | A muscle. | [kɑs] · noun |
| [pop](https://en.wiktionary.org/wiki/pop#Turkish) | pop |  · noun |
| [robot](https://en.wiktionary.org/wiki/robot#Turkish) | robot | /ɾoˈbot/ · noun |
| [göl](https://en.wiktionary.org/wiki/g%C3%B6l#Turkish) | lake, a large, landlocked stretch of water or similar liquid | /ˈɟøl/ · noun |
| [ham](https://en.wiktionary.org/wiki/ham#Turkish) | unripe | /hɑm/ · adj |
| [mevsim](https://en.wiktionary.org/wiki/mevsim#Turkish) | season (part of a year) | /mevˈsim/ · noun |
| [pencere](https://en.wiktionary.org/wiki/pencere#Turkish) | window, an opening which allows light and air from the outside to enter a building | /ˈpen.d͡ʒe.ɾe/ · noun |
| [pirinç](https://en.wiktionary.org/wiki/pirin%C3%A7#Turkish) | rice | /piˈɾint͡ʃ/ · noun |
| [yo](https://en.wiktionary.org/wiki/yo#Turkish) | no | /joː/ · intj |
| [zehir](https://en.wiktionary.org/wiki/zehir#Turkish) | poison, venom, toxin | /zeˈhiɾ/ · noun |
| [dul](https://en.wiktionary.org/wiki/dul#Turkish) | widow, widower | /ˈduɫ/ · noun |
| [elli](https://en.wiktionary.org/wiki/elli#Turkish) | fifty | /elˈli/ · num |
| [fare](https://en.wiktionary.org/wiki/fare#Turkish) | mouse | /fɑːɾe/ · noun |
| [gezegen](https://en.wiktionary.org/wiki/gezegen#Turkish) | planet | /ɟe.zeˈɟen/ · noun |
| [ideal](https://en.wiktionary.org/wiki/ideal#Turkish) | ideal | /ideˈɑl/ · adj |
| [kök](https://en.wiktionary.org/wiki/k%C3%B6k#Turkish) | root | /ˈcøc/ · noun |

</details>

<details><summary>Words 701–750</summary>

![[Resources/Audio/tr/Words 0701-0750.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [platform](https://en.wiktionary.org/wiki/platform#Turkish) | platform |  · noun |
| [tepe](https://en.wiktionary.org/wiki/tepe#Turkish) | hill | /teˈpe/ · noun |
| [akar](https://en.wiktionary.org/wiki/akar#Turkish) | flowing |  · adj |
| [bedel](https://en.wiktionary.org/wiki/bedel#Turkish) | equivalent | /beˈdel/ · adj |
| [benzin](https://en.wiktionary.org/wiki/benzin#Turkish) | gasoline | /benˈzin/ · noun |
| [bilge](https://en.wiktionary.org/wiki/bilge#Turkish) | wise, sage, profound | /bilˈɟe/ · adj |
| [domuz](https://en.wiktionary.org/wiki/domuz#Turkish) | pig, swine | /doˈmuz/ · noun |
| [mide](https://en.wiktionary.org/wiki/mide#Turkish) | stomach | /miːde/ · noun |
| [mit](https://en.wiktionary.org/wiki/mit#Turkish) | myth | /ˈmit/ · noun |
| [oran](https://en.wiktionary.org/wiki/oran#Turkish) | proportion, ratio | /oˈɾan/ · noun |
| [papa](https://en.wiktionary.org/wiki/papa#Turkish) | pope | /pɑˈpɑ/ · noun |
| [post](https://en.wiktionary.org/wiki/post#Turkish) | fur, hide, pelt | [post] · noun |
| [profil](https://en.wiktionary.org/wiki/profil#Turkish) | profile (shape, view, or shadow of a person's head from the side) | /pɾoˈfil/ · noun |
| [sade](https://en.wiktionary.org/wiki/sade#Turkish) | plain |  · adj |
| [taksi](https://en.wiktionary.org/wiki/taksi#Turkish) | taxi | /ˈtak.si/ · noun |
| [yem](https://en.wiktionary.org/wiki/yem#Turkish) | feed, fodder | /ˈjem/ · noun |
| [üzüm](https://en.wiktionary.org/wiki/%C3%BCz%C3%BCm#Turkish) | grape, a small, round, smooth-skinned edible fruit of the genus Vitis, that grows in bunches on vines | /yˈzym/ · noun |
| [ayna](https://en.wiktionary.org/wiki/ayna#Turkish) | mirror | /ajˈna/ · noun |
| [bel](https://en.wiktionary.org/wiki/bel#Turkish) | waist | /ˈbel/ · noun |
| [bot](https://en.wiktionary.org/wiki/bot#Turkish) | boot | /ˈbot/ · noun |
| [malum](https://en.wiktionary.org/wiki/malum#Turkish) | known, certain | /maː.ˈlum/ · adj |
| [tenis](https://en.wiktionary.org/wiki/tenis#Turkish) | tennis | /tenis/ · noun |
| [altıncı](https://en.wiktionary.org/wiki/alt%C4%B1nc%C4%B1#Turkish) | sixth | /aɫ.tɯnˈd͡ʒɯ/ · adj |
| [baz](https://en.wiktionary.org/wiki/baz#Turkish) | base of something | /ˈbaz/ · noun |
| [mert](https://en.wiktionary.org/wiki/mert#Turkish) | valiant, valorous, manly | /mært/ · adj |
| [pay](https://en.wiktionary.org/wiki/pay#Turkish) | portion | [paj] · noun |
| [zehirli](https://en.wiktionary.org/wiki/zehirli#Turkish) | poisonous, venomous | /ze.hiɾˈli/ · adj |
| [bakır](https://en.wiktionary.org/wiki/bak%C4%B1r#Turkish) | copper | /baˈkɯɾ/ · noun |
| [divan](https://en.wiktionary.org/wiki/divan#Turkish) | divan, a collection of poems, especially one written by an author in Arabic or Persian | /diːˈvan/ · noun |
| [firma](https://en.wiktionary.org/wiki/firma#Turkish) | firm |  · noun |
| [karma](https://en.wiktionary.org/wiki/karma#Turkish) | mixed | /kaɾˈma/ · adj |
| [reis](https://en.wiktionary.org/wiki/reis#Turkish) | captain of a small boat | /ɾe(j)ˈis/ · noun |
| [çorba](https://en.wiktionary.org/wiki/%C3%A7orba#Turkish) | soup | /t͡ʃoɾˈba/ · noun |
| [ardında](https://en.wiktionary.org/wiki/ard%C4%B1nda#Turkish) | behind |  · postp |
| [buğday](https://en.wiktionary.org/wiki/bu%C4%9Fday#Turkish) | wheat, any of several cereal grains of the genus Triticum |  · noun |
| [dal](https://en.wiktionary.org/wiki/dal#Turkish) | branch | /daɫ/ · noun |
| [favori](https://en.wiktionary.org/wiki/favori#Turkish) | favourite (UK) / favorite (US) | /fa.vɔ.ɾi/ · adj |
| [kap](https://en.wiktionary.org/wiki/kap#Turkish) | vessel, can, container, holder, pot, case | /kɑp/ · noun |
| [meme](https://en.wiktionary.org/wiki/meme#Turkish) | breast | /meˈme/ · noun |
| [tak](https://en.wiktionary.org/wiki/tak#Turkish) | arch |  · noun |
| [taklit etmek](https://en.wiktionary.org/wiki/taklit%20etmek#Turkish) | to imitate | /taklit etmec/ · verb |
| [tez](https://en.wiktionary.org/wiki/tez#Turkish) | essay | /ˈtez/ · noun |
| [akademi](https://en.wiktionary.org/wiki/akademi#Turkish) | academy |  · noun |
| [bit](https://en.wiktionary.org/wiki/bit#Turkish) | louse belonging to genus Pediculus | /ˈbit/ · noun |
| [bravo](https://en.wiktionary.org/wiki/bravo#Turkish) | well done!, good show! | /b(ɯ)ɾɑ.vo/ · intj |
| [kasa](https://en.wiktionary.org/wiki/kasa#Turkish) | case | /ˈkɑ.sɑ/ · noun |
| [Sami](https://en.wiktionary.org/wiki/Sami#Turkish) | Semite |  · noun |
| [aya](https://en.wiktionary.org/wiki/aya#Turkish) | palm (of hand) |  · noun |
| [haram](https://en.wiktionary.org/wiki/haram#Turkish) | haram (forbidden by religion) | [hä.ɾäm] · adj |
| [sami](https://en.wiktionary.org/wiki/sami#Turkish) | high, lofty, elevated |  · adj |

</details>

<details><summary>Words 751–800</summary>

![[Resources/Audio/tr/Words 0751-0800.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [tercüme](https://en.wiktionary.org/wiki/terc%C3%BCme#Turkish) | translation | /teɾ.d͡ʒyˈme/ · noun |
| [ulan](https://en.wiktionary.org/wiki/ulan#Turkish) | Said to get someone's attention in a rude or colloquial manner. | /uˈɫan/ · intj |
| [Çinli](https://en.wiktionary.org/wiki/%C3%87inli#Turkish) | Chinese |  · adj |
| [şah](https://en.wiktionary.org/wiki/%C5%9Fah#Turkish) | shah, ruler |  · noun |
| [arz](https://en.wiktionary.org/wiki/arz#Turkish) | earth | [aɾz] · noun |
| [beste](https://en.wiktionary.org/wiki/beste#Turkish) | musical composition | /besˈte/ · noun |
| [hile](https://en.wiktionary.org/wiki/hile#Turkish) | deceit, ruse, trick | /hiːˈle/ · noun |
| [kin](https://en.wiktionary.org/wiki/kin#Turkish) | grudge, desire to take revenge | /ˈcin/ · noun |
| [satmak](https://en.wiktionary.org/wiki/satmak#Turkish) | to sell, to market | /satˈmak/ · verb |
| [tesis](https://en.wiktionary.org/wiki/tesis#Turkish) | facility | /teːˈsis/ · noun |
| [çoban](https://en.wiktionary.org/wiki/%C3%A7oban#Turkish) | shepherd | /t͡ʃoˈban/ · noun |
| [şişe](https://en.wiktionary.org/wiki/%C5%9Fi%C5%9Fe#Turkish) | bottle | /ʃiˈʃe/ · noun |
| [beton](https://en.wiktionary.org/wiki/beton#Turkish) | concrete (building material) |  · noun |
| [cadde](https://en.wiktionary.org/wiki/cadde#Turkish) | avenue | [d͡ʒäd̪.d̪e̞] · noun |
| [erkenden](https://en.wiktionary.org/wiki/erkenden#Turkish) | early on | /eɾ.cenˈden/ · adv |
| [kurul](https://en.wiktionary.org/wiki/kurul#Turkish) | board (of directors, judges, etc.) |  · noun |
| [limon](https://en.wiktionary.org/wiki/limon#Turkish) | lemon (citrus fruit) | /liˈmon/ · noun |
| [ot](https://en.wiktionary.org/wiki/ot#Turkish) | grass | /ˈot/ · noun |
| [reel](https://en.wiktionary.org/wiki/reel#Turkish) | real | /ɾeæ̯l/ · adj |
| [tank](https://en.wiktionary.org/wiki/tank#Turkish) | tank | /ˈtank/ · noun |
| [tolga](https://en.wiktionary.org/wiki/tolga#Turkish) | synonym of miğfer (“helmet”) | /toˈɫɡa/ · noun |
| [yak](https://en.wiktionary.org/wiki/yak#Turkish) | yak (ox-like mammal) |  · noun |
| [alfa](https://en.wiktionary.org/wiki/alfa#Turkish) | alpha; the Greek letter Α, α | /ˈal.fa/ · noun |
| [atom](https://en.wiktionary.org/wiki/atom#Turkish) | atom | [ɑˈtɔm] · noun |
| [boğaz](https://en.wiktionary.org/wiki/bo%C4%9Faz#Turkish) | throat | /boˈaz/ · noun |
| [cadı](https://en.wiktionary.org/wiki/cad%C4%B1#Turkish) | A sorcerer, wizard, a female witch. | /d͡ʒaˈdɯ/ · noun |
| [istemek](https://en.wiktionary.org/wiki/istemek#Turkish) | to want, desire, wish | /is.teˈmec/ · verb |
| [lens](https://en.wiktionary.org/wiki/lens#Turkish) | contact lens |  · noun |
| [maske](https://en.wiktionary.org/wiki/maske#Turkish) | mask |  · noun |
| [yüzük](https://en.wiktionary.org/wiki/y%C3%BCz%C3%BCk#Turkish) | ring, a round piece of (precious) metal worn around the finger. |  · noun |
| [borsa](https://en.wiktionary.org/wiki/borsa#Turkish) | stock market |  · noun |
| [estetik](https://en.wiktionary.org/wiki/estetik#Turkish) | aesthetics | /es.te.tic/ · noun |
| [hac](https://en.wiktionary.org/wiki/hac#Turkish) | The act of visiting a sacred place during certain times of the year, generally in monotheistic religions; pilgrimage. | /ˈhɑd͡ʒ/ · noun |
| [jet](https://en.wiktionary.org/wiki/jet#Turkish) | jet | /ʒet/ · noun |
| [kul](https://en.wiktionary.org/wiki/kul#Turkish) | slave | /ˈkʊl/ · noun |
| [kâr](https://en.wiktionary.org/wiki/k%C3%A2r#Turkish) | profit | /ˈcaːɾ/ · noun |
| [mantar](https://en.wiktionary.org/wiki/mantar#Turkish) | mushroom | /manˈtaɾ/ · noun |
| [mola](https://en.wiktionary.org/wiki/mola#Turkish) | rest, break, pause | /ˈmo.ɫa/ · noun |
| [optik](https://en.wiktionary.org/wiki/optik#Turkish) | optic, optical | /opˈtic/ · adj |
| [pizza](https://en.wiktionary.org/wiki/pizza#Turkish) | pizza (Italian dish) | /ˈpi(z)zɑ/ · noun |
| [prim](https://en.wiktionary.org/wiki/prim#Turkish) | prize |  · noun |
| [propaganda](https://en.wiktionary.org/wiki/propaganda#Turkish) | propaganda |  · noun |
| [arı](https://en.wiktionary.org/wiki/ar%C4%B1#Turkish) | bee | /aˈɾɯ/ · noun |
| [etiket](https://en.wiktionary.org/wiki/etiket#Turkish) | label, tag | /eticet/ · noun |
| [helikopter](https://en.wiktionary.org/wiki/helikopter#Turkish) | helicopter | /he.li.kɔp.tɛɾ/ · noun |
| [kayak](https://en.wiktionary.org/wiki/kayak#Turkish) | ski |  · noun |
| [kola](https://en.wiktionary.org/wiki/kola#Turkish) | cola (plant) |  · noun |
| [manuel](https://en.wiktionary.org/wiki/manuel#Turkish) | manual (operated by hand; not automated) | /ma.nuˈel/ · adj |
| [organ](https://en.wiktionary.org/wiki/organ#Turkish) | organ | /oɾˈɡan/ · noun |
| [plak](https://en.wiktionary.org/wiki/plak#Turkish) | gramophone record, vinyl record |  · noun |

</details>

<details><summary>Words 801–850</summary>

![[Resources/Audio/tr/Words 0801-0850.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [sav](https://en.wiktionary.org/wiki/sav#Turkish) | contention |  · noun |
| [vaka](https://en.wiktionary.org/wiki/vaka#Turkish) | event, case (chiefly in medical, psychological and judicial contexts) | /va.kɐ/ · noun |
| [yedinci](https://en.wiktionary.org/wiki/yedinci#Turkish) | seventh | /je.din.dʒi/ · adj |
| [çamur](https://en.wiktionary.org/wiki/%C3%A7amur#Turkish) | mud | /t͡ʃaˈmuɾ/ · noun |
| [şoför](https://en.wiktionary.org/wiki/%C5%9Fof%C3%B6r#Turkish) | driver | /ʃoˈføɾ/ · noun |
| [ikiz](https://en.wiktionary.org/wiki/ikiz#Turkish) | twin |  · noun |
| [moral](https://en.wiktionary.org/wiki/moral#Turkish) | morale, good spirits | /mo.ɾal/ · noun |
| [nasip](https://en.wiktionary.org/wiki/nasip#Turkish) | That which falls on one's share; lot, fortune. | /naˈsip/ · noun |
| [sağır](https://en.wiktionary.org/wiki/sa%C4%9F%C4%B1r#Turkish) | deaf | /sɑ.ɯɾ/ · adj |
| [sevmek](https://en.wiktionary.org/wiki/sevmek#Turkish) | to love | /sev.ˈmec/ · verb |
| [sur](https://en.wiktionary.org/wiki/sur#Turkish) | city wall |  · noun |
| [tüfek](https://en.wiktionary.org/wiki/t%C3%BCfek#Turkish) | rifle | /tyˈfec/ · noun |
| [özen](https://en.wiktionary.org/wiki/%C3%B6zen#Turkish) | Attention and care given to a task at hand; pains. | /øˈzœn/ · noun |
| [ajan](https://en.wiktionary.org/wiki/ajan#Turkish) | agent (someone who works for an intelligence agency) | /ɑ.ʒɑn/ · noun |
| [boks](https://en.wiktionary.org/wiki/boks#Turkish) | boxing |  · noun |
| [dere](https://en.wiktionary.org/wiki/dere#Turkish) | creek, small river | /deˈɾe/ · noun |
| [ejderha](https://en.wiktionary.org/wiki/ejderha#Turkish) | dragon | /eʒ.deɾˈhaː/ · noun |
| [erik](https://en.wiktionary.org/wiki/erik#Turkish) | plum | [eˈɾic] · noun |
| [etek](https://en.wiktionary.org/wiki/etek#Turkish) | skirt | [e̞ˈt̪ʰɛc] · noun |
| [haz](https://en.wiktionary.org/wiki/haz#Turkish) | joy, pleasure | /ˈhaz/ · noun |
| [illa](https://en.wiktionary.org/wiki/illa#Turkish) | no matter what, in any case, under any circumstances | /ˈil.laː/ · adv |
| [kürek](https://en.wiktionary.org/wiki/k%C3%BCrek#Turkish) | oar, paddle | /cy.ɾec/ · noun |
| [opera](https://en.wiktionary.org/wiki/opera#Turkish) | opera | /oˈpe.ɾa/ · noun |
| [pil](https://en.wiktionary.org/wiki/pil#Turkish) | battery | /ˈpil/ · noun |
| [soluk](https://en.wiktionary.org/wiki/soluk#Turkish) | Having lost color; pale, faded, pasty. | /soˈɫuk/ · adj |
| [çarşı](https://en.wiktionary.org/wiki/%C3%A7ar%C5%9F%C4%B1#Turkish) | market |  · noun |
| [kanka](https://en.wiktionary.org/wiki/kanka#Turkish) | best friend | /ˈkan.ka/ · noun |
| [kuzu](https://en.wiktionary.org/wiki/kuzu#Turkish) | lamb, sheepling, yeanling, a little or young sheep | /kuˈzu/ · noun |
| [lale](https://en.wiktionary.org/wiki/lale#Turkish) | tulip, any flowering plant of the genus Tulipa | /laːˈle/ · noun |
| [master](https://en.wiktionary.org/wiki/master#Turkish) | master's degree | /ˈmas.tɯɾ/ · noun |
| [vampir](https://en.wiktionary.org/wiki/vampir#Turkish) | vampire | [βampíɾ] · noun |
| [vefa](https://en.wiktionary.org/wiki/vefa#Turkish) | loyalty, faithfulness | /veˈfaː/ · noun |
| [yelken](https://en.wiktionary.org/wiki/yelken#Turkish) | sail | /jelˈcen/ · noun |
| [yürümek](https://en.wiktionary.org/wiki/y%C3%BCr%C3%BCmek#Turkish) | to walk | /jy.ɾyˈmec/ · verb |
| [Nazi](https://en.wiktionary.org/wiki/Nazi#Turkish) | Nazi | /ˈnɑ.zi/ · adj |
| [bitmek](https://en.wiktionary.org/wiki/bitmek#Turkish) | to end, to finish | /bitˈmek/ · verb |
| [foto](https://en.wiktionary.org/wiki/foto#Turkish) | photo |  · noun |
| [turuncu](https://en.wiktionary.org/wiki/turuncu#Turkish) | orange (colour) | /tu.ɾunˈd͡ʒu/ · noun |
| [hayalet](https://en.wiktionary.org/wiki/hayalet#Turkish) | ghost | /ha.jaˈlet/ · noun |
| [mum](https://en.wiktionary.org/wiki/mum#Turkish) | candle | /mum/ · noun |
| [geliştirmek](https://en.wiktionary.org/wiki/geli%C5%9Ftirmek) | to develop; to improve |  · verb |
| [sis](https://en.wiktionary.org/wiki/sis#Turkish) | fog |  · noun |
| [sulu](https://en.wiktionary.org/wiki/sulu#Turkish) | aqueous, juicy, watery | /suˈɫu/ · adj |
| [tema](https://en.wiktionary.org/wiki/tema#Turkish) | theme, subject |  · noun |
| [alp](https://en.wiktionary.org/wiki/alp#Turkish) | brave, heroic | /ˈaɫp/ · adj |
| [boğa](https://en.wiktionary.org/wiki/bo%C4%9Fa#Turkish) | bull, a domesticated adult male of the species Bos taurus, specifically one that is uncastrated | /boˈa/ · noun |
| [burs](https://en.wiktionary.org/wiki/burs#Turkish) | scholarship (grant to student) |  · noun |
| [dudak](https://en.wiktionary.org/wiki/dudak#Turkish) | lip | [duˈdɑk] · noun |
| [forum](https://en.wiktionary.org/wiki/forum#Turkish) | forum | /foˈɾum/ · noun |
| [mermer](https://en.wiktionary.org/wiki/mermer#Turkish) | marble, a metamorphic rock |  · noun |

</details>

<details><summary>Words 851–900</summary>

![[Resources/Audio/tr/Words 0851-0900.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [partner](https://en.wiktionary.org/wiki/partner#Turkish) | partner | /paɾt.nɛɾ/ · noun |
| [peri](https://en.wiktionary.org/wiki/peri#Turkish) | fairy, pixie | /peˈɾi/ · noun |
| [soykırım](https://en.wiktionary.org/wiki/soyk%C4%B1r%C4%B1m#Turkish) | genocide | /ˈsoj.kɯ.ɾɯm/ · noun |
| [ter](https://en.wiktionary.org/wiki/ter#Turkish) | sweat | /tæɾ/ · noun |
| [zenci](https://en.wiktionary.org/wiki/zenci#Turkish) | black person of African descent, Negro | /zenˈdʒi/ · noun |
| [çorap](https://en.wiktionary.org/wiki/%C3%A7orap#Turkish) | sock, stocking | /t͡ʃoˈɾap/ · noun |
| [blog](https://en.wiktionary.org/wiki/blog#Turkish) | blog |  · noun |
| [boz](https://en.wiktionary.org/wiki/boz#Turkish) | grizzle | /boz/ · adj |
| [kule](https://en.wiktionary.org/wiki/kule#Turkish) | tower |  · noun |
| [mars](https://en.wiktionary.org/wiki/mars#Turkish) | gammon, a victory in backgammon achieved when the opponent has not borne off a single stone | /ˈmaɾs/ · noun |
| [patron](https://en.wiktionary.org/wiki/patron#Turkish) | boss | /pat.ɾɔn/ · noun |
| [salt](https://en.wiktionary.org/wiki/salt#Turkish) | exclusively, only, just, absolute | /saɫt/ · adv |
| [server](https://en.wiktionary.org/wiki/server#Turkish) | server | /sæɾˈvæɾ/ · noun |
| [soğan](https://en.wiktionary.org/wiki/so%C4%9Fan#Turkish) | onion; the bulbs of the plant Allium cepa | /soːan/ · noun |
| [sözlük](https://en.wiktionary.org/wiki/s%C3%B6zl%C3%BCk#Turkish) | dictionary | /søzˈlyc/ · noun |
| [DVD](https://en.wiktionary.org/wiki/DVD#Turkish) | DVD (optical disc) | /diː.viːˈdiː/ · noun |
| [alo](https://en.wiktionary.org/wiki/alo#Turkish) | hello (only when picking up the phone) | /ˈɑlʲo/ · intj |
| [casus](https://en.wiktionary.org/wiki/casus#Turkish) | spy | /d͡ʒaːˈsus/ · noun |
| [damar](https://en.wiktionary.org/wiki/damar#Turkish) | vein, blood vessel |  · noun |
| [düş](https://en.wiktionary.org/wiki/d%C3%BC%C5%9F#Turkish) | dream | /ˈdyʃ/ · noun |
| [inek](https://en.wiktionary.org/wiki/inek#Turkish) | cow | /iˈnec/ · noun |
| [kaan](https://en.wiktionary.org/wiki/kaan#Turkish) | ruler, sovereign | /kaːan/ · noun |
| [muhtar](https://en.wiktionary.org/wiki/muhtar#Turkish) | muhtar, an elected village or neighborhood headman |  · noun |
| [papaz](https://en.wiktionary.org/wiki/papaz#Turkish) | clergyman, priest | [pɑ.ˈpɑz] · noun |
| [tilki](https://en.wiktionary.org/wiki/tilki#Turkish) | fox (Vulpes vulpes) |  · noun |
| [form](https://en.wiktionary.org/wiki/form#Turkish) | form |  · noun |
| [gen](https://en.wiktionary.org/wiki/gen#Turkish) | A field that wasn't plowed for several years. | /ɟæn/ · noun |
| [grip](https://en.wiktionary.org/wiki/grip#Turkish) | flu, influenza, grippe | /ˈɟɾip/ · noun |
| [like](https://en.wiktionary.org/wiki/like#Turkish) | like | /ˈlajk/ · noun |
| [maymun](https://en.wiktionary.org/wiki/maymun#Turkish) | monkey, ape, primate, simian, any mammal in the order Primates except hominids | /majˈmun/ · noun |
| [oğlan](https://en.wiktionary.org/wiki/o%C4%9Flan#Turkish) | boy, male child | /oːˈɫan/ · noun |
| [teori](https://en.wiktionary.org/wiki/teori#Turkish) | theory | [teːoɾi] · noun |
| [trend](https://en.wiktionary.org/wiki/trend#Turkish) | trend | /tɾɛnd/ · noun |
| [yar](https://en.wiktionary.org/wiki/yar#Turkish) | cliff, scarp, precipice | /jɑɾ/ · noun |
| [asfalt](https://en.wiktionary.org/wiki/asfalt#Turkish) | asphalt |  · noun |
| [bereket](https://en.wiktionary.org/wiki/bereket#Turkish) | thank God, luckily, good thing | /be.ɾeˈcet/ · adv |
| [dana](https://en.wiktionary.org/wiki/dana#Turkish) | calf (young of cattle) |  · noun |
| [devir](https://en.wiktionary.org/wiki/devir#Turkish) | age | /deˈviɾ/ · noun |
| [ilke](https://en.wiktionary.org/wiki/ilke#Turkish) | principle | /il.ˈce/ · noun |
| [serin](https://en.wiktionary.org/wiki/serin#Turkish) | between warm and cold; cool, chilly. | /seˈɾin/ · adj |
| [tavşan](https://en.wiktionary.org/wiki/tav%C5%9Fan#Turkish) | rabbit, bunny, a mammal with long ears and a short, fluffy tail | /tɑvˈʃɑn/ · noun |
| [ölçü](https://en.wiktionary.org/wiki/%C3%B6l%C3%A7%C3%BC#Turkish) | measurement | /ølˈt͡ʃy/ · noun |
| [akrep](https://en.wiktionary.org/wiki/akrep#Turkish) | scorpion | /ɑkˈɾep/ · noun |
| [fil](https://en.wiktionary.org/wiki/fil#Turkish) | elephant, a mammal of the order Proboscidea, having a large trunk | /ˈfil/ · noun |
| [nem](https://en.wiktionary.org/wiki/nem#Turkish) | moisture | /nem/ · noun |
| [tat](https://en.wiktionary.org/wiki/tat#Turkish) | taste | /ˈtat/ · noun |
| [hece](https://en.wiktionary.org/wiki/hece) | syllable |  · noun |
| [kaşık](https://en.wiktionary.org/wiki/ka%C5%9F%C4%B1k#Turkish) | spoon, a scooped utensil whose long handle is straight, used for eating or serving | /kaˈʃɯk/ · noun |
| [kura](https://en.wiktionary.org/wiki/kura#Turkish) | Choosing the outcome among two or more candidates by chance; drawing lots, drawing straws. | /ku.ɾaː/ · noun |
| [stil](https://en.wiktionary.org/wiki/stil#Turkish) | style (manner of doing something) | /stil/ · noun |

</details>

<details><summary>Words 901–950</summary>

![[Resources/Audio/tr/Words 0901-0950.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [feci](https://en.wiktionary.org/wiki/feci#Turkish) | disastrous; tragic; terrifying | [fed͡ʒiː] · adj |
| [filo](https://en.wiktionary.org/wiki/filo#Turkish) | fleet; squadron, line of battle |  · noun |
| [piyade](https://en.wiktionary.org/wiki/piyade#Turkish) | infantryman, foot soldier |  · noun |
| [yastık](https://en.wiktionary.org/wiki/yast%C4%B1k#Turkish) | pillow, cushion, a soft mass used to support the head and neck in bed while sleeping | /jasˈtɯk/ · noun |
| [duru](https://en.wiktionary.org/wiki/duru#Turkish) | clear, transparent | /duˈɾu/ · adj |
| [idrar](https://en.wiktionary.org/wiki/idrar#Turkish) | urine |  · noun |
| [mama](https://en.wiktionary.org/wiki/mama#Turkish) | baby food | /maˈma/ · noun |
| [sinek](https://en.wiktionary.org/wiki/sinek#Turkish) | fly (insect) | /sinɛc/ · noun |
| [kaz](https://en.wiktionary.org/wiki/kaz#Turkish) | goose | /ˈkaz/ · noun |
| [liberal](https://en.wiktionary.org/wiki/liberal#Turkish) | liberal |  · adj |
| [market](https://en.wiktionary.org/wiki/market#Turkish) | market | /mɑɾ.cet/ · noun |
| [montaj](https://en.wiktionary.org/wiki/montaj#Turkish) | edit, editing | /mɔn.taʒ/ · noun |
| [sığır](https://en.wiktionary.org/wiki/s%C4%B1%C4%9F%C4%B1r#Turkish) | cattle | /sɯɣɯr/ · noun |
| [tunç](https://en.wiktionary.org/wiki/tun%C3%A7#Turkish) | bronze | /ˈtunt͡ʃ/ · noun |
| [asi](https://en.wiktionary.org/wiki/asi#Turkish) | rebellious | /aːˈsiː/ · adj |
| [ekşi](https://en.wiktionary.org/wiki/ek%C5%9Fi#Turkish) | sour, tart, acid, sharp or biting to the taste |  · adj |
| [halt](https://en.wiktionary.org/wiki/halt#Turkish) | an inappropriate act; mistake, blunder, screwup |  · noun |
| [kel](https://en.wiktionary.org/wiki/kel#Turkish) | bald | /ˈcæl/ · adj |
| [zar](https://en.wiktionary.org/wiki/zar#Turkish) | membrane |  · noun |
| [akustik](https://en.wiktionary.org/wiki/akustik#Turkish) | acoustics |  · noun |
| [beter](https://en.wiktionary.org/wiki/beter#Turkish) | worse | /beˈteɾ/ · adj |
| [dem](https://en.wiktionary.org/wiki/dem#Turkish) | dew | /ˈdem/ · noun |
| [deve](https://en.wiktionary.org/wiki/deve#Turkish) | camel | /deˈve/ · noun |
| [diploma](https://en.wiktionary.org/wiki/diploma#Turkish) | diploma | /dip.ɫoˈma/ · noun |
| [kaide](https://en.wiktionary.org/wiki/kaide#Turkish) | pedestal | /kaːˈi.de/ · noun |
| [kaymakam](https://en.wiktionary.org/wiki/kaymakam#Turkish) | kaymakam, a district governor | /kaj.maˈkam/ · noun |
| [nam](https://en.wiktionary.org/wiki/nam#Turkish) | reputation | /nɑm/ · noun |
| [pat](https://en.wiktionary.org/wiki/pat#Turkish) | oxeye daisy, any widespread flowering plant in the genus Leucanthemum | /ˈpat/ · noun |
| [pul](https://en.wiktionary.org/wiki/pul#Turkish) | stamp |  · noun |
| [rota](https://en.wiktionary.org/wiki/rota#Turkish) | route, course, heading | /ɾɔ.ta/ · noun |
| [soy](https://en.wiktionary.org/wiki/soy#Turkish) | family, kin, tribe, people | /soj/ · noun |
| [tuzla](https://en.wiktionary.org/wiki/tuzla#Turkish) | salt marsh, saltworks, salt mine | /ˈtuz.ɫa/ · noun |
| [yen](https://en.wiktionary.org/wiki/yen#Turkish) | sleeve (part of a garment that covers the arm) | /ˈjen/ · noun |
| [ala](https://en.wiktionary.org/wiki/ala#Turkish) | multicolored, pied, variegated | /aˈɫa/ · adj |
| [avantaj](https://en.wiktionary.org/wiki/avantaj#Turkish) | advantage | /avanˈtaʒ/ · noun |
| [aş](https://en.wiktionary.org/wiki/a%C5%9F#Turkish) | cooked food | /ɑʃ/ · noun |
| [fener](https://en.wiktionary.org/wiki/fener#Turkish) | lantern |  · noun |
| [kont](https://en.wiktionary.org/wiki/kont#Turkish) | count |  · noun |
| [mineral](https://en.wiktionary.org/wiki/mineral#Turkish) | mineral |  · noun |
| [reform](https://en.wiktionary.org/wiki/reform#Turkish) | reform | /ɾɛˈfoɾm/ · noun |
| [sos](https://en.wiktionary.org/wiki/sos#Turkish) | sauce | /sos/ · noun |
| [anormal](https://en.wiktionary.org/wiki/anormal#Turkish) | abnormal | /a.noɾˈmal/ · adj |
| [cins](https://en.wiktionary.org/wiki/cins#Turkish) | sort (kind, type) | /ˈd͡ʒins/ · noun |
| [kostüm](https://en.wiktionary.org/wiki/kost%C3%BCm#Turkish) | costume | /kos.tym/ · noun |
| [kova](https://en.wiktionary.org/wiki/kova#Turkish) | bucket | [ˈkovɑ] · noun |
| [lake](https://en.wiktionary.org/wiki/lake#Turkish) | Polished with lacquer. | /ˈla.ce/ · adj |
| [panel](https://en.wiktionary.org/wiki/panel#Turkish) | A panel that contains personal information (such as Turkish Identification Number, name and surname, place of residence and family tree) of the residents of Türkiye. |  · noun |
| [poker](https://en.wiktionary.org/wiki/poker#Turkish) | poker | /ˈpo.cæɾ/ · noun |
| [sap](https://en.wiktionary.org/wiki/sap#Turkish) | not having a significant other | /ˈsɑp/ · adj |
| [berk](https://en.wiktionary.org/wiki/berk#Turkish) | strong, hard, robust, violent | /ˈbeɾc/ · adj |

</details>

<details><summary>Words 951–1000</summary>

![[Resources/Audio/tr/Words 0951-1000.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [birader](https://en.wiktionary.org/wiki/birader#Turkish) | brother | /biɾaːdɛɾ/ · noun |
| [derviş](https://en.wiktionary.org/wiki/dervi%C5%9F#Turkish) | dervish, an itinerant Sufi mystic practicing voluntary poverty in devotion to God | /deɾˈviʃ/ · noun |
| [duruşma](https://en.wiktionary.org/wiki/duru%C5%9Fma#Turkish) | The stage of a trial when both parties are present before a judge; a hearing. | /du.ɾuʃˈma/ · noun |
| [hendek](https://en.wiktionary.org/wiki/hendek#Turkish) | ditch | /henˈdec/ · noun |
| [kukla](https://en.wiktionary.org/wiki/kukla#Turkish) | puppet (string puppet) | [ˈkuklɑ] · noun |
| [sabun](https://en.wiktionary.org/wiki/sabun#Turkish) | soap, a detergent substance used for cleaning | /saˈbun/ · noun |
| [sekizinci](https://en.wiktionary.org/wiki/sekizinci#Turkish) | eighth | /sekizinˈdʒi/ · adj |
| [story](https://en.wiktionary.org/wiki/story#Turkish) | story | /s(ɯ).ˈto.ɾi/ · noun |
| [tok](https://en.wiktionary.org/wiki/tok#Turkish) | Not hungry; sated, full. |  · adj |
| [tüy](https://en.wiktionary.org/wiki/t%C3%BCy#Turkish) | body hair, especially a shorter one | /tyj/ · noun |
| [emel](https://en.wiktionary.org/wiki/emel#Turkish) | goal | /e.mɛl/ · noun |
| [far](https://en.wiktionary.org/wiki/far#Turkish) | headlight |  · noun |
| [ima](https://en.wiktionary.org/wiki/ima#Turkish) | hint | /iːˈmaː/ · noun |
| [mod](https://en.wiktionary.org/wiki/mod#Turkish) | mode | /ˈmod/ · noun |
| [penis](https://en.wiktionary.org/wiki/penis#Turkish) | penis | [ˈpenis] · noun |
| [salata](https://en.wiktionary.org/wiki/salata#Turkish) | salad | /sɑˈɫɑtɑ/ · noun |
| [salim](https://en.wiktionary.org/wiki/salim#Turkish) | safe, sound |  · adj |
| [yakmak](https://en.wiktionary.org/wiki/yakmak#Turkish) | to light; to ignite; to set fire to, set on fire | /jakˈmak/ · verb |
| [şövalye](https://en.wiktionary.org/wiki/%C5%9F%C3%B6valye#Turkish) | knight | /ʃø.val.je/ · noun |
| [alem](https://en.wiktionary.org/wiki/alem#Turkish) | banner | [aˈlæm] · noun |
| [badem](https://en.wiktionary.org/wiki/badem#Turkish) | almond | /baːˈdɛm/ · noun |
| [bale](https://en.wiktionary.org/wiki/bale#Turkish) | ballet |  · noun |
| [defter](https://en.wiktionary.org/wiki/defter#Turkish) | notebook | /defˈteɾ/ · noun |
| [plaj](https://en.wiktionary.org/wiki/plaj#Turkish) | sandy beach, shore | /ˈplaʒ/ · noun |
| [us](https://en.wiktionary.org/wiki/us#Turkish) | mind | /ˈus/ · noun |
| [yengeç](https://en.wiktionary.org/wiki/yenge%C3%A7#Turkish) | crab, any crustacean of the infraorder Brachyura having five pair of legs, the foremost of which are in the form of claws | [jɛ̞nˈɟɛ̞tʃ] · noun |
| [bez](https://en.wiktionary.org/wiki/bez#Turkish) | cloth | /ˈbez/ · noun |
| [bora](https://en.wiktionary.org/wiki/bora#Turkish) | Squall. |  · noun |
| [but](https://en.wiktionary.org/wiki/but#Turkish) | thigh |  · noun |
| [harap](https://en.wiktionary.org/wiki/harap#Turkish) | ruined | [hɑˈɾɑp] · adj |
| [karınca](https://en.wiktionary.org/wiki/kar%C4%B1nca#Turkish) | ant, any of various insects in the family Formicidae, typically living in colonies | [kɑˈɾɯndʒɑ] · noun |
| [mürekkep](https://en.wiktionary.org/wiki/m%C3%BCrekkep#Turkish) | ink | /my.ɾecˈcep/ · noun |
| [nar](https://en.wiktionary.org/wiki/nar#Turkish) | pomegranate |  · noun |
| [parlamento](https://en.wiktionary.org/wiki/parlamento#Turkish) | parliament | /paɾ.laˈmen.to/ · noun |
| [sal](https://en.wiktionary.org/wiki/sal#Turkish) | raft | /sɑɫ/ · noun |
| [ceviz](https://en.wiktionary.org/wiki/ceviz#Turkish) | walnut | /d͡ʒeˈviz/ · noun |
| [hap](https://en.wiktionary.org/wiki/hap#Turkish) | pill |  · noun |
| [kapitalist](https://en.wiktionary.org/wiki/kapitalist#Turkish) | capitalist | /kɑpitɑˈlist/ · adj |
| [kupon](https://en.wiktionary.org/wiki/kupon#Turkish) | coupon (certificate of interest due) |  · noun |
| [level](https://en.wiktionary.org/wiki/level#Turkish) | level | /ˈle.vel/ · noun |
| [miting](https://en.wiktionary.org/wiki/miting#Turkish) | rally (public gathering) | /ˈmi.tinɟ/ · noun |
| [saçmalık](https://en.wiktionary.org/wiki/sa%C3%A7mal%C4%B1k#Turkish) | nonsense | /sat͡ʃ.maˈɫɯk/ · noun |
| [sin](https://en.wiktionary.org/wiki/sin#Turkish) | Letter of the Arabic alphabet: س |  · noun |
| [yoga](https://en.wiktionary.org/wiki/yoga#Turkish) | yoga |  · noun |
| [büro](https://en.wiktionary.org/wiki/b%C3%BCro#Turkish) | office, bureau |  · noun |
| [dip](https://en.wiktionary.org/wiki/dip#Turkish) | bottom, deep |  · noun |
| [logo](https://en.wiktionary.org/wiki/logo#Turkish) | logo | /ˈlo.ɡo/ · noun |
| [sokağa çıkma yasağı](https://en.wiktionary.org/wiki/soka%C4%9Fa%20%C3%A7%C4%B1kma%20yasa%C4%9F%C4%B1#Turkish) | curfew |  · noun |
| [yoğurt](https://en.wiktionary.org/wiki/yo%C4%9Furt#Turkish) | yogurt, a milk-based product stiffened by a bacterium-aided curdling process | /joˈuɾt/ · noun |
| [güvercin](https://en.wiktionary.org/wiki/g%C3%BCvercin#Turkish) | dove, pigeon | /ɟy.vɛɾˈd͡ʒín/ · noun |

</details>

## Question bank

Try before opening the answers. Different tasks use the same sentence to practise complementary skills. Open translation and explanation tasks can have valid alternatives.

### Pronouns · 50 questions

**tr-Q0001 · Fill the gap**

____, ekmeği yedi.

She ate the bread.

[[Turkish#^tr-Q0001-answer|Compare the answer]]
^tr-Q0001

**tr-Q0002 · Choose the form**

____, ekmeği yedi.

She ate the bread.

Choices: sen / O / ben / biz

[[Turkish#^tr-Q0002-answer|Compare the answer]]
^tr-Q0002

**tr-Q0003 · Edit the changed sentence**

【sen】 McDonald's'ta için çalışıyorum.

I work for McDonald's.

[[Turkish#^tr-Q0003-answer|Compare the answer]]
^tr-Q0003

**tr-Q0004 · Build the sentence**

Arrange: McDonald's'ta / için / çalışıyorum. / Ben

I work for McDonald's.

[[Turkish#^tr-Q0004-answer|Compare the answer]]
^tr-Q0004

**tr-Q0005 · Write a translation**

Write this in Turkish: I'm not the only Canadian living in Boston.

[[Turkish#^tr-Q0005-answer|Compare the answer]]
^tr-Q0005

**tr-Q0006 · Explain the grammar**

Boston'da yaşayan tek Kanadalı 【ben】 değilim.

I'm not the only Canadian living in Boston.

[[Turkish#^tr-Q0006-answer|Compare the answer]]
^tr-Q0006

**tr-Q0007 · Fill the gap**

Bunu ____ yapacağım.

I'm going to make it.

[[Turkish#^tr-Q0007-answer|Compare the answer]]
^tr-Q0007

**tr-Q0008 · Choose the form**

Bunu ____ yapacağım.

I'm going to make it.

Choices: biz / ben / o / sen

[[Turkish#^tr-Q0008-answer|Compare the answer]]
^tr-Q0008

**tr-Q0009 · Edit the changed sentence**

【ben】 Tom için kötü sona erdi.

It ended badly for Tom.

[[Turkish#^tr-Q0009-answer|Compare the answer]]
^tr-Q0009

**tr-Q0010 · Build the sentence**

Arrange: O / kötü / erdi. / Tom / için / sona

It ended badly for Tom.

[[Turkish#^tr-Q0010-answer|Compare the answer]]
^tr-Q0010

**tr-Q0011 · Write a translation**

Write this in Turkish: Tom won't let you guys help Mary.

[[Turkish#^tr-Q0011-answer|Compare the answer]]
^tr-Q0011

**tr-Q0012 · Explain the grammar**

Tom, 【siz】 arkadaşların Mary'ye yardım etmene izin vermeyecek.

Tom won't let you guys help Mary.

[[Turkish#^tr-Q0012-answer|Compare the answer]]
^tr-Q0012

**tr-Q0013 · Fill the gap**

____ senin sorununun farkındayım.

I'm aware of your problem.

[[Turkish#^tr-Q0013-answer|Compare the answer]]
^tr-Q0013

**tr-Q0014 · Choose the form**

____ senin sorununun farkındayım.

I'm aware of your problem.

Choices: biz / o / sen / Ben

[[Turkish#^tr-Q0014-answer|Compare the answer]]
^tr-Q0014

**tr-Q0015 · Edit the changed sentence**

Yıllardır 【ben】 kadar uzağa yürümedim.

I haven't walked that far in years.

[[Turkish#^tr-Q0015-answer|Compare the answer]]
^tr-Q0015

**tr-Q0016 · Build the sentence**

Arrange: o / Yıllardır / kadar / yürümedim. / uzağa

I haven't walked that far in years.

[[Turkish#^tr-Q0016-answer|Compare the answer]]
^tr-Q0016

**tr-Q0017 · Write a translation**

Write this in Turkish: I stopped at the supermarket on my way home.

[[Turkish#^tr-Q0017-answer|Compare the answer]]
^tr-Q0017

**tr-Q0018 · Explain the grammar**

【Ben】 eve giderken süpermarkette durdum.

I stopped at the supermarket on my way home.

[[Turkish#^tr-Q0018-answer|Compare the answer]]
^tr-Q0018

**tr-Q0019 · Fill the gap**

____ bir kelime değil.

That's not a word.

[[Turkish#^tr-Q0019-answer|Compare the answer]]
^tr-Q0019

**tr-Q0020 · Choose the form**

____ bir kelime değil.

That's not a word.

Choices: O / ben / sen / biz

[[Turkish#^tr-Q0020-answer|Compare the answer]]
^tr-Q0020

**tr-Q0021 · Edit the changed sentence**

【sen】 küçük bir aileden geliyorum.

I come from a small family.

[[Turkish#^tr-Q0021-answer|Compare the answer]]
^tr-Q0021

**tr-Q0022 · Build the sentence**

Arrange: küçük / geliyorum. / Ben / bir / aileden

I come from a small family.

[[Turkish#^tr-Q0022-answer|Compare the answer]]
^tr-Q0022

**tr-Q0023 · Write a translation**

Write this in Turkish: You want another slice of cake?

[[Turkish#^tr-Q0023-answer|Compare the answer]]
^tr-Q0023

**tr-Q0024 · Explain the grammar**

【Sen】 başka bir kek dilimi mi istiyorsun?

You want another slice of cake?

[[Turkish#^tr-Q0024-answer|Compare the answer]]
^tr-Q0024

**tr-Q0025 · Fill the gap**

____, okula kadar çocuklara refakat edecek.

He will accompany the children to school.

[[Turkish#^tr-Q0025-answer|Compare the answer]]
^tr-Q0025

**tr-Q0026 · Choose the form**

____, okula kadar çocuklara refakat edecek.

He will accompany the children to school.

Choices: O / sen / ben / biz

[[Turkish#^tr-Q0026-answer|Compare the answer]]
^tr-Q0026

**tr-Q0027 · Edit the changed sentence**

【ben】 savını meşrulaştırabilir misin?

Can you justify your claim?

[[Turkish#^tr-Q0027-answer|Compare the answer]]
^tr-Q0027

**tr-Q0028 · Build the sentence**

Arrange: savını / Sen / meşrulaştırabilir / misin?

Can you justify your claim?

[[Turkish#^tr-Q0028-answer|Compare the answer]]
^tr-Q0028

**tr-Q0029 · Write a translation**

Write this in Turkish: She stayed in that area for a short while.

[[Turkish#^tr-Q0029-answer|Compare the answer]]
^tr-Q0029

**tr-Q0030 · Explain the grammar**

【O】, kısa bir süre o bölgede kaldı.

She stayed in that area for a short while.

[[Turkish#^tr-Q0030-answer|Compare the answer]]
^tr-Q0030

**tr-Q0031 · Fill the gap**

____ kahve, tost ve jöle istiyorum.

I want coffee, toast, and jelly.

[[Turkish#^tr-Q0031-answer|Compare the answer]]
^tr-Q0031

**tr-Q0032 · Choose the form**

____ kahve, tost ve jöle istiyorum.

I want coffee, toast, and jelly.

Choices: biz / o / Ben / sen

[[Turkish#^tr-Q0032-answer|Compare the answer]]
^tr-Q0032

**tr-Q0033 · Edit the changed sentence**

【ben】 çiçeği sulamalıyız.

We must water the flower.

[[Turkish#^tr-Q0033-answer|Compare the answer]]
^tr-Q0033

**tr-Q0034 · Build the sentence**

Arrange: sulamalıyız. / Biz / çiçeği

We must water the flower.

[[Turkish#^tr-Q0034-answer|Compare the answer]]
^tr-Q0034

**tr-Q0035 · Write a translation**

Write this in Turkish: Things are not that simple.

[[Turkish#^tr-Q0035-answer|Compare the answer]]
^tr-Q0035

**tr-Q0036 · Explain the grammar**

Şartlar 【o】 kadar kolay değil.

Things are not that simple.

[[Turkish#^tr-Q0036-answer|Compare the answer]]
^tr-Q0036

**tr-Q0037 · Fill the gap**

____ o fedakarlığı yapmaya hazırım.

I'm willing to make that sacrifice.

[[Turkish#^tr-Q0037-answer|Compare the answer]]
^tr-Q0037

**tr-Q0038 · Choose the form**

____ o fedakarlığı yapmaya hazırım.

I'm willing to make that sacrifice.

Choices: o / biz / Ben / sen

[[Turkish#^tr-Q0038-answer|Compare the answer]]
^tr-Q0038

**tr-Q0039 · Edit the changed sentence**

【ben】 zarfı kim verdi sana?

Who gave that envelope to you?

[[Turkish#^tr-Q0039-answer|Compare the answer]]
^tr-Q0039

**tr-Q0040 · Build the sentence**

Arrange: sana? / O / zarfı / kim / verdi

Who gave that envelope to you?

[[Turkish#^tr-Q0040-answer|Compare the answer]]
^tr-Q0040

**tr-Q0041 · Write a translation**

Write this in Turkish: That seems like an affordable price.

[[Turkish#^tr-Q0041-answer|Compare the answer]]
^tr-Q0041

**tr-Q0042 · Explain the grammar**

【O】, uygun bir fiyatlı gibi görünüyor.

That seems like an affordable price.

[[Turkish#^tr-Q0042-answer|Compare the answer]]
^tr-Q0042

**tr-Q0043 · Fill the gap**

Sami, haziran 2006'da ____ birime taşındı.

Sami moved to that unit in June, 2006.

[[Turkish#^tr-Q0043-answer|Compare the answer]]
^tr-Q0043

**tr-Q0044 · Choose the form**

Sami, haziran 2006'da ____ birime taşındı.

Sami moved to that unit in June, 2006.

Choices: o / sen / biz / ben

[[Turkish#^tr-Q0044-answer|Compare the answer]]
^tr-Q0044

**tr-Q0045 · Edit the changed sentence**

Çünkü 【ben】 ilginç ve güzel bir şehirdir?

Because it is an interesting and beautiful city?

[[Turkish#^tr-Q0045-answer|Compare the answer]]
^tr-Q0045

**tr-Q0046 · Build the sentence**

Arrange: Çünkü / bir / ilginç / şehirdir? / ve / o / güzel

Because it is an interesting and beautiful city?

[[Turkish#^tr-Q0046-answer|Compare the answer]]
^tr-Q0046

**tr-Q0047 · Write a translation**

Write this in Turkish: I can't just leave Tom.

[[Turkish#^tr-Q0047-answer|Compare the answer]]
^tr-Q0047

**tr-Q0048 · Explain the grammar**

【Ben】 sadece Tom'u terk edemem.

I can't just leave Tom.

[[Turkish#^tr-Q0048-answer|Compare the answer]]
^tr-Q0048

**tr-Q0049 · Fill the gap**

____ bir aktris olmak istiyor.

She wants to be an actress.

[[Turkish#^tr-Q0049-answer|Compare the answer]]
^tr-Q0049

**tr-Q0050 · Choose the form**

____ bir aktris olmak istiyor.

She wants to be an actress.

Choices: ben / O / sen / biz

[[Turkish#^tr-Q0050-answer|Compare the answer]]
^tr-Q0050


### Demonstratives · 50 questions

**tr-Q0051 · Edit the changed sentence**

Neden herkes için yeterli yiyeceğimiz yok ? 【şu】 öğleden sonra alışverişe gittiğinizi sanıyordum.

Why don't we have enough food for everyone? I thought you went shopping this afternoon.

[[Turkish#^tr-Q0051-answer|Compare the answer]]
^tr-Q0051

**tr-Q0052 · Build the sentence**

Arrange: alışverişe / sonra / yeterli / için / gittiğinizi / herkes / yok / ? / yiyeceğimiz / sanıyordum. / Bu / Neden / öğleden

Why don't we have enough food for everyone? I thought you went shopping this afternoon.

[[Turkish#^tr-Q0052-answer|Compare the answer]]
^tr-Q0052

**tr-Q0053 · Write a translation**

Write this in Turkish: We can make this work.

[[Turkish#^tr-Q0053-answer|Compare the answer]]
^tr-Q0053

**tr-Q0054 · Explain the grammar**

【Bu】 işi yapabiliriz.

We can make this work.

[[Turkish#^tr-Q0054-answer|Compare the answer]]
^tr-Q0054

**tr-Q0055 · Fill the gap**

____, bu bölgede bugüne kadar en iyi deniz ürünleri restoranıdır.

This is by far the best seafood restaurant in this area.

[[Turkish#^tr-Q0055-answer|Compare the answer]]
^tr-Q0055

**tr-Q0056 · Choose the form**

____, bu bölgede bugüne kadar en iyi deniz ürünleri restoranıdır.

This is by far the best seafood restaurant in this area.

Choices: Bu / şu / o / bunlar

[[Turkish#^tr-Q0056-answer|Compare the answer]]
^tr-Q0056

**tr-Q0057 · Edit the changed sentence**

【şu】 arabayı satın alayım!

Let me buy this car!

[[Turkish#^tr-Q0057-answer|Compare the answer]]
^tr-Q0057

**tr-Q0058 · Build the sentence**

Arrange: satın / alayım! / Bu / arabayı

Let me buy this car!

[[Turkish#^tr-Q0058-answer|Compare the answer]]
^tr-Q0058

**tr-Q0059 · Write a translation**

Write this in Turkish: This can be easily proven.

[[Turkish#^tr-Q0059-answer|Compare the answer]]
^tr-Q0059

**tr-Q0060 · Explain the grammar**

【Bu】 kolayca kanıtlanabilir.

This can be easily proven.

[[Turkish#^tr-Q0060-answer|Compare the answer]]
^tr-Q0060

**tr-Q0061 · Fill the gap**

____ yaz günü çok çabuk bitecek!

This summer's day will be over all too soon!

[[Turkish#^tr-Q0061-answer|Compare the answer]]
^tr-Q0061

**tr-Q0062 · Choose the form**

____ yaz günü çok çabuk bitecek!

This summer's day will be over all too soon!

Choices: şu / Bu / bunlar / o

[[Turkish#^tr-Q0062-answer|Compare the answer]]
^tr-Q0062

**tr-Q0063 · Edit the changed sentence**

【şu】 yeri benim için harita üzerinde bulabilir misin?

Can you locate this place on the map for me?

[[Turkish#^tr-Q0063-answer|Compare the answer]]
^tr-Q0063

**tr-Q0064 · Build the sentence**

Arrange: bulabilir / üzerinde / harita / misin? / için / yeri / Bu / benim

Can you locate this place on the map for me?

[[Turkish#^tr-Q0064-answer|Compare the answer]]
^tr-Q0064

**tr-Q0065 · Write a translation**

Write this in Turkish: I wrote this letter.

[[Turkish#^tr-Q0065-answer|Compare the answer]]
^tr-Q0065

**tr-Q0066 · Explain the grammar**

【Bu】 mektubu yazdım.

I wrote this letter.

[[Turkish#^tr-Q0066-answer|Compare the answer]]
^tr-Q0066

**tr-Q0067 · Fill the gap**

____ sabah bir baş ağrısı ile uyandım.

I woke up with a headache this morning.

[[Turkish#^tr-Q0067-answer|Compare the answer]]
^tr-Q0067

**tr-Q0068 · Choose the form**

____ sabah bir baş ağrısı ile uyandım.

I woke up with a headache this morning.

Choices: bunlar / Bu / o / şu

[[Turkish#^tr-Q0068-answer|Compare the answer]]
^tr-Q0068

**tr-Q0069 · Edit the changed sentence**

Biz 【bu】 veriye sahip değiliz.

We don't have that data.

[[Turkish#^tr-Q0069-answer|Compare the answer]]
^tr-Q0069

**tr-Q0070 · Build the sentence**

Arrange: değiliz. / Biz / o / veriye / sahip

We don't have that data.

[[Turkish#^tr-Q0070-answer|Compare the answer]]
^tr-Q0070

**tr-Q0071 · Write a translation**

Write this in Turkish: This isn't Spanish.

[[Turkish#^tr-Q0071-answer|Compare the answer]]
^tr-Q0071

**tr-Q0072 · Explain the grammar**

【Bu】 İspanyolca değil.

This isn't Spanish.

[[Turkish#^tr-Q0072-answer|Compare the answer]]
^tr-Q0072

**tr-Q0073 · Fill the gap**

____ plaj sörfçüler için bir cennettir.

This beach is a paradise for surfers.

[[Turkish#^tr-Q0073-answer|Compare the answer]]
^tr-Q0073

**tr-Q0074 · Choose the form**

____ plaj sörfçüler için bir cennettir.

This beach is a paradise for surfers.

Choices: şu / bunlar / Bu / o

[[Turkish#^tr-Q0074-answer|Compare the answer]]
^tr-Q0074

**tr-Q0075 · Edit the changed sentence**

【bu】, yapmak için mantıklı bir şey.

That's the logical thing to do.

[[Turkish#^tr-Q0075-answer|Compare the answer]]
^tr-Q0075

**tr-Q0076 · Build the sentence**

Arrange: yapmak / bir / için / O, / mantıklı / şey.

That's the logical thing to do.

[[Turkish#^tr-Q0076-answer|Compare the answer]]
^tr-Q0076

**tr-Q0077 · Write a translation**

Write this in Turkish: That's all Tom said.

[[Turkish#^tr-Q0077-answer|Compare the answer]]
^tr-Q0077

**tr-Q0078 · Explain the grammar**

Tom'un söylediği 【bu】 kadar.

That's all Tom said.

[[Turkish#^tr-Q0078-answer|Compare the answer]]
^tr-Q0078

**tr-Q0079 · Fill the gap**

Tom otoritesini kötüye kullanıyor, ____ yüzden hiç kimse onu sevmiyor.

Tom abuses his authority, so no one likes him.

[[Turkish#^tr-Q0079-answer|Compare the answer]]
^tr-Q0079

**tr-Q0080 · Choose the form**

Tom otoritesini kötüye kullanıyor, ____ yüzden hiç kimse onu sevmiyor.

Tom abuses his authority, so no one likes him.

Choices: bu / o / bunlar / şu

[[Turkish#^tr-Q0080-answer|Compare the answer]]
^tr-Q0080

**tr-Q0081 · Edit the changed sentence**

【bu】, iş için seyahate gitti.

He traveled on business.

[[Turkish#^tr-Q0081-answer|Compare the answer]]
^tr-Q0081

**tr-Q0082 · Build the sentence**

Arrange: gitti. / seyahate / iş / O, / için

He traveled on business.

[[Turkish#^tr-Q0082-answer|Compare the answer]]
^tr-Q0082

**tr-Q0083 · Write a translation**

Write this in Turkish: Would you please have a look at this document?

[[Turkish#^tr-Q0083-answer|Compare the answer]]
^tr-Q0083

**tr-Q0084 · Explain the grammar**

Lütfen 【bu】 belgeye göz atar mısın?

Would you please have a look at this document?

[[Turkish#^tr-Q0084-answer|Compare the answer]]
^tr-Q0084

**tr-Q0085 · Fill the gap**

____ yardımcı olabilir.

That could help.

[[Turkish#^tr-Q0085-answer|Compare the answer]]
^tr-Q0085

**tr-Q0086 · Choose the form**

____ yardımcı olabilir.

That could help.

Choices: şu / bu / bunlar / O

[[Turkish#^tr-Q0086-answer|Compare the answer]]
^tr-Q0086

**tr-Q0087 · Edit the changed sentence**

【bu】 bir manyak.

She is a maniac.

[[Turkish#^tr-Q0087-answer|Compare the answer]]
^tr-Q0087

**tr-Q0088 · Build the sentence**

Arrange: bir / O / manyak.

She is a maniac.

[[Turkish#^tr-Q0088-answer|Compare the answer]]
^tr-Q0088

**tr-Q0089 · Write a translation**

Write this in Turkish: She's got the point.

[[Turkish#^tr-Q0089-answer|Compare the answer]]
^tr-Q0089

**tr-Q0090 · Explain the grammar**

【O】, verilen mesajı aldı.

She's got the point.

[[Turkish#^tr-Q0090-answer|Compare the answer]]
^tr-Q0090

**tr-Q0091 · Fill the gap**

____ yalıtılmış bir sorun değildi.

It wasn't an isolated problem.

[[Turkish#^tr-Q0091-answer|Compare the answer]]
^tr-Q0091

**tr-Q0092 · Choose the form**

____ yalıtılmış bir sorun değildi.

It wasn't an isolated problem.

Choices: Bu / bunlar / şu / o

[[Turkish#^tr-Q0092-answer|Compare the answer]]
^tr-Q0092

**tr-Q0093 · Edit the changed sentence**

Tom 【bu】 kadar yakışıklı değil.

Tom isn't that handsome.

[[Turkish#^tr-Q0093-answer|Compare the answer]]
^tr-Q0093

**tr-Q0094 · Build the sentence**

Arrange: o / yakışıklı / Tom / değil. / kadar

Tom isn't that handsome.

[[Turkish#^tr-Q0094-answer|Compare the answer]]
^tr-Q0094

**tr-Q0095 · Write a translation**

Write this in Turkish: I cannot repair this refrigerator.

[[Turkish#^tr-Q0095-answer|Compare the answer]]
^tr-Q0095

**tr-Q0096 · Explain the grammar**

Ben 【bu】 buzdolabını onaramam.

I cannot repair this refrigerator.

[[Turkish#^tr-Q0096-answer|Compare the answer]]
^tr-Q0096

**tr-Q0097 · Fill the gap**

____, bazen okula gelmez.

He is sometimes absent from school.

[[Turkish#^tr-Q0097-answer|Compare the answer]]
^tr-Q0097

**tr-Q0098 · Choose the form**

____, bazen okula gelmez.

He is sometimes absent from school.

Choices: bunlar / bu / O / şu

[[Turkish#^tr-Q0098-answer|Compare the answer]]
^tr-Q0098

**tr-Q0099 · Edit the changed sentence**

【bu】 kendilerine bakan çocuğu seviyor.

They like the boy looking at them.

[[Turkish#^tr-Q0099-answer|Compare the answer]]
^tr-Q0099

**tr-Q0100 · Build the sentence**

Arrange: Onlar / kendilerine / seviyor. / çocuğu / bakan

They like the boy looking at them.

[[Turkish#^tr-Q0100-answer|Compare the answer]]
^tr-Q0100


### Plural nouns · 50 questions

**tr-Q0101 · Write a translation**

Write this in Turkish: People say that I look like Tom.

[[Turkish#^tr-Q0101-answer|Compare the answer]]
^tr-Q0101

**tr-Q0102 · Explain the grammar**

【İnsanlar】 Tom'a benzediğimi söylüyorlar.

People say that I look like Tom.

[[Turkish#^tr-Q0102-answer|Compare the answer]]
^tr-Q0102

**tr-Q0103 · Fill the gap**

____ balı toplamak için peteği kaldırdılar.

Beekeepers remove the honeycomb to collect the honey.

[[Turkish#^tr-Q0103-answer|Compare the answer]]
^tr-Q0103

**tr-Q0104 · Choose the form**

____ balı toplamak için peteği kaldırdılar.

Beekeepers remove the honeycomb to collect the honey.

Choices: insanlar / Arıcılar / kitaplar / evler

[[Turkish#^tr-Q0104-answer|Compare the answer]]
^tr-Q0104

**tr-Q0105 · Edit the changed sentence**

Tom 【evler】 gününde annesine bir buket çiçek gönderdi.

Tom sent a bouquet of flowers to his mother on Mother's Day.

[[Turkish#^tr-Q0105-answer|Compare the answer]]
^tr-Q0105

**tr-Q0106 · Build the sentence**

Arrange: gününde / bir / buket / anneler / Tom / annesine / çiçek / gönderdi.

Tom sent a bouquet of flowers to his mother on Mother's Day.

[[Turkish#^tr-Q0106-answer|Compare the answer]]
^tr-Q0106

**tr-Q0107 · Write a translation**

Write this in Turkish: Every nation seeks to perpetuate itself.

[[Turkish#^tr-Q0107-answer|Compare the answer]]
^tr-Q0107

**tr-Q0108 · Explain the grammar**

Tüm 【milletler】 kendi sürekliliğini arar.

Every nation seeks to perpetuate itself.

[[Turkish#^tr-Q0108-answer|Compare the answer]]
^tr-Q0108

**tr-Q0109 · Fill the gap**

Biz resmî ve özel ____ arasına çizgi çizmeliyiz.

We should draw the line between public and private affairs.

[[Turkish#^tr-Q0109-answer|Compare the answer]]
^tr-Q0109

**tr-Q0110 · Choose the form**

Biz resmî ve özel ____ arasına çizgi çizmeliyiz.

We should draw the line between public and private affairs.

Choices: işler / kitaplar / insanlar / evler

[[Turkish#^tr-Q0110-answer|Compare the answer]]
^tr-Q0110

**tr-Q0111 · Edit the changed sentence**

Sana ve ailene mutlu 【evler】.

Merry Christmas to you and your family.

[[Turkish#^tr-Q0111-answer|Compare the answer]]
^tr-Q0111

**tr-Q0112 · Build the sentence**

Arrange: ve / Noeller. / mutlu / ailene / Sana

Merry Christmas to you and your family.

[[Turkish#^tr-Q0112-answer|Compare the answer]]
^tr-Q0112

**tr-Q0113 · Write a translation**

Write this in Turkish: Angola was once a Portuguese territory.

[[Turkish#^tr-Q0113-answer|Compare the answer]]
^tr-Q0113

**tr-Q0114 · Explain the grammar**

Angola bir 【zamanlar】 bir Portekiz bölgesiydi.

Angola was once a Portuguese territory.

[[Turkish#^tr-Q0114-answer|Compare the answer]]
^tr-Q0114

**tr-Q0115 · Fill the gap**

Tom çok iyi trombon ____.

Tom plays the trombone very well.

[[Turkish#^tr-Q0115-answer|Compare the answer]]
^tr-Q0115

**tr-Q0116 · Choose the form**

Tom çok iyi trombon ____.

Tom plays the trombone very well.

Choices: kitaplar / insanlar / evler / çalar

[[Turkish#^tr-Q0116-answer|Compare the answer]]
^tr-Q0116

**tr-Q0117 · Edit the changed sentence**

Sami ev tadilatlarına yardımcı olmak için bazı 【evler】 tuttu.

Sami hired some workers to help out with the house renovations.

[[Turkish#^tr-Q0117-answer|Compare the answer]]
^tr-Q0117

**tr-Q0118 · Build the sentence**

Arrange: işçiler / için / yardımcı / bazı / Sami / tadilatlarına / tuttu. / olmak / ev

Sami hired some workers to help out with the house renovations.

[[Turkish#^tr-Q0118-answer|Compare the answer]]
^tr-Q0118

**tr-Q0119 · Write a translation**

Write this in Turkish: They questioned him.

[[Turkish#^tr-Q0119-answer|Compare the answer]]
^tr-Q0119

**tr-Q0120 · Explain the grammar**

【Onlar】 onu sorguladılar.

They questioned him.

[[Turkish#^tr-Q0120-answer|Compare the answer]]
^tr-Q0120

**tr-Q0121 · Fill the gap**

Tom Mary'in önerisini ____ listesine not etti.

Tom put Mary's suggestion down on his to-do list.

[[Turkish#^tr-Q0121-answer|Compare the answer]]
^tr-Q0121

**tr-Q0122 · Choose the form**

Tom Mary'in önerisini ____ listesine not etti.

Tom put Mary's suggestion down on his to-do list.

Choices: insanlar / yapılacaklar / evler / kitaplar

[[Turkish#^tr-Q0122-answer|Compare the answer]]
^tr-Q0122

**tr-Q0123 · Edit the changed sentence**

【evler】 misafirleri ağırlamak için Allah'ın emrini yerine getiriyorlar.

They are fulfilling the commandment to host guests.

[[Turkish#^tr-Q0123-answer|Compare the answer]]
^tr-Q0123

**tr-Q0124 · Build the sentence**

Arrange: misafirleri / Onlar / için / ağırlamak / emrini / getiriyorlar. / Allah'ın / yerine

They are fulfilling the commandment to host guests.

[[Turkish#^tr-Q0124-answer|Compare the answer]]
^tr-Q0124

**tr-Q0125 · Write a translation**

Write this in Turkish: How will all this end?

[[Turkish#^tr-Q0125-answer|Compare the answer]]
^tr-Q0125

**tr-Q0126 · Explain the grammar**

Bütün 【bunlar】 nasıl bitecek?

How will all this end?

[[Turkish#^tr-Q0126-answer|Compare the answer]]
^tr-Q0126

**tr-Q0127 · Fill the gap**

Sen hiç bu restoranda ünlü ____ gördün mü?

Have you ever seen any famous people in this restaurant?

[[Turkish#^tr-Q0127-answer|Compare the answer]]
^tr-Q0127

**tr-Q0128 · Choose the form**

Sen hiç bu restoranda ünlü ____ gördün mü?

Have you ever seen any famous people in this restaurant?

Choices: kişiler / kitaplar / evler / insanlar

[[Turkish#^tr-Q0128-answer|Compare the answer]]
^tr-Q0128

**tr-Q0129 · Edit the changed sentence**

Tom birçok yeni 【evler】 edindi.

Tom has made a lot of new friends.

[[Turkish#^tr-Q0129-answer|Compare the answer]]
^tr-Q0129

**tr-Q0130 · Build the sentence**

Arrange: yeni / Tom / arkadaşlar / birçok / edindi.

Tom has made a lot of new friends.

[[Turkish#^tr-Q0130-answer|Compare the answer]]
^tr-Q0130

**tr-Q0131 · Write a translation**

Write this in Turkish: What triggers your asthma attacks?

[[Turkish#^tr-Q0131-answer|Compare the answer]]
^tr-Q0131

**tr-Q0132 · Explain the grammar**

Astımınızı tetikleyen 【şeyler】 neler?

What triggers your asthma attacks?

[[Turkish#^tr-Q0132-answer|Compare the answer]]
^tr-Q0132

**tr-Q0133 · Fill the gap**

Gerçek ____ yoktur.

True friendships don't exist.

[[Turkish#^tr-Q0133-answer|Compare the answer]]
^tr-Q0133

**tr-Q0134 · Choose the form**

Gerçek ____ yoktur.

True friendships don't exist.

Choices: insanlar / kitaplar / evler / dostluklar

[[Turkish#^tr-Q0134-answer|Compare the answer]]
^tr-Q0134

**tr-Q0135 · Edit the changed sentence**

【evler】 bir zamanlar dünyayı yönetti.

Dinosaurs once ruled the earth.

[[Turkish#^tr-Q0135-answer|Compare the answer]]
^tr-Q0135

**tr-Q0136 · Build the sentence**

Arrange: dünyayı / yönetti. / bir / Dinozorlar / zamanlar

Dinosaurs once ruled the earth.

[[Turkish#^tr-Q0136-answer|Compare the answer]]
^tr-Q0136

**tr-Q0137 · Write a translation**

Write this in Turkish: I don't worry about those kinds of things anymore.

[[Turkish#^tr-Q0137-answer|Compare the answer]]
^tr-Q0137

**tr-Q0138 · Explain the grammar**

Artık o tür 【şeyler】 hakkında endişelenmiyorum.

I don't worry about those kinds of things anymore.

[[Turkish#^tr-Q0138-answer|Compare the answer]]
^tr-Q0138

**tr-Q0139 · Fill the gap**

Seni demir ____ ardında görmek istiyorum.

I want you behind bars.

[[Turkish#^tr-Q0139-answer|Compare the answer]]
^tr-Q0139

**tr-Q0140 · Choose the form**

Seni demir ____ ardında görmek istiyorum.

I want you behind bars.

Choices: evler / kitaplar / insanlar / parmaklıklar

[[Turkish#^tr-Q0140-answer|Compare the answer]]
^tr-Q0140

**tr-Q0141 · Edit the changed sentence**

【evler】 akşam saat 5'te başladı.

The exams started at 5 o'clock in the evening.

[[Turkish#^tr-Q0141-answer|Compare the answer]]
^tr-Q0141

**tr-Q0142 · Build the sentence**

Arrange: Sınavlar / 5'te / saat / akşam / başladı.

The exams started at 5 o'clock in the evening.

[[Turkish#^tr-Q0142-answer|Compare the answer]]
^tr-Q0142

**tr-Q0143 · Write a translation**

Write this in Turkish: Both my father and my brother are fond of gambling.

[[Turkish#^tr-Q0143-answer|Compare the answer]]
^tr-Q0143

**tr-Q0144 · Explain the grammar**

Hem babam hem de erkek kardeşim kumara 【düşkünler】.

Both my father and my brother are fond of gambling.

[[Turkish#^tr-Q0144-answer|Compare the answer]]
^tr-Q0144

**tr-Q0145 · Fill the gap**

Bir ____ burada bir köprü vardı.

At one time, there was a bridge here.

[[Turkish#^tr-Q0145-answer|Compare the answer]]
^tr-Q0145

**tr-Q0146 · Choose the form**

Bir ____ burada bir köprü vardı.

At one time, there was a bridge here.

Choices: evler / insanlar / kitaplar / zamanlar

[[Turkish#^tr-Q0146-answer|Compare the answer]]
^tr-Q0146

**tr-Q0147 · Edit the changed sentence**

İyi 【evler】 her gün ölür.

Good people die every day.

[[Turkish#^tr-Q0147-answer|Compare the answer]]
^tr-Q0147

**tr-Q0148 · Build the sentence**

Arrange: gün / ölür. / her / insanlar / İyi

Good people die every day.

[[Turkish#^tr-Q0148-answer|Compare the answer]]
^tr-Q0148

**tr-Q0149 · Write a translation**

Write this in Turkish: Sami and Layla were from Egypt.

[[Turkish#^tr-Q0149-answer|Compare the answer]]
^tr-Q0149

**tr-Q0150 · Explain the grammar**

Sami ve Leyla, 【Mısırlıydılar】.

Sami and Layla were from Egypt.

[[Turkish#^tr-Q0150-answer|Compare the answer]]
^tr-Q0150


### Location suffix · 50 questions

**tr-Q0151 · Fill the gap**

Bütün onları yapmak ____ mıyız?

Do we have to do all that?

[[Turkish#^tr-Q0151-answer|Compare the answer]]
^tr-Q0151

**tr-Q0152 · Choose the form**

Bütün onları yapmak ____ mıyız?

Do we have to do all that?

Choices: zorunda / evde / okulda / kitapta

[[Turkish#^tr-Q0152-answer|Compare the answer]]
^tr-Q0152

**tr-Q0153 · Edit the changed sentence**

Akşam 【evde】 ne yemek istersiniz?

What would you like to have for dinner?

[[Turkish#^tr-Q0153-answer|Compare the answer]]
^tr-Q0153

**tr-Q0154 · Build the sentence**

Arrange: Akşam / ne / istersiniz? / yemek / yemeğinde

What would you like to have for dinner?

[[Turkish#^tr-Q0154-answer|Compare the answer]]
^tr-Q0154

**tr-Q0155 · Write a translation**

Write this in Turkish: It seems less crowded during the week.

[[Turkish#^tr-Q0155-answer|Compare the answer]]
^tr-Q0155

**tr-Q0156 · Explain the grammar**

【Hafta】 boyunca daha az kalabalık görünüyor.

It seems less crowded during the week.

[[Turkish#^tr-Q0156-answer|Compare the answer]]
^tr-Q0156

**tr-Q0157 · Fill the gap**

Kitabın önermesi ____ kusurludur.

The book's premise is fundamentally flawed.

[[Turkish#^tr-Q0157-answer|Compare the answer]]
^tr-Q0157

**tr-Q0158 · Choose the form**

Kitabın önermesi ____ kusurludur.

The book's premise is fundamentally flawed.

Choices: okulda / kitapta / temelde / evde

[[Turkish#^tr-Q0158-answer|Compare the answer]]
^tr-Q0158

**tr-Q0159 · Edit the changed sentence**

Her şeyin 【evde】 gideceğinden bayağı eminim.

I'm pretty sure everything will go well.

[[Turkish#^tr-Q0159-answer|Compare the answer]]
^tr-Q0159

**tr-Q0160 · Build the sentence**

Arrange: Her / yolunda / eminim. / şeyin / bayağı / gideceğinden

I'm pretty sure everything will go well.

[[Turkish#^tr-Q0160-answer|Compare the answer]]
^tr-Q0160

**tr-Q0161 · Write a translation**

Write this in Turkish: Is he in trouble again?

[[Turkish#^tr-Q0161-answer|Compare the answer]]
^tr-Q0161

**tr-Q0162 · Explain the grammar**

Onun yine başı 【belada】 mı?

Is he in trouble again?

[[Turkish#^tr-Q0162-answer|Compare the answer]]
^tr-Q0162

**tr-Q0163 · Fill the gap**

Şimdi yapmak ____ mıyım?

Do I have to do that now?

[[Turkish#^tr-Q0163-answer|Compare the answer]]
^tr-Q0163

**tr-Q0164 · Choose the form**

Şimdi yapmak ____ mıyım?

Do I have to do that now?

Choices: zorunda / okulda / evde / kitapta

[[Turkish#^tr-Q0164-answer|Compare the answer]]
^tr-Q0164

**tr-Q0165 · Edit the changed sentence**

Tom'un Mary ile 【evde】 okula giden bir kızı var.

Tom has a daughter that goes to school with Mary.

[[Turkish#^tr-Q0165-answer|Compare the answer]]
^tr-Q0165

**tr-Q0166 · Build the sentence**

Arrange: giden / Mary / bir / ile / kızı / birlikte / var. / okula / Tom'un

Tom has a daughter that goes to school with Mary.

[[Turkish#^tr-Q0166-answer|Compare the answer]]
^tr-Q0166

**tr-Q0167 · Write a translation**

Write this in Turkish: Send it in duplicate.

[[Turkish#^tr-Q0167-answer|Compare the answer]]
^tr-Q0167

**tr-Q0168 · Explain the grammar**

Onu iki kopya 【halinde】 gönderin.

Send it in duplicate.

[[Turkish#^tr-Q0168-answer|Compare the answer]]
^tr-Q0168

**tr-Q0169 · Fill the gap**

Lütfen geçerli bir e-____ adresi giriniz.

Please enter a valid email address.

[[Turkish#^tr-Q0169-answer|Compare the answer]]
^tr-Q0169

**tr-Q0170 · Choose the form**

Lütfen geçerli bir e-____ adresi giriniz.

Please enter a valid email address.

Choices: kitapta / evde / posta / okulda

[[Turkish#^tr-Q0170-answer|Compare the answer]]
^tr-Q0170

**tr-Q0171 · Edit the changed sentence**

Tom ders kitabını 【evde】 bıraktı.

Tom left his textbook in the car.

[[Turkish#^tr-Q0171-answer|Compare the answer]]
^tr-Q0171

**tr-Q0172 · Build the sentence**

Arrange: ders / arabada / Tom / kitabını / bıraktı.

Tom left his textbook in the car.

[[Turkish#^tr-Q0172-answer|Compare the answer]]
^tr-Q0172

**tr-Q0173 · Write a translation**

Write this in Turkish: I'm actually a very good driver.

[[Turkish#^tr-Q0173-answer|Compare the answer]]
^tr-Q0173

**tr-Q0174 · Explain the grammar**

【Aslında】 çok iyi bir sürücüyüm.

I'm actually a very good driver.

[[Turkish#^tr-Q0174-answer|Compare the answer]]
^tr-Q0174

**tr-Q0175 · Fill the gap**

____ çok dağınıktı.

The room was very untidy.

[[Turkish#^tr-Q0175-answer|Compare the answer]]
^tr-Q0175

**tr-Q0176 · Choose the form**

____ çok dağınıktı.

The room was very untidy.

Choices: kitapta / Oda / okulda / evde

[[Turkish#^tr-Q0176-answer|Compare the answer]]
^tr-Q0176

**tr-Q0177 · Edit the changed sentence**

Hepimiz 【evde】 mevcuttuk.

We were all present at the conference.

[[Turkish#^tr-Q0177-answer|Compare the answer]]
^tr-Q0177

**tr-Q0178 · Build the sentence**

Arrange: mevcuttuk. / Hepimiz / konferansta

We were all present at the conference.

[[Turkish#^tr-Q0178-answer|Compare the answer]]
^tr-Q0178

**tr-Q0179 · Write a translation**

Write this in Turkish: I didn't have enough money to buy what I had to buy.

[[Turkish#^tr-Q0179-answer|Compare the answer]]
^tr-Q0179

**tr-Q0180 · Explain the grammar**

Satın almak 【zorunda】 olduğum şeyi almak için yeterli param yoktu.

I didn't have enough money to buy what I had to buy.

[[Turkish#^tr-Q0180-answer|Compare the answer]]
^tr-Q0180

**tr-Q0181 · Fill the gap**

Tom akşam yemeği için ____ döndü.

Tom made it back in time for dinner.

[[Turkish#^tr-Q0181-answer|Compare the answer]]
^tr-Q0181

**tr-Q0182 · Choose the form**

Tom akşam yemeği için ____ döndü.

Tom made it back in time for dinner.

Choices: kitapta / zamanında / okulda / evde

[[Turkish#^tr-Q0182-answer|Compare the answer]]
^tr-Q0182

**tr-Q0183 · Edit the changed sentence**

【evde】 Fransızca okuyoruz.

We study French at school.

[[Turkish#^tr-Q0183-answer|Compare the answer]]
^tr-Q0183

**tr-Q0184 · Build the sentence**

Arrange: Fransızca / Okulda / okuyoruz.

We study French at school.

[[Turkish#^tr-Q0184-answer|Compare the answer]]
^tr-Q0184

**tr-Q0185 · Write a translation**

Write this in Turkish: It was difficult for King John to keep control over all of his rivals.

[[Turkish#^tr-Q0185-answer|Compare the answer]]
^tr-Q0185

**tr-Q0186 · Explain the grammar**

Kral John için, rakiplerinin tümünü kontrol 【altında】 tutmak çok zordu.

It was difficult for King John to keep control over all of his rivals.

[[Turkish#^tr-Q0186-answer|Compare the answer]]
^tr-Q0186

**tr-Q0187 · Fill the gap**

Senin ____ çok endişeliydim.

I was worried sick about you.

[[Turkish#^tr-Q0187-answer|Compare the answer]]
^tr-Q0187

**tr-Q0188 · Choose the form**

Senin ____ çok endişeliydim.

I was worried sick about you.

Choices: hakkında / evde / okulda / kitapta

[[Turkish#^tr-Q0188-answer|Compare the answer]]
^tr-Q0188

**tr-Q0189 · Edit the changed sentence**

Amerikan 【evde】 yeni bir yüzdü.

He was a fresh face in American politics.

[[Turkish#^tr-Q0189-answer|Compare the answer]]
^tr-Q0189

**tr-Q0190 · Build the sentence**

Arrange: Amerikan / bir / yeni / yüzdü. / siyasetinde

He was a fresh face in American politics.

[[Turkish#^tr-Q0190-answer|Compare the answer]]
^tr-Q0190

**tr-Q0191 · Write a translation**

Write this in Turkish: There are many hotels in the city's business district.

[[Turkish#^tr-Q0191-answer|Compare the answer]]
^tr-Q0191

**tr-Q0192 · Explain the grammar**

Şehrin iş 【bölgesinde】 birçok otel var.

There are many hotels in the city's business district.

[[Turkish#^tr-Q0192-answer|Compare the answer]]
^tr-Q0192

**tr-Q0193 · Fill the gap**

Onun ____ bilmek istiyorum.

I want to know about him.

[[Turkish#^tr-Q0193-answer|Compare the answer]]
^tr-Q0193

**tr-Q0194 · Choose the form**

Onun ____ bilmek istiyorum.

I want to know about him.

Choices: hakkında / kitapta / evde / okulda

[[Turkish#^tr-Q0194-answer|Compare the answer]]
^tr-Q0194

**tr-Q0195 · Edit the changed sentence**

Sisli 【evde】 yavaşça gözden kayboldu.

She slowly disappeared into the foggy forest.

[[Turkish#^tr-Q0195-answer|Compare the answer]]
^tr-Q0195

**tr-Q0196 · Build the sentence**

Arrange: Sisli / kayboldu. / yavaşça / gözden / ormanda

She slowly disappeared into the foggy forest.

[[Turkish#^tr-Q0196-answer|Compare the answer]]
^tr-Q0196

**tr-Q0197 · Write a translation**

Write this in Turkish: I want you to sit here and be quiet.

[[Turkish#^tr-Q0197-answer|Compare the answer]]
^tr-Q0197

**tr-Q0198 · Explain the grammar**

【Burada】 oturmanı ve sessiz olmanı istiyorum.

I want you to sit here and be quiet.

[[Turkish#^tr-Q0198-answer|Compare the answer]]
^tr-Q0198

**tr-Q0199 · Fill the gap**

Tom'a bir şey yapmasını emretmek ____ değildim.

I never had to order Tom to do anything.

[[Turkish#^tr-Q0199-answer|Compare the answer]]
^tr-Q0199

**tr-Q0200 · Choose the form**

Tom'a bir şey yapmasını emretmek ____ değildim.

I never had to order Tom to do anything.

Choices: okulda / zorunda / evde / kitapta

[[Turkish#^tr-Q0200-answer|Compare the answer]]
^tr-Q0200


### Source suffix · 50 questions

**tr-Q0201 · Edit the changed sentence**

【evden】 beri öksürüyorum.

I've been coughing since this morning.

[[Turkish#^tr-Q0201-answer|Compare the answer]]
^tr-Q0201

**tr-Q0202 · Build the sentence**

Arrange: Sabahtan / öksürüyorum. / beri

I've been coughing since this morning.

[[Turkish#^tr-Q0202-answer|Compare the answer]]
^tr-Q0202

**tr-Q0203 · Write a translation**

Write this in Turkish: Never let a crisis go to waste.

[[Turkish#^tr-Q0203-answer|Compare the answer]]
^tr-Q0203

**tr-Q0204 · Explain the grammar**

【Krizlerden】 mutlaka nemalanmaya bak.

Never let a crisis go to waste.

[[Turkish#^tr-Q0204-answer|Compare the answer]]
^tr-Q0204

**tr-Q0205 · Fill the gap**

____ sonra daha sıkı çalış.

Study harder from now on.

[[Turkish#^tr-Q0205-answer|Compare the answer]]
^tr-Q0205

**tr-Q0206 · Choose the form**

____ sonra daha sıkı çalış.

Study harder from now on.

Choices: Bundan / kitaptan / okuldan / evden

[[Turkish#^tr-Q0206-answer|Compare the answer]]
^tr-Q0206

**tr-Q0207 · Edit the changed sentence**

Tom 【evden】 daha iyi bir kişi.

Tom is a better person than me.

[[Turkish#^tr-Q0207-answer|Compare the answer]]
^tr-Q0207

**tr-Q0208 · Build the sentence**

Arrange: kişi. / Tom / daha / benden / bir / iyi

Tom is a better person than me.

[[Turkish#^tr-Q0208-answer|Compare the answer]]
^tr-Q0208

**tr-Q0209 · Write a translation**

Write this in Turkish: Tom grabbed Mary to keep her from falling.

[[Turkish#^tr-Q0209-answer|Compare the answer]]
^tr-Q0209

**tr-Q0210 · Explain the grammar**

Tom onu 【düşmekten】 korumak için Mary'yi yakaladı.

Tom grabbed Mary to keep her from falling.

[[Turkish#^tr-Q0210-answer|Compare the answer]]
^tr-Q0210

**tr-Q0211 · Fill the gap**

Sadece bir ____ döndüm.

I've just returned from a trip.

[[Turkish#^tr-Q0211-answer|Compare the answer]]
^tr-Q0211

**tr-Q0212 · Choose the form**

Sadece bir ____ döndüm.

I've just returned from a trip.

Choices: evden / geziden / kitaptan / okuldan

[[Turkish#^tr-Q0212-answer|Compare the answer]]
^tr-Q0212

**tr-Q0213 · Edit the changed sentence**

Onu 【evden】 yaptın.

You did that on purpose.

[[Turkish#^tr-Q0213-answer|Compare the answer]]
^tr-Q0213

**tr-Q0214 · Build the sentence**

Arrange: kasten / yaptın. / Onu

You did that on purpose.

[[Turkish#^tr-Q0214-answer|Compare the answer]]
^tr-Q0214

**tr-Q0215 · Write a translation**

Write this in Turkish: Everyone is very welcome, independent of their nationality.

[[Turkish#^tr-Q0215-answer|Compare the answer]]
^tr-Q0215

**tr-Q0216 · Explain the grammar**

【Milliyetlerinden】 bağımsız olarak herkes çok hoş karşılanıyor.

Everyone is very welcome, independent of their nationality.

[[Turkish#^tr-Q0216-answer|Compare the answer]]
^tr-Q0216

**tr-Q0217 · Fill the gap**

Doğum günü ____ sonra ne olduğunu hatırlıyor musun?

Do you remember what happened after your birthday party?

[[Turkish#^tr-Q0217-answer|Compare the answer]]
^tr-Q0217

**tr-Q0218 · Choose the form**

Doğum günü ____ sonra ne olduğunu hatırlıyor musun?

Do you remember what happened after your birthday party?

Choices: kitaptan / partinden / okuldan / evden

[[Turkish#^tr-Q0218-answer|Compare the answer]]
^tr-Q0218

**tr-Q0219 · Edit the changed sentence**

Tom senin 【evden】 daha zengindir.

Tom is richer than you think.

[[Turkish#^tr-Q0219-answer|Compare the answer]]
^tr-Q0219

**tr-Q0220 · Build the sentence**

Arrange: sandığından / daha / senin / zengindir. / Tom

Tom is richer than you think.

[[Turkish#^tr-Q0220-answer|Compare the answer]]
^tr-Q0220

**tr-Q0221 · Write a translation**

Write this in Turkish: Tell him to stop staring at me.

[[Turkish#^tr-Q0221-answer|Compare the answer]]
^tr-Q0221

**tr-Q0222 · Explain the grammar**

Ona bana 【bakmaktan】 vazgeçmesini söyle.

Tell him to stop staring at me.

[[Turkish#^tr-Q0222-answer|Compare the answer]]
^tr-Q0222

**tr-Q0223 · Fill the gap**

____ ilaç gibi geldi.

It really hit the spot.

[[Turkish#^tr-Q0223-answer|Compare the answer]]
^tr-Q0223

**tr-Q0224 · Choose the form**

____ ilaç gibi geldi.

It really hit the spot.

Choices: Gerçekten / okuldan / kitaptan / evden

[[Turkish#^tr-Q0224-answer|Compare the answer]]
^tr-Q0224

**tr-Q0225 · Edit the changed sentence**

Eğer 【evden】 bilmek istiyorsanız, tüm yapmanız gereken sormaktır.

If you really want to know, all you have to do is ask.

[[Turkish#^tr-Q0225-answer|Compare the answer]]
^tr-Q0225

**tr-Q0226 · Build the sentence**

Arrange: istiyorsanız, / sormaktır. / tüm / gerçekten / yapmanız / Eğer / gereken / bilmek

If you really want to know, all you have to do is ask.

[[Turkish#^tr-Q0226-answer|Compare the answer]]
^tr-Q0226

**tr-Q0227 · Write a translation**

Write this in Turkish: I'll be in and out all day, so it might be best if you call around after dinner.

[[Turkish#^tr-Q0227-answer|Compare the answer]]
^tr-Q0227

**tr-Q0228 · Explain the grammar**

Tüm gün git-gel yapacağım için beni akşam 【yemeğinden】 sonra araman en uygunu.

I'll be in and out all day, so it might be best if you call around after dinner.

[[Turkish#^tr-Q0228-answer|Compare the answer]]
^tr-Q0228

**tr-Q0229 · Fill the gap**

Cenaze arabası sekiz siyah at ____ çekildi.

The hearse was drawn by eight black horses.

[[Turkish#^tr-Q0229-answer|Compare the answer]]
^tr-Q0229

**tr-Q0230 · Choose the form**

Cenaze arabası sekiz siyah at ____ çekildi.

The hearse was drawn by eight black horses.

Choices: kitaptan / tarafından / okuldan / evden

[[Turkish#^tr-Q0230-answer|Compare the answer]]
^tr-Q0230

**tr-Q0231 · Edit the changed sentence**

Eylemlerim için 【evden】 üzgünüm.

I'm deeply sorry for my actions.

[[Turkish#^tr-Q0231-answer|Compare the answer]]
^tr-Q0231

**tr-Q0232 · Build the sentence**

Arrange: derinden / üzgünüm. / Eylemlerim / için

I'm deeply sorry for my actions.

[[Turkish#^tr-Q0232-answer|Compare the answer]]
^tr-Q0232

**tr-Q0233 · Write a translation**

Write this in Turkish: I really like the technique called chiaroscuro.

[[Turkish#^tr-Q0233-answer|Compare the answer]]
^tr-Q0233

**tr-Q0234 · Explain the grammar**

Işık ve gölge sanatı denilen tekniği 【gerçekten】 seviyorum.

I really like the technique called chiaroscuro.

[[Turkish#^tr-Q0234-answer|Compare the answer]]
^tr-Q0234

**tr-Q0235 · Fill the gap**

____ bunu yiyebilir misin?

Could you actually eat this?

[[Turkish#^tr-Q0235-answer|Compare the answer]]
^tr-Q0235

**tr-Q0236 · Choose the form**

____ bunu yiyebilir misin?

Could you actually eat this?

Choices: kitaptan / okuldan / Gerçekten / evden

[[Turkish#^tr-Q0236-answer|Compare the answer]]
^tr-Q0236

**tr-Q0237 · Edit the changed sentence**

Bir dağ 【evden】 güneş'in doğuşunu izlemek bir zevk.

To see the sunrise from a mountaintop is a delight.

[[Turkish#^tr-Q0237-answer|Compare the answer]]
^tr-Q0237

**tr-Q0238 · Build the sentence**

Arrange: doğuşunu / izlemek / bir / zevk. / güneş'in / zirvesinden / Bir / dağ

To see the sunrise from a mountaintop is a delight.

[[Turkish#^tr-Q0238-answer|Compare the answer]]
^tr-Q0238

**tr-Q0239 · Write a translation**

Write this in Turkish: We had better do away with such a fixed idea.

[[Turkish#^tr-Q0239-answer|Compare the answer]]
^tr-Q0239

**tr-Q0240 · Explain the grammar**

Böyle bir sabit 【fikirden】 kurtulsak iyi olur.

We had better do away with such a fixed idea.

[[Turkish#^tr-Q0240-answer|Compare the answer]]
^tr-Q0240

**tr-Q0241 · Fill the gap**

Şirket adına, hepinize ____ teşekkürlerimi sunmak isterim.

On behalf of the company, I would like to express our hearty thanks to you all.

[[Turkish#^tr-Q0241-answer|Compare the answer]]
^tr-Q0241

**tr-Q0242 · Choose the form**

Şirket adına, hepinize ____ teşekkürlerimi sunmak isterim.

On behalf of the company, I would like to express our hearty thanks to you all.

Choices: okuldan / kitaptan / içten / evden

[[Turkish#^tr-Q0242-answer|Compare the answer]]
^tr-Q0242

**tr-Q0243 · Edit the changed sentence**

Hangi boyutu 【evden】 emin değildim.

I wasn't sure what size to get.

[[Turkish#^tr-Q0243-answer|Compare the answer]]
^tr-Q0243

**tr-Q0244 · Build the sentence**

Arrange: alacağımdan / Hangi / değildim. / boyutu / emin

I wasn't sure what size to get.

[[Turkish#^tr-Q0244-answer|Compare the answer]]
^tr-Q0244

**tr-Q0245 · Write a translation**

Write this in Turkish: Tom grew up in a one-horse town and was overwhelmed when he moved to the big smoke.

[[Turkish#^tr-Q0245-answer|Compare the answer]]
^tr-Q0245

**tr-Q0246 · Explain the grammar**

Küçük ve köhne bir kasabada yetişen Tom, büyük şehre yerleştiğinde 【sudan】 çıkmış balığa dönmüştü.

Tom grew up in a one-horse town and was overwhelmed when he moved to the big smoke.

[[Turkish#^tr-Q0246-answer|Compare the answer]]
^tr-Q0246

**tr-Q0247 · Fill the gap**

Ona gerçeği ____ hoşlanmıyorum.

I don't like telling him the truth.

[[Turkish#^tr-Q0247-answer|Compare the answer]]
^tr-Q0247

**tr-Q0248 · Choose the form**

Ona gerçeği ____ hoşlanmıyorum.

I don't like telling him the truth.

Choices: okuldan / kitaptan / evden / söylemekten

[[Turkish#^tr-Q0248-answer|Compare the answer]]
^tr-Q0248

**tr-Q0249 · Edit the changed sentence**

İçtenlikle 【evden】 şüphe ediyorum.

I sincerely doubt that.

[[Turkish#^tr-Q0249-answer|Compare the answer]]
^tr-Q0249

**tr-Q0250 · Build the sentence**

Arrange: İçtenlikle / bundan / ediyorum. / şüphe

I sincerely doubt that.

[[Turkish#^tr-Q0250-answer|Compare the answer]]
^tr-Q0250


### Accusative objects · 50 questions

**tr-Q0251 · Write a translation**

Write this in Turkish: I need you to find them.

[[Turkish#^tr-Q0251-answer|Compare the answer]]
^tr-Q0251

**tr-Q0252 · Explain the grammar**

【Onları】 bulmak için sana ihtiyacım var.

I need you to find them.

[[Turkish#^tr-Q0252-answer|Compare the answer]]
^tr-Q0252

**tr-Q0253 · Fill the gap**

____ takip etmemeliydin.

You shouldn't have followed me.

[[Turkish#^tr-Q0253-answer|Compare the answer]]
^tr-Q0253

**tr-Q0254 · Choose the form**

____ takip etmemeliydin.

You shouldn't have followed me.

Choices: bizi / seni / onu / Beni

[[Turkish#^tr-Q0254-answer|Compare the answer]]
^tr-Q0254

**tr-Q0255 · Edit the changed sentence**

Tom ona 【beni】 kimin söylediğini hatırlamıyor.

Tom doesn't remember who told him that.

[[Turkish#^tr-Q0255-answer|Compare the answer]]
^tr-Q0255

**tr-Q0256 · Build the sentence**

Arrange: onu / söylediğini / kimin / Tom / ona / hatırlamıyor.

Tom doesn't remember who told him that.

[[Turkish#^tr-Q0256-answer|Compare the answer]]
^tr-Q0256

**tr-Q0257 · Write a translation**

Write this in Turkish: Are you sure that you know me?

[[Turkish#^tr-Q0257-answer|Compare the answer]]
^tr-Q0257

**tr-Q0258 · Explain the grammar**

【Beni】 tanıdığına emin misin?

Are you sure that you know me?

[[Turkish#^tr-Q0258-answer|Compare the answer]]
^tr-Q0258

**tr-Q0259 · Fill the gap**

____ şimdi tartışmak yersiz olurdu.

It would be inappropriate to discuss that now.

[[Turkish#^tr-Q0259-answer|Compare the answer]]
^tr-Q0259

**tr-Q0260 · Choose the form**

____ şimdi tartışmak yersiz olurdu.

It would be inappropriate to discuss that now.

Choices: bizi / beni / Onu / seni

[[Turkish#^tr-Q0260-answer|Compare the answer]]
^tr-Q0260

**tr-Q0261 · Edit the changed sentence**

Tom 【seni】 kesti.

Tom cut me off.

[[Turkish#^tr-Q0261-answer|Compare the answer]]
^tr-Q0261

**tr-Q0262 · Build the sentence**

Arrange: beni / Tom / kesti.

Tom cut me off.

[[Turkish#^tr-Q0262-answer|Compare the answer]]
^tr-Q0262

**tr-Q0263 · Write a translation**

Write this in Turkish: How long did you wait for me?

[[Turkish#^tr-Q0263-answer|Compare the answer]]
^tr-Q0263

**tr-Q0264 · Explain the grammar**

【Beni】 ne kadar bekledin?

How long did you wait for me?

[[Turkish#^tr-Q0264-answer|Compare the answer]]
^tr-Q0264

**tr-Q0265 · Fill the gap**

____ daha sonra ara.

Call me later.

[[Turkish#^tr-Q0265-answer|Compare the answer]]
^tr-Q0265

**tr-Q0266 · Choose the form**

____ daha sonra ara.

Call me later.

Choices: onu / seni / Beni / bizi

[[Turkish#^tr-Q0266-answer|Compare the answer]]
^tr-Q0266

**tr-Q0267 · Edit the changed sentence**

Eğer zorlukların olursa 【seni】 ara.

Call me if you have difficulties.

[[Turkish#^tr-Q0267-answer|Compare the answer]]
^tr-Q0267

**tr-Q0268 · Build the sentence**

Arrange: ara. / beni / zorlukların / olursa / Eğer

Call me if you have difficulties.

[[Turkish#^tr-Q0268-answer|Compare the answer]]
^tr-Q0268

**tr-Q0269 · Write a translation**

Write this in Turkish: The police threatened to send her to jail.

[[Turkish#^tr-Q0269-answer|Compare the answer]]
^tr-Q0269

**tr-Q0270 · Explain the grammar**

Polis 【onu】 hapishaneye göndermekle tehdit etti.

The police threatened to send her to jail.

[[Turkish#^tr-Q0270-answer|Compare the answer]]
^tr-Q0270

**tr-Q0271 · Fill the gap**

Bir kalabalık ____ görmek için bekledi.

A crowd waited to see him.

[[Turkish#^tr-Q0271-answer|Compare the answer]]
^tr-Q0271

**tr-Q0272 · Choose the form**

Bir kalabalık ____ görmek için bekledi.

A crowd waited to see him.

Choices: onu / beni / bizi / seni

[[Turkish#^tr-Q0272-answer|Compare the answer]]
^tr-Q0272

**tr-Q0273 · Edit the changed sentence**

【beni】 işe almaya karar verdik.

We've decided to hire him.

[[Turkish#^tr-Q0273-answer|Compare the answer]]
^tr-Q0273

**tr-Q0274 · Build the sentence**

Arrange: karar / almaya / verdik. / Onu / işe

We've decided to hire him.

[[Turkish#^tr-Q0274-answer|Compare the answer]]
^tr-Q0274

**tr-Q0275 · Write a translation**

Write this in Turkish: Don't leave him alone with that bag of dried figs.

[[Turkish#^tr-Q0275-answer|Compare the answer]]
^tr-Q0275

**tr-Q0276 · Explain the grammar**

【Onu】 o kuru incir torbasıyla yalnız bırakma.

Don't leave him alone with that bag of dried figs.

[[Turkish#^tr-Q0276-answer|Compare the answer]]
^tr-Q0276

**tr-Q0277 · Fill the gap**

____ kovamazsın, ayrılıyorum!

You can't fire me, I quit!

[[Turkish#^tr-Q0277-answer|Compare the answer]]
^tr-Q0277

**tr-Q0278 · Choose the form**

____ kovamazsın, ayrılıyorum!

You can't fire me, I quit!

Choices: Beni / onu / bizi / seni

[[Turkish#^tr-Q0278-answer|Compare the answer]]
^tr-Q0278

**tr-Q0279 · Edit the changed sentence**

Şimdi 【beni】 görmek istemiyorum.

I don't want to see them now.

[[Turkish#^tr-Q0279-answer|Compare the answer]]
^tr-Q0279

**tr-Q0280 · Build the sentence**

Arrange: Şimdi / onları / istemiyorum. / görmek

I don't want to see them now.

[[Turkish#^tr-Q0280-answer|Compare the answer]]
^tr-Q0280

**tr-Q0281 · Write a translation**

Write this in Turkish: I've seen it myself.

[[Turkish#^tr-Q0281-answer|Compare the answer]]
^tr-Q0281

**tr-Q0282 · Explain the grammar**

【Onu】 kendim gördüm.

I've seen it myself.

[[Turkish#^tr-Q0282-answer|Compare the answer]]
^tr-Q0282

**tr-Q0283 · Fill the gap**

Bak, bu bir kayıt noktası! ____ istediğini biliyorsun!

Look, it's a save point! You know you want it!

[[Turkish#^tr-Q0283-answer|Compare the answer]]
^tr-Q0283

**tr-Q0284 · Choose the form**

Bak, bu bir kayıt noktası! ____ istediğini biliyorsun!

Look, it's a save point! You know you want it!

Choices: bizi / beni / seni / Onu

[[Turkish#^tr-Q0284-answer|Compare the answer]]
^tr-Q0284

**tr-Q0285 · Edit the changed sentence**

【beni】 hava yoluyla gönderirsem, kaça mal olur.

If I send it by air mail, how much will it cost?

[[Turkish#^tr-Q0285-answer|Compare the answer]]
^tr-Q0285

**tr-Q0286 · Build the sentence**

Arrange: mal / hava / Onu / olur. / kaça / gönderirsem, / yoluyla

If I send it by air mail, how much will it cost?

[[Turkish#^tr-Q0286-answer|Compare the answer]]
^tr-Q0286

**tr-Q0287 · Write a translation**

Write this in Turkish: I'm sorry, the manager won't be able to see you. He's engaged.

[[Turkish#^tr-Q0287-answer|Compare the answer]]
^tr-Q0287

**tr-Q0288 · Explain the grammar**

Üzgünüm, yönetici 【sizi】 göremeyecek. O meşgul.

I'm sorry, the manager won't be able to see you. He's engaged.

[[Turkish#^tr-Q0288-answer|Compare the answer]]
^tr-Q0288

**tr-Q0289 · Fill the gap**

Belki ____ tekrar yapmamalısın.

Maybe you shouldn't do that again.

[[Turkish#^tr-Q0289-answer|Compare the answer]]
^tr-Q0289

**tr-Q0290 · Choose the form**

Belki ____ tekrar yapmamalısın.

Maybe you shouldn't do that again.

Choices: seni / beni / onu / bizi

[[Turkish#^tr-Q0290-answer|Compare the answer]]
^tr-Q0290

**tr-Q0291 · Edit the changed sentence**

Onun utancı 【beni】 yapmasını engelledi.

His shame prevented him from doing that.

[[Turkish#^tr-Q0291-answer|Compare the answer]]
^tr-Q0291

**tr-Q0292 · Build the sentence**

Arrange: utancı / onu / yapmasını / engelledi. / Onun

His shame prevented him from doing that.

[[Turkish#^tr-Q0292-answer|Compare the answer]]
^tr-Q0292

**tr-Q0293 · Write a translation**

Write this in Turkish: Tom didn't want to help and Mary couldn't persuade him to.

[[Turkish#^tr-Q0293-answer|Compare the answer]]
^tr-Q0293

**tr-Q0294 · Explain the grammar**

Tom yardım etmek istemiyordu ve Mary yardım etmesi için 【onu】 ikna edemedi.

Tom didn't want to help and Mary couldn't persuade him to.

[[Turkish#^tr-Q0294-answer|Compare the answer]]
^tr-Q0294

**tr-Q0295 · Fill the gap**

____ görmek için sabırsızlanıyoruz.

We are looking forward to seeing you.

[[Turkish#^tr-Q0295-answer|Compare the answer]]
^tr-Q0295

**tr-Q0296 · Choose the form**

____ görmek için sabırsızlanıyoruz.

We are looking forward to seeing you.

Choices: Sizi / seni / onu / beni

[[Turkish#^tr-Q0296-answer|Compare the answer]]
^tr-Q0296

**tr-Q0297 · Edit the changed sentence**

Tom ne zaman 【beni】 yapmanı öğretti?

When did Tom teach you to do that?

[[Turkish#^tr-Q0297-answer|Compare the answer]]
^tr-Q0297

**tr-Q0298 · Build the sentence**

Arrange: zaman / öğretti? / onu / yapmanı / Tom / ne

When did Tom teach you to do that?

[[Turkish#^tr-Q0298-answer|Compare the answer]]
^tr-Q0298

**tr-Q0299 · Write a translation**

Write this in Turkish: I wish you'd stop asking that.

[[Turkish#^tr-Q0299-answer|Compare the answer]]
^tr-Q0299

**tr-Q0300 · Explain the grammar**

Keşke 【onu】 sormayı bıraksan.

I wish you'd stop asking that.

[[Turkish#^tr-Q0300-answer|Compare the answer]]
^tr-Q0300


### Dative direction · 50 questions

**tr-Q0301 · Fill the gap**

Bir daha ____ asla dokunma.

Don't you ever touch me again.

[[Turkish#^tr-Q0301-answer|Compare the answer]]
^tr-Q0301

**tr-Q0302 · Choose the form**

Bir daha ____ asla dokunma.

Don't you ever touch me again.

Choices: bize / bana / sana / ona

[[Turkish#^tr-Q0302-answer|Compare the answer]]
^tr-Q0302

**tr-Q0303 · Edit the changed sentence**

【sana】 dinlenmek için zaman verin.

Give me time to relax.

[[Turkish#^tr-Q0303-answer|Compare the answer]]
^tr-Q0303

**tr-Q0304 · Build the sentence**

Arrange: dinlenmek / verin. / Bana / için / zaman

Give me time to relax.

[[Turkish#^tr-Q0304-answer|Compare the answer]]
^tr-Q0304

**tr-Q0305 · Write a translation**

Write this in Turkish: I can't give it to them.

[[Turkish#^tr-Q0305-answer|Compare the answer]]
^tr-Q0305

**tr-Q0306 · Explain the grammar**

Bunu 【onlara】 veremem.

I can't give it to them.

[[Turkish#^tr-Q0306-answer|Compare the answer]]
^tr-Q0306

**tr-Q0307 · Fill the gap**

Bir seçeneğim olsa şimdi ____ giderim.

If I had a choice, I'd go home now.

[[Turkish#^tr-Q0307-answer|Compare the answer]]
^tr-Q0307

**tr-Q0308 · Choose the form**

Bir seçeneğim olsa şimdi ____ giderim.

If I had a choice, I'd go home now.

Choices: bana / sana / eve / ona

[[Turkish#^tr-Q0308-answer|Compare the answer]]
^tr-Q0308

**tr-Q0309 · Edit the changed sentence**

【bana】 bir hayat bulmasını söyle.

Tell him to get a life.

[[Turkish#^tr-Q0309-answer|Compare the answer]]
^tr-Q0309

**tr-Q0310 · Build the sentence**

Arrange: hayat / bulmasını / söyle. / bir / Ona

Tell him to get a life.

[[Turkish#^tr-Q0310-answer|Compare the answer]]
^tr-Q0310

**tr-Q0311 · Write a translation**

Write this in Turkish: Tom told me he was hoping to get into Harvard.

[[Turkish#^tr-Q0311-answer|Compare the answer]]
^tr-Q0311

**tr-Q0312 · Explain the grammar**

Tom 【bana】 Harvard'a girmeyi umduğunu söyledi.

Tom told me he was hoping to get into Harvard.

[[Turkish#^tr-Q0312-answer|Compare the answer]]
^tr-Q0312

**tr-Q0313 · Fill the gap**

Tom ____ bir yalan söyledi.

Tom told me a lie.

[[Turkish#^tr-Q0313-answer|Compare the answer]]
^tr-Q0313

**tr-Q0314 · Choose the form**

Tom ____ bir yalan söyledi.

Tom told me a lie.

Choices: ona / bana / sana / bize

[[Turkish#^tr-Q0314-answer|Compare the answer]]
^tr-Q0314

**tr-Q0315 · Edit the changed sentence**

Eliimden geldiğince kısa sürede 【bana】 geri ödeyeceğim.

I'll pay you back as soon as I can.

[[Turkish#^tr-Q0315-answer|Compare the answer]]
^tr-Q0315

**tr-Q0316 · Build the sentence**

Arrange: size / sürede / Eliimden / kısa / geldiğince / geri / ödeyeceğim.

I'll pay you back as soon as I can.

[[Turkish#^tr-Q0316-answer|Compare the answer]]
^tr-Q0316

**tr-Q0317 · Write a translation**

Write this in Turkish: Have you told him already?

[[Turkish#^tr-Q0317-answer|Compare the answer]]
^tr-Q0317

**tr-Q0318 · Explain the grammar**

Önceden 【ona】 söyledin mi?

Have you told him already?

[[Turkish#^tr-Q0318-answer|Compare the answer]]
^tr-Q0318

**tr-Q0319 · Fill the gap**

____ yardım etmeye gideceğim.

I'll go and give her a hand.

[[Turkish#^tr-Q0319-answer|Compare the answer]]
^tr-Q0319

**tr-Q0320 · Choose the form**

____ yardım etmeye gideceğim.

I'll go and give her a hand.

Choices: sana / bana / Ona / bize

[[Turkish#^tr-Q0320-answer|Compare the answer]]
^tr-Q0320

**tr-Q0321 · Edit the changed sentence**

【bana】 bir şey söylemeliyim.

I need to tell him something.

[[Turkish#^tr-Q0321-answer|Compare the answer]]
^tr-Q0321

**tr-Q0322 · Build the sentence**

Arrange: Ona / şey / söylemeliyim. / bir

I need to tell him something.

[[Turkish#^tr-Q0322-answer|Compare the answer]]
^tr-Q0322

**tr-Q0323 · Write a translation**

Write this in Turkish: What did you tell him about us?

[[Turkish#^tr-Q0323-answer|Compare the answer]]
^tr-Q0323

**tr-Q0324 · Explain the grammar**

【Ona】 bizim hakkımızda ne söyledin?

What did you tell him about us?

[[Turkish#^tr-Q0324-answer|Compare the answer]]
^tr-Q0324

**tr-Q0325 · Fill the gap**

Tom ____ yardım etmedi.

Tom wouldn't help me.

[[Turkish#^tr-Q0325-answer|Compare the answer]]
^tr-Q0325

**tr-Q0326 · Choose the form**

Tom ____ yardım etmedi.

Tom wouldn't help me.

Choices: sana / bize / ona / bana

[[Turkish#^tr-Q0326-answer|Compare the answer]]
^tr-Q0326

**tr-Q0327 · Edit the changed sentence**

Kız kardeşinin aksine, o, ebeveynlerinin 【bana】 verdiği dini inancı korudu.

Unlike his sister, he has retained the religious faith his parents brought him up in.

[[Turkish#^tr-Q0327-answer|Compare the answer]]
^tr-Q0327

**tr-Q0328 · Build the sentence**

Arrange: Kız / inancı / ebeveynlerinin / ona / verdiği / o, / dini / aksine, / kardeşinin / korudu.

Unlike his sister, he has retained the religious faith his parents brought him up in.

[[Turkish#^tr-Q0328-answer|Compare the answer]]
^tr-Q0328

**tr-Q0329 · Write a translation**

Write this in Turkish: Are we going to help them?

[[Turkish#^tr-Q0329-answer|Compare the answer]]
^tr-Q0329

**tr-Q0330 · Explain the grammar**

【Onlara】 yardım edecek miyiz?

Are we going to help them?

[[Turkish#^tr-Q0330-answer|Compare the answer]]
^tr-Q0330

**tr-Q0331 · Fill the gap**

Tom ____ ne zaman geleceğini söyledi mi?

Did Tom say when he'd arrive?

[[Turkish#^tr-Q0331-answer|Compare the answer]]
^tr-Q0331

**tr-Q0332 · Choose the form**

Tom ____ ne zaman geleceğini söyledi mi?

Did Tom say when he'd arrive?

Choices: ona / bana / bize / sana

[[Turkish#^tr-Q0332-answer|Compare the answer]]
^tr-Q0332

**tr-Q0333 · Edit the changed sentence**

【bana】 yardım edebileceğini umuyorum.

I hope you can help us.

[[Turkish#^tr-Q0333-answer|Compare the answer]]
^tr-Q0333

**tr-Q0334 · Build the sentence**

Arrange: yardım / edebileceğini / umuyorum. / Bize

I hope you can help us.

[[Turkish#^tr-Q0334-answer|Compare the answer]]
^tr-Q0334

**tr-Q0335 · Write a translation**

Write this in Turkish: Pass me the pepper grinder.

[[Turkish#^tr-Q0335-answer|Compare the answer]]
^tr-Q0335

**tr-Q0336 · Explain the grammar**

Karabiber değirmenini 【bana】 uzat.

Pass me the pepper grinder.

[[Turkish#^tr-Q0336-answer|Compare the answer]]
^tr-Q0336

**tr-Q0337 · Fill the gap**

Üzgünüm, ben ____ yardımcı olamam.

I'm sorry, I can't help you.

[[Turkish#^tr-Q0337-answer|Compare the answer]]
^tr-Q0337

**tr-Q0338 · Choose the form**

Üzgünüm, ben ____ yardımcı olamam.

I'm sorry, I can't help you.

Choices: ona / bana / sana / size

[[Turkish#^tr-Q0338-answer|Compare the answer]]
^tr-Q0338

**tr-Q0339 · Edit the changed sentence**

【bana】 nasıl yardım edebiliriz?

How can we help you?

[[Turkish#^tr-Q0339-answer|Compare the answer]]
^tr-Q0339

**tr-Q0340 · Build the sentence**

Arrange: nasıl / yardım / edebiliriz? / Sana

How can we help you?

[[Turkish#^tr-Q0340-answer|Compare the answer]]
^tr-Q0340

**tr-Q0341 · Write a translation**

Write this in Turkish: We're really glad you decided to help us.

[[Turkish#^tr-Q0341-answer|Compare the answer]]
^tr-Q0341

**tr-Q0342 · Explain the grammar**

【Bize】 yardım etmeye karar verdiğine gerçekten çok sevindik.

We're really glad you decided to help us.

[[Turkish#^tr-Q0342-answer|Compare the answer]]
^tr-Q0342

**tr-Q0343 · Fill the gap**

Tom ____ tekrar yazmadı.

Tom hasn't written me back.

[[Turkish#^tr-Q0343-answer|Compare the answer]]
^tr-Q0343

**tr-Q0344 · Choose the form**

Tom ____ tekrar yazmadı.

Tom hasn't written me back.

Choices: ona / bana / sana / bize

[[Turkish#^tr-Q0344-answer|Compare the answer]]
^tr-Q0344

**tr-Q0345 · Edit the changed sentence**

Bu 【sana】 bir ders verdi.

It taught me a lesson.

[[Turkish#^tr-Q0345-answer|Compare the answer]]
^tr-Q0345

**tr-Q0346 · Build the sentence**

Arrange: bir / ders / bana / verdi. / Bu

It taught me a lesson.

[[Turkish#^tr-Q0346-answer|Compare the answer]]
^tr-Q0346

**tr-Q0347 · Write a translation**

Write this in Turkish: He told me that he needs space.

[[Turkish#^tr-Q0347-answer|Compare the answer]]
^tr-Q0347

**tr-Q0348 · Explain the grammar**

O 【bana】 alana ihtiyacı olduğunu söyledi.

He told me that he needs space.

[[Turkish#^tr-Q0348-answer|Compare the answer]]
^tr-Q0348

**tr-Q0349 · Fill the gap**

Tom ____ bir şans daha verecek.

Tom will give you another chance.

[[Turkish#^tr-Q0349-answer|Compare the answer]]
^tr-Q0349

**tr-Q0350 · Choose the form**

Tom ____ bir şans daha verecek.

Tom will give you another chance.

Choices: ona / bize / bana / sana

[[Turkish#^tr-Q0350-answer|Compare the answer]]
^tr-Q0350


### Possession and genitive · 50 questions

**tr-Q0351 · Edit the changed sentence**

【benim】 tekrar olmasına izin vermeyeceğine güveniyorum.

I trust you won't let that happen again.

[[Turkish#^tr-Q0351-answer|Compare the answer]]
^tr-Q0351

**tr-Q0352 · Build the sentence**

Arrange: tekrar / vermeyeceğine / izin / olmasına / güveniyorum. / Onun

I trust you won't let that happen again.

[[Turkish#^tr-Q0352-answer|Compare the answer]]
^tr-Q0352

**tr-Q0353 · Write a translation**

Write this in Turkish: I own a horse.

[[Turkish#^tr-Q0353-answer|Compare the answer]]
^tr-Q0353

**tr-Q0354 · Explain the grammar**

【Benim】 bir atım var.

I own a horse.

[[Turkish#^tr-Q0354-answer|Compare the answer]]
^tr-Q0354

**tr-Q0355 · Fill the gap**

____ şirketim var.

I've got company.

[[Turkish#^tr-Q0355-answer|Compare the answer]]
^tr-Q0355

**tr-Q0356 · Choose the form**

____ şirketim var.

I've got company.

Choices: Benim / onun / bizim / senin

[[Turkish#^tr-Q0356-answer|Compare the answer]]
^tr-Q0356

**tr-Q0357 · Edit the changed sentence**

【benim】 ve Tom'un dövüştüğüne üzgünüm.

I'm sorry that you and Tom had a fight.

[[Turkish#^tr-Q0357-answer|Compare the answer]]
^tr-Q0357

**tr-Q0358 · Build the sentence**

Arrange: Tom'un / ve / dövüştüğüne / Senin / üzgünüm.

I'm sorry that you and Tom had a fight.

[[Turkish#^tr-Q0358-answer|Compare the answer]]
^tr-Q0358

**tr-Q0359 · Write a translation**

Write this in Turkish: Tom is a dear friend of mine.

[[Turkish#^tr-Q0359-answer|Compare the answer]]
^tr-Q0359

**tr-Q0360 · Explain the grammar**

Tom 【benim】 değerli bir arkadaşım.

Tom is a dear friend of mine.

[[Turkish#^tr-Q0360-answer|Compare the answer]]
^tr-Q0360

**tr-Q0361 · Fill the gap**

____ dört çocuğum var.

I have four children.

[[Turkish#^tr-Q0361-answer|Compare the answer]]
^tr-Q0361

**tr-Q0362 · Choose the form**

____ dört çocuğum var.

I have four children.

Choices: bizim / onun / Benim / senin

[[Turkish#^tr-Q0362-answer|Compare the answer]]
^tr-Q0362

**tr-Q0363 · Edit the changed sentence**

【benim】 yardıma ihtiyacı var.

They need help.

[[Turkish#^tr-Q0363-answer|Compare the answer]]
^tr-Q0363

**tr-Q0364 · Build the sentence**

Arrange: yardıma / Onların / ihtiyacı / var.

They need help.

[[Turkish#^tr-Q0364-answer|Compare the answer]]
^tr-Q0364

**tr-Q0365 · Write a translation**

Write this in Turkish: Why do you always take her side?

[[Turkish#^tr-Q0365-answer|Compare the answer]]
^tr-Q0365

**tr-Q0366 · Explain the grammar**

Neden hep 【onun】 tarafını tutuyorsun?

Why do you always take her side?

[[Turkish#^tr-Q0366-answer|Compare the answer]]
^tr-Q0366

**tr-Q0367 · Fill the gap**

____ Meclis'te çoğunluğu vardı.

They had the majority in Parliament.

[[Turkish#^tr-Q0367-answer|Compare the answer]]
^tr-Q0367

**tr-Q0368 · Choose the form**

____ Meclis'te çoğunluğu vardı.

They had the majority in Parliament.

Choices: benim / senin / onun / Onların

[[Turkish#^tr-Q0368-answer|Compare the answer]]
^tr-Q0368

**tr-Q0369 · Edit the changed sentence**

Tom'un konuşma şekli 【senin】 sinirlerimi bozuyor.

Tom's way of speaking gets on my nerves.

[[Turkish#^tr-Q0369-answer|Compare the answer]]
^tr-Q0369

**tr-Q0370 · Build the sentence**

Arrange: sinirlerimi / benim / konuşma / bozuyor. / şekli / Tom'un

Tom's way of speaking gets on my nerves.

[[Turkish#^tr-Q0370-answer|Compare the answer]]
^tr-Q0370

**tr-Q0371 · Write a translation**

Write this in Turkish: Her parents were out of town.

[[Turkish#^tr-Q0371-answer|Compare the answer]]
^tr-Q0371

**tr-Q0372 · Explain the grammar**

【Onun】 ebeveynleri şehir dışındaydı.

Her parents were out of town.

[[Turkish#^tr-Q0372-answer|Compare the answer]]
^tr-Q0372

**tr-Q0373 · Fill the gap**

____ ne kadar süreceği hakkında hiçbir fikrim yok.

I have no idea how long it will take.

[[Turkish#^tr-Q0373-answer|Compare the answer]]
^tr-Q0373

**tr-Q0374 · Choose the form**

____ ne kadar süreceği hakkında hiçbir fikrim yok.

I have no idea how long it will take.

Choices: Onun / benim / bizim / senin

[[Turkish#^tr-Q0374-answer|Compare the answer]]
^tr-Q0374

**tr-Q0375 · Edit the changed sentence**

Gelecek kış 【benim】 kısa sürede unutmayacakları bir kış olacak.

The coming winter would be one they would not soon forget.

[[Turkish#^tr-Q0375-answer|Compare the answer]]
^tr-Q0375

**tr-Q0376 · Build the sentence**

Arrange: kış / kısa / bir / unutmayacakları / kış / olacak. / Gelecek / onların / sürede

The coming winter would be one they would not soon forget.

[[Turkish#^tr-Q0376-answer|Compare the answer]]
^tr-Q0376

**tr-Q0377 · Write a translation**

Write this in Turkish: I can't believe you quit playing harp.

[[Turkish#^tr-Q0377-answer|Compare the answer]]
^tr-Q0377

**tr-Q0378 · Explain the grammar**

【Senin】 harp çalmayı bırakmana inanamıyorum.

I can't believe you quit playing harp.

[[Turkish#^tr-Q0378-answer|Compare the answer]]
^tr-Q0378

**tr-Q0379 · Fill the gap**

____ hepsi dosyada.

It's all in the file.

[[Turkish#^tr-Q0379-answer|Compare the answer]]
^tr-Q0379

**tr-Q0380 · Choose the form**

____ hepsi dosyada.

It's all in the file.

Choices: Onun / benim / senin / bizim

[[Turkish#^tr-Q0380-answer|Compare the answer]]
^tr-Q0380

**tr-Q0381 · Edit the changed sentence**

Bir konferansta 【benim】 eski işverenini gördün, değil mi?

You saw your former employer at a conference, didn't you?

[[Turkish#^tr-Q0381-answer|Compare the answer]]
^tr-Q0381

**tr-Q0382 · Build the sentence**

Arrange: konferansta / gördün, / işverenini / senin / değil / Bir / mi? / eski

You saw your former employer at a conference, didn't you?

[[Turkish#^tr-Q0382-answer|Compare the answer]]
^tr-Q0382

**tr-Q0383 · Write a translation**

Write this in Turkish: Your moon returns.

[[Turkish#^tr-Q0383-answer|Compare the answer]]
^tr-Q0383

**tr-Q0384 · Explain the grammar**

【Senin】 ayın geri dönüyor

Your moon returns.

[[Turkish#^tr-Q0384-answer|Compare the answer]]
^tr-Q0384

**tr-Q0385 · Fill the gap**

Ben ____ müziğini seviyorum.

I like his music.

[[Turkish#^tr-Q0385-answer|Compare the answer]]
^tr-Q0385

**tr-Q0386 · Choose the form**

Ben ____ müziğini seviyorum.

I like his music.

Choices: bizim / onun / benim / senin

[[Turkish#^tr-Q0386-answer|Compare the answer]]
^tr-Q0386

**tr-Q0387 · Edit the changed sentence**

Bir ülke tarafından üretilen kağıt miktarı 【benim】 kültürel standartlarıyla yakından ilişkilidir.

The amount of paper produced by a country is closely related to its cultural standards.

[[Turkish#^tr-Q0387-answer|Compare the answer]]
^tr-Q0387

**tr-Q0388 · Build the sentence**

Arrange: miktarı / onun / tarafından / yakından / Bir / standartlarıyla / kağıt / ilişkilidir. / kültürel / üretilen / ülke

The amount of paper produced by a country is closely related to its cultural standards.

[[Turkish#^tr-Q0388-answer|Compare the answer]]
^tr-Q0388

**tr-Q0389 · Write a translation**

Write this in Turkish: Officially, he works for us as an interpreter.

[[Turkish#^tr-Q0389-answer|Compare the answer]]
^tr-Q0389

**tr-Q0390 · Explain the grammar**

Resmi olarak, o bir tercüman olarak 【bizim】 için çalışıyor.

Officially, he works for us as an interpreter.

[[Turkish#^tr-Q0390-answer|Compare the answer]]
^tr-Q0390

**tr-Q0391 · Fill the gap**

____ keskin bir işitmesi var.

He has sharp hearing.

[[Turkish#^tr-Q0391-answer|Compare the answer]]
^tr-Q0391

**tr-Q0392 · Choose the form**

____ keskin bir işitmesi var.

He has sharp hearing.

Choices: benim / senin / Onun / bizim

[[Turkish#^tr-Q0392-answer|Compare the answer]]
^tr-Q0392

**tr-Q0393 · Edit the changed sentence**

【benim】 sana söylediğine hiç aldırış etme.

Don't pay any attention to what he tells you.

[[Turkish#^tr-Q0393-answer|Compare the answer]]
^tr-Q0393

**tr-Q0394 · Build the sentence**

Arrange: aldırış / etme. / sana / Onun / söylediğine / hiç

Don't pay any attention to what he tells you.

[[Turkish#^tr-Q0394-answer|Compare the answer]]
^tr-Q0394

**tr-Q0395 · Write a translation**

Write this in Turkish: We can see his house over there.

[[Turkish#^tr-Q0395-answer|Compare the answer]]
^tr-Q0395

**tr-Q0396 · Explain the grammar**

Orada 【onun】 evini görebiliriz.

We can see his house over there.

[[Turkish#^tr-Q0396-answer|Compare the answer]]
^tr-Q0396

**tr-Q0397 · Fill the gap**

____ onlara yardım etmemiz gerekebilir.

We may need to help them.

[[Turkish#^tr-Q0397-answer|Compare the answer]]
^tr-Q0397

**tr-Q0398 · Choose the form**

____ onlara yardım etmemiz gerekebilir.

We may need to help them.

Choices: onun / benim / senin / Bizim

[[Turkish#^tr-Q0398-answer|Compare the answer]]
^tr-Q0398

**tr-Q0399 · Edit the changed sentence**

Eğer 【benim】 son topa vuran oyuncumuz tur vuruşu yapmasaydı, takım oyunu kaybederdi.

If our last batter had not hit a home run, team would have lost the game.

[[Turkish#^tr-Q0399-answer|Compare the answer]]
^tr-Q0399

**tr-Q0400 · Build the sentence**

Arrange: takım / bizim / oyunu / tur / vuruşu / topa / oyuncumuz / Eğer / yapmasaydı, / vuran / son / kaybederdi.

If our last batter had not hit a home run, team would have lost the game.

[[Turkish#^tr-Q0400-answer|Compare the answer]]
^tr-Q0400


### Progressive verbs · 50 questions

**tr-Q0401 · Write a translation**

Write this in Turkish: I know who got the prize.

[[Turkish#^tr-Q0401-answer|Compare the answer]]
^tr-Q0401

**tr-Q0402 · Explain the grammar**

Ödülü kimin aldığını 【biliyorum】.

I know who got the prize.

[[Turkish#^tr-Q0402-answer|Compare the answer]]
^tr-Q0402

**tr-Q0403 · Fill the gap**

Hâlâ ____ musunuz?

Are you still having fun?

[[Turkish#^tr-Q0403-answer|Compare the answer]]
^tr-Q0403

**tr-Q0404 · Choose the form**

Hâlâ ____ musunuz?

Are you still having fun?

Choices: geliyor / geliyorum / geliyorsun / eğleniyor

[[Turkish#^tr-Q0404-answer|Compare the answer]]
^tr-Q0404

**tr-Q0405 · Edit the changed sentence**

Müdür seninle konuşmak 【geliyorum】.

The principal wants to talk to you.

[[Turkish#^tr-Q0405-answer|Compare the answer]]
^tr-Q0405

**tr-Q0406 · Build the sentence**

Arrange: istiyor. / Müdür / konuşmak / seninle

The principal wants to talk to you.

[[Turkish#^tr-Q0406-answer|Compare the answer]]
^tr-Q0406

**tr-Q0407 · Write a translation**

Write this in Turkish: Don't you understand what you have to do?

[[Turkish#^tr-Q0407-answer|Compare the answer]]
^tr-Q0407

**tr-Q0408 · Explain the grammar**

Ne yapman gerektiğini 【anlamıyor】 musun?

Don't you understand what you have to do?

[[Turkish#^tr-Q0408-answer|Compare the answer]]
^tr-Q0408

**tr-Q0409 · Fill the gap**

Tom'un haklı olduğunu ____.

You know Tom was right.

[[Turkish#^tr-Q0409-answer|Compare the answer]]
^tr-Q0409

**tr-Q0410 · Choose the form**

Tom'un haklı olduğunu ____.

You know Tom was right.

Choices: geliyorum / geliyorsun / biliyorsun / geliyor

[[Turkish#^tr-Q0410-answer|Compare the answer]]
^tr-Q0410

**tr-Q0411 · Edit the changed sentence**

Tom'un hâlâ öğle yemeği yeyip yemediğini merak 【geliyorum】.

I wonder if Tom is still eating lunch.

[[Turkish#^tr-Q0411-answer|Compare the answer]]
^tr-Q0411

**tr-Q0412 · Build the sentence**

Arrange: yeyip / merak / hâlâ / Tom'un / öğle / ediyorum. / yemeği / yemediğini

I wonder if Tom is still eating lunch.

[[Turkish#^tr-Q0412-answer|Compare the answer]]
^tr-Q0412

**tr-Q0413 · Write a translation**

Write this in Turkish: Tom says he'll go with us.

[[Turkish#^tr-Q0413-answer|Compare the answer]]
^tr-Q0413

**tr-Q0414 · Explain the grammar**

Tom bizimle gideceğini 【söylüyor】.

Tom says he'll go with us.

[[Turkish#^tr-Q0414-answer|Compare the answer]]
^tr-Q0414

**tr-Q0415 · Fill the gap**

Gerçek bir iş edinmek ____.

I want to get a real job.

[[Turkish#^tr-Q0415-answer|Compare the answer]]
^tr-Q0415

**tr-Q0416 · Choose the form**

Gerçek bir iş edinmek ____.

I want to get a real job.

Choices: geliyor / istiyorum / geliyorsun / geliyorum

[[Turkish#^tr-Q0416-answer|Compare the answer]]
^tr-Q0416

**tr-Q0417 · Edit the changed sentence**

Bir kitap 【geliyorum】 musun?

Do you see a book?

[[Turkish#^tr-Q0417-answer|Compare the answer]]
^tr-Q0417

**tr-Q0418 · Build the sentence**

Arrange: kitap / görüyor / musun? / Bir

Do you see a book?

[[Turkish#^tr-Q0418-answer|Compare the answer]]
^tr-Q0418

**tr-Q0419 · Write a translation**

Write this in Turkish: I believe I was wrong.

[[Turkish#^tr-Q0419-answer|Compare the answer]]
^tr-Q0419

**tr-Q0420 · Explain the grammar**

Hatalı olduğuma 【inanıyorum】.

I believe I was wrong.

[[Turkish#^tr-Q0420-answer|Compare the answer]]
^tr-Q0420

**tr-Q0421 · Fill the gap**

Tom yeni bir bisiklet satın aldı gibi ____.

It looks like Tom has bought a new bicycle.

[[Turkish#^tr-Q0421-answer|Compare the answer]]
^tr-Q0421

**tr-Q0422 · Choose the form**

Tom yeni bir bisiklet satın aldı gibi ____.

It looks like Tom has bought a new bicycle.

Choices: geliyorsun / geliyorum / görünüyor / geliyor

[[Turkish#^tr-Q0422-answer|Compare the answer]]
^tr-Q0422

**tr-Q0423 · Edit the changed sentence**

Sabırsızlıkla acil cevabını almayı 【geliyorum】.

We look forward to receiving your prompt reply.

[[Turkish#^tr-Q0423-answer|Compare the answer]]
^tr-Q0423

**tr-Q0424 · Build the sentence**

Arrange: almayı / bekliyoruz. / acil / Sabırsızlıkla / cevabını

We look forward to receiving your prompt reply.

[[Turkish#^tr-Q0424-answer|Compare the answer]]
^tr-Q0424

**tr-Q0425 · Write a translation**

Write this in Turkish: You're cooperating.

[[Turkish#^tr-Q0425-answer|Compare the answer]]
^tr-Q0425

**tr-Q0426 · Explain the grammar**

Sen işbirliği 【yapıyorsun】.

You're cooperating.

[[Turkish#^tr-Q0426-answer|Compare the answer]]
^tr-Q0426

**tr-Q0427 · Fill the gap**

Tom burada harika bir iş ____.

Tom is doing a wonderful job here.

[[Turkish#^tr-Q0427-answer|Compare the answer]]
^tr-Q0427

**tr-Q0428 · Choose the form**

Tom burada harika bir iş ____.

Tom is doing a wonderful job here.

Choices: geliyorsun / yapıyor / geliyor / geliyorum

[[Turkish#^tr-Q0428-answer|Compare the answer]]
^tr-Q0428

**tr-Q0429 · Edit the changed sentence**

Sen umursamaz 【geliyorum】.

You look unimpressed.

[[Turkish#^tr-Q0429-answer|Compare the answer]]
^tr-Q0429

**tr-Q0430 · Build the sentence**

Arrange: görünüyorsun. / umursamaz / Sen

You look unimpressed.

[[Turkish#^tr-Q0430-answer|Compare the answer]]
^tr-Q0430

**tr-Q0431 · Write a translation**

Write this in Turkish: I'm still thinking about Tom.

[[Turkish#^tr-Q0431-answer|Compare the answer]]
^tr-Q0431

**tr-Q0432 · Explain the grammar**

Hâlâ Tom'u 【düşünüyorum】.

I'm still thinking about Tom.

[[Turkish#^tr-Q0432-answer|Compare the answer]]
^tr-Q0432

**tr-Q0433 · Fill the gap**

Ben atölyede ____.

I am working at the workshop.

[[Turkish#^tr-Q0433-answer|Compare the answer]]
^tr-Q0433

**tr-Q0434 · Choose the form**

Ben atölyede ____.

I am working at the workshop.

Choices: geliyor / çalışıyorum / geliyorsun / geliyorum

[[Turkish#^tr-Q0434-answer|Compare the answer]]
^tr-Q0434

**tr-Q0435 · Edit the changed sentence**

Tom zor zaman 【geliyorum】.

Tom is having a tough time.

[[Turkish#^tr-Q0435-answer|Compare the answer]]
^tr-Q0435

**tr-Q0436 · Build the sentence**

Arrange: zor / zaman / geçiriyor. / Tom

Tom is having a tough time.

[[Turkish#^tr-Q0436-answer|Compare the answer]]
^tr-Q0436

**tr-Q0437 · Write a translation**

Write this in Turkish: Everyone's looking for Tom.

[[Turkish#^tr-Q0437-answer|Compare the answer]]
^tr-Q0437

**tr-Q0438 · Explain the grammar**

Herkes Tom'u 【arıyor】.

Everyone's looking for Tom.

[[Turkish#^tr-Q0438-answer|Compare the answer]]
^tr-Q0438

**tr-Q0439 · Fill the gap**

Tom, Mary'nin şüphelenmeyeceğini ____.

Tom thinks Mary won't be suspicious.

[[Turkish#^tr-Q0439-answer|Compare the answer]]
^tr-Q0439

**tr-Q0440 · Choose the form**

Tom, Mary'nin şüphelenmeyeceğini ____.

Tom thinks Mary won't be suspicious.

Choices: geliyorum / düşünüyor / geliyor / geliyorsun

[[Turkish#^tr-Q0440-answer|Compare the answer]]
^tr-Q0440

**tr-Q0441 · Edit the changed sentence**

Biz içeriye 【geliyorum】.

We're coming in.

[[Turkish#^tr-Q0441-answer|Compare the answer]]
^tr-Q0441

**tr-Q0442 · Build the sentence**

Arrange: Biz / geliyoruz. / içeriye

We're coming in.

[[Turkish#^tr-Q0442-answer|Compare the answer]]
^tr-Q0442

**tr-Q0443 · Write a translation**

Write this in Turkish: Tom still wants Mary to help him do that.

[[Turkish#^tr-Q0443-answer|Compare the answer]]
^tr-Q0443

**tr-Q0444 · Explain the grammar**

Tom hâlâ Mary'den kendisine bunu yapmasına yardım etmesini 【istiyor】.

Tom still wants Mary to help him do that.

[[Turkish#^tr-Q0444-answer|Compare the answer]]
^tr-Q0444

**tr-Q0445 · Fill the gap**

Neden bunu akşam yemeğinde ____?

Why don't we talk about this over dinner?

[[Turkish#^tr-Q0445-answer|Compare the answer]]
^tr-Q0445

**tr-Q0446 · Choose the form**

Neden bunu akşam yemeğinde ____?

Why don't we talk about this over dinner?

Choices: geliyorsun / geliyorum / geliyor / konuşmuyoruz

[[Turkish#^tr-Q0446-answer|Compare the answer]]
^tr-Q0446

**tr-Q0447 · Edit the changed sentence**

Mesajın ne olmasını 【geliyorum】?

What do you want the message to be?

[[Turkish#^tr-Q0447-answer|Compare the answer]]
^tr-Q0447

**tr-Q0448 · Build the sentence**

Arrange: Mesajın / ne / istiyorsun? / olmasını

What do you want the message to be?

[[Turkish#^tr-Q0448-answer|Compare the answer]]
^tr-Q0448

**tr-Q0449 · Write a translation**

Write this in Turkish: Louie, your friends are coming. Clean up.

[[Turkish#^tr-Q0449-answer|Compare the answer]]
^tr-Q0449

**tr-Q0450 · Explain the grammar**

Louie, arkadaşların 【geliyor】. Temizlik yap.

Louie, your friends are coming. Clean up.

[[Turkish#^tr-Q0450-answer|Compare the answer]]
^tr-Q0450


### Past forms · 50 questions

**tr-Q0451 · Fill the gap**

Jane kızgın bir jest ____.

Jane made an angry gesture.

[[Turkish#^tr-Q0451-answer|Compare the answer]]
^tr-Q0451

**tr-Q0452 · Choose the form**

Jane kızgın bir jest ____.

Jane made an angry gesture.

Choices: dedi / gitti / yaptı / geldi

[[Turkish#^tr-Q0452-answer|Compare the answer]]
^tr-Q0452

**tr-Q0453 · Edit the changed sentence**

Buraya otuz dakika önce 【geldi】.

I got here about thirty minutes ago.

[[Turkish#^tr-Q0453-answer|Compare the answer]]
^tr-Q0453

**tr-Q0454 · Build the sentence**

Arrange: geldim. / otuz / Buraya / önce / dakika

I got here about thirty minutes ago.

[[Turkish#^tr-Q0454-answer|Compare the answer]]
^tr-Q0454

**tr-Q0455 · Write a translation**

Write this in Turkish: Mary made her sister a new dress.

[[Turkish#^tr-Q0455-answer|Compare the answer]]
^tr-Q0455

**tr-Q0456 · Explain the grammar**

Mary kardeşine yeni bir elbise 【yaptı】.

Mary made her sister a new dress.

[[Turkish#^tr-Q0456-answer|Compare the answer]]
^tr-Q0456

**tr-Q0457 · Fill the gap**

Eski güzel günlerin hatıraları sel gibi peş peşe ____.

Memories of the good old days came flooding back one after another.

[[Turkish#^tr-Q0457-answer|Compare the answer]]
^tr-Q0457

**tr-Q0458 · Choose the form**

Eski güzel günlerin hatıraları sel gibi peş peşe ____.

Memories of the good old days came flooding back one after another.

Choices: dedi / geldi / yaptı / gitti

[[Turkish#^tr-Q0458-answer|Compare the answer]]
^tr-Q0458

**tr-Q0459 · Edit the changed sentence**

Tom'un konuşma yapmasına gerek yoktui. Mary bütün konuşmayı 【geldi】.

Tom didn't need to speak. Mary did all the talking.

[[Turkish#^tr-Q0459-answer|Compare the answer]]
^tr-Q0459

**tr-Q0460 · Build the sentence**

Arrange: konuşmayı / yapmasına / Tom'un / bütün / Mary / yoktui. / yaptı. / konuşma / gerek

Tom didn't need to speak. Mary did all the talking.

[[Turkish#^tr-Q0460-answer|Compare the answer]]
^tr-Q0460

**tr-Q0461 · Write a translation**

Write this in Turkish: Tom got exactly what he deserved.

[[Turkish#^tr-Q0461-answer|Compare the answer]]
^tr-Q0461

**tr-Q0462 · Explain the grammar**

Tom tamamen hak ettiğini 【aldı】.

Tom got exactly what he deserved.

[[Turkish#^tr-Q0462-answer|Compare the answer]]
^tr-Q0462

**tr-Q0463 · Fill the gap**

Tom aşık ____.

Tom fell in love.

[[Turkish#^tr-Q0463-answer|Compare the answer]]
^tr-Q0463

**tr-Q0464 · Choose the form**

Tom aşık ____.

Tom fell in love.

Choices: gitti / geldi / yaptı / oldu

[[Turkish#^tr-Q0464-answer|Compare the answer]]
^tr-Q0464

**tr-Q0465 · Edit the changed sentence**

O, kuşa nişan 【geldi】.

He aimed at the bird.

[[Turkish#^tr-Q0465-answer|Compare the answer]]
^tr-Q0465

**tr-Q0466 · Build the sentence**

Arrange: O, / nişan / kuşa / aldı.

He aimed at the bird.

[[Turkish#^tr-Q0466-answer|Compare the answer]]
^tr-Q0466

**tr-Q0467 · Write a translation**

Write this in Turkish: Francis arrived at Galeao at six.

[[Turkish#^tr-Q0467-answer|Compare the answer]]
^tr-Q0467

**tr-Q0468 · Explain the grammar**

Francis saat altıda Galeao'ya 【geldi】.

Francis arrived at Galeao at six.

[[Turkish#^tr-Q0468-answer|Compare the answer]]
^tr-Q0468

**tr-Q0469 · Fill the gap**

O gerçekten o şekilde mi ____?

Did it actually happen like that?

[[Turkish#^tr-Q0469-answer|Compare the answer]]
^tr-Q0469

**tr-Q0470 · Choose the form**

O gerçekten o şekilde mi ____?

Did it actually happen like that?

Choices: yaptı / oldu / geldi / gitti

[[Turkish#^tr-Q0470-answer|Compare the answer]]
^tr-Q0470

**tr-Q0471 · Edit the changed sentence**

Süzme peynir yediğimden beri bir süre 【geldi】.

It's been a while since I've eaten cottage cheese.

[[Turkish#^tr-Q0471-answer|Compare the answer]]
^tr-Q0471

**tr-Q0472 · Build the sentence**

Arrange: peynir / süre / yediğimden / beri / oldu. / bir / Süzme

It's been a while since I've eaten cottage cheese.

[[Turkish#^tr-Q0472-answer|Compare the answer]]
^tr-Q0472

**tr-Q0473 · Write a translation**

Write this in Turkish: I went to the hospital to see my wife.

[[Turkish#^tr-Q0473-answer|Compare the answer]]
^tr-Q0473

**tr-Q0474 · Explain the grammar**

Karımı görmek için hastaneye 【gittim】.

I went to the hospital to see my wife.

[[Turkish#^tr-Q0474-answer|Compare the answer]]
^tr-Q0474

**tr-Q0475 · Fill the gap**

Yaşlı kadın ____ ve yakında Prenses ile birlikte geri döndü.

The old woman went, and soon returned along with the Princess.

[[Turkish#^tr-Q0475-answer|Compare the answer]]
^tr-Q0475

**tr-Q0476 · Choose the form**

Yaşlı kadın ____ ve yakında Prenses ile birlikte geri döndü.

The old woman went, and soon returned along with the Princess.

Choices: geldi / yaptı / gitti / dedi

[[Turkish#^tr-Q0476-answer|Compare the answer]]
^tr-Q0476

**tr-Q0477 · Edit the changed sentence**

Oğlunuz öğrenci hareketi içinde yer 【geldi】, ben duydum.

Your son took part in the student movement, I hear.

[[Turkish#^tr-Q0477-answer|Compare the answer]]
^tr-Q0477

**tr-Q0478 · Build the sentence**

Arrange: içinde / öğrenci / aldı, / hareketi / yer / ben / duydum. / Oğlunuz

Your son took part in the student movement, I hear.

[[Turkish#^tr-Q0478-answer|Compare the answer]]
^tr-Q0478

**tr-Q0479 · Write a translation**

Write this in Turkish: The exact same thing happened to my friend a week later!

[[Turkish#^tr-Q0479-answer|Compare the answer]]
^tr-Q0479

**tr-Q0480 · Explain the grammar**

Bir hafta sonra aynı şey arkadaşıma 【oldu】.

The exact same thing happened to my friend a week later!

[[Turkish#^tr-Q0480-answer|Compare the answer]]
^tr-Q0480

**tr-Q0481 · Fill the gap**

Tom, Mary'ye bir sosisli sandviç ____.

Tom bought a hot dog for Mary.

[[Turkish#^tr-Q0481-answer|Compare the answer]]
^tr-Q0481

**tr-Q0482 · Choose the form**

Tom, Mary'ye bir sosisli sandviç ____.

Tom bought a hot dog for Mary.

Choices: gitti / geldi / yaptı / aldı

[[Turkish#^tr-Q0482-answer|Compare the answer]]
^tr-Q0482

**tr-Q0483 · Edit the changed sentence**

Sami bir hata 【geldi】.

Sami made a mistake.

[[Turkish#^tr-Q0483-answer|Compare the answer]]
^tr-Q0483

**tr-Q0484 · Build the sentence**

Arrange: hata / Sami / bir / yaptı.

Sami made a mistake.

[[Turkish#^tr-Q0484-answer|Compare the answer]]
^tr-Q0484

**tr-Q0485 · Write a translation**

Write this in Turkish: Tom has already bought everything he needs to buy.

[[Turkish#^tr-Q0485-answer|Compare the answer]]
^tr-Q0485

**tr-Q0486 · Explain the grammar**

Tom zaten satın alması gereken her şeyi satın 【aldı】.

Tom has already bought everything he needs to buy.

[[Turkish#^tr-Q0486-answer|Compare the answer]]
^tr-Q0486

**tr-Q0487 · Fill the gap**

Aniden kaza ____.

The accident happened all of a sudden.

[[Turkish#^tr-Q0487-answer|Compare the answer]]
^tr-Q0487

**tr-Q0488 · Choose the form**

Aniden kaza ____.

The accident happened all of a sudden.

Choices: yaptı / oldu / geldi / gitti

[[Turkish#^tr-Q0488-answer|Compare the answer]]
^tr-Q0488

**tr-Q0489 · Edit the changed sentence**

Boston'a bir gezi 【geldi】.

I took a trip to Boston.

[[Turkish#^tr-Q0489-answer|Compare the answer]]
^tr-Q0489

**tr-Q0490 · Build the sentence**

Arrange: yaptım. / bir / gezi / Boston'a

I took a trip to Boston.

[[Turkish#^tr-Q0490-answer|Compare the answer]]
^tr-Q0490

**tr-Q0491 · Write a translation**

Write this in Turkish: Who did Tom go to Boston with?

[[Turkish#^tr-Q0491-answer|Compare the answer]]
^tr-Q0491

**tr-Q0492 · Explain the grammar**

Tom Boston'a kimle 【gitti】?

Who did Tom go to Boston with?

[[Turkish#^tr-Q0492-answer|Compare the answer]]
^tr-Q0492

**tr-Q0493 · Fill the gap**

Üçüncü yıldız belirli bir krala ait ____.

The third star belonged to a certain king.

[[Turkish#^tr-Q0493-answer|Compare the answer]]
^tr-Q0493

**tr-Q0494 · Choose the form**

Üçüncü yıldız belirli bir krala ait ____.

The third star belonged to a certain king.

Choices: yaptı / geldi / gitti / oldu

[[Turkish#^tr-Q0494-answer|Compare the answer]]
^tr-Q0494

**tr-Q0495 · Edit the changed sentence**

Tom gerçekten 【geldi】 mi?

Did Tom really leave?

[[Turkish#^tr-Q0495-answer|Compare the answer]]
^tr-Q0495

**tr-Q0496 · Build the sentence**

Arrange: Tom / mi? / gerçekten / gitti

Did Tom really leave?

[[Turkish#^tr-Q0496-answer|Compare the answer]]
^tr-Q0496

**tr-Q0497 · Write a translation**

Write this in Turkish: The teacher particularly emphasized that point.

[[Turkish#^tr-Q0497-answer|Compare the answer]]
^tr-Q0497

**tr-Q0498 · Explain the grammar**

Öğretmen özellikle o noktaya vurgu 【yaptı】.

The teacher particularly emphasized that point.

[[Turkish#^tr-Q0498-answer|Compare the answer]]
^tr-Q0498

**tr-Q0499 · Fill the gap**

Sami ölümünden 24 saat önce Leyla'yla seks ____.

Sami had sex with Layla 24 hours before her death.

[[Turkish#^tr-Q0499-answer|Compare the answer]]
^tr-Q0499

**tr-Q0500 · Choose the form**

Sami ölümünden 24 saat önce Leyla'yla seks ____.

Sami had sex with Layla 24 hours before her death.

Choices: yaptı / geldi / dedi / gitti

[[Turkish#^tr-Q0500-answer|Compare the answer]]
^tr-Q0500


### Reported/evidential forms · 50 questions

**tr-Q0501 · Edit the changed sentence**

Yağmur 【gelmiş】 olsaydı gitmezdik.

We wouldn't have gone if it had rained.

[[Turkish#^tr-Q0501-answer|Compare the answer]]
^tr-Q0501

**tr-Q0502 · Build the sentence**

Arrange: gitmezdik. / olsaydı / yağmış / Yağmur

We wouldn't have gone if it had rained.

[[Turkish#^tr-Q0502-answer|Compare the answer]]
^tr-Q0502

**tr-Q0503 · Write a translation**

Write this in Turkish: You're probably the only person in Boston who has never been to this park before.

[[Turkish#^tr-Q0503-answer|Compare the answer]]
^tr-Q0503

**tr-Q0504 · Explain the grammar**

Sen muhtemelen daha önce bu parka hiç 【gelmemiş】 Boston'daki tek kişisin.

You're probably the only person in Boston who has never been to this park before.

[[Turkish#^tr-Q0504-answer|Compare the answer]]
^tr-Q0504

**tr-Q0505 · Fill the gap**

Büyükanne bütün aileyi buz ____ bırakarak öldü.

Grandmother died, leaving the whole family stunned.

[[Turkish#^tr-Q0505-answer|Compare the answer]]
^tr-Q0505

**tr-Q0506 · Choose the form**

Büyükanne bütün aileyi buz ____ bırakarak öldü.

Grandmother died, leaving the whole family stunned.

Choices: yapmış / gelmiş / gitmiş / kesilmiş

[[Turkish#^tr-Q0506-answer|Compare the answer]]
^tr-Q0506

**tr-Q0507 · Edit the changed sentence**

Tom beni 【gelmiş】 gibiydi.

Tom seemed to have recognized me.

[[Turkish#^tr-Q0507-answer|Compare the answer]]
^tr-Q0507

**tr-Q0508 · Build the sentence**

Arrange: gibiydi. / tanımış / beni / Tom

Tom seemed to have recognized me.

[[Turkish#^tr-Q0508-answer|Compare the answer]]
^tr-Q0508

**tr-Q0509 · Write a translation**

Write this in Turkish: Raised hands have become a symbol of protest.

[[Turkish#^tr-Q0509-answer|Compare the answer]]
^tr-Q0509

**tr-Q0510 · Explain the grammar**

【Kaldırılmış】 eller bir protesto sembolü haline gelmiştir.

Raised hands have become a symbol of protest.

[[Turkish#^tr-Q0510-answer|Compare the answer]]
^tr-Q0510

**tr-Q0511 · Fill the gap**

Tom o yatırımı ____ olsaydı, bugün bir milyarder olurdu.

If Tom had made that investment, he'd be a billionaire today.

[[Turkish#^tr-Q0511-answer|Compare the answer]]
^tr-Q0511

**tr-Q0512 · Choose the form**

Tom o yatırımı ____ olsaydı, bugün bir milyarder olurdu.

If Tom had made that investment, he'd be a billionaire today.

Choices: gitmiş / gelmiş / yapmış

[[Turkish#^tr-Q0512-answer|Compare the answer]]
^tr-Q0512

**tr-Q0513 · Edit the changed sentence**

Ne kadar süredir 【gelmiş】 olacağını düşünüyorsun?

How long do you think you'll be gone?

[[Turkish#^tr-Q0513-answer|Compare the answer]]
^tr-Q0513

**tr-Q0514 · Build the sentence**

Arrange: gitmiş / düşünüyorsun? / kadar / süredir / Ne / olacağını

How long do you think you'll be gone?

[[Turkish#^tr-Q0514-answer|Compare the answer]]
^tr-Q0514

**tr-Q0515 · Write a translation**

Write this in Turkish: Tom said Mary wasn't discouraged.

[[Turkish#^tr-Q0515-answer|Compare the answer]]
^tr-Q0515

**tr-Q0516 · Explain the grammar**

Tom Mary'nin cesareti 【kırılmış】 olmadığını söyledi.

Tom said Mary wasn't discouraged.

[[Turkish#^tr-Q0516-answer|Compare the answer]]
^tr-Q0516

**tr-Q0517 · Fill the gap**

Sanki ____ gibi görünüyordunuz.

It looked like you were surprised.

[[Turkish#^tr-Q0517-answer|Compare the answer]]
^tr-Q0517

**tr-Q0518 · Choose the form**

Sanki ____ gibi görünüyordunuz.

It looked like you were surprised.

Choices: gitmiş / gelmiş / yapmış / şaşırmış

[[Turkish#^tr-Q0518-answer|Compare the answer]]
^tr-Q0518

**tr-Q0519 · Edit the changed sentence**

Tom, adını kara tahtaya 【gelmiş】 gördü.

Tom saw his name written on the blackboard.

[[Turkish#^tr-Q0519-answer|Compare the answer]]
^tr-Q0519

**tr-Q0520 · Build the sentence**

Arrange: adını / Tom, / gördü. / tahtaya / kara / yazılmış

Tom saw his name written on the blackboard.

[[Turkish#^tr-Q0520-answer|Compare the answer]]
^tr-Q0520

**tr-Q0521 · Write a translation**

Write this in Turkish: She seemed disappointed and sad.

[[Turkish#^tr-Q0521-answer|Compare the answer]]
^tr-Q0521

**tr-Q0522 · Explain the grammar**

O hayal kırıklığına 【uğramış】 ve üzgün görünüyordu.

She seemed disappointed and sad.

[[Turkish#^tr-Q0522-answer|Compare the answer]]
^tr-Q0522

**tr-Q0523 · Fill the gap**

Raporunuz toplantı için zamanında ____ olacak mı?

Will your report be finished in time for the meeting?

[[Turkish#^tr-Q0523-answer|Compare the answer]]
^tr-Q0523

**tr-Q0524 · Choose the form**

Raporunuz toplantı için zamanında ____ olacak mı?

Will your report be finished in time for the meeting?

Choices: gelmiş / gitmiş / bitmiş / yapmış

[[Turkish#^tr-Q0524-answer|Compare the answer]]
^tr-Q0524

**tr-Q0525 · Edit the changed sentence**

Birisi şemsiyeni yanlışlıkla 【gelmiş】 olmalı.

Somebody must've taken your umbrella by mistake.

[[Turkish#^tr-Q0525-answer|Compare the answer]]
^tr-Q0525

**tr-Q0526 · Build the sentence**

Arrange: şemsiyeni / yanlışlıkla / Birisi / olmalı. / almış

Somebody must've taken your umbrella by mistake.

[[Turkish#^tr-Q0526-answer|Compare the answer]]
^tr-Q0526

**tr-Q0527 · Write a translation**

Write this in Turkish: It is easier to catch an escaped horse than to take back an escaped word.

[[Turkish#^tr-Q0527-answer|Compare the answer]]
^tr-Q0527

**tr-Q0528 · Explain the grammar**

【Kaçmış】 bir atı yakalamak söylenmiş bir sözü geri almaktan daha kolaydır.

It is easier to catch an escaped horse than to take back an escaped word.

[[Turkish#^tr-Q0528-answer|Compare the answer]]
^tr-Q0528

**tr-Q0529 · Fill the gap**

Tom bile ____ görünüyordu.

Even Tom looked surprised.

[[Turkish#^tr-Q0529-answer|Compare the answer]]
^tr-Q0529

**tr-Q0530 · Choose the form**

Tom bile ____ görünüyordu.

Even Tom looked surprised.

Choices: gelmiş / şaşırmış / yapmış / gitmiş

[[Turkish#^tr-Q0530-answer|Compare the answer]]
^tr-Q0530

**tr-Q0531 · Edit the changed sentence**

Doğruyu söylemek gerekirse, o hala 【gelmiş】 yaşın altındadır.

To tell the truth, he is still under sixty.

[[Turkish#^tr-Q0531-answer|Compare the answer]]
^tr-Q0531

**tr-Q0532 · Build the sentence**

Arrange: o / altındadır. / altmış / Doğruyu / hala / yaşın / gerekirse, / söylemek

To tell the truth, he is still under sixty.

[[Turkish#^tr-Q0532-answer|Compare the answer]]
^tr-Q0532

**tr-Q0533 · Write a translation**

Write this in Turkish: He sent me a present.

[[Turkish#^tr-Q0533-answer|Compare the answer]]
^tr-Q0533

**tr-Q0534 · Explain the grammar**

Bana bir hediye 【göndermiş】.

He sent me a present.

[[Turkish#^tr-Q0534-answer|Compare the answer]]
^tr-Q0534

**tr-Q0535 · Fill the gap**

Kendimi tamamen ____ hissediyordum.

I felt utterly overwhelmed.

[[Turkish#^tr-Q0535-answer|Compare the answer]]
^tr-Q0535

**tr-Q0536 · Choose the form**

Kendimi tamamen ____ hissediyordum.

I felt utterly overwhelmed.

Choices: gitmiş / yapmış / bunalmış / gelmiş

[[Turkish#^tr-Q0536-answer|Compare the answer]]
^tr-Q0536

**tr-Q0537 · Edit the changed sentence**

Tom'un bize yardım 【gelmiş】 olabileceğini düşünüyor musun?

Do you think Tom would've helped us?

[[Turkish#^tr-Q0537-answer|Compare the answer]]
^tr-Q0537

**tr-Q0538 · Build the sentence**

Arrange: etmiş / musun? / düşünüyor / Tom'un / bize / olabileceğini / yardım

Do you think Tom would've helped us?

[[Turkish#^tr-Q0538-answer|Compare the answer]]
^tr-Q0538

**tr-Q0539 · Write a translation**

Write this in Turkish: Whoever said money can't buy happiness simply didn't know where to go shopping.

[[Turkish#^tr-Q0539-answer|Compare the answer]]
^tr-Q0539

**tr-Q0540 · Explain the grammar**

Paranın mutluluğu satın alamayacağını söyleyen her kimse, nereden alışveriş yapacağını 【bilmiyormuş】.

Whoever said money can't buy happiness simply didn't know where to go shopping.

[[Turkish#^tr-Q0540-answer|Compare the answer]]
^tr-Q0540

**tr-Q0541 · Fill the gap**

Mary, Tom'un ____ olduklarından çok rencide oldu.

Mary was highly offended by what Tom had said.

[[Turkish#^tr-Q0541-answer|Compare the answer]]
^tr-Q0541

**tr-Q0542 · Choose the form**

Mary, Tom'un ____ olduklarından çok rencide oldu.

Mary was highly offended by what Tom had said.

Choices: gitmiş / söylemiş / yapmış / gelmiş

[[Turkish#^tr-Q0542-answer|Compare the answer]]
^tr-Q0542

**tr-Q0543 · Edit the changed sentence**

Tom, Mary'nin yalnızca bir kez onunla birlikte kano 【gelmiş】 olduğunu söyledi.

Tom said Mary has only gone canoeing with him once.

[[Turkish#^tr-Q0543-answer|Compare the answer]]
^tr-Q0543

**tr-Q0544 · Build the sentence**

Arrange: yalnızca / kez / onunla / kano / Tom, / Mary'nin / bir / birlikte / olduğunu / söyledi. / yapmış

Tom said Mary has only gone canoeing with him once.

[[Turkish#^tr-Q0544-answer|Compare the answer]]
^tr-Q0544

**tr-Q0545 · Write a translation**

Write this in Turkish: Tom wasn't very dedicated.

[[Turkish#^tr-Q0545-answer|Compare the answer]]
^tr-Q0545

**tr-Q0546 · Explain the grammar**

Tom çok 【adanmış】 değildi.

Tom wasn't very dedicated.

[[Turkish#^tr-Q0546-answer|Compare the answer]]
^tr-Q0546

**tr-Q0547 · Fill the gap**

Bay Tanaka bize yeni ____ çocuğunun bir sürü resmini gösterdi.

Mr. Tanaka showed us many pictures of his newborn baby.

[[Turkish#^tr-Q0547-answer|Compare the answer]]
^tr-Q0547

**tr-Q0548 · Choose the form**

Bay Tanaka bize yeni ____ çocuğunun bir sürü resmini gösterdi.

Mr. Tanaka showed us many pictures of his newborn baby.

Choices: yapmış / doğmuş / gitmiş / gelmiş

[[Turkish#^tr-Q0548-answer|Compare the answer]]
^tr-Q0548

**tr-Q0549 · Edit the changed sentence**

Ben 【gelmiş】 bir insanım.

I'm a changed man.

[[Turkish#^tr-Q0549-answer|Compare the answer]]
^tr-Q0549

**tr-Q0550 · Build the sentence**

Arrange: Ben / insanım. / bir / değişmiş

I'm a changed man.

[[Turkish#^tr-Q0550-answer|Compare the answer]]
^tr-Q0550


### Future forms · 50 questions

**tr-Q0551 · Write a translation**

Write this in Turkish: Her mother will continue to work.

[[Turkish#^tr-Q0551-answer|Compare the answer]]
^tr-Q0551

**tr-Q0552 · Explain the grammar**

Annesi çalışmaya devam 【edecek】.

Her mother will continue to work.

[[Turkish#^tr-Q0552-answer|Compare the answer]]
^tr-Q0552

**tr-Q0553 · Fill the gap**

Tom asla gitmene izin ____.

Tom will never allow you to go.

[[Turkish#^tr-Q0553-answer|Compare the answer]]
^tr-Q0553

**tr-Q0554 · Choose the form**

Tom asla gitmene izin ____.

Tom will never allow you to go.

Choices: gelecek / yapacak / vermeyecek / gidecek

[[Turkish#^tr-Q0554-answer|Compare the answer]]
^tr-Q0554

**tr-Q0555 · Edit the changed sentence**

Boston'a nasıl 【gelecek】?

How will you go to Boston?

[[Turkish#^tr-Q0555-answer|Compare the answer]]
^tr-Q0555

**tr-Q0556 · Build the sentence**

Arrange: nasıl / gideceksin? / Boston'a

How will you go to Boston?

[[Turkish#^tr-Q0556-answer|Compare the answer]]
^tr-Q0556

**tr-Q0557 · Write a translation**

Write this in Turkish: I guess I'd better change into something warmer.

[[Turkish#^tr-Q0557-answer|Compare the answer]]
^tr-Q0557

**tr-Q0558 · Explain the grammar**

Sanırım daha kalın bir şey giysem iyi 【olacak】.

I guess I'd better change into something warmer.

[[Turkish#^tr-Q0558-answer|Compare the answer]]
^tr-Q0558

**tr-Q0559 · Fill the gap**

Şimdi Tom'u ____.

I'm going to look for Tom now.

[[Turkish#^tr-Q0559-answer|Compare the answer]]
^tr-Q0559

**tr-Q0560 · Choose the form**

Şimdi Tom'u ____.

I'm going to look for Tom now.

Choices: gidecek / arayacağım / gelecek / yapacak

[[Turkish#^tr-Q0560-answer|Compare the answer]]
^tr-Q0560

**tr-Q0561 · Edit the changed sentence**

Tom aptalca bir şey 【gelecek】.

Tom won't do anything crazy.

[[Turkish#^tr-Q0561-answer|Compare the answer]]
^tr-Q0561

**tr-Q0562 · Build the sentence**

Arrange: aptalca / Tom / şey / yapmayacak. / bir

Tom won't do anything crazy.

[[Turkish#^tr-Q0562-answer|Compare the answer]]
^tr-Q0562

**tr-Q0563 · Write a translation**

Write this in Turkish: I'll be with you right away.

[[Turkish#^tr-Q0563-answer|Compare the answer]]
^tr-Q0563

**tr-Q0564 · Explain the grammar**

Ben hemen seninle 【olacağım】.

I'll be with you right away.

[[Turkish#^tr-Q0564-answer|Compare the answer]]
^tr-Q0564

**tr-Q0565 · Fill the gap**

Tom bu öğleden sonra ____.

Tom will come this afternoon.

[[Turkish#^tr-Q0565-answer|Compare the answer]]
^tr-Q0565

**tr-Q0566 · Choose the form**

Tom bu öğleden sonra ____.

Tom will come this afternoon.

Choices: gidecek / gelecek / yapacak

[[Turkish#^tr-Q0566-answer|Compare the answer]]
^tr-Q0566

**tr-Q0567 · Edit the changed sentence**

【gidecek】 sene Çince öğrenmek istiyorum.

I want to learn Chinese next year.

[[Turkish#^tr-Q0567-answer|Compare the answer]]
^tr-Q0567

**tr-Q0568 · Build the sentence**

Arrange: istiyorum. / Çince / Gelecek / öğrenmek / sene

I want to learn Chinese next year.

[[Turkish#^tr-Q0568-answer|Compare the answer]]
^tr-Q0568

**tr-Q0569 · Write a translation**

Write this in Turkish: Tom won't take a vacation this year.

[[Turkish#^tr-Q0569-answer|Compare the answer]]
^tr-Q0569

**tr-Q0570 · Explain the grammar**

Tom bu yıl tatil 【yapmayacak】.

Tom won't take a vacation this year.

[[Turkish#^tr-Q0570-answer|Compare the answer]]
^tr-Q0570

**tr-Q0571 · Fill the gap**

"____ sene nereye gidiyoruz?" "Fransa'ya."

"Where are we going next year?" "To France."

[[Turkish#^tr-Q0571-answer|Compare the answer]]
^tr-Q0571

**tr-Q0572 · Choose the form**

"____ sene nereye gidiyoruz?" "Fransa'ya."

"Where are we going next year?" "To France."

Choices: Gelecek / gidecek / yapacak

[[Turkish#^tr-Q0572-answer|Compare the answer]]
^tr-Q0572

**tr-Q0573 · Edit the changed sentence**

Tom 【gelecek】 çok önemli bir şeyi olduğunu söyledi.

Tom said he had something very important to say.

[[Turkish#^tr-Q0573-answer|Compare the answer]]
^tr-Q0573

**tr-Q0574 · Build the sentence**

Arrange: söyleyecek / çok / bir / olduğunu / önemli / şeyi / Tom / söyledi.

Tom said he had something very important to say.

[[Turkish#^tr-Q0574-answer|Compare the answer]]
^tr-Q0574

**tr-Q0575 · Write a translation**

Write this in Turkish: Tom is prepared for anything that may happen.

[[Turkish#^tr-Q0575-answer|Compare the answer]]
^tr-Q0575

**tr-Q0576 · Explain the grammar**

Tom 【olabilecek】 herhangi bir şey için hazır.

Tom is prepared for anything that may happen.

[[Turkish#^tr-Q0576-answer|Compare the answer]]
^tr-Q0576

**tr-Q0577 · Fill the gap**

Terbiyeni nasıl takınacağın konusunda dikkatli olmak zorunda ____.

You'll have to be careful how you behave yourself.

[[Turkish#^tr-Q0577-answer|Compare the answer]]
^tr-Q0577

**tr-Q0578 · Choose the form**

Terbiyeni nasıl takınacağın konusunda dikkatli olmak zorunda ____.

You'll have to be careful how you behave yourself.

Choices: olacaksın / yapacak / gelecek / gidecek

[[Turkish#^tr-Q0578-answer|Compare the answer]]
^tr-Q0578

**tr-Q0579 · Edit the changed sentence**

Ne zaman iyi bir oyun 【gelecek】?

When will I write a good play?

[[Turkish#^tr-Q0579-answer|Compare the answer]]
^tr-Q0579

**tr-Q0580 · Build the sentence**

Arrange: yazacağım? / iyi / zaman / Ne / oyun / bir

When will I write a good play?

[[Turkish#^tr-Q0580-answer|Compare the answer]]
^tr-Q0580

**tr-Q0581 · Write a translation**

Write this in Turkish: I'm going to teach one of Tom's advanced classes while he's in Boston.

[[Turkish#^tr-Q0581-answer|Compare the answer]]
^tr-Q0581

**tr-Q0582 · Explain the grammar**

O, Boston'dayken Tom'un ileri sınıflarından birine öğretmenlik 【yapacağım】.

I'm going to teach one of Tom's advanced classes while he's in Boston.

[[Turkish#^tr-Q0582-answer|Compare the answer]]
^tr-Q0582

**tr-Q0583 · Fill the gap**

Kısa bir süre burada ____.

I will stay here for a short period.

[[Turkish#^tr-Q0583-answer|Compare the answer]]
^tr-Q0583

**tr-Q0584 · Choose the form**

Kısa bir süre burada ____.

I will stay here for a short period.

Choices: gelecek / kalacağım / gidecek / yapacak

[[Turkish#^tr-Q0584-answer|Compare the answer]]
^tr-Q0584

**tr-Q0585 · Edit the changed sentence**

Tom bunun neden olduğunu 【gelecek】.

Tom will explain why that happened.

[[Turkish#^tr-Q0585-answer|Compare the answer]]
^tr-Q0585

**tr-Q0586 · Build the sentence**

Arrange: açıklayacak. / olduğunu / neden / bunun / Tom

Tom will explain why that happened.

[[Turkish#^tr-Q0586-answer|Compare the answer]]
^tr-Q0586

**tr-Q0587 · Write a translation**

Write this in Turkish: Tom won't leave tomorrow.

[[Turkish#^tr-Q0587-answer|Compare the answer]]
^tr-Q0587

**tr-Q0588 · Explain the grammar**

Tom yarın 【ayrılmayacak】.

Tom won't leave tomorrow.

[[Turkish#^tr-Q0588-answer|Compare the answer]]
^tr-Q0588

**tr-Q0589 · Fill the gap**

Ben akşam yemeğini ____.

I'll pay for dinner.

[[Turkish#^tr-Q0589-answer|Compare the answer]]
^tr-Q0589

**tr-Q0590 · Choose the form**

Ben akşam yemeğini ____.

I'll pay for dinner.

Choices: gidecek / yapacak / ödeyeceğim / gelecek

[[Turkish#^tr-Q0590-answer|Compare the answer]]
^tr-Q0590

**tr-Q0591 · Edit the changed sentence**

Bu gece eğlenceli 【gelecek】.

Tonight's going to be fun.

[[Turkish#^tr-Q0591-answer|Compare the answer]]
^tr-Q0591

**tr-Q0592 · Build the sentence**

Arrange: olacak. / eğlenceli / gece / Bu

Tonight's going to be fun.

[[Turkish#^tr-Q0592-answer|Compare the answer]]
^tr-Q0592

**tr-Q0593 · Write a translation**

Write this in Turkish: Tom is never going to admit that he was wrong.

[[Turkish#^tr-Q0593-answer|Compare the answer]]
^tr-Q0593

**tr-Q0594 · Explain the grammar**

Tom hatalı olduğunu asla itiraf 【etmeyecek】.

Tom is never going to admit that he was wrong.

[[Turkish#^tr-Q0594-answer|Compare the answer]]
^tr-Q0594

**tr-Q0595 · Fill the gap**

Ben şimdi televizyondaki haberleri ____.

I'll now watch the news on TV.

[[Turkish#^tr-Q0595-answer|Compare the answer]]
^tr-Q0595

**tr-Q0596 · Choose the form**

Ben şimdi televizyondaki haberleri ____.

I'll now watch the news on TV.

Choices: izleyeceğim / gelecek / yapacak / gidecek

[[Turkish#^tr-Q0596-answer|Compare the answer]]
^tr-Q0596

**tr-Q0597 · Edit the changed sentence**

Sanırım bunu bu hafta kese kağıdına 【gelecek】.

I think I'll brown bag it this week.

[[Turkish#^tr-Q0597-answer|Compare the answer]]
^tr-Q0597

**tr-Q0598 · Build the sentence**

Arrange: kağıdına / bunu / Sanırım / kese / bu / hafta / koyacağım.

I think I'll brown bag it this week.

[[Turkish#^tr-Q0598-answer|Compare the answer]]
^tr-Q0598

**tr-Q0599 · Write a translation**

Write this in Turkish: We all anticipate seeing you next weekend.

[[Turkish#^tr-Q0599-answer|Compare the answer]]
^tr-Q0599

**tr-Q0600 · Explain the grammar**

Hepimiz 【gelecek】 hafta seni görmeyi umuyoruz.

We all anticipate seeing you next weekend.

[[Turkish#^tr-Q0600-answer|Compare the answer]]
^tr-Q0600


### Negation and absence · 50 questions

**tr-Q0601 · Fill the gap**

Tom çok ağzı sıkı ____.

Tom isn't very secretive.

[[Turkish#^tr-Q0601-answer|Compare the answer]]
^tr-Q0601

**tr-Q0602 · Choose the form**

Tom çok ağzı sıkı ____.

Tom isn't very secretive.

Choices: değil / yok / hayır

[[Turkish#^tr-Q0602-answer|Compare the answer]]
^tr-Q0602

**tr-Q0603 · Edit the changed sentence**

Tüm nedenimizi izlemek için yeterli gücümüz 【değil】.

We do not have enough strength to follow our reason completely.

[[Turkish#^tr-Q0603-answer|Compare the answer]]
^tr-Q0603

**tr-Q0604 · Build the sentence**

Arrange: Tüm / yok. / izlemek / için / gücümüz / yeterli / nedenimizi

We do not have enough strength to follow our reason completely.

[[Turkish#^tr-Q0604-answer|Compare the answer]]
^tr-Q0604

**tr-Q0605 · Write a translation**

Write this in Turkish: Tom's good, but not good enough.

[[Turkish#^tr-Q0605-answer|Compare the answer]]
^tr-Q0605

**tr-Q0606 · Explain the grammar**

Tom iyi ama yeterince iyi 【değil】.

Tom's good, but not good enough.

[[Turkish#^tr-Q0606-answer|Compare the answer]]
^tr-Q0606

**tr-Q0607 · Fill the gap**

Yardıma ihtiyacınız ____ mu?

Don't you need help?

[[Turkish#^tr-Q0607-answer|Compare the answer]]
^tr-Q0607

**tr-Q0608 · Choose the form**

Yardıma ihtiyacınız ____ mu?

Don't you need help?

Choices: değil / hayır / yok

[[Turkish#^tr-Q0608-answer|Compare the answer]]
^tr-Q0608

**tr-Q0609 · Edit the changed sentence**

Neredeyse 【değil】 et yemem.

I almost never eat meat.

[[Turkish#^tr-Q0609-answer|Compare the answer]]
^tr-Q0609

**tr-Q0610 · Build the sentence**

Arrange: et / yemem. / Neredeyse / hiç

I almost never eat meat.

[[Turkish#^tr-Q0610-answer|Compare the answer]]
^tr-Q0610

**tr-Q0611 · Write a translation**

Write this in Turkish: You returned the shirt because it was too small, isn't it?

[[Turkish#^tr-Q0611-answer|Compare the answer]]
^tr-Q0611

**tr-Q0612 · Explain the grammar**

Çok küçük olduğu için gömleği iade ettin, 【değil】 mi?

You returned the shirt because it was too small, isn't it?

[[Turkish#^tr-Q0612-answer|Compare the answer]]
^tr-Q0612

**tr-Q0613 · Fill the gap**

Öyle yapmamak için ____ bir nedenim yok.

I have no reason not to do so.

[[Turkish#^tr-Q0613-answer|Compare the answer]]
^tr-Q0613

**tr-Q0614 · Choose the form**

Öyle yapmamak için ____ bir nedenim yok.

I have no reason not to do so.

Choices: değil / hiç / yok / hayır

[[Turkish#^tr-Q0614-answer|Compare the answer]]
^tr-Q0614

**tr-Q0615 · Edit the changed sentence**

Tom da bir öğretmen, 【yok】 mi?

Tom is a teacher, too, isn't he?

[[Turkish#^tr-Q0615-answer|Compare the answer]]
^tr-Q0615

**tr-Q0616 · Build the sentence**

Arrange: mi? / değil / da / bir / öğretmen, / Tom

Tom is a teacher, too, isn't he?

[[Turkish#^tr-Q0616-answer|Compare the answer]]
^tr-Q0616

**tr-Q0617 · Write a translation**

Write this in Turkish: We never use sugar.

[[Turkish#^tr-Q0617-answer|Compare the answer]]
^tr-Q0617

**tr-Q0618 · Explain the grammar**

【Asla】 şeker kullanmayız.

We never use sugar.

[[Turkish#^tr-Q0618-answer|Compare the answer]]
^tr-Q0618

**tr-Q0619 · Fill the gap**

Sen ____ böyle bir şey yapmazsın.

You would never do such a thing.

[[Turkish#^tr-Q0619-answer|Compare the answer]]
^tr-Q0619

**tr-Q0620 · Choose the form**

Sen ____ böyle bir şey yapmazsın.

You would never do such a thing.

Choices: yok / hayır / değil / asla

[[Turkish#^tr-Q0620-answer|Compare the answer]]
^tr-Q0620

**tr-Q0621 · Edit the changed sentence**

O satılık 【yok】.

It's not for sale.

[[Turkish#^tr-Q0621-answer|Compare the answer]]
^tr-Q0621

**tr-Q0622 · Build the sentence**

Arrange: satılık / değil. / O

It's not for sale.

[[Turkish#^tr-Q0622-answer|Compare the answer]]
^tr-Q0622

**tr-Q0623 · Write a translation**

Write this in Turkish: I've never had a boyfriend.

[[Turkish#^tr-Q0623-answer|Compare the answer]]
^tr-Q0623

**tr-Q0624 · Explain the grammar**

【Hiç】 erkek arkadaşım olmadı.

I've never had a boyfriend.

[[Turkish#^tr-Q0624-answer|Compare the answer]]
^tr-Q0624

**tr-Q0625 · Fill the gap**

Şimdiye kadar ____ bir ateş böceği gördün mü?

Have you ever even seen a firefly?

[[Turkish#^tr-Q0625-answer|Compare the answer]]
^tr-Q0625

**tr-Q0626 · Choose the form**

Şimdiye kadar ____ bir ateş böceği gördün mü?

Have you ever even seen a firefly?

Choices: hiç / hayır / yok / değil

[[Turkish#^tr-Q0626-answer|Compare the answer]]
^tr-Q0626

**tr-Q0627 · Edit the changed sentence**

Bu kitap sadece ilginç 【yok】, aynı zamanda öğreticidir.

This book is not only interesting but also instructive.

[[Turkish#^tr-Q0627-answer|Compare the answer]]
^tr-Q0627

**tr-Q0628 · Build the sentence**

Arrange: aynı / öğreticidir. / kitap / değil, / sadece / Bu / ilginç / zamanda

This book is not only interesting but also instructive.

[[Turkish#^tr-Q0628-answer|Compare the answer]]
^tr-Q0628

**tr-Q0629 · Write a translation**

Write this in Turkish: We haven't had any problems with them at all.

[[Turkish#^tr-Q0629-answer|Compare the answer]]
^tr-Q0629

**tr-Q0630 · Explain the grammar**

Onlarla 【hiç】 herhangi bir sorun yaşamadık.

We haven't had any problems with them at all.

[[Turkish#^tr-Q0630-answer|Compare the answer]]
^tr-Q0630

**tr-Q0631 · Fill the gap**

Bir forklifti nasıl çalıştıracağını bilmiyorsun, ____ mi?

You don't know how to operate a forklift, do you?

[[Turkish#^tr-Q0631-answer|Compare the answer]]
^tr-Q0631

**tr-Q0632 · Choose the form**

Bir forklifti nasıl çalıştıracağını bilmiyorsun, ____ mi?

You don't know how to operate a forklift, do you?

Choices: değil / hayır / yok

[[Turkish#^tr-Q0632-answer|Compare the answer]]
^tr-Q0632

**tr-Q0633 · Edit the changed sentence**

Onlardan 【değil】 biri konuşmadı.

None of them spoke.

[[Turkish#^tr-Q0633-answer|Compare the answer]]
^tr-Q0633

**tr-Q0634 · Build the sentence**

Arrange: Onlardan / hiç / konuşmadı. / biri

None of them spoke.

[[Turkish#^tr-Q0634-answer|Compare the answer]]
^tr-Q0634

**tr-Q0635 · Write a translation**

Write this in Turkish: No one complains.

[[Turkish#^tr-Q0635-answer|Compare the answer]]
^tr-Q0635

**tr-Q0636 · Explain the grammar**

【Hiç】 kimse şikayet etmiyor.

No one complains.

[[Turkish#^tr-Q0636-answer|Compare the answer]]
^tr-Q0636

**tr-Q0637 · Fill the gap**

Ondan yardım istemenin hiçbir faydası ____.

There is no use in asking him for assistance.

[[Turkish#^tr-Q0637-answer|Compare the answer]]
^tr-Q0637

**tr-Q0638 · Choose the form**

Ondan yardım istemenin hiçbir faydası ____.

There is no use in asking him for assistance.

Choices: değil / yok / hayır

[[Turkish#^tr-Q0638-answer|Compare the answer]]
^tr-Q0638

**tr-Q0639 · Edit the changed sentence**

Artık daha fazla zamanın 【değil】.

You don't have any more time.

[[Turkish#^tr-Q0639-answer|Compare the answer]]
^tr-Q0639

**tr-Q0640 · Build the sentence**

Arrange: Artık / yok. / zamanın / daha / fazla

You don't have any more time.

[[Turkish#^tr-Q0640-answer|Compare the answer]]
^tr-Q0640

**tr-Q0641 · Write a translation**

Write this in Turkish: Tom is stubborn, isn't he?

[[Turkish#^tr-Q0641-answer|Compare the answer]]
^tr-Q0641

**tr-Q0642 · Explain the grammar**

Tom inatçı, 【değil】 mi?

Tom is stubborn, isn't he?

[[Turkish#^tr-Q0642-answer|Compare the answer]]
^tr-Q0642

**tr-Q0643 · Fill the gap**

Onu satın aldın, ____ mi?

You bought it, didn't you?

[[Turkish#^tr-Q0643-answer|Compare the answer]]
^tr-Q0643

**tr-Q0644 · Choose the form**

Onu satın aldın, ____ mi?

You bought it, didn't you?

Choices: değil / hayır / yok

[[Turkish#^tr-Q0644-answer|Compare the answer]]
^tr-Q0644

**tr-Q0645 · Edit the changed sentence**

Tom Fransızcada Mary kadar iyi 【yok】.

Tom isn't as good at French as Mary is.

[[Turkish#^tr-Q0645-answer|Compare the answer]]
^tr-Q0645

**tr-Q0646 · Build the sentence**

Arrange: Fransızcada / iyi / Mary / kadar / değil. / Tom

Tom isn't as good at French as Mary is.

[[Turkish#^tr-Q0646-answer|Compare the answer]]
^tr-Q0646

**tr-Q0647 · Write a translation**

Write this in Turkish: It's no use trying to persuade the boy.

[[Turkish#^tr-Q0647-answer|Compare the answer]]
^tr-Q0647

**tr-Q0648 · Explain the grammar**

Çocuğu ikna etmeye çalışmanın faydası 【yok】.

It's no use trying to persuade the boy.

[[Turkish#^tr-Q0648-answer|Compare the answer]]
^tr-Q0648

**tr-Q0649 · Fill the gap**

Tom'un bunu yapmasına izin vermek kötü bir fikir ____.

It's not a bad idea to let Tom do that.

[[Turkish#^tr-Q0649-answer|Compare the answer]]
^tr-Q0649

**tr-Q0650 · Choose the form**

Tom'un bunu yapmasına izin vermek kötü bir fikir ____.

It's not a bad idea to let Tom do that.

Choices: yok / değil / hayır

[[Turkish#^tr-Q0650-answer|Compare the answer]]
^tr-Q0650


### Question particle · 50 questions

**tr-Q0651 · Edit the changed sentence**

Kabak çorbasını sever 【mı】?

Do you like squash soup?

[[Turkish#^tr-Q0651-answer|Compare the answer]]
^tr-Q0651

**tr-Q0652 · Build the sentence**

Arrange: misin? / sever / çorbasını / Kabak

Do you like squash soup?

[[Turkish#^tr-Q0652-answer|Compare the answer]]
^tr-Q0652

**tr-Q0653 · Write a translation**

Write this in Turkish: Are you still not convinced?

[[Turkish#^tr-Q0653-answer|Compare the answer]]
^tr-Q0653

**tr-Q0654 · Explain the grammar**

Hala ikna olmadınız 【mı】?

Are you still not convinced?

[[Turkish#^tr-Q0654-answer|Compare the answer]]
^tr-Q0654

**tr-Q0655 · Fill the gap**

Haberi gördünüz ____?

Have you guys seen the news?

[[Turkish#^tr-Q0655-answer|Compare the answer]]
^tr-Q0655

**tr-Q0656 · Choose the form**

Haberi gördünüz ____?

Have you guys seen the news?

Choices: mu / mı / mi / mü

[[Turkish#^tr-Q0656-answer|Compare the answer]]
^tr-Q0656

**tr-Q0657 · Edit the changed sentence**

Sabah bir uçuş var 【mi】?

Is there a flight in the morning?

[[Turkish#^tr-Q0657-answer|Compare the answer]]
^tr-Q0657

**tr-Q0658 · Build the sentence**

Arrange: mı? / bir / uçuş / var / Sabah

Is there a flight in the morning?

[[Turkish#^tr-Q0658-answer|Compare the answer]]
^tr-Q0658

**tr-Q0659 · Write a translation**

Write this in Turkish: Will you stay here for a while?

[[Turkish#^tr-Q0659-answer|Compare the answer]]
^tr-Q0659

**tr-Q0660 · Explain the grammar**

Lütfen bir süreliğine burada kalır 【mısın】?

Will you stay here for a while?

[[Turkish#^tr-Q0660-answer|Compare the answer]]
^tr-Q0660

**tr-Q0661 · Fill the gap**

Bu yaygın bir isim ____?

Is that a common name?

[[Turkish#^tr-Q0661-answer|Compare the answer]]
^tr-Q0661

**tr-Q0662 · Choose the form**

Bu yaygın bir isim ____?

Is that a common name?

Choices: mu / mı / mü / mi

[[Turkish#^tr-Q0662-answer|Compare the answer]]
^tr-Q0662

**tr-Q0663 · Edit the changed sentence**

Anne ve baban hala Almanya'da yaşıyor 【mı】?

Do your parents still live in Germany?

[[Turkish#^tr-Q0663-answer|Compare the answer]]
^tr-Q0663

**tr-Q0664 · Build the sentence**

Arrange: hala / ve / Anne / baban / yaşıyor / Almanya'da / mu?

Do your parents still live in Germany?

[[Turkish#^tr-Q0664-answer|Compare the answer]]
^tr-Q0664

**tr-Q0665 · Write a translation**

Write this in Turkish: Don't you want to live forever?

[[Turkish#^tr-Q0665-answer|Compare the answer]]
^tr-Q0665

**tr-Q0666 · Explain the grammar**

Sonsuza kadar yaşamak istemiyor 【musun】?

Don't you want to live forever?

[[Turkish#^tr-Q0666-answer|Compare the answer]]
^tr-Q0666

**tr-Q0667 · Fill the gap**

Hep o kadar meşgul ____?

Are you always that busy?

[[Turkish#^tr-Q0667-answer|Compare the answer]]
^tr-Q0667

**tr-Q0668 · Choose the form**

Hep o kadar meşgul ____?

Are you always that busy?

Choices: mu / müsün / mı / mi

[[Turkish#^tr-Q0668-answer|Compare the answer]]
^tr-Q0668

**tr-Q0669 · Edit the changed sentence**

Tom sinirlendi 【mı】?

Did Tom get angry?

[[Turkish#^tr-Q0669-answer|Compare the answer]]
^tr-Q0669

**tr-Q0670 · Build the sentence**

Arrange: sinirlendi / mi? / Tom

Did Tom get angry?

[[Turkish#^tr-Q0670-answer|Compare the answer]]
^tr-Q0670

**tr-Q0671 · Write a translation**

Write this in Turkish: Do you have a sec?

[[Turkish#^tr-Q0671-answer|Compare the answer]]
^tr-Q0671

**tr-Q0672 · Explain the grammar**

Bir saniyeniz var 【mı】?

Do you have a sec?

[[Turkish#^tr-Q0672-answer|Compare the answer]]
^tr-Q0672

**tr-Q0673 · Fill the gap**

Sadece bana güvenmen gerek, tamam ____?

I just need you to trust me, OK?

[[Turkish#^tr-Q0673-answer|Compare the answer]]
^tr-Q0673

**tr-Q0674 · Choose the form**

Sadece bana güvenmen gerek, tamam ____?

I just need you to trust me, OK?

Choices: mi / mü / mu / mı

[[Turkish#^tr-Q0674-answer|Compare the answer]]
^tr-Q0674

**tr-Q0675 · Edit the changed sentence**

İhtiyacımız olan bilginin herhangi birini alabildin 【mı】?

Were you able to get any of the information we needed?

[[Turkish#^tr-Q0675-answer|Compare the answer]]
^tr-Q0675

**tr-Q0676 · Build the sentence**

Arrange: olan / bilginin / mi? / alabildin / İhtiyacımız / birini / herhangi

Were you able to get any of the information we needed?

[[Turkish#^tr-Q0676-answer|Compare the answer]]
^tr-Q0676

**tr-Q0677 · Write a translation**

Write this in Turkish: Does your girlfriend like flowers?

[[Turkish#^tr-Q0677-answer|Compare the answer]]
^tr-Q0677

**tr-Q0678 · Explain the grammar**

Kız arkadaşın çiçekleri sever 【mi】?

Does your girlfriend like flowers?

[[Turkish#^tr-Q0678-answer|Compare the answer]]
^tr-Q0678

**tr-Q0679 · Fill the gap**

Gerçekten Boston'a geri dönmek istiyor ____?

Do you really want to go back to Boston?

[[Turkish#^tr-Q0679-answer|Compare the answer]]
^tr-Q0679

**tr-Q0680 · Choose the form**

Gerçekten Boston'a geri dönmek istiyor ____?

Do you really want to go back to Boston?

Choices: mu / musun / mi / mı

[[Turkish#^tr-Q0680-answer|Compare the answer]]
^tr-Q0680

**tr-Q0681 · Edit the changed sentence**

Bu sorunu halledebilir 【mı】?

Can you do this problem?

[[Turkish#^tr-Q0681-answer|Compare the answer]]
^tr-Q0681

**tr-Q0682 · Build the sentence**

Arrange: Bu / sorunu / misin? / halledebilir

Can you do this problem?

[[Turkish#^tr-Q0682-answer|Compare the answer]]
^tr-Q0682

**tr-Q0683 · Write a translation**

Write this in Turkish: Is Tom dreaming?

[[Turkish#^tr-Q0683-answer|Compare the answer]]
^tr-Q0683

**tr-Q0684 · Explain the grammar**

Tom hayal kuruyor 【mu】?

Is Tom dreaming?

[[Turkish#^tr-Q0684-answer|Compare the answer]]
^tr-Q0684

**tr-Q0685 · Fill the gap**

Tom ne yaptığının farkında ____?

Is Tom aware of what he did?

[[Turkish#^tr-Q0685-answer|Compare the answer]]
^tr-Q0685

**tr-Q0686 · Choose the form**

Tom ne yaptığının farkında ____?

Is Tom aware of what he did?

Choices: mi / mu / mü / mı

[[Turkish#^tr-Q0686-answer|Compare the answer]]
^tr-Q0686

**tr-Q0687 · Edit the changed sentence**

Bana telefon ettin 【mı】?

Did you phone me?

[[Turkish#^tr-Q0687-answer|Compare the answer]]
^tr-Q0687

**tr-Q0688 · Build the sentence**

Arrange: telefon / mi? / Bana / ettin

Did you phone me?

[[Turkish#^tr-Q0688-answer|Compare the answer]]
^tr-Q0688

**tr-Q0689 · Write a translation**

Write this in Turkish: What are you going to do? Tell your mom?

[[Turkish#^tr-Q0689-answer|Compare the answer]]
^tr-Q0689

**tr-Q0690 · Explain the grammar**

Ne yapacaksın? Annene söyledin 【mi】?

What are you going to do? Tell your mom?

[[Turkish#^tr-Q0690-answer|Compare the answer]]
^tr-Q0690

**tr-Q0691 · Fill the gap**

Tom'un Mary'ye ne verdiğini sen bile bilmek istemiyor ____?

Don't you even want to know what Tom gave Mary?

[[Turkish#^tr-Q0691-answer|Compare the answer]]
^tr-Q0691

**tr-Q0692 · Choose the form**

Tom'un Mary'ye ne verdiğini sen bile bilmek istemiyor ____?

Don't you even want to know what Tom gave Mary?

Choices: mı / mu / musun / mi

[[Turkish#^tr-Q0692-answer|Compare the answer]]
^tr-Q0692

**tr-Q0693 · Edit the changed sentence**

Sen olağanüstü notlar aldın, değil 【mı】?

You got extraordinary grades, didn't you?

[[Turkish#^tr-Q0693-answer|Compare the answer]]
^tr-Q0693

**tr-Q0694 · Build the sentence**

Arrange: mi? / aldın, / notlar / Sen / değil / olağanüstü

You got extraordinary grades, didn't you?

[[Turkish#^tr-Q0694-answer|Compare the answer]]
^tr-Q0694

**tr-Q0695 · Write a translation**

Write this in Turkish: Have you got any plans?

[[Turkish#^tr-Q0695-answer|Compare the answer]]
^tr-Q0695

**tr-Q0696 · Explain the grammar**

Hiç planın var 【mı】?

Have you got any plans?

[[Turkish#^tr-Q0696-answer|Compare the answer]]
^tr-Q0696

**tr-Q0697 · Fill the gap**

Kim olduğumu bilmiyor ____?

Don't you know who I am?

[[Turkish#^tr-Q0697-answer|Compare the answer]]
^tr-Q0697

**tr-Q0698 · Choose the form**

Kim olduğumu bilmiyor ____?

Don't you know who I am?

Choices: mı / mu / musun / mi

[[Turkish#^tr-Q0698-answer|Compare the answer]]
^tr-Q0698

**tr-Q0699 · Edit the changed sentence**

Bu civarda bir market var 【mi】?

Is there a convenience store near here?

[[Turkish#^tr-Q0699-answer|Compare the answer]]
^tr-Q0699

**tr-Q0700 · Build the sentence**

Arrange: Bu / mı? / var / market / bir / civarda

Is there a convenience store near here?

[[Turkish#^tr-Q0700-answer|Compare the answer]]
^tr-Q0700


### Question words · 50 questions

**tr-Q0701 · Write a translation**

Write this in Turkish: Wow! What a big box!

[[Turkish#^tr-Q0701-answer|Compare the answer]]
^tr-Q0701

**tr-Q0702 · Explain the grammar**

Oo! 【Ne】 büyük bir kutu!

Wow! What a big box!

[[Turkish#^tr-Q0702-answer|Compare the answer]]
^tr-Q0702

**tr-Q0703 · Fill the gap**

____ zaman Boston'a gitsek Tom'la kalırız.

We stay with Tom whenever we go to Boston.

[[Turkish#^tr-Q0703-answer|Compare the answer]]
^tr-Q0703

**tr-Q0704 · Choose the form**

____ zaman Boston'a gitsek Tom'la kalırız.

We stay with Tom whenever we go to Boston.

Choices: Ne / nereye / kim / nerede

[[Turkish#^tr-Q0704-answer|Compare the answer]]
^tr-Q0704

**tr-Q0705 · Edit the changed sentence**

【kim】 zaman geri gideceğiz?

When will we go back?

[[Turkish#^tr-Q0705-answer|Compare the answer]]
^tr-Q0705

**tr-Q0706 · Build the sentence**

Arrange: zaman / geri / Ne / gideceğiz?

When will we go back?

[[Turkish#^tr-Q0706-answer|Compare the answer]]
^tr-Q0706

**tr-Q0707 · Write a translation**

Write this in Turkish: How many people climbed Mount Everest?

[[Turkish#^tr-Q0707-answer|Compare the answer]]
^tr-Q0707

**tr-Q0708 · Explain the grammar**

【Kaç】 kişi Everest dağına tırmandı?

How many people climbed Mount Everest?

[[Turkish#^tr-Q0708-answer|Compare the answer]]
^tr-Q0708

**tr-Q0709 · Fill the gap**

Tom ____ Mary'yi bu kadar çok seviyor?

Why does Tom like Mary so much?

[[Turkish#^tr-Q0709-answer|Compare the answer]]
^tr-Q0709

**tr-Q0710 · Choose the form**

Tom ____ Mary'yi bu kadar çok seviyor?

Why does Tom like Mary so much?

Choices: nerede / kim / neden / ne

[[Turkish#^tr-Q0710-answer|Compare the answer]]
^tr-Q0710

**tr-Q0711 · Edit the changed sentence**

Eğer öyleyse, o zaman 【kim】 yaparız?

If so, then what do we do?

[[Turkish#^tr-Q0711-answer|Compare the answer]]
^tr-Q0711

**tr-Q0712 · Build the sentence**

Arrange: Eğer / öyleyse, / yaparız? / zaman / o / ne

If so, then what do we do?

[[Turkish#^tr-Q0712-answer|Compare the answer]]
^tr-Q0712

**tr-Q0713 · Write a translation**

Write this in Turkish: How old are you and what's your name?

[[Turkish#^tr-Q0713-answer|Compare the answer]]
^tr-Q0713

**tr-Q0714 · Explain the grammar**

【Kaç】 yaşındasın ve adın ne?

How old are you and what's your name?

[[Turkish#^tr-Q0714-answer|Compare the answer]]
^tr-Q0714

**tr-Q0715 · Fill the gap**

Tom'un ____ düşündüğüyle neden bu kadar ilgileniyorsun.

Why are you so interested in what Tom thinks?

[[Turkish#^tr-Q0715-answer|Compare the answer]]
^tr-Q0715

**tr-Q0716 · Choose the form**

Tom'un ____ düşündüğüyle neden bu kadar ilgileniyorsun.

Why are you so interested in what Tom thinks?

Choices: nerede / ne / nereye / kim

[[Turkish#^tr-Q0716-answer|Compare the answer]]
^tr-Q0716

**tr-Q0717 · Edit the changed sentence**

Buradan Boston'a gitmek 【kim】 kadar sürer?

How long does it take to get to Boston from here?

[[Turkish#^tr-Q0717-answer|Compare the answer]]
^tr-Q0717

**tr-Q0718 · Build the sentence**

Arrange: Boston'a / Buradan / kadar / ne / gitmek / sürer?

How long does it take to get to Boston from here?

[[Turkish#^tr-Q0718-answer|Compare the answer]]
^tr-Q0718

**tr-Q0719 · Write a translation**

Write this in Turkish: What is he currently doing?

[[Turkish#^tr-Q0719-answer|Compare the answer]]
^tr-Q0719

**tr-Q0720 · Explain the grammar**

O şu anda 【ne】 yapıyor?

What is he currently doing?

[[Turkish#^tr-Q0720-answer|Compare the answer]]
^tr-Q0720

**tr-Q0721 · Fill the gap**

Tom ve ben kendimizi ____ koruyacağız?

How will Tom and I protect ourselves?

[[Turkish#^tr-Q0721-answer|Compare the answer]]
^tr-Q0721

**tr-Q0722 · Choose the form**

Tom ve ben kendimizi ____ koruyacağız?

How will Tom and I protect ourselves?

Choices: kim / nasıl / nerede / ne

[[Turkish#^tr-Q0722-answer|Compare the answer]]
^tr-Q0722

**tr-Q0723 · Edit the changed sentence**

Para biriktirmek 【ne】 önemlidir?

Why is it important to save money?

[[Turkish#^tr-Q0723-answer|Compare the answer]]
^tr-Q0723

**tr-Q0724 · Build the sentence**

Arrange: neden / Para / biriktirmek / önemlidir?

Why is it important to save money?

[[Turkish#^tr-Q0724-answer|Compare the answer]]
^tr-Q0724

**tr-Q0725 · Write a translation**

Write this in Turkish: When did you visit New York?

[[Turkish#^tr-Q0725-answer|Compare the answer]]
^tr-Q0725

**tr-Q0726 · Explain the grammar**

New York'u 【ne】 zaman ziyaret ettin?

When did you visit New York?

[[Turkish#^tr-Q0726-answer|Compare the answer]]
^tr-Q0726

**tr-Q0727 · Fill the gap**

____ yapmamı istediğini anlamıyorum.

I don't understand what he wants me to do.

[[Turkish#^tr-Q0727-answer|Compare the answer]]
^tr-Q0727

**tr-Q0728 · Choose the form**

____ yapmamı istediğini anlamıyorum.

I don't understand what he wants me to do.

Choices: nereye / nerede / Ne / kim

[[Turkish#^tr-Q0728-answer|Compare the answer]]
^tr-Q0728

**tr-Q0729 · Edit the changed sentence**

Yaşamak için bir haftan daha olsaydı, zamanını 【kim】 yaparak geçirirdin?

If you only had one more week to live, what would you spend your time doing?

[[Turkish#^tr-Q0729-answer|Compare the answer]]
^tr-Q0729

**tr-Q0730 · Build the sentence**

Arrange: bir / haftan / zamanını / ne / daha / yaparak / için / Yaşamak / geçirirdin? / olsaydı,

If you only had one more week to live, what would you spend your time doing?

[[Turkish#^tr-Q0730-answer|Compare the answer]]
^tr-Q0730

**tr-Q0731 · Write a translation**

Write this in Turkish: Tom doesn't know how long the party is going to last.

[[Turkish#^tr-Q0731-answer|Compare the answer]]
^tr-Q0731

**tr-Q0732 · Explain the grammar**

Tom partinin 【ne】 kadar süreceğini bilmiyor.

Tom doesn't know how long the party is going to last.

[[Turkish#^tr-Q0732-answer|Compare the answer]]
^tr-Q0732

**tr-Q0733 · Fill the gap**

____ kadar zamandır orada kaldınız?

How long did you stay there?

[[Turkish#^tr-Q0733-answer|Compare the answer]]
^tr-Q0733

**tr-Q0734 · Choose the form**

____ kadar zamandır orada kaldınız?

How long did you stay there?

Choices: nerede / nereye / kim / Ne

[[Turkish#^tr-Q0734-answer|Compare the answer]]
^tr-Q0734

**tr-Q0735 · Edit the changed sentence**

Tom 【ne】 bitirmedi?

Why didn't Tom finish?

[[Turkish#^tr-Q0735-answer|Compare the answer]]
^tr-Q0735

**tr-Q0736 · Build the sentence**

Arrange: Tom / bitirmedi? / neden

Why didn't Tom finish?

[[Turkish#^tr-Q0736-answer|Compare the answer]]
^tr-Q0736

**tr-Q0737 · Write a translation**

Write this in Turkish: Aw, how can you say that?

[[Turkish#^tr-Q0737-answer|Compare the answer]]
^tr-Q0737

**tr-Q0738 · Explain the grammar**

Ah, bunu 【nasıl】 söyleyebilirsin?

Aw, how can you say that?

[[Turkish#^tr-Q0738-answer|Compare the answer]]
^tr-Q0738

**tr-Q0739 · Fill the gap**

İyi bir nasihat almak için ____ gidebilirim?

Where can I go to get some good advice?

[[Turkish#^tr-Q0739-answer|Compare the answer]]
^tr-Q0739

**tr-Q0740 · Choose the form**

İyi bir nasihat almak için ____ gidebilirim?

Where can I go to get some good advice?

Choices: nerede / nereye / ne / kim

[[Turkish#^tr-Q0740-answer|Compare the answer]]
^tr-Q0740

**tr-Q0741 · Edit the changed sentence**

【ne】 yıl doğdun?

What year were you born?

[[Turkish#^tr-Q0741-answer|Compare the answer]]
^tr-Q0741

**tr-Q0742 · Build the sentence**

Arrange: doğdun? / Hangi / yıl

What year were you born?

[[Turkish#^tr-Q0742-answer|Compare the answer]]
^tr-Q0742

**tr-Q0743 · Write a translation**

Write this in Turkish: I finally found out where you were last night.

[[Turkish#^tr-Q0743-answer|Compare the answer]]
^tr-Q0743

**tr-Q0744 · Explain the grammar**

Dün gece 【nerede】 olduğunu sonunda öğrendim.

I finally found out where you were last night.

[[Turkish#^tr-Q0744-answer|Compare the answer]]
^tr-Q0744

**tr-Q0745 · Fill the gap**

Diyelim bin doların vardı, onunla ____ yapardın?

Suppose you had a thousand dollars, what would you do with it?

[[Turkish#^tr-Q0745-answer|Compare the answer]]
^tr-Q0745

**tr-Q0746 · Choose the form**

Diyelim bin doların vardı, onunla ____ yapardın?

Suppose you had a thousand dollars, what would you do with it?

Choices: nereye / kim / nerede / ne

[[Turkish#^tr-Q0746-answer|Compare the answer]]
^tr-Q0746

**tr-Q0747 · Edit the changed sentence**

O zaman 【ne】 yaşındaydın?

How old were you then?

[[Turkish#^tr-Q0747-answer|Compare the answer]]
^tr-Q0747

**tr-Q0748 · Build the sentence**

Arrange: kaç / yaşındaydın? / zaman / O

How old were you then?

[[Turkish#^tr-Q0748-answer|Compare the answer]]
^tr-Q0748

**tr-Q0749 · Write a translation**

Write this in Turkish: Why would I tell Tom that?

[[Turkish#^tr-Q0749-answer|Compare the answer]]
^tr-Q0749

**tr-Q0750 · Explain the grammar**

【Neden】 bunu Tom'a söyleyeyim?

Why would I tell Tom that?

[[Turkish#^tr-Q0750-answer|Compare the answer]]
^tr-Q0750


### Postpositions · 50 questions

**tr-Q0751 · Fill the gap**

Diğer üç kişi özel övgü ____ seçildi.

Three other people were singled out for special praise.

[[Turkish#^tr-Q0751-answer|Compare the answer]]
^tr-Q0751

**tr-Q0752 · Choose the form**

Diğer üç kişi özel övgü ____ seçildi.

Three other people were singled out for special praise.

Choices: kadar / için / sonra / gibi

[[Turkish#^tr-Q0752-answer|Compare the answer]]
^tr-Q0752

**tr-Q0753 · Edit the changed sentence**

Bugün 【gibi】 işimiz bitti.

We're done for today.

[[Turkish#^tr-Q0753-answer|Compare the answer]]
^tr-Q0753

**tr-Q0754 · Build the sentence**

Arrange: bitti. / işimiz / için / Bugün

We're done for today.

[[Turkish#^tr-Q0754-answer|Compare the answer]]
^tr-Q0754

**tr-Q0755 · Write a translation**

Write this in Turkish: Tom had no desire to go out with Mary.

[[Turkish#^tr-Q0755-answer|Compare the answer]]
^tr-Q0755

**tr-Q0756 · Explain the grammar**

Tom Mary 【ile】 çıkmak istemiyordu.

Tom had no desire to go out with Mary.

[[Turkish#^tr-Q0756-answer|Compare the answer]]
^tr-Q0756

**tr-Q0757 · Fill the gap**

Bill Clinton Monica Lewinsky ____ olan ilişkisini açıklamak isterken muğlak bir dil kullandı.

Bill Clinton spoke in ambiguous language when asked to describe his relationship with Monica Lewinsky.

[[Turkish#^tr-Q0757-answer|Compare the answer]]
^tr-Q0757

**tr-Q0758 · Choose the form**

Bill Clinton Monica Lewinsky ____ olan ilişkisini açıklamak isterken muğlak bir dil kullandı.

Bill Clinton spoke in ambiguous language when asked to describe his relationship with Monica Lewinsky.

Choices: kadar / gibi / için / ile

[[Turkish#^tr-Q0758-answer|Compare the answer]]
^tr-Q0758

**tr-Q0759 · Edit the changed sentence**

Mary'nin hatası olan bir şey 【gibi】 Tom'u suçlayamam.

I can't blame Tom for something that was Mary's fault.

[[Turkish#^tr-Q0759-answer|Compare the answer]]
^tr-Q0759

**tr-Q0760 · Build the sentence**

Arrange: bir / hatası / şey / Tom'u / Mary'nin / suçlayamam. / için / olan

I can't blame Tom for something that was Mary's fault.

[[Turkish#^tr-Q0760-answer|Compare the answer]]
^tr-Q0760

**tr-Q0761 · Write a translation**

Write this in Turkish: I thought you said we weren't going to go to Boston with Tom.

[[Turkish#^tr-Q0761-answer|Compare the answer]]
^tr-Q0761

**tr-Q0762 · Explain the grammar**

Tom 【ile】 Boston'a gitmeyeceği söylediğini düşündüm.

I thought you said we weren't going to go to Boston with Tom.

[[Turkish#^tr-Q0762-answer|Compare the answer]]
^tr-Q0762

**tr-Q0763 · Fill the gap**

Biz gitmeden ____ niçin bir tane almadın?

Why didn't you get one before we left?

[[Turkish#^tr-Q0763-answer|Compare the answer]]
^tr-Q0763

**tr-Q0764 · Choose the form**

Biz gitmeden ____ niçin bir tane almadın?

Why didn't you get one before we left?

Choices: gibi / önce / için / kadar

[[Turkish#^tr-Q0764-answer|Compare the answer]]
^tr-Q0764

**tr-Q0765 · Edit the changed sentence**

Shepard yalnızca 15 dakika 【için】 uzayda kaldı.

Shepard remained in space only about 15 minutes.

[[Turkish#^tr-Q0765-answer|Compare the answer]]
^tr-Q0765

**tr-Q0766 · Build the sentence**

Arrange: 15 / kadar / Shepard / yalnızca / dakika / uzayda / kaldı.

Shepard remained in space only about 15 minutes.

[[Turkish#^tr-Q0766-answer|Compare the answer]]
^tr-Q0766

**tr-Q0767 · Write a translation**

Write this in Turkish: It wasn't as expensive as I thought it would be.

[[Turkish#^tr-Q0767-answer|Compare the answer]]
^tr-Q0767

**tr-Q0768 · Explain the grammar**

O olacağını düşündüğüm 【kadar】 pahalı değildi.

It wasn't as expensive as I thought it would be.

[[Turkish#^tr-Q0768-answer|Compare the answer]]
^tr-Q0768

**tr-Q0769 · Fill the gap**

Koşmaya başlamasından ____ beş dakika olmamıştı ki bir kayaya takılıp düştü.

Not five minutes after he started running, he tripped on a rock.

[[Turkish#^tr-Q0769-answer|Compare the answer]]
^tr-Q0769

**tr-Q0770 · Choose the form**

Koşmaya başlamasından ____ beş dakika olmamıştı ki bir kayaya takılıp düştü.

Not five minutes after he started running, he tripped on a rock.

Choices: için / gibi / sonra / kadar

[[Turkish#^tr-Q0770-answer|Compare the answer]]
^tr-Q0770

**tr-Q0771 · Edit the changed sentence**

Tom'un Mary 【için】 gördüğü son kişi John'du.

The last person Tom saw Mary with was John.

[[Turkish#^tr-Q0771-answer|Compare the answer]]
^tr-Q0771

**tr-Q0772 · Build the sentence**

Arrange: kişi / Mary / gördüğü / John'du. / son / Tom'un / ile

The last person Tom saw Mary with was John.

[[Turkish#^tr-Q0772-answer|Compare the answer]]
^tr-Q0772

**tr-Q0773 · Write a translation**

Write this in Turkish: Tom decided he was too old for rock climbing.

[[Turkish#^tr-Q0773-answer|Compare the answer]]
^tr-Q0773

**tr-Q0774 · Explain the grammar**

Tom kaya tırmanışı 【için】 çok yaşlı olduğuna karar verdi.

Tom decided he was too old for rock climbing.

[[Turkish#^tr-Q0774-answer|Compare the answer]]
^tr-Q0774

**tr-Q0775 · Fill the gap**

Jamal içki almaya gitmek ____ şantiyeden ayrıldı.

Jamal left the construction site to go get a drink.

[[Turkish#^tr-Q0775-answer|Compare the answer]]
^tr-Q0775

**tr-Q0776 · Choose the form**

Jamal içki almaya gitmek ____ şantiyeden ayrıldı.

Jamal left the construction site to go get a drink.

Choices: gibi / kadar / için / sonra

[[Turkish#^tr-Q0776-answer|Compare the answer]]
^tr-Q0776

**tr-Q0777 · Edit the changed sentence**

Tom çok sinirli 【için】 görünüyor.

Tom looks like a nervous wreck.

[[Turkish#^tr-Q0777-answer|Compare the answer]]
^tr-Q0777

**tr-Q0778 · Build the sentence**

Arrange: sinirli / gibi / Tom / çok / görünüyor.

Tom looks like a nervous wreck.

[[Turkish#^tr-Q0778-answer|Compare the answer]]
^tr-Q0778

**tr-Q0779 · Write a translation**

Write this in Turkish: According to Tom, you weren't in class today.

[[Turkish#^tr-Q0779-answer|Compare the answer]]
^tr-Q0779

**tr-Q0780 · Explain the grammar**

Tom'a 【göre】 bugün derste değildin.

According to Tom, you weren't in class today.

[[Turkish#^tr-Q0780-answer|Compare the answer]]
^tr-Q0780

**tr-Q0781 · Fill the gap**

O bir balta ____ dalı kesti.

She chopped down the branch with an ax.

[[Turkish#^tr-Q0781-answer|Compare the answer]]
^tr-Q0781

**tr-Q0782 · Choose the form**

O bir balta ____ dalı kesti.

She chopped down the branch with an ax.

Choices: kadar / için / gibi / ile

[[Turkish#^tr-Q0782-answer|Compare the answer]]
^tr-Q0782

**tr-Q0783 · Edit the changed sentence**

Sen böyle iyi arkadaşlara sahip olduğun 【gibi】 şanslısın.

You are fortunate for having such good friends.

[[Turkish#^tr-Q0783-answer|Compare the answer]]
^tr-Q0783

**tr-Q0784 · Build the sentence**

Arrange: böyle / arkadaşlara / sahip / olduğun / şanslısın. / Sen / iyi / için

You are fortunate for having such good friends.

[[Turkish#^tr-Q0784-answer|Compare the answer]]
^tr-Q0784

**tr-Q0785 · Write a translation**

Write this in Turkish: Tom is still too young to drive.

[[Turkish#^tr-Q0785-answer|Compare the answer]]
^tr-Q0785

**tr-Q0786 · Explain the grammar**

Tom araba kullanmak 【için】 hala çok genç.

Tom is still too young to drive.

[[Turkish#^tr-Q0786-answer|Compare the answer]]
^tr-Q0786

**tr-Q0787 · Fill the gap**

Haziran'dan eylül ayına ____, biz daha fazla çalışırız.

From June to September, we work harder.

[[Turkish#^tr-Q0787-answer|Compare the answer]]
^tr-Q0787

**tr-Q0788 · Choose the form**

Haziran'dan eylül ayına ____, biz daha fazla çalışırız.

From June to September, we work harder.

Choices: sonra / kadar / için / gibi

[[Turkish#^tr-Q0788-answer|Compare the answer]]
^tr-Q0788

**tr-Q0789 · Edit the changed sentence**

Tom ve Mary aile 【için】.

Tom and Mary are like family.

[[Turkish#^tr-Q0789-answer|Compare the answer]]
^tr-Q0789

**tr-Q0790 · Build the sentence**

Arrange: Mary / ve / gibi. / Tom / aile

Tom and Mary are like family.

[[Turkish#^tr-Q0790-answer|Compare the answer]]
^tr-Q0790

**tr-Q0791 · Write a translation**

Write this in Turkish: Mr. Yamanaka looks young for his age.

[[Turkish#^tr-Q0791-answer|Compare the answer]]
^tr-Q0791

**tr-Q0792 · Explain the grammar**

Bay Yamanaka, kendi yaşına 【göre】 genç görünüyor.

Mr. Yamanaka looks young for his age.

[[Turkish#^tr-Q0792-answer|Compare the answer]]
^tr-Q0792

**tr-Q0793 · Fill the gap**

Plastik cerrahiden ____ bile, Mary çirkin değildi.

Even before the plastic surgery, Mary wasn't unattractive.

[[Turkish#^tr-Q0793-answer|Compare the answer]]
^tr-Q0793

**tr-Q0794 · Choose the form**

Plastik cerrahiden ____ bile, Mary çirkin değildi.

Even before the plastic surgery, Mary wasn't unattractive.

Choices: kadar / gibi / için / önce

[[Turkish#^tr-Q0794-answer|Compare the answer]]
^tr-Q0794

**tr-Q0795 · Edit the changed sentence**

Her şey 【gibi】 zaman var.

There's time for everything.

[[Turkish#^tr-Q0795-answer|Compare the answer]]
^tr-Q0795

**tr-Q0796 · Build the sentence**

Arrange: zaman / şey / var. / Her / için

There's time for everything.

[[Turkish#^tr-Q0796-answer|Compare the answer]]
^tr-Q0796

**tr-Q0797 · Write a translation**

Write this in Turkish: It looks like Tom is exhausted.

[[Turkish#^tr-Q0797-answer|Compare the answer]]
^tr-Q0797

**tr-Q0798 · Explain the grammar**

Tom yorgun 【gibi】 görünüyor.

It looks like Tom is exhausted.

[[Turkish#^tr-Q0798-answer|Compare the answer]]
^tr-Q0798

**tr-Q0799 · Fill the gap**

Büyü ve yaşına ____ davran!

Grow up and act your age!

[[Turkish#^tr-Q0799-answer|Compare the answer]]
^tr-Q0799

**tr-Q0800 · Choose the form**

Büyü ve yaşına ____ davran!

Grow up and act your age!

Choices: için / gibi / kadar / göre

[[Turkish#^tr-Q0800-answer|Compare the answer]]
^tr-Q0800


### Conditions · 50 questions

**tr-Q0801 · Edit the changed sentence**

【olursa】 isteseydi Tom Mary'ye yardım edebilirdi.

Tom could help Mary if he wanted to.

[[Turkish#^tr-Q0801-answer|Compare the answer]]
^tr-Q0801

**tr-Q0802 · Build the sentence**

Arrange: edebilirdi. / isteseydi / Mary'ye / yardım / Eğer / Tom

Tom could help Mary if he wanted to.

[[Turkish#^tr-Q0802-answer|Compare the answer]]
^tr-Q0802

**tr-Q0803 · Write a translation**

Write this in Turkish: If Tom can help Mary, why can't he help John, too?

[[Turkish#^tr-Q0803-answer|Compare the answer]]
^tr-Q0803

**tr-Q0804 · Explain the grammar**

【Eğer】 Tom Mary'ye yardım edebiliyorsa, neden John'a da yardım edemiyor?

If Tom can help Mary, why can't he help John, too?

[[Turkish#^tr-Q0804-answer|Compare the answer]]
^tr-Q0804

**tr-Q0805 · Fill the gap**

Bir şeye ihtiyacın ____ beni ara.

Call me if you need anything.

[[Turkish#^tr-Q0805-answer|Compare the answer]]
^tr-Q0805

**tr-Q0806 · Choose the form**

Bir şeye ihtiyacın ____ beni ara.

Call me if you need anything.

Choices: olsaydı / olursa / eğer

[[Turkish#^tr-Q0806-answer|Compare the answer]]
^tr-Q0806

**tr-Q0807 · Edit the changed sentence**

【olursa】 sessiz olmazsan seni duyarlar.

If you're not quiet, they'll hear you.

[[Turkish#^tr-Q0807-answer|Compare the answer]]
^tr-Q0807

**tr-Q0808 · Build the sentence**

Arrange: sessiz / seni / duyarlar. / Eğer / olmazsan

If you're not quiet, they'll hear you.

[[Turkish#^tr-Q0808-answer|Compare the answer]]
^tr-Q0808

**tr-Q0809 · Write a translation**

Write this in Turkish: I wish my grandfather had been alive to see that.

[[Turkish#^tr-Q0809-answer|Compare the answer]]
^tr-Q0809

**tr-Q0810 · Explain the grammar**

Keşke büyükbabam onu görmek için hayatta 【olsaydı】.

I wish my grandfather had been alive to see that.

[[Turkish#^tr-Q0810-answer|Compare the answer]]
^tr-Q0810

**tr-Q0811 · Fill the gap**

____ bilmiyorsan sor.

If you don't know, ask.

[[Turkish#^tr-Q0811-answer|Compare the answer]]
^tr-Q0811

**tr-Q0812 · Choose the form**

____ bilmiyorsan sor.

If you don't know, ask.

Choices: olursa / olsaydı / Eğer

[[Turkish#^tr-Q0812-answer|Compare the answer]]
^tr-Q0812

**tr-Q0813 · Edit the changed sentence**

【olursa】 bu modern donanımı kullanırsanız bir sürü iş gücü tasarruf edecektir.

If you use this modern equipment, it will save a lot of manpower.

[[Turkish#^tr-Q0813-answer|Compare the answer]]
^tr-Q0813

**tr-Q0814 · Build the sentence**

Arrange: bir / donanımı / sürü / modern / tasarruf / iş / edecektir. / Eğer / bu / kullanırsanız / gücü

If you use this modern equipment, it will save a lot of manpower.

[[Turkish#^tr-Q0814-answer|Compare the answer]]
^tr-Q0814

**tr-Q0815 · Write a translation**

Write this in Turkish: No matter what happens, I won't give up.

[[Turkish#^tr-Q0815-answer|Compare the answer]]
^tr-Q0815

**tr-Q0816 · Explain the grammar**

Ne 【olursa】 olsun, vazgeçmeyeceğim.

No matter what happens, I won't give up.

[[Turkish#^tr-Q0816-answer|Compare the answer]]
^tr-Q0816

**tr-Q0817 · Fill the gap**

Ne kadar ____ olsun. Gene de istiyorum.

I don't care what it cost. I still want it.

[[Turkish#^tr-Q0817-answer|Compare the answer]]
^tr-Q0817

**tr-Q0818 · Choose the form**

Ne kadar ____ olsun. Gene de istiyorum.

I don't care what it cost. I still want it.

Choices: olursa / eğer / olsaydı

[[Turkish#^tr-Q0818-answer|Compare the answer]]
^tr-Q0818

**tr-Q0819 · Edit the changed sentence**

Bir zaman makinen 【eğer】, hangi yılı ziyaret ederdin?

If you had a time machine, which year would you visit?

[[Turkish#^tr-Q0819-answer|Compare the answer]]
^tr-Q0819

**tr-Q0820 · Build the sentence**

Arrange: ederdin? / olsaydı, / yılı / hangi / makinen / Bir / ziyaret / zaman

If you had a time machine, which year would you visit?

[[Turkish#^tr-Q0820-answer|Compare the answer]]
^tr-Q0820

**tr-Q0821 · Write a translation**

Write this in Turkish: It's okay if you want to.

[[Turkish#^tr-Q0821-answer|Compare the answer]]
^tr-Q0821

**tr-Q0822 · Explain the grammar**

【Eğer】 istiyorsan tamamdır.

It's okay if you want to.

[[Turkish#^tr-Q0822-answer|Compare the answer]]
^tr-Q0822

**tr-Q0823 · Fill the gap**

____ çalışmayacaksan okula gitmenin bir faydası yok.

It is no use going to school if you are not going to study.

[[Turkish#^tr-Q0823-answer|Compare the answer]]
^tr-Q0823

**tr-Q0824 · Choose the form**

____ çalışmayacaksan okula gitmenin bir faydası yok.

It is no use going to school if you are not going to study.

Choices: olursa / olsaydı / Eğer

[[Turkish#^tr-Q0824-answer|Compare the answer]]
^tr-Q0824

**tr-Q0825 · Edit the changed sentence**

【olursa】 Tom yardım etseydi bu kadar meşgul olmazdın.

You wouldn't have been so busy if Tom had helped.

[[Turkish#^tr-Q0825-answer|Compare the answer]]
^tr-Q0825

**tr-Q0826 · Build the sentence**

Arrange: etseydi / meşgul / Tom / bu / olmazdın. / kadar / Eğer / yardım

You wouldn't have been so busy if Tom had helped.

[[Turkish#^tr-Q0826-answer|Compare the answer]]
^tr-Q0826

**tr-Q0827 · Write a translation**

Write this in Turkish: If I had been able to speak English then, I would not have been made fun of.

[[Turkish#^tr-Q0827-answer|Compare the answer]]
^tr-Q0827

**tr-Q0828 · Explain the grammar**

【Eğer】 o zaman İngilizce konuşabilseydim, alay edilmezdim.

If I had been able to speak English then, I would not have been made fun of.

[[Turkish#^tr-Q0828-answer|Compare the answer]]
^tr-Q0828

**tr-Q0829 · Fill the gap**

Ne ____ olsun, fikrimi değiştirmeyeceğim.

Come what may; I won't change my mind.

[[Turkish#^tr-Q0829-answer|Compare the answer]]
^tr-Q0829

**tr-Q0830 · Choose the form**

Ne ____ olsun, fikrimi değiştirmeyeceğim.

Come what may; I won't change my mind.

Choices: olursa / olsaydı / eğer

[[Turkish#^tr-Q0830-answer|Compare the answer]]
^tr-Q0830

**tr-Q0831 · Edit the changed sentence**

【olursa】 herkes bağışta bulunursa, öğleye kadar oturma odasını boyamayı bitirebileceğiz.

If everyone chips in, we'll be able to finish painting the living room by noon.

[[Turkish#^tr-Q0831-answer|Compare the answer]]
^tr-Q0831

**tr-Q0832 · Build the sentence**

Arrange: bağışta / Eğer / öğleye / kadar / bitirebileceğiz. / oturma / herkes / bulunursa, / boyamayı / odasını

If everyone chips in, we'll be able to finish painting the living room by noon.

[[Turkish#^tr-Q0832-answer|Compare the answer]]
^tr-Q0832

**tr-Q0833 · Write a translation**

Write this in Turkish: If we need your help, we'll call you.

[[Turkish#^tr-Q0833-answer|Compare the answer]]
^tr-Q0833

**tr-Q0834 · Explain the grammar**

Yardımına ihtiyacımız 【olursa】, seni ararız.

If we need your help, we'll call you.

[[Turkish#^tr-Q0834-answer|Compare the answer]]
^tr-Q0834

**tr-Q0835 · Fill the gap**

____ kötüleşirseniz doktora gitmeyi unutmayın.

Make sure you go to a doctor if you get worse.

[[Turkish#^tr-Q0835-answer|Compare the answer]]
^tr-Q0835

**tr-Q0836 · Choose the form**

____ kötüleşirseniz doktora gitmeyi unutmayın.

Make sure you go to a doctor if you get worse.

Choices: olursa / Eğer / olsaydı

[[Turkish#^tr-Q0836-answer|Compare the answer]]
^tr-Q0836

**tr-Q0837 · Edit the changed sentence**

Ne kadar meşgul 【eğer】 olsun, ayda en az bir kez ebeveynlerine yazar.

He writes home to his parents at least once a month, no matter how busy he is.

[[Turkish#^tr-Q0837-answer|Compare the answer]]
^tr-Q0837

**tr-Q0838 · Build the sentence**

Arrange: meşgul / Ne / kez / az / bir / olsun, / ayda / kadar / en / ebeveynlerine / yazar. / olursa

He writes home to his parents at least once a month, no matter how busy he is.

[[Turkish#^tr-Q0838-answer|Compare the answer]]
^tr-Q0838

**tr-Q0839 · Write a translation**

Write this in Turkish: If you don't leave, I'm going to call the cops.

[[Turkish#^tr-Q0839-answer|Compare the answer]]
^tr-Q0839

**tr-Q0840 · Explain the grammar**

【Eğer】 gitmezsen polisleri arayacağım.

If you don't leave, I'm going to call the cops.

[[Turkish#^tr-Q0840-answer|Compare the answer]]
^tr-Q0840

**tr-Q0841 · Fill the gap**

O tutumla ne kadar çok paranız ____ olsun mutlu olmazsınız.

With that attitude, you'll never be happy no matter how much money you have.

[[Turkish#^tr-Q0841-answer|Compare the answer]]
^tr-Q0841

**tr-Q0842 · Choose the form**

O tutumla ne kadar çok paranız ____ olsun mutlu olmazsınız.

With that attitude, you'll never be happy no matter how much money you have.

Choices: olsaydı / eğer / olursa

[[Turkish#^tr-Q0842-answer|Compare the answer]]
^tr-Q0842

**tr-Q0843 · Edit the changed sentence**

Tom 【olursa】 gerçekten onları isteseydi onların hepsini alabilirdi.

Tom could buy all of those if he really wanted them.

[[Turkish#^tr-Q0843-answer|Compare the answer]]
^tr-Q0843

**tr-Q0844 · Build the sentence**

Arrange: onları / eğer / Tom / isteseydi / hepsini / alabilirdi. / gerçekten / onların

Tom could buy all of those if he really wanted them.

[[Turkish#^tr-Q0844-answer|Compare the answer]]
^tr-Q0844

**tr-Q0845 · Write a translation**

Write this in Turkish: Tom, if you're not going I'm not going either.

[[Turkish#^tr-Q0845-answer|Compare the answer]]
^tr-Q0845

**tr-Q0846 · Explain the grammar**

Tom, 【eğer】 sen gitmiyorsan ben de gitmiyorum.

Tom, if you're not going I'm not going either.

[[Turkish#^tr-Q0846-answer|Compare the answer]]
^tr-Q0846

**tr-Q0847 · Fill the gap**

____ Tom'un bir sorunu olsaydı ona yardım edebilirdin.

If Tom has a problem, you could help him.

[[Turkish#^tr-Q0847-answer|Compare the answer]]
^tr-Q0847

**tr-Q0848 · Choose the form**

____ Tom'un bir sorunu olsaydı ona yardım edebilirdin.

If Tom has a problem, you could help him.

Choices: olsaydı / Eğer / olursa

[[Turkish#^tr-Q0848-answer|Compare the answer]]
^tr-Q0848

**tr-Q0849 · Edit the changed sentence**

【olursa】 almamı istersen sana başka bir tane alırım.

I'll buy you another one if you want me to.

[[Turkish#^tr-Q0849-answer|Compare the answer]]
^tr-Q0849

**tr-Q0850 · Build the sentence**

Arrange: tane / istersen / alırım. / bir / almamı / başka / sana / Eğer

I'll buy you another one if you want me to.

[[Turkish#^tr-Q0850-answer|Compare the answer]]
^tr-Q0850


### Clause linking · 50 questions

**tr-Q0851 · Write a translation**

Write this in Turkish: Tom and his friend were duelling with plastic swords.

[[Turkish#^tr-Q0851-answer|Compare the answer]]
^tr-Q0851

**tr-Q0852 · Explain the grammar**

Tom 【ve】 arkadaşı plastik kılıçlarla düello ediyorlardı.

Tom and his friend were duelling with plastic swords.

[[Turkish#^tr-Q0852-answer|Compare the answer]]
^tr-Q0852

**tr-Q0853 · Fill the gap**

Tom ____ Mary birbiriyle evliydi.

Tom and Mary used to be married to each other.

[[Turkish#^tr-Q0853-answer|Compare the answer]]
^tr-Q0853

**tr-Q0854 · Choose the form**

Tom ____ Mary birbiriyle evliydi.

Tom and Mary used to be married to each other.

Choices: ve / ama / veya / çünkü

[[Turkish#^tr-Q0854-answer|Compare the answer]]
^tr-Q0854

**tr-Q0855 · Edit the changed sentence**

Dikiş dikmeyi bıraktı 【çünkü】 biraz çay içti.

She stopped sewing and had some tea.

[[Turkish#^tr-Q0855-answer|Compare the answer]]
^tr-Q0855

**tr-Q0856 · Build the sentence**

Arrange: dikmeyi / bıraktı / içti. / ve / çay / biraz / Dikiş

She stopped sewing and had some tea.

[[Turkish#^tr-Q0856-answer|Compare the answer]]
^tr-Q0856

**tr-Q0857 · Write a translation**

Write this in Turkish: The car is waxed and shining.

[[Turkish#^tr-Q0857-answer|Compare the answer]]
^tr-Q0857

**tr-Q0858 · Explain the grammar**

Araba mumluydu 【ve】 parlıyordu.

The car is waxed and shining.

[[Turkish#^tr-Q0858-answer|Compare the answer]]
^tr-Q0858

**tr-Q0859 · Fill the gap**

Sessiz oturun ____ bir şeye dokunmayın.

Sit still and don't touch anything.

[[Turkish#^tr-Q0859-answer|Compare the answer]]
^tr-Q0859

**tr-Q0860 · Choose the form**

Sessiz oturun ____ bir şeye dokunmayın.

Sit still and don't touch anything.

Choices: ama / çünkü / veya / ve

[[Turkish#^tr-Q0860-answer|Compare the answer]]
^tr-Q0860

**tr-Q0861 · Edit the changed sentence**

Pizza yapmada çok iyi değilim 【çünkü】 Tom iyidir.

I'm not very good at making pizza, but Tom is.

[[Turkish#^tr-Q0861-answer|Compare the answer]]
^tr-Q0861

**tr-Q0862 · Build the sentence**

Arrange: yapmada / iyidir. / çok / iyi / değilim / Pizza / Tom / ama

I'm not very good at making pizza, but Tom is.

[[Turkish#^tr-Q0862-answer|Compare the answer]]
^tr-Q0862

**tr-Q0863 · Write a translation**

Write this in Turkish: The disagreement between the union and management could lead to a strike.

[[Turkish#^tr-Q0863-answer|Compare the answer]]
^tr-Q0863

**tr-Q0864 · Explain the grammar**

Sendika 【ve】 yönetim arasındaki anlaşmazlık bir greve yol açabilir.

The disagreement between the union and management could lead to a strike.

[[Turkish#^tr-Q0864-answer|Compare the answer]]
^tr-Q0864

**tr-Q0865 · Fill the gap**

Tom hızla çekmeceyi açtı ____ bir silah çıkardı.

Tom quickly opened the drawer and pulled out a gun.

[[Turkish#^tr-Q0865-answer|Compare the answer]]
^tr-Q0865

**tr-Q0866 · Choose the form**

Tom hızla çekmeceyi açtı ____ bir silah çıkardı.

Tom quickly opened the drawer and pulled out a gun.

Choices: ama / çünkü / ve / veya

[[Turkish#^tr-Q0866-answer|Compare the answer]]
^tr-Q0866

**tr-Q0867 · Edit the changed sentence**

Biz oldukça önemsizdik 【çünkü】 buna rağmen müthiştik.

We're quite insignificant, but awesome nevertheless.

[[Turkish#^tr-Q0867-answer|Compare the answer]]
^tr-Q0867

**tr-Q0868 · Build the sentence**

Arrange: müthiştik. / ama / Biz / rağmen / buna / oldukça / önemsizdik

We're quite insignificant, but awesome nevertheless.

[[Turkish#^tr-Q0868-answer|Compare the answer]]
^tr-Q0868

**tr-Q0869 · Write a translation**

Write this in Turkish: Tom wasn't sick, but Mary was.

[[Turkish#^tr-Q0869-answer|Compare the answer]]
^tr-Q0869

**tr-Q0870 · Explain the grammar**

Tom hasta değildi, 【ama】 Mary hastaydı.

Tom wasn't sick, but Mary was.

[[Turkish#^tr-Q0870-answer|Compare the answer]]
^tr-Q0870

**tr-Q0871 · Fill the gap**

Volkan dışarıya alevlerini ____ dumanlarını güçlü bir şekilde fırlattı.

The volcano is belching out flames and smoke.

[[Turkish#^tr-Q0871-answer|Compare the answer]]
^tr-Q0871

**tr-Q0872 · Choose the form**

Volkan dışarıya alevlerini ____ dumanlarını güçlü bir şekilde fırlattı.

The volcano is belching out flames and smoke.

Choices: ve / veya / ama / çünkü

[[Turkish#^tr-Q0872-answer|Compare the answer]]
^tr-Q0872

**tr-Q0873 · Edit the changed sentence**

Git 【çünkü】 onunla konuş Tom . Neyden korkuyorsun?

Go and talk to her, Tom. What are you afraid of?

[[Turkish#^tr-Q0873-answer|Compare the answer]]
^tr-Q0873

**tr-Q0874 · Build the sentence**

Arrange: onunla / . / ve / korkuyorsun? / Git / Neyden / konuş / Tom

Go and talk to her, Tom. What are you afraid of?

[[Turkish#^tr-Q0874-answer|Compare the answer]]
^tr-Q0874

**tr-Q0875 · Write a translation**

Write this in Turkish: I looked for the key under the welcome mat and in the nearby flower pot.

[[Turkish#^tr-Q0875-answer|Compare the answer]]
^tr-Q0875

**tr-Q0876 · Explain the grammar**

Anahtarı paspasın altında 【ve】 yakındaki saksının içinde aradım.

I looked for the key under the welcome mat and in the nearby flower pot.

[[Turkish#^tr-Q0876-answer|Compare the answer]]
^tr-Q0876

**tr-Q0877 · Fill the gap**

Bahçede, elma ağaçları, erikler, kirazlar, ahududu, bektaşi üzümü ____ kuş üzümü vardır.

In the garden, there are apple trees, plums, cherries, raspberries, gooseberries, and currants.

[[Turkish#^tr-Q0877-answer|Compare the answer]]
^tr-Q0877

**tr-Q0878 · Choose the form**

Bahçede, elma ağaçları, erikler, kirazlar, ahududu, bektaşi üzümü ____ kuş üzümü vardır.

In the garden, there are apple trees, plums, cherries, raspberries, gooseberries, and currants.

Choices: veya / ve / ama / çünkü

[[Turkish#^tr-Q0878-answer|Compare the answer]]
^tr-Q0878

**tr-Q0879 · Edit the changed sentence**

Tom Mary'ye bir öpücük verdi 【çünkü】 arabadan indi.

Tom gave Mary a kiss and got out of the car.

[[Turkish#^tr-Q0879-answer|Compare the answer]]
^tr-Q0879

**tr-Q0880 · Build the sentence**

Arrange: indi. / öpücük / arabadan / verdi / Mary'ye / bir / ve / Tom

Tom gave Mary a kiss and got out of the car.

[[Turkish#^tr-Q0880-answer|Compare the answer]]
^tr-Q0880

**tr-Q0881 · Write a translation**

Write this in Turkish: Tom and Mary usually speak French to each other.

[[Turkish#^tr-Q0881-answer|Compare the answer]]
^tr-Q0881

**tr-Q0882 · Explain the grammar**

Tom 【ve】 Mary birbirleriyle genellikle Fransızca konuşurlar.

Tom and Mary usually speak French to each other.

[[Turkish#^tr-Q0882-answer|Compare the answer]]
^tr-Q0882

**tr-Q0883 · Fill the gap**

Gabriel sıcak çorba ____ biraz şerinin dışında bir şey almadı.

Gabriel took nothing but the hot soup and a little sherry.

[[Turkish#^tr-Q0883-answer|Compare the answer]]
^tr-Q0883

**tr-Q0884 · Choose the form**

Gabriel sıcak çorba ____ biraz şerinin dışında bir şey almadı.

Gabriel took nothing but the hot soup and a little sherry.

Choices: ama / ve / veya / çünkü

[[Turkish#^tr-Q0884-answer|Compare the answer]]
^tr-Q0884

**tr-Q0885 · Edit the changed sentence**

Tom 【çünkü】 Mary yalnız değiller.

Tom and Mary aren't alone.

[[Turkish#^tr-Q0885-answer|Compare the answer]]
^tr-Q0885

**tr-Q0886 · Build the sentence**

Arrange: ve / yalnız / Tom / değiller. / Mary

Tom and Mary aren't alone.

[[Turkish#^tr-Q0886-answer|Compare the answer]]
^tr-Q0886

**tr-Q0887 · Write a translation**

Write this in Turkish: What were you and Tom doing yesterday?

[[Turkish#^tr-Q0887-answer|Compare the answer]]
^tr-Q0887

**tr-Q0888 · Explain the grammar**

Sen 【ve】 Tom dün ne yapıyordunuz?

What were you and Tom doing yesterday?

[[Turkish#^tr-Q0888-answer|Compare the answer]]
^tr-Q0888

**tr-Q0889 · Fill the gap**

Lezzetli yiyecek ____ içecekler servis edildi.

Delicious refreshments were served.

[[Turkish#^tr-Q0889-answer|Compare the answer]]
^tr-Q0889

**tr-Q0890 · Choose the form**

Lezzetli yiyecek ____ içecekler servis edildi.

Delicious refreshments were served.

Choices: veya / ve / çünkü / ama

[[Turkish#^tr-Q0890-answer|Compare the answer]]
^tr-Q0890

**tr-Q0891 · Edit the changed sentence**

İnekler antibiyotik 【çünkü】 hormonla beslenirler.

The cows are fed antibiotics and hormones.

[[Turkish#^tr-Q0891-answer|Compare the answer]]
^tr-Q0891

**tr-Q0892 · Build the sentence**

Arrange: İnekler / beslenirler. / antibiyotik / ve / hormonla

The cows are fed antibiotics and hormones.

[[Turkish#^tr-Q0892-answer|Compare the answer]]
^tr-Q0892

**tr-Q0893 · Write a translation**

Write this in Turkish: Tom married Mary's sister and Mary married Tom's brother.

[[Turkish#^tr-Q0893-answer|Compare the answer]]
^tr-Q0893

**tr-Q0894 · Explain the grammar**

Tom, Mary'nin kız kardeşi ile evlendi 【ve】 Mary, Tom'un erkek kardeşiyle evlendi.

Tom married Mary's sister and Mary married Tom's brother.

[[Turkish#^tr-Q0894-answer|Compare the answer]]
^tr-Q0894

**tr-Q0895 · Fill the gap**

Sami ____ Leyla konuşuyorlardı.

Sami and Layla were talking.

[[Turkish#^tr-Q0895-answer|Compare the answer]]
^tr-Q0895

**tr-Q0896 · Choose the form**

Sami ____ Leyla konuşuyorlardı.

Sami and Layla were talking.

Choices: çünkü / ve / ama / veya

[[Turkish#^tr-Q0896-answer|Compare the answer]]
^tr-Q0896

**tr-Q0897 · Edit the changed sentence**

O hayal kırıklığına uğradı 【çünkü】 öyle olduğu için kendine kızdı.

She was disappointed, and angry with herself for being so.

[[Turkish#^tr-Q0897-answer|Compare the answer]]
^tr-Q0897

**tr-Q0898 · Build the sentence**

Arrange: uğradı / için / O / öyle / hayal / ve / kızdı. / kırıklığına / kendine / olduğu

She was disappointed, and angry with herself for being so.

[[Turkish#^tr-Q0898-answer|Compare the answer]]
^tr-Q0898

**tr-Q0899 · Write a translation**

Write this in Turkish: Tom and I talked about how we were going to spend the money.

[[Turkish#^tr-Q0899-answer|Compare the answer]]
^tr-Q0899

**tr-Q0900 · Explain the grammar**

Tom 【ve】 ben parayı nasıl harcayacağımız hakkında konuştuk.

Tom and I talked about how we were going to spend the money.

[[Turkish#^tr-Q0900-answer|Compare the answer]]
^tr-Q0900


### Participles and nominal clauses · 50 questions

**tr-Q0901 · Fill the gap**

Tom'un erkek arkadaşın ____ sandım.

I assumed Tom was your boyfriend.

[[Turkish#^tr-Q0901-answer|Compare the answer]]
^tr-Q0901

**tr-Q0902 · Choose the form**

Tom'un erkek arkadaşın ____ sandım.

I assumed Tom was your boyfriend.

Choices: gelen / giden / olan / olduğunu

[[Turkish#^tr-Q0902-answer|Compare the answer]]
^tr-Q0902

**tr-Q0903 · Edit the changed sentence**

Daha fazla zamana ihtiyacın 【olan】 söyledin.

You said you needed more time.

[[Turkish#^tr-Q0903-answer|Compare the answer]]
^tr-Q0903

**tr-Q0904 · Build the sentence**

Arrange: ihtiyacın / Daha / fazla / zamana / söyledin. / olduğunu

You said you needed more time.

[[Turkish#^tr-Q0904-answer|Compare the answer]]
^tr-Q0904

**tr-Q0905 · Write a translation**

Write this in Turkish: Tom thought he was smarter than anybody else.

[[Turkish#^tr-Q0905-answer|Compare the answer]]
^tr-Q0905

**tr-Q0906 · Explain the grammar**

Tom başka herkesten daha akıllı 【olduğunu】 düşünüyordu.

Tom thought he was smarter than anybody else.

[[Turkish#^tr-Q0906-answer|Compare the answer]]
^tr-Q0906

**tr-Q0907 · Fill the gap**

Ben oldukça şanslı ____ düşünüyorum.

I think I'm pretty lucky.

[[Turkish#^tr-Q0907-answer|Compare the answer]]
^tr-Q0907

**tr-Q0908 · Choose the form**

Ben oldukça şanslı ____ düşünüyorum.

I think I'm pretty lucky.

Choices: olduğumu / gelen / giden / olan

[[Turkish#^tr-Q0908-answer|Compare the answer]]
^tr-Q0908

**tr-Q0909 · Edit the changed sentence**

Bugün okulda ne 【olan】 duydum.

I heard about what happened at school today.

[[Turkish#^tr-Q0909-answer|Compare the answer]]
^tr-Q0909

**tr-Q0910 · Build the sentence**

Arrange: ne / olduğunu / Bugün / duydum. / okulda

I heard about what happened at school today.

[[Turkish#^tr-Q0910-answer|Compare the answer]]
^tr-Q0910

**tr-Q0911 · Write a translation**

Write this in Turkish: Tom said he was from Boston.

[[Turkish#^tr-Q0911-answer|Compare the answer]]
^tr-Q0911

**tr-Q0912 · Explain the grammar**

Tom Boston'lu 【olduğunu】 söyledi.

Tom said he was from Boston.

[[Turkish#^tr-Q0912-answer|Compare the answer]]
^tr-Q0912

**tr-Q0913 · Fill the gap**

Herkesin aç ____ düşündüm.

I thought everyone was hungry.

[[Turkish#^tr-Q0913-answer|Compare the answer]]
^tr-Q0913

**tr-Q0914 · Choose the form**

Herkesin aç ____ düşündüm.

I thought everyone was hungry.

Choices: olduğunu / gelen / olan / giden

[[Turkish#^tr-Q0914-answer|Compare the answer]]
^tr-Q0914

**tr-Q0915 · Edit the changed sentence**

Benim babam 【olan】 nasıl olur da bana söyleyemezsin?

How could you not tell me that you're my father?

[[Turkish#^tr-Q0915-answer|Compare the answer]]
^tr-Q0915

**tr-Q0916 · Build the sentence**

Arrange: Benim / bana / söyleyemezsin? / nasıl / olduğunu / da / olur / babam

How could you not tell me that you're my father?

[[Turkish#^tr-Q0916-answer|Compare the answer]]
^tr-Q0916

**tr-Q0917 · Write a translation**

Write this in Turkish: I wonder what's taking Tom so long.

[[Turkish#^tr-Q0917-answer|Compare the answer]]
^tr-Q0917

**tr-Q0918 · Explain the grammar**

Tom'un bu kadar zamanını alan şeyin ne 【olduğunu】 merak ediyorum.

I wonder what's taking Tom so long.

[[Turkish#^tr-Q0918-answer|Compare the answer]]
^tr-Q0918

**tr-Q0919 · Fill the gap**

Onunla bir ilgim ____ öne sürüyorsan yanılıyorsun.

If you're suggesting that I had anything to do with, you're wrong.

[[Turkish#^tr-Q0919-answer|Compare the answer]]
^tr-Q0919

**tr-Q0920 · Choose the form**

Onunla bir ilgim ____ öne sürüyorsan yanılıyorsun.

If you're suggesting that I had anything to do with, you're wrong.

Choices: gelen / olduğunu / giden / olan

[[Turkish#^tr-Q0920-answer|Compare the answer]]
^tr-Q0920

**tr-Q0921 · Edit the changed sentence**

Mary'nin onun aptal 【olan】 düşündüğünü Tom'un bildiğini sanmıyorum.

I don't think Tom knows that Mary thinks he's stupid.

[[Turkish#^tr-Q0921-answer|Compare the answer]]
^tr-Q0921

**tr-Q0922 · Build the sentence**

Arrange: düşündüğünü / onun / Mary'nin / aptal / Tom'un / olduğunu / bildiğini / sanmıyorum.

I don't think Tom knows that Mary thinks he's stupid.

[[Turkish#^tr-Q0922-answer|Compare the answer]]
^tr-Q0922

**tr-Q0923 · Write a translation**

Write this in Turkish: Tom probably didn't think it was likely that Mary would fall in love with John.

[[Turkish#^tr-Q0923-answer|Compare the answer]]
^tr-Q0923

**tr-Q0924 · Explain the grammar**

Tom Mary'nin Tom'la evleneceğinin olası 【olduğunu】 muhtemelen düşünmedi.

Tom probably didn't think it was likely that Mary would fall in love with John.

[[Turkish#^tr-Q0924-answer|Compare the answer]]
^tr-Q0924

**tr-Q0925 · Fill the gap**

Tom ayrılmaya hazır ____ söyledi.

Tom said he's ready to leave.

[[Turkish#^tr-Q0925-answer|Compare the answer]]
^tr-Q0925

**tr-Q0926 · Choose the form**

Tom ayrılmaya hazır ____ söyledi.

Tom said he's ready to leave.

Choices: gelen / giden / olan / olduğunu

[[Turkish#^tr-Q0926-answer|Compare the answer]]
^tr-Q0926

**tr-Q0927 · Edit the changed sentence**

Biri nasıl Tom'un iyi bir patron 【olan】 düşünebilir?

How can anyone think that Tom is a good boss?

[[Turkish#^tr-Q0927-answer|Compare the answer]]
^tr-Q0927

**tr-Q0928 · Build the sentence**

Arrange: patron / bir / nasıl / düşünebilir? / iyi / olduğunu / Biri / Tom'un

How can anyone think that Tom is a good boss?

[[Turkish#^tr-Q0928-answer|Compare the answer]]
^tr-Q0928

**tr-Q0929 · Write a translation**

Write this in Turkish: I thought Tom had something to tell you.

[[Turkish#^tr-Q0929-answer|Compare the answer]]
^tr-Q0929

**tr-Q0930 · Explain the grammar**

Tom'un sana söyleyeceği bir şeyi 【olduğunu】 düşünüyordum.

I thought Tom had something to tell you.

[[Turkish#^tr-Q0930-answer|Compare the answer]]
^tr-Q0930

**tr-Q0931 · Fill the gap**

Tom onun doğru ____ biliyor.

Tom knows that's true.

[[Turkish#^tr-Q0931-answer|Compare the answer]]
^tr-Q0931

**tr-Q0932 · Choose the form**

Tom onun doğru ____ biliyor.

Tom knows that's true.

Choices: giden / gelen / olduğunu / olan

[[Turkish#^tr-Q0932-answer|Compare the answer]]
^tr-Q0932

**tr-Q0933 · Edit the changed sentence**

Tom ne 【olan】 görebildi.

Tom could see what was happening.

[[Turkish#^tr-Q0933-answer|Compare the answer]]
^tr-Q0933

**tr-Q0934 · Build the sentence**

Arrange: ne / Tom / görebildi. / olduğunu

Tom could see what was happening.

[[Turkish#^tr-Q0934-answer|Compare the answer]]
^tr-Q0934

**tr-Q0935 · Write a translation**

Write this in Turkish: Fadil isn't here. Do you know where he is?

[[Turkish#^tr-Q0935-answer|Compare the answer]]
^tr-Q0935

**tr-Q0936 · Explain the grammar**

Fadıl burada değil. Onun nerede 【olduğunu】 biliyor musun?

Fadil isn't here. Do you know where he is?

[[Turkish#^tr-Q0936-answer|Compare the answer]]
^tr-Q0936

**tr-Q0937 · Fill the gap**

Tom Mary'ye John'un yatakta hasta ____ söyledi.

Tom told Mary that John was sick in bed.

[[Turkish#^tr-Q0937-answer|Compare the answer]]
^tr-Q0937

**tr-Q0938 · Choose the form**

Tom Mary'ye John'un yatakta hasta ____ söyledi.

Tom told Mary that John was sick in bed.

Choices: gelen / olduğunu / giden / olan

[[Turkish#^tr-Q0938-answer|Compare the answer]]
^tr-Q0938

**tr-Q0939 · Edit the changed sentence**

Tom gururunu yutmak ve yardıma ihtiyacı 【olan】 itiraf etmek zorunda kaldı.

Tom had to swallow his pride and admit that he needed help.

[[Turkish#^tr-Q0939-answer|Compare the answer]]
^tr-Q0939

**tr-Q0940 · Build the sentence**

Arrange: yutmak / zorunda / Tom / gururunu / ve / olduğunu / ihtiyacı / yardıma / kaldı. / etmek / itiraf

Tom had to swallow his pride and admit that he needed help.

[[Turkish#^tr-Q0940-answer|Compare the answer]]
^tr-Q0940

**tr-Q0941 · Write a translation**

Write this in Turkish: I am going to a distant place, you don't want to ask where.

[[Turkish#^tr-Q0941-answer|Compare the answer]]
^tr-Q0941

**tr-Q0942 · Explain the grammar**

Nereye 【olduğunu】 sormak istemediğin uzak bir yere gidiyorum.

I am going to a distant place, you don't want to ask where.

[[Turkish#^tr-Q0942-answer|Compare the answer]]
^tr-Q0942

**tr-Q0943 · Fill the gap**

Bir seçeneğin ____ sanmıyorum.

I don't think you have a choice.

[[Turkish#^tr-Q0943-answer|Compare the answer]]
^tr-Q0943

**tr-Q0944 · Choose the form**

Bir seçeneğin ____ sanmıyorum.

I don't think you have a choice.

Choices: giden / olan / gelen / olduğunu

[[Turkish#^tr-Q0944-answer|Compare the answer]]
^tr-Q0944

**tr-Q0945 · Edit the changed sentence**

Ona ne 【olan】 bilmek istemezsiniz.

You don't want to know what happened to her.

[[Turkish#^tr-Q0945-answer|Compare the answer]]
^tr-Q0945

**tr-Q0946 · Build the sentence**

Arrange: olduğunu / Ona / bilmek / istemezsiniz. / ne

You don't want to know what happened to her.

[[Turkish#^tr-Q0946-answer|Compare the answer]]
^tr-Q0946

**tr-Q0947 · Write a translation**

Write this in Turkish: Tom doesn't know what's in there.

[[Turkish#^tr-Q0947-answer|Compare the answer]]
^tr-Q0947

**tr-Q0948 · Explain the grammar**

Tom orada ne 【olduğunu】 bilmiyor.

Tom doesn't know what's in there.

[[Turkish#^tr-Q0948-answer|Compare the answer]]
^tr-Q0948

**tr-Q0949 · Fill the gap**

Sadece bir şey yapmadan durmayacağım ve ne ____ görmeyeceğim.

I'm not just going to wait around and see what happens.

[[Turkish#^tr-Q0949-answer|Compare the answer]]
^tr-Q0949

**tr-Q0950 · Choose the form**

Sadece bir şey yapmadan durmayacağım ve ne ____ görmeyeceğim.

I'm not just going to wait around and see what happens.

Choices: gelen / olan / giden / olduğunu

[[Turkish#^tr-Q0950-answer|Compare the answer]]
^tr-Q0950


### Ability, necessity and courtesy · 50 questions

**tr-Q0951 · Edit the changed sentence**

【belki】 dürüst davran.

Please behave honestly.

[[Turkish#^tr-Q0951-answer|Compare the answer]]
^tr-Q0951

**tr-Q0952 · Build the sentence**

Arrange: Lütfen / davran. / dürüst

Please behave honestly.

[[Turkish#^tr-Q0952-answer|Compare the answer]]
^tr-Q0952

**tr-Q0953 · Write a translation**

Write this in Turkish: He is the most valuable player in our team.

[[Turkish#^tr-Q0953-answer|Compare the answer]]
^tr-Q0953

**tr-Q0954 · Explain the grammar**

O, takımımızdaki 【en】 değerli oyuncudur.

He is the most valuable player in our team.

[[Turkish#^tr-Q0954-answer|Compare the answer]]
^tr-Q0954

**tr-Q0955 · Fill the gap**

Japonca, İngilizceden ____ zordur.

Japanese is harder than English.

[[Turkish#^tr-Q0955-answer|Compare the answer]]
^tr-Q0955

**tr-Q0956 · Choose the form**

Japonca, İngilizceden ____ zordur.

Japanese is harder than English.

Choices: belki / lütfen / daha / gerek

[[Turkish#^tr-Q0956-answer|Compare the answer]]
^tr-Q0956

**tr-Q0957 · Edit the changed sentence**

Tavuğun 【lütfen】 sevdiğin kısmı hangisi?

What's your favorite part of the chicken?

[[Turkish#^tr-Q0957-answer|Compare the answer]]
^tr-Q0957

**tr-Q0958 · Build the sentence**

Arrange: hangisi? / sevdiğin / Tavuğun / en / kısmı

What's your favorite part of the chicken?

[[Turkish#^tr-Q0958-answer|Compare the answer]]
^tr-Q0958

**tr-Q0959 · Write a translation**

Write this in Turkish: We have bigger problems.

[[Turkish#^tr-Q0959-answer|Compare the answer]]
^tr-Q0959

**tr-Q0960 · Explain the grammar**

【Daha】 büyük sorunlarımız var.

We have bigger problems.

[[Turkish#^tr-Q0960-answer|Compare the answer]]
^tr-Q0960

**tr-Q0961 · Fill the gap**

____ ayrıntılı bir haritaya ihtiyacım var.

I need a more detailed map.

[[Turkish#^tr-Q0961-answer|Compare the answer]]
^tr-Q0961

**tr-Q0962 · Choose the form**

____ ayrıntılı bir haritaya ihtiyacım var.

I need a more detailed map.

Choices: Daha / lütfen / belki / gerek

[[Turkish#^tr-Q0962-answer|Compare the answer]]
^tr-Q0962

**tr-Q0963 · Edit the changed sentence**

Tom kilo vermede Mary'den 【lütfen】 başarılıydı.

Tom has been more successful at losing weight than Mary.

[[Turkish#^tr-Q0963-answer|Compare the answer]]
^tr-Q0963

**tr-Q0964 · Build the sentence**

Arrange: başarılıydı. / vermede / daha / kilo / Mary'den / Tom

Tom has been more successful at losing weight than Mary.

[[Turkish#^tr-Q0964-answer|Compare the answer]]
^tr-Q0964

**tr-Q0965 · Write a translation**

Write this in Turkish: This is better than expected.

[[Turkish#^tr-Q0965-answer|Compare the answer]]
^tr-Q0965

**tr-Q0966 · Explain the grammar**

Bu beklenenden 【daha】 iyi.

This is better than expected.

[[Turkish#^tr-Q0966-answer|Compare the answer]]
^tr-Q0966

**tr-Q0967 · Fill the gap**

____ onu nasıl yapmam gerektiğini bana göster.

Please show me how I have to do it.

[[Turkish#^tr-Q0967-answer|Compare the answer]]
^tr-Q0967

**tr-Q0968 · Choose the form**

____ onu nasıl yapmam gerektiğini bana göster.

Please show me how I have to do it.

Choices: lazım / Lütfen / belki / gerek

[[Turkish#^tr-Q0968-answer|Compare the answer]]
^tr-Q0968

**tr-Q0969 · Edit the changed sentence**

Sanırım Tom ondan 【lütfen】 akıllı.

I think Tom is smarter than that.

[[Turkish#^tr-Q0969-answer|Compare the answer]]
^tr-Q0969

**tr-Q0970 · Build the sentence**

Arrange: daha / Sanırım / akıllı. / ondan / Tom

I think Tom is smarter than that.

[[Turkish#^tr-Q0970-answer|Compare the answer]]
^tr-Q0970

**tr-Q0971 · Write a translation**

Write this in Turkish: Two more beers, please!

[[Turkish#^tr-Q0971-answer|Compare the answer]]
^tr-Q0971

**tr-Q0972 · Explain the grammar**

İki bira 【daha】 lütfen!

Two more beers, please!

[[Turkish#^tr-Q0972-answer|Compare the answer]]
^tr-Q0972

**tr-Q0973 · Fill the gap**

____ benim için not alın.

Please take a message for me.

[[Turkish#^tr-Q0973-answer|Compare the answer]]
^tr-Q0973

**tr-Q0974 · Choose the form**

____ benim için not alın.

Please take a message for me.

Choices: gerek / lazım / Lütfen / belki

[[Turkish#^tr-Q0974-answer|Compare the answer]]
^tr-Q0974

**tr-Q0975 · Edit the changed sentence**

Sanırım itiraf etmek istediğinden 【lütfen】 iyi zaman geçiriyorsun.

I think you're having a better time than you want to admit.

[[Turkish#^tr-Q0975-answer|Compare the answer]]
^tr-Q0975

**tr-Q0976 · Build the sentence**

Arrange: Sanırım / itiraf / istediğinden / zaman / geçiriyorsun. / etmek / daha / iyi

I think you're having a better time than you want to admit.

[[Turkish#^tr-Q0976-answer|Compare the answer]]
^tr-Q0976

**tr-Q0977 · Write a translation**

Write this in Turkish: I'll tell him so then.

[[Turkish#^tr-Q0977-answer|Compare the answer]]
^tr-Q0977

**tr-Q0978 · Explain the grammar**

Ben ona 【daha】 sonra söylerim.

I'll tell him so then.

[[Turkish#^tr-Q0978-answer|Compare the answer]]
^tr-Q0978

**tr-Q0979 · Fill the gap**

Herkes hayatları boyunca ____ az bir kere aşık olur.

Everybody falls in love at least once in their lives.

[[Turkish#^tr-Q0979-answer|Compare the answer]]
^tr-Q0979

**tr-Q0980 · Choose the form**

Herkes hayatları boyunca ____ az bir kere aşık olur.

Everybody falls in love at least once in their lives.

Choices: en / gerek / belki / lütfen

[[Turkish#^tr-Q0980-answer|Compare the answer]]
^tr-Q0980

**tr-Q0981 · Edit the changed sentence**

Bundan 【lütfen】 büyük bir köpek yoktur.

There is no dog which is bigger than this one.

[[Turkish#^tr-Q0981-answer|Compare the answer]]
^tr-Q0981

**tr-Q0982 · Build the sentence**

Arrange: köpek / bir / daha / büyük / yoktur. / Bundan

There is no dog which is bigger than this one.

[[Turkish#^tr-Q0982-answer|Compare the answer]]
^tr-Q0982

**tr-Q0983 · Write a translation**

Write this in Turkish: We can't afford to spend any more time waiting for Tom.

[[Turkish#^tr-Q0983-answer|Compare the answer]]
^tr-Q0983

**tr-Q0984 · Explain the grammar**

Tom'u beklemek için 【daha】 fazla zaman harcayamayız.

We can't afford to spend any more time waiting for Tom.

[[Turkish#^tr-Q0984-answer|Compare the answer]]
^tr-Q0984

**tr-Q0985 · Fill the gap**

Tom'un ____ büyük oğlu, tam anlamıyla kendisine benziyor.

Tom's oldest son looks just like him.

[[Turkish#^tr-Q0985-answer|Compare the answer]]
^tr-Q0985

**tr-Q0986 · Choose the form**

Tom'un ____ büyük oğlu, tam anlamıyla kendisine benziyor.

Tom's oldest son looks just like him.

Choices: gerek / belki / lütfen / en

[[Turkish#^tr-Q0986-answer|Compare the answer]]
^tr-Q0986

**tr-Q0987 · Edit the changed sentence**

【lütfen】 kısa sürede seni alacağız.

We'll pick you up as soon as we can.

[[Turkish#^tr-Q0987-answer|Compare the answer]]
^tr-Q0987

**tr-Q0988 · Build the sentence**

Arrange: seni / alacağız. / sürede / En / kısa

We'll pick you up as soon as we can.

[[Turkish#^tr-Q0988-answer|Compare the answer]]
^tr-Q0988

**tr-Q0989 · Write a translation**

Write this in Turkish: People should sleep at least 7 hours each night.

[[Turkish#^tr-Q0989-answer|Compare the answer]]
^tr-Q0989

**tr-Q0990 · Explain the grammar**

İnsanların her gece 【en】 az 7 saat uyumaları gerekir.

People should sleep at least 7 hours each night.

[[Turkish#^tr-Q0990-answer|Compare the answer]]
^tr-Q0990

**tr-Q0991 · Fill the gap**

Hemen hareket etmen gerekiyor; ____ sonra çok geç olacak.

You need to act immediately; later will be too late.

[[Turkish#^tr-Q0991-answer|Compare the answer]]
^tr-Q0991

**tr-Q0992 · Choose the form**

Hemen hareket etmen gerekiyor; ____ sonra çok geç olacak.

You need to act immediately; later will be too late.

Choices: gerek / belki / daha / lütfen

[[Turkish#^tr-Q0992-answer|Compare the answer]]
^tr-Q0992

**tr-Q0993 · Edit the changed sentence**

Bol buzlu viski, 【belki】.

On the rocks, please.

[[Turkish#^tr-Q0993-answer|Compare the answer]]
^tr-Q0993

**tr-Q0994 · Build the sentence**

Arrange: viski, / Bol / buzlu / lütfen.

On the rocks, please.

[[Turkish#^tr-Q0994-answer|Compare the answer]]
^tr-Q0994

**tr-Q0995 · Write a translation**

Write this in Turkish: Take this seat, please.

[[Turkish#^tr-Q0995-answer|Compare the answer]]
^tr-Q0995

**tr-Q0996 · Explain the grammar**

【Lütfen】 buraya oturun.

Take this seat, please.

[[Turkish#^tr-Q0996-answer|Compare the answer]]
^tr-Q0996

**tr-Q0997 · Fill the gap**

Tamam. ____ onları sipariş edin.

All right. Please order them.

[[Turkish#^tr-Q0997-answer|Compare the answer]]
^tr-Q0997

**tr-Q0998 · Choose the form**

Tamam. ____ onları sipariş edin.

All right. Please order them.

Choices: gerek / Lütfen / belki / lazım

[[Turkish#^tr-Q0998-answer|Compare the answer]]
^tr-Q0998

**tr-Q0999 · Edit the changed sentence**

Bambular gezegendeki 【lütfen】 hızlı büyüyen bitkilerden biridir.

Bamboos are one of the fastest growing plants on the planet.

[[Turkish#^tr-Q0999-answer|Compare the answer]]
^tr-Q0999

**tr-Q1000 · Build the sentence**

Arrange: bitkilerden / hızlı / biridir. / gezegendeki / büyüyen / Bambular / en

Bamboos are one of the fastest growing plants on the planet.

[[Turkish#^tr-Q1000-answer|Compare the answer]]
^tr-Q1000


## Answers

The full sentence is a model. For translation, judge whether meaning and grammar are preserved. Each grammar rule above explains the form.

### Answers 1–50

**tr-Q0001** — O, ekmeği yedi.

She ate the bread.

Expected form: **O**

Why: Pronouns. [[Turkish#^tr-Q0001|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=O%2C%20ekme%C4%9Fi%20yedi.)
^tr-Q0001-answer

**tr-Q0002** — O, ekmeği yedi.

She ate the bread.

Expected form: **O**

Why: Pronouns. [[Turkish#^tr-Q0002|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=O%2C%20ekme%C4%9Fi%20yedi.)
^tr-Q0002-answer

**tr-Q0003** — Ben McDonald's'ta için çalışıyorum.

I work for McDonald's.

Expected form: **Ben**

Why: Pronouns. [[Turkish#^tr-Q0003|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ben%20McDonald%27s%27ta%20i%C3%A7in%20%C3%A7al%C4%B1%C5%9F%C4%B1yorum.)
^tr-Q0003-answer

**tr-Q0004** — Ben McDonald's'ta için çalışıyorum.

I work for McDonald's.

Why: Pronouns. [[Turkish#^tr-Q0004|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ben%20McDonald%27s%27ta%20i%C3%A7in%20%C3%A7al%C4%B1%C5%9F%C4%B1yorum.)
^tr-Q0004-answer

**tr-Q0005** — Boston'da yaşayan tek Kanadalı ben değilim.

I'm not the only Canadian living in Boston.

Why: Pronouns. [[Turkish#^tr-Q0005|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Boston%27da%20ya%C5%9Fayan%20tek%20Kanadal%C4%B1%20ben%20de%C4%9Filim.)
^tr-Q0005-answer

**tr-Q0006** — Boston'da yaşayan tek Kanadalı ben değilim.

I'm not the only Canadian living in Boston.

Subject pronouns can be omitted when verbal endings identify the subject. O does not distinguish he/she/it. Case suffixes create object and other pronoun forms with some irregular stems.

Why: Pronouns. [[Turkish#^tr-Q0006|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Boston%27da%20ya%C5%9Fayan%20tek%20Kanadal%C4%B1%20ben%20de%C4%9Filim.)
^tr-Q0006-answer

**tr-Q0007** — Bunu ben yapacağım.

I'm going to make it.

Expected form: **ben**

Why: Pronouns. [[Turkish#^tr-Q0007|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bunu%20ben%20yapaca%C4%9F%C4%B1m.)
^tr-Q0007-answer

**tr-Q0008** — Bunu ben yapacağım.

I'm going to make it.

Expected form: **ben**

Why: Pronouns. [[Turkish#^tr-Q0008|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bunu%20ben%20yapaca%C4%9F%C4%B1m.)
^tr-Q0008-answer

**tr-Q0009** — O Tom için kötü sona erdi.

It ended badly for Tom.

Expected form: **O**

Why: Pronouns. [[Turkish#^tr-Q0009|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=O%20Tom%20i%C3%A7in%20k%C3%B6t%C3%BC%20sona%20erdi.)
^tr-Q0009-answer

**tr-Q0010** — O Tom için kötü sona erdi.

It ended badly for Tom.

Why: Pronouns. [[Turkish#^tr-Q0010|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=O%20Tom%20i%C3%A7in%20k%C3%B6t%C3%BC%20sona%20erdi.)
^tr-Q0010-answer

**tr-Q0011** — Tom, siz arkadaşların Mary'ye yardım etmene izin vermeyecek.

Tom won't let you guys help Mary.

Why: Pronouns. [[Turkish#^tr-Q0011|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%2C%20siz%20arkada%C5%9Flar%C4%B1n%20Mary%27ye%20yard%C4%B1m%20etmene%20izin%20vermeyecek.)
^tr-Q0011-answer

**tr-Q0012** — Tom, siz arkadaşların Mary'ye yardım etmene izin vermeyecek.

Tom won't let you guys help Mary.

Subject pronouns can be omitted when verbal endings identify the subject. O does not distinguish he/she/it. Case suffixes create object and other pronoun forms with some irregular stems.

Why: Pronouns. [[Turkish#^tr-Q0012|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%2C%20siz%20arkada%C5%9Flar%C4%B1n%20Mary%27ye%20yard%C4%B1m%20etmene%20izin%20vermeyecek.)
^tr-Q0012-answer

**tr-Q0013** — Ben senin sorununun farkındayım.

I'm aware of your problem.

Expected form: **Ben**

Why: Pronouns. [[Turkish#^tr-Q0013|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ben%20senin%20sorununun%20fark%C4%B1nday%C4%B1m.)
^tr-Q0013-answer

**tr-Q0014** — Ben senin sorununun farkındayım.

I'm aware of your problem.

Expected form: **Ben**

Why: Pronouns. [[Turkish#^tr-Q0014|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ben%20senin%20sorununun%20fark%C4%B1nday%C4%B1m.)
^tr-Q0014-answer

**tr-Q0015** — Yıllardır o kadar uzağa yürümedim.

I haven't walked that far in years.

Expected form: **o**

Why: Pronouns. [[Turkish#^tr-Q0015|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Y%C4%B1llard%C4%B1r%20o%20kadar%20uza%C4%9Fa%20y%C3%BCr%C3%BCmedim.)
^tr-Q0015-answer

**tr-Q0016** — Yıllardır o kadar uzağa yürümedim.

I haven't walked that far in years.

Why: Pronouns. [[Turkish#^tr-Q0016|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Y%C4%B1llard%C4%B1r%20o%20kadar%20uza%C4%9Fa%20y%C3%BCr%C3%BCmedim.)
^tr-Q0016-answer

**tr-Q0017** — Ben eve giderken süpermarkette durdum.

I stopped at the supermarket on my way home.

Why: Pronouns. [[Turkish#^tr-Q0017|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ben%20eve%20giderken%20s%C3%BCpermarkette%20durdum.)
^tr-Q0017-answer

**tr-Q0018** — Ben eve giderken süpermarkette durdum.

I stopped at the supermarket on my way home.

Subject pronouns can be omitted when verbal endings identify the subject. O does not distinguish he/she/it. Case suffixes create object and other pronoun forms with some irregular stems.

Why: Pronouns. [[Turkish#^tr-Q0018|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ben%20eve%20giderken%20s%C3%BCpermarkette%20durdum.)
^tr-Q0018-answer

**tr-Q0019** — O bir kelime değil.

That's not a word.

Expected form: **O**

Why: Pronouns. [[Turkish#^tr-Q0019|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=O%20bir%20kelime%20de%C4%9Fil.)
^tr-Q0019-answer

**tr-Q0020** — O bir kelime değil.

That's not a word.

Expected form: **O**

Why: Pronouns. [[Turkish#^tr-Q0020|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=O%20bir%20kelime%20de%C4%9Fil.)
^tr-Q0020-answer

**tr-Q0021** — Ben küçük bir aileden geliyorum.

I come from a small family.

Expected form: **Ben**

Why: Pronouns. [[Turkish#^tr-Q0021|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ben%20k%C3%BC%C3%A7%C3%BCk%20bir%20aileden%20geliyorum.)
^tr-Q0021-answer

**tr-Q0022** — Ben küçük bir aileden geliyorum.

I come from a small family.

Why: Pronouns. [[Turkish#^tr-Q0022|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ben%20k%C3%BC%C3%A7%C3%BCk%20bir%20aileden%20geliyorum.)
^tr-Q0022-answer

**tr-Q0023** — Sen başka bir kek dilimi mi istiyorsun?

You want another slice of cake?

Why: Pronouns. [[Turkish#^tr-Q0023|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Sen%20ba%C5%9Fka%20bir%20kek%20dilimi%20mi%20istiyorsun%3F)
^tr-Q0023-answer

**tr-Q0024** — Sen başka bir kek dilimi mi istiyorsun?

You want another slice of cake?

Subject pronouns can be omitted when verbal endings identify the subject. O does not distinguish he/she/it. Case suffixes create object and other pronoun forms with some irregular stems.

Why: Pronouns. [[Turkish#^tr-Q0024|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Sen%20ba%C5%9Fka%20bir%20kek%20dilimi%20mi%20istiyorsun%3F)
^tr-Q0024-answer

**tr-Q0025** — O, okula kadar çocuklara refakat edecek.

He will accompany the children to school.

Expected form: **O**

Why: Pronouns. [[Turkish#^tr-Q0025|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=O%2C%20okula%20kadar%20%C3%A7ocuklara%20refakat%20edecek.)
^tr-Q0025-answer

**tr-Q0026** — O, okula kadar çocuklara refakat edecek.

He will accompany the children to school.

Expected form: **O**

Why: Pronouns. [[Turkish#^tr-Q0026|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=O%2C%20okula%20kadar%20%C3%A7ocuklara%20refakat%20edecek.)
^tr-Q0026-answer

**tr-Q0027** — Sen savını meşrulaştırabilir misin?

Can you justify your claim?

Expected form: **Sen**

Why: Pronouns. [[Turkish#^tr-Q0027|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Sen%20sav%C4%B1n%C4%B1%20me%C5%9Frula%C5%9Ft%C4%B1rabilir%20misin%3F)
^tr-Q0027-answer

**tr-Q0028** — Sen savını meşrulaştırabilir misin?

Can you justify your claim?

Why: Pronouns. [[Turkish#^tr-Q0028|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Sen%20sav%C4%B1n%C4%B1%20me%C5%9Frula%C5%9Ft%C4%B1rabilir%20misin%3F)
^tr-Q0028-answer

**tr-Q0029** — O, kısa bir süre o bölgede kaldı.

She stayed in that area for a short while.

Why: Pronouns. [[Turkish#^tr-Q0029|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=O%2C%20k%C4%B1sa%20bir%20s%C3%BCre%20o%20b%C3%B6lgede%20kald%C4%B1.)
^tr-Q0029-answer

**tr-Q0030** — O, kısa bir süre o bölgede kaldı.

She stayed in that area for a short while.

Subject pronouns can be omitted when verbal endings identify the subject. O does not distinguish he/she/it. Case suffixes create object and other pronoun forms with some irregular stems.

Why: Pronouns. [[Turkish#^tr-Q0030|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=O%2C%20k%C4%B1sa%20bir%20s%C3%BCre%20o%20b%C3%B6lgede%20kald%C4%B1.)
^tr-Q0030-answer

**tr-Q0031** — Ben kahve, tost ve jöle istiyorum.

I want coffee, toast, and jelly.

Expected form: **Ben**

Why: Pronouns. [[Turkish#^tr-Q0031|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ben%20kahve%2C%20tost%20ve%20j%C3%B6le%20istiyorum.)
^tr-Q0031-answer

**tr-Q0032** — Ben kahve, tost ve jöle istiyorum.

I want coffee, toast, and jelly.

Expected form: **Ben**

Why: Pronouns. [[Turkish#^tr-Q0032|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ben%20kahve%2C%20tost%20ve%20j%C3%B6le%20istiyorum.)
^tr-Q0032-answer

**tr-Q0033** — Biz çiçeği sulamalıyız.

We must water the flower.

Expected form: **Biz**

Why: Pronouns. [[Turkish#^tr-Q0033|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Biz%20%C3%A7i%C3%A7e%C4%9Fi%20sulamal%C4%B1y%C4%B1z.)
^tr-Q0033-answer

**tr-Q0034** — Biz çiçeği sulamalıyız.

We must water the flower.

Why: Pronouns. [[Turkish#^tr-Q0034|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Biz%20%C3%A7i%C3%A7e%C4%9Fi%20sulamal%C4%B1y%C4%B1z.)
^tr-Q0034-answer

**tr-Q0035** — Şartlar o kadar kolay değil.

Things are not that simple.

Why: Pronouns. [[Turkish#^tr-Q0035|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=%C5%9Eartlar%20o%20kadar%20kolay%20de%C4%9Fil.)
^tr-Q0035-answer

**tr-Q0036** — Şartlar o kadar kolay değil.

Things are not that simple.

Subject pronouns can be omitted when verbal endings identify the subject. O does not distinguish he/she/it. Case suffixes create object and other pronoun forms with some irregular stems.

Why: Pronouns. [[Turkish#^tr-Q0036|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=%C5%9Eartlar%20o%20kadar%20kolay%20de%C4%9Fil.)
^tr-Q0036-answer

**tr-Q0037** — Ben o fedakarlığı yapmaya hazırım.

I'm willing to make that sacrifice.

Expected form: **Ben**

Why: Pronouns. [[Turkish#^tr-Q0037|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ben%20o%20fedakarl%C4%B1%C4%9F%C4%B1%20yapmaya%20haz%C4%B1r%C4%B1m.)
^tr-Q0037-answer

**tr-Q0038** — Ben o fedakarlığı yapmaya hazırım.

I'm willing to make that sacrifice.

Expected form: **Ben**

Why: Pronouns. [[Turkish#^tr-Q0038|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ben%20o%20fedakarl%C4%B1%C4%9F%C4%B1%20yapmaya%20haz%C4%B1r%C4%B1m.)
^tr-Q0038-answer

**tr-Q0039** — O zarfı kim verdi sana?

Who gave that envelope to you?

Expected form: **O**

Why: Pronouns. [[Turkish#^tr-Q0039|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=O%20zarf%C4%B1%20kim%20verdi%20sana%3F)
^tr-Q0039-answer

**tr-Q0040** — O zarfı kim verdi sana?

Who gave that envelope to you?

Why: Pronouns. [[Turkish#^tr-Q0040|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=O%20zarf%C4%B1%20kim%20verdi%20sana%3F)
^tr-Q0040-answer

**tr-Q0041** — O, uygun bir fiyatlı gibi görünüyor.

That seems like an affordable price.

Why: Pronouns. [[Turkish#^tr-Q0041|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=O%2C%20uygun%20bir%20fiyatl%C4%B1%20gibi%20g%C3%B6r%C3%BCn%C3%BCyor.)
^tr-Q0041-answer

**tr-Q0042** — O, uygun bir fiyatlı gibi görünüyor.

That seems like an affordable price.

Subject pronouns can be omitted when verbal endings identify the subject. O does not distinguish he/she/it. Case suffixes create object and other pronoun forms with some irregular stems.

Why: Pronouns. [[Turkish#^tr-Q0042|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=O%2C%20uygun%20bir%20fiyatl%C4%B1%20gibi%20g%C3%B6r%C3%BCn%C3%BCyor.)
^tr-Q0042-answer

**tr-Q0043** — Sami, haziran 2006'da o birime taşındı.

Sami moved to that unit in June, 2006.

Expected form: **o**

Why: Pronouns. [[Turkish#^tr-Q0043|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Sami%2C%20haziran%202006%27da%20o%20birime%20ta%C5%9F%C4%B1nd%C4%B1.)
^tr-Q0043-answer

**tr-Q0044** — Sami, haziran 2006'da o birime taşındı.

Sami moved to that unit in June, 2006.

Expected form: **o**

Why: Pronouns. [[Turkish#^tr-Q0044|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Sami%2C%20haziran%202006%27da%20o%20birime%20ta%C5%9F%C4%B1nd%C4%B1.)
^tr-Q0044-answer

**tr-Q0045** — Çünkü o ilginç ve güzel bir şehirdir?

Because it is an interesting and beautiful city?

Expected form: **o**

Why: Pronouns. [[Turkish#^tr-Q0045|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=%C3%87%C3%BCnk%C3%BC%20o%20ilgin%C3%A7%20ve%20g%C3%BCzel%20bir%20%C5%9Fehirdir%3F)
^tr-Q0045-answer

**tr-Q0046** — Çünkü o ilginç ve güzel bir şehirdir?

Because it is an interesting and beautiful city?

Why: Pronouns. [[Turkish#^tr-Q0046|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=%C3%87%C3%BCnk%C3%BC%20o%20ilgin%C3%A7%20ve%20g%C3%BCzel%20bir%20%C5%9Fehirdir%3F)
^tr-Q0046-answer

**tr-Q0047** — Ben sadece Tom'u terk edemem.

I can't just leave Tom.

Why: Pronouns. [[Turkish#^tr-Q0047|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ben%20sadece%20Tom%27u%20terk%20edemem.)
^tr-Q0047-answer

**tr-Q0048** — Ben sadece Tom'u terk edemem.

I can't just leave Tom.

Subject pronouns can be omitted when verbal endings identify the subject. O does not distinguish he/she/it. Case suffixes create object and other pronoun forms with some irregular stems.

Why: Pronouns. [[Turkish#^tr-Q0048|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ben%20sadece%20Tom%27u%20terk%20edemem.)
^tr-Q0048-answer

**tr-Q0049** — O bir aktris olmak istiyor.

She wants to be an actress.

Expected form: **O**

Why: Pronouns. [[Turkish#^tr-Q0049|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=O%20bir%20aktris%20olmak%20istiyor.)
^tr-Q0049-answer

**tr-Q0050** — O bir aktris olmak istiyor.

She wants to be an actress.

Expected form: **O**

Why: Pronouns. [[Turkish#^tr-Q0050|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=O%20bir%20aktris%20olmak%20istiyor.)
^tr-Q0050-answer


### Answers 51–100

**tr-Q0051** — Neden herkes için yeterli yiyeceğimiz yok ? Bu öğleden sonra alışverişe gittiğinizi sanıyordum.

Why don't we have enough food for everyone? I thought you went shopping this afternoon.

Expected form: **Bu**

Why: Demonstratives. [[Turkish#^tr-Q0051|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Neden%20herkes%20i%C3%A7in%20yeterli%20yiyece%C4%9Fimiz%20yok%20%3F%20Bu%20%C3%B6%C4%9Fleden%20sonra%20al%C4%B1%C5%9Fveri%C5%9Fe%20gitti%C4%9Finizi%20san%C4%B1yordum.)
^tr-Q0051-answer

**tr-Q0052** — Neden herkes için yeterli yiyeceğimiz yok ? Bu öğleden sonra alışverişe gittiğinizi sanıyordum.

Why don't we have enough food for everyone? I thought you went shopping this afternoon.

Why: Demonstratives. [[Turkish#^tr-Q0052|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Neden%20herkes%20i%C3%A7in%20yeterli%20yiyece%C4%9Fimiz%20yok%20%3F%20Bu%20%C3%B6%C4%9Fleden%20sonra%20al%C4%B1%C5%9Fveri%C5%9Fe%20gitti%C4%9Finizi%20san%C4%B1yordum.)
^tr-Q0052-answer

**tr-Q0053** — Bu işi yapabiliriz.

We can make this work.

Why: Demonstratives. [[Turkish#^tr-Q0053|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bu%20i%C5%9Fi%20yapabiliriz.)
^tr-Q0053-answer

**tr-Q0054** — Bu işi yapabiliriz.

We can make this work.

Bu/şu/o encode distinctions of reference and distance. Their pronoun inflections use a buffer n in relevant forms. Context, not English this/that alone, determines the best choice.

Why: Demonstratives. [[Turkish#^tr-Q0054|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bu%20i%C5%9Fi%20yapabiliriz.)
^tr-Q0054-answer

**tr-Q0055** — Bu, bu bölgede bugüne kadar en iyi deniz ürünleri restoranıdır.

This is by far the best seafood restaurant in this area.

Expected form: **Bu**

Why: Demonstratives. [[Turkish#^tr-Q0055|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bu%2C%20bu%20b%C3%B6lgede%20bug%C3%BCne%20kadar%20en%20iyi%20deniz%20%C3%BCr%C3%BCnleri%20restoran%C4%B1d%C4%B1r.)
^tr-Q0055-answer

**tr-Q0056** — Bu, bu bölgede bugüne kadar en iyi deniz ürünleri restoranıdır.

This is by far the best seafood restaurant in this area.

Expected form: **Bu**

Why: Demonstratives. [[Turkish#^tr-Q0056|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bu%2C%20bu%20b%C3%B6lgede%20bug%C3%BCne%20kadar%20en%20iyi%20deniz%20%C3%BCr%C3%BCnleri%20restoran%C4%B1d%C4%B1r.)
^tr-Q0056-answer

**tr-Q0057** — Bu arabayı satın alayım!

Let me buy this car!

Expected form: **Bu**

Why: Demonstratives. [[Turkish#^tr-Q0057|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bu%20arabay%C4%B1%20sat%C4%B1n%20alay%C4%B1m%21)
^tr-Q0057-answer

**tr-Q0058** — Bu arabayı satın alayım!

Let me buy this car!

Why: Demonstratives. [[Turkish#^tr-Q0058|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bu%20arabay%C4%B1%20sat%C4%B1n%20alay%C4%B1m%21)
^tr-Q0058-answer

**tr-Q0059** — Bu kolayca kanıtlanabilir.

This can be easily proven.

Why: Demonstratives. [[Turkish#^tr-Q0059|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bu%20kolayca%20kan%C4%B1tlanabilir.)
^tr-Q0059-answer

**tr-Q0060** — Bu kolayca kanıtlanabilir.

This can be easily proven.

Bu/şu/o encode distinctions of reference and distance. Their pronoun inflections use a buffer n in relevant forms. Context, not English this/that alone, determines the best choice.

Why: Demonstratives. [[Turkish#^tr-Q0060|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bu%20kolayca%20kan%C4%B1tlanabilir.)
^tr-Q0060-answer

**tr-Q0061** — Bu yaz günü çok çabuk bitecek!

This summer's day will be over all too soon!

Expected form: **Bu**

Why: Demonstratives. [[Turkish#^tr-Q0061|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bu%20yaz%20g%C3%BCn%C3%BC%20%C3%A7ok%20%C3%A7abuk%20bitecek%21)
^tr-Q0061-answer

**tr-Q0062** — Bu yaz günü çok çabuk bitecek!

This summer's day will be over all too soon!

Expected form: **Bu**

Why: Demonstratives. [[Turkish#^tr-Q0062|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bu%20yaz%20g%C3%BCn%C3%BC%20%C3%A7ok%20%C3%A7abuk%20bitecek%21)
^tr-Q0062-answer

**tr-Q0063** — Bu yeri benim için harita üzerinde bulabilir misin?

Can you locate this place on the map for me?

Expected form: **Bu**

Why: Demonstratives. [[Turkish#^tr-Q0063|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bu%20yeri%20benim%20i%C3%A7in%20harita%20%C3%BCzerinde%20bulabilir%20misin%3F)
^tr-Q0063-answer

**tr-Q0064** — Bu yeri benim için harita üzerinde bulabilir misin?

Can you locate this place on the map for me?

Why: Demonstratives. [[Turkish#^tr-Q0064|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bu%20yeri%20benim%20i%C3%A7in%20harita%20%C3%BCzerinde%20bulabilir%20misin%3F)
^tr-Q0064-answer

**tr-Q0065** — Bu mektubu yazdım.

I wrote this letter.

Why: Demonstratives. [[Turkish#^tr-Q0065|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bu%20mektubu%20yazd%C4%B1m.)
^tr-Q0065-answer

**tr-Q0066** — Bu mektubu yazdım.

I wrote this letter.

Bu/şu/o encode distinctions of reference and distance. Their pronoun inflections use a buffer n in relevant forms. Context, not English this/that alone, determines the best choice.

Why: Demonstratives. [[Turkish#^tr-Q0066|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bu%20mektubu%20yazd%C4%B1m.)
^tr-Q0066-answer

**tr-Q0067** — Bu sabah bir baş ağrısı ile uyandım.

I woke up with a headache this morning.

Expected form: **Bu**

Why: Demonstratives. [[Turkish#^tr-Q0067|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bu%20sabah%20bir%20ba%C5%9F%20a%C4%9Fr%C4%B1s%C4%B1%20ile%20uyand%C4%B1m.)
^tr-Q0067-answer

**tr-Q0068** — Bu sabah bir baş ağrısı ile uyandım.

I woke up with a headache this morning.

Expected form: **Bu**

Why: Demonstratives. [[Turkish#^tr-Q0068|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bu%20sabah%20bir%20ba%C5%9F%20a%C4%9Fr%C4%B1s%C4%B1%20ile%20uyand%C4%B1m.)
^tr-Q0068-answer

**tr-Q0069** — Biz o veriye sahip değiliz.

We don't have that data.

Expected form: **o**

Why: Demonstratives. [[Turkish#^tr-Q0069|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Biz%20o%20veriye%20sahip%20de%C4%9Filiz.)
^tr-Q0069-answer

**tr-Q0070** — Biz o veriye sahip değiliz.

We don't have that data.

Why: Demonstratives. [[Turkish#^tr-Q0070|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Biz%20o%20veriye%20sahip%20de%C4%9Filiz.)
^tr-Q0070-answer

**tr-Q0071** — Bu İspanyolca değil.

This isn't Spanish.

Why: Demonstratives. [[Turkish#^tr-Q0071|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bu%20%C4%B0spanyolca%20de%C4%9Fil.)
^tr-Q0071-answer

**tr-Q0072** — Bu İspanyolca değil.

This isn't Spanish.

Bu/şu/o encode distinctions of reference and distance. Their pronoun inflections use a buffer n in relevant forms. Context, not English this/that alone, determines the best choice.

Why: Demonstratives. [[Turkish#^tr-Q0072|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bu%20%C4%B0spanyolca%20de%C4%9Fil.)
^tr-Q0072-answer

**tr-Q0073** — Bu plaj sörfçüler için bir cennettir.

This beach is a paradise for surfers.

Expected form: **Bu**

Why: Demonstratives. [[Turkish#^tr-Q0073|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bu%20plaj%20s%C3%B6rf%C3%A7%C3%BCler%20i%C3%A7in%20bir%20cennettir.)
^tr-Q0073-answer

**tr-Q0074** — Bu plaj sörfçüler için bir cennettir.

This beach is a paradise for surfers.

Expected form: **Bu**

Why: Demonstratives. [[Turkish#^tr-Q0074|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bu%20plaj%20s%C3%B6rf%C3%A7%C3%BCler%20i%C3%A7in%20bir%20cennettir.)
^tr-Q0074-answer

**tr-Q0075** — O, yapmak için mantıklı bir şey.

That's the logical thing to do.

Expected form: **O**

Why: Demonstratives. [[Turkish#^tr-Q0075|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=O%2C%20yapmak%20i%C3%A7in%20mant%C4%B1kl%C4%B1%20bir%20%C5%9Fey.)
^tr-Q0075-answer

**tr-Q0076** — O, yapmak için mantıklı bir şey.

That's the logical thing to do.

Why: Demonstratives. [[Turkish#^tr-Q0076|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=O%2C%20yapmak%20i%C3%A7in%20mant%C4%B1kl%C4%B1%20bir%20%C5%9Fey.)
^tr-Q0076-answer

**tr-Q0077** — Tom'un söylediği bu kadar.

That's all Tom said.

Why: Demonstratives. [[Turkish#^tr-Q0077|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%27un%20s%C3%B6yledi%C4%9Fi%20bu%20kadar.)
^tr-Q0077-answer

**tr-Q0078** — Tom'un söylediği bu kadar.

That's all Tom said.

Bu/şu/o encode distinctions of reference and distance. Their pronoun inflections use a buffer n in relevant forms. Context, not English this/that alone, determines the best choice.

Why: Demonstratives. [[Turkish#^tr-Q0078|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%27un%20s%C3%B6yledi%C4%9Fi%20bu%20kadar.)
^tr-Q0078-answer

**tr-Q0079** — Tom otoritesini kötüye kullanıyor, bu yüzden hiç kimse onu sevmiyor.

Tom abuses his authority, so no one likes him.

Expected form: **bu**

Why: Demonstratives. [[Turkish#^tr-Q0079|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20otoritesini%20k%C3%B6t%C3%BCye%20kullan%C4%B1yor%2C%20bu%20y%C3%BCzden%20hi%C3%A7%20kimse%20onu%20sevmiyor.)
^tr-Q0079-answer

**tr-Q0080** — Tom otoritesini kötüye kullanıyor, bu yüzden hiç kimse onu sevmiyor.

Tom abuses his authority, so no one likes him.

Expected form: **bu**

Why: Demonstratives. [[Turkish#^tr-Q0080|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20otoritesini%20k%C3%B6t%C3%BCye%20kullan%C4%B1yor%2C%20bu%20y%C3%BCzden%20hi%C3%A7%20kimse%20onu%20sevmiyor.)
^tr-Q0080-answer

**tr-Q0081** — O, iş için seyahate gitti.

He traveled on business.

Expected form: **O**

Why: Demonstratives. [[Turkish#^tr-Q0081|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=O%2C%20i%C5%9F%20i%C3%A7in%20seyahate%20gitti.)
^tr-Q0081-answer

**tr-Q0082** — O, iş için seyahate gitti.

He traveled on business.

Why: Demonstratives. [[Turkish#^tr-Q0082|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=O%2C%20i%C5%9F%20i%C3%A7in%20seyahate%20gitti.)
^tr-Q0082-answer

**tr-Q0083** — Lütfen bu belgeye göz atar mısın?

Would you please have a look at this document?

Why: Demonstratives. [[Turkish#^tr-Q0083|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=L%C3%BCtfen%20bu%20belgeye%20g%C3%B6z%20atar%20m%C4%B1s%C4%B1n%3F)
^tr-Q0083-answer

**tr-Q0084** — Lütfen bu belgeye göz atar mısın?

Would you please have a look at this document?

Bu/şu/o encode distinctions of reference and distance. Their pronoun inflections use a buffer n in relevant forms. Context, not English this/that alone, determines the best choice.

Why: Demonstratives. [[Turkish#^tr-Q0084|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=L%C3%BCtfen%20bu%20belgeye%20g%C3%B6z%20atar%20m%C4%B1s%C4%B1n%3F)
^tr-Q0084-answer

**tr-Q0085** — O yardımcı olabilir.

That could help.

Expected form: **O**

Why: Demonstratives. [[Turkish#^tr-Q0085|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=O%20yard%C4%B1mc%C4%B1%20olabilir.)
^tr-Q0085-answer

**tr-Q0086** — O yardımcı olabilir.

That could help.

Expected form: **O**

Why: Demonstratives. [[Turkish#^tr-Q0086|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=O%20yard%C4%B1mc%C4%B1%20olabilir.)
^tr-Q0086-answer

**tr-Q0087** — O bir manyak.

She is a maniac.

Expected form: **O**

Why: Demonstratives. [[Turkish#^tr-Q0087|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=O%20bir%20manyak.)
^tr-Q0087-answer

**tr-Q0088** — O bir manyak.

She is a maniac.

Why: Demonstratives. [[Turkish#^tr-Q0088|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=O%20bir%20manyak.)
^tr-Q0088-answer

**tr-Q0089** — O, verilen mesajı aldı.

She's got the point.

Why: Demonstratives. [[Turkish#^tr-Q0089|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=O%2C%20verilen%20mesaj%C4%B1%20ald%C4%B1.)
^tr-Q0089-answer

**tr-Q0090** — O, verilen mesajı aldı.

She's got the point.

Bu/şu/o encode distinctions of reference and distance. Their pronoun inflections use a buffer n in relevant forms. Context, not English this/that alone, determines the best choice.

Why: Demonstratives. [[Turkish#^tr-Q0090|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=O%2C%20verilen%20mesaj%C4%B1%20ald%C4%B1.)
^tr-Q0090-answer

**tr-Q0091** — Bu yalıtılmış bir sorun değildi.

It wasn't an isolated problem.

Expected form: **Bu**

Why: Demonstratives. [[Turkish#^tr-Q0091|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bu%20yal%C4%B1t%C4%B1lm%C4%B1%C5%9F%20bir%20sorun%20de%C4%9Fildi.)
^tr-Q0091-answer

**tr-Q0092** — Bu yalıtılmış bir sorun değildi.

It wasn't an isolated problem.

Expected form: **Bu**

Why: Demonstratives. [[Turkish#^tr-Q0092|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bu%20yal%C4%B1t%C4%B1lm%C4%B1%C5%9F%20bir%20sorun%20de%C4%9Fildi.)
^tr-Q0092-answer

**tr-Q0093** — Tom o kadar yakışıklı değil.

Tom isn't that handsome.

Expected form: **o**

Why: Demonstratives. [[Turkish#^tr-Q0093|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20o%20kadar%20yak%C4%B1%C5%9F%C4%B1kl%C4%B1%20de%C4%9Fil.)
^tr-Q0093-answer

**tr-Q0094** — Tom o kadar yakışıklı değil.

Tom isn't that handsome.

Why: Demonstratives. [[Turkish#^tr-Q0094|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20o%20kadar%20yak%C4%B1%C5%9F%C4%B1kl%C4%B1%20de%C4%9Fil.)
^tr-Q0094-answer

**tr-Q0095** — Ben bu buzdolabını onaramam.

I cannot repair this refrigerator.

Why: Demonstratives. [[Turkish#^tr-Q0095|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ben%20bu%20buzdolab%C4%B1n%C4%B1%20onaramam.)
^tr-Q0095-answer

**tr-Q0096** — Ben bu buzdolabını onaramam.

I cannot repair this refrigerator.

Bu/şu/o encode distinctions of reference and distance. Their pronoun inflections use a buffer n in relevant forms. Context, not English this/that alone, determines the best choice.

Why: Demonstratives. [[Turkish#^tr-Q0096|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ben%20bu%20buzdolab%C4%B1n%C4%B1%20onaramam.)
^tr-Q0096-answer

**tr-Q0097** — O, bazen okula gelmez.

He is sometimes absent from school.

Expected form: **O**

Why: Demonstratives. [[Turkish#^tr-Q0097|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=O%2C%20bazen%20okula%20gelmez.)
^tr-Q0097-answer

**tr-Q0098** — O, bazen okula gelmez.

He is sometimes absent from school.

Expected form: **O**

Why: Demonstratives. [[Turkish#^tr-Q0098|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=O%2C%20bazen%20okula%20gelmez.)
^tr-Q0098-answer

**tr-Q0099** — Onlar kendilerine bakan çocuğu seviyor.

They like the boy looking at them.

Expected form: **Onlar**

Why: Demonstratives. [[Turkish#^tr-Q0099|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Onlar%20kendilerine%20bakan%20%C3%A7ocu%C4%9Fu%20seviyor.)
^tr-Q0099-answer

**tr-Q0100** — Onlar kendilerine bakan çocuğu seviyor.

They like the boy looking at them.

Why: Demonstratives. [[Turkish#^tr-Q0100|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Onlar%20kendilerine%20bakan%20%C3%A7ocu%C4%9Fu%20seviyor.)
^tr-Q0100-answer


### Answers 101–150

**tr-Q0101** — İnsanlar Tom'a benzediğimi söylüyorlar.

People say that I look like Tom.

Why: Plural nouns. [[Turkish#^tr-Q0101|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=%C4%B0nsanlar%20Tom%27a%20benzedi%C4%9Fimi%20s%C3%B6yl%C3%BCyorlar.)
^tr-Q0101-answer

**tr-Q0102** — İnsanlar Tom'a benzediğimi söylüyorlar.

People say that I look like Tom.

Plural -lar/-ler follows two-way vowel harmony. Numerals commonly precede an unmarked counted noun, so do not add a plural suffix automatically after every number.

Why: Plural nouns. [[Turkish#^tr-Q0102|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=%C4%B0nsanlar%20Tom%27a%20benzedi%C4%9Fimi%20s%C3%B6yl%C3%BCyorlar.)
^tr-Q0102-answer

**tr-Q0103** — Arıcılar balı toplamak için peteği kaldırdılar.

Beekeepers remove the honeycomb to collect the honey.

Expected form: **Arıcılar**

Why: Plural nouns. [[Turkish#^tr-Q0103|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ar%C4%B1c%C4%B1lar%20bal%C4%B1%20toplamak%20i%C3%A7in%20pete%C4%9Fi%20kald%C4%B1rd%C4%B1lar.)
^tr-Q0103-answer

**tr-Q0104** — Arıcılar balı toplamak için peteği kaldırdılar.

Beekeepers remove the honeycomb to collect the honey.

Expected form: **Arıcılar**

Why: Plural nouns. [[Turkish#^tr-Q0104|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ar%C4%B1c%C4%B1lar%20bal%C4%B1%20toplamak%20i%C3%A7in%20pete%C4%9Fi%20kald%C4%B1rd%C4%B1lar.)
^tr-Q0104-answer

**tr-Q0105** — Tom anneler gününde annesine bir buket çiçek gönderdi.

Tom sent a bouquet of flowers to his mother on Mother's Day.

Expected form: **anneler**

Why: Plural nouns. [[Turkish#^tr-Q0105|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20anneler%20g%C3%BCn%C3%BCnde%20annesine%20bir%20buket%20%C3%A7i%C3%A7ek%20g%C3%B6nderdi.)
^tr-Q0105-answer

**tr-Q0106** — Tom anneler gününde annesine bir buket çiçek gönderdi.

Tom sent a bouquet of flowers to his mother on Mother's Day.

Why: Plural nouns. [[Turkish#^tr-Q0106|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20anneler%20g%C3%BCn%C3%BCnde%20annesine%20bir%20buket%20%C3%A7i%C3%A7ek%20g%C3%B6nderdi.)
^tr-Q0106-answer

**tr-Q0107** — Tüm milletler kendi sürekliliğini arar.

Every nation seeks to perpetuate itself.

Why: Plural nouns. [[Turkish#^tr-Q0107|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=T%C3%BCm%20milletler%20kendi%20s%C3%BCreklili%C4%9Fini%20arar.)
^tr-Q0107-answer

**tr-Q0108** — Tüm milletler kendi sürekliliğini arar.

Every nation seeks to perpetuate itself.

Plural -lar/-ler follows two-way vowel harmony. Numerals commonly precede an unmarked counted noun, so do not add a plural suffix automatically after every number.

Why: Plural nouns. [[Turkish#^tr-Q0108|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=T%C3%BCm%20milletler%20kendi%20s%C3%BCreklili%C4%9Fini%20arar.)
^tr-Q0108-answer

**tr-Q0109** — Biz resmî ve özel işler arasına çizgi çizmeliyiz.

We should draw the line between public and private affairs.

Expected form: **işler**

Why: Plural nouns. [[Turkish#^tr-Q0109|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Biz%20resm%C3%AE%20ve%20%C3%B6zel%20i%C5%9Fler%20aras%C4%B1na%20%C3%A7izgi%20%C3%A7izmeliyiz.)
^tr-Q0109-answer

**tr-Q0110** — Biz resmî ve özel işler arasına çizgi çizmeliyiz.

We should draw the line between public and private affairs.

Expected form: **işler**

Why: Plural nouns. [[Turkish#^tr-Q0110|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Biz%20resm%C3%AE%20ve%20%C3%B6zel%20i%C5%9Fler%20aras%C4%B1na%20%C3%A7izgi%20%C3%A7izmeliyiz.)
^tr-Q0110-answer

**tr-Q0111** — Sana ve ailene mutlu Noeller.

Merry Christmas to you and your family.

Expected form: **Noeller**

Why: Plural nouns. [[Turkish#^tr-Q0111|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Sana%20ve%20ailene%20mutlu%20Noeller.)
^tr-Q0111-answer

**tr-Q0112** — Sana ve ailene mutlu Noeller.

Merry Christmas to you and your family.

Why: Plural nouns. [[Turkish#^tr-Q0112|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Sana%20ve%20ailene%20mutlu%20Noeller.)
^tr-Q0112-answer

**tr-Q0113** — Angola bir zamanlar bir Portekiz bölgesiydi.

Angola was once a Portuguese territory.

Why: Plural nouns. [[Turkish#^tr-Q0113|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Angola%20bir%20zamanlar%20bir%20Portekiz%20b%C3%B6lgesiydi.)
^tr-Q0113-answer

**tr-Q0114** — Angola bir zamanlar bir Portekiz bölgesiydi.

Angola was once a Portuguese territory.

Plural -lar/-ler follows two-way vowel harmony. Numerals commonly precede an unmarked counted noun, so do not add a plural suffix automatically after every number.

Why: Plural nouns. [[Turkish#^tr-Q0114|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Angola%20bir%20zamanlar%20bir%20Portekiz%20b%C3%B6lgesiydi.)
^tr-Q0114-answer

**tr-Q0115** — Tom çok iyi trombon çalar.

Tom plays the trombone very well.

Expected form: **çalar**

Why: Plural nouns. [[Turkish#^tr-Q0115|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20%C3%A7ok%20iyi%20trombon%20%C3%A7alar.)
^tr-Q0115-answer

**tr-Q0116** — Tom çok iyi trombon çalar.

Tom plays the trombone very well.

Expected form: **çalar**

Why: Plural nouns. [[Turkish#^tr-Q0116|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20%C3%A7ok%20iyi%20trombon%20%C3%A7alar.)
^tr-Q0116-answer

**tr-Q0117** — Sami ev tadilatlarına yardımcı olmak için bazı işçiler tuttu.

Sami hired some workers to help out with the house renovations.

Expected form: **işçiler**

Why: Plural nouns. [[Turkish#^tr-Q0117|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Sami%20ev%20tadilatlar%C4%B1na%20yard%C4%B1mc%C4%B1%20olmak%20i%C3%A7in%20baz%C4%B1%20i%C5%9F%C3%A7iler%20tuttu.)
^tr-Q0117-answer

**tr-Q0118** — Sami ev tadilatlarına yardımcı olmak için bazı işçiler tuttu.

Sami hired some workers to help out with the house renovations.

Why: Plural nouns. [[Turkish#^tr-Q0118|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Sami%20ev%20tadilatlar%C4%B1na%20yard%C4%B1mc%C4%B1%20olmak%20i%C3%A7in%20baz%C4%B1%20i%C5%9F%C3%A7iler%20tuttu.)
^tr-Q0118-answer

**tr-Q0119** — Onlar onu sorguladılar.

They questioned him.

Why: Plural nouns. [[Turkish#^tr-Q0119|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Onlar%20onu%20sorgulad%C4%B1lar.)
^tr-Q0119-answer

**tr-Q0120** — Onlar onu sorguladılar.

They questioned him.

Plural -lar/-ler follows two-way vowel harmony. Numerals commonly precede an unmarked counted noun, so do not add a plural suffix automatically after every number.

Why: Plural nouns. [[Turkish#^tr-Q0120|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Onlar%20onu%20sorgulad%C4%B1lar.)
^tr-Q0120-answer

**tr-Q0121** — Tom Mary'in önerisini yapılacaklar listesine not etti.

Tom put Mary's suggestion down on his to-do list.

Expected form: **yapılacaklar**

Why: Plural nouns. [[Turkish#^tr-Q0121|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20Mary%27in%20%C3%B6nerisini%20yap%C4%B1lacaklar%20listesine%20not%20etti.)
^tr-Q0121-answer

**tr-Q0122** — Tom Mary'in önerisini yapılacaklar listesine not etti.

Tom put Mary's suggestion down on his to-do list.

Expected form: **yapılacaklar**

Why: Plural nouns. [[Turkish#^tr-Q0122|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20Mary%27in%20%C3%B6nerisini%20yap%C4%B1lacaklar%20listesine%20not%20etti.)
^tr-Q0122-answer

**tr-Q0123** — Onlar misafirleri ağırlamak için Allah'ın emrini yerine getiriyorlar.

They are fulfilling the commandment to host guests.

Expected form: **Onlar**

Why: Plural nouns. [[Turkish#^tr-Q0123|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Onlar%20misafirleri%20a%C4%9F%C4%B1rlamak%20i%C3%A7in%20Allah%27%C4%B1n%20emrini%20yerine%20getiriyorlar.)
^tr-Q0123-answer

**tr-Q0124** — Onlar misafirleri ağırlamak için Allah'ın emrini yerine getiriyorlar.

They are fulfilling the commandment to host guests.

Why: Plural nouns. [[Turkish#^tr-Q0124|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Onlar%20misafirleri%20a%C4%9F%C4%B1rlamak%20i%C3%A7in%20Allah%27%C4%B1n%20emrini%20yerine%20getiriyorlar.)
^tr-Q0124-answer

**tr-Q0125** — Bütün bunlar nasıl bitecek?

How will all this end?

Why: Plural nouns. [[Turkish#^tr-Q0125|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=B%C3%BCt%C3%BCn%20bunlar%20nas%C4%B1l%20bitecek%3F)
^tr-Q0125-answer

**tr-Q0126** — Bütün bunlar nasıl bitecek?

How will all this end?

Plural -lar/-ler follows two-way vowel harmony. Numerals commonly precede an unmarked counted noun, so do not add a plural suffix automatically after every number.

Why: Plural nouns. [[Turkish#^tr-Q0126|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=B%C3%BCt%C3%BCn%20bunlar%20nas%C4%B1l%20bitecek%3F)
^tr-Q0126-answer

**tr-Q0127** — Sen hiç bu restoranda ünlü kişiler gördün mü?

Have you ever seen any famous people in this restaurant?

Expected form: **kişiler**

Why: Plural nouns. [[Turkish#^tr-Q0127|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Sen%20hi%C3%A7%20bu%20restoranda%20%C3%BCnl%C3%BC%20ki%C5%9Filer%20g%C3%B6rd%C3%BCn%20m%C3%BC%3F)
^tr-Q0127-answer

**tr-Q0128** — Sen hiç bu restoranda ünlü kişiler gördün mü?

Have you ever seen any famous people in this restaurant?

Expected form: **kişiler**

Why: Plural nouns. [[Turkish#^tr-Q0128|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Sen%20hi%C3%A7%20bu%20restoranda%20%C3%BCnl%C3%BC%20ki%C5%9Filer%20g%C3%B6rd%C3%BCn%20m%C3%BC%3F)
^tr-Q0128-answer

**tr-Q0129** — Tom birçok yeni arkadaşlar edindi.

Tom has made a lot of new friends.

Expected form: **arkadaşlar**

Why: Plural nouns. [[Turkish#^tr-Q0129|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20bir%C3%A7ok%20yeni%20arkada%C5%9Flar%20edindi.)
^tr-Q0129-answer

**tr-Q0130** — Tom birçok yeni arkadaşlar edindi.

Tom has made a lot of new friends.

Why: Plural nouns. [[Turkish#^tr-Q0130|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20bir%C3%A7ok%20yeni%20arkada%C5%9Flar%20edindi.)
^tr-Q0130-answer

**tr-Q0131** — Astımınızı tetikleyen şeyler neler?

What triggers your asthma attacks?

Why: Plural nouns. [[Turkish#^tr-Q0131|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ast%C4%B1m%C4%B1n%C4%B1z%C4%B1%20tetikleyen%20%C5%9Feyler%20neler%3F)
^tr-Q0131-answer

**tr-Q0132** — Astımınızı tetikleyen şeyler neler?

What triggers your asthma attacks?

Plural -lar/-ler follows two-way vowel harmony. Numerals commonly precede an unmarked counted noun, so do not add a plural suffix automatically after every number.

Why: Plural nouns. [[Turkish#^tr-Q0132|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ast%C4%B1m%C4%B1n%C4%B1z%C4%B1%20tetikleyen%20%C5%9Feyler%20neler%3F)
^tr-Q0132-answer

**tr-Q0133** — Gerçek dostluklar yoktur.

True friendships don't exist.

Expected form: **dostluklar**

Why: Plural nouns. [[Turkish#^tr-Q0133|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ger%C3%A7ek%20dostluklar%20yoktur.)
^tr-Q0133-answer

**tr-Q0134** — Gerçek dostluklar yoktur.

True friendships don't exist.

Expected form: **dostluklar**

Why: Plural nouns. [[Turkish#^tr-Q0134|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ger%C3%A7ek%20dostluklar%20yoktur.)
^tr-Q0134-answer

**tr-Q0135** — Dinozorlar bir zamanlar dünyayı yönetti.

Dinosaurs once ruled the earth.

Expected form: **Dinozorlar**

Why: Plural nouns. [[Turkish#^tr-Q0135|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Dinozorlar%20bir%20zamanlar%20d%C3%BCnyay%C4%B1%20y%C3%B6netti.)
^tr-Q0135-answer

**tr-Q0136** — Dinozorlar bir zamanlar dünyayı yönetti.

Dinosaurs once ruled the earth.

Why: Plural nouns. [[Turkish#^tr-Q0136|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Dinozorlar%20bir%20zamanlar%20d%C3%BCnyay%C4%B1%20y%C3%B6netti.)
^tr-Q0136-answer

**tr-Q0137** — Artık o tür şeyler hakkında endişelenmiyorum.

I don't worry about those kinds of things anymore.

Why: Plural nouns. [[Turkish#^tr-Q0137|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Art%C4%B1k%20o%20t%C3%BCr%20%C5%9Feyler%20hakk%C4%B1nda%20endi%C5%9Felenmiyorum.)
^tr-Q0137-answer

**tr-Q0138** — Artık o tür şeyler hakkında endişelenmiyorum.

I don't worry about those kinds of things anymore.

Plural -lar/-ler follows two-way vowel harmony. Numerals commonly precede an unmarked counted noun, so do not add a plural suffix automatically after every number.

Why: Plural nouns. [[Turkish#^tr-Q0138|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Art%C4%B1k%20o%20t%C3%BCr%20%C5%9Feyler%20hakk%C4%B1nda%20endi%C5%9Felenmiyorum.)
^tr-Q0138-answer

**tr-Q0139** — Seni demir parmaklıklar ardında görmek istiyorum.

I want you behind bars.

Expected form: **parmaklıklar**

Why: Plural nouns. [[Turkish#^tr-Q0139|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Seni%20demir%20parmakl%C4%B1klar%20ard%C4%B1nda%20g%C3%B6rmek%20istiyorum.)
^tr-Q0139-answer

**tr-Q0140** — Seni demir parmaklıklar ardında görmek istiyorum.

I want you behind bars.

Expected form: **parmaklıklar**

Why: Plural nouns. [[Turkish#^tr-Q0140|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Seni%20demir%20parmakl%C4%B1klar%20ard%C4%B1nda%20g%C3%B6rmek%20istiyorum.)
^tr-Q0140-answer

**tr-Q0141** — Sınavlar akşam saat 5'te başladı.

The exams started at 5 o'clock in the evening.

Expected form: **Sınavlar**

Why: Plural nouns. [[Turkish#^tr-Q0141|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=S%C4%B1navlar%20ak%C5%9Fam%20saat%205%27te%20ba%C5%9Flad%C4%B1.)
^tr-Q0141-answer

**tr-Q0142** — Sınavlar akşam saat 5'te başladı.

The exams started at 5 o'clock in the evening.

Why: Plural nouns. [[Turkish#^tr-Q0142|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=S%C4%B1navlar%20ak%C5%9Fam%20saat%205%27te%20ba%C5%9Flad%C4%B1.)
^tr-Q0142-answer

**tr-Q0143** — Hem babam hem de erkek kardeşim kumara düşkünler.

Both my father and my brother are fond of gambling.

Why: Plural nouns. [[Turkish#^tr-Q0143|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Hem%20babam%20hem%20de%20erkek%20karde%C5%9Fim%20kumara%20d%C3%BC%C5%9Fk%C3%BCnler.)
^tr-Q0143-answer

**tr-Q0144** — Hem babam hem de erkek kardeşim kumara düşkünler.

Both my father and my brother are fond of gambling.

Plural -lar/-ler follows two-way vowel harmony. Numerals commonly precede an unmarked counted noun, so do not add a plural suffix automatically after every number.

Why: Plural nouns. [[Turkish#^tr-Q0144|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Hem%20babam%20hem%20de%20erkek%20karde%C5%9Fim%20kumara%20d%C3%BC%C5%9Fk%C3%BCnler.)
^tr-Q0144-answer

**tr-Q0145** — Bir zamanlar burada bir köprü vardı.

At one time, there was a bridge here.

Expected form: **zamanlar**

Why: Plural nouns. [[Turkish#^tr-Q0145|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bir%20zamanlar%20burada%20bir%20k%C3%B6pr%C3%BC%20vard%C4%B1.)
^tr-Q0145-answer

**tr-Q0146** — Bir zamanlar burada bir köprü vardı.

At one time, there was a bridge here.

Expected form: **zamanlar**

Why: Plural nouns. [[Turkish#^tr-Q0146|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bir%20zamanlar%20burada%20bir%20k%C3%B6pr%C3%BC%20vard%C4%B1.)
^tr-Q0146-answer

**tr-Q0147** — İyi insanlar her gün ölür.

Good people die every day.

Expected form: **insanlar**

Why: Plural nouns. [[Turkish#^tr-Q0147|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=%C4%B0yi%20insanlar%20her%20g%C3%BCn%20%C3%B6l%C3%BCr.)
^tr-Q0147-answer

**tr-Q0148** — İyi insanlar her gün ölür.

Good people die every day.

Why: Plural nouns. [[Turkish#^tr-Q0148|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=%C4%B0yi%20insanlar%20her%20g%C3%BCn%20%C3%B6l%C3%BCr.)
^tr-Q0148-answer

**tr-Q0149** — Sami ve Leyla, Mısırlıydılar.

Sami and Layla were from Egypt.

Why: Plural nouns. [[Turkish#^tr-Q0149|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Sami%20ve%20Leyla%2C%20M%C4%B1s%C4%B1rl%C4%B1yd%C4%B1lar.)
^tr-Q0149-answer

**tr-Q0150** — Sami ve Leyla, Mısırlıydılar.

Sami and Layla were from Egypt.

Plural -lar/-ler follows two-way vowel harmony. Numerals commonly precede an unmarked counted noun, so do not add a plural suffix automatically after every number.

Why: Plural nouns. [[Turkish#^tr-Q0150|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Sami%20ve%20Leyla%2C%20M%C4%B1s%C4%B1rl%C4%B1yd%C4%B1lar.)
^tr-Q0150-answer


### Answers 151–200

**tr-Q0151** — Bütün onları yapmak zorunda mıyız?

Do we have to do all that?

Expected form: **zorunda**

Why: Location suffix. [[Turkish#^tr-Q0151|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=B%C3%BCt%C3%BCn%20onlar%C4%B1%20yapmak%20zorunda%20m%C4%B1y%C4%B1z%3F)
^tr-Q0151-answer

**tr-Q0152** — Bütün onları yapmak zorunda mıyız?

Do we have to do all that?

Expected form: **zorunda**

Why: Location suffix. [[Turkish#^tr-Q0152|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=B%C3%BCt%C3%BCn%20onlar%C4%B1%20yapmak%20zorunda%20m%C4%B1y%C4%B1z%3F)
^tr-Q0152-answer

**tr-Q0153** — Akşam yemeğinde ne yemek istersiniz?

What would you like to have for dinner?

Expected form: **yemeğinde**

Why: Location suffix. [[Turkish#^tr-Q0153|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ak%C5%9Fam%20yeme%C4%9Finde%20ne%20yemek%20istersiniz%3F)
^tr-Q0153-answer

**tr-Q0154** — Akşam yemeğinde ne yemek istersiniz?

What would you like to have for dinner?

Why: Location suffix. [[Turkish#^tr-Q0154|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ak%C5%9Fam%20yeme%C4%9Finde%20ne%20yemek%20istersiniz%3F)
^tr-Q0154-answer

**tr-Q0155** — Hafta boyunca daha az kalabalık görünüyor.

It seems less crowded during the week.

Why: Location suffix. [[Turkish#^tr-Q0155|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Hafta%20boyunca%20daha%20az%20kalabal%C4%B1k%20g%C3%B6r%C3%BCn%C3%BCyor.)
^tr-Q0155-answer

**tr-Q0156** — Hafta boyunca daha az kalabalık görünüyor.

It seems less crowded during the week.

Locative -DA combines vowel harmony and consonant assimilation. The capital notation stands for alternatives, not a written capital suffix. Lexical words can end similarly; inspect their stem.

Why: Location suffix. [[Turkish#^tr-Q0156|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Hafta%20boyunca%20daha%20az%20kalabal%C4%B1k%20g%C3%B6r%C3%BCn%C3%BCyor.)
^tr-Q0156-answer

**tr-Q0157** — Kitabın önermesi temelde kusurludur.

The book's premise is fundamentally flawed.

Expected form: **temelde**

Why: Location suffix. [[Turkish#^tr-Q0157|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Kitab%C4%B1n%20%C3%B6nermesi%20temelde%20kusurludur.)
^tr-Q0157-answer

**tr-Q0158** — Kitabın önermesi temelde kusurludur.

The book's premise is fundamentally flawed.

Expected form: **temelde**

Why: Location suffix. [[Turkish#^tr-Q0158|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Kitab%C4%B1n%20%C3%B6nermesi%20temelde%20kusurludur.)
^tr-Q0158-answer

**tr-Q0159** — Her şeyin yolunda gideceğinden bayağı eminim.

I'm pretty sure everything will go well.

Expected form: **yolunda**

Why: Location suffix. [[Turkish#^tr-Q0159|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Her%20%C5%9Feyin%20yolunda%20gidece%C4%9Finden%20baya%C4%9F%C4%B1%20eminim.)
^tr-Q0159-answer

**tr-Q0160** — Her şeyin yolunda gideceğinden bayağı eminim.

I'm pretty sure everything will go well.

Why: Location suffix. [[Turkish#^tr-Q0160|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Her%20%C5%9Feyin%20yolunda%20gidece%C4%9Finden%20baya%C4%9F%C4%B1%20eminim.)
^tr-Q0160-answer

**tr-Q0161** — Onun yine başı belada mı?

Is he in trouble again?

Why: Location suffix. [[Turkish#^tr-Q0161|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Onun%20yine%20ba%C5%9F%C4%B1%20belada%20m%C4%B1%3F)
^tr-Q0161-answer

**tr-Q0162** — Onun yine başı belada mı?

Is he in trouble again?

Locative -DA combines vowel harmony and consonant assimilation. The capital notation stands for alternatives, not a written capital suffix. Lexical words can end similarly; inspect their stem.

Why: Location suffix. [[Turkish#^tr-Q0162|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Onun%20yine%20ba%C5%9F%C4%B1%20belada%20m%C4%B1%3F)
^tr-Q0162-answer

**tr-Q0163** — Şimdi yapmak zorunda mıyım?

Do I have to do that now?

Expected form: **zorunda**

Why: Location suffix. [[Turkish#^tr-Q0163|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=%C5%9Eimdi%20yapmak%20zorunda%20m%C4%B1y%C4%B1m%3F)
^tr-Q0163-answer

**tr-Q0164** — Şimdi yapmak zorunda mıyım?

Do I have to do that now?

Expected form: **zorunda**

Why: Location suffix. [[Turkish#^tr-Q0164|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=%C5%9Eimdi%20yapmak%20zorunda%20m%C4%B1y%C4%B1m%3F)
^tr-Q0164-answer

**tr-Q0165** — Tom'un Mary ile birlikte okula giden bir kızı var.

Tom has a daughter that goes to school with Mary.

Expected form: **birlikte**

Why: Location suffix. [[Turkish#^tr-Q0165|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%27un%20Mary%20ile%20birlikte%20okula%20giden%20bir%20k%C4%B1z%C4%B1%20var.)
^tr-Q0165-answer

**tr-Q0166** — Tom'un Mary ile birlikte okula giden bir kızı var.

Tom has a daughter that goes to school with Mary.

Why: Location suffix. [[Turkish#^tr-Q0166|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%27un%20Mary%20ile%20birlikte%20okula%20giden%20bir%20k%C4%B1z%C4%B1%20var.)
^tr-Q0166-answer

**tr-Q0167** — Onu iki kopya halinde gönderin.

Send it in duplicate.

Why: Location suffix. [[Turkish#^tr-Q0167|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Onu%20iki%20kopya%20halinde%20g%C3%B6nderin.)
^tr-Q0167-answer

**tr-Q0168** — Onu iki kopya halinde gönderin.

Send it in duplicate.

Locative -DA combines vowel harmony and consonant assimilation. The capital notation stands for alternatives, not a written capital suffix. Lexical words can end similarly; inspect their stem.

Why: Location suffix. [[Turkish#^tr-Q0168|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Onu%20iki%20kopya%20halinde%20g%C3%B6nderin.)
^tr-Q0168-answer

**tr-Q0169** — Lütfen geçerli bir e-posta adresi giriniz.

Please enter a valid email address.

Expected form: **posta**

Why: Location suffix. [[Turkish#^tr-Q0169|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=L%C3%BCtfen%20ge%C3%A7erli%20bir%20e-posta%20adresi%20giriniz.)
^tr-Q0169-answer

**tr-Q0170** — Lütfen geçerli bir e-posta adresi giriniz.

Please enter a valid email address.

Expected form: **posta**

Why: Location suffix. [[Turkish#^tr-Q0170|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=L%C3%BCtfen%20ge%C3%A7erli%20bir%20e-posta%20adresi%20giriniz.)
^tr-Q0170-answer

**tr-Q0171** — Tom ders kitabını arabada bıraktı.

Tom left his textbook in the car.

Expected form: **arabada**

Why: Location suffix. [[Turkish#^tr-Q0171|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20ders%20kitab%C4%B1n%C4%B1%20arabada%20b%C4%B1rakt%C4%B1.)
^tr-Q0171-answer

**tr-Q0172** — Tom ders kitabını arabada bıraktı.

Tom left his textbook in the car.

Why: Location suffix. [[Turkish#^tr-Q0172|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20ders%20kitab%C4%B1n%C4%B1%20arabada%20b%C4%B1rakt%C4%B1.)
^tr-Q0172-answer

**tr-Q0173** — Aslında çok iyi bir sürücüyüm.

I'm actually a very good driver.

Why: Location suffix. [[Turkish#^tr-Q0173|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Asl%C4%B1nda%20%C3%A7ok%20iyi%20bir%20s%C3%BCr%C3%BCc%C3%BCy%C3%BCm.)
^tr-Q0173-answer

**tr-Q0174** — Aslında çok iyi bir sürücüyüm.

I'm actually a very good driver.

Locative -DA combines vowel harmony and consonant assimilation. The capital notation stands for alternatives, not a written capital suffix. Lexical words can end similarly; inspect their stem.

Why: Location suffix. [[Turkish#^tr-Q0174|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Asl%C4%B1nda%20%C3%A7ok%20iyi%20bir%20s%C3%BCr%C3%BCc%C3%BCy%C3%BCm.)
^tr-Q0174-answer

**tr-Q0175** — Oda çok dağınıktı.

The room was very untidy.

Expected form: **Oda**

Why: Location suffix. [[Turkish#^tr-Q0175|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Oda%20%C3%A7ok%20da%C4%9F%C4%B1n%C4%B1kt%C4%B1.)
^tr-Q0175-answer

**tr-Q0176** — Oda çok dağınıktı.

The room was very untidy.

Expected form: **Oda**

Why: Location suffix. [[Turkish#^tr-Q0176|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Oda%20%C3%A7ok%20da%C4%9F%C4%B1n%C4%B1kt%C4%B1.)
^tr-Q0176-answer

**tr-Q0177** — Hepimiz konferansta mevcuttuk.

We were all present at the conference.

Expected form: **konferansta**

Why: Location suffix. [[Turkish#^tr-Q0177|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Hepimiz%20konferansta%20mevcuttuk.)
^tr-Q0177-answer

**tr-Q0178** — Hepimiz konferansta mevcuttuk.

We were all present at the conference.

Why: Location suffix. [[Turkish#^tr-Q0178|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Hepimiz%20konferansta%20mevcuttuk.)
^tr-Q0178-answer

**tr-Q0179** — Satın almak zorunda olduğum şeyi almak için yeterli param yoktu.

I didn't have enough money to buy what I had to buy.

Why: Location suffix. [[Turkish#^tr-Q0179|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Sat%C4%B1n%20almak%20zorunda%20oldu%C4%9Fum%20%C5%9Feyi%20almak%20i%C3%A7in%20yeterli%20param%20yoktu.)
^tr-Q0179-answer

**tr-Q0180** — Satın almak zorunda olduğum şeyi almak için yeterli param yoktu.

I didn't have enough money to buy what I had to buy.

Locative -DA combines vowel harmony and consonant assimilation. The capital notation stands for alternatives, not a written capital suffix. Lexical words can end similarly; inspect their stem.

Why: Location suffix. [[Turkish#^tr-Q0180|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Sat%C4%B1n%20almak%20zorunda%20oldu%C4%9Fum%20%C5%9Feyi%20almak%20i%C3%A7in%20yeterli%20param%20yoktu.)
^tr-Q0180-answer

**tr-Q0181** — Tom akşam yemeği için zamanında döndü.

Tom made it back in time for dinner.

Expected form: **zamanında**

Why: Location suffix. [[Turkish#^tr-Q0181|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20ak%C5%9Fam%20yeme%C4%9Fi%20i%C3%A7in%20zaman%C4%B1nda%20d%C3%B6nd%C3%BC.)
^tr-Q0181-answer

**tr-Q0182** — Tom akşam yemeği için zamanında döndü.

Tom made it back in time for dinner.

Expected form: **zamanında**

Why: Location suffix. [[Turkish#^tr-Q0182|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20ak%C5%9Fam%20yeme%C4%9Fi%20i%C3%A7in%20zaman%C4%B1nda%20d%C3%B6nd%C3%BC.)
^tr-Q0182-answer

**tr-Q0183** — Okulda Fransızca okuyoruz.

We study French at school.

Expected form: **Okulda**

Why: Location suffix. [[Turkish#^tr-Q0183|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Okulda%20Frans%C4%B1zca%20okuyoruz.)
^tr-Q0183-answer

**tr-Q0184** — Okulda Fransızca okuyoruz.

We study French at school.

Why: Location suffix. [[Turkish#^tr-Q0184|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Okulda%20Frans%C4%B1zca%20okuyoruz.)
^tr-Q0184-answer

**tr-Q0185** — Kral John için, rakiplerinin tümünü kontrol altında tutmak çok zordu.

It was difficult for King John to keep control over all of his rivals.

Why: Location suffix. [[Turkish#^tr-Q0185|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Kral%20John%20i%C3%A7in%2C%20rakiplerinin%20t%C3%BCm%C3%BCn%C3%BC%20kontrol%20alt%C4%B1nda%20tutmak%20%C3%A7ok%20zordu.)
^tr-Q0185-answer

**tr-Q0186** — Kral John için, rakiplerinin tümünü kontrol altında tutmak çok zordu.

It was difficult for King John to keep control over all of his rivals.

Locative -DA combines vowel harmony and consonant assimilation. The capital notation stands for alternatives, not a written capital suffix. Lexical words can end similarly; inspect their stem.

Why: Location suffix. [[Turkish#^tr-Q0186|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Kral%20John%20i%C3%A7in%2C%20rakiplerinin%20t%C3%BCm%C3%BCn%C3%BC%20kontrol%20alt%C4%B1nda%20tutmak%20%C3%A7ok%20zordu.)
^tr-Q0186-answer

**tr-Q0187** — Senin hakkında çok endişeliydim.

I was worried sick about you.

Expected form: **hakkında**

Why: Location suffix. [[Turkish#^tr-Q0187|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Senin%20hakk%C4%B1nda%20%C3%A7ok%20endi%C5%9Feliydim.)
^tr-Q0187-answer

**tr-Q0188** — Senin hakkında çok endişeliydim.

I was worried sick about you.

Expected form: **hakkında**

Why: Location suffix. [[Turkish#^tr-Q0188|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Senin%20hakk%C4%B1nda%20%C3%A7ok%20endi%C5%9Feliydim.)
^tr-Q0188-answer

**tr-Q0189** — Amerikan siyasetinde yeni bir yüzdü.

He was a fresh face in American politics.

Expected form: **siyasetinde**

Why: Location suffix. [[Turkish#^tr-Q0189|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Amerikan%20siyasetinde%20yeni%20bir%20y%C3%BCzd%C3%BC.)
^tr-Q0189-answer

**tr-Q0190** — Amerikan siyasetinde yeni bir yüzdü.

He was a fresh face in American politics.

Why: Location suffix. [[Turkish#^tr-Q0190|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Amerikan%20siyasetinde%20yeni%20bir%20y%C3%BCzd%C3%BC.)
^tr-Q0190-answer

**tr-Q0191** — Şehrin iş bölgesinde birçok otel var.

There are many hotels in the city's business district.

Why: Location suffix. [[Turkish#^tr-Q0191|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=%C5%9Eehrin%20i%C5%9F%20b%C3%B6lgesinde%20bir%C3%A7ok%20otel%20var.)
^tr-Q0191-answer

**tr-Q0192** — Şehrin iş bölgesinde birçok otel var.

There are many hotels in the city's business district.

Locative -DA combines vowel harmony and consonant assimilation. The capital notation stands for alternatives, not a written capital suffix. Lexical words can end similarly; inspect their stem.

Why: Location suffix. [[Turkish#^tr-Q0192|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=%C5%9Eehrin%20i%C5%9F%20b%C3%B6lgesinde%20bir%C3%A7ok%20otel%20var.)
^tr-Q0192-answer

**tr-Q0193** — Onun hakkında bilmek istiyorum.

I want to know about him.

Expected form: **hakkında**

Why: Location suffix. [[Turkish#^tr-Q0193|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Onun%20hakk%C4%B1nda%20bilmek%20istiyorum.)
^tr-Q0193-answer

**tr-Q0194** — Onun hakkında bilmek istiyorum.

I want to know about him.

Expected form: **hakkında**

Why: Location suffix. [[Turkish#^tr-Q0194|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Onun%20hakk%C4%B1nda%20bilmek%20istiyorum.)
^tr-Q0194-answer

**tr-Q0195** — Sisli ormanda yavaşça gözden kayboldu.

She slowly disappeared into the foggy forest.

Expected form: **ormanda**

Why: Location suffix. [[Turkish#^tr-Q0195|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Sisli%20ormanda%20yava%C5%9F%C3%A7a%20g%C3%B6zden%20kayboldu.)
^tr-Q0195-answer

**tr-Q0196** — Sisli ormanda yavaşça gözden kayboldu.

She slowly disappeared into the foggy forest.

Why: Location suffix. [[Turkish#^tr-Q0196|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Sisli%20ormanda%20yava%C5%9F%C3%A7a%20g%C3%B6zden%20kayboldu.)
^tr-Q0196-answer

**tr-Q0197** — Burada oturmanı ve sessiz olmanı istiyorum.

I want you to sit here and be quiet.

Why: Location suffix. [[Turkish#^tr-Q0197|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Burada%20oturman%C4%B1%20ve%20sessiz%20olman%C4%B1%20istiyorum.)
^tr-Q0197-answer

**tr-Q0198** — Burada oturmanı ve sessiz olmanı istiyorum.

I want you to sit here and be quiet.

Locative -DA combines vowel harmony and consonant assimilation. The capital notation stands for alternatives, not a written capital suffix. Lexical words can end similarly; inspect their stem.

Why: Location suffix. [[Turkish#^tr-Q0198|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Burada%20oturman%C4%B1%20ve%20sessiz%20olman%C4%B1%20istiyorum.)
^tr-Q0198-answer

**tr-Q0199** — Tom'a bir şey yapmasını emretmek zorunda değildim.

I never had to order Tom to do anything.

Expected form: **zorunda**

Why: Location suffix. [[Turkish#^tr-Q0199|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%27a%20bir%20%C5%9Fey%20yapmas%C4%B1n%C4%B1%20emretmek%20zorunda%20de%C4%9Fildim.)
^tr-Q0199-answer

**tr-Q0200** — Tom'a bir şey yapmasını emretmek zorunda değildim.

I never had to order Tom to do anything.

Expected form: **zorunda**

Why: Location suffix. [[Turkish#^tr-Q0200|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%27a%20bir%20%C5%9Fey%20yapmas%C4%B1n%C4%B1%20emretmek%20zorunda%20de%C4%9Fildim.)
^tr-Q0200-answer


### Answers 201–250

**tr-Q0201** — Sabahtan beri öksürüyorum.

I've been coughing since this morning.

Expected form: **Sabahtan**

Why: Source suffix. [[Turkish#^tr-Q0201|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Sabahtan%20beri%20%C3%B6ks%C3%BCr%C3%BCyorum.)
^tr-Q0201-answer

**tr-Q0202** — Sabahtan beri öksürüyorum.

I've been coughing since this morning.

Why: Source suffix. [[Turkish#^tr-Q0202|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Sabahtan%20beri%20%C3%B6ks%C3%BCr%C3%BCyorum.)
^tr-Q0202-answer

**tr-Q0203** — Krizlerden mutlaka nemalanmaya bak.

Never let a crisis go to waste.

Why: Source suffix. [[Turkish#^tr-Q0203|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Krizlerden%20mutlaka%20nemalanmaya%20bak.)
^tr-Q0203-answer

**tr-Q0204** — Krizlerden mutlaka nemalanmaya bak.

Never let a crisis go to waste.

Ablative -DAn expresses many source/from relations and governed complements. A final voiceless stem consonant commonly selects t. Meaning depends on the governing phrase.

Why: Source suffix. [[Turkish#^tr-Q0204|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Krizlerden%20mutlaka%20nemalanmaya%20bak.)
^tr-Q0204-answer

**tr-Q0205** — Bundan sonra daha sıkı çalış.

Study harder from now on.

Expected form: **Bundan**

Why: Source suffix. [[Turkish#^tr-Q0205|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bundan%20sonra%20daha%20s%C4%B1k%C4%B1%20%C3%A7al%C4%B1%C5%9F.)
^tr-Q0205-answer

**tr-Q0206** — Bundan sonra daha sıkı çalış.

Study harder from now on.

Expected form: **Bundan**

Why: Source suffix. [[Turkish#^tr-Q0206|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bundan%20sonra%20daha%20s%C4%B1k%C4%B1%20%C3%A7al%C4%B1%C5%9F.)
^tr-Q0206-answer

**tr-Q0207** — Tom benden daha iyi bir kişi.

Tom is a better person than me.

Expected form: **benden**

Why: Source suffix. [[Turkish#^tr-Q0207|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20benden%20daha%20iyi%20bir%20ki%C5%9Fi.)
^tr-Q0207-answer

**tr-Q0208** — Tom benden daha iyi bir kişi.

Tom is a better person than me.

Why: Source suffix. [[Turkish#^tr-Q0208|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20benden%20daha%20iyi%20bir%20ki%C5%9Fi.)
^tr-Q0208-answer

**tr-Q0209** — Tom onu düşmekten korumak için Mary'yi yakaladı.

Tom grabbed Mary to keep her from falling.

Why: Source suffix. [[Turkish#^tr-Q0209|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20onu%20d%C3%BC%C5%9Fmekten%20korumak%20i%C3%A7in%20Mary%27yi%20yakalad%C4%B1.)
^tr-Q0209-answer

**tr-Q0210** — Tom onu düşmekten korumak için Mary'yi yakaladı.

Tom grabbed Mary to keep her from falling.

Ablative -DAn expresses many source/from relations and governed complements. A final voiceless stem consonant commonly selects t. Meaning depends on the governing phrase.

Why: Source suffix. [[Turkish#^tr-Q0210|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20onu%20d%C3%BC%C5%9Fmekten%20korumak%20i%C3%A7in%20Mary%27yi%20yakalad%C4%B1.)
^tr-Q0210-answer

**tr-Q0211** — Sadece bir geziden döndüm.

I've just returned from a trip.

Expected form: **geziden**

Why: Source suffix. [[Turkish#^tr-Q0211|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Sadece%20bir%20geziden%20d%C3%B6nd%C3%BCm.)
^tr-Q0211-answer

**tr-Q0212** — Sadece bir geziden döndüm.

I've just returned from a trip.

Expected form: **geziden**

Why: Source suffix. [[Turkish#^tr-Q0212|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Sadece%20bir%20geziden%20d%C3%B6nd%C3%BCm.)
^tr-Q0212-answer

**tr-Q0213** — Onu kasten yaptın.

You did that on purpose.

Expected form: **kasten**

Why: Source suffix. [[Turkish#^tr-Q0213|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Onu%20kasten%20yapt%C4%B1n.)
^tr-Q0213-answer

**tr-Q0214** — Onu kasten yaptın.

You did that on purpose.

Why: Source suffix. [[Turkish#^tr-Q0214|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Onu%20kasten%20yapt%C4%B1n.)
^tr-Q0214-answer

**tr-Q0215** — Milliyetlerinden bağımsız olarak herkes çok hoş karşılanıyor.

Everyone is very welcome, independent of their nationality.

Why: Source suffix. [[Turkish#^tr-Q0215|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Milliyetlerinden%20ba%C4%9F%C4%B1ms%C4%B1z%20olarak%20herkes%20%C3%A7ok%20ho%C5%9F%20kar%C5%9F%C4%B1lan%C4%B1yor.)
^tr-Q0215-answer

**tr-Q0216** — Milliyetlerinden bağımsız olarak herkes çok hoş karşılanıyor.

Everyone is very welcome, independent of their nationality.

Ablative -DAn expresses many source/from relations and governed complements. A final voiceless stem consonant commonly selects t. Meaning depends on the governing phrase.

Why: Source suffix. [[Turkish#^tr-Q0216|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Milliyetlerinden%20ba%C4%9F%C4%B1ms%C4%B1z%20olarak%20herkes%20%C3%A7ok%20ho%C5%9F%20kar%C5%9F%C4%B1lan%C4%B1yor.)
^tr-Q0216-answer

**tr-Q0217** — Doğum günü partinden sonra ne olduğunu hatırlıyor musun?

Do you remember what happened after your birthday party?

Expected form: **partinden**

Why: Source suffix. [[Turkish#^tr-Q0217|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Do%C4%9Fum%20g%C3%BCn%C3%BC%20partinden%20sonra%20ne%20oldu%C4%9Funu%20hat%C4%B1rl%C4%B1yor%20musun%3F)
^tr-Q0217-answer

**tr-Q0218** — Doğum günü partinden sonra ne olduğunu hatırlıyor musun?

Do you remember what happened after your birthday party?

Expected form: **partinden**

Why: Source suffix. [[Turkish#^tr-Q0218|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Do%C4%9Fum%20g%C3%BCn%C3%BC%20partinden%20sonra%20ne%20oldu%C4%9Funu%20hat%C4%B1rl%C4%B1yor%20musun%3F)
^tr-Q0218-answer

**tr-Q0219** — Tom senin sandığından daha zengindir.

Tom is richer than you think.

Expected form: **sandığından**

Why: Source suffix. [[Turkish#^tr-Q0219|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20senin%20sand%C4%B1%C4%9F%C4%B1ndan%20daha%20zengindir.)
^tr-Q0219-answer

**tr-Q0220** — Tom senin sandığından daha zengindir.

Tom is richer than you think.

Why: Source suffix. [[Turkish#^tr-Q0220|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20senin%20sand%C4%B1%C4%9F%C4%B1ndan%20daha%20zengindir.)
^tr-Q0220-answer

**tr-Q0221** — Ona bana bakmaktan vazgeçmesini söyle.

Tell him to stop staring at me.

Why: Source suffix. [[Turkish#^tr-Q0221|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ona%20bana%20bakmaktan%20vazge%C3%A7mesini%20s%C3%B6yle.)
^tr-Q0221-answer

**tr-Q0222** — Ona bana bakmaktan vazgeçmesini söyle.

Tell him to stop staring at me.

Ablative -DAn expresses many source/from relations and governed complements. A final voiceless stem consonant commonly selects t. Meaning depends on the governing phrase.

Why: Source suffix. [[Turkish#^tr-Q0222|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ona%20bana%20bakmaktan%20vazge%C3%A7mesini%20s%C3%B6yle.)
^tr-Q0222-answer

**tr-Q0223** — Gerçekten ilaç gibi geldi.

It really hit the spot.

Expected form: **Gerçekten**

Why: Source suffix. [[Turkish#^tr-Q0223|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ger%C3%A7ekten%20ila%C3%A7%20gibi%20geldi.)
^tr-Q0223-answer

**tr-Q0224** — Gerçekten ilaç gibi geldi.

It really hit the spot.

Expected form: **Gerçekten**

Why: Source suffix. [[Turkish#^tr-Q0224|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ger%C3%A7ekten%20ila%C3%A7%20gibi%20geldi.)
^tr-Q0224-answer

**tr-Q0225** — Eğer gerçekten bilmek istiyorsanız, tüm yapmanız gereken sormaktır.

If you really want to know, all you have to do is ask.

Expected form: **gerçekten**

Why: Source suffix. [[Turkish#^tr-Q0225|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=E%C4%9Fer%20ger%C3%A7ekten%20bilmek%20istiyorsan%C4%B1z%2C%20t%C3%BCm%20yapman%C4%B1z%20gereken%20sormakt%C4%B1r.)
^tr-Q0225-answer

**tr-Q0226** — Eğer gerçekten bilmek istiyorsanız, tüm yapmanız gereken sormaktır.

If you really want to know, all you have to do is ask.

Why: Source suffix. [[Turkish#^tr-Q0226|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=E%C4%9Fer%20ger%C3%A7ekten%20bilmek%20istiyorsan%C4%B1z%2C%20t%C3%BCm%20yapman%C4%B1z%20gereken%20sormakt%C4%B1r.)
^tr-Q0226-answer

**tr-Q0227** — Tüm gün git-gel yapacağım için beni akşam yemeğinden sonra araman en uygunu.

I'll be in and out all day, so it might be best if you call around after dinner.

Why: Source suffix. [[Turkish#^tr-Q0227|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=T%C3%BCm%20g%C3%BCn%20git-gel%20yapaca%C4%9F%C4%B1m%20i%C3%A7in%20beni%20ak%C5%9Fam%20yeme%C4%9Finden%20sonra%20araman%20en%20uygunu.)
^tr-Q0227-answer

**tr-Q0228** — Tüm gün git-gel yapacağım için beni akşam yemeğinden sonra araman en uygunu.

I'll be in and out all day, so it might be best if you call around after dinner.

Ablative -DAn expresses many source/from relations and governed complements. A final voiceless stem consonant commonly selects t. Meaning depends on the governing phrase.

Why: Source suffix. [[Turkish#^tr-Q0228|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=T%C3%BCm%20g%C3%BCn%20git-gel%20yapaca%C4%9F%C4%B1m%20i%C3%A7in%20beni%20ak%C5%9Fam%20yeme%C4%9Finden%20sonra%20araman%20en%20uygunu.)
^tr-Q0228-answer

**tr-Q0229** — Cenaze arabası sekiz siyah at tarafından çekildi.

The hearse was drawn by eight black horses.

Expected form: **tarafından**

Why: Source suffix. [[Turkish#^tr-Q0229|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Cenaze%20arabas%C4%B1%20sekiz%20siyah%20at%20taraf%C4%B1ndan%20%C3%A7ekildi.)
^tr-Q0229-answer

**tr-Q0230** — Cenaze arabası sekiz siyah at tarafından çekildi.

The hearse was drawn by eight black horses.

Expected form: **tarafından**

Why: Source suffix. [[Turkish#^tr-Q0230|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Cenaze%20arabas%C4%B1%20sekiz%20siyah%20at%20taraf%C4%B1ndan%20%C3%A7ekildi.)
^tr-Q0230-answer

**tr-Q0231** — Eylemlerim için derinden üzgünüm.

I'm deeply sorry for my actions.

Expected form: **derinden**

Why: Source suffix. [[Turkish#^tr-Q0231|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Eylemlerim%20i%C3%A7in%20derinden%20%C3%BCzg%C3%BCn%C3%BCm.)
^tr-Q0231-answer

**tr-Q0232** — Eylemlerim için derinden üzgünüm.

I'm deeply sorry for my actions.

Why: Source suffix. [[Turkish#^tr-Q0232|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Eylemlerim%20i%C3%A7in%20derinden%20%C3%BCzg%C3%BCn%C3%BCm.)
^tr-Q0232-answer

**tr-Q0233** — Işık ve gölge sanatı denilen tekniği gerçekten seviyorum.

I really like the technique called chiaroscuro.

Why: Source suffix. [[Turkish#^tr-Q0233|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=I%C5%9F%C4%B1k%20ve%20g%C3%B6lge%20sanat%C4%B1%20denilen%20tekni%C4%9Fi%20ger%C3%A7ekten%20seviyorum.)
^tr-Q0233-answer

**tr-Q0234** — Işık ve gölge sanatı denilen tekniği gerçekten seviyorum.

I really like the technique called chiaroscuro.

Ablative -DAn expresses many source/from relations and governed complements. A final voiceless stem consonant commonly selects t. Meaning depends on the governing phrase.

Why: Source suffix. [[Turkish#^tr-Q0234|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=I%C5%9F%C4%B1k%20ve%20g%C3%B6lge%20sanat%C4%B1%20denilen%20tekni%C4%9Fi%20ger%C3%A7ekten%20seviyorum.)
^tr-Q0234-answer

**tr-Q0235** — Gerçekten bunu yiyebilir misin?

Could you actually eat this?

Expected form: **Gerçekten**

Why: Source suffix. [[Turkish#^tr-Q0235|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ger%C3%A7ekten%20bunu%20yiyebilir%20misin%3F)
^tr-Q0235-answer

**tr-Q0236** — Gerçekten bunu yiyebilir misin?

Could you actually eat this?

Expected form: **Gerçekten**

Why: Source suffix. [[Turkish#^tr-Q0236|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ger%C3%A7ekten%20bunu%20yiyebilir%20misin%3F)
^tr-Q0236-answer

**tr-Q0237** — Bir dağ zirvesinden güneş'in doğuşunu izlemek bir zevk.

To see the sunrise from a mountaintop is a delight.

Expected form: **zirvesinden**

Why: Source suffix. [[Turkish#^tr-Q0237|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bir%20da%C4%9F%20zirvesinden%20g%C3%BCne%C5%9F%27in%20do%C4%9Fu%C5%9Funu%20izlemek%20bir%20zevk.)
^tr-Q0237-answer

**tr-Q0238** — Bir dağ zirvesinden güneş'in doğuşunu izlemek bir zevk.

To see the sunrise from a mountaintop is a delight.

Why: Source suffix. [[Turkish#^tr-Q0238|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bir%20da%C4%9F%20zirvesinden%20g%C3%BCne%C5%9F%27in%20do%C4%9Fu%C5%9Funu%20izlemek%20bir%20zevk.)
^tr-Q0238-answer

**tr-Q0239** — Böyle bir sabit fikirden kurtulsak iyi olur.

We had better do away with such a fixed idea.

Why: Source suffix. [[Turkish#^tr-Q0239|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=B%C3%B6yle%20bir%20sabit%20fikirden%20kurtulsak%20iyi%20olur.)
^tr-Q0239-answer

**tr-Q0240** — Böyle bir sabit fikirden kurtulsak iyi olur.

We had better do away with such a fixed idea.

Ablative -DAn expresses many source/from relations and governed complements. A final voiceless stem consonant commonly selects t. Meaning depends on the governing phrase.

Why: Source suffix. [[Turkish#^tr-Q0240|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=B%C3%B6yle%20bir%20sabit%20fikirden%20kurtulsak%20iyi%20olur.)
^tr-Q0240-answer

**tr-Q0241** — Şirket adına, hepinize içten teşekkürlerimi sunmak isterim.

On behalf of the company, I would like to express our hearty thanks to you all.

Expected form: **içten**

Why: Source suffix. [[Turkish#^tr-Q0241|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=%C5%9Eirket%20ad%C4%B1na%2C%20hepinize%20i%C3%A7ten%20te%C5%9Fekk%C3%BCrlerimi%20sunmak%20isterim.)
^tr-Q0241-answer

**tr-Q0242** — Şirket adına, hepinize içten teşekkürlerimi sunmak isterim.

On behalf of the company, I would like to express our hearty thanks to you all.

Expected form: **içten**

Why: Source suffix. [[Turkish#^tr-Q0242|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=%C5%9Eirket%20ad%C4%B1na%2C%20hepinize%20i%C3%A7ten%20te%C5%9Fekk%C3%BCrlerimi%20sunmak%20isterim.)
^tr-Q0242-answer

**tr-Q0243** — Hangi boyutu alacağımdan emin değildim.

I wasn't sure what size to get.

Expected form: **alacağımdan**

Why: Source suffix. [[Turkish#^tr-Q0243|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Hangi%20boyutu%20alaca%C4%9F%C4%B1mdan%20emin%20de%C4%9Fildim.)
^tr-Q0243-answer

**tr-Q0244** — Hangi boyutu alacağımdan emin değildim.

I wasn't sure what size to get.

Why: Source suffix. [[Turkish#^tr-Q0244|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Hangi%20boyutu%20alaca%C4%9F%C4%B1mdan%20emin%20de%C4%9Fildim.)
^tr-Q0244-answer

**tr-Q0245** — Küçük ve köhne bir kasabada yetişen Tom, büyük şehre yerleştiğinde sudan çıkmış balığa dönmüştü.

Tom grew up in a one-horse town and was overwhelmed when he moved to the big smoke.

Why: Source suffix. [[Turkish#^tr-Q0245|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=K%C3%BC%C3%A7%C3%BCk%20ve%20k%C3%B6hne%20bir%20kasabada%20yeti%C5%9Fen%20Tom%2C%20b%C3%BCy%C3%BCk%20%C5%9Fehre%20yerle%C5%9Fti%C4%9Finde%20sudan%20%C3%A7%C4%B1km%C4%B1%C5%9F%20bal%C4%B1%C4%9Fa%20d%C3%B6nm%C3%BC%C5%9Ft%C3%BC.)
^tr-Q0245-answer

**tr-Q0246** — Küçük ve köhne bir kasabada yetişen Tom, büyük şehre yerleştiğinde sudan çıkmış balığa dönmüştü.

Tom grew up in a one-horse town and was overwhelmed when he moved to the big smoke.

Ablative -DAn expresses many source/from relations and governed complements. A final voiceless stem consonant commonly selects t. Meaning depends on the governing phrase.

Why: Source suffix. [[Turkish#^tr-Q0246|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=K%C3%BC%C3%A7%C3%BCk%20ve%20k%C3%B6hne%20bir%20kasabada%20yeti%C5%9Fen%20Tom%2C%20b%C3%BCy%C3%BCk%20%C5%9Fehre%20yerle%C5%9Fti%C4%9Finde%20sudan%20%C3%A7%C4%B1km%C4%B1%C5%9F%20bal%C4%B1%C4%9Fa%20d%C3%B6nm%C3%BC%C5%9Ft%C3%BC.)
^tr-Q0246-answer

**tr-Q0247** — Ona gerçeği söylemekten hoşlanmıyorum.

I don't like telling him the truth.

Expected form: **söylemekten**

Why: Source suffix. [[Turkish#^tr-Q0247|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ona%20ger%C3%A7e%C4%9Fi%20s%C3%B6ylemekten%20ho%C5%9Flanm%C4%B1yorum.)
^tr-Q0247-answer

**tr-Q0248** — Ona gerçeği söylemekten hoşlanmıyorum.

I don't like telling him the truth.

Expected form: **söylemekten**

Why: Source suffix. [[Turkish#^tr-Q0248|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ona%20ger%C3%A7e%C4%9Fi%20s%C3%B6ylemekten%20ho%C5%9Flanm%C4%B1yorum.)
^tr-Q0248-answer

**tr-Q0249** — İçtenlikle bundan şüphe ediyorum.

I sincerely doubt that.

Expected form: **bundan**

Why: Source suffix. [[Turkish#^tr-Q0249|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=%C4%B0%C3%A7tenlikle%20bundan%20%C5%9F%C3%BCphe%20ediyorum.)
^tr-Q0249-answer

**tr-Q0250** — İçtenlikle bundan şüphe ediyorum.

I sincerely doubt that.

Why: Source suffix. [[Turkish#^tr-Q0250|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=%C4%B0%C3%A7tenlikle%20bundan%20%C5%9F%C3%BCphe%20ediyorum.)
^tr-Q0250-answer


### Answers 251–300

**tr-Q0251** — Onları bulmak için sana ihtiyacım var.

I need you to find them.

Why: Accusative objects. [[Turkish#^tr-Q0251|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Onlar%C4%B1%20bulmak%20i%C3%A7in%20sana%20ihtiyac%C4%B1m%20var.)
^tr-Q0251-answer

**tr-Q0252** — Onları bulmak için sana ihtiyacım var.

I need you to find them.

Accusative commonly marks a specific/definite direct object. The suffix follows four-way harmony with a buffer y after a vowel in applicable nouns. Bare objects have different interpretations and positions.

Why: Accusative objects. [[Turkish#^tr-Q0252|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Onlar%C4%B1%20bulmak%20i%C3%A7in%20sana%20ihtiyac%C4%B1m%20var.)
^tr-Q0252-answer

**tr-Q0253** — Beni takip etmemeliydin.

You shouldn't have followed me.

Expected form: **Beni**

Why: Accusative objects. [[Turkish#^tr-Q0253|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Beni%20takip%20etmemeliydin.)
^tr-Q0253-answer

**tr-Q0254** — Beni takip etmemeliydin.

You shouldn't have followed me.

Expected form: **Beni**

Why: Accusative objects. [[Turkish#^tr-Q0254|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Beni%20takip%20etmemeliydin.)
^tr-Q0254-answer

**tr-Q0255** — Tom ona onu kimin söylediğini hatırlamıyor.

Tom doesn't remember who told him that.

Expected form: **onu**

Why: Accusative objects. [[Turkish#^tr-Q0255|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20ona%20onu%20kimin%20s%C3%B6yledi%C4%9Fini%20hat%C4%B1rlam%C4%B1yor.)
^tr-Q0255-answer

**tr-Q0256** — Tom ona onu kimin söylediğini hatırlamıyor.

Tom doesn't remember who told him that.

Why: Accusative objects. [[Turkish#^tr-Q0256|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20ona%20onu%20kimin%20s%C3%B6yledi%C4%9Fini%20hat%C4%B1rlam%C4%B1yor.)
^tr-Q0256-answer

**tr-Q0257** — Beni tanıdığına emin misin?

Are you sure that you know me?

Why: Accusative objects. [[Turkish#^tr-Q0257|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Beni%20tan%C4%B1d%C4%B1%C4%9F%C4%B1na%20emin%20misin%3F)
^tr-Q0257-answer

**tr-Q0258** — Beni tanıdığına emin misin?

Are you sure that you know me?

Accusative commonly marks a specific/definite direct object. The suffix follows four-way harmony with a buffer y after a vowel in applicable nouns. Bare objects have different interpretations and positions.

Why: Accusative objects. [[Turkish#^tr-Q0258|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Beni%20tan%C4%B1d%C4%B1%C4%9F%C4%B1na%20emin%20misin%3F)
^tr-Q0258-answer

**tr-Q0259** — Onu şimdi tartışmak yersiz olurdu.

It would be inappropriate to discuss that now.

Expected form: **Onu**

Why: Accusative objects. [[Turkish#^tr-Q0259|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Onu%20%C5%9Fimdi%20tart%C4%B1%C5%9Fmak%20yersiz%20olurdu.)
^tr-Q0259-answer

**tr-Q0260** — Onu şimdi tartışmak yersiz olurdu.

It would be inappropriate to discuss that now.

Expected form: **Onu**

Why: Accusative objects. [[Turkish#^tr-Q0260|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Onu%20%C5%9Fimdi%20tart%C4%B1%C5%9Fmak%20yersiz%20olurdu.)
^tr-Q0260-answer

**tr-Q0261** — Tom beni kesti.

Tom cut me off.

Expected form: **beni**

Why: Accusative objects. [[Turkish#^tr-Q0261|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20beni%20kesti.)
^tr-Q0261-answer

**tr-Q0262** — Tom beni kesti.

Tom cut me off.

Why: Accusative objects. [[Turkish#^tr-Q0262|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20beni%20kesti.)
^tr-Q0262-answer

**tr-Q0263** — Beni ne kadar bekledin?

How long did you wait for me?

Why: Accusative objects. [[Turkish#^tr-Q0263|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Beni%20ne%20kadar%20bekledin%3F)
^tr-Q0263-answer

**tr-Q0264** — Beni ne kadar bekledin?

How long did you wait for me?

Accusative commonly marks a specific/definite direct object. The suffix follows four-way harmony with a buffer y after a vowel in applicable nouns. Bare objects have different interpretations and positions.

Why: Accusative objects. [[Turkish#^tr-Q0264|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Beni%20ne%20kadar%20bekledin%3F)
^tr-Q0264-answer

**tr-Q0265** — Beni daha sonra ara.

Call me later.

Expected form: **Beni**

Why: Accusative objects. [[Turkish#^tr-Q0265|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Beni%20daha%20sonra%20ara.)
^tr-Q0265-answer

**tr-Q0266** — Beni daha sonra ara.

Call me later.

Expected form: **Beni**

Why: Accusative objects. [[Turkish#^tr-Q0266|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Beni%20daha%20sonra%20ara.)
^tr-Q0266-answer

**tr-Q0267** — Eğer zorlukların olursa beni ara.

Call me if you have difficulties.

Expected form: **beni**

Why: Accusative objects. [[Turkish#^tr-Q0267|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=E%C4%9Fer%20zorluklar%C4%B1n%20olursa%20beni%20ara.)
^tr-Q0267-answer

**tr-Q0268** — Eğer zorlukların olursa beni ara.

Call me if you have difficulties.

Why: Accusative objects. [[Turkish#^tr-Q0268|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=E%C4%9Fer%20zorluklar%C4%B1n%20olursa%20beni%20ara.)
^tr-Q0268-answer

**tr-Q0269** — Polis onu hapishaneye göndermekle tehdit etti.

The police threatened to send her to jail.

Why: Accusative objects. [[Turkish#^tr-Q0269|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Polis%20onu%20hapishaneye%20g%C3%B6ndermekle%20tehdit%20etti.)
^tr-Q0269-answer

**tr-Q0270** — Polis onu hapishaneye göndermekle tehdit etti.

The police threatened to send her to jail.

Accusative commonly marks a specific/definite direct object. The suffix follows four-way harmony with a buffer y after a vowel in applicable nouns. Bare objects have different interpretations and positions.

Why: Accusative objects. [[Turkish#^tr-Q0270|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Polis%20onu%20hapishaneye%20g%C3%B6ndermekle%20tehdit%20etti.)
^tr-Q0270-answer

**tr-Q0271** — Bir kalabalık onu görmek için bekledi.

A crowd waited to see him.

Expected form: **onu**

Why: Accusative objects. [[Turkish#^tr-Q0271|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bir%20kalabal%C4%B1k%20onu%20g%C3%B6rmek%20i%C3%A7in%20bekledi.)
^tr-Q0271-answer

**tr-Q0272** — Bir kalabalık onu görmek için bekledi.

A crowd waited to see him.

Expected form: **onu**

Why: Accusative objects. [[Turkish#^tr-Q0272|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bir%20kalabal%C4%B1k%20onu%20g%C3%B6rmek%20i%C3%A7in%20bekledi.)
^tr-Q0272-answer

**tr-Q0273** — Onu işe almaya karar verdik.

We've decided to hire him.

Expected form: **Onu**

Why: Accusative objects. [[Turkish#^tr-Q0273|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Onu%20i%C5%9Fe%20almaya%20karar%20verdik.)
^tr-Q0273-answer

**tr-Q0274** — Onu işe almaya karar verdik.

We've decided to hire him.

Why: Accusative objects. [[Turkish#^tr-Q0274|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Onu%20i%C5%9Fe%20almaya%20karar%20verdik.)
^tr-Q0274-answer

**tr-Q0275** — Onu o kuru incir torbasıyla yalnız bırakma.

Don't leave him alone with that bag of dried figs.

Why: Accusative objects. [[Turkish#^tr-Q0275|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Onu%20o%20kuru%20incir%20torbas%C4%B1yla%20yaln%C4%B1z%20b%C4%B1rakma.)
^tr-Q0275-answer

**tr-Q0276** — Onu o kuru incir torbasıyla yalnız bırakma.

Don't leave him alone with that bag of dried figs.

Accusative commonly marks a specific/definite direct object. The suffix follows four-way harmony with a buffer y after a vowel in applicable nouns. Bare objects have different interpretations and positions.

Why: Accusative objects. [[Turkish#^tr-Q0276|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Onu%20o%20kuru%20incir%20torbas%C4%B1yla%20yaln%C4%B1z%20b%C4%B1rakma.)
^tr-Q0276-answer

**tr-Q0277** — Beni kovamazsın, ayrılıyorum!

You can't fire me, I quit!

Expected form: **Beni**

Why: Accusative objects. [[Turkish#^tr-Q0277|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Beni%20kovamazs%C4%B1n%2C%20ayr%C4%B1l%C4%B1yorum%21)
^tr-Q0277-answer

**tr-Q0278** — Beni kovamazsın, ayrılıyorum!

You can't fire me, I quit!

Expected form: **Beni**

Why: Accusative objects. [[Turkish#^tr-Q0278|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Beni%20kovamazs%C4%B1n%2C%20ayr%C4%B1l%C4%B1yorum%21)
^tr-Q0278-answer

**tr-Q0279** — Şimdi onları görmek istemiyorum.

I don't want to see them now.

Expected form: **onları**

Why: Accusative objects. [[Turkish#^tr-Q0279|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=%C5%9Eimdi%20onlar%C4%B1%20g%C3%B6rmek%20istemiyorum.)
^tr-Q0279-answer

**tr-Q0280** — Şimdi onları görmek istemiyorum.

I don't want to see them now.

Why: Accusative objects. [[Turkish#^tr-Q0280|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=%C5%9Eimdi%20onlar%C4%B1%20g%C3%B6rmek%20istemiyorum.)
^tr-Q0280-answer

**tr-Q0281** — Onu kendim gördüm.

I've seen it myself.

Why: Accusative objects. [[Turkish#^tr-Q0281|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Onu%20kendim%20g%C3%B6rd%C3%BCm.)
^tr-Q0281-answer

**tr-Q0282** — Onu kendim gördüm.

I've seen it myself.

Accusative commonly marks a specific/definite direct object. The suffix follows four-way harmony with a buffer y after a vowel in applicable nouns. Bare objects have different interpretations and positions.

Why: Accusative objects. [[Turkish#^tr-Q0282|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Onu%20kendim%20g%C3%B6rd%C3%BCm.)
^tr-Q0282-answer

**tr-Q0283** — Bak, bu bir kayıt noktası! Onu istediğini biliyorsun!

Look, it's a save point! You know you want it!

Expected form: **Onu**

Why: Accusative objects. [[Turkish#^tr-Q0283|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bak%2C%20bu%20bir%20kay%C4%B1t%20noktas%C4%B1%21%20Onu%20istedi%C4%9Fini%20biliyorsun%21)
^tr-Q0283-answer

**tr-Q0284** — Bak, bu bir kayıt noktası! Onu istediğini biliyorsun!

Look, it's a save point! You know you want it!

Expected form: **Onu**

Why: Accusative objects. [[Turkish#^tr-Q0284|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bak%2C%20bu%20bir%20kay%C4%B1t%20noktas%C4%B1%21%20Onu%20istedi%C4%9Fini%20biliyorsun%21)
^tr-Q0284-answer

**tr-Q0285** — Onu hava yoluyla gönderirsem, kaça mal olur.

If I send it by air mail, how much will it cost?

Expected form: **Onu**

Why: Accusative objects. [[Turkish#^tr-Q0285|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Onu%20hava%20yoluyla%20g%C3%B6nderirsem%2C%20ka%C3%A7a%20mal%20olur.)
^tr-Q0285-answer

**tr-Q0286** — Onu hava yoluyla gönderirsem, kaça mal olur.

If I send it by air mail, how much will it cost?

Why: Accusative objects. [[Turkish#^tr-Q0286|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Onu%20hava%20yoluyla%20g%C3%B6nderirsem%2C%20ka%C3%A7a%20mal%20olur.)
^tr-Q0286-answer

**tr-Q0287** — Üzgünüm, yönetici sizi göremeyecek. O meşgul.

I'm sorry, the manager won't be able to see you. He's engaged.

Why: Accusative objects. [[Turkish#^tr-Q0287|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=%C3%9Czg%C3%BCn%C3%BCm%2C%20y%C3%B6netici%20sizi%20g%C3%B6remeyecek.%20O%20me%C5%9Fgul.)
^tr-Q0287-answer

**tr-Q0288** — Üzgünüm, yönetici sizi göremeyecek. O meşgul.

I'm sorry, the manager won't be able to see you. He's engaged.

Accusative commonly marks a specific/definite direct object. The suffix follows four-way harmony with a buffer y after a vowel in applicable nouns. Bare objects have different interpretations and positions.

Why: Accusative objects. [[Turkish#^tr-Q0288|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=%C3%9Czg%C3%BCn%C3%BCm%2C%20y%C3%B6netici%20sizi%20g%C3%B6remeyecek.%20O%20me%C5%9Fgul.)
^tr-Q0288-answer

**tr-Q0289** — Belki onu tekrar yapmamalısın.

Maybe you shouldn't do that again.

Expected form: **onu**

Why: Accusative objects. [[Turkish#^tr-Q0289|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Belki%20onu%20tekrar%20yapmamal%C4%B1s%C4%B1n.)
^tr-Q0289-answer

**tr-Q0290** — Belki onu tekrar yapmamalısın.

Maybe you shouldn't do that again.

Expected form: **onu**

Why: Accusative objects. [[Turkish#^tr-Q0290|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Belki%20onu%20tekrar%20yapmamal%C4%B1s%C4%B1n.)
^tr-Q0290-answer

**tr-Q0291** — Onun utancı onu yapmasını engelledi.

His shame prevented him from doing that.

Expected form: **onu**

Why: Accusative objects. [[Turkish#^tr-Q0291|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Onun%20utanc%C4%B1%20onu%20yapmas%C4%B1n%C4%B1%20engelledi.)
^tr-Q0291-answer

**tr-Q0292** — Onun utancı onu yapmasını engelledi.

His shame prevented him from doing that.

Why: Accusative objects. [[Turkish#^tr-Q0292|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Onun%20utanc%C4%B1%20onu%20yapmas%C4%B1n%C4%B1%20engelledi.)
^tr-Q0292-answer

**tr-Q0293** — Tom yardım etmek istemiyordu ve Mary yardım etmesi için onu ikna edemedi.

Tom didn't want to help and Mary couldn't persuade him to.

Why: Accusative objects. [[Turkish#^tr-Q0293|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20yard%C4%B1m%20etmek%20istemiyordu%20ve%20Mary%20yard%C4%B1m%20etmesi%20i%C3%A7in%20onu%20ikna%20edemedi.)
^tr-Q0293-answer

**tr-Q0294** — Tom yardım etmek istemiyordu ve Mary yardım etmesi için onu ikna edemedi.

Tom didn't want to help and Mary couldn't persuade him to.

Accusative commonly marks a specific/definite direct object. The suffix follows four-way harmony with a buffer y after a vowel in applicable nouns. Bare objects have different interpretations and positions.

Why: Accusative objects. [[Turkish#^tr-Q0294|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20yard%C4%B1m%20etmek%20istemiyordu%20ve%20Mary%20yard%C4%B1m%20etmesi%20i%C3%A7in%20onu%20ikna%20edemedi.)
^tr-Q0294-answer

**tr-Q0295** — Sizi görmek için sabırsızlanıyoruz.

We are looking forward to seeing you.

Expected form: **Sizi**

Why: Accusative objects. [[Turkish#^tr-Q0295|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Sizi%20g%C3%B6rmek%20i%C3%A7in%20sab%C4%B1rs%C4%B1zlan%C4%B1yoruz.)
^tr-Q0295-answer

**tr-Q0296** — Sizi görmek için sabırsızlanıyoruz.

We are looking forward to seeing you.

Expected form: **Sizi**

Why: Accusative objects. [[Turkish#^tr-Q0296|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Sizi%20g%C3%B6rmek%20i%C3%A7in%20sab%C4%B1rs%C4%B1zlan%C4%B1yoruz.)
^tr-Q0296-answer

**tr-Q0297** — Tom ne zaman onu yapmanı öğretti?

When did Tom teach you to do that?

Expected form: **onu**

Why: Accusative objects. [[Turkish#^tr-Q0297|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20ne%20zaman%20onu%20yapman%C4%B1%20%C3%B6%C4%9Fretti%3F)
^tr-Q0297-answer

**tr-Q0298** — Tom ne zaman onu yapmanı öğretti?

When did Tom teach you to do that?

Why: Accusative objects. [[Turkish#^tr-Q0298|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20ne%20zaman%20onu%20yapman%C4%B1%20%C3%B6%C4%9Fretti%3F)
^tr-Q0298-answer

**tr-Q0299** — Keşke onu sormayı bıraksan.

I wish you'd stop asking that.

Why: Accusative objects. [[Turkish#^tr-Q0299|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ke%C5%9Fke%20onu%20sormay%C4%B1%20b%C4%B1raksan.)
^tr-Q0299-answer

**tr-Q0300** — Keşke onu sormayı bıraksan.

I wish you'd stop asking that.

Accusative commonly marks a specific/definite direct object. The suffix follows four-way harmony with a buffer y after a vowel in applicable nouns. Bare objects have different interpretations and positions.

Why: Accusative objects. [[Turkish#^tr-Q0300|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ke%C5%9Fke%20onu%20sormay%C4%B1%20b%C4%B1raksan.)
^tr-Q0300-answer


### Answers 301–350

**tr-Q0301** — Bir daha bana asla dokunma.

Don't you ever touch me again.

Expected form: **bana**

Why: Dative direction. [[Turkish#^tr-Q0301|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bir%20daha%20bana%20asla%20dokunma.)
^tr-Q0301-answer

**tr-Q0302** — Bir daha bana asla dokunma.

Don't you ever touch me again.

Expected form: **bana**

Why: Dative direction. [[Turkish#^tr-Q0302|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bir%20daha%20bana%20asla%20dokunma.)
^tr-Q0302-answer

**tr-Q0303** — Bana dinlenmek için zaman verin.

Give me time to relax.

Expected form: **Bana**

Why: Dative direction. [[Turkish#^tr-Q0303|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bana%20dinlenmek%20i%C3%A7in%20zaman%20verin.)
^tr-Q0303-answer

**tr-Q0304** — Bana dinlenmek için zaman verin.

Give me time to relax.

Why: Dative direction. [[Turkish#^tr-Q0304|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bana%20dinlenmek%20i%C3%A7in%20zaman%20verin.)
^tr-Q0304-answer

**tr-Q0305** — Bunu onlara veremem.

I can't give it to them.

Why: Dative direction. [[Turkish#^tr-Q0305|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bunu%20onlara%20veremem.)
^tr-Q0305-answer

**tr-Q0306** — Bunu onlara veremem.

I can't give it to them.

Dative -A marks many destinations and recipients. Ben/sen have irregular bana/sana forms. English to maps to several Turkish constructions, so learn verb government.

Why: Dative direction. [[Turkish#^tr-Q0306|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bunu%20onlara%20veremem.)
^tr-Q0306-answer

**tr-Q0307** — Bir seçeneğim olsa şimdi eve giderim.

If I had a choice, I'd go home now.

Expected form: **eve**

Why: Dative direction. [[Turkish#^tr-Q0307|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bir%20se%C3%A7ene%C4%9Fim%20olsa%20%C5%9Fimdi%20eve%20giderim.)
^tr-Q0307-answer

**tr-Q0308** — Bir seçeneğim olsa şimdi eve giderim.

If I had a choice, I'd go home now.

Expected form: **eve**

Why: Dative direction. [[Turkish#^tr-Q0308|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bir%20se%C3%A7ene%C4%9Fim%20olsa%20%C5%9Fimdi%20eve%20giderim.)
^tr-Q0308-answer

**tr-Q0309** — Ona bir hayat bulmasını söyle.

Tell him to get a life.

Expected form: **Ona**

Why: Dative direction. [[Turkish#^tr-Q0309|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ona%20bir%20hayat%20bulmas%C4%B1n%C4%B1%20s%C3%B6yle.)
^tr-Q0309-answer

**tr-Q0310** — Ona bir hayat bulmasını söyle.

Tell him to get a life.

Why: Dative direction. [[Turkish#^tr-Q0310|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ona%20bir%20hayat%20bulmas%C4%B1n%C4%B1%20s%C3%B6yle.)
^tr-Q0310-answer

**tr-Q0311** — Tom bana Harvard'a girmeyi umduğunu söyledi.

Tom told me he was hoping to get into Harvard.

Why: Dative direction. [[Turkish#^tr-Q0311|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20bana%20Harvard%27a%20girmeyi%20umdu%C4%9Funu%20s%C3%B6yledi.)
^tr-Q0311-answer

**tr-Q0312** — Tom bana Harvard'a girmeyi umduğunu söyledi.

Tom told me he was hoping to get into Harvard.

Dative -A marks many destinations and recipients. Ben/sen have irregular bana/sana forms. English to maps to several Turkish constructions, so learn verb government.

Why: Dative direction. [[Turkish#^tr-Q0312|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20bana%20Harvard%27a%20girmeyi%20umdu%C4%9Funu%20s%C3%B6yledi.)
^tr-Q0312-answer

**tr-Q0313** — Tom bana bir yalan söyledi.

Tom told me a lie.

Expected form: **bana**

Why: Dative direction. [[Turkish#^tr-Q0313|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20bana%20bir%20yalan%20s%C3%B6yledi.)
^tr-Q0313-answer

**tr-Q0314** — Tom bana bir yalan söyledi.

Tom told me a lie.

Expected form: **bana**

Why: Dative direction. [[Turkish#^tr-Q0314|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20bana%20bir%20yalan%20s%C3%B6yledi.)
^tr-Q0314-answer

**tr-Q0315** — Eliimden geldiğince kısa sürede size geri ödeyeceğim.

I'll pay you back as soon as I can.

Expected form: **size**

Why: Dative direction. [[Turkish#^tr-Q0315|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Eliimden%20geldi%C4%9Fince%20k%C4%B1sa%20s%C3%BCrede%20size%20geri%20%C3%B6deyece%C4%9Fim.)
^tr-Q0315-answer

**tr-Q0316** — Eliimden geldiğince kısa sürede size geri ödeyeceğim.

I'll pay you back as soon as I can.

Why: Dative direction. [[Turkish#^tr-Q0316|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Eliimden%20geldi%C4%9Fince%20k%C4%B1sa%20s%C3%BCrede%20size%20geri%20%C3%B6deyece%C4%9Fim.)
^tr-Q0316-answer

**tr-Q0317** — Önceden ona söyledin mi?

Have you told him already?

Why: Dative direction. [[Turkish#^tr-Q0317|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=%C3%96nceden%20ona%20s%C3%B6yledin%20mi%3F)
^tr-Q0317-answer

**tr-Q0318** — Önceden ona söyledin mi?

Have you told him already?

Dative -A marks many destinations and recipients. Ben/sen have irregular bana/sana forms. English to maps to several Turkish constructions, so learn verb government.

Why: Dative direction. [[Turkish#^tr-Q0318|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=%C3%96nceden%20ona%20s%C3%B6yledin%20mi%3F)
^tr-Q0318-answer

**tr-Q0319** — Ona yardım etmeye gideceğim.

I'll go and give her a hand.

Expected form: **Ona**

Why: Dative direction. [[Turkish#^tr-Q0319|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ona%20yard%C4%B1m%20etmeye%20gidece%C4%9Fim.)
^tr-Q0319-answer

**tr-Q0320** — Ona yardım etmeye gideceğim.

I'll go and give her a hand.

Expected form: **Ona**

Why: Dative direction. [[Turkish#^tr-Q0320|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ona%20yard%C4%B1m%20etmeye%20gidece%C4%9Fim.)
^tr-Q0320-answer

**tr-Q0321** — Ona bir şey söylemeliyim.

I need to tell him something.

Expected form: **Ona**

Why: Dative direction. [[Turkish#^tr-Q0321|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ona%20bir%20%C5%9Fey%20s%C3%B6ylemeliyim.)
^tr-Q0321-answer

**tr-Q0322** — Ona bir şey söylemeliyim.

I need to tell him something.

Why: Dative direction. [[Turkish#^tr-Q0322|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ona%20bir%20%C5%9Fey%20s%C3%B6ylemeliyim.)
^tr-Q0322-answer

**tr-Q0323** — Ona bizim hakkımızda ne söyledin?

What did you tell him about us?

Why: Dative direction. [[Turkish#^tr-Q0323|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ona%20bizim%20hakk%C4%B1m%C4%B1zda%20ne%20s%C3%B6yledin%3F)
^tr-Q0323-answer

**tr-Q0324** — Ona bizim hakkımızda ne söyledin?

What did you tell him about us?

Dative -A marks many destinations and recipients. Ben/sen have irregular bana/sana forms. English to maps to several Turkish constructions, so learn verb government.

Why: Dative direction. [[Turkish#^tr-Q0324|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ona%20bizim%20hakk%C4%B1m%C4%B1zda%20ne%20s%C3%B6yledin%3F)
^tr-Q0324-answer

**tr-Q0325** — Tom bana yardım etmedi.

Tom wouldn't help me.

Expected form: **bana**

Why: Dative direction. [[Turkish#^tr-Q0325|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20bana%20yard%C4%B1m%20etmedi.)
^tr-Q0325-answer

**tr-Q0326** — Tom bana yardım etmedi.

Tom wouldn't help me.

Expected form: **bana**

Why: Dative direction. [[Turkish#^tr-Q0326|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20bana%20yard%C4%B1m%20etmedi.)
^tr-Q0326-answer

**tr-Q0327** — Kız kardeşinin aksine, o, ebeveynlerinin ona verdiği dini inancı korudu.

Unlike his sister, he has retained the religious faith his parents brought him up in.

Expected form: **ona**

Why: Dative direction. [[Turkish#^tr-Q0327|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=K%C4%B1z%20karde%C5%9Finin%20aksine%2C%20o%2C%20ebeveynlerinin%20ona%20verdi%C4%9Fi%20dini%20inanc%C4%B1%20korudu.)
^tr-Q0327-answer

**tr-Q0328** — Kız kardeşinin aksine, o, ebeveynlerinin ona verdiği dini inancı korudu.

Unlike his sister, he has retained the religious faith his parents brought him up in.

Why: Dative direction. [[Turkish#^tr-Q0328|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=K%C4%B1z%20karde%C5%9Finin%20aksine%2C%20o%2C%20ebeveynlerinin%20ona%20verdi%C4%9Fi%20dini%20inanc%C4%B1%20korudu.)
^tr-Q0328-answer

**tr-Q0329** — Onlara yardım edecek miyiz?

Are we going to help them?

Why: Dative direction. [[Turkish#^tr-Q0329|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Onlara%20yard%C4%B1m%20edecek%20miyiz%3F)
^tr-Q0329-answer

**tr-Q0330** — Onlara yardım edecek miyiz?

Are we going to help them?

Dative -A marks many destinations and recipients. Ben/sen have irregular bana/sana forms. English to maps to several Turkish constructions, so learn verb government.

Why: Dative direction. [[Turkish#^tr-Q0330|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Onlara%20yard%C4%B1m%20edecek%20miyiz%3F)
^tr-Q0330-answer

**tr-Q0331** — Tom sana ne zaman geleceğini söyledi mi?

Did Tom say when he'd arrive?

Expected form: **sana**

Why: Dative direction. [[Turkish#^tr-Q0331|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20sana%20ne%20zaman%20gelece%C4%9Fini%20s%C3%B6yledi%20mi%3F)
^tr-Q0331-answer

**tr-Q0332** — Tom sana ne zaman geleceğini söyledi mi?

Did Tom say when he'd arrive?

Expected form: **sana**

Why: Dative direction. [[Turkish#^tr-Q0332|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20sana%20ne%20zaman%20gelece%C4%9Fini%20s%C3%B6yledi%20mi%3F)
^tr-Q0332-answer

**tr-Q0333** — Bize yardım edebileceğini umuyorum.

I hope you can help us.

Expected form: **Bize**

Why: Dative direction. [[Turkish#^tr-Q0333|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bize%20yard%C4%B1m%20edebilece%C4%9Fini%20umuyorum.)
^tr-Q0333-answer

**tr-Q0334** — Bize yardım edebileceğini umuyorum.

I hope you can help us.

Why: Dative direction. [[Turkish#^tr-Q0334|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bize%20yard%C4%B1m%20edebilece%C4%9Fini%20umuyorum.)
^tr-Q0334-answer

**tr-Q0335** — Karabiber değirmenini bana uzat.

Pass me the pepper grinder.

Why: Dative direction. [[Turkish#^tr-Q0335|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Karabiber%20de%C4%9Firmenini%20bana%20uzat.)
^tr-Q0335-answer

**tr-Q0336** — Karabiber değirmenini bana uzat.

Pass me the pepper grinder.

Dative -A marks many destinations and recipients. Ben/sen have irregular bana/sana forms. English to maps to several Turkish constructions, so learn verb government.

Why: Dative direction. [[Turkish#^tr-Q0336|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Karabiber%20de%C4%9Firmenini%20bana%20uzat.)
^tr-Q0336-answer

**tr-Q0337** — Üzgünüm, ben size yardımcı olamam.

I'm sorry, I can't help you.

Expected form: **size**

Why: Dative direction. [[Turkish#^tr-Q0337|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=%C3%9Czg%C3%BCn%C3%BCm%2C%20ben%20size%20yard%C4%B1mc%C4%B1%20olamam.)
^tr-Q0337-answer

**tr-Q0338** — Üzgünüm, ben size yardımcı olamam.

I'm sorry, I can't help you.

Expected form: **size**

Why: Dative direction. [[Turkish#^tr-Q0338|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=%C3%9Czg%C3%BCn%C3%BCm%2C%20ben%20size%20yard%C4%B1mc%C4%B1%20olamam.)
^tr-Q0338-answer

**tr-Q0339** — Sana nasıl yardım edebiliriz?

How can we help you?

Expected form: **Sana**

Why: Dative direction. [[Turkish#^tr-Q0339|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Sana%20nas%C4%B1l%20yard%C4%B1m%20edebiliriz%3F)
^tr-Q0339-answer

**tr-Q0340** — Sana nasıl yardım edebiliriz?

How can we help you?

Why: Dative direction. [[Turkish#^tr-Q0340|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Sana%20nas%C4%B1l%20yard%C4%B1m%20edebiliriz%3F)
^tr-Q0340-answer

**tr-Q0341** — Bize yardım etmeye karar verdiğine gerçekten çok sevindik.

We're really glad you decided to help us.

Why: Dative direction. [[Turkish#^tr-Q0341|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bize%20yard%C4%B1m%20etmeye%20karar%20verdi%C4%9Fine%20ger%C3%A7ekten%20%C3%A7ok%20sevindik.)
^tr-Q0341-answer

**tr-Q0342** — Bize yardım etmeye karar verdiğine gerçekten çok sevindik.

We're really glad you decided to help us.

Dative -A marks many destinations and recipients. Ben/sen have irregular bana/sana forms. English to maps to several Turkish constructions, so learn verb government.

Why: Dative direction. [[Turkish#^tr-Q0342|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bize%20yard%C4%B1m%20etmeye%20karar%20verdi%C4%9Fine%20ger%C3%A7ekten%20%C3%A7ok%20sevindik.)
^tr-Q0342-answer

**tr-Q0343** — Tom bana tekrar yazmadı.

Tom hasn't written me back.

Expected form: **bana**

Why: Dative direction. [[Turkish#^tr-Q0343|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20bana%20tekrar%20yazmad%C4%B1.)
^tr-Q0343-answer

**tr-Q0344** — Tom bana tekrar yazmadı.

Tom hasn't written me back.

Expected form: **bana**

Why: Dative direction. [[Turkish#^tr-Q0344|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20bana%20tekrar%20yazmad%C4%B1.)
^tr-Q0344-answer

**tr-Q0345** — Bu bana bir ders verdi.

It taught me a lesson.

Expected form: **bana**

Why: Dative direction. [[Turkish#^tr-Q0345|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bu%20bana%20bir%20ders%20verdi.)
^tr-Q0345-answer

**tr-Q0346** — Bu bana bir ders verdi.

It taught me a lesson.

Why: Dative direction. [[Turkish#^tr-Q0346|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bu%20bana%20bir%20ders%20verdi.)
^tr-Q0346-answer

**tr-Q0347** — O bana alana ihtiyacı olduğunu söyledi.

He told me that he needs space.

Why: Dative direction. [[Turkish#^tr-Q0347|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=O%20bana%20alana%20ihtiyac%C4%B1%20oldu%C4%9Funu%20s%C3%B6yledi.)
^tr-Q0347-answer

**tr-Q0348** — O bana alana ihtiyacı olduğunu söyledi.

He told me that he needs space.

Dative -A marks many destinations and recipients. Ben/sen have irregular bana/sana forms. English to maps to several Turkish constructions, so learn verb government.

Why: Dative direction. [[Turkish#^tr-Q0348|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=O%20bana%20alana%20ihtiyac%C4%B1%20oldu%C4%9Funu%20s%C3%B6yledi.)
^tr-Q0348-answer

**tr-Q0349** — Tom sana bir şans daha verecek.

Tom will give you another chance.

Expected form: **sana**

Why: Dative direction. [[Turkish#^tr-Q0349|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20sana%20bir%20%C5%9Fans%20daha%20verecek.)
^tr-Q0349-answer

**tr-Q0350** — Tom sana bir şans daha verecek.

Tom will give you another chance.

Expected form: **sana**

Why: Dative direction. [[Turkish#^tr-Q0350|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20sana%20bir%20%C5%9Fans%20daha%20verecek.)
^tr-Q0350-answer


### Answers 351–400

**tr-Q0351** — Onun tekrar olmasına izin vermeyeceğine güveniyorum.

I trust you won't let that happen again.

Expected form: **Onun**

Why: Possession and genitive. [[Turkish#^tr-Q0351|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Onun%20tekrar%20olmas%C4%B1na%20izin%20vermeyece%C4%9Fine%20g%C3%BCveniyorum.)
^tr-Q0351-answer

**tr-Q0352** — Onun tekrar olmasına izin vermeyeceğine güveniyorum.

I trust you won't let that happen again.

Why: Possession and genitive. [[Turkish#^tr-Q0352|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Onun%20tekrar%20olmas%C4%B1na%20izin%20vermeyece%C4%9Fine%20g%C3%BCveniyorum.)
^tr-Q0352-answer

**tr-Q0353** — Benim bir atım var.

I own a horse.

Why: Possession and genitive. [[Turkish#^tr-Q0353|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Benim%20bir%20at%C4%B1m%20var.)
^tr-Q0353-answer

**tr-Q0354** — Benim bir atım var.

I own a horse.

A genitive possessor commonly pairs with a possessive suffix on the possessed noun. Benim kitabım means my book. A possessive relationship is not expressed just by juxtaposing two unchanged nouns.

Why: Possession and genitive. [[Turkish#^tr-Q0354|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Benim%20bir%20at%C4%B1m%20var.)
^tr-Q0354-answer

**tr-Q0355** — Benim şirketim var.

I've got company.

Expected form: **Benim**

Why: Possession and genitive. [[Turkish#^tr-Q0355|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Benim%20%C5%9Firketim%20var.)
^tr-Q0355-answer

**tr-Q0356** — Benim şirketim var.

I've got company.

Expected form: **Benim**

Why: Possession and genitive. [[Turkish#^tr-Q0356|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Benim%20%C5%9Firketim%20var.)
^tr-Q0356-answer

**tr-Q0357** — Senin ve Tom'un dövüştüğüne üzgünüm.

I'm sorry that you and Tom had a fight.

Expected form: **Senin**

Why: Possession and genitive. [[Turkish#^tr-Q0357|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Senin%20ve%20Tom%27un%20d%C3%B6v%C3%BC%C5%9Ft%C3%BC%C4%9F%C3%BCne%20%C3%BCzg%C3%BCn%C3%BCm.)
^tr-Q0357-answer

**tr-Q0358** — Senin ve Tom'un dövüştüğüne üzgünüm.

I'm sorry that you and Tom had a fight.

Why: Possession and genitive. [[Turkish#^tr-Q0358|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Senin%20ve%20Tom%27un%20d%C3%B6v%C3%BC%C5%9Ft%C3%BC%C4%9F%C3%BCne%20%C3%BCzg%C3%BCn%C3%BCm.)
^tr-Q0358-answer

**tr-Q0359** — Tom benim değerli bir arkadaşım.

Tom is a dear friend of mine.

Why: Possession and genitive. [[Turkish#^tr-Q0359|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20benim%20de%C4%9Ferli%20bir%20arkada%C5%9F%C4%B1m.)
^tr-Q0359-answer

**tr-Q0360** — Tom benim değerli bir arkadaşım.

Tom is a dear friend of mine.

A genitive possessor commonly pairs with a possessive suffix on the possessed noun. Benim kitabım means my book. A possessive relationship is not expressed just by juxtaposing two unchanged nouns.

Why: Possession and genitive. [[Turkish#^tr-Q0360|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20benim%20de%C4%9Ferli%20bir%20arkada%C5%9F%C4%B1m.)
^tr-Q0360-answer

**tr-Q0361** — Benim dört çocuğum var.

I have four children.

Expected form: **Benim**

Why: Possession and genitive. [[Turkish#^tr-Q0361|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Benim%20d%C3%B6rt%20%C3%A7ocu%C4%9Fum%20var.)
^tr-Q0361-answer

**tr-Q0362** — Benim dört çocuğum var.

I have four children.

Expected form: **Benim**

Why: Possession and genitive. [[Turkish#^tr-Q0362|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Benim%20d%C3%B6rt%20%C3%A7ocu%C4%9Fum%20var.)
^tr-Q0362-answer

**tr-Q0363** — Onların yardıma ihtiyacı var.

They need help.

Expected form: **Onların**

Why: Possession and genitive. [[Turkish#^tr-Q0363|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Onlar%C4%B1n%20yard%C4%B1ma%20ihtiyac%C4%B1%20var.)
^tr-Q0363-answer

**tr-Q0364** — Onların yardıma ihtiyacı var.

They need help.

Why: Possession and genitive. [[Turkish#^tr-Q0364|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Onlar%C4%B1n%20yard%C4%B1ma%20ihtiyac%C4%B1%20var.)
^tr-Q0364-answer

**tr-Q0365** — Neden hep onun tarafını tutuyorsun?

Why do you always take her side?

Why: Possession and genitive. [[Turkish#^tr-Q0365|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Neden%20hep%20onun%20taraf%C4%B1n%C4%B1%20tutuyorsun%3F)
^tr-Q0365-answer

**tr-Q0366** — Neden hep onun tarafını tutuyorsun?

Why do you always take her side?

A genitive possessor commonly pairs with a possessive suffix on the possessed noun. Benim kitabım means my book. A possessive relationship is not expressed just by juxtaposing two unchanged nouns.

Why: Possession and genitive. [[Turkish#^tr-Q0366|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Neden%20hep%20onun%20taraf%C4%B1n%C4%B1%20tutuyorsun%3F)
^tr-Q0366-answer

**tr-Q0367** — Onların Meclis'te çoğunluğu vardı.

They had the majority in Parliament.

Expected form: **Onların**

Why: Possession and genitive. [[Turkish#^tr-Q0367|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Onlar%C4%B1n%20Meclis%27te%20%C3%A7o%C4%9Funlu%C4%9Fu%20vard%C4%B1.)
^tr-Q0367-answer

**tr-Q0368** — Onların Meclis'te çoğunluğu vardı.

They had the majority in Parliament.

Expected form: **Onların**

Why: Possession and genitive. [[Turkish#^tr-Q0368|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Onlar%C4%B1n%20Meclis%27te%20%C3%A7o%C4%9Funlu%C4%9Fu%20vard%C4%B1.)
^tr-Q0368-answer

**tr-Q0369** — Tom'un konuşma şekli benim sinirlerimi bozuyor.

Tom's way of speaking gets on my nerves.

Expected form: **benim**

Why: Possession and genitive. [[Turkish#^tr-Q0369|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%27un%20konu%C5%9Fma%20%C5%9Fekli%20benim%20sinirlerimi%20bozuyor.)
^tr-Q0369-answer

**tr-Q0370** — Tom'un konuşma şekli benim sinirlerimi bozuyor.

Tom's way of speaking gets on my nerves.

Why: Possession and genitive. [[Turkish#^tr-Q0370|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%27un%20konu%C5%9Fma%20%C5%9Fekli%20benim%20sinirlerimi%20bozuyor.)
^tr-Q0370-answer

**tr-Q0371** — Onun ebeveynleri şehir dışındaydı.

Her parents were out of town.

Why: Possession and genitive. [[Turkish#^tr-Q0371|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Onun%20ebeveynleri%20%C5%9Fehir%20d%C4%B1%C5%9F%C4%B1ndayd%C4%B1.)
^tr-Q0371-answer

**tr-Q0372** — Onun ebeveynleri şehir dışındaydı.

Her parents were out of town.

A genitive possessor commonly pairs with a possessive suffix on the possessed noun. Benim kitabım means my book. A possessive relationship is not expressed just by juxtaposing two unchanged nouns.

Why: Possession and genitive. [[Turkish#^tr-Q0372|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Onun%20ebeveynleri%20%C5%9Fehir%20d%C4%B1%C5%9F%C4%B1ndayd%C4%B1.)
^tr-Q0372-answer

**tr-Q0373** — Onun ne kadar süreceği hakkında hiçbir fikrim yok.

I have no idea how long it will take.

Expected form: **Onun**

Why: Possession and genitive. [[Turkish#^tr-Q0373|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Onun%20ne%20kadar%20s%C3%BCrece%C4%9Fi%20hakk%C4%B1nda%20hi%C3%A7bir%20fikrim%20yok.)
^tr-Q0373-answer

**tr-Q0374** — Onun ne kadar süreceği hakkında hiçbir fikrim yok.

I have no idea how long it will take.

Expected form: **Onun**

Why: Possession and genitive. [[Turkish#^tr-Q0374|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Onun%20ne%20kadar%20s%C3%BCrece%C4%9Fi%20hakk%C4%B1nda%20hi%C3%A7bir%20fikrim%20yok.)
^tr-Q0374-answer

**tr-Q0375** — Gelecek kış onların kısa sürede unutmayacakları bir kış olacak.

The coming winter would be one they would not soon forget.

Expected form: **onların**

Why: Possession and genitive. [[Turkish#^tr-Q0375|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Gelecek%20k%C4%B1%C5%9F%20onlar%C4%B1n%20k%C4%B1sa%20s%C3%BCrede%20unutmayacaklar%C4%B1%20bir%20k%C4%B1%C5%9F%20olacak.)
^tr-Q0375-answer

**tr-Q0376** — Gelecek kış onların kısa sürede unutmayacakları bir kış olacak.

The coming winter would be one they would not soon forget.

Why: Possession and genitive. [[Turkish#^tr-Q0376|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Gelecek%20k%C4%B1%C5%9F%20onlar%C4%B1n%20k%C4%B1sa%20s%C3%BCrede%20unutmayacaklar%C4%B1%20bir%20k%C4%B1%C5%9F%20olacak.)
^tr-Q0376-answer

**tr-Q0377** — Senin harp çalmayı bırakmana inanamıyorum.

I can't believe you quit playing harp.

Why: Possession and genitive. [[Turkish#^tr-Q0377|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Senin%20harp%20%C3%A7almay%C4%B1%20b%C4%B1rakmana%20inanam%C4%B1yorum.)
^tr-Q0377-answer

**tr-Q0378** — Senin harp çalmayı bırakmana inanamıyorum.

I can't believe you quit playing harp.

A genitive possessor commonly pairs with a possessive suffix on the possessed noun. Benim kitabım means my book. A possessive relationship is not expressed just by juxtaposing two unchanged nouns.

Why: Possession and genitive. [[Turkish#^tr-Q0378|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Senin%20harp%20%C3%A7almay%C4%B1%20b%C4%B1rakmana%20inanam%C4%B1yorum.)
^tr-Q0378-answer

**tr-Q0379** — Onun hepsi dosyada.

It's all in the file.

Expected form: **Onun**

Why: Possession and genitive. [[Turkish#^tr-Q0379|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Onun%20hepsi%20dosyada.)
^tr-Q0379-answer

**tr-Q0380** — Onun hepsi dosyada.

It's all in the file.

Expected form: **Onun**

Why: Possession and genitive. [[Turkish#^tr-Q0380|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Onun%20hepsi%20dosyada.)
^tr-Q0380-answer

**tr-Q0381** — Bir konferansta senin eski işverenini gördün, değil mi?

You saw your former employer at a conference, didn't you?

Expected form: **senin**

Why: Possession and genitive. [[Turkish#^tr-Q0381|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bir%20konferansta%20senin%20eski%20i%C5%9Fverenini%20g%C3%B6rd%C3%BCn%2C%20de%C4%9Fil%20mi%3F)
^tr-Q0381-answer

**tr-Q0382** — Bir konferansta senin eski işverenini gördün, değil mi?

You saw your former employer at a conference, didn't you?

Why: Possession and genitive. [[Turkish#^tr-Q0382|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bir%20konferansta%20senin%20eski%20i%C5%9Fverenini%20g%C3%B6rd%C3%BCn%2C%20de%C4%9Fil%20mi%3F)
^tr-Q0382-answer

**tr-Q0383** — Senin ayın geri dönüyor

Your moon returns.

Why: Possession and genitive. [[Turkish#^tr-Q0383|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Senin%20ay%C4%B1n%20geri%20d%C3%B6n%C3%BCyor)
^tr-Q0383-answer

**tr-Q0384** — Senin ayın geri dönüyor

Your moon returns.

A genitive possessor commonly pairs with a possessive suffix on the possessed noun. Benim kitabım means my book. A possessive relationship is not expressed just by juxtaposing two unchanged nouns.

Why: Possession and genitive. [[Turkish#^tr-Q0384|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Senin%20ay%C4%B1n%20geri%20d%C3%B6n%C3%BCyor)
^tr-Q0384-answer

**tr-Q0385** — Ben onun müziğini seviyorum.

I like his music.

Expected form: **onun**

Why: Possession and genitive. [[Turkish#^tr-Q0385|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ben%20onun%20m%C3%BCzi%C4%9Fini%20seviyorum.)
^tr-Q0385-answer

**tr-Q0386** — Ben onun müziğini seviyorum.

I like his music.

Expected form: **onun**

Why: Possession and genitive. [[Turkish#^tr-Q0386|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ben%20onun%20m%C3%BCzi%C4%9Fini%20seviyorum.)
^tr-Q0386-answer

**tr-Q0387** — Bir ülke tarafından üretilen kağıt miktarı onun kültürel standartlarıyla yakından ilişkilidir.

The amount of paper produced by a country is closely related to its cultural standards.

Expected form: **onun**

Why: Possession and genitive. [[Turkish#^tr-Q0387|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bir%20%C3%BClke%20taraf%C4%B1ndan%20%C3%BCretilen%20ka%C4%9F%C4%B1t%20miktar%C4%B1%20onun%20k%C3%BClt%C3%BCrel%20standartlar%C4%B1yla%20yak%C4%B1ndan%20ili%C5%9Fkilidir.)
^tr-Q0387-answer

**tr-Q0388** — Bir ülke tarafından üretilen kağıt miktarı onun kültürel standartlarıyla yakından ilişkilidir.

The amount of paper produced by a country is closely related to its cultural standards.

Why: Possession and genitive. [[Turkish#^tr-Q0388|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bir%20%C3%BClke%20taraf%C4%B1ndan%20%C3%BCretilen%20ka%C4%9F%C4%B1t%20miktar%C4%B1%20onun%20k%C3%BClt%C3%BCrel%20standartlar%C4%B1yla%20yak%C4%B1ndan%20ili%C5%9Fkilidir.)
^tr-Q0388-answer

**tr-Q0389** — Resmi olarak, o bir tercüman olarak bizim için çalışıyor.

Officially, he works for us as an interpreter.

Why: Possession and genitive. [[Turkish#^tr-Q0389|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Resmi%20olarak%2C%20o%20bir%20terc%C3%BCman%20olarak%20bizim%20i%C3%A7in%20%C3%A7al%C4%B1%C5%9F%C4%B1yor.)
^tr-Q0389-answer

**tr-Q0390** — Resmi olarak, o bir tercüman olarak bizim için çalışıyor.

Officially, he works for us as an interpreter.

A genitive possessor commonly pairs with a possessive suffix on the possessed noun. Benim kitabım means my book. A possessive relationship is not expressed just by juxtaposing two unchanged nouns.

Why: Possession and genitive. [[Turkish#^tr-Q0390|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Resmi%20olarak%2C%20o%20bir%20terc%C3%BCman%20olarak%20bizim%20i%C3%A7in%20%C3%A7al%C4%B1%C5%9F%C4%B1yor.)
^tr-Q0390-answer

**tr-Q0391** — Onun keskin bir işitmesi var.

He has sharp hearing.

Expected form: **Onun**

Why: Possession and genitive. [[Turkish#^tr-Q0391|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Onun%20keskin%20bir%20i%C5%9Fitmesi%20var.)
^tr-Q0391-answer

**tr-Q0392** — Onun keskin bir işitmesi var.

He has sharp hearing.

Expected form: **Onun**

Why: Possession and genitive. [[Turkish#^tr-Q0392|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Onun%20keskin%20bir%20i%C5%9Fitmesi%20var.)
^tr-Q0392-answer

**tr-Q0393** — Onun sana söylediğine hiç aldırış etme.

Don't pay any attention to what he tells you.

Expected form: **Onun**

Why: Possession and genitive. [[Turkish#^tr-Q0393|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Onun%20sana%20s%C3%B6yledi%C4%9Fine%20hi%C3%A7%20ald%C4%B1r%C4%B1%C5%9F%20etme.)
^tr-Q0393-answer

**tr-Q0394** — Onun sana söylediğine hiç aldırış etme.

Don't pay any attention to what he tells you.

Why: Possession and genitive. [[Turkish#^tr-Q0394|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Onun%20sana%20s%C3%B6yledi%C4%9Fine%20hi%C3%A7%20ald%C4%B1r%C4%B1%C5%9F%20etme.)
^tr-Q0394-answer

**tr-Q0395** — Orada onun evini görebiliriz.

We can see his house over there.

Why: Possession and genitive. [[Turkish#^tr-Q0395|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Orada%20onun%20evini%20g%C3%B6rebiliriz.)
^tr-Q0395-answer

**tr-Q0396** — Orada onun evini görebiliriz.

We can see his house over there.

A genitive possessor commonly pairs with a possessive suffix on the possessed noun. Benim kitabım means my book. A possessive relationship is not expressed just by juxtaposing two unchanged nouns.

Why: Possession and genitive. [[Turkish#^tr-Q0396|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Orada%20onun%20evini%20g%C3%B6rebiliriz.)
^tr-Q0396-answer

**tr-Q0397** — Bizim onlara yardım etmemiz gerekebilir.

We may need to help them.

Expected form: **Bizim**

Why: Possession and genitive. [[Turkish#^tr-Q0397|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bizim%20onlara%20yard%C4%B1m%20etmemiz%20gerekebilir.)
^tr-Q0397-answer

**tr-Q0398** — Bizim onlara yardım etmemiz gerekebilir.

We may need to help them.

Expected form: **Bizim**

Why: Possession and genitive. [[Turkish#^tr-Q0398|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bizim%20onlara%20yard%C4%B1m%20etmemiz%20gerekebilir.)
^tr-Q0398-answer

**tr-Q0399** — Eğer bizim son topa vuran oyuncumuz tur vuruşu yapmasaydı, takım oyunu kaybederdi.

If our last batter had not hit a home run, team would have lost the game.

Expected form: **bizim**

Why: Possession and genitive. [[Turkish#^tr-Q0399|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=E%C4%9Fer%20bizim%20son%20topa%20vuran%20oyuncumuz%20tur%20vuru%C5%9Fu%20yapmasayd%C4%B1%2C%20tak%C4%B1m%20oyunu%20kaybederdi.)
^tr-Q0399-answer

**tr-Q0400** — Eğer bizim son topa vuran oyuncumuz tur vuruşu yapmasaydı, takım oyunu kaybederdi.

If our last batter had not hit a home run, team would have lost the game.

Why: Possession and genitive. [[Turkish#^tr-Q0400|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=E%C4%9Fer%20bizim%20son%20topa%20vuran%20oyuncumuz%20tur%20vuru%C5%9Fu%20yapmasayd%C4%B1%2C%20tak%C4%B1m%20oyunu%20kaybederdi.)
^tr-Q0400-answer


### Answers 401–450

**tr-Q0401** — Ödülü kimin aldığını biliyorum.

I know who got the prize.

Why: Progressive verbs. [[Turkish#^tr-Q0401|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=%C3%96d%C3%BCl%C3%BC%20kimin%20ald%C4%B1%C4%9F%C4%B1n%C4%B1%20biliyorum.)
^tr-Q0401-answer

**tr-Q0402** — Ödülü kimin aldığını biliyorum.

I know who got the prize.

The -Iyor construction marks a progressive/current pattern and takes personal endings. Vowel interactions can change the stem surface. Learn negative -mIyor separately from a mechanical -ma + ıyor spelling.

Why: Progressive verbs. [[Turkish#^tr-Q0402|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=%C3%96d%C3%BCl%C3%BC%20kimin%20ald%C4%B1%C4%9F%C4%B1n%C4%B1%20biliyorum.)
^tr-Q0402-answer

**tr-Q0403** — Hâlâ eğleniyor musunuz?

Are you still having fun?

Expected form: **eğleniyor**

Why: Progressive verbs. [[Turkish#^tr-Q0403|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=H%C3%A2l%C3%A2%20e%C4%9Fleniyor%20musunuz%3F)
^tr-Q0403-answer

**tr-Q0404** — Hâlâ eğleniyor musunuz?

Are you still having fun?

Expected form: **eğleniyor**

Why: Progressive verbs. [[Turkish#^tr-Q0404|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=H%C3%A2l%C3%A2%20e%C4%9Fleniyor%20musunuz%3F)
^tr-Q0404-answer

**tr-Q0405** — Müdür seninle konuşmak istiyor.

The principal wants to talk to you.

Expected form: **istiyor**

Why: Progressive verbs. [[Turkish#^tr-Q0405|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=M%C3%BCd%C3%BCr%20seninle%20konu%C5%9Fmak%20istiyor.)
^tr-Q0405-answer

**tr-Q0406** — Müdür seninle konuşmak istiyor.

The principal wants to talk to you.

Why: Progressive verbs. [[Turkish#^tr-Q0406|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=M%C3%BCd%C3%BCr%20seninle%20konu%C5%9Fmak%20istiyor.)
^tr-Q0406-answer

**tr-Q0407** — Ne yapman gerektiğini anlamıyor musun?

Don't you understand what you have to do?

Why: Progressive verbs. [[Turkish#^tr-Q0407|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ne%20yapman%20gerekti%C4%9Fini%20anlam%C4%B1yor%20musun%3F)
^tr-Q0407-answer

**tr-Q0408** — Ne yapman gerektiğini anlamıyor musun?

Don't you understand what you have to do?

The -Iyor construction marks a progressive/current pattern and takes personal endings. Vowel interactions can change the stem surface. Learn negative -mIyor separately from a mechanical -ma + ıyor spelling.

Why: Progressive verbs. [[Turkish#^tr-Q0408|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ne%20yapman%20gerekti%C4%9Fini%20anlam%C4%B1yor%20musun%3F)
^tr-Q0408-answer

**tr-Q0409** — Tom'un haklı olduğunu biliyorsun.

You know Tom was right.

Expected form: **biliyorsun**

Why: Progressive verbs. [[Turkish#^tr-Q0409|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%27un%20hakl%C4%B1%20oldu%C4%9Funu%20biliyorsun.)
^tr-Q0409-answer

**tr-Q0410** — Tom'un haklı olduğunu biliyorsun.

You know Tom was right.

Expected form: **biliyorsun**

Why: Progressive verbs. [[Turkish#^tr-Q0410|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%27un%20hakl%C4%B1%20oldu%C4%9Funu%20biliyorsun.)
^tr-Q0410-answer

**tr-Q0411** — Tom'un hâlâ öğle yemeği yeyip yemediğini merak ediyorum.

I wonder if Tom is still eating lunch.

Expected form: **ediyorum**

Why: Progressive verbs. [[Turkish#^tr-Q0411|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%27un%20h%C3%A2l%C3%A2%20%C3%B6%C4%9Fle%20yeme%C4%9Fi%20yeyip%20yemedi%C4%9Fini%20merak%20ediyorum.)
^tr-Q0411-answer

**tr-Q0412** — Tom'un hâlâ öğle yemeği yeyip yemediğini merak ediyorum.

I wonder if Tom is still eating lunch.

Why: Progressive verbs. [[Turkish#^tr-Q0412|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%27un%20h%C3%A2l%C3%A2%20%C3%B6%C4%9Fle%20yeme%C4%9Fi%20yeyip%20yemedi%C4%9Fini%20merak%20ediyorum.)
^tr-Q0412-answer

**tr-Q0413** — Tom bizimle gideceğini söylüyor.

Tom says he'll go with us.

Why: Progressive verbs. [[Turkish#^tr-Q0413|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20bizimle%20gidece%C4%9Fini%20s%C3%B6yl%C3%BCyor.)
^tr-Q0413-answer

**tr-Q0414** — Tom bizimle gideceğini söylüyor.

Tom says he'll go with us.

The -Iyor construction marks a progressive/current pattern and takes personal endings. Vowel interactions can change the stem surface. Learn negative -mIyor separately from a mechanical -ma + ıyor spelling.

Why: Progressive verbs. [[Turkish#^tr-Q0414|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20bizimle%20gidece%C4%9Fini%20s%C3%B6yl%C3%BCyor.)
^tr-Q0414-answer

**tr-Q0415** — Gerçek bir iş edinmek istiyorum.

I want to get a real job.

Expected form: **istiyorum**

Why: Progressive verbs. [[Turkish#^tr-Q0415|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ger%C3%A7ek%20bir%20i%C5%9F%20edinmek%20istiyorum.)
^tr-Q0415-answer

**tr-Q0416** — Gerçek bir iş edinmek istiyorum.

I want to get a real job.

Expected form: **istiyorum**

Why: Progressive verbs. [[Turkish#^tr-Q0416|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ger%C3%A7ek%20bir%20i%C5%9F%20edinmek%20istiyorum.)
^tr-Q0416-answer

**tr-Q0417** — Bir kitap görüyor musun?

Do you see a book?

Expected form: **görüyor**

Why: Progressive verbs. [[Turkish#^tr-Q0417|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bir%20kitap%20g%C3%B6r%C3%BCyor%20musun%3F)
^tr-Q0417-answer

**tr-Q0418** — Bir kitap görüyor musun?

Do you see a book?

Why: Progressive verbs. [[Turkish#^tr-Q0418|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bir%20kitap%20g%C3%B6r%C3%BCyor%20musun%3F)
^tr-Q0418-answer

**tr-Q0419** — Hatalı olduğuma inanıyorum.

I believe I was wrong.

Why: Progressive verbs. [[Turkish#^tr-Q0419|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Hatal%C4%B1%20oldu%C4%9Fuma%20inan%C4%B1yorum.)
^tr-Q0419-answer

**tr-Q0420** — Hatalı olduğuma inanıyorum.

I believe I was wrong.

The -Iyor construction marks a progressive/current pattern and takes personal endings. Vowel interactions can change the stem surface. Learn negative -mIyor separately from a mechanical -ma + ıyor spelling.

Why: Progressive verbs. [[Turkish#^tr-Q0420|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Hatal%C4%B1%20oldu%C4%9Fuma%20inan%C4%B1yorum.)
^tr-Q0420-answer

**tr-Q0421** — Tom yeni bir bisiklet satın aldı gibi görünüyor.

It looks like Tom has bought a new bicycle.

Expected form: **görünüyor**

Why: Progressive verbs. [[Turkish#^tr-Q0421|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20yeni%20bir%20bisiklet%20sat%C4%B1n%20ald%C4%B1%20gibi%20g%C3%B6r%C3%BCn%C3%BCyor.)
^tr-Q0421-answer

**tr-Q0422** — Tom yeni bir bisiklet satın aldı gibi görünüyor.

It looks like Tom has bought a new bicycle.

Expected form: **görünüyor**

Why: Progressive verbs. [[Turkish#^tr-Q0422|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20yeni%20bir%20bisiklet%20sat%C4%B1n%20ald%C4%B1%20gibi%20g%C3%B6r%C3%BCn%C3%BCyor.)
^tr-Q0422-answer

**tr-Q0423** — Sabırsızlıkla acil cevabını almayı bekliyoruz.

We look forward to receiving your prompt reply.

Expected form: **bekliyoruz**

Why: Progressive verbs. [[Turkish#^tr-Q0423|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Sab%C4%B1rs%C4%B1zl%C4%B1kla%20acil%20cevab%C4%B1n%C4%B1%20almay%C4%B1%20bekliyoruz.)
^tr-Q0423-answer

**tr-Q0424** — Sabırsızlıkla acil cevabını almayı bekliyoruz.

We look forward to receiving your prompt reply.

Why: Progressive verbs. [[Turkish#^tr-Q0424|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Sab%C4%B1rs%C4%B1zl%C4%B1kla%20acil%20cevab%C4%B1n%C4%B1%20almay%C4%B1%20bekliyoruz.)
^tr-Q0424-answer

**tr-Q0425** — Sen işbirliği yapıyorsun.

You're cooperating.

Why: Progressive verbs. [[Turkish#^tr-Q0425|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Sen%20i%C5%9Fbirli%C4%9Fi%20yap%C4%B1yorsun.)
^tr-Q0425-answer

**tr-Q0426** — Sen işbirliği yapıyorsun.

You're cooperating.

The -Iyor construction marks a progressive/current pattern and takes personal endings. Vowel interactions can change the stem surface. Learn negative -mIyor separately from a mechanical -ma + ıyor spelling.

Why: Progressive verbs. [[Turkish#^tr-Q0426|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Sen%20i%C5%9Fbirli%C4%9Fi%20yap%C4%B1yorsun.)
^tr-Q0426-answer

**tr-Q0427** — Tom burada harika bir iş yapıyor.

Tom is doing a wonderful job here.

Expected form: **yapıyor**

Why: Progressive verbs. [[Turkish#^tr-Q0427|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20burada%20harika%20bir%20i%C5%9F%20yap%C4%B1yor.)
^tr-Q0427-answer

**tr-Q0428** — Tom burada harika bir iş yapıyor.

Tom is doing a wonderful job here.

Expected form: **yapıyor**

Why: Progressive verbs. [[Turkish#^tr-Q0428|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20burada%20harika%20bir%20i%C5%9F%20yap%C4%B1yor.)
^tr-Q0428-answer

**tr-Q0429** — Sen umursamaz görünüyorsun.

You look unimpressed.

Expected form: **görünüyorsun**

Why: Progressive verbs. [[Turkish#^tr-Q0429|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Sen%20umursamaz%20g%C3%B6r%C3%BCn%C3%BCyorsun.)
^tr-Q0429-answer

**tr-Q0430** — Sen umursamaz görünüyorsun.

You look unimpressed.

Why: Progressive verbs. [[Turkish#^tr-Q0430|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Sen%20umursamaz%20g%C3%B6r%C3%BCn%C3%BCyorsun.)
^tr-Q0430-answer

**tr-Q0431** — Hâlâ Tom'u düşünüyorum.

I'm still thinking about Tom.

Why: Progressive verbs. [[Turkish#^tr-Q0431|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=H%C3%A2l%C3%A2%20Tom%27u%20d%C3%BC%C5%9F%C3%BCn%C3%BCyorum.)
^tr-Q0431-answer

**tr-Q0432** — Hâlâ Tom'u düşünüyorum.

I'm still thinking about Tom.

The -Iyor construction marks a progressive/current pattern and takes personal endings. Vowel interactions can change the stem surface. Learn negative -mIyor separately from a mechanical -ma + ıyor spelling.

Why: Progressive verbs. [[Turkish#^tr-Q0432|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=H%C3%A2l%C3%A2%20Tom%27u%20d%C3%BC%C5%9F%C3%BCn%C3%BCyorum.)
^tr-Q0432-answer

**tr-Q0433** — Ben atölyede çalışıyorum.

I am working at the workshop.

Expected form: **çalışıyorum**

Why: Progressive verbs. [[Turkish#^tr-Q0433|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ben%20at%C3%B6lyede%20%C3%A7al%C4%B1%C5%9F%C4%B1yorum.)
^tr-Q0433-answer

**tr-Q0434** — Ben atölyede çalışıyorum.

I am working at the workshop.

Expected form: **çalışıyorum**

Why: Progressive verbs. [[Turkish#^tr-Q0434|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ben%20at%C3%B6lyede%20%C3%A7al%C4%B1%C5%9F%C4%B1yorum.)
^tr-Q0434-answer

**tr-Q0435** — Tom zor zaman geçiriyor.

Tom is having a tough time.

Expected form: **geçiriyor**

Why: Progressive verbs. [[Turkish#^tr-Q0435|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20zor%20zaman%20ge%C3%A7iriyor.)
^tr-Q0435-answer

**tr-Q0436** — Tom zor zaman geçiriyor.

Tom is having a tough time.

Why: Progressive verbs. [[Turkish#^tr-Q0436|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20zor%20zaman%20ge%C3%A7iriyor.)
^tr-Q0436-answer

**tr-Q0437** — Herkes Tom'u arıyor.

Everyone's looking for Tom.

Why: Progressive verbs. [[Turkish#^tr-Q0437|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Herkes%20Tom%27u%20ar%C4%B1yor.)
^tr-Q0437-answer

**tr-Q0438** — Herkes Tom'u arıyor.

Everyone's looking for Tom.

The -Iyor construction marks a progressive/current pattern and takes personal endings. Vowel interactions can change the stem surface. Learn negative -mIyor separately from a mechanical -ma + ıyor spelling.

Why: Progressive verbs. [[Turkish#^tr-Q0438|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Herkes%20Tom%27u%20ar%C4%B1yor.)
^tr-Q0438-answer

**tr-Q0439** — Tom, Mary'nin şüphelenmeyeceğini düşünüyor.

Tom thinks Mary won't be suspicious.

Expected form: **düşünüyor**

Why: Progressive verbs. [[Turkish#^tr-Q0439|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%2C%20Mary%27nin%20%C5%9F%C3%BCphelenmeyece%C4%9Fini%20d%C3%BC%C5%9F%C3%BCn%C3%BCyor.)
^tr-Q0439-answer

**tr-Q0440** — Tom, Mary'nin şüphelenmeyeceğini düşünüyor.

Tom thinks Mary won't be suspicious.

Expected form: **düşünüyor**

Why: Progressive verbs. [[Turkish#^tr-Q0440|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%2C%20Mary%27nin%20%C5%9F%C3%BCphelenmeyece%C4%9Fini%20d%C3%BC%C5%9F%C3%BCn%C3%BCyor.)
^tr-Q0440-answer

**tr-Q0441** — Biz içeriye geliyoruz.

We're coming in.

Expected form: **geliyoruz**

Why: Progressive verbs. [[Turkish#^tr-Q0441|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Biz%20i%C3%A7eriye%20geliyoruz.)
^tr-Q0441-answer

**tr-Q0442** — Biz içeriye geliyoruz.

We're coming in.

Why: Progressive verbs. [[Turkish#^tr-Q0442|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Biz%20i%C3%A7eriye%20geliyoruz.)
^tr-Q0442-answer

**tr-Q0443** — Tom hâlâ Mary'den kendisine bunu yapmasına yardım etmesini istiyor.

Tom still wants Mary to help him do that.

Why: Progressive verbs. [[Turkish#^tr-Q0443|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20h%C3%A2l%C3%A2%20Mary%27den%20kendisine%20bunu%20yapmas%C4%B1na%20yard%C4%B1m%20etmesini%20istiyor.)
^tr-Q0443-answer

**tr-Q0444** — Tom hâlâ Mary'den kendisine bunu yapmasına yardım etmesini istiyor.

Tom still wants Mary to help him do that.

The -Iyor construction marks a progressive/current pattern and takes personal endings. Vowel interactions can change the stem surface. Learn negative -mIyor separately from a mechanical -ma + ıyor spelling.

Why: Progressive verbs. [[Turkish#^tr-Q0444|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20h%C3%A2l%C3%A2%20Mary%27den%20kendisine%20bunu%20yapmas%C4%B1na%20yard%C4%B1m%20etmesini%20istiyor.)
^tr-Q0444-answer

**tr-Q0445** — Neden bunu akşam yemeğinde konuşmuyoruz?

Why don't we talk about this over dinner?

Expected form: **konuşmuyoruz**

Why: Progressive verbs. [[Turkish#^tr-Q0445|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Neden%20bunu%20ak%C5%9Fam%20yeme%C4%9Finde%20konu%C5%9Fmuyoruz%3F)
^tr-Q0445-answer

**tr-Q0446** — Neden bunu akşam yemeğinde konuşmuyoruz?

Why don't we talk about this over dinner?

Expected form: **konuşmuyoruz**

Why: Progressive verbs. [[Turkish#^tr-Q0446|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Neden%20bunu%20ak%C5%9Fam%20yeme%C4%9Finde%20konu%C5%9Fmuyoruz%3F)
^tr-Q0446-answer

**tr-Q0447** — Mesajın ne olmasını istiyorsun?

What do you want the message to be?

Expected form: **istiyorsun**

Why: Progressive verbs. [[Turkish#^tr-Q0447|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Mesaj%C4%B1n%20ne%20olmas%C4%B1n%C4%B1%20istiyorsun%3F)
^tr-Q0447-answer

**tr-Q0448** — Mesajın ne olmasını istiyorsun?

What do you want the message to be?

Why: Progressive verbs. [[Turkish#^tr-Q0448|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Mesaj%C4%B1n%20ne%20olmas%C4%B1n%C4%B1%20istiyorsun%3F)
^tr-Q0448-answer

**tr-Q0449** — Louie, arkadaşların geliyor. Temizlik yap.

Louie, your friends are coming. Clean up.

Why: Progressive verbs. [[Turkish#^tr-Q0449|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Louie%2C%20arkada%C5%9Flar%C4%B1n%20geliyor.%20Temizlik%20yap.)
^tr-Q0449-answer

**tr-Q0450** — Louie, arkadaşların geliyor. Temizlik yap.

Louie, your friends are coming. Clean up.

The -Iyor construction marks a progressive/current pattern and takes personal endings. Vowel interactions can change the stem surface. Learn negative -mIyor separately from a mechanical -ma + ıyor spelling.

Why: Progressive verbs. [[Turkish#^tr-Q0450|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Louie%2C%20arkada%C5%9Flar%C4%B1n%20geliyor.%20Temizlik%20yap.)
^tr-Q0450-answer


### Answers 451–500

**tr-Q0451** — Jane kızgın bir jest yaptı.

Jane made an angry gesture.

Expected form: **yaptı**

Why: Past forms. [[Turkish#^tr-Q0451|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Jane%20k%C4%B1zg%C4%B1n%20bir%20jest%20yapt%C4%B1.)
^tr-Q0451-answer

**tr-Q0452** — Jane kızgın bir jest yaptı.

Jane made an angry gesture.

Expected form: **yaptı**

Why: Past forms. [[Turkish#^tr-Q0452|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Jane%20k%C4%B1zg%C4%B1n%20bir%20jest%20yapt%C4%B1.)
^tr-Q0452-answer

**tr-Q0453** — Buraya otuz dakika önce geldim.

I got here about thirty minutes ago.

Expected form: **geldim**

Why: Past forms. [[Turkish#^tr-Q0453|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Buraya%20otuz%20dakika%20%C3%B6nce%20geldim.)
^tr-Q0453-answer

**tr-Q0454** — Buraya otuz dakika önce geldim.

I got here about thirty minutes ago.

Why: Past forms. [[Turkish#^tr-Q0454|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Buraya%20otuz%20dakika%20%C3%B6nce%20geldim.)
^tr-Q0454-answer

**tr-Q0455** — Mary kardeşine yeni bir elbise yaptı.

Mary made her sister a new dress.

Why: Past forms. [[Turkish#^tr-Q0455|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Mary%20karde%C5%9Fine%20yeni%20bir%20elbise%20yapt%C4%B1.)
^tr-Q0455-answer

**tr-Q0456** — Mary kardeşine yeni bir elbise yaptı.

Mary made her sister a new dress.

The -DI past uses vowel/consonant harmony and personal endings. Its evidential orientation contrasts with common -mIş forms, though discourse can refine the contrast.

Why: Past forms. [[Turkish#^tr-Q0456|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Mary%20karde%C5%9Fine%20yeni%20bir%20elbise%20yapt%C4%B1.)
^tr-Q0456-answer

**tr-Q0457** — Eski güzel günlerin hatıraları sel gibi peş peşe geldi.

Memories of the good old days came flooding back one after another.

Expected form: **geldi**

Why: Past forms. [[Turkish#^tr-Q0457|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Eski%20g%C3%BCzel%20g%C3%BCnlerin%20hat%C4%B1ralar%C4%B1%20sel%20gibi%20pe%C5%9F%20pe%C5%9Fe%20geldi.)
^tr-Q0457-answer

**tr-Q0458** — Eski güzel günlerin hatıraları sel gibi peş peşe geldi.

Memories of the good old days came flooding back one after another.

Expected form: **geldi**

Why: Past forms. [[Turkish#^tr-Q0458|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Eski%20g%C3%BCzel%20g%C3%BCnlerin%20hat%C4%B1ralar%C4%B1%20sel%20gibi%20pe%C5%9F%20pe%C5%9Fe%20geldi.)
^tr-Q0458-answer

**tr-Q0459** — Tom'un konuşma yapmasına gerek yoktui. Mary bütün konuşmayı yaptı.

Tom didn't need to speak. Mary did all the talking.

Expected form: **yaptı**

Why: Past forms. [[Turkish#^tr-Q0459|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%27un%20konu%C5%9Fma%20yapmas%C4%B1na%20gerek%20yoktui.%20Mary%20b%C3%BCt%C3%BCn%20konu%C5%9Fmay%C4%B1%20yapt%C4%B1.)
^tr-Q0459-answer

**tr-Q0460** — Tom'un konuşma yapmasına gerek yoktui. Mary bütün konuşmayı yaptı.

Tom didn't need to speak. Mary did all the talking.

Why: Past forms. [[Turkish#^tr-Q0460|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%27un%20konu%C5%9Fma%20yapmas%C4%B1na%20gerek%20yoktui.%20Mary%20b%C3%BCt%C3%BCn%20konu%C5%9Fmay%C4%B1%20yapt%C4%B1.)
^tr-Q0460-answer

**tr-Q0461** — Tom tamamen hak ettiğini aldı.

Tom got exactly what he deserved.

Why: Past forms. [[Turkish#^tr-Q0461|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20tamamen%20hak%20etti%C4%9Fini%20ald%C4%B1.)
^tr-Q0461-answer

**tr-Q0462** — Tom tamamen hak ettiğini aldı.

Tom got exactly what he deserved.

The -DI past uses vowel/consonant harmony and personal endings. Its evidential orientation contrasts with common -mIş forms, though discourse can refine the contrast.

Why: Past forms. [[Turkish#^tr-Q0462|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20tamamen%20hak%20etti%C4%9Fini%20ald%C4%B1.)
^tr-Q0462-answer

**tr-Q0463** — Tom aşık oldu.

Tom fell in love.

Expected form: **oldu**

Why: Past forms. [[Turkish#^tr-Q0463|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20a%C5%9F%C4%B1k%20oldu.)
^tr-Q0463-answer

**tr-Q0464** — Tom aşık oldu.

Tom fell in love.

Expected form: **oldu**

Why: Past forms. [[Turkish#^tr-Q0464|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20a%C5%9F%C4%B1k%20oldu.)
^tr-Q0464-answer

**tr-Q0465** — O, kuşa nişan aldı.

He aimed at the bird.

Expected form: **aldı**

Why: Past forms. [[Turkish#^tr-Q0465|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=O%2C%20ku%C5%9Fa%20ni%C5%9Fan%20ald%C4%B1.)
^tr-Q0465-answer

**tr-Q0466** — O, kuşa nişan aldı.

He aimed at the bird.

Why: Past forms. [[Turkish#^tr-Q0466|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=O%2C%20ku%C5%9Fa%20ni%C5%9Fan%20ald%C4%B1.)
^tr-Q0466-answer

**tr-Q0467** — Francis saat altıda Galeao'ya geldi.

Francis arrived at Galeao at six.

Why: Past forms. [[Turkish#^tr-Q0467|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Francis%20saat%20alt%C4%B1da%20Galeao%27ya%20geldi.)
^tr-Q0467-answer

**tr-Q0468** — Francis saat altıda Galeao'ya geldi.

Francis arrived at Galeao at six.

The -DI past uses vowel/consonant harmony and personal endings. Its evidential orientation contrasts with common -mIş forms, though discourse can refine the contrast.

Why: Past forms. [[Turkish#^tr-Q0468|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Francis%20saat%20alt%C4%B1da%20Galeao%27ya%20geldi.)
^tr-Q0468-answer

**tr-Q0469** — O gerçekten o şekilde mi oldu?

Did it actually happen like that?

Expected form: **oldu**

Why: Past forms. [[Turkish#^tr-Q0469|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=O%20ger%C3%A7ekten%20o%20%C5%9Fekilde%20mi%20oldu%3F)
^tr-Q0469-answer

**tr-Q0470** — O gerçekten o şekilde mi oldu?

Did it actually happen like that?

Expected form: **oldu**

Why: Past forms. [[Turkish#^tr-Q0470|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=O%20ger%C3%A7ekten%20o%20%C5%9Fekilde%20mi%20oldu%3F)
^tr-Q0470-answer

**tr-Q0471** — Süzme peynir yediğimden beri bir süre oldu.

It's been a while since I've eaten cottage cheese.

Expected form: **oldu**

Why: Past forms. [[Turkish#^tr-Q0471|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=S%C3%BCzme%20peynir%20yedi%C4%9Fimden%20beri%20bir%20s%C3%BCre%20oldu.)
^tr-Q0471-answer

**tr-Q0472** — Süzme peynir yediğimden beri bir süre oldu.

It's been a while since I've eaten cottage cheese.

Why: Past forms. [[Turkish#^tr-Q0472|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=S%C3%BCzme%20peynir%20yedi%C4%9Fimden%20beri%20bir%20s%C3%BCre%20oldu.)
^tr-Q0472-answer

**tr-Q0473** — Karımı görmek için hastaneye gittim.

I went to the hospital to see my wife.

Why: Past forms. [[Turkish#^tr-Q0473|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Kar%C4%B1m%C4%B1%20g%C3%B6rmek%20i%C3%A7in%20hastaneye%20gittim.)
^tr-Q0473-answer

**tr-Q0474** — Karımı görmek için hastaneye gittim.

I went to the hospital to see my wife.

The -DI past uses vowel/consonant harmony and personal endings. Its evidential orientation contrasts with common -mIş forms, though discourse can refine the contrast.

Why: Past forms. [[Turkish#^tr-Q0474|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Kar%C4%B1m%C4%B1%20g%C3%B6rmek%20i%C3%A7in%20hastaneye%20gittim.)
^tr-Q0474-answer

**tr-Q0475** — Yaşlı kadın gitti ve yakında Prenses ile birlikte geri döndü.

The old woman went, and soon returned along with the Princess.

Expected form: **gitti**

Why: Past forms. [[Turkish#^tr-Q0475|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ya%C5%9Fl%C4%B1%20kad%C4%B1n%20gitti%20ve%20yak%C4%B1nda%20Prenses%20ile%20birlikte%20geri%20d%C3%B6nd%C3%BC.)
^tr-Q0475-answer

**tr-Q0476** — Yaşlı kadın gitti ve yakında Prenses ile birlikte geri döndü.

The old woman went, and soon returned along with the Princess.

Expected form: **gitti**

Why: Past forms. [[Turkish#^tr-Q0476|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ya%C5%9Fl%C4%B1%20kad%C4%B1n%20gitti%20ve%20yak%C4%B1nda%20Prenses%20ile%20birlikte%20geri%20d%C3%B6nd%C3%BC.)
^tr-Q0476-answer

**tr-Q0477** — Oğlunuz öğrenci hareketi içinde yer aldı, ben duydum.

Your son took part in the student movement, I hear.

Expected form: **aldı**

Why: Past forms. [[Turkish#^tr-Q0477|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=O%C4%9Flunuz%20%C3%B6%C4%9Frenci%20hareketi%20i%C3%A7inde%20yer%20ald%C4%B1%2C%20ben%20duydum.)
^tr-Q0477-answer

**tr-Q0478** — Oğlunuz öğrenci hareketi içinde yer aldı, ben duydum.

Your son took part in the student movement, I hear.

Why: Past forms. [[Turkish#^tr-Q0478|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=O%C4%9Flunuz%20%C3%B6%C4%9Frenci%20hareketi%20i%C3%A7inde%20yer%20ald%C4%B1%2C%20ben%20duydum.)
^tr-Q0478-answer

**tr-Q0479** — Bir hafta sonra aynı şey arkadaşıma oldu.

The exact same thing happened to my friend a week later!

Why: Past forms. [[Turkish#^tr-Q0479|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bir%20hafta%20sonra%20ayn%C4%B1%20%C5%9Fey%20arkada%C5%9F%C4%B1ma%20oldu.)
^tr-Q0479-answer

**tr-Q0480** — Bir hafta sonra aynı şey arkadaşıma oldu.

The exact same thing happened to my friend a week later!

The -DI past uses vowel/consonant harmony and personal endings. Its evidential orientation contrasts with common -mIş forms, though discourse can refine the contrast.

Why: Past forms. [[Turkish#^tr-Q0480|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bir%20hafta%20sonra%20ayn%C4%B1%20%C5%9Fey%20arkada%C5%9F%C4%B1ma%20oldu.)
^tr-Q0480-answer

**tr-Q0481** — Tom, Mary'ye bir sosisli sandviç aldı.

Tom bought a hot dog for Mary.

Expected form: **aldı**

Why: Past forms. [[Turkish#^tr-Q0481|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%2C%20Mary%27ye%20bir%20sosisli%20sandvi%C3%A7%20ald%C4%B1.)
^tr-Q0481-answer

**tr-Q0482** — Tom, Mary'ye bir sosisli sandviç aldı.

Tom bought a hot dog for Mary.

Expected form: **aldı**

Why: Past forms. [[Turkish#^tr-Q0482|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%2C%20Mary%27ye%20bir%20sosisli%20sandvi%C3%A7%20ald%C4%B1.)
^tr-Q0482-answer

**tr-Q0483** — Sami bir hata yaptı.

Sami made a mistake.

Expected form: **yaptı**

Why: Past forms. [[Turkish#^tr-Q0483|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Sami%20bir%20hata%20yapt%C4%B1.)
^tr-Q0483-answer

**tr-Q0484** — Sami bir hata yaptı.

Sami made a mistake.

Why: Past forms. [[Turkish#^tr-Q0484|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Sami%20bir%20hata%20yapt%C4%B1.)
^tr-Q0484-answer

**tr-Q0485** — Tom zaten satın alması gereken her şeyi satın aldı.

Tom has already bought everything he needs to buy.

Why: Past forms. [[Turkish#^tr-Q0485|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20zaten%20sat%C4%B1n%20almas%C4%B1%20gereken%20her%20%C5%9Feyi%20sat%C4%B1n%20ald%C4%B1.)
^tr-Q0485-answer

**tr-Q0486** — Tom zaten satın alması gereken her şeyi satın aldı.

Tom has already bought everything he needs to buy.

The -DI past uses vowel/consonant harmony and personal endings. Its evidential orientation contrasts with common -mIş forms, though discourse can refine the contrast.

Why: Past forms. [[Turkish#^tr-Q0486|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20zaten%20sat%C4%B1n%20almas%C4%B1%20gereken%20her%20%C5%9Feyi%20sat%C4%B1n%20ald%C4%B1.)
^tr-Q0486-answer

**tr-Q0487** — Aniden kaza oldu.

The accident happened all of a sudden.

Expected form: **oldu**

Why: Past forms. [[Turkish#^tr-Q0487|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Aniden%20kaza%20oldu.)
^tr-Q0487-answer

**tr-Q0488** — Aniden kaza oldu.

The accident happened all of a sudden.

Expected form: **oldu**

Why: Past forms. [[Turkish#^tr-Q0488|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Aniden%20kaza%20oldu.)
^tr-Q0488-answer

**tr-Q0489** — Boston'a bir gezi yaptım.

I took a trip to Boston.

Expected form: **yaptım**

Why: Past forms. [[Turkish#^tr-Q0489|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Boston%27a%20bir%20gezi%20yapt%C4%B1m.)
^tr-Q0489-answer

**tr-Q0490** — Boston'a bir gezi yaptım.

I took a trip to Boston.

Why: Past forms. [[Turkish#^tr-Q0490|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Boston%27a%20bir%20gezi%20yapt%C4%B1m.)
^tr-Q0490-answer

**tr-Q0491** — Tom Boston'a kimle gitti?

Who did Tom go to Boston with?

Why: Past forms. [[Turkish#^tr-Q0491|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20Boston%27a%20kimle%20gitti%3F)
^tr-Q0491-answer

**tr-Q0492** — Tom Boston'a kimle gitti?

Who did Tom go to Boston with?

The -DI past uses vowel/consonant harmony and personal endings. Its evidential orientation contrasts with common -mIş forms, though discourse can refine the contrast.

Why: Past forms. [[Turkish#^tr-Q0492|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20Boston%27a%20kimle%20gitti%3F)
^tr-Q0492-answer

**tr-Q0493** — Üçüncü yıldız belirli bir krala ait oldu.

The third star belonged to a certain king.

Expected form: **oldu**

Why: Past forms. [[Turkish#^tr-Q0493|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=%C3%9C%C3%A7%C3%BCnc%C3%BC%20y%C4%B1ld%C4%B1z%20belirli%20bir%20krala%20ait%20oldu.)
^tr-Q0493-answer

**tr-Q0494** — Üçüncü yıldız belirli bir krala ait oldu.

The third star belonged to a certain king.

Expected form: **oldu**

Why: Past forms. [[Turkish#^tr-Q0494|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=%C3%9C%C3%A7%C3%BCnc%C3%BC%20y%C4%B1ld%C4%B1z%20belirli%20bir%20krala%20ait%20oldu.)
^tr-Q0494-answer

**tr-Q0495** — Tom gerçekten gitti mi?

Did Tom really leave?

Expected form: **gitti**

Why: Past forms. [[Turkish#^tr-Q0495|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20ger%C3%A7ekten%20gitti%20mi%3F)
^tr-Q0495-answer

**tr-Q0496** — Tom gerçekten gitti mi?

Did Tom really leave?

Why: Past forms. [[Turkish#^tr-Q0496|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20ger%C3%A7ekten%20gitti%20mi%3F)
^tr-Q0496-answer

**tr-Q0497** — Öğretmen özellikle o noktaya vurgu yaptı.

The teacher particularly emphasized that point.

Why: Past forms. [[Turkish#^tr-Q0497|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=%C3%96%C4%9Fretmen%20%C3%B6zellikle%20o%20noktaya%20vurgu%20yapt%C4%B1.)
^tr-Q0497-answer

**tr-Q0498** — Öğretmen özellikle o noktaya vurgu yaptı.

The teacher particularly emphasized that point.

The -DI past uses vowel/consonant harmony and personal endings. Its evidential orientation contrasts with common -mIş forms, though discourse can refine the contrast.

Why: Past forms. [[Turkish#^tr-Q0498|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=%C3%96%C4%9Fretmen%20%C3%B6zellikle%20o%20noktaya%20vurgu%20yapt%C4%B1.)
^tr-Q0498-answer

**tr-Q0499** — Sami ölümünden 24 saat önce Leyla'yla seks yaptı.

Sami had sex with Layla 24 hours before her death.

Expected form: **yaptı**

Why: Past forms. [[Turkish#^tr-Q0499|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Sami%20%C3%B6l%C3%BCm%C3%BCnden%2024%20saat%20%C3%B6nce%20Leyla%27yla%20seks%20yapt%C4%B1.)
^tr-Q0499-answer

**tr-Q0500** — Sami ölümünden 24 saat önce Leyla'yla seks yaptı.

Sami had sex with Layla 24 hours before her death.

Expected form: **yaptı**

Why: Past forms. [[Turkish#^tr-Q0500|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Sami%20%C3%B6l%C3%BCm%C3%BCnden%2024%20saat%20%C3%B6nce%20Leyla%27yla%20seks%20yapt%C4%B1.)
^tr-Q0500-answer


### Answers 501–550

**tr-Q0501** — Yağmur yağmış olsaydı gitmezdik.

We wouldn't have gone if it had rained.

Expected form: **yağmış**

Why: Reported/evidential forms. [[Turkish#^tr-Q0501|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ya%C4%9Fmur%20ya%C4%9Fm%C4%B1%C5%9F%20olsayd%C4%B1%20gitmezdik.)
^tr-Q0501-answer

**tr-Q0502** — Yağmur yağmış olsaydı gitmezdik.

We wouldn't have gone if it had rained.

Why: Reported/evidential forms. [[Turkish#^tr-Q0502|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ya%C4%9Fmur%20ya%C4%9Fm%C4%B1%C5%9F%20olsayd%C4%B1%20gitmezdik.)
^tr-Q0502-answer

**tr-Q0503** — Sen muhtemelen daha önce bu parka hiç gelmemiş Boston'daki tek kişisin.

You're probably the only person in Boston who has never been to this park before.

Why: Reported/evidential forms. [[Turkish#^tr-Q0503|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Sen%20muhtemelen%20daha%20%C3%B6nce%20bu%20parka%20hi%C3%A7%20gelmemi%C5%9F%20Boston%27daki%20tek%20ki%C5%9Fisin.)
^tr-Q0503-answer

**tr-Q0504** — Sen muhtemelen daha önce bu parka hiç gelmemiş Boston'daki tek kişisin.

You're probably the only person in Boston who has never been to this park before.

The -mIş series often presents information as inferred, discovered or reported. It is not exclusively hearsay. Possessive and verbal morphology may add further endings.

Why: Reported/evidential forms. [[Turkish#^tr-Q0504|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Sen%20muhtemelen%20daha%20%C3%B6nce%20bu%20parka%20hi%C3%A7%20gelmemi%C5%9F%20Boston%27daki%20tek%20ki%C5%9Fisin.)
^tr-Q0504-answer

**tr-Q0505** — Büyükanne bütün aileyi buz kesilmiş bırakarak öldü.

Grandmother died, leaving the whole family stunned.

Expected form: **kesilmiş**

Why: Reported/evidential forms. [[Turkish#^tr-Q0505|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=B%C3%BCy%C3%BCkanne%20b%C3%BCt%C3%BCn%20aileyi%20buz%20kesilmi%C5%9F%20b%C4%B1rakarak%20%C3%B6ld%C3%BC.)
^tr-Q0505-answer

**tr-Q0506** — Büyükanne bütün aileyi buz kesilmiş bırakarak öldü.

Grandmother died, leaving the whole family stunned.

Expected form: **kesilmiş**

Why: Reported/evidential forms. [[Turkish#^tr-Q0506|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=B%C3%BCy%C3%BCkanne%20b%C3%BCt%C3%BCn%20aileyi%20buz%20kesilmi%C5%9F%20b%C4%B1rakarak%20%C3%B6ld%C3%BC.)
^tr-Q0506-answer

**tr-Q0507** — Tom beni tanımış gibiydi.

Tom seemed to have recognized me.

Expected form: **tanımış**

Why: Reported/evidential forms. [[Turkish#^tr-Q0507|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20beni%20tan%C4%B1m%C4%B1%C5%9F%20gibiydi.)
^tr-Q0507-answer

**tr-Q0508** — Tom beni tanımış gibiydi.

Tom seemed to have recognized me.

Why: Reported/evidential forms. [[Turkish#^tr-Q0508|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20beni%20tan%C4%B1m%C4%B1%C5%9F%20gibiydi.)
^tr-Q0508-answer

**tr-Q0509** — Kaldırılmış eller bir protesto sembolü haline gelmiştir.

Raised hands have become a symbol of protest.

Why: Reported/evidential forms. [[Turkish#^tr-Q0509|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Kald%C4%B1r%C4%B1lm%C4%B1%C5%9F%20eller%20bir%20protesto%20sembol%C3%BC%20haline%20gelmi%C5%9Ftir.)
^tr-Q0509-answer

**tr-Q0510** — Kaldırılmış eller bir protesto sembolü haline gelmiştir.

Raised hands have become a symbol of protest.

The -mIş series often presents information as inferred, discovered or reported. It is not exclusively hearsay. Possessive and verbal morphology may add further endings.

Why: Reported/evidential forms. [[Turkish#^tr-Q0510|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Kald%C4%B1r%C4%B1lm%C4%B1%C5%9F%20eller%20bir%20protesto%20sembol%C3%BC%20haline%20gelmi%C5%9Ftir.)
^tr-Q0510-answer

**tr-Q0511** — Tom o yatırımı yapmış olsaydı, bugün bir milyarder olurdu.

If Tom had made that investment, he'd be a billionaire today.

Expected form: **yapmış**

Why: Reported/evidential forms. [[Turkish#^tr-Q0511|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20o%20yat%C4%B1r%C4%B1m%C4%B1%20yapm%C4%B1%C5%9F%20olsayd%C4%B1%2C%20bug%C3%BCn%20bir%20milyarder%20olurdu.)
^tr-Q0511-answer

**tr-Q0512** — Tom o yatırımı yapmış olsaydı, bugün bir milyarder olurdu.

If Tom had made that investment, he'd be a billionaire today.

Expected form: **yapmış**

Why: Reported/evidential forms. [[Turkish#^tr-Q0512|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20o%20yat%C4%B1r%C4%B1m%C4%B1%20yapm%C4%B1%C5%9F%20olsayd%C4%B1%2C%20bug%C3%BCn%20bir%20milyarder%20olurdu.)
^tr-Q0512-answer

**tr-Q0513** — Ne kadar süredir gitmiş olacağını düşünüyorsun?

How long do you think you'll be gone?

Expected form: **gitmiş**

Why: Reported/evidential forms. [[Turkish#^tr-Q0513|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ne%20kadar%20s%C3%BCredir%20gitmi%C5%9F%20olaca%C4%9F%C4%B1n%C4%B1%20d%C3%BC%C5%9F%C3%BCn%C3%BCyorsun%3F)
^tr-Q0513-answer

**tr-Q0514** — Ne kadar süredir gitmiş olacağını düşünüyorsun?

How long do you think you'll be gone?

Why: Reported/evidential forms. [[Turkish#^tr-Q0514|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ne%20kadar%20s%C3%BCredir%20gitmi%C5%9F%20olaca%C4%9F%C4%B1n%C4%B1%20d%C3%BC%C5%9F%C3%BCn%C3%BCyorsun%3F)
^tr-Q0514-answer

**tr-Q0515** — Tom Mary'nin cesareti kırılmış olmadığını söyledi.

Tom said Mary wasn't discouraged.

Why: Reported/evidential forms. [[Turkish#^tr-Q0515|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20Mary%27nin%20cesareti%20k%C4%B1r%C4%B1lm%C4%B1%C5%9F%20olmad%C4%B1%C4%9F%C4%B1n%C4%B1%20s%C3%B6yledi.)
^tr-Q0515-answer

**tr-Q0516** — Tom Mary'nin cesareti kırılmış olmadığını söyledi.

Tom said Mary wasn't discouraged.

The -mIş series often presents information as inferred, discovered or reported. It is not exclusively hearsay. Possessive and verbal morphology may add further endings.

Why: Reported/evidential forms. [[Turkish#^tr-Q0516|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20Mary%27nin%20cesareti%20k%C4%B1r%C4%B1lm%C4%B1%C5%9F%20olmad%C4%B1%C4%9F%C4%B1n%C4%B1%20s%C3%B6yledi.)
^tr-Q0516-answer

**tr-Q0517** — Sanki şaşırmış gibi görünüyordunuz.

It looked like you were surprised.

Expected form: **şaşırmış**

Why: Reported/evidential forms. [[Turkish#^tr-Q0517|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Sanki%20%C5%9Fa%C5%9F%C4%B1rm%C4%B1%C5%9F%20gibi%20g%C3%B6r%C3%BCn%C3%BCyordunuz.)
^tr-Q0517-answer

**tr-Q0518** — Sanki şaşırmış gibi görünüyordunuz.

It looked like you were surprised.

Expected form: **şaşırmış**

Why: Reported/evidential forms. [[Turkish#^tr-Q0518|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Sanki%20%C5%9Fa%C5%9F%C4%B1rm%C4%B1%C5%9F%20gibi%20g%C3%B6r%C3%BCn%C3%BCyordunuz.)
^tr-Q0518-answer

**tr-Q0519** — Tom, adını kara tahtaya yazılmış gördü.

Tom saw his name written on the blackboard.

Expected form: **yazılmış**

Why: Reported/evidential forms. [[Turkish#^tr-Q0519|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%2C%20ad%C4%B1n%C4%B1%20kara%20tahtaya%20yaz%C4%B1lm%C4%B1%C5%9F%20g%C3%B6rd%C3%BC.)
^tr-Q0519-answer

**tr-Q0520** — Tom, adını kara tahtaya yazılmış gördü.

Tom saw his name written on the blackboard.

Why: Reported/evidential forms. [[Turkish#^tr-Q0520|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%2C%20ad%C4%B1n%C4%B1%20kara%20tahtaya%20yaz%C4%B1lm%C4%B1%C5%9F%20g%C3%B6rd%C3%BC.)
^tr-Q0520-answer

**tr-Q0521** — O hayal kırıklığına uğramış ve üzgün görünüyordu.

She seemed disappointed and sad.

Why: Reported/evidential forms. [[Turkish#^tr-Q0521|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=O%20hayal%20k%C4%B1r%C4%B1kl%C4%B1%C4%9F%C4%B1na%20u%C4%9Fram%C4%B1%C5%9F%20ve%20%C3%BCzg%C3%BCn%20g%C3%B6r%C3%BCn%C3%BCyordu.)
^tr-Q0521-answer

**tr-Q0522** — O hayal kırıklığına uğramış ve üzgün görünüyordu.

She seemed disappointed and sad.

The -mIş series often presents information as inferred, discovered or reported. It is not exclusively hearsay. Possessive and verbal morphology may add further endings.

Why: Reported/evidential forms. [[Turkish#^tr-Q0522|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=O%20hayal%20k%C4%B1r%C4%B1kl%C4%B1%C4%9F%C4%B1na%20u%C4%9Fram%C4%B1%C5%9F%20ve%20%C3%BCzg%C3%BCn%20g%C3%B6r%C3%BCn%C3%BCyordu.)
^tr-Q0522-answer

**tr-Q0523** — Raporunuz toplantı için zamanında bitmiş olacak mı?

Will your report be finished in time for the meeting?

Expected form: **bitmiş**

Why: Reported/evidential forms. [[Turkish#^tr-Q0523|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Raporunuz%20toplant%C4%B1%20i%C3%A7in%20zaman%C4%B1nda%20bitmi%C5%9F%20olacak%20m%C4%B1%3F)
^tr-Q0523-answer

**tr-Q0524** — Raporunuz toplantı için zamanında bitmiş olacak mı?

Will your report be finished in time for the meeting?

Expected form: **bitmiş**

Why: Reported/evidential forms. [[Turkish#^tr-Q0524|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Raporunuz%20toplant%C4%B1%20i%C3%A7in%20zaman%C4%B1nda%20bitmi%C5%9F%20olacak%20m%C4%B1%3F)
^tr-Q0524-answer

**tr-Q0525** — Birisi şemsiyeni yanlışlıkla almış olmalı.

Somebody must've taken your umbrella by mistake.

Expected form: **almış**

Why: Reported/evidential forms. [[Turkish#^tr-Q0525|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Birisi%20%C5%9Femsiyeni%20yanl%C4%B1%C5%9Fl%C4%B1kla%20alm%C4%B1%C5%9F%20olmal%C4%B1.)
^tr-Q0525-answer

**tr-Q0526** — Birisi şemsiyeni yanlışlıkla almış olmalı.

Somebody must've taken your umbrella by mistake.

Why: Reported/evidential forms. [[Turkish#^tr-Q0526|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Birisi%20%C5%9Femsiyeni%20yanl%C4%B1%C5%9Fl%C4%B1kla%20alm%C4%B1%C5%9F%20olmal%C4%B1.)
^tr-Q0526-answer

**tr-Q0527** — Kaçmış bir atı yakalamak söylenmiş bir sözü geri almaktan daha kolaydır.

It is easier to catch an escaped horse than to take back an escaped word.

Why: Reported/evidential forms. [[Turkish#^tr-Q0527|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ka%C3%A7m%C4%B1%C5%9F%20bir%20at%C4%B1%20yakalamak%20s%C3%B6ylenmi%C5%9F%20bir%20s%C3%B6z%C3%BC%20geri%20almaktan%20daha%20kolayd%C4%B1r.)
^tr-Q0527-answer

**tr-Q0528** — Kaçmış bir atı yakalamak söylenmiş bir sözü geri almaktan daha kolaydır.

It is easier to catch an escaped horse than to take back an escaped word.

The -mIş series often presents information as inferred, discovered or reported. It is not exclusively hearsay. Possessive and verbal morphology may add further endings.

Why: Reported/evidential forms. [[Turkish#^tr-Q0528|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ka%C3%A7m%C4%B1%C5%9F%20bir%20at%C4%B1%20yakalamak%20s%C3%B6ylenmi%C5%9F%20bir%20s%C3%B6z%C3%BC%20geri%20almaktan%20daha%20kolayd%C4%B1r.)
^tr-Q0528-answer

**tr-Q0529** — Tom bile şaşırmış görünüyordu.

Even Tom looked surprised.

Expected form: **şaşırmış**

Why: Reported/evidential forms. [[Turkish#^tr-Q0529|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20bile%20%C5%9Fa%C5%9F%C4%B1rm%C4%B1%C5%9F%20g%C3%B6r%C3%BCn%C3%BCyordu.)
^tr-Q0529-answer

**tr-Q0530** — Tom bile şaşırmış görünüyordu.

Even Tom looked surprised.

Expected form: **şaşırmış**

Why: Reported/evidential forms. [[Turkish#^tr-Q0530|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20bile%20%C5%9Fa%C5%9F%C4%B1rm%C4%B1%C5%9F%20g%C3%B6r%C3%BCn%C3%BCyordu.)
^tr-Q0530-answer

**tr-Q0531** — Doğruyu söylemek gerekirse, o hala altmış yaşın altındadır.

To tell the truth, he is still under sixty.

Expected form: **altmış**

Why: Reported/evidential forms. [[Turkish#^tr-Q0531|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Do%C4%9Fruyu%20s%C3%B6ylemek%20gerekirse%2C%20o%20hala%20altm%C4%B1%C5%9F%20ya%C5%9F%C4%B1n%20alt%C4%B1ndad%C4%B1r.)
^tr-Q0531-answer

**tr-Q0532** — Doğruyu söylemek gerekirse, o hala altmış yaşın altındadır.

To tell the truth, he is still under sixty.

Why: Reported/evidential forms. [[Turkish#^tr-Q0532|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Do%C4%9Fruyu%20s%C3%B6ylemek%20gerekirse%2C%20o%20hala%20altm%C4%B1%C5%9F%20ya%C5%9F%C4%B1n%20alt%C4%B1ndad%C4%B1r.)
^tr-Q0532-answer

**tr-Q0533** — Bana bir hediye göndermiş.

He sent me a present.

Why: Reported/evidential forms. [[Turkish#^tr-Q0533|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bana%20bir%20hediye%20g%C3%B6ndermi%C5%9F.)
^tr-Q0533-answer

**tr-Q0534** — Bana bir hediye göndermiş.

He sent me a present.

The -mIş series often presents information as inferred, discovered or reported. It is not exclusively hearsay. Possessive and verbal morphology may add further endings.

Why: Reported/evidential forms. [[Turkish#^tr-Q0534|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bana%20bir%20hediye%20g%C3%B6ndermi%C5%9F.)
^tr-Q0534-answer

**tr-Q0535** — Kendimi tamamen bunalmış hissediyordum.

I felt utterly overwhelmed.

Expected form: **bunalmış**

Why: Reported/evidential forms. [[Turkish#^tr-Q0535|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Kendimi%20tamamen%20bunalm%C4%B1%C5%9F%20hissediyordum.)
^tr-Q0535-answer

**tr-Q0536** — Kendimi tamamen bunalmış hissediyordum.

I felt utterly overwhelmed.

Expected form: **bunalmış**

Why: Reported/evidential forms. [[Turkish#^tr-Q0536|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Kendimi%20tamamen%20bunalm%C4%B1%C5%9F%20hissediyordum.)
^tr-Q0536-answer

**tr-Q0537** — Tom'un bize yardım etmiş olabileceğini düşünüyor musun?

Do you think Tom would've helped us?

Expected form: **etmiş**

Why: Reported/evidential forms. [[Turkish#^tr-Q0537|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%27un%20bize%20yard%C4%B1m%20etmi%C5%9F%20olabilece%C4%9Fini%20d%C3%BC%C5%9F%C3%BCn%C3%BCyor%20musun%3F)
^tr-Q0537-answer

**tr-Q0538** — Tom'un bize yardım etmiş olabileceğini düşünüyor musun?

Do you think Tom would've helped us?

Why: Reported/evidential forms. [[Turkish#^tr-Q0538|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%27un%20bize%20yard%C4%B1m%20etmi%C5%9F%20olabilece%C4%9Fini%20d%C3%BC%C5%9F%C3%BCn%C3%BCyor%20musun%3F)
^tr-Q0538-answer

**tr-Q0539** — Paranın mutluluğu satın alamayacağını söyleyen her kimse, nereden alışveriş yapacağını bilmiyormuş.

Whoever said money can't buy happiness simply didn't know where to go shopping.

Why: Reported/evidential forms. [[Turkish#^tr-Q0539|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Paran%C4%B1n%20mutlulu%C4%9Fu%20sat%C4%B1n%20alamayaca%C4%9F%C4%B1n%C4%B1%20s%C3%B6yleyen%20her%20kimse%2C%20nereden%20al%C4%B1%C5%9Fveri%C5%9F%20yapaca%C4%9F%C4%B1n%C4%B1%20bilmiyormu%C5%9F.)
^tr-Q0539-answer

**tr-Q0540** — Paranın mutluluğu satın alamayacağını söyleyen her kimse, nereden alışveriş yapacağını bilmiyormuş.

Whoever said money can't buy happiness simply didn't know where to go shopping.

The -mIş series often presents information as inferred, discovered or reported. It is not exclusively hearsay. Possessive and verbal morphology may add further endings.

Why: Reported/evidential forms. [[Turkish#^tr-Q0540|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Paran%C4%B1n%20mutlulu%C4%9Fu%20sat%C4%B1n%20alamayaca%C4%9F%C4%B1n%C4%B1%20s%C3%B6yleyen%20her%20kimse%2C%20nereden%20al%C4%B1%C5%9Fveri%C5%9F%20yapaca%C4%9F%C4%B1n%C4%B1%20bilmiyormu%C5%9F.)
^tr-Q0540-answer

**tr-Q0541** — Mary, Tom'un söylemiş olduklarından çok rencide oldu.

Mary was highly offended by what Tom had said.

Expected form: **söylemiş**

Why: Reported/evidential forms. [[Turkish#^tr-Q0541|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Mary%2C%20Tom%27un%20s%C3%B6ylemi%C5%9F%20olduklar%C4%B1ndan%20%C3%A7ok%20rencide%20oldu.)
^tr-Q0541-answer

**tr-Q0542** — Mary, Tom'un söylemiş olduklarından çok rencide oldu.

Mary was highly offended by what Tom had said.

Expected form: **söylemiş**

Why: Reported/evidential forms. [[Turkish#^tr-Q0542|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Mary%2C%20Tom%27un%20s%C3%B6ylemi%C5%9F%20olduklar%C4%B1ndan%20%C3%A7ok%20rencide%20oldu.)
^tr-Q0542-answer

**tr-Q0543** — Tom, Mary'nin yalnızca bir kez onunla birlikte kano yapmış olduğunu söyledi.

Tom said Mary has only gone canoeing with him once.

Expected form: **yapmış**

Why: Reported/evidential forms. [[Turkish#^tr-Q0543|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%2C%20Mary%27nin%20yaln%C4%B1zca%20bir%20kez%20onunla%20birlikte%20kano%20yapm%C4%B1%C5%9F%20oldu%C4%9Funu%20s%C3%B6yledi.)
^tr-Q0543-answer

**tr-Q0544** — Tom, Mary'nin yalnızca bir kez onunla birlikte kano yapmış olduğunu söyledi.

Tom said Mary has only gone canoeing with him once.

Why: Reported/evidential forms. [[Turkish#^tr-Q0544|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%2C%20Mary%27nin%20yaln%C4%B1zca%20bir%20kez%20onunla%20birlikte%20kano%20yapm%C4%B1%C5%9F%20oldu%C4%9Funu%20s%C3%B6yledi.)
^tr-Q0544-answer

**tr-Q0545** — Tom çok adanmış değildi.

Tom wasn't very dedicated.

Why: Reported/evidential forms. [[Turkish#^tr-Q0545|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20%C3%A7ok%20adanm%C4%B1%C5%9F%20de%C4%9Fildi.)
^tr-Q0545-answer

**tr-Q0546** — Tom çok adanmış değildi.

Tom wasn't very dedicated.

The -mIş series often presents information as inferred, discovered or reported. It is not exclusively hearsay. Possessive and verbal morphology may add further endings.

Why: Reported/evidential forms. [[Turkish#^tr-Q0546|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20%C3%A7ok%20adanm%C4%B1%C5%9F%20de%C4%9Fildi.)
^tr-Q0546-answer

**tr-Q0547** — Bay Tanaka bize yeni doğmuş çocuğunun bir sürü resmini gösterdi.

Mr. Tanaka showed us many pictures of his newborn baby.

Expected form: **doğmuş**

Why: Reported/evidential forms. [[Turkish#^tr-Q0547|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bay%20Tanaka%20bize%20yeni%20do%C4%9Fmu%C5%9F%20%C3%A7ocu%C4%9Funun%20bir%20s%C3%BCr%C3%BC%20resmini%20g%C3%B6sterdi.)
^tr-Q0547-answer

**tr-Q0548** — Bay Tanaka bize yeni doğmuş çocuğunun bir sürü resmini gösterdi.

Mr. Tanaka showed us many pictures of his newborn baby.

Expected form: **doğmuş**

Why: Reported/evidential forms. [[Turkish#^tr-Q0548|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bay%20Tanaka%20bize%20yeni%20do%C4%9Fmu%C5%9F%20%C3%A7ocu%C4%9Funun%20bir%20s%C3%BCr%C3%BC%20resmini%20g%C3%B6sterdi.)
^tr-Q0548-answer

**tr-Q0549** — Ben değişmiş bir insanım.

I'm a changed man.

Expected form: **değişmiş**

Why: Reported/evidential forms. [[Turkish#^tr-Q0549|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ben%20de%C4%9Fi%C5%9Fmi%C5%9F%20bir%20insan%C4%B1m.)
^tr-Q0549-answer

**tr-Q0550** — Ben değişmiş bir insanım.

I'm a changed man.

Why: Reported/evidential forms. [[Turkish#^tr-Q0550|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ben%20de%C4%9Fi%C5%9Fmi%C5%9F%20bir%20insan%C4%B1m.)
^tr-Q0550-answer


### Answers 551–600

**tr-Q0551** — Annesi çalışmaya devam edecek.

Her mother will continue to work.

Why: Future forms. [[Turkish#^tr-Q0551|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Annesi%20%C3%A7al%C4%B1%C5%9Fmaya%20devam%20edecek.)
^tr-Q0551-answer

**tr-Q0552** — Annesi çalışmaya devam edecek.

Her mother will continue to work.

Future -AcAk harmonises and combines with person endings. Intervocalic k can become ğ before a vowel suffix. The same form can also participate in a nominal or adjective construction.

Why: Future forms. [[Turkish#^tr-Q0552|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Annesi%20%C3%A7al%C4%B1%C5%9Fmaya%20devam%20edecek.)
^tr-Q0552-answer

**tr-Q0553** — Tom asla gitmene izin vermeyecek.

Tom will never allow you to go.

Expected form: **vermeyecek**

Why: Future forms. [[Turkish#^tr-Q0553|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20asla%20gitmene%20izin%20vermeyecek.)
^tr-Q0553-answer

**tr-Q0554** — Tom asla gitmene izin vermeyecek.

Tom will never allow you to go.

Expected form: **vermeyecek**

Why: Future forms. [[Turkish#^tr-Q0554|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20asla%20gitmene%20izin%20vermeyecek.)
^tr-Q0554-answer

**tr-Q0555** — Boston'a nasıl gideceksin?

How will you go to Boston?

Expected form: **gideceksin**

Why: Future forms. [[Turkish#^tr-Q0555|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Boston%27a%20nas%C4%B1l%20gideceksin%3F)
^tr-Q0555-answer

**tr-Q0556** — Boston'a nasıl gideceksin?

How will you go to Boston?

Why: Future forms. [[Turkish#^tr-Q0556|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Boston%27a%20nas%C4%B1l%20gideceksin%3F)
^tr-Q0556-answer

**tr-Q0557** — Sanırım daha kalın bir şey giysem iyi olacak.

I guess I'd better change into something warmer.

Why: Future forms. [[Turkish#^tr-Q0557|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=San%C4%B1r%C4%B1m%20daha%20kal%C4%B1n%20bir%20%C5%9Fey%20giysem%20iyi%20olacak.)
^tr-Q0557-answer

**tr-Q0558** — Sanırım daha kalın bir şey giysem iyi olacak.

I guess I'd better change into something warmer.

Future -AcAk harmonises and combines with person endings. Intervocalic k can become ğ before a vowel suffix. The same form can also participate in a nominal or adjective construction.

Why: Future forms. [[Turkish#^tr-Q0558|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=San%C4%B1r%C4%B1m%20daha%20kal%C4%B1n%20bir%20%C5%9Fey%20giysem%20iyi%20olacak.)
^tr-Q0558-answer

**tr-Q0559** — Şimdi Tom'u arayacağım.

I'm going to look for Tom now.

Expected form: **arayacağım**

Why: Future forms. [[Turkish#^tr-Q0559|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=%C5%9Eimdi%20Tom%27u%20arayaca%C4%9F%C4%B1m.)
^tr-Q0559-answer

**tr-Q0560** — Şimdi Tom'u arayacağım.

I'm going to look for Tom now.

Expected form: **arayacağım**

Why: Future forms. [[Turkish#^tr-Q0560|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=%C5%9Eimdi%20Tom%27u%20arayaca%C4%9F%C4%B1m.)
^tr-Q0560-answer

**tr-Q0561** — Tom aptalca bir şey yapmayacak.

Tom won't do anything crazy.

Expected form: **yapmayacak**

Why: Future forms. [[Turkish#^tr-Q0561|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20aptalca%20bir%20%C5%9Fey%20yapmayacak.)
^tr-Q0561-answer

**tr-Q0562** — Tom aptalca bir şey yapmayacak.

Tom won't do anything crazy.

Why: Future forms. [[Turkish#^tr-Q0562|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20aptalca%20bir%20%C5%9Fey%20yapmayacak.)
^tr-Q0562-answer

**tr-Q0563** — Ben hemen seninle olacağım.

I'll be with you right away.

Why: Future forms. [[Turkish#^tr-Q0563|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ben%20hemen%20seninle%20olaca%C4%9F%C4%B1m.)
^tr-Q0563-answer

**tr-Q0564** — Ben hemen seninle olacağım.

I'll be with you right away.

Future -AcAk harmonises and combines with person endings. Intervocalic k can become ğ before a vowel suffix. The same form can also participate in a nominal or adjective construction.

Why: Future forms. [[Turkish#^tr-Q0564|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ben%20hemen%20seninle%20olaca%C4%9F%C4%B1m.)
^tr-Q0564-answer

**tr-Q0565** — Tom bu öğleden sonra gelecek.

Tom will come this afternoon.

Expected form: **gelecek**

Why: Future forms. [[Turkish#^tr-Q0565|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20bu%20%C3%B6%C4%9Fleden%20sonra%20gelecek.)
^tr-Q0565-answer

**tr-Q0566** — Tom bu öğleden sonra gelecek.

Tom will come this afternoon.

Expected form: **gelecek**

Why: Future forms. [[Turkish#^tr-Q0566|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20bu%20%C3%B6%C4%9Fleden%20sonra%20gelecek.)
^tr-Q0566-answer

**tr-Q0567** — Gelecek sene Çince öğrenmek istiyorum.

I want to learn Chinese next year.

Expected form: **Gelecek**

Why: Future forms. [[Turkish#^tr-Q0567|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Gelecek%20sene%20%C3%87ince%20%C3%B6%C4%9Frenmek%20istiyorum.)
^tr-Q0567-answer

**tr-Q0568** — Gelecek sene Çince öğrenmek istiyorum.

I want to learn Chinese next year.

Why: Future forms. [[Turkish#^tr-Q0568|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Gelecek%20sene%20%C3%87ince%20%C3%B6%C4%9Frenmek%20istiyorum.)
^tr-Q0568-answer

**tr-Q0569** — Tom bu yıl tatil yapmayacak.

Tom won't take a vacation this year.

Why: Future forms. [[Turkish#^tr-Q0569|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20bu%20y%C4%B1l%20tatil%20yapmayacak.)
^tr-Q0569-answer

**tr-Q0570** — Tom bu yıl tatil yapmayacak.

Tom won't take a vacation this year.

Future -AcAk harmonises and combines with person endings. Intervocalic k can become ğ before a vowel suffix. The same form can also participate in a nominal or adjective construction.

Why: Future forms. [[Turkish#^tr-Q0570|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20bu%20y%C4%B1l%20tatil%20yapmayacak.)
^tr-Q0570-answer

**tr-Q0571** — "Gelecek sene nereye gidiyoruz?" "Fransa'ya."

"Where are we going next year?" "To France."

Expected form: **Gelecek**

Why: Future forms. [[Turkish#^tr-Q0571|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=%22Gelecek%20sene%20nereye%20gidiyoruz%3F%22%20%22Fransa%27ya.%22)
^tr-Q0571-answer

**tr-Q0572** — "Gelecek sene nereye gidiyoruz?" "Fransa'ya."

"Where are we going next year?" "To France."

Expected form: **Gelecek**

Why: Future forms. [[Turkish#^tr-Q0572|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=%22Gelecek%20sene%20nereye%20gidiyoruz%3F%22%20%22Fransa%27ya.%22)
^tr-Q0572-answer

**tr-Q0573** — Tom söyleyecek çok önemli bir şeyi olduğunu söyledi.

Tom said he had something very important to say.

Expected form: **söyleyecek**

Why: Future forms. [[Turkish#^tr-Q0573|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20s%C3%B6yleyecek%20%C3%A7ok%20%C3%B6nemli%20bir%20%C5%9Feyi%20oldu%C4%9Funu%20s%C3%B6yledi.)
^tr-Q0573-answer

**tr-Q0574** — Tom söyleyecek çok önemli bir şeyi olduğunu söyledi.

Tom said he had something very important to say.

Why: Future forms. [[Turkish#^tr-Q0574|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20s%C3%B6yleyecek%20%C3%A7ok%20%C3%B6nemli%20bir%20%C5%9Feyi%20oldu%C4%9Funu%20s%C3%B6yledi.)
^tr-Q0574-answer

**tr-Q0575** — Tom olabilecek herhangi bir şey için hazır.

Tom is prepared for anything that may happen.

Why: Future forms. [[Turkish#^tr-Q0575|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20olabilecek%20herhangi%20bir%20%C5%9Fey%20i%C3%A7in%20haz%C4%B1r.)
^tr-Q0575-answer

**tr-Q0576** — Tom olabilecek herhangi bir şey için hazır.

Tom is prepared for anything that may happen.

Future -AcAk harmonises and combines with person endings. Intervocalic k can become ğ before a vowel suffix. The same form can also participate in a nominal or adjective construction.

Why: Future forms. [[Turkish#^tr-Q0576|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20olabilecek%20herhangi%20bir%20%C5%9Fey%20i%C3%A7in%20haz%C4%B1r.)
^tr-Q0576-answer

**tr-Q0577** — Terbiyeni nasıl takınacağın konusunda dikkatli olmak zorunda olacaksın.

You'll have to be careful how you behave yourself.

Expected form: **olacaksın**

Why: Future forms. [[Turkish#^tr-Q0577|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Terbiyeni%20nas%C4%B1l%20tak%C4%B1naca%C4%9F%C4%B1n%20konusunda%20dikkatli%20olmak%20zorunda%20olacaks%C4%B1n.)
^tr-Q0577-answer

**tr-Q0578** — Terbiyeni nasıl takınacağın konusunda dikkatli olmak zorunda olacaksın.

You'll have to be careful how you behave yourself.

Expected form: **olacaksın**

Why: Future forms. [[Turkish#^tr-Q0578|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Terbiyeni%20nas%C4%B1l%20tak%C4%B1naca%C4%9F%C4%B1n%20konusunda%20dikkatli%20olmak%20zorunda%20olacaks%C4%B1n.)
^tr-Q0578-answer

**tr-Q0579** — Ne zaman iyi bir oyun yazacağım?

When will I write a good play?

Expected form: **yazacağım**

Why: Future forms. [[Turkish#^tr-Q0579|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ne%20zaman%20iyi%20bir%20oyun%20yazaca%C4%9F%C4%B1m%3F)
^tr-Q0579-answer

**tr-Q0580** — Ne zaman iyi bir oyun yazacağım?

When will I write a good play?

Why: Future forms. [[Turkish#^tr-Q0580|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ne%20zaman%20iyi%20bir%20oyun%20yazaca%C4%9F%C4%B1m%3F)
^tr-Q0580-answer

**tr-Q0581** — O, Boston'dayken Tom'un ileri sınıflarından birine öğretmenlik yapacağım.

I'm going to teach one of Tom's advanced classes while he's in Boston.

Why: Future forms. [[Turkish#^tr-Q0581|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=O%2C%20Boston%27dayken%20Tom%27un%20ileri%20s%C4%B1n%C4%B1flar%C4%B1ndan%20birine%20%C3%B6%C4%9Fretmenlik%20yapaca%C4%9F%C4%B1m.)
^tr-Q0581-answer

**tr-Q0582** — O, Boston'dayken Tom'un ileri sınıflarından birine öğretmenlik yapacağım.

I'm going to teach one of Tom's advanced classes while he's in Boston.

Future -AcAk harmonises and combines with person endings. Intervocalic k can become ğ before a vowel suffix. The same form can also participate in a nominal or adjective construction.

Why: Future forms. [[Turkish#^tr-Q0582|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=O%2C%20Boston%27dayken%20Tom%27un%20ileri%20s%C4%B1n%C4%B1flar%C4%B1ndan%20birine%20%C3%B6%C4%9Fretmenlik%20yapaca%C4%9F%C4%B1m.)
^tr-Q0582-answer

**tr-Q0583** — Kısa bir süre burada kalacağım.

I will stay here for a short period.

Expected form: **kalacağım**

Why: Future forms. [[Turkish#^tr-Q0583|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=K%C4%B1sa%20bir%20s%C3%BCre%20burada%20kalaca%C4%9F%C4%B1m.)
^tr-Q0583-answer

**tr-Q0584** — Kısa bir süre burada kalacağım.

I will stay here for a short period.

Expected form: **kalacağım**

Why: Future forms. [[Turkish#^tr-Q0584|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=K%C4%B1sa%20bir%20s%C3%BCre%20burada%20kalaca%C4%9F%C4%B1m.)
^tr-Q0584-answer

**tr-Q0585** — Tom bunun neden olduğunu açıklayacak.

Tom will explain why that happened.

Expected form: **açıklayacak**

Why: Future forms. [[Turkish#^tr-Q0585|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20bunun%20neden%20oldu%C4%9Funu%20a%C3%A7%C4%B1klayacak.)
^tr-Q0585-answer

**tr-Q0586** — Tom bunun neden olduğunu açıklayacak.

Tom will explain why that happened.

Why: Future forms. [[Turkish#^tr-Q0586|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20bunun%20neden%20oldu%C4%9Funu%20a%C3%A7%C4%B1klayacak.)
^tr-Q0586-answer

**tr-Q0587** — Tom yarın ayrılmayacak.

Tom won't leave tomorrow.

Why: Future forms. [[Turkish#^tr-Q0587|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20yar%C4%B1n%20ayr%C4%B1lmayacak.)
^tr-Q0587-answer

**tr-Q0588** — Tom yarın ayrılmayacak.

Tom won't leave tomorrow.

Future -AcAk harmonises and combines with person endings. Intervocalic k can become ğ before a vowel suffix. The same form can also participate in a nominal or adjective construction.

Why: Future forms. [[Turkish#^tr-Q0588|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20yar%C4%B1n%20ayr%C4%B1lmayacak.)
^tr-Q0588-answer

**tr-Q0589** — Ben akşam yemeğini ödeyeceğim.

I'll pay for dinner.

Expected form: **ödeyeceğim**

Why: Future forms. [[Turkish#^tr-Q0589|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ben%20ak%C5%9Fam%20yeme%C4%9Fini%20%C3%B6deyece%C4%9Fim.)
^tr-Q0589-answer

**tr-Q0590** — Ben akşam yemeğini ödeyeceğim.

I'll pay for dinner.

Expected form: **ödeyeceğim**

Why: Future forms. [[Turkish#^tr-Q0590|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ben%20ak%C5%9Fam%20yeme%C4%9Fini%20%C3%B6deyece%C4%9Fim.)
^tr-Q0590-answer

**tr-Q0591** — Bu gece eğlenceli olacak.

Tonight's going to be fun.

Expected form: **olacak**

Why: Future forms. [[Turkish#^tr-Q0591|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bu%20gece%20e%C4%9Flenceli%20olacak.)
^tr-Q0591-answer

**tr-Q0592** — Bu gece eğlenceli olacak.

Tonight's going to be fun.

Why: Future forms. [[Turkish#^tr-Q0592|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bu%20gece%20e%C4%9Flenceli%20olacak.)
^tr-Q0592-answer

**tr-Q0593** — Tom hatalı olduğunu asla itiraf etmeyecek.

Tom is never going to admit that he was wrong.

Why: Future forms. [[Turkish#^tr-Q0593|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20hatal%C4%B1%20oldu%C4%9Funu%20asla%20itiraf%20etmeyecek.)
^tr-Q0593-answer

**tr-Q0594** — Tom hatalı olduğunu asla itiraf etmeyecek.

Tom is never going to admit that he was wrong.

Future -AcAk harmonises and combines with person endings. Intervocalic k can become ğ before a vowel suffix. The same form can also participate in a nominal or adjective construction.

Why: Future forms. [[Turkish#^tr-Q0594|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20hatal%C4%B1%20oldu%C4%9Funu%20asla%20itiraf%20etmeyecek.)
^tr-Q0594-answer

**tr-Q0595** — Ben şimdi televizyondaki haberleri izleyeceğim.

I'll now watch the news on TV.

Expected form: **izleyeceğim**

Why: Future forms. [[Turkish#^tr-Q0595|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ben%20%C5%9Fimdi%20televizyondaki%20haberleri%20izleyece%C4%9Fim.)
^tr-Q0595-answer

**tr-Q0596** — Ben şimdi televizyondaki haberleri izleyeceğim.

I'll now watch the news on TV.

Expected form: **izleyeceğim**

Why: Future forms. [[Turkish#^tr-Q0596|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ben%20%C5%9Fimdi%20televizyondaki%20haberleri%20izleyece%C4%9Fim.)
^tr-Q0596-answer

**tr-Q0597** — Sanırım bunu bu hafta kese kağıdına koyacağım.

I think I'll brown bag it this week.

Expected form: **koyacağım**

Why: Future forms. [[Turkish#^tr-Q0597|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=San%C4%B1r%C4%B1m%20bunu%20bu%20hafta%20kese%20ka%C4%9F%C4%B1d%C4%B1na%20koyaca%C4%9F%C4%B1m.)
^tr-Q0597-answer

**tr-Q0598** — Sanırım bunu bu hafta kese kağıdına koyacağım.

I think I'll brown bag it this week.

Why: Future forms. [[Turkish#^tr-Q0598|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=San%C4%B1r%C4%B1m%20bunu%20bu%20hafta%20kese%20ka%C4%9F%C4%B1d%C4%B1na%20koyaca%C4%9F%C4%B1m.)
^tr-Q0598-answer

**tr-Q0599** — Hepimiz gelecek hafta seni görmeyi umuyoruz.

We all anticipate seeing you next weekend.

Why: Future forms. [[Turkish#^tr-Q0599|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Hepimiz%20gelecek%20hafta%20seni%20g%C3%B6rmeyi%20umuyoruz.)
^tr-Q0599-answer

**tr-Q0600** — Hepimiz gelecek hafta seni görmeyi umuyoruz.

We all anticipate seeing you next weekend.

Future -AcAk harmonises and combines with person endings. Intervocalic k can become ğ before a vowel suffix. The same form can also participate in a nominal or adjective construction.

Why: Future forms. [[Turkish#^tr-Q0600|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Hepimiz%20gelecek%20hafta%20seni%20g%C3%B6rmeyi%20umuyoruz.)
^tr-Q0600-answer


### Answers 601–650

**tr-Q0601** — Tom çok ağzı sıkı değil.

Tom isn't very secretive.

Expected form: **değil**

Why: Negation and absence. [[Turkish#^tr-Q0601|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20%C3%A7ok%20a%C4%9Fz%C4%B1%20s%C4%B1k%C4%B1%20de%C4%9Fil.)
^tr-Q0601-answer

**tr-Q0602** — Tom çok ağzı sıkı değil.

Tom isn't very secretive.

Expected form: **değil**

Why: Negation and absence. [[Turkish#^tr-Q0602|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20%C3%A7ok%20a%C4%9Fz%C4%B1%20s%C4%B1k%C4%B1%20de%C4%9Fil.)
^tr-Q0602-answer

**tr-Q0603** — Tüm nedenimizi izlemek için yeterli gücümüz yok.

We do not have enough strength to follow our reason completely.

Expected form: **yok**

Why: Negation and absence. [[Turkish#^tr-Q0603|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=T%C3%BCm%20nedenimizi%20izlemek%20i%C3%A7in%20yeterli%20g%C3%BCc%C3%BCm%C3%BCz%20yok.)
^tr-Q0603-answer

**tr-Q0604** — Tüm nedenimizi izlemek için yeterli gücümüz yok.

We do not have enough strength to follow our reason completely.

Why: Negation and absence. [[Turkish#^tr-Q0604|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=T%C3%BCm%20nedenimizi%20izlemek%20i%C3%A7in%20yeterli%20g%C3%BCc%C3%BCm%C3%BCz%20yok.)
^tr-Q0604-answer

**tr-Q0605** — Tom iyi ama yeterince iyi değil.

Tom's good, but not good enough.

Why: Negation and absence. [[Turkish#^tr-Q0605|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20iyi%20ama%20yeterince%20iyi%20de%C4%9Fil.)
^tr-Q0605-answer

**tr-Q0606** — Tom iyi ama yeterince iyi değil.

Tom's good, but not good enough.

Değil negates many non-verbal predicates; yok expresses absence; hayır is a response no. Verbal negation usually belongs inside the verb. Hiç often works with a negative construction.

Why: Negation and absence. [[Turkish#^tr-Q0606|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20iyi%20ama%20yeterince%20iyi%20de%C4%9Fil.)
^tr-Q0606-answer

**tr-Q0607** — Yardıma ihtiyacınız yok mu?

Don't you need help?

Expected form: **yok**

Why: Negation and absence. [[Turkish#^tr-Q0607|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Yard%C4%B1ma%20ihtiyac%C4%B1n%C4%B1z%20yok%20mu%3F)
^tr-Q0607-answer

**tr-Q0608** — Yardıma ihtiyacınız yok mu?

Don't you need help?

Expected form: **yok**

Why: Negation and absence. [[Turkish#^tr-Q0608|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Yard%C4%B1ma%20ihtiyac%C4%B1n%C4%B1z%20yok%20mu%3F)
^tr-Q0608-answer

**tr-Q0609** — Neredeyse hiç et yemem.

I almost never eat meat.

Expected form: **hiç**

Why: Negation and absence. [[Turkish#^tr-Q0609|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Neredeyse%20hi%C3%A7%20et%20yemem.)
^tr-Q0609-answer

**tr-Q0610** — Neredeyse hiç et yemem.

I almost never eat meat.

Why: Negation and absence. [[Turkish#^tr-Q0610|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Neredeyse%20hi%C3%A7%20et%20yemem.)
^tr-Q0610-answer

**tr-Q0611** — Çok küçük olduğu için gömleği iade ettin, değil mi?

You returned the shirt because it was too small, isn't it?

Why: Negation and absence. [[Turkish#^tr-Q0611|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=%C3%87ok%20k%C3%BC%C3%A7%C3%BCk%20oldu%C4%9Fu%20i%C3%A7in%20g%C3%B6mle%C4%9Fi%20iade%20ettin%2C%20de%C4%9Fil%20mi%3F)
^tr-Q0611-answer

**tr-Q0612** — Çok küçük olduğu için gömleği iade ettin, değil mi?

You returned the shirt because it was too small, isn't it?

Değil negates many non-verbal predicates; yok expresses absence; hayır is a response no. Verbal negation usually belongs inside the verb. Hiç often works with a negative construction.

Why: Negation and absence. [[Turkish#^tr-Q0612|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=%C3%87ok%20k%C3%BC%C3%A7%C3%BCk%20oldu%C4%9Fu%20i%C3%A7in%20g%C3%B6mle%C4%9Fi%20iade%20ettin%2C%20de%C4%9Fil%20mi%3F)
^tr-Q0612-answer

**tr-Q0613** — Öyle yapmamak için hiç bir nedenim yok.

I have no reason not to do so.

Expected form: **hiç**

Why: Negation and absence. [[Turkish#^tr-Q0613|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=%C3%96yle%20yapmamak%20i%C3%A7in%20hi%C3%A7%20bir%20nedenim%20yok.)
^tr-Q0613-answer

**tr-Q0614** — Öyle yapmamak için hiç bir nedenim yok.

I have no reason not to do so.

Expected form: **hiç**

Why: Negation and absence. [[Turkish#^tr-Q0614|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=%C3%96yle%20yapmamak%20i%C3%A7in%20hi%C3%A7%20bir%20nedenim%20yok.)
^tr-Q0614-answer

**tr-Q0615** — Tom da bir öğretmen, değil mi?

Tom is a teacher, too, isn't he?

Expected form: **değil**

Why: Negation and absence. [[Turkish#^tr-Q0615|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20da%20bir%20%C3%B6%C4%9Fretmen%2C%20de%C4%9Fil%20mi%3F)
^tr-Q0615-answer

**tr-Q0616** — Tom da bir öğretmen, değil mi?

Tom is a teacher, too, isn't he?

Why: Negation and absence. [[Turkish#^tr-Q0616|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20da%20bir%20%C3%B6%C4%9Fretmen%2C%20de%C4%9Fil%20mi%3F)
^tr-Q0616-answer

**tr-Q0617** — Asla şeker kullanmayız.

We never use sugar.

Why: Negation and absence. [[Turkish#^tr-Q0617|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Asla%20%C5%9Feker%20kullanmay%C4%B1z.)
^tr-Q0617-answer

**tr-Q0618** — Asla şeker kullanmayız.

We never use sugar.

Değil negates many non-verbal predicates; yok expresses absence; hayır is a response no. Verbal negation usually belongs inside the verb. Hiç often works with a negative construction.

Why: Negation and absence. [[Turkish#^tr-Q0618|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Asla%20%C5%9Feker%20kullanmay%C4%B1z.)
^tr-Q0618-answer

**tr-Q0619** — Sen asla böyle bir şey yapmazsın.

You would never do such a thing.

Expected form: **asla**

Why: Negation and absence. [[Turkish#^tr-Q0619|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Sen%20asla%20b%C3%B6yle%20bir%20%C5%9Fey%20yapmazs%C4%B1n.)
^tr-Q0619-answer

**tr-Q0620** — Sen asla böyle bir şey yapmazsın.

You would never do such a thing.

Expected form: **asla**

Why: Negation and absence. [[Turkish#^tr-Q0620|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Sen%20asla%20b%C3%B6yle%20bir%20%C5%9Fey%20yapmazs%C4%B1n.)
^tr-Q0620-answer

**tr-Q0621** — O satılık değil.

It's not for sale.

Expected form: **değil**

Why: Negation and absence. [[Turkish#^tr-Q0621|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=O%20sat%C4%B1l%C4%B1k%20de%C4%9Fil.)
^tr-Q0621-answer

**tr-Q0622** — O satılık değil.

It's not for sale.

Why: Negation and absence. [[Turkish#^tr-Q0622|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=O%20sat%C4%B1l%C4%B1k%20de%C4%9Fil.)
^tr-Q0622-answer

**tr-Q0623** — Hiç erkek arkadaşım olmadı.

I've never had a boyfriend.

Why: Negation and absence. [[Turkish#^tr-Q0623|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Hi%C3%A7%20erkek%20arkada%C5%9F%C4%B1m%20olmad%C4%B1.)
^tr-Q0623-answer

**tr-Q0624** — Hiç erkek arkadaşım olmadı.

I've never had a boyfriend.

Değil negates many non-verbal predicates; yok expresses absence; hayır is a response no. Verbal negation usually belongs inside the verb. Hiç often works with a negative construction.

Why: Negation and absence. [[Turkish#^tr-Q0624|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Hi%C3%A7%20erkek%20arkada%C5%9F%C4%B1m%20olmad%C4%B1.)
^tr-Q0624-answer

**tr-Q0625** — Şimdiye kadar hiç bir ateş böceği gördün mü?

Have you ever even seen a firefly?

Expected form: **hiç**

Why: Negation and absence. [[Turkish#^tr-Q0625|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=%C5%9Eimdiye%20kadar%20hi%C3%A7%20bir%20ate%C5%9F%20b%C3%B6ce%C4%9Fi%20g%C3%B6rd%C3%BCn%20m%C3%BC%3F)
^tr-Q0625-answer

**tr-Q0626** — Şimdiye kadar hiç bir ateş böceği gördün mü?

Have you ever even seen a firefly?

Expected form: **hiç**

Why: Negation and absence. [[Turkish#^tr-Q0626|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=%C5%9Eimdiye%20kadar%20hi%C3%A7%20bir%20ate%C5%9F%20b%C3%B6ce%C4%9Fi%20g%C3%B6rd%C3%BCn%20m%C3%BC%3F)
^tr-Q0626-answer

**tr-Q0627** — Bu kitap sadece ilginç değil, aynı zamanda öğreticidir.

This book is not only interesting but also instructive.

Expected form: **değil**

Why: Negation and absence. [[Turkish#^tr-Q0627|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bu%20kitap%20sadece%20ilgin%C3%A7%20de%C4%9Fil%2C%20ayn%C4%B1%20zamanda%20%C3%B6%C4%9Freticidir.)
^tr-Q0627-answer

**tr-Q0628** — Bu kitap sadece ilginç değil, aynı zamanda öğreticidir.

This book is not only interesting but also instructive.

Why: Negation and absence. [[Turkish#^tr-Q0628|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bu%20kitap%20sadece%20ilgin%C3%A7%20de%C4%9Fil%2C%20ayn%C4%B1%20zamanda%20%C3%B6%C4%9Freticidir.)
^tr-Q0628-answer

**tr-Q0629** — Onlarla hiç herhangi bir sorun yaşamadık.

We haven't had any problems with them at all.

Why: Negation and absence. [[Turkish#^tr-Q0629|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Onlarla%20hi%C3%A7%20herhangi%20bir%20sorun%20ya%C5%9Famad%C4%B1k.)
^tr-Q0629-answer

**tr-Q0630** — Onlarla hiç herhangi bir sorun yaşamadık.

We haven't had any problems with them at all.

Değil negates many non-verbal predicates; yok expresses absence; hayır is a response no. Verbal negation usually belongs inside the verb. Hiç often works with a negative construction.

Why: Negation and absence. [[Turkish#^tr-Q0630|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Onlarla%20hi%C3%A7%20herhangi%20bir%20sorun%20ya%C5%9Famad%C4%B1k.)
^tr-Q0630-answer

**tr-Q0631** — Bir forklifti nasıl çalıştıracağını bilmiyorsun, değil mi?

You don't know how to operate a forklift, do you?

Expected form: **değil**

Why: Negation and absence. [[Turkish#^tr-Q0631|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bir%20forklifti%20nas%C4%B1l%20%C3%A7al%C4%B1%C5%9Ft%C4%B1raca%C4%9F%C4%B1n%C4%B1%20bilmiyorsun%2C%20de%C4%9Fil%20mi%3F)
^tr-Q0631-answer

**tr-Q0632** — Bir forklifti nasıl çalıştıracağını bilmiyorsun, değil mi?

You don't know how to operate a forklift, do you?

Expected form: **değil**

Why: Negation and absence. [[Turkish#^tr-Q0632|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bir%20forklifti%20nas%C4%B1l%20%C3%A7al%C4%B1%C5%9Ft%C4%B1raca%C4%9F%C4%B1n%C4%B1%20bilmiyorsun%2C%20de%C4%9Fil%20mi%3F)
^tr-Q0632-answer

**tr-Q0633** — Onlardan hiç biri konuşmadı.

None of them spoke.

Expected form: **hiç**

Why: Negation and absence. [[Turkish#^tr-Q0633|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Onlardan%20hi%C3%A7%20biri%20konu%C5%9Fmad%C4%B1.)
^tr-Q0633-answer

**tr-Q0634** — Onlardan hiç biri konuşmadı.

None of them spoke.

Why: Negation and absence. [[Turkish#^tr-Q0634|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Onlardan%20hi%C3%A7%20biri%20konu%C5%9Fmad%C4%B1.)
^tr-Q0634-answer

**tr-Q0635** — Hiç kimse şikayet etmiyor.

No one complains.

Why: Negation and absence. [[Turkish#^tr-Q0635|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Hi%C3%A7%20kimse%20%C5%9Fikayet%20etmiyor.)
^tr-Q0635-answer

**tr-Q0636** — Hiç kimse şikayet etmiyor.

No one complains.

Değil negates many non-verbal predicates; yok expresses absence; hayır is a response no. Verbal negation usually belongs inside the verb. Hiç often works with a negative construction.

Why: Negation and absence. [[Turkish#^tr-Q0636|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Hi%C3%A7%20kimse%20%C5%9Fikayet%20etmiyor.)
^tr-Q0636-answer

**tr-Q0637** — Ondan yardım istemenin hiçbir faydası yok.

There is no use in asking him for assistance.

Expected form: **yok**

Why: Negation and absence. [[Turkish#^tr-Q0637|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ondan%20yard%C4%B1m%20istemenin%20hi%C3%A7bir%20faydas%C4%B1%20yok.)
^tr-Q0637-answer

**tr-Q0638** — Ondan yardım istemenin hiçbir faydası yok.

There is no use in asking him for assistance.

Expected form: **yok**

Why: Negation and absence. [[Turkish#^tr-Q0638|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ondan%20yard%C4%B1m%20istemenin%20hi%C3%A7bir%20faydas%C4%B1%20yok.)
^tr-Q0638-answer

**tr-Q0639** — Artık daha fazla zamanın yok.

You don't have any more time.

Expected form: **yok**

Why: Negation and absence. [[Turkish#^tr-Q0639|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Art%C4%B1k%20daha%20fazla%20zaman%C4%B1n%20yok.)
^tr-Q0639-answer

**tr-Q0640** — Artık daha fazla zamanın yok.

You don't have any more time.

Why: Negation and absence. [[Turkish#^tr-Q0640|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Art%C4%B1k%20daha%20fazla%20zaman%C4%B1n%20yok.)
^tr-Q0640-answer

**tr-Q0641** — Tom inatçı, değil mi?

Tom is stubborn, isn't he?

Why: Negation and absence. [[Turkish#^tr-Q0641|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20inat%C3%A7%C4%B1%2C%20de%C4%9Fil%20mi%3F)
^tr-Q0641-answer

**tr-Q0642** — Tom inatçı, değil mi?

Tom is stubborn, isn't he?

Değil negates many non-verbal predicates; yok expresses absence; hayır is a response no. Verbal negation usually belongs inside the verb. Hiç often works with a negative construction.

Why: Negation and absence. [[Turkish#^tr-Q0642|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20inat%C3%A7%C4%B1%2C%20de%C4%9Fil%20mi%3F)
^tr-Q0642-answer

**tr-Q0643** — Onu satın aldın, değil mi?

You bought it, didn't you?

Expected form: **değil**

Why: Negation and absence. [[Turkish#^tr-Q0643|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Onu%20sat%C4%B1n%20ald%C4%B1n%2C%20de%C4%9Fil%20mi%3F)
^tr-Q0643-answer

**tr-Q0644** — Onu satın aldın, değil mi?

You bought it, didn't you?

Expected form: **değil**

Why: Negation and absence. [[Turkish#^tr-Q0644|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Onu%20sat%C4%B1n%20ald%C4%B1n%2C%20de%C4%9Fil%20mi%3F)
^tr-Q0644-answer

**tr-Q0645** — Tom Fransızcada Mary kadar iyi değil.

Tom isn't as good at French as Mary is.

Expected form: **değil**

Why: Negation and absence. [[Turkish#^tr-Q0645|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20Frans%C4%B1zcada%20Mary%20kadar%20iyi%20de%C4%9Fil.)
^tr-Q0645-answer

**tr-Q0646** — Tom Fransızcada Mary kadar iyi değil.

Tom isn't as good at French as Mary is.

Why: Negation and absence. [[Turkish#^tr-Q0646|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20Frans%C4%B1zcada%20Mary%20kadar%20iyi%20de%C4%9Fil.)
^tr-Q0646-answer

**tr-Q0647** — Çocuğu ikna etmeye çalışmanın faydası yok.

It's no use trying to persuade the boy.

Why: Negation and absence. [[Turkish#^tr-Q0647|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=%C3%87ocu%C4%9Fu%20ikna%20etmeye%20%C3%A7al%C4%B1%C5%9Fman%C4%B1n%20faydas%C4%B1%20yok.)
^tr-Q0647-answer

**tr-Q0648** — Çocuğu ikna etmeye çalışmanın faydası yok.

It's no use trying to persuade the boy.

Değil negates many non-verbal predicates; yok expresses absence; hayır is a response no. Verbal negation usually belongs inside the verb. Hiç often works with a negative construction.

Why: Negation and absence. [[Turkish#^tr-Q0648|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=%C3%87ocu%C4%9Fu%20ikna%20etmeye%20%C3%A7al%C4%B1%C5%9Fman%C4%B1n%20faydas%C4%B1%20yok.)
^tr-Q0648-answer

**tr-Q0649** — Tom'un bunu yapmasına izin vermek kötü bir fikir değil.

It's not a bad idea to let Tom do that.

Expected form: **değil**

Why: Negation and absence. [[Turkish#^tr-Q0649|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%27un%20bunu%20yapmas%C4%B1na%20izin%20vermek%20k%C3%B6t%C3%BC%20bir%20fikir%20de%C4%9Fil.)
^tr-Q0649-answer

**tr-Q0650** — Tom'un bunu yapmasına izin vermek kötü bir fikir değil.

It's not a bad idea to let Tom do that.

Expected form: **değil**

Why: Negation and absence. [[Turkish#^tr-Q0650|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%27un%20bunu%20yapmas%C4%B1na%20izin%20vermek%20k%C3%B6t%C3%BC%20bir%20fikir%20de%C4%9Fil.)
^tr-Q0650-answer


### Answers 651–700

**tr-Q0651** — Kabak çorbasını sever misin?

Do you like squash soup?

Expected form: **misin**

Why: Question particle. [[Turkish#^tr-Q0651|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Kabak%20%C3%A7orbas%C4%B1n%C4%B1%20sever%20misin%3F)
^tr-Q0651-answer

**tr-Q0652** — Kabak çorbasını sever misin?

Do you like squash soup?

Why: Question particle. [[Turkish#^tr-Q0652|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Kabak%20%C3%A7orbas%C4%B1n%C4%B1%20sever%20misin%3F)
^tr-Q0652-answer

**tr-Q0653** — Hala ikna olmadınız mı?

Are you still not convinced?

Why: Question particle. [[Turkish#^tr-Q0653|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Hala%20ikna%20olmad%C4%B1n%C4%B1z%20m%C4%B1%3F)
^tr-Q0653-answer

**tr-Q0654** — Hala ikna olmadınız mı?

Are you still not convinced?

The question particle is written separately and follows harmony. It attaches in position to the focused element; personal endings can follow it. A question word does not normally need an extra question particle.

Why: Question particle. [[Turkish#^tr-Q0654|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Hala%20ikna%20olmad%C4%B1n%C4%B1z%20m%C4%B1%3F)
^tr-Q0654-answer

**tr-Q0655** — Haberi gördünüz mü?

Have you guys seen the news?

Expected form: **mü**

Why: Question particle. [[Turkish#^tr-Q0655|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Haberi%20g%C3%B6rd%C3%BCn%C3%BCz%20m%C3%BC%3F)
^tr-Q0655-answer

**tr-Q0656** — Haberi gördünüz mü?

Have you guys seen the news?

Expected form: **mü**

Why: Question particle. [[Turkish#^tr-Q0656|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Haberi%20g%C3%B6rd%C3%BCn%C3%BCz%20m%C3%BC%3F)
^tr-Q0656-answer

**tr-Q0657** — Sabah bir uçuş var mı?

Is there a flight in the morning?

Expected form: **mı**

Why: Question particle. [[Turkish#^tr-Q0657|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Sabah%20bir%20u%C3%A7u%C5%9F%20var%20m%C4%B1%3F)
^tr-Q0657-answer

**tr-Q0658** — Sabah bir uçuş var mı?

Is there a flight in the morning?

Why: Question particle. [[Turkish#^tr-Q0658|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Sabah%20bir%20u%C3%A7u%C5%9F%20var%20m%C4%B1%3F)
^tr-Q0658-answer

**tr-Q0659** — Lütfen bir süreliğine burada kalır mısın?

Will you stay here for a while?

Why: Question particle. [[Turkish#^tr-Q0659|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=L%C3%BCtfen%20bir%20s%C3%BCreli%C4%9Fine%20burada%20kal%C4%B1r%20m%C4%B1s%C4%B1n%3F)
^tr-Q0659-answer

**tr-Q0660** — Lütfen bir süreliğine burada kalır mısın?

Will you stay here for a while?

The question particle is written separately and follows harmony. It attaches in position to the focused element; personal endings can follow it. A question word does not normally need an extra question particle.

Why: Question particle. [[Turkish#^tr-Q0660|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=L%C3%BCtfen%20bir%20s%C3%BCreli%C4%9Fine%20burada%20kal%C4%B1r%20m%C4%B1s%C4%B1n%3F)
^tr-Q0660-answer

**tr-Q0661** — Bu yaygın bir isim mi?

Is that a common name?

Expected form: **mi**

Why: Question particle. [[Turkish#^tr-Q0661|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bu%20yayg%C4%B1n%20bir%20isim%20mi%3F)
^tr-Q0661-answer

**tr-Q0662** — Bu yaygın bir isim mi?

Is that a common name?

Expected form: **mi**

Why: Question particle. [[Turkish#^tr-Q0662|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bu%20yayg%C4%B1n%20bir%20isim%20mi%3F)
^tr-Q0662-answer

**tr-Q0663** — Anne ve baban hala Almanya'da yaşıyor mu?

Do your parents still live in Germany?

Expected form: **mu**

Why: Question particle. [[Turkish#^tr-Q0663|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Anne%20ve%20baban%20hala%20Almanya%27da%20ya%C5%9F%C4%B1yor%20mu%3F)
^tr-Q0663-answer

**tr-Q0664** — Anne ve baban hala Almanya'da yaşıyor mu?

Do your parents still live in Germany?

Why: Question particle. [[Turkish#^tr-Q0664|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Anne%20ve%20baban%20hala%20Almanya%27da%20ya%C5%9F%C4%B1yor%20mu%3F)
^tr-Q0664-answer

**tr-Q0665** — Sonsuza kadar yaşamak istemiyor musun?

Don't you want to live forever?

Why: Question particle. [[Turkish#^tr-Q0665|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Sonsuza%20kadar%20ya%C5%9Famak%20istemiyor%20musun%3F)
^tr-Q0665-answer

**tr-Q0666** — Sonsuza kadar yaşamak istemiyor musun?

Don't you want to live forever?

The question particle is written separately and follows harmony. It attaches in position to the focused element; personal endings can follow it. A question word does not normally need an extra question particle.

Why: Question particle. [[Turkish#^tr-Q0666|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Sonsuza%20kadar%20ya%C5%9Famak%20istemiyor%20musun%3F)
^tr-Q0666-answer

**tr-Q0667** — Hep o kadar meşgul müsün?

Are you always that busy?

Expected form: **müsün**

Why: Question particle. [[Turkish#^tr-Q0667|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Hep%20o%20kadar%20me%C5%9Fgul%20m%C3%BCs%C3%BCn%3F)
^tr-Q0667-answer

**tr-Q0668** — Hep o kadar meşgul müsün?

Are you always that busy?

Expected form: **müsün**

Why: Question particle. [[Turkish#^tr-Q0668|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Hep%20o%20kadar%20me%C5%9Fgul%20m%C3%BCs%C3%BCn%3F)
^tr-Q0668-answer

**tr-Q0669** — Tom sinirlendi mi?

Did Tom get angry?

Expected form: **mi**

Why: Question particle. [[Turkish#^tr-Q0669|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20sinirlendi%20mi%3F)
^tr-Q0669-answer

**tr-Q0670** — Tom sinirlendi mi?

Did Tom get angry?

Why: Question particle. [[Turkish#^tr-Q0670|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20sinirlendi%20mi%3F)
^tr-Q0670-answer

**tr-Q0671** — Bir saniyeniz var mı?

Do you have a sec?

Why: Question particle. [[Turkish#^tr-Q0671|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bir%20saniyeniz%20var%20m%C4%B1%3F)
^tr-Q0671-answer

**tr-Q0672** — Bir saniyeniz var mı?

Do you have a sec?

The question particle is written separately and follows harmony. It attaches in position to the focused element; personal endings can follow it. A question word does not normally need an extra question particle.

Why: Question particle. [[Turkish#^tr-Q0672|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bir%20saniyeniz%20var%20m%C4%B1%3F)
^tr-Q0672-answer

**tr-Q0673** — Sadece bana güvenmen gerek, tamam mı?

I just need you to trust me, OK?

Expected form: **mı**

Why: Question particle. [[Turkish#^tr-Q0673|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Sadece%20bana%20g%C3%BCvenmen%20gerek%2C%20tamam%20m%C4%B1%3F)
^tr-Q0673-answer

**tr-Q0674** — Sadece bana güvenmen gerek, tamam mı?

I just need you to trust me, OK?

Expected form: **mı**

Why: Question particle. [[Turkish#^tr-Q0674|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Sadece%20bana%20g%C3%BCvenmen%20gerek%2C%20tamam%20m%C4%B1%3F)
^tr-Q0674-answer

**tr-Q0675** — İhtiyacımız olan bilginin herhangi birini alabildin mi?

Were you able to get any of the information we needed?

Expected form: **mi**

Why: Question particle. [[Turkish#^tr-Q0675|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=%C4%B0htiyac%C4%B1m%C4%B1z%20olan%20bilginin%20herhangi%20birini%20alabildin%20mi%3F)
^tr-Q0675-answer

**tr-Q0676** — İhtiyacımız olan bilginin herhangi birini alabildin mi?

Were you able to get any of the information we needed?

Why: Question particle. [[Turkish#^tr-Q0676|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=%C4%B0htiyac%C4%B1m%C4%B1z%20olan%20bilginin%20herhangi%20birini%20alabildin%20mi%3F)
^tr-Q0676-answer

**tr-Q0677** — Kız arkadaşın çiçekleri sever mi?

Does your girlfriend like flowers?

Why: Question particle. [[Turkish#^tr-Q0677|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=K%C4%B1z%20arkada%C5%9F%C4%B1n%20%C3%A7i%C3%A7ekleri%20sever%20mi%3F)
^tr-Q0677-answer

**tr-Q0678** — Kız arkadaşın çiçekleri sever mi?

Does your girlfriend like flowers?

The question particle is written separately and follows harmony. It attaches in position to the focused element; personal endings can follow it. A question word does not normally need an extra question particle.

Why: Question particle. [[Turkish#^tr-Q0678|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=K%C4%B1z%20arkada%C5%9F%C4%B1n%20%C3%A7i%C3%A7ekleri%20sever%20mi%3F)
^tr-Q0678-answer

**tr-Q0679** — Gerçekten Boston'a geri dönmek istiyor musun?

Do you really want to go back to Boston?

Expected form: **musun**

Why: Question particle. [[Turkish#^tr-Q0679|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ger%C3%A7ekten%20Boston%27a%20geri%20d%C3%B6nmek%20istiyor%20musun%3F)
^tr-Q0679-answer

**tr-Q0680** — Gerçekten Boston'a geri dönmek istiyor musun?

Do you really want to go back to Boston?

Expected form: **musun**

Why: Question particle. [[Turkish#^tr-Q0680|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ger%C3%A7ekten%20Boston%27a%20geri%20d%C3%B6nmek%20istiyor%20musun%3F)
^tr-Q0680-answer

**tr-Q0681** — Bu sorunu halledebilir misin?

Can you do this problem?

Expected form: **misin**

Why: Question particle. [[Turkish#^tr-Q0681|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bu%20sorunu%20halledebilir%20misin%3F)
^tr-Q0681-answer

**tr-Q0682** — Bu sorunu halledebilir misin?

Can you do this problem?

Why: Question particle. [[Turkish#^tr-Q0682|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bu%20sorunu%20halledebilir%20misin%3F)
^tr-Q0682-answer

**tr-Q0683** — Tom hayal kuruyor mu?

Is Tom dreaming?

Why: Question particle. [[Turkish#^tr-Q0683|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20hayal%20kuruyor%20mu%3F)
^tr-Q0683-answer

**tr-Q0684** — Tom hayal kuruyor mu?

Is Tom dreaming?

The question particle is written separately and follows harmony. It attaches in position to the focused element; personal endings can follow it. A question word does not normally need an extra question particle.

Why: Question particle. [[Turkish#^tr-Q0684|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20hayal%20kuruyor%20mu%3F)
^tr-Q0684-answer

**tr-Q0685** — Tom ne yaptığının farkında mı?

Is Tom aware of what he did?

Expected form: **mı**

Why: Question particle. [[Turkish#^tr-Q0685|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20ne%20yapt%C4%B1%C4%9F%C4%B1n%C4%B1n%20fark%C4%B1nda%20m%C4%B1%3F)
^tr-Q0685-answer

**tr-Q0686** — Tom ne yaptığının farkında mı?

Is Tom aware of what he did?

Expected form: **mı**

Why: Question particle. [[Turkish#^tr-Q0686|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20ne%20yapt%C4%B1%C4%9F%C4%B1n%C4%B1n%20fark%C4%B1nda%20m%C4%B1%3F)
^tr-Q0686-answer

**tr-Q0687** — Bana telefon ettin mi?

Did you phone me?

Expected form: **mi**

Why: Question particle. [[Turkish#^tr-Q0687|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bana%20telefon%20ettin%20mi%3F)
^tr-Q0687-answer

**tr-Q0688** — Bana telefon ettin mi?

Did you phone me?

Why: Question particle. [[Turkish#^tr-Q0688|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bana%20telefon%20ettin%20mi%3F)
^tr-Q0688-answer

**tr-Q0689** — Ne yapacaksın? Annene söyledin mi?

What are you going to do? Tell your mom?

Why: Question particle. [[Turkish#^tr-Q0689|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ne%20yapacaks%C4%B1n%3F%20Annene%20s%C3%B6yledin%20mi%3F)
^tr-Q0689-answer

**tr-Q0690** — Ne yapacaksın? Annene söyledin mi?

What are you going to do? Tell your mom?

The question particle is written separately and follows harmony. It attaches in position to the focused element; personal endings can follow it. A question word does not normally need an extra question particle.

Why: Question particle. [[Turkish#^tr-Q0690|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ne%20yapacaks%C4%B1n%3F%20Annene%20s%C3%B6yledin%20mi%3F)
^tr-Q0690-answer

**tr-Q0691** — Tom'un Mary'ye ne verdiğini sen bile bilmek istemiyor musun?

Don't you even want to know what Tom gave Mary?

Expected form: **musun**

Why: Question particle. [[Turkish#^tr-Q0691|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%27un%20Mary%27ye%20ne%20verdi%C4%9Fini%20sen%20bile%20bilmek%20istemiyor%20musun%3F)
^tr-Q0691-answer

**tr-Q0692** — Tom'un Mary'ye ne verdiğini sen bile bilmek istemiyor musun?

Don't you even want to know what Tom gave Mary?

Expected form: **musun**

Why: Question particle. [[Turkish#^tr-Q0692|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%27un%20Mary%27ye%20ne%20verdi%C4%9Fini%20sen%20bile%20bilmek%20istemiyor%20musun%3F)
^tr-Q0692-answer

**tr-Q0693** — Sen olağanüstü notlar aldın, değil mi?

You got extraordinary grades, didn't you?

Expected form: **mi**

Why: Question particle. [[Turkish#^tr-Q0693|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Sen%20ola%C4%9Fan%C3%BCst%C3%BC%20notlar%20ald%C4%B1n%2C%20de%C4%9Fil%20mi%3F)
^tr-Q0693-answer

**tr-Q0694** — Sen olağanüstü notlar aldın, değil mi?

You got extraordinary grades, didn't you?

Why: Question particle. [[Turkish#^tr-Q0694|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Sen%20ola%C4%9Fan%C3%BCst%C3%BC%20notlar%20ald%C4%B1n%2C%20de%C4%9Fil%20mi%3F)
^tr-Q0694-answer

**tr-Q0695** — Hiç planın var mı?

Have you got any plans?

Why: Question particle. [[Turkish#^tr-Q0695|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Hi%C3%A7%20plan%C4%B1n%20var%20m%C4%B1%3F)
^tr-Q0695-answer

**tr-Q0696** — Hiç planın var mı?

Have you got any plans?

The question particle is written separately and follows harmony. It attaches in position to the focused element; personal endings can follow it. A question word does not normally need an extra question particle.

Why: Question particle. [[Turkish#^tr-Q0696|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Hi%C3%A7%20plan%C4%B1n%20var%20m%C4%B1%3F)
^tr-Q0696-answer

**tr-Q0697** — Kim olduğumu bilmiyor musun?

Don't you know who I am?

Expected form: **musun**

Why: Question particle. [[Turkish#^tr-Q0697|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Kim%20oldu%C4%9Fumu%20bilmiyor%20musun%3F)
^tr-Q0697-answer

**tr-Q0698** — Kim olduğumu bilmiyor musun?

Don't you know who I am?

Expected form: **musun**

Why: Question particle. [[Turkish#^tr-Q0698|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Kim%20oldu%C4%9Fumu%20bilmiyor%20musun%3F)
^tr-Q0698-answer

**tr-Q0699** — Bu civarda bir market var mı?

Is there a convenience store near here?

Expected form: **mı**

Why: Question particle. [[Turkish#^tr-Q0699|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bu%20civarda%20bir%20market%20var%20m%C4%B1%3F)
^tr-Q0699-answer

**tr-Q0700** — Bu civarda bir market var mı?

Is there a convenience store near here?

Why: Question particle. [[Turkish#^tr-Q0700|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bu%20civarda%20bir%20market%20var%20m%C4%B1%3F)
^tr-Q0700-answer


### Answers 701–750

**tr-Q0701** — Oo! Ne büyük bir kutu!

Wow! What a big box!

Why: Question words. [[Turkish#^tr-Q0701|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Oo%21%20Ne%20b%C3%BCy%C3%BCk%20bir%20kutu%21)
^tr-Q0701-answer

**tr-Q0702** — Oo! Ne büyük bir kutu!

Wow! What a big box!

Location, destination and source have different question forms. Question words take relevant case morphology. Context and focus govern their placement.

Why: Question words. [[Turkish#^tr-Q0702|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Oo%21%20Ne%20b%C3%BCy%C3%BCk%20bir%20kutu%21)
^tr-Q0702-answer

**tr-Q0703** — Ne zaman Boston'a gitsek Tom'la kalırız.

We stay with Tom whenever we go to Boston.

Expected form: **Ne**

Why: Question words. [[Turkish#^tr-Q0703|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ne%20zaman%20Boston%27a%20gitsek%20Tom%27la%20kal%C4%B1r%C4%B1z.)
^tr-Q0703-answer

**tr-Q0704** — Ne zaman Boston'a gitsek Tom'la kalırız.

We stay with Tom whenever we go to Boston.

Expected form: **Ne**

Why: Question words. [[Turkish#^tr-Q0704|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ne%20zaman%20Boston%27a%20gitsek%20Tom%27la%20kal%C4%B1r%C4%B1z.)
^tr-Q0704-answer

**tr-Q0705** — Ne zaman geri gideceğiz?

When will we go back?

Expected form: **Ne**

Why: Question words. [[Turkish#^tr-Q0705|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ne%20zaman%20geri%20gidece%C4%9Fiz%3F)
^tr-Q0705-answer

**tr-Q0706** — Ne zaman geri gideceğiz?

When will we go back?

Why: Question words. [[Turkish#^tr-Q0706|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ne%20zaman%20geri%20gidece%C4%9Fiz%3F)
^tr-Q0706-answer

**tr-Q0707** — Kaç kişi Everest dağına tırmandı?

How many people climbed Mount Everest?

Why: Question words. [[Turkish#^tr-Q0707|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ka%C3%A7%20ki%C5%9Fi%20Everest%20da%C4%9F%C4%B1na%20t%C4%B1rmand%C4%B1%3F)
^tr-Q0707-answer

**tr-Q0708** — Kaç kişi Everest dağına tırmandı?

How many people climbed Mount Everest?

Location, destination and source have different question forms. Question words take relevant case morphology. Context and focus govern their placement.

Why: Question words. [[Turkish#^tr-Q0708|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ka%C3%A7%20ki%C5%9Fi%20Everest%20da%C4%9F%C4%B1na%20t%C4%B1rmand%C4%B1%3F)
^tr-Q0708-answer

**tr-Q0709** — Tom neden Mary'yi bu kadar çok seviyor?

Why does Tom like Mary so much?

Expected form: **neden**

Why: Question words. [[Turkish#^tr-Q0709|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20neden%20Mary%27yi%20bu%20kadar%20%C3%A7ok%20seviyor%3F)
^tr-Q0709-answer

**tr-Q0710** — Tom neden Mary'yi bu kadar çok seviyor?

Why does Tom like Mary so much?

Expected form: **neden**

Why: Question words. [[Turkish#^tr-Q0710|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20neden%20Mary%27yi%20bu%20kadar%20%C3%A7ok%20seviyor%3F)
^tr-Q0710-answer

**tr-Q0711** — Eğer öyleyse, o zaman ne yaparız?

If so, then what do we do?

Expected form: **ne**

Why: Question words. [[Turkish#^tr-Q0711|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=E%C4%9Fer%20%C3%B6yleyse%2C%20o%20zaman%20ne%20yapar%C4%B1z%3F)
^tr-Q0711-answer

**tr-Q0712** — Eğer öyleyse, o zaman ne yaparız?

If so, then what do we do?

Why: Question words. [[Turkish#^tr-Q0712|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=E%C4%9Fer%20%C3%B6yleyse%2C%20o%20zaman%20ne%20yapar%C4%B1z%3F)
^tr-Q0712-answer

**tr-Q0713** — Kaç yaşındasın ve adın ne?

How old are you and what's your name?

Why: Question words. [[Turkish#^tr-Q0713|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ka%C3%A7%20ya%C5%9F%C4%B1ndas%C4%B1n%20ve%20ad%C4%B1n%20ne%3F)
^tr-Q0713-answer

**tr-Q0714** — Kaç yaşındasın ve adın ne?

How old are you and what's your name?

Location, destination and source have different question forms. Question words take relevant case morphology. Context and focus govern their placement.

Why: Question words. [[Turkish#^tr-Q0714|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ka%C3%A7%20ya%C5%9F%C4%B1ndas%C4%B1n%20ve%20ad%C4%B1n%20ne%3F)
^tr-Q0714-answer

**tr-Q0715** — Tom'un ne düşündüğüyle neden bu kadar ilgileniyorsun.

Why are you so interested in what Tom thinks?

Expected form: **ne**

Why: Question words. [[Turkish#^tr-Q0715|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%27un%20ne%20d%C3%BC%C5%9F%C3%BCnd%C3%BC%C4%9F%C3%BCyle%20neden%20bu%20kadar%20ilgileniyorsun.)
^tr-Q0715-answer

**tr-Q0716** — Tom'un ne düşündüğüyle neden bu kadar ilgileniyorsun.

Why are you so interested in what Tom thinks?

Expected form: **ne**

Why: Question words. [[Turkish#^tr-Q0716|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%27un%20ne%20d%C3%BC%C5%9F%C3%BCnd%C3%BC%C4%9F%C3%BCyle%20neden%20bu%20kadar%20ilgileniyorsun.)
^tr-Q0716-answer

**tr-Q0717** — Buradan Boston'a gitmek ne kadar sürer?

How long does it take to get to Boston from here?

Expected form: **ne**

Why: Question words. [[Turkish#^tr-Q0717|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Buradan%20Boston%27a%20gitmek%20ne%20kadar%20s%C3%BCrer%3F)
^tr-Q0717-answer

**tr-Q0718** — Buradan Boston'a gitmek ne kadar sürer?

How long does it take to get to Boston from here?

Why: Question words. [[Turkish#^tr-Q0718|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Buradan%20Boston%27a%20gitmek%20ne%20kadar%20s%C3%BCrer%3F)
^tr-Q0718-answer

**tr-Q0719** — O şu anda ne yapıyor?

What is he currently doing?

Why: Question words. [[Turkish#^tr-Q0719|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=O%20%C5%9Fu%20anda%20ne%20yap%C4%B1yor%3F)
^tr-Q0719-answer

**tr-Q0720** — O şu anda ne yapıyor?

What is he currently doing?

Location, destination and source have different question forms. Question words take relevant case morphology. Context and focus govern their placement.

Why: Question words. [[Turkish#^tr-Q0720|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=O%20%C5%9Fu%20anda%20ne%20yap%C4%B1yor%3F)
^tr-Q0720-answer

**tr-Q0721** — Tom ve ben kendimizi nasıl koruyacağız?

How will Tom and I protect ourselves?

Expected form: **nasıl**

Why: Question words. [[Turkish#^tr-Q0721|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20ve%20ben%20kendimizi%20nas%C4%B1l%20koruyaca%C4%9F%C4%B1z%3F)
^tr-Q0721-answer

**tr-Q0722** — Tom ve ben kendimizi nasıl koruyacağız?

How will Tom and I protect ourselves?

Expected form: **nasıl**

Why: Question words. [[Turkish#^tr-Q0722|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20ve%20ben%20kendimizi%20nas%C4%B1l%20koruyaca%C4%9F%C4%B1z%3F)
^tr-Q0722-answer

**tr-Q0723** — Para biriktirmek neden önemlidir?

Why is it important to save money?

Expected form: **neden**

Why: Question words. [[Turkish#^tr-Q0723|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Para%20biriktirmek%20neden%20%C3%B6nemlidir%3F)
^tr-Q0723-answer

**tr-Q0724** — Para biriktirmek neden önemlidir?

Why is it important to save money?

Why: Question words. [[Turkish#^tr-Q0724|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Para%20biriktirmek%20neden%20%C3%B6nemlidir%3F)
^tr-Q0724-answer

**tr-Q0725** — New York'u ne zaman ziyaret ettin?

When did you visit New York?

Why: Question words. [[Turkish#^tr-Q0725|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=New%20York%27u%20ne%20zaman%20ziyaret%20ettin%3F)
^tr-Q0725-answer

**tr-Q0726** — New York'u ne zaman ziyaret ettin?

When did you visit New York?

Location, destination and source have different question forms. Question words take relevant case morphology. Context and focus govern their placement.

Why: Question words. [[Turkish#^tr-Q0726|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=New%20York%27u%20ne%20zaman%20ziyaret%20ettin%3F)
^tr-Q0726-answer

**tr-Q0727** — Ne yapmamı istediğini anlamıyorum.

I don't understand what he wants me to do.

Expected form: **Ne**

Why: Question words. [[Turkish#^tr-Q0727|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ne%20yapmam%C4%B1%20istedi%C4%9Fini%20anlam%C4%B1yorum.)
^tr-Q0727-answer

**tr-Q0728** — Ne yapmamı istediğini anlamıyorum.

I don't understand what he wants me to do.

Expected form: **Ne**

Why: Question words. [[Turkish#^tr-Q0728|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ne%20yapmam%C4%B1%20istedi%C4%9Fini%20anlam%C4%B1yorum.)
^tr-Q0728-answer

**tr-Q0729** — Yaşamak için bir haftan daha olsaydı, zamanını ne yaparak geçirirdin?

If you only had one more week to live, what would you spend your time doing?

Expected form: **ne**

Why: Question words. [[Turkish#^tr-Q0729|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ya%C5%9Famak%20i%C3%A7in%20bir%20haftan%20daha%20olsayd%C4%B1%2C%20zaman%C4%B1n%C4%B1%20ne%20yaparak%20ge%C3%A7irirdin%3F)
^tr-Q0729-answer

**tr-Q0730** — Yaşamak için bir haftan daha olsaydı, zamanını ne yaparak geçirirdin?

If you only had one more week to live, what would you spend your time doing?

Why: Question words. [[Turkish#^tr-Q0730|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ya%C5%9Famak%20i%C3%A7in%20bir%20haftan%20daha%20olsayd%C4%B1%2C%20zaman%C4%B1n%C4%B1%20ne%20yaparak%20ge%C3%A7irirdin%3F)
^tr-Q0730-answer

**tr-Q0731** — Tom partinin ne kadar süreceğini bilmiyor.

Tom doesn't know how long the party is going to last.

Why: Question words. [[Turkish#^tr-Q0731|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20partinin%20ne%20kadar%20s%C3%BCrece%C4%9Fini%20bilmiyor.)
^tr-Q0731-answer

**tr-Q0732** — Tom partinin ne kadar süreceğini bilmiyor.

Tom doesn't know how long the party is going to last.

Location, destination and source have different question forms. Question words take relevant case morphology. Context and focus govern their placement.

Why: Question words. [[Turkish#^tr-Q0732|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20partinin%20ne%20kadar%20s%C3%BCrece%C4%9Fini%20bilmiyor.)
^tr-Q0732-answer

**tr-Q0733** — Ne kadar zamandır orada kaldınız?

How long did you stay there?

Expected form: **Ne**

Why: Question words. [[Turkish#^tr-Q0733|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ne%20kadar%20zamand%C4%B1r%20orada%20kald%C4%B1n%C4%B1z%3F)
^tr-Q0733-answer

**tr-Q0734** — Ne kadar zamandır orada kaldınız?

How long did you stay there?

Expected form: **Ne**

Why: Question words. [[Turkish#^tr-Q0734|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ne%20kadar%20zamand%C4%B1r%20orada%20kald%C4%B1n%C4%B1z%3F)
^tr-Q0734-answer

**tr-Q0735** — Tom neden bitirmedi?

Why didn't Tom finish?

Expected form: **neden**

Why: Question words. [[Turkish#^tr-Q0735|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20neden%20bitirmedi%3F)
^tr-Q0735-answer

**tr-Q0736** — Tom neden bitirmedi?

Why didn't Tom finish?

Why: Question words. [[Turkish#^tr-Q0736|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20neden%20bitirmedi%3F)
^tr-Q0736-answer

**tr-Q0737** — Ah, bunu nasıl söyleyebilirsin?

Aw, how can you say that?

Why: Question words. [[Turkish#^tr-Q0737|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ah%2C%20bunu%20nas%C4%B1l%20s%C3%B6yleyebilirsin%3F)
^tr-Q0737-answer

**tr-Q0738** — Ah, bunu nasıl söyleyebilirsin?

Aw, how can you say that?

Location, destination and source have different question forms. Question words take relevant case morphology. Context and focus govern their placement.

Why: Question words. [[Turkish#^tr-Q0738|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ah%2C%20bunu%20nas%C4%B1l%20s%C3%B6yleyebilirsin%3F)
^tr-Q0738-answer

**tr-Q0739** — İyi bir nasihat almak için nereye gidebilirim?

Where can I go to get some good advice?

Expected form: **nereye**

Why: Question words. [[Turkish#^tr-Q0739|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=%C4%B0yi%20bir%20nasihat%20almak%20i%C3%A7in%20nereye%20gidebilirim%3F)
^tr-Q0739-answer

**tr-Q0740** — İyi bir nasihat almak için nereye gidebilirim?

Where can I go to get some good advice?

Expected form: **nereye**

Why: Question words. [[Turkish#^tr-Q0740|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=%C4%B0yi%20bir%20nasihat%20almak%20i%C3%A7in%20nereye%20gidebilirim%3F)
^tr-Q0740-answer

**tr-Q0741** — Hangi yıl doğdun?

What year were you born?

Expected form: **Hangi**

Why: Question words. [[Turkish#^tr-Q0741|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Hangi%20y%C4%B1l%20do%C4%9Fdun%3F)
^tr-Q0741-answer

**tr-Q0742** — Hangi yıl doğdun?

What year were you born?

Why: Question words. [[Turkish#^tr-Q0742|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Hangi%20y%C4%B1l%20do%C4%9Fdun%3F)
^tr-Q0742-answer

**tr-Q0743** — Dün gece nerede olduğunu sonunda öğrendim.

I finally found out where you were last night.

Why: Question words. [[Turkish#^tr-Q0743|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=D%C3%BCn%20gece%20nerede%20oldu%C4%9Funu%20sonunda%20%C3%B6%C4%9Frendim.)
^tr-Q0743-answer

**tr-Q0744** — Dün gece nerede olduğunu sonunda öğrendim.

I finally found out where you were last night.

Location, destination and source have different question forms. Question words take relevant case morphology. Context and focus govern their placement.

Why: Question words. [[Turkish#^tr-Q0744|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=D%C3%BCn%20gece%20nerede%20oldu%C4%9Funu%20sonunda%20%C3%B6%C4%9Frendim.)
^tr-Q0744-answer

**tr-Q0745** — Diyelim bin doların vardı, onunla ne yapardın?

Suppose you had a thousand dollars, what would you do with it?

Expected form: **ne**

Why: Question words. [[Turkish#^tr-Q0745|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Diyelim%20bin%20dolar%C4%B1n%20vard%C4%B1%2C%20onunla%20ne%20yapard%C4%B1n%3F)
^tr-Q0745-answer

**tr-Q0746** — Diyelim bin doların vardı, onunla ne yapardın?

Suppose you had a thousand dollars, what would you do with it?

Expected form: **ne**

Why: Question words. [[Turkish#^tr-Q0746|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Diyelim%20bin%20dolar%C4%B1n%20vard%C4%B1%2C%20onunla%20ne%20yapard%C4%B1n%3F)
^tr-Q0746-answer

**tr-Q0747** — O zaman kaç yaşındaydın?

How old were you then?

Expected form: **kaç**

Why: Question words. [[Turkish#^tr-Q0747|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=O%20zaman%20ka%C3%A7%20ya%C5%9F%C4%B1ndayd%C4%B1n%3F)
^tr-Q0747-answer

**tr-Q0748** — O zaman kaç yaşındaydın?

How old were you then?

Why: Question words. [[Turkish#^tr-Q0748|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=O%20zaman%20ka%C3%A7%20ya%C5%9F%C4%B1ndayd%C4%B1n%3F)
^tr-Q0748-answer

**tr-Q0749** — Neden bunu Tom'a söyleyeyim?

Why would I tell Tom that?

Why: Question words. [[Turkish#^tr-Q0749|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Neden%20bunu%20Tom%27a%20s%C3%B6yleyeyim%3F)
^tr-Q0749-answer

**tr-Q0750** — Neden bunu Tom'a söyleyeyim?

Why would I tell Tom that?

Location, destination and source have different question forms. Question words take relevant case morphology. Context and focus govern their placement.

Why: Question words. [[Turkish#^tr-Q0750|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Neden%20bunu%20Tom%27a%20s%C3%B6yleyeyim%3F)
^tr-Q0750-answer


### Answers 751–800

**tr-Q0751** — Diğer üç kişi özel övgü için seçildi.

Three other people were singled out for special praise.

Expected form: **için**

Why: Postpositions. [[Turkish#^tr-Q0751|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Di%C4%9Fer%20%C3%BC%C3%A7%20ki%C5%9Fi%20%C3%B6zel%20%C3%B6vg%C3%BC%20i%C3%A7in%20se%C3%A7ildi.)
^tr-Q0751-answer

**tr-Q0752** — Diğer üç kişi özel övgü için seçildi.

Three other people were singled out for special praise.

Expected form: **için**

Why: Postpositions. [[Turkish#^tr-Q0752|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Di%C4%9Fer%20%C3%BC%C3%A7%20ki%C5%9Fi%20%C3%B6zel%20%C3%B6vg%C3%BC%20i%C3%A7in%20se%C3%A7ildi.)
^tr-Q0752-answer

**tr-Q0753** — Bugün için işimiz bitti.

We're done for today.

Expected form: **için**

Why: Postpositions. [[Turkish#^tr-Q0753|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bug%C3%BCn%20i%C3%A7in%20i%C5%9Fimiz%20bitti.)
^tr-Q0753-answer

**tr-Q0754** — Bugün için işimiz bitti.

We're done for today.

Why: Postpositions. [[Turkish#^tr-Q0754|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bug%C3%BCn%20i%C3%A7in%20i%C5%9Fimiz%20bitti.)
^tr-Q0754-answer

**tr-Q0755** — Tom Mary ile çıkmak istemiyordu.

Tom had no desire to go out with Mary.

Why: Postpositions. [[Turkish#^tr-Q0755|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20Mary%20ile%20%C3%A7%C4%B1kmak%20istemiyordu.)
^tr-Q0755-answer

**tr-Q0756** — Tom Mary ile çıkmak istemiyordu.

Tom had no desire to go out with Mary.

Postpositions follow a complement and may require a particular case. Bana göre uses dative; benden sonra uses ablative. Learn the whole governed phrase.

Why: Postpositions. [[Turkish#^tr-Q0756|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20Mary%20ile%20%C3%A7%C4%B1kmak%20istemiyordu.)
^tr-Q0756-answer

**tr-Q0757** — Bill Clinton Monica Lewinsky ile olan ilişkisini açıklamak isterken muğlak bir dil kullandı.

Bill Clinton spoke in ambiguous language when asked to describe his relationship with Monica Lewinsky.

Expected form: **ile**

Why: Postpositions. [[Turkish#^tr-Q0757|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bill%20Clinton%20Monica%20Lewinsky%20ile%20olan%20ili%C5%9Fkisini%20a%C3%A7%C4%B1klamak%20isterken%20mu%C4%9Flak%20bir%20dil%20kulland%C4%B1.)
^tr-Q0757-answer

**tr-Q0758** — Bill Clinton Monica Lewinsky ile olan ilişkisini açıklamak isterken muğlak bir dil kullandı.

Bill Clinton spoke in ambiguous language when asked to describe his relationship with Monica Lewinsky.

Expected form: **ile**

Why: Postpositions. [[Turkish#^tr-Q0758|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bill%20Clinton%20Monica%20Lewinsky%20ile%20olan%20ili%C5%9Fkisini%20a%C3%A7%C4%B1klamak%20isterken%20mu%C4%9Flak%20bir%20dil%20kulland%C4%B1.)
^tr-Q0758-answer

**tr-Q0759** — Mary'nin hatası olan bir şey için Tom'u suçlayamam.

I can't blame Tom for something that was Mary's fault.

Expected form: **için**

Why: Postpositions. [[Turkish#^tr-Q0759|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Mary%27nin%20hatas%C4%B1%20olan%20bir%20%C5%9Fey%20i%C3%A7in%20Tom%27u%20su%C3%A7layamam.)
^tr-Q0759-answer

**tr-Q0760** — Mary'nin hatası olan bir şey için Tom'u suçlayamam.

I can't blame Tom for something that was Mary's fault.

Why: Postpositions. [[Turkish#^tr-Q0760|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Mary%27nin%20hatas%C4%B1%20olan%20bir%20%C5%9Fey%20i%C3%A7in%20Tom%27u%20su%C3%A7layamam.)
^tr-Q0760-answer

**tr-Q0761** — Tom ile Boston'a gitmeyeceği söylediğini düşündüm.

I thought you said we weren't going to go to Boston with Tom.

Why: Postpositions. [[Turkish#^tr-Q0761|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20ile%20Boston%27a%20gitmeyece%C4%9Fi%20s%C3%B6yledi%C4%9Fini%20d%C3%BC%C5%9F%C3%BCnd%C3%BCm.)
^tr-Q0761-answer

**tr-Q0762** — Tom ile Boston'a gitmeyeceği söylediğini düşündüm.

I thought you said we weren't going to go to Boston with Tom.

Postpositions follow a complement and may require a particular case. Bana göre uses dative; benden sonra uses ablative. Learn the whole governed phrase.

Why: Postpositions. [[Turkish#^tr-Q0762|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20ile%20Boston%27a%20gitmeyece%C4%9Fi%20s%C3%B6yledi%C4%9Fini%20d%C3%BC%C5%9F%C3%BCnd%C3%BCm.)
^tr-Q0762-answer

**tr-Q0763** — Biz gitmeden önce niçin bir tane almadın?

Why didn't you get one before we left?

Expected form: **önce**

Why: Postpositions. [[Turkish#^tr-Q0763|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Biz%20gitmeden%20%C3%B6nce%20ni%C3%A7in%20bir%20tane%20almad%C4%B1n%3F)
^tr-Q0763-answer

**tr-Q0764** — Biz gitmeden önce niçin bir tane almadın?

Why didn't you get one before we left?

Expected form: **önce**

Why: Postpositions. [[Turkish#^tr-Q0764|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Biz%20gitmeden%20%C3%B6nce%20ni%C3%A7in%20bir%20tane%20almad%C4%B1n%3F)
^tr-Q0764-answer

**tr-Q0765** — Shepard yalnızca 15 dakika kadar uzayda kaldı.

Shepard remained in space only about 15 minutes.

Expected form: **kadar**

Why: Postpositions. [[Turkish#^tr-Q0765|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Shepard%20yaln%C4%B1zca%2015%20dakika%20kadar%20uzayda%20kald%C4%B1.)
^tr-Q0765-answer

**tr-Q0766** — Shepard yalnızca 15 dakika kadar uzayda kaldı.

Shepard remained in space only about 15 minutes.

Why: Postpositions. [[Turkish#^tr-Q0766|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Shepard%20yaln%C4%B1zca%2015%20dakika%20kadar%20uzayda%20kald%C4%B1.)
^tr-Q0766-answer

**tr-Q0767** — O olacağını düşündüğüm kadar pahalı değildi.

It wasn't as expensive as I thought it would be.

Why: Postpositions. [[Turkish#^tr-Q0767|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=O%20olaca%C4%9F%C4%B1n%C4%B1%20d%C3%BC%C5%9F%C3%BCnd%C3%BC%C4%9F%C3%BCm%20kadar%20pahal%C4%B1%20de%C4%9Fildi.)
^tr-Q0767-answer

**tr-Q0768** — O olacağını düşündüğüm kadar pahalı değildi.

It wasn't as expensive as I thought it would be.

Postpositions follow a complement and may require a particular case. Bana göre uses dative; benden sonra uses ablative. Learn the whole governed phrase.

Why: Postpositions. [[Turkish#^tr-Q0768|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=O%20olaca%C4%9F%C4%B1n%C4%B1%20d%C3%BC%C5%9F%C3%BCnd%C3%BC%C4%9F%C3%BCm%20kadar%20pahal%C4%B1%20de%C4%9Fildi.)
^tr-Q0768-answer

**tr-Q0769** — Koşmaya başlamasından sonra beş dakika olmamıştı ki bir kayaya takılıp düştü.

Not five minutes after he started running, he tripped on a rock.

Expected form: **sonra**

Why: Postpositions. [[Turkish#^tr-Q0769|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ko%C5%9Fmaya%20ba%C5%9Flamas%C4%B1ndan%20sonra%20be%C5%9F%20dakika%20olmam%C4%B1%C5%9Ft%C4%B1%20ki%20bir%20kayaya%20tak%C4%B1l%C4%B1p%20d%C3%BC%C5%9Ft%C3%BC.)
^tr-Q0769-answer

**tr-Q0770** — Koşmaya başlamasından sonra beş dakika olmamıştı ki bir kayaya takılıp düştü.

Not five minutes after he started running, he tripped on a rock.

Expected form: **sonra**

Why: Postpositions. [[Turkish#^tr-Q0770|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ko%C5%9Fmaya%20ba%C5%9Flamas%C4%B1ndan%20sonra%20be%C5%9F%20dakika%20olmam%C4%B1%C5%9Ft%C4%B1%20ki%20bir%20kayaya%20tak%C4%B1l%C4%B1p%20d%C3%BC%C5%9Ft%C3%BC.)
^tr-Q0770-answer

**tr-Q0771** — Tom'un Mary ile gördüğü son kişi John'du.

The last person Tom saw Mary with was John.

Expected form: **ile**

Why: Postpositions. [[Turkish#^tr-Q0771|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%27un%20Mary%20ile%20g%C3%B6rd%C3%BC%C4%9F%C3%BC%20son%20ki%C5%9Fi%20John%27du.)
^tr-Q0771-answer

**tr-Q0772** — Tom'un Mary ile gördüğü son kişi John'du.

The last person Tom saw Mary with was John.

Why: Postpositions. [[Turkish#^tr-Q0772|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%27un%20Mary%20ile%20g%C3%B6rd%C3%BC%C4%9F%C3%BC%20son%20ki%C5%9Fi%20John%27du.)
^tr-Q0772-answer

**tr-Q0773** — Tom kaya tırmanışı için çok yaşlı olduğuna karar verdi.

Tom decided he was too old for rock climbing.

Why: Postpositions. [[Turkish#^tr-Q0773|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20kaya%20t%C4%B1rman%C4%B1%C5%9F%C4%B1%20i%C3%A7in%20%C3%A7ok%20ya%C5%9Fl%C4%B1%20oldu%C4%9Funa%20karar%20verdi.)
^tr-Q0773-answer

**tr-Q0774** — Tom kaya tırmanışı için çok yaşlı olduğuna karar verdi.

Tom decided he was too old for rock climbing.

Postpositions follow a complement and may require a particular case. Bana göre uses dative; benden sonra uses ablative. Learn the whole governed phrase.

Why: Postpositions. [[Turkish#^tr-Q0774|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20kaya%20t%C4%B1rman%C4%B1%C5%9F%C4%B1%20i%C3%A7in%20%C3%A7ok%20ya%C5%9Fl%C4%B1%20oldu%C4%9Funa%20karar%20verdi.)
^tr-Q0774-answer

**tr-Q0775** — Jamal içki almaya gitmek için şantiyeden ayrıldı.

Jamal left the construction site to go get a drink.

Expected form: **için**

Why: Postpositions. [[Turkish#^tr-Q0775|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Jamal%20i%C3%A7ki%20almaya%20gitmek%20i%C3%A7in%20%C5%9Fantiyeden%20ayr%C4%B1ld%C4%B1.)
^tr-Q0775-answer

**tr-Q0776** — Jamal içki almaya gitmek için şantiyeden ayrıldı.

Jamal left the construction site to go get a drink.

Expected form: **için**

Why: Postpositions. [[Turkish#^tr-Q0776|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Jamal%20i%C3%A7ki%20almaya%20gitmek%20i%C3%A7in%20%C5%9Fantiyeden%20ayr%C4%B1ld%C4%B1.)
^tr-Q0776-answer

**tr-Q0777** — Tom çok sinirli gibi görünüyor.

Tom looks like a nervous wreck.

Expected form: **gibi**

Why: Postpositions. [[Turkish#^tr-Q0777|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20%C3%A7ok%20sinirli%20gibi%20g%C3%B6r%C3%BCn%C3%BCyor.)
^tr-Q0777-answer

**tr-Q0778** — Tom çok sinirli gibi görünüyor.

Tom looks like a nervous wreck.

Why: Postpositions. [[Turkish#^tr-Q0778|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20%C3%A7ok%20sinirli%20gibi%20g%C3%B6r%C3%BCn%C3%BCyor.)
^tr-Q0778-answer

**tr-Q0779** — Tom'a göre bugün derste değildin.

According to Tom, you weren't in class today.

Why: Postpositions. [[Turkish#^tr-Q0779|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%27a%20g%C3%B6re%20bug%C3%BCn%20derste%20de%C4%9Fildin.)
^tr-Q0779-answer

**tr-Q0780** — Tom'a göre bugün derste değildin.

According to Tom, you weren't in class today.

Postpositions follow a complement and may require a particular case. Bana göre uses dative; benden sonra uses ablative. Learn the whole governed phrase.

Why: Postpositions. [[Turkish#^tr-Q0780|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%27a%20g%C3%B6re%20bug%C3%BCn%20derste%20de%C4%9Fildin.)
^tr-Q0780-answer

**tr-Q0781** — O bir balta ile dalı kesti.

She chopped down the branch with an ax.

Expected form: **ile**

Why: Postpositions. [[Turkish#^tr-Q0781|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=O%20bir%20balta%20ile%20dal%C4%B1%20kesti.)
^tr-Q0781-answer

**tr-Q0782** — O bir balta ile dalı kesti.

She chopped down the branch with an ax.

Expected form: **ile**

Why: Postpositions. [[Turkish#^tr-Q0782|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=O%20bir%20balta%20ile%20dal%C4%B1%20kesti.)
^tr-Q0782-answer

**tr-Q0783** — Sen böyle iyi arkadaşlara sahip olduğun için şanslısın.

You are fortunate for having such good friends.

Expected form: **için**

Why: Postpositions. [[Turkish#^tr-Q0783|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Sen%20b%C3%B6yle%20iyi%20arkada%C5%9Flara%20sahip%20oldu%C4%9Fun%20i%C3%A7in%20%C5%9Fansl%C4%B1s%C4%B1n.)
^tr-Q0783-answer

**tr-Q0784** — Sen böyle iyi arkadaşlara sahip olduğun için şanslısın.

You are fortunate for having such good friends.

Why: Postpositions. [[Turkish#^tr-Q0784|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Sen%20b%C3%B6yle%20iyi%20arkada%C5%9Flara%20sahip%20oldu%C4%9Fun%20i%C3%A7in%20%C5%9Fansl%C4%B1s%C4%B1n.)
^tr-Q0784-answer

**tr-Q0785** — Tom araba kullanmak için hala çok genç.

Tom is still too young to drive.

Why: Postpositions. [[Turkish#^tr-Q0785|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20araba%20kullanmak%20i%C3%A7in%20hala%20%C3%A7ok%20gen%C3%A7.)
^tr-Q0785-answer

**tr-Q0786** — Tom araba kullanmak için hala çok genç.

Tom is still too young to drive.

Postpositions follow a complement and may require a particular case. Bana göre uses dative; benden sonra uses ablative. Learn the whole governed phrase.

Why: Postpositions. [[Turkish#^tr-Q0786|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20araba%20kullanmak%20i%C3%A7in%20hala%20%C3%A7ok%20gen%C3%A7.)
^tr-Q0786-answer

**tr-Q0787** — Haziran'dan eylül ayına kadar, biz daha fazla çalışırız.

From June to September, we work harder.

Expected form: **kadar**

Why: Postpositions. [[Turkish#^tr-Q0787|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Haziran%27dan%20eyl%C3%BCl%20ay%C4%B1na%20kadar%2C%20biz%20daha%20fazla%20%C3%A7al%C4%B1%C5%9F%C4%B1r%C4%B1z.)
^tr-Q0787-answer

**tr-Q0788** — Haziran'dan eylül ayına kadar, biz daha fazla çalışırız.

From June to September, we work harder.

Expected form: **kadar**

Why: Postpositions. [[Turkish#^tr-Q0788|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Haziran%27dan%20eyl%C3%BCl%20ay%C4%B1na%20kadar%2C%20biz%20daha%20fazla%20%C3%A7al%C4%B1%C5%9F%C4%B1r%C4%B1z.)
^tr-Q0788-answer

**tr-Q0789** — Tom ve Mary aile gibi.

Tom and Mary are like family.

Expected form: **gibi**

Why: Postpositions. [[Turkish#^tr-Q0789|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20ve%20Mary%20aile%20gibi.)
^tr-Q0789-answer

**tr-Q0790** — Tom ve Mary aile gibi.

Tom and Mary are like family.

Why: Postpositions. [[Turkish#^tr-Q0790|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20ve%20Mary%20aile%20gibi.)
^tr-Q0790-answer

**tr-Q0791** — Bay Yamanaka, kendi yaşına göre genç görünüyor.

Mr. Yamanaka looks young for his age.

Why: Postpositions. [[Turkish#^tr-Q0791|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bay%20Yamanaka%2C%20kendi%20ya%C5%9F%C4%B1na%20g%C3%B6re%20gen%C3%A7%20g%C3%B6r%C3%BCn%C3%BCyor.)
^tr-Q0791-answer

**tr-Q0792** — Bay Yamanaka, kendi yaşına göre genç görünüyor.

Mr. Yamanaka looks young for his age.

Postpositions follow a complement and may require a particular case. Bana göre uses dative; benden sonra uses ablative. Learn the whole governed phrase.

Why: Postpositions. [[Turkish#^tr-Q0792|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bay%20Yamanaka%2C%20kendi%20ya%C5%9F%C4%B1na%20g%C3%B6re%20gen%C3%A7%20g%C3%B6r%C3%BCn%C3%BCyor.)
^tr-Q0792-answer

**tr-Q0793** — Plastik cerrahiden önce bile, Mary çirkin değildi.

Even before the plastic surgery, Mary wasn't unattractive.

Expected form: **önce**

Why: Postpositions. [[Turkish#^tr-Q0793|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Plastik%20cerrahiden%20%C3%B6nce%20bile%2C%20Mary%20%C3%A7irkin%20de%C4%9Fildi.)
^tr-Q0793-answer

**tr-Q0794** — Plastik cerrahiden önce bile, Mary çirkin değildi.

Even before the plastic surgery, Mary wasn't unattractive.

Expected form: **önce**

Why: Postpositions. [[Turkish#^tr-Q0794|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Plastik%20cerrahiden%20%C3%B6nce%20bile%2C%20Mary%20%C3%A7irkin%20de%C4%9Fildi.)
^tr-Q0794-answer

**tr-Q0795** — Her şey için zaman var.

There's time for everything.

Expected form: **için**

Why: Postpositions. [[Turkish#^tr-Q0795|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Her%20%C5%9Fey%20i%C3%A7in%20zaman%20var.)
^tr-Q0795-answer

**tr-Q0796** — Her şey için zaman var.

There's time for everything.

Why: Postpositions. [[Turkish#^tr-Q0796|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Her%20%C5%9Fey%20i%C3%A7in%20zaman%20var.)
^tr-Q0796-answer

**tr-Q0797** — Tom yorgun gibi görünüyor.

It looks like Tom is exhausted.

Why: Postpositions. [[Turkish#^tr-Q0797|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20yorgun%20gibi%20g%C3%B6r%C3%BCn%C3%BCyor.)
^tr-Q0797-answer

**tr-Q0798** — Tom yorgun gibi görünüyor.

It looks like Tom is exhausted.

Postpositions follow a complement and may require a particular case. Bana göre uses dative; benden sonra uses ablative. Learn the whole governed phrase.

Why: Postpositions. [[Turkish#^tr-Q0798|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20yorgun%20gibi%20g%C3%B6r%C3%BCn%C3%BCyor.)
^tr-Q0798-answer

**tr-Q0799** — Büyü ve yaşına göre davran!

Grow up and act your age!

Expected form: **göre**

Why: Postpositions. [[Turkish#^tr-Q0799|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=B%C3%BCy%C3%BC%20ve%20ya%C5%9F%C4%B1na%20g%C3%B6re%20davran%21)
^tr-Q0799-answer

**tr-Q0800** — Büyü ve yaşına göre davran!

Grow up and act your age!

Expected form: **göre**

Why: Postpositions. [[Turkish#^tr-Q0800|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=B%C3%BCy%C3%BC%20ve%20ya%C5%9F%C4%B1na%20g%C3%B6re%20davran%21)
^tr-Q0800-answer


### Answers 801–850

**tr-Q0801** — Eğer isteseydi Tom Mary'ye yardım edebilirdi.

Tom could help Mary if he wanted to.

Expected form: **Eğer**

Why: Conditions. [[Turkish#^tr-Q0801|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=E%C4%9Fer%20isteseydi%20Tom%20Mary%27ye%20yard%C4%B1m%20edebilirdi.)
^tr-Q0801-answer

**tr-Q0802** — Eğer isteseydi Tom Mary'ye yardım edebilirdi.

Tom could help Mary if he wanted to.

Why: Conditions. [[Turkish#^tr-Q0802|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=E%C4%9Fer%20isteseydi%20Tom%20Mary%27ye%20yard%C4%B1m%20edebilirdi.)
^tr-Q0802-answer

**tr-Q0803** — Eğer Tom Mary'ye yardım edebiliyorsa, neden John'a da yardım edemiyor?

If Tom can help Mary, why can't he help John, too?

Why: Conditions. [[Turkish#^tr-Q0803|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=E%C4%9Fer%20Tom%20Mary%27ye%20yard%C4%B1m%20edebiliyorsa%2C%20neden%20John%27a%20da%20yard%C4%B1m%20edemiyor%3F)
^tr-Q0803-answer

**tr-Q0804** — Eğer Tom Mary'ye yardım edebiliyorsa, neden John'a da yardım edemiyor?

If Tom can help Mary, why can't he help John, too?

Conditional suffix -sA and related forms encode different time and reality relationships. Eğer can introduce a condition but is not necessary in every conditional sentence.

Why: Conditions. [[Turkish#^tr-Q0804|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=E%C4%9Fer%20Tom%20Mary%27ye%20yard%C4%B1m%20edebiliyorsa%2C%20neden%20John%27a%20da%20yard%C4%B1m%20edemiyor%3F)
^tr-Q0804-answer

**tr-Q0805** — Bir şeye ihtiyacın olursa beni ara.

Call me if you need anything.

Expected form: **olursa**

Why: Conditions. [[Turkish#^tr-Q0805|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bir%20%C5%9Feye%20ihtiyac%C4%B1n%20olursa%20beni%20ara.)
^tr-Q0805-answer

**tr-Q0806** — Bir şeye ihtiyacın olursa beni ara.

Call me if you need anything.

Expected form: **olursa**

Why: Conditions. [[Turkish#^tr-Q0806|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bir%20%C5%9Feye%20ihtiyac%C4%B1n%20olursa%20beni%20ara.)
^tr-Q0806-answer

**tr-Q0807** — Eğer sessiz olmazsan seni duyarlar.

If you're not quiet, they'll hear you.

Expected form: **Eğer**

Why: Conditions. [[Turkish#^tr-Q0807|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=E%C4%9Fer%20sessiz%20olmazsan%20seni%20duyarlar.)
^tr-Q0807-answer

**tr-Q0808** — Eğer sessiz olmazsan seni duyarlar.

If you're not quiet, they'll hear you.

Why: Conditions. [[Turkish#^tr-Q0808|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=E%C4%9Fer%20sessiz%20olmazsan%20seni%20duyarlar.)
^tr-Q0808-answer

**tr-Q0809** — Keşke büyükbabam onu görmek için hayatta olsaydı.

I wish my grandfather had been alive to see that.

Why: Conditions. [[Turkish#^tr-Q0809|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ke%C5%9Fke%20b%C3%BCy%C3%BCkbabam%20onu%20g%C3%B6rmek%20i%C3%A7in%20hayatta%20olsayd%C4%B1.)
^tr-Q0809-answer

**tr-Q0810** — Keşke büyükbabam onu görmek için hayatta olsaydı.

I wish my grandfather had been alive to see that.

Conditional suffix -sA and related forms encode different time and reality relationships. Eğer can introduce a condition but is not necessary in every conditional sentence.

Why: Conditions. [[Turkish#^tr-Q0810|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ke%C5%9Fke%20b%C3%BCy%C3%BCkbabam%20onu%20g%C3%B6rmek%20i%C3%A7in%20hayatta%20olsayd%C4%B1.)
^tr-Q0810-answer

**tr-Q0811** — Eğer bilmiyorsan sor.

If you don't know, ask.

Expected form: **Eğer**

Why: Conditions. [[Turkish#^tr-Q0811|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=E%C4%9Fer%20bilmiyorsan%20sor.)
^tr-Q0811-answer

**tr-Q0812** — Eğer bilmiyorsan sor.

If you don't know, ask.

Expected form: **Eğer**

Why: Conditions. [[Turkish#^tr-Q0812|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=E%C4%9Fer%20bilmiyorsan%20sor.)
^tr-Q0812-answer

**tr-Q0813** — Eğer bu modern donanımı kullanırsanız bir sürü iş gücü tasarruf edecektir.

If you use this modern equipment, it will save a lot of manpower.

Expected form: **Eğer**

Why: Conditions. [[Turkish#^tr-Q0813|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=E%C4%9Fer%20bu%20modern%20donan%C4%B1m%C4%B1%20kullan%C4%B1rsan%C4%B1z%20bir%20s%C3%BCr%C3%BC%20i%C5%9F%20g%C3%BCc%C3%BC%20tasarruf%20edecektir.)
^tr-Q0813-answer

**tr-Q0814** — Eğer bu modern donanımı kullanırsanız bir sürü iş gücü tasarruf edecektir.

If you use this modern equipment, it will save a lot of manpower.

Why: Conditions. [[Turkish#^tr-Q0814|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=E%C4%9Fer%20bu%20modern%20donan%C4%B1m%C4%B1%20kullan%C4%B1rsan%C4%B1z%20bir%20s%C3%BCr%C3%BC%20i%C5%9F%20g%C3%BCc%C3%BC%20tasarruf%20edecektir.)
^tr-Q0814-answer

**tr-Q0815** — Ne olursa olsun, vazgeçmeyeceğim.

No matter what happens, I won't give up.

Why: Conditions. [[Turkish#^tr-Q0815|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ne%20olursa%20olsun%2C%20vazge%C3%A7meyece%C4%9Fim.)
^tr-Q0815-answer

**tr-Q0816** — Ne olursa olsun, vazgeçmeyeceğim.

No matter what happens, I won't give up.

Conditional suffix -sA and related forms encode different time and reality relationships. Eğer can introduce a condition but is not necessary in every conditional sentence.

Why: Conditions. [[Turkish#^tr-Q0816|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ne%20olursa%20olsun%2C%20vazge%C3%A7meyece%C4%9Fim.)
^tr-Q0816-answer

**tr-Q0817** — Ne kadar olursa olsun. Gene de istiyorum.

I don't care what it cost. I still want it.

Expected form: **olursa**

Why: Conditions. [[Turkish#^tr-Q0817|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ne%20kadar%20olursa%20olsun.%20Gene%20de%20istiyorum.)
^tr-Q0817-answer

**tr-Q0818** — Ne kadar olursa olsun. Gene de istiyorum.

I don't care what it cost. I still want it.

Expected form: **olursa**

Why: Conditions. [[Turkish#^tr-Q0818|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ne%20kadar%20olursa%20olsun.%20Gene%20de%20istiyorum.)
^tr-Q0818-answer

**tr-Q0819** — Bir zaman makinen olsaydı, hangi yılı ziyaret ederdin?

If you had a time machine, which year would you visit?

Expected form: **olsaydı**

Why: Conditions. [[Turkish#^tr-Q0819|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bir%20zaman%20makinen%20olsayd%C4%B1%2C%20hangi%20y%C4%B1l%C4%B1%20ziyaret%20ederdin%3F)
^tr-Q0819-answer

**tr-Q0820** — Bir zaman makinen olsaydı, hangi yılı ziyaret ederdin?

If you had a time machine, which year would you visit?

Why: Conditions. [[Turkish#^tr-Q0820|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bir%20zaman%20makinen%20olsayd%C4%B1%2C%20hangi%20y%C4%B1l%C4%B1%20ziyaret%20ederdin%3F)
^tr-Q0820-answer

**tr-Q0821** — Eğer istiyorsan tamamdır.

It's okay if you want to.

Why: Conditions. [[Turkish#^tr-Q0821|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=E%C4%9Fer%20istiyorsan%20tamamd%C4%B1r.)
^tr-Q0821-answer

**tr-Q0822** — Eğer istiyorsan tamamdır.

It's okay if you want to.

Conditional suffix -sA and related forms encode different time and reality relationships. Eğer can introduce a condition but is not necessary in every conditional sentence.

Why: Conditions. [[Turkish#^tr-Q0822|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=E%C4%9Fer%20istiyorsan%20tamamd%C4%B1r.)
^tr-Q0822-answer

**tr-Q0823** — Eğer çalışmayacaksan okula gitmenin bir faydası yok.

It is no use going to school if you are not going to study.

Expected form: **Eğer**

Why: Conditions. [[Turkish#^tr-Q0823|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=E%C4%9Fer%20%C3%A7al%C4%B1%C5%9Fmayacaksan%20okula%20gitmenin%20bir%20faydas%C4%B1%20yok.)
^tr-Q0823-answer

**tr-Q0824** — Eğer çalışmayacaksan okula gitmenin bir faydası yok.

It is no use going to school if you are not going to study.

Expected form: **Eğer**

Why: Conditions. [[Turkish#^tr-Q0824|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=E%C4%9Fer%20%C3%A7al%C4%B1%C5%9Fmayacaksan%20okula%20gitmenin%20bir%20faydas%C4%B1%20yok.)
^tr-Q0824-answer

**tr-Q0825** — Eğer Tom yardım etseydi bu kadar meşgul olmazdın.

You wouldn't have been so busy if Tom had helped.

Expected form: **Eğer**

Why: Conditions. [[Turkish#^tr-Q0825|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=E%C4%9Fer%20Tom%20yard%C4%B1m%20etseydi%20bu%20kadar%20me%C5%9Fgul%20olmazd%C4%B1n.)
^tr-Q0825-answer

**tr-Q0826** — Eğer Tom yardım etseydi bu kadar meşgul olmazdın.

You wouldn't have been so busy if Tom had helped.

Why: Conditions. [[Turkish#^tr-Q0826|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=E%C4%9Fer%20Tom%20yard%C4%B1m%20etseydi%20bu%20kadar%20me%C5%9Fgul%20olmazd%C4%B1n.)
^tr-Q0826-answer

**tr-Q0827** — Eğer o zaman İngilizce konuşabilseydim, alay edilmezdim.

If I had been able to speak English then, I would not have been made fun of.

Why: Conditions. [[Turkish#^tr-Q0827|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=E%C4%9Fer%20o%20zaman%20%C4%B0ngilizce%20konu%C5%9Fabilseydim%2C%20alay%20edilmezdim.)
^tr-Q0827-answer

**tr-Q0828** — Eğer o zaman İngilizce konuşabilseydim, alay edilmezdim.

If I had been able to speak English then, I would not have been made fun of.

Conditional suffix -sA and related forms encode different time and reality relationships. Eğer can introduce a condition but is not necessary in every conditional sentence.

Why: Conditions. [[Turkish#^tr-Q0828|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=E%C4%9Fer%20o%20zaman%20%C4%B0ngilizce%20konu%C5%9Fabilseydim%2C%20alay%20edilmezdim.)
^tr-Q0828-answer

**tr-Q0829** — Ne olursa olsun, fikrimi değiştirmeyeceğim.

Come what may; I won't change my mind.

Expected form: **olursa**

Why: Conditions. [[Turkish#^tr-Q0829|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ne%20olursa%20olsun%2C%20fikrimi%20de%C4%9Fi%C5%9Ftirmeyece%C4%9Fim.)
^tr-Q0829-answer

**tr-Q0830** — Ne olursa olsun, fikrimi değiştirmeyeceğim.

Come what may; I won't change my mind.

Expected form: **olursa**

Why: Conditions. [[Turkish#^tr-Q0830|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ne%20olursa%20olsun%2C%20fikrimi%20de%C4%9Fi%C5%9Ftirmeyece%C4%9Fim.)
^tr-Q0830-answer

**tr-Q0831** — Eğer herkes bağışta bulunursa, öğleye kadar oturma odasını boyamayı bitirebileceğiz.

If everyone chips in, we'll be able to finish painting the living room by noon.

Expected form: **Eğer**

Why: Conditions. [[Turkish#^tr-Q0831|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=E%C4%9Fer%20herkes%20ba%C4%9F%C4%B1%C5%9Fta%20bulunursa%2C%20%C3%B6%C4%9Fleye%20kadar%20oturma%20odas%C4%B1n%C4%B1%20boyamay%C4%B1%20bitirebilece%C4%9Fiz.)
^tr-Q0831-answer

**tr-Q0832** — Eğer herkes bağışta bulunursa, öğleye kadar oturma odasını boyamayı bitirebileceğiz.

If everyone chips in, we'll be able to finish painting the living room by noon.

Why: Conditions. [[Turkish#^tr-Q0832|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=E%C4%9Fer%20herkes%20ba%C4%9F%C4%B1%C5%9Fta%20bulunursa%2C%20%C3%B6%C4%9Fleye%20kadar%20oturma%20odas%C4%B1n%C4%B1%20boyamay%C4%B1%20bitirebilece%C4%9Fiz.)
^tr-Q0832-answer

**tr-Q0833** — Yardımına ihtiyacımız olursa, seni ararız.

If we need your help, we'll call you.

Why: Conditions. [[Turkish#^tr-Q0833|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Yard%C4%B1m%C4%B1na%20ihtiyac%C4%B1m%C4%B1z%20olursa%2C%20seni%20arar%C4%B1z.)
^tr-Q0833-answer

**tr-Q0834** — Yardımına ihtiyacımız olursa, seni ararız.

If we need your help, we'll call you.

Conditional suffix -sA and related forms encode different time and reality relationships. Eğer can introduce a condition but is not necessary in every conditional sentence.

Why: Conditions. [[Turkish#^tr-Q0834|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Yard%C4%B1m%C4%B1na%20ihtiyac%C4%B1m%C4%B1z%20olursa%2C%20seni%20arar%C4%B1z.)
^tr-Q0834-answer

**tr-Q0835** — Eğer kötüleşirseniz doktora gitmeyi unutmayın.

Make sure you go to a doctor if you get worse.

Expected form: **Eğer**

Why: Conditions. [[Turkish#^tr-Q0835|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=E%C4%9Fer%20k%C3%B6t%C3%BCle%C5%9Firseniz%20doktora%20gitmeyi%20unutmay%C4%B1n.)
^tr-Q0835-answer

**tr-Q0836** — Eğer kötüleşirseniz doktora gitmeyi unutmayın.

Make sure you go to a doctor if you get worse.

Expected form: **Eğer**

Why: Conditions. [[Turkish#^tr-Q0836|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=E%C4%9Fer%20k%C3%B6t%C3%BCle%C5%9Firseniz%20doktora%20gitmeyi%20unutmay%C4%B1n.)
^tr-Q0836-answer

**tr-Q0837** — Ne kadar meşgul olursa olsun, ayda en az bir kez ebeveynlerine yazar.

He writes home to his parents at least once a month, no matter how busy he is.

Expected form: **olursa**

Why: Conditions. [[Turkish#^tr-Q0837|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ne%20kadar%20me%C5%9Fgul%20olursa%20olsun%2C%20ayda%20en%20az%20bir%20kez%20ebeveynlerine%20yazar.)
^tr-Q0837-answer

**tr-Q0838** — Ne kadar meşgul olursa olsun, ayda en az bir kez ebeveynlerine yazar.

He writes home to his parents at least once a month, no matter how busy he is.

Why: Conditions. [[Turkish#^tr-Q0838|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ne%20kadar%20me%C5%9Fgul%20olursa%20olsun%2C%20ayda%20en%20az%20bir%20kez%20ebeveynlerine%20yazar.)
^tr-Q0838-answer

**tr-Q0839** — Eğer gitmezsen polisleri arayacağım.

If you don't leave, I'm going to call the cops.

Why: Conditions. [[Turkish#^tr-Q0839|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=E%C4%9Fer%20gitmezsen%20polisleri%20arayaca%C4%9F%C4%B1m.)
^tr-Q0839-answer

**tr-Q0840** — Eğer gitmezsen polisleri arayacağım.

If you don't leave, I'm going to call the cops.

Conditional suffix -sA and related forms encode different time and reality relationships. Eğer can introduce a condition but is not necessary in every conditional sentence.

Why: Conditions. [[Turkish#^tr-Q0840|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=E%C4%9Fer%20gitmezsen%20polisleri%20arayaca%C4%9F%C4%B1m.)
^tr-Q0840-answer

**tr-Q0841** — O tutumla ne kadar çok paranız olursa olsun mutlu olmazsınız.

With that attitude, you'll never be happy no matter how much money you have.

Expected form: **olursa**

Why: Conditions. [[Turkish#^tr-Q0841|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=O%20tutumla%20ne%20kadar%20%C3%A7ok%20paran%C4%B1z%20olursa%20olsun%20mutlu%20olmazs%C4%B1n%C4%B1z.)
^tr-Q0841-answer

**tr-Q0842** — O tutumla ne kadar çok paranız olursa olsun mutlu olmazsınız.

With that attitude, you'll never be happy no matter how much money you have.

Expected form: **olursa**

Why: Conditions. [[Turkish#^tr-Q0842|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=O%20tutumla%20ne%20kadar%20%C3%A7ok%20paran%C4%B1z%20olursa%20olsun%20mutlu%20olmazs%C4%B1n%C4%B1z.)
^tr-Q0842-answer

**tr-Q0843** — Tom eğer gerçekten onları isteseydi onların hepsini alabilirdi.

Tom could buy all of those if he really wanted them.

Expected form: **eğer**

Why: Conditions. [[Turkish#^tr-Q0843|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20e%C4%9Fer%20ger%C3%A7ekten%20onlar%C4%B1%20isteseydi%20onlar%C4%B1n%20hepsini%20alabilirdi.)
^tr-Q0843-answer

**tr-Q0844** — Tom eğer gerçekten onları isteseydi onların hepsini alabilirdi.

Tom could buy all of those if he really wanted them.

Why: Conditions. [[Turkish#^tr-Q0844|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20e%C4%9Fer%20ger%C3%A7ekten%20onlar%C4%B1%20isteseydi%20onlar%C4%B1n%20hepsini%20alabilirdi.)
^tr-Q0844-answer

**tr-Q0845** — Tom, eğer sen gitmiyorsan ben de gitmiyorum.

Tom, if you're not going I'm not going either.

Why: Conditions. [[Turkish#^tr-Q0845|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%2C%20e%C4%9Fer%20sen%20gitmiyorsan%20ben%20de%20gitmiyorum.)
^tr-Q0845-answer

**tr-Q0846** — Tom, eğer sen gitmiyorsan ben de gitmiyorum.

Tom, if you're not going I'm not going either.

Conditional suffix -sA and related forms encode different time and reality relationships. Eğer can introduce a condition but is not necessary in every conditional sentence.

Why: Conditions. [[Turkish#^tr-Q0846|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%2C%20e%C4%9Fer%20sen%20gitmiyorsan%20ben%20de%20gitmiyorum.)
^tr-Q0846-answer

**tr-Q0847** — Eğer Tom'un bir sorunu olsaydı ona yardım edebilirdin.

If Tom has a problem, you could help him.

Expected form: **Eğer**

Why: Conditions. [[Turkish#^tr-Q0847|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=E%C4%9Fer%20Tom%27un%20bir%20sorunu%20olsayd%C4%B1%20ona%20yard%C4%B1m%20edebilirdin.)
^tr-Q0847-answer

**tr-Q0848** — Eğer Tom'un bir sorunu olsaydı ona yardım edebilirdin.

If Tom has a problem, you could help him.

Expected form: **Eğer**

Why: Conditions. [[Turkish#^tr-Q0848|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=E%C4%9Fer%20Tom%27un%20bir%20sorunu%20olsayd%C4%B1%20ona%20yard%C4%B1m%20edebilirdin.)
^tr-Q0848-answer

**tr-Q0849** — Eğer almamı istersen sana başka bir tane alırım.

I'll buy you another one if you want me to.

Expected form: **Eğer**

Why: Conditions. [[Turkish#^tr-Q0849|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=E%C4%9Fer%20almam%C4%B1%20istersen%20sana%20ba%C5%9Fka%20bir%20tane%20al%C4%B1r%C4%B1m.)
^tr-Q0849-answer

**tr-Q0850** — Eğer almamı istersen sana başka bir tane alırım.

I'll buy you another one if you want me to.

Why: Conditions. [[Turkish#^tr-Q0850|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=E%C4%9Fer%20almam%C4%B1%20istersen%20sana%20ba%C5%9Fka%20bir%20tane%20al%C4%B1r%C4%B1m.)
^tr-Q0850-answer


### Answers 851–900

**tr-Q0851** — Tom ve arkadaşı plastik kılıçlarla düello ediyorlardı.

Tom and his friend were duelling with plastic swords.

Why: Clause linking. [[Turkish#^tr-Q0851|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20ve%20arkada%C5%9F%C4%B1%20plastik%20k%C4%B1l%C4%B1%C3%A7larla%20d%C3%BCello%20ediyorlard%C4%B1.)
^tr-Q0851-answer

**tr-Q0852** — Tom ve arkadaşı plastik kılıçlarla düello ediyorlardı.

Tom and his friend were duelling with plastic swords.

Connectors mark cause, contrast and coordination. Turkish also uses suffix-based non-finite clauses extensively; do not assume every English connector needs a separate Turkish word.

Why: Clause linking. [[Turkish#^tr-Q0852|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20ve%20arkada%C5%9F%C4%B1%20plastik%20k%C4%B1l%C4%B1%C3%A7larla%20d%C3%BCello%20ediyorlard%C4%B1.)
^tr-Q0852-answer

**tr-Q0853** — Tom ve Mary birbiriyle evliydi.

Tom and Mary used to be married to each other.

Expected form: **ve**

Why: Clause linking. [[Turkish#^tr-Q0853|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20ve%20Mary%20birbiriyle%20evliydi.)
^tr-Q0853-answer

**tr-Q0854** — Tom ve Mary birbiriyle evliydi.

Tom and Mary used to be married to each other.

Expected form: **ve**

Why: Clause linking. [[Turkish#^tr-Q0854|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20ve%20Mary%20birbiriyle%20evliydi.)
^tr-Q0854-answer

**tr-Q0855** — Dikiş dikmeyi bıraktı ve biraz çay içti.

She stopped sewing and had some tea.

Expected form: **ve**

Why: Clause linking. [[Turkish#^tr-Q0855|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Diki%C5%9F%20dikmeyi%20b%C4%B1rakt%C4%B1%20ve%20biraz%20%C3%A7ay%20i%C3%A7ti.)
^tr-Q0855-answer

**tr-Q0856** — Dikiş dikmeyi bıraktı ve biraz çay içti.

She stopped sewing and had some tea.

Why: Clause linking. [[Turkish#^tr-Q0856|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Diki%C5%9F%20dikmeyi%20b%C4%B1rakt%C4%B1%20ve%20biraz%20%C3%A7ay%20i%C3%A7ti.)
^tr-Q0856-answer

**tr-Q0857** — Araba mumluydu ve parlıyordu.

The car is waxed and shining.

Why: Clause linking. [[Turkish#^tr-Q0857|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Araba%20mumluydu%20ve%20parl%C4%B1yordu.)
^tr-Q0857-answer

**tr-Q0858** — Araba mumluydu ve parlıyordu.

The car is waxed and shining.

Connectors mark cause, contrast and coordination. Turkish also uses suffix-based non-finite clauses extensively; do not assume every English connector needs a separate Turkish word.

Why: Clause linking. [[Turkish#^tr-Q0858|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Araba%20mumluydu%20ve%20parl%C4%B1yordu.)
^tr-Q0858-answer

**tr-Q0859** — Sessiz oturun ve bir şeye dokunmayın.

Sit still and don't touch anything.

Expected form: **ve**

Why: Clause linking. [[Turkish#^tr-Q0859|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Sessiz%20oturun%20ve%20bir%20%C5%9Feye%20dokunmay%C4%B1n.)
^tr-Q0859-answer

**tr-Q0860** — Sessiz oturun ve bir şeye dokunmayın.

Sit still and don't touch anything.

Expected form: **ve**

Why: Clause linking. [[Turkish#^tr-Q0860|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Sessiz%20oturun%20ve%20bir%20%C5%9Feye%20dokunmay%C4%B1n.)
^tr-Q0860-answer

**tr-Q0861** — Pizza yapmada çok iyi değilim ama Tom iyidir.

I'm not very good at making pizza, but Tom is.

Expected form: **ama**

Why: Clause linking. [[Turkish#^tr-Q0861|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Pizza%20yapmada%20%C3%A7ok%20iyi%20de%C4%9Filim%20ama%20Tom%20iyidir.)
^tr-Q0861-answer

**tr-Q0862** — Pizza yapmada çok iyi değilim ama Tom iyidir.

I'm not very good at making pizza, but Tom is.

Why: Clause linking. [[Turkish#^tr-Q0862|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Pizza%20yapmada%20%C3%A7ok%20iyi%20de%C4%9Filim%20ama%20Tom%20iyidir.)
^tr-Q0862-answer

**tr-Q0863** — Sendika ve yönetim arasındaki anlaşmazlık bir greve yol açabilir.

The disagreement between the union and management could lead to a strike.

Why: Clause linking. [[Turkish#^tr-Q0863|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Sendika%20ve%20y%C3%B6netim%20aras%C4%B1ndaki%20anla%C5%9Fmazl%C4%B1k%20bir%20greve%20yol%20a%C3%A7abilir.)
^tr-Q0863-answer

**tr-Q0864** — Sendika ve yönetim arasındaki anlaşmazlık bir greve yol açabilir.

The disagreement between the union and management could lead to a strike.

Connectors mark cause, contrast and coordination. Turkish also uses suffix-based non-finite clauses extensively; do not assume every English connector needs a separate Turkish word.

Why: Clause linking. [[Turkish#^tr-Q0864|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Sendika%20ve%20y%C3%B6netim%20aras%C4%B1ndaki%20anla%C5%9Fmazl%C4%B1k%20bir%20greve%20yol%20a%C3%A7abilir.)
^tr-Q0864-answer

**tr-Q0865** — Tom hızla çekmeceyi açtı ve bir silah çıkardı.

Tom quickly opened the drawer and pulled out a gun.

Expected form: **ve**

Why: Clause linking. [[Turkish#^tr-Q0865|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20h%C4%B1zla%20%C3%A7ekmeceyi%20a%C3%A7t%C4%B1%20ve%20bir%20silah%20%C3%A7%C4%B1kard%C4%B1.)
^tr-Q0865-answer

**tr-Q0866** — Tom hızla çekmeceyi açtı ve bir silah çıkardı.

Tom quickly opened the drawer and pulled out a gun.

Expected form: **ve**

Why: Clause linking. [[Turkish#^tr-Q0866|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20h%C4%B1zla%20%C3%A7ekmeceyi%20a%C3%A7t%C4%B1%20ve%20bir%20silah%20%C3%A7%C4%B1kard%C4%B1.)
^tr-Q0866-answer

**tr-Q0867** — Biz oldukça önemsizdik ama buna rağmen müthiştik.

We're quite insignificant, but awesome nevertheless.

Expected form: **ama**

Why: Clause linking. [[Turkish#^tr-Q0867|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Biz%20olduk%C3%A7a%20%C3%B6nemsizdik%20ama%20buna%20ra%C4%9Fmen%20m%C3%BCthi%C5%9Ftik.)
^tr-Q0867-answer

**tr-Q0868** — Biz oldukça önemsizdik ama buna rağmen müthiştik.

We're quite insignificant, but awesome nevertheless.

Why: Clause linking. [[Turkish#^tr-Q0868|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Biz%20olduk%C3%A7a%20%C3%B6nemsizdik%20ama%20buna%20ra%C4%9Fmen%20m%C3%BCthi%C5%9Ftik.)
^tr-Q0868-answer

**tr-Q0869** — Tom hasta değildi, ama Mary hastaydı.

Tom wasn't sick, but Mary was.

Why: Clause linking. [[Turkish#^tr-Q0869|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20hasta%20de%C4%9Fildi%2C%20ama%20Mary%20hastayd%C4%B1.)
^tr-Q0869-answer

**tr-Q0870** — Tom hasta değildi, ama Mary hastaydı.

Tom wasn't sick, but Mary was.

Connectors mark cause, contrast and coordination. Turkish also uses suffix-based non-finite clauses extensively; do not assume every English connector needs a separate Turkish word.

Why: Clause linking. [[Turkish#^tr-Q0870|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20hasta%20de%C4%9Fildi%2C%20ama%20Mary%20hastayd%C4%B1.)
^tr-Q0870-answer

**tr-Q0871** — Volkan dışarıya alevlerini ve dumanlarını güçlü bir şekilde fırlattı.

The volcano is belching out flames and smoke.

Expected form: **ve**

Why: Clause linking. [[Turkish#^tr-Q0871|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Volkan%20d%C4%B1%C5%9Far%C4%B1ya%20alevlerini%20ve%20dumanlar%C4%B1n%C4%B1%20g%C3%BC%C3%A7l%C3%BC%20bir%20%C5%9Fekilde%20f%C4%B1rlatt%C4%B1.)
^tr-Q0871-answer

**tr-Q0872** — Volkan dışarıya alevlerini ve dumanlarını güçlü bir şekilde fırlattı.

The volcano is belching out flames and smoke.

Expected form: **ve**

Why: Clause linking. [[Turkish#^tr-Q0872|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Volkan%20d%C4%B1%C5%9Far%C4%B1ya%20alevlerini%20ve%20dumanlar%C4%B1n%C4%B1%20g%C3%BC%C3%A7l%C3%BC%20bir%20%C5%9Fekilde%20f%C4%B1rlatt%C4%B1.)
^tr-Q0872-answer

**tr-Q0873** — Git ve onunla konuş Tom . Neyden korkuyorsun?

Go and talk to her, Tom. What are you afraid of?

Expected form: **ve**

Why: Clause linking. [[Turkish#^tr-Q0873|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Git%20ve%20onunla%20konu%C5%9F%20Tom%20.%20Neyden%20korkuyorsun%3F)
^tr-Q0873-answer

**tr-Q0874** — Git ve onunla konuş Tom . Neyden korkuyorsun?

Go and talk to her, Tom. What are you afraid of?

Why: Clause linking. [[Turkish#^tr-Q0874|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Git%20ve%20onunla%20konu%C5%9F%20Tom%20.%20Neyden%20korkuyorsun%3F)
^tr-Q0874-answer

**tr-Q0875** — Anahtarı paspasın altında ve yakındaki saksının içinde aradım.

I looked for the key under the welcome mat and in the nearby flower pot.

Why: Clause linking. [[Turkish#^tr-Q0875|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Anahtar%C4%B1%20paspas%C4%B1n%20alt%C4%B1nda%20ve%20yak%C4%B1ndaki%20saks%C4%B1n%C4%B1n%20i%C3%A7inde%20arad%C4%B1m.)
^tr-Q0875-answer

**tr-Q0876** — Anahtarı paspasın altında ve yakındaki saksının içinde aradım.

I looked for the key under the welcome mat and in the nearby flower pot.

Connectors mark cause, contrast and coordination. Turkish also uses suffix-based non-finite clauses extensively; do not assume every English connector needs a separate Turkish word.

Why: Clause linking. [[Turkish#^tr-Q0876|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Anahtar%C4%B1%20paspas%C4%B1n%20alt%C4%B1nda%20ve%20yak%C4%B1ndaki%20saks%C4%B1n%C4%B1n%20i%C3%A7inde%20arad%C4%B1m.)
^tr-Q0876-answer

**tr-Q0877** — Bahçede, elma ağaçları, erikler, kirazlar, ahududu, bektaşi üzümü ve kuş üzümü vardır.

In the garden, there are apple trees, plums, cherries, raspberries, gooseberries, and currants.

Expected form: **ve**

Why: Clause linking. [[Turkish#^tr-Q0877|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bah%C3%A7ede%2C%20elma%20a%C4%9Fa%C3%A7lar%C4%B1%2C%20erikler%2C%20kirazlar%2C%20ahududu%2C%20bekta%C5%9Fi%20%C3%BCz%C3%BCm%C3%BC%20ve%20ku%C5%9F%20%C3%BCz%C3%BCm%C3%BC%20vard%C4%B1r.)
^tr-Q0877-answer

**tr-Q0878** — Bahçede, elma ağaçları, erikler, kirazlar, ahududu, bektaşi üzümü ve kuş üzümü vardır.

In the garden, there are apple trees, plums, cherries, raspberries, gooseberries, and currants.

Expected form: **ve**

Why: Clause linking. [[Turkish#^tr-Q0878|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bah%C3%A7ede%2C%20elma%20a%C4%9Fa%C3%A7lar%C4%B1%2C%20erikler%2C%20kirazlar%2C%20ahududu%2C%20bekta%C5%9Fi%20%C3%BCz%C3%BCm%C3%BC%20ve%20ku%C5%9F%20%C3%BCz%C3%BCm%C3%BC%20vard%C4%B1r.)
^tr-Q0878-answer

**tr-Q0879** — Tom Mary'ye bir öpücük verdi ve arabadan indi.

Tom gave Mary a kiss and got out of the car.

Expected form: **ve**

Why: Clause linking. [[Turkish#^tr-Q0879|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20Mary%27ye%20bir%20%C3%B6p%C3%BCc%C3%BCk%20verdi%20ve%20arabadan%20indi.)
^tr-Q0879-answer

**tr-Q0880** — Tom Mary'ye bir öpücük verdi ve arabadan indi.

Tom gave Mary a kiss and got out of the car.

Why: Clause linking. [[Turkish#^tr-Q0880|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20Mary%27ye%20bir%20%C3%B6p%C3%BCc%C3%BCk%20verdi%20ve%20arabadan%20indi.)
^tr-Q0880-answer

**tr-Q0881** — Tom ve Mary birbirleriyle genellikle Fransızca konuşurlar.

Tom and Mary usually speak French to each other.

Why: Clause linking. [[Turkish#^tr-Q0881|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20ve%20Mary%20birbirleriyle%20genellikle%20Frans%C4%B1zca%20konu%C5%9Furlar.)
^tr-Q0881-answer

**tr-Q0882** — Tom ve Mary birbirleriyle genellikle Fransızca konuşurlar.

Tom and Mary usually speak French to each other.

Connectors mark cause, contrast and coordination. Turkish also uses suffix-based non-finite clauses extensively; do not assume every English connector needs a separate Turkish word.

Why: Clause linking. [[Turkish#^tr-Q0882|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20ve%20Mary%20birbirleriyle%20genellikle%20Frans%C4%B1zca%20konu%C5%9Furlar.)
^tr-Q0882-answer

**tr-Q0883** — Gabriel sıcak çorba ve biraz şerinin dışında bir şey almadı.

Gabriel took nothing but the hot soup and a little sherry.

Expected form: **ve**

Why: Clause linking. [[Turkish#^tr-Q0883|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Gabriel%20s%C4%B1cak%20%C3%A7orba%20ve%20biraz%20%C5%9Ferinin%20d%C4%B1%C5%9F%C4%B1nda%20bir%20%C5%9Fey%20almad%C4%B1.)
^tr-Q0883-answer

**tr-Q0884** — Gabriel sıcak çorba ve biraz şerinin dışında bir şey almadı.

Gabriel took nothing but the hot soup and a little sherry.

Expected form: **ve**

Why: Clause linking. [[Turkish#^tr-Q0884|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Gabriel%20s%C4%B1cak%20%C3%A7orba%20ve%20biraz%20%C5%9Ferinin%20d%C4%B1%C5%9F%C4%B1nda%20bir%20%C5%9Fey%20almad%C4%B1.)
^tr-Q0884-answer

**tr-Q0885** — Tom ve Mary yalnız değiller.

Tom and Mary aren't alone.

Expected form: **ve**

Why: Clause linking. [[Turkish#^tr-Q0885|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20ve%20Mary%20yaln%C4%B1z%20de%C4%9Filler.)
^tr-Q0885-answer

**tr-Q0886** — Tom ve Mary yalnız değiller.

Tom and Mary aren't alone.

Why: Clause linking. [[Turkish#^tr-Q0886|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20ve%20Mary%20yaln%C4%B1z%20de%C4%9Filler.)
^tr-Q0886-answer

**tr-Q0887** — Sen ve Tom dün ne yapıyordunuz?

What were you and Tom doing yesterday?

Why: Clause linking. [[Turkish#^tr-Q0887|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Sen%20ve%20Tom%20d%C3%BCn%20ne%20yap%C4%B1yordunuz%3F)
^tr-Q0887-answer

**tr-Q0888** — Sen ve Tom dün ne yapıyordunuz?

What were you and Tom doing yesterday?

Connectors mark cause, contrast and coordination. Turkish also uses suffix-based non-finite clauses extensively; do not assume every English connector needs a separate Turkish word.

Why: Clause linking. [[Turkish#^tr-Q0888|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Sen%20ve%20Tom%20d%C3%BCn%20ne%20yap%C4%B1yordunuz%3F)
^tr-Q0888-answer

**tr-Q0889** — Lezzetli yiyecek ve içecekler servis edildi.

Delicious refreshments were served.

Expected form: **ve**

Why: Clause linking. [[Turkish#^tr-Q0889|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Lezzetli%20yiyecek%20ve%20i%C3%A7ecekler%20servis%20edildi.)
^tr-Q0889-answer

**tr-Q0890** — Lezzetli yiyecek ve içecekler servis edildi.

Delicious refreshments were served.

Expected form: **ve**

Why: Clause linking. [[Turkish#^tr-Q0890|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Lezzetli%20yiyecek%20ve%20i%C3%A7ecekler%20servis%20edildi.)
^tr-Q0890-answer

**tr-Q0891** — İnekler antibiyotik ve hormonla beslenirler.

The cows are fed antibiotics and hormones.

Expected form: **ve**

Why: Clause linking. [[Turkish#^tr-Q0891|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=%C4%B0nekler%20antibiyotik%20ve%20hormonla%20beslenirler.)
^tr-Q0891-answer

**tr-Q0892** — İnekler antibiyotik ve hormonla beslenirler.

The cows are fed antibiotics and hormones.

Why: Clause linking. [[Turkish#^tr-Q0892|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=%C4%B0nekler%20antibiyotik%20ve%20hormonla%20beslenirler.)
^tr-Q0892-answer

**tr-Q0893** — Tom, Mary'nin kız kardeşi ile evlendi ve Mary, Tom'un erkek kardeşiyle evlendi.

Tom married Mary's sister and Mary married Tom's brother.

Why: Clause linking. [[Turkish#^tr-Q0893|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%2C%20Mary%27nin%20k%C4%B1z%20karde%C5%9Fi%20ile%20evlendi%20ve%20Mary%2C%20Tom%27un%20erkek%20karde%C5%9Fiyle%20evlendi.)
^tr-Q0893-answer

**tr-Q0894** — Tom, Mary'nin kız kardeşi ile evlendi ve Mary, Tom'un erkek kardeşiyle evlendi.

Tom married Mary's sister and Mary married Tom's brother.

Connectors mark cause, contrast and coordination. Turkish also uses suffix-based non-finite clauses extensively; do not assume every English connector needs a separate Turkish word.

Why: Clause linking. [[Turkish#^tr-Q0894|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%2C%20Mary%27nin%20k%C4%B1z%20karde%C5%9Fi%20ile%20evlendi%20ve%20Mary%2C%20Tom%27un%20erkek%20karde%C5%9Fiyle%20evlendi.)
^tr-Q0894-answer

**tr-Q0895** — Sami ve Leyla konuşuyorlardı.

Sami and Layla were talking.

Expected form: **ve**

Why: Clause linking. [[Turkish#^tr-Q0895|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Sami%20ve%20Leyla%20konu%C5%9Fuyorlard%C4%B1.)
^tr-Q0895-answer

**tr-Q0896** — Sami ve Leyla konuşuyorlardı.

Sami and Layla were talking.

Expected form: **ve**

Why: Clause linking. [[Turkish#^tr-Q0896|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Sami%20ve%20Leyla%20konu%C5%9Fuyorlard%C4%B1.)
^tr-Q0896-answer

**tr-Q0897** — O hayal kırıklığına uğradı ve öyle olduğu için kendine kızdı.

She was disappointed, and angry with herself for being so.

Expected form: **ve**

Why: Clause linking. [[Turkish#^tr-Q0897|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=O%20hayal%20k%C4%B1r%C4%B1kl%C4%B1%C4%9F%C4%B1na%20u%C4%9Frad%C4%B1%20ve%20%C3%B6yle%20oldu%C4%9Fu%20i%C3%A7in%20kendine%20k%C4%B1zd%C4%B1.)
^tr-Q0897-answer

**tr-Q0898** — O hayal kırıklığına uğradı ve öyle olduğu için kendine kızdı.

She was disappointed, and angry with herself for being so.

Why: Clause linking. [[Turkish#^tr-Q0898|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=O%20hayal%20k%C4%B1r%C4%B1kl%C4%B1%C4%9F%C4%B1na%20u%C4%9Frad%C4%B1%20ve%20%C3%B6yle%20oldu%C4%9Fu%20i%C3%A7in%20kendine%20k%C4%B1zd%C4%B1.)
^tr-Q0898-answer

**tr-Q0899** — Tom ve ben parayı nasıl harcayacağımız hakkında konuştuk.

Tom and I talked about how we were going to spend the money.

Why: Clause linking. [[Turkish#^tr-Q0899|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20ve%20ben%20paray%C4%B1%20nas%C4%B1l%20harcayaca%C4%9F%C4%B1m%C4%B1z%20hakk%C4%B1nda%20konu%C5%9Ftuk.)
^tr-Q0899-answer

**tr-Q0900** — Tom ve ben parayı nasıl harcayacağımız hakkında konuştuk.

Tom and I talked about how we were going to spend the money.

Connectors mark cause, contrast and coordination. Turkish also uses suffix-based non-finite clauses extensively; do not assume every English connector needs a separate Turkish word.

Why: Clause linking. [[Turkish#^tr-Q0900|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20ve%20ben%20paray%C4%B1%20nas%C4%B1l%20harcayaca%C4%9F%C4%B1m%C4%B1z%20hakk%C4%B1nda%20konu%C5%9Ftuk.)
^tr-Q0900-answer


### Answers 901–950

**tr-Q0901** — Tom'un erkek arkadaşın olduğunu sandım.

I assumed Tom was your boyfriend.

Expected form: **olduğunu**

Why: Participles and nominal clauses. [[Turkish#^tr-Q0901|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%27un%20erkek%20arkada%C5%9F%C4%B1n%20oldu%C4%9Funu%20sand%C4%B1m.)
^tr-Q0901-answer

**tr-Q0902** — Tom'un erkek arkadaşın olduğunu sandım.

I assumed Tom was your boyfriend.

Expected form: **olduğunu**

Why: Participles and nominal clauses. [[Turkish#^tr-Q0902|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%27un%20erkek%20arkada%C5%9F%C4%B1n%20oldu%C4%9Funu%20sand%C4%B1m.)
^tr-Q0902-answer

**tr-Q0903** — Daha fazla zamana ihtiyacın olduğunu söyledin.

You said you needed more time.

Expected form: **olduğunu**

Why: Participles and nominal clauses. [[Turkish#^tr-Q0903|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Daha%20fazla%20zamana%20ihtiyac%C4%B1n%20oldu%C4%9Funu%20s%C3%B6yledin.)
^tr-Q0903-answer

**tr-Q0904** — Daha fazla zamana ihtiyacın olduğunu söyledin.

You said you needed more time.

Why: Participles and nominal clauses. [[Turkish#^tr-Q0904|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Daha%20fazla%20zamana%20ihtiyac%C4%B1n%20oldu%C4%9Funu%20s%C3%B6yledin.)
^tr-Q0904-answer

**tr-Q0905** — Tom başka herkesten daha akıllı olduğunu düşünüyordu.

Tom thought he was smarter than anybody else.

Why: Participles and nominal clauses. [[Turkish#^tr-Q0905|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20ba%C5%9Fka%20herkesten%20daha%20ak%C4%B1ll%C4%B1%20oldu%C4%9Funu%20d%C3%BC%C5%9F%C3%BCn%C3%BCyordu.)
^tr-Q0905-answer

**tr-Q0906** — Tom başka herkesten daha akıllı olduğunu düşünüyordu.

Tom thought he was smarter than anybody else.

Participles modify nouns before them; nominalised clauses can take possessive and case endings. The form records relationships that English often expresses in a separate relative/content clause.

Why: Participles and nominal clauses. [[Turkish#^tr-Q0906|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20ba%C5%9Fka%20herkesten%20daha%20ak%C4%B1ll%C4%B1%20oldu%C4%9Funu%20d%C3%BC%C5%9F%C3%BCn%C3%BCyordu.)
^tr-Q0906-answer

**tr-Q0907** — Ben oldukça şanslı olduğumu düşünüyorum.

I think I'm pretty lucky.

Expected form: **olduğumu**

Why: Participles and nominal clauses. [[Turkish#^tr-Q0907|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ben%20olduk%C3%A7a%20%C5%9Fansl%C4%B1%20oldu%C4%9Fumu%20d%C3%BC%C5%9F%C3%BCn%C3%BCyorum.)
^tr-Q0907-answer

**tr-Q0908** — Ben oldukça şanslı olduğumu düşünüyorum.

I think I'm pretty lucky.

Expected form: **olduğumu**

Why: Participles and nominal clauses. [[Turkish#^tr-Q0908|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ben%20olduk%C3%A7a%20%C5%9Fansl%C4%B1%20oldu%C4%9Fumu%20d%C3%BC%C5%9F%C3%BCn%C3%BCyorum.)
^tr-Q0908-answer

**tr-Q0909** — Bugün okulda ne olduğunu duydum.

I heard about what happened at school today.

Expected form: **olduğunu**

Why: Participles and nominal clauses. [[Turkish#^tr-Q0909|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bug%C3%BCn%20okulda%20ne%20oldu%C4%9Funu%20duydum.)
^tr-Q0909-answer

**tr-Q0910** — Bugün okulda ne olduğunu duydum.

I heard about what happened at school today.

Why: Participles and nominal clauses. [[Turkish#^tr-Q0910|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bug%C3%BCn%20okulda%20ne%20oldu%C4%9Funu%20duydum.)
^tr-Q0910-answer

**tr-Q0911** — Tom Boston'lu olduğunu söyledi.

Tom said he was from Boston.

Why: Participles and nominal clauses. [[Turkish#^tr-Q0911|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20Boston%27lu%20oldu%C4%9Funu%20s%C3%B6yledi.)
^tr-Q0911-answer

**tr-Q0912** — Tom Boston'lu olduğunu söyledi.

Tom said he was from Boston.

Participles modify nouns before them; nominalised clauses can take possessive and case endings. The form records relationships that English often expresses in a separate relative/content clause.

Why: Participles and nominal clauses. [[Turkish#^tr-Q0912|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20Boston%27lu%20oldu%C4%9Funu%20s%C3%B6yledi.)
^tr-Q0912-answer

**tr-Q0913** — Herkesin aç olduğunu düşündüm.

I thought everyone was hungry.

Expected form: **olduğunu**

Why: Participles and nominal clauses. [[Turkish#^tr-Q0913|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Herkesin%20a%C3%A7%20oldu%C4%9Funu%20d%C3%BC%C5%9F%C3%BCnd%C3%BCm.)
^tr-Q0913-answer

**tr-Q0914** — Herkesin aç olduğunu düşündüm.

I thought everyone was hungry.

Expected form: **olduğunu**

Why: Participles and nominal clauses. [[Turkish#^tr-Q0914|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Herkesin%20a%C3%A7%20oldu%C4%9Funu%20d%C3%BC%C5%9F%C3%BCnd%C3%BCm.)
^tr-Q0914-answer

**tr-Q0915** — Benim babam olduğunu nasıl olur da bana söyleyemezsin?

How could you not tell me that you're my father?

Expected form: **olduğunu**

Why: Participles and nominal clauses. [[Turkish#^tr-Q0915|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Benim%20babam%20oldu%C4%9Funu%20nas%C4%B1l%20olur%20da%20bana%20s%C3%B6yleyemezsin%3F)
^tr-Q0915-answer

**tr-Q0916** — Benim babam olduğunu nasıl olur da bana söyleyemezsin?

How could you not tell me that you're my father?

Why: Participles and nominal clauses. [[Turkish#^tr-Q0916|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Benim%20babam%20oldu%C4%9Funu%20nas%C4%B1l%20olur%20da%20bana%20s%C3%B6yleyemezsin%3F)
^tr-Q0916-answer

**tr-Q0917** — Tom'un bu kadar zamanını alan şeyin ne olduğunu merak ediyorum.

I wonder what's taking Tom so long.

Why: Participles and nominal clauses. [[Turkish#^tr-Q0917|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%27un%20bu%20kadar%20zaman%C4%B1n%C4%B1%20alan%20%C5%9Feyin%20ne%20oldu%C4%9Funu%20merak%20ediyorum.)
^tr-Q0917-answer

**tr-Q0918** — Tom'un bu kadar zamanını alan şeyin ne olduğunu merak ediyorum.

I wonder what's taking Tom so long.

Participles modify nouns before them; nominalised clauses can take possessive and case endings. The form records relationships that English often expresses in a separate relative/content clause.

Why: Participles and nominal clauses. [[Turkish#^tr-Q0918|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%27un%20bu%20kadar%20zaman%C4%B1n%C4%B1%20alan%20%C5%9Feyin%20ne%20oldu%C4%9Funu%20merak%20ediyorum.)
^tr-Q0918-answer

**tr-Q0919** — Onunla bir ilgim olduğunu öne sürüyorsan yanılıyorsun.

If you're suggesting that I had anything to do with, you're wrong.

Expected form: **olduğunu**

Why: Participles and nominal clauses. [[Turkish#^tr-Q0919|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Onunla%20bir%20ilgim%20oldu%C4%9Funu%20%C3%B6ne%20s%C3%BCr%C3%BCyorsan%20yan%C4%B1l%C4%B1yorsun.)
^tr-Q0919-answer

**tr-Q0920** — Onunla bir ilgim olduğunu öne sürüyorsan yanılıyorsun.

If you're suggesting that I had anything to do with, you're wrong.

Expected form: **olduğunu**

Why: Participles and nominal clauses. [[Turkish#^tr-Q0920|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Onunla%20bir%20ilgim%20oldu%C4%9Funu%20%C3%B6ne%20s%C3%BCr%C3%BCyorsan%20yan%C4%B1l%C4%B1yorsun.)
^tr-Q0920-answer

**tr-Q0921** — Mary'nin onun aptal olduğunu düşündüğünü Tom'un bildiğini sanmıyorum.

I don't think Tom knows that Mary thinks he's stupid.

Expected form: **olduğunu**

Why: Participles and nominal clauses. [[Turkish#^tr-Q0921|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Mary%27nin%20onun%20aptal%20oldu%C4%9Funu%20d%C3%BC%C5%9F%C3%BCnd%C3%BC%C4%9F%C3%BCn%C3%BC%20Tom%27un%20bildi%C4%9Fini%20sanm%C4%B1yorum.)
^tr-Q0921-answer

**tr-Q0922** — Mary'nin onun aptal olduğunu düşündüğünü Tom'un bildiğini sanmıyorum.

I don't think Tom knows that Mary thinks he's stupid.

Why: Participles and nominal clauses. [[Turkish#^tr-Q0922|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Mary%27nin%20onun%20aptal%20oldu%C4%9Funu%20d%C3%BC%C5%9F%C3%BCnd%C3%BC%C4%9F%C3%BCn%C3%BC%20Tom%27un%20bildi%C4%9Fini%20sanm%C4%B1yorum.)
^tr-Q0922-answer

**tr-Q0923** — Tom Mary'nin Tom'la evleneceğinin olası olduğunu muhtemelen düşünmedi.

Tom probably didn't think it was likely that Mary would fall in love with John.

Why: Participles and nominal clauses. [[Turkish#^tr-Q0923|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20Mary%27nin%20Tom%27la%20evlenece%C4%9Finin%20olas%C4%B1%20oldu%C4%9Funu%20muhtemelen%20d%C3%BC%C5%9F%C3%BCnmedi.)
^tr-Q0923-answer

**tr-Q0924** — Tom Mary'nin Tom'la evleneceğinin olası olduğunu muhtemelen düşünmedi.

Tom probably didn't think it was likely that Mary would fall in love with John.

Participles modify nouns before them; nominalised clauses can take possessive and case endings. The form records relationships that English often expresses in a separate relative/content clause.

Why: Participles and nominal clauses. [[Turkish#^tr-Q0924|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20Mary%27nin%20Tom%27la%20evlenece%C4%9Finin%20olas%C4%B1%20oldu%C4%9Funu%20muhtemelen%20d%C3%BC%C5%9F%C3%BCnmedi.)
^tr-Q0924-answer

**tr-Q0925** — Tom ayrılmaya hazır olduğunu söyledi.

Tom said he's ready to leave.

Expected form: **olduğunu**

Why: Participles and nominal clauses. [[Turkish#^tr-Q0925|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20ayr%C4%B1lmaya%20haz%C4%B1r%20oldu%C4%9Funu%20s%C3%B6yledi.)
^tr-Q0925-answer

**tr-Q0926** — Tom ayrılmaya hazır olduğunu söyledi.

Tom said he's ready to leave.

Expected form: **olduğunu**

Why: Participles and nominal clauses. [[Turkish#^tr-Q0926|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20ayr%C4%B1lmaya%20haz%C4%B1r%20oldu%C4%9Funu%20s%C3%B6yledi.)
^tr-Q0926-answer

**tr-Q0927** — Biri nasıl Tom'un iyi bir patron olduğunu düşünebilir?

How can anyone think that Tom is a good boss?

Expected form: **olduğunu**

Why: Participles and nominal clauses. [[Turkish#^tr-Q0927|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Biri%20nas%C4%B1l%20Tom%27un%20iyi%20bir%20patron%20oldu%C4%9Funu%20d%C3%BC%C5%9F%C3%BCnebilir%3F)
^tr-Q0927-answer

**tr-Q0928** — Biri nasıl Tom'un iyi bir patron olduğunu düşünebilir?

How can anyone think that Tom is a good boss?

Why: Participles and nominal clauses. [[Turkish#^tr-Q0928|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Biri%20nas%C4%B1l%20Tom%27un%20iyi%20bir%20patron%20oldu%C4%9Funu%20d%C3%BC%C5%9F%C3%BCnebilir%3F)
^tr-Q0928-answer

**tr-Q0929** — Tom'un sana söyleyeceği bir şeyi olduğunu düşünüyordum.

I thought Tom had something to tell you.

Why: Participles and nominal clauses. [[Turkish#^tr-Q0929|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%27un%20sana%20s%C3%B6yleyece%C4%9Fi%20bir%20%C5%9Feyi%20oldu%C4%9Funu%20d%C3%BC%C5%9F%C3%BCn%C3%BCyordum.)
^tr-Q0929-answer

**tr-Q0930** — Tom'un sana söyleyeceği bir şeyi olduğunu düşünüyordum.

I thought Tom had something to tell you.

Participles modify nouns before them; nominalised clauses can take possessive and case endings. The form records relationships that English often expresses in a separate relative/content clause.

Why: Participles and nominal clauses. [[Turkish#^tr-Q0930|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%27un%20sana%20s%C3%B6yleyece%C4%9Fi%20bir%20%C5%9Feyi%20oldu%C4%9Funu%20d%C3%BC%C5%9F%C3%BCn%C3%BCyordum.)
^tr-Q0930-answer

**tr-Q0931** — Tom onun doğru olduğunu biliyor.

Tom knows that's true.

Expected form: **olduğunu**

Why: Participles and nominal clauses. [[Turkish#^tr-Q0931|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20onun%20do%C4%9Fru%20oldu%C4%9Funu%20biliyor.)
^tr-Q0931-answer

**tr-Q0932** — Tom onun doğru olduğunu biliyor.

Tom knows that's true.

Expected form: **olduğunu**

Why: Participles and nominal clauses. [[Turkish#^tr-Q0932|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20onun%20do%C4%9Fru%20oldu%C4%9Funu%20biliyor.)
^tr-Q0932-answer

**tr-Q0933** — Tom ne olduğunu görebildi.

Tom could see what was happening.

Expected form: **olduğunu**

Why: Participles and nominal clauses. [[Turkish#^tr-Q0933|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20ne%20oldu%C4%9Funu%20g%C3%B6rebildi.)
^tr-Q0933-answer

**tr-Q0934** — Tom ne olduğunu görebildi.

Tom could see what was happening.

Why: Participles and nominal clauses. [[Turkish#^tr-Q0934|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20ne%20oldu%C4%9Funu%20g%C3%B6rebildi.)
^tr-Q0934-answer

**tr-Q0935** — Fadıl burada değil. Onun nerede olduğunu biliyor musun?

Fadil isn't here. Do you know where he is?

Why: Participles and nominal clauses. [[Turkish#^tr-Q0935|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Fad%C4%B1l%20burada%20de%C4%9Fil.%20Onun%20nerede%20oldu%C4%9Funu%20biliyor%20musun%3F)
^tr-Q0935-answer

**tr-Q0936** — Fadıl burada değil. Onun nerede olduğunu biliyor musun?

Fadil isn't here. Do you know where he is?

Participles modify nouns before them; nominalised clauses can take possessive and case endings. The form records relationships that English often expresses in a separate relative/content clause.

Why: Participles and nominal clauses. [[Turkish#^tr-Q0936|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Fad%C4%B1l%20burada%20de%C4%9Fil.%20Onun%20nerede%20oldu%C4%9Funu%20biliyor%20musun%3F)
^tr-Q0936-answer

**tr-Q0937** — Tom Mary'ye John'un yatakta hasta olduğunu söyledi.

Tom told Mary that John was sick in bed.

Expected form: **olduğunu**

Why: Participles and nominal clauses. [[Turkish#^tr-Q0937|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20Mary%27ye%20John%27un%20yatakta%20hasta%20oldu%C4%9Funu%20s%C3%B6yledi.)
^tr-Q0937-answer

**tr-Q0938** — Tom Mary'ye John'un yatakta hasta olduğunu söyledi.

Tom told Mary that John was sick in bed.

Expected form: **olduğunu**

Why: Participles and nominal clauses. [[Turkish#^tr-Q0938|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20Mary%27ye%20John%27un%20yatakta%20hasta%20oldu%C4%9Funu%20s%C3%B6yledi.)
^tr-Q0938-answer

**tr-Q0939** — Tom gururunu yutmak ve yardıma ihtiyacı olduğunu itiraf etmek zorunda kaldı.

Tom had to swallow his pride and admit that he needed help.

Expected form: **olduğunu**

Why: Participles and nominal clauses. [[Turkish#^tr-Q0939|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20gururunu%20yutmak%20ve%20yard%C4%B1ma%20ihtiyac%C4%B1%20oldu%C4%9Funu%20itiraf%20etmek%20zorunda%20kald%C4%B1.)
^tr-Q0939-answer

**tr-Q0940** — Tom gururunu yutmak ve yardıma ihtiyacı olduğunu itiraf etmek zorunda kaldı.

Tom had to swallow his pride and admit that he needed help.

Why: Participles and nominal clauses. [[Turkish#^tr-Q0940|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20gururunu%20yutmak%20ve%20yard%C4%B1ma%20ihtiyac%C4%B1%20oldu%C4%9Funu%20itiraf%20etmek%20zorunda%20kald%C4%B1.)
^tr-Q0940-answer

**tr-Q0941** — Nereye olduğunu sormak istemediğin uzak bir yere gidiyorum.

I am going to a distant place, you don't want to ask where.

Why: Participles and nominal clauses. [[Turkish#^tr-Q0941|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Nereye%20oldu%C4%9Funu%20sormak%20istemedi%C4%9Fin%20uzak%20bir%20yere%20gidiyorum.)
^tr-Q0941-answer

**tr-Q0942** — Nereye olduğunu sormak istemediğin uzak bir yere gidiyorum.

I am going to a distant place, you don't want to ask where.

Participles modify nouns before them; nominalised clauses can take possessive and case endings. The form records relationships that English often expresses in a separate relative/content clause.

Why: Participles and nominal clauses. [[Turkish#^tr-Q0942|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Nereye%20oldu%C4%9Funu%20sormak%20istemedi%C4%9Fin%20uzak%20bir%20yere%20gidiyorum.)
^tr-Q0942-answer

**tr-Q0943** — Bir seçeneğin olduğunu sanmıyorum.

I don't think you have a choice.

Expected form: **olduğunu**

Why: Participles and nominal clauses. [[Turkish#^tr-Q0943|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bir%20se%C3%A7ene%C4%9Fin%20oldu%C4%9Funu%20sanm%C4%B1yorum.)
^tr-Q0943-answer

**tr-Q0944** — Bir seçeneğin olduğunu sanmıyorum.

I don't think you have a choice.

Expected form: **olduğunu**

Why: Participles and nominal clauses. [[Turkish#^tr-Q0944|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bir%20se%C3%A7ene%C4%9Fin%20oldu%C4%9Funu%20sanm%C4%B1yorum.)
^tr-Q0944-answer

**tr-Q0945** — Ona ne olduğunu bilmek istemezsiniz.

You don't want to know what happened to her.

Expected form: **olduğunu**

Why: Participles and nominal clauses. [[Turkish#^tr-Q0945|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ona%20ne%20oldu%C4%9Funu%20bilmek%20istemezsiniz.)
^tr-Q0945-answer

**tr-Q0946** — Ona ne olduğunu bilmek istemezsiniz.

You don't want to know what happened to her.

Why: Participles and nominal clauses. [[Turkish#^tr-Q0946|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ona%20ne%20oldu%C4%9Funu%20bilmek%20istemezsiniz.)
^tr-Q0946-answer

**tr-Q0947** — Tom orada ne olduğunu bilmiyor.

Tom doesn't know what's in there.

Why: Participles and nominal clauses. [[Turkish#^tr-Q0947|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20orada%20ne%20oldu%C4%9Funu%20bilmiyor.)
^tr-Q0947-answer

**tr-Q0948** — Tom orada ne olduğunu bilmiyor.

Tom doesn't know what's in there.

Participles modify nouns before them; nominalised clauses can take possessive and case endings. The form records relationships that English often expresses in a separate relative/content clause.

Why: Participles and nominal clauses. [[Turkish#^tr-Q0948|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20orada%20ne%20oldu%C4%9Funu%20bilmiyor.)
^tr-Q0948-answer

**tr-Q0949** — Sadece bir şey yapmadan durmayacağım ve ne olduğunu görmeyeceğim.

I'm not just going to wait around and see what happens.

Expected form: **olduğunu**

Why: Participles and nominal clauses. [[Turkish#^tr-Q0949|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Sadece%20bir%20%C5%9Fey%20yapmadan%20durmayaca%C4%9F%C4%B1m%20ve%20ne%20oldu%C4%9Funu%20g%C3%B6rmeyece%C4%9Fim.)
^tr-Q0949-answer

**tr-Q0950** — Sadece bir şey yapmadan durmayacağım ve ne olduğunu görmeyeceğim.

I'm not just going to wait around and see what happens.

Expected form: **olduğunu**

Why: Participles and nominal clauses. [[Turkish#^tr-Q0950|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Sadece%20bir%20%C5%9Fey%20yapmadan%20durmayaca%C4%9F%C4%B1m%20ve%20ne%20oldu%C4%9Funu%20g%C3%B6rmeyece%C4%9Fim.)
^tr-Q0950-answer


### Answers 951–1000

**tr-Q0951** — Lütfen dürüst davran.

Please behave honestly.

Expected form: **Lütfen**

Why: Ability, necessity and courtesy. [[Turkish#^tr-Q0951|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=L%C3%BCtfen%20d%C3%BCr%C3%BCst%20davran.)
^tr-Q0951-answer

**tr-Q0952** — Lütfen dürüst davran.

Please behave honestly.

Why: Ability, necessity and courtesy. [[Turkish#^tr-Q0952|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=L%C3%BCtfen%20d%C3%BCr%C3%BCst%20davran.)
^tr-Q0952-answer

**tr-Q0953** — O, takımımızdaki en değerli oyuncudur.

He is the most valuable player in our team.

Why: Ability, necessity and courtesy. [[Turkish#^tr-Q0953|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=O%2C%20tak%C4%B1m%C4%B1m%C4%B1zdaki%20en%20de%C4%9Ferli%20oyuncudur.)
^tr-Q0953-answer

**tr-Q0954** — O, takımımızdaki en değerli oyuncudur.

He is the most valuable player in our team.

Lütfen marks a polite request; belki limits certainty; gerek/lazım often express necessity. Daha/en participate in comparison and degree. Use the full construction to identify their role.

Why: Ability, necessity and courtesy. [[Turkish#^tr-Q0954|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=O%2C%20tak%C4%B1m%C4%B1m%C4%B1zdaki%20en%20de%C4%9Ferli%20oyuncudur.)
^tr-Q0954-answer

**tr-Q0955** — Japonca, İngilizceden daha zordur.

Japanese is harder than English.

Expected form: **daha**

Why: Ability, necessity and courtesy. [[Turkish#^tr-Q0955|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Japonca%2C%20%C4%B0ngilizceden%20daha%20zordur.)
^tr-Q0955-answer

**tr-Q0956** — Japonca, İngilizceden daha zordur.

Japanese is harder than English.

Expected form: **daha**

Why: Ability, necessity and courtesy. [[Turkish#^tr-Q0956|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Japonca%2C%20%C4%B0ngilizceden%20daha%20zordur.)
^tr-Q0956-answer

**tr-Q0957** — Tavuğun en sevdiğin kısmı hangisi?

What's your favorite part of the chicken?

Expected form: **en**

Why: Ability, necessity and courtesy. [[Turkish#^tr-Q0957|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tavu%C4%9Fun%20en%20sevdi%C4%9Fin%20k%C4%B1sm%C4%B1%20hangisi%3F)
^tr-Q0957-answer

**tr-Q0958** — Tavuğun en sevdiğin kısmı hangisi?

What's your favorite part of the chicken?

Why: Ability, necessity and courtesy. [[Turkish#^tr-Q0958|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tavu%C4%9Fun%20en%20sevdi%C4%9Fin%20k%C4%B1sm%C4%B1%20hangisi%3F)
^tr-Q0958-answer

**tr-Q0959** — Daha büyük sorunlarımız var.

We have bigger problems.

Why: Ability, necessity and courtesy. [[Turkish#^tr-Q0959|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Daha%20b%C3%BCy%C3%BCk%20sorunlar%C4%B1m%C4%B1z%20var.)
^tr-Q0959-answer

**tr-Q0960** — Daha büyük sorunlarımız var.

We have bigger problems.

Lütfen marks a polite request; belki limits certainty; gerek/lazım often express necessity. Daha/en participate in comparison and degree. Use the full construction to identify their role.

Why: Ability, necessity and courtesy. [[Turkish#^tr-Q0960|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Daha%20b%C3%BCy%C3%BCk%20sorunlar%C4%B1m%C4%B1z%20var.)
^tr-Q0960-answer

**tr-Q0961** — Daha ayrıntılı bir haritaya ihtiyacım var.

I need a more detailed map.

Expected form: **Daha**

Why: Ability, necessity and courtesy. [[Turkish#^tr-Q0961|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Daha%20ayr%C4%B1nt%C4%B1l%C4%B1%20bir%20haritaya%20ihtiyac%C4%B1m%20var.)
^tr-Q0961-answer

**tr-Q0962** — Daha ayrıntılı bir haritaya ihtiyacım var.

I need a more detailed map.

Expected form: **Daha**

Why: Ability, necessity and courtesy. [[Turkish#^tr-Q0962|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Daha%20ayr%C4%B1nt%C4%B1l%C4%B1%20bir%20haritaya%20ihtiyac%C4%B1m%20var.)
^tr-Q0962-answer

**tr-Q0963** — Tom kilo vermede Mary'den daha başarılıydı.

Tom has been more successful at losing weight than Mary.

Expected form: **daha**

Why: Ability, necessity and courtesy. [[Turkish#^tr-Q0963|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20kilo%20vermede%20Mary%27den%20daha%20ba%C5%9Far%C4%B1l%C4%B1yd%C4%B1.)
^tr-Q0963-answer

**tr-Q0964** — Tom kilo vermede Mary'den daha başarılıydı.

Tom has been more successful at losing weight than Mary.

Why: Ability, necessity and courtesy. [[Turkish#^tr-Q0964|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%20kilo%20vermede%20Mary%27den%20daha%20ba%C5%9Far%C4%B1l%C4%B1yd%C4%B1.)
^tr-Q0964-answer

**tr-Q0965** — Bu beklenenden daha iyi.

This is better than expected.

Why: Ability, necessity and courtesy. [[Turkish#^tr-Q0965|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bu%20beklenenden%20daha%20iyi.)
^tr-Q0965-answer

**tr-Q0966** — Bu beklenenden daha iyi.

This is better than expected.

Lütfen marks a polite request; belki limits certainty; gerek/lazım often express necessity. Daha/en participate in comparison and degree. Use the full construction to identify their role.

Why: Ability, necessity and courtesy. [[Turkish#^tr-Q0966|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bu%20beklenenden%20daha%20iyi.)
^tr-Q0966-answer

**tr-Q0967** — Lütfen onu nasıl yapmam gerektiğini bana göster.

Please show me how I have to do it.

Expected form: **Lütfen**

Why: Ability, necessity and courtesy. [[Turkish#^tr-Q0967|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=L%C3%BCtfen%20onu%20nas%C4%B1l%20yapmam%20gerekti%C4%9Fini%20bana%20g%C3%B6ster.)
^tr-Q0967-answer

**tr-Q0968** — Lütfen onu nasıl yapmam gerektiğini bana göster.

Please show me how I have to do it.

Expected form: **Lütfen**

Why: Ability, necessity and courtesy. [[Turkish#^tr-Q0968|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=L%C3%BCtfen%20onu%20nas%C4%B1l%20yapmam%20gerekti%C4%9Fini%20bana%20g%C3%B6ster.)
^tr-Q0968-answer

**tr-Q0969** — Sanırım Tom ondan daha akıllı.

I think Tom is smarter than that.

Expected form: **daha**

Why: Ability, necessity and courtesy. [[Turkish#^tr-Q0969|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=San%C4%B1r%C4%B1m%20Tom%20ondan%20daha%20ak%C4%B1ll%C4%B1.)
^tr-Q0969-answer

**tr-Q0970** — Sanırım Tom ondan daha akıllı.

I think Tom is smarter than that.

Why: Ability, necessity and courtesy. [[Turkish#^tr-Q0970|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=San%C4%B1r%C4%B1m%20Tom%20ondan%20daha%20ak%C4%B1ll%C4%B1.)
^tr-Q0970-answer

**tr-Q0971** — İki bira daha lütfen!

Two more beers, please!

Why: Ability, necessity and courtesy. [[Turkish#^tr-Q0971|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=%C4%B0ki%20bira%20daha%20l%C3%BCtfen%21)
^tr-Q0971-answer

**tr-Q0972** — İki bira daha lütfen!

Two more beers, please!

Lütfen marks a polite request; belki limits certainty; gerek/lazım often express necessity. Daha/en participate in comparison and degree. Use the full construction to identify their role.

Why: Ability, necessity and courtesy. [[Turkish#^tr-Q0972|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=%C4%B0ki%20bira%20daha%20l%C3%BCtfen%21)
^tr-Q0972-answer

**tr-Q0973** — Lütfen benim için not alın.

Please take a message for me.

Expected form: **Lütfen**

Why: Ability, necessity and courtesy. [[Turkish#^tr-Q0973|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=L%C3%BCtfen%20benim%20i%C3%A7in%20not%20al%C4%B1n.)
^tr-Q0973-answer

**tr-Q0974** — Lütfen benim için not alın.

Please take a message for me.

Expected form: **Lütfen**

Why: Ability, necessity and courtesy. [[Turkish#^tr-Q0974|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=L%C3%BCtfen%20benim%20i%C3%A7in%20not%20al%C4%B1n.)
^tr-Q0974-answer

**tr-Q0975** — Sanırım itiraf etmek istediğinden daha iyi zaman geçiriyorsun.

I think you're having a better time than you want to admit.

Expected form: **daha**

Why: Ability, necessity and courtesy. [[Turkish#^tr-Q0975|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=San%C4%B1r%C4%B1m%20itiraf%20etmek%20istedi%C4%9Finden%20daha%20iyi%20zaman%20ge%C3%A7iriyorsun.)
^tr-Q0975-answer

**tr-Q0976** — Sanırım itiraf etmek istediğinden daha iyi zaman geçiriyorsun.

I think you're having a better time than you want to admit.

Why: Ability, necessity and courtesy. [[Turkish#^tr-Q0976|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=San%C4%B1r%C4%B1m%20itiraf%20etmek%20istedi%C4%9Finden%20daha%20iyi%20zaman%20ge%C3%A7iriyorsun.)
^tr-Q0976-answer

**tr-Q0977** — Ben ona daha sonra söylerim.

I'll tell him so then.

Why: Ability, necessity and courtesy. [[Turkish#^tr-Q0977|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ben%20ona%20daha%20sonra%20s%C3%B6ylerim.)
^tr-Q0977-answer

**tr-Q0978** — Ben ona daha sonra söylerim.

I'll tell him so then.

Lütfen marks a polite request; belki limits certainty; gerek/lazım often express necessity. Daha/en participate in comparison and degree. Use the full construction to identify their role.

Why: Ability, necessity and courtesy. [[Turkish#^tr-Q0978|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Ben%20ona%20daha%20sonra%20s%C3%B6ylerim.)
^tr-Q0978-answer

**tr-Q0979** — Herkes hayatları boyunca en az bir kere aşık olur.

Everybody falls in love at least once in their lives.

Expected form: **en**

Why: Ability, necessity and courtesy. [[Turkish#^tr-Q0979|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Herkes%20hayatlar%C4%B1%20boyunca%20en%20az%20bir%20kere%20a%C5%9F%C4%B1k%20olur.)
^tr-Q0979-answer

**tr-Q0980** — Herkes hayatları boyunca en az bir kere aşık olur.

Everybody falls in love at least once in their lives.

Expected form: **en**

Why: Ability, necessity and courtesy. [[Turkish#^tr-Q0980|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Herkes%20hayatlar%C4%B1%20boyunca%20en%20az%20bir%20kere%20a%C5%9F%C4%B1k%20olur.)
^tr-Q0980-answer

**tr-Q0981** — Bundan daha büyük bir köpek yoktur.

There is no dog which is bigger than this one.

Expected form: **daha**

Why: Ability, necessity and courtesy. [[Turkish#^tr-Q0981|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bundan%20daha%20b%C3%BCy%C3%BCk%20bir%20k%C3%B6pek%20yoktur.)
^tr-Q0981-answer

**tr-Q0982** — Bundan daha büyük bir köpek yoktur.

There is no dog which is bigger than this one.

Why: Ability, necessity and courtesy. [[Turkish#^tr-Q0982|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bundan%20daha%20b%C3%BCy%C3%BCk%20bir%20k%C3%B6pek%20yoktur.)
^tr-Q0982-answer

**tr-Q0983** — Tom'u beklemek için daha fazla zaman harcayamayız.

We can't afford to spend any more time waiting for Tom.

Why: Ability, necessity and courtesy. [[Turkish#^tr-Q0983|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%27u%20beklemek%20i%C3%A7in%20daha%20fazla%20zaman%20harcayamay%C4%B1z.)
^tr-Q0983-answer

**tr-Q0984** — Tom'u beklemek için daha fazla zaman harcayamayız.

We can't afford to spend any more time waiting for Tom.

Lütfen marks a polite request; belki limits certainty; gerek/lazım often express necessity. Daha/en participate in comparison and degree. Use the full construction to identify their role.

Why: Ability, necessity and courtesy. [[Turkish#^tr-Q0984|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%27u%20beklemek%20i%C3%A7in%20daha%20fazla%20zaman%20harcayamay%C4%B1z.)
^tr-Q0984-answer

**tr-Q0985** — Tom'un en büyük oğlu, tam anlamıyla kendisine benziyor.

Tom's oldest son looks just like him.

Expected form: **en**

Why: Ability, necessity and courtesy. [[Turkish#^tr-Q0985|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%27un%20en%20b%C3%BCy%C3%BCk%20o%C4%9Flu%2C%20tam%20anlam%C4%B1yla%20kendisine%20benziyor.)
^tr-Q0985-answer

**tr-Q0986** — Tom'un en büyük oğlu, tam anlamıyla kendisine benziyor.

Tom's oldest son looks just like him.

Expected form: **en**

Why: Ability, necessity and courtesy. [[Turkish#^tr-Q0986|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tom%27un%20en%20b%C3%BCy%C3%BCk%20o%C4%9Flu%2C%20tam%20anlam%C4%B1yla%20kendisine%20benziyor.)
^tr-Q0986-answer

**tr-Q0987** — En kısa sürede seni alacağız.

We'll pick you up as soon as we can.

Expected form: **En**

Why: Ability, necessity and courtesy. [[Turkish#^tr-Q0987|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=En%20k%C4%B1sa%20s%C3%BCrede%20seni%20alaca%C4%9F%C4%B1z.)
^tr-Q0987-answer

**tr-Q0988** — En kısa sürede seni alacağız.

We'll pick you up as soon as we can.

Why: Ability, necessity and courtesy. [[Turkish#^tr-Q0988|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=En%20k%C4%B1sa%20s%C3%BCrede%20seni%20alaca%C4%9F%C4%B1z.)
^tr-Q0988-answer

**tr-Q0989** — İnsanların her gece en az 7 saat uyumaları gerekir.

People should sleep at least 7 hours each night.

Why: Ability, necessity and courtesy. [[Turkish#^tr-Q0989|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=%C4%B0nsanlar%C4%B1n%20her%20gece%20en%20az%207%20saat%20uyumalar%C4%B1%20gerekir.)
^tr-Q0989-answer

**tr-Q0990** — İnsanların her gece en az 7 saat uyumaları gerekir.

People should sleep at least 7 hours each night.

Lütfen marks a polite request; belki limits certainty; gerek/lazım often express necessity. Daha/en participate in comparison and degree. Use the full construction to identify their role.

Why: Ability, necessity and courtesy. [[Turkish#^tr-Q0990|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=%C4%B0nsanlar%C4%B1n%20her%20gece%20en%20az%207%20saat%20uyumalar%C4%B1%20gerekir.)
^tr-Q0990-answer

**tr-Q0991** — Hemen hareket etmen gerekiyor; daha sonra çok geç olacak.

You need to act immediately; later will be too late.

Expected form: **daha**

Why: Ability, necessity and courtesy. [[Turkish#^tr-Q0991|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Hemen%20hareket%20etmen%20gerekiyor%3B%20daha%20sonra%20%C3%A7ok%20ge%C3%A7%20olacak.)
^tr-Q0991-answer

**tr-Q0992** — Hemen hareket etmen gerekiyor; daha sonra çok geç olacak.

You need to act immediately; later will be too late.

Expected form: **daha**

Why: Ability, necessity and courtesy. [[Turkish#^tr-Q0992|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Hemen%20hareket%20etmen%20gerekiyor%3B%20daha%20sonra%20%C3%A7ok%20ge%C3%A7%20olacak.)
^tr-Q0992-answer

**tr-Q0993** — Bol buzlu viski, lütfen.

On the rocks, please.

Expected form: **lütfen**

Why: Ability, necessity and courtesy. [[Turkish#^tr-Q0993|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bol%20buzlu%20viski%2C%20l%C3%BCtfen.)
^tr-Q0993-answer

**tr-Q0994** — Bol buzlu viski, lütfen.

On the rocks, please.

Why: Ability, necessity and courtesy. [[Turkish#^tr-Q0994|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bol%20buzlu%20viski%2C%20l%C3%BCtfen.)
^tr-Q0994-answer

**tr-Q0995** — Lütfen buraya oturun.

Take this seat, please.

Why: Ability, necessity and courtesy. [[Turkish#^tr-Q0995|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=L%C3%BCtfen%20buraya%20oturun.)
^tr-Q0995-answer

**tr-Q0996** — Lütfen buraya oturun.

Take this seat, please.

Lütfen marks a polite request; belki limits certainty; gerek/lazım often express necessity. Daha/en participate in comparison and degree. Use the full construction to identify their role.

Why: Ability, necessity and courtesy. [[Turkish#^tr-Q0996|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=L%C3%BCtfen%20buraya%20oturun.)
^tr-Q0996-answer

**tr-Q0997** — Tamam. Lütfen onları sipariş edin.

All right. Please order them.

Expected form: **Lütfen**

Why: Ability, necessity and courtesy. [[Turkish#^tr-Q0997|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tamam.%20L%C3%BCtfen%20onlar%C4%B1%20sipari%C5%9F%20edin.)
^tr-Q0997-answer

**tr-Q0998** — Tamam. Lütfen onları sipariş edin.

All right. Please order them.

Expected form: **Lütfen**

Why: Ability, necessity and courtesy. [[Turkish#^tr-Q0998|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Tamam.%20L%C3%BCtfen%20onlar%C4%B1%20sipari%C5%9F%20edin.)
^tr-Q0998-answer

**tr-Q0999** — Bambular gezegendeki en hızlı büyüyen bitkilerden biridir.

Bamboos are one of the fastest growing plants on the planet.

Expected form: **en**

Why: Ability, necessity and courtesy. [[Turkish#^tr-Q0999|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bambular%20gezegendeki%20en%20h%C4%B1zl%C4%B1%20b%C3%BCy%C3%BCyen%20bitkilerden%20biridir.)
^tr-Q0999-answer

**tr-Q1000** — Bambular gezegendeki en hızlı büyüyen bitkilerden biridir.

Bamboos are one of the fastest growing plants on the planet.

Why: Ability, necessity and courtesy. [[Turkish#^tr-Q1000|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=tur&query=Bambular%20gezegendeki%20en%20h%C4%B1zl%C4%B1%20b%C3%BCy%C3%BCyen%20bitkilerden%20biridir.)
^tr-Q1000-answer


## Read and speak

Read the native sentence first, identify its predicate and one grammar form, then check the translation. Say it aloud and change one detail.

### Learning with a clear purpose

Yeni bir dil öğreniyorum. Her gün kısa bir metin okuyorum ve anlaşılır örnekler dinliyorum. Yararlı kelimeleri bir deftere yazıyorum. Hata yaptığımda kuralı kontrol ediyorum ve tekrar deniyorum. Amacım insanları anlamak ve düşüncelerimi açıkça ifade etmek.

I am learning a new language. Each day, I read a short text and listen to clear examples. I write useful words in a notebook. When I make a mistake, I check the rule and try again. My goal is to understand people and express my ideas clearly.

![[Resources/Audio/tr/Reading passage.mp3]]

**Tom'un şansı yoktu.**

Tom never had a chance.

**Bütün onları yapmak zorunda mıyız?**

Do we have to do all that?

**O, ekmeği yedi.**

She ate the bread.

**Annesi çalışmaya devam edecek.**

Her mother will continue to work.

**Umarım Tom hastalanmadı.**

I hope Tom didn't get sick.

**Harika bir gündü.**

It was a wonderful day.

**Sabahtan beri öksürüyorum.**

I've been coughing since this morning.

**Krizlerden mutlaka nemalanmaya bak.**

Never let a crisis go to waste.

**Bundan sonra daha sıkı çalış.**

Study harder from now on.

**Akşam yemeğinde ne yemek istersiniz?**

What would you like to have for dinner?

**Hemen gemiye dönün.**

Return to the ship immediately.

**Tom benden daha iyi bir kişi.**

Tom is a better person than me.

**Ben McDonald's'ta için çalışıyorum.**

I work for McDonald's.

**Boston'da yaşayan tek Kanadalı ben değilim.**

I'm not the only Canadian living in Boston.

**Hafta boyunca daha az kalabalık görünüyor.**

It seems less crowded during the week.

## Professional writing

Write an introduction, a polite request, an explanation of a finding, a summary of a passage and a tactful disagreement. Use the professional/advanced lessons for models.

## PDF edition

[[Resources/PDFs/Turkish.pdf|Open the complete printable book]]
