# French

Near-native ambition - C2-oriented study

Everything for this language is in this note. Open a rule, read its examples and follow its practice link. Answers stay in this same note.

[[Start Here|All languages]] · [[Sources and licenses|Sources]]

## Start reading

### l’alphabet

| Written form | Name / reading | Related forms |
|---|---|---|
| A a | a  |  ·  ·  |
| B b | bé  |  ·  ·  |
| C c | cé  |  ·  ·  |
| D d | dé  |  ·  ·  |
| E e | e  |  ·  ·  |
| F f | effe  |  ·  ·  |
| G g | gé  |  ·  ·  |
| H h | ache  |  ·  ·  |
| I i | i  |  ·  ·  |
| J j | ji  |  ·  ·  |
| K k | ka  |  ·  ·  |
| L l | elle  |  ·  ·  |
| M m | emme  |  ·  ·  |
| N n | enne  |  ·  ·  |
| O o | o  |  ·  ·  |
| P p | pé  |  ·  ·  |
| Q q | ku  |  ·  ·  |
| R r | erre  |  ·  ·  |
| S s | esse  |  ·  ·  |
| T t | té  |  ·  ·  |
| U u | u  |  ·  ·  |
| V v | vé  |  ·  ·  |
| W w | double vé  |  ·  ·  |
| X x | iks  |  ·  ·  |
| Y y | i grec  |  ·  ·  |
| Z z | zède  |  ·  ·  |

![[Resources/Audio/fr/Script and first phrases.mp3]]

The player above is synthetic speech. Word tracks below work offline.

### The alphabet and accents

There are 26 core letters. Accented letters and ç are written forms, rather than extra alphabet positions. é usually gives /e/; è and ê often give /ɛ/. ç keeps c soft before a, o or u. The letter name u is /y/: say ee with rounded lips. French ou is /u/.

### Read groups together

ch usually gives /ʃ/; gn gives /ɲ/. an/en, on and in often mark nasal vowels when not followed by another vowel or a doubled n/m. Many final consonants are silent, but pronunciation must be learned with the word. eau often represents /o/.

### Connect speech carefully

An obligatory liaison occurs in les amis: /lezami/. It is normally forbidden after et and after a singular noun. The final pronounced syllable of a rhythmic group carries prominence; do not give every word an English-style stress. Learn a recording together with its written phrase.

### Make a noun phrase

un livre → le livre → les livres = a book → the book → the books. belle maison = beautiful house; plural belles maisons. Gender belongs to the noun; learn it with un/une.

### Combine written forms

de + le → du; à + le → au; de + les → des; à + les → aux. These are contractions: Je vais au marché. = I am going to the market.

### Use word families

possible → impossible; organiser → organisation; utile → utilement is not the usual adverb: use utilement only in suitable contexts. Learn natural collocations rather than adding suffixes to every word.

**Bonjour.**

Hello.

**J’apprends le français.**

I am learning French.

**Pouvez-vous répéter, s’il vous plaît ?**

Can you repeat, please?

**Que signifie ce mot ?**

What does this word mean?

### Grammar terms in plain English

**Noun** — A word naming a person, thing or idea: student, book, freedom.

**Verb** — A word describing an action or state: read, know, be.

**Subject** — The participant linked to the main verb’s subject pattern. In The student reads a book, the student is the subject.

**Object** — A participant selected by a verb. In The student reads a book, a book is the direct object.

**Agreement** — One word changes to match another, for example an adjective matching a noun’s gender and number.

**Case** — A noun/pronoun form marking its relationship in a sentence. Cases can mark subjects, objects, possession or relations usually expressed by English prepositions.

**Gender** — A grammatical noun class. It does not always describe the sex of a person or any physical property.

**Tense** — A verb system that relates a situation to a time, often past or non-past.

**Aspect** — How a situation is viewed: unfolding, completed, habitual, experienced or in a resulting state.

**Infinitive** — A non-finite verb form often used for a dictionary entry or a complement. It does not by itself give the ordinary person/tense pattern.

**Participle** — A verb-derived form used in compound predicates or as a modifier; its exact function depends on the language and construction.

**Clause** — A unit organised around a predicate. One sentence can contain several clauses.

**Register** — Language choices suited to a situation: casual conversation, polite requests, academic writing or another context.

## Grammar, examples and practice

### Sound, spelling and noun phrases

French spelling is not a direct pronunciation key. Learn /y/ in tu separately from /u/ in tout; nasal vowels are not simply an oral vowel followed by a pronounced n. Liaison links a normally silent final consonant in certain contexts, but can be obligatory, optional or prohibited. Enchaînement resyllabifies a consonant that is already pronounced. Listening distinguishes them better than spelling alone.
Articles and adjectives agree with nouns. Le problème, la méthode, les résultats. Elision produces l'étude. Partitive expressions such as du café and de la patience can introduce an unspecified amount; ordinary negation commonly changes indefinite and partitive objects to de: Je n'ai pas de temps. With être and contrastive contexts, different patterns occur. Feminine singular nouns beginning with stressed /a/ are not the Spanish article system; do not import another Romance language's rule.

**une méthode précise / des méthodes précises**

a precise method / precise methods Gender and number agreement are visible in writing even when some endings are silent.

**Je n’ai pas de réponse.**

I do not have an answer. De replaces an indefinite object article under ordinary negation.

#### Articles and gender

Articles distinguish gender, number and reference. Le/la are singular definite forms and les is plural. Un/une introduce indefinite singular nouns. Learn each noun with its article; a translation rarely predicts gender.

**Il a été condamné à de la prison.**

He was sentenced to prison.

**Il n'est qu'un homme d'affaires.**

He is nothing but a businessman.

![[Resources/Audio/fr/Rule 01.mp3]]

[[French#^fr-Q0001|Practise this rule (50 questions)]]

#### Contractions and partitives

Du can be de + le or a partitive article. Au and aux contract à + le/les. Meaning and the governing phrase distinguish possession, source, destination and unspecified quantity.

**Roger travaille du matin au soir.**

Roger works from morning till night.

**Cette partie du musée est temporairement inaccessible aux visiteurs.**

This part of the museum is temporarily off-limits to visitors.

![[Resources/Audio/fr/Rule 02.mp3]]

[[French#^fr-Q0051|Practise this rule (50 questions)]]

#### Subject pronouns

A finite verb normally has an expressed subject. On takes third-person singular agreement and often means people generally or informal we. Vous can address one person politely or several people.

**Tom ne semble certainement pas savoir ce qu'il est en train de faire.**

Tom certainly doesn't seem to know what he's doing.

**Je ne pense pas que tu devrais manger ça.**

I don't think you should eat that.

![[Resources/Audio/fr/Rule 03.mp3]]

[[French#^fr-Q0101|Practise this rule (50 questions)]]

#### Negation

Formal French commonly uses ne with pas/jamais/rien/personne/plus. Spoken French often drops ne. Plus can mean no longer in a negative construction or more in an affirmative one; pronunciation and context matter.

**Ne m'arnaquez pas !**

Don't screw me over!

**Je n'aime pas qu'on se moque de moi.**

I don't like being made a fool of.

![[Resources/Audio/fr/Rule 14.mp3]]

[[French#^fr-Q0651|Practise this rule (50 questions)]]

#### Adjective agreement

Adjectives agree with the noun in gender and number, with many spelling changes. Their position can affect meaning. Written agreement is often more visible than spoken agreement.

**Est-ce ta petite copine ?**

Is this your girlfriend?

**Ma mère m'a acheté un nouveau vélo.**

Mother bought me a new bicycle.

![[Resources/Audio/fr/Rule 19.mp3]]

[[French#^fr-Q0901|Practise this rule (50 questions)]]

<details><summary>Correct: un question important.</summary>

Une question importante. Question is feminine; article and adjective agree.

</details>

<details><summary>Explain tu and tout.</summary>

They contrast front rounded /y/ and back rounded /u/. English spelling cannot reliably produce the distinction.

</details>

### Verb system and past perspectives

Present forms of parler are parle, parles, parle, parlons, parlez, parlent. Many frequent verbs are irregular: être, avoir, aller and faire deserve retrieval practice. The passé composé presents past events as bounded; the imparfait commonly presents background, habit or an unfolding state. Their choice follows narrative perspective rather than a simple completed/unfinished rule.
Compound tenses use avoir or être with a past participle. With être in ordinary intransitive constructions, the participle agrees with the subject: elles sont arrivées. With avoir, preceding direct objects can trigger agreement: les lettres que j'ai écrites. Pronominal verbs need their own object analysis; do not apply a blanket subject-agreement rule. The plus-que-parfait places an event before a past reference point.

**Quand je suis arrivé, elle travaillait.**

When I arrived, she was working. A bounded arrival is set against an ongoing background.

**Les notes que j’ai prises sont utiles.**

The notes I took are useful. Prises agrees with preceding direct object notes.

#### Present être

Être is irregular: je suis, tu es, il est, nous sommes, vous êtes, ils sont. It can be a main copula or an auxiliary; a later participle helps identify the latter.

**C'est chaud boulette.**

It's as hot as toast.

**Mon stylo est à court d'encre.**

My pen is out of ink.

![[Resources/Audio/fr/Rule 04.mp3]]

[[French#^fr-Q0151|Practise this rule (50 questions)]]

#### Present avoir

Avoir expresses possession and forms many compound tenses. Some expressions use avoir where English uses be: avoir faim, avoir vingt ans. Do not translate the English verb mechanically.

**Qu'y a-t-il à faire ?**

What's there to do?

**J'ai besoin de ton aide.**

I need your help.

![[Resources/Audio/fr/Rule 05.mp3]]

[[French#^fr-Q0201|Practise this rule (50 questions)]]

#### Imperfect perspective

The imparfait often presents a background state, ongoing situation or past habit. It does not simply mean a long event. Contrast it with a completed event in the passé composé.

**C'était une journée agréable, mais il y avait peu de monde dans le parc.**

It was a pleasant day, but there were few people in the park.

**Aota n'était pas digne de ta confiance.**

Aota was not worthy of your trust.

![[Resources/Audio/fr/Rule 06.mp3]]

[[French#^fr-Q0251|Practise this rule (50 questions)]]

#### Past participles

A past participle combines with avoir or être in a compound tense. Agreement depends on the auxiliary and the construction; with avoir a preceding direct object can matter. A participle may also act adjectivally.

**L'état fait face à une crise financière.**

The state faces a financial crisis.

**Je suis en fait plutôt flattée.**

I'm actually kind of flattered.

![[Resources/Audio/fr/Rule 07.mp3]]

[[French#^fr-Q0301|Practise this rule (50 questions)]]

#### Future forms

The futur simple locates an event ahead or makes a prediction. Aller plus infinitive is another future construction. In many future-time clauses after quand, French uses future where English uses present.

**Peut-être que ce sera suffisant.**

Maybe that'll be enough.

**Un verre d'eau vous fera du bien.**

A glass of water will make you feel better.

![[Resources/Audio/fr/Rule 08.mp3]]

[[French#^fr-Q0351|Practise this rule (50 questions)]]

<details><summary>Distinguish je savais and j’ai su.</summary>

Je savais presents knowing as a state or background; j’ai su can present coming to know or a bounded knowing event in context.

</details>

<details><summary>Complete: Elles sont arrivé__ hier.</summary>

Elles sont arrivées hier. Feminine plural agreement with an être compound tense.

</details>

### Pronouns, y, en and relative structures

Unstressed object pronouns usually precede the conjugated verb or the infinitive they belong to. Learn the order rather than placing each pronoun from an English translation. Je le lui donne places direct object le before indirect object lui. Positive imperatives use a different pattern: donne-le-moi.
Y commonly replaces a location or an à-complement referring to a thing; en commonly replaces de + noun or a quantity expression. Human references and verb government can require other choices. Relative qui is normally a subject and que a direct object. Dont replaces a de relationship; où often relates to place or time. Lequel forms follow certain prepositions and agree with the antecedent. Distinguish the antecedent's gender from the pronoun's grammatical role.

**C’est une question dont nous discutons.**

It is a question that we are discussing. Discuter de licenses dont.

**J’en ai lu trois.**

I have read three of them. En carries the understood noun associated with the quantity.

#### Object pronouns

Direct and indirect object pronouns differ. Lui/leur often replace an animate à-complement; le/la/les replace direct objects. Pronouns generally precede the finite verb, with special imperative ordering.

**Voulez-vous sortir d'ici ou non ?**

Do you want to get out of here or not?

**Je viens te chercher.**

I'm coming to pick you up.

![[Resources/Audio/fr/Rule 11.mp3]]

[[French#^fr-Q0501|Practise this rule (50 questions)]]

#### Y and en

Y often replaces a place or an à + non-person complement. En often replaces a de-complement or partitive quantity. Retain an expressed number when needed: J’en ai deux. En can also begin a different construction, so inspect context.

**Il sait comment se tenir en public.**

He knows how to behave in public.

**On n'en est jamais certain.**

You never know for sure.

![[Resources/Audio/fr/Rule 12.mp3]]

[[French#^fr-Q0551|Practise this rule (50 questions)]]

#### Relative clauses

Qui is a relative subject; que a relative direct object; dont normally replaces a de relation; où relates place or time. Que also has other functions. Determine the role within the clause.

**Attends ici jusqu'à ce que je revienne !**

Wait here until I come back.

**Tom semble être conscient de ce qui se passe.**

Tom seems to be aware of what's happening.

![[Resources/Audio/fr/Rule 13.mp3]]

[[French#^fr-Q0601|Practise this rule (50 questions)]]

#### Questions and indirect questions

Questions can use intonation, est-ce que or inversion. An indirect question normally keeps statement order. Si introduces an indirect yes/no question as well as a condition in other contexts.

**Combien de tuyaux compte cet orgue ?**

How many pipes does this organ have?

**Combien la chemise coûte-t-elle ?**

How much does the shirt cost?

![[Resources/Audio/fr/Rule 15.mp3]]

[[French#^fr-Q0701|Practise this rule (50 questions)]]

<details><summary>Combine: Voici la méthode. Nous avons besoin de cette méthode.</summary>

Voici la méthode dont nous avons besoin. Avoir besoin de licenses dont.

</details>

<details><summary>Replace à cette question: Je réfléchis à cette question.</summary>

J’y réfléchis. Y replaces the thing-complement governed by à.

</details>

### Subjunctive, condition and uncertainty

The subjunctive commonly appears after expressions of necessity, desire, evaluation or doubt. Il faut que vous soyez précis; je souhaite qu'elle vienne. It is not simply a tense for anything uncertain. Although an event can be factual, bien que normally takes the subjunctive: bien qu'il soit tard. Après que normally takes the indicative in standard usage, despite common variation.
Si clauses use coordinated tense patterns: si + present with a real future consequence; si + imperfect with conditional for a hypothetical situation; si + pluperfect with past conditional for a past counterfactual. Do not use the conditional automatically after si in the ordinary condition structure. Literary imperfect and pluperfect subjunctives are recognition topics for advanced reading rather than default everyday production.

**Bien que les résultats soient prometteurs, une confirmation reste nécessaire.**

Although the results are promising, confirmation remains necessary. Subjunctive follows bien que; the main assertion states the limitation.

**Si j’avais su, j’aurais attendu.**

If I had known, I would have waited. Past counterfactual: plus-que-parfait and conditionnel passé.

#### Conditional forms

The conditional can express a hypothetical result, politeness or unconfirmed reported information. A usual hypothetical pattern is si + imperfect, conditional in the main clause.

**Tu ne voudrais prendre un peu l'air ?**

Wouldn't you like to get some fresh air?

**Je ne pourrais pas me passer de ce dictionnaire, ne serait-ce que pour une journée.**

I cannot do without this dictionary even a day.

![[Resources/Audio/fr/Rule 09.mp3]]

[[French#^fr-Q0401|Practise this rule (50 questions)]]

#### Subjunctive contexts

Subjunctive forms occur after many expressions of necessity, desire, doubt and evaluation. The governing expression matters: il faut que commonly takes a subjunctive. A form alone does not establish a speaker’s certainty.

**Ne te rappelles-tu pas quoi que ce soit ?**

Don't you remember anything?

**Il est plus riche que qui que ce soit d'autre en ville.**

He is richer than anybody else in town.

![[Resources/Audio/fr/Rule 10.mp3]]

[[French#^fr-Q0451|Practise this rule (50 questions)]]

#### Conditions

Si introduces several meanings, especially if and indirect whether. For a standard unreal present condition use si + imperfect, not conditional. For a past counterfactual use si + pluperfect.

**Nous n'étions pas si occupées.**

We weren't all that busy.

**Si j'étais vous, je ne le traduirais pas littéralement.**

If I were you, I wouldn't translate it literally.

![[Resources/Audio/fr/Rule 16.mp3]]

[[French#^fr-Q0751|Practise this rule (50 questions)]]

<details><summary>Correct: Si j’aurais le temps, je viendrais.</summary>

Si j’avais le temps, je viendrais. The ordinary hypothetical condition uses imperfect after si.

</details>

<details><summary>Why does bien que take subjunctive even with a true fact?</summary>

Mood is governed by the construction and its concessive framing, not solely by factual uncertainty.

</details>

### Passive, causative and reported information

The passive uses être + participle, agreeing with the subject. French also uses on, reflexive constructions and active wording where English might prefer a passive. Le français se parle dans plusieurs régions uses a pronominal construction. Faire + infinitive is causative: faire réparer le vélo means arranging for the bicycle to be repaired.
Reported speech can change pronouns, time expressions and tense perspective: elle a dit qu'elle viendrait. The conditional can also mark unconfirmed information in journalistic register, as in the report-style Il y aurait plusieurs causes. This is a reporting convention, not the assertion that the writer has disproved the information. Explain the source and degree of confidence explicitly when precision matters.

**Le rapport a été révisé par l’équipe.**

The report was revised by the team. Compound passive with agreement on rapport.

**Nous avons fait vérifier les chiffres.**

We had the figures checked. Faire + infinitive expresses arranged or caused action.

#### Causative faire

Faire can mean do/make or form a causative with an infinitive: faire réparer, have repaired. Identify who arranges the action and who performs it. Not every occurrence of faire is causative.

**Fais ton déplacement.**

Make your move.

**N'importe quel enfant peut faire cela.**

Any child can do that.

![[Resources/Audio/fr/Rule 18.mp3]]

[[French#^fr-Q0851|Practise this rule (50 questions)]]

<details><summary>Rewrite actively: Une décision a été prise par le comité.</summary>

Le comité a pris une décision. The agent becomes clearer.

</details>

<details><summary>Explain elle a dit qu’elle viendrait.</summary>

She said she would come. The conditional represents a future viewed from a past reporting point.

</details>

### Argument connectors, nominalisation and register

Cependant and toutefois introduce qualifications or contrast; en revanche presents a counterbalancing contrast; par conséquent signals inference; néanmoins expresses concession. Do not scatter connectors without an actual logical relation. French academic prose often uses nominalisations, but excessive noun stacking obscures agency.
Politeness includes appropriate address: vous for many professional relationships, tu for familiar ones depending on community and context. Pourriez-vous préciser ... is a conventional request. Formal letters use established opening and closing formulas, while contemporary email can be less ceremonial. Register should match purpose, not a fixed belief that French must always sound ornate.

**Cette hypothèse est plausible ; toutefois, les données restent insuffisantes.**

This hypothesis is plausible; however, the data remain insufficient. The connector limits the implication of plausibility.

**Pourriez-vous préciser les conditions de cette estimation ?**

Could you clarify the conditions of this estimate? Conditional politeness with a precise object.

#### Cause and concession

Parce que supplies a cause; puisque often treats the reason as accepted; bien que introduces concession and generally takes subjunctive. Pourtant/cependant link ideas without themselves supplying the same subordinate structure.

**Tu ne connais pas Tom aussi bien que moi.**

You don't know Tom as well as I do.

**Je ne parle pas bien l'anglais, bien que je l'aie étudié six ans à l'école.**

I don't speak English well even though I took it for six years at school.

![[Resources/Audio/fr/Rule 17.mp3]]

[[French#^fr-Q0801|Practise this rule (50 questions)]]

#### Comparison

Plus/moins ... que compare; aussi ... que expresses equality. Meilleur compares bon; mieux compares bien. Choose adjective versus adverb according to the phrase’s function.

**Mon meilleur ami est mort asphyxié.**

My best friend died of asphyxiation.

**Tom est fort, mais Marie est plus forte.**

Tom is strong, but Mary is stronger.

![[Resources/Audio/fr/Rule 20.mp3]]

[[French#^fr-Q0951|Practise this rule (50 questions)]]

<details><summary>Replace the vague Cela prouve tout with a cautious academic claim.</summary>

Ces résultats soutiennent cette interprétation, sans exclure les autres explications. The claim stays limited.

</details>

<details><summary>Write a request to a professional contact.</summary>

Use vous, a clear purpose and a practical next step. Avoid combining several elaborate politeness formulas in one sentence.

</details>

### Advanced reading and stylistic distinctions

Original teaching passage: Une explication peut sembler convaincante sans être confirmée par les données disponibles. Il convient donc de distinguer ce que les observations montrent de ce que l'auteur en déduit. Plus les conditions de l'étude sont clairement définies, plus il devient possible d'évaluer la portée de ses conclusions. Cette prudence ne rend pas l'analyse moins utile ; elle en précise les limites.
Translation: An explanation can appear convincing without being confirmed by the available data. It is therefore appropriate to distinguish what the observations show from what the author infers from them. The more clearly the study conditions are defined, the more possible it becomes to assess the scope of its conclusions. This caution does not make the analysis less useful; it clarifies its limits.
Convaincant concerns persuasiveness; confirmé concerns evidential confirmation. Portée refers to scope or reach, not just a literal distance. En links an inference to its source and later links limits to the analysis. Advanced reading requires tracking these small references.

**ce que l’auteur en déduit**

what the author infers from it/them Ce que introduces an indefinite relative; en represents the source relationship.

**Il convient de distinguer ...**

It is appropriate to distinguish ... A formal impersonal recommendation rather than a command.

<details><summary>What does the final sentence deny?</summary>

It denies that caution makes the analysis less useful; it instead clarifies the limits.

</details>

<details><summary>Rewrite the passage for a friend in 80 words.</summary>

Keep the evidential distinction but simplify impersonal phrasing. Check natural register and references, not only grammar.

</details>

### Idiomatic competence and broad learning

Learn idioms as situated examples. En fin de compte means ultimately; en revanche is a contrast marker; avoir beau + infinitive expresses unsuccessful effort or a concessive idea. Avoir beau chercher, je ne trouve rien means that however much I search, I find nothing. It does not concern literal beauty. Regional lexical choices such as déjeuner and dîner can designate different meals in different Francophone regions.
For near-native ambition, read essays, quality journalism, literature, letters and specialised prose. Notice humour, understatement, formality and social positioning. Literary passé simple is central for recognition in narrative, although it is not an everyday conversational default. Maintain a phrase notebook that records an entire useful construction and its circumstances.

**Il a beau vérifier, il ne trouve aucune erreur.**

However much he checks, he finds no error. Avoir beau frames an effort that fails to change the result.

**En fin de compte, la décision dépend du contexte.**

Ultimately, the decision depends on the context. A discourse phrase, not a literal accounting statement.

<details><summary>Why should you not translate every instance of beau as beautiful?</summary>

Fixed constructions can have nonliteral meanings; avoir beau + infinitive is a standard example.

</details>

<details><summary>Analyse a page of authentic French from any subject.</summary>

Extract three collocations, one clause structure, one register choice and an accurate summary. Check the source before treating its statements as evidence.

</details>

## Word bank and recordings

1,000 study entries, based on dictionary selections and authored teaching glosses. Learn a word in a phrase; consult the linked entry for additional senses.

<details><summary>Words 1–50</summary>

![[Resources/Audio/fr/Words 0001-0050.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [de](https://en.wiktionary.org/wiki/de#French) | of; from | /də/ · prep |
| [la](https://en.wiktionary.org/wiki/la#French) | the (feminine singular); her/it as an object pronoun | /la/ · article |
| [le](https://en.wiktionary.org/wiki/le#French) | the (masculine singular); him/it as an object pronoun | /lə/ · article |
| [et](https://en.wiktionary.org/wiki/et#French) | and | /e/ · conj |
| [à](https://en.wiktionary.org/wiki/%C3%A0#French) | to (destination) | /a/ · prep |
| [est](https://en.wiktionary.org/wiki/est#French) | is (être, third-person singular); east in another sense | /ɛst/ · verb |
| [en](https://en.wiktionary.org/wiki/en#French) | in; of/from it or them as a pronoun | /ɑ̃/ · prep |
| [un](https://en.wiktionary.org/wiki/un#French) | a/an (masculine singular); one | /œ̃/ · det |
| [il](https://en.wiktionary.org/wiki/il#French) | he (third-person singular masculine subject pronoun for human subject) | /il/ · pron |
| [pour](https://en.wiktionary.org/wiki/pour#French) | for (meant for, intended for) | /puʁ/ · prep |
| [dans](https://en.wiktionary.org/wiki/dans#French) | in, inside (enclosed in a physical space, a group, a state) | /dɑ̃/ · prep |
| [je](https://en.wiktionary.org/wiki/je#French) | I | /ʒə/ · pron |
| [CE](https://en.wiktionary.org/wiki/CE#French) | a part of the primary school | /se.ø/ · noun |
| [ce](https://en.wiktionary.org/wiki/ce#French) | this, that | /sə/ · det |
| [par](https://en.wiktionary.org/wiki/par#French) | through | /paʁ/ · prep |
| [on](https://en.wiktionary.org/wiki/on#French) | one, people, you, someone (an unspecified individual) | /ɔ̃/ · pron |
| [ne](https://en.wiktionary.org/wiki/ne#French) | not (used alone to negate a verb, now chiefly with only a few particular verbs; see usage notes) | /nə/ · particle |
| [se](https://en.wiktionary.org/wiki/se#French) | himself | /sə/ · pron |
| [vous](https://en.wiktionary.org/wiki/vous#French) | you (all) | /vu/ · pron |
| [tu](https://en.wiktionary.org/wiki/tu#French) | you (singular) | /ty/ · pron |
| [son](https://en.wiktionary.org/wiki/son#French) | sound | /sɔ̃/ · noun |
| [y](https://en.wiktionary.org/wiki/y#French) | there (at a place) | /i/ · pron |
| [ou](https://en.wiktionary.org/wiki/ou#French) | or | /u/ · conj |
| [si](https://en.wiktionary.org/wiki/si#French) | if, whether | /si/ · conj |
| [tout](https://en.wiktionary.org/wiki/tout#French) | all | /tu/ · adv |
| [nous](https://en.wiktionary.org/wiki/nous#French) | we | /nu/ · pron |
| [être](https://en.wiktionary.org/wiki/%C3%AAtre#French) | to be | /ɛtʁ/ · verb |
| [bien](https://en.wiktionary.org/wiki/bien#French) | good, all right, great | /bjɛ̃/ · adj |
| [faire](https://en.wiktionary.org/wiki/faire#French) | to do | /fɛʁ/ · verb |
| [sa](https://en.wiktionary.org/wiki/sa#French) | his, her, its, their, one's | /sa/ · det |
| [me](https://en.wiktionary.org/wiki/me#French) | me (direct object) | /mə/ · pron |
| [été](https://en.wiktionary.org/wiki/%C3%A9t%C3%A9#French) | summer | /e.te/ · noun |
| [lui](https://en.wiktionary.org/wiki/lui#French) | him, he, it; the third-person masculine singular personal pronoun used after a preposition, or as the predicate of a linking verb, or when disjoined from a sentence, or as a stressed subject | /lɥi/ · pron |
| [deux](https://en.wiktionary.org/wiki/deux#French) | two | /dø/ · num |
| [sans](https://en.wiktionary.org/wiki/sans#French) | without (not having) | /sɑ̃/ · prep |
| [avoir](https://en.wiktionary.org/wiki/avoir#French) | to have; to own; to possess; to get | /a.vwaʁ/ · verb |
| [non](https://en.wiktionary.org/wiki/non#French) | no | /nɔ̃/ · adv |
| [où](https://en.wiktionary.org/wiki/o%C3%B9#French) | where (interrogative) | /u/ · adv |
| [monde](https://en.wiktionary.org/wiki/monde#French) | world | /mɔ̃d/ · noun |
| [te](https://en.wiktionary.org/wiki/te#French) | you | /tə/ · pron |
| [voir](https://en.wiktionary.org/wiki/voir#French) | to see (visually) | /vwaʁ/ · verb |
| [bon](https://en.wiktionary.org/wiki/bon#French) | good | /bɔ̃/ · adj |
| [sous](https://en.wiktionary.org/wiki/sous#French) | below, under | /su/ · prep |
| [jamais](https://en.wiktionary.org/wiki/jamais#French) | never | /ʒa.mɛ/ · adv |
| [ton](https://en.wiktionary.org/wiki/ton#French) | your | /tɔ̃/ · det |
| [tout le monde](https://en.wiktionary.org/wiki/tout%20le%20monde#French) | everyone, everybody | /tu lə mɔ̃d/ · pron |
| [ainsi](https://en.wiktionary.org/wiki/ainsi#French) | in this way, thus | /ɛ̃.si/ · adv |
| [as](https://en.wiktionary.org/wiki/as#French) | have (tu as); an ace in another sense | /as/ · verb |
| [pays](https://en.wiktionary.org/wiki/pays#French) | land; region; home ground; homeland; home country; country; nation | /pɛ.i/ · noun |
| [français](https://en.wiktionary.org/wiki/fran%C3%A7ais#French) | French | /fʁɑ̃.sɛ/ · adj |

</details>

<details><summary>Words 51–100</summary>

![[Resources/Audio/fr/Words 0051-0100.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [mes](https://en.wiktionary.org/wiki/mes#French) | my (when referring to a plural noun) | /mɛ/ · det |
| [jour](https://en.wiktionary.org/wiki/jour#French) | day | /ʒuʁ/ · noun |
| [premier](https://en.wiktionary.org/wiki/premier#French) | first | /pʁə.mje/ · adj |
| [personne](https://en.wiktionary.org/wiki/personne#French) | person | /pɛʁ.sɔn/ · noun |
| [trois](https://en.wiktionary.org/wiki/trois#French) | three | /tʁwa/ · num |
| [vu](https://en.wiktionary.org/wiki/vu#French) | given (based on) | /vy/ · prep |
| [chose](https://en.wiktionary.org/wiki/chose#French) | thing | /ʃoz/ · noun |
| [car](https://en.wiktionary.org/wiki/car#French) | as, since, because, for | /kaʁ/ · conj |
| [mal](https://en.wiktionary.org/wiki/mal#French) | trouble, difficulty | /mal/ · noun |
| [première](https://en.wiktionary.org/wiki/premi%C3%A8re#French) | premiere, première | /pʁə.mjɛʁ/ · noun |
| [bonne](https://en.wiktionary.org/wiki/bonne#French) | maid | /bɔn/ · noun |
| [fin](https://en.wiktionary.org/wiki/fin#French) | end, close, finish | /fɛ̃/ · noun |
| [pendant](https://en.wiktionary.org/wiki/pendant#French) | hanging | /pɑ̃.dɑ̃/ · adj |
| [moment](https://en.wiktionary.org/wiki/moment#French) | moment (point in time) | /mɔ.mɑ̃/ · noun |
| [place](https://en.wiktionary.org/wiki/place#French) | place, square, plaza, piazza | /plas/ · noun |
| [ta](https://en.wiktionary.org/wiki/ta#French) | your | /ta/ · det |
| [vers](https://en.wiktionary.org/wiki/vers#French) | towards | /vɛʁ/ · prep |
| [part](https://en.wiktionary.org/wiki/part#French) | share | /paʁ/ · noun |
| [femme](https://en.wiktionary.org/wiki/femme#French) | woman | /fam/ · noun |
| [point](https://en.wiktionary.org/wiki/point#French) | point (small mark) | /pwɛ̃/ · noun |
| [coup](https://en.wiktionary.org/wiki/coup#French) | sound of the action | /ku/ · noun |
| [mettre](https://en.wiktionary.org/wiki/mettre#French) | to put; to place | /mɛtʁ/ · verb |
| [maison](https://en.wiktionary.org/wiki/maison#French) | house | /mɛ.zɔ̃/ · noun |
| [saint](https://en.wiktionary.org/wiki/saint#French) | a male saint; masculine of sainte | /sɛ̃/ · noun |
| [homme du monde](https://en.wiktionary.org/wiki/homme%20du%20monde#French) | man of the world (worldly man) | /ɔm dy mɔ̃d/ · noun |
| [pouvoir](https://en.wiktionary.org/wiki/pouvoir#French) | can, to be able to | /pu.vwaʁ/ · verb |
| [question](https://en.wiktionary.org/wiki/question#French) | question (sentence, phrase or word which asks for information, reply or response) | /kɛs.tjɔ̃/ · noun |
| [ci](https://en.wiktionary.org/wiki/ci#French) | see -ci | /si/ · adv |
| [jeu](https://en.wiktionary.org/wiki/jeu#French) | game (activity performed for amusement) | /ʒø/ · noun |
| [ni](https://en.wiktionary.org/wiki/ni#French) | neither; nor | /ni/ · conj |
| [partir](https://en.wiktionary.org/wiki/partir#French) | to go away, leave, depart | /paʁ.tiʁ/ · verb |
| [tout de suite](https://en.wiktionary.org/wiki/tout%20de%20suite#French) | immediately, right away | /tu də sɥit/ · adv |
| [eau](https://en.wiktionary.org/wiki/eau#French) | water, a liquid that is transparent, colorless, odorless, and tasteless in its pure form, the primary constituent of lakes, rivers, seas, and oceans | /o/ · noun |
| [passer](https://en.wiktionary.org/wiki/passer#French) | to pass; to go past | /pa.se/ · verb |
| [raison d'être](https://en.wiktionary.org/wiki/raison%20d%27%C3%AAtre#French) | raison d'être | /ʁɛ.zɔ̃ d‿ɛtʁ/ · noun |
| [face](https://en.wiktionary.org/wiki/face#French) | face | /fas/ · noun |
| [quatre](https://en.wiktionary.org/wiki/quatre#French) | four | /katʁ/ · num |
| [service](https://en.wiktionary.org/wiki/service#French) | service | /sɛʁ.vis/ · noun |
| [accord](https://en.wiktionary.org/wiki/accord#French) | chord | /a.kɔʁ/ · noun |
| [article](https://en.wiktionary.org/wiki/article#French) | article (a piece of nonfictional writing) | /aʁ.tikl/ · noun |
| [donner](https://en.wiktionary.org/wiki/donner#French) | to give, to transfer the possession/holding of something to someone else | /dɔ.ne/ · verb |
| [cause](https://en.wiktionary.org/wiki/cause#French) | cause | /koz/ · noun |
| [dieu](https://en.wiktionary.org/wiki/dieu#French) | a god, male divinity | /djø/ · noun |
| [fils](https://en.wiktionary.org/wiki/fils#French) | son | /fis/ · noun |
| [air](https://en.wiktionary.org/wiki/air#French) | air (gases of the atmosphere) | /ɛʁ/ · noun |
| [centre](https://en.wiktionary.org/wiki/centre#French) | centre, center | /sɑ̃tʁ/ · noun |
| [possible](https://en.wiktionary.org/wiki/possible#French) | possible | /pɔ.sibl/ · adj |
| [nuit](https://en.wiktionary.org/wiki/nuit#French) | night | /nɥi/ · noun |
| [tour](https://en.wiktionary.org/wiki/tour#French) | tower | /tuʁ/ · noun |
| [vue](https://en.wiktionary.org/wiki/vue#French) | sight (something seen) | /vy/ · noun |

</details>

<details><summary>Words 101–150</summary>

![[Resources/Audio/fr/Words 0101-0150.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [an](https://en.wiktionary.org/wiki/an#French) | year | /ɑ̃/ · noun |
| [film](https://en.wiktionary.org/wiki/film#French) | movie, film | /film/ · noun |
| [corps](https://en.wiktionary.org/wiki/corps#French) | body | /kɔʁ/ · noun |
| [haut](https://en.wiktionary.org/wiki/haut#French) | high | /o/ · adj |
| [or](https://en.wiktionary.org/wiki/or#French) | gold | /ɔʁ/ · noun |
| [au-dessus](https://en.wiktionary.org/wiki/au-dessus#French) | above | /o.d(ə).sy/ · adv |
| [public](https://en.wiktionary.org/wiki/public#French) | of the people as a whole | /py.blik/ · adj |
| [main](https://en.wiktionary.org/wiki/main#French) | hand | /mɛ̃/ · noun |
| [plan](https://en.wiktionary.org/wiki/plan#French) | map (schematic maps of streets, subways, etc.) | /plɑ̃/ · noun |
| [type](https://en.wiktionary.org/wiki/type#French) | type; sort, kind | /tip/ · noun |
| [ah](https://en.wiktionary.org/wiki/ah#French) | ah | /a/ · intj |
| [long](https://en.wiktionary.org/wiki/long#French) | long | /lɔ̃/ · adj |
| [quelque chose](https://en.wiktionary.org/wiki/quelque%20chose#French) | something (an indefinite or indeterminate object) | /kɛl.k(ə) ʃoz/ · pron |
| [situation](https://en.wiktionary.org/wiki/situation#French) | situation (all meanings) | /si.tɥa.sjɔ̃/ · noun |
| [vite](https://en.wiktionary.org/wiki/vite#French) | quickly | /vit/ · adv |
| [base](https://en.wiktionary.org/wiki/base#French) | base (bottom part of something) | /baz/ · noun |
| [nord](https://en.wiktionary.org/wiki/nord#French) | north | /nɔʁ/ · noun |
| [etc.](https://en.wiktionary.org/wiki/etc.#French) | et cetera (and so on) | /ɛt.se.te.ʁa/ · adv |
| [but](https://en.wiktionary.org/wiki/but#French) | aim | /byt/ · noun |
| [cinq](https://en.wiktionary.org/wiki/cinq#French) | five | /sɛ̃k/ · num |
| [mars](https://en.wiktionary.org/wiki/mars#French) | March (month) | /maʁs/ · noun |
| [pierre](https://en.wiktionary.org/wiki/pierre#French) | stone (substance) | /pjɛʁ/ · noun |
| [rue](https://en.wiktionary.org/wiki/rue#French) | street, road | /ʁy/ · noun |
| [super](https://en.wiktionary.org/wiki/super#French) | superb, great | /sy.pɛʁ/ · adj |
| [art](https://en.wiktionary.org/wiki/art#French) | art | /aʁ/ · noun |
| [beau](https://en.wiktionary.org/wiki/beau#French) | handsome, fine, attractive | /bo/ · adj |
| [livre](https://en.wiktionary.org/wiki/livre#French) | book | /livʁ/ · noun |
| [musique](https://en.wiktionary.org/wiki/musique#French) | music | /my.zik/ · noun |
| [match](https://en.wiktionary.org/wiki/match#French) | match, game | /matʃ/ · noun |
| [simple](https://en.wiktionary.org/wiki/simple#French) | single | /sɛ̃pl/ · adj |
| [bien sûr](https://en.wiktionary.org/wiki/bien%20s%C3%BBr#French) | of course | /bjɛ̃ syʁ/ · adv |
| [chambre](https://en.wiktionary.org/wiki/chambre#French) | a room. | /ʃɑ̃bʁ/ · noun |
| [homme de guerre](https://en.wiktionary.org/wiki/homme%20de%20guerre#French) | a man of war, a military man | /ɔm də ɡɛʁ/ · noun |
| [anglais](https://en.wiktionary.org/wiki/anglais#French) | English | /ɑ̃.ɡlɛ/ · adj |
| [homme de Dieu](https://en.wiktionary.org/wiki/homme%20de%20Dieu#French) | a man of God, a godly man | /ɔm də djø/ · noun |
| [important](https://en.wiktionary.org/wiki/important#French) | important | /ɛ̃.pɔʁ.tɑ̃/ · adj |
| [force](https://en.wiktionary.org/wiki/force#French) | force | /fɔʁs/ · noun |
| [lire](https://en.wiktionary.org/wiki/lire#French) | to read | /liʁ/ · verb |
| [mot](https://en.wiktionary.org/wiki/mot#French) | word | /mo/ · noun |
| [train](https://en.wiktionary.org/wiki/train#French) | train (rail mounted vehicle) | /tʁɛ̃/ · noun |
| [autour](https://en.wiktionary.org/wiki/autour#French) | around | /o.tuʁ/ · adv |
| [avis](https://en.wiktionary.org/wiki/avis#French) | opinion | /a.vi/ · noun |
| [hier](https://en.wiktionary.org/wiki/hier#French) | yesterday | /jɛʁ/ · adv |
| [vivre](https://en.wiktionary.org/wiki/vivre#French) | to live | /vivʁ/ · verb |
| [ouais](https://en.wiktionary.org/wiki/ouais#French) | synonym of oui; yeah, yep, yup, yes, affirmative expression | /wɛ/ · intj |
| [abord](https://en.wiktionary.org/wiki/abord#French) | the manner with which one acts in the presence of another person or persons, especially in a first encounter | /a.bɔʁ/ · noun |
| [frère](https://en.wiktionary.org/wiki/fr%C3%A8re#French) | brother (son of the same parents as another person) | /fʁɛʁ/ · noun |
| [janvier](https://en.wiktionary.org/wiki/janvier#French) | January | /ʒɑ̃.vje/ · noun |
| [action](https://en.wiktionary.org/wiki/action#French) | action, act, deed | /ak.sjɔ̃/ · noun |
| [club](https://en.wiktionary.org/wiki/club#French) | club (an association of members joining together for some common purpose, especially sports or recreation) | /klœb/ · noun |

</details>

<details><summary>Words 151–200</summary>

![[Resources/Audio/fr/Words 0151-0200.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [culture](https://en.wiktionary.org/wiki/culture#French) | farming, cultivation, crop growing | /kyl.tyʁ/ · noun |
| [cœur](https://en.wiktionary.org/wiki/c%C5%93ur#French) | heart (organ) | /kœʁ/ · noun |
| [programme](https://en.wiktionary.org/wiki/programme#French) | a program (set of structured activities) | /pʁɔ.ɡʁam/ · noun |
| [direction](https://en.wiktionary.org/wiki/direction#French) | direction | /di.ʁɛk.sjɔ̃/ · noun |
| [chance](https://en.wiktionary.org/wiki/chance#French) | chance | /ʃɑ̃s/ · noun |
| [date](https://en.wiktionary.org/wiki/date#French) | date (point in time) | /dat/ · noun |
| [dix](https://en.wiktionary.org/wiki/dix#French) | ten | /dis/ · num |
| [mode](https://en.wiktionary.org/wiki/mode#French) | fashion, trend | /mɔd/ · noun |
| [six](https://en.wiktionary.org/wiki/six#French) | six | /sis/ · num |
| [X](https://en.wiktionary.org/wiki/X#French) | X-frame stool | /iks/ · noun |
| [blanc](https://en.wiktionary.org/wiki/blanc#French) | white color | /blɑ̃/ · adj |
| [photo](https://en.wiktionary.org/wiki/photo#French) | photo | /fɔ.to/ · noun |
| [premier ministre](https://en.wiktionary.org/wiki/premier%20ministre#French) | prime minister; premier | /pʁə.mje mi.nistʁ/ · noun |
| [attention](https://en.wiktionary.org/wiki/attention#French) | attention (mental focus) | /a.tɑ̃.sjɔ̃/ · noun |
| [bout](https://en.wiktionary.org/wiki/bout#French) | end, extremity, tip (of a physical object) | /bu/ · noun |
| [noir](https://en.wiktionary.org/wiki/noir#French) | black in colour | /nwaʁ/ · adj |
| [rouge](https://en.wiktionary.org/wiki/rouge#French) | red (of a red color) | /ʁuʒ/ · adj |
| [bonjour](https://en.wiktionary.org/wiki/bonjour#French) | greetings; hello (general salutation) | /bɔ̃.ʒuʁ/ · noun |
| [langue](https://en.wiktionary.org/wiki/langue#French) | tongue | /lɑ̃ɡ/ · noun |
| [occasion](https://en.wiktionary.org/wiki/occasion#French) | occasion, opportunity | /ɔ.ka.zjɔ̃/ · noun |
| [cadre](https://en.wiktionary.org/wiki/cadre#French) | frame (of a door or picture) | /kadʁ/ · noun |
| [libre](https://en.wiktionary.org/wiki/libre#French) | free, at liberty | /libʁ/ · adj |
| [facile](https://en.wiktionary.org/wiki/facile#French) | easy, simple | /fa.sil/ · adj |
| [image](https://en.wiktionary.org/wiki/image#French) | picture, image | /i.maʒ/ · noun |
| [mer](https://en.wiktionary.org/wiki/mer#French) | sea (large body of water) | /mɛʁ/ · noun |
| [source](https://en.wiktionary.org/wiki/source#French) | source, spring (of water) | /suʁs/ · noun |
| [ami](https://en.wiktionary.org/wiki/ami#French) | friend (one who is affectionately attached to another) | /a.mi/ · noun |
| [coupe](https://en.wiktionary.org/wiki/coupe#French) | goblet, cup | /kup/ · noun |
| [homme d'affaires](https://en.wiktionary.org/wiki/homme%20d%27affaires#French) | a businessman | /ɔm d‿a.fɛʁ/ · noun |
| [oh](https://en.wiktionary.org/wiki/oh#French) | oh | /o/ · intj |
| [seconde](https://en.wiktionary.org/wiki/seconde#French) | second (for indicating time) | /sə.ɡɔ̃d/ · noun |
| [cher](https://en.wiktionary.org/wiki/cher#French) | dear, beloved | /ʃɛʁ/ · adj |
| [dû](https://en.wiktionary.org/wiki/d%C3%BB#French) | what is owed, what is due, money's worth | /dy/ · noun |
| [appel](https://en.wiktionary.org/wiki/appel#French) | call | /a.pɛl/ · noun |
| [certain](https://en.wiktionary.org/wiki/certain#French) | certain, guaranteed (sure, positive) | /sɛʁ.tɛ̃/ · adj |
| [position](https://en.wiktionary.org/wiki/position#French) | position | /po.zi.sjɔ̃/ · noun |
| [carte](https://en.wiktionary.org/wiki/carte#French) | card | /kaʁt/ · noun |
| [nature](https://en.wiktionary.org/wiki/nature#French) | nature | /na.tyʁ/ · noun |
| [bientôt](https://en.wiktionary.org/wiki/bient%C3%B4t#French) | soon | /bjɛ̃.to/ · adv |
| [passage](https://en.wiktionary.org/wiki/passage#French) | the act of going through a place or event | /pa.saʒ/ · noun |
| [sein](https://en.wiktionary.org/wiki/sein#French) | breast (the chest) | /sɛ̃/ · noun |
| [sort](https://en.wiktionary.org/wiki/sort#French) | fate, destiny (consequences or effects predetermined by past events or a divine will) | /sɔʁ/ · noun |
| [OK](https://en.wiktionary.org/wiki/OK#French) | OK (endorsement; approval) | /ɔk/ · intj |
| [bureau](https://en.wiktionary.org/wiki/bureau#French) | desk | /by.ʁo/ · noun |
| [pied](https://en.wiktionary.org/wiki/pied#French) | foot | /pje/ · noun |
| [commission](https://en.wiktionary.org/wiki/commission#French) | commission (fee charged by an agent or broker for carrying out a transaction) | /kɔ.mi.sjɔ̃/ · noun |
| [lit](https://en.wiktionary.org/wiki/lit#French) | bed | /li/ · noun |
| [numéro](https://en.wiktionary.org/wiki/num%C3%A9ro#French) | number | /ny.me.ʁo/ · noun |
| [soleil](https://en.wiktionary.org/wiki/soleil#French) | sun (star) | /sɔ.lɛj/ · noun |
| [ex](https://en.wiktionary.org/wiki/ex#French) | ex (former partner) | /ɛks/ · noun |

</details>

<details><summary>Words 201–250</summary>

![[Resources/Audio/fr/Words 0201-0250.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [manger](https://en.wiktionary.org/wiki/manger#French) | to eat | /mɑ̃.ʒe/ · verb |
| [ben](https://en.wiktionary.org/wiki/ben#French) | Well; uh | /bɛ̃/ · intj |
| [monsieur](https://en.wiktionary.org/wiki/monsieur#French) | mister, sir (a title or form of address for a man, used with or without the name in direct or third-person address) | /mə.sjø/ · noun |
| [proche](https://en.wiktionary.org/wiki/proche#French) | close, near, closeby, nearby (to a place) | /pʁɔʃ/ · adj |
| [administration](https://en.wiktionary.org/wiki/administration#French) | management (administration; the process or practice of managing) | /ad.mi.nis.tʁa.sjɔ̃/ · noun |
| [code](https://en.wiktionary.org/wiki/code#French) | code | /kɔd/ · noun |
| [ouest](https://en.wiktionary.org/wiki/ouest#French) | west | /wɛst/ · noun |
| [sept](https://en.wiktionary.org/wiki/sept#French) | seven | /sɛt/ · num |
| [sol](https://en.wiktionary.org/wiki/sol#French) | soil, earth | /sɔl/ · noun |
| [double](https://en.wiktionary.org/wiki/double#French) | double (all senses), two | /dubl/ · adj |
| [information](https://en.wiktionary.org/wiki/information#French) | piece of information] | /ɛ̃.fɔʁ.ma.sjɔ̃/ · noun |
| [mission](https://en.wiktionary.org/wiki/mission#French) | mission (duty that involves fulfilling a request) | /mi.sjɔ̃/ · noun |
| [page](https://en.wiktionary.org/wiki/page#French) | page (of a book, etc.) | /paʒ/ · noun |
| [prêt](https://en.wiktionary.org/wiki/pr%C3%AAt#French) | ready | /pʁɛ/ · adj |
| [technique](https://en.wiktionary.org/wiki/technique#French) | technical | /tɛk.nik/ · adj |
| [tour de force](https://en.wiktionary.org/wiki/tour%20de%20force#French) | tour de force | /tuʁ də fɔʁs/ · noun |
| [union](https://en.wiktionary.org/wiki/union#French) | union | /y.njɔ̃/ · noun |
| [bien entendu](https://en.wiktionary.org/wiki/bien%20entendu#French) | well understood | /bjɛ̃.n‿ɑ̃.tɑ̃.dy/ · adv |
| [bord](https://en.wiktionary.org/wiki/bord#French) | border, edge, limit; boundary | /bɔʁ/ · noun |
| [finale](https://en.wiktionary.org/wiki/finale#French) | final, finals (game between the last two competitors remaining in the running, in elimination tournaments) | /fi.nal/ · noun |
| [impossible](https://en.wiktionary.org/wiki/impossible#French) | impossible | /ɛ̃.pɔ.sibl/ · adj |
| [sang](https://en.wiktionary.org/wiki/sang#French) | blood | /sɑ̃/ · noun |
| [second](https://en.wiktionary.org/wiki/second#French) | second | /sə.ɡɔ̃/ · adj |
| [faux](https://en.wiktionary.org/wiki/faux#French) | false; untrue | /fo/ · adj |
| [note](https://en.wiktionary.org/wiki/note#French) | note (written or spoken) | /nɔt/ · noun |
| [adresse](https://en.wiktionary.org/wiki/adresse#French) | address (the description or instructions to determine a geographic location) | /a.dʁɛs/ · noun |
| [dos](https://en.wiktionary.org/wiki/dos#French) | back (of a person) | /do/ · noun |
| [huit](https://en.wiktionary.org/wiki/huit#French) | eight | /ɥit/ · num |
| [physique](https://en.wiktionary.org/wiki/physique#French) | physical, sportive | /fi.zik/ · adj |
| [unique](https://en.wiktionary.org/wiki/unique#French) | unique | /y.nik/ · adj |
| [via](https://en.wiktionary.org/wiki/via#French) | via, through, by way of | /vja/ · prep |
| [coup de pied](https://en.wiktionary.org/wiki/coup%20de%20pied#French) | kick | /ku də pje/ · noun |
| [cul](https://en.wiktionary.org/wiki/cul#French) | the bottom, rear (of an object) | /ky/ · noun |
| [lettre](https://en.wiktionary.org/wiki/lettre#French) | letter (written character) | /lɛtʁ/ · noun |
| [parole](https://en.wiktionary.org/wiki/parole#French) | speech, language (the faculty of using spoken language to communicate or express thought, the usage of this faculty, and the words articulated through its use) | /pa.ʁɔl/ · noun |
| [radio](https://en.wiktionary.org/wiki/radio#French) | radio, tuner | /ʁa.djo/ · noun |
| [table](https://en.wiktionary.org/wiki/table#French) | table (furniture with a top surface to accommodate a variety of uses) | /tabl/ · noun |
| [analyse](https://en.wiktionary.org/wiki/analyse#French) | analysis | /a.na.liz/ · noun |
| [couleur](https://en.wiktionary.org/wiki/couleur#French) | color/colour | /ku.lœʁ/ · noun |
| [large](https://en.wiktionary.org/wiki/large#French) | wide, broad | /laʁʒ/ · adj |
| [neuf](https://en.wiktionary.org/wiki/neuf#French) | nine | /nœf/ · num |
| [pro](https://en.wiktionary.org/wiki/pro#French) | professional | /pʁo/ · adj |
| [respect](https://en.wiktionary.org/wiki/respect#French) | respect | /ʁɛs.pɛ/ · noun |
| [change](https://en.wiktionary.org/wiki/change#French) | exchange | /ʃɑ̃ʒ/ · noun |
| [course](https://en.wiktionary.org/wiki/course#French) | run, running | /kuʁs/ · noun |
| [fou](https://en.wiktionary.org/wiki/fou#French) | mad, crazy | /fu/ · adj |
| [village](https://en.wiktionary.org/wiki/village#French) | village | /vi.laʒ/ · noun |
| [clair](https://en.wiktionary.org/wiki/clair#French) | clear (see-through) | /klɛʁ/ · adj |
| [affaire de cœur](https://en.wiktionary.org/wiki/affaire%20de%20c%C5%93ur#French) | matter of the heart, affair of the heart (matter relating to one's love life) | /a.fɛʁ də kœʁ/ · noun |
| [album](https://en.wiktionary.org/wiki/album#French) | album (all meanings) | /al.bɔm/ · noun |

</details>

<details><summary>Words 251–300</summary>

![[Resources/Audio/fr/Words 0251-0300.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [vote](https://en.wiktionary.org/wiki/vote#French) | vote | /vɔt/ · noun |
| [application](https://en.wiktionary.org/wiki/application#French) | application | /a.pli.ka.sjɔ̃/ · noun |
| [final](https://en.wiktionary.org/wiki/final#French) | final (last) | /fi.nal/ · adj |
| [maire](https://en.wiktionary.org/wiki/maire#French) | mayor | /mɛʁ/ · noun |
| [visage](https://en.wiktionary.org/wiki/visage#French) | face (of a human) | /vi.zaʒ/ · noun |
| [chien](https://en.wiktionary.org/wiki/chien#French) | dog | /ʃjɛ̃/ · noun |
| [cool](https://en.wiktionary.org/wiki/cool#French) | cool (only its informal senses, mainly fashionable) | /kul/ · adj |
| [port](https://en.wiktionary.org/wiki/port#French) | port, harbour | /pɔʁ/ · noun |
| [transport](https://en.wiktionary.org/wiki/transport#French) | transport | /tʁɑ̃s.pɔʁ/ · noun |
| [marine](https://en.wiktionary.org/wiki/marine#French) | navy | /ma.ʁin/ · noun |
| [religion](https://en.wiktionary.org/wiki/religion#French) | religion | /ʁə.li.ʒjɔ̃/ · noun |
| [regard](https://en.wiktionary.org/wiki/regard#French) | look, glance | /ʁə.ɡaʁ/ · noun |
| [rêve](https://en.wiktionary.org/wiki/r%C3%AAve#French) | dream | /ʁɛv/ · noun |
| [science](https://en.wiktionary.org/wiki/science#French) | science (field of study, etc.) | /sjɑ̃s/ · noun |
| [absence](https://en.wiktionary.org/wiki/absence#French) | absence (state of being absent or withdrawn) | /ap.sɑ̃s/ · noun |
| [blanche](https://en.wiktionary.org/wiki/blanche#French) | minim, half note | /blɑ̃ʃ/ · noun |
| [secret](https://en.wiktionary.org/wiki/secret#French) | secret | /sə.kʁɛ/ · adj |
| [top](https://en.wiktionary.org/wiki/top#French) | top; shirt or garment covering the upper body | /tɔp/ · noun |
| [usage](https://en.wiktionary.org/wiki/usage#French) | usage, use | /y.zaʒ/ · noun |
| [dame](https://en.wiktionary.org/wiki/dame#French) | lady | /dam/ · noun |
| [direct](https://en.wiktionary.org/wiki/direct#French) | direct | /di.ʁɛkt/ · adj |
| [expression](https://en.wiktionary.org/wiki/expression#French) | expression | /ɛk.spʁɛ.sjɔ̃/ · noun |
| [fer](https://en.wiktionary.org/wiki/fer#French) | iron | /fɛʁ/ · noun |
| [fil](https://en.wiktionary.org/wiki/fil#French) | yarn, thread, wire | /fil/ · noun |
| [futur](https://en.wiktionary.org/wiki/futur#French) | future | /fy.tyʁ/ · adj |
| [tableau](https://en.wiktionary.org/wiki/tableau#French) | painting | /ta.blo/ · noun |
| [goût](https://en.wiktionary.org/wiki/go%C3%BBt#French) | taste, flavour | /ɡu/ · noun |
| [madame](https://en.wiktionary.org/wiki/madame#French) | a title or form of address for a woman, formerly for a married woman and now commonly for any adult woman regardless of marital status, used both in direct and third-person address | /ma.dam/ · noun |
| [parlement](https://en.wiktionary.org/wiki/parlement#French) | parliament | /paʁ.lə.mɑ̃/ · noun |
| [surface](https://en.wiktionary.org/wiki/surface#French) | surface | /syʁ.fas/ · noun |
| [allemand](https://en.wiktionary.org/wiki/allemand#French) | German (The German language) | /al.mɑ̃/ · noun |
| [arrêt](https://en.wiktionary.org/wiki/arr%C3%AAt#French) | stopping, checking, arrest (in development, growth, machinery etc.) | /a.ʁɛ/ · noun |
| [cru](https://en.wiktionary.org/wiki/cru#French) | raw (uncooked, unprocessed) | /kʁy/ · adj |
| [prince](https://en.wiktionary.org/wiki/prince#French) | prince | /pʁɛ̃s/ · noun |
| [province](https://en.wiktionary.org/wiki/province#French) | province | /pʁɔ.vɛ̃s/ · noun |
| [vent](https://en.wiktionary.org/wiki/vent#French) | wind | /vɑ̃/ · noun |
| [acte](https://en.wiktionary.org/wiki/acte#French) | act | /akt/ · noun |
| [opposition](https://en.wiktionary.org/wiki/opposition#French) | opposition | /ɔ.po.zi.sjɔ̃/ · noun |
| [sœur](https://en.wiktionary.org/wiki/s%C5%93ur#French) | sister (a daughter of the same parents as another person; a female sibling) | /sœʁ/ · noun |
| [front](https://en.wiktionary.org/wiki/front#French) | forehead | /fʁɔ̃/ · noun |
| [papier](https://en.wiktionary.org/wiki/papier#French) | paper (A material used for writing or printing on, made from cellulose pulp rolled into thin sheets) | /pa.pje/ · noun |
| [accident](https://en.wiktionary.org/wiki/accident#French) | accident | /ak.si.dɑ̃/ · noun |
| [bien perdu, bien connu](https://en.wiktionary.org/wiki/bien%20perdu%2C%20bien%20connu#French) | That which is well lost is well known, or what once was lost is prized | /bjɛ̃ pɛʁ.dy | bjɛ̃ kɔ.ny/ · phrase |
| [courage](https://en.wiktionary.org/wiki/courage#French) | courage | /ku.ʁaʒ/ · noun |
| [festival](https://en.wiktionary.org/wiki/festival#French) | festival | /fɛs.ti.val/ · noun |
| [jeudi](https://en.wiktionary.org/wiki/jeudi#French) | Thursday (day of the week) | /ʒø.di/ · noun |
| [tuer](https://en.wiktionary.org/wiki/tuer#French) | to kill | /tɥe/ · verb |
| [café](https://en.wiktionary.org/wiki/caf%C3%A9#French) | coffee (drink) | /ka.fe/ · noun |
| [chat](https://en.wiktionary.org/wiki/chat#French) | cat (feline) | /ʃa/ · noun |
| [coin](https://en.wiktionary.org/wiki/coin#French) | wedge, cornerpiece | /kwɛ̃/ · noun |

</details>

<details><summary>Words 301–350</summary>

![[Resources/Audio/fr/Words 0301-0350.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [homme de lettres](https://en.wiktionary.org/wiki/homme%20de%20lettres#French) | homme de lettres, man of letters | /ɔm də lɛtʁ/ · noun |
| [martin](https://en.wiktionary.org/wiki/martin#French) | bird of either the starling family, or of the kingfisher family | /maʁ.tɛ̃/ · noun |
| [mi](https://en.wiktionary.org/wiki/mi#French) | mi, the note 'E' | /mi/ · noun |
| [remettre](https://en.wiktionary.org/wiki/remettre#French) | to put back, replace | /ʁə.mɛtʁ/ · verb |
| [violence](https://en.wiktionary.org/wiki/violence#French) | violence | /vjɔ.lɑ̃s/ · noun |
| [bleu](https://en.wiktionary.org/wiki/bleu#French) | blue | /blø/ · adj |
| [danger](https://en.wiktionary.org/wiki/danger#French) | danger | /dɑ̃.ʒe/ · noun |
| [football](https://en.wiktionary.org/wiki/football#French) | association football, soccer | /fut.bol/ · noun |
| [opinion](https://en.wiktionary.org/wiki/opinion#French) | opinion (thought, estimation) | /ɔ.pi.njɔ̃/ · noun |
| [salle à manger](https://en.wiktionary.org/wiki/salle%20%C3%A0%20manger#French) | dining room | /sa.l‿a mɑ̃.ʒe/ · noun |
| [verre](https://en.wiktionary.org/wiki/verre#French) | glass (substance) | /vɛʁ/ · noun |
| [bus](https://en.wiktionary.org/wiki/bus#French) | bus | /bys/ · noun |
| [content](https://en.wiktionary.org/wiki/content#French) | content, satisfied, pleased | /kɔ̃.tɑ̃/ · adj |
| [distance](https://en.wiktionary.org/wiki/distance#French) | distance (literal physical distance) | /dis.tɑ̃s/ · noun |
| [figure](https://en.wiktionary.org/wiki/figure#French) | face | /fi.ɡyʁ/ · noun |
| [influence](https://en.wiktionary.org/wiki/influence#French) | influence | /ɛ̃.fly.ɑ̃s/ · noun |
| [quitter](https://en.wiktionary.org/wiki/quitter#French) | to leave, to quit | /ki.te/ · verb |
| [vert](https://en.wiktionary.org/wiki/vert#French) | green | /vɛʁ/ · noun |
| [empire](https://en.wiktionary.org/wiki/empire#French) | empire | /ɑ̃.piʁ/ · noun |
| [existence](https://en.wiktionary.org/wiki/existence#French) | existence | /ɛɡ.zis.tɑ̃s/ · noun |
| [château](https://en.wiktionary.org/wiki/ch%C3%A2teau#French) | castle (fortified building or similar structure; winegrower's estate) | /ʃa.to/ · noun |
| [don](https://en.wiktionary.org/wiki/don#French) | gift, talent, knack | /dɔ̃/ · noun |
| [faux-ami](https://en.wiktionary.org/wiki/faux-ami#French) | false friend | /fo.z‿a.mi/ · noun |
| [machine](https://en.wiktionary.org/wiki/machine#French) | machine, device | /ma.ʃin/ · noun |
| [rose](https://en.wiktionary.org/wiki/rose#French) | rose (flower) | /ʁoz/ · noun |
| [silence](https://en.wiktionary.org/wiki/silence#French) | silence | /si.lɑ̃s/ · noun |
| [vice](https://en.wiktionary.org/wiki/vice#French) | vice (bad habit) | /vis/ · noun |
| [vision](https://en.wiktionary.org/wiki/vision#French) | vision, sight | /vi.zjɔ̃/ · noun |
| [augmentation](https://en.wiktionary.org/wiki/augmentation#French) | an increase, a raise | /oɡ.mɑ̃.ta.sjɔ̃/ · noun |
| [bruit](https://en.wiktionary.org/wiki/bruit#French) | a noise | /bʁɥi/ · noun |
| [dix-neuf](https://en.wiktionary.org/wiki/dix-neuf#French) | nineteen | /diz.nœf/ · num |
| [roman](https://en.wiktionary.org/wiki/roman#French) | Romance | /ʁɔ.mɑ̃/ · adj |
| [star](https://en.wiktionary.org/wiki/star#French) | star (celebrity) | /staʁ/ · noun |
| [capital](https://en.wiktionary.org/wiki/capital#French) | capital (money and wealth) | /ka.pi.tal/ · noun |
| [cheval](https://en.wiktionary.org/wiki/cheval#French) | horse | /ʃə.val/ · noun |
| [moteur](https://en.wiktionary.org/wiki/moteur#French) | motor, engine | /mɔ.tœʁ/ · noun |
| [patron](https://en.wiktionary.org/wiki/patron#French) | a boss, employer, | /pa.tʁɔ̃/ · noun |
| [souvenir](https://en.wiktionary.org/wiki/souvenir#French) | to remember | /su.v(ə).niʁ/ · verb |
| [test](https://en.wiktionary.org/wiki/test#French) | test, a cupel or cupelling hearth in which precious metals are melted for trial and refinement | /tɛst/ · noun |
| [van](https://en.wiktionary.org/wiki/van#French) | a winnowing basket | /vɑ̃/ · noun |
| [TV](https://en.wiktionary.org/wiki/TV#French) | television | /te.ve/ · noun |
| [arme](https://en.wiktionary.org/wiki/arme#French) | weapon | /aʁm/ · noun |
| [minute](https://en.wiktionary.org/wiki/minute#French) | minute (etymology 1, time unit, all same senses) | /mi.nyt/ · noun |
| [phase](https://en.wiktionary.org/wiki/phase#French) | phase | /faz/ · noun |
| [accepter](https://en.wiktionary.org/wiki/accepter#French) | to accept | /ak.sɛp.te/ · verb |
| [agent](https://en.wiktionary.org/wiki/agent#French) | agent | /a.ʒɑ̃/ · noun |
| [auto](https://en.wiktionary.org/wiki/auto#French) | car | /o.to/ · noun |
| [cancer](https://en.wiktionary.org/wiki/cancer#French) | cancer | /kɑ̃.sɛʁ/ · noun |
| [constitution](https://en.wiktionary.org/wiki/constitution#French) | constitution (formal or informal system of primary principles and laws that regulates a government or other institutions; legal document describing such a formal system) | /kɔ̃s.ti.ty.sjɔ̃/ · noun |
| [impact](https://en.wiktionary.org/wiki/impact#French) | impact | /ɛ̃.pakt/ · noun |

</details>

<details><summary>Words 351–400</summary>

![[Resources/Audio/fr/Words 0351-0400.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [local](https://en.wiktionary.org/wiki/local#French) | local | /lɔ.kal/ · adj |
| [accueil](https://en.wiktionary.org/wiki/accueil#French) | reception, hospitality | /a.kœj/ · noun |
| [aimer](https://en.wiktionary.org/wiki/aimer#French) | to love (usually of a person, otherwise the meaning is closer to English like) | /ɛ.me/ · verb |
| [cent](https://en.wiktionary.org/wiki/cent#French) | hundred | /sɑ̃/ · num |
| [condition](https://en.wiktionary.org/wiki/condition#French) | term, condition | /kɔ̃.di.sjɔ̃/ · noun |
| [dormir](https://en.wiktionary.org/wiki/dormir#French) | to sleep | /dɔʁ.miʁ/ · verb |
| [jaune](https://en.wiktionary.org/wiki/jaune#French) | yellow | /ʒon/ · adj |
| [minimum](https://en.wiktionary.org/wiki/minimum#French) | minimum | /mi.ni.mɔm/ · noun |
| [phrase](https://en.wiktionary.org/wiki/phrase#French) | sentence | /fʁaz/ · noun |
| [us](https://en.wiktionary.org/wiki/us#French) | mores; traditional practices or manners | /ys/ · noun |
| [œil](https://en.wiktionary.org/wiki/%C5%93il#French) | eye, organ that is sensitive to light, helping organisms to see | /œj/ · noun |
| [bar](https://en.wiktionary.org/wiki/bar#French) | bar (establishment) | /baʁ/ · noun |
| [champion](https://en.wiktionary.org/wiki/champion#French) | champion | /ʃɑ̃.pjɔ̃/ · noun |
| [crime](https://en.wiktionary.org/wiki/crime#French) | a category of severe offences within French law, comparable to a felony under United States laws. Crime are tied to the strongest of penalties, 10 years and more according to law. | /kʁim/ · noun |
| [description](https://en.wiktionary.org/wiki/description#French) | description | /dɛs.kʁip.sjɔ̃/ · noun |
| [dos-à-dos](https://en.wiktionary.org/wiki/dos-%C3%A0-dos#French) | back to back | /do.za.do/ · adj |
| [pain](https://en.wiktionary.org/wiki/pain#French) | bread | /pɛ̃/ · noun |
| [canal](https://en.wiktionary.org/wiki/canal#French) | canal | /ka.nal/ · noun |
| [maximum](https://en.wiktionary.org/wiki/maximum#French) | maximum | /mak.si.mɔm/ · noun |
| [piste](https://en.wiktionary.org/wiki/piste#French) | track or trail (left by an animal or person) | /pist/ · noun |
| [volume](https://en.wiktionary.org/wiki/volume#French) | volume (of a book, a written work) | /vɔ.lym/ · noun |
| [boire](https://en.wiktionary.org/wiki/boire#French) | to drink | /bwaʁ/ · verb |
| [discussion](https://en.wiktionary.org/wiki/discussion#French) | debate, argument (a civil exchange of contradictory points of view) | /dis.ky.sjɔ̃/ · noun |
| [distribution](https://en.wiktionary.org/wiki/distribution#French) | delivery | /dis.tʁi.by.sjɔ̃/ · noun |
| [division](https://en.wiktionary.org/wiki/division#French) | division (act or process of dividing) | /di.vi.zjɔ̃/ · noun |
| [mandat](https://en.wiktionary.org/wiki/mandat#French) | mandate | /mɑ̃.da/ · noun |
| [net](https://en.wiktionary.org/wiki/net#French) | clean, tidy | /nɛt/ · adj |
| [représentant](https://en.wiktionary.org/wiki/repr%C3%A9sentant#French) | representative | /ʁə.pʁe.zɑ̃.tɑ̃/ · noun |
| [sale](https://en.wiktionary.org/wiki/sale#French) | dirty | /sal/ · adj |
| [animal](https://en.wiktionary.org/wiki/animal#French) | animal | /a.ni.mal/ · noun |
| [cap](https://en.wiktionary.org/wiki/cap#French) | cape | /kap/ · noun |
| [démocratie](https://en.wiktionary.org/wiki/d%C3%A9mocratie#French) | democracy | /de.mɔ.kʁa.si/ · noun |
| [formule](https://en.wiktionary.org/wiki/formule#French) | formula | /fɔʁ.myl/ · noun |
| [lune](https://en.wiktionary.org/wiki/lune#French) | the Moon | /lyn/ · noun |
| [office](https://en.wiktionary.org/wiki/office#French) | charge, task, mandate | /ɔ.fis/ · noun |
| [profit](https://en.wiktionary.org/wiki/profit#French) | profit, benefit | /pʁɔ.fi/ · noun |
| [restaurant](https://en.wiktionary.org/wiki/restaurant#French) | restaurant | /ʁɛs.tɔ.ʁɑ̃/ · noun |
| [seine](https://en.wiktionary.org/wiki/seine#French) | seine (for fishing) | /sɛn/ · noun |
| [avoir faim](https://en.wiktionary.org/wiki/avoir%20faim#French) | to be hungry | /a.vwaʁ fɛ̃/ · verb |
| [coup d'œil](https://en.wiktionary.org/wiki/coup%20d%27%C5%93il#French) | glance, look | /ku d‿œj/ · noun |
| [euro](https://en.wiktionary.org/wiki/euro#French) | euro (currency) | /ø.ʁo/ · noun |
| [gratuit](https://en.wiktionary.org/wiki/gratuit#French) | free of charge | /ɡʁa.tɥi/ · adj |
| [mobile](https://en.wiktionary.org/wiki/mobile#French) | mobile | /mɔ.bil/ · adj |
| [orange](https://en.wiktionary.org/wiki/orange#French) | orange (fruit) | /ɔ.ʁɑ̃ʒ/ · noun |
| [race](https://en.wiktionary.org/wiki/race#French) | race (classification) | /ʁas/ · noun |
| [central](https://en.wiktionary.org/wiki/central#French) | central | /sɑ̃.tʁal/ · adj |
| [métro](https://en.wiktionary.org/wiki/m%C3%A9tro#French) | metro; subway (US), underground (UK), Tube (UK) | /me.tʁo/ · noun |
| [trente](https://en.wiktionary.org/wiki/trente#French) | thirty | /tʁɑ̃t/ · num |
| [black](https://en.wiktionary.org/wiki/black#French) | of black people or culture | /blak/ · adj |
| [humour](https://en.wiktionary.org/wiki/humour#French) | humor; comic effect in a communication or performance | /y.muʁ/ · noun |

</details>

<details><summary>Words 401–450</summary>

![[Resources/Audio/fr/Words 0401-0450.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [rang](https://en.wiktionary.org/wiki/rang#French) | row or line of things placed side-by-side | /ʁɑ̃/ · noun |
| [alliance](https://en.wiktionary.org/wiki/alliance#French) | alliance, union | /a.ljɑ̃s/ · noun |
| [arbre](https://en.wiktionary.org/wiki/arbre#French) | tree (plant, diagram, anything in the form of a tree) | /aʁbʁ/ · noun |
| [bel](https://en.wiktionary.org/wiki/bel#French) | bel (unit of sound intensity) | /bɛl/ · noun |
| [papa](https://en.wiktionary.org/wiki/papa#French) | papa, a child's father; also as form of address: dad, daddy | /pa.pa/ · noun |
| [passion](https://en.wiktionary.org/wiki/passion#French) | Passion, suffering | /pa.sjɔ̃/ · noun |
| [royal](https://en.wiktionary.org/wiki/royal#French) | royal | /ʁwa.jal/ · adj |
| [s'il vous plaît](https://en.wiktionary.org/wiki/s%27il%20vous%20pla%C3%AEt#French) | please, if you please | /s‿il vu plɛ/ · phrase |
| [blog](https://en.wiktionary.org/wiki/blog#French) | blog | /blɔɡ/ · noun |
| [conversation](https://en.wiktionary.org/wiki/conversation#French) | conversation | /kɔ̃.vɛʁ.sa.sjɔ̃/ · noun |
| [japonais](https://en.wiktionary.org/wiki/japonais#French) | the Japanese language | /ʒa.pɔ.nɛ/ · noun |
| [marcher](https://en.wiktionary.org/wiki/marcher#French) | to walk | /maʁ.ʃe/ · verb |
| [neige](https://en.wiktionary.org/wiki/neige#French) | snow, crystalline frozen precipitation | /nɛʒ/ · noun |
| [uni](https://en.wiktionary.org/wiki/uni#French) | united | /y.ni/ · adj |
| [vélo](https://en.wiktionary.org/wiki/v%C3%A9lo#French) | bike, bicycle, cycle | /ve.lo/ · noun |
| [doux](https://en.wiktionary.org/wiki/doux#French) | sweet | /du/ · adj |
| [langage](https://en.wiktionary.org/wiki/langage#French) | language: word choice and usage | /lɑ̃.ɡaʒ/ · noun |
| [original](https://en.wiktionary.org/wiki/original#French) | original | /ɔ.ʁi.ʒi.nal/ · adj |
| [talent](https://en.wiktionary.org/wiki/talent#French) | a talent, a gift, a knack | /ta.lɑ̃/ · noun |
| [bravo](https://en.wiktionary.org/wiki/bravo#French) | bravo!, hear, hear!, well said!, well done! | /bʁa.vo/ · intj |
| [convention](https://en.wiktionary.org/wiki/convention#French) | convention, agreement | /kɔ̃.vɑ̃.sjɔ̃/ · noun |
| [fier](https://en.wiktionary.org/wiki/fier#French) | proud, gratified, honoured | /fjɛʁ/ · adj |
| [lever](https://en.wiktionary.org/wiki/lever#French) | to raise, lift | /lə.ve/ · verb |
| [mini](https://en.wiktionary.org/wiki/mini#French) | small; tiny | /mi.ni/ · adj |
| [option](https://en.wiktionary.org/wiki/option#French) | option | /ɔp.sjɔ̃/ · noun |
| [tort](https://en.wiktionary.org/wiki/tort#French) | fault | /tɔʁ/ · noun |
| [trou](https://en.wiktionary.org/wiki/trou#French) | hole | /tʁu/ · noun |
| [étudiant](https://en.wiktionary.org/wiki/%C3%A9tudiant#French) | student | /e.ty.djɑ̃/ · noun |
| [million](https://en.wiktionary.org/wiki/million#French) | million (10⁶) | /mi.ljɔ̃/ · num |
| [tire](https://en.wiktionary.org/wiki/tire#French) | taffy, especially maple taffy |  · noun |
| [douze](https://en.wiktionary.org/wiki/douze#French) | twelve | /duz/ · num |
| [former](https://en.wiktionary.org/wiki/former#French) | to form (generic sense) | /fɔʁ.me/ · verb |
| [frappe](https://en.wiktionary.org/wiki/frappe#French) | hit | /fʁap/ · noun |
| [ha](https://en.wiktionary.org/wiki/ha#French) | ha (exclamation of surprise or laughter) | /ha/ · intj |
| [mélange](https://en.wiktionary.org/wiki/m%C3%A9lange#French) | mixture, blend | /me.lɑ̃ʒ/ · noun |
| [san](https://en.wiktionary.org/wiki/san#French) | san (Greek letter) | /san/ · noun |
| [format](https://en.wiktionary.org/wiki/format#French) | format | /fɔʁ.ma/ · noun |
| [lieutenant](https://en.wiktionary.org/wiki/lieutenant#French) | lieutenant | /ljøt.nɑ̃/ · noun |
| [live](https://en.wiktionary.org/wiki/live#French) | live (as it happens, in real time, directly) |  · adv |
| [magazine](https://en.wiktionary.org/wiki/magazine#French) | magazine (periodical publication) | /ma.ɡa.zin/ · noun |
| [performance](https://en.wiktionary.org/wiki/performance#French) | performance | /pɛʁ.fɔʁ.mɑ̃s/ · noun |
| [score](https://en.wiktionary.org/wiki/score#French) | score (in a sport, game) | /skɔʁ/ · noun |
| [guide](https://en.wiktionary.org/wiki/guide#French) | guide person | /ɡid/ · noun |
| [poisson](https://en.wiktionary.org/wiki/poisson#French) | fish (marine animal) | /pwa.sɔ̃/ · noun |
| [stage](https://en.wiktionary.org/wiki/stage#French) | internship, job that a trainee is doing in a workplace until a fixed date | /staʒ/ · noun |
| [chocolat](https://en.wiktionary.org/wiki/chocolat#French) | chocolate; chocolate-coloured | /ʃɔ.kɔ.la/ · adj |
| [immense](https://en.wiktionary.org/wiki/immense#French) | immense, huge | /i(m).mɑ̃s/ · adj |
| [inverse](https://en.wiktionary.org/wiki/inverse#French) | inverse, the other way round | /ɛ̃.vɛʁs/ · adj |
| [lol](https://en.wiktionary.org/wiki/lol#French) | LOL | /lɔl/ · intj |
| [léger](https://en.wiktionary.org/wiki/l%C3%A9ger#French) | light (not heavy) | /le.ʒe/ · adj |

</details>

<details><summary>Words 451–500</summary>

![[Resources/Audio/fr/Words 0451-0500.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [os](https://en.wiktionary.org/wiki/os#French) | bone | /ɔs/ · noun |
| [pub](https://en.wiktionary.org/wiki/pub#French) | Television ad or advert | /pyb/ · noun |
| [civil](https://en.wiktionary.org/wiki/civil#French) | civil | /si.vil/ · adj |
| [poche](https://en.wiktionary.org/wiki/poche#French) | pocket (part of the clothing) | /pɔʃ/ · noun |
| [rock](https://en.wiktionary.org/wiki/rock#French) | rock (style of music) | /ʁɔk/ · noun |
| [circuit](https://en.wiktionary.org/wiki/circuit#French) | circuit | /siʁ.kɥi/ · noun |
| [fan](https://en.wiktionary.org/wiki/fan#French) | fan (admirer, supporter) | /fan/ · noun |
| [go](https://en.wiktionary.org/wiki/go#French) | go (board game) | /ɡo/ · noun |
| [pause](https://en.wiktionary.org/wiki/pause#French) | pause, break | /poz/ · noun |
| [quart](https://en.wiktionary.org/wiki/quart#French) | quarter, fourth (fraction) | /kaʁ/ · noun |
| [angle](https://en.wiktionary.org/wiki/angle#French) | a geometric angle | /ɑ̃ɡl/ · noun |
| [bière](https://en.wiktionary.org/wiki/bi%C3%A8re#French) | beer | /bjɛʁ/ · noun |
| [pardon](https://en.wiktionary.org/wiki/pardon#French) | excuse me | /paʁ.dɔ̃/ · intj |
| [suicide](https://en.wiktionary.org/wiki/suicide#French) | suicide | /sɥi.sid/ · noun |
| [automobile](https://en.wiktionary.org/wiki/automobile#French) | automotive | /o.tɔ.mɔ.bil/ · adj |
| [do](https://en.wiktionary.org/wiki/do#French) | do, the note 'C' | /do/ · noun |
| [foot](https://en.wiktionary.org/wiki/foot#French) | association football; football, soccer | /fut/ · noun |
| [leader](https://en.wiktionary.org/wiki/leader#French) | leader | /li.dœʁ/ · noun |
| [man](https://en.wiktionary.org/wiki/man#French) | my | /man/ · det |
| [moral](https://en.wiktionary.org/wiki/moral#French) | morale, optimism | /mɔ.ʁal/ · noun |
| [plait](https://en.wiktionary.org/wiki/plait#French) | post-1990 spelling of plaît (third-person singular present indicative of plaire) |  · verb |
| [show](https://en.wiktionary.org/wiki/show#French) | show (entertainment program) | /ʃo/ · noun |
| [vague](https://en.wiktionary.org/wiki/vague#French) | wave | /vaɡ/ · noun |
| [franc](https://en.wiktionary.org/wiki/franc#French) | Frankish, Franconian | /fʁɑ̃/ · adj |
| [lunettes](https://en.wiktionary.org/wiki/lunettes#French) | spectacles, eyeglasses | /ly.nɛt/ · noun |
| [mine](https://en.wiktionary.org/wiki/mine#French) | mine (excavation or explosive) | /min/ · noun |
| [standard](https://en.wiktionary.org/wiki/standard#French) | standard | /stɑ̃.daʁ/ · noun |
| [cycle](https://en.wiktionary.org/wiki/cycle#French) | cycle | /sikl/ · noun |
| [henry](https://en.wiktionary.org/wiki/henry#French) | henry | /ɑ̃.ʁi/ · noun |
| [mail](https://en.wiktionary.org/wiki/mail#French) | maul | /maj/ · noun |
| [queue](https://en.wiktionary.org/wiki/queue#French) | tail | /kø/ · noun |
| [quinze](https://en.wiktionary.org/wiki/quinze#French) | fifteen | /kɛ̃z/ · num |
| [sexy](https://en.wiktionary.org/wiki/sexy#French) | sexy | /sɛk.si/ · adj |
| [apparition](https://en.wiktionary.org/wiki/apparition#French) | appearance | /a.pa.ʁi.sjɔ̃/ · noun |
| [bio](https://en.wiktionary.org/wiki/bio#French) | biological | /bjo/ · adj |
| [dialogue](https://en.wiktionary.org/wiki/dialogue#French) | dialogue | /dja.lɔɡ/ · noun |
| [patient](https://en.wiktionary.org/wiki/patient#French) | patient | /pa.sjɑ̃/ · adj |
| [ski](https://en.wiktionary.org/wiki/ski#French) | ski | /ski/ · noun |
| [temple](https://en.wiktionary.org/wiki/temple#French) | temple (for worship) | /tɑ̃pl/ · noun |
| [bouger](https://en.wiktionary.org/wiki/bouger#French) | to move (in general) | /bu.ʒe/ · verb |
| [cou](https://en.wiktionary.org/wiki/cou#French) | neck | /ku/ · noun |
| [folle](https://en.wiktionary.org/wiki/folle#French) | madwoman | /fɔl/ · noun |
| [fortune](https://en.wiktionary.org/wiki/fortune#French) | fortune; fate, destiny; luck | /fɔʁ.tyn/ · noun |
| [perspective](https://en.wiktionary.org/wiki/perspective#French) | perspective | /pɛʁ.spɛk.tiv/ · noun |
| [tension](https://en.wiktionary.org/wiki/tension#French) | tension | /tɑ̃.sjɔ̃/ · noun |
| [virus](https://en.wiktionary.org/wiki/virus#French) | virus | /vi.ʁys/ · noun |
| [business](https://en.wiktionary.org/wiki/business#French) | business, firm, company | /biz.nɛs/ · noun |
| [job](https://en.wiktionary.org/wiki/job#French) | job (employment role) | /dʒɔb/ · noun |
| [lis](https://en.wiktionary.org/wiki/lis#French) | lily | /lis/ · noun |
| [actrice](https://en.wiktionary.org/wiki/actrice#French) | actress | /ak.tʁis/ · noun |

</details>

<details><summary>Words 501–550</summary>

![[Resources/Audio/fr/Words 0501-0550.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [arc](https://en.wiktionary.org/wiki/arc#French) | bow (weapon) | /aʁk/ · noun |
| [balance](https://en.wiktionary.org/wiki/balance#French) | scales | /ba.lɑ̃s/ · noun |
| [toit](https://en.wiktionary.org/wiki/toit#French) | roof | /twa/ · noun |
| [destruction](https://en.wiktionary.org/wiki/destruction#French) | destruction | /dɛs.tʁyk.sjɔ̃/ · noun |
| [frappé](https://en.wiktionary.org/wiki/frapp%C3%A9#French) | beaten, hit | /fʁa.pe/ · adj |
| [fruit](https://en.wiktionary.org/wiki/fruit#French) | fruit | /fʁɥi/ · noun |
| [sel](https://en.wiktionary.org/wiki/sel#French) | table salt, i.e. sodium chloride (NaCl) | /sɛl/ · noun |
| [transformation](https://en.wiktionary.org/wiki/transformation#French) | transformation | /tʁɑ̃s.fɔʁ.ma.sjɔ̃/ · noun |
| [évêque](https://en.wiktionary.org/wiki/%C3%A9v%C3%AAque#French) | bishop (clergyman) | /e.vɛk/ · noun |
| [avenue](https://en.wiktionary.org/wiki/avenue#French) | avenue (broad street, especially bordered with trees) | /a.vny/ · noun |
| [axe](https://en.wiktionary.org/wiki/axe#French) | axis | /aks/ · noun |
| [cousin](https://en.wiktionary.org/wiki/cousin#French) | cousin (male) | /ku.zɛ̃/ · noun |
| [expert](https://en.wiktionary.org/wiki/expert#French) | expert | /ɛk.spɛʁ/ · adj |
| [indice](https://en.wiktionary.org/wiki/indice#French) | clue, hint, indication | /ɛ̃.dis/ · noun |
| [major](https://en.wiktionary.org/wiki/major#French) | the highest non-commissioned officer rank: sergeant major, “major” | /ma.ʒɔʁ/ · noun |
| [pascal](https://en.wiktionary.org/wiki/pascal#French) | paschal | /pas.kal/ · adj |
| [pis](https://en.wiktionary.org/wiki/pis#French) | udder | /pi/ · noun |
| [pop](https://en.wiktionary.org/wiki/pop#French) | pop (popular) | /pɔp/ · adj |
| [trace](https://en.wiktionary.org/wiki/trace#French) | trace | /tʁas/ · noun |
| [visible](https://en.wiktionary.org/wiki/visible#French) | visible | /vi.zibl/ · adj |
| [accent](https://en.wiktionary.org/wiki/accent#French) | accent, manner or tone of speech | /ak.sɑ̃/ · noun |
| [animation](https://en.wiktionary.org/wiki/animation#French) | animation | /a.ni.ma.sjɔ̃/ · noun |
| [canon](https://en.wiktionary.org/wiki/canon#French) | cannon, (big) gun | /ka.nɔ̃/ · noun |
| [dizaine](https://en.wiktionary.org/wiki/dizaine#French) | a set of ten | /di.zɛn/ · noun |
| [stop](https://en.wiktionary.org/wiki/stop#French) | stop! | /stɔp/ · intj |
| [dimension](https://en.wiktionary.org/wiki/dimension#French) | dimension | /di.mɑ̃.sjɔ̃/ · noun |
| [intelligent](https://en.wiktionary.org/wiki/intelligent#French) | intelligent | /ɛ̃.tɛ.li.ʒɑ̃/ · adj |
| [continent](https://en.wiktionary.org/wiki/continent#French) | continent | /kɔ̃.ti.nɑ̃/ · noun |
| [fleur](https://en.wiktionary.org/wiki/fleur#French) | flower; bloom; blossom; collectively, the reproductive organs and the envelope which surrounds them in angiosperms (also called "flowering plants") | /flœʁ/ · noun |
| [gris](https://en.wiktionary.org/wiki/gris#French) | grey / gray | /ɡʁi/ · adj |
| [métal](https://en.wiktionary.org/wiki/m%C3%A9tal#French) | metal | /me.tal/ · noun |
| [tant pis](https://en.wiktionary.org/wiki/tant%20pis#French) | too bad, never mind | /tɑ̃ pi/ · adv |
| [design](https://en.wiktionary.org/wiki/design#French) | design | /di.zajn/ · noun |
| [explosion](https://en.wiktionary.org/wiki/explosion#French) | explosion | /ɛk.splo.zjɔ̃/ · noun |
| [open](https://en.wiktionary.org/wiki/open#French) | open; open tournament | /ɔ.pɛn/ · noun |
| [paire](https://en.wiktionary.org/wiki/paire#French) | a pair; a couple | /pɛʁ/ · noun |
| [relative](https://en.wiktionary.org/wiki/relative#French) | relative clause, adjectival clause, adjective clause | /ʁə.la.tiv/ · noun |
| [bill](https://en.wiktionary.org/wiki/bill#French) | bill (draft UK law) | /bil/ · noun |
| [bob](https://en.wiktionary.org/wiki/bob#French) | bucket hat, fishing hat | /bɔb/ · noun |
| [ed](https://en.wiktionary.org/wiki/ed#French) | eth | /ɛd/ · noun |
| [file](https://en.wiktionary.org/wiki/file#French) | a line of objects placed one after the other | /fil/ · noun |
| [gras](https://en.wiktionary.org/wiki/gras#French) | fat | /ɡʁa/ · adj |
| [hockey](https://en.wiktionary.org/wiki/hockey#French) | hockey | /ɔ.kɛ/ · noun |
| [liaison](https://en.wiktionary.org/wiki/liaison#French) | link, bond | /ljɛ.zɔ̃/ · noun |
| [nu](https://en.wiktionary.org/wiki/nu#French) | naked; nude; bare | /ny/ · adj |
| [acquisition](https://en.wiktionary.org/wiki/acquisition#French) | acquisition (fact of acquiring) | /a.ki.zi.sjɔ̃/ · noun |
| [jus](https://en.wiktionary.org/wiki/jus#French) | juice | /ʒy/ · noun |
| [latin](https://en.wiktionary.org/wiki/latin#French) | Latin | /la.tɛ̃/ · adj |
| [mark](https://en.wiktionary.org/wiki/mark#French) | mark (currency) | /maʁk/ · noun |
| [onze](https://en.wiktionary.org/wiki/onze#French) | eleven | /ɔ̃z/ · num |

</details>

<details><summary>Words 551–600</summary>

![[Resources/Audio/fr/Words 0551-0600.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [plate](https://en.wiktionary.org/wiki/plate#French) | very small flat boat | /plat/ · noun |
| [prière](https://en.wiktionary.org/wiki/pri%C3%A8re#French) | prayer | /pʁi.jɛʁ/ · noun |
| [prière de](https://en.wiktionary.org/wiki/pri%C3%A8re%20de#French) | please; used to make formal requests, especially in impersonal contexts such as signage | /pʁi.jɛʁ də/ · phrase |
| [profession](https://en.wiktionary.org/wiki/profession#French) | profession, public declaration | /pʁɔ.fɛ.sjɔ̃/ · noun |
| [pseudo](https://en.wiktionary.org/wiki/pseudo#French) | a nickname, handle or pseudonym | /psø.do/ · noun |
| [signal](https://en.wiktionary.org/wiki/signal#French) | signal | /si.ɲal/ · noun |
| [ère](https://en.wiktionary.org/wiki/%C3%A8re#French) | era (all meanings) | /ɛʁ/ · noun |
| [accessible](https://en.wiktionary.org/wiki/accessible#French) | accessible, attainable, obtainable, available | /ak.sɛ.sibl/ · adj |
| [age](https://en.wiktionary.org/wiki/age#French) | beam (central bar of a plough) | /aʒ/ · noun |
| [duo](https://en.wiktionary.org/wiki/duo#French) | duo (combination of two things) | /dɥo/ · noun |
| [global](https://en.wiktionary.org/wiki/global#French) | global, spherical; (hence) concerning the whole world | /ɡlɔ.bal/ · adj |
| [hop](https://en.wiktionary.org/wiki/hop#French) | voila!, hey presto! | /ɔp/ · intj |
| [chant](https://en.wiktionary.org/wiki/chant#French) | singing (act of using the voice to produce musical sounds) | /ʃɑ̃/ · noun |
| [coach](https://en.wiktionary.org/wiki/coach#French) | coach, trainer, instructor | /kotʃ/ · noun |
| [der](https://en.wiktionary.org/wiki/der#French) | last | /dɛʁ/ · noun |
| [fiction](https://en.wiktionary.org/wiki/fiction#French) | fiction | /fik.sjɔ̃/ · noun |
| [fine](https://en.wiktionary.org/wiki/fine#French) | thin space, non-breakable space | /fin/ · noun |
| [fromage](https://en.wiktionary.org/wiki/fromage#French) | cheese | /fʁɔ.maʒ/ · noun |
| [ile](https://en.wiktionary.org/wiki/ile#French) | post-1990 spelling of île | /il/ · noun |
| [lion](https://en.wiktionary.org/wiki/lion#French) | lion | /ljɔ̃/ · noun |
| [masque](https://en.wiktionary.org/wiki/masque#French) | mask (a cover, or partial cover, for the face, used for disguise or protection) | /mask/ · noun |
| [massif](https://en.wiktionary.org/wiki/massif#French) | massif | /ma.sif/ · noun |
| [occupation](https://en.wiktionary.org/wiki/occupation#French) | occupation (act of occupying, of being an occupant) | /ɔ.ky.pa.sjɔ̃/ · noun |
| [pot](https://en.wiktionary.org/wiki/pot#French) | pot, jar, vase, tin, can, carton (a container of any of various materials) | /po/ · noun |
| [tennis](https://en.wiktionary.org/wiki/tennis#French) | tennis | /tɛ.nis/ · noun |
| [abbé](https://en.wiktionary.org/wiki/abb%C3%A9#French) | an abbot, the head of an abbey | /a.be/ · noun |
| [amateur](https://en.wiktionary.org/wiki/amateur#French) | lover of something | /a.ma.tœʁ/ · noun |
| [argument](https://en.wiktionary.org/wiki/argument#French) | argument | /aʁ.ɡy.mɑ̃/ · noun |
| [cardinal](https://en.wiktionary.org/wiki/cardinal#French) | important; paramount | /kaʁ.di.nal/ · adj |
| [arc-en-ciel](https://en.wiktionary.org/wiki/arc-en-ciel#French) | rainbow (multicoloured arch in the sky, produced by prismatic refraction of light within droplets of rain in the air) | /aʁ.kɑ̃.sjɛl/ · noun |
| [bonus](https://en.wiktionary.org/wiki/bonus#French) | premium | /bɔ.nys/ · noun |
| [dan](https://en.wiktionary.org/wiki/dan#French) | dan | /dan/ · noun |
| [express](https://en.wiktionary.org/wiki/express#French) | express, rapid | /ɛk.spʁɛs/ · adj |
| [flux](https://en.wiktionary.org/wiki/flux#French) | flow | /fly/ · noun |
| [instrument](https://en.wiktionary.org/wiki/instrument#French) | instrument (means or agency for achieving an effect) | /ɛ̃s.tʁy.mɑ̃/ · noun |
| [voyager](https://en.wiktionary.org/wiki/voyager#French) | to travel, to voyage | /vwa.ja.ʒe/ · verb |
| [au four](https://en.wiktionary.org/wiki/au%20four#French) | in the oven | /o fuʁ/ · adv |
| [boulevard](https://en.wiktionary.org/wiki/boulevard#French) | bulwark, rampart | /bul.vaʁ/ · noun |
| [four](https://en.wiktionary.org/wiki/four#French) | oven | /fuʁ/ · noun |
| [livrer](https://en.wiktionary.org/wiki/livrer#French) | to deliver (a package, merchandise etc.) | /li.vʁe/ · verb |
| [observation](https://en.wiktionary.org/wiki/observation#French) | observation (careful or controlled attention or consideration) | /ɔp.sɛʁ.va.sjɔ̃/ · noun |
| [parent](https://en.wiktionary.org/wiki/parent#French) | relative, relation, family member | /pa.ʁɑ̃/ · noun |
| [piano](https://en.wiktionary.org/wiki/piano#French) | piano | /pja.no/ · noun |
| [quarante](https://en.wiktionary.org/wiki/quarante#French) | forty | /ka.ʁɑ̃t/ · num |
| [sauce](https://en.wiktionary.org/wiki/sauce#French) | sauce | /sos/ · noun |
| [alternative](https://en.wiktionary.org/wiki/alternative#French) | alternative | /al.tɛʁ.na.tiv/ · noun |
| [basket](https://en.wiktionary.org/wiki/basket#French) | basketball | /bas.kɛt/ · noun |
| [bible](https://en.wiktionary.org/wiki/bible#French) | bible (comprehensive text) | /bibl/ · noun |
| [incident](https://en.wiktionary.org/wiki/incident#French) | incident | /ɛ̃.si.dɑ̃/ · noun |
| [occident](https://en.wiktionary.org/wiki/occident#French) | west (compass point) | /ɔk.si.dɑ̃/ · noun |

</details>

<details><summary>Words 601–650</summary>

![[Resources/Audio/fr/Words 0601-0650.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [tape](https://en.wiktionary.org/wiki/tape#French) | a gentle touch | /tap/ · noun |
| [CD](https://en.wiktionary.org/wiki/CD#French) | CD (compact disk) | /se.de/ · noun |
| [box](https://en.wiktionary.org/wiki/box#French) | stall (for a horse), loose box | /bɔks/ · noun |
| [ours](https://en.wiktionary.org/wiki/ours#French) | bear | /uʁs/ · noun |
| [pollution](https://en.wiktionary.org/wiki/pollution#French) | pollution | /pɔ.ly.sjɔ̃/ · noun |
| [taxi](https://en.wiktionary.org/wiki/taxi#French) | taxi | /tak.si/ · noun |
| [trait](https://en.wiktionary.org/wiki/trait#French) | line | /tʁɛ/ · noun |
| [trouble](https://en.wiktionary.org/wiki/trouble#French) | trouble | /tʁubl/ · noun |
| [we](https://en.wiktionary.org/wiki/we#French) | ouais | /wə/ · intj |
| [éventuellement](https://en.wiktionary.org/wiki/%C3%A9ventuellement#French) | possibly, maybe, perhaps; if you want | /e.vɑ̃.tɥɛl.mɑ̃/ · adv |
| [abandon](https://en.wiktionary.org/wiki/abandon#French) | surrender; desertion; withdrawal | /a.bɑ̃.dɔ̃/ · noun |
| [ambition](https://en.wiktionary.org/wiki/ambition#French) | ambition | /ɑ̃.bi.sjɔ̃/ · noun |
| [bouton](https://en.wiktionary.org/wiki/bouton#French) | button | /bu.tɔ̃/ · noun |
| [bronze](https://en.wiktionary.org/wiki/bronze#French) | bronze (metal, work of art) | /bʁɔ̃z/ · noun |
| [chair](https://en.wiktionary.org/wiki/chair#French) | flesh | /ʃɛʁ/ · noun |
| [clan](https://en.wiktionary.org/wiki/clan#French) | clan | /klɑ̃/ · noun |
| [vocation](https://en.wiktionary.org/wiki/vocation#French) | vocation, calling | /vɔ.ka.sjɔ̃/ · noun |
| [DVD](https://en.wiktionary.org/wiki/DVD#French) | DVD (optical disc) | /de.ve.de/ · noun |
| [accorder](https://en.wiktionary.org/wiki/accorder#French) | to grant (something to someone) | /a.kɔʁ.de/ · verb |
| [civilisation](https://en.wiktionary.org/wiki/civilisation#French) | civilization | /si.vi.li.za.sjɔ̃/ · noun |
| [exposé](https://en.wiktionary.org/wiki/expos%C3%A9#French) | exposed | /ɛk.spo.ze/ · adj |
| [girl](https://en.wiktionary.org/wiki/girl#French) | dancing girl | /ɡœʁl/ · noun |
| [gâteau](https://en.wiktionary.org/wiki/g%C3%A2teau#French) | a sponge cake, i.e. a cake made with a chemical leavening agent (e.g. baking powder), making it light and airy (as opposed to a denser torte) | /ɡa.to/ · noun |
| [las](https://en.wiktionary.org/wiki/las#French) | weary, tired | /la/ · adj |
| [li](https://en.wiktionary.org/wiki/li#French) | li (Chinese unit of distance) | /li/ · noun |
| [miracle](https://en.wiktionary.org/wiki/miracle#French) | miracle | /mi.ʁakl/ · noun |
| [pomme](https://en.wiktionary.org/wiki/pomme#French) | apple (fruit) | /pɔm/ · noun |
| [porno](https://en.wiktionary.org/wiki/porno#French) | porno; porn | /pɔʁ.no/ · noun |
| [proportion](https://en.wiktionary.org/wiki/proportion#French) | proportion | /pʁɔ.pɔʁ.sjɔ̃/ · noun |
| [rêver](https://en.wiktionary.org/wiki/r%C3%AAver#French) | to dream | /ʁɛ.ve/ · verb |
| [vingtaine](https://en.wiktionary.org/wiki/vingtaine#French) | about twenty | /vɛ̃.tɛn/ · noun |
| [baby](https://en.wiktionary.org/wiki/baby#French) | table soccer, table football | /bɛ.bi/ · noun |
| [boss](https://en.wiktionary.org/wiki/boss#French) | boss (leader) | /bɔs/ · noun |
| [dictionnaire](https://en.wiktionary.org/wiki/dictionnaire#French) | dictionary (a list of words, usually arranged alphabetically and presented with definitions or translations) | /dik.sjɔ.nɛʁ/ · noun |
| [management](https://en.wiktionary.org/wiki/management#French) | management | /ma.na(d)ʒ.mɑ̃/ · noun |
| [manager](https://en.wiktionary.org/wiki/manager#French) | manager | /ma.na.dʒɛʁ/ · noun |
| [robot](https://en.wiktionary.org/wiki/robot#French) | robot | /ʁɔ.bo/ · noun |
| [tube](https://en.wiktionary.org/wiki/tube#French) | pipe | /tyb/ · noun |
| [SMS](https://en.wiktionary.org/wiki/SMS#French) | SMS, text, text message | /ɛ.sɛ.mɛs/ · noun |
| [accusation](https://en.wiktionary.org/wiki/accusation#French) | accusation | /a.ky.za.sjɔ̃/ · noun |
| [barbe](https://en.wiktionary.org/wiki/barbe#French) | beard | /baʁb/ · noun |
| [blonde](https://en.wiktionary.org/wiki/blonde#French) | blonde, female with blonde hair | /blɔ̃d/ · noun |
| [location](https://en.wiktionary.org/wiki/location#French) | renting, rental | /lɔ.ka.sjɔ̃/ · noun |
| [menu](https://en.wiktionary.org/wiki/menu#French) | slim, small, fine | /mə.ny/ · adj |
| [qualification](https://en.wiktionary.org/wiki/qualification#French) | qualification (all senses) | /ka.li.fi.ka.sjɔ̃/ · noun |
| [serre](https://en.wiktionary.org/wiki/serre#French) | action of pressing something together; result of this action | /sɛʁ/ · noun |
| [bol](https://en.wiktionary.org/wiki/bol#French) | bowl | /bɔl/ · noun |
| [centaine](https://en.wiktionary.org/wiki/centaine#French) | a hundred or so, about a hundred | /sɑ̃.tɛn/ · noun |
| [dragon](https://en.wiktionary.org/wiki/dragon#French) | a dragon, creature | /dʁa.ɡɔ̃/ · noun |
| [flash](https://en.wiktionary.org/wiki/flash#French) | flash (burst of light) | /flaʃ/ · noun |

</details>

<details><summary>Words 651–700</summary>

![[Resources/Audio/fr/Words 0651-0700.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [gain](https://en.wiktionary.org/wiki/gain#French) | a gain (of something), an instance of saving (something); an increase (in something) | /ɡɛ̃/ · noun |
| [jambe](https://en.wiktionary.org/wiki/jambe#French) | leg | /ʒɑ̃b/ · noun |
| [pile](https://en.wiktionary.org/wiki/pile#French) | heap, stack | /pil/ · noun |
| [altitude](https://en.wiktionary.org/wiki/altitude#French) | altitude | /al.ti.tyd/ · noun |
| [animé](https://en.wiktionary.org/wiki/anim%C3%A9#French) | alive | /a.ni.me/ · adj |
| [monstre](https://en.wiktionary.org/wiki/monstre#French) | monster | /mɔ̃stʁ/ · noun |
| [baron](https://en.wiktionary.org/wiki/baron#French) | baron, lord, noble landowner | /ba.ʁɔ̃/ · noun |
| [canard](https://en.wiktionary.org/wiki/canard#French) | duck (of either sex) | /ka.naʁ/ · noun |
| [case](https://en.wiktionary.org/wiki/case#French) | box (on form) | /kaz/ · noun |
| [commander](https://en.wiktionary.org/wiki/commander#French) | to order (tell someone to do something) | /kɔ.mɑ̃.de/ · verb |
| [de rigueur](https://en.wiktionary.org/wiki/de%20rigueur#French) | absolutely necessary | /də ʁi.ɡœʁ/ · adj |
| [philosophe](https://en.wiktionary.org/wiki/philosophe#French) | philosopher | /fi.lɔ.zɔf/ · noun |
| [suspension](https://en.wiktionary.org/wiki/suspension#French) | suspension | /sys.pɑ̃.sjɔ̃/ · noun |
| [bourgeois](https://en.wiktionary.org/wiki/bourgeois#French) | bourgeois | /buʁ.ʒwa/ · adj |
| [canton](https://en.wiktionary.org/wiki/canton#French) | canton (of Switzerland, France, Luxembourg or Bosnia-Herzegovina) | /kɑ̃.tɔ̃/ · noun |
| [expansion](https://en.wiktionary.org/wiki/expansion#French) | expansion | /ɛk.spɑ̃.sjɔ̃/ · noun |
| [fiscal](https://en.wiktionary.org/wiki/fiscal#French) | fiscal, financial | /fis.kal/ · adj |
| [perception](https://en.wiktionary.org/wiki/perception#French) | perception | /pɛʁ.sɛp.sjɔ̃/ · noun |
| [pique](https://en.wiktionary.org/wiki/pique#French) | pike, lance | /pik/ · noun |
| [roux](https://en.wiktionary.org/wiki/roux#French) | russet | /ʁu/ · adj |
| [stock](https://en.wiktionary.org/wiki/stock#French) | stock, goods in supply | /stɔk/ · noun |
| [variable](https://en.wiktionary.org/wiki/variable#French) | variable | /va.ʁjabl/ · adj |
| [vif](https://en.wiktionary.org/wiki/vif#French) | alive | /vif/ · adj |
| [absolu](https://en.wiktionary.org/wiki/absolu#French) | absolute | /ap.sɔ.ly/ · adj |
| [junior](https://en.wiktionary.org/wiki/junior#French) | junior | /ʒy.njɔʁ/ · noun |
| [miel](https://en.wiktionary.org/wiki/miel#French) | honey (sticky sweet substance) | /mjɛl/ · noun |
| [plaire](https://en.wiktionary.org/wiki/plaire#French) | to please, to appeal to (usually translated into English as like with exchange of subject and object) | /plɛʁ/ · verb |
| [entrepreneur](https://en.wiktionary.org/wiki/entrepreneur#French) | entrepreneur (person who organizes and operates a business venture) | /ɑ̃.tʁə.pʁə.nœʁ/ · noun |
| [explorer](https://en.wiktionary.org/wiki/explorer#French) | to explore | /ɛk.splɔ.ʁe/ · verb |
| [life](https://en.wiktionary.org/wiki/life#French) | life | /lif/ · noun |
| [vache](https://en.wiktionary.org/wiki/vache#French) | cow (bovine) | /vaʃ/ · noun |
| [liège](https://en.wiktionary.org/wiki/li%C3%A8ge#French) | cork (dead protective tissue between the bark and cambium in woody plants, with suberin deposits making it impervious to gasses and water) | /ljɛʒ/ · noun |
| [massacre](https://en.wiktionary.org/wiki/massacre#French) | massacre | /ma.sakʁ/ · noun |
| [provenance](https://en.wiktionary.org/wiki/provenance#French) | provenance, origin | /pʁɔv.nɑ̃s/ · noun |
| [trio](https://en.wiktionary.org/wiki/trio#French) | trio | /tʁi.jo/ · noun |
| [Breton](https://en.wiktionary.org/wiki/Breton#French) | Breton (native or inhabitant of the region of Brittany, France) (usually male) | /bʁə.tɔ̃/ · noun |
| [adieu](https://en.wiktionary.org/wiki/adieu#French) | farewell, adieu | /a.djø/ · intj |
| [bal](https://en.wiktionary.org/wiki/bal#French) | dance party, ball | /bal/ · noun |
| [idiot](https://en.wiktionary.org/wiki/idiot#French) | idiotic; stupid | /i.djo/ · adj |
| [look](https://en.wiktionary.org/wiki/look#French) | a style; appearance; look | /luk/ · noun |
| [chaos](https://en.wiktionary.org/wiki/chaos#French) | chaos | /ka.o/ · noun |
| [croissant](https://en.wiktionary.org/wiki/croissant#French) | crescent | /kʁwa.sɑ̃/ · noun |
| [globe](https://en.wiktionary.org/wiki/globe#French) | globe | /ɡlɔb/ · noun |
| [habitat](https://en.wiktionary.org/wiki/habitat#French) | habitat | /a.bi.ta/ · noun |
| [house](https://en.wiktionary.org/wiki/house#French) | house music, house (a genre of music) | /aws/ · noun |
| [identification](https://en.wiktionary.org/wiki/identification#French) | identification | /i.dɑ̃.ti.fi.ka.sjɔ̃/ · noun |
| [lady](https://en.wiktionary.org/wiki/lady#French) | lady (wife of a British lord; important woman, usually British) | /lɛ.di/ · noun |
| [musical](https://en.wiktionary.org/wiki/musical#French) | music, musical | /my.zi.kal/ · adj |
| [thread](https://en.wiktionary.org/wiki/thread#French) | thread | /tʁɛd/ · noun |
| [agenda](https://en.wiktionary.org/wiki/agenda#French) | organiser, appointment book, engagement book | /a.ʒɛ̃.da/ · noun |

</details>

<details><summary>Words 701–750</summary>

![[Resources/Audio/fr/Words 0701-0750.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [aire](https://en.wiktionary.org/wiki/aire#French) | (surface) area | /ɛʁ/ · noun |
| [antique](https://en.wiktionary.org/wiki/antique#French) | ancient | /ɑ̃.tik/ · adj |
| [back](https://en.wiktionary.org/wiki/back#French) | to back (something) up, to move (something) back; to move (oneself) back, to reverse direction | /bak/ · verb |
| [cage](https://en.wiktionary.org/wiki/cage#French) | cage | /kaʒ/ · noun |
| [cigarette](https://en.wiktionary.org/wiki/cigarette#French) | cigarette | /si.ɡa.ʁɛt/ · noun |
| [correct](https://en.wiktionary.org/wiki/correct#French) | correct, right | /kɔ.ʁɛkt/ · adj |
| [like](https://en.wiktionary.org/wiki/like#French) | a like |  · noun |
| [mental](https://en.wiktionary.org/wiki/mental#French) | mind; mental | /mɑ̃.tal/ · adj |
| [oxygène](https://en.wiktionary.org/wiki/oxyg%C3%A8ne#French) | oxygen | /ɔk.si.ʒɛn/ · noun |
| [pizza](https://en.wiktionary.org/wiki/pizza#French) | pizza (Italian dish) | /pid.za/ · noun |
| [substance](https://en.wiktionary.org/wiki/substance#French) | substance | /syp.stɑ̃s/ · noun |
| [absent](https://en.wiktionary.org/wiki/absent#French) | absent | /ap.sɑ̃/ · adj |
| [chouette](https://en.wiktionary.org/wiki/chouette#French) | owl (specifically, those species of owls without ear tufts; those with ear tufts are hiboux) | /ʃwɛt/ · noun |
| [gaffe](https://en.wiktionary.org/wiki/gaffe#French) | gaffe, blunder, goof-up (North American), cock-up (British) | /ɡaf/ · noun |
| [manga](https://en.wiktionary.org/wiki/manga#French) | manga (comic originating in Japan) | /mɑ̃.ɡa/ · noun |
| [fun](https://en.wiktionary.org/wiki/fun#French) | fun | /fœn/ · adj |
| [invisible](https://en.wiktionary.org/wiki/invisible#French) | invisible (unable to be seen) | /ɛ̃.vi.zibl/ · adj |
| [label](https://en.wiktionary.org/wiki/label#French) | quality label | /la.bɛl/ · noun |
| [solitude](https://en.wiktionary.org/wiki/solitude#French) | solitude | /sɔ.li.tyd/ · noun |
| [confirmation](https://en.wiktionary.org/wiki/confirmation#French) | confirmation (all senses) | /kɔ̃.fiʁ.ma.sjɔ̃/ · noun |
| [dent](https://en.wiktionary.org/wiki/dent#French) | tooth | /dɑ̃/ · noun |
| [dessert](https://en.wiktionary.org/wiki/dessert#French) | dessert, pudding | /de.sɛʁ/ · noun |
| [green](https://en.wiktionary.org/wiki/green#French) | green | /ɡʁin/ · noun |
| [inflation](https://en.wiktionary.org/wiki/inflation#French) | inflation | /ɛ̃.fla.sjɔ̃/ · noun |
| [promo](https://en.wiktionary.org/wiki/promo#French) | promo | /pʁɔ.mo/ · noun |
| [radical](https://en.wiktionary.org/wiki/radical#French) | radical | /ʁa.di.kal/ · adj |
| [trentaine](https://en.wiktionary.org/wiki/trentaine#French) | about thirty | /tʁɑ̃.tɛn/ · noun |
| [allure](https://en.wiktionary.org/wiki/allure#French) | appearance, look | /a.lyʁ/ · noun |
| [clef](https://en.wiktionary.org/wiki/clef#French) | clef | /kle/ · noun |
| [constant](https://en.wiktionary.org/wiki/constant#French) | constant | /kɔ̃s.tɑ̃/ · adj |
| [correction](https://en.wiktionary.org/wiki/correction#French) | correction (all senses) | /kɔ.ʁɛk.sjɔ̃/ · noun |
| [digital](https://en.wiktionary.org/wiki/digital#French) | fingers, toes; digital | /di.ʒi.tal/ · adj |
| [fleur de sel](https://en.wiktionary.org/wiki/fleur%20de%20sel#French) | fleur de sel | /flœʁ də sɛl/ · noun |
| [jet](https://en.wiktionary.org/wiki/jet#French) | throw | /ʒɛ/ · noun |
| [mètre](https://en.wiktionary.org/wiki/m%C3%A8tre#French) | metre/meter | /mɛtʁ/ · noun |
| [panier](https://en.wiktionary.org/wiki/panier#French) | basket | /pa.nje/ · noun |
| [people](https://en.wiktionary.org/wiki/people#French) | a celebrity, celebrities, famous person(s) | /pi.pɔl/ · noun |
| [servant](https://en.wiktionary.org/wiki/servant#French) | servant | /sɛʁ.vɑ̃/ · noun |
| [are](https://en.wiktionary.org/wiki/are#French) | an are |  · noun |
| [barbe à papa](https://en.wiktionary.org/wiki/barbe%20%C3%A0%20papa#French) | cotton candy, candy floss, fairy floss (sugar confectionery) | /baʁ.b‿a pa.pa/ · noun |
| [handicap](https://en.wiktionary.org/wiki/handicap#French) | handicap | /ɑ̃.di.kap/ · noun |
| [hot](https://en.wiktionary.org/wiki/hot#French) | involving or characterized by sex | /ɔt/ · adj |
| [index](https://en.wiktionary.org/wiki/index#French) | index | /ɛ̃.dɛks/ · noun |
| [porto](https://en.wiktionary.org/wiki/porto#French) | port wine | /pɔʁ.to/ · noun |
| [boisson](https://en.wiktionary.org/wiki/boisson#French) | drinking (the activity of consuming alcoholic beverages) | /bwa.sɔ̃/ · noun |
| [cash](https://en.wiktionary.org/wiki/cash#French) | in cash (of paying) | /kaʃ/ · adv |
| [consensus](https://en.wiktionary.org/wiki/consensus#French) | consensus | /kɔ̃.sɛ̃.sys/ · noun |
| [genou](https://en.wiktionary.org/wiki/genou#French) | knee | /ʒə.nu/ · noun |
| [hello](https://en.wiktionary.org/wiki/hello#French) | hello, hi | /ɛ.lo/ · intj |
| [affection](https://en.wiktionary.org/wiki/affection#French) | affection, love, fondness | /a.fɛk.sjɔ̃/ · noun |

</details>

<details><summary>Words 751–800</summary>

![[Resources/Audio/fr/Words 0751-0800.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [doctrine](https://en.wiktionary.org/wiki/doctrine#French) | doctrine | /dɔk.tʁin/ · noun |
| [ho](https://en.wiktionary.org/wiki/ho#French) | Used by tamers to calm the animal they are taming, especially horses; whoa | /o/ · intj |
| [quinzaine](https://en.wiktionary.org/wiki/quinzaine#French) | about fifteen people, about fifteen things, etc. | /kɛ̃.zɛn/ · noun |
| [sacrifice](https://en.wiktionary.org/wiki/sacrifice#French) | sacrifice | /sa.kʁi.fis/ · noun |
| [sanction](https://en.wiktionary.org/wiki/sanction#French) | sanction | /sɑ̃k.sjɔ̃/ · noun |
| [vain](https://en.wiktionary.org/wiki/vain#French) | useless, ineffective, fruitless | /vɛ̃/ · adj |
| [weekend](https://en.wiktionary.org/wiki/weekend#French) | post-1990 spelling of week-end | /wi.kɛnd/ · noun |
| [ban](https://en.wiktionary.org/wiki/ban#French) | territory | /bɑ̃/ · noun |
| [dollar](https://en.wiktionary.org/wiki/dollar#French) | dollar, usually the US dollar. | /dɔ.laʁ/ · noun |
| [duel](https://en.wiktionary.org/wiki/duel#French) | dual (having two components) | /dɥɛl/ · adj |
| [madeleine](https://en.wiktionary.org/wiki/madeleine#French) | madeleine (small gateau in the shape of a scallop shell) | /mad.lɛn/ · noun |
| [serpent](https://en.wiktionary.org/wiki/serpent#French) | snake | /sɛʁ.pɑ̃/ · noun |
| [stand](https://en.wiktionary.org/wiki/stand#French) | stand (In various senses, such as a small building, booth, or stage, as in a bandstand or hamburger stand.) | /stɑ̃d/ · noun |
| [trans](https://en.wiktionary.org/wiki/trans#French) | trans | /tʁɑ̃s/ · adj |
| [treize](https://en.wiktionary.org/wiki/treize#French) | thirteen | /tʁɛz/ · num |
| [certitude](https://en.wiktionary.org/wiki/certitude#French) | certitude | /sɛʁ.ti.tyd/ · noun |
| [fait accompli](https://en.wiktionary.org/wiki/fait%20accompli#French) | fait accompli; done deal | /fɛ.t‿a.kɔ̃.pli/ · noun |
| [grain](https://en.wiktionary.org/wiki/grain#French) | grain | /ɡʁɛ̃/ · noun |
| [marathon](https://en.wiktionary.org/wiki/marathon#French) | marathon | /ma.ʁa.tɔ̃/ · noun |
| [seize](https://en.wiktionary.org/wiki/seize#French) | sixteen | /sɛz/ · num |
| [ticket](https://en.wiktionary.org/wiki/ticket#French) | ticket (admission, pass) | /ti.kɛ/ · noun |
| [PA](https://en.wiktionary.org/wiki/PA#French) | CV (“aircraft carrier”); initialism of porte-avions |  · noun |
| [ado](https://en.wiktionary.org/wiki/ado#French) | teen, teenager | /a.do/ · noun |
| [comparable](https://en.wiktionary.org/wiki/comparable#French) | comparable (suitable to be compared) | /kɔ̃.pa.ʁabl/ · adj |
| [fa](https://en.wiktionary.org/wiki/fa#French) | fa, the fourth diatonic (or sixth chromatic) note 'F' | /fa/ · noun |
| [quarantaine](https://en.wiktionary.org/wiki/quarantaine#French) | a number or group of or about forty | /ka.ʁɑ̃.tɛn/ · noun |
| [quatorze](https://en.wiktionary.org/wiki/quatorze#French) | fourteen | /ka.tɔʁz/ · num |
| [set](https://en.wiktionary.org/wiki/set#French) | set | /sɛt/ · noun |
| [visa](https://en.wiktionary.org/wiki/visa#French) | a mark or stamp attesting to the performance of an official action | /vi.za/ · noun |
| [affirmation](https://en.wiktionary.org/wiki/affirmation#French) | affirmation | /a.fiʁ.ma.sjɔ̃/ · noun |
| [capture](https://en.wiktionary.org/wiki/capture#French) | capture | /kap.tyʁ/ · noun |
| [douzaine](https://en.wiktionary.org/wiki/douzaine#French) | twelve; dozen | /du.zɛn/ · noun |
| [flèche](https://en.wiktionary.org/wiki/fl%C3%A8che#French) | spire | /flɛʃ/ · noun |
| [lent](https://en.wiktionary.org/wiki/lent#French) | slow | /lɑ̃/ · adj |
| [more](https://en.wiktionary.org/wiki/more#French) | mora | /mɔʁ/ · noun |
| [party](https://en.wiktionary.org/wiki/party#French) | party (social gathering) | /paʁ.ti/ · noun |
| [recherché](https://en.wiktionary.org/wiki/recherch%C3%A9#French) | prized, valued | /ʁə.ʃɛʁ.ʃe/ · adj |
| [sphère](https://en.wiktionary.org/wiki/sph%C3%A8re#French) | sphere | /sfɛʁ/ · noun |
| [xi](https://en.wiktionary.org/wiki/xi#French) | xi (Greek letter) | /ksi/ · noun |
| [alpha](https://en.wiktionary.org/wiki/alpha#French) | alpha (Greek letter) | /al.fa/ · noun |
| [gel](https://en.wiktionary.org/wiki/gel#French) | frost | /ʒɛl/ · noun |
| [motion](https://en.wiktionary.org/wiki/motion#French) | motion | /mɔ.sjɔ̃/ · noun |
| [tri](https://en.wiktionary.org/wiki/tri#French) | selection, sorting | /tʁi/ · noun |
| [ba](https://en.wiktionary.org/wiki/ba#French) | ba | /ba/ · noun |
| [crash](https://en.wiktionary.org/wiki/crash#French) | crash landing | /kʁaʃ/ · noun |
| [if](https://en.wiktionary.org/wiki/if#French) | yew | /if/ · noun |
| [pack](https://en.wiktionary.org/wiki/pack#French) | pack (item of packaging) | /pak/ · noun |
| [portion](https://en.wiktionary.org/wiki/portion#French) | portion | /pɔʁ.sjɔ̃/ · noun |
| [report](https://en.wiktionary.org/wiki/report#French) | postponement | /ʁə.pɔʁ/ · noun |
| [aluminium](https://en.wiktionary.org/wiki/aluminium#French) | aluminium (element) | /a.ly.mi.njɔm/ · noun |

</details>

<details><summary>Words 801–850</summary>

![[Resources/Audio/fr/Words 0801-0850.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [approbation](https://en.wiktionary.org/wiki/approbation#French) | approval (permission) | /a.pʁɔ.ba.sjɔ̃/ · noun |
| [beach](https://en.wiktionary.org/wiki/beach#French) | port where goods and passengers embark and debark | /bitʃ/ · noun |
| [clause](https://en.wiktionary.org/wiki/clause#French) | clause | /kloz/ · noun |
| [cloud](https://en.wiktionary.org/wiki/cloud#French) | the cloud | /klawd/ · noun |
| [occidental](https://en.wiktionary.org/wiki/occidental#French) | of the West; Western | /ɔk.si.dɑ̃.tal/ · adj |
| [pair](https://en.wiktionary.org/wiki/pair#French) | even (divisible by two) | /pɛʁ/ · adj |
| [pi](https://en.wiktionary.org/wiki/pi#French) | pi (Greek letter) | /pi/ · noun |
| [potable](https://en.wiktionary.org/wiki/potable#French) | potable | /pɔ.tabl/ · adj |
| [prestige](https://en.wiktionary.org/wiki/prestige#French) | prestige | /pʁɛs.tiʒ/ · noun |
| [zoo](https://en.wiktionary.org/wiki/zoo#French) | zoo | /zo/ · noun |
| [baseball](https://en.wiktionary.org/wiki/baseball#French) | post-1990 spelling of base-ball | /bɛz.bɔl/ · noun |
| [bi](https://en.wiktionary.org/wiki/bi#French) | bi, bisexual person | /bi/ · noun |
| [dead](https://en.wiktionary.org/wiki/dead#French) | to succeed (in doing something well, "killing it") | /dɛd/ · verb |
| [dissolution](https://en.wiktionary.org/wiki/dissolution#French) | dissolution | /di.sɔ.ly.sjɔ̃/ · noun |
| [emprunt](https://en.wiktionary.org/wiki/emprunt#French) | loan | /ɑ̃.pʁœ̃/ · noun |
| [fuck](https://en.wiktionary.org/wiki/fuck#French) | fuck! | /fɛk/ · intj |
| [hard](https://en.wiktionary.org/wiki/hard#French) | hardcore | /aʁd/ · adj |
| [naître](https://en.wiktionary.org/wiki/na%C3%AEtre#French) | to be born | /nɛtʁ/ · verb |
| [participant](https://en.wiktionary.org/wiki/participant#French) | participant | /paʁ.ti.si.pɑ̃/ · noun |
| [allusion](https://en.wiktionary.org/wiki/allusion#French) | allusion, innuendo | /a.ly.zjɔ̃/ · noun |
| [dom](https://en.wiktionary.org/wiki/dom#French) | title of respect given to certain monks and other religious figures | /dɔ̃/ · noun |
| [hélicoptère](https://en.wiktionary.org/wiki/h%C3%A9licopt%C3%A8re#French) | helicopter | /e.li.kɔp.tɛʁ/ · noun |
| [jersey](https://en.wiktionary.org/wiki/jersey#French) | jersey | /ʒɛʁ.zɛ/ · noun |
| [maintenance](https://en.wiktionary.org/wiki/maintenance#French) | maintenance | /mɛ̃t.nɑ̃s/ · noun |
| [pirate](https://en.wiktionary.org/wiki/pirate#French) | pirate | /pi.ʁat/ · noun |
| [short](https://en.wiktionary.org/wiki/short#French) | shorts, short trousers (UK) | /ʃɔʁt/ · noun |
| [ter](https://en.wiktionary.org/wiki/ter#French) | b; designating a third house with the same number | /tɛʁ/ · adv |
| [cassation](https://en.wiktionary.org/wiki/cassation#French) | cassation | /ka.sa.sjɔ̃/ · noun |
| [kit](https://en.wiktionary.org/wiki/kit#French) | kit (to assemble) |  · noun |
| [manœuvre](https://en.wiktionary.org/wiki/man%C5%93uvre#French) | move, movement | /ma.nœvʁ/ · noun |
| [puce](https://en.wiktionary.org/wiki/puce#French) | flea | /pys/ · noun |
| [regret](https://en.wiktionary.org/wiki/regret#French) | regret | /ʁə.ɡʁɛ/ · noun |
| [attraction](https://en.wiktionary.org/wiki/attraction#French) | attraction (all senses) | /a.tʁak.sjɔ̃/ · noun |
| [full](https://en.wiktionary.org/wiki/full#French) | full | /ful/ · adj |
| [laser](https://en.wiktionary.org/wiki/laser#French) | laser (umbelliferous plant) | /la.zɛʁ/ · noun |
| [observateur](https://en.wiktionary.org/wiki/observateur#French) | observant (having the ability to notice things; having power of observation) | /ɔp.sɛʁ.va.tœʁ/ · adj |
| [oral](https://en.wiktionary.org/wiki/oral#French) | oral | /ɔ.ʁal/ · adj |
| [rate](https://en.wiktionary.org/wiki/rate#French) | spleen | /ʁat/ · noun |
| [accélérer](https://en.wiktionary.org/wiki/acc%C3%A9l%C3%A9rer#French) | to accelerate | /ak.se.le.ʁe/ · verb |
| [brave](https://en.wiktionary.org/wiki/brave#French) | brave | /bʁav/ · adj |
| [break](https://en.wiktionary.org/wiki/break#French) | break (pause, holiday) | /bʁɛk/ · noun |
| [gaulois](https://en.wiktionary.org/wiki/gaulois#French) | Gaulish | /ɡo.lwa/ · adj |
| [homo](https://en.wiktionary.org/wiki/homo#French) | gay (homosexual person, especially male) | /ɔ.mo/ · noun |
| [lente](https://en.wiktionary.org/wiki/lente#French) | nit | /lɑ̃t/ · noun |
| [lie](https://en.wiktionary.org/wiki/lie#French) | lees, dregs (of wine, of society) |  · noun |
| [radar](https://en.wiktionary.org/wiki/radar#French) | radar | /ʁa.daʁ/ · noun |
| [slogan](https://en.wiktionary.org/wiki/slogan#French) | slogan (all senses) | /slɔ.ɡɑ̃/ · noun |
| [tigre](https://en.wiktionary.org/wiki/tigre#French) | tiger | /tiɡʁ/ · noun |
| [violet](https://en.wiktionary.org/wiki/violet#French) | purple (colour) | /vjɔ.lɛ/ · noun |
| [abolition](https://en.wiktionary.org/wiki/abolition#French) | abolition | /a.bɔ.li.sjɔ̃/ · noun |

</details>

<details><summary>Words 851–900</summary>

![[Resources/Audio/fr/Words 0851-0900.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [accuser](https://en.wiktionary.org/wiki/accuser#French) | to accuse | /a.ky.ze/ · verb |
| [admirer](https://en.wiktionary.org/wiki/admirer#French) | to admire | /ad.mi.ʁe/ · verb |
| [boue](https://en.wiktionary.org/wiki/boue#French) | mud; dirt | /bu/ · noun |
| [claque](https://en.wiktionary.org/wiki/claque#French) | slap on the cheek | /klak/ · noun |
| [coup de foudre](https://en.wiktionary.org/wiki/coup%20de%20foudre#French) | lightning strike, thunderbolt | /ku d(ə) fudʁ/ · noun |
| [meeting](https://en.wiktionary.org/wiki/meeting#French) | large, public gathering (not used in other senses of "meeting") | /mi.tiŋ/ · noun |
| [nazi](https://en.wiktionary.org/wiki/nazi#French) | Nazi | /na.zi/ · adj |
| [pipe](https://en.wiktionary.org/wiki/pipe#French) | tobacco pipe | /pip/ · noun |
| [rat](https://en.wiktionary.org/wiki/rat#French) | rat | /ʁa/ · noun |
| [revenue](https://en.wiktionary.org/wiki/revenue#French) | a (physical) return; arrival |  · noun |
| [triangle](https://en.wiktionary.org/wiki/triangle#French) | triangle (polygon) | /tʁi.jɑ̃ɡl/ · noun |
| [pull](https://en.wiktionary.org/wiki/pull#French) | pullover | /pyl/ · noun |
| [rude](https://en.wiktionary.org/wiki/rude#French) | rough, harsh | /ʁyd/ · adj |
| [terminal](https://en.wiktionary.org/wiki/terminal#French) | terminal | /tɛʁ.mi.nal/ · adj |
| [acceptation](https://en.wiktionary.org/wiki/acceptation#French) | acceptance | /ak.sɛp.ta.sjɔ̃/ · noun |
| [bull](https://en.wiktionary.org/wiki/bull#French) | bulldozer | /bul/ · noun |
| [cliché](https://en.wiktionary.org/wiki/clich%C3%A9#French) | stereotype (printing plate) | /kli.ʃe/ · noun |
| [confrontation](https://en.wiktionary.org/wiki/confrontation#French) | confrontation | /kɔ̃.fʁɔ̃.ta.sjɔ̃/ · noun |
| [single](https://en.wiktionary.org/wiki/single#French) | single room |  · noun |
| [vampire](https://en.wiktionary.org/wiki/vampire#French) | vampire | /vɑ̃.piʁ/ · noun |
| [chœur](https://en.wiktionary.org/wiki/ch%C5%93ur#French) | chorus | /kœʁ/ · noun |
| [cinquantaine](https://en.wiktionary.org/wiki/cinquantaine#French) | about 50, 50 or so | /sɛ̃.kɑ̃.tɛn/ · noun |
| [cross](https://en.wiktionary.org/wiki/cross#French) | cross country | /kʁɔs/ · noun |
| [divin](https://en.wiktionary.org/wiki/divin#French) | divine, godlike (of or pertaining to a god) | /di.vɛ̃/ · adj |
| [poker](https://en.wiktionary.org/wiki/poker#French) | poker | /pɔ.kɛʁ/ · noun |
| [staff](https://en.wiktionary.org/wiki/staff#French) | staff, mixture of plaster and fibre | /staf/ · noun |
| [Basque](https://en.wiktionary.org/wiki/Basque#French) | Basque (person of either gender) | /bask/ · noun |
| [about](https://en.wiktionary.org/wiki/about#French) | the extremity of a metallic or wooden element or piece |  · noun |
| [admission](https://en.wiktionary.org/wiki/admission#French) | admission (act of admitting; state of being admitted) | /ad.mi.sjɔ̃/ · noun |
| [bang](https://en.wiktionary.org/wiki/bang#French) | bang | /bɑ̃ɡ/ · intj |
| [cruel](https://en.wiktionary.org/wiki/cruel#French) | cruel | /kʁy.ɛl/ · adj |
| [hymne](https://en.wiktionary.org/wiki/hymne#French) | hymn | /imn/ · noun |
| [multiplication](https://en.wiktionary.org/wiki/multiplication#French) | multiplication | /myl.ti.pli.ka.sjɔ̃/ · noun |
| [notable](https://en.wiktionary.org/wiki/notable#French) | notable | /nɔ.tabl/ · adj |
| [olive](https://en.wiktionary.org/wiki/olive#French) | olive | /ɔ.liv/ · noun |
| [pie](https://en.wiktionary.org/wiki/pie#French) | magpie | /pi/ · noun |
| [user](https://en.wiktionary.org/wiki/user#French) | to wear, wear down, wear off, wear out, grind down, run in | /y.ze/ · verb |
| [acceptable](https://en.wiktionary.org/wiki/acceptable#French) | acceptable | /ak.sɛp.tabl/ · adj |
| [boom](https://en.wiktionary.org/wiki/boom#French) | boom (rapid expansion or increase) | /bum/ · noun |
| [corporation](https://en.wiktionary.org/wiki/corporation#French) | corporation | /kɔʁ.pɔ.ʁa.sjɔ̃/ · noun |
| [céleste](https://en.wiktionary.org/wiki/c%C3%A9leste#French) | celestial | /se.lɛst/ · adj |
| [opus](https://en.wiktionary.org/wiki/opus#French) | opus, artistic work | /ɔ.pys/ · noun |
| [rival](https://en.wiktionary.org/wiki/rival#French) | rival | /ʁi.val/ · adj |
| [sandwich](https://en.wiktionary.org/wiki/sandwich#French) | sandwich (food) | /sɑ̃.dwitʃ/ · noun |
| [sobre](https://en.wiktionary.org/wiki/sobre#French) | sober (teetotal) | /sɔbʁ/ · adj |
| [tonne](https://en.wiktionary.org/wiki/tonne#French) | large barrel | /tɔn/ · noun |
| [alias](https://en.wiktionary.org/wiki/alias#French) | alias | /a.ljas/ · adv |
| [borne](https://en.wiktionary.org/wiki/borne#French) | bollard such as those used to restrict automobiles off a pedestrian area | /bɔʁn/ · noun |
| [coma](https://en.wiktionary.org/wiki/coma#French) | coma (state of unconsciousness) | /kɔ.ma/ · noun |
| [four à micro-ondes](https://en.wiktionary.org/wiki/four%20%C3%A0%20micro-ondes#French) | microwave oven, microwave (oven) | /fu.ʁ‿a mi.kʁo.ɔ̃d/ · noun |

</details>

<details><summary>Words 901–950</summary>

![[Resources/Audio/fr/Words 0901-0950.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [rail](https://en.wiktionary.org/wiki/rail#French) | rail | /ʁaj/ · noun |
| [square](https://en.wiktionary.org/wiki/square#French) | square (public plaza) | /skwaʁ/ · noun |
| [stone](https://en.wiktionary.org/wiki/stone#French) | stoned (high on drugs) | /ston/ · adj |
| [accumulation](https://en.wiktionary.org/wiki/accumulation#French) | accumulation (action of accumulating) | /a.ky.my.la.sjɔ̃/ · noun |
| [clown](https://en.wiktionary.org/wiki/clown#French) | clown (performer) | /klun/ · noun |
| [deal](https://en.wiktionary.org/wiki/deal#French) | a deal: a transaction | /dil/ · noun |
| [light](https://en.wiktionary.org/wiki/light#French) | light, slight | /lajt/ · adj |
| [metal](https://en.wiktionary.org/wiki/metal#French) | metal (music style) | /me.tal/ · noun |
| [pin](https://en.wiktionary.org/wiki/pin#French) | pine, pine tree (Pinus) | /pɛ̃/ · noun |
| [accouchement](https://en.wiktionary.org/wiki/accouchement#French) | delivery (act of giving birth) | /a.kuʃ.mɑ̃/ · noun |
| [admiration](https://en.wiktionary.org/wiki/admiration#French) | admiration | /ad.mi.ʁa.sjɔ̃/ · noun |
| [doyen](https://en.wiktionary.org/wiki/doyen#French) | dean | /dwa.jɛ̃/ · noun |
| [jambon](https://en.wiktionary.org/wiki/jambon#French) | ham | /ʒɑ̃.bɔ̃/ · noun |
| [litre](https://en.wiktionary.org/wiki/litre#French) | litre | /litʁ/ · noun |
| [muscle](https://en.wiktionary.org/wiki/muscle#French) | muscle (contractile tissue, strength) | /myskl/ · noun |
| [obsession](https://en.wiktionary.org/wiki/obsession#French) | obsession | /ɔp.sɛ.sjɔ̃/ · noun |
| [poison](https://en.wiktionary.org/wiki/poison#French) | poison (literal or figurative) | /pwa.zɔ̃/ · noun |
| [system](https://en.wiktionary.org/wiki/system#French) | Word used in star system | /sis.tɛm/ · noun |
| [country](https://en.wiktionary.org/wiki/country#French) | country music | /kœ̃.tʁi/ · noun |
| [justification](https://en.wiktionary.org/wiki/justification#French) | justification (reason, excuse, etc.) | /ʒys.ti.fi.ka.sjɔ̃/ · noun |
| [massage](https://en.wiktionary.org/wiki/massage#French) | physical massage | /ma.saʒ/ · noun |
| [taureau](https://en.wiktionary.org/wiki/taureau#French) | bull | /tɔ.ʁo/ · noun |
| [yes](https://en.wiktionary.org/wiki/yes#French) | yes! | /jɛs/ · intj |
| [ail](https://en.wiktionary.org/wiki/ail#French) | garlic | /aj/ · noun |
| [bœuf](https://en.wiktionary.org/wiki/b%C5%93uf#French) | ox | /bœf/ · noun |
| [delta](https://en.wiktionary.org/wiki/delta#French) | delta (Greek letter) | /dɛl.ta/ · noun |
| [drone](https://en.wiktionary.org/wiki/drone#French) | drone (unmanned aircraft) | /dʁon/ · noun |
| [migration](https://en.wiktionary.org/wiki/migration#French) | migration (of animals) |  · noun |
| [nickel](https://en.wiktionary.org/wiki/nickel#French) | nickel (metal) | /ni.kɛl/ · noun |
| [textile](https://en.wiktionary.org/wiki/textile#French) | able to be made into textiles; fibrous | /tɛk.stil/ · adj |
| [timbre](https://en.wiktionary.org/wiki/timbre#French) | small bell | /tɛ̃bʁ/ · noun |
| [éventuel](https://en.wiktionary.org/wiki/%C3%A9ventuel#French) | possible, hypothetical (that might come about) | /e.vɑ̃.tɥɛl/ · adj |
| [LED](https://en.wiktionary.org/wiki/LED#French) | LED (light-emitting diode) | /lɛd/ · noun |
| [modem](https://en.wiktionary.org/wiki/modem#French) | modem | /mɔ.dɛm/ · noun |
| [penalty](https://en.wiktionary.org/wiki/penalty#French) | penalty, penalty kick | /pe.nal.ti/ · noun |
| [sabre](https://en.wiktionary.org/wiki/sabre#French) | a single-edged sword | /sabʁ/ · noun |
| [violon](https://en.wiktionary.org/wiki/violon#French) | violin | /vjɔ.lɔ̃/ · noun |
| [accrue](https://en.wiktionary.org/wiki/accrue#French) | dry land created by draining | /a.kʁy/ · noun |
| [addition](https://en.wiktionary.org/wiki/addition#French) | addition (operation of adding a number to another) | /a.di.sjɔ̃/ · noun |
| [atlas](https://en.wiktionary.org/wiki/atlas#French) | atlas (collection of maps) | /at.las/ · noun |
| [fraction](https://en.wiktionary.org/wiki/fraction#French) | fraction (small amount) | /fʁak.sjɔ̃/ · noun |
| [nuance](https://en.wiktionary.org/wiki/nuance#French) | nuance: | /nɥɑ̃s/ · noun |
| [speed](https://en.wiktionary.org/wiki/speed#French) | speed (amphetamine) | /spid/ · noun |
| [tram](https://en.wiktionary.org/wiki/tram#French) | tram (UK), streetcar (US) | /tʁam/ · noun |
| [uranium](https://en.wiktionary.org/wiki/uranium#French) | uranium | /y.ʁa.njɔm/ · noun |
| [anecdote](https://en.wiktionary.org/wiki/anecdote#French) | anecdote | /a.nɛk.dɔt/ · noun |
| [banal](https://en.wiktionary.org/wiki/banal#French) | public, shared | /ba.nal/ · adj |
| [bug](https://en.wiktionary.org/wiki/bug#French) | bug | /bœɡ/ · noun |
| [cube](https://en.wiktionary.org/wiki/cube#French) | cube (all senses) | /kyb/ · noun |
| [land](https://en.wiktionary.org/wiki/land#French) | land (region of Germany or Austria) |  · noun |

</details>

<details><summary>Words 951–1000</summary>

![[Resources/Audio/fr/Words 0951-1000.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [rousse](https://en.wiktionary.org/wiki/rousse#French) | redhead (woman) | /ʁus/ · noun |
| [vase](https://en.wiktionary.org/wiki/vase#French) | silt, mud | /vaz/ · noun |
| [minuscule](https://en.wiktionary.org/wiki/minuscule#French) | tiny, minute, minuscule | /mi.nys.kyl/ · adj |
| [natal](https://en.wiktionary.org/wiki/natal#French) | native | /na.tal/ · adj |
| [pat](https://en.wiktionary.org/wiki/pat#French) | stalemate | /pat/ · noun |
| [senior](https://en.wiktionary.org/wiki/senior#French) | senior (older player) | /se.njɔʁ/ · noun |
| [sentence](https://en.wiktionary.org/wiki/sentence#French) | sentence | /sɑ̃.tɑ̃s/ · noun |
| [soul](https://en.wiktionary.org/wiki/soul#French) | post-1990 spelling of soûl, itself an alternative form of saoul (“drunk”) | /su/ · adj |
| [tomate](https://en.wiktionary.org/wiki/tomate#French) | tomato (plant) | /tɔ.mat/ · noun |
| [abuser](https://en.wiktionary.org/wiki/abuser#French) | to mislead | /a.by.ze/ · verb |
| [book](https://en.wiktionary.org/wiki/book#French) | portfolio | /buk/ · noun |
| [famine](https://en.wiktionary.org/wiki/famine#French) | famine | /fa.min/ · noun |
| [pommes frites](https://en.wiktionary.org/wiki/pommes%20frites#French) | fried apples | /pɔm fʁit/ · noun |
| [spot](https://en.wiktionary.org/wiki/spot#French) | light spot | /spɔt/ · noun |
| [tee](https://en.wiktionary.org/wiki/tee#French) | tee |  · noun |
| [CS](https://en.wiktionary.org/wiki/CS#French) | SC (“soccer club”); initialism of club de soccer | /se.ɛs/ · noun |
| [baleine](https://en.wiktionary.org/wiki/baleine#French) | whale (mammal) | /ba.lɛn/ · noun |
| [briller](https://en.wiktionary.org/wiki/briller#French) | to shine, to sparkle | /bʁi.je/ · verb |
| [fer à repasser](https://en.wiktionary.org/wiki/fer%20%C3%A0%20repasser#French) | clothes iron, smoothing iron | /fɛ.ʁ‿a ʁ(ə).pa.se/ · noun |
| [fiancée](https://en.wiktionary.org/wiki/fianc%C3%A9e#French) | a large yellow underwing | /fjɑ̃.se/ · noun |
| [mater](https://en.wiktionary.org/wiki/mater#French) | to checkmate | /ma.te/ · verb |
| [palace](https://en.wiktionary.org/wiki/palace#French) | luxury hotel | /pa.las/ · noun |
| [rime](https://en.wiktionary.org/wiki/rime#French) | rhyme | /ʁim/ · noun |
| [river](https://en.wiktionary.org/wiki/river#French) | to drive/set a rivet | /ʁi.ve/ · verb |
| [ver](https://en.wiktionary.org/wiki/ver#French) | worm | /vɛʁ/ · noun |
| [combustion](https://en.wiktionary.org/wiki/combustion#French) | combustion, burning, incineration | /kɔ̃.bys.tjɔ̃/ · noun |
| [nutrition](https://en.wiktionary.org/wiki/nutrition#French) | nutrition | /ny.tʁi.sjɔ̃/ · noun |
| [rein](https://en.wiktionary.org/wiki/rein#French) | kidney | /ʁɛ̃/ · noun |
| [roc](https://en.wiktionary.org/wiki/roc#French) | rock | /ʁɔk/ · noun |
| [soccer](https://en.wiktionary.org/wiki/soccer#French) | soccer (association football) | /sɔ.kœʁ/ · noun |
| [transparent](https://en.wiktionary.org/wiki/transparent#French) | transparent; see-through | /tʁɑ̃s.pa.ʁɑ̃/ · adj |
| [abstention](https://en.wiktionary.org/wiki/abstention#French) | abstention | /ap.stɑ̃.sjɔ̃/ · noun |
| [accession](https://en.wiktionary.org/wiki/accession#French) | accession (to throne) | /ak.sɛ.sjɔ̃/ · noun |
| [bot](https://en.wiktionary.org/wiki/bot#French) | affected by the deformation known as clubfoot | /bo/ · adj |
| [moustache](https://en.wiktionary.org/wiki/moustache#French) | moustache, mustache | /mus.taʃ/ · noun |
| [niche](https://en.wiktionary.org/wiki/niche#French) | niche | /niʃ/ · noun |
| [pointer](https://en.wiktionary.org/wiki/pointer#French) | to point to/at | /pwɛ̃.te/ · verb |
| [protester](https://en.wiktionary.org/wiki/protester#French) | to protest; to object | /pʁɔ.tɛs.te/ · verb |
| [ring](https://en.wiktionary.org/wiki/ring#French) | ring | /ʁiŋɡ/ · noun |
| [sic](https://en.wiktionary.org/wiki/sic#French) | sic (thus) | /sik/ · adv |
| [bacon](https://en.wiktionary.org/wiki/bacon#French) | bacon | /be.kɔn/ · noun |
| [check](https://en.wiktionary.org/wiki/check#French) | fist bump | /tʃɛk/ · noun |
| [coke](https://en.wiktionary.org/wiki/coke#French) | coke (form of carbon) | /kɔk/ · noun |
| [email](https://en.wiktionary.org/wiki/email#French) | email | /i.mɛl/ · noun |
| [intersection](https://en.wiktionary.org/wiki/intersection#French) | intersection | /ɛ̃.tɛʁ.sɛk.sjɔ̃/ · noun |
| [pluriel](https://en.wiktionary.org/wiki/pluriel#French) | plural | /ply.ʁjɛl/ · noun |
| [prototype](https://en.wiktionary.org/wiki/prototype#French) | prototype | /pʁɔ.tɔ.tip/ · noun |
| [self](https://en.wiktionary.org/wiki/self#French) | self-service restaurant or canteen. |  · noun |
| [verbal](https://en.wiktionary.org/wiki/verbal#French) | verbal | /vɛʁ.bal/ · adj |
| [Catalan](https://en.wiktionary.org/wiki/Catalan#French) | Catalan, Catalonian (native or inhabitant of Catalonia) (usually male) | /ka.ta.lɑ̃/ · noun |

</details>

## Question bank

Try before opening the answers. Different tasks use the same sentence to practise complementary skills. Open translation and explanation tasks can have valid alternatives.

### Articles and gender · 50 questions

**fr-Q0001 · Fill the gap**

Il a été condamné à de ____ prison.

He was sentenced to prison.

[[French#^fr-Q0001-answer|Compare the answer]]
^fr-Q0001

**fr-Q0002 · Choose the form**

Il a été condamné à de ____ prison.

He was sentenced to prison.

Choices: les / la / le / un

[[French#^fr-Q0002-answer|Compare the answer]]
^fr-Q0002

**fr-Q0003 · Edit the changed sentence**

Il n'est qu'【le】 homme d'affaires.

He is nothing but a businessman.

[[French#^fr-Q0003-answer|Compare the answer]]
^fr-Q0003

**fr-Q0004 · Build the sentence**

Arrange: qu'un / homme / d'affaires. / n'est / Il

He is nothing but a businessman.

[[French#^fr-Q0004-answer|Compare the answer]]
^fr-Q0004

**fr-Q0005 · Write a translation**

Write this in French: He is a very good friend, yet a little lazy.

[[French#^fr-Q0005-answer|Compare the answer]]
^fr-Q0005

**fr-Q0006 · Explain the grammar**

C'est 【un】 très bon ami, mais il est un peu paresseux.

He is a very good friend, yet a little lazy.

[[French#^fr-Q0006-answer|Compare the answer]]
^fr-Q0006

**fr-Q0007 · Fill the gap**

Êtes-vous prêts pour ____ voyage ?

Are you ready for the trip?

[[French#^fr-Q0007-answer|Compare the answer]]
^fr-Q0007

**fr-Q0008 · Choose the form**

Êtes-vous prêts pour ____ voyage ?

Are you ready for the trip?

Choices: un / le / les / la

[[French#^fr-Q0008-answer|Compare the answer]]
^fr-Q0008

**fr-Q0009 · Edit the changed sentence**

Dans l'ouverture, ne déplacez que 【le】 pions qui aident à développer les pièces.

In the opening, move only those pawns that help develop the pieces.

[[French#^fr-Q0009-answer|Compare the answer]]
^fr-Q0009

**fr-Q0010 · Build the sentence**

Arrange: pions / l'ouverture, / à / Dans / qui / pièces. / déplacez / que / développer / les / ne / les / aident

In the opening, move only those pawns that help develop the pieces.

[[French#^fr-Q0010-answer|Compare the answer]]
^fr-Q0010

**fr-Q0011 · Write a translation**

Write this in French: This student's books are new.

[[French#^fr-Q0011-answer|Compare the answer]]
^fr-Q0011

**fr-Q0012 · Explain the grammar**

【Les】 livres de cet étudiant sont neufs.

This student's books are new.

[[French#^fr-Q0012-answer|Compare the answer]]
^fr-Q0012

**fr-Q0013 · Fill the gap**

____ lacets de Tom sont défaits.

Tom's shoelaces are untied.

[[French#^fr-Q0013-answer|Compare the answer]]
^fr-Q0013

**fr-Q0014 · Choose the form**

____ lacets de Tom sont défaits.

Tom's shoelaces are untied.

Choices: un / la / le / Les

[[French#^fr-Q0014-answer|Compare the answer]]
^fr-Q0014

**fr-Q0015 · Edit the changed sentence**

J'ai décidé d'acheter 【le】 voiture bleue.

I've decided to buy the blue car.

[[French#^fr-Q0015-answer|Compare the answer]]
^fr-Q0015

**fr-Q0016 · Build the sentence**

Arrange: décidé / J'ai / d'acheter / voiture / la / bleue.

I've decided to buy the blue car.

[[French#^fr-Q0016-answer|Compare the answer]]
^fr-Q0016

**fr-Q0017 · Write a translation**

Write this in French: He used a fake I.D.

[[French#^fr-Q0017-answer|Compare the answer]]
^fr-Q0017

**fr-Q0018 · Explain the grammar**

Il s'est servi d'【une】 fausse carte d'identité.

He used a fake I.D.

[[French#^fr-Q0018-answer|Compare the answer]]
^fr-Q0018

**fr-Q0019 · Fill the gap**

Tout ____ monde doit être au courant.

Everybody must know.

[[French#^fr-Q0019-answer|Compare the answer]]
^fr-Q0019

**fr-Q0020 · Choose the form**

Tout ____ monde doit être au courant.

Everybody must know.

Choices: le / la / les / un

[[French#^fr-Q0020-answer|Compare the answer]]
^fr-Q0020

**fr-Q0021 · Edit the changed sentence**

Je me suis assis derrière 【le】 très grande personne au théâtre.

I sat behind a very tall person at the theater.

[[French#^fr-Q0021-answer|Compare the answer]]
^fr-Q0021

**fr-Q0022 · Build the sentence**

Arrange: théâtre. / Je / me / au / grande / derrière / personne / suis / assis / une / très

I sat behind a very tall person at the theater.

[[French#^fr-Q0022-answer|Compare the answer]]
^fr-Q0022

**fr-Q0023 · Write a translation**

Write this in French: My legs feel heavy as lead.

[[French#^fr-Q0023-answer|Compare the answer]]
^fr-Q0023

**fr-Q0024 · Explain the grammar**

Mes pieds sont devenus 【des】 bâtons.

My legs feel heavy as lead.

[[French#^fr-Q0024-answer|Compare the answer]]
^fr-Q0024

**fr-Q0025 · Fill the gap**

Sami n'est pas ____ génie.

Sami is not a genius.

[[French#^fr-Q0025-answer|Compare the answer]]
^fr-Q0025

**fr-Q0026 · Choose the form**

Sami n'est pas ____ génie.

Sami is not a genius.

Choices: un / la / le / les

[[French#^fr-Q0026-answer|Compare the answer]]
^fr-Q0026

**fr-Q0027 · Edit the changed sentence**

【le】 rencontre d'athlétisme fut reportée à cause de la pluie.

The athletic meet was postponed due to rain.

[[French#^fr-Q0027-answer|Compare the answer]]
^fr-Q0027

**fr-Q0028 · Build the sentence**

Arrange: reportée / à / La / d'athlétisme / pluie. / fut / de / rencontre / la / cause

The athletic meet was postponed due to rain.

[[French#^fr-Q0028-answer|Compare the answer]]
^fr-Q0028

**fr-Q0029 · Write a translation**

Write this in French: Some animals can sense the coming of a storm.

[[French#^fr-Q0029-answer|Compare the answer]]
^fr-Q0029

**fr-Q0030 · Explain the grammar**

Certains animaux peuvent sentir l'arrivée d'【un】 orage.

Some animals can sense the coming of a storm.

[[French#^fr-Q0030-answer|Compare the answer]]
^fr-Q0030

**fr-Q0031 · Fill the gap**

____ radio nous a averti d'un risque d'inondation.

The radio warned us of the possibility of flooding.

[[French#^fr-Q0031-answer|Compare the answer]]
^fr-Q0031

**fr-Q0032 · Choose the form**

____ radio nous a averti d'un risque d'inondation.

The radio warned us of the possibility of flooding.

Choices: un / les / La / le

[[French#^fr-Q0032-answer|Compare the answer]]
^fr-Q0032

**fr-Q0033 · Edit the changed sentence**

Je 【la】 rencontre vendredi prochain.

I am meeting him next Friday.

[[French#^fr-Q0033-answer|Compare the answer]]
^fr-Q0033

**fr-Q0034 · Build the sentence**

Arrange: vendredi / prochain. / le / Je / rencontre

I am meeting him next Friday.

[[French#^fr-Q0034-answer|Compare the answer]]
^fr-Q0034

**fr-Q0035 · Write a translation**

Write this in French: I'm a cat.

[[French#^fr-Q0035-answer|Compare the answer]]
^fr-Q0035

**fr-Q0036 · Explain the grammar**

Je suis 【un】 chat.

I'm a cat.

[[French#^fr-Q0036-answer|Compare the answer]]
^fr-Q0036

**fr-Q0037 · Fill the gap**

Êtes-vous en train de ____ draguer ?

Are you flirting with her?

[[French#^fr-Q0037-answer|Compare the answer]]
^fr-Q0037

**fr-Q0038 · Choose the form**

Êtes-vous en train de ____ draguer ?

Are you flirting with her?

Choices: les / un / la / le

[[French#^fr-Q0038-answer|Compare the answer]]
^fr-Q0038

**fr-Q0039 · Edit the changed sentence**

Mon père répare 【le】 chaises cassées.

My father fixes broken chairs.

[[French#^fr-Q0039-answer|Compare the answer]]
^fr-Q0039

**fr-Q0040 · Build the sentence**

Arrange: père / Mon / cassées. / chaises / répare / des

My father fixes broken chairs.

[[French#^fr-Q0040-answer|Compare the answer]]
^fr-Q0040

**fr-Q0041 · Write a translation**

Write this in French: Gerunds are very funny.

[[French#^fr-Q0041-answer|Compare the answer]]
^fr-Q0041

**fr-Q0042 · Explain the grammar**

【Les】 gérondifs sont très amusants.

Gerunds are very funny.

[[French#^fr-Q0042-answer|Compare the answer]]
^fr-Q0042

**fr-Q0043 · Fill the gap**

Après avoir marché ____ moment, nous arrivâmes au lac.

After we walked for a while, we arrived at the lake.

[[French#^fr-Q0043-answer|Compare the answer]]
^fr-Q0043

**fr-Q0044 · Choose the form**

Après avoir marché ____ moment, nous arrivâmes au lac.

After we walked for a while, we arrived at the lake.

Choices: un / la / les / le

[[French#^fr-Q0044-answer|Compare the answer]]
^fr-Q0044

**fr-Q0045 · Edit the changed sentence**

As-tu déjà été trahi par 【le】 ami ?

Have you ever been betrayed by a friend?

[[French#^fr-Q0045-answer|Compare the answer]]
^fr-Q0045

**fr-Q0046 · Build the sentence**

Arrange: As-tu / déjà / un / été / ami / par / ? / trahi

Have you ever been betrayed by a friend?

[[French#^fr-Q0046-answer|Compare the answer]]
^fr-Q0046

**fr-Q0047 · Write a translation**

Write this in French: Have you ever had a serious illness?

[[French#^fr-Q0047-answer|Compare the answer]]
^fr-Q0047

**fr-Q0048 · Explain the grammar**

As-tu jamais eu 【une】 maladie sérieuse ?

Have you ever had a serious illness?

[[French#^fr-Q0048-answer|Compare the answer]]
^fr-Q0048

**fr-Q0049 · Fill the gap**

____ manière répandue de financer un déficit est de proposer des obligations.

A common way to finance a budget deficit is to issue bonds.

[[French#^fr-Q0049-answer|Compare the answer]]
^fr-Q0049

**fr-Q0050 · Choose the form**

____ manière répandue de financer un déficit est de proposer des obligations.

A common way to finance a budget deficit is to issue bonds.

Choices: le / Une / la / les

[[French#^fr-Q0050-answer|Compare the answer]]
^fr-Q0050


### Contractions and partitives · 50 questions

**fr-Q0051 · Edit the changed sentence**

Roger travaille 【de la】 matin au soir.

Roger works from morning till night.

[[French#^fr-Q0051-answer|Compare the answer]]
^fr-Q0051

**fr-Q0052 · Build the sentence**

Arrange: soir. / travaille / du / matin / Roger / au

Roger works from morning till night.

[[French#^fr-Q0052-answer|Compare the answer]]
^fr-Q0052

**fr-Q0053 · Write a translation**

Write this in French: This part of the museum is temporarily off-limits to visitors.

[[French#^fr-Q0053-answer|Compare the answer]]
^fr-Q0053

**fr-Q0054 · Explain the grammar**

Cette partie 【du】 musée est temporairement inaccessible aux visiteurs.

This part of the museum is temporarily off-limits to visitors.

[[French#^fr-Q0054-answer|Compare the answer]]
^fr-Q0054

**fr-Q0055 · Fill the gap**

Allez-vous ____ théâtre ce soir ?

Are you going to the theater tonight?

[[French#^fr-Q0055-answer|Compare the answer]]
^fr-Q0055

**fr-Q0056 · Choose the form**

Allez-vous ____ théâtre ce soir ?

Are you going to the theater tonight?

Choices: au / du / de la / aux

[[French#^fr-Q0056-answer|Compare the answer]]
^fr-Q0056

**fr-Q0057 · Edit the changed sentence**

Le gouvernement est tombé après un vote 【du】 parlement.

The government collapsed after a vote in parliament.

[[French#^fr-Q0057-answer|Compare the answer]]
^fr-Q0057

**fr-Q0058 · Build the sentence**

Arrange: est / après / vote / au / Le / parlement. / un / gouvernement / tombé

The government collapsed after a vote in parliament.

[[French#^fr-Q0058-answer|Compare the answer]]
^fr-Q0058

**fr-Q0059 · Write a translation**

Write this in French: Jenny washed the kitchen wall twice a year.

[[French#^fr-Q0059-answer|Compare the answer]]
^fr-Q0059

**fr-Q0060 · Explain the grammar**

Jenny lavait le mur 【de la】 cuisine deux fois par an.

Jenny washed the kitchen wall twice a year.

[[French#^fr-Q0060-answer|Compare the answer]]
^fr-Q0060

**fr-Q0061 · Fill the gap**

La dépendance ____ drogues a entraîné la déchéance de beaucoup de personnes.

Drug addiction degraded many people.

[[French#^fr-Q0061-answer|Compare the answer]]
^fr-Q0061

**fr-Q0062 · Choose the form**

La dépendance ____ drogues a entraîné la déchéance de beaucoup de personnes.

Drug addiction degraded many people.

Choices: du / aux / au / de la

[[French#^fr-Q0062-answer|Compare the answer]]
^fr-Q0062

**fr-Q0063 · Edit the changed sentence**

Georges travaillait 【du】 même manière que son père.

George did business in the same manner as his father.

[[French#^fr-Q0063-answer|Compare the answer]]
^fr-Q0063

**fr-Q0064 · Build the sentence**

Arrange: Georges / manière / même / père. / la / son / que / travaillait / de

George did business in the same manner as his father.

[[French#^fr-Q0064-answer|Compare the answer]]
^fr-Q0064

**fr-Q0065 · Write a translation**

Write this in French: I have around thirty of them.

[[French#^fr-Q0065-answer|Compare the answer]]
^fr-Q0065

**fr-Q0066 · Explain the grammar**

J'en ai environ trente 【de la】 sorte.

I have around thirty of them.

[[French#^fr-Q0066-answer|Compare the answer]]
^fr-Q0066

**fr-Q0067 · Fill the gap**

Est-ce ____ musique ce que j'entends ?

Is that music I hear?

[[French#^fr-Q0067-answer|Compare the answer]]
^fr-Q0067

**fr-Q0068 · Choose the form**

Est-ce ____ musique ce que j'entends ?

Is that music I hear?

Choices: aux / de la / au / du

[[French#^fr-Q0068-answer|Compare the answer]]
^fr-Q0068

**fr-Q0069 · Edit the changed sentence**

【du】 début, je ne l'aimais pas.

At first, I didn't like him.

[[French#^fr-Q0069-answer|Compare the answer]]
^fr-Q0069

**fr-Q0070 · Build the sentence**

Arrange: début, / Au / pas. / l'aimais / je / ne

At first, I didn't like him.

[[French#^fr-Q0070-answer|Compare the answer]]
^fr-Q0070

**fr-Q0071 · Write a translation**

Write this in French: Only individuals with an aberrant temperament can in the long run retain their self-esteem in the face of the disesteem of their fellows.

[[French#^fr-Q0071-answer|Compare the answer]]
^fr-Q0071

**fr-Q0072 · Explain the grammar**

Seuls les individus 【au】 tempérament aberrant peuvent conserver, sur la durée, leur amour-propre, confrontés à la mésestime de leurs semblables.

Only individuals with an aberrant temperament can in the long run retain their self-esteem in the face of the disesteem of their fellows.

[[French#^fr-Q0072-answer|Compare the answer]]
^fr-Q0072

**fr-Q0073 · Fill the gap**

Si vous parlez à un homme dans un language qu'il comprend, ça lui entre dans le crâne. Si vous lui parlez dans sa langue, ça lui va ____ cœur.

If you talk to a man in a language he understands, that goes to his head. If you talk to him in his language, that goes to his heart.

[[French#^fr-Q0073-answer|Compare the answer]]
^fr-Q0073

**fr-Q0074 · Choose the form**

Si vous parlez à un homme dans un language qu'il comprend, ça lui entre dans le crâne. Si vous lui parlez dans sa langue, ça lui va ____ cœur.

If you talk to a man in a language he understands, that goes to his head. If you talk to him in his language, that goes to his heart.

Choices: du / aux / au / de la

[[French#^fr-Q0074-answer|Compare the answer]]
^fr-Q0074

**fr-Q0075 · Edit the changed sentence**

Il n'était pas conscient 【du】 situation.

He was unaware of the situation.

[[French#^fr-Q0075-answer|Compare the answer]]
^fr-Q0075

**fr-Q0076 · Build the sentence**

Arrange: n'était / situation. / pas / Il / de / conscient / la

He was unaware of the situation.

[[French#^fr-Q0076-answer|Compare the answer]]
^fr-Q0076

**fr-Q0077 · Write a translation**

Write this in French: Tom ate a chicken sandwich.

[[French#^fr-Q0077-answer|Compare the answer]]
^fr-Q0077

**fr-Q0078 · Explain the grammar**

Tom a mangé un sandwich 【au】 poulet.

Tom ate a chicken sandwich.

[[French#^fr-Q0078-answer|Compare the answer]]
^fr-Q0078

**fr-Q0079 · Fill the gap**

Je n’ai rien mangé à part ____ pain et du beurre.

I haven't eaten anything but bread and butter.

[[French#^fr-Q0079-answer|Compare the answer]]
^fr-Q0079

**fr-Q0080 · Choose the form**

Je n’ai rien mangé à part ____ pain et du beurre.

I haven't eaten anything but bread and butter.

Choices: du / au / aux / de la

[[French#^fr-Q0080-answer|Compare the answer]]
^fr-Q0080

**fr-Q0081 · Edit the changed sentence**

Nous avons profité 【du】 paix depuis plus de quarante ans.

We have been enjoying peace for more than 40 years.

[[French#^fr-Q0081-answer|Compare the answer]]
^fr-Q0081

**fr-Q0082 · Build the sentence**

Arrange: ans. / plus / de / quarante / profité / depuis / avons / la / Nous / de / paix

We have been enjoying peace for more than 40 years.

[[French#^fr-Q0082-answer|Compare the answer]]
^fr-Q0082

**fr-Q0083 · Write a translation**

Write this in French: It's already eleven. It's high time you were in bed.

[[French#^fr-Q0083-answer|Compare the answer]]
^fr-Q0083

**fr-Q0084 · Explain the grammar**

Il est déjà onze heures. Tu devrais déjà être 【au】 lit.

It's already eleven. It's high time you were in bed.

[[French#^fr-Q0084-answer|Compare the answer]]
^fr-Q0084

**fr-Q0085 · Fill the gap**

Il a aspiré ____ poste de Premier Ministre.

He aspired to the position of Prime Minister.

[[French#^fr-Q0085-answer|Compare the answer]]
^fr-Q0085

**fr-Q0086 · Choose the form**

Il a aspiré ____ poste de Premier Ministre.

He aspired to the position of Prime Minister.

Choices: de la / du / aux / au

[[French#^fr-Q0086-answer|Compare the answer]]
^fr-Q0086

**fr-Q0087 · Edit the changed sentence**

Je suis 【du】 regret de ne pas être d'accord avec ton opinion.

It pains me to disagree with your opinion.

[[French#^fr-Q0087-answer|Compare the answer]]
^fr-Q0087

**fr-Q0088 · Build the sentence**

Arrange: ton / Je / regret / de / être / au / pas / opinion. / ne / suis / d'accord / avec

It pains me to disagree with your opinion.

[[French#^fr-Q0088-answer|Compare the answer]]
^fr-Q0088

**fr-Q0089 · Write a translation**

Write this in French: I'm proud of the work I've done here.

[[French#^fr-Q0089-answer|Compare the answer]]
^fr-Q0089

**fr-Q0090 · Explain the grammar**

Je suis fière 【du】 travail que j'ai accompli ici.

I'm proud of the work I've done here.

[[French#^fr-Q0090-answer|Compare the answer]]
^fr-Q0090

**fr-Q0091 · Fill the gap**

La terre est l'une des planètes ____ système solaire.

The earth is one of the sun's planets.

[[French#^fr-Q0091-answer|Compare the answer]]
^fr-Q0091

**fr-Q0092 · Choose the form**

La terre est l'une des planètes ____ système solaire.

The earth is one of the sun's planets.

Choices: du / aux / de la / au

[[French#^fr-Q0092-answer|Compare the answer]]
^fr-Q0092

**fr-Q0093 · Edit the changed sentence**

Je montai par l'ascenseur 【du】 troisième étage.

I took the elevator to the third floor.

[[French#^fr-Q0093-answer|Compare the answer]]
^fr-Q0093

**fr-Q0094 · Build the sentence**

Arrange: l'ascenseur / au / Je / montai / troisième / par / étage.

I took the elevator to the third floor.

[[French#^fr-Q0094-answer|Compare the answer]]
^fr-Q0094

**fr-Q0095 · Write a translation**

Write this in French: I've been living in Canada for five years.

[[French#^fr-Q0095-answer|Compare the answer]]
^fr-Q0095

**fr-Q0096 · Explain the grammar**

Ça fait 5 ans que j'habite 【au】 Canada.

I've been living in Canada for five years.

[[French#^fr-Q0096-answer|Compare the answer]]
^fr-Q0096

**fr-Q0097 · Fill the gap**

Je vais aller pleurer ____ lit.

I'll go crying to bed.

[[French#^fr-Q0097-answer|Compare the answer]]
^fr-Q0097

**fr-Q0098 · Choose the form**

Je vais aller pleurer ____ lit.

I'll go crying to bed.

Choices: aux / du / au / de la

[[French#^fr-Q0098-answer|Compare the answer]]
^fr-Q0098

**fr-Q0099 · Edit the changed sentence**

Tom s'est fait agressé en rentrant chez lui 【de la】 travail.

Tom was mugged on his way home from work.

[[French#^fr-Q0099-answer|Compare the answer]]
^fr-Q0099

**fr-Q0100 · Build the sentence**

Arrange: rentrant / Tom / s'est / agressé / travail. / lui / fait / du / chez / en

Tom was mugged on his way home from work.

[[French#^fr-Q0100-answer|Compare the answer]]
^fr-Q0100


### Subject pronouns · 50 questions

**fr-Q0101 · Write a translation**

Write this in French: Tom certainly doesn't seem to know what he's doing.

[[French#^fr-Q0101-answer|Compare the answer]]
^fr-Q0101

**fr-Q0102 · Explain the grammar**

Tom ne semble certainement pas savoir ce qu'【il】 est en train de faire.

Tom certainly doesn't seem to know what he's doing.

[[French#^fr-Q0102-answer|Compare the answer]]
^fr-Q0102

**fr-Q0103 · Fill the gap**

____ ne pense pas que tu devrais manger ça.

I don't think you should eat that.

[[French#^fr-Q0103-answer|Compare the answer]]
^fr-Q0103

**fr-Q0104 · Choose the form**

____ ne pense pas que tu devrais manger ça.

I don't think you should eat that.

Choices: nous / Je / il / tu

[[French#^fr-Q0104-answer|Compare the answer]]
^fr-Q0104

**fr-Q0105 · Edit the changed sentence**

【tu】 n'ai pas appris cela en lisant.

I didn't learn this through reading.

[[French#^fr-Q0105-answer|Compare the answer]]
^fr-Q0105

**fr-Q0106 · Build the sentence**

Arrange: pas / cela / en / n'ai / Je / lisant. / appris

I didn't learn this through reading.

[[French#^fr-Q0106-answer|Compare the answer]]
^fr-Q0106

**fr-Q0107 · Write a translation**

Write this in French: May I use this telephone?

[[French#^fr-Q0107-answer|Compare the answer]]
^fr-Q0107

**fr-Q0108 · Explain the grammar**

Puis-【je】 utiliser ce téléphone ?

May I use this telephone?

[[French#^fr-Q0108-answer|Compare the answer]]
^fr-Q0108

**fr-Q0109 · Fill the gap**

____ vous trompez. Ce n'est pas ce que j'ai dit.

You're mistaken. That's not what I said.

[[French#^fr-Q0109-answer|Compare the answer]]
^fr-Q0109

**fr-Q0110 · Choose the form**

____ vous trompez. Ce n'est pas ce que j'ai dit.

You're mistaken. That's not what I said.

Choices: Vous / tu / il / je

[[French#^fr-Q0110-answer|Compare the answer]]
^fr-Q0110

**fr-Q0111 · Edit the changed sentence**

【tu】 veux être remarqué.

I want to be noticed.

[[French#^fr-Q0111-answer|Compare the answer]]
^fr-Q0111

**fr-Q0112 · Build the sentence**

Arrange: remarqué. / veux / être / Je

I want to be noticed.

[[French#^fr-Q0112-answer|Compare the answer]]
^fr-Q0112

**fr-Q0113 · Write a translation**

Write this in French: I lost consciousness.

[[French#^fr-Q0113-answer|Compare the answer]]
^fr-Q0113

**fr-Q0114 · Explain the grammar**

【Je】 perdis conscience.

I lost consciousness.

[[French#^fr-Q0114-answer|Compare the answer]]
^fr-Q0114

**fr-Q0115 · Fill the gap**

Peux-____ m'aider à apprendre l'espéranto?

Can you help me learn Esperanto?

[[French#^fr-Q0115-answer|Compare the answer]]
^fr-Q0115

**fr-Q0116 · Choose the form**

Peux-____ m'aider à apprendre l'espéranto?

Can you help me learn Esperanto?

Choices: il / nous / je / tu

[[French#^fr-Q0116-answer|Compare the answer]]
^fr-Q0116

**fr-Q0117 · Edit the changed sentence**

【tu】 ne peux m'empêcher de me sentir quelque peu soulagée.

I can't help but feel a little relieved.

[[French#^fr-Q0117-answer|Compare the answer]]
^fr-Q0117

**fr-Q0118 · Build the sentence**

Arrange: sentir / me / peu / m'empêcher / soulagée. / Je / quelque / peux / de / ne

I can't help but feel a little relieved.

[[French#^fr-Q0118-answer|Compare the answer]]
^fr-Q0118

**fr-Q0119 · Write a translation**

Write this in French: Should I call you tomorrow?

[[French#^fr-Q0119-answer|Compare the answer]]
^fr-Q0119

**fr-Q0120 · Explain the grammar**

Dois-【je】 t'appeler demain ?

Should I call you tomorrow?

[[French#^fr-Q0120-answer|Compare the answer]]
^fr-Q0120

**fr-Q0121 · Fill the gap**

____ vous en donnerai autant que vous en voulez.

I'll give you as many as you like.

[[French#^fr-Q0121-answer|Compare the answer]]
^fr-Q0121

**fr-Q0122 · Choose the form**

____ vous en donnerai autant que vous en voulez.

I'll give you as many as you like.

Choices: nous / Je / tu / il

[[French#^fr-Q0122-answer|Compare the answer]]
^fr-Q0122

**fr-Q0123 · Edit the changed sentence**

【je】 n'as rien à te reprocher.

You don't have to blame yourself for that.

[[French#^fr-Q0123-answer|Compare the answer]]
^fr-Q0123

**fr-Q0124 · Build the sentence**

Arrange: n'as / Tu / reprocher. / rien / te / à

You don't have to blame yourself for that.

[[French#^fr-Q0124-answer|Compare the answer]]
^fr-Q0124

**fr-Q0125 · Write a translation**

Write this in French: They lived in Spain for several years.

[[French#^fr-Q0125-answer|Compare the answer]]
^fr-Q0125

**fr-Q0126 · Explain the grammar**

【Ils】 ont vécu en Espagne pendant plusieurs années.

They lived in Spain for several years.

[[French#^fr-Q0126-answer|Compare the answer]]
^fr-Q0126

**fr-Q0127 · Fill the gap**

J'attends toujours que Tom et Mary me rendent l'argent que ____ leur ai prêté.

I'm still waiting for Tom and Mary to pay me back the money I lent them.

[[French#^fr-Q0127-answer|Compare the answer]]
^fr-Q0127

**fr-Q0128 · Choose the form**

J'attends toujours que Tom et Mary me rendent l'argent que ____ leur ai prêté.

I'm still waiting for Tom and Mary to pay me back the money I lent them.

Choices: je / il / tu / nous

[[French#^fr-Q0128-answer|Compare the answer]]
^fr-Q0128

**fr-Q0129 · Edit the changed sentence**

Combien t'ont-【je】 donné de ta guimbarde ?

How much did they give you for your old car?

[[French#^fr-Q0129-answer|Compare the answer]]
^fr-Q0129

**fr-Q0130 · Build the sentence**

Arrange: donné / Combien / de / t'ont-ils / guimbarde / ta / ?

How much did they give you for your old car?

[[French#^fr-Q0130-answer|Compare the answer]]
^fr-Q0130

**fr-Q0131 · Write a translation**

Write this in French: I want to try this.

[[French#^fr-Q0131-answer|Compare the answer]]
^fr-Q0131

**fr-Q0132 · Explain the grammar**

【Je】 veux essayer ça.

I want to try this.

[[French#^fr-Q0132-answer|Compare the answer]]
^fr-Q0132

**fr-Q0133 · Fill the gap**

Pourquoi avez-____ laissé Tom partir ?

Why did you let Tom go?

[[French#^fr-Q0133-answer|Compare the answer]]
^fr-Q0133

**fr-Q0134 · Choose the form**

Pourquoi avez-____ laissé Tom partir ?

Why did you let Tom go?

Choices: il / tu / je / vous

[[French#^fr-Q0134-answer|Compare the answer]]
^fr-Q0134

**fr-Q0135 · Edit the changed sentence**

【tu】 n'ai pas envie de marcher jusqu'à chez moi tout seul.

I don't want to walk home by myself.

[[French#^fr-Q0135-answer|Compare the answer]]
^fr-Q0135

**fr-Q0136 · Build the sentence**

Arrange: n'ai / chez / de / pas / jusqu'à / moi / envie / seul. / Je / tout / marcher

I don't want to walk home by myself.

[[French#^fr-Q0136-answer|Compare the answer]]
^fr-Q0136

**fr-Q0137 · Write a translation**

Write this in French: There's something I want to discuss with you.

[[French#^fr-Q0137-answer|Compare the answer]]
^fr-Q0137

**fr-Q0138 · Explain the grammar**

【Il】 y a quelque chose dont je veux m'entretenir avec vous.

There's something I want to discuss with you.

[[French#^fr-Q0138-answer|Compare the answer]]
^fr-Q0138

**fr-Q0139 · Fill the gap**

____ suis vraiment dangereux.

I am very dangerous.

[[French#^fr-Q0139-answer|Compare the answer]]
^fr-Q0139

**fr-Q0140 · Choose the form**

____ suis vraiment dangereux.

I am very dangerous.

Choices: tu / il / nous / Je

[[French#^fr-Q0140-answer|Compare the answer]]
^fr-Q0140

**fr-Q0141 · Edit the changed sentence**

【tu】 vais essayer de rester bref.

I'll try to keep this brief.

[[French#^fr-Q0141-answer|Compare the answer]]
^fr-Q0141

**fr-Q0142 · Build the sentence**

Arrange: de / Je / bref. / essayer / vais / rester

I'll try to keep this brief.

[[French#^fr-Q0142-answer|Compare the answer]]
^fr-Q0142

**fr-Q0143 · Write a translation**

Write this in French: He smiled and left.

[[French#^fr-Q0143-answer|Compare the answer]]
^fr-Q0143

**fr-Q0144 · Explain the grammar**

【Il】 a souri et est parti.

He smiled and left.

[[French#^fr-Q0144-answer|Compare the answer]]
^fr-Q0144

**fr-Q0145 · Fill the gap**

____ voudrais avoir plus d'argent sur moi.

I wish I had more money with me.

[[French#^fr-Q0145-answer|Compare the answer]]
^fr-Q0145

**fr-Q0146 · Choose the form**

____ voudrais avoir plus d'argent sur moi.

I wish I had more money with me.

Choices: tu / nous / il / Je

[[French#^fr-Q0146-answer|Compare the answer]]
^fr-Q0146

**fr-Q0147 · Edit the changed sentence**

【tu】 ne méritais pas d'aller en prison.

I didn't deserve to go to prison.

[[French#^fr-Q0147-answer|Compare the answer]]
^fr-Q0147

**fr-Q0148 · Build the sentence**

Arrange: méritais / prison. / d'aller / pas / en / ne / Je

I didn't deserve to go to prison.

[[French#^fr-Q0148-answer|Compare the answer]]
^fr-Q0148

**fr-Q0149 · Write a translation**

Write this in French: You can get it at a bookstore.

[[French#^fr-Q0149-answer|Compare the answer]]
^fr-Q0149

**fr-Q0150 · Explain the grammar**

【Vous】 pouvez le trouver chez un libraire.

You can get it at a bookstore.

[[French#^fr-Q0150-answer|Compare the answer]]
^fr-Q0150


### Present être · 50 questions

**fr-Q0151 · Fill the gap**

C'____ chaud boulette.

It's as hot as toast.

[[French#^fr-Q0151-answer|Compare the answer]]
^fr-Q0151

**fr-Q0152 · Choose the form**

C'____ chaud boulette.

It's as hot as toast.

Choices: est / suis / es / sommes

[[French#^fr-Q0152-answer|Compare the answer]]
^fr-Q0152

**fr-Q0153 · Edit the changed sentence**

Mon stylo 【suis】 à court d'encre.

My pen is out of ink.

[[French#^fr-Q0153-answer|Compare the answer]]
^fr-Q0153

**fr-Q0154 · Build the sentence**

Arrange: Mon / est / d'encre. / à / court / stylo

My pen is out of ink.

[[French#^fr-Q0154-answer|Compare the answer]]
^fr-Q0154

**fr-Q0155 · Write a translation**

Write this in French: I came to Tokyo to attend a conference.

[[French#^fr-Q0155-answer|Compare the answer]]
^fr-Q0155

**fr-Q0156 · Explain the grammar**

Je 【suis】 venu à Tokyo pour assister à une conférence.

I came to Tokyo to attend a conference.

[[French#^fr-Q0156-answer|Compare the answer]]
^fr-Q0156

**fr-Q0157 · Fill the gap**

Tom ____ toujours dangereux.

Tom is still dangerous.

[[French#^fr-Q0157-answer|Compare the answer]]
^fr-Q0157

**fr-Q0158 · Choose the form**

Tom ____ toujours dangereux.

Tom is still dangerous.

Choices: es / sommes / est / suis

[[French#^fr-Q0158-answer|Compare the answer]]
^fr-Q0158

**fr-Q0159 · Edit the changed sentence**

Je pense que c'【suis】 trop risqué.

I think it's too risky.

[[French#^fr-Q0159-answer|Compare the answer]]
^fr-Q0159

**fr-Q0160 · Build the sentence**

Arrange: Je / que / risqué. / pense / trop / c'est

I think it's too risky.

[[French#^fr-Q0160-answer|Compare the answer]]
^fr-Q0160

**fr-Q0161 · Write a translation**

Write this in French: Isn't it infuriating?

[[French#^fr-Q0161-answer|Compare the answer]]
^fr-Q0161

**fr-Q0162 · Explain the grammar**

N'【est】-ce pas exaspérant ?

Isn't it infuriating?

[[French#^fr-Q0162-answer|Compare the answer]]
^fr-Q0162

**fr-Q0163 · Fill the gap**

Ils pensent que je ____ millionnaire.

They think I'm a millionaire.

[[French#^fr-Q0163-answer|Compare the answer]]
^fr-Q0163

**fr-Q0164 · Choose the form**

Ils pensent que je ____ millionnaire.

They think I'm a millionaire.

Choices: suis / est / es / sommes

[[French#^fr-Q0164-answer|Compare the answer]]
^fr-Q0164

**fr-Q0165 · Edit the changed sentence**

Il 【suis】 revenu de l'atelier.

He returned from the workshop.

[[French#^fr-Q0165-answer|Compare the answer]]
^fr-Q0165

**fr-Q0166 · Build the sentence**

Arrange: de / est / l'atelier. / revenu / Il

He returned from the workshop.

[[French#^fr-Q0166-answer|Compare the answer]]
^fr-Q0166

**fr-Q0167 · Write a translation**

Write this in French: It's a pity that you can't come.

[[French#^fr-Q0167-answer|Compare the answer]]
^fr-Q0167

**fr-Q0168 · Explain the grammar**

Il 【est】 dommage que vous ne puissiez pas venir.

It's a pity that you can't come.

[[French#^fr-Q0168-answer|Compare the answer]]
^fr-Q0168

**fr-Q0169 · Fill the gap**

C'____ ton choix.

It's your decision.

[[French#^fr-Q0169-answer|Compare the answer]]
^fr-Q0169

**fr-Q0170 · Choose the form**

C'____ ton choix.

It's your decision.

Choices: sommes / suis / est / es

[[French#^fr-Q0170-answer|Compare the answer]]
^fr-Q0170

**fr-Q0171 · Edit the changed sentence**

Je 【es】 très triste d'entendre cela.

I'm very sad to hear that.

[[French#^fr-Q0171-answer|Compare the answer]]
^fr-Q0171

**fr-Q0172 · Build the sentence**

Arrange: suis / triste / Je / très / d'entendre / cela.

I'm very sad to hear that.

[[French#^fr-Q0172-answer|Compare the answer]]
^fr-Q0172

**fr-Q0173 · Write a translation**

Write this in French: You're not angry, are you?

[[French#^fr-Q0173-answer|Compare the answer]]
^fr-Q0173

**fr-Q0174 · Explain the grammar**

Vous n'【êtes】 pas en colère, n'est-ce pas ?

You're not angry, are you?

[[French#^fr-Q0174-answer|Compare the answer]]
^fr-Q0174

**fr-Q0175 · Fill the gap**

Tom a une fille qui ____ musicienne.

Tom has a daughter who is a musician.

[[French#^fr-Q0175-answer|Compare the answer]]
^fr-Q0175

**fr-Q0176 · Choose the form**

Tom a une fille qui ____ musicienne.

Tom has a daughter who is a musician.

Choices: sommes / est / es / suis

[[French#^fr-Q0176-answer|Compare the answer]]
^fr-Q0176

**fr-Q0177 · Edit the changed sentence**

Il 【suis】 mort d'une crise cardiaque sur scène.

He died of a heart attack on the stage.

[[French#^fr-Q0177-answer|Compare the answer]]
^fr-Q0177

**fr-Q0178 · Build the sentence**

Arrange: sur / mort / Il / d'une / scène. / cardiaque / est / crise

He died of a heart attack on the stage.

[[French#^fr-Q0178-answer|Compare the answer]]
^fr-Q0178

**fr-Q0179 · Write a translation**

Write this in French: I'm very proud of Tom.

[[French#^fr-Q0179-answer|Compare the answer]]
^fr-Q0179

**fr-Q0180 · Explain the grammar**

Je 【suis】 très fier de Tom.

I'm very proud of Tom.

[[French#^fr-Q0180-answer|Compare the answer]]
^fr-Q0180

**fr-Q0181 · Fill the gap**

Ils ____ trop gros pour moi.

They're too big for me.

[[French#^fr-Q0181-answer|Compare the answer]]
^fr-Q0181

**fr-Q0182 · Choose the form**

Ils ____ trop gros pour moi.

They're too big for me.

Choices: est / sont / es / suis

[[French#^fr-Q0182-answer|Compare the answer]]
^fr-Q0182

**fr-Q0183 · Edit the changed sentence**

Bonjour, je 【es】 Nancy !

Hello, I am Nancy.

[[French#^fr-Q0183-answer|Compare the answer]]
^fr-Q0183

**fr-Q0184 · Build the sentence**

Arrange: Bonjour, / Nancy / suis / je / !

Hello, I am Nancy.

[[French#^fr-Q0184-answer|Compare the answer]]
^fr-Q0184

**fr-Q0185 · Write a translation**

Write this in French: She had fun with him.

[[French#^fr-Q0185-answer|Compare the answer]]
^fr-Q0185

**fr-Q0186 · Explain the grammar**

Elle s'【est】 amusée avec lui.

She had fun with him.

[[French#^fr-Q0186-answer|Compare the answer]]
^fr-Q0186

**fr-Q0187 · Fill the gap**

Le pauvre ____ aussi une personne dotée de sentiments.

The poor are also people with feelings.

[[French#^fr-Q0187-answer|Compare the answer]]
^fr-Q0187

**fr-Q0188 · Choose the form**

Le pauvre ____ aussi une personne dotée de sentiments.

The poor are also people with feelings.

Choices: est / suis / es / sommes

[[French#^fr-Q0188-answer|Compare the answer]]
^fr-Q0188

**fr-Q0189 · Edit the changed sentence**

Je ne 【es】 pas encore fatigué.

I'm not tired yet.

[[French#^fr-Q0189-answer|Compare the answer]]
^fr-Q0189

**fr-Q0190 · Build the sentence**

Arrange: encore / Je / pas / suis / fatigué. / ne

I'm not tired yet.

[[French#^fr-Q0190-answer|Compare the answer]]
^fr-Q0190

**fr-Q0191 · Write a translation**

Write this in French: She is late.

[[French#^fr-Q0191-answer|Compare the answer]]
^fr-Q0191

**fr-Q0192 · Explain the grammar**

Elle 【est】 en retard.

She is late.

[[French#^fr-Q0192-answer|Compare the answer]]
^fr-Q0192

**fr-Q0193 · Fill the gap**

Qu'____-vous allé faire en Russie ?

What did you go to Russia to do?

[[French#^fr-Q0193-answer|Compare the answer]]
^fr-Q0193

**fr-Q0194 · Choose the form**

Qu'____-vous allé faire en Russie ?

What did you go to Russia to do?

Choices: êtes / est / suis / es

[[French#^fr-Q0194-answer|Compare the answer]]
^fr-Q0194

**fr-Q0195 · Edit the changed sentence**

C'【suis】 une chance unique dans la vie.

This is a once-in-a-lifetime chance.

[[French#^fr-Q0195-answer|Compare the answer]]
^fr-Q0195

**fr-Q0196 · Build the sentence**

Arrange: dans / la / C'est / chance / unique / une / vie.

This is a once-in-a-lifetime chance.

[[French#^fr-Q0196-answer|Compare the answer]]
^fr-Q0196

**fr-Q0197 · Write a translation**

Write this in French: The apple is red.

[[French#^fr-Q0197-answer|Compare the answer]]
^fr-Q0197

**fr-Q0198 · Explain the grammar**

La pomme 【est】 rouge.

The apple is red.

[[French#^fr-Q0198-answer|Compare the answer]]
^fr-Q0198

**fr-Q0199 · Fill the gap**

Enfin la période des examens ____ terminée.

At last, the end-of-term exams are over.

[[French#^fr-Q0199-answer|Compare the answer]]
^fr-Q0199

**fr-Q0200 · Choose the form**

Enfin la période des examens ____ terminée.

At last, the end-of-term exams are over.

Choices: es / est / suis / sommes

[[French#^fr-Q0200-answer|Compare the answer]]
^fr-Q0200


### Present avoir · 50 questions

**fr-Q0201 · Edit the changed sentence**

Qu'y 【ai】-t-il à faire ?

What's there to do?

[[French#^fr-Q0201-answer|Compare the answer]]
^fr-Q0201

**fr-Q0202 · Build the sentence**

Arrange: a-t-il / Qu'y / faire / ? / à

What's there to do?

[[French#^fr-Q0202-answer|Compare the answer]]
^fr-Q0202

**fr-Q0203 · Write a translation**

Write this in French: I need your help.

[[French#^fr-Q0203-answer|Compare the answer]]
^fr-Q0203

**fr-Q0204 · Explain the grammar**

J'【ai】 besoin de ton aide.

I need your help.

[[French#^fr-Q0204-answer|Compare the answer]]
^fr-Q0204

**fr-Q0205 · Fill the gap**

Tom ____ été très respectueux.

Tom has been very respectful.

[[French#^fr-Q0205-answer|Compare the answer]]
^fr-Q0205

**fr-Q0206 · Choose the form**

Tom ____ été très respectueux.

Tom has been very respectful.

Choices: a / avons / as / ai

[[French#^fr-Q0206-answer|Compare the answer]]
^fr-Q0206

**fr-Q0207 · Edit the changed sentence**

L'【ai】-vous mesuré ?

Have you measured it?

[[French#^fr-Q0207-answer|Compare the answer]]
^fr-Q0207

**fr-Q0208 · Build the sentence**

Arrange: ? / L'avez-vous / mesuré

Have you measured it?

[[French#^fr-Q0208-answer|Compare the answer]]
^fr-Q0208

**fr-Q0209 · Write a translation**

Write this in French: I've already talked to this student.

[[French#^fr-Q0209-answer|Compare the answer]]
^fr-Q0209

**fr-Q0210 · Explain the grammar**

J'【ai】 déjà parlé à cet étudiant.

I've already talked to this student.

[[French#^fr-Q0210-answer|Compare the answer]]
^fr-Q0210

**fr-Q0211 · Fill the gap**

Penses-tu que Tom nous ____ vus ?

Do you think Tom saw us?

[[French#^fr-Q0211-answer|Compare the answer]]
^fr-Q0211

**fr-Q0212 · Choose the form**

Penses-tu que Tom nous ____ vus ?

Do you think Tom saw us?

Choices: ai / a / avons / as

[[French#^fr-Q0212-answer|Compare the answer]]
^fr-Q0212

**fr-Q0213 · Edit the changed sentence**

Cet entraîneur lui 【ai】 donné de bons conseils.

That coach gave him good advice.

[[French#^fr-Q0213-answer|Compare the answer]]
^fr-Q0213

**fr-Q0214 · Build the sentence**

Arrange: donné / de / Cet / bons / lui / a / conseils. / entraîneur

That coach gave him good advice.

[[French#^fr-Q0214-answer|Compare the answer]]
^fr-Q0214

**fr-Q0215 · Write a translation**

Write this in French: We didn't kill Tom.

[[French#^fr-Q0215-answer|Compare the answer]]
^fr-Q0215

**fr-Q0216 · Explain the grammar**

Nous n'【avons】 pas tué Tom.

We didn't kill Tom.

[[French#^fr-Q0216-answer|Compare the answer]]
^fr-Q0216

**fr-Q0217 · Fill the gap**

Je n'____ pas vu Tom depuis des mois.

I haven't seen Tom for months.

[[French#^fr-Q0217-answer|Compare the answer]]
^fr-Q0217

**fr-Q0218 · Choose the form**

Je n'____ pas vu Tom depuis des mois.

I haven't seen Tom for months.

Choices: avons / ai / a / as

[[French#^fr-Q0218-answer|Compare the answer]]
^fr-Q0218

**fr-Q0219 · Edit the changed sentence**

Nous 【ai】 été contraints de différer notre départ.

We were compelled to put off our departure.

[[French#^fr-Q0219-answer|Compare the answer]]
^fr-Q0219

**fr-Q0220 · Build the sentence**

Arrange: départ. / contraints / différer / de / notre / été / Nous / avons

We were compelled to put off our departure.

[[French#^fr-Q0220-answer|Compare the answer]]
^fr-Q0220

**fr-Q0221 · Write a translation**

Write this in French: Tom ate my lunch.

[[French#^fr-Q0221-answer|Compare the answer]]
^fr-Q0221

**fr-Q0222 · Explain the grammar**

Tom 【a】 mangé mon déjeuner.

Tom ate my lunch.

[[French#^fr-Q0222-answer|Compare the answer]]
^fr-Q0222

**fr-Q0223 · Fill the gap**

Il n'____ pas la capacité d'être président.

He doesn't have the capacity to be president.

[[French#^fr-Q0223-answer|Compare the answer]]
^fr-Q0223

**fr-Q0224 · Choose the form**

Il n'____ pas la capacité d'être président.

He doesn't have the capacity to be president.

Choices: a / as / avons / ai

[[French#^fr-Q0224-answer|Compare the answer]]
^fr-Q0224

**fr-Q0225 · Edit the changed sentence**

Cela n'【ai】 aucun sens.

This makes no sense.

[[French#^fr-Q0225-answer|Compare the answer]]
^fr-Q0225

**fr-Q0226 · Build the sentence**

Arrange: sens. / aucun / Cela / n'a

This makes no sense.

[[French#^fr-Q0226-answer|Compare the answer]]
^fr-Q0226

**fr-Q0227 · Write a translation**

Write this in French: Tom said that he had a contract.

[[French#^fr-Q0227-answer|Compare the answer]]
^fr-Q0227

**fr-Q0228 · Explain the grammar**

Tom 【a】 dit qu'il avait un contrat.

Tom said that he had a contract.

[[French#^fr-Q0228-answer|Compare the answer]]
^fr-Q0228

**fr-Q0229 · Fill the gap**

J'ignore comment, mais elle l'____ fait.

I don't know how, but she did it.

[[French#^fr-Q0229-answer|Compare the answer]]
^fr-Q0229

**fr-Q0230 · Choose the form**

J'ignore comment, mais elle l'____ fait.

I don't know how, but she did it.

Choices: avons / a / as / ai

[[French#^fr-Q0230-answer|Compare the answer]]
^fr-Q0230

**fr-Q0231 · Edit the changed sentence**

Je roulais à cent-vingt kilomètres à l'heure lorsque la police m'【ai】 arrêtée.

I was driving at 120 kilometers per hour when the police stopped me.

[[French#^fr-Q0231-answer|Compare the answer]]
^fr-Q0231

**fr-Q0232 · Build the sentence**

Arrange: la / cent-vingt / l'heure / Je / m'a / kilomètres / lorsque / roulais / à / police / arrêtée. / à

I was driving at 120 kilometers per hour when the police stopped me.

[[French#^fr-Q0232-answer|Compare the answer]]
^fr-Q0232

**fr-Q0233 · Write a translation**

Write this in French: Thank you for everything you have done for me.

[[French#^fr-Q0233-answer|Compare the answer]]
^fr-Q0233

**fr-Q0234 · Explain the grammar**

Merci pour tout ce que tu 【as】 fait pour moi.

Thank you for everything you have done for me.

[[French#^fr-Q0234-answer|Compare the answer]]
^fr-Q0234

**fr-Q0235 · Fill the gap**

Il y ____ une bonne chance qu'il soit choisi.

There's a good chance that he'll be chosen.

[[French#^fr-Q0235-answer|Compare the answer]]
^fr-Q0235

**fr-Q0236 · Choose the form**

Il y ____ une bonne chance qu'il soit choisi.

There's a good chance that he'll be chosen.

Choices: avons / as / a / ai

[[French#^fr-Q0236-answer|Compare the answer]]
^fr-Q0236

**fr-Q0237 · Edit the changed sentence**

Tom vous 【ai】-t-il dit où il allait ?

Did Tom tell you where he was going?

[[French#^fr-Q0237-answer|Compare the answer]]
^fr-Q0237

**fr-Q0238 · Build the sentence**

Arrange: où / il / allait / ? / dit / a-t-il / Tom / vous

Did Tom tell you where he was going?

[[French#^fr-Q0238-answer|Compare the answer]]
^fr-Q0238

**fr-Q0239 · Write a translation**

Write this in French: I have to go now. I have a plane to catch.

[[French#^fr-Q0239-answer|Compare the answer]]
^fr-Q0239

**fr-Q0240 · Explain the grammar**

Il faut que j'y aille. J'【ai】 un avion à prendre.

I have to go now. I have a plane to catch.

[[French#^fr-Q0240-answer|Compare the answer]]
^fr-Q0240

**fr-Q0241 · Fill the gap**

La famille ____ pris son déjeuner à midi.

The family had its dinner at noon.

[[French#^fr-Q0241-answer|Compare the answer]]
^fr-Q0241

**fr-Q0242 · Choose the form**

La famille ____ pris son déjeuner à midi.

The family had its dinner at noon.

Choices: as / avons / a / ai

[[French#^fr-Q0242-answer|Compare the answer]]
^fr-Q0242

**fr-Q0243 · Edit the changed sentence**

Yutaka 【ai】 deux frères plus âgés.

Yutaka has two older brothers.

[[French#^fr-Q0243-answer|Compare the answer]]
^fr-Q0243

**fr-Q0244 · Build the sentence**

Arrange: plus / deux / Yutaka / âgés. / a / frères

Yutaka has two older brothers.

[[French#^fr-Q0244-answer|Compare the answer]]
^fr-Q0244

**fr-Q0245 · Write a translation**

Write this in French: Can we afford it now?

[[French#^fr-Q0245-answer|Compare the answer]]
^fr-Q0245

**fr-Q0246 · Explain the grammar**

En 【avons】-nous actuellement les moyens ?

Can we afford it now?

[[French#^fr-Q0246-answer|Compare the answer]]
^fr-Q0246

**fr-Q0247 · Fill the gap**

J'____ lu votre nouveau livre avec un réel plaisir.

I read your new book with real delight.

[[French#^fr-Q0247-answer|Compare the answer]]
^fr-Q0247

**fr-Q0248 · Choose the form**

J'____ lu votre nouveau livre avec un réel plaisir.

I read your new book with real delight.

Choices: a / avons / as / ai

[[French#^fr-Q0248-answer|Compare the answer]]
^fr-Q0248

**fr-Q0249 · Edit the changed sentence**

Mon frère m'【ai】 acheté un petit jouet.

My brother bought me a small toy.

[[French#^fr-Q0249-answer|Compare the answer]]
^fr-Q0249

**fr-Q0250 · Build the sentence**

Arrange: Mon / frère / acheté / m'a / petit / jouet. / un

My brother bought me a small toy.

[[French#^fr-Q0250-answer|Compare the answer]]
^fr-Q0250


### Imperfect perspective · 50 questions

**fr-Q0251 · Write a translation**

Write this in French: It was a pleasant day, but there were few people in the park.

[[French#^fr-Q0251-answer|Compare the answer]]
^fr-Q0251

**fr-Q0252 · Explain the grammar**

C'【était】 une journée agréable, mais il y avait peu de monde dans le parc.

It was a pleasant day, but there were few people in the park.

[[French#^fr-Q0252-answer|Compare the answer]]
^fr-Q0252

**fr-Q0253 · Fill the gap**

Aota n'____ pas digne de ta confiance.

Aota was not worthy of your trust.

[[French#^fr-Q0253-answer|Compare the answer]]
^fr-Q0253

**fr-Q0254 · Choose the form**

Aota n'____ pas digne de ta confiance.

Aota was not worthy of your trust.

Choices: avaient / étaient / avait / était

[[French#^fr-Q0254-answer|Compare the answer]]
^fr-Q0254

**fr-Q0255 · Edit the changed sentence**

Vos questions 【était】 trop directes.

Your questions were too direct.

[[French#^fr-Q0255-answer|Compare the answer]]
^fr-Q0255

**fr-Q0256 · Build the sentence**

Arrange: étaient / directes. / trop / Vos / questions

Your questions were too direct.

[[French#^fr-Q0256-answer|Compare the answer]]
^fr-Q0256

**fr-Q0257 · Write a translation**

Write this in French: It was a complicated question.

[[French#^fr-Q0257-answer|Compare the answer]]
^fr-Q0257

**fr-Q0258 · Explain the grammar**

C'【était】 une question compliquée.

It was a complicated question.

[[French#^fr-Q0258-answer|Compare the answer]]
^fr-Q0258

**fr-Q0259 · Fill the gap**

Tom ____ en avance à son rendez-vous.

Tom was early for his appointment.

[[French#^fr-Q0259-answer|Compare the answer]]
^fr-Q0259

**fr-Q0260 · Choose the form**

Tom ____ en avance à son rendez-vous.

Tom was early for his appointment.

Choices: avaient / étaient / était / avait

[[French#^fr-Q0260-answer|Compare the answer]]
^fr-Q0260

**fr-Q0261 · Edit the changed sentence**

Elle n'【était】 pas l'air heureuse de le voir.

She didn't look happy to see him.

[[French#^fr-Q0261-answer|Compare the answer]]
^fr-Q0261

**fr-Q0262 · Build the sentence**

Arrange: pas / le / Elle / voir. / de / n'avait / heureuse / l'air

She didn't look happy to see him.

[[French#^fr-Q0262-answer|Compare the answer]]
^fr-Q0262

**fr-Q0263 · Write a translation**

Write this in French: All the people felt for the victims deeply.

[[French#^fr-Q0263-answer|Compare the answer]]
^fr-Q0263

**fr-Q0264 · Explain the grammar**

Tout le monde 【avait】 une profonde sympathie pour les victimes.

All the people felt for the victims deeply.

[[French#^fr-Q0264-answer|Compare the answer]]
^fr-Q0264

**fr-Q0265 · Fill the gap**

Il m'a dit que j'étais pâle et m'a demandé quel ____ le problème.

He told me that I looked pale and asked me what the matter was.

[[French#^fr-Q0265-answer|Compare the answer]]
^fr-Q0265

**fr-Q0266 · Choose the form**

Il m'a dit que j'étais pâle et m'a demandé quel ____ le problème.

He told me that I looked pale and asked me what the matter was.

Choices: avait / étaient / était / avaient

[[French#^fr-Q0266-answer|Compare the answer]]
^fr-Q0266

**fr-Q0267 · Edit the changed sentence**

Pourquoi 【étaient】-elle à Paris ?

Why was she in Paris?

[[French#^fr-Q0267-answer|Compare the answer]]
^fr-Q0267

**fr-Q0268 · Build the sentence**

Arrange: ? / Paris / était-elle / à / Pourquoi

Why was she in Paris?

[[French#^fr-Q0268-answer|Compare the answer]]
^fr-Q0268

**fr-Q0269 · Write a translation**

Write this in French: They were free at that moment.

[[French#^fr-Q0269-answer|Compare the answer]]
^fr-Q0269

**fr-Q0270 · Explain the grammar**

Ils 【étaient】 libres à ce moment.

They were free at that moment.

[[French#^fr-Q0270-answer|Compare the answer]]
^fr-Q0270

**fr-Q0271 · Fill the gap**

Parmi les invités à la fête, il y ____ deux étrangères.

Among the guests invited to the party were two foreign ladies.

[[French#^fr-Q0271-answer|Compare the answer]]
^fr-Q0271

**fr-Q0272 · Choose the form**

Parmi les invités à la fête, il y ____ deux étrangères.

Among the guests invited to the party were two foreign ladies.

Choices: avait / était / avaient / étaient

[[French#^fr-Q0272-answer|Compare the answer]]
^fr-Q0272

**fr-Q0273 · Edit the changed sentence**

Convaincre Tom de faire ce qui 【étaient】 juste fut difficile.

Convincing Tom to do the right thing was hard.

[[French#^fr-Q0273-answer|Compare the answer]]
^fr-Q0273

**fr-Q0274 · Build the sentence**

Arrange: était / juste / fut / ce / Convaincre / de / difficile. / qui / Tom / faire

Convincing Tom to do the right thing was hard.

[[French#^fr-Q0274-answer|Compare the answer]]
^fr-Q0274

**fr-Q0275 · Write a translation**

Write this in French: Our plane was flying over the Pacific Ocean.

[[French#^fr-Q0275-answer|Compare the answer]]
^fr-Q0275

**fr-Q0276 · Explain the grammar**

Notre avion 【était】 en train de voler au-dessus de l'océan Pacifique.

Our plane was flying over the Pacific Ocean.

[[French#^fr-Q0276-answer|Compare the answer]]
^fr-Q0276

**fr-Q0277 · Fill the gap**

Il ____ une fois un grand roi qui vivait en Grèce.

Once upon a time, there lived a great king in Greece.

[[French#^fr-Q0277-answer|Compare the answer]]
^fr-Q0277

**fr-Q0278 · Choose the form**

Il ____ une fois un grand roi qui vivait en Grèce.

Once upon a time, there lived a great king in Greece.

Choices: était / avait / avaient / étaient

[[French#^fr-Q0278-answer|Compare the answer]]
^fr-Q0278

**fr-Q0279 · Edit the changed sentence**

Je 【était】 disparaître.

I wanted to disappear.

[[French#^fr-Q0279-answer|Compare the answer]]
^fr-Q0279

**fr-Q0280 · Build the sentence**

Arrange: Je / disparaître. / voulais

I wanted to disappear.

[[French#^fr-Q0280-answer|Compare the answer]]
^fr-Q0280

**fr-Q0281 · Write a translation**

Write this in French: Were your eyelids stuck together when you woke up this morning?

[[French#^fr-Q0281-answer|Compare the answer]]
^fr-Q0281

**fr-Q0282 · Explain the grammar**

Tes paupières 【étaient】-elles collées quand tu t'es réveillée ce matin ?

Were your eyelids stuck together when you woke up this morning?

[[French#^fr-Q0282-answer|Compare the answer]]
^fr-Q0282

**fr-Q0283 · Fill the gap**

Elle ____ l'air ravissante.

She looked ravishing.

[[French#^fr-Q0283-answer|Compare the answer]]
^fr-Q0283

**fr-Q0284 · Choose the form**

Elle ____ l'air ravissante.

She looked ravishing.

Choices: avaient / était / étaient / avait

[[French#^fr-Q0284-answer|Compare the answer]]
^fr-Q0284

**fr-Q0285 · Edit the changed sentence**

J'ai demandé à Tom qui 【étaient】 son professeur de français.

I asked Tom who his French teacher was.

[[French#^fr-Q0285-answer|Compare the answer]]
^fr-Q0285

**fr-Q0286 · Build the sentence**

Arrange: à / qui / de / J'ai / Tom / demandé / son / français. / professeur / était

I asked Tom who his French teacher was.

[[French#^fr-Q0286-answer|Compare the answer]]
^fr-Q0286

**fr-Q0287 · Write a translation**

Write this in French: They had no more electricity.

[[French#^fr-Q0287-answer|Compare the answer]]
^fr-Q0287

**fr-Q0288 · Explain the grammar**

Ils n'【avaient】 plus d'électricité.

They had no more electricity.

[[French#^fr-Q0288-answer|Compare the answer]]
^fr-Q0288

**fr-Q0289 · Fill the gap**

Il ____ satisfait d'apprendre le résultat.

He was satisfied to know the result.

[[French#^fr-Q0289-answer|Compare the answer]]
^fr-Q0289

**fr-Q0290 · Choose the form**

Il ____ satisfait d'apprendre le résultat.

He was satisfied to know the result.

Choices: avait / étaient / était / avaient

[[French#^fr-Q0290-answer|Compare the answer]]
^fr-Q0290

**fr-Q0291 · Edit the changed sentence**

Je ne savais pas si je 【était】 aller à l'université.

I didn't know whether I wanted to go to university.

[[French#^fr-Q0291-answer|Compare the answer]]
^fr-Q0291

**fr-Q0292 · Build the sentence**

Arrange: je / ne / si / savais / aller / à / voulais / pas / l'université. / Je

I didn't know whether I wanted to go to university.

[[French#^fr-Q0292-answer|Compare the answer]]
^fr-Q0292

**fr-Q0293 · Write a translation**

Write this in French: The results were negative.

[[French#^fr-Q0293-answer|Compare the answer]]
^fr-Q0293

**fr-Q0294 · Explain the grammar**

Les résultats 【étaient】 négatifs.

The results were negative.

[[French#^fr-Q0294-answer|Compare the answer]]
^fr-Q0294

**fr-Q0295 · Fill the gap**

Comme je l'essayais, c'____ simple.

As I tried, I found it simple.

[[French#^fr-Q0295-answer|Compare the answer]]
^fr-Q0295

**fr-Q0296 · Choose the form**

Comme je l'essayais, c'____ simple.

As I tried, I found it simple.

Choices: était / avait / avaient / étaient

[[French#^fr-Q0296-answer|Compare the answer]]
^fr-Q0296

**fr-Q0297 · Edit the changed sentence**

Il y 【était】 de la neige sur la route.

There was snow on the road.

[[French#^fr-Q0297-answer|Compare the answer]]
^fr-Q0297

**fr-Q0298 · Build the sentence**

Arrange: route. / la / la / avait / neige / Il / sur / y / de

There was snow on the road.

[[French#^fr-Q0298-answer|Compare the answer]]
^fr-Q0298

**fr-Q0299 · Write a translation**

Write this in French: It was a pretty amazing experience.

[[French#^fr-Q0299-answer|Compare the answer]]
^fr-Q0299

**fr-Q0300 · Explain the grammar**

C'【était】 une expérience assez incroyable.

It was a pretty amazing experience.

[[French#^fr-Q0300-answer|Compare the answer]]
^fr-Q0300


### Past participles · 50 questions

**fr-Q0301 · Fill the gap**

L'état ____ face à une crise financière.

The state faces a financial crisis.

[[French#^fr-Q0301-answer|Compare the answer]]
^fr-Q0301

**fr-Q0302 · Choose the form**

L'état ____ face à une crise financière.

The state faces a financial crisis.

Choices: dit / fait / été / eu

[[French#^fr-Q0302-answer|Compare the answer]]
^fr-Q0302

**fr-Q0303 · Edit the changed sentence**

Je suis en 【été】 plutôt flattée.

I'm actually kind of flattered.

[[French#^fr-Q0303-answer|Compare the answer]]
^fr-Q0303

**fr-Q0304 · Build the sentence**

Arrange: plutôt / flattée. / Je / suis / en / fait

I'm actually kind of flattered.

[[French#^fr-Q0304-answer|Compare the answer]]
^fr-Q0304

**fr-Q0305 · Write a translation**

Write this in French: I've come to ask you a question.

[[French#^fr-Q0305-answer|Compare the answer]]
^fr-Q0305

**fr-Q0306 · Explain the grammar**

Je suis 【venu】 pour vous poser une question.

I've come to ask you a question.

[[French#^fr-Q0306-answer|Compare the answer]]
^fr-Q0306

**fr-Q0307 · Fill the gap**

C'est le plus beau cadeau que j'ai jamais ____.

This is the nicest present I've ever had.

[[French#^fr-Q0307-answer|Compare the answer]]
^fr-Q0307

**fr-Q0308 · Choose the form**

C'est le plus beau cadeau que j'ai jamais ____.

This is the nicest present I've ever had.

Choices: été / fait / eu / dit

[[French#^fr-Q0308-answer|Compare the answer]]
^fr-Q0308

**fr-Q0309 · Edit the changed sentence**

Vous ne m'avez toujours pas 【été】 où vous vivez.

You still haven't told me where you live.

[[French#^fr-Q0309-answer|Compare the answer]]
^fr-Q0309

**fr-Q0310 · Build the sentence**

Arrange: Vous / dit / où / toujours / pas / vous / vivez. / m'avez / ne

You still haven't told me where you live.

[[French#^fr-Q0310-answer|Compare the answer]]
^fr-Q0310

**fr-Q0311 · Write a translation**

Write this in French: I saw the file.

[[French#^fr-Q0311-answer|Compare the answer]]
^fr-Q0311

**fr-Q0312 · Explain the grammar**

J'ai 【vu】 le dossier.

I saw the file.

[[French#^fr-Q0312-answer|Compare the answer]]
^fr-Q0312

**fr-Q0313 · Fill the gap**

Je pense que Tom a ____ qu'il venait de Boston.

I think Tom said he was from Boston.

[[French#^fr-Q0313-answer|Compare the answer]]
^fr-Q0313

**fr-Q0314 · Choose the form**

Je pense que Tom a ____ qu'il venait de Boston.

I think Tom said he was from Boston.

Choices: eu / dit / été / fait

[[French#^fr-Q0314-answer|Compare the answer]]
^fr-Q0314

**fr-Q0315 · Edit the changed sentence**

Nous en avons 【été】 pas plus tard qu'hier.

We talked about it just yesterday.

[[French#^fr-Q0315-answer|Compare the answer]]
^fr-Q0315

**fr-Q0316 · Build the sentence**

Arrange: qu'hier. / pas / tard / plus / en / Nous / avons / parlé

We talked about it just yesterday.

[[French#^fr-Q0316-answer|Compare the answer]]
^fr-Q0316

**fr-Q0317 · Write a translation**

Write this in French: Have you told your parents?

[[French#^fr-Q0317-answer|Compare the answer]]
^fr-Q0317

**fr-Q0318 · Explain the grammar**

L'as-tu 【dit】 à tes parents ?

Have you told your parents?

[[French#^fr-Q0318-answer|Compare the answer]]
^fr-Q0318

**fr-Q0319 · Fill the gap**

Tom ____ deux pouces de plus que Mary.

Tom is two inches taller than Mary.

[[French#^fr-Q0319-answer|Compare the answer]]
^fr-Q0319

**fr-Q0320 · Choose the form**

Tom ____ deux pouces de plus que Mary.

Tom is two inches taller than Mary.

Choices: eu / été / fait / dit

[[French#^fr-Q0320-answer|Compare the answer]]
^fr-Q0320

**fr-Q0321 · Edit the changed sentence**

Je suis 【été】 ici pour apprendre.

I came here to learn.

[[French#^fr-Q0321-answer|Compare the answer]]
^fr-Q0321

**fr-Q0322 · Build the sentence**

Arrange: Je / venue / ici / suis / apprendre. / pour

I came here to learn.

[[French#^fr-Q0322-answer|Compare the answer]]
^fr-Q0322

**fr-Q0323 · Write a translation**

Write this in French: He did not agree.

[[French#^fr-Q0323-answer|Compare the answer]]
^fr-Q0323

**fr-Q0324 · Explain the grammar**

Il n'a pas 【été】 d'accord.

He did not agree.

[[French#^fr-Q0324-answer|Compare the answer]]
^fr-Q0324

**fr-Q0325 · Fill the gap**

J'ai encore ____ ce rêve étrange, la nuit dernière.

I had that weird dream again last night.

[[French#^fr-Q0325-answer|Compare the answer]]
^fr-Q0325

**fr-Q0326 · Choose the form**

J'ai encore ____ ce rêve étrange, la nuit dernière.

I had that weird dream again last night.

Choices: été / dit / eu / fait

[[French#^fr-Q0326-answer|Compare the answer]]
^fr-Q0326

**fr-Q0327 · Edit the changed sentence**

J'ai 【été】 comment Tom a fait.

I saw how Tom did it.

[[French#^fr-Q0327-answer|Compare the answer]]
^fr-Q0327

**fr-Q0328 · Build the sentence**

Arrange: fait. / comment / Tom / vu / J'ai / a

I saw how Tom did it.

[[French#^fr-Q0328-answer|Compare the answer]]
^fr-Q0328

**fr-Q0329 · Write a translation**

Write this in French: That's actually very common.

[[French#^fr-Q0329-answer|Compare the answer]]
^fr-Q0329

**fr-Q0330 · Explain the grammar**

C'est en 【fait】 très courant.

That's actually very common.

[[French#^fr-Q0330-answer|Compare the answer]]
^fr-Q0330

**fr-Q0331 · Fill the gap**

Je n'ai jamais ____ capable de prendre en main des responsabilités.

I've never been able to handle responsibility.

[[French#^fr-Q0331-answer|Compare the answer]]
^fr-Q0331

**fr-Q0332 · Choose the form**

Je n'ai jamais ____ capable de prendre en main des responsabilités.

I've never been able to handle responsibility.

Choices: fait / eu / dit / été

[[French#^fr-Q0332-answer|Compare the answer]]
^fr-Q0332

**fr-Q0333 · Edit the changed sentence**

Il est 【été】 là-bas seul.

He went there by himself.

[[French#^fr-Q0333-answer|Compare the answer]]
^fr-Q0333

**fr-Q0334 · Build the sentence**

Arrange: est / allé / là-bas / Il / seul.

He went there by himself.

[[French#^fr-Q0334-answer|Compare the answer]]
^fr-Q0334

**fr-Q0335 · Write a translation**

Write this in French: Tom does little other than play the guitar.

[[French#^fr-Q0335-answer|Compare the answer]]
^fr-Q0335

**fr-Q0336 · Explain the grammar**

Tom ne 【fait】 pas grand-chose à part jouer de la guitare.

Tom does little other than play the guitar.

[[French#^fr-Q0336-answer|Compare the answer]]
^fr-Q0336

**fr-Q0337 · Fill the gap**

Elle a ____ la gentillesse de m'accompagner à la gare.

She was kind enough to accompany me to the station.

[[French#^fr-Q0337-answer|Compare the answer]]
^fr-Q0337

**fr-Q0338 · Choose the form**

Elle a ____ la gentillesse de m'accompagner à la gare.

She was kind enough to accompany me to the station.

Choices: dit / été / fait / eu

[[French#^fr-Q0338-answer|Compare the answer]]
^fr-Q0338

**fr-Q0339 · Edit the changed sentence**

Qu'est-ce qui te 【été】 tenir ?

What keeps you going?

[[French#^fr-Q0339-answer|Compare the answer]]
^fr-Q0339

**fr-Q0340 · Build the sentence**

Arrange: te / tenir / fait / ? / qui / Qu'est-ce

What keeps you going?

[[French#^fr-Q0340-answer|Compare the answer]]
^fr-Q0340

**fr-Q0341 · Write a translation**

Write this in French: You told me that you were here yesterday.

[[French#^fr-Q0341-answer|Compare the answer]]
^fr-Q0341

**fr-Q0342 · Explain the grammar**

Vous m'avez 【dit】 que vous étiez là hier.

You told me that you were here yesterday.

[[French#^fr-Q0342-answer|Compare the answer]]
^fr-Q0342

**fr-Q0343 · Fill the gap**

Je lui ai ____ de ne pas être en retard.

I told her not to be late.

[[French#^fr-Q0343-answer|Compare the answer]]
^fr-Q0343

**fr-Q0344 · Choose the form**

Je lui ai ____ de ne pas être en retard.

I told her not to be late.

Choices: eu / dit / été / fait

[[French#^fr-Q0344-answer|Compare the answer]]
^fr-Q0344

**fr-Q0345 · Edit the changed sentence**

Il n'a pas 【été】 d'autre choix.

He didn't have another choice.

[[French#^fr-Q0345-answer|Compare the answer]]
^fr-Q0345

**fr-Q0346 · Build the sentence**

Arrange: n'a / d'autre / pas / eu / choix. / Il

He didn't have another choice.

[[French#^fr-Q0346-answer|Compare the answer]]
^fr-Q0346

**fr-Q0347 · Write a translation**

Write this in French: I do what I'm told.

[[French#^fr-Q0347-answer|Compare the answer]]
^fr-Q0347

**fr-Q0348 · Explain the grammar**

Je fais ce qu'on me 【dit】.

I do what I'm told.

[[French#^fr-Q0348-answer|Compare the answer]]
^fr-Q0348

**fr-Q0349 · Fill the gap**

Tu as ____ que tu étais heureuse.

You said you were happy.

[[French#^fr-Q0349-answer|Compare the answer]]
^fr-Q0349

**fr-Q0350 · Choose the form**

Tu as ____ que tu étais heureuse.

You said you were happy.

Choices: eu / fait / été / dit

[[French#^fr-Q0350-answer|Compare the answer]]
^fr-Q0350


### Future forms · 50 questions

**fr-Q0351 · Edit the changed sentence**

Peut-être que ce 【aura】 suffisant.

Maybe that'll be enough.

[[French#^fr-Q0351-answer|Compare the answer]]
^fr-Q0351

**fr-Q0352 · Build the sentence**

Arrange: ce / sera / que / suffisant. / Peut-être

Maybe that'll be enough.

[[French#^fr-Q0352-answer|Compare the answer]]
^fr-Q0352

**fr-Q0353 · Write a translation**

Write this in French: A glass of water will make you feel better.

[[French#^fr-Q0353-answer|Compare the answer]]
^fr-Q0353

**fr-Q0354 · Explain the grammar**

Un verre d'eau vous 【fera】 du bien.

A glass of water will make you feel better.

[[French#^fr-Q0354-answer|Compare the answer]]
^fr-Q0354

**fr-Q0355 · Fill the gap**

J'ignore quand il ____ là.

I don't know when he'll be here.

[[French#^fr-Q0355-answer|Compare the answer]]
^fr-Q0355

**fr-Q0356 · Choose the form**

J'ignore quand il ____ là.

I don't know when he'll be here.

Choices: sera / fera / ira / aura

[[French#^fr-Q0356-answer|Compare the answer]]
^fr-Q0356

**fr-Q0357 · Edit the changed sentence**

Personne ne 【sera】.

No one will come.

[[French#^fr-Q0357-answer|Compare the answer]]
^fr-Q0357

**fr-Q0358 · Build the sentence**

Arrange: ne / Personne / viendra.

No one will come.

[[French#^fr-Q0358-answer|Compare the answer]]
^fr-Q0358

**fr-Q0359 · Write a translation**

Write this in French: He is a man of his word, so if he said he'd help, he will.

[[French#^fr-Q0359-answer|Compare the answer]]
^fr-Q0359

**fr-Q0360 · Explain the grammar**

C'est un homme de parole, donc s'il a dit qu'il aiderait, il le 【fera】.

He is a man of his word, so if he said he'd help, he will.

[[French#^fr-Q0360-answer|Compare the answer]]
^fr-Q0360

**fr-Q0361 · Fill the gap**

On ne te ____ pas de mal.

You won't be harmed.

[[French#^fr-Q0361-answer|Compare the answer]]
^fr-Q0361

**fr-Q0362 · Choose the form**

On ne te ____ pas de mal.

You won't be harmed.

Choices: ira / aura / fera / sera

[[French#^fr-Q0362-answer|Compare the answer]]
^fr-Q0362

**fr-Q0363 · Edit the changed sentence**

Demain, il 【sera】 froid.

Tomorrow, it will be cold.

[[French#^fr-Q0363-answer|Compare the answer]]
^fr-Q0363

**fr-Q0364 · Build the sentence**

Arrange: il / Demain, / fera / froid.

Tomorrow, it will be cold.

[[French#^fr-Q0364-answer|Compare the answer]]
^fr-Q0364

**fr-Q0365 · Write a translation**

Write this in French: I'll go shopping.

[[French#^fr-Q0365-answer|Compare the answer]]
^fr-Q0365

**fr-Q0366 · Explain the grammar**

J'【irai】 faire des courses.

I'll go shopping.

[[French#^fr-Q0366-answer|Compare the answer]]
^fr-Q0366

**fr-Q0367 · Fill the gap**

Tom ____ ici ce soir.

Tom will be here tonight.

[[French#^fr-Q0367-answer|Compare the answer]]
^fr-Q0367

**fr-Q0368 · Choose the form**

Tom ____ ici ce soir.

Tom will be here tonight.

Choices: aura / fera / ira / sera

[[French#^fr-Q0368-answer|Compare the answer]]
^fr-Q0368

**fr-Q0369 · Edit the changed sentence**

Demain, j'【sera】 besoin de l'aide de tout le monde.

I need everyone's help tomorrow.

[[French#^fr-Q0369-answer|Compare the answer]]
^fr-Q0369

**fr-Q0370 · Build the sentence**

Arrange: l'aide / de / le / tout / j'aurai / besoin / monde. / de / Demain,

I need everyone's help tomorrow.

[[French#^fr-Q0370-answer|Compare the answer]]
^fr-Q0370

**fr-Q0371 · Write a translation**

Write this in French: Do you really think Tom will do that?

[[French#^fr-Q0371-answer|Compare the answer]]
^fr-Q0371

**fr-Q0372 · Explain the grammar**

Pensez-vous vraiment que Tom le 【fera】 ?

Do you really think Tom will do that?

[[French#^fr-Q0372-answer|Compare the answer]]
^fr-Q0372

**fr-Q0373 · Fill the gap**

J'____ dû mettre un manteau.

I should've worn a coat.

[[French#^fr-Q0373-answer|Compare the answer]]
^fr-Q0373

**fr-Q0374 · Choose the form**

J'____ dû mettre un manteau.

I should've worn a coat.

Choices: aurai / sera / fera / aura

[[French#^fr-Q0374-answer|Compare the answer]]
^fr-Q0374

**fr-Q0375 · Edit the changed sentence**

Tom 【aura】 de retour dans une seconde.

Tom will be back in a second.

[[French#^fr-Q0375-answer|Compare the answer]]
^fr-Q0375

**fr-Q0376 · Build the sentence**

Arrange: retour / dans / une / seconde. / Tom / sera / de

Tom will be back in a second.

[[French#^fr-Q0376-answer|Compare the answer]]
^fr-Q0376

**fr-Q0377 · Write a translation**

Write this in French: Sadly many people will believe things told to them via an email which they would find implausible face-to-face.

[[French#^fr-Q0377-answer|Compare the answer]]
^fr-Q0377

**fr-Q0378 · Explain the grammar**

Malheureusement, beaucoup de gens croient des choses qu'on leur 【aura】 dites via un courriel qu'ils ne trouveraient pas plausibles en face à face.

Sadly many people will believe things told to them via an email which they would find implausible face-to-face.

[[French#^fr-Q0378-answer|Compare the answer]]
^fr-Q0378

**fr-Q0379 · Fill the gap**

Quiconque ____, sera bienvenu.

Whoever comes will be welcomed.

[[French#^fr-Q0379-answer|Compare the answer]]
^fr-Q0379

**fr-Q0380 · Choose the form**

Quiconque ____, sera bienvenu.

Whoever comes will be welcomed.

Choices: viendra / sera / aura / fera

[[French#^fr-Q0380-answer|Compare the answer]]
^fr-Q0380

**fr-Q0381 · Edit the changed sentence**

J'espère que je n'【sera】 jamais à refaire ça.

I hope I never have to do that again.

[[French#^fr-Q0381-answer|Compare the answer]]
^fr-Q0381

**fr-Q0382 · Build the sentence**

Arrange: que / à / jamais / je / refaire / J'espère / ça. / n'aurai

I hope I never have to do that again.

[[French#^fr-Q0382-answer|Compare the answer]]
^fr-Q0382

**fr-Q0383 · Write a translation**

Write this in French: I'll trust you.

[[French#^fr-Q0383-answer|Compare the answer]]
^fr-Q0383

**fr-Q0384 · Explain the grammar**

Je vous 【ferai】 confiance.

I'll trust you.

[[French#^fr-Q0384-answer|Compare the answer]]
^fr-Q0384

**fr-Q0385 · Fill the gap**

Je pense qu'on peut dire avec certitude que Tom ne ____ pas là demain.

I think it's safe to assume Tom won't be here tomorrow.

[[French#^fr-Q0385-answer|Compare the answer]]
^fr-Q0385

**fr-Q0386 · Choose the form**

Je pense qu'on peut dire avec certitude que Tom ne ____ pas là demain.

I think it's safe to assume Tom won't be here tomorrow.

Choices: ira / sera / aura / fera

[[French#^fr-Q0386-answer|Compare the answer]]
^fr-Q0386

**fr-Q0387 · Edit the changed sentence**

Mes parents ne 【sera】 pas là.

My parents aren't going to be there.

[[French#^fr-Q0387-answer|Compare the answer]]
^fr-Q0387

**fr-Q0388 · Build the sentence**

Arrange: pas / ne / là. / seront / parents / Mes

My parents aren't going to be there.

[[French#^fr-Q0388-answer|Compare the answer]]
^fr-Q0388

**fr-Q0389 · Write a translation**

Write this in French: I'll go if you insist.

[[French#^fr-Q0389-answer|Compare the answer]]
^fr-Q0389

**fr-Q0390 · Explain the grammar**

J'【irai】, si vous insistez.

I'll go if you insist.

[[French#^fr-Q0390-answer|Compare the answer]]
^fr-Q0390

**fr-Q0391 · Fill the gap**

Je ____ n'importe quoi pour le bien de l'humanité.

I'll do anything in the interests of humanity.

[[French#^fr-Q0391-answer|Compare the answer]]
^fr-Q0391

**fr-Q0392 · Choose the form**

Je ____ n'importe quoi pour le bien de l'humanité.

I'll do anything in the interests of humanity.

Choices: sera / aura / ferai / fera

[[French#^fr-Q0392-answer|Compare the answer]]
^fr-Q0392

**fr-Q0393 · Edit the changed sentence**

Soit il 【sera】, soit il m'appellera.

He will either come or call me.

[[French#^fr-Q0393-answer|Compare the answer]]
^fr-Q0393

**fr-Q0394 · Build the sentence**

Arrange: il / m'appellera. / il / Soit / viendra, / soit

He will either come or call me.

[[French#^fr-Q0394-answer|Compare the answer]]
^fr-Q0394

**fr-Q0395 · Write a translation**

Write this in French: Do you think it'll make a difference?

[[French#^fr-Q0395-answer|Compare the answer]]
^fr-Q0395

**fr-Q0396 · Explain the grammar**

Est-ce que tu penses que ça 【fera】 une différence ?

Do you think it'll make a difference?

[[French#^fr-Q0396-answer|Compare the answer]]
^fr-Q0396

**fr-Q0397 · Fill the gap**

Dis-moi quoi faire et je le ____.

Tell me what to do and I will do it.

[[French#^fr-Q0397-answer|Compare the answer]]
^fr-Q0397

**fr-Q0398 · Choose the form**

Dis-moi quoi faire et je le ____.

Tell me what to do and I will do it.

Choices: fera / sera / aura / ferai

[[French#^fr-Q0398-answer|Compare the answer]]
^fr-Q0398

**fr-Q0399 · Edit the changed sentence**

Y 【sera】-t-il des effets permanents ?

Will there be permanent effects?

[[French#^fr-Q0399-answer|Compare the answer]]
^fr-Q0399

**fr-Q0400 · Build the sentence**

Arrange: permanents / Y / effets / des / aura-t-il / ?

Will there be permanent effects?

[[French#^fr-Q0400-answer|Compare the answer]]
^fr-Q0400


### Conditional forms · 50 questions

**fr-Q0401 · Write a translation**

Write this in French: Wouldn't you like to get some fresh air?

[[French#^fr-Q0401-answer|Compare the answer]]
^fr-Q0401

**fr-Q0402 · Explain the grammar**

Tu ne 【voudrais】 prendre un peu l'air ?

Wouldn't you like to get some fresh air?

[[French#^fr-Q0402-answer|Compare the answer]]
^fr-Q0402

**fr-Q0403 · Fill the gap**

Je ne ____ pas me passer de ce dictionnaire, ne serait-ce que pour une journée.

I cannot do without this dictionary even a day.

[[French#^fr-Q0403-answer|Compare the answer]]
^fr-Q0403

**fr-Q0404 · Choose the form**

Je ne ____ pas me passer de ce dictionnaire, ne serait-ce que pour une journée.

I cannot do without this dictionary even a day.

Choices: voudrais / serait / aurait / pourrais

[[French#^fr-Q0404-answer|Compare the answer]]
^fr-Q0404

**fr-Q0405 · Edit the changed sentence**

Tu 【serait】 dû lui dire la vérité.

You should have told him the truth.

[[French#^fr-Q0405-answer|Compare the answer]]
^fr-Q0405

**fr-Q0406 · Build the sentence**

Arrange: dû / Tu / lui / dire / aurais / vérité. / la

You should have told him the truth.

[[French#^fr-Q0406-answer|Compare the answer]]
^fr-Q0406

**fr-Q0407 · Write a translation**

Write this in French: I wish you'd stop saying that.

[[French#^fr-Q0407-answer|Compare the answer]]
^fr-Q0407

**fr-Q0408 · Explain the grammar**

Je 【voudrais】 que vous arrêtiez de dire cela.

I wish you'd stop saying that.

[[French#^fr-Q0408-answer|Compare the answer]]
^fr-Q0408

**fr-Q0409 · Fill the gap**

Loin de moi l'idée que George ____ me tromper.

Never did I dream that George would cheat me.

[[French#^fr-Q0409-answer|Compare the answer]]
^fr-Q0409

**fr-Q0410 · Choose the form**

Loin de moi l'idée que George ____ me tromper.

Never did I dream that George would cheat me.

Choices: serait / aurait / pourrait / voudrais

[[French#^fr-Q0410-answer|Compare the answer]]
^fr-Q0410

**fr-Q0411 · Edit the changed sentence**

En 【serait】-tu un ?

Would you like one?

[[French#^fr-Q0411-answer|Compare the answer]]
^fr-Q0411

**fr-Q0412 · Build the sentence**

Arrange: En / ? / voudrais-tu / un

Would you like one?

[[French#^fr-Q0412-answer|Compare the answer]]
^fr-Q0412

**fr-Q0413 · Write a translation**

Write this in French: We should always obey laws.

[[French#^fr-Q0413-answer|Compare the answer]]
^fr-Q0413

**fr-Q0414 · Explain the grammar**

On 【devrait】 toujours se soumettre à la loi.

We should always obey laws.

[[French#^fr-Q0414-answer|Compare the answer]]
^fr-Q0414

**fr-Q0415 · Fill the gap**

Elle ne ____ pas le convaincre de solliciter un prêt.

She couldn't convince him to ask for a loan.

[[French#^fr-Q0415-answer|Compare the answer]]
^fr-Q0415

**fr-Q0416 · Choose the form**

Elle ne ____ pas le convaincre de solliciter un prêt.

She couldn't convince him to ask for a loan.

Choices: voudrais / pourrait / aurait / serait

[[French#^fr-Q0416-answer|Compare the answer]]
^fr-Q0416

**fr-Q0417 · Edit the changed sentence**

【serait】-tu me dire à nouveau où tu as mis la clé ?

Could you please tell me again where you put the key?

[[French#^fr-Q0417-answer|Compare the answer]]
^fr-Q0417

**fr-Q0418 · Build the sentence**

Arrange: nouveau / as / où / mis / la / Pourrais-tu / clé / ? / tu / dire / à / me

Could you please tell me again where you put the key?

[[French#^fr-Q0418-answer|Compare the answer]]
^fr-Q0418

**fr-Q0419 · Write a translation**

Write this in French: That should be ready on Tuesday.

[[French#^fr-Q0419-answer|Compare the answer]]
^fr-Q0419

**fr-Q0420 · Explain the grammar**

Ça 【devrait】 être prêt mardi.

That should be ready on Tuesday.

[[French#^fr-Q0420-answer|Compare the answer]]
^fr-Q0420

**fr-Q0421 · Fill the gap**

C'est la meilleure chose qui ____ m'arriver.

That's the best thing that could happen to me.

[[French#^fr-Q0421-answer|Compare the answer]]
^fr-Q0421

**fr-Q0422 · Choose the form**

C'est la meilleure chose qui ____ m'arriver.

That's the best thing that could happen to me.

Choices: aurait / serait / pourrait / voudrais

[[French#^fr-Q0422-answer|Compare the answer]]
^fr-Q0422

**fr-Q0423 · Edit the changed sentence**

Elles m'ont dit qu'elles 【serait】 à la maison lundi.

They told me they'd be home on Monday.

[[French#^fr-Q0423-answer|Compare the answer]]
^fr-Q0423

**fr-Q0424 · Build the sentence**

Arrange: m'ont / maison / dit / la / lundi. / seraient / qu'elles / Elles / à

They told me they'd be home on Monday.

[[French#^fr-Q0424-answer|Compare the answer]]
^fr-Q0424

**fr-Q0425 · Write a translation**

Write this in French: I knew I shouldn't have worn this color.

[[French#^fr-Q0425-answer|Compare the answer]]
^fr-Q0425

**fr-Q0426 · Explain the grammar**

Je savais que je n'【aurais】 pas dû porter cette couleur.

I knew I shouldn't have worn this color.

[[French#^fr-Q0426-answer|Compare the answer]]
^fr-Q0426

**fr-Q0427 · Fill the gap**

Elle ____ dû être très fière de vous.

She would have been very proud of you.

[[French#^fr-Q0427-answer|Compare the answer]]
^fr-Q0427

**fr-Q0428 · Choose the form**

Elle ____ dû être très fière de vous.

She would have been very proud of you.

Choices: voudrais / aurait / pourrait / serait

[[French#^fr-Q0428-answer|Compare the answer]]
^fr-Q0428

**fr-Q0429 · Edit the changed sentence**

Ça 【serait】 avoir des conséquences involontaires.

This could have unintended consequences.

[[French#^fr-Q0429-answer|Compare the answer]]
^fr-Q0429

**fr-Q0430 · Build the sentence**

Arrange: conséquences / involontaires. / Ça / des / avoir / pourrait

This could have unintended consequences.

[[French#^fr-Q0430-answer|Compare the answer]]
^fr-Q0430

**fr-Q0431 · Write a translation**

Write this in French: He wished he had more time.

[[French#^fr-Q0431-answer|Compare the answer]]
^fr-Q0431

**fr-Q0432 · Explain the grammar**

Il 【aurait】 aimé disposer de davantage de temps.

He wished he had more time.

[[French#^fr-Q0432-answer|Compare the answer]]
^fr-Q0432

**fr-Q0433 · Fill the gap**

Tatoeba : on a plus de phrases que ta mère ____ en dire dans toute sa vie.

Tatoeba: We've got more sentences than your mom could ever say in her lifetime.

[[French#^fr-Q0433-answer|Compare the answer]]
^fr-Q0433

**fr-Q0434 · Choose the form**

Tatoeba : on a plus de phrases que ta mère ____ en dire dans toute sa vie.

Tatoeba: We've got more sentences than your mom could ever say in her lifetime.

Choices: voudrais / pourrait / aurait / serait

[[French#^fr-Q0434-answer|Compare the answer]]
^fr-Q0434

**fr-Q0435 · Edit the changed sentence**

On 【serait】 pu le faire sans votre aide.

We could've done this without your help.

[[French#^fr-Q0435-answer|Compare the answer]]
^fr-Q0435

**fr-Q0436 · Build the sentence**

Arrange: faire / On / pu / aide. / aurait / le / sans / votre

We could've done this without your help.

[[French#^fr-Q0436-answer|Compare the answer]]
^fr-Q0436

**fr-Q0437 · Write a translation**

Write this in French: Could you please tell me how tall you are and how much you weigh?

[[French#^fr-Q0437-answer|Compare the answer]]
^fr-Q0437

**fr-Q0438 · Explain the grammar**

【Pourrais】-tu m'indiquer quelle taille tu fais et combien tu pèses, je te prie ?

Could you please tell me how tall you are and how much you weigh?

[[French#^fr-Q0438-answer|Compare the answer]]
^fr-Q0438

**fr-Q0439 · Fill the gap**

Je savais que cela ____ facile.

I knew it would be easy.

[[French#^fr-Q0439-answer|Compare the answer]]
^fr-Q0439

**fr-Q0440 · Choose the form**

Je savais que cela ____ facile.

I knew it would be easy.

Choices: aurait / serait / pourrait / voudrais

[[French#^fr-Q0440-answer|Compare the answer]]
^fr-Q0440

**fr-Q0441 · Edit the changed sentence**

Peux-tu te figurer comment 【aurait】 la vie sans télévision ?

Can you imagine what life would be like without television?

[[French#^fr-Q0441-answer|Compare the answer]]
^fr-Q0441

**fr-Q0442 · Build the sentence**

Arrange: figurer / serait / télévision / Peux-tu / la / comment / te / ? / vie / sans

Can you imagine what life would be like without television?

[[French#^fr-Q0442-answer|Compare the answer]]
^fr-Q0442

**fr-Q0443 · Write a translation**

Write this in French: I never thought it would be so exciting.

[[French#^fr-Q0443-answer|Compare the answer]]
^fr-Q0443

**fr-Q0444 · Explain the grammar**

Je n'ai jamais pensé que ça 【serait】 aussi passionnant.

I never thought it would be so exciting.

[[French#^fr-Q0444-answer|Compare the answer]]
^fr-Q0444

**fr-Q0445 · Fill the gap**

Ce ____ cool.

That would be cool.

[[French#^fr-Q0445-answer|Compare the answer]]
^fr-Q0445

**fr-Q0446 · Choose the form**

Ce ____ cool.

That would be cool.

Choices: voudrais / aurait / pourrait / serait

[[French#^fr-Q0446-answer|Compare the answer]]
^fr-Q0446

**fr-Q0447 · Edit the changed sentence**

Ce 【serait】 être notre seul espoir.

It may be our only hope.

[[French#^fr-Q0447-answer|Compare the answer]]
^fr-Q0447

**fr-Q0448 · Build the sentence**

Arrange: Ce / notre / pourrait / espoir. / seul / être

It may be our only hope.

[[French#^fr-Q0448-answer|Compare the answer]]
^fr-Q0448

**fr-Q0449 · Write a translation**

Write this in French: I couldn't lie to you.

[[French#^fr-Q0449-answer|Compare the answer]]
^fr-Q0449

**fr-Q0450 · Explain the grammar**

Je ne 【pourrais】 pas vous mentir.

I couldn't lie to you.

[[French#^fr-Q0450-answer|Compare the answer]]
^fr-Q0450


### Subjunctive contexts · 50 questions

**fr-Q0451 · Fill the gap**

Ne te rappelles-tu pas quoi que ce ____ ?

Don't you remember anything?

[[French#^fr-Q0451-answer|Compare the answer]]
^fr-Q0451

**fr-Q0452 · Choose the form**

Ne te rappelles-tu pas quoi que ce ____ ?

Don't you remember anything?

Choices: vienne / puisse / soit / fasse

[[French#^fr-Q0452-answer|Compare the answer]]
^fr-Q0452

**fr-Q0453 · Edit the changed sentence**

Il est plus riche que qui que ce 【fasse】 d'autre en ville.

He is richer than anybody else in town.

[[French#^fr-Q0453-answer|Compare the answer]]
^fr-Q0453

**fr-Q0454 · Build the sentence**

Arrange: d'autre / ville. / plus / ce / en / soit / Il / riche / que / est / que / qui

He is richer than anybody else in town.

[[French#^fr-Q0454-answer|Compare the answer]]
^fr-Q0454

**fr-Q0455 · Write a translation**

Write this in French: May God have mercy on him.

[[French#^fr-Q0455-answer|Compare the answer]]
^fr-Q0455

**fr-Q0456 · Explain the grammar**

Que Dieu l'【ait】 en sa sainte miséricorde.

May God have mercy on him.

[[French#^fr-Q0456-answer|Compare the answer]]
^fr-Q0456

**fr-Q0457 · Fill the gap**

Ça ne fait aucune différence, qu'il ____ ou pas.

It makes no difference whether he comes or not.

[[French#^fr-Q0457-answer|Compare the answer]]
^fr-Q0457

**fr-Q0458 · Choose the form**

Ça ne fait aucune différence, qu'il ____ ou pas.

It makes no difference whether he comes or not.

Choices: puisse / vienne / fasse / soit

[[French#^fr-Q0458-answer|Compare the answer]]
^fr-Q0458

**fr-Q0459 · Edit the changed sentence**

J'attends qu'il 【soit】.

I expect him to come.

[[French#^fr-Q0459-answer|Compare the answer]]
^fr-Q0459

**fr-Q0460 · Build the sentence**

Arrange: qu'il / vienne. / J'attends

I expect him to come.

[[French#^fr-Q0460-answer|Compare the answer]]
^fr-Q0460

**fr-Q0461 · Write a translation**

Write this in French: Let's hope there are no more acts of vandalism.

[[French#^fr-Q0461-answer|Compare the answer]]
^fr-Q0461

**fr-Q0462 · Explain the grammar**

Espérons qu'il n'y 【ait】 plus d'actes de vandalisme.

Let's hope there are no more acts of vandalism.

[[French#^fr-Q0462-answer|Compare the answer]]
^fr-Q0462

**fr-Q0463 · Fill the gap**

Quoi qu'il en ____, je vous appellerai demain.

In any case, I'll call you tomorrow.

[[French#^fr-Q0463-answer|Compare the answer]]
^fr-Q0463

**fr-Q0464 · Choose the form**

Quoi qu'il en ____, je vous appellerai demain.

In any case, I'll call you tomorrow.

Choices: puisse / fasse / vienne / soit

[[French#^fr-Q0464-answer|Compare the answer]]
^fr-Q0464

**fr-Q0465 · Edit the changed sentence**

J'ai assisté à la réunion bien que mon père m'【soit】 dit de ne pas le faire.

I attended the meeting though my father told me not to.

[[French#^fr-Q0465-answer|Compare the answer]]
^fr-Q0465

**fr-Q0466 · Build the sentence**

Arrange: dit / assisté / la / faire. / de / J'ai / le / père / mon / à / réunion / que / ne / m'ait / bien / pas

I attended the meeting though my father told me not to.

[[French#^fr-Q0466-answer|Compare the answer]]
^fr-Q0466

**fr-Q0467 · Write a translation**

Write this in French: This may hurt a bit.

[[French#^fr-Q0467-answer|Compare the answer]]
^fr-Q0467

**fr-Q0468 · Explain the grammar**

Il se peut que ça 【fasse】 un peu mal.

This may hurt a bit.

[[French#^fr-Q0468-answer|Compare the answer]]
^fr-Q0468

**fr-Q0469 · Fill the gap**

Veux-tu réellement que cette information ____ rendue publique ?

Do you really want this information to be made public?

[[French#^fr-Q0469-answer|Compare the answer]]
^fr-Q0469

**fr-Q0470 · Choose the form**

Veux-tu réellement que cette information ____ rendue publique ?

Do you really want this information to be made public?

Choices: vienne / soit / fasse / puisse

[[French#^fr-Q0470-answer|Compare the answer]]
^fr-Q0470

**fr-Q0471 · Edit the changed sentence**

Je veux que mon argent me 【fasse】 restitué sur-le-champ.

I want my money returned immediately.

[[French#^fr-Q0471-answer|Compare the answer]]
^fr-Q0471

**fr-Q0472 · Build the sentence**

Arrange: que / Je / argent / soit / restitué / me / mon / sur-le-champ. / veux

I want my money returned immediately.

[[French#^fr-Q0472-answer|Compare the answer]]
^fr-Q0472

**fr-Q0473 · Write a translation**

Write this in French: Do you want me to make coffee?

[[French#^fr-Q0473-answer|Compare the answer]]
^fr-Q0473

**fr-Q0474 · Explain the grammar**

Veux-tu que je 【fasse】 du café ?

Do you want me to make coffee?

[[French#^fr-Q0474-answer|Compare the answer]]
^fr-Q0474

**fr-Q0475 · Fill the gap**

Aimes-tu qu'on te ____ attendre ?

Do you like to be kept waiting?

[[French#^fr-Q0475-answer|Compare the answer]]
^fr-Q0475

**fr-Q0476 · Choose the form**

Aimes-tu qu'on te ____ attendre ?

Do you like to be kept waiting?

Choices: soit / puisse / fasse / vienne

[[French#^fr-Q0476-answer|Compare the answer]]
^fr-Q0476

**fr-Q0477 · Edit the changed sentence**

Je ne me rappelle pas que quoi que ce 【fasse】 fut arrivé.

I don't remember anything happening.

[[French#^fr-Q0477-answer|Compare the answer]]
^fr-Q0477

**fr-Q0478 · Build the sentence**

Arrange: soit / que / que / fut / ce / quoi / me / rappelle / pas / ne / arrivé. / Je

I don't remember anything happening.

[[French#^fr-Q0478-answer|Compare the answer]]
^fr-Q0478

**fr-Q0479 · Write a translation**

Write this in French: I can't believe that this is real.

[[French#^fr-Q0479-answer|Compare the answer]]
^fr-Q0479

**fr-Q0480 · Explain the grammar**

Je ne parviens pas à croire que ce 【soit】 réel.

I can't believe that this is real.

[[French#^fr-Q0480-answer|Compare the answer]]
^fr-Q0480

**fr-Q0481 · Fill the gap**

Je ne peux pas croire qu'elle ____ plus âgée que ma mère.

I can't believe that she is older than my mother.

[[French#^fr-Q0481-answer|Compare the answer]]
^fr-Q0481

**fr-Q0482 · Choose the form**

Je ne peux pas croire qu'elle ____ plus âgée que ma mère.

I can't believe that she is older than my mother.

Choices: puisse / fasse / vienne / soit

[[French#^fr-Q0482-answer|Compare the answer]]
^fr-Q0482

**fr-Q0483 · Edit the changed sentence**

Les lecteurs ne peuvent pas êtres sûrs que les nouvelles 【soit】 vraies ou non.

The readers cannot ascertain whether the news is true or not.

[[French#^fr-Q0483-answer|Compare the answer]]
^fr-Q0483

**fr-Q0484 · Build the sentence**

Arrange: Les / peuvent / sûrs / vraies / ne / pas / nouvelles / les / ou / non. / soient / lecteurs / êtres / que

The readers cannot ascertain whether the news is true or not.

[[French#^fr-Q0484-answer|Compare the answer]]
^fr-Q0484

**fr-Q0485 · Write a translation**

Write this in French: What would you have me do?

[[French#^fr-Q0485-answer|Compare the answer]]
^fr-Q0485

**fr-Q0486 · Explain the grammar**

Qu'est-ce que tu voulais que je 【fasse】 ?

What would you have me do?

[[French#^fr-Q0486-answer|Compare the answer]]
^fr-Q0486

**fr-Q0487 · Fill the gap**

Je ne pense pas que je ____ jamais faire cela.

I don't think I could ever do that.

[[French#^fr-Q0487-answer|Compare the answer]]
^fr-Q0487

**fr-Q0488 · Choose the form**

Je ne pense pas que je ____ jamais faire cela.

I don't think I could ever do that.

Choices: vienne / puisse / soit / fasse

[[French#^fr-Q0488-answer|Compare the answer]]
^fr-Q0488

**fr-Q0489 · Edit the changed sentence**

Ça fait un moment qu'il n'a pas publié quoi que ce 【fasse】 sur son site web.

It's been quite a while since the last time he posted anything on his website.

[[French#^fr-Q0489-answer|Compare the answer]]
^fr-Q0489

**fr-Q0490 · Build the sentence**

Arrange: Ça / web. / ce / son / fait / publié / pas / site / un / sur / qu'il / quoi / n'a / soit / que / moment

It's been quite a while since the last time he posted anything on his website.

[[French#^fr-Q0490-answer|Compare the answer]]
^fr-Q0490

**fr-Q0491 · Write a translation**

Write this in French: Are you hurt anywhere?

[[French#^fr-Q0491-answer|Compare the answer]]
^fr-Q0491

**fr-Q0492 · Explain the grammar**

Es-tu blessée où que ce 【soit】 ?

Are you hurt anywhere?

[[French#^fr-Q0492-answer|Compare the answer]]
^fr-Q0492

**fr-Q0493 · Fill the gap**

En admettant qu'il en ____ ainsi, que s'ensuit-il ?

Granting that it is so, what follows?

[[French#^fr-Q0493-answer|Compare the answer]]
^fr-Q0493

**fr-Q0494 · Choose the form**

En admettant qu'il en ____ ainsi, que s'ensuit-il ?

Granting that it is so, what follows?

Choices: vienne / fasse / puisse / soit

[[French#^fr-Q0494-answer|Compare the answer]]
^fr-Q0494

**fr-Q0495 · Edit the changed sentence**

J'espère que cela 【fasse】 résolu rapidement.

I hope this is resolved quickly.

[[French#^fr-Q0495-answer|Compare the answer]]
^fr-Q0495

**fr-Q0496 · Build the sentence**

Arrange: résolu / que / J'espère / rapidement. / soit / cela

I hope this is resolved quickly.

[[French#^fr-Q0496-answer|Compare the answer]]
^fr-Q0496

**fr-Q0497 · Write a translation**

Write this in French: I want him to be informed about that in advance.

[[French#^fr-Q0497-answer|Compare the answer]]
^fr-Q0497

**fr-Q0498 · Explain the grammar**

Je veux qu'il 【soit】 informé de cela en avance.

I want him to be informed about that in advance.

[[French#^fr-Q0498-answer|Compare the answer]]
^fr-Q0498

**fr-Q0499 · Fill the gap**

Je ne suis pas certaine que ceci ____ nécessaire.

I'm not sure this is necessary.

[[French#^fr-Q0499-answer|Compare the answer]]
^fr-Q0499

**fr-Q0500 · Choose the form**

Je ne suis pas certaine que ceci ____ nécessaire.

I'm not sure this is necessary.

Choices: soit / fasse / vienne / puisse

[[French#^fr-Q0500-answer|Compare the answer]]
^fr-Q0500


### Object pronouns · 50 questions

**fr-Q0501 · Edit the changed sentence**

Voulez-【le】 sortir d'ici ou non ?

Do you want to get out of here or not?

[[French#^fr-Q0501-answer|Compare the answer]]
^fr-Q0501

**fr-Q0502 · Build the sentence**

Arrange: ou / sortir / ? / non / d'ici / Voulez-vous

Do you want to get out of here or not?

[[French#^fr-Q0502-answer|Compare the answer]]
^fr-Q0502

**fr-Q0503 · Write a translation**

Write this in French: I'm coming to pick you up.

[[French#^fr-Q0503-answer|Compare the answer]]
^fr-Q0503

**fr-Q0504 · Explain the grammar**

Je viens 【te】 chercher.

I'm coming to pick you up.

[[French#^fr-Q0504-answer|Compare the answer]]
^fr-Q0504

**fr-Q0505 · Fill the gap**

Faisons-____ l'objet d'une accusation ?

Are we being charged with something?

[[French#^fr-Q0505-answer|Compare the answer]]
^fr-Q0505

**fr-Q0506 · Choose the form**

Faisons-____ l'objet d'une accusation ?

Are we being charged with something?

Choices: les / le / la / nous

[[French#^fr-Q0506-answer|Compare the answer]]
^fr-Q0506

**fr-Q0507 · Edit the changed sentence**

【le】 employés de bureau japonais travaillent très dur.

Japanese office workers work very hard.

[[French#^fr-Q0507-answer|Compare the answer]]
^fr-Q0507

**fr-Q0508 · Build the sentence**

Arrange: bureau / japonais / employés / dur. / travaillent / de / très / Les

Japanese office workers work very hard.

[[French#^fr-Q0508-answer|Compare the answer]]
^fr-Q0508

**fr-Q0509 · Write a translation**

Write this in French: He used a big piece of paper to make the bag.

[[French#^fr-Q0509-answer|Compare the answer]]
^fr-Q0509

**fr-Q0510 · Explain the grammar**

Il utilisa un grand morceau de papier pour confectionner 【le】 sac.

He used a big piece of paper to make the bag.

[[French#^fr-Q0510-answer|Compare the answer]]
^fr-Q0510

**fr-Q0511 · Fill the gap**

Elle ____ parla de l'affaire.

She spoke to him about the matter.

[[French#^fr-Q0511-answer|Compare the answer]]
^fr-Q0511

**fr-Q0512 · Choose the form**

Elle ____ parla de l'affaire.

She spoke to him about the matter.

Choices: la / les / le / lui

[[French#^fr-Q0512-answer|Compare the answer]]
^fr-Q0512

**fr-Q0513 · Edit the changed sentence**

【le】 voulons analyser votre urine.

We want to analyze your urine.

[[French#^fr-Q0513-answer|Compare the answer]]
^fr-Q0513

**fr-Q0514 · Build the sentence**

Arrange: votre / analyser / voulons / Nous / urine.

We want to analyze your urine.

[[French#^fr-Q0514-answer|Compare the answer]]
^fr-Q0514

**fr-Q0515 · Write a translation**

Write this in French: Why do you feel that way?

[[French#^fr-Q0515-answer|Compare the answer]]
^fr-Q0515

**fr-Q0516 · Explain the grammar**

Pourquoi 【vous】 sentez-vous ainsi ?

Why do you feel that way?

[[French#^fr-Q0516-answer|Compare the answer]]
^fr-Q0516

**fr-Q0517 · Fill the gap**

Étudiez aussi durement que ____ pouvez.

Study as hard as you can.

[[French#^fr-Q0517-answer|Compare the answer]]
^fr-Q0517

**fr-Q0518 · Choose the form**

Étudiez aussi durement que ____ pouvez.

Study as hard as you can.

Choices: la / le / les / vous

[[French#^fr-Q0518-answer|Compare the answer]]
^fr-Q0518

**fr-Q0519 · Edit the changed sentence**

Ne pose pas de livres sur 【le】 table.

Don't put books on the table.

[[French#^fr-Q0519-answer|Compare the answer]]
^fr-Q0519

**fr-Q0520 · Build the sentence**

Arrange: la / pas / table. / pose / Ne / livres / de / sur

Don't put books on the table.

[[French#^fr-Q0520-answer|Compare the answer]]
^fr-Q0520

**fr-Q0521 · Write a translation**

Write this in French: Do it by yourself.

[[French#^fr-Q0521-answer|Compare the answer]]
^fr-Q0521

**fr-Q0522 · Explain the grammar**

Fais-【le】 toi-même !

Do it by yourself.

[[French#^fr-Q0522-answer|Compare the answer]]
^fr-Q0522

**fr-Q0523 · Fill the gap**

____ pyramides furent bâties en des temps anciens.

The pyramids were built in ancient times.

[[French#^fr-Q0523-answer|Compare the answer]]
^fr-Q0523

**fr-Q0524 · Choose the form**

____ pyramides furent bâties en des temps anciens.

The pyramids were built in ancient times.

Choices: le / la / Les / lui

[[French#^fr-Q0524-answer|Compare the answer]]
^fr-Q0524

**fr-Q0525 · Edit the changed sentence**

Ne t'inquiète pas. 【le】 la trouverons.

Don't worry. We'll find it.

[[French#^fr-Q0525-answer|Compare the answer]]
^fr-Q0525

**fr-Q0526 · Build the sentence**

Arrange: pas. / t'inquiète / la / Ne / trouverons. / Nous

Don't worry. We'll find it.

[[French#^fr-Q0526-answer|Compare the answer]]
^fr-Q0526

**fr-Q0527 · Write a translation**

Write this in French: My parents never let me do anything.

[[French#^fr-Q0527-answer|Compare the answer]]
^fr-Q0527

**fr-Q0528 · Explain the grammar**

Mes parents ne 【me】 laissaient rien faire.

My parents never let me do anything.

[[French#^fr-Q0528-answer|Compare the answer]]
^fr-Q0528

**fr-Q0529 · Fill the gap**

Je trouve très ennuyeux d'apprendre ____ verbes irréguliers.

I find it very boring to learn irregular verbs.

[[French#^fr-Q0529-answer|Compare the answer]]
^fr-Q0529

**fr-Q0530 · Choose the form**

Je trouve très ennuyeux d'apprendre ____ verbes irréguliers.

I find it very boring to learn irregular verbs.

Choices: le / les / lui / la

[[French#^fr-Q0530-answer|Compare the answer]]
^fr-Q0530

**fr-Q0531 · Edit the changed sentence**

Apporte-moi 【la】 journal.

Bring me the newspaper.

[[French#^fr-Q0531-answer|Compare the answer]]
^fr-Q0531

**fr-Q0532 · Build the sentence**

Arrange: journal. / le / Apporte-moi

Bring me the newspaper.

[[French#^fr-Q0532-answer|Compare the answer]]
^fr-Q0532

**fr-Q0533 · Write a translation**

Write this in French: Tom will accompany the children to school.

[[French#^fr-Q0533-answer|Compare the answer]]
^fr-Q0533

**fr-Q0534 · Explain the grammar**

Tom accompagnera 【les】 enfants à l'école.

Tom will accompany the children to school.

[[French#^fr-Q0534-answer|Compare the answer]]
^fr-Q0534

**fr-Q0535 · Fill the gap**

____ minutes de nos discussions sont tenues par le secrétaire.

The records of our discussions are kept by the secretary.

[[French#^fr-Q0535-answer|Compare the answer]]
^fr-Q0535

**fr-Q0536 · Choose the form**

____ minutes de nos discussions sont tenues par le secrétaire.

The records of our discussions are kept by the secretary.

Choices: la / lui / Les / le

[[French#^fr-Q0536-answer|Compare the answer]]
^fr-Q0536

**fr-Q0537 · Edit the changed sentence**

【le】 me rappelez ma fille.

You remind me of my daughter.

[[French#^fr-Q0537-answer|Compare the answer]]
^fr-Q0537

**fr-Q0538 · Build the sentence**

Arrange: fille. / ma / Vous / me / rappelez

You remind me of my daughter.

[[French#^fr-Q0538-answer|Compare the answer]]
^fr-Q0538

**fr-Q0539 · Write a translation**

Write this in French: You're not fast enough.

[[French#^fr-Q0539-answer|Compare the answer]]
^fr-Q0539

**fr-Q0540 · Explain the grammar**

【Vous】 n'êtes pas assez rapide.

You're not fast enough.

[[French#^fr-Q0540-answer|Compare the answer]]
^fr-Q0540

**fr-Q0541 · Fill the gap**

Je peux personnellement ____ en assurer.

I can give you my personal assurance of that.

[[French#^fr-Q0541-answer|Compare the answer]]
^fr-Q0541

**fr-Q0542 · Choose the form**

Je peux personnellement ____ en assurer.

I can give you my personal assurance of that.

Choices: la / vous / les / le

[[French#^fr-Q0542-answer|Compare the answer]]
^fr-Q0542

**fr-Q0543 · Edit the changed sentence**

【le】 auriez pu être heureuse.

You could have been happy.

[[French#^fr-Q0543-answer|Compare the answer]]
^fr-Q0543

**fr-Q0544 · Build the sentence**

Arrange: pu / Vous / auriez / être / heureuse.

You could have been happy.

[[French#^fr-Q0544-answer|Compare the answer]]
^fr-Q0544

**fr-Q0545 · Write a translation**

Write this in French: The king governed the country.

[[French#^fr-Q0545-answer|Compare the answer]]
^fr-Q0545

**fr-Q0546 · Explain the grammar**

【Le】 roi gouvernait le pays.

The king governed the country.

[[French#^fr-Q0546-answer|Compare the answer]]
^fr-Q0546

**fr-Q0547 · Fill the gap**

Deux des choses ____ plus importantes dont tu puisses disposer dans ta vie sont les amis et les rêves.

Two of the most important things you can have in your life are friendships and dreams.

[[French#^fr-Q0547-answer|Compare the answer]]
^fr-Q0547

**fr-Q0548 · Choose the form**

Deux des choses ____ plus importantes dont tu puisses disposer dans ta vie sont les amis et les rêves.

Two of the most important things you can have in your life are friendships and dreams.

Choices: lui / les / la / le

[[French#^fr-Q0548-answer|Compare the answer]]
^fr-Q0548

**fr-Q0549 · Edit the changed sentence**

【le】 devons réduire les coûts.

We need to cut costs.

[[French#^fr-Q0549-answer|Compare the answer]]
^fr-Q0549

**fr-Q0550 · Build the sentence**

Arrange: Nous / coûts. / réduire / les / devons

We need to cut costs.

[[French#^fr-Q0550-answer|Compare the answer]]
^fr-Q0550


### Y and en · 50 questions

**fr-Q0551 · Write a translation**

Write this in French: He knows how to behave in public.

[[French#^fr-Q0551-answer|Compare the answer]]
^fr-Q0551

**fr-Q0552 · Explain the grammar**

Il sait comment se tenir 【en】 public.

He knows how to behave in public.

[[French#^fr-Q0552-answer|Compare the answer]]
^fr-Q0552

**fr-Q0553 · Fill the gap**

On n'____ est jamais certain.

You never know for sure.

[[French#^fr-Q0553-answer|Compare the answer]]
^fr-Q0553

**fr-Q0554 · Choose the form**

On n'____ est jamais certain.

You never know for sure.

Choices: y / lui / en / le

[[French#^fr-Q0554-answer|Compare the answer]]
^fr-Q0554

**fr-Q0555 · Edit the changed sentence**

Je suis 【y】 léger surpoids.

I'm a little overweight.

[[French#^fr-Q0555-answer|Compare the answer]]
^fr-Q0555

**fr-Q0556 · Build the sentence**

Arrange: Je / en / léger / surpoids. / suis

I'm a little overweight.

[[French#^fr-Q0556-answer|Compare the answer]]
^fr-Q0556

**fr-Q0557 · Write a translation**

Write this in French: There seems to be a hidden meaning to his words.

[[French#^fr-Q0557-answer|Compare the answer]]
^fr-Q0557

**fr-Q0558 · Explain the grammar**

Il semble 【y】 avoir un sens caché dans ses mots.

There seems to be a hidden meaning to his words.

[[French#^fr-Q0558-answer|Compare the answer]]
^fr-Q0558

**fr-Q0559 · Fill the gap**

Nous ____ connûmes une expérience désagréable.

We had an unpleasant experience there.

[[French#^fr-Q0559-answer|Compare the answer]]
^fr-Q0559

**fr-Q0560 · Choose the form**

Nous ____ connûmes une expérience désagréable.

We had an unpleasant experience there.

Choices: le / y / en / lui

[[French#^fr-Q0560-answer|Compare the answer]]
^fr-Q0560

**fr-Q0561 · Edit the changed sentence**

Nous 【y】 sommes pour ainsi dire certains.

We're quite certain of that.

[[French#^fr-Q0561-answer|Compare the answer]]
^fr-Q0561

**fr-Q0562 · Build the sentence**

Arrange: pour / ainsi / en / Nous / dire / sommes / certains.

We're quite certain of that.

[[French#^fr-Q0562-answer|Compare the answer]]
^fr-Q0562

**fr-Q0563 · Write a translation**

Write this in French: Elephants live in Asia and Africa.

[[French#^fr-Q0563-answer|Compare the answer]]
^fr-Q0563

**fr-Q0564 · Explain the grammar**

Les éléphants vivent 【en】 Asie et en Afrique.

Elephants live in Asia and Africa.

[[French#^fr-Q0564-answer|Compare the answer]]
^fr-Q0564

**fr-Q0565 · Fill the gap**

Tu ne veux pas aller ____ prison, si ?

You don't want to go to prison, do you?

[[French#^fr-Q0565-answer|Compare the answer]]
^fr-Q0565

**fr-Q0566 · Choose the form**

Tu ne veux pas aller ____ prison, si ?

You don't want to go to prison, do you?

Choices: lui / y / le / en

[[French#^fr-Q0566-answer|Compare the answer]]
^fr-Q0566

**fr-Q0567 · Edit the changed sentence**

J'ai un ami qui habite 【y】 Angleterre.

I have a friend who lives in England.

[[French#^fr-Q0567-answer|Compare the answer]]
^fr-Q0567

**fr-Q0568 · Build the sentence**

Arrange: ami / en / habite / Angleterre. / J'ai / qui / un

I have a friend who lives in England.

[[French#^fr-Q0568-answer|Compare the answer]]
^fr-Q0568

**fr-Q0569 · Write a translation**

Write this in French: I want to hear more about your trip.

[[French#^fr-Q0569-answer|Compare the answer]]
^fr-Q0569

**fr-Q0570 · Explain the grammar**

Je veux 【en】 entendre plus sur ton voyage.

I want to hear more about your trip.

[[French#^fr-Q0570-answer|Compare the answer]]
^fr-Q0570

**fr-Q0571 · Fill the gap**

J'ai dépensé tout mon salaire ____ une journée.

I spent all my wages in one day.

[[French#^fr-Q0571-answer|Compare the answer]]
^fr-Q0571

**fr-Q0572 · Choose the form**

J'ai dépensé tout mon salaire ____ une journée.

I spent all my wages in one day.

Choices: en / lui / y / le

[[French#^fr-Q0572-answer|Compare the answer]]
^fr-Q0572

**fr-Q0573 · Edit the changed sentence**

Elle semble réservée mais elle a 【y】 vérité une forte volonté.

She seems reserved, but she's actually a strong-willed person.

[[French#^fr-Q0573-answer|Compare the answer]]
^fr-Q0573

**fr-Q0574 · Build the sentence**

Arrange: volonté. / a / réservée / mais / elle / une / semble / forte / en / Elle / vérité

She seems reserved, but she's actually a strong-willed person.

[[French#^fr-Q0574-answer|Compare the answer]]
^fr-Q0574

**fr-Q0575 · Write a translation**

Write this in French: He listened to the news on the radio as he fed his dog.

[[French#^fr-Q0575-answer|Compare the answer]]
^fr-Q0575

**fr-Q0576 · Explain the grammar**

Il écouta les nouvelles à la radio 【en】 nourrissant son chien.

He listened to the news on the radio as he fed his dog.

[[French#^fr-Q0576-answer|Compare the answer]]
^fr-Q0576

**fr-Q0577 · Fill the gap**

____ travaillant ensemble, ils ont nettoyé toute la maison très rapidement.

Working together, they cleaned the entire house in no time.

[[French#^fr-Q0577-answer|Compare the answer]]
^fr-Q0577

**fr-Q0578 · Choose the form**

____ travaillant ensemble, ils ont nettoyé toute la maison très rapidement.

Working together, they cleaned the entire house in no time.

Choices: En / lui / y / le

[[French#^fr-Q0578-answer|Compare the answer]]
^fr-Q0578

**fr-Q0579 · Edit the changed sentence**

Berlin est 【y】 Allemagne.

Berlin is in Germany.

[[French#^fr-Q0579-answer|Compare the answer]]
^fr-Q0579

**fr-Q0580 · Build the sentence**

Arrange: est / Berlin / en / Allemagne.

Berlin is in Germany.

[[French#^fr-Q0580-answer|Compare the answer]]
^fr-Q0580

**fr-Q0581 · Write a translation**

Write this in French: You're kind of cute when you're mad.

[[French#^fr-Q0581-answer|Compare the answer]]
^fr-Q0581

**fr-Q0582 · Explain the grammar**

Vous êtes assez mignons quand vous êtes 【en】 colère.

You're kind of cute when you're mad.

[[French#^fr-Q0582-answer|Compare the answer]]
^fr-Q0582

**fr-Q0583 · Fill the gap**

Il est ____ retard.

He is late.

[[French#^fr-Q0583-answer|Compare the answer]]
^fr-Q0583

**fr-Q0584 · Choose the form**

Il est ____ retard.

He is late.

Choices: y / en / le / lui

[[French#^fr-Q0584-answer|Compare the answer]]
^fr-Q0584

**fr-Q0585 · Edit the changed sentence**

Je veux vivre 【y】 ville.

I want to live in the city.

[[French#^fr-Q0585-answer|Compare the answer]]
^fr-Q0585

**fr-Q0586 · Build the sentence**

Arrange: ville. / en / vivre / veux / Je

I want to live in the city.

[[French#^fr-Q0586-answer|Compare the answer]]
^fr-Q0586

**fr-Q0587 · Write a translation**

Write this in French: These cookies are star-shaped.

[[French#^fr-Q0587-answer|Compare the answer]]
^fr-Q0587

**fr-Q0588 · Explain the grammar**

Ces gâteaux sont 【en】 forme d'étoile.

These cookies are star-shaped.

[[French#^fr-Q0588-answer|Compare the answer]]
^fr-Q0588

**fr-Q0589 · Fill the gap**

Tu n'es pas ____ position de négocier.

You're in no position to bargain.

[[French#^fr-Q0589-answer|Compare the answer]]
^fr-Q0589

**fr-Q0590 · Choose the form**

Tu n'es pas ____ position de négocier.

You're in no position to bargain.

Choices: le / lui / en / y

[[French#^fr-Q0590-answer|Compare the answer]]
^fr-Q0590

**fr-Q0591 · Edit the changed sentence**

Que sommes-nous, 【y】 effet, qu'est ce que notre caractère, sinon la condensation de l'histoire que nous avons vécue depuis notre naissance.

What are we, indeed, what is our character, if not the concentration of the things which we have lived since our birth.

[[French#^fr-Q0591-answer|Compare the answer]]
^fr-Q0591

**fr-Q0592 · Build the sentence**

Arrange: notre / naissance. / condensation / depuis / que / notre / Que / en / caractère, / ce / qu'est / l'histoire / avons / la / vécue / de / que / sommes-nous, / sinon / nous / effet,

What are we, indeed, what is our character, if not the concentration of the things which we have lived since our birth.

[[French#^fr-Q0592-answer|Compare the answer]]
^fr-Q0592

**fr-Q0593 · Write a translation**

Write this in French: She divided the cake into five pieces.

[[French#^fr-Q0593-answer|Compare the answer]]
^fr-Q0593

**fr-Q0594 · Explain the grammar**

Elle partagea la tarte 【en】 cinq.

She divided the cake into five pieces.

[[French#^fr-Q0594-answer|Compare the answer]]
^fr-Q0594

**fr-Q0595 · Fill the gap**

Comme mon père et mon grand-père ont beaucoup de frères et sœurs, il ____ a beaucoup d'enfants dans notre famille.

As my father and my grandfather have many siblings, there are a lot of kids in our family.

[[French#^fr-Q0595-answer|Compare the answer]]
^fr-Q0595

**fr-Q0596 · Choose the form**

Comme mon père et mon grand-père ont beaucoup de frères et sœurs, il ____ a beaucoup d'enfants dans notre famille.

As my father and my grandfather have many siblings, there are a lot of kids in our family.

Choices: y / en / lui / le

[[French#^fr-Q0596-answer|Compare the answer]]
^fr-Q0596

**fr-Q0597 · Edit the changed sentence**

J'ai pensé que vous vous 【y】 étiez assez bien tirée.

I thought you did fairly well.

[[French#^fr-Q0597-answer|Compare the answer]]
^fr-Q0597

**fr-Q0598 · Build the sentence**

Arrange: bien / tirée. / J'ai / étiez / que / vous / pensé / en / vous / assez

I thought you did fairly well.

[[French#^fr-Q0598-answer|Compare the answer]]
^fr-Q0598

**fr-Q0599 · Write a translation**

Write this in French: I started working about 4 weeks ago.

[[French#^fr-Q0599-answer|Compare the answer]]
^fr-Q0599

**fr-Q0600 · Explain the grammar**

J'ai commencé à travailler il 【y】 a environ 4 semaines.

I started working about 4 weeks ago.

[[French#^fr-Q0600-answer|Compare the answer]]
^fr-Q0600


### Relative clauses · 50 questions

**fr-Q0601 · Fill the gap**

Attends ici jusqu'à ce ____ je revienne !

Wait here until I come back.

[[French#^fr-Q0601-answer|Compare the answer]]
^fr-Q0601

**fr-Q0602 · Choose the form**

Attends ici jusqu'à ce ____ je revienne !

Wait here until I come back.

Choices: où / que / qui / dont

[[French#^fr-Q0602-answer|Compare the answer]]
^fr-Q0602

**fr-Q0603 · Edit the changed sentence**

Tom semble être conscient de ce 【que】 se passe.

Tom seems to be aware of what's happening.

[[French#^fr-Q0603-answer|Compare the answer]]
^fr-Q0603

**fr-Q0604 · Build the sentence**

Arrange: se / être / Tom / semble / passe. / de / ce / qui / conscient

Tom seems to be aware of what's happening.

[[French#^fr-Q0604-answer|Compare the answer]]
^fr-Q0604

**fr-Q0605 · Write a translation**

Write this in French: Where exactly do you live?

[[French#^fr-Q0605-answer|Compare the answer]]
^fr-Q0605

**fr-Q0606 · Explain the grammar**

【Où】 vis-tu exactement ?

Where exactly do you live?

[[French#^fr-Q0606-answer|Compare the answer]]
^fr-Q0606

**fr-Q0607 · Fill the gap**

Les enfants veulent souvent faire des choses ____ sont dangereuses, sans savoir qu'elles sont dangereuses.

Children often want to do things that are dangerous without knowing that they are dangerous.

[[French#^fr-Q0607-answer|Compare the answer]]
^fr-Q0607

**fr-Q0608 · Choose the form**

Les enfants veulent souvent faire des choses ____ sont dangereuses, sans savoir qu'elles sont dangereuses.

Children often want to do things that are dangerous without knowing that they are dangerous.

Choices: que / dont / où / qui

[[French#^fr-Q0608-answer|Compare the answer]]
^fr-Q0608

**fr-Q0609 · Edit the changed sentence**

Est-ce là ce 【qui】 vous pensez que je veuille entendre ?

Is that what you think I want to hear?

[[French#^fr-Q0609-answer|Compare the answer]]
^fr-Q0609

**fr-Q0610 · Build the sentence**

Arrange: vous / ? / que / là / pensez / entendre / veuille / que / je / Est-ce / ce

Is that what you think I want to hear?

[[French#^fr-Q0610-answer|Compare the answer]]
^fr-Q0610

**fr-Q0611 · Write a translation**

Write this in French: I think you're funny.

[[French#^fr-Q0611-answer|Compare the answer]]
^fr-Q0611

**fr-Q0612 · Explain the grammar**

Je pense 【que】 vous êtes marrant.

I think you're funny.

[[French#^fr-Q0612-answer|Compare the answer]]
^fr-Q0612

**fr-Q0613 · Fill the gap**

Je ne serai jamais aussi bonne ____ toi.

I'll never be as good as you.

[[French#^fr-Q0613-answer|Compare the answer]]
^fr-Q0613

**fr-Q0614 · Choose the form**

Je ne serai jamais aussi bonne ____ toi.

I'll never be as good as you.

Choices: qui / que / dont / où

[[French#^fr-Q0614-answer|Compare the answer]]
^fr-Q0614

**fr-Q0615 · Edit the changed sentence**

Je promets 【qui】 je prendrai bien soin de votre chien.

I promise I'll take good care of your dog.

[[French#^fr-Q0615-answer|Compare the answer]]
^fr-Q0615

**fr-Q0616 · Build the sentence**

Arrange: bien / de / que / Je / chien. / votre / je / prendrai / soin / promets

I promise I'll take good care of your dog.

[[French#^fr-Q0616-answer|Compare the answer]]
^fr-Q0616

**fr-Q0617 · Write a translation**

Write this in French: Women are physically weaker than men.

[[French#^fr-Q0617-answer|Compare the answer]]
^fr-Q0617

**fr-Q0618 · Explain the grammar**

Les femmes sont physiquement plus faibles 【que】 les hommes.

Women are physically weaker than men.

[[French#^fr-Q0618-answer|Compare the answer]]
^fr-Q0618

**fr-Q0619 · Fill the gap**

Chaque fois ____ je trouve quelque chose que j'aime, c'est trop cher.

Whenever I find something I like, it's too expensive.

[[French#^fr-Q0619-answer|Compare the answer]]
^fr-Q0619

**fr-Q0620 · Choose the form**

Chaque fois ____ je trouve quelque chose que j'aime, c'est trop cher.

Whenever I find something I like, it's too expensive.

Choices: dont / où / qui / que

[[French#^fr-Q0620-answer|Compare the answer]]
^fr-Q0620

**fr-Q0621 · Edit the changed sentence**

Honnêtement, je ne pense pas 【qui】 vous ayez l’étoffe pour devenir enseignante.

Honestly, I don't think you have what it takes to become a teacher.

[[French#^fr-Q0621-answer|Compare the answer]]
^fr-Q0621

**fr-Q0622 · Build the sentence**

Arrange: pense / que / je / vous / l’étoffe / devenir / ayez / Honnêtement, / ne / enseignante. / pas / pour

Honestly, I don't think you have what it takes to become a teacher.

[[French#^fr-Q0622-answer|Compare the answer]]
^fr-Q0622

**fr-Q0623 · Write a translation**

Write this in French: You are a child of the universe, no less than the trees and the stars; you have a right to be here.

[[French#^fr-Q0623-answer|Compare the answer]]
^fr-Q0623

**fr-Q0624 · Explain the grammar**

Tu es enfant de l'univers, tout autant 【que】 les arbres et les étoiles ; tu as droit à te trouver ici.

You are a child of the universe, no less than the trees and the stars; you have a right to be here.

[[French#^fr-Q0624-answer|Compare the answer]]
^fr-Q0624

**fr-Q0625 · Fill the gap**

Est-ce ____ c'est ta chanson préférée ?

Is this your favorite song?

[[French#^fr-Q0625-answer|Compare the answer]]
^fr-Q0625

**fr-Q0626 · Choose the form**

Est-ce ____ c'est ta chanson préférée ?

Is this your favorite song?

Choices: que / où / dont / qui

[[French#^fr-Q0626-answer|Compare the answer]]
^fr-Q0626

**fr-Q0627 · Edit the changed sentence**

Dès 【qui】 je peux avoir l'occasion, je vous enverrai de l'argent.

As soon as I can get the chance, I'll send you some money.

[[French#^fr-Q0627-answer|Compare the answer]]
^fr-Q0627

**fr-Q0628 · Build the sentence**

Arrange: Dès / peux / enverrai / je / de / vous / l'occasion, / avoir / que / l'argent. / je

As soon as I can get the chance, I'll send you some money.

[[French#^fr-Q0628-answer|Compare the answer]]
^fr-Q0628

**fr-Q0629 · Write a translation**

Write this in French: Do you have any idea what that is?

[[French#^fr-Q0629-answer|Compare the answer]]
^fr-Q0629

**fr-Q0630 · Explain the grammar**

As-tu une idée de ce 【que】 c'est ?

Do you have any idea what that is?

[[French#^fr-Q0630-answer|Compare the answer]]
^fr-Q0630

**fr-Q0631 · Fill the gap**

Tom pensait probablement ____ j'étais assoiffée.

Tom probably thought I was thirsty.

[[French#^fr-Q0631-answer|Compare the answer]]
^fr-Q0631

**fr-Q0632 · Choose the form**

Tom pensait probablement ____ j'étais assoiffée.

Tom probably thought I was thirsty.

Choices: que / qui / dont / où

[[French#^fr-Q0632-answer|Compare the answer]]
^fr-Q0632

**fr-Q0633 · Edit the changed sentence**

Est-ce 【qui】 ce chapeau est à toi ?

Is this hat yours?

[[French#^fr-Q0633-answer|Compare the answer]]
^fr-Q0633

**fr-Q0634 · Build the sentence**

Arrange: que / toi / Est-ce / ? / ce / chapeau / est / à

Is this hat yours?

[[French#^fr-Q0634-answer|Compare the answer]]
^fr-Q0634

**fr-Q0635 · Write a translation**

Write this in French: I think it's time for me to ask for directions.

[[French#^fr-Q0635-answer|Compare the answer]]
^fr-Q0635

**fr-Q0636 · Explain the grammar**

Je pense qu'il est temps 【que】 je demande des instructions.

I think it's time for me to ask for directions.

[[French#^fr-Q0636-answer|Compare the answer]]
^fr-Q0636

**fr-Q0637 · Fill the gap**

Je veux ____ vous descendiez de mon dos.

I want you to get off my back.

[[French#^fr-Q0637-answer|Compare the answer]]
^fr-Q0637

**fr-Q0638 · Choose the form**

Je veux ____ vous descendiez de mon dos.

I want you to get off my back.

Choices: où / dont / qui / que

[[French#^fr-Q0638-answer|Compare the answer]]
^fr-Q0638

**fr-Q0639 · Edit the changed sentence**

Je veux 【qui】 tu sois mon patron.

I want you to be my manager.

[[French#^fr-Q0639-answer|Compare the answer]]
^fr-Q0639

**fr-Q0640 · Build the sentence**

Arrange: Je / mon / sois / patron. / tu / veux / que

I want you to be my manager.

[[French#^fr-Q0640-answer|Compare the answer]]
^fr-Q0640

**fr-Q0641 · Write a translation**

Write this in French: Barking dogs seldom bite.

[[French#^fr-Q0641-answer|Compare the answer]]
^fr-Q0641

**fr-Q0642 · Explain the grammar**

Chien 【qui】 aboie ne mord pas.

Barking dogs seldom bite.

[[French#^fr-Q0642-answer|Compare the answer]]
^fr-Q0642

**fr-Q0643 · Fill the gap**

J'espérais ____ nous puissions encore être amis.

I was hoping we could still be friends.

[[French#^fr-Q0643-answer|Compare the answer]]
^fr-Q0643

**fr-Q0644 · Choose the form**

J'espérais ____ nous puissions encore être amis.

I was hoping we could still be friends.

Choices: où / que / qui / dont

[[French#^fr-Q0644-answer|Compare the answer]]
^fr-Q0644

**fr-Q0645 · Edit the changed sentence**

Les gens croient 【qui】 Dieu existe.

People believe that god exists.

[[French#^fr-Q0645-answer|Compare the answer]]
^fr-Q0645

**fr-Q0646 · Build the sentence**

Arrange: gens / Dieu / croient / que / existe. / Les

People believe that god exists.

[[French#^fr-Q0646-answer|Compare the answer]]
^fr-Q0646

**fr-Q0647 · Write a translation**

Write this in French: Even though we lost the game, I have to say that we played the better football.

[[French#^fr-Q0647-answer|Compare the answer]]
^fr-Q0647

**fr-Q0648 · Explain the grammar**

Même si nous avons perdu la partie, je dois dire 【que】 nous avons joué le meilleur football.

Even though we lost the game, I have to say that we played the better football.

[[French#^fr-Q0648-answer|Compare the answer]]
^fr-Q0648

**fr-Q0649 · Fill the gap**

Est-ce ____ tu travailles avec Tom ?

Are you and Tom working together?

[[French#^fr-Q0649-answer|Compare the answer]]
^fr-Q0649

**fr-Q0650 · Choose the form**

Est-ce ____ tu travailles avec Tom ?

Are you and Tom working together?

Choices: que / où / dont / qui

[[French#^fr-Q0650-answer|Compare the answer]]
^fr-Q0650


### Negation · 50 questions

**fr-Q0651 · Edit the changed sentence**

Ne m'arnaquez 【jamais】 !

Don't screw me over!

[[French#^fr-Q0651-answer|Compare the answer]]
^fr-Q0651

**fr-Q0652 · Build the sentence**

Arrange: ! / pas / m'arnaquez / Ne

Don't screw me over!

[[French#^fr-Q0652-answer|Compare the answer]]
^fr-Q0652

**fr-Q0653 · Write a translation**

Write this in French: I don't like being made a fool of.

[[French#^fr-Q0653-answer|Compare the answer]]
^fr-Q0653

**fr-Q0654 · Explain the grammar**

Je n'aime 【pas】 qu'on se moque de moi.

I don't like being made a fool of.

[[French#^fr-Q0654-answer|Compare the answer]]
^fr-Q0654

**fr-Q0655 · Fill the gap**

Ne dites ____ à ma blonde !

Don't tell my girlfriend.

[[French#^fr-Q0655-answer|Compare the answer]]
^fr-Q0655

**fr-Q0656 · Choose the form**

Ne dites ____ à ma blonde !

Don't tell my girlfriend.

Choices: personne / pas / jamais / rien

[[French#^fr-Q0656-answer|Compare the answer]]
^fr-Q0656

**fr-Q0657 · Edit the changed sentence**

Je ne vois 【jamais】 pourquoi je suis de mauvaise humeur ce matin.

I don't see why I am in a bad humor this morning.

[[French#^fr-Q0657-answer|Compare the answer]]
^fr-Q0657

**fr-Q0658 · Build the sentence**

Arrange: matin. / je / vois / ce / Je / pas / humeur / pourquoi / de / suis / mauvaise / ne

I don't see why I am in a bad humor this morning.

[[French#^fr-Q0658-answer|Compare the answer]]
^fr-Q0658

**fr-Q0659 · Write a translation**

Write this in French: It makes things easier if your matrix is sparse.

[[French#^fr-Q0659-answer|Compare the answer]]
^fr-Q0659

**fr-Q0660 · Explain the grammar**

Ça rend les choses 【plus】 faciles si ta matrice est creuse.

It makes things easier if your matrix is sparse.

[[French#^fr-Q0660-answer|Compare the answer]]
^fr-Q0660

**fr-Q0661 · Fill the gap**

Ce n'est ____ loin de Boston.

It's not far to Boston.

[[French#^fr-Q0661-answer|Compare the answer]]
^fr-Q0661

**fr-Q0662 · Choose the form**

Ce n'est ____ loin de Boston.

It's not far to Boston.

Choices: rien / jamais / personne / pas

[[French#^fr-Q0662-answer|Compare the answer]]
^fr-Q0662

**fr-Q0663 · Edit the changed sentence**

Les choses ne se présentent 【jamais】 bien.

Things are not looking good.

[[French#^fr-Q0663-answer|Compare the answer]]
^fr-Q0663

**fr-Q0664 · Build the sentence**

Arrange: se / choses / Les / ne / pas / présentent / bien.

Things are not looking good.

[[French#^fr-Q0664-answer|Compare the answer]]
^fr-Q0664

**fr-Q0665 · Write a translation**

Write this in French: You're not bad looking either.

[[French#^fr-Q0665-answer|Compare the answer]]
^fr-Q0665

**fr-Q0666 · Explain the grammar**

Vous n'êtes 【pas】 mal non plus.

You're not bad looking either.

[[French#^fr-Q0666-answer|Compare the answer]]
^fr-Q0666

**fr-Q0667 · Fill the gap**

Je suis le coureur le ____ rapide.

I am the fastest runner.

[[French#^fr-Q0667-answer|Compare the answer]]
^fr-Q0667

**fr-Q0668 · Choose the form**

Je suis le coureur le ____ rapide.

I am the fastest runner.

Choices: rien / plus / pas / jamais

[[French#^fr-Q0668-answer|Compare the answer]]
^fr-Q0668

**fr-Q0669 · Edit the changed sentence**

Je ne pus me tenir debout 【pas】 longtemps.

I could stand no more.

[[French#^fr-Q0669-answer|Compare the answer]]
^fr-Q0669

**fr-Q0670 · Build the sentence**

Arrange: Je / me / longtemps. / plus / pus / ne / debout / tenir

I could stand no more.

[[French#^fr-Q0670-answer|Compare the answer]]
^fr-Q0670

**fr-Q0671 · Write a translation**

Write this in French: I don't want to go and eat today.

[[French#^fr-Q0671-answer|Compare the answer]]
^fr-Q0671

**fr-Q0672 · Explain the grammar**

Je ne veux 【pas】 aller manger aujourd'hui.

I don't want to go and eat today.

[[French#^fr-Q0672-answer|Compare the answer]]
^fr-Q0672

**fr-Q0673 · Fill the gap**

Vous n'étiez ____ sérieux, si ?

You weren't serious, were you?

[[French#^fr-Q0673-answer|Compare the answer]]
^fr-Q0673

**fr-Q0674 · Choose the form**

Vous n'étiez ____ sérieux, si ?

You weren't serious, were you?

Choices: jamais / personne / rien / pas

[[French#^fr-Q0674-answer|Compare the answer]]
^fr-Q0674

**fr-Q0675 · Edit the changed sentence**

Ce n'est 【jamais】 facile d'écrire avec une craie.

It is not easy to write in chalk.

[[French#^fr-Q0675-answer|Compare the answer]]
^fr-Q0675

**fr-Q0676 · Build the sentence**

Arrange: pas / facile / une / n'est / avec / Ce / d'écrire / craie.

It is not easy to write in chalk.

[[French#^fr-Q0676-answer|Compare the answer]]
^fr-Q0676

**fr-Q0677 · Write a translation**

Write this in French: I can't find my ticket. I must have lost it.

[[French#^fr-Q0677-answer|Compare the answer]]
^fr-Q0677

**fr-Q0678 · Explain the grammar**

Je n'arrive 【pas】 à trouver mon ticket. Je dois l'avoir perdu.

I can't find my ticket. I must have lost it.

[[French#^fr-Q0678-answer|Compare the answer]]
^fr-Q0678

**fr-Q0679 · Fill the gap**

Il n'a ____ de famille.

He doesn't have a family.

[[French#^fr-Q0679-answer|Compare the answer]]
^fr-Q0679

**fr-Q0680 · Choose the form**

Il n'a ____ de famille.

He doesn't have a family.

Choices: personne / pas / rien / jamais

[[French#^fr-Q0680-answer|Compare the answer]]
^fr-Q0680

**fr-Q0681 · Edit the changed sentence**

Merci de ne 【jamais】 quitter.

Please hold the line.

[[French#^fr-Q0681-answer|Compare the answer]]
^fr-Q0681

**fr-Q0682 · Build the sentence**

Arrange: quitter. / Merci / de / pas / ne

Please hold the line.

[[French#^fr-Q0682-answer|Compare the answer]]
^fr-Q0682

**fr-Q0683 · Write a translation**

Write this in French: I'm not intimidated.

[[French#^fr-Q0683-answer|Compare the answer]]
^fr-Q0683

**fr-Q0684 · Explain the grammar**

Je ne suis 【pas】 intimidé.

I'm not intimidated.

[[French#^fr-Q0684-answer|Compare the answer]]
^fr-Q0684

**fr-Q0685 · Fill the gap**

Je ne suis ____ oublieuse.

I'm not forgetful.

[[French#^fr-Q0685-answer|Compare the answer]]
^fr-Q0685

**fr-Q0686 · Choose the form**

Je ne suis ____ oublieuse.

I'm not forgetful.

Choices: jamais / rien / personne / pas

[[French#^fr-Q0686-answer|Compare the answer]]
^fr-Q0686

**fr-Q0687 · Edit the changed sentence**

Je ne suis 【jamais】 une professionnelle.

I'm not a professional.

[[French#^fr-Q0687-answer|Compare the answer]]
^fr-Q0687

**fr-Q0688 · Build the sentence**

Arrange: pas / professionnelle. / Je / une / ne / suis

I'm not a professional.

[[French#^fr-Q0688-answer|Compare the answer]]
^fr-Q0688

**fr-Q0689 · Write a translation**

Write this in French: I don't need advisers.

[[French#^fr-Q0689-answer|Compare the answer]]
^fr-Q0689

**fr-Q0690 · Explain the grammar**

Je n'ai 【pas】 besoin de conseillers.

I don't need advisers.

[[French#^fr-Q0690-answer|Compare the answer]]
^fr-Q0690

**fr-Q0691 · Fill the gap**

Je n'ai ____ toute la journée.

I don't have all day.

[[French#^fr-Q0691-answer|Compare the answer]]
^fr-Q0691

**fr-Q0692 · Choose the form**

Je n'ai ____ toute la journée.

I don't have all day.

Choices: jamais / personne / pas / rien

[[French#^fr-Q0692-answer|Compare the answer]]
^fr-Q0692

**fr-Q0693 · Edit the changed sentence**

Tom ne prête 【jamais】 attention.

Tom isn't paying attention.

[[French#^fr-Q0693-answer|Compare the answer]]
^fr-Q0693

**fr-Q0694 · Build the sentence**

Arrange: attention. / pas / prête / Tom / ne

Tom isn't paying attention.

[[French#^fr-Q0694-answer|Compare the answer]]
^fr-Q0694

**fr-Q0695 · Write a translation**

Write this in French: It's not for the faint of heart.

[[French#^fr-Q0695-answer|Compare the answer]]
^fr-Q0695

**fr-Q0696 · Explain the grammar**

Ce n'est 【pas】 pour les mauviettes.

It's not for the faint of heart.

[[French#^fr-Q0696-answer|Compare the answer]]
^fr-Q0696

**fr-Q0697 · Fill the gap**

Tom est déjà là, mais Bill n'est ____ encore arrivé.

Tom's already here, but Bill hasn't come yet.

[[French#^fr-Q0697-answer|Compare the answer]]
^fr-Q0697

**fr-Q0698 · Choose the form**

Tom est déjà là, mais Bill n'est ____ encore arrivé.

Tom's already here, but Bill hasn't come yet.

Choices: jamais / personne / pas / rien

[[French#^fr-Q0698-answer|Compare the answer]]
^fr-Q0698

**fr-Q0699 · Edit the changed sentence**

Je ne m'intéresse 【jamais】 à la nourriture étrangère.

I don't care for foreign food.

[[French#^fr-Q0699-answer|Compare the answer]]
^fr-Q0699

**fr-Q0700 · Build the sentence**

Arrange: ne / nourriture / Je / la / pas / à / étrangère. / m'intéresse

I don't care for foreign food.

[[French#^fr-Q0700-answer|Compare the answer]]
^fr-Q0700


### Questions and indirect questions · 50 questions

**fr-Q0701 · Write a translation**

Write this in French: How many pipes does this organ have?

[[French#^fr-Q0701-answer|Compare the answer]]
^fr-Q0701

**fr-Q0702 · Explain the grammar**

【Combien】 de tuyaux compte cet orgue ?

How many pipes does this organ have?

[[French#^fr-Q0702-answer|Compare the answer]]
^fr-Q0702

**fr-Q0703 · Fill the gap**

____ la chemise coûte-t-elle ?

How much does the shirt cost?

[[French#^fr-Q0703-answer|Compare the answer]]
^fr-Q0703

**fr-Q0704 · Choose the form**

____ la chemise coûte-t-elle ?

How much does the shirt cost?

Choices: Combien / quand / pourquoi / comment

[[French#^fr-Q0704-answer|Compare the answer]]
^fr-Q0704

**fr-Q0705 · Edit the changed sentence**

【pourquoi】 trouvez-vous Kyoto ?

How do you like Kyoto?

[[French#^fr-Q0705-answer|Compare the answer]]
^fr-Q0705

**fr-Q0706 · Build the sentence**

Arrange: trouvez-vous / Kyoto / Comment / ?

How do you like Kyoto?

[[French#^fr-Q0706-answer|Compare the answer]]
^fr-Q0706

**fr-Q0707 · Write a translation**

Write this in French: People ask me 'why would you want to cherish a piece of junk like that?' But this little beauty means the world to me.

[[French#^fr-Q0707-answer|Compare the answer]]
^fr-Q0707

**fr-Q0708 · Explain the grammar**

Les gens me demandent : "【pourquoi】 veux-tu chérir un tas de ferraille comme ça ?" Mais cette petite merveille veut tout dire pour moi.

People ask me 'why would you want to cherish a piece of junk like that?' But this little beauty means the world to me.

[[French#^fr-Q0708-answer|Compare the answer]]
^fr-Q0708

**fr-Q0709 · Fill the gap**

Je deviendrai folle ____ ça continue.

I'll go crazy if this keeps up.

[[French#^fr-Q0709-answer|Compare the answer]]
^fr-Q0709

**fr-Q0710 · Choose the form**

Je deviendrai folle ____ ça continue.

I'll go crazy if this keeps up.

Choices: quand / comment / si / pourquoi

[[French#^fr-Q0710-answer|Compare the answer]]
^fr-Q0710

**fr-Q0711 · Edit the changed sentence**

Depuis 【pourquoi】 de temps avez-vous planifié ce marriage ?

How long have you been planning this wedding?

[[French#^fr-Q0711-answer|Compare the answer]]
^fr-Q0711

**fr-Q0712 · Build the sentence**

Arrange: combien / marriage / de / Depuis / planifié / temps / ? / ce / avez-vous

How long have you been planning this wedding?

[[French#^fr-Q0712-answer|Compare the answer]]
^fr-Q0712

**fr-Q0713 · Write a translation**

Write this in French: Why on earth did you take him to the station?

[[French#^fr-Q0713-answer|Compare the answer]]
^fr-Q0713

**fr-Q0714 · Explain the grammar**

【Pourquoi】, mon Dieu, l'as-tu amené à la gare ?

Why on earth did you take him to the station?

[[French#^fr-Q0714-answer|Compare the answer]]
^fr-Q0714

**fr-Q0715 · Fill the gap**

Excusez-moi. ____ vous appelez-vous?

Excuse me. What's your name?

[[French#^fr-Q0715-answer|Compare the answer]]
^fr-Q0715

**fr-Q0716 · Choose the form**

Excusez-moi. ____ vous appelez-vous?

Excuse me. What's your name?

Choices: quand / Comment / combien / pourquoi

[[French#^fr-Q0716-answer|Compare the answer]]
^fr-Q0716

**fr-Q0717 · Edit the changed sentence**

【pourquoi】 seulement je pouvais parler français.

If only I could speak French.

[[French#^fr-Q0717-answer|Compare the answer]]
^fr-Q0717

**fr-Q0718 · Build the sentence**

Arrange: seulement / Si / parler / pouvais / je / français.

If only I could speak French.

[[French#^fr-Q0718-answer|Compare the answer]]
^fr-Q0718

**fr-Q0719 · Write a translation**

Write this in French: Why are they fighting?

[[French#^fr-Q0719-answer|Compare the answer]]
^fr-Q0719

**fr-Q0720 · Explain the grammar**

【Pourquoi】 se battent-elles ?

Why are they fighting?

[[French#^fr-Q0720-answer|Compare the answer]]
^fr-Q0720

**fr-Q0721 · Fill the gap**

____ reviendrez-vous à Melbourne ?

When are you coming to Melbourne again?

[[French#^fr-Q0721-answer|Compare the answer]]
^fr-Q0721

**fr-Q0722 · Choose the form**

____ reviendrez-vous à Melbourne ?

When are you coming to Melbourne again?

Choices: comment / Quand / combien / pourquoi

[[French#^fr-Q0722-answer|Compare the answer]]
^fr-Q0722

**fr-Q0723 · Edit the changed sentence**

【pourquoi】 tu es en difficulté, écris-moi une lettre.

Please write me a letter whenever you run into trouble.

[[French#^fr-Q0723-answer|Compare the answer]]
^fr-Q0723

**fr-Q0724 · Build the sentence**

Arrange: es / écris-moi / Si / une / tu / difficulté, / en / lettre.

Please write me a letter whenever you run into trouble.

[[French#^fr-Q0724-answer|Compare the answer]]
^fr-Q0724

**fr-Q0725 · Write a translation**

Write this in French: I want to know why I'm here.

[[French#^fr-Q0725-answer|Compare the answer]]
^fr-Q0725

**fr-Q0726 · Explain the grammar**

Je veux savoir 【pourquoi】 je suis ici.

I want to know why I'm here.

[[French#^fr-Q0726-answer|Compare the answer]]
^fr-Q0726

**fr-Q0727 · Fill the gap**

____ peux-tu critiquer ça ?

How can you criticize that?

[[French#^fr-Q0727-answer|Compare the answer]]
^fr-Q0727

**fr-Q0728 · Choose the form**

____ peux-tu critiquer ça ?

How can you criticize that?

Choices: combien / quand / Comment / pourquoi

[[French#^fr-Q0728-answer|Compare the answer]]
^fr-Q0728

**fr-Q0729 · Edit the changed sentence**

J'étais très heureux 【pourquoi】 j'entendis les nouvelles.

I was very happy when I heard that news.

[[French#^fr-Q0729-answer|Compare the answer]]
^fr-Q0729

**fr-Q0730 · Build the sentence**

Arrange: quand / j'entendis / les / très / J'étais / nouvelles. / heureux

I was very happy when I heard that news.

[[French#^fr-Q0730-answer|Compare the answer]]
^fr-Q0730

**fr-Q0731 · Write a translation**

Write this in French: Why didn't you call for help?

[[French#^fr-Q0731-answer|Compare the answer]]
^fr-Q0731

**fr-Q0732 · Explain the grammar**

【Pourquoi】 n'avez-vous pas appelé à l'aide ?

Why didn't you call for help?

[[French#^fr-Q0732-answer|Compare the answer]]
^fr-Q0732

**fr-Q0733 · Fill the gap**

Je me demande ____ nous aurons à payer.

I wonder how much we'll have to pay.

[[French#^fr-Q0733-answer|Compare the answer]]
^fr-Q0733

**fr-Q0734 · Choose the form**

Je me demande ____ nous aurons à payer.

I wonder how much we'll have to pay.

Choices: comment / quand / pourquoi / combien

[[French#^fr-Q0734-answer|Compare the answer]]
^fr-Q0734

**fr-Q0735 · Edit the changed sentence**

Je ne sais pas 【pourquoi】 te dénommer.

I don't know what to call you.

[[French#^fr-Q0735-answer|Compare the answer]]
^fr-Q0735

**fr-Q0736 · Build the sentence**

Arrange: Je / sais / comment / te / ne / dénommer. / pas

I don't know what to call you.

[[French#^fr-Q0736-answer|Compare the answer]]
^fr-Q0736

**fr-Q0737 · Write a translation**

Write this in French: I'm making about four times as much myself as when I first hired Tony.

[[French#^fr-Q0737-answer|Compare the answer]]
^fr-Q0737

**fr-Q0738 · Explain the grammar**

Je fais quatre fois plus par moi-même que 【quand】 j'ai engagé Tony pour la première fois.

I'm making about four times as much myself as when I first hired Tony.

[[French#^fr-Q0738-answer|Compare the answer]]
^fr-Q0738

**fr-Q0739 · Fill the gap**

____ t'es-tu blessé ?

How did you get hurt?

[[French#^fr-Q0739-answer|Compare the answer]]
^fr-Q0739

**fr-Q0740 · Choose the form**

____ t'es-tu blessé ?

How did you get hurt?

Choices: combien / Comment / pourquoi / quand

[[French#^fr-Q0740-answer|Compare the answer]]
^fr-Q0740

**fr-Q0741 · Edit the changed sentence**

【pourquoi】 on gratte un peu sous la couche de vieux, il y a encore un enfant.

If you scrape off a bit under the layer of old man, there is still a child.

[[French#^fr-Q0741-answer|Compare the answer]]
^fr-Q0741

**fr-Q0742 · Build the sentence**

Arrange: a / il / Si / un / un / de / y / gratte / sous / couche / encore / vieux, / peu / la / on / enfant.

If you scrape off a bit under the layer of old man, there is still a child.

[[French#^fr-Q0742-answer|Compare the answer]]
^fr-Q0742

**fr-Q0743 · Write a translation**

Write this in French: "Tell me, aren't you hungry?"" "Yes, of course, and thirsty too."

[[French#^fr-Q0743-answer|Compare the answer]]
^fr-Q0743

**fr-Q0744 · Explain the grammar**

« Dis donc, tu n'as pas faim ? » « 【Si】, bien sûr, et soif aussi. »

"Tell me, aren't you hungry?"" "Yes, of course, and thirsty too."

[[French#^fr-Q0744-answer|Compare the answer]]
^fr-Q0744

**fr-Q0745 · Fill the gap**

Nazareth ! ____ quelque chose de bon peut sortir de là ?

Nazareth! Can anything good come from there?

[[French#^fr-Q0745-answer|Compare the answer]]
^fr-Q0745

**fr-Q0746 · Choose the form**

Nazareth ! ____ quelque chose de bon peut sortir de là ?

Nazareth! Can anything good come from there?

Choices: quand / pourquoi / comment / Est-ce que

[[French#^fr-Q0746-answer|Compare the answer]]
^fr-Q0746

**fr-Q0747 · Edit the changed sentence**

Je veux juste savoir 【comment】 tu m'as amenée ici.

I just want to know why you brought me here.

[[French#^fr-Q0747-answer|Compare the answer]]
^fr-Q0747

**fr-Q0748 · Build the sentence**

Arrange: juste / savoir / ici. / tu / amenée / pourquoi / Je / m'as / veux

I just want to know why you brought me here.

[[French#^fr-Q0748-answer|Compare the answer]]
^fr-Q0748

**fr-Q0749 · Write a translation**

Write this in French: How shall we find it?

[[French#^fr-Q0749-answer|Compare the answer]]
^fr-Q0749

**fr-Q0750 · Explain the grammar**

【Comment】 allons-nous trouver ça ?

How shall we find it?

[[French#^fr-Q0750-answer|Compare the answer]]
^fr-Q0750


### Conditions · 50 questions

**fr-Q0751 · Fill the gap**

Nous n'étions pas ____ occupées.

We weren't all that busy.

[[French#^fr-Q0751-answer|Compare the answer]]
^fr-Q0751

**fr-Q0752 · Choose the form**

Nous n'étions pas ____ occupées.

We weren't all that busy.

Choices: parce que / si / bien que / quand

[[French#^fr-Q0752-answer|Compare the answer]]
^fr-Q0752

**fr-Q0753 · Edit the changed sentence**

【quand】 j'étais vous, je ne le traduirais pas littéralement.

If I were you, I wouldn't translate it literally.

[[French#^fr-Q0753-answer|Compare the answer]]
^fr-Q0753

**fr-Q0754 · Build the sentence**

Arrange: Si / littéralement. / traduirais / le / vous, / je / pas / ne / j'étais

If I were you, I wouldn't translate it literally.

[[French#^fr-Q0754-answer|Compare the answer]]
^fr-Q0754

**fr-Q0755 · Write a translation**

Write this in French: If countries were named after the words you first hear when you go there, England would have to be called Damn It.

[[French#^fr-Q0755-answer|Compare the answer]]
^fr-Q0755

**fr-Q0756 · Explain the grammar**

【Si】 l'on devait nommer les pays d'après les mots qu'on y entend d'abord, l'Angleterre s'appellerait “damn it”.

If countries were named after the words you first hear when you go there, England would have to be called Damn It.

[[French#^fr-Q0756-answer|Compare the answer]]
^fr-Q0756

**fr-Q0757 · Fill the gap**

____ quelqu'un devait demander quel est le but de l'histoire, je ne saurais vraiment pas.

If anyone was to ask what the point of the story is, I really don't know.

[[French#^fr-Q0757-answer|Compare the answer]]
^fr-Q0757

**fr-Q0758 · Choose the form**

____ quelqu'un devait demander quel est le but de l'histoire, je ne saurais vraiment pas.

If anyone was to ask what the point of the story is, I really don't know.

Choices: bien que / parce que / quand / Si

[[French#^fr-Q0758-answer|Compare the answer]]
^fr-Q0758

**fr-Q0759 · Edit the changed sentence**

【quand】 les péchés faisaient souffrir quand on les fait, nous serions tous des saints.

If sins made us suffer when we sinned, we'd all be saints.

[[French#^fr-Q0759-answer|Compare the answer]]
^fr-Q0759

**fr-Q0760 · Build the sentence**

Arrange: les / saints. / des / fait, / faisaient / on / nous / tous / les / quand / Si / souffrir / serions / péchés

If sins made us suffer when we sinned, we'd all be saints.

[[French#^fr-Q0760-answer|Compare the answer]]
^fr-Q0760

**fr-Q0761 · Write a translation**

Write this in French: Don't take everything so literally.

[[French#^fr-Q0761-answer|Compare the answer]]
^fr-Q0761

**fr-Q0762 · Explain the grammar**

Ne prenez pas tout 【si】 littéralement.

Don't take everything so literally.

[[French#^fr-Q0762-answer|Compare the answer]]
^fr-Q0762

**fr-Q0763 · Fill the gap**

____ tu regardes cette vidéo, je suis mort.

If you're watching this video, I'm dead.

[[French#^fr-Q0763-answer|Compare the answer]]
^fr-Q0763

**fr-Q0764 · Choose the form**

____ tu regardes cette vidéo, je suis mort.

If you're watching this video, I'm dead.

Choices: parce que / Si / quand / bien que

[[French#^fr-Q0764-answer|Compare the answer]]
^fr-Q0764

**fr-Q0765 · Edit the changed sentence**

Cela me rend 【quand】 heureux.

It makes me so happy.

[[French#^fr-Q0765-answer|Compare the answer]]
^fr-Q0765

**fr-Q0766 · Build the sentence**

Arrange: rend / heureux. / Cela / me / si

It makes me so happy.

[[French#^fr-Q0766-answer|Compare the answer]]
^fr-Q0766

**fr-Q0767 · Write a translation**

Write this in French: If you want to stay here, you are welcome to.

[[French#^fr-Q0767-answer|Compare the answer]]
^fr-Q0767

**fr-Q0768 · Explain the grammar**

【Si】 vous voulez rester ici, vous êtes bienvenues.

If you want to stay here, you are welcome to.

[[French#^fr-Q0768-answer|Compare the answer]]
^fr-Q0768

**fr-Q0769 · Fill the gap**

____ ce n'avait été à cause de la tempête, je serais arrivée plus tôt.

If it hadn't been for the storm, I would've arrived sooner.

[[French#^fr-Q0769-answer|Compare the answer]]
^fr-Q0769

**fr-Q0770 · Choose the form**

____ ce n'avait été à cause de la tempête, je serais arrivée plus tôt.

If it hadn't been for the storm, I would've arrived sooner.

Choices: quand / parce que / Si / bien que

[[French#^fr-Q0770-answer|Compare the answer]]
^fr-Q0770

**fr-Q0771 · Edit the changed sentence**

Ils étaient 【quand】 intimidés qu'ils ne pouvaient bouger d'un pouce.

They were so frightened that they couldn't move an inch.

[[French#^fr-Q0771-answer|Compare the answer]]
^fr-Q0771

**fr-Q0772 · Build the sentence**

Arrange: pouvaient / étaient / ne / d'un / intimidés / si / bouger / pouce. / Ils / qu'ils

They were so frightened that they couldn't move an inch.

[[French#^fr-Q0772-answer|Compare the answer]]
^fr-Q0772

**fr-Q0773 · Write a translation**

Write this in French: If you are free, come around to see me.

[[French#^fr-Q0773-answer|Compare the answer]]
^fr-Q0773

**fr-Q0774 · Explain the grammar**

【Si】 vous êtes libre, passez me voir.

If you are free, come around to see me.

[[French#^fr-Q0774-answer|Compare the answer]]
^fr-Q0774

**fr-Q0775 · Fill the gap**

____ possible, j'aimerais te voir ce soir.

If possible, I'd like to meet you tonight.

[[French#^fr-Q0775-answer|Compare the answer]]
^fr-Q0775

**fr-Q0776 · Choose the form**

____ possible, j'aimerais te voir ce soir.

If possible, I'd like to meet you tonight.

Choices: quand / parce que / Si / bien que

[[French#^fr-Q0776-answer|Compare the answer]]
^fr-Q0776

**fr-Q0777 · Edit the changed sentence**

Pourquoi êtes-vous 【quand】 négative ?

Why are you being so negative?

[[French#^fr-Q0777-answer|Compare the answer]]
^fr-Q0777

**fr-Q0778 · Build the sentence**

Arrange: si / négative / Pourquoi / êtes-vous / ?

Why are you being so negative?

[[French#^fr-Q0778-answer|Compare the answer]]
^fr-Q0778

**fr-Q0779 · Write a translation**

Write this in French: And what if I say "no"?

[[French#^fr-Q0779-answer|Compare the answer]]
^fr-Q0779

**fr-Q0780 · Explain the grammar**

Et qu'en est-il, 【si】 je dis « non » ?

And what if I say "no"?

[[French#^fr-Q0780-answer|Compare the answer]]
^fr-Q0780

**fr-Q0781 · Fill the gap**

Je vous présente mes excuses, ____ je vous ai offensés.

I apologize if I offended you.

[[French#^fr-Q0781-answer|Compare the answer]]
^fr-Q0781

**fr-Q0782 · Choose the form**

Je vous présente mes excuses, ____ je vous ai offensés.

I apologize if I offended you.

Choices: bien que / quand / parce que / si

[[French#^fr-Q0782-answer|Compare the answer]]
^fr-Q0782

**fr-Q0783 · Edit the changed sentence**

Tom avait l'air 【quand】 pauvre et si triste.

Tom seemed so poor and so sad.

[[French#^fr-Q0783-answer|Compare the answer]]
^fr-Q0783

**fr-Q0784 · Build the sentence**

Arrange: avait / si / pauvre / et / triste. / Tom / l'air / si

Tom seemed so poor and so sad.

[[French#^fr-Q0784-answer|Compare the answer]]
^fr-Q0784

**fr-Q0785 · Write a translation**

Write this in French: Don't be so careless!

[[French#^fr-Q0785-answer|Compare the answer]]
^fr-Q0785

**fr-Q0786 · Explain the grammar**

Ne soyez pas 【si】 négligents !

Don't be so careless!

[[French#^fr-Q0786-answer|Compare the answer]]
^fr-Q0786

**fr-Q0787 · Fill the gap**

Il y a seulement quelques jours, nous étions ____ heureux.

Just a few days ago, we were so happy.

[[French#^fr-Q0787-answer|Compare the answer]]
^fr-Q0787

**fr-Q0788 · Choose the form**

Il y a seulement quelques jours, nous étions ____ heureux.

Just a few days ago, we were so happy.

Choices: bien que / si / quand / parce que

[[French#^fr-Q0788-answer|Compare the answer]]
^fr-Q0788

**fr-Q0789 · Edit the changed sentence**

【quand】 tu veux réussir dans la vie, tu dois travailler dur.

If you would succeed in life, you must work hard.

[[French#^fr-Q0789-answer|Compare the answer]]
^fr-Q0789

**fr-Q0790 · Build the sentence**

Arrange: réussir / dur. / dois / travailler / tu / dans / Si / la / veux / tu / vie,

If you would succeed in life, you must work hard.

[[French#^fr-Q0790-answer|Compare the answer]]
^fr-Q0790

**fr-Q0791 · Write a translation**

Write this in French: How did you get here so fast?

[[French#^fr-Q0791-answer|Compare the answer]]
^fr-Q0791

**fr-Q0792 · Explain the grammar**

Comment es-tu arrivé ici 【si】 rapidement ?

How did you get here so fast?

[[French#^fr-Q0792-answer|Compare the answer]]
^fr-Q0792

**fr-Q0793 · Fill the gap**

C’est pratique d’habiter ____ près de la station.

It's convenient living so close to the station.

[[French#^fr-Q0793-answer|Compare the answer]]
^fr-Q0793

**fr-Q0794 · Choose the form**

C’est pratique d’habiter ____ près de la station.

It's convenient living so close to the station.

Choices: bien que / parce que / quand / si

[[French#^fr-Q0794-answer|Compare the answer]]
^fr-Q0794

**fr-Q0795 · Edit the changed sentence**

Pourquoi réfléchissez-vous 【quand】 longtemps ?

Why are you thinking so long?

[[French#^fr-Q0795-answer|Compare the answer]]
^fr-Q0795

**fr-Q0796 · Build the sentence**

Arrange: longtemps / réfléchissez-vous / ? / Pourquoi / si

Why are you thinking so long?

[[French#^fr-Q0796-answer|Compare the answer]]
^fr-Q0796

**fr-Q0797 · Write a translation**

Write this in French: She's got such lovely eyes.

[[French#^fr-Q0797-answer|Compare the answer]]
^fr-Q0797

**fr-Q0798 · Explain the grammar**

Elle a de 【si】 beaux yeux.

She's got such lovely eyes.

[[French#^fr-Q0798-answer|Compare the answer]]
^fr-Q0798

**fr-Q0799 · Fill the gap**

Je me demande pourquoi Tom est ____ maigre.

I wonder why Tom is so skinny.

[[French#^fr-Q0799-answer|Compare the answer]]
^fr-Q0799

**fr-Q0800 · Choose the form**

Je me demande pourquoi Tom est ____ maigre.

I wonder why Tom is so skinny.

Choices: quand / parce que / bien que / si

[[French#^fr-Q0800-answer|Compare the answer]]
^fr-Q0800


### Cause and concession · 50 questions

**fr-Q0801 · Edit the changed sentence**

Tu ne connais pas Tom aussi 【parce que】 moi.

You don't know Tom as well as I do.

[[French#^fr-Q0801-answer|Compare the answer]]
^fr-Q0801

**fr-Q0802 · Build the sentence**

Arrange: ne / moi. / connais / pas / bien / que / aussi / Tu / Tom

You don't know Tom as well as I do.

[[French#^fr-Q0802-answer|Compare the answer]]
^fr-Q0802

**fr-Q0803 · Write a translation**

Write this in French: I don't speak English well even though I took it for six years at school.

[[French#^fr-Q0803-answer|Compare the answer]]
^fr-Q0803

**fr-Q0804 · Explain the grammar**

Je ne parle pas bien l'anglais, 【bien que】 je l'aie étudié six ans à l'école.

I don't speak English well even though I took it for six years at school.

[[French#^fr-Q0804-answer|Compare the answer]]
^fr-Q0804

**fr-Q0805 · Fill the gap**

Garde tes distances ____ j'ai un mauvais rhume.

Keep away from me because I have a bad cold.

[[French#^fr-Q0805-answer|Compare the answer]]
^fr-Q0805

**fr-Q0806 · Choose the form**

Garde tes distances ____ j'ai un mauvais rhume.

Keep away from me because I have a bad cold.

Choices: bien que / puisque / parce que / pourtant

[[French#^fr-Q0806-answer|Compare the answer]]
^fr-Q0806

**fr-Q0807 · Edit the changed sentence**

【parce que】, la quantité n'était pas correcte.

However, the quantity was not correct.

[[French#^fr-Q0807-answer|Compare the answer]]
^fr-Q0807

**fr-Q0808 · Build the sentence**

Arrange: pas / correcte. / n'était / la / Cependant, / quantité

However, the quantity was not correct.

[[French#^fr-Q0808-answer|Compare the answer]]
^fr-Q0808

**fr-Q0809 · Write a translation**

Write this in French: I became a Catholic because I'm extremely pessimistic.

[[French#^fr-Q0809-answer|Compare the answer]]
^fr-Q0809

**fr-Q0810 · Explain the grammar**

Je suis devenu catholique 【parce que】 je suis extrêmement pessimiste.

I became a Catholic because I'm extremely pessimistic.

[[French#^fr-Q0810-answer|Compare the answer]]
^fr-Q0810

**fr-Q0811 · Fill the gap**

« Pourquoi l'avez-vous fait ? » « ____ je le peux. »

"Why did you do it?" "Because I can."

[[French#^fr-Q0811-answer|Compare the answer]]
^fr-Q0811

**fr-Q0812 · Choose the form**

« Pourquoi l'avez-vous fait ? » « ____ je le peux. »

"Why did you do it?" "Because I can."

Choices: bien que / puisque / pourtant / Parce que

[[French#^fr-Q0812-answer|Compare the answer]]
^fr-Q0812

**fr-Q0813 · Edit the changed sentence**

C'est 【puisque】 la lumière voyage plus vite que le son que nous voyons l'éclair avant d'entendre le tonnerre.

It is because light travels faster than sound that we see lightning before we hear thunder.

[[French#^fr-Q0813-answer|Compare the answer]]
^fr-Q0813

**fr-Q0814 · Build the sentence**

Arrange: parce / que / nous / plus / tonnerre. / voyons / l'éclair / que / voyage / son / vite / lumière / le / avant / que / C'est / la / le / d'entendre

It is because light travels faster than sound that we see lightning before we hear thunder.

[[French#^fr-Q0814-answer|Compare the answer]]
^fr-Q0814

**fr-Q0815 · Write a translation**

Write this in French: Because my husband has been admitted to hospital, I am writing on his behalf.

[[French#^fr-Q0815-answer|Compare the answer]]
^fr-Q0815

**fr-Q0816 · Explain the grammar**

【Puisque】 mon époux a été admis à l'hôpital, j'écris en son nom.

Because my husband has been admitted to hospital, I am writing on his behalf.

[[French#^fr-Q0816-answer|Compare the answer]]
^fr-Q0816

**fr-Q0817 · Fill the gap**

C'est stable ____ toutes les racines de cette équation sont négatives.

It's stable because all the roots of this equation are negative.

[[French#^fr-Q0817-answer|Compare the answer]]
^fr-Q0817

**fr-Q0818 · Choose the form**

C'est stable ____ toutes les racines de cette équation sont négatives.

It's stable because all the roots of this equation are negative.

Choices: bien que / parce que / puisque / pourtant

[[French#^fr-Q0818-answer|Compare the answer]]
^fr-Q0818

**fr-Q0819 · Edit the changed sentence**

Elle a grandi au bord de la mer, et 【parce que】 elle a horreur de nager.

She grew up near the sea, yet she hates swimming.

[[French#^fr-Q0819-answer|Compare the answer]]
^fr-Q0819

**fr-Q0820 · Build the sentence**

Arrange: la / mer, / de / de / elle / grandi / Elle / et / pourtant / au / a / bord / nager. / horreur / a

She grew up near the sea, yet she hates swimming.

[[French#^fr-Q0820-answer|Compare the answer]]
^fr-Q0820

**fr-Q0821 · Write a translation**

Write this in French: Since you have nothing to do with this matter, you don't have to worry.

[[French#^fr-Q0821-answer|Compare the answer]]
^fr-Q0821

**fr-Q0822 · Explain the grammar**

【Puisque】 tu n'as rien à voir avec cette affaire, tu ne dois pas te faire de souci.

Since you have nothing to do with this matter, you don't have to worry.

[[French#^fr-Q0822-answer|Compare the answer]]
^fr-Q0822

**fr-Q0823 · Fill the gap**

Tom n'aime pas Mary. ____, elle ne se soucie pas particulièrement de savoir si il l'aime ou non.

Tom doesn't like Mary. However, she doesn't particularly care whether he likes her or not.

[[French#^fr-Q0823-answer|Compare the answer]]
^fr-Q0823

**fr-Q0824 · Choose the form**

Tom n'aime pas Mary. ____, elle ne se soucie pas particulièrement de savoir si il l'aime ou non.

Tom doesn't like Mary. However, she doesn't particularly care whether he likes her or not.

Choices: puisque / bien que / Cependant / parce que

[[French#^fr-Q0824-answer|Compare the answer]]
^fr-Q0824

**fr-Q0825 · Edit the changed sentence**

【parce que】, je te demande de ne pas faire les mêmes erreurs que moi.

However, I ask you not to make the same mistakes that I did.

[[French#^fr-Q0825-answer|Compare the answer]]
^fr-Q0825

**fr-Q0826 · Build the sentence**

Arrange: les / demande / faire / pas / je / que / erreurs / mêmes / ne / de / Cependant, / te / moi.

However, I ask you not to make the same mistakes that I did.

[[French#^fr-Q0826-answer|Compare the answer]]
^fr-Q0826

**fr-Q0827 · Write a translation**

Write this in French: You know as well as I do that Tom isn't a very good singer.

[[French#^fr-Q0827-answer|Compare the answer]]
^fr-Q0827

**fr-Q0828 · Explain the grammar**

Vous savez aussi 【bien que】 moi que Tom n'est pas un très bon chanteur.

You know as well as I do that Tom isn't a very good singer.

[[French#^fr-Q0828-answer|Compare the answer]]
^fr-Q0828

**fr-Q0829 · Fill the gap**

____ je fusse épuisé, je continuais à travailler.

Although I was exhausted, I continued to work.

[[French#^fr-Q0829-answer|Compare the answer]]
^fr-Q0829

**fr-Q0830 · Choose the form**

____ je fusse épuisé, je continuais à travailler.

Although I was exhausted, I continued to work.

Choices: puisque / Bien que / parce que / pourtant

[[French#^fr-Q0830-answer|Compare the answer]]
^fr-Q0830

**fr-Q0831 · Edit the changed sentence**

C'est un mensonge, 【puisque】 son stylo n'était pas sous la table.

It's a lie, because his pen was not under the table.

[[French#^fr-Q0831-answer|Compare the answer]]
^fr-Q0831

**fr-Q0832 · Build the sentence**

Arrange: table. / C'est / son / stylo / que / la / un / mensonge, / parce / sous / pas / n'était

It's a lie, because his pen was not under the table.

[[French#^fr-Q0832-answer|Compare the answer]]
^fr-Q0832

**fr-Q0833 · Write a translation**

Write this in French: He's my uncle, because my father is his brother.

[[French#^fr-Q0833-answer|Compare the answer]]
^fr-Q0833

**fr-Q0834 · Explain the grammar**

Il est mon oncle, 【parce que】 mon père est son frère.

He's my uncle, because my father is his brother.

[[French#^fr-Q0834-answer|Compare the answer]]
^fr-Q0834

**fr-Q0835 · Fill the gap**

Je t'avais ____ dit de rester dans la voiture.

I did tell you to stay in the car.

[[French#^fr-Q0835-answer|Compare the answer]]
^fr-Q0835

**fr-Q0836 · Choose the form**

Je t'avais ____ dit de rester dans la voiture.

I did tell you to stay in the car.

Choices: puisque / parce que / bien que / pourtant

[[French#^fr-Q0836-answer|Compare the answer]]
^fr-Q0836

**fr-Q0837 · Edit the changed sentence**

Comme la Chine est un pays en voie de développement, certains aspects ne sont pas aussi 【parce que】 les pays occidentaux.

Because it's a developing country, some aspects of China aren't as good as those in Western countries.

[[French#^fr-Q0837-answer|Compare the answer]]
^fr-Q0837

**fr-Q0838 · Build the sentence**

Arrange: un / aussi / aspects / Chine / Comme / bien / développement, / sont / de / pas / que / pays / certains / la / voie / les / est / ne / pays / occidentaux. / en

Because it's a developing country, some aspects of China aren't as good as those in Western countries.

[[French#^fr-Q0838-answer|Compare the answer]]
^fr-Q0838

**fr-Q0839 · Write a translation**

Write this in French: The Algerian state does not respect human rights yet it has signed the charter.

[[French#^fr-Q0839-answer|Compare the answer]]
^fr-Q0839

**fr-Q0840 · Explain the grammar**

L'État algérien ne respecte pas les droits de l'homme 【pourtant】 il a signé la charte.

The Algerian state does not respect human rights yet it has signed the charter.

[[French#^fr-Q0840-answer|Compare the answer]]
^fr-Q0840

**fr-Q0841 · Fill the gap**

Je dois acheter des pâtes sans gluten ____ mon amie vient manger.

I have to buy gluten-free pasta because my friend is coming over to eat.

[[French#^fr-Q0841-answer|Compare the answer]]
^fr-Q0841

**fr-Q0842 · Choose the form**

Je dois acheter des pâtes sans gluten ____ mon amie vient manger.

I have to buy gluten-free pasta because my friend is coming over to eat.

Choices: pourtant / puisque / bien que / parce que

[[French#^fr-Q0842-answer|Compare the answer]]
^fr-Q0842

**fr-Q0843 · Edit the changed sentence**

La mort d'un homme de talent m'attriste toujours, 【parce que】 le monde en a plus besoin que le ciel.

The death of a talented man always saddens me, as the world needs them more than heaven does.

[[French#^fr-Q0843-answer|Compare the answer]]
^fr-Q0843

**fr-Q0844 · Build the sentence**

Arrange: m'attriste / d'un / besoin / le / ciel. / a / La / toujours, / que / puisque / homme / plus / de / mort / talent / le / en / monde

The death of a talented man always saddens me, as the world needs them more than heaven does.

[[French#^fr-Q0844-answer|Compare the answer]]
^fr-Q0844

**fr-Q0845 · Write a translation**

Write this in French: I was bored because I had seen the movie before.

[[French#^fr-Q0845-answer|Compare the answer]]
^fr-Q0845

**fr-Q0846 · Explain the grammar**

Je m'ennuyais 【parce que】 j'avais déjà vu le film.

I was bored because I had seen the movie before.

[[French#^fr-Q0846-answer|Compare the answer]]
^fr-Q0846

**fr-Q0847 · Fill the gap**

Tu n'arrives pas à fermer cette valise ____ tu as mis trop de choses dedans.

You can't get the suitcase closed because you've stuffed too much into it.

[[French#^fr-Q0847-answer|Compare the answer]]
^fr-Q0847

**fr-Q0848 · Choose the form**

Tu n'arrives pas à fermer cette valise ____ tu as mis trop de choses dedans.

You can't get the suitcase closed because you've stuffed too much into it.

Choices: pourtant / puisque / parce que / bien que

[[French#^fr-Q0848-answer|Compare the answer]]
^fr-Q0848

**fr-Q0849 · Edit the changed sentence**

Je pense que c'est 【parce que】 les livres existent encore, mais ils me donnent bien envie de dormir.

I think it is good that books still exist, but they do make me sleepy.

[[French#^fr-Q0849-answer|Compare the answer]]
^fr-Q0849

**fr-Q0850 · Build the sentence**

Arrange: de / bien / dormir. / encore, / existent / que / mais / les / pense / bien / envie / donnent / c'est / que / ils / livres / me / Je

I think it is good that books still exist, but they do make me sleepy.

[[French#^fr-Q0850-answer|Compare the answer]]
^fr-Q0850


### Causative faire · 50 questions

**fr-Q0851 · Write a translation**

Write this in French: Make your move.

[[French#^fr-Q0851-answer|Compare the answer]]
^fr-Q0851

**fr-Q0852 · Explain the grammar**

【Fais】 ton déplacement.

Make your move.

[[French#^fr-Q0852-answer|Compare the answer]]
^fr-Q0852

**fr-Q0853 · Fill the gap**

N'importe quel enfant peut ____ cela.

Any child can do that.

[[French#^fr-Q0853-answer|Compare the answer]]
^fr-Q0853

**fr-Q0854 · Choose the form**

N'importe quel enfant peut ____ cela.

Any child can do that.

Choices: faire / fais / font / fait

[[French#^fr-Q0854-answer|Compare the answer]]
^fr-Q0854

**fr-Q0855 · Edit the changed sentence**

J'ai envie de te 【fait】 un câlin.

I want to give you a hug.

[[French#^fr-Q0855-answer|Compare the answer]]
^fr-Q0855

**fr-Q0856 · Build the sentence**

Arrange: envie / de / câlin. / te / un / faire / J'ai

I want to give you a hug.

[[French#^fr-Q0856-answer|Compare the answer]]
^fr-Q0856

**fr-Q0857 · Write a translation**

Write this in French: I should call the police and have you arrested.

[[French#^fr-Q0857-answer|Compare the answer]]
^fr-Q0857

**fr-Q0858 · Explain the grammar**

Je devrais appeler la police et te 【faire】 arrêter.

I should call the police and have you arrested.

[[French#^fr-Q0858-answer|Compare the answer]]
^fr-Q0858

**fr-Q0859 · Fill the gap**

Pour ____ de l'exercice, je nage dans la piscine chaque semaine.

To exercise, I swim in the pool every week.

[[French#^fr-Q0859-answer|Compare the answer]]
^fr-Q0859

**fr-Q0860 · Choose the form**

Pour ____ de l'exercice, je nage dans la piscine chaque semaine.

To exercise, I swim in the pool every week.

Choices: fais / fait / font / faire

[[French#^fr-Q0860-answer|Compare the answer]]
^fr-Q0860

**fr-Q0861 · Edit the changed sentence**

Je ne pense pas que nous avons besoin de 【fait】 cela.

I don't think we need to do that.

[[French#^fr-Q0861-answer|Compare the answer]]
^fr-Q0861

**fr-Q0862 · Build the sentence**

Arrange: pas / pense / besoin / Je / faire / que / cela. / avons / de / ne / nous

I don't think we need to do that.

[[French#^fr-Q0862-answer|Compare the answer]]
^fr-Q0862

**fr-Q0863 · Write a translation**

Write this in French: You probably won't be able to do that.

[[French#^fr-Q0863-answer|Compare the answer]]
^fr-Q0863

**fr-Q0864 · Explain the grammar**

Vous ne pourrez probablement pas 【faire】 cela.

You probably won't be able to do that.

[[French#^fr-Q0864-answer|Compare the answer]]
^fr-Q0864

**fr-Q0865 · Fill the gap**

Tu devrais vraiment dire à Tom de ne pas le ____.

You should really tell Tom not to do that.

[[French#^fr-Q0865-answer|Compare the answer]]
^fr-Q0865

**fr-Q0866 · Choose the form**

Tu devrais vraiment dire à Tom de ne pas le ____.

You should really tell Tom not to do that.

Choices: fais / fait / faire / font

[[French#^fr-Q0866-answer|Compare the answer]]
^fr-Q0866

**fr-Q0867 · Edit the changed sentence**

Nous n'aurions vraiment pas dû 【fait】 ça.

We really shouldn't have done that.

[[French#^fr-Q0867-answer|Compare the answer]]
^fr-Q0867

**fr-Q0868 · Build the sentence**

Arrange: ça. / pas / Nous / faire / dû / n'aurions / vraiment

We really shouldn't have done that.

[[French#^fr-Q0868-answer|Compare the answer]]
^fr-Q0868

**fr-Q0869 · Write a translation**

Write this in French: I ought to do this by myself.

[[French#^fr-Q0869-answer|Compare the answer]]
^fr-Q0869

**fr-Q0870 · Explain the grammar**

Je devrais 【faire】 ça par mes propres moyens.

I ought to do this by myself.

[[French#^fr-Q0870-answer|Compare the answer]]
^fr-Q0870

**fr-Q0871 · Fill the gap**

C'est le genre d'homme qui ne ____ rien avec modération, mais va toujours à l'extrême.

He is the kind of man who cannot do anything in moderation, but always goes to extremes.

[[French#^fr-Q0871-answer|Compare the answer]]
^fr-Q0871

**fr-Q0872 · Choose the form**

C'est le genre d'homme qui ne ____ rien avec modération, mais va toujours à l'extrême.

He is the kind of man who cannot do anything in moderation, but always goes to extremes.

Choices: fait / font / fais / faire

[[French#^fr-Q0872-answer|Compare the answer]]
^fr-Q0872

**fr-Q0873 · Edit the changed sentence**

Il s'est 【faire】 catholique.

He became a Catholic.

[[French#^fr-Q0873-answer|Compare the answer]]
^fr-Q0873

**fr-Q0874 · Build the sentence**

Arrange: Il / catholique. / s'est / fait

He became a Catholic.

[[French#^fr-Q0874-answer|Compare the answer]]
^fr-Q0874

**fr-Q0875 · Write a translation**

Write this in French: Talk less, do more.

[[French#^fr-Q0875-answer|Compare the answer]]
^fr-Q0875

**fr-Q0876 · Explain the grammar**

Parle moins et 【fais】-en plus.

Talk less, do more.

[[French#^fr-Q0876-answer|Compare the answer]]
^fr-Q0876

**fr-Q0877 · Fill the gap**

Comment on ____ du compost ?

How do you make compost?

[[French#^fr-Q0877-answer|Compare the answer]]
^fr-Q0877

**fr-Q0878 · Choose the form**

Comment on ____ du compost ?

How do you make compost?

Choices: font / fait / fais / faire

[[French#^fr-Q0878-answer|Compare the answer]]
^fr-Q0878

**fr-Q0879 · Edit the changed sentence**

Pourquoi te 【faire】-tu du souci à propos de quelque chose qui n'a pas tant d'importance ?

Why are you worrying about something that doesn't matter so much?

[[French#^fr-Q0879-answer|Compare the answer]]
^fr-Q0879

**fr-Q0880 · Build the sentence**

Arrange: tant / qui / souci / d'importance / Pourquoi / du / chose / propos / ? / de / quelque / pas / fais-tu / à / n'a / te

Why are you worrying about something that doesn't matter so much?

[[French#^fr-Q0880-answer|Compare the answer]]
^fr-Q0880

**fr-Q0881 · Write a translation**

Write this in French: We should do something about that.

[[French#^fr-Q0881-answer|Compare the answer]]
^fr-Q0881

**fr-Q0882 · Explain the grammar**

Nous devrions 【faire】 quelque chose pour ça.

We should do something about that.

[[French#^fr-Q0882-answer|Compare the answer]]
^fr-Q0882

**fr-Q0883 · Fill the gap**

Marie ____ beaucoup plus jeune que son âge.

Mary looks much younger than she really is.

[[French#^fr-Q0883-answer|Compare the answer]]
^fr-Q0883

**fr-Q0884 · Choose the form**

Marie ____ beaucoup plus jeune que son âge.

Mary looks much younger than she really is.

Choices: fais / fait / font / faire

[[French#^fr-Q0884-answer|Compare the answer]]
^fr-Q0884

**fr-Q0885 · Edit the changed sentence**

Il m'a 【faire】 attendre longtemps.

He kept me waiting for a long time.

[[French#^fr-Q0885-answer|Compare the answer]]
^fr-Q0885

**fr-Q0886 · Build the sentence**

Arrange: m'a / attendre / Il / longtemps. / fait

He kept me waiting for a long time.

[[French#^fr-Q0886-answer|Compare the answer]]
^fr-Q0886

**fr-Q0887 · Write a translation**

Write this in French: You probably could've done that better.

[[French#^fr-Q0887-answer|Compare the answer]]
^fr-Q0887

**fr-Q0888 · Explain the grammar**

Vous auriez probablement pu 【faire】 cela mieux.

You probably could've done that better.

[[French#^fr-Q0888-answer|Compare the answer]]
^fr-Q0888

**fr-Q0889 · Fill the gap**

Premièrement, parlons de ce que Tom a ____.

First, let's talk about what Tom did.

[[French#^fr-Q0889-answer|Compare the answer]]
^fr-Q0889

**fr-Q0890 · Choose the form**

Premièrement, parlons de ce que Tom a ____.

First, let's talk about what Tom did.

Choices: font / fait / faire / fais

[[French#^fr-Q0890-answer|Compare the answer]]
^fr-Q0890

**fr-Q0891 · Edit the changed sentence**

Je sais tout ce que vous avez 【faire】.

I know everything that you've done.

[[French#^fr-Q0891-answer|Compare the answer]]
^fr-Q0891

**fr-Q0892 · Build the sentence**

Arrange: Je / sais / ce / avez / tout / que / vous / fait.

I know everything that you've done.

[[French#^fr-Q0892-answer|Compare the answer]]
^fr-Q0892

**fr-Q0893 · Write a translation**

Write this in French: What have you done with your car?

[[French#^fr-Q0893-answer|Compare the answer]]
^fr-Q0893

**fr-Q0894 · Explain the grammar**

Qu'avez-vous 【fait】 de votre voiture ?

What have you done with your car?

[[French#^fr-Q0894-answer|Compare the answer]]
^fr-Q0894

**fr-Q0895 · Fill the gap**

Je n'ai rien ____ à Tom.

I didn't do anything to Tom.

[[French#^fr-Q0895-answer|Compare the answer]]
^fr-Q0895

**fr-Q0896 · Choose the form**

Je n'ai rien ____ à Tom.

I didn't do anything to Tom.

Choices: faire / fait / fais / font

[[French#^fr-Q0896-answer|Compare the answer]]
^fr-Q0896

**fr-Q0897 · Edit the changed sentence**

Il 【faire】 froid là-dedans.

It's cold in here.

[[French#^fr-Q0897-answer|Compare the answer]]
^fr-Q0897

**fr-Q0898 · Build the sentence**

Arrange: fait / Il / froid / là-dedans.

It's cold in here.

[[French#^fr-Q0898-answer|Compare the answer]]
^fr-Q0898

**fr-Q0899 · Write a translation**

Write this in French: How long ago was that?

[[French#^fr-Q0899-answer|Compare the answer]]
^fr-Q0899

**fr-Q0900 · Explain the grammar**

Combien de temps cela 【fait】-il ?

How long ago was that?

[[French#^fr-Q0900-answer|Compare the answer]]
^fr-Q0900


### Adjective agreement · 50 questions

**fr-Q0901 · Fill the gap**

Est-ce ta ____ copine ?

Is this your girlfriend?

[[French#^fr-Q0901-answer|Compare the answer]]
^fr-Q0901

**fr-Q0902 · Choose the form**

Est-ce ta ____ copine ?

Is this your girlfriend?

Choices: petits / petites / petit / petite

[[French#^fr-Q0902-answer|Compare the answer]]
^fr-Q0902

**fr-Q0903 · Edit the changed sentence**

Ma mère m'a acheté un 【petit】 vélo.

Mother bought me a new bicycle.

[[French#^fr-Q0903-answer|Compare the answer]]
^fr-Q0903

**fr-Q0904 · Build the sentence**

Arrange: mère / Ma / nouveau / acheté / m'a / vélo. / un

Mother bought me a new bicycle.

[[French#^fr-Q0904-answer|Compare the answer]]
^fr-Q0904

**fr-Q0905 · Write a translation**

Write this in French: It's crowded again today.

[[French#^fr-Q0905-answer|Compare the answer]]
^fr-Q0905

**fr-Q0906 · Explain the grammar**

C'est de 【nouveau】 plein, aujourd'hui.

It's crowded again today.

[[French#^fr-Q0906-answer|Compare the answer]]
^fr-Q0906

**fr-Q0907 · Fill the gap**

Tu es trop ____ pour elle.

You're too good for her.

[[French#^fr-Q0907-answer|Compare the answer]]
^fr-Q0907

**fr-Q0908 · Choose the form**

Tu es trop ____ pour elle.

You're too good for her.

Choices: bon / petite / petits / petit

[[French#^fr-Q0908-answer|Compare the answer]]
^fr-Q0908

**fr-Q0909 · Edit the changed sentence**

Le 【petit】 plan a bien fonctionné.

The new plan has been very successful.

[[French#^fr-Q0909-answer|Compare the answer]]
^fr-Q0909

**fr-Q0910 · Build the sentence**

Arrange: Le / plan / a / bien / fonctionné. / nouveau

The new plan has been very successful.

[[French#^fr-Q0910-answer|Compare the answer]]
^fr-Q0910

**fr-Q0911 · Write a translation**

Write this in French: Keep an eye on the boys. They're mischievous.

[[French#^fr-Q0911-answer|Compare the answer]]
^fr-Q0911

**fr-Q0912 · Explain the grammar**

Garde un œil sur les garçons : ce sont des 【petits】 galopins.

Keep an eye on the boys. They're mischievous.

[[French#^fr-Q0912-answer|Compare the answer]]
^fr-Q0912

**fr-Q0913 · Fill the gap**

Ce ____ vaisseau spatial est plus de deux fois plus rapide que les vaisseaux spatiaux précédents.

This new spacecraft is over twice as fast as previous spaceships.

[[French#^fr-Q0913-answer|Compare the answer]]
^fr-Q0913

**fr-Q0914 · Choose the form**

Ce ____ vaisseau spatial est plus de deux fois plus rapide que les vaisseaux spatiaux précédents.

This new spacecraft is over twice as fast as previous spaceships.

Choices: nouveau / petite / petit / petits

[[French#^fr-Q0914-answer|Compare the answer]]
^fr-Q0914

**fr-Q0915 · Edit the changed sentence**

Mon ami a quitté sa 【petit】 copine et maintenant il veut sortir avec moi.

My friend broke up with his girlfriend and now he wants to go out with me.

[[French#^fr-Q0915-answer|Compare the answer]]
^fr-Q0915

**fr-Q0916 · Build the sentence**

Arrange: veut / moi. / Mon / et / quitté / sa / a / copine / il / avec / petite / sortir / maintenant / ami

My friend broke up with his girlfriend and now he wants to go out with me.

[[French#^fr-Q0916-answer|Compare the answer]]
^fr-Q0916

**fr-Q0917 · Write a translation**

Write this in French: The boss has a good opinion of your work.

[[French#^fr-Q0917-answer|Compare the answer]]
^fr-Q0917

**fr-Q0918 · Explain the grammar**

Le patron a une 【bonne】 opinion de votre travail.

The boss has a good opinion of your work.

[[French#^fr-Q0918-answer|Compare the answer]]
^fr-Q0918

**fr-Q0919 · Fill the gap**

Il a une ____ réputation.

He has a good reputation.

[[French#^fr-Q0919-answer|Compare the answer]]
^fr-Q0919

**fr-Q0920 · Choose the form**

Il a une ____ réputation.

He has a good reputation.

Choices: petite / bonne / petits / petit

[[French#^fr-Q0920-answer|Compare the answer]]
^fr-Q0920

**fr-Q0921 · Edit the changed sentence**

Un 【petit】 docteur est bien disposé à l'égard de ses patients.

A good doctor is sympathetic to his patients.

[[French#^fr-Q0921-answer|Compare the answer]]
^fr-Q0921

**fr-Q0922 · Build the sentence**

Arrange: docteur / Un / de / ses / est / bien / bon / disposé / patients. / à / l'égard

A good doctor is sympathetic to his patients.

[[French#^fr-Q0922-answer|Compare the answer]]
^fr-Q0922

**fr-Q0923 · Write a translation**

Write this in French: The book is new.

[[French#^fr-Q0923-answer|Compare the answer]]
^fr-Q0923

**fr-Q0924 · Explain the grammar**

Le livre est 【nouveau】.

The book is new.

[[French#^fr-Q0924-answer|Compare the answer]]
^fr-Q0924

**fr-Q0925 · Fill the gap**

Mon tout ____ frère dort dix heures par jour.

My baby brother sleeps ten hours a day.

[[French#^fr-Q0925-answer|Compare the answer]]
^fr-Q0925

**fr-Q0926 · Choose the form**

Mon tout ____ frère dort dix heures par jour.

My baby brother sleeps ten hours a day.

Choices: petits / petites / petite / petit

[[French#^fr-Q0926-answer|Compare the answer]]
^fr-Q0926

**fr-Q0927 · Edit the changed sentence**

Sami est un 【petit】 plongeur.

Sami is a good diver.

[[French#^fr-Q0927-answer|Compare the answer]]
^fr-Q0927

**fr-Q0928 · Build the sentence**

Arrange: bon / un / Sami / est / plongeur.

Sami is a good diver.

[[French#^fr-Q0928-answer|Compare the answer]]
^fr-Q0928

**fr-Q0929 · Write a translation**

Write this in French: You're a very good football player.

[[French#^fr-Q0929-answer|Compare the answer]]
^fr-Q0929

**fr-Q0930 · Explain the grammar**

Tu es un très 【bon】 footballeur.

You're a very good football player.

[[French#^fr-Q0930-answer|Compare the answer]]
^fr-Q0930

**fr-Q0931 · Fill the gap**

J'ai une ____ faveur à vous demander.

I have a small favor to ask of you.

[[French#^fr-Q0931-answer|Compare the answer]]
^fr-Q0931

**fr-Q0932 · Choose the form**

J'ai une ____ faveur à vous demander.

I have a small favor to ask of you.

Choices: petites / petits / petite / petit

[[French#^fr-Q0932-answer|Compare the answer]]
^fr-Q0932

**fr-Q0933 · Edit the changed sentence**

Ton téléphone sonne à 【petit】.

Your phone is ringing again.

[[French#^fr-Q0933-answer|Compare the answer]]
^fr-Q0933

**fr-Q0934 · Build the sentence**

Arrange: nouveau. / Ton / à / téléphone / sonne

Your phone is ringing again.

[[French#^fr-Q0934-answer|Compare the answer]]
^fr-Q0934

**fr-Q0935 · Write a translation**

Write this in French: Strange to say, he didn't know the news.

[[French#^fr-Q0935-answer|Compare the answer]]
^fr-Q0935

**fr-Q0936 · Explain the grammar**

C'est étrange à dire, mais il ne connaissait pas la 【nouvelle】.

Strange to say, he didn't know the news.

[[French#^fr-Q0936-answer|Compare the answer]]
^fr-Q0936

**fr-Q0937 · Fill the gap**

Elle a reçu un présent de son ____ copain.

She got a present from her boyfriend.

[[French#^fr-Q0937-answer|Compare the answer]]
^fr-Q0937

**fr-Q0938 · Choose the form**

Elle a reçu un présent de son ____ copain.

She got a present from her boyfriend.

Choices: petits / petit / petites / petite

[[French#^fr-Q0938-answer|Compare the answer]]
^fr-Q0938

**fr-Q0939 · Edit the changed sentence**

Elle est 【petit】 et grosse.

She's short and fat.

[[French#^fr-Q0939-answer|Compare the answer]]
^fr-Q0939

**fr-Q0940 · Build the sentence**

Arrange: Elle / petite / est / grosse. / et

She's short and fat.

[[French#^fr-Q0940-answer|Compare the answer]]
^fr-Q0940

**fr-Q0941 · Write a translation**

Write this in French: When the girl entered the room, some boys made fun of her because of her little hat.

[[French#^fr-Q0941-answer|Compare the answer]]
^fr-Q0941

**fr-Q0942 · Explain the grammar**

Quand la fille est entrée dans la pièce, certains garçons se sont moqués d'elle à cause de son 【petit】 chapeau.

When the girl entered the room, some boys made fun of her because of her little hat.

[[French#^fr-Q0942-answer|Compare the answer]]
^fr-Q0942

**fr-Q0943 · Fill the gap**

Je n'étais pas assez ____.

I wasn't good enough.

[[French#^fr-Q0943-answer|Compare the answer]]
^fr-Q0943

**fr-Q0944 · Choose the form**

Je n'étais pas assez ____.

I wasn't good enough.

Choices: petits / petit / petite / bonne

[[French#^fr-Q0944-answer|Compare the answer]]
^fr-Q0944

**fr-Q0945 · Edit the changed sentence**

Pour être grand, il faut avoir été 【petite】.

To be tall, you must have been small.

[[French#^fr-Q0945-answer|Compare the answer]]
^fr-Q0945

**fr-Q0946 · Build the sentence**

Arrange: avoir / Pour / faut / il / été / petit. / être / grand,

To be tall, you must have been small.

[[French#^fr-Q0946-answer|Compare the answer]]
^fr-Q0946

**fr-Q0947 · Write a translation**

Write this in French: You've got the wrong man!

[[French#^fr-Q0947-answer|Compare the answer]]
^fr-Q0947

**fr-Q0948 · Explain the grammar**

Vous n'avez pas le 【bon】 client !

You've got the wrong man!

[[French#^fr-Q0948-answer|Compare the answer]]
^fr-Q0948

**fr-Q0949 · Fill the gap**

Je suis une ____ enfant.

I'm a little child.

[[French#^fr-Q0949-answer|Compare the answer]]
^fr-Q0949

**fr-Q0950 · Choose the form**

Je suis une ____ enfant.

I'm a little child.

Choices: petits / petit / petites / petite

[[French#^fr-Q0950-answer|Compare the answer]]
^fr-Q0950


### Comparison · 50 questions

**fr-Q0951 · Edit the changed sentence**

Mon 【plus】 ami est mort asphyxié.

My best friend died of asphyxiation.

[[French#^fr-Q0951-answer|Compare the answer]]
^fr-Q0951

**fr-Q0952 · Build the sentence**

Arrange: Mon / meilleur / mort / asphyxié. / ami / est

My best friend died of asphyxiation.

[[French#^fr-Q0952-answer|Compare the answer]]
^fr-Q0952

**fr-Q0953 · Write a translation**

Write this in French: Tom is strong, but Mary is stronger.

[[French#^fr-Q0953-answer|Compare the answer]]
^fr-Q0953

**fr-Q0954 · Explain the grammar**

Tom est fort, mais Marie est 【plus】 forte.

Tom is strong, but Mary is stronger.

[[French#^fr-Q0954-answer|Compare the answer]]
^fr-Q0954

**fr-Q0955 · Fill the gap**

Un des ____ gros problèmes dans notre société moderne, c'est que les gens ne voient pas le monde comme moi.

One of the biggest problems in our modern society is that the people don't see the world as I do.

[[French#^fr-Q0955-answer|Compare the answer]]
^fr-Q0955

**fr-Q0956 · Choose the form**

Un des ____ gros problèmes dans notre société moderne, c'est que les gens ne voient pas le monde comme moi.

One of the biggest problems in our modern society is that the people don't see the world as I do.

Choices: aussi / moins / plus / meilleur

[[French#^fr-Q0956-answer|Compare the answer]]
^fr-Q0956

**fr-Q0957 · Edit the changed sentence**

Un peu 【moins】 fort, s'il te plait.

A little louder, please.

[[French#^fr-Q0957-answer|Compare the answer]]
^fr-Q0957

**fr-Q0958 · Build the sentence**

Arrange: plait. / Un / plus / s'il / peu / fort, / te

A little louder, please.

[[French#^fr-Q0958-answer|Compare the answer]]
^fr-Q0958

**fr-Q0959 · Write a translation**

Write this in French: Tom is taller than Dan but Tim is the tallest guy in the group.

[[French#^fr-Q0959-answer|Compare the answer]]
^fr-Q0959

**fr-Q0960 · Explain the grammar**

Tom est 【plus】 grand que Dan mais Tim est le garçon le plus grand dans le groupe.

Tom is taller than Dan but Tim is the tallest guy in the group.

[[French#^fr-Q0960-answer|Compare the answer]]
^fr-Q0960

**fr-Q0961 · Fill the gap**

La vôtre n'est pas mal non ____.

Yours is not bad, either.

[[French#^fr-Q0961-answer|Compare the answer]]
^fr-Q0961

**fr-Q0962 · Choose the form**

La vôtre n'est pas mal non ____.

Yours is not bad, either.

Choices: plus / moins / aussi / meilleur

[[French#^fr-Q0962-answer|Compare the answer]]
^fr-Q0962

**fr-Q0963 · Edit the changed sentence**

Un hochement de tête est 【plus】 utile qu'un clin d'œil à un cheval aveugle.

A nod is as good as a wink to a blind horse.

[[French#^fr-Q0963-answer|Compare the answer]]
^fr-Q0963

**fr-Q0964 · Build the sentence**

Arrange: tête / un / aveugle. / est / clin / hochement / cheval / d'œil / à / utile / aussi / de / qu'un / Un

A nod is as good as a wink to a blind horse.

[[French#^fr-Q0964-answer|Compare the answer]]
^fr-Q0964

**fr-Q0965 · Write a translation**

Write this in French: I haven't read his novel, and my brother hasn't either.

[[French#^fr-Q0965-answer|Compare the answer]]
^fr-Q0965

**fr-Q0966 · Explain the grammar**

Je n'ai pas lu son roman, et mon frère non 【plus】.

I haven't read his novel, and my brother hasn't either.

[[French#^fr-Q0966-answer|Compare the answer]]
^fr-Q0966

**fr-Q0967 · Fill the gap**

Je ne me rappelle ____ très bien.

I don't remember exactly.

[[French#^fr-Q0967-answer|Compare the answer]]
^fr-Q0967

**fr-Q0968 · Choose the form**

Je ne me rappelle ____ très bien.

I don't remember exactly.

Choices: meilleur / plus / moins / aussi

[[French#^fr-Q0968-answer|Compare the answer]]
^fr-Q0968

**fr-Q0969 · Edit the changed sentence**

Je t'aime 【plus】.

I love you, too.

[[French#^fr-Q0969-answer|Compare the answer]]
^fr-Q0969

**fr-Q0970 · Build the sentence**

Arrange: aussi. / t'aime / Je

I love you, too.

[[French#^fr-Q0970-answer|Compare the answer]]
^fr-Q0970

**fr-Q0971 · Write a translation**

Write this in French: Even night falls on the longest day of the year.

[[French#^fr-Q0971-answer|Compare the answer]]
^fr-Q0971

**fr-Q0972 · Explain the grammar**

Même pour le jour le 【plus】 long vient le soir.

Even night falls on the longest day of the year.

[[French#^fr-Q0972-answer|Compare the answer]]
^fr-Q0972

**fr-Q0973 · Fill the gap**

Une feuille de papier s'est coincée dans l'imprimante et depuis elle ne fonctionne ____.

A piece of paper got jammed in the printer and now it doesn't work.

[[French#^fr-Q0973-answer|Compare the answer]]
^fr-Q0973

**fr-Q0974 · Choose the form**

Une feuille de papier s'est coincée dans l'imprimante et depuis elle ne fonctionne ____.

A piece of paper got jammed in the printer and now it doesn't work.

Choices: aussi / meilleur / plus / moins

[[French#^fr-Q0974-answer|Compare the answer]]
^fr-Q0974

**fr-Q0975 · Edit the changed sentence**

Tu es un peu 【moins】 grande que moi.

You're a bit taller than I am.

[[French#^fr-Q0975-answer|Compare the answer]]
^fr-Q0975

**fr-Q0976 · Build the sentence**

Arrange: Tu / es / peu / que / moi. / un / plus / grande

You're a bit taller than I am.

[[French#^fr-Q0976-answer|Compare the answer]]
^fr-Q0976

**fr-Q0977 · Write a translation**

Write this in French: Can you also count in Italian?

[[French#^fr-Q0977-answer|Compare the answer]]
^fr-Q0977

**fr-Q0978 · Explain the grammar**

Sais-tu 【aussi】 compter en italien ?

Can you also count in Italian?

[[French#^fr-Q0978-answer|Compare the answer]]
^fr-Q0978

**fr-Q0979 · Fill the gap**

J'aimerai une couverture en ____.

I'd like one more blanket.

[[French#^fr-Q0979-answer|Compare the answer]]
^fr-Q0979

**fr-Q0980 · Choose the form**

J'aimerai une couverture en ____.

I'd like one more blanket.

Choices: plus / meilleur / aussi / moins

[[French#^fr-Q0980-answer|Compare the answer]]
^fr-Q0980

**fr-Q0981 · Edit the changed sentence**

Le fer est 【moins】 dur que l'or.

Iron is harder than gold.

[[French#^fr-Q0981-answer|Compare the answer]]
^fr-Q0981

**fr-Q0982 · Build the sentence**

Arrange: plus / que / fer / dur / est / l'or. / Le

Iron is harder than gold.

[[French#^fr-Q0982-answer|Compare the answer]]
^fr-Q0982

**fr-Q0983 · Write a translation**

Write this in French: Nothing is more important than compassion.

[[French#^fr-Q0983-answer|Compare the answer]]
^fr-Q0983

**fr-Q0984 · Explain the grammar**

Rien n'est 【plus】 important que la compassion.

Nothing is more important than compassion.

[[French#^fr-Q0984-answer|Compare the answer]]
^fr-Q0984

**fr-Q0985 · Fill the gap**

Aimez-vous mon frère ____ que moi ?

Do you love my brother more than me?

[[French#^fr-Q0985-answer|Compare the answer]]
^fr-Q0985

**fr-Q0986 · Choose the form**

Aimez-vous mon frère ____ que moi ?

Do you love my brother more than me?

Choices: meilleur / aussi / moins / plus

[[French#^fr-Q0986-answer|Compare the answer]]
^fr-Q0986

**fr-Q0987 · Edit the changed sentence**

Ce n'est pas l'aspect le 【moins】 important du conte.

That's not the most important facet of the tale.

[[French#^fr-Q0987-answer|Compare the answer]]
^fr-Q0987

**fr-Q0988 · Build the sentence**

Arrange: important / n'est / du / plus / conte. / pas / le / Ce / l'aspect

That's not the most important facet of the tale.

[[French#^fr-Q0988-answer|Compare the answer]]
^fr-Q0988

**fr-Q0989 · Write a translation**

Write this in French: I was unable to stand any longer.

[[French#^fr-Q0989-answer|Compare the answer]]
^fr-Q0989

**fr-Q0990 · Explain the grammar**

Je fus incapable de me tenir debout 【plus】 longtemps.

I was unable to stand any longer.

[[French#^fr-Q0990-answer|Compare the answer]]
^fr-Q0990

**fr-Q0991 · Fill the gap**

La solution la ____ simple est souvent la meilleure.

The simplest solution is often the best.

[[French#^fr-Q0991-answer|Compare the answer]]
^fr-Q0991

**fr-Q0992 · Choose the form**

La solution la ____ simple est souvent la meilleure.

The simplest solution is often the best.

Choices: meilleur / aussi / plus / moins

[[French#^fr-Q0992-answer|Compare the answer]]
^fr-Q0992

**fr-Q0993 · Edit the changed sentence**

Cela fait des siècles que l'argent a perdu sa matérialisation papier ou métallique. Ce n'est désormais 【moins】 que des chiffres dans l'ordinateur.

It's been centuries since money lost its paper and coin incarnations. They're just digits in the computer now.

[[French#^fr-Q0993-answer|Compare the answer]]
^fr-Q0993

**fr-Q0994 · Build the sentence**

Arrange: métallique. / des / sa / n'est / a / plus / siècles / désormais / chiffres / que / que / l'ordinateur. / des / ou / Cela / fait / matérialisation / perdu / dans / l'argent / papier / Ce

It's been centuries since money lost its paper and coin incarnations. They're just digits in the computer now.

[[French#^fr-Q0994-answer|Compare the answer]]
^fr-Q0994

**fr-Q0995 · Write a translation**

Write this in French: Which is the best hotel in the town?

[[French#^fr-Q0995-answer|Compare the answer]]
^fr-Q0995

**fr-Q0996 · Explain the grammar**

Quel est le 【meilleur】 hôtel de la ville ?

Which is the best hotel in the town?

[[French#^fr-Q0996-answer|Compare the answer]]
^fr-Q0996

**fr-Q0997 · Fill the gap**

Tom est ____ sage que moi.

Tom is wiser than me.

[[French#^fr-Q0997-answer|Compare the answer]]
^fr-Q0997

**fr-Q0998 · Choose the form**

Tom est ____ sage que moi.

Tom is wiser than me.

Choices: aussi / plus / moins / meilleur

[[French#^fr-Q0998-answer|Compare the answer]]
^fr-Q0998

**fr-Q0999 · Edit the changed sentence**

Ce dictionnaire est 【plus】 utile que le tien.

This dictionary is as useful as yours.

[[French#^fr-Q0999-answer|Compare the answer]]
^fr-Q0999

**fr-Q1000 · Build the sentence**

Arrange: le / aussi / est / dictionnaire / utile / tien. / Ce / que

This dictionary is as useful as yours.

[[French#^fr-Q1000-answer|Compare the answer]]
^fr-Q1000


## Answers

The full sentence is a model. For translation, judge whether meaning and grammar are preserved. Each grammar rule above explains the form.

### Answers 1–50

**fr-Q0001** — Il a été condamné à de la prison.

He was sentenced to prison.

Expected form: **la**

Why: Articles and gender. [[French#^fr-Q0001|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Il%20a%20%C3%A9t%C3%A9%20condamn%C3%A9%20%C3%A0%20de%20la%20prison.)
^fr-Q0001-answer

**fr-Q0002** — Il a été condamné à de la prison.

He was sentenced to prison.

Expected form: **la**

Why: Articles and gender. [[French#^fr-Q0002|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Il%20a%20%C3%A9t%C3%A9%20condamn%C3%A9%20%C3%A0%20de%20la%20prison.)
^fr-Q0002-answer

**fr-Q0003** — Il n'est qu'un homme d'affaires.

He is nothing but a businessman.

Expected form: **un**

Why: Articles and gender. [[French#^fr-Q0003|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Il%20n%27est%20qu%27un%20homme%20d%27affaires.)
^fr-Q0003-answer

**fr-Q0004** — Il n'est qu'un homme d'affaires.

He is nothing but a businessman.

Why: Articles and gender. [[French#^fr-Q0004|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Il%20n%27est%20qu%27un%20homme%20d%27affaires.)
^fr-Q0004-answer

**fr-Q0005** — C'est un très bon ami, mais il est un peu paresseux.

He is a very good friend, yet a little lazy.

Why: Articles and gender. [[French#^fr-Q0005|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=C%27est%20un%20tr%C3%A8s%20bon%20ami%2C%20mais%20il%20est%20un%20peu%20paresseux.)
^fr-Q0005-answer

**fr-Q0006** — C'est un très bon ami, mais il est un peu paresseux.

He is a very good friend, yet a little lazy.

Articles distinguish gender, number and reference. Le/la are singular definite forms and les is plural. Un/une introduce indefinite singular nouns. Learn each noun with its article; a translation rarely predicts gender.

Why: Articles and gender. [[French#^fr-Q0006|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=C%27est%20un%20tr%C3%A8s%20bon%20ami%2C%20mais%20il%20est%20un%20peu%20paresseux.)
^fr-Q0006-answer

**fr-Q0007** — Êtes-vous prêts pour le voyage ?

Are you ready for the trip?

Expected form: **le**

Why: Articles and gender. [[French#^fr-Q0007|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=%C3%8Ates-vous%20pr%C3%AAts%20pour%20le%20voyage%20%3F)
^fr-Q0007-answer

**fr-Q0008** — Êtes-vous prêts pour le voyage ?

Are you ready for the trip?

Expected form: **le**

Why: Articles and gender. [[French#^fr-Q0008|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=%C3%8Ates-vous%20pr%C3%AAts%20pour%20le%20voyage%20%3F)
^fr-Q0008-answer

**fr-Q0009** — Dans l'ouverture, ne déplacez que les pions qui aident à développer les pièces.

In the opening, move only those pawns that help develop the pieces.

Expected form: **les**

Why: Articles and gender. [[French#^fr-Q0009|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Dans%20l%27ouverture%2C%20ne%20d%C3%A9placez%20que%20les%20pions%20qui%20aident%20%C3%A0%20d%C3%A9velopper%20les%20pi%C3%A8ces.)
^fr-Q0009-answer

**fr-Q0010** — Dans l'ouverture, ne déplacez que les pions qui aident à développer les pièces.

In the opening, move only those pawns that help develop the pieces.

Why: Articles and gender. [[French#^fr-Q0010|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Dans%20l%27ouverture%2C%20ne%20d%C3%A9placez%20que%20les%20pions%20qui%20aident%20%C3%A0%20d%C3%A9velopper%20les%20pi%C3%A8ces.)
^fr-Q0010-answer

**fr-Q0011** — Les livres de cet étudiant sont neufs.

This student's books are new.

Why: Articles and gender. [[French#^fr-Q0011|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Les%20livres%20de%20cet%20%C3%A9tudiant%20sont%20neufs.)
^fr-Q0011-answer

**fr-Q0012** — Les livres de cet étudiant sont neufs.

This student's books are new.

Articles distinguish gender, number and reference. Le/la are singular definite forms and les is plural. Un/une introduce indefinite singular nouns. Learn each noun with its article; a translation rarely predicts gender.

Why: Articles and gender. [[French#^fr-Q0012|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Les%20livres%20de%20cet%20%C3%A9tudiant%20sont%20neufs.)
^fr-Q0012-answer

**fr-Q0013** — Les lacets de Tom sont défaits.

Tom's shoelaces are untied.

Expected form: **Les**

Why: Articles and gender. [[French#^fr-Q0013|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Les%20lacets%20de%20Tom%20sont%20d%C3%A9faits.)
^fr-Q0013-answer

**fr-Q0014** — Les lacets de Tom sont défaits.

Tom's shoelaces are untied.

Expected form: **Les**

Why: Articles and gender. [[French#^fr-Q0014|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Les%20lacets%20de%20Tom%20sont%20d%C3%A9faits.)
^fr-Q0014-answer

**fr-Q0015** — J'ai décidé d'acheter la voiture bleue.

I've decided to buy the blue car.

Expected form: **la**

Why: Articles and gender. [[French#^fr-Q0015|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=J%27ai%20d%C3%A9cid%C3%A9%20d%27acheter%20la%20voiture%20bleue.)
^fr-Q0015-answer

**fr-Q0016** — J'ai décidé d'acheter la voiture bleue.

I've decided to buy the blue car.

Why: Articles and gender. [[French#^fr-Q0016|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=J%27ai%20d%C3%A9cid%C3%A9%20d%27acheter%20la%20voiture%20bleue.)
^fr-Q0016-answer

**fr-Q0017** — Il s'est servi d'une fausse carte d'identité.

He used a fake I.D.

Why: Articles and gender. [[French#^fr-Q0017|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Il%20s%27est%20servi%20d%27une%20fausse%20carte%20d%27identit%C3%A9.)
^fr-Q0017-answer

**fr-Q0018** — Il s'est servi d'une fausse carte d'identité.

He used a fake I.D.

Articles distinguish gender, number and reference. Le/la are singular definite forms and les is plural. Un/une introduce indefinite singular nouns. Learn each noun with its article; a translation rarely predicts gender.

Why: Articles and gender. [[French#^fr-Q0018|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Il%20s%27est%20servi%20d%27une%20fausse%20carte%20d%27identit%C3%A9.)
^fr-Q0018-answer

**fr-Q0019** — Tout le monde doit être au courant.

Everybody must know.

Expected form: **le**

Why: Articles and gender. [[French#^fr-Q0019|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tout%20le%20monde%20doit%20%C3%AAtre%20au%20courant.)
^fr-Q0019-answer

**fr-Q0020** — Tout le monde doit être au courant.

Everybody must know.

Expected form: **le**

Why: Articles and gender. [[French#^fr-Q0020|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tout%20le%20monde%20doit%20%C3%AAtre%20au%20courant.)
^fr-Q0020-answer

**fr-Q0021** — Je me suis assis derrière une très grande personne au théâtre.

I sat behind a very tall person at the theater.

Expected form: **une**

Why: Articles and gender. [[French#^fr-Q0021|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20me%20suis%20assis%20derri%C3%A8re%20une%20tr%C3%A8s%20grande%20personne%20au%20th%C3%A9%C3%A2tre.)
^fr-Q0021-answer

**fr-Q0022** — Je me suis assis derrière une très grande personne au théâtre.

I sat behind a very tall person at the theater.

Why: Articles and gender. [[French#^fr-Q0022|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20me%20suis%20assis%20derri%C3%A8re%20une%20tr%C3%A8s%20grande%20personne%20au%20th%C3%A9%C3%A2tre.)
^fr-Q0022-answer

**fr-Q0023** — Mes pieds sont devenus des bâtons.

My legs feel heavy as lead.

Why: Articles and gender. [[French#^fr-Q0023|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Mes%20pieds%20sont%20devenus%20des%20b%C3%A2tons.)
^fr-Q0023-answer

**fr-Q0024** — Mes pieds sont devenus des bâtons.

My legs feel heavy as lead.

Articles distinguish gender, number and reference. Le/la are singular definite forms and les is plural. Un/une introduce indefinite singular nouns. Learn each noun with its article; a translation rarely predicts gender.

Why: Articles and gender. [[French#^fr-Q0024|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Mes%20pieds%20sont%20devenus%20des%20b%C3%A2tons.)
^fr-Q0024-answer

**fr-Q0025** — Sami n'est pas un génie.

Sami is not a genius.

Expected form: **un**

Why: Articles and gender. [[French#^fr-Q0025|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Sami%20n%27est%20pas%20un%20g%C3%A9nie.)
^fr-Q0025-answer

**fr-Q0026** — Sami n'est pas un génie.

Sami is not a genius.

Expected form: **un**

Why: Articles and gender. [[French#^fr-Q0026|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Sami%20n%27est%20pas%20un%20g%C3%A9nie.)
^fr-Q0026-answer

**fr-Q0027** — La rencontre d'athlétisme fut reportée à cause de la pluie.

The athletic meet was postponed due to rain.

Expected form: **La**

Why: Articles and gender. [[French#^fr-Q0027|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=La%20rencontre%20d%27athl%C3%A9tisme%20fut%20report%C3%A9e%20%C3%A0%20cause%20de%20la%20pluie.)
^fr-Q0027-answer

**fr-Q0028** — La rencontre d'athlétisme fut reportée à cause de la pluie.

The athletic meet was postponed due to rain.

Why: Articles and gender. [[French#^fr-Q0028|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=La%20rencontre%20d%27athl%C3%A9tisme%20fut%20report%C3%A9e%20%C3%A0%20cause%20de%20la%20pluie.)
^fr-Q0028-answer

**fr-Q0029** — Certains animaux peuvent sentir l'arrivée d'un orage.

Some animals can sense the coming of a storm.

Why: Articles and gender. [[French#^fr-Q0029|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Certains%20animaux%20peuvent%20sentir%20l%27arriv%C3%A9e%20d%27un%20orage.)
^fr-Q0029-answer

**fr-Q0030** — Certains animaux peuvent sentir l'arrivée d'un orage.

Some animals can sense the coming of a storm.

Articles distinguish gender, number and reference. Le/la are singular definite forms and les is plural. Un/une introduce indefinite singular nouns. Learn each noun with its article; a translation rarely predicts gender.

Why: Articles and gender. [[French#^fr-Q0030|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Certains%20animaux%20peuvent%20sentir%20l%27arriv%C3%A9e%20d%27un%20orage.)
^fr-Q0030-answer

**fr-Q0031** — La radio nous a averti d'un risque d'inondation.

The radio warned us of the possibility of flooding.

Expected form: **La**

Why: Articles and gender. [[French#^fr-Q0031|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=La%20radio%20nous%20a%20averti%20d%27un%20risque%20d%27inondation.)
^fr-Q0031-answer

**fr-Q0032** — La radio nous a averti d'un risque d'inondation.

The radio warned us of the possibility of flooding.

Expected form: **La**

Why: Articles and gender. [[French#^fr-Q0032|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=La%20radio%20nous%20a%20averti%20d%27un%20risque%20d%27inondation.)
^fr-Q0032-answer

**fr-Q0033** — Je le rencontre vendredi prochain.

I am meeting him next Friday.

Expected form: **le**

Why: Articles and gender. [[French#^fr-Q0033|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20le%20rencontre%20vendredi%20prochain.)
^fr-Q0033-answer

**fr-Q0034** — Je le rencontre vendredi prochain.

I am meeting him next Friday.

Why: Articles and gender. [[French#^fr-Q0034|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20le%20rencontre%20vendredi%20prochain.)
^fr-Q0034-answer

**fr-Q0035** — Je suis un chat.

I'm a cat.

Why: Articles and gender. [[French#^fr-Q0035|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20suis%20un%20chat.)
^fr-Q0035-answer

**fr-Q0036** — Je suis un chat.

I'm a cat.

Articles distinguish gender, number and reference. Le/la are singular definite forms and les is plural. Un/une introduce indefinite singular nouns. Learn each noun with its article; a translation rarely predicts gender.

Why: Articles and gender. [[French#^fr-Q0036|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20suis%20un%20chat.)
^fr-Q0036-answer

**fr-Q0037** — Êtes-vous en train de la draguer ?

Are you flirting with her?

Expected form: **la**

Why: Articles and gender. [[French#^fr-Q0037|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=%C3%8Ates-vous%20en%20train%20de%20la%20draguer%20%3F)
^fr-Q0037-answer

**fr-Q0038** — Êtes-vous en train de la draguer ?

Are you flirting with her?

Expected form: **la**

Why: Articles and gender. [[French#^fr-Q0038|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=%C3%8Ates-vous%20en%20train%20de%20la%20draguer%20%3F)
^fr-Q0038-answer

**fr-Q0039** — Mon père répare des chaises cassées.

My father fixes broken chairs.

Expected form: **des**

Why: Articles and gender. [[French#^fr-Q0039|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Mon%20p%C3%A8re%20r%C3%A9pare%20des%20chaises%20cass%C3%A9es.)
^fr-Q0039-answer

**fr-Q0040** — Mon père répare des chaises cassées.

My father fixes broken chairs.

Why: Articles and gender. [[French#^fr-Q0040|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Mon%20p%C3%A8re%20r%C3%A9pare%20des%20chaises%20cass%C3%A9es.)
^fr-Q0040-answer

**fr-Q0041** — Les gérondifs sont très amusants.

Gerunds are very funny.

Why: Articles and gender. [[French#^fr-Q0041|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Les%20g%C3%A9rondifs%20sont%20tr%C3%A8s%20amusants.)
^fr-Q0041-answer

**fr-Q0042** — Les gérondifs sont très amusants.

Gerunds are very funny.

Articles distinguish gender, number and reference. Le/la are singular definite forms and les is plural. Un/une introduce indefinite singular nouns. Learn each noun with its article; a translation rarely predicts gender.

Why: Articles and gender. [[French#^fr-Q0042|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Les%20g%C3%A9rondifs%20sont%20tr%C3%A8s%20amusants.)
^fr-Q0042-answer

**fr-Q0043** — Après avoir marché un moment, nous arrivâmes au lac.

After we walked for a while, we arrived at the lake.

Expected form: **un**

Why: Articles and gender. [[French#^fr-Q0043|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Apr%C3%A8s%20avoir%20march%C3%A9%20un%20moment%2C%20nous%20arriv%C3%A2mes%20au%20lac.)
^fr-Q0043-answer

**fr-Q0044** — Après avoir marché un moment, nous arrivâmes au lac.

After we walked for a while, we arrived at the lake.

Expected form: **un**

Why: Articles and gender. [[French#^fr-Q0044|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Apr%C3%A8s%20avoir%20march%C3%A9%20un%20moment%2C%20nous%20arriv%C3%A2mes%20au%20lac.)
^fr-Q0044-answer

**fr-Q0045** — As-tu déjà été trahi par un ami ?

Have you ever been betrayed by a friend?

Expected form: **un**

Why: Articles and gender. [[French#^fr-Q0045|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=As-tu%20d%C3%A9j%C3%A0%20%C3%A9t%C3%A9%20trahi%20par%20un%20ami%20%3F)
^fr-Q0045-answer

**fr-Q0046** — As-tu déjà été trahi par un ami ?

Have you ever been betrayed by a friend?

Why: Articles and gender. [[French#^fr-Q0046|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=As-tu%20d%C3%A9j%C3%A0%20%C3%A9t%C3%A9%20trahi%20par%20un%20ami%20%3F)
^fr-Q0046-answer

**fr-Q0047** — As-tu jamais eu une maladie sérieuse ?

Have you ever had a serious illness?

Why: Articles and gender. [[French#^fr-Q0047|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=As-tu%20jamais%20eu%20une%20maladie%20s%C3%A9rieuse%20%3F)
^fr-Q0047-answer

**fr-Q0048** — As-tu jamais eu une maladie sérieuse ?

Have you ever had a serious illness?

Articles distinguish gender, number and reference. Le/la are singular definite forms and les is plural. Un/une introduce indefinite singular nouns. Learn each noun with its article; a translation rarely predicts gender.

Why: Articles and gender. [[French#^fr-Q0048|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=As-tu%20jamais%20eu%20une%20maladie%20s%C3%A9rieuse%20%3F)
^fr-Q0048-answer

**fr-Q0049** — Une manière répandue de financer un déficit est de proposer des obligations.

A common way to finance a budget deficit is to issue bonds.

Expected form: **Une**

Why: Articles and gender. [[French#^fr-Q0049|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Une%20mani%C3%A8re%20r%C3%A9pandue%20de%20financer%20un%20d%C3%A9ficit%20est%20de%20proposer%20des%20obligations.)
^fr-Q0049-answer

**fr-Q0050** — Une manière répandue de financer un déficit est de proposer des obligations.

A common way to finance a budget deficit is to issue bonds.

Expected form: **Une**

Why: Articles and gender. [[French#^fr-Q0050|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Une%20mani%C3%A8re%20r%C3%A9pandue%20de%20financer%20un%20d%C3%A9ficit%20est%20de%20proposer%20des%20obligations.)
^fr-Q0050-answer


### Answers 51–100

**fr-Q0051** — Roger travaille du matin au soir.

Roger works from morning till night.

Expected form: **du**

Why: Contractions and partitives. [[French#^fr-Q0051|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Roger%20travaille%20du%20matin%20au%20soir.)
^fr-Q0051-answer

**fr-Q0052** — Roger travaille du matin au soir.

Roger works from morning till night.

Why: Contractions and partitives. [[French#^fr-Q0052|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Roger%20travaille%20du%20matin%20au%20soir.)
^fr-Q0052-answer

**fr-Q0053** — Cette partie du musée est temporairement inaccessible aux visiteurs.

This part of the museum is temporarily off-limits to visitors.

Why: Contractions and partitives. [[French#^fr-Q0053|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Cette%20partie%20du%20mus%C3%A9e%20est%20temporairement%20inaccessible%20aux%20visiteurs.)
^fr-Q0053-answer

**fr-Q0054** — Cette partie du musée est temporairement inaccessible aux visiteurs.

This part of the museum is temporarily off-limits to visitors.

Du can be de + le or a partitive article. Au and aux contract à + le/les. Meaning and the governing phrase distinguish possession, source, destination and unspecified quantity.

Why: Contractions and partitives. [[French#^fr-Q0054|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Cette%20partie%20du%20mus%C3%A9e%20est%20temporairement%20inaccessible%20aux%20visiteurs.)
^fr-Q0054-answer

**fr-Q0055** — Allez-vous au théâtre ce soir ?

Are you going to the theater tonight?

Expected form: **au**

Why: Contractions and partitives. [[French#^fr-Q0055|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Allez-vous%20au%20th%C3%A9%C3%A2tre%20ce%20soir%20%3F)
^fr-Q0055-answer

**fr-Q0056** — Allez-vous au théâtre ce soir ?

Are you going to the theater tonight?

Expected form: **au**

Why: Contractions and partitives. [[French#^fr-Q0056|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Allez-vous%20au%20th%C3%A9%C3%A2tre%20ce%20soir%20%3F)
^fr-Q0056-answer

**fr-Q0057** — Le gouvernement est tombé après un vote au parlement.

The government collapsed after a vote in parliament.

Expected form: **au**

Why: Contractions and partitives. [[French#^fr-Q0057|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Le%20gouvernement%20est%20tomb%C3%A9%20apr%C3%A8s%20un%20vote%20au%20parlement.)
^fr-Q0057-answer

**fr-Q0058** — Le gouvernement est tombé après un vote au parlement.

The government collapsed after a vote in parliament.

Why: Contractions and partitives. [[French#^fr-Q0058|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Le%20gouvernement%20est%20tomb%C3%A9%20apr%C3%A8s%20un%20vote%20au%20parlement.)
^fr-Q0058-answer

**fr-Q0059** — Jenny lavait le mur de la cuisine deux fois par an.

Jenny washed the kitchen wall twice a year.

Why: Contractions and partitives. [[French#^fr-Q0059|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Jenny%20lavait%20le%20mur%20de%20la%20cuisine%20deux%20fois%20par%20an.)
^fr-Q0059-answer

**fr-Q0060** — Jenny lavait le mur de la cuisine deux fois par an.

Jenny washed the kitchen wall twice a year.

Du can be de + le or a partitive article. Au and aux contract à + le/les. Meaning and the governing phrase distinguish possession, source, destination and unspecified quantity.

Why: Contractions and partitives. [[French#^fr-Q0060|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Jenny%20lavait%20le%20mur%20de%20la%20cuisine%20deux%20fois%20par%20an.)
^fr-Q0060-answer

**fr-Q0061** — La dépendance aux drogues a entraîné la déchéance de beaucoup de personnes.

Drug addiction degraded many people.

Expected form: **aux**

Why: Contractions and partitives. [[French#^fr-Q0061|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=La%20d%C3%A9pendance%20aux%20drogues%20a%20entra%C3%AEn%C3%A9%20la%20d%C3%A9ch%C3%A9ance%20de%20beaucoup%20de%20personnes.)
^fr-Q0061-answer

**fr-Q0062** — La dépendance aux drogues a entraîné la déchéance de beaucoup de personnes.

Drug addiction degraded many people.

Expected form: **aux**

Why: Contractions and partitives. [[French#^fr-Q0062|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=La%20d%C3%A9pendance%20aux%20drogues%20a%20entra%C3%AEn%C3%A9%20la%20d%C3%A9ch%C3%A9ance%20de%20beaucoup%20de%20personnes.)
^fr-Q0062-answer

**fr-Q0063** — Georges travaillait de la même manière que son père.

George did business in the same manner as his father.

Expected form: **de la**

Why: Contractions and partitives. [[French#^fr-Q0063|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Georges%20travaillait%20de%20la%20m%C3%AAme%20mani%C3%A8re%20que%20son%20p%C3%A8re.)
^fr-Q0063-answer

**fr-Q0064** — Georges travaillait de la même manière que son père.

George did business in the same manner as his father.

Why: Contractions and partitives. [[French#^fr-Q0064|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Georges%20travaillait%20de%20la%20m%C3%AAme%20mani%C3%A8re%20que%20son%20p%C3%A8re.)
^fr-Q0064-answer

**fr-Q0065** — J'en ai environ trente de la sorte.

I have around thirty of them.

Why: Contractions and partitives. [[French#^fr-Q0065|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=J%27en%20ai%20environ%20trente%20de%20la%20sorte.)
^fr-Q0065-answer

**fr-Q0066** — J'en ai environ trente de la sorte.

I have around thirty of them.

Du can be de + le or a partitive article. Au and aux contract à + le/les. Meaning and the governing phrase distinguish possession, source, destination and unspecified quantity.

Why: Contractions and partitives. [[French#^fr-Q0066|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=J%27en%20ai%20environ%20trente%20de%20la%20sorte.)
^fr-Q0066-answer

**fr-Q0067** — Est-ce de la musique ce que j'entends ?

Is that music I hear?

Expected form: **de la**

Why: Contractions and partitives. [[French#^fr-Q0067|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Est-ce%20de%20la%20musique%20ce%20que%20j%27entends%20%3F)
^fr-Q0067-answer

**fr-Q0068** — Est-ce de la musique ce que j'entends ?

Is that music I hear?

Expected form: **de la**

Why: Contractions and partitives. [[French#^fr-Q0068|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Est-ce%20de%20la%20musique%20ce%20que%20j%27entends%20%3F)
^fr-Q0068-answer

**fr-Q0069** — Au début, je ne l'aimais pas.

At first, I didn't like him.

Expected form: **Au**

Why: Contractions and partitives. [[French#^fr-Q0069|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Au%20d%C3%A9but%2C%20je%20ne%20l%27aimais%20pas.)
^fr-Q0069-answer

**fr-Q0070** — Au début, je ne l'aimais pas.

At first, I didn't like him.

Why: Contractions and partitives. [[French#^fr-Q0070|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Au%20d%C3%A9but%2C%20je%20ne%20l%27aimais%20pas.)
^fr-Q0070-answer

**fr-Q0071** — Seuls les individus au tempérament aberrant peuvent conserver, sur la durée, leur amour-propre, confrontés à la mésestime de leurs semblables.

Only individuals with an aberrant temperament can in the long run retain their self-esteem in the face of the disesteem of their fellows.

Why: Contractions and partitives. [[French#^fr-Q0071|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Seuls%20les%20individus%20au%20temp%C3%A9rament%20aberrant%20peuvent%20conserver%2C%20sur%20la%20dur%C3%A9e%2C%20leur%20amour-propre%2C%20confront%C3%A9s%20%C3%A0%20la%20m%C3%A9sestime%20de%20leurs%20semblables.)
^fr-Q0071-answer

**fr-Q0072** — Seuls les individus au tempérament aberrant peuvent conserver, sur la durée, leur amour-propre, confrontés à la mésestime de leurs semblables.

Only individuals with an aberrant temperament can in the long run retain their self-esteem in the face of the disesteem of their fellows.

Du can be de + le or a partitive article. Au and aux contract à + le/les. Meaning and the governing phrase distinguish possession, source, destination and unspecified quantity.

Why: Contractions and partitives. [[French#^fr-Q0072|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Seuls%20les%20individus%20au%20temp%C3%A9rament%20aberrant%20peuvent%20conserver%2C%20sur%20la%20dur%C3%A9e%2C%20leur%20amour-propre%2C%20confront%C3%A9s%20%C3%A0%20la%20m%C3%A9sestime%20de%20leurs%20semblables.)
^fr-Q0072-answer

**fr-Q0073** — Si vous parlez à un homme dans un language qu'il comprend, ça lui entre dans le crâne. Si vous lui parlez dans sa langue, ça lui va au cœur.

If you talk to a man in a language he understands, that goes to his head. If you talk to him in his language, that goes to his heart.

Expected form: **au**

Why: Contractions and partitives. [[French#^fr-Q0073|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Si%20vous%20parlez%20%C3%A0%20un%20homme%20dans%20un%20language%20qu%27il%20comprend%2C%20%C3%A7a%20lui%20entre%20dans%20le%20cr%C3%A2ne.%20Si%20vous%20lui%20parlez%20dans%20sa%20langue%2C%20%C3%A7a%20lui%20va%20au%20c%C5%93ur.)
^fr-Q0073-answer

**fr-Q0074** — Si vous parlez à un homme dans un language qu'il comprend, ça lui entre dans le crâne. Si vous lui parlez dans sa langue, ça lui va au cœur.

If you talk to a man in a language he understands, that goes to his head. If you talk to him in his language, that goes to his heart.

Expected form: **au**

Why: Contractions and partitives. [[French#^fr-Q0074|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Si%20vous%20parlez%20%C3%A0%20un%20homme%20dans%20un%20language%20qu%27il%20comprend%2C%20%C3%A7a%20lui%20entre%20dans%20le%20cr%C3%A2ne.%20Si%20vous%20lui%20parlez%20dans%20sa%20langue%2C%20%C3%A7a%20lui%20va%20au%20c%C5%93ur.)
^fr-Q0074-answer

**fr-Q0075** — Il n'était pas conscient de la situation.

He was unaware of the situation.

Expected form: **de la**

Why: Contractions and partitives. [[French#^fr-Q0075|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Il%20n%27%C3%A9tait%20pas%20conscient%20de%20la%20situation.)
^fr-Q0075-answer

**fr-Q0076** — Il n'était pas conscient de la situation.

He was unaware of the situation.

Why: Contractions and partitives. [[French#^fr-Q0076|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Il%20n%27%C3%A9tait%20pas%20conscient%20de%20la%20situation.)
^fr-Q0076-answer

**fr-Q0077** — Tom a mangé un sandwich au poulet.

Tom ate a chicken sandwich.

Why: Contractions and partitives. [[French#^fr-Q0077|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tom%20a%20mang%C3%A9%20un%20sandwich%20au%20poulet.)
^fr-Q0077-answer

**fr-Q0078** — Tom a mangé un sandwich au poulet.

Tom ate a chicken sandwich.

Du can be de + le or a partitive article. Au and aux contract à + le/les. Meaning and the governing phrase distinguish possession, source, destination and unspecified quantity.

Why: Contractions and partitives. [[French#^fr-Q0078|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tom%20a%20mang%C3%A9%20un%20sandwich%20au%20poulet.)
^fr-Q0078-answer

**fr-Q0079** — Je n’ai rien mangé à part du pain et du beurre.

I haven't eaten anything but bread and butter.

Expected form: **du**

Why: Contractions and partitives. [[French#^fr-Q0079|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20n%E2%80%99ai%20rien%20mang%C3%A9%20%C3%A0%20part%20du%20pain%20et%20du%20beurre.)
^fr-Q0079-answer

**fr-Q0080** — Je n’ai rien mangé à part du pain et du beurre.

I haven't eaten anything but bread and butter.

Expected form: **du**

Why: Contractions and partitives. [[French#^fr-Q0080|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20n%E2%80%99ai%20rien%20mang%C3%A9%20%C3%A0%20part%20du%20pain%20et%20du%20beurre.)
^fr-Q0080-answer

**fr-Q0081** — Nous avons profité de la paix depuis plus de quarante ans.

We have been enjoying peace for more than 40 years.

Expected form: **de la**

Why: Contractions and partitives. [[French#^fr-Q0081|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Nous%20avons%20profit%C3%A9%20de%20la%20paix%20depuis%20plus%20de%20quarante%20ans.)
^fr-Q0081-answer

**fr-Q0082** — Nous avons profité de la paix depuis plus de quarante ans.

We have been enjoying peace for more than 40 years.

Why: Contractions and partitives. [[French#^fr-Q0082|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Nous%20avons%20profit%C3%A9%20de%20la%20paix%20depuis%20plus%20de%20quarante%20ans.)
^fr-Q0082-answer

**fr-Q0083** — Il est déjà onze heures. Tu devrais déjà être au lit.

It's already eleven. It's high time you were in bed.

Why: Contractions and partitives. [[French#^fr-Q0083|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Il%20est%20d%C3%A9j%C3%A0%20onze%20heures.%20Tu%20devrais%20d%C3%A9j%C3%A0%20%C3%AAtre%20au%20lit.)
^fr-Q0083-answer

**fr-Q0084** — Il est déjà onze heures. Tu devrais déjà être au lit.

It's already eleven. It's high time you were in bed.

Du can be de + le or a partitive article. Au and aux contract à + le/les. Meaning and the governing phrase distinguish possession, source, destination and unspecified quantity.

Why: Contractions and partitives. [[French#^fr-Q0084|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Il%20est%20d%C3%A9j%C3%A0%20onze%20heures.%20Tu%20devrais%20d%C3%A9j%C3%A0%20%C3%AAtre%20au%20lit.)
^fr-Q0084-answer

**fr-Q0085** — Il a aspiré au poste de Premier Ministre.

He aspired to the position of Prime Minister.

Expected form: **au**

Why: Contractions and partitives. [[French#^fr-Q0085|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Il%20a%20aspir%C3%A9%20au%20poste%20de%20Premier%20Ministre.)
^fr-Q0085-answer

**fr-Q0086** — Il a aspiré au poste de Premier Ministre.

He aspired to the position of Prime Minister.

Expected form: **au**

Why: Contractions and partitives. [[French#^fr-Q0086|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Il%20a%20aspir%C3%A9%20au%20poste%20de%20Premier%20Ministre.)
^fr-Q0086-answer

**fr-Q0087** — Je suis au regret de ne pas être d'accord avec ton opinion.

It pains me to disagree with your opinion.

Expected form: **au**

Why: Contractions and partitives. [[French#^fr-Q0087|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20suis%20au%20regret%20de%20ne%20pas%20%C3%AAtre%20d%27accord%20avec%20ton%20opinion.)
^fr-Q0087-answer

**fr-Q0088** — Je suis au regret de ne pas être d'accord avec ton opinion.

It pains me to disagree with your opinion.

Why: Contractions and partitives. [[French#^fr-Q0088|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20suis%20au%20regret%20de%20ne%20pas%20%C3%AAtre%20d%27accord%20avec%20ton%20opinion.)
^fr-Q0088-answer

**fr-Q0089** — Je suis fière du travail que j'ai accompli ici.

I'm proud of the work I've done here.

Why: Contractions and partitives. [[French#^fr-Q0089|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20suis%20fi%C3%A8re%20du%20travail%20que%20j%27ai%20accompli%20ici.)
^fr-Q0089-answer

**fr-Q0090** — Je suis fière du travail que j'ai accompli ici.

I'm proud of the work I've done here.

Du can be de + le or a partitive article. Au and aux contract à + le/les. Meaning and the governing phrase distinguish possession, source, destination and unspecified quantity.

Why: Contractions and partitives. [[French#^fr-Q0090|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20suis%20fi%C3%A8re%20du%20travail%20que%20j%27ai%20accompli%20ici.)
^fr-Q0090-answer

**fr-Q0091** — La terre est l'une des planètes du système solaire.

The earth is one of the sun's planets.

Expected form: **du**

Why: Contractions and partitives. [[French#^fr-Q0091|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=La%20terre%20est%20l%27une%20des%20plan%C3%A8tes%20du%20syst%C3%A8me%20solaire.)
^fr-Q0091-answer

**fr-Q0092** — La terre est l'une des planètes du système solaire.

The earth is one of the sun's planets.

Expected form: **du**

Why: Contractions and partitives. [[French#^fr-Q0092|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=La%20terre%20est%20l%27une%20des%20plan%C3%A8tes%20du%20syst%C3%A8me%20solaire.)
^fr-Q0092-answer

**fr-Q0093** — Je montai par l'ascenseur au troisième étage.

I took the elevator to the third floor.

Expected form: **au**

Why: Contractions and partitives. [[French#^fr-Q0093|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20montai%20par%20l%27ascenseur%20au%20troisi%C3%A8me%20%C3%A9tage.)
^fr-Q0093-answer

**fr-Q0094** — Je montai par l'ascenseur au troisième étage.

I took the elevator to the third floor.

Why: Contractions and partitives. [[French#^fr-Q0094|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20montai%20par%20l%27ascenseur%20au%20troisi%C3%A8me%20%C3%A9tage.)
^fr-Q0094-answer

**fr-Q0095** — Ça fait 5 ans que j'habite au Canada.

I've been living in Canada for five years.

Why: Contractions and partitives. [[French#^fr-Q0095|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=%C3%87a%20fait%205%20ans%20que%20j%27habite%20au%20Canada.)
^fr-Q0095-answer

**fr-Q0096** — Ça fait 5 ans que j'habite au Canada.

I've been living in Canada for five years.

Du can be de + le or a partitive article. Au and aux contract à + le/les. Meaning and the governing phrase distinguish possession, source, destination and unspecified quantity.

Why: Contractions and partitives. [[French#^fr-Q0096|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=%C3%87a%20fait%205%20ans%20que%20j%27habite%20au%20Canada.)
^fr-Q0096-answer

**fr-Q0097** — Je vais aller pleurer au lit.

I'll go crying to bed.

Expected form: **au**

Why: Contractions and partitives. [[French#^fr-Q0097|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20vais%20aller%20pleurer%20au%20lit.)
^fr-Q0097-answer

**fr-Q0098** — Je vais aller pleurer au lit.

I'll go crying to bed.

Expected form: **au**

Why: Contractions and partitives. [[French#^fr-Q0098|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20vais%20aller%20pleurer%20au%20lit.)
^fr-Q0098-answer

**fr-Q0099** — Tom s'est fait agressé en rentrant chez lui du travail.

Tom was mugged on his way home from work.

Expected form: **du**

Why: Contractions and partitives. [[French#^fr-Q0099|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tom%20s%27est%20fait%20agress%C3%A9%20en%20rentrant%20chez%20lui%20du%20travail.)
^fr-Q0099-answer

**fr-Q0100** — Tom s'est fait agressé en rentrant chez lui du travail.

Tom was mugged on his way home from work.

Why: Contractions and partitives. [[French#^fr-Q0100|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tom%20s%27est%20fait%20agress%C3%A9%20en%20rentrant%20chez%20lui%20du%20travail.)
^fr-Q0100-answer


### Answers 101–150

**fr-Q0101** — Tom ne semble certainement pas savoir ce qu'il est en train de faire.

Tom certainly doesn't seem to know what he's doing.

Why: Subject pronouns. [[French#^fr-Q0101|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tom%20ne%20semble%20certainement%20pas%20savoir%20ce%20qu%27il%20est%20en%20train%20de%20faire.)
^fr-Q0101-answer

**fr-Q0102** — Tom ne semble certainement pas savoir ce qu'il est en train de faire.

Tom certainly doesn't seem to know what he's doing.

A finite verb normally has an expressed subject. On takes third-person singular agreement and often means people generally or informal we. Vous can address one person politely or several people.

Why: Subject pronouns. [[French#^fr-Q0102|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tom%20ne%20semble%20certainement%20pas%20savoir%20ce%20qu%27il%20est%20en%20train%20de%20faire.)
^fr-Q0102-answer

**fr-Q0103** — Je ne pense pas que tu devrais manger ça.

I don't think you should eat that.

Expected form: **Je**

Why: Subject pronouns. [[French#^fr-Q0103|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20ne%20pense%20pas%20que%20tu%20devrais%20manger%20%C3%A7a.)
^fr-Q0103-answer

**fr-Q0104** — Je ne pense pas que tu devrais manger ça.

I don't think you should eat that.

Expected form: **Je**

Why: Subject pronouns. [[French#^fr-Q0104|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20ne%20pense%20pas%20que%20tu%20devrais%20manger%20%C3%A7a.)
^fr-Q0104-answer

**fr-Q0105** — Je n'ai pas appris cela en lisant.

I didn't learn this through reading.

Expected form: **Je**

Why: Subject pronouns. [[French#^fr-Q0105|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20n%27ai%20pas%20appris%20cela%20en%20lisant.)
^fr-Q0105-answer

**fr-Q0106** — Je n'ai pas appris cela en lisant.

I didn't learn this through reading.

Why: Subject pronouns. [[French#^fr-Q0106|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20n%27ai%20pas%20appris%20cela%20en%20lisant.)
^fr-Q0106-answer

**fr-Q0107** — Puis-je utiliser ce téléphone ?

May I use this telephone?

Why: Subject pronouns. [[French#^fr-Q0107|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Puis-je%20utiliser%20ce%20t%C3%A9l%C3%A9phone%20%3F)
^fr-Q0107-answer

**fr-Q0108** — Puis-je utiliser ce téléphone ?

May I use this telephone?

A finite verb normally has an expressed subject. On takes third-person singular agreement and often means people generally or informal we. Vous can address one person politely or several people.

Why: Subject pronouns. [[French#^fr-Q0108|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Puis-je%20utiliser%20ce%20t%C3%A9l%C3%A9phone%20%3F)
^fr-Q0108-answer

**fr-Q0109** — Vous vous trompez. Ce n'est pas ce que j'ai dit.

You're mistaken. That's not what I said.

Expected form: **Vous**

Why: Subject pronouns. [[French#^fr-Q0109|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Vous%20vous%20trompez.%20Ce%20n%27est%20pas%20ce%20que%20j%27ai%20dit.)
^fr-Q0109-answer

**fr-Q0110** — Vous vous trompez. Ce n'est pas ce que j'ai dit.

You're mistaken. That's not what I said.

Expected form: **Vous**

Why: Subject pronouns. [[French#^fr-Q0110|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Vous%20vous%20trompez.%20Ce%20n%27est%20pas%20ce%20que%20j%27ai%20dit.)
^fr-Q0110-answer

**fr-Q0111** — Je veux être remarqué.

I want to be noticed.

Expected form: **Je**

Why: Subject pronouns. [[French#^fr-Q0111|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20veux%20%C3%AAtre%20remarqu%C3%A9.)
^fr-Q0111-answer

**fr-Q0112** — Je veux être remarqué.

I want to be noticed.

Why: Subject pronouns. [[French#^fr-Q0112|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20veux%20%C3%AAtre%20remarqu%C3%A9.)
^fr-Q0112-answer

**fr-Q0113** — Je perdis conscience.

I lost consciousness.

Why: Subject pronouns. [[French#^fr-Q0113|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20perdis%20conscience.)
^fr-Q0113-answer

**fr-Q0114** — Je perdis conscience.

I lost consciousness.

A finite verb normally has an expressed subject. On takes third-person singular agreement and often means people generally or informal we. Vous can address one person politely or several people.

Why: Subject pronouns. [[French#^fr-Q0114|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20perdis%20conscience.)
^fr-Q0114-answer

**fr-Q0115** — Peux-tu m'aider à apprendre l'espéranto?

Can you help me learn Esperanto?

Expected form: **tu**

Why: Subject pronouns. [[French#^fr-Q0115|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Peux-tu%20m%27aider%20%C3%A0%20apprendre%20l%27esp%C3%A9ranto%3F)
^fr-Q0115-answer

**fr-Q0116** — Peux-tu m'aider à apprendre l'espéranto?

Can you help me learn Esperanto?

Expected form: **tu**

Why: Subject pronouns. [[French#^fr-Q0116|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Peux-tu%20m%27aider%20%C3%A0%20apprendre%20l%27esp%C3%A9ranto%3F)
^fr-Q0116-answer

**fr-Q0117** — Je ne peux m'empêcher de me sentir quelque peu soulagée.

I can't help but feel a little relieved.

Expected form: **Je**

Why: Subject pronouns. [[French#^fr-Q0117|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20ne%20peux%20m%27emp%C3%AAcher%20de%20me%20sentir%20quelque%20peu%20soulag%C3%A9e.)
^fr-Q0117-answer

**fr-Q0118** — Je ne peux m'empêcher de me sentir quelque peu soulagée.

I can't help but feel a little relieved.

Why: Subject pronouns. [[French#^fr-Q0118|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20ne%20peux%20m%27emp%C3%AAcher%20de%20me%20sentir%20quelque%20peu%20soulag%C3%A9e.)
^fr-Q0118-answer

**fr-Q0119** — Dois-je t'appeler demain ?

Should I call you tomorrow?

Why: Subject pronouns. [[French#^fr-Q0119|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Dois-je%20t%27appeler%20demain%20%3F)
^fr-Q0119-answer

**fr-Q0120** — Dois-je t'appeler demain ?

Should I call you tomorrow?

A finite verb normally has an expressed subject. On takes third-person singular agreement and often means people generally or informal we. Vous can address one person politely or several people.

Why: Subject pronouns. [[French#^fr-Q0120|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Dois-je%20t%27appeler%20demain%20%3F)
^fr-Q0120-answer

**fr-Q0121** — Je vous en donnerai autant que vous en voulez.

I'll give you as many as you like.

Expected form: **Je**

Why: Subject pronouns. [[French#^fr-Q0121|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20vous%20en%20donnerai%20autant%20que%20vous%20en%20voulez.)
^fr-Q0121-answer

**fr-Q0122** — Je vous en donnerai autant que vous en voulez.

I'll give you as many as you like.

Expected form: **Je**

Why: Subject pronouns. [[French#^fr-Q0122|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20vous%20en%20donnerai%20autant%20que%20vous%20en%20voulez.)
^fr-Q0122-answer

**fr-Q0123** — Tu n'as rien à te reprocher.

You don't have to blame yourself for that.

Expected form: **Tu**

Why: Subject pronouns. [[French#^fr-Q0123|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tu%20n%27as%20rien%20%C3%A0%20te%20reprocher.)
^fr-Q0123-answer

**fr-Q0124** — Tu n'as rien à te reprocher.

You don't have to blame yourself for that.

Why: Subject pronouns. [[French#^fr-Q0124|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tu%20n%27as%20rien%20%C3%A0%20te%20reprocher.)
^fr-Q0124-answer

**fr-Q0125** — Ils ont vécu en Espagne pendant plusieurs années.

They lived in Spain for several years.

Why: Subject pronouns. [[French#^fr-Q0125|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Ils%20ont%20v%C3%A9cu%20en%20Espagne%20pendant%20plusieurs%20ann%C3%A9es.)
^fr-Q0125-answer

**fr-Q0126** — Ils ont vécu en Espagne pendant plusieurs années.

They lived in Spain for several years.

A finite verb normally has an expressed subject. On takes third-person singular agreement and often means people generally or informal we. Vous can address one person politely or several people.

Why: Subject pronouns. [[French#^fr-Q0126|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Ils%20ont%20v%C3%A9cu%20en%20Espagne%20pendant%20plusieurs%20ann%C3%A9es.)
^fr-Q0126-answer

**fr-Q0127** — J'attends toujours que Tom et Mary me rendent l'argent que je leur ai prêté.

I'm still waiting for Tom and Mary to pay me back the money I lent them.

Expected form: **je**

Why: Subject pronouns. [[French#^fr-Q0127|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=J%27attends%20toujours%20que%20Tom%20et%20Mary%20me%20rendent%20l%27argent%20que%20je%20leur%20ai%20pr%C3%AAt%C3%A9.)
^fr-Q0127-answer

**fr-Q0128** — J'attends toujours que Tom et Mary me rendent l'argent que je leur ai prêté.

I'm still waiting for Tom and Mary to pay me back the money I lent them.

Expected form: **je**

Why: Subject pronouns. [[French#^fr-Q0128|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=J%27attends%20toujours%20que%20Tom%20et%20Mary%20me%20rendent%20l%27argent%20que%20je%20leur%20ai%20pr%C3%AAt%C3%A9.)
^fr-Q0128-answer

**fr-Q0129** — Combien t'ont-ils donné de ta guimbarde ?

How much did they give you for your old car?

Expected form: **ils**

Why: Subject pronouns. [[French#^fr-Q0129|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Combien%20t%27ont-ils%20donn%C3%A9%20de%20ta%20guimbarde%20%3F)
^fr-Q0129-answer

**fr-Q0130** — Combien t'ont-ils donné de ta guimbarde ?

How much did they give you for your old car?

Why: Subject pronouns. [[French#^fr-Q0130|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Combien%20t%27ont-ils%20donn%C3%A9%20de%20ta%20guimbarde%20%3F)
^fr-Q0130-answer

**fr-Q0131** — Je veux essayer ça.

I want to try this.

Why: Subject pronouns. [[French#^fr-Q0131|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20veux%20essayer%20%C3%A7a.)
^fr-Q0131-answer

**fr-Q0132** — Je veux essayer ça.

I want to try this.

A finite verb normally has an expressed subject. On takes third-person singular agreement and often means people generally or informal we. Vous can address one person politely or several people.

Why: Subject pronouns. [[French#^fr-Q0132|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20veux%20essayer%20%C3%A7a.)
^fr-Q0132-answer

**fr-Q0133** — Pourquoi avez-vous laissé Tom partir ?

Why did you let Tom go?

Expected form: **vous**

Why: Subject pronouns. [[French#^fr-Q0133|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Pourquoi%20avez-vous%20laiss%C3%A9%20Tom%20partir%20%3F)
^fr-Q0133-answer

**fr-Q0134** — Pourquoi avez-vous laissé Tom partir ?

Why did you let Tom go?

Expected form: **vous**

Why: Subject pronouns. [[French#^fr-Q0134|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Pourquoi%20avez-vous%20laiss%C3%A9%20Tom%20partir%20%3F)
^fr-Q0134-answer

**fr-Q0135** — Je n'ai pas envie de marcher jusqu'à chez moi tout seul.

I don't want to walk home by myself.

Expected form: **Je**

Why: Subject pronouns. [[French#^fr-Q0135|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20n%27ai%20pas%20envie%20de%20marcher%20jusqu%27%C3%A0%20chez%20moi%20tout%20seul.)
^fr-Q0135-answer

**fr-Q0136** — Je n'ai pas envie de marcher jusqu'à chez moi tout seul.

I don't want to walk home by myself.

Why: Subject pronouns. [[French#^fr-Q0136|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20n%27ai%20pas%20envie%20de%20marcher%20jusqu%27%C3%A0%20chez%20moi%20tout%20seul.)
^fr-Q0136-answer

**fr-Q0137** — Il y a quelque chose dont je veux m'entretenir avec vous.

There's something I want to discuss with you.

Why: Subject pronouns. [[French#^fr-Q0137|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Il%20y%20a%20quelque%20chose%20dont%20je%20veux%20m%27entretenir%20avec%20vous.)
^fr-Q0137-answer

**fr-Q0138** — Il y a quelque chose dont je veux m'entretenir avec vous.

There's something I want to discuss with you.

A finite verb normally has an expressed subject. On takes third-person singular agreement and often means people generally or informal we. Vous can address one person politely or several people.

Why: Subject pronouns. [[French#^fr-Q0138|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Il%20y%20a%20quelque%20chose%20dont%20je%20veux%20m%27entretenir%20avec%20vous.)
^fr-Q0138-answer

**fr-Q0139** — Je suis vraiment dangereux.

I am very dangerous.

Expected form: **Je**

Why: Subject pronouns. [[French#^fr-Q0139|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20suis%20vraiment%20dangereux.)
^fr-Q0139-answer

**fr-Q0140** — Je suis vraiment dangereux.

I am very dangerous.

Expected form: **Je**

Why: Subject pronouns. [[French#^fr-Q0140|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20suis%20vraiment%20dangereux.)
^fr-Q0140-answer

**fr-Q0141** — Je vais essayer de rester bref.

I'll try to keep this brief.

Expected form: **Je**

Why: Subject pronouns. [[French#^fr-Q0141|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20vais%20essayer%20de%20rester%20bref.)
^fr-Q0141-answer

**fr-Q0142** — Je vais essayer de rester bref.

I'll try to keep this brief.

Why: Subject pronouns. [[French#^fr-Q0142|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20vais%20essayer%20de%20rester%20bref.)
^fr-Q0142-answer

**fr-Q0143** — Il a souri et est parti.

He smiled and left.

Why: Subject pronouns. [[French#^fr-Q0143|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Il%20a%20souri%20et%20est%20parti.)
^fr-Q0143-answer

**fr-Q0144** — Il a souri et est parti.

He smiled and left.

A finite verb normally has an expressed subject. On takes third-person singular agreement and often means people generally or informal we. Vous can address one person politely or several people.

Why: Subject pronouns. [[French#^fr-Q0144|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Il%20a%20souri%20et%20est%20parti.)
^fr-Q0144-answer

**fr-Q0145** — Je voudrais avoir plus d'argent sur moi.

I wish I had more money with me.

Expected form: **Je**

Why: Subject pronouns. [[French#^fr-Q0145|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20voudrais%20avoir%20plus%20d%27argent%20sur%20moi.)
^fr-Q0145-answer

**fr-Q0146** — Je voudrais avoir plus d'argent sur moi.

I wish I had more money with me.

Expected form: **Je**

Why: Subject pronouns. [[French#^fr-Q0146|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20voudrais%20avoir%20plus%20d%27argent%20sur%20moi.)
^fr-Q0146-answer

**fr-Q0147** — Je ne méritais pas d'aller en prison.

I didn't deserve to go to prison.

Expected form: **Je**

Why: Subject pronouns. [[French#^fr-Q0147|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20ne%20m%C3%A9ritais%20pas%20d%27aller%20en%20prison.)
^fr-Q0147-answer

**fr-Q0148** — Je ne méritais pas d'aller en prison.

I didn't deserve to go to prison.

Why: Subject pronouns. [[French#^fr-Q0148|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20ne%20m%C3%A9ritais%20pas%20d%27aller%20en%20prison.)
^fr-Q0148-answer

**fr-Q0149** — Vous pouvez le trouver chez un libraire.

You can get it at a bookstore.

Why: Subject pronouns. [[French#^fr-Q0149|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Vous%20pouvez%20le%20trouver%20chez%20un%20libraire.)
^fr-Q0149-answer

**fr-Q0150** — Vous pouvez le trouver chez un libraire.

You can get it at a bookstore.

A finite verb normally has an expressed subject. On takes third-person singular agreement and often means people generally or informal we. Vous can address one person politely or several people.

Why: Subject pronouns. [[French#^fr-Q0150|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Vous%20pouvez%20le%20trouver%20chez%20un%20libraire.)
^fr-Q0150-answer


### Answers 151–200

**fr-Q0151** — C'est chaud boulette.

It's as hot as toast.

Expected form: **est**

Why: Present être. [[French#^fr-Q0151|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=C%27est%20chaud%20boulette.)
^fr-Q0151-answer

**fr-Q0152** — C'est chaud boulette.

It's as hot as toast.

Expected form: **est**

Why: Present être. [[French#^fr-Q0152|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=C%27est%20chaud%20boulette.)
^fr-Q0152-answer

**fr-Q0153** — Mon stylo est à court d'encre.

My pen is out of ink.

Expected form: **est**

Why: Present être. [[French#^fr-Q0153|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Mon%20stylo%20est%20%C3%A0%20court%20d%27encre.)
^fr-Q0153-answer

**fr-Q0154** — Mon stylo est à court d'encre.

My pen is out of ink.

Why: Present être. [[French#^fr-Q0154|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Mon%20stylo%20est%20%C3%A0%20court%20d%27encre.)
^fr-Q0154-answer

**fr-Q0155** — Je suis venu à Tokyo pour assister à une conférence.

I came to Tokyo to attend a conference.

Why: Present être. [[French#^fr-Q0155|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20suis%20venu%20%C3%A0%20Tokyo%20pour%20assister%20%C3%A0%20une%20conf%C3%A9rence.)
^fr-Q0155-answer

**fr-Q0156** — Je suis venu à Tokyo pour assister à une conférence.

I came to Tokyo to attend a conference.

Être is irregular: je suis, tu es, il est, nous sommes, vous êtes, ils sont. It can be a main copula or an auxiliary; a later participle helps identify the latter.

Why: Present être. [[French#^fr-Q0156|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20suis%20venu%20%C3%A0%20Tokyo%20pour%20assister%20%C3%A0%20une%20conf%C3%A9rence.)
^fr-Q0156-answer

**fr-Q0157** — Tom est toujours dangereux.

Tom is still dangerous.

Expected form: **est**

Why: Present être. [[French#^fr-Q0157|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tom%20est%20toujours%20dangereux.)
^fr-Q0157-answer

**fr-Q0158** — Tom est toujours dangereux.

Tom is still dangerous.

Expected form: **est**

Why: Present être. [[French#^fr-Q0158|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tom%20est%20toujours%20dangereux.)
^fr-Q0158-answer

**fr-Q0159** — Je pense que c'est trop risqué.

I think it's too risky.

Expected form: **est**

Why: Present être. [[French#^fr-Q0159|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20pense%20que%20c%27est%20trop%20risqu%C3%A9.)
^fr-Q0159-answer

**fr-Q0160** — Je pense que c'est trop risqué.

I think it's too risky.

Why: Present être. [[French#^fr-Q0160|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20pense%20que%20c%27est%20trop%20risqu%C3%A9.)
^fr-Q0160-answer

**fr-Q0161** — N'est-ce pas exaspérant ?

Isn't it infuriating?

Why: Present être. [[French#^fr-Q0161|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=N%27est-ce%20pas%20exasp%C3%A9rant%20%3F)
^fr-Q0161-answer

**fr-Q0162** — N'est-ce pas exaspérant ?

Isn't it infuriating?

Être is irregular: je suis, tu es, il est, nous sommes, vous êtes, ils sont. It can be a main copula or an auxiliary; a later participle helps identify the latter.

Why: Present être. [[French#^fr-Q0162|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=N%27est-ce%20pas%20exasp%C3%A9rant%20%3F)
^fr-Q0162-answer

**fr-Q0163** — Ils pensent que je suis millionnaire.

They think I'm a millionaire.

Expected form: **suis**

Why: Present être. [[French#^fr-Q0163|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Ils%20pensent%20que%20je%20suis%20millionnaire.)
^fr-Q0163-answer

**fr-Q0164** — Ils pensent que je suis millionnaire.

They think I'm a millionaire.

Expected form: **suis**

Why: Present être. [[French#^fr-Q0164|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Ils%20pensent%20que%20je%20suis%20millionnaire.)
^fr-Q0164-answer

**fr-Q0165** — Il est revenu de l'atelier.

He returned from the workshop.

Expected form: **est**

Why: Present être. [[French#^fr-Q0165|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Il%20est%20revenu%20de%20l%27atelier.)
^fr-Q0165-answer

**fr-Q0166** — Il est revenu de l'atelier.

He returned from the workshop.

Why: Present être. [[French#^fr-Q0166|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Il%20est%20revenu%20de%20l%27atelier.)
^fr-Q0166-answer

**fr-Q0167** — Il est dommage que vous ne puissiez pas venir.

It's a pity that you can't come.

Why: Present être. [[French#^fr-Q0167|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Il%20est%20dommage%20que%20vous%20ne%20puissiez%20pas%20venir.)
^fr-Q0167-answer

**fr-Q0168** — Il est dommage que vous ne puissiez pas venir.

It's a pity that you can't come.

Être is irregular: je suis, tu es, il est, nous sommes, vous êtes, ils sont. It can be a main copula or an auxiliary; a later participle helps identify the latter.

Why: Present être. [[French#^fr-Q0168|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Il%20est%20dommage%20que%20vous%20ne%20puissiez%20pas%20venir.)
^fr-Q0168-answer

**fr-Q0169** — C'est ton choix.

It's your decision.

Expected form: **est**

Why: Present être. [[French#^fr-Q0169|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=C%27est%20ton%20choix.)
^fr-Q0169-answer

**fr-Q0170** — C'est ton choix.

It's your decision.

Expected form: **est**

Why: Present être. [[French#^fr-Q0170|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=C%27est%20ton%20choix.)
^fr-Q0170-answer

**fr-Q0171** — Je suis très triste d'entendre cela.

I'm very sad to hear that.

Expected form: **suis**

Why: Present être. [[French#^fr-Q0171|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20suis%20tr%C3%A8s%20triste%20d%27entendre%20cela.)
^fr-Q0171-answer

**fr-Q0172** — Je suis très triste d'entendre cela.

I'm very sad to hear that.

Why: Present être. [[French#^fr-Q0172|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20suis%20tr%C3%A8s%20triste%20d%27entendre%20cela.)
^fr-Q0172-answer

**fr-Q0173** — Vous n'êtes pas en colère, n'est-ce pas ?

You're not angry, are you?

Why: Present être. [[French#^fr-Q0173|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Vous%20n%27%C3%AAtes%20pas%20en%20col%C3%A8re%2C%20n%27est-ce%20pas%20%3F)
^fr-Q0173-answer

**fr-Q0174** — Vous n'êtes pas en colère, n'est-ce pas ?

You're not angry, are you?

Être is irregular: je suis, tu es, il est, nous sommes, vous êtes, ils sont. It can be a main copula or an auxiliary; a later participle helps identify the latter.

Why: Present être. [[French#^fr-Q0174|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Vous%20n%27%C3%AAtes%20pas%20en%20col%C3%A8re%2C%20n%27est-ce%20pas%20%3F)
^fr-Q0174-answer

**fr-Q0175** — Tom a une fille qui est musicienne.

Tom has a daughter who is a musician.

Expected form: **est**

Why: Present être. [[French#^fr-Q0175|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tom%20a%20une%20fille%20qui%20est%20musicienne.)
^fr-Q0175-answer

**fr-Q0176** — Tom a une fille qui est musicienne.

Tom has a daughter who is a musician.

Expected form: **est**

Why: Present être. [[French#^fr-Q0176|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tom%20a%20une%20fille%20qui%20est%20musicienne.)
^fr-Q0176-answer

**fr-Q0177** — Il est mort d'une crise cardiaque sur scène.

He died of a heart attack on the stage.

Expected form: **est**

Why: Present être. [[French#^fr-Q0177|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Il%20est%20mort%20d%27une%20crise%20cardiaque%20sur%20sc%C3%A8ne.)
^fr-Q0177-answer

**fr-Q0178** — Il est mort d'une crise cardiaque sur scène.

He died of a heart attack on the stage.

Why: Present être. [[French#^fr-Q0178|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Il%20est%20mort%20d%27une%20crise%20cardiaque%20sur%20sc%C3%A8ne.)
^fr-Q0178-answer

**fr-Q0179** — Je suis très fier de Tom.

I'm very proud of Tom.

Why: Present être. [[French#^fr-Q0179|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20suis%20tr%C3%A8s%20fier%20de%20Tom.)
^fr-Q0179-answer

**fr-Q0180** — Je suis très fier de Tom.

I'm very proud of Tom.

Être is irregular: je suis, tu es, il est, nous sommes, vous êtes, ils sont. It can be a main copula or an auxiliary; a later participle helps identify the latter.

Why: Present être. [[French#^fr-Q0180|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20suis%20tr%C3%A8s%20fier%20de%20Tom.)
^fr-Q0180-answer

**fr-Q0181** — Ils sont trop gros pour moi.

They're too big for me.

Expected form: **sont**

Why: Present être. [[French#^fr-Q0181|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Ils%20sont%20trop%20gros%20pour%20moi.)
^fr-Q0181-answer

**fr-Q0182** — Ils sont trop gros pour moi.

They're too big for me.

Expected form: **sont**

Why: Present être. [[French#^fr-Q0182|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Ils%20sont%20trop%20gros%20pour%20moi.)
^fr-Q0182-answer

**fr-Q0183** — Bonjour, je suis Nancy !

Hello, I am Nancy.

Expected form: **suis**

Why: Present être. [[French#^fr-Q0183|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Bonjour%2C%20je%20suis%20Nancy%20%21)
^fr-Q0183-answer

**fr-Q0184** — Bonjour, je suis Nancy !

Hello, I am Nancy.

Why: Present être. [[French#^fr-Q0184|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Bonjour%2C%20je%20suis%20Nancy%20%21)
^fr-Q0184-answer

**fr-Q0185** — Elle s'est amusée avec lui.

She had fun with him.

Why: Present être. [[French#^fr-Q0185|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Elle%20s%27est%20amus%C3%A9e%20avec%20lui.)
^fr-Q0185-answer

**fr-Q0186** — Elle s'est amusée avec lui.

She had fun with him.

Être is irregular: je suis, tu es, il est, nous sommes, vous êtes, ils sont. It can be a main copula or an auxiliary; a later participle helps identify the latter.

Why: Present être. [[French#^fr-Q0186|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Elle%20s%27est%20amus%C3%A9e%20avec%20lui.)
^fr-Q0186-answer

**fr-Q0187** — Le pauvre est aussi une personne dotée de sentiments.

The poor are also people with feelings.

Expected form: **est**

Why: Present être. [[French#^fr-Q0187|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Le%20pauvre%20est%20aussi%20une%20personne%20dot%C3%A9e%20de%20sentiments.)
^fr-Q0187-answer

**fr-Q0188** — Le pauvre est aussi une personne dotée de sentiments.

The poor are also people with feelings.

Expected form: **est**

Why: Present être. [[French#^fr-Q0188|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Le%20pauvre%20est%20aussi%20une%20personne%20dot%C3%A9e%20de%20sentiments.)
^fr-Q0188-answer

**fr-Q0189** — Je ne suis pas encore fatigué.

I'm not tired yet.

Expected form: **suis**

Why: Present être. [[French#^fr-Q0189|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20ne%20suis%20pas%20encore%20fatigu%C3%A9.)
^fr-Q0189-answer

**fr-Q0190** — Je ne suis pas encore fatigué.

I'm not tired yet.

Why: Present être. [[French#^fr-Q0190|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20ne%20suis%20pas%20encore%20fatigu%C3%A9.)
^fr-Q0190-answer

**fr-Q0191** — Elle est en retard.

She is late.

Why: Present être. [[French#^fr-Q0191|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Elle%20est%20en%20retard.)
^fr-Q0191-answer

**fr-Q0192** — Elle est en retard.

She is late.

Être is irregular: je suis, tu es, il est, nous sommes, vous êtes, ils sont. It can be a main copula or an auxiliary; a later participle helps identify the latter.

Why: Present être. [[French#^fr-Q0192|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Elle%20est%20en%20retard.)
^fr-Q0192-answer

**fr-Q0193** — Qu'êtes-vous allé faire en Russie ?

What did you go to Russia to do?

Expected form: **êtes**

Why: Present être. [[French#^fr-Q0193|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Qu%27%C3%AAtes-vous%20all%C3%A9%20faire%20en%20Russie%20%3F)
^fr-Q0193-answer

**fr-Q0194** — Qu'êtes-vous allé faire en Russie ?

What did you go to Russia to do?

Expected form: **êtes**

Why: Present être. [[French#^fr-Q0194|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Qu%27%C3%AAtes-vous%20all%C3%A9%20faire%20en%20Russie%20%3F)
^fr-Q0194-answer

**fr-Q0195** — C'est une chance unique dans la vie.

This is a once-in-a-lifetime chance.

Expected form: **est**

Why: Present être. [[French#^fr-Q0195|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=C%27est%20une%20chance%20unique%20dans%20la%20vie.)
^fr-Q0195-answer

**fr-Q0196** — C'est une chance unique dans la vie.

This is a once-in-a-lifetime chance.

Why: Present être. [[French#^fr-Q0196|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=C%27est%20une%20chance%20unique%20dans%20la%20vie.)
^fr-Q0196-answer

**fr-Q0197** — La pomme est rouge.

The apple is red.

Why: Present être. [[French#^fr-Q0197|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=La%20pomme%20est%20rouge.)
^fr-Q0197-answer

**fr-Q0198** — La pomme est rouge.

The apple is red.

Être is irregular: je suis, tu es, il est, nous sommes, vous êtes, ils sont. It can be a main copula or an auxiliary; a later participle helps identify the latter.

Why: Present être. [[French#^fr-Q0198|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=La%20pomme%20est%20rouge.)
^fr-Q0198-answer

**fr-Q0199** — Enfin la période des examens est terminée.

At last, the end-of-term exams are over.

Expected form: **est**

Why: Present être. [[French#^fr-Q0199|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Enfin%20la%20p%C3%A9riode%20des%20examens%20est%20termin%C3%A9e.)
^fr-Q0199-answer

**fr-Q0200** — Enfin la période des examens est terminée.

At last, the end-of-term exams are over.

Expected form: **est**

Why: Present être. [[French#^fr-Q0200|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Enfin%20la%20p%C3%A9riode%20des%20examens%20est%20termin%C3%A9e.)
^fr-Q0200-answer


### Answers 201–250

**fr-Q0201** — Qu'y a-t-il à faire ?

What's there to do?

Expected form: **a**

Why: Present avoir. [[French#^fr-Q0201|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Qu%27y%20a-t-il%20%C3%A0%20faire%20%3F)
^fr-Q0201-answer

**fr-Q0202** — Qu'y a-t-il à faire ?

What's there to do?

Why: Present avoir. [[French#^fr-Q0202|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Qu%27y%20a-t-il%20%C3%A0%20faire%20%3F)
^fr-Q0202-answer

**fr-Q0203** — J'ai besoin de ton aide.

I need your help.

Why: Present avoir. [[French#^fr-Q0203|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=J%27ai%20besoin%20de%20ton%20aide.)
^fr-Q0203-answer

**fr-Q0204** — J'ai besoin de ton aide.

I need your help.

Avoir expresses possession and forms many compound tenses. Some expressions use avoir where English uses be: avoir faim, avoir vingt ans. Do not translate the English verb mechanically.

Why: Present avoir. [[French#^fr-Q0204|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=J%27ai%20besoin%20de%20ton%20aide.)
^fr-Q0204-answer

**fr-Q0205** — Tom a été très respectueux.

Tom has been very respectful.

Expected form: **a**

Why: Present avoir. [[French#^fr-Q0205|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tom%20a%20%C3%A9t%C3%A9%20tr%C3%A8s%20respectueux.)
^fr-Q0205-answer

**fr-Q0206** — Tom a été très respectueux.

Tom has been very respectful.

Expected form: **a**

Why: Present avoir. [[French#^fr-Q0206|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tom%20a%20%C3%A9t%C3%A9%20tr%C3%A8s%20respectueux.)
^fr-Q0206-answer

**fr-Q0207** — L'avez-vous mesuré ?

Have you measured it?

Expected form: **avez**

Why: Present avoir. [[French#^fr-Q0207|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=L%27avez-vous%20mesur%C3%A9%20%3F)
^fr-Q0207-answer

**fr-Q0208** — L'avez-vous mesuré ?

Have you measured it?

Why: Present avoir. [[French#^fr-Q0208|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=L%27avez-vous%20mesur%C3%A9%20%3F)
^fr-Q0208-answer

**fr-Q0209** — J'ai déjà parlé à cet étudiant.

I've already talked to this student.

Why: Present avoir. [[French#^fr-Q0209|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=J%27ai%20d%C3%A9j%C3%A0%20parl%C3%A9%20%C3%A0%20cet%20%C3%A9tudiant.)
^fr-Q0209-answer

**fr-Q0210** — J'ai déjà parlé à cet étudiant.

I've already talked to this student.

Avoir expresses possession and forms many compound tenses. Some expressions use avoir where English uses be: avoir faim, avoir vingt ans. Do not translate the English verb mechanically.

Why: Present avoir. [[French#^fr-Q0210|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=J%27ai%20d%C3%A9j%C3%A0%20parl%C3%A9%20%C3%A0%20cet%20%C3%A9tudiant.)
^fr-Q0210-answer

**fr-Q0211** — Penses-tu que Tom nous a vus ?

Do you think Tom saw us?

Expected form: **a**

Why: Present avoir. [[French#^fr-Q0211|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Penses-tu%20que%20Tom%20nous%20a%20vus%20%3F)
^fr-Q0211-answer

**fr-Q0212** — Penses-tu que Tom nous a vus ?

Do you think Tom saw us?

Expected form: **a**

Why: Present avoir. [[French#^fr-Q0212|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Penses-tu%20que%20Tom%20nous%20a%20vus%20%3F)
^fr-Q0212-answer

**fr-Q0213** — Cet entraîneur lui a donné de bons conseils.

That coach gave him good advice.

Expected form: **a**

Why: Present avoir. [[French#^fr-Q0213|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Cet%20entra%C3%AEneur%20lui%20a%20donn%C3%A9%20de%20bons%20conseils.)
^fr-Q0213-answer

**fr-Q0214** — Cet entraîneur lui a donné de bons conseils.

That coach gave him good advice.

Why: Present avoir. [[French#^fr-Q0214|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Cet%20entra%C3%AEneur%20lui%20a%20donn%C3%A9%20de%20bons%20conseils.)
^fr-Q0214-answer

**fr-Q0215** — Nous n'avons pas tué Tom.

We didn't kill Tom.

Why: Present avoir. [[French#^fr-Q0215|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Nous%20n%27avons%20pas%20tu%C3%A9%20Tom.)
^fr-Q0215-answer

**fr-Q0216** — Nous n'avons pas tué Tom.

We didn't kill Tom.

Avoir expresses possession and forms many compound tenses. Some expressions use avoir where English uses be: avoir faim, avoir vingt ans. Do not translate the English verb mechanically.

Why: Present avoir. [[French#^fr-Q0216|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Nous%20n%27avons%20pas%20tu%C3%A9%20Tom.)
^fr-Q0216-answer

**fr-Q0217** — Je n'ai pas vu Tom depuis des mois.

I haven't seen Tom for months.

Expected form: **ai**

Why: Present avoir. [[French#^fr-Q0217|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20n%27ai%20pas%20vu%20Tom%20depuis%20des%20mois.)
^fr-Q0217-answer

**fr-Q0218** — Je n'ai pas vu Tom depuis des mois.

I haven't seen Tom for months.

Expected form: **ai**

Why: Present avoir. [[French#^fr-Q0218|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20n%27ai%20pas%20vu%20Tom%20depuis%20des%20mois.)
^fr-Q0218-answer

**fr-Q0219** — Nous avons été contraints de différer notre départ.

We were compelled to put off our departure.

Expected form: **avons**

Why: Present avoir. [[French#^fr-Q0219|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Nous%20avons%20%C3%A9t%C3%A9%20contraints%20de%20diff%C3%A9rer%20notre%20d%C3%A9part.)
^fr-Q0219-answer

**fr-Q0220** — Nous avons été contraints de différer notre départ.

We were compelled to put off our departure.

Why: Present avoir. [[French#^fr-Q0220|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Nous%20avons%20%C3%A9t%C3%A9%20contraints%20de%20diff%C3%A9rer%20notre%20d%C3%A9part.)
^fr-Q0220-answer

**fr-Q0221** — Tom a mangé mon déjeuner.

Tom ate my lunch.

Why: Present avoir. [[French#^fr-Q0221|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tom%20a%20mang%C3%A9%20mon%20d%C3%A9jeuner.)
^fr-Q0221-answer

**fr-Q0222** — Tom a mangé mon déjeuner.

Tom ate my lunch.

Avoir expresses possession and forms many compound tenses. Some expressions use avoir where English uses be: avoir faim, avoir vingt ans. Do not translate the English verb mechanically.

Why: Present avoir. [[French#^fr-Q0222|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tom%20a%20mang%C3%A9%20mon%20d%C3%A9jeuner.)
^fr-Q0222-answer

**fr-Q0223** — Il n'a pas la capacité d'être président.

He doesn't have the capacity to be president.

Expected form: **a**

Why: Present avoir. [[French#^fr-Q0223|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Il%20n%27a%20pas%20la%20capacit%C3%A9%20d%27%C3%AAtre%20pr%C3%A9sident.)
^fr-Q0223-answer

**fr-Q0224** — Il n'a pas la capacité d'être président.

He doesn't have the capacity to be president.

Expected form: **a**

Why: Present avoir. [[French#^fr-Q0224|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Il%20n%27a%20pas%20la%20capacit%C3%A9%20d%27%C3%AAtre%20pr%C3%A9sident.)
^fr-Q0224-answer

**fr-Q0225** — Cela n'a aucun sens.

This makes no sense.

Expected form: **a**

Why: Present avoir. [[French#^fr-Q0225|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Cela%20n%27a%20aucun%20sens.)
^fr-Q0225-answer

**fr-Q0226** — Cela n'a aucun sens.

This makes no sense.

Why: Present avoir. [[French#^fr-Q0226|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Cela%20n%27a%20aucun%20sens.)
^fr-Q0226-answer

**fr-Q0227** — Tom a dit qu'il avait un contrat.

Tom said that he had a contract.

Why: Present avoir. [[French#^fr-Q0227|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tom%20a%20dit%20qu%27il%20avait%20un%20contrat.)
^fr-Q0227-answer

**fr-Q0228** — Tom a dit qu'il avait un contrat.

Tom said that he had a contract.

Avoir expresses possession and forms many compound tenses. Some expressions use avoir where English uses be: avoir faim, avoir vingt ans. Do not translate the English verb mechanically.

Why: Present avoir. [[French#^fr-Q0228|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tom%20a%20dit%20qu%27il%20avait%20un%20contrat.)
^fr-Q0228-answer

**fr-Q0229** — J'ignore comment, mais elle l'a fait.

I don't know how, but she did it.

Expected form: **a**

Why: Present avoir. [[French#^fr-Q0229|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=J%27ignore%20comment%2C%20mais%20elle%20l%27a%20fait.)
^fr-Q0229-answer

**fr-Q0230** — J'ignore comment, mais elle l'a fait.

I don't know how, but she did it.

Expected form: **a**

Why: Present avoir. [[French#^fr-Q0230|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=J%27ignore%20comment%2C%20mais%20elle%20l%27a%20fait.)
^fr-Q0230-answer

**fr-Q0231** — Je roulais à cent-vingt kilomètres à l'heure lorsque la police m'a arrêtée.

I was driving at 120 kilometers per hour when the police stopped me.

Expected form: **a**

Why: Present avoir. [[French#^fr-Q0231|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20roulais%20%C3%A0%20cent-vingt%20kilom%C3%A8tres%20%C3%A0%20l%27heure%20lorsque%20la%20police%20m%27a%20arr%C3%AAt%C3%A9e.)
^fr-Q0231-answer

**fr-Q0232** — Je roulais à cent-vingt kilomètres à l'heure lorsque la police m'a arrêtée.

I was driving at 120 kilometers per hour when the police stopped me.

Why: Present avoir. [[French#^fr-Q0232|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20roulais%20%C3%A0%20cent-vingt%20kilom%C3%A8tres%20%C3%A0%20l%27heure%20lorsque%20la%20police%20m%27a%20arr%C3%AAt%C3%A9e.)
^fr-Q0232-answer

**fr-Q0233** — Merci pour tout ce que tu as fait pour moi.

Thank you for everything you have done for me.

Why: Present avoir. [[French#^fr-Q0233|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Merci%20pour%20tout%20ce%20que%20tu%20as%20fait%20pour%20moi.)
^fr-Q0233-answer

**fr-Q0234** — Merci pour tout ce que tu as fait pour moi.

Thank you for everything you have done for me.

Avoir expresses possession and forms many compound tenses. Some expressions use avoir where English uses be: avoir faim, avoir vingt ans. Do not translate the English verb mechanically.

Why: Present avoir. [[French#^fr-Q0234|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Merci%20pour%20tout%20ce%20que%20tu%20as%20fait%20pour%20moi.)
^fr-Q0234-answer

**fr-Q0235** — Il y a une bonne chance qu'il soit choisi.

There's a good chance that he'll be chosen.

Expected form: **a**

Why: Present avoir. [[French#^fr-Q0235|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Il%20y%20a%20une%20bonne%20chance%20qu%27il%20soit%20choisi.)
^fr-Q0235-answer

**fr-Q0236** — Il y a une bonne chance qu'il soit choisi.

There's a good chance that he'll be chosen.

Expected form: **a**

Why: Present avoir. [[French#^fr-Q0236|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Il%20y%20a%20une%20bonne%20chance%20qu%27il%20soit%20choisi.)
^fr-Q0236-answer

**fr-Q0237** — Tom vous a-t-il dit où il allait ?

Did Tom tell you where he was going?

Expected form: **a**

Why: Present avoir. [[French#^fr-Q0237|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tom%20vous%20a-t-il%20dit%20o%C3%B9%20il%20allait%20%3F)
^fr-Q0237-answer

**fr-Q0238** — Tom vous a-t-il dit où il allait ?

Did Tom tell you where he was going?

Why: Present avoir. [[French#^fr-Q0238|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tom%20vous%20a-t-il%20dit%20o%C3%B9%20il%20allait%20%3F)
^fr-Q0238-answer

**fr-Q0239** — Il faut que j'y aille. J'ai un avion à prendre.

I have to go now. I have a plane to catch.

Why: Present avoir. [[French#^fr-Q0239|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Il%20faut%20que%20j%27y%20aille.%20J%27ai%20un%20avion%20%C3%A0%20prendre.)
^fr-Q0239-answer

**fr-Q0240** — Il faut que j'y aille. J'ai un avion à prendre.

I have to go now. I have a plane to catch.

Avoir expresses possession and forms many compound tenses. Some expressions use avoir where English uses be: avoir faim, avoir vingt ans. Do not translate the English verb mechanically.

Why: Present avoir. [[French#^fr-Q0240|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Il%20faut%20que%20j%27y%20aille.%20J%27ai%20un%20avion%20%C3%A0%20prendre.)
^fr-Q0240-answer

**fr-Q0241** — La famille a pris son déjeuner à midi.

The family had its dinner at noon.

Expected form: **a**

Why: Present avoir. [[French#^fr-Q0241|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=La%20famille%20a%20pris%20son%20d%C3%A9jeuner%20%C3%A0%20midi.)
^fr-Q0241-answer

**fr-Q0242** — La famille a pris son déjeuner à midi.

The family had its dinner at noon.

Expected form: **a**

Why: Present avoir. [[French#^fr-Q0242|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=La%20famille%20a%20pris%20son%20d%C3%A9jeuner%20%C3%A0%20midi.)
^fr-Q0242-answer

**fr-Q0243** — Yutaka a deux frères plus âgés.

Yutaka has two older brothers.

Expected form: **a**

Why: Present avoir. [[French#^fr-Q0243|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Yutaka%20a%20deux%20fr%C3%A8res%20plus%20%C3%A2g%C3%A9s.)
^fr-Q0243-answer

**fr-Q0244** — Yutaka a deux frères plus âgés.

Yutaka has two older brothers.

Why: Present avoir. [[French#^fr-Q0244|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Yutaka%20a%20deux%20fr%C3%A8res%20plus%20%C3%A2g%C3%A9s.)
^fr-Q0244-answer

**fr-Q0245** — En avons-nous actuellement les moyens ?

Can we afford it now?

Why: Present avoir. [[French#^fr-Q0245|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=En%20avons-nous%20actuellement%20les%20moyens%20%3F)
^fr-Q0245-answer

**fr-Q0246** — En avons-nous actuellement les moyens ?

Can we afford it now?

Avoir expresses possession and forms many compound tenses. Some expressions use avoir where English uses be: avoir faim, avoir vingt ans. Do not translate the English verb mechanically.

Why: Present avoir. [[French#^fr-Q0246|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=En%20avons-nous%20actuellement%20les%20moyens%20%3F)
^fr-Q0246-answer

**fr-Q0247** — J'ai lu votre nouveau livre avec un réel plaisir.

I read your new book with real delight.

Expected form: **ai**

Why: Present avoir. [[French#^fr-Q0247|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=J%27ai%20lu%20votre%20nouveau%20livre%20avec%20un%20r%C3%A9el%20plaisir.)
^fr-Q0247-answer

**fr-Q0248** — J'ai lu votre nouveau livre avec un réel plaisir.

I read your new book with real delight.

Expected form: **ai**

Why: Present avoir. [[French#^fr-Q0248|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=J%27ai%20lu%20votre%20nouveau%20livre%20avec%20un%20r%C3%A9el%20plaisir.)
^fr-Q0248-answer

**fr-Q0249** — Mon frère m'a acheté un petit jouet.

My brother bought me a small toy.

Expected form: **a**

Why: Present avoir. [[French#^fr-Q0249|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Mon%20fr%C3%A8re%20m%27a%20achet%C3%A9%20un%20petit%20jouet.)
^fr-Q0249-answer

**fr-Q0250** — Mon frère m'a acheté un petit jouet.

My brother bought me a small toy.

Why: Present avoir. [[French#^fr-Q0250|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Mon%20fr%C3%A8re%20m%27a%20achet%C3%A9%20un%20petit%20jouet.)
^fr-Q0250-answer


### Answers 251–300

**fr-Q0251** — C'était une journée agréable, mais il y avait peu de monde dans le parc.

It was a pleasant day, but there were few people in the park.

Why: Imperfect perspective. [[French#^fr-Q0251|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=C%27%C3%A9tait%20une%20journ%C3%A9e%20agr%C3%A9able%2C%20mais%20il%20y%20avait%20peu%20de%20monde%20dans%20le%20parc.)
^fr-Q0251-answer

**fr-Q0252** — C'était une journée agréable, mais il y avait peu de monde dans le parc.

It was a pleasant day, but there were few people in the park.

The imparfait often presents a background state, ongoing situation or past habit. It does not simply mean a long event. Contrast it with a completed event in the passé composé.

Why: Imperfect perspective. [[French#^fr-Q0252|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=C%27%C3%A9tait%20une%20journ%C3%A9e%20agr%C3%A9able%2C%20mais%20il%20y%20avait%20peu%20de%20monde%20dans%20le%20parc.)
^fr-Q0252-answer

**fr-Q0253** — Aota n'était pas digne de ta confiance.

Aota was not worthy of your trust.

Expected form: **était**

Why: Imperfect perspective. [[French#^fr-Q0253|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Aota%20n%27%C3%A9tait%20pas%20digne%20de%20ta%20confiance.)
^fr-Q0253-answer

**fr-Q0254** — Aota n'était pas digne de ta confiance.

Aota was not worthy of your trust.

Expected form: **était**

Why: Imperfect perspective. [[French#^fr-Q0254|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Aota%20n%27%C3%A9tait%20pas%20digne%20de%20ta%20confiance.)
^fr-Q0254-answer

**fr-Q0255** — Vos questions étaient trop directes.

Your questions were too direct.

Expected form: **étaient**

Why: Imperfect perspective. [[French#^fr-Q0255|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Vos%20questions%20%C3%A9taient%20trop%20directes.)
^fr-Q0255-answer

**fr-Q0256** — Vos questions étaient trop directes.

Your questions were too direct.

Why: Imperfect perspective. [[French#^fr-Q0256|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Vos%20questions%20%C3%A9taient%20trop%20directes.)
^fr-Q0256-answer

**fr-Q0257** — C'était une question compliquée.

It was a complicated question.

Why: Imperfect perspective. [[French#^fr-Q0257|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=C%27%C3%A9tait%20une%20question%20compliqu%C3%A9e.)
^fr-Q0257-answer

**fr-Q0258** — C'était une question compliquée.

It was a complicated question.

The imparfait often presents a background state, ongoing situation or past habit. It does not simply mean a long event. Contrast it with a completed event in the passé composé.

Why: Imperfect perspective. [[French#^fr-Q0258|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=C%27%C3%A9tait%20une%20question%20compliqu%C3%A9e.)
^fr-Q0258-answer

**fr-Q0259** — Tom était en avance à son rendez-vous.

Tom was early for his appointment.

Expected form: **était**

Why: Imperfect perspective. [[French#^fr-Q0259|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tom%20%C3%A9tait%20en%20avance%20%C3%A0%20son%20rendez-vous.)
^fr-Q0259-answer

**fr-Q0260** — Tom était en avance à son rendez-vous.

Tom was early for his appointment.

Expected form: **était**

Why: Imperfect perspective. [[French#^fr-Q0260|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tom%20%C3%A9tait%20en%20avance%20%C3%A0%20son%20rendez-vous.)
^fr-Q0260-answer

**fr-Q0261** — Elle n'avait pas l'air heureuse de le voir.

She didn't look happy to see him.

Expected form: **avait**

Why: Imperfect perspective. [[French#^fr-Q0261|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Elle%20n%27avait%20pas%20l%27air%20heureuse%20de%20le%20voir.)
^fr-Q0261-answer

**fr-Q0262** — Elle n'avait pas l'air heureuse de le voir.

She didn't look happy to see him.

Why: Imperfect perspective. [[French#^fr-Q0262|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Elle%20n%27avait%20pas%20l%27air%20heureuse%20de%20le%20voir.)
^fr-Q0262-answer

**fr-Q0263** — Tout le monde avait une profonde sympathie pour les victimes.

All the people felt for the victims deeply.

Why: Imperfect perspective. [[French#^fr-Q0263|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tout%20le%20monde%20avait%20une%20profonde%20sympathie%20pour%20les%20victimes.)
^fr-Q0263-answer

**fr-Q0264** — Tout le monde avait une profonde sympathie pour les victimes.

All the people felt for the victims deeply.

The imparfait often presents a background state, ongoing situation or past habit. It does not simply mean a long event. Contrast it with a completed event in the passé composé.

Why: Imperfect perspective. [[French#^fr-Q0264|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tout%20le%20monde%20avait%20une%20profonde%20sympathie%20pour%20les%20victimes.)
^fr-Q0264-answer

**fr-Q0265** — Il m'a dit que j'étais pâle et m'a demandé quel était le problème.

He told me that I looked pale and asked me what the matter was.

Expected form: **était**

Why: Imperfect perspective. [[French#^fr-Q0265|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Il%20m%27a%20dit%20que%20j%27%C3%A9tais%20p%C3%A2le%20et%20m%27a%20demand%C3%A9%20quel%20%C3%A9tait%20le%20probl%C3%A8me.)
^fr-Q0265-answer

**fr-Q0266** — Il m'a dit que j'étais pâle et m'a demandé quel était le problème.

He told me that I looked pale and asked me what the matter was.

Expected form: **était**

Why: Imperfect perspective. [[French#^fr-Q0266|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Il%20m%27a%20dit%20que%20j%27%C3%A9tais%20p%C3%A2le%20et%20m%27a%20demand%C3%A9%20quel%20%C3%A9tait%20le%20probl%C3%A8me.)
^fr-Q0266-answer

**fr-Q0267** — Pourquoi était-elle à Paris ?

Why was she in Paris?

Expected form: **était**

Why: Imperfect perspective. [[French#^fr-Q0267|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Pourquoi%20%C3%A9tait-elle%20%C3%A0%20Paris%20%3F)
^fr-Q0267-answer

**fr-Q0268** — Pourquoi était-elle à Paris ?

Why was she in Paris?

Why: Imperfect perspective. [[French#^fr-Q0268|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Pourquoi%20%C3%A9tait-elle%20%C3%A0%20Paris%20%3F)
^fr-Q0268-answer

**fr-Q0269** — Ils étaient libres à ce moment.

They were free at that moment.

Why: Imperfect perspective. [[French#^fr-Q0269|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Ils%20%C3%A9taient%20libres%20%C3%A0%20ce%20moment.)
^fr-Q0269-answer

**fr-Q0270** — Ils étaient libres à ce moment.

They were free at that moment.

The imparfait often presents a background state, ongoing situation or past habit. It does not simply mean a long event. Contrast it with a completed event in the passé composé.

Why: Imperfect perspective. [[French#^fr-Q0270|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Ils%20%C3%A9taient%20libres%20%C3%A0%20ce%20moment.)
^fr-Q0270-answer

**fr-Q0271** — Parmi les invités à la fête, il y avait deux étrangères.

Among the guests invited to the party were two foreign ladies.

Expected form: **avait**

Why: Imperfect perspective. [[French#^fr-Q0271|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Parmi%20les%20invit%C3%A9s%20%C3%A0%20la%20f%C3%AAte%2C%20il%20y%20avait%20deux%20%C3%A9trang%C3%A8res.)
^fr-Q0271-answer

**fr-Q0272** — Parmi les invités à la fête, il y avait deux étrangères.

Among the guests invited to the party were two foreign ladies.

Expected form: **avait**

Why: Imperfect perspective. [[French#^fr-Q0272|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Parmi%20les%20invit%C3%A9s%20%C3%A0%20la%20f%C3%AAte%2C%20il%20y%20avait%20deux%20%C3%A9trang%C3%A8res.)
^fr-Q0272-answer

**fr-Q0273** — Convaincre Tom de faire ce qui était juste fut difficile.

Convincing Tom to do the right thing was hard.

Expected form: **était**

Why: Imperfect perspective. [[French#^fr-Q0273|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Convaincre%20Tom%20de%20faire%20ce%20qui%20%C3%A9tait%20juste%20fut%20difficile.)
^fr-Q0273-answer

**fr-Q0274** — Convaincre Tom de faire ce qui était juste fut difficile.

Convincing Tom to do the right thing was hard.

Why: Imperfect perspective. [[French#^fr-Q0274|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Convaincre%20Tom%20de%20faire%20ce%20qui%20%C3%A9tait%20juste%20fut%20difficile.)
^fr-Q0274-answer

**fr-Q0275** — Notre avion était en train de voler au-dessus de l'océan Pacifique.

Our plane was flying over the Pacific Ocean.

Why: Imperfect perspective. [[French#^fr-Q0275|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Notre%20avion%20%C3%A9tait%20en%20train%20de%20voler%20au-dessus%20de%20l%27oc%C3%A9an%20Pacifique.)
^fr-Q0275-answer

**fr-Q0276** — Notre avion était en train de voler au-dessus de l'océan Pacifique.

Our plane was flying over the Pacific Ocean.

The imparfait often presents a background state, ongoing situation or past habit. It does not simply mean a long event. Contrast it with a completed event in the passé composé.

Why: Imperfect perspective. [[French#^fr-Q0276|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Notre%20avion%20%C3%A9tait%20en%20train%20de%20voler%20au-dessus%20de%20l%27oc%C3%A9an%20Pacifique.)
^fr-Q0276-answer

**fr-Q0277** — Il était une fois un grand roi qui vivait en Grèce.

Once upon a time, there lived a great king in Greece.

Expected form: **était**

Why: Imperfect perspective. [[French#^fr-Q0277|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Il%20%C3%A9tait%20une%20fois%20un%20grand%20roi%20qui%20vivait%20en%20Gr%C3%A8ce.)
^fr-Q0277-answer

**fr-Q0278** — Il était une fois un grand roi qui vivait en Grèce.

Once upon a time, there lived a great king in Greece.

Expected form: **était**

Why: Imperfect perspective. [[French#^fr-Q0278|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Il%20%C3%A9tait%20une%20fois%20un%20grand%20roi%20qui%20vivait%20en%20Gr%C3%A8ce.)
^fr-Q0278-answer

**fr-Q0279** — Je voulais disparaître.

I wanted to disappear.

Expected form: **voulais**

Why: Imperfect perspective. [[French#^fr-Q0279|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20voulais%20dispara%C3%AEtre.)
^fr-Q0279-answer

**fr-Q0280** — Je voulais disparaître.

I wanted to disappear.

Why: Imperfect perspective. [[French#^fr-Q0280|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20voulais%20dispara%C3%AEtre.)
^fr-Q0280-answer

**fr-Q0281** — Tes paupières étaient-elles collées quand tu t'es réveillée ce matin ?

Were your eyelids stuck together when you woke up this morning?

Why: Imperfect perspective. [[French#^fr-Q0281|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tes%20paupi%C3%A8res%20%C3%A9taient-elles%20coll%C3%A9es%20quand%20tu%20t%27es%20r%C3%A9veill%C3%A9e%20ce%20matin%20%3F)
^fr-Q0281-answer

**fr-Q0282** — Tes paupières étaient-elles collées quand tu t'es réveillée ce matin ?

Were your eyelids stuck together when you woke up this morning?

The imparfait often presents a background state, ongoing situation or past habit. It does not simply mean a long event. Contrast it with a completed event in the passé composé.

Why: Imperfect perspective. [[French#^fr-Q0282|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tes%20paupi%C3%A8res%20%C3%A9taient-elles%20coll%C3%A9es%20quand%20tu%20t%27es%20r%C3%A9veill%C3%A9e%20ce%20matin%20%3F)
^fr-Q0282-answer

**fr-Q0283** — Elle avait l'air ravissante.

She looked ravishing.

Expected form: **avait**

Why: Imperfect perspective. [[French#^fr-Q0283|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Elle%20avait%20l%27air%20ravissante.)
^fr-Q0283-answer

**fr-Q0284** — Elle avait l'air ravissante.

She looked ravishing.

Expected form: **avait**

Why: Imperfect perspective. [[French#^fr-Q0284|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Elle%20avait%20l%27air%20ravissante.)
^fr-Q0284-answer

**fr-Q0285** — J'ai demandé à Tom qui était son professeur de français.

I asked Tom who his French teacher was.

Expected form: **était**

Why: Imperfect perspective. [[French#^fr-Q0285|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=J%27ai%20demand%C3%A9%20%C3%A0%20Tom%20qui%20%C3%A9tait%20son%20professeur%20de%20fran%C3%A7ais.)
^fr-Q0285-answer

**fr-Q0286** — J'ai demandé à Tom qui était son professeur de français.

I asked Tom who his French teacher was.

Why: Imperfect perspective. [[French#^fr-Q0286|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=J%27ai%20demand%C3%A9%20%C3%A0%20Tom%20qui%20%C3%A9tait%20son%20professeur%20de%20fran%C3%A7ais.)
^fr-Q0286-answer

**fr-Q0287** — Ils n'avaient plus d'électricité.

They had no more electricity.

Why: Imperfect perspective. [[French#^fr-Q0287|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Ils%20n%27avaient%20plus%20d%27%C3%A9lectricit%C3%A9.)
^fr-Q0287-answer

**fr-Q0288** — Ils n'avaient plus d'électricité.

They had no more electricity.

The imparfait often presents a background state, ongoing situation or past habit. It does not simply mean a long event. Contrast it with a completed event in the passé composé.

Why: Imperfect perspective. [[French#^fr-Q0288|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Ils%20n%27avaient%20plus%20d%27%C3%A9lectricit%C3%A9.)
^fr-Q0288-answer

**fr-Q0289** — Il était satisfait d'apprendre le résultat.

He was satisfied to know the result.

Expected form: **était**

Why: Imperfect perspective. [[French#^fr-Q0289|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Il%20%C3%A9tait%20satisfait%20d%27apprendre%20le%20r%C3%A9sultat.)
^fr-Q0289-answer

**fr-Q0290** — Il était satisfait d'apprendre le résultat.

He was satisfied to know the result.

Expected form: **était**

Why: Imperfect perspective. [[French#^fr-Q0290|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Il%20%C3%A9tait%20satisfait%20d%27apprendre%20le%20r%C3%A9sultat.)
^fr-Q0290-answer

**fr-Q0291** — Je ne savais pas si je voulais aller à l'université.

I didn't know whether I wanted to go to university.

Expected form: **voulais**

Why: Imperfect perspective. [[French#^fr-Q0291|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20ne%20savais%20pas%20si%20je%20voulais%20aller%20%C3%A0%20l%27universit%C3%A9.)
^fr-Q0291-answer

**fr-Q0292** — Je ne savais pas si je voulais aller à l'université.

I didn't know whether I wanted to go to university.

Why: Imperfect perspective. [[French#^fr-Q0292|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20ne%20savais%20pas%20si%20je%20voulais%20aller%20%C3%A0%20l%27universit%C3%A9.)
^fr-Q0292-answer

**fr-Q0293** — Les résultats étaient négatifs.

The results were negative.

Why: Imperfect perspective. [[French#^fr-Q0293|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Les%20r%C3%A9sultats%20%C3%A9taient%20n%C3%A9gatifs.)
^fr-Q0293-answer

**fr-Q0294** — Les résultats étaient négatifs.

The results were negative.

The imparfait often presents a background state, ongoing situation or past habit. It does not simply mean a long event. Contrast it with a completed event in the passé composé.

Why: Imperfect perspective. [[French#^fr-Q0294|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Les%20r%C3%A9sultats%20%C3%A9taient%20n%C3%A9gatifs.)
^fr-Q0294-answer

**fr-Q0295** — Comme je l'essayais, c'était simple.

As I tried, I found it simple.

Expected form: **était**

Why: Imperfect perspective. [[French#^fr-Q0295|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Comme%20je%20l%27essayais%2C%20c%27%C3%A9tait%20simple.)
^fr-Q0295-answer

**fr-Q0296** — Comme je l'essayais, c'était simple.

As I tried, I found it simple.

Expected form: **était**

Why: Imperfect perspective. [[French#^fr-Q0296|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Comme%20je%20l%27essayais%2C%20c%27%C3%A9tait%20simple.)
^fr-Q0296-answer

**fr-Q0297** — Il y avait de la neige sur la route.

There was snow on the road.

Expected form: **avait**

Why: Imperfect perspective. [[French#^fr-Q0297|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Il%20y%20avait%20de%20la%20neige%20sur%20la%20route.)
^fr-Q0297-answer

**fr-Q0298** — Il y avait de la neige sur la route.

There was snow on the road.

Why: Imperfect perspective. [[French#^fr-Q0298|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Il%20y%20avait%20de%20la%20neige%20sur%20la%20route.)
^fr-Q0298-answer

**fr-Q0299** — C'était une expérience assez incroyable.

It was a pretty amazing experience.

Why: Imperfect perspective. [[French#^fr-Q0299|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=C%27%C3%A9tait%20une%20exp%C3%A9rience%20assez%20incroyable.)
^fr-Q0299-answer

**fr-Q0300** — C'était une expérience assez incroyable.

It was a pretty amazing experience.

The imparfait often presents a background state, ongoing situation or past habit. It does not simply mean a long event. Contrast it with a completed event in the passé composé.

Why: Imperfect perspective. [[French#^fr-Q0300|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=C%27%C3%A9tait%20une%20exp%C3%A9rience%20assez%20incroyable.)
^fr-Q0300-answer


### Answers 301–350

**fr-Q0301** — L'état fait face à une crise financière.

The state faces a financial crisis.

Expected form: **fait**

Why: Past participles. [[French#^fr-Q0301|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=L%27%C3%A9tat%20fait%20face%20%C3%A0%20une%20crise%20financi%C3%A8re.)
^fr-Q0301-answer

**fr-Q0302** — L'état fait face à une crise financière.

The state faces a financial crisis.

Expected form: **fait**

Why: Past participles. [[French#^fr-Q0302|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=L%27%C3%A9tat%20fait%20face%20%C3%A0%20une%20crise%20financi%C3%A8re.)
^fr-Q0302-answer

**fr-Q0303** — Je suis en fait plutôt flattée.

I'm actually kind of flattered.

Expected form: **fait**

Why: Past participles. [[French#^fr-Q0303|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20suis%20en%20fait%20plut%C3%B4t%20flatt%C3%A9e.)
^fr-Q0303-answer

**fr-Q0304** — Je suis en fait plutôt flattée.

I'm actually kind of flattered.

Why: Past participles. [[French#^fr-Q0304|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20suis%20en%20fait%20plut%C3%B4t%20flatt%C3%A9e.)
^fr-Q0304-answer

**fr-Q0305** — Je suis venu pour vous poser une question.

I've come to ask you a question.

Why: Past participles. [[French#^fr-Q0305|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20suis%20venu%20pour%20vous%20poser%20une%20question.)
^fr-Q0305-answer

**fr-Q0306** — Je suis venu pour vous poser une question.

I've come to ask you a question.

A past participle combines with avoir or être in a compound tense. Agreement depends on the auxiliary and the construction; with avoir a preceding direct object can matter. A participle may also act adjectivally.

Why: Past participles. [[French#^fr-Q0306|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20suis%20venu%20pour%20vous%20poser%20une%20question.)
^fr-Q0306-answer

**fr-Q0307** — C'est le plus beau cadeau que j'ai jamais eu.

This is the nicest present I've ever had.

Expected form: **eu**

Why: Past participles. [[French#^fr-Q0307|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=C%27est%20le%20plus%20beau%20cadeau%20que%20j%27ai%20jamais%20eu.)
^fr-Q0307-answer

**fr-Q0308** — C'est le plus beau cadeau que j'ai jamais eu.

This is the nicest present I've ever had.

Expected form: **eu**

Why: Past participles. [[French#^fr-Q0308|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=C%27est%20le%20plus%20beau%20cadeau%20que%20j%27ai%20jamais%20eu.)
^fr-Q0308-answer

**fr-Q0309** — Vous ne m'avez toujours pas dit où vous vivez.

You still haven't told me where you live.

Expected form: **dit**

Why: Past participles. [[French#^fr-Q0309|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Vous%20ne%20m%27avez%20toujours%20pas%20dit%20o%C3%B9%20vous%20vivez.)
^fr-Q0309-answer

**fr-Q0310** — Vous ne m'avez toujours pas dit où vous vivez.

You still haven't told me where you live.

Why: Past participles. [[French#^fr-Q0310|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Vous%20ne%20m%27avez%20toujours%20pas%20dit%20o%C3%B9%20vous%20vivez.)
^fr-Q0310-answer

**fr-Q0311** — J'ai vu le dossier.

I saw the file.

Why: Past participles. [[French#^fr-Q0311|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=J%27ai%20vu%20le%20dossier.)
^fr-Q0311-answer

**fr-Q0312** — J'ai vu le dossier.

I saw the file.

A past participle combines with avoir or être in a compound tense. Agreement depends on the auxiliary and the construction; with avoir a preceding direct object can matter. A participle may also act adjectivally.

Why: Past participles. [[French#^fr-Q0312|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=J%27ai%20vu%20le%20dossier.)
^fr-Q0312-answer

**fr-Q0313** — Je pense que Tom a dit qu'il venait de Boston.

I think Tom said he was from Boston.

Expected form: **dit**

Why: Past participles. [[French#^fr-Q0313|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20pense%20que%20Tom%20a%20dit%20qu%27il%20venait%20de%20Boston.)
^fr-Q0313-answer

**fr-Q0314** — Je pense que Tom a dit qu'il venait de Boston.

I think Tom said he was from Boston.

Expected form: **dit**

Why: Past participles. [[French#^fr-Q0314|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20pense%20que%20Tom%20a%20dit%20qu%27il%20venait%20de%20Boston.)
^fr-Q0314-answer

**fr-Q0315** — Nous en avons parlé pas plus tard qu'hier.

We talked about it just yesterday.

Expected form: **parlé**

Why: Past participles. [[French#^fr-Q0315|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Nous%20en%20avons%20parl%C3%A9%20pas%20plus%20tard%20qu%27hier.)
^fr-Q0315-answer

**fr-Q0316** — Nous en avons parlé pas plus tard qu'hier.

We talked about it just yesterday.

Why: Past participles. [[French#^fr-Q0316|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Nous%20en%20avons%20parl%C3%A9%20pas%20plus%20tard%20qu%27hier.)
^fr-Q0316-answer

**fr-Q0317** — L'as-tu dit à tes parents ?

Have you told your parents?

Why: Past participles. [[French#^fr-Q0317|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=L%27as-tu%20dit%20%C3%A0%20tes%20parents%20%3F)
^fr-Q0317-answer

**fr-Q0318** — L'as-tu dit à tes parents ?

Have you told your parents?

A past participle combines with avoir or être in a compound tense. Agreement depends on the auxiliary and the construction; with avoir a preceding direct object can matter. A participle may also act adjectivally.

Why: Past participles. [[French#^fr-Q0318|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=L%27as-tu%20dit%20%C3%A0%20tes%20parents%20%3F)
^fr-Q0318-answer

**fr-Q0319** — Tom fait deux pouces de plus que Mary.

Tom is two inches taller than Mary.

Expected form: **fait**

Why: Past participles. [[French#^fr-Q0319|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tom%20fait%20deux%20pouces%20de%20plus%20que%20Mary.)
^fr-Q0319-answer

**fr-Q0320** — Tom fait deux pouces de plus que Mary.

Tom is two inches taller than Mary.

Expected form: **fait**

Why: Past participles. [[French#^fr-Q0320|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tom%20fait%20deux%20pouces%20de%20plus%20que%20Mary.)
^fr-Q0320-answer

**fr-Q0321** — Je suis venue ici pour apprendre.

I came here to learn.

Expected form: **venue**

Why: Past participles. [[French#^fr-Q0321|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20suis%20venue%20ici%20pour%20apprendre.)
^fr-Q0321-answer

**fr-Q0322** — Je suis venue ici pour apprendre.

I came here to learn.

Why: Past participles. [[French#^fr-Q0322|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20suis%20venue%20ici%20pour%20apprendre.)
^fr-Q0322-answer

**fr-Q0323** — Il n'a pas été d'accord.

He did not agree.

Why: Past participles. [[French#^fr-Q0323|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Il%20n%27a%20pas%20%C3%A9t%C3%A9%20d%27accord.)
^fr-Q0323-answer

**fr-Q0324** — Il n'a pas été d'accord.

He did not agree.

A past participle combines with avoir or être in a compound tense. Agreement depends on the auxiliary and the construction; with avoir a preceding direct object can matter. A participle may also act adjectivally.

Why: Past participles. [[French#^fr-Q0324|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Il%20n%27a%20pas%20%C3%A9t%C3%A9%20d%27accord.)
^fr-Q0324-answer

**fr-Q0325** — J'ai encore fait ce rêve étrange, la nuit dernière.

I had that weird dream again last night.

Expected form: **fait**

Why: Past participles. [[French#^fr-Q0325|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=J%27ai%20encore%20fait%20ce%20r%C3%AAve%20%C3%A9trange%2C%20la%20nuit%20derni%C3%A8re.)
^fr-Q0325-answer

**fr-Q0326** — J'ai encore fait ce rêve étrange, la nuit dernière.

I had that weird dream again last night.

Expected form: **fait**

Why: Past participles. [[French#^fr-Q0326|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=J%27ai%20encore%20fait%20ce%20r%C3%AAve%20%C3%A9trange%2C%20la%20nuit%20derni%C3%A8re.)
^fr-Q0326-answer

**fr-Q0327** — J'ai vu comment Tom a fait.

I saw how Tom did it.

Expected form: **vu**

Why: Past participles. [[French#^fr-Q0327|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=J%27ai%20vu%20comment%20Tom%20a%20fait.)
^fr-Q0327-answer

**fr-Q0328** — J'ai vu comment Tom a fait.

I saw how Tom did it.

Why: Past participles. [[French#^fr-Q0328|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=J%27ai%20vu%20comment%20Tom%20a%20fait.)
^fr-Q0328-answer

**fr-Q0329** — C'est en fait très courant.

That's actually very common.

Why: Past participles. [[French#^fr-Q0329|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=C%27est%20en%20fait%20tr%C3%A8s%20courant.)
^fr-Q0329-answer

**fr-Q0330** — C'est en fait très courant.

That's actually very common.

A past participle combines with avoir or être in a compound tense. Agreement depends on the auxiliary and the construction; with avoir a preceding direct object can matter. A participle may also act adjectivally.

Why: Past participles. [[French#^fr-Q0330|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=C%27est%20en%20fait%20tr%C3%A8s%20courant.)
^fr-Q0330-answer

**fr-Q0331** — Je n'ai jamais été capable de prendre en main des responsabilités.

I've never been able to handle responsibility.

Expected form: **été**

Why: Past participles. [[French#^fr-Q0331|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20n%27ai%20jamais%20%C3%A9t%C3%A9%20capable%20de%20prendre%20en%20main%20des%20responsabilit%C3%A9s.)
^fr-Q0331-answer

**fr-Q0332** — Je n'ai jamais été capable de prendre en main des responsabilités.

I've never been able to handle responsibility.

Expected form: **été**

Why: Past participles. [[French#^fr-Q0332|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20n%27ai%20jamais%20%C3%A9t%C3%A9%20capable%20de%20prendre%20en%20main%20des%20responsabilit%C3%A9s.)
^fr-Q0332-answer

**fr-Q0333** — Il est allé là-bas seul.

He went there by himself.

Expected form: **allé**

Why: Past participles. [[French#^fr-Q0333|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Il%20est%20all%C3%A9%20l%C3%A0-bas%20seul.)
^fr-Q0333-answer

**fr-Q0334** — Il est allé là-bas seul.

He went there by himself.

Why: Past participles. [[French#^fr-Q0334|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Il%20est%20all%C3%A9%20l%C3%A0-bas%20seul.)
^fr-Q0334-answer

**fr-Q0335** — Tom ne fait pas grand-chose à part jouer de la guitare.

Tom does little other than play the guitar.

Why: Past participles. [[French#^fr-Q0335|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tom%20ne%20fait%20pas%20grand-chose%20%C3%A0%20part%20jouer%20de%20la%20guitare.)
^fr-Q0335-answer

**fr-Q0336** — Tom ne fait pas grand-chose à part jouer de la guitare.

Tom does little other than play the guitar.

A past participle combines with avoir or être in a compound tense. Agreement depends on the auxiliary and the construction; with avoir a preceding direct object can matter. A participle may also act adjectivally.

Why: Past participles. [[French#^fr-Q0336|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tom%20ne%20fait%20pas%20grand-chose%20%C3%A0%20part%20jouer%20de%20la%20guitare.)
^fr-Q0336-answer

**fr-Q0337** — Elle a eu la gentillesse de m'accompagner à la gare.

She was kind enough to accompany me to the station.

Expected form: **eu**

Why: Past participles. [[French#^fr-Q0337|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Elle%20a%20eu%20la%20gentillesse%20de%20m%27accompagner%20%C3%A0%20la%20gare.)
^fr-Q0337-answer

**fr-Q0338** — Elle a eu la gentillesse de m'accompagner à la gare.

She was kind enough to accompany me to the station.

Expected form: **eu**

Why: Past participles. [[French#^fr-Q0338|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Elle%20a%20eu%20la%20gentillesse%20de%20m%27accompagner%20%C3%A0%20la%20gare.)
^fr-Q0338-answer

**fr-Q0339** — Qu'est-ce qui te fait tenir ?

What keeps you going?

Expected form: **fait**

Why: Past participles. [[French#^fr-Q0339|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Qu%27est-ce%20qui%20te%20fait%20tenir%20%3F)
^fr-Q0339-answer

**fr-Q0340** — Qu'est-ce qui te fait tenir ?

What keeps you going?

Why: Past participles. [[French#^fr-Q0340|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Qu%27est-ce%20qui%20te%20fait%20tenir%20%3F)
^fr-Q0340-answer

**fr-Q0341** — Vous m'avez dit que vous étiez là hier.

You told me that you were here yesterday.

Why: Past participles. [[French#^fr-Q0341|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Vous%20m%27avez%20dit%20que%20vous%20%C3%A9tiez%20l%C3%A0%20hier.)
^fr-Q0341-answer

**fr-Q0342** — Vous m'avez dit que vous étiez là hier.

You told me that you were here yesterday.

A past participle combines with avoir or être in a compound tense. Agreement depends on the auxiliary and the construction; with avoir a preceding direct object can matter. A participle may also act adjectivally.

Why: Past participles. [[French#^fr-Q0342|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Vous%20m%27avez%20dit%20que%20vous%20%C3%A9tiez%20l%C3%A0%20hier.)
^fr-Q0342-answer

**fr-Q0343** — Je lui ai dit de ne pas être en retard.

I told her not to be late.

Expected form: **dit**

Why: Past participles. [[French#^fr-Q0343|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20lui%20ai%20dit%20de%20ne%20pas%20%C3%AAtre%20en%20retard.)
^fr-Q0343-answer

**fr-Q0344** — Je lui ai dit de ne pas être en retard.

I told her not to be late.

Expected form: **dit**

Why: Past participles. [[French#^fr-Q0344|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20lui%20ai%20dit%20de%20ne%20pas%20%C3%AAtre%20en%20retard.)
^fr-Q0344-answer

**fr-Q0345** — Il n'a pas eu d'autre choix.

He didn't have another choice.

Expected form: **eu**

Why: Past participles. [[French#^fr-Q0345|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Il%20n%27a%20pas%20eu%20d%27autre%20choix.)
^fr-Q0345-answer

**fr-Q0346** — Il n'a pas eu d'autre choix.

He didn't have another choice.

Why: Past participles. [[French#^fr-Q0346|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Il%20n%27a%20pas%20eu%20d%27autre%20choix.)
^fr-Q0346-answer

**fr-Q0347** — Je fais ce qu'on me dit.

I do what I'm told.

Why: Past participles. [[French#^fr-Q0347|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20fais%20ce%20qu%27on%20me%20dit.)
^fr-Q0347-answer

**fr-Q0348** — Je fais ce qu'on me dit.

I do what I'm told.

A past participle combines with avoir or être in a compound tense. Agreement depends on the auxiliary and the construction; with avoir a preceding direct object can matter. A participle may also act adjectivally.

Why: Past participles. [[French#^fr-Q0348|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20fais%20ce%20qu%27on%20me%20dit.)
^fr-Q0348-answer

**fr-Q0349** — Tu as dit que tu étais heureuse.

You said you were happy.

Expected form: **dit**

Why: Past participles. [[French#^fr-Q0349|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tu%20as%20dit%20que%20tu%20%C3%A9tais%20heureuse.)
^fr-Q0349-answer

**fr-Q0350** — Tu as dit que tu étais heureuse.

You said you were happy.

Expected form: **dit**

Why: Past participles. [[French#^fr-Q0350|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tu%20as%20dit%20que%20tu%20%C3%A9tais%20heureuse.)
^fr-Q0350-answer


### Answers 351–400

**fr-Q0351** — Peut-être que ce sera suffisant.

Maybe that'll be enough.

Expected form: **sera**

Why: Future forms. [[French#^fr-Q0351|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Peut-%C3%AAtre%20que%20ce%20sera%20suffisant.)
^fr-Q0351-answer

**fr-Q0352** — Peut-être que ce sera suffisant.

Maybe that'll be enough.

Why: Future forms. [[French#^fr-Q0352|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Peut-%C3%AAtre%20que%20ce%20sera%20suffisant.)
^fr-Q0352-answer

**fr-Q0353** — Un verre d'eau vous fera du bien.

A glass of water will make you feel better.

Why: Future forms. [[French#^fr-Q0353|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Un%20verre%20d%27eau%20vous%20fera%20du%20bien.)
^fr-Q0353-answer

**fr-Q0354** — Un verre d'eau vous fera du bien.

A glass of water will make you feel better.

The futur simple locates an event ahead or makes a prediction. Aller plus infinitive is another future construction. In many future-time clauses after quand, French uses future where English uses present.

Why: Future forms. [[French#^fr-Q0354|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Un%20verre%20d%27eau%20vous%20fera%20du%20bien.)
^fr-Q0354-answer

**fr-Q0355** — J'ignore quand il sera là.

I don't know when he'll be here.

Expected form: **sera**

Why: Future forms. [[French#^fr-Q0355|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=J%27ignore%20quand%20il%20sera%20l%C3%A0.)
^fr-Q0355-answer

**fr-Q0356** — J'ignore quand il sera là.

I don't know when he'll be here.

Expected form: **sera**

Why: Future forms. [[French#^fr-Q0356|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=J%27ignore%20quand%20il%20sera%20l%C3%A0.)
^fr-Q0356-answer

**fr-Q0357** — Personne ne viendra.

No one will come.

Expected form: **viendra**

Why: Future forms. [[French#^fr-Q0357|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Personne%20ne%20viendra.)
^fr-Q0357-answer

**fr-Q0358** — Personne ne viendra.

No one will come.

Why: Future forms. [[French#^fr-Q0358|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Personne%20ne%20viendra.)
^fr-Q0358-answer

**fr-Q0359** — C'est un homme de parole, donc s'il a dit qu'il aiderait, il le fera.

He is a man of his word, so if he said he'd help, he will.

Why: Future forms. [[French#^fr-Q0359|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=C%27est%20un%20homme%20de%20parole%2C%20donc%20s%27il%20a%20dit%20qu%27il%20aiderait%2C%20il%20le%20fera.)
^fr-Q0359-answer

**fr-Q0360** — C'est un homme de parole, donc s'il a dit qu'il aiderait, il le fera.

He is a man of his word, so if he said he'd help, he will.

The futur simple locates an event ahead or makes a prediction. Aller plus infinitive is another future construction. In many future-time clauses after quand, French uses future where English uses present.

Why: Future forms. [[French#^fr-Q0360|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=C%27est%20un%20homme%20de%20parole%2C%20donc%20s%27il%20a%20dit%20qu%27il%20aiderait%2C%20il%20le%20fera.)
^fr-Q0360-answer

**fr-Q0361** — On ne te fera pas de mal.

You won't be harmed.

Expected form: **fera**

Why: Future forms. [[French#^fr-Q0361|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=On%20ne%20te%20fera%20pas%20de%20mal.)
^fr-Q0361-answer

**fr-Q0362** — On ne te fera pas de mal.

You won't be harmed.

Expected form: **fera**

Why: Future forms. [[French#^fr-Q0362|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=On%20ne%20te%20fera%20pas%20de%20mal.)
^fr-Q0362-answer

**fr-Q0363** — Demain, il fera froid.

Tomorrow, it will be cold.

Expected form: **fera**

Why: Future forms. [[French#^fr-Q0363|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Demain%2C%20il%20fera%20froid.)
^fr-Q0363-answer

**fr-Q0364** — Demain, il fera froid.

Tomorrow, it will be cold.

Why: Future forms. [[French#^fr-Q0364|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Demain%2C%20il%20fera%20froid.)
^fr-Q0364-answer

**fr-Q0365** — J'irai faire des courses.

I'll go shopping.

Why: Future forms. [[French#^fr-Q0365|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=J%27irai%20faire%20des%20courses.)
^fr-Q0365-answer

**fr-Q0366** — J'irai faire des courses.

I'll go shopping.

The futur simple locates an event ahead or makes a prediction. Aller plus infinitive is another future construction. In many future-time clauses after quand, French uses future where English uses present.

Why: Future forms. [[French#^fr-Q0366|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=J%27irai%20faire%20des%20courses.)
^fr-Q0366-answer

**fr-Q0367** — Tom sera ici ce soir.

Tom will be here tonight.

Expected form: **sera**

Why: Future forms. [[French#^fr-Q0367|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tom%20sera%20ici%20ce%20soir.)
^fr-Q0367-answer

**fr-Q0368** — Tom sera ici ce soir.

Tom will be here tonight.

Expected form: **sera**

Why: Future forms. [[French#^fr-Q0368|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tom%20sera%20ici%20ce%20soir.)
^fr-Q0368-answer

**fr-Q0369** — Demain, j'aurai besoin de l'aide de tout le monde.

I need everyone's help tomorrow.

Expected form: **aurai**

Why: Future forms. [[French#^fr-Q0369|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Demain%2C%20j%27aurai%20besoin%20de%20l%27aide%20de%20tout%20le%20monde.)
^fr-Q0369-answer

**fr-Q0370** — Demain, j'aurai besoin de l'aide de tout le monde.

I need everyone's help tomorrow.

Why: Future forms. [[French#^fr-Q0370|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Demain%2C%20j%27aurai%20besoin%20de%20l%27aide%20de%20tout%20le%20monde.)
^fr-Q0370-answer

**fr-Q0371** — Pensez-vous vraiment que Tom le fera ?

Do you really think Tom will do that?

Why: Future forms. [[French#^fr-Q0371|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Pensez-vous%20vraiment%20que%20Tom%20le%20fera%20%3F)
^fr-Q0371-answer

**fr-Q0372** — Pensez-vous vraiment que Tom le fera ?

Do you really think Tom will do that?

The futur simple locates an event ahead or makes a prediction. Aller plus infinitive is another future construction. In many future-time clauses after quand, French uses future where English uses present.

Why: Future forms. [[French#^fr-Q0372|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Pensez-vous%20vraiment%20que%20Tom%20le%20fera%20%3F)
^fr-Q0372-answer

**fr-Q0373** — J'aurai dû mettre un manteau.

I should've worn a coat.

Expected form: **aurai**

Why: Future forms. [[French#^fr-Q0373|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=J%27aurai%20d%C3%BB%20mettre%20un%20manteau.)
^fr-Q0373-answer

**fr-Q0374** — J'aurai dû mettre un manteau.

I should've worn a coat.

Expected form: **aurai**

Why: Future forms. [[French#^fr-Q0374|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=J%27aurai%20d%C3%BB%20mettre%20un%20manteau.)
^fr-Q0374-answer

**fr-Q0375** — Tom sera de retour dans une seconde.

Tom will be back in a second.

Expected form: **sera**

Why: Future forms. [[French#^fr-Q0375|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tom%20sera%20de%20retour%20dans%20une%20seconde.)
^fr-Q0375-answer

**fr-Q0376** — Tom sera de retour dans une seconde.

Tom will be back in a second.

Why: Future forms. [[French#^fr-Q0376|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tom%20sera%20de%20retour%20dans%20une%20seconde.)
^fr-Q0376-answer

**fr-Q0377** — Malheureusement, beaucoup de gens croient des choses qu'on leur aura dites via un courriel qu'ils ne trouveraient pas plausibles en face à face.

Sadly many people will believe things told to them via an email which they would find implausible face-to-face.

Why: Future forms. [[French#^fr-Q0377|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Malheureusement%2C%20beaucoup%20de%20gens%20croient%20des%20choses%20qu%27on%20leur%20aura%20dites%20via%20un%20courriel%20qu%27ils%20ne%20trouveraient%20pas%20plausibles%20en%20face%20%C3%A0%20face.)
^fr-Q0377-answer

**fr-Q0378** — Malheureusement, beaucoup de gens croient des choses qu'on leur aura dites via un courriel qu'ils ne trouveraient pas plausibles en face à face.

Sadly many people will believe things told to them via an email which they would find implausible face-to-face.

The futur simple locates an event ahead or makes a prediction. Aller plus infinitive is another future construction. In many future-time clauses after quand, French uses future where English uses present.

Why: Future forms. [[French#^fr-Q0378|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Malheureusement%2C%20beaucoup%20de%20gens%20croient%20des%20choses%20qu%27on%20leur%20aura%20dites%20via%20un%20courriel%20qu%27ils%20ne%20trouveraient%20pas%20plausibles%20en%20face%20%C3%A0%20face.)
^fr-Q0378-answer

**fr-Q0379** — Quiconque viendra, sera bienvenu.

Whoever comes will be welcomed.

Expected form: **viendra**

Why: Future forms. [[French#^fr-Q0379|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Quiconque%20viendra%2C%20sera%20bienvenu.)
^fr-Q0379-answer

**fr-Q0380** — Quiconque viendra, sera bienvenu.

Whoever comes will be welcomed.

Expected form: **viendra**

Why: Future forms. [[French#^fr-Q0380|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Quiconque%20viendra%2C%20sera%20bienvenu.)
^fr-Q0380-answer

**fr-Q0381** — J'espère que je n'aurai jamais à refaire ça.

I hope I never have to do that again.

Expected form: **aurai**

Why: Future forms. [[French#^fr-Q0381|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=J%27esp%C3%A8re%20que%20je%20n%27aurai%20jamais%20%C3%A0%20refaire%20%C3%A7a.)
^fr-Q0381-answer

**fr-Q0382** — J'espère que je n'aurai jamais à refaire ça.

I hope I never have to do that again.

Why: Future forms. [[French#^fr-Q0382|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=J%27esp%C3%A8re%20que%20je%20n%27aurai%20jamais%20%C3%A0%20refaire%20%C3%A7a.)
^fr-Q0382-answer

**fr-Q0383** — Je vous ferai confiance.

I'll trust you.

Why: Future forms. [[French#^fr-Q0383|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20vous%20ferai%20confiance.)
^fr-Q0383-answer

**fr-Q0384** — Je vous ferai confiance.

I'll trust you.

The futur simple locates an event ahead or makes a prediction. Aller plus infinitive is another future construction. In many future-time clauses after quand, French uses future where English uses present.

Why: Future forms. [[French#^fr-Q0384|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20vous%20ferai%20confiance.)
^fr-Q0384-answer

**fr-Q0385** — Je pense qu'on peut dire avec certitude que Tom ne sera pas là demain.

I think it's safe to assume Tom won't be here tomorrow.

Expected form: **sera**

Why: Future forms. [[French#^fr-Q0385|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20pense%20qu%27on%20peut%20dire%20avec%20certitude%20que%20Tom%20ne%20sera%20pas%20l%C3%A0%20demain.)
^fr-Q0385-answer

**fr-Q0386** — Je pense qu'on peut dire avec certitude que Tom ne sera pas là demain.

I think it's safe to assume Tom won't be here tomorrow.

Expected form: **sera**

Why: Future forms. [[French#^fr-Q0386|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20pense%20qu%27on%20peut%20dire%20avec%20certitude%20que%20Tom%20ne%20sera%20pas%20l%C3%A0%20demain.)
^fr-Q0386-answer

**fr-Q0387** — Mes parents ne seront pas là.

My parents aren't going to be there.

Expected form: **seront**

Why: Future forms. [[French#^fr-Q0387|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Mes%20parents%20ne%20seront%20pas%20l%C3%A0.)
^fr-Q0387-answer

**fr-Q0388** — Mes parents ne seront pas là.

My parents aren't going to be there.

Why: Future forms. [[French#^fr-Q0388|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Mes%20parents%20ne%20seront%20pas%20l%C3%A0.)
^fr-Q0388-answer

**fr-Q0389** — J'irai, si vous insistez.

I'll go if you insist.

Why: Future forms. [[French#^fr-Q0389|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=J%27irai%2C%20si%20vous%20insistez.)
^fr-Q0389-answer

**fr-Q0390** — J'irai, si vous insistez.

I'll go if you insist.

The futur simple locates an event ahead or makes a prediction. Aller plus infinitive is another future construction. In many future-time clauses after quand, French uses future where English uses present.

Why: Future forms. [[French#^fr-Q0390|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=J%27irai%2C%20si%20vous%20insistez.)
^fr-Q0390-answer

**fr-Q0391** — Je ferai n'importe quoi pour le bien de l'humanité.

I'll do anything in the interests of humanity.

Expected form: **ferai**

Why: Future forms. [[French#^fr-Q0391|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20ferai%20n%27importe%20quoi%20pour%20le%20bien%20de%20l%27humanit%C3%A9.)
^fr-Q0391-answer

**fr-Q0392** — Je ferai n'importe quoi pour le bien de l'humanité.

I'll do anything in the interests of humanity.

Expected form: **ferai**

Why: Future forms. [[French#^fr-Q0392|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20ferai%20n%27importe%20quoi%20pour%20le%20bien%20de%20l%27humanit%C3%A9.)
^fr-Q0392-answer

**fr-Q0393** — Soit il viendra, soit il m'appellera.

He will either come or call me.

Expected form: **viendra**

Why: Future forms. [[French#^fr-Q0393|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Soit%20il%20viendra%2C%20soit%20il%20m%27appellera.)
^fr-Q0393-answer

**fr-Q0394** — Soit il viendra, soit il m'appellera.

He will either come or call me.

Why: Future forms. [[French#^fr-Q0394|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Soit%20il%20viendra%2C%20soit%20il%20m%27appellera.)
^fr-Q0394-answer

**fr-Q0395** — Est-ce que tu penses que ça fera une différence ?

Do you think it'll make a difference?

Why: Future forms. [[French#^fr-Q0395|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Est-ce%20que%20tu%20penses%20que%20%C3%A7a%20fera%20une%20diff%C3%A9rence%20%3F)
^fr-Q0395-answer

**fr-Q0396** — Est-ce que tu penses que ça fera une différence ?

Do you think it'll make a difference?

The futur simple locates an event ahead or makes a prediction. Aller plus infinitive is another future construction. In many future-time clauses after quand, French uses future where English uses present.

Why: Future forms. [[French#^fr-Q0396|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Est-ce%20que%20tu%20penses%20que%20%C3%A7a%20fera%20une%20diff%C3%A9rence%20%3F)
^fr-Q0396-answer

**fr-Q0397** — Dis-moi quoi faire et je le ferai.

Tell me what to do and I will do it.

Expected form: **ferai**

Why: Future forms. [[French#^fr-Q0397|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Dis-moi%20quoi%20faire%20et%20je%20le%20ferai.)
^fr-Q0397-answer

**fr-Q0398** — Dis-moi quoi faire et je le ferai.

Tell me what to do and I will do it.

Expected form: **ferai**

Why: Future forms. [[French#^fr-Q0398|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Dis-moi%20quoi%20faire%20et%20je%20le%20ferai.)
^fr-Q0398-answer

**fr-Q0399** — Y aura-t-il des effets permanents ?

Will there be permanent effects?

Expected form: **aura**

Why: Future forms. [[French#^fr-Q0399|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Y%20aura-t-il%20des%20effets%20permanents%20%3F)
^fr-Q0399-answer

**fr-Q0400** — Y aura-t-il des effets permanents ?

Will there be permanent effects?

Why: Future forms. [[French#^fr-Q0400|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Y%20aura-t-il%20des%20effets%20permanents%20%3F)
^fr-Q0400-answer


### Answers 401–450

**fr-Q0401** — Tu ne voudrais prendre un peu l'air ?

Wouldn't you like to get some fresh air?

Why: Conditional forms. [[French#^fr-Q0401|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tu%20ne%20voudrais%20prendre%20un%20peu%20l%27air%20%3F)
^fr-Q0401-answer

**fr-Q0402** — Tu ne voudrais prendre un peu l'air ?

Wouldn't you like to get some fresh air?

The conditional can express a hypothetical result, politeness or unconfirmed reported information. A usual hypothetical pattern is si + imperfect, conditional in the main clause.

Why: Conditional forms. [[French#^fr-Q0402|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tu%20ne%20voudrais%20prendre%20un%20peu%20l%27air%20%3F)
^fr-Q0402-answer

**fr-Q0403** — Je ne pourrais pas me passer de ce dictionnaire, ne serait-ce que pour une journée.

I cannot do without this dictionary even a day.

Expected form: **pourrais**

Why: Conditional forms. [[French#^fr-Q0403|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20ne%20pourrais%20pas%20me%20passer%20de%20ce%20dictionnaire%2C%20ne%20serait-ce%20que%20pour%20une%20journ%C3%A9e.)
^fr-Q0403-answer

**fr-Q0404** — Je ne pourrais pas me passer de ce dictionnaire, ne serait-ce que pour une journée.

I cannot do without this dictionary even a day.

Expected form: **pourrais**

Why: Conditional forms. [[French#^fr-Q0404|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20ne%20pourrais%20pas%20me%20passer%20de%20ce%20dictionnaire%2C%20ne%20serait-ce%20que%20pour%20une%20journ%C3%A9e.)
^fr-Q0404-answer

**fr-Q0405** — Tu aurais dû lui dire la vérité.

You should have told him the truth.

Expected form: **aurais**

Why: Conditional forms. [[French#^fr-Q0405|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tu%20aurais%20d%C3%BB%20lui%20dire%20la%20v%C3%A9rit%C3%A9.)
^fr-Q0405-answer

**fr-Q0406** — Tu aurais dû lui dire la vérité.

You should have told him the truth.

Why: Conditional forms. [[French#^fr-Q0406|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tu%20aurais%20d%C3%BB%20lui%20dire%20la%20v%C3%A9rit%C3%A9.)
^fr-Q0406-answer

**fr-Q0407** — Je voudrais que vous arrêtiez de dire cela.

I wish you'd stop saying that.

Why: Conditional forms. [[French#^fr-Q0407|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20voudrais%20que%20vous%20arr%C3%AAtiez%20de%20dire%20cela.)
^fr-Q0407-answer

**fr-Q0408** — Je voudrais que vous arrêtiez de dire cela.

I wish you'd stop saying that.

The conditional can express a hypothetical result, politeness or unconfirmed reported information. A usual hypothetical pattern is si + imperfect, conditional in the main clause.

Why: Conditional forms. [[French#^fr-Q0408|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20voudrais%20que%20vous%20arr%C3%AAtiez%20de%20dire%20cela.)
^fr-Q0408-answer

**fr-Q0409** — Loin de moi l'idée que George pourrait me tromper.

Never did I dream that George would cheat me.

Expected form: **pourrait**

Why: Conditional forms. [[French#^fr-Q0409|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Loin%20de%20moi%20l%27id%C3%A9e%20que%20George%20pourrait%20me%20tromper.)
^fr-Q0409-answer

**fr-Q0410** — Loin de moi l'idée que George pourrait me tromper.

Never did I dream that George would cheat me.

Expected form: **pourrait**

Why: Conditional forms. [[French#^fr-Q0410|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Loin%20de%20moi%20l%27id%C3%A9e%20que%20George%20pourrait%20me%20tromper.)
^fr-Q0410-answer

**fr-Q0411** — En voudrais-tu un ?

Would you like one?

Expected form: **voudrais**

Why: Conditional forms. [[French#^fr-Q0411|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=En%20voudrais-tu%20un%20%3F)
^fr-Q0411-answer

**fr-Q0412** — En voudrais-tu un ?

Would you like one?

Why: Conditional forms. [[French#^fr-Q0412|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=En%20voudrais-tu%20un%20%3F)
^fr-Q0412-answer

**fr-Q0413** — On devrait toujours se soumettre à la loi.

We should always obey laws.

Why: Conditional forms. [[French#^fr-Q0413|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=On%20devrait%20toujours%20se%20soumettre%20%C3%A0%20la%20loi.)
^fr-Q0413-answer

**fr-Q0414** — On devrait toujours se soumettre à la loi.

We should always obey laws.

The conditional can express a hypothetical result, politeness or unconfirmed reported information. A usual hypothetical pattern is si + imperfect, conditional in the main clause.

Why: Conditional forms. [[French#^fr-Q0414|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=On%20devrait%20toujours%20se%20soumettre%20%C3%A0%20la%20loi.)
^fr-Q0414-answer

**fr-Q0415** — Elle ne pourrait pas le convaincre de solliciter un prêt.

She couldn't convince him to ask for a loan.

Expected form: **pourrait**

Why: Conditional forms. [[French#^fr-Q0415|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Elle%20ne%20pourrait%20pas%20le%20convaincre%20de%20solliciter%20un%20pr%C3%AAt.)
^fr-Q0415-answer

**fr-Q0416** — Elle ne pourrait pas le convaincre de solliciter un prêt.

She couldn't convince him to ask for a loan.

Expected form: **pourrait**

Why: Conditional forms. [[French#^fr-Q0416|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Elle%20ne%20pourrait%20pas%20le%20convaincre%20de%20solliciter%20un%20pr%C3%AAt.)
^fr-Q0416-answer

**fr-Q0417** — Pourrais-tu me dire à nouveau où tu as mis la clé ?

Could you please tell me again where you put the key?

Expected form: **Pourrais**

Why: Conditional forms. [[French#^fr-Q0417|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Pourrais-tu%20me%20dire%20%C3%A0%20nouveau%20o%C3%B9%20tu%20as%20mis%20la%20cl%C3%A9%20%3F)
^fr-Q0417-answer

**fr-Q0418** — Pourrais-tu me dire à nouveau où tu as mis la clé ?

Could you please tell me again where you put the key?

Why: Conditional forms. [[French#^fr-Q0418|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Pourrais-tu%20me%20dire%20%C3%A0%20nouveau%20o%C3%B9%20tu%20as%20mis%20la%20cl%C3%A9%20%3F)
^fr-Q0418-answer

**fr-Q0419** — Ça devrait être prêt mardi.

That should be ready on Tuesday.

Why: Conditional forms. [[French#^fr-Q0419|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=%C3%87a%20devrait%20%C3%AAtre%20pr%C3%AAt%20mardi.)
^fr-Q0419-answer

**fr-Q0420** — Ça devrait être prêt mardi.

That should be ready on Tuesday.

The conditional can express a hypothetical result, politeness or unconfirmed reported information. A usual hypothetical pattern is si + imperfect, conditional in the main clause.

Why: Conditional forms. [[French#^fr-Q0420|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=%C3%87a%20devrait%20%C3%AAtre%20pr%C3%AAt%20mardi.)
^fr-Q0420-answer

**fr-Q0421** — C'est la meilleure chose qui pourrait m'arriver.

That's the best thing that could happen to me.

Expected form: **pourrait**

Why: Conditional forms. [[French#^fr-Q0421|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=C%27est%20la%20meilleure%20chose%20qui%20pourrait%20m%27arriver.)
^fr-Q0421-answer

**fr-Q0422** — C'est la meilleure chose qui pourrait m'arriver.

That's the best thing that could happen to me.

Expected form: **pourrait**

Why: Conditional forms. [[French#^fr-Q0422|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=C%27est%20la%20meilleure%20chose%20qui%20pourrait%20m%27arriver.)
^fr-Q0422-answer

**fr-Q0423** — Elles m'ont dit qu'elles seraient à la maison lundi.

They told me they'd be home on Monday.

Expected form: **seraient**

Why: Conditional forms. [[French#^fr-Q0423|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Elles%20m%27ont%20dit%20qu%27elles%20seraient%20%C3%A0%20la%20maison%20lundi.)
^fr-Q0423-answer

**fr-Q0424** — Elles m'ont dit qu'elles seraient à la maison lundi.

They told me they'd be home on Monday.

Why: Conditional forms. [[French#^fr-Q0424|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Elles%20m%27ont%20dit%20qu%27elles%20seraient%20%C3%A0%20la%20maison%20lundi.)
^fr-Q0424-answer

**fr-Q0425** — Je savais que je n'aurais pas dû porter cette couleur.

I knew I shouldn't have worn this color.

Why: Conditional forms. [[French#^fr-Q0425|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20savais%20que%20je%20n%27aurais%20pas%20d%C3%BB%20porter%20cette%20couleur.)
^fr-Q0425-answer

**fr-Q0426** — Je savais que je n'aurais pas dû porter cette couleur.

I knew I shouldn't have worn this color.

The conditional can express a hypothetical result, politeness or unconfirmed reported information. A usual hypothetical pattern is si + imperfect, conditional in the main clause.

Why: Conditional forms. [[French#^fr-Q0426|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20savais%20que%20je%20n%27aurais%20pas%20d%C3%BB%20porter%20cette%20couleur.)
^fr-Q0426-answer

**fr-Q0427** — Elle aurait dû être très fière de vous.

She would have been very proud of you.

Expected form: **aurait**

Why: Conditional forms. [[French#^fr-Q0427|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Elle%20aurait%20d%C3%BB%20%C3%AAtre%20tr%C3%A8s%20fi%C3%A8re%20de%20vous.)
^fr-Q0427-answer

**fr-Q0428** — Elle aurait dû être très fière de vous.

She would have been very proud of you.

Expected form: **aurait**

Why: Conditional forms. [[French#^fr-Q0428|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Elle%20aurait%20d%C3%BB%20%C3%AAtre%20tr%C3%A8s%20fi%C3%A8re%20de%20vous.)
^fr-Q0428-answer

**fr-Q0429** — Ça pourrait avoir des conséquences involontaires.

This could have unintended consequences.

Expected form: **pourrait**

Why: Conditional forms. [[French#^fr-Q0429|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=%C3%87a%20pourrait%20avoir%20des%20cons%C3%A9quences%20involontaires.)
^fr-Q0429-answer

**fr-Q0430** — Ça pourrait avoir des conséquences involontaires.

This could have unintended consequences.

Why: Conditional forms. [[French#^fr-Q0430|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=%C3%87a%20pourrait%20avoir%20des%20cons%C3%A9quences%20involontaires.)
^fr-Q0430-answer

**fr-Q0431** — Il aurait aimé disposer de davantage de temps.

He wished he had more time.

Why: Conditional forms. [[French#^fr-Q0431|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Il%20aurait%20aim%C3%A9%20disposer%20de%20davantage%20de%20temps.)
^fr-Q0431-answer

**fr-Q0432** — Il aurait aimé disposer de davantage de temps.

He wished he had more time.

The conditional can express a hypothetical result, politeness or unconfirmed reported information. A usual hypothetical pattern is si + imperfect, conditional in the main clause.

Why: Conditional forms. [[French#^fr-Q0432|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Il%20aurait%20aim%C3%A9%20disposer%20de%20davantage%20de%20temps.)
^fr-Q0432-answer

**fr-Q0433** — Tatoeba : on a plus de phrases que ta mère pourrait en dire dans toute sa vie.

Tatoeba: We've got more sentences than your mom could ever say in her lifetime.

Expected form: **pourrait**

Why: Conditional forms. [[French#^fr-Q0433|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tatoeba%20%3A%20on%20a%20plus%20de%20phrases%20que%20ta%20m%C3%A8re%20pourrait%20en%20dire%20dans%20toute%20sa%20vie.)
^fr-Q0433-answer

**fr-Q0434** — Tatoeba : on a plus de phrases que ta mère pourrait en dire dans toute sa vie.

Tatoeba: We've got more sentences than your mom could ever say in her lifetime.

Expected form: **pourrait**

Why: Conditional forms. [[French#^fr-Q0434|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tatoeba%20%3A%20on%20a%20plus%20de%20phrases%20que%20ta%20m%C3%A8re%20pourrait%20en%20dire%20dans%20toute%20sa%20vie.)
^fr-Q0434-answer

**fr-Q0435** — On aurait pu le faire sans votre aide.

We could've done this without your help.

Expected form: **aurait**

Why: Conditional forms. [[French#^fr-Q0435|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=On%20aurait%20pu%20le%20faire%20sans%20votre%20aide.)
^fr-Q0435-answer

**fr-Q0436** — On aurait pu le faire sans votre aide.

We could've done this without your help.

Why: Conditional forms. [[French#^fr-Q0436|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=On%20aurait%20pu%20le%20faire%20sans%20votre%20aide.)
^fr-Q0436-answer

**fr-Q0437** — Pourrais-tu m'indiquer quelle taille tu fais et combien tu pèses, je te prie ?

Could you please tell me how tall you are and how much you weigh?

Why: Conditional forms. [[French#^fr-Q0437|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Pourrais-tu%20m%27indiquer%20quelle%20taille%20tu%20fais%20et%20combien%20tu%20p%C3%A8ses%2C%20je%20te%20prie%20%3F)
^fr-Q0437-answer

**fr-Q0438** — Pourrais-tu m'indiquer quelle taille tu fais et combien tu pèses, je te prie ?

Could you please tell me how tall you are and how much you weigh?

The conditional can express a hypothetical result, politeness or unconfirmed reported information. A usual hypothetical pattern is si + imperfect, conditional in the main clause.

Why: Conditional forms. [[French#^fr-Q0438|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Pourrais-tu%20m%27indiquer%20quelle%20taille%20tu%20fais%20et%20combien%20tu%20p%C3%A8ses%2C%20je%20te%20prie%20%3F)
^fr-Q0438-answer

**fr-Q0439** — Je savais que cela serait facile.

I knew it would be easy.

Expected form: **serait**

Why: Conditional forms. [[French#^fr-Q0439|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20savais%20que%20cela%20serait%20facile.)
^fr-Q0439-answer

**fr-Q0440** — Je savais que cela serait facile.

I knew it would be easy.

Expected form: **serait**

Why: Conditional forms. [[French#^fr-Q0440|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20savais%20que%20cela%20serait%20facile.)
^fr-Q0440-answer

**fr-Q0441** — Peux-tu te figurer comment serait la vie sans télévision ?

Can you imagine what life would be like without television?

Expected form: **serait**

Why: Conditional forms. [[French#^fr-Q0441|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Peux-tu%20te%20figurer%20comment%20serait%20la%20vie%20sans%20t%C3%A9l%C3%A9vision%20%3F)
^fr-Q0441-answer

**fr-Q0442** — Peux-tu te figurer comment serait la vie sans télévision ?

Can you imagine what life would be like without television?

Why: Conditional forms. [[French#^fr-Q0442|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Peux-tu%20te%20figurer%20comment%20serait%20la%20vie%20sans%20t%C3%A9l%C3%A9vision%20%3F)
^fr-Q0442-answer

**fr-Q0443** — Je n'ai jamais pensé que ça serait aussi passionnant.

I never thought it would be so exciting.

Why: Conditional forms. [[French#^fr-Q0443|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20n%27ai%20jamais%20pens%C3%A9%20que%20%C3%A7a%20serait%20aussi%20passionnant.)
^fr-Q0443-answer

**fr-Q0444** — Je n'ai jamais pensé que ça serait aussi passionnant.

I never thought it would be so exciting.

The conditional can express a hypothetical result, politeness or unconfirmed reported information. A usual hypothetical pattern is si + imperfect, conditional in the main clause.

Why: Conditional forms. [[French#^fr-Q0444|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20n%27ai%20jamais%20pens%C3%A9%20que%20%C3%A7a%20serait%20aussi%20passionnant.)
^fr-Q0444-answer

**fr-Q0445** — Ce serait cool.

That would be cool.

Expected form: **serait**

Why: Conditional forms. [[French#^fr-Q0445|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Ce%20serait%20cool.)
^fr-Q0445-answer

**fr-Q0446** — Ce serait cool.

That would be cool.

Expected form: **serait**

Why: Conditional forms. [[French#^fr-Q0446|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Ce%20serait%20cool.)
^fr-Q0446-answer

**fr-Q0447** — Ce pourrait être notre seul espoir.

It may be our only hope.

Expected form: **pourrait**

Why: Conditional forms. [[French#^fr-Q0447|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Ce%20pourrait%20%C3%AAtre%20notre%20seul%20espoir.)
^fr-Q0447-answer

**fr-Q0448** — Ce pourrait être notre seul espoir.

It may be our only hope.

Why: Conditional forms. [[French#^fr-Q0448|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Ce%20pourrait%20%C3%AAtre%20notre%20seul%20espoir.)
^fr-Q0448-answer

**fr-Q0449** — Je ne pourrais pas vous mentir.

I couldn't lie to you.

Why: Conditional forms. [[French#^fr-Q0449|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20ne%20pourrais%20pas%20vous%20mentir.)
^fr-Q0449-answer

**fr-Q0450** — Je ne pourrais pas vous mentir.

I couldn't lie to you.

The conditional can express a hypothetical result, politeness or unconfirmed reported information. A usual hypothetical pattern is si + imperfect, conditional in the main clause.

Why: Conditional forms. [[French#^fr-Q0450|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20ne%20pourrais%20pas%20vous%20mentir.)
^fr-Q0450-answer


### Answers 451–500

**fr-Q0451** — Ne te rappelles-tu pas quoi que ce soit ?

Don't you remember anything?

Expected form: **soit**

Why: Subjunctive contexts. [[French#^fr-Q0451|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Ne%20te%20rappelles-tu%20pas%20quoi%20que%20ce%20soit%20%3F)
^fr-Q0451-answer

**fr-Q0452** — Ne te rappelles-tu pas quoi que ce soit ?

Don't you remember anything?

Expected form: **soit**

Why: Subjunctive contexts. [[French#^fr-Q0452|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Ne%20te%20rappelles-tu%20pas%20quoi%20que%20ce%20soit%20%3F)
^fr-Q0452-answer

**fr-Q0453** — Il est plus riche que qui que ce soit d'autre en ville.

He is richer than anybody else in town.

Expected form: **soit**

Why: Subjunctive contexts. [[French#^fr-Q0453|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Il%20est%20plus%20riche%20que%20qui%20que%20ce%20soit%20d%27autre%20en%20ville.)
^fr-Q0453-answer

**fr-Q0454** — Il est plus riche que qui que ce soit d'autre en ville.

He is richer than anybody else in town.

Why: Subjunctive contexts. [[French#^fr-Q0454|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Il%20est%20plus%20riche%20que%20qui%20que%20ce%20soit%20d%27autre%20en%20ville.)
^fr-Q0454-answer

**fr-Q0455** — Que Dieu l'ait en sa sainte miséricorde.

May God have mercy on him.

Why: Subjunctive contexts. [[French#^fr-Q0455|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Que%20Dieu%20l%27ait%20en%20sa%20sainte%20mis%C3%A9ricorde.)
^fr-Q0455-answer

**fr-Q0456** — Que Dieu l'ait en sa sainte miséricorde.

May God have mercy on him.

Subjunctive forms occur after many expressions of necessity, desire, doubt and evaluation. The governing expression matters: il faut que commonly takes a subjunctive. A form alone does not establish a speaker’s certainty.

Why: Subjunctive contexts. [[French#^fr-Q0456|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Que%20Dieu%20l%27ait%20en%20sa%20sainte%20mis%C3%A9ricorde.)
^fr-Q0456-answer

**fr-Q0457** — Ça ne fait aucune différence, qu'il vienne ou pas.

It makes no difference whether he comes or not.

Expected form: **vienne**

Why: Subjunctive contexts. [[French#^fr-Q0457|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=%C3%87a%20ne%20fait%20aucune%20diff%C3%A9rence%2C%20qu%27il%20vienne%20ou%20pas.)
^fr-Q0457-answer

**fr-Q0458** — Ça ne fait aucune différence, qu'il vienne ou pas.

It makes no difference whether he comes or not.

Expected form: **vienne**

Why: Subjunctive contexts. [[French#^fr-Q0458|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=%C3%87a%20ne%20fait%20aucune%20diff%C3%A9rence%2C%20qu%27il%20vienne%20ou%20pas.)
^fr-Q0458-answer

**fr-Q0459** — J'attends qu'il vienne.

I expect him to come.

Expected form: **vienne**

Why: Subjunctive contexts. [[French#^fr-Q0459|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=J%27attends%20qu%27il%20vienne.)
^fr-Q0459-answer

**fr-Q0460** — J'attends qu'il vienne.

I expect him to come.

Why: Subjunctive contexts. [[French#^fr-Q0460|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=J%27attends%20qu%27il%20vienne.)
^fr-Q0460-answer

**fr-Q0461** — Espérons qu'il n'y ait plus d'actes de vandalisme.

Let's hope there are no more acts of vandalism.

Why: Subjunctive contexts. [[French#^fr-Q0461|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Esp%C3%A9rons%20qu%27il%20n%27y%20ait%20plus%20d%27actes%20de%20vandalisme.)
^fr-Q0461-answer

**fr-Q0462** — Espérons qu'il n'y ait plus d'actes de vandalisme.

Let's hope there are no more acts of vandalism.

Subjunctive forms occur after many expressions of necessity, desire, doubt and evaluation. The governing expression matters: il faut que commonly takes a subjunctive. A form alone does not establish a speaker’s certainty.

Why: Subjunctive contexts. [[French#^fr-Q0462|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Esp%C3%A9rons%20qu%27il%20n%27y%20ait%20plus%20d%27actes%20de%20vandalisme.)
^fr-Q0462-answer

**fr-Q0463** — Quoi qu'il en soit, je vous appellerai demain.

In any case, I'll call you tomorrow.

Expected form: **soit**

Why: Subjunctive contexts. [[French#^fr-Q0463|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Quoi%20qu%27il%20en%20soit%2C%20je%20vous%20appellerai%20demain.)
^fr-Q0463-answer

**fr-Q0464** — Quoi qu'il en soit, je vous appellerai demain.

In any case, I'll call you tomorrow.

Expected form: **soit**

Why: Subjunctive contexts. [[French#^fr-Q0464|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Quoi%20qu%27il%20en%20soit%2C%20je%20vous%20appellerai%20demain.)
^fr-Q0464-answer

**fr-Q0465** — J'ai assisté à la réunion bien que mon père m'ait dit de ne pas le faire.

I attended the meeting though my father told me not to.

Expected form: **ait**

Why: Subjunctive contexts. [[French#^fr-Q0465|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=J%27ai%20assist%C3%A9%20%C3%A0%20la%20r%C3%A9union%20bien%20que%20mon%20p%C3%A8re%20m%27ait%20dit%20de%20ne%20pas%20le%20faire.)
^fr-Q0465-answer

**fr-Q0466** — J'ai assisté à la réunion bien que mon père m'ait dit de ne pas le faire.

I attended the meeting though my father told me not to.

Why: Subjunctive contexts. [[French#^fr-Q0466|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=J%27ai%20assist%C3%A9%20%C3%A0%20la%20r%C3%A9union%20bien%20que%20mon%20p%C3%A8re%20m%27ait%20dit%20de%20ne%20pas%20le%20faire.)
^fr-Q0466-answer

**fr-Q0467** — Il se peut que ça fasse un peu mal.

This may hurt a bit.

Why: Subjunctive contexts. [[French#^fr-Q0467|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Il%20se%20peut%20que%20%C3%A7a%20fasse%20un%20peu%20mal.)
^fr-Q0467-answer

**fr-Q0468** — Il se peut que ça fasse un peu mal.

This may hurt a bit.

Subjunctive forms occur after many expressions of necessity, desire, doubt and evaluation. The governing expression matters: il faut que commonly takes a subjunctive. A form alone does not establish a speaker’s certainty.

Why: Subjunctive contexts. [[French#^fr-Q0468|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Il%20se%20peut%20que%20%C3%A7a%20fasse%20un%20peu%20mal.)
^fr-Q0468-answer

**fr-Q0469** — Veux-tu réellement que cette information soit rendue publique ?

Do you really want this information to be made public?

Expected form: **soit**

Why: Subjunctive contexts. [[French#^fr-Q0469|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Veux-tu%20r%C3%A9ellement%20que%20cette%20information%20soit%20rendue%20publique%20%3F)
^fr-Q0469-answer

**fr-Q0470** — Veux-tu réellement que cette information soit rendue publique ?

Do you really want this information to be made public?

Expected form: **soit**

Why: Subjunctive contexts. [[French#^fr-Q0470|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Veux-tu%20r%C3%A9ellement%20que%20cette%20information%20soit%20rendue%20publique%20%3F)
^fr-Q0470-answer

**fr-Q0471** — Je veux que mon argent me soit restitué sur-le-champ.

I want my money returned immediately.

Expected form: **soit**

Why: Subjunctive contexts. [[French#^fr-Q0471|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20veux%20que%20mon%20argent%20me%20soit%20restitu%C3%A9%20sur-le-champ.)
^fr-Q0471-answer

**fr-Q0472** — Je veux que mon argent me soit restitué sur-le-champ.

I want my money returned immediately.

Why: Subjunctive contexts. [[French#^fr-Q0472|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20veux%20que%20mon%20argent%20me%20soit%20restitu%C3%A9%20sur-le-champ.)
^fr-Q0472-answer

**fr-Q0473** — Veux-tu que je fasse du café ?

Do you want me to make coffee?

Why: Subjunctive contexts. [[French#^fr-Q0473|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Veux-tu%20que%20je%20fasse%20du%20caf%C3%A9%20%3F)
^fr-Q0473-answer

**fr-Q0474** — Veux-tu que je fasse du café ?

Do you want me to make coffee?

Subjunctive forms occur after many expressions of necessity, desire, doubt and evaluation. The governing expression matters: il faut que commonly takes a subjunctive. A form alone does not establish a speaker’s certainty.

Why: Subjunctive contexts. [[French#^fr-Q0474|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Veux-tu%20que%20je%20fasse%20du%20caf%C3%A9%20%3F)
^fr-Q0474-answer

**fr-Q0475** — Aimes-tu qu'on te fasse attendre ?

Do you like to be kept waiting?

Expected form: **fasse**

Why: Subjunctive contexts. [[French#^fr-Q0475|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Aimes-tu%20qu%27on%20te%20fasse%20attendre%20%3F)
^fr-Q0475-answer

**fr-Q0476** — Aimes-tu qu'on te fasse attendre ?

Do you like to be kept waiting?

Expected form: **fasse**

Why: Subjunctive contexts. [[French#^fr-Q0476|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Aimes-tu%20qu%27on%20te%20fasse%20attendre%20%3F)
^fr-Q0476-answer

**fr-Q0477** — Je ne me rappelle pas que quoi que ce soit fut arrivé.

I don't remember anything happening.

Expected form: **soit**

Why: Subjunctive contexts. [[French#^fr-Q0477|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20ne%20me%20rappelle%20pas%20que%20quoi%20que%20ce%20soit%20fut%20arriv%C3%A9.)
^fr-Q0477-answer

**fr-Q0478** — Je ne me rappelle pas que quoi que ce soit fut arrivé.

I don't remember anything happening.

Why: Subjunctive contexts. [[French#^fr-Q0478|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20ne%20me%20rappelle%20pas%20que%20quoi%20que%20ce%20soit%20fut%20arriv%C3%A9.)
^fr-Q0478-answer

**fr-Q0479** — Je ne parviens pas à croire que ce soit réel.

I can't believe that this is real.

Why: Subjunctive contexts. [[French#^fr-Q0479|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20ne%20parviens%20pas%20%C3%A0%20croire%20que%20ce%20soit%20r%C3%A9el.)
^fr-Q0479-answer

**fr-Q0480** — Je ne parviens pas à croire que ce soit réel.

I can't believe that this is real.

Subjunctive forms occur after many expressions of necessity, desire, doubt and evaluation. The governing expression matters: il faut que commonly takes a subjunctive. A form alone does not establish a speaker’s certainty.

Why: Subjunctive contexts. [[French#^fr-Q0480|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20ne%20parviens%20pas%20%C3%A0%20croire%20que%20ce%20soit%20r%C3%A9el.)
^fr-Q0480-answer

**fr-Q0481** — Je ne peux pas croire qu'elle soit plus âgée que ma mère.

I can't believe that she is older than my mother.

Expected form: **soit**

Why: Subjunctive contexts. [[French#^fr-Q0481|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20ne%20peux%20pas%20croire%20qu%27elle%20soit%20plus%20%C3%A2g%C3%A9e%20que%20ma%20m%C3%A8re.)
^fr-Q0481-answer

**fr-Q0482** — Je ne peux pas croire qu'elle soit plus âgée que ma mère.

I can't believe that she is older than my mother.

Expected form: **soit**

Why: Subjunctive contexts. [[French#^fr-Q0482|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20ne%20peux%20pas%20croire%20qu%27elle%20soit%20plus%20%C3%A2g%C3%A9e%20que%20ma%20m%C3%A8re.)
^fr-Q0482-answer

**fr-Q0483** — Les lecteurs ne peuvent pas êtres sûrs que les nouvelles soient vraies ou non.

The readers cannot ascertain whether the news is true or not.

Expected form: **soient**

Why: Subjunctive contexts. [[French#^fr-Q0483|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Les%20lecteurs%20ne%20peuvent%20pas%20%C3%AAtres%20s%C3%BBrs%20que%20les%20nouvelles%20soient%20vraies%20ou%20non.)
^fr-Q0483-answer

**fr-Q0484** — Les lecteurs ne peuvent pas êtres sûrs que les nouvelles soient vraies ou non.

The readers cannot ascertain whether the news is true or not.

Why: Subjunctive contexts. [[French#^fr-Q0484|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Les%20lecteurs%20ne%20peuvent%20pas%20%C3%AAtres%20s%C3%BBrs%20que%20les%20nouvelles%20soient%20vraies%20ou%20non.)
^fr-Q0484-answer

**fr-Q0485** — Qu'est-ce que tu voulais que je fasse ?

What would you have me do?

Why: Subjunctive contexts. [[French#^fr-Q0485|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Qu%27est-ce%20que%20tu%20voulais%20que%20je%20fasse%20%3F)
^fr-Q0485-answer

**fr-Q0486** — Qu'est-ce que tu voulais que je fasse ?

What would you have me do?

Subjunctive forms occur after many expressions of necessity, desire, doubt and evaluation. The governing expression matters: il faut que commonly takes a subjunctive. A form alone does not establish a speaker’s certainty.

Why: Subjunctive contexts. [[French#^fr-Q0486|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Qu%27est-ce%20que%20tu%20voulais%20que%20je%20fasse%20%3F)
^fr-Q0486-answer

**fr-Q0487** — Je ne pense pas que je puisse jamais faire cela.

I don't think I could ever do that.

Expected form: **puisse**

Why: Subjunctive contexts. [[French#^fr-Q0487|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20ne%20pense%20pas%20que%20je%20puisse%20jamais%20faire%20cela.)
^fr-Q0487-answer

**fr-Q0488** — Je ne pense pas que je puisse jamais faire cela.

I don't think I could ever do that.

Expected form: **puisse**

Why: Subjunctive contexts. [[French#^fr-Q0488|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20ne%20pense%20pas%20que%20je%20puisse%20jamais%20faire%20cela.)
^fr-Q0488-answer

**fr-Q0489** — Ça fait un moment qu'il n'a pas publié quoi que ce soit sur son site web.

It's been quite a while since the last time he posted anything on his website.

Expected form: **soit**

Why: Subjunctive contexts. [[French#^fr-Q0489|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=%C3%87a%20fait%20un%20moment%20qu%27il%20n%27a%20pas%20publi%C3%A9%20quoi%20que%20ce%20soit%20sur%20son%20site%20web.)
^fr-Q0489-answer

**fr-Q0490** — Ça fait un moment qu'il n'a pas publié quoi que ce soit sur son site web.

It's been quite a while since the last time he posted anything on his website.

Why: Subjunctive contexts. [[French#^fr-Q0490|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=%C3%87a%20fait%20un%20moment%20qu%27il%20n%27a%20pas%20publi%C3%A9%20quoi%20que%20ce%20soit%20sur%20son%20site%20web.)
^fr-Q0490-answer

**fr-Q0491** — Es-tu blessée où que ce soit ?

Are you hurt anywhere?

Why: Subjunctive contexts. [[French#^fr-Q0491|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Es-tu%20bless%C3%A9e%20o%C3%B9%20que%20ce%20soit%20%3F)
^fr-Q0491-answer

**fr-Q0492** — Es-tu blessée où que ce soit ?

Are you hurt anywhere?

Subjunctive forms occur after many expressions of necessity, desire, doubt and evaluation. The governing expression matters: il faut que commonly takes a subjunctive. A form alone does not establish a speaker’s certainty.

Why: Subjunctive contexts. [[French#^fr-Q0492|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Es-tu%20bless%C3%A9e%20o%C3%B9%20que%20ce%20soit%20%3F)
^fr-Q0492-answer

**fr-Q0493** — En admettant qu'il en soit ainsi, que s'ensuit-il ?

Granting that it is so, what follows?

Expected form: **soit**

Why: Subjunctive contexts. [[French#^fr-Q0493|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=En%20admettant%20qu%27il%20en%20soit%20ainsi%2C%20que%20s%27ensuit-il%20%3F)
^fr-Q0493-answer

**fr-Q0494** — En admettant qu'il en soit ainsi, que s'ensuit-il ?

Granting that it is so, what follows?

Expected form: **soit**

Why: Subjunctive contexts. [[French#^fr-Q0494|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=En%20admettant%20qu%27il%20en%20soit%20ainsi%2C%20que%20s%27ensuit-il%20%3F)
^fr-Q0494-answer

**fr-Q0495** — J'espère que cela soit résolu rapidement.

I hope this is resolved quickly.

Expected form: **soit**

Why: Subjunctive contexts. [[French#^fr-Q0495|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=J%27esp%C3%A8re%20que%20cela%20soit%20r%C3%A9solu%20rapidement.)
^fr-Q0495-answer

**fr-Q0496** — J'espère que cela soit résolu rapidement.

I hope this is resolved quickly.

Why: Subjunctive contexts. [[French#^fr-Q0496|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=J%27esp%C3%A8re%20que%20cela%20soit%20r%C3%A9solu%20rapidement.)
^fr-Q0496-answer

**fr-Q0497** — Je veux qu'il soit informé de cela en avance.

I want him to be informed about that in advance.

Why: Subjunctive contexts. [[French#^fr-Q0497|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20veux%20qu%27il%20soit%20inform%C3%A9%20de%20cela%20en%20avance.)
^fr-Q0497-answer

**fr-Q0498** — Je veux qu'il soit informé de cela en avance.

I want him to be informed about that in advance.

Subjunctive forms occur after many expressions of necessity, desire, doubt and evaluation. The governing expression matters: il faut que commonly takes a subjunctive. A form alone does not establish a speaker’s certainty.

Why: Subjunctive contexts. [[French#^fr-Q0498|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20veux%20qu%27il%20soit%20inform%C3%A9%20de%20cela%20en%20avance.)
^fr-Q0498-answer

**fr-Q0499** — Je ne suis pas certaine que ceci soit nécessaire.

I'm not sure this is necessary.

Expected form: **soit**

Why: Subjunctive contexts. [[French#^fr-Q0499|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20ne%20suis%20pas%20certaine%20que%20ceci%20soit%20n%C3%A9cessaire.)
^fr-Q0499-answer

**fr-Q0500** — Je ne suis pas certaine que ceci soit nécessaire.

I'm not sure this is necessary.

Expected form: **soit**

Why: Subjunctive contexts. [[French#^fr-Q0500|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20ne%20suis%20pas%20certaine%20que%20ceci%20soit%20n%C3%A9cessaire.)
^fr-Q0500-answer


### Answers 501–550

**fr-Q0501** — Voulez-vous sortir d'ici ou non ?

Do you want to get out of here or not?

Expected form: **vous**

Why: Object pronouns. [[French#^fr-Q0501|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Voulez-vous%20sortir%20d%27ici%20ou%20non%20%3F)
^fr-Q0501-answer

**fr-Q0502** — Voulez-vous sortir d'ici ou non ?

Do you want to get out of here or not?

Why: Object pronouns. [[French#^fr-Q0502|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Voulez-vous%20sortir%20d%27ici%20ou%20non%20%3F)
^fr-Q0502-answer

**fr-Q0503** — Je viens te chercher.

I'm coming to pick you up.

Why: Object pronouns. [[French#^fr-Q0503|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20viens%20te%20chercher.)
^fr-Q0503-answer

**fr-Q0504** — Je viens te chercher.

I'm coming to pick you up.

Direct and indirect object pronouns differ. Lui/leur often replace an animate à-complement; le/la/les replace direct objects. Pronouns generally precede the finite verb, with special imperative ordering.

Why: Object pronouns. [[French#^fr-Q0504|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20viens%20te%20chercher.)
^fr-Q0504-answer

**fr-Q0505** — Faisons-nous l'objet d'une accusation ?

Are we being charged with something?

Expected form: **nous**

Why: Object pronouns. [[French#^fr-Q0505|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Faisons-nous%20l%27objet%20d%27une%20accusation%20%3F)
^fr-Q0505-answer

**fr-Q0506** — Faisons-nous l'objet d'une accusation ?

Are we being charged with something?

Expected form: **nous**

Why: Object pronouns. [[French#^fr-Q0506|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Faisons-nous%20l%27objet%20d%27une%20accusation%20%3F)
^fr-Q0506-answer

**fr-Q0507** — Les employés de bureau japonais travaillent très dur.

Japanese office workers work very hard.

Expected form: **Les**

Why: Object pronouns. [[French#^fr-Q0507|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Les%20employ%C3%A9s%20de%20bureau%20japonais%20travaillent%20tr%C3%A8s%20dur.)
^fr-Q0507-answer

**fr-Q0508** — Les employés de bureau japonais travaillent très dur.

Japanese office workers work very hard.

Why: Object pronouns. [[French#^fr-Q0508|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Les%20employ%C3%A9s%20de%20bureau%20japonais%20travaillent%20tr%C3%A8s%20dur.)
^fr-Q0508-answer

**fr-Q0509** — Il utilisa un grand morceau de papier pour confectionner le sac.

He used a big piece of paper to make the bag.

Why: Object pronouns. [[French#^fr-Q0509|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Il%20utilisa%20un%20grand%20morceau%20de%20papier%20pour%20confectionner%20le%20sac.)
^fr-Q0509-answer

**fr-Q0510** — Il utilisa un grand morceau de papier pour confectionner le sac.

He used a big piece of paper to make the bag.

Direct and indirect object pronouns differ. Lui/leur often replace an animate à-complement; le/la/les replace direct objects. Pronouns generally precede the finite verb, with special imperative ordering.

Why: Object pronouns. [[French#^fr-Q0510|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Il%20utilisa%20un%20grand%20morceau%20de%20papier%20pour%20confectionner%20le%20sac.)
^fr-Q0510-answer

**fr-Q0511** — Elle lui parla de l'affaire.

She spoke to him about the matter.

Expected form: **lui**

Why: Object pronouns. [[French#^fr-Q0511|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Elle%20lui%20parla%20de%20l%27affaire.)
^fr-Q0511-answer

**fr-Q0512** — Elle lui parla de l'affaire.

She spoke to him about the matter.

Expected form: **lui**

Why: Object pronouns. [[French#^fr-Q0512|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Elle%20lui%20parla%20de%20l%27affaire.)
^fr-Q0512-answer

**fr-Q0513** — Nous voulons analyser votre urine.

We want to analyze your urine.

Expected form: **Nous**

Why: Object pronouns. [[French#^fr-Q0513|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Nous%20voulons%20analyser%20votre%20urine.)
^fr-Q0513-answer

**fr-Q0514** — Nous voulons analyser votre urine.

We want to analyze your urine.

Why: Object pronouns. [[French#^fr-Q0514|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Nous%20voulons%20analyser%20votre%20urine.)
^fr-Q0514-answer

**fr-Q0515** — Pourquoi vous sentez-vous ainsi ?

Why do you feel that way?

Why: Object pronouns. [[French#^fr-Q0515|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Pourquoi%20vous%20sentez-vous%20ainsi%20%3F)
^fr-Q0515-answer

**fr-Q0516** — Pourquoi vous sentez-vous ainsi ?

Why do you feel that way?

Direct and indirect object pronouns differ. Lui/leur often replace an animate à-complement; le/la/les replace direct objects. Pronouns generally precede the finite verb, with special imperative ordering.

Why: Object pronouns. [[French#^fr-Q0516|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Pourquoi%20vous%20sentez-vous%20ainsi%20%3F)
^fr-Q0516-answer

**fr-Q0517** — Étudiez aussi durement que vous pouvez.

Study as hard as you can.

Expected form: **vous**

Why: Object pronouns. [[French#^fr-Q0517|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=%C3%89tudiez%20aussi%20durement%20que%20vous%20pouvez.)
^fr-Q0517-answer

**fr-Q0518** — Étudiez aussi durement que vous pouvez.

Study as hard as you can.

Expected form: **vous**

Why: Object pronouns. [[French#^fr-Q0518|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=%C3%89tudiez%20aussi%20durement%20que%20vous%20pouvez.)
^fr-Q0518-answer

**fr-Q0519** — Ne pose pas de livres sur la table.

Don't put books on the table.

Expected form: **la**

Why: Object pronouns. [[French#^fr-Q0519|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Ne%20pose%20pas%20de%20livres%20sur%20la%20table.)
^fr-Q0519-answer

**fr-Q0520** — Ne pose pas de livres sur la table.

Don't put books on the table.

Why: Object pronouns. [[French#^fr-Q0520|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Ne%20pose%20pas%20de%20livres%20sur%20la%20table.)
^fr-Q0520-answer

**fr-Q0521** — Fais-le toi-même !

Do it by yourself.

Why: Object pronouns. [[French#^fr-Q0521|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Fais-le%20toi-m%C3%AAme%20%21)
^fr-Q0521-answer

**fr-Q0522** — Fais-le toi-même !

Do it by yourself.

Direct and indirect object pronouns differ. Lui/leur often replace an animate à-complement; le/la/les replace direct objects. Pronouns generally precede the finite verb, with special imperative ordering.

Why: Object pronouns. [[French#^fr-Q0522|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Fais-le%20toi-m%C3%AAme%20%21)
^fr-Q0522-answer

**fr-Q0523** — Les pyramides furent bâties en des temps anciens.

The pyramids were built in ancient times.

Expected form: **Les**

Why: Object pronouns. [[French#^fr-Q0523|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Les%20pyramides%20furent%20b%C3%A2ties%20en%20des%20temps%20anciens.)
^fr-Q0523-answer

**fr-Q0524** — Les pyramides furent bâties en des temps anciens.

The pyramids were built in ancient times.

Expected form: **Les**

Why: Object pronouns. [[French#^fr-Q0524|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Les%20pyramides%20furent%20b%C3%A2ties%20en%20des%20temps%20anciens.)
^fr-Q0524-answer

**fr-Q0525** — Ne t'inquiète pas. Nous la trouverons.

Don't worry. We'll find it.

Expected form: **Nous**

Why: Object pronouns. [[French#^fr-Q0525|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Ne%20t%27inqui%C3%A8te%20pas.%20Nous%20la%20trouverons.)
^fr-Q0525-answer

**fr-Q0526** — Ne t'inquiète pas. Nous la trouverons.

Don't worry. We'll find it.

Why: Object pronouns. [[French#^fr-Q0526|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Ne%20t%27inqui%C3%A8te%20pas.%20Nous%20la%20trouverons.)
^fr-Q0526-answer

**fr-Q0527** — Mes parents ne me laissaient rien faire.

My parents never let me do anything.

Why: Object pronouns. [[French#^fr-Q0527|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Mes%20parents%20ne%20me%20laissaient%20rien%20faire.)
^fr-Q0527-answer

**fr-Q0528** — Mes parents ne me laissaient rien faire.

My parents never let me do anything.

Direct and indirect object pronouns differ. Lui/leur often replace an animate à-complement; le/la/les replace direct objects. Pronouns generally precede the finite verb, with special imperative ordering.

Why: Object pronouns. [[French#^fr-Q0528|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Mes%20parents%20ne%20me%20laissaient%20rien%20faire.)
^fr-Q0528-answer

**fr-Q0529** — Je trouve très ennuyeux d'apprendre les verbes irréguliers.

I find it very boring to learn irregular verbs.

Expected form: **les**

Why: Object pronouns. [[French#^fr-Q0529|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20trouve%20tr%C3%A8s%20ennuyeux%20d%27apprendre%20les%20verbes%20irr%C3%A9guliers.)
^fr-Q0529-answer

**fr-Q0530** — Je trouve très ennuyeux d'apprendre les verbes irréguliers.

I find it very boring to learn irregular verbs.

Expected form: **les**

Why: Object pronouns. [[French#^fr-Q0530|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20trouve%20tr%C3%A8s%20ennuyeux%20d%27apprendre%20les%20verbes%20irr%C3%A9guliers.)
^fr-Q0530-answer

**fr-Q0531** — Apporte-moi le journal.

Bring me the newspaper.

Expected form: **le**

Why: Object pronouns. [[French#^fr-Q0531|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Apporte-moi%20le%20journal.)
^fr-Q0531-answer

**fr-Q0532** — Apporte-moi le journal.

Bring me the newspaper.

Why: Object pronouns. [[French#^fr-Q0532|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Apporte-moi%20le%20journal.)
^fr-Q0532-answer

**fr-Q0533** — Tom accompagnera les enfants à l'école.

Tom will accompany the children to school.

Why: Object pronouns. [[French#^fr-Q0533|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tom%20accompagnera%20les%20enfants%20%C3%A0%20l%27%C3%A9cole.)
^fr-Q0533-answer

**fr-Q0534** — Tom accompagnera les enfants à l'école.

Tom will accompany the children to school.

Direct and indirect object pronouns differ. Lui/leur often replace an animate à-complement; le/la/les replace direct objects. Pronouns generally precede the finite verb, with special imperative ordering.

Why: Object pronouns. [[French#^fr-Q0534|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tom%20accompagnera%20les%20enfants%20%C3%A0%20l%27%C3%A9cole.)
^fr-Q0534-answer

**fr-Q0535** — Les minutes de nos discussions sont tenues par le secrétaire.

The records of our discussions are kept by the secretary.

Expected form: **Les**

Why: Object pronouns. [[French#^fr-Q0535|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Les%20minutes%20de%20nos%20discussions%20sont%20tenues%20par%20le%20secr%C3%A9taire.)
^fr-Q0535-answer

**fr-Q0536** — Les minutes de nos discussions sont tenues par le secrétaire.

The records of our discussions are kept by the secretary.

Expected form: **Les**

Why: Object pronouns. [[French#^fr-Q0536|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Les%20minutes%20de%20nos%20discussions%20sont%20tenues%20par%20le%20secr%C3%A9taire.)
^fr-Q0536-answer

**fr-Q0537** — Vous me rappelez ma fille.

You remind me of my daughter.

Expected form: **Vous**

Why: Object pronouns. [[French#^fr-Q0537|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Vous%20me%20rappelez%20ma%20fille.)
^fr-Q0537-answer

**fr-Q0538** — Vous me rappelez ma fille.

You remind me of my daughter.

Why: Object pronouns. [[French#^fr-Q0538|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Vous%20me%20rappelez%20ma%20fille.)
^fr-Q0538-answer

**fr-Q0539** — Vous n'êtes pas assez rapide.

You're not fast enough.

Why: Object pronouns. [[French#^fr-Q0539|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Vous%20n%27%C3%AAtes%20pas%20assez%20rapide.)
^fr-Q0539-answer

**fr-Q0540** — Vous n'êtes pas assez rapide.

You're not fast enough.

Direct and indirect object pronouns differ. Lui/leur often replace an animate à-complement; le/la/les replace direct objects. Pronouns generally precede the finite verb, with special imperative ordering.

Why: Object pronouns. [[French#^fr-Q0540|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Vous%20n%27%C3%AAtes%20pas%20assez%20rapide.)
^fr-Q0540-answer

**fr-Q0541** — Je peux personnellement vous en assurer.

I can give you my personal assurance of that.

Expected form: **vous**

Why: Object pronouns. [[French#^fr-Q0541|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20peux%20personnellement%20vous%20en%20assurer.)
^fr-Q0541-answer

**fr-Q0542** — Je peux personnellement vous en assurer.

I can give you my personal assurance of that.

Expected form: **vous**

Why: Object pronouns. [[French#^fr-Q0542|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20peux%20personnellement%20vous%20en%20assurer.)
^fr-Q0542-answer

**fr-Q0543** — Vous auriez pu être heureuse.

You could have been happy.

Expected form: **Vous**

Why: Object pronouns. [[French#^fr-Q0543|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Vous%20auriez%20pu%20%C3%AAtre%20heureuse.)
^fr-Q0543-answer

**fr-Q0544** — Vous auriez pu être heureuse.

You could have been happy.

Why: Object pronouns. [[French#^fr-Q0544|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Vous%20auriez%20pu%20%C3%AAtre%20heureuse.)
^fr-Q0544-answer

**fr-Q0545** — Le roi gouvernait le pays.

The king governed the country.

Why: Object pronouns. [[French#^fr-Q0545|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Le%20roi%20gouvernait%20le%20pays.)
^fr-Q0545-answer

**fr-Q0546** — Le roi gouvernait le pays.

The king governed the country.

Direct and indirect object pronouns differ. Lui/leur often replace an animate à-complement; le/la/les replace direct objects. Pronouns generally precede the finite verb, with special imperative ordering.

Why: Object pronouns. [[French#^fr-Q0546|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Le%20roi%20gouvernait%20le%20pays.)
^fr-Q0546-answer

**fr-Q0547** — Deux des choses les plus importantes dont tu puisses disposer dans ta vie sont les amis et les rêves.

Two of the most important things you can have in your life are friendships and dreams.

Expected form: **les**

Why: Object pronouns. [[French#^fr-Q0547|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Deux%20des%20choses%20les%20plus%20importantes%20dont%20tu%20puisses%20disposer%20dans%20ta%20vie%20sont%20les%20amis%20et%20les%20r%C3%AAves.)
^fr-Q0547-answer

**fr-Q0548** — Deux des choses les plus importantes dont tu puisses disposer dans ta vie sont les amis et les rêves.

Two of the most important things you can have in your life are friendships and dreams.

Expected form: **les**

Why: Object pronouns. [[French#^fr-Q0548|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Deux%20des%20choses%20les%20plus%20importantes%20dont%20tu%20puisses%20disposer%20dans%20ta%20vie%20sont%20les%20amis%20et%20les%20r%C3%AAves.)
^fr-Q0548-answer

**fr-Q0549** — Nous devons réduire les coûts.

We need to cut costs.

Expected form: **Nous**

Why: Object pronouns. [[French#^fr-Q0549|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Nous%20devons%20r%C3%A9duire%20les%20co%C3%BBts.)
^fr-Q0549-answer

**fr-Q0550** — Nous devons réduire les coûts.

We need to cut costs.

Why: Object pronouns. [[French#^fr-Q0550|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Nous%20devons%20r%C3%A9duire%20les%20co%C3%BBts.)
^fr-Q0550-answer


### Answers 551–600

**fr-Q0551** — Il sait comment se tenir en public.

He knows how to behave in public.

Why: Y and en. [[French#^fr-Q0551|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Il%20sait%20comment%20se%20tenir%20en%20public.)
^fr-Q0551-answer

**fr-Q0552** — Il sait comment se tenir en public.

He knows how to behave in public.

Y often replaces a place or an à + non-person complement. En often replaces a de-complement or partitive quantity. Retain an expressed number when needed: J’en ai deux. En can also begin a different construction, so inspect context.

Why: Y and en. [[French#^fr-Q0552|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Il%20sait%20comment%20se%20tenir%20en%20public.)
^fr-Q0552-answer

**fr-Q0553** — On n'en est jamais certain.

You never know for sure.

Expected form: **en**

Why: Y and en. [[French#^fr-Q0553|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=On%20n%27en%20est%20jamais%20certain.)
^fr-Q0553-answer

**fr-Q0554** — On n'en est jamais certain.

You never know for sure.

Expected form: **en**

Why: Y and en. [[French#^fr-Q0554|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=On%20n%27en%20est%20jamais%20certain.)
^fr-Q0554-answer

**fr-Q0555** — Je suis en léger surpoids.

I'm a little overweight.

Expected form: **en**

Why: Y and en. [[French#^fr-Q0555|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20suis%20en%20l%C3%A9ger%20surpoids.)
^fr-Q0555-answer

**fr-Q0556** — Je suis en léger surpoids.

I'm a little overweight.

Why: Y and en. [[French#^fr-Q0556|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20suis%20en%20l%C3%A9ger%20surpoids.)
^fr-Q0556-answer

**fr-Q0557** — Il semble y avoir un sens caché dans ses mots.

There seems to be a hidden meaning to his words.

Why: Y and en. [[French#^fr-Q0557|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Il%20semble%20y%20avoir%20un%20sens%20cach%C3%A9%20dans%20ses%20mots.)
^fr-Q0557-answer

**fr-Q0558** — Il semble y avoir un sens caché dans ses mots.

There seems to be a hidden meaning to his words.

Y often replaces a place or an à + non-person complement. En often replaces a de-complement or partitive quantity. Retain an expressed number when needed: J’en ai deux. En can also begin a different construction, so inspect context.

Why: Y and en. [[French#^fr-Q0558|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Il%20semble%20y%20avoir%20un%20sens%20cach%C3%A9%20dans%20ses%20mots.)
^fr-Q0558-answer

**fr-Q0559** — Nous y connûmes une expérience désagréable.

We had an unpleasant experience there.

Expected form: **y**

Why: Y and en. [[French#^fr-Q0559|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Nous%20y%20conn%C3%BBmes%20une%20exp%C3%A9rience%20d%C3%A9sagr%C3%A9able.)
^fr-Q0559-answer

**fr-Q0560** — Nous y connûmes une expérience désagréable.

We had an unpleasant experience there.

Expected form: **y**

Why: Y and en. [[French#^fr-Q0560|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Nous%20y%20conn%C3%BBmes%20une%20exp%C3%A9rience%20d%C3%A9sagr%C3%A9able.)
^fr-Q0560-answer

**fr-Q0561** — Nous en sommes pour ainsi dire certains.

We're quite certain of that.

Expected form: **en**

Why: Y and en. [[French#^fr-Q0561|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Nous%20en%20sommes%20pour%20ainsi%20dire%20certains.)
^fr-Q0561-answer

**fr-Q0562** — Nous en sommes pour ainsi dire certains.

We're quite certain of that.

Why: Y and en. [[French#^fr-Q0562|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Nous%20en%20sommes%20pour%20ainsi%20dire%20certains.)
^fr-Q0562-answer

**fr-Q0563** — Les éléphants vivent en Asie et en Afrique.

Elephants live in Asia and Africa.

Why: Y and en. [[French#^fr-Q0563|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Les%20%C3%A9l%C3%A9phants%20vivent%20en%20Asie%20et%20en%20Afrique.)
^fr-Q0563-answer

**fr-Q0564** — Les éléphants vivent en Asie et en Afrique.

Elephants live in Asia and Africa.

Y often replaces a place or an à + non-person complement. En often replaces a de-complement or partitive quantity. Retain an expressed number when needed: J’en ai deux. En can also begin a different construction, so inspect context.

Why: Y and en. [[French#^fr-Q0564|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Les%20%C3%A9l%C3%A9phants%20vivent%20en%20Asie%20et%20en%20Afrique.)
^fr-Q0564-answer

**fr-Q0565** — Tu ne veux pas aller en prison, si ?

You don't want to go to prison, do you?

Expected form: **en**

Why: Y and en. [[French#^fr-Q0565|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tu%20ne%20veux%20pas%20aller%20en%20prison%2C%20si%20%3F)
^fr-Q0565-answer

**fr-Q0566** — Tu ne veux pas aller en prison, si ?

You don't want to go to prison, do you?

Expected form: **en**

Why: Y and en. [[French#^fr-Q0566|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tu%20ne%20veux%20pas%20aller%20en%20prison%2C%20si%20%3F)
^fr-Q0566-answer

**fr-Q0567** — J'ai un ami qui habite en Angleterre.

I have a friend who lives in England.

Expected form: **en**

Why: Y and en. [[French#^fr-Q0567|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=J%27ai%20un%20ami%20qui%20habite%20en%20Angleterre.)
^fr-Q0567-answer

**fr-Q0568** — J'ai un ami qui habite en Angleterre.

I have a friend who lives in England.

Why: Y and en. [[French#^fr-Q0568|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=J%27ai%20un%20ami%20qui%20habite%20en%20Angleterre.)
^fr-Q0568-answer

**fr-Q0569** — Je veux en entendre plus sur ton voyage.

I want to hear more about your trip.

Why: Y and en. [[French#^fr-Q0569|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20veux%20en%20entendre%20plus%20sur%20ton%20voyage.)
^fr-Q0569-answer

**fr-Q0570** — Je veux en entendre plus sur ton voyage.

I want to hear more about your trip.

Y often replaces a place or an à + non-person complement. En often replaces a de-complement or partitive quantity. Retain an expressed number when needed: J’en ai deux. En can also begin a different construction, so inspect context.

Why: Y and en. [[French#^fr-Q0570|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20veux%20en%20entendre%20plus%20sur%20ton%20voyage.)
^fr-Q0570-answer

**fr-Q0571** — J'ai dépensé tout mon salaire en une journée.

I spent all my wages in one day.

Expected form: **en**

Why: Y and en. [[French#^fr-Q0571|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=J%27ai%20d%C3%A9pens%C3%A9%20tout%20mon%20salaire%20en%20une%20journ%C3%A9e.)
^fr-Q0571-answer

**fr-Q0572** — J'ai dépensé tout mon salaire en une journée.

I spent all my wages in one day.

Expected form: **en**

Why: Y and en. [[French#^fr-Q0572|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=J%27ai%20d%C3%A9pens%C3%A9%20tout%20mon%20salaire%20en%20une%20journ%C3%A9e.)
^fr-Q0572-answer

**fr-Q0573** — Elle semble réservée mais elle a en vérité une forte volonté.

She seems reserved, but she's actually a strong-willed person.

Expected form: **en**

Why: Y and en. [[French#^fr-Q0573|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Elle%20semble%20r%C3%A9serv%C3%A9e%20mais%20elle%20a%20en%20v%C3%A9rit%C3%A9%20une%20forte%20volont%C3%A9.)
^fr-Q0573-answer

**fr-Q0574** — Elle semble réservée mais elle a en vérité une forte volonté.

She seems reserved, but she's actually a strong-willed person.

Why: Y and en. [[French#^fr-Q0574|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Elle%20semble%20r%C3%A9serv%C3%A9e%20mais%20elle%20a%20en%20v%C3%A9rit%C3%A9%20une%20forte%20volont%C3%A9.)
^fr-Q0574-answer

**fr-Q0575** — Il écouta les nouvelles à la radio en nourrissant son chien.

He listened to the news on the radio as he fed his dog.

Why: Y and en. [[French#^fr-Q0575|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Il%20%C3%A9couta%20les%20nouvelles%20%C3%A0%20la%20radio%20en%20nourrissant%20son%20chien.)
^fr-Q0575-answer

**fr-Q0576** — Il écouta les nouvelles à la radio en nourrissant son chien.

He listened to the news on the radio as he fed his dog.

Y often replaces a place or an à + non-person complement. En often replaces a de-complement or partitive quantity. Retain an expressed number when needed: J’en ai deux. En can also begin a different construction, so inspect context.

Why: Y and en. [[French#^fr-Q0576|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Il%20%C3%A9couta%20les%20nouvelles%20%C3%A0%20la%20radio%20en%20nourrissant%20son%20chien.)
^fr-Q0576-answer

**fr-Q0577** — En travaillant ensemble, ils ont nettoyé toute la maison très rapidement.

Working together, they cleaned the entire house in no time.

Expected form: **En**

Why: Y and en. [[French#^fr-Q0577|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=En%20travaillant%20ensemble%2C%20ils%20ont%20nettoy%C3%A9%20toute%20la%20maison%20tr%C3%A8s%20rapidement.)
^fr-Q0577-answer

**fr-Q0578** — En travaillant ensemble, ils ont nettoyé toute la maison très rapidement.

Working together, they cleaned the entire house in no time.

Expected form: **En**

Why: Y and en. [[French#^fr-Q0578|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=En%20travaillant%20ensemble%2C%20ils%20ont%20nettoy%C3%A9%20toute%20la%20maison%20tr%C3%A8s%20rapidement.)
^fr-Q0578-answer

**fr-Q0579** — Berlin est en Allemagne.

Berlin is in Germany.

Expected form: **en**

Why: Y and en. [[French#^fr-Q0579|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Berlin%20est%20en%20Allemagne.)
^fr-Q0579-answer

**fr-Q0580** — Berlin est en Allemagne.

Berlin is in Germany.

Why: Y and en. [[French#^fr-Q0580|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Berlin%20est%20en%20Allemagne.)
^fr-Q0580-answer

**fr-Q0581** — Vous êtes assez mignons quand vous êtes en colère.

You're kind of cute when you're mad.

Why: Y and en. [[French#^fr-Q0581|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Vous%20%C3%AAtes%20assez%20mignons%20quand%20vous%20%C3%AAtes%20en%20col%C3%A8re.)
^fr-Q0581-answer

**fr-Q0582** — Vous êtes assez mignons quand vous êtes en colère.

You're kind of cute when you're mad.

Y often replaces a place or an à + non-person complement. En often replaces a de-complement or partitive quantity. Retain an expressed number when needed: J’en ai deux. En can also begin a different construction, so inspect context.

Why: Y and en. [[French#^fr-Q0582|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Vous%20%C3%AAtes%20assez%20mignons%20quand%20vous%20%C3%AAtes%20en%20col%C3%A8re.)
^fr-Q0582-answer

**fr-Q0583** — Il est en retard.

He is late.

Expected form: **en**

Why: Y and en. [[French#^fr-Q0583|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Il%20est%20en%20retard.)
^fr-Q0583-answer

**fr-Q0584** — Il est en retard.

He is late.

Expected form: **en**

Why: Y and en. [[French#^fr-Q0584|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Il%20est%20en%20retard.)
^fr-Q0584-answer

**fr-Q0585** — Je veux vivre en ville.

I want to live in the city.

Expected form: **en**

Why: Y and en. [[French#^fr-Q0585|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20veux%20vivre%20en%20ville.)
^fr-Q0585-answer

**fr-Q0586** — Je veux vivre en ville.

I want to live in the city.

Why: Y and en. [[French#^fr-Q0586|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20veux%20vivre%20en%20ville.)
^fr-Q0586-answer

**fr-Q0587** — Ces gâteaux sont en forme d'étoile.

These cookies are star-shaped.

Why: Y and en. [[French#^fr-Q0587|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Ces%20g%C3%A2teaux%20sont%20en%20forme%20d%27%C3%A9toile.)
^fr-Q0587-answer

**fr-Q0588** — Ces gâteaux sont en forme d'étoile.

These cookies are star-shaped.

Y often replaces a place or an à + non-person complement. En often replaces a de-complement or partitive quantity. Retain an expressed number when needed: J’en ai deux. En can also begin a different construction, so inspect context.

Why: Y and en. [[French#^fr-Q0588|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Ces%20g%C3%A2teaux%20sont%20en%20forme%20d%27%C3%A9toile.)
^fr-Q0588-answer

**fr-Q0589** — Tu n'es pas en position de négocier.

You're in no position to bargain.

Expected form: **en**

Why: Y and en. [[French#^fr-Q0589|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tu%20n%27es%20pas%20en%20position%20de%20n%C3%A9gocier.)
^fr-Q0589-answer

**fr-Q0590** — Tu n'es pas en position de négocier.

You're in no position to bargain.

Expected form: **en**

Why: Y and en. [[French#^fr-Q0590|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tu%20n%27es%20pas%20en%20position%20de%20n%C3%A9gocier.)
^fr-Q0590-answer

**fr-Q0591** — Que sommes-nous, en effet, qu'est ce que notre caractère, sinon la condensation de l'histoire que nous avons vécue depuis notre naissance.

What are we, indeed, what is our character, if not the concentration of the things which we have lived since our birth.

Expected form: **en**

Why: Y and en. [[French#^fr-Q0591|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Que%20sommes-nous%2C%20en%20effet%2C%20qu%27est%20ce%20que%20notre%20caract%C3%A8re%2C%20sinon%20la%20condensation%20de%20l%27histoire%20que%20nous%20avons%20v%C3%A9cue%20depuis%20notre%20naissance.)
^fr-Q0591-answer

**fr-Q0592** — Que sommes-nous, en effet, qu'est ce que notre caractère, sinon la condensation de l'histoire que nous avons vécue depuis notre naissance.

What are we, indeed, what is our character, if not the concentration of the things which we have lived since our birth.

Why: Y and en. [[French#^fr-Q0592|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Que%20sommes-nous%2C%20en%20effet%2C%20qu%27est%20ce%20que%20notre%20caract%C3%A8re%2C%20sinon%20la%20condensation%20de%20l%27histoire%20que%20nous%20avons%20v%C3%A9cue%20depuis%20notre%20naissance.)
^fr-Q0592-answer

**fr-Q0593** — Elle partagea la tarte en cinq.

She divided the cake into five pieces.

Why: Y and en. [[French#^fr-Q0593|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Elle%20partagea%20la%20tarte%20en%20cinq.)
^fr-Q0593-answer

**fr-Q0594** — Elle partagea la tarte en cinq.

She divided the cake into five pieces.

Y often replaces a place or an à + non-person complement. En often replaces a de-complement or partitive quantity. Retain an expressed number when needed: J’en ai deux. En can also begin a different construction, so inspect context.

Why: Y and en. [[French#^fr-Q0594|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Elle%20partagea%20la%20tarte%20en%20cinq.)
^fr-Q0594-answer

**fr-Q0595** — Comme mon père et mon grand-père ont beaucoup de frères et sœurs, il y a beaucoup d'enfants dans notre famille.

As my father and my grandfather have many siblings, there are a lot of kids in our family.

Expected form: **y**

Why: Y and en. [[French#^fr-Q0595|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Comme%20mon%20p%C3%A8re%20et%20mon%20grand-p%C3%A8re%20ont%20beaucoup%20de%20fr%C3%A8res%20et%20s%C5%93urs%2C%20il%20y%20a%20beaucoup%20d%27enfants%20dans%20notre%20famille.)
^fr-Q0595-answer

**fr-Q0596** — Comme mon père et mon grand-père ont beaucoup de frères et sœurs, il y a beaucoup d'enfants dans notre famille.

As my father and my grandfather have many siblings, there are a lot of kids in our family.

Expected form: **y**

Why: Y and en. [[French#^fr-Q0596|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Comme%20mon%20p%C3%A8re%20et%20mon%20grand-p%C3%A8re%20ont%20beaucoup%20de%20fr%C3%A8res%20et%20s%C5%93urs%2C%20il%20y%20a%20beaucoup%20d%27enfants%20dans%20notre%20famille.)
^fr-Q0596-answer

**fr-Q0597** — J'ai pensé que vous vous en étiez assez bien tirée.

I thought you did fairly well.

Expected form: **en**

Why: Y and en. [[French#^fr-Q0597|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=J%27ai%20pens%C3%A9%20que%20vous%20vous%20en%20%C3%A9tiez%20assez%20bien%20tir%C3%A9e.)
^fr-Q0597-answer

**fr-Q0598** — J'ai pensé que vous vous en étiez assez bien tirée.

I thought you did fairly well.

Why: Y and en. [[French#^fr-Q0598|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=J%27ai%20pens%C3%A9%20que%20vous%20vous%20en%20%C3%A9tiez%20assez%20bien%20tir%C3%A9e.)
^fr-Q0598-answer

**fr-Q0599** — J'ai commencé à travailler il y a environ 4 semaines.

I started working about 4 weeks ago.

Why: Y and en. [[French#^fr-Q0599|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=J%27ai%20commenc%C3%A9%20%C3%A0%20travailler%20il%20y%20a%20environ%204%20semaines.)
^fr-Q0599-answer

**fr-Q0600** — J'ai commencé à travailler il y a environ 4 semaines.

I started working about 4 weeks ago.

Y often replaces a place or an à + non-person complement. En often replaces a de-complement or partitive quantity. Retain an expressed number when needed: J’en ai deux. En can also begin a different construction, so inspect context.

Why: Y and en. [[French#^fr-Q0600|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=J%27ai%20commenc%C3%A9%20%C3%A0%20travailler%20il%20y%20a%20environ%204%20semaines.)
^fr-Q0600-answer


### Answers 601–650

**fr-Q0601** — Attends ici jusqu'à ce que je revienne !

Wait here until I come back.

Expected form: **que**

Why: Relative clauses. [[French#^fr-Q0601|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Attends%20ici%20jusqu%27%C3%A0%20ce%20que%20je%20revienne%20%21)
^fr-Q0601-answer

**fr-Q0602** — Attends ici jusqu'à ce que je revienne !

Wait here until I come back.

Expected form: **que**

Why: Relative clauses. [[French#^fr-Q0602|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Attends%20ici%20jusqu%27%C3%A0%20ce%20que%20je%20revienne%20%21)
^fr-Q0602-answer

**fr-Q0603** — Tom semble être conscient de ce qui se passe.

Tom seems to be aware of what's happening.

Expected form: **qui**

Why: Relative clauses. [[French#^fr-Q0603|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tom%20semble%20%C3%AAtre%20conscient%20de%20ce%20qui%20se%20passe.)
^fr-Q0603-answer

**fr-Q0604** — Tom semble être conscient de ce qui se passe.

Tom seems to be aware of what's happening.

Why: Relative clauses. [[French#^fr-Q0604|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tom%20semble%20%C3%AAtre%20conscient%20de%20ce%20qui%20se%20passe.)
^fr-Q0604-answer

**fr-Q0605** — Où vis-tu exactement ?

Where exactly do you live?

Why: Relative clauses. [[French#^fr-Q0605|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=O%C3%B9%20vis-tu%20exactement%20%3F)
^fr-Q0605-answer

**fr-Q0606** — Où vis-tu exactement ?

Where exactly do you live?

Qui is a relative subject; que a relative direct object; dont normally replaces a de relation; où relates place or time. Que also has other functions. Determine the role within the clause.

Why: Relative clauses. [[French#^fr-Q0606|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=O%C3%B9%20vis-tu%20exactement%20%3F)
^fr-Q0606-answer

**fr-Q0607** — Les enfants veulent souvent faire des choses qui sont dangereuses, sans savoir qu'elles sont dangereuses.

Children often want to do things that are dangerous without knowing that they are dangerous.

Expected form: **qui**

Why: Relative clauses. [[French#^fr-Q0607|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Les%20enfants%20veulent%20souvent%20faire%20des%20choses%20qui%20sont%20dangereuses%2C%20sans%20savoir%20qu%27elles%20sont%20dangereuses.)
^fr-Q0607-answer

**fr-Q0608** — Les enfants veulent souvent faire des choses qui sont dangereuses, sans savoir qu'elles sont dangereuses.

Children often want to do things that are dangerous without knowing that they are dangerous.

Expected form: **qui**

Why: Relative clauses. [[French#^fr-Q0608|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Les%20enfants%20veulent%20souvent%20faire%20des%20choses%20qui%20sont%20dangereuses%2C%20sans%20savoir%20qu%27elles%20sont%20dangereuses.)
^fr-Q0608-answer

**fr-Q0609** — Est-ce là ce que vous pensez que je veuille entendre ?

Is that what you think I want to hear?

Expected form: **que**

Why: Relative clauses. [[French#^fr-Q0609|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Est-ce%20l%C3%A0%20ce%20que%20vous%20pensez%20que%20je%20veuille%20entendre%20%3F)
^fr-Q0609-answer

**fr-Q0610** — Est-ce là ce que vous pensez que je veuille entendre ?

Is that what you think I want to hear?

Why: Relative clauses. [[French#^fr-Q0610|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Est-ce%20l%C3%A0%20ce%20que%20vous%20pensez%20que%20je%20veuille%20entendre%20%3F)
^fr-Q0610-answer

**fr-Q0611** — Je pense que vous êtes marrant.

I think you're funny.

Why: Relative clauses. [[French#^fr-Q0611|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20pense%20que%20vous%20%C3%AAtes%20marrant.)
^fr-Q0611-answer

**fr-Q0612** — Je pense que vous êtes marrant.

I think you're funny.

Qui is a relative subject; que a relative direct object; dont normally replaces a de relation; où relates place or time. Que also has other functions. Determine the role within the clause.

Why: Relative clauses. [[French#^fr-Q0612|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20pense%20que%20vous%20%C3%AAtes%20marrant.)
^fr-Q0612-answer

**fr-Q0613** — Je ne serai jamais aussi bonne que toi.

I'll never be as good as you.

Expected form: **que**

Why: Relative clauses. [[French#^fr-Q0613|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20ne%20serai%20jamais%20aussi%20bonne%20que%20toi.)
^fr-Q0613-answer

**fr-Q0614** — Je ne serai jamais aussi bonne que toi.

I'll never be as good as you.

Expected form: **que**

Why: Relative clauses. [[French#^fr-Q0614|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20ne%20serai%20jamais%20aussi%20bonne%20que%20toi.)
^fr-Q0614-answer

**fr-Q0615** — Je promets que je prendrai bien soin de votre chien.

I promise I'll take good care of your dog.

Expected form: **que**

Why: Relative clauses. [[French#^fr-Q0615|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20promets%20que%20je%20prendrai%20bien%20soin%20de%20votre%20chien.)
^fr-Q0615-answer

**fr-Q0616** — Je promets que je prendrai bien soin de votre chien.

I promise I'll take good care of your dog.

Why: Relative clauses. [[French#^fr-Q0616|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20promets%20que%20je%20prendrai%20bien%20soin%20de%20votre%20chien.)
^fr-Q0616-answer

**fr-Q0617** — Les femmes sont physiquement plus faibles que les hommes.

Women are physically weaker than men.

Why: Relative clauses. [[French#^fr-Q0617|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Les%20femmes%20sont%20physiquement%20plus%20faibles%20que%20les%20hommes.)
^fr-Q0617-answer

**fr-Q0618** — Les femmes sont physiquement plus faibles que les hommes.

Women are physically weaker than men.

Qui is a relative subject; que a relative direct object; dont normally replaces a de relation; où relates place or time. Que also has other functions. Determine the role within the clause.

Why: Relative clauses. [[French#^fr-Q0618|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Les%20femmes%20sont%20physiquement%20plus%20faibles%20que%20les%20hommes.)
^fr-Q0618-answer

**fr-Q0619** — Chaque fois que je trouve quelque chose que j'aime, c'est trop cher.

Whenever I find something I like, it's too expensive.

Expected form: **que**

Why: Relative clauses. [[French#^fr-Q0619|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Chaque%20fois%20que%20je%20trouve%20quelque%20chose%20que%20j%27aime%2C%20c%27est%20trop%20cher.)
^fr-Q0619-answer

**fr-Q0620** — Chaque fois que je trouve quelque chose que j'aime, c'est trop cher.

Whenever I find something I like, it's too expensive.

Expected form: **que**

Why: Relative clauses. [[French#^fr-Q0620|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Chaque%20fois%20que%20je%20trouve%20quelque%20chose%20que%20j%27aime%2C%20c%27est%20trop%20cher.)
^fr-Q0620-answer

**fr-Q0621** — Honnêtement, je ne pense pas que vous ayez l’étoffe pour devenir enseignante.

Honestly, I don't think you have what it takes to become a teacher.

Expected form: **que**

Why: Relative clauses. [[French#^fr-Q0621|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Honn%C3%AAtement%2C%20je%20ne%20pense%20pas%20que%20vous%20ayez%20l%E2%80%99%C3%A9toffe%20pour%20devenir%20enseignante.)
^fr-Q0621-answer

**fr-Q0622** — Honnêtement, je ne pense pas que vous ayez l’étoffe pour devenir enseignante.

Honestly, I don't think you have what it takes to become a teacher.

Why: Relative clauses. [[French#^fr-Q0622|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Honn%C3%AAtement%2C%20je%20ne%20pense%20pas%20que%20vous%20ayez%20l%E2%80%99%C3%A9toffe%20pour%20devenir%20enseignante.)
^fr-Q0622-answer

**fr-Q0623** — Tu es enfant de l'univers, tout autant que les arbres et les étoiles ; tu as droit à te trouver ici.

You are a child of the universe, no less than the trees and the stars; you have a right to be here.

Why: Relative clauses. [[French#^fr-Q0623|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tu%20es%20enfant%20de%20l%27univers%2C%20tout%20autant%20que%20les%20arbres%20et%20les%20%C3%A9toiles%20%3B%20tu%20as%20droit%20%C3%A0%20te%20trouver%20ici.)
^fr-Q0623-answer

**fr-Q0624** — Tu es enfant de l'univers, tout autant que les arbres et les étoiles ; tu as droit à te trouver ici.

You are a child of the universe, no less than the trees and the stars; you have a right to be here.

Qui is a relative subject; que a relative direct object; dont normally replaces a de relation; où relates place or time. Que also has other functions. Determine the role within the clause.

Why: Relative clauses. [[French#^fr-Q0624|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tu%20es%20enfant%20de%20l%27univers%2C%20tout%20autant%20que%20les%20arbres%20et%20les%20%C3%A9toiles%20%3B%20tu%20as%20droit%20%C3%A0%20te%20trouver%20ici.)
^fr-Q0624-answer

**fr-Q0625** — Est-ce que c'est ta chanson préférée ?

Is this your favorite song?

Expected form: **que**

Why: Relative clauses. [[French#^fr-Q0625|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Est-ce%20que%20c%27est%20ta%20chanson%20pr%C3%A9f%C3%A9r%C3%A9e%20%3F)
^fr-Q0625-answer

**fr-Q0626** — Est-ce que c'est ta chanson préférée ?

Is this your favorite song?

Expected form: **que**

Why: Relative clauses. [[French#^fr-Q0626|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Est-ce%20que%20c%27est%20ta%20chanson%20pr%C3%A9f%C3%A9r%C3%A9e%20%3F)
^fr-Q0626-answer

**fr-Q0627** — Dès que je peux avoir l'occasion, je vous enverrai de l'argent.

As soon as I can get the chance, I'll send you some money.

Expected form: **que**

Why: Relative clauses. [[French#^fr-Q0627|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=D%C3%A8s%20que%20je%20peux%20avoir%20l%27occasion%2C%20je%20vous%20enverrai%20de%20l%27argent.)
^fr-Q0627-answer

**fr-Q0628** — Dès que je peux avoir l'occasion, je vous enverrai de l'argent.

As soon as I can get the chance, I'll send you some money.

Why: Relative clauses. [[French#^fr-Q0628|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=D%C3%A8s%20que%20je%20peux%20avoir%20l%27occasion%2C%20je%20vous%20enverrai%20de%20l%27argent.)
^fr-Q0628-answer

**fr-Q0629** — As-tu une idée de ce que c'est ?

Do you have any idea what that is?

Why: Relative clauses. [[French#^fr-Q0629|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=As-tu%20une%20id%C3%A9e%20de%20ce%20que%20c%27est%20%3F)
^fr-Q0629-answer

**fr-Q0630** — As-tu une idée de ce que c'est ?

Do you have any idea what that is?

Qui is a relative subject; que a relative direct object; dont normally replaces a de relation; où relates place or time. Que also has other functions. Determine the role within the clause.

Why: Relative clauses. [[French#^fr-Q0630|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=As-tu%20une%20id%C3%A9e%20de%20ce%20que%20c%27est%20%3F)
^fr-Q0630-answer

**fr-Q0631** — Tom pensait probablement que j'étais assoiffée.

Tom probably thought I was thirsty.

Expected form: **que**

Why: Relative clauses. [[French#^fr-Q0631|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tom%20pensait%20probablement%20que%20j%27%C3%A9tais%20assoiff%C3%A9e.)
^fr-Q0631-answer

**fr-Q0632** — Tom pensait probablement que j'étais assoiffée.

Tom probably thought I was thirsty.

Expected form: **que**

Why: Relative clauses. [[French#^fr-Q0632|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tom%20pensait%20probablement%20que%20j%27%C3%A9tais%20assoiff%C3%A9e.)
^fr-Q0632-answer

**fr-Q0633** — Est-ce que ce chapeau est à toi ?

Is this hat yours?

Expected form: **que**

Why: Relative clauses. [[French#^fr-Q0633|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Est-ce%20que%20ce%20chapeau%20est%20%C3%A0%20toi%20%3F)
^fr-Q0633-answer

**fr-Q0634** — Est-ce que ce chapeau est à toi ?

Is this hat yours?

Why: Relative clauses. [[French#^fr-Q0634|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Est-ce%20que%20ce%20chapeau%20est%20%C3%A0%20toi%20%3F)
^fr-Q0634-answer

**fr-Q0635** — Je pense qu'il est temps que je demande des instructions.

I think it's time for me to ask for directions.

Why: Relative clauses. [[French#^fr-Q0635|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20pense%20qu%27il%20est%20temps%20que%20je%20demande%20des%20instructions.)
^fr-Q0635-answer

**fr-Q0636** — Je pense qu'il est temps que je demande des instructions.

I think it's time for me to ask for directions.

Qui is a relative subject; que a relative direct object; dont normally replaces a de relation; où relates place or time. Que also has other functions. Determine the role within the clause.

Why: Relative clauses. [[French#^fr-Q0636|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20pense%20qu%27il%20est%20temps%20que%20je%20demande%20des%20instructions.)
^fr-Q0636-answer

**fr-Q0637** — Je veux que vous descendiez de mon dos.

I want you to get off my back.

Expected form: **que**

Why: Relative clauses. [[French#^fr-Q0637|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20veux%20que%20vous%20descendiez%20de%20mon%20dos.)
^fr-Q0637-answer

**fr-Q0638** — Je veux que vous descendiez de mon dos.

I want you to get off my back.

Expected form: **que**

Why: Relative clauses. [[French#^fr-Q0638|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20veux%20que%20vous%20descendiez%20de%20mon%20dos.)
^fr-Q0638-answer

**fr-Q0639** — Je veux que tu sois mon patron.

I want you to be my manager.

Expected form: **que**

Why: Relative clauses. [[French#^fr-Q0639|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20veux%20que%20tu%20sois%20mon%20patron.)
^fr-Q0639-answer

**fr-Q0640** — Je veux que tu sois mon patron.

I want you to be my manager.

Why: Relative clauses. [[French#^fr-Q0640|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20veux%20que%20tu%20sois%20mon%20patron.)
^fr-Q0640-answer

**fr-Q0641** — Chien qui aboie ne mord pas.

Barking dogs seldom bite.

Why: Relative clauses. [[French#^fr-Q0641|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Chien%20qui%20aboie%20ne%20mord%20pas.)
^fr-Q0641-answer

**fr-Q0642** — Chien qui aboie ne mord pas.

Barking dogs seldom bite.

Qui is a relative subject; que a relative direct object; dont normally replaces a de relation; où relates place or time. Que also has other functions. Determine the role within the clause.

Why: Relative clauses. [[French#^fr-Q0642|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Chien%20qui%20aboie%20ne%20mord%20pas.)
^fr-Q0642-answer

**fr-Q0643** — J'espérais que nous puissions encore être amis.

I was hoping we could still be friends.

Expected form: **que**

Why: Relative clauses. [[French#^fr-Q0643|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=J%27esp%C3%A9rais%20que%20nous%20puissions%20encore%20%C3%AAtre%20amis.)
^fr-Q0643-answer

**fr-Q0644** — J'espérais que nous puissions encore être amis.

I was hoping we could still be friends.

Expected form: **que**

Why: Relative clauses. [[French#^fr-Q0644|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=J%27esp%C3%A9rais%20que%20nous%20puissions%20encore%20%C3%AAtre%20amis.)
^fr-Q0644-answer

**fr-Q0645** — Les gens croient que Dieu existe.

People believe that god exists.

Expected form: **que**

Why: Relative clauses. [[French#^fr-Q0645|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Les%20gens%20croient%20que%20Dieu%20existe.)
^fr-Q0645-answer

**fr-Q0646** — Les gens croient que Dieu existe.

People believe that god exists.

Why: Relative clauses. [[French#^fr-Q0646|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Les%20gens%20croient%20que%20Dieu%20existe.)
^fr-Q0646-answer

**fr-Q0647** — Même si nous avons perdu la partie, je dois dire que nous avons joué le meilleur football.

Even though we lost the game, I have to say that we played the better football.

Why: Relative clauses. [[French#^fr-Q0647|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=M%C3%AAme%20si%20nous%20avons%20perdu%20la%20partie%2C%20je%20dois%20dire%20que%20nous%20avons%20jou%C3%A9%20le%20meilleur%20football.)
^fr-Q0647-answer

**fr-Q0648** — Même si nous avons perdu la partie, je dois dire que nous avons joué le meilleur football.

Even though we lost the game, I have to say that we played the better football.

Qui is a relative subject; que a relative direct object; dont normally replaces a de relation; où relates place or time. Que also has other functions. Determine the role within the clause.

Why: Relative clauses. [[French#^fr-Q0648|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=M%C3%AAme%20si%20nous%20avons%20perdu%20la%20partie%2C%20je%20dois%20dire%20que%20nous%20avons%20jou%C3%A9%20le%20meilleur%20football.)
^fr-Q0648-answer

**fr-Q0649** — Est-ce que tu travailles avec Tom ?

Are you and Tom working together?

Expected form: **que**

Why: Relative clauses. [[French#^fr-Q0649|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Est-ce%20que%20tu%20travailles%20avec%20Tom%20%3F)
^fr-Q0649-answer

**fr-Q0650** — Est-ce que tu travailles avec Tom ?

Are you and Tom working together?

Expected form: **que**

Why: Relative clauses. [[French#^fr-Q0650|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Est-ce%20que%20tu%20travailles%20avec%20Tom%20%3F)
^fr-Q0650-answer


### Answers 651–700

**fr-Q0651** — Ne m'arnaquez pas !

Don't screw me over!

Expected form: **pas**

Why: Negation. [[French#^fr-Q0651|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Ne%20m%27arnaquez%20pas%20%21)
^fr-Q0651-answer

**fr-Q0652** — Ne m'arnaquez pas !

Don't screw me over!

Why: Negation. [[French#^fr-Q0652|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Ne%20m%27arnaquez%20pas%20%21)
^fr-Q0652-answer

**fr-Q0653** — Je n'aime pas qu'on se moque de moi.

I don't like being made a fool of.

Why: Negation. [[French#^fr-Q0653|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20n%27aime%20pas%20qu%27on%20se%20moque%20de%20moi.)
^fr-Q0653-answer

**fr-Q0654** — Je n'aime pas qu'on se moque de moi.

I don't like being made a fool of.

Formal French commonly uses ne with pas/jamais/rien/personne/plus. Spoken French often drops ne. Plus can mean no longer in a negative construction or more in an affirmative one; pronunciation and context matter.

Why: Negation. [[French#^fr-Q0654|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20n%27aime%20pas%20qu%27on%20se%20moque%20de%20moi.)
^fr-Q0654-answer

**fr-Q0655** — Ne dites rien à ma blonde !

Don't tell my girlfriend.

Expected form: **rien**

Why: Negation. [[French#^fr-Q0655|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Ne%20dites%20rien%20%C3%A0%20ma%20blonde%20%21)
^fr-Q0655-answer

**fr-Q0656** — Ne dites rien à ma blonde !

Don't tell my girlfriend.

Expected form: **rien**

Why: Negation. [[French#^fr-Q0656|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Ne%20dites%20rien%20%C3%A0%20ma%20blonde%20%21)
^fr-Q0656-answer

**fr-Q0657** — Je ne vois pas pourquoi je suis de mauvaise humeur ce matin.

I don't see why I am in a bad humor this morning.

Expected form: **pas**

Why: Negation. [[French#^fr-Q0657|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20ne%20vois%20pas%20pourquoi%20je%20suis%20de%20mauvaise%20humeur%20ce%20matin.)
^fr-Q0657-answer

**fr-Q0658** — Je ne vois pas pourquoi je suis de mauvaise humeur ce matin.

I don't see why I am in a bad humor this morning.

Why: Negation. [[French#^fr-Q0658|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20ne%20vois%20pas%20pourquoi%20je%20suis%20de%20mauvaise%20humeur%20ce%20matin.)
^fr-Q0658-answer

**fr-Q0659** — Ça rend les choses plus faciles si ta matrice est creuse.

It makes things easier if your matrix is sparse.

Why: Negation. [[French#^fr-Q0659|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=%C3%87a%20rend%20les%20choses%20plus%20faciles%20si%20ta%20matrice%20est%20creuse.)
^fr-Q0659-answer

**fr-Q0660** — Ça rend les choses plus faciles si ta matrice est creuse.

It makes things easier if your matrix is sparse.

Formal French commonly uses ne with pas/jamais/rien/personne/plus. Spoken French often drops ne. Plus can mean no longer in a negative construction or more in an affirmative one; pronunciation and context matter.

Why: Negation. [[French#^fr-Q0660|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=%C3%87a%20rend%20les%20choses%20plus%20faciles%20si%20ta%20matrice%20est%20creuse.)
^fr-Q0660-answer

**fr-Q0661** — Ce n'est pas loin de Boston.

It's not far to Boston.

Expected form: **pas**

Why: Negation. [[French#^fr-Q0661|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Ce%20n%27est%20pas%20loin%20de%20Boston.)
^fr-Q0661-answer

**fr-Q0662** — Ce n'est pas loin de Boston.

It's not far to Boston.

Expected form: **pas**

Why: Negation. [[French#^fr-Q0662|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Ce%20n%27est%20pas%20loin%20de%20Boston.)
^fr-Q0662-answer

**fr-Q0663** — Les choses ne se présentent pas bien.

Things are not looking good.

Expected form: **pas**

Why: Negation. [[French#^fr-Q0663|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Les%20choses%20ne%20se%20pr%C3%A9sentent%20pas%20bien.)
^fr-Q0663-answer

**fr-Q0664** — Les choses ne se présentent pas bien.

Things are not looking good.

Why: Negation. [[French#^fr-Q0664|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Les%20choses%20ne%20se%20pr%C3%A9sentent%20pas%20bien.)
^fr-Q0664-answer

**fr-Q0665** — Vous n'êtes pas mal non plus.

You're not bad looking either.

Why: Negation. [[French#^fr-Q0665|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Vous%20n%27%C3%AAtes%20pas%20mal%20non%20plus.)
^fr-Q0665-answer

**fr-Q0666** — Vous n'êtes pas mal non plus.

You're not bad looking either.

Formal French commonly uses ne with pas/jamais/rien/personne/plus. Spoken French often drops ne. Plus can mean no longer in a negative construction or more in an affirmative one; pronunciation and context matter.

Why: Negation. [[French#^fr-Q0666|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Vous%20n%27%C3%AAtes%20pas%20mal%20non%20plus.)
^fr-Q0666-answer

**fr-Q0667** — Je suis le coureur le plus rapide.

I am the fastest runner.

Expected form: **plus**

Why: Negation. [[French#^fr-Q0667|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20suis%20le%20coureur%20le%20plus%20rapide.)
^fr-Q0667-answer

**fr-Q0668** — Je suis le coureur le plus rapide.

I am the fastest runner.

Expected form: **plus**

Why: Negation. [[French#^fr-Q0668|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20suis%20le%20coureur%20le%20plus%20rapide.)
^fr-Q0668-answer

**fr-Q0669** — Je ne pus me tenir debout plus longtemps.

I could stand no more.

Expected form: **plus**

Why: Negation. [[French#^fr-Q0669|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20ne%20pus%20me%20tenir%20debout%20plus%20longtemps.)
^fr-Q0669-answer

**fr-Q0670** — Je ne pus me tenir debout plus longtemps.

I could stand no more.

Why: Negation. [[French#^fr-Q0670|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20ne%20pus%20me%20tenir%20debout%20plus%20longtemps.)
^fr-Q0670-answer

**fr-Q0671** — Je ne veux pas aller manger aujourd'hui.

I don't want to go and eat today.

Why: Negation. [[French#^fr-Q0671|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20ne%20veux%20pas%20aller%20manger%20aujourd%27hui.)
^fr-Q0671-answer

**fr-Q0672** — Je ne veux pas aller manger aujourd'hui.

I don't want to go and eat today.

Formal French commonly uses ne with pas/jamais/rien/personne/plus. Spoken French often drops ne. Plus can mean no longer in a negative construction or more in an affirmative one; pronunciation and context matter.

Why: Negation. [[French#^fr-Q0672|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20ne%20veux%20pas%20aller%20manger%20aujourd%27hui.)
^fr-Q0672-answer

**fr-Q0673** — Vous n'étiez pas sérieux, si ?

You weren't serious, were you?

Expected form: **pas**

Why: Negation. [[French#^fr-Q0673|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Vous%20n%27%C3%A9tiez%20pas%20s%C3%A9rieux%2C%20si%20%3F)
^fr-Q0673-answer

**fr-Q0674** — Vous n'étiez pas sérieux, si ?

You weren't serious, were you?

Expected form: **pas**

Why: Negation. [[French#^fr-Q0674|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Vous%20n%27%C3%A9tiez%20pas%20s%C3%A9rieux%2C%20si%20%3F)
^fr-Q0674-answer

**fr-Q0675** — Ce n'est pas facile d'écrire avec une craie.

It is not easy to write in chalk.

Expected form: **pas**

Why: Negation. [[French#^fr-Q0675|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Ce%20n%27est%20pas%20facile%20d%27%C3%A9crire%20avec%20une%20craie.)
^fr-Q0675-answer

**fr-Q0676** — Ce n'est pas facile d'écrire avec une craie.

It is not easy to write in chalk.

Why: Negation. [[French#^fr-Q0676|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Ce%20n%27est%20pas%20facile%20d%27%C3%A9crire%20avec%20une%20craie.)
^fr-Q0676-answer

**fr-Q0677** — Je n'arrive pas à trouver mon ticket. Je dois l'avoir perdu.

I can't find my ticket. I must have lost it.

Why: Negation. [[French#^fr-Q0677|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20n%27arrive%20pas%20%C3%A0%20trouver%20mon%20ticket.%20Je%20dois%20l%27avoir%20perdu.)
^fr-Q0677-answer

**fr-Q0678** — Je n'arrive pas à trouver mon ticket. Je dois l'avoir perdu.

I can't find my ticket. I must have lost it.

Formal French commonly uses ne with pas/jamais/rien/personne/plus. Spoken French often drops ne. Plus can mean no longer in a negative construction or more in an affirmative one; pronunciation and context matter.

Why: Negation. [[French#^fr-Q0678|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20n%27arrive%20pas%20%C3%A0%20trouver%20mon%20ticket.%20Je%20dois%20l%27avoir%20perdu.)
^fr-Q0678-answer

**fr-Q0679** — Il n'a pas de famille.

He doesn't have a family.

Expected form: **pas**

Why: Negation. [[French#^fr-Q0679|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Il%20n%27a%20pas%20de%20famille.)
^fr-Q0679-answer

**fr-Q0680** — Il n'a pas de famille.

He doesn't have a family.

Expected form: **pas**

Why: Negation. [[French#^fr-Q0680|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Il%20n%27a%20pas%20de%20famille.)
^fr-Q0680-answer

**fr-Q0681** — Merci de ne pas quitter.

Please hold the line.

Expected form: **pas**

Why: Negation. [[French#^fr-Q0681|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Merci%20de%20ne%20pas%20quitter.)
^fr-Q0681-answer

**fr-Q0682** — Merci de ne pas quitter.

Please hold the line.

Why: Negation. [[French#^fr-Q0682|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Merci%20de%20ne%20pas%20quitter.)
^fr-Q0682-answer

**fr-Q0683** — Je ne suis pas intimidé.

I'm not intimidated.

Why: Negation. [[French#^fr-Q0683|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20ne%20suis%20pas%20intimid%C3%A9.)
^fr-Q0683-answer

**fr-Q0684** — Je ne suis pas intimidé.

I'm not intimidated.

Formal French commonly uses ne with pas/jamais/rien/personne/plus. Spoken French often drops ne. Plus can mean no longer in a negative construction or more in an affirmative one; pronunciation and context matter.

Why: Negation. [[French#^fr-Q0684|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20ne%20suis%20pas%20intimid%C3%A9.)
^fr-Q0684-answer

**fr-Q0685** — Je ne suis pas oublieuse.

I'm not forgetful.

Expected form: **pas**

Why: Negation. [[French#^fr-Q0685|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20ne%20suis%20pas%20oublieuse.)
^fr-Q0685-answer

**fr-Q0686** — Je ne suis pas oublieuse.

I'm not forgetful.

Expected form: **pas**

Why: Negation. [[French#^fr-Q0686|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20ne%20suis%20pas%20oublieuse.)
^fr-Q0686-answer

**fr-Q0687** — Je ne suis pas une professionnelle.

I'm not a professional.

Expected form: **pas**

Why: Negation. [[French#^fr-Q0687|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20ne%20suis%20pas%20une%20professionnelle.)
^fr-Q0687-answer

**fr-Q0688** — Je ne suis pas une professionnelle.

I'm not a professional.

Why: Negation. [[French#^fr-Q0688|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20ne%20suis%20pas%20une%20professionnelle.)
^fr-Q0688-answer

**fr-Q0689** — Je n'ai pas besoin de conseillers.

I don't need advisers.

Why: Negation. [[French#^fr-Q0689|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20n%27ai%20pas%20besoin%20de%20conseillers.)
^fr-Q0689-answer

**fr-Q0690** — Je n'ai pas besoin de conseillers.

I don't need advisers.

Formal French commonly uses ne with pas/jamais/rien/personne/plus. Spoken French often drops ne. Plus can mean no longer in a negative construction or more in an affirmative one; pronunciation and context matter.

Why: Negation. [[French#^fr-Q0690|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20n%27ai%20pas%20besoin%20de%20conseillers.)
^fr-Q0690-answer

**fr-Q0691** — Je n'ai pas toute la journée.

I don't have all day.

Expected form: **pas**

Why: Negation. [[French#^fr-Q0691|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20n%27ai%20pas%20toute%20la%20journ%C3%A9e.)
^fr-Q0691-answer

**fr-Q0692** — Je n'ai pas toute la journée.

I don't have all day.

Expected form: **pas**

Why: Negation. [[French#^fr-Q0692|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20n%27ai%20pas%20toute%20la%20journ%C3%A9e.)
^fr-Q0692-answer

**fr-Q0693** — Tom ne prête pas attention.

Tom isn't paying attention.

Expected form: **pas**

Why: Negation. [[French#^fr-Q0693|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tom%20ne%20pr%C3%AAte%20pas%20attention.)
^fr-Q0693-answer

**fr-Q0694** — Tom ne prête pas attention.

Tom isn't paying attention.

Why: Negation. [[French#^fr-Q0694|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tom%20ne%20pr%C3%AAte%20pas%20attention.)
^fr-Q0694-answer

**fr-Q0695** — Ce n'est pas pour les mauviettes.

It's not for the faint of heart.

Why: Negation. [[French#^fr-Q0695|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Ce%20n%27est%20pas%20pour%20les%20mauviettes.)
^fr-Q0695-answer

**fr-Q0696** — Ce n'est pas pour les mauviettes.

It's not for the faint of heart.

Formal French commonly uses ne with pas/jamais/rien/personne/plus. Spoken French often drops ne. Plus can mean no longer in a negative construction or more in an affirmative one; pronunciation and context matter.

Why: Negation. [[French#^fr-Q0696|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Ce%20n%27est%20pas%20pour%20les%20mauviettes.)
^fr-Q0696-answer

**fr-Q0697** — Tom est déjà là, mais Bill n'est pas encore arrivé.

Tom's already here, but Bill hasn't come yet.

Expected form: **pas**

Why: Negation. [[French#^fr-Q0697|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tom%20est%20d%C3%A9j%C3%A0%20l%C3%A0%2C%20mais%20Bill%20n%27est%20pas%20encore%20arriv%C3%A9.)
^fr-Q0697-answer

**fr-Q0698** — Tom est déjà là, mais Bill n'est pas encore arrivé.

Tom's already here, but Bill hasn't come yet.

Expected form: **pas**

Why: Negation. [[French#^fr-Q0698|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tom%20est%20d%C3%A9j%C3%A0%20l%C3%A0%2C%20mais%20Bill%20n%27est%20pas%20encore%20arriv%C3%A9.)
^fr-Q0698-answer

**fr-Q0699** — Je ne m'intéresse pas à la nourriture étrangère.

I don't care for foreign food.

Expected form: **pas**

Why: Negation. [[French#^fr-Q0699|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20ne%20m%27int%C3%A9resse%20pas%20%C3%A0%20la%20nourriture%20%C3%A9trang%C3%A8re.)
^fr-Q0699-answer

**fr-Q0700** — Je ne m'intéresse pas à la nourriture étrangère.

I don't care for foreign food.

Why: Negation. [[French#^fr-Q0700|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20ne%20m%27int%C3%A9resse%20pas%20%C3%A0%20la%20nourriture%20%C3%A9trang%C3%A8re.)
^fr-Q0700-answer


### Answers 701–750

**fr-Q0701** — Combien de tuyaux compte cet orgue ?

How many pipes does this organ have?

Why: Questions and indirect questions. [[French#^fr-Q0701|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Combien%20de%20tuyaux%20compte%20cet%20orgue%20%3F)
^fr-Q0701-answer

**fr-Q0702** — Combien de tuyaux compte cet orgue ?

How many pipes does this organ have?

Questions can use intonation, est-ce que or inversion. An indirect question normally keeps statement order. Si introduces an indirect yes/no question as well as a condition in other contexts.

Why: Questions and indirect questions. [[French#^fr-Q0702|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Combien%20de%20tuyaux%20compte%20cet%20orgue%20%3F)
^fr-Q0702-answer

**fr-Q0703** — Combien la chemise coûte-t-elle ?

How much does the shirt cost?

Expected form: **Combien**

Why: Questions and indirect questions. [[French#^fr-Q0703|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Combien%20la%20chemise%20co%C3%BBte-t-elle%20%3F)
^fr-Q0703-answer

**fr-Q0704** — Combien la chemise coûte-t-elle ?

How much does the shirt cost?

Expected form: **Combien**

Why: Questions and indirect questions. [[French#^fr-Q0704|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Combien%20la%20chemise%20co%C3%BBte-t-elle%20%3F)
^fr-Q0704-answer

**fr-Q0705** — Comment trouvez-vous Kyoto ?

How do you like Kyoto?

Expected form: **Comment**

Why: Questions and indirect questions. [[French#^fr-Q0705|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Comment%20trouvez-vous%20Kyoto%20%3F)
^fr-Q0705-answer

**fr-Q0706** — Comment trouvez-vous Kyoto ?

How do you like Kyoto?

Why: Questions and indirect questions. [[French#^fr-Q0706|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Comment%20trouvez-vous%20Kyoto%20%3F)
^fr-Q0706-answer

**fr-Q0707** — Les gens me demandent : "pourquoi veux-tu chérir un tas de ferraille comme ça ?" Mais cette petite merveille veut tout dire pour moi.

People ask me 'why would you want to cherish a piece of junk like that?' But this little beauty means the world to me.

Why: Questions and indirect questions. [[French#^fr-Q0707|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Les%20gens%20me%20demandent%20%3A%20%22pourquoi%20veux-tu%20ch%C3%A9rir%20un%20tas%20de%20ferraille%20comme%20%C3%A7a%20%3F%22%20Mais%20cette%20petite%20merveille%20veut%20tout%20dire%20pour%20moi.)
^fr-Q0707-answer

**fr-Q0708** — Les gens me demandent : "pourquoi veux-tu chérir un tas de ferraille comme ça ?" Mais cette petite merveille veut tout dire pour moi.

People ask me 'why would you want to cherish a piece of junk like that?' But this little beauty means the world to me.

Questions can use intonation, est-ce que or inversion. An indirect question normally keeps statement order. Si introduces an indirect yes/no question as well as a condition in other contexts.

Why: Questions and indirect questions. [[French#^fr-Q0708|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Les%20gens%20me%20demandent%20%3A%20%22pourquoi%20veux-tu%20ch%C3%A9rir%20un%20tas%20de%20ferraille%20comme%20%C3%A7a%20%3F%22%20Mais%20cette%20petite%20merveille%20veut%20tout%20dire%20pour%20moi.)
^fr-Q0708-answer

**fr-Q0709** — Je deviendrai folle si ça continue.

I'll go crazy if this keeps up.

Expected form: **si**

Why: Questions and indirect questions. [[French#^fr-Q0709|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20deviendrai%20folle%20si%20%C3%A7a%20continue.)
^fr-Q0709-answer

**fr-Q0710** — Je deviendrai folle si ça continue.

I'll go crazy if this keeps up.

Expected form: **si**

Why: Questions and indirect questions. [[French#^fr-Q0710|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20deviendrai%20folle%20si%20%C3%A7a%20continue.)
^fr-Q0710-answer

**fr-Q0711** — Depuis combien de temps avez-vous planifié ce marriage ?

How long have you been planning this wedding?

Expected form: **combien**

Why: Questions and indirect questions. [[French#^fr-Q0711|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Depuis%20combien%20de%20temps%20avez-vous%20planifi%C3%A9%20ce%20marriage%20%3F)
^fr-Q0711-answer

**fr-Q0712** — Depuis combien de temps avez-vous planifié ce marriage ?

How long have you been planning this wedding?

Why: Questions and indirect questions. [[French#^fr-Q0712|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Depuis%20combien%20de%20temps%20avez-vous%20planifi%C3%A9%20ce%20marriage%20%3F)
^fr-Q0712-answer

**fr-Q0713** — Pourquoi, mon Dieu, l'as-tu amené à la gare ?

Why on earth did you take him to the station?

Why: Questions and indirect questions. [[French#^fr-Q0713|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Pourquoi%2C%20mon%20Dieu%2C%20l%27as-tu%20amen%C3%A9%20%C3%A0%20la%20gare%20%3F)
^fr-Q0713-answer

**fr-Q0714** — Pourquoi, mon Dieu, l'as-tu amené à la gare ?

Why on earth did you take him to the station?

Questions can use intonation, est-ce que or inversion. An indirect question normally keeps statement order. Si introduces an indirect yes/no question as well as a condition in other contexts.

Why: Questions and indirect questions. [[French#^fr-Q0714|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Pourquoi%2C%20mon%20Dieu%2C%20l%27as-tu%20amen%C3%A9%20%C3%A0%20la%20gare%20%3F)
^fr-Q0714-answer

**fr-Q0715** — Excusez-moi. Comment vous appelez-vous?

Excuse me. What's your name?

Expected form: **Comment**

Why: Questions and indirect questions. [[French#^fr-Q0715|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Excusez-moi.%20Comment%20vous%20appelez-vous%3F)
^fr-Q0715-answer

**fr-Q0716** — Excusez-moi. Comment vous appelez-vous?

Excuse me. What's your name?

Expected form: **Comment**

Why: Questions and indirect questions. [[French#^fr-Q0716|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Excusez-moi.%20Comment%20vous%20appelez-vous%3F)
^fr-Q0716-answer

**fr-Q0717** — Si seulement je pouvais parler français.

If only I could speak French.

Expected form: **Si**

Why: Questions and indirect questions. [[French#^fr-Q0717|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Si%20seulement%20je%20pouvais%20parler%20fran%C3%A7ais.)
^fr-Q0717-answer

**fr-Q0718** — Si seulement je pouvais parler français.

If only I could speak French.

Why: Questions and indirect questions. [[French#^fr-Q0718|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Si%20seulement%20je%20pouvais%20parler%20fran%C3%A7ais.)
^fr-Q0718-answer

**fr-Q0719** — Pourquoi se battent-elles ?

Why are they fighting?

Why: Questions and indirect questions. [[French#^fr-Q0719|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Pourquoi%20se%20battent-elles%20%3F)
^fr-Q0719-answer

**fr-Q0720** — Pourquoi se battent-elles ?

Why are they fighting?

Questions can use intonation, est-ce que or inversion. An indirect question normally keeps statement order. Si introduces an indirect yes/no question as well as a condition in other contexts.

Why: Questions and indirect questions. [[French#^fr-Q0720|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Pourquoi%20se%20battent-elles%20%3F)
^fr-Q0720-answer

**fr-Q0721** — Quand reviendrez-vous à Melbourne ?

When are you coming to Melbourne again?

Expected form: **Quand**

Why: Questions and indirect questions. [[French#^fr-Q0721|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Quand%20reviendrez-vous%20%C3%A0%20Melbourne%20%3F)
^fr-Q0721-answer

**fr-Q0722** — Quand reviendrez-vous à Melbourne ?

When are you coming to Melbourne again?

Expected form: **Quand**

Why: Questions and indirect questions. [[French#^fr-Q0722|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Quand%20reviendrez-vous%20%C3%A0%20Melbourne%20%3F)
^fr-Q0722-answer

**fr-Q0723** — Si tu es en difficulté, écris-moi une lettre.

Please write me a letter whenever you run into trouble.

Expected form: **Si**

Why: Questions and indirect questions. [[French#^fr-Q0723|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Si%20tu%20es%20en%20difficult%C3%A9%2C%20%C3%A9cris-moi%20une%20lettre.)
^fr-Q0723-answer

**fr-Q0724** — Si tu es en difficulté, écris-moi une lettre.

Please write me a letter whenever you run into trouble.

Why: Questions and indirect questions. [[French#^fr-Q0724|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Si%20tu%20es%20en%20difficult%C3%A9%2C%20%C3%A9cris-moi%20une%20lettre.)
^fr-Q0724-answer

**fr-Q0725** — Je veux savoir pourquoi je suis ici.

I want to know why I'm here.

Why: Questions and indirect questions. [[French#^fr-Q0725|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20veux%20savoir%20pourquoi%20je%20suis%20ici.)
^fr-Q0725-answer

**fr-Q0726** — Je veux savoir pourquoi je suis ici.

I want to know why I'm here.

Questions can use intonation, est-ce que or inversion. An indirect question normally keeps statement order. Si introduces an indirect yes/no question as well as a condition in other contexts.

Why: Questions and indirect questions. [[French#^fr-Q0726|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20veux%20savoir%20pourquoi%20je%20suis%20ici.)
^fr-Q0726-answer

**fr-Q0727** — Comment peux-tu critiquer ça ?

How can you criticize that?

Expected form: **Comment**

Why: Questions and indirect questions. [[French#^fr-Q0727|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Comment%20peux-tu%20critiquer%20%C3%A7a%20%3F)
^fr-Q0727-answer

**fr-Q0728** — Comment peux-tu critiquer ça ?

How can you criticize that?

Expected form: **Comment**

Why: Questions and indirect questions. [[French#^fr-Q0728|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Comment%20peux-tu%20critiquer%20%C3%A7a%20%3F)
^fr-Q0728-answer

**fr-Q0729** — J'étais très heureux quand j'entendis les nouvelles.

I was very happy when I heard that news.

Expected form: **quand**

Why: Questions and indirect questions. [[French#^fr-Q0729|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=J%27%C3%A9tais%20tr%C3%A8s%20heureux%20quand%20j%27entendis%20les%20nouvelles.)
^fr-Q0729-answer

**fr-Q0730** — J'étais très heureux quand j'entendis les nouvelles.

I was very happy when I heard that news.

Why: Questions and indirect questions. [[French#^fr-Q0730|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=J%27%C3%A9tais%20tr%C3%A8s%20heureux%20quand%20j%27entendis%20les%20nouvelles.)
^fr-Q0730-answer

**fr-Q0731** — Pourquoi n'avez-vous pas appelé à l'aide ?

Why didn't you call for help?

Why: Questions and indirect questions. [[French#^fr-Q0731|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Pourquoi%20n%27avez-vous%20pas%20appel%C3%A9%20%C3%A0%20l%27aide%20%3F)
^fr-Q0731-answer

**fr-Q0732** — Pourquoi n'avez-vous pas appelé à l'aide ?

Why didn't you call for help?

Questions can use intonation, est-ce que or inversion. An indirect question normally keeps statement order. Si introduces an indirect yes/no question as well as a condition in other contexts.

Why: Questions and indirect questions. [[French#^fr-Q0732|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Pourquoi%20n%27avez-vous%20pas%20appel%C3%A9%20%C3%A0%20l%27aide%20%3F)
^fr-Q0732-answer

**fr-Q0733** — Je me demande combien nous aurons à payer.

I wonder how much we'll have to pay.

Expected form: **combien**

Why: Questions and indirect questions. [[French#^fr-Q0733|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20me%20demande%20combien%20nous%20aurons%20%C3%A0%20payer.)
^fr-Q0733-answer

**fr-Q0734** — Je me demande combien nous aurons à payer.

I wonder how much we'll have to pay.

Expected form: **combien**

Why: Questions and indirect questions. [[French#^fr-Q0734|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20me%20demande%20combien%20nous%20aurons%20%C3%A0%20payer.)
^fr-Q0734-answer

**fr-Q0735** — Je ne sais pas comment te dénommer.

I don't know what to call you.

Expected form: **comment**

Why: Questions and indirect questions. [[French#^fr-Q0735|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20ne%20sais%20pas%20comment%20te%20d%C3%A9nommer.)
^fr-Q0735-answer

**fr-Q0736** — Je ne sais pas comment te dénommer.

I don't know what to call you.

Why: Questions and indirect questions. [[French#^fr-Q0736|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20ne%20sais%20pas%20comment%20te%20d%C3%A9nommer.)
^fr-Q0736-answer

**fr-Q0737** — Je fais quatre fois plus par moi-même que quand j'ai engagé Tony pour la première fois.

I'm making about four times as much myself as when I first hired Tony.

Why: Questions and indirect questions. [[French#^fr-Q0737|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20fais%20quatre%20fois%20plus%20par%20moi-m%C3%AAme%20que%20quand%20j%27ai%20engag%C3%A9%20Tony%20pour%20la%20premi%C3%A8re%20fois.)
^fr-Q0737-answer

**fr-Q0738** — Je fais quatre fois plus par moi-même que quand j'ai engagé Tony pour la première fois.

I'm making about four times as much myself as when I first hired Tony.

Questions can use intonation, est-ce que or inversion. An indirect question normally keeps statement order. Si introduces an indirect yes/no question as well as a condition in other contexts.

Why: Questions and indirect questions. [[French#^fr-Q0738|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20fais%20quatre%20fois%20plus%20par%20moi-m%C3%AAme%20que%20quand%20j%27ai%20engag%C3%A9%20Tony%20pour%20la%20premi%C3%A8re%20fois.)
^fr-Q0738-answer

**fr-Q0739** — Comment t'es-tu blessé ?

How did you get hurt?

Expected form: **Comment**

Why: Questions and indirect questions. [[French#^fr-Q0739|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Comment%20t%27es-tu%20bless%C3%A9%20%3F)
^fr-Q0739-answer

**fr-Q0740** — Comment t'es-tu blessé ?

How did you get hurt?

Expected form: **Comment**

Why: Questions and indirect questions. [[French#^fr-Q0740|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Comment%20t%27es-tu%20bless%C3%A9%20%3F)
^fr-Q0740-answer

**fr-Q0741** — Si on gratte un peu sous la couche de vieux, il y a encore un enfant.

If you scrape off a bit under the layer of old man, there is still a child.

Expected form: **Si**

Why: Questions and indirect questions. [[French#^fr-Q0741|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Si%20on%20gratte%20un%20peu%20sous%20la%20couche%20de%20vieux%2C%20il%20y%20a%20encore%20un%20enfant.)
^fr-Q0741-answer

**fr-Q0742** — Si on gratte un peu sous la couche de vieux, il y a encore un enfant.

If you scrape off a bit under the layer of old man, there is still a child.

Why: Questions and indirect questions. [[French#^fr-Q0742|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Si%20on%20gratte%20un%20peu%20sous%20la%20couche%20de%20vieux%2C%20il%20y%20a%20encore%20un%20enfant.)
^fr-Q0742-answer

**fr-Q0743** — « Dis donc, tu n'as pas faim ? » « Si, bien sûr, et soif aussi. »

"Tell me, aren't you hungry?"" "Yes, of course, and thirsty too."

Why: Questions and indirect questions. [[French#^fr-Q0743|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=%C2%AB%20Dis%20donc%2C%20tu%20n%27as%20pas%20faim%20%3F%20%C2%BB%20%C2%AB%20Si%2C%20bien%20s%C3%BBr%2C%20et%20soif%20aussi.%20%C2%BB)
^fr-Q0743-answer

**fr-Q0744** — « Dis donc, tu n'as pas faim ? » « Si, bien sûr, et soif aussi. »

"Tell me, aren't you hungry?"" "Yes, of course, and thirsty too."

Questions can use intonation, est-ce que or inversion. An indirect question normally keeps statement order. Si introduces an indirect yes/no question as well as a condition in other contexts.

Why: Questions and indirect questions. [[French#^fr-Q0744|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=%C2%AB%20Dis%20donc%2C%20tu%20n%27as%20pas%20faim%20%3F%20%C2%BB%20%C2%AB%20Si%2C%20bien%20s%C3%BBr%2C%20et%20soif%20aussi.%20%C2%BB)
^fr-Q0744-answer

**fr-Q0745** — Nazareth ! Est-ce que quelque chose de bon peut sortir de là ?

Nazareth! Can anything good come from there?

Expected form: **Est-ce que**

Why: Questions and indirect questions. [[French#^fr-Q0745|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Nazareth%20%21%20Est-ce%20que%20quelque%20chose%20de%20bon%20peut%20sortir%20de%20l%C3%A0%20%3F)
^fr-Q0745-answer

**fr-Q0746** — Nazareth ! Est-ce que quelque chose de bon peut sortir de là ?

Nazareth! Can anything good come from there?

Expected form: **Est-ce que**

Why: Questions and indirect questions. [[French#^fr-Q0746|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Nazareth%20%21%20Est-ce%20que%20quelque%20chose%20de%20bon%20peut%20sortir%20de%20l%C3%A0%20%3F)
^fr-Q0746-answer

**fr-Q0747** — Je veux juste savoir pourquoi tu m'as amenée ici.

I just want to know why you brought me here.

Expected form: **pourquoi**

Why: Questions and indirect questions. [[French#^fr-Q0747|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20veux%20juste%20savoir%20pourquoi%20tu%20m%27as%20amen%C3%A9e%20ici.)
^fr-Q0747-answer

**fr-Q0748** — Je veux juste savoir pourquoi tu m'as amenée ici.

I just want to know why you brought me here.

Why: Questions and indirect questions. [[French#^fr-Q0748|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20veux%20juste%20savoir%20pourquoi%20tu%20m%27as%20amen%C3%A9e%20ici.)
^fr-Q0748-answer

**fr-Q0749** — Comment allons-nous trouver ça ?

How shall we find it?

Why: Questions and indirect questions. [[French#^fr-Q0749|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Comment%20allons-nous%20trouver%20%C3%A7a%20%3F)
^fr-Q0749-answer

**fr-Q0750** — Comment allons-nous trouver ça ?

How shall we find it?

Questions can use intonation, est-ce que or inversion. An indirect question normally keeps statement order. Si introduces an indirect yes/no question as well as a condition in other contexts.

Why: Questions and indirect questions. [[French#^fr-Q0750|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Comment%20allons-nous%20trouver%20%C3%A7a%20%3F)
^fr-Q0750-answer


### Answers 751–800

**fr-Q0751** — Nous n'étions pas si occupées.

We weren't all that busy.

Expected form: **si**

Why: Conditions. [[French#^fr-Q0751|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Nous%20n%27%C3%A9tions%20pas%20si%20occup%C3%A9es.)
^fr-Q0751-answer

**fr-Q0752** — Nous n'étions pas si occupées.

We weren't all that busy.

Expected form: **si**

Why: Conditions. [[French#^fr-Q0752|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Nous%20n%27%C3%A9tions%20pas%20si%20occup%C3%A9es.)
^fr-Q0752-answer

**fr-Q0753** — Si j'étais vous, je ne le traduirais pas littéralement.

If I were you, I wouldn't translate it literally.

Expected form: **Si**

Why: Conditions. [[French#^fr-Q0753|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Si%20j%27%C3%A9tais%20vous%2C%20je%20ne%20le%20traduirais%20pas%20litt%C3%A9ralement.)
^fr-Q0753-answer

**fr-Q0754** — Si j'étais vous, je ne le traduirais pas littéralement.

If I were you, I wouldn't translate it literally.

Why: Conditions. [[French#^fr-Q0754|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Si%20j%27%C3%A9tais%20vous%2C%20je%20ne%20le%20traduirais%20pas%20litt%C3%A9ralement.)
^fr-Q0754-answer

**fr-Q0755** — Si l'on devait nommer les pays d'après les mots qu'on y entend d'abord, l'Angleterre s'appellerait “damn it”.

If countries were named after the words you first hear when you go there, England would have to be called Damn It.

Why: Conditions. [[French#^fr-Q0755|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Si%20l%27on%20devait%20nommer%20les%20pays%20d%27apr%C3%A8s%20les%20mots%20qu%27on%20y%20entend%20d%27abord%2C%20l%27Angleterre%20s%27appellerait%20%E2%80%9Cdamn%20it%E2%80%9D.)
^fr-Q0755-answer

**fr-Q0756** — Si l'on devait nommer les pays d'après les mots qu'on y entend d'abord, l'Angleterre s'appellerait “damn it”.

If countries were named after the words you first hear when you go there, England would have to be called Damn It.

Si introduces several meanings, especially if and indirect whether. For a standard unreal present condition use si + imperfect, not conditional. For a past counterfactual use si + pluperfect.

Why: Conditions. [[French#^fr-Q0756|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Si%20l%27on%20devait%20nommer%20les%20pays%20d%27apr%C3%A8s%20les%20mots%20qu%27on%20y%20entend%20d%27abord%2C%20l%27Angleterre%20s%27appellerait%20%E2%80%9Cdamn%20it%E2%80%9D.)
^fr-Q0756-answer

**fr-Q0757** — Si quelqu'un devait demander quel est le but de l'histoire, je ne saurais vraiment pas.

If anyone was to ask what the point of the story is, I really don't know.

Expected form: **Si**

Why: Conditions. [[French#^fr-Q0757|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Si%20quelqu%27un%20devait%20demander%20quel%20est%20le%20but%20de%20l%27histoire%2C%20je%20ne%20saurais%20vraiment%20pas.)
^fr-Q0757-answer

**fr-Q0758** — Si quelqu'un devait demander quel est le but de l'histoire, je ne saurais vraiment pas.

If anyone was to ask what the point of the story is, I really don't know.

Expected form: **Si**

Why: Conditions. [[French#^fr-Q0758|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Si%20quelqu%27un%20devait%20demander%20quel%20est%20le%20but%20de%20l%27histoire%2C%20je%20ne%20saurais%20vraiment%20pas.)
^fr-Q0758-answer

**fr-Q0759** — Si les péchés faisaient souffrir quand on les fait, nous serions tous des saints.

If sins made us suffer when we sinned, we'd all be saints.

Expected form: **Si**

Why: Conditions. [[French#^fr-Q0759|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Si%20les%20p%C3%A9ch%C3%A9s%20faisaient%20souffrir%20quand%20on%20les%20fait%2C%20nous%20serions%20tous%20des%20saints.)
^fr-Q0759-answer

**fr-Q0760** — Si les péchés faisaient souffrir quand on les fait, nous serions tous des saints.

If sins made us suffer when we sinned, we'd all be saints.

Why: Conditions. [[French#^fr-Q0760|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Si%20les%20p%C3%A9ch%C3%A9s%20faisaient%20souffrir%20quand%20on%20les%20fait%2C%20nous%20serions%20tous%20des%20saints.)
^fr-Q0760-answer

**fr-Q0761** — Ne prenez pas tout si littéralement.

Don't take everything so literally.

Why: Conditions. [[French#^fr-Q0761|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Ne%20prenez%20pas%20tout%20si%20litt%C3%A9ralement.)
^fr-Q0761-answer

**fr-Q0762** — Ne prenez pas tout si littéralement.

Don't take everything so literally.

Si introduces several meanings, especially if and indirect whether. For a standard unreal present condition use si + imperfect, not conditional. For a past counterfactual use si + pluperfect.

Why: Conditions. [[French#^fr-Q0762|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Ne%20prenez%20pas%20tout%20si%20litt%C3%A9ralement.)
^fr-Q0762-answer

**fr-Q0763** — Si tu regardes cette vidéo, je suis mort.

If you're watching this video, I'm dead.

Expected form: **Si**

Why: Conditions. [[French#^fr-Q0763|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Si%20tu%20regardes%20cette%20vid%C3%A9o%2C%20je%20suis%20mort.)
^fr-Q0763-answer

**fr-Q0764** — Si tu regardes cette vidéo, je suis mort.

If you're watching this video, I'm dead.

Expected form: **Si**

Why: Conditions. [[French#^fr-Q0764|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Si%20tu%20regardes%20cette%20vid%C3%A9o%2C%20je%20suis%20mort.)
^fr-Q0764-answer

**fr-Q0765** — Cela me rend si heureux.

It makes me so happy.

Expected form: **si**

Why: Conditions. [[French#^fr-Q0765|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Cela%20me%20rend%20si%20heureux.)
^fr-Q0765-answer

**fr-Q0766** — Cela me rend si heureux.

It makes me so happy.

Why: Conditions. [[French#^fr-Q0766|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Cela%20me%20rend%20si%20heureux.)
^fr-Q0766-answer

**fr-Q0767** — Si vous voulez rester ici, vous êtes bienvenues.

If you want to stay here, you are welcome to.

Why: Conditions. [[French#^fr-Q0767|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Si%20vous%20voulez%20rester%20ici%2C%20vous%20%C3%AAtes%20bienvenues.)
^fr-Q0767-answer

**fr-Q0768** — Si vous voulez rester ici, vous êtes bienvenues.

If you want to stay here, you are welcome to.

Si introduces several meanings, especially if and indirect whether. For a standard unreal present condition use si + imperfect, not conditional. For a past counterfactual use si + pluperfect.

Why: Conditions. [[French#^fr-Q0768|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Si%20vous%20voulez%20rester%20ici%2C%20vous%20%C3%AAtes%20bienvenues.)
^fr-Q0768-answer

**fr-Q0769** — Si ce n'avait été à cause de la tempête, je serais arrivée plus tôt.

If it hadn't been for the storm, I would've arrived sooner.

Expected form: **Si**

Why: Conditions. [[French#^fr-Q0769|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Si%20ce%20n%27avait%20%C3%A9t%C3%A9%20%C3%A0%20cause%20de%20la%20temp%C3%AAte%2C%20je%20serais%20arriv%C3%A9e%20plus%20t%C3%B4t.)
^fr-Q0769-answer

**fr-Q0770** — Si ce n'avait été à cause de la tempête, je serais arrivée plus tôt.

If it hadn't been for the storm, I would've arrived sooner.

Expected form: **Si**

Why: Conditions. [[French#^fr-Q0770|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Si%20ce%20n%27avait%20%C3%A9t%C3%A9%20%C3%A0%20cause%20de%20la%20temp%C3%AAte%2C%20je%20serais%20arriv%C3%A9e%20plus%20t%C3%B4t.)
^fr-Q0770-answer

**fr-Q0771** — Ils étaient si intimidés qu'ils ne pouvaient bouger d'un pouce.

They were so frightened that they couldn't move an inch.

Expected form: **si**

Why: Conditions. [[French#^fr-Q0771|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Ils%20%C3%A9taient%20si%20intimid%C3%A9s%20qu%27ils%20ne%20pouvaient%20bouger%20d%27un%20pouce.)
^fr-Q0771-answer

**fr-Q0772** — Ils étaient si intimidés qu'ils ne pouvaient bouger d'un pouce.

They were so frightened that they couldn't move an inch.

Why: Conditions. [[French#^fr-Q0772|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Ils%20%C3%A9taient%20si%20intimid%C3%A9s%20qu%27ils%20ne%20pouvaient%20bouger%20d%27un%20pouce.)
^fr-Q0772-answer

**fr-Q0773** — Si vous êtes libre, passez me voir.

If you are free, come around to see me.

Why: Conditions. [[French#^fr-Q0773|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Si%20vous%20%C3%AAtes%20libre%2C%20passez%20me%20voir.)
^fr-Q0773-answer

**fr-Q0774** — Si vous êtes libre, passez me voir.

If you are free, come around to see me.

Si introduces several meanings, especially if and indirect whether. For a standard unreal present condition use si + imperfect, not conditional. For a past counterfactual use si + pluperfect.

Why: Conditions. [[French#^fr-Q0774|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Si%20vous%20%C3%AAtes%20libre%2C%20passez%20me%20voir.)
^fr-Q0774-answer

**fr-Q0775** — Si possible, j'aimerais te voir ce soir.

If possible, I'd like to meet you tonight.

Expected form: **Si**

Why: Conditions. [[French#^fr-Q0775|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Si%20possible%2C%20j%27aimerais%20te%20voir%20ce%20soir.)
^fr-Q0775-answer

**fr-Q0776** — Si possible, j'aimerais te voir ce soir.

If possible, I'd like to meet you tonight.

Expected form: **Si**

Why: Conditions. [[French#^fr-Q0776|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Si%20possible%2C%20j%27aimerais%20te%20voir%20ce%20soir.)
^fr-Q0776-answer

**fr-Q0777** — Pourquoi êtes-vous si négative ?

Why are you being so negative?

Expected form: **si**

Why: Conditions. [[French#^fr-Q0777|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Pourquoi%20%C3%AAtes-vous%20si%20n%C3%A9gative%20%3F)
^fr-Q0777-answer

**fr-Q0778** — Pourquoi êtes-vous si négative ?

Why are you being so negative?

Why: Conditions. [[French#^fr-Q0778|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Pourquoi%20%C3%AAtes-vous%20si%20n%C3%A9gative%20%3F)
^fr-Q0778-answer

**fr-Q0779** — Et qu'en est-il, si je dis « non » ?

And what if I say "no"?

Why: Conditions. [[French#^fr-Q0779|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Et%20qu%27en%20est-il%2C%20si%20je%20dis%20%C2%AB%20non%20%C2%BB%20%3F)
^fr-Q0779-answer

**fr-Q0780** — Et qu'en est-il, si je dis « non » ?

And what if I say "no"?

Si introduces several meanings, especially if and indirect whether. For a standard unreal present condition use si + imperfect, not conditional. For a past counterfactual use si + pluperfect.

Why: Conditions. [[French#^fr-Q0780|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Et%20qu%27en%20est-il%2C%20si%20je%20dis%20%C2%AB%20non%20%C2%BB%20%3F)
^fr-Q0780-answer

**fr-Q0781** — Je vous présente mes excuses, si je vous ai offensés.

I apologize if I offended you.

Expected form: **si**

Why: Conditions. [[French#^fr-Q0781|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20vous%20pr%C3%A9sente%20mes%20excuses%2C%20si%20je%20vous%20ai%20offens%C3%A9s.)
^fr-Q0781-answer

**fr-Q0782** — Je vous présente mes excuses, si je vous ai offensés.

I apologize if I offended you.

Expected form: **si**

Why: Conditions. [[French#^fr-Q0782|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20vous%20pr%C3%A9sente%20mes%20excuses%2C%20si%20je%20vous%20ai%20offens%C3%A9s.)
^fr-Q0782-answer

**fr-Q0783** — Tom avait l'air si pauvre et si triste.

Tom seemed so poor and so sad.

Expected form: **si**

Why: Conditions. [[French#^fr-Q0783|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tom%20avait%20l%27air%20si%20pauvre%20et%20si%20triste.)
^fr-Q0783-answer

**fr-Q0784** — Tom avait l'air si pauvre et si triste.

Tom seemed so poor and so sad.

Why: Conditions. [[French#^fr-Q0784|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tom%20avait%20l%27air%20si%20pauvre%20et%20si%20triste.)
^fr-Q0784-answer

**fr-Q0785** — Ne soyez pas si négligents !

Don't be so careless!

Why: Conditions. [[French#^fr-Q0785|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Ne%20soyez%20pas%20si%20n%C3%A9gligents%20%21)
^fr-Q0785-answer

**fr-Q0786** — Ne soyez pas si négligents !

Don't be so careless!

Si introduces several meanings, especially if and indirect whether. For a standard unreal present condition use si + imperfect, not conditional. For a past counterfactual use si + pluperfect.

Why: Conditions. [[French#^fr-Q0786|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Ne%20soyez%20pas%20si%20n%C3%A9gligents%20%21)
^fr-Q0786-answer

**fr-Q0787** — Il y a seulement quelques jours, nous étions si heureux.

Just a few days ago, we were so happy.

Expected form: **si**

Why: Conditions. [[French#^fr-Q0787|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Il%20y%20a%20seulement%20quelques%20jours%2C%20nous%20%C3%A9tions%20si%20heureux.)
^fr-Q0787-answer

**fr-Q0788** — Il y a seulement quelques jours, nous étions si heureux.

Just a few days ago, we were so happy.

Expected form: **si**

Why: Conditions. [[French#^fr-Q0788|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Il%20y%20a%20seulement%20quelques%20jours%2C%20nous%20%C3%A9tions%20si%20heureux.)
^fr-Q0788-answer

**fr-Q0789** — Si tu veux réussir dans la vie, tu dois travailler dur.

If you would succeed in life, you must work hard.

Expected form: **Si**

Why: Conditions. [[French#^fr-Q0789|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Si%20tu%20veux%20r%C3%A9ussir%20dans%20la%20vie%2C%20tu%20dois%20travailler%20dur.)
^fr-Q0789-answer

**fr-Q0790** — Si tu veux réussir dans la vie, tu dois travailler dur.

If you would succeed in life, you must work hard.

Why: Conditions. [[French#^fr-Q0790|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Si%20tu%20veux%20r%C3%A9ussir%20dans%20la%20vie%2C%20tu%20dois%20travailler%20dur.)
^fr-Q0790-answer

**fr-Q0791** — Comment es-tu arrivé ici si rapidement ?

How did you get here so fast?

Why: Conditions. [[French#^fr-Q0791|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Comment%20es-tu%20arriv%C3%A9%20ici%20si%20rapidement%20%3F)
^fr-Q0791-answer

**fr-Q0792** — Comment es-tu arrivé ici si rapidement ?

How did you get here so fast?

Si introduces several meanings, especially if and indirect whether. For a standard unreal present condition use si + imperfect, not conditional. For a past counterfactual use si + pluperfect.

Why: Conditions. [[French#^fr-Q0792|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Comment%20es-tu%20arriv%C3%A9%20ici%20si%20rapidement%20%3F)
^fr-Q0792-answer

**fr-Q0793** — C’est pratique d’habiter si près de la station.

It's convenient living so close to the station.

Expected form: **si**

Why: Conditions. [[French#^fr-Q0793|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=C%E2%80%99est%20pratique%20d%E2%80%99habiter%20si%20pr%C3%A8s%20de%20la%20station.)
^fr-Q0793-answer

**fr-Q0794** — C’est pratique d’habiter si près de la station.

It's convenient living so close to the station.

Expected form: **si**

Why: Conditions. [[French#^fr-Q0794|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=C%E2%80%99est%20pratique%20d%E2%80%99habiter%20si%20pr%C3%A8s%20de%20la%20station.)
^fr-Q0794-answer

**fr-Q0795** — Pourquoi réfléchissez-vous si longtemps ?

Why are you thinking so long?

Expected form: **si**

Why: Conditions. [[French#^fr-Q0795|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Pourquoi%20r%C3%A9fl%C3%A9chissez-vous%20si%20longtemps%20%3F)
^fr-Q0795-answer

**fr-Q0796** — Pourquoi réfléchissez-vous si longtemps ?

Why are you thinking so long?

Why: Conditions. [[French#^fr-Q0796|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Pourquoi%20r%C3%A9fl%C3%A9chissez-vous%20si%20longtemps%20%3F)
^fr-Q0796-answer

**fr-Q0797** — Elle a de si beaux yeux.

She's got such lovely eyes.

Why: Conditions. [[French#^fr-Q0797|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Elle%20a%20de%20si%20beaux%20yeux.)
^fr-Q0797-answer

**fr-Q0798** — Elle a de si beaux yeux.

She's got such lovely eyes.

Si introduces several meanings, especially if and indirect whether. For a standard unreal present condition use si + imperfect, not conditional. For a past counterfactual use si + pluperfect.

Why: Conditions. [[French#^fr-Q0798|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Elle%20a%20de%20si%20beaux%20yeux.)
^fr-Q0798-answer

**fr-Q0799** — Je me demande pourquoi Tom est si maigre.

I wonder why Tom is so skinny.

Expected form: **si**

Why: Conditions. [[French#^fr-Q0799|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20me%20demande%20pourquoi%20Tom%20est%20si%20maigre.)
^fr-Q0799-answer

**fr-Q0800** — Je me demande pourquoi Tom est si maigre.

I wonder why Tom is so skinny.

Expected form: **si**

Why: Conditions. [[French#^fr-Q0800|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20me%20demande%20pourquoi%20Tom%20est%20si%20maigre.)
^fr-Q0800-answer


### Answers 801–850

**fr-Q0801** — Tu ne connais pas Tom aussi bien que moi.

You don't know Tom as well as I do.

Expected form: **bien que**

Why: Cause and concession. [[French#^fr-Q0801|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tu%20ne%20connais%20pas%20Tom%20aussi%20bien%20que%20moi.)
^fr-Q0801-answer

**fr-Q0802** — Tu ne connais pas Tom aussi bien que moi.

You don't know Tom as well as I do.

Why: Cause and concession. [[French#^fr-Q0802|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tu%20ne%20connais%20pas%20Tom%20aussi%20bien%20que%20moi.)
^fr-Q0802-answer

**fr-Q0803** — Je ne parle pas bien l'anglais, bien que je l'aie étudié six ans à l'école.

I don't speak English well even though I took it for six years at school.

Why: Cause and concession. [[French#^fr-Q0803|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20ne%20parle%20pas%20bien%20l%27anglais%2C%20bien%20que%20je%20l%27aie%20%C3%A9tudi%C3%A9%20six%20ans%20%C3%A0%20l%27%C3%A9cole.)
^fr-Q0803-answer

**fr-Q0804** — Je ne parle pas bien l'anglais, bien que je l'aie étudié six ans à l'école.

I don't speak English well even though I took it for six years at school.

Parce que supplies a cause; puisque often treats the reason as accepted; bien que introduces concession and generally takes subjunctive. Pourtant/cependant link ideas without themselves supplying the same subordinate structure.

Why: Cause and concession. [[French#^fr-Q0804|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20ne%20parle%20pas%20bien%20l%27anglais%2C%20bien%20que%20je%20l%27aie%20%C3%A9tudi%C3%A9%20six%20ans%20%C3%A0%20l%27%C3%A9cole.)
^fr-Q0804-answer

**fr-Q0805** — Garde tes distances parce que j'ai un mauvais rhume.

Keep away from me because I have a bad cold.

Expected form: **parce que**

Why: Cause and concession. [[French#^fr-Q0805|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Garde%20tes%20distances%20parce%20que%20j%27ai%20un%20mauvais%20rhume.)
^fr-Q0805-answer

**fr-Q0806** — Garde tes distances parce que j'ai un mauvais rhume.

Keep away from me because I have a bad cold.

Expected form: **parce que**

Why: Cause and concession. [[French#^fr-Q0806|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Garde%20tes%20distances%20parce%20que%20j%27ai%20un%20mauvais%20rhume.)
^fr-Q0806-answer

**fr-Q0807** — Cependant, la quantité n'était pas correcte.

However, the quantity was not correct.

Expected form: **Cependant**

Why: Cause and concession. [[French#^fr-Q0807|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Cependant%2C%20la%20quantit%C3%A9%20n%27%C3%A9tait%20pas%20correcte.)
^fr-Q0807-answer

**fr-Q0808** — Cependant, la quantité n'était pas correcte.

However, the quantity was not correct.

Why: Cause and concession. [[French#^fr-Q0808|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Cependant%2C%20la%20quantit%C3%A9%20n%27%C3%A9tait%20pas%20correcte.)
^fr-Q0808-answer

**fr-Q0809** — Je suis devenu catholique parce que je suis extrêmement pessimiste.

I became a Catholic because I'm extremely pessimistic.

Why: Cause and concession. [[French#^fr-Q0809|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20suis%20devenu%20catholique%20parce%20que%20je%20suis%20extr%C3%AAmement%20pessimiste.)
^fr-Q0809-answer

**fr-Q0810** — Je suis devenu catholique parce que je suis extrêmement pessimiste.

I became a Catholic because I'm extremely pessimistic.

Parce que supplies a cause; puisque often treats the reason as accepted; bien que introduces concession and generally takes subjunctive. Pourtant/cependant link ideas without themselves supplying the same subordinate structure.

Why: Cause and concession. [[French#^fr-Q0810|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20suis%20devenu%20catholique%20parce%20que%20je%20suis%20extr%C3%AAmement%20pessimiste.)
^fr-Q0810-answer

**fr-Q0811** — « Pourquoi l'avez-vous fait ? » « Parce que je le peux. »

"Why did you do it?" "Because I can."

Expected form: **Parce que**

Why: Cause and concession. [[French#^fr-Q0811|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=%C2%AB%20Pourquoi%20l%27avez-vous%20fait%20%3F%20%C2%BB%20%C2%AB%20Parce%20que%20je%20le%20peux.%20%C2%BB)
^fr-Q0811-answer

**fr-Q0812** — « Pourquoi l'avez-vous fait ? » « Parce que je le peux. »

"Why did you do it?" "Because I can."

Expected form: **Parce que**

Why: Cause and concession. [[French#^fr-Q0812|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=%C2%AB%20Pourquoi%20l%27avez-vous%20fait%20%3F%20%C2%BB%20%C2%AB%20Parce%20que%20je%20le%20peux.%20%C2%BB)
^fr-Q0812-answer

**fr-Q0813** — C'est parce que la lumière voyage plus vite que le son que nous voyons l'éclair avant d'entendre le tonnerre.

It is because light travels faster than sound that we see lightning before we hear thunder.

Expected form: **parce que**

Why: Cause and concession. [[French#^fr-Q0813|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=C%27est%20parce%20que%20la%20lumi%C3%A8re%20voyage%20plus%20vite%20que%20le%20son%20que%20nous%20voyons%20l%27%C3%A9clair%20avant%20d%27entendre%20le%20tonnerre.)
^fr-Q0813-answer

**fr-Q0814** — C'est parce que la lumière voyage plus vite que le son que nous voyons l'éclair avant d'entendre le tonnerre.

It is because light travels faster than sound that we see lightning before we hear thunder.

Why: Cause and concession. [[French#^fr-Q0814|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=C%27est%20parce%20que%20la%20lumi%C3%A8re%20voyage%20plus%20vite%20que%20le%20son%20que%20nous%20voyons%20l%27%C3%A9clair%20avant%20d%27entendre%20le%20tonnerre.)
^fr-Q0814-answer

**fr-Q0815** — Puisque mon époux a été admis à l'hôpital, j'écris en son nom.

Because my husband has been admitted to hospital, I am writing on his behalf.

Why: Cause and concession. [[French#^fr-Q0815|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Puisque%20mon%20%C3%A9poux%20a%20%C3%A9t%C3%A9%20admis%20%C3%A0%20l%27h%C3%B4pital%2C%20j%27%C3%A9cris%20en%20son%20nom.)
^fr-Q0815-answer

**fr-Q0816** — Puisque mon époux a été admis à l'hôpital, j'écris en son nom.

Because my husband has been admitted to hospital, I am writing on his behalf.

Parce que supplies a cause; puisque often treats the reason as accepted; bien que introduces concession and generally takes subjunctive. Pourtant/cependant link ideas without themselves supplying the same subordinate structure.

Why: Cause and concession. [[French#^fr-Q0816|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Puisque%20mon%20%C3%A9poux%20a%20%C3%A9t%C3%A9%20admis%20%C3%A0%20l%27h%C3%B4pital%2C%20j%27%C3%A9cris%20en%20son%20nom.)
^fr-Q0816-answer

**fr-Q0817** — C'est stable parce que toutes les racines de cette équation sont négatives.

It's stable because all the roots of this equation are negative.

Expected form: **parce que**

Why: Cause and concession. [[French#^fr-Q0817|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=C%27est%20stable%20parce%20que%20toutes%20les%20racines%20de%20cette%20%C3%A9quation%20sont%20n%C3%A9gatives.)
^fr-Q0817-answer

**fr-Q0818** — C'est stable parce que toutes les racines de cette équation sont négatives.

It's stable because all the roots of this equation are negative.

Expected form: **parce que**

Why: Cause and concession. [[French#^fr-Q0818|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=C%27est%20stable%20parce%20que%20toutes%20les%20racines%20de%20cette%20%C3%A9quation%20sont%20n%C3%A9gatives.)
^fr-Q0818-answer

**fr-Q0819** — Elle a grandi au bord de la mer, et pourtant elle a horreur de nager.

She grew up near the sea, yet she hates swimming.

Expected form: **pourtant**

Why: Cause and concession. [[French#^fr-Q0819|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Elle%20a%20grandi%20au%20bord%20de%20la%20mer%2C%20et%20pourtant%20elle%20a%20horreur%20de%20nager.)
^fr-Q0819-answer

**fr-Q0820** — Elle a grandi au bord de la mer, et pourtant elle a horreur de nager.

She grew up near the sea, yet she hates swimming.

Why: Cause and concession. [[French#^fr-Q0820|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Elle%20a%20grandi%20au%20bord%20de%20la%20mer%2C%20et%20pourtant%20elle%20a%20horreur%20de%20nager.)
^fr-Q0820-answer

**fr-Q0821** — Puisque tu n'as rien à voir avec cette affaire, tu ne dois pas te faire de souci.

Since you have nothing to do with this matter, you don't have to worry.

Why: Cause and concession. [[French#^fr-Q0821|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Puisque%20tu%20n%27as%20rien%20%C3%A0%20voir%20avec%20cette%20affaire%2C%20tu%20ne%20dois%20pas%20te%20faire%20de%20souci.)
^fr-Q0821-answer

**fr-Q0822** — Puisque tu n'as rien à voir avec cette affaire, tu ne dois pas te faire de souci.

Since you have nothing to do with this matter, you don't have to worry.

Parce que supplies a cause; puisque often treats the reason as accepted; bien que introduces concession and generally takes subjunctive. Pourtant/cependant link ideas without themselves supplying the same subordinate structure.

Why: Cause and concession. [[French#^fr-Q0822|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Puisque%20tu%20n%27as%20rien%20%C3%A0%20voir%20avec%20cette%20affaire%2C%20tu%20ne%20dois%20pas%20te%20faire%20de%20souci.)
^fr-Q0822-answer

**fr-Q0823** — Tom n'aime pas Mary. Cependant, elle ne se soucie pas particulièrement de savoir si il l'aime ou non.

Tom doesn't like Mary. However, she doesn't particularly care whether he likes her or not.

Expected form: **Cependant**

Why: Cause and concession. [[French#^fr-Q0823|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tom%20n%27aime%20pas%20Mary.%20Cependant%2C%20elle%20ne%20se%20soucie%20pas%20particuli%C3%A8rement%20de%20savoir%20si%20il%20l%27aime%20ou%20non.)
^fr-Q0823-answer

**fr-Q0824** — Tom n'aime pas Mary. Cependant, elle ne se soucie pas particulièrement de savoir si il l'aime ou non.

Tom doesn't like Mary. However, she doesn't particularly care whether he likes her or not.

Expected form: **Cependant**

Why: Cause and concession. [[French#^fr-Q0824|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tom%20n%27aime%20pas%20Mary.%20Cependant%2C%20elle%20ne%20se%20soucie%20pas%20particuli%C3%A8rement%20de%20savoir%20si%20il%20l%27aime%20ou%20non.)
^fr-Q0824-answer

**fr-Q0825** — Cependant, je te demande de ne pas faire les mêmes erreurs que moi.

However, I ask you not to make the same mistakes that I did.

Expected form: **Cependant**

Why: Cause and concession. [[French#^fr-Q0825|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Cependant%2C%20je%20te%20demande%20de%20ne%20pas%20faire%20les%20m%C3%AAmes%20erreurs%20que%20moi.)
^fr-Q0825-answer

**fr-Q0826** — Cependant, je te demande de ne pas faire les mêmes erreurs que moi.

However, I ask you not to make the same mistakes that I did.

Why: Cause and concession. [[French#^fr-Q0826|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Cependant%2C%20je%20te%20demande%20de%20ne%20pas%20faire%20les%20m%C3%AAmes%20erreurs%20que%20moi.)
^fr-Q0826-answer

**fr-Q0827** — Vous savez aussi bien que moi que Tom n'est pas un très bon chanteur.

You know as well as I do that Tom isn't a very good singer.

Why: Cause and concession. [[French#^fr-Q0827|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Vous%20savez%20aussi%20bien%20que%20moi%20que%20Tom%20n%27est%20pas%20un%20tr%C3%A8s%20bon%20chanteur.)
^fr-Q0827-answer

**fr-Q0828** — Vous savez aussi bien que moi que Tom n'est pas un très bon chanteur.

You know as well as I do that Tom isn't a very good singer.

Parce que supplies a cause; puisque often treats the reason as accepted; bien que introduces concession and generally takes subjunctive. Pourtant/cependant link ideas without themselves supplying the same subordinate structure.

Why: Cause and concession. [[French#^fr-Q0828|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Vous%20savez%20aussi%20bien%20que%20moi%20que%20Tom%20n%27est%20pas%20un%20tr%C3%A8s%20bon%20chanteur.)
^fr-Q0828-answer

**fr-Q0829** — Bien que je fusse épuisé, je continuais à travailler.

Although I was exhausted, I continued to work.

Expected form: **Bien que**

Why: Cause and concession. [[French#^fr-Q0829|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Bien%20que%20je%20fusse%20%C3%A9puis%C3%A9%2C%20je%20continuais%20%C3%A0%20travailler.)
^fr-Q0829-answer

**fr-Q0830** — Bien que je fusse épuisé, je continuais à travailler.

Although I was exhausted, I continued to work.

Expected form: **Bien que**

Why: Cause and concession. [[French#^fr-Q0830|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Bien%20que%20je%20fusse%20%C3%A9puis%C3%A9%2C%20je%20continuais%20%C3%A0%20travailler.)
^fr-Q0830-answer

**fr-Q0831** — C'est un mensonge, parce que son stylo n'était pas sous la table.

It's a lie, because his pen was not under the table.

Expected form: **parce que**

Why: Cause and concession. [[French#^fr-Q0831|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=C%27est%20un%20mensonge%2C%20parce%20que%20son%20stylo%20n%27%C3%A9tait%20pas%20sous%20la%20table.)
^fr-Q0831-answer

**fr-Q0832** — C'est un mensonge, parce que son stylo n'était pas sous la table.

It's a lie, because his pen was not under the table.

Why: Cause and concession. [[French#^fr-Q0832|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=C%27est%20un%20mensonge%2C%20parce%20que%20son%20stylo%20n%27%C3%A9tait%20pas%20sous%20la%20table.)
^fr-Q0832-answer

**fr-Q0833** — Il est mon oncle, parce que mon père est son frère.

He's my uncle, because my father is his brother.

Why: Cause and concession. [[French#^fr-Q0833|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Il%20est%20mon%20oncle%2C%20parce%20que%20mon%20p%C3%A8re%20est%20son%20fr%C3%A8re.)
^fr-Q0833-answer

**fr-Q0834** — Il est mon oncle, parce que mon père est son frère.

He's my uncle, because my father is his brother.

Parce que supplies a cause; puisque often treats the reason as accepted; bien que introduces concession and generally takes subjunctive. Pourtant/cependant link ideas without themselves supplying the same subordinate structure.

Why: Cause and concession. [[French#^fr-Q0834|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Il%20est%20mon%20oncle%2C%20parce%20que%20mon%20p%C3%A8re%20est%20son%20fr%C3%A8re.)
^fr-Q0834-answer

**fr-Q0835** — Je t'avais pourtant dit de rester dans la voiture.

I did tell you to stay in the car.

Expected form: **pourtant**

Why: Cause and concession. [[French#^fr-Q0835|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20t%27avais%20pourtant%20dit%20de%20rester%20dans%20la%20voiture.)
^fr-Q0835-answer

**fr-Q0836** — Je t'avais pourtant dit de rester dans la voiture.

I did tell you to stay in the car.

Expected form: **pourtant**

Why: Cause and concession. [[French#^fr-Q0836|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20t%27avais%20pourtant%20dit%20de%20rester%20dans%20la%20voiture.)
^fr-Q0836-answer

**fr-Q0837** — Comme la Chine est un pays en voie de développement, certains aspects ne sont pas aussi bien que les pays occidentaux.

Because it's a developing country, some aspects of China aren't as good as those in Western countries.

Expected form: **bien que**

Why: Cause and concession. [[French#^fr-Q0837|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Comme%20la%20Chine%20est%20un%20pays%20en%20voie%20de%20d%C3%A9veloppement%2C%20certains%20aspects%20ne%20sont%20pas%20aussi%20bien%20que%20les%20pays%20occidentaux.)
^fr-Q0837-answer

**fr-Q0838** — Comme la Chine est un pays en voie de développement, certains aspects ne sont pas aussi bien que les pays occidentaux.

Because it's a developing country, some aspects of China aren't as good as those in Western countries.

Why: Cause and concession. [[French#^fr-Q0838|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Comme%20la%20Chine%20est%20un%20pays%20en%20voie%20de%20d%C3%A9veloppement%2C%20certains%20aspects%20ne%20sont%20pas%20aussi%20bien%20que%20les%20pays%20occidentaux.)
^fr-Q0838-answer

**fr-Q0839** — L'État algérien ne respecte pas les droits de l'homme pourtant il a signé la charte.

The Algerian state does not respect human rights yet it has signed the charter.

Why: Cause and concession. [[French#^fr-Q0839|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=L%27%C3%89tat%20alg%C3%A9rien%20ne%20respecte%20pas%20les%20droits%20de%20l%27homme%20pourtant%20il%20a%20sign%C3%A9%20la%20charte.)
^fr-Q0839-answer

**fr-Q0840** — L'État algérien ne respecte pas les droits de l'homme pourtant il a signé la charte.

The Algerian state does not respect human rights yet it has signed the charter.

Parce que supplies a cause; puisque often treats the reason as accepted; bien que introduces concession and generally takes subjunctive. Pourtant/cependant link ideas without themselves supplying the same subordinate structure.

Why: Cause and concession. [[French#^fr-Q0840|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=L%27%C3%89tat%20alg%C3%A9rien%20ne%20respecte%20pas%20les%20droits%20de%20l%27homme%20pourtant%20il%20a%20sign%C3%A9%20la%20charte.)
^fr-Q0840-answer

**fr-Q0841** — Je dois acheter des pâtes sans gluten parce que mon amie vient manger.

I have to buy gluten-free pasta because my friend is coming over to eat.

Expected form: **parce que**

Why: Cause and concession. [[French#^fr-Q0841|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20dois%20acheter%20des%20p%C3%A2tes%20sans%20gluten%20parce%20que%20mon%20amie%20vient%20manger.)
^fr-Q0841-answer

**fr-Q0842** — Je dois acheter des pâtes sans gluten parce que mon amie vient manger.

I have to buy gluten-free pasta because my friend is coming over to eat.

Expected form: **parce que**

Why: Cause and concession. [[French#^fr-Q0842|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20dois%20acheter%20des%20p%C3%A2tes%20sans%20gluten%20parce%20que%20mon%20amie%20vient%20manger.)
^fr-Q0842-answer

**fr-Q0843** — La mort d'un homme de talent m'attriste toujours, puisque le monde en a plus besoin que le ciel.

The death of a talented man always saddens me, as the world needs them more than heaven does.

Expected form: **puisque**

Why: Cause and concession. [[French#^fr-Q0843|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=La%20mort%20d%27un%20homme%20de%20talent%20m%27attriste%20toujours%2C%20puisque%20le%20monde%20en%20a%20plus%20besoin%20que%20le%20ciel.)
^fr-Q0843-answer

**fr-Q0844** — La mort d'un homme de talent m'attriste toujours, puisque le monde en a plus besoin que le ciel.

The death of a talented man always saddens me, as the world needs them more than heaven does.

Why: Cause and concession. [[French#^fr-Q0844|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=La%20mort%20d%27un%20homme%20de%20talent%20m%27attriste%20toujours%2C%20puisque%20le%20monde%20en%20a%20plus%20besoin%20que%20le%20ciel.)
^fr-Q0844-answer

**fr-Q0845** — Je m'ennuyais parce que j'avais déjà vu le film.

I was bored because I had seen the movie before.

Why: Cause and concession. [[French#^fr-Q0845|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20m%27ennuyais%20parce%20que%20j%27avais%20d%C3%A9j%C3%A0%20vu%20le%20film.)
^fr-Q0845-answer

**fr-Q0846** — Je m'ennuyais parce que j'avais déjà vu le film.

I was bored because I had seen the movie before.

Parce que supplies a cause; puisque often treats the reason as accepted; bien que introduces concession and generally takes subjunctive. Pourtant/cependant link ideas without themselves supplying the same subordinate structure.

Why: Cause and concession. [[French#^fr-Q0846|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20m%27ennuyais%20parce%20que%20j%27avais%20d%C3%A9j%C3%A0%20vu%20le%20film.)
^fr-Q0846-answer

**fr-Q0847** — Tu n'arrives pas à fermer cette valise parce que tu as mis trop de choses dedans.

You can't get the suitcase closed because you've stuffed too much into it.

Expected form: **parce que**

Why: Cause and concession. [[French#^fr-Q0847|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tu%20n%27arrives%20pas%20%C3%A0%20fermer%20cette%20valise%20parce%20que%20tu%20as%20mis%20trop%20de%20choses%20dedans.)
^fr-Q0847-answer

**fr-Q0848** — Tu n'arrives pas à fermer cette valise parce que tu as mis trop de choses dedans.

You can't get the suitcase closed because you've stuffed too much into it.

Expected form: **parce que**

Why: Cause and concession. [[French#^fr-Q0848|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tu%20n%27arrives%20pas%20%C3%A0%20fermer%20cette%20valise%20parce%20que%20tu%20as%20mis%20trop%20de%20choses%20dedans.)
^fr-Q0848-answer

**fr-Q0849** — Je pense que c'est bien que les livres existent encore, mais ils me donnent bien envie de dormir.

I think it is good that books still exist, but they do make me sleepy.

Expected form: **bien que**

Why: Cause and concession. [[French#^fr-Q0849|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20pense%20que%20c%27est%20bien%20que%20les%20livres%20existent%20encore%2C%20mais%20ils%20me%20donnent%20bien%20envie%20de%20dormir.)
^fr-Q0849-answer

**fr-Q0850** — Je pense que c'est bien que les livres existent encore, mais ils me donnent bien envie de dormir.

I think it is good that books still exist, but they do make me sleepy.

Why: Cause and concession. [[French#^fr-Q0850|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20pense%20que%20c%27est%20bien%20que%20les%20livres%20existent%20encore%2C%20mais%20ils%20me%20donnent%20bien%20envie%20de%20dormir.)
^fr-Q0850-answer


### Answers 851–900

**fr-Q0851** — Fais ton déplacement.

Make your move.

Why: Causative faire. [[French#^fr-Q0851|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Fais%20ton%20d%C3%A9placement.)
^fr-Q0851-answer

**fr-Q0852** — Fais ton déplacement.

Make your move.

Faire can mean do/make or form a causative with an infinitive: faire réparer, have repaired. Identify who arranges the action and who performs it. Not every occurrence of faire is causative.

Why: Causative faire. [[French#^fr-Q0852|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Fais%20ton%20d%C3%A9placement.)
^fr-Q0852-answer

**fr-Q0853** — N'importe quel enfant peut faire cela.

Any child can do that.

Expected form: **faire**

Why: Causative faire. [[French#^fr-Q0853|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=N%27importe%20quel%20enfant%20peut%20faire%20cela.)
^fr-Q0853-answer

**fr-Q0854** — N'importe quel enfant peut faire cela.

Any child can do that.

Expected form: **faire**

Why: Causative faire. [[French#^fr-Q0854|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=N%27importe%20quel%20enfant%20peut%20faire%20cela.)
^fr-Q0854-answer

**fr-Q0855** — J'ai envie de te faire un câlin.

I want to give you a hug.

Expected form: **faire**

Why: Causative faire. [[French#^fr-Q0855|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=J%27ai%20envie%20de%20te%20faire%20un%20c%C3%A2lin.)
^fr-Q0855-answer

**fr-Q0856** — J'ai envie de te faire un câlin.

I want to give you a hug.

Why: Causative faire. [[French#^fr-Q0856|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=J%27ai%20envie%20de%20te%20faire%20un%20c%C3%A2lin.)
^fr-Q0856-answer

**fr-Q0857** — Je devrais appeler la police et te faire arrêter.

I should call the police and have you arrested.

Why: Causative faire. [[French#^fr-Q0857|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20devrais%20appeler%20la%20police%20et%20te%20faire%20arr%C3%AAter.)
^fr-Q0857-answer

**fr-Q0858** — Je devrais appeler la police et te faire arrêter.

I should call the police and have you arrested.

Faire can mean do/make or form a causative with an infinitive: faire réparer, have repaired. Identify who arranges the action and who performs it. Not every occurrence of faire is causative.

Why: Causative faire. [[French#^fr-Q0858|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20devrais%20appeler%20la%20police%20et%20te%20faire%20arr%C3%AAter.)
^fr-Q0858-answer

**fr-Q0859** — Pour faire de l'exercice, je nage dans la piscine chaque semaine.

To exercise, I swim in the pool every week.

Expected form: **faire**

Why: Causative faire. [[French#^fr-Q0859|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Pour%20faire%20de%20l%27exercice%2C%20je%20nage%20dans%20la%20piscine%20chaque%20semaine.)
^fr-Q0859-answer

**fr-Q0860** — Pour faire de l'exercice, je nage dans la piscine chaque semaine.

To exercise, I swim in the pool every week.

Expected form: **faire**

Why: Causative faire. [[French#^fr-Q0860|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Pour%20faire%20de%20l%27exercice%2C%20je%20nage%20dans%20la%20piscine%20chaque%20semaine.)
^fr-Q0860-answer

**fr-Q0861** — Je ne pense pas que nous avons besoin de faire cela.

I don't think we need to do that.

Expected form: **faire**

Why: Causative faire. [[French#^fr-Q0861|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20ne%20pense%20pas%20que%20nous%20avons%20besoin%20de%20faire%20cela.)
^fr-Q0861-answer

**fr-Q0862** — Je ne pense pas que nous avons besoin de faire cela.

I don't think we need to do that.

Why: Causative faire. [[French#^fr-Q0862|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20ne%20pense%20pas%20que%20nous%20avons%20besoin%20de%20faire%20cela.)
^fr-Q0862-answer

**fr-Q0863** — Vous ne pourrez probablement pas faire cela.

You probably won't be able to do that.

Why: Causative faire. [[French#^fr-Q0863|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Vous%20ne%20pourrez%20probablement%20pas%20faire%20cela.)
^fr-Q0863-answer

**fr-Q0864** — Vous ne pourrez probablement pas faire cela.

You probably won't be able to do that.

Faire can mean do/make or form a causative with an infinitive: faire réparer, have repaired. Identify who arranges the action and who performs it. Not every occurrence of faire is causative.

Why: Causative faire. [[French#^fr-Q0864|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Vous%20ne%20pourrez%20probablement%20pas%20faire%20cela.)
^fr-Q0864-answer

**fr-Q0865** — Tu devrais vraiment dire à Tom de ne pas le faire.

You should really tell Tom not to do that.

Expected form: **faire**

Why: Causative faire. [[French#^fr-Q0865|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tu%20devrais%20vraiment%20dire%20%C3%A0%20Tom%20de%20ne%20pas%20le%20faire.)
^fr-Q0865-answer

**fr-Q0866** — Tu devrais vraiment dire à Tom de ne pas le faire.

You should really tell Tom not to do that.

Expected form: **faire**

Why: Causative faire. [[French#^fr-Q0866|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tu%20devrais%20vraiment%20dire%20%C3%A0%20Tom%20de%20ne%20pas%20le%20faire.)
^fr-Q0866-answer

**fr-Q0867** — Nous n'aurions vraiment pas dû faire ça.

We really shouldn't have done that.

Expected form: **faire**

Why: Causative faire. [[French#^fr-Q0867|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Nous%20n%27aurions%20vraiment%20pas%20d%C3%BB%20faire%20%C3%A7a.)
^fr-Q0867-answer

**fr-Q0868** — Nous n'aurions vraiment pas dû faire ça.

We really shouldn't have done that.

Why: Causative faire. [[French#^fr-Q0868|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Nous%20n%27aurions%20vraiment%20pas%20d%C3%BB%20faire%20%C3%A7a.)
^fr-Q0868-answer

**fr-Q0869** — Je devrais faire ça par mes propres moyens.

I ought to do this by myself.

Why: Causative faire. [[French#^fr-Q0869|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20devrais%20faire%20%C3%A7a%20par%20mes%20propres%20moyens.)
^fr-Q0869-answer

**fr-Q0870** — Je devrais faire ça par mes propres moyens.

I ought to do this by myself.

Faire can mean do/make or form a causative with an infinitive: faire réparer, have repaired. Identify who arranges the action and who performs it. Not every occurrence of faire is causative.

Why: Causative faire. [[French#^fr-Q0870|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20devrais%20faire%20%C3%A7a%20par%20mes%20propres%20moyens.)
^fr-Q0870-answer

**fr-Q0871** — C'est le genre d'homme qui ne fait rien avec modération, mais va toujours à l'extrême.

He is the kind of man who cannot do anything in moderation, but always goes to extremes.

Expected form: **fait**

Why: Causative faire. [[French#^fr-Q0871|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=C%27est%20le%20genre%20d%27homme%20qui%20ne%20fait%20rien%20avec%20mod%C3%A9ration%2C%20mais%20va%20toujours%20%C3%A0%20l%27extr%C3%AAme.)
^fr-Q0871-answer

**fr-Q0872** — C'est le genre d'homme qui ne fait rien avec modération, mais va toujours à l'extrême.

He is the kind of man who cannot do anything in moderation, but always goes to extremes.

Expected form: **fait**

Why: Causative faire. [[French#^fr-Q0872|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=C%27est%20le%20genre%20d%27homme%20qui%20ne%20fait%20rien%20avec%20mod%C3%A9ration%2C%20mais%20va%20toujours%20%C3%A0%20l%27extr%C3%AAme.)
^fr-Q0872-answer

**fr-Q0873** — Il s'est fait catholique.

He became a Catholic.

Expected form: **fait**

Why: Causative faire. [[French#^fr-Q0873|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Il%20s%27est%20fait%20catholique.)
^fr-Q0873-answer

**fr-Q0874** — Il s'est fait catholique.

He became a Catholic.

Why: Causative faire. [[French#^fr-Q0874|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Il%20s%27est%20fait%20catholique.)
^fr-Q0874-answer

**fr-Q0875** — Parle moins et fais-en plus.

Talk less, do more.

Why: Causative faire. [[French#^fr-Q0875|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Parle%20moins%20et%20fais-en%20plus.)
^fr-Q0875-answer

**fr-Q0876** — Parle moins et fais-en plus.

Talk less, do more.

Faire can mean do/make or form a causative with an infinitive: faire réparer, have repaired. Identify who arranges the action and who performs it. Not every occurrence of faire is causative.

Why: Causative faire. [[French#^fr-Q0876|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Parle%20moins%20et%20fais-en%20plus.)
^fr-Q0876-answer

**fr-Q0877** — Comment on fait du compost ?

How do you make compost?

Expected form: **fait**

Why: Causative faire. [[French#^fr-Q0877|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Comment%20on%20fait%20du%20compost%20%3F)
^fr-Q0877-answer

**fr-Q0878** — Comment on fait du compost ?

How do you make compost?

Expected form: **fait**

Why: Causative faire. [[French#^fr-Q0878|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Comment%20on%20fait%20du%20compost%20%3F)
^fr-Q0878-answer

**fr-Q0879** — Pourquoi te fais-tu du souci à propos de quelque chose qui n'a pas tant d'importance ?

Why are you worrying about something that doesn't matter so much?

Expected form: **fais**

Why: Causative faire. [[French#^fr-Q0879|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Pourquoi%20te%20fais-tu%20du%20souci%20%C3%A0%20propos%20de%20quelque%20chose%20qui%20n%27a%20pas%20tant%20d%27importance%20%3F)
^fr-Q0879-answer

**fr-Q0880** — Pourquoi te fais-tu du souci à propos de quelque chose qui n'a pas tant d'importance ?

Why are you worrying about something that doesn't matter so much?

Why: Causative faire. [[French#^fr-Q0880|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Pourquoi%20te%20fais-tu%20du%20souci%20%C3%A0%20propos%20de%20quelque%20chose%20qui%20n%27a%20pas%20tant%20d%27importance%20%3F)
^fr-Q0880-answer

**fr-Q0881** — Nous devrions faire quelque chose pour ça.

We should do something about that.

Why: Causative faire. [[French#^fr-Q0881|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Nous%20devrions%20faire%20quelque%20chose%20pour%20%C3%A7a.)
^fr-Q0881-answer

**fr-Q0882** — Nous devrions faire quelque chose pour ça.

We should do something about that.

Faire can mean do/make or form a causative with an infinitive: faire réparer, have repaired. Identify who arranges the action and who performs it. Not every occurrence of faire is causative.

Why: Causative faire. [[French#^fr-Q0882|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Nous%20devrions%20faire%20quelque%20chose%20pour%20%C3%A7a.)
^fr-Q0882-answer

**fr-Q0883** — Marie fait beaucoup plus jeune que son âge.

Mary looks much younger than she really is.

Expected form: **fait**

Why: Causative faire. [[French#^fr-Q0883|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Marie%20fait%20beaucoup%20plus%20jeune%20que%20son%20%C3%A2ge.)
^fr-Q0883-answer

**fr-Q0884** — Marie fait beaucoup plus jeune que son âge.

Mary looks much younger than she really is.

Expected form: **fait**

Why: Causative faire. [[French#^fr-Q0884|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Marie%20fait%20beaucoup%20plus%20jeune%20que%20son%20%C3%A2ge.)
^fr-Q0884-answer

**fr-Q0885** — Il m'a fait attendre longtemps.

He kept me waiting for a long time.

Expected form: **fait**

Why: Causative faire. [[French#^fr-Q0885|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Il%20m%27a%20fait%20attendre%20longtemps.)
^fr-Q0885-answer

**fr-Q0886** — Il m'a fait attendre longtemps.

He kept me waiting for a long time.

Why: Causative faire. [[French#^fr-Q0886|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Il%20m%27a%20fait%20attendre%20longtemps.)
^fr-Q0886-answer

**fr-Q0887** — Vous auriez probablement pu faire cela mieux.

You probably could've done that better.

Why: Causative faire. [[French#^fr-Q0887|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Vous%20auriez%20probablement%20pu%20faire%20cela%20mieux.)
^fr-Q0887-answer

**fr-Q0888** — Vous auriez probablement pu faire cela mieux.

You probably could've done that better.

Faire can mean do/make or form a causative with an infinitive: faire réparer, have repaired. Identify who arranges the action and who performs it. Not every occurrence of faire is causative.

Why: Causative faire. [[French#^fr-Q0888|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Vous%20auriez%20probablement%20pu%20faire%20cela%20mieux.)
^fr-Q0888-answer

**fr-Q0889** — Premièrement, parlons de ce que Tom a fait.

First, let's talk about what Tom did.

Expected form: **fait**

Why: Causative faire. [[French#^fr-Q0889|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Premi%C3%A8rement%2C%20parlons%20de%20ce%20que%20Tom%20a%20fait.)
^fr-Q0889-answer

**fr-Q0890** — Premièrement, parlons de ce que Tom a fait.

First, let's talk about what Tom did.

Expected form: **fait**

Why: Causative faire. [[French#^fr-Q0890|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Premi%C3%A8rement%2C%20parlons%20de%20ce%20que%20Tom%20a%20fait.)
^fr-Q0890-answer

**fr-Q0891** — Je sais tout ce que vous avez fait.

I know everything that you've done.

Expected form: **fait**

Why: Causative faire. [[French#^fr-Q0891|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20sais%20tout%20ce%20que%20vous%20avez%20fait.)
^fr-Q0891-answer

**fr-Q0892** — Je sais tout ce que vous avez fait.

I know everything that you've done.

Why: Causative faire. [[French#^fr-Q0892|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20sais%20tout%20ce%20que%20vous%20avez%20fait.)
^fr-Q0892-answer

**fr-Q0893** — Qu'avez-vous fait de votre voiture ?

What have you done with your car?

Why: Causative faire. [[French#^fr-Q0893|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Qu%27avez-vous%20fait%20de%20votre%20voiture%20%3F)
^fr-Q0893-answer

**fr-Q0894** — Qu'avez-vous fait de votre voiture ?

What have you done with your car?

Faire can mean do/make or form a causative with an infinitive: faire réparer, have repaired. Identify who arranges the action and who performs it. Not every occurrence of faire is causative.

Why: Causative faire. [[French#^fr-Q0894|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Qu%27avez-vous%20fait%20de%20votre%20voiture%20%3F)
^fr-Q0894-answer

**fr-Q0895** — Je n'ai rien fait à Tom.

I didn't do anything to Tom.

Expected form: **fait**

Why: Causative faire. [[French#^fr-Q0895|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20n%27ai%20rien%20fait%20%C3%A0%20Tom.)
^fr-Q0895-answer

**fr-Q0896** — Je n'ai rien fait à Tom.

I didn't do anything to Tom.

Expected form: **fait**

Why: Causative faire. [[French#^fr-Q0896|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20n%27ai%20rien%20fait%20%C3%A0%20Tom.)
^fr-Q0896-answer

**fr-Q0897** — Il fait froid là-dedans.

It's cold in here.

Expected form: **fait**

Why: Causative faire. [[French#^fr-Q0897|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Il%20fait%20froid%20l%C3%A0-dedans.)
^fr-Q0897-answer

**fr-Q0898** — Il fait froid là-dedans.

It's cold in here.

Why: Causative faire. [[French#^fr-Q0898|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Il%20fait%20froid%20l%C3%A0-dedans.)
^fr-Q0898-answer

**fr-Q0899** — Combien de temps cela fait-il ?

How long ago was that?

Why: Causative faire. [[French#^fr-Q0899|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Combien%20de%20temps%20cela%20fait-il%20%3F)
^fr-Q0899-answer

**fr-Q0900** — Combien de temps cela fait-il ?

How long ago was that?

Faire can mean do/make or form a causative with an infinitive: faire réparer, have repaired. Identify who arranges the action and who performs it. Not every occurrence of faire is causative.

Why: Causative faire. [[French#^fr-Q0900|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Combien%20de%20temps%20cela%20fait-il%20%3F)
^fr-Q0900-answer


### Answers 901–950

**fr-Q0901** — Est-ce ta petite copine ?

Is this your girlfriend?

Expected form: **petite**

Why: Adjective agreement. [[French#^fr-Q0901|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Est-ce%20ta%20petite%20copine%20%3F)
^fr-Q0901-answer

**fr-Q0902** — Est-ce ta petite copine ?

Is this your girlfriend?

Expected form: **petite**

Why: Adjective agreement. [[French#^fr-Q0902|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Est-ce%20ta%20petite%20copine%20%3F)
^fr-Q0902-answer

**fr-Q0903** — Ma mère m'a acheté un nouveau vélo.

Mother bought me a new bicycle.

Expected form: **nouveau**

Why: Adjective agreement. [[French#^fr-Q0903|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Ma%20m%C3%A8re%20m%27a%20achet%C3%A9%20un%20nouveau%20v%C3%A9lo.)
^fr-Q0903-answer

**fr-Q0904** — Ma mère m'a acheté un nouveau vélo.

Mother bought me a new bicycle.

Why: Adjective agreement. [[French#^fr-Q0904|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Ma%20m%C3%A8re%20m%27a%20achet%C3%A9%20un%20nouveau%20v%C3%A9lo.)
^fr-Q0904-answer

**fr-Q0905** — C'est de nouveau plein, aujourd'hui.

It's crowded again today.

Why: Adjective agreement. [[French#^fr-Q0905|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=C%27est%20de%20nouveau%20plein%2C%20aujourd%27hui.)
^fr-Q0905-answer

**fr-Q0906** — C'est de nouveau plein, aujourd'hui.

It's crowded again today.

Adjectives agree with the noun in gender and number, with many spelling changes. Their position can affect meaning. Written agreement is often more visible than spoken agreement.

Why: Adjective agreement. [[French#^fr-Q0906|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=C%27est%20de%20nouveau%20plein%2C%20aujourd%27hui.)
^fr-Q0906-answer

**fr-Q0907** — Tu es trop bon pour elle.

You're too good for her.

Expected form: **bon**

Why: Adjective agreement. [[French#^fr-Q0907|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tu%20es%20trop%20bon%20pour%20elle.)
^fr-Q0907-answer

**fr-Q0908** — Tu es trop bon pour elle.

You're too good for her.

Expected form: **bon**

Why: Adjective agreement. [[French#^fr-Q0908|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tu%20es%20trop%20bon%20pour%20elle.)
^fr-Q0908-answer

**fr-Q0909** — Le nouveau plan a bien fonctionné.

The new plan has been very successful.

Expected form: **nouveau**

Why: Adjective agreement. [[French#^fr-Q0909|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Le%20nouveau%20plan%20a%20bien%20fonctionn%C3%A9.)
^fr-Q0909-answer

**fr-Q0910** — Le nouveau plan a bien fonctionné.

The new plan has been very successful.

Why: Adjective agreement. [[French#^fr-Q0910|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Le%20nouveau%20plan%20a%20bien%20fonctionn%C3%A9.)
^fr-Q0910-answer

**fr-Q0911** — Garde un œil sur les garçons : ce sont des petits galopins.

Keep an eye on the boys. They're mischievous.

Why: Adjective agreement. [[French#^fr-Q0911|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Garde%20un%20%C5%93il%20sur%20les%20gar%C3%A7ons%20%3A%20ce%20sont%20des%20petits%20galopins.)
^fr-Q0911-answer

**fr-Q0912** — Garde un œil sur les garçons : ce sont des petits galopins.

Keep an eye on the boys. They're mischievous.

Adjectives agree with the noun in gender and number, with many spelling changes. Their position can affect meaning. Written agreement is often more visible than spoken agreement.

Why: Adjective agreement. [[French#^fr-Q0912|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Garde%20un%20%C5%93il%20sur%20les%20gar%C3%A7ons%20%3A%20ce%20sont%20des%20petits%20galopins.)
^fr-Q0912-answer

**fr-Q0913** — Ce nouveau vaisseau spatial est plus de deux fois plus rapide que les vaisseaux spatiaux précédents.

This new spacecraft is over twice as fast as previous spaceships.

Expected form: **nouveau**

Why: Adjective agreement. [[French#^fr-Q0913|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Ce%20nouveau%20vaisseau%20spatial%20est%20plus%20de%20deux%20fois%20plus%20rapide%20que%20les%20vaisseaux%20spatiaux%20pr%C3%A9c%C3%A9dents.)
^fr-Q0913-answer

**fr-Q0914** — Ce nouveau vaisseau spatial est plus de deux fois plus rapide que les vaisseaux spatiaux précédents.

This new spacecraft is over twice as fast as previous spaceships.

Expected form: **nouveau**

Why: Adjective agreement. [[French#^fr-Q0914|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Ce%20nouveau%20vaisseau%20spatial%20est%20plus%20de%20deux%20fois%20plus%20rapide%20que%20les%20vaisseaux%20spatiaux%20pr%C3%A9c%C3%A9dents.)
^fr-Q0914-answer

**fr-Q0915** — Mon ami a quitté sa petite copine et maintenant il veut sortir avec moi.

My friend broke up with his girlfriend and now he wants to go out with me.

Expected form: **petite**

Why: Adjective agreement. [[French#^fr-Q0915|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Mon%20ami%20a%20quitt%C3%A9%20sa%20petite%20copine%20et%20maintenant%20il%20veut%20sortir%20avec%20moi.)
^fr-Q0915-answer

**fr-Q0916** — Mon ami a quitté sa petite copine et maintenant il veut sortir avec moi.

My friend broke up with his girlfriend and now he wants to go out with me.

Why: Adjective agreement. [[French#^fr-Q0916|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Mon%20ami%20a%20quitt%C3%A9%20sa%20petite%20copine%20et%20maintenant%20il%20veut%20sortir%20avec%20moi.)
^fr-Q0916-answer

**fr-Q0917** — Le patron a une bonne opinion de votre travail.

The boss has a good opinion of your work.

Why: Adjective agreement. [[French#^fr-Q0917|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Le%20patron%20a%20une%20bonne%20opinion%20de%20votre%20travail.)
^fr-Q0917-answer

**fr-Q0918** — Le patron a une bonne opinion de votre travail.

The boss has a good opinion of your work.

Adjectives agree with the noun in gender and number, with many spelling changes. Their position can affect meaning. Written agreement is often more visible than spoken agreement.

Why: Adjective agreement. [[French#^fr-Q0918|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Le%20patron%20a%20une%20bonne%20opinion%20de%20votre%20travail.)
^fr-Q0918-answer

**fr-Q0919** — Il a une bonne réputation.

He has a good reputation.

Expected form: **bonne**

Why: Adjective agreement. [[French#^fr-Q0919|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Il%20a%20une%20bonne%20r%C3%A9putation.)
^fr-Q0919-answer

**fr-Q0920** — Il a une bonne réputation.

He has a good reputation.

Expected form: **bonne**

Why: Adjective agreement. [[French#^fr-Q0920|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Il%20a%20une%20bonne%20r%C3%A9putation.)
^fr-Q0920-answer

**fr-Q0921** — Un bon docteur est bien disposé à l'égard de ses patients.

A good doctor is sympathetic to his patients.

Expected form: **bon**

Why: Adjective agreement. [[French#^fr-Q0921|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Un%20bon%20docteur%20est%20bien%20dispos%C3%A9%20%C3%A0%20l%27%C3%A9gard%20de%20ses%20patients.)
^fr-Q0921-answer

**fr-Q0922** — Un bon docteur est bien disposé à l'égard de ses patients.

A good doctor is sympathetic to his patients.

Why: Adjective agreement. [[French#^fr-Q0922|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Un%20bon%20docteur%20est%20bien%20dispos%C3%A9%20%C3%A0%20l%27%C3%A9gard%20de%20ses%20patients.)
^fr-Q0922-answer

**fr-Q0923** — Le livre est nouveau.

The book is new.

Why: Adjective agreement. [[French#^fr-Q0923|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Le%20livre%20est%20nouveau.)
^fr-Q0923-answer

**fr-Q0924** — Le livre est nouveau.

The book is new.

Adjectives agree with the noun in gender and number, with many spelling changes. Their position can affect meaning. Written agreement is often more visible than spoken agreement.

Why: Adjective agreement. [[French#^fr-Q0924|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Le%20livre%20est%20nouveau.)
^fr-Q0924-answer

**fr-Q0925** — Mon tout petit frère dort dix heures par jour.

My baby brother sleeps ten hours a day.

Expected form: **petit**

Why: Adjective agreement. [[French#^fr-Q0925|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Mon%20tout%20petit%20fr%C3%A8re%20dort%20dix%20heures%20par%20jour.)
^fr-Q0925-answer

**fr-Q0926** — Mon tout petit frère dort dix heures par jour.

My baby brother sleeps ten hours a day.

Expected form: **petit**

Why: Adjective agreement. [[French#^fr-Q0926|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Mon%20tout%20petit%20fr%C3%A8re%20dort%20dix%20heures%20par%20jour.)
^fr-Q0926-answer

**fr-Q0927** — Sami est un bon plongeur.

Sami is a good diver.

Expected form: **bon**

Why: Adjective agreement. [[French#^fr-Q0927|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Sami%20est%20un%20bon%20plongeur.)
^fr-Q0927-answer

**fr-Q0928** — Sami est un bon plongeur.

Sami is a good diver.

Why: Adjective agreement. [[French#^fr-Q0928|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Sami%20est%20un%20bon%20plongeur.)
^fr-Q0928-answer

**fr-Q0929** — Tu es un très bon footballeur.

You're a very good football player.

Why: Adjective agreement. [[French#^fr-Q0929|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tu%20es%20un%20tr%C3%A8s%20bon%20footballeur.)
^fr-Q0929-answer

**fr-Q0930** — Tu es un très bon footballeur.

You're a very good football player.

Adjectives agree with the noun in gender and number, with many spelling changes. Their position can affect meaning. Written agreement is often more visible than spoken agreement.

Why: Adjective agreement. [[French#^fr-Q0930|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tu%20es%20un%20tr%C3%A8s%20bon%20footballeur.)
^fr-Q0930-answer

**fr-Q0931** — J'ai une petite faveur à vous demander.

I have a small favor to ask of you.

Expected form: **petite**

Why: Adjective agreement. [[French#^fr-Q0931|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=J%27ai%20une%20petite%20faveur%20%C3%A0%20vous%20demander.)
^fr-Q0931-answer

**fr-Q0932** — J'ai une petite faveur à vous demander.

I have a small favor to ask of you.

Expected form: **petite**

Why: Adjective agreement. [[French#^fr-Q0932|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=J%27ai%20une%20petite%20faveur%20%C3%A0%20vous%20demander.)
^fr-Q0932-answer

**fr-Q0933** — Ton téléphone sonne à nouveau.

Your phone is ringing again.

Expected form: **nouveau**

Why: Adjective agreement. [[French#^fr-Q0933|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Ton%20t%C3%A9l%C3%A9phone%20sonne%20%C3%A0%20nouveau.)
^fr-Q0933-answer

**fr-Q0934** — Ton téléphone sonne à nouveau.

Your phone is ringing again.

Why: Adjective agreement. [[French#^fr-Q0934|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Ton%20t%C3%A9l%C3%A9phone%20sonne%20%C3%A0%20nouveau.)
^fr-Q0934-answer

**fr-Q0935** — C'est étrange à dire, mais il ne connaissait pas la nouvelle.

Strange to say, he didn't know the news.

Why: Adjective agreement. [[French#^fr-Q0935|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=C%27est%20%C3%A9trange%20%C3%A0%20dire%2C%20mais%20il%20ne%20connaissait%20pas%20la%20nouvelle.)
^fr-Q0935-answer

**fr-Q0936** — C'est étrange à dire, mais il ne connaissait pas la nouvelle.

Strange to say, he didn't know the news.

Adjectives agree with the noun in gender and number, with many spelling changes. Their position can affect meaning. Written agreement is often more visible than spoken agreement.

Why: Adjective agreement. [[French#^fr-Q0936|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=C%27est%20%C3%A9trange%20%C3%A0%20dire%2C%20mais%20il%20ne%20connaissait%20pas%20la%20nouvelle.)
^fr-Q0936-answer

**fr-Q0937** — Elle a reçu un présent de son petit copain.

She got a present from her boyfriend.

Expected form: **petit**

Why: Adjective agreement. [[French#^fr-Q0937|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Elle%20a%20re%C3%A7u%20un%20pr%C3%A9sent%20de%20son%20petit%20copain.)
^fr-Q0937-answer

**fr-Q0938** — Elle a reçu un présent de son petit copain.

She got a present from her boyfriend.

Expected form: **petit**

Why: Adjective agreement. [[French#^fr-Q0938|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Elle%20a%20re%C3%A7u%20un%20pr%C3%A9sent%20de%20son%20petit%20copain.)
^fr-Q0938-answer

**fr-Q0939** — Elle est petite et grosse.

She's short and fat.

Expected form: **petite**

Why: Adjective agreement. [[French#^fr-Q0939|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Elle%20est%20petite%20et%20grosse.)
^fr-Q0939-answer

**fr-Q0940** — Elle est petite et grosse.

She's short and fat.

Why: Adjective agreement. [[French#^fr-Q0940|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Elle%20est%20petite%20et%20grosse.)
^fr-Q0940-answer

**fr-Q0941** — Quand la fille est entrée dans la pièce, certains garçons se sont moqués d'elle à cause de son petit chapeau.

When the girl entered the room, some boys made fun of her because of her little hat.

Why: Adjective agreement. [[French#^fr-Q0941|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Quand%20la%20fille%20est%20entr%C3%A9e%20dans%20la%20pi%C3%A8ce%2C%20certains%20gar%C3%A7ons%20se%20sont%20moqu%C3%A9s%20d%27elle%20%C3%A0%20cause%20de%20son%20petit%20chapeau.)
^fr-Q0941-answer

**fr-Q0942** — Quand la fille est entrée dans la pièce, certains garçons se sont moqués d'elle à cause de son petit chapeau.

When the girl entered the room, some boys made fun of her because of her little hat.

Adjectives agree with the noun in gender and number, with many spelling changes. Their position can affect meaning. Written agreement is often more visible than spoken agreement.

Why: Adjective agreement. [[French#^fr-Q0942|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Quand%20la%20fille%20est%20entr%C3%A9e%20dans%20la%20pi%C3%A8ce%2C%20certains%20gar%C3%A7ons%20se%20sont%20moqu%C3%A9s%20d%27elle%20%C3%A0%20cause%20de%20son%20petit%20chapeau.)
^fr-Q0942-answer

**fr-Q0943** — Je n'étais pas assez bonne.

I wasn't good enough.

Expected form: **bonne**

Why: Adjective agreement. [[French#^fr-Q0943|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20n%27%C3%A9tais%20pas%20assez%20bonne.)
^fr-Q0943-answer

**fr-Q0944** — Je n'étais pas assez bonne.

I wasn't good enough.

Expected form: **bonne**

Why: Adjective agreement. [[French#^fr-Q0944|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20n%27%C3%A9tais%20pas%20assez%20bonne.)
^fr-Q0944-answer

**fr-Q0945** — Pour être grand, il faut avoir été petit.

To be tall, you must have been small.

Expected form: **petit**

Why: Adjective agreement. [[French#^fr-Q0945|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Pour%20%C3%AAtre%20grand%2C%20il%20faut%20avoir%20%C3%A9t%C3%A9%20petit.)
^fr-Q0945-answer

**fr-Q0946** — Pour être grand, il faut avoir été petit.

To be tall, you must have been small.

Why: Adjective agreement. [[French#^fr-Q0946|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Pour%20%C3%AAtre%20grand%2C%20il%20faut%20avoir%20%C3%A9t%C3%A9%20petit.)
^fr-Q0946-answer

**fr-Q0947** — Vous n'avez pas le bon client !

You've got the wrong man!

Why: Adjective agreement. [[French#^fr-Q0947|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Vous%20n%27avez%20pas%20le%20bon%20client%20%21)
^fr-Q0947-answer

**fr-Q0948** — Vous n'avez pas le bon client !

You've got the wrong man!

Adjectives agree with the noun in gender and number, with many spelling changes. Their position can affect meaning. Written agreement is often more visible than spoken agreement.

Why: Adjective agreement. [[French#^fr-Q0948|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Vous%20n%27avez%20pas%20le%20bon%20client%20%21)
^fr-Q0948-answer

**fr-Q0949** — Je suis une petite enfant.

I'm a little child.

Expected form: **petite**

Why: Adjective agreement. [[French#^fr-Q0949|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20suis%20une%20petite%20enfant.)
^fr-Q0949-answer

**fr-Q0950** — Je suis une petite enfant.

I'm a little child.

Expected form: **petite**

Why: Adjective agreement. [[French#^fr-Q0950|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20suis%20une%20petite%20enfant.)
^fr-Q0950-answer


### Answers 951–1000

**fr-Q0951** — Mon meilleur ami est mort asphyxié.

My best friend died of asphyxiation.

Expected form: **meilleur**

Why: Comparison. [[French#^fr-Q0951|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Mon%20meilleur%20ami%20est%20mort%20asphyxi%C3%A9.)
^fr-Q0951-answer

**fr-Q0952** — Mon meilleur ami est mort asphyxié.

My best friend died of asphyxiation.

Why: Comparison. [[French#^fr-Q0952|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Mon%20meilleur%20ami%20est%20mort%20asphyxi%C3%A9.)
^fr-Q0952-answer

**fr-Q0953** — Tom est fort, mais Marie est plus forte.

Tom is strong, but Mary is stronger.

Why: Comparison. [[French#^fr-Q0953|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tom%20est%20fort%2C%20mais%20Marie%20est%20plus%20forte.)
^fr-Q0953-answer

**fr-Q0954** — Tom est fort, mais Marie est plus forte.

Tom is strong, but Mary is stronger.

Plus/moins ... que compare; aussi ... que expresses equality. Meilleur compares bon; mieux compares bien. Choose adjective versus adverb according to the phrase’s function.

Why: Comparison. [[French#^fr-Q0954|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tom%20est%20fort%2C%20mais%20Marie%20est%20plus%20forte.)
^fr-Q0954-answer

**fr-Q0955** — Un des plus gros problèmes dans notre société moderne, c'est que les gens ne voient pas le monde comme moi.

One of the biggest problems in our modern society is that the people don't see the world as I do.

Expected form: **plus**

Why: Comparison. [[French#^fr-Q0955|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Un%20des%20plus%20gros%20probl%C3%A8mes%20dans%20notre%20soci%C3%A9t%C3%A9%20moderne%2C%20c%27est%20que%20les%20gens%20ne%20voient%20pas%20le%20monde%20comme%20moi.)
^fr-Q0955-answer

**fr-Q0956** — Un des plus gros problèmes dans notre société moderne, c'est que les gens ne voient pas le monde comme moi.

One of the biggest problems in our modern society is that the people don't see the world as I do.

Expected form: **plus**

Why: Comparison. [[French#^fr-Q0956|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Un%20des%20plus%20gros%20probl%C3%A8mes%20dans%20notre%20soci%C3%A9t%C3%A9%20moderne%2C%20c%27est%20que%20les%20gens%20ne%20voient%20pas%20le%20monde%20comme%20moi.)
^fr-Q0956-answer

**fr-Q0957** — Un peu plus fort, s'il te plait.

A little louder, please.

Expected form: **plus**

Why: Comparison. [[French#^fr-Q0957|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Un%20peu%20plus%20fort%2C%20s%27il%20te%20plait.)
^fr-Q0957-answer

**fr-Q0958** — Un peu plus fort, s'il te plait.

A little louder, please.

Why: Comparison. [[French#^fr-Q0958|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Un%20peu%20plus%20fort%2C%20s%27il%20te%20plait.)
^fr-Q0958-answer

**fr-Q0959** — Tom est plus grand que Dan mais Tim est le garçon le plus grand dans le groupe.

Tom is taller than Dan but Tim is the tallest guy in the group.

Why: Comparison. [[French#^fr-Q0959|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tom%20est%20plus%20grand%20que%20Dan%20mais%20Tim%20est%20le%20gar%C3%A7on%20le%20plus%20grand%20dans%20le%20groupe.)
^fr-Q0959-answer

**fr-Q0960** — Tom est plus grand que Dan mais Tim est le garçon le plus grand dans le groupe.

Tom is taller than Dan but Tim is the tallest guy in the group.

Plus/moins ... que compare; aussi ... que expresses equality. Meilleur compares bon; mieux compares bien. Choose adjective versus adverb according to the phrase’s function.

Why: Comparison. [[French#^fr-Q0960|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tom%20est%20plus%20grand%20que%20Dan%20mais%20Tim%20est%20le%20gar%C3%A7on%20le%20plus%20grand%20dans%20le%20groupe.)
^fr-Q0960-answer

**fr-Q0961** — La vôtre n'est pas mal non plus.

Yours is not bad, either.

Expected form: **plus**

Why: Comparison. [[French#^fr-Q0961|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=La%20v%C3%B4tre%20n%27est%20pas%20mal%20non%20plus.)
^fr-Q0961-answer

**fr-Q0962** — La vôtre n'est pas mal non plus.

Yours is not bad, either.

Expected form: **plus**

Why: Comparison. [[French#^fr-Q0962|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=La%20v%C3%B4tre%20n%27est%20pas%20mal%20non%20plus.)
^fr-Q0962-answer

**fr-Q0963** — Un hochement de tête est aussi utile qu'un clin d'œil à un cheval aveugle.

A nod is as good as a wink to a blind horse.

Expected form: **aussi**

Why: Comparison. [[French#^fr-Q0963|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Un%20hochement%20de%20t%C3%AAte%20est%20aussi%20utile%20qu%27un%20clin%20d%27%C5%93il%20%C3%A0%20un%20cheval%20aveugle.)
^fr-Q0963-answer

**fr-Q0964** — Un hochement de tête est aussi utile qu'un clin d'œil à un cheval aveugle.

A nod is as good as a wink to a blind horse.

Why: Comparison. [[French#^fr-Q0964|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Un%20hochement%20de%20t%C3%AAte%20est%20aussi%20utile%20qu%27un%20clin%20d%27%C5%93il%20%C3%A0%20un%20cheval%20aveugle.)
^fr-Q0964-answer

**fr-Q0965** — Je n'ai pas lu son roman, et mon frère non plus.

I haven't read his novel, and my brother hasn't either.

Why: Comparison. [[French#^fr-Q0965|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20n%27ai%20pas%20lu%20son%20roman%2C%20et%20mon%20fr%C3%A8re%20non%20plus.)
^fr-Q0965-answer

**fr-Q0966** — Je n'ai pas lu son roman, et mon frère non plus.

I haven't read his novel, and my brother hasn't either.

Plus/moins ... que compare; aussi ... que expresses equality. Meilleur compares bon; mieux compares bien. Choose adjective versus adverb according to the phrase’s function.

Why: Comparison. [[French#^fr-Q0966|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20n%27ai%20pas%20lu%20son%20roman%2C%20et%20mon%20fr%C3%A8re%20non%20plus.)
^fr-Q0966-answer

**fr-Q0967** — Je ne me rappelle plus très bien.

I don't remember exactly.

Expected form: **plus**

Why: Comparison. [[French#^fr-Q0967|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20ne%20me%20rappelle%20plus%20tr%C3%A8s%20bien.)
^fr-Q0967-answer

**fr-Q0968** — Je ne me rappelle plus très bien.

I don't remember exactly.

Expected form: **plus**

Why: Comparison. [[French#^fr-Q0968|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20ne%20me%20rappelle%20plus%20tr%C3%A8s%20bien.)
^fr-Q0968-answer

**fr-Q0969** — Je t'aime aussi.

I love you, too.

Expected form: **aussi**

Why: Comparison. [[French#^fr-Q0969|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20t%27aime%20aussi.)
^fr-Q0969-answer

**fr-Q0970** — Je t'aime aussi.

I love you, too.

Why: Comparison. [[French#^fr-Q0970|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20t%27aime%20aussi.)
^fr-Q0970-answer

**fr-Q0971** — Même pour le jour le plus long vient le soir.

Even night falls on the longest day of the year.

Why: Comparison. [[French#^fr-Q0971|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=M%C3%AAme%20pour%20le%20jour%20le%20plus%20long%20vient%20le%20soir.)
^fr-Q0971-answer

**fr-Q0972** — Même pour le jour le plus long vient le soir.

Even night falls on the longest day of the year.

Plus/moins ... que compare; aussi ... que expresses equality. Meilleur compares bon; mieux compares bien. Choose adjective versus adverb according to the phrase’s function.

Why: Comparison. [[French#^fr-Q0972|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=M%C3%AAme%20pour%20le%20jour%20le%20plus%20long%20vient%20le%20soir.)
^fr-Q0972-answer

**fr-Q0973** — Une feuille de papier s'est coincée dans l'imprimante et depuis elle ne fonctionne plus.

A piece of paper got jammed in the printer and now it doesn't work.

Expected form: **plus**

Why: Comparison. [[French#^fr-Q0973|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Une%20feuille%20de%20papier%20s%27est%20coinc%C3%A9e%20dans%20l%27imprimante%20et%20depuis%20elle%20ne%20fonctionne%20plus.)
^fr-Q0973-answer

**fr-Q0974** — Une feuille de papier s'est coincée dans l'imprimante et depuis elle ne fonctionne plus.

A piece of paper got jammed in the printer and now it doesn't work.

Expected form: **plus**

Why: Comparison. [[French#^fr-Q0974|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Une%20feuille%20de%20papier%20s%27est%20coinc%C3%A9e%20dans%20l%27imprimante%20et%20depuis%20elle%20ne%20fonctionne%20plus.)
^fr-Q0974-answer

**fr-Q0975** — Tu es un peu plus grande que moi.

You're a bit taller than I am.

Expected form: **plus**

Why: Comparison. [[French#^fr-Q0975|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tu%20es%20un%20peu%20plus%20grande%20que%20moi.)
^fr-Q0975-answer

**fr-Q0976** — Tu es un peu plus grande que moi.

You're a bit taller than I am.

Why: Comparison. [[French#^fr-Q0976|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tu%20es%20un%20peu%20plus%20grande%20que%20moi.)
^fr-Q0976-answer

**fr-Q0977** — Sais-tu aussi compter en italien ?

Can you also count in Italian?

Why: Comparison. [[French#^fr-Q0977|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Sais-tu%20aussi%20compter%20en%20italien%20%3F)
^fr-Q0977-answer

**fr-Q0978** — Sais-tu aussi compter en italien ?

Can you also count in Italian?

Plus/moins ... que compare; aussi ... que expresses equality. Meilleur compares bon; mieux compares bien. Choose adjective versus adverb according to the phrase’s function.

Why: Comparison. [[French#^fr-Q0978|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Sais-tu%20aussi%20compter%20en%20italien%20%3F)
^fr-Q0978-answer

**fr-Q0979** — J'aimerai une couverture en plus.

I'd like one more blanket.

Expected form: **plus**

Why: Comparison. [[French#^fr-Q0979|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=J%27aimerai%20une%20couverture%20en%20plus.)
^fr-Q0979-answer

**fr-Q0980** — J'aimerai une couverture en plus.

I'd like one more blanket.

Expected form: **plus**

Why: Comparison. [[French#^fr-Q0980|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=J%27aimerai%20une%20couverture%20en%20plus.)
^fr-Q0980-answer

**fr-Q0981** — Le fer est plus dur que l'or.

Iron is harder than gold.

Expected form: **plus**

Why: Comparison. [[French#^fr-Q0981|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Le%20fer%20est%20plus%20dur%20que%20l%27or.)
^fr-Q0981-answer

**fr-Q0982** — Le fer est plus dur que l'or.

Iron is harder than gold.

Why: Comparison. [[French#^fr-Q0982|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Le%20fer%20est%20plus%20dur%20que%20l%27or.)
^fr-Q0982-answer

**fr-Q0983** — Rien n'est plus important que la compassion.

Nothing is more important than compassion.

Why: Comparison. [[French#^fr-Q0983|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Rien%20n%27est%20plus%20important%20que%20la%20compassion.)
^fr-Q0983-answer

**fr-Q0984** — Rien n'est plus important que la compassion.

Nothing is more important than compassion.

Plus/moins ... que compare; aussi ... que expresses equality. Meilleur compares bon; mieux compares bien. Choose adjective versus adverb according to the phrase’s function.

Why: Comparison. [[French#^fr-Q0984|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Rien%20n%27est%20plus%20important%20que%20la%20compassion.)
^fr-Q0984-answer

**fr-Q0985** — Aimez-vous mon frère plus que moi ?

Do you love my brother more than me?

Expected form: **plus**

Why: Comparison. [[French#^fr-Q0985|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Aimez-vous%20mon%20fr%C3%A8re%20plus%20que%20moi%20%3F)
^fr-Q0985-answer

**fr-Q0986** — Aimez-vous mon frère plus que moi ?

Do you love my brother more than me?

Expected form: **plus**

Why: Comparison. [[French#^fr-Q0986|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Aimez-vous%20mon%20fr%C3%A8re%20plus%20que%20moi%20%3F)
^fr-Q0986-answer

**fr-Q0987** — Ce n'est pas l'aspect le plus important du conte.

That's not the most important facet of the tale.

Expected form: **plus**

Why: Comparison. [[French#^fr-Q0987|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Ce%20n%27est%20pas%20l%27aspect%20le%20plus%20important%20du%20conte.)
^fr-Q0987-answer

**fr-Q0988** — Ce n'est pas l'aspect le plus important du conte.

That's not the most important facet of the tale.

Why: Comparison. [[French#^fr-Q0988|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Ce%20n%27est%20pas%20l%27aspect%20le%20plus%20important%20du%20conte.)
^fr-Q0988-answer

**fr-Q0989** — Je fus incapable de me tenir debout plus longtemps.

I was unable to stand any longer.

Why: Comparison. [[French#^fr-Q0989|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20fus%20incapable%20de%20me%20tenir%20debout%20plus%20longtemps.)
^fr-Q0989-answer

**fr-Q0990** — Je fus incapable de me tenir debout plus longtemps.

I was unable to stand any longer.

Plus/moins ... que compare; aussi ... que expresses equality. Meilleur compares bon; mieux compares bien. Choose adjective versus adverb according to the phrase’s function.

Why: Comparison. [[French#^fr-Q0990|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Je%20fus%20incapable%20de%20me%20tenir%20debout%20plus%20longtemps.)
^fr-Q0990-answer

**fr-Q0991** — La solution la plus simple est souvent la meilleure.

The simplest solution is often the best.

Expected form: **plus**

Why: Comparison. [[French#^fr-Q0991|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=La%20solution%20la%20plus%20simple%20est%20souvent%20la%20meilleure.)
^fr-Q0991-answer

**fr-Q0992** — La solution la plus simple est souvent la meilleure.

The simplest solution is often the best.

Expected form: **plus**

Why: Comparison. [[French#^fr-Q0992|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=La%20solution%20la%20plus%20simple%20est%20souvent%20la%20meilleure.)
^fr-Q0992-answer

**fr-Q0993** — Cela fait des siècles que l'argent a perdu sa matérialisation papier ou métallique. Ce n'est désormais plus que des chiffres dans l'ordinateur.

It's been centuries since money lost its paper and coin incarnations. They're just digits in the computer now.

Expected form: **plus**

Why: Comparison. [[French#^fr-Q0993|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Cela%20fait%20des%20si%C3%A8cles%20que%20l%27argent%20a%20perdu%20sa%20mat%C3%A9rialisation%20papier%20ou%20m%C3%A9tallique.%20Ce%20n%27est%20d%C3%A9sormais%20plus%20que%20des%20chiffres%20dans%20l%27ordinateur.)
^fr-Q0993-answer

**fr-Q0994** — Cela fait des siècles que l'argent a perdu sa matérialisation papier ou métallique. Ce n'est désormais plus que des chiffres dans l'ordinateur.

It's been centuries since money lost its paper and coin incarnations. They're just digits in the computer now.

Why: Comparison. [[French#^fr-Q0994|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Cela%20fait%20des%20si%C3%A8cles%20que%20l%27argent%20a%20perdu%20sa%20mat%C3%A9rialisation%20papier%20ou%20m%C3%A9tallique.%20Ce%20n%27est%20d%C3%A9sormais%20plus%20que%20des%20chiffres%20dans%20l%27ordinateur.)
^fr-Q0994-answer

**fr-Q0995** — Quel est le meilleur hôtel de la ville ?

Which is the best hotel in the town?

Why: Comparison. [[French#^fr-Q0995|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Quel%20est%20le%20meilleur%20h%C3%B4tel%20de%20la%20ville%20%3F)
^fr-Q0995-answer

**fr-Q0996** — Quel est le meilleur hôtel de la ville ?

Which is the best hotel in the town?

Plus/moins ... que compare; aussi ... que expresses equality. Meilleur compares bon; mieux compares bien. Choose adjective versus adverb according to the phrase’s function.

Why: Comparison. [[French#^fr-Q0996|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Quel%20est%20le%20meilleur%20h%C3%B4tel%20de%20la%20ville%20%3F)
^fr-Q0996-answer

**fr-Q0997** — Tom est plus sage que moi.

Tom is wiser than me.

Expected form: **plus**

Why: Comparison. [[French#^fr-Q0997|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tom%20est%20plus%20sage%20que%20moi.)
^fr-Q0997-answer

**fr-Q0998** — Tom est plus sage que moi.

Tom is wiser than me.

Expected form: **plus**

Why: Comparison. [[French#^fr-Q0998|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Tom%20est%20plus%20sage%20que%20moi.)
^fr-Q0998-answer

**fr-Q0999** — Ce dictionnaire est aussi utile que le tien.

This dictionary is as useful as yours.

Expected form: **aussi**

Why: Comparison. [[French#^fr-Q0999|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Ce%20dictionnaire%20est%20aussi%20utile%20que%20le%20tien.)
^fr-Q0999-answer

**fr-Q1000** — Ce dictionnaire est aussi utile que le tien.

This dictionary is as useful as yours.

Why: Comparison. [[French#^fr-Q1000|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fra&query=Ce%20dictionnaire%20est%20aussi%20utile%20que%20le%20tien.)
^fr-Q1000-answer


## Read and speak

Read the native sentence first, identify its predicate and one grammar form, then check the translation. Say it aloud and change one detail.

### Learning with a clear purpose

J’apprends une nouvelle langue. Chaque jour, je lis un texte court et j’écoute des exemples clairs. J’écris des mots utiles dans un cahier. Quand je fais une erreur, je vérifie la règle et j’essaie encore. Mon objectif est de comprendre les gens et d’exprimer mes idées clairement.

I am learning a new language. Each day, I read a short text and listen to clear examples. I write useful words in a notebook. When I make a mistake, I check the rule and try again. My goal is to understand people and express my ideas clearly.

### Philosophy: definitions and disagreement

Deux personnes peuvent employer le même mot sans lui donner exactement le même sens. Avant de conclure qu'elles sont en désaccord, il est donc utile de préciser les termes de la discussion. Une définition ne résout pas nécessairement le problème, mais elle permet de mieux identifier ce qui reste à expliquer. Il faut également distinguer une définition proposée pour un objectif particulier d'une description de l'usage ordinaire. Dans un débat sérieux, les exemples limites sont souvent aussi instructifs que les exemples évidents, car ils révèlent les conditions que l'on avait laissées implicites.

People can use the same word with different meanings. Clarifying terms can reveal whether they really disagree. A definition does not necessarily solve the problem, but makes the remaining issue clearer. A purpose-specific definition differs from a description of ordinary usage. Borderline examples can reveal previously implicit conditions.

![[Resources/Audio/fr/Reading passage.mp3]]

**Tom ne semble certainement pas savoir ce qu'il est en train de faire.**

Tom certainly doesn't seem to know what he's doing.

**Il a été condamné à de la prison.**

He was sentenced to prison.

**Il n'est qu'un homme d'affaires.**

He is nothing but a businessman.

**Je ne pense pas que tu devrais manger ça.**

I don't think you should eat that.

**Je n'ai pas appris cela en lisant.**

I didn't learn this through reading.

**C'est un très bon ami, mais il est un peu paresseux.**

He is a very good friend, yet a little lazy.

**Êtes-vous prêts pour le voyage ?**

Are you ready for the trip?

**Dans l'ouverture, ne déplacez que les pions qui aident à développer les pièces.**

In the opening, move only those pawns that help develop the pieces.

**Les livres de cet étudiant sont neufs.**

This student's books are new.

**Les lacets de Tom sont défaits.**

Tom's shoelaces are untied.

**J'ai décidé d'acheter la voiture bleue.**

I've decided to buy the blue car.

**Il s'est servi d'une fausse carte d'identité.**

He used a fake I.D.

**Tout le monde doit être au courant.**

Everybody must know.

**Puis-je utiliser ce téléphone ?**

May I use this telephone?

**Vous vous trompez. Ce n'est pas ce que j'ai dit.**

You're mistaken. That's not what I said.

## Professional writing

Write an introduction, a polite request, an explanation of a finding, a summary of a passage and a tactful disagreement. Use the professional/advanced lessons for models.

## PDF edition

[[Resources/PDFs/French.pdf|Open the complete printable book]]


<!-- individual-letter-audio -->
## Hear each letter separately

Play each letter’s own synthetic recording. English has separate US and UK models.

### A a · a

![[Resources/Audio/fr/Letters/001.mp3]]

### B b · bé

![[Resources/Audio/fr/Letters/002.mp3]]

### C c · cé

![[Resources/Audio/fr/Letters/003.mp3]]

### D d · dé

![[Resources/Audio/fr/Letters/004.mp3]]

### E e · e

![[Resources/Audio/fr/Letters/005.mp3]]

### F f · effe

![[Resources/Audio/fr/Letters/006.mp3]]

### G g · gé

![[Resources/Audio/fr/Letters/007.mp3]]

### H h · ache

![[Resources/Audio/fr/Letters/008.mp3]]

### I i · i

![[Resources/Audio/fr/Letters/009.mp3]]

### J j · ji

![[Resources/Audio/fr/Letters/010.mp3]]

### K k · ka

![[Resources/Audio/fr/Letters/011.mp3]]

### L l · elle

![[Resources/Audio/fr/Letters/012.mp3]]

### M m · emme

![[Resources/Audio/fr/Letters/013.mp3]]

### N n · enne

![[Resources/Audio/fr/Letters/014.mp3]]

### O o · o

![[Resources/Audio/fr/Letters/015.mp3]]

### P p · pé

![[Resources/Audio/fr/Letters/016.mp3]]

### Q q · ku

![[Resources/Audio/fr/Letters/017.mp3]]

### R r · erre

![[Resources/Audio/fr/Letters/018.mp3]]

### S s · esse

![[Resources/Audio/fr/Letters/019.mp3]]

### T t · té

![[Resources/Audio/fr/Letters/020.mp3]]

### U u · u

![[Resources/Audio/fr/Letters/021.mp3]]

### V v · vé

![[Resources/Audio/fr/Letters/022.mp3]]

### W w · double vé

![[Resources/Audio/fr/Letters/023.mp3]]

### X x · iks

![[Resources/Audio/fr/Letters/024.mp3]]

### Y y · i grec

![[Resources/Audio/fr/Letters/025.mp3]]

### Z z · zède

![[Resources/Audio/fr/Letters/026.mp3]]
<!-- /individual-letter-audio -->
