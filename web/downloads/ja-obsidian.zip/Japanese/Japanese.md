# Japanese

Professional ambition - C1-oriented study

Everything for this language is in this note. Open a rule, read its examples and follow its practice link. Answers stay in this same note.

[[Start Here|All languages]] · [[Sources and licenses|Sources]]

## Start reading

### 文字・五十音 (moji / gojūon)

| Written form | Name / reading | Related forms |
|---|---|---|
| あ | a  | ア |
| い | i  | イ |
| う | u  | ウ |
| え | e  | エ |
| お | o  | オ |
| か | ka  | カ |
| き | ki  | キ |
| く | ku  | ク |
| け | ke  | ケ |
| こ | ko  | コ |
| さ | sa  | サ |
| し | shi  | シ |
| す | su  | ス |
| せ | se  | セ |
| そ | so  | ソ |
| た | ta  | タ |
| ち | chi  | チ |
| つ | tsu  | ツ |
| て | te  | テ |
| と | to  | ト |
| な | na  | ナ |
| に | ni  | ニ |
| ぬ | nu  | ヌ |
| ね | ne  | ネ |
| の | no  | ノ |
| は | ha  | ハ |
| ひ | hi  | ヒ |
| ふ | fu  | フ |
| へ | he  | ヘ |
| ほ | ho  | ホ |
| ま | ma  | マ |
| み | mi  | ミ |
| む | mu  | ム |
| め | me  | メ |
| も | mo  | モ |
| や | ya  | ヤ |
| ゆ | yu  | ユ |
| よ | yo  | ヨ |
| ら | ra  | ラ |
| り | ri  | リ |
| る | ru  | ル |
| れ | re  | レ |
| ろ | ro  | ロ |
| わ | wa  | ワ |
| を | o (written wo)  | ヲ |
| ん | n  | ン |

![[Resources/Audio/ja/Script and first phrases.mp3]]

The player above is synthetic speech. Word tracks below work offline.

### Three systems work together

Hiragana writes grammar endings and many ordinary words. Katakana writes many loanwords, names and emphasis. Kanji are characters with meanings and context-dependent readings. The table contains the 46 basic hiragana and their katakana partners; this is a syllabary, not an English-style alphabet.

### Modify kana and count morae

Dakuten ゛ gives forms such as か→が, さ→ざ, た→だ, は→ば. Handakuten ゜ gives は→ぱ. Small ゃ/ゅ/ょ combine: きゃ = kya, one mora. Small っ marks a held consonant. Long vowels occupy an extra mora: おばさん = aunt; おばあさん = grandmother. Katakana often uses ー for length.

### Particles and pitch

Topic は is pronounced wa, directional へ is e, and object を is o. Japanese r is usually a tap. Pitch accent differs by word and region; romaji does not show it. Learn recordings in context, then reduce dependence on romaji.

### The complete voiced rows

Voiced kana: が ぎ ぐ げ ご / ガ ギ グ ゲ ゴ; ざ じ ず ぜ ぞ / ザ ジ ズ ゼ ゾ; だ ぢ づ で ど / ダ ヂ ヅ デ ド; ば び ぶ べ ぼ / バ ビ ブ ベ ボ. Semi-voiced: ぱ ぴ ぷ ぺ ぽ / パ ピ プ ペ ポ. In much standard speech, じ/ぢ and ず/づ share a pronunciation but retain distinct conventional spellings.

### Small-y combinations

きゃ きゅ きょ; しゃ しゅ しょ; ちゃ ちゅ ちょ; にゃ にゅ にょ; ひゃ ひゅ ひょ; みゃ みゅ みょ; りゃ りゅ りょ; ぎゃ ぎゅ ぎょ; じゃ じゅ じょ; びゃ びゅ びょ; ぴゃ ぴゅ ぴょ. Each combination occupies one mora. Katakana has matching combinations and additional loanword combinations such as ティ and ファ.

### Build a written word

に + ほ + ん → にほん; 日本 = Japan (Nihon/Nippon depending on context). Do not assume a kanji has only one reading.

### Attach a verb ending

食べる → 食べます → 食べません → 食べました = eat → eat (polite) → do not eat (polite) → ate (polite). Recognise the stem and the ending.

### Build a sentence

私は日本語を勉強しています。 = I am studying Japanese. は marks the topic; を marks the object; the predicate comes at the end. Subjects can be omitted when understood.

**こんにちは。**

Hello.

**日本語を勉強しています。**

I am studying Japanese.

**もう一度言ってください。**

Please say it again.

**この言葉はどういう意味ですか。**

What does this word mean?

### Grammar terms in plain English

**Noun** — A word naming a person, thing or idea: student, book, freedom.

**Verb** — A word describing an action or state: read, know, be.

**Subject** — The participant linked to the main verb’s subject pattern. In The student reads a book, the student is the subject.

**Object** — A participant selected by a verb. In The student reads a book, a book is the direct object.

**Agreement** — One word changes to match another, for example an adjective matching a noun’s gender and number.

**Case** — A noun/pronoun form marking its relationship in a sentence. Cases can mark subjects, objects, possession or relations usually expressed by English prepositions.

**Gender** — A grammatical noun class. It does not always describe the sex of a person or any physical property.

**Tense** — A verb system that relates a situation to a time, often past or non-past.

**Aspect** — How a situation is viewed: unfolding, completed, habitual, experienced or in a resulting state.

**Infinitive** — A non-finite verb form often used for a dictionary entry or a complement. It does not by itself give the ordinary person/tense pattern.

**Participle** — A verb-derived form used in compound predicates or as a modifier; its exact function depends on the language and construction.

**Clause** — A unit organised around a predicate. One sentence can contain several clauses.

**Register** — Language choices suited to a situation: casual conversation, polite requests, academic writing or another context.

## Grammar, examples and practice

### Particles and topic-comment structure

Japanese often places the predicate at the end and omits recoverable arguments. は frames a topic, が commonly marks a subject or focused identification, を an object, に a goal/time or other governed relation, and で a setting or means. Their functions are not one-word English translations. Contrast can make は replace or accompany certain marking. First identify the predicate, then reconstruct its arguments from context.

**私は図書館で本を読みます。**

I read books at the library. は topic, で action setting, を object.

**この方法が重要です。**

This method is important. が identifies the subject in this context.

#### Topic は

は marks a topic or contrast and is pronounced wa as a particle. A topic is not necessarily a grammatical subject. Japanese can omit participants understood from context.

**彼女は無邪気なふりをした。**

She pretended innocence.

**私は息子に芝生に水を撒かせた。**

I had my son water the lawn.

![[Resources/Audio/ja/Rule 01.mp3]]

[[Japanese#^ja-Q0001|Practise this rule (50 questions)]]

#### Subject and focus が

が often marks a subject or focused identification. Certain predicates govern が for a participant English treats differently. It also links clauses with a contrasting meaning in another construction.

**怒鳴りつけたかったが思いとどまった。**

He was about to explode, but checked himself.

**オーストラリアには多くのおもしろい動物がいる。**

There are many interesting animals in Australia.

![[Resources/Audio/ja/Rule 02.mp3]]

[[Japanese#^ja-Q0051|Practise this rule (50 questions)]]

#### Object を

を commonly marks a direct object and is pronounced o. It can also mark a route or place traversed. Identify the verb’s construction rather than applying one English object rule.

**お留守中の猫の世話をして上げましょう。**

While they are away, let's take care of their cat.

**もっと時間をかけて発表を準備すべきだったと先生に言われた。**

My teacher told me that I should have spent more time preparing my presentation.

![[Resources/Audio/ja/Rule 03.mp3]]

[[Japanese#^ja-Q0101|Practise this rule (50 questions)]]

#### に relations

に marks many destinations, recipients, time points and locations with existence predicates. It is also part of other grammatical constructions. Contrast event location with で.

**パーティーに行かない。**

I'm not going to go to the party.

**明日買い物に行きます。**

I'm going shopping tomorrow.

![[Resources/Audio/ja/Rule 04.mp3]]

[[Japanese#^ja-Q0151|Practise this rule (50 questions)]]

#### で relations

で often marks event location, means or material. Compare 学校にいる, be at school, with 学校で勉強する, study at school. It can also link a noun/adjectival predicate.

**彼は本当のところ支配人ではない。**

He is actually not the manager.

**トムね、自分で髪切ったのよ。**

Tom cut his own hair.

![[Resources/Audio/ja/Rule 05.mp3]]

[[Japanese#^ja-Q0201|Practise this rule (50 questions)]]

#### Possession and modification の

の links nouns in many relationships, including possession. It can also nominalise a clause. The relation is broader than English possessive ’s.

**彼女の友達は歌手です。**

Her friend is a singer.

**これまた政府の隠ぺい策のようです。**

This looks like another government cover-up.

![[Resources/Audio/ja/Rule 06.mp3]]

[[Japanese#^ja-Q0251|Practise this rule (50 questions)]]

#### Quotation and accompaniment と

と links an exhaustive noun list, marks accompaniment, quotes content and occurs in a conditional pattern. Its role depends on what follows.

**彼は全く不可能だと言った。**

He said it was out of the question.

**暑いと牛乳はすぐに腐る。**

Milk does not keep long on a hot day.

![[Resources/Audio/ja/Rule 07.mp3]]

[[Japanese#^ja-Q0301|Practise this rule (50 questions)]]

#### Inclusion も

も often means also/even and replaces or combines with another marker. In negative quantity expressions it can help convey not even/none. The scope is set by the phrase it follows.

**金は鉄よりも貴重だ。**

Gold is more precious than iron.

**街はクリスマスムード一色・・・もうじきイブだ。**

The streets are in full Christmas mode - it's almost Christmas Eve.

![[Resources/Audio/ja/Rule 08.mp3]]

[[Japanese#^ja-Q0351|Practise this rule (50 questions)]]

<details><summary>Why are は and が not simply interchangeable?</summary>

They organise topic, focus and grammatical relations differently. Context and contrast affect the choice.

</details>

<details><summary>Identify the action setting in the first example.</summary>

図書館で. で marks where reading takes place.

</details>

### Verb forms, negation and aspect

Learn verbs by conjugation class and core dictionary, negative, past and て forms. 読む becomes 読まない, 読んだ, 読んで. Polite forms such as 読みます express register. ている can mark ongoing activity or a resulting state depending on the verb: 読んでいる is reading; 結婚している is being married. Past た is not a universal completed-action marker divorced from discourse.

**今、報告書を読んでいます。**

I am reading the report now. ている presents an ongoing activity.

**結果はまだ分かりません。**

The result is not yet known to me/us. Polite negative; context supplies the experiencer.

#### Polite present ending

ます marks a polite affirmative non-past predicate. Japanese non-past covers present habits and many future contexts. Attach it to the appropriate verb stem, not the dictionary form unchanged.

**食事ですよ。今、いきます。**

Dinner's ready. I'm coming.

**列車は時刻通りに出ますか。**

Will the train leave on time?

![[Resources/Audio/ja/Rule 09.mp3]]

[[Japanese#^ja-Q0401|Practise this rule (50 questions)]]

#### Polite past ending

ました marks a polite affirmative past form. Recognise the verb stem and preceding complements before converting a sentence to past.

**ガソリンスタンドを探しましょう。燃料がなくなってしまいました。**

Let's find a gas station; we've run out of fuel.

**こつが飲み込めましたか。**

Got the hang of it?

![[Resources/Audio/ja/Rule 10.mp3]]

[[Japanese#^ja-Q0451|Practise this rule (50 questions)]]

#### Polite negation

ません marks a polite non-past negative. Past polite negative commonly uses ませんでした. The negative form also participates in some invitations/questions.

**彼女は私にお金を返してくれませんでした。**

She didn't give me my money back.

**駅までの行き方を教えていただけませんか。**

Could you tell me how to get to the station?

![[Resources/Audio/ja/Rule 11.mp3]]

[[Japanese#^ja-Q0501|Practise this rule (50 questions)]]

#### Plain negation

Plain negative verbs commonly end in ない with class-dependent stem changes. Some adjectives and copulas have their own negative constructions. Do not attach ない indiscriminately to every dictionary form.

**私をどなり散らす人は気にならないわ。**

The ones who shout at me don't bother me.

**そのなぞなぞの解き方が解らない。**

I can't figure out how to solve the puzzle.

![[Resources/Audio/ja/Rule 12.mp3]]

[[Japanese#^ja-Q0551|Practise this rule (50 questions)]]

#### Te-form links and requests

The te-form joins predicates and builds constructions such as requests and いる aspect. The stem change depends on verb class. ている can mark an ongoing action or a resulting state.

**私はあなたのぐちには死ぬほどうんざりしている。**

I am sick to death of your complaints.

**君の成功は主に好機をいかにして上手に利用するかにかかっている。**

Your success will largely depend upon how you will make good use of your opportunity.

![[Resources/Audio/ja/Rule 13.mp3]]

[[Japanese#^ja-Q0601|Practise this rule (50 questions)]]

#### Plain past and experience

A past form plus ことがある expresses experience. A past verb also modifies a noun directly. The construction as a whole determines the reading; the ending alone does not establish experience.

**これ見たことある？**

Have you seen this?

**彼は涙を流したことがはずかしかった。**

He was ashamed of his tears.

![[Resources/Audio/ja/Rule 14.mp3]]

[[Japanese#^ja-Q0651|Practise this rule (50 questions)]]

<details><summary>Give the て-form of 書く.</summary>

書いて. It belongs to the relevant consonant-verb pattern.

</details>

<details><summary>Does ている always mean an action occurring now?</summary>

No. It can mark resulting states, habits and other context-dependent interpretations.

</details>

### Modifiers, clauses and formal reasoning

A modifying clause normally precedes its noun without an English relative pronoun: 昨日読んだ本. Quotation and report use と; nominalisers such as こと and の turn propositions into noun-like structures with different distributions. ので often presents a reason with explanatory framing; から is also causal. Conditions と, ば, たら and なら differ in time, assumption and speaker intention.

**昨日読んだ論文**

the paper I read yesterday Pre-nominal clause modifier.

**条件が変われば、結果も変わります。**

If conditions change, the result changes too. ば conditional; も adds the result to the relation.

#### Cause

から and ので can supply reasons. から also marks a source/start point. Degree of explicitness and discourse tone differ between causal expressions.

**彼は窓から出て行った。**

He went out the window.

**月は地球から遠い。**

The moon is distant from the earth.

![[Resources/Audio/ja/Rule 15.mp3]]

[[Japanese#^ja-Q0701|Practise this rule (50 questions)]]

#### Contrast and concession

These forms connect contrast or concession but differ in grammar and register. のに presents a contrary-to-expectation relation. でも has additional functions, including examples and alternatives.

**少女は友達にお茶をいれるのに忙しかった。**

The girl was busy making tea for her friend.

**彼が話をやめるように頼んだが、彼はそれでもはなしつづけた。**

I asked him to stop talking, but he still went on.

![[Resources/Audio/ja/Rule 16.mp3]]

[[Japanese#^ja-Q0751|Practise this rule (50 questions)]]

#### Conditions

Japanese has several condition constructions with different timing and assumptions. もし can flag an if scenario but does not replace the needed predicate form. Avoid treating と, ば, たら and なら as fully interchangeable.

**長い目で見れば、正直は報われる。**

Honesty pays in the long run.

**「もしも僕が豚になっても、変わらず友達でいてくれる？」「もちろんだよ！」**

'Would you still be my friend even if I turned into a pig all of a sudden?' 'Of course!'

![[Resources/Audio/ja/Rule 17.mp3]]

[[Japanese#^ja-Q0801|Practise this rule (50 questions)]]

#### Nominalisation and explanation

こと can nominalise a proposition/activity. のです/んです adds explanatory framing. A nominalised clause can itself take particles and play a noun-like role.

**これ、本当にノンアルコールビールなんですか？**

Is this really a non-alcoholic beer?

**大統領は発展途上諸国に十分な援助を提供することを決めた。**

The President decided to provide developing countries with sufficient aid.

![[Resources/Audio/ja/Rule 18.mp3]]

[[Japanese#^ja-Q0851|Practise this rule (50 questions)]]

<details><summary>Find the head of 昨日読んだ論文.</summary>

論文. The preceding clause modifies it.

</details>

<details><summary>Why should four Japanese conditionals not be learned as identical if words?</summary>

Their restrictions differ for automatic consequences, future events, suppositions and decisions.

</details>

### Respect, humility and workplace language

Honorific and humble expressions position people in a social relationship. 尊敬語 elevates an appropriate person's action, while 謙譲語 lowers the speaker's side in relevant relations. Polite です/ます does not cover the entire honorific system. Learn who performs each action and toward whom it is directed. A memorised respectful verb used for your own action can reverse the intended relationship.

**確認していただけますか。**

Could you check it for me/us? A courteous request using an receiving-benefit structure.

**担当者に確認いたします。**

I will check with the person in charge. いたす is a humble form associated with the speaker's action.

#### Polite requests

Politeness depends on the entire construction and social relationship. Honorific and humble forms orient differently to whose action is described; they are not merely longer synonyms.

**知らせてください。**

Please let me know.

**私にお茶を入れてください。**

Please make me some tea.

![[Resources/Audio/ja/Rule 19.mp3]]

[[Japanese#^ja-Q0901|Practise this rule (50 questions)]]

<details><summary>What must you identify before choosing an honorific form?</summary>

Agent, recipient, in-group/out-group relation, relationship and medium.

</details>

<details><summary>Write a courteous clarification request.</summary>

この点について、もう少し詳しく説明していただけますか。 A fuller explanation is requested without a blunt command.

</details>

### Professional reading and inference

Formal Japanese uses nominalisation, passive perspectives and long modifiers. Distinguish 示す show/indicate, 示唆する suggest and 証明する prove.
Teaching passage: この結果は、二つの要因の関連を示している。しかし、一方が他方の原因であることを証明しているわけではない。結論を評価する際には、調査の条件を確認する必要がある。
Translation: This result indicates an association between two factors. However, it does not mean that it proves one is the cause of the other. When evaluating the conclusion, the investigation conditions need checking.

**証明しているわけではない**

it does not mean that it proves ... わけではない denies the stated interpretation, not necessarily every related possibility.

**評価する際には**

when evaluating 際 is a formal occasion/time noun modified by a verb.

#### Questions and stance

か can mark a question or embed one; でしょう and かもしれない express stance at different strengths. A cautious inference does not have the same force as a factual assertion.

**現在はどちらにお住まいですか。**

Where do you live now?

**風呂場はどこですか。**

Where is the bathroom?

![[Resources/Audio/ja/Rule 20.mp3]]

[[Japanese#^ja-Q0951|Practise this rule (50 questions)]]

<details><summary>What claim does the passage avoid?</summary>

It avoids treating association as proven causation.

</details>

<details><summary>Write a source summary and identify one limitation.</summary>

Preserve predicate scope, omitted referents and distinctions between evidence and interpretation.

</details>

## Word bank and recordings

1,000 study entries, based on dictionary selections and authored teaching glosses. Learn a word in a phrase; consult the linked entry for additional senses.

<details><summary>Words 1–50</summary>

![[Resources/Audio/ja/Words 0001-0050.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [の](https://en.wiktionary.org/wiki/%E3%81%AE#Japanese) | indicates possession, where the preceding noun owns or is the agent of the following noun: of, -’s | no · particle |
| [に](https://en.wiktionary.org/wiki/%E3%81%AB#Japanese) | marks the recipient of an action; to | ni · particle |
| [て](https://en.wiktionary.org/wiki/%E3%81%A6#Japanese) | used after ん (n) | te · particle |
| [は](https://en.wiktionary.org/wiki/%E3%81%AF#Japanese) | marks the topic of the clause, sentence, or conversation | wa · particle |
| [が](https://en.wiktionary.org/wiki/%E3%81%8C#Japanese) | indicates the subject of a verb | ga · particle |
| [を](https://en.wiktionary.org/wiki/%E3%82%92#Japanese) | An accusative case particle: a grammatical marker following the direct object of a verb. | o · particle |
| [で](https://en.wiktionary.org/wiki/%E3%81%A7#Japanese) | indicating a location or duration at which something happens | de · particle |
| [し](https://en.wiktionary.org/wiki/%E3%81%97#Japanese) | conjunctive particle, separates items in a list of reasons | shi · particle |
| [と](https://en.wiktionary.org/wiki/%E3%81%A8#Japanese) | with; marks a companion, partner, etc. that an action is done with | to · particle |
| [な](https://en.wiktionary.org/wiki/%E3%81%AA#Japanese) | used to get someone's attention, generally carries neutral or slightly positive connotations | na · intj |
| [ない](https://en.wiktionary.org/wiki/%E3%81%AA%E3%81%84#Japanese) | nonexistent, not existing, not there, no | nai · adj |
| [も](https://en.wiktionary.org/wiki/%E3%82%82#Japanese) | too, also, as well | mo · particle |
| [だ](https://en.wiktionary.org/wiki/%E3%81%A0#Japanese) | to be | da · verb |
| [か](https://en.wiktionary.org/wiki/%E3%81%8B#Japanese) | marks a statement as a question | ka · particle |
| [です](https://en.wiktionary.org/wiki/%E3%81%A7%E3%81%99#Japanese) | indicates politeness | desu · verb |
| [する](https://en.wiktionary.org/wiki/%E3%81%99%E3%82%8B#Japanese) | to do; to perform an action | suru · verb |
| [よ](https://en.wiktionary.org/wiki/%E3%82%88#Japanese) | indicates certainty, conviction, or emphasis | yo · particle |
| [さ](https://en.wiktionary.org/wiki/%E3%81%95#Japanese) | third person personal pronoun; they | sa · pron |
| [れ](https://en.wiktionary.org/wiki/%E3%82%8C#Japanese) | the wind | re · noun |
| [ね](https://en.wiktionary.org/wiki/%E3%81%AD#Japanese) | emphasis and question marker particle; asks for confirmation; right?; eh?; isn't it, innit? | ne · particle |
| [ある](https://en.wiktionary.org/wiki/%E3%81%82%E3%82%8B#Japanese) | 有る: (inanimate) to exist, be in existence | aru · verb |
| [い](https://en.wiktionary.org/wiki/%E3%81%84#Japanese) | Used in compounds with certain sentence-ending particles to create a familiar effect. | i · particle |
| [人](https://en.wiktionary.org/wiki/%E4%BA%BA#Japanese) | a person, human | hito · noun |
| [や](https://en.wiktionary.org/wiki/%E3%82%84#Japanese) | used to express a nonexhaustive list: and, or | ya · particle |
| [日](https://en.wiktionary.org/wiki/%E6%97%A5#Japanese) | 陽: the sun | hi · noun |
| [いい](https://en.wiktionary.org/wiki/%E3%81%84%E3%81%84#Japanese) | good | ii · adj |
| [そう](https://en.wiktionary.org/wiki/%E3%81%9D%E3%81%86#Japanese) | so, like that, in such a way, such | sō · adv |
| [ば](https://en.wiktionary.org/wiki/%E3%81%B0#Japanese) | In Modern Japanese, attaches to the kateikei, and in Classical Japanese, attaches to the mizenkei, to express the hypothetical condition: if | -ba · particle |
| [年](https://en.wiktionary.org/wiki/%E5%B9%B4#Japanese) | a year | nen · noun |
| [その](https://en.wiktionary.org/wiki/%E3%81%9D%E3%81%AE#Japanese) | uh, umm, er | sono · intj |
| [的](https://en.wiktionary.org/wiki/%E7%9A%84#Japanese) | a target, a mark, a bullseye | mato · noun |
| [なら](https://en.wiktionary.org/wiki/%E3%81%AA%E3%82%89#Japanese) | A conditional particle appended to a noun or the plain form of a verb or adjective. | nara · particle |
| [者](https://en.wiktionary.org/wiki/%E8%80%85#Japanese) | person | mono · noun |
| [月](https://en.wiktionary.org/wiki/%E6%9C%88#Japanese) | the Moon | tsuki · noun |
| [見](https://en.wiktionary.org/wiki/%E8%A6%8B#Japanese) | seeing, looking | mi · noun |
| [中](https://en.wiktionary.org/wiki/%E4%B8%AD#Japanese) | the middle, medium | chū · noun |
| [それ](https://en.wiktionary.org/wiki/%E3%81%9D%E3%82%8C#Japanese) | that (near the addressee) | sore · pron |
| [何](https://en.wiktionary.org/wiki/%E4%BD%95#Japanese) | what?, huh? | nani · intj |
| [私](https://en.wiktionary.org/wiki/%E7%A7%81#Japanese) | a personal or private matter | watakushi · noun |
| [わ](https://en.wiktionary.org/wiki/%E3%82%8F#Japanese) | a particle used in the end of sentences to indicate emphasis | wa · particle |
| [時](https://en.wiktionary.org/wiki/%E6%99%82#Japanese) | time | toki · noun |
| [もの](https://en.wiktionary.org/wiki/%E3%82%82%E3%81%AE#Japanese) | indicates a reason or cause; because | mono · particle |
| [へ](https://en.wiktionary.org/wiki/%E3%81%B8#Japanese) | to, towards (indicates a destination or movement toward something) | e · particle |
| [一](https://en.wiktionary.org/wiki/%E4%B8%80#Japanese) | one, 1 | ichi · num |
| [今](https://en.wiktionary.org/wiki/%E4%BB%8A#Japanese) | now | ima · adv |
| [方](https://en.wiktionary.org/wiki/%E6%96%B9#Japanese) | direction, way, side | hō · noun |
| [き](https://en.wiktionary.org/wiki/%E3%81%8D#Japanese) | indicates certainty, conviction, or emphasis | ki · particle |
| [せ](https://en.wiktionary.org/wiki/%E3%81%9B#Japanese) | rapids, current | se · noun |
| [俺](https://en.wiktionary.org/wiki/%E4%BF%BA#Japanese) | I, me | ore · pron |
| [前](https://en.wiktionary.org/wiki/%E5%89%8D#Japanese) | the front | mae · noun |

</details>

<details><summary>Words 51–100</summary>

![[Resources/Audio/ja/Words 0051-0100.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [気](https://en.wiktionary.org/wiki/%E6%B0%97#Japanese) | spirit, mood | ki · noun |
| [目](https://en.wiktionary.org/wiki/%E7%9B%AE#Japanese) | 目, 眼: eye | me · noun |
| [できる](https://en.wiktionary.org/wiki/%E3%81%A7%E3%81%8D%E3%82%8B#Japanese) | to be able to do | dekiru · verb |
| [話](https://en.wiktionary.org/wiki/%E8%A9%B1#Japanese) | talking, speaking, speech, conversation | hanashi · noun |
| [出](https://en.wiktionary.org/wiki/%E5%87%BA#Japanese) | being from a certain place | shutsu · noun |
| [分](https://en.wiktionary.org/wiki/%E5%88%86#Japanese) | a minute (unit of time) | fun · noun |
| [家](https://en.wiktionary.org/wiki/%E5%AE%B6#Japanese) | a house | ie · noun |
| [円](https://en.wiktionary.org/wiki/%E5%86%86#Japanese) | a round or circular object; a circle; roundness | en · noun |
| [後](https://en.wiktionary.org/wiki/%E5%BE%8C#Japanese) | the back, the rear, behind | ato · noun |
| [二](https://en.wiktionary.org/wiki/%E4%BA%8C#Japanese) | two, 2 | ni · noun |
| [良い](https://en.wiktionary.org/wiki/%E8%89%AF%E3%81%84#Japanese) | good | yoi · adj |
| [ぞ](https://en.wiktionary.org/wiki/%E3%81%9E#Japanese) | a particle used at the end of sentences, which indicates certainty, emphasis or even a warning or a threat. | zo · particle |
| [性](https://en.wiktionary.org/wiki/%E6%80%A7#Japanese) | the nature of something | shō · noun |
| [上](https://en.wiktionary.org/wiki/%E4%B8%8A#Japanese) | the above | ue · noun |
| [回](https://en.wiktionary.org/wiki/%E5%9B%9E#Japanese) | time, occasion | kai · noun |
| [数](https://en.wiktionary.org/wiki/%E6%95%B0#Japanese) | number; amount | kazu · noun |
| [万](https://en.wiktionary.org/wiki/%E4%B8%87#Japanese) | ten thousand, myriad | man · noun |
| [世界](https://en.wiktionary.org/wiki/%E4%B8%96%E7%95%8C#Japanese) | world | sekai · noun |
| [他](https://en.wiktionary.org/wiki/%E4%BB%96#Japanese) | another, other, some other, the rest | hoka · noun |
| [本](https://en.wiktionary.org/wiki/%E6%9C%AC#Japanese) | a book | hon · noun |
| [誰](https://en.wiktionary.org/wiki/%E8%AA%B0#Japanese) | interrogative personal pronoun: who, whom | dare · pron |
| [あれ](https://en.wiktionary.org/wiki/%E3%81%82%E3%82%8C#Japanese) | that one over there (far from the speaker and the addressee) | are · pron |
| [言う](https://en.wiktionary.org/wiki/%E8%A8%80%E3%81%86#Japanese) | to say, to tell somebody | iu · verb |
| [市](https://en.wiktionary.org/wiki/%E5%B8%82#Japanese) | a market, a marketplace | ichi · noun |
| [県](https://en.wiktionary.org/wiki/%E7%9C%8C#Japanese) | a type of administrative district, including 43 of the 47 prefectures of modern Japan, Chinese counties, French departments, etc. | ken · noun |
| [あなた](https://en.wiktionary.org/wiki/%E3%81%82%E3%81%AA%E3%81%9F#Japanese) | 貴方, 貴女, 貴男: you (second-person pronoun) | anata · pron |
| [度](https://en.wiktionary.org/wiki/%E5%BA%A6#Japanese) | time; whenever | tabi · noun |
| [手](https://en.wiktionary.org/wiki/%E6%89%8B#Japanese) | a hand | te · noun |
| [三](https://en.wiktionary.org/wiki/%E4%B8%89#Japanese) | three, 3 | san · num |
| [会](https://en.wiktionary.org/wiki/%E4%BC%9A#Japanese) | meeting, gathering | kai · noun |
| [僕](https://en.wiktionary.org/wiki/%E5%83%95#Japanese) | manservant, servant | boku · noun |
| [力](https://en.wiktionary.org/wiki/%E5%8A%9B#Japanese) | strength; power; force | chikara · noun |
| [国](https://en.wiktionary.org/wiki/%E5%9B%BD#Japanese) | a land, a large place | kuni · noun |
| [今日](https://en.wiktionary.org/wiki/%E4%BB%8A%E6%97%A5#Japanese) | today, this day | konnichi · noun |
| [多い](https://en.wiktionary.org/wiki/%E5%A4%9A%E3%81%84#Japanese) | there are many, there is much, there are numerous, there is an abundance, there amply exists, abounding | ōi · adj |
| [子](https://en.wiktionary.org/wiki/%E5%AD%90#Japanese) | a child | ko · noun |
| [車](https://en.wiktionary.org/wiki/%E8%BB%8A#Japanese) | a car, a carriage, a cart, a vehicle | kuruma · noun |
| [金](https://en.wiktionary.org/wiki/%E9%87%91#Japanese) | gold (Au) | kin · noun |
| [あ](https://en.wiktionary.org/wiki/%E3%81%82#Japanese) | expresses surprise: Ah! Oh! | a · intj |
| [あの](https://en.wiktionary.org/wiki/%E3%81%82%E3%81%AE#Japanese) | similar to English er or umm, said when hesitating in speech | ano · intj |
| [男](https://en.wiktionary.org/wiki/%E7%94%B7#Japanese) | a male person | otoko · noun |
| [間](https://en.wiktionary.org/wiki/%E9%96%93#Japanese) | interval | kan · noun |
| [所](https://en.wiktionary.org/wiki/%E6%89%80#Japanese) | a place, a scene, a site; an address | tokoro · noun |
| [人間](https://en.wiktionary.org/wiki/%E4%BA%BA%E9%96%93#Japanese) | human, person, human being | ningen · noun |
| [名](https://en.wiktionary.org/wiki/%E5%90%8D#Japanese) | name | na · noun |
| [女](https://en.wiktionary.org/wiki/%E5%A5%B3#Japanese) | a female person | onna · noun |
| [いく](https://en.wiktionary.org/wiki/%E3%81%84%E3%81%8F#Japanese) | 生く: to be alive; to come back to life; to be vigorous, to be lively; to make something live, to plant something | iku · verb |
| [様](https://en.wiktionary.org/wiki/%E6%A7%98#Japanese) | way, style, appearance | yō · noun |
| [次](https://en.wiktionary.org/wiki/%E6%AC%A1#Japanese) | next, order, sequence, below | tsugi · noun |
| [行く](https://en.wiktionary.org/wiki/%E8%A1%8C%E3%81%8F#Japanese) | to go; to come to one's place | iku · verb |

</details>

<details><summary>Words 101–150</summary>

![[Resources/Audio/ja/Words 0101-0150.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [見る](https://en.wiktionary.org/wiki/%E8%A6%8B%E3%82%8B#Japanese) | to see, to watch, to observe, to look at something | miru · verb |
| [そこ](https://en.wiktionary.org/wiki/%E3%81%9D%E3%81%93#Japanese) | That place, area, or part near you. (near the addressee) | soko · pron |
| [君](https://en.wiktionary.org/wiki/%E5%90%9B#Japanese) | an emperor | kimi · noun |
| [店](https://en.wiktionary.org/wiki/%E5%BA%97#Japanese) | a commercial building; a store; a shop | mise · noun |
| [新](https://en.wiktionary.org/wiki/%E6%96%B0#Japanese) | a novelty | shin · noun |
| [生](https://en.wiktionary.org/wiki/%E7%94%9F#Japanese) | a raw, uncooked state | nama · noun |
| [ぜ](https://en.wiktionary.org/wiki/%E3%81%9C#Japanese) | sentence-ending particle signifying emphasis, used to lightly press one's point, with familiar overtones | ze · particle |
| [先](https://en.wiktionary.org/wiki/%E5%85%88#Japanese) | before, previous | saki · noun |
| [内](https://en.wiktionary.org/wiki/%E5%86%85#Japanese) | the inside, within (a physical location) | uchi · noun |
| [参加](https://en.wiktionary.org/wiki/%E5%8F%82%E5%8A%A0#Japanese) | participation, commitment | sanka · noun |
| [感](https://en.wiktionary.org/wiki/%E6%84%9F#Japanese) | feeling; sense | kan · noun |
| [物](https://en.wiktionary.org/wiki/%E7%89%A9#Japanese) | thing (concrete, tangible) | mono · noun |
| [顔](https://en.wiktionary.org/wiki/%E9%A1%94#Japanese) | a person's face | kao · noun |
| [お願い](https://en.wiktionary.org/wiki/%E3%81%8A%E9%A1%98%E3%81%84#Japanese) | request, wish, favor | onegai · noun |
| [声](https://en.wiktionary.org/wiki/%E5%A3%B0#Japanese) | a voice | koe · noun |
| [最近](https://en.wiktionary.org/wiki/%E6%9C%80%E8%BF%91#Japanese) | the latest; the most recent | saikin · noun |
| [用](https://en.wiktionary.org/wiki/%E7%94%A8#Japanese) | use | yō · noun |
| [ま](https://en.wiktionary.org/wiki/%E3%81%BE#Japanese) | the space between two (physical) things | ma · noun |
| [十](https://en.wiktionary.org/wiki/%E5%8D%81#Japanese) | ten, 10 | jū · num |
| [頭](https://en.wiktionary.org/wiki/%E9%A0%AD#Japanese) | head (body part) | atama · noun |
| [こ](https://en.wiktionary.org/wiki/%E3%81%93#Japanese) | 此: (derogatory) you | ko · pron |
| [代](https://en.wiktionary.org/wiki/%E4%BB%A3#Japanese) | price | dai · noun |
| [彼](https://en.wiktionary.org/wiki/%E5%BD%BC#Japanese) | distal demonstrative, something far off removed from both speaker and listener: that, yon | ka · pron |
| [心](https://en.wiktionary.org/wiki/%E5%BF%83#Japanese) | mind, heart, spirit, soul; thoughts, ideas | kokoro · noun |
| [高](https://en.wiktionary.org/wiki/%E9%AB%98#Japanese) | maximum, the limit | taka · noun |
| [名前](https://en.wiktionary.org/wiki/%E5%90%8D%E5%89%8D#Japanese) | a name (word or phrase indicating a particular person, place, class, or thing) | namae · noun |
| [神](https://en.wiktionary.org/wiki/%E7%A5%9E#Japanese) | a spirit or an essence present in all things, the main subject of worship of Shinto | kami · noun |
| [等](https://en.wiktionary.org/wiki/%E7%AD%89#Japanese) | et cetera | tō · adv |
| [下](https://en.wiktionary.org/wiki/%E4%B8%8B#Japanese) | the underneath | shita · noun |
| [元](https://en.wiktionary.org/wiki/%E5%85%83#Japanese) | cause, origin | moto · noun |
| [別](https://en.wiktionary.org/wiki/%E5%88%A5#Japanese) | different, separate, another | betsu · adj |
| [部](https://en.wiktionary.org/wiki/%E9%83%A8#Japanese) | division, divide, a part | bu · noun |
| [高い](https://en.wiktionary.org/wiki/%E9%AB%98%E3%81%84#Japanese) | high, tall | takai · adj |
| [町](https://en.wiktionary.org/wiki/%E7%94%BA#Japanese) | a town, a city | machi · noun |
| [言葉](https://en.wiktionary.org/wiki/%E8%A8%80%E8%91%89#Japanese) | a word, a term | kotoba · noun |
| [映画](https://en.wiktionary.org/wiki/%E6%98%A0%E7%94%BB#Japanese) | movie, film | eiga · noun |
| [氏](https://en.wiktionary.org/wiki/%E6%B0%8F#Japanese) | a family, a clan | shi · noun |
| [点](https://en.wiktionary.org/wiki/%E7%82%B9#Japanese) | spot, dot | ten · noun |
| [社会](https://en.wiktionary.org/wiki/%E7%A4%BE%E4%BC%9A#Japanese) | society (group of people sharing culture) | shakai · noun |
| [もん](https://en.wiktionary.org/wiki/%E3%82%82%E3%82%93#Japanese) | 物: thing (alternative form of もの mono) | mon · noun |
| [体](https://en.wiktionary.org/wiki/%E4%BD%93#Japanese) | the body (e.g., of a human or animal) | tai · noun |
| [型](https://en.wiktionary.org/wiki/%E5%9E%8B#Japanese) | a style, a type | kata · noun |
| [駅](https://en.wiktionary.org/wiki/%E9%A7%85#Japanese) | station (train, underground/subway) | eki · noun |
| [曲](https://en.wiktionary.org/wiki/%E6%9B%B2#Japanese) | a piece of music | kyoku · noun |
| [無理](https://en.wiktionary.org/wiki/%E7%84%A1%E7%90%86#Japanese) | cannot, impossible, incapable | muri · adj |
| [現在](https://en.wiktionary.org/wiki/%E7%8F%BE%E5%9C%A8#Japanese) | the present, now | genzai · noun |
| [す](https://en.wiktionary.org/wiki/%E3%81%99#Japanese) | 酢, 醋, 酸: vinegar (condiment) | su · noun |
| [水](https://en.wiktionary.org/wiki/%E6%B0%B4#Japanese) | water (sometimes cold and/or fresh) | mizu · noun |
| [番](https://en.wiktionary.org/wiki/%E7%95%AA#Japanese) | one's turn (as in a game, etc.) | ban · noun |
| [得](https://en.wiktionary.org/wiki/%E5%BE%97#Japanese) | beneficial; with gain | toku · adj |

</details>

<details><summary>Words 151–200</summary>

![[Resources/Audio/ja/Words 0151-0200.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [約](https://en.wiktionary.org/wiki/%E7%B4%84#Japanese) | about, approximately | yaku · adv |
| [中国](https://en.wiktionary.org/wiki/%E4%B8%AD%E5%9B%BD#Japanese) | the central part of a country, historically, commonly known as the capital city or the main region, where an emperor or other ruler resides | chūgoku · noun |
| [側](https://en.wiktionary.org/wiki/%E5%81%B4#Japanese) | side | gawa · noun |
| [夜](https://en.wiktionary.org/wiki/%E5%A4%9C#Japanese) | the night, evening | yoru · noun |
| [外](https://en.wiktionary.org/wiki/%E5%A4%96#Japanese) | outside | soto · noun |
| [枚](https://en.wiktionary.org/wiki/%E6%9E%9A#Japanese) | thin and flat object | hira · noun |
| [機](https://en.wiktionary.org/wiki/%E6%A9%9F#Japanese) | a machine, a device; a contraption | ki · noun |
| [法](https://en.wiktionary.org/wiki/%E6%B3%95#Japanese) | principle | hō · noun |
| [○](https://en.wiktionary.org/wiki/%E2%97%8B#Japanese) | circle | maru · noun |
| [ずっと](https://en.wiktionary.org/wiki/%E3%81%9A%E3%81%A3%E3%81%A8#Japanese) | by far; much (better, etc.) | zutto · adv |
| [場](https://en.wiktionary.org/wiki/%E5%A0%B4#Japanese) | a place | ba · noun |
| [生活](https://en.wiktionary.org/wiki/%E7%94%9F%E6%B4%BB#Japanese) | life; livelihood; daily living. | seikatsu · noun |
| [色](https://en.wiktionary.org/wiki/%E8%89%B2#Japanese) | color | iro · noun |
| [CM](https://en.wiktionary.org/wiki/CM#Japanese) | a commercial; television ad | shīemu · noun |
| [かなり](https://en.wiktionary.org/wiki/%E3%81%8B%E3%81%AA%E3%82%8A#Japanese) | quite; rather; considerably; fairly | kanari · adv |
| [初](https://en.wiktionary.org/wiki/%E5%88%9D#Japanese) | a first, start, a beginning | hatsu · noun |
| [区](https://en.wiktionary.org/wiki/%E5%8C%BA#Japanese) | ward, section, district | ku · noun |
| [新しい](https://en.wiktionary.org/wiki/%E6%96%B0%E3%81%97%E3%81%84#Japanese) | new, novel | atarashii · adj |
| [こう](https://en.wiktionary.org/wiki/%E3%81%93%E3%81%86#Japanese) | like this, in this way, so, thus | kō · adv |
| [娘](https://en.wiktionary.org/wiki/%E5%A8%98#Japanese) | daughter | musume · noun |
| [音](https://en.wiktionary.org/wiki/%E9%9F%B3#Japanese) | sound | on · noun |
| [全](https://en.wiktionary.org/wiki/%E5%85%A8#Japanese) | entire, complete, overall | zen · noun |
| [夢](https://en.wiktionary.org/wiki/%E5%A4%A2#Japanese) | a dream | yume · noun |
| [く](https://en.wiktionary.org/wiki/%E3%81%8F#Japanese) | 消: disappear | ku · verb |
| [式](https://en.wiktionary.org/wiki/%E5%BC%8F#Japanese) | type, style | shiki · noun |
| [発表](https://en.wiktionary.org/wiki/%E7%99%BA%E8%A1%A8#Japanese) | announcement; publication; presentation | happyō · noun |
| [道](https://en.wiktionary.org/wiki/%E9%81%93#Japanese) | Tao (the way of nature), Taoism | dō · noun |
| [風](https://en.wiktionary.org/wiki/%E9%A2%A8#Japanese) | wind (movement of air) | kaze · noun |
| [件](https://en.wiktionary.org/wiki/%E4%BB%B6#Japanese) | case | ken · noun |
| [無](https://en.wiktionary.org/wiki/%E7%84%A1#Japanese) | nothing, nothingness | mu · noun |
| [電話](https://en.wiktionary.org/wiki/%E9%9B%BB%E8%A9%B1#Japanese) | telephone | denwa · noun |
| [口](https://en.wiktionary.org/wiki/%E5%8F%A3#Japanese) | the mouth | ku · noun |
| [愛](https://en.wiktionary.org/wiki/%E6%84%9B#Japanese) | love | ai · noun |
| [明日](https://en.wiktionary.org/wiki/%E6%98%8E%E6%97%A5#Japanese) | tomorrow | ashita · noun |
| [紹介](https://en.wiktionary.org/wiki/%E7%B4%B9%E4%BB%8B#Japanese) | introduction (causing someone to be acquainted) | shōkai · noun |
| [花](https://en.wiktionary.org/wiki/%E8%8A%B1#Japanese) | a flower | hana · noun |
| [号](https://en.wiktionary.org/wiki/%E5%8F%B7#Japanese) | number | gō · noun |
| [る](https://en.wiktionary.org/wiki/%E3%82%8B#Japanese) | the present progressive: to be doing | -ru · verb |
| [人生](https://en.wiktionary.org/wiki/%E4%BA%BA%E7%94%9F#Japanese) | life | jinsei · noun |
| [員](https://en.wiktionary.org/wiki/%E5%93%A1#Japanese) | member | in · noun |
| [屋](https://en.wiktionary.org/wiki/%E5%B1%8B#Japanese) | house | ya · noun |
| [形](https://en.wiktionary.org/wiki/%E5%BD%A2#Japanese) | a shape | kata · noun |
| [昔](https://en.wiktionary.org/wiki/%E6%98%94#Japanese) | once (in the indeterminate past) | mukashi · adv |
| [朝](https://en.wiktionary.org/wiki/%E6%9C%9D#Japanese) | the morning | asa · noun |
| [来る](https://en.wiktionary.org/wiki/%E6%9D%A5%E3%82%8B#Japanese) | to come (toward the speaker) | kuru · verb |
| [自由](https://en.wiktionary.org/wiki/%E8%87%AA%E7%94%B1#Japanese) | free (as in freedom) | jiyū · adj |
| [際](https://en.wiktionary.org/wiki/%E9%9A%9B#Japanese) | time; occasion | sai · noun |
| [地](https://en.wiktionary.org/wiki/%E5%9C%B0#Japanese) | earth, dirt | ji · noun |
| [部屋](https://en.wiktionary.org/wiki/%E9%83%A8%E5%B1%8B#Japanese) | room (of a house or hotel), chamber, apartment, flat | heya · noun |
| [夏](https://en.wiktionary.org/wiki/%E5%A4%8F#Japanese) | summer (season) | natsu · noun |

</details>

<details><summary>Words 201–250</summary>

![[Resources/Audio/ja/Words 0201-0250.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [姿](https://en.wiktionary.org/wiki/%E5%A7%BF#Japanese) | figure, appearance, form, aspect, shape | sugata · noun |
| [英語](https://en.wiktionary.org/wiki/%E8%8B%B1%E8%AA%9E#Japanese) | the English language | Eigo · noun |
| [しろ](https://en.wiktionary.org/wiki/%E3%81%97%E3%82%8D#Japanese) | no matter; regardless of | shiro · verb |
| [め](https://en.wiktionary.org/wiki/%E3%82%81#Japanese) | 芽: bud, sprout, shoot | me · noun |
| [室](https://en.wiktionary.org/wiki/%E5%AE%A4#Japanese) | cellar, storage chamber | muro · noun |
| [強い](https://en.wiktionary.org/wiki/%E5%BC%B7%E3%81%84#Japanese) | strong, durable, powerful | tsuyoi · adj |
| [長](https://en.wiktionary.org/wiki/%E9%95%B7#Japanese) | chief, head, leader | chō · noun |
| [似](https://en.wiktionary.org/wiki/%E4%BC%BC#Japanese) | 肖: imperfective and stem (or continuative) forms of 似る (niru) | ni · verb |
| [安全](https://en.wiktionary.org/wiki/%E5%AE%89%E5%85%A8#Japanese) | safe; secure | anzen · adj |
| [戦](https://en.wiktionary.org/wiki/%E6%88%A6#Japanese) | a battle, conflict, fight, war | sen · noun |
| [為](https://en.wiktionary.org/wiki/%E7%82%BA#Japanese) | the twelfth string on a 箏 (koto, “Japanese zither”) | i · noun |
| [王](https://en.wiktionary.org/wiki/%E7%8E%8B#Japanese) | an East Asian queen regnant | ō · noun |
| [足](https://en.wiktionary.org/wiki/%E8%B6%B3#Japanese) | foot | ashi · noun |
| [軍](https://en.wiktionary.org/wiki/%E8%BB%8D#Japanese) | an army, corps | gun · noun |
| [of](https://en.wiktionary.org/wiki/of#Japanese) | Used to express that one is an exemplar. | obu · particle |
| [はい](https://en.wiktionary.org/wiki/%E3%81%AF%E3%81%84#Japanese) | yes; okay; understood, got it; here, present; right, so (agreement); uh-huh (acknowledgement that one is listening) | hai · intj |
| [音楽](https://en.wiktionary.org/wiki/%E9%9F%B3%E6%A5%BD#Japanese) | music | ongaku · noun |
| [け](https://en.wiktionary.org/wiki/%E3%81%91#Japanese) | (question particle) | ke · particle |
| [寝](https://en.wiktionary.org/wiki/%E5%AF%9D#Japanese) | sleep, sleeping | ne · noun |
| [書](https://en.wiktionary.org/wiki/%E6%9B%B8#Japanese) | document | sho · noun |
| [着](https://en.wiktionary.org/wiki/%E7%9D%80#Japanese) | arrival at a location | chaku · noun |
| [期](https://en.wiktionary.org/wiki/%E6%9C%9F#Japanese) | a specific time or date | go · noun |
| [米](https://en.wiktionary.org/wiki/%E7%B1%B3#Japanese) | rice (husked grains of the Asian rice plant, Oryza sativa), one of the five grains | kome · noun |
| [線](https://en.wiktionary.org/wiki/%E7%B7%9A#Japanese) | line | sen · noun |
| [台](https://en.wiktionary.org/wiki/%E5%8F%B0#Japanese) | a four-cornered earthen terrace from which one might view their surroundings | utena · noun |
| [犬](https://en.wiktionary.org/wiki/%E7%8A%AC#Japanese) | dog, canine | inu · noun |
| [光](https://en.wiktionary.org/wiki/%E5%85%89#Japanese) | a light, beam, illumination | hikari · noun |
| [母](https://en.wiktionary.org/wiki/%E6%AF%8D#Japanese) | mother | haha · noun |
| [海](https://en.wiktionary.org/wiki/%E6%B5%B7#Japanese) | a sea, an ocean | umi · noun |
| [主](https://en.wiktionary.org/wiki/%E4%B8%BB#Japanese) | main | shu · noun |
| [千](https://en.wiktionary.org/wiki/%E5%8D%83#Japanese) | a thousand, 1000 | sen · num |
| [経済](https://en.wiktionary.org/wiki/%E7%B5%8C%E6%B8%88#Japanese) | economics; the study of economics | keizai · noun |
| [専門](https://en.wiktionary.org/wiki/%E5%B0%82%E9%96%80#Japanese) | speciality/specialty; subject of study; subject of expertise; area of interest; profession | senmon · noun |
| [映像](https://en.wiktionary.org/wiki/%E6%98%A0%E5%83%8F#Japanese) | image; video (visual media, either still or moving) | eizō · noun |
| [死ぬ](https://en.wiktionary.org/wiki/%E6%AD%BB%E3%81%AC#Japanese) | to die | shinu · verb |
| [父](https://en.wiktionary.org/wiki/%E7%88%B6#Japanese) | father | chichi · noun |
| [じ](https://en.wiktionary.org/wiki/%E3%81%98#Japanese) | 柱: pillar; prism, cylinder | ji · noun |
| [品](https://en.wiktionary.org/wiki/%E5%93%81#Japanese) | article, goods | shina · noun |
| [嘘](https://en.wiktionary.org/wiki/%E5%98%98#Japanese) | a lie; a falsehood; a fallacy | uso · noun |
| [色々](https://en.wiktionary.org/wiki/%E8%89%B2%E3%80%85#Japanese) | various | iroiro · adj |
| [逆](https://en.wiktionary.org/wiki/%E9%80%86#Japanese) | reverse; contrary; opposite | gyaku · adj |
| [量](https://en.wiktionary.org/wiki/%E9%87%8F#Japanese) | volume, amount | ryō · noun |
| [今年](https://en.wiktionary.org/wiki/%E4%BB%8A%E5%B9%B4#Japanese) | this year, the present year | kotoshi · noun |
| [敵](https://en.wiktionary.org/wiki/%E6%95%B5#Japanese) | an enemy | teki · noun |
| [昨日](https://en.wiktionary.org/wiki/%E6%98%A8%E6%97%A5#Japanese) | yesterday | kinō · noun |
| [猫](https://en.wiktionary.org/wiki/%E7%8C%AB#Japanese) | a cat | neko · noun |
| [組](https://en.wiktionary.org/wiki/%E7%B5%84#Japanese) | class, group, team, set | kumi · noun |
| [絵](https://en.wiktionary.org/wiki/%E7%B5%B5#Japanese) | picture, painting | e · noun |
| [酒](https://en.wiktionary.org/wiki/%E9%85%92#Japanese) | any alcoholic beverage | sake · noun |
| [元気](https://en.wiktionary.org/wiki/%E5%85%83%E6%B0%97#Japanese) | healthy | genki · adj |

</details>

<details><summary>Words 251–300</summary>

![[Resources/Audio/ja/Words 0251-0300.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [小](https://en.wiktionary.org/wiki/%E5%B0%8F#Japanese) | smallness; small size, small (sometimes used as an abbreviation for small serving, etc.) | shō · noun |
| [白](https://en.wiktionary.org/wiki/%E7%99%BD#Japanese) | the color white | shiro · noun |
| [百](https://en.wiktionary.org/wiki/%E7%99%BE#Japanese) | hundred | hyaku · noun |
| [語](https://en.wiktionary.org/wiki/%E8%AA%9E#Japanese) | a word, term | go · noun |
| [面](https://en.wiktionary.org/wiki/%E9%9D%A2#Japanese) | face | men · noun |
| [億](https://en.wiktionary.org/wiki/%E5%84%84#Japanese) | a hundred million, 10⁸ | oku · noun |
| [星](https://en.wiktionary.org/wiki/%E6%98%9F#Japanese) | a star (luminous celestial body) | hoshi · noun |
| [服](https://en.wiktionary.org/wiki/%E6%9C%8D#Japanese) | clothes | fuku · noun |
| [かい](https://en.wiktionary.org/wiki/%E3%81%8B%E3%81%84#Japanese) | Marks a non-rhetorical question. | kai · particle |
| [くん](https://en.wiktionary.org/wiki/%E3%81%8F%E3%82%93#Japanese) | Representing a sniffing sound. | kun · intj |
| [変](https://en.wiktionary.org/wiki/%E5%A4%89#Japanese) | strange | hen · adj |
| [妻](https://en.wiktionary.org/wiki/%E5%A6%BB#Japanese) | a wife (married woman) | tsuma · noun |
| [楽しい](https://en.wiktionary.org/wiki/%E6%A5%BD%E3%81%97%E3%81%84#Japanese) | pleasant, delightful, fun, enjoyable | tanoshii · adj |
| [秒](https://en.wiktionary.org/wiki/%E7%A7%92#Japanese) | second (one-sixtieth of a minute; SI unit of time) | byō · noun |
| [笑](https://en.wiktionary.org/wiki/%E7%AC%91#Japanese) | a laugh, laughing, laughter | warai · noun |
| [観](https://en.wiktionary.org/wiki/%E8%A6%B3#Japanese) | look, appearance | kan · noun |
| [訳](https://en.wiktionary.org/wiki/%E8%A8%B3#Japanese) | translation | yaku · noun |
| [倍](https://en.wiktionary.org/wiki/%E5%80%8D#Japanese) | twice, double, two times | bai · noun |
| [官](https://en.wiktionary.org/wiki/%E5%AE%98#Japanese) | government office; authority | kan · noun |
| [木](https://en.wiktionary.org/wiki/%E6%9C%A8#Japanese) | a tree or shrub | ki · noun |
| [黒](https://en.wiktionary.org/wiki/%E9%BB%92#Japanese) | 黒, 緇: black (color) | kuro · noun |
| [味](https://en.wiktionary.org/wiki/%E5%91%B3#Japanese) | clever, smart, witty | aji · adj |
| [山](https://en.wiktionary.org/wiki/%E5%B1%B1#Japanese) | a mountain (large mass of earth and rock) or (large) hill | yama · noun |
| [割](https://en.wiktionary.org/wiki/%E5%89%B2#Japanese) | proportion | wari · noun |
| [安心](https://en.wiktionary.org/wiki/%E5%AE%89%E5%BF%83#Japanese) | unworrying, safe | anshin · adj |
| [歌](https://en.wiktionary.org/wiki/%E6%AD%8C#Japanese) | a song | uta · noun |
| [死](https://en.wiktionary.org/wiki/%E6%AD%BB#Japanese) | death | shi · noun |
| [薬](https://en.wiktionary.org/wiki/%E8%96%AC#Japanese) | a medicine or drug, a pharmaceutical | kusuri · noun |
| [例](https://en.wiktionary.org/wiki/%E4%BE%8B#Japanese) | a custom, usual practice, habit | rei · noun |
| [右](https://en.wiktionary.org/wiki/%E5%8F%B3#Japanese) | right (direction) | migi · noun |
| [巻](https://en.wiktionary.org/wiki/%E5%B7%BB#Japanese) | scroll | kan · noun |
| [師](https://en.wiktionary.org/wiki/%E5%B8%AB#Japanese) | a teacher, mentor, or religious master (esp. in Buddhist contexts) | shi · noun |
| [春](https://en.wiktionary.org/wiki/%E6%98%A5#Japanese) | the spring (season) | haru · noun |
| [身](https://en.wiktionary.org/wiki/%E8%BA%AB#Japanese) | a body | mi · noun |
| [OK](https://en.wiktionary.org/wiki/OK#Japanese) | agreement; approval; okay | ōkē · noun |
| [PC](https://en.wiktionary.org/wiki/PC#Japanese) | PC; personal computer | pīshī · noun |
| [ページ](https://en.wiktionary.org/wiki/%E3%83%9A%E3%83%BC%E3%82%B8#Japanese) | page (of a book, newspaper, etc.) | pēji · noun |
| [大切](https://en.wiktionary.org/wiki/%E5%A4%A7%E5%88%87#Japanese) | important, weighty | taisetsu · adj |
| [居](https://en.wiktionary.org/wiki/%E5%B1%85#Japanese) | residence | kyo · noun |
| [種](https://en.wiktionary.org/wiki/%E7%A8%AE#Japanese) | a seed | tane · noun |
| [美](https://en.wiktionary.org/wiki/%E7%BE%8E#Japanese) | beautiful | bi · adj |
| [親](https://en.wiktionary.org/wiki/%E8%A6%AA#Japanese) | a parent | oya · noun |
| [位置](https://en.wiktionary.org/wiki/%E4%BD%8D%E7%BD%AE#Japanese) | location, position | ichi · noun |
| [作](https://en.wiktionary.org/wiki/%E4%BD%9C#Japanese) | a work, a production (particularly a cultural work, such as a work of art, of literature, or of theatre) | saku · noun |
| [島](https://en.wiktionary.org/wiki/%E5%B3%B6#Japanese) | an island (land surrounded by water) | shima · noun |
| [日本語](https://en.wiktionary.org/wiki/%E6%97%A5%E6%9C%AC%E8%AA%9E#Japanese) | the Japanese language | nihongo · noun |
| [空](https://en.wiktionary.org/wiki/%E7%A9%BA#Japanese) | the sky | sora · noun |
| [裏](https://en.wiktionary.org/wiki/%E8%A3%8F#Japanese) | backside, back, behind, other side | ura · noun |
| [長い](https://en.wiktionary.org/wiki/%E9%95%B7%E3%81%84#Japanese) | long | nagai · adj |
| [重](https://en.wiktionary.org/wiki/%E9%87%8D#Japanese) | a division | he · noun |

</details>

<details><summary>Words 301–350</summary>

![[Resources/Audio/ja/Words 0301-0350.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [階](https://en.wiktionary.org/wiki/%E9%9A%8E#Japanese) | stairs from a garden up to the house | hashi · noun |
| [馬](https://en.wiktionary.org/wiki/%E9%A6%AC#Japanese) | a horse | uma · noun |
| [人々](https://en.wiktionary.org/wiki/%E4%BA%BA%E3%80%85#Japanese) | people, each person, everybody | hitobito · noun |
| [四](https://en.wiktionary.org/wiki/%E5%9B%9B#Japanese) | four, 4 | yo · num |
| [村](https://en.wiktionary.org/wiki/%E6%9D%91#Japanese) | village (a rural habitation of size between a hamlet and a town) | mura · noun |
| [真](https://en.wiktionary.org/wiki/%E7%9C%9F#Japanese) | truth, reality | shin · noun |
| [肉](https://en.wiktionary.org/wiki/%E8%82%89#Japanese) | meat, the muscle and fat tissue of an animal used as food | niku · noun |
| [学](https://en.wiktionary.org/wiki/%E5%AD%A6#Japanese) | scholarship; learning; knowledge | gaku · noun |
| [差](https://en.wiktionary.org/wiki/%E5%B7%AE#Japanese) | difference | sa · noun |
| [弾](https://en.wiktionary.org/wiki/%E5%BC%BE#Japanese) | goal | dan · noun |
| [明らか](https://en.wiktionary.org/wiki/%E6%98%8E%E3%82%89%E3%81%8B#Japanese) | clear, obvious, distinct | akiraka · adj |
| [楽](https://en.wiktionary.org/wiki/%E6%A5%BD#Japanese) | comfortable, enjoying | raku · adj |
| [火](https://en.wiktionary.org/wiki/%E7%81%AB#Japanese) | a flame | hi · noun |
| [監督](https://en.wiktionary.org/wiki/%E7%9B%A3%E7%9D%A3#Japanese) | director, supervisor, manager, superintendent | kantoku · noun |
| [良](https://en.wiktionary.org/wiki/%E8%89%AF#Japanese) | good, B | ryō · noun |
| [食べる](https://en.wiktionary.org/wiki/%E9%A3%9F%E3%81%B9%E3%82%8B#Japanese) | to eat | taberu · verb |
| [値](https://en.wiktionary.org/wiki/%E5%80%A4#Japanese) | value, worth | atai · noun |
| [役](https://en.wiktionary.org/wiki/%E5%BD%B9#Japanese) | role, service, use | yaku · noun |
| [聞く](https://en.wiktionary.org/wiki/%E8%81%9E%E3%81%8F#Japanese) | 聞く, 聴く: to hear, to listen (to) | kiku · verb |
| [脳](https://en.wiktionary.org/wiki/%E8%84%B3#Japanese) | the brain | nō · noun |
| [艦](https://en.wiktionary.org/wiki/%E8%89%A6#Japanese) | warship | kan · noun |
| [非](https://en.wiktionary.org/wiki/%E9%9D%9E#Japanese) | evil, wrong, wrongdoing | hi · noun |
| [士](https://en.wiktionary.org/wiki/%E5%A3%AB#Japanese) | man, especially one who is esteemed or learned; gentleman | shi · noun |
| [少年](https://en.wiktionary.org/wiki/%E5%B0%91%E5%B9%B4#Japanese) | a boy, a young man | shōnen · noun |
| [森](https://en.wiktionary.org/wiki/%E6%A3%AE#Japanese) | a forest (dense collection of trees) | mori · noun |
| [石](https://en.wiktionary.org/wiki/%E7%9F%B3#Japanese) | a stone | ishi · noun |
| [北](https://en.wiktionary.org/wiki/%E5%8C%97#Japanese) | north (cardinal point) | kita · noun |
| [半](https://en.wiktionary.org/wiki/%E5%8D%8A#Japanese) | odd | han · noun |
| [器](https://en.wiktionary.org/wiki/%E5%99%A8#Japanese) | container, vessel | utsuwa · noun |
| [左](https://en.wiktionary.org/wiki/%E5%B7%A6#Japanese) | left, the side of the left hand | hidari · noun |
| [当然](https://en.wiktionary.org/wiki/%E5%BD%93%E7%84%B6#Japanese) | natural, inevitable | tōzen · adj |
| [恋](https://en.wiktionary.org/wiki/%E6%81%8B#Japanese) | love, especially romantic love | koi · noun |
| [旅](https://en.wiktionary.org/wiki/%E6%97%85#Japanese) | a journey; travel | tabi · noun |
| [雨](https://en.wiktionary.org/wiki/%E9%9B%A8#Japanese) | rain, rainfall | ame · noun |
| [DVD](https://en.wiktionary.org/wiki/DVD#Japanese) | DVD (optical disc) | dībuidī · noun |
| [by](https://en.wiktionary.org/wiki/by#Japanese) | Used to sign off a message/attribute a text. | bai · particle |
| [客](https://en.wiktionary.org/wiki/%E5%AE%A2#Japanese) | guest; visitor | kyaku · noun |
| [発](https://en.wiktionary.org/wiki/%E7%99%BA#Japanese) | departure | hatsu · noun |
| [箱](https://en.wiktionary.org/wiki/%E7%AE%B1#Japanese) | a box: a container with a lid | hako · noun |
| [若い](https://en.wiktionary.org/wiki/%E8%8B%A5%E3%81%84#Japanese) | young, juvenile | wakai · adj |
| [製](https://en.wiktionary.org/wiki/%E8%A3%BD#Japanese) | make | sei · noun |
| [赤](https://en.wiktionary.org/wiki/%E8%B5%A4#Japanese) | red (color) | aka · noun |
| [郡](https://en.wiktionary.org/wiki/%E9%83%A1#Japanese) | county, district | gun · noun |
| [髪](https://en.wiktionary.org/wiki/%E9%AB%AA#Japanese) | hair on the head | kami · noun |
| [ど](https://en.wiktionary.org/wiki/%E3%81%A9#Japanese) | used for emphasis | do · particle |
| [パン](https://en.wiktionary.org/wiki/%E3%83%91%E3%83%B3#Japanese) | bread, pastries, any baked good with a crust (a type of food) | pan · noun |
| [南](https://en.wiktionary.org/wiki/%E5%8D%97#Japanese) | the south (cardinal point) | minami · noun |
| [命](https://en.wiktionary.org/wiki/%E5%91%BD#Japanese) | life | inochi · noun |
| [夫](https://en.wiktionary.org/wiki/%E5%A4%AB#Japanese) | husband | otto · noun |
| [賞](https://en.wiktionary.org/wiki/%E8%B3%9E#Japanese) | prize | -shō · noun |

</details>

<details><summary>Words 351–400</summary>

![[Resources/Audio/ja/Words 0351-0400.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [都](https://en.wiktionary.org/wiki/%E9%83%BD#Japanese) | a capital city | miyako · noun |
| [五](https://en.wiktionary.org/wiki/%E4%BA%94#Japanese) | five | itsu · noun |
| [壁](https://en.wiktionary.org/wiki/%E5%A3%81#Japanese) | wall | kabe · noun |
| [大きい](https://en.wiktionary.org/wiki/%E5%A4%A7%E3%81%8D%E3%81%84#Japanese) | big | ōkii · adj |
| [妹](https://en.wiktionary.org/wiki/%E5%A6%B9#Japanese) | one's own younger sister | imōto · noun |
| [席](https://en.wiktionary.org/wiki/%E5%B8%AD#Japanese) | seat | seki · noun |
| [耳](https://en.wiktionary.org/wiki/%E8%80%B3#Japanese) | ear; ears | mimi · noun |
| [枠](https://en.wiktionary.org/wiki/%E6%9E%A0#Japanese) | frame (such as a picture frame) | waku · noun |
| [法律](https://en.wiktionary.org/wiki/%E6%B3%95%E5%BE%8B#Japanese) | The field, profession, and study of law. The rule of law. | hōritsu · noun |
| [級](https://en.wiktionary.org/wiki/%E7%B4%9A#Japanese) | rank | kyū · noun |
| [局](https://en.wiktionary.org/wiki/%E5%B1%80#Japanese) | a temporary room created by subdividing a larger room with curtains and screens | tsubone · noun |
| [州](https://en.wiktionary.org/wiki/%E5%B7%9E#Japanese) | first-level administrative division of some countries, such as: (1) state of the United States, Australia, India, Nigeria and Germany; (2) province of Canada; (3) canton of Switzerland; etc. | shū · noun |
| [隊](https://en.wiktionary.org/wiki/%E9%9A%8A#Japanese) | squad; company (group of soldiers) | tai · noun |
| [丸](https://en.wiktionary.org/wiki/%E4%B8%B8#Japanese) | 丸, 円: a circle | maru · noun |
| [土](https://en.wiktionary.org/wiki/%E5%9C%9F#Japanese) | earth, soil, mud | tsuchi · noun |
| [秋](https://en.wiktionary.org/wiki/%E7%A7%8B#Japanese) | autumn, fall (season) | aki · noun |
| [胸](https://en.wiktionary.org/wiki/%E8%83%B8#Japanese) | chest, breast | muna · noun |
| [論](https://en.wiktionary.org/wiki/%E8%AB%96#Japanese) | argument, discussion, disputation | ron · noun |
| [科](https://en.wiktionary.org/wiki/%E7%A7%91#Japanese) | department, section | ka · noun |
| [紙](https://en.wiktionary.org/wiki/%E7%B4%99#Japanese) | paper | kami · noun |
| [食](https://en.wiktionary.org/wiki/%E9%A3%9F#Japanese) | food | uka · noun |
| [制](https://en.wiktionary.org/wiki/%E5%88%B6#Japanese) | system, organization | sei · noun |
| [弟](https://en.wiktionary.org/wiki/%E5%BC%9F#Japanese) | one’s own younger brother | otōto · noun |
| [横](https://en.wiktionary.org/wiki/%E6%A8%AA#Japanese) | side | yoko · noun |
| [罪](https://en.wiktionary.org/wiki/%E7%BD%AA#Japanese) | guilt | tsumi · noun |
| [合](https://en.wiktionary.org/wiki/%E5%90%88#Japanese) | 0.18039 liters, equaling ten shaku or a tenth of a shō | gō · noun |
| [天](https://en.wiktionary.org/wiki/%E5%A4%A9#Japanese) | where the smoke collects in an old kitchen using a wood-burning stove | ama · noun |
| [川](https://en.wiktionary.org/wiki/%E5%B7%9D#Japanese) | river, stream, brook | kawa · noun |
| [集](https://en.wiktionary.org/wiki/%E9%9B%86#Japanese) | collection, assembly | shū · noun |
| [首](https://en.wiktionary.org/wiki/%E9%A6%96#Japanese) | neck (part of the body connecting head and torso) | kubi · noun |
| [メイン](https://en.wiktionary.org/wiki/%E3%83%A1%E3%82%A4%E3%83%B3#Japanese) | the state of being the main thing | mein · noun |
| [兄](https://en.wiktionary.org/wiki/%E5%85%84#Japanese) | elder brother | ani · noun |
| [八](https://en.wiktionary.org/wiki/%E5%85%AB#Japanese) | eight, 8 | hachi · num |
| [冬](https://en.wiktionary.org/wiki/%E5%86%AC#Japanese) | winter (season) | fuyu · noun |
| [条](https://en.wiktionary.org/wiki/%E6%9D%A1#Japanese) | paragraph | kudari · noun |
| [穴](https://en.wiktionary.org/wiki/%E7%A9%B4#Japanese) | hole | ana · noun |
| [旧](https://en.wiktionary.org/wiki/%E6%97%A7#Japanese) | old things, original state, former state, old times | kyū · noun |
| [表](https://en.wiktionary.org/wiki/%E8%A1%A8#Japanese) | surface; face (visible side of an object) | omote · noun |
| [西](https://en.wiktionary.org/wiki/%E8%A5%BF#Japanese) | west (one of the four cardinal directions) | nishi · noun |
| [青](https://en.wiktionary.org/wiki/%E9%9D%92#Japanese) | one of three primary colors | ao · noun |
| [ID](https://en.wiktionary.org/wiki/ID#Japanese) | identification | aidī · noun |
| [そ](https://en.wiktionary.org/wiki/%E3%81%9D#Japanese) | 粗 | so · adj |
| [城](https://en.wiktionary.org/wiki/%E5%9F%8E#Japanese) | castle | shiro · noun |
| [層](https://en.wiktionary.org/wiki/%E5%B1%A4#Japanese) | layer | sō · noun |
| [東](https://en.wiktionary.org/wiki/%E6%9D%B1#Japanese) | the east (compass point) | higashi · noun |
| [桜](https://en.wiktionary.org/wiki/%E6%A1%9C#Japanese) | a cherry tree, in Japanese contexts particularly the Japanese cherry, Prunus serrulata, yet not limited to it | sakura · noun |
| [編](https://en.wiktionary.org/wiki/%E7%B7%A8#Japanese) | compilation | hen · noun |
| [ボール](https://en.wiktionary.org/wiki/%E3%83%9C%E3%83%BC%E3%83%AB#Japanese) | ball (sphere) | bōru · noun |
| [剣](https://en.wiktionary.org/wiki/%E5%89%A3#Japanese) | a sword, especially one with a double-edged blade | ken · noun |
| [太](https://en.wiktionary.org/wiki/%E5%A4%AA#Japanese) | fatness | futo · noun |

</details>

<details><summary>Words 401–450</summary>

![[Resources/Audio/ja/Words 0401-0450.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [強](https://en.wiktionary.org/wiki/%E5%BC%B7#Japanese) | strength | kyō · noun |
| [指](https://en.wiktionary.org/wiki/%E6%8C%87#Japanese) | a finger or toe; digit | yubi · noun |
| [文](https://en.wiktionary.org/wiki/%E6%96%87#Japanese) | the mon, an old currency | mon · noun |
| [雪](https://en.wiktionary.org/wiki/%E9%9B%AA#Japanese) | snow | yuki · noun |
| [中央](https://en.wiktionary.org/wiki/%E4%B8%AD%E5%A4%AE#Japanese) | center/centre, middle | chūō · noun |
| [字](https://en.wiktionary.org/wiki/%E5%AD%97#Japanese) | letter, character | ji · noun |
| [対](https://en.wiktionary.org/wiki/%E5%AF%BE#Japanese) | versus | tai · conj |
| [御](https://en.wiktionary.org/wiki/%E5%BE%A1#Japanese) | equestrianism, horseriding | gyo · noun |
| [急](https://en.wiktionary.org/wiki/%E6%80%A5#Japanese) | sudden, without warning | kyū · adj |
| [悪](https://en.wiktionary.org/wiki/%E6%82%AA#Japanese) | evil, wickedness | aku · noun |
| [闇](https://en.wiktionary.org/wiki/%E9%97%87#Japanese) | the dark, darkness | yami · noun |
| [魂](https://en.wiktionary.org/wiki/%E9%AD%82#Japanese) | a soul, spirit | tamashī · noun |
| [交通](https://en.wiktionary.org/wiki/%E4%BA%A4%E9%80%9A#Japanese) | transportation | kōtsū · noun |
| [姫](https://en.wiktionary.org/wiki/%E5%A7%AB#Japanese) | a noblewoman | hime · noun |
| [界](https://en.wiktionary.org/wiki/%E7%95%8C#Japanese) | boundary | kai · noun |
| [痛い](https://en.wiktionary.org/wiki/%E7%97%9B%E3%81%84#Japanese) | painful | itai · adj |
| [類](https://en.wiktionary.org/wiki/%E9%A1%9E#Japanese) | kind, sort, type, the like | rui · noun |
| [館](https://en.wiktionary.org/wiki/%E9%A4%A8#Japanese) | a roofed structure on a boat, shaped like a house | yakata · noun |
| [ひ](https://en.wiktionary.org/wiki/%E3%81%B2#Japanese) | A shriek, as when recoiling in fear or disgust. | hi · intj |
| [尻](https://en.wiktionary.org/wiki/%E5%B0%BB#Japanese) | behind; the end | shiri · noun |
| [獣](https://en.wiktionary.org/wiki/%E7%8D%A3#Japanese) | an animal covered in fur, a beast | kedamono · noun |
| [葉](https://en.wiktionary.org/wiki/%E8%91%89#Japanese) | leaf, needle, blade (of a plant) | ha · noun |
| [血](https://en.wiktionary.org/wiki/%E8%A1%80#Japanese) | blood | chi · noun |
| [週](https://en.wiktionary.org/wiki/%E9%80%B1#Japanese) | a week (unit of time) | shū · noun |
| [web](https://en.wiktionary.org/wiki/web#Japanese) | the Internet | web · noun |
| [ゼロ](https://en.wiktionary.org/wiki/%E3%82%BC%E3%83%AD#Japanese) | zero (number) | zero · num |
| [姉](https://en.wiktionary.org/wiki/%E5%A7%89#Japanese) | elder sister | ane · noun |
| [帯](https://en.wiktionary.org/wiki/%E5%B8%AF#Japanese) | obi (kimono sash) | obi · noun |
| [教授](https://en.wiktionary.org/wiki/%E6%95%99%E6%8E%88#Japanese) | professor | kyōju · noun |
| [園](https://en.wiktionary.org/wiki/%E5%9C%92#Japanese) | an orchard, plantation | sono · noun |
| [腕](https://en.wiktionary.org/wiki/%E8%85%95#Japanese) | arm | ude · noun |
| [魚](https://en.wiktionary.org/wiki/%E9%AD%9A#Japanese) | fish | uo · noun |
| [人類](https://en.wiktionary.org/wiki/%E4%BA%BA%E9%A1%9E#Japanese) | mankind, the human race, humanity | jinrui · noun |
| [技](https://en.wiktionary.org/wiki/%E6%8A%80#Japanese) | technique, art, skill | gi · noun |
| [授業](https://en.wiktionary.org/wiki/%E6%8E%88%E6%A5%AD#Japanese) | instruction; teaching; school; lesson, class | jugyō · noun |
| [末](https://en.wiktionary.org/wiki/%E6%9C%AB#Japanese) | a twig or shoot | sue · noun |
| [業](https://en.wiktionary.org/wiki/%E6%A5%AD#Japanese) | work, task, business: the job at hand | gyō · noun |
| [毛](https://en.wiktionary.org/wiki/%E6%AF%9B#Japanese) | animal fur | ke · noun |
| [税](https://en.wiktionary.org/wiki/%E7%A8%8E#Japanese) | tax, duty, customs (money paid to the government) | zei · noun |
| [腹](https://en.wiktionary.org/wiki/%E8%85%B9#Japanese) | belly | hara · noun |
| [銃](https://en.wiktionary.org/wiki/%E9%8A%83#Japanese) | gun (firearm) | jū · noun |
| [隣](https://en.wiktionary.org/wiki/%E9%9A%A3#Japanese) | a neighbour / neighbor | tonari · noun |
| [鳥](https://en.wiktionary.org/wiki/%E9%B3%A5#Japanese) | a bird | tori · noun |
| [便](https://en.wiktionary.org/wiki/%E4%BE%BF#Japanese) | convenient | ben · adj |
| [券](https://en.wiktionary.org/wiki/%E5%88%B8#Japanese) | ticket, certificate | ken · noun |
| [板](https://en.wiktionary.org/wiki/%E6%9D%BF#Japanese) | plank, board | ita · noun |
| [歩](https://en.wiktionary.org/wiki/%E6%AD%A9#Japanese) | a literal (foot)step: walk, walking | ho · noun |
| [玉](https://en.wiktionary.org/wiki/%E7%8E%89#Japanese) | 球, 珠: a ball | tama · noun |
| [病](https://en.wiktionary.org/wiki/%E7%97%85#Japanese) | disease, illness | yamai · noun |
| [選](https://en.wiktionary.org/wiki/%E9%81%B8#Japanese) | selection | sen · noun |

</details>

<details><summary>Words 451–500</summary>

![[Resources/Audio/ja/Words 0451-0500.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [URL](https://en.wiktionary.org/wiki/URL#Japanese) | Uniform Resource Locator | yūārueru · noun |
| [伝説](https://en.wiktionary.org/wiki/%E4%BC%9D%E8%AA%AC#Japanese) | legend (an unrealistic story depicting past events) | densetsu · noun |
| [熱](https://en.wiktionary.org/wiki/%E7%86%B1#Japanese) | fever | netsu · noun |
| [画](https://en.wiktionary.org/wiki/%E7%94%BB#Japanese) | picture, drawing, painting | ga · noun |
| [緑](https://en.wiktionary.org/wiki/%E7%B7%91#Japanese) | green (color) | midori · noun |
| [運](https://en.wiktionary.org/wiki/%E9%81%8B#Japanese) | luck, fortune | un · noun |
| [ビール](https://en.wiktionary.org/wiki/%E3%83%93%E3%83%BC%E3%83%AB#Japanese) | beer (alcoholic drink made of malt) | bīru · noun |
| [窓](https://en.wiktionary.org/wiki/%E7%AA%93#Japanese) | window | mado · noun |
| [草](https://en.wiktionary.org/wiki/%E8%8D%89#Japanese) | grass | kusa · noun |
| [七](https://en.wiktionary.org/wiki/%E4%B8%83#Japanese) | seven, 7 | nana · num |
| [両](https://en.wiktionary.org/wiki/%E4%B8%A1#Japanese) | the both of something | ryō · noun |
| [六](https://en.wiktionary.org/wiki/%E5%85%AD#Japanese) | six | mu · noun |
| [合う](https://en.wiktionary.org/wiki/%E5%90%88%E3%81%86#Japanese) | to match, to fit, to agree | au · verb |
| [省](https://en.wiktionary.org/wiki/%E7%9C%81#Japanese) | ministry, government department, office | shō · noun |
| [筋](https://en.wiktionary.org/wiki/%E7%AD%8B#Japanese) | muscle | suji · noun |
| [説](https://en.wiktionary.org/wiki/%E8%AA%AC#Japanese) | theory | setsu · noun |
| [ドラゴン](https://en.wiktionary.org/wiki/%E3%83%89%E3%83%A9%E3%82%B4%E3%83%B3#Japanese) | Western dragon (mythical creature) | doragon · noun |
| [噂](https://en.wiktionary.org/wiki/%E5%99%82#Japanese) | rumor, rumour | uwasa · noun |
| [天使](https://en.wiktionary.org/wiki/%E5%A4%A9%E4%BD%BF#Japanese) | an angel | tenshi · noun |
| [実](https://en.wiktionary.org/wiki/%E5%AE%9F#Japanese) | fruit (a product of fertilization in a plant) | mi · noun |
| [肌](https://en.wiktionary.org/wiki/%E8%82%8C#Japanese) | human skin | hada · noun |
| [行](https://en.wiktionary.org/wiki/%E8%A1%8C#Japanese) | a line of text | gyō · noun |
| [質](https://en.wiktionary.org/wiki/%E8%B3%AA#Japanese) | quality | shitsu · noun |
| [党](https://en.wiktionary.org/wiki/%E5%85%9A#Japanese) | political party | tō · noun |
| [図](https://en.wiktionary.org/wiki/%E5%9B%B3#Japanese) | diagram, figure, illustration | zu · noun |
| [靴](https://en.wiktionary.org/wiki/%E9%9D%B4#Japanese) | footwear, footgear: a shoe, (a pair of) shoes | kutsu · noun |
| [鬼](https://en.wiktionary.org/wiki/%E9%AC%BC#Japanese) | ghost | oni · noun |
| [人口](https://en.wiktionary.org/wiki/%E4%BA%BA%E5%8F%A3#Japanese) | population | jinkō · noun |
| [共](https://en.wiktionary.org/wiki/%E5%85%B1#Japanese) | both, all | tomo · noun |
| [相](https://en.wiktionary.org/wiki/%E7%9B%B8#Japanese) | nature, personality, characteristic | saga · noun |
| [世](https://en.wiktionary.org/wiki/%E4%B8%96#Japanese) | world, society | yo · noun |
| [副](https://en.wiktionary.org/wiki/%E5%89%AF#Japanese) | copy | fuku · noun |
| [株](https://en.wiktionary.org/wiki/%E6%A0%AA#Japanese) | stump of a tree | kabu · noun |
| [生きる](https://en.wiktionary.org/wiki/%E7%94%9F%E3%81%8D%E3%82%8B#Japanese) | to live; to exist | ikiru · verb |
| [章](https://en.wiktionary.org/wiki/%E7%AB%A0#Japanese) | chapter; section | shō · noun |
| [角](https://en.wiktionary.org/wiki/%E8%A7%92#Japanese) | a corner (e.g., of a desk; compare 隅) | kado · noun |
| [銀](https://en.wiktionary.org/wiki/%E9%8A%80#Japanese) | silver (lustrous, white, metallic element; symbol Ag) | gin · noun |
| [額](https://en.wiktionary.org/wiki/%E9%A1%8D#Japanese) | framed picture | gaku · noun |
| [卵](https://en.wiktionary.org/wiki/%E5%8D%B5#Japanese) | an egg, including fish roe | tamago · noun |
| [和](https://en.wiktionary.org/wiki/%E5%92%8C#Japanese) | peace, harmony, tranquillity, serenity. | wa · noun |
| [府](https://en.wiktionary.org/wiki/%E5%BA%9C#Japanese) | the prefectural governments of Ōsaka and Kyōto | fu · noun |
| [座](https://en.wiktionary.org/wiki/%E5%BA%A7#Japanese) | historical Japanese trade guild (see Za on Wikipedia.Wikipedia | za · noun |
| [悪魔](https://en.wiktionary.org/wiki/%E6%82%AA%E9%AD%94#Japanese) | a demon, devil, fiend | akuma · noun |
| [核](https://en.wiktionary.org/wiki/%E6%A0%B8#Japanese) | atomic nucleus | kaku · noun |
| [牛](https://en.wiktionary.org/wiki/%E7%89%9B#Japanese) | cow, bull, ox, cattle, a domestic bovine | ushi · noun |
| [翻訳](https://en.wiktionary.org/wiki/%E7%BF%BB%E8%A8%B3#Japanese) | translation | hon'yaku · noun |
| [話す](https://en.wiktionary.org/wiki/%E8%A9%B1%E3%81%99#Japanese) | to talk (about something); to speak (on a subject); to converse | hanasu · verb |
| [圏](https://en.wiktionary.org/wiki/%E5%9C%8F#Japanese) | a bounded area, a sphere, a region | ken · noun |
| [比](https://en.wiktionary.org/wiki/%E6%AF%94#Japanese) | a ratio | hi · noun |
| [経](https://en.wiktionary.org/wiki/%E7%B5%8C#Japanese) | a discourse of the Gautama Buddha, one of the Twelve Divisions of Mahayana Buddhism | kyō · noun |

</details>

<details><summary>Words 501–550</summary>

![[Resources/Audio/ja/Words 0501-0550.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [魔](https://en.wiktionary.org/wiki/%E9%AD%94#Japanese) | demon, devil, evil spirit, evil influence | ma · noun |
| [鼻](https://en.wiktionary.org/wiki/%E9%BC%BB#Japanese) | nose | hana · noun |
| [即](https://en.wiktionary.org/wiki/%E5%8D%B3#Japanese) | immediately | soku · adv |
| [段](https://en.wiktionary.org/wiki/%E6%AE%B5#Japanese) | steps (up and down); stairs | dan · noun |
| [産](https://en.wiktionary.org/wiki/%E7%94%A3#Japanese) | production, giving birth | san · noun |
| [職](https://en.wiktionary.org/wiki/%E8%81%B7#Japanese) | employment | shoku · noun |
| [上手](https://en.wiktionary.org/wiki/%E4%B8%8A%E6%89%8B#Japanese) | skillful, dexterous | jōzu · adj |
| [乳](https://en.wiktionary.org/wiki/%E4%B9%B3#Japanese) | breast (of a woman, of a female mammal) | chichi · noun |
| [塩](https://en.wiktionary.org/wiki/%E5%A1%A9#Japanese) | salt | shio · noun |
| [将軍](https://en.wiktionary.org/wiki/%E5%B0%86%E8%BB%8D#Japanese) | a commander of troops, especially of an expeditionary or frontline force | shōgun · noun |
| [橋](https://en.wiktionary.org/wiki/%E6%A9%8B#Japanese) | a bridge | hashi · noun |
| [歯](https://en.wiktionary.org/wiki/%E6%AD%AF#Japanese) | tooth | ha · noun |
| [汗](https://en.wiktionary.org/wiki/%E6%B1%97#Japanese) | sweat | ase · noun |
| [涙](https://en.wiktionary.org/wiki/%E6%B6%99#Japanese) | tear, teardrop | namida · noun |
| [炎](https://en.wiktionary.org/wiki/%E7%82%8E#Japanese) | a flame | honoo · noun |
| [術](https://en.wiktionary.org/wiki/%E8%A1%93#Japanese) | technique | jutsu · noun |
| [貴方](https://en.wiktionary.org/wiki/%E8%B2%B4%E6%96%B9#Japanese) | your house, your residence | kihō · pron |
| [骨](https://en.wiktionary.org/wiki/%E9%AA%A8#Japanese) | bone | hone · noun |
| [床](https://en.wiktionary.org/wiki/%E5%BA%8A#Japanese) | the floor (the bottom surface of a room) | yuka · noun |
| [案](https://en.wiktionary.org/wiki/%E6%A1%88#Japanese) | desk; table | an · noun |
| [理想](https://en.wiktionary.org/wiki/%E7%90%86%E6%83%B3#Japanese) | an ideal | risō · noun |
| [空港](https://en.wiktionary.org/wiki/%E7%A9%BA%E6%B8%AF#Japanese) | airport | kūkō · noun |
| [袋](https://en.wiktionary.org/wiki/%E8%A2%8B#Japanese) | a bag; a sack; a pouch | fukuro · noun |
| [豚](https://en.wiktionary.org/wiki/%E8%B1%9A#Japanese) | pig; swine | buta · noun |
| [鍵](https://en.wiktionary.org/wiki/%E9%8D%B5#Japanese) | key (tool for opening or locking something) | kagi · noun |
| [会う](https://en.wiktionary.org/wiki/%E4%BC%9A%E3%81%86#Japanese) | to meet with, see, meet again or for the first time | au · verb |
| [垢](https://en.wiktionary.org/wiki/%E5%9E%A2#Japanese) | scum | aka · noun |
| [虫](https://en.wiktionary.org/wiki/%E8%99%AB#Japanese) | a small invertebrate. Especially insects and their larvae. | mushi · noun |
| [輪](https://en.wiktionary.org/wiki/%E8%BC%AA#Japanese) | ring; circle | wa · noun |
| [適当](https://en.wiktionary.org/wiki/%E9%81%A9%E5%BD%93#Japanese) | suitable; appropriate; fit | tekitō · adj |
| [鏡](https://en.wiktionary.org/wiki/%E9%8F%A1#Japanese) | a mirror (smooth reflecting surface) | kagami · noun |
| [九](https://en.wiktionary.org/wiki/%E4%B9%9D#Japanese) | nine | kyū · num |
| [伝](https://en.wiktionary.org/wiki/%E4%BC%9D#Japanese) | legend, tradition | den · noun |
| [公](https://en.wiktionary.org/wiki/%E5%85%AC#Japanese) | a European sovereign prince | kō · noun |
| [兵](https://en.wiktionary.org/wiki/%E5%85%B5#Japanese) | a soldier | hei · noun |
| [列](https://en.wiktionary.org/wiki/%E5%88%97#Japanese) | line, row | retsu · noun |
| [匹](https://en.wiktionary.org/wiki/%E5%8C%B9#Japanese) | a unit of measure for fabric length, particularly silk. Presently set at 2 鯨尺 (kujira-shaku) 6 丈 (jō), around 22.8m; with a width of 9 寸 (sun) 5 分 (bu) | hiki · noun |
| [容疑](https://en.wiktionary.org/wiki/%E5%AE%B9%E7%96%91#Japanese) | suspicion, charge | yōgi · noun |
| [肩](https://en.wiktionary.org/wiki/%E8%82%A9#Japanese) | a shoulder | kata · noun |
| [医](https://en.wiktionary.org/wiki/%E5%8C%BB#Japanese) | doctor; physician; medicine | i · noun |
| [天才](https://en.wiktionary.org/wiki/%E5%A4%A9%E6%89%8D#Japanese) | genius | tensai · noun |
| [影](https://en.wiktionary.org/wiki/%E5%BD%B1#Japanese) | light | kaga · noun |
| [暇](https://en.wiktionary.org/wiki/%E6%9A%87#Japanese) | free; leisure; idle; vacant | hima · adj |
| [白い](https://en.wiktionary.org/wiki/%E7%99%BD%E3%81%84#Japanese) | white | shiroi · adj |
| [芸術](https://en.wiktionary.org/wiki/%E8%8A%B8%E8%A1%93#Japanese) | the arts | geijutsu · noun |
| [平](https://en.wiktionary.org/wiki/%E5%B9%B3#Japanese) | something flat; flattened | hira · noun |
| [招待](https://en.wiktionary.org/wiki/%E6%8B%9B%E5%BE%85#Japanese) | invitation | shōtai · noun |
| [波](https://en.wiktionary.org/wiki/%E6%B3%A2#Japanese) | a wave | nami · noun |
| [流](https://en.wiktionary.org/wiki/%E6%B5%81#Japanese) | the flow of water or something like water | ryū · noun |
| [現](https://en.wiktionary.org/wiki/%E7%8F%BE#Japanese) | present reality; what actually exists now | gen · noun |

</details>

<details><summary>Words 551–600</summary>

![[Resources/Audio/ja/Words 0551-0600.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [異](https://en.wiktionary.org/wiki/%E7%95%B0#Japanese) | difference | i · noun |
| [聖](https://en.wiktionary.org/wiki/%E8%81%96#Japanese) | a very virtuous or godly person; a saint | hijiri · noun |
| [赤い](https://en.wiktionary.org/wiki/%E8%B5%A4%E3%81%84#Japanese) | red (color) | akai · adj |
| [通](https://en.wiktionary.org/wiki/%E9%80%9A#Japanese) | authority, expert, connoisseur | tsū · noun |
| [計](https://en.wiktionary.org/wiki/%E8%A8%88#Japanese) | plan | kei · noun |
| [連](https://en.wiktionary.org/wiki/%E9%80%A3#Japanese) | a ream | ren · noun |
| [飯](https://en.wiktionary.org/wiki/%E9%A3%AF#Japanese) | meal; food | han · noun |
| [タバコ](https://en.wiktionary.org/wiki/%E3%82%BF%E3%83%90%E3%82%B3#Japanese) | tobacco | tabako · noun |
| [一応](https://en.wiktionary.org/wiki/%E4%B8%80%E5%BF%9C#Japanese) | just to make sure | ichiō · adv |
| [傷](https://en.wiktionary.org/wiki/%E5%82%B7#Japanese) | any form of shallow wound: an injury, cut, scar | kizu · noun |
| [嵐](https://en.wiktionary.org/wiki/%E5%B5%90#Japanese) | a windstorm | arashi · noun |
| [昼](https://en.wiktionary.org/wiki/%E6%98%BC#Japanese) | the daytime | hiru · noun |
| [神社](https://en.wiktionary.org/wiki/%E7%A5%9E%E7%A4%BE#Japanese) | a shrine, especially a Shinto shrine | jinja · noun |
| [辺](https://en.wiktionary.org/wiki/%E8%BE%BA#Japanese) | place, general area, vicinity | hen · noun |
| [送る](https://en.wiktionary.org/wiki/%E9%80%81%E3%82%8B#Japanese) | to send; to dispatch | okuru · verb |
| [鉄](https://en.wiktionary.org/wiki/%E9%89%84#Japanese) | iron, the metal and the metallic chemical element | tetsu · noun |
| [あい](https://en.wiktionary.org/wiki/%E3%81%82%E3%81%84#Japanese) | relation; relationship; terms (between people) | ai · noun |
| [ジャンプ](https://en.wiktionary.org/wiki/%E3%82%B8%E3%83%A3%E3%83%B3%E3%83%97#Japanese) | a jump | janpu · noun |
| [原](https://en.wiktionary.org/wiki/%E5%8E%9F#Japanese) | meadow, plain, field | hara · noun |
| [可](https://en.wiktionary.org/wiki/%E5%8F%AF#Japanese) | C (academic letter grade); passable | ka · noun |
| [引退](https://en.wiktionary.org/wiki/%E5%BC%95%E9%80%80#Japanese) | retirement | intai · noun |
| [有](https://en.wiktionary.org/wiki/%E6%9C%89#Japanese) | existence | yū · noun |
| [源](https://en.wiktionary.org/wiki/%E6%BA%90#Japanese) | a fountainhead (source of a river) | minamoto · noun |
| [勝](https://en.wiktionary.org/wiki/%E5%8B%9D#Japanese) | win, victory | shō · noun |
| [変態](https://en.wiktionary.org/wiki/%E5%A4%89%E6%85%8B#Japanese) | metamorphosis, transformation | hentai · noun |
| [幅](https://en.wiktionary.org/wiki/%E5%B9%85#Japanese) | width, breadth | haba · noun |
| [戦士](https://en.wiktionary.org/wiki/%E6%88%A6%E5%A3%AB#Japanese) | a soldier, a combatant, a warrior | senshi · noun |
| [扉](https://en.wiktionary.org/wiki/%E6%89%89#Japanese) | a door (moving part of a hinged door that swings out or in, as opposed to a sliding door or the doorway as a whole) | tobira · noun |
| [正](https://en.wiktionary.org/wiki/%E6%AD%A3#Japanese) | correctness | sei · noun |
| [純](https://en.wiktionary.org/wiki/%E7%B4%94#Japanese) | innocent | jun · adj |
| [置く](https://en.wiktionary.org/wiki/%E7%BD%AE%E3%81%8F#Japanese) | to put, place, set | oku · verb |
| [腰](https://en.wiktionary.org/wiki/%E8%85%B0#Japanese) | the waist, the (lower) back, the small of the back | koshi · noun |
| [谷](https://en.wiktionary.org/wiki/%E8%B0%B7#Japanese) | a valley (elongated depression between hills or mountains) | tani · noun |
| [麺](https://en.wiktionary.org/wiki/%E9%BA%BA#Japanese) | noodles | men · noun |
| [お茶](https://en.wiktionary.org/wiki/%E3%81%8A%E8%8C%B6#Japanese) | tea, usually green tea | ocha · noun |
| [上がる](https://en.wiktionary.org/wiki/%E4%B8%8A%E3%81%8C%E3%82%8B#Japanese) | to rise, to ascend, to go up | agaru · verb |
| [人工](https://en.wiktionary.org/wiki/%E4%BA%BA%E5%B7%A5#Japanese) | man-made; artificial | jinkō · noun |
| [奥](https://en.wiktionary.org/wiki/%E5%A5%A5#Japanese) | inside; inner depths | oku · noun |
| [毒](https://en.wiktionary.org/wiki/%E6%AF%92#Japanese) | poison, toxin | doku · noun |
| [策](https://en.wiktionary.org/wiki/%E7%AD%96#Japanese) | plan; policy | saku · noun |
| [多少](https://en.wiktionary.org/wiki/%E5%A4%9A%E5%B0%91#Japanese) | little, somewhat, rather, quite | tashō · adv |
| [宮](https://en.wiktionary.org/wiki/%E5%AE%AE#Japanese) | the place where a god resides: a shrine | miya · noun |
| [環](https://en.wiktionary.org/wiki/%E7%92%B0#Japanese) | ring | kan · noun |
| [関](https://en.wiktionary.org/wiki/%E9%96%A2#Japanese) | barrier, gate | kan · noun |
| [静か](https://en.wiktionary.org/wiki/%E9%9D%99%E3%81%8B#Japanese) | inaudible, quiet, silent | shizuka · adj |
| [松](https://en.wiktionary.org/wiki/%E6%9D%BE#Japanese) | a pine tree | matsu · noun |
| [神様](https://en.wiktionary.org/wiki/%E7%A5%9E%E6%A7%98#Japanese) | an honorific reference to any god or deity, including the God of the Abrahamic religions | kami-sama · noun |
| [野](https://en.wiktionary.org/wiki/%E9%87%8E#Japanese) | an area, field | no · noun |
| [ポケット](https://en.wiktionary.org/wiki/%E3%83%9D%E3%82%B1%E3%83%83%E3%83%88#Japanese) | pocket | poketto · noun |
| [入](https://en.wiktionary.org/wiki/%E5%85%A5#Japanese) | entering, going in | iri · noun |

</details>

<details><summary>Words 601–650</summary>

![[Resources/Audio/ja/Words 0601-0650.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [刀](https://en.wiktionary.org/wiki/%E5%88%80#Japanese) | a single-edged sword, such as a katana | katana · noun |
| [心臓](https://en.wiktionary.org/wiki/%E5%BF%83%E8%87%93#Japanese) | a heart | shinzō · noun |
| [有り](https://en.wiktionary.org/wiki/%E6%9C%89%E3%82%8A#Japanese) | nominalization of 有る (aru): there is, available | ari · noun |
| [糞](https://en.wiktionary.org/wiki/%E7%B3%9E#Japanese) | droppings, dung | fun · noun |
| [縁](https://en.wiktionary.org/wiki/%E7%B8%81#Japanese) | fate, destiny | en · noun |
| [群](https://en.wiktionary.org/wiki/%E7%BE%A4#Japanese) | a group (of people, animals, etc.) | gun · noun |
| [華](https://en.wiktionary.org/wiki/%E8%8F%AF#Japanese) | flashiness, showiness | ka · noun |
| [見せる](https://en.wiktionary.org/wiki/%E8%A6%8B%E3%81%9B%E3%82%8B#Japanese) | to show | miseru · verb |
| [陣](https://en.wiktionary.org/wiki/%E9%99%A3#Japanese) | battle formation | jin · noun |
| [順](https://en.wiktionary.org/wiki/%E9%A0%86#Japanese) | order, sequence, turn | jun · noun |
| [香](https://en.wiktionary.org/wiki/%E9%A6%99#Japanese) | a pleasant smell; a scent, a fragrance, an aroma | ka · noun |
| [仕組み](https://en.wiktionary.org/wiki/%E4%BB%95%E7%B5%84%E3%81%BF#Japanese) | construction, structure | shikumi · noun |
| [図書館](https://en.wiktionary.org/wiki/%E5%9B%B3%E6%9B%B8%E9%A4%A8#Japanese) | library (building) | toshokan · noun |
| [嫁](https://en.wiktionary.org/wiki/%E5%AB%81#Japanese) | bride | yome · noun |
| [酸](https://en.wiktionary.org/wiki/%E9%85%B8#Japanese) | sourness (quality or condition) | san · noun |
| [重い](https://en.wiktionary.org/wiki/%E9%87%8D%E3%81%84#Japanese) | heavy | omoi · adj |
| [黒い](https://en.wiktionary.org/wiki/%E9%BB%92%E3%81%84#Japanese) | black | kuroi · adj |
| [丁](https://en.wiktionary.org/wiki/%E4%B8%81#Japanese) | street, district | chō · noun |
| [像](https://en.wiktionary.org/wiki/%E5%83%8F#Japanese) | a form of a thing, including god; a figure; a statue; an idol | zō · noun |
| [勢](https://en.wiktionary.org/wiki/%E5%8B%A2#Japanese) | force | sei · noun |
| [弱](https://en.wiktionary.org/wiki/%E5%BC%B1#Japanese) | weakness | jaku · noun |
| [早](https://en.wiktionary.org/wiki/%E6%97%A9#Japanese) | already, now | haya · noun |
| [極](https://en.wiktionary.org/wiki/%E6%A5%B5#Japanese) | very, extremely | goku · adv |
| [氷](https://en.wiktionary.org/wiki/%E6%B0%B7#Japanese) | ice (frozen water) | kōri · noun |
| [活](https://en.wiktionary.org/wiki/%E6%B4%BB#Japanese) | life | katsu · noun |
| [狼](https://en.wiktionary.org/wiki/%E7%8B%BC#Japanese) | a wolf (animal) | ōkami · noun |
| [輸入](https://en.wiktionary.org/wiki/%E8%BC%B8%E5%85%A5#Japanese) | import, importation | yunyū · noun |
| [送信](https://en.wiktionary.org/wiki/%E9%80%81%E4%BF%A1#Japanese) | transmission | sōshin · noun |
| [底](https://en.wiktionary.org/wiki/%E5%BA%95#Japanese) | the bottom | soko · noun |
| [新幹線](https://en.wiktionary.org/wiki/%E6%96%B0%E5%B9%B9%E7%B7%9A#Japanese) | shinkansen (Japanese high-speed railway line) | shinkansen · noun |
| [球](https://en.wiktionary.org/wiki/%E7%90%83#Japanese) | sphere, globe, orb | kyū · noun |
| [真剣](https://en.wiktionary.org/wiki/%E7%9C%9F%E5%89%A3#Japanese) | serious, sincere, intense, honest | shinken · adj |
| [羽](https://en.wiktionary.org/wiki/%E7%BE%BD#Japanese) | a feather, down, plume | hane · noun |
| [軸](https://en.wiktionary.org/wiki/%E8%BB%B8#Japanese) | axis | jiku · noun |
| [里](https://en.wiktionary.org/wiki/%E9%87%8C#Japanese) | 郷: a village | sato · noun |
| [門](https://en.wiktionary.org/wiki/%E9%96%80#Japanese) | a gate | mon · noun |
| [開く](https://en.wiktionary.org/wiki/%E9%96%8B%E3%81%8F#Japanese) | to open | aku · verb |
| [棒](https://en.wiktionary.org/wiki/%E6%A3%92#Japanese) | a staff, measuring 6 shaku (about 1.8 meters), used in martial arts such as 棒術 (bōjutsu) | bō · noun |
| [票](https://en.wiktionary.org/wiki/%E7%A5%A8#Japanese) | vote | hyō · noun |
| [茶](https://en.wiktionary.org/wiki/%E8%8C%B6#Japanese) | tea | cha · noun |
| [証](https://en.wiktionary.org/wiki/%E8%A8%BC#Japanese) | proof, evidence, testimony | akashi · noun |
| [こん](https://en.wiktionary.org/wiki/%E3%81%93%E3%82%93#Japanese) | 事: thing | kon · noun |
| [俳優](https://en.wiktionary.org/wiki/%E4%BF%B3%E5%84%AA#Japanese) | actor (male or female) | haiyū · noun |
| [塾](https://en.wiktionary.org/wiki/%E5%A1%BE#Japanese) | a cram school | juku · noun |
| [晩](https://en.wiktionary.org/wiki/%E6%99%A9#Japanese) | evening | ban · noun |
| [欄](https://en.wiktionary.org/wiki/%E6%AC%84#Japanese) | column in a newspaper | ran · noun |
| [漢字](https://en.wiktionary.org/wiki/%E6%BC%A2%E5%AD%97#Japanese) | kanji | kanji · noun |
| [皮](https://en.wiktionary.org/wiki/%E7%9A%AE#Japanese) | skin | kawa · noun |
| [やす](https://en.wiktionary.org/wiki/%E3%82%84%E3%81%99#Japanese) | 簎, 矠: spear, lance | yasu · noun |
| [ゆき](https://en.wiktionary.org/wiki/%E3%82%86%E3%81%8D#Japanese) | for 大嘗祭 (Daijōsai), the country chosen to offer grain and alcohol | yuki · noun |

</details>

<details><summary>Words 651–700</summary>

![[Resources/Audio/ja/Words 0651-0700.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [優](https://en.wiktionary.org/wiki/%E5%84%AA#Japanese) | enough, amply | yū · adv |
| [岩](https://en.wiktionary.org/wiki/%E5%B2%A9#Japanese) | rock | iwa · noun |
| [我](https://en.wiktionary.org/wiki/%E6%88%91#Japanese) | first person singular pronoun: I, me, oneself | ware · pron |
| [才](https://en.wiktionary.org/wiki/%E6%89%8D#Japanese) | ability, talent, aptitude | sai · noun |
| [族](https://en.wiktionary.org/wiki/%E6%97%8F#Japanese) | group (column in the periodic table) | zoku · noun |
| [池](https://en.wiktionary.org/wiki/%E6%B1%A0#Japanese) | a pond (small lake or pool) | ike · noun |
| [直](https://en.wiktionary.org/wiki/%E7%9B%B4#Japanese) | soon, shortly | jiki · adj |
| [缶](https://en.wiktionary.org/wiki/%E7%BC%B6#Japanese) | a can, a tin | kan · noun |
| [若](https://en.wiktionary.org/wiki/%E8%8B%A5#Japanese) | “my lord” (towards a young master or a young heir) | waka · noun |
| [英雄](https://en.wiktionary.org/wiki/%E8%8B%B1%E9%9B%84#Japanese) | hero | eiyū · noun |
| [菜](https://en.wiktionary.org/wiki/%E8%8F%9C#Japanese) | greens | na · noun |
| [要](https://en.wiktionary.org/wiki/%E8%A6%81#Japanese) | key, important point | yō · noun |
| [ぼ](https://en.wiktionary.org/wiki/%E3%81%BC#Japanese) | 戊: the fifth day of the traditional Chinese ten-day cycle | bo · noun |
| [港](https://en.wiktionary.org/wiki/%E6%B8%AF#Japanese) | a sluice; a section of a river to let water in and out | minato · noun |
| [霊](https://en.wiktionary.org/wiki/%E9%9C%8A#Japanese) | soul; spirit | rei · noun |
| [具](https://en.wiktionary.org/wiki/%E5%85%B7#Japanese) | tool | gu · noun |
| [基](https://en.wiktionary.org/wiki/%E5%9F%BA#Japanese) | foundation | motoi · noun |
| [嬢](https://en.wiktionary.org/wiki/%E5%AC%A2#Japanese) | a daughter (female offspring) | jō · noun |
| [管](https://en.wiktionary.org/wiki/%E7%AE%A1#Japanese) | pipe | kan · noun |
| [素](https://en.wiktionary.org/wiki/%E7%B4%A0#Japanese) | unadorned state | su · noun |
| [SF](https://en.wiktionary.org/wiki/SF#Japanese) | SF: abbreviation of サイエンス・フィクション (“science fiction”) | esuefu · noun |
| [体育](https://en.wiktionary.org/wiki/%E4%BD%93%E8%82%B2#Japanese) | physical education | taiiku · noun |
| [工作](https://en.wiktionary.org/wiki/%E5%B7%A5%E4%BD%9C#Japanese) | handicraft, industrial art, woodwork | kōsaku · noun |
| [明](https://en.wiktionary.org/wiki/%E6%98%8E#Japanese) | brightness | mei · noun |
| [柄](https://en.wiktionary.org/wiki/%E6%9F%84#Japanese) | a handle, a grip, a shaft, a haft | e · noun |
| [格](https://en.wiktionary.org/wiki/%E6%A0%BC#Japanese) | status, rank | kaku · noun |
| [汚い](https://en.wiktionary.org/wiki/%E6%B1%9A%E3%81%84#Japanese) | dirty | kitanai · adj |
| [爪](https://en.wiktionary.org/wiki/%E7%88%AA#Japanese) | nail; claw | tsume · noun |
| [猿](https://en.wiktionary.org/wiki/%E7%8C%BF#Japanese) | a monkey (primate) | saru · noun |
| [翼](https://en.wiktionary.org/wiki/%E7%BF%BC#Japanese) | a wing (of a bird or bat) | tsubasa · noun |
| [背](https://en.wiktionary.org/wiki/%E8%83%8C#Japanese) | one's back (part of the human body) | se · noun |
| [鍋](https://en.wiktionary.org/wiki/%E9%8D%8B#Japanese) | a broad-bottomed pot or pan | nabe · noun |
| [項](https://en.wiktionary.org/wiki/%E9%A0%85#Japanese) | nape (back of the neck) | unaji · noun |
| [乙](https://en.wiktionary.org/wiki/%E4%B9%99#Japanese) | the second item of any ordered list | otsu · noun |
| [亀](https://en.wiktionary.org/wiki/%E4%BA%80#Japanese) | a tortoise or turtle (land or marine reptile with a shell) | kame · noun |
| [劇](https://en.wiktionary.org/wiki/%E5%8A%87#Japanese) | play | geki · noun |
| [加](https://en.wiktionary.org/wiki/%E5%8A%A0#Japanese) | addition | ka · noun |
| [妙](https://en.wiktionary.org/wiki/%E5%A6%99#Japanese) | strange | myō · adj |
| [庭](https://en.wiktionary.org/wiki/%E5%BA%AD#Japanese) | garden, yard | niwa · noun |
| [矢](https://en.wiktionary.org/wiki/%E7%9F%A2#Japanese) | an arrow | ya · noun |
| [紫](https://en.wiktionary.org/wiki/%E7%B4%AB#Japanese) | purple or red-root gromwell (Lithospermum erythrorhizon) | murasaki · noun |
| [膝](https://en.wiktionary.org/wiki/%E8%86%9D#Japanese) | knee | hiza · noun |
| [陽](https://en.wiktionary.org/wiki/%E9%99%BD#Japanese) | yang (in yin-yang) | yō · noun |
| [SP](https://en.wiktionary.org/wiki/SP#Japanese) | bodyguard | esu-pī · noun |
| [けん](https://en.wiktionary.org/wiki/%E3%81%91%E3%82%93#Japanese) | because, since, so: presents the preceding clause as the reason for the following clause | ken · particle |
| [京](https://en.wiktionary.org/wiki/%E4%BA%AC#Japanese) | capital city | kyō · noun |
| [損](https://en.wiktionary.org/wiki/%E6%90%8D#Japanese) | loss (opposite of gain) | son · noun |
| [桁](https://en.wiktionary.org/wiki/%E6%A1%81#Japanese) | girder, crossbeam | keta · noun |
| [竜](https://en.wiktionary.org/wiki/%E7%AB%9C#Japanese) | a Chinese dragon | ryū · noun |
| [節](https://en.wiktionary.org/wiki/%E7%AF%80#Japanese) | a knuckle, a joint | fushi · noun |

</details>

<details><summary>Words 701–750</summary>

![[Resources/Audio/ja/Words 0701-0750.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [舌](https://en.wiktionary.org/wiki/%E8%88%8C#Japanese) | tongue | shita · noun |
| [豆](https://en.wiktionary.org/wiki/%E8%B1%86#Japanese) | the pulses | mame · noun |
| [録音](https://en.wiktionary.org/wiki/%E9%8C%B2%E9%9F%B3#Japanese) | audio recording | rokuon · noun |
| [雲](https://en.wiktionary.org/wiki/%E9%9B%B2#Japanese) | a cloud (visible mass of water droplets or other related material suspended in the air) | kumo · noun |
| [青い](https://en.wiktionary.org/wiki/%E9%9D%92%E3%81%84#Japanese) | blue | aoi · adj |
| [堂](https://en.wiktionary.org/wiki/%E5%A0%82#Japanese) | a hall where a deity is enshrined | dō · noun |
| [墓](https://en.wiktionary.org/wiki/%E5%A2%93#Japanese) | a grave, a tomb | haka · noun |
| [某](https://en.wiktionary.org/wiki/%E6%9F%90#Japanese) | a certain person or thing; a so-and-so | bō · noun |
| [汁](https://en.wiktionary.org/wiki/%E6%B1%81#Japanese) | juice | shiru · noun |
| [裸](https://en.wiktionary.org/wiki/%E8%A3%B8#Japanese) | nakedness; nudity; not being clothed | hadaka · noun |
| [跡](https://en.wiktionary.org/wiki/%E8%B7%A1#Japanese) | evidence of something passing; footsteps, trace, tracks | ato · noun |
| [印](https://en.wiktionary.org/wiki/%E5%8D%B0#Japanese) | stamp, seal | in · noun |
| [宝](https://en.wiktionary.org/wiki/%E5%AE%9D#Japanese) | treasure | takara · noun |
| [尾](https://en.wiktionary.org/wiki/%E5%B0%BE#Japanese) | tail | o · noun |
| [弁](https://en.wiktionary.org/wiki/%E5%BC%81#Japanese) | discrimination | ben · noun |
| [殿](https://en.wiktionary.org/wiki/%E6%AE%BF#Japanese) | a feudal lord | tono · noun |
| [泉](https://en.wiktionary.org/wiki/%E6%B3%89#Japanese) | natural spring, a wellspring | izumi · noun |
| [課](https://en.wiktionary.org/wiki/%E8%AA%B2#Japanese) | lesson | ka · noun |
| [助](https://en.wiktionary.org/wiki/%E5%8A%A9#Japanese) | assistance | suke · noun |
| [医学](https://en.wiktionary.org/wiki/%E5%8C%BB%E5%AD%A6#Japanese) | medicine (field of study), medical science | igaku · noun |
| [古](https://en.wiktionary.org/wiki/%E5%8F%A4#Japanese) | used item, secondhand item, hand-me-down | furu · noun |
| [増](https://en.wiktionary.org/wiki/%E5%A2%97#Japanese) | increase | zō · noun |
| [孫](https://en.wiktionary.org/wiki/%E5%AD%AB#Japanese) | grandchild | mumago · noun |
| [教える](https://en.wiktionary.org/wiki/%E6%95%99%E3%81%88%E3%82%8B#Japanese) | to inform, to teach, to instruct | oshieru · verb |
| [林](https://en.wiktionary.org/wiki/%E6%9E%97#Japanese) | a grove, woods, copse | hayashi · noun |
| [癖](https://en.wiktionary.org/wiki/%E7%99%96#Japanese) | habit; tendency | kuse · noun |
| [きょう](https://en.wiktionary.org/wiki/%E3%81%8D%E3%82%87%E3%81%86#Japanese) | today | kyō · noun |
| [丼](https://en.wiktionary.org/wiki/%E4%B8%BC#Japanese) | a simple large bowl for serving food | donburi · noun |
| [喉](https://en.wiktionary.org/wiki/%E5%96%89#Japanese) | throat | nodo · noun |
| [湯](https://en.wiktionary.org/wiki/%E6%B9%AF#Japanese) | warm or hot water | yu · noun |
| [今朝](https://en.wiktionary.org/wiki/%E4%BB%8A%E6%9C%9D#Japanese) | this morning | kesa · adv |
| [卒](https://en.wiktionary.org/wiki/%E5%8D%92#Japanese) | low-ranking soldier | sotsu · noun |
| [恥](https://en.wiktionary.org/wiki/%E6%81%A5#Japanese) | shame | haji · noun |
| [根](https://en.wiktionary.org/wiki/%E6%A0%B9#Japanese) | a root of a plant | ne · noun |
| [湖](https://en.wiktionary.org/wiki/%E6%B9%96#Japanese) | a lake (body of water) | mizuumi · noun |
| [網](https://en.wiktionary.org/wiki/%E7%B6%B2#Japanese) | net, netting | ami · noun |
| [縦](https://en.wiktionary.org/wiki/%E7%B8%A6#Japanese) | length | tate · noun |
| [記](https://en.wiktionary.org/wiki/%E8%A8%98#Japanese) | a chronicle | ki · noun |
| [寺](https://en.wiktionary.org/wiki/%E5%AF%BA#Japanese) | a temple | tera · noun |
| [机](https://en.wiktionary.org/wiki/%E6%9C%BA#Japanese) | desk; table | tsukue · noun |
| [洋](https://en.wiktionary.org/wiki/%E6%B4%8B#Japanese) | an ocean | yō · noun |
| [理](https://en.wiktionary.org/wiki/%E7%90%86#Japanese) | reason, logic | ri · noun |
| [畑](https://en.wiktionary.org/wiki/%E7%95%91#Japanese) | dry field; plantation; garden for growing fruits and vegetables | hatake · noun |
| [舞](https://en.wiktionary.org/wiki/%E8%88%9E#Japanese) | a type of traditional Japanese dance consisting of simple and quiet movements | mai · noun |
| [MC](https://en.wiktionary.org/wiki/MC#Japanese) | emcee | emu-shī · noun |
| [PR](https://en.wiktionary.org/wiki/PR#Japanese) | synonym of パブリック・リレーションズ (paburikku rirēshonzu, “public relations”); PR | pīāru · noun |
| [勇](https://en.wiktionary.org/wiki/%E5%8B%87#Japanese) | bravery | yū · noun |
| [吉](https://en.wiktionary.org/wiki/%E5%90%89#Japanese) | good luck, blessedness, happiness | kichi · noun |
| [帳](https://en.wiktionary.org/wiki/%E5%B8%B3#Japanese) | curtain | tobari · noun |
| [恵](https://en.wiktionary.org/wiki/%E6%81%B5#Japanese) | 恵, 慧: enlightenment | e · noun |

</details>

<details><summary>Words 751–800</summary>

![[Resources/Audio/ja/Words 0751-0800.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [武](https://en.wiktionary.org/wiki/%E6%AD%A6#Japanese) | courage, ferocity, valor | bu · noun |
| [藤](https://en.wiktionary.org/wiki/%E8%97%A4#Japanese) | wisteria | fuji · noun |
| [虎](https://en.wiktionary.org/wiki/%E8%99%8E#Japanese) | tiger, Panthera tigris | tora · noun |
| [SM](https://en.wiktionary.org/wiki/SM#Japanese) | S&M | esuemu · noun |
| [利](https://en.wiktionary.org/wiki/%E5%88%A9#Japanese) | profit, benefit, advantage | ri · noun |
| [宿](https://en.wiktionary.org/wiki/%E5%AE%BF#Japanese) | dwelling, house, home | yado · noun |
| [斗](https://en.wiktionary.org/wiki/%E6%96%97#Japanese) | an obsolete unit of liquid measure equal to about 18 liters (18,000 cm³) | to · noun |
| [菌](https://en.wiktionary.org/wiki/%E8%8F%8C#Japanese) | fungus, germ, bacterium | kin · noun |
| [衣](https://en.wiktionary.org/wiki/%E8%A1%A3#Japanese) | a robe (as worn by a monk, nun, or priest) | koromo · noun |
| [人権](https://en.wiktionary.org/wiki/%E4%BA%BA%E6%A8%A9#Japanese) | human rights | jinken · noun |
| [塔](https://en.wiktionary.org/wiki/%E5%A1%94#Japanese) | tower (structure) | tō · noun |
| [材](https://en.wiktionary.org/wiki/%E6%9D%90#Japanese) | wood | zai · noun |
| [略](https://en.wiktionary.org/wiki/%E7%95%A5#Japanese) | omission | ryaku · noun |
| [皿](https://en.wiktionary.org/wiki/%E7%9A%BF#Japanese) | dish, plate | sara · noun |
| [糸](https://en.wiktionary.org/wiki/%E7%B3%B8#Japanese) | thread | ito · noun |
| [花火](https://en.wiktionary.org/wiki/%E8%8A%B1%E7%81%AB#Japanese) | fireworks | hanabi · noun |
| [倉庫](https://en.wiktionary.org/wiki/%E5%80%89%E5%BA%AB#Japanese) | warehouse | sōko · noun |
| [偽](https://en.wiktionary.org/wiki/%E5%81%BD#Japanese) | a falsehood, lie | gi · noun |
| [兆](https://en.wiktionary.org/wiki/%E5%85%86#Japanese) | trillion (million million), 10¹² | chō · num |
| [刃](https://en.wiktionary.org/wiki/%E5%88%83#Japanese) | any sharp and thin cutting implement: a blade, edge | ha · noun |
| [明るい](https://en.wiktionary.org/wiki/%E6%98%8E%E3%82%8B%E3%81%84#Japanese) | bright; light; luminous | akarui · adj |
| [田](https://en.wiktionary.org/wiki/%E7%94%B0#Japanese) | rice paddy | ta · noun |
| [瞳](https://en.wiktionary.org/wiki/%E7%9E%B3#Japanese) | pupil | hitomi · noun |
| [紅](https://en.wiktionary.org/wiki/%E7%B4%85#Japanese) | the color crimson, a vivid red edging towards pink | kurenai · noun |
| [調べる](https://en.wiktionary.org/wiki/%E8%AA%BF%E3%81%B9%E3%82%8B#Japanese) | to investigate, to look up, to look into, to study, to examine, to check up on, to look over | shiraberu · verb |
| [黄色](https://en.wiktionary.org/wiki/%E9%BB%84%E8%89%B2#Japanese) | yellow | kiiro · adj |
| [び](https://en.wiktionary.org/wiki/%E3%81%B3#Japanese) | 美: beautiful | bi · adj |
| [協議](https://en.wiktionary.org/wiki/%E5%8D%94%E8%AD%B0#Japanese) | consultation, conference, deliberation, discussion, negotiation | kyōgi · noun |
| [志](https://en.wiktionary.org/wiki/%E5%BF%97#Japanese) | intention, aspiration, aim, ambition, will | kokorozashi · noun |
| [戸](https://en.wiktionary.org/wiki/%E6%88%B8#Japanese) | door; a plate placed on doorway | to · noun |
| [胃](https://en.wiktionary.org/wiki/%E8%83%83#Japanese) | stomach | i · noun |
| [蓮](https://en.wiktionary.org/wiki/%E8%93%AE#Japanese) | older name for 蓮(はす) (hasu), below: a lotus plant or flower, Nelumbo nucifera | hachisu · noun |
| [蘭](https://en.wiktionary.org/wiki/%E8%98%AD#Japanese) | an orchid | ran · noun |
| [餌](https://en.wiktionary.org/wiki/%E9%A4%8C#Japanese) | animal food, feed | esa · noun |
| [鶏](https://en.wiktionary.org/wiki/%E9%B6%8F#Japanese) | a domesticated chicken (Gallus gallus domesticus) | niwatori · noun |
| [ホラー](https://en.wiktionary.org/wiki/%E3%83%9B%E3%83%A9%E3%83%BC#Japanese) | horror (as a genre or element of fiction) | horā · noun |
| [メス](https://en.wiktionary.org/wiki/%E3%83%A1%E3%82%B9#Japanese) | scalpel, lancet, medical knife | mesu · noun |
| [係](https://en.wiktionary.org/wiki/%E4%BF%82#Japanese) | person in charge, person responsible | kakari · noun |
| [唐](https://en.wiktionary.org/wiki/%E5%94%90#Japanese) | foreign lands in general | tō · noun |
| [布](https://en.wiktionary.org/wiki/%E5%B8%83#Japanese) | cloth | nuno · noun |
| [念](https://en.wiktionary.org/wiki/%E5%BF%B5#Japanese) | idea, thought | nen · noun |
| [癌](https://en.wiktionary.org/wiki/%E7%99%8C#Japanese) | cancer | gan · noun |
| [砲](https://en.wiktionary.org/wiki/%E7%A0%B2#Japanese) | gun, firearm | hō · noun |
| [雷](https://en.wiktionary.org/wiki/%E9%9B%B7#Japanese) | thunder (loud sound caused by expansion of rapidly heated air) | kaminari · noun |
| [AI](https://en.wiktionary.org/wiki/AI#Japanese) | synonym of 人工知能 (jinkō chinō, “artificial intelligence”); AI | ēai · noun |
| [仮](https://en.wiktionary.org/wiki/%E4%BB%AE#Japanese) | temporary; tentative; provisional | kari · noun |
| [女神](https://en.wiktionary.org/wiki/%E5%A5%B3%E7%A5%9E#Japanese) | a goddess (female deity) | megami · noun |
| [端](https://en.wiktionary.org/wiki/%E7%AB%AF#Japanese) | edge, side | hashi · noun |
| [if](https://en.wiktionary.org/wiki/if#Japanese) | "what-if" alternative history (real-life) / events (fictional) | if · noun |
| [寒](https://en.wiktionary.org/wiki/%E5%AF%92#Japanese) | cold, coldness | kan · noun |

</details>

<details><summary>Words 801–850</summary>

![[Resources/Audio/ja/Words 0801-0850.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [拳](https://en.wiktionary.org/wiki/%E6%8B%B3#Japanese) | fist | kobushi · noun |
| [旗](https://en.wiktionary.org/wiki/%E6%97%97#Japanese) | flag | hata · noun |
| [旨](https://en.wiktionary.org/wiki/%E6%97%A8#Japanese) | principle; aim; purpose | mune · noun |
| [栄](https://en.wiktionary.org/wiki/%E6%A0%84#Japanese) | honour, glory | ei · noun |
| [梅](https://en.wiktionary.org/wiki/%E6%A2%85#Japanese) | Japanese plum or apricot (Prunus mume) | ume · noun |
| [欲](https://en.wiktionary.org/wiki/%E6%AC%B2#Japanese) | desire, a want, that which is wanted | yoku · noun |
| [液](https://en.wiktionary.org/wiki/%E6%B6%B2#Japanese) | liquid | eki · noun |
| [炉](https://en.wiktionary.org/wiki/%E7%82%89#Japanese) | furnace, kiln | ro · noun |
| [熊](https://en.wiktionary.org/wiki/%E7%86%8A#Japanese) | a bear (large mammal of family Ursidae) | kuma · noun |
| [詩](https://en.wiktionary.org/wiki/%E8%A9%A9#Japanese) | poem | shi · noun |
| [黄](https://en.wiktionary.org/wiki/%E9%BB%84#Japanese) | yellow | ki · adj |
| [仏](https://en.wiktionary.org/wiki/%E4%BB%8F#Japanese) | a buddha (enlightened or awakened sentient being) | hotoke · noun |
| [桃](https://en.wiktionary.org/wiki/%E6%A1%83#Japanese) | peach | momo · noun |
| [灯](https://en.wiktionary.org/wiki/%E7%81%AF#Japanese) | a light, lamp | tō · noun |
| [糖](https://en.wiktionary.org/wiki/%E7%B3%96#Japanese) | sugar | tō · noun |
| [罠](https://en.wiktionary.org/wiki/%E7%BD%A0#Japanese) | a trap, a snare | wana · noun |
| [鈴](https://en.wiktionary.org/wiki/%E9%88%B4#Japanese) | a bell, chime | suzu · noun |
| [DNA](https://en.wiktionary.org/wiki/DNA#Japanese) | synonym of デオキシリボ核酸 (deokishiribo-kakusan, “deoxyribonucleic acid”); DNA | dī-enu-ē · noun |
| [プロレス](https://en.wiktionary.org/wiki/%E3%83%97%E3%83%AD%E3%83%AC%E3%82%B9#Japanese) | professional wrestling | puroresu · noun |
| [井](https://en.wiktionary.org/wiki/%E4%BA%95#Japanese) | well (water source) | i · noun |
| [人種](https://en.wiktionary.org/wiki/%E4%BA%BA%E7%A8%AE#Japanese) | race; ethnicity | jinshu · noun |
| [兼](https://en.wiktionary.org/wiki/%E5%85%BC#Japanese) | -cum-, concurrently, and; in addition | -ken- · conj |
| [宅](https://en.wiktionary.org/wiki/%E5%AE%85#Japanese) | home | taku · noun |
| [柱](https://en.wiktionary.org/wiki/%E6%9F%B1#Japanese) | pillar | hashira · noun |
| [発音](https://en.wiktionary.org/wiki/%E7%99%BA%E9%9F%B3#Japanese) | pronunciation | hatsuon · noun |
| [盾](https://en.wiktionary.org/wiki/%E7%9B%BE#Japanese) | a shield (weapon stood up or erected before one's body to block and protect from attacks) | tate · noun |
| [眼鏡](https://en.wiktionary.org/wiki/%E7%9C%BC%E9%8F%A1#Japanese) | glasses, eyeglasses | megane · noun |
| [知](https://en.wiktionary.org/wiki/%E7%9F%A5#Japanese) | wisdom | chi · noun |
| [竹](https://en.wiktionary.org/wiki/%E7%AB%B9#Japanese) | bamboo | take · noun |
| [罰](https://en.wiktionary.org/wiki/%E7%BD%B0#Japanese) | punishment; a curse | bachi · noun |
| [脇](https://en.wiktionary.org/wiki/%E8%84%87#Japanese) | the armpit, the underarm | waki · noun |
| [芸](https://en.wiktionary.org/wiki/%E8%8A%B8#Japanese) | art, craft, technique, performance | gei · noun |
| [麻](https://en.wiktionary.org/wiki/%E9%BA%BB#Japanese) | hemp, Cannabis sativa | asa · noun |
| [あか](https://en.wiktionary.org/wiki/%E3%81%82%E3%81%8B#Japanese) | 垢: dirt, grime | aka · noun |
| [いいえ](https://en.wiktionary.org/wiki/%E3%81%84%E3%81%84%E3%81%88#Japanese) | no | īe · intj |
| [乱](https://en.wiktionary.org/wiki/%E4%B9%B1#Japanese) | chaos, disorder | ran · noun |
| [人格](https://en.wiktionary.org/wiki/%E4%BA%BA%E6%A0%BC#Japanese) | personality; a person's character | jinkaku · noun |
| [傘](https://en.wiktionary.org/wiki/%E5%82%98#Japanese) | a folding umbrella (cloth-covered frame used for protection against rain or sun) | kasa · noun |
| [泥](https://en.wiktionary.org/wiki/%E6%B3%A5#Japanese) | mud | doro · noun |
| [砂](https://en.wiktionary.org/wiki/%E7%A0%82#Japanese) | sand; grit | suna · noun |
| [稀](https://en.wiktionary.org/wiki/%E7%A8%80#Japanese) | rare | mare · adj |
| [虹](https://en.wiktionary.org/wiki/%E8%99%B9#Japanese) | a rainbow | niji · noun |
| [言](https://en.wiktionary.org/wiki/%E8%A8%80#Japanese) | word | gen · noun |
| [雄](https://en.wiktionary.org/wiki/%E9%9B%84#Japanese) | male | yū · noun |
| [くま](https://en.wiktionary.org/wiki/%E3%81%8F%E3%81%BE#Japanese) | 隈, 曲, 阿: corner, nook, recess | kuma · noun |
| [域](https://en.wiktionary.org/wiki/%E5%9F%9F#Japanese) | region, level | iki · noun |
| [幸](https://en.wiktionary.org/wiki/%E5%B9%B8#Japanese) | good luck, good fortune; happiness | kō · noun |
| [甲](https://en.wiktionary.org/wiki/%E7%94%B2#Japanese) | carapace, shell | kō · noun |
| [礼](https://en.wiktionary.org/wiki/%E7%A4%BC#Japanese) | a bow, the gesture of bending at the waist | rei · noun |
| [福](https://en.wiktionary.org/wiki/%E7%A6%8F#Japanese) | good luck, good fortune | fuku · noun |

</details>

<details><summary>Words 851–900</summary>

![[Resources/Audio/ja/Words 0851-0900.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [粒](https://en.wiktionary.org/wiki/%E7%B2%92#Japanese) | something round and small, such as a kernel of grain or a bead | tsubu · noun |
| [軒](https://en.wiktionary.org/wiki/%E8%BB%92#Japanese) | eaves | noki · noun |
| [針](https://en.wiktionary.org/wiki/%E9%87%9D#Japanese) | a sewing needle | hari · noun |
| [鶴](https://en.wiktionary.org/wiki/%E9%B6%B4#Japanese) | a crane (large, long-legged and long-necked bird of the family Gruidae) | tsuru · noun |
| [商](https://en.wiktionary.org/wiki/%E5%95%86#Japanese) | dealing, dealer, merchant | shō · noun |
| [報](https://en.wiktionary.org/wiki/%E5%A0%B1#Japanese) | news, information | hō · noun |
| [守](https://en.wiktionary.org/wiki/%E5%AE%88#Japanese) | a watchman, a keeper (as of a lighthouse), a caretaker | mori · noun |
| [幕](https://en.wiktionary.org/wiki/%E5%B9%95#Japanese) | curtain | maku · noun |
| [忍](https://en.wiktionary.org/wiki/%E5%BF%8D#Japanese) | squirrel's foot fern, Davallia mariesii | shinobu · noun |
| [槍](https://en.wiktionary.org/wiki/%E6%A7%8D#Japanese) | a spear, lance | yari · noun |
| [紗](https://en.wiktionary.org/wiki/%E7%B4%97#Japanese) | a coarse gauze woven of raw silk | sha · noun |
| [能](https://en.wiktionary.org/wiki/%E8%83%BD#Japanese) | Noh, a form of classical Japanese musical drama | nō · noun |
| [雑](https://en.wiktionary.org/wiki/%E9%9B%91#Japanese) | rough, crude, sloppy, messy | zatsu · adj |
| [並](https://en.wiktionary.org/wiki/%E4%B8%A6#Japanese) | something medium, average, common, ordinary | nami · noun |
| [堀](https://en.wiktionary.org/wiki/%E5%A0%80#Japanese) | ditch, canal | hori · noun |
| [撮](https://en.wiktionary.org/wiki/%E6%92%AE#Japanese) | A unit of volume, equal to one-tenth of a 勺(しゃく) (shaku), or equivalently around 1.8039 millilitres. | satsu · noun |
| [札](https://en.wiktionary.org/wiki/%E6%9C%AD#Japanese) | a ticket, a token | satsu · noun |
| [籠](https://en.wiktionary.org/wiki/%E7%B1%A0#Japanese) | a cage | kago · noun |
| [紐](https://en.wiktionary.org/wiki/%E7%B4%90#Japanese) | string, cord, laces | himo · noun |
| [絆](https://en.wiktionary.org/wiki/%E7%B5%86#Japanese) | a bond (emotional link or connection), tie | kizuna · noun |
| [羊](https://en.wiktionary.org/wiki/%E7%BE%8A#Japanese) | a sheep (animal) | hitsuji · noun |
| [鹿](https://en.wiktionary.org/wiki/%E9%B9%BF#Japanese) | deer | shika · noun |
| [む](https://en.wiktionary.org/wiki/%E3%82%80#Japanese) | A mumbling sound. | mu · intj |
| [侍](https://en.wiktionary.org/wiki/%E4%BE%8D#Japanese) | a servant | samurai · noun |
| [信](https://en.wiktionary.org/wiki/%E4%BF%A1#Japanese) | trust, faith | shin · noun |
| [将](https://en.wiktionary.org/wiki/%E5%B0%86#Japanese) | a commander | shō · noun |
| [巣](https://en.wiktionary.org/wiki/%E5%B7%A3#Japanese) | 巣, 栖, 窼: nest, hive, den | su · noun |
| [己](https://en.wiktionary.org/wiki/%E5%B7%B1#Japanese) | reflexive pronoun: oneself | onore · pron |
| [幻](https://en.wiktionary.org/wiki/%E5%B9%BB#Japanese) | an illusion, a phantom, a dream, a vision | maboroshi · noun |
| [枕](https://en.wiktionary.org/wiki/%E6%9E%95#Japanese) | pillow | makura · noun |
| [棚](https://en.wiktionary.org/wiki/%E6%A3%9A#Japanese) | shelf, ledge, rack, trellis | tana · noun |
| [残](https://en.wiktionary.org/wiki/%E6%AE%8B#Japanese) | the remainder; leftover; residue | zan · noun |
| [沙](https://en.wiktionary.org/wiki/%E6%B2%99#Japanese) | one hundred millionth (1 in 100,000,000) | sha · noun |
| [清](https://en.wiktionary.org/wiki/%E6%B8%85#Japanese) | brightly, clearly, vividly | saya · adv |
| [煙](https://en.wiktionary.org/wiki/%E7%85%99#Japanese) | smoke | kemuri · noun |
| [相撲](https://en.wiktionary.org/wiki/%E7%9B%B8%E6%92%B2#Japanese) | sumo (Japanese traditional wrestling) | sumō · noun |
| [育てる](https://en.wiktionary.org/wiki/%E8%82%B2%E3%81%A6%E3%82%8B#Japanese) | to raise, to rear, to foster, to bring up (children, animals, etc.) | sodateru · verb |
| [零](https://en.wiktionary.org/wiki/%E9%9B%B6#Japanese) | zero | rei · noun |
| [厨](https://en.wiktionary.org/wiki/%E5%8E%A8#Japanese) | kitchen | kuriya · noun |
| [枝](https://en.wiktionary.org/wiki/%E6%9E%9D#Japanese) | branch, limbs | eda · noun |
| [準](https://en.wiktionary.org/wiki/%E6%BA%96#Japanese) | water level (measuring instrument) | mizumori · noun |
| [禁](https://en.wiktionary.org/wiki/%E7%A6%81#Japanese) | ban, prohibition, forbiddance | kin · noun |
| [粉](https://en.wiktionary.org/wiki/%E7%B2%89#Japanese) | powder | ko · noun |
| [聖書](https://en.wiktionary.org/wiki/%E8%81%96%E6%9B%B8#Japanese) | a Bible | seisho · noun |
| [花粉](https://en.wiktionary.org/wiki/%E8%8A%B1%E7%B2%89#Japanese) | pollen | kafun · noun |
| [静](https://en.wiktionary.org/wiki/%E9%9D%99#Japanese) | stillness | sei · noun |
| [CPU](https://en.wiktionary.org/wiki/CPU#Japanese) | a CPU | shīpīyū · noun |
| [意](https://en.wiktionary.org/wiki/%E6%84%8F#Japanese) | thoughts; feelings | i · noun |
| [重力](https://en.wiktionary.org/wiki/%E9%87%8D%E5%8A%9B#Japanese) | gravity, gravitational force | jūryoku · noun |
| [題](https://en.wiktionary.org/wiki/%E9%A1%8C#Japanese) | title | dai · noun |

</details>

<details><summary>Words 901–950</summary>

![[Resources/Audio/ja/Words 0901-0950.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [FX](https://en.wiktionary.org/wiki/FX#Japanese) | foreign exchange; forex | efu-ekkusu · noun |
| [GPS](https://en.wiktionary.org/wiki/GPS#Japanese) | GPS | jī-pī-esu · noun |
| [効](https://en.wiktionary.org/wiki/%E5%8A%B9#Japanese) | efficacy, benefit, effect | kō · noun |
| [密](https://en.wiktionary.org/wiki/%E5%AF%86#Japanese) | something without breaks or openings, something dense | mitsu · noun |
| [弓](https://en.wiktionary.org/wiki/%E5%BC%93#Japanese) | a bow for shooting arrows | yumi · noun |
| [被](https://en.wiktionary.org/wiki/%E8%A2%AB#Japanese) | a covering | ōi · noun |
| [過](https://en.wiktionary.org/wiki/%E9%81%8E#Japanese) | fault; error; mistake | ka · noun |
| [中国人](https://en.wiktionary.org/wiki/%E4%B8%AD%E5%9B%BD%E4%BA%BA#Japanese) | a Chinese person | Chūgokujin · noun |
| [厳](https://en.wiktionary.org/wiki/%E5%8E%B3#Japanese) | strict, stern | gen · adj |
| [唇](https://en.wiktionary.org/wiki/%E5%94%87#Japanese) | lips | kuchibiru · noun |
| [岸](https://en.wiktionary.org/wiki/%E5%B2%B8#Japanese) | water's edge, bank, coast, shore | kishi · noun |
| [梨](https://en.wiktionary.org/wiki/%E6%A2%A8#Japanese) | a pear tree | nashi · noun |
| [江](https://en.wiktionary.org/wiki/%E6%B1%9F#Japanese) | inlet, bay | e · noun |
| [蓋](https://en.wiktionary.org/wiki/%E8%93%8B#Japanese) | lid; cap; cover; (malacology) operculum | futa · noun |
| [覚える](https://en.wiktionary.org/wiki/%E8%A6%9A%E3%81%88%E3%82%8B#Japanese) | 覚える, 憶える: to recall, to remember | oboeru · verb |
| [むら](https://en.wiktionary.org/wiki/%E3%82%80%E3%82%89#Japanese) | 群, 叢, 簇: gathering, grouping | mura · noun |
| [刑](https://en.wiktionary.org/wiki/%E5%88%91#Japanese) | punishment | kei · noun |
| [寮](https://en.wiktionary.org/wiki/%E5%AF%AE#Japanese) | dormitory, student accommodation, barracks | ryō · noun |
| [棟](https://en.wiktionary.org/wiki/%E6%A3%9F#Japanese) | ridge of a roof | mune · noun |
| [涼](https://en.wiktionary.org/wiki/%E6%B6%BC#Japanese) | cool breeze; refreshing coolness | ryō · noun |
| [鋼](https://en.wiktionary.org/wiki/%E9%8B%BC#Japanese) | steel (metal produced from iron) | hagane · noun |
| [令](https://en.wiktionary.org/wiki/%E4%BB%A4#Japanese) | an order, command, decree | rei · noun |
| [大学院](https://en.wiktionary.org/wiki/%E5%A4%A7%E5%AD%A6%E9%99%A2#Japanese) | graduate school | daigakuin · noun |
| [杉](https://en.wiktionary.org/wiki/%E6%9D%89#Japanese) | Japanese cedar (Cryptomeria japonica) | sugi · noun |
| [李](https://en.wiktionary.org/wiki/%E6%9D%8E#Japanese) | plum (Prunus salicina) | sumomo · noun |
| [滝](https://en.wiktionary.org/wiki/%E6%BB%9D#Japanese) | waterfall | taki · noun |
| [牙](https://en.wiktionary.org/wiki/%E7%89%99#Japanese) | fang, tusk, tooth (particularly the canines) | kiba · noun |
| [短](https://en.wiktionary.org/wiki/%E7%9F%AD#Japanese) | fault, weak point | tan · noun |
| [著](https://en.wiktionary.org/wiki/%E8%91%97#Japanese) | book | cho · noun |
| [蔵](https://en.wiktionary.org/wiki/%E8%94%B5#Japanese) | warehouse, storehouse | kura · noun |
| [難](https://en.wiktionary.org/wiki/%E9%9B%A3#Japanese) | difficulty | nan · noun |
| [丈](https://en.wiktionary.org/wiki/%E4%B8%88#Japanese) | jō, a traditional Japanese unit of length based on 10 shaku, standardized as equal to 3+¹⁄₃₃ meters. | jō · noun |
| [卿](https://en.wiktionary.org/wiki/%E5%8D%BF#Japanese) | Sir, Lord | kyō · noun |
| [否](https://en.wiktionary.org/wiki/%E5%90%A6#Japanese) | no | hi · noun |
| [完](https://en.wiktionary.org/wiki/%E5%AE%8C#Japanese) | the end; finis (used at the end of a novel, movie, etc.) | kan · noun |
| [尺](https://en.wiktionary.org/wiki/%E5%B0%BA#Japanese) | the shaku, "metal shaku", or Japanese foot: a traditional Japanese unit of length equal to 10 sun (寸) or ¹⁄₁₀ jō (丈), standardized as ¹⁰⁄₃₃ of a meter | shaku · noun |
| [注](https://en.wiktionary.org/wiki/%E6%B3%A8#Japanese) | annotation, note | chū · noun |
| [煮](https://en.wiktionary.org/wiki/%E7%85%AE#Japanese) | imperfective and stem (or continuative) forms of 煮る (niru) | ni · verb |
| [瓶](https://en.wiktionary.org/wiki/%E7%93%B6#Japanese) | bottle, jug, or jar made from glass, pottery, or ceramic | bin · noun |
| [蛇](https://en.wiktionary.org/wiki/%E8%9B%87#Japanese) | a snake, serpent | hebi · noun |
| [露](https://en.wiktionary.org/wiki/%E9%9C%B2#Japanese) | dew, dewdrop | tsuyu · noun |
| [夕](https://en.wiktionary.org/wiki/%E5%A4%95#Japanese) | evening | yū · noun |
| [富](https://en.wiktionary.org/wiki/%E5%AF%8C#Japanese) | wealth; fortune | tomi · noun |
| [常](https://en.wiktionary.org/wiki/%E5%B8%B8#Japanese) | a traditional Japanese unit of length, equal to one 丈(じょう) (jō, roughly three meters) and three 尺(しゃく) (shaku, roughly one foot or thirty centimeters) | jō · noun |
| [微](https://en.wiktionary.org/wiki/%E5%BE%AE#Japanese) | tiny | bi · adj |
| [沢](https://en.wiktionary.org/wiki/%E6%B2%A2#Japanese) | a mountain stream; a stream near its headwaters | sawa · noun |
| [経つ](https://en.wiktionary.org/wiki/%E7%B5%8C%E3%81%A4#Japanese) | to pass | tatsu · verb |
| [膜](https://en.wiktionary.org/wiki/%E8%86%9C#Japanese) | membrane; film | maku · noun |
| [陰](https://en.wiktionary.org/wiki/%E9%99%B0#Japanese) | shadow, shade | kage · noun |
| [陸](https://en.wiktionary.org/wiki/%E9%99%B8#Japanese) | flat, not steep | roku · adj |

</details>

<details><summary>Words 951–1000</summary>

![[Resources/Audio/ja/Words 0951-1000.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [餅](https://en.wiktionary.org/wiki/%E9%A4%85#Japanese) | mochi (Japanese rice cake made from glutinous rice, usually mixed with other ingredients) | mochi · noun |
| [忍者](https://en.wiktionary.org/wiki/%E5%BF%8D%E8%80%85#Japanese) | a ninja (person trained in stealth, espionage, assassination and ninjutsu) | ninja · noun |
| [穂](https://en.wiktionary.org/wiki/%E7%A9%82#Japanese) | ear of grain, head of grain | ho · noun |
| [菅](https://en.wiktionary.org/wiki/%E8%8F%85#Japanese) | a sedge | suge · noun |
| [蒼](https://en.wiktionary.org/wiki/%E8%92%BC#Japanese) | blue | ao · noun |
| [鯖](https://en.wiktionary.org/wiki/%E9%AF%96#Japanese) | mackerel, especially chub mackerel (Scomber japonicus) | saba · noun |
| [害](https://en.wiktionary.org/wiki/%E5%AE%B3#Japanese) | injury, harm, damage | gai · noun |
| [尿](https://en.wiktionary.org/wiki/%E5%B0%BF#Japanese) | urine | nyō · noun |
| [止まる](https://en.wiktionary.org/wiki/%E6%AD%A2%E3%81%BE%E3%82%8B#Japanese) | to stop, to be stopped | tomaru · verb |
| [津波](https://en.wiktionary.org/wiki/%E6%B4%A5%E6%B3%A2#Japanese) | a tsunami, a tidal wave | tsunami · noun |
| [灰](https://en.wiktionary.org/wiki/%E7%81%B0#Japanese) | ash | hai · noun |
| [辻](https://en.wiktionary.org/wiki/%E8%BE%BB#Japanese) | a crossroad, intersection | tsuji · noun |
| [弦](https://en.wiktionary.org/wiki/%E5%BC%A6#Japanese) | string of a stringed instrument | gen · noun |
| [筆](https://en.wiktionary.org/wiki/%E7%AD%86#Japanese) | a writing brush, a painting brush, a pen | fude · noun |
| [辞める](https://en.wiktionary.org/wiki/%E8%BE%9E%E3%82%81%E3%82%8B#Japanese) | to resign, to quit | yameru · verb |
| [雅](https://en.wiktionary.org/wiki/%E9%9B%85#Japanese) | elegant | ga · adj |
| [顎](https://en.wiktionary.org/wiki/%E9%A1%8E#Japanese) | jaw | ago · noun |
| [卓球](https://en.wiktionary.org/wiki/%E5%8D%93%E7%90%83#Japanese) | table tennis | takkyū · noun |
| [寿](https://en.wiktionary.org/wiki/%E5%AF%BF#Japanese) | years of age | ju · noun |
| [旬](https://en.wiktionary.org/wiki/%E6%97%AC#Japanese) | Season (of something, as in "in season"). | shun · noun |
| [潮](https://en.wiktionary.org/wiki/%E6%BD%AE#Japanese) | a (morning) tide | shio · noun |
| [義](https://en.wiktionary.org/wiki/%E7%BE%A9#Japanese) | justice; a situation which has a right and proper reason | gi · noun |
| [葵](https://en.wiktionary.org/wiki/%E8%91%B5#Japanese) | synonym of 葵 (aoi): plant name | ki · noun |
| [鷹](https://en.wiktionary.org/wiki/%E9%B7%B9#Japanese) | a hawk (predatory bird) | taka · noun |
| [CV](https://en.wiktionary.org/wiki/CV#Japanese) | synonym of 声優 (seiyū, “voice actor, character voice performer”) | shībui · noun |
| [LED](https://en.wiktionary.org/wiki/LED#Japanese) | LED (light-emitting diode) | eruīdī · noun |
| [恩](https://en.wiktionary.org/wiki/%E6%81%A9#Japanese) | obligation | on · noun |
| [殻](https://en.wiktionary.org/wiki/%E6%AE%BB#Japanese) | shell, crust, chaff | kara · noun |
| [浜](https://en.wiktionary.org/wiki/%E6%B5%9C#Japanese) | beach, seashore | hama · noun |
| [琴](https://en.wiktionary.org/wiki/%E7%90%B4#Japanese) | koto: a Japanese zither derived from the Chinese guzheng | koto · noun |
| [腸](https://en.wiktionary.org/wiki/%E8%85%B8#Japanese) | the intestines | wata · noun |
| [パッド](https://en.wiktionary.org/wiki/%E3%83%91%E3%83%83%E3%83%89#Japanese) | pad (flattened mass of anything soft) | paddo · noun |
| [善](https://en.wiktionary.org/wiki/%E5%96%84#Japanese) | good, good deed | zen · noun |
| [更](https://en.wiktionary.org/wiki/%E6%9B%B4#Japanese) | one of the five two-hour periods into which the night was divided in ancient China | kō · noun |
| [泡](https://en.wiktionary.org/wiki/%E6%B3%A1#Japanese) | bubble | awa · noun |
| [鎖](https://en.wiktionary.org/wiki/%E9%8E%96#Japanese) | a chain | kusari · noun |
| [霧](https://en.wiktionary.org/wiki/%E9%9C%A7#Japanese) | mist, fog | kiri · noun |
| [唯](https://en.wiktionary.org/wiki/%E5%94%AF#Japanese) | polite particle used to respond to elders: yes | i · intj |
| [果](https://en.wiktionary.org/wiki/%E6%9E%9C#Japanese) | fruit | ka · noun |
| [蝶](https://en.wiktionary.org/wiki/%E8%9D%B6#Japanese) | a butterfly (insect) | chō · noun |
| [辞書](https://en.wiktionary.org/wiki/%E8%BE%9E%E6%9B%B8#Japanese) | a dictionary (publication that explains the meanings of an ordered list of words) | jisho · noun |
| [ABC](https://en.wiktionary.org/wiki/ABC#Japanese) | ABC(s) (alphabet) | ēbīshī · noun |
| [圧](https://en.wiktionary.org/wiki/%E5%9C%A7#Japanese) | pressure | atsu · noun |
| [湾](https://en.wiktionary.org/wiki/%E6%B9%BE#Japanese) | bay, gulf, inlet | wan · noun |
| [益](https://en.wiktionary.org/wiki/%E7%9B%8A#Japanese) | benefit | eki · noun |
| [芝](https://en.wiktionary.org/wiki/%E8%8A%9D#Japanese) | grass, turf, green | shiba · noun |
| [銭](https://en.wiktionary.org/wiki/%E9%8A%AD#Japanese) | a round coin with a square hole in the middle | zeni · noun |
| [ATM](https://en.wiktionary.org/wiki/ATM#Japanese) | ATM, cash machine | ētīemu · noun |
| [日産](https://en.wiktionary.org/wiki/%E6%97%A5%E7%94%A3#Japanese) | daily product | nissan · noun |
| [木曜日](https://en.wiktionary.org/wiki/%E6%9C%A8%E6%9B%9C%E6%97%A5#Japanese) | Thursday | mokuyōbi · noun |

</details>

## Question bank

Try before opening the answers. Different tasks use the same sentence to practise complementary skills. Open translation and explanation tasks can have valid alternatives.

### Topic は · 50 questions

**ja-Q0001 · Fill the gap**

彼女____無邪気なふりをした。

She pretended innocence.

[[Japanese#^ja-Q0001-answer|Compare the answer]]
^ja-Q0001

**ja-Q0002 · Choose the form**

彼女____無邪気なふりをした。

She pretended innocence.

Choices: を / は / が / に

[[Japanese#^ja-Q0002-answer|Compare the answer]]
^ja-Q0002

**ja-Q0003 · Edit the changed sentence**

私【が】息子に芝生に水を撒かせた。

I had my son water the lawn.

[[Japanese#^ja-Q0003-answer|Compare the answer]]
^ja-Q0003

**ja-Q0004 · Build the sentence**

Arrange: は / 息子に芝生に水を撒かせた。 / 私

I had my son water the lawn.

[[Japanese#^ja-Q0004-answer|Compare the answer]]
^ja-Q0004

**ja-Q0005 · Write a translation**

Write this in Japanese: They went to church on Christmas Eve.

[[Japanese#^ja-Q0005-answer|Compare the answer]]
^ja-Q0005

**ja-Q0006 · Explain the grammar**

彼ら【は】クリスマスイブに教会に行った。

They went to church on Christmas Eve.

[[Japanese#^ja-Q0006-answer|Compare the answer]]
^ja-Q0006

**ja-Q0007 · Fill the gap**

年とともに、情熱____弱まり、習慣は強くなる。

Passions weaken, but habits strengthen, with age.

[[Japanese#^ja-Q0007-answer|Compare the answer]]
^ja-Q0007

**ja-Q0008 · Choose the form**

年とともに、情熱____弱まり、習慣は強くなる。

Passions weaken, but habits strengthen, with age.

Choices: に / は / を / が

[[Japanese#^ja-Q0008-answer|Compare the answer]]
^ja-Q0008

**ja-Q0009 · Edit the changed sentence**

その女性【が】悲しげで、その上疲れているようだった。

The lady looked sad, also tired.

[[Japanese#^ja-Q0009-answer|Compare the answer]]
^ja-Q0009

**ja-Q0010 · Build the sentence**

Arrange: は / 悲しげで、その上疲れているようだった。 / その女性

The lady looked sad, also tired.

[[Japanese#^ja-Q0010-answer|Compare the answer]]
^ja-Q0010

**ja-Q0011 · Write a translation**

Write this in Japanese: How much is the annual membership fee?

[[Japanese#^ja-Q0011-answer|Compare the answer]]
^ja-Q0011

**ja-Q0012 · Explain the grammar**

年会費【は】いくらですか。

How much is the annual membership fee?

[[Japanese#^ja-Q0012-answer|Compare the answer]]
^ja-Q0012

**ja-Q0013 · Fill the gap**

彼____何らかの解決策を提案しましたか。

Did he propose any solutions?

[[Japanese#^ja-Q0013-answer|Compare the answer]]
^ja-Q0013

**ja-Q0014 · Choose the form**

彼____何らかの解決策を提案しましたか。

Did he propose any solutions?

Choices: に / を / が / は

[[Japanese#^ja-Q0014-answer|Compare the answer]]
^ja-Q0014

**ja-Q0015 · Edit the changed sentence**

彼がもう少し注意していれば、事故【が】防げたろうに。

If he had been a little more careful, the accident would have been avoided.

[[Japanese#^ja-Q0015-answer|Compare the answer]]
^ja-Q0015

**ja-Q0016 · Build the sentence**

Arrange: は / 防げたろうに。 / 彼がもう少し注意していれば、事故

If he had been a little more careful, the accident would have been avoided.

[[Japanese#^ja-Q0016-answer|Compare the answer]]
^ja-Q0016

**ja-Q0017 · Write a translation**

Write this in Japanese: The best way to write letters is to put down whatever is in your mind.

[[Japanese#^ja-Q0017-answer|Compare the answer]]
^ja-Q0017

**ja-Q0018 · Explain the grammar**

手紙を書く際の最善の方法【は】、心にあることを何でも書き留めることだ。

The best way to write letters is to put down whatever is in your mind.

[[Japanese#^ja-Q0018-answer|Compare the answer]]
^ja-Q0018

**ja-Q0019 · Fill the gap**

彼女の息子____交通事故で死んだ。

Her son was killed in a traffic accident.

[[Japanese#^ja-Q0019-answer|Compare the answer]]
^ja-Q0019

**ja-Q0020 · Choose the form**

彼女の息子____交通事故で死んだ。

Her son was killed in a traffic accident.

Choices: は / が / を / に

[[Japanese#^ja-Q0020-answer|Compare the answer]]
^ja-Q0020

**ja-Q0021 · Edit the changed sentence**

このピアノを弾いてもいいが、夜【が】だめだ。

You can play this piano, but not at night.

[[Japanese#^ja-Q0021-answer|Compare the answer]]
^ja-Q0021

**ja-Q0022 · Build the sentence**

Arrange: このピアノを弾いてもいいが、夜 / だめだ。 / は

You can play this piano, but not at night.

[[Japanese#^ja-Q0022-answer|Compare the answer]]
^ja-Q0022

**ja-Q0023 · Write a translation**

Write this in Japanese: That goes against my beliefs.

[[Japanese#^ja-Q0023-answer|Compare the answer]]
^ja-Q0023

**ja-Q0024 · Explain the grammar**

それ【は】私の信念には合わない。

That goes against my beliefs.

[[Japanese#^ja-Q0024-answer|Compare the answer]]
^ja-Q0024

**ja-Q0025 · Fill the gap**

私____自身の部屋がほしい。

I want to have my own room.

[[Japanese#^ja-Q0025-answer|Compare the answer]]
^ja-Q0025

**ja-Q0026 · Choose the form**

私____自身の部屋がほしい。

I want to have my own room.

Choices: は / を / が / に

[[Japanese#^ja-Q0026-answer|Compare the answer]]
^ja-Q0026

**ja-Q0027 · Edit the changed sentence**

この制度に【が】改良の余地がない。

There is no room for further improvement in this system.

[[Japanese#^ja-Q0027-answer|Compare the answer]]
^ja-Q0027

**ja-Q0028 · Build the sentence**

Arrange: 改良の余地がない。 / この制度に / は

There is no room for further improvement in this system.

[[Japanese#^ja-Q0028-answer|Compare the answer]]
^ja-Q0028

**ja-Q0029 · Write a translation**

Write this in Japanese: My brother in Kyoto became a teacher.

[[Japanese#^ja-Q0029-answer|Compare the answer]]
^ja-Q0029

**ja-Q0030 · Explain the grammar**

京都にいる私の兄【は】先生になった。

My brother in Kyoto became a teacher.

[[Japanese#^ja-Q0030-answer|Compare the answer]]
^ja-Q0030

**ja-Q0031 · Fill the gap**

私の兄____電車の中でスリにあった。

My brother had his pocket picked in the train.

[[Japanese#^ja-Q0031-answer|Compare the answer]]
^ja-Q0031

**ja-Q0032 · Choose the form**

私の兄____電車の中でスリにあった。

My brother had his pocket picked in the train.

Choices: に / を / は / が

[[Japanese#^ja-Q0032-answer|Compare the answer]]
^ja-Q0032

**ja-Q0033 · Edit the changed sentence**

写真を撮るために【が】、このボタンを押しさえすればよい。

All you have to do to take a picture is push this button.

[[Japanese#^ja-Q0033-answer|Compare the answer]]
^ja-Q0033

**ja-Q0034 · Build the sentence**

Arrange: 、このボタンを押しさえすればよい。 / 写真を撮るために / は

All you have to do to take a picture is push this button.

[[Japanese#^ja-Q0034-answer|Compare the answer]]
^ja-Q0034

**ja-Q0035 · Write a translation**

Write this in Japanese: Human pride is human weakness.

[[Japanese#^ja-Q0035-answer|Compare the answer]]
^ja-Q0035

**ja-Q0036 · Explain the grammar**

驕傲【は】人間の弱さである。

Human pride is human weakness.

[[Japanese#^ja-Q0036-answer|Compare the answer]]
^ja-Q0036

**ja-Q0037 · Fill the gap**

彼女____エイミーと呼ばれている。

She goes by the name of Amy.

[[Japanese#^ja-Q0037-answer|Compare the answer]]
^ja-Q0037

**ja-Q0038 · Choose the form**

彼女____エイミーと呼ばれている。

She goes by the name of Amy.

Choices: を / に / は / が

[[Japanese#^ja-Q0038-answer|Compare the answer]]
^ja-Q0038

**ja-Q0039 · Edit the changed sentence**

品物【が】良好な状態で到着した。

The goods arrived in good condition.

[[Japanese#^ja-Q0039-answer|Compare the answer]]
^ja-Q0039

**ja-Q0040 · Build the sentence**

Arrange: 品物 / 良好な状態で到着した。 / は

The goods arrived in good condition.

[[Japanese#^ja-Q0040-answer|Compare the answer]]
^ja-Q0040

**ja-Q0041 · Write a translation**

Write this in Japanese: I think she will succeed as a lawyer.

[[Japanese#^ja-Q0041-answer|Compare the answer]]
^ja-Q0041

**ja-Q0042 · Explain the grammar**

彼女【は】弁護士として成功するだろうと思う。

I think she will succeed as a lawyer.

[[Japanese#^ja-Q0042-answer|Compare the answer]]
^ja-Q0042

**ja-Q0043 · Fill the gap**

トム____周囲を見回したが、誰の姿も見なかった。

Tom looked around, but saw no one.

[[Japanese#^ja-Q0043-answer|Compare the answer]]
^ja-Q0043

**ja-Q0044 · Choose the form**

トム____周囲を見回したが、誰の姿も見なかった。

Tom looked around, but saw no one.

Choices: は / を / に / が

[[Japanese#^ja-Q0044-answer|Compare the answer]]
^ja-Q0044

**ja-Q0045 · Edit the changed sentence**

私【が】あなたにその歌をうたってもらいたい。

I want you to sing the song.

[[Japanese#^ja-Q0045-answer|Compare the answer]]
^ja-Q0045

**ja-Q0046 · Build the sentence**

Arrange: は / 私 / あなたにその歌をうたってもらいたい。

I want you to sing the song.

[[Japanese#^ja-Q0046-answer|Compare the answer]]
^ja-Q0046

**ja-Q0047 · Write a translation**

Write this in Japanese: He regained consciousness in the hospital.

[[Japanese#^ja-Q0047-answer|Compare the answer]]
^ja-Q0047

**ja-Q0048 · Explain the grammar**

彼【は】病院で意識を回復した。

He regained consciousness in the hospital.

[[Japanese#^ja-Q0048-answer|Compare the answer]]
^ja-Q0048

**ja-Q0049 · Fill the gap**

なんでここにトム____いてメアリーはいないの?

Why is Tom here and not Mary?

[[Japanese#^ja-Q0049-answer|Compare the answer]]
^ja-Q0049

**ja-Q0050 · Choose the form**

なんでここにトム____いてメアリーはいないの?

Why is Tom here and not Mary?

Choices: が / は / を / に

[[Japanese#^ja-Q0050-answer|Compare the answer]]
^ja-Q0050


### Subject and focus が · 50 questions

**ja-Q0051 · Edit the changed sentence**

怒鳴りつけたかった【は】思いとどまった。

He was about to explode, but checked himself.

[[Japanese#^ja-Q0051-answer|Compare the answer]]
^ja-Q0051

**ja-Q0052 · Build the sentence**

Arrange: が / 怒鳴りつけたかった / 思いとどまった。

He was about to explode, but checked himself.

[[Japanese#^ja-Q0052-answer|Compare the answer]]
^ja-Q0052

**ja-Q0053 · Write a translation**

Write this in Japanese: There are many interesting animals in Australia.

[[Japanese#^ja-Q0053-answer|Compare the answer]]
^ja-Q0053

**ja-Q0054 · Explain the grammar**

オーストラリアには多くのおもしろい動物【が】いる。

There are many interesting animals in Australia.

[[Japanese#^ja-Q0054-answer|Compare the answer]]
^ja-Q0054

**ja-Q0055 · Fill the gap**

仕事もたい____い片付いた。

Almost all the work is done now.

[[Japanese#^ja-Q0055-answer|Compare the answer]]
^ja-Q0055

**ja-Q0056 · Choose the form**

仕事もたい____い片付いた。

Almost all the work is done now.

Choices: が / は / を / に

[[Japanese#^ja-Q0056-answer|Compare the answer]]
^ja-Q0056

**ja-Q0057 · Edit the changed sentence**

太陽【は】なければ、我々は生きてゆけないだろう。

If it were not for the sun, we could not live at all.

[[Japanese#^ja-Q0057-answer|Compare the answer]]
^ja-Q0057

**ja-Q0058 · Build the sentence**

Arrange: が / なければ、我々は生きてゆけないだろう。 / 太陽

If it were not for the sun, we could not live at all.

[[Japanese#^ja-Q0058-answer|Compare the answer]]
^ja-Q0058

**ja-Q0059 · Write a translation**

Write this in Japanese: No one can tell what'll happen in the future.

[[Japanese#^ja-Q0059-answer|Compare the answer]]
^ja-Q0059

**ja-Q0060 · Explain the grammar**

これから先何【が】起きるかだれも分からない。

No one can tell what'll happen in the future.

[[Japanese#^ja-Q0060-answer|Compare the answer]]
^ja-Q0060

**ja-Q0061 · Fill the gap**

先生は私____東大に入る可能性について非常に率直だった。

The teacher was quite candid about my chances of entering Tokyo University.

[[Japanese#^ja-Q0061-answer|Compare the answer]]
^ja-Q0061

**ja-Q0062 · Choose the form**

先生は私____東大に入る可能性について非常に率直だった。

The teacher was quite candid about my chances of entering Tokyo University.

Choices: は / が / に / を

[[Japanese#^ja-Q0062-answer|Compare the answer]]
^ja-Q0062

**ja-Q0063 · Edit the changed sentence**

僕の友達はみなサッカー【は】好きだ。

All of my friends like soccer.

[[Japanese#^ja-Q0063-answer|Compare the answer]]
^ja-Q0063

**ja-Q0064 · Build the sentence**

Arrange: が / 僕の友達はみなサッカー / 好きだ。

All of my friends like soccer.

[[Japanese#^ja-Q0064-answer|Compare the answer]]
^ja-Q0064

**ja-Q0065 · Write a translation**

Write this in Japanese: It was foggy, so it was hard to make out the figures of people walking.

[[Japanese#^ja-Q0065-answer|Compare the answer]]
^ja-Q0065

**ja-Q0066 · Explain the grammar**

霧【が】深かったので、歩いている人たちの姿を似分けるのは困難だった。

It was foggy, so it was hard to make out the figures of people walking.

[[Japanese#^ja-Q0066-answer|Compare the answer]]
^ja-Q0066

**ja-Q0067 · Fill the gap**

そういうわけで彼らは世界中の彼らの道をみつけること____できるのです。

This is why they can find their way around the world.

[[Japanese#^ja-Q0067-answer|Compare the answer]]
^ja-Q0067

**ja-Q0068 · Choose the form**

そういうわけで彼らは世界中の彼らの道をみつけること____できるのです。

This is why they can find their way around the world.

Choices: に / が / を / は

[[Japanese#^ja-Q0068-answer|Compare the answer]]
^ja-Q0068

**ja-Q0069 · Edit the changed sentence**

実は、その出来事【は】新聞に載らなかったのは、たった一人の目撃者を除いては誰ひとりとしてそのことを知っている者はなかった――という極く簡単な事情に原因しているのである。

In truth, the very simple reason why this incident did not appear in the newspapers is that, outside of a single witness, no one knew about it.

[[Japanese#^ja-Q0069-answer|Compare the answer]]
^ja-Q0069

**ja-Q0070 · Build the sentence**

Arrange: 実は、その出来事 / 新聞に載らなかったのは、たった一人の目撃者を除いては誰ひとりとしてそのことを知っている者はなかった――という極く簡単な事情に原因しているのである。 / が

In truth, the very simple reason why this incident did not appear in the newspapers is that, outside of a single witness, no one knew about it.

[[Japanese#^ja-Q0070-answer|Compare the answer]]
^ja-Q0070

**ja-Q0071 · Write a translation**

Write this in Japanese: I think Tom's grandmother is too old to wear a miniskirt.

[[Japanese#^ja-Q0071-answer|Compare the answer]]
^ja-Q0071

**ja-Q0072 · Explain the grammar**

トムのおばあちゃん【が】ミニスカートをはくには歳を取り過ぎていると思う。

I think Tom's grandmother is too old to wear a miniskirt.

[[Japanese#^ja-Q0072-answer|Compare the answer]]
^ja-Q0072

**ja-Q0073 · Fill the gap**

土着のアメリカ・インディアン____政府から不当な扱いを受けたと主張するのは歴史的にみて当然の権利である。

American Indians have a fair historical right to claim they got a raw deal from the government.

[[Japanese#^ja-Q0073-answer|Compare the answer]]
^ja-Q0073

**ja-Q0074 · Choose the form**

土着のアメリカ・インディアン____政府から不当な扱いを受けたと主張するのは歴史的にみて当然の権利である。

American Indians have a fair historical right to claim they got a raw deal from the government.

Choices: は / に / が / を

[[Japanese#^ja-Q0074-answer|Compare the answer]]
^ja-Q0074

**ja-Q0075 · Edit the changed sentence**

赤ちゃん【は】ミルクを欲しがって泣き出した。

My baby began crying, asking for milk.

[[Japanese#^ja-Q0075-answer|Compare the answer]]
^ja-Q0075

**ja-Q0076 · Build the sentence**

Arrange: が / ミルクを欲しがって泣き出した。 / 赤ちゃん

My baby began crying, asking for milk.

[[Japanese#^ja-Q0076-answer|Compare the answer]]
^ja-Q0076

**ja-Q0077 · Write a translation**

Write this in Japanese: If we hang tight, I'm sure we can make it through these bad times.

[[Japanese#^ja-Q0077-answer|Compare the answer]]
^ja-Q0077

**ja-Q0078 · Explain the grammar**

我々【が】手に手を取って一致団結すれば、きっとこの不況の時代も乗り切れるだろう。

If we hang tight, I'm sure we can make it through these bad times.

[[Japanese#^ja-Q0078-answer|Compare the answer]]
^ja-Q0078

**ja-Q0079 · Fill the gap**

ひとりでその仕事をやりとげること____できないから、彼は援助を求めて私をたよった。

Unable to accomplish the task by himself, he turned to me for help.

[[Japanese#^ja-Q0079-answer|Compare the answer]]
^ja-Q0079

**ja-Q0080 · Choose the form**

ひとりでその仕事をやりとげること____できないから、彼は援助を求めて私をたよった。

Unable to accomplish the task by himself, he turned to me for help.

Choices: が / を / に / は

[[Japanese#^ja-Q0080-answer|Compare the answer]]
^ja-Q0080

**ja-Q0081 · Edit the changed sentence**

今日では、パスポートには写真【は】なければならない。

Today, you must have a photograph in your passport.

[[Japanese#^ja-Q0081-answer|Compare the answer]]
^ja-Q0081

**ja-Q0082 · Build the sentence**

Arrange: なければならない。 / 今日では、パスポートには写真 / が

Today, you must have a photograph in your passport.

[[Japanese#^ja-Q0082-answer|Compare the answer]]
^ja-Q0082

**ja-Q0083 · Write a translation**

Write this in Japanese: Despite all his faults, everybody likes him.

[[Japanese#^ja-Q0083-answer|Compare the answer]]
^ja-Q0083

**ja-Q0084 · Explain the grammar**

欠点【が】あるにもかかわらず、だれもが彼を好きだ。

Despite all his faults, everybody likes him.

[[Japanese#^ja-Q0084-answer|Compare the answer]]
^ja-Q0084

**ja-Q0085 · Fill the gap**

世界中の多くの人____、食料不安を肌で感じています。

Many people around the world experience food insecurity.

[[Japanese#^ja-Q0085-answer|Compare the answer]]
^ja-Q0085

**ja-Q0086 · Choose the form**

世界中の多くの人____、食料不安を肌で感じています。

Many people around the world experience food insecurity.

Choices: を / は / に / が

[[Japanese#^ja-Q0086-answer|Compare the answer]]
^ja-Q0086

**ja-Q0087 · Edit the changed sentence**

英語は読めます【は】話せません。

I can read English, but I can't speak it.

[[Japanese#^ja-Q0087-answer|Compare the answer]]
^ja-Q0087

**ja-Q0088 · Build the sentence**

Arrange: が / 英語は読めます / 話せません。

I can read English, but I can't speak it.

[[Japanese#^ja-Q0088-answer|Compare the answer]]
^ja-Q0088

**ja-Q0089 · Write a translation**

Write this in Japanese: The campers were hard up for water because their well had run dry.

[[Japanese#^ja-Q0089-answer|Compare the answer]]
^ja-Q0089

**ja-Q0090 · Explain the grammar**

使っていた井戸【が】干上がったので、キャンプをしていた人は水に困ってしまった。

The campers were hard up for water because their well had run dry.

[[Japanese#^ja-Q0090-answer|Compare the answer]]
^ja-Q0090

**ja-Q0091 · Fill the gap**

仕様、価格は変更すること____あります。

Specifications and price are subject to change.

[[Japanese#^ja-Q0091-answer|Compare the answer]]
^ja-Q0091

**ja-Q0092 · Choose the form**

仕様、価格は変更すること____あります。

Specifications and price are subject to change.

Choices: が / に / は / を

[[Japanese#^ja-Q0092-answer|Compare the answer]]
^ja-Q0092

**ja-Q0093 · Edit the changed sentence**

君はどうして目【は】覚めたんだ？

What woke you up?

[[Japanese#^ja-Q0093-answer|Compare the answer]]
^ja-Q0093

**ja-Q0094 · Build the sentence**

Arrange: 君はどうして目 / 覚めたんだ？ / が

What woke you up?

[[Japanese#^ja-Q0094-answer|Compare the answer]]
^ja-Q0094

**ja-Q0095 · Write a translation**

Write this in Japanese: Any input would be appreciated!

[[Japanese#^ja-Q0095-answer|Compare the answer]]
^ja-Q0095

**ja-Q0096 · Explain the grammar**

どんなインプットでもいただければあり【が】たいです。

Any input would be appreciated!

[[Japanese#^ja-Q0096-answer|Compare the answer]]
^ja-Q0096

**ja-Q0097 · Fill the gap**

落石____道路をふさいだ。

Fallen rocks closed the way.

[[Japanese#^ja-Q0097-answer|Compare the answer]]
^ja-Q0097

**ja-Q0098 · Choose the form**

落石____道路をふさいだ。

Fallen rocks closed the way.

Choices: に / は / が / を

[[Japanese#^ja-Q0098-answer|Compare the answer]]
^ja-Q0098

**ja-Q0099 · Edit the changed sentence**

私はしなければならない仕事【は】たくさんあります。

I have a lot of work to do.

[[Japanese#^ja-Q0099-answer|Compare the answer]]
^ja-Q0099

**ja-Q0100 · Build the sentence**

Arrange: 私はしなければならない仕事 / たくさんあります。 / が

I have a lot of work to do.

[[Japanese#^ja-Q0100-answer|Compare the answer]]
^ja-Q0100


### Object を · 50 questions

**ja-Q0101 · Write a translation**

Write this in Japanese: While they are away, let's take care of their cat.

[[Japanese#^ja-Q0101-answer|Compare the answer]]
^ja-Q0101

**ja-Q0102 · Explain the grammar**

お留守中の猫の世話【を】して上げましょう。

While they are away, let's take care of their cat.

[[Japanese#^ja-Q0102-answer|Compare the answer]]
^ja-Q0102

**ja-Q0103 · Fill the gap**

もっと時間____かけて発表を準備すべきだったと先生に言われた。

My teacher told me that I should have spent more time preparing my presentation.

[[Japanese#^ja-Q0103-answer|Compare the answer]]
^ja-Q0103

**ja-Q0104 · Choose the form**

もっと時間____かけて発表を準備すべきだったと先生に言われた。

My teacher told me that I should have spent more time preparing my presentation.

Choices: が / を / で / に

[[Japanese#^ja-Q0104-answer|Compare the answer]]
^ja-Q0104

**ja-Q0105 · Edit the changed sentence**

ちょっと顔【に】貸してくれませんか。

Can I have a few words with you?

[[Japanese#^ja-Q0105-answer|Compare the answer]]
^ja-Q0105

**ja-Q0106 · Build the sentence**

Arrange: ちょっと顔 / 貸してくれませんか。 / を

Can I have a few words with you?

[[Japanese#^ja-Q0106-answer|Compare the answer]]
^ja-Q0106

**ja-Q0107 · Write a translation**

Write this in Japanese: I read a newspaper every day so that I may keep up with the time.

[[Japanese#^ja-Q0107-answer|Compare the answer]]
^ja-Q0107

**ja-Q0108 · Explain the grammar**

私は時代に遅れないように、毎日新聞【を】読む。

I read a newspaper every day so that I may keep up with the time.

[[Japanese#^ja-Q0108-answer|Compare the answer]]
^ja-Q0108

**ja-Q0109 · Fill the gap**

彼の演奏は目____見張るものであった。

His performance was amazing.

[[Japanese#^ja-Q0109-answer|Compare the answer]]
^ja-Q0109

**ja-Q0110 · Choose the form**

彼の演奏は目____見張るものであった。

His performance was amazing.

Choices: を / で / が / に

[[Japanese#^ja-Q0110-answer|Compare the answer]]
^ja-Q0110

**ja-Q0111 · Edit the changed sentence**

彼は新生活【に】始めた。

He started a new life.

[[Japanese#^ja-Q0111-answer|Compare the answer]]
^ja-Q0111

**ja-Q0112 · Build the sentence**

Arrange: 始めた。 / を / 彼は新生活

He started a new life.

[[Japanese#^ja-Q0112-answer|Compare the answer]]
^ja-Q0112

**ja-Q0113 · Write a translation**

Write this in Japanese: Three were sentenced to life in prison.

[[Japanese#^ja-Q0113-answer|Compare the answer]]
^ja-Q0113

**ja-Q0114 · Explain the grammar**

三人は終身刑【を】科せられた。

Three were sentenced to life in prison.

[[Japanese#^ja-Q0114-answer|Compare the answer]]
^ja-Q0114

**ja-Q0115 · Fill the gap**

彼____見るとすぐに私には病気だとわかった。

The instant I saw him, I knew he was ill.

[[Japanese#^ja-Q0115-answer|Compare the answer]]
^ja-Q0115

**ja-Q0116 · Choose the form**

彼____見るとすぐに私には病気だとわかった。

The instant I saw him, I knew he was ill.

Choices: で / が / に / を

[[Japanese#^ja-Q0116-answer|Compare the answer]]
^ja-Q0116

**ja-Q0117 · Edit the changed sentence**

あのＥメール【に】送るべきじゃなかった。

I shouldn't have sent that email.

[[Japanese#^ja-Q0117-answer|Compare the answer]]
^ja-Q0117

**ja-Q0118 · Build the sentence**

Arrange: 送るべきじゃなかった。 / を / あのＥメール

I shouldn't have sent that email.

[[Japanese#^ja-Q0118-answer|Compare the answer]]
^ja-Q0118

**ja-Q0119 · Write a translation**

Write this in Japanese: If not confidently, at least hopefully.

[[Japanese#^ja-Q0119-answer|Compare the answer]]
^ja-Q0119

**ja-Q0120 · Explain the grammar**

たとえ自信【を】持ってないにせよ少なくとも希望を持って。

If not confidently, at least hopefully.

[[Japanese#^ja-Q0120-answer|Compare the answer]]
^ja-Q0120

**ja-Q0121 · Fill the gap**

私はもうあの医者____信用しない。

I have lost faith in the doctor.

[[Japanese#^ja-Q0121-answer|Compare the answer]]
^ja-Q0121

**ja-Q0122 · Choose the form**

私はもうあの医者____信用しない。

I have lost faith in the doctor.

Choices: が / を / に / で

[[Japanese#^ja-Q0122-answer|Compare the answer]]
^ja-Q0122

**ja-Q0123 · Edit the changed sentence**

アメリカは１７７６年に独立【に】宣言したと彼は言った。

He said that America declared its independence in 1776.

[[Japanese#^ja-Q0123-answer|Compare the answer]]
^ja-Q0123

**ja-Q0124 · Build the sentence**

Arrange: アメリカは１７７６年に独立 / 宣言したと彼は言った。 / を

He said that America declared its independence in 1776.

[[Japanese#^ja-Q0124-answer|Compare the answer]]
^ja-Q0124

**ja-Q0125 · Write a translation**

Write this in Japanese: Choose either one or the other.

[[Japanese#^ja-Q0125-answer|Compare the answer]]
^ja-Q0125

**ja-Q0126 · Explain the grammar**

２つのうちどちらか【を】選びなさい。

Choose either one or the other.

[[Japanese#^ja-Q0126-answer|Compare the answer]]
^ja-Q0126

**ja-Q0127 · Fill the gap**

デイリー・ニュース____買いました。

I bought a Daily News.

[[Japanese#^ja-Q0127-answer|Compare the answer]]
^ja-Q0127

**ja-Q0128 · Choose the form**

デイリー・ニュース____買いました。

I bought a Daily News.

Choices: を / で / に / が

[[Japanese#^ja-Q0128-answer|Compare the answer]]
^ja-Q0128

**ja-Q0129 · Edit the changed sentence**

私たちはきわめて慎重に調査【に】行なった。

We conducted our investigation with the greatest care.

[[Japanese#^ja-Q0129-answer|Compare the answer]]
^ja-Q0129

**ja-Q0130 · Build the sentence**

Arrange: を / 私たちはきわめて慎重に調査 / 行なった。

We conducted our investigation with the greatest care.

[[Japanese#^ja-Q0130-answer|Compare the answer]]
^ja-Q0130

**ja-Q0131 · Write a translation**

Write this in Japanese: Any chance you know where I put my keys?

[[Japanese#^ja-Q0131-answer|Compare the answer]]
^ja-Q0131

**ja-Q0132 · Explain the grammar**

私はカギ【を】置いたところなんか知りませんか。

Any chance you know where I put my keys?

[[Japanese#^ja-Q0132-answer|Compare the answer]]
^ja-Q0132

**ja-Q0133 · Fill the gap**

その少年はわざと私の足____踏んだ。

The boy stepped on my foot on purpose.

[[Japanese#^ja-Q0133-answer|Compare the answer]]
^ja-Q0133

**ja-Q0134 · Choose the form**

その少年はわざと私の足____踏んだ。

The boy stepped on my foot on purpose.

Choices: が / で / に / を

[[Japanese#^ja-Q0134-answer|Compare the answer]]
^ja-Q0134

**ja-Q0135 · Edit the changed sentence**

先生達は親たちとその問題【に】討議しあった。

The teachers debated the problem with the parents.

[[Japanese#^ja-Q0135-answer|Compare the answer]]
^ja-Q0135

**ja-Q0136 · Build the sentence**

Arrange: 討議しあった。 / 先生達は親たちとその問題 / を

The teachers debated the problem with the parents.

[[Japanese#^ja-Q0136-answer|Compare the answer]]
^ja-Q0136

**ja-Q0137 · Write a translation**

Write this in Japanese: Would you bring me some salt?

[[Japanese#^ja-Q0137-answer|Compare the answer]]
^ja-Q0137

**ja-Q0138 · Explain the grammar**

お塩【を】持ってきてもらえませんか。

Would you bring me some salt?

[[Japanese#^ja-Q0138-answer|Compare the answer]]
^ja-Q0138

**ja-Q0139 · Fill the gap**

林さんには、言行____一致させる努力を求めたいと思います。

What I want from Mr Hayashi is the effort required for his actions to live up to his words.

[[Japanese#^ja-Q0139-answer|Compare the answer]]
^ja-Q0139

**ja-Q0140 · Choose the form**

林さんには、言行____一致させる努力を求めたいと思います。

What I want from Mr Hayashi is the effort required for his actions to live up to his words.

Choices: に / で / が / を

[[Japanese#^ja-Q0140-answer|Compare the answer]]
^ja-Q0140

**ja-Q0141 · Edit the changed sentence**

明日までには仕事【に】やり終えているでしょう。

I will be through with my work by tomorrow.

[[Japanese#^ja-Q0141-answer|Compare the answer]]
^ja-Q0141

**ja-Q0142 · Build the sentence**

Arrange: を / 明日までには仕事 / やり終えているでしょう。

I will be through with my work by tomorrow.

[[Japanese#^ja-Q0142-answer|Compare the answer]]
^ja-Q0142

**ja-Q0143 · Write a translation**

Write this in Japanese: I ate some potato chips.

[[Japanese#^ja-Q0143-answer|Compare the answer]]
^ja-Q0143

**ja-Q0144 · Explain the grammar**

私はポテトチップス【を】食べました。

I ate some potato chips.

[[Japanese#^ja-Q0144-answer|Compare the answer]]
^ja-Q0144

**ja-Q0145 · Fill the gap**

彼女はその教師____訪問した。

She visited the teacher.

[[Japanese#^ja-Q0145-answer|Compare the answer]]
^ja-Q0145

**ja-Q0146 · Choose the form**

彼女はその教師____訪問した。

She visited the teacher.

Choices: に / が / で / を

[[Japanese#^ja-Q0146-answer|Compare the answer]]
^ja-Q0146

**ja-Q0147 · Edit the changed sentence**

僕は会った瞬間彼女【に】好きになった。

I took to her the moment I met her.

[[Japanese#^ja-Q0147-answer|Compare the answer]]
^ja-Q0147

**ja-Q0148 · Build the sentence**

Arrange: を / 好きになった。 / 僕は会った瞬間彼女

I took to her the moment I met her.

[[Japanese#^ja-Q0148-answer|Compare the answer]]
^ja-Q0148

**ja-Q0149 · Write a translation**

Write this in Japanese: The baby held out his tiny hand.

[[Japanese#^ja-Q0149-answer|Compare the answer]]
^ja-Q0149

**ja-Q0150 · Explain the grammar**

赤ん坊は小さな手【を】差し出した。

The baby held out his tiny hand.

[[Japanese#^ja-Q0150-answer|Compare the answer]]
^ja-Q0150


### に relations · 50 questions

**ja-Q0151 · Fill the gap**

パーティー____行かない。

I'm not going to go to the party.

[[Japanese#^ja-Q0151-answer|Compare the answer]]
^ja-Q0151

**ja-Q0152 · Choose the form**

パーティー____行かない。

I'm not going to go to the party.

Choices: に / で / へ / を

[[Japanese#^ja-Q0152-answer|Compare the answer]]
^ja-Q0152

**ja-Q0153 · Edit the changed sentence**

明日買い物【で】行きます。

I'm going shopping tomorrow.

[[Japanese#^ja-Q0153-answer|Compare the answer]]
^ja-Q0153

**ja-Q0154 · Build the sentence**

Arrange: 行きます。 / に / 明日買い物

I'm going shopping tomorrow.

[[Japanese#^ja-Q0154-answer|Compare the answer]]
^ja-Q0154

**ja-Q0155 · Write a translation**

Write this in Japanese: Do to others as you would be done by.

[[Japanese#^ja-Q0155-answer|Compare the answer]]
^ja-Q0155

**ja-Q0156 · Explain the grammar**

人からしてもらいたいよう【に】人にしてやれ。

Do to others as you would be done by.

[[Japanese#^ja-Q0156-answer|Compare the answer]]
^ja-Q0156

**ja-Q0157 · Fill the gap**

三日前、旧友____ひょっこり会った。

I ran into an old friend three days ago.

[[Japanese#^ja-Q0157-answer|Compare the answer]]
^ja-Q0157

**ja-Q0158 · Choose the form**

三日前、旧友____ひょっこり会った。

I ran into an old friend three days ago.

Choices: へ / を / に / で

[[Japanese#^ja-Q0158-answer|Compare the answer]]
^ja-Q0158

**ja-Q0159 · Edit the changed sentence**

あいつの家族はみんなアメリカ【で】行ったんだけど、あいつはブラジルに残ったんだ。

All his family went to the United States, but he stayed in Brazil.

[[Japanese#^ja-Q0159-answer|Compare the answer]]
^ja-Q0159

**ja-Q0160 · Build the sentence**

Arrange: 行ったんだけど、あいつはブラジルに残ったんだ。 / あいつの家族はみんなアメリカ / に

All his family went to the United States, but he stayed in Brazil.

[[Japanese#^ja-Q0160-answer|Compare the answer]]
^ja-Q0160

**ja-Q0161 · Write a translation**

Write this in Japanese: The three neighbours helped each other.

[[Japanese#^ja-Q0161-answer|Compare the answer]]
^ja-Q0161

**ja-Q0162 · Explain the grammar**

３人の隣人はお互い【に】助け合った。

The three neighbours helped each other.

[[Japanese#^ja-Q0162-answer|Compare the answer]]
^ja-Q0162

**ja-Q0163 · Fill the gap**

夜ご飯____ステーキはどうですか?

Would you like to have steak for dinner?

[[Japanese#^ja-Q0163-answer|Compare the answer]]
^ja-Q0163

**ja-Q0164 · Choose the form**

夜ご飯____ステーキはどうですか?

Would you like to have steak for dinner?

Choices: に / へ / で / を

[[Japanese#^ja-Q0164-answer|Compare the answer]]
^ja-Q0164

**ja-Q0165 · Edit the changed sentence**

私たちはその結果【で】十分満足しているわけではない。

We are not quite satisfied with the result.

[[Japanese#^ja-Q0165-answer|Compare the answer]]
^ja-Q0165

**ja-Q0166 · Build the sentence**

Arrange: 十分満足しているわけではない。 / に / 私たちはその結果

We are not quite satisfied with the result.

[[Japanese#^ja-Q0166-answer|Compare the answer]]
^ja-Q0166

**ja-Q0167 · Write a translation**

Write this in Japanese: It was decided that the old building be pulled down.

[[Japanese#^ja-Q0167-answer|Compare the answer]]
^ja-Q0167

**ja-Q0168 · Explain the grammar**

その古い建物は取り壊されること【に】なった。

It was decided that the old building be pulled down.

[[Japanese#^ja-Q0168-answer|Compare the answer]]
^ja-Q0168

**ja-Q0169 · Fill the gap**

昨日ケン____会った。

I met Ken yesterday.

[[Japanese#^ja-Q0169-answer|Compare the answer]]
^ja-Q0169

**ja-Q0170 · Choose the form**

昨日ケン____会った。

I met Ken yesterday.

Choices: を / で / に / へ

[[Japanese#^ja-Q0170-answer|Compare the answer]]
^ja-Q0170

**ja-Q0171 · Edit the changed sentence**

私達は年【で】一回集まります。

We get together once a year.

[[Japanese#^ja-Q0171-answer|Compare the answer]]
^ja-Q0171

**ja-Q0172 · Build the sentence**

Arrange: に / 一回集まります。 / 私達は年

We get together once a year.

[[Japanese#^ja-Q0172-answer|Compare the answer]]
^ja-Q0172

**ja-Q0173 · Write a translation**

Write this in Japanese: He's really into chemistry.

[[Japanese#^ja-Q0173-answer|Compare the answer]]
^ja-Q0173

**ja-Q0174 · Explain the grammar**

彼は化学【に】ハマってるんだよ。

He's really into chemistry.

[[Japanese#^ja-Q0174-answer|Compare the answer]]
^ja-Q0174

**ja-Q0175 · Fill the gap**

すぐ出発しなさい。そうすれば彼____追いつきますよ。

Start at once, and you will catch up with him.

[[Japanese#^ja-Q0175-answer|Compare the answer]]
^ja-Q0175

**ja-Q0176 · Choose the form**

すぐ出発しなさい。そうすれば彼____追いつきますよ。

Start at once, and you will catch up with him.

Choices: を / に / へ / で

[[Japanese#^ja-Q0176-answer|Compare the answer]]
^ja-Q0176

**ja-Q0177 · Edit the changed sentence**

危険など【で】ひるまず、彼は平気でいる。

He remains calm in the face of danger.

[[Japanese#^ja-Q0177-answer|Compare the answer]]
^ja-Q0177

**ja-Q0178 · Build the sentence**

Arrange: ひるまず、彼は平気でいる。 / 危険など / に

He remains calm in the face of danger.

[[Japanese#^ja-Q0178-answer|Compare the answer]]
^ja-Q0178

**ja-Q0179 · Write a translation**

Write this in Japanese: The sun was hidden by thick clouds.

[[Japanese#^ja-Q0179-answer|Compare the answer]]
^ja-Q0179

**ja-Q0180 · Explain the grammar**

太陽は厚い雲【に】おおわれた。

The sun was hidden by thick clouds.

[[Japanese#^ja-Q0180-answer|Compare the answer]]
^ja-Q0180

**ja-Q0181 · Fill the gap**

私達は時勢____通じていなければならない。

We must keep in touch with the times.

[[Japanese#^ja-Q0181-answer|Compare the answer]]
^ja-Q0181

**ja-Q0182 · Choose the form**

私達は時勢____通じていなければならない。

We must keep in touch with the times.

Choices: を / に / へ / で

[[Japanese#^ja-Q0182-answer|Compare the answer]]
^ja-Q0182

**ja-Q0183 · Edit the changed sentence**

もっと一所懸命勉強しなきゃいけないよ、ってトム【で】話した。

I told Tom he should study harder.

[[Japanese#^ja-Q0183-answer|Compare the answer]]
^ja-Q0183

**ja-Q0184 · Build the sentence**

Arrange: に / もっと一所懸命勉強しなきゃいけないよ、ってトム / 話した。

I told Tom he should study harder.

[[Japanese#^ja-Q0184-answer|Compare the answer]]
^ja-Q0184

**ja-Q0185 · Write a translation**

Write this in Japanese: Tom met Mary for the first time three years ago.

[[Japanese#^ja-Q0185-answer|Compare the answer]]
^ja-Q0185

**ja-Q0186 · Explain the grammar**

トムは3年前【に】初めてメアリーに会った。

Tom met Mary for the first time three years ago.

[[Japanese#^ja-Q0186-answer|Compare the answer]]
^ja-Q0186

**ja-Q0187 · Fill the gap**

私はエイズの研究____従事している。

I am engaged in AIDS research.

[[Japanese#^ja-Q0187-answer|Compare the answer]]
^ja-Q0187

**ja-Q0188 · Choose the form**

私はエイズの研究____従事している。

I am engaged in AIDS research.

Choices: に / で / へ / を

[[Japanese#^ja-Q0188-answer|Compare the answer]]
^ja-Q0188

**ja-Q0189 · Edit the changed sentence**

この理論はとてもむずかしいので私【で】は理解できない。

This theory is too difficult for me to comprehend.

[[Japanese#^ja-Q0189-answer|Compare the answer]]
^ja-Q0189

**ja-Q0190 · Build the sentence**

Arrange: に / は理解できない。 / この理論はとてもむずかしいので私

This theory is too difficult for me to comprehend.

[[Japanese#^ja-Q0190-answer|Compare the answer]]
^ja-Q0190

**ja-Q0191 · Write a translation**

Write this in Japanese: I'm walking beside her.

[[Japanese#^ja-Q0191-answer|Compare the answer]]
^ja-Q0191

**ja-Q0192 · Explain the grammar**

僕は彼女と一緒【に】歩いている。

I'm walking beside her.

[[Japanese#^ja-Q0192-answer|Compare the answer]]
^ja-Q0192

**ja-Q0193 · Fill the gap**

彼は彼の現状____満足している。

He is content with his present state.

[[Japanese#^ja-Q0193-answer|Compare the answer]]
^ja-Q0193

**ja-Q0194 · Choose the form**

彼は彼の現状____満足している。

He is content with his present state.

Choices: に / を / で / へ

[[Japanese#^ja-Q0194-answer|Compare the answer]]
^ja-Q0194

**ja-Q0195 · Edit the changed sentence**

彼らは毎週日曜日【で】礼拝に行く。

They worship every Sunday.

[[Japanese#^ja-Q0195-answer|Compare the answer]]
^ja-Q0195

**ja-Q0196 · Build the sentence**

Arrange: 礼拝に行く。 / に / 彼らは毎週日曜日

They worship every Sunday.

[[Japanese#^ja-Q0196-answer|Compare the answer]]
^ja-Q0196

**ja-Q0197 · Write a translation**

Write this in Japanese: "What time is it?" "2:30." "Really? I wanted to go to sleep early today, too."

[[Japanese#^ja-Q0197-answer|Compare the answer]]
^ja-Q0197

**ja-Q0198 · Explain the grammar**

「今何時？」「2時半」「まじか。今日は早く寝るつもりだったの【に】」

"What time is it?" "2:30." "Really? I wanted to go to sleep early today, too."

[[Japanese#^ja-Q0198-answer|Compare the answer]]
^ja-Q0198

**ja-Q0199 · Fill the gap**

彼はその物音____ぎょっとなった。

He started at the noise.

[[Japanese#^ja-Q0199-answer|Compare the answer]]
^ja-Q0199

**ja-Q0200 · Choose the form**

彼はその物音____ぎょっとなった。

He started at the noise.

Choices: へ / に / で / を

[[Japanese#^ja-Q0200-answer|Compare the answer]]
^ja-Q0200


### で relations · 50 questions

**ja-Q0201 · Edit the changed sentence**

彼は本当のところ支配人【に】はない。

He is actually not the manager.

[[Japanese#^ja-Q0201-answer|Compare the answer]]
^ja-Q0201

**ja-Q0202 · Build the sentence**

Arrange: 彼は本当のところ支配人 / はない。 / で

He is actually not the manager.

[[Japanese#^ja-Q0202-answer|Compare the answer]]
^ja-Q0202

**ja-Q0203 · Write a translation**

Write this in Japanese: Tom cut his own hair.

[[Japanese#^ja-Q0203-answer|Compare the answer]]
^ja-Q0203

**ja-Q0204 · Explain the grammar**

トムね、自分【で】髪切ったのよ。

Tom cut his own hair.

[[Japanese#^ja-Q0204-answer|Compare the answer]]
^ja-Q0204

**ja-Q0205 · Fill the gap**

ボクシングやホッケーのようなスポーツは好き____はない。

I don't like such sports as boxing and hockey.

[[Japanese#^ja-Q0205-answer|Compare the answer]]
^ja-Q0205

**ja-Q0206 · Choose the form**

ボクシングやホッケーのようなスポーツは好き____はない。

I don't like such sports as boxing and hockey.

Choices: で / を / と / に

[[Japanese#^ja-Q0206-answer|Compare the answer]]
^ja-Q0206

**ja-Q0207 · Edit the changed sentence**

中東は文明の発祥地【に】ある。

The Middle East is the cradle of civilization.

[[Japanese#^ja-Q0207-answer|Compare the answer]]
^ja-Q0207

**ja-Q0208 · Build the sentence**

Arrange: ある。 / 中東は文明の発祥地 / で

The Middle East is the cradle of civilization.

[[Japanese#^ja-Q0208-answer|Compare the answer]]
^ja-Q0208

**ja-Q0209 · Write a translation**

Write this in Japanese: Don't trouble about small things.

[[Japanese#^ja-Q0209-answer|Compare the answer]]
^ja-Q0209

**ja-Q0210 · Explain the grammar**

小さなこと【で】くよくよするな。

Don't trouble about small things.

[[Japanese#^ja-Q0210-answer|Compare the answer]]
^ja-Q0210

**ja-Q0211 · Fill the gap**

彼女はフランス____一番のテニス選手だと言われている。

It is said that she is the best tennis player in France.

[[Japanese#^ja-Q0211-answer|Compare the answer]]
^ja-Q0211

**ja-Q0212 · Choose the form**

彼女はフランス____一番のテニス選手だと言われている。

It is said that she is the best tennis player in France.

Choices: に / で / を / と

[[Japanese#^ja-Q0212-answer|Compare the answer]]
^ja-Q0212

**ja-Q0213 · Edit the changed sentence**

なん【に】こんなに早く来たの？

Why did you come so early?

[[Japanese#^ja-Q0213-answer|Compare the answer]]
^ja-Q0213

**ja-Q0214 · Build the sentence**

Arrange: で / こんなに早く来たの？ / なん

Why did you come so early?

[[Japanese#^ja-Q0214-answer|Compare the answer]]
^ja-Q0214

**ja-Q0215 · Write a translation**

Write this in Japanese: We study English at school every day.

[[Japanese#^ja-Q0215-answer|Compare the answer]]
^ja-Q0215

**ja-Q0216 · Explain the grammar**

私たちは毎日学校【で】英語を勉強する。

We study English at school every day.

[[Japanese#^ja-Q0216-answer|Compare the answer]]
^ja-Q0216

**ja-Q0217 · Fill the gap**

船は嵐____左右に揺れた。

The ship rolled from side to side in the storm.

[[Japanese#^ja-Q0217-answer|Compare the answer]]
^ja-Q0217

**ja-Q0218 · Choose the form**

船は嵐____左右に揺れた。

The ship rolled from side to side in the storm.

Choices: を / で / と / に

[[Japanese#^ja-Q0218-answer|Compare the answer]]
^ja-Q0218

**ja-Q0219 · Edit the changed sentence**

私は貴乃花が急い【に】体育館を出てくる時、彼をちらっと見た。

I got a quick glimpse of Takanohana as he hurriedly left the gymnasium.

[[Japanese#^ja-Q0219-answer|Compare the answer]]
^ja-Q0219

**ja-Q0220 · Build the sentence**

Arrange: で / 体育館を出てくる時、彼をちらっと見た。 / 私は貴乃花が急い

I got a quick glimpse of Takanohana as he hurriedly left the gymnasium.

[[Japanese#^ja-Q0220-answer|Compare the answer]]
^ja-Q0220

**ja-Q0221 · Write a translation**

Write this in Japanese: She could always call her parents when she was in a crunch.

[[Japanese#^ja-Q0221-answer|Compare the answer]]
^ja-Q0221

**ja-Q0222 · Explain the grammar**

彼女は困ったらいつも両親を呼ぶことが【で】きた。

She could always call her parents when she was in a crunch.

[[Japanese#^ja-Q0222-answer|Compare the answer]]
^ja-Q0222

**ja-Q0223 · Fill the gap**

彼は夜随分遅くま____働いた。

He worked far into the night.

[[Japanese#^ja-Q0223-answer|Compare the answer]]
^ja-Q0223

**ja-Q0224 · Choose the form**

彼は夜随分遅くま____働いた。

He worked far into the night.

Choices: で / と / を / に

[[Japanese#^ja-Q0224-answer|Compare the answer]]
^ja-Q0224

**ja-Q0225 · Edit the changed sentence**

私は英語を教える事が【に】きます。

I can teach English.

[[Japanese#^ja-Q0225-answer|Compare the answer]]
^ja-Q0225

**ja-Q0226 · Build the sentence**

Arrange: で / きます。 / 私は英語を教える事が

I can teach English.

[[Japanese#^ja-Q0226-answer|Compare the answer]]
^ja-Q0226

**ja-Q0227 · Write a translation**

Write this in Japanese: Why does everything happen to me?

[[Japanese#^ja-Q0227-answer|Compare the answer]]
^ja-Q0227

**ja-Q0228 · Explain the grammar**

どういう風の吹き回し【で】こうなったのだろう。

Why does everything happen to me?

[[Japanese#^ja-Q0228-answer|Compare the answer]]
^ja-Q0228

**ja-Q0229 · Fill the gap**

これから火葬場へ移動しますの____、小川様と君は車へ。

We are now going to move to the crematorium so if Mr. Ogawa and you would enter the car ...

[[Japanese#^ja-Q0229-answer|Compare the answer]]
^ja-Q0229

**ja-Q0230 · Choose the form**

これから火葬場へ移動しますの____、小川様と君は車へ。

We are now going to move to the crematorium so if Mr. Ogawa and you would enter the car ...

Choices: を / で / と / に

[[Japanese#^ja-Q0230-answer|Compare the answer]]
^ja-Q0230

**ja-Q0231 · Edit the changed sentence**

私は彼の要求しているものが理解【に】きない。

I can't make out what he wants.

[[Japanese#^ja-Q0231-answer|Compare the answer]]
^ja-Q0231

**ja-Q0232 · Build the sentence**

Arrange: で / きない。 / 私は彼の要求しているものが理解

I can't make out what he wants.

[[Japanese#^ja-Q0232-answer|Compare the answer]]
^ja-Q0232

**ja-Q0233 · Write a translation**

Write this in Japanese: He lived in Kyoto in his college days.

[[Japanese#^ja-Q0233-answer|Compare the answer]]
^ja-Q0233

**ja-Q0234 · Explain the grammar**

彼は大学時代に京都にすん【で】いた。

He lived in Kyoto in his college days.

[[Japanese#^ja-Q0234-answer|Compare the answer]]
^ja-Q0234

**ja-Q0235 · Fill the gap**

彼がどんなに熱心に英語を勉強しても、１年や２年____はものにすることはできない。

No matter how hard he may study, he cannot master English in a year or two.

[[Japanese#^ja-Q0235-answer|Compare the answer]]
^ja-Q0235

**ja-Q0236 · Choose the form**

彼がどんなに熱心に英語を勉強しても、１年や２年____はものにすることはできない。

No matter how hard he may study, he cannot master English in a year or two.

Choices: を / と / で / に

[[Japanese#^ja-Q0236-answer|Compare the answer]]
^ja-Q0236

**ja-Q0237 · Edit the changed sentence**

彼女は秘書としては推薦することは【に】きない。

I cannot recommend her as a secretary.

[[Japanese#^ja-Q0237-answer|Compare the answer]]
^ja-Q0237

**ja-Q0238 · Build the sentence**

Arrange: で / きない。 / 彼女は秘書としては推薦することは

I cannot recommend her as a secretary.

[[Japanese#^ja-Q0238-answer|Compare the answer]]
^ja-Q0238

**ja-Q0239 · Write a translation**

Write this in Japanese: And then, on the final turn, he began to sprint at full speed.

[[Japanese#^ja-Q0239-answer|Compare the answer]]
^ja-Q0239

**ja-Q0240 · Explain the grammar**

それから，最終コーナー【で】全力疾走に入った。

And then, on the final turn, he began to sprint at full speed.

[[Japanese#^ja-Q0240-answer|Compare the answer]]
^ja-Q0240

**ja-Q0241 · Fill the gap**

その城は今____は廃虚となっている。

The castle is now in ruins.

[[Japanese#^ja-Q0241-answer|Compare the answer]]
^ja-Q0241

**ja-Q0242 · Choose the form**

その城は今____は廃虚となっている。

The castle is now in ruins.

Choices: と / を / で / に

[[Japanese#^ja-Q0242-answer|Compare the answer]]
^ja-Q0242

**ja-Q0243 · Edit the changed sentence**

国家が繁栄するかは多かれ少なかれ国民次第【に】ある。

The prosperity of a country depends more or less on its citizens.

[[Japanese#^ja-Q0243-answer|Compare the answer]]
^ja-Q0243

**ja-Q0244 · Build the sentence**

Arrange: ある。 / 国家が繁栄するかは多かれ少なかれ国民次第 / で

The prosperity of a country depends more or less on its citizens.

[[Japanese#^ja-Q0244-answer|Compare the answer]]
^ja-Q0244

**ja-Q0245 · Write a translation**

Write this in Japanese: We can never begin to finish this work by tomorrow.

[[Japanese#^ja-Q0245-answer|Compare the answer]]
^ja-Q0245

**ja-Q0246 · Explain the grammar**

とても明日ま【で】にこの仕事はすみそうにない。

We can never begin to finish this work by tomorrow.

[[Japanese#^ja-Q0246-answer|Compare the answer]]
^ja-Q0246

**ja-Q0247 · Fill the gap**

私は船に弱いの____、船旅は好きではない。

I am a poor sailor, so I don't like to travel by boat.

[[Japanese#^ja-Q0247-answer|Compare the answer]]
^ja-Q0247

**ja-Q0248 · Choose the form**

私は船に弱いの____、船旅は好きではない。

I am a poor sailor, so I don't like to travel by boat.

Choices: と / を / に / で

[[Japanese#^ja-Q0248-answer|Compare the answer]]
^ja-Q0248

**ja-Q0249 · Edit the changed sentence**

お父さんが帰るま【に】に宿題をすませなさい。

Finish your homework by the time your father comes home.

[[Japanese#^ja-Q0249-answer|Compare the answer]]
^ja-Q0249

**ja-Q0250 · Build the sentence**

Arrange: で / に宿題をすませなさい。 / お父さんが帰るま

Finish your homework by the time your father comes home.

[[Japanese#^ja-Q0250-answer|Compare the answer]]
^ja-Q0250


### Possession and modification の · 50 questions

**ja-Q0251 · Write a translation**

Write this in Japanese: Her friend is a singer.

[[Japanese#^ja-Q0251-answer|Compare the answer]]
^ja-Q0251

**ja-Q0252 · Explain the grammar**

彼女【の】友達は歌手です。

Her friend is a singer.

[[Japanese#^ja-Q0252-answer|Compare the answer]]
^ja-Q0252

**ja-Q0253 · Fill the gap**

これまた政府____隠ぺい策のようです。

This looks like another government cover-up.

[[Japanese#^ja-Q0253-answer|Compare the answer]]
^ja-Q0253

**ja-Q0254 · Choose the form**

これまた政府____隠ぺい策のようです。

This looks like another government cover-up.

Choices: を / に / が / の

[[Japanese#^ja-Q0254-answer|Compare the answer]]
^ja-Q0254

**ja-Q0255 · Edit the changed sentence**

君【に】場合は例外としよう。

We will make an exception of your case.

[[Japanese#^ja-Q0255-answer|Compare the answer]]
^ja-Q0255

**ja-Q0256 · Build the sentence**

Arrange: の / 君 / 場合は例外としよう。

We will make an exception of your case.

[[Japanese#^ja-Q0256-answer|Compare the answer]]
^ja-Q0256

**ja-Q0257 · Write a translation**

Write this in Japanese: Those jets were faster than lightning.

[[Japanese#^ja-Q0257-answer|Compare the answer]]
^ja-Q0257

**ja-Q0258 · Explain the grammar**

そ【の】ジェット機は稲光より速かった。

Those jets were faster than lightning.

[[Japanese#^ja-Q0258-answer|Compare the answer]]
^ja-Q0258

**ja-Q0259 · Fill the gap**

これは扇子といって、こうやって開くんです。夏____暑い日に使うんです。

This is a folding fan, and this is how you open it. It's for hot summer days.

[[Japanese#^ja-Q0259-answer|Compare the answer]]
^ja-Q0259

**ja-Q0260 · Choose the form**

これは扇子といって、こうやって開くんです。夏____暑い日に使うんです。

This is a folding fan, and this is how you open it. It's for hot summer days.

Choices: を / に / の / が

[[Japanese#^ja-Q0260-answer|Compare the answer]]
^ja-Q0260

**ja-Q0261 · Edit the changed sentence**

それは君【に】決めることだ。

It is up to you.

[[Japanese#^ja-Q0261-answer|Compare the answer]]
^ja-Q0261

**ja-Q0262 · Build the sentence**

Arrange: の / それは君 / 決めることだ。

It is up to you.

[[Japanese#^ja-Q0262-answer|Compare the answer]]
^ja-Q0262

**ja-Q0263 · Write a translation**

Write this in Japanese: She kept on dancing all through the party.

[[Japanese#^ja-Q0263-answer|Compare the answer]]
^ja-Q0263

**ja-Q0264 · Explain the grammar**

彼女はパーティー【の】間ずっと踊り続けた。

She kept on dancing all through the party.

[[Japanese#^ja-Q0264-answer|Compare the answer]]
^ja-Q0264

**ja-Q0265 · Fill the gap**

私はそ____話を聞いて東京の将来について考えさせられた。

That story made me think over the future of Tokyo.

[[Japanese#^ja-Q0265-answer|Compare the answer]]
^ja-Q0265

**ja-Q0266 · Choose the form**

私はそ____話を聞いて東京の将来について考えさせられた。

That story made me think over the future of Tokyo.

Choices: が / に / の / を

[[Japanese#^ja-Q0266-answer|Compare the answer]]
^ja-Q0266

**ja-Q0267 · Edit the changed sentence**

忘れずに出席者【に】員数をかぞえなさい。

Don't forget to count how many people attend.

[[Japanese#^ja-Q0267-answer|Compare the answer]]
^ja-Q0267

**ja-Q0268 · Build the sentence**

Arrange: 員数をかぞえなさい。 / の / 忘れずに出席者

Don't forget to count how many people attend.

[[Japanese#^ja-Q0268-answer|Compare the answer]]
^ja-Q0268

**ja-Q0269 · Write a translation**

Write this in Japanese: I must request you to obey my orders.

[[Japanese#^ja-Q0269-answer|Compare the answer]]
^ja-Q0269

**ja-Q0270 · Explain the grammar**

私【の】命令には従ってもらうようお願いいたします。

I must request you to obey my orders.

[[Japanese#^ja-Q0270-answer|Compare the answer]]
^ja-Q0270

**ja-Q0271 · Fill the gap**

こ____小説はつまらない。

This novel is boring.

[[Japanese#^ja-Q0271-answer|Compare the answer]]
^ja-Q0271

**ja-Q0272 · Choose the form**

こ____小説はつまらない。

This novel is boring.

Choices: の / に / を / が

[[Japanese#^ja-Q0272-answer|Compare the answer]]
^ja-Q0272

**ja-Q0273 · Edit the changed sentence**

私は息子にそ【に】手紙を投函させた。

I got my son to post the letters.

[[Japanese#^ja-Q0273-answer|Compare the answer]]
^ja-Q0273

**ja-Q0274 · Build the sentence**

Arrange: の / 手紙を投函させた。 / 私は息子にそ

I got my son to post the letters.

[[Japanese#^ja-Q0274-answer|Compare the answer]]
^ja-Q0274

**ja-Q0275 · Write a translation**

Write this in Japanese: They make good use of their rooms.

[[Japanese#^ja-Q0275-answer|Compare the answer]]
^ja-Q0275

**ja-Q0276 · Explain the grammar**

彼らは自分【の】部屋をうまく利用している。

They make good use of their rooms.

[[Japanese#^ja-Q0276-answer|Compare the answer]]
^ja-Q0276

**ja-Q0277 · Fill the gap**

ふっ、禁断____魔術とやらは、俺には通用しないぜ！

Hah, your 'forbidden magics' aren't going to work with me!

[[Japanese#^ja-Q0277-answer|Compare the answer]]
^ja-Q0277

**ja-Q0278 · Choose the form**

ふっ、禁断____魔術とやらは、俺には通用しないぜ！

Hah, your 'forbidden magics' aren't going to work with me!

Choices: の / が / を / に

[[Japanese#^ja-Q0278-answer|Compare the answer]]
^ja-Q0278

**ja-Q0279 · Edit the changed sentence**

これは彼【に】家です。

This is his house.

[[Japanese#^ja-Q0279-answer|Compare the answer]]
^ja-Q0279

**ja-Q0280 · Build the sentence**

Arrange: これは彼 / 家です。 / の

This is his house.

[[Japanese#^ja-Q0280-answer|Compare the answer]]
^ja-Q0280

**ja-Q0281 · Write a translation**

Write this in Japanese: "We don't give discounts," the woman said sternly. "Regardless how small. Now, please take off the suit if you can't afford it."

[[Japanese#^ja-Q0281-answer|Compare the answer]]
^ja-Q0281

**ja-Q0282 · Explain the grammar**

そ【の】女性は断固として「我々は値下げをしません」と言った。「びた一文たりともです。さぁ、お買い上げ頂けないのでしたら、そのスーツを脱いで下さい。」

"We don't give discounts," the woman said sternly. "Regardless how small. Now, please take off the suit if you can't afford it."

[[Japanese#^ja-Q0282-answer|Compare the answer]]
^ja-Q0282

**ja-Q0283 · Fill the gap**

日本は多く____国からしっぺ返しをくらうだろう。

Japan will get it from many countries.

[[Japanese#^ja-Q0283-answer|Compare the answer]]
^ja-Q0283

**ja-Q0284 · Choose the form**

日本は多く____国からしっぺ返しをくらうだろう。

Japan will get it from many countries.

Choices: を / に / が / の

[[Japanese#^ja-Q0284-answer|Compare the answer]]
^ja-Q0284

**ja-Q0285 · Edit the changed sentence**

私にこ【に】ペンをください。

Please give me this pen.

[[Japanese#^ja-Q0285-answer|Compare the answer]]
^ja-Q0285

**ja-Q0286 · Build the sentence**

Arrange: 私にこ / ペンをください。 / の

Please give me this pen.

[[Japanese#^ja-Q0286-answer|Compare the answer]]
^ja-Q0286

**ja-Q0287 · Write a translation**

Write this in Japanese: My father is busy as a bee every day.

[[Japanese#^ja-Q0287-answer|Compare the answer]]
^ja-Q0287

**ja-Q0288 · Explain the grammar**

私【の】父は毎日とても忙しい。

My father is busy as a bee every day.

[[Japanese#^ja-Q0288-answer|Compare the answer]]
^ja-Q0288

**ja-Q0289 · Fill the gap**

これら____図式は求職に関する様々なアプローチを示している。

These diagrams demonstrate different possible approaches to job seeking.

[[Japanese#^ja-Q0289-answer|Compare the answer]]
^ja-Q0289

**ja-Q0290 · Choose the form**

これら____図式は求職に関する様々なアプローチを示している。

These diagrams demonstrate different possible approaches to job seeking.

Choices: が / に / の / を

[[Japanese#^ja-Q0290-answer|Compare the answer]]
^ja-Q0290

**ja-Q0291 · Edit the changed sentence**

私は、あ【に】人たちみたいにはなりたくない。

I don't want to become like those people.

[[Japanese#^ja-Q0291-answer|Compare the answer]]
^ja-Q0291

**ja-Q0292 · Build the sentence**

Arrange: の / 人たちみたいにはなりたくない。 / 私は、あ

I don't want to become like those people.

[[Japanese#^ja-Q0292-answer|Compare the answer]]
^ja-Q0292

**ja-Q0293 · Write a translation**

Write this in Japanese: His motorcycle is the latest model.

[[Japanese#^ja-Q0293-answer|Compare the answer]]
^ja-Q0293

**ja-Q0294 · Explain the grammar**

彼【の】オートバイは最新モデルだ。

His motorcycle is the latest model.

[[Japanese#^ja-Q0294-answer|Compare the answer]]
^ja-Q0294

**ja-Q0295 · Fill the gap**

彼女____息子たちも、娘と同様に、大学に行っている。

Her sons as well as her daughter are in college.

[[Japanese#^ja-Q0295-answer|Compare the answer]]
^ja-Q0295

**ja-Q0296 · Choose the form**

彼女____息子たちも、娘と同様に、大学に行っている。

Her sons as well as her daughter are in college.

Choices: の / が / を / に

[[Japanese#^ja-Q0296-answer|Compare the answer]]
^ja-Q0296

**ja-Q0297 · Edit the changed sentence**

彼女はラジオ【に】音を小さくした。

She turned down the radio.

[[Japanese#^ja-Q0297-answer|Compare the answer]]
^ja-Q0297

**ja-Q0298 · Build the sentence**

Arrange: の / 音を小さくした。 / 彼女はラジオ

She turned down the radio.

[[Japanese#^ja-Q0298-answer|Compare the answer]]
^ja-Q0298

**ja-Q0299 · Write a translation**

Write this in Japanese: His statement is void of sincerity.

[[Japanese#^ja-Q0299-answer|Compare the answer]]
^ja-Q0299

**ja-Q0300 · Explain the grammar**

彼【の】言う事には誠意が欠けている。

His statement is void of sincerity.

[[Japanese#^ja-Q0300-answer|Compare the answer]]
^ja-Q0300


### Quotation and accompaniment と · 50 questions

**ja-Q0301 · Fill the gap**

彼は全く不可能だ____言った。

He said it was out of the question.

[[Japanese#^ja-Q0301-answer|Compare the answer]]
^ja-Q0301

**ja-Q0302 · Choose the form**

彼は全く不可能だ____言った。

He said it was out of the question.

Choices: で / と / や / に

[[Japanese#^ja-Q0302-answer|Compare the answer]]
^ja-Q0302

**ja-Q0303 · Edit the changed sentence**

暑い【や】牛乳はすぐに腐る。

Milk does not keep long on a hot day.

[[Japanese#^ja-Q0303-answer|Compare the answer]]
^ja-Q0303

**ja-Q0304 · Build the sentence**

Arrange: 暑い / 牛乳はすぐに腐る。 / と

Milk does not keep long on a hot day.

[[Japanese#^ja-Q0304-answer|Compare the answer]]
^ja-Q0304

**ja-Q0305 · Write a translation**

Write this in Japanese: The marigold rises with the sun.

[[Japanese#^ja-Q0305-answer|Compare the answer]]
^ja-Q0305

**ja-Q0306 · Explain the grammar**

マリーゴールドは太陽【と】ともに起きる。

The marigold rises with the sun.

[[Japanese#^ja-Q0306-answer|Compare the answer]]
^ja-Q0306

**ja-Q0307 · Fill the gap**

私達は美しい景色に見____れて立っていた。

We stood looking at the beautiful scenery.

[[Japanese#^ja-Q0307-answer|Compare the answer]]
^ja-Q0307

**ja-Q0308 · Choose the form**

私達は美しい景色に見____れて立っていた。

We stood looking at the beautiful scenery.

Choices: や / に / と / で

[[Japanese#^ja-Q0308-answer|Compare the answer]]
^ja-Q0308

**ja-Q0309 · Edit the changed sentence**

わたしはあなた【や】、旅行に行きたい。

I want to travel with you.

[[Japanese#^ja-Q0309-answer|Compare the answer]]
^ja-Q0309

**ja-Q0310 · Build the sentence**

Arrange: と / 、旅行に行きたい。 / わたしはあなた

I want to travel with you.

[[Japanese#^ja-Q0310-answer|Compare the answer]]
^ja-Q0310

**ja-Q0311 · Write a translation**

Write this in Japanese: Hit the ball after the bounce.

[[Japanese#^ja-Q0311-answer|Compare the answer]]
^ja-Q0311

**ja-Q0312 · Explain the grammar**

ボールがバウンドして上がってくる【と】ころを打つ。

Hit the ball after the bounce.

[[Japanese#^ja-Q0312-answer|Compare the answer]]
^ja-Q0312

**ja-Q0313 · Fill the gap**

彼には二度____会いたくない。

I don't want to see him again.

[[Japanese#^ja-Q0313-answer|Compare the answer]]
^ja-Q0313

**ja-Q0314 · Choose the form**

彼には二度____会いたくない。

I don't want to see him again.

Choices: に / と / や / で

[[Japanese#^ja-Q0314-answer|Compare the answer]]
^ja-Q0314

**ja-Q0315 · Edit the changed sentence**

手がすべって皿を床にお【や】してしまった。

The plate slipped from my hands and fell to the floor.

[[Japanese#^ja-Q0315-answer|Compare the answer]]
^ja-Q0315

**ja-Q0316 · Build the sentence**

Arrange: と / 手がすべって皿を床にお / してしまった。

The plate slipped from my hands and fell to the floor.

[[Japanese#^ja-Q0316-answer|Compare the answer]]
^ja-Q0316

**ja-Q0317 · Write a translation**

Write this in Japanese: Do you know the old lady at the gate?

[[Japanese#^ja-Q0317-answer|Compare the answer]]
^ja-Q0317

**ja-Q0318 · Explain the grammar**

門の【と】ころにいる老婦人を知っていますか。

Do you know the old lady at the gate?

[[Japanese#^ja-Q0318-answer|Compare the answer]]
^ja-Q0318

**ja-Q0319 · Fill the gap**

彼は私に攻撃的な態度を____った。

He assumed an aggressive attitude toward me.

[[Japanese#^ja-Q0319-answer|Compare the answer]]
^ja-Q0319

**ja-Q0320 · Choose the form**

彼は私に攻撃的な態度を____った。

He assumed an aggressive attitude toward me.

Choices: に / や / と / で

[[Japanese#^ja-Q0320-answer|Compare the answer]]
^ja-Q0320

**ja-Q0321 · Edit the changed sentence**

明日彼【や】話をするのを忘れてはいけませんよ。

Don't forget to talk with him tomorrow.

[[Japanese#^ja-Q0321-answer|Compare the answer]]
^ja-Q0321

**ja-Q0322 · Build the sentence**

Arrange: と / 明日彼 / 話をするのを忘れてはいけませんよ。

Don't forget to talk with him tomorrow.

[[Japanese#^ja-Q0322-answer|Compare the answer]]
^ja-Q0322

**ja-Q0323 · Write a translation**

Write this in Japanese: The picture of the accident makes me sick.

[[Japanese#^ja-Q0323-answer|Compare the answer]]
^ja-Q0323

**ja-Q0324 · Explain the grammar**

その事故の写真を見る【と】むかつく。

The picture of the accident makes me sick.

[[Japanese#^ja-Q0324-answer|Compare the answer]]
^ja-Q0324

**ja-Q0325 · Fill the gap**

彼らの息子はエドワード____名づけられた。

Their boy was named Edward.

[[Japanese#^ja-Q0325-answer|Compare the answer]]
^ja-Q0325

**ja-Q0326 · Choose the form**

彼らの息子はエドワード____名づけられた。

Their boy was named Edward.

Choices: や / で / に / と

[[Japanese#^ja-Q0326-answer|Compare the answer]]
^ja-Q0326

**ja-Q0327 · Edit the changed sentence**

朝食に何を【や】りましたか。

What did you eat for breakfast?

[[Japanese#^ja-Q0327-answer|Compare the answer]]
^ja-Q0327

**ja-Q0328 · Build the sentence**

Arrange: と / 朝食に何を / りましたか。

What did you eat for breakfast?

[[Japanese#^ja-Q0328-answer|Compare the answer]]
^ja-Q0328

**ja-Q0329 · Write a translation**

Write this in Japanese: The soft gentle sunlight beckoned me off to sleep.

[[Japanese#^ja-Q0329-answer|Compare the answer]]
^ja-Q0329

**ja-Q0330 · Explain the grammar**

ウラウラ【と】した日差しに誘われて、眠りに落ちた。

The soft gentle sunlight beckoned me off to sleep.

[[Japanese#^ja-Q0330-answer|Compare the answer]]
^ja-Q0330

**ja-Q0331 · Fill the gap**

その小さな犬は逃げよう____しました。

The small dog tried to get away.

[[Japanese#^ja-Q0331-answer|Compare the answer]]
^ja-Q0331

**ja-Q0332 · Choose the form**

その小さな犬は逃げよう____しました。

The small dog tried to get away.

Choices: に / や / で / と

[[Japanese#^ja-Q0332-answer|Compare the answer]]
^ja-Q0332

**ja-Q0333 · Edit the changed sentence**

いろいろ【や】コツがわかってきたときに仕事を辞めなければいけなかったのは残念だ。

It's a shame that I had to quit my job just when I was getting the hang of things.

[[Japanese#^ja-Q0333-answer|Compare the answer]]
^ja-Q0333

**ja-Q0334 · Build the sentence**

Arrange: と / いろいろ / コツがわかってきたときに仕事を辞めなければいけなかったのは残念だ。

It's a shame that I had to quit my job just when I was getting the hang of things.

[[Japanese#^ja-Q0334-answer|Compare the answer]]
^ja-Q0334

**ja-Q0335 · Write a translation**

Write this in Japanese: Helen Moody was noted as a tennis player for not showing any expression on the court.

[[Japanese#^ja-Q0335-answer|Compare the answer]]
^ja-Q0335

**ja-Q0336 · Explain the grammar**

ヘレン・ムーディーはテニスの選手【と】して、職業上感情を表さない人として有名だった。

Helen Moody was noted as a tennis player for not showing any expression on the court.

[[Japanese#^ja-Q0336-answer|Compare the answer]]
^ja-Q0336

**ja-Q0337 · Fill the gap**

ジェントルマン____は独立した財産のある人のことだ。

A gentleman is a man of independent means.

[[Japanese#^ja-Q0337-answer|Compare the answer]]
^ja-Q0337

**ja-Q0338 · Choose the form**

ジェントルマン____は独立した財産のある人のことだ。

A gentleman is a man of independent means.

Choices: で / や / に / と

[[Japanese#^ja-Q0338-answer|Compare the answer]]
^ja-Q0338

**ja-Q0339 · Edit the changed sentence**

私が抱えた問題は、私のするタイプが気に入らなかった人【や】の関係だけよ。

The only trouble I've ever had was dealing with people who didn't like my personality.

[[Japanese#^ja-Q0339-answer|Compare the answer]]
^ja-Q0339

**ja-Q0340 · Build the sentence**

Arrange: と / の関係だけよ。 / 私が抱えた問題は、私のするタイプが気に入らなかった人

The only trouble I've ever had was dealing with people who didn't like my personality.

[[Japanese#^ja-Q0340-answer|Compare the answer]]
^ja-Q0340

**ja-Q0341 · Write a translation**

Write this in Japanese: The boy was good at mathematics so everybody considered him a genius.

[[Japanese#^ja-Q0341-answer|Compare the answer]]
^ja-Q0341

**ja-Q0342 · Explain the grammar**

その少年は数学が得意であったので、皆は彼を天才【と】思った。

The boy was good at mathematics so everybody considered him a genius.

[[Japanese#^ja-Q0342-answer|Compare the answer]]
^ja-Q0342

**ja-Q0343 · Fill the gap**

タクシーは信号の____ころで急停車した。

The taxi stopped dead at the traffic signal.

[[Japanese#^ja-Q0343-answer|Compare the answer]]
^ja-Q0343

**ja-Q0344 · Choose the form**

タクシーは信号の____ころで急停車した。

The taxi stopped dead at the traffic signal.

Choices: に / と / や / で

[[Japanese#^ja-Q0344-answer|Compare the answer]]
^ja-Q0344

**ja-Q0345 · Edit the changed sentence**

エドワードはキャシーの目をじっ【や】見て本気でそう言っているのか尋ねた。

Edward looked Kathy in the eye and asked her if she really meant what she said.

[[Japanese#^ja-Q0345-answer|Compare the answer]]
^ja-Q0345

**ja-Q0346 · Build the sentence**

Arrange: と / 見て本気でそう言っているのか尋ねた。 / エドワードはキャシーの目をじっ

Edward looked Kathy in the eye and asked her if she really meant what she said.

[[Japanese#^ja-Q0346-answer|Compare the answer]]
^ja-Q0346

**ja-Q0347 · Write a translation**

Write this in Japanese: The classroom has finally warmed up.

[[Japanese#^ja-Q0347-answer|Compare the answer]]
^ja-Q0347

**ja-Q0348 · Explain the grammar**

教室はやっ【と】暖かくなった。

The classroom has finally warmed up.

[[Japanese#^ja-Q0348-answer|Compare the answer]]
^ja-Q0348

**ja-Q0349 · Fill the gap**

改めて反芻してる____、何だか恥ずかしいぞ。

Now that I think over it, it's somewhat embarrassing.

[[Japanese#^ja-Q0349-answer|Compare the answer]]
^ja-Q0349

**ja-Q0350 · Choose the form**

改めて反芻してる____、何だか恥ずかしいぞ。

Now that I think over it, it's somewhat embarrassing.

Choices: に / で / や / と

[[Japanese#^ja-Q0350-answer|Compare the answer]]
^ja-Q0350


### Inclusion も · 50 questions

**ja-Q0351 · Edit the changed sentence**

金は鉄より【は】貴重だ。

Gold is more precious than iron.

[[Japanese#^ja-Q0351-answer|Compare the answer]]
^ja-Q0351

**ja-Q0352 · Build the sentence**

Arrange: も / 貴重だ。 / 金は鉄より

Gold is more precious than iron.

[[Japanese#^ja-Q0352-answer|Compare the answer]]
^ja-Q0352

**ja-Q0353 · Write a translation**

Write this in Japanese: The streets are in full Christmas mode - it's almost Christmas Eve.

[[Japanese#^ja-Q0353-answer|Compare the answer]]
^ja-Q0353

**ja-Q0354 · Explain the grammar**

街はクリスマスムード一色・・・【も】うじきイブだ。

The streets are in full Christmas mode - it's almost Christmas Eve.

[[Japanese#^ja-Q0354-answer|Compare the answer]]
^ja-Q0354

**ja-Q0355 · Fill the gap**

友達に２０年____会ってない。

I hadn't seen my friend for over twenty years.

[[Japanese#^ja-Q0355-answer|Compare the answer]]
^ja-Q0355

**ja-Q0356 · Choose the form**

友達に２０年____会ってない。

I hadn't seen my friend for over twenty years.

Choices: も / が / を / は

[[Japanese#^ja-Q0356-answer|Compare the answer]]
^ja-Q0356

**ja-Q0357 · Edit the changed sentence**

トム【は】来なかったしジェーンも来なかった。

Tom didn't come, nor did Jane.

[[Japanese#^ja-Q0357-answer|Compare the answer]]
^ja-Q0357

**ja-Q0358 · Build the sentence**

Arrange: も / トム / 来なかったしジェーンも来なかった。

Tom didn't come, nor did Jane.

[[Japanese#^ja-Q0358-answer|Compare the answer]]
^ja-Q0358

**ja-Q0359 · Write a translation**

Write this in Japanese: If the sun were to stop shining, all living things would die.

[[Japanese#^ja-Q0359-answer|Compare the answer]]
^ja-Q0359

**ja-Q0360 · Explain the grammar**

【も】し太陽が輝かなくなれば、生物は皆死ぬだろう。

If the sun were to stop shining, all living things would die.

[[Japanese#^ja-Q0360-answer|Compare the answer]]
^ja-Q0360

**ja-Q0361 · Fill the gap**

両親はどちら____娘の捜索に力を注いだんです。

Both of the parents did try hard in search of their daughter.

[[Japanese#^ja-Q0361-answer|Compare the answer]]
^ja-Q0361

**ja-Q0362 · Choose the form**

両親はどちら____娘の捜索に力を注いだんです。

Both of the parents did try hard in search of their daughter.

Choices: を / が / も / は

[[Japanese#^ja-Q0362-answer|Compare the answer]]
^ja-Q0362

**ja-Q0363 · Edit the changed sentence**

彼は勇敢に【は】そのスキャンダルを暴露した。

He had the courage to expose the scandal.

[[Japanese#^ja-Q0363-answer|Compare the answer]]
^ja-Q0363

**ja-Q0364 · Build the sentence**

Arrange: そのスキャンダルを暴露した。 / 彼は勇敢に / も

He had the courage to expose the scandal.

[[Japanese#^ja-Q0364-answer|Compare the answer]]
^ja-Q0364

**ja-Q0365 · Write a translation**

Write this in Japanese: I was allowed to take a week off.

[[Japanese#^ja-Q0365-answer|Compare the answer]]
^ja-Q0365

**ja-Q0366 · Explain the grammar**

１週間の休暇を取って【も】良い事になった。

I was allowed to take a week off.

[[Japanese#^ja-Q0366-answer|Compare the answer]]
^ja-Q0366

**ja-Q0367 · Fill the gap**

あなたたちはいつ____完全である必要はありません。

You don't have to be perfect all the time.

[[Japanese#^ja-Q0367-answer|Compare the answer]]
^ja-Q0367

**ja-Q0368 · Choose the form**

あなたたちはいつ____完全である必要はありません。

You don't have to be perfect all the time.

Choices: は / が / を / も

[[Japanese#^ja-Q0368-answer|Compare the answer]]
^ja-Q0368

**ja-Q0369 · Edit the changed sentence**

兄は何度【は】試験に挑戦して、最後には合格した。

My brother tried many times to pass the examination, finally succeeding.

[[Japanese#^ja-Q0369-answer|Compare the answer]]
^ja-Q0369

**ja-Q0370 · Build the sentence**

Arrange: 試験に挑戦して、最後には合格した。 / も / 兄は何度

My brother tried many times to pass the examination, finally succeeding.

[[Japanese#^ja-Q0370-answer|Compare the answer]]
^ja-Q0370

**ja-Q0371 · Write a translation**

Write this in Japanese: I may indeed be wrong.

[[Japanese#^ja-Q0371-answer|Compare the answer]]
^ja-Q0371

**ja-Q0372 · Explain the grammar**

なるほど私が間違ってるか【も】しれない。

I may indeed be wrong.

[[Japanese#^ja-Q0372-answer|Compare the answer]]
^ja-Q0372

**ja-Q0373 · Fill the gap**

東京での生活費はとて____高い。

The cost of living is very high in Tokyo.

[[Japanese#^ja-Q0373-answer|Compare the answer]]
^ja-Q0373

**ja-Q0374 · Choose the form**

東京での生活費はとて____高い。

The cost of living is very high in Tokyo.

Choices: も / は / を / が

[[Japanese#^ja-Q0374-answer|Compare the answer]]
^ja-Q0374

**ja-Q0375 · Edit the changed sentence**

彼は終電に乗り遅れたのか【は】しれない。

He may have missed the last train.

[[Japanese#^ja-Q0375-answer|Compare the answer]]
^ja-Q0375

**ja-Q0376 · Build the sentence**

Arrange: しれない。 / 彼は終電に乗り遅れたのか / も

He may have missed the last train.

[[Japanese#^ja-Q0376-answer|Compare the answer]]
^ja-Q0376

**ja-Q0377 · Write a translation**

Write this in Japanese: Could I have a napkin, please?

[[Japanese#^ja-Q0377-answer|Compare the answer]]
^ja-Q0377

**ja-Q0378 · Explain the grammar**

ナプキンを貰って【も】よろしいでしょうか？

Could I have a napkin, please?

[[Japanese#^ja-Q0378-answer|Compare the answer]]
^ja-Q0378

**ja-Q0379 · Fill the gap**

満腹なので、____うこれ以上食べられない。

I am full, and I can eat no more.

[[Japanese#^ja-Q0379-answer|Compare the answer]]
^ja-Q0379

**ja-Q0380 · Choose the form**

満腹なので、____うこれ以上食べられない。

I am full, and I can eat no more.

Choices: も / は / が / を

[[Japanese#^ja-Q0380-answer|Compare the answer]]
^ja-Q0380

**ja-Q0381 · Edit the changed sentence**

トムは英語さえできれば世界中どこへ行って【は】不自由しないと思っている。

Tom believes that as long as you speak English, you'll have no problems going anywhere in the world.

[[Japanese#^ja-Q0381-answer|Compare the answer]]
^ja-Q0381

**ja-Q0382 · Build the sentence**

Arrange: 不自由しないと思っている。 / も / トムは英語さえできれば世界中どこへ行って

Tom believes that as long as you speak English, you'll have no problems going anywhere in the world.

[[Japanese#^ja-Q0382-answer|Compare the answer]]
^ja-Q0382

**ja-Q0383 · Write a translation**

Write this in Japanese: There is nothing interesting in the newspaper today.

[[Japanese#^ja-Q0383-answer|Compare the answer]]
^ja-Q0383

**ja-Q0384 · Explain the grammar**

今日の新聞には面白いことは何【も】ない。

There is nothing interesting in the newspaper today.

[[Japanese#^ja-Q0384-answer|Compare the answer]]
^ja-Q0384

**ja-Q0385 · Fill the gap**

どんなに忙しくて____、宿題はしなければならない。

However busy you may be, you must do your homework.

[[Japanese#^ja-Q0385-answer|Compare the answer]]
^ja-Q0385

**ja-Q0386 · Choose the form**

どんなに忙しくて____、宿題はしなければならない。

However busy you may be, you must do your homework.

Choices: を / も / は / が

[[Japanese#^ja-Q0386-answer|Compare the answer]]
^ja-Q0386

**ja-Q0387 · Edit the changed sentence**

彼にはその５分が５時間に【は】思えた。

To him those five minutes seemed like five hours.

[[Japanese#^ja-Q0387-answer|Compare the answer]]
^ja-Q0387

**ja-Q0388 · Build the sentence**

Arrange: も / 思えた。 / 彼にはその５分が５時間に

To him those five minutes seemed like five hours.

[[Japanese#^ja-Q0388-answer|Compare the answer]]
^ja-Q0388

**ja-Q0389 · Write a translation**

Write this in Japanese: He built on his father's fortune.

[[Japanese#^ja-Q0389-answer|Compare the answer]]
^ja-Q0389

**ja-Q0390 · Explain the grammar**

彼は親譲りの財産を【も】とにして富を作った。

He built on his father's fortune.

[[Japanese#^ja-Q0390-answer|Compare the answer]]
^ja-Q0390

**ja-Q0391 · Fill the gap**

私たちはいつ____地球とともに動いている。

We are always moving with the earth.

[[Japanese#^ja-Q0391-answer|Compare the answer]]
^ja-Q0391

**ja-Q0392 · Choose the form**

私たちはいつ____地球とともに動いている。

We are always moving with the earth.

Choices: は / が / も / を

[[Japanese#^ja-Q0392-answer|Compare the answer]]
^ja-Q0392

**ja-Q0393 · Edit the changed sentence**

彼女はこの世の中で【は】っとも親切な女だとおもう。

I think she is the kindest woman on earth.

[[Japanese#^ja-Q0393-answer|Compare the answer]]
^ja-Q0393

**ja-Q0394 · Build the sentence**

Arrange: 彼女はこの世の中で / っとも親切な女だとおもう。 / も

I think she is the kindest woman on earth.

[[Japanese#^ja-Q0394-answer|Compare the answer]]
^ja-Q0394

**ja-Q0395 · Write a translation**

Write this in Japanese: If you could go back and start your life again, from what age would you like to start?

[[Japanese#^ja-Q0395-answer|Compare the answer]]
^ja-Q0395

**ja-Q0396 · Explain the grammar**

【も】し過去に戻ってもう一度人生をやり直せるとしたら、幾つの時に戻りたい？

If you could go back and start your life again, from what age would you like to start?

[[Japanese#^ja-Q0396-answer|Compare the answer]]
^ja-Q0396

**ja-Q0397 · Fill the gap**

手____とにあるどのような武器を用いてもエイズと闘う必要がある。

It is necessary to fight AIDS with whatever weapons are at hand.

[[Japanese#^ja-Q0397-answer|Compare the answer]]
^ja-Q0397

**ja-Q0398 · Choose the form**

手____とにあるどのような武器を用いてもエイズと闘う必要がある。

It is necessary to fight AIDS with whatever weapons are at hand.

Choices: を / は / が / も

[[Japanese#^ja-Q0398-answer|Compare the answer]]
^ja-Q0398

**ja-Q0399 · Edit the changed sentence**

彼女の唯一の望みは息子に【は】う１度会うことだった。

Her one wish was to see her son again.

[[Japanese#^ja-Q0399-answer|Compare the answer]]
^ja-Q0399

**ja-Q0400 · Build the sentence**

Arrange: も / 彼女の唯一の望みは息子に / う１度会うことだった。

Her one wish was to see her son again.

[[Japanese#^ja-Q0400-answer|Compare the answer]]
^ja-Q0400


### Polite present ending · 50 questions

**ja-Q0401 · Write a translation**

Write this in Japanese: Dinner's ready. I'm coming.

[[Japanese#^ja-Q0401-answer|Compare the answer]]
^ja-Q0401

**ja-Q0402 · Explain the grammar**

食事ですよ。今、いき【ます】。

Dinner's ready. I'm coming.

[[Japanese#^ja-Q0402-answer|Compare the answer]]
^ja-Q0402

**ja-Q0403 · Fill the gap**

列車は時刻通りに出____か。

Will the train leave on time?

[[Japanese#^ja-Q0403-answer|Compare the answer]]
^ja-Q0403

**ja-Q0404 · Choose the form**

列車は時刻通りに出____か。

Will the train leave on time?

Choices: ましょう / ました / ません / ます

[[Japanese#^ja-Q0404-answer|Compare the answer]]
^ja-Q0404

**ja-Q0405 · Edit the changed sentence**

私は東京までの往復券を持ってい【ました】。

I have a round trip ticket to Tokyo.

[[Japanese#^ja-Q0405-answer|Compare the answer]]
^ja-Q0405

**ja-Q0406 · Build the sentence**

Arrange: ます / 私は東京までの往復券を持ってい / 。

I have a round trip ticket to Tokyo.

[[Japanese#^ja-Q0406-answer|Compare the answer]]
^ja-Q0406

**ja-Q0407 · Write a translation**

Write this in Japanese: Have you been in Japan since last month?

[[Japanese#^ja-Q0407-answer|Compare the answer]]
^ja-Q0407

**ja-Q0408 · Explain the grammar**

あなたは先月から日本にい【ます】か。

Have you been in Japan since last month?

[[Japanese#^ja-Q0408-answer|Compare the answer]]
^ja-Q0408

**ja-Q0409 · Fill the gap**

トムはどれくらいボストンに住んでい____か?

How long has Tom lived in Boston?

[[Japanese#^ja-Q0409-answer|Compare the answer]]
^ja-Q0409

**ja-Q0410 · Choose the form**

トムはどれくらいボストンに住んでい____か?

How long has Tom lived in Boston?

Choices: ました / ません / ます / ましょう

[[Japanese#^ja-Q0410-answer|Compare the answer]]
^ja-Q0410

**ja-Q0411 · Edit the changed sentence**

あなたには賛成しかね【ました】。

I cannot agree with you.

[[Japanese#^ja-Q0411-answer|Compare the answer]]
^ja-Q0411

**ja-Q0412 · Build the sentence**

Arrange: ます / 。 / あなたには賛成しかね

I cannot agree with you.

[[Japanese#^ja-Q0412-answer|Compare the answer]]
^ja-Q0412

**ja-Q0413 · Write a translation**

Write this in Japanese: He will be back in a day or two.

[[Japanese#^ja-Q0413-answer|Compare the answer]]
^ja-Q0413

**ja-Q0414 · Explain the grammar**

彼は１日か２日で帰ってき【ます】。

He will be back in a day or two.

[[Japanese#^ja-Q0414-answer|Compare the answer]]
^ja-Q0414

**ja-Q0415 · Fill the gap**

あなたは中国語を話せ____か？

Can you speak Chinese?

[[Japanese#^ja-Q0415-answer|Compare the answer]]
^ja-Q0415

**ja-Q0416 · Choose the form**

あなたは中国語を話せ____か？

Can you speak Chinese?

Choices: ましょう / ます / ません / ました

[[Japanese#^ja-Q0416-answer|Compare the answer]]
^ja-Q0416

**ja-Q0417 · Edit the changed sentence**

ここに原子力発電所があり【ました】。

Here is an atomic power plant.

[[Japanese#^ja-Q0417-answer|Compare the answer]]
^ja-Q0417

**ja-Q0418 · Build the sentence**

Arrange: ます / 。 / ここに原子力発電所があり

Here is an atomic power plant.

[[Japanese#^ja-Q0418-answer|Compare the answer]]
^ja-Q0418

**ja-Q0419 · Write a translation**

Write this in Japanese: There is a man at the door who wants to see you.

[[Japanese#^ja-Q0419-answer|Compare the answer]]
^ja-Q0419

**ja-Q0420 · Explain the grammar**

あなたに会いたがっている人が玄関にい【ます】。

There is a man at the door who wants to see you.

[[Japanese#^ja-Q0420-answer|Compare the answer]]
^ja-Q0420

**ja-Q0421 · Fill the gap**

色は何色あり____か。

How many colors are there?

[[Japanese#^ja-Q0421-answer|Compare the answer]]
^ja-Q0421

**ja-Q0422 · Choose the form**

色は何色あり____か。

How many colors are there?

Choices: ません / ました / ます / ましょう

[[Japanese#^ja-Q0422-answer|Compare the answer]]
^ja-Q0422

**ja-Q0423 · Edit the changed sentence**

私はここで泳ぐことができ【ました】。

I am able to swim here.

[[Japanese#^ja-Q0423-answer|Compare the answer]]
^ja-Q0423

**ja-Q0424 · Build the sentence**

Arrange: 。 / 私はここで泳ぐことができ / ます

I am able to swim here.

[[Japanese#^ja-Q0424-answer|Compare the answer]]
^ja-Q0424

**ja-Q0425 · Write a translation**

Write this in Japanese: My daughter, Kate, won a singing competition and I'm proud of her.

[[Japanese#^ja-Q0425-answer|Compare the answer]]
^ja-Q0425

**ja-Q0426 · Explain the grammar**

私の娘のケイトは歌のコンテストで賞を取りました。私は彼女を誇りに思い【ます】。

My daughter, Kate, won a singing competition and I'm proud of her.

[[Japanese#^ja-Q0426-answer|Compare the answer]]
^ja-Q0426

**ja-Q0427 · Fill the gap**

２ヶ月に１度メーターを検査し____。

We read the meter once every two months.

[[Japanese#^ja-Q0427-answer|Compare the answer]]
^ja-Q0427

**ja-Q0428 · Choose the form**

２ヶ月に１度メーターを検査し____。

We read the meter once every two months.

Choices: ません / ます / ましょう / ました

[[Japanese#^ja-Q0428-answer|Compare the answer]]
^ja-Q0428

**ja-Q0429 · Edit the changed sentence**

授業は毎日九時に始まり【ました】。

Classes start at nine o'clock every day.

[[Japanese#^ja-Q0429-answer|Compare the answer]]
^ja-Q0429

**ja-Q0430 · Build the sentence**

Arrange: 。 / ます / 授業は毎日九時に始まり

Classes start at nine o'clock every day.

[[Japanese#^ja-Q0430-answer|Compare the answer]]
^ja-Q0430

**ja-Q0431 · Write a translation**

Write this in Japanese: There is no hurry; you have five days to think the matter over.

[[Japanese#^ja-Q0431-answer|Compare the answer]]
^ja-Q0431

**ja-Q0432 · Explain the grammar**

急ぐ必要はありません。そのことはまだ５日間よく考えられ【ます】。

There is no hurry; you have five days to think the matter over.

[[Japanese#^ja-Q0432-answer|Compare the answer]]
^ja-Q0432

**ja-Q0433 · Fill the gap**

1時間ほどお待ちいただけ____か？

Can you wait about an hour?

[[Japanese#^ja-Q0433-answer|Compare the answer]]
^ja-Q0433

**ja-Q0434 · Choose the form**

1時間ほどお待ちいただけ____か？

Can you wait about an hour?

Choices: ましょう / ます / ません / ました

[[Japanese#^ja-Q0434-answer|Compare the answer]]
^ja-Q0434

**ja-Q0435 · Edit the changed sentence**

お宅の暖房はどのようにしてい【ました】か。

How do you heat the house?

[[Japanese#^ja-Q0435-answer|Compare the answer]]
^ja-Q0435

**ja-Q0436 · Build the sentence**

Arrange: お宅の暖房はどのようにしてい / か。 / ます

How do you heat the house?

[[Japanese#^ja-Q0436-answer|Compare the answer]]
^ja-Q0436

**ja-Q0437 · Write a translation**

Write this in Japanese: That soil is rich in humus.

[[Japanese#^ja-Q0437-answer|Compare the answer]]
^ja-Q0437

**ja-Q0438 · Explain the grammar**

その土壌は腐植に富んでい【ます】。

That soil is rich in humus.

[[Japanese#^ja-Q0438-answer|Compare the answer]]
^ja-Q0438

**ja-Q0439 · Fill the gap**

何故彼は失業したと思い____か。

What do you think caused him to lose his job?

[[Japanese#^ja-Q0439-answer|Compare the answer]]
^ja-Q0439

**ja-Q0440 · Choose the form**

何故彼は失業したと思い____か。

What do you think caused him to lose his job?

Choices: ました / ます / ましょう / ません

[[Japanese#^ja-Q0440-answer|Compare the answer]]
^ja-Q0440

**ja-Q0441 · Edit the changed sentence**

来月このアパートから引っ越し【ました】。

We're moving out of this apartment next month.

[[Japanese#^ja-Q0441-answer|Compare the answer]]
^ja-Q0441

**ja-Q0442 · Build the sentence**

Arrange: 来月このアパートから引っ越し / 。 / ます

We're moving out of this apartment next month.

[[Japanese#^ja-Q0442-answer|Compare the answer]]
^ja-Q0442

**ja-Q0443 · Write a translation**

Write this in Japanese: We have extracurricular activities after school.

[[Japanese#^ja-Q0443-answer|Compare the answer]]
^ja-Q0443

**ja-Q0444 · Explain the grammar**

放課後にはクラブ活動があり【ます】。

We have extracurricular activities after school.

[[Japanese#^ja-Q0444-answer|Compare the answer]]
^ja-Q0444

**ja-Q0445 · Fill the gap**

あなたは新しい家に満足して____か。

Are you pleased with your new house?

[[Japanese#^ja-Q0445-answer|Compare the answer]]
^ja-Q0445

**ja-Q0446 · Choose the form**

あなたは新しい家に満足して____か。

Are you pleased with your new house?

Choices: ません / ました / ましょう / ます

[[Japanese#^ja-Q0446-answer|Compare the answer]]
^ja-Q0446

**ja-Q0447 · Edit the changed sentence**

値段には消費税を含み【ました】。

The price includes the consumption tax.

[[Japanese#^ja-Q0447-answer|Compare the answer]]
^ja-Q0447

**ja-Q0448 · Build the sentence**

Arrange: 値段には消費税を含み / 。 / ます

The price includes the consumption tax.

[[Japanese#^ja-Q0448-answer|Compare the answer]]
^ja-Q0448

**ja-Q0449 · Write a translation**

Write this in Japanese: Today's movie is The Sound of Music.

[[Japanese#^ja-Q0449-answer|Compare the answer]]
^ja-Q0449

**ja-Q0450 · Explain the grammar**

本日の映画は「サウンド・オブ・ミュージック」でござい【ます】。

Today's movie is The Sound of Music.

[[Japanese#^ja-Q0450-answer|Compare the answer]]
^ja-Q0450


### Polite past ending · 50 questions

**ja-Q0451 · Fill the gap**

ガソリンスタンドを探しましょう。燃料がなくなってしまい____。

Let's find a gas station; we've run out of fuel.

[[Japanese#^ja-Q0451-answer|Compare the answer]]
^ja-Q0451

**ja-Q0452 · Choose the form**

ガソリンスタンドを探しましょう。燃料がなくなってしまい____。

Let's find a gas station; we've run out of fuel.

Choices: ます / ました / ません

[[Japanese#^ja-Q0452-answer|Compare the answer]]
^ja-Q0452

**ja-Q0453 · Edit the changed sentence**

こつが飲み込め【ます】か。

Got the hang of it?

[[Japanese#^ja-Q0453-answer|Compare the answer]]
^ja-Q0453

**ja-Q0454 · Build the sentence**

Arrange: こつが飲み込め / か。 / ました

Got the hang of it?

[[Japanese#^ja-Q0454-answer|Compare the answer]]
^ja-Q0454

**ja-Q0455 · Write a translation**

Write this in Japanese: I went to the park to play.

[[Japanese#^ja-Q0455-answer|Compare the answer]]
^ja-Q0455

**ja-Q0456 · Explain the grammar**

私は遊ぶために公園へ行き【ました】。

I went to the park to play.

[[Japanese#^ja-Q0456-answer|Compare the answer]]
^ja-Q0456

**ja-Q0457 · Fill the gap**

いつゴルフを始め____か?

When did you start playing golf?

[[Japanese#^ja-Q0457-answer|Compare the answer]]
^ja-Q0457

**ja-Q0458 · Choose the form**

いつゴルフを始め____か?

When did you start playing golf?

Choices: ます / ました / ません

[[Japanese#^ja-Q0458-answer|Compare the answer]]
^ja-Q0458

**ja-Q0459 · Edit the changed sentence**

彼は昨年京都を訪問し【ます】。

He visited Kyoto last year.

[[Japanese#^ja-Q0459-answer|Compare the answer]]
^ja-Q0459

**ja-Q0460 · Build the sentence**

Arrange: ました / 。 / 彼は昨年京都を訪問し

He visited Kyoto last year.

[[Japanese#^ja-Q0460-answer|Compare the answer]]
^ja-Q0460

**ja-Q0461 · Write a translation**

Write this in Japanese: I was worried about my mistakes at first.

[[Japanese#^ja-Q0461-answer|Compare the answer]]
^ja-Q0461

**ja-Q0462 · Explain the grammar**

初めのうちは私は自分の誤りが気になり【ました】。

I was worried about my mistakes at first.

[[Japanese#^ja-Q0462-answer|Compare the answer]]
^ja-Q0462

**ja-Q0463 · Fill the gap**

自動車の売れ行きは年度末に後退し____。

Automobile sales suffered a setback at the end of the financial year.

[[Japanese#^ja-Q0463-answer|Compare the answer]]
^ja-Q0463

**ja-Q0464 · Choose the form**

自動車の売れ行きは年度末に後退し____。

Automobile sales suffered a setback at the end of the financial year.

Choices: ます / ません / ました

[[Japanese#^ja-Q0464-answer|Compare the answer]]
^ja-Q0464

**ja-Q0465 · Edit the changed sentence**

ガーデニングの本を見てたら、ドクロマークのついたのがいっぱいあって驚き【ます】。

When I looked in a gardening book I was surprised by how many were marked poisonous.

[[Japanese#^ja-Q0465-answer|Compare the answer]]
^ja-Q0465

**ja-Q0466 · Build the sentence**

Arrange: ました / 。 / ガーデニングの本を見てたら、ドクロマークのついたのがいっぱいあって驚き

When I looked in a gardening book I was surprised by how many were marked poisonous.

[[Japanese#^ja-Q0466-answer|Compare the answer]]
^ja-Q0466

**ja-Q0467 · Write a translation**

Write this in Japanese: I've dreamed of this day.

[[Japanese#^ja-Q0467-answer|Compare the answer]]
^ja-Q0467

**ja-Q0468 · Explain the grammar**

この日が来るのを夢見てい【ました】。

I've dreamed of this day.

[[Japanese#^ja-Q0468-answer|Compare the answer]]
^ja-Q0468

**ja-Q0469 · Fill the gap**

ご依頼の件、承知し____。

I am willing to agree to your request.

[[Japanese#^ja-Q0469-answer|Compare the answer]]
^ja-Q0469

**ja-Q0470 · Choose the form**

ご依頼の件、承知し____。

I am willing to agree to your request.

Choices: ました / ません / ます

[[Japanese#^ja-Q0470-answer|Compare the answer]]
^ja-Q0470

**ja-Q0471 · Edit the changed sentence**

寮生活には慣れ【ます】か。

Have you got used to living in the dorm?

[[Japanese#^ja-Q0471-answer|Compare the answer]]
^ja-Q0471

**ja-Q0472 · Build the sentence**

Arrange: ました / か。 / 寮生活には慣れ

Have you got used to living in the dorm?

[[Japanese#^ja-Q0472-answer|Compare the answer]]
^ja-Q0472

**ja-Q0473 · Write a translation**

Write this in Japanese: I have already written a letter.

[[Japanese#^ja-Q0473-answer|Compare the answer]]
^ja-Q0473

**ja-Q0474 · Explain the grammar**

私はもう手紙を書いてしまい【ました】。

I have already written a letter.

[[Japanese#^ja-Q0474-answer|Compare the answer]]
^ja-Q0474

**ja-Q0475 · Fill the gap**

母はパンを買いに町へいき____。

Mother went to town to get some bread.

[[Japanese#^ja-Q0475-answer|Compare the answer]]
^ja-Q0475

**ja-Q0476 · Choose the form**

母はパンを買いに町へいき____。

Mother went to town to get some bread.

Choices: ました / ます / ません

[[Japanese#^ja-Q0476-answer|Compare the answer]]
^ja-Q0476

**ja-Q0477 · Edit the changed sentence**

トムはメアリーについてあなたに話し【ます】か。

Did Tom talk to you about Mary?

[[Japanese#^ja-Q0477-answer|Compare the answer]]
^ja-Q0477

**ja-Q0478 · Build the sentence**

Arrange: ました / か。 / トムはメアリーについてあなたに話し

Did Tom talk to you about Mary?

[[Japanese#^ja-Q0478-answer|Compare the answer]]
^ja-Q0478

**ja-Q0479 · Write a translation**

Write this in Japanese: Tom and Jane got married last month.

[[Japanese#^ja-Q0479-answer|Compare the answer]]
^ja-Q0479

**ja-Q0480 · Explain the grammar**

トムとジェーンは先月結婚し【ました】。

Tom and Jane got married last month.

[[Japanese#^ja-Q0480-answer|Compare the answer]]
^ja-Q0480

**ja-Q0481 · Fill the gap**

あなたが外出している間にこの手紙が着き____。

This letter arrived while you were out.

[[Japanese#^ja-Q0481-answer|Compare the answer]]
^ja-Q0481

**ja-Q0482 · Choose the form**

あなたが外出している間にこの手紙が着き____。

This letter arrived while you were out.

Choices: ます / ました / ません

[[Japanese#^ja-Q0482-answer|Compare the answer]]
^ja-Q0482

**ja-Q0483 · Edit the changed sentence**

あなたは昨晩疲れてい【ます】か。

Were you tired last night?

[[Japanese#^ja-Q0483-answer|Compare the answer]]
^ja-Q0483

**ja-Q0484 · Build the sentence**

Arrange: あなたは昨晩疲れてい / か。 / ました

Were you tired last night?

[[Japanese#^ja-Q0484-answer|Compare the answer]]
^ja-Q0484

**ja-Q0485 · Write a translation**

Write this in Japanese: How many staff members filed to change departments?

[[Japanese#^ja-Q0485-answer|Compare the answer]]
^ja-Q0485

**ja-Q0486 · Explain the grammar**

何人社員が転部を申し込んでき【ました】か。

How many staff members filed to change departments?

[[Japanese#^ja-Q0486-answer|Compare the answer]]
^ja-Q0486

**ja-Q0487 · Fill the gap**

今シーズン、インフルエンザの予防接種は受け____か？

Did you receive your flu shot this season?

[[Japanese#^ja-Q0487-answer|Compare the answer]]
^ja-Q0487

**ja-Q0488 · Choose the form**

今シーズン、インフルエンザの予防接種は受け____か？

Did you receive your flu shot this season?

Choices: ました / ます / ません

[[Japanese#^ja-Q0488-answer|Compare the answer]]
^ja-Q0488

**ja-Q0489 · Edit the changed sentence**

あなたはきのう放課後まっすぐ帰宅し【ます】か。

Did you go straight home after school yesterday?

[[Japanese#^ja-Q0489-answer|Compare the answer]]
^ja-Q0489

**ja-Q0490 · Build the sentence**

Arrange: か。 / ました / あなたはきのう放課後まっすぐ帰宅し

Did you go straight home after school yesterday?

[[Japanese#^ja-Q0490-answer|Compare the answer]]
^ja-Q0490

**ja-Q0491 · Write a translation**

Write this in Japanese: Her laughter echoed through the house.

[[Japanese#^ja-Q0491-answer|Compare the answer]]
^ja-Q0491

**ja-Q0492 · Explain the grammar**

彼女の笑い声が家にこだ【ました】。

Her laughter echoed through the house.

[[Japanese#^ja-Q0492-answer|Compare the answer]]
^ja-Q0492

**ja-Q0493 · Fill the gap**

山田氏は大変親切だったので、私を車で家まで送ってくれ____。

Mr Yamada was kind enough to drive me home.

[[Japanese#^ja-Q0493-answer|Compare the answer]]
^ja-Q0493

**ja-Q0494 · Choose the form**

山田氏は大変親切だったので、私を車で家まで送ってくれ____。

Mr Yamada was kind enough to drive me home.

Choices: ません / ます / ました

[[Japanese#^ja-Q0494-answer|Compare the answer]]
^ja-Q0494

**ja-Q0495 · Edit the changed sentence**

万次郎はこの二国をお互いに親しくするために一役果たし【ます】。

Manjiro played a part in making the two countries friends with each other.

[[Japanese#^ja-Q0495-answer|Compare the answer]]
^ja-Q0495

**ja-Q0496 · Build the sentence**

Arrange: 万次郎はこの二国をお互いに親しくするために一役果たし / 。 / ました

Manjiro played a part in making the two countries friends with each other.

[[Japanese#^ja-Q0496-answer|Compare the answer]]
^ja-Q0496

**ja-Q0497 · Write a translation**

Write this in Japanese: I met my teacher on the street the other day.

[[Japanese#^ja-Q0497-answer|Compare the answer]]
^ja-Q0497

**ja-Q0498 · Explain the grammar**

こないだ先生と道で会い【ました】。

I met my teacher on the street the other day.

[[Japanese#^ja-Q0498-answer|Compare the answer]]
^ja-Q0498

**ja-Q0499 · Fill the gap**

最近、胸の痛みはあり____か？

Have you had chest pain recently?

[[Japanese#^ja-Q0499-answer|Compare the answer]]
^ja-Q0499

**ja-Q0500 · Choose the form**

最近、胸の痛みはあり____か？

Have you had chest pain recently?

Choices: ました / ません / ます

[[Japanese#^ja-Q0500-answer|Compare the answer]]
^ja-Q0500


### Polite negation · 50 questions

**ja-Q0501 · Edit the changed sentence**

彼女は私にお金を返してくれ【ます】でした。

She didn't give me my money back.

[[Japanese#^ja-Q0501-answer|Compare the answer]]
^ja-Q0501

**ja-Q0502 · Build the sentence**

Arrange: でした。 / ません / 彼女は私にお金を返してくれ

She didn't give me my money back.

[[Japanese#^ja-Q0502-answer|Compare the answer]]
^ja-Q0502

**ja-Q0503 · Write a translation**

Write this in Japanese: Could you tell me how to get to the station?

[[Japanese#^ja-Q0503-answer|Compare the answer]]
^ja-Q0503

**ja-Q0504 · Explain the grammar**

駅までの行き方を教えていただけ【ません】か。

Could you tell me how to get to the station?

[[Japanese#^ja-Q0504-answer|Compare the answer]]
^ja-Q0504

**ja-Q0505 · Fill the gap**

抜歯しなければなり____。

Your tooth must be extracted.

[[Japanese#^ja-Q0505-answer|Compare the answer]]
^ja-Q0505

**ja-Q0506 · Choose the form**

抜歯しなければなり____。

Your tooth must be extracted.

Choices: ます / ません / ました

[[Japanese#^ja-Q0506-answer|Compare the answer]]
^ja-Q0506

**ja-Q0507 · Edit the changed sentence**

私は今ではそれについてなにも覚えてい【ます】。

I have no remembrance of it now.

[[Japanese#^ja-Q0507-answer|Compare the answer]]
^ja-Q0507

**ja-Q0508 · Build the sentence**

Arrange: 。 / ません / 私は今ではそれについてなにも覚えてい

I have no remembrance of it now.

[[Japanese#^ja-Q0508-answer|Compare the answer]]
^ja-Q0508

**ja-Q0509 · Write a translation**

Write this in Japanese: He is not a doctor.

[[Japanese#^ja-Q0509-answer|Compare the answer]]
^ja-Q0509

**ja-Q0510 · Explain the grammar**

彼は医者ではあり【ません】。

He is not a doctor.

[[Japanese#^ja-Q0510-answer|Compare the answer]]
^ja-Q0510

**ja-Q0511 · Fill the gap**

あまり彼に会い____。

I don't see much of him.

[[Japanese#^ja-Q0511-answer|Compare the answer]]
^ja-Q0511

**ja-Q0512 · Choose the form**

あまり彼に会い____。

I don't see much of him.

Choices: ました / ます / ません

[[Japanese#^ja-Q0512-answer|Compare the answer]]
^ja-Q0512

**ja-Q0513 · Edit the changed sentence**

あなたのおっしゃることが、どうもよく分かり【ます】。

I don't quite follow you.

[[Japanese#^ja-Q0513-answer|Compare the answer]]
^ja-Q0513

**ja-Q0514 · Build the sentence**

Arrange: ません / あなたのおっしゃることが、どうもよく分かり / 。

I don't quite follow you.

[[Japanese#^ja-Q0514-answer|Compare the answer]]
^ja-Q0514

**ja-Q0515 · Write a translation**

Write this in Japanese: It's cold. Could you close the window?

[[Japanese#^ja-Q0515-answer|Compare the answer]]
^ja-Q0515

**ja-Q0516 · Explain the grammar**

寒いです。どうか窓を閉めてください【ません】か。

It's cold. Could you close the window?

[[Japanese#^ja-Q0516-answer|Compare the answer]]
^ja-Q0516

**ja-Q0517 · Fill the gap**

トムがボストンに到着してから、まだ三週間は経ってい____。

Tom arrived in Boston less than three weeks ago.

[[Japanese#^ja-Q0517-answer|Compare the answer]]
^ja-Q0517

**ja-Q0518 · Choose the form**

トムがボストンに到着してから、まだ三週間は経ってい____。

Tom arrived in Boston less than three weeks ago.

Choices: ます / ません / ました

[[Japanese#^ja-Q0518-answer|Compare the answer]]
^ja-Q0518

**ja-Q0519 · Edit the changed sentence**

そんなに遅くまで外出していてはいけ【ます】。

You mustn't stay out that late.

[[Japanese#^ja-Q0519-answer|Compare the answer]]
^ja-Q0519

**ja-Q0520 · Build the sentence**

Arrange: ません / 。 / そんなに遅くまで外出していてはいけ

You mustn't stay out that late.

[[Japanese#^ja-Q0520-answer|Compare the answer]]
^ja-Q0520

**ja-Q0521 · Write a translation**

Write this in Japanese: I don't know if I have enough money.

[[Japanese#^ja-Q0521-answer|Compare the answer]]
^ja-Q0521

**ja-Q0522 · Explain the grammar**

十分にお金があるかわかり【ません】。

I don't know if I have enough money.

[[Japanese#^ja-Q0522-answer|Compare the answer]]
^ja-Q0522

**ja-Q0523 · Fill the gap**

ペンがなければ鉛筆でもかまい____。

If you don't have a pen, use a pencil.

[[Japanese#^ja-Q0523-answer|Compare the answer]]
^ja-Q0523

**ja-Q0524 · Choose the form**

ペンがなければ鉛筆でもかまい____。

If you don't have a pen, use a pencil.

Choices: ました / ません / ます

[[Japanese#^ja-Q0524-answer|Compare the answer]]
^ja-Q0524

**ja-Q0525 · Edit the changed sentence**

すみ【ます】が、郵便局はどこでしょうか。

Excuse me, but could you tell me where the post office is?

[[Japanese#^ja-Q0525-answer|Compare the answer]]
^ja-Q0525

**ja-Q0526 · Build the sentence**

Arrange: すみ / が、郵便局はどこでしょうか。 / ません

Excuse me, but could you tell me where the post office is?

[[Japanese#^ja-Q0526-answer|Compare the answer]]
^ja-Q0526

**ja-Q0527 · Write a translation**

Write this in Japanese: I don't know exactly where Kyoko lives, but it's in the direction of Sannomiya.

[[Japanese#^ja-Q0527-answer|Compare the answer]]
^ja-Q0527

**ja-Q0528 · Explain the grammar**

京子がどこに住んでいるのか正確にはしり【ません】が、三ノ宮の方です。

I don't know exactly where Kyoko lives, but it's in the direction of Sannomiya.

[[Japanese#^ja-Q0528-answer|Compare the answer]]
^ja-Q0528

**ja-Q0529 · Fill the gap**

そのことについてもう少し例をあげてくれ____か。

Could you please give me some more examples of that?

[[Japanese#^ja-Q0529-answer|Compare the answer]]
^ja-Q0529

**ja-Q0530 · Choose the form**

そのことについてもう少し例をあげてくれ____か。

Could you please give me some more examples of that?

Choices: ません / ます / ました

[[Japanese#^ja-Q0530-answer|Compare the answer]]
^ja-Q0530

**ja-Q0531 · Edit the changed sentence**

溶岩を地理学的に説明してくれ【ます】か。

Can you give me a geological explanation of lava?

[[Japanese#^ja-Q0531-answer|Compare the answer]]
^ja-Q0531

**ja-Q0532 · Build the sentence**

Arrange: か。 / ません / 溶岩を地理学的に説明してくれ

Can you give me a geological explanation of lava?

[[Japanese#^ja-Q0532-answer|Compare the answer]]
^ja-Q0532

**ja-Q0533 · Write a translation**

Write this in Japanese: Don't put off answering the letter.

[[Japanese#^ja-Q0533-answer|Compare the answer]]
^ja-Q0533

**ja-Q0534 · Explain the grammar**

手紙の返事を延ばしてはいけ【ません】。

Don't put off answering the letter.

[[Japanese#^ja-Q0534-answer|Compare the answer]]
^ja-Q0534

**ja-Q0535 · Fill the gap**

糸車の使い方は知り____。

I don't know how to operate a spinning wheel.

[[Japanese#^ja-Q0535-answer|Compare the answer]]
^ja-Q0535

**ja-Q0536 · Choose the form**

糸車の使い方は知り____。

I don't know how to operate a spinning wheel.

Choices: ます / ました / ません

[[Japanese#^ja-Q0536-answer|Compare the answer]]
^ja-Q0536

**ja-Q0537 · Edit the changed sentence**

会議室の椅子が足り【ます】。

There are not enough chairs in the meeting room.

[[Japanese#^ja-Q0537-answer|Compare the answer]]
^ja-Q0537

**ja-Q0538 · Build the sentence**

Arrange: 。 / 会議室の椅子が足り / ません

There are not enough chairs in the meeting room.

[[Japanese#^ja-Q0538-answer|Compare the answer]]
^ja-Q0538

**ja-Q0539 · Write a translation**

Write this in Japanese: Why don't you try on this yellow sweater?

[[Japanese#^ja-Q0539-answer|Compare the answer]]
^ja-Q0539

**ja-Q0540 · Explain the grammar**

この黄色いセーターを着てみ【ません】か。

Why don't you try on this yellow sweater?

[[Japanese#^ja-Q0540-answer|Compare the answer]]
^ja-Q0540

**ja-Q0541 · Fill the gap**

今晩一緒に食事をし____か。

Why don't you have dinner with me tonight?

[[Japanese#^ja-Q0541-answer|Compare the answer]]
^ja-Q0541

**ja-Q0542 · Choose the form**

今晩一緒に食事をし____か。

Why don't you have dinner with me tonight?

Choices: ました / ます / ません

[[Japanese#^ja-Q0542-answer|Compare the answer]]
^ja-Q0542

**ja-Q0543 · Edit the changed sentence**

トイレの水が流れ【ます】。

The toilet doesn't flush.

[[Japanese#^ja-Q0543-answer|Compare the answer]]
^ja-Q0543

**ja-Q0544 · Build the sentence**

Arrange: ません / 。 / トイレの水が流れ

The toilet doesn't flush.

[[Japanese#^ja-Q0544-answer|Compare the answer]]
^ja-Q0544

**ja-Q0545 · Write a translation**

Write this in Japanese: If you are to succeed, you must work harder.

[[Japanese#^ja-Q0545-answer|Compare the answer]]
^ja-Q0545

**ja-Q0546 · Explain the grammar**

もしあなたが成功したいなら、もっと働かなければなり【ません】。

If you are to succeed, you must work harder.

[[Japanese#^ja-Q0546-answer|Compare the answer]]
^ja-Q0546

**ja-Q0547 · Fill the gap**

はっきり言うと、私は彼と一緒に働きたくあり____。

Frankly speaking, I don't want to work with him.

[[Japanese#^ja-Q0547-answer|Compare the answer]]
^ja-Q0547

**ja-Q0548 · Choose the form**

はっきり言うと、私は彼と一緒に働きたくあり____。

Frankly speaking, I don't want to work with him.

Choices: ます / ました / ません

[[Japanese#^ja-Q0548-answer|Compare the answer]]
^ja-Q0548

**ja-Q0549 · Edit the changed sentence**

彼女がどうしてその犯罪に及んだかという動機については、いまだによくわかり【ます】。

They still haven't been able to work out quite what her motive was for resorting to crime.

[[Japanese#^ja-Q0549-answer|Compare the answer]]
^ja-Q0549

**ja-Q0550 · Build the sentence**

Arrange: 。 / ません / 彼女がどうしてその犯罪に及んだかという動機については、いまだによくわかり

They still haven't been able to work out quite what her motive was for resorting to crime.

[[Japanese#^ja-Q0550-answer|Compare the answer]]
^ja-Q0550


### Plain negation · 50 questions

**ja-Q0551 · Write a translation**

Write this in Japanese: The ones who shout at me don't bother me.

[[Japanese#^ja-Q0551-answer|Compare the answer]]
^ja-Q0551

**ja-Q0552 · Explain the grammar**

私をどなり散らす人は気になら【ない】わ。

The ones who shout at me don't bother me.

[[Japanese#^ja-Q0552-answer|Compare the answer]]
^ja-Q0552

**ja-Q0553 · Fill the gap**

そのなぞなぞの解き方が解ら____。

I can't figure out how to solve the puzzle.

[[Japanese#^ja-Q0553-answer|Compare the answer]]
^ja-Q0553

**ja-Q0554 · Choose the form**

そのなぞなぞの解き方が解ら____。

I can't figure out how to solve the puzzle.

Choices: ます / ない / た

[[Japanese#^ja-Q0554-answer|Compare the answer]]
^ja-Q0554

**ja-Q0555 · Edit the changed sentence**

なんで傘さしてんの？ 雨降って【た】よ。

Why do you have your umbrella up? It's not raining.

[[Japanese#^ja-Q0555-answer|Compare the answer]]
^ja-Q0555

**ja-Q0556 · Build the sentence**

Arrange: ない / よ。 / なんで傘さしてんの？ 雨降って

Why do you have your umbrella up? It's not raining.

[[Japanese#^ja-Q0556-answer|Compare the answer]]
^ja-Q0556

**ja-Q0557 · Write a translation**

Write this in Japanese: This bird cannot fly.

[[Japanese#^ja-Q0557-answer|Compare the answer]]
^ja-Q0557

**ja-Q0558 · Explain the grammar**

この鳥は飛ぶことができ【ない】。

This bird cannot fly.

[[Japanese#^ja-Q0558-answer|Compare the answer]]
^ja-Q0558

**ja-Q0559 · Fill the gap**

私達は今あるもので我慢しなければなら____。

We have to make the best of what we have.

[[Japanese#^ja-Q0559-answer|Compare the answer]]
^ja-Q0559

**ja-Q0560 · Choose the form**

私達は今あるもので我慢しなければなら____。

We have to make the best of what we have.

Choices: ない / ます / た

[[Japanese#^ja-Q0560-answer|Compare the answer]]
^ja-Q0560

**ja-Q0561 · Edit the changed sentence**

世界はお前中心に回ってるわけじゃ【た】んだよ。

The world doesn't revolve around you.

[[Japanese#^ja-Q0561-answer|Compare the answer]]
^ja-Q0561

**ja-Q0562 · Build the sentence**

Arrange: 世界はお前中心に回ってるわけじゃ / んだよ。 / ない

The world doesn't revolve around you.

[[Japanese#^ja-Q0562-answer|Compare the answer]]
^ja-Q0562

**ja-Q0563 · Write a translation**

Write this in Japanese: Don't cut in with your remarks.

[[Japanese#^ja-Q0563-answer|Compare the answer]]
^ja-Q0563

**ja-Q0564 · Explain the grammar**

あなたの意見をさしはさま【ない】で。

Don't cut in with your remarks.

[[Japanese#^ja-Q0564-answer|Compare the answer]]
^ja-Q0564

**ja-Q0565 · Fill the gap**

僕はこういう音楽が好きでは____。

I'm not keen on this kind of music.

[[Japanese#^ja-Q0565-answer|Compare the answer]]
^ja-Q0565

**ja-Q0566 · Choose the form**

僕はこういう音楽が好きでは____。

I'm not keen on this kind of music.

Choices: た / ない / ます

[[Japanese#^ja-Q0566-answer|Compare the answer]]
^ja-Q0566

**ja-Q0567 · Edit the changed sentence**

金銭は成功を計る基準にはなら【た】。

Money is not a criterion of success.

[[Japanese#^ja-Q0567-answer|Compare the answer]]
^ja-Q0567

**ja-Q0568 · Build the sentence**

Arrange: 。 / ない / 金銭は成功を計る基準にはなら

Money is not a criterion of success.

[[Japanese#^ja-Q0568-answer|Compare the answer]]
^ja-Q0568

**ja-Q0569 · Write a translation**

Write this in Japanese: Don't sit up till late.

[[Japanese#^ja-Q0569-answer|Compare the answer]]
^ja-Q0569

**ja-Q0570 · Explain the grammar**

遅くまで起きていてはいけ【ない】。

Don't sit up till late.

[[Japanese#^ja-Q0570-answer|Compare the answer]]
^ja-Q0570

**ja-Q0571 · Fill the gap**

彼が一番やってきそうに____。

He is least likely to come.

[[Japanese#^ja-Q0571-answer|Compare the answer]]
^ja-Q0571

**ja-Q0572 · Choose the form**

彼が一番やってきそうに____。

He is least likely to come.

Choices: ない / た / ます

[[Japanese#^ja-Q0572-answer|Compare the answer]]
^ja-Q0572

**ja-Q0573 · Edit the changed sentence**

正確な時間に関して、その部屋の時計をあてにしてはいけ【た】。

Do not rely on the room clock for the accurate time of day.

[[Japanese#^ja-Q0573-answer|Compare the answer]]
^ja-Q0573

**ja-Q0574 · Build the sentence**

Arrange: 。 / 正確な時間に関して、その部屋の時計をあてにしてはいけ / ない

Do not rely on the room clock for the accurate time of day.

[[Japanese#^ja-Q0574-answer|Compare the answer]]
^ja-Q0574

**ja-Q0575 · Write a translation**

Write this in Japanese: You need to come to terms with your jealousy of this young man.

[[Japanese#^ja-Q0575-answer|Compare the answer]]
^ja-Q0575

**ja-Q0576 · Explain the grammar**

この若人に対してねたましく思う気持ちを、君はやむを得【ない】ものと受け入れなければならない。

You need to come to terms with your jealousy of this young man.

[[Japanese#^ja-Q0576-answer|Compare the answer]]
^ja-Q0576

**ja-Q0577 · Fill the gap**

だれかがピアノをひいている。アンに違い____。

Somebody is playing the piano. It must be Ann.

[[Japanese#^ja-Q0577-answer|Compare the answer]]
^ja-Q0577

**ja-Q0578 · Choose the form**

だれかがピアノをひいている。アンに違い____。

Somebody is playing the piano. It must be Ann.

Choices: ない / ます / た

[[Japanese#^ja-Q0578-answer|Compare the answer]]
^ja-Q0578

**ja-Q0579 · Edit the changed sentence**

彼は一介の詩人に過ぎ【た】。

He is nothing but a poet.

[[Japanese#^ja-Q0579-answer|Compare the answer]]
^ja-Q0579

**ja-Q0580 · Build the sentence**

Arrange: 。 / 彼は一介の詩人に過ぎ / ない

He is nothing but a poet.

[[Japanese#^ja-Q0580-answer|Compare the answer]]
^ja-Q0580

**ja-Q0581 · Write a translation**

Write this in Japanese: The end of the task is not yet in mind.

[[Japanese#^ja-Q0581-answer|Compare the answer]]
^ja-Q0581

**ja-Q0582 · Explain the grammar**

仕事の終わりはまだ見当がつか【ない】。

The end of the task is not yet in mind.

[[Japanese#^ja-Q0582-answer|Compare the answer]]
^ja-Q0582

**ja-Q0583 · Fill the gap**

僕はあの学校のスクールカラーがすきでは____。

I don't like the atmosphere of that school.

[[Japanese#^ja-Q0583-answer|Compare the answer]]
^ja-Q0583

**ja-Q0584 · Choose the form**

僕はあの学校のスクールカラーがすきでは____。

I don't like the atmosphere of that school.

Choices: ない / た / ます

[[Japanese#^ja-Q0584-answer|Compare the answer]]
^ja-Q0584

**ja-Q0585 · Edit the changed sentence**

彼女が美しいからといって彼女を好きなわけでは【た】。

It is not because she is beautiful that I like her.

[[Japanese#^ja-Q0585-answer|Compare the answer]]
^ja-Q0585

**ja-Q0586 · Build the sentence**

Arrange: ない / 彼女が美しいからといって彼女を好きなわけでは / 。

It is not because she is beautiful that I like her.

[[Japanese#^ja-Q0586-answer|Compare the answer]]
^ja-Q0586

**ja-Q0587 · Write a translation**

Write this in Japanese: In short, I don't want you to work for that company.

[[Japanese#^ja-Q0587-answer|Compare the answer]]
^ja-Q0587

**ja-Q0588 · Explain the grammar**

端的に言うと、私はあなたにその会社で働いて欲しく【ない】。

In short, I don't want you to work for that company.

[[Japanese#^ja-Q0588-answer|Compare the answer]]
^ja-Q0588

**ja-Q0589 · Fill the gap**

父親と比べると彼は深みが____。

As compared with his father, he is lacking in depth.

[[Japanese#^ja-Q0589-answer|Compare the answer]]
^ja-Q0589

**ja-Q0590 · Choose the form**

父親と比べると彼は深みが____。

As compared with his father, he is lacking in depth.

Choices: た / ます / ない

[[Japanese#^ja-Q0590-answer|Compare the answer]]
^ja-Q0590

**ja-Q0591 · Edit the changed sentence**

彼は今一番会いたく【た】人だ。

He is the last person I want to see now.

[[Japanese#^ja-Q0591-answer|Compare the answer]]
^ja-Q0591

**ja-Q0592 · Build the sentence**

Arrange: 人だ。 / ない / 彼は今一番会いたく

He is the last person I want to see now.

[[Japanese#^ja-Q0592-answer|Compare the answer]]
^ja-Q0592

**ja-Q0593 · Write a translation**

Write this in Japanese: I must learn this poem by heart.

[[Japanese#^ja-Q0593-answer|Compare the answer]]
^ja-Q0593

**ja-Q0594 · Explain the grammar**

この詩を暗記しなければなら【ない】。

I must learn this poem by heart.

[[Japanese#^ja-Q0594-answer|Compare the answer]]
^ja-Q0594

**ja-Q0595 · Fill the gap**

ほかの学生に遅れ____ように一生懸命勉強しなければならなかった。

I had to work hard to keep up with the other students.

[[Japanese#^ja-Q0595-answer|Compare the answer]]
^ja-Q0595

**ja-Q0596 · Choose the form**

ほかの学生に遅れ____ように一生懸命勉強しなければならなかった。

I had to work hard to keep up with the other students.

Choices: ない / た / ます

[[Japanese#^ja-Q0596-answer|Compare the answer]]
^ja-Q0596

**ja-Q0597 · Edit the changed sentence**

実を言うと、私は昨日言ったことを全く覚えてい【た】。

To tell the truth, I don't remember anything I said yesterday.

[[Japanese#^ja-Q0597-answer|Compare the answer]]
^ja-Q0597

**ja-Q0598 · Build the sentence**

Arrange: 実を言うと、私は昨日言ったことを全く覚えてい / 。 / ない

To tell the truth, I don't remember anything I said yesterday.

[[Japanese#^ja-Q0598-answer|Compare the answer]]
^ja-Q0598

**ja-Q0599 · Write a translation**

Write this in Japanese: He was admitted to the school without sitting for an examination.

[[Japanese#^ja-Q0599-answer|Compare the answer]]
^ja-Q0599

**ja-Q0600 · Explain the grammar**

彼は試験を受け【ない】でその学校に入学を認められた。

He was admitted to the school without sitting for an examination.

[[Japanese#^ja-Q0600-answer|Compare the answer]]
^ja-Q0600


### Te-form links and requests · 50 questions

**ja-Q0601 · Fill the gap**

私はあなたのぐちには死ぬほどうんざりし____。

I am sick to death of your complaints.

[[Japanese#^ja-Q0601-answer|Compare the answer]]
^ja-Q0601

**ja-Q0602 · Choose the form**

私はあなたのぐちには死ぬほどうんざりし____。

I am sick to death of your complaints.

Choices: ている / てください / ています

[[Japanese#^ja-Q0602-answer|Compare the answer]]
^ja-Q0602

**ja-Q0603 · Edit the changed sentence**

君の成功は主に好機をいかにして上手に利用するかにかかっ【てください】。

Your success will largely depend upon how you will make good use of your opportunity.

[[Japanese#^ja-Q0603-answer|Compare the answer]]
^ja-Q0603

**ja-Q0604 · Build the sentence**

Arrange: 。 / ている / 君の成功は主に好機をいかにして上手に利用するかにかかっ

Your success will largely depend upon how you will make good use of your opportunity.

[[Japanese#^ja-Q0604-answer|Compare the answer]]
^ja-Q0604

**ja-Q0605 · Write a translation**

Write this in Japanese: Diplomats are allowed various privileges.

[[Japanese#^ja-Q0605-answer|Compare the answer]]
^ja-Q0605

**ja-Q0606 · Explain the grammar**

外交官には様々な特権が与えられ【ている】。

Diplomats are allowed various privileges.

[[Japanese#^ja-Q0606-answer|Compare the answer]]
^ja-Q0606

**ja-Q0607 · Fill the gap**

彼はドアが閉まっ____ことに気がついた。

He found the door closed.

[[Japanese#^ja-Q0607-answer|Compare the answer]]
^ja-Q0607

**ja-Q0608 · Choose the form**

彼はドアが閉まっ____ことに気がついた。

He found the door closed.

Choices: てください / ています / ている

[[Japanese#^ja-Q0608-answer|Compare the answer]]
^ja-Q0608

**ja-Q0609 · Edit the changed sentence**

彼はそれについて知っ【てください】様だ。

It seems that he knows about it.

[[Japanese#^ja-Q0609-answer|Compare the answer]]
^ja-Q0609

**ja-Q0610 · Build the sentence**

Arrange: ている / 様だ。 / 彼はそれについて知っ

It seems that he knows about it.

[[Japanese#^ja-Q0610-answer|Compare the answer]]
^ja-Q0610

**ja-Q0611 · Write a translation**

Write this in Japanese: She likes the design on the plate.

[[Japanese#^ja-Q0611-answer|Compare the answer]]
^ja-Q0611

**ja-Q0612 · Explain the grammar**

彼女はその皿の模様が気に入っ【ている】。

She likes the design on the plate.

[[Japanese#^ja-Q0612-answer|Compare the answer]]
^ja-Q0612

**ja-Q0613 · Fill the gap**

あなたが言っ____ことからすれば、彼はそこにいなかったことになる。

It follows from what you say that he was not there.

[[Japanese#^ja-Q0613-answer|Compare the answer]]
^ja-Q0613

**ja-Q0614 · Choose the form**

あなたが言っ____ことからすれば、彼はそこにいなかったことになる。

It follows from what you say that he was not there.

Choices: ています / ている / てください

[[Japanese#^ja-Q0614-answer|Compare the answer]]
^ja-Q0614

**ja-Q0615 · Edit the changed sentence**

駅で私を降ろし【ています】。

Please drop me off at the station.

[[Japanese#^ja-Q0615-answer|Compare the answer]]
^ja-Q0615

**ja-Q0616 · Build the sentence**

Arrange: 。 / てください / 駅で私を降ろし

Please drop me off at the station.

[[Japanese#^ja-Q0616-answer|Compare the answer]]
^ja-Q0616

**ja-Q0617 · Write a translation**

Write this in Japanese: The fly is on the ceiling.

[[Japanese#^ja-Q0617-answer|Compare the answer]]
^ja-Q0617

**ja-Q0618 · Explain the grammar**

ハエが天井にとまっ【ている】。

The fly is on the ceiling.

[[Japanese#^ja-Q0618-answer|Compare the answer]]
^ja-Q0618

**ja-Q0619 · Fill the gap**

彼はたいていうたた寝をし____。

He is taking a nap half the time.

[[Japanese#^ja-Q0619-answer|Compare the answer]]
^ja-Q0619

**ja-Q0620 · Choose the form**

彼はたいていうたた寝をし____。

He is taking a nap half the time.

Choices: ています / てください / ている

[[Japanese#^ja-Q0620-answer|Compare the answer]]
^ja-Q0620

**ja-Q0621 · Edit the changed sentence**

二人の男性が自転車に乗って体をきたえ【てください】。

The men are getting into shape riding bicycles.

[[Japanese#^ja-Q0621-answer|Compare the answer]]
^ja-Q0621

**ja-Q0622 · Build the sentence**

Arrange: ている / 。 / 二人の男性が自転車に乗って体をきたえ

The men are getting into shape riding bicycles.

[[Japanese#^ja-Q0622-answer|Compare the answer]]
^ja-Q0622

**ja-Q0623 · Write a translation**

Write this in Japanese: Medicaid, a program originally created to provide medical care for poverty-level women and children, today spends almost a third of its budget on elderly people.

[[Japanese#^ja-Q0623-answer|Compare the answer]]
^ja-Q0623

**ja-Q0624 · Explain the grammar**

本来は、貧困層の女性や子供に医療保護を提供するために創設された制度である、アメリカ低所得者医療扶助制度が、今日では、その予算の約３分の１を老人に費やし【ている】。

Medicaid, a program originally created to provide medical care for poverty-level women and children, today spends almost a third of its budget on elderly people.

[[Japanese#^ja-Q0624-answer|Compare the answer]]
^ja-Q0624

**ja-Q0625 · Fill the gap**

タイの国民は自国の首都を「クルンテープ」と呼ん____。これは訳すと「天使の都」という意味である。

Thai people call their country's capital Krung Thep. If you translate this it means 'City of Angels'.

[[Japanese#^ja-Q0625-answer|Compare the answer]]
^ja-Q0625

**ja-Q0626 · Choose the form**

タイの国民は自国の首都を「クルンテープ」と呼ん____。これは訳すと「天使の都」という意味である。

Thai people call their country's capital Krung Thep. If you translate this it means 'City of Angels'.

Choices: でいる / ている / ています / てください

[[Japanese#^ja-Q0626-answer|Compare the answer]]
^ja-Q0626

**ja-Q0627 · Edit the changed sentence**

私は数学では彼より劣っ【てください】。

I am inferior to him in mathematics.

[[Japanese#^ja-Q0627-answer|Compare the answer]]
^ja-Q0627

**ja-Q0628 · Build the sentence**

Arrange: 私は数学では彼より劣っ / 。 / ている

I am inferior to him in mathematics.

[[Japanese#^ja-Q0628-answer|Compare the answer]]
^ja-Q0628

**ja-Q0629 · Write a translation**

Write this in Japanese: He's getting along well with all of his classmates.

[[Japanese#^ja-Q0629-answer|Compare the answer]]
^ja-Q0629

**ja-Q0630 · Explain the grammar**

彼はクラスメート全員と上手く付き合っ【ている】。

He's getting along well with all of his classmates.

[[Japanese#^ja-Q0630-answer|Compare the answer]]
^ja-Q0630

**ja-Q0631 · Fill the gap**

道に迷っ____んですか。

Are you lost?

[[Japanese#^ja-Q0631-answer|Compare the answer]]
^ja-Q0631

**ja-Q0632 · Choose the form**

道に迷っ____んですか。

Are you lost?

Choices: ている / ています / てください

[[Japanese#^ja-Q0632-answer|Compare the answer]]
^ja-Q0632

**ja-Q0633 · Edit the changed sentence**

それは彼女でした。彼女はそっと私に忍び寄ろうとし【てください】のです。

That was her. She was trying to creep up on me unnoticed.

[[Japanese#^ja-Q0633-answer|Compare the answer]]
^ja-Q0633

**ja-Q0634 · Build the sentence**

Arrange: それは彼女でした。彼女はそっと私に忍び寄ろうとし / のです。 / ている

That was her. She was trying to creep up on me unnoticed.

[[Japanese#^ja-Q0634-answer|Compare the answer]]
^ja-Q0634

**ja-Q0635 · Write a translation**

Write this in Japanese: Wait here till I come back.

[[Japanese#^ja-Q0635-answer|Compare the answer]]
^ja-Q0635

**ja-Q0636 · Explain the grammar**

帰って来るまでここで待ってい【てください】。

Wait here till I come back.

[[Japanese#^ja-Q0636-answer|Compare the answer]]
^ja-Q0636

**ja-Q0637 · Fill the gap**

私は彼の勝利を確信し____。

I am sure of his victory.

[[Japanese#^ja-Q0637-answer|Compare the answer]]
^ja-Q0637

**ja-Q0638 · Choose the form**

私は彼の勝利を確信し____。

I am sure of his victory.

Choices: てください / ている / ています

[[Japanese#^ja-Q0638-answer|Compare the answer]]
^ja-Q0638

**ja-Q0639 · Edit the changed sentence**

ジェーンはそのパーティーを楽しん【てください】ようにみえる。

Jane appears to be enjoying the party.

[[Japanese#^ja-Q0639-answer|Compare the answer]]
^ja-Q0639

**ja-Q0640 · Build the sentence**

Arrange: ようにみえる。 / ジェーンはそのパーティーを楽しん / でいる

Jane appears to be enjoying the party.

[[Japanese#^ja-Q0640-answer|Compare the answer]]
^ja-Q0640

**ja-Q0641 · Write a translation**

Write this in Japanese: Please think it over and let me know your decision.

[[Japanese#^ja-Q0641-answer|Compare the answer]]
^ja-Q0641

**ja-Q0642 · Explain the grammar**

それについてよく考えて、私に結論を知らせ【てください】。

Please think it over and let me know your decision.

[[Japanese#^ja-Q0642-answer|Compare the answer]]
^ja-Q0642

**ja-Q0643 · Fill the gap**

その問題は私たちに重くのしかかっ____。

The problem bears heavily on us.

[[Japanese#^ja-Q0643-answer|Compare the answer]]
^ja-Q0643

**ja-Q0644 · Choose the form**

その問題は私たちに重くのしかかっ____。

The problem bears heavily on us.

Choices: ている / ています / てください

[[Japanese#^ja-Q0644-answer|Compare the answer]]
^ja-Q0644

**ja-Q0645 · Edit the changed sentence**

日本の女性は平均２６歳で結婚する。出生率が下がっ【てください】のも不思議ではない。

Japanese women marry at 26 on average. It is no mystery that the birthrate is declining.

[[Japanese#^ja-Q0645-answer|Compare the answer]]
^ja-Q0645

**ja-Q0646 · Build the sentence**

Arrange: ている / のも不思議ではない。 / 日本の女性は平均２６歳で結婚する。出生率が下がっ

Japanese women marry at 26 on average. It is no mystery that the birthrate is declining.

[[Japanese#^ja-Q0646-answer|Compare the answer]]
^ja-Q0646

**ja-Q0647 · Write a translation**

Write this in Japanese: Several races live together in America.

[[Japanese#^ja-Q0647-answer|Compare the answer]]
^ja-Q0647

**ja-Q0648 · Explain the grammar**

アメリカにはいくつかの人種が一緒に住ん【でいる】。

Several races live together in America.

[[Japanese#^ja-Q0648-answer|Compare the answer]]
^ja-Q0648

**ja-Q0649 · Fill the gap**

議題に上っ____項目（の議論）を続けましょう。

Let's proceed with the items on the agenda.

[[Japanese#^ja-Q0649-answer|Compare the answer]]
^ja-Q0649

**ja-Q0650 · Choose the form**

議題に上っ____項目（の議論）を続けましょう。

Let's proceed with the items on the agenda.

Choices: てください / ている / ています

[[Japanese#^ja-Q0650-answer|Compare the answer]]
^ja-Q0650


### Plain past and experience · 50 questions

**ja-Q0651 · Edit the changed sentence**

これ見【ている】ある？

Have you seen this?

[[Japanese#^ja-Q0651-answer|Compare the answer]]
^ja-Q0651

**ja-Q0652 · Build the sentence**

Arrange: たこと / これ見 / ある？

Have you seen this?

[[Japanese#^ja-Q0652-answer|Compare the answer]]
^ja-Q0652

**ja-Q0653 · Write a translation**

Write this in Japanese: He was ashamed of his tears.

[[Japanese#^ja-Q0653-answer|Compare the answer]]
^ja-Q0653

**ja-Q0654 · Explain the grammar**

彼は涙を流し【たこと】がはずかしかった。

He was ashamed of his tears.

[[Japanese#^ja-Q0654-answer|Compare the answer]]
^ja-Q0654

**ja-Q0655 · Fill the gap**

お返事が遅れ____をお許し下さい。

Excuse me for not having answered your letter sooner.

[[Japanese#^ja-Q0655-answer|Compare the answer]]
^ja-Q0655

**ja-Q0656 · Choose the form**

お返事が遅れ____をお許し下さい。

Excuse me for not having answered your letter sooner.

Choices: ます / ている / たこと

[[Japanese#^ja-Q0656-answer|Compare the answer]]
^ja-Q0656

**ja-Q0657 · Edit the changed sentence**

次に起こっ【ている】は恐ろしかった。

What happened next was terrible.

[[Japanese#^ja-Q0657-answer|Compare the answer]]
^ja-Q0657

**ja-Q0658 · Build the sentence**

Arrange: は恐ろしかった。 / たこと / 次に起こっ

What happened next was terrible.

[[Japanese#^ja-Q0658-answer|Compare the answer]]
^ja-Q0658

**ja-Q0659 · Write a translation**

Write this in Japanese: I don't really care for that sort of thing.

[[Japanese#^ja-Q0659-answer|Compare the answer]]
^ja-Q0659

**ja-Q0660 · Explain the grammar**

私は実際、そういっ【たこと】は好きではない。

I don't really care for that sort of thing.

[[Japanese#^ja-Q0660-answer|Compare the answer]]
^ja-Q0660

**ja-Q0661 · Fill the gap**

直美は一等賞をとっ____を、とても喜んでいる。

Naomi is very glad about having won first prize.

[[Japanese#^ja-Q0661-answer|Compare the answer]]
^ja-Q0661

**ja-Q0662 · Choose the form**

直美は一等賞をとっ____を、とても喜んでいる。

Naomi is very glad about having won first prize.

Choices: ている / たこと / ます

[[Japanese#^ja-Q0662-answer|Compare the answer]]
^ja-Q0662

**ja-Q0663 · Edit the changed sentence**

トムはメアリーのお金を盗ん【たこと】を認めた。

Tom admitted that he had stolen Mary's money.

[[Japanese#^ja-Q0663-answer|Compare the answer]]
^ja-Q0663

**ja-Q0664 · Build the sentence**

Arrange: だこと / を認めた。 / トムはメアリーのお金を盗ん

Tom admitted that he had stolen Mary's money.

[[Japanese#^ja-Q0664-answer|Compare the answer]]
^ja-Q0664

**ja-Q0665 · Write a translation**

Write this in Japanese: Never have I seen her before.

[[Japanese#^ja-Q0665-answer|Compare the answer]]
^ja-Q0665

**ja-Q0666 · Explain the grammar**

彼女に会っ【たこと】がない。

Never have I seen her before.

[[Japanese#^ja-Q0666-answer|Compare the answer]]
^ja-Q0666

**ja-Q0667 · Fill the gap**

ボストンでは雨が降ってい____か？

Was it raining in Boston?

[[Japanese#^ja-Q0667-answer|Compare the answer]]
^ja-Q0667

**ja-Q0668 · Choose the form**

ボストンでは雨が降ってい____か？

Was it raining in Boston?

Choices: ます / ました / たこと / ている

[[Japanese#^ja-Q0668-answer|Compare the answer]]
^ja-Q0668

**ja-Q0669 · Edit the changed sentence**

彼女が二度結婚し【ている】は本当だった。

It was true that she had got married twice.

[[Japanese#^ja-Q0669-answer|Compare the answer]]
^ja-Q0669

**ja-Q0670 · Build the sentence**

Arrange: たこと / は本当だった。 / 彼女が二度結婚し

It was true that she had got married twice.

[[Japanese#^ja-Q0670-answer|Compare the answer]]
^ja-Q0670

**ja-Q0671 · Write a translation**

Write this in Japanese: I sat down and opened my notebook.

[[Japanese#^ja-Q0671-answer|Compare the answer]]
^ja-Q0671

**ja-Q0672 · Explain the grammar**

腰を下ろし、手帳を開き【ました】。

I sat down and opened my notebook.

[[Japanese#^ja-Q0672-answer|Compare the answer]]
^ja-Q0672

**ja-Q0673 · Fill the gap**

お宅が休暇で出かけている間に、泥棒が入り____。

A burglar broke into your house while you were away on vacation.

[[Japanese#^ja-Q0673-answer|Compare the answer]]
^ja-Q0673

**ja-Q0674 · Choose the form**

お宅が休暇で出かけている間に、泥棒が入り____。

A burglar broke into your house while you were away on vacation.

Choices: たこと / ます / ている / ました

[[Japanese#^ja-Q0674-answer|Compare the answer]]
^ja-Q0674

**ja-Q0675 · Edit the changed sentence**

日焼けし過ぎ【たこと】。

I have a bad sunburn.

[[Japanese#^ja-Q0675-answer|Compare the answer]]
^ja-Q0675

**ja-Q0676 · Build the sentence**

Arrange: 。 / 日焼けし過ぎ / ました

I have a bad sunburn.

[[Japanese#^ja-Q0676-answer|Compare the answer]]
^ja-Q0676

**ja-Q0677 · Write a translation**

Write this in Japanese: She had never seen New York before, so I offered to show her around.

[[Japanese#^ja-Q0677-answer|Compare the answer]]
^ja-Q0677

**ja-Q0678 · Explain the grammar**

彼女はそれまでニューヨークを見学し【たこと】がなかったので、彼女に案内して回りましょうと申し出た。

She had never seen New York before, so I offered to show her around.

[[Japanese#^ja-Q0678-answer|Compare the answer]]
^ja-Q0678

**ja-Q0679 · Fill the gap**

ボールを丸く、そして堅くするために麦わらをいっぱいに詰め込んでい____。

They filled them with straw to make them round and hard.

[[Japanese#^ja-Q0679-answer|Compare the answer]]
^ja-Q0679

**ja-Q0680 · Choose the form**

ボールを丸く、そして堅くするために麦わらをいっぱいに詰め込んでい____。

They filled them with straw to make them round and hard.

Choices: ます / ました / ている / たこと

[[Japanese#^ja-Q0680-answer|Compare the answer]]
^ja-Q0680

**ja-Q0681 · Edit the changed sentence**

君はコアラを見【ている】があるかい。

Have you ever seen a koala?

[[Japanese#^ja-Q0681-answer|Compare the answer]]
^ja-Q0681

**ja-Q0682 · Build the sentence**

Arrange: 君はコアラを見 / があるかい。 / たこと

Have you ever seen a koala?

[[Japanese#^ja-Q0682-answer|Compare the answer]]
^ja-Q0682

**ja-Q0683 · Write a translation**

Write this in Japanese: Did you get there on time?

[[Japanese#^ja-Q0683-answer|Compare the answer]]
^ja-Q0683

**ja-Q0684 · Explain the grammar**

時間通りに着き【ました】か。

Did you get there on time?

[[Japanese#^ja-Q0684-answer|Compare the answer]]
^ja-Q0684

**ja-Q0685 · Fill the gap**

野球場には多くの興奮したファンがい____。

There were a lot of excited fans in the stadium.

[[Japanese#^ja-Q0685-answer|Compare the answer]]
^ja-Q0685

**ja-Q0686 · Choose the form**

野球場には多くの興奮したファンがい____。

There were a lot of excited fans in the stadium.

Choices: たこと / ている / ます / ました

[[Japanese#^ja-Q0686-answer|Compare the answer]]
^ja-Q0686

**ja-Q0687 · Edit the changed sentence**

私はその会議で通訳を務め【たこと】。

I acted as interpreter at the meeting.

[[Japanese#^ja-Q0687-answer|Compare the answer]]
^ja-Q0687

**ja-Q0688 · Build the sentence**

Arrange: 。 / 私はその会議で通訳を務め / ました

I acted as interpreter at the meeting.

[[Japanese#^ja-Q0688-answer|Compare the answer]]
^ja-Q0688

**ja-Q0689 · Write a translation**

Write this in Japanese: Have you ever heard of Lucia Popp, who was a Slovakian opera singer?

[[Japanese#^ja-Q0689-answer|Compare the answer]]
^ja-Q0689

**ja-Q0690 · Explain the grammar**

スロバキア人のオペラ歌手の一人であるルチア・ポップのことを聞い【たこと】がありますか。

Have you ever heard of Lucia Popp, who was a Slovakian opera singer?

[[Japanese#^ja-Q0690-answer|Compare the answer]]
^ja-Q0690

**ja-Q0691 · Fill the gap**

はい、着き____。

Here we are.

[[Japanese#^ja-Q0691-answer|Compare the answer]]
^ja-Q0691

**ja-Q0692 · Choose the form**

はい、着き____。

Here we are.

Choices: たこと / ます / ました / ている

[[Japanese#^ja-Q0692-answer|Compare the answer]]
^ja-Q0692

**ja-Q0693 · Edit the changed sentence**

あなたがそれについて何かするつもりだと思って【たこと】。

I thought you were going to do something about that.

[[Japanese#^ja-Q0693-answer|Compare the answer]]
^ja-Q0693

**ja-Q0694 · Build the sentence**

Arrange: ました / 。 / あなたがそれについて何かするつもりだと思って

I thought you were going to do something about that.

[[Japanese#^ja-Q0694-answer|Compare the answer]]
^ja-Q0694

**ja-Q0695 · Write a translation**

Write this in Japanese: I got a pregnancy test.

[[Japanese#^ja-Q0695-answer|Compare the answer]]
^ja-Q0695

**ja-Q0696 · Explain the grammar**

妊娠検査を受け【ました】。

I got a pregnancy test.

[[Japanese#^ja-Q0696-answer|Compare the answer]]
^ja-Q0696

**ja-Q0697 · Fill the gap**

今日は少しでも練習し____か。

Have you practiced any today?

[[Japanese#^ja-Q0697-answer|Compare the answer]]
^ja-Q0697

**ja-Q0698 · Choose the form**

今日は少しでも練習し____か。

Have you practiced any today?

Choices: たこと / ます / ました / ている

[[Japanese#^ja-Q0698-answer|Compare the answer]]
^ja-Q0698

**ja-Q0699 · Edit the changed sentence**

私は徹夜し【たこと】。

I stayed up all night.

[[Japanese#^ja-Q0699-answer|Compare the answer]]
^ja-Q0699

**ja-Q0700 · Build the sentence**

Arrange: 。 / ました / 私は徹夜し

I stayed up all night.

[[Japanese#^ja-Q0700-answer|Compare the answer]]
^ja-Q0700


### Cause · 50 questions

**ja-Q0701 · Write a translation**

Write this in Japanese: He went out the window.

[[Japanese#^ja-Q0701-answer|Compare the answer]]
^ja-Q0701

**ja-Q0702 · Explain the grammar**

彼は窓【から】出て行った。

He went out the window.

[[Japanese#^ja-Q0702-answer|Compare the answer]]
^ja-Q0702

**ja-Q0703 · Fill the gap**

月は地球____遠い。

The moon is distant from the earth.

[[Japanese#^ja-Q0703-answer|Compare the answer]]
^ja-Q0703

**ja-Q0704 · Choose the form**

月は地球____遠い。

The moon is distant from the earth.

Choices: から / ので / のに

[[Japanese#^ja-Q0704-answer|Compare the answer]]
^ja-Q0704

**ja-Q0705 · Edit the changed sentence**

私はただ休養したい【から】す。

I just want to rest.

[[Japanese#^ja-Q0705-answer|Compare the answer]]
^ja-Q0705

**ja-Q0706 · Build the sentence**

Arrange: ので / す。 / 私はただ休養したい

I just want to rest.

[[Japanese#^ja-Q0706-answer|Compare the answer]]
^ja-Q0706

**ja-Q0707 · Write a translation**

Write this in Japanese: I like her all the better for her shyness.

[[Japanese#^ja-Q0707-answer|Compare the answer]]
^ja-Q0707

**ja-Q0708 · Explain the grammar**

彼女が恥ずかしがりやな【ので】、なおいっそう好きです。

I like her all the better for her shyness.

[[Japanese#^ja-Q0708-answer|Compare the answer]]
^ja-Q0708

**ja-Q0709 · Fill the gap**

少年が車にはねられるのを見た____す。

I saw a boy knocked down by a car.

[[Japanese#^ja-Q0709-answer|Compare the answer]]
^ja-Q0709

**ja-Q0710 · Choose the form**

少年が車にはねられるのを見た____す。

I saw a boy knocked down by a car.

Choices: から / のに / ので

[[Japanese#^ja-Q0710-answer|Compare the answer]]
^ja-Q0710

**ja-Q0711 · Edit the changed sentence**

どうすればいいのか分【ので】なくて、彼女を呼んでみた。

Not knowing what to do, I called her.

[[Japanese#^ja-Q0711-answer|Compare the answer]]
^ja-Q0711

**ja-Q0712 · Build the sentence**

Arrange: から / なくて、彼女を呼んでみた。 / どうすればいいのか分

Not knowing what to do, I called her.

[[Japanese#^ja-Q0712-answer|Compare the answer]]
^ja-Q0712

**ja-Q0713 · Write a translation**

Write this in Japanese: I will rescue you from these horrible circumstances.

[[Japanese#^ja-Q0713-answer|Compare the answer]]
^ja-Q0713

**ja-Q0714 · Explain the grammar**

私がその恐ろしい状況【から】あなたを救ってやるぞ。

I will rescue you from these horrible circumstances.

[[Japanese#^ja-Q0714-answer|Compare the answer]]
^ja-Q0714

**ja-Q0715 · Fill the gap**

学生の頃はよくテニスをしたも____す。

I used to play tennis when I was a student.

[[Japanese#^ja-Q0715-answer|Compare the answer]]
^ja-Q0715

**ja-Q0716 · Choose the form**

学生の頃はよくテニスをしたも____す。

I used to play tennis when I was a student.

Choices: のに / から / ので

[[Japanese#^ja-Q0716-answer|Compare the answer]]
^ja-Q0716

**ja-Q0717 · Edit the changed sentence**

彼は水に飛び込んで【ので】息をしようとして水面に浮かび上がってきた。

He dived into the water and came up for air.

[[Japanese#^ja-Q0717-answer|Compare the answer]]
^ja-Q0717

**ja-Q0718 · Build the sentence**

Arrange: から / 息をしようとして水面に浮かび上がってきた。 / 彼は水に飛び込んで

He dived into the water and came up for air.

[[Japanese#^ja-Q0718-answer|Compare the answer]]
^ja-Q0718

**ja-Q0719 · Write a translation**

Write this in Japanese: She's pure bred blue-blood you see. Unfortunately that's no sort of put-on but her natural self.

[[Japanese#^ja-Q0719-answer|Compare the answer]]
^ja-Q0719

**ja-Q0720 · Explain the grammar**

生粋のお嬢様だ【から】な。残念ながら悪戯とかじゃなくてあれで素だ。

She's pure bred blue-blood you see. Unfortunately that's no sort of put-on but her natural self.

[[Japanese#^ja-Q0720-answer|Compare the answer]]
^ja-Q0720

**ja-Q0721 · Fill the gap**

いやいや本を読む人はだれも読書の喜びがわ____ない。

Anyone who is unwilling to read does not understand the joy of reading.

[[Japanese#^ja-Q0721-answer|Compare the answer]]
^ja-Q0721

**ja-Q0722 · Choose the form**

いやいや本を読む人はだれも読書の喜びがわ____ない。

Anyone who is unwilling to read does not understand the joy of reading.

Choices: のに / ので / から

[[Japanese#^ja-Q0722-answer|Compare the answer]]
^ja-Q0722

**ja-Q0723 · Edit the changed sentence**

私は彼女【ので】手紙をもらった。

I got a letter from her.

[[Japanese#^ja-Q0723-answer|Compare the answer]]
^ja-Q0723

**ja-Q0724 · Build the sentence**

Arrange: から / 手紙をもらった。 / 私は彼女

I got a letter from her.

[[Japanese#^ja-Q0724-answer|Compare the answer]]
^ja-Q0724

**ja-Q0725 · Write a translation**

Write this in Japanese: Living near the school, I usually walk there.

[[Japanese#^ja-Q0725-answer|Compare the answer]]
^ja-Q0725

**ja-Q0726 · Explain the grammar**

学校の近くに住んでいる【ので】、普段は歩いて通学する。

Living near the school, I usually walk there.

[[Japanese#^ja-Q0726-answer|Compare the answer]]
^ja-Q0726

**ja-Q0727 · Fill the gap**

私たちはその時以来、彼女____便りをもらっていない。

We haven't heard from her since then.

[[Japanese#^ja-Q0727-answer|Compare the answer]]
^ja-Q0727

**ja-Q0728 · Choose the form**

私たちはその時以来、彼女____便りをもらっていない。

We haven't heard from her since then.

Choices: ので / のに / から

[[Japanese#^ja-Q0728-answer|Compare the answer]]
^ja-Q0728

**ja-Q0729 · Edit the changed sentence**

彼はその文法書【ので】多くの用例を引用している。

He has extracted a great many examples from the grammar book.

[[Japanese#^ja-Q0729-answer|Compare the answer]]
^ja-Q0729

**ja-Q0730 · Build the sentence**

Arrange: 彼はその文法書 / 多くの用例を引用している。 / から

He has extracted a great many examples from the grammar book.

[[Japanese#^ja-Q0730-answer|Compare the answer]]
^ja-Q0730

**ja-Q0731 · Write a translation**

Write this in Japanese: The mountain is not valuable because it is high.

[[Japanese#^ja-Q0731-answer|Compare the answer]]
^ja-Q0731

**ja-Q0732 · Explain the grammar**

山は高い【から】といって価値があるわけではない。

The mountain is not valuable because it is high.

[[Japanese#^ja-Q0732-answer|Compare the answer]]
^ja-Q0732

**ja-Q0733 · Fill the gap**

内ポケット____財布を盗まれた。

I had my wallet stolen from my inner pocket.

[[Japanese#^ja-Q0733-answer|Compare the answer]]
^ja-Q0733

**ja-Q0734 · Choose the form**

内ポケット____財布を盗まれた。

I had my wallet stolen from my inner pocket.

Choices: のに / ので / から

[[Japanese#^ja-Q0734-answer|Compare the answer]]
^ja-Q0734

**ja-Q0735 · Edit the changed sentence**

心の底【ので】同意します。

I wholeheartedly agree.

[[Japanese#^ja-Q0735-answer|Compare the answer]]
^ja-Q0735

**ja-Q0736 · Build the sentence**

Arrange: 心の底 / 同意します。 / から

I wholeheartedly agree.

[[Japanese#^ja-Q0736-answer|Compare the answer]]
^ja-Q0736

**ja-Q0737 · Write a translation**

Write this in Japanese: As it got warmer, I took off the sweater.

[[Japanese#^ja-Q0737-answer|Compare the answer]]
^ja-Q0737

**ja-Q0738 · Explain the grammar**

暖かくなった【ので】、私はセーターを脱いだ。

As it got warmer, I took off the sweater.

[[Japanese#^ja-Q0738-answer|Compare the answer]]
^ja-Q0738

**ja-Q0739 · Fill the gap**

何しろ朝____夕方まで、校舎の中で軟禁状態だからな。釈放されれば元気にもなるってもんだ。

Anyhow, having been held in school from morning to evening ... anybody'd be happy on getting released.

[[Japanese#^ja-Q0739-answer|Compare the answer]]
^ja-Q0739

**ja-Q0740 · Choose the form**

何しろ朝____夕方まで、校舎の中で軟禁状態だからな。釈放されれば元気にもなるってもんだ。

Anyhow, having been held in school from morning to evening ... anybody'd be happy on getting released.

Choices: から / のに / ので

[[Japanese#^ja-Q0740-answer|Compare the answer]]
^ja-Q0740

**ja-Q0741 · Edit the changed sentence**

このｅ—ｍａｉｌアドレスは明日【ので】は使用不可能になります。

From tomorrow this email address will be invalid.

[[Japanese#^ja-Q0741-answer|Compare the answer]]
^ja-Q0741

**ja-Q0742 · Build the sentence**

Arrange: は使用不可能になります。 / このｅ—ｍａｉｌアドレスは明日 / から

From tomorrow this email address will be invalid.

[[Japanese#^ja-Q0742-answer|Compare the answer]]
^ja-Q0742

**ja-Q0743 · Write a translation**

Write this in Japanese: Tom is liked by everyone.

[[Japanese#^ja-Q0743-answer|Compare the answer]]
^ja-Q0743

**ja-Q0744 · Explain the grammar**

トムはみんな【から】好かれている。

Tom is liked by everyone.

[[Japanese#^ja-Q0744-answer|Compare the answer]]
^ja-Q0744

**ja-Q0745 · Fill the gap**

税は直接税と間接税____なっている。

Taxes consist of direct taxes and indirect ones.

[[Japanese#^ja-Q0745-answer|Compare the answer]]
^ja-Q0745

**ja-Q0746 · Choose the form**

税は直接税と間接税____なっている。

Taxes consist of direct taxes and indirect ones.

Choices: のに / ので / から

[[Japanese#^ja-Q0746-answer|Compare the answer]]
^ja-Q0746

**ja-Q0747 · Edit the changed sentence**

風邪をひいていた【から】、学校を休んだ。

I was absent from school because I had a cold.

[[Japanese#^ja-Q0747-answer|Compare the answer]]
^ja-Q0747

**ja-Q0748 · Build the sentence**

Arrange: 、学校を休んだ。 / ので / 風邪をひいていた

I was absent from school because I had a cold.

[[Japanese#^ja-Q0748-answer|Compare the answer]]
^ja-Q0748

**ja-Q0749 · Write a translation**

Write this in Japanese: What gate do I board at?

[[Japanese#^ja-Q0749-answer|Compare the answer]]
^ja-Q0749

**ja-Q0750 · Explain the grammar**

どのゲート【から】乗ればよいのでしょうか。

What gate do I board at?

[[Japanese#^ja-Q0750-answer|Compare the answer]]
^ja-Q0750


### Contrast and concession · 50 questions

**ja-Q0751 · Fill the gap**

少女は友達にお茶をいれる____忙しかった。

The girl was busy making tea for her friend.

[[Japanese#^ja-Q0751-answer|Compare the answer]]
^ja-Q0751

**ja-Q0752 · Choose the form**

少女は友達にお茶をいれる____忙しかった。

The girl was busy making tea for her friend.

Choices: しかし / のに / ので / けど

[[Japanese#^ja-Q0752-answer|Compare the answer]]
^ja-Q0752

**ja-Q0753 · Edit the changed sentence**

彼が話をやめるように頼んだが、彼はそれ【けど】はなしつづけた。

I asked him to stop talking, but he still went on.

[[Japanese#^ja-Q0753-answer|Compare the answer]]
^ja-Q0753

**ja-Q0754 · Build the sentence**

Arrange: でも / 彼が話をやめるように頼んだが、彼はそれ / はなしつづけた。

I asked him to stop talking, but he still went on.

[[Japanese#^ja-Q0754-answer|Compare the answer]]
^ja-Q0754

**ja-Q0755 · Write a translation**

Write this in Japanese: I've been told that the museum is closed on Mondays.

[[Japanese#^ja-Q0755-answer|Compare the answer]]
^ja-Q0755

**ja-Q0756 · Explain the grammar**

博物館は月曜日が休館だって言われた【けど】な。

I've been told that the museum is closed on Mondays.

[[Japanese#^ja-Q0756-answer|Compare the answer]]
^ja-Q0756

**ja-Q0757 · Fill the gap**

彼がその仕事を終える____２時間かかるだろう。

It will take him two hours to finish the work.

[[Japanese#^ja-Q0757-answer|Compare the answer]]
^ja-Q0757

**ja-Q0758 · Choose the form**

彼がその仕事を終える____２時間かかるだろう。

It will take him two hours to finish the work.

Choices: ので / しかし / けど / のに

[[Japanese#^ja-Q0758-answer|Compare the answer]]
^ja-Q0758

**ja-Q0759 · Edit the changed sentence**

君が来るかどうかは私にとってはどう【けど】よいことだ。

It does not matter to me whether you come or not.

[[Japanese#^ja-Q0759-answer|Compare the answer]]
^ja-Q0759

**ja-Q0760 · Build the sentence**

Arrange: よいことだ。 / でも / 君が来るかどうかは私にとってはどう

It does not matter to me whether you come or not.

[[Japanese#^ja-Q0760-answer|Compare the answer]]
^ja-Q0760

**ja-Q0761 · Write a translation**

Write this in Japanese: I got it for nothing.

[[Japanese#^ja-Q0761-answer|Compare the answer]]
^ja-Q0761

**ja-Q0762 · Explain the grammar**

私はそれをただ【でも】らった。

I got it for nothing.

[[Japanese#^ja-Q0762-answer|Compare the answer]]
^ja-Q0762

**ja-Q0763 · Fill the gap**

二度と私のも____触らないで。

Don't ever touch my things again.

[[Japanese#^ja-Q0763-answer|Compare the answer]]
^ja-Q0763

**ja-Q0764 · Choose the form**

二度と私のも____触らないで。

Don't ever touch my things again.

Choices: しかし / のに / けど / ので

[[Japanese#^ja-Q0764-answer|Compare the answer]]
^ja-Q0764

**ja-Q0765 · Edit the changed sentence**

もうすこし注意すべきだった【けど】。

You should have been more careful.

[[Japanese#^ja-Q0765-answer|Compare the answer]]
^ja-Q0765

**ja-Q0766 · Build the sentence**

Arrange: のに / 。 / もうすこし注意すべきだった

You should have been more careful.

[[Japanese#^ja-Q0766-answer|Compare the answer]]
^ja-Q0766

**ja-Q0767 · Write a translation**

Write this in Japanese: I'd like to set up a sign like, "This Way ->," but what would it be if I made it in English?

[[Japanese#^ja-Q0767-answer|Compare the answer]]
^ja-Q0767

**ja-Q0768 · Explain the grammar**

「順路→」といったかんじの看板を設置したいと思うんです【けど】、これを英語で作るとどうなるでしょうか？

I'd like to set up a sign like, "This Way ->," but what would it be if I made it in English?

[[Japanese#^ja-Q0768-answer|Compare the answer]]
^ja-Q0768

**ja-Q0769 · Fill the gap**

トムね、怪我したんだ____それほどひどくなかったよ。

Tom was injured, but not too badly.

[[Japanese#^ja-Q0769-answer|Compare the answer]]
^ja-Q0769

**ja-Q0770 · Choose the form**

トムね、怪我したんだ____それほどひどくなかったよ。

Tom was injured, but not too badly.

Choices: しかし / ので / けど / から

[[Japanese#^ja-Q0770-answer|Compare the answer]]
^ja-Q0770

**ja-Q0771 · Edit the changed sentence**

君は仕事を得る【けど】成功した。

You finally succeeded in getting a job.

[[Japanese#^ja-Q0771-answer|Compare the answer]]
^ja-Q0771

**ja-Q0772 · Build the sentence**

Arrange: 成功した。 / 君は仕事を得る / のに

You finally succeeded in getting a job.

[[Japanese#^ja-Q0772-answer|Compare the answer]]
^ja-Q0772

**ja-Q0773 · Write a translation**

Write this in Japanese: I don't want to hide anything from you anymore.

[[Japanese#^ja-Q0773-answer|Compare the answer]]
^ja-Q0773

**ja-Q0774 · Explain the grammar**

もうこれ以上、あなたに隠し事はしたくないんだ【けど】。

I don't want to hide anything from you anymore.

[[Japanese#^ja-Q0774-answer|Compare the answer]]
^ja-Q0774

**ja-Q0775 · Fill the gap**

今回の金融危機から得たほか____ない教訓というのは、メーン・ストリート（普通の町の中央通り）が苦しんでいるのにウォール・ストリートだけ栄えるなど、そんなことがあってはならないということ。それを忘れずにいましょう。

Let us remember that if this financial crisis taught us anything, it's that we cannot have a thriving Wall Street while Main Street suffers.

[[Japanese#^ja-Q0775-answer|Compare the answer]]
^ja-Q0775

**ja-Q0776 · Choose the form**

今回の金融危機から得たほか____ない教訓というのは、メーン・ストリート（普通の町の中央通り）が苦しんでいるのにウォール・ストリートだけ栄えるなど、そんなことがあってはならないということ。それを忘れずにいましょう。

Let us remember that if this financial crisis taught us anything, it's that we cannot have a thriving Wall Street while Main Street suffers.

Choices: けど / しかし / でも / ので

[[Japanese#^ja-Q0776-answer|Compare the answer]]
^ja-Q0776

**ja-Q0777 · Edit the changed sentence**

トムは自分の身長についてからかわれることを知ってた【しかし】、バスケットチームにトライアウトすることに決めた。

Even though Tom knew he'd be teased about his height, he decided to try out for the basketball team.

[[Japanese#^ja-Q0777-answer|Compare the answer]]
^ja-Q0777

**ja-Q0778 · Build the sentence**

Arrange: けど / トムは自分の身長についてからかわれることを知ってた / 、バスケットチームにトライアウトすることに決めた。

Even though Tom knew he'd be teased about his height, he decided to try out for the basketball team.

[[Japanese#^ja-Q0778-answer|Compare the answer]]
^ja-Q0778

**ja-Q0779 · Write a translation**

Write this in Japanese: It took me three days to clean the room.

[[Japanese#^ja-Q0779-answer|Compare the answer]]
^ja-Q0779

**ja-Q0780 · Explain the grammar**

その部屋を掃除する【のに】三日かかった。

It took me three days to clean the room.

[[Japanese#^ja-Q0780-answer|Compare the answer]]
^ja-Q0780

**ja-Q0781 · Fill the gap**

もっと時間があればいい____。

I wish we had more time.

[[Japanese#^ja-Q0781-answer|Compare the answer]]
^ja-Q0781

**ja-Q0782 · Choose the form**

もっと時間があればいい____。

I wish we had more time.

Choices: ので / けど / しかし / のに

[[Japanese#^ja-Q0782-answer|Compare the answer]]
^ja-Q0782

**ja-Q0783 · Edit the changed sentence**

どれ【けど】好きなドレスを選んでください。

Choose any dress you like.

[[Japanese#^ja-Q0783-answer|Compare the answer]]
^ja-Q0783

**ja-Q0784 · Build the sentence**

Arrange: どれ / 好きなドレスを選んでください。 / でも

Choose any dress you like.

[[Japanese#^ja-Q0784-answer|Compare the answer]]
^ja-Q0784

**ja-Q0785 · Write a translation**

Write this in Japanese: When John came back, he looked pale as if he had seen a ghost.

[[Japanese#^ja-Q0785-answer|Compare the answer]]
^ja-Q0785

**ja-Q0786 · Explain the grammar**

ジョンが戻ってきたとき、彼はまるで幽霊【でも】みたように青白い顔つきだった。

When John came back, he looked pale as if he had seen a ghost.

[[Japanese#^ja-Q0786-answer|Compare the answer]]
^ja-Q0786

**ja-Q0787 · Fill the gap**

タケオはその数学の問題を解く____熱中している。

Takeo is engrossed in solving mathematical problems.

[[Japanese#^ja-Q0787-answer|Compare the answer]]
^ja-Q0787

**ja-Q0788 · Choose the form**

タケオはその数学の問題を解く____熱中している。

Takeo is engrossed in solving mathematical problems.

Choices: ので / のに / けど / しかし

[[Japanese#^ja-Q0788-answer|Compare the answer]]
^ja-Q0788

**ja-Q0789 · Edit the changed sentence**

ボブは事故にあった【けど】違いない。

Bob must have had an accident.

[[Japanese#^ja-Q0789-answer|Compare the answer]]
^ja-Q0789

**ja-Q0790 · Build the sentence**

Arrange: 違いない。 / ボブは事故にあった / のに

Bob must have had an accident.

[[Japanese#^ja-Q0790-answer|Compare the answer]]
^ja-Q0790

**ja-Q0791 · Write a translation**

Write this in Japanese: I like to do a few exercises to loosen up before I run.

[[Japanese#^ja-Q0791-answer|Compare the answer]]
^ja-Q0791

**ja-Q0792 · Explain the grammar**

私は走る前に、体をほぐす【のに】ちょっと体操をする。

I like to do a few exercises to loosen up before I run.

[[Japanese#^ja-Q0792-answer|Compare the answer]]
^ja-Q0792

**ja-Q0793 · Fill the gap**

も____て直せるかも。

Maybe I can fix it.

[[Japanese#^ja-Q0793-answer|Compare the answer]]
^ja-Q0793

**ja-Q0794 · Choose the form**

も____て直せるかも。

Maybe I can fix it.

Choices: から / ので / けど / しかし

[[Japanese#^ja-Q0794-answer|Compare the answer]]
^ja-Q0794

**ja-Q0795 · Edit the changed sentence**

そんなも【けど】飛びつくのはばかだ。

If you bite at it, you're a fool.

[[Japanese#^ja-Q0795-answer|Compare the answer]]
^ja-Q0795

**ja-Q0796 · Build the sentence**

Arrange: 飛びつくのはばかだ。 / そんなも / のに

If you bite at it, you're a fool.

[[Japanese#^ja-Q0796-answer|Compare the answer]]
^ja-Q0796

**ja-Q0797 · Write a translation**

Write this in Japanese: You should have started by now.

[[Japanese#^ja-Q0797-answer|Compare the answer]]
^ja-Q0797

**ja-Q0798 · Explain the grammar**

もっと早くはじめるべきだった【のに】。

You should have started by now.

[[Japanese#^ja-Q0798-answer|Compare the answer]]
^ja-Q0798

**ja-Q0799 · Fill the gap**

今はそれについて話したくないんだ____。

I'd prefer to not talk about that now.

[[Japanese#^ja-Q0799-answer|Compare the answer]]
^ja-Q0799

**ja-Q0800 · Choose the form**

今はそれについて話したくないんだ____。

I'd prefer to not talk about that now.

Choices: しかし / ので / から / けど

[[Japanese#^ja-Q0800-answer|Compare the answer]]
^ja-Q0800


### Conditions · 50 questions

**ja-Q0801 · Edit the changed sentence**

長い目で見【なら】、正直は報われる。

Honesty pays in the long run.

[[Japanese#^ja-Q0801-answer|Compare the answer]]
^ja-Q0801

**ja-Q0802 · Build the sentence**

Arrange: 、正直は報われる。 / 長い目で見 / れば

Honesty pays in the long run.

[[Japanese#^ja-Q0802-answer|Compare the answer]]
^ja-Q0802

**ja-Q0803 · Write a translation**

Write this in Japanese: 'Would you still be my friend even if I turned into a pig all of a sudden?' 'Of course!'

[[Japanese#^ja-Q0803-answer|Compare the answer]]
^ja-Q0803

**ja-Q0804 · Explain the grammar**

「【もし】も僕が豚になっても、変わらず友達でいてくれる？」「もちろんだよ！」

'Would you still be my friend even if I turned into a pig all of a sudden?' 'Of course!'

[[Japanese#^ja-Q0804-answer|Compare the answer]]
^ja-Q0804

**ja-Q0805 · Fill the gap**

今、あなたがパソコンの電源を切____、地球温暖化防止に貢献できる。

If you turned off your computer right now, you would contribute to the prevention of global warming.

[[Japanese#^ja-Q0805-answer|Compare the answer]]
^ja-Q0805

**ja-Q0806 · Choose the form**

今、あなたがパソコンの電源を切____、地球温暖化防止に貢献できる。

If you turned off your computer right now, you would contribute to the prevention of global warming.

Choices: もし / なら / れば / から

[[Japanese#^ja-Q0806-answer|Compare the answer]]
^ja-Q0806

**ja-Q0807 · Edit the changed sentence**

北極熊は、生きていくために体を適温に保ち、数日か数ヶ月もあくか【なら】れない食事の間持ちこたえられるだけの十分なエネルギーを蓄えねばならない。

To survive, the polar bear must keep its body at the right temperature and store enough energy to last between meals that could be a few days or a few months apart.

[[Japanese#^ja-Q0807-answer|Compare the answer]]
^ja-Q0807

**ja-Q0808 · Build the sentence**

Arrange: れない食事の間持ちこたえられるだけの十分なエネルギーを蓄えねばならない。 / 北極熊は、生きていくために体を適温に保ち、数日か数ヶ月もあくか / もし

To survive, the polar bear must keep its body at the right temperature and store enough energy to last between meals that could be a few days or a few months apart.

[[Japanese#^ja-Q0808-answer|Compare the answer]]
^ja-Q0808

**ja-Q0809 · Write a translation**

Write this in Japanese: But that he was idle, he would have succeeded.

[[Japanese#^ja-Q0809-answer|Compare the answer]]
^ja-Q0809

**ja-Q0810 · Explain the grammar**

【もし】怠けていなかったならば彼は成功しただろうに。

But that he was idle, he would have succeeded.

[[Japanese#^ja-Q0810-answer|Compare the answer]]
^ja-Q0810

**ja-Q0811 · Fill the gap**

____すべてが彼女の計画通りに進むなら、彼女は引っ張りだこだろう。

If all went according to her plan, she would be in great demand.

[[Japanese#^ja-Q0811-answer|Compare the answer]]
^ja-Q0811

**ja-Q0812 · Choose the form**

____すべてが彼女の計画通りに進むなら、彼女は引っ張りだこだろう。

If all went according to her plan, she would be in great demand.

Choices: から / なら / ので / もし

[[Japanese#^ja-Q0812-answer|Compare the answer]]
^ja-Q0812

**ja-Q0813 · Edit the changed sentence**

君が俺のそばにいてくれ【なら】なあ。

I wish you were close to me.

[[Japanese#^ja-Q0813-answer|Compare the answer]]
^ja-Q0813

**ja-Q0814 · Build the sentence**

Arrange: たら / なあ。 / 君が俺のそばにいてくれ

I wish you were close to me.

[[Japanese#^ja-Q0814-answer|Compare the answer]]
^ja-Q0814

**ja-Q0815 · Write a translation**

Write this in Japanese: We have to pay taxes by March 15.

[[Japanese#^ja-Q0815-answer|Compare the answer]]
^ja-Q0815

**ja-Q0816 · Explain the grammar**

私たちは３月１５日までに税金を払わなけ【れば】ならない。

We have to pay taxes by March 15.

[[Japanese#^ja-Q0816-answer|Compare the answer]]
^ja-Q0816

**ja-Q0817 · Fill the gap**

「君がそれをするのをやめさせなけ____いけないな。」「何をするのをやめさせるって？」

"I have to stop you from doing that." "Stop me from doing what?"

[[Japanese#^ja-Q0817-answer|Compare the answer]]
^ja-Q0817

**ja-Q0818 · Choose the form**

「君がそれをするのをやめさせなけ____いけないな。」「何をするのをやめさせるって？」

"I have to stop you from doing that." "Stop me from doing what?"

Choices: もし / れば / なら / から

[[Japanese#^ja-Q0818-answer|Compare the answer]]
^ja-Q0818

**ja-Q0819 · Edit the changed sentence**

あなたのように英語が話せ【なら】いいなあ。

I wish I could speak English like you.

[[Japanese#^ja-Q0819-answer|Compare the answer]]
^ja-Q0819

**ja-Q0820 · Build the sentence**

Arrange: たら / いいなあ。 / あなたのように英語が話せ

I wish I could speak English like you.

[[Japanese#^ja-Q0820-answer|Compare the answer]]
^ja-Q0820

**ja-Q0821 · Write a translation**

Write this in Japanese: According to the paper, there was an earthquake last night.

[[Japanese#^ja-Q0821-answer|Compare the answer]]
^ja-Q0821

**ja-Q0822 · Explain the grammar**

新聞によ【れば】、昨夜地震があったそうだ。

According to the paper, there was an earthquake last night.

[[Japanese#^ja-Q0822-answer|Compare the answer]]
^ja-Q0822

**ja-Q0823 · Fill the gap**

このプログラムを持っていない____ば、今ダウンロードすることができます。

If you do not have this program, you can download it now.

[[Japanese#^ja-Q0823-answer|Compare the answer]]
^ja-Q0823

**ja-Q0824 · Choose the form**

このプログラムを持っていない____ば、今ダウンロードすることができます。

If you do not have this program, you can download it now.

Choices: から / ので / なら / もし

[[Japanese#^ja-Q0824-answer|Compare the answer]]
^ja-Q0824

**ja-Q0825 · Edit the changed sentence**

誤字脱字を見つけ【なら】教えてください。

Please let me know if you find any typos or missing words.

[[Japanese#^ja-Q0825-answer|Compare the answer]]
^ja-Q0825

**ja-Q0826 · Build the sentence**

Arrange: たら / 教えてください。 / 誤字脱字を見つけ

Please let me know if you find any typos or missing words.

[[Japanese#^ja-Q0826-answer|Compare the answer]]
^ja-Q0826

**ja-Q0827 · Write a translation**

Write this in Japanese: I may have caught cold on that cold night.

[[Japanese#^ja-Q0827-answer|Compare the answer]]
^ja-Q0827

**ja-Q0828 · Explain the grammar**

あの寒い夜に風邪を引いたのか【もし】れない。

I may have caught cold on that cold night.

[[Japanese#^ja-Q0828-answer|Compare the answer]]
^ja-Q0828

**ja-Q0829 · Fill the gap**

世界的な全面核戦争が起こ____、地球規模でこの「核の冬」が数カ月間も続くと言われています。

If there's a world-wide all-out nuclear war it's said that there will be a "nuclear winter" all over the planet for several months.

[[Japanese#^ja-Q0829-answer|Compare the answer]]
^ja-Q0829

**ja-Q0830 · Choose the form**

世界的な全面核戦争が起こ____、地球規模でこの「核の冬」が数カ月間も続くと言われています。

If there's a world-wide all-out nuclear war it's said that there will be a "nuclear winter" all over the planet for several months.

Choices: もし / れば / なら / から

[[Japanese#^ja-Q0830-answer|Compare the answer]]
^ja-Q0830

**ja-Q0831 · Edit the changed sentence**

あなたは私についてきさえす【なら】よい。

All you have to do is follow me.

[[Japanese#^ja-Q0831-answer|Compare the answer]]
^ja-Q0831

**ja-Q0832 · Build the sentence**

Arrange: よい。 / あなたは私についてきさえす / れば

All you have to do is follow me.

[[Japanese#^ja-Q0832-answer|Compare the answer]]
^ja-Q0832

**ja-Q0833 · Write a translation**

Write this in Japanese: We had to learn the lines of the play in park.

[[Japanese#^ja-Q0833-answer|Compare the answer]]
^ja-Q0833

**ja-Q0834 · Explain the grammar**

一週間で劇のせりふを思えなけ【れば】ならない。

We had to learn the lines of the play in park.

[[Japanese#^ja-Q0834-answer|Compare the answer]]
^ja-Q0834

**ja-Q0835 · Fill the gap**

上司のミスター田中が君を飲みに誘うか____れないってことを言っておくね。

I should tell you that my boss, Mr Tanaka, might try to take you drinking.

[[Japanese#^ja-Q0835-answer|Compare the answer]]
^ja-Q0835

**ja-Q0836 · Choose the form**

上司のミスター田中が君を飲みに誘うか____れないってことを言っておくね。

I should tell you that my boss, Mr Tanaka, might try to take you drinking.

Choices: から / なら / ので / もし

[[Japanese#^ja-Q0836-answer|Compare the answer]]
^ja-Q0836

**ja-Q0837 · Edit the changed sentence**

80円切手があっ【なら】なぁ。

I wish I had an 80-yen stamp.

[[Japanese#^ja-Q0837-answer|Compare the answer]]
^ja-Q0837

**ja-Q0838 · Build the sentence**

Arrange: たら / なぁ。 / 80円切手があっ

I wish I had an 80-yen stamp.

[[Japanese#^ja-Q0838-answer|Compare the answer]]
^ja-Q0838

**ja-Q0839 · Write a translation**

Write this in Japanese: You'll never know unless you try.

[[Japanese#^ja-Q0839-answer|Compare the answer]]
^ja-Q0839

**ja-Q0840 · Explain the grammar**

試してみなけ【れば】決して分からないだろう。

You'll never know unless you try.

[[Japanese#^ja-Q0840-answer|Compare the answer]]
^ja-Q0840

**ja-Q0841 · Fill the gap**

ドイツ語がいい____ドイツ語で話してもいいよ。

Feel free to speak German.

[[Japanese#^ja-Q0841-answer|Compare the answer]]
^ja-Q0841

**ja-Q0842 · Choose the form**

ドイツ語がいい____ドイツ語で話してもいいよ。

Feel free to speak German.

Choices: ので / もし / から / なら

[[Japanese#^ja-Q0842-answer|Compare the answer]]
^ja-Q0842

**ja-Q0843 · Edit the changed sentence**

【なら】６月前にその仕事を完成するつもりならばもっと努力が必要です。

If you are to finish the work before June, you will have to work much better.

[[Japanese#^ja-Q0843-answer|Compare the answer]]
^ja-Q0843

**ja-Q0844 · Build the sentence**

Arrange: ６月前にその仕事を完成するつもりならばもっと努力が必要です。 / もし

If you are to finish the work before June, you will have to work much better.

[[Japanese#^ja-Q0844-answer|Compare the answer]]
^ja-Q0844

**ja-Q0845 · Write a translation**

Write this in Japanese: The tourists had to leave the town before dawn.

[[Japanese#^ja-Q0845-answer|Compare the answer]]
^ja-Q0845

**ja-Q0846 · Explain the grammar**

旅行者は夜明け前に離れなけ【れば】ならなかった。

The tourists had to leave the town before dawn.

[[Japanese#^ja-Q0846-answer|Compare the answer]]
^ja-Q0846

**ja-Q0847 · Fill the gap**

あなたには感謝して____たりない。

I can't thank you enough.

[[Japanese#^ja-Q0847-answer|Compare the answer]]
^ja-Q0847

**ja-Q0848 · Choose the form**

あなたには感謝して____たりない。

I can't thank you enough.

Choices: ので / なら / もし / から

[[Japanese#^ja-Q0848-answer|Compare the answer]]
^ja-Q0848

**ja-Q0849 · Edit the changed sentence**

君は行かねば【もし】ない。

You have to go.

[[Japanese#^ja-Q0849-answer|Compare the answer]]
^ja-Q0849

**ja-Q0850 · Build the sentence**

Arrange: なら / 君は行かねば / ない。

You have to go.

[[Japanese#^ja-Q0850-answer|Compare the answer]]
^ja-Q0850


### Nominalisation and explanation · 50 questions

**ja-Q0851 · Write a translation**

Write this in Japanese: Is this really a non-alcoholic beer?

[[Japanese#^ja-Q0851-answer|Compare the answer]]
^ja-Q0851

**ja-Q0852 · Explain the grammar**

これ、本当にノンアルコールビールな【んです】か？

Is this really a non-alcoholic beer?

[[Japanese#^ja-Q0852-answer|Compare the answer]]
^ja-Q0852

**ja-Q0853 · Fill the gap**

大統領は発展途上諸国に十分な援助を提供する____を決めた。

The President decided to provide developing countries with sufficient aid.

[[Japanese#^ja-Q0853-answer|Compare the answer]]
^ja-Q0853

**ja-Q0854 · Choose the form**

大統領は発展途上諸国に十分な援助を提供する____を決めた。

The President decided to provide developing countries with sufficient aid.

Choices: のです / もの / こと

[[Japanese#^ja-Q0854-answer|Compare the answer]]
^ja-Q0854

**ja-Q0855 · Edit the changed sentence**

最初は彼の【もの】を信じなかった。

I didn't believe him at first.

[[Japanese#^ja-Q0855-answer|Compare the answer]]
^ja-Q0855

**ja-Q0856 · Build the sentence**

Arrange: を信じなかった。 / こと / 最初は彼の

I didn't believe him at first.

[[Japanese#^ja-Q0856-answer|Compare the answer]]
^ja-Q0856

**ja-Q0857 · Write a translation**

Write this in Japanese: The only way to find out what happened is to ask Tom.

[[Japanese#^ja-Q0857-answer|Compare the answer]]
^ja-Q0857

**ja-Q0858 · Explain the grammar**

何が起こったか知る唯一の方法は、トムに訊く【こと】です。

The only way to find out what happened is to ask Tom.

[[Japanese#^ja-Q0858-answer|Compare the answer]]
^ja-Q0858

**ja-Q0859 · Fill the gap**

みんな寂しがっていた____よ。

We all have missed you.

[[Japanese#^ja-Q0859-answer|Compare the answer]]
^ja-Q0859

**ja-Q0860 · Choose the form**

みんな寂しがっていた____よ。

We all have missed you.

Choices: もの / こと / のです / んです

[[Japanese#^ja-Q0860-answer|Compare the answer]]
^ja-Q0860

**ja-Q0861 · Edit the changed sentence**

君は自分を抑える【もの】を学ぶべきだ。

You should learn to restrain yourself.

[[Japanese#^ja-Q0861-answer|Compare the answer]]
^ja-Q0861

**ja-Q0862 · Build the sentence**

Arrange: こと / を学ぶべきだ。 / 君は自分を抑える

You should learn to restrain yourself.

[[Japanese#^ja-Q0862-answer|Compare the answer]]
^ja-Q0862

**ja-Q0863 · Write a translation**

Write this in Japanese: Dr. Patterson: Yes, it was horrible.

[[Japanese#^ja-Q0863-answer|Compare the answer]]
^ja-Q0863

**ja-Q0864 · Explain the grammar**

パターソン博士：そうです。ひどい【こと】でした。

Dr. Patterson: Yes, it was horrible.

[[Japanese#^ja-Q0864-answer|Compare the answer]]
^ja-Q0864

**ja-Q0865 · Fill the gap**

たまに彼女の自由奔放な態度は無礼に見える____がある。

Sometimes her free manner seems rude.

[[Japanese#^ja-Q0865-answer|Compare the answer]]
^ja-Q0865

**ja-Q0866 · Choose the form**

たまに彼女の自由奔放な態度は無礼に見える____がある。

Sometimes her free manner seems rude.

Choices: こと / もの / のです

[[Japanese#^ja-Q0866-answer|Compare the answer]]
^ja-Q0866

**ja-Q0867 · Edit the changed sentence**

彼女はときどき何時間もじっと座っている【もの】がある。

She will sometimes sit still for hours.

[[Japanese#^ja-Q0867-answer|Compare the answer]]
^ja-Q0867

**ja-Q0868 · Build the sentence**

Arrange: がある。 / 彼女はときどき何時間もじっと座っている / こと

She will sometimes sit still for hours.

[[Japanese#^ja-Q0868-answer|Compare the answer]]
^ja-Q0868

**ja-Q0869 · Write a translation**

Write this in Japanese: To read books is important.

[[Japanese#^ja-Q0869-answer|Compare the answer]]
^ja-Q0869

**ja-Q0870 · Explain the grammar**

本を読む【こと】は大切です。

To read books is important.

[[Japanese#^ja-Q0870-answer|Compare the answer]]
^ja-Q0870

**ja-Q0871 · Fill the gap**

彼は彼女を脇へ呼んでその____を知らせた。

He took her aside and told her the news.

[[Japanese#^ja-Q0871-answer|Compare the answer]]
^ja-Q0871

**ja-Q0872 · Choose the form**

彼は彼女を脇へ呼んでその____を知らせた。

He took her aside and told her the news.

Choices: のです / もの / こと

[[Japanese#^ja-Q0872-answer|Compare the answer]]
^ja-Q0872

**ja-Q0873 · Edit the changed sentence**

来年の【もの】を言えば鬼が笑う。

Next year is the devil's joke.

[[Japanese#^ja-Q0873-answer|Compare the answer]]
^ja-Q0873

**ja-Q0874 · Build the sentence**

Arrange: 来年の / を言えば鬼が笑う。 / こと

Next year is the devil's joke.

[[Japanese#^ja-Q0874-answer|Compare the answer]]
^ja-Q0874

**ja-Q0875 · Write a translation**

Write this in Japanese: I calculated that it would cost 300 dollars.

[[Japanese#^ja-Q0875-answer|Compare the answer]]
^ja-Q0875

**ja-Q0876 · Explain the grammar**

私の見積もりでは、それは300ドルかかるだろうという【こと】だった。

I calculated that it would cost 300 dollars.

[[Japanese#^ja-Q0876-answer|Compare the answer]]
^ja-Q0876

**ja-Q0877 · Fill the gap**

死ぬ____より苦痛に耐えることの方がもっと勇気がいる。

It requires more courage to suffer than to die.

[[Japanese#^ja-Q0877-answer|Compare the answer]]
^ja-Q0877

**ja-Q0878 · Choose the form**

死ぬ____より苦痛に耐えることの方がもっと勇気がいる。

It requires more courage to suffer than to die.

Choices: もの / のです / こと

[[Japanese#^ja-Q0878-answer|Compare the answer]]
^ja-Q0878

**ja-Q0879 · Edit the changed sentence**

彼に酒を飲ませないようにする【もの】はできない。

You cannot prevent him from drinking.

[[Japanese#^ja-Q0879-answer|Compare the answer]]
^ja-Q0879

**ja-Q0880 · Build the sentence**

Arrange: はできない。 / こと / 彼に酒を飲ませないようにする

You cannot prevent him from drinking.

[[Japanese#^ja-Q0880-answer|Compare the answer]]
^ja-Q0880

**ja-Q0881 · Write a translation**

Write this in Japanese: It is important to overview the economic status of these groups before examining the proposed solutions.

[[Japanese#^ja-Q0881-answer|Compare the answer]]
^ja-Q0881

**ja-Q0882 · Explain the grammar**

提案されている解決策を検討する前に、これらのグループの経済学的地位を概観しておく【こと】が重要である。

It is important to overview the economic status of these groups before examining the proposed solutions.

[[Japanese#^ja-Q0882-answer|Compare the answer]]
^ja-Q0882

**ja-Q0883 · Fill the gap**

私達は彼と取り引きする____にした。

We decided to make a deal with him.

[[Japanese#^ja-Q0883-answer|Compare the answer]]
^ja-Q0883

**ja-Q0884 · Choose the form**

私達は彼と取り引きする____にした。

We decided to make a deal with him.

Choices: のです / もの / こと

[[Japanese#^ja-Q0884-answer|Compare the answer]]
^ja-Q0884

**ja-Q0885 · Edit the changed sentence**

その問題が簡単な【もの】に気づいた。

I found the problem was easy.

[[Japanese#^ja-Q0885-answer|Compare the answer]]
^ja-Q0885

**ja-Q0886 · Build the sentence**

Arrange: その問題が簡単な / に気づいた。 / こと

I found the problem was easy.

[[Japanese#^ja-Q0886-answer|Compare the answer]]
^ja-Q0886

**ja-Q0887 · Write a translation**

Write this in Japanese: Australians are, on the whole, pleased with the stabilizing benefits of their political system.

[[Japanese#^ja-Q0887-answer|Compare the answer]]
^ja-Q0887

**ja-Q0888 · Explain the grammar**

オーストラリア人は全体として政治システムが安定している【こと】による恩恵に満足している。

Australians are, on the whole, pleased with the stabilizing benefits of their political system.

[[Japanese#^ja-Q0888-answer|Compare the answer]]
^ja-Q0888

**ja-Q0889 · Fill the gap**

愛する我が子を失う____ほど辛いことはない。

There's nothing more painful than losing one's loved child.

[[Japanese#^ja-Q0889-answer|Compare the answer]]
^ja-Q0889

**ja-Q0890 · Choose the form**

愛する我が子を失う____ほど辛いことはない。

There's nothing more painful than losing one's loved child.

Choices: こと / のです / もの

[[Japanese#^ja-Q0890-answer|Compare the answer]]
^ja-Q0890

**ja-Q0891 · Edit the changed sentence**

私はその問題を自分でとく【もの】ができます。

I can solve the problem by myself.

[[Japanese#^ja-Q0891-answer|Compare the answer]]
^ja-Q0891

**ja-Q0892 · Build the sentence**

Arrange: 私はその問題を自分でとく / ができます。 / こと

I can solve the problem by myself.

[[Japanese#^ja-Q0892-answer|Compare the answer]]
^ja-Q0892

**ja-Q0893 · Write a translation**

Write this in Japanese: It's no crime to skip breakfast once in a while.

[[Japanese#^ja-Q0893-answer|Compare the answer]]
^ja-Q0893

**ja-Q0894 · Explain the grammar**

たまに朝飯を抜いたって別に悪い【こと】じゃない。

It's no crime to skip breakfast once in a while.

[[Japanese#^ja-Q0894-answer|Compare the answer]]
^ja-Q0894

**ja-Q0895 · Fill the gap**

趣味というものを説明する____は出来ない。

There is no accounting for tastes.

[[Japanese#^ja-Q0895-answer|Compare the answer]]
^ja-Q0895

**ja-Q0896 · Choose the form**

趣味というものを説明する____は出来ない。

There is no accounting for tastes.

Choices: のです / こと / もの

[[Japanese#^ja-Q0896-answer|Compare the answer]]
^ja-Q0896

**ja-Q0897 · Edit the changed sentence**

私は警官に知っている【もの】を全部話した。

I told the policeman what I knew.

[[Japanese#^ja-Q0897-answer|Compare the answer]]
^ja-Q0897

**ja-Q0898 · Build the sentence**

Arrange: を全部話した。 / 私は警官に知っている / こと

I told the policeman what I knew.

[[Japanese#^ja-Q0898-answer|Compare the answer]]
^ja-Q0898

**ja-Q0899 · Write a translation**

Write this in Japanese: I don't believe you. You're always telling lies.

[[Japanese#^ja-Q0899-answer|Compare the answer]]
^ja-Q0899

**ja-Q0900 · Explain the grammar**

ぼくは君の言う【こと】なんか信じないよ。君はいつもうそばかりついているじゃないか。

I don't believe you. You're always telling lies.

[[Japanese#^ja-Q0900-answer|Compare the answer]]
^ja-Q0900


### Polite requests · 50 questions

**ja-Q0901 · Fill the gap**

知らせて____。

Please let me know.

[[Japanese#^ja-Q0901-answer|Compare the answer]]
^ja-Q0901

**ja-Q0902 · Choose the form**

知らせて____。

Please let me know.

Choices: お願いします / ください

[[Japanese#^ja-Q0902-answer|Compare the answer]]
^ja-Q0902

**ja-Q0903 · Edit the changed sentence**

私にお茶を入れて【お願いします】。

Please make me some tea.

[[Japanese#^ja-Q0903-answer|Compare the answer]]
^ja-Q0903

**ja-Q0904 · Build the sentence**

Arrange: ください / 。 / 私にお茶を入れて

Please make me some tea.

[[Japanese#^ja-Q0904-answer|Compare the answer]]
^ja-Q0904

**ja-Q0905 · Write a translation**

Write this in Japanese: You should drink a lot of liquid.

[[Japanese#^ja-Q0905-answer|Compare the answer]]
^ja-Q0905

**ja-Q0906 · Explain the grammar**

水分をたくさん取って【ください】。

You should drink a lot of liquid.

[[Japanese#^ja-Q0906-answer|Compare the answer]]
^ja-Q0906

**ja-Q0907 · Fill the gap**

万一に備えて連絡をたもって____。

Try to keep in touch with me, just in case.

[[Japanese#^ja-Q0907-answer|Compare the answer]]
^ja-Q0907

**ja-Q0908 · Choose the form**

万一に備えて連絡をたもって____。

Try to keep in touch with me, just in case.

Choices: お願いします / ください

[[Japanese#^ja-Q0908-answer|Compare the answer]]
^ja-Q0908

**ja-Q0909 · Edit the changed sentence**

グラスワインの赤を【ください】。

A glass of red wine, please.

[[Japanese#^ja-Q0909-answer|Compare the answer]]
^ja-Q0909

**ja-Q0910 · Build the sentence**

Arrange: お願いします / 。 / グラスワインの赤を

A glass of red wine, please.

[[Japanese#^ja-Q0910-answer|Compare the answer]]
^ja-Q0910

**ja-Q0911 · Write a translation**

Write this in Japanese: Please don't boil the eggs so hard.

[[Japanese#^ja-Q0911-answer|Compare the answer]]
^ja-Q0911

**ja-Q0912 · Explain the grammar**

卵をあまり固くゆでないで【ください】。

Please don't boil the eggs so hard.

[[Japanese#^ja-Q0912-answer|Compare the answer]]
^ja-Q0912

**ja-Q0913 · Fill the gap**

お買い物にお越しの際には是非、お立ち寄り____。

Please, by all means, drop in when you go shopping.

[[Japanese#^ja-Q0913-answer|Compare the answer]]
^ja-Q0913

**ja-Q0914 · Choose the form**

お買い物にお越しの際には是非、お立ち寄り____。

Please, by all means, drop in when you go shopping.

Choices: ください / お願いします

[[Japanese#^ja-Q0914-answer|Compare the answer]]
^ja-Q0914

**ja-Q0915 · Edit the changed sentence**

あなたの新しい住所を教えて【お願いします】。

Let me know your new address.

[[Japanese#^ja-Q0915-answer|Compare the answer]]
^ja-Q0915

**ja-Q0916 · Build the sentence**

Arrange: 。 / ください / あなたの新しい住所を教えて

Let me know your new address.

[[Japanese#^ja-Q0916-answer|Compare the answer]]
^ja-Q0916

**ja-Q0917 · Write a translation**

Write this in Japanese: Please drink this three times per day.

[[Japanese#^ja-Q0917-answer|Compare the answer]]
^ja-Q0917

**ja-Q0918 · Explain the grammar**

これを１日に３回、飲んで【ください】。

Please drink this three times per day.

[[Japanese#^ja-Q0918-answer|Compare the answer]]
^ja-Q0918

**ja-Q0919 · Fill the gap**

アルコール類は控えて____。

Don't drink any alcohol.

[[Japanese#^ja-Q0919-answer|Compare the answer]]
^ja-Q0919

**ja-Q0920 · Choose the form**

アルコール類は控えて____。

Don't drink any alcohol.

Choices: お願いします / ください

[[Japanese#^ja-Q0920-answer|Compare the answer]]
^ja-Q0920

**ja-Q0921 · Edit the changed sentence**

手紙を速達で送って【お願いします】。

Please send the letter by express.

[[Japanese#^ja-Q0921-answer|Compare the answer]]
^ja-Q0921

**ja-Q0922 · Build the sentence**

Arrange: 手紙を速達で送って / 。 / ください

Please send the letter by express.

[[Japanese#^ja-Q0922-answer|Compare the answer]]
^ja-Q0922

**ja-Q0923 · Write a translation**

Write this in Japanese: Oh, don't worry about that.

[[Japanese#^ja-Q0923-answer|Compare the answer]]
^ja-Q0923

**ja-Q0924 · Explain the grammar**

そんな事は気にしないで【ください】。

Oh, don't worry about that.

[[Japanese#^ja-Q0924-answer|Compare the answer]]
^ja-Q0924

**ja-Q0925 · Fill the gap**

車を停めて____。

Please pull over.

[[Japanese#^ja-Q0925-answer|Compare the answer]]
^ja-Q0925

**ja-Q0926 · Choose the form**

車を停めて____。

Please pull over.

Choices: お願いします / ください

[[Japanese#^ja-Q0926-answer|Compare the answer]]
^ja-Q0926

**ja-Q0927 · Edit the changed sentence**

ちょっと電話を貸して【お願いします】。

May I use your telephone?

[[Japanese#^ja-Q0927-answer|Compare the answer]]
^ja-Q0927

**ja-Q0928 · Build the sentence**

Arrange: ください / ちょっと電話を貸して / 。

May I use your telephone?

[[Japanese#^ja-Q0928-answer|Compare the answer]]
^ja-Q0928

**ja-Q0929 · Write a translation**

Write this in Japanese: If you see this message, write to me.

[[Japanese#^ja-Q0929-answer|Compare the answer]]
^ja-Q0929

**ja-Q0930 · Explain the grammar**

このメッセージを見たら、返事を【ください】。

If you see this message, write to me.

[[Japanese#^ja-Q0930-answer|Compare the answer]]
^ja-Q0930

**ja-Q0931 · Fill the gap**

家を出る前にはガスのスイッチを切ることを忘れないで____。

Don't forget to turn off the gas before you leave the house.

[[Japanese#^ja-Q0931-answer|Compare the answer]]
^ja-Q0931

**ja-Q0932 · Choose the form**

家を出る前にはガスのスイッチを切ることを忘れないで____。

Don't forget to turn off the gas before you leave the house.

Choices: お願いします / ください

[[Japanese#^ja-Q0932-answer|Compare the answer]]
^ja-Q0932

**ja-Q0933 · Edit the changed sentence**

彼女にご協力【ください】ますことについて、あらかじめお礼を申し上げます。

I would like to thank you in advance for any help that you are able to give her.

[[Japanese#^ja-Q0933-answer|Compare the answer]]
^ja-Q0933

**ja-Q0934 · Build the sentence**

Arrange: ますことについて、あらかじめお礼を申し上げます。 / 彼女にご協力 / いただけ

I would like to thank you in advance for any help that you are able to give her.

[[Japanese#^ja-Q0934-answer|Compare the answer]]
^ja-Q0934

**ja-Q0935 · Write a translation**

Write this in Japanese: If you see a suspicious person, please inform the police.

[[Japanese#^ja-Q0935-answer|Compare the answer]]
^ja-Q0935

**ja-Q0936 · Explain the grammar**

不審者を見かけたら警察に通報して【ください】。

If you see a suspicious person, please inform the police.

[[Japanese#^ja-Q0936-answer|Compare the answer]]
^ja-Q0936

**ja-Q0937 · Fill the gap**

この用紙を保険会社に郵送して____。

Please mail this form to your insurance company.

[[Japanese#^ja-Q0937-answer|Compare the answer]]
^ja-Q0937

**ja-Q0938 · Choose the form**

この用紙を保険会社に郵送して____。

Please mail this form to your insurance company.

Choices: お願いします / ください

[[Japanese#^ja-Q0938-answer|Compare the answer]]
^ja-Q0938

**ja-Q0939 · Edit the changed sentence**

万一あなたの身に何か起これば、すぐに私たちに知らせて【お願いします】。

Should anything happen to you, let us know at once.

[[Japanese#^ja-Q0939-answer|Compare the answer]]
^ja-Q0939

**ja-Q0940 · Build the sentence**

Arrange: 万一あなたの身に何か起これば、すぐに私たちに知らせて / 。 / ください

Should anything happen to you, let us know at once.

[[Japanese#^ja-Q0940-answer|Compare the answer]]
^ja-Q0940

**ja-Q0941 · Write a translation**

Write this in Japanese: Excuse me, could you spare me a few minutes? I have a favor to ask you.

[[Japanese#^ja-Q0941-answer|Compare the answer]]
^ja-Q0941

**ja-Q0942 · Explain the grammar**

すみませんが、２～３分時間をさいて【いただけ】ませんか。お願いがあるんです。

Excuse me, could you spare me a few minutes? I have a favor to ask you.

[[Japanese#^ja-Q0942-answer|Compare the answer]]
^ja-Q0942

**ja-Q0943 · Fill the gap**

切符を見せて____。

Please show your ticket.

[[Japanese#^ja-Q0943-answer|Compare the answer]]
^ja-Q0943

**ja-Q0944 · Choose the form**

切符を見せて____。

Please show your ticket.

Choices: お願いします / ください

[[Japanese#^ja-Q0944-answer|Compare the answer]]
^ja-Q0944

**ja-Q0945 · Edit the changed sentence**

鏡を割らないで【お願いします】。

Don't break a mirror.

[[Japanese#^ja-Q0945-answer|Compare the answer]]
^ja-Q0945

**ja-Q0946 · Build the sentence**

Arrange: ください / 。 / 鏡を割らないで

Don't break a mirror.

[[Japanese#^ja-Q0946-answer|Compare the answer]]
^ja-Q0946

**ja-Q0947 · Write a translation**

Write this in Japanese: Watch out for thieves around here.

[[Japanese#^ja-Q0947-answer|Compare the answer]]
^ja-Q0947

**ja-Q0948 · Explain the grammar**

この近辺では窃盗犯に警戒して【ください】。

Watch out for thieves around here.

[[Japanese#^ja-Q0948-answer|Compare the answer]]
^ja-Q0948

**ja-Q0949 · Fill the gap**

紅茶を____ますか。

Could you get me some tea?

[[Japanese#^ja-Q0949-answer|Compare the answer]]
^ja-Q0949

**ja-Q0950 · Choose the form**

紅茶を____ますか。

Could you get me some tea?

Choices: ください / お願いします / いただけ

[[Japanese#^ja-Q0950-answer|Compare the answer]]
^ja-Q0950


### Questions and stance · 50 questions

**ja-Q0951 · Edit the changed sentence**

現在はどちらにお住まいです【でしょう】。

Where do you live now?

[[Japanese#^ja-Q0951-answer|Compare the answer]]
^ja-Q0951

**ja-Q0952 · Build the sentence**

Arrange: 現在はどちらにお住まいです / 。 / か

Where do you live now?

[[Japanese#^ja-Q0952-answer|Compare the answer]]
^ja-Q0952

**ja-Q0953 · Write a translation**

Write this in Japanese: Where is the bathroom?

[[Japanese#^ja-Q0953-answer|Compare the answer]]
^ja-Q0953

**ja-Q0954 · Explain the grammar**

風呂場はどこです【か】。

Where is the bathroom?

[[Japanese#^ja-Q0954-answer|Compare the answer]]
^ja-Q0954

**ja-Q0955 · Fill the gap**

ジュディは明日日本について話をする____。

Judy will talk about Japan tomorrow.

[[Japanese#^ja-Q0955-answer|Compare the answer]]
^ja-Q0955

**ja-Q0956 · Choose the form**

ジュディは明日日本について話をする____。

Judy will talk about Japan tomorrow.

Choices: でしょう / か / と思う

[[Japanese#^ja-Q0956-answer|Compare the answer]]
^ja-Q0956

**ja-Q0957 · Edit the changed sentence**

試験はうまくいった【か】。

I think my exam went well.

[[Japanese#^ja-Q0957-answer|Compare the answer]]
^ja-Q0957

**ja-Q0958 · Build the sentence**

Arrange: と思う / 。 / 試験はうまくいった

I think my exam went well.

[[Japanese#^ja-Q0958-answer|Compare the answer]]
^ja-Q0958

**ja-Q0959 · Write a translation**

Write this in Japanese: How's the weather?

[[Japanese#^ja-Q0959-answer|Compare the answer]]
^ja-Q0959

**ja-Q0960 · Explain the grammar**

どんな天気です【か】。

How's the weather?

[[Japanese#^ja-Q0960-answer|Compare the answer]]
^ja-Q0960

**ja-Q0961 · Fill the gap**

雑誌を持ってきましょう____。

Shall I bring a magazine?

[[Japanese#^ja-Q0961-answer|Compare the answer]]
^ja-Q0961

**ja-Q0962 · Choose the form**

雑誌を持ってきましょう____。

Shall I bring a magazine?

Choices: か / と思う / でしょう

[[Japanese#^ja-Q0962-answer|Compare the answer]]
^ja-Q0962

**ja-Q0963 · Edit the changed sentence**

最悪のシナリオは何です【でしょう】?

What's the worst case scenario?

[[Japanese#^ja-Q0963-answer|Compare the answer]]
^ja-Q0963

**ja-Q0964 · Build the sentence**

Arrange: ? / か / 最悪のシナリオは何です

What's the worst case scenario?

[[Japanese#^ja-Q0964-answer|Compare the answer]]
^ja-Q0964

**ja-Q0965 · Write a translation**

Write this in Japanese: Does Tom like tomatoes?

[[Japanese#^ja-Q0965-answer|Compare the answer]]
^ja-Q0965

**ja-Q0966 · Explain the grammar**

トムはトマトが好きです【か】。

Does Tom like tomatoes?

[[Japanese#^ja-Q0966-answer|Compare the answer]]
^ja-Q0966

**ja-Q0967 · Fill the gap**

時刻表をお持ちです____。

Do you have a timetable?

[[Japanese#^ja-Q0967-answer|Compare the answer]]
^ja-Q0967

**ja-Q0968 · Choose the form**

時刻表をお持ちです____。

Do you have a timetable?

Choices: か / でしょう / と思う

[[Japanese#^ja-Q0968-answer|Compare the answer]]
^ja-Q0968

**ja-Q0969 · Edit the changed sentence**

まもなく暗くなる【か】。

It will be dark soon.

[[Japanese#^ja-Q0969-answer|Compare the answer]]
^ja-Q0969

**ja-Q0970 · Build the sentence**

Arrange: 。 / でしょう / まもなく暗くなる

It will be dark soon.

[[Japanese#^ja-Q0970-answer|Compare the answer]]
^ja-Q0970

**ja-Q0971 · Write a translation**

Write this in Japanese: Don't you think you are a little too pushy?

[[Japanese#^ja-Q0971-answer|Compare the answer]]
^ja-Q0971

**ja-Q0972 · Explain the grammar**

少し、出しゃばりすぎると思わない【か】。

Don't you think you are a little too pushy?

[[Japanese#^ja-Q0972-answer|Compare the answer]]
^ja-Q0972

**ja-Q0973 · Fill the gap**

私はあなたは母親似だ____。

I think you resemble your mother.

[[Japanese#^ja-Q0973-answer|Compare the answer]]
^ja-Q0973

**ja-Q0974 · Choose the form**

私はあなたは母親似だ____。

I think you resemble your mother.

Choices: か / でしょう / と思う

[[Japanese#^ja-Q0974-answer|Compare the answer]]
^ja-Q0974

**ja-Q0975 · Edit the changed sentence**

傘をお借りしてもいいです【でしょう】？

Could I borrow an umbrella?

[[Japanese#^ja-Q0975-answer|Compare the answer]]
^ja-Q0975

**ja-Q0976 · Build the sentence**

Arrange: 傘をお借りしてもいいです / ？ / か

Could I borrow an umbrella?

[[Japanese#^ja-Q0976-answer|Compare the answer]]
^ja-Q0976

**ja-Q0977 · Write a translation**

Write this in Japanese: Where can I learn Korean?

[[Japanese#^ja-Q0977-answer|Compare the answer]]
^ja-Q0977

**ja-Q0978 · Explain the grammar**

韓国語はどこで学べます【か】？

Where can I learn Korean?

[[Japanese#^ja-Q0978-answer|Compare the answer]]
^ja-Q0978

**ja-Q0979 · Fill the gap**

彼は正直だ____。

I think he is honest.

[[Japanese#^ja-Q0979-answer|Compare the answer]]
^ja-Q0979

**ja-Q0980 · Choose the form**

彼は正直だ____。

I think he is honest.

Choices: でしょう / か / と思う

[[Japanese#^ja-Q0980-answer|Compare the answer]]
^ja-Q0980

**ja-Q0981 · Edit the changed sentence**

メグもパーティーに呼びましょう【でしょう】。

How about inviting Meg to the party?

[[Japanese#^ja-Q0981-answer|Compare the answer]]
^ja-Q0981

**ja-Q0982 · Build the sentence**

Arrange: か / 。 / メグもパーティーに呼びましょう

How about inviting Meg to the party?

[[Japanese#^ja-Q0982-answer|Compare the answer]]
^ja-Q0982

**ja-Q0983 · Write a translation**

Write this in Japanese: What the hell are you going to do with it?

[[Japanese#^ja-Q0983-answer|Compare the answer]]
^ja-Q0983

**ja-Q0984 · Explain the grammar**

一体全体、きみはそれをどうしようと言うつもりなの【か】。

What the hell are you going to do with it?

[[Japanese#^ja-Q0984-answer|Compare the answer]]
^ja-Q0984

**ja-Q0985 · Fill the gap**

これは本当です____。

Is this true?

[[Japanese#^ja-Q0985-answer|Compare the answer]]
^ja-Q0985

**ja-Q0986 · Choose the form**

これは本当です____。

Is this true?

Choices: でしょう / か / と思う

[[Japanese#^ja-Q0986-answer|Compare the answer]]
^ja-Q0986

**ja-Q0987 · Edit the changed sentence**

今学期は政治学を取っています【でしょう】。

Are you taking politics this semester?

[[Japanese#^ja-Q0987-answer|Compare the answer]]
^ja-Q0987

**ja-Q0988 · Build the sentence**

Arrange: か / 。 / 今学期は政治学を取っています

Are you taking politics this semester?

[[Japanese#^ja-Q0988-answer|Compare the answer]]
^ja-Q0988

**ja-Q0989 · Write a translation**

Write this in Japanese: Do you usually have tea for breakfast?

[[Japanese#^ja-Q0989-answer|Compare the answer]]
^ja-Q0989

**ja-Q0990 · Explain the grammar**

あなたはふつう朝食に紅茶を飲みます【か】。

Do you usually have tea for breakfast?

[[Japanese#^ja-Q0990-answer|Compare the answer]]
^ja-Q0990

**ja-Q0991 · Fill the gap**

どうして煙草を止める決心をしたのです____。

What made up your mind to quit smoking?

[[Japanese#^ja-Q0991-answer|Compare the answer]]
^ja-Q0991

**ja-Q0992 · Choose the form**

どうして煙草を止める決心をしたのです____。

What made up your mind to quit smoking?

Choices: でしょう / か / と思う

[[Japanese#^ja-Q0992-answer|Compare the answer]]
^ja-Q0992

**ja-Q0993 · Edit the changed sentence**

友人は空港へ見送りに来るのです【でしょう】。

Will your friends be seeing you off at the airport?

[[Japanese#^ja-Q0993-answer|Compare the answer]]
^ja-Q0993

**ja-Q0994 · Build the sentence**

Arrange: 友人は空港へ見送りに来るのです / 。 / か

Will your friends be seeing you off at the airport?

[[Japanese#^ja-Q0994-answer|Compare the answer]]
^ja-Q0994

**ja-Q0995 · Write a translation**

Write this in Japanese: Is there much sugar in the jar?

[[Japanese#^ja-Q0995-answer|Compare the answer]]
^ja-Q0995

**ja-Q0996 · Explain the grammar**

つぼにたくさん砂糖が入っています【か】。

Is there much sugar in the jar?

[[Japanese#^ja-Q0996-answer|Compare the answer]]
^ja-Q0996

**ja-Q0997 · Fill the gap**

あなたの所属は何部です____？

What club do you belong to?

[[Japanese#^ja-Q0997-answer|Compare the answer]]
^ja-Q0997

**ja-Q0998 · Choose the form**

あなたの所属は何部です____？

What club do you belong to?

Choices: か / と思う / でしょう

[[Japanese#^ja-Q0998-answer|Compare the answer]]
^ja-Q0998

**ja-Q0999 · Edit the changed sentence**

彼は四時にもどる【か】。

He will come back at four.

[[Japanese#^ja-Q0999-answer|Compare the answer]]
^ja-Q0999

**ja-Q1000 · Build the sentence**

Arrange: 。 / 彼は四時にもどる / でしょう

He will come back at four.

[[Japanese#^ja-Q1000-answer|Compare the answer]]
^ja-Q1000


## Answers

The full sentence is a model. For translation, judge whether meaning and grammar are preserved. Each grammar rule above explains the form.

### Answers 1–50

**ja-Q0001** — 彼女は無邪気なふりをした。

She pretended innocence.

Expected form: **は**

Why: Topic は. [[Japanese#^ja-Q0001|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E5%A5%B3%E3%81%AF%E7%84%A1%E9%82%AA%E6%B0%97%E3%81%AA%E3%81%B5%E3%82%8A%E3%82%92%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0001-answer

**ja-Q0002** — 彼女は無邪気なふりをした。

She pretended innocence.

Expected form: **は**

Why: Topic は. [[Japanese#^ja-Q0002|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E5%A5%B3%E3%81%AF%E7%84%A1%E9%82%AA%E6%B0%97%E3%81%AA%E3%81%B5%E3%82%8A%E3%82%92%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0002-answer

**ja-Q0003** — 私は息子に芝生に水を撒かせた。

I had my son water the lawn.

Expected form: **は**

Why: Topic は. [[Japanese#^ja-Q0003|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AF%E6%81%AF%E5%AD%90%E3%81%AB%E8%8A%9D%E7%94%9F%E3%81%AB%E6%B0%B4%E3%82%92%E6%92%92%E3%81%8B%E3%81%9B%E3%81%9F%E3%80%82)
^ja-Q0003-answer

**ja-Q0004** — 私は息子に芝生に水を撒かせた。

I had my son water the lawn.

Why: Topic は. [[Japanese#^ja-Q0004|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AF%E6%81%AF%E5%AD%90%E3%81%AB%E8%8A%9D%E7%94%9F%E3%81%AB%E6%B0%B4%E3%82%92%E6%92%92%E3%81%8B%E3%81%9B%E3%81%9F%E3%80%82)
^ja-Q0004-answer

**ja-Q0005** — 彼らはクリスマスイブに教会に行った。

They went to church on Christmas Eve.

Why: Topic は. [[Japanese#^ja-Q0005|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%82%89%E3%81%AF%E3%82%AF%E3%83%AA%E3%82%B9%E3%83%9E%E3%82%B9%E3%82%A4%E3%83%96%E3%81%AB%E6%95%99%E4%BC%9A%E3%81%AB%E8%A1%8C%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0005-answer

**ja-Q0006** — 彼らはクリスマスイブに教会に行った。

They went to church on Christmas Eve.

は marks a topic or contrast and is pronounced wa as a particle. A topic is not necessarily a grammatical subject. Japanese can omit participants understood from context.

Why: Topic は. [[Japanese#^ja-Q0006|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%82%89%E3%81%AF%E3%82%AF%E3%83%AA%E3%82%B9%E3%83%9E%E3%82%B9%E3%82%A4%E3%83%96%E3%81%AB%E6%95%99%E4%BC%9A%E3%81%AB%E8%A1%8C%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0006-answer

**ja-Q0007** — 年とともに、情熱は弱まり、習慣は強くなる。

Passions weaken, but habits strengthen, with age.

Expected form: **は**

Why: Topic は. [[Japanese#^ja-Q0007|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%B9%B4%E3%81%A8%E3%81%A8%E3%82%82%E3%81%AB%E3%80%81%E6%83%85%E7%86%B1%E3%81%AF%E5%BC%B1%E3%81%BE%E3%82%8A%E3%80%81%E7%BF%92%E6%85%A3%E3%81%AF%E5%BC%B7%E3%81%8F%E3%81%AA%E3%82%8B%E3%80%82)
^ja-Q0007-answer

**ja-Q0008** — 年とともに、情熱は弱まり、習慣は強くなる。

Passions weaken, but habits strengthen, with age.

Expected form: **は**

Why: Topic は. [[Japanese#^ja-Q0008|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%B9%B4%E3%81%A8%E3%81%A8%E3%82%82%E3%81%AB%E3%80%81%E6%83%85%E7%86%B1%E3%81%AF%E5%BC%B1%E3%81%BE%E3%82%8A%E3%80%81%E7%BF%92%E6%85%A3%E3%81%AF%E5%BC%B7%E3%81%8F%E3%81%AA%E3%82%8B%E3%80%82)
^ja-Q0008-answer

**ja-Q0009** — その女性は悲しげで、その上疲れているようだった。

The lady looked sad, also tired.

Expected form: **は**

Why: Topic は. [[Japanese#^ja-Q0009|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%9D%E3%81%AE%E5%A5%B3%E6%80%A7%E3%81%AF%E6%82%B2%E3%81%97%E3%81%92%E3%81%A7%E3%80%81%E3%81%9D%E3%81%AE%E4%B8%8A%E7%96%B2%E3%82%8C%E3%81%A6%E3%81%84%E3%82%8B%E3%82%88%E3%81%86%E3%81%A0%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0009-answer

**ja-Q0010** — その女性は悲しげで、その上疲れているようだった。

The lady looked sad, also tired.

Why: Topic は. [[Japanese#^ja-Q0010|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%9D%E3%81%AE%E5%A5%B3%E6%80%A7%E3%81%AF%E6%82%B2%E3%81%97%E3%81%92%E3%81%A7%E3%80%81%E3%81%9D%E3%81%AE%E4%B8%8A%E7%96%B2%E3%82%8C%E3%81%A6%E3%81%84%E3%82%8B%E3%82%88%E3%81%86%E3%81%A0%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0010-answer

**ja-Q0011** — 年会費はいくらですか。

How much is the annual membership fee?

Why: Topic は. [[Japanese#^ja-Q0011|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%B9%B4%E4%BC%9A%E8%B2%BB%E3%81%AF%E3%81%84%E3%81%8F%E3%82%89%E3%81%A7%E3%81%99%E3%81%8B%E3%80%82)
^ja-Q0011-answer

**ja-Q0012** — 年会費はいくらですか。

How much is the annual membership fee?

は marks a topic or contrast and is pronounced wa as a particle. A topic is not necessarily a grammatical subject. Japanese can omit participants understood from context.

Why: Topic は. [[Japanese#^ja-Q0012|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%B9%B4%E4%BC%9A%E8%B2%BB%E3%81%AF%E3%81%84%E3%81%8F%E3%82%89%E3%81%A7%E3%81%99%E3%81%8B%E3%80%82)
^ja-Q0012-answer

**ja-Q0013** — 彼は何らかの解決策を提案しましたか。

Did he propose any solutions?

Expected form: **は**

Why: Topic は. [[Japanese#^ja-Q0013|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%AF%E4%BD%95%E3%82%89%E3%81%8B%E3%81%AE%E8%A7%A3%E6%B1%BA%E7%AD%96%E3%82%92%E6%8F%90%E6%A1%88%E3%81%97%E3%81%BE%E3%81%97%E3%81%9F%E3%81%8B%E3%80%82)
^ja-Q0013-answer

**ja-Q0014** — 彼は何らかの解決策を提案しましたか。

Did he propose any solutions?

Expected form: **は**

Why: Topic は. [[Japanese#^ja-Q0014|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%AF%E4%BD%95%E3%82%89%E3%81%8B%E3%81%AE%E8%A7%A3%E6%B1%BA%E7%AD%96%E3%82%92%E6%8F%90%E6%A1%88%E3%81%97%E3%81%BE%E3%81%97%E3%81%9F%E3%81%8B%E3%80%82)
^ja-Q0014-answer

**ja-Q0015** — 彼がもう少し注意していれば、事故は防げたろうに。

If he had been a little more careful, the accident would have been avoided.

Expected form: **は**

Why: Topic は. [[Japanese#^ja-Q0015|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%8C%E3%82%82%E3%81%86%E5%B0%91%E3%81%97%E6%B3%A8%E6%84%8F%E3%81%97%E3%81%A6%E3%81%84%E3%82%8C%E3%81%B0%E3%80%81%E4%BA%8B%E6%95%85%E3%81%AF%E9%98%B2%E3%81%92%E3%81%9F%E3%82%8D%E3%81%86%E3%81%AB%E3%80%82)
^ja-Q0015-answer

**ja-Q0016** — 彼がもう少し注意していれば、事故は防げたろうに。

If he had been a little more careful, the accident would have been avoided.

Why: Topic は. [[Japanese#^ja-Q0016|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%8C%E3%82%82%E3%81%86%E5%B0%91%E3%81%97%E6%B3%A8%E6%84%8F%E3%81%97%E3%81%A6%E3%81%84%E3%82%8C%E3%81%B0%E3%80%81%E4%BA%8B%E6%95%85%E3%81%AF%E9%98%B2%E3%81%92%E3%81%9F%E3%82%8D%E3%81%86%E3%81%AB%E3%80%82)
^ja-Q0016-answer

**ja-Q0017** — 手紙を書く際の最善の方法は、心にあることを何でも書き留めることだ。

The best way to write letters is to put down whatever is in your mind.

Why: Topic は. [[Japanese#^ja-Q0017|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%89%8B%E7%B4%99%E3%82%92%E6%9B%B8%E3%81%8F%E9%9A%9B%E3%81%AE%E6%9C%80%E5%96%84%E3%81%AE%E6%96%B9%E6%B3%95%E3%81%AF%E3%80%81%E5%BF%83%E3%81%AB%E3%81%82%E3%82%8B%E3%81%93%E3%81%A8%E3%82%92%E4%BD%95%E3%81%A7%E3%82%82%E6%9B%B8%E3%81%8D%E7%95%99%E3%82%81%E3%82%8B%E3%81%93%E3%81%A8%E3%81%A0%E3%80%82)
^ja-Q0017-answer

**ja-Q0018** — 手紙を書く際の最善の方法は、心にあることを何でも書き留めることだ。

The best way to write letters is to put down whatever is in your mind.

は marks a topic or contrast and is pronounced wa as a particle. A topic is not necessarily a grammatical subject. Japanese can omit participants understood from context.

Why: Topic は. [[Japanese#^ja-Q0018|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%89%8B%E7%B4%99%E3%82%92%E6%9B%B8%E3%81%8F%E9%9A%9B%E3%81%AE%E6%9C%80%E5%96%84%E3%81%AE%E6%96%B9%E6%B3%95%E3%81%AF%E3%80%81%E5%BF%83%E3%81%AB%E3%81%82%E3%82%8B%E3%81%93%E3%81%A8%E3%82%92%E4%BD%95%E3%81%A7%E3%82%82%E6%9B%B8%E3%81%8D%E7%95%99%E3%82%81%E3%82%8B%E3%81%93%E3%81%A8%E3%81%A0%E3%80%82)
^ja-Q0018-answer

**ja-Q0019** — 彼女の息子は交通事故で死んだ。

Her son was killed in a traffic accident.

Expected form: **は**

Why: Topic は. [[Japanese#^ja-Q0019|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E5%A5%B3%E3%81%AE%E6%81%AF%E5%AD%90%E3%81%AF%E4%BA%A4%E9%80%9A%E4%BA%8B%E6%95%85%E3%81%A7%E6%AD%BB%E3%82%93%E3%81%A0%E3%80%82)
^ja-Q0019-answer

**ja-Q0020** — 彼女の息子は交通事故で死んだ。

Her son was killed in a traffic accident.

Expected form: **は**

Why: Topic は. [[Japanese#^ja-Q0020|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E5%A5%B3%E3%81%AE%E6%81%AF%E5%AD%90%E3%81%AF%E4%BA%A4%E9%80%9A%E4%BA%8B%E6%95%85%E3%81%A7%E6%AD%BB%E3%82%93%E3%81%A0%E3%80%82)
^ja-Q0020-answer

**ja-Q0021** — このピアノを弾いてもいいが、夜はだめだ。

You can play this piano, but not at night.

Expected form: **は**

Why: Topic は. [[Japanese#^ja-Q0021|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%93%E3%81%AE%E3%83%94%E3%82%A2%E3%83%8E%E3%82%92%E5%BC%BE%E3%81%84%E3%81%A6%E3%82%82%E3%81%84%E3%81%84%E3%81%8C%E3%80%81%E5%A4%9C%E3%81%AF%E3%81%A0%E3%82%81%E3%81%A0%E3%80%82)
^ja-Q0021-answer

**ja-Q0022** — このピアノを弾いてもいいが、夜はだめだ。

You can play this piano, but not at night.

Why: Topic は. [[Japanese#^ja-Q0022|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%93%E3%81%AE%E3%83%94%E3%82%A2%E3%83%8E%E3%82%92%E5%BC%BE%E3%81%84%E3%81%A6%E3%82%82%E3%81%84%E3%81%84%E3%81%8C%E3%80%81%E5%A4%9C%E3%81%AF%E3%81%A0%E3%82%81%E3%81%A0%E3%80%82)
^ja-Q0022-answer

**ja-Q0023** — それは私の信念には合わない。

That goes against my beliefs.

Why: Topic は. [[Japanese#^ja-Q0023|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%9D%E3%82%8C%E3%81%AF%E7%A7%81%E3%81%AE%E4%BF%A1%E5%BF%B5%E3%81%AB%E3%81%AF%E5%90%88%E3%82%8F%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0023-answer

**ja-Q0024** — それは私の信念には合わない。

That goes against my beliefs.

は marks a topic or contrast and is pronounced wa as a particle. A topic is not necessarily a grammatical subject. Japanese can omit participants understood from context.

Why: Topic は. [[Japanese#^ja-Q0024|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%9D%E3%82%8C%E3%81%AF%E7%A7%81%E3%81%AE%E4%BF%A1%E5%BF%B5%E3%81%AB%E3%81%AF%E5%90%88%E3%82%8F%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0024-answer

**ja-Q0025** — 私は自身の部屋がほしい。

I want to have my own room.

Expected form: **は**

Why: Topic は. [[Japanese#^ja-Q0025|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AF%E8%87%AA%E8%BA%AB%E3%81%AE%E9%83%A8%E5%B1%8B%E3%81%8C%E3%81%BB%E3%81%97%E3%81%84%E3%80%82)
^ja-Q0025-answer

**ja-Q0026** — 私は自身の部屋がほしい。

I want to have my own room.

Expected form: **は**

Why: Topic は. [[Japanese#^ja-Q0026|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AF%E8%87%AA%E8%BA%AB%E3%81%AE%E9%83%A8%E5%B1%8B%E3%81%8C%E3%81%BB%E3%81%97%E3%81%84%E3%80%82)
^ja-Q0026-answer

**ja-Q0027** — この制度には改良の余地がない。

There is no room for further improvement in this system.

Expected form: **は**

Why: Topic は. [[Japanese#^ja-Q0027|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%93%E3%81%AE%E5%88%B6%E5%BA%A6%E3%81%AB%E3%81%AF%E6%94%B9%E8%89%AF%E3%81%AE%E4%BD%99%E5%9C%B0%E3%81%8C%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0027-answer

**ja-Q0028** — この制度には改良の余地がない。

There is no room for further improvement in this system.

Why: Topic は. [[Japanese#^ja-Q0028|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%93%E3%81%AE%E5%88%B6%E5%BA%A6%E3%81%AB%E3%81%AF%E6%94%B9%E8%89%AF%E3%81%AE%E4%BD%99%E5%9C%B0%E3%81%8C%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0028-answer

**ja-Q0029** — 京都にいる私の兄は先生になった。

My brother in Kyoto became a teacher.

Why: Topic は. [[Japanese#^ja-Q0029|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E4%BA%AC%E9%83%BD%E3%81%AB%E3%81%84%E3%82%8B%E7%A7%81%E3%81%AE%E5%85%84%E3%81%AF%E5%85%88%E7%94%9F%E3%81%AB%E3%81%AA%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0029-answer

**ja-Q0030** — 京都にいる私の兄は先生になった。

My brother in Kyoto became a teacher.

は marks a topic or contrast and is pronounced wa as a particle. A topic is not necessarily a grammatical subject. Japanese can omit participants understood from context.

Why: Topic は. [[Japanese#^ja-Q0030|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E4%BA%AC%E9%83%BD%E3%81%AB%E3%81%84%E3%82%8B%E7%A7%81%E3%81%AE%E5%85%84%E3%81%AF%E5%85%88%E7%94%9F%E3%81%AB%E3%81%AA%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0030-answer

**ja-Q0031** — 私の兄は電車の中でスリにあった。

My brother had his pocket picked in the train.

Expected form: **は**

Why: Topic は. [[Japanese#^ja-Q0031|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AE%E5%85%84%E3%81%AF%E9%9B%BB%E8%BB%8A%E3%81%AE%E4%B8%AD%E3%81%A7%E3%82%B9%E3%83%AA%E3%81%AB%E3%81%82%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0031-answer

**ja-Q0032** — 私の兄は電車の中でスリにあった。

My brother had his pocket picked in the train.

Expected form: **は**

Why: Topic は. [[Japanese#^ja-Q0032|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AE%E5%85%84%E3%81%AF%E9%9B%BB%E8%BB%8A%E3%81%AE%E4%B8%AD%E3%81%A7%E3%82%B9%E3%83%AA%E3%81%AB%E3%81%82%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0032-answer

**ja-Q0033** — 写真を撮るためには、このボタンを押しさえすればよい。

All you have to do to take a picture is push this button.

Expected form: **は**

Why: Topic は. [[Japanese#^ja-Q0033|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%86%99%E7%9C%9F%E3%82%92%E6%92%AE%E3%82%8B%E3%81%9F%E3%82%81%E3%81%AB%E3%81%AF%E3%80%81%E3%81%93%E3%81%AE%E3%83%9C%E3%82%BF%E3%83%B3%E3%82%92%E6%8A%BC%E3%81%97%E3%81%95%E3%81%88%E3%81%99%E3%82%8C%E3%81%B0%E3%82%88%E3%81%84%E3%80%82)
^ja-Q0033-answer

**ja-Q0034** — 写真を撮るためには、このボタンを押しさえすればよい。

All you have to do to take a picture is push this button.

Why: Topic は. [[Japanese#^ja-Q0034|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%86%99%E7%9C%9F%E3%82%92%E6%92%AE%E3%82%8B%E3%81%9F%E3%82%81%E3%81%AB%E3%81%AF%E3%80%81%E3%81%93%E3%81%AE%E3%83%9C%E3%82%BF%E3%83%B3%E3%82%92%E6%8A%BC%E3%81%97%E3%81%95%E3%81%88%E3%81%99%E3%82%8C%E3%81%B0%E3%82%88%E3%81%84%E3%80%82)
^ja-Q0034-answer

**ja-Q0035** — 驕傲は人間の弱さである。

Human pride is human weakness.

Why: Topic は. [[Japanese#^ja-Q0035|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E9%A9%95%E5%82%B2%E3%81%AF%E4%BA%BA%E9%96%93%E3%81%AE%E5%BC%B1%E3%81%95%E3%81%A7%E3%81%82%E3%82%8B%E3%80%82)
^ja-Q0035-answer

**ja-Q0036** — 驕傲は人間の弱さである。

Human pride is human weakness.

は marks a topic or contrast and is pronounced wa as a particle. A topic is not necessarily a grammatical subject. Japanese can omit participants understood from context.

Why: Topic は. [[Japanese#^ja-Q0036|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E9%A9%95%E5%82%B2%E3%81%AF%E4%BA%BA%E9%96%93%E3%81%AE%E5%BC%B1%E3%81%95%E3%81%A7%E3%81%82%E3%82%8B%E3%80%82)
^ja-Q0036-answer

**ja-Q0037** — 彼女はエイミーと呼ばれている。

She goes by the name of Amy.

Expected form: **は**

Why: Topic は. [[Japanese#^ja-Q0037|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E5%A5%B3%E3%81%AF%E3%82%A8%E3%82%A4%E3%83%9F%E3%83%BC%E3%81%A8%E5%91%BC%E3%81%B0%E3%82%8C%E3%81%A6%E3%81%84%E3%82%8B%E3%80%82)
^ja-Q0037-answer

**ja-Q0038** — 彼女はエイミーと呼ばれている。

She goes by the name of Amy.

Expected form: **は**

Why: Topic は. [[Japanese#^ja-Q0038|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E5%A5%B3%E3%81%AF%E3%82%A8%E3%82%A4%E3%83%9F%E3%83%BC%E3%81%A8%E5%91%BC%E3%81%B0%E3%82%8C%E3%81%A6%E3%81%84%E3%82%8B%E3%80%82)
^ja-Q0038-answer

**ja-Q0039** — 品物は良好な状態で到着した。

The goods arrived in good condition.

Expected form: **は**

Why: Topic は. [[Japanese#^ja-Q0039|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%93%81%E7%89%A9%E3%81%AF%E8%89%AF%E5%A5%BD%E3%81%AA%E7%8A%B6%E6%85%8B%E3%81%A7%E5%88%B0%E7%9D%80%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0039-answer

**ja-Q0040** — 品物は良好な状態で到着した。

The goods arrived in good condition.

Why: Topic は. [[Japanese#^ja-Q0040|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%93%81%E7%89%A9%E3%81%AF%E8%89%AF%E5%A5%BD%E3%81%AA%E7%8A%B6%E6%85%8B%E3%81%A7%E5%88%B0%E7%9D%80%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0040-answer

**ja-Q0041** — 彼女は弁護士として成功するだろうと思う。

I think she will succeed as a lawyer.

Why: Topic は. [[Japanese#^ja-Q0041|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E5%A5%B3%E3%81%AF%E5%BC%81%E8%AD%B7%E5%A3%AB%E3%81%A8%E3%81%97%E3%81%A6%E6%88%90%E5%8A%9F%E3%81%99%E3%82%8B%E3%81%A0%E3%82%8D%E3%81%86%E3%81%A8%E6%80%9D%E3%81%86%E3%80%82)
^ja-Q0041-answer

**ja-Q0042** — 彼女は弁護士として成功するだろうと思う。

I think she will succeed as a lawyer.

は marks a topic or contrast and is pronounced wa as a particle. A topic is not necessarily a grammatical subject. Japanese can omit participants understood from context.

Why: Topic は. [[Japanese#^ja-Q0042|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E5%A5%B3%E3%81%AF%E5%BC%81%E8%AD%B7%E5%A3%AB%E3%81%A8%E3%81%97%E3%81%A6%E6%88%90%E5%8A%9F%E3%81%99%E3%82%8B%E3%81%A0%E3%82%8D%E3%81%86%E3%81%A8%E6%80%9D%E3%81%86%E3%80%82)
^ja-Q0042-answer

**ja-Q0043** — トムは周囲を見回したが、誰の姿も見なかった。

Tom looked around, but saw no one.

Expected form: **は**

Why: Topic は. [[Japanese#^ja-Q0043|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%83%88%E3%83%A0%E3%81%AF%E5%91%A8%E5%9B%B2%E3%82%92%E8%A6%8B%E5%9B%9E%E3%81%97%E3%81%9F%E3%81%8C%E3%80%81%E8%AA%B0%E3%81%AE%E5%A7%BF%E3%82%82%E8%A6%8B%E3%81%AA%E3%81%8B%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0043-answer

**ja-Q0044** — トムは周囲を見回したが、誰の姿も見なかった。

Tom looked around, but saw no one.

Expected form: **は**

Why: Topic は. [[Japanese#^ja-Q0044|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%83%88%E3%83%A0%E3%81%AF%E5%91%A8%E5%9B%B2%E3%82%92%E8%A6%8B%E5%9B%9E%E3%81%97%E3%81%9F%E3%81%8C%E3%80%81%E8%AA%B0%E3%81%AE%E5%A7%BF%E3%82%82%E8%A6%8B%E3%81%AA%E3%81%8B%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0044-answer

**ja-Q0045** — 私はあなたにその歌をうたってもらいたい。

I want you to sing the song.

Expected form: **は**

Why: Topic は. [[Japanese#^ja-Q0045|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AF%E3%81%82%E3%81%AA%E3%81%9F%E3%81%AB%E3%81%9D%E3%81%AE%E6%AD%8C%E3%82%92%E3%81%86%E3%81%9F%E3%81%A3%E3%81%A6%E3%82%82%E3%82%89%E3%81%84%E3%81%9F%E3%81%84%E3%80%82)
^ja-Q0045-answer

**ja-Q0046** — 私はあなたにその歌をうたってもらいたい。

I want you to sing the song.

Why: Topic は. [[Japanese#^ja-Q0046|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AF%E3%81%82%E3%81%AA%E3%81%9F%E3%81%AB%E3%81%9D%E3%81%AE%E6%AD%8C%E3%82%92%E3%81%86%E3%81%9F%E3%81%A3%E3%81%A6%E3%82%82%E3%82%89%E3%81%84%E3%81%9F%E3%81%84%E3%80%82)
^ja-Q0046-answer

**ja-Q0047** — 彼は病院で意識を回復した。

He regained consciousness in the hospital.

Why: Topic は. [[Japanese#^ja-Q0047|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%AF%E7%97%85%E9%99%A2%E3%81%A7%E6%84%8F%E8%AD%98%E3%82%92%E5%9B%9E%E5%BE%A9%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0047-answer

**ja-Q0048** — 彼は病院で意識を回復した。

He regained consciousness in the hospital.

は marks a topic or contrast and is pronounced wa as a particle. A topic is not necessarily a grammatical subject. Japanese can omit participants understood from context.

Why: Topic は. [[Japanese#^ja-Q0048|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%AF%E7%97%85%E9%99%A2%E3%81%A7%E6%84%8F%E8%AD%98%E3%82%92%E5%9B%9E%E5%BE%A9%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0048-answer

**ja-Q0049** — なんでここにトムはいてメアリーはいないの?

Why is Tom here and not Mary?

Expected form: **は**

Why: Topic は. [[Japanese#^ja-Q0049|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%AA%E3%82%93%E3%81%A7%E3%81%93%E3%81%93%E3%81%AB%E3%83%88%E3%83%A0%E3%81%AF%E3%81%84%E3%81%A6%E3%83%A1%E3%82%A2%E3%83%AA%E3%83%BC%E3%81%AF%E3%81%84%E3%81%AA%E3%81%84%E3%81%AE%3F)
^ja-Q0049-answer

**ja-Q0050** — なんでここにトムはいてメアリーはいないの?

Why is Tom here and not Mary?

Expected form: **は**

Why: Topic は. [[Japanese#^ja-Q0050|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%AA%E3%82%93%E3%81%A7%E3%81%93%E3%81%93%E3%81%AB%E3%83%88%E3%83%A0%E3%81%AF%E3%81%84%E3%81%A6%E3%83%A1%E3%82%A2%E3%83%AA%E3%83%BC%E3%81%AF%E3%81%84%E3%81%AA%E3%81%84%E3%81%AE%3F)
^ja-Q0050-answer


### Answers 51–100

**ja-Q0051** — 怒鳴りつけたかったが思いとどまった。

He was about to explode, but checked himself.

Expected form: **が**

Why: Subject and focus が. [[Japanese#^ja-Q0051|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%80%92%E9%B3%B4%E3%82%8A%E3%81%A4%E3%81%91%E3%81%9F%E3%81%8B%E3%81%A3%E3%81%9F%E3%81%8C%E6%80%9D%E3%81%84%E3%81%A8%E3%81%A9%E3%81%BE%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0051-answer

**ja-Q0052** — 怒鳴りつけたかったが思いとどまった。

He was about to explode, but checked himself.

Why: Subject and focus が. [[Japanese#^ja-Q0052|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%80%92%E9%B3%B4%E3%82%8A%E3%81%A4%E3%81%91%E3%81%9F%E3%81%8B%E3%81%A3%E3%81%9F%E3%81%8C%E6%80%9D%E3%81%84%E3%81%A8%E3%81%A9%E3%81%BE%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0052-answer

**ja-Q0053** — オーストラリアには多くのおもしろい動物がいる。

There are many interesting animals in Australia.

Why: Subject and focus が. [[Japanese#^ja-Q0053|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%82%AA%E3%83%BC%E3%82%B9%E3%83%88%E3%83%A9%E3%83%AA%E3%82%A2%E3%81%AB%E3%81%AF%E5%A4%9A%E3%81%8F%E3%81%AE%E3%81%8A%E3%82%82%E3%81%97%E3%82%8D%E3%81%84%E5%8B%95%E7%89%A9%E3%81%8C%E3%81%84%E3%82%8B%E3%80%82)
^ja-Q0053-answer

**ja-Q0054** — オーストラリアには多くのおもしろい動物がいる。

There are many interesting animals in Australia.

が often marks a subject or focused identification. Certain predicates govern が for a participant English treats differently. It also links clauses with a contrasting meaning in another construction.

Why: Subject and focus が. [[Japanese#^ja-Q0054|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%82%AA%E3%83%BC%E3%82%B9%E3%83%88%E3%83%A9%E3%83%AA%E3%82%A2%E3%81%AB%E3%81%AF%E5%A4%9A%E3%81%8F%E3%81%AE%E3%81%8A%E3%82%82%E3%81%97%E3%82%8D%E3%81%84%E5%8B%95%E7%89%A9%E3%81%8C%E3%81%84%E3%82%8B%E3%80%82)
^ja-Q0054-answer

**ja-Q0055** — 仕事もたいがい片付いた。

Almost all the work is done now.

Expected form: **が**

Why: Subject and focus が. [[Japanese#^ja-Q0055|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E4%BB%95%E4%BA%8B%E3%82%82%E3%81%9F%E3%81%84%E3%81%8C%E3%81%84%E7%89%87%E4%BB%98%E3%81%84%E3%81%9F%E3%80%82)
^ja-Q0055-answer

**ja-Q0056** — 仕事もたいがい片付いた。

Almost all the work is done now.

Expected form: **が**

Why: Subject and focus が. [[Japanese#^ja-Q0056|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E4%BB%95%E4%BA%8B%E3%82%82%E3%81%9F%E3%81%84%E3%81%8C%E3%81%84%E7%89%87%E4%BB%98%E3%81%84%E3%81%9F%E3%80%82)
^ja-Q0056-answer

**ja-Q0057** — 太陽がなければ、我々は生きてゆけないだろう。

If it were not for the sun, we could not live at all.

Expected form: **が**

Why: Subject and focus が. [[Japanese#^ja-Q0057|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%A4%AA%E9%99%BD%E3%81%8C%E3%81%AA%E3%81%91%E3%82%8C%E3%81%B0%E3%80%81%E6%88%91%E3%80%85%E3%81%AF%E7%94%9F%E3%81%8D%E3%81%A6%E3%82%86%E3%81%91%E3%81%AA%E3%81%84%E3%81%A0%E3%82%8D%E3%81%86%E3%80%82)
^ja-Q0057-answer

**ja-Q0058** — 太陽がなければ、我々は生きてゆけないだろう。

If it were not for the sun, we could not live at all.

Why: Subject and focus が. [[Japanese#^ja-Q0058|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%A4%AA%E9%99%BD%E3%81%8C%E3%81%AA%E3%81%91%E3%82%8C%E3%81%B0%E3%80%81%E6%88%91%E3%80%85%E3%81%AF%E7%94%9F%E3%81%8D%E3%81%A6%E3%82%86%E3%81%91%E3%81%AA%E3%81%84%E3%81%A0%E3%82%8D%E3%81%86%E3%80%82)
^ja-Q0058-answer

**ja-Q0059** — これから先何が起きるかだれも分からない。

No one can tell what'll happen in the future.

Why: Subject and focus が. [[Japanese#^ja-Q0059|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%93%E3%82%8C%E3%81%8B%E3%82%89%E5%85%88%E4%BD%95%E3%81%8C%E8%B5%B7%E3%81%8D%E3%82%8B%E3%81%8B%E3%81%A0%E3%82%8C%E3%82%82%E5%88%86%E3%81%8B%E3%82%89%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0059-answer

**ja-Q0060** — これから先何が起きるかだれも分からない。

No one can tell what'll happen in the future.

が often marks a subject or focused identification. Certain predicates govern が for a participant English treats differently. It also links clauses with a contrasting meaning in another construction.

Why: Subject and focus が. [[Japanese#^ja-Q0060|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%93%E3%82%8C%E3%81%8B%E3%82%89%E5%85%88%E4%BD%95%E3%81%8C%E8%B5%B7%E3%81%8D%E3%82%8B%E3%81%8B%E3%81%A0%E3%82%8C%E3%82%82%E5%88%86%E3%81%8B%E3%82%89%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0060-answer

**ja-Q0061** — 先生は私が東大に入る可能性について非常に率直だった。

The teacher was quite candid about my chances of entering Tokyo University.

Expected form: **が**

Why: Subject and focus が. [[Japanese#^ja-Q0061|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%85%88%E7%94%9F%E3%81%AF%E7%A7%81%E3%81%8C%E6%9D%B1%E5%A4%A7%E3%81%AB%E5%85%A5%E3%82%8B%E5%8F%AF%E8%83%BD%E6%80%A7%E3%81%AB%E3%81%A4%E3%81%84%E3%81%A6%E9%9D%9E%E5%B8%B8%E3%81%AB%E7%8E%87%E7%9B%B4%E3%81%A0%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0061-answer

**ja-Q0062** — 先生は私が東大に入る可能性について非常に率直だった。

The teacher was quite candid about my chances of entering Tokyo University.

Expected form: **が**

Why: Subject and focus が. [[Japanese#^ja-Q0062|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%85%88%E7%94%9F%E3%81%AF%E7%A7%81%E3%81%8C%E6%9D%B1%E5%A4%A7%E3%81%AB%E5%85%A5%E3%82%8B%E5%8F%AF%E8%83%BD%E6%80%A7%E3%81%AB%E3%81%A4%E3%81%84%E3%81%A6%E9%9D%9E%E5%B8%B8%E3%81%AB%E7%8E%87%E7%9B%B4%E3%81%A0%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0062-answer

**ja-Q0063** — 僕の友達はみなサッカーが好きだ。

All of my friends like soccer.

Expected form: **が**

Why: Subject and focus が. [[Japanese#^ja-Q0063|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%83%95%E3%81%AE%E5%8F%8B%E9%81%94%E3%81%AF%E3%81%BF%E3%81%AA%E3%82%B5%E3%83%83%E3%82%AB%E3%83%BC%E3%81%8C%E5%A5%BD%E3%81%8D%E3%81%A0%E3%80%82)
^ja-Q0063-answer

**ja-Q0064** — 僕の友達はみなサッカーが好きだ。

All of my friends like soccer.

Why: Subject and focus が. [[Japanese#^ja-Q0064|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%83%95%E3%81%AE%E5%8F%8B%E9%81%94%E3%81%AF%E3%81%BF%E3%81%AA%E3%82%B5%E3%83%83%E3%82%AB%E3%83%BC%E3%81%8C%E5%A5%BD%E3%81%8D%E3%81%A0%E3%80%82)
^ja-Q0064-answer

**ja-Q0065** — 霧が深かったので、歩いている人たちの姿を似分けるのは困難だった。

It was foggy, so it was hard to make out the figures of people walking.

Why: Subject and focus が. [[Japanese#^ja-Q0065|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E9%9C%A7%E3%81%8C%E6%B7%B1%E3%81%8B%E3%81%A3%E3%81%9F%E3%81%AE%E3%81%A7%E3%80%81%E6%AD%A9%E3%81%84%E3%81%A6%E3%81%84%E3%82%8B%E4%BA%BA%E3%81%9F%E3%81%A1%E3%81%AE%E5%A7%BF%E3%82%92%E4%BC%BC%E5%88%86%E3%81%91%E3%82%8B%E3%81%AE%E3%81%AF%E5%9B%B0%E9%9B%A3%E3%81%A0%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0065-answer

**ja-Q0066** — 霧が深かったので、歩いている人たちの姿を似分けるのは困難だった。

It was foggy, so it was hard to make out the figures of people walking.

が often marks a subject or focused identification. Certain predicates govern が for a participant English treats differently. It also links clauses with a contrasting meaning in another construction.

Why: Subject and focus が. [[Japanese#^ja-Q0066|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E9%9C%A7%E3%81%8C%E6%B7%B1%E3%81%8B%E3%81%A3%E3%81%9F%E3%81%AE%E3%81%A7%E3%80%81%E6%AD%A9%E3%81%84%E3%81%A6%E3%81%84%E3%82%8B%E4%BA%BA%E3%81%9F%E3%81%A1%E3%81%AE%E5%A7%BF%E3%82%92%E4%BC%BC%E5%88%86%E3%81%91%E3%82%8B%E3%81%AE%E3%81%AF%E5%9B%B0%E9%9B%A3%E3%81%A0%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0066-answer

**ja-Q0067** — そういうわけで彼らは世界中の彼らの道をみつけることができるのです。

This is why they can find their way around the world.

Expected form: **が**

Why: Subject and focus が. [[Japanese#^ja-Q0067|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%9D%E3%81%86%E3%81%84%E3%81%86%E3%82%8F%E3%81%91%E3%81%A7%E5%BD%BC%E3%82%89%E3%81%AF%E4%B8%96%E7%95%8C%E4%B8%AD%E3%81%AE%E5%BD%BC%E3%82%89%E3%81%AE%E9%81%93%E3%82%92%E3%81%BF%E3%81%A4%E3%81%91%E3%82%8B%E3%81%93%E3%81%A8%E3%81%8C%E3%81%A7%E3%81%8D%E3%82%8B%E3%81%AE%E3%81%A7%E3%81%99%E3%80%82)
^ja-Q0067-answer

**ja-Q0068** — そういうわけで彼らは世界中の彼らの道をみつけることができるのです。

This is why they can find their way around the world.

Expected form: **が**

Why: Subject and focus が. [[Japanese#^ja-Q0068|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%9D%E3%81%86%E3%81%84%E3%81%86%E3%82%8F%E3%81%91%E3%81%A7%E5%BD%BC%E3%82%89%E3%81%AF%E4%B8%96%E7%95%8C%E4%B8%AD%E3%81%AE%E5%BD%BC%E3%82%89%E3%81%AE%E9%81%93%E3%82%92%E3%81%BF%E3%81%A4%E3%81%91%E3%82%8B%E3%81%93%E3%81%A8%E3%81%8C%E3%81%A7%E3%81%8D%E3%82%8B%E3%81%AE%E3%81%A7%E3%81%99%E3%80%82)
^ja-Q0068-answer

**ja-Q0069** — 実は、その出来事が新聞に載らなかったのは、たった一人の目撃者を除いては誰ひとりとしてそのことを知っている者はなかった――という極く簡単な事情に原因しているのである。

In truth, the very simple reason why this incident did not appear in the newspapers is that, outside of a single witness, no one knew about it.

Expected form: **が**

Why: Subject and focus が. [[Japanese#^ja-Q0069|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%AE%9F%E3%81%AF%E3%80%81%E3%81%9D%E3%81%AE%E5%87%BA%E6%9D%A5%E4%BA%8B%E3%81%8C%E6%96%B0%E8%81%9E%E3%81%AB%E8%BC%89%E3%82%89%E3%81%AA%E3%81%8B%E3%81%A3%E3%81%9F%E3%81%AE%E3%81%AF%E3%80%81%E3%81%9F%E3%81%A3%E3%81%9F%E4%B8%80%E4%BA%BA%E3%81%AE%E7%9B%AE%E6%92%83%E8%80%85%E3%82%92%E9%99%A4%E3%81%84%E3%81%A6%E3%81%AF%E8%AA%B0%E3%81%B2%E3%81%A8%E3%82%8A%E3%81%A8%E3%81%97%E3%81%A6%E3%81%9D%E3%81%AE%E3%81%93%E3%81%A8%E3%82%92%E7%9F%A5%E3%81%A3%E3%81%A6%E3%81%84%E3%82%8B%E8%80%85%E3%81%AF%E3%81%AA%E3%81%8B%E3%81%A3%E3%81%9F%E2%80%95%E2%80%95%E3%81%A8%E3%81%84%E3%81%86%E6%A5%B5%E3%81%8F%E7%B0%A1%E5%8D%98%E3%81%AA%E4%BA%8B%E6%83%85%E3%81%AB%E5%8E%9F%E5%9B%A0%E3%81%97%E3%81%A6%E3%81%84%E3%82%8B%E3%81%AE%E3%81%A7%E3%81%82%E3%82%8B%E3%80%82)
^ja-Q0069-answer

**ja-Q0070** — 実は、その出来事が新聞に載らなかったのは、たった一人の目撃者を除いては誰ひとりとしてそのことを知っている者はなかった――という極く簡単な事情に原因しているのである。

In truth, the very simple reason why this incident did not appear in the newspapers is that, outside of a single witness, no one knew about it.

Why: Subject and focus が. [[Japanese#^ja-Q0070|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%AE%9F%E3%81%AF%E3%80%81%E3%81%9D%E3%81%AE%E5%87%BA%E6%9D%A5%E4%BA%8B%E3%81%8C%E6%96%B0%E8%81%9E%E3%81%AB%E8%BC%89%E3%82%89%E3%81%AA%E3%81%8B%E3%81%A3%E3%81%9F%E3%81%AE%E3%81%AF%E3%80%81%E3%81%9F%E3%81%A3%E3%81%9F%E4%B8%80%E4%BA%BA%E3%81%AE%E7%9B%AE%E6%92%83%E8%80%85%E3%82%92%E9%99%A4%E3%81%84%E3%81%A6%E3%81%AF%E8%AA%B0%E3%81%B2%E3%81%A8%E3%82%8A%E3%81%A8%E3%81%97%E3%81%A6%E3%81%9D%E3%81%AE%E3%81%93%E3%81%A8%E3%82%92%E7%9F%A5%E3%81%A3%E3%81%A6%E3%81%84%E3%82%8B%E8%80%85%E3%81%AF%E3%81%AA%E3%81%8B%E3%81%A3%E3%81%9F%E2%80%95%E2%80%95%E3%81%A8%E3%81%84%E3%81%86%E6%A5%B5%E3%81%8F%E7%B0%A1%E5%8D%98%E3%81%AA%E4%BA%8B%E6%83%85%E3%81%AB%E5%8E%9F%E5%9B%A0%E3%81%97%E3%81%A6%E3%81%84%E3%82%8B%E3%81%AE%E3%81%A7%E3%81%82%E3%82%8B%E3%80%82)
^ja-Q0070-answer

**ja-Q0071** — トムのおばあちゃんがミニスカートをはくには歳を取り過ぎていると思う。

I think Tom's grandmother is too old to wear a miniskirt.

Why: Subject and focus が. [[Japanese#^ja-Q0071|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%83%88%E3%83%A0%E3%81%AE%E3%81%8A%E3%81%B0%E3%81%82%E3%81%A1%E3%82%83%E3%82%93%E3%81%8C%E3%83%9F%E3%83%8B%E3%82%B9%E3%82%AB%E3%83%BC%E3%83%88%E3%82%92%E3%81%AF%E3%81%8F%E3%81%AB%E3%81%AF%E6%AD%B3%E3%82%92%E5%8F%96%E3%82%8A%E9%81%8E%E3%81%8E%E3%81%A6%E3%81%84%E3%82%8B%E3%81%A8%E6%80%9D%E3%81%86%E3%80%82)
^ja-Q0071-answer

**ja-Q0072** — トムのおばあちゃんがミニスカートをはくには歳を取り過ぎていると思う。

I think Tom's grandmother is too old to wear a miniskirt.

が often marks a subject or focused identification. Certain predicates govern が for a participant English treats differently. It also links clauses with a contrasting meaning in another construction.

Why: Subject and focus が. [[Japanese#^ja-Q0072|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%83%88%E3%83%A0%E3%81%AE%E3%81%8A%E3%81%B0%E3%81%82%E3%81%A1%E3%82%83%E3%82%93%E3%81%8C%E3%83%9F%E3%83%8B%E3%82%B9%E3%82%AB%E3%83%BC%E3%83%88%E3%82%92%E3%81%AF%E3%81%8F%E3%81%AB%E3%81%AF%E6%AD%B3%E3%82%92%E5%8F%96%E3%82%8A%E9%81%8E%E3%81%8E%E3%81%A6%E3%81%84%E3%82%8B%E3%81%A8%E6%80%9D%E3%81%86%E3%80%82)
^ja-Q0072-answer

**ja-Q0073** — 土着のアメリカ・インディアンが政府から不当な扱いを受けたと主張するのは歴史的にみて当然の権利である。

American Indians have a fair historical right to claim they got a raw deal from the government.

Expected form: **が**

Why: Subject and focus が. [[Japanese#^ja-Q0073|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%9C%9F%E7%9D%80%E3%81%AE%E3%82%A2%E3%83%A1%E3%83%AA%E3%82%AB%E3%83%BB%E3%82%A4%E3%83%B3%E3%83%87%E3%82%A3%E3%82%A2%E3%83%B3%E3%81%8C%E6%94%BF%E5%BA%9C%E3%81%8B%E3%82%89%E4%B8%8D%E5%BD%93%E3%81%AA%E6%89%B1%E3%81%84%E3%82%92%E5%8F%97%E3%81%91%E3%81%9F%E3%81%A8%E4%B8%BB%E5%BC%B5%E3%81%99%E3%82%8B%E3%81%AE%E3%81%AF%E6%AD%B4%E5%8F%B2%E7%9A%84%E3%81%AB%E3%81%BF%E3%81%A6%E5%BD%93%E7%84%B6%E3%81%AE%E6%A8%A9%E5%88%A9%E3%81%A7%E3%81%82%E3%82%8B%E3%80%82)
^ja-Q0073-answer

**ja-Q0074** — 土着のアメリカ・インディアンが政府から不当な扱いを受けたと主張するのは歴史的にみて当然の権利である。

American Indians have a fair historical right to claim they got a raw deal from the government.

Expected form: **が**

Why: Subject and focus が. [[Japanese#^ja-Q0074|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%9C%9F%E7%9D%80%E3%81%AE%E3%82%A2%E3%83%A1%E3%83%AA%E3%82%AB%E3%83%BB%E3%82%A4%E3%83%B3%E3%83%87%E3%82%A3%E3%82%A2%E3%83%B3%E3%81%8C%E6%94%BF%E5%BA%9C%E3%81%8B%E3%82%89%E4%B8%8D%E5%BD%93%E3%81%AA%E6%89%B1%E3%81%84%E3%82%92%E5%8F%97%E3%81%91%E3%81%9F%E3%81%A8%E4%B8%BB%E5%BC%B5%E3%81%99%E3%82%8B%E3%81%AE%E3%81%AF%E6%AD%B4%E5%8F%B2%E7%9A%84%E3%81%AB%E3%81%BF%E3%81%A6%E5%BD%93%E7%84%B6%E3%81%AE%E6%A8%A9%E5%88%A9%E3%81%A7%E3%81%82%E3%82%8B%E3%80%82)
^ja-Q0074-answer

**ja-Q0075** — 赤ちゃんがミルクを欲しがって泣き出した。

My baby began crying, asking for milk.

Expected form: **が**

Why: Subject and focus が. [[Japanese#^ja-Q0075|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E8%B5%A4%E3%81%A1%E3%82%83%E3%82%93%E3%81%8C%E3%83%9F%E3%83%AB%E3%82%AF%E3%82%92%E6%AC%B2%E3%81%97%E3%81%8C%E3%81%A3%E3%81%A6%E6%B3%A3%E3%81%8D%E5%87%BA%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0075-answer

**ja-Q0076** — 赤ちゃんがミルクを欲しがって泣き出した。

My baby began crying, asking for milk.

Why: Subject and focus が. [[Japanese#^ja-Q0076|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E8%B5%A4%E3%81%A1%E3%82%83%E3%82%93%E3%81%8C%E3%83%9F%E3%83%AB%E3%82%AF%E3%82%92%E6%AC%B2%E3%81%97%E3%81%8C%E3%81%A3%E3%81%A6%E6%B3%A3%E3%81%8D%E5%87%BA%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0076-answer

**ja-Q0077** — 我々が手に手を取って一致団結すれば、きっとこの不況の時代も乗り切れるだろう。

If we hang tight, I'm sure we can make it through these bad times.

Why: Subject and focus が. [[Japanese#^ja-Q0077|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%88%91%E3%80%85%E3%81%8C%E6%89%8B%E3%81%AB%E6%89%8B%E3%82%92%E5%8F%96%E3%81%A3%E3%81%A6%E4%B8%80%E8%87%B4%E5%9B%A3%E7%B5%90%E3%81%99%E3%82%8C%E3%81%B0%E3%80%81%E3%81%8D%E3%81%A3%E3%81%A8%E3%81%93%E3%81%AE%E4%B8%8D%E6%B3%81%E3%81%AE%E6%99%82%E4%BB%A3%E3%82%82%E4%B9%97%E3%82%8A%E5%88%87%E3%82%8C%E3%82%8B%E3%81%A0%E3%82%8D%E3%81%86%E3%80%82)
^ja-Q0077-answer

**ja-Q0078** — 我々が手に手を取って一致団結すれば、きっとこの不況の時代も乗り切れるだろう。

If we hang tight, I'm sure we can make it through these bad times.

が often marks a subject or focused identification. Certain predicates govern が for a participant English treats differently. It also links clauses with a contrasting meaning in another construction.

Why: Subject and focus が. [[Japanese#^ja-Q0078|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%88%91%E3%80%85%E3%81%8C%E6%89%8B%E3%81%AB%E6%89%8B%E3%82%92%E5%8F%96%E3%81%A3%E3%81%A6%E4%B8%80%E8%87%B4%E5%9B%A3%E7%B5%90%E3%81%99%E3%82%8C%E3%81%B0%E3%80%81%E3%81%8D%E3%81%A3%E3%81%A8%E3%81%93%E3%81%AE%E4%B8%8D%E6%B3%81%E3%81%AE%E6%99%82%E4%BB%A3%E3%82%82%E4%B9%97%E3%82%8A%E5%88%87%E3%82%8C%E3%82%8B%E3%81%A0%E3%82%8D%E3%81%86%E3%80%82)
^ja-Q0078-answer

**ja-Q0079** — ひとりでその仕事をやりとげることができないから、彼は援助を求めて私をたよった。

Unable to accomplish the task by himself, he turned to me for help.

Expected form: **が**

Why: Subject and focus が. [[Japanese#^ja-Q0079|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%B2%E3%81%A8%E3%82%8A%E3%81%A7%E3%81%9D%E3%81%AE%E4%BB%95%E4%BA%8B%E3%82%92%E3%82%84%E3%82%8A%E3%81%A8%E3%81%92%E3%82%8B%E3%81%93%E3%81%A8%E3%81%8C%E3%81%A7%E3%81%8D%E3%81%AA%E3%81%84%E3%81%8B%E3%82%89%E3%80%81%E5%BD%BC%E3%81%AF%E6%8F%B4%E5%8A%A9%E3%82%92%E6%B1%82%E3%82%81%E3%81%A6%E7%A7%81%E3%82%92%E3%81%9F%E3%82%88%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0079-answer

**ja-Q0080** — ひとりでその仕事をやりとげることができないから、彼は援助を求めて私をたよった。

Unable to accomplish the task by himself, he turned to me for help.

Expected form: **が**

Why: Subject and focus が. [[Japanese#^ja-Q0080|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%B2%E3%81%A8%E3%82%8A%E3%81%A7%E3%81%9D%E3%81%AE%E4%BB%95%E4%BA%8B%E3%82%92%E3%82%84%E3%82%8A%E3%81%A8%E3%81%92%E3%82%8B%E3%81%93%E3%81%A8%E3%81%8C%E3%81%A7%E3%81%8D%E3%81%AA%E3%81%84%E3%81%8B%E3%82%89%E3%80%81%E5%BD%BC%E3%81%AF%E6%8F%B4%E5%8A%A9%E3%82%92%E6%B1%82%E3%82%81%E3%81%A6%E7%A7%81%E3%82%92%E3%81%9F%E3%82%88%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0080-answer

**ja-Q0081** — 今日では、パスポートには写真がなければならない。

Today, you must have a photograph in your passport.

Expected form: **が**

Why: Subject and focus が. [[Japanese#^ja-Q0081|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E4%BB%8A%E6%97%A5%E3%81%A7%E3%81%AF%E3%80%81%E3%83%91%E3%82%B9%E3%83%9D%E3%83%BC%E3%83%88%E3%81%AB%E3%81%AF%E5%86%99%E7%9C%9F%E3%81%8C%E3%81%AA%E3%81%91%E3%82%8C%E3%81%B0%E3%81%AA%E3%82%89%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0081-answer

**ja-Q0082** — 今日では、パスポートには写真がなければならない。

Today, you must have a photograph in your passport.

Why: Subject and focus が. [[Japanese#^ja-Q0082|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E4%BB%8A%E6%97%A5%E3%81%A7%E3%81%AF%E3%80%81%E3%83%91%E3%82%B9%E3%83%9D%E3%83%BC%E3%83%88%E3%81%AB%E3%81%AF%E5%86%99%E7%9C%9F%E3%81%8C%E3%81%AA%E3%81%91%E3%82%8C%E3%81%B0%E3%81%AA%E3%82%89%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0082-answer

**ja-Q0083** — 欠点があるにもかかわらず、だれもが彼を好きだ。

Despite all his faults, everybody likes him.

Why: Subject and focus が. [[Japanese#^ja-Q0083|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%AC%A0%E7%82%B9%E3%81%8C%E3%81%82%E3%82%8B%E3%81%AB%E3%82%82%E3%81%8B%E3%81%8B%E3%82%8F%E3%82%89%E3%81%9A%E3%80%81%E3%81%A0%E3%82%8C%E3%82%82%E3%81%8C%E5%BD%BC%E3%82%92%E5%A5%BD%E3%81%8D%E3%81%A0%E3%80%82)
^ja-Q0083-answer

**ja-Q0084** — 欠点があるにもかかわらず、だれもが彼を好きだ。

Despite all his faults, everybody likes him.

が often marks a subject or focused identification. Certain predicates govern が for a participant English treats differently. It also links clauses with a contrasting meaning in another construction.

Why: Subject and focus が. [[Japanese#^ja-Q0084|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%AC%A0%E7%82%B9%E3%81%8C%E3%81%82%E3%82%8B%E3%81%AB%E3%82%82%E3%81%8B%E3%81%8B%E3%82%8F%E3%82%89%E3%81%9A%E3%80%81%E3%81%A0%E3%82%8C%E3%82%82%E3%81%8C%E5%BD%BC%E3%82%92%E5%A5%BD%E3%81%8D%E3%81%A0%E3%80%82)
^ja-Q0084-answer

**ja-Q0085** — 世界中の多くの人が、食料不安を肌で感じています。

Many people around the world experience food insecurity.

Expected form: **が**

Why: Subject and focus が. [[Japanese#^ja-Q0085|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E4%B8%96%E7%95%8C%E4%B8%AD%E3%81%AE%E5%A4%9A%E3%81%8F%E3%81%AE%E4%BA%BA%E3%81%8C%E3%80%81%E9%A3%9F%E6%96%99%E4%B8%8D%E5%AE%89%E3%82%92%E8%82%8C%E3%81%A7%E6%84%9F%E3%81%98%E3%81%A6%E3%81%84%E3%81%BE%E3%81%99%E3%80%82)
^ja-Q0085-answer

**ja-Q0086** — 世界中の多くの人が、食料不安を肌で感じています。

Many people around the world experience food insecurity.

Expected form: **が**

Why: Subject and focus が. [[Japanese#^ja-Q0086|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E4%B8%96%E7%95%8C%E4%B8%AD%E3%81%AE%E5%A4%9A%E3%81%8F%E3%81%AE%E4%BA%BA%E3%81%8C%E3%80%81%E9%A3%9F%E6%96%99%E4%B8%8D%E5%AE%89%E3%82%92%E8%82%8C%E3%81%A7%E6%84%9F%E3%81%98%E3%81%A6%E3%81%84%E3%81%BE%E3%81%99%E3%80%82)
^ja-Q0086-answer

**ja-Q0087** — 英語は読めますが話せません。

I can read English, but I can't speak it.

Expected form: **が**

Why: Subject and focus が. [[Japanese#^ja-Q0087|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E8%8B%B1%E8%AA%9E%E3%81%AF%E8%AA%AD%E3%82%81%E3%81%BE%E3%81%99%E3%81%8C%E8%A9%B1%E3%81%9B%E3%81%BE%E3%81%9B%E3%82%93%E3%80%82)
^ja-Q0087-answer

**ja-Q0088** — 英語は読めますが話せません。

I can read English, but I can't speak it.

Why: Subject and focus が. [[Japanese#^ja-Q0088|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E8%8B%B1%E8%AA%9E%E3%81%AF%E8%AA%AD%E3%82%81%E3%81%BE%E3%81%99%E3%81%8C%E8%A9%B1%E3%81%9B%E3%81%BE%E3%81%9B%E3%82%93%E3%80%82)
^ja-Q0088-answer

**ja-Q0089** — 使っていた井戸が干上がったので、キャンプをしていた人は水に困ってしまった。

The campers were hard up for water because their well had run dry.

Why: Subject and focus が. [[Japanese#^ja-Q0089|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E4%BD%BF%E3%81%A3%E3%81%A6%E3%81%84%E3%81%9F%E4%BA%95%E6%88%B8%E3%81%8C%E5%B9%B2%E4%B8%8A%E3%81%8C%E3%81%A3%E3%81%9F%E3%81%AE%E3%81%A7%E3%80%81%E3%82%AD%E3%83%A3%E3%83%B3%E3%83%97%E3%82%92%E3%81%97%E3%81%A6%E3%81%84%E3%81%9F%E4%BA%BA%E3%81%AF%E6%B0%B4%E3%81%AB%E5%9B%B0%E3%81%A3%E3%81%A6%E3%81%97%E3%81%BE%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0089-answer

**ja-Q0090** — 使っていた井戸が干上がったので、キャンプをしていた人は水に困ってしまった。

The campers were hard up for water because their well had run dry.

が often marks a subject or focused identification. Certain predicates govern が for a participant English treats differently. It also links clauses with a contrasting meaning in another construction.

Why: Subject and focus が. [[Japanese#^ja-Q0090|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E4%BD%BF%E3%81%A3%E3%81%A6%E3%81%84%E3%81%9F%E4%BA%95%E6%88%B8%E3%81%8C%E5%B9%B2%E4%B8%8A%E3%81%8C%E3%81%A3%E3%81%9F%E3%81%AE%E3%81%A7%E3%80%81%E3%82%AD%E3%83%A3%E3%83%B3%E3%83%97%E3%82%92%E3%81%97%E3%81%A6%E3%81%84%E3%81%9F%E4%BA%BA%E3%81%AF%E6%B0%B4%E3%81%AB%E5%9B%B0%E3%81%A3%E3%81%A6%E3%81%97%E3%81%BE%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0090-answer

**ja-Q0091** — 仕様、価格は変更することがあります。

Specifications and price are subject to change.

Expected form: **が**

Why: Subject and focus が. [[Japanese#^ja-Q0091|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E4%BB%95%E6%A7%98%E3%80%81%E4%BE%A1%E6%A0%BC%E3%81%AF%E5%A4%89%E6%9B%B4%E3%81%99%E3%82%8B%E3%81%93%E3%81%A8%E3%81%8C%E3%81%82%E3%82%8A%E3%81%BE%E3%81%99%E3%80%82)
^ja-Q0091-answer

**ja-Q0092** — 仕様、価格は変更することがあります。

Specifications and price are subject to change.

Expected form: **が**

Why: Subject and focus が. [[Japanese#^ja-Q0092|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E4%BB%95%E6%A7%98%E3%80%81%E4%BE%A1%E6%A0%BC%E3%81%AF%E5%A4%89%E6%9B%B4%E3%81%99%E3%82%8B%E3%81%93%E3%81%A8%E3%81%8C%E3%81%82%E3%82%8A%E3%81%BE%E3%81%99%E3%80%82)
^ja-Q0092-answer

**ja-Q0093** — 君はどうして目が覚めたんだ？

What woke you up?

Expected form: **が**

Why: Subject and focus が. [[Japanese#^ja-Q0093|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%90%9B%E3%81%AF%E3%81%A9%E3%81%86%E3%81%97%E3%81%A6%E7%9B%AE%E3%81%8C%E8%A6%9A%E3%82%81%E3%81%9F%E3%82%93%E3%81%A0%EF%BC%9F)
^ja-Q0093-answer

**ja-Q0094** — 君はどうして目が覚めたんだ？

What woke you up?

Why: Subject and focus が. [[Japanese#^ja-Q0094|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%90%9B%E3%81%AF%E3%81%A9%E3%81%86%E3%81%97%E3%81%A6%E7%9B%AE%E3%81%8C%E8%A6%9A%E3%82%81%E3%81%9F%E3%82%93%E3%81%A0%EF%BC%9F)
^ja-Q0094-answer

**ja-Q0095** — どんなインプットでもいただければありがたいです。

Any input would be appreciated!

Why: Subject and focus が. [[Japanese#^ja-Q0095|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%A9%E3%82%93%E3%81%AA%E3%82%A4%E3%83%B3%E3%83%97%E3%83%83%E3%83%88%E3%81%A7%E3%82%82%E3%81%84%E3%81%9F%E3%81%A0%E3%81%91%E3%82%8C%E3%81%B0%E3%81%82%E3%82%8A%E3%81%8C%E3%81%9F%E3%81%84%E3%81%A7%E3%81%99%E3%80%82)
^ja-Q0095-answer

**ja-Q0096** — どんなインプットでもいただければありがたいです。

Any input would be appreciated!

が often marks a subject or focused identification. Certain predicates govern が for a participant English treats differently. It also links clauses with a contrasting meaning in another construction.

Why: Subject and focus が. [[Japanese#^ja-Q0096|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%A9%E3%82%93%E3%81%AA%E3%82%A4%E3%83%B3%E3%83%97%E3%83%83%E3%83%88%E3%81%A7%E3%82%82%E3%81%84%E3%81%9F%E3%81%A0%E3%81%91%E3%82%8C%E3%81%B0%E3%81%82%E3%82%8A%E3%81%8C%E3%81%9F%E3%81%84%E3%81%A7%E3%81%99%E3%80%82)
^ja-Q0096-answer

**ja-Q0097** — 落石が道路をふさいだ。

Fallen rocks closed the way.

Expected form: **が**

Why: Subject and focus が. [[Japanese#^ja-Q0097|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E8%90%BD%E7%9F%B3%E3%81%8C%E9%81%93%E8%B7%AF%E3%82%92%E3%81%B5%E3%81%95%E3%81%84%E3%81%A0%E3%80%82)
^ja-Q0097-answer

**ja-Q0098** — 落石が道路をふさいだ。

Fallen rocks closed the way.

Expected form: **が**

Why: Subject and focus が. [[Japanese#^ja-Q0098|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E8%90%BD%E7%9F%B3%E3%81%8C%E9%81%93%E8%B7%AF%E3%82%92%E3%81%B5%E3%81%95%E3%81%84%E3%81%A0%E3%80%82)
^ja-Q0098-answer

**ja-Q0099** — 私はしなければならない仕事がたくさんあります。

I have a lot of work to do.

Expected form: **が**

Why: Subject and focus が. [[Japanese#^ja-Q0099|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AF%E3%81%97%E3%81%AA%E3%81%91%E3%82%8C%E3%81%B0%E3%81%AA%E3%82%89%E3%81%AA%E3%81%84%E4%BB%95%E4%BA%8B%E3%81%8C%E3%81%9F%E3%81%8F%E3%81%95%E3%82%93%E3%81%82%E3%82%8A%E3%81%BE%E3%81%99%E3%80%82)
^ja-Q0099-answer

**ja-Q0100** — 私はしなければならない仕事がたくさんあります。

I have a lot of work to do.

Why: Subject and focus が. [[Japanese#^ja-Q0100|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AF%E3%81%97%E3%81%AA%E3%81%91%E3%82%8C%E3%81%B0%E3%81%AA%E3%82%89%E3%81%AA%E3%81%84%E4%BB%95%E4%BA%8B%E3%81%8C%E3%81%9F%E3%81%8F%E3%81%95%E3%82%93%E3%81%82%E3%82%8A%E3%81%BE%E3%81%99%E3%80%82)
^ja-Q0100-answer


### Answers 101–150

**ja-Q0101** — お留守中の猫の世話をして上げましょう。

While they are away, let's take care of their cat.

Why: Object を. [[Japanese#^ja-Q0101|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%8A%E7%95%99%E5%AE%88%E4%B8%AD%E3%81%AE%E7%8C%AB%E3%81%AE%E4%B8%96%E8%A9%B1%E3%82%92%E3%81%97%E3%81%A6%E4%B8%8A%E3%81%92%E3%81%BE%E3%81%97%E3%82%87%E3%81%86%E3%80%82)
^ja-Q0101-answer

**ja-Q0102** — お留守中の猫の世話をして上げましょう。

While they are away, let's take care of their cat.

を commonly marks a direct object and is pronounced o. It can also mark a route or place traversed. Identify the verb’s construction rather than applying one English object rule.

Why: Object を. [[Japanese#^ja-Q0102|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%8A%E7%95%99%E5%AE%88%E4%B8%AD%E3%81%AE%E7%8C%AB%E3%81%AE%E4%B8%96%E8%A9%B1%E3%82%92%E3%81%97%E3%81%A6%E4%B8%8A%E3%81%92%E3%81%BE%E3%81%97%E3%82%87%E3%81%86%E3%80%82)
^ja-Q0102-answer

**ja-Q0103** — もっと時間をかけて発表を準備すべきだったと先生に言われた。

My teacher told me that I should have spent more time preparing my presentation.

Expected form: **を**

Why: Object を. [[Japanese#^ja-Q0103|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%82%82%E3%81%A3%E3%81%A8%E6%99%82%E9%96%93%E3%82%92%E3%81%8B%E3%81%91%E3%81%A6%E7%99%BA%E8%A1%A8%E3%82%92%E6%BA%96%E5%82%99%E3%81%99%E3%81%B9%E3%81%8D%E3%81%A0%E3%81%A3%E3%81%9F%E3%81%A8%E5%85%88%E7%94%9F%E3%81%AB%E8%A8%80%E3%82%8F%E3%82%8C%E3%81%9F%E3%80%82)
^ja-Q0103-answer

**ja-Q0104** — もっと時間をかけて発表を準備すべきだったと先生に言われた。

My teacher told me that I should have spent more time preparing my presentation.

Expected form: **を**

Why: Object を. [[Japanese#^ja-Q0104|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%82%82%E3%81%A3%E3%81%A8%E6%99%82%E9%96%93%E3%82%92%E3%81%8B%E3%81%91%E3%81%A6%E7%99%BA%E8%A1%A8%E3%82%92%E6%BA%96%E5%82%99%E3%81%99%E3%81%B9%E3%81%8D%E3%81%A0%E3%81%A3%E3%81%9F%E3%81%A8%E5%85%88%E7%94%9F%E3%81%AB%E8%A8%80%E3%82%8F%E3%82%8C%E3%81%9F%E3%80%82)
^ja-Q0104-answer

**ja-Q0105** — ちょっと顔を貸してくれませんか。

Can I have a few words with you?

Expected form: **を**

Why: Object を. [[Japanese#^ja-Q0105|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%A1%E3%82%87%E3%81%A3%E3%81%A8%E9%A1%94%E3%82%92%E8%B2%B8%E3%81%97%E3%81%A6%E3%81%8F%E3%82%8C%E3%81%BE%E3%81%9B%E3%82%93%E3%81%8B%E3%80%82)
^ja-Q0105-answer

**ja-Q0106** — ちょっと顔を貸してくれませんか。

Can I have a few words with you?

Why: Object を. [[Japanese#^ja-Q0106|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%A1%E3%82%87%E3%81%A3%E3%81%A8%E9%A1%94%E3%82%92%E8%B2%B8%E3%81%97%E3%81%A6%E3%81%8F%E3%82%8C%E3%81%BE%E3%81%9B%E3%82%93%E3%81%8B%E3%80%82)
^ja-Q0106-answer

**ja-Q0107** — 私は時代に遅れないように、毎日新聞を読む。

I read a newspaper every day so that I may keep up with the time.

Why: Object を. [[Japanese#^ja-Q0107|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AF%E6%99%82%E4%BB%A3%E3%81%AB%E9%81%85%E3%82%8C%E3%81%AA%E3%81%84%E3%82%88%E3%81%86%E3%81%AB%E3%80%81%E6%AF%8E%E6%97%A5%E6%96%B0%E8%81%9E%E3%82%92%E8%AA%AD%E3%82%80%E3%80%82)
^ja-Q0107-answer

**ja-Q0108** — 私は時代に遅れないように、毎日新聞を読む。

I read a newspaper every day so that I may keep up with the time.

を commonly marks a direct object and is pronounced o. It can also mark a route or place traversed. Identify the verb’s construction rather than applying one English object rule.

Why: Object を. [[Japanese#^ja-Q0108|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AF%E6%99%82%E4%BB%A3%E3%81%AB%E9%81%85%E3%82%8C%E3%81%AA%E3%81%84%E3%82%88%E3%81%86%E3%81%AB%E3%80%81%E6%AF%8E%E6%97%A5%E6%96%B0%E8%81%9E%E3%82%92%E8%AA%AD%E3%82%80%E3%80%82)
^ja-Q0108-answer

**ja-Q0109** — 彼の演奏は目を見張るものであった。

His performance was amazing.

Expected form: **を**

Why: Object を. [[Japanese#^ja-Q0109|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%AE%E6%BC%94%E5%A5%8F%E3%81%AF%E7%9B%AE%E3%82%92%E8%A6%8B%E5%BC%B5%E3%82%8B%E3%82%82%E3%81%AE%E3%81%A7%E3%81%82%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0109-answer

**ja-Q0110** — 彼の演奏は目を見張るものであった。

His performance was amazing.

Expected form: **を**

Why: Object を. [[Japanese#^ja-Q0110|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%AE%E6%BC%94%E5%A5%8F%E3%81%AF%E7%9B%AE%E3%82%92%E8%A6%8B%E5%BC%B5%E3%82%8B%E3%82%82%E3%81%AE%E3%81%A7%E3%81%82%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0110-answer

**ja-Q0111** — 彼は新生活を始めた。

He started a new life.

Expected form: **を**

Why: Object を. [[Japanese#^ja-Q0111|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%AF%E6%96%B0%E7%94%9F%E6%B4%BB%E3%82%92%E5%A7%8B%E3%82%81%E3%81%9F%E3%80%82)
^ja-Q0111-answer

**ja-Q0112** — 彼は新生活を始めた。

He started a new life.

Why: Object を. [[Japanese#^ja-Q0112|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%AF%E6%96%B0%E7%94%9F%E6%B4%BB%E3%82%92%E5%A7%8B%E3%82%81%E3%81%9F%E3%80%82)
^ja-Q0112-answer

**ja-Q0113** — 三人は終身刑を科せられた。

Three were sentenced to life in prison.

Why: Object を. [[Japanese#^ja-Q0113|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E4%B8%89%E4%BA%BA%E3%81%AF%E7%B5%82%E8%BA%AB%E5%88%91%E3%82%92%E7%A7%91%E3%81%9B%E3%82%89%E3%82%8C%E3%81%9F%E3%80%82)
^ja-Q0113-answer

**ja-Q0114** — 三人は終身刑を科せられた。

Three were sentenced to life in prison.

を commonly marks a direct object and is pronounced o. It can also mark a route or place traversed. Identify the verb’s construction rather than applying one English object rule.

Why: Object を. [[Japanese#^ja-Q0114|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E4%B8%89%E4%BA%BA%E3%81%AF%E7%B5%82%E8%BA%AB%E5%88%91%E3%82%92%E7%A7%91%E3%81%9B%E3%82%89%E3%82%8C%E3%81%9F%E3%80%82)
^ja-Q0114-answer

**ja-Q0115** — 彼を見るとすぐに私には病気だとわかった。

The instant I saw him, I knew he was ill.

Expected form: **を**

Why: Object を. [[Japanese#^ja-Q0115|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%82%92%E8%A6%8B%E3%82%8B%E3%81%A8%E3%81%99%E3%81%90%E3%81%AB%E7%A7%81%E3%81%AB%E3%81%AF%E7%97%85%E6%B0%97%E3%81%A0%E3%81%A8%E3%82%8F%E3%81%8B%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0115-answer

**ja-Q0116** — 彼を見るとすぐに私には病気だとわかった。

The instant I saw him, I knew he was ill.

Expected form: **を**

Why: Object を. [[Japanese#^ja-Q0116|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%82%92%E8%A6%8B%E3%82%8B%E3%81%A8%E3%81%99%E3%81%90%E3%81%AB%E7%A7%81%E3%81%AB%E3%81%AF%E7%97%85%E6%B0%97%E3%81%A0%E3%81%A8%E3%82%8F%E3%81%8B%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0116-answer

**ja-Q0117** — あのＥメールを送るべきじゃなかった。

I shouldn't have sent that email.

Expected form: **を**

Why: Object を. [[Japanese#^ja-Q0117|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%82%E3%81%AE%EF%BC%A5%E3%83%A1%E3%83%BC%E3%83%AB%E3%82%92%E9%80%81%E3%82%8B%E3%81%B9%E3%81%8D%E3%81%98%E3%82%83%E3%81%AA%E3%81%8B%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0117-answer

**ja-Q0118** — あのＥメールを送るべきじゃなかった。

I shouldn't have sent that email.

Why: Object を. [[Japanese#^ja-Q0118|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%82%E3%81%AE%EF%BC%A5%E3%83%A1%E3%83%BC%E3%83%AB%E3%82%92%E9%80%81%E3%82%8B%E3%81%B9%E3%81%8D%E3%81%98%E3%82%83%E3%81%AA%E3%81%8B%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0118-answer

**ja-Q0119** — たとえ自信を持ってないにせよ少なくとも希望を持って。

If not confidently, at least hopefully.

Why: Object を. [[Japanese#^ja-Q0119|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%9F%E3%81%A8%E3%81%88%E8%87%AA%E4%BF%A1%E3%82%92%E6%8C%81%E3%81%A3%E3%81%A6%E3%81%AA%E3%81%84%E3%81%AB%E3%81%9B%E3%82%88%E5%B0%91%E3%81%AA%E3%81%8F%E3%81%A8%E3%82%82%E5%B8%8C%E6%9C%9B%E3%82%92%E6%8C%81%E3%81%A3%E3%81%A6%E3%80%82)
^ja-Q0119-answer

**ja-Q0120** — たとえ自信を持ってないにせよ少なくとも希望を持って。

If not confidently, at least hopefully.

を commonly marks a direct object and is pronounced o. It can also mark a route or place traversed. Identify the verb’s construction rather than applying one English object rule.

Why: Object を. [[Japanese#^ja-Q0120|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%9F%E3%81%A8%E3%81%88%E8%87%AA%E4%BF%A1%E3%82%92%E6%8C%81%E3%81%A3%E3%81%A6%E3%81%AA%E3%81%84%E3%81%AB%E3%81%9B%E3%82%88%E5%B0%91%E3%81%AA%E3%81%8F%E3%81%A8%E3%82%82%E5%B8%8C%E6%9C%9B%E3%82%92%E6%8C%81%E3%81%A3%E3%81%A6%E3%80%82)
^ja-Q0120-answer

**ja-Q0121** — 私はもうあの医者を信用しない。

I have lost faith in the doctor.

Expected form: **を**

Why: Object を. [[Japanese#^ja-Q0121|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AF%E3%82%82%E3%81%86%E3%81%82%E3%81%AE%E5%8C%BB%E8%80%85%E3%82%92%E4%BF%A1%E7%94%A8%E3%81%97%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0121-answer

**ja-Q0122** — 私はもうあの医者を信用しない。

I have lost faith in the doctor.

Expected form: **を**

Why: Object を. [[Japanese#^ja-Q0122|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AF%E3%82%82%E3%81%86%E3%81%82%E3%81%AE%E5%8C%BB%E8%80%85%E3%82%92%E4%BF%A1%E7%94%A8%E3%81%97%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0122-answer

**ja-Q0123** — アメリカは１７７６年に独立を宣言したと彼は言った。

He said that America declared its independence in 1776.

Expected form: **を**

Why: Object を. [[Japanese#^ja-Q0123|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%82%A2%E3%83%A1%E3%83%AA%E3%82%AB%E3%81%AF%EF%BC%91%EF%BC%97%EF%BC%97%EF%BC%96%E5%B9%B4%E3%81%AB%E7%8B%AC%E7%AB%8B%E3%82%92%E5%AE%A3%E8%A8%80%E3%81%97%E3%81%9F%E3%81%A8%E5%BD%BC%E3%81%AF%E8%A8%80%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0123-answer

**ja-Q0124** — アメリカは１７７６年に独立を宣言したと彼は言った。

He said that America declared its independence in 1776.

Why: Object を. [[Japanese#^ja-Q0124|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%82%A2%E3%83%A1%E3%83%AA%E3%82%AB%E3%81%AF%EF%BC%91%EF%BC%97%EF%BC%97%EF%BC%96%E5%B9%B4%E3%81%AB%E7%8B%AC%E7%AB%8B%E3%82%92%E5%AE%A3%E8%A8%80%E3%81%97%E3%81%9F%E3%81%A8%E5%BD%BC%E3%81%AF%E8%A8%80%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0124-answer

**ja-Q0125** — ２つのうちどちらかを選びなさい。

Choose either one or the other.

Why: Object を. [[Japanese#^ja-Q0125|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%EF%BC%92%E3%81%A4%E3%81%AE%E3%81%86%E3%81%A1%E3%81%A9%E3%81%A1%E3%82%89%E3%81%8B%E3%82%92%E9%81%B8%E3%81%B3%E3%81%AA%E3%81%95%E3%81%84%E3%80%82)
^ja-Q0125-answer

**ja-Q0126** — ２つのうちどちらかを選びなさい。

Choose either one or the other.

を commonly marks a direct object and is pronounced o. It can also mark a route or place traversed. Identify the verb’s construction rather than applying one English object rule.

Why: Object を. [[Japanese#^ja-Q0126|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%EF%BC%92%E3%81%A4%E3%81%AE%E3%81%86%E3%81%A1%E3%81%A9%E3%81%A1%E3%82%89%E3%81%8B%E3%82%92%E9%81%B8%E3%81%B3%E3%81%AA%E3%81%95%E3%81%84%E3%80%82)
^ja-Q0126-answer

**ja-Q0127** — デイリー・ニュースを買いました。

I bought a Daily News.

Expected form: **を**

Why: Object を. [[Japanese#^ja-Q0127|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%83%87%E3%82%A4%E3%83%AA%E3%83%BC%E3%83%BB%E3%83%8B%E3%83%A5%E3%83%BC%E3%82%B9%E3%82%92%E8%B2%B7%E3%81%84%E3%81%BE%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0127-answer

**ja-Q0128** — デイリー・ニュースを買いました。

I bought a Daily News.

Expected form: **を**

Why: Object を. [[Japanese#^ja-Q0128|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%83%87%E3%82%A4%E3%83%AA%E3%83%BC%E3%83%BB%E3%83%8B%E3%83%A5%E3%83%BC%E3%82%B9%E3%82%92%E8%B2%B7%E3%81%84%E3%81%BE%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0128-answer

**ja-Q0129** — 私たちはきわめて慎重に調査を行なった。

We conducted our investigation with the greatest care.

Expected form: **を**

Why: Object を. [[Japanese#^ja-Q0129|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%9F%E3%81%A1%E3%81%AF%E3%81%8D%E3%82%8F%E3%82%81%E3%81%A6%E6%85%8E%E9%87%8D%E3%81%AB%E8%AA%BF%E6%9F%BB%E3%82%92%E8%A1%8C%E3%81%AA%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0129-answer

**ja-Q0130** — 私たちはきわめて慎重に調査を行なった。

We conducted our investigation with the greatest care.

Why: Object を. [[Japanese#^ja-Q0130|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%9F%E3%81%A1%E3%81%AF%E3%81%8D%E3%82%8F%E3%82%81%E3%81%A6%E6%85%8E%E9%87%8D%E3%81%AB%E8%AA%BF%E6%9F%BB%E3%82%92%E8%A1%8C%E3%81%AA%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0130-answer

**ja-Q0131** — 私はカギを置いたところなんか知りませんか。

Any chance you know where I put my keys?

Why: Object を. [[Japanese#^ja-Q0131|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AF%E3%82%AB%E3%82%AE%E3%82%92%E7%BD%AE%E3%81%84%E3%81%9F%E3%81%A8%E3%81%93%E3%82%8D%E3%81%AA%E3%82%93%E3%81%8B%E7%9F%A5%E3%82%8A%E3%81%BE%E3%81%9B%E3%82%93%E3%81%8B%E3%80%82)
^ja-Q0131-answer

**ja-Q0132** — 私はカギを置いたところなんか知りませんか。

Any chance you know where I put my keys?

を commonly marks a direct object and is pronounced o. It can also mark a route or place traversed. Identify the verb’s construction rather than applying one English object rule.

Why: Object を. [[Japanese#^ja-Q0132|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AF%E3%82%AB%E3%82%AE%E3%82%92%E7%BD%AE%E3%81%84%E3%81%9F%E3%81%A8%E3%81%93%E3%82%8D%E3%81%AA%E3%82%93%E3%81%8B%E7%9F%A5%E3%82%8A%E3%81%BE%E3%81%9B%E3%82%93%E3%81%8B%E3%80%82)
^ja-Q0132-answer

**ja-Q0133** — その少年はわざと私の足を踏んだ。

The boy stepped on my foot on purpose.

Expected form: **を**

Why: Object を. [[Japanese#^ja-Q0133|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%9D%E3%81%AE%E5%B0%91%E5%B9%B4%E3%81%AF%E3%82%8F%E3%81%96%E3%81%A8%E7%A7%81%E3%81%AE%E8%B6%B3%E3%82%92%E8%B8%8F%E3%82%93%E3%81%A0%E3%80%82)
^ja-Q0133-answer

**ja-Q0134** — その少年はわざと私の足を踏んだ。

The boy stepped on my foot on purpose.

Expected form: **を**

Why: Object を. [[Japanese#^ja-Q0134|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%9D%E3%81%AE%E5%B0%91%E5%B9%B4%E3%81%AF%E3%82%8F%E3%81%96%E3%81%A8%E7%A7%81%E3%81%AE%E8%B6%B3%E3%82%92%E8%B8%8F%E3%82%93%E3%81%A0%E3%80%82)
^ja-Q0134-answer

**ja-Q0135** — 先生達は親たちとその問題を討議しあった。

The teachers debated the problem with the parents.

Expected form: **を**

Why: Object を. [[Japanese#^ja-Q0135|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%85%88%E7%94%9F%E9%81%94%E3%81%AF%E8%A6%AA%E3%81%9F%E3%81%A1%E3%81%A8%E3%81%9D%E3%81%AE%E5%95%8F%E9%A1%8C%E3%82%92%E8%A8%8E%E8%AD%B0%E3%81%97%E3%81%82%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0135-answer

**ja-Q0136** — 先生達は親たちとその問題を討議しあった。

The teachers debated the problem with the parents.

Why: Object を. [[Japanese#^ja-Q0136|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%85%88%E7%94%9F%E9%81%94%E3%81%AF%E8%A6%AA%E3%81%9F%E3%81%A1%E3%81%A8%E3%81%9D%E3%81%AE%E5%95%8F%E9%A1%8C%E3%82%92%E8%A8%8E%E8%AD%B0%E3%81%97%E3%81%82%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0136-answer

**ja-Q0137** — お塩を持ってきてもらえませんか。

Would you bring me some salt?

Why: Object を. [[Japanese#^ja-Q0137|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%8A%E5%A1%A9%E3%82%92%E6%8C%81%E3%81%A3%E3%81%A6%E3%81%8D%E3%81%A6%E3%82%82%E3%82%89%E3%81%88%E3%81%BE%E3%81%9B%E3%82%93%E3%81%8B%E3%80%82)
^ja-Q0137-answer

**ja-Q0138** — お塩を持ってきてもらえませんか。

Would you bring me some salt?

を commonly marks a direct object and is pronounced o. It can also mark a route or place traversed. Identify the verb’s construction rather than applying one English object rule.

Why: Object を. [[Japanese#^ja-Q0138|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%8A%E5%A1%A9%E3%82%92%E6%8C%81%E3%81%A3%E3%81%A6%E3%81%8D%E3%81%A6%E3%82%82%E3%82%89%E3%81%88%E3%81%BE%E3%81%9B%E3%82%93%E3%81%8B%E3%80%82)
^ja-Q0138-answer

**ja-Q0139** — 林さんには、言行を一致させる努力を求めたいと思います。

What I want from Mr Hayashi is the effort required for his actions to live up to his words.

Expected form: **を**

Why: Object を. [[Japanese#^ja-Q0139|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%9E%97%E3%81%95%E3%82%93%E3%81%AB%E3%81%AF%E3%80%81%E8%A8%80%E8%A1%8C%E3%82%92%E4%B8%80%E8%87%B4%E3%81%95%E3%81%9B%E3%82%8B%E5%8A%AA%E5%8A%9B%E3%82%92%E6%B1%82%E3%82%81%E3%81%9F%E3%81%84%E3%81%A8%E6%80%9D%E3%81%84%E3%81%BE%E3%81%99%E3%80%82)
^ja-Q0139-answer

**ja-Q0140** — 林さんには、言行を一致させる努力を求めたいと思います。

What I want from Mr Hayashi is the effort required for his actions to live up to his words.

Expected form: **を**

Why: Object を. [[Japanese#^ja-Q0140|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%9E%97%E3%81%95%E3%82%93%E3%81%AB%E3%81%AF%E3%80%81%E8%A8%80%E8%A1%8C%E3%82%92%E4%B8%80%E8%87%B4%E3%81%95%E3%81%9B%E3%82%8B%E5%8A%AA%E5%8A%9B%E3%82%92%E6%B1%82%E3%82%81%E3%81%9F%E3%81%84%E3%81%A8%E6%80%9D%E3%81%84%E3%81%BE%E3%81%99%E3%80%82)
^ja-Q0140-answer

**ja-Q0141** — 明日までには仕事をやり終えているでしょう。

I will be through with my work by tomorrow.

Expected form: **を**

Why: Object を. [[Japanese#^ja-Q0141|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%98%8E%E6%97%A5%E3%81%BE%E3%81%A7%E3%81%AB%E3%81%AF%E4%BB%95%E4%BA%8B%E3%82%92%E3%82%84%E3%82%8A%E7%B5%82%E3%81%88%E3%81%A6%E3%81%84%E3%82%8B%E3%81%A7%E3%81%97%E3%82%87%E3%81%86%E3%80%82)
^ja-Q0141-answer

**ja-Q0142** — 明日までには仕事をやり終えているでしょう。

I will be through with my work by tomorrow.

Why: Object を. [[Japanese#^ja-Q0142|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%98%8E%E6%97%A5%E3%81%BE%E3%81%A7%E3%81%AB%E3%81%AF%E4%BB%95%E4%BA%8B%E3%82%92%E3%82%84%E3%82%8A%E7%B5%82%E3%81%88%E3%81%A6%E3%81%84%E3%82%8B%E3%81%A7%E3%81%97%E3%82%87%E3%81%86%E3%80%82)
^ja-Q0142-answer

**ja-Q0143** — 私はポテトチップスを食べました。

I ate some potato chips.

Why: Object を. [[Japanese#^ja-Q0143|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AF%E3%83%9D%E3%83%86%E3%83%88%E3%83%81%E3%83%83%E3%83%97%E3%82%B9%E3%82%92%E9%A3%9F%E3%81%B9%E3%81%BE%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0143-answer

**ja-Q0144** — 私はポテトチップスを食べました。

I ate some potato chips.

を commonly marks a direct object and is pronounced o. It can also mark a route or place traversed. Identify the verb’s construction rather than applying one English object rule.

Why: Object を. [[Japanese#^ja-Q0144|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AF%E3%83%9D%E3%83%86%E3%83%88%E3%83%81%E3%83%83%E3%83%97%E3%82%B9%E3%82%92%E9%A3%9F%E3%81%B9%E3%81%BE%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0144-answer

**ja-Q0145** — 彼女はその教師を訪問した。

She visited the teacher.

Expected form: **を**

Why: Object を. [[Japanese#^ja-Q0145|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E5%A5%B3%E3%81%AF%E3%81%9D%E3%81%AE%E6%95%99%E5%B8%AB%E3%82%92%E8%A8%AA%E5%95%8F%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0145-answer

**ja-Q0146** — 彼女はその教師を訪問した。

She visited the teacher.

Expected form: **を**

Why: Object を. [[Japanese#^ja-Q0146|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E5%A5%B3%E3%81%AF%E3%81%9D%E3%81%AE%E6%95%99%E5%B8%AB%E3%82%92%E8%A8%AA%E5%95%8F%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0146-answer

**ja-Q0147** — 僕は会った瞬間彼女を好きになった。

I took to her the moment I met her.

Expected form: **を**

Why: Object を. [[Japanese#^ja-Q0147|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%83%95%E3%81%AF%E4%BC%9A%E3%81%A3%E3%81%9F%E7%9E%AC%E9%96%93%E5%BD%BC%E5%A5%B3%E3%82%92%E5%A5%BD%E3%81%8D%E3%81%AB%E3%81%AA%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0147-answer

**ja-Q0148** — 僕は会った瞬間彼女を好きになった。

I took to her the moment I met her.

Why: Object を. [[Japanese#^ja-Q0148|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%83%95%E3%81%AF%E4%BC%9A%E3%81%A3%E3%81%9F%E7%9E%AC%E9%96%93%E5%BD%BC%E5%A5%B3%E3%82%92%E5%A5%BD%E3%81%8D%E3%81%AB%E3%81%AA%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0148-answer

**ja-Q0149** — 赤ん坊は小さな手を差し出した。

The baby held out his tiny hand.

Why: Object を. [[Japanese#^ja-Q0149|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E8%B5%A4%E3%82%93%E5%9D%8A%E3%81%AF%E5%B0%8F%E3%81%95%E3%81%AA%E6%89%8B%E3%82%92%E5%B7%AE%E3%81%97%E5%87%BA%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0149-answer

**ja-Q0150** — 赤ん坊は小さな手を差し出した。

The baby held out his tiny hand.

を commonly marks a direct object and is pronounced o. It can also mark a route or place traversed. Identify the verb’s construction rather than applying one English object rule.

Why: Object を. [[Japanese#^ja-Q0150|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E8%B5%A4%E3%82%93%E5%9D%8A%E3%81%AF%E5%B0%8F%E3%81%95%E3%81%AA%E6%89%8B%E3%82%92%E5%B7%AE%E3%81%97%E5%87%BA%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0150-answer


### Answers 151–200

**ja-Q0151** — パーティーに行かない。

I'm not going to go to the party.

Expected form: **に**

Why: に relations. [[Japanese#^ja-Q0151|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%83%91%E3%83%BC%E3%83%86%E3%82%A3%E3%83%BC%E3%81%AB%E8%A1%8C%E3%81%8B%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0151-answer

**ja-Q0152** — パーティーに行かない。

I'm not going to go to the party.

Expected form: **に**

Why: に relations. [[Japanese#^ja-Q0152|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%83%91%E3%83%BC%E3%83%86%E3%82%A3%E3%83%BC%E3%81%AB%E8%A1%8C%E3%81%8B%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0152-answer

**ja-Q0153** — 明日買い物に行きます。

I'm going shopping tomorrow.

Expected form: **に**

Why: に relations. [[Japanese#^ja-Q0153|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%98%8E%E6%97%A5%E8%B2%B7%E3%81%84%E7%89%A9%E3%81%AB%E8%A1%8C%E3%81%8D%E3%81%BE%E3%81%99%E3%80%82)
^ja-Q0153-answer

**ja-Q0154** — 明日買い物に行きます。

I'm going shopping tomorrow.

Why: に relations. [[Japanese#^ja-Q0154|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%98%8E%E6%97%A5%E8%B2%B7%E3%81%84%E7%89%A9%E3%81%AB%E8%A1%8C%E3%81%8D%E3%81%BE%E3%81%99%E3%80%82)
^ja-Q0154-answer

**ja-Q0155** — 人からしてもらいたいように人にしてやれ。

Do to others as you would be done by.

Why: に relations. [[Japanese#^ja-Q0155|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E4%BA%BA%E3%81%8B%E3%82%89%E3%81%97%E3%81%A6%E3%82%82%E3%82%89%E3%81%84%E3%81%9F%E3%81%84%E3%82%88%E3%81%86%E3%81%AB%E4%BA%BA%E3%81%AB%E3%81%97%E3%81%A6%E3%82%84%E3%82%8C%E3%80%82)
^ja-Q0155-answer

**ja-Q0156** — 人からしてもらいたいように人にしてやれ。

Do to others as you would be done by.

に marks many destinations, recipients, time points and locations with existence predicates. It is also part of other grammatical constructions. Contrast event location with で.

Why: に relations. [[Japanese#^ja-Q0156|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E4%BA%BA%E3%81%8B%E3%82%89%E3%81%97%E3%81%A6%E3%82%82%E3%82%89%E3%81%84%E3%81%9F%E3%81%84%E3%82%88%E3%81%86%E3%81%AB%E4%BA%BA%E3%81%AB%E3%81%97%E3%81%A6%E3%82%84%E3%82%8C%E3%80%82)
^ja-Q0156-answer

**ja-Q0157** — 三日前、旧友にひょっこり会った。

I ran into an old friend three days ago.

Expected form: **に**

Why: に relations. [[Japanese#^ja-Q0157|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E4%B8%89%E6%97%A5%E5%89%8D%E3%80%81%E6%97%A7%E5%8F%8B%E3%81%AB%E3%81%B2%E3%82%87%E3%81%A3%E3%81%93%E3%82%8A%E4%BC%9A%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0157-answer

**ja-Q0158** — 三日前、旧友にひょっこり会った。

I ran into an old friend three days ago.

Expected form: **に**

Why: に relations. [[Japanese#^ja-Q0158|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E4%B8%89%E6%97%A5%E5%89%8D%E3%80%81%E6%97%A7%E5%8F%8B%E3%81%AB%E3%81%B2%E3%82%87%E3%81%A3%E3%81%93%E3%82%8A%E4%BC%9A%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0158-answer

**ja-Q0159** — あいつの家族はみんなアメリカに行ったんだけど、あいつはブラジルに残ったんだ。

All his family went to the United States, but he stayed in Brazil.

Expected form: **に**

Why: に relations. [[Japanese#^ja-Q0159|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%82%E3%81%84%E3%81%A4%E3%81%AE%E5%AE%B6%E6%97%8F%E3%81%AF%E3%81%BF%E3%82%93%E3%81%AA%E3%82%A2%E3%83%A1%E3%83%AA%E3%82%AB%E3%81%AB%E8%A1%8C%E3%81%A3%E3%81%9F%E3%82%93%E3%81%A0%E3%81%91%E3%81%A9%E3%80%81%E3%81%82%E3%81%84%E3%81%A4%E3%81%AF%E3%83%96%E3%83%A9%E3%82%B8%E3%83%AB%E3%81%AB%E6%AE%8B%E3%81%A3%E3%81%9F%E3%82%93%E3%81%A0%E3%80%82)
^ja-Q0159-answer

**ja-Q0160** — あいつの家族はみんなアメリカに行ったんだけど、あいつはブラジルに残ったんだ。

All his family went to the United States, but he stayed in Brazil.

Why: に relations. [[Japanese#^ja-Q0160|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%82%E3%81%84%E3%81%A4%E3%81%AE%E5%AE%B6%E6%97%8F%E3%81%AF%E3%81%BF%E3%82%93%E3%81%AA%E3%82%A2%E3%83%A1%E3%83%AA%E3%82%AB%E3%81%AB%E8%A1%8C%E3%81%A3%E3%81%9F%E3%82%93%E3%81%A0%E3%81%91%E3%81%A9%E3%80%81%E3%81%82%E3%81%84%E3%81%A4%E3%81%AF%E3%83%96%E3%83%A9%E3%82%B8%E3%83%AB%E3%81%AB%E6%AE%8B%E3%81%A3%E3%81%9F%E3%82%93%E3%81%A0%E3%80%82)
^ja-Q0160-answer

**ja-Q0161** — ３人の隣人はお互いに助け合った。

The three neighbours helped each other.

Why: に relations. [[Japanese#^ja-Q0161|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%EF%BC%93%E4%BA%BA%E3%81%AE%E9%9A%A3%E4%BA%BA%E3%81%AF%E3%81%8A%E4%BA%92%E3%81%84%E3%81%AB%E5%8A%A9%E3%81%91%E5%90%88%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0161-answer

**ja-Q0162** — ３人の隣人はお互いに助け合った。

The three neighbours helped each other.

に marks many destinations, recipients, time points and locations with existence predicates. It is also part of other grammatical constructions. Contrast event location with で.

Why: に relations. [[Japanese#^ja-Q0162|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%EF%BC%93%E4%BA%BA%E3%81%AE%E9%9A%A3%E4%BA%BA%E3%81%AF%E3%81%8A%E4%BA%92%E3%81%84%E3%81%AB%E5%8A%A9%E3%81%91%E5%90%88%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0162-answer

**ja-Q0163** — 夜ご飯にステーキはどうですか?

Would you like to have steak for dinner?

Expected form: **に**

Why: に relations. [[Japanese#^ja-Q0163|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%A4%9C%E3%81%94%E9%A3%AF%E3%81%AB%E3%82%B9%E3%83%86%E3%83%BC%E3%82%AD%E3%81%AF%E3%81%A9%E3%81%86%E3%81%A7%E3%81%99%E3%81%8B%3F)
^ja-Q0163-answer

**ja-Q0164** — 夜ご飯にステーキはどうですか?

Would you like to have steak for dinner?

Expected form: **に**

Why: に relations. [[Japanese#^ja-Q0164|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%A4%9C%E3%81%94%E9%A3%AF%E3%81%AB%E3%82%B9%E3%83%86%E3%83%BC%E3%82%AD%E3%81%AF%E3%81%A9%E3%81%86%E3%81%A7%E3%81%99%E3%81%8B%3F)
^ja-Q0164-answer

**ja-Q0165** — 私たちはその結果に十分満足しているわけではない。

We are not quite satisfied with the result.

Expected form: **に**

Why: に relations. [[Japanese#^ja-Q0165|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%9F%E3%81%A1%E3%81%AF%E3%81%9D%E3%81%AE%E7%B5%90%E6%9E%9C%E3%81%AB%E5%8D%81%E5%88%86%E6%BA%80%E8%B6%B3%E3%81%97%E3%81%A6%E3%81%84%E3%82%8B%E3%82%8F%E3%81%91%E3%81%A7%E3%81%AF%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0165-answer

**ja-Q0166** — 私たちはその結果に十分満足しているわけではない。

We are not quite satisfied with the result.

Why: に relations. [[Japanese#^ja-Q0166|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%9F%E3%81%A1%E3%81%AF%E3%81%9D%E3%81%AE%E7%B5%90%E6%9E%9C%E3%81%AB%E5%8D%81%E5%88%86%E6%BA%80%E8%B6%B3%E3%81%97%E3%81%A6%E3%81%84%E3%82%8B%E3%82%8F%E3%81%91%E3%81%A7%E3%81%AF%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0166-answer

**ja-Q0167** — その古い建物は取り壊されることになった。

It was decided that the old building be pulled down.

Why: に relations. [[Japanese#^ja-Q0167|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%9D%E3%81%AE%E5%8F%A4%E3%81%84%E5%BB%BA%E7%89%A9%E3%81%AF%E5%8F%96%E3%82%8A%E5%A3%8A%E3%81%95%E3%82%8C%E3%82%8B%E3%81%93%E3%81%A8%E3%81%AB%E3%81%AA%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0167-answer

**ja-Q0168** — その古い建物は取り壊されることになった。

It was decided that the old building be pulled down.

に marks many destinations, recipients, time points and locations with existence predicates. It is also part of other grammatical constructions. Contrast event location with で.

Why: に relations. [[Japanese#^ja-Q0168|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%9D%E3%81%AE%E5%8F%A4%E3%81%84%E5%BB%BA%E7%89%A9%E3%81%AF%E5%8F%96%E3%82%8A%E5%A3%8A%E3%81%95%E3%82%8C%E3%82%8B%E3%81%93%E3%81%A8%E3%81%AB%E3%81%AA%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0168-answer

**ja-Q0169** — 昨日ケンに会った。

I met Ken yesterday.

Expected form: **に**

Why: に relations. [[Japanese#^ja-Q0169|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%98%A8%E6%97%A5%E3%82%B1%E3%83%B3%E3%81%AB%E4%BC%9A%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0169-answer

**ja-Q0170** — 昨日ケンに会った。

I met Ken yesterday.

Expected form: **に**

Why: に relations. [[Japanese#^ja-Q0170|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%98%A8%E6%97%A5%E3%82%B1%E3%83%B3%E3%81%AB%E4%BC%9A%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0170-answer

**ja-Q0171** — 私達は年に一回集まります。

We get together once a year.

Expected form: **に**

Why: に relations. [[Japanese#^ja-Q0171|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E9%81%94%E3%81%AF%E5%B9%B4%E3%81%AB%E4%B8%80%E5%9B%9E%E9%9B%86%E3%81%BE%E3%82%8A%E3%81%BE%E3%81%99%E3%80%82)
^ja-Q0171-answer

**ja-Q0172** — 私達は年に一回集まります。

We get together once a year.

Why: に relations. [[Japanese#^ja-Q0172|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E9%81%94%E3%81%AF%E5%B9%B4%E3%81%AB%E4%B8%80%E5%9B%9E%E9%9B%86%E3%81%BE%E3%82%8A%E3%81%BE%E3%81%99%E3%80%82)
^ja-Q0172-answer

**ja-Q0173** — 彼は化学にハマってるんだよ。

He's really into chemistry.

Why: に relations. [[Japanese#^ja-Q0173|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%AF%E5%8C%96%E5%AD%A6%E3%81%AB%E3%83%8F%E3%83%9E%E3%81%A3%E3%81%A6%E3%82%8B%E3%82%93%E3%81%A0%E3%82%88%E3%80%82)
^ja-Q0173-answer

**ja-Q0174** — 彼は化学にハマってるんだよ。

He's really into chemistry.

に marks many destinations, recipients, time points and locations with existence predicates. It is also part of other grammatical constructions. Contrast event location with で.

Why: に relations. [[Japanese#^ja-Q0174|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%AF%E5%8C%96%E5%AD%A6%E3%81%AB%E3%83%8F%E3%83%9E%E3%81%A3%E3%81%A6%E3%82%8B%E3%82%93%E3%81%A0%E3%82%88%E3%80%82)
^ja-Q0174-answer

**ja-Q0175** — すぐ出発しなさい。そうすれば彼に追いつきますよ。

Start at once, and you will catch up with him.

Expected form: **に**

Why: に relations. [[Japanese#^ja-Q0175|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%99%E3%81%90%E5%87%BA%E7%99%BA%E3%81%97%E3%81%AA%E3%81%95%E3%81%84%E3%80%82%E3%81%9D%E3%81%86%E3%81%99%E3%82%8C%E3%81%B0%E5%BD%BC%E3%81%AB%E8%BF%BD%E3%81%84%E3%81%A4%E3%81%8D%E3%81%BE%E3%81%99%E3%82%88%E3%80%82)
^ja-Q0175-answer

**ja-Q0176** — すぐ出発しなさい。そうすれば彼に追いつきますよ。

Start at once, and you will catch up with him.

Expected form: **に**

Why: に relations. [[Japanese#^ja-Q0176|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%99%E3%81%90%E5%87%BA%E7%99%BA%E3%81%97%E3%81%AA%E3%81%95%E3%81%84%E3%80%82%E3%81%9D%E3%81%86%E3%81%99%E3%82%8C%E3%81%B0%E5%BD%BC%E3%81%AB%E8%BF%BD%E3%81%84%E3%81%A4%E3%81%8D%E3%81%BE%E3%81%99%E3%82%88%E3%80%82)
^ja-Q0176-answer

**ja-Q0177** — 危険などにひるまず、彼は平気でいる。

He remains calm in the face of danger.

Expected form: **に**

Why: に relations. [[Japanese#^ja-Q0177|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%8D%B1%E9%99%BA%E3%81%AA%E3%81%A9%E3%81%AB%E3%81%B2%E3%82%8B%E3%81%BE%E3%81%9A%E3%80%81%E5%BD%BC%E3%81%AF%E5%B9%B3%E6%B0%97%E3%81%A7%E3%81%84%E3%82%8B%E3%80%82)
^ja-Q0177-answer

**ja-Q0178** — 危険などにひるまず、彼は平気でいる。

He remains calm in the face of danger.

Why: に relations. [[Japanese#^ja-Q0178|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%8D%B1%E9%99%BA%E3%81%AA%E3%81%A9%E3%81%AB%E3%81%B2%E3%82%8B%E3%81%BE%E3%81%9A%E3%80%81%E5%BD%BC%E3%81%AF%E5%B9%B3%E6%B0%97%E3%81%A7%E3%81%84%E3%82%8B%E3%80%82)
^ja-Q0178-answer

**ja-Q0179** — 太陽は厚い雲におおわれた。

The sun was hidden by thick clouds.

Why: に relations. [[Japanese#^ja-Q0179|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%A4%AA%E9%99%BD%E3%81%AF%E5%8E%9A%E3%81%84%E9%9B%B2%E3%81%AB%E3%81%8A%E3%81%8A%E3%82%8F%E3%82%8C%E3%81%9F%E3%80%82)
^ja-Q0179-answer

**ja-Q0180** — 太陽は厚い雲におおわれた。

The sun was hidden by thick clouds.

に marks many destinations, recipients, time points and locations with existence predicates. It is also part of other grammatical constructions. Contrast event location with で.

Why: に relations. [[Japanese#^ja-Q0180|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%A4%AA%E9%99%BD%E3%81%AF%E5%8E%9A%E3%81%84%E9%9B%B2%E3%81%AB%E3%81%8A%E3%81%8A%E3%82%8F%E3%82%8C%E3%81%9F%E3%80%82)
^ja-Q0180-answer

**ja-Q0181** — 私達は時勢に通じていなければならない。

We must keep in touch with the times.

Expected form: **に**

Why: に relations. [[Japanese#^ja-Q0181|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E9%81%94%E3%81%AF%E6%99%82%E5%8B%A2%E3%81%AB%E9%80%9A%E3%81%98%E3%81%A6%E3%81%84%E3%81%AA%E3%81%91%E3%82%8C%E3%81%B0%E3%81%AA%E3%82%89%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0181-answer

**ja-Q0182** — 私達は時勢に通じていなければならない。

We must keep in touch with the times.

Expected form: **に**

Why: に relations. [[Japanese#^ja-Q0182|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E9%81%94%E3%81%AF%E6%99%82%E5%8B%A2%E3%81%AB%E9%80%9A%E3%81%98%E3%81%A6%E3%81%84%E3%81%AA%E3%81%91%E3%82%8C%E3%81%B0%E3%81%AA%E3%82%89%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0182-answer

**ja-Q0183** — もっと一所懸命勉強しなきゃいけないよ、ってトムに話した。

I told Tom he should study harder.

Expected form: **に**

Why: に relations. [[Japanese#^ja-Q0183|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%82%82%E3%81%A3%E3%81%A8%E4%B8%80%E6%89%80%E6%87%B8%E5%91%BD%E5%8B%89%E5%BC%B7%E3%81%97%E3%81%AA%E3%81%8D%E3%82%83%E3%81%84%E3%81%91%E3%81%AA%E3%81%84%E3%82%88%E3%80%81%E3%81%A3%E3%81%A6%E3%83%88%E3%83%A0%E3%81%AB%E8%A9%B1%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0183-answer

**ja-Q0184** — もっと一所懸命勉強しなきゃいけないよ、ってトムに話した。

I told Tom he should study harder.

Why: に relations. [[Japanese#^ja-Q0184|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%82%82%E3%81%A3%E3%81%A8%E4%B8%80%E6%89%80%E6%87%B8%E5%91%BD%E5%8B%89%E5%BC%B7%E3%81%97%E3%81%AA%E3%81%8D%E3%82%83%E3%81%84%E3%81%91%E3%81%AA%E3%81%84%E3%82%88%E3%80%81%E3%81%A3%E3%81%A6%E3%83%88%E3%83%A0%E3%81%AB%E8%A9%B1%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0184-answer

**ja-Q0185** — トムは3年前に初めてメアリーに会った。

Tom met Mary for the first time three years ago.

Why: に relations. [[Japanese#^ja-Q0185|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%83%88%E3%83%A0%E3%81%AF3%E5%B9%B4%E5%89%8D%E3%81%AB%E5%88%9D%E3%82%81%E3%81%A6%E3%83%A1%E3%82%A2%E3%83%AA%E3%83%BC%E3%81%AB%E4%BC%9A%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0185-answer

**ja-Q0186** — トムは3年前に初めてメアリーに会った。

Tom met Mary for the first time three years ago.

に marks many destinations, recipients, time points and locations with existence predicates. It is also part of other grammatical constructions. Contrast event location with で.

Why: に relations. [[Japanese#^ja-Q0186|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%83%88%E3%83%A0%E3%81%AF3%E5%B9%B4%E5%89%8D%E3%81%AB%E5%88%9D%E3%82%81%E3%81%A6%E3%83%A1%E3%82%A2%E3%83%AA%E3%83%BC%E3%81%AB%E4%BC%9A%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0186-answer

**ja-Q0187** — 私はエイズの研究に従事している。

I am engaged in AIDS research.

Expected form: **に**

Why: に relations. [[Japanese#^ja-Q0187|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AF%E3%82%A8%E3%82%A4%E3%82%BA%E3%81%AE%E7%A0%94%E7%A9%B6%E3%81%AB%E5%BE%93%E4%BA%8B%E3%81%97%E3%81%A6%E3%81%84%E3%82%8B%E3%80%82)
^ja-Q0187-answer

**ja-Q0188** — 私はエイズの研究に従事している。

I am engaged in AIDS research.

Expected form: **に**

Why: に relations. [[Japanese#^ja-Q0188|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AF%E3%82%A8%E3%82%A4%E3%82%BA%E3%81%AE%E7%A0%94%E7%A9%B6%E3%81%AB%E5%BE%93%E4%BA%8B%E3%81%97%E3%81%A6%E3%81%84%E3%82%8B%E3%80%82)
^ja-Q0188-answer

**ja-Q0189** — この理論はとてもむずかしいので私には理解できない。

This theory is too difficult for me to comprehend.

Expected form: **に**

Why: に relations. [[Japanese#^ja-Q0189|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%93%E3%81%AE%E7%90%86%E8%AB%96%E3%81%AF%E3%81%A8%E3%81%A6%E3%82%82%E3%82%80%E3%81%9A%E3%81%8B%E3%81%97%E3%81%84%E3%81%AE%E3%81%A7%E7%A7%81%E3%81%AB%E3%81%AF%E7%90%86%E8%A7%A3%E3%81%A7%E3%81%8D%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0189-answer

**ja-Q0190** — この理論はとてもむずかしいので私には理解できない。

This theory is too difficult for me to comprehend.

Why: に relations. [[Japanese#^ja-Q0190|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%93%E3%81%AE%E7%90%86%E8%AB%96%E3%81%AF%E3%81%A8%E3%81%A6%E3%82%82%E3%82%80%E3%81%9A%E3%81%8B%E3%81%97%E3%81%84%E3%81%AE%E3%81%A7%E7%A7%81%E3%81%AB%E3%81%AF%E7%90%86%E8%A7%A3%E3%81%A7%E3%81%8D%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0190-answer

**ja-Q0191** — 僕は彼女と一緒に歩いている。

I'm walking beside her.

Why: に relations. [[Japanese#^ja-Q0191|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%83%95%E3%81%AF%E5%BD%BC%E5%A5%B3%E3%81%A8%E4%B8%80%E7%B7%92%E3%81%AB%E6%AD%A9%E3%81%84%E3%81%A6%E3%81%84%E3%82%8B%E3%80%82)
^ja-Q0191-answer

**ja-Q0192** — 僕は彼女と一緒に歩いている。

I'm walking beside her.

に marks many destinations, recipients, time points and locations with existence predicates. It is also part of other grammatical constructions. Contrast event location with で.

Why: に relations. [[Japanese#^ja-Q0192|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%83%95%E3%81%AF%E5%BD%BC%E5%A5%B3%E3%81%A8%E4%B8%80%E7%B7%92%E3%81%AB%E6%AD%A9%E3%81%84%E3%81%A6%E3%81%84%E3%82%8B%E3%80%82)
^ja-Q0192-answer

**ja-Q0193** — 彼は彼の現状に満足している。

He is content with his present state.

Expected form: **に**

Why: に relations. [[Japanese#^ja-Q0193|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%AF%E5%BD%BC%E3%81%AE%E7%8F%BE%E7%8A%B6%E3%81%AB%E6%BA%80%E8%B6%B3%E3%81%97%E3%81%A6%E3%81%84%E3%82%8B%E3%80%82)
^ja-Q0193-answer

**ja-Q0194** — 彼は彼の現状に満足している。

He is content with his present state.

Expected form: **に**

Why: に relations. [[Japanese#^ja-Q0194|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%AF%E5%BD%BC%E3%81%AE%E7%8F%BE%E7%8A%B6%E3%81%AB%E6%BA%80%E8%B6%B3%E3%81%97%E3%81%A6%E3%81%84%E3%82%8B%E3%80%82)
^ja-Q0194-answer

**ja-Q0195** — 彼らは毎週日曜日に礼拝に行く。

They worship every Sunday.

Expected form: **に**

Why: に relations. [[Japanese#^ja-Q0195|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%82%89%E3%81%AF%E6%AF%8E%E9%80%B1%E6%97%A5%E6%9B%9C%E6%97%A5%E3%81%AB%E7%A4%BC%E6%8B%9D%E3%81%AB%E8%A1%8C%E3%81%8F%E3%80%82)
^ja-Q0195-answer

**ja-Q0196** — 彼らは毎週日曜日に礼拝に行く。

They worship every Sunday.

Why: に relations. [[Japanese#^ja-Q0196|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%82%89%E3%81%AF%E6%AF%8E%E9%80%B1%E6%97%A5%E6%9B%9C%E6%97%A5%E3%81%AB%E7%A4%BC%E6%8B%9D%E3%81%AB%E8%A1%8C%E3%81%8F%E3%80%82)
^ja-Q0196-answer

**ja-Q0197** — 「今何時？」「2時半」「まじか。今日は早く寝るつもりだったのに」

"What time is it?" "2:30." "Really? I wanted to go to sleep early today, too."

Why: に relations. [[Japanese#^ja-Q0197|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%80%8C%E4%BB%8A%E4%BD%95%E6%99%82%EF%BC%9F%E3%80%8D%E3%80%8C2%E6%99%82%E5%8D%8A%E3%80%8D%E3%80%8C%E3%81%BE%E3%81%98%E3%81%8B%E3%80%82%E4%BB%8A%E6%97%A5%E3%81%AF%E6%97%A9%E3%81%8F%E5%AF%9D%E3%82%8B%E3%81%A4%E3%82%82%E3%82%8A%E3%81%A0%E3%81%A3%E3%81%9F%E3%81%AE%E3%81%AB%E3%80%8D)
^ja-Q0197-answer

**ja-Q0198** — 「今何時？」「2時半」「まじか。今日は早く寝るつもりだったのに」

"What time is it?" "2:30." "Really? I wanted to go to sleep early today, too."

に marks many destinations, recipients, time points and locations with existence predicates. It is also part of other grammatical constructions. Contrast event location with で.

Why: に relations. [[Japanese#^ja-Q0198|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%80%8C%E4%BB%8A%E4%BD%95%E6%99%82%EF%BC%9F%E3%80%8D%E3%80%8C2%E6%99%82%E5%8D%8A%E3%80%8D%E3%80%8C%E3%81%BE%E3%81%98%E3%81%8B%E3%80%82%E4%BB%8A%E6%97%A5%E3%81%AF%E6%97%A9%E3%81%8F%E5%AF%9D%E3%82%8B%E3%81%A4%E3%82%82%E3%82%8A%E3%81%A0%E3%81%A3%E3%81%9F%E3%81%AE%E3%81%AB%E3%80%8D)
^ja-Q0198-answer

**ja-Q0199** — 彼はその物音にぎょっとなった。

He started at the noise.

Expected form: **に**

Why: に relations. [[Japanese#^ja-Q0199|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%AF%E3%81%9D%E3%81%AE%E7%89%A9%E9%9F%B3%E3%81%AB%E3%81%8E%E3%82%87%E3%81%A3%E3%81%A8%E3%81%AA%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0199-answer

**ja-Q0200** — 彼はその物音にぎょっとなった。

He started at the noise.

Expected form: **に**

Why: に relations. [[Japanese#^ja-Q0200|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%AF%E3%81%9D%E3%81%AE%E7%89%A9%E9%9F%B3%E3%81%AB%E3%81%8E%E3%82%87%E3%81%A3%E3%81%A8%E3%81%AA%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0200-answer


### Answers 201–250

**ja-Q0201** — 彼は本当のところ支配人ではない。

He is actually not the manager.

Expected form: **で**

Why: で relations. [[Japanese#^ja-Q0201|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%AF%E6%9C%AC%E5%BD%93%E3%81%AE%E3%81%A8%E3%81%93%E3%82%8D%E6%94%AF%E9%85%8D%E4%BA%BA%E3%81%A7%E3%81%AF%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0201-answer

**ja-Q0202** — 彼は本当のところ支配人ではない。

He is actually not the manager.

Why: で relations. [[Japanese#^ja-Q0202|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%AF%E6%9C%AC%E5%BD%93%E3%81%AE%E3%81%A8%E3%81%93%E3%82%8D%E6%94%AF%E9%85%8D%E4%BA%BA%E3%81%A7%E3%81%AF%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0202-answer

**ja-Q0203** — トムね、自分で髪切ったのよ。

Tom cut his own hair.

Why: で relations. [[Japanese#^ja-Q0203|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%83%88%E3%83%A0%E3%81%AD%E3%80%81%E8%87%AA%E5%88%86%E3%81%A7%E9%AB%AA%E5%88%87%E3%81%A3%E3%81%9F%E3%81%AE%E3%82%88%E3%80%82)
^ja-Q0203-answer

**ja-Q0204** — トムね、自分で髪切ったのよ。

Tom cut his own hair.

で often marks event location, means or material. Compare 学校にいる, be at school, with 学校で勉強する, study at school. It can also link a noun/adjectival predicate.

Why: で relations. [[Japanese#^ja-Q0204|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%83%88%E3%83%A0%E3%81%AD%E3%80%81%E8%87%AA%E5%88%86%E3%81%A7%E9%AB%AA%E5%88%87%E3%81%A3%E3%81%9F%E3%81%AE%E3%82%88%E3%80%82)
^ja-Q0204-answer

**ja-Q0205** — ボクシングやホッケーのようなスポーツは好きではない。

I don't like such sports as boxing and hockey.

Expected form: **で**

Why: で relations. [[Japanese#^ja-Q0205|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%83%9C%E3%82%AF%E3%82%B7%E3%83%B3%E3%82%B0%E3%82%84%E3%83%9B%E3%83%83%E3%82%B1%E3%83%BC%E3%81%AE%E3%82%88%E3%81%86%E3%81%AA%E3%82%B9%E3%83%9D%E3%83%BC%E3%83%84%E3%81%AF%E5%A5%BD%E3%81%8D%E3%81%A7%E3%81%AF%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0205-answer

**ja-Q0206** — ボクシングやホッケーのようなスポーツは好きではない。

I don't like such sports as boxing and hockey.

Expected form: **で**

Why: で relations. [[Japanese#^ja-Q0206|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%83%9C%E3%82%AF%E3%82%B7%E3%83%B3%E3%82%B0%E3%82%84%E3%83%9B%E3%83%83%E3%82%B1%E3%83%BC%E3%81%AE%E3%82%88%E3%81%86%E3%81%AA%E3%82%B9%E3%83%9D%E3%83%BC%E3%83%84%E3%81%AF%E5%A5%BD%E3%81%8D%E3%81%A7%E3%81%AF%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0206-answer

**ja-Q0207** — 中東は文明の発祥地である。

The Middle East is the cradle of civilization.

Expected form: **で**

Why: で relations. [[Japanese#^ja-Q0207|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E4%B8%AD%E6%9D%B1%E3%81%AF%E6%96%87%E6%98%8E%E3%81%AE%E7%99%BA%E7%A5%A5%E5%9C%B0%E3%81%A7%E3%81%82%E3%82%8B%E3%80%82)
^ja-Q0207-answer

**ja-Q0208** — 中東は文明の発祥地である。

The Middle East is the cradle of civilization.

Why: で relations. [[Japanese#^ja-Q0208|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E4%B8%AD%E6%9D%B1%E3%81%AF%E6%96%87%E6%98%8E%E3%81%AE%E7%99%BA%E7%A5%A5%E5%9C%B0%E3%81%A7%E3%81%82%E3%82%8B%E3%80%82)
^ja-Q0208-answer

**ja-Q0209** — 小さなことでくよくよするな。

Don't trouble about small things.

Why: で relations. [[Japanese#^ja-Q0209|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%B0%8F%E3%81%95%E3%81%AA%E3%81%93%E3%81%A8%E3%81%A7%E3%81%8F%E3%82%88%E3%81%8F%E3%82%88%E3%81%99%E3%82%8B%E3%81%AA%E3%80%82)
^ja-Q0209-answer

**ja-Q0210** — 小さなことでくよくよするな。

Don't trouble about small things.

で often marks event location, means or material. Compare 学校にいる, be at school, with 学校で勉強する, study at school. It can also link a noun/adjectival predicate.

Why: で relations. [[Japanese#^ja-Q0210|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%B0%8F%E3%81%95%E3%81%AA%E3%81%93%E3%81%A8%E3%81%A7%E3%81%8F%E3%82%88%E3%81%8F%E3%82%88%E3%81%99%E3%82%8B%E3%81%AA%E3%80%82)
^ja-Q0210-answer

**ja-Q0211** — 彼女はフランスで一番のテニス選手だと言われている。

It is said that she is the best tennis player in France.

Expected form: **で**

Why: で relations. [[Japanese#^ja-Q0211|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E5%A5%B3%E3%81%AF%E3%83%95%E3%83%A9%E3%83%B3%E3%82%B9%E3%81%A7%E4%B8%80%E7%95%AA%E3%81%AE%E3%83%86%E3%83%8B%E3%82%B9%E9%81%B8%E6%89%8B%E3%81%A0%E3%81%A8%E8%A8%80%E3%82%8F%E3%82%8C%E3%81%A6%E3%81%84%E3%82%8B%E3%80%82)
^ja-Q0211-answer

**ja-Q0212** — 彼女はフランスで一番のテニス選手だと言われている。

It is said that she is the best tennis player in France.

Expected form: **で**

Why: で relations. [[Japanese#^ja-Q0212|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E5%A5%B3%E3%81%AF%E3%83%95%E3%83%A9%E3%83%B3%E3%82%B9%E3%81%A7%E4%B8%80%E7%95%AA%E3%81%AE%E3%83%86%E3%83%8B%E3%82%B9%E9%81%B8%E6%89%8B%E3%81%A0%E3%81%A8%E8%A8%80%E3%82%8F%E3%82%8C%E3%81%A6%E3%81%84%E3%82%8B%E3%80%82)
^ja-Q0212-answer

**ja-Q0213** — なんでこんなに早く来たの？

Why did you come so early?

Expected form: **で**

Why: で relations. [[Japanese#^ja-Q0213|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%AA%E3%82%93%E3%81%A7%E3%81%93%E3%82%93%E3%81%AA%E3%81%AB%E6%97%A9%E3%81%8F%E6%9D%A5%E3%81%9F%E3%81%AE%EF%BC%9F)
^ja-Q0213-answer

**ja-Q0214** — なんでこんなに早く来たの？

Why did you come so early?

Why: で relations. [[Japanese#^ja-Q0214|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%AA%E3%82%93%E3%81%A7%E3%81%93%E3%82%93%E3%81%AA%E3%81%AB%E6%97%A9%E3%81%8F%E6%9D%A5%E3%81%9F%E3%81%AE%EF%BC%9F)
^ja-Q0214-answer

**ja-Q0215** — 私たちは毎日学校で英語を勉強する。

We study English at school every day.

Why: で relations. [[Japanese#^ja-Q0215|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%9F%E3%81%A1%E3%81%AF%E6%AF%8E%E6%97%A5%E5%AD%A6%E6%A0%A1%E3%81%A7%E8%8B%B1%E8%AA%9E%E3%82%92%E5%8B%89%E5%BC%B7%E3%81%99%E3%82%8B%E3%80%82)
^ja-Q0215-answer

**ja-Q0216** — 私たちは毎日学校で英語を勉強する。

We study English at school every day.

で often marks event location, means or material. Compare 学校にいる, be at school, with 学校で勉強する, study at school. It can also link a noun/adjectival predicate.

Why: で relations. [[Japanese#^ja-Q0216|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%9F%E3%81%A1%E3%81%AF%E6%AF%8E%E6%97%A5%E5%AD%A6%E6%A0%A1%E3%81%A7%E8%8B%B1%E8%AA%9E%E3%82%92%E5%8B%89%E5%BC%B7%E3%81%99%E3%82%8B%E3%80%82)
^ja-Q0216-answer

**ja-Q0217** — 船は嵐で左右に揺れた。

The ship rolled from side to side in the storm.

Expected form: **で**

Why: で relations. [[Japanese#^ja-Q0217|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E8%88%B9%E3%81%AF%E5%B5%90%E3%81%A7%E5%B7%A6%E5%8F%B3%E3%81%AB%E6%8F%BA%E3%82%8C%E3%81%9F%E3%80%82)
^ja-Q0217-answer

**ja-Q0218** — 船は嵐で左右に揺れた。

The ship rolled from side to side in the storm.

Expected form: **で**

Why: で relations. [[Japanese#^ja-Q0218|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E8%88%B9%E3%81%AF%E5%B5%90%E3%81%A7%E5%B7%A6%E5%8F%B3%E3%81%AB%E6%8F%BA%E3%82%8C%E3%81%9F%E3%80%82)
^ja-Q0218-answer

**ja-Q0219** — 私は貴乃花が急いで体育館を出てくる時、彼をちらっと見た。

I got a quick glimpse of Takanohana as he hurriedly left the gymnasium.

Expected form: **で**

Why: で relations. [[Japanese#^ja-Q0219|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AF%E8%B2%B4%E4%B9%83%E8%8A%B1%E3%81%8C%E6%80%A5%E3%81%84%E3%81%A7%E4%BD%93%E8%82%B2%E9%A4%A8%E3%82%92%E5%87%BA%E3%81%A6%E3%81%8F%E3%82%8B%E6%99%82%E3%80%81%E5%BD%BC%E3%82%92%E3%81%A1%E3%82%89%E3%81%A3%E3%81%A8%E8%A6%8B%E3%81%9F%E3%80%82)
^ja-Q0219-answer

**ja-Q0220** — 私は貴乃花が急いで体育館を出てくる時、彼をちらっと見た。

I got a quick glimpse of Takanohana as he hurriedly left the gymnasium.

Why: で relations. [[Japanese#^ja-Q0220|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AF%E8%B2%B4%E4%B9%83%E8%8A%B1%E3%81%8C%E6%80%A5%E3%81%84%E3%81%A7%E4%BD%93%E8%82%B2%E9%A4%A8%E3%82%92%E5%87%BA%E3%81%A6%E3%81%8F%E3%82%8B%E6%99%82%E3%80%81%E5%BD%BC%E3%82%92%E3%81%A1%E3%82%89%E3%81%A3%E3%81%A8%E8%A6%8B%E3%81%9F%E3%80%82)
^ja-Q0220-answer

**ja-Q0221** — 彼女は困ったらいつも両親を呼ぶことができた。

She could always call her parents when she was in a crunch.

Why: で relations. [[Japanese#^ja-Q0221|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E5%A5%B3%E3%81%AF%E5%9B%B0%E3%81%A3%E3%81%9F%E3%82%89%E3%81%84%E3%81%A4%E3%82%82%E4%B8%A1%E8%A6%AA%E3%82%92%E5%91%BC%E3%81%B6%E3%81%93%E3%81%A8%E3%81%8C%E3%81%A7%E3%81%8D%E3%81%9F%E3%80%82)
^ja-Q0221-answer

**ja-Q0222** — 彼女は困ったらいつも両親を呼ぶことができた。

She could always call her parents when she was in a crunch.

で often marks event location, means or material. Compare 学校にいる, be at school, with 学校で勉強する, study at school. It can also link a noun/adjectival predicate.

Why: で relations. [[Japanese#^ja-Q0222|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E5%A5%B3%E3%81%AF%E5%9B%B0%E3%81%A3%E3%81%9F%E3%82%89%E3%81%84%E3%81%A4%E3%82%82%E4%B8%A1%E8%A6%AA%E3%82%92%E5%91%BC%E3%81%B6%E3%81%93%E3%81%A8%E3%81%8C%E3%81%A7%E3%81%8D%E3%81%9F%E3%80%82)
^ja-Q0222-answer

**ja-Q0223** — 彼は夜随分遅くまで働いた。

He worked far into the night.

Expected form: **で**

Why: で relations. [[Japanese#^ja-Q0223|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%AF%E5%A4%9C%E9%9A%8F%E5%88%86%E9%81%85%E3%81%8F%E3%81%BE%E3%81%A7%E5%83%8D%E3%81%84%E3%81%9F%E3%80%82)
^ja-Q0223-answer

**ja-Q0224** — 彼は夜随分遅くまで働いた。

He worked far into the night.

Expected form: **で**

Why: で relations. [[Japanese#^ja-Q0224|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%AF%E5%A4%9C%E9%9A%8F%E5%88%86%E9%81%85%E3%81%8F%E3%81%BE%E3%81%A7%E5%83%8D%E3%81%84%E3%81%9F%E3%80%82)
^ja-Q0224-answer

**ja-Q0225** — 私は英語を教える事ができます。

I can teach English.

Expected form: **で**

Why: で relations. [[Japanese#^ja-Q0225|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AF%E8%8B%B1%E8%AA%9E%E3%82%92%E6%95%99%E3%81%88%E3%82%8B%E4%BA%8B%E3%81%8C%E3%81%A7%E3%81%8D%E3%81%BE%E3%81%99%E3%80%82)
^ja-Q0225-answer

**ja-Q0226** — 私は英語を教える事ができます。

I can teach English.

Why: で relations. [[Japanese#^ja-Q0226|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AF%E8%8B%B1%E8%AA%9E%E3%82%92%E6%95%99%E3%81%88%E3%82%8B%E4%BA%8B%E3%81%8C%E3%81%A7%E3%81%8D%E3%81%BE%E3%81%99%E3%80%82)
^ja-Q0226-answer

**ja-Q0227** — どういう風の吹き回しでこうなったのだろう。

Why does everything happen to me?

Why: で relations. [[Japanese#^ja-Q0227|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%A9%E3%81%86%E3%81%84%E3%81%86%E9%A2%A8%E3%81%AE%E5%90%B9%E3%81%8D%E5%9B%9E%E3%81%97%E3%81%A7%E3%81%93%E3%81%86%E3%81%AA%E3%81%A3%E3%81%9F%E3%81%AE%E3%81%A0%E3%82%8D%E3%81%86%E3%80%82)
^ja-Q0227-answer

**ja-Q0228** — どういう風の吹き回しでこうなったのだろう。

Why does everything happen to me?

で often marks event location, means or material. Compare 学校にいる, be at school, with 学校で勉強する, study at school. It can also link a noun/adjectival predicate.

Why: で relations. [[Japanese#^ja-Q0228|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%A9%E3%81%86%E3%81%84%E3%81%86%E9%A2%A8%E3%81%AE%E5%90%B9%E3%81%8D%E5%9B%9E%E3%81%97%E3%81%A7%E3%81%93%E3%81%86%E3%81%AA%E3%81%A3%E3%81%9F%E3%81%AE%E3%81%A0%E3%82%8D%E3%81%86%E3%80%82)
^ja-Q0228-answer

**ja-Q0229** — これから火葬場へ移動しますので、小川様と君は車へ。

We are now going to move to the crematorium so if Mr. Ogawa and you would enter the car ...

Expected form: **で**

Why: で relations. [[Japanese#^ja-Q0229|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%93%E3%82%8C%E3%81%8B%E3%82%89%E7%81%AB%E8%91%AC%E5%A0%B4%E3%81%B8%E7%A7%BB%E5%8B%95%E3%81%97%E3%81%BE%E3%81%99%E3%81%AE%E3%81%A7%E3%80%81%E5%B0%8F%E5%B7%9D%E6%A7%98%E3%81%A8%E5%90%9B%E3%81%AF%E8%BB%8A%E3%81%B8%E3%80%82)
^ja-Q0229-answer

**ja-Q0230** — これから火葬場へ移動しますので、小川様と君は車へ。

We are now going to move to the crematorium so if Mr. Ogawa and you would enter the car ...

Expected form: **で**

Why: で relations. [[Japanese#^ja-Q0230|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%93%E3%82%8C%E3%81%8B%E3%82%89%E7%81%AB%E8%91%AC%E5%A0%B4%E3%81%B8%E7%A7%BB%E5%8B%95%E3%81%97%E3%81%BE%E3%81%99%E3%81%AE%E3%81%A7%E3%80%81%E5%B0%8F%E5%B7%9D%E6%A7%98%E3%81%A8%E5%90%9B%E3%81%AF%E8%BB%8A%E3%81%B8%E3%80%82)
^ja-Q0230-answer

**ja-Q0231** — 私は彼の要求しているものが理解できない。

I can't make out what he wants.

Expected form: **で**

Why: で relations. [[Japanese#^ja-Q0231|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AF%E5%BD%BC%E3%81%AE%E8%A6%81%E6%B1%82%E3%81%97%E3%81%A6%E3%81%84%E3%82%8B%E3%82%82%E3%81%AE%E3%81%8C%E7%90%86%E8%A7%A3%E3%81%A7%E3%81%8D%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0231-answer

**ja-Q0232** — 私は彼の要求しているものが理解できない。

I can't make out what he wants.

Why: で relations. [[Japanese#^ja-Q0232|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AF%E5%BD%BC%E3%81%AE%E8%A6%81%E6%B1%82%E3%81%97%E3%81%A6%E3%81%84%E3%82%8B%E3%82%82%E3%81%AE%E3%81%8C%E7%90%86%E8%A7%A3%E3%81%A7%E3%81%8D%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0232-answer

**ja-Q0233** — 彼は大学時代に京都にすんでいた。

He lived in Kyoto in his college days.

Why: で relations. [[Japanese#^ja-Q0233|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%AF%E5%A4%A7%E5%AD%A6%E6%99%82%E4%BB%A3%E3%81%AB%E4%BA%AC%E9%83%BD%E3%81%AB%E3%81%99%E3%82%93%E3%81%A7%E3%81%84%E3%81%9F%E3%80%82)
^ja-Q0233-answer

**ja-Q0234** — 彼は大学時代に京都にすんでいた。

He lived in Kyoto in his college days.

で often marks event location, means or material. Compare 学校にいる, be at school, with 学校で勉強する, study at school. It can also link a noun/adjectival predicate.

Why: で relations. [[Japanese#^ja-Q0234|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%AF%E5%A4%A7%E5%AD%A6%E6%99%82%E4%BB%A3%E3%81%AB%E4%BA%AC%E9%83%BD%E3%81%AB%E3%81%99%E3%82%93%E3%81%A7%E3%81%84%E3%81%9F%E3%80%82)
^ja-Q0234-answer

**ja-Q0235** — 彼がどんなに熱心に英語を勉強しても、１年や２年ではものにすることはできない。

No matter how hard he may study, he cannot master English in a year or two.

Expected form: **で**

Why: で relations. [[Japanese#^ja-Q0235|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%8C%E3%81%A9%E3%82%93%E3%81%AA%E3%81%AB%E7%86%B1%E5%BF%83%E3%81%AB%E8%8B%B1%E8%AA%9E%E3%82%92%E5%8B%89%E5%BC%B7%E3%81%97%E3%81%A6%E3%82%82%E3%80%81%EF%BC%91%E5%B9%B4%E3%82%84%EF%BC%92%E5%B9%B4%E3%81%A7%E3%81%AF%E3%82%82%E3%81%AE%E3%81%AB%E3%81%99%E3%82%8B%E3%81%93%E3%81%A8%E3%81%AF%E3%81%A7%E3%81%8D%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0235-answer

**ja-Q0236** — 彼がどんなに熱心に英語を勉強しても、１年や２年ではものにすることはできない。

No matter how hard he may study, he cannot master English in a year or two.

Expected form: **で**

Why: で relations. [[Japanese#^ja-Q0236|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%8C%E3%81%A9%E3%82%93%E3%81%AA%E3%81%AB%E7%86%B1%E5%BF%83%E3%81%AB%E8%8B%B1%E8%AA%9E%E3%82%92%E5%8B%89%E5%BC%B7%E3%81%97%E3%81%A6%E3%82%82%E3%80%81%EF%BC%91%E5%B9%B4%E3%82%84%EF%BC%92%E5%B9%B4%E3%81%A7%E3%81%AF%E3%82%82%E3%81%AE%E3%81%AB%E3%81%99%E3%82%8B%E3%81%93%E3%81%A8%E3%81%AF%E3%81%A7%E3%81%8D%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0236-answer

**ja-Q0237** — 彼女は秘書としては推薦することはできない。

I cannot recommend her as a secretary.

Expected form: **で**

Why: で relations. [[Japanese#^ja-Q0237|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E5%A5%B3%E3%81%AF%E7%A7%98%E6%9B%B8%E3%81%A8%E3%81%97%E3%81%A6%E3%81%AF%E6%8E%A8%E8%96%A6%E3%81%99%E3%82%8B%E3%81%93%E3%81%A8%E3%81%AF%E3%81%A7%E3%81%8D%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0237-answer

**ja-Q0238** — 彼女は秘書としては推薦することはできない。

I cannot recommend her as a secretary.

Why: で relations. [[Japanese#^ja-Q0238|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E5%A5%B3%E3%81%AF%E7%A7%98%E6%9B%B8%E3%81%A8%E3%81%97%E3%81%A6%E3%81%AF%E6%8E%A8%E8%96%A6%E3%81%99%E3%82%8B%E3%81%93%E3%81%A8%E3%81%AF%E3%81%A7%E3%81%8D%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0238-answer

**ja-Q0239** — それから，最終コーナーで全力疾走に入った。

And then, on the final turn, he began to sprint at full speed.

Why: で relations. [[Japanese#^ja-Q0239|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%9D%E3%82%8C%E3%81%8B%E3%82%89%EF%BC%8C%E6%9C%80%E7%B5%82%E3%82%B3%E3%83%BC%E3%83%8A%E3%83%BC%E3%81%A7%E5%85%A8%E5%8A%9B%E7%96%BE%E8%B5%B0%E3%81%AB%E5%85%A5%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0239-answer

**ja-Q0240** — それから，最終コーナーで全力疾走に入った。

And then, on the final turn, he began to sprint at full speed.

で often marks event location, means or material. Compare 学校にいる, be at school, with 学校で勉強する, study at school. It can also link a noun/adjectival predicate.

Why: で relations. [[Japanese#^ja-Q0240|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%9D%E3%82%8C%E3%81%8B%E3%82%89%EF%BC%8C%E6%9C%80%E7%B5%82%E3%82%B3%E3%83%BC%E3%83%8A%E3%83%BC%E3%81%A7%E5%85%A8%E5%8A%9B%E7%96%BE%E8%B5%B0%E3%81%AB%E5%85%A5%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0240-answer

**ja-Q0241** — その城は今では廃虚となっている。

The castle is now in ruins.

Expected form: **で**

Why: で relations. [[Japanese#^ja-Q0241|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%9D%E3%81%AE%E5%9F%8E%E3%81%AF%E4%BB%8A%E3%81%A7%E3%81%AF%E5%BB%83%E8%99%9A%E3%81%A8%E3%81%AA%E3%81%A3%E3%81%A6%E3%81%84%E3%82%8B%E3%80%82)
^ja-Q0241-answer

**ja-Q0242** — その城は今では廃虚となっている。

The castle is now in ruins.

Expected form: **で**

Why: で relations. [[Japanese#^ja-Q0242|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%9D%E3%81%AE%E5%9F%8E%E3%81%AF%E4%BB%8A%E3%81%A7%E3%81%AF%E5%BB%83%E8%99%9A%E3%81%A8%E3%81%AA%E3%81%A3%E3%81%A6%E3%81%84%E3%82%8B%E3%80%82)
^ja-Q0242-answer

**ja-Q0243** — 国家が繁栄するかは多かれ少なかれ国民次第である。

The prosperity of a country depends more or less on its citizens.

Expected form: **で**

Why: で relations. [[Japanese#^ja-Q0243|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%9B%BD%E5%AE%B6%E3%81%8C%E7%B9%81%E6%A0%84%E3%81%99%E3%82%8B%E3%81%8B%E3%81%AF%E5%A4%9A%E3%81%8B%E3%82%8C%E5%B0%91%E3%81%AA%E3%81%8B%E3%82%8C%E5%9B%BD%E6%B0%91%E6%AC%A1%E7%AC%AC%E3%81%A7%E3%81%82%E3%82%8B%E3%80%82)
^ja-Q0243-answer

**ja-Q0244** — 国家が繁栄するかは多かれ少なかれ国民次第である。

The prosperity of a country depends more or less on its citizens.

Why: で relations. [[Japanese#^ja-Q0244|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%9B%BD%E5%AE%B6%E3%81%8C%E7%B9%81%E6%A0%84%E3%81%99%E3%82%8B%E3%81%8B%E3%81%AF%E5%A4%9A%E3%81%8B%E3%82%8C%E5%B0%91%E3%81%AA%E3%81%8B%E3%82%8C%E5%9B%BD%E6%B0%91%E6%AC%A1%E7%AC%AC%E3%81%A7%E3%81%82%E3%82%8B%E3%80%82)
^ja-Q0244-answer

**ja-Q0245** — とても明日までにこの仕事はすみそうにない。

We can never begin to finish this work by tomorrow.

Why: で relations. [[Japanese#^ja-Q0245|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%A8%E3%81%A6%E3%82%82%E6%98%8E%E6%97%A5%E3%81%BE%E3%81%A7%E3%81%AB%E3%81%93%E3%81%AE%E4%BB%95%E4%BA%8B%E3%81%AF%E3%81%99%E3%81%BF%E3%81%9D%E3%81%86%E3%81%AB%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0245-answer

**ja-Q0246** — とても明日までにこの仕事はすみそうにない。

We can never begin to finish this work by tomorrow.

で often marks event location, means or material. Compare 学校にいる, be at school, with 学校で勉強する, study at school. It can also link a noun/adjectival predicate.

Why: で relations. [[Japanese#^ja-Q0246|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%A8%E3%81%A6%E3%82%82%E6%98%8E%E6%97%A5%E3%81%BE%E3%81%A7%E3%81%AB%E3%81%93%E3%81%AE%E4%BB%95%E4%BA%8B%E3%81%AF%E3%81%99%E3%81%BF%E3%81%9D%E3%81%86%E3%81%AB%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0246-answer

**ja-Q0247** — 私は船に弱いので、船旅は好きではない。

I am a poor sailor, so I don't like to travel by boat.

Expected form: **で**

Why: で relations. [[Japanese#^ja-Q0247|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AF%E8%88%B9%E3%81%AB%E5%BC%B1%E3%81%84%E3%81%AE%E3%81%A7%E3%80%81%E8%88%B9%E6%97%85%E3%81%AF%E5%A5%BD%E3%81%8D%E3%81%A7%E3%81%AF%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0247-answer

**ja-Q0248** — 私は船に弱いので、船旅は好きではない。

I am a poor sailor, so I don't like to travel by boat.

Expected form: **で**

Why: で relations. [[Japanese#^ja-Q0248|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AF%E8%88%B9%E3%81%AB%E5%BC%B1%E3%81%84%E3%81%AE%E3%81%A7%E3%80%81%E8%88%B9%E6%97%85%E3%81%AF%E5%A5%BD%E3%81%8D%E3%81%A7%E3%81%AF%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0248-answer

**ja-Q0249** — お父さんが帰るまでに宿題をすませなさい。

Finish your homework by the time your father comes home.

Expected form: **で**

Why: で relations. [[Japanese#^ja-Q0249|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%8A%E7%88%B6%E3%81%95%E3%82%93%E3%81%8C%E5%B8%B0%E3%82%8B%E3%81%BE%E3%81%A7%E3%81%AB%E5%AE%BF%E9%A1%8C%E3%82%92%E3%81%99%E3%81%BE%E3%81%9B%E3%81%AA%E3%81%95%E3%81%84%E3%80%82)
^ja-Q0249-answer

**ja-Q0250** — お父さんが帰るまでに宿題をすませなさい。

Finish your homework by the time your father comes home.

Why: で relations. [[Japanese#^ja-Q0250|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%8A%E7%88%B6%E3%81%95%E3%82%93%E3%81%8C%E5%B8%B0%E3%82%8B%E3%81%BE%E3%81%A7%E3%81%AB%E5%AE%BF%E9%A1%8C%E3%82%92%E3%81%99%E3%81%BE%E3%81%9B%E3%81%AA%E3%81%95%E3%81%84%E3%80%82)
^ja-Q0250-answer


### Answers 251–300

**ja-Q0251** — 彼女の友達は歌手です。

Her friend is a singer.

Why: Possession and modification の. [[Japanese#^ja-Q0251|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E5%A5%B3%E3%81%AE%E5%8F%8B%E9%81%94%E3%81%AF%E6%AD%8C%E6%89%8B%E3%81%A7%E3%81%99%E3%80%82)
^ja-Q0251-answer

**ja-Q0252** — 彼女の友達は歌手です。

Her friend is a singer.

の links nouns in many relationships, including possession. It can also nominalise a clause. The relation is broader than English possessive ’s.

Why: Possession and modification の. [[Japanese#^ja-Q0252|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E5%A5%B3%E3%81%AE%E5%8F%8B%E9%81%94%E3%81%AF%E6%AD%8C%E6%89%8B%E3%81%A7%E3%81%99%E3%80%82)
^ja-Q0252-answer

**ja-Q0253** — これまた政府の隠ぺい策のようです。

This looks like another government cover-up.

Expected form: **の**

Why: Possession and modification の. [[Japanese#^ja-Q0253|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%93%E3%82%8C%E3%81%BE%E3%81%9F%E6%94%BF%E5%BA%9C%E3%81%AE%E9%9A%A0%E3%81%BA%E3%81%84%E7%AD%96%E3%81%AE%E3%82%88%E3%81%86%E3%81%A7%E3%81%99%E3%80%82)
^ja-Q0253-answer

**ja-Q0254** — これまた政府の隠ぺい策のようです。

This looks like another government cover-up.

Expected form: **の**

Why: Possession and modification の. [[Japanese#^ja-Q0254|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%93%E3%82%8C%E3%81%BE%E3%81%9F%E6%94%BF%E5%BA%9C%E3%81%AE%E9%9A%A0%E3%81%BA%E3%81%84%E7%AD%96%E3%81%AE%E3%82%88%E3%81%86%E3%81%A7%E3%81%99%E3%80%82)
^ja-Q0254-answer

**ja-Q0255** — 君の場合は例外としよう。

We will make an exception of your case.

Expected form: **の**

Why: Possession and modification の. [[Japanese#^ja-Q0255|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%90%9B%E3%81%AE%E5%A0%B4%E5%90%88%E3%81%AF%E4%BE%8B%E5%A4%96%E3%81%A8%E3%81%97%E3%82%88%E3%81%86%E3%80%82)
^ja-Q0255-answer

**ja-Q0256** — 君の場合は例外としよう。

We will make an exception of your case.

Why: Possession and modification の. [[Japanese#^ja-Q0256|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%90%9B%E3%81%AE%E5%A0%B4%E5%90%88%E3%81%AF%E4%BE%8B%E5%A4%96%E3%81%A8%E3%81%97%E3%82%88%E3%81%86%E3%80%82)
^ja-Q0256-answer

**ja-Q0257** — そのジェット機は稲光より速かった。

Those jets were faster than lightning.

Why: Possession and modification の. [[Japanese#^ja-Q0257|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%9D%E3%81%AE%E3%82%B8%E3%82%A7%E3%83%83%E3%83%88%E6%A9%9F%E3%81%AF%E7%A8%B2%E5%85%89%E3%82%88%E3%82%8A%E9%80%9F%E3%81%8B%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0257-answer

**ja-Q0258** — そのジェット機は稲光より速かった。

Those jets were faster than lightning.

の links nouns in many relationships, including possession. It can also nominalise a clause. The relation is broader than English possessive ’s.

Why: Possession and modification の. [[Japanese#^ja-Q0258|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%9D%E3%81%AE%E3%82%B8%E3%82%A7%E3%83%83%E3%83%88%E6%A9%9F%E3%81%AF%E7%A8%B2%E5%85%89%E3%82%88%E3%82%8A%E9%80%9F%E3%81%8B%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0258-answer

**ja-Q0259** — これは扇子といって、こうやって開くんです。夏の暑い日に使うんです。

This is a folding fan, and this is how you open it. It's for hot summer days.

Expected form: **の**

Why: Possession and modification の. [[Japanese#^ja-Q0259|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%93%E3%82%8C%E3%81%AF%E6%89%87%E5%AD%90%E3%81%A8%E3%81%84%E3%81%A3%E3%81%A6%E3%80%81%E3%81%93%E3%81%86%E3%82%84%E3%81%A3%E3%81%A6%E9%96%8B%E3%81%8F%E3%82%93%E3%81%A7%E3%81%99%E3%80%82%E5%A4%8F%E3%81%AE%E6%9A%91%E3%81%84%E6%97%A5%E3%81%AB%E4%BD%BF%E3%81%86%E3%82%93%E3%81%A7%E3%81%99%E3%80%82)
^ja-Q0259-answer

**ja-Q0260** — これは扇子といって、こうやって開くんです。夏の暑い日に使うんです。

This is a folding fan, and this is how you open it. It's for hot summer days.

Expected form: **の**

Why: Possession and modification の. [[Japanese#^ja-Q0260|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%93%E3%82%8C%E3%81%AF%E6%89%87%E5%AD%90%E3%81%A8%E3%81%84%E3%81%A3%E3%81%A6%E3%80%81%E3%81%93%E3%81%86%E3%82%84%E3%81%A3%E3%81%A6%E9%96%8B%E3%81%8F%E3%82%93%E3%81%A7%E3%81%99%E3%80%82%E5%A4%8F%E3%81%AE%E6%9A%91%E3%81%84%E6%97%A5%E3%81%AB%E4%BD%BF%E3%81%86%E3%82%93%E3%81%A7%E3%81%99%E3%80%82)
^ja-Q0260-answer

**ja-Q0261** — それは君の決めることだ。

It is up to you.

Expected form: **の**

Why: Possession and modification の. [[Japanese#^ja-Q0261|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%9D%E3%82%8C%E3%81%AF%E5%90%9B%E3%81%AE%E6%B1%BA%E3%82%81%E3%82%8B%E3%81%93%E3%81%A8%E3%81%A0%E3%80%82)
^ja-Q0261-answer

**ja-Q0262** — それは君の決めることだ。

It is up to you.

Why: Possession and modification の. [[Japanese#^ja-Q0262|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%9D%E3%82%8C%E3%81%AF%E5%90%9B%E3%81%AE%E6%B1%BA%E3%82%81%E3%82%8B%E3%81%93%E3%81%A8%E3%81%A0%E3%80%82)
^ja-Q0262-answer

**ja-Q0263** — 彼女はパーティーの間ずっと踊り続けた。

She kept on dancing all through the party.

Why: Possession and modification の. [[Japanese#^ja-Q0263|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E5%A5%B3%E3%81%AF%E3%83%91%E3%83%BC%E3%83%86%E3%82%A3%E3%83%BC%E3%81%AE%E9%96%93%E3%81%9A%E3%81%A3%E3%81%A8%E8%B8%8A%E3%82%8A%E7%B6%9A%E3%81%91%E3%81%9F%E3%80%82)
^ja-Q0263-answer

**ja-Q0264** — 彼女はパーティーの間ずっと踊り続けた。

She kept on dancing all through the party.

の links nouns in many relationships, including possession. It can also nominalise a clause. The relation is broader than English possessive ’s.

Why: Possession and modification の. [[Japanese#^ja-Q0264|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E5%A5%B3%E3%81%AF%E3%83%91%E3%83%BC%E3%83%86%E3%82%A3%E3%83%BC%E3%81%AE%E9%96%93%E3%81%9A%E3%81%A3%E3%81%A8%E8%B8%8A%E3%82%8A%E7%B6%9A%E3%81%91%E3%81%9F%E3%80%82)
^ja-Q0264-answer

**ja-Q0265** — 私はその話を聞いて東京の将来について考えさせられた。

That story made me think over the future of Tokyo.

Expected form: **の**

Why: Possession and modification の. [[Japanese#^ja-Q0265|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AF%E3%81%9D%E3%81%AE%E8%A9%B1%E3%82%92%E8%81%9E%E3%81%84%E3%81%A6%E6%9D%B1%E4%BA%AC%E3%81%AE%E5%B0%86%E6%9D%A5%E3%81%AB%E3%81%A4%E3%81%84%E3%81%A6%E8%80%83%E3%81%88%E3%81%95%E3%81%9B%E3%82%89%E3%82%8C%E3%81%9F%E3%80%82)
^ja-Q0265-answer

**ja-Q0266** — 私はその話を聞いて東京の将来について考えさせられた。

That story made me think over the future of Tokyo.

Expected form: **の**

Why: Possession and modification の. [[Japanese#^ja-Q0266|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AF%E3%81%9D%E3%81%AE%E8%A9%B1%E3%82%92%E8%81%9E%E3%81%84%E3%81%A6%E6%9D%B1%E4%BA%AC%E3%81%AE%E5%B0%86%E6%9D%A5%E3%81%AB%E3%81%A4%E3%81%84%E3%81%A6%E8%80%83%E3%81%88%E3%81%95%E3%81%9B%E3%82%89%E3%82%8C%E3%81%9F%E3%80%82)
^ja-Q0266-answer

**ja-Q0267** — 忘れずに出席者の員数をかぞえなさい。

Don't forget to count how many people attend.

Expected form: **の**

Why: Possession and modification の. [[Japanese#^ja-Q0267|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BF%98%E3%82%8C%E3%81%9A%E3%81%AB%E5%87%BA%E5%B8%AD%E8%80%85%E3%81%AE%E5%93%A1%E6%95%B0%E3%82%92%E3%81%8B%E3%81%9E%E3%81%88%E3%81%AA%E3%81%95%E3%81%84%E3%80%82)
^ja-Q0267-answer

**ja-Q0268** — 忘れずに出席者の員数をかぞえなさい。

Don't forget to count how many people attend.

Why: Possession and modification の. [[Japanese#^ja-Q0268|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BF%98%E3%82%8C%E3%81%9A%E3%81%AB%E5%87%BA%E5%B8%AD%E8%80%85%E3%81%AE%E5%93%A1%E6%95%B0%E3%82%92%E3%81%8B%E3%81%9E%E3%81%88%E3%81%AA%E3%81%95%E3%81%84%E3%80%82)
^ja-Q0268-answer

**ja-Q0269** — 私の命令には従ってもらうようお願いいたします。

I must request you to obey my orders.

Why: Possession and modification の. [[Japanese#^ja-Q0269|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AE%E5%91%BD%E4%BB%A4%E3%81%AB%E3%81%AF%E5%BE%93%E3%81%A3%E3%81%A6%E3%82%82%E3%82%89%E3%81%86%E3%82%88%E3%81%86%E3%81%8A%E9%A1%98%E3%81%84%E3%81%84%E3%81%9F%E3%81%97%E3%81%BE%E3%81%99%E3%80%82)
^ja-Q0269-answer

**ja-Q0270** — 私の命令には従ってもらうようお願いいたします。

I must request you to obey my orders.

の links nouns in many relationships, including possession. It can also nominalise a clause. The relation is broader than English possessive ’s.

Why: Possession and modification の. [[Japanese#^ja-Q0270|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AE%E5%91%BD%E4%BB%A4%E3%81%AB%E3%81%AF%E5%BE%93%E3%81%A3%E3%81%A6%E3%82%82%E3%82%89%E3%81%86%E3%82%88%E3%81%86%E3%81%8A%E9%A1%98%E3%81%84%E3%81%84%E3%81%9F%E3%81%97%E3%81%BE%E3%81%99%E3%80%82)
^ja-Q0270-answer

**ja-Q0271** — この小説はつまらない。

This novel is boring.

Expected form: **の**

Why: Possession and modification の. [[Japanese#^ja-Q0271|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%93%E3%81%AE%E5%B0%8F%E8%AA%AC%E3%81%AF%E3%81%A4%E3%81%BE%E3%82%89%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0271-answer

**ja-Q0272** — この小説はつまらない。

This novel is boring.

Expected form: **の**

Why: Possession and modification の. [[Japanese#^ja-Q0272|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%93%E3%81%AE%E5%B0%8F%E8%AA%AC%E3%81%AF%E3%81%A4%E3%81%BE%E3%82%89%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0272-answer

**ja-Q0273** — 私は息子にその手紙を投函させた。

I got my son to post the letters.

Expected form: **の**

Why: Possession and modification の. [[Japanese#^ja-Q0273|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AF%E6%81%AF%E5%AD%90%E3%81%AB%E3%81%9D%E3%81%AE%E6%89%8B%E7%B4%99%E3%82%92%E6%8A%95%E5%87%BD%E3%81%95%E3%81%9B%E3%81%9F%E3%80%82)
^ja-Q0273-answer

**ja-Q0274** — 私は息子にその手紙を投函させた。

I got my son to post the letters.

Why: Possession and modification の. [[Japanese#^ja-Q0274|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AF%E6%81%AF%E5%AD%90%E3%81%AB%E3%81%9D%E3%81%AE%E6%89%8B%E7%B4%99%E3%82%92%E6%8A%95%E5%87%BD%E3%81%95%E3%81%9B%E3%81%9F%E3%80%82)
^ja-Q0274-answer

**ja-Q0275** — 彼らは自分の部屋をうまく利用している。

They make good use of their rooms.

Why: Possession and modification の. [[Japanese#^ja-Q0275|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%82%89%E3%81%AF%E8%87%AA%E5%88%86%E3%81%AE%E9%83%A8%E5%B1%8B%E3%82%92%E3%81%86%E3%81%BE%E3%81%8F%E5%88%A9%E7%94%A8%E3%81%97%E3%81%A6%E3%81%84%E3%82%8B%E3%80%82)
^ja-Q0275-answer

**ja-Q0276** — 彼らは自分の部屋をうまく利用している。

They make good use of their rooms.

の links nouns in many relationships, including possession. It can also nominalise a clause. The relation is broader than English possessive ’s.

Why: Possession and modification の. [[Japanese#^ja-Q0276|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%82%89%E3%81%AF%E8%87%AA%E5%88%86%E3%81%AE%E9%83%A8%E5%B1%8B%E3%82%92%E3%81%86%E3%81%BE%E3%81%8F%E5%88%A9%E7%94%A8%E3%81%97%E3%81%A6%E3%81%84%E3%82%8B%E3%80%82)
^ja-Q0276-answer

**ja-Q0277** — ふっ、禁断の魔術とやらは、俺には通用しないぜ！

Hah, your 'forbidden magics' aren't going to work with me!

Expected form: **の**

Why: Possession and modification の. [[Japanese#^ja-Q0277|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%B5%E3%81%A3%E3%80%81%E7%A6%81%E6%96%AD%E3%81%AE%E9%AD%94%E8%A1%93%E3%81%A8%E3%82%84%E3%82%89%E3%81%AF%E3%80%81%E4%BF%BA%E3%81%AB%E3%81%AF%E9%80%9A%E7%94%A8%E3%81%97%E3%81%AA%E3%81%84%E3%81%9C%EF%BC%81)
^ja-Q0277-answer

**ja-Q0278** — ふっ、禁断の魔術とやらは、俺には通用しないぜ！

Hah, your 'forbidden magics' aren't going to work with me!

Expected form: **の**

Why: Possession and modification の. [[Japanese#^ja-Q0278|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%B5%E3%81%A3%E3%80%81%E7%A6%81%E6%96%AD%E3%81%AE%E9%AD%94%E8%A1%93%E3%81%A8%E3%82%84%E3%82%89%E3%81%AF%E3%80%81%E4%BF%BA%E3%81%AB%E3%81%AF%E9%80%9A%E7%94%A8%E3%81%97%E3%81%AA%E3%81%84%E3%81%9C%EF%BC%81)
^ja-Q0278-answer

**ja-Q0279** — これは彼の家です。

This is his house.

Expected form: **の**

Why: Possession and modification の. [[Japanese#^ja-Q0279|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%93%E3%82%8C%E3%81%AF%E5%BD%BC%E3%81%AE%E5%AE%B6%E3%81%A7%E3%81%99%E3%80%82)
^ja-Q0279-answer

**ja-Q0280** — これは彼の家です。

This is his house.

Why: Possession and modification の. [[Japanese#^ja-Q0280|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%93%E3%82%8C%E3%81%AF%E5%BD%BC%E3%81%AE%E5%AE%B6%E3%81%A7%E3%81%99%E3%80%82)
^ja-Q0280-answer

**ja-Q0281** — その女性は断固として「我々は値下げをしません」と言った。「びた一文たりともです。さぁ、お買い上げ頂けないのでしたら、そのスーツを脱いで下さい。」

"We don't give discounts," the woman said sternly. "Regardless how small. Now, please take off the suit if you can't afford it."

Why: Possession and modification の. [[Japanese#^ja-Q0281|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%9D%E3%81%AE%E5%A5%B3%E6%80%A7%E3%81%AF%E6%96%AD%E5%9B%BA%E3%81%A8%E3%81%97%E3%81%A6%E3%80%8C%E6%88%91%E3%80%85%E3%81%AF%E5%80%A4%E4%B8%8B%E3%81%92%E3%82%92%E3%81%97%E3%81%BE%E3%81%9B%E3%82%93%E3%80%8D%E3%81%A8%E8%A8%80%E3%81%A3%E3%81%9F%E3%80%82%E3%80%8C%E3%81%B3%E3%81%9F%E4%B8%80%E6%96%87%E3%81%9F%E3%82%8A%E3%81%A8%E3%82%82%E3%81%A7%E3%81%99%E3%80%82%E3%81%95%E3%81%81%E3%80%81%E3%81%8A%E8%B2%B7%E3%81%84%E4%B8%8A%E3%81%92%E9%A0%82%E3%81%91%E3%81%AA%E3%81%84%E3%81%AE%E3%81%A7%E3%81%97%E3%81%9F%E3%82%89%E3%80%81%E3%81%9D%E3%81%AE%E3%82%B9%E3%83%BC%E3%83%84%E3%82%92%E8%84%B1%E3%81%84%E3%81%A7%E4%B8%8B%E3%81%95%E3%81%84%E3%80%82%E3%80%8D)
^ja-Q0281-answer

**ja-Q0282** — その女性は断固として「我々は値下げをしません」と言った。「びた一文たりともです。さぁ、お買い上げ頂けないのでしたら、そのスーツを脱いで下さい。」

"We don't give discounts," the woman said sternly. "Regardless how small. Now, please take off the suit if you can't afford it."

の links nouns in many relationships, including possession. It can also nominalise a clause. The relation is broader than English possessive ’s.

Why: Possession and modification の. [[Japanese#^ja-Q0282|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%9D%E3%81%AE%E5%A5%B3%E6%80%A7%E3%81%AF%E6%96%AD%E5%9B%BA%E3%81%A8%E3%81%97%E3%81%A6%E3%80%8C%E6%88%91%E3%80%85%E3%81%AF%E5%80%A4%E4%B8%8B%E3%81%92%E3%82%92%E3%81%97%E3%81%BE%E3%81%9B%E3%82%93%E3%80%8D%E3%81%A8%E8%A8%80%E3%81%A3%E3%81%9F%E3%80%82%E3%80%8C%E3%81%B3%E3%81%9F%E4%B8%80%E6%96%87%E3%81%9F%E3%82%8A%E3%81%A8%E3%82%82%E3%81%A7%E3%81%99%E3%80%82%E3%81%95%E3%81%81%E3%80%81%E3%81%8A%E8%B2%B7%E3%81%84%E4%B8%8A%E3%81%92%E9%A0%82%E3%81%91%E3%81%AA%E3%81%84%E3%81%AE%E3%81%A7%E3%81%97%E3%81%9F%E3%82%89%E3%80%81%E3%81%9D%E3%81%AE%E3%82%B9%E3%83%BC%E3%83%84%E3%82%92%E8%84%B1%E3%81%84%E3%81%A7%E4%B8%8B%E3%81%95%E3%81%84%E3%80%82%E3%80%8D)
^ja-Q0282-answer

**ja-Q0283** — 日本は多くの国からしっぺ返しをくらうだろう。

Japan will get it from many countries.

Expected form: **の**

Why: Possession and modification の. [[Japanese#^ja-Q0283|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%97%A5%E6%9C%AC%E3%81%AF%E5%A4%9A%E3%81%8F%E3%81%AE%E5%9B%BD%E3%81%8B%E3%82%89%E3%81%97%E3%81%A3%E3%81%BA%E8%BF%94%E3%81%97%E3%82%92%E3%81%8F%E3%82%89%E3%81%86%E3%81%A0%E3%82%8D%E3%81%86%E3%80%82)
^ja-Q0283-answer

**ja-Q0284** — 日本は多くの国からしっぺ返しをくらうだろう。

Japan will get it from many countries.

Expected form: **の**

Why: Possession and modification の. [[Japanese#^ja-Q0284|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%97%A5%E6%9C%AC%E3%81%AF%E5%A4%9A%E3%81%8F%E3%81%AE%E5%9B%BD%E3%81%8B%E3%82%89%E3%81%97%E3%81%A3%E3%81%BA%E8%BF%94%E3%81%97%E3%82%92%E3%81%8F%E3%82%89%E3%81%86%E3%81%A0%E3%82%8D%E3%81%86%E3%80%82)
^ja-Q0284-answer

**ja-Q0285** — 私にこのペンをください。

Please give me this pen.

Expected form: **の**

Why: Possession and modification の. [[Japanese#^ja-Q0285|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AB%E3%81%93%E3%81%AE%E3%83%9A%E3%83%B3%E3%82%92%E3%81%8F%E3%81%A0%E3%81%95%E3%81%84%E3%80%82)
^ja-Q0285-answer

**ja-Q0286** — 私にこのペンをください。

Please give me this pen.

Why: Possession and modification の. [[Japanese#^ja-Q0286|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AB%E3%81%93%E3%81%AE%E3%83%9A%E3%83%B3%E3%82%92%E3%81%8F%E3%81%A0%E3%81%95%E3%81%84%E3%80%82)
^ja-Q0286-answer

**ja-Q0287** — 私の父は毎日とても忙しい。

My father is busy as a bee every day.

Why: Possession and modification の. [[Japanese#^ja-Q0287|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AE%E7%88%B6%E3%81%AF%E6%AF%8E%E6%97%A5%E3%81%A8%E3%81%A6%E3%82%82%E5%BF%99%E3%81%97%E3%81%84%E3%80%82)
^ja-Q0287-answer

**ja-Q0288** — 私の父は毎日とても忙しい。

My father is busy as a bee every day.

の links nouns in many relationships, including possession. It can also nominalise a clause. The relation is broader than English possessive ’s.

Why: Possession and modification の. [[Japanese#^ja-Q0288|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AE%E7%88%B6%E3%81%AF%E6%AF%8E%E6%97%A5%E3%81%A8%E3%81%A6%E3%82%82%E5%BF%99%E3%81%97%E3%81%84%E3%80%82)
^ja-Q0288-answer

**ja-Q0289** — これらの図式は求職に関する様々なアプローチを示している。

These diagrams demonstrate different possible approaches to job seeking.

Expected form: **の**

Why: Possession and modification の. [[Japanese#^ja-Q0289|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%93%E3%82%8C%E3%82%89%E3%81%AE%E5%9B%B3%E5%BC%8F%E3%81%AF%E6%B1%82%E8%81%B7%E3%81%AB%E9%96%A2%E3%81%99%E3%82%8B%E6%A7%98%E3%80%85%E3%81%AA%E3%82%A2%E3%83%97%E3%83%AD%E3%83%BC%E3%83%81%E3%82%92%E7%A4%BA%E3%81%97%E3%81%A6%E3%81%84%E3%82%8B%E3%80%82)
^ja-Q0289-answer

**ja-Q0290** — これらの図式は求職に関する様々なアプローチを示している。

These diagrams demonstrate different possible approaches to job seeking.

Expected form: **の**

Why: Possession and modification の. [[Japanese#^ja-Q0290|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%93%E3%82%8C%E3%82%89%E3%81%AE%E5%9B%B3%E5%BC%8F%E3%81%AF%E6%B1%82%E8%81%B7%E3%81%AB%E9%96%A2%E3%81%99%E3%82%8B%E6%A7%98%E3%80%85%E3%81%AA%E3%82%A2%E3%83%97%E3%83%AD%E3%83%BC%E3%83%81%E3%82%92%E7%A4%BA%E3%81%97%E3%81%A6%E3%81%84%E3%82%8B%E3%80%82)
^ja-Q0290-answer

**ja-Q0291** — 私は、あの人たちみたいにはなりたくない。

I don't want to become like those people.

Expected form: **の**

Why: Possession and modification の. [[Japanese#^ja-Q0291|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AF%E3%80%81%E3%81%82%E3%81%AE%E4%BA%BA%E3%81%9F%E3%81%A1%E3%81%BF%E3%81%9F%E3%81%84%E3%81%AB%E3%81%AF%E3%81%AA%E3%82%8A%E3%81%9F%E3%81%8F%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0291-answer

**ja-Q0292** — 私は、あの人たちみたいにはなりたくない。

I don't want to become like those people.

Why: Possession and modification の. [[Japanese#^ja-Q0292|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AF%E3%80%81%E3%81%82%E3%81%AE%E4%BA%BA%E3%81%9F%E3%81%A1%E3%81%BF%E3%81%9F%E3%81%84%E3%81%AB%E3%81%AF%E3%81%AA%E3%82%8A%E3%81%9F%E3%81%8F%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0292-answer

**ja-Q0293** — 彼のオートバイは最新モデルだ。

His motorcycle is the latest model.

Why: Possession and modification の. [[Japanese#^ja-Q0293|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%AE%E3%82%AA%E3%83%BC%E3%83%88%E3%83%90%E3%82%A4%E3%81%AF%E6%9C%80%E6%96%B0%E3%83%A2%E3%83%87%E3%83%AB%E3%81%A0%E3%80%82)
^ja-Q0293-answer

**ja-Q0294** — 彼のオートバイは最新モデルだ。

His motorcycle is the latest model.

の links nouns in many relationships, including possession. It can also nominalise a clause. The relation is broader than English possessive ’s.

Why: Possession and modification の. [[Japanese#^ja-Q0294|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%AE%E3%82%AA%E3%83%BC%E3%83%88%E3%83%90%E3%82%A4%E3%81%AF%E6%9C%80%E6%96%B0%E3%83%A2%E3%83%87%E3%83%AB%E3%81%A0%E3%80%82)
^ja-Q0294-answer

**ja-Q0295** — 彼女の息子たちも、娘と同様に、大学に行っている。

Her sons as well as her daughter are in college.

Expected form: **の**

Why: Possession and modification の. [[Japanese#^ja-Q0295|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E5%A5%B3%E3%81%AE%E6%81%AF%E5%AD%90%E3%81%9F%E3%81%A1%E3%82%82%E3%80%81%E5%A8%98%E3%81%A8%E5%90%8C%E6%A7%98%E3%81%AB%E3%80%81%E5%A4%A7%E5%AD%A6%E3%81%AB%E8%A1%8C%E3%81%A3%E3%81%A6%E3%81%84%E3%82%8B%E3%80%82)
^ja-Q0295-answer

**ja-Q0296** — 彼女の息子たちも、娘と同様に、大学に行っている。

Her sons as well as her daughter are in college.

Expected form: **の**

Why: Possession and modification の. [[Japanese#^ja-Q0296|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E5%A5%B3%E3%81%AE%E6%81%AF%E5%AD%90%E3%81%9F%E3%81%A1%E3%82%82%E3%80%81%E5%A8%98%E3%81%A8%E5%90%8C%E6%A7%98%E3%81%AB%E3%80%81%E5%A4%A7%E5%AD%A6%E3%81%AB%E8%A1%8C%E3%81%A3%E3%81%A6%E3%81%84%E3%82%8B%E3%80%82)
^ja-Q0296-answer

**ja-Q0297** — 彼女はラジオの音を小さくした。

She turned down the radio.

Expected form: **の**

Why: Possession and modification の. [[Japanese#^ja-Q0297|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E5%A5%B3%E3%81%AF%E3%83%A9%E3%82%B8%E3%82%AA%E3%81%AE%E9%9F%B3%E3%82%92%E5%B0%8F%E3%81%95%E3%81%8F%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0297-answer

**ja-Q0298** — 彼女はラジオの音を小さくした。

She turned down the radio.

Why: Possession and modification の. [[Japanese#^ja-Q0298|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E5%A5%B3%E3%81%AF%E3%83%A9%E3%82%B8%E3%82%AA%E3%81%AE%E9%9F%B3%E3%82%92%E5%B0%8F%E3%81%95%E3%81%8F%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0298-answer

**ja-Q0299** — 彼の言う事には誠意が欠けている。

His statement is void of sincerity.

Why: Possession and modification の. [[Japanese#^ja-Q0299|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%AE%E8%A8%80%E3%81%86%E4%BA%8B%E3%81%AB%E3%81%AF%E8%AA%A0%E6%84%8F%E3%81%8C%E6%AC%A0%E3%81%91%E3%81%A6%E3%81%84%E3%82%8B%E3%80%82)
^ja-Q0299-answer

**ja-Q0300** — 彼の言う事には誠意が欠けている。

His statement is void of sincerity.

の links nouns in many relationships, including possession. It can also nominalise a clause. The relation is broader than English possessive ’s.

Why: Possession and modification の. [[Japanese#^ja-Q0300|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%AE%E8%A8%80%E3%81%86%E4%BA%8B%E3%81%AB%E3%81%AF%E8%AA%A0%E6%84%8F%E3%81%8C%E6%AC%A0%E3%81%91%E3%81%A6%E3%81%84%E3%82%8B%E3%80%82)
^ja-Q0300-answer


### Answers 301–350

**ja-Q0301** — 彼は全く不可能だと言った。

He said it was out of the question.

Expected form: **と**

Why: Quotation and accompaniment と. [[Japanese#^ja-Q0301|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%AF%E5%85%A8%E3%81%8F%E4%B8%8D%E5%8F%AF%E8%83%BD%E3%81%A0%E3%81%A8%E8%A8%80%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0301-answer

**ja-Q0302** — 彼は全く不可能だと言った。

He said it was out of the question.

Expected form: **と**

Why: Quotation and accompaniment と. [[Japanese#^ja-Q0302|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%AF%E5%85%A8%E3%81%8F%E4%B8%8D%E5%8F%AF%E8%83%BD%E3%81%A0%E3%81%A8%E8%A8%80%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0302-answer

**ja-Q0303** — 暑いと牛乳はすぐに腐る。

Milk does not keep long on a hot day.

Expected form: **と**

Why: Quotation and accompaniment と. [[Japanese#^ja-Q0303|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%9A%91%E3%81%84%E3%81%A8%E7%89%9B%E4%B9%B3%E3%81%AF%E3%81%99%E3%81%90%E3%81%AB%E8%85%90%E3%82%8B%E3%80%82)
^ja-Q0303-answer

**ja-Q0304** — 暑いと牛乳はすぐに腐る。

Milk does not keep long on a hot day.

Why: Quotation and accompaniment と. [[Japanese#^ja-Q0304|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%9A%91%E3%81%84%E3%81%A8%E7%89%9B%E4%B9%B3%E3%81%AF%E3%81%99%E3%81%90%E3%81%AB%E8%85%90%E3%82%8B%E3%80%82)
^ja-Q0304-answer

**ja-Q0305** — マリーゴールドは太陽とともに起きる。

The marigold rises with the sun.

Why: Quotation and accompaniment と. [[Japanese#^ja-Q0305|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%83%9E%E3%83%AA%E3%83%BC%E3%82%B4%E3%83%BC%E3%83%AB%E3%83%89%E3%81%AF%E5%A4%AA%E9%99%BD%E3%81%A8%E3%81%A8%E3%82%82%E3%81%AB%E8%B5%B7%E3%81%8D%E3%82%8B%E3%80%82)
^ja-Q0305-answer

**ja-Q0306** — マリーゴールドは太陽とともに起きる。

The marigold rises with the sun.

と links an exhaustive noun list, marks accompaniment, quotes content and occurs in a conditional pattern. Its role depends on what follows.

Why: Quotation and accompaniment と. [[Japanese#^ja-Q0306|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%83%9E%E3%83%AA%E3%83%BC%E3%82%B4%E3%83%BC%E3%83%AB%E3%83%89%E3%81%AF%E5%A4%AA%E9%99%BD%E3%81%A8%E3%81%A8%E3%82%82%E3%81%AB%E8%B5%B7%E3%81%8D%E3%82%8B%E3%80%82)
^ja-Q0306-answer

**ja-Q0307** — 私達は美しい景色に見とれて立っていた。

We stood looking at the beautiful scenery.

Expected form: **と**

Why: Quotation and accompaniment と. [[Japanese#^ja-Q0307|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E9%81%94%E3%81%AF%E7%BE%8E%E3%81%97%E3%81%84%E6%99%AF%E8%89%B2%E3%81%AB%E8%A6%8B%E3%81%A8%E3%82%8C%E3%81%A6%E7%AB%8B%E3%81%A3%E3%81%A6%E3%81%84%E3%81%9F%E3%80%82)
^ja-Q0307-answer

**ja-Q0308** — 私達は美しい景色に見とれて立っていた。

We stood looking at the beautiful scenery.

Expected form: **と**

Why: Quotation and accompaniment と. [[Japanese#^ja-Q0308|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E9%81%94%E3%81%AF%E7%BE%8E%E3%81%97%E3%81%84%E6%99%AF%E8%89%B2%E3%81%AB%E8%A6%8B%E3%81%A8%E3%82%8C%E3%81%A6%E7%AB%8B%E3%81%A3%E3%81%A6%E3%81%84%E3%81%9F%E3%80%82)
^ja-Q0308-answer

**ja-Q0309** — わたしはあなたと、旅行に行きたい。

I want to travel with you.

Expected form: **と**

Why: Quotation and accompaniment と. [[Japanese#^ja-Q0309|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%82%8F%E3%81%9F%E3%81%97%E3%81%AF%E3%81%82%E3%81%AA%E3%81%9F%E3%81%A8%E3%80%81%E6%97%85%E8%A1%8C%E3%81%AB%E8%A1%8C%E3%81%8D%E3%81%9F%E3%81%84%E3%80%82)
^ja-Q0309-answer

**ja-Q0310** — わたしはあなたと、旅行に行きたい。

I want to travel with you.

Why: Quotation and accompaniment と. [[Japanese#^ja-Q0310|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%82%8F%E3%81%9F%E3%81%97%E3%81%AF%E3%81%82%E3%81%AA%E3%81%9F%E3%81%A8%E3%80%81%E6%97%85%E8%A1%8C%E3%81%AB%E8%A1%8C%E3%81%8D%E3%81%9F%E3%81%84%E3%80%82)
^ja-Q0310-answer

**ja-Q0311** — ボールがバウンドして上がってくるところを打つ。

Hit the ball after the bounce.

Why: Quotation and accompaniment と. [[Japanese#^ja-Q0311|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%83%9C%E3%83%BC%E3%83%AB%E3%81%8C%E3%83%90%E3%82%A6%E3%83%B3%E3%83%89%E3%81%97%E3%81%A6%E4%B8%8A%E3%81%8C%E3%81%A3%E3%81%A6%E3%81%8F%E3%82%8B%E3%81%A8%E3%81%93%E3%82%8D%E3%82%92%E6%89%93%E3%81%A4%E3%80%82)
^ja-Q0311-answer

**ja-Q0312** — ボールがバウンドして上がってくるところを打つ。

Hit the ball after the bounce.

と links an exhaustive noun list, marks accompaniment, quotes content and occurs in a conditional pattern. Its role depends on what follows.

Why: Quotation and accompaniment と. [[Japanese#^ja-Q0312|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%83%9C%E3%83%BC%E3%83%AB%E3%81%8C%E3%83%90%E3%82%A6%E3%83%B3%E3%83%89%E3%81%97%E3%81%A6%E4%B8%8A%E3%81%8C%E3%81%A3%E3%81%A6%E3%81%8F%E3%82%8B%E3%81%A8%E3%81%93%E3%82%8D%E3%82%92%E6%89%93%E3%81%A4%E3%80%82)
^ja-Q0312-answer

**ja-Q0313** — 彼には二度と会いたくない。

I don't want to see him again.

Expected form: **と**

Why: Quotation and accompaniment と. [[Japanese#^ja-Q0313|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%AB%E3%81%AF%E4%BA%8C%E5%BA%A6%E3%81%A8%E4%BC%9A%E3%81%84%E3%81%9F%E3%81%8F%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0313-answer

**ja-Q0314** — 彼には二度と会いたくない。

I don't want to see him again.

Expected form: **と**

Why: Quotation and accompaniment と. [[Japanese#^ja-Q0314|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%AB%E3%81%AF%E4%BA%8C%E5%BA%A6%E3%81%A8%E4%BC%9A%E3%81%84%E3%81%9F%E3%81%8F%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0314-answer

**ja-Q0315** — 手がすべって皿を床におとしてしまった。

The plate slipped from my hands and fell to the floor.

Expected form: **と**

Why: Quotation and accompaniment と. [[Japanese#^ja-Q0315|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%89%8B%E3%81%8C%E3%81%99%E3%81%B9%E3%81%A3%E3%81%A6%E7%9A%BF%E3%82%92%E5%BA%8A%E3%81%AB%E3%81%8A%E3%81%A8%E3%81%97%E3%81%A6%E3%81%97%E3%81%BE%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0315-answer

**ja-Q0316** — 手がすべって皿を床におとしてしまった。

The plate slipped from my hands and fell to the floor.

Why: Quotation and accompaniment と. [[Japanese#^ja-Q0316|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%89%8B%E3%81%8C%E3%81%99%E3%81%B9%E3%81%A3%E3%81%A6%E7%9A%BF%E3%82%92%E5%BA%8A%E3%81%AB%E3%81%8A%E3%81%A8%E3%81%97%E3%81%A6%E3%81%97%E3%81%BE%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0316-answer

**ja-Q0317** — 門のところにいる老婦人を知っていますか。

Do you know the old lady at the gate?

Why: Quotation and accompaniment と. [[Japanese#^ja-Q0317|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E9%96%80%E3%81%AE%E3%81%A8%E3%81%93%E3%82%8D%E3%81%AB%E3%81%84%E3%82%8B%E8%80%81%E5%A9%A6%E4%BA%BA%E3%82%92%E7%9F%A5%E3%81%A3%E3%81%A6%E3%81%84%E3%81%BE%E3%81%99%E3%81%8B%E3%80%82)
^ja-Q0317-answer

**ja-Q0318** — 門のところにいる老婦人を知っていますか。

Do you know the old lady at the gate?

と links an exhaustive noun list, marks accompaniment, quotes content and occurs in a conditional pattern. Its role depends on what follows.

Why: Quotation and accompaniment と. [[Japanese#^ja-Q0318|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E9%96%80%E3%81%AE%E3%81%A8%E3%81%93%E3%82%8D%E3%81%AB%E3%81%84%E3%82%8B%E8%80%81%E5%A9%A6%E4%BA%BA%E3%82%92%E7%9F%A5%E3%81%A3%E3%81%A6%E3%81%84%E3%81%BE%E3%81%99%E3%81%8B%E3%80%82)
^ja-Q0318-answer

**ja-Q0319** — 彼は私に攻撃的な態度をとった。

He assumed an aggressive attitude toward me.

Expected form: **と**

Why: Quotation and accompaniment と. [[Japanese#^ja-Q0319|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%AF%E7%A7%81%E3%81%AB%E6%94%BB%E6%92%83%E7%9A%84%E3%81%AA%E6%85%8B%E5%BA%A6%E3%82%92%E3%81%A8%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0319-answer

**ja-Q0320** — 彼は私に攻撃的な態度をとった。

He assumed an aggressive attitude toward me.

Expected form: **と**

Why: Quotation and accompaniment と. [[Japanese#^ja-Q0320|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%AF%E7%A7%81%E3%81%AB%E6%94%BB%E6%92%83%E7%9A%84%E3%81%AA%E6%85%8B%E5%BA%A6%E3%82%92%E3%81%A8%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0320-answer

**ja-Q0321** — 明日彼と話をするのを忘れてはいけませんよ。

Don't forget to talk with him tomorrow.

Expected form: **と**

Why: Quotation and accompaniment と. [[Japanese#^ja-Q0321|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%98%8E%E6%97%A5%E5%BD%BC%E3%81%A8%E8%A9%B1%E3%82%92%E3%81%99%E3%82%8B%E3%81%AE%E3%82%92%E5%BF%98%E3%82%8C%E3%81%A6%E3%81%AF%E3%81%84%E3%81%91%E3%81%BE%E3%81%9B%E3%82%93%E3%82%88%E3%80%82)
^ja-Q0321-answer

**ja-Q0322** — 明日彼と話をするのを忘れてはいけませんよ。

Don't forget to talk with him tomorrow.

Why: Quotation and accompaniment と. [[Japanese#^ja-Q0322|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%98%8E%E6%97%A5%E5%BD%BC%E3%81%A8%E8%A9%B1%E3%82%92%E3%81%99%E3%82%8B%E3%81%AE%E3%82%92%E5%BF%98%E3%82%8C%E3%81%A6%E3%81%AF%E3%81%84%E3%81%91%E3%81%BE%E3%81%9B%E3%82%93%E3%82%88%E3%80%82)
^ja-Q0322-answer

**ja-Q0323** — その事故の写真を見るとむかつく。

The picture of the accident makes me sick.

Why: Quotation and accompaniment と. [[Japanese#^ja-Q0323|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%9D%E3%81%AE%E4%BA%8B%E6%95%85%E3%81%AE%E5%86%99%E7%9C%9F%E3%82%92%E8%A6%8B%E3%82%8B%E3%81%A8%E3%82%80%E3%81%8B%E3%81%A4%E3%81%8F%E3%80%82)
^ja-Q0323-answer

**ja-Q0324** — その事故の写真を見るとむかつく。

The picture of the accident makes me sick.

と links an exhaustive noun list, marks accompaniment, quotes content and occurs in a conditional pattern. Its role depends on what follows.

Why: Quotation and accompaniment と. [[Japanese#^ja-Q0324|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%9D%E3%81%AE%E4%BA%8B%E6%95%85%E3%81%AE%E5%86%99%E7%9C%9F%E3%82%92%E8%A6%8B%E3%82%8B%E3%81%A8%E3%82%80%E3%81%8B%E3%81%A4%E3%81%8F%E3%80%82)
^ja-Q0324-answer

**ja-Q0325** — 彼らの息子はエドワードと名づけられた。

Their boy was named Edward.

Expected form: **と**

Why: Quotation and accompaniment と. [[Japanese#^ja-Q0325|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%82%89%E3%81%AE%E6%81%AF%E5%AD%90%E3%81%AF%E3%82%A8%E3%83%89%E3%83%AF%E3%83%BC%E3%83%89%E3%81%A8%E5%90%8D%E3%81%A5%E3%81%91%E3%82%89%E3%82%8C%E3%81%9F%E3%80%82)
^ja-Q0325-answer

**ja-Q0326** — 彼らの息子はエドワードと名づけられた。

Their boy was named Edward.

Expected form: **と**

Why: Quotation and accompaniment と. [[Japanese#^ja-Q0326|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%82%89%E3%81%AE%E6%81%AF%E5%AD%90%E3%81%AF%E3%82%A8%E3%83%89%E3%83%AF%E3%83%BC%E3%83%89%E3%81%A8%E5%90%8D%E3%81%A5%E3%81%91%E3%82%89%E3%82%8C%E3%81%9F%E3%80%82)
^ja-Q0326-answer

**ja-Q0327** — 朝食に何をとりましたか。

What did you eat for breakfast?

Expected form: **と**

Why: Quotation and accompaniment と. [[Japanese#^ja-Q0327|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%9C%9D%E9%A3%9F%E3%81%AB%E4%BD%95%E3%82%92%E3%81%A8%E3%82%8A%E3%81%BE%E3%81%97%E3%81%9F%E3%81%8B%E3%80%82)
^ja-Q0327-answer

**ja-Q0328** — 朝食に何をとりましたか。

What did you eat for breakfast?

Why: Quotation and accompaniment と. [[Japanese#^ja-Q0328|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%9C%9D%E9%A3%9F%E3%81%AB%E4%BD%95%E3%82%92%E3%81%A8%E3%82%8A%E3%81%BE%E3%81%97%E3%81%9F%E3%81%8B%E3%80%82)
^ja-Q0328-answer

**ja-Q0329** — ウラウラとした日差しに誘われて、眠りに落ちた。

The soft gentle sunlight beckoned me off to sleep.

Why: Quotation and accompaniment と. [[Japanese#^ja-Q0329|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%82%A6%E3%83%A9%E3%82%A6%E3%83%A9%E3%81%A8%E3%81%97%E3%81%9F%E6%97%A5%E5%B7%AE%E3%81%97%E3%81%AB%E8%AA%98%E3%82%8F%E3%82%8C%E3%81%A6%E3%80%81%E7%9C%A0%E3%82%8A%E3%81%AB%E8%90%BD%E3%81%A1%E3%81%9F%E3%80%82)
^ja-Q0329-answer

**ja-Q0330** — ウラウラとした日差しに誘われて、眠りに落ちた。

The soft gentle sunlight beckoned me off to sleep.

と links an exhaustive noun list, marks accompaniment, quotes content and occurs in a conditional pattern. Its role depends on what follows.

Why: Quotation and accompaniment と. [[Japanese#^ja-Q0330|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%82%A6%E3%83%A9%E3%82%A6%E3%83%A9%E3%81%A8%E3%81%97%E3%81%9F%E6%97%A5%E5%B7%AE%E3%81%97%E3%81%AB%E8%AA%98%E3%82%8F%E3%82%8C%E3%81%A6%E3%80%81%E7%9C%A0%E3%82%8A%E3%81%AB%E8%90%BD%E3%81%A1%E3%81%9F%E3%80%82)
^ja-Q0330-answer

**ja-Q0331** — その小さな犬は逃げようとしました。

The small dog tried to get away.

Expected form: **と**

Why: Quotation and accompaniment と. [[Japanese#^ja-Q0331|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%9D%E3%81%AE%E5%B0%8F%E3%81%95%E3%81%AA%E7%8A%AC%E3%81%AF%E9%80%83%E3%81%92%E3%82%88%E3%81%86%E3%81%A8%E3%81%97%E3%81%BE%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0331-answer

**ja-Q0332** — その小さな犬は逃げようとしました。

The small dog tried to get away.

Expected form: **と**

Why: Quotation and accompaniment と. [[Japanese#^ja-Q0332|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%9D%E3%81%AE%E5%B0%8F%E3%81%95%E3%81%AA%E7%8A%AC%E3%81%AF%E9%80%83%E3%81%92%E3%82%88%E3%81%86%E3%81%A8%E3%81%97%E3%81%BE%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0332-answer

**ja-Q0333** — いろいろとコツがわかってきたときに仕事を辞めなければいけなかったのは残念だ。

It's a shame that I had to quit my job just when I was getting the hang of things.

Expected form: **と**

Why: Quotation and accompaniment と. [[Japanese#^ja-Q0333|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%84%E3%82%8D%E3%81%84%E3%82%8D%E3%81%A8%E3%82%B3%E3%83%84%E3%81%8C%E3%82%8F%E3%81%8B%E3%81%A3%E3%81%A6%E3%81%8D%E3%81%9F%E3%81%A8%E3%81%8D%E3%81%AB%E4%BB%95%E4%BA%8B%E3%82%92%E8%BE%9E%E3%82%81%E3%81%AA%E3%81%91%E3%82%8C%E3%81%B0%E3%81%84%E3%81%91%E3%81%AA%E3%81%8B%E3%81%A3%E3%81%9F%E3%81%AE%E3%81%AF%E6%AE%8B%E5%BF%B5%E3%81%A0%E3%80%82)
^ja-Q0333-answer

**ja-Q0334** — いろいろとコツがわかってきたときに仕事を辞めなければいけなかったのは残念だ。

It's a shame that I had to quit my job just when I was getting the hang of things.

Why: Quotation and accompaniment と. [[Japanese#^ja-Q0334|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%84%E3%82%8D%E3%81%84%E3%82%8D%E3%81%A8%E3%82%B3%E3%83%84%E3%81%8C%E3%82%8F%E3%81%8B%E3%81%A3%E3%81%A6%E3%81%8D%E3%81%9F%E3%81%A8%E3%81%8D%E3%81%AB%E4%BB%95%E4%BA%8B%E3%82%92%E8%BE%9E%E3%82%81%E3%81%AA%E3%81%91%E3%82%8C%E3%81%B0%E3%81%84%E3%81%91%E3%81%AA%E3%81%8B%E3%81%A3%E3%81%9F%E3%81%AE%E3%81%AF%E6%AE%8B%E5%BF%B5%E3%81%A0%E3%80%82)
^ja-Q0334-answer

**ja-Q0335** — ヘレン・ムーディーはテニスの選手として、職業上感情を表さない人として有名だった。

Helen Moody was noted as a tennis player for not showing any expression on the court.

Why: Quotation and accompaniment と. [[Japanese#^ja-Q0335|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%83%98%E3%83%AC%E3%83%B3%E3%83%BB%E3%83%A0%E3%83%BC%E3%83%87%E3%82%A3%E3%83%BC%E3%81%AF%E3%83%86%E3%83%8B%E3%82%B9%E3%81%AE%E9%81%B8%E6%89%8B%E3%81%A8%E3%81%97%E3%81%A6%E3%80%81%E8%81%B7%E6%A5%AD%E4%B8%8A%E6%84%9F%E6%83%85%E3%82%92%E8%A1%A8%E3%81%95%E3%81%AA%E3%81%84%E4%BA%BA%E3%81%A8%E3%81%97%E3%81%A6%E6%9C%89%E5%90%8D%E3%81%A0%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0335-answer

**ja-Q0336** — ヘレン・ムーディーはテニスの選手として、職業上感情を表さない人として有名だった。

Helen Moody was noted as a tennis player for not showing any expression on the court.

と links an exhaustive noun list, marks accompaniment, quotes content and occurs in a conditional pattern. Its role depends on what follows.

Why: Quotation and accompaniment と. [[Japanese#^ja-Q0336|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%83%98%E3%83%AC%E3%83%B3%E3%83%BB%E3%83%A0%E3%83%BC%E3%83%87%E3%82%A3%E3%83%BC%E3%81%AF%E3%83%86%E3%83%8B%E3%82%B9%E3%81%AE%E9%81%B8%E6%89%8B%E3%81%A8%E3%81%97%E3%81%A6%E3%80%81%E8%81%B7%E6%A5%AD%E4%B8%8A%E6%84%9F%E6%83%85%E3%82%92%E8%A1%A8%E3%81%95%E3%81%AA%E3%81%84%E4%BA%BA%E3%81%A8%E3%81%97%E3%81%A6%E6%9C%89%E5%90%8D%E3%81%A0%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0336-answer

**ja-Q0337** — ジェントルマンとは独立した財産のある人のことだ。

A gentleman is a man of independent means.

Expected form: **と**

Why: Quotation and accompaniment と. [[Japanese#^ja-Q0337|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%82%B8%E3%82%A7%E3%83%B3%E3%83%88%E3%83%AB%E3%83%9E%E3%83%B3%E3%81%A8%E3%81%AF%E7%8B%AC%E7%AB%8B%E3%81%97%E3%81%9F%E8%B2%A1%E7%94%A3%E3%81%AE%E3%81%82%E3%82%8B%E4%BA%BA%E3%81%AE%E3%81%93%E3%81%A8%E3%81%A0%E3%80%82)
^ja-Q0337-answer

**ja-Q0338** — ジェントルマンとは独立した財産のある人のことだ。

A gentleman is a man of independent means.

Expected form: **と**

Why: Quotation and accompaniment と. [[Japanese#^ja-Q0338|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%82%B8%E3%82%A7%E3%83%B3%E3%83%88%E3%83%AB%E3%83%9E%E3%83%B3%E3%81%A8%E3%81%AF%E7%8B%AC%E7%AB%8B%E3%81%97%E3%81%9F%E8%B2%A1%E7%94%A3%E3%81%AE%E3%81%82%E3%82%8B%E4%BA%BA%E3%81%AE%E3%81%93%E3%81%A8%E3%81%A0%E3%80%82)
^ja-Q0338-answer

**ja-Q0339** — 私が抱えた問題は、私のするタイプが気に入らなかった人との関係だけよ。

The only trouble I've ever had was dealing with people who didn't like my personality.

Expected form: **と**

Why: Quotation and accompaniment と. [[Japanese#^ja-Q0339|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%8C%E6%8A%B1%E3%81%88%E3%81%9F%E5%95%8F%E9%A1%8C%E3%81%AF%E3%80%81%E7%A7%81%E3%81%AE%E3%81%99%E3%82%8B%E3%82%BF%E3%82%A4%E3%83%97%E3%81%8C%E6%B0%97%E3%81%AB%E5%85%A5%E3%82%89%E3%81%AA%E3%81%8B%E3%81%A3%E3%81%9F%E4%BA%BA%E3%81%A8%E3%81%AE%E9%96%A2%E4%BF%82%E3%81%A0%E3%81%91%E3%82%88%E3%80%82)
^ja-Q0339-answer

**ja-Q0340** — 私が抱えた問題は、私のするタイプが気に入らなかった人との関係だけよ。

The only trouble I've ever had was dealing with people who didn't like my personality.

Why: Quotation and accompaniment と. [[Japanese#^ja-Q0340|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%8C%E6%8A%B1%E3%81%88%E3%81%9F%E5%95%8F%E9%A1%8C%E3%81%AF%E3%80%81%E7%A7%81%E3%81%AE%E3%81%99%E3%82%8B%E3%82%BF%E3%82%A4%E3%83%97%E3%81%8C%E6%B0%97%E3%81%AB%E5%85%A5%E3%82%89%E3%81%AA%E3%81%8B%E3%81%A3%E3%81%9F%E4%BA%BA%E3%81%A8%E3%81%AE%E9%96%A2%E4%BF%82%E3%81%A0%E3%81%91%E3%82%88%E3%80%82)
^ja-Q0340-answer

**ja-Q0341** — その少年は数学が得意であったので、皆は彼を天才と思った。

The boy was good at mathematics so everybody considered him a genius.

Why: Quotation and accompaniment と. [[Japanese#^ja-Q0341|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%9D%E3%81%AE%E5%B0%91%E5%B9%B4%E3%81%AF%E6%95%B0%E5%AD%A6%E3%81%8C%E5%BE%97%E6%84%8F%E3%81%A7%E3%81%82%E3%81%A3%E3%81%9F%E3%81%AE%E3%81%A7%E3%80%81%E7%9A%86%E3%81%AF%E5%BD%BC%E3%82%92%E5%A4%A9%E6%89%8D%E3%81%A8%E6%80%9D%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0341-answer

**ja-Q0342** — その少年は数学が得意であったので、皆は彼を天才と思った。

The boy was good at mathematics so everybody considered him a genius.

と links an exhaustive noun list, marks accompaniment, quotes content and occurs in a conditional pattern. Its role depends on what follows.

Why: Quotation and accompaniment と. [[Japanese#^ja-Q0342|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%9D%E3%81%AE%E5%B0%91%E5%B9%B4%E3%81%AF%E6%95%B0%E5%AD%A6%E3%81%8C%E5%BE%97%E6%84%8F%E3%81%A7%E3%81%82%E3%81%A3%E3%81%9F%E3%81%AE%E3%81%A7%E3%80%81%E7%9A%86%E3%81%AF%E5%BD%BC%E3%82%92%E5%A4%A9%E6%89%8D%E3%81%A8%E6%80%9D%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0342-answer

**ja-Q0343** — タクシーは信号のところで急停車した。

The taxi stopped dead at the traffic signal.

Expected form: **と**

Why: Quotation and accompaniment と. [[Japanese#^ja-Q0343|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%82%BF%E3%82%AF%E3%82%B7%E3%83%BC%E3%81%AF%E4%BF%A1%E5%8F%B7%E3%81%AE%E3%81%A8%E3%81%93%E3%82%8D%E3%81%A7%E6%80%A5%E5%81%9C%E8%BB%8A%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0343-answer

**ja-Q0344** — タクシーは信号のところで急停車した。

The taxi stopped dead at the traffic signal.

Expected form: **と**

Why: Quotation and accompaniment と. [[Japanese#^ja-Q0344|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%82%BF%E3%82%AF%E3%82%B7%E3%83%BC%E3%81%AF%E4%BF%A1%E5%8F%B7%E3%81%AE%E3%81%A8%E3%81%93%E3%82%8D%E3%81%A7%E6%80%A5%E5%81%9C%E8%BB%8A%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0344-answer

**ja-Q0345** — エドワードはキャシーの目をじっと見て本気でそう言っているのか尋ねた。

Edward looked Kathy in the eye and asked her if she really meant what she said.

Expected form: **と**

Why: Quotation and accompaniment と. [[Japanese#^ja-Q0345|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%82%A8%E3%83%89%E3%83%AF%E3%83%BC%E3%83%89%E3%81%AF%E3%82%AD%E3%83%A3%E3%82%B7%E3%83%BC%E3%81%AE%E7%9B%AE%E3%82%92%E3%81%98%E3%81%A3%E3%81%A8%E8%A6%8B%E3%81%A6%E6%9C%AC%E6%B0%97%E3%81%A7%E3%81%9D%E3%81%86%E8%A8%80%E3%81%A3%E3%81%A6%E3%81%84%E3%82%8B%E3%81%AE%E3%81%8B%E5%B0%8B%E3%81%AD%E3%81%9F%E3%80%82)
^ja-Q0345-answer

**ja-Q0346** — エドワードはキャシーの目をじっと見て本気でそう言っているのか尋ねた。

Edward looked Kathy in the eye and asked her if she really meant what she said.

Why: Quotation and accompaniment と. [[Japanese#^ja-Q0346|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%82%A8%E3%83%89%E3%83%AF%E3%83%BC%E3%83%89%E3%81%AF%E3%82%AD%E3%83%A3%E3%82%B7%E3%83%BC%E3%81%AE%E7%9B%AE%E3%82%92%E3%81%98%E3%81%A3%E3%81%A8%E8%A6%8B%E3%81%A6%E6%9C%AC%E6%B0%97%E3%81%A7%E3%81%9D%E3%81%86%E8%A8%80%E3%81%A3%E3%81%A6%E3%81%84%E3%82%8B%E3%81%AE%E3%81%8B%E5%B0%8B%E3%81%AD%E3%81%9F%E3%80%82)
^ja-Q0346-answer

**ja-Q0347** — 教室はやっと暖かくなった。

The classroom has finally warmed up.

Why: Quotation and accompaniment と. [[Japanese#^ja-Q0347|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%95%99%E5%AE%A4%E3%81%AF%E3%82%84%E3%81%A3%E3%81%A8%E6%9A%96%E3%81%8B%E3%81%8F%E3%81%AA%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0347-answer

**ja-Q0348** — 教室はやっと暖かくなった。

The classroom has finally warmed up.

と links an exhaustive noun list, marks accompaniment, quotes content and occurs in a conditional pattern. Its role depends on what follows.

Why: Quotation and accompaniment と. [[Japanese#^ja-Q0348|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%95%99%E5%AE%A4%E3%81%AF%E3%82%84%E3%81%A3%E3%81%A8%E6%9A%96%E3%81%8B%E3%81%8F%E3%81%AA%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0348-answer

**ja-Q0349** — 改めて反芻してると、何だか恥ずかしいぞ。

Now that I think over it, it's somewhat embarrassing.

Expected form: **と**

Why: Quotation and accompaniment と. [[Japanese#^ja-Q0349|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%94%B9%E3%82%81%E3%81%A6%E5%8F%8D%E8%8A%BB%E3%81%97%E3%81%A6%E3%82%8B%E3%81%A8%E3%80%81%E4%BD%95%E3%81%A0%E3%81%8B%E6%81%A5%E3%81%9A%E3%81%8B%E3%81%97%E3%81%84%E3%81%9E%E3%80%82)
^ja-Q0349-answer

**ja-Q0350** — 改めて反芻してると、何だか恥ずかしいぞ。

Now that I think over it, it's somewhat embarrassing.

Expected form: **と**

Why: Quotation and accompaniment と. [[Japanese#^ja-Q0350|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%94%B9%E3%82%81%E3%81%A6%E5%8F%8D%E8%8A%BB%E3%81%97%E3%81%A6%E3%82%8B%E3%81%A8%E3%80%81%E4%BD%95%E3%81%A0%E3%81%8B%E6%81%A5%E3%81%9A%E3%81%8B%E3%81%97%E3%81%84%E3%81%9E%E3%80%82)
^ja-Q0350-answer


### Answers 351–400

**ja-Q0351** — 金は鉄よりも貴重だ。

Gold is more precious than iron.

Expected form: **も**

Why: Inclusion も. [[Japanese#^ja-Q0351|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E9%87%91%E3%81%AF%E9%89%84%E3%82%88%E3%82%8A%E3%82%82%E8%B2%B4%E9%87%8D%E3%81%A0%E3%80%82)
^ja-Q0351-answer

**ja-Q0352** — 金は鉄よりも貴重だ。

Gold is more precious than iron.

Why: Inclusion も. [[Japanese#^ja-Q0352|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E9%87%91%E3%81%AF%E9%89%84%E3%82%88%E3%82%8A%E3%82%82%E8%B2%B4%E9%87%8D%E3%81%A0%E3%80%82)
^ja-Q0352-answer

**ja-Q0353** — 街はクリスマスムード一色・・・もうじきイブだ。

The streets are in full Christmas mode - it's almost Christmas Eve.

Why: Inclusion も. [[Japanese#^ja-Q0353|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E8%A1%97%E3%81%AF%E3%82%AF%E3%83%AA%E3%82%B9%E3%83%9E%E3%82%B9%E3%83%A0%E3%83%BC%E3%83%89%E4%B8%80%E8%89%B2%E3%83%BB%E3%83%BB%E3%83%BB%E3%82%82%E3%81%86%E3%81%98%E3%81%8D%E3%82%A4%E3%83%96%E3%81%A0%E3%80%82)
^ja-Q0353-answer

**ja-Q0354** — 街はクリスマスムード一色・・・もうじきイブだ。

The streets are in full Christmas mode - it's almost Christmas Eve.

も often means also/even and replaces or combines with another marker. In negative quantity expressions it can help convey not even/none. The scope is set by the phrase it follows.

Why: Inclusion も. [[Japanese#^ja-Q0354|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E8%A1%97%E3%81%AF%E3%82%AF%E3%83%AA%E3%82%B9%E3%83%9E%E3%82%B9%E3%83%A0%E3%83%BC%E3%83%89%E4%B8%80%E8%89%B2%E3%83%BB%E3%83%BB%E3%83%BB%E3%82%82%E3%81%86%E3%81%98%E3%81%8D%E3%82%A4%E3%83%96%E3%81%A0%E3%80%82)
^ja-Q0354-answer

**ja-Q0355** — 友達に２０年も会ってない。

I hadn't seen my friend for over twenty years.

Expected form: **も**

Why: Inclusion も. [[Japanese#^ja-Q0355|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%8F%8B%E9%81%94%E3%81%AB%EF%BC%92%EF%BC%90%E5%B9%B4%E3%82%82%E4%BC%9A%E3%81%A3%E3%81%A6%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0355-answer

**ja-Q0356** — 友達に２０年も会ってない。

I hadn't seen my friend for over twenty years.

Expected form: **も**

Why: Inclusion も. [[Japanese#^ja-Q0356|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%8F%8B%E9%81%94%E3%81%AB%EF%BC%92%EF%BC%90%E5%B9%B4%E3%82%82%E4%BC%9A%E3%81%A3%E3%81%A6%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0356-answer

**ja-Q0357** — トムも来なかったしジェーンも来なかった。

Tom didn't come, nor did Jane.

Expected form: **も**

Why: Inclusion も. [[Japanese#^ja-Q0357|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%83%88%E3%83%A0%E3%82%82%E6%9D%A5%E3%81%AA%E3%81%8B%E3%81%A3%E3%81%9F%E3%81%97%E3%82%B8%E3%82%A7%E3%83%BC%E3%83%B3%E3%82%82%E6%9D%A5%E3%81%AA%E3%81%8B%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0357-answer

**ja-Q0358** — トムも来なかったしジェーンも来なかった。

Tom didn't come, nor did Jane.

Why: Inclusion も. [[Japanese#^ja-Q0358|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%83%88%E3%83%A0%E3%82%82%E6%9D%A5%E3%81%AA%E3%81%8B%E3%81%A3%E3%81%9F%E3%81%97%E3%82%B8%E3%82%A7%E3%83%BC%E3%83%B3%E3%82%82%E6%9D%A5%E3%81%AA%E3%81%8B%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0358-answer

**ja-Q0359** — もし太陽が輝かなくなれば、生物は皆死ぬだろう。

If the sun were to stop shining, all living things would die.

Why: Inclusion も. [[Japanese#^ja-Q0359|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%82%82%E3%81%97%E5%A4%AA%E9%99%BD%E3%81%8C%E8%BC%9D%E3%81%8B%E3%81%AA%E3%81%8F%E3%81%AA%E3%82%8C%E3%81%B0%E3%80%81%E7%94%9F%E7%89%A9%E3%81%AF%E7%9A%86%E6%AD%BB%E3%81%AC%E3%81%A0%E3%82%8D%E3%81%86%E3%80%82)
^ja-Q0359-answer

**ja-Q0360** — もし太陽が輝かなくなれば、生物は皆死ぬだろう。

If the sun were to stop shining, all living things would die.

も often means also/even and replaces or combines with another marker. In negative quantity expressions it can help convey not even/none. The scope is set by the phrase it follows.

Why: Inclusion も. [[Japanese#^ja-Q0360|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%82%82%E3%81%97%E5%A4%AA%E9%99%BD%E3%81%8C%E8%BC%9D%E3%81%8B%E3%81%AA%E3%81%8F%E3%81%AA%E3%82%8C%E3%81%B0%E3%80%81%E7%94%9F%E7%89%A9%E3%81%AF%E7%9A%86%E6%AD%BB%E3%81%AC%E3%81%A0%E3%82%8D%E3%81%86%E3%80%82)
^ja-Q0360-answer

**ja-Q0361** — 両親はどちらも娘の捜索に力を注いだんです。

Both of the parents did try hard in search of their daughter.

Expected form: **も**

Why: Inclusion も. [[Japanese#^ja-Q0361|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E4%B8%A1%E8%A6%AA%E3%81%AF%E3%81%A9%E3%81%A1%E3%82%89%E3%82%82%E5%A8%98%E3%81%AE%E6%8D%9C%E7%B4%A2%E3%81%AB%E5%8A%9B%E3%82%92%E6%B3%A8%E3%81%84%E3%81%A0%E3%82%93%E3%81%A7%E3%81%99%E3%80%82)
^ja-Q0361-answer

**ja-Q0362** — 両親はどちらも娘の捜索に力を注いだんです。

Both of the parents did try hard in search of their daughter.

Expected form: **も**

Why: Inclusion も. [[Japanese#^ja-Q0362|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E4%B8%A1%E8%A6%AA%E3%81%AF%E3%81%A9%E3%81%A1%E3%82%89%E3%82%82%E5%A8%98%E3%81%AE%E6%8D%9C%E7%B4%A2%E3%81%AB%E5%8A%9B%E3%82%92%E6%B3%A8%E3%81%84%E3%81%A0%E3%82%93%E3%81%A7%E3%81%99%E3%80%82)
^ja-Q0362-answer

**ja-Q0363** — 彼は勇敢にもそのスキャンダルを暴露した。

He had the courage to expose the scandal.

Expected form: **も**

Why: Inclusion も. [[Japanese#^ja-Q0363|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%AF%E5%8B%87%E6%95%A2%E3%81%AB%E3%82%82%E3%81%9D%E3%81%AE%E3%82%B9%E3%82%AD%E3%83%A3%E3%83%B3%E3%83%80%E3%83%AB%E3%82%92%E6%9A%B4%E9%9C%B2%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0363-answer

**ja-Q0364** — 彼は勇敢にもそのスキャンダルを暴露した。

He had the courage to expose the scandal.

Why: Inclusion も. [[Japanese#^ja-Q0364|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%AF%E5%8B%87%E6%95%A2%E3%81%AB%E3%82%82%E3%81%9D%E3%81%AE%E3%82%B9%E3%82%AD%E3%83%A3%E3%83%B3%E3%83%80%E3%83%AB%E3%82%92%E6%9A%B4%E9%9C%B2%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0364-answer

**ja-Q0365** — １週間の休暇を取っても良い事になった。

I was allowed to take a week off.

Why: Inclusion も. [[Japanese#^ja-Q0365|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%EF%BC%91%E9%80%B1%E9%96%93%E3%81%AE%E4%BC%91%E6%9A%87%E3%82%92%E5%8F%96%E3%81%A3%E3%81%A6%E3%82%82%E8%89%AF%E3%81%84%E4%BA%8B%E3%81%AB%E3%81%AA%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0365-answer

**ja-Q0366** — １週間の休暇を取っても良い事になった。

I was allowed to take a week off.

も often means also/even and replaces or combines with another marker. In negative quantity expressions it can help convey not even/none. The scope is set by the phrase it follows.

Why: Inclusion も. [[Japanese#^ja-Q0366|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%EF%BC%91%E9%80%B1%E9%96%93%E3%81%AE%E4%BC%91%E6%9A%87%E3%82%92%E5%8F%96%E3%81%A3%E3%81%A6%E3%82%82%E8%89%AF%E3%81%84%E4%BA%8B%E3%81%AB%E3%81%AA%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0366-answer

**ja-Q0367** — あなたたちはいつも完全である必要はありません。

You don't have to be perfect all the time.

Expected form: **も**

Why: Inclusion も. [[Japanese#^ja-Q0367|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%82%E3%81%AA%E3%81%9F%E3%81%9F%E3%81%A1%E3%81%AF%E3%81%84%E3%81%A4%E3%82%82%E5%AE%8C%E5%85%A8%E3%81%A7%E3%81%82%E3%82%8B%E5%BF%85%E8%A6%81%E3%81%AF%E3%81%82%E3%82%8A%E3%81%BE%E3%81%9B%E3%82%93%E3%80%82)
^ja-Q0367-answer

**ja-Q0368** — あなたたちはいつも完全である必要はありません。

You don't have to be perfect all the time.

Expected form: **も**

Why: Inclusion も. [[Japanese#^ja-Q0368|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%82%E3%81%AA%E3%81%9F%E3%81%9F%E3%81%A1%E3%81%AF%E3%81%84%E3%81%A4%E3%82%82%E5%AE%8C%E5%85%A8%E3%81%A7%E3%81%82%E3%82%8B%E5%BF%85%E8%A6%81%E3%81%AF%E3%81%82%E3%82%8A%E3%81%BE%E3%81%9B%E3%82%93%E3%80%82)
^ja-Q0368-answer

**ja-Q0369** — 兄は何度も試験に挑戦して、最後には合格した。

My brother tried many times to pass the examination, finally succeeding.

Expected form: **も**

Why: Inclusion も. [[Japanese#^ja-Q0369|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%85%84%E3%81%AF%E4%BD%95%E5%BA%A6%E3%82%82%E8%A9%A6%E9%A8%93%E3%81%AB%E6%8C%91%E6%88%A6%E3%81%97%E3%81%A6%E3%80%81%E6%9C%80%E5%BE%8C%E3%81%AB%E3%81%AF%E5%90%88%E6%A0%BC%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0369-answer

**ja-Q0370** — 兄は何度も試験に挑戦して、最後には合格した。

My brother tried many times to pass the examination, finally succeeding.

Why: Inclusion も. [[Japanese#^ja-Q0370|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%85%84%E3%81%AF%E4%BD%95%E5%BA%A6%E3%82%82%E8%A9%A6%E9%A8%93%E3%81%AB%E6%8C%91%E6%88%A6%E3%81%97%E3%81%A6%E3%80%81%E6%9C%80%E5%BE%8C%E3%81%AB%E3%81%AF%E5%90%88%E6%A0%BC%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0370-answer

**ja-Q0371** — なるほど私が間違ってるかもしれない。

I may indeed be wrong.

Why: Inclusion も. [[Japanese#^ja-Q0371|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%AA%E3%82%8B%E3%81%BB%E3%81%A9%E7%A7%81%E3%81%8C%E9%96%93%E9%81%95%E3%81%A3%E3%81%A6%E3%82%8B%E3%81%8B%E3%82%82%E3%81%97%E3%82%8C%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0371-answer

**ja-Q0372** — なるほど私が間違ってるかもしれない。

I may indeed be wrong.

も often means also/even and replaces or combines with another marker. In negative quantity expressions it can help convey not even/none. The scope is set by the phrase it follows.

Why: Inclusion も. [[Japanese#^ja-Q0372|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%AA%E3%82%8B%E3%81%BB%E3%81%A9%E7%A7%81%E3%81%8C%E9%96%93%E9%81%95%E3%81%A3%E3%81%A6%E3%82%8B%E3%81%8B%E3%82%82%E3%81%97%E3%82%8C%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0372-answer

**ja-Q0373** — 東京での生活費はとても高い。

The cost of living is very high in Tokyo.

Expected form: **も**

Why: Inclusion も. [[Japanese#^ja-Q0373|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%9D%B1%E4%BA%AC%E3%81%A7%E3%81%AE%E7%94%9F%E6%B4%BB%E8%B2%BB%E3%81%AF%E3%81%A8%E3%81%A6%E3%82%82%E9%AB%98%E3%81%84%E3%80%82)
^ja-Q0373-answer

**ja-Q0374** — 東京での生活費はとても高い。

The cost of living is very high in Tokyo.

Expected form: **も**

Why: Inclusion も. [[Japanese#^ja-Q0374|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%9D%B1%E4%BA%AC%E3%81%A7%E3%81%AE%E7%94%9F%E6%B4%BB%E8%B2%BB%E3%81%AF%E3%81%A8%E3%81%A6%E3%82%82%E9%AB%98%E3%81%84%E3%80%82)
^ja-Q0374-answer

**ja-Q0375** — 彼は終電に乗り遅れたのかもしれない。

He may have missed the last train.

Expected form: **も**

Why: Inclusion も. [[Japanese#^ja-Q0375|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%AF%E7%B5%82%E9%9B%BB%E3%81%AB%E4%B9%97%E3%82%8A%E9%81%85%E3%82%8C%E3%81%9F%E3%81%AE%E3%81%8B%E3%82%82%E3%81%97%E3%82%8C%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0375-answer

**ja-Q0376** — 彼は終電に乗り遅れたのかもしれない。

He may have missed the last train.

Why: Inclusion も. [[Japanese#^ja-Q0376|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%AF%E7%B5%82%E9%9B%BB%E3%81%AB%E4%B9%97%E3%82%8A%E9%81%85%E3%82%8C%E3%81%9F%E3%81%AE%E3%81%8B%E3%82%82%E3%81%97%E3%82%8C%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0376-answer

**ja-Q0377** — ナプキンを貰ってもよろしいでしょうか？

Could I have a napkin, please?

Why: Inclusion も. [[Japanese#^ja-Q0377|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%83%8A%E3%83%97%E3%82%AD%E3%83%B3%E3%82%92%E8%B2%B0%E3%81%A3%E3%81%A6%E3%82%82%E3%82%88%E3%82%8D%E3%81%97%E3%81%84%E3%81%A7%E3%81%97%E3%82%87%E3%81%86%E3%81%8B%EF%BC%9F)
^ja-Q0377-answer

**ja-Q0378** — ナプキンを貰ってもよろしいでしょうか？

Could I have a napkin, please?

も often means also/even and replaces or combines with another marker. In negative quantity expressions it can help convey not even/none. The scope is set by the phrase it follows.

Why: Inclusion も. [[Japanese#^ja-Q0378|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%83%8A%E3%83%97%E3%82%AD%E3%83%B3%E3%82%92%E8%B2%B0%E3%81%A3%E3%81%A6%E3%82%82%E3%82%88%E3%82%8D%E3%81%97%E3%81%84%E3%81%A7%E3%81%97%E3%82%87%E3%81%86%E3%81%8B%EF%BC%9F)
^ja-Q0378-answer

**ja-Q0379** — 満腹なので、もうこれ以上食べられない。

I am full, and I can eat no more.

Expected form: **も**

Why: Inclusion も. [[Japanese#^ja-Q0379|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%BA%80%E8%85%B9%E3%81%AA%E3%81%AE%E3%81%A7%E3%80%81%E3%82%82%E3%81%86%E3%81%93%E3%82%8C%E4%BB%A5%E4%B8%8A%E9%A3%9F%E3%81%B9%E3%82%89%E3%82%8C%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0379-answer

**ja-Q0380** — 満腹なので、もうこれ以上食べられない。

I am full, and I can eat no more.

Expected form: **も**

Why: Inclusion も. [[Japanese#^ja-Q0380|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%BA%80%E8%85%B9%E3%81%AA%E3%81%AE%E3%81%A7%E3%80%81%E3%82%82%E3%81%86%E3%81%93%E3%82%8C%E4%BB%A5%E4%B8%8A%E9%A3%9F%E3%81%B9%E3%82%89%E3%82%8C%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0380-answer

**ja-Q0381** — トムは英語さえできれば世界中どこへ行っても不自由しないと思っている。

Tom believes that as long as you speak English, you'll have no problems going anywhere in the world.

Expected form: **も**

Why: Inclusion も. [[Japanese#^ja-Q0381|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%83%88%E3%83%A0%E3%81%AF%E8%8B%B1%E8%AA%9E%E3%81%95%E3%81%88%E3%81%A7%E3%81%8D%E3%82%8C%E3%81%B0%E4%B8%96%E7%95%8C%E4%B8%AD%E3%81%A9%E3%81%93%E3%81%B8%E8%A1%8C%E3%81%A3%E3%81%A6%E3%82%82%E4%B8%8D%E8%87%AA%E7%94%B1%E3%81%97%E3%81%AA%E3%81%84%E3%81%A8%E6%80%9D%E3%81%A3%E3%81%A6%E3%81%84%E3%82%8B%E3%80%82)
^ja-Q0381-answer

**ja-Q0382** — トムは英語さえできれば世界中どこへ行っても不自由しないと思っている。

Tom believes that as long as you speak English, you'll have no problems going anywhere in the world.

Why: Inclusion も. [[Japanese#^ja-Q0382|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%83%88%E3%83%A0%E3%81%AF%E8%8B%B1%E8%AA%9E%E3%81%95%E3%81%88%E3%81%A7%E3%81%8D%E3%82%8C%E3%81%B0%E4%B8%96%E7%95%8C%E4%B8%AD%E3%81%A9%E3%81%93%E3%81%B8%E8%A1%8C%E3%81%A3%E3%81%A6%E3%82%82%E4%B8%8D%E8%87%AA%E7%94%B1%E3%81%97%E3%81%AA%E3%81%84%E3%81%A8%E6%80%9D%E3%81%A3%E3%81%A6%E3%81%84%E3%82%8B%E3%80%82)
^ja-Q0382-answer

**ja-Q0383** — 今日の新聞には面白いことは何もない。

There is nothing interesting in the newspaper today.

Why: Inclusion も. [[Japanese#^ja-Q0383|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E4%BB%8A%E6%97%A5%E3%81%AE%E6%96%B0%E8%81%9E%E3%81%AB%E3%81%AF%E9%9D%A2%E7%99%BD%E3%81%84%E3%81%93%E3%81%A8%E3%81%AF%E4%BD%95%E3%82%82%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0383-answer

**ja-Q0384** — 今日の新聞には面白いことは何もない。

There is nothing interesting in the newspaper today.

も often means also/even and replaces or combines with another marker. In negative quantity expressions it can help convey not even/none. The scope is set by the phrase it follows.

Why: Inclusion も. [[Japanese#^ja-Q0384|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E4%BB%8A%E6%97%A5%E3%81%AE%E6%96%B0%E8%81%9E%E3%81%AB%E3%81%AF%E9%9D%A2%E7%99%BD%E3%81%84%E3%81%93%E3%81%A8%E3%81%AF%E4%BD%95%E3%82%82%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0384-answer

**ja-Q0385** — どんなに忙しくても、宿題はしなければならない。

However busy you may be, you must do your homework.

Expected form: **も**

Why: Inclusion も. [[Japanese#^ja-Q0385|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%A9%E3%82%93%E3%81%AA%E3%81%AB%E5%BF%99%E3%81%97%E3%81%8F%E3%81%A6%E3%82%82%E3%80%81%E5%AE%BF%E9%A1%8C%E3%81%AF%E3%81%97%E3%81%AA%E3%81%91%E3%82%8C%E3%81%B0%E3%81%AA%E3%82%89%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0385-answer

**ja-Q0386** — どんなに忙しくても、宿題はしなければならない。

However busy you may be, you must do your homework.

Expected form: **も**

Why: Inclusion も. [[Japanese#^ja-Q0386|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%A9%E3%82%93%E3%81%AA%E3%81%AB%E5%BF%99%E3%81%97%E3%81%8F%E3%81%A6%E3%82%82%E3%80%81%E5%AE%BF%E9%A1%8C%E3%81%AF%E3%81%97%E3%81%AA%E3%81%91%E3%82%8C%E3%81%B0%E3%81%AA%E3%82%89%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0386-answer

**ja-Q0387** — 彼にはその５分が５時間にも思えた。

To him those five minutes seemed like five hours.

Expected form: **も**

Why: Inclusion も. [[Japanese#^ja-Q0387|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%AB%E3%81%AF%E3%81%9D%E3%81%AE%EF%BC%95%E5%88%86%E3%81%8C%EF%BC%95%E6%99%82%E9%96%93%E3%81%AB%E3%82%82%E6%80%9D%E3%81%88%E3%81%9F%E3%80%82)
^ja-Q0387-answer

**ja-Q0388** — 彼にはその５分が５時間にも思えた。

To him those five minutes seemed like five hours.

Why: Inclusion も. [[Japanese#^ja-Q0388|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%AB%E3%81%AF%E3%81%9D%E3%81%AE%EF%BC%95%E5%88%86%E3%81%8C%EF%BC%95%E6%99%82%E9%96%93%E3%81%AB%E3%82%82%E6%80%9D%E3%81%88%E3%81%9F%E3%80%82)
^ja-Q0388-answer

**ja-Q0389** — 彼は親譲りの財産をもとにして富を作った。

He built on his father's fortune.

Why: Inclusion も. [[Japanese#^ja-Q0389|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%AF%E8%A6%AA%E8%AD%B2%E3%82%8A%E3%81%AE%E8%B2%A1%E7%94%A3%E3%82%92%E3%82%82%E3%81%A8%E3%81%AB%E3%81%97%E3%81%A6%E5%AF%8C%E3%82%92%E4%BD%9C%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0389-answer

**ja-Q0390** — 彼は親譲りの財産をもとにして富を作った。

He built on his father's fortune.

も often means also/even and replaces or combines with another marker. In negative quantity expressions it can help convey not even/none. The scope is set by the phrase it follows.

Why: Inclusion も. [[Japanese#^ja-Q0390|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%AF%E8%A6%AA%E8%AD%B2%E3%82%8A%E3%81%AE%E8%B2%A1%E7%94%A3%E3%82%92%E3%82%82%E3%81%A8%E3%81%AB%E3%81%97%E3%81%A6%E5%AF%8C%E3%82%92%E4%BD%9C%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0390-answer

**ja-Q0391** — 私たちはいつも地球とともに動いている。

We are always moving with the earth.

Expected form: **も**

Why: Inclusion も. [[Japanese#^ja-Q0391|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%9F%E3%81%A1%E3%81%AF%E3%81%84%E3%81%A4%E3%82%82%E5%9C%B0%E7%90%83%E3%81%A8%E3%81%A8%E3%82%82%E3%81%AB%E5%8B%95%E3%81%84%E3%81%A6%E3%81%84%E3%82%8B%E3%80%82)
^ja-Q0391-answer

**ja-Q0392** — 私たちはいつも地球とともに動いている。

We are always moving with the earth.

Expected form: **も**

Why: Inclusion も. [[Japanese#^ja-Q0392|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%9F%E3%81%A1%E3%81%AF%E3%81%84%E3%81%A4%E3%82%82%E5%9C%B0%E7%90%83%E3%81%A8%E3%81%A8%E3%82%82%E3%81%AB%E5%8B%95%E3%81%84%E3%81%A6%E3%81%84%E3%82%8B%E3%80%82)
^ja-Q0392-answer

**ja-Q0393** — 彼女はこの世の中でもっとも親切な女だとおもう。

I think she is the kindest woman on earth.

Expected form: **も**

Why: Inclusion も. [[Japanese#^ja-Q0393|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E5%A5%B3%E3%81%AF%E3%81%93%E3%81%AE%E4%B8%96%E3%81%AE%E4%B8%AD%E3%81%A7%E3%82%82%E3%81%A3%E3%81%A8%E3%82%82%E8%A6%AA%E5%88%87%E3%81%AA%E5%A5%B3%E3%81%A0%E3%81%A8%E3%81%8A%E3%82%82%E3%81%86%E3%80%82)
^ja-Q0393-answer

**ja-Q0394** — 彼女はこの世の中でもっとも親切な女だとおもう。

I think she is the kindest woman on earth.

Why: Inclusion も. [[Japanese#^ja-Q0394|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E5%A5%B3%E3%81%AF%E3%81%93%E3%81%AE%E4%B8%96%E3%81%AE%E4%B8%AD%E3%81%A7%E3%82%82%E3%81%A3%E3%81%A8%E3%82%82%E8%A6%AA%E5%88%87%E3%81%AA%E5%A5%B3%E3%81%A0%E3%81%A8%E3%81%8A%E3%82%82%E3%81%86%E3%80%82)
^ja-Q0394-answer

**ja-Q0395** — もし過去に戻ってもう一度人生をやり直せるとしたら、幾つの時に戻りたい？

If you could go back and start your life again, from what age would you like to start?

Why: Inclusion も. [[Japanese#^ja-Q0395|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%82%82%E3%81%97%E9%81%8E%E5%8E%BB%E3%81%AB%E6%88%BB%E3%81%A3%E3%81%A6%E3%82%82%E3%81%86%E4%B8%80%E5%BA%A6%E4%BA%BA%E7%94%9F%E3%82%92%E3%82%84%E3%82%8A%E7%9B%B4%E3%81%9B%E3%82%8B%E3%81%A8%E3%81%97%E3%81%9F%E3%82%89%E3%80%81%E5%B9%BE%E3%81%A4%E3%81%AE%E6%99%82%E3%81%AB%E6%88%BB%E3%82%8A%E3%81%9F%E3%81%84%EF%BC%9F)
^ja-Q0395-answer

**ja-Q0396** — もし過去に戻ってもう一度人生をやり直せるとしたら、幾つの時に戻りたい？

If you could go back and start your life again, from what age would you like to start?

も often means also/even and replaces or combines with another marker. In negative quantity expressions it can help convey not even/none. The scope is set by the phrase it follows.

Why: Inclusion も. [[Japanese#^ja-Q0396|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%82%82%E3%81%97%E9%81%8E%E5%8E%BB%E3%81%AB%E6%88%BB%E3%81%A3%E3%81%A6%E3%82%82%E3%81%86%E4%B8%80%E5%BA%A6%E4%BA%BA%E7%94%9F%E3%82%92%E3%82%84%E3%82%8A%E7%9B%B4%E3%81%9B%E3%82%8B%E3%81%A8%E3%81%97%E3%81%9F%E3%82%89%E3%80%81%E5%B9%BE%E3%81%A4%E3%81%AE%E6%99%82%E3%81%AB%E6%88%BB%E3%82%8A%E3%81%9F%E3%81%84%EF%BC%9F)
^ja-Q0396-answer

**ja-Q0397** — 手もとにあるどのような武器を用いてもエイズと闘う必要がある。

It is necessary to fight AIDS with whatever weapons are at hand.

Expected form: **も**

Why: Inclusion も. [[Japanese#^ja-Q0397|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%89%8B%E3%82%82%E3%81%A8%E3%81%AB%E3%81%82%E3%82%8B%E3%81%A9%E3%81%AE%E3%82%88%E3%81%86%E3%81%AA%E6%AD%A6%E5%99%A8%E3%82%92%E7%94%A8%E3%81%84%E3%81%A6%E3%82%82%E3%82%A8%E3%82%A4%E3%82%BA%E3%81%A8%E9%97%98%E3%81%86%E5%BF%85%E8%A6%81%E3%81%8C%E3%81%82%E3%82%8B%E3%80%82)
^ja-Q0397-answer

**ja-Q0398** — 手もとにあるどのような武器を用いてもエイズと闘う必要がある。

It is necessary to fight AIDS with whatever weapons are at hand.

Expected form: **も**

Why: Inclusion も. [[Japanese#^ja-Q0398|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%89%8B%E3%82%82%E3%81%A8%E3%81%AB%E3%81%82%E3%82%8B%E3%81%A9%E3%81%AE%E3%82%88%E3%81%86%E3%81%AA%E6%AD%A6%E5%99%A8%E3%82%92%E7%94%A8%E3%81%84%E3%81%A6%E3%82%82%E3%82%A8%E3%82%A4%E3%82%BA%E3%81%A8%E9%97%98%E3%81%86%E5%BF%85%E8%A6%81%E3%81%8C%E3%81%82%E3%82%8B%E3%80%82)
^ja-Q0398-answer

**ja-Q0399** — 彼女の唯一の望みは息子にもう１度会うことだった。

Her one wish was to see her son again.

Expected form: **も**

Why: Inclusion も. [[Japanese#^ja-Q0399|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E5%A5%B3%E3%81%AE%E5%94%AF%E4%B8%80%E3%81%AE%E6%9C%9B%E3%81%BF%E3%81%AF%E6%81%AF%E5%AD%90%E3%81%AB%E3%82%82%E3%81%86%EF%BC%91%E5%BA%A6%E4%BC%9A%E3%81%86%E3%81%93%E3%81%A8%E3%81%A0%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0399-answer

**ja-Q0400** — 彼女の唯一の望みは息子にもう１度会うことだった。

Her one wish was to see her son again.

Why: Inclusion も. [[Japanese#^ja-Q0400|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E5%A5%B3%E3%81%AE%E5%94%AF%E4%B8%80%E3%81%AE%E6%9C%9B%E3%81%BF%E3%81%AF%E6%81%AF%E5%AD%90%E3%81%AB%E3%82%82%E3%81%86%EF%BC%91%E5%BA%A6%E4%BC%9A%E3%81%86%E3%81%93%E3%81%A8%E3%81%A0%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0400-answer


### Answers 401–450

**ja-Q0401** — 食事ですよ。今、いきます。

Dinner's ready. I'm coming.

Why: Polite present ending. [[Japanese#^ja-Q0401|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E9%A3%9F%E4%BA%8B%E3%81%A7%E3%81%99%E3%82%88%E3%80%82%E4%BB%8A%E3%80%81%E3%81%84%E3%81%8D%E3%81%BE%E3%81%99%E3%80%82)
^ja-Q0401-answer

**ja-Q0402** — 食事ですよ。今、いきます。

Dinner's ready. I'm coming.

ます marks a polite affirmative non-past predicate. Japanese non-past covers present habits and many future contexts. Attach it to the appropriate verb stem, not the dictionary form unchanged.

Why: Polite present ending. [[Japanese#^ja-Q0402|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E9%A3%9F%E4%BA%8B%E3%81%A7%E3%81%99%E3%82%88%E3%80%82%E4%BB%8A%E3%80%81%E3%81%84%E3%81%8D%E3%81%BE%E3%81%99%E3%80%82)
^ja-Q0402-answer

**ja-Q0403** — 列車は時刻通りに出ますか。

Will the train leave on time?

Expected form: **ます**

Why: Polite present ending. [[Japanese#^ja-Q0403|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%88%97%E8%BB%8A%E3%81%AF%E6%99%82%E5%88%BB%E9%80%9A%E3%82%8A%E3%81%AB%E5%87%BA%E3%81%BE%E3%81%99%E3%81%8B%E3%80%82)
^ja-Q0403-answer

**ja-Q0404** — 列車は時刻通りに出ますか。

Will the train leave on time?

Expected form: **ます**

Why: Polite present ending. [[Japanese#^ja-Q0404|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%88%97%E8%BB%8A%E3%81%AF%E6%99%82%E5%88%BB%E9%80%9A%E3%82%8A%E3%81%AB%E5%87%BA%E3%81%BE%E3%81%99%E3%81%8B%E3%80%82)
^ja-Q0404-answer

**ja-Q0405** — 私は東京までの往復券を持っています。

I have a round trip ticket to Tokyo.

Expected form: **ます**

Why: Polite present ending. [[Japanese#^ja-Q0405|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AF%E6%9D%B1%E4%BA%AC%E3%81%BE%E3%81%A7%E3%81%AE%E5%BE%80%E5%BE%A9%E5%88%B8%E3%82%92%E6%8C%81%E3%81%A3%E3%81%A6%E3%81%84%E3%81%BE%E3%81%99%E3%80%82)
^ja-Q0405-answer

**ja-Q0406** — 私は東京までの往復券を持っています。

I have a round trip ticket to Tokyo.

Why: Polite present ending. [[Japanese#^ja-Q0406|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AF%E6%9D%B1%E4%BA%AC%E3%81%BE%E3%81%A7%E3%81%AE%E5%BE%80%E5%BE%A9%E5%88%B8%E3%82%92%E6%8C%81%E3%81%A3%E3%81%A6%E3%81%84%E3%81%BE%E3%81%99%E3%80%82)
^ja-Q0406-answer

**ja-Q0407** — あなたは先月から日本にいますか。

Have you been in Japan since last month?

Why: Polite present ending. [[Japanese#^ja-Q0407|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%82%E3%81%AA%E3%81%9F%E3%81%AF%E5%85%88%E6%9C%88%E3%81%8B%E3%82%89%E6%97%A5%E6%9C%AC%E3%81%AB%E3%81%84%E3%81%BE%E3%81%99%E3%81%8B%E3%80%82)
^ja-Q0407-answer

**ja-Q0408** — あなたは先月から日本にいますか。

Have you been in Japan since last month?

ます marks a polite affirmative non-past predicate. Japanese non-past covers present habits and many future contexts. Attach it to the appropriate verb stem, not the dictionary form unchanged.

Why: Polite present ending. [[Japanese#^ja-Q0408|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%82%E3%81%AA%E3%81%9F%E3%81%AF%E5%85%88%E6%9C%88%E3%81%8B%E3%82%89%E6%97%A5%E6%9C%AC%E3%81%AB%E3%81%84%E3%81%BE%E3%81%99%E3%81%8B%E3%80%82)
^ja-Q0408-answer

**ja-Q0409** — トムはどれくらいボストンに住んでいますか?

How long has Tom lived in Boston?

Expected form: **ます**

Why: Polite present ending. [[Japanese#^ja-Q0409|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%83%88%E3%83%A0%E3%81%AF%E3%81%A9%E3%82%8C%E3%81%8F%E3%82%89%E3%81%84%E3%83%9C%E3%82%B9%E3%83%88%E3%83%B3%E3%81%AB%E4%BD%8F%E3%82%93%E3%81%A7%E3%81%84%E3%81%BE%E3%81%99%E3%81%8B%3F)
^ja-Q0409-answer

**ja-Q0410** — トムはどれくらいボストンに住んでいますか?

How long has Tom lived in Boston?

Expected form: **ます**

Why: Polite present ending. [[Japanese#^ja-Q0410|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%83%88%E3%83%A0%E3%81%AF%E3%81%A9%E3%82%8C%E3%81%8F%E3%82%89%E3%81%84%E3%83%9C%E3%82%B9%E3%83%88%E3%83%B3%E3%81%AB%E4%BD%8F%E3%82%93%E3%81%A7%E3%81%84%E3%81%BE%E3%81%99%E3%81%8B%3F)
^ja-Q0410-answer

**ja-Q0411** — あなたには賛成しかねます。

I cannot agree with you.

Expected form: **ます**

Why: Polite present ending. [[Japanese#^ja-Q0411|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%82%E3%81%AA%E3%81%9F%E3%81%AB%E3%81%AF%E8%B3%9B%E6%88%90%E3%81%97%E3%81%8B%E3%81%AD%E3%81%BE%E3%81%99%E3%80%82)
^ja-Q0411-answer

**ja-Q0412** — あなたには賛成しかねます。

I cannot agree with you.

Why: Polite present ending. [[Japanese#^ja-Q0412|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%82%E3%81%AA%E3%81%9F%E3%81%AB%E3%81%AF%E8%B3%9B%E6%88%90%E3%81%97%E3%81%8B%E3%81%AD%E3%81%BE%E3%81%99%E3%80%82)
^ja-Q0412-answer

**ja-Q0413** — 彼は１日か２日で帰ってきます。

He will be back in a day or two.

Why: Polite present ending. [[Japanese#^ja-Q0413|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%AF%EF%BC%91%E6%97%A5%E3%81%8B%EF%BC%92%E6%97%A5%E3%81%A7%E5%B8%B0%E3%81%A3%E3%81%A6%E3%81%8D%E3%81%BE%E3%81%99%E3%80%82)
^ja-Q0413-answer

**ja-Q0414** — 彼は１日か２日で帰ってきます。

He will be back in a day or two.

ます marks a polite affirmative non-past predicate. Japanese non-past covers present habits and many future contexts. Attach it to the appropriate verb stem, not the dictionary form unchanged.

Why: Polite present ending. [[Japanese#^ja-Q0414|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%AF%EF%BC%91%E6%97%A5%E3%81%8B%EF%BC%92%E6%97%A5%E3%81%A7%E5%B8%B0%E3%81%A3%E3%81%A6%E3%81%8D%E3%81%BE%E3%81%99%E3%80%82)
^ja-Q0414-answer

**ja-Q0415** — あなたは中国語を話せますか？

Can you speak Chinese?

Expected form: **ます**

Why: Polite present ending. [[Japanese#^ja-Q0415|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%82%E3%81%AA%E3%81%9F%E3%81%AF%E4%B8%AD%E5%9B%BD%E8%AA%9E%E3%82%92%E8%A9%B1%E3%81%9B%E3%81%BE%E3%81%99%E3%81%8B%EF%BC%9F)
^ja-Q0415-answer

**ja-Q0416** — あなたは中国語を話せますか？

Can you speak Chinese?

Expected form: **ます**

Why: Polite present ending. [[Japanese#^ja-Q0416|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%82%E3%81%AA%E3%81%9F%E3%81%AF%E4%B8%AD%E5%9B%BD%E8%AA%9E%E3%82%92%E8%A9%B1%E3%81%9B%E3%81%BE%E3%81%99%E3%81%8B%EF%BC%9F)
^ja-Q0416-answer

**ja-Q0417** — ここに原子力発電所があります。

Here is an atomic power plant.

Expected form: **ます**

Why: Polite present ending. [[Japanese#^ja-Q0417|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%93%E3%81%93%E3%81%AB%E5%8E%9F%E5%AD%90%E5%8A%9B%E7%99%BA%E9%9B%BB%E6%89%80%E3%81%8C%E3%81%82%E3%82%8A%E3%81%BE%E3%81%99%E3%80%82)
^ja-Q0417-answer

**ja-Q0418** — ここに原子力発電所があります。

Here is an atomic power plant.

Why: Polite present ending. [[Japanese#^ja-Q0418|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%93%E3%81%93%E3%81%AB%E5%8E%9F%E5%AD%90%E5%8A%9B%E7%99%BA%E9%9B%BB%E6%89%80%E3%81%8C%E3%81%82%E3%82%8A%E3%81%BE%E3%81%99%E3%80%82)
^ja-Q0418-answer

**ja-Q0419** — あなたに会いたがっている人が玄関にいます。

There is a man at the door who wants to see you.

Why: Polite present ending. [[Japanese#^ja-Q0419|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%82%E3%81%AA%E3%81%9F%E3%81%AB%E4%BC%9A%E3%81%84%E3%81%9F%E3%81%8C%E3%81%A3%E3%81%A6%E3%81%84%E3%82%8B%E4%BA%BA%E3%81%8C%E7%8E%84%E9%96%A2%E3%81%AB%E3%81%84%E3%81%BE%E3%81%99%E3%80%82)
^ja-Q0419-answer

**ja-Q0420** — あなたに会いたがっている人が玄関にいます。

There is a man at the door who wants to see you.

ます marks a polite affirmative non-past predicate. Japanese non-past covers present habits and many future contexts. Attach it to the appropriate verb stem, not the dictionary form unchanged.

Why: Polite present ending. [[Japanese#^ja-Q0420|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%82%E3%81%AA%E3%81%9F%E3%81%AB%E4%BC%9A%E3%81%84%E3%81%9F%E3%81%8C%E3%81%A3%E3%81%A6%E3%81%84%E3%82%8B%E4%BA%BA%E3%81%8C%E7%8E%84%E9%96%A2%E3%81%AB%E3%81%84%E3%81%BE%E3%81%99%E3%80%82)
^ja-Q0420-answer

**ja-Q0421** — 色は何色ありますか。

How many colors are there?

Expected form: **ます**

Why: Polite present ending. [[Japanese#^ja-Q0421|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E8%89%B2%E3%81%AF%E4%BD%95%E8%89%B2%E3%81%82%E3%82%8A%E3%81%BE%E3%81%99%E3%81%8B%E3%80%82)
^ja-Q0421-answer

**ja-Q0422** — 色は何色ありますか。

How many colors are there?

Expected form: **ます**

Why: Polite present ending. [[Japanese#^ja-Q0422|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E8%89%B2%E3%81%AF%E4%BD%95%E8%89%B2%E3%81%82%E3%82%8A%E3%81%BE%E3%81%99%E3%81%8B%E3%80%82)
^ja-Q0422-answer

**ja-Q0423** — 私はここで泳ぐことができます。

I am able to swim here.

Expected form: **ます**

Why: Polite present ending. [[Japanese#^ja-Q0423|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AF%E3%81%93%E3%81%93%E3%81%A7%E6%B3%B3%E3%81%90%E3%81%93%E3%81%A8%E3%81%8C%E3%81%A7%E3%81%8D%E3%81%BE%E3%81%99%E3%80%82)
^ja-Q0423-answer

**ja-Q0424** — 私はここで泳ぐことができます。

I am able to swim here.

Why: Polite present ending. [[Japanese#^ja-Q0424|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AF%E3%81%93%E3%81%93%E3%81%A7%E6%B3%B3%E3%81%90%E3%81%93%E3%81%A8%E3%81%8C%E3%81%A7%E3%81%8D%E3%81%BE%E3%81%99%E3%80%82)
^ja-Q0424-answer

**ja-Q0425** — 私の娘のケイトは歌のコンテストで賞を取りました。私は彼女を誇りに思います。

My daughter, Kate, won a singing competition and I'm proud of her.

Why: Polite present ending. [[Japanese#^ja-Q0425|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AE%E5%A8%98%E3%81%AE%E3%82%B1%E3%82%A4%E3%83%88%E3%81%AF%E6%AD%8C%E3%81%AE%E3%82%B3%E3%83%B3%E3%83%86%E3%82%B9%E3%83%88%E3%81%A7%E8%B3%9E%E3%82%92%E5%8F%96%E3%82%8A%E3%81%BE%E3%81%97%E3%81%9F%E3%80%82%E7%A7%81%E3%81%AF%E5%BD%BC%E5%A5%B3%E3%82%92%E8%AA%87%E3%82%8A%E3%81%AB%E6%80%9D%E3%81%84%E3%81%BE%E3%81%99%E3%80%82)
^ja-Q0425-answer

**ja-Q0426** — 私の娘のケイトは歌のコンテストで賞を取りました。私は彼女を誇りに思います。

My daughter, Kate, won a singing competition and I'm proud of her.

ます marks a polite affirmative non-past predicate. Japanese non-past covers present habits and many future contexts. Attach it to the appropriate verb stem, not the dictionary form unchanged.

Why: Polite present ending. [[Japanese#^ja-Q0426|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AE%E5%A8%98%E3%81%AE%E3%82%B1%E3%82%A4%E3%83%88%E3%81%AF%E6%AD%8C%E3%81%AE%E3%82%B3%E3%83%B3%E3%83%86%E3%82%B9%E3%83%88%E3%81%A7%E8%B3%9E%E3%82%92%E5%8F%96%E3%82%8A%E3%81%BE%E3%81%97%E3%81%9F%E3%80%82%E7%A7%81%E3%81%AF%E5%BD%BC%E5%A5%B3%E3%82%92%E8%AA%87%E3%82%8A%E3%81%AB%E6%80%9D%E3%81%84%E3%81%BE%E3%81%99%E3%80%82)
^ja-Q0426-answer

**ja-Q0427** — ２ヶ月に１度メーターを検査します。

We read the meter once every two months.

Expected form: **ます**

Why: Polite present ending. [[Japanese#^ja-Q0427|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%EF%BC%92%E3%83%B6%E6%9C%88%E3%81%AB%EF%BC%91%E5%BA%A6%E3%83%A1%E3%83%BC%E3%82%BF%E3%83%BC%E3%82%92%E6%A4%9C%E6%9F%BB%E3%81%97%E3%81%BE%E3%81%99%E3%80%82)
^ja-Q0427-answer

**ja-Q0428** — ２ヶ月に１度メーターを検査します。

We read the meter once every two months.

Expected form: **ます**

Why: Polite present ending. [[Japanese#^ja-Q0428|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%EF%BC%92%E3%83%B6%E6%9C%88%E3%81%AB%EF%BC%91%E5%BA%A6%E3%83%A1%E3%83%BC%E3%82%BF%E3%83%BC%E3%82%92%E6%A4%9C%E6%9F%BB%E3%81%97%E3%81%BE%E3%81%99%E3%80%82)
^ja-Q0428-answer

**ja-Q0429** — 授業は毎日九時に始まります。

Classes start at nine o'clock every day.

Expected form: **ます**

Why: Polite present ending. [[Japanese#^ja-Q0429|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%8E%88%E6%A5%AD%E3%81%AF%E6%AF%8E%E6%97%A5%E4%B9%9D%E6%99%82%E3%81%AB%E5%A7%8B%E3%81%BE%E3%82%8A%E3%81%BE%E3%81%99%E3%80%82)
^ja-Q0429-answer

**ja-Q0430** — 授業は毎日九時に始まります。

Classes start at nine o'clock every day.

Why: Polite present ending. [[Japanese#^ja-Q0430|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%8E%88%E6%A5%AD%E3%81%AF%E6%AF%8E%E6%97%A5%E4%B9%9D%E6%99%82%E3%81%AB%E5%A7%8B%E3%81%BE%E3%82%8A%E3%81%BE%E3%81%99%E3%80%82)
^ja-Q0430-answer

**ja-Q0431** — 急ぐ必要はありません。そのことはまだ５日間よく考えられます。

There is no hurry; you have five days to think the matter over.

Why: Polite present ending. [[Japanese#^ja-Q0431|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%80%A5%E3%81%90%E5%BF%85%E8%A6%81%E3%81%AF%E3%81%82%E3%82%8A%E3%81%BE%E3%81%9B%E3%82%93%E3%80%82%E3%81%9D%E3%81%AE%E3%81%93%E3%81%A8%E3%81%AF%E3%81%BE%E3%81%A0%EF%BC%95%E6%97%A5%E9%96%93%E3%82%88%E3%81%8F%E8%80%83%E3%81%88%E3%82%89%E3%82%8C%E3%81%BE%E3%81%99%E3%80%82)
^ja-Q0431-answer

**ja-Q0432** — 急ぐ必要はありません。そのことはまだ５日間よく考えられます。

There is no hurry; you have five days to think the matter over.

ます marks a polite affirmative non-past predicate. Japanese non-past covers present habits and many future contexts. Attach it to the appropriate verb stem, not the dictionary form unchanged.

Why: Polite present ending. [[Japanese#^ja-Q0432|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%80%A5%E3%81%90%E5%BF%85%E8%A6%81%E3%81%AF%E3%81%82%E3%82%8A%E3%81%BE%E3%81%9B%E3%82%93%E3%80%82%E3%81%9D%E3%81%AE%E3%81%93%E3%81%A8%E3%81%AF%E3%81%BE%E3%81%A0%EF%BC%95%E6%97%A5%E9%96%93%E3%82%88%E3%81%8F%E8%80%83%E3%81%88%E3%82%89%E3%82%8C%E3%81%BE%E3%81%99%E3%80%82)
^ja-Q0432-answer

**ja-Q0433** — 1時間ほどお待ちいただけますか？

Can you wait about an hour?

Expected form: **ます**

Why: Polite present ending. [[Japanese#^ja-Q0433|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=1%E6%99%82%E9%96%93%E3%81%BB%E3%81%A9%E3%81%8A%E5%BE%85%E3%81%A1%E3%81%84%E3%81%9F%E3%81%A0%E3%81%91%E3%81%BE%E3%81%99%E3%81%8B%EF%BC%9F)
^ja-Q0433-answer

**ja-Q0434** — 1時間ほどお待ちいただけますか？

Can you wait about an hour?

Expected form: **ます**

Why: Polite present ending. [[Japanese#^ja-Q0434|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=1%E6%99%82%E9%96%93%E3%81%BB%E3%81%A9%E3%81%8A%E5%BE%85%E3%81%A1%E3%81%84%E3%81%9F%E3%81%A0%E3%81%91%E3%81%BE%E3%81%99%E3%81%8B%EF%BC%9F)
^ja-Q0434-answer

**ja-Q0435** — お宅の暖房はどのようにしていますか。

How do you heat the house?

Expected form: **ます**

Why: Polite present ending. [[Japanese#^ja-Q0435|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%8A%E5%AE%85%E3%81%AE%E6%9A%96%E6%88%BF%E3%81%AF%E3%81%A9%E3%81%AE%E3%82%88%E3%81%86%E3%81%AB%E3%81%97%E3%81%A6%E3%81%84%E3%81%BE%E3%81%99%E3%81%8B%E3%80%82)
^ja-Q0435-answer

**ja-Q0436** — お宅の暖房はどのようにしていますか。

How do you heat the house?

Why: Polite present ending. [[Japanese#^ja-Q0436|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%8A%E5%AE%85%E3%81%AE%E6%9A%96%E6%88%BF%E3%81%AF%E3%81%A9%E3%81%AE%E3%82%88%E3%81%86%E3%81%AB%E3%81%97%E3%81%A6%E3%81%84%E3%81%BE%E3%81%99%E3%81%8B%E3%80%82)
^ja-Q0436-answer

**ja-Q0437** — その土壌は腐植に富んでいます。

That soil is rich in humus.

Why: Polite present ending. [[Japanese#^ja-Q0437|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%9D%E3%81%AE%E5%9C%9F%E5%A3%8C%E3%81%AF%E8%85%90%E6%A4%8D%E3%81%AB%E5%AF%8C%E3%82%93%E3%81%A7%E3%81%84%E3%81%BE%E3%81%99%E3%80%82)
^ja-Q0437-answer

**ja-Q0438** — その土壌は腐植に富んでいます。

That soil is rich in humus.

ます marks a polite affirmative non-past predicate. Japanese non-past covers present habits and many future contexts. Attach it to the appropriate verb stem, not the dictionary form unchanged.

Why: Polite present ending. [[Japanese#^ja-Q0438|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%9D%E3%81%AE%E5%9C%9F%E5%A3%8C%E3%81%AF%E8%85%90%E6%A4%8D%E3%81%AB%E5%AF%8C%E3%82%93%E3%81%A7%E3%81%84%E3%81%BE%E3%81%99%E3%80%82)
^ja-Q0438-answer

**ja-Q0439** — 何故彼は失業したと思いますか。

What do you think caused him to lose his job?

Expected form: **ます**

Why: Polite present ending. [[Japanese#^ja-Q0439|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E4%BD%95%E6%95%85%E5%BD%BC%E3%81%AF%E5%A4%B1%E6%A5%AD%E3%81%97%E3%81%9F%E3%81%A8%E6%80%9D%E3%81%84%E3%81%BE%E3%81%99%E3%81%8B%E3%80%82)
^ja-Q0439-answer

**ja-Q0440** — 何故彼は失業したと思いますか。

What do you think caused him to lose his job?

Expected form: **ます**

Why: Polite present ending. [[Japanese#^ja-Q0440|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E4%BD%95%E6%95%85%E5%BD%BC%E3%81%AF%E5%A4%B1%E6%A5%AD%E3%81%97%E3%81%9F%E3%81%A8%E6%80%9D%E3%81%84%E3%81%BE%E3%81%99%E3%81%8B%E3%80%82)
^ja-Q0440-answer

**ja-Q0441** — 来月このアパートから引っ越します。

We're moving out of this apartment next month.

Expected form: **ます**

Why: Polite present ending. [[Japanese#^ja-Q0441|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%9D%A5%E6%9C%88%E3%81%93%E3%81%AE%E3%82%A2%E3%83%91%E3%83%BC%E3%83%88%E3%81%8B%E3%82%89%E5%BC%95%E3%81%A3%E8%B6%8A%E3%81%97%E3%81%BE%E3%81%99%E3%80%82)
^ja-Q0441-answer

**ja-Q0442** — 来月このアパートから引っ越します。

We're moving out of this apartment next month.

Why: Polite present ending. [[Japanese#^ja-Q0442|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%9D%A5%E6%9C%88%E3%81%93%E3%81%AE%E3%82%A2%E3%83%91%E3%83%BC%E3%83%88%E3%81%8B%E3%82%89%E5%BC%95%E3%81%A3%E8%B6%8A%E3%81%97%E3%81%BE%E3%81%99%E3%80%82)
^ja-Q0442-answer

**ja-Q0443** — 放課後にはクラブ活動があります。

We have extracurricular activities after school.

Why: Polite present ending. [[Japanese#^ja-Q0443|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%94%BE%E8%AA%B2%E5%BE%8C%E3%81%AB%E3%81%AF%E3%82%AF%E3%83%A9%E3%83%96%E6%B4%BB%E5%8B%95%E3%81%8C%E3%81%82%E3%82%8A%E3%81%BE%E3%81%99%E3%80%82)
^ja-Q0443-answer

**ja-Q0444** — 放課後にはクラブ活動があります。

We have extracurricular activities after school.

ます marks a polite affirmative non-past predicate. Japanese non-past covers present habits and many future contexts. Attach it to the appropriate verb stem, not the dictionary form unchanged.

Why: Polite present ending. [[Japanese#^ja-Q0444|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%94%BE%E8%AA%B2%E5%BE%8C%E3%81%AB%E3%81%AF%E3%82%AF%E3%83%A9%E3%83%96%E6%B4%BB%E5%8B%95%E3%81%8C%E3%81%82%E3%82%8A%E3%81%BE%E3%81%99%E3%80%82)
^ja-Q0444-answer

**ja-Q0445** — あなたは新しい家に満足してますか。

Are you pleased with your new house?

Expected form: **ます**

Why: Polite present ending. [[Japanese#^ja-Q0445|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%82%E3%81%AA%E3%81%9F%E3%81%AF%E6%96%B0%E3%81%97%E3%81%84%E5%AE%B6%E3%81%AB%E6%BA%80%E8%B6%B3%E3%81%97%E3%81%A6%E3%81%BE%E3%81%99%E3%81%8B%E3%80%82)
^ja-Q0445-answer

**ja-Q0446** — あなたは新しい家に満足してますか。

Are you pleased with your new house?

Expected form: **ます**

Why: Polite present ending. [[Japanese#^ja-Q0446|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%82%E3%81%AA%E3%81%9F%E3%81%AF%E6%96%B0%E3%81%97%E3%81%84%E5%AE%B6%E3%81%AB%E6%BA%80%E8%B6%B3%E3%81%97%E3%81%A6%E3%81%BE%E3%81%99%E3%81%8B%E3%80%82)
^ja-Q0446-answer

**ja-Q0447** — 値段には消費税を含みます。

The price includes the consumption tax.

Expected form: **ます**

Why: Polite present ending. [[Japanese#^ja-Q0447|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%80%A4%E6%AE%B5%E3%81%AB%E3%81%AF%E6%B6%88%E8%B2%BB%E7%A8%8E%E3%82%92%E5%90%AB%E3%81%BF%E3%81%BE%E3%81%99%E3%80%82)
^ja-Q0447-answer

**ja-Q0448** — 値段には消費税を含みます。

The price includes the consumption tax.

Why: Polite present ending. [[Japanese#^ja-Q0448|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%80%A4%E6%AE%B5%E3%81%AB%E3%81%AF%E6%B6%88%E8%B2%BB%E7%A8%8E%E3%82%92%E5%90%AB%E3%81%BF%E3%81%BE%E3%81%99%E3%80%82)
^ja-Q0448-answer

**ja-Q0449** — 本日の映画は「サウンド・オブ・ミュージック」でございます。

Today's movie is The Sound of Music.

Why: Polite present ending. [[Japanese#^ja-Q0449|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%9C%AC%E6%97%A5%E3%81%AE%E6%98%A0%E7%94%BB%E3%81%AF%E3%80%8C%E3%82%B5%E3%82%A6%E3%83%B3%E3%83%89%E3%83%BB%E3%82%AA%E3%83%96%E3%83%BB%E3%83%9F%E3%83%A5%E3%83%BC%E3%82%B8%E3%83%83%E3%82%AF%E3%80%8D%E3%81%A7%E3%81%94%E3%81%96%E3%81%84%E3%81%BE%E3%81%99%E3%80%82)
^ja-Q0449-answer

**ja-Q0450** — 本日の映画は「サウンド・オブ・ミュージック」でございます。

Today's movie is The Sound of Music.

ます marks a polite affirmative non-past predicate. Japanese non-past covers present habits and many future contexts. Attach it to the appropriate verb stem, not the dictionary form unchanged.

Why: Polite present ending. [[Japanese#^ja-Q0450|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%9C%AC%E6%97%A5%E3%81%AE%E6%98%A0%E7%94%BB%E3%81%AF%E3%80%8C%E3%82%B5%E3%82%A6%E3%83%B3%E3%83%89%E3%83%BB%E3%82%AA%E3%83%96%E3%83%BB%E3%83%9F%E3%83%A5%E3%83%BC%E3%82%B8%E3%83%83%E3%82%AF%E3%80%8D%E3%81%A7%E3%81%94%E3%81%96%E3%81%84%E3%81%BE%E3%81%99%E3%80%82)
^ja-Q0450-answer


### Answers 451–500

**ja-Q0451** — ガソリンスタンドを探しましょう。燃料がなくなってしまいました。

Let's find a gas station; we've run out of fuel.

Expected form: **ました**

Why: Polite past ending. [[Japanese#^ja-Q0451|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%82%AC%E3%82%BD%E3%83%AA%E3%83%B3%E3%82%B9%E3%82%BF%E3%83%B3%E3%83%89%E3%82%92%E6%8E%A2%E3%81%97%E3%81%BE%E3%81%97%E3%82%87%E3%81%86%E3%80%82%E7%87%83%E6%96%99%E3%81%8C%E3%81%AA%E3%81%8F%E3%81%AA%E3%81%A3%E3%81%A6%E3%81%97%E3%81%BE%E3%81%84%E3%81%BE%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0451-answer

**ja-Q0452** — ガソリンスタンドを探しましょう。燃料がなくなってしまいました。

Let's find a gas station; we've run out of fuel.

Expected form: **ました**

Why: Polite past ending. [[Japanese#^ja-Q0452|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%82%AC%E3%82%BD%E3%83%AA%E3%83%B3%E3%82%B9%E3%82%BF%E3%83%B3%E3%83%89%E3%82%92%E6%8E%A2%E3%81%97%E3%81%BE%E3%81%97%E3%82%87%E3%81%86%E3%80%82%E7%87%83%E6%96%99%E3%81%8C%E3%81%AA%E3%81%8F%E3%81%AA%E3%81%A3%E3%81%A6%E3%81%97%E3%81%BE%E3%81%84%E3%81%BE%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0452-answer

**ja-Q0453** — こつが飲み込めましたか。

Got the hang of it?

Expected form: **ました**

Why: Polite past ending. [[Japanese#^ja-Q0453|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%93%E3%81%A4%E3%81%8C%E9%A3%B2%E3%81%BF%E8%BE%BC%E3%82%81%E3%81%BE%E3%81%97%E3%81%9F%E3%81%8B%E3%80%82)
^ja-Q0453-answer

**ja-Q0454** — こつが飲み込めましたか。

Got the hang of it?

Why: Polite past ending. [[Japanese#^ja-Q0454|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%93%E3%81%A4%E3%81%8C%E9%A3%B2%E3%81%BF%E8%BE%BC%E3%82%81%E3%81%BE%E3%81%97%E3%81%9F%E3%81%8B%E3%80%82)
^ja-Q0454-answer

**ja-Q0455** — 私は遊ぶために公園へ行きました。

I went to the park to play.

Why: Polite past ending. [[Japanese#^ja-Q0455|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AF%E9%81%8A%E3%81%B6%E3%81%9F%E3%82%81%E3%81%AB%E5%85%AC%E5%9C%92%E3%81%B8%E8%A1%8C%E3%81%8D%E3%81%BE%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0455-answer

**ja-Q0456** — 私は遊ぶために公園へ行きました。

I went to the park to play.

ました marks a polite affirmative past form. Recognise the verb stem and preceding complements before converting a sentence to past.

Why: Polite past ending. [[Japanese#^ja-Q0456|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AF%E9%81%8A%E3%81%B6%E3%81%9F%E3%82%81%E3%81%AB%E5%85%AC%E5%9C%92%E3%81%B8%E8%A1%8C%E3%81%8D%E3%81%BE%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0456-answer

**ja-Q0457** — いつゴルフを始めましたか?

When did you start playing golf?

Expected form: **ました**

Why: Polite past ending. [[Japanese#^ja-Q0457|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%84%E3%81%A4%E3%82%B4%E3%83%AB%E3%83%95%E3%82%92%E5%A7%8B%E3%82%81%E3%81%BE%E3%81%97%E3%81%9F%E3%81%8B%3F)
^ja-Q0457-answer

**ja-Q0458** — いつゴルフを始めましたか?

When did you start playing golf?

Expected form: **ました**

Why: Polite past ending. [[Japanese#^ja-Q0458|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%84%E3%81%A4%E3%82%B4%E3%83%AB%E3%83%95%E3%82%92%E5%A7%8B%E3%82%81%E3%81%BE%E3%81%97%E3%81%9F%E3%81%8B%3F)
^ja-Q0458-answer

**ja-Q0459** — 彼は昨年京都を訪問しました。

He visited Kyoto last year.

Expected form: **ました**

Why: Polite past ending. [[Japanese#^ja-Q0459|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%AF%E6%98%A8%E5%B9%B4%E4%BA%AC%E9%83%BD%E3%82%92%E8%A8%AA%E5%95%8F%E3%81%97%E3%81%BE%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0459-answer

**ja-Q0460** — 彼は昨年京都を訪問しました。

He visited Kyoto last year.

Why: Polite past ending. [[Japanese#^ja-Q0460|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%AF%E6%98%A8%E5%B9%B4%E4%BA%AC%E9%83%BD%E3%82%92%E8%A8%AA%E5%95%8F%E3%81%97%E3%81%BE%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0460-answer

**ja-Q0461** — 初めのうちは私は自分の誤りが気になりました。

I was worried about my mistakes at first.

Why: Polite past ending. [[Japanese#^ja-Q0461|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%88%9D%E3%82%81%E3%81%AE%E3%81%86%E3%81%A1%E3%81%AF%E7%A7%81%E3%81%AF%E8%87%AA%E5%88%86%E3%81%AE%E8%AA%A4%E3%82%8A%E3%81%8C%E6%B0%97%E3%81%AB%E3%81%AA%E3%82%8A%E3%81%BE%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0461-answer

**ja-Q0462** — 初めのうちは私は自分の誤りが気になりました。

I was worried about my mistakes at first.

ました marks a polite affirmative past form. Recognise the verb stem and preceding complements before converting a sentence to past.

Why: Polite past ending. [[Japanese#^ja-Q0462|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%88%9D%E3%82%81%E3%81%AE%E3%81%86%E3%81%A1%E3%81%AF%E7%A7%81%E3%81%AF%E8%87%AA%E5%88%86%E3%81%AE%E8%AA%A4%E3%82%8A%E3%81%8C%E6%B0%97%E3%81%AB%E3%81%AA%E3%82%8A%E3%81%BE%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0462-answer

**ja-Q0463** — 自動車の売れ行きは年度末に後退しました。

Automobile sales suffered a setback at the end of the financial year.

Expected form: **ました**

Why: Polite past ending. [[Japanese#^ja-Q0463|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E8%87%AA%E5%8B%95%E8%BB%8A%E3%81%AE%E5%A3%B2%E3%82%8C%E8%A1%8C%E3%81%8D%E3%81%AF%E5%B9%B4%E5%BA%A6%E6%9C%AB%E3%81%AB%E5%BE%8C%E9%80%80%E3%81%97%E3%81%BE%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0463-answer

**ja-Q0464** — 自動車の売れ行きは年度末に後退しました。

Automobile sales suffered a setback at the end of the financial year.

Expected form: **ました**

Why: Polite past ending. [[Japanese#^ja-Q0464|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E8%87%AA%E5%8B%95%E8%BB%8A%E3%81%AE%E5%A3%B2%E3%82%8C%E8%A1%8C%E3%81%8D%E3%81%AF%E5%B9%B4%E5%BA%A6%E6%9C%AB%E3%81%AB%E5%BE%8C%E9%80%80%E3%81%97%E3%81%BE%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0464-answer

**ja-Q0465** — ガーデニングの本を見てたら、ドクロマークのついたのがいっぱいあって驚きました。

When I looked in a gardening book I was surprised by how many were marked poisonous.

Expected form: **ました**

Why: Polite past ending. [[Japanese#^ja-Q0465|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%82%AC%E3%83%BC%E3%83%87%E3%83%8B%E3%83%B3%E3%82%B0%E3%81%AE%E6%9C%AC%E3%82%92%E8%A6%8B%E3%81%A6%E3%81%9F%E3%82%89%E3%80%81%E3%83%89%E3%82%AF%E3%83%AD%E3%83%9E%E3%83%BC%E3%82%AF%E3%81%AE%E3%81%A4%E3%81%84%E3%81%9F%E3%81%AE%E3%81%8C%E3%81%84%E3%81%A3%E3%81%B1%E3%81%84%E3%81%82%E3%81%A3%E3%81%A6%E9%A9%9A%E3%81%8D%E3%81%BE%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0465-answer

**ja-Q0466** — ガーデニングの本を見てたら、ドクロマークのついたのがいっぱいあって驚きました。

When I looked in a gardening book I was surprised by how many were marked poisonous.

Why: Polite past ending. [[Japanese#^ja-Q0466|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%82%AC%E3%83%BC%E3%83%87%E3%83%8B%E3%83%B3%E3%82%B0%E3%81%AE%E6%9C%AC%E3%82%92%E8%A6%8B%E3%81%A6%E3%81%9F%E3%82%89%E3%80%81%E3%83%89%E3%82%AF%E3%83%AD%E3%83%9E%E3%83%BC%E3%82%AF%E3%81%AE%E3%81%A4%E3%81%84%E3%81%9F%E3%81%AE%E3%81%8C%E3%81%84%E3%81%A3%E3%81%B1%E3%81%84%E3%81%82%E3%81%A3%E3%81%A6%E9%A9%9A%E3%81%8D%E3%81%BE%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0466-answer

**ja-Q0467** — この日が来るのを夢見ていました。

I've dreamed of this day.

Why: Polite past ending. [[Japanese#^ja-Q0467|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%93%E3%81%AE%E6%97%A5%E3%81%8C%E6%9D%A5%E3%82%8B%E3%81%AE%E3%82%92%E5%A4%A2%E8%A6%8B%E3%81%A6%E3%81%84%E3%81%BE%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0467-answer

**ja-Q0468** — この日が来るのを夢見ていました。

I've dreamed of this day.

ました marks a polite affirmative past form. Recognise the verb stem and preceding complements before converting a sentence to past.

Why: Polite past ending. [[Japanese#^ja-Q0468|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%93%E3%81%AE%E6%97%A5%E3%81%8C%E6%9D%A5%E3%82%8B%E3%81%AE%E3%82%92%E5%A4%A2%E8%A6%8B%E3%81%A6%E3%81%84%E3%81%BE%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0468-answer

**ja-Q0469** — ご依頼の件、承知しました。

I am willing to agree to your request.

Expected form: **ました**

Why: Polite past ending. [[Japanese#^ja-Q0469|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%94%E4%BE%9D%E9%A0%BC%E3%81%AE%E4%BB%B6%E3%80%81%E6%89%BF%E7%9F%A5%E3%81%97%E3%81%BE%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0469-answer

**ja-Q0470** — ご依頼の件、承知しました。

I am willing to agree to your request.

Expected form: **ました**

Why: Polite past ending. [[Japanese#^ja-Q0470|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%94%E4%BE%9D%E9%A0%BC%E3%81%AE%E4%BB%B6%E3%80%81%E6%89%BF%E7%9F%A5%E3%81%97%E3%81%BE%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0470-answer

**ja-Q0471** — 寮生活には慣れましたか。

Have you got used to living in the dorm?

Expected form: **ました**

Why: Polite past ending. [[Japanese#^ja-Q0471|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%AF%AE%E7%94%9F%E6%B4%BB%E3%81%AB%E3%81%AF%E6%85%A3%E3%82%8C%E3%81%BE%E3%81%97%E3%81%9F%E3%81%8B%E3%80%82)
^ja-Q0471-answer

**ja-Q0472** — 寮生活には慣れましたか。

Have you got used to living in the dorm?

Why: Polite past ending. [[Japanese#^ja-Q0472|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%AF%AE%E7%94%9F%E6%B4%BB%E3%81%AB%E3%81%AF%E6%85%A3%E3%82%8C%E3%81%BE%E3%81%97%E3%81%9F%E3%81%8B%E3%80%82)
^ja-Q0472-answer

**ja-Q0473** — 私はもう手紙を書いてしまいました。

I have already written a letter.

Why: Polite past ending. [[Japanese#^ja-Q0473|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AF%E3%82%82%E3%81%86%E6%89%8B%E7%B4%99%E3%82%92%E6%9B%B8%E3%81%84%E3%81%A6%E3%81%97%E3%81%BE%E3%81%84%E3%81%BE%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0473-answer

**ja-Q0474** — 私はもう手紙を書いてしまいました。

I have already written a letter.

ました marks a polite affirmative past form. Recognise the verb stem and preceding complements before converting a sentence to past.

Why: Polite past ending. [[Japanese#^ja-Q0474|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AF%E3%82%82%E3%81%86%E6%89%8B%E7%B4%99%E3%82%92%E6%9B%B8%E3%81%84%E3%81%A6%E3%81%97%E3%81%BE%E3%81%84%E3%81%BE%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0474-answer

**ja-Q0475** — 母はパンを買いに町へいきました。

Mother went to town to get some bread.

Expected form: **ました**

Why: Polite past ending. [[Japanese#^ja-Q0475|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%AF%8D%E3%81%AF%E3%83%91%E3%83%B3%E3%82%92%E8%B2%B7%E3%81%84%E3%81%AB%E7%94%BA%E3%81%B8%E3%81%84%E3%81%8D%E3%81%BE%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0475-answer

**ja-Q0476** — 母はパンを買いに町へいきました。

Mother went to town to get some bread.

Expected form: **ました**

Why: Polite past ending. [[Japanese#^ja-Q0476|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%AF%8D%E3%81%AF%E3%83%91%E3%83%B3%E3%82%92%E8%B2%B7%E3%81%84%E3%81%AB%E7%94%BA%E3%81%B8%E3%81%84%E3%81%8D%E3%81%BE%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0476-answer

**ja-Q0477** — トムはメアリーについてあなたに話しましたか。

Did Tom talk to you about Mary?

Expected form: **ました**

Why: Polite past ending. [[Japanese#^ja-Q0477|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%83%88%E3%83%A0%E3%81%AF%E3%83%A1%E3%82%A2%E3%83%AA%E3%83%BC%E3%81%AB%E3%81%A4%E3%81%84%E3%81%A6%E3%81%82%E3%81%AA%E3%81%9F%E3%81%AB%E8%A9%B1%E3%81%97%E3%81%BE%E3%81%97%E3%81%9F%E3%81%8B%E3%80%82)
^ja-Q0477-answer

**ja-Q0478** — トムはメアリーについてあなたに話しましたか。

Did Tom talk to you about Mary?

Why: Polite past ending. [[Japanese#^ja-Q0478|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%83%88%E3%83%A0%E3%81%AF%E3%83%A1%E3%82%A2%E3%83%AA%E3%83%BC%E3%81%AB%E3%81%A4%E3%81%84%E3%81%A6%E3%81%82%E3%81%AA%E3%81%9F%E3%81%AB%E8%A9%B1%E3%81%97%E3%81%BE%E3%81%97%E3%81%9F%E3%81%8B%E3%80%82)
^ja-Q0478-answer

**ja-Q0479** — トムとジェーンは先月結婚しました。

Tom and Jane got married last month.

Why: Polite past ending. [[Japanese#^ja-Q0479|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%83%88%E3%83%A0%E3%81%A8%E3%82%B8%E3%82%A7%E3%83%BC%E3%83%B3%E3%81%AF%E5%85%88%E6%9C%88%E7%B5%90%E5%A9%9A%E3%81%97%E3%81%BE%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0479-answer

**ja-Q0480** — トムとジェーンは先月結婚しました。

Tom and Jane got married last month.

ました marks a polite affirmative past form. Recognise the verb stem and preceding complements before converting a sentence to past.

Why: Polite past ending. [[Japanese#^ja-Q0480|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%83%88%E3%83%A0%E3%81%A8%E3%82%B8%E3%82%A7%E3%83%BC%E3%83%B3%E3%81%AF%E5%85%88%E6%9C%88%E7%B5%90%E5%A9%9A%E3%81%97%E3%81%BE%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0480-answer

**ja-Q0481** — あなたが外出している間にこの手紙が着きました。

This letter arrived while you were out.

Expected form: **ました**

Why: Polite past ending. [[Japanese#^ja-Q0481|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%82%E3%81%AA%E3%81%9F%E3%81%8C%E5%A4%96%E5%87%BA%E3%81%97%E3%81%A6%E3%81%84%E3%82%8B%E9%96%93%E3%81%AB%E3%81%93%E3%81%AE%E6%89%8B%E7%B4%99%E3%81%8C%E7%9D%80%E3%81%8D%E3%81%BE%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0481-answer

**ja-Q0482** — あなたが外出している間にこの手紙が着きました。

This letter arrived while you were out.

Expected form: **ました**

Why: Polite past ending. [[Japanese#^ja-Q0482|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%82%E3%81%AA%E3%81%9F%E3%81%8C%E5%A4%96%E5%87%BA%E3%81%97%E3%81%A6%E3%81%84%E3%82%8B%E9%96%93%E3%81%AB%E3%81%93%E3%81%AE%E6%89%8B%E7%B4%99%E3%81%8C%E7%9D%80%E3%81%8D%E3%81%BE%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0482-answer

**ja-Q0483** — あなたは昨晩疲れていましたか。

Were you tired last night?

Expected form: **ました**

Why: Polite past ending. [[Japanese#^ja-Q0483|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%82%E3%81%AA%E3%81%9F%E3%81%AF%E6%98%A8%E6%99%A9%E7%96%B2%E3%82%8C%E3%81%A6%E3%81%84%E3%81%BE%E3%81%97%E3%81%9F%E3%81%8B%E3%80%82)
^ja-Q0483-answer

**ja-Q0484** — あなたは昨晩疲れていましたか。

Were you tired last night?

Why: Polite past ending. [[Japanese#^ja-Q0484|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%82%E3%81%AA%E3%81%9F%E3%81%AF%E6%98%A8%E6%99%A9%E7%96%B2%E3%82%8C%E3%81%A6%E3%81%84%E3%81%BE%E3%81%97%E3%81%9F%E3%81%8B%E3%80%82)
^ja-Q0484-answer

**ja-Q0485** — 何人社員が転部を申し込んできましたか。

How many staff members filed to change departments?

Why: Polite past ending. [[Japanese#^ja-Q0485|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E4%BD%95%E4%BA%BA%E7%A4%BE%E5%93%A1%E3%81%8C%E8%BB%A2%E9%83%A8%E3%82%92%E7%94%B3%E3%81%97%E8%BE%BC%E3%82%93%E3%81%A7%E3%81%8D%E3%81%BE%E3%81%97%E3%81%9F%E3%81%8B%E3%80%82)
^ja-Q0485-answer

**ja-Q0486** — 何人社員が転部を申し込んできましたか。

How many staff members filed to change departments?

ました marks a polite affirmative past form. Recognise the verb stem and preceding complements before converting a sentence to past.

Why: Polite past ending. [[Japanese#^ja-Q0486|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E4%BD%95%E4%BA%BA%E7%A4%BE%E5%93%A1%E3%81%8C%E8%BB%A2%E9%83%A8%E3%82%92%E7%94%B3%E3%81%97%E8%BE%BC%E3%82%93%E3%81%A7%E3%81%8D%E3%81%BE%E3%81%97%E3%81%9F%E3%81%8B%E3%80%82)
^ja-Q0486-answer

**ja-Q0487** — 今シーズン、インフルエンザの予防接種は受けましたか？

Did you receive your flu shot this season?

Expected form: **ました**

Why: Polite past ending. [[Japanese#^ja-Q0487|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E4%BB%8A%E3%82%B7%E3%83%BC%E3%82%BA%E3%83%B3%E3%80%81%E3%82%A4%E3%83%B3%E3%83%95%E3%83%AB%E3%82%A8%E3%83%B3%E3%82%B6%E3%81%AE%E4%BA%88%E9%98%B2%E6%8E%A5%E7%A8%AE%E3%81%AF%E5%8F%97%E3%81%91%E3%81%BE%E3%81%97%E3%81%9F%E3%81%8B%EF%BC%9F)
^ja-Q0487-answer

**ja-Q0488** — 今シーズン、インフルエンザの予防接種は受けましたか？

Did you receive your flu shot this season?

Expected form: **ました**

Why: Polite past ending. [[Japanese#^ja-Q0488|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E4%BB%8A%E3%82%B7%E3%83%BC%E3%82%BA%E3%83%B3%E3%80%81%E3%82%A4%E3%83%B3%E3%83%95%E3%83%AB%E3%82%A8%E3%83%B3%E3%82%B6%E3%81%AE%E4%BA%88%E9%98%B2%E6%8E%A5%E7%A8%AE%E3%81%AF%E5%8F%97%E3%81%91%E3%81%BE%E3%81%97%E3%81%9F%E3%81%8B%EF%BC%9F)
^ja-Q0488-answer

**ja-Q0489** — あなたはきのう放課後まっすぐ帰宅しましたか。

Did you go straight home after school yesterday?

Expected form: **ました**

Why: Polite past ending. [[Japanese#^ja-Q0489|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%82%E3%81%AA%E3%81%9F%E3%81%AF%E3%81%8D%E3%81%AE%E3%81%86%E6%94%BE%E8%AA%B2%E5%BE%8C%E3%81%BE%E3%81%A3%E3%81%99%E3%81%90%E5%B8%B0%E5%AE%85%E3%81%97%E3%81%BE%E3%81%97%E3%81%9F%E3%81%8B%E3%80%82)
^ja-Q0489-answer

**ja-Q0490** — あなたはきのう放課後まっすぐ帰宅しましたか。

Did you go straight home after school yesterday?

Why: Polite past ending. [[Japanese#^ja-Q0490|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%82%E3%81%AA%E3%81%9F%E3%81%AF%E3%81%8D%E3%81%AE%E3%81%86%E6%94%BE%E8%AA%B2%E5%BE%8C%E3%81%BE%E3%81%A3%E3%81%99%E3%81%90%E5%B8%B0%E5%AE%85%E3%81%97%E3%81%BE%E3%81%97%E3%81%9F%E3%81%8B%E3%80%82)
^ja-Q0490-answer

**ja-Q0491** — 彼女の笑い声が家にこだました。

Her laughter echoed through the house.

Why: Polite past ending. [[Japanese#^ja-Q0491|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E5%A5%B3%E3%81%AE%E7%AC%91%E3%81%84%E5%A3%B0%E3%81%8C%E5%AE%B6%E3%81%AB%E3%81%93%E3%81%A0%E3%81%BE%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0491-answer

**ja-Q0492** — 彼女の笑い声が家にこだました。

Her laughter echoed through the house.

ました marks a polite affirmative past form. Recognise the verb stem and preceding complements before converting a sentence to past.

Why: Polite past ending. [[Japanese#^ja-Q0492|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E5%A5%B3%E3%81%AE%E7%AC%91%E3%81%84%E5%A3%B0%E3%81%8C%E5%AE%B6%E3%81%AB%E3%81%93%E3%81%A0%E3%81%BE%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0492-answer

**ja-Q0493** — 山田氏は大変親切だったので、私を車で家まで送ってくれました。

Mr Yamada was kind enough to drive me home.

Expected form: **ました**

Why: Polite past ending. [[Japanese#^ja-Q0493|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%B1%B1%E7%94%B0%E6%B0%8F%E3%81%AF%E5%A4%A7%E5%A4%89%E8%A6%AA%E5%88%87%E3%81%A0%E3%81%A3%E3%81%9F%E3%81%AE%E3%81%A7%E3%80%81%E7%A7%81%E3%82%92%E8%BB%8A%E3%81%A7%E5%AE%B6%E3%81%BE%E3%81%A7%E9%80%81%E3%81%A3%E3%81%A6%E3%81%8F%E3%82%8C%E3%81%BE%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0493-answer

**ja-Q0494** — 山田氏は大変親切だったので、私を車で家まで送ってくれました。

Mr Yamada was kind enough to drive me home.

Expected form: **ました**

Why: Polite past ending. [[Japanese#^ja-Q0494|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%B1%B1%E7%94%B0%E6%B0%8F%E3%81%AF%E5%A4%A7%E5%A4%89%E8%A6%AA%E5%88%87%E3%81%A0%E3%81%A3%E3%81%9F%E3%81%AE%E3%81%A7%E3%80%81%E7%A7%81%E3%82%92%E8%BB%8A%E3%81%A7%E5%AE%B6%E3%81%BE%E3%81%A7%E9%80%81%E3%81%A3%E3%81%A6%E3%81%8F%E3%82%8C%E3%81%BE%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0494-answer

**ja-Q0495** — 万次郎はこの二国をお互いに親しくするために一役果たしました。

Manjiro played a part in making the two countries friends with each other.

Expected form: **ました**

Why: Polite past ending. [[Japanese#^ja-Q0495|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E4%B8%87%E6%AC%A1%E9%83%8E%E3%81%AF%E3%81%93%E3%81%AE%E4%BA%8C%E5%9B%BD%E3%82%92%E3%81%8A%E4%BA%92%E3%81%84%E3%81%AB%E8%A6%AA%E3%81%97%E3%81%8F%E3%81%99%E3%82%8B%E3%81%9F%E3%82%81%E3%81%AB%E4%B8%80%E5%BD%B9%E6%9E%9C%E3%81%9F%E3%81%97%E3%81%BE%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0495-answer

**ja-Q0496** — 万次郎はこの二国をお互いに親しくするために一役果たしました。

Manjiro played a part in making the two countries friends with each other.

Why: Polite past ending. [[Japanese#^ja-Q0496|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E4%B8%87%E6%AC%A1%E9%83%8E%E3%81%AF%E3%81%93%E3%81%AE%E4%BA%8C%E5%9B%BD%E3%82%92%E3%81%8A%E4%BA%92%E3%81%84%E3%81%AB%E8%A6%AA%E3%81%97%E3%81%8F%E3%81%99%E3%82%8B%E3%81%9F%E3%82%81%E3%81%AB%E4%B8%80%E5%BD%B9%E6%9E%9C%E3%81%9F%E3%81%97%E3%81%BE%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0496-answer

**ja-Q0497** — こないだ先生と道で会いました。

I met my teacher on the street the other day.

Why: Polite past ending. [[Japanese#^ja-Q0497|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%93%E3%81%AA%E3%81%84%E3%81%A0%E5%85%88%E7%94%9F%E3%81%A8%E9%81%93%E3%81%A7%E4%BC%9A%E3%81%84%E3%81%BE%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0497-answer

**ja-Q0498** — こないだ先生と道で会いました。

I met my teacher on the street the other day.

ました marks a polite affirmative past form. Recognise the verb stem and preceding complements before converting a sentence to past.

Why: Polite past ending. [[Japanese#^ja-Q0498|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%93%E3%81%AA%E3%81%84%E3%81%A0%E5%85%88%E7%94%9F%E3%81%A8%E9%81%93%E3%81%A7%E4%BC%9A%E3%81%84%E3%81%BE%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0498-answer

**ja-Q0499** — 最近、胸の痛みはありましたか？

Have you had chest pain recently?

Expected form: **ました**

Why: Polite past ending. [[Japanese#^ja-Q0499|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%9C%80%E8%BF%91%E3%80%81%E8%83%B8%E3%81%AE%E7%97%9B%E3%81%BF%E3%81%AF%E3%81%82%E3%82%8A%E3%81%BE%E3%81%97%E3%81%9F%E3%81%8B%EF%BC%9F)
^ja-Q0499-answer

**ja-Q0500** — 最近、胸の痛みはありましたか？

Have you had chest pain recently?

Expected form: **ました**

Why: Polite past ending. [[Japanese#^ja-Q0500|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%9C%80%E8%BF%91%E3%80%81%E8%83%B8%E3%81%AE%E7%97%9B%E3%81%BF%E3%81%AF%E3%81%82%E3%82%8A%E3%81%BE%E3%81%97%E3%81%9F%E3%81%8B%EF%BC%9F)
^ja-Q0500-answer


### Answers 501–550

**ja-Q0501** — 彼女は私にお金を返してくれませんでした。

She didn't give me my money back.

Expected form: **ません**

Why: Polite negation. [[Japanese#^ja-Q0501|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E5%A5%B3%E3%81%AF%E7%A7%81%E3%81%AB%E3%81%8A%E9%87%91%E3%82%92%E8%BF%94%E3%81%97%E3%81%A6%E3%81%8F%E3%82%8C%E3%81%BE%E3%81%9B%E3%82%93%E3%81%A7%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0501-answer

**ja-Q0502** — 彼女は私にお金を返してくれませんでした。

She didn't give me my money back.

Why: Polite negation. [[Japanese#^ja-Q0502|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E5%A5%B3%E3%81%AF%E7%A7%81%E3%81%AB%E3%81%8A%E9%87%91%E3%82%92%E8%BF%94%E3%81%97%E3%81%A6%E3%81%8F%E3%82%8C%E3%81%BE%E3%81%9B%E3%82%93%E3%81%A7%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0502-answer

**ja-Q0503** — 駅までの行き方を教えていただけませんか。

Could you tell me how to get to the station?

Why: Polite negation. [[Japanese#^ja-Q0503|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E9%A7%85%E3%81%BE%E3%81%A7%E3%81%AE%E8%A1%8C%E3%81%8D%E6%96%B9%E3%82%92%E6%95%99%E3%81%88%E3%81%A6%E3%81%84%E3%81%9F%E3%81%A0%E3%81%91%E3%81%BE%E3%81%9B%E3%82%93%E3%81%8B%E3%80%82)
^ja-Q0503-answer

**ja-Q0504** — 駅までの行き方を教えていただけませんか。

Could you tell me how to get to the station?

ません marks a polite non-past negative. Past polite negative commonly uses ませんでした. The negative form also participates in some invitations/questions.

Why: Polite negation. [[Japanese#^ja-Q0504|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E9%A7%85%E3%81%BE%E3%81%A7%E3%81%AE%E8%A1%8C%E3%81%8D%E6%96%B9%E3%82%92%E6%95%99%E3%81%88%E3%81%A6%E3%81%84%E3%81%9F%E3%81%A0%E3%81%91%E3%81%BE%E3%81%9B%E3%82%93%E3%81%8B%E3%80%82)
^ja-Q0504-answer

**ja-Q0505** — 抜歯しなければなりません。

Your tooth must be extracted.

Expected form: **ません**

Why: Polite negation. [[Japanese#^ja-Q0505|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%8A%9C%E6%AD%AF%E3%81%97%E3%81%AA%E3%81%91%E3%82%8C%E3%81%B0%E3%81%AA%E3%82%8A%E3%81%BE%E3%81%9B%E3%82%93%E3%80%82)
^ja-Q0505-answer

**ja-Q0506** — 抜歯しなければなりません。

Your tooth must be extracted.

Expected form: **ません**

Why: Polite negation. [[Japanese#^ja-Q0506|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%8A%9C%E6%AD%AF%E3%81%97%E3%81%AA%E3%81%91%E3%82%8C%E3%81%B0%E3%81%AA%E3%82%8A%E3%81%BE%E3%81%9B%E3%82%93%E3%80%82)
^ja-Q0506-answer

**ja-Q0507** — 私は今ではそれについてなにも覚えていません。

I have no remembrance of it now.

Expected form: **ません**

Why: Polite negation. [[Japanese#^ja-Q0507|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AF%E4%BB%8A%E3%81%A7%E3%81%AF%E3%81%9D%E3%82%8C%E3%81%AB%E3%81%A4%E3%81%84%E3%81%A6%E3%81%AA%E3%81%AB%E3%82%82%E8%A6%9A%E3%81%88%E3%81%A6%E3%81%84%E3%81%BE%E3%81%9B%E3%82%93%E3%80%82)
^ja-Q0507-answer

**ja-Q0508** — 私は今ではそれについてなにも覚えていません。

I have no remembrance of it now.

Why: Polite negation. [[Japanese#^ja-Q0508|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AF%E4%BB%8A%E3%81%A7%E3%81%AF%E3%81%9D%E3%82%8C%E3%81%AB%E3%81%A4%E3%81%84%E3%81%A6%E3%81%AA%E3%81%AB%E3%82%82%E8%A6%9A%E3%81%88%E3%81%A6%E3%81%84%E3%81%BE%E3%81%9B%E3%82%93%E3%80%82)
^ja-Q0508-answer

**ja-Q0509** — 彼は医者ではありません。

He is not a doctor.

Why: Polite negation. [[Japanese#^ja-Q0509|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%AF%E5%8C%BB%E8%80%85%E3%81%A7%E3%81%AF%E3%81%82%E3%82%8A%E3%81%BE%E3%81%9B%E3%82%93%E3%80%82)
^ja-Q0509-answer

**ja-Q0510** — 彼は医者ではありません。

He is not a doctor.

ません marks a polite non-past negative. Past polite negative commonly uses ませんでした. The negative form also participates in some invitations/questions.

Why: Polite negation. [[Japanese#^ja-Q0510|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%AF%E5%8C%BB%E8%80%85%E3%81%A7%E3%81%AF%E3%81%82%E3%82%8A%E3%81%BE%E3%81%9B%E3%82%93%E3%80%82)
^ja-Q0510-answer

**ja-Q0511** — あまり彼に会いません。

I don't see much of him.

Expected form: **ません**

Why: Polite negation. [[Japanese#^ja-Q0511|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%82%E3%81%BE%E3%82%8A%E5%BD%BC%E3%81%AB%E4%BC%9A%E3%81%84%E3%81%BE%E3%81%9B%E3%82%93%E3%80%82)
^ja-Q0511-answer

**ja-Q0512** — あまり彼に会いません。

I don't see much of him.

Expected form: **ません**

Why: Polite negation. [[Japanese#^ja-Q0512|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%82%E3%81%BE%E3%82%8A%E5%BD%BC%E3%81%AB%E4%BC%9A%E3%81%84%E3%81%BE%E3%81%9B%E3%82%93%E3%80%82)
^ja-Q0512-answer

**ja-Q0513** — あなたのおっしゃることが、どうもよく分かりません。

I don't quite follow you.

Expected form: **ません**

Why: Polite negation. [[Japanese#^ja-Q0513|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%82%E3%81%AA%E3%81%9F%E3%81%AE%E3%81%8A%E3%81%A3%E3%81%97%E3%82%83%E3%82%8B%E3%81%93%E3%81%A8%E3%81%8C%E3%80%81%E3%81%A9%E3%81%86%E3%82%82%E3%82%88%E3%81%8F%E5%88%86%E3%81%8B%E3%82%8A%E3%81%BE%E3%81%9B%E3%82%93%E3%80%82)
^ja-Q0513-answer

**ja-Q0514** — あなたのおっしゃることが、どうもよく分かりません。

I don't quite follow you.

Why: Polite negation. [[Japanese#^ja-Q0514|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%82%E3%81%AA%E3%81%9F%E3%81%AE%E3%81%8A%E3%81%A3%E3%81%97%E3%82%83%E3%82%8B%E3%81%93%E3%81%A8%E3%81%8C%E3%80%81%E3%81%A9%E3%81%86%E3%82%82%E3%82%88%E3%81%8F%E5%88%86%E3%81%8B%E3%82%8A%E3%81%BE%E3%81%9B%E3%82%93%E3%80%82)
^ja-Q0514-answer

**ja-Q0515** — 寒いです。どうか窓を閉めてくださいませんか。

It's cold. Could you close the window?

Why: Polite negation. [[Japanese#^ja-Q0515|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%AF%92%E3%81%84%E3%81%A7%E3%81%99%E3%80%82%E3%81%A9%E3%81%86%E3%81%8B%E7%AA%93%E3%82%92%E9%96%89%E3%82%81%E3%81%A6%E3%81%8F%E3%81%A0%E3%81%95%E3%81%84%E3%81%BE%E3%81%9B%E3%82%93%E3%81%8B%E3%80%82)
^ja-Q0515-answer

**ja-Q0516** — 寒いです。どうか窓を閉めてくださいませんか。

It's cold. Could you close the window?

ません marks a polite non-past negative. Past polite negative commonly uses ませんでした. The negative form also participates in some invitations/questions.

Why: Polite negation. [[Japanese#^ja-Q0516|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%AF%92%E3%81%84%E3%81%A7%E3%81%99%E3%80%82%E3%81%A9%E3%81%86%E3%81%8B%E7%AA%93%E3%82%92%E9%96%89%E3%82%81%E3%81%A6%E3%81%8F%E3%81%A0%E3%81%95%E3%81%84%E3%81%BE%E3%81%9B%E3%82%93%E3%81%8B%E3%80%82)
^ja-Q0516-answer

**ja-Q0517** — トムがボストンに到着してから、まだ三週間は経っていません。

Tom arrived in Boston less than three weeks ago.

Expected form: **ません**

Why: Polite negation. [[Japanese#^ja-Q0517|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%83%88%E3%83%A0%E3%81%8C%E3%83%9C%E3%82%B9%E3%83%88%E3%83%B3%E3%81%AB%E5%88%B0%E7%9D%80%E3%81%97%E3%81%A6%E3%81%8B%E3%82%89%E3%80%81%E3%81%BE%E3%81%A0%E4%B8%89%E9%80%B1%E9%96%93%E3%81%AF%E7%B5%8C%E3%81%A3%E3%81%A6%E3%81%84%E3%81%BE%E3%81%9B%E3%82%93%E3%80%82)
^ja-Q0517-answer

**ja-Q0518** — トムがボストンに到着してから、まだ三週間は経っていません。

Tom arrived in Boston less than three weeks ago.

Expected form: **ません**

Why: Polite negation. [[Japanese#^ja-Q0518|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%83%88%E3%83%A0%E3%81%8C%E3%83%9C%E3%82%B9%E3%83%88%E3%83%B3%E3%81%AB%E5%88%B0%E7%9D%80%E3%81%97%E3%81%A6%E3%81%8B%E3%82%89%E3%80%81%E3%81%BE%E3%81%A0%E4%B8%89%E9%80%B1%E9%96%93%E3%81%AF%E7%B5%8C%E3%81%A3%E3%81%A6%E3%81%84%E3%81%BE%E3%81%9B%E3%82%93%E3%80%82)
^ja-Q0518-answer

**ja-Q0519** — そんなに遅くまで外出していてはいけません。

You mustn't stay out that late.

Expected form: **ません**

Why: Polite negation. [[Japanese#^ja-Q0519|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%9D%E3%82%93%E3%81%AA%E3%81%AB%E9%81%85%E3%81%8F%E3%81%BE%E3%81%A7%E5%A4%96%E5%87%BA%E3%81%97%E3%81%A6%E3%81%84%E3%81%A6%E3%81%AF%E3%81%84%E3%81%91%E3%81%BE%E3%81%9B%E3%82%93%E3%80%82)
^ja-Q0519-answer

**ja-Q0520** — そんなに遅くまで外出していてはいけません。

You mustn't stay out that late.

Why: Polite negation. [[Japanese#^ja-Q0520|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%9D%E3%82%93%E3%81%AA%E3%81%AB%E9%81%85%E3%81%8F%E3%81%BE%E3%81%A7%E5%A4%96%E5%87%BA%E3%81%97%E3%81%A6%E3%81%84%E3%81%A6%E3%81%AF%E3%81%84%E3%81%91%E3%81%BE%E3%81%9B%E3%82%93%E3%80%82)
^ja-Q0520-answer

**ja-Q0521** — 十分にお金があるかわかりません。

I don't know if I have enough money.

Why: Polite negation. [[Japanese#^ja-Q0521|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%8D%81%E5%88%86%E3%81%AB%E3%81%8A%E9%87%91%E3%81%8C%E3%81%82%E3%82%8B%E3%81%8B%E3%82%8F%E3%81%8B%E3%82%8A%E3%81%BE%E3%81%9B%E3%82%93%E3%80%82)
^ja-Q0521-answer

**ja-Q0522** — 十分にお金があるかわかりません。

I don't know if I have enough money.

ません marks a polite non-past negative. Past polite negative commonly uses ませんでした. The negative form also participates in some invitations/questions.

Why: Polite negation. [[Japanese#^ja-Q0522|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%8D%81%E5%88%86%E3%81%AB%E3%81%8A%E9%87%91%E3%81%8C%E3%81%82%E3%82%8B%E3%81%8B%E3%82%8F%E3%81%8B%E3%82%8A%E3%81%BE%E3%81%9B%E3%82%93%E3%80%82)
^ja-Q0522-answer

**ja-Q0523** — ペンがなければ鉛筆でもかまいません。

If you don't have a pen, use a pencil.

Expected form: **ません**

Why: Polite negation. [[Japanese#^ja-Q0523|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%83%9A%E3%83%B3%E3%81%8C%E3%81%AA%E3%81%91%E3%82%8C%E3%81%B0%E9%89%9B%E7%AD%86%E3%81%A7%E3%82%82%E3%81%8B%E3%81%BE%E3%81%84%E3%81%BE%E3%81%9B%E3%82%93%E3%80%82)
^ja-Q0523-answer

**ja-Q0524** — ペンがなければ鉛筆でもかまいません。

If you don't have a pen, use a pencil.

Expected form: **ません**

Why: Polite negation. [[Japanese#^ja-Q0524|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%83%9A%E3%83%B3%E3%81%8C%E3%81%AA%E3%81%91%E3%82%8C%E3%81%B0%E9%89%9B%E7%AD%86%E3%81%A7%E3%82%82%E3%81%8B%E3%81%BE%E3%81%84%E3%81%BE%E3%81%9B%E3%82%93%E3%80%82)
^ja-Q0524-answer

**ja-Q0525** — すみませんが、郵便局はどこでしょうか。

Excuse me, but could you tell me where the post office is?

Expected form: **ません**

Why: Polite negation. [[Japanese#^ja-Q0525|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%99%E3%81%BF%E3%81%BE%E3%81%9B%E3%82%93%E3%81%8C%E3%80%81%E9%83%B5%E4%BE%BF%E5%B1%80%E3%81%AF%E3%81%A9%E3%81%93%E3%81%A7%E3%81%97%E3%82%87%E3%81%86%E3%81%8B%E3%80%82)
^ja-Q0525-answer

**ja-Q0526** — すみませんが、郵便局はどこでしょうか。

Excuse me, but could you tell me where the post office is?

Why: Polite negation. [[Japanese#^ja-Q0526|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%99%E3%81%BF%E3%81%BE%E3%81%9B%E3%82%93%E3%81%8C%E3%80%81%E9%83%B5%E4%BE%BF%E5%B1%80%E3%81%AF%E3%81%A9%E3%81%93%E3%81%A7%E3%81%97%E3%82%87%E3%81%86%E3%81%8B%E3%80%82)
^ja-Q0526-answer

**ja-Q0527** — 京子がどこに住んでいるのか正確にはしりませんが、三ノ宮の方です。

I don't know exactly where Kyoko lives, but it's in the direction of Sannomiya.

Why: Polite negation. [[Japanese#^ja-Q0527|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E4%BA%AC%E5%AD%90%E3%81%8C%E3%81%A9%E3%81%93%E3%81%AB%E4%BD%8F%E3%82%93%E3%81%A7%E3%81%84%E3%82%8B%E3%81%AE%E3%81%8B%E6%AD%A3%E7%A2%BA%E3%81%AB%E3%81%AF%E3%81%97%E3%82%8A%E3%81%BE%E3%81%9B%E3%82%93%E3%81%8C%E3%80%81%E4%B8%89%E3%83%8E%E5%AE%AE%E3%81%AE%E6%96%B9%E3%81%A7%E3%81%99%E3%80%82)
^ja-Q0527-answer

**ja-Q0528** — 京子がどこに住んでいるのか正確にはしりませんが、三ノ宮の方です。

I don't know exactly where Kyoko lives, but it's in the direction of Sannomiya.

ません marks a polite non-past negative. Past polite negative commonly uses ませんでした. The negative form also participates in some invitations/questions.

Why: Polite negation. [[Japanese#^ja-Q0528|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E4%BA%AC%E5%AD%90%E3%81%8C%E3%81%A9%E3%81%93%E3%81%AB%E4%BD%8F%E3%82%93%E3%81%A7%E3%81%84%E3%82%8B%E3%81%AE%E3%81%8B%E6%AD%A3%E7%A2%BA%E3%81%AB%E3%81%AF%E3%81%97%E3%82%8A%E3%81%BE%E3%81%9B%E3%82%93%E3%81%8C%E3%80%81%E4%B8%89%E3%83%8E%E5%AE%AE%E3%81%AE%E6%96%B9%E3%81%A7%E3%81%99%E3%80%82)
^ja-Q0528-answer

**ja-Q0529** — そのことについてもう少し例をあげてくれませんか。

Could you please give me some more examples of that?

Expected form: **ません**

Why: Polite negation. [[Japanese#^ja-Q0529|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%9D%E3%81%AE%E3%81%93%E3%81%A8%E3%81%AB%E3%81%A4%E3%81%84%E3%81%A6%E3%82%82%E3%81%86%E5%B0%91%E3%81%97%E4%BE%8B%E3%82%92%E3%81%82%E3%81%92%E3%81%A6%E3%81%8F%E3%82%8C%E3%81%BE%E3%81%9B%E3%82%93%E3%81%8B%E3%80%82)
^ja-Q0529-answer

**ja-Q0530** — そのことについてもう少し例をあげてくれませんか。

Could you please give me some more examples of that?

Expected form: **ません**

Why: Polite negation. [[Japanese#^ja-Q0530|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%9D%E3%81%AE%E3%81%93%E3%81%A8%E3%81%AB%E3%81%A4%E3%81%84%E3%81%A6%E3%82%82%E3%81%86%E5%B0%91%E3%81%97%E4%BE%8B%E3%82%92%E3%81%82%E3%81%92%E3%81%A6%E3%81%8F%E3%82%8C%E3%81%BE%E3%81%9B%E3%82%93%E3%81%8B%E3%80%82)
^ja-Q0530-answer

**ja-Q0531** — 溶岩を地理学的に説明してくれませんか。

Can you give me a geological explanation of lava?

Expected form: **ません**

Why: Polite negation. [[Japanese#^ja-Q0531|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%BA%B6%E5%B2%A9%E3%82%92%E5%9C%B0%E7%90%86%E5%AD%A6%E7%9A%84%E3%81%AB%E8%AA%AC%E6%98%8E%E3%81%97%E3%81%A6%E3%81%8F%E3%82%8C%E3%81%BE%E3%81%9B%E3%82%93%E3%81%8B%E3%80%82)
^ja-Q0531-answer

**ja-Q0532** — 溶岩を地理学的に説明してくれませんか。

Can you give me a geological explanation of lava?

Why: Polite negation. [[Japanese#^ja-Q0532|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%BA%B6%E5%B2%A9%E3%82%92%E5%9C%B0%E7%90%86%E5%AD%A6%E7%9A%84%E3%81%AB%E8%AA%AC%E6%98%8E%E3%81%97%E3%81%A6%E3%81%8F%E3%82%8C%E3%81%BE%E3%81%9B%E3%82%93%E3%81%8B%E3%80%82)
^ja-Q0532-answer

**ja-Q0533** — 手紙の返事を延ばしてはいけません。

Don't put off answering the letter.

Why: Polite negation. [[Japanese#^ja-Q0533|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%89%8B%E7%B4%99%E3%81%AE%E8%BF%94%E4%BA%8B%E3%82%92%E5%BB%B6%E3%81%B0%E3%81%97%E3%81%A6%E3%81%AF%E3%81%84%E3%81%91%E3%81%BE%E3%81%9B%E3%82%93%E3%80%82)
^ja-Q0533-answer

**ja-Q0534** — 手紙の返事を延ばしてはいけません。

Don't put off answering the letter.

ません marks a polite non-past negative. Past polite negative commonly uses ませんでした. The negative form also participates in some invitations/questions.

Why: Polite negation. [[Japanese#^ja-Q0534|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%89%8B%E7%B4%99%E3%81%AE%E8%BF%94%E4%BA%8B%E3%82%92%E5%BB%B6%E3%81%B0%E3%81%97%E3%81%A6%E3%81%AF%E3%81%84%E3%81%91%E3%81%BE%E3%81%9B%E3%82%93%E3%80%82)
^ja-Q0534-answer

**ja-Q0535** — 糸車の使い方は知りません。

I don't know how to operate a spinning wheel.

Expected form: **ません**

Why: Polite negation. [[Japanese#^ja-Q0535|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%B3%B8%E8%BB%8A%E3%81%AE%E4%BD%BF%E3%81%84%E6%96%B9%E3%81%AF%E7%9F%A5%E3%82%8A%E3%81%BE%E3%81%9B%E3%82%93%E3%80%82)
^ja-Q0535-answer

**ja-Q0536** — 糸車の使い方は知りません。

I don't know how to operate a spinning wheel.

Expected form: **ません**

Why: Polite negation. [[Japanese#^ja-Q0536|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%B3%B8%E8%BB%8A%E3%81%AE%E4%BD%BF%E3%81%84%E6%96%B9%E3%81%AF%E7%9F%A5%E3%82%8A%E3%81%BE%E3%81%9B%E3%82%93%E3%80%82)
^ja-Q0536-answer

**ja-Q0537** — 会議室の椅子が足りません。

There are not enough chairs in the meeting room.

Expected form: **ません**

Why: Polite negation. [[Japanese#^ja-Q0537|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E4%BC%9A%E8%AD%B0%E5%AE%A4%E3%81%AE%E6%A4%85%E5%AD%90%E3%81%8C%E8%B6%B3%E3%82%8A%E3%81%BE%E3%81%9B%E3%82%93%E3%80%82)
^ja-Q0537-answer

**ja-Q0538** — 会議室の椅子が足りません。

There are not enough chairs in the meeting room.

Why: Polite negation. [[Japanese#^ja-Q0538|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E4%BC%9A%E8%AD%B0%E5%AE%A4%E3%81%AE%E6%A4%85%E5%AD%90%E3%81%8C%E8%B6%B3%E3%82%8A%E3%81%BE%E3%81%9B%E3%82%93%E3%80%82)
^ja-Q0538-answer

**ja-Q0539** — この黄色いセーターを着てみませんか。

Why don't you try on this yellow sweater?

Why: Polite negation. [[Japanese#^ja-Q0539|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%93%E3%81%AE%E9%BB%84%E8%89%B2%E3%81%84%E3%82%BB%E3%83%BC%E3%82%BF%E3%83%BC%E3%82%92%E7%9D%80%E3%81%A6%E3%81%BF%E3%81%BE%E3%81%9B%E3%82%93%E3%81%8B%E3%80%82)
^ja-Q0539-answer

**ja-Q0540** — この黄色いセーターを着てみませんか。

Why don't you try on this yellow sweater?

ません marks a polite non-past negative. Past polite negative commonly uses ませんでした. The negative form also participates in some invitations/questions.

Why: Polite negation. [[Japanese#^ja-Q0540|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%93%E3%81%AE%E9%BB%84%E8%89%B2%E3%81%84%E3%82%BB%E3%83%BC%E3%82%BF%E3%83%BC%E3%82%92%E7%9D%80%E3%81%A6%E3%81%BF%E3%81%BE%E3%81%9B%E3%82%93%E3%81%8B%E3%80%82)
^ja-Q0540-answer

**ja-Q0541** — 今晩一緒に食事をしませんか。

Why don't you have dinner with me tonight?

Expected form: **ません**

Why: Polite negation. [[Japanese#^ja-Q0541|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E4%BB%8A%E6%99%A9%E4%B8%80%E7%B7%92%E3%81%AB%E9%A3%9F%E4%BA%8B%E3%82%92%E3%81%97%E3%81%BE%E3%81%9B%E3%82%93%E3%81%8B%E3%80%82)
^ja-Q0541-answer

**ja-Q0542** — 今晩一緒に食事をしませんか。

Why don't you have dinner with me tonight?

Expected form: **ません**

Why: Polite negation. [[Japanese#^ja-Q0542|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E4%BB%8A%E6%99%A9%E4%B8%80%E7%B7%92%E3%81%AB%E9%A3%9F%E4%BA%8B%E3%82%92%E3%81%97%E3%81%BE%E3%81%9B%E3%82%93%E3%81%8B%E3%80%82)
^ja-Q0542-answer

**ja-Q0543** — トイレの水が流れません。

The toilet doesn't flush.

Expected form: **ません**

Why: Polite negation. [[Japanese#^ja-Q0543|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%83%88%E3%82%A4%E3%83%AC%E3%81%AE%E6%B0%B4%E3%81%8C%E6%B5%81%E3%82%8C%E3%81%BE%E3%81%9B%E3%82%93%E3%80%82)
^ja-Q0543-answer

**ja-Q0544** — トイレの水が流れません。

The toilet doesn't flush.

Why: Polite negation. [[Japanese#^ja-Q0544|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%83%88%E3%82%A4%E3%83%AC%E3%81%AE%E6%B0%B4%E3%81%8C%E6%B5%81%E3%82%8C%E3%81%BE%E3%81%9B%E3%82%93%E3%80%82)
^ja-Q0544-answer

**ja-Q0545** — もしあなたが成功したいなら、もっと働かなければなりません。

If you are to succeed, you must work harder.

Why: Polite negation. [[Japanese#^ja-Q0545|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%82%82%E3%81%97%E3%81%82%E3%81%AA%E3%81%9F%E3%81%8C%E6%88%90%E5%8A%9F%E3%81%97%E3%81%9F%E3%81%84%E3%81%AA%E3%82%89%E3%80%81%E3%82%82%E3%81%A3%E3%81%A8%E5%83%8D%E3%81%8B%E3%81%AA%E3%81%91%E3%82%8C%E3%81%B0%E3%81%AA%E3%82%8A%E3%81%BE%E3%81%9B%E3%82%93%E3%80%82)
^ja-Q0545-answer

**ja-Q0546** — もしあなたが成功したいなら、もっと働かなければなりません。

If you are to succeed, you must work harder.

ません marks a polite non-past negative. Past polite negative commonly uses ませんでした. The negative form also participates in some invitations/questions.

Why: Polite negation. [[Japanese#^ja-Q0546|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%82%82%E3%81%97%E3%81%82%E3%81%AA%E3%81%9F%E3%81%8C%E6%88%90%E5%8A%9F%E3%81%97%E3%81%9F%E3%81%84%E3%81%AA%E3%82%89%E3%80%81%E3%82%82%E3%81%A3%E3%81%A8%E5%83%8D%E3%81%8B%E3%81%AA%E3%81%91%E3%82%8C%E3%81%B0%E3%81%AA%E3%82%8A%E3%81%BE%E3%81%9B%E3%82%93%E3%80%82)
^ja-Q0546-answer

**ja-Q0547** — はっきり言うと、私は彼と一緒に働きたくありません。

Frankly speaking, I don't want to work with him.

Expected form: **ません**

Why: Polite negation. [[Japanese#^ja-Q0547|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%AF%E3%81%A3%E3%81%8D%E3%82%8A%E8%A8%80%E3%81%86%E3%81%A8%E3%80%81%E7%A7%81%E3%81%AF%E5%BD%BC%E3%81%A8%E4%B8%80%E7%B7%92%E3%81%AB%E5%83%8D%E3%81%8D%E3%81%9F%E3%81%8F%E3%81%82%E3%82%8A%E3%81%BE%E3%81%9B%E3%82%93%E3%80%82)
^ja-Q0547-answer

**ja-Q0548** — はっきり言うと、私は彼と一緒に働きたくありません。

Frankly speaking, I don't want to work with him.

Expected form: **ません**

Why: Polite negation. [[Japanese#^ja-Q0548|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%AF%E3%81%A3%E3%81%8D%E3%82%8A%E8%A8%80%E3%81%86%E3%81%A8%E3%80%81%E7%A7%81%E3%81%AF%E5%BD%BC%E3%81%A8%E4%B8%80%E7%B7%92%E3%81%AB%E5%83%8D%E3%81%8D%E3%81%9F%E3%81%8F%E3%81%82%E3%82%8A%E3%81%BE%E3%81%9B%E3%82%93%E3%80%82)
^ja-Q0548-answer

**ja-Q0549** — 彼女がどうしてその犯罪に及んだかという動機については、いまだによくわかりません。

They still haven't been able to work out quite what her motive was for resorting to crime.

Expected form: **ません**

Why: Polite negation. [[Japanese#^ja-Q0549|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E5%A5%B3%E3%81%8C%E3%81%A9%E3%81%86%E3%81%97%E3%81%A6%E3%81%9D%E3%81%AE%E7%8A%AF%E7%BD%AA%E3%81%AB%E5%8F%8A%E3%82%93%E3%81%A0%E3%81%8B%E3%81%A8%E3%81%84%E3%81%86%E5%8B%95%E6%A9%9F%E3%81%AB%E3%81%A4%E3%81%84%E3%81%A6%E3%81%AF%E3%80%81%E3%81%84%E3%81%BE%E3%81%A0%E3%81%AB%E3%82%88%E3%81%8F%E3%82%8F%E3%81%8B%E3%82%8A%E3%81%BE%E3%81%9B%E3%82%93%E3%80%82)
^ja-Q0549-answer

**ja-Q0550** — 彼女がどうしてその犯罪に及んだかという動機については、いまだによくわかりません。

They still haven't been able to work out quite what her motive was for resorting to crime.

Why: Polite negation. [[Japanese#^ja-Q0550|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E5%A5%B3%E3%81%8C%E3%81%A9%E3%81%86%E3%81%97%E3%81%A6%E3%81%9D%E3%81%AE%E7%8A%AF%E7%BD%AA%E3%81%AB%E5%8F%8A%E3%82%93%E3%81%A0%E3%81%8B%E3%81%A8%E3%81%84%E3%81%86%E5%8B%95%E6%A9%9F%E3%81%AB%E3%81%A4%E3%81%84%E3%81%A6%E3%81%AF%E3%80%81%E3%81%84%E3%81%BE%E3%81%A0%E3%81%AB%E3%82%88%E3%81%8F%E3%82%8F%E3%81%8B%E3%82%8A%E3%81%BE%E3%81%9B%E3%82%93%E3%80%82)
^ja-Q0550-answer


### Answers 551–600

**ja-Q0551** — 私をどなり散らす人は気にならないわ。

The ones who shout at me don't bother me.

Why: Plain negation. [[Japanese#^ja-Q0551|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%82%92%E3%81%A9%E3%81%AA%E3%82%8A%E6%95%A3%E3%82%89%E3%81%99%E4%BA%BA%E3%81%AF%E6%B0%97%E3%81%AB%E3%81%AA%E3%82%89%E3%81%AA%E3%81%84%E3%82%8F%E3%80%82)
^ja-Q0551-answer

**ja-Q0552** — 私をどなり散らす人は気にならないわ。

The ones who shout at me don't bother me.

Plain negative verbs commonly end in ない with class-dependent stem changes. Some adjectives and copulas have their own negative constructions. Do not attach ない indiscriminately to every dictionary form.

Why: Plain negation. [[Japanese#^ja-Q0552|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%82%92%E3%81%A9%E3%81%AA%E3%82%8A%E6%95%A3%E3%82%89%E3%81%99%E4%BA%BA%E3%81%AF%E6%B0%97%E3%81%AB%E3%81%AA%E3%82%89%E3%81%AA%E3%81%84%E3%82%8F%E3%80%82)
^ja-Q0552-answer

**ja-Q0553** — そのなぞなぞの解き方が解らない。

I can't figure out how to solve the puzzle.

Expected form: **ない**

Why: Plain negation. [[Japanese#^ja-Q0553|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%9D%E3%81%AE%E3%81%AA%E3%81%9E%E3%81%AA%E3%81%9E%E3%81%AE%E8%A7%A3%E3%81%8D%E6%96%B9%E3%81%8C%E8%A7%A3%E3%82%89%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0553-answer

**ja-Q0554** — そのなぞなぞの解き方が解らない。

I can't figure out how to solve the puzzle.

Expected form: **ない**

Why: Plain negation. [[Japanese#^ja-Q0554|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%9D%E3%81%AE%E3%81%AA%E3%81%9E%E3%81%AA%E3%81%9E%E3%81%AE%E8%A7%A3%E3%81%8D%E6%96%B9%E3%81%8C%E8%A7%A3%E3%82%89%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0554-answer

**ja-Q0555** — なんで傘さしてんの？ 雨降ってないよ。

Why do you have your umbrella up? It's not raining.

Expected form: **ない**

Why: Plain negation. [[Japanese#^ja-Q0555|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%AA%E3%82%93%E3%81%A7%E5%82%98%E3%81%95%E3%81%97%E3%81%A6%E3%82%93%E3%81%AE%EF%BC%9F%20%E9%9B%A8%E9%99%8D%E3%81%A3%E3%81%A6%E3%81%AA%E3%81%84%E3%82%88%E3%80%82)
^ja-Q0555-answer

**ja-Q0556** — なんで傘さしてんの？ 雨降ってないよ。

Why do you have your umbrella up? It's not raining.

Why: Plain negation. [[Japanese#^ja-Q0556|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%AA%E3%82%93%E3%81%A7%E5%82%98%E3%81%95%E3%81%97%E3%81%A6%E3%82%93%E3%81%AE%EF%BC%9F%20%E9%9B%A8%E9%99%8D%E3%81%A3%E3%81%A6%E3%81%AA%E3%81%84%E3%82%88%E3%80%82)
^ja-Q0556-answer

**ja-Q0557** — この鳥は飛ぶことができない。

This bird cannot fly.

Why: Plain negation. [[Japanese#^ja-Q0557|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%93%E3%81%AE%E9%B3%A5%E3%81%AF%E9%A3%9B%E3%81%B6%E3%81%93%E3%81%A8%E3%81%8C%E3%81%A7%E3%81%8D%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0557-answer

**ja-Q0558** — この鳥は飛ぶことができない。

This bird cannot fly.

Plain negative verbs commonly end in ない with class-dependent stem changes. Some adjectives and copulas have their own negative constructions. Do not attach ない indiscriminately to every dictionary form.

Why: Plain negation. [[Japanese#^ja-Q0558|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%93%E3%81%AE%E9%B3%A5%E3%81%AF%E9%A3%9B%E3%81%B6%E3%81%93%E3%81%A8%E3%81%8C%E3%81%A7%E3%81%8D%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0558-answer

**ja-Q0559** — 私達は今あるもので我慢しなければならない。

We have to make the best of what we have.

Expected form: **ない**

Why: Plain negation. [[Japanese#^ja-Q0559|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E9%81%94%E3%81%AF%E4%BB%8A%E3%81%82%E3%82%8B%E3%82%82%E3%81%AE%E3%81%A7%E6%88%91%E6%85%A2%E3%81%97%E3%81%AA%E3%81%91%E3%82%8C%E3%81%B0%E3%81%AA%E3%82%89%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0559-answer

**ja-Q0560** — 私達は今あるもので我慢しなければならない。

We have to make the best of what we have.

Expected form: **ない**

Why: Plain negation. [[Japanese#^ja-Q0560|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E9%81%94%E3%81%AF%E4%BB%8A%E3%81%82%E3%82%8B%E3%82%82%E3%81%AE%E3%81%A7%E6%88%91%E6%85%A2%E3%81%97%E3%81%AA%E3%81%91%E3%82%8C%E3%81%B0%E3%81%AA%E3%82%89%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0560-answer

**ja-Q0561** — 世界はお前中心に回ってるわけじゃないんだよ。

The world doesn't revolve around you.

Expected form: **ない**

Why: Plain negation. [[Japanese#^ja-Q0561|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E4%B8%96%E7%95%8C%E3%81%AF%E3%81%8A%E5%89%8D%E4%B8%AD%E5%BF%83%E3%81%AB%E5%9B%9E%E3%81%A3%E3%81%A6%E3%82%8B%E3%82%8F%E3%81%91%E3%81%98%E3%82%83%E3%81%AA%E3%81%84%E3%82%93%E3%81%A0%E3%82%88%E3%80%82)
^ja-Q0561-answer

**ja-Q0562** — 世界はお前中心に回ってるわけじゃないんだよ。

The world doesn't revolve around you.

Why: Plain negation. [[Japanese#^ja-Q0562|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E4%B8%96%E7%95%8C%E3%81%AF%E3%81%8A%E5%89%8D%E4%B8%AD%E5%BF%83%E3%81%AB%E5%9B%9E%E3%81%A3%E3%81%A6%E3%82%8B%E3%82%8F%E3%81%91%E3%81%98%E3%82%83%E3%81%AA%E3%81%84%E3%82%93%E3%81%A0%E3%82%88%E3%80%82)
^ja-Q0562-answer

**ja-Q0563** — あなたの意見をさしはさまないで。

Don't cut in with your remarks.

Why: Plain negation. [[Japanese#^ja-Q0563|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%82%E3%81%AA%E3%81%9F%E3%81%AE%E6%84%8F%E8%A6%8B%E3%82%92%E3%81%95%E3%81%97%E3%81%AF%E3%81%95%E3%81%BE%E3%81%AA%E3%81%84%E3%81%A7%E3%80%82)
^ja-Q0563-answer

**ja-Q0564** — あなたの意見をさしはさまないで。

Don't cut in with your remarks.

Plain negative verbs commonly end in ない with class-dependent stem changes. Some adjectives and copulas have their own negative constructions. Do not attach ない indiscriminately to every dictionary form.

Why: Plain negation. [[Japanese#^ja-Q0564|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%82%E3%81%AA%E3%81%9F%E3%81%AE%E6%84%8F%E8%A6%8B%E3%82%92%E3%81%95%E3%81%97%E3%81%AF%E3%81%95%E3%81%BE%E3%81%AA%E3%81%84%E3%81%A7%E3%80%82)
^ja-Q0564-answer

**ja-Q0565** — 僕はこういう音楽が好きではない。

I'm not keen on this kind of music.

Expected form: **ない**

Why: Plain negation. [[Japanese#^ja-Q0565|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%83%95%E3%81%AF%E3%81%93%E3%81%86%E3%81%84%E3%81%86%E9%9F%B3%E6%A5%BD%E3%81%8C%E5%A5%BD%E3%81%8D%E3%81%A7%E3%81%AF%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0565-answer

**ja-Q0566** — 僕はこういう音楽が好きではない。

I'm not keen on this kind of music.

Expected form: **ない**

Why: Plain negation. [[Japanese#^ja-Q0566|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%83%95%E3%81%AF%E3%81%93%E3%81%86%E3%81%84%E3%81%86%E9%9F%B3%E6%A5%BD%E3%81%8C%E5%A5%BD%E3%81%8D%E3%81%A7%E3%81%AF%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0566-answer

**ja-Q0567** — 金銭は成功を計る基準にはならない。

Money is not a criterion of success.

Expected form: **ない**

Why: Plain negation. [[Japanese#^ja-Q0567|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E9%87%91%E9%8A%AD%E3%81%AF%E6%88%90%E5%8A%9F%E3%82%92%E8%A8%88%E3%82%8B%E5%9F%BA%E6%BA%96%E3%81%AB%E3%81%AF%E3%81%AA%E3%82%89%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0567-answer

**ja-Q0568** — 金銭は成功を計る基準にはならない。

Money is not a criterion of success.

Why: Plain negation. [[Japanese#^ja-Q0568|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E9%87%91%E9%8A%AD%E3%81%AF%E6%88%90%E5%8A%9F%E3%82%92%E8%A8%88%E3%82%8B%E5%9F%BA%E6%BA%96%E3%81%AB%E3%81%AF%E3%81%AA%E3%82%89%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0568-answer

**ja-Q0569** — 遅くまで起きていてはいけない。

Don't sit up till late.

Why: Plain negation. [[Japanese#^ja-Q0569|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E9%81%85%E3%81%8F%E3%81%BE%E3%81%A7%E8%B5%B7%E3%81%8D%E3%81%A6%E3%81%84%E3%81%A6%E3%81%AF%E3%81%84%E3%81%91%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0569-answer

**ja-Q0570** — 遅くまで起きていてはいけない。

Don't sit up till late.

Plain negative verbs commonly end in ない with class-dependent stem changes. Some adjectives and copulas have their own negative constructions. Do not attach ない indiscriminately to every dictionary form.

Why: Plain negation. [[Japanese#^ja-Q0570|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E9%81%85%E3%81%8F%E3%81%BE%E3%81%A7%E8%B5%B7%E3%81%8D%E3%81%A6%E3%81%84%E3%81%A6%E3%81%AF%E3%81%84%E3%81%91%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0570-answer

**ja-Q0571** — 彼が一番やってきそうにない。

He is least likely to come.

Expected form: **ない**

Why: Plain negation. [[Japanese#^ja-Q0571|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%8C%E4%B8%80%E7%95%AA%E3%82%84%E3%81%A3%E3%81%A6%E3%81%8D%E3%81%9D%E3%81%86%E3%81%AB%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0571-answer

**ja-Q0572** — 彼が一番やってきそうにない。

He is least likely to come.

Expected form: **ない**

Why: Plain negation. [[Japanese#^ja-Q0572|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%8C%E4%B8%80%E7%95%AA%E3%82%84%E3%81%A3%E3%81%A6%E3%81%8D%E3%81%9D%E3%81%86%E3%81%AB%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0572-answer

**ja-Q0573** — 正確な時間に関して、その部屋の時計をあてにしてはいけない。

Do not rely on the room clock for the accurate time of day.

Expected form: **ない**

Why: Plain negation. [[Japanese#^ja-Q0573|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%AD%A3%E7%A2%BA%E3%81%AA%E6%99%82%E9%96%93%E3%81%AB%E9%96%A2%E3%81%97%E3%81%A6%E3%80%81%E3%81%9D%E3%81%AE%E9%83%A8%E5%B1%8B%E3%81%AE%E6%99%82%E8%A8%88%E3%82%92%E3%81%82%E3%81%A6%E3%81%AB%E3%81%97%E3%81%A6%E3%81%AF%E3%81%84%E3%81%91%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0573-answer

**ja-Q0574** — 正確な時間に関して、その部屋の時計をあてにしてはいけない。

Do not rely on the room clock for the accurate time of day.

Why: Plain negation. [[Japanese#^ja-Q0574|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%AD%A3%E7%A2%BA%E3%81%AA%E6%99%82%E9%96%93%E3%81%AB%E9%96%A2%E3%81%97%E3%81%A6%E3%80%81%E3%81%9D%E3%81%AE%E9%83%A8%E5%B1%8B%E3%81%AE%E6%99%82%E8%A8%88%E3%82%92%E3%81%82%E3%81%A6%E3%81%AB%E3%81%97%E3%81%A6%E3%81%AF%E3%81%84%E3%81%91%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0574-answer

**ja-Q0575** — この若人に対してねたましく思う気持ちを、君はやむを得ないものと受け入れなければならない。

You need to come to terms with your jealousy of this young man.

Why: Plain negation. [[Japanese#^ja-Q0575|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%93%E3%81%AE%E8%8B%A5%E4%BA%BA%E3%81%AB%E5%AF%BE%E3%81%97%E3%81%A6%E3%81%AD%E3%81%9F%E3%81%BE%E3%81%97%E3%81%8F%E6%80%9D%E3%81%86%E6%B0%97%E6%8C%81%E3%81%A1%E3%82%92%E3%80%81%E5%90%9B%E3%81%AF%E3%82%84%E3%82%80%E3%82%92%E5%BE%97%E3%81%AA%E3%81%84%E3%82%82%E3%81%AE%E3%81%A8%E5%8F%97%E3%81%91%E5%85%A5%E3%82%8C%E3%81%AA%E3%81%91%E3%82%8C%E3%81%B0%E3%81%AA%E3%82%89%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0575-answer

**ja-Q0576** — この若人に対してねたましく思う気持ちを、君はやむを得ないものと受け入れなければならない。

You need to come to terms with your jealousy of this young man.

Plain negative verbs commonly end in ない with class-dependent stem changes. Some adjectives and copulas have their own negative constructions. Do not attach ない indiscriminately to every dictionary form.

Why: Plain negation. [[Japanese#^ja-Q0576|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%93%E3%81%AE%E8%8B%A5%E4%BA%BA%E3%81%AB%E5%AF%BE%E3%81%97%E3%81%A6%E3%81%AD%E3%81%9F%E3%81%BE%E3%81%97%E3%81%8F%E6%80%9D%E3%81%86%E6%B0%97%E6%8C%81%E3%81%A1%E3%82%92%E3%80%81%E5%90%9B%E3%81%AF%E3%82%84%E3%82%80%E3%82%92%E5%BE%97%E3%81%AA%E3%81%84%E3%82%82%E3%81%AE%E3%81%A8%E5%8F%97%E3%81%91%E5%85%A5%E3%82%8C%E3%81%AA%E3%81%91%E3%82%8C%E3%81%B0%E3%81%AA%E3%82%89%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0576-answer

**ja-Q0577** — だれかがピアノをひいている。アンに違いない。

Somebody is playing the piano. It must be Ann.

Expected form: **ない**

Why: Plain negation. [[Japanese#^ja-Q0577|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%A0%E3%82%8C%E3%81%8B%E3%81%8C%E3%83%94%E3%82%A2%E3%83%8E%E3%82%92%E3%81%B2%E3%81%84%E3%81%A6%E3%81%84%E3%82%8B%E3%80%82%E3%82%A2%E3%83%B3%E3%81%AB%E9%81%95%E3%81%84%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0577-answer

**ja-Q0578** — だれかがピアノをひいている。アンに違いない。

Somebody is playing the piano. It must be Ann.

Expected form: **ない**

Why: Plain negation. [[Japanese#^ja-Q0578|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%A0%E3%82%8C%E3%81%8B%E3%81%8C%E3%83%94%E3%82%A2%E3%83%8E%E3%82%92%E3%81%B2%E3%81%84%E3%81%A6%E3%81%84%E3%82%8B%E3%80%82%E3%82%A2%E3%83%B3%E3%81%AB%E9%81%95%E3%81%84%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0578-answer

**ja-Q0579** — 彼は一介の詩人に過ぎない。

He is nothing but a poet.

Expected form: **ない**

Why: Plain negation. [[Japanese#^ja-Q0579|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%AF%E4%B8%80%E4%BB%8B%E3%81%AE%E8%A9%A9%E4%BA%BA%E3%81%AB%E9%81%8E%E3%81%8E%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0579-answer

**ja-Q0580** — 彼は一介の詩人に過ぎない。

He is nothing but a poet.

Why: Plain negation. [[Japanese#^ja-Q0580|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%AF%E4%B8%80%E4%BB%8B%E3%81%AE%E8%A9%A9%E4%BA%BA%E3%81%AB%E9%81%8E%E3%81%8E%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0580-answer

**ja-Q0581** — 仕事の終わりはまだ見当がつかない。

The end of the task is not yet in mind.

Why: Plain negation. [[Japanese#^ja-Q0581|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E4%BB%95%E4%BA%8B%E3%81%AE%E7%B5%82%E3%82%8F%E3%82%8A%E3%81%AF%E3%81%BE%E3%81%A0%E8%A6%8B%E5%BD%93%E3%81%8C%E3%81%A4%E3%81%8B%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0581-answer

**ja-Q0582** — 仕事の終わりはまだ見当がつかない。

The end of the task is not yet in mind.

Plain negative verbs commonly end in ない with class-dependent stem changes. Some adjectives and copulas have their own negative constructions. Do not attach ない indiscriminately to every dictionary form.

Why: Plain negation. [[Japanese#^ja-Q0582|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E4%BB%95%E4%BA%8B%E3%81%AE%E7%B5%82%E3%82%8F%E3%82%8A%E3%81%AF%E3%81%BE%E3%81%A0%E8%A6%8B%E5%BD%93%E3%81%8C%E3%81%A4%E3%81%8B%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0582-answer

**ja-Q0583** — 僕はあの学校のスクールカラーがすきではない。

I don't like the atmosphere of that school.

Expected form: **ない**

Why: Plain negation. [[Japanese#^ja-Q0583|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%83%95%E3%81%AF%E3%81%82%E3%81%AE%E5%AD%A6%E6%A0%A1%E3%81%AE%E3%82%B9%E3%82%AF%E3%83%BC%E3%83%AB%E3%82%AB%E3%83%A9%E3%83%BC%E3%81%8C%E3%81%99%E3%81%8D%E3%81%A7%E3%81%AF%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0583-answer

**ja-Q0584** — 僕はあの学校のスクールカラーがすきではない。

I don't like the atmosphere of that school.

Expected form: **ない**

Why: Plain negation. [[Japanese#^ja-Q0584|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%83%95%E3%81%AF%E3%81%82%E3%81%AE%E5%AD%A6%E6%A0%A1%E3%81%AE%E3%82%B9%E3%82%AF%E3%83%BC%E3%83%AB%E3%82%AB%E3%83%A9%E3%83%BC%E3%81%8C%E3%81%99%E3%81%8D%E3%81%A7%E3%81%AF%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0584-answer

**ja-Q0585** — 彼女が美しいからといって彼女を好きなわけではない。

It is not because she is beautiful that I like her.

Expected form: **ない**

Why: Plain negation. [[Japanese#^ja-Q0585|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E5%A5%B3%E3%81%8C%E7%BE%8E%E3%81%97%E3%81%84%E3%81%8B%E3%82%89%E3%81%A8%E3%81%84%E3%81%A3%E3%81%A6%E5%BD%BC%E5%A5%B3%E3%82%92%E5%A5%BD%E3%81%8D%E3%81%AA%E3%82%8F%E3%81%91%E3%81%A7%E3%81%AF%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0585-answer

**ja-Q0586** — 彼女が美しいからといって彼女を好きなわけではない。

It is not because she is beautiful that I like her.

Why: Plain negation. [[Japanese#^ja-Q0586|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E5%A5%B3%E3%81%8C%E7%BE%8E%E3%81%97%E3%81%84%E3%81%8B%E3%82%89%E3%81%A8%E3%81%84%E3%81%A3%E3%81%A6%E5%BD%BC%E5%A5%B3%E3%82%92%E5%A5%BD%E3%81%8D%E3%81%AA%E3%82%8F%E3%81%91%E3%81%A7%E3%81%AF%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0586-answer

**ja-Q0587** — 端的に言うと、私はあなたにその会社で働いて欲しくない。

In short, I don't want you to work for that company.

Why: Plain negation. [[Japanese#^ja-Q0587|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%AB%AF%E7%9A%84%E3%81%AB%E8%A8%80%E3%81%86%E3%81%A8%E3%80%81%E7%A7%81%E3%81%AF%E3%81%82%E3%81%AA%E3%81%9F%E3%81%AB%E3%81%9D%E3%81%AE%E4%BC%9A%E7%A4%BE%E3%81%A7%E5%83%8D%E3%81%84%E3%81%A6%E6%AC%B2%E3%81%97%E3%81%8F%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0587-answer

**ja-Q0588** — 端的に言うと、私はあなたにその会社で働いて欲しくない。

In short, I don't want you to work for that company.

Plain negative verbs commonly end in ない with class-dependent stem changes. Some adjectives and copulas have their own negative constructions. Do not attach ない indiscriminately to every dictionary form.

Why: Plain negation. [[Japanese#^ja-Q0588|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%AB%AF%E7%9A%84%E3%81%AB%E8%A8%80%E3%81%86%E3%81%A8%E3%80%81%E7%A7%81%E3%81%AF%E3%81%82%E3%81%AA%E3%81%9F%E3%81%AB%E3%81%9D%E3%81%AE%E4%BC%9A%E7%A4%BE%E3%81%A7%E5%83%8D%E3%81%84%E3%81%A6%E6%AC%B2%E3%81%97%E3%81%8F%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0588-answer

**ja-Q0589** — 父親と比べると彼は深みがない。

As compared with his father, he is lacking in depth.

Expected form: **ない**

Why: Plain negation. [[Japanese#^ja-Q0589|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%88%B6%E8%A6%AA%E3%81%A8%E6%AF%94%E3%81%B9%E3%82%8B%E3%81%A8%E5%BD%BC%E3%81%AF%E6%B7%B1%E3%81%BF%E3%81%8C%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0589-answer

**ja-Q0590** — 父親と比べると彼は深みがない。

As compared with his father, he is lacking in depth.

Expected form: **ない**

Why: Plain negation. [[Japanese#^ja-Q0590|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%88%B6%E8%A6%AA%E3%81%A8%E6%AF%94%E3%81%B9%E3%82%8B%E3%81%A8%E5%BD%BC%E3%81%AF%E6%B7%B1%E3%81%BF%E3%81%8C%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0590-answer

**ja-Q0591** — 彼は今一番会いたくない人だ。

He is the last person I want to see now.

Expected form: **ない**

Why: Plain negation. [[Japanese#^ja-Q0591|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%AF%E4%BB%8A%E4%B8%80%E7%95%AA%E4%BC%9A%E3%81%84%E3%81%9F%E3%81%8F%E3%81%AA%E3%81%84%E4%BA%BA%E3%81%A0%E3%80%82)
^ja-Q0591-answer

**ja-Q0592** — 彼は今一番会いたくない人だ。

He is the last person I want to see now.

Why: Plain negation. [[Japanese#^ja-Q0592|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%AF%E4%BB%8A%E4%B8%80%E7%95%AA%E4%BC%9A%E3%81%84%E3%81%9F%E3%81%8F%E3%81%AA%E3%81%84%E4%BA%BA%E3%81%A0%E3%80%82)
^ja-Q0592-answer

**ja-Q0593** — この詩を暗記しなければならない。

I must learn this poem by heart.

Why: Plain negation. [[Japanese#^ja-Q0593|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%93%E3%81%AE%E8%A9%A9%E3%82%92%E6%9A%97%E8%A8%98%E3%81%97%E3%81%AA%E3%81%91%E3%82%8C%E3%81%B0%E3%81%AA%E3%82%89%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0593-answer

**ja-Q0594** — この詩を暗記しなければならない。

I must learn this poem by heart.

Plain negative verbs commonly end in ない with class-dependent stem changes. Some adjectives and copulas have their own negative constructions. Do not attach ない indiscriminately to every dictionary form.

Why: Plain negation. [[Japanese#^ja-Q0594|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%93%E3%81%AE%E8%A9%A9%E3%82%92%E6%9A%97%E8%A8%98%E3%81%97%E3%81%AA%E3%81%91%E3%82%8C%E3%81%B0%E3%81%AA%E3%82%89%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0594-answer

**ja-Q0595** — ほかの学生に遅れないように一生懸命勉強しなければならなかった。

I had to work hard to keep up with the other students.

Expected form: **ない**

Why: Plain negation. [[Japanese#^ja-Q0595|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%BB%E3%81%8B%E3%81%AE%E5%AD%A6%E7%94%9F%E3%81%AB%E9%81%85%E3%82%8C%E3%81%AA%E3%81%84%E3%82%88%E3%81%86%E3%81%AB%E4%B8%80%E7%94%9F%E6%87%B8%E5%91%BD%E5%8B%89%E5%BC%B7%E3%81%97%E3%81%AA%E3%81%91%E3%82%8C%E3%81%B0%E3%81%AA%E3%82%89%E3%81%AA%E3%81%8B%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0595-answer

**ja-Q0596** — ほかの学生に遅れないように一生懸命勉強しなければならなかった。

I had to work hard to keep up with the other students.

Expected form: **ない**

Why: Plain negation. [[Japanese#^ja-Q0596|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%BB%E3%81%8B%E3%81%AE%E5%AD%A6%E7%94%9F%E3%81%AB%E9%81%85%E3%82%8C%E3%81%AA%E3%81%84%E3%82%88%E3%81%86%E3%81%AB%E4%B8%80%E7%94%9F%E6%87%B8%E5%91%BD%E5%8B%89%E5%BC%B7%E3%81%97%E3%81%AA%E3%81%91%E3%82%8C%E3%81%B0%E3%81%AA%E3%82%89%E3%81%AA%E3%81%8B%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0596-answer

**ja-Q0597** — 実を言うと、私は昨日言ったことを全く覚えていない。

To tell the truth, I don't remember anything I said yesterday.

Expected form: **ない**

Why: Plain negation. [[Japanese#^ja-Q0597|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%AE%9F%E3%82%92%E8%A8%80%E3%81%86%E3%81%A8%E3%80%81%E7%A7%81%E3%81%AF%E6%98%A8%E6%97%A5%E8%A8%80%E3%81%A3%E3%81%9F%E3%81%93%E3%81%A8%E3%82%92%E5%85%A8%E3%81%8F%E8%A6%9A%E3%81%88%E3%81%A6%E3%81%84%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0597-answer

**ja-Q0598** — 実を言うと、私は昨日言ったことを全く覚えていない。

To tell the truth, I don't remember anything I said yesterday.

Why: Plain negation. [[Japanese#^ja-Q0598|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%AE%9F%E3%82%92%E8%A8%80%E3%81%86%E3%81%A8%E3%80%81%E7%A7%81%E3%81%AF%E6%98%A8%E6%97%A5%E8%A8%80%E3%81%A3%E3%81%9F%E3%81%93%E3%81%A8%E3%82%92%E5%85%A8%E3%81%8F%E8%A6%9A%E3%81%88%E3%81%A6%E3%81%84%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0598-answer

**ja-Q0599** — 彼は試験を受けないでその学校に入学を認められた。

He was admitted to the school without sitting for an examination.

Why: Plain negation. [[Japanese#^ja-Q0599|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%AF%E8%A9%A6%E9%A8%93%E3%82%92%E5%8F%97%E3%81%91%E3%81%AA%E3%81%84%E3%81%A7%E3%81%9D%E3%81%AE%E5%AD%A6%E6%A0%A1%E3%81%AB%E5%85%A5%E5%AD%A6%E3%82%92%E8%AA%8D%E3%82%81%E3%82%89%E3%82%8C%E3%81%9F%E3%80%82)
^ja-Q0599-answer

**ja-Q0600** — 彼は試験を受けないでその学校に入学を認められた。

He was admitted to the school without sitting for an examination.

Plain negative verbs commonly end in ない with class-dependent stem changes. Some adjectives and copulas have their own negative constructions. Do not attach ない indiscriminately to every dictionary form.

Why: Plain negation. [[Japanese#^ja-Q0600|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%AF%E8%A9%A6%E9%A8%93%E3%82%92%E5%8F%97%E3%81%91%E3%81%AA%E3%81%84%E3%81%A7%E3%81%9D%E3%81%AE%E5%AD%A6%E6%A0%A1%E3%81%AB%E5%85%A5%E5%AD%A6%E3%82%92%E8%AA%8D%E3%82%81%E3%82%89%E3%82%8C%E3%81%9F%E3%80%82)
^ja-Q0600-answer


### Answers 601–650

**ja-Q0601** — 私はあなたのぐちには死ぬほどうんざりしている。

I am sick to death of your complaints.

Expected form: **ている**

Why: Te-form links and requests. [[Japanese#^ja-Q0601|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AF%E3%81%82%E3%81%AA%E3%81%9F%E3%81%AE%E3%81%90%E3%81%A1%E3%81%AB%E3%81%AF%E6%AD%BB%E3%81%AC%E3%81%BB%E3%81%A9%E3%81%86%E3%82%93%E3%81%96%E3%82%8A%E3%81%97%E3%81%A6%E3%81%84%E3%82%8B%E3%80%82)
^ja-Q0601-answer

**ja-Q0602** — 私はあなたのぐちには死ぬほどうんざりしている。

I am sick to death of your complaints.

Expected form: **ている**

Why: Te-form links and requests. [[Japanese#^ja-Q0602|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AF%E3%81%82%E3%81%AA%E3%81%9F%E3%81%AE%E3%81%90%E3%81%A1%E3%81%AB%E3%81%AF%E6%AD%BB%E3%81%AC%E3%81%BB%E3%81%A9%E3%81%86%E3%82%93%E3%81%96%E3%82%8A%E3%81%97%E3%81%A6%E3%81%84%E3%82%8B%E3%80%82)
^ja-Q0602-answer

**ja-Q0603** — 君の成功は主に好機をいかにして上手に利用するかにかかっている。

Your success will largely depend upon how you will make good use of your opportunity.

Expected form: **ている**

Why: Te-form links and requests. [[Japanese#^ja-Q0603|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%90%9B%E3%81%AE%E6%88%90%E5%8A%9F%E3%81%AF%E4%B8%BB%E3%81%AB%E5%A5%BD%E6%A9%9F%E3%82%92%E3%81%84%E3%81%8B%E3%81%AB%E3%81%97%E3%81%A6%E4%B8%8A%E6%89%8B%E3%81%AB%E5%88%A9%E7%94%A8%E3%81%99%E3%82%8B%E3%81%8B%E3%81%AB%E3%81%8B%E3%81%8B%E3%81%A3%E3%81%A6%E3%81%84%E3%82%8B%E3%80%82)
^ja-Q0603-answer

**ja-Q0604** — 君の成功は主に好機をいかにして上手に利用するかにかかっている。

Your success will largely depend upon how you will make good use of your opportunity.

Why: Te-form links and requests. [[Japanese#^ja-Q0604|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%90%9B%E3%81%AE%E6%88%90%E5%8A%9F%E3%81%AF%E4%B8%BB%E3%81%AB%E5%A5%BD%E6%A9%9F%E3%82%92%E3%81%84%E3%81%8B%E3%81%AB%E3%81%97%E3%81%A6%E4%B8%8A%E6%89%8B%E3%81%AB%E5%88%A9%E7%94%A8%E3%81%99%E3%82%8B%E3%81%8B%E3%81%AB%E3%81%8B%E3%81%8B%E3%81%A3%E3%81%A6%E3%81%84%E3%82%8B%E3%80%82)
^ja-Q0604-answer

**ja-Q0605** — 外交官には様々な特権が与えられている。

Diplomats are allowed various privileges.

Why: Te-form links and requests. [[Japanese#^ja-Q0605|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%A4%96%E4%BA%A4%E5%AE%98%E3%81%AB%E3%81%AF%E6%A7%98%E3%80%85%E3%81%AA%E7%89%B9%E6%A8%A9%E3%81%8C%E4%B8%8E%E3%81%88%E3%82%89%E3%82%8C%E3%81%A6%E3%81%84%E3%82%8B%E3%80%82)
^ja-Q0605-answer

**ja-Q0606** — 外交官には様々な特権が与えられている。

Diplomats are allowed various privileges.

The te-form joins predicates and builds constructions such as requests and いる aspect. The stem change depends on verb class. ている can mark an ongoing action or a resulting state.

Why: Te-form links and requests. [[Japanese#^ja-Q0606|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%A4%96%E4%BA%A4%E5%AE%98%E3%81%AB%E3%81%AF%E6%A7%98%E3%80%85%E3%81%AA%E7%89%B9%E6%A8%A9%E3%81%8C%E4%B8%8E%E3%81%88%E3%82%89%E3%82%8C%E3%81%A6%E3%81%84%E3%82%8B%E3%80%82)
^ja-Q0606-answer

**ja-Q0607** — 彼はドアが閉まっていることに気がついた。

He found the door closed.

Expected form: **ている**

Why: Te-form links and requests. [[Japanese#^ja-Q0607|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%AF%E3%83%89%E3%82%A2%E3%81%8C%E9%96%89%E3%81%BE%E3%81%A3%E3%81%A6%E3%81%84%E3%82%8B%E3%81%93%E3%81%A8%E3%81%AB%E6%B0%97%E3%81%8C%E3%81%A4%E3%81%84%E3%81%9F%E3%80%82)
^ja-Q0607-answer

**ja-Q0608** — 彼はドアが閉まっていることに気がついた。

He found the door closed.

Expected form: **ている**

Why: Te-form links and requests. [[Japanese#^ja-Q0608|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%AF%E3%83%89%E3%82%A2%E3%81%8C%E9%96%89%E3%81%BE%E3%81%A3%E3%81%A6%E3%81%84%E3%82%8B%E3%81%93%E3%81%A8%E3%81%AB%E6%B0%97%E3%81%8C%E3%81%A4%E3%81%84%E3%81%9F%E3%80%82)
^ja-Q0608-answer

**ja-Q0609** — 彼はそれについて知っている様だ。

It seems that he knows about it.

Expected form: **ている**

Why: Te-form links and requests. [[Japanese#^ja-Q0609|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%AF%E3%81%9D%E3%82%8C%E3%81%AB%E3%81%A4%E3%81%84%E3%81%A6%E7%9F%A5%E3%81%A3%E3%81%A6%E3%81%84%E3%82%8B%E6%A7%98%E3%81%A0%E3%80%82)
^ja-Q0609-answer

**ja-Q0610** — 彼はそれについて知っている様だ。

It seems that he knows about it.

Why: Te-form links and requests. [[Japanese#^ja-Q0610|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%AF%E3%81%9D%E3%82%8C%E3%81%AB%E3%81%A4%E3%81%84%E3%81%A6%E7%9F%A5%E3%81%A3%E3%81%A6%E3%81%84%E3%82%8B%E6%A7%98%E3%81%A0%E3%80%82)
^ja-Q0610-answer

**ja-Q0611** — 彼女はその皿の模様が気に入っている。

She likes the design on the plate.

Why: Te-form links and requests. [[Japanese#^ja-Q0611|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E5%A5%B3%E3%81%AF%E3%81%9D%E3%81%AE%E7%9A%BF%E3%81%AE%E6%A8%A1%E6%A7%98%E3%81%8C%E6%B0%97%E3%81%AB%E5%85%A5%E3%81%A3%E3%81%A6%E3%81%84%E3%82%8B%E3%80%82)
^ja-Q0611-answer

**ja-Q0612** — 彼女はその皿の模様が気に入っている。

She likes the design on the plate.

The te-form joins predicates and builds constructions such as requests and いる aspect. The stem change depends on verb class. ている can mark an ongoing action or a resulting state.

Why: Te-form links and requests. [[Japanese#^ja-Q0612|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E5%A5%B3%E3%81%AF%E3%81%9D%E3%81%AE%E7%9A%BF%E3%81%AE%E6%A8%A1%E6%A7%98%E3%81%8C%E6%B0%97%E3%81%AB%E5%85%A5%E3%81%A3%E3%81%A6%E3%81%84%E3%82%8B%E3%80%82)
^ja-Q0612-answer

**ja-Q0613** — あなたが言っていることからすれば、彼はそこにいなかったことになる。

It follows from what you say that he was not there.

Expected form: **ている**

Why: Te-form links and requests. [[Japanese#^ja-Q0613|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%82%E3%81%AA%E3%81%9F%E3%81%8C%E8%A8%80%E3%81%A3%E3%81%A6%E3%81%84%E3%82%8B%E3%81%93%E3%81%A8%E3%81%8B%E3%82%89%E3%81%99%E3%82%8C%E3%81%B0%E3%80%81%E5%BD%BC%E3%81%AF%E3%81%9D%E3%81%93%E3%81%AB%E3%81%84%E3%81%AA%E3%81%8B%E3%81%A3%E3%81%9F%E3%81%93%E3%81%A8%E3%81%AB%E3%81%AA%E3%82%8B%E3%80%82)
^ja-Q0613-answer

**ja-Q0614** — あなたが言っていることからすれば、彼はそこにいなかったことになる。

It follows from what you say that he was not there.

Expected form: **ている**

Why: Te-form links and requests. [[Japanese#^ja-Q0614|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%82%E3%81%AA%E3%81%9F%E3%81%8C%E8%A8%80%E3%81%A3%E3%81%A6%E3%81%84%E3%82%8B%E3%81%93%E3%81%A8%E3%81%8B%E3%82%89%E3%81%99%E3%82%8C%E3%81%B0%E3%80%81%E5%BD%BC%E3%81%AF%E3%81%9D%E3%81%93%E3%81%AB%E3%81%84%E3%81%AA%E3%81%8B%E3%81%A3%E3%81%9F%E3%81%93%E3%81%A8%E3%81%AB%E3%81%AA%E3%82%8B%E3%80%82)
^ja-Q0614-answer

**ja-Q0615** — 駅で私を降ろしてください。

Please drop me off at the station.

Expected form: **てください**

Why: Te-form links and requests. [[Japanese#^ja-Q0615|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E9%A7%85%E3%81%A7%E7%A7%81%E3%82%92%E9%99%8D%E3%82%8D%E3%81%97%E3%81%A6%E3%81%8F%E3%81%A0%E3%81%95%E3%81%84%E3%80%82)
^ja-Q0615-answer

**ja-Q0616** — 駅で私を降ろしてください。

Please drop me off at the station.

Why: Te-form links and requests. [[Japanese#^ja-Q0616|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E9%A7%85%E3%81%A7%E7%A7%81%E3%82%92%E9%99%8D%E3%82%8D%E3%81%97%E3%81%A6%E3%81%8F%E3%81%A0%E3%81%95%E3%81%84%E3%80%82)
^ja-Q0616-answer

**ja-Q0617** — ハエが天井にとまっている。

The fly is on the ceiling.

Why: Te-form links and requests. [[Japanese#^ja-Q0617|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%83%8F%E3%82%A8%E3%81%8C%E5%A4%A9%E4%BA%95%E3%81%AB%E3%81%A8%E3%81%BE%E3%81%A3%E3%81%A6%E3%81%84%E3%82%8B%E3%80%82)
^ja-Q0617-answer

**ja-Q0618** — ハエが天井にとまっている。

The fly is on the ceiling.

The te-form joins predicates and builds constructions such as requests and いる aspect. The stem change depends on verb class. ている can mark an ongoing action or a resulting state.

Why: Te-form links and requests. [[Japanese#^ja-Q0618|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%83%8F%E3%82%A8%E3%81%8C%E5%A4%A9%E4%BA%95%E3%81%AB%E3%81%A8%E3%81%BE%E3%81%A3%E3%81%A6%E3%81%84%E3%82%8B%E3%80%82)
^ja-Q0618-answer

**ja-Q0619** — 彼はたいていうたた寝をしている。

He is taking a nap half the time.

Expected form: **ている**

Why: Te-form links and requests. [[Japanese#^ja-Q0619|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%AF%E3%81%9F%E3%81%84%E3%81%A6%E3%81%84%E3%81%86%E3%81%9F%E3%81%9F%E5%AF%9D%E3%82%92%E3%81%97%E3%81%A6%E3%81%84%E3%82%8B%E3%80%82)
^ja-Q0619-answer

**ja-Q0620** — 彼はたいていうたた寝をしている。

He is taking a nap half the time.

Expected form: **ている**

Why: Te-form links and requests. [[Japanese#^ja-Q0620|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%AF%E3%81%9F%E3%81%84%E3%81%A6%E3%81%84%E3%81%86%E3%81%9F%E3%81%9F%E5%AF%9D%E3%82%92%E3%81%97%E3%81%A6%E3%81%84%E3%82%8B%E3%80%82)
^ja-Q0620-answer

**ja-Q0621** — 二人の男性が自転車に乗って体をきたえている。

The men are getting into shape riding bicycles.

Expected form: **ている**

Why: Te-form links and requests. [[Japanese#^ja-Q0621|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E4%BA%8C%E4%BA%BA%E3%81%AE%E7%94%B7%E6%80%A7%E3%81%8C%E8%87%AA%E8%BB%A2%E8%BB%8A%E3%81%AB%E4%B9%97%E3%81%A3%E3%81%A6%E4%BD%93%E3%82%92%E3%81%8D%E3%81%9F%E3%81%88%E3%81%A6%E3%81%84%E3%82%8B%E3%80%82)
^ja-Q0621-answer

**ja-Q0622** — 二人の男性が自転車に乗って体をきたえている。

The men are getting into shape riding bicycles.

Why: Te-form links and requests. [[Japanese#^ja-Q0622|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E4%BA%8C%E4%BA%BA%E3%81%AE%E7%94%B7%E6%80%A7%E3%81%8C%E8%87%AA%E8%BB%A2%E8%BB%8A%E3%81%AB%E4%B9%97%E3%81%A3%E3%81%A6%E4%BD%93%E3%82%92%E3%81%8D%E3%81%9F%E3%81%88%E3%81%A6%E3%81%84%E3%82%8B%E3%80%82)
^ja-Q0622-answer

**ja-Q0623** — 本来は、貧困層の女性や子供に医療保護を提供するために創設された制度である、アメリカ低所得者医療扶助制度が、今日では、その予算の約３分の１を老人に費やしている。

Medicaid, a program originally created to provide medical care for poverty-level women and children, today spends almost a third of its budget on elderly people.

Why: Te-form links and requests. [[Japanese#^ja-Q0623|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%9C%AC%E6%9D%A5%E3%81%AF%E3%80%81%E8%B2%A7%E5%9B%B0%E5%B1%A4%E3%81%AE%E5%A5%B3%E6%80%A7%E3%82%84%E5%AD%90%E4%BE%9B%E3%81%AB%E5%8C%BB%E7%99%82%E4%BF%9D%E8%AD%B7%E3%82%92%E6%8F%90%E4%BE%9B%E3%81%99%E3%82%8B%E3%81%9F%E3%82%81%E3%81%AB%E5%89%B5%E8%A8%AD%E3%81%95%E3%82%8C%E3%81%9F%E5%88%B6%E5%BA%A6%E3%81%A7%E3%81%82%E3%82%8B%E3%80%81%E3%82%A2%E3%83%A1%E3%83%AA%E3%82%AB%E4%BD%8E%E6%89%80%E5%BE%97%E8%80%85%E5%8C%BB%E7%99%82%E6%89%B6%E5%8A%A9%E5%88%B6%E5%BA%A6%E3%81%8C%E3%80%81%E4%BB%8A%E6%97%A5%E3%81%A7%E3%81%AF%E3%80%81%E3%81%9D%E3%81%AE%E4%BA%88%E7%AE%97%E3%81%AE%E7%B4%84%EF%BC%93%E5%88%86%E3%81%AE%EF%BC%91%E3%82%92%E8%80%81%E4%BA%BA%E3%81%AB%E8%B2%BB%E3%82%84%E3%81%97%E3%81%A6%E3%81%84%E3%82%8B%E3%80%82)
^ja-Q0623-answer

**ja-Q0624** — 本来は、貧困層の女性や子供に医療保護を提供するために創設された制度である、アメリカ低所得者医療扶助制度が、今日では、その予算の約３分の１を老人に費やしている。

Medicaid, a program originally created to provide medical care for poverty-level women and children, today spends almost a third of its budget on elderly people.

The te-form joins predicates and builds constructions such as requests and いる aspect. The stem change depends on verb class. ている can mark an ongoing action or a resulting state.

Why: Te-form links and requests. [[Japanese#^ja-Q0624|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%9C%AC%E6%9D%A5%E3%81%AF%E3%80%81%E8%B2%A7%E5%9B%B0%E5%B1%A4%E3%81%AE%E5%A5%B3%E6%80%A7%E3%82%84%E5%AD%90%E4%BE%9B%E3%81%AB%E5%8C%BB%E7%99%82%E4%BF%9D%E8%AD%B7%E3%82%92%E6%8F%90%E4%BE%9B%E3%81%99%E3%82%8B%E3%81%9F%E3%82%81%E3%81%AB%E5%89%B5%E8%A8%AD%E3%81%95%E3%82%8C%E3%81%9F%E5%88%B6%E5%BA%A6%E3%81%A7%E3%81%82%E3%82%8B%E3%80%81%E3%82%A2%E3%83%A1%E3%83%AA%E3%82%AB%E4%BD%8E%E6%89%80%E5%BE%97%E8%80%85%E5%8C%BB%E7%99%82%E6%89%B6%E5%8A%A9%E5%88%B6%E5%BA%A6%E3%81%8C%E3%80%81%E4%BB%8A%E6%97%A5%E3%81%A7%E3%81%AF%E3%80%81%E3%81%9D%E3%81%AE%E4%BA%88%E7%AE%97%E3%81%AE%E7%B4%84%EF%BC%93%E5%88%86%E3%81%AE%EF%BC%91%E3%82%92%E8%80%81%E4%BA%BA%E3%81%AB%E8%B2%BB%E3%82%84%E3%81%97%E3%81%A6%E3%81%84%E3%82%8B%E3%80%82)
^ja-Q0624-answer

**ja-Q0625** — タイの国民は自国の首都を「クルンテープ」と呼んでいる。これは訳すと「天使の都」という意味である。

Thai people call their country's capital Krung Thep. If you translate this it means 'City of Angels'.

Expected form: **でいる**

Why: Te-form links and requests. [[Japanese#^ja-Q0625|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%82%BF%E3%82%A4%E3%81%AE%E5%9B%BD%E6%B0%91%E3%81%AF%E8%87%AA%E5%9B%BD%E3%81%AE%E9%A6%96%E9%83%BD%E3%82%92%E3%80%8C%E3%82%AF%E3%83%AB%E3%83%B3%E3%83%86%E3%83%BC%E3%83%97%E3%80%8D%E3%81%A8%E5%91%BC%E3%82%93%E3%81%A7%E3%81%84%E3%82%8B%E3%80%82%E3%81%93%E3%82%8C%E3%81%AF%E8%A8%B3%E3%81%99%E3%81%A8%E3%80%8C%E5%A4%A9%E4%BD%BF%E3%81%AE%E9%83%BD%E3%80%8D%E3%81%A8%E3%81%84%E3%81%86%E6%84%8F%E5%91%B3%E3%81%A7%E3%81%82%E3%82%8B%E3%80%82)
^ja-Q0625-answer

**ja-Q0626** — タイの国民は自国の首都を「クルンテープ」と呼んでいる。これは訳すと「天使の都」という意味である。

Thai people call their country's capital Krung Thep. If you translate this it means 'City of Angels'.

Expected form: **でいる**

Why: Te-form links and requests. [[Japanese#^ja-Q0626|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%82%BF%E3%82%A4%E3%81%AE%E5%9B%BD%E6%B0%91%E3%81%AF%E8%87%AA%E5%9B%BD%E3%81%AE%E9%A6%96%E9%83%BD%E3%82%92%E3%80%8C%E3%82%AF%E3%83%AB%E3%83%B3%E3%83%86%E3%83%BC%E3%83%97%E3%80%8D%E3%81%A8%E5%91%BC%E3%82%93%E3%81%A7%E3%81%84%E3%82%8B%E3%80%82%E3%81%93%E3%82%8C%E3%81%AF%E8%A8%B3%E3%81%99%E3%81%A8%E3%80%8C%E5%A4%A9%E4%BD%BF%E3%81%AE%E9%83%BD%E3%80%8D%E3%81%A8%E3%81%84%E3%81%86%E6%84%8F%E5%91%B3%E3%81%A7%E3%81%82%E3%82%8B%E3%80%82)
^ja-Q0626-answer

**ja-Q0627** — 私は数学では彼より劣っている。

I am inferior to him in mathematics.

Expected form: **ている**

Why: Te-form links and requests. [[Japanese#^ja-Q0627|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AF%E6%95%B0%E5%AD%A6%E3%81%A7%E3%81%AF%E5%BD%BC%E3%82%88%E3%82%8A%E5%8A%A3%E3%81%A3%E3%81%A6%E3%81%84%E3%82%8B%E3%80%82)
^ja-Q0627-answer

**ja-Q0628** — 私は数学では彼より劣っている。

I am inferior to him in mathematics.

Why: Te-form links and requests. [[Japanese#^ja-Q0628|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AF%E6%95%B0%E5%AD%A6%E3%81%A7%E3%81%AF%E5%BD%BC%E3%82%88%E3%82%8A%E5%8A%A3%E3%81%A3%E3%81%A6%E3%81%84%E3%82%8B%E3%80%82)
^ja-Q0628-answer

**ja-Q0629** — 彼はクラスメート全員と上手く付き合っている。

He's getting along well with all of his classmates.

Why: Te-form links and requests. [[Japanese#^ja-Q0629|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%AF%E3%82%AF%E3%83%A9%E3%82%B9%E3%83%A1%E3%83%BC%E3%83%88%E5%85%A8%E5%93%A1%E3%81%A8%E4%B8%8A%E6%89%8B%E3%81%8F%E4%BB%98%E3%81%8D%E5%90%88%E3%81%A3%E3%81%A6%E3%81%84%E3%82%8B%E3%80%82)
^ja-Q0629-answer

**ja-Q0630** — 彼はクラスメート全員と上手く付き合っている。

He's getting along well with all of his classmates.

The te-form joins predicates and builds constructions such as requests and いる aspect. The stem change depends on verb class. ている can mark an ongoing action or a resulting state.

Why: Te-form links and requests. [[Japanese#^ja-Q0630|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%AF%E3%82%AF%E3%83%A9%E3%82%B9%E3%83%A1%E3%83%BC%E3%83%88%E5%85%A8%E5%93%A1%E3%81%A8%E4%B8%8A%E6%89%8B%E3%81%8F%E4%BB%98%E3%81%8D%E5%90%88%E3%81%A3%E3%81%A6%E3%81%84%E3%82%8B%E3%80%82)
^ja-Q0630-answer

**ja-Q0631** — 道に迷っているんですか。

Are you lost?

Expected form: **ている**

Why: Te-form links and requests. [[Japanese#^ja-Q0631|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E9%81%93%E3%81%AB%E8%BF%B7%E3%81%A3%E3%81%A6%E3%81%84%E3%82%8B%E3%82%93%E3%81%A7%E3%81%99%E3%81%8B%E3%80%82)
^ja-Q0631-answer

**ja-Q0632** — 道に迷っているんですか。

Are you lost?

Expected form: **ている**

Why: Te-form links and requests. [[Japanese#^ja-Q0632|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E9%81%93%E3%81%AB%E8%BF%B7%E3%81%A3%E3%81%A6%E3%81%84%E3%82%8B%E3%82%93%E3%81%A7%E3%81%99%E3%81%8B%E3%80%82)
^ja-Q0632-answer

**ja-Q0633** — それは彼女でした。彼女はそっと私に忍び寄ろうとしているのです。

That was her. She was trying to creep up on me unnoticed.

Expected form: **ている**

Why: Te-form links and requests. [[Japanese#^ja-Q0633|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%9D%E3%82%8C%E3%81%AF%E5%BD%BC%E5%A5%B3%E3%81%A7%E3%81%97%E3%81%9F%E3%80%82%E5%BD%BC%E5%A5%B3%E3%81%AF%E3%81%9D%E3%81%A3%E3%81%A8%E7%A7%81%E3%81%AB%E5%BF%8D%E3%81%B3%E5%AF%84%E3%82%8D%E3%81%86%E3%81%A8%E3%81%97%E3%81%A6%E3%81%84%E3%82%8B%E3%81%AE%E3%81%A7%E3%81%99%E3%80%82)
^ja-Q0633-answer

**ja-Q0634** — それは彼女でした。彼女はそっと私に忍び寄ろうとしているのです。

That was her. She was trying to creep up on me unnoticed.

Why: Te-form links and requests. [[Japanese#^ja-Q0634|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%9D%E3%82%8C%E3%81%AF%E5%BD%BC%E5%A5%B3%E3%81%A7%E3%81%97%E3%81%9F%E3%80%82%E5%BD%BC%E5%A5%B3%E3%81%AF%E3%81%9D%E3%81%A3%E3%81%A8%E7%A7%81%E3%81%AB%E5%BF%8D%E3%81%B3%E5%AF%84%E3%82%8D%E3%81%86%E3%81%A8%E3%81%97%E3%81%A6%E3%81%84%E3%82%8B%E3%81%AE%E3%81%A7%E3%81%99%E3%80%82)
^ja-Q0634-answer

**ja-Q0635** — 帰って来るまでここで待っていてください。

Wait here till I come back.

Why: Te-form links and requests. [[Japanese#^ja-Q0635|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%B8%B0%E3%81%A3%E3%81%A6%E6%9D%A5%E3%82%8B%E3%81%BE%E3%81%A7%E3%81%93%E3%81%93%E3%81%A7%E5%BE%85%E3%81%A3%E3%81%A6%E3%81%84%E3%81%A6%E3%81%8F%E3%81%A0%E3%81%95%E3%81%84%E3%80%82)
^ja-Q0635-answer

**ja-Q0636** — 帰って来るまでここで待っていてください。

Wait here till I come back.

The te-form joins predicates and builds constructions such as requests and いる aspect. The stem change depends on verb class. ている can mark an ongoing action or a resulting state.

Why: Te-form links and requests. [[Japanese#^ja-Q0636|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%B8%B0%E3%81%A3%E3%81%A6%E6%9D%A5%E3%82%8B%E3%81%BE%E3%81%A7%E3%81%93%E3%81%93%E3%81%A7%E5%BE%85%E3%81%A3%E3%81%A6%E3%81%84%E3%81%A6%E3%81%8F%E3%81%A0%E3%81%95%E3%81%84%E3%80%82)
^ja-Q0636-answer

**ja-Q0637** — 私は彼の勝利を確信している。

I am sure of his victory.

Expected form: **ている**

Why: Te-form links and requests. [[Japanese#^ja-Q0637|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AF%E5%BD%BC%E3%81%AE%E5%8B%9D%E5%88%A9%E3%82%92%E7%A2%BA%E4%BF%A1%E3%81%97%E3%81%A6%E3%81%84%E3%82%8B%E3%80%82)
^ja-Q0637-answer

**ja-Q0638** — 私は彼の勝利を確信している。

I am sure of his victory.

Expected form: **ている**

Why: Te-form links and requests. [[Japanese#^ja-Q0638|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AF%E5%BD%BC%E3%81%AE%E5%8B%9D%E5%88%A9%E3%82%92%E7%A2%BA%E4%BF%A1%E3%81%97%E3%81%A6%E3%81%84%E3%82%8B%E3%80%82)
^ja-Q0638-answer

**ja-Q0639** — ジェーンはそのパーティーを楽しんでいるようにみえる。

Jane appears to be enjoying the party.

Expected form: **でいる**

Why: Te-form links and requests. [[Japanese#^ja-Q0639|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%82%B8%E3%82%A7%E3%83%BC%E3%83%B3%E3%81%AF%E3%81%9D%E3%81%AE%E3%83%91%E3%83%BC%E3%83%86%E3%82%A3%E3%83%BC%E3%82%92%E6%A5%BD%E3%81%97%E3%82%93%E3%81%A7%E3%81%84%E3%82%8B%E3%82%88%E3%81%86%E3%81%AB%E3%81%BF%E3%81%88%E3%82%8B%E3%80%82)
^ja-Q0639-answer

**ja-Q0640** — ジェーンはそのパーティーを楽しんでいるようにみえる。

Jane appears to be enjoying the party.

Why: Te-form links and requests. [[Japanese#^ja-Q0640|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%82%B8%E3%82%A7%E3%83%BC%E3%83%B3%E3%81%AF%E3%81%9D%E3%81%AE%E3%83%91%E3%83%BC%E3%83%86%E3%82%A3%E3%83%BC%E3%82%92%E6%A5%BD%E3%81%97%E3%82%93%E3%81%A7%E3%81%84%E3%82%8B%E3%82%88%E3%81%86%E3%81%AB%E3%81%BF%E3%81%88%E3%82%8B%E3%80%82)
^ja-Q0640-answer

**ja-Q0641** — それについてよく考えて、私に結論を知らせてください。

Please think it over and let me know your decision.

Why: Te-form links and requests. [[Japanese#^ja-Q0641|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%9D%E3%82%8C%E3%81%AB%E3%81%A4%E3%81%84%E3%81%A6%E3%82%88%E3%81%8F%E8%80%83%E3%81%88%E3%81%A6%E3%80%81%E7%A7%81%E3%81%AB%E7%B5%90%E8%AB%96%E3%82%92%E7%9F%A5%E3%82%89%E3%81%9B%E3%81%A6%E3%81%8F%E3%81%A0%E3%81%95%E3%81%84%E3%80%82)
^ja-Q0641-answer

**ja-Q0642** — それについてよく考えて、私に結論を知らせてください。

Please think it over and let me know your decision.

The te-form joins predicates and builds constructions such as requests and いる aspect. The stem change depends on verb class. ている can mark an ongoing action or a resulting state.

Why: Te-form links and requests. [[Japanese#^ja-Q0642|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%9D%E3%82%8C%E3%81%AB%E3%81%A4%E3%81%84%E3%81%A6%E3%82%88%E3%81%8F%E8%80%83%E3%81%88%E3%81%A6%E3%80%81%E7%A7%81%E3%81%AB%E7%B5%90%E8%AB%96%E3%82%92%E7%9F%A5%E3%82%89%E3%81%9B%E3%81%A6%E3%81%8F%E3%81%A0%E3%81%95%E3%81%84%E3%80%82)
^ja-Q0642-answer

**ja-Q0643** — その問題は私たちに重くのしかかっている。

The problem bears heavily on us.

Expected form: **ている**

Why: Te-form links and requests. [[Japanese#^ja-Q0643|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%9D%E3%81%AE%E5%95%8F%E9%A1%8C%E3%81%AF%E7%A7%81%E3%81%9F%E3%81%A1%E3%81%AB%E9%87%8D%E3%81%8F%E3%81%AE%E3%81%97%E3%81%8B%E3%81%8B%E3%81%A3%E3%81%A6%E3%81%84%E3%82%8B%E3%80%82)
^ja-Q0643-answer

**ja-Q0644** — その問題は私たちに重くのしかかっている。

The problem bears heavily on us.

Expected form: **ている**

Why: Te-form links and requests. [[Japanese#^ja-Q0644|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%9D%E3%81%AE%E5%95%8F%E9%A1%8C%E3%81%AF%E7%A7%81%E3%81%9F%E3%81%A1%E3%81%AB%E9%87%8D%E3%81%8F%E3%81%AE%E3%81%97%E3%81%8B%E3%81%8B%E3%81%A3%E3%81%A6%E3%81%84%E3%82%8B%E3%80%82)
^ja-Q0644-answer

**ja-Q0645** — 日本の女性は平均２６歳で結婚する。出生率が下がっているのも不思議ではない。

Japanese women marry at 26 on average. It is no mystery that the birthrate is declining.

Expected form: **ている**

Why: Te-form links and requests. [[Japanese#^ja-Q0645|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%97%A5%E6%9C%AC%E3%81%AE%E5%A5%B3%E6%80%A7%E3%81%AF%E5%B9%B3%E5%9D%87%EF%BC%92%EF%BC%96%E6%AD%B3%E3%81%A7%E7%B5%90%E5%A9%9A%E3%81%99%E3%82%8B%E3%80%82%E5%87%BA%E7%94%9F%E7%8E%87%E3%81%8C%E4%B8%8B%E3%81%8C%E3%81%A3%E3%81%A6%E3%81%84%E3%82%8B%E3%81%AE%E3%82%82%E4%B8%8D%E6%80%9D%E8%AD%B0%E3%81%A7%E3%81%AF%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0645-answer

**ja-Q0646** — 日本の女性は平均２６歳で結婚する。出生率が下がっているのも不思議ではない。

Japanese women marry at 26 on average. It is no mystery that the birthrate is declining.

Why: Te-form links and requests. [[Japanese#^ja-Q0646|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%97%A5%E6%9C%AC%E3%81%AE%E5%A5%B3%E6%80%A7%E3%81%AF%E5%B9%B3%E5%9D%87%EF%BC%92%EF%BC%96%E6%AD%B3%E3%81%A7%E7%B5%90%E5%A9%9A%E3%81%99%E3%82%8B%E3%80%82%E5%87%BA%E7%94%9F%E7%8E%87%E3%81%8C%E4%B8%8B%E3%81%8C%E3%81%A3%E3%81%A6%E3%81%84%E3%82%8B%E3%81%AE%E3%82%82%E4%B8%8D%E6%80%9D%E8%AD%B0%E3%81%A7%E3%81%AF%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0646-answer

**ja-Q0647** — アメリカにはいくつかの人種が一緒に住んでいる。

Several races live together in America.

Why: Te-form links and requests. [[Japanese#^ja-Q0647|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%82%A2%E3%83%A1%E3%83%AA%E3%82%AB%E3%81%AB%E3%81%AF%E3%81%84%E3%81%8F%E3%81%A4%E3%81%8B%E3%81%AE%E4%BA%BA%E7%A8%AE%E3%81%8C%E4%B8%80%E7%B7%92%E3%81%AB%E4%BD%8F%E3%82%93%E3%81%A7%E3%81%84%E3%82%8B%E3%80%82)
^ja-Q0647-answer

**ja-Q0648** — アメリカにはいくつかの人種が一緒に住んでいる。

Several races live together in America.

The te-form joins predicates and builds constructions such as requests and いる aspect. The stem change depends on verb class. ている can mark an ongoing action or a resulting state.

Why: Te-form links and requests. [[Japanese#^ja-Q0648|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%82%A2%E3%83%A1%E3%83%AA%E3%82%AB%E3%81%AB%E3%81%AF%E3%81%84%E3%81%8F%E3%81%A4%E3%81%8B%E3%81%AE%E4%BA%BA%E7%A8%AE%E3%81%8C%E4%B8%80%E7%B7%92%E3%81%AB%E4%BD%8F%E3%82%93%E3%81%A7%E3%81%84%E3%82%8B%E3%80%82)
^ja-Q0648-answer

**ja-Q0649** — 議題に上っている項目（の議論）を続けましょう。

Let's proceed with the items on the agenda.

Expected form: **ている**

Why: Te-form links and requests. [[Japanese#^ja-Q0649|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E8%AD%B0%E9%A1%8C%E3%81%AB%E4%B8%8A%E3%81%A3%E3%81%A6%E3%81%84%E3%82%8B%E9%A0%85%E7%9B%AE%EF%BC%88%E3%81%AE%E8%AD%B0%E8%AB%96%EF%BC%89%E3%82%92%E7%B6%9A%E3%81%91%E3%81%BE%E3%81%97%E3%82%87%E3%81%86%E3%80%82)
^ja-Q0649-answer

**ja-Q0650** — 議題に上っている項目（の議論）を続けましょう。

Let's proceed with the items on the agenda.

Expected form: **ている**

Why: Te-form links and requests. [[Japanese#^ja-Q0650|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E8%AD%B0%E9%A1%8C%E3%81%AB%E4%B8%8A%E3%81%A3%E3%81%A6%E3%81%84%E3%82%8B%E9%A0%85%E7%9B%AE%EF%BC%88%E3%81%AE%E8%AD%B0%E8%AB%96%EF%BC%89%E3%82%92%E7%B6%9A%E3%81%91%E3%81%BE%E3%81%97%E3%82%87%E3%81%86%E3%80%82)
^ja-Q0650-answer


### Answers 651–700

**ja-Q0651** — これ見たことある？

Have you seen this?

Expected form: **たこと**

Why: Plain past and experience. [[Japanese#^ja-Q0651|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%93%E3%82%8C%E8%A6%8B%E3%81%9F%E3%81%93%E3%81%A8%E3%81%82%E3%82%8B%EF%BC%9F)
^ja-Q0651-answer

**ja-Q0652** — これ見たことある？

Have you seen this?

Why: Plain past and experience. [[Japanese#^ja-Q0652|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%93%E3%82%8C%E8%A6%8B%E3%81%9F%E3%81%93%E3%81%A8%E3%81%82%E3%82%8B%EF%BC%9F)
^ja-Q0652-answer

**ja-Q0653** — 彼は涙を流したことがはずかしかった。

He was ashamed of his tears.

Why: Plain past and experience. [[Japanese#^ja-Q0653|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%AF%E6%B6%99%E3%82%92%E6%B5%81%E3%81%97%E3%81%9F%E3%81%93%E3%81%A8%E3%81%8C%E3%81%AF%E3%81%9A%E3%81%8B%E3%81%97%E3%81%8B%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0653-answer

**ja-Q0654** — 彼は涙を流したことがはずかしかった。

He was ashamed of his tears.

A past form plus ことがある expresses experience. A past verb also modifies a noun directly. The construction as a whole determines the reading; the ending alone does not establish experience.

Why: Plain past and experience. [[Japanese#^ja-Q0654|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%AF%E6%B6%99%E3%82%92%E6%B5%81%E3%81%97%E3%81%9F%E3%81%93%E3%81%A8%E3%81%8C%E3%81%AF%E3%81%9A%E3%81%8B%E3%81%97%E3%81%8B%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0654-answer

**ja-Q0655** — お返事が遅れたことをお許し下さい。

Excuse me for not having answered your letter sooner.

Expected form: **たこと**

Why: Plain past and experience. [[Japanese#^ja-Q0655|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%8A%E8%BF%94%E4%BA%8B%E3%81%8C%E9%81%85%E3%82%8C%E3%81%9F%E3%81%93%E3%81%A8%E3%82%92%E3%81%8A%E8%A8%B1%E3%81%97%E4%B8%8B%E3%81%95%E3%81%84%E3%80%82)
^ja-Q0655-answer

**ja-Q0656** — お返事が遅れたことをお許し下さい。

Excuse me for not having answered your letter sooner.

Expected form: **たこと**

Why: Plain past and experience. [[Japanese#^ja-Q0656|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%8A%E8%BF%94%E4%BA%8B%E3%81%8C%E9%81%85%E3%82%8C%E3%81%9F%E3%81%93%E3%81%A8%E3%82%92%E3%81%8A%E8%A8%B1%E3%81%97%E4%B8%8B%E3%81%95%E3%81%84%E3%80%82)
^ja-Q0656-answer

**ja-Q0657** — 次に起こったことは恐ろしかった。

What happened next was terrible.

Expected form: **たこと**

Why: Plain past and experience. [[Japanese#^ja-Q0657|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%AC%A1%E3%81%AB%E8%B5%B7%E3%81%93%E3%81%A3%E3%81%9F%E3%81%93%E3%81%A8%E3%81%AF%E6%81%90%E3%82%8D%E3%81%97%E3%81%8B%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0657-answer

**ja-Q0658** — 次に起こったことは恐ろしかった。

What happened next was terrible.

Why: Plain past and experience. [[Japanese#^ja-Q0658|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%AC%A1%E3%81%AB%E8%B5%B7%E3%81%93%E3%81%A3%E3%81%9F%E3%81%93%E3%81%A8%E3%81%AF%E6%81%90%E3%82%8D%E3%81%97%E3%81%8B%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0658-answer

**ja-Q0659** — 私は実際、そういったことは好きではない。

I don't really care for that sort of thing.

Why: Plain past and experience. [[Japanese#^ja-Q0659|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AF%E5%AE%9F%E9%9A%9B%E3%80%81%E3%81%9D%E3%81%86%E3%81%84%E3%81%A3%E3%81%9F%E3%81%93%E3%81%A8%E3%81%AF%E5%A5%BD%E3%81%8D%E3%81%A7%E3%81%AF%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0659-answer

**ja-Q0660** — 私は実際、そういったことは好きではない。

I don't really care for that sort of thing.

A past form plus ことがある expresses experience. A past verb also modifies a noun directly. The construction as a whole determines the reading; the ending alone does not establish experience.

Why: Plain past and experience. [[Japanese#^ja-Q0660|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AF%E5%AE%9F%E9%9A%9B%E3%80%81%E3%81%9D%E3%81%86%E3%81%84%E3%81%A3%E3%81%9F%E3%81%93%E3%81%A8%E3%81%AF%E5%A5%BD%E3%81%8D%E3%81%A7%E3%81%AF%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0660-answer

**ja-Q0661** — 直美は一等賞をとったことを、とても喜んでいる。

Naomi is very glad about having won first prize.

Expected form: **たこと**

Why: Plain past and experience. [[Japanese#^ja-Q0661|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%9B%B4%E7%BE%8E%E3%81%AF%E4%B8%80%E7%AD%89%E8%B3%9E%E3%82%92%E3%81%A8%E3%81%A3%E3%81%9F%E3%81%93%E3%81%A8%E3%82%92%E3%80%81%E3%81%A8%E3%81%A6%E3%82%82%E5%96%9C%E3%82%93%E3%81%A7%E3%81%84%E3%82%8B%E3%80%82)
^ja-Q0661-answer

**ja-Q0662** — 直美は一等賞をとったことを、とても喜んでいる。

Naomi is very glad about having won first prize.

Expected form: **たこと**

Why: Plain past and experience. [[Japanese#^ja-Q0662|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%9B%B4%E7%BE%8E%E3%81%AF%E4%B8%80%E7%AD%89%E8%B3%9E%E3%82%92%E3%81%A8%E3%81%A3%E3%81%9F%E3%81%93%E3%81%A8%E3%82%92%E3%80%81%E3%81%A8%E3%81%A6%E3%82%82%E5%96%9C%E3%82%93%E3%81%A7%E3%81%84%E3%82%8B%E3%80%82)
^ja-Q0662-answer

**ja-Q0663** — トムはメアリーのお金を盗んだことを認めた。

Tom admitted that he had stolen Mary's money.

Expected form: **だこと**

Why: Plain past and experience. [[Japanese#^ja-Q0663|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%83%88%E3%83%A0%E3%81%AF%E3%83%A1%E3%82%A2%E3%83%AA%E3%83%BC%E3%81%AE%E3%81%8A%E9%87%91%E3%82%92%E7%9B%97%E3%82%93%E3%81%A0%E3%81%93%E3%81%A8%E3%82%92%E8%AA%8D%E3%82%81%E3%81%9F%E3%80%82)
^ja-Q0663-answer

**ja-Q0664** — トムはメアリーのお金を盗んだことを認めた。

Tom admitted that he had stolen Mary's money.

Why: Plain past and experience. [[Japanese#^ja-Q0664|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%83%88%E3%83%A0%E3%81%AF%E3%83%A1%E3%82%A2%E3%83%AA%E3%83%BC%E3%81%AE%E3%81%8A%E9%87%91%E3%82%92%E7%9B%97%E3%82%93%E3%81%A0%E3%81%93%E3%81%A8%E3%82%92%E8%AA%8D%E3%82%81%E3%81%9F%E3%80%82)
^ja-Q0664-answer

**ja-Q0665** — 彼女に会ったことがない。

Never have I seen her before.

Why: Plain past and experience. [[Japanese#^ja-Q0665|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E5%A5%B3%E3%81%AB%E4%BC%9A%E3%81%A3%E3%81%9F%E3%81%93%E3%81%A8%E3%81%8C%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0665-answer

**ja-Q0666** — 彼女に会ったことがない。

Never have I seen her before.

A past form plus ことがある expresses experience. A past verb also modifies a noun directly. The construction as a whole determines the reading; the ending alone does not establish experience.

Why: Plain past and experience. [[Japanese#^ja-Q0666|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E5%A5%B3%E3%81%AB%E4%BC%9A%E3%81%A3%E3%81%9F%E3%81%93%E3%81%A8%E3%81%8C%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0666-answer

**ja-Q0667** — ボストンでは雨が降っていましたか？

Was it raining in Boston?

Expected form: **ました**

Why: Plain past and experience. [[Japanese#^ja-Q0667|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%83%9C%E3%82%B9%E3%83%88%E3%83%B3%E3%81%A7%E3%81%AF%E9%9B%A8%E3%81%8C%E9%99%8D%E3%81%A3%E3%81%A6%E3%81%84%E3%81%BE%E3%81%97%E3%81%9F%E3%81%8B%EF%BC%9F)
^ja-Q0667-answer

**ja-Q0668** — ボストンでは雨が降っていましたか？

Was it raining in Boston?

Expected form: **ました**

Why: Plain past and experience. [[Japanese#^ja-Q0668|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%83%9C%E3%82%B9%E3%83%88%E3%83%B3%E3%81%A7%E3%81%AF%E9%9B%A8%E3%81%8C%E9%99%8D%E3%81%A3%E3%81%A6%E3%81%84%E3%81%BE%E3%81%97%E3%81%9F%E3%81%8B%EF%BC%9F)
^ja-Q0668-answer

**ja-Q0669** — 彼女が二度結婚したことは本当だった。

It was true that she had got married twice.

Expected form: **たこと**

Why: Plain past and experience. [[Japanese#^ja-Q0669|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E5%A5%B3%E3%81%8C%E4%BA%8C%E5%BA%A6%E7%B5%90%E5%A9%9A%E3%81%97%E3%81%9F%E3%81%93%E3%81%A8%E3%81%AF%E6%9C%AC%E5%BD%93%E3%81%A0%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0669-answer

**ja-Q0670** — 彼女が二度結婚したことは本当だった。

It was true that she had got married twice.

Why: Plain past and experience. [[Japanese#^ja-Q0670|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E5%A5%B3%E3%81%8C%E4%BA%8C%E5%BA%A6%E7%B5%90%E5%A9%9A%E3%81%97%E3%81%9F%E3%81%93%E3%81%A8%E3%81%AF%E6%9C%AC%E5%BD%93%E3%81%A0%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0670-answer

**ja-Q0671** — 腰を下ろし、手帳を開きました。

I sat down and opened my notebook.

Why: Plain past and experience. [[Japanese#^ja-Q0671|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E8%85%B0%E3%82%92%E4%B8%8B%E3%82%8D%E3%81%97%E3%80%81%E6%89%8B%E5%B8%B3%E3%82%92%E9%96%8B%E3%81%8D%E3%81%BE%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0671-answer

**ja-Q0672** — 腰を下ろし、手帳を開きました。

I sat down and opened my notebook.

A past form plus ことがある expresses experience. A past verb also modifies a noun directly. The construction as a whole determines the reading; the ending alone does not establish experience.

Why: Plain past and experience. [[Japanese#^ja-Q0672|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E8%85%B0%E3%82%92%E4%B8%8B%E3%82%8D%E3%81%97%E3%80%81%E6%89%8B%E5%B8%B3%E3%82%92%E9%96%8B%E3%81%8D%E3%81%BE%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0672-answer

**ja-Q0673** — お宅が休暇で出かけている間に、泥棒が入りました。

A burglar broke into your house while you were away on vacation.

Expected form: **ました**

Why: Plain past and experience. [[Japanese#^ja-Q0673|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%8A%E5%AE%85%E3%81%8C%E4%BC%91%E6%9A%87%E3%81%A7%E5%87%BA%E3%81%8B%E3%81%91%E3%81%A6%E3%81%84%E3%82%8B%E9%96%93%E3%81%AB%E3%80%81%E6%B3%A5%E6%A3%92%E3%81%8C%E5%85%A5%E3%82%8A%E3%81%BE%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0673-answer

**ja-Q0674** — お宅が休暇で出かけている間に、泥棒が入りました。

A burglar broke into your house while you were away on vacation.

Expected form: **ました**

Why: Plain past and experience. [[Japanese#^ja-Q0674|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%8A%E5%AE%85%E3%81%8C%E4%BC%91%E6%9A%87%E3%81%A7%E5%87%BA%E3%81%8B%E3%81%91%E3%81%A6%E3%81%84%E3%82%8B%E9%96%93%E3%81%AB%E3%80%81%E6%B3%A5%E6%A3%92%E3%81%8C%E5%85%A5%E3%82%8A%E3%81%BE%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0674-answer

**ja-Q0675** — 日焼けし過ぎました。

I have a bad sunburn.

Expected form: **ました**

Why: Plain past and experience. [[Japanese#^ja-Q0675|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%97%A5%E7%84%BC%E3%81%91%E3%81%97%E9%81%8E%E3%81%8E%E3%81%BE%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0675-answer

**ja-Q0676** — 日焼けし過ぎました。

I have a bad sunburn.

Why: Plain past and experience. [[Japanese#^ja-Q0676|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%97%A5%E7%84%BC%E3%81%91%E3%81%97%E9%81%8E%E3%81%8E%E3%81%BE%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0676-answer

**ja-Q0677** — 彼女はそれまでニューヨークを見学したことがなかったので、彼女に案内して回りましょうと申し出た。

She had never seen New York before, so I offered to show her around.

Why: Plain past and experience. [[Japanese#^ja-Q0677|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E5%A5%B3%E3%81%AF%E3%81%9D%E3%82%8C%E3%81%BE%E3%81%A7%E3%83%8B%E3%83%A5%E3%83%BC%E3%83%A8%E3%83%BC%E3%82%AF%E3%82%92%E8%A6%8B%E5%AD%A6%E3%81%97%E3%81%9F%E3%81%93%E3%81%A8%E3%81%8C%E3%81%AA%E3%81%8B%E3%81%A3%E3%81%9F%E3%81%AE%E3%81%A7%E3%80%81%E5%BD%BC%E5%A5%B3%E3%81%AB%E6%A1%88%E5%86%85%E3%81%97%E3%81%A6%E5%9B%9E%E3%82%8A%E3%81%BE%E3%81%97%E3%82%87%E3%81%86%E3%81%A8%E7%94%B3%E3%81%97%E5%87%BA%E3%81%9F%E3%80%82)
^ja-Q0677-answer

**ja-Q0678** — 彼女はそれまでニューヨークを見学したことがなかったので、彼女に案内して回りましょうと申し出た。

She had never seen New York before, so I offered to show her around.

A past form plus ことがある expresses experience. A past verb also modifies a noun directly. The construction as a whole determines the reading; the ending alone does not establish experience.

Why: Plain past and experience. [[Japanese#^ja-Q0678|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E5%A5%B3%E3%81%AF%E3%81%9D%E3%82%8C%E3%81%BE%E3%81%A7%E3%83%8B%E3%83%A5%E3%83%BC%E3%83%A8%E3%83%BC%E3%82%AF%E3%82%92%E8%A6%8B%E5%AD%A6%E3%81%97%E3%81%9F%E3%81%93%E3%81%A8%E3%81%8C%E3%81%AA%E3%81%8B%E3%81%A3%E3%81%9F%E3%81%AE%E3%81%A7%E3%80%81%E5%BD%BC%E5%A5%B3%E3%81%AB%E6%A1%88%E5%86%85%E3%81%97%E3%81%A6%E5%9B%9E%E3%82%8A%E3%81%BE%E3%81%97%E3%82%87%E3%81%86%E3%81%A8%E7%94%B3%E3%81%97%E5%87%BA%E3%81%9F%E3%80%82)
^ja-Q0678-answer

**ja-Q0679** — ボールを丸く、そして堅くするために麦わらをいっぱいに詰め込んでいました。

They filled them with straw to make them round and hard.

Expected form: **ました**

Why: Plain past and experience. [[Japanese#^ja-Q0679|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%83%9C%E3%83%BC%E3%83%AB%E3%82%92%E4%B8%B8%E3%81%8F%E3%80%81%E3%81%9D%E3%81%97%E3%81%A6%E5%A0%85%E3%81%8F%E3%81%99%E3%82%8B%E3%81%9F%E3%82%81%E3%81%AB%E9%BA%A6%E3%82%8F%E3%82%89%E3%82%92%E3%81%84%E3%81%A3%E3%81%B1%E3%81%84%E3%81%AB%E8%A9%B0%E3%82%81%E8%BE%BC%E3%82%93%E3%81%A7%E3%81%84%E3%81%BE%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0679-answer

**ja-Q0680** — ボールを丸く、そして堅くするために麦わらをいっぱいに詰め込んでいました。

They filled them with straw to make them round and hard.

Expected form: **ました**

Why: Plain past and experience. [[Japanese#^ja-Q0680|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%83%9C%E3%83%BC%E3%83%AB%E3%82%92%E4%B8%B8%E3%81%8F%E3%80%81%E3%81%9D%E3%81%97%E3%81%A6%E5%A0%85%E3%81%8F%E3%81%99%E3%82%8B%E3%81%9F%E3%82%81%E3%81%AB%E9%BA%A6%E3%82%8F%E3%82%89%E3%82%92%E3%81%84%E3%81%A3%E3%81%B1%E3%81%84%E3%81%AB%E8%A9%B0%E3%82%81%E8%BE%BC%E3%82%93%E3%81%A7%E3%81%84%E3%81%BE%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0680-answer

**ja-Q0681** — 君はコアラを見たことがあるかい。

Have you ever seen a koala?

Expected form: **たこと**

Why: Plain past and experience. [[Japanese#^ja-Q0681|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%90%9B%E3%81%AF%E3%82%B3%E3%82%A2%E3%83%A9%E3%82%92%E8%A6%8B%E3%81%9F%E3%81%93%E3%81%A8%E3%81%8C%E3%81%82%E3%82%8B%E3%81%8B%E3%81%84%E3%80%82)
^ja-Q0681-answer

**ja-Q0682** — 君はコアラを見たことがあるかい。

Have you ever seen a koala?

Why: Plain past and experience. [[Japanese#^ja-Q0682|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%90%9B%E3%81%AF%E3%82%B3%E3%82%A2%E3%83%A9%E3%82%92%E8%A6%8B%E3%81%9F%E3%81%93%E3%81%A8%E3%81%8C%E3%81%82%E3%82%8B%E3%81%8B%E3%81%84%E3%80%82)
^ja-Q0682-answer

**ja-Q0683** — 時間通りに着きましたか。

Did you get there on time?

Why: Plain past and experience. [[Japanese#^ja-Q0683|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%99%82%E9%96%93%E9%80%9A%E3%82%8A%E3%81%AB%E7%9D%80%E3%81%8D%E3%81%BE%E3%81%97%E3%81%9F%E3%81%8B%E3%80%82)
^ja-Q0683-answer

**ja-Q0684** — 時間通りに着きましたか。

Did you get there on time?

A past form plus ことがある expresses experience. A past verb also modifies a noun directly. The construction as a whole determines the reading; the ending alone does not establish experience.

Why: Plain past and experience. [[Japanese#^ja-Q0684|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%99%82%E9%96%93%E9%80%9A%E3%82%8A%E3%81%AB%E7%9D%80%E3%81%8D%E3%81%BE%E3%81%97%E3%81%9F%E3%81%8B%E3%80%82)
^ja-Q0684-answer

**ja-Q0685** — 野球場には多くの興奮したファンがいました。

There were a lot of excited fans in the stadium.

Expected form: **ました**

Why: Plain past and experience. [[Japanese#^ja-Q0685|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E9%87%8E%E7%90%83%E5%A0%B4%E3%81%AB%E3%81%AF%E5%A4%9A%E3%81%8F%E3%81%AE%E8%88%88%E5%A5%AE%E3%81%97%E3%81%9F%E3%83%95%E3%82%A1%E3%83%B3%E3%81%8C%E3%81%84%E3%81%BE%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0685-answer

**ja-Q0686** — 野球場には多くの興奮したファンがいました。

There were a lot of excited fans in the stadium.

Expected form: **ました**

Why: Plain past and experience. [[Japanese#^ja-Q0686|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E9%87%8E%E7%90%83%E5%A0%B4%E3%81%AB%E3%81%AF%E5%A4%9A%E3%81%8F%E3%81%AE%E8%88%88%E5%A5%AE%E3%81%97%E3%81%9F%E3%83%95%E3%82%A1%E3%83%B3%E3%81%8C%E3%81%84%E3%81%BE%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0686-answer

**ja-Q0687** — 私はその会議で通訳を務めました。

I acted as interpreter at the meeting.

Expected form: **ました**

Why: Plain past and experience. [[Japanese#^ja-Q0687|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AF%E3%81%9D%E3%81%AE%E4%BC%9A%E8%AD%B0%E3%81%A7%E9%80%9A%E8%A8%B3%E3%82%92%E5%8B%99%E3%82%81%E3%81%BE%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0687-answer

**ja-Q0688** — 私はその会議で通訳を務めました。

I acted as interpreter at the meeting.

Why: Plain past and experience. [[Japanese#^ja-Q0688|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AF%E3%81%9D%E3%81%AE%E4%BC%9A%E8%AD%B0%E3%81%A7%E9%80%9A%E8%A8%B3%E3%82%92%E5%8B%99%E3%82%81%E3%81%BE%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0688-answer

**ja-Q0689** — スロバキア人のオペラ歌手の一人であるルチア・ポップのことを聞いたことがありますか。

Have you ever heard of Lucia Popp, who was a Slovakian opera singer?

Why: Plain past and experience. [[Japanese#^ja-Q0689|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%82%B9%E3%83%AD%E3%83%90%E3%82%AD%E3%82%A2%E4%BA%BA%E3%81%AE%E3%82%AA%E3%83%9A%E3%83%A9%E6%AD%8C%E6%89%8B%E3%81%AE%E4%B8%80%E4%BA%BA%E3%81%A7%E3%81%82%E3%82%8B%E3%83%AB%E3%83%81%E3%82%A2%E3%83%BB%E3%83%9D%E3%83%83%E3%83%97%E3%81%AE%E3%81%93%E3%81%A8%E3%82%92%E8%81%9E%E3%81%84%E3%81%9F%E3%81%93%E3%81%A8%E3%81%8C%E3%81%82%E3%82%8A%E3%81%BE%E3%81%99%E3%81%8B%E3%80%82)
^ja-Q0689-answer

**ja-Q0690** — スロバキア人のオペラ歌手の一人であるルチア・ポップのことを聞いたことがありますか。

Have you ever heard of Lucia Popp, who was a Slovakian opera singer?

A past form plus ことがある expresses experience. A past verb also modifies a noun directly. The construction as a whole determines the reading; the ending alone does not establish experience.

Why: Plain past and experience. [[Japanese#^ja-Q0690|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%82%B9%E3%83%AD%E3%83%90%E3%82%AD%E3%82%A2%E4%BA%BA%E3%81%AE%E3%82%AA%E3%83%9A%E3%83%A9%E6%AD%8C%E6%89%8B%E3%81%AE%E4%B8%80%E4%BA%BA%E3%81%A7%E3%81%82%E3%82%8B%E3%83%AB%E3%83%81%E3%82%A2%E3%83%BB%E3%83%9D%E3%83%83%E3%83%97%E3%81%AE%E3%81%93%E3%81%A8%E3%82%92%E8%81%9E%E3%81%84%E3%81%9F%E3%81%93%E3%81%A8%E3%81%8C%E3%81%82%E3%82%8A%E3%81%BE%E3%81%99%E3%81%8B%E3%80%82)
^ja-Q0690-answer

**ja-Q0691** — はい、着きました。

Here we are.

Expected form: **ました**

Why: Plain past and experience. [[Japanese#^ja-Q0691|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%AF%E3%81%84%E3%80%81%E7%9D%80%E3%81%8D%E3%81%BE%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0691-answer

**ja-Q0692** — はい、着きました。

Here we are.

Expected form: **ました**

Why: Plain past and experience. [[Japanese#^ja-Q0692|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%AF%E3%81%84%E3%80%81%E7%9D%80%E3%81%8D%E3%81%BE%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0692-answer

**ja-Q0693** — あなたがそれについて何かするつもりだと思ってました。

I thought you were going to do something about that.

Expected form: **ました**

Why: Plain past and experience. [[Japanese#^ja-Q0693|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%82%E3%81%AA%E3%81%9F%E3%81%8C%E3%81%9D%E3%82%8C%E3%81%AB%E3%81%A4%E3%81%84%E3%81%A6%E4%BD%95%E3%81%8B%E3%81%99%E3%82%8B%E3%81%A4%E3%82%82%E3%82%8A%E3%81%A0%E3%81%A8%E6%80%9D%E3%81%A3%E3%81%A6%E3%81%BE%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0693-answer

**ja-Q0694** — あなたがそれについて何かするつもりだと思ってました。

I thought you were going to do something about that.

Why: Plain past and experience. [[Japanese#^ja-Q0694|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%82%E3%81%AA%E3%81%9F%E3%81%8C%E3%81%9D%E3%82%8C%E3%81%AB%E3%81%A4%E3%81%84%E3%81%A6%E4%BD%95%E3%81%8B%E3%81%99%E3%82%8B%E3%81%A4%E3%82%82%E3%82%8A%E3%81%A0%E3%81%A8%E6%80%9D%E3%81%A3%E3%81%A6%E3%81%BE%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0694-answer

**ja-Q0695** — 妊娠検査を受けました。

I got a pregnancy test.

Why: Plain past and experience. [[Japanese#^ja-Q0695|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%A6%8A%E5%A8%A0%E6%A4%9C%E6%9F%BB%E3%82%92%E5%8F%97%E3%81%91%E3%81%BE%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0695-answer

**ja-Q0696** — 妊娠検査を受けました。

I got a pregnancy test.

A past form plus ことがある expresses experience. A past verb also modifies a noun directly. The construction as a whole determines the reading; the ending alone does not establish experience.

Why: Plain past and experience. [[Japanese#^ja-Q0696|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%A6%8A%E5%A8%A0%E6%A4%9C%E6%9F%BB%E3%82%92%E5%8F%97%E3%81%91%E3%81%BE%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0696-answer

**ja-Q0697** — 今日は少しでも練習しましたか。

Have you practiced any today?

Expected form: **ました**

Why: Plain past and experience. [[Japanese#^ja-Q0697|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E4%BB%8A%E6%97%A5%E3%81%AF%E5%B0%91%E3%81%97%E3%81%A7%E3%82%82%E7%B7%B4%E7%BF%92%E3%81%97%E3%81%BE%E3%81%97%E3%81%9F%E3%81%8B%E3%80%82)
^ja-Q0697-answer

**ja-Q0698** — 今日は少しでも練習しましたか。

Have you practiced any today?

Expected form: **ました**

Why: Plain past and experience. [[Japanese#^ja-Q0698|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E4%BB%8A%E6%97%A5%E3%81%AF%E5%B0%91%E3%81%97%E3%81%A7%E3%82%82%E7%B7%B4%E7%BF%92%E3%81%97%E3%81%BE%E3%81%97%E3%81%9F%E3%81%8B%E3%80%82)
^ja-Q0698-answer

**ja-Q0699** — 私は徹夜しました。

I stayed up all night.

Expected form: **ました**

Why: Plain past and experience. [[Japanese#^ja-Q0699|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AF%E5%BE%B9%E5%A4%9C%E3%81%97%E3%81%BE%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0699-answer

**ja-Q0700** — 私は徹夜しました。

I stayed up all night.

Why: Plain past and experience. [[Japanese#^ja-Q0700|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AF%E5%BE%B9%E5%A4%9C%E3%81%97%E3%81%BE%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0700-answer


### Answers 701–750

**ja-Q0701** — 彼は窓から出て行った。

He went out the window.

Why: Cause. [[Japanese#^ja-Q0701|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%AF%E7%AA%93%E3%81%8B%E3%82%89%E5%87%BA%E3%81%A6%E8%A1%8C%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0701-answer

**ja-Q0702** — 彼は窓から出て行った。

He went out the window.

から and ので can supply reasons. から also marks a source/start point. Degree of explicitness and discourse tone differ between causal expressions.

Why: Cause. [[Japanese#^ja-Q0702|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%AF%E7%AA%93%E3%81%8B%E3%82%89%E5%87%BA%E3%81%A6%E8%A1%8C%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0702-answer

**ja-Q0703** — 月は地球から遠い。

The moon is distant from the earth.

Expected form: **から**

Why: Cause. [[Japanese#^ja-Q0703|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%9C%88%E3%81%AF%E5%9C%B0%E7%90%83%E3%81%8B%E3%82%89%E9%81%A0%E3%81%84%E3%80%82)
^ja-Q0703-answer

**ja-Q0704** — 月は地球から遠い。

The moon is distant from the earth.

Expected form: **から**

Why: Cause. [[Japanese#^ja-Q0704|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%9C%88%E3%81%AF%E5%9C%B0%E7%90%83%E3%81%8B%E3%82%89%E9%81%A0%E3%81%84%E3%80%82)
^ja-Q0704-answer

**ja-Q0705** — 私はただ休養したいのです。

I just want to rest.

Expected form: **ので**

Why: Cause. [[Japanese#^ja-Q0705|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AF%E3%81%9F%E3%81%A0%E4%BC%91%E9%A4%8A%E3%81%97%E3%81%9F%E3%81%84%E3%81%AE%E3%81%A7%E3%81%99%E3%80%82)
^ja-Q0705-answer

**ja-Q0706** — 私はただ休養したいのです。

I just want to rest.

Why: Cause. [[Japanese#^ja-Q0706|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AF%E3%81%9F%E3%81%A0%E4%BC%91%E9%A4%8A%E3%81%97%E3%81%9F%E3%81%84%E3%81%AE%E3%81%A7%E3%81%99%E3%80%82)
^ja-Q0706-answer

**ja-Q0707** — 彼女が恥ずかしがりやなので、なおいっそう好きです。

I like her all the better for her shyness.

Why: Cause. [[Japanese#^ja-Q0707|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E5%A5%B3%E3%81%8C%E6%81%A5%E3%81%9A%E3%81%8B%E3%81%97%E3%81%8C%E3%82%8A%E3%82%84%E3%81%AA%E3%81%AE%E3%81%A7%E3%80%81%E3%81%AA%E3%81%8A%E3%81%84%E3%81%A3%E3%81%9D%E3%81%86%E5%A5%BD%E3%81%8D%E3%81%A7%E3%81%99%E3%80%82)
^ja-Q0707-answer

**ja-Q0708** — 彼女が恥ずかしがりやなので、なおいっそう好きです。

I like her all the better for her shyness.

から and ので can supply reasons. から also marks a source/start point. Degree of explicitness and discourse tone differ between causal expressions.

Why: Cause. [[Japanese#^ja-Q0708|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E5%A5%B3%E3%81%8C%E6%81%A5%E3%81%9A%E3%81%8B%E3%81%97%E3%81%8C%E3%82%8A%E3%82%84%E3%81%AA%E3%81%AE%E3%81%A7%E3%80%81%E3%81%AA%E3%81%8A%E3%81%84%E3%81%A3%E3%81%9D%E3%81%86%E5%A5%BD%E3%81%8D%E3%81%A7%E3%81%99%E3%80%82)
^ja-Q0708-answer

**ja-Q0709** — 少年が車にはねられるのを見たのです。

I saw a boy knocked down by a car.

Expected form: **ので**

Why: Cause. [[Japanese#^ja-Q0709|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%B0%91%E5%B9%B4%E3%81%8C%E8%BB%8A%E3%81%AB%E3%81%AF%E3%81%AD%E3%82%89%E3%82%8C%E3%82%8B%E3%81%AE%E3%82%92%E8%A6%8B%E3%81%9F%E3%81%AE%E3%81%A7%E3%81%99%E3%80%82)
^ja-Q0709-answer

**ja-Q0710** — 少年が車にはねられるのを見たのです。

I saw a boy knocked down by a car.

Expected form: **ので**

Why: Cause. [[Japanese#^ja-Q0710|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%B0%91%E5%B9%B4%E3%81%8C%E8%BB%8A%E3%81%AB%E3%81%AF%E3%81%AD%E3%82%89%E3%82%8C%E3%82%8B%E3%81%AE%E3%82%92%E8%A6%8B%E3%81%9F%E3%81%AE%E3%81%A7%E3%81%99%E3%80%82)
^ja-Q0710-answer

**ja-Q0711** — どうすればいいのか分からなくて、彼女を呼んでみた。

Not knowing what to do, I called her.

Expected form: **から**

Why: Cause. [[Japanese#^ja-Q0711|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%A9%E3%81%86%E3%81%99%E3%82%8C%E3%81%B0%E3%81%84%E3%81%84%E3%81%AE%E3%81%8B%E5%88%86%E3%81%8B%E3%82%89%E3%81%AA%E3%81%8F%E3%81%A6%E3%80%81%E5%BD%BC%E5%A5%B3%E3%82%92%E5%91%BC%E3%82%93%E3%81%A7%E3%81%BF%E3%81%9F%E3%80%82)
^ja-Q0711-answer

**ja-Q0712** — どうすればいいのか分からなくて、彼女を呼んでみた。

Not knowing what to do, I called her.

Why: Cause. [[Japanese#^ja-Q0712|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%A9%E3%81%86%E3%81%99%E3%82%8C%E3%81%B0%E3%81%84%E3%81%84%E3%81%AE%E3%81%8B%E5%88%86%E3%81%8B%E3%82%89%E3%81%AA%E3%81%8F%E3%81%A6%E3%80%81%E5%BD%BC%E5%A5%B3%E3%82%92%E5%91%BC%E3%82%93%E3%81%A7%E3%81%BF%E3%81%9F%E3%80%82)
^ja-Q0712-answer

**ja-Q0713** — 私がその恐ろしい状況からあなたを救ってやるぞ。

I will rescue you from these horrible circumstances.

Why: Cause. [[Japanese#^ja-Q0713|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%8C%E3%81%9D%E3%81%AE%E6%81%90%E3%82%8D%E3%81%97%E3%81%84%E7%8A%B6%E6%B3%81%E3%81%8B%E3%82%89%E3%81%82%E3%81%AA%E3%81%9F%E3%82%92%E6%95%91%E3%81%A3%E3%81%A6%E3%82%84%E3%82%8B%E3%81%9E%E3%80%82)
^ja-Q0713-answer

**ja-Q0714** — 私がその恐ろしい状況からあなたを救ってやるぞ。

I will rescue you from these horrible circumstances.

から and ので can supply reasons. から also marks a source/start point. Degree of explicitness and discourse tone differ between causal expressions.

Why: Cause. [[Japanese#^ja-Q0714|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%8C%E3%81%9D%E3%81%AE%E6%81%90%E3%82%8D%E3%81%97%E3%81%84%E7%8A%B6%E6%B3%81%E3%81%8B%E3%82%89%E3%81%82%E3%81%AA%E3%81%9F%E3%82%92%E6%95%91%E3%81%A3%E3%81%A6%E3%82%84%E3%82%8B%E3%81%9E%E3%80%82)
^ja-Q0714-answer

**ja-Q0715** — 学生の頃はよくテニスをしたものです。

I used to play tennis when I was a student.

Expected form: **ので**

Why: Cause. [[Japanese#^ja-Q0715|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%AD%A6%E7%94%9F%E3%81%AE%E9%A0%83%E3%81%AF%E3%82%88%E3%81%8F%E3%83%86%E3%83%8B%E3%82%B9%E3%82%92%E3%81%97%E3%81%9F%E3%82%82%E3%81%AE%E3%81%A7%E3%81%99%E3%80%82)
^ja-Q0715-answer

**ja-Q0716** — 学生の頃はよくテニスをしたものです。

I used to play tennis when I was a student.

Expected form: **ので**

Why: Cause. [[Japanese#^ja-Q0716|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%AD%A6%E7%94%9F%E3%81%AE%E9%A0%83%E3%81%AF%E3%82%88%E3%81%8F%E3%83%86%E3%83%8B%E3%82%B9%E3%82%92%E3%81%97%E3%81%9F%E3%82%82%E3%81%AE%E3%81%A7%E3%81%99%E3%80%82)
^ja-Q0716-answer

**ja-Q0717** — 彼は水に飛び込んでから息をしようとして水面に浮かび上がってきた。

He dived into the water and came up for air.

Expected form: **から**

Why: Cause. [[Japanese#^ja-Q0717|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%AF%E6%B0%B4%E3%81%AB%E9%A3%9B%E3%81%B3%E8%BE%BC%E3%82%93%E3%81%A7%E3%81%8B%E3%82%89%E6%81%AF%E3%82%92%E3%81%97%E3%82%88%E3%81%86%E3%81%A8%E3%81%97%E3%81%A6%E6%B0%B4%E9%9D%A2%E3%81%AB%E6%B5%AE%E3%81%8B%E3%81%B3%E4%B8%8A%E3%81%8C%E3%81%A3%E3%81%A6%E3%81%8D%E3%81%9F%E3%80%82)
^ja-Q0717-answer

**ja-Q0718** — 彼は水に飛び込んでから息をしようとして水面に浮かび上がってきた。

He dived into the water and came up for air.

Why: Cause. [[Japanese#^ja-Q0718|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%AF%E6%B0%B4%E3%81%AB%E9%A3%9B%E3%81%B3%E8%BE%BC%E3%82%93%E3%81%A7%E3%81%8B%E3%82%89%E6%81%AF%E3%82%92%E3%81%97%E3%82%88%E3%81%86%E3%81%A8%E3%81%97%E3%81%A6%E6%B0%B4%E9%9D%A2%E3%81%AB%E6%B5%AE%E3%81%8B%E3%81%B3%E4%B8%8A%E3%81%8C%E3%81%A3%E3%81%A6%E3%81%8D%E3%81%9F%E3%80%82)
^ja-Q0718-answer

**ja-Q0719** — 生粋のお嬢様だからな。残念ながら悪戯とかじゃなくてあれで素だ。

She's pure bred blue-blood you see. Unfortunately that's no sort of put-on but her natural self.

Why: Cause. [[Japanese#^ja-Q0719|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%94%9F%E7%B2%8B%E3%81%AE%E3%81%8A%E5%AC%A2%E6%A7%98%E3%81%A0%E3%81%8B%E3%82%89%E3%81%AA%E3%80%82%E6%AE%8B%E5%BF%B5%E3%81%AA%E3%81%8C%E3%82%89%E6%82%AA%E6%88%AF%E3%81%A8%E3%81%8B%E3%81%98%E3%82%83%E3%81%AA%E3%81%8F%E3%81%A6%E3%81%82%E3%82%8C%E3%81%A7%E7%B4%A0%E3%81%A0%E3%80%82)
^ja-Q0719-answer

**ja-Q0720** — 生粋のお嬢様だからな。残念ながら悪戯とかじゃなくてあれで素だ。

She's pure bred blue-blood you see. Unfortunately that's no sort of put-on but her natural self.

から and ので can supply reasons. から also marks a source/start point. Degree of explicitness and discourse tone differ between causal expressions.

Why: Cause. [[Japanese#^ja-Q0720|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%94%9F%E7%B2%8B%E3%81%AE%E3%81%8A%E5%AC%A2%E6%A7%98%E3%81%A0%E3%81%8B%E3%82%89%E3%81%AA%E3%80%82%E6%AE%8B%E5%BF%B5%E3%81%AA%E3%81%8C%E3%82%89%E6%82%AA%E6%88%AF%E3%81%A8%E3%81%8B%E3%81%98%E3%82%83%E3%81%AA%E3%81%8F%E3%81%A6%E3%81%82%E3%82%8C%E3%81%A7%E7%B4%A0%E3%81%A0%E3%80%82)
^ja-Q0720-answer

**ja-Q0721** — いやいや本を読む人はだれも読書の喜びがわからない。

Anyone who is unwilling to read does not understand the joy of reading.

Expected form: **から**

Why: Cause. [[Japanese#^ja-Q0721|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%84%E3%82%84%E3%81%84%E3%82%84%E6%9C%AC%E3%82%92%E8%AA%AD%E3%82%80%E4%BA%BA%E3%81%AF%E3%81%A0%E3%82%8C%E3%82%82%E8%AA%AD%E6%9B%B8%E3%81%AE%E5%96%9C%E3%81%B3%E3%81%8C%E3%82%8F%E3%81%8B%E3%82%89%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0721-answer

**ja-Q0722** — いやいや本を読む人はだれも読書の喜びがわからない。

Anyone who is unwilling to read does not understand the joy of reading.

Expected form: **から**

Why: Cause. [[Japanese#^ja-Q0722|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%84%E3%82%84%E3%81%84%E3%82%84%E6%9C%AC%E3%82%92%E8%AA%AD%E3%82%80%E4%BA%BA%E3%81%AF%E3%81%A0%E3%82%8C%E3%82%82%E8%AA%AD%E6%9B%B8%E3%81%AE%E5%96%9C%E3%81%B3%E3%81%8C%E3%82%8F%E3%81%8B%E3%82%89%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0722-answer

**ja-Q0723** — 私は彼女から手紙をもらった。

I got a letter from her.

Expected form: **から**

Why: Cause. [[Japanese#^ja-Q0723|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AF%E5%BD%BC%E5%A5%B3%E3%81%8B%E3%82%89%E6%89%8B%E7%B4%99%E3%82%92%E3%82%82%E3%82%89%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0723-answer

**ja-Q0724** — 私は彼女から手紙をもらった。

I got a letter from her.

Why: Cause. [[Japanese#^ja-Q0724|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AF%E5%BD%BC%E5%A5%B3%E3%81%8B%E3%82%89%E6%89%8B%E7%B4%99%E3%82%92%E3%82%82%E3%82%89%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0724-answer

**ja-Q0725** — 学校の近くに住んでいるので、普段は歩いて通学する。

Living near the school, I usually walk there.

Why: Cause. [[Japanese#^ja-Q0725|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%AD%A6%E6%A0%A1%E3%81%AE%E8%BF%91%E3%81%8F%E3%81%AB%E4%BD%8F%E3%82%93%E3%81%A7%E3%81%84%E3%82%8B%E3%81%AE%E3%81%A7%E3%80%81%E6%99%AE%E6%AE%B5%E3%81%AF%E6%AD%A9%E3%81%84%E3%81%A6%E9%80%9A%E5%AD%A6%E3%81%99%E3%82%8B%E3%80%82)
^ja-Q0725-answer

**ja-Q0726** — 学校の近くに住んでいるので、普段は歩いて通学する。

Living near the school, I usually walk there.

から and ので can supply reasons. から also marks a source/start point. Degree of explicitness and discourse tone differ between causal expressions.

Why: Cause. [[Japanese#^ja-Q0726|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%AD%A6%E6%A0%A1%E3%81%AE%E8%BF%91%E3%81%8F%E3%81%AB%E4%BD%8F%E3%82%93%E3%81%A7%E3%81%84%E3%82%8B%E3%81%AE%E3%81%A7%E3%80%81%E6%99%AE%E6%AE%B5%E3%81%AF%E6%AD%A9%E3%81%84%E3%81%A6%E9%80%9A%E5%AD%A6%E3%81%99%E3%82%8B%E3%80%82)
^ja-Q0726-answer

**ja-Q0727** — 私たちはその時以来、彼女から便りをもらっていない。

We haven't heard from her since then.

Expected form: **から**

Why: Cause. [[Japanese#^ja-Q0727|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%9F%E3%81%A1%E3%81%AF%E3%81%9D%E3%81%AE%E6%99%82%E4%BB%A5%E6%9D%A5%E3%80%81%E5%BD%BC%E5%A5%B3%E3%81%8B%E3%82%89%E4%BE%BF%E3%82%8A%E3%82%92%E3%82%82%E3%82%89%E3%81%A3%E3%81%A6%E3%81%84%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0727-answer

**ja-Q0728** — 私たちはその時以来、彼女から便りをもらっていない。

We haven't heard from her since then.

Expected form: **から**

Why: Cause. [[Japanese#^ja-Q0728|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%9F%E3%81%A1%E3%81%AF%E3%81%9D%E3%81%AE%E6%99%82%E4%BB%A5%E6%9D%A5%E3%80%81%E5%BD%BC%E5%A5%B3%E3%81%8B%E3%82%89%E4%BE%BF%E3%82%8A%E3%82%92%E3%82%82%E3%82%89%E3%81%A3%E3%81%A6%E3%81%84%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0728-answer

**ja-Q0729** — 彼はその文法書から多くの用例を引用している。

He has extracted a great many examples from the grammar book.

Expected form: **から**

Why: Cause. [[Japanese#^ja-Q0729|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%AF%E3%81%9D%E3%81%AE%E6%96%87%E6%B3%95%E6%9B%B8%E3%81%8B%E3%82%89%E5%A4%9A%E3%81%8F%E3%81%AE%E7%94%A8%E4%BE%8B%E3%82%92%E5%BC%95%E7%94%A8%E3%81%97%E3%81%A6%E3%81%84%E3%82%8B%E3%80%82)
^ja-Q0729-answer

**ja-Q0730** — 彼はその文法書から多くの用例を引用している。

He has extracted a great many examples from the grammar book.

Why: Cause. [[Japanese#^ja-Q0730|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%AF%E3%81%9D%E3%81%AE%E6%96%87%E6%B3%95%E6%9B%B8%E3%81%8B%E3%82%89%E5%A4%9A%E3%81%8F%E3%81%AE%E7%94%A8%E4%BE%8B%E3%82%92%E5%BC%95%E7%94%A8%E3%81%97%E3%81%A6%E3%81%84%E3%82%8B%E3%80%82)
^ja-Q0730-answer

**ja-Q0731** — 山は高いからといって価値があるわけではない。

The mountain is not valuable because it is high.

Why: Cause. [[Japanese#^ja-Q0731|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%B1%B1%E3%81%AF%E9%AB%98%E3%81%84%E3%81%8B%E3%82%89%E3%81%A8%E3%81%84%E3%81%A3%E3%81%A6%E4%BE%A1%E5%80%A4%E3%81%8C%E3%81%82%E3%82%8B%E3%82%8F%E3%81%91%E3%81%A7%E3%81%AF%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0731-answer

**ja-Q0732** — 山は高いからといって価値があるわけではない。

The mountain is not valuable because it is high.

から and ので can supply reasons. から also marks a source/start point. Degree of explicitness and discourse tone differ between causal expressions.

Why: Cause. [[Japanese#^ja-Q0732|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%B1%B1%E3%81%AF%E9%AB%98%E3%81%84%E3%81%8B%E3%82%89%E3%81%A8%E3%81%84%E3%81%A3%E3%81%A6%E4%BE%A1%E5%80%A4%E3%81%8C%E3%81%82%E3%82%8B%E3%82%8F%E3%81%91%E3%81%A7%E3%81%AF%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0732-answer

**ja-Q0733** — 内ポケットから財布を盗まれた。

I had my wallet stolen from my inner pocket.

Expected form: **から**

Why: Cause. [[Japanese#^ja-Q0733|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%86%85%E3%83%9D%E3%82%B1%E3%83%83%E3%83%88%E3%81%8B%E3%82%89%E8%B2%A1%E5%B8%83%E3%82%92%E7%9B%97%E3%81%BE%E3%82%8C%E3%81%9F%E3%80%82)
^ja-Q0733-answer

**ja-Q0734** — 内ポケットから財布を盗まれた。

I had my wallet stolen from my inner pocket.

Expected form: **から**

Why: Cause. [[Japanese#^ja-Q0734|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%86%85%E3%83%9D%E3%82%B1%E3%83%83%E3%83%88%E3%81%8B%E3%82%89%E8%B2%A1%E5%B8%83%E3%82%92%E7%9B%97%E3%81%BE%E3%82%8C%E3%81%9F%E3%80%82)
^ja-Q0734-answer

**ja-Q0735** — 心の底から同意します。

I wholeheartedly agree.

Expected form: **から**

Why: Cause. [[Japanese#^ja-Q0735|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BF%83%E3%81%AE%E5%BA%95%E3%81%8B%E3%82%89%E5%90%8C%E6%84%8F%E3%81%97%E3%81%BE%E3%81%99%E3%80%82)
^ja-Q0735-answer

**ja-Q0736** — 心の底から同意します。

I wholeheartedly agree.

Why: Cause. [[Japanese#^ja-Q0736|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BF%83%E3%81%AE%E5%BA%95%E3%81%8B%E3%82%89%E5%90%8C%E6%84%8F%E3%81%97%E3%81%BE%E3%81%99%E3%80%82)
^ja-Q0736-answer

**ja-Q0737** — 暖かくなったので、私はセーターを脱いだ。

As it got warmer, I took off the sweater.

Why: Cause. [[Japanese#^ja-Q0737|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%9A%96%E3%81%8B%E3%81%8F%E3%81%AA%E3%81%A3%E3%81%9F%E3%81%AE%E3%81%A7%E3%80%81%E7%A7%81%E3%81%AF%E3%82%BB%E3%83%BC%E3%82%BF%E3%83%BC%E3%82%92%E8%84%B1%E3%81%84%E3%81%A0%E3%80%82)
^ja-Q0737-answer

**ja-Q0738** — 暖かくなったので、私はセーターを脱いだ。

As it got warmer, I took off the sweater.

から and ので can supply reasons. から also marks a source/start point. Degree of explicitness and discourse tone differ between causal expressions.

Why: Cause. [[Japanese#^ja-Q0738|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%9A%96%E3%81%8B%E3%81%8F%E3%81%AA%E3%81%A3%E3%81%9F%E3%81%AE%E3%81%A7%E3%80%81%E7%A7%81%E3%81%AF%E3%82%BB%E3%83%BC%E3%82%BF%E3%83%BC%E3%82%92%E8%84%B1%E3%81%84%E3%81%A0%E3%80%82)
^ja-Q0738-answer

**ja-Q0739** — 何しろ朝から夕方まで、校舎の中で軟禁状態だからな。釈放されれば元気にもなるってもんだ。

Anyhow, having been held in school from morning to evening ... anybody'd be happy on getting released.

Expected form: **から**

Why: Cause. [[Japanese#^ja-Q0739|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E4%BD%95%E3%81%97%E3%82%8D%E6%9C%9D%E3%81%8B%E3%82%89%E5%A4%95%E6%96%B9%E3%81%BE%E3%81%A7%E3%80%81%E6%A0%A1%E8%88%8E%E3%81%AE%E4%B8%AD%E3%81%A7%E8%BB%9F%E7%A6%81%E7%8A%B6%E6%85%8B%E3%81%A0%E3%81%8B%E3%82%89%E3%81%AA%E3%80%82%E9%87%88%E6%94%BE%E3%81%95%E3%82%8C%E3%82%8C%E3%81%B0%E5%85%83%E6%B0%97%E3%81%AB%E3%82%82%E3%81%AA%E3%82%8B%E3%81%A3%E3%81%A6%E3%82%82%E3%82%93%E3%81%A0%E3%80%82)
^ja-Q0739-answer

**ja-Q0740** — 何しろ朝から夕方まで、校舎の中で軟禁状態だからな。釈放されれば元気にもなるってもんだ。

Anyhow, having been held in school from morning to evening ... anybody'd be happy on getting released.

Expected form: **から**

Why: Cause. [[Japanese#^ja-Q0740|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E4%BD%95%E3%81%97%E3%82%8D%E6%9C%9D%E3%81%8B%E3%82%89%E5%A4%95%E6%96%B9%E3%81%BE%E3%81%A7%E3%80%81%E6%A0%A1%E8%88%8E%E3%81%AE%E4%B8%AD%E3%81%A7%E8%BB%9F%E7%A6%81%E7%8A%B6%E6%85%8B%E3%81%A0%E3%81%8B%E3%82%89%E3%81%AA%E3%80%82%E9%87%88%E6%94%BE%E3%81%95%E3%82%8C%E3%82%8C%E3%81%B0%E5%85%83%E6%B0%97%E3%81%AB%E3%82%82%E3%81%AA%E3%82%8B%E3%81%A3%E3%81%A6%E3%82%82%E3%82%93%E3%81%A0%E3%80%82)
^ja-Q0740-answer

**ja-Q0741** — このｅ—ｍａｉｌアドレスは明日からは使用不可能になります。

From tomorrow this email address will be invalid.

Expected form: **から**

Why: Cause. [[Japanese#^ja-Q0741|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%93%E3%81%AE%EF%BD%85%E2%80%94%EF%BD%8D%EF%BD%81%EF%BD%89%EF%BD%8C%E3%82%A2%E3%83%89%E3%83%AC%E3%82%B9%E3%81%AF%E6%98%8E%E6%97%A5%E3%81%8B%E3%82%89%E3%81%AF%E4%BD%BF%E7%94%A8%E4%B8%8D%E5%8F%AF%E8%83%BD%E3%81%AB%E3%81%AA%E3%82%8A%E3%81%BE%E3%81%99%E3%80%82)
^ja-Q0741-answer

**ja-Q0742** — このｅ—ｍａｉｌアドレスは明日からは使用不可能になります。

From tomorrow this email address will be invalid.

Why: Cause. [[Japanese#^ja-Q0742|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%93%E3%81%AE%EF%BD%85%E2%80%94%EF%BD%8D%EF%BD%81%EF%BD%89%EF%BD%8C%E3%82%A2%E3%83%89%E3%83%AC%E3%82%B9%E3%81%AF%E6%98%8E%E6%97%A5%E3%81%8B%E3%82%89%E3%81%AF%E4%BD%BF%E7%94%A8%E4%B8%8D%E5%8F%AF%E8%83%BD%E3%81%AB%E3%81%AA%E3%82%8A%E3%81%BE%E3%81%99%E3%80%82)
^ja-Q0742-answer

**ja-Q0743** — トムはみんなから好かれている。

Tom is liked by everyone.

Why: Cause. [[Japanese#^ja-Q0743|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%83%88%E3%83%A0%E3%81%AF%E3%81%BF%E3%82%93%E3%81%AA%E3%81%8B%E3%82%89%E5%A5%BD%E3%81%8B%E3%82%8C%E3%81%A6%E3%81%84%E3%82%8B%E3%80%82)
^ja-Q0743-answer

**ja-Q0744** — トムはみんなから好かれている。

Tom is liked by everyone.

から and ので can supply reasons. から also marks a source/start point. Degree of explicitness and discourse tone differ between causal expressions.

Why: Cause. [[Japanese#^ja-Q0744|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%83%88%E3%83%A0%E3%81%AF%E3%81%BF%E3%82%93%E3%81%AA%E3%81%8B%E3%82%89%E5%A5%BD%E3%81%8B%E3%82%8C%E3%81%A6%E3%81%84%E3%82%8B%E3%80%82)
^ja-Q0744-answer

**ja-Q0745** — 税は直接税と間接税からなっている。

Taxes consist of direct taxes and indirect ones.

Expected form: **から**

Why: Cause. [[Japanese#^ja-Q0745|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A8%8E%E3%81%AF%E7%9B%B4%E6%8E%A5%E7%A8%8E%E3%81%A8%E9%96%93%E6%8E%A5%E7%A8%8E%E3%81%8B%E3%82%89%E3%81%AA%E3%81%A3%E3%81%A6%E3%81%84%E3%82%8B%E3%80%82)
^ja-Q0745-answer

**ja-Q0746** — 税は直接税と間接税からなっている。

Taxes consist of direct taxes and indirect ones.

Expected form: **から**

Why: Cause. [[Japanese#^ja-Q0746|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A8%8E%E3%81%AF%E7%9B%B4%E6%8E%A5%E7%A8%8E%E3%81%A8%E9%96%93%E6%8E%A5%E7%A8%8E%E3%81%8B%E3%82%89%E3%81%AA%E3%81%A3%E3%81%A6%E3%81%84%E3%82%8B%E3%80%82)
^ja-Q0746-answer

**ja-Q0747** — 風邪をひいていたので、学校を休んだ。

I was absent from school because I had a cold.

Expected form: **ので**

Why: Cause. [[Japanese#^ja-Q0747|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E9%A2%A8%E9%82%AA%E3%82%92%E3%81%B2%E3%81%84%E3%81%A6%E3%81%84%E3%81%9F%E3%81%AE%E3%81%A7%E3%80%81%E5%AD%A6%E6%A0%A1%E3%82%92%E4%BC%91%E3%82%93%E3%81%A0%E3%80%82)
^ja-Q0747-answer

**ja-Q0748** — 風邪をひいていたので、学校を休んだ。

I was absent from school because I had a cold.

Why: Cause. [[Japanese#^ja-Q0748|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E9%A2%A8%E9%82%AA%E3%82%92%E3%81%B2%E3%81%84%E3%81%A6%E3%81%84%E3%81%9F%E3%81%AE%E3%81%A7%E3%80%81%E5%AD%A6%E6%A0%A1%E3%82%92%E4%BC%91%E3%82%93%E3%81%A0%E3%80%82)
^ja-Q0748-answer

**ja-Q0749** — どのゲートから乗ればよいのでしょうか。

What gate do I board at?

Why: Cause. [[Japanese#^ja-Q0749|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%A9%E3%81%AE%E3%82%B2%E3%83%BC%E3%83%88%E3%81%8B%E3%82%89%E4%B9%97%E3%82%8C%E3%81%B0%E3%82%88%E3%81%84%E3%81%AE%E3%81%A7%E3%81%97%E3%82%87%E3%81%86%E3%81%8B%E3%80%82)
^ja-Q0749-answer

**ja-Q0750** — どのゲートから乗ればよいのでしょうか。

What gate do I board at?

から and ので can supply reasons. から also marks a source/start point. Degree of explicitness and discourse tone differ between causal expressions.

Why: Cause. [[Japanese#^ja-Q0750|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%A9%E3%81%AE%E3%82%B2%E3%83%BC%E3%83%88%E3%81%8B%E3%82%89%E4%B9%97%E3%82%8C%E3%81%B0%E3%82%88%E3%81%84%E3%81%AE%E3%81%A7%E3%81%97%E3%82%87%E3%81%86%E3%81%8B%E3%80%82)
^ja-Q0750-answer


### Answers 751–800

**ja-Q0751** — 少女は友達にお茶をいれるのに忙しかった。

The girl was busy making tea for her friend.

Expected form: **のに**

Why: Contrast and concession. [[Japanese#^ja-Q0751|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%B0%91%E5%A5%B3%E3%81%AF%E5%8F%8B%E9%81%94%E3%81%AB%E3%81%8A%E8%8C%B6%E3%82%92%E3%81%84%E3%82%8C%E3%82%8B%E3%81%AE%E3%81%AB%E5%BF%99%E3%81%97%E3%81%8B%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0751-answer

**ja-Q0752** — 少女は友達にお茶をいれるのに忙しかった。

The girl was busy making tea for her friend.

Expected form: **のに**

Why: Contrast and concession. [[Japanese#^ja-Q0752|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%B0%91%E5%A5%B3%E3%81%AF%E5%8F%8B%E9%81%94%E3%81%AB%E3%81%8A%E8%8C%B6%E3%82%92%E3%81%84%E3%82%8C%E3%82%8B%E3%81%AE%E3%81%AB%E5%BF%99%E3%81%97%E3%81%8B%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0752-answer

**ja-Q0753** — 彼が話をやめるように頼んだが、彼はそれでもはなしつづけた。

I asked him to stop talking, but he still went on.

Expected form: **でも**

Why: Contrast and concession. [[Japanese#^ja-Q0753|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%8C%E8%A9%B1%E3%82%92%E3%82%84%E3%82%81%E3%82%8B%E3%82%88%E3%81%86%E3%81%AB%E9%A0%BC%E3%82%93%E3%81%A0%E3%81%8C%E3%80%81%E5%BD%BC%E3%81%AF%E3%81%9D%E3%82%8C%E3%81%A7%E3%82%82%E3%81%AF%E3%81%AA%E3%81%97%E3%81%A4%E3%81%A5%E3%81%91%E3%81%9F%E3%80%82)
^ja-Q0753-answer

**ja-Q0754** — 彼が話をやめるように頼んだが、彼はそれでもはなしつづけた。

I asked him to stop talking, but he still went on.

Why: Contrast and concession. [[Japanese#^ja-Q0754|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%8C%E8%A9%B1%E3%82%92%E3%82%84%E3%82%81%E3%82%8B%E3%82%88%E3%81%86%E3%81%AB%E9%A0%BC%E3%82%93%E3%81%A0%E3%81%8C%E3%80%81%E5%BD%BC%E3%81%AF%E3%81%9D%E3%82%8C%E3%81%A7%E3%82%82%E3%81%AF%E3%81%AA%E3%81%97%E3%81%A4%E3%81%A5%E3%81%91%E3%81%9F%E3%80%82)
^ja-Q0754-answer

**ja-Q0755** — 博物館は月曜日が休館だって言われたけどな。

I've been told that the museum is closed on Mondays.

Why: Contrast and concession. [[Japanese#^ja-Q0755|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%8D%9A%E7%89%A9%E9%A4%A8%E3%81%AF%E6%9C%88%E6%9B%9C%E6%97%A5%E3%81%8C%E4%BC%91%E9%A4%A8%E3%81%A0%E3%81%A3%E3%81%A6%E8%A8%80%E3%82%8F%E3%82%8C%E3%81%9F%E3%81%91%E3%81%A9%E3%81%AA%E3%80%82)
^ja-Q0755-answer

**ja-Q0756** — 博物館は月曜日が休館だって言われたけどな。

I've been told that the museum is closed on Mondays.

These forms connect contrast or concession but differ in grammar and register. のに presents a contrary-to-expectation relation. でも has additional functions, including examples and alternatives.

Why: Contrast and concession. [[Japanese#^ja-Q0756|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%8D%9A%E7%89%A9%E9%A4%A8%E3%81%AF%E6%9C%88%E6%9B%9C%E6%97%A5%E3%81%8C%E4%BC%91%E9%A4%A8%E3%81%A0%E3%81%A3%E3%81%A6%E8%A8%80%E3%82%8F%E3%82%8C%E3%81%9F%E3%81%91%E3%81%A9%E3%81%AA%E3%80%82)
^ja-Q0756-answer

**ja-Q0757** — 彼がその仕事を終えるのに２時間かかるだろう。

It will take him two hours to finish the work.

Expected form: **のに**

Why: Contrast and concession. [[Japanese#^ja-Q0757|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%8C%E3%81%9D%E3%81%AE%E4%BB%95%E4%BA%8B%E3%82%92%E7%B5%82%E3%81%88%E3%82%8B%E3%81%AE%E3%81%AB%EF%BC%92%E6%99%82%E9%96%93%E3%81%8B%E3%81%8B%E3%82%8B%E3%81%A0%E3%82%8D%E3%81%86%E3%80%82)
^ja-Q0757-answer

**ja-Q0758** — 彼がその仕事を終えるのに２時間かかるだろう。

It will take him two hours to finish the work.

Expected form: **のに**

Why: Contrast and concession. [[Japanese#^ja-Q0758|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%8C%E3%81%9D%E3%81%AE%E4%BB%95%E4%BA%8B%E3%82%92%E7%B5%82%E3%81%88%E3%82%8B%E3%81%AE%E3%81%AB%EF%BC%92%E6%99%82%E9%96%93%E3%81%8B%E3%81%8B%E3%82%8B%E3%81%A0%E3%82%8D%E3%81%86%E3%80%82)
^ja-Q0758-answer

**ja-Q0759** — 君が来るかどうかは私にとってはどうでもよいことだ。

It does not matter to me whether you come or not.

Expected form: **でも**

Why: Contrast and concession. [[Japanese#^ja-Q0759|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%90%9B%E3%81%8C%E6%9D%A5%E3%82%8B%E3%81%8B%E3%81%A9%E3%81%86%E3%81%8B%E3%81%AF%E7%A7%81%E3%81%AB%E3%81%A8%E3%81%A3%E3%81%A6%E3%81%AF%E3%81%A9%E3%81%86%E3%81%A7%E3%82%82%E3%82%88%E3%81%84%E3%81%93%E3%81%A8%E3%81%A0%E3%80%82)
^ja-Q0759-answer

**ja-Q0760** — 君が来るかどうかは私にとってはどうでもよいことだ。

It does not matter to me whether you come or not.

Why: Contrast and concession. [[Japanese#^ja-Q0760|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%90%9B%E3%81%8C%E6%9D%A5%E3%82%8B%E3%81%8B%E3%81%A9%E3%81%86%E3%81%8B%E3%81%AF%E7%A7%81%E3%81%AB%E3%81%A8%E3%81%A3%E3%81%A6%E3%81%AF%E3%81%A9%E3%81%86%E3%81%A7%E3%82%82%E3%82%88%E3%81%84%E3%81%93%E3%81%A8%E3%81%A0%E3%80%82)
^ja-Q0760-answer

**ja-Q0761** — 私はそれをただでもらった。

I got it for nothing.

Why: Contrast and concession. [[Japanese#^ja-Q0761|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AF%E3%81%9D%E3%82%8C%E3%82%92%E3%81%9F%E3%81%A0%E3%81%A7%E3%82%82%E3%82%89%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0761-answer

**ja-Q0762** — 私はそれをただでもらった。

I got it for nothing.

These forms connect contrast or concession but differ in grammar and register. のに presents a contrary-to-expectation relation. でも has additional functions, including examples and alternatives.

Why: Contrast and concession. [[Japanese#^ja-Q0762|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AF%E3%81%9D%E3%82%8C%E3%82%92%E3%81%9F%E3%81%A0%E3%81%A7%E3%82%82%E3%82%89%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0762-answer

**ja-Q0763** — 二度と私のものに触らないで。

Don't ever touch my things again.

Expected form: **のに**

Why: Contrast and concession. [[Japanese#^ja-Q0763|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E4%BA%8C%E5%BA%A6%E3%81%A8%E7%A7%81%E3%81%AE%E3%82%82%E3%81%AE%E3%81%AB%E8%A7%A6%E3%82%89%E3%81%AA%E3%81%84%E3%81%A7%E3%80%82)
^ja-Q0763-answer

**ja-Q0764** — 二度と私のものに触らないで。

Don't ever touch my things again.

Expected form: **のに**

Why: Contrast and concession. [[Japanese#^ja-Q0764|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E4%BA%8C%E5%BA%A6%E3%81%A8%E7%A7%81%E3%81%AE%E3%82%82%E3%81%AE%E3%81%AB%E8%A7%A6%E3%82%89%E3%81%AA%E3%81%84%E3%81%A7%E3%80%82)
^ja-Q0764-answer

**ja-Q0765** — もうすこし注意すべきだったのに。

You should have been more careful.

Expected form: **のに**

Why: Contrast and concession. [[Japanese#^ja-Q0765|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%82%82%E3%81%86%E3%81%99%E3%81%93%E3%81%97%E6%B3%A8%E6%84%8F%E3%81%99%E3%81%B9%E3%81%8D%E3%81%A0%E3%81%A3%E3%81%9F%E3%81%AE%E3%81%AB%E3%80%82)
^ja-Q0765-answer

**ja-Q0766** — もうすこし注意すべきだったのに。

You should have been more careful.

Why: Contrast and concession. [[Japanese#^ja-Q0766|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%82%82%E3%81%86%E3%81%99%E3%81%93%E3%81%97%E6%B3%A8%E6%84%8F%E3%81%99%E3%81%B9%E3%81%8D%E3%81%A0%E3%81%A3%E3%81%9F%E3%81%AE%E3%81%AB%E3%80%82)
^ja-Q0766-answer

**ja-Q0767** — 「順路→」といったかんじの看板を設置したいと思うんですけど、これを英語で作るとどうなるでしょうか？

I'd like to set up a sign like, "This Way ->," but what would it be if I made it in English?

Why: Contrast and concession. [[Japanese#^ja-Q0767|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%80%8C%E9%A0%86%E8%B7%AF%E2%86%92%E3%80%8D%E3%81%A8%E3%81%84%E3%81%A3%E3%81%9F%E3%81%8B%E3%82%93%E3%81%98%E3%81%AE%E7%9C%8B%E6%9D%BF%E3%82%92%E8%A8%AD%E7%BD%AE%E3%81%97%E3%81%9F%E3%81%84%E3%81%A8%E6%80%9D%E3%81%86%E3%82%93%E3%81%A7%E3%81%99%E3%81%91%E3%81%A9%E3%80%81%E3%81%93%E3%82%8C%E3%82%92%E8%8B%B1%E8%AA%9E%E3%81%A7%E4%BD%9C%E3%82%8B%E3%81%A8%E3%81%A9%E3%81%86%E3%81%AA%E3%82%8B%E3%81%A7%E3%81%97%E3%82%87%E3%81%86%E3%81%8B%EF%BC%9F)
^ja-Q0767-answer

**ja-Q0768** — 「順路→」といったかんじの看板を設置したいと思うんですけど、これを英語で作るとどうなるでしょうか？

I'd like to set up a sign like, "This Way ->," but what would it be if I made it in English?

These forms connect contrast or concession but differ in grammar and register. のに presents a contrary-to-expectation relation. でも has additional functions, including examples and alternatives.

Why: Contrast and concession. [[Japanese#^ja-Q0768|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%80%8C%E9%A0%86%E8%B7%AF%E2%86%92%E3%80%8D%E3%81%A8%E3%81%84%E3%81%A3%E3%81%9F%E3%81%8B%E3%82%93%E3%81%98%E3%81%AE%E7%9C%8B%E6%9D%BF%E3%82%92%E8%A8%AD%E7%BD%AE%E3%81%97%E3%81%9F%E3%81%84%E3%81%A8%E6%80%9D%E3%81%86%E3%82%93%E3%81%A7%E3%81%99%E3%81%91%E3%81%A9%E3%80%81%E3%81%93%E3%82%8C%E3%82%92%E8%8B%B1%E8%AA%9E%E3%81%A7%E4%BD%9C%E3%82%8B%E3%81%A8%E3%81%A9%E3%81%86%E3%81%AA%E3%82%8B%E3%81%A7%E3%81%97%E3%82%87%E3%81%86%E3%81%8B%EF%BC%9F)
^ja-Q0768-answer

**ja-Q0769** — トムね、怪我したんだけどそれほどひどくなかったよ。

Tom was injured, but not too badly.

Expected form: **けど**

Why: Contrast and concession. [[Japanese#^ja-Q0769|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%83%88%E3%83%A0%E3%81%AD%E3%80%81%E6%80%AA%E6%88%91%E3%81%97%E3%81%9F%E3%82%93%E3%81%A0%E3%81%91%E3%81%A9%E3%81%9D%E3%82%8C%E3%81%BB%E3%81%A9%E3%81%B2%E3%81%A9%E3%81%8F%E3%81%AA%E3%81%8B%E3%81%A3%E3%81%9F%E3%82%88%E3%80%82)
^ja-Q0769-answer

**ja-Q0770** — トムね、怪我したんだけどそれほどひどくなかったよ。

Tom was injured, but not too badly.

Expected form: **けど**

Why: Contrast and concession. [[Japanese#^ja-Q0770|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%83%88%E3%83%A0%E3%81%AD%E3%80%81%E6%80%AA%E6%88%91%E3%81%97%E3%81%9F%E3%82%93%E3%81%A0%E3%81%91%E3%81%A9%E3%81%9D%E3%82%8C%E3%81%BB%E3%81%A9%E3%81%B2%E3%81%A9%E3%81%8F%E3%81%AA%E3%81%8B%E3%81%A3%E3%81%9F%E3%82%88%E3%80%82)
^ja-Q0770-answer

**ja-Q0771** — 君は仕事を得るのに成功した。

You finally succeeded in getting a job.

Expected form: **のに**

Why: Contrast and concession. [[Japanese#^ja-Q0771|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%90%9B%E3%81%AF%E4%BB%95%E4%BA%8B%E3%82%92%E5%BE%97%E3%82%8B%E3%81%AE%E3%81%AB%E6%88%90%E5%8A%9F%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0771-answer

**ja-Q0772** — 君は仕事を得るのに成功した。

You finally succeeded in getting a job.

Why: Contrast and concession. [[Japanese#^ja-Q0772|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%90%9B%E3%81%AF%E4%BB%95%E4%BA%8B%E3%82%92%E5%BE%97%E3%82%8B%E3%81%AE%E3%81%AB%E6%88%90%E5%8A%9F%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0772-answer

**ja-Q0773** — もうこれ以上、あなたに隠し事はしたくないんだけど。

I don't want to hide anything from you anymore.

Why: Contrast and concession. [[Japanese#^ja-Q0773|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%82%82%E3%81%86%E3%81%93%E3%82%8C%E4%BB%A5%E4%B8%8A%E3%80%81%E3%81%82%E3%81%AA%E3%81%9F%E3%81%AB%E9%9A%A0%E3%81%97%E4%BA%8B%E3%81%AF%E3%81%97%E3%81%9F%E3%81%8F%E3%81%AA%E3%81%84%E3%82%93%E3%81%A0%E3%81%91%E3%81%A9%E3%80%82)
^ja-Q0773-answer

**ja-Q0774** — もうこれ以上、あなたに隠し事はしたくないんだけど。

I don't want to hide anything from you anymore.

These forms connect contrast or concession but differ in grammar and register. のに presents a contrary-to-expectation relation. でも has additional functions, including examples and alternatives.

Why: Contrast and concession. [[Japanese#^ja-Q0774|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%82%82%E3%81%86%E3%81%93%E3%82%8C%E4%BB%A5%E4%B8%8A%E3%80%81%E3%81%82%E3%81%AA%E3%81%9F%E3%81%AB%E9%9A%A0%E3%81%97%E4%BA%8B%E3%81%AF%E3%81%97%E3%81%9F%E3%81%8F%E3%81%AA%E3%81%84%E3%82%93%E3%81%A0%E3%81%91%E3%81%A9%E3%80%82)
^ja-Q0774-answer

**ja-Q0775** — 今回の金融危機から得たほかでもない教訓というのは、メーン・ストリート（普通の町の中央通り）が苦しんでいるのにウォール・ストリートだけ栄えるなど、そんなことがあってはならないということ。それを忘れずにいましょう。

Let us remember that if this financial crisis taught us anything, it's that we cannot have a thriving Wall Street while Main Street suffers.

Expected form: **でも**

Why: Contrast and concession. [[Japanese#^ja-Q0775|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E4%BB%8A%E5%9B%9E%E3%81%AE%E9%87%91%E8%9E%8D%E5%8D%B1%E6%A9%9F%E3%81%8B%E3%82%89%E5%BE%97%E3%81%9F%E3%81%BB%E3%81%8B%E3%81%A7%E3%82%82%E3%81%AA%E3%81%84%E6%95%99%E8%A8%93%E3%81%A8%E3%81%84%E3%81%86%E3%81%AE%E3%81%AF%E3%80%81%E3%83%A1%E3%83%BC%E3%83%B3%E3%83%BB%E3%82%B9%E3%83%88%E3%83%AA%E3%83%BC%E3%83%88%EF%BC%88%E6%99%AE%E9%80%9A%E3%81%AE%E7%94%BA%E3%81%AE%E4%B8%AD%E5%A4%AE%E9%80%9A%E3%82%8A%EF%BC%89%E3%81%8C%E8%8B%A6%E3%81%97%E3%82%93%E3%81%A7%E3%81%84%E3%82%8B%E3%81%AE%E3%81%AB%E3%82%A6%E3%82%A9%E3%83%BC%E3%83%AB%E3%83%BB%E3%82%B9%E3%83%88%E3%83%AA%E3%83%BC%E3%83%88%E3%81%A0%E3%81%91%E6%A0%84%E3%81%88%E3%82%8B%E3%81%AA%E3%81%A9%E3%80%81%E3%81%9D%E3%82%93%E3%81%AA%E3%81%93%E3%81%A8%E3%81%8C%E3%81%82%E3%81%A3%E3%81%A6%E3%81%AF%E3%81%AA%E3%82%89%E3%81%AA%E3%81%84%E3%81%A8%E3%81%84%E3%81%86%E3%81%93%E3%81%A8%E3%80%82%E3%81%9D%E3%82%8C%E3%82%92%E5%BF%98%E3%82%8C%E3%81%9A%E3%81%AB%E3%81%84%E3%81%BE%E3%81%97%E3%82%87%E3%81%86%E3%80%82)
^ja-Q0775-answer

**ja-Q0776** — 今回の金融危機から得たほかでもない教訓というのは、メーン・ストリート（普通の町の中央通り）が苦しんでいるのにウォール・ストリートだけ栄えるなど、そんなことがあってはならないということ。それを忘れずにいましょう。

Let us remember that if this financial crisis taught us anything, it's that we cannot have a thriving Wall Street while Main Street suffers.

Expected form: **でも**

Why: Contrast and concession. [[Japanese#^ja-Q0776|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E4%BB%8A%E5%9B%9E%E3%81%AE%E9%87%91%E8%9E%8D%E5%8D%B1%E6%A9%9F%E3%81%8B%E3%82%89%E5%BE%97%E3%81%9F%E3%81%BB%E3%81%8B%E3%81%A7%E3%82%82%E3%81%AA%E3%81%84%E6%95%99%E8%A8%93%E3%81%A8%E3%81%84%E3%81%86%E3%81%AE%E3%81%AF%E3%80%81%E3%83%A1%E3%83%BC%E3%83%B3%E3%83%BB%E3%82%B9%E3%83%88%E3%83%AA%E3%83%BC%E3%83%88%EF%BC%88%E6%99%AE%E9%80%9A%E3%81%AE%E7%94%BA%E3%81%AE%E4%B8%AD%E5%A4%AE%E9%80%9A%E3%82%8A%EF%BC%89%E3%81%8C%E8%8B%A6%E3%81%97%E3%82%93%E3%81%A7%E3%81%84%E3%82%8B%E3%81%AE%E3%81%AB%E3%82%A6%E3%82%A9%E3%83%BC%E3%83%AB%E3%83%BB%E3%82%B9%E3%83%88%E3%83%AA%E3%83%BC%E3%83%88%E3%81%A0%E3%81%91%E6%A0%84%E3%81%88%E3%82%8B%E3%81%AA%E3%81%A9%E3%80%81%E3%81%9D%E3%82%93%E3%81%AA%E3%81%93%E3%81%A8%E3%81%8C%E3%81%82%E3%81%A3%E3%81%A6%E3%81%AF%E3%81%AA%E3%82%89%E3%81%AA%E3%81%84%E3%81%A8%E3%81%84%E3%81%86%E3%81%93%E3%81%A8%E3%80%82%E3%81%9D%E3%82%8C%E3%82%92%E5%BF%98%E3%82%8C%E3%81%9A%E3%81%AB%E3%81%84%E3%81%BE%E3%81%97%E3%82%87%E3%81%86%E3%80%82)
^ja-Q0776-answer

**ja-Q0777** — トムは自分の身長についてからかわれることを知ってたけど、バスケットチームにトライアウトすることに決めた。

Even though Tom knew he'd be teased about his height, he decided to try out for the basketball team.

Expected form: **けど**

Why: Contrast and concession. [[Japanese#^ja-Q0777|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%83%88%E3%83%A0%E3%81%AF%E8%87%AA%E5%88%86%E3%81%AE%E8%BA%AB%E9%95%B7%E3%81%AB%E3%81%A4%E3%81%84%E3%81%A6%E3%81%8B%E3%82%89%E3%81%8B%E3%82%8F%E3%82%8C%E3%82%8B%E3%81%93%E3%81%A8%E3%82%92%E7%9F%A5%E3%81%A3%E3%81%A6%E3%81%9F%E3%81%91%E3%81%A9%E3%80%81%E3%83%90%E3%82%B9%E3%82%B1%E3%83%83%E3%83%88%E3%83%81%E3%83%BC%E3%83%A0%E3%81%AB%E3%83%88%E3%83%A9%E3%82%A4%E3%82%A2%E3%82%A6%E3%83%88%E3%81%99%E3%82%8B%E3%81%93%E3%81%A8%E3%81%AB%E6%B1%BA%E3%82%81%E3%81%9F%E3%80%82)
^ja-Q0777-answer

**ja-Q0778** — トムは自分の身長についてからかわれることを知ってたけど、バスケットチームにトライアウトすることに決めた。

Even though Tom knew he'd be teased about his height, he decided to try out for the basketball team.

Why: Contrast and concession. [[Japanese#^ja-Q0778|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%83%88%E3%83%A0%E3%81%AF%E8%87%AA%E5%88%86%E3%81%AE%E8%BA%AB%E9%95%B7%E3%81%AB%E3%81%A4%E3%81%84%E3%81%A6%E3%81%8B%E3%82%89%E3%81%8B%E3%82%8F%E3%82%8C%E3%82%8B%E3%81%93%E3%81%A8%E3%82%92%E7%9F%A5%E3%81%A3%E3%81%A6%E3%81%9F%E3%81%91%E3%81%A9%E3%80%81%E3%83%90%E3%82%B9%E3%82%B1%E3%83%83%E3%83%88%E3%83%81%E3%83%BC%E3%83%A0%E3%81%AB%E3%83%88%E3%83%A9%E3%82%A4%E3%82%A2%E3%82%A6%E3%83%88%E3%81%99%E3%82%8B%E3%81%93%E3%81%A8%E3%81%AB%E6%B1%BA%E3%82%81%E3%81%9F%E3%80%82)
^ja-Q0778-answer

**ja-Q0779** — その部屋を掃除するのに三日かかった。

It took me three days to clean the room.

Why: Contrast and concession. [[Japanese#^ja-Q0779|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%9D%E3%81%AE%E9%83%A8%E5%B1%8B%E3%82%92%E6%8E%83%E9%99%A4%E3%81%99%E3%82%8B%E3%81%AE%E3%81%AB%E4%B8%89%E6%97%A5%E3%81%8B%E3%81%8B%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0779-answer

**ja-Q0780** — その部屋を掃除するのに三日かかった。

It took me three days to clean the room.

These forms connect contrast or concession but differ in grammar and register. のに presents a contrary-to-expectation relation. でも has additional functions, including examples and alternatives.

Why: Contrast and concession. [[Japanese#^ja-Q0780|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%9D%E3%81%AE%E9%83%A8%E5%B1%8B%E3%82%92%E6%8E%83%E9%99%A4%E3%81%99%E3%82%8B%E3%81%AE%E3%81%AB%E4%B8%89%E6%97%A5%E3%81%8B%E3%81%8B%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0780-answer

**ja-Q0781** — もっと時間があればいいのに。

I wish we had more time.

Expected form: **のに**

Why: Contrast and concession. [[Japanese#^ja-Q0781|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%82%82%E3%81%A3%E3%81%A8%E6%99%82%E9%96%93%E3%81%8C%E3%81%82%E3%82%8C%E3%81%B0%E3%81%84%E3%81%84%E3%81%AE%E3%81%AB%E3%80%82)
^ja-Q0781-answer

**ja-Q0782** — もっと時間があればいいのに。

I wish we had more time.

Expected form: **のに**

Why: Contrast and concession. [[Japanese#^ja-Q0782|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%82%82%E3%81%A3%E3%81%A8%E6%99%82%E9%96%93%E3%81%8C%E3%81%82%E3%82%8C%E3%81%B0%E3%81%84%E3%81%84%E3%81%AE%E3%81%AB%E3%80%82)
^ja-Q0782-answer

**ja-Q0783** — どれでも好きなドレスを選んでください。

Choose any dress you like.

Expected form: **でも**

Why: Contrast and concession. [[Japanese#^ja-Q0783|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%A9%E3%82%8C%E3%81%A7%E3%82%82%E5%A5%BD%E3%81%8D%E3%81%AA%E3%83%89%E3%83%AC%E3%82%B9%E3%82%92%E9%81%B8%E3%82%93%E3%81%A7%E3%81%8F%E3%81%A0%E3%81%95%E3%81%84%E3%80%82)
^ja-Q0783-answer

**ja-Q0784** — どれでも好きなドレスを選んでください。

Choose any dress you like.

Why: Contrast and concession. [[Japanese#^ja-Q0784|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%A9%E3%82%8C%E3%81%A7%E3%82%82%E5%A5%BD%E3%81%8D%E3%81%AA%E3%83%89%E3%83%AC%E3%82%B9%E3%82%92%E9%81%B8%E3%82%93%E3%81%A7%E3%81%8F%E3%81%A0%E3%81%95%E3%81%84%E3%80%82)
^ja-Q0784-answer

**ja-Q0785** — ジョンが戻ってきたとき、彼はまるで幽霊でもみたように青白い顔つきだった。

When John came back, he looked pale as if he had seen a ghost.

Why: Contrast and concession. [[Japanese#^ja-Q0785|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%82%B8%E3%83%A7%E3%83%B3%E3%81%8C%E6%88%BB%E3%81%A3%E3%81%A6%E3%81%8D%E3%81%9F%E3%81%A8%E3%81%8D%E3%80%81%E5%BD%BC%E3%81%AF%E3%81%BE%E3%82%8B%E3%81%A7%E5%B9%BD%E9%9C%8A%E3%81%A7%E3%82%82%E3%81%BF%E3%81%9F%E3%82%88%E3%81%86%E3%81%AB%E9%9D%92%E7%99%BD%E3%81%84%E9%A1%94%E3%81%A4%E3%81%8D%E3%81%A0%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0785-answer

**ja-Q0786** — ジョンが戻ってきたとき、彼はまるで幽霊でもみたように青白い顔つきだった。

When John came back, he looked pale as if he had seen a ghost.

These forms connect contrast or concession but differ in grammar and register. のに presents a contrary-to-expectation relation. でも has additional functions, including examples and alternatives.

Why: Contrast and concession. [[Japanese#^ja-Q0786|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%82%B8%E3%83%A7%E3%83%B3%E3%81%8C%E6%88%BB%E3%81%A3%E3%81%A6%E3%81%8D%E3%81%9F%E3%81%A8%E3%81%8D%E3%80%81%E5%BD%BC%E3%81%AF%E3%81%BE%E3%82%8B%E3%81%A7%E5%B9%BD%E9%9C%8A%E3%81%A7%E3%82%82%E3%81%BF%E3%81%9F%E3%82%88%E3%81%86%E3%81%AB%E9%9D%92%E7%99%BD%E3%81%84%E9%A1%94%E3%81%A4%E3%81%8D%E3%81%A0%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0786-answer

**ja-Q0787** — タケオはその数学の問題を解くのに熱中している。

Takeo is engrossed in solving mathematical problems.

Expected form: **のに**

Why: Contrast and concession. [[Japanese#^ja-Q0787|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%82%BF%E3%82%B1%E3%82%AA%E3%81%AF%E3%81%9D%E3%81%AE%E6%95%B0%E5%AD%A6%E3%81%AE%E5%95%8F%E9%A1%8C%E3%82%92%E8%A7%A3%E3%81%8F%E3%81%AE%E3%81%AB%E7%86%B1%E4%B8%AD%E3%81%97%E3%81%A6%E3%81%84%E3%82%8B%E3%80%82)
^ja-Q0787-answer

**ja-Q0788** — タケオはその数学の問題を解くのに熱中している。

Takeo is engrossed in solving mathematical problems.

Expected form: **のに**

Why: Contrast and concession. [[Japanese#^ja-Q0788|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%82%BF%E3%82%B1%E3%82%AA%E3%81%AF%E3%81%9D%E3%81%AE%E6%95%B0%E5%AD%A6%E3%81%AE%E5%95%8F%E9%A1%8C%E3%82%92%E8%A7%A3%E3%81%8F%E3%81%AE%E3%81%AB%E7%86%B1%E4%B8%AD%E3%81%97%E3%81%A6%E3%81%84%E3%82%8B%E3%80%82)
^ja-Q0788-answer

**ja-Q0789** — ボブは事故にあったのに違いない。

Bob must have had an accident.

Expected form: **のに**

Why: Contrast and concession. [[Japanese#^ja-Q0789|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%83%9C%E3%83%96%E3%81%AF%E4%BA%8B%E6%95%85%E3%81%AB%E3%81%82%E3%81%A3%E3%81%9F%E3%81%AE%E3%81%AB%E9%81%95%E3%81%84%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0789-answer

**ja-Q0790** — ボブは事故にあったのに違いない。

Bob must have had an accident.

Why: Contrast and concession. [[Japanese#^ja-Q0790|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%83%9C%E3%83%96%E3%81%AF%E4%BA%8B%E6%95%85%E3%81%AB%E3%81%82%E3%81%A3%E3%81%9F%E3%81%AE%E3%81%AB%E9%81%95%E3%81%84%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0790-answer

**ja-Q0791** — 私は走る前に、体をほぐすのにちょっと体操をする。

I like to do a few exercises to loosen up before I run.

Why: Contrast and concession. [[Japanese#^ja-Q0791|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AF%E8%B5%B0%E3%82%8B%E5%89%8D%E3%81%AB%E3%80%81%E4%BD%93%E3%82%92%E3%81%BB%E3%81%90%E3%81%99%E3%81%AE%E3%81%AB%E3%81%A1%E3%82%87%E3%81%A3%E3%81%A8%E4%BD%93%E6%93%8D%E3%82%92%E3%81%99%E3%82%8B%E3%80%82)
^ja-Q0791-answer

**ja-Q0792** — 私は走る前に、体をほぐすのにちょっと体操をする。

I like to do a few exercises to loosen up before I run.

These forms connect contrast or concession but differ in grammar and register. のに presents a contrary-to-expectation relation. でも has additional functions, including examples and alternatives.

Why: Contrast and concession. [[Japanese#^ja-Q0792|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AF%E8%B5%B0%E3%82%8B%E5%89%8D%E3%81%AB%E3%80%81%E4%BD%93%E3%82%92%E3%81%BB%E3%81%90%E3%81%99%E3%81%AE%E3%81%AB%E3%81%A1%E3%82%87%E3%81%A3%E3%81%A8%E4%BD%93%E6%93%8D%E3%82%92%E3%81%99%E3%82%8B%E3%80%82)
^ja-Q0792-answer

**ja-Q0793** — もしかして直せるかも。

Maybe I can fix it.

Expected form: **しかし**

Why: Contrast and concession. [[Japanese#^ja-Q0793|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%82%82%E3%81%97%E3%81%8B%E3%81%97%E3%81%A6%E7%9B%B4%E3%81%9B%E3%82%8B%E3%81%8B%E3%82%82%E3%80%82)
^ja-Q0793-answer

**ja-Q0794** — もしかして直せるかも。

Maybe I can fix it.

Expected form: **しかし**

Why: Contrast and concession. [[Japanese#^ja-Q0794|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%82%82%E3%81%97%E3%81%8B%E3%81%97%E3%81%A6%E7%9B%B4%E3%81%9B%E3%82%8B%E3%81%8B%E3%82%82%E3%80%82)
^ja-Q0794-answer

**ja-Q0795** — そんなものに飛びつくのはばかだ。

If you bite at it, you're a fool.

Expected form: **のに**

Why: Contrast and concession. [[Japanese#^ja-Q0795|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%9D%E3%82%93%E3%81%AA%E3%82%82%E3%81%AE%E3%81%AB%E9%A3%9B%E3%81%B3%E3%81%A4%E3%81%8F%E3%81%AE%E3%81%AF%E3%81%B0%E3%81%8B%E3%81%A0%E3%80%82)
^ja-Q0795-answer

**ja-Q0796** — そんなものに飛びつくのはばかだ。

If you bite at it, you're a fool.

Why: Contrast and concession. [[Japanese#^ja-Q0796|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%9D%E3%82%93%E3%81%AA%E3%82%82%E3%81%AE%E3%81%AB%E9%A3%9B%E3%81%B3%E3%81%A4%E3%81%8F%E3%81%AE%E3%81%AF%E3%81%B0%E3%81%8B%E3%81%A0%E3%80%82)
^ja-Q0796-answer

**ja-Q0797** — もっと早くはじめるべきだったのに。

You should have started by now.

Why: Contrast and concession. [[Japanese#^ja-Q0797|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%82%82%E3%81%A3%E3%81%A8%E6%97%A9%E3%81%8F%E3%81%AF%E3%81%98%E3%82%81%E3%82%8B%E3%81%B9%E3%81%8D%E3%81%A0%E3%81%A3%E3%81%9F%E3%81%AE%E3%81%AB%E3%80%82)
^ja-Q0797-answer

**ja-Q0798** — もっと早くはじめるべきだったのに。

You should have started by now.

These forms connect contrast or concession but differ in grammar and register. のに presents a contrary-to-expectation relation. でも has additional functions, including examples and alternatives.

Why: Contrast and concession. [[Japanese#^ja-Q0798|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%82%82%E3%81%A3%E3%81%A8%E6%97%A9%E3%81%8F%E3%81%AF%E3%81%98%E3%82%81%E3%82%8B%E3%81%B9%E3%81%8D%E3%81%A0%E3%81%A3%E3%81%9F%E3%81%AE%E3%81%AB%E3%80%82)
^ja-Q0798-answer

**ja-Q0799** — 今はそれについて話したくないんだけど。

I'd prefer to not talk about that now.

Expected form: **けど**

Why: Contrast and concession. [[Japanese#^ja-Q0799|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E4%BB%8A%E3%81%AF%E3%81%9D%E3%82%8C%E3%81%AB%E3%81%A4%E3%81%84%E3%81%A6%E8%A9%B1%E3%81%97%E3%81%9F%E3%81%8F%E3%81%AA%E3%81%84%E3%82%93%E3%81%A0%E3%81%91%E3%81%A9%E3%80%82)
^ja-Q0799-answer

**ja-Q0800** — 今はそれについて話したくないんだけど。

I'd prefer to not talk about that now.

Expected form: **けど**

Why: Contrast and concession. [[Japanese#^ja-Q0800|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E4%BB%8A%E3%81%AF%E3%81%9D%E3%82%8C%E3%81%AB%E3%81%A4%E3%81%84%E3%81%A6%E8%A9%B1%E3%81%97%E3%81%9F%E3%81%8F%E3%81%AA%E3%81%84%E3%82%93%E3%81%A0%E3%81%91%E3%81%A9%E3%80%82)
^ja-Q0800-answer


### Answers 801–850

**ja-Q0801** — 長い目で見れば、正直は報われる。

Honesty pays in the long run.

Expected form: **れば**

Why: Conditions. [[Japanese#^ja-Q0801|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E9%95%B7%E3%81%84%E7%9B%AE%E3%81%A7%E8%A6%8B%E3%82%8C%E3%81%B0%E3%80%81%E6%AD%A3%E7%9B%B4%E3%81%AF%E5%A0%B1%E3%82%8F%E3%82%8C%E3%82%8B%E3%80%82)
^ja-Q0801-answer

**ja-Q0802** — 長い目で見れば、正直は報われる。

Honesty pays in the long run.

Why: Conditions. [[Japanese#^ja-Q0802|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E9%95%B7%E3%81%84%E7%9B%AE%E3%81%A7%E8%A6%8B%E3%82%8C%E3%81%B0%E3%80%81%E6%AD%A3%E7%9B%B4%E3%81%AF%E5%A0%B1%E3%82%8F%E3%82%8C%E3%82%8B%E3%80%82)
^ja-Q0802-answer

**ja-Q0803** — 「もしも僕が豚になっても、変わらず友達でいてくれる？」「もちろんだよ！」

'Would you still be my friend even if I turned into a pig all of a sudden?' 'Of course!'

Why: Conditions. [[Japanese#^ja-Q0803|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%80%8C%E3%82%82%E3%81%97%E3%82%82%E5%83%95%E3%81%8C%E8%B1%9A%E3%81%AB%E3%81%AA%E3%81%A3%E3%81%A6%E3%82%82%E3%80%81%E5%A4%89%E3%82%8F%E3%82%89%E3%81%9A%E5%8F%8B%E9%81%94%E3%81%A7%E3%81%84%E3%81%A6%E3%81%8F%E3%82%8C%E3%82%8B%EF%BC%9F%E3%80%8D%E3%80%8C%E3%82%82%E3%81%A1%E3%82%8D%E3%82%93%E3%81%A0%E3%82%88%EF%BC%81%E3%80%8D)
^ja-Q0803-answer

**ja-Q0804** — 「もしも僕が豚になっても、変わらず友達でいてくれる？」「もちろんだよ！」

'Would you still be my friend even if I turned into a pig all of a sudden?' 'Of course!'

Japanese has several condition constructions with different timing and assumptions. もし can flag an if scenario but does not replace the needed predicate form. Avoid treating と, ば, たら and なら as fully interchangeable.

Why: Conditions. [[Japanese#^ja-Q0804|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%80%8C%E3%82%82%E3%81%97%E3%82%82%E5%83%95%E3%81%8C%E8%B1%9A%E3%81%AB%E3%81%AA%E3%81%A3%E3%81%A6%E3%82%82%E3%80%81%E5%A4%89%E3%82%8F%E3%82%89%E3%81%9A%E5%8F%8B%E9%81%94%E3%81%A7%E3%81%84%E3%81%A6%E3%81%8F%E3%82%8C%E3%82%8B%EF%BC%9F%E3%80%8D%E3%80%8C%E3%82%82%E3%81%A1%E3%82%8D%E3%82%93%E3%81%A0%E3%82%88%EF%BC%81%E3%80%8D)
^ja-Q0804-answer

**ja-Q0805** — 今、あなたがパソコンの電源を切れば、地球温暖化防止に貢献できる。

If you turned off your computer right now, you would contribute to the prevention of global warming.

Expected form: **れば**

Why: Conditions. [[Japanese#^ja-Q0805|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E4%BB%8A%E3%80%81%E3%81%82%E3%81%AA%E3%81%9F%E3%81%8C%E3%83%91%E3%82%BD%E3%82%B3%E3%83%B3%E3%81%AE%E9%9B%BB%E6%BA%90%E3%82%92%E5%88%87%E3%82%8C%E3%81%B0%E3%80%81%E5%9C%B0%E7%90%83%E6%B8%A9%E6%9A%96%E5%8C%96%E9%98%B2%E6%AD%A2%E3%81%AB%E8%B2%A2%E7%8C%AE%E3%81%A7%E3%81%8D%E3%82%8B%E3%80%82)
^ja-Q0805-answer

**ja-Q0806** — 今、あなたがパソコンの電源を切れば、地球温暖化防止に貢献できる。

If you turned off your computer right now, you would contribute to the prevention of global warming.

Expected form: **れば**

Why: Conditions. [[Japanese#^ja-Q0806|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E4%BB%8A%E3%80%81%E3%81%82%E3%81%AA%E3%81%9F%E3%81%8C%E3%83%91%E3%82%BD%E3%82%B3%E3%83%B3%E3%81%AE%E9%9B%BB%E6%BA%90%E3%82%92%E5%88%87%E3%82%8C%E3%81%B0%E3%80%81%E5%9C%B0%E7%90%83%E6%B8%A9%E6%9A%96%E5%8C%96%E9%98%B2%E6%AD%A2%E3%81%AB%E8%B2%A2%E7%8C%AE%E3%81%A7%E3%81%8D%E3%82%8B%E3%80%82)
^ja-Q0806-answer

**ja-Q0807** — 北極熊は、生きていくために体を適温に保ち、数日か数ヶ月もあくかもしれない食事の間持ちこたえられるだけの十分なエネルギーを蓄えねばならない。

To survive, the polar bear must keep its body at the right temperature and store enough energy to last between meals that could be a few days or a few months apart.

Expected form: **もし**

Why: Conditions. [[Japanese#^ja-Q0807|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%8C%97%E6%A5%B5%E7%86%8A%E3%81%AF%E3%80%81%E7%94%9F%E3%81%8D%E3%81%A6%E3%81%84%E3%81%8F%E3%81%9F%E3%82%81%E3%81%AB%E4%BD%93%E3%82%92%E9%81%A9%E6%B8%A9%E3%81%AB%E4%BF%9D%E3%81%A1%E3%80%81%E6%95%B0%E6%97%A5%E3%81%8B%E6%95%B0%E3%83%B6%E6%9C%88%E3%82%82%E3%81%82%E3%81%8F%E3%81%8B%E3%82%82%E3%81%97%E3%82%8C%E3%81%AA%E3%81%84%E9%A3%9F%E4%BA%8B%E3%81%AE%E9%96%93%E6%8C%81%E3%81%A1%E3%81%93%E3%81%9F%E3%81%88%E3%82%89%E3%82%8C%E3%82%8B%E3%81%A0%E3%81%91%E3%81%AE%E5%8D%81%E5%88%86%E3%81%AA%E3%82%A8%E3%83%8D%E3%83%AB%E3%82%AE%E3%83%BC%E3%82%92%E8%93%84%E3%81%88%E3%81%AD%E3%81%B0%E3%81%AA%E3%82%89%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0807-answer

**ja-Q0808** — 北極熊は、生きていくために体を適温に保ち、数日か数ヶ月もあくかもしれない食事の間持ちこたえられるだけの十分なエネルギーを蓄えねばならない。

To survive, the polar bear must keep its body at the right temperature and store enough energy to last between meals that could be a few days or a few months apart.

Why: Conditions. [[Japanese#^ja-Q0808|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%8C%97%E6%A5%B5%E7%86%8A%E3%81%AF%E3%80%81%E7%94%9F%E3%81%8D%E3%81%A6%E3%81%84%E3%81%8F%E3%81%9F%E3%82%81%E3%81%AB%E4%BD%93%E3%82%92%E9%81%A9%E6%B8%A9%E3%81%AB%E4%BF%9D%E3%81%A1%E3%80%81%E6%95%B0%E6%97%A5%E3%81%8B%E6%95%B0%E3%83%B6%E6%9C%88%E3%82%82%E3%81%82%E3%81%8F%E3%81%8B%E3%82%82%E3%81%97%E3%82%8C%E3%81%AA%E3%81%84%E9%A3%9F%E4%BA%8B%E3%81%AE%E9%96%93%E6%8C%81%E3%81%A1%E3%81%93%E3%81%9F%E3%81%88%E3%82%89%E3%82%8C%E3%82%8B%E3%81%A0%E3%81%91%E3%81%AE%E5%8D%81%E5%88%86%E3%81%AA%E3%82%A8%E3%83%8D%E3%83%AB%E3%82%AE%E3%83%BC%E3%82%92%E8%93%84%E3%81%88%E3%81%AD%E3%81%B0%E3%81%AA%E3%82%89%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0808-answer

**ja-Q0809** — もし怠けていなかったならば彼は成功しただろうに。

But that he was idle, he would have succeeded.

Why: Conditions. [[Japanese#^ja-Q0809|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%82%82%E3%81%97%E6%80%A0%E3%81%91%E3%81%A6%E3%81%84%E3%81%AA%E3%81%8B%E3%81%A3%E3%81%9F%E3%81%AA%E3%82%89%E3%81%B0%E5%BD%BC%E3%81%AF%E6%88%90%E5%8A%9F%E3%81%97%E3%81%9F%E3%81%A0%E3%82%8D%E3%81%86%E3%81%AB%E3%80%82)
^ja-Q0809-answer

**ja-Q0810** — もし怠けていなかったならば彼は成功しただろうに。

But that he was idle, he would have succeeded.

Japanese has several condition constructions with different timing and assumptions. もし can flag an if scenario but does not replace the needed predicate form. Avoid treating と, ば, たら and なら as fully interchangeable.

Why: Conditions. [[Japanese#^ja-Q0810|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%82%82%E3%81%97%E6%80%A0%E3%81%91%E3%81%A6%E3%81%84%E3%81%AA%E3%81%8B%E3%81%A3%E3%81%9F%E3%81%AA%E3%82%89%E3%81%B0%E5%BD%BC%E3%81%AF%E6%88%90%E5%8A%9F%E3%81%97%E3%81%9F%E3%81%A0%E3%82%8D%E3%81%86%E3%81%AB%E3%80%82)
^ja-Q0810-answer

**ja-Q0811** — もしすべてが彼女の計画通りに進むなら、彼女は引っ張りだこだろう。

If all went according to her plan, she would be in great demand.

Expected form: **もし**

Why: Conditions. [[Japanese#^ja-Q0811|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%82%82%E3%81%97%E3%81%99%E3%81%B9%E3%81%A6%E3%81%8C%E5%BD%BC%E5%A5%B3%E3%81%AE%E8%A8%88%E7%94%BB%E9%80%9A%E3%82%8A%E3%81%AB%E9%80%B2%E3%82%80%E3%81%AA%E3%82%89%E3%80%81%E5%BD%BC%E5%A5%B3%E3%81%AF%E5%BC%95%E3%81%A3%E5%BC%B5%E3%82%8A%E3%81%A0%E3%81%93%E3%81%A0%E3%82%8D%E3%81%86%E3%80%82)
^ja-Q0811-answer

**ja-Q0812** — もしすべてが彼女の計画通りに進むなら、彼女は引っ張りだこだろう。

If all went according to her plan, she would be in great demand.

Expected form: **もし**

Why: Conditions. [[Japanese#^ja-Q0812|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%82%82%E3%81%97%E3%81%99%E3%81%B9%E3%81%A6%E3%81%8C%E5%BD%BC%E5%A5%B3%E3%81%AE%E8%A8%88%E7%94%BB%E9%80%9A%E3%82%8A%E3%81%AB%E9%80%B2%E3%82%80%E3%81%AA%E3%82%89%E3%80%81%E5%BD%BC%E5%A5%B3%E3%81%AF%E5%BC%95%E3%81%A3%E5%BC%B5%E3%82%8A%E3%81%A0%E3%81%93%E3%81%A0%E3%82%8D%E3%81%86%E3%80%82)
^ja-Q0812-answer

**ja-Q0813** — 君が俺のそばにいてくれたらなあ。

I wish you were close to me.

Expected form: **たら**

Why: Conditions. [[Japanese#^ja-Q0813|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%90%9B%E3%81%8C%E4%BF%BA%E3%81%AE%E3%81%9D%E3%81%B0%E3%81%AB%E3%81%84%E3%81%A6%E3%81%8F%E3%82%8C%E3%81%9F%E3%82%89%E3%81%AA%E3%81%82%E3%80%82)
^ja-Q0813-answer

**ja-Q0814** — 君が俺のそばにいてくれたらなあ。

I wish you were close to me.

Why: Conditions. [[Japanese#^ja-Q0814|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%90%9B%E3%81%8C%E4%BF%BA%E3%81%AE%E3%81%9D%E3%81%B0%E3%81%AB%E3%81%84%E3%81%A6%E3%81%8F%E3%82%8C%E3%81%9F%E3%82%89%E3%81%AA%E3%81%82%E3%80%82)
^ja-Q0814-answer

**ja-Q0815** — 私たちは３月１５日までに税金を払わなければならない。

We have to pay taxes by March 15.

Why: Conditions. [[Japanese#^ja-Q0815|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%9F%E3%81%A1%E3%81%AF%EF%BC%93%E6%9C%88%EF%BC%91%EF%BC%95%E6%97%A5%E3%81%BE%E3%81%A7%E3%81%AB%E7%A8%8E%E9%87%91%E3%82%92%E6%89%95%E3%82%8F%E3%81%AA%E3%81%91%E3%82%8C%E3%81%B0%E3%81%AA%E3%82%89%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0815-answer

**ja-Q0816** — 私たちは３月１５日までに税金を払わなければならない。

We have to pay taxes by March 15.

Japanese has several condition constructions with different timing and assumptions. もし can flag an if scenario but does not replace the needed predicate form. Avoid treating と, ば, たら and なら as fully interchangeable.

Why: Conditions. [[Japanese#^ja-Q0816|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%9F%E3%81%A1%E3%81%AF%EF%BC%93%E6%9C%88%EF%BC%91%EF%BC%95%E6%97%A5%E3%81%BE%E3%81%A7%E3%81%AB%E7%A8%8E%E9%87%91%E3%82%92%E6%89%95%E3%82%8F%E3%81%AA%E3%81%91%E3%82%8C%E3%81%B0%E3%81%AA%E3%82%89%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0816-answer

**ja-Q0817** — 「君がそれをするのをやめさせなければいけないな。」「何をするのをやめさせるって？」

"I have to stop you from doing that." "Stop me from doing what?"

Expected form: **れば**

Why: Conditions. [[Japanese#^ja-Q0817|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%80%8C%E5%90%9B%E3%81%8C%E3%81%9D%E3%82%8C%E3%82%92%E3%81%99%E3%82%8B%E3%81%AE%E3%82%92%E3%82%84%E3%82%81%E3%81%95%E3%81%9B%E3%81%AA%E3%81%91%E3%82%8C%E3%81%B0%E3%81%84%E3%81%91%E3%81%AA%E3%81%84%E3%81%AA%E3%80%82%E3%80%8D%E3%80%8C%E4%BD%95%E3%82%92%E3%81%99%E3%82%8B%E3%81%AE%E3%82%92%E3%82%84%E3%82%81%E3%81%95%E3%81%9B%E3%82%8B%E3%81%A3%E3%81%A6%EF%BC%9F%E3%80%8D)
^ja-Q0817-answer

**ja-Q0818** — 「君がそれをするのをやめさせなければいけないな。」「何をするのをやめさせるって？」

"I have to stop you from doing that." "Stop me from doing what?"

Expected form: **れば**

Why: Conditions. [[Japanese#^ja-Q0818|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%80%8C%E5%90%9B%E3%81%8C%E3%81%9D%E3%82%8C%E3%82%92%E3%81%99%E3%82%8B%E3%81%AE%E3%82%92%E3%82%84%E3%82%81%E3%81%95%E3%81%9B%E3%81%AA%E3%81%91%E3%82%8C%E3%81%B0%E3%81%84%E3%81%91%E3%81%AA%E3%81%84%E3%81%AA%E3%80%82%E3%80%8D%E3%80%8C%E4%BD%95%E3%82%92%E3%81%99%E3%82%8B%E3%81%AE%E3%82%92%E3%82%84%E3%82%81%E3%81%95%E3%81%9B%E3%82%8B%E3%81%A3%E3%81%A6%EF%BC%9F%E3%80%8D)
^ja-Q0818-answer

**ja-Q0819** — あなたのように英語が話せたらいいなあ。

I wish I could speak English like you.

Expected form: **たら**

Why: Conditions. [[Japanese#^ja-Q0819|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%82%E3%81%AA%E3%81%9F%E3%81%AE%E3%82%88%E3%81%86%E3%81%AB%E8%8B%B1%E8%AA%9E%E3%81%8C%E8%A9%B1%E3%81%9B%E3%81%9F%E3%82%89%E3%81%84%E3%81%84%E3%81%AA%E3%81%82%E3%80%82)
^ja-Q0819-answer

**ja-Q0820** — あなたのように英語が話せたらいいなあ。

I wish I could speak English like you.

Why: Conditions. [[Japanese#^ja-Q0820|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%82%E3%81%AA%E3%81%9F%E3%81%AE%E3%82%88%E3%81%86%E3%81%AB%E8%8B%B1%E8%AA%9E%E3%81%8C%E8%A9%B1%E3%81%9B%E3%81%9F%E3%82%89%E3%81%84%E3%81%84%E3%81%AA%E3%81%82%E3%80%82)
^ja-Q0820-answer

**ja-Q0821** — 新聞によれば、昨夜地震があったそうだ。

According to the paper, there was an earthquake last night.

Why: Conditions. [[Japanese#^ja-Q0821|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%96%B0%E8%81%9E%E3%81%AB%E3%82%88%E3%82%8C%E3%81%B0%E3%80%81%E6%98%A8%E5%A4%9C%E5%9C%B0%E9%9C%87%E3%81%8C%E3%81%82%E3%81%A3%E3%81%9F%E3%81%9D%E3%81%86%E3%81%A0%E3%80%82)
^ja-Q0821-answer

**ja-Q0822** — 新聞によれば、昨夜地震があったそうだ。

According to the paper, there was an earthquake last night.

Japanese has several condition constructions with different timing and assumptions. もし can flag an if scenario but does not replace the needed predicate form. Avoid treating と, ば, たら and なら as fully interchangeable.

Why: Conditions. [[Japanese#^ja-Q0822|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%96%B0%E8%81%9E%E3%81%AB%E3%82%88%E3%82%8C%E3%81%B0%E3%80%81%E6%98%A8%E5%A4%9C%E5%9C%B0%E9%9C%87%E3%81%8C%E3%81%82%E3%81%A3%E3%81%9F%E3%81%9D%E3%81%86%E3%81%A0%E3%80%82)
^ja-Q0822-answer

**ja-Q0823** — このプログラムを持っていないならば、今ダウンロードすることができます。

If you do not have this program, you can download it now.

Expected form: **なら**

Why: Conditions. [[Japanese#^ja-Q0823|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%93%E3%81%AE%E3%83%97%E3%83%AD%E3%82%B0%E3%83%A9%E3%83%A0%E3%82%92%E6%8C%81%E3%81%A3%E3%81%A6%E3%81%84%E3%81%AA%E3%81%84%E3%81%AA%E3%82%89%E3%81%B0%E3%80%81%E4%BB%8A%E3%83%80%E3%82%A6%E3%83%B3%E3%83%AD%E3%83%BC%E3%83%89%E3%81%99%E3%82%8B%E3%81%93%E3%81%A8%E3%81%8C%E3%81%A7%E3%81%8D%E3%81%BE%E3%81%99%E3%80%82)
^ja-Q0823-answer

**ja-Q0824** — このプログラムを持っていないならば、今ダウンロードすることができます。

If you do not have this program, you can download it now.

Expected form: **なら**

Why: Conditions. [[Japanese#^ja-Q0824|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%93%E3%81%AE%E3%83%97%E3%83%AD%E3%82%B0%E3%83%A9%E3%83%A0%E3%82%92%E6%8C%81%E3%81%A3%E3%81%A6%E3%81%84%E3%81%AA%E3%81%84%E3%81%AA%E3%82%89%E3%81%B0%E3%80%81%E4%BB%8A%E3%83%80%E3%82%A6%E3%83%B3%E3%83%AD%E3%83%BC%E3%83%89%E3%81%99%E3%82%8B%E3%81%93%E3%81%A8%E3%81%8C%E3%81%A7%E3%81%8D%E3%81%BE%E3%81%99%E3%80%82)
^ja-Q0824-answer

**ja-Q0825** — 誤字脱字を見つけたら教えてください。

Please let me know if you find any typos or missing words.

Expected form: **たら**

Why: Conditions. [[Japanese#^ja-Q0825|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E8%AA%A4%E5%AD%97%E8%84%B1%E5%AD%97%E3%82%92%E8%A6%8B%E3%81%A4%E3%81%91%E3%81%9F%E3%82%89%E6%95%99%E3%81%88%E3%81%A6%E3%81%8F%E3%81%A0%E3%81%95%E3%81%84%E3%80%82)
^ja-Q0825-answer

**ja-Q0826** — 誤字脱字を見つけたら教えてください。

Please let me know if you find any typos or missing words.

Why: Conditions. [[Japanese#^ja-Q0826|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E8%AA%A4%E5%AD%97%E8%84%B1%E5%AD%97%E3%82%92%E8%A6%8B%E3%81%A4%E3%81%91%E3%81%9F%E3%82%89%E6%95%99%E3%81%88%E3%81%A6%E3%81%8F%E3%81%A0%E3%81%95%E3%81%84%E3%80%82)
^ja-Q0826-answer

**ja-Q0827** — あの寒い夜に風邪を引いたのかもしれない。

I may have caught cold on that cold night.

Why: Conditions. [[Japanese#^ja-Q0827|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%82%E3%81%AE%E5%AF%92%E3%81%84%E5%A4%9C%E3%81%AB%E9%A2%A8%E9%82%AA%E3%82%92%E5%BC%95%E3%81%84%E3%81%9F%E3%81%AE%E3%81%8B%E3%82%82%E3%81%97%E3%82%8C%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0827-answer

**ja-Q0828** — あの寒い夜に風邪を引いたのかもしれない。

I may have caught cold on that cold night.

Japanese has several condition constructions with different timing and assumptions. もし can flag an if scenario but does not replace the needed predicate form. Avoid treating と, ば, たら and なら as fully interchangeable.

Why: Conditions. [[Japanese#^ja-Q0828|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%82%E3%81%AE%E5%AF%92%E3%81%84%E5%A4%9C%E3%81%AB%E9%A2%A8%E9%82%AA%E3%82%92%E5%BC%95%E3%81%84%E3%81%9F%E3%81%AE%E3%81%8B%E3%82%82%E3%81%97%E3%82%8C%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0828-answer

**ja-Q0829** — 世界的な全面核戦争が起これば、地球規模でこの「核の冬」が数カ月間も続くと言われています。

If there's a world-wide all-out nuclear war it's said that there will be a "nuclear winter" all over the planet for several months.

Expected form: **れば**

Why: Conditions. [[Japanese#^ja-Q0829|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E4%B8%96%E7%95%8C%E7%9A%84%E3%81%AA%E5%85%A8%E9%9D%A2%E6%A0%B8%E6%88%A6%E4%BA%89%E3%81%8C%E8%B5%B7%E3%81%93%E3%82%8C%E3%81%B0%E3%80%81%E5%9C%B0%E7%90%83%E8%A6%8F%E6%A8%A1%E3%81%A7%E3%81%93%E3%81%AE%E3%80%8C%E6%A0%B8%E3%81%AE%E5%86%AC%E3%80%8D%E3%81%8C%E6%95%B0%E3%82%AB%E6%9C%88%E9%96%93%E3%82%82%E7%B6%9A%E3%81%8F%E3%81%A8%E8%A8%80%E3%82%8F%E3%82%8C%E3%81%A6%E3%81%84%E3%81%BE%E3%81%99%E3%80%82)
^ja-Q0829-answer

**ja-Q0830** — 世界的な全面核戦争が起これば、地球規模でこの「核の冬」が数カ月間も続くと言われています。

If there's a world-wide all-out nuclear war it's said that there will be a "nuclear winter" all over the planet for several months.

Expected form: **れば**

Why: Conditions. [[Japanese#^ja-Q0830|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E4%B8%96%E7%95%8C%E7%9A%84%E3%81%AA%E5%85%A8%E9%9D%A2%E6%A0%B8%E6%88%A6%E4%BA%89%E3%81%8C%E8%B5%B7%E3%81%93%E3%82%8C%E3%81%B0%E3%80%81%E5%9C%B0%E7%90%83%E8%A6%8F%E6%A8%A1%E3%81%A7%E3%81%93%E3%81%AE%E3%80%8C%E6%A0%B8%E3%81%AE%E5%86%AC%E3%80%8D%E3%81%8C%E6%95%B0%E3%82%AB%E6%9C%88%E9%96%93%E3%82%82%E7%B6%9A%E3%81%8F%E3%81%A8%E8%A8%80%E3%82%8F%E3%82%8C%E3%81%A6%E3%81%84%E3%81%BE%E3%81%99%E3%80%82)
^ja-Q0830-answer

**ja-Q0831** — あなたは私についてきさえすればよい。

All you have to do is follow me.

Expected form: **れば**

Why: Conditions. [[Japanese#^ja-Q0831|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%82%E3%81%AA%E3%81%9F%E3%81%AF%E7%A7%81%E3%81%AB%E3%81%A4%E3%81%84%E3%81%A6%E3%81%8D%E3%81%95%E3%81%88%E3%81%99%E3%82%8C%E3%81%B0%E3%82%88%E3%81%84%E3%80%82)
^ja-Q0831-answer

**ja-Q0832** — あなたは私についてきさえすればよい。

All you have to do is follow me.

Why: Conditions. [[Japanese#^ja-Q0832|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%82%E3%81%AA%E3%81%9F%E3%81%AF%E7%A7%81%E3%81%AB%E3%81%A4%E3%81%84%E3%81%A6%E3%81%8D%E3%81%95%E3%81%88%E3%81%99%E3%82%8C%E3%81%B0%E3%82%88%E3%81%84%E3%80%82)
^ja-Q0832-answer

**ja-Q0833** — 一週間で劇のせりふを思えなければならない。

We had to learn the lines of the play in park.

Why: Conditions. [[Japanese#^ja-Q0833|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E4%B8%80%E9%80%B1%E9%96%93%E3%81%A7%E5%8A%87%E3%81%AE%E3%81%9B%E3%82%8A%E3%81%B5%E3%82%92%E6%80%9D%E3%81%88%E3%81%AA%E3%81%91%E3%82%8C%E3%81%B0%E3%81%AA%E3%82%89%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0833-answer

**ja-Q0834** — 一週間で劇のせりふを思えなければならない。

We had to learn the lines of the play in park.

Japanese has several condition constructions with different timing and assumptions. もし can flag an if scenario but does not replace the needed predicate form. Avoid treating と, ば, たら and なら as fully interchangeable.

Why: Conditions. [[Japanese#^ja-Q0834|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E4%B8%80%E9%80%B1%E9%96%93%E3%81%A7%E5%8A%87%E3%81%AE%E3%81%9B%E3%82%8A%E3%81%B5%E3%82%92%E6%80%9D%E3%81%88%E3%81%AA%E3%81%91%E3%82%8C%E3%81%B0%E3%81%AA%E3%82%89%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0834-answer

**ja-Q0835** — 上司のミスター田中が君を飲みに誘うかもしれないってことを言っておくね。

I should tell you that my boss, Mr Tanaka, might try to take you drinking.

Expected form: **もし**

Why: Conditions. [[Japanese#^ja-Q0835|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E4%B8%8A%E5%8F%B8%E3%81%AE%E3%83%9F%E3%82%B9%E3%82%BF%E3%83%BC%E7%94%B0%E4%B8%AD%E3%81%8C%E5%90%9B%E3%82%92%E9%A3%B2%E3%81%BF%E3%81%AB%E8%AA%98%E3%81%86%E3%81%8B%E3%82%82%E3%81%97%E3%82%8C%E3%81%AA%E3%81%84%E3%81%A3%E3%81%A6%E3%81%93%E3%81%A8%E3%82%92%E8%A8%80%E3%81%A3%E3%81%A6%E3%81%8A%E3%81%8F%E3%81%AD%E3%80%82)
^ja-Q0835-answer

**ja-Q0836** — 上司のミスター田中が君を飲みに誘うかもしれないってことを言っておくね。

I should tell you that my boss, Mr Tanaka, might try to take you drinking.

Expected form: **もし**

Why: Conditions. [[Japanese#^ja-Q0836|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E4%B8%8A%E5%8F%B8%E3%81%AE%E3%83%9F%E3%82%B9%E3%82%BF%E3%83%BC%E7%94%B0%E4%B8%AD%E3%81%8C%E5%90%9B%E3%82%92%E9%A3%B2%E3%81%BF%E3%81%AB%E8%AA%98%E3%81%86%E3%81%8B%E3%82%82%E3%81%97%E3%82%8C%E3%81%AA%E3%81%84%E3%81%A3%E3%81%A6%E3%81%93%E3%81%A8%E3%82%92%E8%A8%80%E3%81%A3%E3%81%A6%E3%81%8A%E3%81%8F%E3%81%AD%E3%80%82)
^ja-Q0836-answer

**ja-Q0837** — 80円切手があったらなぁ。

I wish I had an 80-yen stamp.

Expected form: **たら**

Why: Conditions. [[Japanese#^ja-Q0837|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=80%E5%86%86%E5%88%87%E6%89%8B%E3%81%8C%E3%81%82%E3%81%A3%E3%81%9F%E3%82%89%E3%81%AA%E3%81%81%E3%80%82)
^ja-Q0837-answer

**ja-Q0838** — 80円切手があったらなぁ。

I wish I had an 80-yen stamp.

Why: Conditions. [[Japanese#^ja-Q0838|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=80%E5%86%86%E5%88%87%E6%89%8B%E3%81%8C%E3%81%82%E3%81%A3%E3%81%9F%E3%82%89%E3%81%AA%E3%81%81%E3%80%82)
^ja-Q0838-answer

**ja-Q0839** — 試してみなければ決して分からないだろう。

You'll never know unless you try.

Why: Conditions. [[Japanese#^ja-Q0839|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E8%A9%A6%E3%81%97%E3%81%A6%E3%81%BF%E3%81%AA%E3%81%91%E3%82%8C%E3%81%B0%E6%B1%BA%E3%81%97%E3%81%A6%E5%88%86%E3%81%8B%E3%82%89%E3%81%AA%E3%81%84%E3%81%A0%E3%82%8D%E3%81%86%E3%80%82)
^ja-Q0839-answer

**ja-Q0840** — 試してみなければ決して分からないだろう。

You'll never know unless you try.

Japanese has several condition constructions with different timing and assumptions. もし can flag an if scenario but does not replace the needed predicate form. Avoid treating と, ば, たら and なら as fully interchangeable.

Why: Conditions. [[Japanese#^ja-Q0840|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E8%A9%A6%E3%81%97%E3%81%A6%E3%81%BF%E3%81%AA%E3%81%91%E3%82%8C%E3%81%B0%E6%B1%BA%E3%81%97%E3%81%A6%E5%88%86%E3%81%8B%E3%82%89%E3%81%AA%E3%81%84%E3%81%A0%E3%82%8D%E3%81%86%E3%80%82)
^ja-Q0840-answer

**ja-Q0841** — ドイツ語がいいならドイツ語で話してもいいよ。

Feel free to speak German.

Expected form: **なら**

Why: Conditions. [[Japanese#^ja-Q0841|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%83%89%E3%82%A4%E3%83%84%E8%AA%9E%E3%81%8C%E3%81%84%E3%81%84%E3%81%AA%E3%82%89%E3%83%89%E3%82%A4%E3%83%84%E8%AA%9E%E3%81%A7%E8%A9%B1%E3%81%97%E3%81%A6%E3%82%82%E3%81%84%E3%81%84%E3%82%88%E3%80%82)
^ja-Q0841-answer

**ja-Q0842** — ドイツ語がいいならドイツ語で話してもいいよ。

Feel free to speak German.

Expected form: **なら**

Why: Conditions. [[Japanese#^ja-Q0842|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%83%89%E3%82%A4%E3%83%84%E8%AA%9E%E3%81%8C%E3%81%84%E3%81%84%E3%81%AA%E3%82%89%E3%83%89%E3%82%A4%E3%83%84%E8%AA%9E%E3%81%A7%E8%A9%B1%E3%81%97%E3%81%A6%E3%82%82%E3%81%84%E3%81%84%E3%82%88%E3%80%82)
^ja-Q0842-answer

**ja-Q0843** — もし６月前にその仕事を完成するつもりならばもっと努力が必要です。

If you are to finish the work before June, you will have to work much better.

Expected form: **もし**

Why: Conditions. [[Japanese#^ja-Q0843|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%82%82%E3%81%97%EF%BC%96%E6%9C%88%E5%89%8D%E3%81%AB%E3%81%9D%E3%81%AE%E4%BB%95%E4%BA%8B%E3%82%92%E5%AE%8C%E6%88%90%E3%81%99%E3%82%8B%E3%81%A4%E3%82%82%E3%82%8A%E3%81%AA%E3%82%89%E3%81%B0%E3%82%82%E3%81%A3%E3%81%A8%E5%8A%AA%E5%8A%9B%E3%81%8C%E5%BF%85%E8%A6%81%E3%81%A7%E3%81%99%E3%80%82)
^ja-Q0843-answer

**ja-Q0844** — もし６月前にその仕事を完成するつもりならばもっと努力が必要です。

If you are to finish the work before June, you will have to work much better.

Why: Conditions. [[Japanese#^ja-Q0844|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%82%82%E3%81%97%EF%BC%96%E6%9C%88%E5%89%8D%E3%81%AB%E3%81%9D%E3%81%AE%E4%BB%95%E4%BA%8B%E3%82%92%E5%AE%8C%E6%88%90%E3%81%99%E3%82%8B%E3%81%A4%E3%82%82%E3%82%8A%E3%81%AA%E3%82%89%E3%81%B0%E3%82%82%E3%81%A3%E3%81%A8%E5%8A%AA%E5%8A%9B%E3%81%8C%E5%BF%85%E8%A6%81%E3%81%A7%E3%81%99%E3%80%82)
^ja-Q0844-answer

**ja-Q0845** — 旅行者は夜明け前に離れなければならなかった。

The tourists had to leave the town before dawn.

Why: Conditions. [[Japanese#^ja-Q0845|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%97%85%E8%A1%8C%E8%80%85%E3%81%AF%E5%A4%9C%E6%98%8E%E3%81%91%E5%89%8D%E3%81%AB%E9%9B%A2%E3%82%8C%E3%81%AA%E3%81%91%E3%82%8C%E3%81%B0%E3%81%AA%E3%82%89%E3%81%AA%E3%81%8B%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0845-answer

**ja-Q0846** — 旅行者は夜明け前に離れなければならなかった。

The tourists had to leave the town before dawn.

Japanese has several condition constructions with different timing and assumptions. もし can flag an if scenario but does not replace the needed predicate form. Avoid treating と, ば, たら and なら as fully interchangeable.

Why: Conditions. [[Japanese#^ja-Q0846|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%97%85%E8%A1%8C%E8%80%85%E3%81%AF%E5%A4%9C%E6%98%8E%E3%81%91%E5%89%8D%E3%81%AB%E9%9B%A2%E3%82%8C%E3%81%AA%E3%81%91%E3%82%8C%E3%81%B0%E3%81%AA%E3%82%89%E3%81%AA%E3%81%8B%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0846-answer

**ja-Q0847** — あなたには感謝してもしたりない。

I can't thank you enough.

Expected form: **もし**

Why: Conditions. [[Japanese#^ja-Q0847|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%82%E3%81%AA%E3%81%9F%E3%81%AB%E3%81%AF%E6%84%9F%E8%AC%9D%E3%81%97%E3%81%A6%E3%82%82%E3%81%97%E3%81%9F%E3%82%8A%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0847-answer

**ja-Q0848** — あなたには感謝してもしたりない。

I can't thank you enough.

Expected form: **もし**

Why: Conditions. [[Japanese#^ja-Q0848|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%82%E3%81%AA%E3%81%9F%E3%81%AB%E3%81%AF%E6%84%9F%E8%AC%9D%E3%81%97%E3%81%A6%E3%82%82%E3%81%97%E3%81%9F%E3%82%8A%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0848-answer

**ja-Q0849** — 君は行かねばならない。

You have to go.

Expected form: **なら**

Why: Conditions. [[Japanese#^ja-Q0849|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%90%9B%E3%81%AF%E8%A1%8C%E3%81%8B%E3%81%AD%E3%81%B0%E3%81%AA%E3%82%89%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0849-answer

**ja-Q0850** — 君は行かねばならない。

You have to go.

Why: Conditions. [[Japanese#^ja-Q0850|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%90%9B%E3%81%AF%E8%A1%8C%E3%81%8B%E3%81%AD%E3%81%B0%E3%81%AA%E3%82%89%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0850-answer


### Answers 851–900

**ja-Q0851** — これ、本当にノンアルコールビールなんですか？

Is this really a non-alcoholic beer?

Why: Nominalisation and explanation. [[Japanese#^ja-Q0851|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%93%E3%82%8C%E3%80%81%E6%9C%AC%E5%BD%93%E3%81%AB%E3%83%8E%E3%83%B3%E3%82%A2%E3%83%AB%E3%82%B3%E3%83%BC%E3%83%AB%E3%83%93%E3%83%BC%E3%83%AB%E3%81%AA%E3%82%93%E3%81%A7%E3%81%99%E3%81%8B%EF%BC%9F)
^ja-Q0851-answer

**ja-Q0852** — これ、本当にノンアルコールビールなんですか？

Is this really a non-alcoholic beer?

こと can nominalise a proposition/activity. のです/んです adds explanatory framing. A nominalised clause can itself take particles and play a noun-like role.

Why: Nominalisation and explanation. [[Japanese#^ja-Q0852|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%93%E3%82%8C%E3%80%81%E6%9C%AC%E5%BD%93%E3%81%AB%E3%83%8E%E3%83%B3%E3%82%A2%E3%83%AB%E3%82%B3%E3%83%BC%E3%83%AB%E3%83%93%E3%83%BC%E3%83%AB%E3%81%AA%E3%82%93%E3%81%A7%E3%81%99%E3%81%8B%EF%BC%9F)
^ja-Q0852-answer

**ja-Q0853** — 大統領は発展途上諸国に十分な援助を提供することを決めた。

The President decided to provide developing countries with sufficient aid.

Expected form: **こと**

Why: Nominalisation and explanation. [[Japanese#^ja-Q0853|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%A4%A7%E7%B5%B1%E9%A0%98%E3%81%AF%E7%99%BA%E5%B1%95%E9%80%94%E4%B8%8A%E8%AB%B8%E5%9B%BD%E3%81%AB%E5%8D%81%E5%88%86%E3%81%AA%E6%8F%B4%E5%8A%A9%E3%82%92%E6%8F%90%E4%BE%9B%E3%81%99%E3%82%8B%E3%81%93%E3%81%A8%E3%82%92%E6%B1%BA%E3%82%81%E3%81%9F%E3%80%82)
^ja-Q0853-answer

**ja-Q0854** — 大統領は発展途上諸国に十分な援助を提供することを決めた。

The President decided to provide developing countries with sufficient aid.

Expected form: **こと**

Why: Nominalisation and explanation. [[Japanese#^ja-Q0854|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%A4%A7%E7%B5%B1%E9%A0%98%E3%81%AF%E7%99%BA%E5%B1%95%E9%80%94%E4%B8%8A%E8%AB%B8%E5%9B%BD%E3%81%AB%E5%8D%81%E5%88%86%E3%81%AA%E6%8F%B4%E5%8A%A9%E3%82%92%E6%8F%90%E4%BE%9B%E3%81%99%E3%82%8B%E3%81%93%E3%81%A8%E3%82%92%E6%B1%BA%E3%82%81%E3%81%9F%E3%80%82)
^ja-Q0854-answer

**ja-Q0855** — 最初は彼のことを信じなかった。

I didn't believe him at first.

Expected form: **こと**

Why: Nominalisation and explanation. [[Japanese#^ja-Q0855|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%9C%80%E5%88%9D%E3%81%AF%E5%BD%BC%E3%81%AE%E3%81%93%E3%81%A8%E3%82%92%E4%BF%A1%E3%81%98%E3%81%AA%E3%81%8B%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0855-answer

**ja-Q0856** — 最初は彼のことを信じなかった。

I didn't believe him at first.

Why: Nominalisation and explanation. [[Japanese#^ja-Q0856|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%9C%80%E5%88%9D%E3%81%AF%E5%BD%BC%E3%81%AE%E3%81%93%E3%81%A8%E3%82%92%E4%BF%A1%E3%81%98%E3%81%AA%E3%81%8B%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0856-answer

**ja-Q0857** — 何が起こったか知る唯一の方法は、トムに訊くことです。

The only way to find out what happened is to ask Tom.

Why: Nominalisation and explanation. [[Japanese#^ja-Q0857|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E4%BD%95%E3%81%8C%E8%B5%B7%E3%81%93%E3%81%A3%E3%81%9F%E3%81%8B%E7%9F%A5%E3%82%8B%E5%94%AF%E4%B8%80%E3%81%AE%E6%96%B9%E6%B3%95%E3%81%AF%E3%80%81%E3%83%88%E3%83%A0%E3%81%AB%E8%A8%8A%E3%81%8F%E3%81%93%E3%81%A8%E3%81%A7%E3%81%99%E3%80%82)
^ja-Q0857-answer

**ja-Q0858** — 何が起こったか知る唯一の方法は、トムに訊くことです。

The only way to find out what happened is to ask Tom.

こと can nominalise a proposition/activity. のです/んです adds explanatory framing. A nominalised clause can itself take particles and play a noun-like role.

Why: Nominalisation and explanation. [[Japanese#^ja-Q0858|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E4%BD%95%E3%81%8C%E8%B5%B7%E3%81%93%E3%81%A3%E3%81%9F%E3%81%8B%E7%9F%A5%E3%82%8B%E5%94%AF%E4%B8%80%E3%81%AE%E6%96%B9%E6%B3%95%E3%81%AF%E3%80%81%E3%83%88%E3%83%A0%E3%81%AB%E8%A8%8A%E3%81%8F%E3%81%93%E3%81%A8%E3%81%A7%E3%81%99%E3%80%82)
^ja-Q0858-answer

**ja-Q0859** — みんな寂しがっていたんですよ。

We all have missed you.

Expected form: **んです**

Why: Nominalisation and explanation. [[Japanese#^ja-Q0859|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%BF%E3%82%93%E3%81%AA%E5%AF%82%E3%81%97%E3%81%8C%E3%81%A3%E3%81%A6%E3%81%84%E3%81%9F%E3%82%93%E3%81%A7%E3%81%99%E3%82%88%E3%80%82)
^ja-Q0859-answer

**ja-Q0860** — みんな寂しがっていたんですよ。

We all have missed you.

Expected form: **んです**

Why: Nominalisation and explanation. [[Japanese#^ja-Q0860|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%BF%E3%82%93%E3%81%AA%E5%AF%82%E3%81%97%E3%81%8C%E3%81%A3%E3%81%A6%E3%81%84%E3%81%9F%E3%82%93%E3%81%A7%E3%81%99%E3%82%88%E3%80%82)
^ja-Q0860-answer

**ja-Q0861** — 君は自分を抑えることを学ぶべきだ。

You should learn to restrain yourself.

Expected form: **こと**

Why: Nominalisation and explanation. [[Japanese#^ja-Q0861|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%90%9B%E3%81%AF%E8%87%AA%E5%88%86%E3%82%92%E6%8A%91%E3%81%88%E3%82%8B%E3%81%93%E3%81%A8%E3%82%92%E5%AD%A6%E3%81%B6%E3%81%B9%E3%81%8D%E3%81%A0%E3%80%82)
^ja-Q0861-answer

**ja-Q0862** — 君は自分を抑えることを学ぶべきだ。

You should learn to restrain yourself.

Why: Nominalisation and explanation. [[Japanese#^ja-Q0862|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%90%9B%E3%81%AF%E8%87%AA%E5%88%86%E3%82%92%E6%8A%91%E3%81%88%E3%82%8B%E3%81%93%E3%81%A8%E3%82%92%E5%AD%A6%E3%81%B6%E3%81%B9%E3%81%8D%E3%81%A0%E3%80%82)
^ja-Q0862-answer

**ja-Q0863** — パターソン博士：そうです。ひどいことでした。

Dr. Patterson: Yes, it was horrible.

Why: Nominalisation and explanation. [[Japanese#^ja-Q0863|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%83%91%E3%82%BF%E3%83%BC%E3%82%BD%E3%83%B3%E5%8D%9A%E5%A3%AB%EF%BC%9A%E3%81%9D%E3%81%86%E3%81%A7%E3%81%99%E3%80%82%E3%81%B2%E3%81%A9%E3%81%84%E3%81%93%E3%81%A8%E3%81%A7%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0863-answer

**ja-Q0864** — パターソン博士：そうです。ひどいことでした。

Dr. Patterson: Yes, it was horrible.

こと can nominalise a proposition/activity. のです/んです adds explanatory framing. A nominalised clause can itself take particles and play a noun-like role.

Why: Nominalisation and explanation. [[Japanese#^ja-Q0864|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%83%91%E3%82%BF%E3%83%BC%E3%82%BD%E3%83%B3%E5%8D%9A%E5%A3%AB%EF%BC%9A%E3%81%9D%E3%81%86%E3%81%A7%E3%81%99%E3%80%82%E3%81%B2%E3%81%A9%E3%81%84%E3%81%93%E3%81%A8%E3%81%A7%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0864-answer

**ja-Q0865** — たまに彼女の自由奔放な態度は無礼に見えることがある。

Sometimes her free manner seems rude.

Expected form: **こと**

Why: Nominalisation and explanation. [[Japanese#^ja-Q0865|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%9F%E3%81%BE%E3%81%AB%E5%BD%BC%E5%A5%B3%E3%81%AE%E8%87%AA%E7%94%B1%E5%A5%94%E6%94%BE%E3%81%AA%E6%85%8B%E5%BA%A6%E3%81%AF%E7%84%A1%E7%A4%BC%E3%81%AB%E8%A6%8B%E3%81%88%E3%82%8B%E3%81%93%E3%81%A8%E3%81%8C%E3%81%82%E3%82%8B%E3%80%82)
^ja-Q0865-answer

**ja-Q0866** — たまに彼女の自由奔放な態度は無礼に見えることがある。

Sometimes her free manner seems rude.

Expected form: **こと**

Why: Nominalisation and explanation. [[Japanese#^ja-Q0866|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%9F%E3%81%BE%E3%81%AB%E5%BD%BC%E5%A5%B3%E3%81%AE%E8%87%AA%E7%94%B1%E5%A5%94%E6%94%BE%E3%81%AA%E6%85%8B%E5%BA%A6%E3%81%AF%E7%84%A1%E7%A4%BC%E3%81%AB%E8%A6%8B%E3%81%88%E3%82%8B%E3%81%93%E3%81%A8%E3%81%8C%E3%81%82%E3%82%8B%E3%80%82)
^ja-Q0866-answer

**ja-Q0867** — 彼女はときどき何時間もじっと座っていることがある。

She will sometimes sit still for hours.

Expected form: **こと**

Why: Nominalisation and explanation. [[Japanese#^ja-Q0867|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E5%A5%B3%E3%81%AF%E3%81%A8%E3%81%8D%E3%81%A9%E3%81%8D%E4%BD%95%E6%99%82%E9%96%93%E3%82%82%E3%81%98%E3%81%A3%E3%81%A8%E5%BA%A7%E3%81%A3%E3%81%A6%E3%81%84%E3%82%8B%E3%81%93%E3%81%A8%E3%81%8C%E3%81%82%E3%82%8B%E3%80%82)
^ja-Q0867-answer

**ja-Q0868** — 彼女はときどき何時間もじっと座っていることがある。

She will sometimes sit still for hours.

Why: Nominalisation and explanation. [[Japanese#^ja-Q0868|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E5%A5%B3%E3%81%AF%E3%81%A8%E3%81%8D%E3%81%A9%E3%81%8D%E4%BD%95%E6%99%82%E9%96%93%E3%82%82%E3%81%98%E3%81%A3%E3%81%A8%E5%BA%A7%E3%81%A3%E3%81%A6%E3%81%84%E3%82%8B%E3%81%93%E3%81%A8%E3%81%8C%E3%81%82%E3%82%8B%E3%80%82)
^ja-Q0868-answer

**ja-Q0869** — 本を読むことは大切です。

To read books is important.

Why: Nominalisation and explanation. [[Japanese#^ja-Q0869|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%9C%AC%E3%82%92%E8%AA%AD%E3%82%80%E3%81%93%E3%81%A8%E3%81%AF%E5%A4%A7%E5%88%87%E3%81%A7%E3%81%99%E3%80%82)
^ja-Q0869-answer

**ja-Q0870** — 本を読むことは大切です。

To read books is important.

こと can nominalise a proposition/activity. のです/んです adds explanatory framing. A nominalised clause can itself take particles and play a noun-like role.

Why: Nominalisation and explanation. [[Japanese#^ja-Q0870|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%9C%AC%E3%82%92%E8%AA%AD%E3%82%80%E3%81%93%E3%81%A8%E3%81%AF%E5%A4%A7%E5%88%87%E3%81%A7%E3%81%99%E3%80%82)
^ja-Q0870-answer

**ja-Q0871** — 彼は彼女を脇へ呼んでそのことを知らせた。

He took her aside and told her the news.

Expected form: **こと**

Why: Nominalisation and explanation. [[Japanese#^ja-Q0871|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%AF%E5%BD%BC%E5%A5%B3%E3%82%92%E8%84%87%E3%81%B8%E5%91%BC%E3%82%93%E3%81%A7%E3%81%9D%E3%81%AE%E3%81%93%E3%81%A8%E3%82%92%E7%9F%A5%E3%82%89%E3%81%9B%E3%81%9F%E3%80%82)
^ja-Q0871-answer

**ja-Q0872** — 彼は彼女を脇へ呼んでそのことを知らせた。

He took her aside and told her the news.

Expected form: **こと**

Why: Nominalisation and explanation. [[Japanese#^ja-Q0872|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%AF%E5%BD%BC%E5%A5%B3%E3%82%92%E8%84%87%E3%81%B8%E5%91%BC%E3%82%93%E3%81%A7%E3%81%9D%E3%81%AE%E3%81%93%E3%81%A8%E3%82%92%E7%9F%A5%E3%82%89%E3%81%9B%E3%81%9F%E3%80%82)
^ja-Q0872-answer

**ja-Q0873** — 来年のことを言えば鬼が笑う。

Next year is the devil's joke.

Expected form: **こと**

Why: Nominalisation and explanation. [[Japanese#^ja-Q0873|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%9D%A5%E5%B9%B4%E3%81%AE%E3%81%93%E3%81%A8%E3%82%92%E8%A8%80%E3%81%88%E3%81%B0%E9%AC%BC%E3%81%8C%E7%AC%91%E3%81%86%E3%80%82)
^ja-Q0873-answer

**ja-Q0874** — 来年のことを言えば鬼が笑う。

Next year is the devil's joke.

Why: Nominalisation and explanation. [[Japanese#^ja-Q0874|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%9D%A5%E5%B9%B4%E3%81%AE%E3%81%93%E3%81%A8%E3%82%92%E8%A8%80%E3%81%88%E3%81%B0%E9%AC%BC%E3%81%8C%E7%AC%91%E3%81%86%E3%80%82)
^ja-Q0874-answer

**ja-Q0875** — 私の見積もりでは、それは300ドルかかるだろうということだった。

I calculated that it would cost 300 dollars.

Why: Nominalisation and explanation. [[Japanese#^ja-Q0875|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AE%E8%A6%8B%E7%A9%8D%E3%82%82%E3%82%8A%E3%81%A7%E3%81%AF%E3%80%81%E3%81%9D%E3%82%8C%E3%81%AF300%E3%83%89%E3%83%AB%E3%81%8B%E3%81%8B%E3%82%8B%E3%81%A0%E3%82%8D%E3%81%86%E3%81%A8%E3%81%84%E3%81%86%E3%81%93%E3%81%A8%E3%81%A0%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0875-answer

**ja-Q0876** — 私の見積もりでは、それは300ドルかかるだろうということだった。

I calculated that it would cost 300 dollars.

こと can nominalise a proposition/activity. のです/んです adds explanatory framing. A nominalised clause can itself take particles and play a noun-like role.

Why: Nominalisation and explanation. [[Japanese#^ja-Q0876|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AE%E8%A6%8B%E7%A9%8D%E3%82%82%E3%82%8A%E3%81%A7%E3%81%AF%E3%80%81%E3%81%9D%E3%82%8C%E3%81%AF300%E3%83%89%E3%83%AB%E3%81%8B%E3%81%8B%E3%82%8B%E3%81%A0%E3%82%8D%E3%81%86%E3%81%A8%E3%81%84%E3%81%86%E3%81%93%E3%81%A8%E3%81%A0%E3%81%A3%E3%81%9F%E3%80%82)
^ja-Q0876-answer

**ja-Q0877** — 死ぬことより苦痛に耐えることの方がもっと勇気がいる。

It requires more courage to suffer than to die.

Expected form: **こと**

Why: Nominalisation and explanation. [[Japanese#^ja-Q0877|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%AD%BB%E3%81%AC%E3%81%93%E3%81%A8%E3%82%88%E3%82%8A%E8%8B%A6%E7%97%9B%E3%81%AB%E8%80%90%E3%81%88%E3%82%8B%E3%81%93%E3%81%A8%E3%81%AE%E6%96%B9%E3%81%8C%E3%82%82%E3%81%A3%E3%81%A8%E5%8B%87%E6%B0%97%E3%81%8C%E3%81%84%E3%82%8B%E3%80%82)
^ja-Q0877-answer

**ja-Q0878** — 死ぬことより苦痛に耐えることの方がもっと勇気がいる。

It requires more courage to suffer than to die.

Expected form: **こと**

Why: Nominalisation and explanation. [[Japanese#^ja-Q0878|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%AD%BB%E3%81%AC%E3%81%93%E3%81%A8%E3%82%88%E3%82%8A%E8%8B%A6%E7%97%9B%E3%81%AB%E8%80%90%E3%81%88%E3%82%8B%E3%81%93%E3%81%A8%E3%81%AE%E6%96%B9%E3%81%8C%E3%82%82%E3%81%A3%E3%81%A8%E5%8B%87%E6%B0%97%E3%81%8C%E3%81%84%E3%82%8B%E3%80%82)
^ja-Q0878-answer

**ja-Q0879** — 彼に酒を飲ませないようにすることはできない。

You cannot prevent him from drinking.

Expected form: **こと**

Why: Nominalisation and explanation. [[Japanese#^ja-Q0879|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%AB%E9%85%92%E3%82%92%E9%A3%B2%E3%81%BE%E3%81%9B%E3%81%AA%E3%81%84%E3%82%88%E3%81%86%E3%81%AB%E3%81%99%E3%82%8B%E3%81%93%E3%81%A8%E3%81%AF%E3%81%A7%E3%81%8D%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0879-answer

**ja-Q0880** — 彼に酒を飲ませないようにすることはできない。

You cannot prevent him from drinking.

Why: Nominalisation and explanation. [[Japanese#^ja-Q0880|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%AB%E9%85%92%E3%82%92%E9%A3%B2%E3%81%BE%E3%81%9B%E3%81%AA%E3%81%84%E3%82%88%E3%81%86%E3%81%AB%E3%81%99%E3%82%8B%E3%81%93%E3%81%A8%E3%81%AF%E3%81%A7%E3%81%8D%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0880-answer

**ja-Q0881** — 提案されている解決策を検討する前に、これらのグループの経済学的地位を概観しておくことが重要である。

It is important to overview the economic status of these groups before examining the proposed solutions.

Why: Nominalisation and explanation. [[Japanese#^ja-Q0881|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%8F%90%E6%A1%88%E3%81%95%E3%82%8C%E3%81%A6%E3%81%84%E3%82%8B%E8%A7%A3%E6%B1%BA%E7%AD%96%E3%82%92%E6%A4%9C%E8%A8%8E%E3%81%99%E3%82%8B%E5%89%8D%E3%81%AB%E3%80%81%E3%81%93%E3%82%8C%E3%82%89%E3%81%AE%E3%82%B0%E3%83%AB%E3%83%BC%E3%83%97%E3%81%AE%E7%B5%8C%E6%B8%88%E5%AD%A6%E7%9A%84%E5%9C%B0%E4%BD%8D%E3%82%92%E6%A6%82%E8%A6%B3%E3%81%97%E3%81%A6%E3%81%8A%E3%81%8F%E3%81%93%E3%81%A8%E3%81%8C%E9%87%8D%E8%A6%81%E3%81%A7%E3%81%82%E3%82%8B%E3%80%82)
^ja-Q0881-answer

**ja-Q0882** — 提案されている解決策を検討する前に、これらのグループの経済学的地位を概観しておくことが重要である。

It is important to overview the economic status of these groups before examining the proposed solutions.

こと can nominalise a proposition/activity. のです/んです adds explanatory framing. A nominalised clause can itself take particles and play a noun-like role.

Why: Nominalisation and explanation. [[Japanese#^ja-Q0882|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%8F%90%E6%A1%88%E3%81%95%E3%82%8C%E3%81%A6%E3%81%84%E3%82%8B%E8%A7%A3%E6%B1%BA%E7%AD%96%E3%82%92%E6%A4%9C%E8%A8%8E%E3%81%99%E3%82%8B%E5%89%8D%E3%81%AB%E3%80%81%E3%81%93%E3%82%8C%E3%82%89%E3%81%AE%E3%82%B0%E3%83%AB%E3%83%BC%E3%83%97%E3%81%AE%E7%B5%8C%E6%B8%88%E5%AD%A6%E7%9A%84%E5%9C%B0%E4%BD%8D%E3%82%92%E6%A6%82%E8%A6%B3%E3%81%97%E3%81%A6%E3%81%8A%E3%81%8F%E3%81%93%E3%81%A8%E3%81%8C%E9%87%8D%E8%A6%81%E3%81%A7%E3%81%82%E3%82%8B%E3%80%82)
^ja-Q0882-answer

**ja-Q0883** — 私達は彼と取り引きすることにした。

We decided to make a deal with him.

Expected form: **こと**

Why: Nominalisation and explanation. [[Japanese#^ja-Q0883|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E9%81%94%E3%81%AF%E5%BD%BC%E3%81%A8%E5%8F%96%E3%82%8A%E5%BC%95%E3%81%8D%E3%81%99%E3%82%8B%E3%81%93%E3%81%A8%E3%81%AB%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0883-answer

**ja-Q0884** — 私達は彼と取り引きすることにした。

We decided to make a deal with him.

Expected form: **こと**

Why: Nominalisation and explanation. [[Japanese#^ja-Q0884|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E9%81%94%E3%81%AF%E5%BD%BC%E3%81%A8%E5%8F%96%E3%82%8A%E5%BC%95%E3%81%8D%E3%81%99%E3%82%8B%E3%81%93%E3%81%A8%E3%81%AB%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0884-answer

**ja-Q0885** — その問題が簡単なことに気づいた。

I found the problem was easy.

Expected form: **こと**

Why: Nominalisation and explanation. [[Japanese#^ja-Q0885|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%9D%E3%81%AE%E5%95%8F%E9%A1%8C%E3%81%8C%E7%B0%A1%E5%8D%98%E3%81%AA%E3%81%93%E3%81%A8%E3%81%AB%E6%B0%97%E3%81%A5%E3%81%84%E3%81%9F%E3%80%82)
^ja-Q0885-answer

**ja-Q0886** — その問題が簡単なことに気づいた。

I found the problem was easy.

Why: Nominalisation and explanation. [[Japanese#^ja-Q0886|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%9D%E3%81%AE%E5%95%8F%E9%A1%8C%E3%81%8C%E7%B0%A1%E5%8D%98%E3%81%AA%E3%81%93%E3%81%A8%E3%81%AB%E6%B0%97%E3%81%A5%E3%81%84%E3%81%9F%E3%80%82)
^ja-Q0886-answer

**ja-Q0887** — オーストラリア人は全体として政治システムが安定していることによる恩恵に満足している。

Australians are, on the whole, pleased with the stabilizing benefits of their political system.

Why: Nominalisation and explanation. [[Japanese#^ja-Q0887|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%82%AA%E3%83%BC%E3%82%B9%E3%83%88%E3%83%A9%E3%83%AA%E3%82%A2%E4%BA%BA%E3%81%AF%E5%85%A8%E4%BD%93%E3%81%A8%E3%81%97%E3%81%A6%E6%94%BF%E6%B2%BB%E3%82%B7%E3%82%B9%E3%83%86%E3%83%A0%E3%81%8C%E5%AE%89%E5%AE%9A%E3%81%97%E3%81%A6%E3%81%84%E3%82%8B%E3%81%93%E3%81%A8%E3%81%AB%E3%82%88%E3%82%8B%E6%81%A9%E6%81%B5%E3%81%AB%E6%BA%80%E8%B6%B3%E3%81%97%E3%81%A6%E3%81%84%E3%82%8B%E3%80%82)
^ja-Q0887-answer

**ja-Q0888** — オーストラリア人は全体として政治システムが安定していることによる恩恵に満足している。

Australians are, on the whole, pleased with the stabilizing benefits of their political system.

こと can nominalise a proposition/activity. のです/んです adds explanatory framing. A nominalised clause can itself take particles and play a noun-like role.

Why: Nominalisation and explanation. [[Japanese#^ja-Q0888|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%82%AA%E3%83%BC%E3%82%B9%E3%83%88%E3%83%A9%E3%83%AA%E3%82%A2%E4%BA%BA%E3%81%AF%E5%85%A8%E4%BD%93%E3%81%A8%E3%81%97%E3%81%A6%E6%94%BF%E6%B2%BB%E3%82%B7%E3%82%B9%E3%83%86%E3%83%A0%E3%81%8C%E5%AE%89%E5%AE%9A%E3%81%97%E3%81%A6%E3%81%84%E3%82%8B%E3%81%93%E3%81%A8%E3%81%AB%E3%82%88%E3%82%8B%E6%81%A9%E6%81%B5%E3%81%AB%E6%BA%80%E8%B6%B3%E3%81%97%E3%81%A6%E3%81%84%E3%82%8B%E3%80%82)
^ja-Q0888-answer

**ja-Q0889** — 愛する我が子を失うことほど辛いことはない。

There's nothing more painful than losing one's loved child.

Expected form: **こと**

Why: Nominalisation and explanation. [[Japanese#^ja-Q0889|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%84%9B%E3%81%99%E3%82%8B%E6%88%91%E3%81%8C%E5%AD%90%E3%82%92%E5%A4%B1%E3%81%86%E3%81%93%E3%81%A8%E3%81%BB%E3%81%A9%E8%BE%9B%E3%81%84%E3%81%93%E3%81%A8%E3%81%AF%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0889-answer

**ja-Q0890** — 愛する我が子を失うことほど辛いことはない。

There's nothing more painful than losing one's loved child.

Expected form: **こと**

Why: Nominalisation and explanation. [[Japanese#^ja-Q0890|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%84%9B%E3%81%99%E3%82%8B%E6%88%91%E3%81%8C%E5%AD%90%E3%82%92%E5%A4%B1%E3%81%86%E3%81%93%E3%81%A8%E3%81%BB%E3%81%A9%E8%BE%9B%E3%81%84%E3%81%93%E3%81%A8%E3%81%AF%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0890-answer

**ja-Q0891** — 私はその問題を自分でとくことができます。

I can solve the problem by myself.

Expected form: **こと**

Why: Nominalisation and explanation. [[Japanese#^ja-Q0891|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AF%E3%81%9D%E3%81%AE%E5%95%8F%E9%A1%8C%E3%82%92%E8%87%AA%E5%88%86%E3%81%A7%E3%81%A8%E3%81%8F%E3%81%93%E3%81%A8%E3%81%8C%E3%81%A7%E3%81%8D%E3%81%BE%E3%81%99%E3%80%82)
^ja-Q0891-answer

**ja-Q0892** — 私はその問題を自分でとくことができます。

I can solve the problem by myself.

Why: Nominalisation and explanation. [[Japanese#^ja-Q0892|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AF%E3%81%9D%E3%81%AE%E5%95%8F%E9%A1%8C%E3%82%92%E8%87%AA%E5%88%86%E3%81%A7%E3%81%A8%E3%81%8F%E3%81%93%E3%81%A8%E3%81%8C%E3%81%A7%E3%81%8D%E3%81%BE%E3%81%99%E3%80%82)
^ja-Q0892-answer

**ja-Q0893** — たまに朝飯を抜いたって別に悪いことじゃない。

It's no crime to skip breakfast once in a while.

Why: Nominalisation and explanation. [[Japanese#^ja-Q0893|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%9F%E3%81%BE%E3%81%AB%E6%9C%9D%E9%A3%AF%E3%82%92%E6%8A%9C%E3%81%84%E3%81%9F%E3%81%A3%E3%81%A6%E5%88%A5%E3%81%AB%E6%82%AA%E3%81%84%E3%81%93%E3%81%A8%E3%81%98%E3%82%83%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0893-answer

**ja-Q0894** — たまに朝飯を抜いたって別に悪いことじゃない。

It's no crime to skip breakfast once in a while.

こと can nominalise a proposition/activity. のです/んです adds explanatory framing. A nominalised clause can itself take particles and play a noun-like role.

Why: Nominalisation and explanation. [[Japanese#^ja-Q0894|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%9F%E3%81%BE%E3%81%AB%E6%9C%9D%E9%A3%AF%E3%82%92%E6%8A%9C%E3%81%84%E3%81%9F%E3%81%A3%E3%81%A6%E5%88%A5%E3%81%AB%E6%82%AA%E3%81%84%E3%81%93%E3%81%A8%E3%81%98%E3%82%83%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0894-answer

**ja-Q0895** — 趣味というものを説明することは出来ない。

There is no accounting for tastes.

Expected form: **こと**

Why: Nominalisation and explanation. [[Japanese#^ja-Q0895|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E8%B6%A3%E5%91%B3%E3%81%A8%E3%81%84%E3%81%86%E3%82%82%E3%81%AE%E3%82%92%E8%AA%AC%E6%98%8E%E3%81%99%E3%82%8B%E3%81%93%E3%81%A8%E3%81%AF%E5%87%BA%E6%9D%A5%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0895-answer

**ja-Q0896** — 趣味というものを説明することは出来ない。

There is no accounting for tastes.

Expected form: **こと**

Why: Nominalisation and explanation. [[Japanese#^ja-Q0896|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E8%B6%A3%E5%91%B3%E3%81%A8%E3%81%84%E3%81%86%E3%82%82%E3%81%AE%E3%82%92%E8%AA%AC%E6%98%8E%E3%81%99%E3%82%8B%E3%81%93%E3%81%A8%E3%81%AF%E5%87%BA%E6%9D%A5%E3%81%AA%E3%81%84%E3%80%82)
^ja-Q0896-answer

**ja-Q0897** — 私は警官に知っていることを全部話した。

I told the policeman what I knew.

Expected form: **こと**

Why: Nominalisation and explanation. [[Japanese#^ja-Q0897|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AF%E8%AD%A6%E5%AE%98%E3%81%AB%E7%9F%A5%E3%81%A3%E3%81%A6%E3%81%84%E3%82%8B%E3%81%93%E3%81%A8%E3%82%92%E5%85%A8%E9%83%A8%E8%A9%B1%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0897-answer

**ja-Q0898** — 私は警官に知っていることを全部話した。

I told the policeman what I knew.

Why: Nominalisation and explanation. [[Japanese#^ja-Q0898|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AF%E8%AD%A6%E5%AE%98%E3%81%AB%E7%9F%A5%E3%81%A3%E3%81%A6%E3%81%84%E3%82%8B%E3%81%93%E3%81%A8%E3%82%92%E5%85%A8%E9%83%A8%E8%A9%B1%E3%81%97%E3%81%9F%E3%80%82)
^ja-Q0898-answer

**ja-Q0899** — ぼくは君の言うことなんか信じないよ。君はいつもうそばかりついているじゃないか。

I don't believe you. You're always telling lies.

Why: Nominalisation and explanation. [[Japanese#^ja-Q0899|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%BC%E3%81%8F%E3%81%AF%E5%90%9B%E3%81%AE%E8%A8%80%E3%81%86%E3%81%93%E3%81%A8%E3%81%AA%E3%82%93%E3%81%8B%E4%BF%A1%E3%81%98%E3%81%AA%E3%81%84%E3%82%88%E3%80%82%E5%90%9B%E3%81%AF%E3%81%84%E3%81%A4%E3%82%82%E3%81%86%E3%81%9D%E3%81%B0%E3%81%8B%E3%82%8A%E3%81%A4%E3%81%84%E3%81%A6%E3%81%84%E3%82%8B%E3%81%98%E3%82%83%E3%81%AA%E3%81%84%E3%81%8B%E3%80%82)
^ja-Q0899-answer

**ja-Q0900** — ぼくは君の言うことなんか信じないよ。君はいつもうそばかりついているじゃないか。

I don't believe you. You're always telling lies.

こと can nominalise a proposition/activity. のです/んです adds explanatory framing. A nominalised clause can itself take particles and play a noun-like role.

Why: Nominalisation and explanation. [[Japanese#^ja-Q0900|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%BC%E3%81%8F%E3%81%AF%E5%90%9B%E3%81%AE%E8%A8%80%E3%81%86%E3%81%93%E3%81%A8%E3%81%AA%E3%82%93%E3%81%8B%E4%BF%A1%E3%81%98%E3%81%AA%E3%81%84%E3%82%88%E3%80%82%E5%90%9B%E3%81%AF%E3%81%84%E3%81%A4%E3%82%82%E3%81%86%E3%81%9D%E3%81%B0%E3%81%8B%E3%82%8A%E3%81%A4%E3%81%84%E3%81%A6%E3%81%84%E3%82%8B%E3%81%98%E3%82%83%E3%81%AA%E3%81%84%E3%81%8B%E3%80%82)
^ja-Q0900-answer


### Answers 901–950

**ja-Q0901** — 知らせてください。

Please let me know.

Expected form: **ください**

Why: Polite requests. [[Japanese#^ja-Q0901|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%9F%A5%E3%82%89%E3%81%9B%E3%81%A6%E3%81%8F%E3%81%A0%E3%81%95%E3%81%84%E3%80%82)
^ja-Q0901-answer

**ja-Q0902** — 知らせてください。

Please let me know.

Expected form: **ください**

Why: Polite requests. [[Japanese#^ja-Q0902|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%9F%A5%E3%82%89%E3%81%9B%E3%81%A6%E3%81%8F%E3%81%A0%E3%81%95%E3%81%84%E3%80%82)
^ja-Q0902-answer

**ja-Q0903** — 私にお茶を入れてください。

Please make me some tea.

Expected form: **ください**

Why: Polite requests. [[Japanese#^ja-Q0903|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AB%E3%81%8A%E8%8C%B6%E3%82%92%E5%85%A5%E3%82%8C%E3%81%A6%E3%81%8F%E3%81%A0%E3%81%95%E3%81%84%E3%80%82)
^ja-Q0903-answer

**ja-Q0904** — 私にお茶を入れてください。

Please make me some tea.

Why: Polite requests. [[Japanese#^ja-Q0904|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AB%E3%81%8A%E8%8C%B6%E3%82%92%E5%85%A5%E3%82%8C%E3%81%A6%E3%81%8F%E3%81%A0%E3%81%95%E3%81%84%E3%80%82)
^ja-Q0904-answer

**ja-Q0905** — 水分をたくさん取ってください。

You should drink a lot of liquid.

Why: Polite requests. [[Japanese#^ja-Q0905|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%B0%B4%E5%88%86%E3%82%92%E3%81%9F%E3%81%8F%E3%81%95%E3%82%93%E5%8F%96%E3%81%A3%E3%81%A6%E3%81%8F%E3%81%A0%E3%81%95%E3%81%84%E3%80%82)
^ja-Q0905-answer

**ja-Q0906** — 水分をたくさん取ってください。

You should drink a lot of liquid.

Politeness depends on the entire construction and social relationship. Honorific and humble forms orient differently to whose action is described; they are not merely longer synonyms.

Why: Polite requests. [[Japanese#^ja-Q0906|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%B0%B4%E5%88%86%E3%82%92%E3%81%9F%E3%81%8F%E3%81%95%E3%82%93%E5%8F%96%E3%81%A3%E3%81%A6%E3%81%8F%E3%81%A0%E3%81%95%E3%81%84%E3%80%82)
^ja-Q0906-answer

**ja-Q0907** — 万一に備えて連絡をたもってください。

Try to keep in touch with me, just in case.

Expected form: **ください**

Why: Polite requests. [[Japanese#^ja-Q0907|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E4%B8%87%E4%B8%80%E3%81%AB%E5%82%99%E3%81%88%E3%81%A6%E9%80%A3%E7%B5%A1%E3%82%92%E3%81%9F%E3%82%82%E3%81%A3%E3%81%A6%E3%81%8F%E3%81%A0%E3%81%95%E3%81%84%E3%80%82)
^ja-Q0907-answer

**ja-Q0908** — 万一に備えて連絡をたもってください。

Try to keep in touch with me, just in case.

Expected form: **ください**

Why: Polite requests. [[Japanese#^ja-Q0908|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E4%B8%87%E4%B8%80%E3%81%AB%E5%82%99%E3%81%88%E3%81%A6%E9%80%A3%E7%B5%A1%E3%82%92%E3%81%9F%E3%82%82%E3%81%A3%E3%81%A6%E3%81%8F%E3%81%A0%E3%81%95%E3%81%84%E3%80%82)
^ja-Q0908-answer

**ja-Q0909** — グラスワインの赤をお願いします。

A glass of red wine, please.

Expected form: **お願いします**

Why: Polite requests. [[Japanese#^ja-Q0909|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%82%B0%E3%83%A9%E3%82%B9%E3%83%AF%E3%82%A4%E3%83%B3%E3%81%AE%E8%B5%A4%E3%82%92%E3%81%8A%E9%A1%98%E3%81%84%E3%81%97%E3%81%BE%E3%81%99%E3%80%82)
^ja-Q0909-answer

**ja-Q0910** — グラスワインの赤をお願いします。

A glass of red wine, please.

Why: Polite requests. [[Japanese#^ja-Q0910|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%82%B0%E3%83%A9%E3%82%B9%E3%83%AF%E3%82%A4%E3%83%B3%E3%81%AE%E8%B5%A4%E3%82%92%E3%81%8A%E9%A1%98%E3%81%84%E3%81%97%E3%81%BE%E3%81%99%E3%80%82)
^ja-Q0910-answer

**ja-Q0911** — 卵をあまり固くゆでないでください。

Please don't boil the eggs so hard.

Why: Polite requests. [[Japanese#^ja-Q0911|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%8D%B5%E3%82%92%E3%81%82%E3%81%BE%E3%82%8A%E5%9B%BA%E3%81%8F%E3%82%86%E3%81%A7%E3%81%AA%E3%81%84%E3%81%A7%E3%81%8F%E3%81%A0%E3%81%95%E3%81%84%E3%80%82)
^ja-Q0911-answer

**ja-Q0912** — 卵をあまり固くゆでないでください。

Please don't boil the eggs so hard.

Politeness depends on the entire construction and social relationship. Honorific and humble forms orient differently to whose action is described; they are not merely longer synonyms.

Why: Polite requests. [[Japanese#^ja-Q0912|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%8D%B5%E3%82%92%E3%81%82%E3%81%BE%E3%82%8A%E5%9B%BA%E3%81%8F%E3%82%86%E3%81%A7%E3%81%AA%E3%81%84%E3%81%A7%E3%81%8F%E3%81%A0%E3%81%95%E3%81%84%E3%80%82)
^ja-Q0912-answer

**ja-Q0913** — お買い物にお越しの際には是非、お立ち寄りください。

Please, by all means, drop in when you go shopping.

Expected form: **ください**

Why: Polite requests. [[Japanese#^ja-Q0913|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%8A%E8%B2%B7%E3%81%84%E7%89%A9%E3%81%AB%E3%81%8A%E8%B6%8A%E3%81%97%E3%81%AE%E9%9A%9B%E3%81%AB%E3%81%AF%E6%98%AF%E9%9D%9E%E3%80%81%E3%81%8A%E7%AB%8B%E3%81%A1%E5%AF%84%E3%82%8A%E3%81%8F%E3%81%A0%E3%81%95%E3%81%84%E3%80%82)
^ja-Q0913-answer

**ja-Q0914** — お買い物にお越しの際には是非、お立ち寄りください。

Please, by all means, drop in when you go shopping.

Expected form: **ください**

Why: Polite requests. [[Japanese#^ja-Q0914|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%8A%E8%B2%B7%E3%81%84%E7%89%A9%E3%81%AB%E3%81%8A%E8%B6%8A%E3%81%97%E3%81%AE%E9%9A%9B%E3%81%AB%E3%81%AF%E6%98%AF%E9%9D%9E%E3%80%81%E3%81%8A%E7%AB%8B%E3%81%A1%E5%AF%84%E3%82%8A%E3%81%8F%E3%81%A0%E3%81%95%E3%81%84%E3%80%82)
^ja-Q0914-answer

**ja-Q0915** — あなたの新しい住所を教えてください。

Let me know your new address.

Expected form: **ください**

Why: Polite requests. [[Japanese#^ja-Q0915|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%82%E3%81%AA%E3%81%9F%E3%81%AE%E6%96%B0%E3%81%97%E3%81%84%E4%BD%8F%E6%89%80%E3%82%92%E6%95%99%E3%81%88%E3%81%A6%E3%81%8F%E3%81%A0%E3%81%95%E3%81%84%E3%80%82)
^ja-Q0915-answer

**ja-Q0916** — あなたの新しい住所を教えてください。

Let me know your new address.

Why: Polite requests. [[Japanese#^ja-Q0916|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%82%E3%81%AA%E3%81%9F%E3%81%AE%E6%96%B0%E3%81%97%E3%81%84%E4%BD%8F%E6%89%80%E3%82%92%E6%95%99%E3%81%88%E3%81%A6%E3%81%8F%E3%81%A0%E3%81%95%E3%81%84%E3%80%82)
^ja-Q0916-answer

**ja-Q0917** — これを１日に３回、飲んでください。

Please drink this three times per day.

Why: Polite requests. [[Japanese#^ja-Q0917|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%93%E3%82%8C%E3%82%92%EF%BC%91%E6%97%A5%E3%81%AB%EF%BC%93%E5%9B%9E%E3%80%81%E9%A3%B2%E3%82%93%E3%81%A7%E3%81%8F%E3%81%A0%E3%81%95%E3%81%84%E3%80%82)
^ja-Q0917-answer

**ja-Q0918** — これを１日に３回、飲んでください。

Please drink this three times per day.

Politeness depends on the entire construction and social relationship. Honorific and humble forms orient differently to whose action is described; they are not merely longer synonyms.

Why: Polite requests. [[Japanese#^ja-Q0918|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%93%E3%82%8C%E3%82%92%EF%BC%91%E6%97%A5%E3%81%AB%EF%BC%93%E5%9B%9E%E3%80%81%E9%A3%B2%E3%82%93%E3%81%A7%E3%81%8F%E3%81%A0%E3%81%95%E3%81%84%E3%80%82)
^ja-Q0918-answer

**ja-Q0919** — アルコール類は控えてください。

Don't drink any alcohol.

Expected form: **ください**

Why: Polite requests. [[Japanese#^ja-Q0919|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%82%A2%E3%83%AB%E3%82%B3%E3%83%BC%E3%83%AB%E9%A1%9E%E3%81%AF%E6%8E%A7%E3%81%88%E3%81%A6%E3%81%8F%E3%81%A0%E3%81%95%E3%81%84%E3%80%82)
^ja-Q0919-answer

**ja-Q0920** — アルコール類は控えてください。

Don't drink any alcohol.

Expected form: **ください**

Why: Polite requests. [[Japanese#^ja-Q0920|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%82%A2%E3%83%AB%E3%82%B3%E3%83%BC%E3%83%AB%E9%A1%9E%E3%81%AF%E6%8E%A7%E3%81%88%E3%81%A6%E3%81%8F%E3%81%A0%E3%81%95%E3%81%84%E3%80%82)
^ja-Q0920-answer

**ja-Q0921** — 手紙を速達で送ってください。

Please send the letter by express.

Expected form: **ください**

Why: Polite requests. [[Japanese#^ja-Q0921|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%89%8B%E7%B4%99%E3%82%92%E9%80%9F%E9%81%94%E3%81%A7%E9%80%81%E3%81%A3%E3%81%A6%E3%81%8F%E3%81%A0%E3%81%95%E3%81%84%E3%80%82)
^ja-Q0921-answer

**ja-Q0922** — 手紙を速達で送ってください。

Please send the letter by express.

Why: Polite requests. [[Japanese#^ja-Q0922|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%89%8B%E7%B4%99%E3%82%92%E9%80%9F%E9%81%94%E3%81%A7%E9%80%81%E3%81%A3%E3%81%A6%E3%81%8F%E3%81%A0%E3%81%95%E3%81%84%E3%80%82)
^ja-Q0922-answer

**ja-Q0923** — そんな事は気にしないでください。

Oh, don't worry about that.

Why: Polite requests. [[Japanese#^ja-Q0923|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%9D%E3%82%93%E3%81%AA%E4%BA%8B%E3%81%AF%E6%B0%97%E3%81%AB%E3%81%97%E3%81%AA%E3%81%84%E3%81%A7%E3%81%8F%E3%81%A0%E3%81%95%E3%81%84%E3%80%82)
^ja-Q0923-answer

**ja-Q0924** — そんな事は気にしないでください。

Oh, don't worry about that.

Politeness depends on the entire construction and social relationship. Honorific and humble forms orient differently to whose action is described; they are not merely longer synonyms.

Why: Polite requests. [[Japanese#^ja-Q0924|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%9D%E3%82%93%E3%81%AA%E4%BA%8B%E3%81%AF%E6%B0%97%E3%81%AB%E3%81%97%E3%81%AA%E3%81%84%E3%81%A7%E3%81%8F%E3%81%A0%E3%81%95%E3%81%84%E3%80%82)
^ja-Q0924-answer

**ja-Q0925** — 車を停めてください。

Please pull over.

Expected form: **ください**

Why: Polite requests. [[Japanese#^ja-Q0925|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E8%BB%8A%E3%82%92%E5%81%9C%E3%82%81%E3%81%A6%E3%81%8F%E3%81%A0%E3%81%95%E3%81%84%E3%80%82)
^ja-Q0925-answer

**ja-Q0926** — 車を停めてください。

Please pull over.

Expected form: **ください**

Why: Polite requests. [[Japanese#^ja-Q0926|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E8%BB%8A%E3%82%92%E5%81%9C%E3%82%81%E3%81%A6%E3%81%8F%E3%81%A0%E3%81%95%E3%81%84%E3%80%82)
^ja-Q0926-answer

**ja-Q0927** — ちょっと電話を貸してください。

May I use your telephone?

Expected form: **ください**

Why: Polite requests. [[Japanese#^ja-Q0927|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%A1%E3%82%87%E3%81%A3%E3%81%A8%E9%9B%BB%E8%A9%B1%E3%82%92%E8%B2%B8%E3%81%97%E3%81%A6%E3%81%8F%E3%81%A0%E3%81%95%E3%81%84%E3%80%82)
^ja-Q0927-answer

**ja-Q0928** — ちょっと電話を貸してください。

May I use your telephone?

Why: Polite requests. [[Japanese#^ja-Q0928|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%A1%E3%82%87%E3%81%A3%E3%81%A8%E9%9B%BB%E8%A9%B1%E3%82%92%E8%B2%B8%E3%81%97%E3%81%A6%E3%81%8F%E3%81%A0%E3%81%95%E3%81%84%E3%80%82)
^ja-Q0928-answer

**ja-Q0929** — このメッセージを見たら、返事をください。

If you see this message, write to me.

Why: Polite requests. [[Japanese#^ja-Q0929|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%93%E3%81%AE%E3%83%A1%E3%83%83%E3%82%BB%E3%83%BC%E3%82%B8%E3%82%92%E8%A6%8B%E3%81%9F%E3%82%89%E3%80%81%E8%BF%94%E4%BA%8B%E3%82%92%E3%81%8F%E3%81%A0%E3%81%95%E3%81%84%E3%80%82)
^ja-Q0929-answer

**ja-Q0930** — このメッセージを見たら、返事をください。

If you see this message, write to me.

Politeness depends on the entire construction and social relationship. Honorific and humble forms orient differently to whose action is described; they are not merely longer synonyms.

Why: Polite requests. [[Japanese#^ja-Q0930|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%93%E3%81%AE%E3%83%A1%E3%83%83%E3%82%BB%E3%83%BC%E3%82%B8%E3%82%92%E8%A6%8B%E3%81%9F%E3%82%89%E3%80%81%E8%BF%94%E4%BA%8B%E3%82%92%E3%81%8F%E3%81%A0%E3%81%95%E3%81%84%E3%80%82)
^ja-Q0930-answer

**ja-Q0931** — 家を出る前にはガスのスイッチを切ることを忘れないでください。

Don't forget to turn off the gas before you leave the house.

Expected form: **ください**

Why: Polite requests. [[Japanese#^ja-Q0931|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%AE%B6%E3%82%92%E5%87%BA%E3%82%8B%E5%89%8D%E3%81%AB%E3%81%AF%E3%82%AC%E3%82%B9%E3%81%AE%E3%82%B9%E3%82%A4%E3%83%83%E3%83%81%E3%82%92%E5%88%87%E3%82%8B%E3%81%93%E3%81%A8%E3%82%92%E5%BF%98%E3%82%8C%E3%81%AA%E3%81%84%E3%81%A7%E3%81%8F%E3%81%A0%E3%81%95%E3%81%84%E3%80%82)
^ja-Q0931-answer

**ja-Q0932** — 家を出る前にはガスのスイッチを切ることを忘れないでください。

Don't forget to turn off the gas before you leave the house.

Expected form: **ください**

Why: Polite requests. [[Japanese#^ja-Q0932|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%AE%B6%E3%82%92%E5%87%BA%E3%82%8B%E5%89%8D%E3%81%AB%E3%81%AF%E3%82%AC%E3%82%B9%E3%81%AE%E3%82%B9%E3%82%A4%E3%83%83%E3%83%81%E3%82%92%E5%88%87%E3%82%8B%E3%81%93%E3%81%A8%E3%82%92%E5%BF%98%E3%82%8C%E3%81%AA%E3%81%84%E3%81%A7%E3%81%8F%E3%81%A0%E3%81%95%E3%81%84%E3%80%82)
^ja-Q0932-answer

**ja-Q0933** — 彼女にご協力いただけますことについて、あらかじめお礼を申し上げます。

I would like to thank you in advance for any help that you are able to give her.

Expected form: **いただけ**

Why: Polite requests. [[Japanese#^ja-Q0933|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E5%A5%B3%E3%81%AB%E3%81%94%E5%8D%94%E5%8A%9B%E3%81%84%E3%81%9F%E3%81%A0%E3%81%91%E3%81%BE%E3%81%99%E3%81%93%E3%81%A8%E3%81%AB%E3%81%A4%E3%81%84%E3%81%A6%E3%80%81%E3%81%82%E3%82%89%E3%81%8B%E3%81%98%E3%82%81%E3%81%8A%E7%A4%BC%E3%82%92%E7%94%B3%E3%81%97%E4%B8%8A%E3%81%92%E3%81%BE%E3%81%99%E3%80%82)
^ja-Q0933-answer

**ja-Q0934** — 彼女にご協力いただけますことについて、あらかじめお礼を申し上げます。

I would like to thank you in advance for any help that you are able to give her.

Why: Polite requests. [[Japanese#^ja-Q0934|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E5%A5%B3%E3%81%AB%E3%81%94%E5%8D%94%E5%8A%9B%E3%81%84%E3%81%9F%E3%81%A0%E3%81%91%E3%81%BE%E3%81%99%E3%81%93%E3%81%A8%E3%81%AB%E3%81%A4%E3%81%84%E3%81%A6%E3%80%81%E3%81%82%E3%82%89%E3%81%8B%E3%81%98%E3%82%81%E3%81%8A%E7%A4%BC%E3%82%92%E7%94%B3%E3%81%97%E4%B8%8A%E3%81%92%E3%81%BE%E3%81%99%E3%80%82)
^ja-Q0934-answer

**ja-Q0935** — 不審者を見かけたら警察に通報してください。

If you see a suspicious person, please inform the police.

Why: Polite requests. [[Japanese#^ja-Q0935|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E4%B8%8D%E5%AF%A9%E8%80%85%E3%82%92%E8%A6%8B%E3%81%8B%E3%81%91%E3%81%9F%E3%82%89%E8%AD%A6%E5%AF%9F%E3%81%AB%E9%80%9A%E5%A0%B1%E3%81%97%E3%81%A6%E3%81%8F%E3%81%A0%E3%81%95%E3%81%84%E3%80%82)
^ja-Q0935-answer

**ja-Q0936** — 不審者を見かけたら警察に通報してください。

If you see a suspicious person, please inform the police.

Politeness depends on the entire construction and social relationship. Honorific and humble forms orient differently to whose action is described; they are not merely longer synonyms.

Why: Polite requests. [[Japanese#^ja-Q0936|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E4%B8%8D%E5%AF%A9%E8%80%85%E3%82%92%E8%A6%8B%E3%81%8B%E3%81%91%E3%81%9F%E3%82%89%E8%AD%A6%E5%AF%9F%E3%81%AB%E9%80%9A%E5%A0%B1%E3%81%97%E3%81%A6%E3%81%8F%E3%81%A0%E3%81%95%E3%81%84%E3%80%82)
^ja-Q0936-answer

**ja-Q0937** — この用紙を保険会社に郵送してください。

Please mail this form to your insurance company.

Expected form: **ください**

Why: Polite requests. [[Japanese#^ja-Q0937|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%93%E3%81%AE%E7%94%A8%E7%B4%99%E3%82%92%E4%BF%9D%E9%99%BA%E4%BC%9A%E7%A4%BE%E3%81%AB%E9%83%B5%E9%80%81%E3%81%97%E3%81%A6%E3%81%8F%E3%81%A0%E3%81%95%E3%81%84%E3%80%82)
^ja-Q0937-answer

**ja-Q0938** — この用紙を保険会社に郵送してください。

Please mail this form to your insurance company.

Expected form: **ください**

Why: Polite requests. [[Japanese#^ja-Q0938|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%93%E3%81%AE%E7%94%A8%E7%B4%99%E3%82%92%E4%BF%9D%E9%99%BA%E4%BC%9A%E7%A4%BE%E3%81%AB%E9%83%B5%E9%80%81%E3%81%97%E3%81%A6%E3%81%8F%E3%81%A0%E3%81%95%E3%81%84%E3%80%82)
^ja-Q0938-answer

**ja-Q0939** — 万一あなたの身に何か起これば、すぐに私たちに知らせてください。

Should anything happen to you, let us know at once.

Expected form: **ください**

Why: Polite requests. [[Japanese#^ja-Q0939|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E4%B8%87%E4%B8%80%E3%81%82%E3%81%AA%E3%81%9F%E3%81%AE%E8%BA%AB%E3%81%AB%E4%BD%95%E3%81%8B%E8%B5%B7%E3%81%93%E3%82%8C%E3%81%B0%E3%80%81%E3%81%99%E3%81%90%E3%81%AB%E7%A7%81%E3%81%9F%E3%81%A1%E3%81%AB%E7%9F%A5%E3%82%89%E3%81%9B%E3%81%A6%E3%81%8F%E3%81%A0%E3%81%95%E3%81%84%E3%80%82)
^ja-Q0939-answer

**ja-Q0940** — 万一あなたの身に何か起これば、すぐに私たちに知らせてください。

Should anything happen to you, let us know at once.

Why: Polite requests. [[Japanese#^ja-Q0940|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E4%B8%87%E4%B8%80%E3%81%82%E3%81%AA%E3%81%9F%E3%81%AE%E8%BA%AB%E3%81%AB%E4%BD%95%E3%81%8B%E8%B5%B7%E3%81%93%E3%82%8C%E3%81%B0%E3%80%81%E3%81%99%E3%81%90%E3%81%AB%E7%A7%81%E3%81%9F%E3%81%A1%E3%81%AB%E7%9F%A5%E3%82%89%E3%81%9B%E3%81%A6%E3%81%8F%E3%81%A0%E3%81%95%E3%81%84%E3%80%82)
^ja-Q0940-answer

**ja-Q0941** — すみませんが、２～３分時間をさいていただけませんか。お願いがあるんです。

Excuse me, could you spare me a few minutes? I have a favor to ask you.

Why: Polite requests. [[Japanese#^ja-Q0941|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%99%E3%81%BF%E3%81%BE%E3%81%9B%E3%82%93%E3%81%8C%E3%80%81%EF%BC%92%EF%BD%9E%EF%BC%93%E5%88%86%E6%99%82%E9%96%93%E3%82%92%E3%81%95%E3%81%84%E3%81%A6%E3%81%84%E3%81%9F%E3%81%A0%E3%81%91%E3%81%BE%E3%81%9B%E3%82%93%E3%81%8B%E3%80%82%E3%81%8A%E9%A1%98%E3%81%84%E3%81%8C%E3%81%82%E3%82%8B%E3%82%93%E3%81%A7%E3%81%99%E3%80%82)
^ja-Q0941-answer

**ja-Q0942** — すみませんが、２～３分時間をさいていただけませんか。お願いがあるんです。

Excuse me, could you spare me a few minutes? I have a favor to ask you.

Politeness depends on the entire construction and social relationship. Honorific and humble forms orient differently to whose action is described; they are not merely longer synonyms.

Why: Polite requests. [[Japanese#^ja-Q0942|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%99%E3%81%BF%E3%81%BE%E3%81%9B%E3%82%93%E3%81%8C%E3%80%81%EF%BC%92%EF%BD%9E%EF%BC%93%E5%88%86%E6%99%82%E9%96%93%E3%82%92%E3%81%95%E3%81%84%E3%81%A6%E3%81%84%E3%81%9F%E3%81%A0%E3%81%91%E3%81%BE%E3%81%9B%E3%82%93%E3%81%8B%E3%80%82%E3%81%8A%E9%A1%98%E3%81%84%E3%81%8C%E3%81%82%E3%82%8B%E3%82%93%E3%81%A7%E3%81%99%E3%80%82)
^ja-Q0942-answer

**ja-Q0943** — 切符を見せてください。

Please show your ticket.

Expected form: **ください**

Why: Polite requests. [[Japanese#^ja-Q0943|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%88%87%E7%AC%A6%E3%82%92%E8%A6%8B%E3%81%9B%E3%81%A6%E3%81%8F%E3%81%A0%E3%81%95%E3%81%84%E3%80%82)
^ja-Q0943-answer

**ja-Q0944** — 切符を見せてください。

Please show your ticket.

Expected form: **ください**

Why: Polite requests. [[Japanese#^ja-Q0944|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%88%87%E7%AC%A6%E3%82%92%E8%A6%8B%E3%81%9B%E3%81%A6%E3%81%8F%E3%81%A0%E3%81%95%E3%81%84%E3%80%82)
^ja-Q0944-answer

**ja-Q0945** — 鏡を割らないでください。

Don't break a mirror.

Expected form: **ください**

Why: Polite requests. [[Japanese#^ja-Q0945|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E9%8F%A1%E3%82%92%E5%89%B2%E3%82%89%E3%81%AA%E3%81%84%E3%81%A7%E3%81%8F%E3%81%A0%E3%81%95%E3%81%84%E3%80%82)
^ja-Q0945-answer

**ja-Q0946** — 鏡を割らないでください。

Don't break a mirror.

Why: Polite requests. [[Japanese#^ja-Q0946|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E9%8F%A1%E3%82%92%E5%89%B2%E3%82%89%E3%81%AA%E3%81%84%E3%81%A7%E3%81%8F%E3%81%A0%E3%81%95%E3%81%84%E3%80%82)
^ja-Q0946-answer

**ja-Q0947** — この近辺では窃盗犯に警戒してください。

Watch out for thieves around here.

Why: Polite requests. [[Japanese#^ja-Q0947|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%93%E3%81%AE%E8%BF%91%E8%BE%BA%E3%81%A7%E3%81%AF%E7%AA%83%E7%9B%97%E7%8A%AF%E3%81%AB%E8%AD%A6%E6%88%92%E3%81%97%E3%81%A6%E3%81%8F%E3%81%A0%E3%81%95%E3%81%84%E3%80%82)
^ja-Q0947-answer

**ja-Q0948** — この近辺では窃盗犯に警戒してください。

Watch out for thieves around here.

Politeness depends on the entire construction and social relationship. Honorific and humble forms orient differently to whose action is described; they are not merely longer synonyms.

Why: Polite requests. [[Japanese#^ja-Q0948|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%93%E3%81%AE%E8%BF%91%E8%BE%BA%E3%81%A7%E3%81%AF%E7%AA%83%E7%9B%97%E7%8A%AF%E3%81%AB%E8%AD%A6%E6%88%92%E3%81%97%E3%81%A6%E3%81%8F%E3%81%A0%E3%81%95%E3%81%84%E3%80%82)
^ja-Q0948-answer

**ja-Q0949** — 紅茶をいただけますか。

Could you get me some tea?

Expected form: **いただけ**

Why: Polite requests. [[Japanese#^ja-Q0949|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%B4%85%E8%8C%B6%E3%82%92%E3%81%84%E3%81%9F%E3%81%A0%E3%81%91%E3%81%BE%E3%81%99%E3%81%8B%E3%80%82)
^ja-Q0949-answer

**ja-Q0950** — 紅茶をいただけますか。

Could you get me some tea?

Expected form: **いただけ**

Why: Polite requests. [[Japanese#^ja-Q0950|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%B4%85%E8%8C%B6%E3%82%92%E3%81%84%E3%81%9F%E3%81%A0%E3%81%91%E3%81%BE%E3%81%99%E3%81%8B%E3%80%82)
^ja-Q0950-answer


### Answers 951–1000

**ja-Q0951** — 現在はどちらにお住まいですか。

Where do you live now?

Expected form: **か**

Why: Questions and stance. [[Japanese#^ja-Q0951|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%8F%BE%E5%9C%A8%E3%81%AF%E3%81%A9%E3%81%A1%E3%82%89%E3%81%AB%E3%81%8A%E4%BD%8F%E3%81%BE%E3%81%84%E3%81%A7%E3%81%99%E3%81%8B%E3%80%82)
^ja-Q0951-answer

**ja-Q0952** — 現在はどちらにお住まいですか。

Where do you live now?

Why: Questions and stance. [[Japanese#^ja-Q0952|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%8F%BE%E5%9C%A8%E3%81%AF%E3%81%A9%E3%81%A1%E3%82%89%E3%81%AB%E3%81%8A%E4%BD%8F%E3%81%BE%E3%81%84%E3%81%A7%E3%81%99%E3%81%8B%E3%80%82)
^ja-Q0952-answer

**ja-Q0953** — 風呂場はどこですか。

Where is the bathroom?

Why: Questions and stance. [[Japanese#^ja-Q0953|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E9%A2%A8%E5%91%82%E5%A0%B4%E3%81%AF%E3%81%A9%E3%81%93%E3%81%A7%E3%81%99%E3%81%8B%E3%80%82)
^ja-Q0953-answer

**ja-Q0954** — 風呂場はどこですか。

Where is the bathroom?

か can mark a question or embed one; でしょう and かもしれない express stance at different strengths. A cautious inference does not have the same force as a factual assertion.

Why: Questions and stance. [[Japanese#^ja-Q0954|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E9%A2%A8%E5%91%82%E5%A0%B4%E3%81%AF%E3%81%A9%E3%81%93%E3%81%A7%E3%81%99%E3%81%8B%E3%80%82)
^ja-Q0954-answer

**ja-Q0955** — ジュディは明日日本について話をするでしょう。

Judy will talk about Japan tomorrow.

Expected form: **でしょう**

Why: Questions and stance. [[Japanese#^ja-Q0955|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%82%B8%E3%83%A5%E3%83%87%E3%82%A3%E3%81%AF%E6%98%8E%E6%97%A5%E6%97%A5%E6%9C%AC%E3%81%AB%E3%81%A4%E3%81%84%E3%81%A6%E8%A9%B1%E3%82%92%E3%81%99%E3%82%8B%E3%81%A7%E3%81%97%E3%82%87%E3%81%86%E3%80%82)
^ja-Q0955-answer

**ja-Q0956** — ジュディは明日日本について話をするでしょう。

Judy will talk about Japan tomorrow.

Expected form: **でしょう**

Why: Questions and stance. [[Japanese#^ja-Q0956|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%82%B8%E3%83%A5%E3%83%87%E3%82%A3%E3%81%AF%E6%98%8E%E6%97%A5%E6%97%A5%E6%9C%AC%E3%81%AB%E3%81%A4%E3%81%84%E3%81%A6%E8%A9%B1%E3%82%92%E3%81%99%E3%82%8B%E3%81%A7%E3%81%97%E3%82%87%E3%81%86%E3%80%82)
^ja-Q0956-answer

**ja-Q0957** — 試験はうまくいったと思う。

I think my exam went well.

Expected form: **と思う**

Why: Questions and stance. [[Japanese#^ja-Q0957|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E8%A9%A6%E9%A8%93%E3%81%AF%E3%81%86%E3%81%BE%E3%81%8F%E3%81%84%E3%81%A3%E3%81%9F%E3%81%A8%E6%80%9D%E3%81%86%E3%80%82)
^ja-Q0957-answer

**ja-Q0958** — 試験はうまくいったと思う。

I think my exam went well.

Why: Questions and stance. [[Japanese#^ja-Q0958|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E8%A9%A6%E9%A8%93%E3%81%AF%E3%81%86%E3%81%BE%E3%81%8F%E3%81%84%E3%81%A3%E3%81%9F%E3%81%A8%E6%80%9D%E3%81%86%E3%80%82)
^ja-Q0958-answer

**ja-Q0959** — どんな天気ですか。

How's the weather?

Why: Questions and stance. [[Japanese#^ja-Q0959|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%A9%E3%82%93%E3%81%AA%E5%A4%A9%E6%B0%97%E3%81%A7%E3%81%99%E3%81%8B%E3%80%82)
^ja-Q0959-answer

**ja-Q0960** — どんな天気ですか。

How's the weather?

か can mark a question or embed one; でしょう and かもしれない express stance at different strengths. A cautious inference does not have the same force as a factual assertion.

Why: Questions and stance. [[Japanese#^ja-Q0960|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%A9%E3%82%93%E3%81%AA%E5%A4%A9%E6%B0%97%E3%81%A7%E3%81%99%E3%81%8B%E3%80%82)
^ja-Q0960-answer

**ja-Q0961** — 雑誌を持ってきましょうか。

Shall I bring a magazine?

Expected form: **か**

Why: Questions and stance. [[Japanese#^ja-Q0961|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E9%9B%91%E8%AA%8C%E3%82%92%E6%8C%81%E3%81%A3%E3%81%A6%E3%81%8D%E3%81%BE%E3%81%97%E3%82%87%E3%81%86%E3%81%8B%E3%80%82)
^ja-Q0961-answer

**ja-Q0962** — 雑誌を持ってきましょうか。

Shall I bring a magazine?

Expected form: **か**

Why: Questions and stance. [[Japanese#^ja-Q0962|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E9%9B%91%E8%AA%8C%E3%82%92%E6%8C%81%E3%81%A3%E3%81%A6%E3%81%8D%E3%81%BE%E3%81%97%E3%82%87%E3%81%86%E3%81%8B%E3%80%82)
^ja-Q0962-answer

**ja-Q0963** — 最悪のシナリオは何ですか?

What's the worst case scenario?

Expected form: **か**

Why: Questions and stance. [[Japanese#^ja-Q0963|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%9C%80%E6%82%AA%E3%81%AE%E3%82%B7%E3%83%8A%E3%83%AA%E3%82%AA%E3%81%AF%E4%BD%95%E3%81%A7%E3%81%99%E3%81%8B%3F)
^ja-Q0963-answer

**ja-Q0964** — 最悪のシナリオは何ですか?

What's the worst case scenario?

Why: Questions and stance. [[Japanese#^ja-Q0964|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%9C%80%E6%82%AA%E3%81%AE%E3%82%B7%E3%83%8A%E3%83%AA%E3%82%AA%E3%81%AF%E4%BD%95%E3%81%A7%E3%81%99%E3%81%8B%3F)
^ja-Q0964-answer

**ja-Q0965** — トムはトマトが好きですか。

Does Tom like tomatoes?

Why: Questions and stance. [[Japanese#^ja-Q0965|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%83%88%E3%83%A0%E3%81%AF%E3%83%88%E3%83%9E%E3%83%88%E3%81%8C%E5%A5%BD%E3%81%8D%E3%81%A7%E3%81%99%E3%81%8B%E3%80%82)
^ja-Q0965-answer

**ja-Q0966** — トムはトマトが好きですか。

Does Tom like tomatoes?

か can mark a question or embed one; でしょう and かもしれない express stance at different strengths. A cautious inference does not have the same force as a factual assertion.

Why: Questions and stance. [[Japanese#^ja-Q0966|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%83%88%E3%83%A0%E3%81%AF%E3%83%88%E3%83%9E%E3%83%88%E3%81%8C%E5%A5%BD%E3%81%8D%E3%81%A7%E3%81%99%E3%81%8B%E3%80%82)
^ja-Q0966-answer

**ja-Q0967** — 時刻表をお持ちですか。

Do you have a timetable?

Expected form: **か**

Why: Questions and stance. [[Japanese#^ja-Q0967|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%99%82%E5%88%BB%E8%A1%A8%E3%82%92%E3%81%8A%E6%8C%81%E3%81%A1%E3%81%A7%E3%81%99%E3%81%8B%E3%80%82)
^ja-Q0967-answer

**ja-Q0968** — 時刻表をお持ちですか。

Do you have a timetable?

Expected form: **か**

Why: Questions and stance. [[Japanese#^ja-Q0968|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E6%99%82%E5%88%BB%E8%A1%A8%E3%82%92%E3%81%8A%E6%8C%81%E3%81%A1%E3%81%A7%E3%81%99%E3%81%8B%E3%80%82)
^ja-Q0968-answer

**ja-Q0969** — まもなく暗くなるでしょう。

It will be dark soon.

Expected form: **でしょう**

Why: Questions and stance. [[Japanese#^ja-Q0969|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%BE%E3%82%82%E3%81%AA%E3%81%8F%E6%9A%97%E3%81%8F%E3%81%AA%E3%82%8B%E3%81%A7%E3%81%97%E3%82%87%E3%81%86%E3%80%82)
^ja-Q0969-answer

**ja-Q0970** — まもなく暗くなるでしょう。

It will be dark soon.

Why: Questions and stance. [[Japanese#^ja-Q0970|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%BE%E3%82%82%E3%81%AA%E3%81%8F%E6%9A%97%E3%81%8F%E3%81%AA%E3%82%8B%E3%81%A7%E3%81%97%E3%82%87%E3%81%86%E3%80%82)
^ja-Q0970-answer

**ja-Q0971** — 少し、出しゃばりすぎると思わないか。

Don't you think you are a little too pushy?

Why: Questions and stance. [[Japanese#^ja-Q0971|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%B0%91%E3%81%97%E3%80%81%E5%87%BA%E3%81%97%E3%82%83%E3%81%B0%E3%82%8A%E3%81%99%E3%81%8E%E3%82%8B%E3%81%A8%E6%80%9D%E3%82%8F%E3%81%AA%E3%81%84%E3%81%8B%E3%80%82)
^ja-Q0971-answer

**ja-Q0972** — 少し、出しゃばりすぎると思わないか。

Don't you think you are a little too pushy?

か can mark a question or embed one; でしょう and かもしれない express stance at different strengths. A cautious inference does not have the same force as a factual assertion.

Why: Questions and stance. [[Japanese#^ja-Q0972|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%B0%91%E3%81%97%E3%80%81%E5%87%BA%E3%81%97%E3%82%83%E3%81%B0%E3%82%8A%E3%81%99%E3%81%8E%E3%82%8B%E3%81%A8%E6%80%9D%E3%82%8F%E3%81%AA%E3%81%84%E3%81%8B%E3%80%82)
^ja-Q0972-answer

**ja-Q0973** — 私はあなたは母親似だと思う。

I think you resemble your mother.

Expected form: **と思う**

Why: Questions and stance. [[Japanese#^ja-Q0973|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AF%E3%81%82%E3%81%AA%E3%81%9F%E3%81%AF%E6%AF%8D%E8%A6%AA%E4%BC%BC%E3%81%A0%E3%81%A8%E6%80%9D%E3%81%86%E3%80%82)
^ja-Q0973-answer

**ja-Q0974** — 私はあなたは母親似だと思う。

I think you resemble your mother.

Expected form: **と思う**

Why: Questions and stance. [[Japanese#^ja-Q0974|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E7%A7%81%E3%81%AF%E3%81%82%E3%81%AA%E3%81%9F%E3%81%AF%E6%AF%8D%E8%A6%AA%E4%BC%BC%E3%81%A0%E3%81%A8%E6%80%9D%E3%81%86%E3%80%82)
^ja-Q0974-answer

**ja-Q0975** — 傘をお借りしてもいいですか？

Could I borrow an umbrella?

Expected form: **か**

Why: Questions and stance. [[Japanese#^ja-Q0975|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%82%98%E3%82%92%E3%81%8A%E5%80%9F%E3%82%8A%E3%81%97%E3%81%A6%E3%82%82%E3%81%84%E3%81%84%E3%81%A7%E3%81%99%E3%81%8B%EF%BC%9F)
^ja-Q0975-answer

**ja-Q0976** — 傘をお借りしてもいいですか？

Could I borrow an umbrella?

Why: Questions and stance. [[Japanese#^ja-Q0976|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%82%98%E3%82%92%E3%81%8A%E5%80%9F%E3%82%8A%E3%81%97%E3%81%A6%E3%82%82%E3%81%84%E3%81%84%E3%81%A7%E3%81%99%E3%81%8B%EF%BC%9F)
^ja-Q0976-answer

**ja-Q0977** — 韓国語はどこで学べますか？

Where can I learn Korean?

Why: Questions and stance. [[Japanese#^ja-Q0977|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E9%9F%93%E5%9B%BD%E8%AA%9E%E3%81%AF%E3%81%A9%E3%81%93%E3%81%A7%E5%AD%A6%E3%81%B9%E3%81%BE%E3%81%99%E3%81%8B%EF%BC%9F)
^ja-Q0977-answer

**ja-Q0978** — 韓国語はどこで学べますか？

Where can I learn Korean?

か can mark a question or embed one; でしょう and かもしれない express stance at different strengths. A cautious inference does not have the same force as a factual assertion.

Why: Questions and stance. [[Japanese#^ja-Q0978|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E9%9F%93%E5%9B%BD%E8%AA%9E%E3%81%AF%E3%81%A9%E3%81%93%E3%81%A7%E5%AD%A6%E3%81%B9%E3%81%BE%E3%81%99%E3%81%8B%EF%BC%9F)
^ja-Q0978-answer

**ja-Q0979** — 彼は正直だと思う。

I think he is honest.

Expected form: **と思う**

Why: Questions and stance. [[Japanese#^ja-Q0979|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%AF%E6%AD%A3%E7%9B%B4%E3%81%A0%E3%81%A8%E6%80%9D%E3%81%86%E3%80%82)
^ja-Q0979-answer

**ja-Q0980** — 彼は正直だと思う。

I think he is honest.

Expected form: **と思う**

Why: Questions and stance. [[Japanese#^ja-Q0980|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%AF%E6%AD%A3%E7%9B%B4%E3%81%A0%E3%81%A8%E6%80%9D%E3%81%86%E3%80%82)
^ja-Q0980-answer

**ja-Q0981** — メグもパーティーに呼びましょうか。

How about inviting Meg to the party?

Expected form: **か**

Why: Questions and stance. [[Japanese#^ja-Q0981|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%83%A1%E3%82%B0%E3%82%82%E3%83%91%E3%83%BC%E3%83%86%E3%82%A3%E3%83%BC%E3%81%AB%E5%91%BC%E3%81%B3%E3%81%BE%E3%81%97%E3%82%87%E3%81%86%E3%81%8B%E3%80%82)
^ja-Q0981-answer

**ja-Q0982** — メグもパーティーに呼びましょうか。

How about inviting Meg to the party?

Why: Questions and stance. [[Japanese#^ja-Q0982|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%83%A1%E3%82%B0%E3%82%82%E3%83%91%E3%83%BC%E3%83%86%E3%82%A3%E3%83%BC%E3%81%AB%E5%91%BC%E3%81%B3%E3%81%BE%E3%81%97%E3%82%87%E3%81%86%E3%81%8B%E3%80%82)
^ja-Q0982-answer

**ja-Q0983** — 一体全体、きみはそれをどうしようと言うつもりなのか。

What the hell are you going to do with it?

Why: Questions and stance. [[Japanese#^ja-Q0983|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E4%B8%80%E4%BD%93%E5%85%A8%E4%BD%93%E3%80%81%E3%81%8D%E3%81%BF%E3%81%AF%E3%81%9D%E3%82%8C%E3%82%92%E3%81%A9%E3%81%86%E3%81%97%E3%82%88%E3%81%86%E3%81%A8%E8%A8%80%E3%81%86%E3%81%A4%E3%82%82%E3%82%8A%E3%81%AA%E3%81%AE%E3%81%8B%E3%80%82)
^ja-Q0983-answer

**ja-Q0984** — 一体全体、きみはそれをどうしようと言うつもりなのか。

What the hell are you going to do with it?

か can mark a question or embed one; でしょう and かもしれない express stance at different strengths. A cautious inference does not have the same force as a factual assertion.

Why: Questions and stance. [[Japanese#^ja-Q0984|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E4%B8%80%E4%BD%93%E5%85%A8%E4%BD%93%E3%80%81%E3%81%8D%E3%81%BF%E3%81%AF%E3%81%9D%E3%82%8C%E3%82%92%E3%81%A9%E3%81%86%E3%81%97%E3%82%88%E3%81%86%E3%81%A8%E8%A8%80%E3%81%86%E3%81%A4%E3%82%82%E3%82%8A%E3%81%AA%E3%81%AE%E3%81%8B%E3%80%82)
^ja-Q0984-answer

**ja-Q0985** — これは本当ですか。

Is this true?

Expected form: **か**

Why: Questions and stance. [[Japanese#^ja-Q0985|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%93%E3%82%8C%E3%81%AF%E6%9C%AC%E5%BD%93%E3%81%A7%E3%81%99%E3%81%8B%E3%80%82)
^ja-Q0985-answer

**ja-Q0986** — これは本当ですか。

Is this true?

Expected form: **か**

Why: Questions and stance. [[Japanese#^ja-Q0986|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%93%E3%82%8C%E3%81%AF%E6%9C%AC%E5%BD%93%E3%81%A7%E3%81%99%E3%81%8B%E3%80%82)
^ja-Q0986-answer

**ja-Q0987** — 今学期は政治学を取っていますか。

Are you taking politics this semester?

Expected form: **か**

Why: Questions and stance. [[Japanese#^ja-Q0987|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E4%BB%8A%E5%AD%A6%E6%9C%9F%E3%81%AF%E6%94%BF%E6%B2%BB%E5%AD%A6%E3%82%92%E5%8F%96%E3%81%A3%E3%81%A6%E3%81%84%E3%81%BE%E3%81%99%E3%81%8B%E3%80%82)
^ja-Q0987-answer

**ja-Q0988** — 今学期は政治学を取っていますか。

Are you taking politics this semester?

Why: Questions and stance. [[Japanese#^ja-Q0988|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E4%BB%8A%E5%AD%A6%E6%9C%9F%E3%81%AF%E6%94%BF%E6%B2%BB%E5%AD%A6%E3%82%92%E5%8F%96%E3%81%A3%E3%81%A6%E3%81%84%E3%81%BE%E3%81%99%E3%81%8B%E3%80%82)
^ja-Q0988-answer

**ja-Q0989** — あなたはふつう朝食に紅茶を飲みますか。

Do you usually have tea for breakfast?

Why: Questions and stance. [[Japanese#^ja-Q0989|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%82%E3%81%AA%E3%81%9F%E3%81%AF%E3%81%B5%E3%81%A4%E3%81%86%E6%9C%9D%E9%A3%9F%E3%81%AB%E7%B4%85%E8%8C%B6%E3%82%92%E9%A3%B2%E3%81%BF%E3%81%BE%E3%81%99%E3%81%8B%E3%80%82)
^ja-Q0989-answer

**ja-Q0990** — あなたはふつう朝食に紅茶を飲みますか。

Do you usually have tea for breakfast?

か can mark a question or embed one; でしょう and かもしれない express stance at different strengths. A cautious inference does not have the same force as a factual assertion.

Why: Questions and stance. [[Japanese#^ja-Q0990|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%82%E3%81%AA%E3%81%9F%E3%81%AF%E3%81%B5%E3%81%A4%E3%81%86%E6%9C%9D%E9%A3%9F%E3%81%AB%E7%B4%85%E8%8C%B6%E3%82%92%E9%A3%B2%E3%81%BF%E3%81%BE%E3%81%99%E3%81%8B%E3%80%82)
^ja-Q0990-answer

**ja-Q0991** — どうして煙草を止める決心をしたのですか。

What made up your mind to quit smoking?

Expected form: **か**

Why: Questions and stance. [[Japanese#^ja-Q0991|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%A9%E3%81%86%E3%81%97%E3%81%A6%E7%85%99%E8%8D%89%E3%82%92%E6%AD%A2%E3%82%81%E3%82%8B%E6%B1%BA%E5%BF%83%E3%82%92%E3%81%97%E3%81%9F%E3%81%AE%E3%81%A7%E3%81%99%E3%81%8B%E3%80%82)
^ja-Q0991-answer

**ja-Q0992** — どうして煙草を止める決心をしたのですか。

What made up your mind to quit smoking?

Expected form: **か**

Why: Questions and stance. [[Japanese#^ja-Q0992|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%A9%E3%81%86%E3%81%97%E3%81%A6%E7%85%99%E8%8D%89%E3%82%92%E6%AD%A2%E3%82%81%E3%82%8B%E6%B1%BA%E5%BF%83%E3%82%92%E3%81%97%E3%81%9F%E3%81%AE%E3%81%A7%E3%81%99%E3%81%8B%E3%80%82)
^ja-Q0992-answer

**ja-Q0993** — 友人は空港へ見送りに来るのですか。

Will your friends be seeing you off at the airport?

Expected form: **か**

Why: Questions and stance. [[Japanese#^ja-Q0993|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%8F%8B%E4%BA%BA%E3%81%AF%E7%A9%BA%E6%B8%AF%E3%81%B8%E8%A6%8B%E9%80%81%E3%82%8A%E3%81%AB%E6%9D%A5%E3%82%8B%E3%81%AE%E3%81%A7%E3%81%99%E3%81%8B%E3%80%82)
^ja-Q0993-answer

**ja-Q0994** — 友人は空港へ見送りに来るのですか。

Will your friends be seeing you off at the airport?

Why: Questions and stance. [[Japanese#^ja-Q0994|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%8F%8B%E4%BA%BA%E3%81%AF%E7%A9%BA%E6%B8%AF%E3%81%B8%E8%A6%8B%E9%80%81%E3%82%8A%E3%81%AB%E6%9D%A5%E3%82%8B%E3%81%AE%E3%81%A7%E3%81%99%E3%81%8B%E3%80%82)
^ja-Q0994-answer

**ja-Q0995** — つぼにたくさん砂糖が入っていますか。

Is there much sugar in the jar?

Why: Questions and stance. [[Japanese#^ja-Q0995|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%A4%E3%81%BC%E3%81%AB%E3%81%9F%E3%81%8F%E3%81%95%E3%82%93%E7%A0%82%E7%B3%96%E3%81%8C%E5%85%A5%E3%81%A3%E3%81%A6%E3%81%84%E3%81%BE%E3%81%99%E3%81%8B%E3%80%82)
^ja-Q0995-answer

**ja-Q0996** — つぼにたくさん砂糖が入っていますか。

Is there much sugar in the jar?

か can mark a question or embed one; でしょう and かもしれない express stance at different strengths. A cautious inference does not have the same force as a factual assertion.

Why: Questions and stance. [[Japanese#^ja-Q0996|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%A4%E3%81%BC%E3%81%AB%E3%81%9F%E3%81%8F%E3%81%95%E3%82%93%E7%A0%82%E7%B3%96%E3%81%8C%E5%85%A5%E3%81%A3%E3%81%A6%E3%81%84%E3%81%BE%E3%81%99%E3%81%8B%E3%80%82)
^ja-Q0996-answer

**ja-Q0997** — あなたの所属は何部ですか？

What club do you belong to?

Expected form: **か**

Why: Questions and stance. [[Japanese#^ja-Q0997|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%82%E3%81%AA%E3%81%9F%E3%81%AE%E6%89%80%E5%B1%9E%E3%81%AF%E4%BD%95%E9%83%A8%E3%81%A7%E3%81%99%E3%81%8B%EF%BC%9F)
^ja-Q0997-answer

**ja-Q0998** — あなたの所属は何部ですか？

What club do you belong to?

Expected form: **か**

Why: Questions and stance. [[Japanese#^ja-Q0998|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E3%81%82%E3%81%AA%E3%81%9F%E3%81%AE%E6%89%80%E5%B1%9E%E3%81%AF%E4%BD%95%E9%83%A8%E3%81%A7%E3%81%99%E3%81%8B%EF%BC%9F)
^ja-Q0998-answer

**ja-Q0999** — 彼は四時にもどるでしょう。

He will come back at four.

Expected form: **でしょう**

Why: Questions and stance. [[Japanese#^ja-Q0999|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%AF%E5%9B%9B%E6%99%82%E3%81%AB%E3%82%82%E3%81%A9%E3%82%8B%E3%81%A7%E3%81%97%E3%82%87%E3%81%86%E3%80%82)
^ja-Q0999-answer

**ja-Q1000** — 彼は四時にもどるでしょう。

He will come back at four.

Why: Questions and stance. [[Japanese#^ja-Q1000|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=jpn&query=%E5%BD%BC%E3%81%AF%E5%9B%9B%E6%99%82%E3%81%AB%E3%82%82%E3%81%A9%E3%82%8B%E3%81%A7%E3%81%97%E3%82%87%E3%81%86%E3%80%82)
^ja-Q1000-answer


## Read and speak

Read the native sentence first, identify its predicate and one grammar form, then check the translation. Say it aloud and change one detail.

### Learning with a clear purpose

新しい言語を勉強しています。毎日、短い文章を読んで、分かりやすい例を聞きます。役に立つ単語をノートに書きます。間違えたら、文法のルールを確認して、もう一度やってみます。目標は、人の話を理解し、自分の考えをはっきり伝えることです。

I am learning a new language. Each day, I read a short text and listen to clear examples. I write useful words in a notebook. When I make a mistake, I check the rule and try again. My goal is to understand people and express my ideas clearly.

![[Resources/Audio/ja/Reading passage.mp3]]

**パーティーに行かない。**

I'm not going to go to the party.

**彼女は無邪気なふりをした。**

She pretended innocence.

**私は息子に芝生に水を撒かせた。**

I had my son water the lawn.

**彼らはクリスマスイブに教会に行った。**

They went to church on Christmas Eve.

**年とともに、情熱は弱まり、習慣は強くなる。**

Passions weaken, but habits strengthen, with age.

**その女性は悲しげで、その上疲れているようだった。**

The lady looked sad, also tired.

**年会費はいくらですか。**

How much is the annual membership fee?

**彼は何らかの解決策を提案しましたか。**

Did he propose any solutions?

**お留守中の猫の世話をして上げましょう。**

While they are away, let's take care of their cat.

**彼がもう少し注意していれば、事故は防げたろうに。**

If he had been a little more careful, the accident would have been avoided.

**怒鳴りつけたかったが思いとどまった。**

He was about to explode, but checked himself.

**明日買い物に行きます。**

I'm going shopping tomorrow.

**もっと時間をかけて発表を準備すべきだったと先生に言われた。**

My teacher told me that I should have spent more time preparing my presentation.

**手紙を書く際の最善の方法は、心にあることを何でも書き留めることだ。**

The best way to write letters is to put down whatever is in your mind.

**彼女の息子は交通事故で死んだ。**

Her son was killed in a traffic accident.

## Professional writing

Write an introduction, a polite request, an explanation of a finding, a summary of a passage and a tactful disagreement. Use the professional/advanced lessons for models.

## PDF edition

[[Resources/PDFs/Japanese.pdf|Open the complete printable book]]


<!-- individual-letter-audio -->
## Hear each letter separately

Play each letter’s own synthetic recording. English has separate US and UK models.

### あ · a

![[Resources/Audio/ja/Letters/001.mp3]]

### い · i

![[Resources/Audio/ja/Letters/002.mp3]]

### う · u

![[Resources/Audio/ja/Letters/003.mp3]]

### え · e

![[Resources/Audio/ja/Letters/004.mp3]]

### お · o

![[Resources/Audio/ja/Letters/005.mp3]]

### か · ka

![[Resources/Audio/ja/Letters/006.mp3]]

### き · ki

![[Resources/Audio/ja/Letters/007.mp3]]

### く · ku

![[Resources/Audio/ja/Letters/008.mp3]]

### け · ke

![[Resources/Audio/ja/Letters/009.mp3]]

### こ · ko

![[Resources/Audio/ja/Letters/010.mp3]]

### さ · sa

![[Resources/Audio/ja/Letters/011.mp3]]

### し · shi

![[Resources/Audio/ja/Letters/012.mp3]]

### す · su

![[Resources/Audio/ja/Letters/013.mp3]]

### せ · se

![[Resources/Audio/ja/Letters/014.mp3]]

### そ · so

![[Resources/Audio/ja/Letters/015.mp3]]

### た · ta

![[Resources/Audio/ja/Letters/016.mp3]]

### ち · chi

![[Resources/Audio/ja/Letters/017.mp3]]

### つ · tsu

![[Resources/Audio/ja/Letters/018.mp3]]

### て · te

![[Resources/Audio/ja/Letters/019.mp3]]

### と · to

![[Resources/Audio/ja/Letters/020.mp3]]

### な · na

![[Resources/Audio/ja/Letters/021.mp3]]

### に · ni

![[Resources/Audio/ja/Letters/022.mp3]]

### ぬ · nu

![[Resources/Audio/ja/Letters/023.mp3]]

### ね · ne

![[Resources/Audio/ja/Letters/024.mp3]]

### の · no

![[Resources/Audio/ja/Letters/025.mp3]]

### は · ha

![[Resources/Audio/ja/Letters/026.mp3]]

### ひ · hi

![[Resources/Audio/ja/Letters/027.mp3]]

### ふ · fu

![[Resources/Audio/ja/Letters/028.mp3]]

### へ · he

![[Resources/Audio/ja/Letters/029.mp3]]

### ほ · ho

![[Resources/Audio/ja/Letters/030.mp3]]

### ま · ma

![[Resources/Audio/ja/Letters/031.mp3]]

### み · mi

![[Resources/Audio/ja/Letters/032.mp3]]

### む · mu

![[Resources/Audio/ja/Letters/033.mp3]]

### め · me

![[Resources/Audio/ja/Letters/034.mp3]]

### も · mo

![[Resources/Audio/ja/Letters/035.mp3]]

### や · ya

![[Resources/Audio/ja/Letters/036.mp3]]

### ゆ · yu

![[Resources/Audio/ja/Letters/037.mp3]]

### よ · yo

![[Resources/Audio/ja/Letters/038.mp3]]

### ら · ra

![[Resources/Audio/ja/Letters/039.mp3]]

### り · ri

![[Resources/Audio/ja/Letters/040.mp3]]

### る · ru

![[Resources/Audio/ja/Letters/041.mp3]]

### れ · re

![[Resources/Audio/ja/Letters/042.mp3]]

### ろ · ro

![[Resources/Audio/ja/Letters/043.mp3]]

### わ · wa

![[Resources/Audio/ja/Letters/044.mp3]]

### を · o (written wo)

![[Resources/Audio/ja/Letters/045.mp3]]

### ん · n

![[Resources/Audio/ja/Letters/046.mp3]]
<!-- /individual-letter-audio -->
