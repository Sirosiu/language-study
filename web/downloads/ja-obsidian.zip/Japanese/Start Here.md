# Japanese study

[[Japanese|Open the complete Japanese course note]]

Audio and the printable PDF are in Resources. This vault contains one language.

[[Sources and licenses]]
