# Finnish

Professional ambition - C1-oriented study

Everything for this language is in this note. Open a rule, read its examples and follow its practice link. Answers stay in this same note.

[[Start Here|All languages]] · [[Sources and licenses|Sources]]

## Start reading

### aakkoset

| Written form | Name / reading | Related forms |
|---|---|---|
| A a | aa  |  ·  ·  |
| B b | bee  |  ·  ·  |
| C c | see  |  ·  ·  |
| D d | dee  |  ·  ·  |
| E e | ee  |  ·  ·  |
| F f | äf  |  ·  ·  |
| G g | gee  |  ·  ·  |
| H h | hoo  |  ·  ·  |
| I i | ii  |  ·  ·  |
| J j | jii  |  ·  ·  |
| K k | koo  |  ·  ·  |
| L l | äl  |  ·  ·  |
| M m | äm  |  ·  ·  |
| N n | än  |  ·  ·  |
| O o | oo  |  ·  ·  |
| P p | pee  |  ·  ·  |
| Q q | kuu  |  ·  ·  |
| R r | är  |  ·  ·  |
| S s | äs  |  ·  ·  |
| T t | tee  |  ·  ·  |
| U u | uu  |  ·  ·  |
| V v | vee  |  ·  ·  |
| W w | kaksoisvee  |  ·  ·  |
| X x | äks  |  ·  ·  |
| Y y | yy  |  ·  ·  |
| Z z | tseta  |  ·  ·  |
| Å å | ruotsalainen oo  |  ·  ·  |
| Ä ä | ää  |  ·  ·  |
| Ö ö | öö  |  ·  ·  |

![[Resources/Audio/fi/Script and first phrases.mp3]]

The player above is synthetic speech. Word tracks below work offline.

### Letters and sound length

Finnish uses the Latin alphabet with Å, Ä and Ö. Several letters occur mainly in loans and names. Length is meaningful: tuli = fire; tuuli = wind; tulli = customs. A doubled letter represents longer duration, not a second syllable by default.

### Stress and vowels

Primary stress falls on the first syllable. y is a rounded front vowel /y/, ä is /æ/, ö is /ø/. Vowel harmony groups a/o/u against ä/ö/y; e/i are neutral. Suffixes often have back and front variants.

### Read the stem

A dictionary form is not always the stem used before a suffix. Consonant gradation and other changes appear in inflection: kauppa → kaupassa. Learn a small paradigm rather than guessing from the final letter.

### Attach a case ending

talo → talossa → talosta → taloon = house → in the house → out of the house → into the house. These suffixes are part of the word, not separate English prepositions.

### Use vowel harmony

talo + ssa → talossa; kylä + ssä → kylässä = in the village. Neutral vowels normally coexist with either group; compound parts can behave separately.

### Distinguish object meanings

Luen kirjaa. = I am reading a book (ongoing/partial perspective). Luen kirjan. = I will read the book through / read the whole book. Object marking depends on more than definiteness.

**Hyvää huomenta.**

Good morning.

**Opiskelen suomea.**

I study Finnish.

**Voisitko toistaa?**

Could you repeat?

**Mitä tämä sana tarkoittaa?**

What does this word mean?

### Grammar terms in plain English

**Noun** — A word naming a person, thing or idea: student, book, freedom.

**Verb** — A word describing an action or state: read, know, be.

**Subject** — The participant linked to the main verb’s subject pattern. In The student reads a book, the student is the subject.

**Object** — A participant selected by a verb. In The student reads a book, a book is the direct object.

**Agreement** — One word changes to match another, for example an adjective matching a noun’s gender and number.

**Case** — A noun/pronoun form marking its relationship in a sentence. Cases can mark subjects, objects, possession or relations usually expressed by English prepositions.

**Gender** — A grammatical noun class. It does not always describe the sex of a person or any physical property.

**Tense** — A verb system that relates a situation to a time, often past or non-past.

**Aspect** — How a situation is viewed: unfolding, completed, habitual, experienced or in a resulting state.

**Infinitive** — A non-finite verb form often used for a dictionary entry or a complement. It does not by itself give the ordinary person/tense pattern.

**Participle** — A verb-derived form used in compound predicates or as a modifier; its exact function depends on the language and construction.

**Clause** — A unit organised around a predicate. One sentence can contain several clauses.

**Register** — Language choices suited to a situation: casual conversation, polite requests, academic writing or another context.

## Grammar, examples and practice

### Sound, harmony and case stems

Front/back vowel harmony affects many endings; e and i are neutral in the basic system. Long vowels and doubled consonants contrast with short ones. Case formation can change a noun's stem through gradation and other patterns: kauppa/kaupassa. Finnish has many cases, including local cases in series; their labels do not remove lexical government and metaphorical uses.

**talossa / talosta / taloon**

in a house / out of a house / into a house Interior local-case series.

**kauppa / kaupassa**

shop / in a shop Consonant gradation affects the stem.

#### Personal pronouns

Personal pronouns have distinct case forms. Verb endings often identify first/second person, allowing the pronoun to be omitted. Standard hän refers to a person without encoding male/female gender.

**He vaativat taistelulle loppua.**

They called for an end to the fighting.

**Minä olen jo rakastunut sinuun.**

I'm in love with you already.

![[Resources/Audio/fi/Rule 01.mp3]]

[[Finnish#^fi-Q0001|Practise this rule (50 questions)]]

#### Inessive location

Inessive -ssa/-ssä expresses many inside/location relations. Vowel harmony chooses the variant. Words such as missä contain the same case relation in an interrogative form.

**Tomi vietti puolet elämästään Bostonissa.**

Tom lived half his life in Boston.

**Tom vaikutti tuijottavan jotain huoneen nurkassa.**

Tom seemed to be staring at something in the corner of the room.

![[Resources/Audio/fi/Rule 08.mp3]]

[[Finnish#^fi-Q0351|Practise this rule (50 questions)]]

#### Elative source

Elative -sta/-stä expresses movement out of, source and some governed complements. The noun stem may change before the ending. A word’s suffix must be checked against its actual paradigm.

**Ethän kerro tästä kenellekään.**

Please don't tell anybody about this.

**Tomi kadehti Marin menestystä.**

Tom envied Mary's success.

![[Resources/Audio/fi/Rule 09.mp3]]

[[Finnish#^fi-Q0401|Practise this rule (50 questions)]]

#### Allative destination

Allative -lle commonly marks a destination onto/at a surface or a recipient. Pronouns have their own stems. English to can also map to other Finnish cases.

**Tom valehteli sinulle.**

Tom lied to you.

**Kerro minulle siitä!**

Tell me about it!

![[Resources/Audio/fi/Rule 10.mp3]]

[[Finnish#^fi-Q0451|Practise this rule (50 questions)]]

#### Adessive and possession

Adessive marks many surface/location meanings. A possessive construction often uses an adessive possessor plus olla: Minulla on kirja. The possessed noun is not automatically an accusative object.

**Minulla on ollut todella kova päivä.**

I've had a really hard day.

**Sinulla ei ole mitään sanottavaa siitä, vai?**

You don't have anything to say about it, do you?

![[Resources/Audio/fi/Rule 11.mp3]]

[[Finnish#^fi-Q0501|Practise this rule (50 questions)]]

#### Ablative source

Ablative -lta/-ltä commonly expresses movement away from a surface or a source/person. Contrast it with allative destination and adessive location.

**Ne saarelaiset pyytävät meiltä apua.**

The islanders are asking us for help.

**Tom aikoi kysyä sinulta siitä.**

Tom was going to ask you about that.

![[Resources/Audio/fi/Rule 12.mp3]]

[[Finnish#^fi-Q0551|Practise this rule (50 questions)]]

<details><summary>Why learn a noun with several forms?</summary>

The stem can change; endings alone do not predict every form.

</details>

<details><summary>What does vowel/consonant length practice require?</summary>

Meaningful audio contrasts and timed production, not just louder stress.

</details>

### Objects, partitive and boundedness

Finnish object marking depends on negation, quantity and aspectual boundedness. A partitive object often presents an unbounded activity or incomplete quantity; a total object presents a bounded whole under appropriate conditions. Negated objects take partitive in core patterns. Form choice for total objects also depends on sentence construction, so it is not one uniform ending.

**Luen kirjaa.**

I am reading a book. Partitive frames the activity as unbounded.

**Luin kirjan.**

I read the book through. Total object with a bounded reading interpretation.

#### Partitive nouns

Partitive occurs in many quantities, negative objects and ongoing/unbounded object constructions. It is not merely the form for an indefinite English noun. Learn the case stem alongside the nominative.

**Käyn hakemassa vähän kahvia. Haluatko sinäkin?**

I'm going to get myself some coffee. Do you want some?

**Kuinka monta kirjaa luette kuukaudessa?**

How many books do you read a month?

![[Resources/Audio/fi/Rule 06.mp3]]

[[Finnish#^fi-Q0251|Practise this rule (50 questions)]]

#### Genitive singular

Singular genitive often ends in -n with possible stem changes. It can express possession and participates in total-object marking in suitable constructions. The function depends on the sentence.

**Haluan tuon koiran kuvan.**

I want a picture of that dog.

**Ostin uuden auton viime sunnuntaina.**

Last Sunday I bought a new car.

![[Resources/Audio/fi/Rule 07.mp3]]

[[Finnish#^fi-Q0301|Practise this rule (50 questions)]]

#### Quantity and numerals

Many cardinal quantities greater than one take singular partitive of the counted noun. Paljon/vähän interact with countability and case. Do not simply put a plural nominative after every number.

**Tom teki neljä maalia.**

Tom scored four goals.

**Tom osaa puhua vain vähän ranskaa.**

Tom can speak only a little French.

![[Resources/Audio/fi/Rule 18.mp3]]

[[Finnish#^fi-Q0851|Practise this rule (50 questions)]]

<details><summary>Negate Luin kirjan.</summary>

En lukenut kirjaa. Negative auxiliary, past participle and partitive object.

</details>

<details><summary>Is partitive merely an indefinite article?</summary>

No. Quantity, negation and boundedness are central grammatical factors.

</details>

### Verb forms and the negative verb

Finnish negative uses an inflecting negative auxiliary: en, et, ei, emme, ette, eivät. The main verb has a connegative or participial form according to tense. Present and past forms have person marking; perfect uses olla + participle. The conditional -isi- supports hypothetical reasoning and courtesy. Learn verb types with stem changes.

**En tiedä.**

I do not know. First-person negative auxiliary plus connegative main verb.

**Voisitko selittää tämän?**

Could you explain this? Conditional courtesy with question clitic.

#### Present olla

Olla agrees with the subject: olen, olet, on, olemme, olette, ovat. On is also used in many existential or possessive constructions whose syntax differs from a simple subject predicate.

**Kahden kauppa on kolmannen korvapuusti.**

When two people quarrel, a third rejoices.

**Tomi on äreä.**

Tom is grumpy.

![[Resources/Audio/fi/Rule 02.mp3]]

[[Finnish#^fi-Q0051|Practise this rule (50 questions)]]

#### The negative verb

Finnish negation conjugates the negative auxiliary for person and number. The ordinary lexical verb appears in a connegative form: en puhu, et puhu, ei puhu.

**Vannoin, että en puhuisi enää ikinä hänelle.**

I vowed that I would never speak to her again.

**Miksi et ole vielä valmistanut illallista?**

Why haven't you cooked dinner yet?

![[Resources/Audio/fi/Rule 03.mp3]]

[[Finnish#^fi-Q0101|Practise this rule (50 questions)]]

#### Negative imperatives

Älä gives a singular prohibition; älkää a plural/polite one. The following verb has an imperative-compatible form. These are not ordinary present negative auxiliary forms.

**Älä ikinä yritä tehdä tätä itse.**

Don't ever try to do this by yourself.

**Älä unohda laittaa postimerkkejä kirjeisiin, jotka annoin sinulle postitettavaksi.**

Please don't forget to put stamps on the letters I gave you to post.

![[Resources/Audio/fi/Rule 04.mp3]]

[[Finnish#^fi-Q0151|Practise this rule (50 questions)]]

#### Past olla

The past of olla agrees with the subject. It can be a main verb or a perfect/pluperfect auxiliary. Read any accompanying participle before choosing the analysis.

**Mary oli heidän suuri faninsa.**

Mary is a big fan of theirs.

**Huone oli tupaten täynnä.**

The room was packed.

![[Resources/Audio/fi/Rule 05.mp3]]

[[Finnish#^fi-Q0201|Practise this rule (50 questions)]]

#### Conditional forms

The conditional often contains -isi- and can mark hypothetical or polite meanings. Person endings still matter. Pitäisi commonly expresses should/ought in a construction that may require genitive marking.

**Tom olisi voittanut helposti.**

Tom would've won easily.

**Hänen olisi pitänyt pitää suunsa kiinni.**

She should have kept her mouth shut.

![[Resources/Audio/fi/Rule 13.mp3]]

[[Finnish#^fi-Q0601|Practise this rule (50 questions)]]

#### Questions and question particle

Question words inflect for the needed case. The clitic -ko/-kö can turn a focused word into a yes/no question. It follows vowel harmony and can attach to more than verbs.

**Mitä sitä ennen tapahtui?**

What happened before that?

**Meidän täytyy kertoa kaikille mitä tapahtui.**

We have to tell everybody what happened.

![[Resources/Audio/fi/Rule 14.mp3]]

[[Finnish#^fi-Q0651|Practise this rule (50 questions)]]

<details><summary>Change En tiedä to we do not know.</summary>

Emme tiedä. The negative auxiliary carries person/number.

</details>

<details><summary>Why cannot English do not be translated as one fixed word?</summary>

The Finnish negative auxiliary inflects and interacts with tense and the main verb form.

</details>

### Participles, clauses and standard/spoken differences

Participles and infinitival constructions compress clauses in formal prose. Relative joka inflects according to its role, with agreement and case patterns to learn. Standard Finnish minä olen and colloquial forms such as mä oon illustrate a wider gap than a minor accent difference. Keep a stable professional written standard while recognising conversational forms.

**eilen julkaistu raportti**

the report published yesterday Passive past participle modifies raportti.

**menetelmä, jota käytämme**

the method we use Relative partitive reflects the construction.

#### Relative forms

Joka forms relative clauses and inflects according to its role inside the clause. The antecedent helps choose number, but the relative clause supplies the case relation.

**Matkustan melkein joka päivä.**

I travel almost every day.

**Voi olla, että se ei ollut Tomi, joka rikkoi ikkunan.**

Tom might not be the one who broke the window.

![[Resources/Audio/fi/Rule 15.mp3]]

[[Finnish#^fi-Q0701|Practise this rule (50 questions)]]

#### Complement and condition

Että introduces a content clause; jos a condition; kun a temporal clause; koska a cause; vaikka a concession. Finnish does not copy German verb-final order merely because a clause is subordinate.

**Voisitko katsoa hetken muualle kun vaihdan vaatteeni?**

Would you mind looking the other way for just a minute while I change my clothes?

**Olen pahoillani kun olen antanut sinun odottaa.**

I'm sorry I've kept you waiting so long.

![[Resources/Audio/fi/Rule 16.mp3]]

[[Finnish#^fi-Q0751|Practise this rule (50 questions)]]

#### Postpositions

Many postpositions follow a noun in a governed case, frequently genitive. Some corresponding prepositions take another case. Learn a relation word with its complement pattern.

**Autapa minua näiden matkatavaroiden kanssa.**

Just help me with this baggage.

**Menikö hän Hangzhouhun isänsä kanssa?**

Did he go to Hangzhou with his dad?

![[Resources/Audio/fi/Rule 17.mp3]]

[[Finnish#^fi-Q0801|Practise this rule (50 questions)]]

#### Perfect participles

A perfect uses an olla form plus a past active participle, with number agreement in relevant forms. Negative past constructions also use a participle but differ in auxiliary pattern.

**Hän meni Kiinaan sotilaana eikä koskaan tullut takaisin.**

He went to China as a soldier, never to come back.

**Tomilla ei ollut paljonkaan valinnanvaraa.**

Tom didn't have much of a choice.

![[Resources/Audio/fi/Rule 19.mp3]]

[[Finnish#^fi-Q0901|Practise this rule (50 questions)]]

<details><summary>What should you track in a compressed clause?</summary>

Agent, time, case government, head noun and relationship to the main predicate.

</details>

<details><summary>Should colloquial forms automatically appear in formal reports?</summary>

No. Register must match audience and medium.

</details>

### Professional reading

Teaching passage: Tulokset osoittavat yhteyden kahden tekijän välillä. Ne eivät kuitenkaan todista, että toinen tekijä aiheuttaa toisen. Tutkimuksen olosuhteet on otettava huomioon johtopäätöstä arvioitaessa.
Translation: The results show a relationship between two factors. However, they do not prove that one causes the other. Study conditions must be considered when assessing the conclusion.

**Voisitteko täsmentää tätä kohtaa?**

Could you clarify this point? Polite plural conditional request.

**Johtopäätös on alustava.**

The conclusion is preliminary. Qualified status.

#### Comparison and stance

Parempi is adjectival better; paremmin adverbial better. Kuitenkin marks nevertheless and siksi a consequence. Ehkä limits certainty. Compare the form’s actual role before choosing an English gloss.

**Ehkä hän on italialainen tai espanjalainen.**

Maybe he is Italian or Spanish.

**Minä pidän enemmän kesästä kuin talvesta.**

I like summer better than winter.

![[Resources/Audio/fi/Rule 20.mp3]]

[[Finnish#^fi-Q0951|Practise this rule (50 questions)]]

<details><summary>What is the role of eivät?</summary>

Third-person plural negative auxiliary agreeing with ne.

</details>

<details><summary>Summarise the passage in standard Finnish.</summary>

Preserve case relationships, causal caution and the distinction between formal and spoken forms.

</details>

## Word bank and recordings

1,000 study entries, based on dictionary selections and authored teaching glosses. Learn a word in a phrase; consult the linked entry for additional senses.

<details><summary>Words 1–50</summary>

![[Resources/Audio/fi/Words 0001-0050.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [ja](https://en.wiktionary.org/wiki/ja#Finnish) | and | /ˈjɑ/ · conj |
| [ei](https://en.wiktionary.org/wiki/ei#Finnish) | The negative verb or negation verb; not, be not, do not, etc. | /ˈei̯/ · verb |
| [se](https://en.wiktionary.org/wiki/se#Finnish) | it; that | /ˈse/ · pron |
| [kun](https://en.wiktionary.org/wiki/kun#Finnish) | when, as, while (temporal: at the same time or instant that) | /ˈkun/ · conj |
| [hän](https://en.wiktionary.org/wiki/h%C3%A4n#Finnish) | he, she, one, they sg (only of a human being; gender-neutral) | /ˈhæn/ · pron |
| [jos](https://en.wiktionary.org/wiki/jos#Finnish) | if (supposing that) | /ˈjos/ · conj |
| [voi](https://en.wiktionary.org/wiki/voi#Finnish) | can/may (voida); butter in another sense | /ˈʋoi̯/ · verb |
| [nyt](https://en.wiktionary.org/wiki/nyt#Finnish) | now (at the present time) | /ˈnyt/ · adv |
| [tai](https://en.wiktionary.org/wiki/tai#Finnish) | or (in statements, or an inclusive or in questions) | /ˈtɑi̯(ˣ)/ · conj |
| [joka](https://en.wiktionary.org/wiki/joka#Finnish) | who, which, that (referring to the previous word or phrase; see usage notes) | /ˈjokɑ/ · pron |
| [olla](https://en.wiktionary.org/wiki/olla#Finnish) | to be (indicating that the subject and the complement of the verb form the same thing, or that the complement describes the subject) | /ˈolːɑˣ/ · verb |
| [vain](https://en.wiktionary.org/wiki/vain#Finnish) | only, merely, exclusively, solely, just | /ˈʋɑi̯n/ · adv |
| [jo](https://en.wiktionary.org/wiki/jo#Finnish) | already (prior to some time; so soon) | /ˈjo/ · adv |
| [tämä](https://en.wiktionary.org/wiki/t%C3%A4m%C3%A4#Finnish) | this | /ˈtæmæ/ · pron |
| [kaikki](https://en.wiktionary.org/wiki/kaikki#Finnish) | everything (in the singular) | /ˈkɑi̯kːi/ · pron |
| [kyllä](https://en.wiktionary.org/wiki/kyll%C3%A4#Finnish) | an intensifier; corresponds to the English auxiliary do in many cases | /ˈkylːæ/ · adv |
| [hyvä](https://en.wiktionary.org/wiki/hyv%C3%A4#Finnish) | good (of high quality) | /ˈhyʋæ/ · adj |
| [pitää](https://en.wiktionary.org/wiki/pit%C3%A4%C3%A4#Finnish) | to hold, grasp, grip | /ˈpitæːˣ/ · verb |
| [ihan](https://en.wiktionary.org/wiki/ihan#Finnish) | very, rather, quite | /ˈihɑn/ · adv |
| [koska](https://en.wiktionary.org/wiki/koska#Finnish) | because, since | /ˈkoskɑ/ · conj |
| [koko](https://en.wiktionary.org/wiki/koko#Finnish) | whole, entire | /ˈkoko/ · adj |
| [mikä](https://en.wiktionary.org/wiki/mik%C3%A4#Finnish) | what, which | /ˈmikæ/ · pron |
| [aika](https://en.wiktionary.org/wiki/aika#Finnish) | time (inevitable progression into the future with the passing of present and past events) | /ˈɑi̯kɑ/ · noun |
| [eli](https://en.wiktionary.org/wiki/eli#Finnish) | that is, that is to say, i.e.; in other words, to put it another way; as in (used to introduce a clarification or explanation) | /ˈeli(ˣ)/ · conj |
| [et](https://en.wiktionary.org/wiki/et#Finnish) | and (especially as symbolized by an ampersand) | /ˈet/ · conj |
| [ehkä](https://en.wiktionary.org/wiki/ehk%C3%A4#Finnish) | perhaps, maybe | /ˈehkæ/ · adv |
| [tehdä](https://en.wiktionary.org/wiki/tehd%C3%A4#Finnish) | to do, perform, execute, carry out | /ˈtehdæˣ/ · verb |
| [tuo](https://en.wiktionary.org/wiki/tuo#Finnish) | that (over there) (compare se, see usage notes) | /ˈtuo̯/ · pron |
| [yksi](https://en.wiktionary.org/wiki/yksi#Finnish) | one | /ˈyksi/ · num |
| [juuri](https://en.wiktionary.org/wiki/juuri#Finnish) | root (of a plant, hair, tooth, etc.) | /ˈjuːri/ · noun |
| [kaksi](https://en.wiktionary.org/wiki/kaksi#Finnish) | two | /ˈkɑksi/ · num |
| [taas](https://en.wiktionary.org/wiki/taas#Finnish) | again, another time, once again | /ˈtɑːs/ · adv |
| [tuli](https://en.wiktionary.org/wiki/tuli#Finnish) | fire (reaction; burning) | /ˈtuli/ · noun |
| [joku](https://en.wiktionary.org/wiki/joku#Finnish) | someone, somebody | /ˈjoku/ · pron |
| [eri](https://en.wiktionary.org/wiki/eri#Finnish) | different, other, another | /ˈeri/ · adj |
| [he](https://en.wiktionary.org/wiki/he#Finnish) | they (plural, only of people) | /ˈhe/ · pron |
| [vai](https://en.wiktionary.org/wiki/vai#Finnish) | or (exclusive or; either what comes before or what comes after) | /ˈʋɑi̯/ · conj |
| [pois](https://en.wiktionary.org/wiki/pois#Finnish) | away, off | /ˈpoi̯s/ · adv |
| [suomi](https://en.wiktionary.org/wiki/suomi#Finnish) | Finnish (language) | /ˈsuo̯mi/ · noun |
| [mies](https://en.wiktionary.org/wiki/mies#Finnish) | man (adult male human being) | /ˈmie̯s/ · noun |
| [minä](https://en.wiktionary.org/wiki/min%C3%A4#Finnish) | I (first-person singular personal pronoun) | /ˈminæ/ · pron |
| [täällä](https://en.wiktionary.org/wiki/t%C3%A4%C3%A4ll%C3%A4#Finnish) | here, over here (in this place) | /ˈtæːlːæ/ · adv |
| [missä](https://en.wiktionary.org/wiki/miss%C3%A4#Finnish) | where | /ˈmisːæ/ · adv |
| [saada](https://en.wiktionary.org/wiki/saada#Finnish) | to get, receive | /ˈsɑːdɑˣ/ · verb |
| [toinen](https://en.wiktionary.org/wiki/toinen#Finnish) | second (after the first in a sequence) | /ˈtoi̯nen/ · adj |
| [kolme](https://en.wiktionary.org/wiki/kolme#Finnish) | three | /ˈkolme(ˣ)/ · num |
| [me](https://en.wiktionary.org/wiki/me#Finnish) | we | /ˈme/ · pron |
| [ottaa](https://en.wiktionary.org/wiki/ottaa#Finnish) | to take | /ˈotːɑːˣ/ · verb |
| [uusi](https://en.wiktionary.org/wiki/uusi#Finnish) | new | /ˈuːsi/ · adj |
| [antaa](https://en.wiktionary.org/wiki/antaa#Finnish) | to give [with allative ‘to’] (transfer possession of to someone else) | /ˈɑntɑːˣ/ · verb |

</details>

<details><summary>Words 51–100</summary>

![[Resources/Audio/fi/Words 0051-0100.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [näyttää](https://en.wiktionary.org/wiki/n%C3%A4ytt%C3%A4%C3%A4#Finnish) | to show, present, display | /ˈnæy̯tːæːˣ/ · verb |
| [a](https://en.wiktionary.org/wiki/a#Finnish) | A (note) |  · noun |
| [asia](https://en.wiktionary.org/wiki/asia#Finnish) | matter, issue, affair, concern, business, subject, case, thing (any abstract thing) | /ˈɑsiɑ/ · noun |
| [jota](https://en.wiktionary.org/wiki/jota#Finnish) | iota (ninth letter in Greek alphabet) | /ˈjoːtɑ/ · noun |
| [kukaan](https://en.wiktionary.org/wiki/kukaan#Finnish) | anybody, anyone; (with negative) no-one, none, nobody | /ˈkukɑːn/ · pron |
| [käyttää](https://en.wiktionary.org/wiki/k%C3%A4ytt%C3%A4%C3%A4#Finnish) | to use, make use of‚ employ, apply, utilize, exploit, take advantage of, exert, exercise | /ˈkæy̯tːæːˣ/ · verb |
| [alle](https://en.wiktionary.org/wiki/alle#Finnish) | under, less than (+ number) | /ˈɑlːeˣ/ · prep |
| [oma](https://en.wiktionary.org/wiki/oma#Finnish) | own (that belongs to one) | /ˈomɑ/ · adj |
| [asti](https://en.wiktionary.org/wiki/asti#Finnish) | up to, all the way to | /ˈɑstiˣ/ · postp |
| [kai](https://en.wiktionary.org/wiki/kai#Finnish) | probably, I guess (that) (used to express a possibility or belief of what's going to happen) | /ˈkɑi̯(ˣ)/ · adv |
| [mennä](https://en.wiktionary.org/wiki/menn%C3%A4#Finnish) | to go [with illative of third infinitive ‘to do’] (move away from a point of reference) | /ˈmenːæˣ/ · verb |
| [iso](https://en.wiktionary.org/wiki/iso#Finnish) | big, large, great (of a great size) | /ˈiso/ · adj |
| [sama](https://en.wiktionary.org/wiki/sama#Finnish) | same | /ˈsɑmɑ/ · det |
| [sanoa](https://en.wiktionary.org/wiki/sanoa#Finnish) | to say, tell | /ˈsɑnoɑˣ/ · verb |
| [d](https://en.wiktionary.org/wiki/d#Finnish) | D (note) |  · noun |
| [ensimmäinen](https://en.wiktionary.org/wiki/ensimm%C3%A4inen#Finnish) | first | /ˈensimːæi̯nen/ · adj |
| [kuka](https://en.wiktionary.org/wiki/kuka#Finnish) | who | /ˈkukɑ/ · pron |
| [tulla](https://en.wiktionary.org/wiki/tulla#Finnish) | to come (move nearer) | /ˈtulːɑˣ/ · verb |
| [nainen](https://en.wiktionary.org/wiki/nainen#Finnish) | woman (adult female human being) | /ˈnɑi̯nen/ · noun |
| [tietää](https://en.wiktionary.org/wiki/tiet%C3%A4%C3%A4#Finnish) | to know [with elative ‘about’], be aware of (in some cases implying superficial knowledge, see the usage notes below) | /ˈtie̯tæːˣ/ · verb |
| [-s](https://en.wiktionary.org/wiki/-s#Finnish) | Appended to a second-person imperative to give a command or request a slightly rude or impatient tone—the tone may vary depending on the verb and other particles used. |  · particle |
| [pieni](https://en.wiktionary.org/wiki/pieni#Finnish) | small, little (low in size, amount or intensity) | /ˈpie̯ni/ · adj |
| [joo](https://en.wiktionary.org/wiki/joo#Finnish) | yeah, yes | /ˈjoː/ · adv |
| [suuri](https://en.wiktionary.org/wiki/suuri#Finnish) | large, big, great (of considerable size or extent) | /ˈsuːri/ · adj |
| [päivä](https://en.wiktionary.org/wiki/p%C3%A4iv%C3%A4#Finnish) | day (period between sunrise and sunset) | /ˈpæi̯ʋæ/ · noun |
| [toki](https://en.wiktionary.org/wiki/toki#Finnish) | of course | /ˈtoki/ · adv |
| [jää](https://en.wiktionary.org/wiki/j%C3%A4%C3%A4#Finnish) | ice (water in solid form) | /ˈjæː/ · noun |
| [neljä](https://en.wiktionary.org/wiki/nelj%C3%A4#Finnish) | four | /ˈneljæ/ · num |
| [suomalainen](https://en.wiktionary.org/wiki/suomalainen#Finnish) | Finnish, of or relating to Finland | /ˈsuo̯mɑlɑi̯nen/ · adj |
| [kuva](https://en.wiktionary.org/wiki/kuva#Finnish) | picture, figure (representation of visible reality produced by e.g. drawing) | /ˈkuʋɑ/ · noun |
| [nähdä](https://en.wiktionary.org/wiki/n%C3%A4hd%C3%A4#Finnish) | to see (perceive with the eyes) | /ˈnæhdæˣ/ · verb |
| [sinä](https://en.wiktionary.org/wiki/sin%C3%A4#Finnish) | you (second-person singular personal pronoun, used in familiar or neutral contexts), thou | /ˈsinæ/ · pron |
| [pian](https://en.wiktionary.org/wiki/pian#Finnish) | soon (within a short time) | /ˈpiɑn/ · adv |
| [ihminen](https://en.wiktionary.org/wiki/ihminen#Finnish) | human, human being (an individual) | /ˈihminen/ · noun |
| [hei](https://en.wiktionary.org/wiki/hei#Finnish) | hi (greeting) | /ˈhei̯/ · intj |
| [in](https://en.wiktionary.org/wiki/in#Finnish) | in, popular (in fashion) | /ˈin/ · adv |
| [nimi](https://en.wiktionary.org/wiki/nimi#Finnish) | name | /ˈnimi/ · noun |
| [tee](https://en.wiktionary.org/wiki/tee#Finnish) | tea (dried leaves or buds of the tea plant, Camellia sinensis) | /ˈteː/ · noun |
| [vanha](https://en.wiktionary.org/wiki/vanha#Finnish) | old (of age) | /ˈʋɑnhɑ/ · adj |
| [viisi](https://en.wiktionary.org/wiki/viisi#Finnish) | five | /ˈʋiːsi/ · num |
| [auttaa](https://en.wiktionary.org/wiki/auttaa#Finnish) | to help, assist, give assistance, lend a hand, aid | /ˈɑu̯tːɑːˣ/ · verb |
| [poika](https://en.wiktionary.org/wiki/poika#Finnish) | boy (young male human) | /ˈpoi̯kɑ/ · noun |
| [usko](https://en.wiktionary.org/wiki/usko#Finnish) | faith (religious belief system) | /ˈusko/ · noun |
| [äiti](https://en.wiktionary.org/wiki/%C3%A4iti#Finnish) | mother (woman in relation to her children) | /ˈæi̯ti/ · noun |
| [kiva](https://en.wiktionary.org/wiki/kiva#Finnish) | nice, pleasant | /ˈkiʋɑ/ · adj |
| [vaikea](https://en.wiktionary.org/wiki/vaikea#Finnish) | difficult, hard | /ˈʋɑi̯keɑ/ · adj |
| [ohi](https://en.wiktionary.org/wiki/ohi#Finnish) | past, beyond | /ˈohi(ˣ)/ · adv |
| [alla](https://en.wiktionary.org/wiki/alla#Finnish) | beneath, underneath, below | /ˈɑlːɑ/ · adv |
| [huono](https://en.wiktionary.org/wiki/huono#Finnish) | bad, poor (of low quality, not very useful or effective; incompetent, unskilled, untalented) | /ˈhuo̯no/ · adj |
| [to](https://en.wiktionary.org/wiki/to#Finnish) | Thu (abbreviation of Thursday) | /ˈto/ · noun |

</details>

<details><summary>Words 101–150</summary>

![[Resources/Audio/fi/Words 0101-0150.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [auto](https://en.wiktionary.org/wiki/auto#Finnish) | car, automobile | /ˈɑu̯to/ · noun |
| [etelä](https://en.wiktionary.org/wiki/etel%C3%A4#Finnish) | south | /ˈetelæ/ · noun |
| [oikea](https://en.wiktionary.org/wiki/oikea#Finnish) | right (opposite of left) | /ˈoi̯keɑ/ · adj |
| [ostaa](https://en.wiktionary.org/wiki/ostaa#Finnish) | to buy, purchase | /ˈostɑːˣ/ · verb |
| [e](https://en.wiktionary.org/wiki/e#Finnish) | E (note) |  · noun |
| [kysymys](https://en.wiktionary.org/wiki/kysymys#Finnish) | question | /ˈkysymys/ · noun |
| [maa](https://en.wiktionary.org/wiki/maa#Finnish) | ground, land (surface of the Earth, especially that which is not covered by water) | /ˈmɑː/ · noun |
| [syy](https://en.wiktionary.org/wiki/syy#Finnish) | fibre, filament | /ˈsyː/ · noun |
| [jättää](https://en.wiktionary.org/wiki/j%C3%A4tt%C3%A4%C3%A4#Finnish) | to leave, leave behind (a thing, place, person, group, traces, etc.) (cause or allow to remain as available; cause, result in; deposit; transfer possession; have a consequence or remnant) | /ˈjætːæːˣ/ · verb |
| [kello](https://en.wiktionary.org/wiki/kello#Finnish) | watch (portable or wearable timepiece) | /ˈkelːo/ · noun |
| [lähteä](https://en.wiktionary.org/wiki/l%C3%A4hte%C3%A4#Finnish) | to leave, go, go away, set off, take off, depart, embark, sail | /ˈlæhteæˣ/ · verb |
| [sun](https://en.wiktionary.org/wiki/sun#Finnish) | A coordinating conjunction expressing generality. | /ˈsun/ · conj |
| [toi](https://en.wiktionary.org/wiki/toi#Finnish) | synonym of tuo (“that”) | /ˈtoi̯/ · pron |
| [jatkaa](https://en.wiktionary.org/wiki/jatkaa#Finnish) | to continue, keep on, go on, proceed, keep going; to resume | /ˈjɑtkɑːˣ/ · verb |
| [oy](https://en.wiktionary.org/wiki/oy#Finnish) | LLC; initialism of osakeyhtiö (“limited liability company”) | /ˈoːˌyː/ · noun |
| [tyttö](https://en.wiktionary.org/wiki/tytt%C3%B6#Finnish) | girl (young female human) | /ˈtytːø/ · noun |
| [c](https://en.wiktionary.org/wiki/c#Finnish) | C (note) |  · noun |
| [elää](https://en.wiktionary.org/wiki/el%C3%A4%C3%A4#Finnish) | to live, be alive | /ˈelæːˣ/ · verb |
| [löytää](https://en.wiktionary.org/wiki/l%C3%B6yt%C3%A4%C3%A4#Finnish) | to find; to discover; to come across | /ˈløy̯tæːˣ/ · verb |
| [muu](https://en.wiktionary.org/wiki/muu#Finnish) | other, another | /ˈmuː/ · pron |
| [pitkä](https://en.wiktionary.org/wiki/pitk%C3%A4#Finnish) | long (having great length) | /ˈpitkæ/ · adj |
| [video](https://en.wiktionary.org/wiki/video#Finnish) | video | /ˈʋideo/ · noun |
| [TV](https://en.wiktionary.org/wiki/TV#Finnish) | TV (abbreviation for television) |  · noun |
| [tapa](https://en.wiktionary.org/wiki/tapa#Finnish) | habit (action performed on a regular basis) | /ˈtɑpɑ/ · noun |
| [tv](https://en.wiktionary.org/wiki/tv#Finnish) | TV, television | /ˈteːˌʋeː/ · noun |
| [b](https://en.wiktionary.org/wiki/b#Finnish) | B flat |  · noun |
| [isä](https://en.wiktionary.org/wiki/is%C3%A4#Finnish) | father (male parent; male who has sired a baby, that man relative to his children) | /ˈisæ/ · noun |
| [kasvaa](https://en.wiktionary.org/wiki/kasvaa#Finnish) | to grow | /ˈkɑsʋɑːˣ/ · verb |
| [kuinka paljon se maksaa](https://en.wiktionary.org/wiki/kuinka%20paljon%20se%20maksaa#Finnish) | how much is it? |  · phrase |
| [kymmenen](https://en.wiktionary.org/wiki/kymmenen#Finnish) | ten | /ˈkymːenen/ · num |
| [ääntäminen](https://en.wiktionary.org/wiki/%C3%A4%C3%A4nt%C3%A4minen) | pronunciation |  · noun |
| [ala](https://en.wiktionary.org/wiki/ala#Finnish) | area (measure of the extent of a surface) | /ˈɑlɑ/ · noun |
| [muuttaa](https://en.wiktionary.org/wiki/muuttaa#Finnish) | to modify, change, alter, amend | /ˈmuːtːɑːˣ/ · verb |
| [venäjä](https://en.wiktionary.org/wiki/ven%C3%A4j%C3%A4#Finnish) | Russian (language) | /ˈʋenæjæ/ · noun |
| [elämä](https://en.wiktionary.org/wiki/el%C3%A4m%C3%A4#Finnish) | life (state of being alive, existence of a person or creature; experience of living, description of (a person's) day-to-day existence) | /ˈelæmæ/ · noun |
| [kaupunki](https://en.wiktionary.org/wiki/kaupunki#Finnish) | town, city (larger settlement with significant amenities) | /ˈkɑu̯puŋki/ · noun |
| [kirjoittaa](https://en.wiktionary.org/wiki/kirjoittaa#Finnish) | to write (form symbols, especially those directly expressing language, on a medium to be seen and interpreted) | /ˈkirjoi̯tːɑːˣ/ · verb |
| [mahdollisuus](https://en.wiktionary.org/wiki/mahdollisuus#Finnish) | possibility, chance, probability, likelihood (the extent to which something is possible; the quality of being possible) | /ˈmɑhdolːisuːs/ · noun |
| [odottaa](https://en.wiktionary.org/wiki/odottaa#Finnish) | to wait (for), await, expect, anticipate | /ˈodotːɑːˣ/ · verb |
| [ilta](https://en.wiktionary.org/wiki/ilta#Finnish) | evening | /ˈiltɑ/ · noun |
| [katsoa](https://en.wiktionary.org/wiki/katsoa#Finnish) | to look, have a look, take a look (+ at) | /ˈkɑtsoɑˣ/ · verb |
| [peli](https://en.wiktionary.org/wiki/peli#Finnish) | game (activity described by a set of rules, especially for the purpose of entertainment) | /ˈpeli/ · noun |
| [musta](https://en.wiktionary.org/wiki/musta#Finnish) | black (colour) | /ˈmustɑ/ · adj |
| [puhua](https://en.wiktionary.org/wiki/puhua#Finnish) | to speak, talk [with elative ‘about, of’ and allative ‘to’] (communicate, discuss, converse; usually by speaking or with one's voice) | /ˈpuhuɑˣ/ · verb |
| [työ](https://en.wiktionary.org/wiki/ty%C3%B6#Finnish) | work, toil, effort, labour (effort expended on a particular task) | /ˈtyø̯/ · noun |
| [h](https://en.wiktionary.org/wiki/h#Finnish) | B (note) |  · noun |
| [kuusi](https://en.wiktionary.org/wiki/kuusi#Finnish) | six | /ˈkuːsi/ · num |
| [lapsi](https://en.wiktionary.org/wiki/lapsi#Finnish) | child (person who is below the age of adulthood) | /ˈlɑpsi/ · noun |
| [ajaa](https://en.wiktionary.org/wiki/ajaa#Finnish) | to drive, ride, travel (in a vehicle), transport (e.g. in a car) | /ˈɑjɑːˣ/ · verb |
| [hyvää uutta vuotta](https://en.wiktionary.org/wiki/hyv%C3%A4%C3%A4%20uutta%20vuotta#Finnish) | Happy New Year |  · phrase |

</details>

<details><summary>Words 151–200</summary>

![[Resources/Audio/fi/Words 0151-0200.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [kova](https://en.wiktionary.org/wiki/kova#Finnish) | hard (of an object, resistant to pressure) | /ˈkoʋɑ/ · adj |
| [lue](https://en.wiktionary.org/wiki/lue#Finnish) | read; used to indicate pronunciation | /ˈlueˣ/ · intj |
| [kertoa](https://en.wiktionary.org/wiki/kertoa#Finnish) | to tell | /ˈkertoɑˣ/ · verb |
| [lähde](https://en.wiktionary.org/wiki/l%C3%A4hde#Finnish) | spring, wellhead (place where water emerges from the ground) | /ˈlæhdeˣ/ · noun |
| [nuori](https://en.wiktionary.org/wiki/nuori#Finnish) | young | /ˈnuo̯ri/ · adj |
| [varma](https://en.wiktionary.org/wiki/varma#Finnish) | sure, certain | /ˈʋɑrmɑ/ · adj |
| [ymmärtää](https://en.wiktionary.org/wiki/ymm%C3%A4rt%C3%A4%C3%A4#Finnish) | to understand | /ˈymːærtæːˣ/ · verb |
| [lukea](https://en.wiktionary.org/wiki/lukea#Finnish) | to read (interpret or speak aloud something written) | /ˈlukeɑˣ/ · verb |
| [tasa](https://en.wiktionary.org/wiki/tasa#Finnish) | even, equal, equi-, homo-, flat, uniform | /ˈtɑsɑ/ · adj |
| [aloittaa](https://en.wiktionary.org/wiki/aloittaa#Finnish) | to start, begin, commence, initiate | /ˈɑloi̯tːɑːˣ/ · verb |
| [jokin](https://en.wiktionary.org/wiki/jokin#Finnish) | something | /ˈjokin/ · pron |
| [OK](https://en.wiktionary.org/wiki/OK#Finnish) | OK (in buttons, etc.) | /ˈokei̯/ · intj |
| [Te](https://en.wiktionary.org/wiki/Te#Finnish) | You (very formal, honorific or respectful 2nd person address both in singular and in plural) (alternative letter-case form of te) | /ˈte/ · pron |
| [itä](https://en.wiktionary.org/wiki/it%C3%A4#Finnish) | east | /ˈitæ/ · noun |
| [kaunis](https://en.wiktionary.org/wiki/kaunis#Finnish) | beautiful, pretty, fair | /ˈkɑu̯nis/ · adj |
| [te](https://en.wiktionary.org/wiki/te#Finnish) | you (second-person plural; when addressing many persons or when addressing politely or formally one person) | /ˈte/ · pron |
| [kirja](https://en.wiktionary.org/wiki/kirja#Finnish) | book (collection of sheets of paper bound together containing printed or written material) | /ˈkirjɑ/ · noun |
| [valita](https://en.wiktionary.org/wiki/valita#Finnish) | to choose, select | /ˈʋɑlitɑˣ/ · verb |
| [arvo](https://en.wiktionary.org/wiki/arvo#Finnish) | value, worth (quality (positive or negative) that renders something desirable or valuable) | /ˈɑrʋo/ · noun |
| [paha](https://en.wiktionary.org/wiki/paha#Finnish) | bad, evil, ill | /ˈpɑhɑ/ · adj |
| [vapaa](https://en.wiktionary.org/wiki/vapaa#Finnish) | free (not imprisoned, enslaved or subjugated) | /ˈʋɑpɑː/ · adj |
| [ai](https://en.wiktionary.org/wiki/ai#Finnish) | ouch! | /ˈɑi̯/ · intj |
| [nostaa](https://en.wiktionary.org/wiki/nostaa#Finnish) | to lift, raise, elevate | /ˈnostɑːˣ/ · verb |
| [kuulla](https://en.wiktionary.org/wiki/kuulla#Finnish) | to hear (perceive through hearing) | /ˈkuːlːɑˣ/ · verb |
| [alas](https://en.wiktionary.org/wiki/alas#Finnish) | down, downward, downwards | /ˈɑlɑs/ · adv |
| [perhe](https://en.wiktionary.org/wiki/perhe#Finnish) | family, nuclear family, immediate family (parents and children) | /ˈperheˣ/ · noun |
| [seitsemän](https://en.wiktionary.org/wiki/seitsem%C3%A4n#Finnish) | seven | /ˈsei̯tsemæn/ · num |
| [ajatus](https://en.wiktionary.org/wiki/ajatus#Finnish) | thought (form created in the mind) | /ˈɑjɑtus/ · noun |
| [just](https://en.wiktionary.org/wiki/just#Finnish) | just, exactly, precisely, perfectly | /ˈjust/ · adv |
| [kolmas](https://en.wiktionary.org/wiki/kolmas#Finnish) | third | /ˈkolmɑs/ · adj |
| [mukava](https://en.wiktionary.org/wiki/mukava#Finnish) | comfortable | /ˈmukɑʋɑ/ · adj |
| [voittaa](https://en.wiktionary.org/wiki/voittaa#Finnish) | to win | /ˈʋoi̯tːɑːˣ/ · verb |
| [henkilö](https://en.wiktionary.org/wiki/henkil%C3%B6#Finnish) | person, figure (an individual with personhood, such as one representing a certain consciousness) | /ˈheŋkilø/ · noun |
| [idea](https://en.wiktionary.org/wiki/idea#Finnish) | idea | /ˈideɑ/ · noun |
| [hauska](https://en.wiktionary.org/wiki/hauska#Finnish) | pleasant, nice, merry, fun, enjoyable | /ˈhɑu̯skɑ/ · adj |
| [jäädä](https://en.wiktionary.org/wiki/j%C3%A4%C3%A4d%C3%A4#Finnish) | to stay (behind), remain | /ˈjæːdæˣ/ · verb |
| [kahdeksan](https://en.wiktionary.org/wiki/kahdeksan#Finnish) | eight | /ˈkɑhdeksɑn/ · num |
| [koira](https://en.wiktionary.org/wiki/koira#Finnish) | dog (Canis lupus familiaris) | /ˈkoi̯rɑ/ · noun |
| [lopettaa](https://en.wiktionary.org/wiki/lopettaa#Finnish) | to stop, end, finish, quit | /ˈlopetːɑːˣ/ · verb |
| [valtio](https://en.wiktionary.org/wiki/valtio#Finnish) | state, country (political entity with sovereignty over a usually large geographical area) | /ˈʋɑltio/ · noun |
| [estää](https://en.wiktionary.org/wiki/est%C3%A4%C3%A4#Finnish) | to prevent, forestall, preclude, avert | /ˈestæːˣ/ · verb |
| [muistaa](https://en.wiktionary.org/wiki/muistaa#Finnish) | to remember, recall, recollect | /ˈmui̯stɑːˣ/ · verb |
| [sana](https://en.wiktionary.org/wiki/sana#Finnish) | word (unit of language, text or storage) | /ˈsɑnɑ/ · noun |
| [tieto](https://en.wiktionary.org/wiki/tieto#Finnish) | knowledge (fact of knowing about something; awareness) | /ˈtie̯to/ · noun |
| [matka](https://en.wiktionary.org/wiki/matka#Finnish) | journey, trip, voyage, travel | /ˈmɑtkɑ/ · noun |
| [palaa](https://en.wiktionary.org/wiki/palaa#Finnish) | to burn (be on fire, be consumed by fire, be destroyed or rendered unusable by excessive heat) | /ˈpɑlɑːˣ/ · verb |
| [ruotsi](https://en.wiktionary.org/wiki/ruotsi#Finnish) | Swedish (language) | /ˈruo̯tsi/ · noun |
| [kysyä](https://en.wiktionary.org/wiki/kysy%C3%A4#Finnish) | to ask, inquire/enquire | /ˈkysyæˣ/ · verb |
| [ruoka](https://en.wiktionary.org/wiki/ruoka#Finnish) | food (any substance consumed by living organisms to sustain life) | /ˈruo̯kɑ/ · noun |
| [sano](https://en.wiktionary.org/wiki/sano#Finnish) | Especially in spoken language, a common contraction of the third person singular indicative past form of the verb sanoa (“to say”), sanoi. |  · verb |

</details>

<details><summary>Words 201–250</summary>

![[Resources/Audio/fi/Words 0201-0250.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [syödä](https://en.wiktionary.org/wiki/sy%C3%B6d%C3%A4#Finnish) | to eat | /ˈsyø̯dæˣ/ · verb |
| [vahva](https://en.wiktionary.org/wiki/vahva#Finnish) | strong, powerful (capable of exerting or withstanding great physical force; possessing power, might, or strength) | /ˈʋɑhʋɑ/ · adj |
| [uskoa](https://en.wiktionary.org/wiki/uskoa#Finnish) | to believe, have faith [with illative ‘in’] (someone's abilities, chances etc.; someone's existence; the power, value etc. of something; the existence of something) | /ˈuskoɑˣ/ · verb |
| [koulu](https://en.wiktionary.org/wiki/koulu#Finnish) | school (an institution dedicated to teaching and learning, particularly one before college or university, or sometimes before lukio) | /ˈkou̯lu/ · noun |
| [selittää](https://en.wiktionary.org/wiki/selitt%C3%A4%C3%A4#Finnish) | to explain | /ˈselitːæːˣ/ · verb |
| [pyytää](https://en.wiktionary.org/wiki/pyyt%C3%A4%C3%A4#Finnish) | to ask (for), request | /ˈpyːtæːˣ/ · verb |
| [tuoda](https://en.wiktionary.org/wiki/tuoda#Finnish) | to bring, fetch, get (transport toward somebody/somewhere) | /ˈtuo̯dɑˣ/ · verb |
| [maata](https://en.wiktionary.org/wiki/maata#Finnish) | to be lying (in a lying or horizontal position) | /ˈmɑːtɑˣ/ · verb |
| [pelata](https://en.wiktionary.org/wiki/pelata#Finnish) | to play (participate in (a sport or game)) | /ˈpelɑtɑˣ/ · verb |
| [ajatella](https://en.wiktionary.org/wiki/ajatella#Finnish) | to think (about) | /ˈɑjɑtelːɑˣ/ · verb |
| [lasta](https://en.wiktionary.org/wiki/lasta#Finnish) | spatula, scraper (kitchen tool) | /ˈlɑstɑ/ · noun |
| [media](https://en.wiktionary.org/wiki/media#Finnish) | media | /ˈmediɑ/ · noun |
| [sota](https://en.wiktionary.org/wiki/sota#Finnish) | war (conflict involving organized use of arms; also figuratively, e.g. of a campaign against something or business competition) | /ˈsotɑ/ · noun |
| [eräs](https://en.wiktionary.org/wiki/er%C3%A4s#Finnish) | a certain, some | /ˈeræs/ · det |
| [g](https://en.wiktionary.org/wiki/g#Finnish) | G (note) |  · noun |
| [muka](https://en.wiktionary.org/wiki/muka#Finnish) | supposedly, allegedly, as if (used to express that what follows is doubtful or untrue) | /ˈmukɑ/ · adv |
| [parantaa](https://en.wiktionary.org/wiki/parantaa#Finnish) | to improve, better, enhance | /ˈpɑrɑntɑːˣ/ · verb |
| [tie](https://en.wiktionary.org/wiki/tie#Finnish) | way, road, path, route (for travelling) | /ˈtie̯/ · noun |
| [täydellinen](https://en.wiktionary.org/wiki/t%C3%A4ydellinen#Finnish) | perfect (without fault or mistake; which cannot be (further) improved; excellent and delightful in all respects) | /ˈtæy̯delːinen/ · adj |
| [pää](https://en.wiktionary.org/wiki/p%C3%A4%C3%A4#Finnish) | head (part of a body) | /ˈpæː/ · noun |
| [soittaa](https://en.wiktionary.org/wiki/soittaa#Finnish) | to play (produce music using a musical instrument; use a device to hear a recording) | /ˈsoi̯tːɑːˣ/ · verb |
| [kieli](https://en.wiktionary.org/wiki/kieli#Finnish) | tongue (organ in the mouth) | /ˈkie̯li/ · noun |
| [korkea](https://en.wiktionary.org/wiki/korkea#Finnish) | high (physically elevated, extending above a base or average level; located at a great altitude) | /ˈkorkeɑ/ · adj |
| [lahti](https://en.wiktionary.org/wiki/lahti#Finnish) | bay, gulf, inlet (portion of a body of water extending into the land) | /ˈlɑhti/ · noun |
| [seurata](https://en.wiktionary.org/wiki/seurata#Finnish) | to follow, accompany (to go or come after in physical space) | /ˈseu̯rɑtɑˣ/ · verb |
| [juu](https://en.wiktionary.org/wiki/juu#Finnish) | yeah, yes | /ˈjuː/ · intj |
| [laki](https://en.wiktionary.org/wiki/laki#Finnish) | act (a specific legal statute, inferior to a constitution) | /ˈlɑki/ · noun |
| [radio](https://en.wiktionary.org/wiki/radio#Finnish) | radio (technology) | /ˈrɑdio/ · noun |
| [ääni](https://en.wiktionary.org/wiki/%C3%A4%C3%A4ni#Finnish) | sound; noise (sound as a perceived or physical phenomenon; the sound emitted by something) | /ˈæːni/ · noun |
| [länsi](https://en.wiktionary.org/wiki/l%C3%A4nsi#Finnish) | west | /ˈlænsi/ · noun |
| [ero](https://en.wiktionary.org/wiki/ero#Finnish) | difference (that which is different between multiple things; characteristic of something that makes it different from something else) | /ˈero/ · noun |
| [heittää](https://en.wiktionary.org/wiki/heitt%C3%A4%C3%A4#Finnish) | to throw, cast, hurl, toss | /ˈhei̯tːæːˣ/ · verb |
| [puhelin](https://en.wiktionary.org/wiki/puhelin#Finnish) | telephone, phone | /ˈpuhelin/ · noun |
| [raha](https://en.wiktionary.org/wiki/raha#Finnish) | money (means of exchange and measure of value) | /ˈrɑhɑ/ · noun |
| [talo](https://en.wiktionary.org/wiki/talo#Finnish) | house (building meant to serve as a human abode) | /ˈtɑlo/ · noun |
| [kulttuuri](https://en.wiktionary.org/wiki/kulttuuri#Finnish) | culture (arts, customs and habits) | /ˈkultːuːri/ · noun |
| [laulu](https://en.wiktionary.org/wiki/laulu#Finnish) | song | /ˈlɑu̯lu/ · noun |
| [musiikki](https://en.wiktionary.org/wiki/musiikki#Finnish) | music | /ˈmusiːkːi/ · noun |
| [vastata](https://en.wiktionary.org/wiki/vastata#Finnish) | to answer, to reply; to respond | /ˈʋɑstɑtɑˣ/ · verb |
| [yhdeksän](https://en.wiktionary.org/wiki/yhdeks%C3%A4n#Finnish) | nine | /ˈyhdeksæn/ · num |
| [f](https://en.wiktionary.org/wiki/f#Finnish) | F (note) |  · noun |
| [kone](https://en.wiktionary.org/wiki/kone#Finnish) | machine (mechanical or electrical device) | /ˈkoneˣ/ · noun |
| [myydä](https://en.wiktionary.org/wiki/myyd%C3%A4#Finnish) | to sell | /ˈmyːdæˣ/ · verb |
| [poistaa](https://en.wiktionary.org/wiki/poistaa#Finnish) | to remove, take away, take off, take out | /ˈpoi̯stɑːˣ/ · verb |
| [siirtää](https://en.wiktionary.org/wiki/siirt%C3%A4%C3%A4#Finnish) | to move, transfer, relocate; (chiefly math) to translate | /ˈsiːrtæːˣ/ · verb |
| [valkoinen](https://en.wiktionary.org/wiki/valkoinen#Finnish) | white (of colour) | /ˈʋɑlkoi̯nen/ · adj |
| [vesi](https://en.wiktionary.org/wiki/vesi#Finnish) | water | /ˈʋesi/ · noun |
| [välittömästi](https://en.wiktionary.org/wiki/v%C3%A4litt%C3%B6m%C3%A4sti#Finnish) | immediately, right away, at once | /ˈʋælitːømæstiˣ/ · adv |
| [herra](https://en.wiktionary.org/wiki/herra#Finnish) | Mister (polite title for an adult man) | /ˈherːɑ/ · noun |
| [jaa](https://en.wiktionary.org/wiki/jaa#Finnish) | um, well | /ˈjɑː/ · intj |

</details>

<details><summary>Words 251–300</summary>

![[Resources/Audio/fi/Words 0251-0300.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [kuvitella](https://en.wiktionary.org/wiki/kuvitella#Finnish) | to imagine | /ˈkuʋitelːɑˣ/ · verb |
| [veli](https://en.wiktionary.org/wiki/veli#Finnish) | brother (male sibling) | /ˈʋeli/ · noun |
| [kauppa](https://en.wiktionary.org/wiki/kauppa#Finnish) | trade, commerce, buying and selling, trading, dealing, business, traffic | /ˈkɑu̯pːɑ/ · noun |
| [lyhyt](https://en.wiktionary.org/wiki/lyhyt#Finnish) | short (not long: having little length) | /ˈlyhyt/ · adj |
| [punainen](https://en.wiktionary.org/wiki/punainen#Finnish) | red | /ˈpunɑi̯nen/ · adj |
| [saksa](https://en.wiktionary.org/wiki/saksa#Finnish) | the German language | /ˈsɑksɑ/ · noun |
| [vika](https://en.wiktionary.org/wiki/vika#Finnish) | flaw, malfunction, failure, problem, defect | /ˈʋikɑ/ · noun |
| [äänestää](https://en.wiktionary.org/wiki/%C3%A4%C3%A4nest%C3%A4%C3%A4#Finnish) | to vote (for) | /ˈæːnestæːˣ/ · verb |
| [alta](https://en.wiktionary.org/wiki/alta#Finnish) | from under, from underneath, from beneath | /ˈɑltɑ/ · postp |
| [kuningas](https://en.wiktionary.org/wiki/kuningas#Finnish) | king (male monarch) | /ˈkuniŋːɑs/ · noun |
| [sata](https://en.wiktionary.org/wiki/sata#Finnish) | hundred | /ˈsɑtɑ/ · num |
| [per](https://en.wiktionary.org/wiki/per#Finnish) | per (for each, to each) | /ˈper/ · prep |
| [jumala](https://en.wiktionary.org/wiki/jumala#Finnish) | god, deity | /ˈjumɑlɑ/ · noun |
| [rakkaus](https://en.wiktionary.org/wiki/rakkaus#Finnish) | love, affection | /ˈrɑkːɑus/ · noun |
| [-ko](https://en.wiktionary.org/wiki/-ko#Finnish) | Makes a clause interrogative (polar question, yes–no). |  · particle |
| [kuunnella](https://en.wiktionary.org/wiki/kuunnella#Finnish) | to listen (to) | /ˈkuːnːelːɑˣ/ · verb |
| [raja](https://en.wiktionary.org/wiki/raja#Finnish) | border, boundary, limit, line (line or frontier area separating political or geographical regions) | /ˈrɑjɑ/ · noun |
| [etsiä](https://en.wiktionary.org/wiki/etsi%C3%A4#Finnish) | to look for, seek, search (for) | /ˈetsiæˣ/ · verb |
| [max](https://en.wiktionary.org/wiki/max#Finnish) | at most, max | /ˈmɑks/ · adv |
| [nopea](https://en.wiktionary.org/wiki/nopea#Finnish) | fast, quick, rapid, swift | /ˈnopeɑ/ · adj |
| [vitsi](https://en.wiktionary.org/wiki/vitsi#Finnish) | joke | /ˈʋitsi/ · noun |
| [historia](https://en.wiktionary.org/wiki/historia#Finnish) | history | /ˈhistoriɑ/ · noun |
| [luottaa](https://en.wiktionary.org/wiki/luottaa#Finnish) | to trust, rely on, count on | /ˈluo̯tːɑːˣ/ · verb |
| [minne](https://en.wiktionary.org/wiki/minne#Finnish) | where (to), whereto, whither | /ˈminːeˣ/ · adv |
| [tarvita](https://en.wiktionary.org/wiki/tarvita#Finnish) | to need, require | /ˈtɑrʋitɑˣ/ · verb |
| [tyhmä](https://en.wiktionary.org/wiki/tyhm%C3%A4#Finnish) | stupid, dumb, dull (not intelligent) | /ˈtyhmæ/ · adj |
| [internet](https://en.wiktionary.org/wiki/internet#Finnish) | internet | /ˈint(ː)ernet/ · noun |
| [kieltää](https://en.wiktionary.org/wiki/kielt%C3%A4%C3%A4#Finnish) | to forbid, prohibit, disallow, ban | /ˈkie̯ltæːˣ/ · verb |
| [luoda](https://en.wiktionary.org/wiki/luoda#Finnish) | to create (bring into existence out of nothing) | /ˈluo̯dɑˣ/ · verb |
| [numero](https://en.wiktionary.org/wiki/numero#Finnish) | digit, number (symbol for a non-negative integer: 0, 1, ..., 9) | /ˈnumero/ · noun |
| [tutkija](https://en.wiktionary.org/wiki/tutkija#Finnish) | researcher; scientist | /ˈtutkijɑ/ · noun |
| [koti](https://en.wiktionary.org/wiki/koti#Finnish) | home (house or structure in which one lives; place of the affections, or of refuge or rest) | /ˈkoti/ · noun |
| [linja-auto](https://en.wiktionary.org/wiki/linja-auto#Finnish) | bus, autobus, coach | /ˈlinjɑˌ(ʔ)ɑu̯to/ · noun |
| [tytär](https://en.wiktionary.org/wiki/tyt%C3%A4r#Finnish) | daughter | /ˈtytær/ · noun |
| [tähti](https://en.wiktionary.org/wiki/t%C3%A4hti#Finnish) | star (luminous dot) | /ˈtæhti/ · noun |
| [iloinen](https://en.wiktionary.org/wiki/iloinen#Finnish) | happy, merry, cheerful, joyful, joyous, mirthy, delighted | /ˈiloi̯nen/ · adj |
| [laskea](https://en.wiktionary.org/wiki/laskea#Finnish) | to lower, move down | /ˈlɑskeɑˣ/ · verb |
| [pro](https://en.wiktionary.org/wiki/pro#Finnish) | instead of, rather than | /ˈproː/ · adv |
| [tapahtua](https://en.wiktionary.org/wiki/tapahtua#Finnish) | to happen, take place, occur, come about, come up | /ˈtɑpɑhtuɑˣ/ · verb |
| [toivoa](https://en.wiktionary.org/wiki/toivoa#Finnish) | to hope (for), wish | /ˈtoi̯ʋoɑˣ/ · verb |
| [väärä](https://en.wiktionary.org/wiki/v%C3%A4%C3%A4r%C3%A4#Finnish) | wrong, incorrect | /ˈʋæːræ/ · adj |
| [aalto](https://en.wiktionary.org/wiki/aalto#Finnish) | wave (on the surface of a liquid) | /ˈɑːlto/ · noun |
| [asunto](https://en.wiktionary.org/wiki/asunto#Finnish) | home, residence; unit, housing unit, dwelling unit; dwelling, domicile, habitation (any place for living, especially one constructed for that purpose) | /ˈɑsunto/ · noun |
| [kutsua](https://en.wiktionary.org/wiki/kutsua#Finnish) | to invite | /ˈkutsuɑˣ/ · verb |
| [kuuma](https://en.wiktionary.org/wiki/kuuma#Finnish) | hot (having a high temperature) | /ˈkuːmɑ/ · adj |
| [painaa](https://en.wiktionary.org/wiki/painaa#Finnish) | to press, push | /ˈpɑi̯nɑːˣ/ · verb |
| [kesä](https://en.wiktionary.org/wiki/kes%C3%A4#Finnish) | summer (season) | /ˈkesæ/ · noun |
| [kylmä](https://en.wiktionary.org/wiki/kylm%C3%A4#Finnish) | cold (having a low temperature) | /ˈkylmæ/ · adj |
| [pysyä](https://en.wiktionary.org/wiki/pysy%C3%A4#Finnish) | to stay, remain | /ˈpysyæˣ/ · verb |
| [tom](https://en.wiktionary.org/wiki/tom#Finnish) | tom, tom-tom (percussion instrument) | /ˈtom/ · noun |

</details>

<details><summary>Words 301–350</summary>

![[Resources/Audio/fi/Words 0301-0350.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [keksi](https://en.wiktionary.org/wiki/keksi#Finnish) | cookie (small flat, baked cake which is either crisp or soft but firm) | /ˈkeksi/ · noun |
| [käsi](https://en.wiktionary.org/wiki/k%C3%A4si#Finnish) | hand, arm; an upper limb of a human or certain animals | /ˈkæsi/ · noun |
| [pistää](https://en.wiktionary.org/wiki/pist%C3%A4%C3%A4#Finnish) | to poke, thrust | /ˈpistæːˣ/ · verb |
| [yö](https://en.wiktionary.org/wiki/y%C3%B6#Finnish) | night | /ˈyø̯/ · noun |
| [aurinko](https://en.wiktionary.org/wiki/aurinko#Finnish) | the Sun | /ˈɑu̯riŋko/ · noun |
| [jaksaa](https://en.wiktionary.org/wiki/jaksaa#Finnish) | to manage, to get by, to have strength, energy, or stamina | /ˈjɑksɑːˣ/ · verb |
| [kiina](https://en.wiktionary.org/wiki/kiina#Finnish) | Chinese (language) | /ˈkiːnɑ/ · noun |
| [laatu](https://en.wiktionary.org/wiki/laatu#Finnish) | quality (level of excellence) | /ˈlɑːtu/ · noun |
| [kiittää](https://en.wiktionary.org/wiki/kiitt%C3%A4%C3%A4#Finnish) | to thank [with elative ‘for’], express one's gratitude | /ˈkiːtːæːˣ/ · verb |
| [koe](https://en.wiktionary.org/wiki/koe#Finnish) | experiment (test under controlled conditions) | /ˈkoeˣ/ · noun |
| [sydän](https://en.wiktionary.org/wiki/syd%C3%A4n#Finnish) | heart (organ) | /ˈsydæn/ · noun |
| [tunti](https://en.wiktionary.org/wiki/tunti#Finnish) | hour (unit of time) | /ˈtunti/ · noun |
| [unohtaa](https://en.wiktionary.org/wiki/unohtaa#Finnish) | to forget | /ˈunohtɑːˣ/ · verb |
| [etu](https://en.wiktionary.org/wiki/etu#Finnish) | advantage, benefit [with elative ‘from’ and allative ‘who or what benefits’] (any condition, circumstance, opportunity, or means, particularly favorable to success) | /ˈetu/ · noun |
| [etu-](https://en.wiktionary.org/wiki/etu-#Finnish) | front, fore- | /ˈetu-/ · adj |
| [ilves](https://en.wiktionary.org/wiki/ilves#Finnish) | lynx (any of the four species in the genus Lynx) | /ˈilʋes/ · noun |
| [neljäs](https://en.wiktionary.org/wiki/nelj%C3%A4s#Finnish) | fourth | /ˈneljæs/ · adj |
| [san](https://en.wiktionary.org/wiki/san#Finnish) | san (letter in Ancient Greek alphabet) | /ˈsɑn/ · noun |
| [pinta](https://en.wiktionary.org/wiki/pinta#Finnish) | surface (top side of something; outer hull of a tangible object) | /ˈpintɑ/ · noun |
| [alkuperäinen](https://en.wiktionary.org/wiki/alkuper%C3%A4inen#Finnish) | original (preceding all others; first in a series of versions) | /ˈɑlkuˌperæi̯nen/ · adj |
| [as](https://en.wiktionary.org/wiki/as#Finnish) | A-flat | /ˈɑs/ · noun |
| [levy](https://en.wiktionary.org/wiki/levy#Finnish) | sheet (thin, flat layer of solid material) | /ˈleʋy/ · noun |
| [luonto](https://en.wiktionary.org/wiki/luonto#Finnish) | nature, environment (the natural world) | /ˈluo̯nto/ · noun |
| [pelastaa](https://en.wiktionary.org/wiki/pelastaa#Finnish) | to save, rescue | /ˈpelɑstɑːˣ/ · verb |
| [sää](https://en.wiktionary.org/wiki/s%C3%A4%C3%A4#Finnish) | weather | /ˈsæː/ · noun |
| [tutkia](https://en.wiktionary.org/wiki/tutkia#Finnish) | to examine, investigate, research, search (through), explore | /ˈtutkiɑˣ/ · verb |
| [energia](https://en.wiktionary.org/wiki/energia#Finnish) | energy (impetus behind activity; ability to do work) | /ˈenerɡiɑ/ · noun |
| [sanasto](https://en.wiktionary.org/wiki/sanasto) | vocabulary |  · noun |
| [kuolema](https://en.wiktionary.org/wiki/kuolema#Finnish) | death, demise, decease | /ˈkuo̯lemɑ/ · noun |
| [vihreä](https://en.wiktionary.org/wiki/vihre%C3%A4#Finnish) | green (colour) | /ˈʋihreæ/ · adj |
| [asua](https://en.wiktionary.org/wiki/asua#Finnish) | to live, reside, dwell | /ˈɑsuɑˣ/ · verb |
| [homo](https://en.wiktionary.org/wiki/homo#Finnish) | gay man | /ˈhomo/ · noun |
| [ikä](https://en.wiktionary.org/wiki/ik%C3%A4#Finnish) | age (time which someone or something has been alive or existed) | /ˈikæ/ · noun |
| [pallo](https://en.wiktionary.org/wiki/pallo#Finnish) | ball, orb, sphere, globe (spherical object) | /ˈpɑlːo/ · noun |
| [erottaa](https://en.wiktionary.org/wiki/erottaa#Finnish) | to separate, part, divide | /ˈerotːɑːˣ/ · verb |
| [lentää](https://en.wiktionary.org/wiki/lent%C3%A4%C3%A4#Finnish) | to fly (travel through the air) | /ˈlentæːˣ/ · verb |
| [lista](https://en.wiktionary.org/wiki/lista#Finnish) | batten (thin strip of wood, especially one used for decorative purposes) | /ˈlistɑ/ · noun |
| [ura](https://en.wiktionary.org/wiki/ura#Finnish) | track, groove, rut, trail, furrow (mark in the form of a groove or long, narrow depression left by something that has passed along) | /ˈurɑ/ · noun |
| [voima](https://en.wiktionary.org/wiki/voima#Finnish) | power, strength, force, might | /ˈʋoi̯mɑ/ · noun |
| [maali](https://en.wiktionary.org/wiki/maali#Finnish) | paint | /ˈmɑːli/ · noun |
| [jalkapallo](https://en.wiktionary.org/wiki/jalkapallo#Finnish) | association football, football, soccer (association football) | /ˈjɑlkɑˌpɑlːo/ · noun |
| [kissa](https://en.wiktionary.org/wiki/kissa#Finnish) | cat (Felis catus) | /ˈkisːɑ/ · noun |
| [maku](https://en.wiktionary.org/wiki/maku#Finnish) | taste, flavor | /ˈmɑku/ · noun |
| [perjantai](https://en.wiktionary.org/wiki/perjantai#Finnish) | Friday (day of the week; the fifth day of the week in Finland and in the ISO 8601 standard) | /ˈperjɑntɑi̯/ · noun |
| [plus](https://en.wiktionary.org/wiki/plus#Finnish) | plus | /ˈplus/ · conj |
| [seksi](https://en.wiktionary.org/wiki/seksi#Finnish) | sex (sexual intercourse) | /ˈseksi/ · noun |
| [tuhat](https://en.wiktionary.org/wiki/tuhat#Finnish) | thousand | /ˈtuhɑt/ · num |
| [valo](https://en.wiktionary.org/wiki/valo#Finnish) | light (visible electromagnetic radiation) | /ˈʋɑlo/ · noun |
| [aamu](https://en.wiktionary.org/wiki/aamu#Finnish) | morning | /ˈɑːmu/ · noun |
| [city](https://en.wiktionary.org/wiki/city#Finnish) | synonym of liikekeskusta (“central business district”) (central area of a city) | /ˈsiti/ · noun |

</details>

<details><summary>Words 351–400</summary>

![[Resources/Audio/fi/Words 0351-0400.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [hyväksyä](https://en.wiktionary.org/wiki/hyv%C3%A4ksy%C3%A4#Finnish) | to accept, approve of, agree with (consider something acceptable) | /ˈhyʋæksyæˣ/ · verb |
| [ilma](https://en.wiktionary.org/wiki/ilma#Finnish) | air | /ˈilmɑ/ · noun |
| [ilo](https://en.wiktionary.org/wiki/ilo#Finnish) | joy, happiness, delight, merriment, mirth | /ˈilo/ · noun |
| [kääntää](https://en.wiktionary.org/wiki/k%C3%A4%C3%A4nt%C3%A4%C3%A4#Finnish) | to turn, reorient (change the direction or orientation of); to turn (around), reverse, invert | /ˈkæːntæːˣ/ · verb |
| [laulaja](https://en.wiktionary.org/wiki/laulaja#Finnish) | singer | /ˈlɑu̯lɑjɑ/ · noun |
| [nukkua](https://en.wiktionary.org/wiki/nukkua#Finnish) | to sleep | /ˈnukːuɑˣ/ · verb |
| [positiivinen](https://en.wiktionary.org/wiki/positiivinen#Finnish) | positive (favorable, desirable) | /ˈpositiːʋinen/ · adj |
| [ranska](https://en.wiktionary.org/wiki/ranska#Finnish) | French (language) | /ˈrɑnskɑ/ · noun |
| [vakava](https://en.wiktionary.org/wiki/vakava#Finnish) | serious, earnest | /ˈʋɑkɑʋɑ/ · adj |
| [juoda](https://en.wiktionary.org/wiki/juoda#Finnish) | to drink | /ˈjuo̯dɑˣ/ · verb |
| [maksa](https://en.wiktionary.org/wiki/maksa#Finnish) | liver | /ˈmɑksɑ/ · noun |
| [rock](https://en.wiktionary.org/wiki/rock#Finnish) | rock (style of music) | /ˈrok/ · noun |
| [show](https://en.wiktionary.org/wiki/show#Finnish) | show (entertainment) | /ˈʃou̯/ · noun |
| [terve](https://en.wiktionary.org/wiki/terve#Finnish) | healthy, sane (enjoying health and vigor of body, mind, or spirit) | /ˈterʋeˣ/ · adj |
| [väri](https://en.wiktionary.org/wiki/v%C3%A4ri#Finnish) | color (particular set of the visible spectrum) | /ˈʋæri/ · noun |
| [kulta](https://en.wiktionary.org/wiki/kulta#Finnish) | gold (metal; chemical element Au) | /ˈkultɑ/ · noun |
| [lauantai](https://en.wiktionary.org/wiki/lauantai#Finnish) | Saturday (day of the week; the sixth day of the week in Finland and in the ISO 8601 standard) | /ˈlɑu̯.ɑntɑi̯/ · noun |
| [nauraa](https://en.wiktionary.org/wiki/nauraa#Finnish) | to laugh | /ˈnɑu̯rɑːˣ/ · verb |
| [tuuli](https://en.wiktionary.org/wiki/tuuli#Finnish) | wind (movement of air) | /ˈtuːli/ · noun |
| [valmistaa](https://en.wiktionary.org/wiki/valmistaa#Finnish) | to make, prepare | /ˈʋɑlmistɑːˣ/ · verb |
| [edellinen](https://en.wiktionary.org/wiki/edellinen#Finnish) | previous | /ˈedelːinen/ · adj |
| [laulaa](https://en.wiktionary.org/wiki/laulaa#Finnish) | to sing | /ˈlɑu̯lɑːˣ/ · verb |
| [lupa](https://en.wiktionary.org/wiki/lupa#Finnish) | permission | /ˈlupɑ/ · noun |
| [lämmin](https://en.wiktionary.org/wiki/l%C3%A4mmin#Finnish) | warm | /ˈlæmːin/ · adj |
| [oi](https://en.wiktionary.org/wiki/oi#Finnish) | O, oh | /ˈoi̯/ · intj |
| [pinta-ala](https://en.wiktionary.org/wiki/pinta-ala#Finnish) | area | /ˈpintɑˌ(ʔ)ɑlɑ/ · noun |
| [pituus](https://en.wiktionary.org/wiki/pituus#Finnish) | length (distance measured along the longest dimension of an object) | /ˈpituːs/ · noun |
| [sininen](https://en.wiktionary.org/wiki/sininen#Finnish) | blue | /ˈsininen/ · adj |
| [voimakas](https://en.wiktionary.org/wiki/voimakas#Finnish) | powerful, intense, potent | /ˈʋoi̯mɑkɑs/ · adj |
| [alus](https://en.wiktionary.org/wiki/alus#Finnish) | underlay, base, under- (anything underlaid) | /ˈɑlus/ · noun |
| [käyttäjä](https://en.wiktionary.org/wiki/k%C3%A4ytt%C3%A4j%C3%A4#Finnish) | user | /ˈkæy̯tːæjæ/ · noun |
| [sauna](https://en.wiktionary.org/wiki/sauna#Finnish) | sauna | /ˈsɑu̯nɑ/ · noun |
| [tavata](https://en.wiktionary.org/wiki/tavata#Finnish) | to meet (come face to face with) | /ˈtɑʋɑtɑˣ/ · verb |
| [arvio](https://en.wiktionary.org/wiki/arvio#Finnish) | estimate, assessment, evaluation | /ˈɑrʋio/ · noun |
| [henry](https://en.wiktionary.org/wiki/henry#Finnish) | henry (unit of inductance) | /ˈhenry/ · noun |
| [hotelli](https://en.wiktionary.org/wiki/hotelli#Finnish) | hotel (establishment providing accommodation) | /ˈhotelːi/ · noun |
| [muuttua](https://en.wiktionary.org/wiki/muuttua#Finnish) | to change, alter (become different) | /ˈmuːtːuɑˣ/ · verb |
| [pomo](https://en.wiktionary.org/wiki/pomo#Finnish) | boss | /ˈpomo/ · noun |
| [teos](https://en.wiktionary.org/wiki/teos#Finnish) | work (of art), oeuvre, opus (literary, artistic, or intellectual production) | /ˈteos/ · noun |
| [juna](https://en.wiktionary.org/wiki/juna#Finnish) | train (railroad vehicle) | /ˈjunɑ/ · noun |
| [kukin](https://en.wiktionary.org/wiki/kukin#Finnish) | each | /ˈkukin/ · pron |
| [pop](https://en.wiktionary.org/wiki/pop#Finnish) | pop (popular) | /ˈpop/ · adj |
| [pelko](https://en.wiktionary.org/wiki/pelko#Finnish) | fear, dread | /ˈpelko/ · noun |
| [piste](https://en.wiktionary.org/wiki/piste#Finnish) | point, dot, full stop, period | /ˈpisteˣ/ · noun |
| [pyhä](https://en.wiktionary.org/wiki/pyh%C3%A4#Finnish) | holy, sacred | /ˈpyhæ/ · adj |
| [rikos](https://en.wiktionary.org/wiki/rikos#Finnish) | crime, offence/offense, criminality (criminal act) | /ˈrikos/ · noun |
| [suunnitelma](https://en.wiktionary.org/wiki/suunnitelma#Finnish) | plan (set of intended actions through which one expects to achieve a goal) | /ˈsuːnːitelmɑ/ · noun |
| [go](https://en.wiktionary.org/wiki/go#Finnish) | go (game) | /ˈɡoː/ · noun |
| [kamera](https://en.wiktionary.org/wiki/kamera#Finnish) | camera | /ˈkɑmerɑ/ · noun |
| [kela](https://en.wiktionary.org/wiki/kela#Finnish) | reel, spool, bobbin (device around which thread, wire, cable or something similar is wound) | /ˈkelɑ/ · noun |

</details>

<details><summary>Words 401–450</summary>

![[Resources/Audio/fi/Words 0401-0450.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [leikata](https://en.wiktionary.org/wiki/leikata#Finnish) | to cut (divide with a sharp instrument) | /ˈlei̯kɑtɑˣ/ · verb |
| [palkinto](https://en.wiktionary.org/wiki/palkinto#Finnish) | prize, award, reward | /ˈpɑlkinto/ · noun |
| [talvi](https://en.wiktionary.org/wiki/talvi#Finnish) | winter | /ˈtɑlʋi/ · noun |
| [euro](https://en.wiktionary.org/wiki/euro#Finnish) | euro (currency) | /ˈeu̯ro/ · noun |
| [huutaa](https://en.wiktionary.org/wiki/huutaa#Finnish) | to shout, yell, holler | /ˈhuːtɑːˣ/ · verb |
| [kuolla](https://en.wiktionary.org/wiki/kuolla#Finnish) | to die [with illative ‘of/from’] (cease to live) | /ˈkuo̯lːɑˣ/ · verb |
| [moottori](https://en.wiktionary.org/wiki/moottori#Finnish) | engine, motor | /ˈmoːtːori/ · noun |
| [rakastaa](https://en.wiktionary.org/wiki/rakastaa#Finnish) | to love | /ˈrɑkɑstɑːˣ/ · verb |
| [satu](https://en.wiktionary.org/wiki/satu#Finnish) | fairy tale | /ˈsɑtu/ · noun |
| [summa](https://en.wiktionary.org/wiki/summa#Finnish) | sum (result of addition) | /ˈsumːɑ/ · noun |
| [ajo](https://en.wiktionary.org/wiki/ajo#Finnish) | driving | /ˈɑjo/ · noun |
| [istua](https://en.wiktionary.org/wiki/istua#Finnish) | to sit, be sitting | /ˈistuɑˣ/ · verb |
| [mahdoton](https://en.wiktionary.org/wiki/mahdoton#Finnish) | impossible | /ˈmɑhdoton/ · adj |
| [tehokas](https://en.wiktionary.org/wiki/tehokas#Finnish) | powerful, potent | /ˈtehokɑs/ · adj |
| [aivot](https://en.wiktionary.org/wiki/aivot#Finnish) | brain (organ) | /ˈɑi̯ʋot/ · noun |
| [englanti](https://en.wiktionary.org/wiki/englanti#Finnish) | English (language) | /ˈeŋlɑnti/ · noun |
| [hevonen](https://en.wiktionary.org/wiki/hevonen#Finnish) | horse, Equus caballus | /ˈheʋonen/ · noun |
| [lento](https://en.wiktionary.org/wiki/lento#Finnish) | flying, flight (act of flying or being in the air) | /ˈlento/ · noun |
| [lippu](https://en.wiktionary.org/wiki/lippu#Finnish) | flag, banner | /ˈlipːu/ · noun |
| [ovi](https://en.wiktionary.org/wiki/ovi#Finnish) | door (portal of entry into a building, room, or vehicle) | /ˈoʋi/ · noun |
| [sunnuntai](https://en.wiktionary.org/wiki/sunnuntai#Finnish) | Sunday (day of the week; the seventh and last day of the week in Finland and in the ISO 8601 standard) | /ˈsunːuntɑi̯/ · noun |
| [veto](https://en.wiktionary.org/wiki/veto#Finnish) | pull (act of pulling) | /ˈʋeto/ · noun |
| [Ay](https://en.wiktionary.org/wiki/Ay#Finnish) | An unofficial abbreviation of avoin yhtiö (“general partnership”) |  · noun |
| [ase](https://en.wiktionary.org/wiki/ase#Finnish) | weapon (also figuratively) | /ˈɑseˣ/ · noun |
| [blues](https://en.wiktionary.org/wiki/blues#Finnish) | blues (musical genre of African American origin) | /ˈbluːs/ · noun |
| [data](https://en.wiktionary.org/wiki/data#Finnish) | data | /ˈdɑtɑ/ · noun |
| [karhu](https://en.wiktionary.org/wiki/karhu#Finnish) | bear (large omnivorous mammal of the family Ursidae) | /ˈkɑrhu/ · noun |
| [loma](https://en.wiktionary.org/wiki/loma#Finnish) | holiday, vacation | /ˈlomɑ/ · noun |
| [nälkä](https://en.wiktionary.org/wiki/n%C3%A4lk%C3%A4#Finnish) | hunger (need for food) | /ˈnælkæ/ · noun |
| [paita](https://en.wiktionary.org/wiki/paita#Finnish) | shirt (article of clothing) | /ˈpɑi̯tɑ/ · noun |
| [taide](https://en.wiktionary.org/wiki/taide#Finnish) | art (conscious production or arrangement of elements; skillful creative activity; aesthetic value; field or category of art) | /ˈtɑi̯deˣ/ · noun |
| [tuntea](https://en.wiktionary.org/wiki/tuntea#Finnish) | to feel, sense (sense by touch) | /ˈtunteɑˣ/ · verb |
| [vaarallinen](https://en.wiktionary.org/wiki/vaarallinen#Finnish) | dangerous, hazardous | /ˈʋɑːrɑlːinen/ · adj |
| [ylittää](https://en.wiktionary.org/wiki/ylitt%C3%A4%C3%A4#Finnish) | to go over, cross | /ˈylitːæːˣ/ · verb |
| [housut](https://en.wiktionary.org/wiki/housut#Finnish) | trousers, pants | /ˈhou̯sut/ · noun |
| [joulu](https://en.wiktionary.org/wiki/joulu#Finnish) | Christmas | /ˈjou̯lu/ · noun |
| [kivi](https://en.wiktionary.org/wiki/kivi#Finnish) | a piece of stone which is larger than a grain of sand | /ˈkiʋi/ · noun |
| [komea](https://en.wiktionary.org/wiki/komea#Finnish) | handsome (beautiful, especially of a man) | /ˈkomeɑ/ · adj |
| [about](https://en.wiktionary.org/wiki/about#Finnish) | about (around, approximately, roughly) | /ˈøbɑu̯t/ · adv |
| [asu](https://en.wiktionary.org/wiki/asu#Finnish) | attire, dress, suit, raiment, costume, outfit | /ˈɑsu/ · noun |
| [formula](https://en.wiktionary.org/wiki/formula#Finnish) | a Formula One racing car | /ˈformulɑ/ · noun |
| [halpa](https://en.wiktionary.org/wiki/halpa#Finnish) | cheap, inexpensive, low-end (low in price) | /ˈhɑlpɑ/ · adj |
| [haluta](https://en.wiktionary.org/wiki/haluta#Finnish) | to want, desire, wish, crave | /ˈhɑlutɑˣ/ · verb |
| [japani](https://en.wiktionary.org/wiki/japani#Finnish) | Japanese language | /ˈjɑpɑni/ · noun |
| [korvata](https://en.wiktionary.org/wiki/korvata#Finnish) | to replace, substitute | /ˈkorʋɑtɑˣ/ · verb |
| [kumpikin](https://en.wiktionary.org/wiki/kumpikin#Finnish) | both | /ˈkumpikin/ · pron |
| [sisko](https://en.wiktionary.org/wiki/sisko#Finnish) | sister | /ˈsisko/ · noun |
| [syksy](https://en.wiktionary.org/wiki/syksy#Finnish) | autumn, fall (season of the year) | /ˈsyksy/ · noun |
| [tuore](https://en.wiktionary.org/wiki/tuore#Finnish) | fresh (new or clean) | /ˈtuo̯reˣ/ · adj |
| [vauva](https://en.wiktionary.org/wiki/vauva#Finnish) | baby (a very young child) | /ˈʋɑu̯ʋɑ/ · noun |

</details>

<details><summary>Words 451–500</summary>

![[Resources/Audio/fi/Words 0451-0500.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [ha](https://en.wiktionary.org/wiki/ha#Finnish) | ha! (a representation of laughter) | /ˈhɑ/ · intj |
| [liikkua](https://en.wiktionary.org/wiki/liikkua#Finnish) | to move, stir (change places, change one's location or position) | /ˈliːkːuɑˣ/ · verb |
| [norja](https://en.wiktionary.org/wiki/norja#Finnish) | lithe (capable of being easily bent) | /ˈnorjɑ/ · adj |
| [olut](https://en.wiktionary.org/wiki/olut#Finnish) | beer, ale (fermented beverage made of malt, originally barley, but also other cereals are used) | /ˈolut/ · noun |
| [pala](https://en.wiktionary.org/wiki/pala#Finnish) | piece, bit, part, lump, chunk | /ˈpɑlɑ/ · noun |
| [puu](https://en.wiktionary.org/wiki/puu#Finnish) | tree (large woody plant) | /ˈpuː/ · noun |
| [taivas](https://en.wiktionary.org/wiki/taivas#Finnish) | sky | /ˈtɑi̯ʋɑs/ · noun |
| [turvallinen](https://en.wiktionary.org/wiki/turvallinen#Finnish) | safe (free from risk; harmless, riskless) | /ˈturʋɑlːinen/ · adj |
| [DNA](https://en.wiktionary.org/wiki/DNA#Finnish) | DNA | /ˈdeːˌænˌɑː/ · noun |
| [cup](https://en.wiktionary.org/wiki/cup#Finnish) | cup (contest) | /ˈkɑp/ · noun |
| [jalka](https://en.wiktionary.org/wiki/jalka#Finnish) | foot, leg; a lower supporting limb of a human or animal | /ˈjɑlkɑ/ · noun |
| [kevät](https://en.wiktionary.org/wiki/kev%C3%A4t#Finnish) | spring, springtime (season of the year) | /ˈkeʋæt/ · noun |
| [kuningatar](https://en.wiktionary.org/wiki/kuningatar#Finnish) | queen (something or someone outstanding or supreme among its kind) | /ˈkuniŋːɑtɑr/ · noun |
| [viro](https://en.wiktionary.org/wiki/viro#Finnish) | Estonian (language) | /ˈʋiro/ · noun |
| [mari](https://en.wiktionary.org/wiki/mari#Finnish) | Mari (person) | /ˈmɑri/ · noun |
| [meri](https://en.wiktionary.org/wiki/meri#Finnish) | sea (a single area or the seas altogether) | /ˈmeri/ · noun |
| [nolla](https://en.wiktionary.org/wiki/nolla#Finnish) | zero | /ˈnolːɑ/ · num |
| [otto](https://en.wiktionary.org/wiki/otto#Finnish) | taking (act or action of taking) | /ˈotːo/ · noun |
| [turkki](https://en.wiktionary.org/wiki/turkki#Finnish) | fur (hairy coat of various mammal species) | /ˈturkːi/ · noun |
| [uskomaton](https://en.wiktionary.org/wiki/uskomaton#Finnish) | unbelievable, incredible | /ˈuskomɑton/ · adj |
| [kallis](https://en.wiktionary.org/wiki/kallis#Finnish) | expensive | /ˈkɑlːis/ · adj |
| [kevyt](https://en.wiktionary.org/wiki/kevyt#Finnish) | light, lightweight (low in weight; not heavy) | /ˈkeʋyt/ · adj |
| [kisa](https://en.wiktionary.org/wiki/kisa#Finnish) | competition, games | /ˈkisɑ/ · noun |
| [moi](https://en.wiktionary.org/wiki/moi#Finnish) | hi, hello | /ˈmoi̯/ · intj |
| [sulkea](https://en.wiktionary.org/wiki/sulkea#Finnish) | to close, shut (a door, gate, box, buttons, book, valve, umbrella, etc.) (make nonpassable; make denser, more compact) | /ˈsulkeɑˣ/ · verb |
| [viides](https://en.wiktionary.org/wiki/viides#Finnish) | fifth | /ˈʋiːdes/ · adj |
| [huh](https://en.wiktionary.org/wiki/huh#Finnish) | phew (used to show relief, fatigue, or surprise) | /ˈhuh/ · intj |
| [juosta](https://en.wiktionary.org/wiki/juosta#Finnish) | to run (move swiftly) | /ˈjuo̯stɑˣ/ · verb |
| [kala](https://en.wiktionary.org/wiki/kala#Finnish) | fish (aquatic animal) | /ˈkɑlɑ/ · noun |
| [kävellä](https://en.wiktionary.org/wiki/k%C3%A4vell%C3%A4#Finnish) | to walk (move on the feet; travel by moving on the feet) | /ˈkæʋelːæˣ/ · verb |
| [some](https://en.wiktionary.org/wiki/some#Finnish) | social media | /ˈsome/ · noun |
| [bussi](https://en.wiktionary.org/wiki/bussi#Finnish) | bus (vehicle) | /ˈbusːi/ · noun |
| [sähkö](https://en.wiktionary.org/wiki/s%C3%A4hk%C3%B6#Finnish) | electricity (form of energy or power) | /ˈsæhkø/ · noun |
| [virta](https://en.wiktionary.org/wiki/virta#Finnish) | flow, stream, current | /ˈʋirtɑ/ · noun |
| [house](https://en.wiktionary.org/wiki/house#Finnish) | house music, house (a genre of music) | /ˈhɑu̯s/ · noun |
| [sopia](https://en.wiktionary.org/wiki/sopia#Finnish) | to fit [with allative] (to be of the correct size and shape; to be capable of being put into or passing through something; to be not too big) | /ˈsopiɑˣ/ · verb |
| [vero](https://en.wiktionary.org/wiki/vero#Finnish) | tax (money paid to the government) | /ˈʋero/ · noun |
| [iho](https://en.wiktionary.org/wiki/iho#Finnish) | skin (of a human being) | /ˈiho/ · noun |
| [kreikka](https://en.wiktionary.org/wiki/kreikka#Finnish) | Greek (language) | /ˈkrei̯kːɑ/ · noun |
| [lee](https://en.wiktionary.org/wiki/lee#Finnish) | lee (side of the ship away from the wind) | /ˈleː/ · noun |
| [maine](https://en.wiktionary.org/wiki/maine#Finnish) | reputation | /ˈmɑi̯neˣ/ · noun |
| [nopeus](https://en.wiktionary.org/wiki/nopeus#Finnish) | velocity (vector quantity that denotes the rate of change of position with respect to time) | /ˈnopeus/ · noun |
| [tiede](https://en.wiktionary.org/wiki/tiede#Finnish) | science (collective discipline of learning, including the liberal arts or humanities) | /ˈtie̯deˣ/ · noun |
| [uskonto](https://en.wiktionary.org/wiki/uskonto#Finnish) | religion | /ˈuskonto/ · noun |
| [ah](https://en.wiktionary.org/wiki/ah#Finnish) | oh, ah | /ˈɑh/ · intj |
| [heh](https://en.wiktionary.org/wiki/heh#Finnish) | heh (short chuckle or laugh) | /ˈheh/ · intj |
| [keltainen](https://en.wiktionary.org/wiki/keltainen#Finnish) | yellow (color) | /ˈkeltɑi̯nen/ · adj |
| [ketju](https://en.wiktionary.org/wiki/ketju#Finnish) | chain (series of interconnected rings or links usually made of metal) | /ˈketju/ · noun |
| [lahja](https://en.wiktionary.org/wiki/lahja#Finnish) | present, gift | /ˈlɑhjɑ/ · noun |
| [maanantai](https://en.wiktionary.org/wiki/maanantai#Finnish) | Monday (day of the week; the first day of the week in Finland and in the ISO 8601 standard) | /ˈmɑːnɑntɑi̯/ · noun |

</details>

<details><summary>Words 501–550</summary>

![[Resources/Audio/fi/Words 0501-0550.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [out](https://en.wiktionary.org/wiki/out#Finnish) | out (no longer popular or in fashion) | /ˈɑu̯t/ · adv |
| [panna](https://en.wiktionary.org/wiki/panna#Finnish) | to put, set, place | /ˈpɑnːɑˣ/ · verb |
| [saari](https://en.wiktionary.org/wiki/saari#Finnish) | island (contiguous area of land, smaller than a continent, totally surrounded by water) | /ˈsɑːri/ · noun |
| [tauti](https://en.wiktionary.org/wiki/tauti#Finnish) | disease (abnormal condition of the body causing discomfort or dysfunction) | /ˈtɑu̯ti/ · noun |
| [teho](https://en.wiktionary.org/wiki/teho#Finnish) | power, effect, effectivity, effectiveness | /ˈteho/ · noun |
| [tietokone](https://en.wiktionary.org/wiki/tietokone#Finnish) | computer (programmable electronic device) | /ˈtie̯toˌkoneˣ/ · noun |
| [erota](https://en.wiktionary.org/wiki/erota#Finnish) | to part, separate, diverge (run apart; leave the company of; disunite from a group or mass) | /ˈerotɑˣ/ · verb |
| [laine](https://en.wiktionary.org/wiki/laine#Finnish) | wave | /ˈlɑi̯neˣ/ · noun |
| [laiva](https://en.wiktionary.org/wiki/laiva#Finnish) | ship ((large) water vessel) | /ˈlɑi̯ʋɑ/ · noun |
| [matala](https://en.wiktionary.org/wiki/matala#Finnish) | low (small in height) | /ˈmɑtɑlɑ/ · adj |
| [mäki](https://en.wiktionary.org/wiki/m%C3%A4ki#Finnish) | hill (a relatively large, usually rounded elevation of earth; generally larger than kukkula (“hill, hillock”) and smaller than vuori (“mountain”)) | /ˈmæki/ · noun |
| [näyttö](https://en.wiktionary.org/wiki/n%C3%A4ytt%C3%B6#Finnish) | showing (occasion when something is shown, particularly something that is for sale) | /ˈnæy̯tːø/ · noun |
| [rauha](https://en.wiktionary.org/wiki/rauha#Finnish) | peace, harmony, calm (state of tranquility, quiet, and harmony) | /ˈrɑu̯hɑ/ · noun |
| [tuhota](https://en.wiktionary.org/wiki/tuhota#Finnish) | to destroy (damage beyond use or repair) | /ˈtuhotɑˣ/ · verb |
| [vasen](https://en.wiktionary.org/wiki/vasen#Finnish) | left (on the left side) | /ˈʋɑsen/ · adj |
| [öljy](https://en.wiktionary.org/wiki/%C3%B6ljy#Finnish) | synonym of ruokaöljy (“oil, liquid fat”) | /ˈøljy/ · noun |
| [bändi](https://en.wiktionary.org/wiki/b%C3%A4ndi#Finnish) | band, group, orchestra | /ˈbændi/ · noun |
| [kahvi](https://en.wiktionary.org/wiki/kahvi#Finnish) | coffee (beverage made by infusing the beans of the coffee plant) | /ˈkɑhʋi/ · noun |
| [kumpikaan](https://en.wiktionary.org/wiki/kumpikaan#Finnish) | (not) either, neither | /ˈkumpikɑːn/ · pron |
| [sankari](https://en.wiktionary.org/wiki/sankari#Finnish) | hero, heroine | /ˈsɑŋkɑri/ · noun |
| [suo](https://en.wiktionary.org/wiki/suo#Finnish) | swamp, bog, marsh, mire | /ˈsuo̯/ · noun |
| [surullinen](https://en.wiktionary.org/wiki/surullinen#Finnish) | sad, sorrowful | /ˈsurulːinen/ · adj |
| [testata](https://en.wiktionary.org/wiki/testata#Finnish) | to test | /ˈtestɑtɑˣ/ · verb |
| [web](https://en.wiktionary.org/wiki/web#Finnish) | synonym of verkko (“web, www”) | /ˈʋeb/ · noun |
| [kielioppi](https://en.wiktionary.org/wiki/kielioppi) | grammar |  · noun |
| [ali](https://en.wiktionary.org/wiki/ali#Finnish) | beneath, underneath (through the space that is underneath something) | /ˈɑli/ · postp |
| [kuorma-auto](https://en.wiktionary.org/wiki/kuorma-auto#Finnish) | truck, lorry (heavier motor vehicle designed to carry goods or to pull a semi-trailer designed to carry goods) | /ˈkuo̯rmɑˌ(ʔ)ɑu̯to/ · noun |
| [teoria](https://en.wiktionary.org/wiki/teoria#Finnish) | theory | /ˈteoriɑ/ · noun |
| [demokratia](https://en.wiktionary.org/wiki/demokratia#Finnish) | democracy | /ˈdemoˌkrɑtiɑ/ · noun |
| [golf](https://en.wiktionary.org/wiki/golf#Finnish) | golf | /ˈɡolf/ · noun |
| [harmaa](https://en.wiktionary.org/wiki/harmaa#Finnish) | grey, gray (colour) | /ˈhɑrmɑː/ · adj |
| [hmm](https://en.wiktionary.org/wiki/hmm#Finnish) | hmm | [m̥m̩˦˨] · intj |
| [home](https://en.wiktionary.org/wiki/home#Finnish) | mold, mildew (furry or woolly growth of tiny fungi) | /ˈhomeˣ/ · noun |
| [huone](https://en.wiktionary.org/wiki/huone#Finnish) | room (separate part of a building, enclosed by walls, a floor and a ceiling) | /ˈhuo̯neˣ/ · noun |
| [italia](https://en.wiktionary.org/wiki/italia#Finnish) | Italian (Romance language) | /ˈitɑliɑ/ · noun |
| [kamala](https://en.wiktionary.org/wiki/kamala#Finnish) | horrible, terrible, awful, ghastly | /ˈkɑmɑlɑ/ · adj |
| [kartta](https://en.wiktionary.org/wiki/kartta#Finnish) | map (visual representation of an area) | /ˈkɑrtːɑ/ · noun |
| [luokka](https://en.wiktionary.org/wiki/luokka#Finnish) | class (group, collection, category or set sharing characteristics or attributes) | /ˈluo̯kːɑ/ · noun |
| [online](https://en.wiktionary.org/wiki/online#Finnish) | online (used also as modifier in compound terms, often with a hyphen and as an uninflected attribute) | /ˈonlɑi̯n/ · adv |
| [paistaa](https://en.wiktionary.org/wiki/paistaa#Finnish) | to fry (cook in hot fat or oil) | /ˈpɑi̯stɑːˣ/ · verb |
| [säätää](https://en.wiktionary.org/wiki/s%C3%A4%C3%A4t%C3%A4%C3%A4#Finnish) | to enact; prescribe, ordain, decree | /ˈsæːtæːˣ/ · verb |
| [hidas](https://en.wiktionary.org/wiki/hidas#Finnish) | slow (at a low speed; not fast, not quick) | /ˈhidɑs/ · adj |
| [käännös](https://en.wiktionary.org/wiki/k%C3%A4%C3%A4nn%C3%B6s#Finnish) | turn (change of direction or orientation) | /ˈkæːnːøs/ · noun |
| [lintu](https://en.wiktionary.org/wiki/lintu#Finnish) | bird (animal in the class Aves, having a beaked mouth and usually capable of flight) | /ˈlintu/ · noun |
| [sairas](https://en.wiktionary.org/wiki/sairas#Finnish) | ill, sick | /ˈsɑi̯rɑs/ · adj |
| [studio](https://en.wiktionary.org/wiki/studio#Finnish) | studio (workshop) | /ˈstudio/ · noun |
| [taito](https://en.wiktionary.org/wiki/taito#Finnish) | skill (capacity to do something well, particularly one that is acquired or learned) | /ˈtɑi̯to/ · noun |
| [televisio](https://en.wiktionary.org/wiki/televisio#Finnish) | television | /ˈteleˌʋisio/ · noun |
| [design](https://en.wiktionary.org/wiki/design#Finnish) | design | /ˈdisɑi̯n/ · noun |
| [espanja](https://en.wiktionary.org/wiki/espanja#Finnish) | Spanish (language) | /ˈespɑnjɑ/ · noun |

</details>

<details><summary>Words 551–600</summary>

![[Resources/Audio/fi/Words 0551-0600.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [ladata](https://en.wiktionary.org/wiki/ladata#Finnish) | to load | /ˈlɑdɑtɑˣ/ · verb |
| [suu](https://en.wiktionary.org/wiki/suu#Finnish) | mouth (organ) | /ˈsuː/ · noun |
| [islam](https://en.wiktionary.org/wiki/islam#Finnish) | Islam (religion) | /ˈislɑm/ · noun |
| [kylä](https://en.wiktionary.org/wiki/kyl%C3%A4#Finnish) | village (rural habitation smaller than a town) | /ˈkylæ/ · noun |
| [paine](https://en.wiktionary.org/wiki/paine#Finnish) | pressure (force over surface) | /ˈpɑi̯neˣ/ · noun |
| [rata](https://en.wiktionary.org/wiki/rata#Finnish) | route, path, road | /ˈrɑtɑ/ · noun |
| [rauhallinen](https://en.wiktionary.org/wiki/rauhallinen#Finnish) | peaceful, quiet, restful, serene, tranquil, calm | /ˈrɑu̯hɑlːinen/ · adj |
| [rauhallisesti](https://en.wiktionary.org/wiki/rauhallisesti#Finnish) | in a calm manner; calmly | /ˈrɑu̯hɑlːisestiˣ/ · adv |
| [susi](https://en.wiktionary.org/wiki/susi#Finnish) | wolf | /ˈsusi/ · noun |
| [todellisuus](https://en.wiktionary.org/wiki/todellisuus#Finnish) | reality | /ˈtodelːisuːs/ · noun |
| [ampua](https://en.wiktionary.org/wiki/ampua#Finnish) | to shoot, fire (fire a projectile or a weapon that fires a projectile) | /ˈɑmpuɑˣ/ · verb |
| [kirje](https://en.wiktionary.org/wiki/kirje#Finnish) | letter (a written message) | /ˈkirjeˣ/ · noun |
| [kotka](https://en.wiktionary.org/wiki/kotka#Finnish) | eagle (any of several large carnivorous and carrion-eating birds in the family Accipitridae, having a powerful hooked bill and keen vision) | /ˈkotkɑ/ · noun |
| [oho](https://en.wiktionary.org/wiki/oho#Finnish) | oops, whoops-a-daisy (acknowledgment of minor mistake) | /ˈoho/ · intj |
| [raskas](https://en.wiktionary.org/wiki/raskas#Finnish) | heavy (having great weight) | /ˈrɑskɑs/ · adj |
| [sari](https://en.wiktionary.org/wiki/sari#Finnish) | sari (Indian piece of clothing) | /ˈsɑri/ · noun |
| [tavan](https://en.wiktionary.org/wiki/tavan#Finnish) | ordinary, usual, normal, conventional | /ˈtɑʋɑn/ · adj |
| [tumma](https://en.wiktionary.org/wiki/tumma#Finnish) | dark (of colour) | /ˈtumːɑ/ · adj |
| [metro](https://en.wiktionary.org/wiki/metro#Finnish) | a metro, an underground, a subway, a Tube | /ˈmetro/ · noun |
| [ruma](https://en.wiktionary.org/wiki/ruma#Finnish) | ugly (displeasing to the eye or ear) | /ˈrumɑ/ · adj |
| [suvi](https://en.wiktionary.org/wiki/suvi#Finnish) | summer | /ˈsuʋi/ · noun |
| [tiistai](https://en.wiktionary.org/wiki/tiistai#Finnish) | Tuesday (day of the week; the second day of the week in Finland and in the ISO 8601 standard) | /ˈtiːstɑi̯/ · noun |
| [ydin](https://en.wiktionary.org/wiki/ydin#Finnish) | core, kernel, nucleus, the central part of something | /ˈydin/ · noun |
| [alko](https://en.wiktionary.org/wiki/alko#Finnish) | liquor store, bottle shop | /ˈɑlko/ · noun |
| [korea](https://en.wiktionary.org/wiki/korea#Finnish) | beautiful, decorated, pretty | /ˈkoreɑ/ · adj |
| [natsi](https://en.wiktionary.org/wiki/natsi#Finnish) | a Nazi | /ˈnɑtsi/ · noun |
| [puola](https://en.wiktionary.org/wiki/puola#Finnish) | bobbin (small spool) | /ˈpuo̯lɑ/ · noun |
| [saudi](https://en.wiktionary.org/wiki/saudi#Finnish) | Saudi | /ˈsɑu̯di/ · noun |
| [setä](https://en.wiktionary.org/wiki/set%C3%A4#Finnish) | paternal uncle, uncle | /ˈsetæ/ · noun |
| [CD](https://en.wiktionary.org/wiki/CD#Finnish) | CD, compact disc | /ˈseːˌdeː/ · noun |
| [katto](https://en.wiktionary.org/wiki/katto#Finnish) | ceiling (overhead closure of room) | /ˈkɑtːo/ · noun |
| [kuu](https://en.wiktionary.org/wiki/kuu#Finnish) | the moon (the Earth's moon) | /ˈkuː/ · noun |
| [massa](https://en.wiktionary.org/wiki/massa#Finnish) | mass (quantity of matter cohering together to make one body) | /ˈmɑsːɑ/ · noun |
| [niemi](https://en.wiktionary.org/wiki/niemi#Finnish) | cape, ness, headland, promontory, (small) peninsula (form of coastal land jutting into a lake or sea) | /ˈnie̯mi/ · noun |
| [rikkoa](https://en.wiktionary.org/wiki/rikkoa#Finnish) | to break (separate into pieces; destroy the continuity of; abruptly change a steady state; cause to stop functioning) | /ˈrikːoɑˣ/ · verb |
| [silta](https://en.wiktionary.org/wiki/silta#Finnish) | bridge (construction or natural feature that spans a divide) | /ˈsiltɑ/ · noun |
| [tanska](https://en.wiktionary.org/wiki/tanska#Finnish) | Danish (language) | /ˈtɑnskɑ/ · noun |
| [ties](https://en.wiktionary.org/wiki/ties#Finnish) | God knows, who knows | /ˈtie̯s/ · adv |
| [kenttä](https://en.wiktionary.org/wiki/kentt%C3%A4#Finnish) | field (land area free of woodland, cities, and towns; open country) | /ˈkentːæ/ · noun |
| [palo](https://en.wiktionary.org/wiki/palo#Finnish) | fire (event of something burning, an occurrence of fire) | /ˈpɑlo/ · noun |
| [uni](https://en.wiktionary.org/wiki/uni#Finnish) | sleep (state of reduced consciousness) | /ˈuni/ · noun |
| [anti](https://en.wiktionary.org/wiki/anti#Finnish) | offering, issue (of shares, bonds etc.) | /ˈɑnti/ · noun |
| [hypätä](https://en.wiktionary.org/wiki/hyp%C3%A4t%C3%A4#Finnish) | to jump, leap (usually once) | /ˈhypætæˣ/ · verb |
| [kate](https://en.wiktionary.org/wiki/kate#Finnish) | covering, roofing (something used to cover or roof) | /ˈkɑteˣ/ · noun |
| [katse](https://en.wiktionary.org/wiki/katse#Finnish) | look, glance, gaze | /ˈkɑtseˣ/ · noun |
| [kumma](https://en.wiktionary.org/wiki/kumma#Finnish) | odd, strange | /ˈkumːɑ/ · adj |
| [lainata](https://en.wiktionary.org/wiki/lainata#Finnish) | to loan, lend | /ˈlɑi̯nɑtɑˣ/ · verb |
| [minuutti](https://en.wiktionary.org/wiki/minuutti#Finnish) | minute (unit of time or angle) | /ˈminuːtːi/ · noun |
| [paperi](https://en.wiktionary.org/wiki/paperi#Finnish) | paper (material) | /ˈpɑperi/ · noun |
| [peittää](https://en.wiktionary.org/wiki/peitt%C3%A4%C3%A4#Finnish) | to cover | /ˈpei̯tːæːˣ/ · verb |

</details>

<details><summary>Words 601–650</summary>

![[Resources/Audio/fi/Words 0601-0650.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [pyörä](https://en.wiktionary.org/wiki/py%C3%B6r%C3%A4#Finnish) | wheel (circular device capable of rotating on its axis) | /ˈpyø̯ræ/ · noun |
| [täti](https://en.wiktionary.org/wiki/t%C3%A4ti#Finnish) | aunt (mother's or father's sister) | /ˈtæti/ · noun |
| [ulkoministeri](https://en.wiktionary.org/wiki/ulkoministeri#Finnish) | foreign minister; (US equivalent) secretary of state | /ˈulkoˌministeri/ · noun |
| [vene](https://en.wiktionary.org/wiki/vene#Finnish) | boat | /ˈʋeneˣ/ · noun |
| [mummo](https://en.wiktionary.org/wiki/mummo#Finnish) | grandmother, grandma | /ˈmumːo/ · noun |
| [pe](https://en.wiktionary.org/wiki/pe#Finnish) | pe (seventeenth letter of the Hebrew and Phoenician scripts and the Northwest Semitic abjad) | /ˈpe(ː)/ · noun |
| [rap](https://en.wiktionary.org/wiki/rap#Finnish) | rap, rap music | /ˈrɑp/ · noun |
| [syöpä](https://en.wiktionary.org/wiki/sy%C3%B6p%C3%A4#Finnish) | cancer | /ˈsyø̯pæ/ · noun |
| [vau](https://en.wiktionary.org/wiki/vau#Finnish) | wow | /ˈʋɑu̯/ · intj |
| [elo](https://en.wiktionary.org/wiki/elo#Finnish) | life, living | /ˈelo/ · noun |
| [leijona](https://en.wiktionary.org/wiki/leijona#Finnish) | lion, Panthera leo | /ˈlei̯jonɑ/ · noun |
| [logo](https://en.wiktionary.org/wiki/logo#Finnish) | logo | /ˈloɡo/ · noun |
| [neste](https://en.wiktionary.org/wiki/neste#Finnish) | liquid | /ˈnesteˣ/ · noun |
| [silmä](https://en.wiktionary.org/wiki/silm%C3%A4#Finnish) | eye (organ of the body) | /ˈsilmæ/ · noun |
| [torstai](https://en.wiktionary.org/wiki/torstai#Finnish) | Thursday (day of the week; the fourth day of the week in Finland and in the ISO 8601 standard) | /ˈtorstɑi̯/ · noun |
| [jee](https://en.wiktionary.org/wiki/jee#Finnish) | yeah!, yay! (expressing joy) | /ˈjeː/ · intj |
| [kuudes](https://en.wiktionary.org/wiki/kuudes#Finnish) | sixth | /ˈkuːdes/ · adj |
| [ote](https://en.wiktionary.org/wiki/ote#Finnish) | grasp, grip, hold | /ˈoteˣ/ · noun |
| [syvä](https://en.wiktionary.org/wiki/syv%C3%A4#Finnish) | deep | /ˈsyʋæ/ · adj |
| [tauko](https://en.wiktionary.org/wiki/tauko#Finnish) | break, pause, recess (interruption) | /ˈtɑu̯ko/ · noun |
| [toistaa](https://en.wiktionary.org/wiki/toistaa#Finnish) | to repeat, reiterate (do or say again) | /ˈtoi̯stɑːˣ/ · verb |
| [tukka](https://en.wiktionary.org/wiki/tukka#Finnish) | hair (cover of hair on a human head); head of hair | /ˈtukːɑ/ · noun |
| [virus](https://en.wiktionary.org/wiki/virus#Finnish) | virus | /ˈʋirus/ · noun |
| [esi-](https://en.wiktionary.org/wiki/esi-#Finnish) | pre-, fore- | /ˈesi-/ · adj |
| [köyhä](https://en.wiktionary.org/wiki/k%C3%B6yh%C3%A4#Finnish) | poor (with few or no possessions or money) | /ˈkøy̯hæ/ · adj |
| [lentokone](https://en.wiktionary.org/wiki/lentokone#Finnish) | aeroplane, airplane (powered heavier-than-air aircraft with fixed wings) | /ˈlentoˌkoneˣ/ · noun |
| [sika](https://en.wiktionary.org/wiki/sika#Finnish) | pig, swine (Sus domesticus) | /ˈsikɑ/ · noun |
| [sukupolvi](https://en.wiktionary.org/wiki/sukupolvi#Finnish) | generation (single step in the succession of natural descent) | /ˈsukuˌpolʋi/ · noun |
| [taka-](https://en.wiktionary.org/wiki/taka-#Finnish) | back, rear, hind | /ˈtɑkɑ-/ · adj |
| [aikainen](https://en.wiktionary.org/wiki/aikainen#Finnish) | early (near the start of the day; arriving at a time before expected; at a time in advance of the usual) | /ˈɑi̯kɑi̯nen/ · adj |
| [ellen](https://en.wiktionary.org/wiki/ellen#Finnish) | if I not, unless I | /ˈelːen/ · conj |
| [hyi](https://en.wiktionary.org/wiki/hyi#Finnish) | yuck, ew, ugh | /ˈhyi̯/ · intj |
| [into](https://en.wiktionary.org/wiki/into#Finnish) | eagerness, enthusiasm | /ˈinto/ · noun |
| [kato](https://en.wiktionary.org/wiki/kato#Finnish) | crop failure, failure of crops | /ˈkɑto/ · noun |
| [pääkaupunki](https://en.wiktionary.org/wiki/p%C3%A4%C3%A4kaupunki#Finnish) | capital, capital city | /ˈpæːˌkɑu̯puŋki/ · noun |
| [reilu meininki](https://en.wiktionary.org/wiki/reilu%20meininki#Finnish) | great atmosphere (said e.g. of a party or festival) |  · phrase |
| [seksuaalinen](https://en.wiktionary.org/wiki/seksuaalinen#Finnish) | sexual, pertaining to sexual intercourse | /ˈseksuɑːlinen/ · adj |
| [ti](https://en.wiktionary.org/wiki/ti#Finnish) | dit (spoken representation of a dot in radio and telegraph Morse code) | /ˈti/ · noun |
| [elin](https://en.wiktionary.org/wiki/elin#Finnish) | organ (larger part of an organism, composed of tissues that perform similar functions) | /ˈelin/ · noun |
| [jazz](https://en.wiktionary.org/wiki/jazz#Finnish) | jazz (style of music) | /ˈjɑts/ · noun |
| [koskea](https://en.wiktionary.org/wiki/koskea#Finnish) | to touch | /ˈkoskeɑˣ/ · verb |
| [leveä](https://en.wiktionary.org/wiki/leve%C3%A4#Finnish) | wide (having a large physical extent from side to side) | /ˈleʋeæ/ · adj |
| [lumi](https://en.wiktionary.org/wiki/lumi#Finnish) | snow (frozen, crystalline state of water that falls as precipitation; sometimes also similar frozen forms of other substances) | /ˈlumi/ · noun |
| [mittari](https://en.wiktionary.org/wiki/mittari#Finnish) | meter, gauge, indicator, instrument (device for measuring) | /ˈmitːɑri/ · noun |
| [viisas](https://en.wiktionary.org/wiki/viisas#Finnish) | wise | /ˈʋiːsɑs/ · adj |
| [albumi](https://en.wiktionary.org/wiki/albumi#Finnish) | album | /ˈɑlbumi/ · noun |
| [hockey](https://en.wiktionary.org/wiki/hockey#Finnish) | hockey | /ˈhokːei̯/ · noun |
| [murha](https://en.wiktionary.org/wiki/murha#Finnish) | murder; first-degree murder (US) | /ˈmurhɑ/ · noun |
| [ruskea](https://en.wiktionary.org/wiki/ruskea#Finnish) | brown | /ˈruskeɑ/ · adj |
| [sade](https://en.wiktionary.org/wiki/sade#Finnish) | precipitation (any kind of precipitation from the sky (e.g. rain, snow, sleet, hailstones)) | /ˈsɑdeˣ/ · noun |

</details>

<details><summary>Words 651–700</summary>

![[Resources/Audio/fi/Words 0651-0700.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [esi-isä](https://en.wiktionary.org/wiki/esi-is%C3%A4#Finnish) | ancestor, forebear, forefather | /ˈesiˌ(ʔ)isæ/ · noun |
| [firma](https://en.wiktionary.org/wiki/firma#Finnish) | firm, company, business | /ˈfirmɑ/ · noun |
| [jälki-](https://en.wiktionary.org/wiki/j%C3%A4lki-#Finnish) | post-, after- | /ˈjælki-/ · adj |
| [muna](https://en.wiktionary.org/wiki/muna#Finnish) | egg | /ˈmunɑ/ · noun |
| [vakaa](https://en.wiktionary.org/wiki/vakaa#Finnish) | stable, steady, firm | /ˈʋɑkɑː/ · adj |
| [veri](https://en.wiktionary.org/wiki/veri#Finnish) | blood (liquid flowing in human and animal bodies) | /ˈʋeri/ · noun |
| [villa](https://en.wiktionary.org/wiki/villa#Finnish) | wool | /ˈʋilːɑ/ · noun |
| [ha-ha](https://en.wiktionary.org/wiki/ha-ha#Finnish) | ha-ha, haha (onomatopoeic representation of laughter) | /ˈhɑˌhɑ/ · intj |
| [itkeä](https://en.wiktionary.org/wiki/itke%C3%A4#Finnish) | to cry, weep | /ˈitkeæˣ/ · verb |
| [katu](https://en.wiktionary.org/wiki/katu#Finnish) | street (paved part of road in a village or a town, especially one bordered by pavements or sidewalks) | /ˈkɑtu/ · noun |
| [kuiva](https://en.wiktionary.org/wiki/kuiva#Finnish) | dry | /ˈkui̯ʋɑ/ · adj |
| [lama](https://en.wiktionary.org/wiki/lama#Finnish) | paralysis, depression (state of being unable to act) | /ˈlɑmɑ/ · noun |
| [onnekas](https://en.wiktionary.org/wiki/onnekas#Finnish) | lucky, fortunate | /ˈonːekɑs/ · adj |
| [pullo](https://en.wiktionary.org/wiki/pullo#Finnish) | bottle | /ˈpulːo/ · noun |
| [rikas](https://en.wiktionary.org/wiki/rikas#Finnish) | rich, wealthy, opulent, well off | /ˈrikɑs/ · adj |
| [syyskuu](https://en.wiktionary.org/wiki/syyskuu#Finnish) | September (month) | /ˈsyːsˌkuː/ · noun |
| [taksi](https://en.wiktionary.org/wiki/taksi#Finnish) | taxi, cab, taxicab (vehicle available for public hire) | /ˈtɑksi/ · noun |
| [keho](https://en.wiktionary.org/wiki/keho#Finnish) | body (frame of a living human or animal) | /ˈkeho/ · noun |
| [multa](https://en.wiktionary.org/wiki/multa#Finnish) | mold, mull (humus); soil or earth suitable for growing plants, a mixture of mineral soil and humus | /ˈmultɑ/ · noun |
| [pelle](https://en.wiktionary.org/wiki/pelle#Finnish) | clown | /ˈpelːe/ · noun |
| [puku](https://en.wiktionary.org/wiki/puku#Finnish) | suit (set of clothes to be worn together, now especially a man's matching jacket and trousers) | /ˈpuku/ · noun |
| [raamattu](https://en.wiktionary.org/wiki/raamattu#Finnish) | Bible, (a) bible (an individual copy of Raamattu, or the Bible) | /ˈrɑːmɑtːu/ · noun |
| [stop](https://en.wiktionary.org/wiki/stop#Finnish) | stop (halt) | /ˈstop/ · intj |
| [yksinäinen](https://en.wiktionary.org/wiki/yksin%C3%A4inen#Finnish) | lonely (unhappy by feeling isolated) | /ˈyksinæi̯nen/ · adj |
| [college](https://en.wiktionary.org/wiki/college#Finnish) | sweatshirt (especially one with text referring to a certain college) | /ˈkolids(i)/ · noun |
| [este](https://en.wiktionary.org/wiki/este#Finnish) | obstacle, barrier, hindrance, obstruction, impediment | /ˈesteˣ/ · noun |
| [hop](https://en.wiktionary.org/wiki/hop#Finnish) | General spurring interjection. | /ˈhop/ · intj |
| [ikkuna](https://en.wiktionary.org/wiki/ikkuna#Finnish) | window (opening for light and air) | /ˈikːunɑ/ · noun |
| [juusto](https://en.wiktionary.org/wiki/juusto#Finnish) | cheese (dairy product) | /ˈjuːsto/ · noun |
| [lihava](https://en.wiktionary.org/wiki/lihava#Finnish) | fat, plump, overweight | /ˈlihɑʋɑ/ · adj |
| [manner](https://en.wiktionary.org/wiki/manner#Finnish) | mainland (main landmass of a country, continent or sometimes of a group of islands) | /ˈmɑnːer/ · noun |
| [nenä](https://en.wiktionary.org/wiki/nen%C3%A4#Finnish) | nose (protuberance on the human face) | /ˈnenæ/ · noun |
| [suola](https://en.wiktionary.org/wiki/suola#Finnish) | salt (common table salt, sodium chloride, NaCl) | /ˈsuo̯lɑ/ · noun |
| [viini](https://en.wiktionary.org/wiki/viini#Finnish) | wine (alcoholic drink made from grapes) | /ˈʋiːni/ · noun |
| [ääri](https://en.wiktionary.org/wiki/%C3%A4%C3%A4ri#Finnish) | edge, verge, end, boundary, brink | /ˈæːri/ · noun |
| [anime](https://en.wiktionary.org/wiki/anime#Finnish) | anime | /ˈɑnime/ · noun |
| [leipä](https://en.wiktionary.org/wiki/leip%C3%A4#Finnish) | bread (foodstuff) | /ˈlei̯pæ/ · noun |
| [lounas](https://en.wiktionary.org/wiki/lounas#Finnish) | southwest | /ˈlou̯nɑs/ · noun |
| [paeta](https://en.wiktionary.org/wiki/paeta#Finnish) | to flee, run away (from), escape | /ˈpɑetɑˣ/ · verb |
| [piirtää](https://en.wiktionary.org/wiki/piirt%C3%A4%C3%A4#Finnish) | to draw, sketch (produce a picture with a pencil or other similar implement) | /ˈpiːrtæːˣ/ · verb |
| [viis](https://en.wiktionary.org/wiki/viis#Finnish) | Said to ignore something | /ˈʋiːs/ · intj |
| [kana](https://en.wiktionary.org/wiki/kana#Finnish) | chicken (domestic fowl of species Gallus gallus, Gallus domesticus) | /ˈkɑnɑ/ · noun |
| [kirkas](https://en.wiktionary.org/wiki/kirkas#Finnish) | bright (emitting or reflecting much light; luminous, intense, brilliant) | /ˈkirkɑs/ · adj |
| [linna](https://en.wiktionary.org/wiki/linna#Finnish) | castle (house or mansion with some of the architectural features of medieval castles) | /ˈlinːɑ/ · noun |
| [mars](https://en.wiktionary.org/wiki/mars#Finnish) | march! (military command) | /ˈmɑrs/ · intj |
| [paavi](https://en.wiktionary.org/wiki/paavi#Finnish) | pope | /ˈpɑːʋi/ · noun |
| [paksu](https://en.wiktionary.org/wiki/paksu#Finnish) | thick (relatively great in extent from one surface to the opposite in its smallest solid dimension) | /ˈpɑksu/ · adj |
| [pizza](https://en.wiktionary.org/wiki/pizza#Finnish) | pizza (Italian dish) | /ˈpitsɑ/ · noun |
| [unkari](https://en.wiktionary.org/wiki/unkari#Finnish) | Hungarian language | /ˈuŋkɑri/ · noun |
| [vaalea](https://en.wiktionary.org/wiki/vaalea#Finnish) | light, pale (of a shade of colour) | /ˈʋɑːleɑ/ · adj |

</details>

<details><summary>Words 701–750</summary>

![[Resources/Audio/fi/Words 0701-0750.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [ikuinen](https://en.wiktionary.org/wiki/ikuinen#Finnish) | everlasting, eternal | /ˈikui̯nen/ · adj |
| [järvi](https://en.wiktionary.org/wiki/j%C3%A4rvi#Finnish) | lake (large, landlocked stretch of water) | /ˈjærʋi/ · noun |
| [räjähtää](https://en.wiktionary.org/wiki/r%C3%A4j%C3%A4ht%C3%A4%C3%A4#Finnish) | to explode, burst, blow up | /ˈræjæhtæːˣ/ · verb |
| [sielu](https://en.wiktionary.org/wiki/sielu#Finnish) | soul (spirit or essence of a person or of a thing) | /ˈsie̯lu/ · noun |
| [DJ](https://en.wiktionary.org/wiki/DJ#Finnish) | disc jockey | /ˈdeːˌjiː/ · noun |
| [ankka](https://en.wiktionary.org/wiki/ankka#Finnish) | domestic duck, (informally) duck, Anas platyrhynchos f. domesticus | /ˈɑŋkːɑ/ · noun |
| [hattu](https://en.wiktionary.org/wiki/hattu#Finnish) | hat (piece of headwear) | /ˈhɑtːu/ · noun |
| [häiriö](https://en.wiktionary.org/wiki/h%C3%A4iri%C3%B6#Finnish) | disorder, trouble | /ˈhæi̯riø/ · noun |
| [keisari](https://en.wiktionary.org/wiki/keisari#Finnish) | emperor | /ˈkei̯sɑri/ · noun |
| [köyhyys](https://en.wiktionary.org/wiki/k%C3%B6yhyys#Finnish) | poverty | /ˈkøy̯hyːs/ · noun |
| [lasi](https://en.wiktionary.org/wiki/lasi#Finnish) | glass (substance) | /ˈlɑsi/ · noun |
| [haha](https://en.wiktionary.org/wiki/haha#Finnish) | haha, ha-ha (laughing) | /ˈhɑhɑ/ · intj |
| [kapea](https://en.wiktionary.org/wiki/kapea#Finnish) | narrow (having small width) | /ˈkɑpeɑ/ · adj |
| [keskiviikko](https://en.wiktionary.org/wiki/keskiviikko#Finnish) | Wednesday (day of the week; the third day of the week in Finland and in the ISO 8601 standard) | /ˈkeskiˌʋiːkːo/ · noun |
| [kirjallisuus](https://en.wiktionary.org/wiki/kirjallisuus#Finnish) | literature | /ˈkirjɑlːisuːs/ · noun |
| [WC](https://en.wiktionary.org/wiki/WC#Finnish) | WC (water closet) | /ˈʋeːseː/ · noun |
| [es](https://en.wiktionary.org/wiki/es#Finnish) | E-flat | /ˈes/ · noun |
| [kertomus](https://en.wiktionary.org/wiki/kertomus#Finnish) | story, narrative | /ˈkertomus/ · noun |
| [kukka](https://en.wiktionary.org/wiki/kukka#Finnish) | flower (reproductive structure in angiosperms; plant with such structures) | /ˈkukːɑ/ · noun |
| [made](https://en.wiktionary.org/wiki/made#Finnish) | burbot (Lota lota) | /ˈmɑdeˣ/ · noun |
| [pehmeä](https://en.wiktionary.org/wiki/pehme%C3%A4#Finnish) | soft (easily giving way under pressure) | /ˈpehmeæ/ · adj |
| [VIP](https://en.wiktionary.org/wiki/VIP#Finnish) | VIP (very important person) |  · noun |
| [au](https://en.wiktionary.org/wiki/au#Finnish) | ow, ouch | /ˈɑu̯/ · intj |
| [lehmä](https://en.wiktionary.org/wiki/lehm%C3%A4#Finnish) | cow (female of Bos taurus) | /ˈlehmæ/ · noun |
| [manu](https://en.wiktionary.org/wiki/manu#Finnish) | studio director | /ˈmɑnu/ · noun |
| [seitsemäs](https://en.wiktionary.org/wiki/seitsem%C3%A4s#Finnish) | seventh | /ˈsei̯tsemæs/ · adj |
| [suku](https://en.wiktionary.org/wiki/suku#Finnish) | extended family, kin (in addition to parents and children, includes cousins, uncles, aunts, grandparents and farther relatives) | /ˈsuku/ · noun |
| [vaadin](https://en.wiktionary.org/wiki/vaadin#Finnish) | reindeer doe | /ˈʋɑːdin/ · noun |
| [vuori](https://en.wiktionary.org/wiki/vuori#Finnish) | mountain (large mass of earth and rock) | /ˈʋuo̯ri/ · noun |
| [hiljaisuus](https://en.wiktionary.org/wiki/hiljaisuus#Finnish) | silence, quiet | /ˈhiljɑi̯suːs/ · noun |
| [isi](https://en.wiktionary.org/wiki/isi#Finnish) | dad, father, daddy | /ˈisi/ · noun |
| [rauta](https://en.wiktionary.org/wiki/rauta#Finnish) | iron (metal; chemical element with the symbol Fe) | /ˈrɑu̯tɑ/ · noun |
| [runo](https://en.wiktionary.org/wiki/runo#Finnish) | poem (piece of poetry) | /ˈruno/ · noun |
| [kuunteleminen](https://en.wiktionary.org/wiki/kuunteleminen) | listening |  · noun |
| [allas](https://en.wiktionary.org/wiki/allas#Finnish) | a closed body of water, e.g. a lagoon | /ˈɑlːɑs/ · noun |
| [baby](https://en.wiktionary.org/wiki/baby#Finnish) | baby (term of endearment) | /ˈbei̯bi/ · noun |
| [elokuu](https://en.wiktionary.org/wiki/elokuu#Finnish) | August (month) | /ˈeloˌkuː/ · noun |
| [espanjalainen](https://en.wiktionary.org/wiki/espanjalainen#Finnish) | Spanish | /ˈespɑnjɑlɑi̯nen/ · adj |
| [haista](https://en.wiktionary.org/wiki/haista#Finnish) | to smell, to have a smell/scent/odor [with ablative or allative]; to stink | /ˈhɑi̯stɑˣ/ · verb |
| [laukku](https://en.wiktionary.org/wiki/laukku#Finnish) | bag, case (firm container made out of cloth, leather, plastic, etc.) | /ˈlɑu̯kːu/ · noun |
| [terävä](https://en.wiktionary.org/wiki/ter%C3%A4v%C3%A4#Finnish) | sharp (able to cut or pierce easily) | /ˈteræʋæ/ · adj |
| [-ka](https://en.wiktionary.org/wiki/-ka#Finnish) | functionally a conjunction, suffixed to the negation verb to join two main clauses; and (not) (see eikä) |  · particle |
| [aarre](https://en.wiktionary.org/wiki/aarre#Finnish) | treasure | /ˈɑːrːeˣ/ · noun |
| [bonus](https://en.wiktionary.org/wiki/bonus#Finnish) | bonus (something extra) | /ˈbo(ː)nus/ · noun |
| [joki](https://en.wiktionary.org/wiki/joki#Finnish) | river (large stream which drains a landmass) | /ˈjoki/ · noun |
| [kurkku](https://en.wiktionary.org/wiki/kurkku#Finnish) | throat, gullet | /ˈkurkːu/ · noun |
| [kymmenes](https://en.wiktionary.org/wiki/kymmenes#Finnish) | tenth | /ˈkymːenes/ · adj |
| [makea](https://en.wiktionary.org/wiki/makea#Finnish) | sweet (of taste, or figuratively) | /ˈmɑkeɑ/ · adj |
| [open house](https://en.wiktionary.org/wiki/open%20house#Finnish) | synonym of avoimet ovet (“open house”) | /ˈou̯p(ː)en ˈhɑu̯s/ · noun |
| [hirviö](https://en.wiktionary.org/wiki/hirvi%C3%B6#Finnish) | monster | /ˈhirʋiø/ · noun |

</details>

<details><summary>Words 751–800</summary>

![[Resources/Audio/fi/Words 0751-0800.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [isoäiti](https://en.wiktionary.org/wiki/iso%C3%A4iti#Finnish) | grandmother | /ˈisoˌæi̯ti/ · noun |
| [juoma](https://en.wiktionary.org/wiki/juoma#Finnish) | drink, beverage (something to drink, or a serving thereof) | /ˈjuo̯mɑ/ · noun |
| [kulma](https://en.wiktionary.org/wiki/kulma#Finnish) | corner (external point where two converging lines meet) | /ˈkulmɑ/ · noun |
| [maalaus](https://en.wiktionary.org/wiki/maalaus#Finnish) | painting (work of art) | /ˈmɑːlɑus/ · noun |
| [sisar](https://en.wiktionary.org/wiki/sisar#Finnish) | sister | /ˈsisɑr/ · noun |
| [-kin](https://en.wiktionary.org/wiki/-kin#Finnish) | also, too |  · particle |
| [PR](https://en.wiktionary.org/wiki/PR#Finnish) | PR, public relations (communication by a person or an organization with the purpose of creating a favorable public image) |  · noun |
| [ale](https://en.wiktionary.org/wiki/ale#Finnish) | sale (selling of goods at bargain prices) | /ˈɑle/ · noun |
| [ansaita](https://en.wiktionary.org/wiki/ansaita#Finnish) | to earn, make, win, gain (e.g. money) | /ˈɑnsɑi̯tɑˣ/ · verb |
| [info](https://en.wiktionary.org/wiki/info#Finnish) | info, information | /ˈinf(ː)o/ · noun |
| [isoisä](https://en.wiktionary.org/wiki/isois%C3%A4#Finnish) | grandfather | /ˈisoˌisæ/ · noun |
| [kakku](https://en.wiktionary.org/wiki/kakku#Finnish) | cake (rich, sweet dessert food) | /ˈkɑkːu/ · noun |
| [muuri](https://en.wiktionary.org/wiki/muuri#Finnish) | wall (rampart built for defensive purposes; structure built for defense) | /ˈmuːri/ · noun |
| [seinä](https://en.wiktionary.org/wiki/sein%C3%A4#Finnish) | wall (substantial structure acting as side or division in a building; something with the apparent solidity and dimensions of a building wall; also figurative uses) | /ˈsei̯næ/ · noun |
| [sokea](https://en.wiktionary.org/wiki/sokea#Finnish) | blind (unable to see) | /ˈsokeɑ/ · adj |
| [sänky](https://en.wiktionary.org/wiki/s%C3%A4nky#Finnish) | bed, bedstead, bedframe (piece of furniture, usually flat and soft, on which to rest or sleep) | /ˈsæŋky/ · noun |
| [enkeli](https://en.wiktionary.org/wiki/enkeli#Finnish) | angel | /ˈeŋkeli/ · noun |
| [esine](https://en.wiktionary.org/wiki/esine#Finnish) | object, item, thing (that is physical, concrete, tangible) | /ˈesineˣ/ · noun |
| [hiiri](https://en.wiktionary.org/wiki/hiiri#Finnish) | mouse (used rather indiscriminately for a number of small mouse-resembling rodents mostly in the zoologic family Muridae, but also in Zapodidae and Gliridae) | /ˈhiːri/ · noun |
| [oranssi](https://en.wiktionary.org/wiki/oranssi#Finnish) | orange (colour) | /ˈorɑnsːi/ · adj |
| [polku](https://en.wiktionary.org/wiki/polku#Finnish) | path, trail, track | /ˈpolku/ · noun |
| [pula](https://en.wiktionary.org/wiki/pula#Finnish) | shortage | /ˈpulɑ/ · noun |
| [side](https://en.wiktionary.org/wiki/side#Finnish) | bandage, dressing (medical binding or strip of cloth used as a blindfold) | /ˈsideˣ/ · noun |
| [torni](https://en.wiktionary.org/wiki/torni#Finnish) | tower (tall structure) | /ˈtorni/ · noun |
| [trans](https://en.wiktionary.org/wiki/trans#Finnish) | trans, transgender | /ˈtrɑns/ · adj |
| [alfa](https://en.wiktionary.org/wiki/alfa#Finnish) | alpha; the Greek letter Α, α | /ˈɑlf(ː)ɑ/ · noun |
| [diesel](https://en.wiktionary.org/wiki/diesel#Finnish) | diesel car, diesel (automobile powered with a diesel motor) | /ˈdiːs(ː)el/ · noun |
| [fitness](https://en.wiktionary.org/wiki/fitness#Finnish) | fitness (a type of fitness sport) | /ˈfitnesː/ · noun |
| [itsemurha](https://en.wiktionary.org/wiki/itsemurha#Finnish) | suicide | /ˈitse(ˣ)ˌmurhɑ/ · noun |
| [lumen](https://en.wiktionary.org/wiki/lumen#Finnish) | lumen | /ˈlu(ː)men/ · noun |
| [must](https://en.wiktionary.org/wiki/must#Finnish) | must (something mandatory or required) | /ˈmɑst/ · noun |
| [naurettava](https://en.wiktionary.org/wiki/naurettava#Finnish) | laughable, ridiculous, ludicrous, preposterous | /ˈnɑu̯retːɑʋɑ/ · adj |
| [oleellinen](https://en.wiktionary.org/wiki/oleellinen#Finnish) | essential, substantial, integral, important | /ˈoleːlːinen/ · adj |
| [planeetta](https://en.wiktionary.org/wiki/planeetta#Finnish) | planet | /ˈplɑneːtːɑ/ · noun |
| [single](https://en.wiktionary.org/wiki/single#Finnish) | single (45 rpm record; track nominally released on its own) | /ˈsiŋle/ · noun |
| [tesla](https://en.wiktionary.org/wiki/tesla#Finnish) | tesla | /ˈteslɑ/ · noun |
| [IP-osoite](https://en.wiktionary.org/wiki/IP-osoite#Finnish) | IP address | /ˈiːˌpeːˌosoi̯teˣ/ · noun |
| [helmikuu](https://en.wiktionary.org/wiki/helmikuu#Finnish) | February (month) | /ˈhelmiˌkuː/ · noun |
| [laiha](https://en.wiktionary.org/wiki/laiha#Finnish) | thin, lean, meagre, slim, skinny (of a human or animal) | /ˈlɑi̯hɑ/ · adj |
| [sisu](https://en.wiktionary.org/wiki/sisu#Finnish) | perseverance, doggedness, stubbornness, grit, stamina, spunk, determination, courage, guts, tenacity (unwavering strength to keep going when the going gets tough) | /ˈsisu/ · noun |
| [status](https://en.wiktionary.org/wiki/status#Finnish) | status (a person's position or standing; high standing) | /ˈstɑtus/ · noun |
| [suru](https://en.wiktionary.org/wiki/suru#Finnish) | sorrow, grief, woe, sadness, mourning | /ˈsuru/ · noun |
| [tennis](https://en.wiktionary.org/wiki/tennis#Finnish) | tennis | /ˈtenːis/ · noun |
| [body](https://en.wiktionary.org/wiki/body#Finnish) | snapsuit, onesies (infant bodysuit) | /ˈbody/ · noun |
| [hah](https://en.wiktionary.org/wiki/hah#Finnish) | ha | /ˈhɑh/ · intj |
| [kuppi](https://en.wiktionary.org/wiki/kuppi#Finnish) | cup (vessel for warm drinks) | /ˈkupːi/ · noun |
| [ohut](https://en.wiktionary.org/wiki/ohut#Finnish) | thin (having little thickness or extent from one surface to its opposite) | /ˈohut/ · adj |
| [pyöreä](https://en.wiktionary.org/wiki/py%C3%B6re%C3%A4#Finnish) | round (of a round shape; circular, cylindrical, spherical, etc.; with no sharp corners) | /ˈpyø̯reæ/ · adj |
| [vara](https://en.wiktionary.org/wiki/vara#Finnish) | reserve, backup (that which is reserved or kept back, as for future use) | /ˈʋɑrɑ/ · noun |
| [visio](https://en.wiktionary.org/wiki/visio#Finnish) | vision (goal) | /ˈʋisio/ · noun |

</details>

<details><summary>Words 801–850</summary>

![[Resources/Audio/fi/Words 0801-0850.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [julma](https://en.wiktionary.org/wiki/julma#Finnish) | cruel, heartless, merciless | /ˈjulmɑ/ · adj |
| [nobel](https://en.wiktionary.org/wiki/nobel#Finnish) | synonym of Nobel-palkinto (“Nobel Prize”) | /ˈnoːbel/ · noun |
| [painava](https://en.wiktionary.org/wiki/painava#Finnish) | heavy (having great weight) | /ˈpɑi̯nɑʋɑ/ · adj |
| [parta](https://en.wiktionary.org/wiki/parta#Finnish) | beard (facial hair on humans) | /ˈpɑrtɑ/ · noun |
| [penis](https://en.wiktionary.org/wiki/penis#Finnish) | penis | /ˈpenis/ · noun |
| [propaganda](https://en.wiktionary.org/wiki/propaganda#Finnish) | propaganda | /ˈpropɑɡɑndɑ/ · noun |
| [hirvi](https://en.wiktionary.org/wiki/hirvi#Finnish) | elk, moose (Alces alces) | /ˈhirʋi/ · noun |
| [kupla](https://en.wiktionary.org/wiki/kupla#Finnish) | bubble (spherically contained volume of air or other gas) | /ˈkuplɑ/ · noun |
| [märkä](https://en.wiktionary.org/wiki/m%C3%A4rk%C3%A4#Finnish) | wet | /ˈmærkæ/ · adj |
| [nero](https://en.wiktionary.org/wiki/nero#Finnish) | genius (someone possessing extraordinary intelligence or skill) | /ˈnero/ · noun |
| [oikeudenkäynti](https://en.wiktionary.org/wiki/oikeudenk%C3%A4ynti#Finnish) | a trial, (legal) process, judicial proceedings | /ˈoi̯keu̯denˌkæy̯nti/ · noun |
| [serkku](https://en.wiktionary.org/wiki/serkku#Finnish) | cousin, first cousin | /ˈserkːu/ · noun |
| [tammikuu](https://en.wiktionary.org/wiki/tammikuu#Finnish) | January (month) | /ˈtɑmːiˌkuː/ · noun |
| [hetero](https://en.wiktionary.org/wiki/hetero#Finnish) | heterosexual, hetero (person) | /ˈhetero/ · noun |
| [jes](https://en.wiktionary.org/wiki/jes#Finnish) | yes! (used to express pleasure, joy, or great excitement) | /ˈjes/ · intj |
| [sangen](https://en.wiktionary.org/wiki/sangen#Finnish) | quite, very, pretty | /ˈsɑŋːen/ · adv |
| [stora](https://en.wiktionary.org/wiki/stora#Finnish) | synonym of isopurje | /ˈstuːrɑ/ · noun |
| [heinäkuu](https://en.wiktionary.org/wiki/hein%C3%A4kuu#Finnish) | July (month) | /ˈhei̯næˌkuː/ · noun |
| [hiki](https://en.wiktionary.org/wiki/hiki#Finnish) | sweat, perspiration (body fluid) | /ˈhiki/ · noun |
| [jääkaappi](https://en.wiktionary.org/wiki/j%C3%A4%C3%A4kaappi#Finnish) | refrigerator | /ˈjæːˌkɑːpːi/ · noun |
| [kaksikymmentä](https://en.wiktionary.org/wiki/kaksikymment%C3%A4#Finnish) | twenty | /ˈkɑksiˌkymːentæ/ · num |
| [kettu](https://en.wiktionary.org/wiki/kettu#Finnish) | red fox (Vulpes vulpes) | /ˈketːu/ · noun |
| [pappa](https://en.wiktionary.org/wiki/pappa#Finnish) | grandpa, grandfather | /ˈpɑpːɑ/ · noun |
| [patsas](https://en.wiktionary.org/wiki/patsas#Finnish) | statue (three-dimensional work of art) | /ˈpɑtsɑs/ · noun |
| [päivämäärä](https://en.wiktionary.org/wiki/p%C3%A4iv%C3%A4m%C3%A4%C3%A4r%C3%A4#Finnish) | date (day, month and year of occurrence of an event or a transaction; such information marked on something) | /ˈpæi̯ʋæˌmæːræ/ · noun |
| [henna](https://en.wiktionary.org/wiki/henna#Finnish) | henna (dye and color) | /ˈhenːɑ/ · noun |
| [kahdeksas](https://en.wiktionary.org/wiki/kahdeksas#Finnish) | eighth | /ˈkɑhdeksɑs/ · adj |
| [kirjain](https://en.wiktionary.org/wiki/kirjain#Finnish) | letter (such of the alphabet, character, glyph) | /ˈkirjɑi̯n/ · noun |
| [master](https://en.wiktionary.org/wiki/master#Finnish) | (male) dom | /ˈmɑster/ · noun |
| [samankaltainen](https://en.wiktionary.org/wiki/samankaltainen#Finnish) | similar (having traits or characteristics in common) | /ˈsɑmɑnˌkɑltɑi̯nen/ · adj |
| [sattua](https://en.wiktionary.org/wiki/sattua#Finnish) | to hurt, be sore (physically or mentally) | /ˈsɑtːuɑˣ/ · verb |
| [sormi](https://en.wiktionary.org/wiki/sormi#Finnish) | finger (one of the five extremities of the hand) | /ˈsormi/ · noun |
| [uinti](https://en.wiktionary.org/wiki/uinti#Finnish) | swimming | /ˈui̯nti/ · noun |
| [vuoto](https://en.wiktionary.org/wiki/vuoto#Finnish) | leak (instance of leaking; a particular case where something continuously leaks; the liquid or fluid leaked; damage which causes something to leak) | /ˈʋuo̯to/ · noun |
| [aamiainen](https://en.wiktionary.org/wiki/aamiainen#Finnish) | breakfast | /ˈɑːmiɑi̯nen/ · noun |
| [chili](https://en.wiktionary.org/wiki/chili#Finnish) | chili | /ˈtʃili/ · noun |
| [demo](https://en.wiktionary.org/wiki/demo#Finnish) | demo (brief demonstration) | /ˈdemo/ · noun |
| [jenny](https://en.wiktionary.org/wiki/jenny#Finnish) | synonym of genua | /ˈjenːy/ · noun |
| [kaksitoista](https://en.wiktionary.org/wiki/kaksitoista#Finnish) | twelve | /ˈkɑksiˌtoi̯stɑ/ · num |
| [kaula](https://en.wiktionary.org/wiki/kaula#Finnish) | neck (part of the body connecting the head and the trunk) | /ˈkɑu̯lɑ/ · noun |
| [kynä](https://en.wiktionary.org/wiki/kyn%C3%A4#Finnish) | pen (writing instrument) | /ˈkynæ/ · noun |
| [maistaa](https://en.wiktionary.org/wiki/maistaa#Finnish) | to taste (sense by taste) | /ˈmɑi̯stɑːˣ/ · verb |
| [omena](https://en.wiktionary.org/wiki/omena#Finnish) | apple | /ˈomenɑ/ · noun |
| [saldo](https://en.wiktionary.org/wiki/saldo#Finnish) | balance (of an account) | /ˈsɑldo/ · noun |
| [HIV](https://en.wiktionary.org/wiki/HIV#Finnish) | HIV (human immunodeficiency virus) | /ˈhiʋ/ · noun |
| [kanna](https://en.wiktionary.org/wiki/kanna#Finnish) | canna lily (any plant of the genus Canna); (in the plural) the genus Canna | /ˈkɑnːɑ/ · noun |
| [uskollinen](https://en.wiktionary.org/wiki/uskollinen#Finnish) | faithful, loyal | /ˈuskolːinen/ · adj |
| [diabetes](https://en.wiktionary.org/wiki/diabetes#Finnish) | diabetes | /ˈdiɑbe(ː)t(ː)es/ · noun |
| [islanti](https://en.wiktionary.org/wiki/islanti#Finnish) | Icelandic (language) | /ˈislɑnti/ · noun |
| [juan](https://en.wiktionary.org/wiki/juan#Finnish) | yuan (Chinese currency) | /ˈjuɑn/ · noun |

</details>

<details><summary>Words 851–900</summary>

![[Resources/Audio/fi/Words 0851-0900.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [lohi](https://en.wiktionary.org/wiki/lohi#Finnish) | salmon (fish of the family Salmonidae) | /ˈlohi/ · noun |
| [marraskuu](https://en.wiktionary.org/wiki/marraskuu#Finnish) | November (month) | /ˈmɑrːɑsˌkuː/ · noun |
| [ori](https://en.wiktionary.org/wiki/ori#Finnish) | stallion | /ˈori(ˣ)/ · noun |
| [peili](https://en.wiktionary.org/wiki/peili#Finnish) | mirror | /ˈpei̯li/ · noun |
| [pohjoinen](https://en.wiktionary.org/wiki/pohjoinen#Finnish) | north | /ˈpohjoi̯nen/ · noun |
| [portugali](https://en.wiktionary.org/wiki/portugali#Finnish) | Portuguese, the Portuguese language | /ˈport(ː)uɡɑli/ · noun |
| [ulkomaalainen](https://en.wiktionary.org/wiki/ulkomaalainen#Finnish) | foreign (originating from a foreign country) | /ˈulkoˌmɑːlɑi̯nen/ · adj |
| [valehdella](https://en.wiktionary.org/wiki/valehdella#Finnish) | to lie [with allative ‘to’ and elative ‘about’] (tell untruths) | /ˈʋɑlehdelːɑˣ/ · verb |
| [via](https://en.wiktionary.org/wiki/via#Finnish) | via | /ˈʋiɑ/ · adv |
| [aro](https://en.wiktionary.org/wiki/aro#Finnish) | steppe; flat, vast, temperate but relatively dry grassland | /ˈɑro/ · noun |
| [aura](https://en.wiktionary.org/wiki/aura#Finnish) | plough, plow (agricultural tool) | /ˈɑu̯rɑ/ · noun |
| [avaruus](https://en.wiktionary.org/wiki/avaruus#Finnish) | space (three-dimensional continuum) | /ˈɑʋɑruːs/ · noun |
| [id](https://en.wiktionary.org/wiki/id#Finnish) | id | /ˈid/ · noun |
| [mitta](https://en.wiktionary.org/wiki/mitta#Finnish) | measure (prescribed quantity or extent) | /ˈmitːɑ/ · noun |
| [olemassaolo](https://en.wiktionary.org/wiki/olemassaolo#Finnish) | existence | /ˈolemɑsːɑˌolo/ · noun |
| [pinkki](https://en.wiktionary.org/wiki/pinkki#Finnish) | hot pink | /ˈpiŋkːi/ · adj |
| [sammuttaa](https://en.wiktionary.org/wiki/sammuttaa#Finnish) | to put out, extinguish (a fire) | /ˈsɑmːutːɑːˣ/ · verb |
| [tabu](https://en.wiktionary.org/wiki/tabu#Finnish) | taboo | /ˈtɑbu/ · noun |
| [tuho](https://en.wiktionary.org/wiki/tuho#Finnish) | destruction, devastation, havoc, damage | /ˈtuho/ · noun |
| [varjo](https://en.wiktionary.org/wiki/varjo#Finnish) | shadow (dark image projected onto a surface) | /ˈʋɑrjo/ · noun |
| [visa](https://en.wiktionary.org/wiki/visa#Finnish) | synonym of visakoivu (“wood obtained from a mutation of the silver birch”) | /ˈʋisɑ/ · noun |
| [diktaattori](https://en.wiktionary.org/wiki/diktaattori#Finnish) | dictator, dictatrix (totalitarian leader of a dictatorship) | /ˈdiktɑːtːori/ · noun |
| [hai](https://en.wiktionary.org/wiki/hai#Finnish) | shark | /ˈhɑi̯/ · noun |
| [ho](https://en.wiktionary.org/wiki/ho#Finnish) | synonym of oho | /ˈho/ · intj |
| [ki](https://en.wiktionary.org/wiki/ki#Finnish) | chi, qi (life force in Chinese medicine) | /ˈki(ː)/ · noun |
| [lammas](https://en.wiktionary.org/wiki/lammas#Finnish) | sheep (woolly ruminant of the genus Ovis; either used generically or referring more specifically to a female mature one) | /ˈlɑmːɑs/ · noun |
| [nam](https://en.wiktionary.org/wiki/nam#Finnish) | yum | /ˈnɑm/ · intj |
| [piru](https://en.wiktionary.org/wiki/piru#Finnish) | the Devil, Satan | /ˈpiru/ · noun |
| [ankara](https://en.wiktionary.org/wiki/ankara#Finnish) | harsh, hard, strict, stern [with allative ‘to’ or (partitive +) kohtaan] (of a person or character, etc.) | /ˈɑŋkɑrɑ/ · adj |
| [hus](https://en.wiktionary.org/wiki/hus#Finnish) | shoo! | /ˈhus/ · intj |
| [karma](https://en.wiktionary.org/wiki/karma#Finnish) | karma | /ˈkɑrmɑ/ · noun |
| [keittää](https://en.wiktionary.org/wiki/keitt%C3%A4%C3%A4#Finnish) | to boil (cook in boiling water) | /ˈkei̯tːæːˣ/ · verb |
| [lyhentää](https://en.wiktionary.org/wiki/lyhent%C3%A4%C3%A4#Finnish) | to shorten, abridge | /ˈlyhentæːˣ/ · verb |
| [miekka](https://en.wiktionary.org/wiki/miekka#Finnish) | sword (weapon) | /ˈmie̯kːɑ/ · noun |
| [mobile](https://en.wiktionary.org/wiki/mobile#Finnish) | mobile (kinetic sculpture) | /ˈmobile/ · noun |
| [muovi](https://en.wiktionary.org/wiki/muovi#Finnish) | plastic (material; synthetic thermoplastic polymer) | /ˈmuo̯ʋi/ · noun |
| [murhaaja](https://en.wiktionary.org/wiki/murhaaja#Finnish) | murderer | /ˈmurhɑːjɑ/ · noun |
| [pasta](https://en.wiktionary.org/wiki/pasta#Finnish) | pasta (food) | /ˈpɑstɑ/ · noun |
| [yhdeksäs](https://en.wiktionary.org/wiki/yhdeks%C3%A4s#Finnish) | ninth | /ˈyhdeksæs/ · adj |
| [apina](https://en.wiktionary.org/wiki/apina#Finnish) | simian (ape, monkey or human; animal belonging to the infraorder Simiiformes within the order Primates) | /ˈɑpinɑ/ · noun |
| [georgia](https://en.wiktionary.org/wiki/georgia#Finnish) | Georgian language | /ˈɡeorɡiɑ/ · noun |
| [kuula](https://en.wiktionary.org/wiki/kuula#Finnish) | a hard ball, such as one made of metal | /ˈkuːlɑ/ · noun |
| [lattia](https://en.wiktionary.org/wiki/lattia#Finnish) | floor (bottom of a room) | /ˈlɑtːiɑ/ · noun |
| [mamma](https://en.wiktionary.org/wiki/mamma#Finnish) | An elder, plump woman. | /ˈmɑmːɑ/ · noun |
| [saku](https://en.wiktionary.org/wiki/saku#Finnish) | German, Kraut (German person) | /ˈsɑku/ · noun |
| [seis](https://en.wiktionary.org/wiki/seis#Finnish) | stop! (do not move! stop moving!) | /ˈsei̯s/ · intj |
| [uida](https://en.wiktionary.org/wiki/uida#Finnish) | to swim (move through water without touching the bottom) | /ˈui̯dɑˣ/ · verb |
| [Sale](https://en.wiktionary.org/wiki/Sale#Finnish) | Nickname for people named Sauli. | /ˈsɑle/ · noun |
| [graham](https://en.wiktionary.org/wiki/graham#Finnish) | graham (flour) | /ˈɡrɑ(ː)hɑm/ · noun |
| [kilo](https://en.wiktionary.org/wiki/kilo#Finnish) | kilogram, kilo | /ˈkilo/ · noun |

</details>

<details><summary>Words 901–950</summary>

![[Resources/Audio/fi/Words 0901-0950.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [luu](https://en.wiktionary.org/wiki/luu#Finnish) | bone (one of the rigid structural elements in a skeleton) | /ˈluː/ · noun |
| [marina](https://en.wiktionary.org/wiki/marina#Finnish) | continuing grumble, whining; quibble | /ˈmɑrinɑ/ · noun |
| [nelson](https://en.wiktionary.org/wiki/nelson#Finnish) | nelson | /ˈnels(ː)on/ · noun |
| [pam](https://en.wiktionary.org/wiki/pam#Finnish) | bam! | /ˈpɑm/ · intj |
| [päämäärä](https://en.wiktionary.org/wiki/p%C3%A4%C3%A4m%C3%A4%C3%A4r%C3%A4#Finnish) | goal, aim, objective, purpose, end | /ˈpæːˌmæːræ/ · noun |
| [saalis](https://en.wiktionary.org/wiki/saalis#Finnish) | prey, catch | /ˈsɑːlis/ · noun |
| [yksitoista](https://en.wiktionary.org/wiki/yksitoista#Finnish) | eleven | /ˈyksiˌtoi̯stɑ/ · num |
| [CV](https://en.wiktionary.org/wiki/CV#Finnish) | curriculum vitae, resumé | /ˈseːˌʋeː/ · noun |
| [graafinen](https://en.wiktionary.org/wiki/graafinen#Finnish) | graphic (drawn, pictorial) | /ˈɡrɑːfinen/ · adj |
| [huhtikuu](https://en.wiktionary.org/wiki/huhtikuu#Finnish) | April (month) | /ˈhuhtiˌkuː/ · noun |
| [kitara](https://en.wiktionary.org/wiki/kitara#Finnish) | guitar | /ˈkitɑrɑ/ · noun |
| [käyttöjärjestelmä](https://en.wiktionary.org/wiki/k%C3%A4ytt%C3%B6j%C3%A4rjestelm%C3%A4#Finnish) | operating system | /ˈkæy̯tːøˌjærjestelmæ/ · noun |
| [lokakuu](https://en.wiktionary.org/wiki/lokakuu#Finnish) | October (month) | /ˈlokɑˌkuː/ · noun |
| [manga](https://en.wiktionary.org/wiki/manga#Finnish) | manga (comic originating in Japan) | /ˈmɑŋːɑ/ · noun |
| [pilvi](https://en.wiktionary.org/wiki/pilvi#Finnish) | cloud (visible mass of water droplets suspended in the air; mass of dust, steam or smoke) | /ˈpilʋi/ · noun |
| [taulu](https://en.wiktionary.org/wiki/taulu#Finnish) | painting (illustration or artwork, especially one that is painted and when it exists physically) | /ˈtɑu̯lu/ · noun |
| [viisitoista](https://en.wiktionary.org/wiki/viisitoista#Finnish) | fifteen | /ˈʋiːsiˌtoi̯stɑ/ · num |
| [hauta](https://en.wiktionary.org/wiki/hauta#Finnish) | grave, tomb (excavation in the earth as a place of burial; place of interment in the ground, or loosely anywhere) | /ˈhɑu̯tɑ/ · noun |
| [kesäkuu](https://en.wiktionary.org/wiki/kes%C3%A4kuu#Finnish) | June (month) | /ˈkesæˌkuː/ · noun |
| [melissa](https://en.wiktionary.org/wiki/melissa#Finnish) | melissa (plant of the genus Melissa) | /ˈmelisːɑ/ · noun |
| [porkkana](https://en.wiktionary.org/wiki/porkkana#Finnish) | carrot (plant, Daucus carota subsp. sativus) | /ˈporkːɑnɑ/ · noun |
| [tuoli](https://en.wiktionary.org/wiki/tuoli#Finnish) | chair (piece of furniture for sitting) | /ˈtuo̯li/ · noun |
| [ujo](https://en.wiktionary.org/wiki/ujo#Finnish) | shy, coy, timid, bashful | /ˈujo/ · adj |
| [ele](https://en.wiktionary.org/wiki/ele#Finnish) | gesture, sign | /ˈeleˣ/ · noun |
| [eve](https://en.wiktionary.org/wiki/eve#Finnish) | ecstasy (drug) | /ˈeʋe/ · noun |
| [inhimillinen](https://en.wiktionary.org/wiki/inhimillinen#Finnish) | human | /ˈinhimilːinen/ · adj |
| [mieto](https://en.wiktionary.org/wiki/mieto#Finnish) | mild, bland | /ˈmie̯to/ · adj |
| [tragedia](https://en.wiktionary.org/wiki/tragedia#Finnish) | tragedy | /ˈtrɑɡediɑ/ · noun |
| [viiva](https://en.wiktionary.org/wiki/viiva#Finnish) | line (straight, very narrow shape; continuous mark) | /ˈʋiːʋɑ/ · noun |
| [agenda](https://en.wiktionary.org/wiki/agenda#Finnish) | agenda | /ˈɑɡendɑ/ · noun |
| [kostaa](https://en.wiktionary.org/wiki/kostaa#Finnish) | to avenge, revenge, take revenge, get back at (on); to retaliate (to) | /ˈkostɑːˣ/ · verb |
| [kukko](https://en.wiktionary.org/wiki/kukko#Finnish) | cock, rooster (male chicken) | /ˈkukːo/ · noun |
| [lava](https://en.wiktionary.org/wiki/lava#Finnish) | platform; podium (a flat, raised surface) | /ˈlɑʋɑ/ · noun |
| [main](https://en.wiktionary.org/wiki/main#Finnish) | in ... region, in the vicinity of, around ... | /ˈmɑi̯n/ · postp |
| [naida](https://en.wiktionary.org/wiki/naida#Finnish) | to marry, wed (take as one's spouse) | /ˈnɑi̯dɑˣ/ · verb |
| [peto](https://en.wiktionary.org/wiki/peto#Finnish) | predator | /ˈpeto/ · noun |
| [radikaali](https://en.wiktionary.org/wiki/radikaali#Finnish) | radical | /ˈrɑdikɑːli/ · adj |
| [kirjoittaminen](https://en.wiktionary.org/wiki/kirjoittaminen) | writing |  · noun |
| [duo](https://en.wiktionary.org/wiki/duo#Finnish) | duo (twosome of musicians performing together) | /ˈdu(ː)o/ · noun |
| [fantasia](https://en.wiktionary.org/wiki/fantasia#Finnish) | fantasy | /ˈfɑntɑsiɑ/ · noun |
| [latvia](https://en.wiktionary.org/wiki/latvia#Finnish) | Latvian (language) | /ˈlɑtʋiɑ/ · noun |
| [maaliskuu](https://en.wiktionary.org/wiki/maaliskuu#Finnish) | March (month) | /ˈmɑːlisˌkuː/ · noun |
| [nais](https://en.wiktionary.org/wiki/nais#Finnish) | nice | /ˈnɑi̯s/ · adj |
| [nukke](https://en.wiktionary.org/wiki/nukke#Finnish) | doll | /ˈnukːe/ · noun |
| [river](https://en.wiktionary.org/wiki/river#Finnish) | river (fifth communal card in Texas hold'em) | /ˈriʋer/ · noun |
| [taikuri](https://en.wiktionary.org/wiki/taikuri#Finnish) | magician, conjurer/conjuror | /ˈtɑi̯kuri/ · noun |
| [baseball](https://en.wiktionary.org/wiki/baseball#Finnish) | baseball | /ˈbei̯sboːl/ · noun |
| [bravo](https://en.wiktionary.org/wiki/bravo#Finnish) | bravo | /ˈbrɑʋo(ː)/ · intj |
| [country](https://en.wiktionary.org/wiki/country#Finnish) | country music | /ˈkɑntri/ · noun |
| [lukeminen](https://en.wiktionary.org/wiki/lukeminen) | reading |  · noun |

</details>

<details><summary>Words 951–1000</summary>

![[Resources/Audio/fi/Words 0951-1000.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [delta](https://en.wiktionary.org/wiki/delta#Finnish) | delta (Greek letter) | /ˈdelt(ː)ɑ/ · noun |
| [drive-in](https://en.wiktionary.org/wiki/drive-in#Finnish) | drive-in (any establishment providing drive-in service) | /ˈdrɑi̯ʋˌin/ · noun |
| [emo](https://en.wiktionary.org/wiki/emo#Finnish) | mother (animal female parent) | /ˈemo/ · noun |
| [eno](https://en.wiktionary.org/wiki/eno#Finnish) | maternal uncle, uncle | /ˈeno/ · noun |
| [joulukuu](https://en.wiktionary.org/wiki/joulukuu#Finnish) | December (month) | /ˈjou̯luˌkuː/ · noun |
| [lelu](https://en.wiktionary.org/wiki/lelu#Finnish) | toy | /ˈlelu/ · noun |
| [narttu](https://en.wiktionary.org/wiki/narttu#Finnish) | bitch (female dog) | /ˈnɑrtːu/ · noun |
| [oire](https://en.wiktionary.org/wiki/oire#Finnish) | symptom | /ˈoi̯reˣ/ · noun |
| [sormus](https://en.wiktionary.org/wiki/sormus#Finnish) | ring, finger ring (jewelry worn around the finger) | /ˈsormus/ · noun |
| [viski](https://en.wiktionary.org/wiki/viski#Finnish) | whiskey/whisky (type of liquor) | /ˈʋiski/ · noun |
| [bulgaria](https://en.wiktionary.org/wiki/bulgaria#Finnish) | Bulgarian (language) | /ˈbulɡɑ(ː)riɑ/ · noun |
| [lohikäärme](https://en.wiktionary.org/wiki/lohik%C3%A4%C3%A4rme#Finnish) | dragon, drake | /ˈlohiˌkæːrmeˣ/ · noun |
| [paniikki](https://en.wiktionary.org/wiki/paniikki#Finnish) | panic | /ˈpɑniːkːi/ · noun |
| [pika](https://en.wiktionary.org/wiki/pika#Finnish) | pika | /ˈpikɑ/ · noun |
| [sorsa](https://en.wiktionary.org/wiki/sorsa#Finnish) | duck (bird of the Anatidae family) | /ˈsorsɑ/ · noun |
| [trio](https://en.wiktionary.org/wiki/trio#Finnish) | trio | /ˈtrio/ · noun |
| [uhrata](https://en.wiktionary.org/wiki/uhrata#Finnish) | to sacrifice | /ˈuhrɑtɑˣ/ · verb |
| [vasara](https://en.wiktionary.org/wiki/vasara#Finnish) | hammer (tool) | /ˈʋɑsɑrɑ/ · noun |
| [vihata](https://en.wiktionary.org/wiki/vihata#Finnish) | to hate | /ˈʋihɑtɑˣ/ · verb |
| [byrokratia](https://en.wiktionary.org/wiki/byrokratia#Finnish) | bureaucracy | /ˈbyroˌkrɑtiɑ/ · noun |
| [des](https://en.wiktionary.org/wiki/des#Finnish) | D-flat | /ˈdes/ · noun |
| [gloria](https://en.wiktionary.org/wiki/gloria#Finnish) | glory (optical phenomenon) | /ˈɡloriɑ/ · noun |
| [potkia](https://en.wiktionary.org/wiki/potkia#Finnish) | to kick (repeatedly/continuously) | /ˈpotkiɑˣ/ · verb |
| [semi](https://en.wiktionary.org/wiki/semi#Finnish) | mid, mediocre, not bad, not good | /ˈsemi/ · adj |
| [donna](https://en.wiktionary.org/wiki/donna#Finnish) | woman | /ˈdonːɑ/ · noun |
| [essi](https://en.wiktionary.org/wiki/essi#Finnish) | ecstasy, X (drug) | /ˈesːi/ · noun |
| [haka](https://en.wiktionary.org/wiki/haka#Finnish) | hook, clasp (type of fastener) | /ˈhɑkɑ/ · noun |
| [hiekka](https://en.wiktionary.org/wiki/hiekka#Finnish) | sand (fine-grained, finely-ground rock: according to the technical definition, with a grain size between 0.063 and 2.0 millimetres) | /ˈhie̯kːɑ/ · noun |
| [hymyillä](https://en.wiktionary.org/wiki/hymyill%C3%A4#Finnish) | to smile | /ˈhymyi̯lːæˣ/ · verb |
| [laser](https://en.wiktionary.org/wiki/laser#Finnish) | laser | /ˈlɑ(ː)ser/ · noun |
| [meksikolainen](https://en.wiktionary.org/wiki/meksikolainen#Finnish) | Mexican (person) | /ˈmeksikolɑi̯nen/ · noun |
| [nova](https://en.wiktionary.org/wiki/nova#Finnish) | nova (sudden brightening of a previously inconspicuous star) | /ˈnoʋɑ/ · noun |
| [dollari](https://en.wiktionary.org/wiki/dollari#Finnish) | dollar (unit of currency in the US, Canada, Australia, NZ, Hong Kong and Singapore) | /ˈdolːɑri/ · noun |
| [his](https://en.wiktionary.org/wiki/his#Finnish) | B-sharp | /ˈhis/ · noun |
| [näkö](https://en.wiktionary.org/wiki/n%C3%A4k%C3%B6#Finnish) | sight, vision, eyesight | /ˈnækø/ · noun |
| [soul](https://en.wiktionary.org/wiki/soul#Finnish) | soul music | /ˈsou̯l/ · noun |
| [värikäs](https://en.wiktionary.org/wiki/v%C3%A4rik%C3%A4s#Finnish) | colorful/colourful | /ˈʋærikæs/ · adj |
| [ympyrä](https://en.wiktionary.org/wiki/ympyr%C3%A4#Finnish) | circle | /ˈympyræ/ · noun |
| [hot dog](https://en.wiktionary.org/wiki/hot%20dog#Finnish) | hot dog (frankfurter in a bun) | /ˈhotdoɡ/ · noun |
| [kata](https://en.wiktionary.org/wiki/kata#Finnish) | synonym of loimiletti | /ˈkɑtɑ/ · noun |
| [konstaapeli](https://en.wiktionary.org/wiki/konstaapeli#Finnish) | constable (policeman belonging to the lowest ranks of a police force) | /ˈkonstɑːpeli/ · noun |
| [kostea](https://en.wiktionary.org/wiki/kostea#Finnish) | moist, humid, damp, wet (with high humidity or some liquid, but not completely impregnated) | /ˈkosteɑ/ · adj |
| [käärme](https://en.wiktionary.org/wiki/k%C3%A4%C3%A4rme#Finnish) | snake, Serpentes | /ˈkæːrmeˣ/ · noun |
| [liettua](https://en.wiktionary.org/wiki/liettua#Finnish) | Lithuanian (language) | /ˈlie̯tːuɑ/ · noun |
| [markka](https://en.wiktionary.org/wiki/markka#Finnish) | mark (a currency used in many European countries, notably Germany and Finland; currently in use only in Bosnia and Herzegovina, see: convertible mark) | /ˈmɑrkːɑ/ · noun |
| [mode](https://en.wiktionary.org/wiki/mode#Finnish) | synonym of moderaattori | /ˈmode/ · noun |
| [perhonen](https://en.wiktionary.org/wiki/perhonen#Finnish) | insect of the order Lepidoptera; butterfly, moth or skipper. | /ˈperhonen/ · noun |
| [à](https://en.wiktionary.org/wiki/%C3%A0#Finnish) | a, per, each | /ˈɑ/ · adv |
| [hui](https://en.wiktionary.org/wiki/hui#Finnish) | oh! (an exclamation when scared or startled) | /ˈhui̯/ · intj |
| [mehiläinen](https://en.wiktionary.org/wiki/mehil%C3%A4inen#Finnish) | bee (flying insect of the clade Anthophila) | /ˈmehilæi̯nen/ · noun |

</details>

## Question bank

Try before opening the answers. Different tasks use the same sentence to practise complementary skills. Open translation and explanation tasks can have valid alternatives.

### Personal pronouns · 50 questions

**fi-Q0001 · Fill the gap**

____ vaativat taistelulle loppua.

They called for an end to the fighting.

[[Finnish#^fi-Q0001-answer|Compare the answer]]
^fi-Q0001

**fi-Q0002 · Choose the form**

____ vaativat taistelulle loppua.

They called for an end to the fighting.

Choices: sinä / He / minä / hän

[[Finnish#^fi-Q0002-answer|Compare the answer]]
^fi-Q0002

**fi-Q0003 · Edit the changed sentence**

【sinä】 olen jo rakastunut sinuun.

I'm in love with you already.

[[Finnish#^fi-Q0003-answer|Compare the answer]]
^fi-Q0003

**fi-Q0004 · Build the sentence**

Arrange: jo / rakastunut / sinuun. / olen / Minä

I'm in love with you already.

[[Finnish#^fi-Q0004-answer|Compare the answer]]
^fi-Q0004

**fi-Q0005 · Write a translation**

Write this in Finnish: I am not a penguin.

[[Finnish#^fi-Q0005-answer|Compare the answer]]
^fi-Q0005

**fi-Q0006 · Explain the grammar**

【Minä】 en ole pingviini.

I am not a penguin.

[[Finnish#^fi-Q0006-answer|Compare the answer]]
^fi-Q0006

**fi-Q0007 · Fill the gap**

____ on elossa!

She's alive!

[[Finnish#^fi-Q0007-answer|Compare the answer]]
^fi-Q0007

**fi-Q0008 · Choose the form**

____ on elossa!

She's alive!

Choices: me / Hän / sinä / minä

[[Finnish#^fi-Q0008-answer|Compare the answer]]
^fi-Q0008

**fi-Q0009 · Edit the changed sentence**

Et saa koskaan tietää, ellet 【minä】 yritä.

You'll never know unless you try.

[[Finnish#^fi-Q0009-answer|Compare the answer]]
^fi-Q0009

**fi-Q0010 · Build the sentence**

Arrange: tietää, / yritä. / Et / sinä / saa / koskaan / ellet

You'll never know unless you try.

[[Finnish#^fi-Q0010-answer|Compare the answer]]
^fi-Q0010

**fi-Q0011 · Write a translation**

Write this in Finnish: He is in a bad mood.

[[Finnish#^fi-Q0011-answer|Compare the answer]]
^fi-Q0011

**fi-Q0012 · Explain the grammar**

【Hän】 on huonolla tuulella.

He is in a bad mood.

[[Finnish#^fi-Q0012-answer|Compare the answer]]
^fi-Q0012

**fi-Q0013 · Fill the gap**

En ____ tiedä, että pystynkö minä siihen, mutta minä yritän.

I don't know whether I can do it, but I'll try.

[[Finnish#^fi-Q0013-answer|Compare the answer]]
^fi-Q0013

**fi-Q0014 · Choose the form**

En ____ tiedä, että pystynkö minä siihen, mutta minä yritän.

I don't know whether I can do it, but I'll try.

Choices: me / hän / sinä / minä

[[Finnish#^fi-Q0014-answer|Compare the answer]]
^fi-Q0014

**fi-Q0015 · Edit the changed sentence**

【sinä】 en ole koskaan käynyt Amerikassa.

I have never been to America.

[[Finnish#^fi-Q0015-answer|Compare the answer]]
^fi-Q0015

**fi-Q0016 · Build the sentence**

Arrange: en / Minä / ole / käynyt / koskaan / Amerikassa.

I have never been to America.

[[Finnish#^fi-Q0016-answer|Compare the answer]]
^fi-Q0016

**fi-Q0017 · Write a translation**

Write this in Finnish: You haven't eaten anything.

[[Finnish#^fi-Q0017-answer|Compare the answer]]
^fi-Q0017

**fi-Q0018 · Explain the grammar**

【Sinä】 et ole syönyt mitään.

You haven't eaten anything.

[[Finnish#^fi-Q0018-answer|Compare the answer]]
^fi-Q0018

**fi-Q0019 · Fill the gap**

____ voimme tehdä sen.

We can do that.

[[Finnish#^fi-Q0019-answer|Compare the answer]]
^fi-Q0019

**fi-Q0020 · Choose the form**

____ voimme tehdä sen.

We can do that.

Choices: Me / minä / sinä / hän

[[Finnish#^fi-Q0020-answer|Compare the answer]]
^fi-Q0020

**fi-Q0021 · Edit the changed sentence**

Vaikka 【minä】 onkin rikas, ei hän ole onnellinen.

Rich as she is, she is not happy.

[[Finnish#^fi-Q0021-answer|Compare the answer]]
^fi-Q0021

**fi-Q0022 · Build the sentence**

Arrange: Vaikka / ei / onnellinen. / rikas, / hän / hän / onkin / ole

Rich as she is, she is not happy.

[[Finnish#^fi-Q0022-answer|Compare the answer]]
^fi-Q0022

**fi-Q0023 · Write a translation**

Write this in Finnish: We have changed.

[[Finnish#^fi-Q0023-answer|Compare the answer]]
^fi-Q0023

**fi-Q0024 · Explain the grammar**

【Me】 ollaan muututtu.

We have changed.

[[Finnish#^fi-Q0024-answer|Compare the answer]]
^fi-Q0024

**fi-Q0025 · Fill the gap**

____ kietoi kätensä hänen kaulaansa.

She wrapped her arms around his neck.

[[Finnish#^fi-Q0025-answer|Compare the answer]]
^fi-Q0025

**fi-Q0026 · Choose the form**

____ kietoi kätensä hänen kaulaansa.

She wrapped her arms around his neck.

Choices: Hän / sinä / minä / me

[[Finnish#^fi-Q0026-answer|Compare the answer]]
^fi-Q0026

**fi-Q0027 · Edit the changed sentence**

Sinne korkean vuoren huipulle rakensivat 【minä】 itselleen pienen kaupungin ja elivät rauhassa.

There on the top of a high mountain they built a small town of their own and lived in peace.

[[Finnish#^fi-Q0027-answer|Compare the answer]]
^fi-Q0027

**fi-Q0028 · Build the sentence**

Arrange: he / rakensivat / rauhassa. / Sinne / pienen / ja / huipulle / vuoren / korkean / elivät / kaupungin / itselleen

There on the top of a high mountain they built a small town of their own and lived in peace.

[[Finnish#^fi-Q0028-answer|Compare the answer]]
^fi-Q0028

**fi-Q0029 · Write a translation**

Write this in Finnish: I read the book.

[[Finnish#^fi-Q0029-answer|Compare the answer]]
^fi-Q0029

**fi-Q0030 · Explain the grammar**

【Minä】 luin sen kirjan.

I read the book.

[[Finnish#^fi-Q0030-answer|Compare the answer]]
^fi-Q0030

**fi-Q0031 · Fill the gap**

Tomi sanoo, että ____ käy lenkillä vähintään kolme kertaa viikossa.

Tom says he goes jogging at least three times a week.

[[Finnish#^fi-Q0031-answer|Compare the answer]]
^fi-Q0031

**fi-Q0032 · Choose the form**

Tomi sanoo, että ____ käy lenkillä vähintään kolme kertaa viikossa.

Tom says he goes jogging at least three times a week.

Choices: me / sinä / hän / minä

[[Finnish#^fi-Q0032-answer|Compare the answer]]
^fi-Q0032

**fi-Q0033 · Edit the changed sentence**

Sopiiko, että 【sinä】 istun tähän?

May I sit here?

[[Finnish#^fi-Q0033-answer|Compare the answer]]
^fi-Q0033

**fi-Q0034 · Build the sentence**

Arrange: istun / tähän? / että / Sopiiko, / minä

May I sit here?

[[Finnish#^fi-Q0034-answer|Compare the answer]]
^fi-Q0034

**fi-Q0035 · Write a translation**

Write this in Finnish: She is no saint.

[[Finnish#^fi-Q0035-answer|Compare the answer]]
^fi-Q0035

**fi-Q0036 · Explain the grammar**

【Hän】 ei ole mikään pyhimys.

She is no saint.

[[Finnish#^fi-Q0036-answer|Compare the answer]]
^fi-Q0036

**fi-Q0037 · Fill the gap**

No, mitä ____ teen?

So what do I do?

[[Finnish#^fi-Q0037-answer|Compare the answer]]
^fi-Q0037

**fi-Q0038 · Choose the form**

No, mitä ____ teen?

So what do I do?

Choices: hän / me / minä / sinä

[[Finnish#^fi-Q0038-answer|Compare the answer]]
^fi-Q0038

**fi-Q0039 · Edit the changed sentence**

【minä】 saattoivat odottaa kymmenen vuoden vankilatuomiota.

They could face a ten-year prison term.

[[Finnish#^fi-Q0039-answer|Compare the answer]]
^fi-Q0039

**fi-Q0040 · Build the sentence**

Arrange: saattoivat / He / vankilatuomiota. / vuoden / odottaa / kymmenen

They could face a ten-year prison term.

[[Finnish#^fi-Q0040-answer|Compare the answer]]
^fi-Q0040

**fi-Q0041 · Write a translation**

Write this in Finnish: And again he was drunk as anything.

[[Finnish#^fi-Q0041-answer|Compare the answer]]
^fi-Q0041

**fi-Q0042 · Explain the grammar**

Ja taas 【hän】 oli niin humalassa kuin vain voi olla.

And again he was drunk as anything.

[[Finnish#^fi-Q0042-answer|Compare the answer]]
^fi-Q0042

**fi-Q0043 · Fill the gap**

____ ei tiennyt naineensa hirviön.

She didn't know she had married a monster.

[[Finnish#^fi-Q0043-answer|Compare the answer]]
^fi-Q0043

**fi-Q0044 · Choose the form**

____ ei tiennyt naineensa hirviön.

She didn't know she had married a monster.

Choices: Hän / sinä / me / minä

[[Finnish#^fi-Q0044-answer|Compare the answer]]
^fi-Q0044

**fi-Q0045 · Edit the changed sentence**

【minä】 lupasi tulla, mutta ei tullut.

He promised to come, but he didn't come.

[[Finnish#^fi-Q0045-answer|Compare the answer]]
^fi-Q0045

**fi-Q0046 · Build the sentence**

Arrange: Hän / tullut. / tulla, / mutta / lupasi / ei

He promised to come, but he didn't come.

[[Finnish#^fi-Q0046-answer|Compare the answer]]
^fi-Q0046

**fi-Q0047 · Write a translation**

Write this in Finnish: Tom certainly wasn't at home when we went to visit him.

[[Finnish#^fi-Q0047-answer|Compare the answer]]
^fi-Q0047

**fi-Q0048 · Explain the grammar**

Tom ei tosiaankaan ollut kotona, kun 【me】 menimme käymään hänen luonaan.

Tom certainly wasn't at home when we went to visit him.

[[Finnish#^fi-Q0048-answer|Compare the answer]]
^fi-Q0048

**fi-Q0049 · Fill the gap**

____ et ole tappaja enkä ole minäkään.

You're not a killer and neither am I.

[[Finnish#^fi-Q0049-answer|Compare the answer]]
^fi-Q0049

**fi-Q0050 · Choose the form**

____ et ole tappaja enkä ole minäkään.

You're not a killer and neither am I.

Choices: minä / Sinä / hän / me

[[Finnish#^fi-Q0050-answer|Compare the answer]]
^fi-Q0050


### Present olla · 50 questions

**fi-Q0051 · Edit the changed sentence**

Kahden kauppa 【olen】 kolmannen korvapuusti.

When two people quarrel, a third rejoices.

[[Finnish#^fi-Q0051-answer|Compare the answer]]
^fi-Q0051

**fi-Q0052 · Build the sentence**

Arrange: kolmannen / on / kauppa / Kahden / korvapuusti.

When two people quarrel, a third rejoices.

[[Finnish#^fi-Q0052-answer|Compare the answer]]
^fi-Q0052

**fi-Q0053 · Write a translation**

Write this in Finnish: Tom is grumpy.

[[Finnish#^fi-Q0053-answer|Compare the answer]]
^fi-Q0053

**fi-Q0054 · Explain the grammar**

Tomi 【on】 äreä.

Tom is grumpy.

[[Finnish#^fi-Q0054-answer|Compare the answer]]
^fi-Q0054

**fi-Q0055 · Fill the gap**

Tomin operoinut kirurgi ____ hyvin kokenut ja erittäin arvostettu.

The surgeon who did Tom's operation is very experienced and highly regarded.

[[Finnish#^fi-Q0055-answer|Compare the answer]]
^fi-Q0055

**fi-Q0056 · Choose the form**

Tomin operoinut kirurgi ____ hyvin kokenut ja erittäin arvostettu.

The surgeon who did Tom's operation is very experienced and highly regarded.

Choices: on / olen / olet / olemme

[[Finnish#^fi-Q0056-answer|Compare the answer]]
^fi-Q0056

**fi-Q0057 · Edit the changed sentence**

”Minua ei huvita juoda tänään.” ”Älä viitsi, nyt 【olen】 syntymäpäiväni.”

"I don't feel like drinking today." "Come on, it's my birthday!"

[[Finnish#^fi-Q0057-answer|Compare the answer]]
^fi-Q0057

**fi-Q0058 · Build the sentence**

Arrange: ”Älä / syntymäpäiväni.” / tänään.” / viitsi, / huvita / on / ”Minua / nyt / ei / juoda

"I don't feel like drinking today." "Come on, it's my birthday!"

[[Finnish#^fi-Q0058-answer|Compare the answer]]
^fi-Q0058

**fi-Q0059 · Write a translation**

Write this in Finnish: Tom's terrified.

[[Finnish#^fi-Q0059-answer|Compare the answer]]
^fi-Q0059

**fi-Q0060 · Explain the grammar**

Tomi 【on】 kauhistunut.

Tom's terrified.

[[Finnish#^fi-Q0060-answer|Compare the answer]]
^fi-Q0060

**fi-Q0061 · Fill the gap**

Vaikuttaa siltä, että ____ humalassa.

You seem to be drunk.

[[Finnish#^fi-Q0061-answer|Compare the answer]]
^fi-Q0061

**fi-Q0062 · Choose the form**

Vaikuttaa siltä, että ____ humalassa.

You seem to be drunk.

Choices: olen / olet / olemme / on

[[Finnish#^fi-Q0062-answer|Compare the answer]]
^fi-Q0062

**fi-Q0063 · Edit the changed sentence**

Tomilla 【olen】 lounastapaaminen Maryn kanssa.

Tom has a lunch date with Mary.

[[Finnish#^fi-Q0063-answer|Compare the answer]]
^fi-Q0063

**fi-Q0064 · Build the sentence**

Arrange: Maryn / lounastapaaminen / Tomilla / on / kanssa.

Tom has a lunch date with Mary.

[[Finnish#^fi-Q0064-answer|Compare the answer]]
^fi-Q0064

**fi-Q0065 · Write a translation**

Write this in Finnish: Tom has moved away.

[[Finnish#^fi-Q0065-answer|Compare the answer]]
^fi-Q0065

**fi-Q0066 · Explain the grammar**

Tomi 【on】 liikkunut pois.

Tom has moved away.

[[Finnish#^fi-Q0066-answer|Compare the answer]]
^fi-Q0066

**fi-Q0067 · Fill the gap**

____ eri mieltä.

I don't agree.

[[Finnish#^fi-Q0067-answer|Compare the answer]]
^fi-Q0067

**fi-Q0068 · Choose the form**

____ eri mieltä.

I don't agree.

Choices: olemme / Olen / on / olet

[[Finnish#^fi-Q0068-answer|Compare the answer]]
^fi-Q0068

**fi-Q0069 · Edit the changed sentence**

Kakun leikkaaminen samankokoisiin paloihin 【olen】 aika vaikeaa.

Cutting a cake into equal pieces is rather difficult.

[[Finnish#^fi-Q0069-answer|Compare the answer]]
^fi-Q0069

**fi-Q0070 · Build the sentence**

Arrange: Kakun / on / vaikeaa. / leikkaaminen / aika / samankokoisiin / paloihin

Cutting a cake into equal pieces is rather difficult.

[[Finnish#^fi-Q0070-answer|Compare the answer]]
^fi-Q0070

**fi-Q0071 · Write a translation**

Write this in Finnish: You guys are insane!

[[Finnish#^fi-Q0071-answer|Compare the answer]]
^fi-Q0071

**fi-Q0072 · Explain the grammar**

Jätkät 【on】 hulluja!

You guys are insane!

[[Finnish#^fi-Q0072-answer|Compare the answer]]
^fi-Q0072

**fi-Q0073 · Fill the gap**

Mulla ____ tatska.

I have a tattoo.

[[Finnish#^fi-Q0073-answer|Compare the answer]]
^fi-Q0073

**fi-Q0074 · Choose the form**

Mulla ____ tatska.

I have a tattoo.

Choices: olen / olemme / on / olet

[[Finnish#^fi-Q0074-answer|Compare the answer]]
^fi-Q0074

**fi-Q0075 · Edit the changed sentence**

Hei, sun 【olen】 pakko nähdä tää.

Hey, you've got to see this.

[[Finnish#^fi-Q0075-answer|Compare the answer]]
^fi-Q0075

**fi-Q0076 · Build the sentence**

Arrange: sun / nähdä / on / Hei, / pakko / tää.

Hey, you've got to see this.

[[Finnish#^fi-Q0076-answer|Compare the answer]]
^fi-Q0076

**fi-Q0077 · Write a translation**

Write this in Finnish: Water is a liquid.

[[Finnish#^fi-Q0077-answer|Compare the answer]]
^fi-Q0077

**fi-Q0078 · Explain the grammar**

Vesi 【on】 neste.

Water is a liquid.

[[Finnish#^fi-Q0078-answer|Compare the answer]]
^fi-Q0078

**fi-Q0079 · Fill the gap**

Maailmassa ____ noin 1 800 miljardööriä.

There are about 1,800 billionaires in the world.

[[Finnish#^fi-Q0079-answer|Compare the answer]]
^fi-Q0079

**fi-Q0080 · Choose the form**

Maailmassa ____ noin 1 800 miljardööriä.

There are about 1,800 billionaires in the world.

Choices: on / olet / olemme / olen

[[Finnish#^fi-Q0080-answer|Compare the answer]]
^fi-Q0080

**fi-Q0081 · Edit the changed sentence**

Tyttäreni 【olen】 vain lapsi.

My daughter is but a child.

[[Finnish#^fi-Q0081-answer|Compare the answer]]
^fi-Q0081

**fi-Q0082 · Build the sentence**

Arrange: on / Tyttäreni / lapsi. / vain

My daughter is but a child.

[[Finnish#^fi-Q0082-answer|Compare the answer]]
^fi-Q0082

**fi-Q0083 · Write a translation**

Write this in Finnish: There are some things in this world that will never come true, no matter how much you wish for them.

[[Finnish#^fi-Q0083-answer|Compare the answer]]
^fi-Q0083

**fi-Q0084 · Explain the grammar**

Tässä maailmassa 【on】 joitain sellaisia asioita, jotka eivät tule ikinä toteen, ei vaikka kuinka toivoisit niitä.

There are some things in this world that will never come true, no matter how much you wish for them.

[[Finnish#^fi-Q0084-answer|Compare the answer]]
^fi-Q0084

**fi-Q0085 · Fill the gap**

Minun nimeni ____ Henry.

My name is Henry.

[[Finnish#^fi-Q0085-answer|Compare the answer]]
^fi-Q0085

**fi-Q0086 · Choose the form**

Minun nimeni ____ Henry.

My name is Henry.

Choices: olet / olen / olemme / on

[[Finnish#^fi-Q0086-answer|Compare the answer]]
^fi-Q0086

**fi-Q0087 · Edit the changed sentence**

Myönnän, että 【olet】 väärässä.

I'll admit I'm wrong.

[[Finnish#^fi-Q0087-answer|Compare the answer]]
^fi-Q0087

**fi-Q0088 · Build the sentence**

Arrange: olen / väärässä. / että / Myönnän,

I'll admit I'm wrong.

[[Finnish#^fi-Q0088-answer|Compare the answer]]
^fi-Q0088

**fi-Q0089 · Write a translation**

Write this in Finnish: I've had enough of your snide remarks.

[[Finnish#^fi-Q0089-answer|Compare the answer]]
^fi-Q0089

**fi-Q0090 · Explain the grammar**

【Olen】 saanut tarpeekseni sarkastisista huomautuksistasi.

I've had enough of your snide remarks.

[[Finnish#^fi-Q0090-answer|Compare the answer]]
^fi-Q0090

**fi-Q0091 · Fill the gap**

Naistenhuone ____ kolmannessa kerroksessa.

The ladies' room is on the third floor.

[[Finnish#^fi-Q0091-answer|Compare the answer]]
^fi-Q0091

**fi-Q0092 · Choose the form**

Naistenhuone ____ kolmannessa kerroksessa.

The ladies' room is on the third floor.

Choices: on / olemme / olen / olet

[[Finnish#^fi-Q0092-answer|Compare the answer]]
^fi-Q0092

**fi-Q0093 · Edit the changed sentence**

Se tuote 【olen】 loppu varastosta.

That article is out of stock.

[[Finnish#^fi-Q0093-answer|Compare the answer]]
^fi-Q0093

**fi-Q0094 · Build the sentence**

Arrange: tuote / loppu / Se / varastosta. / on

That article is out of stock.

[[Finnish#^fi-Q0094-answer|Compare the answer]]
^fi-Q0094

**fi-Q0095 · Write a translation**

Write this in Finnish: I'm sorry about yesterday.

[[Finnish#^fi-Q0095-answer|Compare the answer]]
^fi-Q0095

**fi-Q0096 · Explain the grammar**

【Olen】 pahoillani eilisestä.

I'm sorry about yesterday.

[[Finnish#^fi-Q0096-answer|Compare the answer]]
^fi-Q0096

**fi-Q0097 · Fill the gap**

Kolme kolmanteen ____ kaksikymmentäseitsemän.

3 to the third power is 27.

[[Finnish#^fi-Q0097-answer|Compare the answer]]
^fi-Q0097

**fi-Q0098 · Choose the form**

Kolme kolmanteen ____ kaksikymmentäseitsemän.

3 to the third power is 27.

Choices: olemme / olen / on / olet

[[Finnish#^fi-Q0098-answer|Compare the answer]]
^fi-Q0098

**fi-Q0099 · Edit the changed sentence**

Sinun seurassasi 【olen】 mukavaa olla.

You're fun to hang out with.

[[Finnish#^fi-Q0099-answer|Compare the answer]]
^fi-Q0099

**fi-Q0100 · Build the sentence**

Arrange: Sinun / seurassasi / olla. / mukavaa / on

You're fun to hang out with.

[[Finnish#^fi-Q0100-answer|Compare the answer]]
^fi-Q0100


### The negative verb · 50 questions

**fi-Q0101 · Write a translation**

Write this in Finnish: I vowed that I would never speak to her again.

[[Finnish#^fi-Q0101-answer|Compare the answer]]
^fi-Q0101

**fi-Q0102 · Explain the grammar**

Vannoin, että 【en】 puhuisi enää ikinä hänelle.

I vowed that I would never speak to her again.

[[Finnish#^fi-Q0102-answer|Compare the answer]]
^fi-Q0102

**fi-Q0103 · Fill the gap**

Miksi ____ ole vielä valmistanut illallista?

Why haven't you cooked dinner yet?

[[Finnish#^fi-Q0103-answer|Compare the answer]]
^fi-Q0103

**fi-Q0104 · Choose the form**

Miksi ____ ole vielä valmistanut illallista?

Why haven't you cooked dinner yet?

Choices: emme / et / ei / en

[[Finnish#^fi-Q0104-answer|Compare the answer]]
^fi-Q0104

**fi-Q0105 · Edit the changed sentence**

【et】 halua mennä naimisiin liian aikaisin.

I don't want to get married too early.

[[Finnish#^fi-Q0105-answer|Compare the answer]]
^fi-Q0105

**fi-Q0106 · Build the sentence**

Arrange: mennä / halua / liian / En / aikaisin. / naimisiin

I don't want to get married too early.

[[Finnish#^fi-Q0106-answer|Compare the answer]]
^fi-Q0106

**fi-Q0107 · Write a translation**

Write this in Finnish: I won't let that bother me.

[[Finnish#^fi-Q0107-answer|Compare the answer]]
^fi-Q0107

**fi-Q0108 · Explain the grammar**

【En】 anna sen vaivata minua.

I won't let that bother me.

[[Finnish#^fi-Q0108-answer|Compare the answer]]
^fi-Q0108

**fi-Q0109 · Fill the gap**

Kielen oppiminen ____ koskaan lopu.

Language learning never ends.

[[Finnish#^fi-Q0109-answer|Compare the answer]]
^fi-Q0109

**fi-Q0110 · Choose the form**

Kielen oppiminen ____ koskaan lopu.

Language learning never ends.

Choices: ei / et / emme / en

[[Finnish#^fi-Q0110-answer|Compare the answer]]
^fi-Q0110

**fi-Q0111 · Edit the changed sentence**

【et】 nyt menisi ihan niin pitkälle, että kutsuisin Suomea paratiisiksi.

I would not go so far as to call Finland a paradise.

[[Finnish#^fi-Q0111-answer|Compare the answer]]
^fi-Q0111

**fi-Q0112 · Build the sentence**

Arrange: niin / nyt / ihan / menisi / että / paratiisiksi. / kutsuisin / pitkälle, / Suomea / En

I would not go so far as to call Finland a paradise.

[[Finnish#^fi-Q0112-answer|Compare the answer]]
^fi-Q0112

**fi-Q0113 · Write a translation**

Write this in Finnish: There's no shortage of candidates.

[[Finnish#^fi-Q0113-answer|Compare the answer]]
^fi-Q0113

**fi-Q0114 · Explain the grammar**

【Ei】 ole puutetta ehdokkaista.

There's no shortage of candidates.

[[Finnish#^fi-Q0114-answer|Compare the answer]]
^fi-Q0114

**fi-Q0115 · Fill the gap**

Ihmisten ____ pitäisi rääkätä eläimiä.

People shouldn't abuse animals.

[[Finnish#^fi-Q0115-answer|Compare the answer]]
^fi-Q0115

**fi-Q0116 · Choose the form**

Ihmisten ____ pitäisi rääkätä eläimiä.

People shouldn't abuse animals.

Choices: et / emme / en / ei

[[Finnish#^fi-Q0116-answer|Compare the answer]]
^fi-Q0116

**fi-Q0117 · Edit the changed sentence**

【en】 voi muuttaa Tomia.

You can't change Tom.

[[Finnish#^fi-Q0117-answer|Compare the answer]]
^fi-Q0117

**fi-Q0118 · Build the sentence**

Arrange: Tomia. / voi / muuttaa / Et

You can't change Tom.

[[Finnish#^fi-Q0118-answer|Compare the answer]]
^fi-Q0118

**fi-Q0119 · Write a translation**

Write this in Finnish: Why can't you just call Tom?

[[Finnish#^fi-Q0119-answer|Compare the answer]]
^fi-Q0119

**fi-Q0120 · Explain the grammar**

Miksi 【et】 vain voi soittaa Tomille?

Why can't you just call Tom?

[[Finnish#^fi-Q0120-answer|Compare the answer]]
^fi-Q0120

**fi-Q0121 · Fill the gap**

Mä luulin, ____ Tomi vitsaili vaan.

I thought Tom was just kidding.

[[Finnish#^fi-Q0121-answer|Compare the answer]]
^fi-Q0121

**fi-Q0122 · Choose the form**

Mä luulin, ____ Tomi vitsaili vaan.

I thought Tom was just kidding.

Choices: emme / et / en / ei

[[Finnish#^fi-Q0122-answer|Compare the answer]]
^fi-Q0122

**fi-Q0123 · Edit the changed sentence**

Jos 【en】 kerro meille, niin me tapamme sinut.

If you don't tell us, we'll kill you.

[[Finnish#^fi-Q0123-answer|Compare the answer]]
^fi-Q0123

**fi-Q0124 · Build the sentence**

Arrange: et / Jos / meille, / kerro / me / sinut. / niin / tapamme

If you don't tell us, we'll kill you.

[[Finnish#^fi-Q0124-answer|Compare the answer]]
^fi-Q0124

**fi-Q0125 · Write a translation**

Write this in Finnish: Tom can't have written this letter himself.

[[Finnish#^fi-Q0125-answer|Compare the answer]]
^fi-Q0125

**fi-Q0126 · Explain the grammar**

Tom 【ei】 ole voinut kirjoittaa tätä kirjettä itse.

Tom can't have written this letter himself.

[[Finnish#^fi-Q0126-answer|Compare the answer]]
^fi-Q0126

**fi-Q0127 · Fill the gap**

____ halua puhua säästä.

I don't want to talk about the weather.

[[Finnish#^fi-Q0127-answer|Compare the answer]]
^fi-Q0127

**fi-Q0128 · Choose the form**

____ halua puhua säästä.

I don't want to talk about the weather.

Choices: En / ei / et / emme

[[Finnish#^fi-Q0128-answer|Compare the answer]]
^fi-Q0128

**fi-Q0129 · Edit the changed sentence**

Minua 【en】 kiinnosta panna rahojani sinun unelmiisi.

I have no interest in putting my money into your dreams.

[[Finnish#^fi-Q0129-answer|Compare the answer]]
^fi-Q0129

**fi-Q0130 · Build the sentence**

Arrange: kiinnosta / Minua / panna / ei / sinun / rahojani / unelmiisi.

I have no interest in putting my money into your dreams.

[[Finnish#^fi-Q0130-answer|Compare the answer]]
^fi-Q0130

**fi-Q0131 · Write a translation**

Write this in Finnish: You didn't write anything.

[[Finnish#^fi-Q0131-answer|Compare the answer]]
^fi-Q0131

**fi-Q0132 · Explain the grammar**

Te 【ette】 kirjoittaneet mitään.

You didn't write anything.

[[Finnish#^fi-Q0132-answer|Compare the answer]]
^fi-Q0132

**fi-Q0133 · Fill the gap**

Hän ____ elänyt päivääkään elämästään väkivallatta.

She didn't live a single day of her life without violence.

[[Finnish#^fi-Q0133-answer|Compare the answer]]
^fi-Q0133

**fi-Q0134 · Choose the form**

Hän ____ elänyt päivääkään elämästään väkivallatta.

She didn't live a single day of her life without violence.

Choices: emme / et / en / ei

[[Finnish#^fi-Q0134-answer|Compare the answer]]
^fi-Q0134

**fi-Q0135 · Edit the changed sentence**

【et】 ole pukeissa.

I'm not dressed.

[[Finnish#^fi-Q0135-answer|Compare the answer]]
^fi-Q0135

**fi-Q0136 · Build the sentence**

Arrange: pukeissa. / En / ole

I'm not dressed.

[[Finnish#^fi-Q0136-answer|Compare the answer]]
^fi-Q0136

**fi-Q0137 · Write a translation**

Write this in Finnish: You don't seem very busy.

[[Finnish#^fi-Q0137-answer|Compare the answer]]
^fi-Q0137

**fi-Q0138 · Explain the grammar**

【Et】 vaikuta kovin kiireiseltä.

You don't seem very busy.

[[Finnish#^fi-Q0138-answer|Compare the answer]]
^fi-Q0138

**fi-Q0139 · Fill the gap**

____ tunne itseäni kovin fiksuksi.

I don't feel so smart.

[[Finnish#^fi-Q0139-answer|Compare the answer]]
^fi-Q0139

**fi-Q0140 · Choose the form**

____ tunne itseäni kovin fiksuksi.

I don't feel so smart.

Choices: et / ei / emme / En

[[Finnish#^fi-Q0140-answer|Compare the answer]]
^fi-Q0140

**fi-Q0141 · Edit the changed sentence**

Tomi 【en】 onnistunut löytämään hattuaan.

Tom couldn't find his hat.

[[Finnish#^fi-Q0141-answer|Compare the answer]]
^fi-Q0141

**fi-Q0142 · Build the sentence**

Arrange: Tomi / löytämään / onnistunut / ei / hattuaan.

Tom couldn't find his hat.

[[Finnish#^fi-Q0142-answer|Compare the answer]]
^fi-Q0142

**fi-Q0143 · Write a translation**

Write this in Finnish: They won't believe me even if I swear it is true.

[[Finnish#^fi-Q0143-answer|Compare the answer]]
^fi-Q0143

**fi-Q0144 · Explain the grammar**

Minua he 【eivät】 uskoisi, vaikka vannoisin sen todeksi.

They won't believe me even if I swear it is true.

[[Finnish#^fi-Q0144-answer|Compare the answer]]
^fi-Q0144

**fi-Q0145 · Fill the gap**

____ voi kuvata tunteitani.

I cannot describe my feelings.

[[Finnish#^fi-Q0145-answer|Compare the answer]]
^fi-Q0145

**fi-Q0146 · Choose the form**

____ voi kuvata tunteitani.

I cannot describe my feelings.

Choices: et / emme / ei / En

[[Finnish#^fi-Q0146-answer|Compare the answer]]
^fi-Q0146

**fi-Q0147 · Edit the changed sentence**

【et】 nuku hyvin.

I do not sleep well.

[[Finnish#^fi-Q0147-answer|Compare the answer]]
^fi-Q0147

**fi-Q0148 · Build the sentence**

Arrange: nuku / hyvin. / En

I do not sleep well.

[[Finnish#^fi-Q0148-answer|Compare the answer]]
^fi-Q0148

**fi-Q0149 · Write a translation**

Write this in Finnish: I don't want to hurt her.

[[Finnish#^fi-Q0149-answer|Compare the answer]]
^fi-Q0149

**fi-Q0150 · Explain the grammar**

【En】 halua satuttaa häntä.

I don't want to hurt her.

[[Finnish#^fi-Q0150-answer|Compare the answer]]
^fi-Q0150


### Negative imperatives · 50 questions

**fi-Q0151 · Fill the gap**

____ ikinä yritä tehdä tätä itse.

Don't ever try to do this by yourself.

[[Finnish#^fi-Q0151-answer|Compare the answer]]
^fi-Q0151

**fi-Q0152 · Choose the form**

____ ikinä yritä tehdä tätä itse.

Don't ever try to do this by yourself.

Choices: Älä / älkää / ei / en

[[Finnish#^fi-Q0152-answer|Compare the answer]]
^fi-Q0152

**fi-Q0153 · Edit the changed sentence**

【älkää】 unohda laittaa postimerkkejä kirjeisiin, jotka annoin sinulle postitettavaksi.

Please don't forget to put stamps on the letters I gave you to post.

[[Finnish#^fi-Q0153-answer|Compare the answer]]
^fi-Q0153

**fi-Q0154 · Build the sentence**

Arrange: kirjeisiin, / Älä / jotka / sinulle / unohda / laittaa / postitettavaksi. / annoin / postimerkkejä

Please don't forget to put stamps on the letters I gave you to post.

[[Finnish#^fi-Q0154-answer|Compare the answer]]
^fi-Q0154

**fi-Q0155 · Write a translation**

Write this in Finnish: Don't drink beer before going to bed!

[[Finnish#^fi-Q0155-answer|Compare the answer]]
^fi-Q0155

**fi-Q0156 · Explain the grammar**

【Älä】 juo olutta ennen vuoteeseen menoa.

Don't drink beer before going to bed!

[[Finnish#^fi-Q0156-answer|Compare the answer]]
^fi-Q0156

**fi-Q0157 · Fill the gap**

____ sano, ettet osaa tehdä sitä ennen kuin yrität. Sinä et edes tee sitä, joten miten sinä voit sanoa, että et osaa tehdä sitä?

Don't say that you can't do it before trying. You're not even doing it so how can you say that you can't do it?

[[Finnish#^fi-Q0157-answer|Compare the answer]]
^fi-Q0157

**fi-Q0158 · Choose the form**

____ sano, ettet osaa tehdä sitä ennen kuin yrität. Sinä et edes tee sitä, joten miten sinä voit sanoa, että et osaa tehdä sitä?

Don't say that you can't do it before trying. You're not even doing it so how can you say that you can't do it?

Choices: ei / en / Älä / älkää

[[Finnish#^fi-Q0158-answer|Compare the answer]]
^fi-Q0158

**fi-Q0159 · Edit the changed sentence**

【älkää】 kerro juttuja koulusta.

Don't tell tales out of school.

[[Finnish#^fi-Q0159-answer|Compare the answer]]
^fi-Q0159

**fi-Q0160 · Build the sentence**

Arrange: kerro / Älä / juttuja / koulusta.

Don't tell tales out of school.

[[Finnish#^fi-Q0160-answer|Compare the answer]]
^fi-Q0160

**fi-Q0161 · Write a translation**

Write this in Finnish: Don't get me wrong.

[[Finnish#^fi-Q0161-answer|Compare the answer]]
^fi-Q0161

**fi-Q0162 · Explain the grammar**

【Älä】 käsitä minua väärin.

Don't get me wrong.

[[Finnish#^fi-Q0162-answer|Compare the answer]]
^fi-Q0162

**fi-Q0163 · Fill the gap**

____ koske mihinkään täällä.

Don't touch anything here.

[[Finnish#^fi-Q0163-answer|Compare the answer]]
^fi-Q0163

**fi-Q0164 · Choose the form**

____ koske mihinkään täällä.

Don't touch anything here.

Choices: Älä / ei / älkää / en

[[Finnish#^fi-Q0164-answer|Compare the answer]]
^fi-Q0164

**fi-Q0165 · Edit the changed sentence**

【älkää】 koskaan vittuile vittupäälle!

Never fuck with a fucker!

[[Finnish#^fi-Q0165-answer|Compare the answer]]
^fi-Q0165

**fi-Q0166 · Build the sentence**

Arrange: vittupäälle! / koskaan / vittuile / Älä

Never fuck with a fucker!

[[Finnish#^fi-Q0166-answer|Compare the answer]]
^fi-Q0166

**fi-Q0167 · Write a translation**

Write this in Finnish: Don't cut this tree down.

[[Finnish#^fi-Q0167-answer|Compare the answer]]
^fi-Q0167

**fi-Q0168 · Explain the grammar**

【Älä】 kaada tätä puuta.

Don't cut this tree down.

[[Finnish#^fi-Q0168-answer|Compare the answer]]
^fi-Q0168

**fi-Q0169 · Fill the gap**

____ avaa suutasi!

Don't open your mouth.

[[Finnish#^fi-Q0169-answer|Compare the answer]]
^fi-Q0169

**fi-Q0170 · Choose the form**

____ avaa suutasi!

Don't open your mouth.

Choices: en / älkää / Älä / ei

[[Finnish#^fi-Q0170-answer|Compare the answer]]
^fi-Q0170

**fi-Q0171 · Edit the changed sentence**

【älä】 menettäkö tajuntojanne.

Don't pass out on me.

[[Finnish#^fi-Q0171-answer|Compare the answer]]
^fi-Q0171

**fi-Q0172 · Build the sentence**

Arrange: menettäkö / tajuntojanne. / Älkää

Don't pass out on me.

[[Finnish#^fi-Q0172-answer|Compare the answer]]
^fi-Q0172

**fi-Q0173 · Write a translation**

Write this in Finnish: In your dreams!

[[Finnish#^fi-Q0173-answer|Compare the answer]]
^fi-Q0173

**fi-Q0174 · Explain the grammar**

【Älä】 unta näe!

In your dreams!

[[Finnish#^fi-Q0174-answer|Compare the answer]]
^fi-Q0174

**fi-Q0175 · Fill the gap**

____ heitä pois tätä lehteä. En ole lukenut sitä vielä.

Don't throw away this magazine. I haven't read it yet.

[[Finnish#^fi-Q0175-answer|Compare the answer]]
^fi-Q0175

**fi-Q0176 · Choose the form**

____ heitä pois tätä lehteä. En ole lukenut sitä vielä.

Don't throw away this magazine. I haven't read it yet.

Choices: en / Älä / ei / älkää

[[Finnish#^fi-Q0176-answer|Compare the answer]]
^fi-Q0176

**fi-Q0177 · Edit the changed sentence**

【älkää】 julkaise sivuston ilmapiiriä huonontavia kirjoituksia.

Please refrain from making posts that make this site less pleasant to visit.

[[Finnish#^fi-Q0177-answer|Compare the answer]]
^fi-Q0177

**fi-Q0178 · Build the sentence**

Arrange: huonontavia / kirjoituksia. / Älä / ilmapiiriä / julkaise / sivuston

Please refrain from making posts that make this site less pleasant to visit.

[[Finnish#^fi-Q0178-answer|Compare the answer]]
^fi-Q0178

**fi-Q0179 · Write a translation**

Write this in Finnish: Don't blame me for this.

[[Finnish#^fi-Q0179-answer|Compare the answer]]
^fi-Q0179

**fi-Q0180 · Explain the grammar**

【Älkää】 syyttäkö meitä tästä.

Don't blame me for this.

[[Finnish#^fi-Q0180-answer|Compare the answer]]
^fi-Q0180

**fi-Q0181 · Fill the gap**

____ ole niin vahingoniloinen!

Don't be so gleeful!

[[Finnish#^fi-Q0181-answer|Compare the answer]]
^fi-Q0181

**fi-Q0182 · Choose the form**

____ ole niin vahingoniloinen!

Don't be so gleeful!

Choices: en / Älä / ei / älkää

[[Finnish#^fi-Q0182-answer|Compare the answer]]
^fi-Q0182

**fi-Q0183 · Edit the changed sentence**

【älkää】 laita sitä vielä pois.

Don't put that away yet.

[[Finnish#^fi-Q0183-answer|Compare the answer]]
^fi-Q0183

**fi-Q0184 · Build the sentence**

Arrange: Älä / vielä / sitä / laita / pois.

Don't put that away yet.

[[Finnish#^fi-Q0184-answer|Compare the answer]]
^fi-Q0184

**fi-Q0185 · Write a translation**

Write this in Finnish: Come on, let's go.

[[Finnish#^fi-Q0185-answer|Compare the answer]]
^fi-Q0185

**fi-Q0186 · Explain the grammar**

【Älä】 viitsi, mennään.

Come on, let's go.

[[Finnish#^fi-Q0186-answer|Compare the answer]]
^fi-Q0186

**fi-Q0187 · Fill the gap**

____ räpäytä silmiä.

Don't blink.

[[Finnish#^fi-Q0187-answer|Compare the answer]]
^fi-Q0187

**fi-Q0188 · Choose the form**

____ räpäytä silmiä.

Don't blink.

Choices: Älä / älkää / ei / en

[[Finnish#^fi-Q0188-answer|Compare the answer]]
^fi-Q0188

**fi-Q0189 · Edit the changed sentence**

Ole kiltti ja 【älkää】 pakota minua menemään.

Please don't force me to go.

[[Finnish#^fi-Q0189-answer|Compare the answer]]
^fi-Q0189

**fi-Q0190 · Build the sentence**

Arrange: minua / Ole / älä / ja / pakota / menemään. / kiltti

Please don't force me to go.

[[Finnish#^fi-Q0190-answer|Compare the answer]]
^fi-Q0190

**fi-Q0191 · Write a translation**

Write this in Finnish: Don't lie.

[[Finnish#^fi-Q0191-answer|Compare the answer]]
^fi-Q0191

**fi-Q0192 · Explain the grammar**

【Älä】 puhu palturia.

Don't lie.

[[Finnish#^fi-Q0192-answer|Compare the answer]]
^fi-Q0192

**fi-Q0193 · Fill the gap**

____ kuuntele häntä, hän puhuu pötyä.

Don't listen to him, he's talking nonsense.

[[Finnish#^fi-Q0193-answer|Compare the answer]]
^fi-Q0193

**fi-Q0194 · Choose the form**

____ kuuntele häntä, hän puhuu pötyä.

Don't listen to him, he's talking nonsense.

Choices: Älä / en / älkää / ei

[[Finnish#^fi-Q0194-answer|Compare the answer]]
^fi-Q0194

**fi-Q0195 · Edit the changed sentence**

【älkää】 unohda ottaa sateenvarjoasi mukaan lähtiessäsi.

Don't forget to take your umbrella when you leave.

[[Finnish#^fi-Q0195-answer|Compare the answer]]
^fi-Q0195

**fi-Q0196 · Build the sentence**

Arrange: mukaan / lähtiessäsi. / Älä / ottaa / sateenvarjoasi / unohda

Don't forget to take your umbrella when you leave.

[[Finnish#^fi-Q0196-answer|Compare the answer]]
^fi-Q0196

**fi-Q0197 · Write a translation**

Write this in Finnish: If you come to Rio, don't forget to call me to be your guide!

[[Finnish#^fi-Q0197-answer|Compare the answer]]
^fi-Q0197

**fi-Q0198 · Explain the grammar**

【Älä】 unohda soittaa minulle jos tulet Rioon, niin minä voin olla oppaasi!

If you come to Rio, don't forget to call me to be your guide!

[[Finnish#^fi-Q0198-answer|Compare the answer]]
^fi-Q0198

**fi-Q0199 · Fill the gap**

____ puhu niin paljon seuraavalla kerralla.

Don't talk so much next time.

[[Finnish#^fi-Q0199-answer|Compare the answer]]
^fi-Q0199

**fi-Q0200 · Choose the form**

____ puhu niin paljon seuraavalla kerralla.

Don't talk so much next time.

Choices: ei / Älä / älkää / en

[[Finnish#^fi-Q0200-answer|Compare the answer]]
^fi-Q0200


### Past olla · 50 questions

**fi-Q0201 · Edit the changed sentence**

Mary 【olin】 heidän suuri faninsa.

Mary is a big fan of theirs.

[[Finnish#^fi-Q0201-answer|Compare the answer]]
^fi-Q0201

**fi-Q0202 · Build the sentence**

Arrange: oli / Mary / suuri / faninsa. / heidän

Mary is a big fan of theirs.

[[Finnish#^fi-Q0202-answer|Compare the answer]]
^fi-Q0202

**fi-Q0203 · Write a translation**

Write this in Finnish: The room was packed.

[[Finnish#^fi-Q0203-answer|Compare the answer]]
^fi-Q0203

**fi-Q0204 · Explain the grammar**

Huone 【oli】 tupaten täynnä.

The room was packed.

[[Finnish#^fi-Q0204-answer|Compare the answer]]
^fi-Q0204

**fi-Q0205 · Fill the gap**

Kahdesti ja kolmasti ____ sinua rakastanut, ennen kuin tunsin naamaasi tahi nimeäsi.

Twice and thrice had I loved thee before I knew thy face or name.

[[Finnish#^fi-Q0205-answer|Compare the answer]]
^fi-Q0205

**fi-Q0206 · Choose the form**

Kahdesti ja kolmasti ____ sinua rakastanut, ennen kuin tunsin naamaasi tahi nimeäsi.

Twice and thrice had I loved thee before I knew thy face or name.

Choices: olin / olimme / oli / olit

[[Finnish#^fi-Q0206-answer|Compare the answer]]
^fi-Q0206

**fi-Q0207 · Edit the changed sentence**

Luulin, että Tom 【olin】 vaikeuksissa.

I thought Tom was in trouble.

[[Finnish#^fi-Q0207-answer|Compare the answer]]
^fi-Q0207

**fi-Q0208 · Build the sentence**

Arrange: vaikeuksissa. / Luulin, / Tom / että / oli

I thought Tom was in trouble.

[[Finnish#^fi-Q0208-answer|Compare the answer]]
^fi-Q0208

**fi-Q0209 · Write a translation**

Write this in Finnish: Yesterday was my birthday.

[[Finnish#^fi-Q0209-answer|Compare the answer]]
^fi-Q0209

**fi-Q0210 · Explain the grammar**

Eilen 【oli】 minun syntymäpäiväni.

Yesterday was my birthday.

[[Finnish#^fi-Q0210-answer|Compare the answer]]
^fi-Q0210

**fi-Q0211 · Fill the gap**

Vaikkakin hän ____ vaikeasti loukkaantunut, hän onnistui pääsemään puhelimeen.

Though seriously injured, he managed to get to a telephone.

[[Finnish#^fi-Q0211-answer|Compare the answer]]
^fi-Q0211

**fi-Q0212 · Choose the form**

Vaikkakin hän ____ vaikeasti loukkaantunut, hän onnistui pääsemään puhelimeen.

Though seriously injured, he managed to get to a telephone.

Choices: olin / oli / olimme / olit

[[Finnish#^fi-Q0212-answer|Compare the answer]]
^fi-Q0212

**fi-Q0213 · Edit the changed sentence**

Hän 【olin】 tyytyväinen elämäänsä.

She was content with her life.

[[Finnish#^fi-Q0213-answer|Compare the answer]]
^fi-Q0213

**fi-Q0214 · Build the sentence**

Arrange: tyytyväinen / oli / elämäänsä. / Hän

She was content with her life.

[[Finnish#^fi-Q0214-answer|Compare the answer]]
^fi-Q0214

**fi-Q0215 · Write a translation**

Write this in Finnish: The squirrel was more than twenty meters away from us.

[[Finnish#^fi-Q0215-answer|Compare the answer]]
^fi-Q0215

**fi-Q0216 · Explain the grammar**

Orava 【oli】 yli kahdenkymmenen metrin päässä meistä.

The squirrel was more than twenty meters away from us.

[[Finnish#^fi-Q0216-answer|Compare the answer]]
^fi-Q0216

**fi-Q0217 · Fill the gap**

Tomi teeskenteli sitä, että hän ____ Marin ystävä.

Tom pretended to be Mary's friend.

[[Finnish#^fi-Q0217-answer|Compare the answer]]
^fi-Q0217

**fi-Q0218 · Choose the form**

Tomi teeskenteli sitä, että hän ____ Marin ystävä.

Tom pretended to be Mary's friend.

Choices: olimme / oli / olit / olin

[[Finnish#^fi-Q0218-answer|Compare the answer]]
^fi-Q0218

**fi-Q0219 · Edit the changed sentence**

Tom sanoi, että hänellä 【olin】 ongelmia Marin kanssa.

Tom said he was having problems with Mary.

[[Finnish#^fi-Q0219-answer|Compare the answer]]
^fi-Q0219

**fi-Q0220 · Build the sentence**

Arrange: kanssa. / hänellä / ongelmia / oli / Marin / että / Tom / sanoi,

Tom said he was having problems with Mary.

[[Finnish#^fi-Q0220-answer|Compare the answer]]
^fi-Q0220

**fi-Q0221 · Write a translation**

Write this in Finnish: I said, "Five months worth of the Pill, please," and was told "Certainly."

[[Finnish#^fi-Q0221-answer|Compare the answer]]
^fi-Q0221

**fi-Q0222 · Explain the grammar**

Pyysin viiden kuukauden pillerikuurin, ja vastaus 【oli】 "totta kai".

I said, "Five months worth of the Pill, please," and was told "Certainly."

[[Finnish#^fi-Q0222-answer|Compare the answer]]
^fi-Q0222

**fi-Q0223 · Fill the gap**

Tomin isoisoisä ____ Bostonin kaupunginjohtaja.

Tom's great-grandfather was the mayor of Boston.

[[Finnish#^fi-Q0223-answer|Compare the answer]]
^fi-Q0223

**fi-Q0224 · Choose the form**

Tomin isoisoisä ____ Bostonin kaupunginjohtaja.

Tom's great-grandfather was the mayor of Boston.

Choices: oli / olit / olimme / olin

[[Finnish#^fi-Q0224-answer|Compare the answer]]
^fi-Q0224

**fi-Q0225 · Edit the changed sentence**

No 【olin】 jo vittu aikakin!

It's about fucking time.

[[Finnish#^fi-Q0225-answer|Compare the answer]]
^fi-Q0225

**fi-Q0226 · Build the sentence**

Arrange: aikakin! / jo / vittu / No / oli

It's about fucking time.

[[Finnish#^fi-Q0226-answer|Compare the answer]]
^fi-Q0226

**fi-Q0227 · Write a translation**

Write this in Finnish: Before Tom and Mary realized what was happening, their friendship had turned into love.

[[Finnish#^fi-Q0227-answer|Compare the answer]]
^fi-Q0227

**fi-Q0228 · Explain the grammar**

Ennen kuin Tom ja Mary huomasivatkaan mitä tapahtui, heidän ystävyytensä 【oli】 muuttunut rakkaudeksi.

Before Tom and Mary realized what was happening, their friendship had turned into love.

[[Finnish#^fi-Q0228-answer|Compare the answer]]
^fi-Q0228

**fi-Q0229 · Fill the gap**

Radio ____ Marconin keksimä.

The radio was invented by Marconi.

[[Finnish#^fi-Q0229-answer|Compare the answer]]
^fi-Q0229

**fi-Q0230 · Choose the form**

Radio ____ Marconin keksimä.

The radio was invented by Marconi.

Choices: olimme / oli / olit / olin

[[Finnish#^fi-Q0230-answer|Compare the answer]]
^fi-Q0230

**fi-Q0231 · Edit the changed sentence**

Hän 【olin】 hyvällä tuulella.

He was in good spirits.

[[Finnish#^fi-Q0231-answer|Compare the answer]]
^fi-Q0231

**fi-Q0232 · Build the sentence**

Arrange: hyvällä / tuulella. / Hän / oli

He was in good spirits.

[[Finnish#^fi-Q0232-answer|Compare the answer]]
^fi-Q0232

**fi-Q0233 · Write a translation**

Write this in Finnish: Tom was Mary's stepchild.

[[Finnish#^fi-Q0233-answer|Compare the answer]]
^fi-Q0233

**fi-Q0234 · Explain the grammar**

Tom 【oli】 Maryn lapsipuoli.

Tom was Mary's stepchild.

[[Finnish#^fi-Q0234-answer|Compare the answer]]
^fi-Q0234

**fi-Q0235 · Fill the gap**

West-niminen henkilö soitti sinä aikana kun ____ poissa kotoa.

A person named West called while you were out.

[[Finnish#^fi-Q0235-answer|Compare the answer]]
^fi-Q0235

**fi-Q0236 · Choose the form**

West-niminen henkilö soitti sinä aikana kun ____ poissa kotoa.

A person named West called while you were out.

Choices: olimme / oli / olit / olin

[[Finnish#^fi-Q0236-answer|Compare the answer]]
^fi-Q0236

**fi-Q0237 · Edit the changed sentence**

Tom halusi tietää, mitä 【olin】 tapahtunut.

Tom wanted to know what had happened.

[[Finnish#^fi-Q0237-answer|Compare the answer]]
^fi-Q0237

**fi-Q0238 · Build the sentence**

Arrange: mitä / oli / halusi / tietää, / tapahtunut. / Tom

Tom wanted to know what had happened.

[[Finnish#^fi-Q0238-answer|Compare the answer]]
^fi-Q0238

**fi-Q0239 · Write a translation**

Write this in Finnish: Tom thought that Mary had a boyfriend.

[[Finnish#^fi-Q0239-answer|Compare the answer]]
^fi-Q0239

**fi-Q0240 · Explain the grammar**

Tomista Marilla 【oli】 poikaystävä.

Tom thought that Mary had a boyfriend.

[[Finnish#^fi-Q0240-answer|Compare the answer]]
^fi-Q0240

**fi-Q0241 · Fill the gap**

Luulin että minulla ____ vapaapäivä.

I thought I had a day off.

[[Finnish#^fi-Q0241-answer|Compare the answer]]
^fi-Q0241

**fi-Q0242 · Choose the form**

Luulin että minulla ____ vapaapäivä.

I thought I had a day off.

Choices: olit / olimme / oli / olin

[[Finnish#^fi-Q0242-answer|Compare the answer]]
^fi-Q0242

**fi-Q0243 · Edit the changed sentence**

Tämä päivä 【olin】 poikkeuksellisen rasittava.

This day was exceptionally tiring.

[[Finnish#^fi-Q0243-answer|Compare the answer]]
^fi-Q0243

**fi-Q0244 · Build the sentence**

Arrange: oli / Tämä / rasittava. / päivä / poikkeuksellisen

This day was exceptionally tiring.

[[Finnish#^fi-Q0244-answer|Compare the answer]]
^fi-Q0244

**fi-Q0245 · Write a translation**

Write this in Finnish: I wondered what had happened to Tom.

[[Finnish#^fi-Q0245-answer|Compare the answer]]
^fi-Q0245

**fi-Q0246 · Explain the grammar**

Ihmettelin mitä Tomille 【oli】 sattunut.

I wondered what had happened to Tom.

[[Finnish#^fi-Q0246-answer|Compare the answer]]
^fi-Q0246

**fi-Q0247 · Fill the gap**

Juoksin hänen peräänsä kantaen paperipinoa, jonka hän ____ jättänyt lähtiessään.

I ran after him with a pile of papers that he'd left behind.

[[Finnish#^fi-Q0247-answer|Compare the answer]]
^fi-Q0247

**fi-Q0248 · Choose the form**

Juoksin hänen peräänsä kantaen paperipinoa, jonka hän ____ jättänyt lähtiessään.

I ran after him with a pile of papers that he'd left behind.

Choices: olit / olimme / olin / oli

[[Finnish#^fi-Q0248-answer|Compare the answer]]
^fi-Q0248

**fi-Q0249 · Edit the changed sentence**

Minulla 【olin】 jonkin verran vaikeuksia.

I had some trouble.

[[Finnish#^fi-Q0249-answer|Compare the answer]]
^fi-Q0249

**fi-Q0250 · Build the sentence**

Arrange: Minulla / oli / verran / jonkin / vaikeuksia.

I had some trouble.

[[Finnish#^fi-Q0250-answer|Compare the answer]]
^fi-Q0250


### Partitive nouns · 50 questions

**fi-Q0251 · Write a translation**

Write this in Finnish: I'm going to get myself some coffee. Do you want some?

[[Finnish#^fi-Q0251-answer|Compare the answer]]
^fi-Q0251

**fi-Q0252 · Explain the grammar**

Käyn hakemassa vähän 【kahvia】. Haluatko sinäkin?

I'm going to get myself some coffee. Do you want some?

[[Finnish#^fi-Q0252-answer|Compare the answer]]
^fi-Q0252

**fi-Q0253 · Fill the gap**

Kuinka monta ____ luette kuukaudessa?

How many books do you read a month?

[[Finnish#^fi-Q0253-answer|Compare the answer]]
^fi-Q0253

**fi-Q0254 · Choose the form**

Kuinka monta ____ luette kuukaudessa?

How many books do you read a month?

Choices: aikaa / vettä / kahvia / kirjaa

[[Finnish#^fi-Q0254-answer|Compare the answer]]
^fi-Q0254

**fi-Q0255 · Edit the changed sentence**

Mä luulen, että meillä on tarpeeksi 【kirjaa】.

I think we have enough money.

[[Finnish#^fi-Q0255-answer|Compare the answer]]
^fi-Q0255

**fi-Q0256 · Build the sentence**

Arrange: meillä / että / rahaa. / on / Mä / luulen, / tarpeeksi

I think we have enough money.

[[Finnish#^fi-Q0256-answer|Compare the answer]]
^fi-Q0256

**fi-Q0257 · Write a translation**

Write this in Finnish: Time is money.

[[Finnish#^fi-Q0257-answer|Compare the answer]]
^fi-Q0257

**fi-Q0258 · Explain the grammar**

Aika on 【rahaa】.

Time is money.

[[Finnish#^fi-Q0258-answer|Compare the answer]]
^fi-Q0258

**fi-Q0259 · Fill the gap**

En voi olla kahdessa paikassa yhtä ____.

I can't be in two places at once.

[[Finnish#^fi-Q0259-answer|Compare the answer]]
^fi-Q0259

**fi-Q0260 · Choose the form**

En voi olla kahdessa paikassa yhtä ____.

I can't be in two places at once.

Choices: kahvia / kirjaa / aikaa / vettä

[[Finnish#^fi-Q0260-answer|Compare the answer]]
^fi-Q0260

**fi-Q0261 · Edit the changed sentence**

Minun täytyy nostaa hieman 【kirjaa】 pankista.

I have to take some money out of the bank.

[[Finnish#^fi-Q0261-answer|Compare the answer]]
^fi-Q0261

**fi-Q0262 · Build the sentence**

Arrange: nostaa / hieman / Minun / pankista. / täytyy / rahaa

I have to take some money out of the bank.

[[Finnish#^fi-Q0262-answer|Compare the answer]]
^fi-Q0262

**fi-Q0263 · Write a translation**

Write this in Finnish: Are you still reading that book?

[[Finnish#^fi-Q0263-answer|Compare the answer]]
^fi-Q0263

**fi-Q0264 · Explain the grammar**

Luetko vielä sitä 【kirjaa】?

Are you still reading that book?

[[Finnish#^fi-Q0264-answer|Compare the answer]]
^fi-Q0264

**fi-Q0265 · Fill the gap**

Jos minulla olisi ____, opiskelisin ranskaa.

If I had time, I would study French.

[[Finnish#^fi-Q0265-answer|Compare the answer]]
^fi-Q0265

**fi-Q0266 · Choose the form**

Jos minulla olisi ____, opiskelisin ranskaa.

If I had time, I would study French.

Choices: vettä / kirjaa / aikaa / kahvia

[[Finnish#^fi-Q0266-answer|Compare the answer]]
^fi-Q0266

**fi-Q0267 · Edit the changed sentence**

Ostan usein 【kirjaa】 Tomille.

I often buy food for Tom.

[[Finnish#^fi-Q0267-answer|Compare the answer]]
^fi-Q0267

**fi-Q0268 · Build the sentence**

Arrange: Tomille. / usein / ruokaa / Ostan

I often buy food for Tom.

[[Finnish#^fi-Q0268-answer|Compare the answer]]
^fi-Q0268

**fi-Q0269 · Write a translation**

Write this in Finnish: He poured himself a tall glass of milk.

[[Finnish#^fi-Q0269-answer|Compare the answer]]
^fi-Q0269

**fi-Q0270 · Explain the grammar**

Hän kaatoi itselleen ison lasin 【maitoa】.

He poured himself a tall glass of milk.

[[Finnish#^fi-Q0270-answer|Compare the answer]]
^fi-Q0270

**fi-Q0271 · Fill the gap**

Juo enemmän ____.

Drink more water.

[[Finnish#^fi-Q0271-answer|Compare the answer]]
^fi-Q0271

**fi-Q0272 · Choose the form**

Juo enemmän ____.

Drink more water.

Choices: vettä / kirjaa / aikaa / kahvia

[[Finnish#^fi-Q0272-answer|Compare the answer]]
^fi-Q0272

**fi-Q0273 · Edit the changed sentence**

Etkö ottaisi vielä vähän lisää 【kirjaa】?

Won't you have some more tea?

[[Finnish#^fi-Q0273-answer|Compare the answer]]
^fi-Q0273

**fi-Q0274 · Build the sentence**

Arrange: lisää / vähän / teetä? / vielä / Etkö / ottaisi

Won't you have some more tea?

[[Finnish#^fi-Q0274-answer|Compare the answer]]
^fi-Q0274

**fi-Q0275 · Write a translation**

Write this in Finnish: Do you have a few minutes to talk?

[[Finnish#^fi-Q0275-answer|Compare the answer]]
^fi-Q0275

**fi-Q0276 · Explain the grammar**

Onko sinulla muutama minuuttia 【aikaa】 puhua?

Do you have a few minutes to talk?

[[Finnish#^fi-Q0276-answer|Compare the answer]]
^fi-Q0276

**fi-Q0277 · Fill the gap**

Minä luen ____.

I am reading a book.

[[Finnish#^fi-Q0277-answer|Compare the answer]]
^fi-Q0277

**fi-Q0278 · Choose the form**

Minä luen ____.

I am reading a book.

Choices: kirjaa / kahvia / aikaa / vettä

[[Finnish#^fi-Q0278-answer|Compare the answer]]
^fi-Q0278

**fi-Q0279 · Edit the changed sentence**

Olin lukemassa 【vettä】.

I was reading a book.

[[Finnish#^fi-Q0279-answer|Compare the answer]]
^fi-Q0279

**fi-Q0280 · Build the sentence**

Arrange: Olin / kirjaa. / lukemassa

I was reading a book.

[[Finnish#^fi-Q0280-answer|Compare the answer]]
^fi-Q0280

**fi-Q0281 · Write a translation**

Write this in Finnish: There is some water in the cup.

[[Finnish#^fi-Q0281-answer|Compare the answer]]
^fi-Q0281

**fi-Q0282 · Explain the grammar**

Kupissa on hieman 【vettä】.

There is some water in the cup.

[[Finnish#^fi-Q0282-answer|Compare the answer]]
^fi-Q0282

**fi-Q0283 · Fill the gap**

En voi juoda ____.

I can't drink milk.

[[Finnish#^fi-Q0283-answer|Compare the answer]]
^fi-Q0283

**fi-Q0284 · Choose the form**

En voi juoda ____.

I can't drink milk.

Choices: kahvia / kirjaa / vettä / maitoa

[[Finnish#^fi-Q0284-answer|Compare the answer]]
^fi-Q0284

**fi-Q0285 · Edit the changed sentence**

Haluaisitko 【kirjaa】 tai kahvia?

Would you like some tea or coffee?

[[Finnish#^fi-Q0285-answer|Compare the answer]]
^fi-Q0285

**fi-Q0286 · Build the sentence**

Arrange: Haluaisitko / kahvia? / teetä / tai

Would you like some tea or coffee?

[[Finnish#^fi-Q0286-answer|Compare the answer]]
^fi-Q0286

**fi-Q0287 · Write a translation**

Write this in Finnish: When you put money in the bank, you deposit it.

[[Finnish#^fi-Q0287-answer|Compare the answer]]
^fi-Q0287

**fi-Q0288 · Explain the grammar**

Kun laitat 【rahaa】 pankkiin, talletat sitä.

When you put money in the bank, you deposit it.

[[Finnish#^fi-Q0288-answer|Compare the answer]]
^fi-Q0288

**fi-Q0289 · Fill the gap**

Minä olen lukenut sitä ____.

I have read the book.

[[Finnish#^fi-Q0289-answer|Compare the answer]]
^fi-Q0289

**fi-Q0290 · Choose the form**

Minä olen lukenut sitä ____.

I have read the book.

Choices: kahvia / vettä / kirjaa / aikaa

[[Finnish#^fi-Q0290-answer|Compare the answer]]
^fi-Q0290

**fi-Q0291 · Edit the changed sentence**

Hapen reagoidessa vedyn kanssa syntyy 【kirjaa】.

Oxygen reacts with hydrogen to make water.

[[Finnish#^fi-Q0291-answer|Compare the answer]]
^fi-Q0291

**fi-Q0292 · Build the sentence**

Arrange: vedyn / kanssa / syntyy / reagoidessa / vettä. / Hapen

Oxygen reacts with hydrogen to make water.

[[Finnish#^fi-Q0292-answer|Compare the answer]]
^fi-Q0292

**fi-Q0293 · Write a translation**

Write this in Finnish: I always drink a cup of coffee every morning.

[[Finnish#^fi-Q0293-answer|Compare the answer]]
^fi-Q0293

**fi-Q0294 · Explain the grammar**

Juon aina joka aamu kupin 【kahvia】.

I always drink a cup of coffee every morning.

[[Finnish#^fi-Q0294-answer|Compare the answer]]
^fi-Q0294

**fi-Q0295 · Fill the gap**

Poliitikot ovat hyviä keräämään ____.

Politicians are good at raising money.

[[Finnish#^fi-Q0295-answer|Compare the answer]]
^fi-Q0295

**fi-Q0296 · Choose the form**

Poliitikot ovat hyviä keräämään ____.

Politicians are good at raising money.

Choices: rahaa / vettä / kahvia / kirjaa

[[Finnish#^fi-Q0296-answer|Compare the answer]]
^fi-Q0296

**fi-Q0297 · Edit the changed sentence**

Tomi antoi kodittomalle 【kirjaa】.

Tom gave the homeless man some food.

[[Finnish#^fi-Q0297-answer|Compare the answer]]
^fi-Q0297

**fi-Q0298 · Build the sentence**

Arrange: ruokaa. / kodittomalle / Tomi / antoi

Tom gave the homeless man some food.

[[Finnish#^fi-Q0298-answer|Compare the answer]]
^fi-Q0298

**fi-Q0299 · Write a translation**

Write this in Finnish: I don't have time to read.

[[Finnish#^fi-Q0299-answer|Compare the answer]]
^fi-Q0299

**fi-Q0300 · Explain the grammar**

Minulla ei ole 【aikaa】 lukea.

I don't have time to read.

[[Finnish#^fi-Q0300-answer|Compare the answer]]
^fi-Q0300


### Genitive singular · 50 questions

**fi-Q0301 · Fill the gap**

Haluan tuon ____ kuvan.

I want a picture of that dog.

[[Finnish#^fi-Q0301-answer|Compare the answer]]
^fi-Q0301

**fi-Q0302 · Choose the form**

Haluan tuon ____ kuvan.

I want a picture of that dog.

Choices: auton / koiran / kirjan / talon

[[Finnish#^fi-Q0302-answer|Compare the answer]]
^fi-Q0302

**fi-Q0303 · Edit the changed sentence**

Ostin uuden 【kirjan】 viime sunnuntaina.

Last Sunday I bought a new car.

[[Finnish#^fi-Q0303-answer|Compare the answer]]
^fi-Q0303

**fi-Q0304 · Build the sentence**

Arrange: uuden / sunnuntaina. / Ostin / auton / viime

Last Sunday I bought a new car.

[[Finnish#^fi-Q0304-answer|Compare the answer]]
^fi-Q0304

**fi-Q0305 · Write a translation**

Write this in Finnish: Tom bought a new car.

[[Finnish#^fi-Q0305-answer|Compare the answer]]
^fi-Q0305

**fi-Q0306 · Explain the grammar**

Tom osti uuden 【auton】.

Tom bought a new car.

[[Finnish#^fi-Q0306-answer|Compare the answer]]
^fi-Q0306

**fi-Q0307 · Fill the gap**

Toivon että voisin ostaan tuon ____ halvalla.

I wish I could buy that house cheap.

[[Finnish#^fi-Q0307-answer|Compare the answer]]
^fi-Q0307

**fi-Q0308 · Choose the form**

Toivon että voisin ostaan tuon ____ halvalla.

I wish I could buy that house cheap.

Choices: kirjan / auton / talon / lapsen

[[Finnish#^fi-Q0308-answer|Compare the answer]]
^fi-Q0308

**fi-Q0309 · Edit the changed sentence**

Palautin 【talon】 takaisin hyllylleen.

I returned the book to its shelf.

[[Finnish#^fi-Q0309-answer|Compare the answer]]
^fi-Q0309

**fi-Q0310 · Build the sentence**

Arrange: kirjan / takaisin / hyllylleen. / Palautin

I returned the book to its shelf.

[[Finnish#^fi-Q0310-answer|Compare the answer]]
^fi-Q0310

**fi-Q0311 · Write a translation**

Write this in Finnish: Tom bought a car using his savings.

[[Finnish#^fi-Q0311-answer|Compare the answer]]
^fi-Q0311

**fi-Q0312 · Explain the grammar**

Tom osti 【auton】 säästöillään.

Tom bought a car using his savings.

[[Finnish#^fi-Q0312-answer|Compare the answer]]
^fi-Q0312

**fi-Q0313 · Fill the gap**

Hänen äänensä kaikui halki hiljaisen ____.

Her voice echoed through the silent house.

[[Finnish#^fi-Q0313-answer|Compare the answer]]
^fi-Q0313

**fi-Q0314 · Choose the form**

Hänen äänensä kaikui halki hiljaisen ____.

Her voice echoed through the silent house.

Choices: auton / talon / kirjan / lapsen

[[Finnish#^fi-Q0314-answer|Compare the answer]]
^fi-Q0314

**fi-Q0315 · Edit the changed sentence**

Tom siivosi 【kirjan】 yksinään.

Tom cleaned the house by himself.

[[Finnish#^fi-Q0315-answer|Compare the answer]]
^fi-Q0315

**fi-Q0316 · Build the sentence**

Arrange: talon / Tom / yksinään. / siivosi

Tom cleaned the house by himself.

[[Finnish#^fi-Q0316-answer|Compare the answer]]
^fi-Q0316

**fi-Q0317 · Write a translation**

Write this in Finnish: I found the book by chance.

[[Finnish#^fi-Q0317-answer|Compare the answer]]
^fi-Q0317

**fi-Q0318 · Explain the grammar**

Minä löysin sen 【kirjan】 sattumalta.

I found the book by chance.

[[Finnish#^fi-Q0318-answer|Compare the answer]]
^fi-Q0318

**fi-Q0319 · Fill the gap**

Oletko nähnyt Tomin uuden ____?

Have you seen Tom's new house?

[[Finnish#^fi-Q0319-answer|Compare the answer]]
^fi-Q0319

**fi-Q0320 · Choose the form**

Oletko nähnyt Tomin uuden ____?

Have you seen Tom's new house?

Choices: auton / kirjan / talon / lapsen

[[Finnish#^fi-Q0320-answer|Compare the answer]]
^fi-Q0320

**fi-Q0321 · Edit the changed sentence**

Kuulitko jutun benjihyppääjästä, joka kuoli, koska hän laski väärin jokaisen kerroksen korkeuden ennen kuin hyppäsi alas 【kirjan】 katolta.

Did you hear the story about the bungee jumper who died because he miscalculated the height of each storey before diving off a building?

[[Finnish#^fi-Q0321-answer|Compare the answer]]
^fi-Q0321

**fi-Q0322 · Build the sentence**

Arrange: alas / korkeuden / väärin / koska / benjihyppääjästä, / kuin / joka / jokaisen / jutun / Kuulitko / laski / kerroksen / hyppäsi / hän / ennen / kuoli, / katolta. / talon

Did you hear the story about the bungee jumper who died because he miscalculated the height of each storey before diving off a building?

[[Finnish#^fi-Q0322-answer|Compare the answer]]
^fi-Q0322

**fi-Q0323 · Write a translation**

Write this in Finnish: I see a woman wearing black.

[[Finnish#^fi-Q0323-answer|Compare the answer]]
^fi-Q0323

**fi-Q0324 · Explain the grammar**

Näen erään 【naisen】 mustissa.

I see a woman wearing black.

[[Finnish#^fi-Q0324-answer|Compare the answer]]
^fi-Q0324

**fi-Q0325 · Fill the gap**

Hän pani ____ pöydälle.

He laid the book on the desk.

[[Finnish#^fi-Q0325-answer|Compare the answer]]
^fi-Q0325

**fi-Q0326 · Choose the form**

Hän pani ____ pöydälle.

He laid the book on the desk.

Choices: talon / lapsen / auton / kirjan

[[Finnish#^fi-Q0326-answer|Compare the answer]]
^fi-Q0326

**fi-Q0327 · Edit the changed sentence**

Kahden 【kirjan】 iät yhdessä vastasivat heidän isänsä ikää.

The ages of the two children put together was equivalent to that of their father.

[[Finnish#^fi-Q0327-answer|Compare the answer]]
^fi-Q0327

**fi-Q0328 · Build the sentence**

Arrange: Kahden / isänsä / heidän / yhdessä / iät / ikää. / vastasivat / lapsen

The ages of the two children put together was equivalent to that of their father.

[[Finnish#^fi-Q0328-answer|Compare the answer]]
^fi-Q0328

**fi-Q0329 · Write a translation**

Write this in Finnish: Tom saw Mary with another man.

[[Finnish#^fi-Q0329-answer|Compare the answer]]
^fi-Q0329

**fi-Q0330 · Explain the grammar**

Tom näki Marin toisen 【miehen】 seurassa.

Tom saw Mary with another man.

[[Finnish#^fi-Q0330-answer|Compare the answer]]
^fi-Q0330

**fi-Q0331 · Fill the gap**

Näen ____ ja naisen.

I see a man and a woman.

[[Finnish#^fi-Q0331-answer|Compare the answer]]
^fi-Q0331

**fi-Q0332 · Choose the form**

Näen ____ ja naisen.

I see a man and a woman.

Choices: talon / kirjan / auton / miehen

[[Finnish#^fi-Q0332-answer|Compare the answer]]
^fi-Q0332

**fi-Q0333 · Edit the changed sentence**

Olen jo lukenut tämän 【talon】 loppuun.

I have already finished reading this book.

[[Finnish#^fi-Q0333-answer|Compare the answer]]
^fi-Q0333

**fi-Q0334 · Build the sentence**

Arrange: tämän / lukenut / loppuun. / jo / Olen / kirjan

I have already finished reading this book.

[[Finnish#^fi-Q0334-answer|Compare the answer]]
^fi-Q0334

**fi-Q0335 · Write a translation**

Write this in Finnish: My father bought me the book.

[[Finnish#^fi-Q0335-answer|Compare the answer]]
^fi-Q0335

**fi-Q0336 · Explain the grammar**

Minun isäni osti minulle tuon 【kirjan】.

My father bought me the book.

[[Finnish#^fi-Q0336-answer|Compare the answer]]
^fi-Q0336

**fi-Q0337 · Fill the gap**

Mistä voin vuokrata ____?

Where can I hire a car?

[[Finnish#^fi-Q0337-answer|Compare the answer]]
^fi-Q0337

**fi-Q0338 · Choose the form**

Mistä voin vuokrata ____?

Where can I hire a car?

Choices: lapsen / kirjan / talon / auton

[[Finnish#^fi-Q0338-answer|Compare the answer]]
^fi-Q0338

**fi-Q0339 · Edit the changed sentence**

Hän käänsi 【talon】 ranskasta englanniksi.

He translated the book from French into English.

[[Finnish#^fi-Q0339-answer|Compare the answer]]
^fi-Q0339

**fi-Q0340 · Build the sentence**

Arrange: ranskasta / englanniksi. / kirjan / käänsi / Hän

He translated the book from French into English.

[[Finnish#^fi-Q0340-answer|Compare the answer]]
^fi-Q0340

**fi-Q0341 · Write a translation**

Write this in Finnish: I saw a young man lying on the bench under the cherry tree in the park.

[[Finnish#^fi-Q0341-answer|Compare the answer]]
^fi-Q0341

**fi-Q0342 · Explain the grammar**

Näin puistossa nuoren 【miehen】 makoilevan penkillä kirsikkapuun alla.

I saw a young man lying on the bench under the cherry tree in the park.

[[Finnish#^fi-Q0342-answer|Compare the answer]]
^fi-Q0342

**fi-Q0343 · Fill the gap**

Minun vaimoni haluaa adoptoida ____.

My wife wants to adopt a child.

[[Finnish#^fi-Q0343-answer|Compare the answer]]
^fi-Q0343

**fi-Q0344 · Choose the form**

Minun vaimoni haluaa adoptoida ____.

My wife wants to adopt a child.

Choices: talon / lapsen / kirjan / auton

[[Finnish#^fi-Q0344-answer|Compare the answer]]
^fi-Q0344

**fi-Q0345 · Edit the changed sentence**

Haluan sinun pesevän 【kirjan】.

I want you to wash the car.

[[Finnish#^fi-Q0345-answer|Compare the answer]]
^fi-Q0345

**fi-Q0346 · Build the sentence**

Arrange: pesevän / sinun / auton. / Haluan

I want you to wash the car.

[[Finnish#^fi-Q0346-answer|Compare the answer]]
^fi-Q0346

**fi-Q0347 · Write a translation**

Write this in Finnish: I want a car, but I have no money to buy one.

[[Finnish#^fi-Q0347-answer|Compare the answer]]
^fi-Q0347

**fi-Q0348 · Explain the grammar**

Haluan 【auton】, mutta minulla ei ole rahaa ostaa sellaista.

I want a car, but I have no money to buy one.

[[Finnish#^fi-Q0348-answer|Compare the answer]]
^fi-Q0348

**fi-Q0349 · Fill the gap**

Järjestimme ____ tulemaan vastaan sinua asemalle.

We arranged that a car meet you at the station.

[[Finnish#^fi-Q0349-answer|Compare the answer]]
^fi-Q0349

**fi-Q0350 · Choose the form**

Järjestimme ____ tulemaan vastaan sinua asemalle.

We arranged that a car meet you at the station.

Choices: talon / lapsen / kirjan / auton

[[Finnish#^fi-Q0350-answer|Compare the answer]]
^fi-Q0350


### Inessive location · 50 questions

**fi-Q0351 · Edit the changed sentence**

Tomi vietti puolet elämästään 【talossa】.

Tom lived half his life in Boston.

[[Finnish#^fi-Q0351-answer|Compare the answer]]
^fi-Q0351

**fi-Q0352 · Build the sentence**

Arrange: puolet / elämästään / vietti / Bostonissa. / Tomi

Tom lived half his life in Boston.

[[Finnish#^fi-Q0352-answer|Compare the answer]]
^fi-Q0352

**fi-Q0353 · Write a translation**

Write this in Finnish: Tom seemed to be staring at something in the corner of the room.

[[Finnish#^fi-Q0353-answer|Compare the answer]]
^fi-Q0353

**fi-Q0354 · Explain the grammar**

Tom vaikutti tuijottavan jotain huoneen 【nurkassa】.

Tom seemed to be staring at something in the corner of the room.

[[Finnish#^fi-Q0354-answer|Compare the answer]]
^fi-Q0354

**fi-Q0355 · Fill the gap**

Kävin ____ ennen aamupalaa.

I showered before breakfast.

[[Finnish#^fi-Q0355-answer|Compare the answer]]
^fi-Q0355

**fi-Q0356 · Choose the form**

Kävin ____ ennen aamupalaa.

I showered before breakfast.

Choices: suihkussa / koulussa / kaupungissa / talossa

[[Finnish#^fi-Q0356-answer|Compare the answer]]
^fi-Q0356

**fi-Q0357 · Edit the changed sentence**

Minun veljeni asuu 【talossa】.

My brother lives in Tokyo.

[[Finnish#^fi-Q0357-answer|Compare the answer]]
^fi-Q0357

**fi-Q0358 · Build the sentence**

Arrange: asuu / veljeni / Tokiossa. / Minun

My brother lives in Tokyo.

[[Finnish#^fi-Q0358-answer|Compare the answer]]
^fi-Q0358

**fi-Q0359 · Write a translation**

Write this in Finnish: A friend in hand is worth two in the bush!

[[Finnish#^fi-Q0359-answer|Compare the answer]]
^fi-Q0359

**fi-Q0360 · Explain the grammar**

Parempi ystävä 【pivossa】 kuin kymmenen oksalla.

A friend in hand is worth two in the bush!

[[Finnish#^fi-Q0360-answer|Compare the answer]]
^fi-Q0360

**fi-Q0361 · Fill the gap**

Onko Tom yhtään ____ kunnossa?

Is Tom any better?

[[Finnish#^fi-Q0361-answer|Compare the answer]]
^fi-Q0361

**fi-Q0362 · Choose the form**

Onko Tom yhtään ____ kunnossa?

Is Tom any better?

Choices: kaupungissa / koulussa / paremmassa / talossa

[[Finnish#^fi-Q0362-answer|Compare the answer]]
^fi-Q0362

**fi-Q0363 · Edit the changed sentence**

Hänet tapettiin 【talossa】.

He was killed in the battle.

[[Finnish#^fi-Q0363-answer|Compare the answer]]
^fi-Q0363

**fi-Q0364 · Build the sentence**

Arrange: taistelussa. / Hänet / tapettiin

He was killed in the battle.

[[Finnish#^fi-Q0364-answer|Compare the answer]]
^fi-Q0364

**fi-Q0365 · Write a translation**

Write this in Finnish: By giving us the opinions of the uneducated, journalism keeps us in touch with the ignorance of the community.

[[Finnish#^fi-Q0365-answer|Compare the answer]]
^fi-Q0365

**fi-Q0366 · Explain the grammar**

Antamalla meidän tietoomme oppimattomien mielipiteitä journalismi pitää meidät 【yhteydessä】 yhteisön tietämättömyyteen.

By giving us the opinions of the uneducated, journalism keeps us in touch with the ignorance of the community.

[[Finnish#^fi-Q0366-answer|Compare the answer]]
^fi-Q0366

**fi-Q0367 · Fill the gap**

Luulin, että menisit Tomin ____.

I thought you'd gone with Tom.

[[Finnish#^fi-Q0367-answer|Compare the answer]]
^fi-Q0367

**fi-Q0368 · Choose the form**

Luulin, että menisit Tomin ____.

I thought you'd gone with Tom.

Choices: talossa / koulussa / kaupungissa / kanssa

[[Finnish#^fi-Q0368-answer|Compare the answer]]
^fi-Q0368

**fi-Q0369 · Edit the changed sentence**

Vesi kiehuu 【talossa】 asteessa.

Water boils at 100 degrees.

[[Finnish#^fi-Q0369-answer|Compare the answer]]
^fi-Q0369

**fi-Q0370 · Build the sentence**

Arrange: asteessa. / kiehuu / sadassa / Vesi

Water boils at 100 degrees.

[[Finnish#^fi-Q0370-answer|Compare the answer]]
^fi-Q0370

**fi-Q0371 · Write a translation**

Write this in Finnish: She spent most of the day at the hospital.

[[Finnish#^fi-Q0371-answer|Compare the answer]]
^fi-Q0371

**fi-Q0372 · Explain the grammar**

Hän vietti suurimman osan päivästä 【sairaalassa】.

She spent most of the day at the hospital.

[[Finnish#^fi-Q0372-answer|Compare the answer]]
^fi-Q0372

**fi-Q0373 · Fill the gap**

Minulla on Ranskan kansalaisuus, mutta juuret ____.

I have French nationality but Vietnamese origins.

[[Finnish#^fi-Q0373-answer|Compare the answer]]
^fi-Q0373

**fi-Q0374 · Choose the form**

Minulla on Ranskan kansalaisuus, mutta juuret ____.

I have French nationality but Vietnamese origins.

Choices: Vietnamissa / talossa / kaupungissa / koulussa

[[Finnish#^fi-Q0374-answer|Compare the answer]]
^fi-Q0374

**fi-Q0375 · Edit the changed sentence**

Minä olen 【talossa】.

I'm coming.

[[Finnish#^fi-Q0375-answer|Compare the answer]]
^fi-Q0375

**fi-Q0376 · Build the sentence**

Arrange: tulossa. / Minä / olen

I'm coming.

[[Finnish#^fi-Q0376-answer|Compare the answer]]
^fi-Q0376

**fi-Q0377 · Write a translation**

Write this in Finnish: Then what's the problem?

[[Finnish#^fi-Q0377-answer|Compare the answer]]
^fi-Q0377

**fi-Q0378 · Explain the grammar**

No mikä 【tässä】 on sitten ongelma?

Then what's the problem?

[[Finnish#^fi-Q0378-answer|Compare the answer]]
^fi-Q0378

**fi-Q0379 · Fill the gap**

Onko se totta, että ette olleet ____ eilen?

Is it true that you weren't here yesterday?

[[Finnish#^fi-Q0379-answer|Compare the answer]]
^fi-Q0379

**fi-Q0380 · Choose the form**

Onko se totta, että ette olleet ____ eilen?

Is it true that you weren't here yesterday?

Choices: tässä / talossa / koulussa / kaupungissa

[[Finnish#^fi-Q0380-answer|Compare the answer]]
^fi-Q0380

**fi-Q0381 · Edit the changed sentence**

Haluaisin opiskella kemiaa 【talossa】.

I'd like to study chemistry at college.

[[Finnish#^fi-Q0381-answer|Compare the answer]]
^fi-Q0381

**fi-Q0382 · Build the sentence**

Arrange: kemiaa / Haluaisin / yliopistossa. / opiskella

I'd like to study chemistry at college.

[[Finnish#^fi-Q0382-answer|Compare the answer]]
^fi-Q0382

**fi-Q0383 · Write a translation**

Write this in Finnish: Sami didn't look panicked.

[[Finnish#^fi-Q0383-answer|Compare the answer]]
^fi-Q0383

**fi-Q0384 · Explain the grammar**

Sami ei näyttänyt olevan 【paniikissa】.

Sami didn't look panicked.

[[Finnish#^fi-Q0384-answer|Compare the answer]]
^fi-Q0384

**fi-Q0385 · Fill the gap**

Hän siinä on ____.

That's him at the window.

[[Finnish#^fi-Q0385-answer|Compare the answer]]
^fi-Q0385

**fi-Q0386 · Choose the form**

Hän siinä on ____.

That's him at the window.

Choices: kaupungissa / ikkunassa / talossa / koulussa

[[Finnish#^fi-Q0386-answer|Compare the answer]]
^fi-Q0386

**fi-Q0387 · Edit the changed sentence**

Tomi on sinkku eikä ole koskaan ollut 【talossa】.

Tom is single and has never been married.

[[Finnish#^fi-Q0387-answer|Compare the answer]]
^fi-Q0387

**fi-Q0388 · Build the sentence**

Arrange: koskaan / ole / sinkku / Tomi / eikä / naimisissa. / ollut / on

Tom is single and has never been married.

[[Finnish#^fi-Q0388-answer|Compare the answer]]
^fi-Q0388

**fi-Q0389 · Write a translation**

Write this in Finnish: Is there any hope whatsoever?

[[Finnish#^fi-Q0389-answer|Compare the answer]]
^fi-Q0389

**fi-Q0390 · Explain the grammar**

Onko 【olemassa】 mitään toivoa?

Is there any hope whatsoever?

[[Finnish#^fi-Q0390-answer|Compare the answer]]
^fi-Q0390

**fi-Q0391 · Fill the gap**

Tom tuli paikalle kolme minuuttia ____.

Tom arrived three minutes early.

[[Finnish#^fi-Q0391-answer|Compare the answer]]
^fi-Q0391

**fi-Q0392 · Choose the form**

Tom tuli paikalle kolme minuuttia ____.

Tom arrived three minutes early.

Choices: talossa / koulussa / etuajassa / kaupungissa

[[Finnish#^fi-Q0392-answer|Compare the answer]]
^fi-Q0392

**fi-Q0393 · Edit the changed sentence**

Eikö mitään ole 【talossa】?

Can't anything be done?

[[Finnish#^fi-Q0393-answer|Compare the answer]]
^fi-Q0393

**fi-Q0394 · Build the sentence**

Arrange: mitään / ole / tehtävissä? / Eikö

Can't anything be done?

[[Finnish#^fi-Q0394-answer|Compare the answer]]
^fi-Q0394

**fi-Q0395 · Write a translation**

Write this in Finnish: Just leave everything where it is.

[[Finnish#^fi-Q0395-answer|Compare the answer]]
^fi-Q0395

**fi-Q0396 · Explain the grammar**

Jätä vaan kaikki siihen 【missä】 ne ovat.

Just leave everything where it is.

[[Finnish#^fi-Q0396-answer|Compare the answer]]
^fi-Q0396

**fi-Q0397 · Fill the gap**

Ystäväni on ____ minua aulassa.

I have a friend waiting for me in the lobby.

[[Finnish#^fi-Q0397-answer|Compare the answer]]
^fi-Q0397

**fi-Q0398 · Choose the form**

Ystäväni on ____ minua aulassa.

I have a friend waiting for me in the lobby.

Choices: kaupungissa / talossa / koulussa / odottamassa

[[Finnish#^fi-Q0398-answer|Compare the answer]]
^fi-Q0398

**fi-Q0399 · Edit the changed sentence**

Tämä mies on 【talossa】.

This man is alive.

[[Finnish#^fi-Q0399-answer|Compare the answer]]
^fi-Q0399

**fi-Q0400 · Build the sentence**

Arrange: on / Tämä / elossa. / mies

This man is alive.

[[Finnish#^fi-Q0400-answer|Compare the answer]]
^fi-Q0400


### Elative source · 50 questions

**fi-Q0401 · Write a translation**

Write this in Finnish: Please don't tell anybody about this.

[[Finnish#^fi-Q0401-answer|Compare the answer]]
^fi-Q0401

**fi-Q0402 · Explain the grammar**

Ethän kerro 【tästä】 kenellekään.

Please don't tell anybody about this.

[[Finnish#^fi-Q0402-answer|Compare the answer]]
^fi-Q0402

**fi-Q0403 · Fill the gap**

Tomi kadehti Marin ____.

Tom envied Mary's success.

[[Finnish#^fi-Q0403-answer|Compare the answer]]
^fi-Q0403

**fi-Q0404 · Choose the form**

Tomi kadehti Marin ____.

Tom envied Mary's success.

Choices: kaupungista / talosta / koulusta / menestystä

[[Finnish#^fi-Q0404-answer|Compare the answer]]
^fi-Q0404

**fi-Q0405 · Edit the changed sentence**

Mä tykkään sun 【talosta】.

I like your friends.

[[Finnish#^fi-Q0405-answer|Compare the answer]]
^fi-Q0405

**fi-Q0406 · Build the sentence**

Arrange: kavereista. / Mä / sun / tykkään

I like your friends.

[[Finnish#^fi-Q0406-answer|Compare the answer]]
^fi-Q0406

**fi-Q0407 · Write a translation**

Write this in Finnish: Do you not play tennis?

[[Finnish#^fi-Q0407-answer|Compare the answer]]
^fi-Q0407

**fi-Q0408 · Explain the grammar**

Etkö pelaa 【tennistä】?

Do you not play tennis?

[[Finnish#^fi-Q0408-answer|Compare the answer]]
^fi-Q0408

**fi-Q0409 · Fill the gap**

Minun pitää ____.

I must run.

[[Finnish#^fi-Q0409-answer|Compare the answer]]
^fi-Q0409

**fi-Q0410 · Choose the form**

Minun pitää ____.

I must run.

Choices: talosta / koulusta / juosta / kaupungista

[[Finnish#^fi-Q0410-answer|Compare the answer]]
^fi-Q0410

**fi-Q0411 · Edit the changed sentence**

Sinun täytyy murtautua ulos 【talosta】.

You must break the vicious circle.

[[Finnish#^fi-Q0411-answer|Compare the answer]]
^fi-Q0411

**fi-Q0412 · Build the sentence**

Arrange: Sinun / täytyy / noidankehästä. / ulos / murtautua

You must break the vicious circle.

[[Finnish#^fi-Q0412-answer|Compare the answer]]
^fi-Q0412

**fi-Q0413 · Write a translation**

Write this in Finnish: There is an urgent need for more doctors.

[[Finnish#^fi-Q0413-answer|Compare the answer]]
^fi-Q0413

**fi-Q0414 · Explain the grammar**

【Lisälääkäreistä】 on kipeä tarve.

There is an urgent need for more doctors.

[[Finnish#^fi-Q0414-answer|Compare the answer]]
^fi-Q0414

**fi-Q0415 · Fill the gap**

Tosi filosofia on asioiden ____ sellaisenaan kuin ne ovat.

True philosophy is seeing things as they are.

[[Finnish#^fi-Q0415-answer|Compare the answer]]
^fi-Q0415

**fi-Q0416 · Choose the form**

Tosi filosofia on asioiden ____ sellaisenaan kuin ne ovat.

True philosophy is seeing things as they are.

Choices: kaupungista / näkemistä / koulusta / talosta

[[Finnish#^fi-Q0416-answer|Compare the answer]]
^fi-Q0416

**fi-Q0417 · Edit the changed sentence**

En tykkää 【talosta】 ruoasta.

I don't like spicy food.

[[Finnish#^fi-Q0417-answer|Compare the answer]]
^fi-Q0417

**fi-Q0418 · Build the sentence**

Arrange: tykkää / mausteisesta / ruoasta. / En

I don't like spicy food.

[[Finnish#^fi-Q0418-answer|Compare the answer]]
^fi-Q0418

**fi-Q0419 · Write a translation**

Write this in Finnish: Angela didn't sleep a wink that night.

[[Finnish#^fi-Q0419-answer|Compare the answer]]
^fi-Q0419

**fi-Q0420 · Explain the grammar**

Angela ei saanut unen 【päästä】 kiinni sinä yönä.

Angela didn't sleep a wink that night.

[[Finnish#^fi-Q0420-answer|Compare the answer]]
^fi-Q0420

**fi-Q0421 · Fill the gap**

Aika ajoin olemme ponnistelleet pitääksemme lupauksemme ____ ja tasa-arvosta koko kansallemme.

At times, we've struggled to keep the promise of liberty and equality for all of our people.

[[Finnish#^fi-Q0421-answer|Compare the answer]]
^fi-Q0421

**fi-Q0422 · Choose the form**

Aika ajoin olemme ponnistelleet pitääksemme lupauksemme ____ ja tasa-arvosta koko kansallemme.

At times, we've struggled to keep the promise of liberty and equality for all of our people.

Choices: koulusta / talosta / vapaudesta / kaupungista

[[Finnish#^fi-Q0422-answer|Compare the answer]]
^fi-Q0422

**fi-Q0423 · Edit the changed sentence**

【talosta】 kätesi ennen kuin vastaat.

Raise your hand before you answer.

[[Finnish#^fi-Q0423-answer|Compare the answer]]
^fi-Q0423

**fi-Q0424 · Build the sentence**

Arrange: kuin / vastaat. / kätesi / Nosta / ennen

Raise your hand before you answer.

[[Finnish#^fi-Q0424-answer|Compare the answer]]
^fi-Q0424

**fi-Q0425 · Write a translation**

Write this in Finnish: Who are those three men?

[[Finnish#^fi-Q0425-answer|Compare the answer]]
^fi-Q0425

**fi-Q0426 · Explain the grammar**

Keitä ovat nuo kolme 【miestä】?

Who are those three men?

[[Finnish#^fi-Q0426-answer|Compare the answer]]
^fi-Q0426

**fi-Q0427 · Fill the gap**

Jakaminen on ____.

Sharing is caring.

[[Finnish#^fi-Q0427-answer|Compare the answer]]
^fi-Q0427

**fi-Q0428 · Choose the form**

Jakaminen on ____.

Sharing is caring.

Choices: koulusta / välittämistä / kaupungista / talosta

[[Finnish#^fi-Q0428-answer|Compare the answer]]
^fi-Q0428

**fi-Q0429 · Edit the changed sentence**

Tomin 【talosta】 ei ollut hyvä ajatus jättää Maria kotiin ilman lapsenvahtia.

Tom thought it wasn't a good idea to leave Mary at home without a babysitter.

[[Finnish#^fi-Q0429-answer|Compare the answer]]
^fi-Q0429

**fi-Q0430 · Build the sentence**

Arrange: kotiin / ajatus / Tomin / jättää / ilman / lapsenvahtia. / ollut / mielestä / Maria / hyvä / ei

Tom thought it wasn't a good idea to leave Mary at home without a babysitter.

[[Finnish#^fi-Q0430-answer|Compare the answer]]
^fi-Q0430

**fi-Q0431 · Write a translation**

Write this in Finnish: I'm big on semantics; I always want to try to understand as much nuance as possible!

[[Finnish#^fi-Q0431-answer|Compare the answer]]
^fi-Q0431

**fi-Q0432 · Explain the grammar**

Tykkään paljon 【semantiikasta】; haluan aina ymmärtää niin paljon nyansseja kuin mahdollita!

I'm big on semantics; I always want to try to understand as much nuance as possible!

[[Finnish#^fi-Q0432-answer|Compare the answer]]
^fi-Q0432

**fi-Q0433 · Fill the gap**

Hajuaisti on yksi ____ aistista.

Smell is one of the five senses.

[[Finnish#^fi-Q0433-answer|Compare the answer]]
^fi-Q0433

**fi-Q0434 · Choose the form**

Hajuaisti on yksi ____ aistista.

Smell is one of the five senses.

Choices: kaupungista / viidestä / koulusta / talosta

[[Finnish#^fi-Q0434-answer|Compare the answer]]
^fi-Q0434

**fi-Q0435 · Edit the changed sentence**

Puhutko sinä 【talosta】?

Do you talk about us?

[[Finnish#^fi-Q0435-answer|Compare the answer]]
^fi-Q0435

**fi-Q0436 · Build the sentence**

Arrange: Puhutko / meistä? / sinä

Do you talk about us?

[[Finnish#^fi-Q0436-answer|Compare the answer]]
^fi-Q0436

**fi-Q0437 · Write a translation**

Write this in Finnish: Now, we show how this lemma can be used to prove our main theorem.

[[Finnish#^fi-Q0437-answer|Compare the answer]]
^fi-Q0437

**fi-Q0438 · Explain the grammar**

Nyt me näytämme miten tätä 【aputulosta】 voi käyttää päälauseen todistamiseen.

Now, we show how this lemma can be used to prove our main theorem.

[[Finnish#^fi-Q0438-answer|Compare the answer]]
^fi-Q0438

**fi-Q0439 · Fill the gap**

Otin kakun ____.

I took the cake out of the oven.

[[Finnish#^fi-Q0439-answer|Compare the answer]]
^fi-Q0439

**fi-Q0440 · Choose the form**

Otin kakun ____.

I took the cake out of the oven.

Choices: talosta / uunista / kaupungista / koulusta

[[Finnish#^fi-Q0440-answer|Compare the answer]]
^fi-Q0440

**fi-Q0441 · Edit the changed sentence**

Pidän 【talosta】 vielä enemmän.

I like this one even better.

[[Finnish#^fi-Q0441-answer|Compare the answer]]
^fi-Q0441

**fi-Q0442 · Build the sentence**

Arrange: tästä / vielä / enemmän. / Pidän

I like this one even better.

[[Finnish#^fi-Q0442-answer|Compare the answer]]
^fi-Q0442

**fi-Q0443 · Write a translation**

Write this in Finnish: You come from Sweden.

[[Finnish#^fi-Q0443-answer|Compare the answer]]
^fi-Q0443

**fi-Q0444 · Explain the grammar**

Sinä olet kotoisin 【Ruotsista】.

You come from Sweden.

[[Finnish#^fi-Q0444-answer|Compare the answer]]
^fi-Q0444

**fi-Q0445 · Fill the gap**

Tom tykkää ____, mutta Mari tykkää Jonista. Jotta asiat kävisivät vielä mielenkiintoisemmiksi, Joni tykkää Liisasta, mutta Liisa taas Tomista.

Tom likes Mary, but Mary likes John. To make matters even more interesting, John likes Alice, but Alice likes Tom.

[[Finnish#^fi-Q0445-answer|Compare the answer]]
^fi-Q0445

**fi-Q0446 · Choose the form**

Tom tykkää ____, mutta Mari tykkää Jonista. Jotta asiat kävisivät vielä mielenkiintoisemmiksi, Joni tykkää Liisasta, mutta Liisa taas Tomista.

Tom likes Mary, but Mary likes John. To make matters even more interesting, John likes Alice, but Alice likes Tom.

Choices: koulusta / talosta / kaupungista / Marista

[[Finnish#^fi-Q0446-answer|Compare the answer]]
^fi-Q0446

**fi-Q0447 · Edit the changed sentence**

Tämä on yksi Tomin 【talosta】.

This is one of Tom's weaknesses.

[[Finnish#^fi-Q0447-answer|Compare the answer]]
^fi-Q0447

**fi-Q0448 · Build the sentence**

Arrange: Tämä / Tomin / on / heikkouksista. / yksi

This is one of Tom's weaknesses.

[[Finnish#^fi-Q0448-answer|Compare the answer]]
^fi-Q0448

**fi-Q0449 · Write a translation**

Write this in Finnish: The plumber pumped the water out of the pipe.

[[Finnish#^fi-Q0449-answer|Compare the answer]]
^fi-Q0449

**fi-Q0450 · Explain the grammar**

Putkimies pumppasi veden 【putkesta】.

The plumber pumped the water out of the pipe.

[[Finnish#^fi-Q0450-answer|Compare the answer]]
^fi-Q0450


### Allative destination · 50 questions

**fi-Q0451 · Fill the gap**

Tom valehteli ____.

Tom lied to you.

[[Finnish#^fi-Q0451-answer|Compare the answer]]
^fi-Q0451

**fi-Q0452 · Choose the form**

Tom valehteli ____.

Tom lied to you.

Choices: meille / hänelle / sinulle / minulle

[[Finnish#^fi-Q0452-answer|Compare the answer]]
^fi-Q0452

**fi-Q0453 · Edit the changed sentence**

Kerro 【sinulle】 siitä!

Tell me about it!

[[Finnish#^fi-Q0453-answer|Compare the answer]]
^fi-Q0453

**fi-Q0454 · Build the sentence**

Arrange: Kerro / siitä! / minulle

Tell me about it!

[[Finnish#^fi-Q0454-answer|Compare the answer]]
^fi-Q0454

**fi-Q0455 · Write a translation**

Write this in Finnish: All this is strange to me.

[[Finnish#^fi-Q0455-answer|Compare the answer]]
^fi-Q0455

**fi-Q0456 · Explain the grammar**

Tämä kaikki on 【minulle】 outoa.

All this is strange to me.

[[Finnish#^fi-Q0456-answer|Compare the answer]]
^fi-Q0456

**fi-Q0457 · Fill the gap**

Kerro ____ mikä sinun ongelmasi on.

Tell me what your problem is.

[[Finnish#^fi-Q0457-answer|Compare the answer]]
^fi-Q0457

**fi-Q0458 · Choose the form**

Kerro ____ mikä sinun ongelmasi on.

Tell me what your problem is.

Choices: meille / minulle / hänelle / sinulle

[[Finnish#^fi-Q0458-answer|Compare the answer]]
^fi-Q0458

**fi-Q0459 · Edit the changed sentence**

Miten vastasitte 【minulle】?

How did you answer her?

[[Finnish#^fi-Q0459-answer|Compare the answer]]
^fi-Q0459

**fi-Q0460 · Build the sentence**

Arrange: vastasitte / hänelle? / Miten

How did you answer her?

[[Finnish#^fi-Q0460-answer|Compare the answer]]
^fi-Q0460

**fi-Q0461 · Write a translation**

Write this in Finnish: Call me anytime.

[[Finnish#^fi-Q0461-answer|Compare the answer]]
^fi-Q0461

**fi-Q0462 · Explain the grammar**

Voit soittaa 【minulle】 milloin vain.

Call me anytime.

[[Finnish#^fi-Q0462-answer|Compare the answer]]
^fi-Q0462

**fi-Q0463 · Fill the gap**

Jos tietäisin sen, niin kertoisin ____.

If I knew it, I would tell you.

[[Finnish#^fi-Q0463-answer|Compare the answer]]
^fi-Q0463

**fi-Q0464 · Choose the form**

Jos tietäisin sen, niin kertoisin ____.

If I knew it, I would tell you.

Choices: hänelle / minulle / meille / sinulle

[[Finnish#^fi-Q0464-answer|Compare the answer]]
^fi-Q0464

**fi-Q0465 · Edit the changed sentence**

Minun poikani valehteli 【sinulle】.

My son lied to me.

[[Finnish#^fi-Q0465-answer|Compare the answer]]
^fi-Q0465

**fi-Q0466 · Build the sentence**

Arrange: Minun / valehteli / poikani / minulle.

My son lied to me.

[[Finnish#^fi-Q0466-answer|Compare the answer]]
^fi-Q0466

**fi-Q0467 · Write a translation**

Write this in Finnish: Tom gave me a pen.

[[Finnish#^fi-Q0467-answer|Compare the answer]]
^fi-Q0467

**fi-Q0468 · Explain the grammar**

Tom antoi 【minulle】 kynän.

Tom gave me a pen.

[[Finnish#^fi-Q0468-answer|Compare the answer]]
^fi-Q0468

**fi-Q0469 · Fill the gap**

Voisitko lainata sanakirjaasi ____?

Will you lend your dictionary to me?

[[Finnish#^fi-Q0469-answer|Compare the answer]]
^fi-Q0469

**fi-Q0470 · Choose the form**

Voisitko lainata sanakirjaasi ____?

Will you lend your dictionary to me?

Choices: meille / minulle / sinulle / hänelle

[[Finnish#^fi-Q0470-answer|Compare the answer]]
^fi-Q0470

**fi-Q0471 · Edit the changed sentence**

Tom lupasi 【sinulle】, että hän olisi täällä puoli kolmeen mennessä.

Tom promised me he'd be here by 2:30.

[[Finnish#^fi-Q0471-answer|Compare the answer]]
^fi-Q0471

**fi-Q0472 · Build the sentence**

Arrange: minulle, / Tom / hän / täällä / puoli / olisi / että / mennessä. / kolmeen / lupasi

Tom promised me he'd be here by 2:30.

[[Finnish#^fi-Q0472-answer|Compare the answer]]
^fi-Q0472

**fi-Q0473 · Write a translation**

Write this in Finnish: Give me your weapons.

[[Finnish#^fi-Q0473-answer|Compare the answer]]
^fi-Q0473

**fi-Q0474 · Explain the grammar**

Anna 【minulle】 sinun aseesi.

Give me your weapons.

[[Finnish#^fi-Q0474-answer|Compare the answer]]
^fi-Q0474

**fi-Q0475 · Fill the gap**

Katso minua kun puhun ____.

Look at me when I talk to you!

[[Finnish#^fi-Q0475-answer|Compare the answer]]
^fi-Q0475

**fi-Q0476 · Choose the form**

Katso minua kun puhun ____.

Look at me when I talk to you!

Choices: minulle / hänelle / sinulle / meille

[[Finnish#^fi-Q0476-answer|Compare the answer]]
^fi-Q0476

**fi-Q0477 · Edit the changed sentence**

Toin 【minulle】 jotakin pientä.

I brought you a little something.

[[Finnish#^fi-Q0477-answer|Compare the answer]]
^fi-Q0477

**fi-Q0478 · Build the sentence**

Arrange: sinulle / jotakin / pientä. / Toin

I brought you a little something.

[[Finnish#^fi-Q0478-answer|Compare the answer]]
^fi-Q0478

**fi-Q0479 · Write a translation**

Write this in Finnish: Why is Tom being so nice to me all of a sudden?

[[Finnish#^fi-Q0479-answer|Compare the answer]]
^fi-Q0479

**fi-Q0480 · Explain the grammar**

Miksi Tomi on yhtäkkiä 【minulle】 niin ystävällinen.

Why is Tom being so nice to me all of a sudden?

[[Finnish#^fi-Q0480-answer|Compare the answer]]
^fi-Q0480

**fi-Q0481 · Fill the gap**

Onko jotain, jota et nyt kerro ____?

Is there anything you're not telling me?

[[Finnish#^fi-Q0481-answer|Compare the answer]]
^fi-Q0481

**fi-Q0482 · Choose the form**

Onko jotain, jota et nyt kerro ____?

Is there anything you're not telling me?

Choices: hänelle / sinulle / meille / minulle

[[Finnish#^fi-Q0482-answer|Compare the answer]]
^fi-Q0482

**fi-Q0483 · Edit the changed sentence**

Kirjoita 【minulle】 viesti.

Write him a note.

[[Finnish#^fi-Q0483-answer|Compare the answer]]
^fi-Q0483

**fi-Q0484 · Build the sentence**

Arrange: Kirjoita / viesti. / hänelle

Write him a note.

[[Finnish#^fi-Q0484-answer|Compare the answer]]
^fi-Q0484

**fi-Q0485 · Write a translation**

Write this in Finnish: Please tell me your address.

[[Finnish#^fi-Q0485-answer|Compare the answer]]
^fi-Q0485

**fi-Q0486 · Explain the grammar**

Kerro 【minulle】 osoitteesi.

Please tell me your address.

[[Finnish#^fi-Q0486-answer|Compare the answer]]
^fi-Q0486

**fi-Q0487 · Fill the gap**

Kerro ____ hänestä.

Tell me about him.

[[Finnish#^fi-Q0487-answer|Compare the answer]]
^fi-Q0487

**fi-Q0488 · Choose the form**

Kerro ____ hänestä.

Tell me about him.

Choices: meille / minulle / sinulle / hänelle

[[Finnish#^fi-Q0488-answer|Compare the answer]]
^fi-Q0488

**fi-Q0489 · Edit the changed sentence**

Epäilen, ettei Tomi tee sitä 【sinulle】.

I suspect Tom won't do that for me.

[[Finnish#^fi-Q0489-answer|Compare the answer]]
^fi-Q0489

**fi-Q0490 · Build the sentence**

Arrange: minulle. / ettei / tee / Tomi / sitä / Epäilen,

I suspect Tom won't do that for me.

[[Finnish#^fi-Q0490-answer|Compare the answer]]
^fi-Q0490

**fi-Q0491 · Write a translation**

Write this in Finnish: It's none of your business.

[[Finnish#^fi-Q0491-answer|Compare the answer]]
^fi-Q0491

**fi-Q0492 · Explain the grammar**

Ei kuulu 【sinulle】.

It's none of your business.

[[Finnish#^fi-Q0492-answer|Compare the answer]]
^fi-Q0492

**fi-Q0493 · Fill the gap**

____ tulee maha kipeäksi maidosta.

Milk gives me a stomachache.

[[Finnish#^fi-Q0493-answer|Compare the answer]]
^fi-Q0493

**fi-Q0494 · Choose the form**

____ tulee maha kipeäksi maidosta.

Milk gives me a stomachache.

Choices: meille / sinulle / hänelle / Minulle

[[Finnish#^fi-Q0494-answer|Compare the answer]]
^fi-Q0494

**fi-Q0495 · Edit the changed sentence**

Kitara on 【sinulle】 liian kallis ostaa.

That guitar is too expensive for me to buy.

[[Finnish#^fi-Q0495-answer|Compare the answer]]
^fi-Q0495

**fi-Q0496 · Build the sentence**

Arrange: kallis / on / Kitara / ostaa. / liian / minulle

That guitar is too expensive for me to buy.

[[Finnish#^fi-Q0496-answer|Compare the answer]]
^fi-Q0496

**fi-Q0497 · Write a translation**

Write this in Finnish: Tell me how to find Tom.

[[Finnish#^fi-Q0497-answer|Compare the answer]]
^fi-Q0497

**fi-Q0498 · Explain the grammar**

Kerro 【minulle】 se, että miten voin löytää Tomin.

Tell me how to find Tom.

[[Finnish#^fi-Q0498-answer|Compare the answer]]
^fi-Q0498

**fi-Q0499 · Fill the gap**

Kiiruhdimme ____ vain myöhästyäksemme junasta.

We hurried to the station only to miss the train.

[[Finnish#^fi-Q0499-answer|Compare the answer]]
^fi-Q0499

**fi-Q0500 · Choose the form**

Kiiruhdimme ____ vain myöhästyäksemme junasta.

We hurried to the station only to miss the train.

Choices: asemalle / minulle / hänelle / sinulle

[[Finnish#^fi-Q0500-answer|Compare the answer]]
^fi-Q0500


### Adessive and possession · 50 questions

**fi-Q0501 · Edit the changed sentence**

【sinulla】 on ollut todella kova päivä.

I've had a really hard day.

[[Finnish#^fi-Q0501-answer|Compare the answer]]
^fi-Q0501

**fi-Q0502 · Build the sentence**

Arrange: todella / on / päivä. / kova / ollut / Minulla

I've had a really hard day.

[[Finnish#^fi-Q0502-answer|Compare the answer]]
^fi-Q0502

**fi-Q0503 · Write a translation**

Write this in Finnish: You don't have anything to say about it, do you?

[[Finnish#^fi-Q0503-answer|Compare the answer]]
^fi-Q0503

**fi-Q0504 · Explain the grammar**

【Sinulla】 ei ole mitään sanottavaa siitä, vai?

You don't have anything to say about it, do you?

[[Finnish#^fi-Q0504-answer|Compare the answer]]
^fi-Q0504

**fi-Q0505 · Fill the gap**

____ on uusi työ.

I have a new job.

[[Finnish#^fi-Q0505-answer|Compare the answer]]
^fi-Q0505

**fi-Q0506 · Choose the form**

____ on uusi työ.

I have a new job.

Choices: meillä / sinulla / hänellä / Minulla

[[Finnish#^fi-Q0506-answer|Compare the answer]]
^fi-Q0506

**fi-Q0507 · Edit the changed sentence**

【sinulla】 on nyt todella tylsää.

I'm really bored right now.

[[Finnish#^fi-Q0507-answer|Compare the answer]]
^fi-Q0507

**fi-Q0508 · Build the sentence**

Arrange: todella / tylsää. / on / nyt / Minulla

I'm really bored right now.

[[Finnish#^fi-Q0508-answer|Compare the answer]]
^fi-Q0508

**fi-Q0509 · Write a translation**

Write this in Finnish: You're all they have.

[[Finnish#^fi-Q0509-answer|Compare the answer]]
^fi-Q0509

**fi-Q0510 · Explain the grammar**

Olette kaikki mitä 【heillä】 on.

You're all they have.

[[Finnish#^fi-Q0510-answer|Compare the answer]]
^fi-Q0510

**fi-Q0511 · Fill the gap**

____ on tänään todella paljon tehtävää.

I have a lot to do today.

[[Finnish#^fi-Q0511-answer|Compare the answer]]
^fi-Q0511

**fi-Q0512 · Choose the form**

____ on tänään todella paljon tehtävää.

I have a lot to do today.

Choices: hänellä / meillä / sinulla / Minulla

[[Finnish#^fi-Q0512-answer|Compare the answer]]
^fi-Q0512

**fi-Q0513 · Edit the changed sentence**

Onko 【minulla】 halvempia istuimia?

Do you have any cheaper seats?

[[Finnish#^fi-Q0513-answer|Compare the answer]]
^fi-Q0513

**fi-Q0514 · Build the sentence**

Arrange: istuimia? / halvempia / teillä / Onko

Do you have any cheaper seats?

[[Finnish#^fi-Q0514-answer|Compare the answer]]
^fi-Q0514

**fi-Q0515 · Write a translation**

Write this in Finnish: You have nothing to lose.

[[Finnish#^fi-Q0515-answer|Compare the answer]]
^fi-Q0515

**fi-Q0516 · Explain the grammar**

【Sinulla】 ei ole mitään menetettävää.

You have nothing to lose.

[[Finnish#^fi-Q0516-answer|Compare the answer]]
^fi-Q0516

**fi-Q0517 · Fill the gap**

____ ei ole harmaintakaan haisuakaan.

He hasn't got the foggiest.

[[Finnish#^fi-Q0517-answer|Compare the answer]]
^fi-Q0517

**fi-Q0518 · Choose the form**

____ ei ole harmaintakaan haisuakaan.

He hasn't got the foggiest.

Choices: sinulla / minulla / meillä / Hänellä

[[Finnish#^fi-Q0518-answer|Compare the answer]]
^fi-Q0518

**fi-Q0519 · Edit the changed sentence**

Ei 【minulla】 ole mitään, mitä pitäisi piilottaa.

We have nothing to hide.

[[Finnish#^fi-Q0519-answer|Compare the answer]]
^fi-Q0519

**fi-Q0520 · Build the sentence**

Arrange: meillä / pitäisi / piilottaa. / Ei / mitään, / ole / mitä

We have nothing to hide.

[[Finnish#^fi-Q0520-answer|Compare the answer]]
^fi-Q0520

**fi-Q0521 · Write a translation**

Write this in Finnish: They're both wearing uniforms.

[[Finnish#^fi-Q0521-answer|Compare the answer]]
^fi-Q0521

**fi-Q0522 · Explain the grammar**

【Heillä】 on molemmilla univormut.

They're both wearing uniforms.

[[Finnish#^fi-Q0522-answer|Compare the answer]]
^fi-Q0522

**fi-Q0523 · Fill the gap**

____ alkaa olla parempi olo.

I'm starting to feel better.

[[Finnish#^fi-Q0523-answer|Compare the answer]]
^fi-Q0523

**fi-Q0524 · Choose the form**

____ alkaa olla parempi olo.

I'm starting to feel better.

Choices: sinulla / hänellä / Minulla / meillä

[[Finnish#^fi-Q0524-answer|Compare the answer]]
^fi-Q0524

**fi-Q0525 · Edit the changed sentence**

【sinulla】 on nälkä, koska en syönyt aamupalaa.

I am hungry because I did not have breakfast.

[[Finnish#^fi-Q0525-answer|Compare the answer]]
^fi-Q0525

**fi-Q0526 · Build the sentence**

Arrange: en / syönyt / nälkä, / on / Minulla / aamupalaa. / koska

I am hungry because I did not have breakfast.

[[Finnish#^fi-Q0526-answer|Compare the answer]]
^fi-Q0526

**fi-Q0527 · Write a translation**

Write this in Finnish: You do have a point there.

[[Finnish#^fi-Q0527-answer|Compare the answer]]
^fi-Q0527

**fi-Q0528 · Explain the grammar**

Onhan 【sinulla】 pointti siinä.

You do have a point there.

[[Finnish#^fi-Q0528-answer|Compare the answer]]
^fi-Q0528

**fi-Q0529 · Fill the gap**

____ on ikävä kissaani.

I miss my cat.

[[Finnish#^fi-Q0529-answer|Compare the answer]]
^fi-Q0529

**fi-Q0530 · Choose the form**

____ on ikävä kissaani.

I miss my cat.

Choices: sinulla / Minulla / meillä / hänellä

[[Finnish#^fi-Q0530-answer|Compare the answer]]
^fi-Q0530

**fi-Q0531 · Edit the changed sentence**

Voi kunpa 【sinulla】 olisi auto.

I wish I had a car.

[[Finnish#^fi-Q0531-answer|Compare the answer]]
^fi-Q0531

**fi-Q0532 · Build the sentence**

Arrange: olisi / auto. / kunpa / minulla / Voi

I wish I had a car.

[[Finnish#^fi-Q0532-answer|Compare the answer]]
^fi-Q0532

**fi-Q0533 · Write a translation**

Write this in Finnish: She has a a tidy apartment.

[[Finnish#^fi-Q0533-answer|Compare the answer]]
^fi-Q0533

**fi-Q0534 · Explain the grammar**

【Hänellä】 on siisti huoneisto.

She has a a tidy apartment.

[[Finnish#^fi-Q0534-answer|Compare the answer]]
^fi-Q0534

**fi-Q0535 · Fill the gap**

____ ei ole varaa siihen.

We can't afford that.

[[Finnish#^fi-Q0535-answer|Compare the answer]]
^fi-Q0535

**fi-Q0536 · Choose the form**

____ ei ole varaa siihen.

We can't afford that.

Choices: sinulla / hänellä / Meillä / minulla

[[Finnish#^fi-Q0536-answer|Compare the answer]]
^fi-Q0536

**fi-Q0537 · Edit the changed sentence**

【sinulla】 on ikävä Tomia. Toivon, että hän tulee pian takaisin.

I miss Tom. I hope he comes back soon.

[[Finnish#^fi-Q0537-answer|Compare the answer]]
^fi-Q0537

**fi-Q0538 · Build the sentence**

Arrange: hän / tulee / on / ikävä / takaisin. / Toivon, / pian / Minulla / Tomia. / että

I miss Tom. I hope he comes back soon.

[[Finnish#^fi-Q0538-answer|Compare the answer]]
^fi-Q0538

**fi-Q0539 · Write a translation**

Write this in Finnish: I wasn't in a hurry.

[[Finnish#^fi-Q0539-answer|Compare the answer]]
^fi-Q0539

**fi-Q0540 · Explain the grammar**

【Minulla】 ei ollut kiire.

I wasn't in a hurry.

[[Finnish#^fi-Q0540-answer|Compare the answer]]
^fi-Q0540

**fi-Q0541 · Fill the gap**

____ ei ole varaa ostaa uutta autoa.

He can't afford to buy a new car.

[[Finnish#^fi-Q0541-answer|Compare the answer]]
^fi-Q0541

**fi-Q0542 · Choose the form**

____ ei ole varaa ostaa uutta autoa.

He can't afford to buy a new car.

Choices: sinulla / Hänellä / meillä / minulla

[[Finnish#^fi-Q0542-answer|Compare the answer]]
^fi-Q0542

**fi-Q0543 · Edit the changed sentence**

【minulla】 on suuri työ edessämme.

We have a big job ahead of us.

[[Finnish#^fi-Q0543-answer|Compare the answer]]
^fi-Q0543

**fi-Q0544 · Build the sentence**

Arrange: suuri / Meillä / on / työ / edessämme.

We have a big job ahead of us.

[[Finnish#^fi-Q0544-answer|Compare the answer]]
^fi-Q0544

**fi-Q0545 · Write a translation**

Write this in Finnish: I have a normal eyesight.

[[Finnish#^fi-Q0545-answer|Compare the answer]]
^fi-Q0545

**fi-Q0546 · Explain the grammar**

【Minulla】 on normaali näkö.

I have a normal eyesight.

[[Finnish#^fi-Q0546-answer|Compare the answer]]
^fi-Q0546

**fi-Q0547 · Fill the gap**

____ menee hyvin, kiitos!

I am fine, thank you.

[[Finnish#^fi-Q0547-answer|Compare the answer]]
^fi-Q0547

**fi-Q0548 · Choose the form**

____ menee hyvin, kiitos!

I am fine, thank you.

Choices: meillä / Minulla / hänellä / sinulla

[[Finnish#^fi-Q0548-answer|Compare the answer]]
^fi-Q0548

**fi-Q0549 · Edit the changed sentence**

【sinulla】 on vaikeuksia ymmärtää häntä.

I have difficulty in understanding him.

[[Finnish#^fi-Q0549-answer|Compare the answer]]
^fi-Q0549

**fi-Q0550 · Build the sentence**

Arrange: Minulla / häntä. / vaikeuksia / ymmärtää / on

I have difficulty in understanding him.

[[Finnish#^fi-Q0550-answer|Compare the answer]]
^fi-Q0550


### Ablative source · 50 questions

**fi-Q0551 · Write a translation**

Write this in Finnish: The islanders are asking us for help.

[[Finnish#^fi-Q0551-answer|Compare the answer]]
^fi-Q0551

**fi-Q0552 · Explain the grammar**

Ne saarelaiset pyytävät 【meiltä】 apua.

The islanders are asking us for help.

[[Finnish#^fi-Q0552-answer|Compare the answer]]
^fi-Q0552

**fi-Q0553 · Fill the gap**

Tom aikoi kysyä ____ siitä.

Tom was going to ask you about that.

[[Finnish#^fi-Q0553-answer|Compare the answer]]
^fi-Q0553

**fi-Q0554 · Choose the form**

Tom aikoi kysyä ____ siitä.

Tom was going to ask you about that.

Choices: minulta / meiltä / sinulta / häneltä

[[Finnish#^fi-Q0554-answer|Compare the answer]]
^fi-Q0554

**fi-Q0555 · Edit the changed sentence**

Kaikki kysyvät 【sinulta】 millaista on olla värisokea.

Everyone asks me what it's like to be colour-blind.

[[Finnish#^fi-Q0555-answer|Compare the answer]]
^fi-Q0555

**fi-Q0556 · Build the sentence**

Arrange: Kaikki / on / olla / minulta / millaista / värisokea. / kysyvät

Everyone asks me what it's like to be colour-blind.

[[Finnish#^fi-Q0556-answer|Compare the answer]]
^fi-Q0556

**fi-Q0557 · Write a translation**

Write this in Finnish: His doctor told him not to drink alcohol.

[[Finnish#^fi-Q0557-answer|Compare the answer]]
^fi-Q0557

**fi-Q0558 · Explain the grammar**

Hänen lääkärinsä kielsi 【häneltä】 alkoholin juomisen.

His doctor told him not to drink alcohol.

[[Finnish#^fi-Q0558-answer|Compare the answer]]
^fi-Q0558

**fi-Q0559 · Fill the gap**

____ kesti kolme kuukautta oppia ajamaan polkupyörällä.

It took him three months to learn to ride a bicycle.

[[Finnish#^fi-Q0559-answer|Compare the answer]]
^fi-Q0559

**fi-Q0560 · Choose the form**

____ kesti kolme kuukautta oppia ajamaan polkupyörällä.

It took him three months to learn to ride a bicycle.

Choices: sinulta / Häneltä / minulta / meiltä

[[Finnish#^fi-Q0560-answer|Compare the answer]]
^fi-Q0560

**fi-Q0561 · Edit the changed sentence**

Se oli ilkeää 【minulta】.

That was wicked of him.

[[Finnish#^fi-Q0561-answer|Compare the answer]]
^fi-Q0561

**fi-Q0562 · Build the sentence**

Arrange: häneltä. / Se / oli / ilkeää

That was wicked of him.

[[Finnish#^fi-Q0562-answer|Compare the answer]]
^fi-Q0562

**fi-Q0563 · Write a translation**

Write this in Finnish: Could I ask you a big favor?

[[Finnish#^fi-Q0563-answer|Compare the answer]]
^fi-Q0563

**fi-Q0564 · Explain the grammar**

Voinko pyytää 【sinulta】 isoa palvelusta?

Could I ask you a big favor?

[[Finnish#^fi-Q0564-answer|Compare the answer]]
^fi-Q0564

**fi-Q0565 · Fill the gap**

Tämä kirja menee ____ yli hilseen.

This book is above my understanding.

[[Finnish#^fi-Q0565-answer|Compare the answer]]
^fi-Q0565

**fi-Q0566 · Choose the form**

Tämä kirja menee ____ yli hilseen.

This book is above my understanding.

Choices: meiltä / sinulta / häneltä / minulta

[[Finnish#^fi-Q0566-answer|Compare the answer]]
^fi-Q0566

**fi-Q0567 · Edit the changed sentence**

Kysyn 【minulta】 siitä huomenna.

I will ask him about it tomorrow.

[[Finnish#^fi-Q0567-answer|Compare the answer]]
^fi-Q0567

**fi-Q0568 · Build the sentence**

Arrange: siitä / Kysyn / huomenna. / häneltä

I will ask him about it tomorrow.

[[Finnish#^fi-Q0568-answer|Compare the answer]]
^fi-Q0568

**fi-Q0569 · Write a translation**

Write this in Finnish: She asked me where I was going.

[[Finnish#^fi-Q0569-answer|Compare the answer]]
^fi-Q0569

**fi-Q0570 · Explain the grammar**

Hän kysyi 【minulta】, minne olen matkalla.

She asked me where I was going.

[[Finnish#^fi-Q0570-answer|Compare the answer]]
^fi-Q0570

**fi-Q0571 · Fill the gap**

Minun pitää kysyä ____ monta kysymystä.

I've got a lot of questions I need to ask you.

[[Finnish#^fi-Q0571-answer|Compare the answer]]
^fi-Q0571

**fi-Q0572 · Choose the form**

Minun pitää kysyä ____ monta kysymystä.

I've got a lot of questions I need to ask you.

Choices: sinulta / meiltä / minulta / häneltä

[[Finnish#^fi-Q0572-answer|Compare the answer]]
^fi-Q0572

**fi-Q0573 · Edit the changed sentence**

Minä haluaisin pyytää 【minulta】 palvelusta.

I have a favor to ask.

[[Finnish#^fi-Q0573-answer|Compare the answer]]
^fi-Q0573

**fi-Q0574 · Build the sentence**

Arrange: palvelusta. / haluaisin / pyytää / Minä / sinulta

I have a favor to ask.

[[Finnish#^fi-Q0574-answer|Compare the answer]]
^fi-Q0574

**fi-Q0575 · Write a translation**

Write this in Finnish: I get asked that question a lot.

[[Finnish#^fi-Q0575-answer|Compare the answer]]
^fi-Q0575

**fi-Q0576 · Explain the grammar**

【Minulta】 kysytään tuota usein.

I get asked that question a lot.

[[Finnish#^fi-Q0576-answer|Compare the answer]]
^fi-Q0576

**fi-Q0577 · Fill the gap**

Hän halusi kysyä ____ puutarhasta

He wanted to ask me about the garden.

[[Finnish#^fi-Q0577-answer|Compare the answer]]
^fi-Q0577

**fi-Q0578 · Choose the form**

Hän halusi kysyä ____ puutarhasta

He wanted to ask me about the garden.

Choices: minulta / meiltä / sinulta / häneltä

[[Finnish#^fi-Q0578-answer|Compare the answer]]
^fi-Q0578

**fi-Q0579 · Edit the changed sentence**

【sinulta】 loppui akku.

My battery died.

[[Finnish#^fi-Q0579-answer|Compare the answer]]
^fi-Q0579

**fi-Q0580 · Build the sentence**

Arrange: akku. / Minulta / loppui

My battery died.

[[Finnish#^fi-Q0580-answer|Compare the answer]]
^fi-Q0580

**fi-Q0581 · Write a translation**

Write this in Finnish: I have no reason not to do what Tom asked me to do.

[[Finnish#^fi-Q0581-answer|Compare the answer]]
^fi-Q0581

**fi-Q0582 · Explain the grammar**

Minulla ei ole mitään syytä olla tekemättä, mitä Tom 【minulta】 pyysi.

I have no reason not to do what Tom asked me to do.

[[Finnish#^fi-Q0582-answer|Compare the answer]]
^fi-Q0582

**fi-Q0583 · Fill the gap**

Oli typerää ____ tehdä niin kuin teit.

It was stupid of you to do what you did.

[[Finnish#^fi-Q0583-answer|Compare the answer]]
^fi-Q0583

**fi-Q0584 · Choose the form**

Oli typerää ____ tehdä niin kuin teit.

It was stupid of you to do what you did.

Choices: minulta / sinulta / häneltä / meiltä

[[Finnish#^fi-Q0584-answer|Compare the answer]]
^fi-Q0584

**fi-Q0585 · Edit the changed sentence**

Olisiko minun pitänyt kysyä 【minulta】 ensin?

Should I have asked you first?

[[Finnish#^fi-Q0585-answer|Compare the answer]]
^fi-Q0585

**fi-Q0586 · Build the sentence**

Arrange: sinulta / kysyä / pitänyt / minun / Olisiko / ensin?

Should I have asked you first?

[[Finnish#^fi-Q0586-answer|Compare the answer]]
^fi-Q0586

**fi-Q0587 · Write a translation**

Write this in Finnish: It is not good to borrow money from him.

[[Finnish#^fi-Q0587-answer|Compare the answer]]
^fi-Q0587

**fi-Q0588 · Explain the grammar**

Ei ole hyvä asia lainata 【häneltä】 rahaa.

It is not good to borrow money from him.

[[Finnish#^fi-Q0588-answer|Compare the answer]]
^fi-Q0588

**fi-Q0589 · Fill the gap**

____ irtosi paikka hampaasta.

I've lost a filling.

[[Finnish#^fi-Q0589-answer|Compare the answer]]
^fi-Q0589

**fi-Q0590 · Choose the form**

____ irtosi paikka hampaasta.

I've lost a filling.

Choices: häneltä / meiltä / Minulta / sinulta

[[Finnish#^fi-Q0590-answer|Compare the answer]]
^fi-Q0590

**fi-Q0591 · Edit the changed sentence**

Kerro Tomille paljon terveisiä 【sinulta】.

Please give my best regards to Tom.

[[Finnish#^fi-Q0591-answer|Compare the answer]]
^fi-Q0591

**fi-Q0592 · Build the sentence**

Arrange: paljon / minulta. / Tomille / terveisiä / Kerro

Please give my best regards to Tom.

[[Finnish#^fi-Q0592-answer|Compare the answer]]
^fi-Q0592

**fi-Q0593 · Write a translation**

Write this in Finnish: Ask him if he will attend the meeting.

[[Finnish#^fi-Q0593-answer|Compare the answer]]
^fi-Q0593

**fi-Q0594 · Explain the grammar**

Kysy 【häneltä】 haluaako hän osallistua kokoukseen.

Ask him if he will attend the meeting.

[[Finnish#^fi-Q0594-answer|Compare the answer]]
^fi-Q0594

**fi-Q0595 · Fill the gap**

Tom luuli, että ____ oli murtunut luu jalasta, mutta röntgenkuvasta näkyi, ettei se ollut murtunut.

Tom thought he'd broken a bone in his foot, but an X-ray showed that he hadn't.

[[Finnish#^fi-Q0595-answer|Compare the answer]]
^fi-Q0595

**fi-Q0596 · Choose the form**

Tom luuli, että ____ oli murtunut luu jalasta, mutta röntgenkuvasta näkyi, ettei se ollut murtunut.

Tom thought he'd broken a bone in his foot, but an X-ray showed that he hadn't.

Choices: häneltä / minulta / meiltä / sinulta

[[Finnish#^fi-Q0596-answer|Compare the answer]]
^fi-Q0596

**fi-Q0597 · Edit the changed sentence**

Hän kysyi 【sinulta】, että kuinka montaa kieltä puhun.

She asked me how many languages I spoke.

[[Finnish#^fi-Q0597-answer|Compare the answer]]
^fi-Q0597

**fi-Q0598 · Build the sentence**

Arrange: Hän / montaa / että / kysyi / kieltä / kuinka / minulta, / puhun.

She asked me how many languages I spoke.

[[Finnish#^fi-Q0598-answer|Compare the answer]]
^fi-Q0598

**fi-Q0599 · Write a translation**

Write this in Finnish: How long were you planning on keeping this a secret from me?

[[Finnish#^fi-Q0599-answer|Compare the answer]]
^fi-Q0599

**fi-Q0600 · Explain the grammar**

Kuinka kauan sinä aioit pitää tämän salassa 【minulta】?

How long were you planning on keeping this a secret from me?

[[Finnish#^fi-Q0600-answer|Compare the answer]]
^fi-Q0600


### Conditional forms · 50 questions

**fi-Q0601 · Fill the gap**

Tom ____ voittanut helposti.

Tom would've won easily.

[[Finnish#^fi-Q0601-answer|Compare the answer]]
^fi-Q0601

**fi-Q0602 · Choose the form**

Tom ____ voittanut helposti.

Tom would've won easily.

Choices: haluaisin / olisi / olisin / voisi

[[Finnish#^fi-Q0602-answer|Compare the answer]]
^fi-Q0602

**fi-Q0603 · Edit the changed sentence**

Hänen 【olisin】 pitänyt pitää suunsa kiinni.

She should have kept her mouth shut.

[[Finnish#^fi-Q0603-answer|Compare the answer]]
^fi-Q0603

**fi-Q0604 · Build the sentence**

Arrange: Hänen / kiinni. / pitänyt / pitää / suunsa / olisi

She should have kept her mouth shut.

[[Finnish#^fi-Q0604-answer|Compare the answer]]
^fi-Q0604

**fi-Q0605 · Write a translation**

Write this in Finnish: Tom wants to ask what Mary has been doing, but he knows that he shouldn't.

[[Finnish#^fi-Q0605-answer|Compare the answer]]
^fi-Q0605

**fi-Q0606 · Explain the grammar**

Tom haluaa kysyä mitä Mari on puuhastellut, mutta hän tietää ettei hänen 【pitäisi】.

Tom wants to ask what Mary has been doing, but he knows that he shouldn't.

[[Finnish#^fi-Q0606-answer|Compare the answer]]
^fi-Q0606

**fi-Q0607 · Fill the gap**

Silloin kun ajatte, ____ teidän keskittyä tiehen.

While you drive, you should focus on the road.

[[Finnish#^fi-Q0607-answer|Compare the answer]]
^fi-Q0607

**fi-Q0608 · Choose the form**

Silloin kun ajatte, ____ teidän keskittyä tiehen.

While you drive, you should focus on the road.

Choices: olisi / olisin / voisi / pitäisi

[[Finnish#^fi-Q0608-answer|Compare the answer]]
^fi-Q0608

**fi-Q0609 · Edit the changed sentence**

Tom toivoi, että 【olisin】 muistanut ostaa kukkia Marille.

Tom wished he had remembered to buy flowers for Mary.

[[Finnish#^fi-Q0609-answer|Compare the answer]]
^fi-Q0609

**fi-Q0610 · Build the sentence**

Arrange: toivoi, / Marille. / kukkia / ostaa / muistanut / olisi / Tom / että

Tom wished he had remembered to buy flowers for Mary.

[[Finnish#^fi-Q0610-answer|Compare the answer]]
^fi-Q0610

**fi-Q0611 · Write a translation**

Write this in Finnish: What would Tom do if he found out?

[[Finnish#^fi-Q0611-answer|Compare the answer]]
^fi-Q0611

**fi-Q0612 · Explain the grammar**

Mitä Tom tekisi, jos hän 【saisi】 tietää?

What would Tom do if he found out?

[[Finnish#^fi-Q0612-answer|Compare the answer]]
^fi-Q0612

**fi-Q0613 · Fill the gap**

Tom ____ pyytää Marilta anteeksi sitä, ettei hän saapunut ajoissa.

Tom should apologize to Mary for not arriving on time.

[[Finnish#^fi-Q0613-answer|Compare the answer]]
^fi-Q0613

**fi-Q0614 · Choose the form**

Tom ____ pyytää Marilta anteeksi sitä, ettei hän saapunut ajoissa.

Tom should apologize to Mary for not arriving on time.

Choices: olisi / pitäisi / olisin / voisi

[[Finnish#^fi-Q0614-answer|Compare the answer]]
^fi-Q0614

**fi-Q0615 · Edit the changed sentence**

Luulen että sinun 【olisin】 parempi hieman levätä.

I think you'd better rest for a while.

[[Finnish#^fi-Q0615-answer|Compare the answer]]
^fi-Q0615

**fi-Q0616 · Build the sentence**

Arrange: parempi / levätä. / että / hieman / sinun / olisi / Luulen

I think you'd better rest for a while.

[[Finnish#^fi-Q0616-answer|Compare the answer]]
^fi-Q0616

**fi-Q0617 · Write a translation**

Write this in Finnish: I think you should be careful.

[[Finnish#^fi-Q0617-answer|Compare the answer]]
^fi-Q0617

**fi-Q0618 · Explain the grammar**

Mielestäni sinun 【pitäisi】 olla varovainen.

I think you should be careful.

[[Finnish#^fi-Q0618-answer|Compare the answer]]
^fi-Q0618

**fi-Q0619 · Fill the gap**

Teidän ____ pysyä vuoteessa.

You should stay in bed.

[[Finnish#^fi-Q0619-answer|Compare the answer]]
^fi-Q0619

**fi-Q0620 · Choose the form**

Teidän ____ pysyä vuoteessa.

You should stay in bed.

Choices: olisin / voisi / olisi / pitäisi

[[Finnish#^fi-Q0620-answer|Compare the answer]]
^fi-Q0620

**fi-Q0621 · Edit the changed sentence**

Tuollaista ei 【olisi】 tapahtua alkuunkaan.

That shouldn't happen at all.

[[Finnish#^fi-Q0621-answer|Compare the answer]]
^fi-Q0621

**fi-Q0622 · Build the sentence**

Arrange: ei / Tuollaista / tapahtua / pitäisi / alkuunkaan.

That shouldn't happen at all.

[[Finnish#^fi-Q0622-answer|Compare the answer]]
^fi-Q0622

**fi-Q0623 · Write a translation**

Write this in Finnish: I'd take it if I were you.

[[Finnish#^fi-Q0623-answer|Compare the answer]]
^fi-Q0623

**fi-Q0624 · Explain the grammar**

Ottaisin sen jos 【olisin】 sinä.

I'd take it if I were you.

[[Finnish#^fi-Q0624-answer|Compare the answer]]
^fi-Q0624

**fi-Q0625 · Fill the gap**

Sinun ____ pitänyt tehdä se aiemmin.

You should've done that sooner.

[[Finnish#^fi-Q0625-answer|Compare the answer]]
^fi-Q0625

**fi-Q0626 · Choose the form**

Sinun ____ pitänyt tehdä se aiemmin.

You should've done that sooner.

Choices: olisi / haluaisin / voisi / olisin

[[Finnish#^fi-Q0626-answer|Compare the answer]]
^fi-Q0626

**fi-Q0627 · Edit the changed sentence**

Olen edelleen sitä miltä, että meidän 【olisin】 pitänyt ostaa se maalaus, josta pidit.

I still think we should've bought the painting you liked.

[[Finnish#^fi-Q0627-answer|Compare the answer]]
^fi-Q0627

**fi-Q0628 · Build the sentence**

Arrange: Olen / se / maalaus, / josta / pitänyt / miltä, / sitä / meidän / ostaa / että / edelleen / pidit. / olisi

I still think we should've bought the painting you liked.

[[Finnish#^fi-Q0628-answer|Compare the answer]]
^fi-Q0628

**fi-Q0629 · Write a translation**

Write this in Finnish: I didn't need to hear that.

[[Finnish#^fi-Q0629-answer|Compare the answer]]
^fi-Q0629

**fi-Q0630 · Explain the grammar**

Tuota minun ei 【olisi】 tarvinnut kuulla.

I didn't need to hear that.

[[Finnish#^fi-Q0630-answer|Compare the answer]]
^fi-Q0630

**fi-Q0631 · Fill the gap**

Ajatus Jumalasta ____ paljon mielenkiintoisempi, jos hän olisi löytänyt ihmiset sen sijaan, että hän olisi luonut heidät.

The idea of God would be more interesting if instead of having created humans he had found them.

[[Finnish#^fi-Q0631-answer|Compare the answer]]
^fi-Q0631

**fi-Q0632 · Choose the form**

Ajatus Jumalasta ____ paljon mielenkiintoisempi, jos hän olisi löytänyt ihmiset sen sijaan, että hän olisi luonut heidät.

The idea of God would be more interesting if instead of having created humans he had found them.

Choices: olisi / olisin / voisi / haluaisin

[[Finnish#^fi-Q0632-answer|Compare the answer]]
^fi-Q0632

**fi-Q0633 · Edit the changed sentence**

Sinun 【olisi】 toteuttaa ensimmäinen suunnitelmasi.

You should carry out your first plan.

[[Finnish#^fi-Q0633-answer|Compare the answer]]
^fi-Q0633

**fi-Q0634 · Build the sentence**

Arrange: Sinun / pitäisi / suunnitelmasi. / ensimmäinen / toteuttaa

You should carry out your first plan.

[[Finnish#^fi-Q0634-answer|Compare the answer]]
^fi-Q0634

**fi-Q0635 · Write a translation**

Write this in Finnish: I never knew Tom's mother was Japanese.

[[Finnish#^fi-Q0635-answer|Compare the answer]]
^fi-Q0635

**fi-Q0636 · Explain the grammar**

Minulla ei ollut aavistustakaan, että Tomin äiti 【olisi】 japanilainen.

I never knew Tom's mother was Japanese.

[[Finnish#^fi-Q0636-answer|Compare the answer]]
^fi-Q0636

**fi-Q0637 · Fill the gap**

Meidän ei ____ vetää liian hätäisiä johtopäätöksiä.

We shouldn't jump to conclusions.

[[Finnish#^fi-Q0637-answer|Compare the answer]]
^fi-Q0637

**fi-Q0638 · Choose the form**

Meidän ei ____ vetää liian hätäisiä johtopäätöksiä.

We shouldn't jump to conclusions.

Choices: voisi / olisin / olisi / pitäisi

[[Finnish#^fi-Q0638-answer|Compare the answer]]
^fi-Q0638

**fi-Q0639 · Edit the changed sentence**

Sinun 【olisin】 pitänyt suudella Tomia.

You should've kissed Tom.

[[Finnish#^fi-Q0639-answer|Compare the answer]]
^fi-Q0639

**fi-Q0640 · Build the sentence**

Arrange: Sinun / Tomia. / suudella / olisi / pitänyt

You should've kissed Tom.

[[Finnish#^fi-Q0640-answer|Compare the answer]]
^fi-Q0640

**fi-Q0641 · Write a translation**

Write this in Finnish: You'd better see a dentist at once.

[[Finnish#^fi-Q0641-answer|Compare the answer]]
^fi-Q0641

**fi-Q0642 · Explain the grammar**

Sinun 【olisi】 parempi käydä hammaslääkärillä heti.

You'd better see a dentist at once.

[[Finnish#^fi-Q0642-answer|Compare the answer]]
^fi-Q0642

**fi-Q0643 · Fill the gap**

Mitä meidän ____ tehdä tänään?

What should we do today?

[[Finnish#^fi-Q0643-answer|Compare the answer]]
^fi-Q0643

**fi-Q0644 · Choose the form**

Mitä meidän ____ tehdä tänään?

What should we do today?

Choices: voisi / pitäisi / olisi / olisin

[[Finnish#^fi-Q0644-answer|Compare the answer]]
^fi-Q0644

**fi-Q0645 · Edit the changed sentence**

Haisee siltä kuin joku 【olisin】 polttanut täällä.

It smells as though someone has been smoking in here.

[[Finnish#^fi-Q0645-answer|Compare the answer]]
^fi-Q0645

**fi-Q0646 · Build the sentence**

Arrange: olisi / siltä / kuin / polttanut / joku / täällä. / Haisee

It smells as though someone has been smoking in here.

[[Finnish#^fi-Q0646-answer|Compare the answer]]
^fi-Q0646

**fi-Q0647 · Write a translation**

Write this in Finnish: You had better go now.

[[Finnish#^fi-Q0647-answer|Compare the answer]]
^fi-Q0647

**fi-Q0648 · Explain the grammar**

Sinun 【olisi】 parempi mennä nyt.

You had better go now.

[[Finnish#^fi-Q0648-answer|Compare the answer]]
^fi-Q0648

**fi-Q0649 · Fill the gap**

Mistä ____ saada kartan?

Where can I get the map?

[[Finnish#^fi-Q0649-answer|Compare the answer]]
^fi-Q0649

**fi-Q0650 · Choose the form**

Mistä ____ saada kartan?

Where can I get the map?

Choices: voisin / voisi / olisin / olisi

[[Finnish#^fi-Q0650-answer|Compare the answer]]
^fi-Q0650


### Questions and question particle · 50 questions

**fi-Q0651 · Edit the changed sentence**

【mikä】 sitä ennen tapahtui?

What happened before that?

[[Finnish#^fi-Q0651-answer|Compare the answer]]
^fi-Q0651

**fi-Q0652 · Build the sentence**

Arrange: tapahtui? / ennen / sitä / Mitä

What happened before that?

[[Finnish#^fi-Q0652-answer|Compare the answer]]
^fi-Q0652

**fi-Q0653 · Write a translation**

Write this in Finnish: We have to tell everybody what happened.

[[Finnish#^fi-Q0653-answer|Compare the answer]]
^fi-Q0653

**fi-Q0654 · Explain the grammar**

Meidän täytyy kertoa kaikille 【mitä】 tapahtui.

We have to tell everybody what happened.

[[Finnish#^fi-Q0654-answer|Compare the answer]]
^fi-Q0654

**fi-Q0655 · Fill the gap**

____ lehmällä vaaleanpunaiset utareet?

Does a cow have a pink udder?

[[Finnish#^fi-Q0655-answer|Compare the answer]]
^fi-Q0655

**fi-Q0656 · Choose the form**

____ lehmällä vaaleanpunaiset utareet?

Does a cow have a pink udder?

Choices: kuka / mitä / mikä / Onko

[[Finnish#^fi-Q0656-answer|Compare the answer]]
^fi-Q0656

**fi-Q0657 · Edit the changed sentence**

Tiedätkö 【mitä】 kevätkääryleitä sanotaan kevätkääryleiksi?

Do you know why spring rolls are called spring rolls?

[[Finnish#^fi-Q0657-answer|Compare the answer]]
^fi-Q0657

**fi-Q0658 · Build the sentence**

Arrange: kevätkääryleiksi? / miksi / kevätkääryleitä / sanotaan / Tiedätkö

Do you know why spring rolls are called spring rolls?

[[Finnish#^fi-Q0658-answer|Compare the answer]]
^fi-Q0658

**fi-Q0659 · Write a translation**

Write this in Finnish: What would you like for breakfast?

[[Finnish#^fi-Q0659-answer|Compare the answer]]
^fi-Q0659

**fi-Q0660 · Explain the grammar**

【Mitä】 haluaisit aamiaiseksi?

What would you like for breakfast?

[[Finnish#^fi-Q0660-answer|Compare the answer]]
^fi-Q0660

**fi-Q0661 · Fill the gap**

____ australialainen vai uusiseelantilainen?

Are you Australian or Kiwi?

[[Finnish#^fi-Q0661-answer|Compare the answer]]
^fi-Q0661

**fi-Q0662 · Choose the form**

____ australialainen vai uusiseelantilainen?

Are you Australian or Kiwi?

Choices: mikä / mitä / kuka / Oletko

[[Finnish#^fi-Q0662-answer|Compare the answer]]
^fi-Q0662

**fi-Q0663 · Edit the changed sentence**

【mitä】 tämä kuva, jonka hän on piirtänyt itse?

Is this a picture that he drew by himself?

[[Finnish#^fi-Q0663-answer|Compare the answer]]
^fi-Q0663

**fi-Q0664 · Build the sentence**

Arrange: Onko / jonka / piirtänyt / itse? / kuva, / hän / tämä / on

Is this a picture that he drew by himself?

[[Finnish#^fi-Q0664-answer|Compare the answer]]
^fi-Q0664

**fi-Q0665 · Write a translation**

Write this in Finnish: How are you, Tom?

[[Finnish#^fi-Q0665-answer|Compare the answer]]
^fi-Q0665

**fi-Q0666 · Explain the grammar**

【Miten】 menee, Tom?

How are you, Tom?

[[Finnish#^fi-Q0666-answer|Compare the answer]]
^fi-Q0666

**fi-Q0667 · Fill the gap**

En uskon mitään, ____ en ole omin silmin nähnyt.

I don't believe anything I haven't seen with my own eyes.

[[Finnish#^fi-Q0667-answer|Compare the answer]]
^fi-Q0667

**fi-Q0668 · Choose the form**

En uskon mitään, ____ en ole omin silmin nähnyt.

I don't believe anything I haven't seen with my own eyes.

Choices: missä / mitä / mikä / kuka

[[Finnish#^fi-Q0668-answer|Compare the answer]]
^fi-Q0668

**fi-Q0669 · Edit the changed sentence**

【mitä】 menet kouluun?

How do you get to school?

[[Finnish#^fi-Q0669-answer|Compare the answer]]
^fi-Q0669

**fi-Q0670 · Build the sentence**

Arrange: menet / kouluun? / Miten

How do you get to school?

[[Finnish#^fi-Q0670-answer|Compare the answer]]
^fi-Q0670

**fi-Q0671 · Write a translation**

Write this in Finnish: Have you been out at all?

[[Finnish#^fi-Q0671-answer|Compare the answer]]
^fi-Q0671

**fi-Q0672 · Explain the grammar**

【Oletko】 ollut ollenkaan ulkona?

Have you been out at all?

[[Finnish#^fi-Q0672-answer|Compare the answer]]
^fi-Q0672

**fi-Q0673 · Fill the gap**

____ samaa mieltä?

Do you agree?

[[Finnish#^fi-Q0673-answer|Compare the answer]]
^fi-Q0673

**fi-Q0674 · Choose the form**

____ samaa mieltä?

Do you agree?

Choices: mitä / kuka / mikä / Oletko

[[Finnish#^fi-Q0674-answer|Compare the answer]]
^fi-Q0674

**fi-Q0675 · Edit the changed sentence**

【mitä】 valmis laittamaan sen sisään?

Are you ready to put it in?

[[Finnish#^fi-Q0675-answer|Compare the answer]]
^fi-Q0675

**fi-Q0676 · Build the sentence**

Arrange: valmis / laittamaan / sisään? / Oletko / sen

Are you ready to put it in?

[[Finnish#^fi-Q0676-answer|Compare the answer]]
^fi-Q0676

**fi-Q0677 · Write a translation**

Write this in Finnish: Is Finland dangerous?

[[Finnish#^fi-Q0677-answer|Compare the answer]]
^fi-Q0677

**fi-Q0678 · Explain the grammar**

【Onko】 Suomi vaarallinen?

Is Finland dangerous?

[[Finnish#^fi-Q0678-answer|Compare the answer]]
^fi-Q0678

**fi-Q0679 · Fill the gap**

____ sinä ostit?

What did you buy?

[[Finnish#^fi-Q0679-answer|Compare the answer]]
^fi-Q0679

**fi-Q0680 · Choose the form**

____ sinä ostit?

What did you buy?

Choices: missä / Mitä / kuka / mikä

[[Finnish#^fi-Q0680-answer|Compare the answer]]
^fi-Q0680

**fi-Q0681 · Edit the changed sentence**

【mitä】 tuo oikeasti totta?

Is that really true?

[[Finnish#^fi-Q0681-answer|Compare the answer]]
^fi-Q0681

**fi-Q0682 · Build the sentence**

Arrange: Onko / tuo / totta? / oikeasti

Is that really true?

[[Finnish#^fi-Q0682-answer|Compare the answer]]
^fi-Q0682

**fi-Q0683 · Write a translation**

Write this in Finnish: Tom wanted to know what happened.

[[Finnish#^fi-Q0683-answer|Compare the answer]]
^fi-Q0683

**fi-Q0684 · Explain the grammar**

Tom tahtoi tietää 【mitä】 sattui.

Tom wanted to know what happened.

[[Finnish#^fi-Q0684-answer|Compare the answer]]
^fi-Q0684

**fi-Q0685 · Fill the gap**

____ sinä odotat?

What are you waiting for?

[[Finnish#^fi-Q0685-answer|Compare the answer]]
^fi-Q0685

**fi-Q0686 · Choose the form**

____ sinä odotat?

What are you waiting for?

Choices: mikä / kuka / missä / Mitä

[[Finnish#^fi-Q0686-answer|Compare the answer]]
^fi-Q0686

**fi-Q0687 · Edit the changed sentence**

【mitä】 kirjoitetaan Kleopatra hieroglyfeillä?

How do you write Cleopatra in hieroglyphs?

[[Finnish#^fi-Q0687-answer|Compare the answer]]
^fi-Q0687

**fi-Q0688 · Build the sentence**

Arrange: kirjoitetaan / hieroglyfeillä? / Miten / Kleopatra

How do you write Cleopatra in hieroglyphs?

[[Finnish#^fi-Q0688-answer|Compare the answer]]
^fi-Q0688

**fi-Q0689 · Write a translation**

Write this in Finnish: Why did you lock the door?

[[Finnish#^fi-Q0689-answer|Compare the answer]]
^fi-Q0689

**fi-Q0690 · Explain the grammar**

【Miksi】 lukitsit oven?

Why did you lock the door?

[[Finnish#^fi-Q0690-answer|Compare the answer]]
^fi-Q0690

**fi-Q0691 · Fill the gap**

____ on menossa naimisiin?

Who's getting married?

[[Finnish#^fi-Q0691-answer|Compare the answer]]
^fi-Q0691

**fi-Q0692 · Choose the form**

____ on menossa naimisiin?

Who's getting married?

Choices: mitä / missä / Kuka / mikä

[[Finnish#^fi-Q0692-answer|Compare the answer]]
^fi-Q0692

**fi-Q0693 · Edit the changed sentence**

En usko, että Tom ymmärtää, 【mikä】 sanot.

I don't think Tom understands what you're saying.

[[Finnish#^fi-Q0693-answer|Compare the answer]]
^fi-Q0693

**fi-Q0694 · Build the sentence**

Arrange: Tom / että / mitä / sanot. / En / ymmärtää, / usko,

I don't think Tom understands what you're saying.

[[Finnish#^fi-Q0694-answer|Compare the answer]]
^fi-Q0694

**fi-Q0695 · Write a translation**

Write this in Finnish: Did you understand what I meant by that?

[[Finnish#^fi-Q0695-answer|Compare the answer]]
^fi-Q0695

**fi-Q0696 · Explain the grammar**

Ymmärrätkö sinä 【mitä】 minä tarkoitan tuolla?

Did you understand what I meant by that?

[[Finnish#^fi-Q0696-answer|Compare the answer]]
^fi-Q0696

**fi-Q0697 · Fill the gap**

____ sinä aiot ottaa ruoaksi?

What are you going to have?

[[Finnish#^fi-Q0697-answer|Compare the answer]]
^fi-Q0697

**fi-Q0698 · Choose the form**

____ sinä aiot ottaa ruoaksi?

What are you going to have?

Choices: mikä / missä / Mitä / kuka

[[Finnish#^fi-Q0698-answer|Compare the answer]]
^fi-Q0698

**fi-Q0699 · Edit the changed sentence**

【mitä】 minä voin nukkua?

How can I sleep?

[[Finnish#^fi-Q0699-answer|Compare the answer]]
^fi-Q0699

**fi-Q0700 · Build the sentence**

Arrange: Miten / voin / nukkua? / minä

How can I sleep?

[[Finnish#^fi-Q0700-answer|Compare the answer]]
^fi-Q0700


### Relative forms · 50 questions

**fi-Q0701 · Write a translation**

Write this in Finnish: I travel almost every day.

[[Finnish#^fi-Q0701-answer|Compare the answer]]
^fi-Q0701

**fi-Q0702 · Explain the grammar**

Matkustan melkein 【joka】 päivä.

I travel almost every day.

[[Finnish#^fi-Q0702-answer|Compare the answer]]
^fi-Q0702

**fi-Q0703 · Fill the gap**

Voi olla, että se ei ollut Tomi, ____ rikkoi ikkunan.

Tom might not be the one who broke the window.

[[Finnish#^fi-Q0703-answer|Compare the answer]]
^fi-Q0703

**fi-Q0704 · Choose the form**

Voi olla, että se ei ollut Tomi, ____ rikkoi ikkunan.

Tom might not be the one who broke the window.

Choices: joka / jota / jonka / jossa

[[Finnish#^fi-Q0704-answer|Compare the answer]]
^fi-Q0704

**fi-Q0705 · Edit the changed sentence**

Te olette ainoita, 【joka】 voivat auttaa minua.

You're the only one who can help me.

[[Finnish#^fi-Q0705-answer|Compare the answer]]
^fi-Q0705

**fi-Q0706 · Build the sentence**

Arrange: ainoita, / auttaa / Te / olette / jotka / minua. / voivat

You're the only one who can help me.

[[Finnish#^fi-Q0706-answer|Compare the answer]]
^fi-Q0706

**fi-Q0707 · Write a translation**

Write this in Finnish: I know the girl who is playing tennis.

[[Finnish#^fi-Q0707-answer|Compare the answer]]
^fi-Q0707

**fi-Q0708 · Explain the grammar**

Minä tunnen sen tytön, 【joka】 pelaa tennistä.

I know the girl who is playing tennis.

[[Finnish#^fi-Q0708-answer|Compare the answer]]
^fi-Q0708

**fi-Q0709 · Fill the gap**

Tuo tyttö ____ pitää huivia on neitsyt.

That girl who's wearing a scarf is a virgin.

[[Finnish#^fi-Q0709-answer|Compare the answer]]
^fi-Q0709

**fi-Q0710 · Choose the form**

Tuo tyttö ____ pitää huivia on neitsyt.

That girl who's wearing a scarf is a virgin.

Choices: jota / jossa / joka / jonka

[[Finnish#^fi-Q0710-answer|Compare the answer]]
^fi-Q0710

**fi-Q0711 · Edit the changed sentence**

Älykäs nainen on sellainen, 【joka】 seurassa voi olla niin tyhmä kuin haluaa.

An intelligent woman is a woman with which one can be as stupid as they want.

[[Finnish#^fi-Q0711-answer|Compare the answer]]
^fi-Q0711

**fi-Q0712 · Build the sentence**

Arrange: on / nainen / haluaa. / seurassa / kuin / Älykäs / sellainen, / olla / niin / voi / jonka / tyhmä

An intelligent woman is a woman with which one can be as stupid as they want.

[[Finnish#^fi-Q0712-answer|Compare the answer]]
^fi-Q0712

**fi-Q0713 · Write a translation**

Write this in Finnish: Everyone who worked on that project became a millionaire.

[[Finnish#^fi-Q0713-answer|Compare the answer]]
^fi-Q0713

**fi-Q0714 · Explain the grammar**

Jokaisesta 【joka】 työskenteli tuon projektin parissa tuli miljonääri.

Everyone who worked on that project became a millionaire.

[[Finnish#^fi-Q0714-answer|Compare the answer]]
^fi-Q0714

**fi-Q0715 · Fill the gap**

Asuimme hotellissa, ____ ympäröivät puut.

We stayed at a hotel surrounded by trees.

[[Finnish#^fi-Q0715-answer|Compare the answer]]
^fi-Q0715

**fi-Q0716 · Choose the form**

Asuimme hotellissa, ____ ympäröivät puut.

We stayed at a hotel surrounded by trees.

Choices: jonka / jota / jossa / joka

[[Finnish#^fi-Q0716-answer|Compare the answer]]
^fi-Q0716

**fi-Q0717 · Edit the changed sentence**

Kasvava lapsi, 【jonka】 ei vaikuta kovin energiseltä, saattaa tarvita lääkäriä.

A growing child who doesn't seem to have much energy perhaps needs medical attention.

[[Finnish#^fi-Q0717-answer|Compare the answer]]
^fi-Q0717

**fi-Q0718 · Build the sentence**

Arrange: joka / Kasvava / vaikuta / tarvita / lääkäriä. / saattaa / lapsi, / ei / energiseltä, / kovin

A growing child who doesn't seem to have much energy perhaps needs medical attention.

[[Finnish#^fi-Q0718-answer|Compare the answer]]
^fi-Q0718

**fi-Q0719 · Write a translation**

Write this in Finnish: Once upon a time there was a dwarf that lived in the forest.

[[Finnish#^fi-Q0719-answer|Compare the answer]]
^fi-Q0719

**fi-Q0720 · Explain the grammar**

Olipa kerran kääpiö, 【joka】 asui metsässä.

Once upon a time there was a dwarf that lived in the forest.

[[Finnish#^fi-Q0720-answer|Compare the answer]]
^fi-Q0720

**fi-Q0721 · Fill the gap**

Onko jotain paikkaa, ____ voimme puhua?

Is there somewhere we can talk?

[[Finnish#^fi-Q0721-answer|Compare the answer]]
^fi-Q0721

**fi-Q0722 · Choose the form**

Onko jotain paikkaa, ____ voimme puhua?

Is there somewhere we can talk?

Choices: jonka / jossa / jota / joka

[[Finnish#^fi-Q0722-answer|Compare the answer]]
^fi-Q0722

**fi-Q0723 · Edit the changed sentence**

Se on riski, 【jonka】 meidän on otettava.

It's a risk we have to take.

[[Finnish#^fi-Q0723-answer|Compare the answer]]
^fi-Q0723

**fi-Q0724 · Build the sentence**

Arrange: riski, / Se / otettava. / on / on / joka / meidän

It's a risk we have to take.

[[Finnish#^fi-Q0724-answer|Compare the answer]]
^fi-Q0724

**fi-Q0725 · Write a translation**

Write this in Finnish: Tom has a daughter who's very beautiful.

[[Finnish#^fi-Q0725-answer|Compare the answer]]
^fi-Q0725

**fi-Q0726 · Explain the grammar**

Tomilla on tytär, 【joka】 on erittäin kaunis.

Tom has a daughter who's very beautiful.

[[Finnish#^fi-Q0726-answer|Compare the answer]]
^fi-Q0726

**fi-Q0727 · Fill the gap**

Jumituimme ruuhkaan, ____ takia myöhästyimme kaksikymmentä minuuttia.

We got stuck in a traffic jam, which made us twenty minutes late.

[[Finnish#^fi-Q0727-answer|Compare the answer]]
^fi-Q0727

**fi-Q0728 · Choose the form**

Jumituimme ruuhkaan, ____ takia myöhästyimme kaksikymmentä minuuttia.

We got stuck in a traffic jam, which made us twenty minutes late.

Choices: jota / jossa / jonka / joka

[[Finnish#^fi-Q0728-answer|Compare the answer]]
^fi-Q0728

**fi-Q0729 · Edit the changed sentence**

【jonka】 iltapäivä nainen meni kirkkoon rukoilemaan.

Every afternoon, the woman went to church to pray.

[[Finnish#^fi-Q0729-answer|Compare the answer]]
^fi-Q0729

**fi-Q0730 · Build the sentence**

Arrange: iltapäivä / kirkkoon / meni / Joka / rukoilemaan. / nainen

Every afternoon, the woman went to church to pray.

[[Finnish#^fi-Q0730-answer|Compare the answer]]
^fi-Q0730

**fi-Q0731 · Write a translation**

Write this in Finnish: A network of railroads spreads all over Japan.

[[Finnish#^fi-Q0731-answer|Compare the answer]]
^fi-Q0731

**fi-Q0732 · Explain the grammar**

Rautateiden verkosto levittäytyy 【joka】 puolelle Japania.

A network of railroads spreads all over Japan.

[[Finnish#^fi-Q0732-answer|Compare the answer]]
^fi-Q0732

**fi-Q0733 · Fill the gap**

Tuo on se talo, ____ majoitun.

That is the house that I stay in.

[[Finnish#^fi-Q0733-answer|Compare the answer]]
^fi-Q0733

**fi-Q0734 · Choose the form**

Tuo on se talo, ____ majoitun.

That is the house that I stay in.

Choices: jonka / jota / joka / jossa

[[Finnish#^fi-Q0734-answer|Compare the answer]]
^fi-Q0734

**fi-Q0735 · Edit the changed sentence**

Sain kirjeitä eräältä henkilöltä 【joka】 en ole koskaan tavannut.

I got letters from a person I've never met.

[[Finnish#^fi-Q0735-answer|Compare the answer]]
^fi-Q0735

**fi-Q0736 · Build the sentence**

Arrange: en / Sain / koskaan / eräältä / henkilöltä / jota / kirjeitä / tavannut. / ole

I got letters from a person I've never met.

[[Finnish#^fi-Q0736-answer|Compare the answer]]
^fi-Q0736

**fi-Q0737 · Write a translation**

Write this in Finnish: Once upon a time, there lived a great king in Greece.

[[Finnish#^fi-Q0737-answer|Compare the answer]]
^fi-Q0737

**fi-Q0738 · Explain the grammar**

Olipa kerran mahtava kuningas, 【joka】 asui Kreikassa.

Once upon a time, there lived a great king in Greece.

[[Finnish#^fi-Q0738-answer|Compare the answer]]
^fi-Q0738

**fi-Q0739 · Fill the gap**

He soittavat toisilleen lähes ____ päivä.

They call each other almost every day.

[[Finnish#^fi-Q0739-answer|Compare the answer]]
^fi-Q0739

**fi-Q0740 · Choose the form**

He soittavat toisilleen lähes ____ päivä.

They call each other almost every day.

Choices: jota / joka / jonka / jossa

[[Finnish#^fi-Q0740-answer|Compare the answer]]
^fi-Q0740

**fi-Q0741 · Edit the changed sentence**

Hänellä, 【jonka】 ei lue, ei ole yliotetta häneen, joka ei osaa lukea.

A person who won't read has no advantage over one who can't read.

[[Finnish#^fi-Q0741-answer|Compare the answer]]
^fi-Q0741

**fi-Q0742 · Build the sentence**

Arrange: Hänellä, / joka / lukea. / ole / osaa / ei / lue, / ei / ei / yliotetta / joka / häneen,

A person who won't read has no advantage over one who can't read.

[[Finnish#^fi-Q0742-answer|Compare the answer]]
^fi-Q0742

**fi-Q0743 · Write a translation**

Write this in Finnish: Boston Dynamic's robot, RHex, is an amazing piece of work that can run over various terrains.

[[Finnish#^fi-Q0743-answer|Compare the answer]]
^fi-Q0743

**fi-Q0744 · Explain the grammar**

Boston Dynamicin robotti RHex on ihmeellinen tekele, 【joka】 osaa juosta monenlaisessa maastossa.

Boston Dynamic's robot, RHex, is an amazing piece of work that can run over various terrains.

[[Finnish#^fi-Q0744-answer|Compare the answer]]
^fi-Q0744

**fi-Q0745 · Fill the gap**

Tomi on ainoa, ____ osaa korjata tämän.

Tom is the only one who knows how to fix this.

[[Finnish#^fi-Q0745-answer|Compare the answer]]
^fi-Q0745

**fi-Q0746 · Choose the form**

Tomi on ainoa, ____ osaa korjata tämän.

Tom is the only one who knows how to fix this.

Choices: jota / jonka / jossa / joka

[[Finnish#^fi-Q0746-answer|Compare the answer]]
^fi-Q0746

**fi-Q0747 · Edit the changed sentence**

Anna minulle paperinpala, 【joka】 voin kirjoittaa!

Give me a piece of paper to write on!

[[Finnish#^fi-Q0747-answer|Compare the answer]]
^fi-Q0747

**fi-Q0748 · Build the sentence**

Arrange: minulle / voin / paperinpala, / kirjoittaa! / johon / Anna

Give me a piece of paper to write on!

[[Finnish#^fi-Q0748-answer|Compare the answer]]
^fi-Q0748

**fi-Q0749 · Write a translation**

Write this in Finnish: He goes to school to study every day.

[[Finnish#^fi-Q0749-answer|Compare the answer]]
^fi-Q0749

**fi-Q0750 · Explain the grammar**

Hän menee kouluun opiskelemaan 【joka】 päivä.

He goes to school to study every day.

[[Finnish#^fi-Q0750-answer|Compare the answer]]
^fi-Q0750


### Complement and condition · 50 questions

**fi-Q0751 · Fill the gap**

Voisitko katsoa hetken muualle ____ vaihdan vaatteeni?

Would you mind looking the other way for just a minute while I change my clothes?

[[Finnish#^fi-Q0751-answer|Compare the answer]]
^fi-Q0751

**fi-Q0752 · Choose the form**

Voisitko katsoa hetken muualle ____ vaihdan vaatteeni?

Would you mind looking the other way for just a minute while I change my clothes?

Choices: jos / kun / koska / että

[[Finnish#^fi-Q0752-answer|Compare the answer]]
^fi-Q0752

**fi-Q0753 · Edit the changed sentence**

Olen pahoillani 【että】 olen antanut sinun odottaa.

I'm sorry I've kept you waiting so long.

[[Finnish#^fi-Q0753-answer|Compare the answer]]
^fi-Q0753

**fi-Q0754 · Build the sentence**

Arrange: odottaa. / antanut / pahoillani / olen / kun / Olen / sinun

I'm sorry I've kept you waiting so long.

[[Finnish#^fi-Q0754-answer|Compare the answer]]
^fi-Q0754

**fi-Q0755 · Write a translation**

Write this in Finnish: The diagram above commutes if and only if f is an isomorphism.

[[Finnish#^fi-Q0755-answer|Compare the answer]]
^fi-Q0755

**fi-Q0756 · Explain the grammar**

Yllä oleva diagrammi kommutoi aina ja vain, 【kun】 f on isomorfismi.

The diagram above commutes if and only if f is an isomorphism.

[[Finnish#^fi-Q0756-answer|Compare the answer]]
^fi-Q0756

**fi-Q0757 · Fill the gap**

On sanomattakin selvää, ____ hän on onnellinen.

It goes without saying that she is happy.

[[Finnish#^fi-Q0757-answer|Compare the answer]]
^fi-Q0757

**fi-Q0758 · Choose the form**

On sanomattakin selvää, ____ hän on onnellinen.

It goes without saying that she is happy.

Choices: koska / kun / jos / että

[[Finnish#^fi-Q0758-answer|Compare the answer]]
^fi-Q0758

**fi-Q0759 · Edit the changed sentence**

Luulin, 【jos】 tänään on maanantai.

I thought it was Monday today.

[[Finnish#^fi-Q0759-answer|Compare the answer]]
^fi-Q0759

**fi-Q0760 · Build the sentence**

Arrange: on / maanantai. / Luulin, / tänään / että

I thought it was Monday today.

[[Finnish#^fi-Q0760-answer|Compare the answer]]
^fi-Q0760

**fi-Q0761 · Write a translation**

Write this in Finnish: I'll introduce you to Tom if you want me to.

[[Finnish#^fi-Q0761-answer|Compare the answer]]
^fi-Q0761

**fi-Q0762 · Explain the grammar**

Esittelen sinut Tomille, 【jos】 niin haluat.

I'll introduce you to Tom if you want me to.

[[Finnish#^fi-Q0762-answer|Compare the answer]]
^fi-Q0762

**fi-Q0763 · Fill the gap**

Heti ____ menet ulos asemalta, käänny vasemmalle.

As soon as you leave the station, turn left.

[[Finnish#^fi-Q0763-answer|Compare the answer]]
^fi-Q0763

**fi-Q0764 · Choose the form**

Heti ____ menet ulos asemalta, käänny vasemmalle.

As soon as you leave the station, turn left.

Choices: jos / kun / että / koska

[[Finnish#^fi-Q0764-answer|Compare the answer]]
^fi-Q0764

**fi-Q0765 · Edit the changed sentence**

Mitäpä 【että】 vain jäisit?

Why not just stay?

[[Finnish#^fi-Q0765-answer|Compare the answer]]
^fi-Q0765

**fi-Q0766 · Build the sentence**

Arrange: jos / vain / Mitäpä / jäisit?

Why not just stay?

[[Finnish#^fi-Q0766-answer|Compare the answer]]
^fi-Q0766

**fi-Q0767 · Write a translation**

Write this in Finnish: A girl opened the door in answer to my knock.

[[Finnish#^fi-Q0767-answer|Compare the answer]]
^fi-Q0767

**fi-Q0768 · Explain the grammar**

Tyttö avasi oven, 【kun】 koputin.

A girl opened the door in answer to my knock.

[[Finnish#^fi-Q0768-answer|Compare the answer]]
^fi-Q0768

**fi-Q0769 · Fill the gap**

Palauta kirja ____ olet lukenut sen.

Please return the book when you have finished reading it.

[[Finnish#^fi-Q0769-answer|Compare the answer]]
^fi-Q0769

**fi-Q0770 · Choose the form**

Palauta kirja ____ olet lukenut sen.

Please return the book when you have finished reading it.

Choices: että / jos / kun / koska

[[Finnish#^fi-Q0770-answer|Compare the answer]]
^fi-Q0770

**fi-Q0771 · Edit the changed sentence**

Tiedän, 【jos】 ette te valehtele.

I know you're not lying.

[[Finnish#^fi-Q0771-answer|Compare the answer]]
^fi-Q0771

**fi-Q0772 · Build the sentence**

Arrange: te / että / valehtele. / Tiedän, / ette

I know you're not lying.

[[Finnish#^fi-Q0772-answer|Compare the answer]]
^fi-Q0772

**fi-Q0773 · Write a translation**

Write this in Finnish: I say quite deliberately that the Christian religion, as organized in its churches, has been and still is the principal enemy of moral progress in the world.

[[Finnish#^fi-Q0773-answer|Compare the answer]]
^fi-Q0773

**fi-Q0774 · Explain the grammar**

Sanon harkinnan jälkeen, 【että】 kristinusko, kirkkoihin järjestäytyneenä, on ollut ja on yhä yleismaallisen moraalisen kehityksen perivihollinen.

I say quite deliberately that the Christian religion, as organized in its churches, has been and still is the principal enemy of moral progress in the world.

[[Finnish#^fi-Q0774-answer|Compare the answer]]
^fi-Q0774

**fi-Q0775 · Fill the gap**

Protokollaa käytetään ____ tietokoneet kommunikoivat keskenään, aivan kuten ihmisetkin.

A protocol is used when computers intercommunicate, just as human beings do.

[[Finnish#^fi-Q0775-answer|Compare the answer]]
^fi-Q0775

**fi-Q0776 · Choose the form**

Protokollaa käytetään ____ tietokoneet kommunikoivat keskenään, aivan kuten ihmisetkin.

A protocol is used when computers intercommunicate, just as human beings do.

Choices: että / jos / kun / koska

[[Finnish#^fi-Q0776-answer|Compare the answer]]
^fi-Q0776

**fi-Q0777 · Edit the changed sentence**

Et saa ikinä tietää, 【että】 et kokeile.

You'll never know unless you try.

[[Finnish#^fi-Q0777-answer|Compare the answer]]
^fi-Q0777

**fi-Q0778 · Build the sentence**

Arrange: Et / ikinä / tietää, / kokeile. / saa / et / jos

You'll never know unless you try.

[[Finnish#^fi-Q0778-answer|Compare the answer]]
^fi-Q0778

**fi-Q0779 · Write a translation**

Write this in Finnish: Thanks for spotting the typo.

[[Finnish#^fi-Q0779-answer|Compare the answer]]
^fi-Q0779

**fi-Q0780 · Explain the grammar**

Kiitos, 【että】 huomasit kirjoitusvirheen!

Thanks for spotting the typo.

[[Finnish#^fi-Q0780-answer|Compare the answer]]
^fi-Q0780

**fi-Q0781 · Fill the gap**

He huomasivat, ____ heidän perheensä eivät pitäneet toisistaan.

They found that their families didn't like each other.

[[Finnish#^fi-Q0781-answer|Compare the answer]]
^fi-Q0781

**fi-Q0782 · Choose the form**

He huomasivat, ____ heidän perheensä eivät pitäneet toisistaan.

They found that their families didn't like each other.

Choices: koska / jos / kun / että

[[Finnish#^fi-Q0782-answer|Compare the answer]]
^fi-Q0782

**fi-Q0783 · Edit the changed sentence**

On hyvä merkki, 【että】 heistä ei kuulu mitään.

No news is good news.

[[Finnish#^fi-Q0783-answer|Compare the answer]]
^fi-Q0783

**fi-Q0784 · Build the sentence**

Arrange: hyvä / jos / heistä / ei / mitään. / On / merkki, / kuulu

No news is good news.

[[Finnish#^fi-Q0784-answer|Compare the answer]]
^fi-Q0784

**fi-Q0785 · Write a translation**

Write this in Finnish: Tom seemed to think that you and I used to be married.

[[Finnish#^fi-Q0785-answer|Compare the answer]]
^fi-Q0785

**fi-Q0786 · Explain the grammar**

Tom tuntui luulevan, 【että】 sinä ja minä olisimme olleet aiemmin naimisissa.

Tom seemed to think that you and I used to be married.

[[Finnish#^fi-Q0786-answer|Compare the answer]]
^fi-Q0786

**fi-Q0787 · Fill the gap**

Jokainen sanoo ____ ruoka tässä ravintolassa on sekä herkullista että edullista.

Everyone says the food in this restaurant is both delicious and inexpensive.

[[Finnish#^fi-Q0787-answer|Compare the answer]]
^fi-Q0787

**fi-Q0788 · Choose the form**

Jokainen sanoo ____ ruoka tässä ravintolassa on sekä herkullista että edullista.

Everyone says the food in this restaurant is both delicious and inexpensive.

Choices: koska / että / jos / kun

[[Finnish#^fi-Q0788-answer|Compare the answer]]
^fi-Q0788

**fi-Q0789 · Edit the changed sentence**

【että】 saavut talolle?

When will you be arriving to the house?

[[Finnish#^fi-Q0789-answer|Compare the answer]]
^fi-Q0789

**fi-Q0790 · Build the sentence**

Arrange: talolle? / Koska / saavut

When will you be arriving to the house?

[[Finnish#^fi-Q0790-answer|Compare the answer]]
^fi-Q0790

**fi-Q0791 · Write a translation**

Write this in Finnish: Come nearer so that I can see your face.

[[Finnish#^fi-Q0791-answer|Compare the answer]]
^fi-Q0791

**fi-Q0792 · Explain the grammar**

Tule lähemmäksi, 【että】 näen sinun kasvosi.

Come nearer so that I can see your face.

[[Finnish#^fi-Q0792-answer|Compare the answer]]
^fi-Q0792

**fi-Q0793 · Fill the gap**

Tom ei tiedä, ____ olen olemassa.

Tom doesn't know I exist.

[[Finnish#^fi-Q0793-answer|Compare the answer]]
^fi-Q0793

**fi-Q0794 · Choose the form**

Tom ei tiedä, ____ olen olemassa.

Tom doesn't know I exist.

Choices: koska / kun / jos / että

[[Finnish#^fi-Q0794-answer|Compare the answer]]
^fi-Q0794

**fi-Q0795 · Edit the changed sentence**

Harva asia vetää vertoja ilolle lapsesi kasvoilla, 【että】 hän avaa joululahjojaan.

Few things can compare to the joy on your child's face as they open their Christmas presents.

[[Finnish#^fi-Q0795-answer|Compare the answer]]
^fi-Q0795

**fi-Q0796 · Build the sentence**

Arrange: asia / kasvoilla, / vertoja / lapsesi / vetää / joululahjojaan. / avaa / kun / hän / Harva / ilolle

Few things can compare to the joy on your child's face as they open their Christmas presents.

[[Finnish#^fi-Q0796-answer|Compare the answer]]
^fi-Q0796

**fi-Q0797 · Write a translation**

Write this in Finnish: The customer's always right, even when they're not.

[[Finnish#^fi-Q0797-answer|Compare the answer]]
^fi-Q0797

**fi-Q0798 · Explain the grammar**

Asiakas on aina oikeassa, silloinkin 【kun】 ei ole.

The customer's always right, even when they're not.

[[Finnish#^fi-Q0798-answer|Compare the answer]]
^fi-Q0798

**fi-Q0799 · Fill the gap**

Olen iloinen, ____ se en ollut minä.

I'm glad it wasn't me.

[[Finnish#^fi-Q0799-answer|Compare the answer]]
^fi-Q0799

**fi-Q0800 · Choose the form**

Olen iloinen, ____ se en ollut minä.

I'm glad it wasn't me.

Choices: jos / kun / koska / että

[[Finnish#^fi-Q0800-answer|Compare the answer]]
^fi-Q0800


### Postpositions · 50 questions

**fi-Q0801 · Edit the changed sentence**

Autapa minua näiden matkatavaroiden 【jälkeen】.

Just help me with this baggage.

[[Finnish#^fi-Q0801-answer|Compare the answer]]
^fi-Q0801

**fi-Q0802 · Build the sentence**

Arrange: minua / matkatavaroiden / kanssa. / Autapa / näiden

Just help me with this baggage.

[[Finnish#^fi-Q0802-answer|Compare the answer]]
^fi-Q0802

**fi-Q0803 · Write a translation**

Write this in Finnish: Did he go to Hangzhou with his dad?

[[Finnish#^fi-Q0803-answer|Compare the answer]]
^fi-Q0803

**fi-Q0804 · Explain the grammar**

Menikö hän Hangzhouhun isänsä 【kanssa】?

Did he go to Hangzhou with his dad?

[[Finnish#^fi-Q0804-answer|Compare the answer]]
^fi-Q0804

**fi-Q0805 · Fill the gap**

Ajattelin, että saattaisit olla yksinäinen, joten tulin kylään viinipullon ____.

I thought you might be lonely, so I came over with a bottle of wine.

[[Finnish#^fi-Q0805-answer|Compare the answer]]
^fi-Q0805

**fi-Q0806 · Choose the form**

Ajattelin, että saattaisit olla yksinäinen, joten tulin kylään viinipullon ____.

I thought you might be lonely, so I came over with a bottle of wine.

Choices: ennen / jälkeen / kanssa / ilman

[[Finnish#^fi-Q0806-answer|Compare the answer]]
^fi-Q0806

**fi-Q0807 · Edit the changed sentence**

Ostin lähikaupasta mäyräkoiran ja menin sen 【jälkeen】 puistoon viettämään iltaa.

I bought a twelve-pack of beer, and went to the park to spend the night with it.

[[Finnish#^fi-Q0807-answer|Compare the answer]]
^fi-Q0807

**fi-Q0808 · Build the sentence**

Arrange: iltaa. / viettämään / kanssa / Ostin / mäyräkoiran / menin / puistoon / ja / lähikaupasta / sen

I bought a twelve-pack of beer, and went to the park to spend the night with it.

[[Finnish#^fi-Q0808-answer|Compare the answer]]
^fi-Q0808

**fi-Q0809 · Write a translation**

Write this in Finnish: I couldn't go out on account of the bad weather.

[[Finnish#^fi-Q0809-answer|Compare the answer]]
^fi-Q0809

**fi-Q0810 · Explain the grammar**

En voinut mennä ulos huonon 【ilman】 johdosta.

I couldn't go out on account of the bad weather.

[[Finnish#^fi-Q0810-answer|Compare the answer]]
^fi-Q0810

**fi-Q0811 · Fill the gap**

Tomi menee aina nukkumaan ____ puoltayötä.

Tom always go to bed before midnight.

[[Finnish#^fi-Q0811-answer|Compare the answer]]
^fi-Q0811

**fi-Q0812 · Choose the form**

Tomi menee aina nukkumaan ____ puoltayötä.

Tom always go to bed before midnight.

Choices: jälkeen / kanssa / ilman / ennen

[[Finnish#^fi-Q0812-answer|Compare the answer]]
^fi-Q0812

**fi-Q0813 · Edit the changed sentence**

Voiko 【kanssa】 yhtäkään petosta menestyä?

Is it possible to succeed without any act of betrayal?

[[Finnish#^fi-Q0813-answer|Compare the answer]]
^fi-Q0813

**fi-Q0814 · Build the sentence**

Arrange: ilman / petosta / Voiko / yhtäkään / menestyä?

Is it possible to succeed without any act of betrayal?

[[Finnish#^fi-Q0814-answer|Compare the answer]]
^fi-Q0814

**fi-Q0815 · Write a translation**

Write this in Finnish: I usually eat french fries with ketchup.

[[Finnish#^fi-Q0815-answer|Compare the answer]]
^fi-Q0815

**fi-Q0816 · Explain the grammar**

Yleensä syön ranskikset ketsupin 【kanssa】.

I usually eat french fries with ketchup.

[[Finnish#^fi-Q0816-answer|Compare the answer]]
^fi-Q0816

**fi-Q0817 · Fill the gap**

Voi olla, että Tomilla on jotain tekemistä asian ____.

Tom might have something to do with that.

[[Finnish#^fi-Q0817-answer|Compare the answer]]
^fi-Q0817

**fi-Q0818 · Choose the form**

Voi olla, että Tomilla on jotain tekemistä asian ____.

Tom might have something to do with that.

Choices: ennen / kanssa / jälkeen / ilman

[[Finnish#^fi-Q0818-answer|Compare the answer]]
^fi-Q0818

**fi-Q0819 · Edit the changed sentence**

Etkö tykkää leikkiä mun 【jälkeen】?

Don't you like playing with me?

[[Finnish#^fi-Q0819-answer|Compare the answer]]
^fi-Q0819

**fi-Q0820 · Build the sentence**

Arrange: mun / leikkiä / tykkää / kanssa? / Etkö

Don't you like playing with me?

[[Finnish#^fi-Q0820-answer|Compare the answer]]
^fi-Q0820

**fi-Q0821 · Write a translation**

Write this in Finnish: Tom had nothing to do with getting Mary fired.

[[Finnish#^fi-Q0821-answer|Compare the answer]]
^fi-Q0821

**fi-Q0822 · Explain the grammar**

Tomilla ei ollut mitään tekemistä Maryn potkujen 【kanssa】.

Tom had nothing to do with getting Mary fired.

[[Finnish#^fi-Q0822-answer|Compare the answer]]
^fi-Q0822

**fi-Q0823 · Fill the gap**

John haastoi baarissa riitaa vieressään olevien yliopisto-opiskelijoiden ____.

John picked a quarrel with college kids near him at the bar.

[[Finnish#^fi-Q0823-answer|Compare the answer]]
^fi-Q0823

**fi-Q0824 · Choose the form**

John haastoi baarissa riitaa vieressään olevien yliopisto-opiskelijoiden ____.

John picked a quarrel with college kids near him at the bar.

Choices: ennen / ilman / kanssa / jälkeen

[[Finnish#^fi-Q0824-answer|Compare the answer]]
^fi-Q0824

**fi-Q0825 · Edit the changed sentence**

Etkö pääse sisään 【kanssa】 jonottamista, koska tunnet poken?

Can't you get in without lining up because you know the bouncer?

[[Finnish#^fi-Q0825-answer|Compare the answer]]
^fi-Q0825

**fi-Q0826 · Build the sentence**

Arrange: ilman / tunnet / pääse / jonottamista, / poken? / koska / Etkö / sisään

Can't you get in without lining up because you know the bouncer?

[[Finnish#^fi-Q0826-answer|Compare the answer]]
^fi-Q0826

**fi-Q0827 · Write a translation**

Write this in Finnish: The northern half of what is today Papua New Guinea was a German colony.

[[Finnish#^fi-Q0827-answer|Compare the answer]]
^fi-Q0827

**fi-Q0828 · Explain the grammar**

Pohjoinen osa siitä, mikä on nykyään Papua-Uusi-Guinea, oli 【ennen】 Saksan siirtokunta.

The northern half of what is today Papua New Guinea was a German colony.

[[Finnish#^fi-Q0828-answer|Compare the answer]]
^fi-Q0828

**fi-Q0829 · Fill the gap**

Tomin ranskasta tuli melko sujuvaa kolmen vuoden intensiivisen opiskelun ____.

Tom became fairly fluent in French after about three years of intense study.

[[Finnish#^fi-Q0829-answer|Compare the answer]]
^fi-Q0829

**fi-Q0830 · Choose the form**

Tomin ranskasta tuli melko sujuvaa kolmen vuoden intensiivisen opiskelun ____.

Tom became fairly fluent in French after about three years of intense study.

Choices: ennen / jälkeen / kanssa / ilman

[[Finnish#^fi-Q0830-answer|Compare the answer]]
^fi-Q0830

**fi-Q0831 · Edit the changed sentence**

Tomi kävelee kävelykepin 【jälkeen】.

Tom walks with a cane.

[[Finnish#^fi-Q0831-answer|Compare the answer]]
^fi-Q0831

**fi-Q0832 · Build the sentence**

Arrange: kävelee / Tomi / kävelykepin / kanssa.

Tom walks with a cane.

[[Finnish#^fi-Q0832-answer|Compare the answer]]
^fi-Q0832

**fi-Q0833 · Write a translation**

Write this in Finnish: I started dating Tom.

[[Finnish#^fi-Q0833-answer|Compare the answer]]
^fi-Q0833

**fi-Q0834 · Explain the grammar**

Aloin seurustella Tomin 【kanssa】.

I started dating Tom.

[[Finnish#^fi-Q0834-answer|Compare the answer]]
^fi-Q0834

**fi-Q0835 · Fill the gap**

Tom ystävystyi kaikkien ____.

Tom made friends with everybody.

[[Finnish#^fi-Q0835-answer|Compare the answer]]
^fi-Q0835

**fi-Q0836 · Choose the form**

Tom ystävystyi kaikkien ____.

Tom made friends with everybody.

Choices: ennen / jälkeen / ilman / kanssa

[[Finnish#^fi-Q0836-answer|Compare the answer]]
^fi-Q0836

**fi-Q0837 · Edit the changed sentence**

En ollut ehtinyt pitkälle 【kanssa】 kuin tapasin hänet.

I had not gone far before I met him.

[[Finnish#^fi-Q0837-answer|Compare the answer]]
^fi-Q0837

**fi-Q0838 · Build the sentence**

Arrange: kuin / ennen / ehtinyt / En / hänet. / tapasin / ollut / pitkälle

I had not gone far before I met him.

[[Finnish#^fi-Q0838-answer|Compare the answer]]
^fi-Q0838

**fi-Q0839 · Write a translation**

Write this in Finnish: He lives with his mom.

[[Finnish#^fi-Q0839-answer|Compare the answer]]
^fi-Q0839

**fi-Q0840 · Explain the grammar**

Hän asuu äitinsä 【kanssa】.

He lives with his mom.

[[Finnish#^fi-Q0840-answer|Compare the answer]]
^fi-Q0840

**fi-Q0841 · Fill the gap**

Kenen ____ sinä asut?

Who do you live with?

[[Finnish#^fi-Q0841-answer|Compare the answer]]
^fi-Q0841

**fi-Q0842 · Choose the form**

Kenen ____ sinä asut?

Who do you live with?

Choices: ilman / jälkeen / ennen / kanssa

[[Finnish#^fi-Q0842-answer|Compare the answer]]
^fi-Q0842

**fi-Q0843 · Edit the changed sentence**

Hän oli sängyssä hänen pomonsa 【jälkeen】.

She slept with her boss.

[[Finnish#^fi-Q0843-answer|Compare the answer]]
^fi-Q0843

**fi-Q0844 · Build the sentence**

Arrange: hänen / Hän / oli / pomonsa / kanssa. / sängyssä

She slept with her boss.

[[Finnish#^fi-Q0844-answer|Compare the answer]]
^fi-Q0844

**fi-Q0845 · Write a translation**

Write this in Finnish: Make sure the chef is skilled before ordering fugu.

[[Finnish#^fi-Q0845-answer|Compare the answer]]
^fi-Q0845

**fi-Q0846 · Explain the grammar**

Varmista keittiömestarin kyvykkyys 【ennen】 kuin tilaat pallokalaa.

Make sure the chef is skilled before ordering fugu.

[[Finnish#^fi-Q0846-answer|Compare the answer]]
^fi-Q0846

**fi-Q0847 · Fill the gap**

Menin veljeni ____ elokuviin.

I went to the movies with my brother.

[[Finnish#^fi-Q0847-answer|Compare the answer]]
^fi-Q0847

**fi-Q0848 · Choose the form**

Menin veljeni ____ elokuviin.

I went to the movies with my brother.

Choices: ilman / jälkeen / kanssa / ennen

[[Finnish#^fi-Q0848-answer|Compare the answer]]
^fi-Q0848

**fi-Q0849 · Edit the changed sentence**

Minulla ei ole minkäänlaista ongelmaa sen 【jälkeen】.

I have absolutely no problem with that.

[[Finnish#^fi-Q0849-answer|Compare the answer]]
^fi-Q0849

**fi-Q0850 · Build the sentence**

Arrange: ei / ongelmaa / ole / minkäänlaista / Minulla / sen / kanssa.

I have absolutely no problem with that.

[[Finnish#^fi-Q0850-answer|Compare the answer]]
^fi-Q0850


### Quantity and numerals · 50 questions

**fi-Q0851 · Write a translation**

Write this in Finnish: Tom scored four goals.

[[Finnish#^fi-Q0851-answer|Compare the answer]]
^fi-Q0851

**fi-Q0852 · Explain the grammar**

Tom teki 【neljä】 maalia.

Tom scored four goals.

[[Finnish#^fi-Q0852-answer|Compare the answer]]
^fi-Q0852

**fi-Q0853 · Fill the gap**

Tom osaa puhua vain ____ ranskaa.

Tom can speak only a little French.

[[Finnish#^fi-Q0853-answer|Compare the answer]]
^fi-Q0853

**fi-Q0854 · Choose the form**

Tom osaa puhua vain ____ ranskaa.

Tom can speak only a little French.

Choices: vähän / kolme / monta / kaksi

[[Finnish#^fi-Q0854-answer|Compare the answer]]
^fi-Q0854

**fi-Q0855 · Edit the changed sentence**

Tiedän kuinka 【kaksi】 arvostat yksityisyyttäsi.

I know how much you value your privacy.

[[Finnish#^fi-Q0855-answer|Compare the answer]]
^fi-Q0855

**fi-Q0856 · Build the sentence**

Arrange: kuinka / paljon / yksityisyyttäsi. / arvostat / Tiedän

I know how much you value your privacy.

[[Finnish#^fi-Q0856-answer|Compare the answer]]
^fi-Q0856

**fi-Q0857 · Write a translation**

Write this in Finnish: I don't think we can keep the lid on the scandal much longer; people are bound to find out.

[[Finnish#^fi-Q0857-answer|Compare the answer]]
^fi-Q0857

**fi-Q0858 · Explain the grammar**

En usko, että voimme salata skandaalia enää 【paljon】 pidempään; ihmiset saavat selville.

I don't think we can keep the lid on the scandal much longer; people are bound to find out.

[[Finnish#^fi-Q0858-answer|Compare the answer]]
^fi-Q0858

**fi-Q0859 · Fill the gap**

Tom tietää ____ asioita Marista.

Tom knows quite a lot about Mary.

[[Finnish#^fi-Q0859-answer|Compare the answer]]
^fi-Q0859

**fi-Q0860 · Choose the form**

Tom tietää ____ asioita Marista.

Tom knows quite a lot about Mary.

Choices: kolme / kaksi / monta / paljon

[[Finnish#^fi-Q0860-answer|Compare the answer]]
^fi-Q0860

**fi-Q0861 · Edit the changed sentence**

Mitä enemmän syöt, sitä vähemmän meidän tarvitsee tuoda takaisin. Joten syö niin 【kaksi】 kuin haluat!

The more food you eat, the less we have to bring back. So eat as much as you want!

[[Finnish#^fi-Q0861-answer|Compare the answer]]
^fi-Q0861

**fi-Q0862 · Build the sentence**

Arrange: sitä / syöt, / tuoda / Mitä / haluat! / vähemmän / kuin / tarvitsee / takaisin. / syö / Joten / enemmän / paljon / meidän / niin

The more food you eat, the less we have to bring back. So eat as much as you want!

[[Finnish#^fi-Q0862-answer|Compare the answer]]
^fi-Q0862

**fi-Q0863 · Write a translation**

Write this in Finnish: Tom's trip lasted three months.

[[Finnish#^fi-Q0863-answer|Compare the answer]]
^fi-Q0863

**fi-Q0864 · Explain the grammar**

Tomin matka kesti 【kolme】 kuukautta.

Tom's trip lasted three months.

[[Finnish#^fi-Q0864-answer|Compare the answer]]
^fi-Q0864

**fi-Q0865 · Fill the gap**

Suomalaisista on ____ stereotypiaa, mutta stereotyypit ovat usein liioitteluja tai yleistyksiä

There are many stereotypes about Finnish people, but stereotypes are often exaggerations or generalizations.

[[Finnish#^fi-Q0865-answer|Compare the answer]]
^fi-Q0865

**fi-Q0866 · Choose the form**

Suomalaisista on ____ stereotypiaa, mutta stereotyypit ovat usein liioitteluja tai yleistyksiä

There are many stereotypes about Finnish people, but stereotypes are often exaggerations or generalizations.

Choices: kolme / kaksi / monta / paljon

[[Finnish#^fi-Q0866-answer|Compare the answer]]
^fi-Q0866

**fi-Q0867 · Edit the changed sentence**

Odotin 【kaksi】 tuntia.

I waited three hours.

[[Finnish#^fi-Q0867-answer|Compare the answer]]
^fi-Q0867

**fi-Q0868 · Build the sentence**

Arrange: tuntia. / Odotin / kolme

I waited three hours.

[[Finnish#^fi-Q0868-answer|Compare the answer]]
^fi-Q0868

**fi-Q0869 · Write a translation**

Write this in Finnish: The tyre is a little under-inflated.

[[Finnish#^fi-Q0869-answer|Compare the answer]]
^fi-Q0869

**fi-Q0870 · Explain the grammar**

Renkaassa on liian 【vähän】 ilmaa.

The tyre is a little under-inflated.

[[Finnish#^fi-Q0870-answer|Compare the answer]]
^fi-Q0870

**fi-Q0871 · Fill the gap**

Tomilla on ____ mahtavia ideoita.

Tom has a lot of great ideas.

[[Finnish#^fi-Q0871-answer|Compare the answer]]
^fi-Q0871

**fi-Q0872 · Choose the form**

Tomilla on ____ mahtavia ideoita.

Tom has a lot of great ideas.

Choices: paljon / monta / kolme / kaksi

[[Finnish#^fi-Q0872-answer|Compare the answer]]
^fi-Q0872

**fi-Q0873 · Edit the changed sentence**

Tavallisesti syömme 【kaksi】 kertaa päivässä.

Normally, we eat three times a day.

[[Finnish#^fi-Q0873-answer|Compare the answer]]
^fi-Q0873

**fi-Q0874 · Build the sentence**

Arrange: päivässä. / Tavallisesti / syömme / kertaa / kolme

Normally, we eat three times a day.

[[Finnish#^fi-Q0874-answer|Compare the answer]]
^fi-Q0874

**fi-Q0875 · Write a translation**

Write this in Finnish: Tom has three older sisters.

[[Finnish#^fi-Q0875-answer|Compare the answer]]
^fi-Q0875

**fi-Q0876 · Explain the grammar**

Tomilla on 【kolme】 isosiskoa.

Tom has three older sisters.

[[Finnish#^fi-Q0876-answer|Compare the answer]]
^fi-Q0876

**fi-Q0877 · Fill the gap**

Hän on ____ älykkäämpi kuin minä.

He is much smarter than I am.

[[Finnish#^fi-Q0877-answer|Compare the answer]]
^fi-Q0877

**fi-Q0878 · Choose the form**

Hän on ____ älykkäämpi kuin minä.

He is much smarter than I am.

Choices: monta / paljon / kolme / kaksi

[[Finnish#^fi-Q0878-answer|Compare the answer]]
^fi-Q0878

**fi-Q0879 · Edit the changed sentence**

Viime aikoina minulla on ollut 【kaksi】 huono ruokahalu.

Recently, I don't have much appetite.

[[Finnish#^fi-Q0879-answer|Compare the answer]]
^fi-Q0879

**fi-Q0880 · Build the sentence**

Arrange: ruokahalu. / on / huono / ollut / aikoina / minulla / vähän / Viime

Recently, I don't have much appetite.

[[Finnish#^fi-Q0880-answer|Compare the answer]]
^fi-Q0880

**fi-Q0881 · Write a translation**

Write this in Finnish: There's a tendency to conflate proposing a solution with actually solving the problem. I think it's important to differentiate between the two.

[[Finnish#^fi-Q0881-answer|Compare the answer]]
^fi-Q0881

**fi-Q0882 · Explain the grammar**

On tapana sekoittaa ratkaisun ehdottaminen ja ongelman varsinainen ratkaiseminen. Mielestäni on tärkeää erottaa nämä 【kaksi】.

There's a tendency to conflate proposing a solution with actually solving the problem. I think it's important to differentiate between the two.

[[Finnish#^fi-Q0882-answer|Compare the answer]]
^fi-Q0882

**fi-Q0883 · Fill the gap**

Tahtoisin ____ lisää voita.

I'd like some more butter.

[[Finnish#^fi-Q0883-answer|Compare the answer]]
^fi-Q0883

**fi-Q0884 · Choose the form**

Tahtoisin ____ lisää voita.

I'd like some more butter.

Choices: kolme / vähän / monta / kaksi

[[Finnish#^fi-Q0884-answer|Compare the answer]]
^fi-Q0884

**fi-Q0885 · Edit the changed sentence**

Oletteko te 【kolme】 menossa yhdessä ulos?

Are you two going out together?

[[Finnish#^fi-Q0885-answer|Compare the answer]]
^fi-Q0885

**fi-Q0886 · Build the sentence**

Arrange: yhdessä / te / menossa / Oletteko / ulos? / kaksi

Are you two going out together?

[[Finnish#^fi-Q0886-answer|Compare the answer]]
^fi-Q0886

**fi-Q0887 · Write a translation**

Write this in Finnish: I need a little help.

[[Finnish#^fi-Q0887-answer|Compare the answer]]
^fi-Q0887

**fi-Q0888 · Explain the grammar**

Tarvitsen 【vähän】 apua.

I need a little help.

[[Finnish#^fi-Q0888-answer|Compare the answer]]
^fi-Q0888

**fi-Q0889 · Fill the gap**

Teillä on ____ kirjoja.

You have a lot of books.

[[Finnish#^fi-Q0889-answer|Compare the answer]]
^fi-Q0889

**fi-Q0890 · Choose the form**

Teillä on ____ kirjoja.

You have a lot of books.

Choices: monta / paljon / kaksi / kolme

[[Finnish#^fi-Q0890-answer|Compare the answer]]
^fi-Q0890

**fi-Q0891 · Edit the changed sentence**

He olivat 【kaksi】 hämmentyneitä.

They were a bit embarrassed.

[[Finnish#^fi-Q0891-answer|Compare the answer]]
^fi-Q0891

**fi-Q0892 · Build the sentence**

Arrange: olivat / vähän / hämmentyneitä. / He

They were a bit embarrassed.

[[Finnish#^fi-Q0892-answer|Compare the answer]]
^fi-Q0892

**fi-Q0893 · Write a translation**

Write this in Finnish: The cat has two ears.

[[Finnish#^fi-Q0893-answer|Compare the answer]]
^fi-Q0893

**fi-Q0894 · Explain the grammar**

Sillä kissalla on 【kaksi】 korvaa.

The cat has two ears.

[[Finnish#^fi-Q0894-answer|Compare the answer]]
^fi-Q0894

**fi-Q0895 · Fill the gap**

Voimmeko siirtää aikarajaa ____ viikkoa myöhemmäksi?

Can we extend the deadline by two weeks?

[[Finnish#^fi-Q0895-answer|Compare the answer]]
^fi-Q0895

**fi-Q0896 · Choose the form**

Voimmeko siirtää aikarajaa ____ viikkoa myöhemmäksi?

Can we extend the deadline by two weeks?

Choices: kolme / kaksi / monta / paljon

[[Finnish#^fi-Q0896-answer|Compare the answer]]
^fi-Q0896

**fi-Q0897 · Edit the changed sentence**

Sinä osaat uida 【kaksi】 paremmin kuin hän.

You can swim much better than him.

[[Finnish#^fi-Q0897-answer|Compare the answer]]
^fi-Q0897

**fi-Q0898 · Build the sentence**

Arrange: kuin / Sinä / uida / osaat / paremmin / paljon / hän.

You can swim much better than him.

[[Finnish#^fi-Q0898-answer|Compare the answer]]
^fi-Q0898

**fi-Q0899 · Write a translation**

Write this in Finnish: Tom has been in jail three times.

[[Finnish#^fi-Q0899-answer|Compare the answer]]
^fi-Q0899

**fi-Q0900 · Explain the grammar**

Tomi on joutunut vankilaan 【kolme】 kertaa.

Tom has been in jail three times.

[[Finnish#^fi-Q0900-answer|Compare the answer]]
^fi-Q0900


### Perfect participles · 50 questions

**fi-Q0901 · Fill the gap**

Hän meni Kiinaan sotilaana eikä koskaan ____ takaisin.

He went to China as a soldier, never to come back.

[[Finnish#^fi-Q0901-answer|Compare the answer]]
^fi-Q0901

**fi-Q0902 · Choose the form**

Hän meni Kiinaan sotilaana eikä koskaan ____ takaisin.

He went to China as a soldier, never to come back.

Choices: tehnyt / nähnyt / ollut / tullut

[[Finnish#^fi-Q0902-answer|Compare the answer]]
^fi-Q0902

**fi-Q0903 · Edit the changed sentence**

Tomilla ei 【tehnyt】 paljonkaan valinnanvaraa.

Tom didn't have much of a choice.

[[Finnish#^fi-Q0903-answer|Compare the answer]]
^fi-Q0903

**fi-Q0904 · Build the sentence**

Arrange: paljonkaan / Tomilla / ei / ollut / valinnanvaraa.

Tom didn't have much of a choice.

[[Finnish#^fi-Q0904-answer|Compare the answer]]
^fi-Q0904

**fi-Q0905 · Write a translation**

Write this in Finnish: This wasn't cheap, was it?

[[Finnish#^fi-Q0905-answer|Compare the answer]]
^fi-Q0905

**fi-Q0906 · Explain the grammar**

Tämä ei 【ollut】 halpa, eikö niin?

This wasn't cheap, was it?

[[Finnish#^fi-Q0906-answer|Compare the answer]]
^fi-Q0906

**fi-Q0907 · Fill the gap**

Olen ____ noutamaan sinut kotiin.

I've come to take you home.

[[Finnish#^fi-Q0907-answer|Compare the answer]]
^fi-Q0907

**fi-Q0908 · Choose the form**

Olen ____ noutamaan sinut kotiin.

I've come to take you home.

Choices: tullut / tehnyt / nähnyt / ollut

[[Finnish#^fi-Q0908-answer|Compare the answer]]
^fi-Q0908

**fi-Q0909 · Edit the changed sentence**

Tomilla ei 【tehnyt】 mitään syömistä.

Tom had nothing to eat.

[[Finnish#^fi-Q0909-answer|Compare the answer]]
^fi-Q0909

**fi-Q0910 · Build the sentence**

Arrange: ollut / mitään / Tomilla / syömistä. / ei

Tom had nothing to eat.

[[Finnish#^fi-Q0910-answer|Compare the answer]]
^fi-Q0910

**fi-Q0911 · Write a translation**

Write this in Finnish: Tom asked Mary if she'd seen John.

[[Finnish#^fi-Q0911-answer|Compare the answer]]
^fi-Q0911

**fi-Q0912 · Explain the grammar**

Tom kysyi Marilta oliko hän 【nähnyt】 Jonia.

Tom asked Mary if she'd seen John.

[[Finnish#^fi-Q0912-answer|Compare the answer]]
^fi-Q0912

**fi-Q0913 · Fill the gap**

En ____ yhtään nukuttua viime yönä.

I didn't get any sleep last night.

[[Finnish#^fi-Q0913-answer|Compare the answer]]
^fi-Q0913

**fi-Q0914 · Choose the form**

En ____ yhtään nukuttua viime yönä.

I didn't get any sleep last night.

Choices: saanut / tehnyt / ollut / nähnyt

[[Finnish#^fi-Q0914-answer|Compare the answer]]
^fi-Q0914

**fi-Q0915 · Edit the changed sentence**

Tomilla ei 【tehnyt】 aikomusta antaa periksi.

Tom had no intention of giving up.

[[Finnish#^fi-Q0915-answer|Compare the answer]]
^fi-Q0915

**fi-Q0916 · Build the sentence**

Arrange: periksi. / ei / aikomusta / ollut / antaa / Tomilla

Tom had no intention of giving up.

[[Finnish#^fi-Q0916-answer|Compare the answer]]
^fi-Q0916

**fi-Q0917 · Write a translation**

Write this in Finnish: I finally realized that I wasn't in love with you.

[[Finnish#^fi-Q0917-answer|Compare the answer]]
^fi-Q0917

**fi-Q0918 · Explain the grammar**

Viimein tajusin, että en 【ollut】 rakastunut sinuun.

I finally realized that I wasn't in love with you.

[[Finnish#^fi-Q0918-answer|Compare the answer]]
^fi-Q0918

**fi-Q0919 · Fill the gap**

Lapsena minä en ____ ylipainoinen.

I wasn't overweight when I was a kid.

[[Finnish#^fi-Q0919-answer|Compare the answer]]
^fi-Q0919

**fi-Q0920 · Choose the form**

Lapsena minä en ____ ylipainoinen.

I wasn't overweight when I was a kid.

Choices: nähnyt / ollut / tullut / tehnyt

[[Finnish#^fi-Q0920-answer|Compare the answer]]
^fi-Q0920

**fi-Q0921 · Edit the changed sentence**

En ole 【ollut】 vielä uutta muistiota sisäisestä turvallisuudesta.

I haven't yet read the new memorandum on internal security.

[[Finnish#^fi-Q0921-answer|Compare the answer]]
^fi-Q0921

**fi-Q0922 · Build the sentence**

Arrange: uutta / ole / En / lukenut / muistiota / vielä / sisäisestä / turvallisuudesta.

I haven't yet read the new memorandum on internal security.

[[Finnish#^fi-Q0922-answer|Compare the answer]]
^fi-Q0922

**fi-Q0923 · Write a translation**

Write this in Finnish: A full description of him has been circulated in every newspaper.

[[Finnish#^fi-Q0923-answer|Compare the answer]]
^fi-Q0923

**fi-Q0924 · Explain the grammar**

Täydellinen kuvaus hänestä on 【ollut】 levityksessä jokaisessa sanomalehdessä.

A full description of him has been circulated in every newspaper.

[[Finnish#^fi-Q0924-answer|Compare the answer]]
^fi-Q0924

**fi-Q0925 · Fill the gap**

En muista, milloin viimeksi olen ____ Tomin niin onnellisena.

I can't remember the last time I saw Tom so happy.

[[Finnish#^fi-Q0925-answer|Compare the answer]]
^fi-Q0925

**fi-Q0926 · Choose the form**

En muista, milloin viimeksi olen ____ Tomin niin onnellisena.

I can't remember the last time I saw Tom so happy.

Choices: tehnyt / tullut / ollut / nähnyt

[[Finnish#^fi-Q0926-answer|Compare the answer]]
^fi-Q0926

**fi-Q0927 · Edit the changed sentence**

Tämä on kiinnostavin tarina, minkä olen koskaan 【ollut】.

This is the most interesting story that I have ever read.

[[Finnish#^fi-Q0927-answer|Compare the answer]]
^fi-Q0927

**fi-Q0928 · Build the sentence**

Arrange: olen / minkä / on / lukenut. / tarina, / koskaan / Tämä / kiinnostavin

This is the most interesting story that I have ever read.

[[Finnish#^fi-Q0928-answer|Compare the answer]]
^fi-Q0928

**fi-Q0929 · Write a translation**

Write this in Finnish: Tom didn't go to work today.

[[Finnish#^fi-Q0929-answer|Compare the answer]]
^fi-Q0929

**fi-Q0930 · Explain the grammar**

Tomi ei 【mennyt】 tänään töihin.

Tom didn't go to work today.

[[Finnish#^fi-Q0930-answer|Compare the answer]]
^fi-Q0930

**fi-Q0931 · Fill the gap**

Ehkä Tom ei ____ saatavilla.

Maybe Tom wasn't available.

[[Finnish#^fi-Q0931-answer|Compare the answer]]
^fi-Q0931

**fi-Q0932 · Choose the form**

Ehkä Tom ei ____ saatavilla.

Maybe Tom wasn't available.

Choices: tullut / nähnyt / ollut / tehnyt

[[Finnish#^fi-Q0932-answer|Compare the answer]]
^fi-Q0932

**fi-Q0933 · Edit the changed sentence**

Se ei 【tehnyt】 tärkeää.

It wasn't important.

[[Finnish#^fi-Q0933-answer|Compare the answer]]
^fi-Q0933

**fi-Q0934 · Build the sentence**

Arrange: ei / Se / tärkeää. / ollut

It wasn't important.

[[Finnish#^fi-Q0934-answer|Compare the answer]]
^fi-Q0934

**fi-Q0935 · Write a translation**

Write this in Finnish: I didn't see a thing.

[[Finnish#^fi-Q0935-answer|Compare the answer]]
^fi-Q0935

**fi-Q0936 · Explain the grammar**

En 【nähnyt】 yhtään mitään.

I didn't see a thing.

[[Finnish#^fi-Q0936-answer|Compare the answer]]
^fi-Q0936

**fi-Q0937 · Fill the gap**

En ole koskaan ____ matkoillani kauniimpaa vuorta kuin Everest.

In all my travels I've never seen a more beautiful mountain than Everest.

[[Finnish#^fi-Q0937-answer|Compare the answer]]
^fi-Q0937

**fi-Q0938 · Choose the form**

En ole koskaan ____ matkoillani kauniimpaa vuorta kuin Everest.

In all my travels I've never seen a more beautiful mountain than Everest.

Choices: tehnyt / nähnyt / tullut / ollut

[[Finnish#^fi-Q0938-answer|Compare the answer]]
^fi-Q0938

**fi-Q0939 · Edit the changed sentence**

Tom ei 【tehnyt】 varma selviääkö hän.

Tom wasn't sure if he was going to make it.

[[Finnish#^fi-Q0939-answer|Compare the answer]]
^fi-Q0939

**fi-Q0940 · Build the sentence**

Arrange: Tom / ollut / ei / hän. / selviääkö / varma

Tom wasn't sure if he was going to make it.

[[Finnish#^fi-Q0940-answer|Compare the answer]]
^fi-Q0940

**fi-Q0941 · Write a translation**

Write this in Finnish: Modern science has turned many impossibilities into possibilities.

[[Finnish#^fi-Q0941-answer|Compare the answer]]
^fi-Q0941

**fi-Q0942 · Explain the grammar**

Moderni tiede on 【tehnyt】 monista mahdottomista asioista mahdollisia.

Modern science has turned many impossibilities into possibilities.

[[Finnish#^fi-Q0942-answer|Compare the answer]]
^fi-Q0942

**fi-Q0943 · Fill the gap**

En ole koskaan ____ Argentiinassa.

I've never been to Argentina.

[[Finnish#^fi-Q0943-answer|Compare the answer]]
^fi-Q0943

**fi-Q0944 · Choose the form**

En ole koskaan ____ Argentiinassa.

I've never been to Argentina.

Choices: tullut / tehnyt / nähnyt / ollut

[[Finnish#^fi-Q0944-answer|Compare the answer]]
^fi-Q0944

**fi-Q0945 · Edit the changed sentence**

En 【ollut】 tilaisuutta esittäytyä tytölle.

I didn't get a chance to introduce myself to her.

[[Finnish#^fi-Q0945-answer|Compare the answer]]
^fi-Q0945

**fi-Q0946 · Build the sentence**

Arrange: tilaisuutta / En / esittäytyä / tytölle. / saanut

I didn't get a chance to introduce myself to her.

[[Finnish#^fi-Q0946-answer|Compare the answer]]
^fi-Q0946

**fi-Q0947 · Write a translation**

Write this in Finnish: She has been sick in bed for some time.

[[Finnish#^fi-Q0947-answer|Compare the answer]]
^fi-Q0947

**fi-Q0948 · Explain the grammar**

Hän on 【ollut】 vuoteen omana jonkin aikaa.

She has been sick in bed for some time.

[[Finnish#^fi-Q0948-answer|Compare the answer]]
^fi-Q0948

**fi-Q0949 · Fill the gap**

Jätä ____ taakse ja jatka eteenpäin.

Leave the past behind and go on.

[[Finnish#^fi-Q0949-answer|Compare the answer]]
^fi-Q0949

**fi-Q0950 · Choose the form**

Jätä ____ taakse ja jatka eteenpäin.

Leave the past behind and go on.

Choices: tehnyt / ollut / nähnyt / mennyt

[[Finnish#^fi-Q0950-answer|Compare the answer]]
^fi-Q0950


### Comparison and stance · 50 questions

**fi-Q0951 · Edit the changed sentence**

【enemmän】 hän on italialainen tai espanjalainen.

Maybe he is Italian or Spanish.

[[Finnish#^fi-Q0951-answer|Compare the answer]]
^fi-Q0951

**fi-Q0952 · Build the sentence**

Arrange: Ehkä / hän / tai / espanjalainen. / on / italialainen

Maybe he is Italian or Spanish.

[[Finnish#^fi-Q0952-answer|Compare the answer]]
^fi-Q0952

**fi-Q0953 · Write a translation**

Write this in Finnish: I like summer better than winter.

[[Finnish#^fi-Q0953-answer|Compare the answer]]
^fi-Q0953

**fi-Q0954 · Explain the grammar**

Minä pidän 【enemmän】 kesästä kuin talvesta.

I like summer better than winter.

[[Finnish#^fi-Q0954-answer|Compare the answer]]
^fi-Q0954

**fi-Q0955 · Fill the gap**

Tulisitko sinä ____ mukaan?

Would you care to come with us?

[[Finnish#^fi-Q0955-answer|Compare the answer]]
^fi-Q0955

**fi-Q0956 · Choose the form**

Tulisitko sinä ____ mukaan?

Would you care to come with us?

Choices: vähemmän / enemmän / myös / parempi

[[Finnish#^fi-Q0956-answer|Compare the answer]]
^fi-Q0956

**fi-Q0957 · Edit the changed sentence**

Tomi vaikutti 【vähemmän】 yllättyneeltä kuin vihaiselta.

Tom seemed more surprised than angry.

[[Finnish#^fi-Q0957-answer|Compare the answer]]
^fi-Q0957

**fi-Q0958 · Build the sentence**

Arrange: kuin / enemmän / Tomi / vaikutti / yllättyneeltä / vihaiselta.

Tom seemed more surprised than angry.

[[Finnish#^fi-Q0958-answer|Compare the answer]]
^fi-Q0958

**fi-Q0959 · Write a translation**

Write this in Finnish: Which do you prefer, Coke or Pepsi?

[[Finnish#^fi-Q0959-answer|Compare the answer]]
^fi-Q0959

**fi-Q0960 · Explain the grammar**

Kummasta sinä pidät 【enemmän】, Coca-colasta vai Pepsistä?

Which do you prefer, Coke or Pepsi?

[[Finnish#^fi-Q0960-answer|Compare the answer]]
^fi-Q0960

**fi-Q0961 · Fill the gap**

Tom toivoi osaavansa ____ kuin yhtä kieltä.

Tom wished he knew more than one language.

[[Finnish#^fi-Q0961-answer|Compare the answer]]
^fi-Q0961

**fi-Q0962 · Choose the form**

Tom toivoi osaavansa ____ kuin yhtä kieltä.

Tom wished he knew more than one language.

Choices: enemmän / vähemmän / parempi / ehkä

[[Finnish#^fi-Q0962-answer|Compare the answer]]
^fi-Q0962

**fi-Q0963 · Edit the changed sentence**

Ilmeisesti jotkin rupikonnalajit hyötyivät 【vähemmän】 selkäkyhmystä kuin sileästä selästä.

Apparently, in some toad species, to have a protuberance on their backs was more advantages than to have a smooth back.

[[Finnish#^fi-Q0963-answer|Compare the answer]]
^fi-Q0963

**fi-Q0964 · Build the sentence**

Arrange: selästä. / kuin / enemmän / selkäkyhmystä / hyötyivät / rupikonnalajit / jotkin / sileästä / Ilmeisesti

Apparently, in some toad species, to have a protuberance on their backs was more advantages than to have a smooth back.

[[Finnish#^fi-Q0964-answer|Compare the answer]]
^fi-Q0964

**fi-Q0965 · Write a translation**

Write this in Finnish: That costs more than I thought.

[[Finnish#^fi-Q0965-answer|Compare the answer]]
^fi-Q0965

**fi-Q0966 · Explain the grammar**

Se maksaa 【enemmän】 kuin luulin.

That costs more than I thought.

[[Finnish#^fi-Q0966-answer|Compare the answer]]
^fi-Q0966

**fi-Q0967 · Fill the gap**

Hän ei puhu ainoastaan englantia vaan ____ saksaa.

Not only does she speak English, but also German.

[[Finnish#^fi-Q0967-answer|Compare the answer]]
^fi-Q0967

**fi-Q0968 · Choose the form**

Hän ei puhu ainoastaan englantia vaan ____ saksaa.

Not only does she speak English, but also German.

Choices: parempi / myös / enemmän / vähemmän

[[Finnish#^fi-Q0968-answer|Compare the answer]]
^fi-Q0968

**fi-Q0969 · Edit the changed sentence**

Hän ei ole vain ystävällinen vaan 【enemmän】 antelias.

She's not just friendly but also generous.

[[Finnish#^fi-Q0969-answer|Compare the answer]]
^fi-Q0969

**fi-Q0970 · Build the sentence**

Arrange: vaan / ystävällinen / vain / Hän / ei / myös / antelias. / ole

She's not just friendly but also generous.

[[Finnish#^fi-Q0970-answer|Compare the answer]]
^fi-Q0970

**fi-Q0971 · Write a translation**

Write this in Finnish: The surface of a balloon is not an Euclidean space, and therefore does not follow the rules of Euclidean geometry.

[[Finnish#^fi-Q0971-answer|Compare the answer]]
^fi-Q0971

**fi-Q0972 · Explain the grammar**

Ilmapallon pinta ei ole euklidinen avaruus, eikä 【siksi】 noudata euklidisen geometrian sääntöjä.

The surface of a balloon is not an Euclidean space, and therefore does not follow the rules of Euclidean geometry.

[[Finnish#^fi-Q0972-answer|Compare the answer]]
^fi-Q0972

**fi-Q0973 · Fill the gap**

____ hänestä ei tule koskaan kuuluisaa.

Perhaps he'll never become famous.

[[Finnish#^fi-Q0973-answer|Compare the answer]]
^fi-Q0973

**fi-Q0974 · Choose the form**

____ hänestä ei tule koskaan kuuluisaa.

Perhaps he'll never become famous.

Choices: vähemmän / parempi / Ehkä / enemmän

[[Finnish#^fi-Q0974-answer|Compare the answer]]
^fi-Q0974

**fi-Q0975 · Edit the changed sentence**

【enemmän】 se on sinun ongelmasi.

Maybe that's your problem.

[[Finnish#^fi-Q0975-answer|Compare the answer]]
^fi-Q0975

**fi-Q0976 · Build the sentence**

Arrange: Ehkä / sinun / se / ongelmasi. / on

Maybe that's your problem.

[[Finnish#^fi-Q0976-answer|Compare the answer]]
^fi-Q0976

**fi-Q0977 · Write a translation**

Write this in Finnish: Which of these two do you think is better?

[[Finnish#^fi-Q0977-answer|Compare the answer]]
^fi-Q0977

**fi-Q0978 · Explain the grammar**

Minkä näistä kahdesta ajattelet olevan 【parempi】.

Which of these two do you think is better?

[[Finnish#^fi-Q0978-answer|Compare the answer]]
^fi-Q0978

**fi-Q0979 · Fill the gap**

Korkeakoulutuksen suorittaneet tienaavat keskimäärin yli 50 prosenttia ____ kuin vain toisen asteen päättötodistukselliset.

College graduates earn on average over fifty per cent more than those with only a high-school degree.

[[Finnish#^fi-Q0979-answer|Compare the answer]]
^fi-Q0979

**fi-Q0980 · Choose the form**

Korkeakoulutuksen suorittaneet tienaavat keskimäärin yli 50 prosenttia ____ kuin vain toisen asteen päättötodistukselliset.

College graduates earn on average over fifty per cent more than those with only a high-school degree.

Choices: enemmän / ehkä / parempi / vähemmän

[[Finnish#^fi-Q0980-answer|Compare the answer]]
^fi-Q0980

**fi-Q0981 · Edit the changed sentence**

【enemmän】 meidän ei pitäisi mennä sinne.

Maybe we shouldn't go there.

[[Finnish#^fi-Q0981-answer|Compare the answer]]
^fi-Q0981

**fi-Q0982 · Build the sentence**

Arrange: mennä / pitäisi / meidän / ei / sinne. / Ehkä

Maybe we shouldn't go there.

[[Finnish#^fi-Q0982-answer|Compare the answer]]
^fi-Q0982

**fi-Q0983 · Write a translation**

Write this in Finnish: They're not just roommates. They're also lovers.

[[Finnish#^fi-Q0983-answer|Compare the answer]]
^fi-Q0983

**fi-Q0984 · Explain the grammar**

He eivät ole vain kämppiksiä, vaan 【myös】 rakastavaisia.

They're not just roommates. They're also lovers.

[[Finnish#^fi-Q0984-answer|Compare the answer]]
^fi-Q0984

**fi-Q0985 · Fill the gap**

Suuren hadronitörmäyttimen tulokset merkitsevät, että supersymmetriateoreetikoiden on ____ keksittävä uusi alkeishiukkasteoria.

Results from the Large Hadron Collider mean that supersymmetry theorists may have to come up with a new theory of sub-atomic physics.

[[Finnish#^fi-Q0985-answer|Compare the answer]]
^fi-Q0985

**fi-Q0986 · Choose the form**

Suuren hadronitörmäyttimen tulokset merkitsevät, että supersymmetriateoreetikoiden on ____ keksittävä uusi alkeishiukkasteoria.

Results from the Large Hadron Collider mean that supersymmetry theorists may have to come up with a new theory of sub-atomic physics.

Choices: parempi / vähemmän / enemmän / ehkä

[[Finnish#^fi-Q0986-answer|Compare the answer]]
^fi-Q0986

**fi-Q0987 · Edit the changed sentence**

Tomi syö kuin possu ja näyttää semmoiselta 【enemmän】.

Tom eats like a pig and he looks like one, too.

[[Finnish#^fi-Q0987-answer|Compare the answer]]
^fi-Q0987

**fi-Q0988 · Build the sentence**

Arrange: näyttää / semmoiselta / syö / myös. / kuin / ja / Tomi / possu

Tom eats like a pig and he looks like one, too.

[[Finnish#^fi-Q0988-answer|Compare the answer]]
^fi-Q0988

**fi-Q0989 · Write a translation**

Write this in Finnish: Tom knows more about this kind of thing than Mary does.

[[Finnish#^fi-Q0989-answer|Compare the answer]]
^fi-Q0989

**fi-Q0990 · Explain the grammar**

Tom tietää 【enemmän】 tällaisesta asiasta kuin Mari.

Tom knows more about this kind of thing than Mary does.

[[Finnish#^fi-Q0990-answer|Compare the answer]]
^fi-Q0990

**fi-Q0991 · Fill the gap**

Suunnittelen parhaillaan seuraavaa lomaani. Menen ____ Disney landiin perheeni ja ystävieni kanssa. Kuinka paljon minun pitäisi säästää lomaa varten?

I'm planning my next vacation. Maybe I'll go to Disneyland with my family and friends. How much should I save for it?

[[Finnish#^fi-Q0991-answer|Compare the answer]]
^fi-Q0991

**fi-Q0992 · Choose the form**

Suunnittelen parhaillaan seuraavaa lomaani. Menen ____ Disney landiin perheeni ja ystävieni kanssa. Kuinka paljon minun pitäisi säästää lomaa varten?

I'm planning my next vacation. Maybe I'll go to Disneyland with my family and friends. How much should I save for it?

Choices: parempi / vähemmän / ehkä / enemmän

[[Finnish#^fi-Q0992-answer|Compare the answer]]
^fi-Q0992

**fi-Q0993 · Edit the changed sentence**

Kun ihmiset vanhenevat, heidän aivosolunsa tulevat 【enemmän】 tehokkaiksi.

As people get older, their brain cells become less efficient.

[[Finnish#^fi-Q0993-answer|Compare the answer]]
^fi-Q0993

**fi-Q0994 · Build the sentence**

Arrange: heidän / aivosolunsa / Kun / tulevat / ihmiset / vanhenevat, / tehokkaiksi. / vähemmän

As people get older, their brain cells become less efficient.

[[Finnish#^fi-Q0994-answer|Compare the answer]]
^fi-Q0994

**fi-Q0995 · Write a translation**

Write this in Finnish: If we suspect others, others will suspect us just as much.

[[Finnish#^fi-Q0995-answer|Compare the answer]]
^fi-Q0995

**fi-Q0996 · Explain the grammar**

Mitä 【enemmän】 me epäilemme heitä, sitä enemmän he epäilevät meitä.

If we suspect others, others will suspect us just as much.

[[Finnish#^fi-Q0996-answer|Compare the answer]]
^fi-Q0996

**fi-Q0997 · Fill the gap**

Hän on ____ kuin minä.

She's better than me.

[[Finnish#^fi-Q0997-answer|Compare the answer]]
^fi-Q0997

**fi-Q0998 · Choose the form**

Hän on ____ kuin minä.

She's better than me.

Choices: vähemmän / parempi / enemmän / ehkä

[[Finnish#^fi-Q0998-answer|Compare the answer]]
^fi-Q0998

**fi-Q0999 · Edit the changed sentence**

Pidän 【enemmän】 makeisista.

I like candy, too.

[[Finnish#^fi-Q0999-answer|Compare the answer]]
^fi-Q0999

**fi-Q1000 · Build the sentence**

Arrange: makeisista. / Pidän / myös

I like candy, too.

[[Finnish#^fi-Q1000-answer|Compare the answer]]
^fi-Q1000


## Answers

The full sentence is a model. For translation, judge whether meaning and grammar are preserved. Each grammar rule above explains the form.

### Answers 1–50

**fi-Q0001** — He vaativat taistelulle loppua.

They called for an end to the fighting.

Expected form: **He**

Why: Personal pronouns. [[Finnish#^fi-Q0001|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=He%20vaativat%20taistelulle%20loppua.)
^fi-Q0001-answer

**fi-Q0002** — He vaativat taistelulle loppua.

They called for an end to the fighting.

Expected form: **He**

Why: Personal pronouns. [[Finnish#^fi-Q0002|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=He%20vaativat%20taistelulle%20loppua.)
^fi-Q0002-answer

**fi-Q0003** — Minä olen jo rakastunut sinuun.

I'm in love with you already.

Expected form: **Minä**

Why: Personal pronouns. [[Finnish#^fi-Q0003|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Min%C3%A4%20olen%20jo%20rakastunut%20sinuun.)
^fi-Q0003-answer

**fi-Q0004** — Minä olen jo rakastunut sinuun.

I'm in love with you already.

Why: Personal pronouns. [[Finnish#^fi-Q0004|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Min%C3%A4%20olen%20jo%20rakastunut%20sinuun.)
^fi-Q0004-answer

**fi-Q0005** — Minä en ole pingviini.

I am not a penguin.

Why: Personal pronouns. [[Finnish#^fi-Q0005|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Min%C3%A4%20en%20ole%20pingviini.)
^fi-Q0005-answer

**fi-Q0006** — Minä en ole pingviini.

I am not a penguin.

Personal pronouns have distinct case forms. Verb endings often identify first/second person, allowing the pronoun to be omitted. Standard hän refers to a person without encoding male/female gender.

Why: Personal pronouns. [[Finnish#^fi-Q0006|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Min%C3%A4%20en%20ole%20pingviini.)
^fi-Q0006-answer

**fi-Q0007** — Hän on elossa!

She's alive!

Expected form: **Hän**

Why: Personal pronouns. [[Finnish#^fi-Q0007|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=H%C3%A4n%20on%20elossa%21)
^fi-Q0007-answer

**fi-Q0008** — Hän on elossa!

She's alive!

Expected form: **Hän**

Why: Personal pronouns. [[Finnish#^fi-Q0008|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=H%C3%A4n%20on%20elossa%21)
^fi-Q0008-answer

**fi-Q0009** — Et saa koskaan tietää, ellet sinä yritä.

You'll never know unless you try.

Expected form: **sinä**

Why: Personal pronouns. [[Finnish#^fi-Q0009|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Et%20saa%20koskaan%20tiet%C3%A4%C3%A4%2C%20ellet%20sin%C3%A4%20yrit%C3%A4.)
^fi-Q0009-answer

**fi-Q0010** — Et saa koskaan tietää, ellet sinä yritä.

You'll never know unless you try.

Why: Personal pronouns. [[Finnish#^fi-Q0010|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Et%20saa%20koskaan%20tiet%C3%A4%C3%A4%2C%20ellet%20sin%C3%A4%20yrit%C3%A4.)
^fi-Q0010-answer

**fi-Q0011** — Hän on huonolla tuulella.

He is in a bad mood.

Why: Personal pronouns. [[Finnish#^fi-Q0011|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=H%C3%A4n%20on%20huonolla%20tuulella.)
^fi-Q0011-answer

**fi-Q0012** — Hän on huonolla tuulella.

He is in a bad mood.

Personal pronouns have distinct case forms. Verb endings often identify first/second person, allowing the pronoun to be omitted. Standard hän refers to a person without encoding male/female gender.

Why: Personal pronouns. [[Finnish#^fi-Q0012|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=H%C3%A4n%20on%20huonolla%20tuulella.)
^fi-Q0012-answer

**fi-Q0013** — En minä tiedä, että pystynkö minä siihen, mutta minä yritän.

I don't know whether I can do it, but I'll try.

Expected form: **minä**

Why: Personal pronouns. [[Finnish#^fi-Q0013|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=En%20min%C3%A4%20tied%C3%A4%2C%20ett%C3%A4%20pystynk%C3%B6%20min%C3%A4%20siihen%2C%20mutta%20min%C3%A4%20yrit%C3%A4n.)
^fi-Q0013-answer

**fi-Q0014** — En minä tiedä, että pystynkö minä siihen, mutta minä yritän.

I don't know whether I can do it, but I'll try.

Expected form: **minä**

Why: Personal pronouns. [[Finnish#^fi-Q0014|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=En%20min%C3%A4%20tied%C3%A4%2C%20ett%C3%A4%20pystynk%C3%B6%20min%C3%A4%20siihen%2C%20mutta%20min%C3%A4%20yrit%C3%A4n.)
^fi-Q0014-answer

**fi-Q0015** — Minä en ole koskaan käynyt Amerikassa.

I have never been to America.

Expected form: **Minä**

Why: Personal pronouns. [[Finnish#^fi-Q0015|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Min%C3%A4%20en%20ole%20koskaan%20k%C3%A4ynyt%20Amerikassa.)
^fi-Q0015-answer

**fi-Q0016** — Minä en ole koskaan käynyt Amerikassa.

I have never been to America.

Why: Personal pronouns. [[Finnish#^fi-Q0016|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Min%C3%A4%20en%20ole%20koskaan%20k%C3%A4ynyt%20Amerikassa.)
^fi-Q0016-answer

**fi-Q0017** — Sinä et ole syönyt mitään.

You haven't eaten anything.

Why: Personal pronouns. [[Finnish#^fi-Q0017|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Sin%C3%A4%20et%20ole%20sy%C3%B6nyt%20mit%C3%A4%C3%A4n.)
^fi-Q0017-answer

**fi-Q0018** — Sinä et ole syönyt mitään.

You haven't eaten anything.

Personal pronouns have distinct case forms. Verb endings often identify first/second person, allowing the pronoun to be omitted. Standard hän refers to a person without encoding male/female gender.

Why: Personal pronouns. [[Finnish#^fi-Q0018|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Sin%C3%A4%20et%20ole%20sy%C3%B6nyt%20mit%C3%A4%C3%A4n.)
^fi-Q0018-answer

**fi-Q0019** — Me voimme tehdä sen.

We can do that.

Expected form: **Me**

Why: Personal pronouns. [[Finnish#^fi-Q0019|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Me%20voimme%20tehd%C3%A4%20sen.)
^fi-Q0019-answer

**fi-Q0020** — Me voimme tehdä sen.

We can do that.

Expected form: **Me**

Why: Personal pronouns. [[Finnish#^fi-Q0020|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Me%20voimme%20tehd%C3%A4%20sen.)
^fi-Q0020-answer

**fi-Q0021** — Vaikka hän onkin rikas, ei hän ole onnellinen.

Rich as she is, she is not happy.

Expected form: **hän**

Why: Personal pronouns. [[Finnish#^fi-Q0021|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Vaikka%20h%C3%A4n%20onkin%20rikas%2C%20ei%20h%C3%A4n%20ole%20onnellinen.)
^fi-Q0021-answer

**fi-Q0022** — Vaikka hän onkin rikas, ei hän ole onnellinen.

Rich as she is, she is not happy.

Why: Personal pronouns. [[Finnish#^fi-Q0022|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Vaikka%20h%C3%A4n%20onkin%20rikas%2C%20ei%20h%C3%A4n%20ole%20onnellinen.)
^fi-Q0022-answer

**fi-Q0023** — Me ollaan muututtu.

We have changed.

Why: Personal pronouns. [[Finnish#^fi-Q0023|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Me%20ollaan%20muututtu.)
^fi-Q0023-answer

**fi-Q0024** — Me ollaan muututtu.

We have changed.

Personal pronouns have distinct case forms. Verb endings often identify first/second person, allowing the pronoun to be omitted. Standard hän refers to a person without encoding male/female gender.

Why: Personal pronouns. [[Finnish#^fi-Q0024|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Me%20ollaan%20muututtu.)
^fi-Q0024-answer

**fi-Q0025** — Hän kietoi kätensä hänen kaulaansa.

She wrapped her arms around his neck.

Expected form: **Hän**

Why: Personal pronouns. [[Finnish#^fi-Q0025|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=H%C3%A4n%20kietoi%20k%C3%A4tens%C3%A4%20h%C3%A4nen%20kaulaansa.)
^fi-Q0025-answer

**fi-Q0026** — Hän kietoi kätensä hänen kaulaansa.

She wrapped her arms around his neck.

Expected form: **Hän**

Why: Personal pronouns. [[Finnish#^fi-Q0026|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=H%C3%A4n%20kietoi%20k%C3%A4tens%C3%A4%20h%C3%A4nen%20kaulaansa.)
^fi-Q0026-answer

**fi-Q0027** — Sinne korkean vuoren huipulle rakensivat he itselleen pienen kaupungin ja elivät rauhassa.

There on the top of a high mountain they built a small town of their own and lived in peace.

Expected form: **he**

Why: Personal pronouns. [[Finnish#^fi-Q0027|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Sinne%20korkean%20vuoren%20huipulle%20rakensivat%20he%20itselleen%20pienen%20kaupungin%20ja%20eliv%C3%A4t%20rauhassa.)
^fi-Q0027-answer

**fi-Q0028** — Sinne korkean vuoren huipulle rakensivat he itselleen pienen kaupungin ja elivät rauhassa.

There on the top of a high mountain they built a small town of their own and lived in peace.

Why: Personal pronouns. [[Finnish#^fi-Q0028|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Sinne%20korkean%20vuoren%20huipulle%20rakensivat%20he%20itselleen%20pienen%20kaupungin%20ja%20eliv%C3%A4t%20rauhassa.)
^fi-Q0028-answer

**fi-Q0029** — Minä luin sen kirjan.

I read the book.

Why: Personal pronouns. [[Finnish#^fi-Q0029|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Min%C3%A4%20luin%20sen%20kirjan.)
^fi-Q0029-answer

**fi-Q0030** — Minä luin sen kirjan.

I read the book.

Personal pronouns have distinct case forms. Verb endings often identify first/second person, allowing the pronoun to be omitted. Standard hän refers to a person without encoding male/female gender.

Why: Personal pronouns. [[Finnish#^fi-Q0030|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Min%C3%A4%20luin%20sen%20kirjan.)
^fi-Q0030-answer

**fi-Q0031** — Tomi sanoo, että hän käy lenkillä vähintään kolme kertaa viikossa.

Tom says he goes jogging at least three times a week.

Expected form: **hän**

Why: Personal pronouns. [[Finnish#^fi-Q0031|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tomi%20sanoo%2C%20ett%C3%A4%20h%C3%A4n%20k%C3%A4y%20lenkill%C3%A4%20v%C3%A4hint%C3%A4%C3%A4n%20kolme%20kertaa%20viikossa.)
^fi-Q0031-answer

**fi-Q0032** — Tomi sanoo, että hän käy lenkillä vähintään kolme kertaa viikossa.

Tom says he goes jogging at least three times a week.

Expected form: **hän**

Why: Personal pronouns. [[Finnish#^fi-Q0032|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tomi%20sanoo%2C%20ett%C3%A4%20h%C3%A4n%20k%C3%A4y%20lenkill%C3%A4%20v%C3%A4hint%C3%A4%C3%A4n%20kolme%20kertaa%20viikossa.)
^fi-Q0032-answer

**fi-Q0033** — Sopiiko, että minä istun tähän?

May I sit here?

Expected form: **minä**

Why: Personal pronouns. [[Finnish#^fi-Q0033|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Sopiiko%2C%20ett%C3%A4%20min%C3%A4%20istun%20t%C3%A4h%C3%A4n%3F)
^fi-Q0033-answer

**fi-Q0034** — Sopiiko, että minä istun tähän?

May I sit here?

Why: Personal pronouns. [[Finnish#^fi-Q0034|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Sopiiko%2C%20ett%C3%A4%20min%C3%A4%20istun%20t%C3%A4h%C3%A4n%3F)
^fi-Q0034-answer

**fi-Q0035** — Hän ei ole mikään pyhimys.

She is no saint.

Why: Personal pronouns. [[Finnish#^fi-Q0035|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=H%C3%A4n%20ei%20ole%20mik%C3%A4%C3%A4n%20pyhimys.)
^fi-Q0035-answer

**fi-Q0036** — Hän ei ole mikään pyhimys.

She is no saint.

Personal pronouns have distinct case forms. Verb endings often identify first/second person, allowing the pronoun to be omitted. Standard hän refers to a person without encoding male/female gender.

Why: Personal pronouns. [[Finnish#^fi-Q0036|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=H%C3%A4n%20ei%20ole%20mik%C3%A4%C3%A4n%20pyhimys.)
^fi-Q0036-answer

**fi-Q0037** — No, mitä minä teen?

So what do I do?

Expected form: **minä**

Why: Personal pronouns. [[Finnish#^fi-Q0037|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=No%2C%20mit%C3%A4%20min%C3%A4%20teen%3F)
^fi-Q0037-answer

**fi-Q0038** — No, mitä minä teen?

So what do I do?

Expected form: **minä**

Why: Personal pronouns. [[Finnish#^fi-Q0038|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=No%2C%20mit%C3%A4%20min%C3%A4%20teen%3F)
^fi-Q0038-answer

**fi-Q0039** — He saattoivat odottaa kymmenen vuoden vankilatuomiota.

They could face a ten-year prison term.

Expected form: **He**

Why: Personal pronouns. [[Finnish#^fi-Q0039|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=He%20saattoivat%20odottaa%20kymmenen%20vuoden%20vankilatuomiota.)
^fi-Q0039-answer

**fi-Q0040** — He saattoivat odottaa kymmenen vuoden vankilatuomiota.

They could face a ten-year prison term.

Why: Personal pronouns. [[Finnish#^fi-Q0040|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=He%20saattoivat%20odottaa%20kymmenen%20vuoden%20vankilatuomiota.)
^fi-Q0040-answer

**fi-Q0041** — Ja taas hän oli niin humalassa kuin vain voi olla.

And again he was drunk as anything.

Why: Personal pronouns. [[Finnish#^fi-Q0041|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Ja%20taas%20h%C3%A4n%20oli%20niin%20humalassa%20kuin%20vain%20voi%20olla.)
^fi-Q0041-answer

**fi-Q0042** — Ja taas hän oli niin humalassa kuin vain voi olla.

And again he was drunk as anything.

Personal pronouns have distinct case forms. Verb endings often identify first/second person, allowing the pronoun to be omitted. Standard hän refers to a person without encoding male/female gender.

Why: Personal pronouns. [[Finnish#^fi-Q0042|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Ja%20taas%20h%C3%A4n%20oli%20niin%20humalassa%20kuin%20vain%20voi%20olla.)
^fi-Q0042-answer

**fi-Q0043** — Hän ei tiennyt naineensa hirviön.

She didn't know she had married a monster.

Expected form: **Hän**

Why: Personal pronouns. [[Finnish#^fi-Q0043|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=H%C3%A4n%20ei%20tiennyt%20naineensa%20hirvi%C3%B6n.)
^fi-Q0043-answer

**fi-Q0044** — Hän ei tiennyt naineensa hirviön.

She didn't know she had married a monster.

Expected form: **Hän**

Why: Personal pronouns. [[Finnish#^fi-Q0044|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=H%C3%A4n%20ei%20tiennyt%20naineensa%20hirvi%C3%B6n.)
^fi-Q0044-answer

**fi-Q0045** — Hän lupasi tulla, mutta ei tullut.

He promised to come, but he didn't come.

Expected form: **Hän**

Why: Personal pronouns. [[Finnish#^fi-Q0045|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=H%C3%A4n%20lupasi%20tulla%2C%20mutta%20ei%20tullut.)
^fi-Q0045-answer

**fi-Q0046** — Hän lupasi tulla, mutta ei tullut.

He promised to come, but he didn't come.

Why: Personal pronouns. [[Finnish#^fi-Q0046|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=H%C3%A4n%20lupasi%20tulla%2C%20mutta%20ei%20tullut.)
^fi-Q0046-answer

**fi-Q0047** — Tom ei tosiaankaan ollut kotona, kun me menimme käymään hänen luonaan.

Tom certainly wasn't at home when we went to visit him.

Why: Personal pronouns. [[Finnish#^fi-Q0047|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tom%20ei%20tosiaankaan%20ollut%20kotona%2C%20kun%20me%20menimme%20k%C3%A4ym%C3%A4%C3%A4n%20h%C3%A4nen%20luonaan.)
^fi-Q0047-answer

**fi-Q0048** — Tom ei tosiaankaan ollut kotona, kun me menimme käymään hänen luonaan.

Tom certainly wasn't at home when we went to visit him.

Personal pronouns have distinct case forms. Verb endings often identify first/second person, allowing the pronoun to be omitted. Standard hän refers to a person without encoding male/female gender.

Why: Personal pronouns. [[Finnish#^fi-Q0048|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tom%20ei%20tosiaankaan%20ollut%20kotona%2C%20kun%20me%20menimme%20k%C3%A4ym%C3%A4%C3%A4n%20h%C3%A4nen%20luonaan.)
^fi-Q0048-answer

**fi-Q0049** — Sinä et ole tappaja enkä ole minäkään.

You're not a killer and neither am I.

Expected form: **Sinä**

Why: Personal pronouns. [[Finnish#^fi-Q0049|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Sin%C3%A4%20et%20ole%20tappaja%20enk%C3%A4%20ole%20min%C3%A4k%C3%A4%C3%A4n.)
^fi-Q0049-answer

**fi-Q0050** — Sinä et ole tappaja enkä ole minäkään.

You're not a killer and neither am I.

Expected form: **Sinä**

Why: Personal pronouns. [[Finnish#^fi-Q0050|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Sin%C3%A4%20et%20ole%20tappaja%20enk%C3%A4%20ole%20min%C3%A4k%C3%A4%C3%A4n.)
^fi-Q0050-answer


### Answers 51–100

**fi-Q0051** — Kahden kauppa on kolmannen korvapuusti.

When two people quarrel, a third rejoices.

Expected form: **on**

Why: Present olla. [[Finnish#^fi-Q0051|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Kahden%20kauppa%20on%20kolmannen%20korvapuusti.)
^fi-Q0051-answer

**fi-Q0052** — Kahden kauppa on kolmannen korvapuusti.

When two people quarrel, a third rejoices.

Why: Present olla. [[Finnish#^fi-Q0052|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Kahden%20kauppa%20on%20kolmannen%20korvapuusti.)
^fi-Q0052-answer

**fi-Q0053** — Tomi on äreä.

Tom is grumpy.

Why: Present olla. [[Finnish#^fi-Q0053|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tomi%20on%20%C3%A4re%C3%A4.)
^fi-Q0053-answer

**fi-Q0054** — Tomi on äreä.

Tom is grumpy.

Olla agrees with the subject: olen, olet, on, olemme, olette, ovat. On is also used in many existential or possessive constructions whose syntax differs from a simple subject predicate.

Why: Present olla. [[Finnish#^fi-Q0054|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tomi%20on%20%C3%A4re%C3%A4.)
^fi-Q0054-answer

**fi-Q0055** — Tomin operoinut kirurgi on hyvin kokenut ja erittäin arvostettu.

The surgeon who did Tom's operation is very experienced and highly regarded.

Expected form: **on**

Why: Present olla. [[Finnish#^fi-Q0055|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tomin%20operoinut%20kirurgi%20on%20hyvin%20kokenut%20ja%20eritt%C3%A4in%20arvostettu.)
^fi-Q0055-answer

**fi-Q0056** — Tomin operoinut kirurgi on hyvin kokenut ja erittäin arvostettu.

The surgeon who did Tom's operation is very experienced and highly regarded.

Expected form: **on**

Why: Present olla. [[Finnish#^fi-Q0056|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tomin%20operoinut%20kirurgi%20on%20hyvin%20kokenut%20ja%20eritt%C3%A4in%20arvostettu.)
^fi-Q0056-answer

**fi-Q0057** — ”Minua ei huvita juoda tänään.” ”Älä viitsi, nyt on syntymäpäiväni.”

"I don't feel like drinking today." "Come on, it's my birthday!"

Expected form: **on**

Why: Present olla. [[Finnish#^fi-Q0057|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=%E2%80%9DMinua%20ei%20huvita%20juoda%20t%C3%A4n%C3%A4%C3%A4n.%E2%80%9D%20%E2%80%9D%C3%84l%C3%A4%20viitsi%2C%20nyt%20on%20syntym%C3%A4p%C3%A4iv%C3%A4ni.%E2%80%9D)
^fi-Q0057-answer

**fi-Q0058** — ”Minua ei huvita juoda tänään.” ”Älä viitsi, nyt on syntymäpäiväni.”

"I don't feel like drinking today." "Come on, it's my birthday!"

Why: Present olla. [[Finnish#^fi-Q0058|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=%E2%80%9DMinua%20ei%20huvita%20juoda%20t%C3%A4n%C3%A4%C3%A4n.%E2%80%9D%20%E2%80%9D%C3%84l%C3%A4%20viitsi%2C%20nyt%20on%20syntym%C3%A4p%C3%A4iv%C3%A4ni.%E2%80%9D)
^fi-Q0058-answer

**fi-Q0059** — Tomi on kauhistunut.

Tom's terrified.

Why: Present olla. [[Finnish#^fi-Q0059|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tomi%20on%20kauhistunut.)
^fi-Q0059-answer

**fi-Q0060** — Tomi on kauhistunut.

Tom's terrified.

Olla agrees with the subject: olen, olet, on, olemme, olette, ovat. On is also used in many existential or possessive constructions whose syntax differs from a simple subject predicate.

Why: Present olla. [[Finnish#^fi-Q0060|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tomi%20on%20kauhistunut.)
^fi-Q0060-answer

**fi-Q0061** — Vaikuttaa siltä, että olet humalassa.

You seem to be drunk.

Expected form: **olet**

Why: Present olla. [[Finnish#^fi-Q0061|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Vaikuttaa%20silt%C3%A4%2C%20ett%C3%A4%20olet%20humalassa.)
^fi-Q0061-answer

**fi-Q0062** — Vaikuttaa siltä, että olet humalassa.

You seem to be drunk.

Expected form: **olet**

Why: Present olla. [[Finnish#^fi-Q0062|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Vaikuttaa%20silt%C3%A4%2C%20ett%C3%A4%20olet%20humalassa.)
^fi-Q0062-answer

**fi-Q0063** — Tomilla on lounastapaaminen Maryn kanssa.

Tom has a lunch date with Mary.

Expected form: **on**

Why: Present olla. [[Finnish#^fi-Q0063|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tomilla%20on%20lounastapaaminen%20Maryn%20kanssa.)
^fi-Q0063-answer

**fi-Q0064** — Tomilla on lounastapaaminen Maryn kanssa.

Tom has a lunch date with Mary.

Why: Present olla. [[Finnish#^fi-Q0064|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tomilla%20on%20lounastapaaminen%20Maryn%20kanssa.)
^fi-Q0064-answer

**fi-Q0065** — Tomi on liikkunut pois.

Tom has moved away.

Why: Present olla. [[Finnish#^fi-Q0065|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tomi%20on%20liikkunut%20pois.)
^fi-Q0065-answer

**fi-Q0066** — Tomi on liikkunut pois.

Tom has moved away.

Olla agrees with the subject: olen, olet, on, olemme, olette, ovat. On is also used in many existential or possessive constructions whose syntax differs from a simple subject predicate.

Why: Present olla. [[Finnish#^fi-Q0066|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tomi%20on%20liikkunut%20pois.)
^fi-Q0066-answer

**fi-Q0067** — Olen eri mieltä.

I don't agree.

Expected form: **Olen**

Why: Present olla. [[Finnish#^fi-Q0067|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Olen%20eri%20mielt%C3%A4.)
^fi-Q0067-answer

**fi-Q0068** — Olen eri mieltä.

I don't agree.

Expected form: **Olen**

Why: Present olla. [[Finnish#^fi-Q0068|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Olen%20eri%20mielt%C3%A4.)
^fi-Q0068-answer

**fi-Q0069** — Kakun leikkaaminen samankokoisiin paloihin on aika vaikeaa.

Cutting a cake into equal pieces is rather difficult.

Expected form: **on**

Why: Present olla. [[Finnish#^fi-Q0069|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Kakun%20leikkaaminen%20samankokoisiin%20paloihin%20on%20aika%20vaikeaa.)
^fi-Q0069-answer

**fi-Q0070** — Kakun leikkaaminen samankokoisiin paloihin on aika vaikeaa.

Cutting a cake into equal pieces is rather difficult.

Why: Present olla. [[Finnish#^fi-Q0070|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Kakun%20leikkaaminen%20samankokoisiin%20paloihin%20on%20aika%20vaikeaa.)
^fi-Q0070-answer

**fi-Q0071** — Jätkät on hulluja!

You guys are insane!

Why: Present olla. [[Finnish#^fi-Q0071|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=J%C3%A4tk%C3%A4t%20on%20hulluja%21)
^fi-Q0071-answer

**fi-Q0072** — Jätkät on hulluja!

You guys are insane!

Olla agrees with the subject: olen, olet, on, olemme, olette, ovat. On is also used in many existential or possessive constructions whose syntax differs from a simple subject predicate.

Why: Present olla. [[Finnish#^fi-Q0072|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=J%C3%A4tk%C3%A4t%20on%20hulluja%21)
^fi-Q0072-answer

**fi-Q0073** — Mulla on tatska.

I have a tattoo.

Expected form: **on**

Why: Present olla. [[Finnish#^fi-Q0073|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Mulla%20on%20tatska.)
^fi-Q0073-answer

**fi-Q0074** — Mulla on tatska.

I have a tattoo.

Expected form: **on**

Why: Present olla. [[Finnish#^fi-Q0074|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Mulla%20on%20tatska.)
^fi-Q0074-answer

**fi-Q0075** — Hei, sun on pakko nähdä tää.

Hey, you've got to see this.

Expected form: **on**

Why: Present olla. [[Finnish#^fi-Q0075|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Hei%2C%20sun%20on%20pakko%20n%C3%A4hd%C3%A4%20t%C3%A4%C3%A4.)
^fi-Q0075-answer

**fi-Q0076** — Hei, sun on pakko nähdä tää.

Hey, you've got to see this.

Why: Present olla. [[Finnish#^fi-Q0076|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Hei%2C%20sun%20on%20pakko%20n%C3%A4hd%C3%A4%20t%C3%A4%C3%A4.)
^fi-Q0076-answer

**fi-Q0077** — Vesi on neste.

Water is a liquid.

Why: Present olla. [[Finnish#^fi-Q0077|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Vesi%20on%20neste.)
^fi-Q0077-answer

**fi-Q0078** — Vesi on neste.

Water is a liquid.

Olla agrees with the subject: olen, olet, on, olemme, olette, ovat. On is also used in many existential or possessive constructions whose syntax differs from a simple subject predicate.

Why: Present olla. [[Finnish#^fi-Q0078|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Vesi%20on%20neste.)
^fi-Q0078-answer

**fi-Q0079** — Maailmassa on noin 1 800 miljardööriä.

There are about 1,800 billionaires in the world.

Expected form: **on**

Why: Present olla. [[Finnish#^fi-Q0079|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Maailmassa%20on%20noin%201%20800%20miljard%C3%B6%C3%B6ri%C3%A4.)
^fi-Q0079-answer

**fi-Q0080** — Maailmassa on noin 1 800 miljardööriä.

There are about 1,800 billionaires in the world.

Expected form: **on**

Why: Present olla. [[Finnish#^fi-Q0080|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Maailmassa%20on%20noin%201%20800%20miljard%C3%B6%C3%B6ri%C3%A4.)
^fi-Q0080-answer

**fi-Q0081** — Tyttäreni on vain lapsi.

My daughter is but a child.

Expected form: **on**

Why: Present olla. [[Finnish#^fi-Q0081|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tytt%C3%A4reni%20on%20vain%20lapsi.)
^fi-Q0081-answer

**fi-Q0082** — Tyttäreni on vain lapsi.

My daughter is but a child.

Why: Present olla. [[Finnish#^fi-Q0082|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tytt%C3%A4reni%20on%20vain%20lapsi.)
^fi-Q0082-answer

**fi-Q0083** — Tässä maailmassa on joitain sellaisia asioita, jotka eivät tule ikinä toteen, ei vaikka kuinka toivoisit niitä.

There are some things in this world that will never come true, no matter how much you wish for them.

Why: Present olla. [[Finnish#^fi-Q0083|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=T%C3%A4ss%C3%A4%20maailmassa%20on%20joitain%20sellaisia%20asioita%2C%20jotka%20eiv%C3%A4t%20tule%20ikin%C3%A4%20toteen%2C%20ei%20vaikka%20kuinka%20toivoisit%20niit%C3%A4.)
^fi-Q0083-answer

**fi-Q0084** — Tässä maailmassa on joitain sellaisia asioita, jotka eivät tule ikinä toteen, ei vaikka kuinka toivoisit niitä.

There are some things in this world that will never come true, no matter how much you wish for them.

Olla agrees with the subject: olen, olet, on, olemme, olette, ovat. On is also used in many existential or possessive constructions whose syntax differs from a simple subject predicate.

Why: Present olla. [[Finnish#^fi-Q0084|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=T%C3%A4ss%C3%A4%20maailmassa%20on%20joitain%20sellaisia%20asioita%2C%20jotka%20eiv%C3%A4t%20tule%20ikin%C3%A4%20toteen%2C%20ei%20vaikka%20kuinka%20toivoisit%20niit%C3%A4.)
^fi-Q0084-answer

**fi-Q0085** — Minun nimeni on Henry.

My name is Henry.

Expected form: **on**

Why: Present olla. [[Finnish#^fi-Q0085|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Minun%20nimeni%20on%20Henry.)
^fi-Q0085-answer

**fi-Q0086** — Minun nimeni on Henry.

My name is Henry.

Expected form: **on**

Why: Present olla. [[Finnish#^fi-Q0086|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Minun%20nimeni%20on%20Henry.)
^fi-Q0086-answer

**fi-Q0087** — Myönnän, että olen väärässä.

I'll admit I'm wrong.

Expected form: **olen**

Why: Present olla. [[Finnish#^fi-Q0087|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=My%C3%B6nn%C3%A4n%2C%20ett%C3%A4%20olen%20v%C3%A4%C3%A4r%C3%A4ss%C3%A4.)
^fi-Q0087-answer

**fi-Q0088** — Myönnän, että olen väärässä.

I'll admit I'm wrong.

Why: Present olla. [[Finnish#^fi-Q0088|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=My%C3%B6nn%C3%A4n%2C%20ett%C3%A4%20olen%20v%C3%A4%C3%A4r%C3%A4ss%C3%A4.)
^fi-Q0088-answer

**fi-Q0089** — Olen saanut tarpeekseni sarkastisista huomautuksistasi.

I've had enough of your snide remarks.

Why: Present olla. [[Finnish#^fi-Q0089|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Olen%20saanut%20tarpeekseni%20sarkastisista%20huomautuksistasi.)
^fi-Q0089-answer

**fi-Q0090** — Olen saanut tarpeekseni sarkastisista huomautuksistasi.

I've had enough of your snide remarks.

Olla agrees with the subject: olen, olet, on, olemme, olette, ovat. On is also used in many existential or possessive constructions whose syntax differs from a simple subject predicate.

Why: Present olla. [[Finnish#^fi-Q0090|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Olen%20saanut%20tarpeekseni%20sarkastisista%20huomautuksistasi.)
^fi-Q0090-answer

**fi-Q0091** — Naistenhuone on kolmannessa kerroksessa.

The ladies' room is on the third floor.

Expected form: **on**

Why: Present olla. [[Finnish#^fi-Q0091|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Naistenhuone%20on%20kolmannessa%20kerroksessa.)
^fi-Q0091-answer

**fi-Q0092** — Naistenhuone on kolmannessa kerroksessa.

The ladies' room is on the third floor.

Expected form: **on**

Why: Present olla. [[Finnish#^fi-Q0092|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Naistenhuone%20on%20kolmannessa%20kerroksessa.)
^fi-Q0092-answer

**fi-Q0093** — Se tuote on loppu varastosta.

That article is out of stock.

Expected form: **on**

Why: Present olla. [[Finnish#^fi-Q0093|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Se%20tuote%20on%20loppu%20varastosta.)
^fi-Q0093-answer

**fi-Q0094** — Se tuote on loppu varastosta.

That article is out of stock.

Why: Present olla. [[Finnish#^fi-Q0094|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Se%20tuote%20on%20loppu%20varastosta.)
^fi-Q0094-answer

**fi-Q0095** — Olen pahoillani eilisestä.

I'm sorry about yesterday.

Why: Present olla. [[Finnish#^fi-Q0095|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Olen%20pahoillani%20eilisest%C3%A4.)
^fi-Q0095-answer

**fi-Q0096** — Olen pahoillani eilisestä.

I'm sorry about yesterday.

Olla agrees with the subject: olen, olet, on, olemme, olette, ovat. On is also used in many existential or possessive constructions whose syntax differs from a simple subject predicate.

Why: Present olla. [[Finnish#^fi-Q0096|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Olen%20pahoillani%20eilisest%C3%A4.)
^fi-Q0096-answer

**fi-Q0097** — Kolme kolmanteen on kaksikymmentäseitsemän.

3 to the third power is 27.

Expected form: **on**

Why: Present olla. [[Finnish#^fi-Q0097|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Kolme%20kolmanteen%20on%20kaksikymment%C3%A4seitsem%C3%A4n.)
^fi-Q0097-answer

**fi-Q0098** — Kolme kolmanteen on kaksikymmentäseitsemän.

3 to the third power is 27.

Expected form: **on**

Why: Present olla. [[Finnish#^fi-Q0098|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Kolme%20kolmanteen%20on%20kaksikymment%C3%A4seitsem%C3%A4n.)
^fi-Q0098-answer

**fi-Q0099** — Sinun seurassasi on mukavaa olla.

You're fun to hang out with.

Expected form: **on**

Why: Present olla. [[Finnish#^fi-Q0099|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Sinun%20seurassasi%20on%20mukavaa%20olla.)
^fi-Q0099-answer

**fi-Q0100** — Sinun seurassasi on mukavaa olla.

You're fun to hang out with.

Why: Present olla. [[Finnish#^fi-Q0100|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Sinun%20seurassasi%20on%20mukavaa%20olla.)
^fi-Q0100-answer


### Answers 101–150

**fi-Q0101** — Vannoin, että en puhuisi enää ikinä hänelle.

I vowed that I would never speak to her again.

Why: The negative verb. [[Finnish#^fi-Q0101|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Vannoin%2C%20ett%C3%A4%20en%20puhuisi%20en%C3%A4%C3%A4%20ikin%C3%A4%20h%C3%A4nelle.)
^fi-Q0101-answer

**fi-Q0102** — Vannoin, että en puhuisi enää ikinä hänelle.

I vowed that I would never speak to her again.

Finnish negation conjugates the negative auxiliary for person and number. The ordinary lexical verb appears in a connegative form: en puhu, et puhu, ei puhu.

Why: The negative verb. [[Finnish#^fi-Q0102|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Vannoin%2C%20ett%C3%A4%20en%20puhuisi%20en%C3%A4%C3%A4%20ikin%C3%A4%20h%C3%A4nelle.)
^fi-Q0102-answer

**fi-Q0103** — Miksi et ole vielä valmistanut illallista?

Why haven't you cooked dinner yet?

Expected form: **et**

Why: The negative verb. [[Finnish#^fi-Q0103|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Miksi%20et%20ole%20viel%C3%A4%20valmistanut%20illallista%3F)
^fi-Q0103-answer

**fi-Q0104** — Miksi et ole vielä valmistanut illallista?

Why haven't you cooked dinner yet?

Expected form: **et**

Why: The negative verb. [[Finnish#^fi-Q0104|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Miksi%20et%20ole%20viel%C3%A4%20valmistanut%20illallista%3F)
^fi-Q0104-answer

**fi-Q0105** — En halua mennä naimisiin liian aikaisin.

I don't want to get married too early.

Expected form: **En**

Why: The negative verb. [[Finnish#^fi-Q0105|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=En%20halua%20menn%C3%A4%20naimisiin%20liian%20aikaisin.)
^fi-Q0105-answer

**fi-Q0106** — En halua mennä naimisiin liian aikaisin.

I don't want to get married too early.

Why: The negative verb. [[Finnish#^fi-Q0106|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=En%20halua%20menn%C3%A4%20naimisiin%20liian%20aikaisin.)
^fi-Q0106-answer

**fi-Q0107** — En anna sen vaivata minua.

I won't let that bother me.

Why: The negative verb. [[Finnish#^fi-Q0107|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=En%20anna%20sen%20vaivata%20minua.)
^fi-Q0107-answer

**fi-Q0108** — En anna sen vaivata minua.

I won't let that bother me.

Finnish negation conjugates the negative auxiliary for person and number. The ordinary lexical verb appears in a connegative form: en puhu, et puhu, ei puhu.

Why: The negative verb. [[Finnish#^fi-Q0108|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=En%20anna%20sen%20vaivata%20minua.)
^fi-Q0108-answer

**fi-Q0109** — Kielen oppiminen ei koskaan lopu.

Language learning never ends.

Expected form: **ei**

Why: The negative verb. [[Finnish#^fi-Q0109|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Kielen%20oppiminen%20ei%20koskaan%20lopu.)
^fi-Q0109-answer

**fi-Q0110** — Kielen oppiminen ei koskaan lopu.

Language learning never ends.

Expected form: **ei**

Why: The negative verb. [[Finnish#^fi-Q0110|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Kielen%20oppiminen%20ei%20koskaan%20lopu.)
^fi-Q0110-answer

**fi-Q0111** — En nyt menisi ihan niin pitkälle, että kutsuisin Suomea paratiisiksi.

I would not go so far as to call Finland a paradise.

Expected form: **En**

Why: The negative verb. [[Finnish#^fi-Q0111|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=En%20nyt%20menisi%20ihan%20niin%20pitk%C3%A4lle%2C%20ett%C3%A4%20kutsuisin%20Suomea%20paratiisiksi.)
^fi-Q0111-answer

**fi-Q0112** — En nyt menisi ihan niin pitkälle, että kutsuisin Suomea paratiisiksi.

I would not go so far as to call Finland a paradise.

Why: The negative verb. [[Finnish#^fi-Q0112|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=En%20nyt%20menisi%20ihan%20niin%20pitk%C3%A4lle%2C%20ett%C3%A4%20kutsuisin%20Suomea%20paratiisiksi.)
^fi-Q0112-answer

**fi-Q0113** — Ei ole puutetta ehdokkaista.

There's no shortage of candidates.

Why: The negative verb. [[Finnish#^fi-Q0113|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Ei%20ole%20puutetta%20ehdokkaista.)
^fi-Q0113-answer

**fi-Q0114** — Ei ole puutetta ehdokkaista.

There's no shortage of candidates.

Finnish negation conjugates the negative auxiliary for person and number. The ordinary lexical verb appears in a connegative form: en puhu, et puhu, ei puhu.

Why: The negative verb. [[Finnish#^fi-Q0114|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Ei%20ole%20puutetta%20ehdokkaista.)
^fi-Q0114-answer

**fi-Q0115** — Ihmisten ei pitäisi rääkätä eläimiä.

People shouldn't abuse animals.

Expected form: **ei**

Why: The negative verb. [[Finnish#^fi-Q0115|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Ihmisten%20ei%20pit%C3%A4isi%20r%C3%A4%C3%A4k%C3%A4t%C3%A4%20el%C3%A4imi%C3%A4.)
^fi-Q0115-answer

**fi-Q0116** — Ihmisten ei pitäisi rääkätä eläimiä.

People shouldn't abuse animals.

Expected form: **ei**

Why: The negative verb. [[Finnish#^fi-Q0116|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Ihmisten%20ei%20pit%C3%A4isi%20r%C3%A4%C3%A4k%C3%A4t%C3%A4%20el%C3%A4imi%C3%A4.)
^fi-Q0116-answer

**fi-Q0117** — Et voi muuttaa Tomia.

You can't change Tom.

Expected form: **Et**

Why: The negative verb. [[Finnish#^fi-Q0117|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Et%20voi%20muuttaa%20Tomia.)
^fi-Q0117-answer

**fi-Q0118** — Et voi muuttaa Tomia.

You can't change Tom.

Why: The negative verb. [[Finnish#^fi-Q0118|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Et%20voi%20muuttaa%20Tomia.)
^fi-Q0118-answer

**fi-Q0119** — Miksi et vain voi soittaa Tomille?

Why can't you just call Tom?

Why: The negative verb. [[Finnish#^fi-Q0119|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Miksi%20et%20vain%20voi%20soittaa%20Tomille%3F)
^fi-Q0119-answer

**fi-Q0120** — Miksi et vain voi soittaa Tomille?

Why can't you just call Tom?

Finnish negation conjugates the negative auxiliary for person and number. The ordinary lexical verb appears in a connegative form: en puhu, et puhu, ei puhu.

Why: The negative verb. [[Finnish#^fi-Q0120|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Miksi%20et%20vain%20voi%20soittaa%20Tomille%3F)
^fi-Q0120-answer

**fi-Q0121** — Mä luulin, et Tomi vitsaili vaan.

I thought Tom was just kidding.

Expected form: **et**

Why: The negative verb. [[Finnish#^fi-Q0121|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=M%C3%A4%20luulin%2C%20et%20Tomi%20vitsaili%20vaan.)
^fi-Q0121-answer

**fi-Q0122** — Mä luulin, et Tomi vitsaili vaan.

I thought Tom was just kidding.

Expected form: **et**

Why: The negative verb. [[Finnish#^fi-Q0122|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=M%C3%A4%20luulin%2C%20et%20Tomi%20vitsaili%20vaan.)
^fi-Q0122-answer

**fi-Q0123** — Jos et kerro meille, niin me tapamme sinut.

If you don't tell us, we'll kill you.

Expected form: **et**

Why: The negative verb. [[Finnish#^fi-Q0123|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Jos%20et%20kerro%20meille%2C%20niin%20me%20tapamme%20sinut.)
^fi-Q0123-answer

**fi-Q0124** — Jos et kerro meille, niin me tapamme sinut.

If you don't tell us, we'll kill you.

Why: The negative verb. [[Finnish#^fi-Q0124|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Jos%20et%20kerro%20meille%2C%20niin%20me%20tapamme%20sinut.)
^fi-Q0124-answer

**fi-Q0125** — Tom ei ole voinut kirjoittaa tätä kirjettä itse.

Tom can't have written this letter himself.

Why: The negative verb. [[Finnish#^fi-Q0125|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tom%20ei%20ole%20voinut%20kirjoittaa%20t%C3%A4t%C3%A4%20kirjett%C3%A4%20itse.)
^fi-Q0125-answer

**fi-Q0126** — Tom ei ole voinut kirjoittaa tätä kirjettä itse.

Tom can't have written this letter himself.

Finnish negation conjugates the negative auxiliary for person and number. The ordinary lexical verb appears in a connegative form: en puhu, et puhu, ei puhu.

Why: The negative verb. [[Finnish#^fi-Q0126|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tom%20ei%20ole%20voinut%20kirjoittaa%20t%C3%A4t%C3%A4%20kirjett%C3%A4%20itse.)
^fi-Q0126-answer

**fi-Q0127** — En halua puhua säästä.

I don't want to talk about the weather.

Expected form: **En**

Why: The negative verb. [[Finnish#^fi-Q0127|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=En%20halua%20puhua%20s%C3%A4%C3%A4st%C3%A4.)
^fi-Q0127-answer

**fi-Q0128** — En halua puhua säästä.

I don't want to talk about the weather.

Expected form: **En**

Why: The negative verb. [[Finnish#^fi-Q0128|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=En%20halua%20puhua%20s%C3%A4%C3%A4st%C3%A4.)
^fi-Q0128-answer

**fi-Q0129** — Minua ei kiinnosta panna rahojani sinun unelmiisi.

I have no interest in putting my money into your dreams.

Expected form: **ei**

Why: The negative verb. [[Finnish#^fi-Q0129|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Minua%20ei%20kiinnosta%20panna%20rahojani%20sinun%20unelmiisi.)
^fi-Q0129-answer

**fi-Q0130** — Minua ei kiinnosta panna rahojani sinun unelmiisi.

I have no interest in putting my money into your dreams.

Why: The negative verb. [[Finnish#^fi-Q0130|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Minua%20ei%20kiinnosta%20panna%20rahojani%20sinun%20unelmiisi.)
^fi-Q0130-answer

**fi-Q0131** — Te ette kirjoittaneet mitään.

You didn't write anything.

Why: The negative verb. [[Finnish#^fi-Q0131|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Te%20ette%20kirjoittaneet%20mit%C3%A4%C3%A4n.)
^fi-Q0131-answer

**fi-Q0132** — Te ette kirjoittaneet mitään.

You didn't write anything.

Finnish negation conjugates the negative auxiliary for person and number. The ordinary lexical verb appears in a connegative form: en puhu, et puhu, ei puhu.

Why: The negative verb. [[Finnish#^fi-Q0132|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Te%20ette%20kirjoittaneet%20mit%C3%A4%C3%A4n.)
^fi-Q0132-answer

**fi-Q0133** — Hän ei elänyt päivääkään elämästään väkivallatta.

She didn't live a single day of her life without violence.

Expected form: **ei**

Why: The negative verb. [[Finnish#^fi-Q0133|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=H%C3%A4n%20ei%20el%C3%A4nyt%20p%C3%A4iv%C3%A4%C3%A4k%C3%A4%C3%A4n%20el%C3%A4m%C3%A4st%C3%A4%C3%A4n%20v%C3%A4kivallatta.)
^fi-Q0133-answer

**fi-Q0134** — Hän ei elänyt päivääkään elämästään väkivallatta.

She didn't live a single day of her life without violence.

Expected form: **ei**

Why: The negative verb. [[Finnish#^fi-Q0134|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=H%C3%A4n%20ei%20el%C3%A4nyt%20p%C3%A4iv%C3%A4%C3%A4k%C3%A4%C3%A4n%20el%C3%A4m%C3%A4st%C3%A4%C3%A4n%20v%C3%A4kivallatta.)
^fi-Q0134-answer

**fi-Q0135** — En ole pukeissa.

I'm not dressed.

Expected form: **En**

Why: The negative verb. [[Finnish#^fi-Q0135|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=En%20ole%20pukeissa.)
^fi-Q0135-answer

**fi-Q0136** — En ole pukeissa.

I'm not dressed.

Why: The negative verb. [[Finnish#^fi-Q0136|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=En%20ole%20pukeissa.)
^fi-Q0136-answer

**fi-Q0137** — Et vaikuta kovin kiireiseltä.

You don't seem very busy.

Why: The negative verb. [[Finnish#^fi-Q0137|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Et%20vaikuta%20kovin%20kiireiselt%C3%A4.)
^fi-Q0137-answer

**fi-Q0138** — Et vaikuta kovin kiireiseltä.

You don't seem very busy.

Finnish negation conjugates the negative auxiliary for person and number. The ordinary lexical verb appears in a connegative form: en puhu, et puhu, ei puhu.

Why: The negative verb. [[Finnish#^fi-Q0138|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Et%20vaikuta%20kovin%20kiireiselt%C3%A4.)
^fi-Q0138-answer

**fi-Q0139** — En tunne itseäni kovin fiksuksi.

I don't feel so smart.

Expected form: **En**

Why: The negative verb. [[Finnish#^fi-Q0139|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=En%20tunne%20itse%C3%A4ni%20kovin%20fiksuksi.)
^fi-Q0139-answer

**fi-Q0140** — En tunne itseäni kovin fiksuksi.

I don't feel so smart.

Expected form: **En**

Why: The negative verb. [[Finnish#^fi-Q0140|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=En%20tunne%20itse%C3%A4ni%20kovin%20fiksuksi.)
^fi-Q0140-answer

**fi-Q0141** — Tomi ei onnistunut löytämään hattuaan.

Tom couldn't find his hat.

Expected form: **ei**

Why: The negative verb. [[Finnish#^fi-Q0141|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tomi%20ei%20onnistunut%20l%C3%B6yt%C3%A4m%C3%A4%C3%A4n%20hattuaan.)
^fi-Q0141-answer

**fi-Q0142** — Tomi ei onnistunut löytämään hattuaan.

Tom couldn't find his hat.

Why: The negative verb. [[Finnish#^fi-Q0142|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tomi%20ei%20onnistunut%20l%C3%B6yt%C3%A4m%C3%A4%C3%A4n%20hattuaan.)
^fi-Q0142-answer

**fi-Q0143** — Minua he eivät uskoisi, vaikka vannoisin sen todeksi.

They won't believe me even if I swear it is true.

Why: The negative verb. [[Finnish#^fi-Q0143|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Minua%20he%20eiv%C3%A4t%20uskoisi%2C%20vaikka%20vannoisin%20sen%20todeksi.)
^fi-Q0143-answer

**fi-Q0144** — Minua he eivät uskoisi, vaikka vannoisin sen todeksi.

They won't believe me even if I swear it is true.

Finnish negation conjugates the negative auxiliary for person and number. The ordinary lexical verb appears in a connegative form: en puhu, et puhu, ei puhu.

Why: The negative verb. [[Finnish#^fi-Q0144|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Minua%20he%20eiv%C3%A4t%20uskoisi%2C%20vaikka%20vannoisin%20sen%20todeksi.)
^fi-Q0144-answer

**fi-Q0145** — En voi kuvata tunteitani.

I cannot describe my feelings.

Expected form: **En**

Why: The negative verb. [[Finnish#^fi-Q0145|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=En%20voi%20kuvata%20tunteitani.)
^fi-Q0145-answer

**fi-Q0146** — En voi kuvata tunteitani.

I cannot describe my feelings.

Expected form: **En**

Why: The negative verb. [[Finnish#^fi-Q0146|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=En%20voi%20kuvata%20tunteitani.)
^fi-Q0146-answer

**fi-Q0147** — En nuku hyvin.

I do not sleep well.

Expected form: **En**

Why: The negative verb. [[Finnish#^fi-Q0147|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=En%20nuku%20hyvin.)
^fi-Q0147-answer

**fi-Q0148** — En nuku hyvin.

I do not sleep well.

Why: The negative verb. [[Finnish#^fi-Q0148|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=En%20nuku%20hyvin.)
^fi-Q0148-answer

**fi-Q0149** — En halua satuttaa häntä.

I don't want to hurt her.

Why: The negative verb. [[Finnish#^fi-Q0149|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=En%20halua%20satuttaa%20h%C3%A4nt%C3%A4.)
^fi-Q0149-answer

**fi-Q0150** — En halua satuttaa häntä.

I don't want to hurt her.

Finnish negation conjugates the negative auxiliary for person and number. The ordinary lexical verb appears in a connegative form: en puhu, et puhu, ei puhu.

Why: The negative verb. [[Finnish#^fi-Q0150|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=En%20halua%20satuttaa%20h%C3%A4nt%C3%A4.)
^fi-Q0150-answer


### Answers 151–200

**fi-Q0151** — Älä ikinä yritä tehdä tätä itse.

Don't ever try to do this by yourself.

Expected form: **Älä**

Why: Negative imperatives. [[Finnish#^fi-Q0151|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=%C3%84l%C3%A4%20ikin%C3%A4%20yrit%C3%A4%20tehd%C3%A4%20t%C3%A4t%C3%A4%20itse.)
^fi-Q0151-answer

**fi-Q0152** — Älä ikinä yritä tehdä tätä itse.

Don't ever try to do this by yourself.

Expected form: **Älä**

Why: Negative imperatives. [[Finnish#^fi-Q0152|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=%C3%84l%C3%A4%20ikin%C3%A4%20yrit%C3%A4%20tehd%C3%A4%20t%C3%A4t%C3%A4%20itse.)
^fi-Q0152-answer

**fi-Q0153** — Älä unohda laittaa postimerkkejä kirjeisiin, jotka annoin sinulle postitettavaksi.

Please don't forget to put stamps on the letters I gave you to post.

Expected form: **Älä**

Why: Negative imperatives. [[Finnish#^fi-Q0153|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=%C3%84l%C3%A4%20unohda%20laittaa%20postimerkkej%C3%A4%20kirjeisiin%2C%20jotka%20annoin%20sinulle%20postitettavaksi.)
^fi-Q0153-answer

**fi-Q0154** — Älä unohda laittaa postimerkkejä kirjeisiin, jotka annoin sinulle postitettavaksi.

Please don't forget to put stamps on the letters I gave you to post.

Why: Negative imperatives. [[Finnish#^fi-Q0154|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=%C3%84l%C3%A4%20unohda%20laittaa%20postimerkkej%C3%A4%20kirjeisiin%2C%20jotka%20annoin%20sinulle%20postitettavaksi.)
^fi-Q0154-answer

**fi-Q0155** — Älä juo olutta ennen vuoteeseen menoa.

Don't drink beer before going to bed!

Why: Negative imperatives. [[Finnish#^fi-Q0155|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=%C3%84l%C3%A4%20juo%20olutta%20ennen%20vuoteeseen%20menoa.)
^fi-Q0155-answer

**fi-Q0156** — Älä juo olutta ennen vuoteeseen menoa.

Don't drink beer before going to bed!

Älä gives a singular prohibition; älkää a plural/polite one. The following verb has an imperative-compatible form. These are not ordinary present negative auxiliary forms.

Why: Negative imperatives. [[Finnish#^fi-Q0156|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=%C3%84l%C3%A4%20juo%20olutta%20ennen%20vuoteeseen%20menoa.)
^fi-Q0156-answer

**fi-Q0157** — Älä sano, ettet osaa tehdä sitä ennen kuin yrität. Sinä et edes tee sitä, joten miten sinä voit sanoa, että et osaa tehdä sitä?

Don't say that you can't do it before trying. You're not even doing it so how can you say that you can't do it?

Expected form: **Älä**

Why: Negative imperatives. [[Finnish#^fi-Q0157|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=%C3%84l%C3%A4%20sano%2C%20ettet%20osaa%20tehd%C3%A4%20sit%C3%A4%20ennen%20kuin%20yrit%C3%A4t.%20Sin%C3%A4%20et%20edes%20tee%20sit%C3%A4%2C%20joten%20miten%20sin%C3%A4%20voit%20sanoa%2C%20ett%C3%A4%20et%20osaa%20tehd%C3%A4%20sit%C3%A4%3F)
^fi-Q0157-answer

**fi-Q0158** — Älä sano, ettet osaa tehdä sitä ennen kuin yrität. Sinä et edes tee sitä, joten miten sinä voit sanoa, että et osaa tehdä sitä?

Don't say that you can't do it before trying. You're not even doing it so how can you say that you can't do it?

Expected form: **Älä**

Why: Negative imperatives. [[Finnish#^fi-Q0158|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=%C3%84l%C3%A4%20sano%2C%20ettet%20osaa%20tehd%C3%A4%20sit%C3%A4%20ennen%20kuin%20yrit%C3%A4t.%20Sin%C3%A4%20et%20edes%20tee%20sit%C3%A4%2C%20joten%20miten%20sin%C3%A4%20voit%20sanoa%2C%20ett%C3%A4%20et%20osaa%20tehd%C3%A4%20sit%C3%A4%3F)
^fi-Q0158-answer

**fi-Q0159** — Älä kerro juttuja koulusta.

Don't tell tales out of school.

Expected form: **Älä**

Why: Negative imperatives. [[Finnish#^fi-Q0159|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=%C3%84l%C3%A4%20kerro%20juttuja%20koulusta.)
^fi-Q0159-answer

**fi-Q0160** — Älä kerro juttuja koulusta.

Don't tell tales out of school.

Why: Negative imperatives. [[Finnish#^fi-Q0160|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=%C3%84l%C3%A4%20kerro%20juttuja%20koulusta.)
^fi-Q0160-answer

**fi-Q0161** — Älä käsitä minua väärin.

Don't get me wrong.

Why: Negative imperatives. [[Finnish#^fi-Q0161|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=%C3%84l%C3%A4%20k%C3%A4sit%C3%A4%20minua%20v%C3%A4%C3%A4rin.)
^fi-Q0161-answer

**fi-Q0162** — Älä käsitä minua väärin.

Don't get me wrong.

Älä gives a singular prohibition; älkää a plural/polite one. The following verb has an imperative-compatible form. These are not ordinary present negative auxiliary forms.

Why: Negative imperatives. [[Finnish#^fi-Q0162|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=%C3%84l%C3%A4%20k%C3%A4sit%C3%A4%20minua%20v%C3%A4%C3%A4rin.)
^fi-Q0162-answer

**fi-Q0163** — Älä koske mihinkään täällä.

Don't touch anything here.

Expected form: **Älä**

Why: Negative imperatives. [[Finnish#^fi-Q0163|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=%C3%84l%C3%A4%20koske%20mihink%C3%A4%C3%A4n%20t%C3%A4%C3%A4ll%C3%A4.)
^fi-Q0163-answer

**fi-Q0164** — Älä koske mihinkään täällä.

Don't touch anything here.

Expected form: **Älä**

Why: Negative imperatives. [[Finnish#^fi-Q0164|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=%C3%84l%C3%A4%20koske%20mihink%C3%A4%C3%A4n%20t%C3%A4%C3%A4ll%C3%A4.)
^fi-Q0164-answer

**fi-Q0165** — Älä koskaan vittuile vittupäälle!

Never fuck with a fucker!

Expected form: **Älä**

Why: Negative imperatives. [[Finnish#^fi-Q0165|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=%C3%84l%C3%A4%20koskaan%20vittuile%20vittup%C3%A4%C3%A4lle%21)
^fi-Q0165-answer

**fi-Q0166** — Älä koskaan vittuile vittupäälle!

Never fuck with a fucker!

Why: Negative imperatives. [[Finnish#^fi-Q0166|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=%C3%84l%C3%A4%20koskaan%20vittuile%20vittup%C3%A4%C3%A4lle%21)
^fi-Q0166-answer

**fi-Q0167** — Älä kaada tätä puuta.

Don't cut this tree down.

Why: Negative imperatives. [[Finnish#^fi-Q0167|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=%C3%84l%C3%A4%20kaada%20t%C3%A4t%C3%A4%20puuta.)
^fi-Q0167-answer

**fi-Q0168** — Älä kaada tätä puuta.

Don't cut this tree down.

Älä gives a singular prohibition; älkää a plural/polite one. The following verb has an imperative-compatible form. These are not ordinary present negative auxiliary forms.

Why: Negative imperatives. [[Finnish#^fi-Q0168|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=%C3%84l%C3%A4%20kaada%20t%C3%A4t%C3%A4%20puuta.)
^fi-Q0168-answer

**fi-Q0169** — Älä avaa suutasi!

Don't open your mouth.

Expected form: **Älä**

Why: Negative imperatives. [[Finnish#^fi-Q0169|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=%C3%84l%C3%A4%20avaa%20suutasi%21)
^fi-Q0169-answer

**fi-Q0170** — Älä avaa suutasi!

Don't open your mouth.

Expected form: **Älä**

Why: Negative imperatives. [[Finnish#^fi-Q0170|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=%C3%84l%C3%A4%20avaa%20suutasi%21)
^fi-Q0170-answer

**fi-Q0171** — Älkää menettäkö tajuntojanne.

Don't pass out on me.

Expected form: **Älkää**

Why: Negative imperatives. [[Finnish#^fi-Q0171|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=%C3%84lk%C3%A4%C3%A4%20menett%C3%A4k%C3%B6%20tajuntojanne.)
^fi-Q0171-answer

**fi-Q0172** — Älkää menettäkö tajuntojanne.

Don't pass out on me.

Why: Negative imperatives. [[Finnish#^fi-Q0172|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=%C3%84lk%C3%A4%C3%A4%20menett%C3%A4k%C3%B6%20tajuntojanne.)
^fi-Q0172-answer

**fi-Q0173** — Älä unta näe!

In your dreams!

Why: Negative imperatives. [[Finnish#^fi-Q0173|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=%C3%84l%C3%A4%20unta%20n%C3%A4e%21)
^fi-Q0173-answer

**fi-Q0174** — Älä unta näe!

In your dreams!

Älä gives a singular prohibition; älkää a plural/polite one. The following verb has an imperative-compatible form. These are not ordinary present negative auxiliary forms.

Why: Negative imperatives. [[Finnish#^fi-Q0174|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=%C3%84l%C3%A4%20unta%20n%C3%A4e%21)
^fi-Q0174-answer

**fi-Q0175** — Älä heitä pois tätä lehteä. En ole lukenut sitä vielä.

Don't throw away this magazine. I haven't read it yet.

Expected form: **Älä**

Why: Negative imperatives. [[Finnish#^fi-Q0175|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=%C3%84l%C3%A4%20heit%C3%A4%20pois%20t%C3%A4t%C3%A4%20lehte%C3%A4.%20En%20ole%20lukenut%20sit%C3%A4%20viel%C3%A4.)
^fi-Q0175-answer

**fi-Q0176** — Älä heitä pois tätä lehteä. En ole lukenut sitä vielä.

Don't throw away this magazine. I haven't read it yet.

Expected form: **Älä**

Why: Negative imperatives. [[Finnish#^fi-Q0176|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=%C3%84l%C3%A4%20heit%C3%A4%20pois%20t%C3%A4t%C3%A4%20lehte%C3%A4.%20En%20ole%20lukenut%20sit%C3%A4%20viel%C3%A4.)
^fi-Q0176-answer

**fi-Q0177** — Älä julkaise sivuston ilmapiiriä huonontavia kirjoituksia.

Please refrain from making posts that make this site less pleasant to visit.

Expected form: **Älä**

Why: Negative imperatives. [[Finnish#^fi-Q0177|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=%C3%84l%C3%A4%20julkaise%20sivuston%20ilmapiiri%C3%A4%20huonontavia%20kirjoituksia.)
^fi-Q0177-answer

**fi-Q0178** — Älä julkaise sivuston ilmapiiriä huonontavia kirjoituksia.

Please refrain from making posts that make this site less pleasant to visit.

Why: Negative imperatives. [[Finnish#^fi-Q0178|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=%C3%84l%C3%A4%20julkaise%20sivuston%20ilmapiiri%C3%A4%20huonontavia%20kirjoituksia.)
^fi-Q0178-answer

**fi-Q0179** — Älkää syyttäkö meitä tästä.

Don't blame me for this.

Why: Negative imperatives. [[Finnish#^fi-Q0179|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=%C3%84lk%C3%A4%C3%A4%20syytt%C3%A4k%C3%B6%20meit%C3%A4%20t%C3%A4st%C3%A4.)
^fi-Q0179-answer

**fi-Q0180** — Älkää syyttäkö meitä tästä.

Don't blame me for this.

Älä gives a singular prohibition; älkää a plural/polite one. The following verb has an imperative-compatible form. These are not ordinary present negative auxiliary forms.

Why: Negative imperatives. [[Finnish#^fi-Q0180|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=%C3%84lk%C3%A4%C3%A4%20syytt%C3%A4k%C3%B6%20meit%C3%A4%20t%C3%A4st%C3%A4.)
^fi-Q0180-answer

**fi-Q0181** — Älä ole niin vahingoniloinen!

Don't be so gleeful!

Expected form: **Älä**

Why: Negative imperatives. [[Finnish#^fi-Q0181|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=%C3%84l%C3%A4%20ole%20niin%20vahingoniloinen%21)
^fi-Q0181-answer

**fi-Q0182** — Älä ole niin vahingoniloinen!

Don't be so gleeful!

Expected form: **Älä**

Why: Negative imperatives. [[Finnish#^fi-Q0182|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=%C3%84l%C3%A4%20ole%20niin%20vahingoniloinen%21)
^fi-Q0182-answer

**fi-Q0183** — Älä laita sitä vielä pois.

Don't put that away yet.

Expected form: **Älä**

Why: Negative imperatives. [[Finnish#^fi-Q0183|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=%C3%84l%C3%A4%20laita%20sit%C3%A4%20viel%C3%A4%20pois.)
^fi-Q0183-answer

**fi-Q0184** — Älä laita sitä vielä pois.

Don't put that away yet.

Why: Negative imperatives. [[Finnish#^fi-Q0184|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=%C3%84l%C3%A4%20laita%20sit%C3%A4%20viel%C3%A4%20pois.)
^fi-Q0184-answer

**fi-Q0185** — Älä viitsi, mennään.

Come on, let's go.

Why: Negative imperatives. [[Finnish#^fi-Q0185|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=%C3%84l%C3%A4%20viitsi%2C%20menn%C3%A4%C3%A4n.)
^fi-Q0185-answer

**fi-Q0186** — Älä viitsi, mennään.

Come on, let's go.

Älä gives a singular prohibition; älkää a plural/polite one. The following verb has an imperative-compatible form. These are not ordinary present negative auxiliary forms.

Why: Negative imperatives. [[Finnish#^fi-Q0186|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=%C3%84l%C3%A4%20viitsi%2C%20menn%C3%A4%C3%A4n.)
^fi-Q0186-answer

**fi-Q0187** — Älä räpäytä silmiä.

Don't blink.

Expected form: **Älä**

Why: Negative imperatives. [[Finnish#^fi-Q0187|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=%C3%84l%C3%A4%20r%C3%A4p%C3%A4yt%C3%A4%20silmi%C3%A4.)
^fi-Q0187-answer

**fi-Q0188** — Älä räpäytä silmiä.

Don't blink.

Expected form: **Älä**

Why: Negative imperatives. [[Finnish#^fi-Q0188|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=%C3%84l%C3%A4%20r%C3%A4p%C3%A4yt%C3%A4%20silmi%C3%A4.)
^fi-Q0188-answer

**fi-Q0189** — Ole kiltti ja älä pakota minua menemään.

Please don't force me to go.

Expected form: **älä**

Why: Negative imperatives. [[Finnish#^fi-Q0189|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Ole%20kiltti%20ja%20%C3%A4l%C3%A4%20pakota%20minua%20menem%C3%A4%C3%A4n.)
^fi-Q0189-answer

**fi-Q0190** — Ole kiltti ja älä pakota minua menemään.

Please don't force me to go.

Why: Negative imperatives. [[Finnish#^fi-Q0190|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Ole%20kiltti%20ja%20%C3%A4l%C3%A4%20pakota%20minua%20menem%C3%A4%C3%A4n.)
^fi-Q0190-answer

**fi-Q0191** — Älä puhu palturia.

Don't lie.

Why: Negative imperatives. [[Finnish#^fi-Q0191|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=%C3%84l%C3%A4%20puhu%20palturia.)
^fi-Q0191-answer

**fi-Q0192** — Älä puhu palturia.

Don't lie.

Älä gives a singular prohibition; älkää a plural/polite one. The following verb has an imperative-compatible form. These are not ordinary present negative auxiliary forms.

Why: Negative imperatives. [[Finnish#^fi-Q0192|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=%C3%84l%C3%A4%20puhu%20palturia.)
^fi-Q0192-answer

**fi-Q0193** — Älä kuuntele häntä, hän puhuu pötyä.

Don't listen to him, he's talking nonsense.

Expected form: **Älä**

Why: Negative imperatives. [[Finnish#^fi-Q0193|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=%C3%84l%C3%A4%20kuuntele%20h%C3%A4nt%C3%A4%2C%20h%C3%A4n%20puhuu%20p%C3%B6ty%C3%A4.)
^fi-Q0193-answer

**fi-Q0194** — Älä kuuntele häntä, hän puhuu pötyä.

Don't listen to him, he's talking nonsense.

Expected form: **Älä**

Why: Negative imperatives. [[Finnish#^fi-Q0194|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=%C3%84l%C3%A4%20kuuntele%20h%C3%A4nt%C3%A4%2C%20h%C3%A4n%20puhuu%20p%C3%B6ty%C3%A4.)
^fi-Q0194-answer

**fi-Q0195** — Älä unohda ottaa sateenvarjoasi mukaan lähtiessäsi.

Don't forget to take your umbrella when you leave.

Expected form: **Älä**

Why: Negative imperatives. [[Finnish#^fi-Q0195|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=%C3%84l%C3%A4%20unohda%20ottaa%20sateenvarjoasi%20mukaan%20l%C3%A4htiess%C3%A4si.)
^fi-Q0195-answer

**fi-Q0196** — Älä unohda ottaa sateenvarjoasi mukaan lähtiessäsi.

Don't forget to take your umbrella when you leave.

Why: Negative imperatives. [[Finnish#^fi-Q0196|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=%C3%84l%C3%A4%20unohda%20ottaa%20sateenvarjoasi%20mukaan%20l%C3%A4htiess%C3%A4si.)
^fi-Q0196-answer

**fi-Q0197** — Älä unohda soittaa minulle jos tulet Rioon, niin minä voin olla oppaasi!

If you come to Rio, don't forget to call me to be your guide!

Why: Negative imperatives. [[Finnish#^fi-Q0197|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=%C3%84l%C3%A4%20unohda%20soittaa%20minulle%20jos%20tulet%20Rioon%2C%20niin%20min%C3%A4%20voin%20olla%20oppaasi%21)
^fi-Q0197-answer

**fi-Q0198** — Älä unohda soittaa minulle jos tulet Rioon, niin minä voin olla oppaasi!

If you come to Rio, don't forget to call me to be your guide!

Älä gives a singular prohibition; älkää a plural/polite one. The following verb has an imperative-compatible form. These are not ordinary present negative auxiliary forms.

Why: Negative imperatives. [[Finnish#^fi-Q0198|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=%C3%84l%C3%A4%20unohda%20soittaa%20minulle%20jos%20tulet%20Rioon%2C%20niin%20min%C3%A4%20voin%20olla%20oppaasi%21)
^fi-Q0198-answer

**fi-Q0199** — Älä puhu niin paljon seuraavalla kerralla.

Don't talk so much next time.

Expected form: **Älä**

Why: Negative imperatives. [[Finnish#^fi-Q0199|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=%C3%84l%C3%A4%20puhu%20niin%20paljon%20seuraavalla%20kerralla.)
^fi-Q0199-answer

**fi-Q0200** — Älä puhu niin paljon seuraavalla kerralla.

Don't talk so much next time.

Expected form: **Älä**

Why: Negative imperatives. [[Finnish#^fi-Q0200|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=%C3%84l%C3%A4%20puhu%20niin%20paljon%20seuraavalla%20kerralla.)
^fi-Q0200-answer


### Answers 201–250

**fi-Q0201** — Mary oli heidän suuri faninsa.

Mary is a big fan of theirs.

Expected form: **oli**

Why: Past olla. [[Finnish#^fi-Q0201|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Mary%20oli%20heid%C3%A4n%20suuri%20faninsa.)
^fi-Q0201-answer

**fi-Q0202** — Mary oli heidän suuri faninsa.

Mary is a big fan of theirs.

Why: Past olla. [[Finnish#^fi-Q0202|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Mary%20oli%20heid%C3%A4n%20suuri%20faninsa.)
^fi-Q0202-answer

**fi-Q0203** — Huone oli tupaten täynnä.

The room was packed.

Why: Past olla. [[Finnish#^fi-Q0203|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Huone%20oli%20tupaten%20t%C3%A4ynn%C3%A4.)
^fi-Q0203-answer

**fi-Q0204** — Huone oli tupaten täynnä.

The room was packed.

The past of olla agrees with the subject. It can be a main verb or a perfect/pluperfect auxiliary. Read any accompanying participle before choosing the analysis.

Why: Past olla. [[Finnish#^fi-Q0204|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Huone%20oli%20tupaten%20t%C3%A4ynn%C3%A4.)
^fi-Q0204-answer

**fi-Q0205** — Kahdesti ja kolmasti olin sinua rakastanut, ennen kuin tunsin naamaasi tahi nimeäsi.

Twice and thrice had I loved thee before I knew thy face or name.

Expected form: **olin**

Why: Past olla. [[Finnish#^fi-Q0205|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Kahdesti%20ja%20kolmasti%20olin%20sinua%20rakastanut%2C%20ennen%20kuin%20tunsin%20naamaasi%20tahi%20nime%C3%A4si.)
^fi-Q0205-answer

**fi-Q0206** — Kahdesti ja kolmasti olin sinua rakastanut, ennen kuin tunsin naamaasi tahi nimeäsi.

Twice and thrice had I loved thee before I knew thy face or name.

Expected form: **olin**

Why: Past olla. [[Finnish#^fi-Q0206|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Kahdesti%20ja%20kolmasti%20olin%20sinua%20rakastanut%2C%20ennen%20kuin%20tunsin%20naamaasi%20tahi%20nime%C3%A4si.)
^fi-Q0206-answer

**fi-Q0207** — Luulin, että Tom oli vaikeuksissa.

I thought Tom was in trouble.

Expected form: **oli**

Why: Past olla. [[Finnish#^fi-Q0207|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Luulin%2C%20ett%C3%A4%20Tom%20oli%20vaikeuksissa.)
^fi-Q0207-answer

**fi-Q0208** — Luulin, että Tom oli vaikeuksissa.

I thought Tom was in trouble.

Why: Past olla. [[Finnish#^fi-Q0208|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Luulin%2C%20ett%C3%A4%20Tom%20oli%20vaikeuksissa.)
^fi-Q0208-answer

**fi-Q0209** — Eilen oli minun syntymäpäiväni.

Yesterday was my birthday.

Why: Past olla. [[Finnish#^fi-Q0209|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Eilen%20oli%20minun%20syntym%C3%A4p%C3%A4iv%C3%A4ni.)
^fi-Q0209-answer

**fi-Q0210** — Eilen oli minun syntymäpäiväni.

Yesterday was my birthday.

The past of olla agrees with the subject. It can be a main verb or a perfect/pluperfect auxiliary. Read any accompanying participle before choosing the analysis.

Why: Past olla. [[Finnish#^fi-Q0210|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Eilen%20oli%20minun%20syntym%C3%A4p%C3%A4iv%C3%A4ni.)
^fi-Q0210-answer

**fi-Q0211** — Vaikkakin hän oli vaikeasti loukkaantunut, hän onnistui pääsemään puhelimeen.

Though seriously injured, he managed to get to a telephone.

Expected form: **oli**

Why: Past olla. [[Finnish#^fi-Q0211|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Vaikkakin%20h%C3%A4n%20oli%20vaikeasti%20loukkaantunut%2C%20h%C3%A4n%20onnistui%20p%C3%A4%C3%A4sem%C3%A4%C3%A4n%20puhelimeen.)
^fi-Q0211-answer

**fi-Q0212** — Vaikkakin hän oli vaikeasti loukkaantunut, hän onnistui pääsemään puhelimeen.

Though seriously injured, he managed to get to a telephone.

Expected form: **oli**

Why: Past olla. [[Finnish#^fi-Q0212|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Vaikkakin%20h%C3%A4n%20oli%20vaikeasti%20loukkaantunut%2C%20h%C3%A4n%20onnistui%20p%C3%A4%C3%A4sem%C3%A4%C3%A4n%20puhelimeen.)
^fi-Q0212-answer

**fi-Q0213** — Hän oli tyytyväinen elämäänsä.

She was content with her life.

Expected form: **oli**

Why: Past olla. [[Finnish#^fi-Q0213|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=H%C3%A4n%20oli%20tyytyv%C3%A4inen%20el%C3%A4m%C3%A4%C3%A4ns%C3%A4.)
^fi-Q0213-answer

**fi-Q0214** — Hän oli tyytyväinen elämäänsä.

She was content with her life.

Why: Past olla. [[Finnish#^fi-Q0214|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=H%C3%A4n%20oli%20tyytyv%C3%A4inen%20el%C3%A4m%C3%A4%C3%A4ns%C3%A4.)
^fi-Q0214-answer

**fi-Q0215** — Orava oli yli kahdenkymmenen metrin päässä meistä.

The squirrel was more than twenty meters away from us.

Why: Past olla. [[Finnish#^fi-Q0215|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Orava%20oli%20yli%20kahdenkymmenen%20metrin%20p%C3%A4%C3%A4ss%C3%A4%20meist%C3%A4.)
^fi-Q0215-answer

**fi-Q0216** — Orava oli yli kahdenkymmenen metrin päässä meistä.

The squirrel was more than twenty meters away from us.

The past of olla agrees with the subject. It can be a main verb or a perfect/pluperfect auxiliary. Read any accompanying participle before choosing the analysis.

Why: Past olla. [[Finnish#^fi-Q0216|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Orava%20oli%20yli%20kahdenkymmenen%20metrin%20p%C3%A4%C3%A4ss%C3%A4%20meist%C3%A4.)
^fi-Q0216-answer

**fi-Q0217** — Tomi teeskenteli sitä, että hän oli Marin ystävä.

Tom pretended to be Mary's friend.

Expected form: **oli**

Why: Past olla. [[Finnish#^fi-Q0217|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tomi%20teeskenteli%20sit%C3%A4%2C%20ett%C3%A4%20h%C3%A4n%20oli%20Marin%20yst%C3%A4v%C3%A4.)
^fi-Q0217-answer

**fi-Q0218** — Tomi teeskenteli sitä, että hän oli Marin ystävä.

Tom pretended to be Mary's friend.

Expected form: **oli**

Why: Past olla. [[Finnish#^fi-Q0218|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tomi%20teeskenteli%20sit%C3%A4%2C%20ett%C3%A4%20h%C3%A4n%20oli%20Marin%20yst%C3%A4v%C3%A4.)
^fi-Q0218-answer

**fi-Q0219** — Tom sanoi, että hänellä oli ongelmia Marin kanssa.

Tom said he was having problems with Mary.

Expected form: **oli**

Why: Past olla. [[Finnish#^fi-Q0219|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tom%20sanoi%2C%20ett%C3%A4%20h%C3%A4nell%C3%A4%20oli%20ongelmia%20Marin%20kanssa.)
^fi-Q0219-answer

**fi-Q0220** — Tom sanoi, että hänellä oli ongelmia Marin kanssa.

Tom said he was having problems with Mary.

Why: Past olla. [[Finnish#^fi-Q0220|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tom%20sanoi%2C%20ett%C3%A4%20h%C3%A4nell%C3%A4%20oli%20ongelmia%20Marin%20kanssa.)
^fi-Q0220-answer

**fi-Q0221** — Pyysin viiden kuukauden pillerikuurin, ja vastaus oli "totta kai".

I said, "Five months worth of the Pill, please," and was told "Certainly."

Why: Past olla. [[Finnish#^fi-Q0221|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Pyysin%20viiden%20kuukauden%20pillerikuurin%2C%20ja%20vastaus%20oli%20%22totta%20kai%22.)
^fi-Q0221-answer

**fi-Q0222** — Pyysin viiden kuukauden pillerikuurin, ja vastaus oli "totta kai".

I said, "Five months worth of the Pill, please," and was told "Certainly."

The past of olla agrees with the subject. It can be a main verb or a perfect/pluperfect auxiliary. Read any accompanying participle before choosing the analysis.

Why: Past olla. [[Finnish#^fi-Q0222|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Pyysin%20viiden%20kuukauden%20pillerikuurin%2C%20ja%20vastaus%20oli%20%22totta%20kai%22.)
^fi-Q0222-answer

**fi-Q0223** — Tomin isoisoisä oli Bostonin kaupunginjohtaja.

Tom's great-grandfather was the mayor of Boston.

Expected form: **oli**

Why: Past olla. [[Finnish#^fi-Q0223|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tomin%20isoisois%C3%A4%20oli%20Bostonin%20kaupunginjohtaja.)
^fi-Q0223-answer

**fi-Q0224** — Tomin isoisoisä oli Bostonin kaupunginjohtaja.

Tom's great-grandfather was the mayor of Boston.

Expected form: **oli**

Why: Past olla. [[Finnish#^fi-Q0224|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tomin%20isoisois%C3%A4%20oli%20Bostonin%20kaupunginjohtaja.)
^fi-Q0224-answer

**fi-Q0225** — No oli jo vittu aikakin!

It's about fucking time.

Expected form: **oli**

Why: Past olla. [[Finnish#^fi-Q0225|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=No%20oli%20jo%20vittu%20aikakin%21)
^fi-Q0225-answer

**fi-Q0226** — No oli jo vittu aikakin!

It's about fucking time.

Why: Past olla. [[Finnish#^fi-Q0226|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=No%20oli%20jo%20vittu%20aikakin%21)
^fi-Q0226-answer

**fi-Q0227** — Ennen kuin Tom ja Mary huomasivatkaan mitä tapahtui, heidän ystävyytensä oli muuttunut rakkaudeksi.

Before Tom and Mary realized what was happening, their friendship had turned into love.

Why: Past olla. [[Finnish#^fi-Q0227|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Ennen%20kuin%20Tom%20ja%20Mary%20huomasivatkaan%20mit%C3%A4%20tapahtui%2C%20heid%C3%A4n%20yst%C3%A4vyytens%C3%A4%20oli%20muuttunut%20rakkaudeksi.)
^fi-Q0227-answer

**fi-Q0228** — Ennen kuin Tom ja Mary huomasivatkaan mitä tapahtui, heidän ystävyytensä oli muuttunut rakkaudeksi.

Before Tom and Mary realized what was happening, their friendship had turned into love.

The past of olla agrees with the subject. It can be a main verb or a perfect/pluperfect auxiliary. Read any accompanying participle before choosing the analysis.

Why: Past olla. [[Finnish#^fi-Q0228|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Ennen%20kuin%20Tom%20ja%20Mary%20huomasivatkaan%20mit%C3%A4%20tapahtui%2C%20heid%C3%A4n%20yst%C3%A4vyytens%C3%A4%20oli%20muuttunut%20rakkaudeksi.)
^fi-Q0228-answer

**fi-Q0229** — Radio oli Marconin keksimä.

The radio was invented by Marconi.

Expected form: **oli**

Why: Past olla. [[Finnish#^fi-Q0229|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Radio%20oli%20Marconin%20keksim%C3%A4.)
^fi-Q0229-answer

**fi-Q0230** — Radio oli Marconin keksimä.

The radio was invented by Marconi.

Expected form: **oli**

Why: Past olla. [[Finnish#^fi-Q0230|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Radio%20oli%20Marconin%20keksim%C3%A4.)
^fi-Q0230-answer

**fi-Q0231** — Hän oli hyvällä tuulella.

He was in good spirits.

Expected form: **oli**

Why: Past olla. [[Finnish#^fi-Q0231|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=H%C3%A4n%20oli%20hyv%C3%A4ll%C3%A4%20tuulella.)
^fi-Q0231-answer

**fi-Q0232** — Hän oli hyvällä tuulella.

He was in good spirits.

Why: Past olla. [[Finnish#^fi-Q0232|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=H%C3%A4n%20oli%20hyv%C3%A4ll%C3%A4%20tuulella.)
^fi-Q0232-answer

**fi-Q0233** — Tom oli Maryn lapsipuoli.

Tom was Mary's stepchild.

Why: Past olla. [[Finnish#^fi-Q0233|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tom%20oli%20Maryn%20lapsipuoli.)
^fi-Q0233-answer

**fi-Q0234** — Tom oli Maryn lapsipuoli.

Tom was Mary's stepchild.

The past of olla agrees with the subject. It can be a main verb or a perfect/pluperfect auxiliary. Read any accompanying participle before choosing the analysis.

Why: Past olla. [[Finnish#^fi-Q0234|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tom%20oli%20Maryn%20lapsipuoli.)
^fi-Q0234-answer

**fi-Q0235** — West-niminen henkilö soitti sinä aikana kun olit poissa kotoa.

A person named West called while you were out.

Expected form: **olit**

Why: Past olla. [[Finnish#^fi-Q0235|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=West-niminen%20henkil%C3%B6%20soitti%20sin%C3%A4%20aikana%20kun%20olit%20poissa%20kotoa.)
^fi-Q0235-answer

**fi-Q0236** — West-niminen henkilö soitti sinä aikana kun olit poissa kotoa.

A person named West called while you were out.

Expected form: **olit**

Why: Past olla. [[Finnish#^fi-Q0236|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=West-niminen%20henkil%C3%B6%20soitti%20sin%C3%A4%20aikana%20kun%20olit%20poissa%20kotoa.)
^fi-Q0236-answer

**fi-Q0237** — Tom halusi tietää, mitä oli tapahtunut.

Tom wanted to know what had happened.

Expected form: **oli**

Why: Past olla. [[Finnish#^fi-Q0237|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tom%20halusi%20tiet%C3%A4%C3%A4%2C%20mit%C3%A4%20oli%20tapahtunut.)
^fi-Q0237-answer

**fi-Q0238** — Tom halusi tietää, mitä oli tapahtunut.

Tom wanted to know what had happened.

Why: Past olla. [[Finnish#^fi-Q0238|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tom%20halusi%20tiet%C3%A4%C3%A4%2C%20mit%C3%A4%20oli%20tapahtunut.)
^fi-Q0238-answer

**fi-Q0239** — Tomista Marilla oli poikaystävä.

Tom thought that Mary had a boyfriend.

Why: Past olla. [[Finnish#^fi-Q0239|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tomista%20Marilla%20oli%20poikayst%C3%A4v%C3%A4.)
^fi-Q0239-answer

**fi-Q0240** — Tomista Marilla oli poikaystävä.

Tom thought that Mary had a boyfriend.

The past of olla agrees with the subject. It can be a main verb or a perfect/pluperfect auxiliary. Read any accompanying participle before choosing the analysis.

Why: Past olla. [[Finnish#^fi-Q0240|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tomista%20Marilla%20oli%20poikayst%C3%A4v%C3%A4.)
^fi-Q0240-answer

**fi-Q0241** — Luulin että minulla oli vapaapäivä.

I thought I had a day off.

Expected form: **oli**

Why: Past olla. [[Finnish#^fi-Q0241|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Luulin%20ett%C3%A4%20minulla%20oli%20vapaap%C3%A4iv%C3%A4.)
^fi-Q0241-answer

**fi-Q0242** — Luulin että minulla oli vapaapäivä.

I thought I had a day off.

Expected form: **oli**

Why: Past olla. [[Finnish#^fi-Q0242|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Luulin%20ett%C3%A4%20minulla%20oli%20vapaap%C3%A4iv%C3%A4.)
^fi-Q0242-answer

**fi-Q0243** — Tämä päivä oli poikkeuksellisen rasittava.

This day was exceptionally tiring.

Expected form: **oli**

Why: Past olla. [[Finnish#^fi-Q0243|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=T%C3%A4m%C3%A4%20p%C3%A4iv%C3%A4%20oli%20poikkeuksellisen%20rasittava.)
^fi-Q0243-answer

**fi-Q0244** — Tämä päivä oli poikkeuksellisen rasittava.

This day was exceptionally tiring.

Why: Past olla. [[Finnish#^fi-Q0244|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=T%C3%A4m%C3%A4%20p%C3%A4iv%C3%A4%20oli%20poikkeuksellisen%20rasittava.)
^fi-Q0244-answer

**fi-Q0245** — Ihmettelin mitä Tomille oli sattunut.

I wondered what had happened to Tom.

Why: Past olla. [[Finnish#^fi-Q0245|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Ihmettelin%20mit%C3%A4%20Tomille%20oli%20sattunut.)
^fi-Q0245-answer

**fi-Q0246** — Ihmettelin mitä Tomille oli sattunut.

I wondered what had happened to Tom.

The past of olla agrees with the subject. It can be a main verb or a perfect/pluperfect auxiliary. Read any accompanying participle before choosing the analysis.

Why: Past olla. [[Finnish#^fi-Q0246|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Ihmettelin%20mit%C3%A4%20Tomille%20oli%20sattunut.)
^fi-Q0246-answer

**fi-Q0247** — Juoksin hänen peräänsä kantaen paperipinoa, jonka hän oli jättänyt lähtiessään.

I ran after him with a pile of papers that he'd left behind.

Expected form: **oli**

Why: Past olla. [[Finnish#^fi-Q0247|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Juoksin%20h%C3%A4nen%20per%C3%A4%C3%A4ns%C3%A4%20kantaen%20paperipinoa%2C%20jonka%20h%C3%A4n%20oli%20j%C3%A4tt%C3%A4nyt%20l%C3%A4htiess%C3%A4%C3%A4n.)
^fi-Q0247-answer

**fi-Q0248** — Juoksin hänen peräänsä kantaen paperipinoa, jonka hän oli jättänyt lähtiessään.

I ran after him with a pile of papers that he'd left behind.

Expected form: **oli**

Why: Past olla. [[Finnish#^fi-Q0248|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Juoksin%20h%C3%A4nen%20per%C3%A4%C3%A4ns%C3%A4%20kantaen%20paperipinoa%2C%20jonka%20h%C3%A4n%20oli%20j%C3%A4tt%C3%A4nyt%20l%C3%A4htiess%C3%A4%C3%A4n.)
^fi-Q0248-answer

**fi-Q0249** — Minulla oli jonkin verran vaikeuksia.

I had some trouble.

Expected form: **oli**

Why: Past olla. [[Finnish#^fi-Q0249|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Minulla%20oli%20jonkin%20verran%20vaikeuksia.)
^fi-Q0249-answer

**fi-Q0250** — Minulla oli jonkin verran vaikeuksia.

I had some trouble.

Why: Past olla. [[Finnish#^fi-Q0250|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Minulla%20oli%20jonkin%20verran%20vaikeuksia.)
^fi-Q0250-answer


### Answers 251–300

**fi-Q0251** — Käyn hakemassa vähän kahvia. Haluatko sinäkin?

I'm going to get myself some coffee. Do you want some?

Why: Partitive nouns. [[Finnish#^fi-Q0251|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=K%C3%A4yn%20hakemassa%20v%C3%A4h%C3%A4n%20kahvia.%20Haluatko%20sin%C3%A4kin%3F)
^fi-Q0251-answer

**fi-Q0252** — Käyn hakemassa vähän kahvia. Haluatko sinäkin?

I'm going to get myself some coffee. Do you want some?

Partitive occurs in many quantities, negative objects and ongoing/unbounded object constructions. It is not merely the form for an indefinite English noun. Learn the case stem alongside the nominative.

Why: Partitive nouns. [[Finnish#^fi-Q0252|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=K%C3%A4yn%20hakemassa%20v%C3%A4h%C3%A4n%20kahvia.%20Haluatko%20sin%C3%A4kin%3F)
^fi-Q0252-answer

**fi-Q0253** — Kuinka monta kirjaa luette kuukaudessa?

How many books do you read a month?

Expected form: **kirjaa**

Why: Partitive nouns. [[Finnish#^fi-Q0253|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Kuinka%20monta%20kirjaa%20luette%20kuukaudessa%3F)
^fi-Q0253-answer

**fi-Q0254** — Kuinka monta kirjaa luette kuukaudessa?

How many books do you read a month?

Expected form: **kirjaa**

Why: Partitive nouns. [[Finnish#^fi-Q0254|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Kuinka%20monta%20kirjaa%20luette%20kuukaudessa%3F)
^fi-Q0254-answer

**fi-Q0255** — Mä luulen, että meillä on tarpeeksi rahaa.

I think we have enough money.

Expected form: **rahaa**

Why: Partitive nouns. [[Finnish#^fi-Q0255|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=M%C3%A4%20luulen%2C%20ett%C3%A4%20meill%C3%A4%20on%20tarpeeksi%20rahaa.)
^fi-Q0255-answer

**fi-Q0256** — Mä luulen, että meillä on tarpeeksi rahaa.

I think we have enough money.

Why: Partitive nouns. [[Finnish#^fi-Q0256|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=M%C3%A4%20luulen%2C%20ett%C3%A4%20meill%C3%A4%20on%20tarpeeksi%20rahaa.)
^fi-Q0256-answer

**fi-Q0257** — Aika on rahaa.

Time is money.

Why: Partitive nouns. [[Finnish#^fi-Q0257|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Aika%20on%20rahaa.)
^fi-Q0257-answer

**fi-Q0258** — Aika on rahaa.

Time is money.

Partitive occurs in many quantities, negative objects and ongoing/unbounded object constructions. It is not merely the form for an indefinite English noun. Learn the case stem alongside the nominative.

Why: Partitive nouns. [[Finnish#^fi-Q0258|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Aika%20on%20rahaa.)
^fi-Q0258-answer

**fi-Q0259** — En voi olla kahdessa paikassa yhtä aikaa.

I can't be in two places at once.

Expected form: **aikaa**

Why: Partitive nouns. [[Finnish#^fi-Q0259|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=En%20voi%20olla%20kahdessa%20paikassa%20yht%C3%A4%20aikaa.)
^fi-Q0259-answer

**fi-Q0260** — En voi olla kahdessa paikassa yhtä aikaa.

I can't be in two places at once.

Expected form: **aikaa**

Why: Partitive nouns. [[Finnish#^fi-Q0260|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=En%20voi%20olla%20kahdessa%20paikassa%20yht%C3%A4%20aikaa.)
^fi-Q0260-answer

**fi-Q0261** — Minun täytyy nostaa hieman rahaa pankista.

I have to take some money out of the bank.

Expected form: **rahaa**

Why: Partitive nouns. [[Finnish#^fi-Q0261|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Minun%20t%C3%A4ytyy%20nostaa%20hieman%20rahaa%20pankista.)
^fi-Q0261-answer

**fi-Q0262** — Minun täytyy nostaa hieman rahaa pankista.

I have to take some money out of the bank.

Why: Partitive nouns. [[Finnish#^fi-Q0262|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Minun%20t%C3%A4ytyy%20nostaa%20hieman%20rahaa%20pankista.)
^fi-Q0262-answer

**fi-Q0263** — Luetko vielä sitä kirjaa?

Are you still reading that book?

Why: Partitive nouns. [[Finnish#^fi-Q0263|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Luetko%20viel%C3%A4%20sit%C3%A4%20kirjaa%3F)
^fi-Q0263-answer

**fi-Q0264** — Luetko vielä sitä kirjaa?

Are you still reading that book?

Partitive occurs in many quantities, negative objects and ongoing/unbounded object constructions. It is not merely the form for an indefinite English noun. Learn the case stem alongside the nominative.

Why: Partitive nouns. [[Finnish#^fi-Q0264|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Luetko%20viel%C3%A4%20sit%C3%A4%20kirjaa%3F)
^fi-Q0264-answer

**fi-Q0265** — Jos minulla olisi aikaa, opiskelisin ranskaa.

If I had time, I would study French.

Expected form: **aikaa**

Why: Partitive nouns. [[Finnish#^fi-Q0265|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Jos%20minulla%20olisi%20aikaa%2C%20opiskelisin%20ranskaa.)
^fi-Q0265-answer

**fi-Q0266** — Jos minulla olisi aikaa, opiskelisin ranskaa.

If I had time, I would study French.

Expected form: **aikaa**

Why: Partitive nouns. [[Finnish#^fi-Q0266|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Jos%20minulla%20olisi%20aikaa%2C%20opiskelisin%20ranskaa.)
^fi-Q0266-answer

**fi-Q0267** — Ostan usein ruokaa Tomille.

I often buy food for Tom.

Expected form: **ruokaa**

Why: Partitive nouns. [[Finnish#^fi-Q0267|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Ostan%20usein%20ruokaa%20Tomille.)
^fi-Q0267-answer

**fi-Q0268** — Ostan usein ruokaa Tomille.

I often buy food for Tom.

Why: Partitive nouns. [[Finnish#^fi-Q0268|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Ostan%20usein%20ruokaa%20Tomille.)
^fi-Q0268-answer

**fi-Q0269** — Hän kaatoi itselleen ison lasin maitoa.

He poured himself a tall glass of milk.

Why: Partitive nouns. [[Finnish#^fi-Q0269|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=H%C3%A4n%20kaatoi%20itselleen%20ison%20lasin%20maitoa.)
^fi-Q0269-answer

**fi-Q0270** — Hän kaatoi itselleen ison lasin maitoa.

He poured himself a tall glass of milk.

Partitive occurs in many quantities, negative objects and ongoing/unbounded object constructions. It is not merely the form for an indefinite English noun. Learn the case stem alongside the nominative.

Why: Partitive nouns. [[Finnish#^fi-Q0270|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=H%C3%A4n%20kaatoi%20itselleen%20ison%20lasin%20maitoa.)
^fi-Q0270-answer

**fi-Q0271** — Juo enemmän vettä.

Drink more water.

Expected form: **vettä**

Why: Partitive nouns. [[Finnish#^fi-Q0271|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Juo%20enemm%C3%A4n%20vett%C3%A4.)
^fi-Q0271-answer

**fi-Q0272** — Juo enemmän vettä.

Drink more water.

Expected form: **vettä**

Why: Partitive nouns. [[Finnish#^fi-Q0272|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Juo%20enemm%C3%A4n%20vett%C3%A4.)
^fi-Q0272-answer

**fi-Q0273** — Etkö ottaisi vielä vähän lisää teetä?

Won't you have some more tea?

Expected form: **teetä**

Why: Partitive nouns. [[Finnish#^fi-Q0273|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Etk%C3%B6%20ottaisi%20viel%C3%A4%20v%C3%A4h%C3%A4n%20lis%C3%A4%C3%A4%20teet%C3%A4%3F)
^fi-Q0273-answer

**fi-Q0274** — Etkö ottaisi vielä vähän lisää teetä?

Won't you have some more tea?

Why: Partitive nouns. [[Finnish#^fi-Q0274|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Etk%C3%B6%20ottaisi%20viel%C3%A4%20v%C3%A4h%C3%A4n%20lis%C3%A4%C3%A4%20teet%C3%A4%3F)
^fi-Q0274-answer

**fi-Q0275** — Onko sinulla muutama minuuttia aikaa puhua?

Do you have a few minutes to talk?

Why: Partitive nouns. [[Finnish#^fi-Q0275|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Onko%20sinulla%20muutama%20minuuttia%20aikaa%20puhua%3F)
^fi-Q0275-answer

**fi-Q0276** — Onko sinulla muutama minuuttia aikaa puhua?

Do you have a few minutes to talk?

Partitive occurs in many quantities, negative objects and ongoing/unbounded object constructions. It is not merely the form for an indefinite English noun. Learn the case stem alongside the nominative.

Why: Partitive nouns. [[Finnish#^fi-Q0276|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Onko%20sinulla%20muutama%20minuuttia%20aikaa%20puhua%3F)
^fi-Q0276-answer

**fi-Q0277** — Minä luen kirjaa.

I am reading a book.

Expected form: **kirjaa**

Why: Partitive nouns. [[Finnish#^fi-Q0277|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Min%C3%A4%20luen%20kirjaa.)
^fi-Q0277-answer

**fi-Q0278** — Minä luen kirjaa.

I am reading a book.

Expected form: **kirjaa**

Why: Partitive nouns. [[Finnish#^fi-Q0278|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Min%C3%A4%20luen%20kirjaa.)
^fi-Q0278-answer

**fi-Q0279** — Olin lukemassa kirjaa.

I was reading a book.

Expected form: **kirjaa**

Why: Partitive nouns. [[Finnish#^fi-Q0279|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Olin%20lukemassa%20kirjaa.)
^fi-Q0279-answer

**fi-Q0280** — Olin lukemassa kirjaa.

I was reading a book.

Why: Partitive nouns. [[Finnish#^fi-Q0280|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Olin%20lukemassa%20kirjaa.)
^fi-Q0280-answer

**fi-Q0281** — Kupissa on hieman vettä.

There is some water in the cup.

Why: Partitive nouns. [[Finnish#^fi-Q0281|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Kupissa%20on%20hieman%20vett%C3%A4.)
^fi-Q0281-answer

**fi-Q0282** — Kupissa on hieman vettä.

There is some water in the cup.

Partitive occurs in many quantities, negative objects and ongoing/unbounded object constructions. It is not merely the form for an indefinite English noun. Learn the case stem alongside the nominative.

Why: Partitive nouns. [[Finnish#^fi-Q0282|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Kupissa%20on%20hieman%20vett%C3%A4.)
^fi-Q0282-answer

**fi-Q0283** — En voi juoda maitoa.

I can't drink milk.

Expected form: **maitoa**

Why: Partitive nouns. [[Finnish#^fi-Q0283|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=En%20voi%20juoda%20maitoa.)
^fi-Q0283-answer

**fi-Q0284** — En voi juoda maitoa.

I can't drink milk.

Expected form: **maitoa**

Why: Partitive nouns. [[Finnish#^fi-Q0284|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=En%20voi%20juoda%20maitoa.)
^fi-Q0284-answer

**fi-Q0285** — Haluaisitko teetä tai kahvia?

Would you like some tea or coffee?

Expected form: **teetä**

Why: Partitive nouns. [[Finnish#^fi-Q0285|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Haluaisitko%20teet%C3%A4%20tai%20kahvia%3F)
^fi-Q0285-answer

**fi-Q0286** — Haluaisitko teetä tai kahvia?

Would you like some tea or coffee?

Why: Partitive nouns. [[Finnish#^fi-Q0286|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Haluaisitko%20teet%C3%A4%20tai%20kahvia%3F)
^fi-Q0286-answer

**fi-Q0287** — Kun laitat rahaa pankkiin, talletat sitä.

When you put money in the bank, you deposit it.

Why: Partitive nouns. [[Finnish#^fi-Q0287|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Kun%20laitat%20rahaa%20pankkiin%2C%20talletat%20sit%C3%A4.)
^fi-Q0287-answer

**fi-Q0288** — Kun laitat rahaa pankkiin, talletat sitä.

When you put money in the bank, you deposit it.

Partitive occurs in many quantities, negative objects and ongoing/unbounded object constructions. It is not merely the form for an indefinite English noun. Learn the case stem alongside the nominative.

Why: Partitive nouns. [[Finnish#^fi-Q0288|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Kun%20laitat%20rahaa%20pankkiin%2C%20talletat%20sit%C3%A4.)
^fi-Q0288-answer

**fi-Q0289** — Minä olen lukenut sitä kirjaa.

I have read the book.

Expected form: **kirjaa**

Why: Partitive nouns. [[Finnish#^fi-Q0289|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Min%C3%A4%20olen%20lukenut%20sit%C3%A4%20kirjaa.)
^fi-Q0289-answer

**fi-Q0290** — Minä olen lukenut sitä kirjaa.

I have read the book.

Expected form: **kirjaa**

Why: Partitive nouns. [[Finnish#^fi-Q0290|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Min%C3%A4%20olen%20lukenut%20sit%C3%A4%20kirjaa.)
^fi-Q0290-answer

**fi-Q0291** — Hapen reagoidessa vedyn kanssa syntyy vettä.

Oxygen reacts with hydrogen to make water.

Expected form: **vettä**

Why: Partitive nouns. [[Finnish#^fi-Q0291|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Hapen%20reagoidessa%20vedyn%20kanssa%20syntyy%20vett%C3%A4.)
^fi-Q0291-answer

**fi-Q0292** — Hapen reagoidessa vedyn kanssa syntyy vettä.

Oxygen reacts with hydrogen to make water.

Why: Partitive nouns. [[Finnish#^fi-Q0292|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Hapen%20reagoidessa%20vedyn%20kanssa%20syntyy%20vett%C3%A4.)
^fi-Q0292-answer

**fi-Q0293** — Juon aina joka aamu kupin kahvia.

I always drink a cup of coffee every morning.

Why: Partitive nouns. [[Finnish#^fi-Q0293|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Juon%20aina%20joka%20aamu%20kupin%20kahvia.)
^fi-Q0293-answer

**fi-Q0294** — Juon aina joka aamu kupin kahvia.

I always drink a cup of coffee every morning.

Partitive occurs in many quantities, negative objects and ongoing/unbounded object constructions. It is not merely the form for an indefinite English noun. Learn the case stem alongside the nominative.

Why: Partitive nouns. [[Finnish#^fi-Q0294|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Juon%20aina%20joka%20aamu%20kupin%20kahvia.)
^fi-Q0294-answer

**fi-Q0295** — Poliitikot ovat hyviä keräämään rahaa.

Politicians are good at raising money.

Expected form: **rahaa**

Why: Partitive nouns. [[Finnish#^fi-Q0295|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Poliitikot%20ovat%20hyvi%C3%A4%20ker%C3%A4%C3%A4m%C3%A4%C3%A4n%20rahaa.)
^fi-Q0295-answer

**fi-Q0296** — Poliitikot ovat hyviä keräämään rahaa.

Politicians are good at raising money.

Expected form: **rahaa**

Why: Partitive nouns. [[Finnish#^fi-Q0296|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Poliitikot%20ovat%20hyvi%C3%A4%20ker%C3%A4%C3%A4m%C3%A4%C3%A4n%20rahaa.)
^fi-Q0296-answer

**fi-Q0297** — Tomi antoi kodittomalle ruokaa.

Tom gave the homeless man some food.

Expected form: **ruokaa**

Why: Partitive nouns. [[Finnish#^fi-Q0297|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tomi%20antoi%20kodittomalle%20ruokaa.)
^fi-Q0297-answer

**fi-Q0298** — Tomi antoi kodittomalle ruokaa.

Tom gave the homeless man some food.

Why: Partitive nouns. [[Finnish#^fi-Q0298|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tomi%20antoi%20kodittomalle%20ruokaa.)
^fi-Q0298-answer

**fi-Q0299** — Minulla ei ole aikaa lukea.

I don't have time to read.

Why: Partitive nouns. [[Finnish#^fi-Q0299|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Minulla%20ei%20ole%20aikaa%20lukea.)
^fi-Q0299-answer

**fi-Q0300** — Minulla ei ole aikaa lukea.

I don't have time to read.

Partitive occurs in many quantities, negative objects and ongoing/unbounded object constructions. It is not merely the form for an indefinite English noun. Learn the case stem alongside the nominative.

Why: Partitive nouns. [[Finnish#^fi-Q0300|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Minulla%20ei%20ole%20aikaa%20lukea.)
^fi-Q0300-answer


### Answers 301–350

**fi-Q0301** — Haluan tuon koiran kuvan.

I want a picture of that dog.

Expected form: **koiran**

Why: Genitive singular. [[Finnish#^fi-Q0301|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Haluan%20tuon%20koiran%20kuvan.)
^fi-Q0301-answer

**fi-Q0302** — Haluan tuon koiran kuvan.

I want a picture of that dog.

Expected form: **koiran**

Why: Genitive singular. [[Finnish#^fi-Q0302|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Haluan%20tuon%20koiran%20kuvan.)
^fi-Q0302-answer

**fi-Q0303** — Ostin uuden auton viime sunnuntaina.

Last Sunday I bought a new car.

Expected form: **auton**

Why: Genitive singular. [[Finnish#^fi-Q0303|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Ostin%20uuden%20auton%20viime%20sunnuntaina.)
^fi-Q0303-answer

**fi-Q0304** — Ostin uuden auton viime sunnuntaina.

Last Sunday I bought a new car.

Why: Genitive singular. [[Finnish#^fi-Q0304|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Ostin%20uuden%20auton%20viime%20sunnuntaina.)
^fi-Q0304-answer

**fi-Q0305** — Tom osti uuden auton.

Tom bought a new car.

Why: Genitive singular. [[Finnish#^fi-Q0305|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tom%20osti%20uuden%20auton.)
^fi-Q0305-answer

**fi-Q0306** — Tom osti uuden auton.

Tom bought a new car.

Singular genitive often ends in -n with possible stem changes. It can express possession and participates in total-object marking in suitable constructions. The function depends on the sentence.

Why: Genitive singular. [[Finnish#^fi-Q0306|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tom%20osti%20uuden%20auton.)
^fi-Q0306-answer

**fi-Q0307** — Toivon että voisin ostaan tuon talon halvalla.

I wish I could buy that house cheap.

Expected form: **talon**

Why: Genitive singular. [[Finnish#^fi-Q0307|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Toivon%20ett%C3%A4%20voisin%20ostaan%20tuon%20talon%20halvalla.)
^fi-Q0307-answer

**fi-Q0308** — Toivon että voisin ostaan tuon talon halvalla.

I wish I could buy that house cheap.

Expected form: **talon**

Why: Genitive singular. [[Finnish#^fi-Q0308|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Toivon%20ett%C3%A4%20voisin%20ostaan%20tuon%20talon%20halvalla.)
^fi-Q0308-answer

**fi-Q0309** — Palautin kirjan takaisin hyllylleen.

I returned the book to its shelf.

Expected form: **kirjan**

Why: Genitive singular. [[Finnish#^fi-Q0309|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Palautin%20kirjan%20takaisin%20hyllylleen.)
^fi-Q0309-answer

**fi-Q0310** — Palautin kirjan takaisin hyllylleen.

I returned the book to its shelf.

Why: Genitive singular. [[Finnish#^fi-Q0310|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Palautin%20kirjan%20takaisin%20hyllylleen.)
^fi-Q0310-answer

**fi-Q0311** — Tom osti auton säästöillään.

Tom bought a car using his savings.

Why: Genitive singular. [[Finnish#^fi-Q0311|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tom%20osti%20auton%20s%C3%A4%C3%A4st%C3%B6ill%C3%A4%C3%A4n.)
^fi-Q0311-answer

**fi-Q0312** — Tom osti auton säästöillään.

Tom bought a car using his savings.

Singular genitive often ends in -n with possible stem changes. It can express possession and participates in total-object marking in suitable constructions. The function depends on the sentence.

Why: Genitive singular. [[Finnish#^fi-Q0312|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tom%20osti%20auton%20s%C3%A4%C3%A4st%C3%B6ill%C3%A4%C3%A4n.)
^fi-Q0312-answer

**fi-Q0313** — Hänen äänensä kaikui halki hiljaisen talon.

Her voice echoed through the silent house.

Expected form: **talon**

Why: Genitive singular. [[Finnish#^fi-Q0313|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=H%C3%A4nen%20%C3%A4%C3%A4nens%C3%A4%20kaikui%20halki%20hiljaisen%20talon.)
^fi-Q0313-answer

**fi-Q0314** — Hänen äänensä kaikui halki hiljaisen talon.

Her voice echoed through the silent house.

Expected form: **talon**

Why: Genitive singular. [[Finnish#^fi-Q0314|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=H%C3%A4nen%20%C3%A4%C3%A4nens%C3%A4%20kaikui%20halki%20hiljaisen%20talon.)
^fi-Q0314-answer

**fi-Q0315** — Tom siivosi talon yksinään.

Tom cleaned the house by himself.

Expected form: **talon**

Why: Genitive singular. [[Finnish#^fi-Q0315|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tom%20siivosi%20talon%20yksin%C3%A4%C3%A4n.)
^fi-Q0315-answer

**fi-Q0316** — Tom siivosi talon yksinään.

Tom cleaned the house by himself.

Why: Genitive singular. [[Finnish#^fi-Q0316|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tom%20siivosi%20talon%20yksin%C3%A4%C3%A4n.)
^fi-Q0316-answer

**fi-Q0317** — Minä löysin sen kirjan sattumalta.

I found the book by chance.

Why: Genitive singular. [[Finnish#^fi-Q0317|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Min%C3%A4%20l%C3%B6ysin%20sen%20kirjan%20sattumalta.)
^fi-Q0317-answer

**fi-Q0318** — Minä löysin sen kirjan sattumalta.

I found the book by chance.

Singular genitive often ends in -n with possible stem changes. It can express possession and participates in total-object marking in suitable constructions. The function depends on the sentence.

Why: Genitive singular. [[Finnish#^fi-Q0318|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Min%C3%A4%20l%C3%B6ysin%20sen%20kirjan%20sattumalta.)
^fi-Q0318-answer

**fi-Q0319** — Oletko nähnyt Tomin uuden talon?

Have you seen Tom's new house?

Expected form: **talon**

Why: Genitive singular. [[Finnish#^fi-Q0319|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Oletko%20n%C3%A4hnyt%20Tomin%20uuden%20talon%3F)
^fi-Q0319-answer

**fi-Q0320** — Oletko nähnyt Tomin uuden talon?

Have you seen Tom's new house?

Expected form: **talon**

Why: Genitive singular. [[Finnish#^fi-Q0320|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Oletko%20n%C3%A4hnyt%20Tomin%20uuden%20talon%3F)
^fi-Q0320-answer

**fi-Q0321** — Kuulitko jutun benjihyppääjästä, joka kuoli, koska hän laski väärin jokaisen kerroksen korkeuden ennen kuin hyppäsi alas talon katolta.

Did you hear the story about the bungee jumper who died because he miscalculated the height of each storey before diving off a building?

Expected form: **talon**

Why: Genitive singular. [[Finnish#^fi-Q0321|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Kuulitko%20jutun%20benjihypp%C3%A4%C3%A4j%C3%A4st%C3%A4%2C%20joka%20kuoli%2C%20koska%20h%C3%A4n%20laski%20v%C3%A4%C3%A4rin%20jokaisen%20kerroksen%20korkeuden%20ennen%20kuin%20hypp%C3%A4si%20alas%20talon%20katolta.)
^fi-Q0321-answer

**fi-Q0322** — Kuulitko jutun benjihyppääjästä, joka kuoli, koska hän laski väärin jokaisen kerroksen korkeuden ennen kuin hyppäsi alas talon katolta.

Did you hear the story about the bungee jumper who died because he miscalculated the height of each storey before diving off a building?

Why: Genitive singular. [[Finnish#^fi-Q0322|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Kuulitko%20jutun%20benjihypp%C3%A4%C3%A4j%C3%A4st%C3%A4%2C%20joka%20kuoli%2C%20koska%20h%C3%A4n%20laski%20v%C3%A4%C3%A4rin%20jokaisen%20kerroksen%20korkeuden%20ennen%20kuin%20hypp%C3%A4si%20alas%20talon%20katolta.)
^fi-Q0322-answer

**fi-Q0323** — Näen erään naisen mustissa.

I see a woman wearing black.

Why: Genitive singular. [[Finnish#^fi-Q0323|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=N%C3%A4en%20er%C3%A4%C3%A4n%20naisen%20mustissa.)
^fi-Q0323-answer

**fi-Q0324** — Näen erään naisen mustissa.

I see a woman wearing black.

Singular genitive often ends in -n with possible stem changes. It can express possession and participates in total-object marking in suitable constructions. The function depends on the sentence.

Why: Genitive singular. [[Finnish#^fi-Q0324|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=N%C3%A4en%20er%C3%A4%C3%A4n%20naisen%20mustissa.)
^fi-Q0324-answer

**fi-Q0325** — Hän pani kirjan pöydälle.

He laid the book on the desk.

Expected form: **kirjan**

Why: Genitive singular. [[Finnish#^fi-Q0325|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=H%C3%A4n%20pani%20kirjan%20p%C3%B6yd%C3%A4lle.)
^fi-Q0325-answer

**fi-Q0326** — Hän pani kirjan pöydälle.

He laid the book on the desk.

Expected form: **kirjan**

Why: Genitive singular. [[Finnish#^fi-Q0326|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=H%C3%A4n%20pani%20kirjan%20p%C3%B6yd%C3%A4lle.)
^fi-Q0326-answer

**fi-Q0327** — Kahden lapsen iät yhdessä vastasivat heidän isänsä ikää.

The ages of the two children put together was equivalent to that of their father.

Expected form: **lapsen**

Why: Genitive singular. [[Finnish#^fi-Q0327|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Kahden%20lapsen%20i%C3%A4t%20yhdess%C3%A4%20vastasivat%20heid%C3%A4n%20is%C3%A4ns%C3%A4%20ik%C3%A4%C3%A4.)
^fi-Q0327-answer

**fi-Q0328** — Kahden lapsen iät yhdessä vastasivat heidän isänsä ikää.

The ages of the two children put together was equivalent to that of their father.

Why: Genitive singular. [[Finnish#^fi-Q0328|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Kahden%20lapsen%20i%C3%A4t%20yhdess%C3%A4%20vastasivat%20heid%C3%A4n%20is%C3%A4ns%C3%A4%20ik%C3%A4%C3%A4.)
^fi-Q0328-answer

**fi-Q0329** — Tom näki Marin toisen miehen seurassa.

Tom saw Mary with another man.

Why: Genitive singular. [[Finnish#^fi-Q0329|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tom%20n%C3%A4ki%20Marin%20toisen%20miehen%20seurassa.)
^fi-Q0329-answer

**fi-Q0330** — Tom näki Marin toisen miehen seurassa.

Tom saw Mary with another man.

Singular genitive often ends in -n with possible stem changes. It can express possession and participates in total-object marking in suitable constructions. The function depends on the sentence.

Why: Genitive singular. [[Finnish#^fi-Q0330|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tom%20n%C3%A4ki%20Marin%20toisen%20miehen%20seurassa.)
^fi-Q0330-answer

**fi-Q0331** — Näen miehen ja naisen.

I see a man and a woman.

Expected form: **miehen**

Why: Genitive singular. [[Finnish#^fi-Q0331|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=N%C3%A4en%20miehen%20ja%20naisen.)
^fi-Q0331-answer

**fi-Q0332** — Näen miehen ja naisen.

I see a man and a woman.

Expected form: **miehen**

Why: Genitive singular. [[Finnish#^fi-Q0332|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=N%C3%A4en%20miehen%20ja%20naisen.)
^fi-Q0332-answer

**fi-Q0333** — Olen jo lukenut tämän kirjan loppuun.

I have already finished reading this book.

Expected form: **kirjan**

Why: Genitive singular. [[Finnish#^fi-Q0333|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Olen%20jo%20lukenut%20t%C3%A4m%C3%A4n%20kirjan%20loppuun.)
^fi-Q0333-answer

**fi-Q0334** — Olen jo lukenut tämän kirjan loppuun.

I have already finished reading this book.

Why: Genitive singular. [[Finnish#^fi-Q0334|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Olen%20jo%20lukenut%20t%C3%A4m%C3%A4n%20kirjan%20loppuun.)
^fi-Q0334-answer

**fi-Q0335** — Minun isäni osti minulle tuon kirjan.

My father bought me the book.

Why: Genitive singular. [[Finnish#^fi-Q0335|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Minun%20is%C3%A4ni%20osti%20minulle%20tuon%20kirjan.)
^fi-Q0335-answer

**fi-Q0336** — Minun isäni osti minulle tuon kirjan.

My father bought me the book.

Singular genitive often ends in -n with possible stem changes. It can express possession and participates in total-object marking in suitable constructions. The function depends on the sentence.

Why: Genitive singular. [[Finnish#^fi-Q0336|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Minun%20is%C3%A4ni%20osti%20minulle%20tuon%20kirjan.)
^fi-Q0336-answer

**fi-Q0337** — Mistä voin vuokrata auton?

Where can I hire a car?

Expected form: **auton**

Why: Genitive singular. [[Finnish#^fi-Q0337|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Mist%C3%A4%20voin%20vuokrata%20auton%3F)
^fi-Q0337-answer

**fi-Q0338** — Mistä voin vuokrata auton?

Where can I hire a car?

Expected form: **auton**

Why: Genitive singular. [[Finnish#^fi-Q0338|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Mist%C3%A4%20voin%20vuokrata%20auton%3F)
^fi-Q0338-answer

**fi-Q0339** — Hän käänsi kirjan ranskasta englanniksi.

He translated the book from French into English.

Expected form: **kirjan**

Why: Genitive singular. [[Finnish#^fi-Q0339|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=H%C3%A4n%20k%C3%A4%C3%A4nsi%20kirjan%20ranskasta%20englanniksi.)
^fi-Q0339-answer

**fi-Q0340** — Hän käänsi kirjan ranskasta englanniksi.

He translated the book from French into English.

Why: Genitive singular. [[Finnish#^fi-Q0340|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=H%C3%A4n%20k%C3%A4%C3%A4nsi%20kirjan%20ranskasta%20englanniksi.)
^fi-Q0340-answer

**fi-Q0341** — Näin puistossa nuoren miehen makoilevan penkillä kirsikkapuun alla.

I saw a young man lying on the bench under the cherry tree in the park.

Why: Genitive singular. [[Finnish#^fi-Q0341|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=N%C3%A4in%20puistossa%20nuoren%20miehen%20makoilevan%20penkill%C3%A4%20kirsikkapuun%20alla.)
^fi-Q0341-answer

**fi-Q0342** — Näin puistossa nuoren miehen makoilevan penkillä kirsikkapuun alla.

I saw a young man lying on the bench under the cherry tree in the park.

Singular genitive often ends in -n with possible stem changes. It can express possession and participates in total-object marking in suitable constructions. The function depends on the sentence.

Why: Genitive singular. [[Finnish#^fi-Q0342|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=N%C3%A4in%20puistossa%20nuoren%20miehen%20makoilevan%20penkill%C3%A4%20kirsikkapuun%20alla.)
^fi-Q0342-answer

**fi-Q0343** — Minun vaimoni haluaa adoptoida lapsen.

My wife wants to adopt a child.

Expected form: **lapsen**

Why: Genitive singular. [[Finnish#^fi-Q0343|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Minun%20vaimoni%20haluaa%20adoptoida%20lapsen.)
^fi-Q0343-answer

**fi-Q0344** — Minun vaimoni haluaa adoptoida lapsen.

My wife wants to adopt a child.

Expected form: **lapsen**

Why: Genitive singular. [[Finnish#^fi-Q0344|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Minun%20vaimoni%20haluaa%20adoptoida%20lapsen.)
^fi-Q0344-answer

**fi-Q0345** — Haluan sinun pesevän auton.

I want you to wash the car.

Expected form: **auton**

Why: Genitive singular. [[Finnish#^fi-Q0345|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Haluan%20sinun%20pesev%C3%A4n%20auton.)
^fi-Q0345-answer

**fi-Q0346** — Haluan sinun pesevän auton.

I want you to wash the car.

Why: Genitive singular. [[Finnish#^fi-Q0346|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Haluan%20sinun%20pesev%C3%A4n%20auton.)
^fi-Q0346-answer

**fi-Q0347** — Haluan auton, mutta minulla ei ole rahaa ostaa sellaista.

I want a car, but I have no money to buy one.

Why: Genitive singular. [[Finnish#^fi-Q0347|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Haluan%20auton%2C%20mutta%20minulla%20ei%20ole%20rahaa%20ostaa%20sellaista.)
^fi-Q0347-answer

**fi-Q0348** — Haluan auton, mutta minulla ei ole rahaa ostaa sellaista.

I want a car, but I have no money to buy one.

Singular genitive often ends in -n with possible stem changes. It can express possession and participates in total-object marking in suitable constructions. The function depends on the sentence.

Why: Genitive singular. [[Finnish#^fi-Q0348|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Haluan%20auton%2C%20mutta%20minulla%20ei%20ole%20rahaa%20ostaa%20sellaista.)
^fi-Q0348-answer

**fi-Q0349** — Järjestimme auton tulemaan vastaan sinua asemalle.

We arranged that a car meet you at the station.

Expected form: **auton**

Why: Genitive singular. [[Finnish#^fi-Q0349|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=J%C3%A4rjestimme%20auton%20tulemaan%20vastaan%20sinua%20asemalle.)
^fi-Q0349-answer

**fi-Q0350** — Järjestimme auton tulemaan vastaan sinua asemalle.

We arranged that a car meet you at the station.

Expected form: **auton**

Why: Genitive singular. [[Finnish#^fi-Q0350|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=J%C3%A4rjestimme%20auton%20tulemaan%20vastaan%20sinua%20asemalle.)
^fi-Q0350-answer


### Answers 351–400

**fi-Q0351** — Tomi vietti puolet elämästään Bostonissa.

Tom lived half his life in Boston.

Expected form: **Bostonissa**

Why: Inessive location. [[Finnish#^fi-Q0351|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tomi%20vietti%20puolet%20el%C3%A4m%C3%A4st%C3%A4%C3%A4n%20Bostonissa.)
^fi-Q0351-answer

**fi-Q0352** — Tomi vietti puolet elämästään Bostonissa.

Tom lived half his life in Boston.

Why: Inessive location. [[Finnish#^fi-Q0352|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tomi%20vietti%20puolet%20el%C3%A4m%C3%A4st%C3%A4%C3%A4n%20Bostonissa.)
^fi-Q0352-answer

**fi-Q0353** — Tom vaikutti tuijottavan jotain huoneen nurkassa.

Tom seemed to be staring at something in the corner of the room.

Why: Inessive location. [[Finnish#^fi-Q0353|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tom%20vaikutti%20tuijottavan%20jotain%20huoneen%20nurkassa.)
^fi-Q0353-answer

**fi-Q0354** — Tom vaikutti tuijottavan jotain huoneen nurkassa.

Tom seemed to be staring at something in the corner of the room.

Inessive -ssa/-ssä expresses many inside/location relations. Vowel harmony chooses the variant. Words such as missä contain the same case relation in an interrogative form.

Why: Inessive location. [[Finnish#^fi-Q0354|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tom%20vaikutti%20tuijottavan%20jotain%20huoneen%20nurkassa.)
^fi-Q0354-answer

**fi-Q0355** — Kävin suihkussa ennen aamupalaa.

I showered before breakfast.

Expected form: **suihkussa**

Why: Inessive location. [[Finnish#^fi-Q0355|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=K%C3%A4vin%20suihkussa%20ennen%20aamupalaa.)
^fi-Q0355-answer

**fi-Q0356** — Kävin suihkussa ennen aamupalaa.

I showered before breakfast.

Expected form: **suihkussa**

Why: Inessive location. [[Finnish#^fi-Q0356|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=K%C3%A4vin%20suihkussa%20ennen%20aamupalaa.)
^fi-Q0356-answer

**fi-Q0357** — Minun veljeni asuu Tokiossa.

My brother lives in Tokyo.

Expected form: **Tokiossa**

Why: Inessive location. [[Finnish#^fi-Q0357|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Minun%20veljeni%20asuu%20Tokiossa.)
^fi-Q0357-answer

**fi-Q0358** — Minun veljeni asuu Tokiossa.

My brother lives in Tokyo.

Why: Inessive location. [[Finnish#^fi-Q0358|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Minun%20veljeni%20asuu%20Tokiossa.)
^fi-Q0358-answer

**fi-Q0359** — Parempi ystävä pivossa kuin kymmenen oksalla.

A friend in hand is worth two in the bush!

Why: Inessive location. [[Finnish#^fi-Q0359|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Parempi%20yst%C3%A4v%C3%A4%20pivossa%20kuin%20kymmenen%20oksalla.)
^fi-Q0359-answer

**fi-Q0360** — Parempi ystävä pivossa kuin kymmenen oksalla.

A friend in hand is worth two in the bush!

Inessive -ssa/-ssä expresses many inside/location relations. Vowel harmony chooses the variant. Words such as missä contain the same case relation in an interrogative form.

Why: Inessive location. [[Finnish#^fi-Q0360|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Parempi%20yst%C3%A4v%C3%A4%20pivossa%20kuin%20kymmenen%20oksalla.)
^fi-Q0360-answer

**fi-Q0361** — Onko Tom yhtään paremmassa kunnossa?

Is Tom any better?

Expected form: **paremmassa**

Why: Inessive location. [[Finnish#^fi-Q0361|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Onko%20Tom%20yht%C3%A4%C3%A4n%20paremmassa%20kunnossa%3F)
^fi-Q0361-answer

**fi-Q0362** — Onko Tom yhtään paremmassa kunnossa?

Is Tom any better?

Expected form: **paremmassa**

Why: Inessive location. [[Finnish#^fi-Q0362|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Onko%20Tom%20yht%C3%A4%C3%A4n%20paremmassa%20kunnossa%3F)
^fi-Q0362-answer

**fi-Q0363** — Hänet tapettiin taistelussa.

He was killed in the battle.

Expected form: **taistelussa**

Why: Inessive location. [[Finnish#^fi-Q0363|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=H%C3%A4net%20tapettiin%20taistelussa.)
^fi-Q0363-answer

**fi-Q0364** — Hänet tapettiin taistelussa.

He was killed in the battle.

Why: Inessive location. [[Finnish#^fi-Q0364|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=H%C3%A4net%20tapettiin%20taistelussa.)
^fi-Q0364-answer

**fi-Q0365** — Antamalla meidän tietoomme oppimattomien mielipiteitä journalismi pitää meidät yhteydessä yhteisön tietämättömyyteen.

By giving us the opinions of the uneducated, journalism keeps us in touch with the ignorance of the community.

Why: Inessive location. [[Finnish#^fi-Q0365|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Antamalla%20meid%C3%A4n%20tietoomme%20oppimattomien%20mielipiteit%C3%A4%20journalismi%20pit%C3%A4%C3%A4%20meid%C3%A4t%20yhteydess%C3%A4%20yhteis%C3%B6n%20tiet%C3%A4m%C3%A4tt%C3%B6myyteen.)
^fi-Q0365-answer

**fi-Q0366** — Antamalla meidän tietoomme oppimattomien mielipiteitä journalismi pitää meidät yhteydessä yhteisön tietämättömyyteen.

By giving us the opinions of the uneducated, journalism keeps us in touch with the ignorance of the community.

Inessive -ssa/-ssä expresses many inside/location relations. Vowel harmony chooses the variant. Words such as missä contain the same case relation in an interrogative form.

Why: Inessive location. [[Finnish#^fi-Q0366|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Antamalla%20meid%C3%A4n%20tietoomme%20oppimattomien%20mielipiteit%C3%A4%20journalismi%20pit%C3%A4%C3%A4%20meid%C3%A4t%20yhteydess%C3%A4%20yhteis%C3%B6n%20tiet%C3%A4m%C3%A4tt%C3%B6myyteen.)
^fi-Q0366-answer

**fi-Q0367** — Luulin, että menisit Tomin kanssa.

I thought you'd gone with Tom.

Expected form: **kanssa**

Why: Inessive location. [[Finnish#^fi-Q0367|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Luulin%2C%20ett%C3%A4%20menisit%20Tomin%20kanssa.)
^fi-Q0367-answer

**fi-Q0368** — Luulin, että menisit Tomin kanssa.

I thought you'd gone with Tom.

Expected form: **kanssa**

Why: Inessive location. [[Finnish#^fi-Q0368|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Luulin%2C%20ett%C3%A4%20menisit%20Tomin%20kanssa.)
^fi-Q0368-answer

**fi-Q0369** — Vesi kiehuu sadassa asteessa.

Water boils at 100 degrees.

Expected form: **sadassa**

Why: Inessive location. [[Finnish#^fi-Q0369|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Vesi%20kiehuu%20sadassa%20asteessa.)
^fi-Q0369-answer

**fi-Q0370** — Vesi kiehuu sadassa asteessa.

Water boils at 100 degrees.

Why: Inessive location. [[Finnish#^fi-Q0370|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Vesi%20kiehuu%20sadassa%20asteessa.)
^fi-Q0370-answer

**fi-Q0371** — Hän vietti suurimman osan päivästä sairaalassa.

She spent most of the day at the hospital.

Why: Inessive location. [[Finnish#^fi-Q0371|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=H%C3%A4n%20vietti%20suurimman%20osan%20p%C3%A4iv%C3%A4st%C3%A4%20sairaalassa.)
^fi-Q0371-answer

**fi-Q0372** — Hän vietti suurimman osan päivästä sairaalassa.

She spent most of the day at the hospital.

Inessive -ssa/-ssä expresses many inside/location relations. Vowel harmony chooses the variant. Words such as missä contain the same case relation in an interrogative form.

Why: Inessive location. [[Finnish#^fi-Q0372|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=H%C3%A4n%20vietti%20suurimman%20osan%20p%C3%A4iv%C3%A4st%C3%A4%20sairaalassa.)
^fi-Q0372-answer

**fi-Q0373** — Minulla on Ranskan kansalaisuus, mutta juuret Vietnamissa.

I have French nationality but Vietnamese origins.

Expected form: **Vietnamissa**

Why: Inessive location. [[Finnish#^fi-Q0373|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Minulla%20on%20Ranskan%20kansalaisuus%2C%20mutta%20juuret%20Vietnamissa.)
^fi-Q0373-answer

**fi-Q0374** — Minulla on Ranskan kansalaisuus, mutta juuret Vietnamissa.

I have French nationality but Vietnamese origins.

Expected form: **Vietnamissa**

Why: Inessive location. [[Finnish#^fi-Q0374|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Minulla%20on%20Ranskan%20kansalaisuus%2C%20mutta%20juuret%20Vietnamissa.)
^fi-Q0374-answer

**fi-Q0375** — Minä olen tulossa.

I'm coming.

Expected form: **tulossa**

Why: Inessive location. [[Finnish#^fi-Q0375|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Min%C3%A4%20olen%20tulossa.)
^fi-Q0375-answer

**fi-Q0376** — Minä olen tulossa.

I'm coming.

Why: Inessive location. [[Finnish#^fi-Q0376|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Min%C3%A4%20olen%20tulossa.)
^fi-Q0376-answer

**fi-Q0377** — No mikä tässä on sitten ongelma?

Then what's the problem?

Why: Inessive location. [[Finnish#^fi-Q0377|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=No%20mik%C3%A4%20t%C3%A4ss%C3%A4%20on%20sitten%20ongelma%3F)
^fi-Q0377-answer

**fi-Q0378** — No mikä tässä on sitten ongelma?

Then what's the problem?

Inessive -ssa/-ssä expresses many inside/location relations. Vowel harmony chooses the variant. Words such as missä contain the same case relation in an interrogative form.

Why: Inessive location. [[Finnish#^fi-Q0378|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=No%20mik%C3%A4%20t%C3%A4ss%C3%A4%20on%20sitten%20ongelma%3F)
^fi-Q0378-answer

**fi-Q0379** — Onko se totta, että ette olleet tässä eilen?

Is it true that you weren't here yesterday?

Expected form: **tässä**

Why: Inessive location. [[Finnish#^fi-Q0379|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Onko%20se%20totta%2C%20ett%C3%A4%20ette%20olleet%20t%C3%A4ss%C3%A4%20eilen%3F)
^fi-Q0379-answer

**fi-Q0380** — Onko se totta, että ette olleet tässä eilen?

Is it true that you weren't here yesterday?

Expected form: **tässä**

Why: Inessive location. [[Finnish#^fi-Q0380|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Onko%20se%20totta%2C%20ett%C3%A4%20ette%20olleet%20t%C3%A4ss%C3%A4%20eilen%3F)
^fi-Q0380-answer

**fi-Q0381** — Haluaisin opiskella kemiaa yliopistossa.

I'd like to study chemistry at college.

Expected form: **yliopistossa**

Why: Inessive location. [[Finnish#^fi-Q0381|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Haluaisin%20opiskella%20kemiaa%20yliopistossa.)
^fi-Q0381-answer

**fi-Q0382** — Haluaisin opiskella kemiaa yliopistossa.

I'd like to study chemistry at college.

Why: Inessive location. [[Finnish#^fi-Q0382|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Haluaisin%20opiskella%20kemiaa%20yliopistossa.)
^fi-Q0382-answer

**fi-Q0383** — Sami ei näyttänyt olevan paniikissa.

Sami didn't look panicked.

Why: Inessive location. [[Finnish#^fi-Q0383|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Sami%20ei%20n%C3%A4ytt%C3%A4nyt%20olevan%20paniikissa.)
^fi-Q0383-answer

**fi-Q0384** — Sami ei näyttänyt olevan paniikissa.

Sami didn't look panicked.

Inessive -ssa/-ssä expresses many inside/location relations. Vowel harmony chooses the variant. Words such as missä contain the same case relation in an interrogative form.

Why: Inessive location. [[Finnish#^fi-Q0384|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Sami%20ei%20n%C3%A4ytt%C3%A4nyt%20olevan%20paniikissa.)
^fi-Q0384-answer

**fi-Q0385** — Hän siinä on ikkunassa.

That's him at the window.

Expected form: **ikkunassa**

Why: Inessive location. [[Finnish#^fi-Q0385|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=H%C3%A4n%20siin%C3%A4%20on%20ikkunassa.)
^fi-Q0385-answer

**fi-Q0386** — Hän siinä on ikkunassa.

That's him at the window.

Expected form: **ikkunassa**

Why: Inessive location. [[Finnish#^fi-Q0386|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=H%C3%A4n%20siin%C3%A4%20on%20ikkunassa.)
^fi-Q0386-answer

**fi-Q0387** — Tomi on sinkku eikä ole koskaan ollut naimisissa.

Tom is single and has never been married.

Expected form: **naimisissa**

Why: Inessive location. [[Finnish#^fi-Q0387|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tomi%20on%20sinkku%20eik%C3%A4%20ole%20koskaan%20ollut%20naimisissa.)
^fi-Q0387-answer

**fi-Q0388** — Tomi on sinkku eikä ole koskaan ollut naimisissa.

Tom is single and has never been married.

Why: Inessive location. [[Finnish#^fi-Q0388|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tomi%20on%20sinkku%20eik%C3%A4%20ole%20koskaan%20ollut%20naimisissa.)
^fi-Q0388-answer

**fi-Q0389** — Onko olemassa mitään toivoa?

Is there any hope whatsoever?

Why: Inessive location. [[Finnish#^fi-Q0389|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Onko%20olemassa%20mit%C3%A4%C3%A4n%20toivoa%3F)
^fi-Q0389-answer

**fi-Q0390** — Onko olemassa mitään toivoa?

Is there any hope whatsoever?

Inessive -ssa/-ssä expresses many inside/location relations. Vowel harmony chooses the variant. Words such as missä contain the same case relation in an interrogative form.

Why: Inessive location. [[Finnish#^fi-Q0390|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Onko%20olemassa%20mit%C3%A4%C3%A4n%20toivoa%3F)
^fi-Q0390-answer

**fi-Q0391** — Tom tuli paikalle kolme minuuttia etuajassa.

Tom arrived three minutes early.

Expected form: **etuajassa**

Why: Inessive location. [[Finnish#^fi-Q0391|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tom%20tuli%20paikalle%20kolme%20minuuttia%20etuajassa.)
^fi-Q0391-answer

**fi-Q0392** — Tom tuli paikalle kolme minuuttia etuajassa.

Tom arrived three minutes early.

Expected form: **etuajassa**

Why: Inessive location. [[Finnish#^fi-Q0392|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tom%20tuli%20paikalle%20kolme%20minuuttia%20etuajassa.)
^fi-Q0392-answer

**fi-Q0393** — Eikö mitään ole tehtävissä?

Can't anything be done?

Expected form: **tehtävissä**

Why: Inessive location. [[Finnish#^fi-Q0393|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Eik%C3%B6%20mit%C3%A4%C3%A4n%20ole%20teht%C3%A4viss%C3%A4%3F)
^fi-Q0393-answer

**fi-Q0394** — Eikö mitään ole tehtävissä?

Can't anything be done?

Why: Inessive location. [[Finnish#^fi-Q0394|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Eik%C3%B6%20mit%C3%A4%C3%A4n%20ole%20teht%C3%A4viss%C3%A4%3F)
^fi-Q0394-answer

**fi-Q0395** — Jätä vaan kaikki siihen missä ne ovat.

Just leave everything where it is.

Why: Inessive location. [[Finnish#^fi-Q0395|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=J%C3%A4t%C3%A4%20vaan%20kaikki%20siihen%20miss%C3%A4%20ne%20ovat.)
^fi-Q0395-answer

**fi-Q0396** — Jätä vaan kaikki siihen missä ne ovat.

Just leave everything where it is.

Inessive -ssa/-ssä expresses many inside/location relations. Vowel harmony chooses the variant. Words such as missä contain the same case relation in an interrogative form.

Why: Inessive location. [[Finnish#^fi-Q0396|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=J%C3%A4t%C3%A4%20vaan%20kaikki%20siihen%20miss%C3%A4%20ne%20ovat.)
^fi-Q0396-answer

**fi-Q0397** — Ystäväni on odottamassa minua aulassa.

I have a friend waiting for me in the lobby.

Expected form: **odottamassa**

Why: Inessive location. [[Finnish#^fi-Q0397|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Yst%C3%A4v%C3%A4ni%20on%20odottamassa%20minua%20aulassa.)
^fi-Q0397-answer

**fi-Q0398** — Ystäväni on odottamassa minua aulassa.

I have a friend waiting for me in the lobby.

Expected form: **odottamassa**

Why: Inessive location. [[Finnish#^fi-Q0398|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Yst%C3%A4v%C3%A4ni%20on%20odottamassa%20minua%20aulassa.)
^fi-Q0398-answer

**fi-Q0399** — Tämä mies on elossa.

This man is alive.

Expected form: **elossa**

Why: Inessive location. [[Finnish#^fi-Q0399|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=T%C3%A4m%C3%A4%20mies%20on%20elossa.)
^fi-Q0399-answer

**fi-Q0400** — Tämä mies on elossa.

This man is alive.

Why: Inessive location. [[Finnish#^fi-Q0400|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=T%C3%A4m%C3%A4%20mies%20on%20elossa.)
^fi-Q0400-answer


### Answers 401–450

**fi-Q0401** — Ethän kerro tästä kenellekään.

Please don't tell anybody about this.

Why: Elative source. [[Finnish#^fi-Q0401|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Eth%C3%A4n%20kerro%20t%C3%A4st%C3%A4%20kenellek%C3%A4%C3%A4n.)
^fi-Q0401-answer

**fi-Q0402** — Ethän kerro tästä kenellekään.

Please don't tell anybody about this.

Elative -sta/-stä expresses movement out of, source and some governed complements. The noun stem may change before the ending. A word’s suffix must be checked against its actual paradigm.

Why: Elative source. [[Finnish#^fi-Q0402|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Eth%C3%A4n%20kerro%20t%C3%A4st%C3%A4%20kenellek%C3%A4%C3%A4n.)
^fi-Q0402-answer

**fi-Q0403** — Tomi kadehti Marin menestystä.

Tom envied Mary's success.

Expected form: **menestystä**

Why: Elative source. [[Finnish#^fi-Q0403|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tomi%20kadehti%20Marin%20menestyst%C3%A4.)
^fi-Q0403-answer

**fi-Q0404** — Tomi kadehti Marin menestystä.

Tom envied Mary's success.

Expected form: **menestystä**

Why: Elative source. [[Finnish#^fi-Q0404|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tomi%20kadehti%20Marin%20menestyst%C3%A4.)
^fi-Q0404-answer

**fi-Q0405** — Mä tykkään sun kavereista.

I like your friends.

Expected form: **kavereista**

Why: Elative source. [[Finnish#^fi-Q0405|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=M%C3%A4%20tykk%C3%A4%C3%A4n%20sun%20kavereista.)
^fi-Q0405-answer

**fi-Q0406** — Mä tykkään sun kavereista.

I like your friends.

Why: Elative source. [[Finnish#^fi-Q0406|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=M%C3%A4%20tykk%C3%A4%C3%A4n%20sun%20kavereista.)
^fi-Q0406-answer

**fi-Q0407** — Etkö pelaa tennistä?

Do you not play tennis?

Why: Elative source. [[Finnish#^fi-Q0407|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Etk%C3%B6%20pelaa%20tennist%C3%A4%3F)
^fi-Q0407-answer

**fi-Q0408** — Etkö pelaa tennistä?

Do you not play tennis?

Elative -sta/-stä expresses movement out of, source and some governed complements. The noun stem may change before the ending. A word’s suffix must be checked against its actual paradigm.

Why: Elative source. [[Finnish#^fi-Q0408|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Etk%C3%B6%20pelaa%20tennist%C3%A4%3F)
^fi-Q0408-answer

**fi-Q0409** — Minun pitää juosta.

I must run.

Expected form: **juosta**

Why: Elative source. [[Finnish#^fi-Q0409|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Minun%20pit%C3%A4%C3%A4%20juosta.)
^fi-Q0409-answer

**fi-Q0410** — Minun pitää juosta.

I must run.

Expected form: **juosta**

Why: Elative source. [[Finnish#^fi-Q0410|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Minun%20pit%C3%A4%C3%A4%20juosta.)
^fi-Q0410-answer

**fi-Q0411** — Sinun täytyy murtautua ulos noidankehästä.

You must break the vicious circle.

Expected form: **noidankehästä**

Why: Elative source. [[Finnish#^fi-Q0411|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Sinun%20t%C3%A4ytyy%20murtautua%20ulos%20noidankeh%C3%A4st%C3%A4.)
^fi-Q0411-answer

**fi-Q0412** — Sinun täytyy murtautua ulos noidankehästä.

You must break the vicious circle.

Why: Elative source. [[Finnish#^fi-Q0412|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Sinun%20t%C3%A4ytyy%20murtautua%20ulos%20noidankeh%C3%A4st%C3%A4.)
^fi-Q0412-answer

**fi-Q0413** — Lisälääkäreistä on kipeä tarve.

There is an urgent need for more doctors.

Why: Elative source. [[Finnish#^fi-Q0413|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Lis%C3%A4l%C3%A4%C3%A4k%C3%A4reist%C3%A4%20on%20kipe%C3%A4%20tarve.)
^fi-Q0413-answer

**fi-Q0414** — Lisälääkäreistä on kipeä tarve.

There is an urgent need for more doctors.

Elative -sta/-stä expresses movement out of, source and some governed complements. The noun stem may change before the ending. A word’s suffix must be checked against its actual paradigm.

Why: Elative source. [[Finnish#^fi-Q0414|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Lis%C3%A4l%C3%A4%C3%A4k%C3%A4reist%C3%A4%20on%20kipe%C3%A4%20tarve.)
^fi-Q0414-answer

**fi-Q0415** — Tosi filosofia on asioiden näkemistä sellaisenaan kuin ne ovat.

True philosophy is seeing things as they are.

Expected form: **näkemistä**

Why: Elative source. [[Finnish#^fi-Q0415|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tosi%20filosofia%20on%20asioiden%20n%C3%A4kemist%C3%A4%20sellaisenaan%20kuin%20ne%20ovat.)
^fi-Q0415-answer

**fi-Q0416** — Tosi filosofia on asioiden näkemistä sellaisenaan kuin ne ovat.

True philosophy is seeing things as they are.

Expected form: **näkemistä**

Why: Elative source. [[Finnish#^fi-Q0416|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tosi%20filosofia%20on%20asioiden%20n%C3%A4kemist%C3%A4%20sellaisenaan%20kuin%20ne%20ovat.)
^fi-Q0416-answer

**fi-Q0417** — En tykkää mausteisesta ruoasta.

I don't like spicy food.

Expected form: **mausteisesta**

Why: Elative source. [[Finnish#^fi-Q0417|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=En%20tykk%C3%A4%C3%A4%20mausteisesta%20ruoasta.)
^fi-Q0417-answer

**fi-Q0418** — En tykkää mausteisesta ruoasta.

I don't like spicy food.

Why: Elative source. [[Finnish#^fi-Q0418|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=En%20tykk%C3%A4%C3%A4%20mausteisesta%20ruoasta.)
^fi-Q0418-answer

**fi-Q0419** — Angela ei saanut unen päästä kiinni sinä yönä.

Angela didn't sleep a wink that night.

Why: Elative source. [[Finnish#^fi-Q0419|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Angela%20ei%20saanut%20unen%20p%C3%A4%C3%A4st%C3%A4%20kiinni%20sin%C3%A4%20y%C3%B6n%C3%A4.)
^fi-Q0419-answer

**fi-Q0420** — Angela ei saanut unen päästä kiinni sinä yönä.

Angela didn't sleep a wink that night.

Elative -sta/-stä expresses movement out of, source and some governed complements. The noun stem may change before the ending. A word’s suffix must be checked against its actual paradigm.

Why: Elative source. [[Finnish#^fi-Q0420|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Angela%20ei%20saanut%20unen%20p%C3%A4%C3%A4st%C3%A4%20kiinni%20sin%C3%A4%20y%C3%B6n%C3%A4.)
^fi-Q0420-answer

**fi-Q0421** — Aika ajoin olemme ponnistelleet pitääksemme lupauksemme vapaudesta ja tasa-arvosta koko kansallemme.

At times, we've struggled to keep the promise of liberty and equality for all of our people.

Expected form: **vapaudesta**

Why: Elative source. [[Finnish#^fi-Q0421|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Aika%20ajoin%20olemme%20ponnistelleet%20pit%C3%A4%C3%A4ksemme%20lupauksemme%20vapaudesta%20ja%20tasa-arvosta%20koko%20kansallemme.)
^fi-Q0421-answer

**fi-Q0422** — Aika ajoin olemme ponnistelleet pitääksemme lupauksemme vapaudesta ja tasa-arvosta koko kansallemme.

At times, we've struggled to keep the promise of liberty and equality for all of our people.

Expected form: **vapaudesta**

Why: Elative source. [[Finnish#^fi-Q0422|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Aika%20ajoin%20olemme%20ponnistelleet%20pit%C3%A4%C3%A4ksemme%20lupauksemme%20vapaudesta%20ja%20tasa-arvosta%20koko%20kansallemme.)
^fi-Q0422-answer

**fi-Q0423** — Nosta kätesi ennen kuin vastaat.

Raise your hand before you answer.

Expected form: **Nosta**

Why: Elative source. [[Finnish#^fi-Q0423|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Nosta%20k%C3%A4tesi%20ennen%20kuin%20vastaat.)
^fi-Q0423-answer

**fi-Q0424** — Nosta kätesi ennen kuin vastaat.

Raise your hand before you answer.

Why: Elative source. [[Finnish#^fi-Q0424|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Nosta%20k%C3%A4tesi%20ennen%20kuin%20vastaat.)
^fi-Q0424-answer

**fi-Q0425** — Keitä ovat nuo kolme miestä?

Who are those three men?

Why: Elative source. [[Finnish#^fi-Q0425|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Keit%C3%A4%20ovat%20nuo%20kolme%20miest%C3%A4%3F)
^fi-Q0425-answer

**fi-Q0426** — Keitä ovat nuo kolme miestä?

Who are those three men?

Elative -sta/-stä expresses movement out of, source and some governed complements. The noun stem may change before the ending. A word’s suffix must be checked against its actual paradigm.

Why: Elative source. [[Finnish#^fi-Q0426|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Keit%C3%A4%20ovat%20nuo%20kolme%20miest%C3%A4%3F)
^fi-Q0426-answer

**fi-Q0427** — Jakaminen on välittämistä.

Sharing is caring.

Expected form: **välittämistä**

Why: Elative source. [[Finnish#^fi-Q0427|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Jakaminen%20on%20v%C3%A4litt%C3%A4mist%C3%A4.)
^fi-Q0427-answer

**fi-Q0428** — Jakaminen on välittämistä.

Sharing is caring.

Expected form: **välittämistä**

Why: Elative source. [[Finnish#^fi-Q0428|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Jakaminen%20on%20v%C3%A4litt%C3%A4mist%C3%A4.)
^fi-Q0428-answer

**fi-Q0429** — Tomin mielestä ei ollut hyvä ajatus jättää Maria kotiin ilman lapsenvahtia.

Tom thought it wasn't a good idea to leave Mary at home without a babysitter.

Expected form: **mielestä**

Why: Elative source. [[Finnish#^fi-Q0429|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tomin%20mielest%C3%A4%20ei%20ollut%20hyv%C3%A4%20ajatus%20j%C3%A4tt%C3%A4%C3%A4%20Maria%20kotiin%20ilman%20lapsenvahtia.)
^fi-Q0429-answer

**fi-Q0430** — Tomin mielestä ei ollut hyvä ajatus jättää Maria kotiin ilman lapsenvahtia.

Tom thought it wasn't a good idea to leave Mary at home without a babysitter.

Why: Elative source. [[Finnish#^fi-Q0430|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tomin%20mielest%C3%A4%20ei%20ollut%20hyv%C3%A4%20ajatus%20j%C3%A4tt%C3%A4%C3%A4%20Maria%20kotiin%20ilman%20lapsenvahtia.)
^fi-Q0430-answer

**fi-Q0431** — Tykkään paljon semantiikasta; haluan aina ymmärtää niin paljon nyansseja kuin mahdollita!

I'm big on semantics; I always want to try to understand as much nuance as possible!

Why: Elative source. [[Finnish#^fi-Q0431|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tykk%C3%A4%C3%A4n%20paljon%20semantiikasta%3B%20haluan%20aina%20ymm%C3%A4rt%C3%A4%C3%A4%20niin%20paljon%20nyansseja%20kuin%20mahdollita%21)
^fi-Q0431-answer

**fi-Q0432** — Tykkään paljon semantiikasta; haluan aina ymmärtää niin paljon nyansseja kuin mahdollita!

I'm big on semantics; I always want to try to understand as much nuance as possible!

Elative -sta/-stä expresses movement out of, source and some governed complements. The noun stem may change before the ending. A word’s suffix must be checked against its actual paradigm.

Why: Elative source. [[Finnish#^fi-Q0432|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tykk%C3%A4%C3%A4n%20paljon%20semantiikasta%3B%20haluan%20aina%20ymm%C3%A4rt%C3%A4%C3%A4%20niin%20paljon%20nyansseja%20kuin%20mahdollita%21)
^fi-Q0432-answer

**fi-Q0433** — Hajuaisti on yksi viidestä aistista.

Smell is one of the five senses.

Expected form: **viidestä**

Why: Elative source. [[Finnish#^fi-Q0433|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Hajuaisti%20on%20yksi%20viidest%C3%A4%20aistista.)
^fi-Q0433-answer

**fi-Q0434** — Hajuaisti on yksi viidestä aistista.

Smell is one of the five senses.

Expected form: **viidestä**

Why: Elative source. [[Finnish#^fi-Q0434|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Hajuaisti%20on%20yksi%20viidest%C3%A4%20aistista.)
^fi-Q0434-answer

**fi-Q0435** — Puhutko sinä meistä?

Do you talk about us?

Expected form: **meistä**

Why: Elative source. [[Finnish#^fi-Q0435|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Puhutko%20sin%C3%A4%20meist%C3%A4%3F)
^fi-Q0435-answer

**fi-Q0436** — Puhutko sinä meistä?

Do you talk about us?

Why: Elative source. [[Finnish#^fi-Q0436|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Puhutko%20sin%C3%A4%20meist%C3%A4%3F)
^fi-Q0436-answer

**fi-Q0437** — Nyt me näytämme miten tätä aputulosta voi käyttää päälauseen todistamiseen.

Now, we show how this lemma can be used to prove our main theorem.

Why: Elative source. [[Finnish#^fi-Q0437|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Nyt%20me%20n%C3%A4yt%C3%A4mme%20miten%20t%C3%A4t%C3%A4%20aputulosta%20voi%20k%C3%A4ytt%C3%A4%C3%A4%20p%C3%A4%C3%A4lauseen%20todistamiseen.)
^fi-Q0437-answer

**fi-Q0438** — Nyt me näytämme miten tätä aputulosta voi käyttää päälauseen todistamiseen.

Now, we show how this lemma can be used to prove our main theorem.

Elative -sta/-stä expresses movement out of, source and some governed complements. The noun stem may change before the ending. A word’s suffix must be checked against its actual paradigm.

Why: Elative source. [[Finnish#^fi-Q0438|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Nyt%20me%20n%C3%A4yt%C3%A4mme%20miten%20t%C3%A4t%C3%A4%20aputulosta%20voi%20k%C3%A4ytt%C3%A4%C3%A4%20p%C3%A4%C3%A4lauseen%20todistamiseen.)
^fi-Q0438-answer

**fi-Q0439** — Otin kakun uunista.

I took the cake out of the oven.

Expected form: **uunista**

Why: Elative source. [[Finnish#^fi-Q0439|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Otin%20kakun%20uunista.)
^fi-Q0439-answer

**fi-Q0440** — Otin kakun uunista.

I took the cake out of the oven.

Expected form: **uunista**

Why: Elative source. [[Finnish#^fi-Q0440|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Otin%20kakun%20uunista.)
^fi-Q0440-answer

**fi-Q0441** — Pidän tästä vielä enemmän.

I like this one even better.

Expected form: **tästä**

Why: Elative source. [[Finnish#^fi-Q0441|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Pid%C3%A4n%20t%C3%A4st%C3%A4%20viel%C3%A4%20enemm%C3%A4n.)
^fi-Q0441-answer

**fi-Q0442** — Pidän tästä vielä enemmän.

I like this one even better.

Why: Elative source. [[Finnish#^fi-Q0442|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Pid%C3%A4n%20t%C3%A4st%C3%A4%20viel%C3%A4%20enemm%C3%A4n.)
^fi-Q0442-answer

**fi-Q0443** — Sinä olet kotoisin Ruotsista.

You come from Sweden.

Why: Elative source. [[Finnish#^fi-Q0443|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Sin%C3%A4%20olet%20kotoisin%20Ruotsista.)
^fi-Q0443-answer

**fi-Q0444** — Sinä olet kotoisin Ruotsista.

You come from Sweden.

Elative -sta/-stä expresses movement out of, source and some governed complements. The noun stem may change before the ending. A word’s suffix must be checked against its actual paradigm.

Why: Elative source. [[Finnish#^fi-Q0444|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Sin%C3%A4%20olet%20kotoisin%20Ruotsista.)
^fi-Q0444-answer

**fi-Q0445** — Tom tykkää Marista, mutta Mari tykkää Jonista. Jotta asiat kävisivät vielä mielenkiintoisemmiksi, Joni tykkää Liisasta, mutta Liisa taas Tomista.

Tom likes Mary, but Mary likes John. To make matters even more interesting, John likes Alice, but Alice likes Tom.

Expected form: **Marista**

Why: Elative source. [[Finnish#^fi-Q0445|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tom%20tykk%C3%A4%C3%A4%20Marista%2C%20mutta%20Mari%20tykk%C3%A4%C3%A4%20Jonista.%20Jotta%20asiat%20k%C3%A4visiv%C3%A4t%20viel%C3%A4%20mielenkiintoisemmiksi%2C%20Joni%20tykk%C3%A4%C3%A4%20Liisasta%2C%20mutta%20Liisa%20taas%20Tomista.)
^fi-Q0445-answer

**fi-Q0446** — Tom tykkää Marista, mutta Mari tykkää Jonista. Jotta asiat kävisivät vielä mielenkiintoisemmiksi, Joni tykkää Liisasta, mutta Liisa taas Tomista.

Tom likes Mary, but Mary likes John. To make matters even more interesting, John likes Alice, but Alice likes Tom.

Expected form: **Marista**

Why: Elative source. [[Finnish#^fi-Q0446|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tom%20tykk%C3%A4%C3%A4%20Marista%2C%20mutta%20Mari%20tykk%C3%A4%C3%A4%20Jonista.%20Jotta%20asiat%20k%C3%A4visiv%C3%A4t%20viel%C3%A4%20mielenkiintoisemmiksi%2C%20Joni%20tykk%C3%A4%C3%A4%20Liisasta%2C%20mutta%20Liisa%20taas%20Tomista.)
^fi-Q0446-answer

**fi-Q0447** — Tämä on yksi Tomin heikkouksista.

This is one of Tom's weaknesses.

Expected form: **heikkouksista**

Why: Elative source. [[Finnish#^fi-Q0447|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=T%C3%A4m%C3%A4%20on%20yksi%20Tomin%20heikkouksista.)
^fi-Q0447-answer

**fi-Q0448** — Tämä on yksi Tomin heikkouksista.

This is one of Tom's weaknesses.

Why: Elative source. [[Finnish#^fi-Q0448|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=T%C3%A4m%C3%A4%20on%20yksi%20Tomin%20heikkouksista.)
^fi-Q0448-answer

**fi-Q0449** — Putkimies pumppasi veden putkesta.

The plumber pumped the water out of the pipe.

Why: Elative source. [[Finnish#^fi-Q0449|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Putkimies%20pumppasi%20veden%20putkesta.)
^fi-Q0449-answer

**fi-Q0450** — Putkimies pumppasi veden putkesta.

The plumber pumped the water out of the pipe.

Elative -sta/-stä expresses movement out of, source and some governed complements. The noun stem may change before the ending. A word’s suffix must be checked against its actual paradigm.

Why: Elative source. [[Finnish#^fi-Q0450|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Putkimies%20pumppasi%20veden%20putkesta.)
^fi-Q0450-answer


### Answers 451–500

**fi-Q0451** — Tom valehteli sinulle.

Tom lied to you.

Expected form: **sinulle**

Why: Allative destination. [[Finnish#^fi-Q0451|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tom%20valehteli%20sinulle.)
^fi-Q0451-answer

**fi-Q0452** — Tom valehteli sinulle.

Tom lied to you.

Expected form: **sinulle**

Why: Allative destination. [[Finnish#^fi-Q0452|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tom%20valehteli%20sinulle.)
^fi-Q0452-answer

**fi-Q0453** — Kerro minulle siitä!

Tell me about it!

Expected form: **minulle**

Why: Allative destination. [[Finnish#^fi-Q0453|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Kerro%20minulle%20siit%C3%A4%21)
^fi-Q0453-answer

**fi-Q0454** — Kerro minulle siitä!

Tell me about it!

Why: Allative destination. [[Finnish#^fi-Q0454|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Kerro%20minulle%20siit%C3%A4%21)
^fi-Q0454-answer

**fi-Q0455** — Tämä kaikki on minulle outoa.

All this is strange to me.

Why: Allative destination. [[Finnish#^fi-Q0455|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=T%C3%A4m%C3%A4%20kaikki%20on%20minulle%20outoa.)
^fi-Q0455-answer

**fi-Q0456** — Tämä kaikki on minulle outoa.

All this is strange to me.

Allative -lle commonly marks a destination onto/at a surface or a recipient. Pronouns have their own stems. English to can also map to other Finnish cases.

Why: Allative destination. [[Finnish#^fi-Q0456|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=T%C3%A4m%C3%A4%20kaikki%20on%20minulle%20outoa.)
^fi-Q0456-answer

**fi-Q0457** — Kerro minulle mikä sinun ongelmasi on.

Tell me what your problem is.

Expected form: **minulle**

Why: Allative destination. [[Finnish#^fi-Q0457|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Kerro%20minulle%20mik%C3%A4%20sinun%20ongelmasi%20on.)
^fi-Q0457-answer

**fi-Q0458** — Kerro minulle mikä sinun ongelmasi on.

Tell me what your problem is.

Expected form: **minulle**

Why: Allative destination. [[Finnish#^fi-Q0458|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Kerro%20minulle%20mik%C3%A4%20sinun%20ongelmasi%20on.)
^fi-Q0458-answer

**fi-Q0459** — Miten vastasitte hänelle?

How did you answer her?

Expected form: **hänelle**

Why: Allative destination. [[Finnish#^fi-Q0459|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Miten%20vastasitte%20h%C3%A4nelle%3F)
^fi-Q0459-answer

**fi-Q0460** — Miten vastasitte hänelle?

How did you answer her?

Why: Allative destination. [[Finnish#^fi-Q0460|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Miten%20vastasitte%20h%C3%A4nelle%3F)
^fi-Q0460-answer

**fi-Q0461** — Voit soittaa minulle milloin vain.

Call me anytime.

Why: Allative destination. [[Finnish#^fi-Q0461|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Voit%20soittaa%20minulle%20milloin%20vain.)
^fi-Q0461-answer

**fi-Q0462** — Voit soittaa minulle milloin vain.

Call me anytime.

Allative -lle commonly marks a destination onto/at a surface or a recipient. Pronouns have their own stems. English to can also map to other Finnish cases.

Why: Allative destination. [[Finnish#^fi-Q0462|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Voit%20soittaa%20minulle%20milloin%20vain.)
^fi-Q0462-answer

**fi-Q0463** — Jos tietäisin sen, niin kertoisin sinulle.

If I knew it, I would tell you.

Expected form: **sinulle**

Why: Allative destination. [[Finnish#^fi-Q0463|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Jos%20tiet%C3%A4isin%20sen%2C%20niin%20kertoisin%20sinulle.)
^fi-Q0463-answer

**fi-Q0464** — Jos tietäisin sen, niin kertoisin sinulle.

If I knew it, I would tell you.

Expected form: **sinulle**

Why: Allative destination. [[Finnish#^fi-Q0464|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Jos%20tiet%C3%A4isin%20sen%2C%20niin%20kertoisin%20sinulle.)
^fi-Q0464-answer

**fi-Q0465** — Minun poikani valehteli minulle.

My son lied to me.

Expected form: **minulle**

Why: Allative destination. [[Finnish#^fi-Q0465|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Minun%20poikani%20valehteli%20minulle.)
^fi-Q0465-answer

**fi-Q0466** — Minun poikani valehteli minulle.

My son lied to me.

Why: Allative destination. [[Finnish#^fi-Q0466|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Minun%20poikani%20valehteli%20minulle.)
^fi-Q0466-answer

**fi-Q0467** — Tom antoi minulle kynän.

Tom gave me a pen.

Why: Allative destination. [[Finnish#^fi-Q0467|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tom%20antoi%20minulle%20kyn%C3%A4n.)
^fi-Q0467-answer

**fi-Q0468** — Tom antoi minulle kynän.

Tom gave me a pen.

Allative -lle commonly marks a destination onto/at a surface or a recipient. Pronouns have their own stems. English to can also map to other Finnish cases.

Why: Allative destination. [[Finnish#^fi-Q0468|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tom%20antoi%20minulle%20kyn%C3%A4n.)
^fi-Q0468-answer

**fi-Q0469** — Voisitko lainata sanakirjaasi minulle?

Will you lend your dictionary to me?

Expected form: **minulle**

Why: Allative destination. [[Finnish#^fi-Q0469|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Voisitko%20lainata%20sanakirjaasi%20minulle%3F)
^fi-Q0469-answer

**fi-Q0470** — Voisitko lainata sanakirjaasi minulle?

Will you lend your dictionary to me?

Expected form: **minulle**

Why: Allative destination. [[Finnish#^fi-Q0470|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Voisitko%20lainata%20sanakirjaasi%20minulle%3F)
^fi-Q0470-answer

**fi-Q0471** — Tom lupasi minulle, että hän olisi täällä puoli kolmeen mennessä.

Tom promised me he'd be here by 2:30.

Expected form: **minulle**

Why: Allative destination. [[Finnish#^fi-Q0471|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tom%20lupasi%20minulle%2C%20ett%C3%A4%20h%C3%A4n%20olisi%20t%C3%A4%C3%A4ll%C3%A4%20puoli%20kolmeen%20menness%C3%A4.)
^fi-Q0471-answer

**fi-Q0472** — Tom lupasi minulle, että hän olisi täällä puoli kolmeen mennessä.

Tom promised me he'd be here by 2:30.

Why: Allative destination. [[Finnish#^fi-Q0472|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tom%20lupasi%20minulle%2C%20ett%C3%A4%20h%C3%A4n%20olisi%20t%C3%A4%C3%A4ll%C3%A4%20puoli%20kolmeen%20menness%C3%A4.)
^fi-Q0472-answer

**fi-Q0473** — Anna minulle sinun aseesi.

Give me your weapons.

Why: Allative destination. [[Finnish#^fi-Q0473|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Anna%20minulle%20sinun%20aseesi.)
^fi-Q0473-answer

**fi-Q0474** — Anna minulle sinun aseesi.

Give me your weapons.

Allative -lle commonly marks a destination onto/at a surface or a recipient. Pronouns have their own stems. English to can also map to other Finnish cases.

Why: Allative destination. [[Finnish#^fi-Q0474|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Anna%20minulle%20sinun%20aseesi.)
^fi-Q0474-answer

**fi-Q0475** — Katso minua kun puhun sinulle.

Look at me when I talk to you!

Expected form: **sinulle**

Why: Allative destination. [[Finnish#^fi-Q0475|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Katso%20minua%20kun%20puhun%20sinulle.)
^fi-Q0475-answer

**fi-Q0476** — Katso minua kun puhun sinulle.

Look at me when I talk to you!

Expected form: **sinulle**

Why: Allative destination. [[Finnish#^fi-Q0476|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Katso%20minua%20kun%20puhun%20sinulle.)
^fi-Q0476-answer

**fi-Q0477** — Toin sinulle jotakin pientä.

I brought you a little something.

Expected form: **sinulle**

Why: Allative destination. [[Finnish#^fi-Q0477|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Toin%20sinulle%20jotakin%20pient%C3%A4.)
^fi-Q0477-answer

**fi-Q0478** — Toin sinulle jotakin pientä.

I brought you a little something.

Why: Allative destination. [[Finnish#^fi-Q0478|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Toin%20sinulle%20jotakin%20pient%C3%A4.)
^fi-Q0478-answer

**fi-Q0479** — Miksi Tomi on yhtäkkiä minulle niin ystävällinen.

Why is Tom being so nice to me all of a sudden?

Why: Allative destination. [[Finnish#^fi-Q0479|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Miksi%20Tomi%20on%20yht%C3%A4kki%C3%A4%20minulle%20niin%20yst%C3%A4v%C3%A4llinen.)
^fi-Q0479-answer

**fi-Q0480** — Miksi Tomi on yhtäkkiä minulle niin ystävällinen.

Why is Tom being so nice to me all of a sudden?

Allative -lle commonly marks a destination onto/at a surface or a recipient. Pronouns have their own stems. English to can also map to other Finnish cases.

Why: Allative destination. [[Finnish#^fi-Q0480|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Miksi%20Tomi%20on%20yht%C3%A4kki%C3%A4%20minulle%20niin%20yst%C3%A4v%C3%A4llinen.)
^fi-Q0480-answer

**fi-Q0481** — Onko jotain, jota et nyt kerro minulle?

Is there anything you're not telling me?

Expected form: **minulle**

Why: Allative destination. [[Finnish#^fi-Q0481|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Onko%20jotain%2C%20jota%20et%20nyt%20kerro%20minulle%3F)
^fi-Q0481-answer

**fi-Q0482** — Onko jotain, jota et nyt kerro minulle?

Is there anything you're not telling me?

Expected form: **minulle**

Why: Allative destination. [[Finnish#^fi-Q0482|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Onko%20jotain%2C%20jota%20et%20nyt%20kerro%20minulle%3F)
^fi-Q0482-answer

**fi-Q0483** — Kirjoita hänelle viesti.

Write him a note.

Expected form: **hänelle**

Why: Allative destination. [[Finnish#^fi-Q0483|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Kirjoita%20h%C3%A4nelle%20viesti.)
^fi-Q0483-answer

**fi-Q0484** — Kirjoita hänelle viesti.

Write him a note.

Why: Allative destination. [[Finnish#^fi-Q0484|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Kirjoita%20h%C3%A4nelle%20viesti.)
^fi-Q0484-answer

**fi-Q0485** — Kerro minulle osoitteesi.

Please tell me your address.

Why: Allative destination. [[Finnish#^fi-Q0485|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Kerro%20minulle%20osoitteesi.)
^fi-Q0485-answer

**fi-Q0486** — Kerro minulle osoitteesi.

Please tell me your address.

Allative -lle commonly marks a destination onto/at a surface or a recipient. Pronouns have their own stems. English to can also map to other Finnish cases.

Why: Allative destination. [[Finnish#^fi-Q0486|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Kerro%20minulle%20osoitteesi.)
^fi-Q0486-answer

**fi-Q0487** — Kerro minulle hänestä.

Tell me about him.

Expected form: **minulle**

Why: Allative destination. [[Finnish#^fi-Q0487|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Kerro%20minulle%20h%C3%A4nest%C3%A4.)
^fi-Q0487-answer

**fi-Q0488** — Kerro minulle hänestä.

Tell me about him.

Expected form: **minulle**

Why: Allative destination. [[Finnish#^fi-Q0488|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Kerro%20minulle%20h%C3%A4nest%C3%A4.)
^fi-Q0488-answer

**fi-Q0489** — Epäilen, ettei Tomi tee sitä minulle.

I suspect Tom won't do that for me.

Expected form: **minulle**

Why: Allative destination. [[Finnish#^fi-Q0489|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Ep%C3%A4ilen%2C%20ettei%20Tomi%20tee%20sit%C3%A4%20minulle.)
^fi-Q0489-answer

**fi-Q0490** — Epäilen, ettei Tomi tee sitä minulle.

I suspect Tom won't do that for me.

Why: Allative destination. [[Finnish#^fi-Q0490|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Ep%C3%A4ilen%2C%20ettei%20Tomi%20tee%20sit%C3%A4%20minulle.)
^fi-Q0490-answer

**fi-Q0491** — Ei kuulu sinulle.

It's none of your business.

Why: Allative destination. [[Finnish#^fi-Q0491|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Ei%20kuulu%20sinulle.)
^fi-Q0491-answer

**fi-Q0492** — Ei kuulu sinulle.

It's none of your business.

Allative -lle commonly marks a destination onto/at a surface or a recipient. Pronouns have their own stems. English to can also map to other Finnish cases.

Why: Allative destination. [[Finnish#^fi-Q0492|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Ei%20kuulu%20sinulle.)
^fi-Q0492-answer

**fi-Q0493** — Minulle tulee maha kipeäksi maidosta.

Milk gives me a stomachache.

Expected form: **Minulle**

Why: Allative destination. [[Finnish#^fi-Q0493|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Minulle%20tulee%20maha%20kipe%C3%A4ksi%20maidosta.)
^fi-Q0493-answer

**fi-Q0494** — Minulle tulee maha kipeäksi maidosta.

Milk gives me a stomachache.

Expected form: **Minulle**

Why: Allative destination. [[Finnish#^fi-Q0494|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Minulle%20tulee%20maha%20kipe%C3%A4ksi%20maidosta.)
^fi-Q0494-answer

**fi-Q0495** — Kitara on minulle liian kallis ostaa.

That guitar is too expensive for me to buy.

Expected form: **minulle**

Why: Allative destination. [[Finnish#^fi-Q0495|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Kitara%20on%20minulle%20liian%20kallis%20ostaa.)
^fi-Q0495-answer

**fi-Q0496** — Kitara on minulle liian kallis ostaa.

That guitar is too expensive for me to buy.

Why: Allative destination. [[Finnish#^fi-Q0496|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Kitara%20on%20minulle%20liian%20kallis%20ostaa.)
^fi-Q0496-answer

**fi-Q0497** — Kerro minulle se, että miten voin löytää Tomin.

Tell me how to find Tom.

Why: Allative destination. [[Finnish#^fi-Q0497|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Kerro%20minulle%20se%2C%20ett%C3%A4%20miten%20voin%20l%C3%B6yt%C3%A4%C3%A4%20Tomin.)
^fi-Q0497-answer

**fi-Q0498** — Kerro minulle se, että miten voin löytää Tomin.

Tell me how to find Tom.

Allative -lle commonly marks a destination onto/at a surface or a recipient. Pronouns have their own stems. English to can also map to other Finnish cases.

Why: Allative destination. [[Finnish#^fi-Q0498|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Kerro%20minulle%20se%2C%20ett%C3%A4%20miten%20voin%20l%C3%B6yt%C3%A4%C3%A4%20Tomin.)
^fi-Q0498-answer

**fi-Q0499** — Kiiruhdimme asemalle vain myöhästyäksemme junasta.

We hurried to the station only to miss the train.

Expected form: **asemalle**

Why: Allative destination. [[Finnish#^fi-Q0499|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Kiiruhdimme%20asemalle%20vain%20my%C3%B6h%C3%A4sty%C3%A4ksemme%20junasta.)
^fi-Q0499-answer

**fi-Q0500** — Kiiruhdimme asemalle vain myöhästyäksemme junasta.

We hurried to the station only to miss the train.

Expected form: **asemalle**

Why: Allative destination. [[Finnish#^fi-Q0500|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Kiiruhdimme%20asemalle%20vain%20my%C3%B6h%C3%A4sty%C3%A4ksemme%20junasta.)
^fi-Q0500-answer


### Answers 501–550

**fi-Q0501** — Minulla on ollut todella kova päivä.

I've had a really hard day.

Expected form: **Minulla**

Why: Adessive and possession. [[Finnish#^fi-Q0501|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Minulla%20on%20ollut%20todella%20kova%20p%C3%A4iv%C3%A4.)
^fi-Q0501-answer

**fi-Q0502** — Minulla on ollut todella kova päivä.

I've had a really hard day.

Why: Adessive and possession. [[Finnish#^fi-Q0502|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Minulla%20on%20ollut%20todella%20kova%20p%C3%A4iv%C3%A4.)
^fi-Q0502-answer

**fi-Q0503** — Sinulla ei ole mitään sanottavaa siitä, vai?

You don't have anything to say about it, do you?

Why: Adessive and possession. [[Finnish#^fi-Q0503|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Sinulla%20ei%20ole%20mit%C3%A4%C3%A4n%20sanottavaa%20siit%C3%A4%2C%20vai%3F)
^fi-Q0503-answer

**fi-Q0504** — Sinulla ei ole mitään sanottavaa siitä, vai?

You don't have anything to say about it, do you?

Adessive marks many surface/location meanings. A possessive construction often uses an adessive possessor plus olla: Minulla on kirja. The possessed noun is not automatically an accusative object.

Why: Adessive and possession. [[Finnish#^fi-Q0504|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Sinulla%20ei%20ole%20mit%C3%A4%C3%A4n%20sanottavaa%20siit%C3%A4%2C%20vai%3F)
^fi-Q0504-answer

**fi-Q0505** — Minulla on uusi työ.

I have a new job.

Expected form: **Minulla**

Why: Adessive and possession. [[Finnish#^fi-Q0505|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Minulla%20on%20uusi%20ty%C3%B6.)
^fi-Q0505-answer

**fi-Q0506** — Minulla on uusi työ.

I have a new job.

Expected form: **Minulla**

Why: Adessive and possession. [[Finnish#^fi-Q0506|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Minulla%20on%20uusi%20ty%C3%B6.)
^fi-Q0506-answer

**fi-Q0507** — Minulla on nyt todella tylsää.

I'm really bored right now.

Expected form: **Minulla**

Why: Adessive and possession. [[Finnish#^fi-Q0507|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Minulla%20on%20nyt%20todella%20tyls%C3%A4%C3%A4.)
^fi-Q0507-answer

**fi-Q0508** — Minulla on nyt todella tylsää.

I'm really bored right now.

Why: Adessive and possession. [[Finnish#^fi-Q0508|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Minulla%20on%20nyt%20todella%20tyls%C3%A4%C3%A4.)
^fi-Q0508-answer

**fi-Q0509** — Olette kaikki mitä heillä on.

You're all they have.

Why: Adessive and possession. [[Finnish#^fi-Q0509|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Olette%20kaikki%20mit%C3%A4%20heill%C3%A4%20on.)
^fi-Q0509-answer

**fi-Q0510** — Olette kaikki mitä heillä on.

You're all they have.

Adessive marks many surface/location meanings. A possessive construction often uses an adessive possessor plus olla: Minulla on kirja. The possessed noun is not automatically an accusative object.

Why: Adessive and possession. [[Finnish#^fi-Q0510|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Olette%20kaikki%20mit%C3%A4%20heill%C3%A4%20on.)
^fi-Q0510-answer

**fi-Q0511** — Minulla on tänään todella paljon tehtävää.

I have a lot to do today.

Expected form: **Minulla**

Why: Adessive and possession. [[Finnish#^fi-Q0511|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Minulla%20on%20t%C3%A4n%C3%A4%C3%A4n%20todella%20paljon%20teht%C3%A4v%C3%A4%C3%A4.)
^fi-Q0511-answer

**fi-Q0512** — Minulla on tänään todella paljon tehtävää.

I have a lot to do today.

Expected form: **Minulla**

Why: Adessive and possession. [[Finnish#^fi-Q0512|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Minulla%20on%20t%C3%A4n%C3%A4%C3%A4n%20todella%20paljon%20teht%C3%A4v%C3%A4%C3%A4.)
^fi-Q0512-answer

**fi-Q0513** — Onko teillä halvempia istuimia?

Do you have any cheaper seats?

Expected form: **teillä**

Why: Adessive and possession. [[Finnish#^fi-Q0513|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Onko%20teill%C3%A4%20halvempia%20istuimia%3F)
^fi-Q0513-answer

**fi-Q0514** — Onko teillä halvempia istuimia?

Do you have any cheaper seats?

Why: Adessive and possession. [[Finnish#^fi-Q0514|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Onko%20teill%C3%A4%20halvempia%20istuimia%3F)
^fi-Q0514-answer

**fi-Q0515** — Sinulla ei ole mitään menetettävää.

You have nothing to lose.

Why: Adessive and possession. [[Finnish#^fi-Q0515|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Sinulla%20ei%20ole%20mit%C3%A4%C3%A4n%20menetett%C3%A4v%C3%A4%C3%A4.)
^fi-Q0515-answer

**fi-Q0516** — Sinulla ei ole mitään menetettävää.

You have nothing to lose.

Adessive marks many surface/location meanings. A possessive construction often uses an adessive possessor plus olla: Minulla on kirja. The possessed noun is not automatically an accusative object.

Why: Adessive and possession. [[Finnish#^fi-Q0516|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Sinulla%20ei%20ole%20mit%C3%A4%C3%A4n%20menetett%C3%A4v%C3%A4%C3%A4.)
^fi-Q0516-answer

**fi-Q0517** — Hänellä ei ole harmaintakaan haisuakaan.

He hasn't got the foggiest.

Expected form: **Hänellä**

Why: Adessive and possession. [[Finnish#^fi-Q0517|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=H%C3%A4nell%C3%A4%20ei%20ole%20harmaintakaan%20haisuakaan.)
^fi-Q0517-answer

**fi-Q0518** — Hänellä ei ole harmaintakaan haisuakaan.

He hasn't got the foggiest.

Expected form: **Hänellä**

Why: Adessive and possession. [[Finnish#^fi-Q0518|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=H%C3%A4nell%C3%A4%20ei%20ole%20harmaintakaan%20haisuakaan.)
^fi-Q0518-answer

**fi-Q0519** — Ei meillä ole mitään, mitä pitäisi piilottaa.

We have nothing to hide.

Expected form: **meillä**

Why: Adessive and possession. [[Finnish#^fi-Q0519|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Ei%20meill%C3%A4%20ole%20mit%C3%A4%C3%A4n%2C%20mit%C3%A4%20pit%C3%A4isi%20piilottaa.)
^fi-Q0519-answer

**fi-Q0520** — Ei meillä ole mitään, mitä pitäisi piilottaa.

We have nothing to hide.

Why: Adessive and possession. [[Finnish#^fi-Q0520|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Ei%20meill%C3%A4%20ole%20mit%C3%A4%C3%A4n%2C%20mit%C3%A4%20pit%C3%A4isi%20piilottaa.)
^fi-Q0520-answer

**fi-Q0521** — Heillä on molemmilla univormut.

They're both wearing uniforms.

Why: Adessive and possession. [[Finnish#^fi-Q0521|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Heill%C3%A4%20on%20molemmilla%20univormut.)
^fi-Q0521-answer

**fi-Q0522** — Heillä on molemmilla univormut.

They're both wearing uniforms.

Adessive marks many surface/location meanings. A possessive construction often uses an adessive possessor plus olla: Minulla on kirja. The possessed noun is not automatically an accusative object.

Why: Adessive and possession. [[Finnish#^fi-Q0522|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Heill%C3%A4%20on%20molemmilla%20univormut.)
^fi-Q0522-answer

**fi-Q0523** — Minulla alkaa olla parempi olo.

I'm starting to feel better.

Expected form: **Minulla**

Why: Adessive and possession. [[Finnish#^fi-Q0523|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Minulla%20alkaa%20olla%20parempi%20olo.)
^fi-Q0523-answer

**fi-Q0524** — Minulla alkaa olla parempi olo.

I'm starting to feel better.

Expected form: **Minulla**

Why: Adessive and possession. [[Finnish#^fi-Q0524|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Minulla%20alkaa%20olla%20parempi%20olo.)
^fi-Q0524-answer

**fi-Q0525** — Minulla on nälkä, koska en syönyt aamupalaa.

I am hungry because I did not have breakfast.

Expected form: **Minulla**

Why: Adessive and possession. [[Finnish#^fi-Q0525|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Minulla%20on%20n%C3%A4lk%C3%A4%2C%20koska%20en%20sy%C3%B6nyt%20aamupalaa.)
^fi-Q0525-answer

**fi-Q0526** — Minulla on nälkä, koska en syönyt aamupalaa.

I am hungry because I did not have breakfast.

Why: Adessive and possession. [[Finnish#^fi-Q0526|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Minulla%20on%20n%C3%A4lk%C3%A4%2C%20koska%20en%20sy%C3%B6nyt%20aamupalaa.)
^fi-Q0526-answer

**fi-Q0527** — Onhan sinulla pointti siinä.

You do have a point there.

Why: Adessive and possession. [[Finnish#^fi-Q0527|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Onhan%20sinulla%20pointti%20siin%C3%A4.)
^fi-Q0527-answer

**fi-Q0528** — Onhan sinulla pointti siinä.

You do have a point there.

Adessive marks many surface/location meanings. A possessive construction often uses an adessive possessor plus olla: Minulla on kirja. The possessed noun is not automatically an accusative object.

Why: Adessive and possession. [[Finnish#^fi-Q0528|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Onhan%20sinulla%20pointti%20siin%C3%A4.)
^fi-Q0528-answer

**fi-Q0529** — Minulla on ikävä kissaani.

I miss my cat.

Expected form: **Minulla**

Why: Adessive and possession. [[Finnish#^fi-Q0529|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Minulla%20on%20ik%C3%A4v%C3%A4%20kissaani.)
^fi-Q0529-answer

**fi-Q0530** — Minulla on ikävä kissaani.

I miss my cat.

Expected form: **Minulla**

Why: Adessive and possession. [[Finnish#^fi-Q0530|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Minulla%20on%20ik%C3%A4v%C3%A4%20kissaani.)
^fi-Q0530-answer

**fi-Q0531** — Voi kunpa minulla olisi auto.

I wish I had a car.

Expected form: **minulla**

Why: Adessive and possession. [[Finnish#^fi-Q0531|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Voi%20kunpa%20minulla%20olisi%20auto.)
^fi-Q0531-answer

**fi-Q0532** — Voi kunpa minulla olisi auto.

I wish I had a car.

Why: Adessive and possession. [[Finnish#^fi-Q0532|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Voi%20kunpa%20minulla%20olisi%20auto.)
^fi-Q0532-answer

**fi-Q0533** — Hänellä on siisti huoneisto.

She has a a tidy apartment.

Why: Adessive and possession. [[Finnish#^fi-Q0533|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=H%C3%A4nell%C3%A4%20on%20siisti%20huoneisto.)
^fi-Q0533-answer

**fi-Q0534** — Hänellä on siisti huoneisto.

She has a a tidy apartment.

Adessive marks many surface/location meanings. A possessive construction often uses an adessive possessor plus olla: Minulla on kirja. The possessed noun is not automatically an accusative object.

Why: Adessive and possession. [[Finnish#^fi-Q0534|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=H%C3%A4nell%C3%A4%20on%20siisti%20huoneisto.)
^fi-Q0534-answer

**fi-Q0535** — Meillä ei ole varaa siihen.

We can't afford that.

Expected form: **Meillä**

Why: Adessive and possession. [[Finnish#^fi-Q0535|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Meill%C3%A4%20ei%20ole%20varaa%20siihen.)
^fi-Q0535-answer

**fi-Q0536** — Meillä ei ole varaa siihen.

We can't afford that.

Expected form: **Meillä**

Why: Adessive and possession. [[Finnish#^fi-Q0536|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Meill%C3%A4%20ei%20ole%20varaa%20siihen.)
^fi-Q0536-answer

**fi-Q0537** — Minulla on ikävä Tomia. Toivon, että hän tulee pian takaisin.

I miss Tom. I hope he comes back soon.

Expected form: **Minulla**

Why: Adessive and possession. [[Finnish#^fi-Q0537|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Minulla%20on%20ik%C3%A4v%C3%A4%20Tomia.%20Toivon%2C%20ett%C3%A4%20h%C3%A4n%20tulee%20pian%20takaisin.)
^fi-Q0537-answer

**fi-Q0538** — Minulla on ikävä Tomia. Toivon, että hän tulee pian takaisin.

I miss Tom. I hope he comes back soon.

Why: Adessive and possession. [[Finnish#^fi-Q0538|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Minulla%20on%20ik%C3%A4v%C3%A4%20Tomia.%20Toivon%2C%20ett%C3%A4%20h%C3%A4n%20tulee%20pian%20takaisin.)
^fi-Q0538-answer

**fi-Q0539** — Minulla ei ollut kiire.

I wasn't in a hurry.

Why: Adessive and possession. [[Finnish#^fi-Q0539|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Minulla%20ei%20ollut%20kiire.)
^fi-Q0539-answer

**fi-Q0540** — Minulla ei ollut kiire.

I wasn't in a hurry.

Adessive marks many surface/location meanings. A possessive construction often uses an adessive possessor plus olla: Minulla on kirja. The possessed noun is not automatically an accusative object.

Why: Adessive and possession. [[Finnish#^fi-Q0540|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Minulla%20ei%20ollut%20kiire.)
^fi-Q0540-answer

**fi-Q0541** — Hänellä ei ole varaa ostaa uutta autoa.

He can't afford to buy a new car.

Expected form: **Hänellä**

Why: Adessive and possession. [[Finnish#^fi-Q0541|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=H%C3%A4nell%C3%A4%20ei%20ole%20varaa%20ostaa%20uutta%20autoa.)
^fi-Q0541-answer

**fi-Q0542** — Hänellä ei ole varaa ostaa uutta autoa.

He can't afford to buy a new car.

Expected form: **Hänellä**

Why: Adessive and possession. [[Finnish#^fi-Q0542|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=H%C3%A4nell%C3%A4%20ei%20ole%20varaa%20ostaa%20uutta%20autoa.)
^fi-Q0542-answer

**fi-Q0543** — Meillä on suuri työ edessämme.

We have a big job ahead of us.

Expected form: **Meillä**

Why: Adessive and possession. [[Finnish#^fi-Q0543|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Meill%C3%A4%20on%20suuri%20ty%C3%B6%20edess%C3%A4mme.)
^fi-Q0543-answer

**fi-Q0544** — Meillä on suuri työ edessämme.

We have a big job ahead of us.

Why: Adessive and possession. [[Finnish#^fi-Q0544|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Meill%C3%A4%20on%20suuri%20ty%C3%B6%20edess%C3%A4mme.)
^fi-Q0544-answer

**fi-Q0545** — Minulla on normaali näkö.

I have a normal eyesight.

Why: Adessive and possession. [[Finnish#^fi-Q0545|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Minulla%20on%20normaali%20n%C3%A4k%C3%B6.)
^fi-Q0545-answer

**fi-Q0546** — Minulla on normaali näkö.

I have a normal eyesight.

Adessive marks many surface/location meanings. A possessive construction often uses an adessive possessor plus olla: Minulla on kirja. The possessed noun is not automatically an accusative object.

Why: Adessive and possession. [[Finnish#^fi-Q0546|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Minulla%20on%20normaali%20n%C3%A4k%C3%B6.)
^fi-Q0546-answer

**fi-Q0547** — Minulla menee hyvin, kiitos!

I am fine, thank you.

Expected form: **Minulla**

Why: Adessive and possession. [[Finnish#^fi-Q0547|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Minulla%20menee%20hyvin%2C%20kiitos%21)
^fi-Q0547-answer

**fi-Q0548** — Minulla menee hyvin, kiitos!

I am fine, thank you.

Expected form: **Minulla**

Why: Adessive and possession. [[Finnish#^fi-Q0548|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Minulla%20menee%20hyvin%2C%20kiitos%21)
^fi-Q0548-answer

**fi-Q0549** — Minulla on vaikeuksia ymmärtää häntä.

I have difficulty in understanding him.

Expected form: **Minulla**

Why: Adessive and possession. [[Finnish#^fi-Q0549|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Minulla%20on%20vaikeuksia%20ymm%C3%A4rt%C3%A4%C3%A4%20h%C3%A4nt%C3%A4.)
^fi-Q0549-answer

**fi-Q0550** — Minulla on vaikeuksia ymmärtää häntä.

I have difficulty in understanding him.

Why: Adessive and possession. [[Finnish#^fi-Q0550|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Minulla%20on%20vaikeuksia%20ymm%C3%A4rt%C3%A4%C3%A4%20h%C3%A4nt%C3%A4.)
^fi-Q0550-answer


### Answers 551–600

**fi-Q0551** — Ne saarelaiset pyytävät meiltä apua.

The islanders are asking us for help.

Why: Ablative source. [[Finnish#^fi-Q0551|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Ne%20saarelaiset%20pyyt%C3%A4v%C3%A4t%20meilt%C3%A4%20apua.)
^fi-Q0551-answer

**fi-Q0552** — Ne saarelaiset pyytävät meiltä apua.

The islanders are asking us for help.

Ablative -lta/-ltä commonly expresses movement away from a surface or a source/person. Contrast it with allative destination and adessive location.

Why: Ablative source. [[Finnish#^fi-Q0552|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Ne%20saarelaiset%20pyyt%C3%A4v%C3%A4t%20meilt%C3%A4%20apua.)
^fi-Q0552-answer

**fi-Q0553** — Tom aikoi kysyä sinulta siitä.

Tom was going to ask you about that.

Expected form: **sinulta**

Why: Ablative source. [[Finnish#^fi-Q0553|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tom%20aikoi%20kysy%C3%A4%20sinulta%20siit%C3%A4.)
^fi-Q0553-answer

**fi-Q0554** — Tom aikoi kysyä sinulta siitä.

Tom was going to ask you about that.

Expected form: **sinulta**

Why: Ablative source. [[Finnish#^fi-Q0554|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tom%20aikoi%20kysy%C3%A4%20sinulta%20siit%C3%A4.)
^fi-Q0554-answer

**fi-Q0555** — Kaikki kysyvät minulta millaista on olla värisokea.

Everyone asks me what it's like to be colour-blind.

Expected form: **minulta**

Why: Ablative source. [[Finnish#^fi-Q0555|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Kaikki%20kysyv%C3%A4t%20minulta%20millaista%20on%20olla%20v%C3%A4risokea.)
^fi-Q0555-answer

**fi-Q0556** — Kaikki kysyvät minulta millaista on olla värisokea.

Everyone asks me what it's like to be colour-blind.

Why: Ablative source. [[Finnish#^fi-Q0556|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Kaikki%20kysyv%C3%A4t%20minulta%20millaista%20on%20olla%20v%C3%A4risokea.)
^fi-Q0556-answer

**fi-Q0557** — Hänen lääkärinsä kielsi häneltä alkoholin juomisen.

His doctor told him not to drink alcohol.

Why: Ablative source. [[Finnish#^fi-Q0557|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=H%C3%A4nen%20l%C3%A4%C3%A4k%C3%A4rins%C3%A4%20kielsi%20h%C3%A4nelt%C3%A4%20alkoholin%20juomisen.)
^fi-Q0557-answer

**fi-Q0558** — Hänen lääkärinsä kielsi häneltä alkoholin juomisen.

His doctor told him not to drink alcohol.

Ablative -lta/-ltä commonly expresses movement away from a surface or a source/person. Contrast it with allative destination and adessive location.

Why: Ablative source. [[Finnish#^fi-Q0558|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=H%C3%A4nen%20l%C3%A4%C3%A4k%C3%A4rins%C3%A4%20kielsi%20h%C3%A4nelt%C3%A4%20alkoholin%20juomisen.)
^fi-Q0558-answer

**fi-Q0559** — Häneltä kesti kolme kuukautta oppia ajamaan polkupyörällä.

It took him three months to learn to ride a bicycle.

Expected form: **Häneltä**

Why: Ablative source. [[Finnish#^fi-Q0559|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=H%C3%A4nelt%C3%A4%20kesti%20kolme%20kuukautta%20oppia%20ajamaan%20polkupy%C3%B6r%C3%A4ll%C3%A4.)
^fi-Q0559-answer

**fi-Q0560** — Häneltä kesti kolme kuukautta oppia ajamaan polkupyörällä.

It took him three months to learn to ride a bicycle.

Expected form: **Häneltä**

Why: Ablative source. [[Finnish#^fi-Q0560|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=H%C3%A4nelt%C3%A4%20kesti%20kolme%20kuukautta%20oppia%20ajamaan%20polkupy%C3%B6r%C3%A4ll%C3%A4.)
^fi-Q0560-answer

**fi-Q0561** — Se oli ilkeää häneltä.

That was wicked of him.

Expected form: **häneltä**

Why: Ablative source. [[Finnish#^fi-Q0561|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Se%20oli%20ilke%C3%A4%C3%A4%20h%C3%A4nelt%C3%A4.)
^fi-Q0561-answer

**fi-Q0562** — Se oli ilkeää häneltä.

That was wicked of him.

Why: Ablative source. [[Finnish#^fi-Q0562|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Se%20oli%20ilke%C3%A4%C3%A4%20h%C3%A4nelt%C3%A4.)
^fi-Q0562-answer

**fi-Q0563** — Voinko pyytää sinulta isoa palvelusta?

Could I ask you a big favor?

Why: Ablative source. [[Finnish#^fi-Q0563|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Voinko%20pyyt%C3%A4%C3%A4%20sinulta%20isoa%20palvelusta%3F)
^fi-Q0563-answer

**fi-Q0564** — Voinko pyytää sinulta isoa palvelusta?

Could I ask you a big favor?

Ablative -lta/-ltä commonly expresses movement away from a surface or a source/person. Contrast it with allative destination and adessive location.

Why: Ablative source. [[Finnish#^fi-Q0564|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Voinko%20pyyt%C3%A4%C3%A4%20sinulta%20isoa%20palvelusta%3F)
^fi-Q0564-answer

**fi-Q0565** — Tämä kirja menee minulta yli hilseen.

This book is above my understanding.

Expected form: **minulta**

Why: Ablative source. [[Finnish#^fi-Q0565|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=T%C3%A4m%C3%A4%20kirja%20menee%20minulta%20yli%20hilseen.)
^fi-Q0565-answer

**fi-Q0566** — Tämä kirja menee minulta yli hilseen.

This book is above my understanding.

Expected form: **minulta**

Why: Ablative source. [[Finnish#^fi-Q0566|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=T%C3%A4m%C3%A4%20kirja%20menee%20minulta%20yli%20hilseen.)
^fi-Q0566-answer

**fi-Q0567** — Kysyn häneltä siitä huomenna.

I will ask him about it tomorrow.

Expected form: **häneltä**

Why: Ablative source. [[Finnish#^fi-Q0567|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Kysyn%20h%C3%A4nelt%C3%A4%20siit%C3%A4%20huomenna.)
^fi-Q0567-answer

**fi-Q0568** — Kysyn häneltä siitä huomenna.

I will ask him about it tomorrow.

Why: Ablative source. [[Finnish#^fi-Q0568|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Kysyn%20h%C3%A4nelt%C3%A4%20siit%C3%A4%20huomenna.)
^fi-Q0568-answer

**fi-Q0569** — Hän kysyi minulta, minne olen matkalla.

She asked me where I was going.

Why: Ablative source. [[Finnish#^fi-Q0569|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=H%C3%A4n%20kysyi%20minulta%2C%20minne%20olen%20matkalla.)
^fi-Q0569-answer

**fi-Q0570** — Hän kysyi minulta, minne olen matkalla.

She asked me where I was going.

Ablative -lta/-ltä commonly expresses movement away from a surface or a source/person. Contrast it with allative destination and adessive location.

Why: Ablative source. [[Finnish#^fi-Q0570|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=H%C3%A4n%20kysyi%20minulta%2C%20minne%20olen%20matkalla.)
^fi-Q0570-answer

**fi-Q0571** — Minun pitää kysyä sinulta monta kysymystä.

I've got a lot of questions I need to ask you.

Expected form: **sinulta**

Why: Ablative source. [[Finnish#^fi-Q0571|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Minun%20pit%C3%A4%C3%A4%20kysy%C3%A4%20sinulta%20monta%20kysymyst%C3%A4.)
^fi-Q0571-answer

**fi-Q0572** — Minun pitää kysyä sinulta monta kysymystä.

I've got a lot of questions I need to ask you.

Expected form: **sinulta**

Why: Ablative source. [[Finnish#^fi-Q0572|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Minun%20pit%C3%A4%C3%A4%20kysy%C3%A4%20sinulta%20monta%20kysymyst%C3%A4.)
^fi-Q0572-answer

**fi-Q0573** — Minä haluaisin pyytää sinulta palvelusta.

I have a favor to ask.

Expected form: **sinulta**

Why: Ablative source. [[Finnish#^fi-Q0573|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Min%C3%A4%20haluaisin%20pyyt%C3%A4%C3%A4%20sinulta%20palvelusta.)
^fi-Q0573-answer

**fi-Q0574** — Minä haluaisin pyytää sinulta palvelusta.

I have a favor to ask.

Why: Ablative source. [[Finnish#^fi-Q0574|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Min%C3%A4%20haluaisin%20pyyt%C3%A4%C3%A4%20sinulta%20palvelusta.)
^fi-Q0574-answer

**fi-Q0575** — Minulta kysytään tuota usein.

I get asked that question a lot.

Why: Ablative source. [[Finnish#^fi-Q0575|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Minulta%20kysyt%C3%A4%C3%A4n%20tuota%20usein.)
^fi-Q0575-answer

**fi-Q0576** — Minulta kysytään tuota usein.

I get asked that question a lot.

Ablative -lta/-ltä commonly expresses movement away from a surface or a source/person. Contrast it with allative destination and adessive location.

Why: Ablative source. [[Finnish#^fi-Q0576|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Minulta%20kysyt%C3%A4%C3%A4n%20tuota%20usein.)
^fi-Q0576-answer

**fi-Q0577** — Hän halusi kysyä minulta puutarhasta

He wanted to ask me about the garden.

Expected form: **minulta**

Why: Ablative source. [[Finnish#^fi-Q0577|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=H%C3%A4n%20halusi%20kysy%C3%A4%20minulta%20puutarhasta)
^fi-Q0577-answer

**fi-Q0578** — Hän halusi kysyä minulta puutarhasta

He wanted to ask me about the garden.

Expected form: **minulta**

Why: Ablative source. [[Finnish#^fi-Q0578|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=H%C3%A4n%20halusi%20kysy%C3%A4%20minulta%20puutarhasta)
^fi-Q0578-answer

**fi-Q0579** — Minulta loppui akku.

My battery died.

Expected form: **Minulta**

Why: Ablative source. [[Finnish#^fi-Q0579|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Minulta%20loppui%20akku.)
^fi-Q0579-answer

**fi-Q0580** — Minulta loppui akku.

My battery died.

Why: Ablative source. [[Finnish#^fi-Q0580|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Minulta%20loppui%20akku.)
^fi-Q0580-answer

**fi-Q0581** — Minulla ei ole mitään syytä olla tekemättä, mitä Tom minulta pyysi.

I have no reason not to do what Tom asked me to do.

Why: Ablative source. [[Finnish#^fi-Q0581|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Minulla%20ei%20ole%20mit%C3%A4%C3%A4n%20syyt%C3%A4%20olla%20tekem%C3%A4tt%C3%A4%2C%20mit%C3%A4%20Tom%20minulta%20pyysi.)
^fi-Q0581-answer

**fi-Q0582** — Minulla ei ole mitään syytä olla tekemättä, mitä Tom minulta pyysi.

I have no reason not to do what Tom asked me to do.

Ablative -lta/-ltä commonly expresses movement away from a surface or a source/person. Contrast it with allative destination and adessive location.

Why: Ablative source. [[Finnish#^fi-Q0582|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Minulla%20ei%20ole%20mit%C3%A4%C3%A4n%20syyt%C3%A4%20olla%20tekem%C3%A4tt%C3%A4%2C%20mit%C3%A4%20Tom%20minulta%20pyysi.)
^fi-Q0582-answer

**fi-Q0583** — Oli typerää sinulta tehdä niin kuin teit.

It was stupid of you to do what you did.

Expected form: **sinulta**

Why: Ablative source. [[Finnish#^fi-Q0583|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Oli%20typer%C3%A4%C3%A4%20sinulta%20tehd%C3%A4%20niin%20kuin%20teit.)
^fi-Q0583-answer

**fi-Q0584** — Oli typerää sinulta tehdä niin kuin teit.

It was stupid of you to do what you did.

Expected form: **sinulta**

Why: Ablative source. [[Finnish#^fi-Q0584|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Oli%20typer%C3%A4%C3%A4%20sinulta%20tehd%C3%A4%20niin%20kuin%20teit.)
^fi-Q0584-answer

**fi-Q0585** — Olisiko minun pitänyt kysyä sinulta ensin?

Should I have asked you first?

Expected form: **sinulta**

Why: Ablative source. [[Finnish#^fi-Q0585|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Olisiko%20minun%20pit%C3%A4nyt%20kysy%C3%A4%20sinulta%20ensin%3F)
^fi-Q0585-answer

**fi-Q0586** — Olisiko minun pitänyt kysyä sinulta ensin?

Should I have asked you first?

Why: Ablative source. [[Finnish#^fi-Q0586|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Olisiko%20minun%20pit%C3%A4nyt%20kysy%C3%A4%20sinulta%20ensin%3F)
^fi-Q0586-answer

**fi-Q0587** — Ei ole hyvä asia lainata häneltä rahaa.

It is not good to borrow money from him.

Why: Ablative source. [[Finnish#^fi-Q0587|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Ei%20ole%20hyv%C3%A4%20asia%20lainata%20h%C3%A4nelt%C3%A4%20rahaa.)
^fi-Q0587-answer

**fi-Q0588** — Ei ole hyvä asia lainata häneltä rahaa.

It is not good to borrow money from him.

Ablative -lta/-ltä commonly expresses movement away from a surface or a source/person. Contrast it with allative destination and adessive location.

Why: Ablative source. [[Finnish#^fi-Q0588|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Ei%20ole%20hyv%C3%A4%20asia%20lainata%20h%C3%A4nelt%C3%A4%20rahaa.)
^fi-Q0588-answer

**fi-Q0589** — Minulta irtosi paikka hampaasta.

I've lost a filling.

Expected form: **Minulta**

Why: Ablative source. [[Finnish#^fi-Q0589|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Minulta%20irtosi%20paikka%20hampaasta.)
^fi-Q0589-answer

**fi-Q0590** — Minulta irtosi paikka hampaasta.

I've lost a filling.

Expected form: **Minulta**

Why: Ablative source. [[Finnish#^fi-Q0590|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Minulta%20irtosi%20paikka%20hampaasta.)
^fi-Q0590-answer

**fi-Q0591** — Kerro Tomille paljon terveisiä minulta.

Please give my best regards to Tom.

Expected form: **minulta**

Why: Ablative source. [[Finnish#^fi-Q0591|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Kerro%20Tomille%20paljon%20terveisi%C3%A4%20minulta.)
^fi-Q0591-answer

**fi-Q0592** — Kerro Tomille paljon terveisiä minulta.

Please give my best regards to Tom.

Why: Ablative source. [[Finnish#^fi-Q0592|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Kerro%20Tomille%20paljon%20terveisi%C3%A4%20minulta.)
^fi-Q0592-answer

**fi-Q0593** — Kysy häneltä haluaako hän osallistua kokoukseen.

Ask him if he will attend the meeting.

Why: Ablative source. [[Finnish#^fi-Q0593|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Kysy%20h%C3%A4nelt%C3%A4%20haluaako%20h%C3%A4n%20osallistua%20kokoukseen.)
^fi-Q0593-answer

**fi-Q0594** — Kysy häneltä haluaako hän osallistua kokoukseen.

Ask him if he will attend the meeting.

Ablative -lta/-ltä commonly expresses movement away from a surface or a source/person. Contrast it with allative destination and adessive location.

Why: Ablative source. [[Finnish#^fi-Q0594|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Kysy%20h%C3%A4nelt%C3%A4%20haluaako%20h%C3%A4n%20osallistua%20kokoukseen.)
^fi-Q0594-answer

**fi-Q0595** — Tom luuli, että häneltä oli murtunut luu jalasta, mutta röntgenkuvasta näkyi, ettei se ollut murtunut.

Tom thought he'd broken a bone in his foot, but an X-ray showed that he hadn't.

Expected form: **häneltä**

Why: Ablative source. [[Finnish#^fi-Q0595|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tom%20luuli%2C%20ett%C3%A4%20h%C3%A4nelt%C3%A4%20oli%20murtunut%20luu%20jalasta%2C%20mutta%20r%C3%B6ntgenkuvasta%20n%C3%A4kyi%2C%20ettei%20se%20ollut%20murtunut.)
^fi-Q0595-answer

**fi-Q0596** — Tom luuli, että häneltä oli murtunut luu jalasta, mutta röntgenkuvasta näkyi, ettei se ollut murtunut.

Tom thought he'd broken a bone in his foot, but an X-ray showed that he hadn't.

Expected form: **häneltä**

Why: Ablative source. [[Finnish#^fi-Q0596|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tom%20luuli%2C%20ett%C3%A4%20h%C3%A4nelt%C3%A4%20oli%20murtunut%20luu%20jalasta%2C%20mutta%20r%C3%B6ntgenkuvasta%20n%C3%A4kyi%2C%20ettei%20se%20ollut%20murtunut.)
^fi-Q0596-answer

**fi-Q0597** — Hän kysyi minulta, että kuinka montaa kieltä puhun.

She asked me how many languages I spoke.

Expected form: **minulta**

Why: Ablative source. [[Finnish#^fi-Q0597|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=H%C3%A4n%20kysyi%20minulta%2C%20ett%C3%A4%20kuinka%20montaa%20kielt%C3%A4%20puhun.)
^fi-Q0597-answer

**fi-Q0598** — Hän kysyi minulta, että kuinka montaa kieltä puhun.

She asked me how many languages I spoke.

Why: Ablative source. [[Finnish#^fi-Q0598|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=H%C3%A4n%20kysyi%20minulta%2C%20ett%C3%A4%20kuinka%20montaa%20kielt%C3%A4%20puhun.)
^fi-Q0598-answer

**fi-Q0599** — Kuinka kauan sinä aioit pitää tämän salassa minulta?

How long were you planning on keeping this a secret from me?

Why: Ablative source. [[Finnish#^fi-Q0599|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Kuinka%20kauan%20sin%C3%A4%20aioit%20pit%C3%A4%C3%A4%20t%C3%A4m%C3%A4n%20salassa%20minulta%3F)
^fi-Q0599-answer

**fi-Q0600** — Kuinka kauan sinä aioit pitää tämän salassa minulta?

How long were you planning on keeping this a secret from me?

Ablative -lta/-ltä commonly expresses movement away from a surface or a source/person. Contrast it with allative destination and adessive location.

Why: Ablative source. [[Finnish#^fi-Q0600|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Kuinka%20kauan%20sin%C3%A4%20aioit%20pit%C3%A4%C3%A4%20t%C3%A4m%C3%A4n%20salassa%20minulta%3F)
^fi-Q0600-answer


### Answers 601–650

**fi-Q0601** — Tom olisi voittanut helposti.

Tom would've won easily.

Expected form: **olisi**

Why: Conditional forms. [[Finnish#^fi-Q0601|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tom%20olisi%20voittanut%20helposti.)
^fi-Q0601-answer

**fi-Q0602** — Tom olisi voittanut helposti.

Tom would've won easily.

Expected form: **olisi**

Why: Conditional forms. [[Finnish#^fi-Q0602|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tom%20olisi%20voittanut%20helposti.)
^fi-Q0602-answer

**fi-Q0603** — Hänen olisi pitänyt pitää suunsa kiinni.

She should have kept her mouth shut.

Expected form: **olisi**

Why: Conditional forms. [[Finnish#^fi-Q0603|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=H%C3%A4nen%20olisi%20pit%C3%A4nyt%20pit%C3%A4%C3%A4%20suunsa%20kiinni.)
^fi-Q0603-answer

**fi-Q0604** — Hänen olisi pitänyt pitää suunsa kiinni.

She should have kept her mouth shut.

Why: Conditional forms. [[Finnish#^fi-Q0604|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=H%C3%A4nen%20olisi%20pit%C3%A4nyt%20pit%C3%A4%C3%A4%20suunsa%20kiinni.)
^fi-Q0604-answer

**fi-Q0605** — Tom haluaa kysyä mitä Mari on puuhastellut, mutta hän tietää ettei hänen pitäisi.

Tom wants to ask what Mary has been doing, but he knows that he shouldn't.

Why: Conditional forms. [[Finnish#^fi-Q0605|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tom%20haluaa%20kysy%C3%A4%20mit%C3%A4%20Mari%20on%20puuhastellut%2C%20mutta%20h%C3%A4n%20tiet%C3%A4%C3%A4%20ettei%20h%C3%A4nen%20pit%C3%A4isi.)
^fi-Q0605-answer

**fi-Q0606** — Tom haluaa kysyä mitä Mari on puuhastellut, mutta hän tietää ettei hänen pitäisi.

Tom wants to ask what Mary has been doing, but he knows that he shouldn't.

The conditional often contains -isi- and can mark hypothetical or polite meanings. Person endings still matter. Pitäisi commonly expresses should/ought in a construction that may require genitive marking.

Why: Conditional forms. [[Finnish#^fi-Q0606|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tom%20haluaa%20kysy%C3%A4%20mit%C3%A4%20Mari%20on%20puuhastellut%2C%20mutta%20h%C3%A4n%20tiet%C3%A4%C3%A4%20ettei%20h%C3%A4nen%20pit%C3%A4isi.)
^fi-Q0606-answer

**fi-Q0607** — Silloin kun ajatte, pitäisi teidän keskittyä tiehen.

While you drive, you should focus on the road.

Expected form: **pitäisi**

Why: Conditional forms. [[Finnish#^fi-Q0607|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Silloin%20kun%20ajatte%2C%20pit%C3%A4isi%20teid%C3%A4n%20keskitty%C3%A4%20tiehen.)
^fi-Q0607-answer

**fi-Q0608** — Silloin kun ajatte, pitäisi teidän keskittyä tiehen.

While you drive, you should focus on the road.

Expected form: **pitäisi**

Why: Conditional forms. [[Finnish#^fi-Q0608|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Silloin%20kun%20ajatte%2C%20pit%C3%A4isi%20teid%C3%A4n%20keskitty%C3%A4%20tiehen.)
^fi-Q0608-answer

**fi-Q0609** — Tom toivoi, että olisi muistanut ostaa kukkia Marille.

Tom wished he had remembered to buy flowers for Mary.

Expected form: **olisi**

Why: Conditional forms. [[Finnish#^fi-Q0609|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tom%20toivoi%2C%20ett%C3%A4%20olisi%20muistanut%20ostaa%20kukkia%20Marille.)
^fi-Q0609-answer

**fi-Q0610** — Tom toivoi, että olisi muistanut ostaa kukkia Marille.

Tom wished he had remembered to buy flowers for Mary.

Why: Conditional forms. [[Finnish#^fi-Q0610|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tom%20toivoi%2C%20ett%C3%A4%20olisi%20muistanut%20ostaa%20kukkia%20Marille.)
^fi-Q0610-answer

**fi-Q0611** — Mitä Tom tekisi, jos hän saisi tietää?

What would Tom do if he found out?

Why: Conditional forms. [[Finnish#^fi-Q0611|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Mit%C3%A4%20Tom%20tekisi%2C%20jos%20h%C3%A4n%20saisi%20tiet%C3%A4%C3%A4%3F)
^fi-Q0611-answer

**fi-Q0612** — Mitä Tom tekisi, jos hän saisi tietää?

What would Tom do if he found out?

The conditional often contains -isi- and can mark hypothetical or polite meanings. Person endings still matter. Pitäisi commonly expresses should/ought in a construction that may require genitive marking.

Why: Conditional forms. [[Finnish#^fi-Q0612|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Mit%C3%A4%20Tom%20tekisi%2C%20jos%20h%C3%A4n%20saisi%20tiet%C3%A4%C3%A4%3F)
^fi-Q0612-answer

**fi-Q0613** — Tom pitäisi pyytää Marilta anteeksi sitä, ettei hän saapunut ajoissa.

Tom should apologize to Mary for not arriving on time.

Expected form: **pitäisi**

Why: Conditional forms. [[Finnish#^fi-Q0613|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tom%20pit%C3%A4isi%20pyyt%C3%A4%C3%A4%20Marilta%20anteeksi%20sit%C3%A4%2C%20ettei%20h%C3%A4n%20saapunut%20ajoissa.)
^fi-Q0613-answer

**fi-Q0614** — Tom pitäisi pyytää Marilta anteeksi sitä, ettei hän saapunut ajoissa.

Tom should apologize to Mary for not arriving on time.

Expected form: **pitäisi**

Why: Conditional forms. [[Finnish#^fi-Q0614|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tom%20pit%C3%A4isi%20pyyt%C3%A4%C3%A4%20Marilta%20anteeksi%20sit%C3%A4%2C%20ettei%20h%C3%A4n%20saapunut%20ajoissa.)
^fi-Q0614-answer

**fi-Q0615** — Luulen että sinun olisi parempi hieman levätä.

I think you'd better rest for a while.

Expected form: **olisi**

Why: Conditional forms. [[Finnish#^fi-Q0615|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Luulen%20ett%C3%A4%20sinun%20olisi%20parempi%20hieman%20lev%C3%A4t%C3%A4.)
^fi-Q0615-answer

**fi-Q0616** — Luulen että sinun olisi parempi hieman levätä.

I think you'd better rest for a while.

Why: Conditional forms. [[Finnish#^fi-Q0616|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Luulen%20ett%C3%A4%20sinun%20olisi%20parempi%20hieman%20lev%C3%A4t%C3%A4.)
^fi-Q0616-answer

**fi-Q0617** — Mielestäni sinun pitäisi olla varovainen.

I think you should be careful.

Why: Conditional forms. [[Finnish#^fi-Q0617|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Mielest%C3%A4ni%20sinun%20pit%C3%A4isi%20olla%20varovainen.)
^fi-Q0617-answer

**fi-Q0618** — Mielestäni sinun pitäisi olla varovainen.

I think you should be careful.

The conditional often contains -isi- and can mark hypothetical or polite meanings. Person endings still matter. Pitäisi commonly expresses should/ought in a construction that may require genitive marking.

Why: Conditional forms. [[Finnish#^fi-Q0618|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Mielest%C3%A4ni%20sinun%20pit%C3%A4isi%20olla%20varovainen.)
^fi-Q0618-answer

**fi-Q0619** — Teidän pitäisi pysyä vuoteessa.

You should stay in bed.

Expected form: **pitäisi**

Why: Conditional forms. [[Finnish#^fi-Q0619|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Teid%C3%A4n%20pit%C3%A4isi%20pysy%C3%A4%20vuoteessa.)
^fi-Q0619-answer

**fi-Q0620** — Teidän pitäisi pysyä vuoteessa.

You should stay in bed.

Expected form: **pitäisi**

Why: Conditional forms. [[Finnish#^fi-Q0620|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Teid%C3%A4n%20pit%C3%A4isi%20pysy%C3%A4%20vuoteessa.)
^fi-Q0620-answer

**fi-Q0621** — Tuollaista ei pitäisi tapahtua alkuunkaan.

That shouldn't happen at all.

Expected form: **pitäisi**

Why: Conditional forms. [[Finnish#^fi-Q0621|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tuollaista%20ei%20pit%C3%A4isi%20tapahtua%20alkuunkaan.)
^fi-Q0621-answer

**fi-Q0622** — Tuollaista ei pitäisi tapahtua alkuunkaan.

That shouldn't happen at all.

Why: Conditional forms. [[Finnish#^fi-Q0622|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tuollaista%20ei%20pit%C3%A4isi%20tapahtua%20alkuunkaan.)
^fi-Q0622-answer

**fi-Q0623** — Ottaisin sen jos olisin sinä.

I'd take it if I were you.

Why: Conditional forms. [[Finnish#^fi-Q0623|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Ottaisin%20sen%20jos%20olisin%20sin%C3%A4.)
^fi-Q0623-answer

**fi-Q0624** — Ottaisin sen jos olisin sinä.

I'd take it if I were you.

The conditional often contains -isi- and can mark hypothetical or polite meanings. Person endings still matter. Pitäisi commonly expresses should/ought in a construction that may require genitive marking.

Why: Conditional forms. [[Finnish#^fi-Q0624|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Ottaisin%20sen%20jos%20olisin%20sin%C3%A4.)
^fi-Q0624-answer

**fi-Q0625** — Sinun olisi pitänyt tehdä se aiemmin.

You should've done that sooner.

Expected form: **olisi**

Why: Conditional forms. [[Finnish#^fi-Q0625|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Sinun%20olisi%20pit%C3%A4nyt%20tehd%C3%A4%20se%20aiemmin.)
^fi-Q0625-answer

**fi-Q0626** — Sinun olisi pitänyt tehdä se aiemmin.

You should've done that sooner.

Expected form: **olisi**

Why: Conditional forms. [[Finnish#^fi-Q0626|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Sinun%20olisi%20pit%C3%A4nyt%20tehd%C3%A4%20se%20aiemmin.)
^fi-Q0626-answer

**fi-Q0627** — Olen edelleen sitä miltä, että meidän olisi pitänyt ostaa se maalaus, josta pidit.

I still think we should've bought the painting you liked.

Expected form: **olisi**

Why: Conditional forms. [[Finnish#^fi-Q0627|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Olen%20edelleen%20sit%C3%A4%20milt%C3%A4%2C%20ett%C3%A4%20meid%C3%A4n%20olisi%20pit%C3%A4nyt%20ostaa%20se%20maalaus%2C%20josta%20pidit.)
^fi-Q0627-answer

**fi-Q0628** — Olen edelleen sitä miltä, että meidän olisi pitänyt ostaa se maalaus, josta pidit.

I still think we should've bought the painting you liked.

Why: Conditional forms. [[Finnish#^fi-Q0628|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Olen%20edelleen%20sit%C3%A4%20milt%C3%A4%2C%20ett%C3%A4%20meid%C3%A4n%20olisi%20pit%C3%A4nyt%20ostaa%20se%20maalaus%2C%20josta%20pidit.)
^fi-Q0628-answer

**fi-Q0629** — Tuota minun ei olisi tarvinnut kuulla.

I didn't need to hear that.

Why: Conditional forms. [[Finnish#^fi-Q0629|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tuota%20minun%20ei%20olisi%20tarvinnut%20kuulla.)
^fi-Q0629-answer

**fi-Q0630** — Tuota minun ei olisi tarvinnut kuulla.

I didn't need to hear that.

The conditional often contains -isi- and can mark hypothetical or polite meanings. Person endings still matter. Pitäisi commonly expresses should/ought in a construction that may require genitive marking.

Why: Conditional forms. [[Finnish#^fi-Q0630|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tuota%20minun%20ei%20olisi%20tarvinnut%20kuulla.)
^fi-Q0630-answer

**fi-Q0631** — Ajatus Jumalasta olisi paljon mielenkiintoisempi, jos hän olisi löytänyt ihmiset sen sijaan, että hän olisi luonut heidät.

The idea of God would be more interesting if instead of having created humans he had found them.

Expected form: **olisi**

Why: Conditional forms. [[Finnish#^fi-Q0631|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Ajatus%20Jumalasta%20olisi%20paljon%20mielenkiintoisempi%2C%20jos%20h%C3%A4n%20olisi%20l%C3%B6yt%C3%A4nyt%20ihmiset%20sen%20sijaan%2C%20ett%C3%A4%20h%C3%A4n%20olisi%20luonut%20heid%C3%A4t.)
^fi-Q0631-answer

**fi-Q0632** — Ajatus Jumalasta olisi paljon mielenkiintoisempi, jos hän olisi löytänyt ihmiset sen sijaan, että hän olisi luonut heidät.

The idea of God would be more interesting if instead of having created humans he had found them.

Expected form: **olisi**

Why: Conditional forms. [[Finnish#^fi-Q0632|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Ajatus%20Jumalasta%20olisi%20paljon%20mielenkiintoisempi%2C%20jos%20h%C3%A4n%20olisi%20l%C3%B6yt%C3%A4nyt%20ihmiset%20sen%20sijaan%2C%20ett%C3%A4%20h%C3%A4n%20olisi%20luonut%20heid%C3%A4t.)
^fi-Q0632-answer

**fi-Q0633** — Sinun pitäisi toteuttaa ensimmäinen suunnitelmasi.

You should carry out your first plan.

Expected form: **pitäisi**

Why: Conditional forms. [[Finnish#^fi-Q0633|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Sinun%20pit%C3%A4isi%20toteuttaa%20ensimm%C3%A4inen%20suunnitelmasi.)
^fi-Q0633-answer

**fi-Q0634** — Sinun pitäisi toteuttaa ensimmäinen suunnitelmasi.

You should carry out your first plan.

Why: Conditional forms. [[Finnish#^fi-Q0634|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Sinun%20pit%C3%A4isi%20toteuttaa%20ensimm%C3%A4inen%20suunnitelmasi.)
^fi-Q0634-answer

**fi-Q0635** — Minulla ei ollut aavistustakaan, että Tomin äiti olisi japanilainen.

I never knew Tom's mother was Japanese.

Why: Conditional forms. [[Finnish#^fi-Q0635|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Minulla%20ei%20ollut%20aavistustakaan%2C%20ett%C3%A4%20Tomin%20%C3%A4iti%20olisi%20japanilainen.)
^fi-Q0635-answer

**fi-Q0636** — Minulla ei ollut aavistustakaan, että Tomin äiti olisi japanilainen.

I never knew Tom's mother was Japanese.

The conditional often contains -isi- and can mark hypothetical or polite meanings. Person endings still matter. Pitäisi commonly expresses should/ought in a construction that may require genitive marking.

Why: Conditional forms. [[Finnish#^fi-Q0636|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Minulla%20ei%20ollut%20aavistustakaan%2C%20ett%C3%A4%20Tomin%20%C3%A4iti%20olisi%20japanilainen.)
^fi-Q0636-answer

**fi-Q0637** — Meidän ei pitäisi vetää liian hätäisiä johtopäätöksiä.

We shouldn't jump to conclusions.

Expected form: **pitäisi**

Why: Conditional forms. [[Finnish#^fi-Q0637|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Meid%C3%A4n%20ei%20pit%C3%A4isi%20vet%C3%A4%C3%A4%20liian%20h%C3%A4t%C3%A4isi%C3%A4%20johtop%C3%A4%C3%A4t%C3%B6ksi%C3%A4.)
^fi-Q0637-answer

**fi-Q0638** — Meidän ei pitäisi vetää liian hätäisiä johtopäätöksiä.

We shouldn't jump to conclusions.

Expected form: **pitäisi**

Why: Conditional forms. [[Finnish#^fi-Q0638|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Meid%C3%A4n%20ei%20pit%C3%A4isi%20vet%C3%A4%C3%A4%20liian%20h%C3%A4t%C3%A4isi%C3%A4%20johtop%C3%A4%C3%A4t%C3%B6ksi%C3%A4.)
^fi-Q0638-answer

**fi-Q0639** — Sinun olisi pitänyt suudella Tomia.

You should've kissed Tom.

Expected form: **olisi**

Why: Conditional forms. [[Finnish#^fi-Q0639|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Sinun%20olisi%20pit%C3%A4nyt%20suudella%20Tomia.)
^fi-Q0639-answer

**fi-Q0640** — Sinun olisi pitänyt suudella Tomia.

You should've kissed Tom.

Why: Conditional forms. [[Finnish#^fi-Q0640|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Sinun%20olisi%20pit%C3%A4nyt%20suudella%20Tomia.)
^fi-Q0640-answer

**fi-Q0641** — Sinun olisi parempi käydä hammaslääkärillä heti.

You'd better see a dentist at once.

Why: Conditional forms. [[Finnish#^fi-Q0641|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Sinun%20olisi%20parempi%20k%C3%A4yd%C3%A4%20hammasl%C3%A4%C3%A4k%C3%A4rill%C3%A4%20heti.)
^fi-Q0641-answer

**fi-Q0642** — Sinun olisi parempi käydä hammaslääkärillä heti.

You'd better see a dentist at once.

The conditional often contains -isi- and can mark hypothetical or polite meanings. Person endings still matter. Pitäisi commonly expresses should/ought in a construction that may require genitive marking.

Why: Conditional forms. [[Finnish#^fi-Q0642|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Sinun%20olisi%20parempi%20k%C3%A4yd%C3%A4%20hammasl%C3%A4%C3%A4k%C3%A4rill%C3%A4%20heti.)
^fi-Q0642-answer

**fi-Q0643** — Mitä meidän pitäisi tehdä tänään?

What should we do today?

Expected form: **pitäisi**

Why: Conditional forms. [[Finnish#^fi-Q0643|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Mit%C3%A4%20meid%C3%A4n%20pit%C3%A4isi%20tehd%C3%A4%20t%C3%A4n%C3%A4%C3%A4n%3F)
^fi-Q0643-answer

**fi-Q0644** — Mitä meidän pitäisi tehdä tänään?

What should we do today?

Expected form: **pitäisi**

Why: Conditional forms. [[Finnish#^fi-Q0644|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Mit%C3%A4%20meid%C3%A4n%20pit%C3%A4isi%20tehd%C3%A4%20t%C3%A4n%C3%A4%C3%A4n%3F)
^fi-Q0644-answer

**fi-Q0645** — Haisee siltä kuin joku olisi polttanut täällä.

It smells as though someone has been smoking in here.

Expected form: **olisi**

Why: Conditional forms. [[Finnish#^fi-Q0645|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Haisee%20silt%C3%A4%20kuin%20joku%20olisi%20polttanut%20t%C3%A4%C3%A4ll%C3%A4.)
^fi-Q0645-answer

**fi-Q0646** — Haisee siltä kuin joku olisi polttanut täällä.

It smells as though someone has been smoking in here.

Why: Conditional forms. [[Finnish#^fi-Q0646|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Haisee%20silt%C3%A4%20kuin%20joku%20olisi%20polttanut%20t%C3%A4%C3%A4ll%C3%A4.)
^fi-Q0646-answer

**fi-Q0647** — Sinun olisi parempi mennä nyt.

You had better go now.

Why: Conditional forms. [[Finnish#^fi-Q0647|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Sinun%20olisi%20parempi%20menn%C3%A4%20nyt.)
^fi-Q0647-answer

**fi-Q0648** — Sinun olisi parempi mennä nyt.

You had better go now.

The conditional often contains -isi- and can mark hypothetical or polite meanings. Person endings still matter. Pitäisi commonly expresses should/ought in a construction that may require genitive marking.

Why: Conditional forms. [[Finnish#^fi-Q0648|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Sinun%20olisi%20parempi%20menn%C3%A4%20nyt.)
^fi-Q0648-answer

**fi-Q0649** — Mistä voisin saada kartan?

Where can I get the map?

Expected form: **voisin**

Why: Conditional forms. [[Finnish#^fi-Q0649|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Mist%C3%A4%20voisin%20saada%20kartan%3F)
^fi-Q0649-answer

**fi-Q0650** — Mistä voisin saada kartan?

Where can I get the map?

Expected form: **voisin**

Why: Conditional forms. [[Finnish#^fi-Q0650|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Mist%C3%A4%20voisin%20saada%20kartan%3F)
^fi-Q0650-answer


### Answers 651–700

**fi-Q0651** — Mitä sitä ennen tapahtui?

What happened before that?

Expected form: **Mitä**

Why: Questions and question particle. [[Finnish#^fi-Q0651|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Mit%C3%A4%20sit%C3%A4%20ennen%20tapahtui%3F)
^fi-Q0651-answer

**fi-Q0652** — Mitä sitä ennen tapahtui?

What happened before that?

Why: Questions and question particle. [[Finnish#^fi-Q0652|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Mit%C3%A4%20sit%C3%A4%20ennen%20tapahtui%3F)
^fi-Q0652-answer

**fi-Q0653** — Meidän täytyy kertoa kaikille mitä tapahtui.

We have to tell everybody what happened.

Why: Questions and question particle. [[Finnish#^fi-Q0653|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Meid%C3%A4n%20t%C3%A4ytyy%20kertoa%20kaikille%20mit%C3%A4%20tapahtui.)
^fi-Q0653-answer

**fi-Q0654** — Meidän täytyy kertoa kaikille mitä tapahtui.

We have to tell everybody what happened.

Question words inflect for the needed case. The clitic -ko/-kö can turn a focused word into a yes/no question. It follows vowel harmony and can attach to more than verbs.

Why: Questions and question particle. [[Finnish#^fi-Q0654|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Meid%C3%A4n%20t%C3%A4ytyy%20kertoa%20kaikille%20mit%C3%A4%20tapahtui.)
^fi-Q0654-answer

**fi-Q0655** — Onko lehmällä vaaleanpunaiset utareet?

Does a cow have a pink udder?

Expected form: **Onko**

Why: Questions and question particle. [[Finnish#^fi-Q0655|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Onko%20lehm%C3%A4ll%C3%A4%20vaaleanpunaiset%20utareet%3F)
^fi-Q0655-answer

**fi-Q0656** — Onko lehmällä vaaleanpunaiset utareet?

Does a cow have a pink udder?

Expected form: **Onko**

Why: Questions and question particle. [[Finnish#^fi-Q0656|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Onko%20lehm%C3%A4ll%C3%A4%20vaaleanpunaiset%20utareet%3F)
^fi-Q0656-answer

**fi-Q0657** — Tiedätkö miksi kevätkääryleitä sanotaan kevätkääryleiksi?

Do you know why spring rolls are called spring rolls?

Expected form: **miksi**

Why: Questions and question particle. [[Finnish#^fi-Q0657|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tied%C3%A4tk%C3%B6%20miksi%20kev%C3%A4tk%C3%A4%C3%A4ryleit%C3%A4%20sanotaan%20kev%C3%A4tk%C3%A4%C3%A4ryleiksi%3F)
^fi-Q0657-answer

**fi-Q0658** — Tiedätkö miksi kevätkääryleitä sanotaan kevätkääryleiksi?

Do you know why spring rolls are called spring rolls?

Why: Questions and question particle. [[Finnish#^fi-Q0658|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tied%C3%A4tk%C3%B6%20miksi%20kev%C3%A4tk%C3%A4%C3%A4ryleit%C3%A4%20sanotaan%20kev%C3%A4tk%C3%A4%C3%A4ryleiksi%3F)
^fi-Q0658-answer

**fi-Q0659** — Mitä haluaisit aamiaiseksi?

What would you like for breakfast?

Why: Questions and question particle. [[Finnish#^fi-Q0659|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Mit%C3%A4%20haluaisit%20aamiaiseksi%3F)
^fi-Q0659-answer

**fi-Q0660** — Mitä haluaisit aamiaiseksi?

What would you like for breakfast?

Question words inflect for the needed case. The clitic -ko/-kö can turn a focused word into a yes/no question. It follows vowel harmony and can attach to more than verbs.

Why: Questions and question particle. [[Finnish#^fi-Q0660|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Mit%C3%A4%20haluaisit%20aamiaiseksi%3F)
^fi-Q0660-answer

**fi-Q0661** — Oletko australialainen vai uusiseelantilainen?

Are you Australian or Kiwi?

Expected form: **Oletko**

Why: Questions and question particle. [[Finnish#^fi-Q0661|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Oletko%20australialainen%20vai%20uusiseelantilainen%3F)
^fi-Q0661-answer

**fi-Q0662** — Oletko australialainen vai uusiseelantilainen?

Are you Australian or Kiwi?

Expected form: **Oletko**

Why: Questions and question particle. [[Finnish#^fi-Q0662|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Oletko%20australialainen%20vai%20uusiseelantilainen%3F)
^fi-Q0662-answer

**fi-Q0663** — Onko tämä kuva, jonka hän on piirtänyt itse?

Is this a picture that he drew by himself?

Expected form: **Onko**

Why: Questions and question particle. [[Finnish#^fi-Q0663|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Onko%20t%C3%A4m%C3%A4%20kuva%2C%20jonka%20h%C3%A4n%20on%20piirt%C3%A4nyt%20itse%3F)
^fi-Q0663-answer

**fi-Q0664** — Onko tämä kuva, jonka hän on piirtänyt itse?

Is this a picture that he drew by himself?

Why: Questions and question particle. [[Finnish#^fi-Q0664|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Onko%20t%C3%A4m%C3%A4%20kuva%2C%20jonka%20h%C3%A4n%20on%20piirt%C3%A4nyt%20itse%3F)
^fi-Q0664-answer

**fi-Q0665** — Miten menee, Tom?

How are you, Tom?

Why: Questions and question particle. [[Finnish#^fi-Q0665|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Miten%20menee%2C%20Tom%3F)
^fi-Q0665-answer

**fi-Q0666** — Miten menee, Tom?

How are you, Tom?

Question words inflect for the needed case. The clitic -ko/-kö can turn a focused word into a yes/no question. It follows vowel harmony and can attach to more than verbs.

Why: Questions and question particle. [[Finnish#^fi-Q0666|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Miten%20menee%2C%20Tom%3F)
^fi-Q0666-answer

**fi-Q0667** — En uskon mitään, mitä en ole omin silmin nähnyt.

I don't believe anything I haven't seen with my own eyes.

Expected form: **mitä**

Why: Questions and question particle. [[Finnish#^fi-Q0667|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=En%20uskon%20mit%C3%A4%C3%A4n%2C%20mit%C3%A4%20en%20ole%20omin%20silmin%20n%C3%A4hnyt.)
^fi-Q0667-answer

**fi-Q0668** — En uskon mitään, mitä en ole omin silmin nähnyt.

I don't believe anything I haven't seen with my own eyes.

Expected form: **mitä**

Why: Questions and question particle. [[Finnish#^fi-Q0668|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=En%20uskon%20mit%C3%A4%C3%A4n%2C%20mit%C3%A4%20en%20ole%20omin%20silmin%20n%C3%A4hnyt.)
^fi-Q0668-answer

**fi-Q0669** — Miten menet kouluun?

How do you get to school?

Expected form: **Miten**

Why: Questions and question particle. [[Finnish#^fi-Q0669|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Miten%20menet%20kouluun%3F)
^fi-Q0669-answer

**fi-Q0670** — Miten menet kouluun?

How do you get to school?

Why: Questions and question particle. [[Finnish#^fi-Q0670|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Miten%20menet%20kouluun%3F)
^fi-Q0670-answer

**fi-Q0671** — Oletko ollut ollenkaan ulkona?

Have you been out at all?

Why: Questions and question particle. [[Finnish#^fi-Q0671|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Oletko%20ollut%20ollenkaan%20ulkona%3F)
^fi-Q0671-answer

**fi-Q0672** — Oletko ollut ollenkaan ulkona?

Have you been out at all?

Question words inflect for the needed case. The clitic -ko/-kö can turn a focused word into a yes/no question. It follows vowel harmony and can attach to more than verbs.

Why: Questions and question particle. [[Finnish#^fi-Q0672|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Oletko%20ollut%20ollenkaan%20ulkona%3F)
^fi-Q0672-answer

**fi-Q0673** — Oletko samaa mieltä?

Do you agree?

Expected form: **Oletko**

Why: Questions and question particle. [[Finnish#^fi-Q0673|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Oletko%20samaa%20mielt%C3%A4%3F)
^fi-Q0673-answer

**fi-Q0674** — Oletko samaa mieltä?

Do you agree?

Expected form: **Oletko**

Why: Questions and question particle. [[Finnish#^fi-Q0674|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Oletko%20samaa%20mielt%C3%A4%3F)
^fi-Q0674-answer

**fi-Q0675** — Oletko valmis laittamaan sen sisään?

Are you ready to put it in?

Expected form: **Oletko**

Why: Questions and question particle. [[Finnish#^fi-Q0675|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Oletko%20valmis%20laittamaan%20sen%20sis%C3%A4%C3%A4n%3F)
^fi-Q0675-answer

**fi-Q0676** — Oletko valmis laittamaan sen sisään?

Are you ready to put it in?

Why: Questions and question particle. [[Finnish#^fi-Q0676|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Oletko%20valmis%20laittamaan%20sen%20sis%C3%A4%C3%A4n%3F)
^fi-Q0676-answer

**fi-Q0677** — Onko Suomi vaarallinen?

Is Finland dangerous?

Why: Questions and question particle. [[Finnish#^fi-Q0677|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Onko%20Suomi%20vaarallinen%3F)
^fi-Q0677-answer

**fi-Q0678** — Onko Suomi vaarallinen?

Is Finland dangerous?

Question words inflect for the needed case. The clitic -ko/-kö can turn a focused word into a yes/no question. It follows vowel harmony and can attach to more than verbs.

Why: Questions and question particle. [[Finnish#^fi-Q0678|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Onko%20Suomi%20vaarallinen%3F)
^fi-Q0678-answer

**fi-Q0679** — Mitä sinä ostit?

What did you buy?

Expected form: **Mitä**

Why: Questions and question particle. [[Finnish#^fi-Q0679|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Mit%C3%A4%20sin%C3%A4%20ostit%3F)
^fi-Q0679-answer

**fi-Q0680** — Mitä sinä ostit?

What did you buy?

Expected form: **Mitä**

Why: Questions and question particle. [[Finnish#^fi-Q0680|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Mit%C3%A4%20sin%C3%A4%20ostit%3F)
^fi-Q0680-answer

**fi-Q0681** — Onko tuo oikeasti totta?

Is that really true?

Expected form: **Onko**

Why: Questions and question particle. [[Finnish#^fi-Q0681|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Onko%20tuo%20oikeasti%20totta%3F)
^fi-Q0681-answer

**fi-Q0682** — Onko tuo oikeasti totta?

Is that really true?

Why: Questions and question particle. [[Finnish#^fi-Q0682|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Onko%20tuo%20oikeasti%20totta%3F)
^fi-Q0682-answer

**fi-Q0683** — Tom tahtoi tietää mitä sattui.

Tom wanted to know what happened.

Why: Questions and question particle. [[Finnish#^fi-Q0683|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tom%20tahtoi%20tiet%C3%A4%C3%A4%20mit%C3%A4%20sattui.)
^fi-Q0683-answer

**fi-Q0684** — Tom tahtoi tietää mitä sattui.

Tom wanted to know what happened.

Question words inflect for the needed case. The clitic -ko/-kö can turn a focused word into a yes/no question. It follows vowel harmony and can attach to more than verbs.

Why: Questions and question particle. [[Finnish#^fi-Q0684|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tom%20tahtoi%20tiet%C3%A4%C3%A4%20mit%C3%A4%20sattui.)
^fi-Q0684-answer

**fi-Q0685** — Mitä sinä odotat?

What are you waiting for?

Expected form: **Mitä**

Why: Questions and question particle. [[Finnish#^fi-Q0685|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Mit%C3%A4%20sin%C3%A4%20odotat%3F)
^fi-Q0685-answer

**fi-Q0686** — Mitä sinä odotat?

What are you waiting for?

Expected form: **Mitä**

Why: Questions and question particle. [[Finnish#^fi-Q0686|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Mit%C3%A4%20sin%C3%A4%20odotat%3F)
^fi-Q0686-answer

**fi-Q0687** — Miten kirjoitetaan Kleopatra hieroglyfeillä?

How do you write Cleopatra in hieroglyphs?

Expected form: **Miten**

Why: Questions and question particle. [[Finnish#^fi-Q0687|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Miten%20kirjoitetaan%20Kleopatra%20hieroglyfeill%C3%A4%3F)
^fi-Q0687-answer

**fi-Q0688** — Miten kirjoitetaan Kleopatra hieroglyfeillä?

How do you write Cleopatra in hieroglyphs?

Why: Questions and question particle. [[Finnish#^fi-Q0688|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Miten%20kirjoitetaan%20Kleopatra%20hieroglyfeill%C3%A4%3F)
^fi-Q0688-answer

**fi-Q0689** — Miksi lukitsit oven?

Why did you lock the door?

Why: Questions and question particle. [[Finnish#^fi-Q0689|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Miksi%20lukitsit%20oven%3F)
^fi-Q0689-answer

**fi-Q0690** — Miksi lukitsit oven?

Why did you lock the door?

Question words inflect for the needed case. The clitic -ko/-kö can turn a focused word into a yes/no question. It follows vowel harmony and can attach to more than verbs.

Why: Questions and question particle. [[Finnish#^fi-Q0690|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Miksi%20lukitsit%20oven%3F)
^fi-Q0690-answer

**fi-Q0691** — Kuka on menossa naimisiin?

Who's getting married?

Expected form: **Kuka**

Why: Questions and question particle. [[Finnish#^fi-Q0691|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Kuka%20on%20menossa%20naimisiin%3F)
^fi-Q0691-answer

**fi-Q0692** — Kuka on menossa naimisiin?

Who's getting married?

Expected form: **Kuka**

Why: Questions and question particle. [[Finnish#^fi-Q0692|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Kuka%20on%20menossa%20naimisiin%3F)
^fi-Q0692-answer

**fi-Q0693** — En usko, että Tom ymmärtää, mitä sanot.

I don't think Tom understands what you're saying.

Expected form: **mitä**

Why: Questions and question particle. [[Finnish#^fi-Q0693|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=En%20usko%2C%20ett%C3%A4%20Tom%20ymm%C3%A4rt%C3%A4%C3%A4%2C%20mit%C3%A4%20sanot.)
^fi-Q0693-answer

**fi-Q0694** — En usko, että Tom ymmärtää, mitä sanot.

I don't think Tom understands what you're saying.

Why: Questions and question particle. [[Finnish#^fi-Q0694|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=En%20usko%2C%20ett%C3%A4%20Tom%20ymm%C3%A4rt%C3%A4%C3%A4%2C%20mit%C3%A4%20sanot.)
^fi-Q0694-answer

**fi-Q0695** — Ymmärrätkö sinä mitä minä tarkoitan tuolla?

Did you understand what I meant by that?

Why: Questions and question particle. [[Finnish#^fi-Q0695|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Ymm%C3%A4rr%C3%A4tk%C3%B6%20sin%C3%A4%20mit%C3%A4%20min%C3%A4%20tarkoitan%20tuolla%3F)
^fi-Q0695-answer

**fi-Q0696** — Ymmärrätkö sinä mitä minä tarkoitan tuolla?

Did you understand what I meant by that?

Question words inflect for the needed case. The clitic -ko/-kö can turn a focused word into a yes/no question. It follows vowel harmony and can attach to more than verbs.

Why: Questions and question particle. [[Finnish#^fi-Q0696|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Ymm%C3%A4rr%C3%A4tk%C3%B6%20sin%C3%A4%20mit%C3%A4%20min%C3%A4%20tarkoitan%20tuolla%3F)
^fi-Q0696-answer

**fi-Q0697** — Mitä sinä aiot ottaa ruoaksi?

What are you going to have?

Expected form: **Mitä**

Why: Questions and question particle. [[Finnish#^fi-Q0697|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Mit%C3%A4%20sin%C3%A4%20aiot%20ottaa%20ruoaksi%3F)
^fi-Q0697-answer

**fi-Q0698** — Mitä sinä aiot ottaa ruoaksi?

What are you going to have?

Expected form: **Mitä**

Why: Questions and question particle. [[Finnish#^fi-Q0698|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Mit%C3%A4%20sin%C3%A4%20aiot%20ottaa%20ruoaksi%3F)
^fi-Q0698-answer

**fi-Q0699** — Miten minä voin nukkua?

How can I sleep?

Expected form: **Miten**

Why: Questions and question particle. [[Finnish#^fi-Q0699|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Miten%20min%C3%A4%20voin%20nukkua%3F)
^fi-Q0699-answer

**fi-Q0700** — Miten minä voin nukkua?

How can I sleep?

Why: Questions and question particle. [[Finnish#^fi-Q0700|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Miten%20min%C3%A4%20voin%20nukkua%3F)
^fi-Q0700-answer


### Answers 701–750

**fi-Q0701** — Matkustan melkein joka päivä.

I travel almost every day.

Why: Relative forms. [[Finnish#^fi-Q0701|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Matkustan%20melkein%20joka%20p%C3%A4iv%C3%A4.)
^fi-Q0701-answer

**fi-Q0702** — Matkustan melkein joka päivä.

I travel almost every day.

Joka forms relative clauses and inflects according to its role inside the clause. The antecedent helps choose number, but the relative clause supplies the case relation.

Why: Relative forms. [[Finnish#^fi-Q0702|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Matkustan%20melkein%20joka%20p%C3%A4iv%C3%A4.)
^fi-Q0702-answer

**fi-Q0703** — Voi olla, että se ei ollut Tomi, joka rikkoi ikkunan.

Tom might not be the one who broke the window.

Expected form: **joka**

Why: Relative forms. [[Finnish#^fi-Q0703|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Voi%20olla%2C%20ett%C3%A4%20se%20ei%20ollut%20Tomi%2C%20joka%20rikkoi%20ikkunan.)
^fi-Q0703-answer

**fi-Q0704** — Voi olla, että se ei ollut Tomi, joka rikkoi ikkunan.

Tom might not be the one who broke the window.

Expected form: **joka**

Why: Relative forms. [[Finnish#^fi-Q0704|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Voi%20olla%2C%20ett%C3%A4%20se%20ei%20ollut%20Tomi%2C%20joka%20rikkoi%20ikkunan.)
^fi-Q0704-answer

**fi-Q0705** — Te olette ainoita, jotka voivat auttaa minua.

You're the only one who can help me.

Expected form: **jotka**

Why: Relative forms. [[Finnish#^fi-Q0705|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Te%20olette%20ainoita%2C%20jotka%20voivat%20auttaa%20minua.)
^fi-Q0705-answer

**fi-Q0706** — Te olette ainoita, jotka voivat auttaa minua.

You're the only one who can help me.

Why: Relative forms. [[Finnish#^fi-Q0706|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Te%20olette%20ainoita%2C%20jotka%20voivat%20auttaa%20minua.)
^fi-Q0706-answer

**fi-Q0707** — Minä tunnen sen tytön, joka pelaa tennistä.

I know the girl who is playing tennis.

Why: Relative forms. [[Finnish#^fi-Q0707|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Min%C3%A4%20tunnen%20sen%20tyt%C3%B6n%2C%20joka%20pelaa%20tennist%C3%A4.)
^fi-Q0707-answer

**fi-Q0708** — Minä tunnen sen tytön, joka pelaa tennistä.

I know the girl who is playing tennis.

Joka forms relative clauses and inflects according to its role inside the clause. The antecedent helps choose number, but the relative clause supplies the case relation.

Why: Relative forms. [[Finnish#^fi-Q0708|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Min%C3%A4%20tunnen%20sen%20tyt%C3%B6n%2C%20joka%20pelaa%20tennist%C3%A4.)
^fi-Q0708-answer

**fi-Q0709** — Tuo tyttö joka pitää huivia on neitsyt.

That girl who's wearing a scarf is a virgin.

Expected form: **joka**

Why: Relative forms. [[Finnish#^fi-Q0709|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tuo%20tytt%C3%B6%20joka%20pit%C3%A4%C3%A4%20huivia%20on%20neitsyt.)
^fi-Q0709-answer

**fi-Q0710** — Tuo tyttö joka pitää huivia on neitsyt.

That girl who's wearing a scarf is a virgin.

Expected form: **joka**

Why: Relative forms. [[Finnish#^fi-Q0710|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tuo%20tytt%C3%B6%20joka%20pit%C3%A4%C3%A4%20huivia%20on%20neitsyt.)
^fi-Q0710-answer

**fi-Q0711** — Älykäs nainen on sellainen, jonka seurassa voi olla niin tyhmä kuin haluaa.

An intelligent woman is a woman with which one can be as stupid as they want.

Expected form: **jonka**

Why: Relative forms. [[Finnish#^fi-Q0711|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=%C3%84lyk%C3%A4s%20nainen%20on%20sellainen%2C%20jonka%20seurassa%20voi%20olla%20niin%20tyhm%C3%A4%20kuin%20haluaa.)
^fi-Q0711-answer

**fi-Q0712** — Älykäs nainen on sellainen, jonka seurassa voi olla niin tyhmä kuin haluaa.

An intelligent woman is a woman with which one can be as stupid as they want.

Why: Relative forms. [[Finnish#^fi-Q0712|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=%C3%84lyk%C3%A4s%20nainen%20on%20sellainen%2C%20jonka%20seurassa%20voi%20olla%20niin%20tyhm%C3%A4%20kuin%20haluaa.)
^fi-Q0712-answer

**fi-Q0713** — Jokaisesta joka työskenteli tuon projektin parissa tuli miljonääri.

Everyone who worked on that project became a millionaire.

Why: Relative forms. [[Finnish#^fi-Q0713|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Jokaisesta%20joka%20ty%C3%B6skenteli%20tuon%20projektin%20parissa%20tuli%20miljon%C3%A4%C3%A4ri.)
^fi-Q0713-answer

**fi-Q0714** — Jokaisesta joka työskenteli tuon projektin parissa tuli miljonääri.

Everyone who worked on that project became a millionaire.

Joka forms relative clauses and inflects according to its role inside the clause. The antecedent helps choose number, but the relative clause supplies the case relation.

Why: Relative forms. [[Finnish#^fi-Q0714|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Jokaisesta%20joka%20ty%C3%B6skenteli%20tuon%20projektin%20parissa%20tuli%20miljon%C3%A4%C3%A4ri.)
^fi-Q0714-answer

**fi-Q0715** — Asuimme hotellissa, jota ympäröivät puut.

We stayed at a hotel surrounded by trees.

Expected form: **jota**

Why: Relative forms. [[Finnish#^fi-Q0715|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Asuimme%20hotellissa%2C%20jota%20ymp%C3%A4r%C3%B6iv%C3%A4t%20puut.)
^fi-Q0715-answer

**fi-Q0716** — Asuimme hotellissa, jota ympäröivät puut.

We stayed at a hotel surrounded by trees.

Expected form: **jota**

Why: Relative forms. [[Finnish#^fi-Q0716|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Asuimme%20hotellissa%2C%20jota%20ymp%C3%A4r%C3%B6iv%C3%A4t%20puut.)
^fi-Q0716-answer

**fi-Q0717** — Kasvava lapsi, joka ei vaikuta kovin energiseltä, saattaa tarvita lääkäriä.

A growing child who doesn't seem to have much energy perhaps needs medical attention.

Expected form: **joka**

Why: Relative forms. [[Finnish#^fi-Q0717|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Kasvava%20lapsi%2C%20joka%20ei%20vaikuta%20kovin%20energiselt%C3%A4%2C%20saattaa%20tarvita%20l%C3%A4%C3%A4k%C3%A4ri%C3%A4.)
^fi-Q0717-answer

**fi-Q0718** — Kasvava lapsi, joka ei vaikuta kovin energiseltä, saattaa tarvita lääkäriä.

A growing child who doesn't seem to have much energy perhaps needs medical attention.

Why: Relative forms. [[Finnish#^fi-Q0718|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Kasvava%20lapsi%2C%20joka%20ei%20vaikuta%20kovin%20energiselt%C3%A4%2C%20saattaa%20tarvita%20l%C3%A4%C3%A4k%C3%A4ri%C3%A4.)
^fi-Q0718-answer

**fi-Q0719** — Olipa kerran kääpiö, joka asui metsässä.

Once upon a time there was a dwarf that lived in the forest.

Why: Relative forms. [[Finnish#^fi-Q0719|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Olipa%20kerran%20k%C3%A4%C3%A4pi%C3%B6%2C%20joka%20asui%20mets%C3%A4ss%C3%A4.)
^fi-Q0719-answer

**fi-Q0720** — Olipa kerran kääpiö, joka asui metsässä.

Once upon a time there was a dwarf that lived in the forest.

Joka forms relative clauses and inflects according to its role inside the clause. The antecedent helps choose number, but the relative clause supplies the case relation.

Why: Relative forms. [[Finnish#^fi-Q0720|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Olipa%20kerran%20k%C3%A4%C3%A4pi%C3%B6%2C%20joka%20asui%20mets%C3%A4ss%C3%A4.)
^fi-Q0720-answer

**fi-Q0721** — Onko jotain paikkaa, jossa voimme puhua?

Is there somewhere we can talk?

Expected form: **jossa**

Why: Relative forms. [[Finnish#^fi-Q0721|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Onko%20jotain%20paikkaa%2C%20jossa%20voimme%20puhua%3F)
^fi-Q0721-answer

**fi-Q0722** — Onko jotain paikkaa, jossa voimme puhua?

Is there somewhere we can talk?

Expected form: **jossa**

Why: Relative forms. [[Finnish#^fi-Q0722|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Onko%20jotain%20paikkaa%2C%20jossa%20voimme%20puhua%3F)
^fi-Q0722-answer

**fi-Q0723** — Se on riski, joka meidän on otettava.

It's a risk we have to take.

Expected form: **joka**

Why: Relative forms. [[Finnish#^fi-Q0723|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Se%20on%20riski%2C%20joka%20meid%C3%A4n%20on%20otettava.)
^fi-Q0723-answer

**fi-Q0724** — Se on riski, joka meidän on otettava.

It's a risk we have to take.

Why: Relative forms. [[Finnish#^fi-Q0724|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Se%20on%20riski%2C%20joka%20meid%C3%A4n%20on%20otettava.)
^fi-Q0724-answer

**fi-Q0725** — Tomilla on tytär, joka on erittäin kaunis.

Tom has a daughter who's very beautiful.

Why: Relative forms. [[Finnish#^fi-Q0725|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tomilla%20on%20tyt%C3%A4r%2C%20joka%20on%20eritt%C3%A4in%20kaunis.)
^fi-Q0725-answer

**fi-Q0726** — Tomilla on tytär, joka on erittäin kaunis.

Tom has a daughter who's very beautiful.

Joka forms relative clauses and inflects according to its role inside the clause. The antecedent helps choose number, but the relative clause supplies the case relation.

Why: Relative forms. [[Finnish#^fi-Q0726|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tomilla%20on%20tyt%C3%A4r%2C%20joka%20on%20eritt%C3%A4in%20kaunis.)
^fi-Q0726-answer

**fi-Q0727** — Jumituimme ruuhkaan, jonka takia myöhästyimme kaksikymmentä minuuttia.

We got stuck in a traffic jam, which made us twenty minutes late.

Expected form: **jonka**

Why: Relative forms. [[Finnish#^fi-Q0727|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Jumituimme%20ruuhkaan%2C%20jonka%20takia%20my%C3%B6h%C3%A4styimme%20kaksikymment%C3%A4%20minuuttia.)
^fi-Q0727-answer

**fi-Q0728** — Jumituimme ruuhkaan, jonka takia myöhästyimme kaksikymmentä minuuttia.

We got stuck in a traffic jam, which made us twenty minutes late.

Expected form: **jonka**

Why: Relative forms. [[Finnish#^fi-Q0728|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Jumituimme%20ruuhkaan%2C%20jonka%20takia%20my%C3%B6h%C3%A4styimme%20kaksikymment%C3%A4%20minuuttia.)
^fi-Q0728-answer

**fi-Q0729** — Joka iltapäivä nainen meni kirkkoon rukoilemaan.

Every afternoon, the woman went to church to pray.

Expected form: **Joka**

Why: Relative forms. [[Finnish#^fi-Q0729|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Joka%20iltap%C3%A4iv%C3%A4%20nainen%20meni%20kirkkoon%20rukoilemaan.)
^fi-Q0729-answer

**fi-Q0730** — Joka iltapäivä nainen meni kirkkoon rukoilemaan.

Every afternoon, the woman went to church to pray.

Why: Relative forms. [[Finnish#^fi-Q0730|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Joka%20iltap%C3%A4iv%C3%A4%20nainen%20meni%20kirkkoon%20rukoilemaan.)
^fi-Q0730-answer

**fi-Q0731** — Rautateiden verkosto levittäytyy joka puolelle Japania.

A network of railroads spreads all over Japan.

Why: Relative forms. [[Finnish#^fi-Q0731|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Rautateiden%20verkosto%20levitt%C3%A4ytyy%20joka%20puolelle%20Japania.)
^fi-Q0731-answer

**fi-Q0732** — Rautateiden verkosto levittäytyy joka puolelle Japania.

A network of railroads spreads all over Japan.

Joka forms relative clauses and inflects according to its role inside the clause. The antecedent helps choose number, but the relative clause supplies the case relation.

Why: Relative forms. [[Finnish#^fi-Q0732|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Rautateiden%20verkosto%20levitt%C3%A4ytyy%20joka%20puolelle%20Japania.)
^fi-Q0732-answer

**fi-Q0733** — Tuo on se talo, jossa majoitun.

That is the house that I stay in.

Expected form: **jossa**

Why: Relative forms. [[Finnish#^fi-Q0733|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tuo%20on%20se%20talo%2C%20jossa%20majoitun.)
^fi-Q0733-answer

**fi-Q0734** — Tuo on se talo, jossa majoitun.

That is the house that I stay in.

Expected form: **jossa**

Why: Relative forms. [[Finnish#^fi-Q0734|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tuo%20on%20se%20talo%2C%20jossa%20majoitun.)
^fi-Q0734-answer

**fi-Q0735** — Sain kirjeitä eräältä henkilöltä jota en ole koskaan tavannut.

I got letters from a person I've never met.

Expected form: **jota**

Why: Relative forms. [[Finnish#^fi-Q0735|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Sain%20kirjeit%C3%A4%20er%C3%A4%C3%A4lt%C3%A4%20henkil%C3%B6lt%C3%A4%20jota%20en%20ole%20koskaan%20tavannut.)
^fi-Q0735-answer

**fi-Q0736** — Sain kirjeitä eräältä henkilöltä jota en ole koskaan tavannut.

I got letters from a person I've never met.

Why: Relative forms. [[Finnish#^fi-Q0736|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Sain%20kirjeit%C3%A4%20er%C3%A4%C3%A4lt%C3%A4%20henkil%C3%B6lt%C3%A4%20jota%20en%20ole%20koskaan%20tavannut.)
^fi-Q0736-answer

**fi-Q0737** — Olipa kerran mahtava kuningas, joka asui Kreikassa.

Once upon a time, there lived a great king in Greece.

Why: Relative forms. [[Finnish#^fi-Q0737|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Olipa%20kerran%20mahtava%20kuningas%2C%20joka%20asui%20Kreikassa.)
^fi-Q0737-answer

**fi-Q0738** — Olipa kerran mahtava kuningas, joka asui Kreikassa.

Once upon a time, there lived a great king in Greece.

Joka forms relative clauses and inflects according to its role inside the clause. The antecedent helps choose number, but the relative clause supplies the case relation.

Why: Relative forms. [[Finnish#^fi-Q0738|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Olipa%20kerran%20mahtava%20kuningas%2C%20joka%20asui%20Kreikassa.)
^fi-Q0738-answer

**fi-Q0739** — He soittavat toisilleen lähes joka päivä.

They call each other almost every day.

Expected form: **joka**

Why: Relative forms. [[Finnish#^fi-Q0739|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=He%20soittavat%20toisilleen%20l%C3%A4hes%20joka%20p%C3%A4iv%C3%A4.)
^fi-Q0739-answer

**fi-Q0740** — He soittavat toisilleen lähes joka päivä.

They call each other almost every day.

Expected form: **joka**

Why: Relative forms. [[Finnish#^fi-Q0740|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=He%20soittavat%20toisilleen%20l%C3%A4hes%20joka%20p%C3%A4iv%C3%A4.)
^fi-Q0740-answer

**fi-Q0741** — Hänellä, joka ei lue, ei ole yliotetta häneen, joka ei osaa lukea.

A person who won't read has no advantage over one who can't read.

Expected form: **joka**

Why: Relative forms. [[Finnish#^fi-Q0741|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=H%C3%A4nell%C3%A4%2C%20joka%20ei%20lue%2C%20ei%20ole%20yliotetta%20h%C3%A4neen%2C%20joka%20ei%20osaa%20lukea.)
^fi-Q0741-answer

**fi-Q0742** — Hänellä, joka ei lue, ei ole yliotetta häneen, joka ei osaa lukea.

A person who won't read has no advantage over one who can't read.

Why: Relative forms. [[Finnish#^fi-Q0742|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=H%C3%A4nell%C3%A4%2C%20joka%20ei%20lue%2C%20ei%20ole%20yliotetta%20h%C3%A4neen%2C%20joka%20ei%20osaa%20lukea.)
^fi-Q0742-answer

**fi-Q0743** — Boston Dynamicin robotti RHex on ihmeellinen tekele, joka osaa juosta monenlaisessa maastossa.

Boston Dynamic's robot, RHex, is an amazing piece of work that can run over various terrains.

Why: Relative forms. [[Finnish#^fi-Q0743|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Boston%20Dynamicin%20robotti%20RHex%20on%20ihmeellinen%20tekele%2C%20joka%20osaa%20juosta%20monenlaisessa%20maastossa.)
^fi-Q0743-answer

**fi-Q0744** — Boston Dynamicin robotti RHex on ihmeellinen tekele, joka osaa juosta monenlaisessa maastossa.

Boston Dynamic's robot, RHex, is an amazing piece of work that can run over various terrains.

Joka forms relative clauses and inflects according to its role inside the clause. The antecedent helps choose number, but the relative clause supplies the case relation.

Why: Relative forms. [[Finnish#^fi-Q0744|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Boston%20Dynamicin%20robotti%20RHex%20on%20ihmeellinen%20tekele%2C%20joka%20osaa%20juosta%20monenlaisessa%20maastossa.)
^fi-Q0744-answer

**fi-Q0745** — Tomi on ainoa, joka osaa korjata tämän.

Tom is the only one who knows how to fix this.

Expected form: **joka**

Why: Relative forms. [[Finnish#^fi-Q0745|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tomi%20on%20ainoa%2C%20joka%20osaa%20korjata%20t%C3%A4m%C3%A4n.)
^fi-Q0745-answer

**fi-Q0746** — Tomi on ainoa, joka osaa korjata tämän.

Tom is the only one who knows how to fix this.

Expected form: **joka**

Why: Relative forms. [[Finnish#^fi-Q0746|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tomi%20on%20ainoa%2C%20joka%20osaa%20korjata%20t%C3%A4m%C3%A4n.)
^fi-Q0746-answer

**fi-Q0747** — Anna minulle paperinpala, johon voin kirjoittaa!

Give me a piece of paper to write on!

Expected form: **johon**

Why: Relative forms. [[Finnish#^fi-Q0747|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Anna%20minulle%20paperinpala%2C%20johon%20voin%20kirjoittaa%21)
^fi-Q0747-answer

**fi-Q0748** — Anna minulle paperinpala, johon voin kirjoittaa!

Give me a piece of paper to write on!

Why: Relative forms. [[Finnish#^fi-Q0748|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Anna%20minulle%20paperinpala%2C%20johon%20voin%20kirjoittaa%21)
^fi-Q0748-answer

**fi-Q0749** — Hän menee kouluun opiskelemaan joka päivä.

He goes to school to study every day.

Why: Relative forms. [[Finnish#^fi-Q0749|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=H%C3%A4n%20menee%20kouluun%20opiskelemaan%20joka%20p%C3%A4iv%C3%A4.)
^fi-Q0749-answer

**fi-Q0750** — Hän menee kouluun opiskelemaan joka päivä.

He goes to school to study every day.

Joka forms relative clauses and inflects according to its role inside the clause. The antecedent helps choose number, but the relative clause supplies the case relation.

Why: Relative forms. [[Finnish#^fi-Q0750|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=H%C3%A4n%20menee%20kouluun%20opiskelemaan%20joka%20p%C3%A4iv%C3%A4.)
^fi-Q0750-answer


### Answers 751–800

**fi-Q0751** — Voisitko katsoa hetken muualle kun vaihdan vaatteeni?

Would you mind looking the other way for just a minute while I change my clothes?

Expected form: **kun**

Why: Complement and condition. [[Finnish#^fi-Q0751|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Voisitko%20katsoa%20hetken%20muualle%20kun%20vaihdan%20vaatteeni%3F)
^fi-Q0751-answer

**fi-Q0752** — Voisitko katsoa hetken muualle kun vaihdan vaatteeni?

Would you mind looking the other way for just a minute while I change my clothes?

Expected form: **kun**

Why: Complement and condition. [[Finnish#^fi-Q0752|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Voisitko%20katsoa%20hetken%20muualle%20kun%20vaihdan%20vaatteeni%3F)
^fi-Q0752-answer

**fi-Q0753** — Olen pahoillani kun olen antanut sinun odottaa.

I'm sorry I've kept you waiting so long.

Expected form: **kun**

Why: Complement and condition. [[Finnish#^fi-Q0753|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Olen%20pahoillani%20kun%20olen%20antanut%20sinun%20odottaa.)
^fi-Q0753-answer

**fi-Q0754** — Olen pahoillani kun olen antanut sinun odottaa.

I'm sorry I've kept you waiting so long.

Why: Complement and condition. [[Finnish#^fi-Q0754|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Olen%20pahoillani%20kun%20olen%20antanut%20sinun%20odottaa.)
^fi-Q0754-answer

**fi-Q0755** — Yllä oleva diagrammi kommutoi aina ja vain, kun f on isomorfismi.

The diagram above commutes if and only if f is an isomorphism.

Why: Complement and condition. [[Finnish#^fi-Q0755|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Yll%C3%A4%20oleva%20diagrammi%20kommutoi%20aina%20ja%20vain%2C%20kun%20f%20on%20isomorfismi.)
^fi-Q0755-answer

**fi-Q0756** — Yllä oleva diagrammi kommutoi aina ja vain, kun f on isomorfismi.

The diagram above commutes if and only if f is an isomorphism.

Että introduces a content clause; jos a condition; kun a temporal clause; koska a cause; vaikka a concession. Finnish does not copy German verb-final order merely because a clause is subordinate.

Why: Complement and condition. [[Finnish#^fi-Q0756|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Yll%C3%A4%20oleva%20diagrammi%20kommutoi%20aina%20ja%20vain%2C%20kun%20f%20on%20isomorfismi.)
^fi-Q0756-answer

**fi-Q0757** — On sanomattakin selvää, että hän on onnellinen.

It goes without saying that she is happy.

Expected form: **että**

Why: Complement and condition. [[Finnish#^fi-Q0757|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=On%20sanomattakin%20selv%C3%A4%C3%A4%2C%20ett%C3%A4%20h%C3%A4n%20on%20onnellinen.)
^fi-Q0757-answer

**fi-Q0758** — On sanomattakin selvää, että hän on onnellinen.

It goes without saying that she is happy.

Expected form: **että**

Why: Complement and condition. [[Finnish#^fi-Q0758|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=On%20sanomattakin%20selv%C3%A4%C3%A4%2C%20ett%C3%A4%20h%C3%A4n%20on%20onnellinen.)
^fi-Q0758-answer

**fi-Q0759** — Luulin, että tänään on maanantai.

I thought it was Monday today.

Expected form: **että**

Why: Complement and condition. [[Finnish#^fi-Q0759|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Luulin%2C%20ett%C3%A4%20t%C3%A4n%C3%A4%C3%A4n%20on%20maanantai.)
^fi-Q0759-answer

**fi-Q0760** — Luulin, että tänään on maanantai.

I thought it was Monday today.

Why: Complement and condition. [[Finnish#^fi-Q0760|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Luulin%2C%20ett%C3%A4%20t%C3%A4n%C3%A4%C3%A4n%20on%20maanantai.)
^fi-Q0760-answer

**fi-Q0761** — Esittelen sinut Tomille, jos niin haluat.

I'll introduce you to Tom if you want me to.

Why: Complement and condition. [[Finnish#^fi-Q0761|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Esittelen%20sinut%20Tomille%2C%20jos%20niin%20haluat.)
^fi-Q0761-answer

**fi-Q0762** — Esittelen sinut Tomille, jos niin haluat.

I'll introduce you to Tom if you want me to.

Että introduces a content clause; jos a condition; kun a temporal clause; koska a cause; vaikka a concession. Finnish does not copy German verb-final order merely because a clause is subordinate.

Why: Complement and condition. [[Finnish#^fi-Q0762|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Esittelen%20sinut%20Tomille%2C%20jos%20niin%20haluat.)
^fi-Q0762-answer

**fi-Q0763** — Heti kun menet ulos asemalta, käänny vasemmalle.

As soon as you leave the station, turn left.

Expected form: **kun**

Why: Complement and condition. [[Finnish#^fi-Q0763|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Heti%20kun%20menet%20ulos%20asemalta%2C%20k%C3%A4%C3%A4nny%20vasemmalle.)
^fi-Q0763-answer

**fi-Q0764** — Heti kun menet ulos asemalta, käänny vasemmalle.

As soon as you leave the station, turn left.

Expected form: **kun**

Why: Complement and condition. [[Finnish#^fi-Q0764|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Heti%20kun%20menet%20ulos%20asemalta%2C%20k%C3%A4%C3%A4nny%20vasemmalle.)
^fi-Q0764-answer

**fi-Q0765** — Mitäpä jos vain jäisit?

Why not just stay?

Expected form: **jos**

Why: Complement and condition. [[Finnish#^fi-Q0765|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Mit%C3%A4p%C3%A4%20jos%20vain%20j%C3%A4isit%3F)
^fi-Q0765-answer

**fi-Q0766** — Mitäpä jos vain jäisit?

Why not just stay?

Why: Complement and condition. [[Finnish#^fi-Q0766|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Mit%C3%A4p%C3%A4%20jos%20vain%20j%C3%A4isit%3F)
^fi-Q0766-answer

**fi-Q0767** — Tyttö avasi oven, kun koputin.

A girl opened the door in answer to my knock.

Why: Complement and condition. [[Finnish#^fi-Q0767|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tytt%C3%B6%20avasi%20oven%2C%20kun%20koputin.)
^fi-Q0767-answer

**fi-Q0768** — Tyttö avasi oven, kun koputin.

A girl opened the door in answer to my knock.

Että introduces a content clause; jos a condition; kun a temporal clause; koska a cause; vaikka a concession. Finnish does not copy German verb-final order merely because a clause is subordinate.

Why: Complement and condition. [[Finnish#^fi-Q0768|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tytt%C3%B6%20avasi%20oven%2C%20kun%20koputin.)
^fi-Q0768-answer

**fi-Q0769** — Palauta kirja kun olet lukenut sen.

Please return the book when you have finished reading it.

Expected form: **kun**

Why: Complement and condition. [[Finnish#^fi-Q0769|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Palauta%20kirja%20kun%20olet%20lukenut%20sen.)
^fi-Q0769-answer

**fi-Q0770** — Palauta kirja kun olet lukenut sen.

Please return the book when you have finished reading it.

Expected form: **kun**

Why: Complement and condition. [[Finnish#^fi-Q0770|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Palauta%20kirja%20kun%20olet%20lukenut%20sen.)
^fi-Q0770-answer

**fi-Q0771** — Tiedän, että ette te valehtele.

I know you're not lying.

Expected form: **että**

Why: Complement and condition. [[Finnish#^fi-Q0771|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tied%C3%A4n%2C%20ett%C3%A4%20ette%20te%20valehtele.)
^fi-Q0771-answer

**fi-Q0772** — Tiedän, että ette te valehtele.

I know you're not lying.

Why: Complement and condition. [[Finnish#^fi-Q0772|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tied%C3%A4n%2C%20ett%C3%A4%20ette%20te%20valehtele.)
^fi-Q0772-answer

**fi-Q0773** — Sanon harkinnan jälkeen, että kristinusko, kirkkoihin järjestäytyneenä, on ollut ja on yhä yleismaallisen moraalisen kehityksen perivihollinen.

I say quite deliberately that the Christian religion, as organized in its churches, has been and still is the principal enemy of moral progress in the world.

Why: Complement and condition. [[Finnish#^fi-Q0773|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Sanon%20harkinnan%20j%C3%A4lkeen%2C%20ett%C3%A4%20kristinusko%2C%20kirkkoihin%20j%C3%A4rjest%C3%A4ytyneen%C3%A4%2C%20on%20ollut%20ja%20on%20yh%C3%A4%20yleismaallisen%20moraalisen%20kehityksen%20perivihollinen.)
^fi-Q0773-answer

**fi-Q0774** — Sanon harkinnan jälkeen, että kristinusko, kirkkoihin järjestäytyneenä, on ollut ja on yhä yleismaallisen moraalisen kehityksen perivihollinen.

I say quite deliberately that the Christian religion, as organized in its churches, has been and still is the principal enemy of moral progress in the world.

Että introduces a content clause; jos a condition; kun a temporal clause; koska a cause; vaikka a concession. Finnish does not copy German verb-final order merely because a clause is subordinate.

Why: Complement and condition. [[Finnish#^fi-Q0774|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Sanon%20harkinnan%20j%C3%A4lkeen%2C%20ett%C3%A4%20kristinusko%2C%20kirkkoihin%20j%C3%A4rjest%C3%A4ytyneen%C3%A4%2C%20on%20ollut%20ja%20on%20yh%C3%A4%20yleismaallisen%20moraalisen%20kehityksen%20perivihollinen.)
^fi-Q0774-answer

**fi-Q0775** — Protokollaa käytetään kun tietokoneet kommunikoivat keskenään, aivan kuten ihmisetkin.

A protocol is used when computers intercommunicate, just as human beings do.

Expected form: **kun**

Why: Complement and condition. [[Finnish#^fi-Q0775|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Protokollaa%20k%C3%A4ytet%C3%A4%C3%A4n%20kun%20tietokoneet%20kommunikoivat%20kesken%C3%A4%C3%A4n%2C%20aivan%20kuten%20ihmisetkin.)
^fi-Q0775-answer

**fi-Q0776** — Protokollaa käytetään kun tietokoneet kommunikoivat keskenään, aivan kuten ihmisetkin.

A protocol is used when computers intercommunicate, just as human beings do.

Expected form: **kun**

Why: Complement and condition. [[Finnish#^fi-Q0776|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Protokollaa%20k%C3%A4ytet%C3%A4%C3%A4n%20kun%20tietokoneet%20kommunikoivat%20kesken%C3%A4%C3%A4n%2C%20aivan%20kuten%20ihmisetkin.)
^fi-Q0776-answer

**fi-Q0777** — Et saa ikinä tietää, jos et kokeile.

You'll never know unless you try.

Expected form: **jos**

Why: Complement and condition. [[Finnish#^fi-Q0777|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Et%20saa%20ikin%C3%A4%20tiet%C3%A4%C3%A4%2C%20jos%20et%20kokeile.)
^fi-Q0777-answer

**fi-Q0778** — Et saa ikinä tietää, jos et kokeile.

You'll never know unless you try.

Why: Complement and condition. [[Finnish#^fi-Q0778|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Et%20saa%20ikin%C3%A4%20tiet%C3%A4%C3%A4%2C%20jos%20et%20kokeile.)
^fi-Q0778-answer

**fi-Q0779** — Kiitos, että huomasit kirjoitusvirheen!

Thanks for spotting the typo.

Why: Complement and condition. [[Finnish#^fi-Q0779|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Kiitos%2C%20ett%C3%A4%20huomasit%20kirjoitusvirheen%21)
^fi-Q0779-answer

**fi-Q0780** — Kiitos, että huomasit kirjoitusvirheen!

Thanks for spotting the typo.

Että introduces a content clause; jos a condition; kun a temporal clause; koska a cause; vaikka a concession. Finnish does not copy German verb-final order merely because a clause is subordinate.

Why: Complement and condition. [[Finnish#^fi-Q0780|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Kiitos%2C%20ett%C3%A4%20huomasit%20kirjoitusvirheen%21)
^fi-Q0780-answer

**fi-Q0781** — He huomasivat, että heidän perheensä eivät pitäneet toisistaan.

They found that their families didn't like each other.

Expected form: **että**

Why: Complement and condition. [[Finnish#^fi-Q0781|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=He%20huomasivat%2C%20ett%C3%A4%20heid%C3%A4n%20perheens%C3%A4%20eiv%C3%A4t%20pit%C3%A4neet%20toisistaan.)
^fi-Q0781-answer

**fi-Q0782** — He huomasivat, että heidän perheensä eivät pitäneet toisistaan.

They found that their families didn't like each other.

Expected form: **että**

Why: Complement and condition. [[Finnish#^fi-Q0782|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=He%20huomasivat%2C%20ett%C3%A4%20heid%C3%A4n%20perheens%C3%A4%20eiv%C3%A4t%20pit%C3%A4neet%20toisistaan.)
^fi-Q0782-answer

**fi-Q0783** — On hyvä merkki, jos heistä ei kuulu mitään.

No news is good news.

Expected form: **jos**

Why: Complement and condition. [[Finnish#^fi-Q0783|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=On%20hyv%C3%A4%20merkki%2C%20jos%20heist%C3%A4%20ei%20kuulu%20mit%C3%A4%C3%A4n.)
^fi-Q0783-answer

**fi-Q0784** — On hyvä merkki, jos heistä ei kuulu mitään.

No news is good news.

Why: Complement and condition. [[Finnish#^fi-Q0784|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=On%20hyv%C3%A4%20merkki%2C%20jos%20heist%C3%A4%20ei%20kuulu%20mit%C3%A4%C3%A4n.)
^fi-Q0784-answer

**fi-Q0785** — Tom tuntui luulevan, että sinä ja minä olisimme olleet aiemmin naimisissa.

Tom seemed to think that you and I used to be married.

Why: Complement and condition. [[Finnish#^fi-Q0785|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tom%20tuntui%20luulevan%2C%20ett%C3%A4%20sin%C3%A4%20ja%20min%C3%A4%20olisimme%20olleet%20aiemmin%20naimisissa.)
^fi-Q0785-answer

**fi-Q0786** — Tom tuntui luulevan, että sinä ja minä olisimme olleet aiemmin naimisissa.

Tom seemed to think that you and I used to be married.

Että introduces a content clause; jos a condition; kun a temporal clause; koska a cause; vaikka a concession. Finnish does not copy German verb-final order merely because a clause is subordinate.

Why: Complement and condition. [[Finnish#^fi-Q0786|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tom%20tuntui%20luulevan%2C%20ett%C3%A4%20sin%C3%A4%20ja%20min%C3%A4%20olisimme%20olleet%20aiemmin%20naimisissa.)
^fi-Q0786-answer

**fi-Q0787** — Jokainen sanoo että ruoka tässä ravintolassa on sekä herkullista että edullista.

Everyone says the food in this restaurant is both delicious and inexpensive.

Expected form: **että**

Why: Complement and condition. [[Finnish#^fi-Q0787|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Jokainen%20sanoo%20ett%C3%A4%20ruoka%20t%C3%A4ss%C3%A4%20ravintolassa%20on%20sek%C3%A4%20herkullista%20ett%C3%A4%20edullista.)
^fi-Q0787-answer

**fi-Q0788** — Jokainen sanoo että ruoka tässä ravintolassa on sekä herkullista että edullista.

Everyone says the food in this restaurant is both delicious and inexpensive.

Expected form: **että**

Why: Complement and condition. [[Finnish#^fi-Q0788|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Jokainen%20sanoo%20ett%C3%A4%20ruoka%20t%C3%A4ss%C3%A4%20ravintolassa%20on%20sek%C3%A4%20herkullista%20ett%C3%A4%20edullista.)
^fi-Q0788-answer

**fi-Q0789** — Koska saavut talolle?

When will you be arriving to the house?

Expected form: **Koska**

Why: Complement and condition. [[Finnish#^fi-Q0789|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Koska%20saavut%20talolle%3F)
^fi-Q0789-answer

**fi-Q0790** — Koska saavut talolle?

When will you be arriving to the house?

Why: Complement and condition. [[Finnish#^fi-Q0790|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Koska%20saavut%20talolle%3F)
^fi-Q0790-answer

**fi-Q0791** — Tule lähemmäksi, että näen sinun kasvosi.

Come nearer so that I can see your face.

Why: Complement and condition. [[Finnish#^fi-Q0791|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tule%20l%C3%A4hemm%C3%A4ksi%2C%20ett%C3%A4%20n%C3%A4en%20sinun%20kasvosi.)
^fi-Q0791-answer

**fi-Q0792** — Tule lähemmäksi, että näen sinun kasvosi.

Come nearer so that I can see your face.

Että introduces a content clause; jos a condition; kun a temporal clause; koska a cause; vaikka a concession. Finnish does not copy German verb-final order merely because a clause is subordinate.

Why: Complement and condition. [[Finnish#^fi-Q0792|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tule%20l%C3%A4hemm%C3%A4ksi%2C%20ett%C3%A4%20n%C3%A4en%20sinun%20kasvosi.)
^fi-Q0792-answer

**fi-Q0793** — Tom ei tiedä, että olen olemassa.

Tom doesn't know I exist.

Expected form: **että**

Why: Complement and condition. [[Finnish#^fi-Q0793|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tom%20ei%20tied%C3%A4%2C%20ett%C3%A4%20olen%20olemassa.)
^fi-Q0793-answer

**fi-Q0794** — Tom ei tiedä, että olen olemassa.

Tom doesn't know I exist.

Expected form: **että**

Why: Complement and condition. [[Finnish#^fi-Q0794|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tom%20ei%20tied%C3%A4%2C%20ett%C3%A4%20olen%20olemassa.)
^fi-Q0794-answer

**fi-Q0795** — Harva asia vetää vertoja ilolle lapsesi kasvoilla, kun hän avaa joululahjojaan.

Few things can compare to the joy on your child's face as they open their Christmas presents.

Expected form: **kun**

Why: Complement and condition. [[Finnish#^fi-Q0795|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Harva%20asia%20vet%C3%A4%C3%A4%20vertoja%20ilolle%20lapsesi%20kasvoilla%2C%20kun%20h%C3%A4n%20avaa%20joululahjojaan.)
^fi-Q0795-answer

**fi-Q0796** — Harva asia vetää vertoja ilolle lapsesi kasvoilla, kun hän avaa joululahjojaan.

Few things can compare to the joy on your child's face as they open their Christmas presents.

Why: Complement and condition. [[Finnish#^fi-Q0796|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Harva%20asia%20vet%C3%A4%C3%A4%20vertoja%20ilolle%20lapsesi%20kasvoilla%2C%20kun%20h%C3%A4n%20avaa%20joululahjojaan.)
^fi-Q0796-answer

**fi-Q0797** — Asiakas on aina oikeassa, silloinkin kun ei ole.

The customer's always right, even when they're not.

Why: Complement and condition. [[Finnish#^fi-Q0797|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Asiakas%20on%20aina%20oikeassa%2C%20silloinkin%20kun%20ei%20ole.)
^fi-Q0797-answer

**fi-Q0798** — Asiakas on aina oikeassa, silloinkin kun ei ole.

The customer's always right, even when they're not.

Että introduces a content clause; jos a condition; kun a temporal clause; koska a cause; vaikka a concession. Finnish does not copy German verb-final order merely because a clause is subordinate.

Why: Complement and condition. [[Finnish#^fi-Q0798|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Asiakas%20on%20aina%20oikeassa%2C%20silloinkin%20kun%20ei%20ole.)
^fi-Q0798-answer

**fi-Q0799** — Olen iloinen, että se en ollut minä.

I'm glad it wasn't me.

Expected form: **että**

Why: Complement and condition. [[Finnish#^fi-Q0799|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Olen%20iloinen%2C%20ett%C3%A4%20se%20en%20ollut%20min%C3%A4.)
^fi-Q0799-answer

**fi-Q0800** — Olen iloinen, että se en ollut minä.

I'm glad it wasn't me.

Expected form: **että**

Why: Complement and condition. [[Finnish#^fi-Q0800|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Olen%20iloinen%2C%20ett%C3%A4%20se%20en%20ollut%20min%C3%A4.)
^fi-Q0800-answer


### Answers 801–850

**fi-Q0801** — Autapa minua näiden matkatavaroiden kanssa.

Just help me with this baggage.

Expected form: **kanssa**

Why: Postpositions. [[Finnish#^fi-Q0801|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Autapa%20minua%20n%C3%A4iden%20matkatavaroiden%20kanssa.)
^fi-Q0801-answer

**fi-Q0802** — Autapa minua näiden matkatavaroiden kanssa.

Just help me with this baggage.

Why: Postpositions. [[Finnish#^fi-Q0802|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Autapa%20minua%20n%C3%A4iden%20matkatavaroiden%20kanssa.)
^fi-Q0802-answer

**fi-Q0803** — Menikö hän Hangzhouhun isänsä kanssa?

Did he go to Hangzhou with his dad?

Why: Postpositions. [[Finnish#^fi-Q0803|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Menik%C3%B6%20h%C3%A4n%20Hangzhouhun%20is%C3%A4ns%C3%A4%20kanssa%3F)
^fi-Q0803-answer

**fi-Q0804** — Menikö hän Hangzhouhun isänsä kanssa?

Did he go to Hangzhou with his dad?

Many postpositions follow a noun in a governed case, frequently genitive. Some corresponding prepositions take another case. Learn a relation word with its complement pattern.

Why: Postpositions. [[Finnish#^fi-Q0804|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Menik%C3%B6%20h%C3%A4n%20Hangzhouhun%20is%C3%A4ns%C3%A4%20kanssa%3F)
^fi-Q0804-answer

**fi-Q0805** — Ajattelin, että saattaisit olla yksinäinen, joten tulin kylään viinipullon kanssa.

I thought you might be lonely, so I came over with a bottle of wine.

Expected form: **kanssa**

Why: Postpositions. [[Finnish#^fi-Q0805|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Ajattelin%2C%20ett%C3%A4%20saattaisit%20olla%20yksin%C3%A4inen%2C%20joten%20tulin%20kyl%C3%A4%C3%A4n%20viinipullon%20kanssa.)
^fi-Q0805-answer

**fi-Q0806** — Ajattelin, että saattaisit olla yksinäinen, joten tulin kylään viinipullon kanssa.

I thought you might be lonely, so I came over with a bottle of wine.

Expected form: **kanssa**

Why: Postpositions. [[Finnish#^fi-Q0806|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Ajattelin%2C%20ett%C3%A4%20saattaisit%20olla%20yksin%C3%A4inen%2C%20joten%20tulin%20kyl%C3%A4%C3%A4n%20viinipullon%20kanssa.)
^fi-Q0806-answer

**fi-Q0807** — Ostin lähikaupasta mäyräkoiran ja menin sen kanssa puistoon viettämään iltaa.

I bought a twelve-pack of beer, and went to the park to spend the night with it.

Expected form: **kanssa**

Why: Postpositions. [[Finnish#^fi-Q0807|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Ostin%20l%C3%A4hikaupasta%20m%C3%A4yr%C3%A4koiran%20ja%20menin%20sen%20kanssa%20puistoon%20viett%C3%A4m%C3%A4%C3%A4n%20iltaa.)
^fi-Q0807-answer

**fi-Q0808** — Ostin lähikaupasta mäyräkoiran ja menin sen kanssa puistoon viettämään iltaa.

I bought a twelve-pack of beer, and went to the park to spend the night with it.

Why: Postpositions. [[Finnish#^fi-Q0808|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Ostin%20l%C3%A4hikaupasta%20m%C3%A4yr%C3%A4koiran%20ja%20menin%20sen%20kanssa%20puistoon%20viett%C3%A4m%C3%A4%C3%A4n%20iltaa.)
^fi-Q0808-answer

**fi-Q0809** — En voinut mennä ulos huonon ilman johdosta.

I couldn't go out on account of the bad weather.

Why: Postpositions. [[Finnish#^fi-Q0809|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=En%20voinut%20menn%C3%A4%20ulos%20huonon%20ilman%20johdosta.)
^fi-Q0809-answer

**fi-Q0810** — En voinut mennä ulos huonon ilman johdosta.

I couldn't go out on account of the bad weather.

Many postpositions follow a noun in a governed case, frequently genitive. Some corresponding prepositions take another case. Learn a relation word with its complement pattern.

Why: Postpositions. [[Finnish#^fi-Q0810|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=En%20voinut%20menn%C3%A4%20ulos%20huonon%20ilman%20johdosta.)
^fi-Q0810-answer

**fi-Q0811** — Tomi menee aina nukkumaan ennen puoltayötä.

Tom always go to bed before midnight.

Expected form: **ennen**

Why: Postpositions. [[Finnish#^fi-Q0811|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tomi%20menee%20aina%20nukkumaan%20ennen%20puoltay%C3%B6t%C3%A4.)
^fi-Q0811-answer

**fi-Q0812** — Tomi menee aina nukkumaan ennen puoltayötä.

Tom always go to bed before midnight.

Expected form: **ennen**

Why: Postpositions. [[Finnish#^fi-Q0812|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tomi%20menee%20aina%20nukkumaan%20ennen%20puoltay%C3%B6t%C3%A4.)
^fi-Q0812-answer

**fi-Q0813** — Voiko ilman yhtäkään petosta menestyä?

Is it possible to succeed without any act of betrayal?

Expected form: **ilman**

Why: Postpositions. [[Finnish#^fi-Q0813|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Voiko%20ilman%20yht%C3%A4k%C3%A4%C3%A4n%20petosta%20menesty%C3%A4%3F)
^fi-Q0813-answer

**fi-Q0814** — Voiko ilman yhtäkään petosta menestyä?

Is it possible to succeed without any act of betrayal?

Why: Postpositions. [[Finnish#^fi-Q0814|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Voiko%20ilman%20yht%C3%A4k%C3%A4%C3%A4n%20petosta%20menesty%C3%A4%3F)
^fi-Q0814-answer

**fi-Q0815** — Yleensä syön ranskikset ketsupin kanssa.

I usually eat french fries with ketchup.

Why: Postpositions. [[Finnish#^fi-Q0815|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Yleens%C3%A4%20sy%C3%B6n%20ranskikset%20ketsupin%20kanssa.)
^fi-Q0815-answer

**fi-Q0816** — Yleensä syön ranskikset ketsupin kanssa.

I usually eat french fries with ketchup.

Many postpositions follow a noun in a governed case, frequently genitive. Some corresponding prepositions take another case. Learn a relation word with its complement pattern.

Why: Postpositions. [[Finnish#^fi-Q0816|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Yleens%C3%A4%20sy%C3%B6n%20ranskikset%20ketsupin%20kanssa.)
^fi-Q0816-answer

**fi-Q0817** — Voi olla, että Tomilla on jotain tekemistä asian kanssa.

Tom might have something to do with that.

Expected form: **kanssa**

Why: Postpositions. [[Finnish#^fi-Q0817|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Voi%20olla%2C%20ett%C3%A4%20Tomilla%20on%20jotain%20tekemist%C3%A4%20asian%20kanssa.)
^fi-Q0817-answer

**fi-Q0818** — Voi olla, että Tomilla on jotain tekemistä asian kanssa.

Tom might have something to do with that.

Expected form: **kanssa**

Why: Postpositions. [[Finnish#^fi-Q0818|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Voi%20olla%2C%20ett%C3%A4%20Tomilla%20on%20jotain%20tekemist%C3%A4%20asian%20kanssa.)
^fi-Q0818-answer

**fi-Q0819** — Etkö tykkää leikkiä mun kanssa?

Don't you like playing with me?

Expected form: **kanssa**

Why: Postpositions. [[Finnish#^fi-Q0819|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Etk%C3%B6%20tykk%C3%A4%C3%A4%20leikki%C3%A4%20mun%20kanssa%3F)
^fi-Q0819-answer

**fi-Q0820** — Etkö tykkää leikkiä mun kanssa?

Don't you like playing with me?

Why: Postpositions. [[Finnish#^fi-Q0820|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Etk%C3%B6%20tykk%C3%A4%C3%A4%20leikki%C3%A4%20mun%20kanssa%3F)
^fi-Q0820-answer

**fi-Q0821** — Tomilla ei ollut mitään tekemistä Maryn potkujen kanssa.

Tom had nothing to do with getting Mary fired.

Why: Postpositions. [[Finnish#^fi-Q0821|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tomilla%20ei%20ollut%20mit%C3%A4%C3%A4n%20tekemist%C3%A4%20Maryn%20potkujen%20kanssa.)
^fi-Q0821-answer

**fi-Q0822** — Tomilla ei ollut mitään tekemistä Maryn potkujen kanssa.

Tom had nothing to do with getting Mary fired.

Many postpositions follow a noun in a governed case, frequently genitive. Some corresponding prepositions take another case. Learn a relation word with its complement pattern.

Why: Postpositions. [[Finnish#^fi-Q0822|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tomilla%20ei%20ollut%20mit%C3%A4%C3%A4n%20tekemist%C3%A4%20Maryn%20potkujen%20kanssa.)
^fi-Q0822-answer

**fi-Q0823** — John haastoi baarissa riitaa vieressään olevien yliopisto-opiskelijoiden kanssa.

John picked a quarrel with college kids near him at the bar.

Expected form: **kanssa**

Why: Postpositions. [[Finnish#^fi-Q0823|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=John%20haastoi%20baarissa%20riitaa%20vieress%C3%A4%C3%A4n%20olevien%20yliopisto-opiskelijoiden%20kanssa.)
^fi-Q0823-answer

**fi-Q0824** — John haastoi baarissa riitaa vieressään olevien yliopisto-opiskelijoiden kanssa.

John picked a quarrel with college kids near him at the bar.

Expected form: **kanssa**

Why: Postpositions. [[Finnish#^fi-Q0824|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=John%20haastoi%20baarissa%20riitaa%20vieress%C3%A4%C3%A4n%20olevien%20yliopisto-opiskelijoiden%20kanssa.)
^fi-Q0824-answer

**fi-Q0825** — Etkö pääse sisään ilman jonottamista, koska tunnet poken?

Can't you get in without lining up because you know the bouncer?

Expected form: **ilman**

Why: Postpositions. [[Finnish#^fi-Q0825|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Etk%C3%B6%20p%C3%A4%C3%A4se%20sis%C3%A4%C3%A4n%20ilman%20jonottamista%2C%20koska%20tunnet%20poken%3F)
^fi-Q0825-answer

**fi-Q0826** — Etkö pääse sisään ilman jonottamista, koska tunnet poken?

Can't you get in without lining up because you know the bouncer?

Why: Postpositions. [[Finnish#^fi-Q0826|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Etk%C3%B6%20p%C3%A4%C3%A4se%20sis%C3%A4%C3%A4n%20ilman%20jonottamista%2C%20koska%20tunnet%20poken%3F)
^fi-Q0826-answer

**fi-Q0827** — Pohjoinen osa siitä, mikä on nykyään Papua-Uusi-Guinea, oli ennen Saksan siirtokunta.

The northern half of what is today Papua New Guinea was a German colony.

Why: Postpositions. [[Finnish#^fi-Q0827|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Pohjoinen%20osa%20siit%C3%A4%2C%20mik%C3%A4%20on%20nyky%C3%A4%C3%A4n%20Papua-Uusi-Guinea%2C%20oli%20ennen%20Saksan%20siirtokunta.)
^fi-Q0827-answer

**fi-Q0828** — Pohjoinen osa siitä, mikä on nykyään Papua-Uusi-Guinea, oli ennen Saksan siirtokunta.

The northern half of what is today Papua New Guinea was a German colony.

Many postpositions follow a noun in a governed case, frequently genitive. Some corresponding prepositions take another case. Learn a relation word with its complement pattern.

Why: Postpositions. [[Finnish#^fi-Q0828|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Pohjoinen%20osa%20siit%C3%A4%2C%20mik%C3%A4%20on%20nyky%C3%A4%C3%A4n%20Papua-Uusi-Guinea%2C%20oli%20ennen%20Saksan%20siirtokunta.)
^fi-Q0828-answer

**fi-Q0829** — Tomin ranskasta tuli melko sujuvaa kolmen vuoden intensiivisen opiskelun jälkeen.

Tom became fairly fluent in French after about three years of intense study.

Expected form: **jälkeen**

Why: Postpositions. [[Finnish#^fi-Q0829|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tomin%20ranskasta%20tuli%20melko%20sujuvaa%20kolmen%20vuoden%20intensiivisen%20opiskelun%20j%C3%A4lkeen.)
^fi-Q0829-answer

**fi-Q0830** — Tomin ranskasta tuli melko sujuvaa kolmen vuoden intensiivisen opiskelun jälkeen.

Tom became fairly fluent in French after about three years of intense study.

Expected form: **jälkeen**

Why: Postpositions. [[Finnish#^fi-Q0830|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tomin%20ranskasta%20tuli%20melko%20sujuvaa%20kolmen%20vuoden%20intensiivisen%20opiskelun%20j%C3%A4lkeen.)
^fi-Q0830-answer

**fi-Q0831** — Tomi kävelee kävelykepin kanssa.

Tom walks with a cane.

Expected form: **kanssa**

Why: Postpositions. [[Finnish#^fi-Q0831|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tomi%20k%C3%A4velee%20k%C3%A4velykepin%20kanssa.)
^fi-Q0831-answer

**fi-Q0832** — Tomi kävelee kävelykepin kanssa.

Tom walks with a cane.

Why: Postpositions. [[Finnish#^fi-Q0832|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tomi%20k%C3%A4velee%20k%C3%A4velykepin%20kanssa.)
^fi-Q0832-answer

**fi-Q0833** — Aloin seurustella Tomin kanssa.

I started dating Tom.

Why: Postpositions. [[Finnish#^fi-Q0833|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Aloin%20seurustella%20Tomin%20kanssa.)
^fi-Q0833-answer

**fi-Q0834** — Aloin seurustella Tomin kanssa.

I started dating Tom.

Many postpositions follow a noun in a governed case, frequently genitive. Some corresponding prepositions take another case. Learn a relation word with its complement pattern.

Why: Postpositions. [[Finnish#^fi-Q0834|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Aloin%20seurustella%20Tomin%20kanssa.)
^fi-Q0834-answer

**fi-Q0835** — Tom ystävystyi kaikkien kanssa.

Tom made friends with everybody.

Expected form: **kanssa**

Why: Postpositions. [[Finnish#^fi-Q0835|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tom%20yst%C3%A4vystyi%20kaikkien%20kanssa.)
^fi-Q0835-answer

**fi-Q0836** — Tom ystävystyi kaikkien kanssa.

Tom made friends with everybody.

Expected form: **kanssa**

Why: Postpositions. [[Finnish#^fi-Q0836|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tom%20yst%C3%A4vystyi%20kaikkien%20kanssa.)
^fi-Q0836-answer

**fi-Q0837** — En ollut ehtinyt pitkälle ennen kuin tapasin hänet.

I had not gone far before I met him.

Expected form: **ennen**

Why: Postpositions. [[Finnish#^fi-Q0837|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=En%20ollut%20ehtinyt%20pitk%C3%A4lle%20ennen%20kuin%20tapasin%20h%C3%A4net.)
^fi-Q0837-answer

**fi-Q0838** — En ollut ehtinyt pitkälle ennen kuin tapasin hänet.

I had not gone far before I met him.

Why: Postpositions. [[Finnish#^fi-Q0838|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=En%20ollut%20ehtinyt%20pitk%C3%A4lle%20ennen%20kuin%20tapasin%20h%C3%A4net.)
^fi-Q0838-answer

**fi-Q0839** — Hän asuu äitinsä kanssa.

He lives with his mom.

Why: Postpositions. [[Finnish#^fi-Q0839|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=H%C3%A4n%20asuu%20%C3%A4itins%C3%A4%20kanssa.)
^fi-Q0839-answer

**fi-Q0840** — Hän asuu äitinsä kanssa.

He lives with his mom.

Many postpositions follow a noun in a governed case, frequently genitive. Some corresponding prepositions take another case. Learn a relation word with its complement pattern.

Why: Postpositions. [[Finnish#^fi-Q0840|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=H%C3%A4n%20asuu%20%C3%A4itins%C3%A4%20kanssa.)
^fi-Q0840-answer

**fi-Q0841** — Kenen kanssa sinä asut?

Who do you live with?

Expected form: **kanssa**

Why: Postpositions. [[Finnish#^fi-Q0841|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Kenen%20kanssa%20sin%C3%A4%20asut%3F)
^fi-Q0841-answer

**fi-Q0842** — Kenen kanssa sinä asut?

Who do you live with?

Expected form: **kanssa**

Why: Postpositions. [[Finnish#^fi-Q0842|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Kenen%20kanssa%20sin%C3%A4%20asut%3F)
^fi-Q0842-answer

**fi-Q0843** — Hän oli sängyssä hänen pomonsa kanssa.

She slept with her boss.

Expected form: **kanssa**

Why: Postpositions. [[Finnish#^fi-Q0843|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=H%C3%A4n%20oli%20s%C3%A4ngyss%C3%A4%20h%C3%A4nen%20pomonsa%20kanssa.)
^fi-Q0843-answer

**fi-Q0844** — Hän oli sängyssä hänen pomonsa kanssa.

She slept with her boss.

Why: Postpositions. [[Finnish#^fi-Q0844|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=H%C3%A4n%20oli%20s%C3%A4ngyss%C3%A4%20h%C3%A4nen%20pomonsa%20kanssa.)
^fi-Q0844-answer

**fi-Q0845** — Varmista keittiömestarin kyvykkyys ennen kuin tilaat pallokalaa.

Make sure the chef is skilled before ordering fugu.

Why: Postpositions. [[Finnish#^fi-Q0845|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Varmista%20keitti%C3%B6mestarin%20kyvykkyys%20ennen%20kuin%20tilaat%20pallokalaa.)
^fi-Q0845-answer

**fi-Q0846** — Varmista keittiömestarin kyvykkyys ennen kuin tilaat pallokalaa.

Make sure the chef is skilled before ordering fugu.

Many postpositions follow a noun in a governed case, frequently genitive. Some corresponding prepositions take another case. Learn a relation word with its complement pattern.

Why: Postpositions. [[Finnish#^fi-Q0846|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Varmista%20keitti%C3%B6mestarin%20kyvykkyys%20ennen%20kuin%20tilaat%20pallokalaa.)
^fi-Q0846-answer

**fi-Q0847** — Menin veljeni kanssa elokuviin.

I went to the movies with my brother.

Expected form: **kanssa**

Why: Postpositions. [[Finnish#^fi-Q0847|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Menin%20veljeni%20kanssa%20elokuviin.)
^fi-Q0847-answer

**fi-Q0848** — Menin veljeni kanssa elokuviin.

I went to the movies with my brother.

Expected form: **kanssa**

Why: Postpositions. [[Finnish#^fi-Q0848|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Menin%20veljeni%20kanssa%20elokuviin.)
^fi-Q0848-answer

**fi-Q0849** — Minulla ei ole minkäänlaista ongelmaa sen kanssa.

I have absolutely no problem with that.

Expected form: **kanssa**

Why: Postpositions. [[Finnish#^fi-Q0849|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Minulla%20ei%20ole%20mink%C3%A4%C3%A4nlaista%20ongelmaa%20sen%20kanssa.)
^fi-Q0849-answer

**fi-Q0850** — Minulla ei ole minkäänlaista ongelmaa sen kanssa.

I have absolutely no problem with that.

Why: Postpositions. [[Finnish#^fi-Q0850|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Minulla%20ei%20ole%20mink%C3%A4%C3%A4nlaista%20ongelmaa%20sen%20kanssa.)
^fi-Q0850-answer


### Answers 851–900

**fi-Q0851** — Tom teki neljä maalia.

Tom scored four goals.

Why: Quantity and numerals. [[Finnish#^fi-Q0851|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tom%20teki%20nelj%C3%A4%20maalia.)
^fi-Q0851-answer

**fi-Q0852** — Tom teki neljä maalia.

Tom scored four goals.

Many cardinal quantities greater than one take singular partitive of the counted noun. Paljon/vähän interact with countability and case. Do not simply put a plural nominative after every number.

Why: Quantity and numerals. [[Finnish#^fi-Q0852|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tom%20teki%20nelj%C3%A4%20maalia.)
^fi-Q0852-answer

**fi-Q0853** — Tom osaa puhua vain vähän ranskaa.

Tom can speak only a little French.

Expected form: **vähän**

Why: Quantity and numerals. [[Finnish#^fi-Q0853|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tom%20osaa%20puhua%20vain%20v%C3%A4h%C3%A4n%20ranskaa.)
^fi-Q0853-answer

**fi-Q0854** — Tom osaa puhua vain vähän ranskaa.

Tom can speak only a little French.

Expected form: **vähän**

Why: Quantity and numerals. [[Finnish#^fi-Q0854|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tom%20osaa%20puhua%20vain%20v%C3%A4h%C3%A4n%20ranskaa.)
^fi-Q0854-answer

**fi-Q0855** — Tiedän kuinka paljon arvostat yksityisyyttäsi.

I know how much you value your privacy.

Expected form: **paljon**

Why: Quantity and numerals. [[Finnish#^fi-Q0855|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tied%C3%A4n%20kuinka%20paljon%20arvostat%20yksityisyytt%C3%A4si.)
^fi-Q0855-answer

**fi-Q0856** — Tiedän kuinka paljon arvostat yksityisyyttäsi.

I know how much you value your privacy.

Why: Quantity and numerals. [[Finnish#^fi-Q0856|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tied%C3%A4n%20kuinka%20paljon%20arvostat%20yksityisyytt%C3%A4si.)
^fi-Q0856-answer

**fi-Q0857** — En usko, että voimme salata skandaalia enää paljon pidempään; ihmiset saavat selville.

I don't think we can keep the lid on the scandal much longer; people are bound to find out.

Why: Quantity and numerals. [[Finnish#^fi-Q0857|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=En%20usko%2C%20ett%C3%A4%20voimme%20salata%20skandaalia%20en%C3%A4%C3%A4%20paljon%20pidemp%C3%A4%C3%A4n%3B%20ihmiset%20saavat%20selville.)
^fi-Q0857-answer

**fi-Q0858** — En usko, että voimme salata skandaalia enää paljon pidempään; ihmiset saavat selville.

I don't think we can keep the lid on the scandal much longer; people are bound to find out.

Many cardinal quantities greater than one take singular partitive of the counted noun. Paljon/vähän interact with countability and case. Do not simply put a plural nominative after every number.

Why: Quantity and numerals. [[Finnish#^fi-Q0858|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=En%20usko%2C%20ett%C3%A4%20voimme%20salata%20skandaalia%20en%C3%A4%C3%A4%20paljon%20pidemp%C3%A4%C3%A4n%3B%20ihmiset%20saavat%20selville.)
^fi-Q0858-answer

**fi-Q0859** — Tom tietää paljon asioita Marista.

Tom knows quite a lot about Mary.

Expected form: **paljon**

Why: Quantity and numerals. [[Finnish#^fi-Q0859|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tom%20tiet%C3%A4%C3%A4%20paljon%20asioita%20Marista.)
^fi-Q0859-answer

**fi-Q0860** — Tom tietää paljon asioita Marista.

Tom knows quite a lot about Mary.

Expected form: **paljon**

Why: Quantity and numerals. [[Finnish#^fi-Q0860|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tom%20tiet%C3%A4%C3%A4%20paljon%20asioita%20Marista.)
^fi-Q0860-answer

**fi-Q0861** — Mitä enemmän syöt, sitä vähemmän meidän tarvitsee tuoda takaisin. Joten syö niin paljon kuin haluat!

The more food you eat, the less we have to bring back. So eat as much as you want!

Expected form: **paljon**

Why: Quantity and numerals. [[Finnish#^fi-Q0861|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Mit%C3%A4%20enemm%C3%A4n%20sy%C3%B6t%2C%20sit%C3%A4%20v%C3%A4hemm%C3%A4n%20meid%C3%A4n%20tarvitsee%20tuoda%20takaisin.%20Joten%20sy%C3%B6%20niin%20paljon%20kuin%20haluat%21)
^fi-Q0861-answer

**fi-Q0862** — Mitä enemmän syöt, sitä vähemmän meidän tarvitsee tuoda takaisin. Joten syö niin paljon kuin haluat!

The more food you eat, the less we have to bring back. So eat as much as you want!

Why: Quantity and numerals. [[Finnish#^fi-Q0862|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Mit%C3%A4%20enemm%C3%A4n%20sy%C3%B6t%2C%20sit%C3%A4%20v%C3%A4hemm%C3%A4n%20meid%C3%A4n%20tarvitsee%20tuoda%20takaisin.%20Joten%20sy%C3%B6%20niin%20paljon%20kuin%20haluat%21)
^fi-Q0862-answer

**fi-Q0863** — Tomin matka kesti kolme kuukautta.

Tom's trip lasted three months.

Why: Quantity and numerals. [[Finnish#^fi-Q0863|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tomin%20matka%20kesti%20kolme%20kuukautta.)
^fi-Q0863-answer

**fi-Q0864** — Tomin matka kesti kolme kuukautta.

Tom's trip lasted three months.

Many cardinal quantities greater than one take singular partitive of the counted noun. Paljon/vähän interact with countability and case. Do not simply put a plural nominative after every number.

Why: Quantity and numerals. [[Finnish#^fi-Q0864|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tomin%20matka%20kesti%20kolme%20kuukautta.)
^fi-Q0864-answer

**fi-Q0865** — Suomalaisista on monta stereotypiaa, mutta stereotyypit ovat usein liioitteluja tai yleistyksiä

There are many stereotypes about Finnish people, but stereotypes are often exaggerations or generalizations.

Expected form: **monta**

Why: Quantity and numerals. [[Finnish#^fi-Q0865|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Suomalaisista%20on%20monta%20stereotypiaa%2C%20mutta%20stereotyypit%20ovat%20usein%20liioitteluja%20tai%20yleistyksi%C3%A4)
^fi-Q0865-answer

**fi-Q0866** — Suomalaisista on monta stereotypiaa, mutta stereotyypit ovat usein liioitteluja tai yleistyksiä

There are many stereotypes about Finnish people, but stereotypes are often exaggerations or generalizations.

Expected form: **monta**

Why: Quantity and numerals. [[Finnish#^fi-Q0866|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Suomalaisista%20on%20monta%20stereotypiaa%2C%20mutta%20stereotyypit%20ovat%20usein%20liioitteluja%20tai%20yleistyksi%C3%A4)
^fi-Q0866-answer

**fi-Q0867** — Odotin kolme tuntia.

I waited three hours.

Expected form: **kolme**

Why: Quantity and numerals. [[Finnish#^fi-Q0867|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Odotin%20kolme%20tuntia.)
^fi-Q0867-answer

**fi-Q0868** — Odotin kolme tuntia.

I waited three hours.

Why: Quantity and numerals. [[Finnish#^fi-Q0868|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Odotin%20kolme%20tuntia.)
^fi-Q0868-answer

**fi-Q0869** — Renkaassa on liian vähän ilmaa.

The tyre is a little under-inflated.

Why: Quantity and numerals. [[Finnish#^fi-Q0869|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Renkaassa%20on%20liian%20v%C3%A4h%C3%A4n%20ilmaa.)
^fi-Q0869-answer

**fi-Q0870** — Renkaassa on liian vähän ilmaa.

The tyre is a little under-inflated.

Many cardinal quantities greater than one take singular partitive of the counted noun. Paljon/vähän interact with countability and case. Do not simply put a plural nominative after every number.

Why: Quantity and numerals. [[Finnish#^fi-Q0870|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Renkaassa%20on%20liian%20v%C3%A4h%C3%A4n%20ilmaa.)
^fi-Q0870-answer

**fi-Q0871** — Tomilla on paljon mahtavia ideoita.

Tom has a lot of great ideas.

Expected form: **paljon**

Why: Quantity and numerals. [[Finnish#^fi-Q0871|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tomilla%20on%20paljon%20mahtavia%20ideoita.)
^fi-Q0871-answer

**fi-Q0872** — Tomilla on paljon mahtavia ideoita.

Tom has a lot of great ideas.

Expected form: **paljon**

Why: Quantity and numerals. [[Finnish#^fi-Q0872|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tomilla%20on%20paljon%20mahtavia%20ideoita.)
^fi-Q0872-answer

**fi-Q0873** — Tavallisesti syömme kolme kertaa päivässä.

Normally, we eat three times a day.

Expected form: **kolme**

Why: Quantity and numerals. [[Finnish#^fi-Q0873|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tavallisesti%20sy%C3%B6mme%20kolme%20kertaa%20p%C3%A4iv%C3%A4ss%C3%A4.)
^fi-Q0873-answer

**fi-Q0874** — Tavallisesti syömme kolme kertaa päivässä.

Normally, we eat three times a day.

Why: Quantity and numerals. [[Finnish#^fi-Q0874|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tavallisesti%20sy%C3%B6mme%20kolme%20kertaa%20p%C3%A4iv%C3%A4ss%C3%A4.)
^fi-Q0874-answer

**fi-Q0875** — Tomilla on kolme isosiskoa.

Tom has three older sisters.

Why: Quantity and numerals. [[Finnish#^fi-Q0875|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tomilla%20on%20kolme%20isosiskoa.)
^fi-Q0875-answer

**fi-Q0876** — Tomilla on kolme isosiskoa.

Tom has three older sisters.

Many cardinal quantities greater than one take singular partitive of the counted noun. Paljon/vähän interact with countability and case. Do not simply put a plural nominative after every number.

Why: Quantity and numerals. [[Finnish#^fi-Q0876|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tomilla%20on%20kolme%20isosiskoa.)
^fi-Q0876-answer

**fi-Q0877** — Hän on paljon älykkäämpi kuin minä.

He is much smarter than I am.

Expected form: **paljon**

Why: Quantity and numerals. [[Finnish#^fi-Q0877|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=H%C3%A4n%20on%20paljon%20%C3%A4lykk%C3%A4%C3%A4mpi%20kuin%20min%C3%A4.)
^fi-Q0877-answer

**fi-Q0878** — Hän on paljon älykkäämpi kuin minä.

He is much smarter than I am.

Expected form: **paljon**

Why: Quantity and numerals. [[Finnish#^fi-Q0878|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=H%C3%A4n%20on%20paljon%20%C3%A4lykk%C3%A4%C3%A4mpi%20kuin%20min%C3%A4.)
^fi-Q0878-answer

**fi-Q0879** — Viime aikoina minulla on ollut vähän huono ruokahalu.

Recently, I don't have much appetite.

Expected form: **vähän**

Why: Quantity and numerals. [[Finnish#^fi-Q0879|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Viime%20aikoina%20minulla%20on%20ollut%20v%C3%A4h%C3%A4n%20huono%20ruokahalu.)
^fi-Q0879-answer

**fi-Q0880** — Viime aikoina minulla on ollut vähän huono ruokahalu.

Recently, I don't have much appetite.

Why: Quantity and numerals. [[Finnish#^fi-Q0880|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Viime%20aikoina%20minulla%20on%20ollut%20v%C3%A4h%C3%A4n%20huono%20ruokahalu.)
^fi-Q0880-answer

**fi-Q0881** — On tapana sekoittaa ratkaisun ehdottaminen ja ongelman varsinainen ratkaiseminen. Mielestäni on tärkeää erottaa nämä kaksi.

There's a tendency to conflate proposing a solution with actually solving the problem. I think it's important to differentiate between the two.

Why: Quantity and numerals. [[Finnish#^fi-Q0881|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=On%20tapana%20sekoittaa%20ratkaisun%20ehdottaminen%20ja%20ongelman%20varsinainen%20ratkaiseminen.%20Mielest%C3%A4ni%20on%20t%C3%A4rke%C3%A4%C3%A4%20erottaa%20n%C3%A4m%C3%A4%20kaksi.)
^fi-Q0881-answer

**fi-Q0882** — On tapana sekoittaa ratkaisun ehdottaminen ja ongelman varsinainen ratkaiseminen. Mielestäni on tärkeää erottaa nämä kaksi.

There's a tendency to conflate proposing a solution with actually solving the problem. I think it's important to differentiate between the two.

Many cardinal quantities greater than one take singular partitive of the counted noun. Paljon/vähän interact with countability and case. Do not simply put a plural nominative after every number.

Why: Quantity and numerals. [[Finnish#^fi-Q0882|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=On%20tapana%20sekoittaa%20ratkaisun%20ehdottaminen%20ja%20ongelman%20varsinainen%20ratkaiseminen.%20Mielest%C3%A4ni%20on%20t%C3%A4rke%C3%A4%C3%A4%20erottaa%20n%C3%A4m%C3%A4%20kaksi.)
^fi-Q0882-answer

**fi-Q0883** — Tahtoisin vähän lisää voita.

I'd like some more butter.

Expected form: **vähän**

Why: Quantity and numerals. [[Finnish#^fi-Q0883|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tahtoisin%20v%C3%A4h%C3%A4n%20lis%C3%A4%C3%A4%20voita.)
^fi-Q0883-answer

**fi-Q0884** — Tahtoisin vähän lisää voita.

I'd like some more butter.

Expected form: **vähän**

Why: Quantity and numerals. [[Finnish#^fi-Q0884|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tahtoisin%20v%C3%A4h%C3%A4n%20lis%C3%A4%C3%A4%20voita.)
^fi-Q0884-answer

**fi-Q0885** — Oletteko te kaksi menossa yhdessä ulos?

Are you two going out together?

Expected form: **kaksi**

Why: Quantity and numerals. [[Finnish#^fi-Q0885|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Oletteko%20te%20kaksi%20menossa%20yhdess%C3%A4%20ulos%3F)
^fi-Q0885-answer

**fi-Q0886** — Oletteko te kaksi menossa yhdessä ulos?

Are you two going out together?

Why: Quantity and numerals. [[Finnish#^fi-Q0886|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Oletteko%20te%20kaksi%20menossa%20yhdess%C3%A4%20ulos%3F)
^fi-Q0886-answer

**fi-Q0887** — Tarvitsen vähän apua.

I need a little help.

Why: Quantity and numerals. [[Finnish#^fi-Q0887|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tarvitsen%20v%C3%A4h%C3%A4n%20apua.)
^fi-Q0887-answer

**fi-Q0888** — Tarvitsen vähän apua.

I need a little help.

Many cardinal quantities greater than one take singular partitive of the counted noun. Paljon/vähän interact with countability and case. Do not simply put a plural nominative after every number.

Why: Quantity and numerals. [[Finnish#^fi-Q0888|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tarvitsen%20v%C3%A4h%C3%A4n%20apua.)
^fi-Q0888-answer

**fi-Q0889** — Teillä on paljon kirjoja.

You have a lot of books.

Expected form: **paljon**

Why: Quantity and numerals. [[Finnish#^fi-Q0889|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Teill%C3%A4%20on%20paljon%20kirjoja.)
^fi-Q0889-answer

**fi-Q0890** — Teillä on paljon kirjoja.

You have a lot of books.

Expected form: **paljon**

Why: Quantity and numerals. [[Finnish#^fi-Q0890|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Teill%C3%A4%20on%20paljon%20kirjoja.)
^fi-Q0890-answer

**fi-Q0891** — He olivat vähän hämmentyneitä.

They were a bit embarrassed.

Expected form: **vähän**

Why: Quantity and numerals. [[Finnish#^fi-Q0891|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=He%20olivat%20v%C3%A4h%C3%A4n%20h%C3%A4mmentyneit%C3%A4.)
^fi-Q0891-answer

**fi-Q0892** — He olivat vähän hämmentyneitä.

They were a bit embarrassed.

Why: Quantity and numerals. [[Finnish#^fi-Q0892|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=He%20olivat%20v%C3%A4h%C3%A4n%20h%C3%A4mmentyneit%C3%A4.)
^fi-Q0892-answer

**fi-Q0893** — Sillä kissalla on kaksi korvaa.

The cat has two ears.

Why: Quantity and numerals. [[Finnish#^fi-Q0893|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Sill%C3%A4%20kissalla%20on%20kaksi%20korvaa.)
^fi-Q0893-answer

**fi-Q0894** — Sillä kissalla on kaksi korvaa.

The cat has two ears.

Many cardinal quantities greater than one take singular partitive of the counted noun. Paljon/vähän interact with countability and case. Do not simply put a plural nominative after every number.

Why: Quantity and numerals. [[Finnish#^fi-Q0894|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Sill%C3%A4%20kissalla%20on%20kaksi%20korvaa.)
^fi-Q0894-answer

**fi-Q0895** — Voimmeko siirtää aikarajaa kaksi viikkoa myöhemmäksi?

Can we extend the deadline by two weeks?

Expected form: **kaksi**

Why: Quantity and numerals. [[Finnish#^fi-Q0895|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Voimmeko%20siirt%C3%A4%C3%A4%20aikarajaa%20kaksi%20viikkoa%20my%C3%B6hemm%C3%A4ksi%3F)
^fi-Q0895-answer

**fi-Q0896** — Voimmeko siirtää aikarajaa kaksi viikkoa myöhemmäksi?

Can we extend the deadline by two weeks?

Expected form: **kaksi**

Why: Quantity and numerals. [[Finnish#^fi-Q0896|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Voimmeko%20siirt%C3%A4%C3%A4%20aikarajaa%20kaksi%20viikkoa%20my%C3%B6hemm%C3%A4ksi%3F)
^fi-Q0896-answer

**fi-Q0897** — Sinä osaat uida paljon paremmin kuin hän.

You can swim much better than him.

Expected form: **paljon**

Why: Quantity and numerals. [[Finnish#^fi-Q0897|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Sin%C3%A4%20osaat%20uida%20paljon%20paremmin%20kuin%20h%C3%A4n.)
^fi-Q0897-answer

**fi-Q0898** — Sinä osaat uida paljon paremmin kuin hän.

You can swim much better than him.

Why: Quantity and numerals. [[Finnish#^fi-Q0898|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Sin%C3%A4%20osaat%20uida%20paljon%20paremmin%20kuin%20h%C3%A4n.)
^fi-Q0898-answer

**fi-Q0899** — Tomi on joutunut vankilaan kolme kertaa.

Tom has been in jail three times.

Why: Quantity and numerals. [[Finnish#^fi-Q0899|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tomi%20on%20joutunut%20vankilaan%20kolme%20kertaa.)
^fi-Q0899-answer

**fi-Q0900** — Tomi on joutunut vankilaan kolme kertaa.

Tom has been in jail three times.

Many cardinal quantities greater than one take singular partitive of the counted noun. Paljon/vähän interact with countability and case. Do not simply put a plural nominative after every number.

Why: Quantity and numerals. [[Finnish#^fi-Q0900|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tomi%20on%20joutunut%20vankilaan%20kolme%20kertaa.)
^fi-Q0900-answer


### Answers 901–950

**fi-Q0901** — Hän meni Kiinaan sotilaana eikä koskaan tullut takaisin.

He went to China as a soldier, never to come back.

Expected form: **tullut**

Why: Perfect participles. [[Finnish#^fi-Q0901|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=H%C3%A4n%20meni%20Kiinaan%20sotilaana%20eik%C3%A4%20koskaan%20tullut%20takaisin.)
^fi-Q0901-answer

**fi-Q0902** — Hän meni Kiinaan sotilaana eikä koskaan tullut takaisin.

He went to China as a soldier, never to come back.

Expected form: **tullut**

Why: Perfect participles. [[Finnish#^fi-Q0902|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=H%C3%A4n%20meni%20Kiinaan%20sotilaana%20eik%C3%A4%20koskaan%20tullut%20takaisin.)
^fi-Q0902-answer

**fi-Q0903** — Tomilla ei ollut paljonkaan valinnanvaraa.

Tom didn't have much of a choice.

Expected form: **ollut**

Why: Perfect participles. [[Finnish#^fi-Q0903|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tomilla%20ei%20ollut%20paljonkaan%20valinnanvaraa.)
^fi-Q0903-answer

**fi-Q0904** — Tomilla ei ollut paljonkaan valinnanvaraa.

Tom didn't have much of a choice.

Why: Perfect participles. [[Finnish#^fi-Q0904|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tomilla%20ei%20ollut%20paljonkaan%20valinnanvaraa.)
^fi-Q0904-answer

**fi-Q0905** — Tämä ei ollut halpa, eikö niin?

This wasn't cheap, was it?

Why: Perfect participles. [[Finnish#^fi-Q0905|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=T%C3%A4m%C3%A4%20ei%20ollut%20halpa%2C%20eik%C3%B6%20niin%3F)
^fi-Q0905-answer

**fi-Q0906** — Tämä ei ollut halpa, eikö niin?

This wasn't cheap, was it?

A perfect uses an olla form plus a past active participle, with number agreement in relevant forms. Negative past constructions also use a participle but differ in auxiliary pattern.

Why: Perfect participles. [[Finnish#^fi-Q0906|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=T%C3%A4m%C3%A4%20ei%20ollut%20halpa%2C%20eik%C3%B6%20niin%3F)
^fi-Q0906-answer

**fi-Q0907** — Olen tullut noutamaan sinut kotiin.

I've come to take you home.

Expected form: **tullut**

Why: Perfect participles. [[Finnish#^fi-Q0907|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Olen%20tullut%20noutamaan%20sinut%20kotiin.)
^fi-Q0907-answer

**fi-Q0908** — Olen tullut noutamaan sinut kotiin.

I've come to take you home.

Expected form: **tullut**

Why: Perfect participles. [[Finnish#^fi-Q0908|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Olen%20tullut%20noutamaan%20sinut%20kotiin.)
^fi-Q0908-answer

**fi-Q0909** — Tomilla ei ollut mitään syömistä.

Tom had nothing to eat.

Expected form: **ollut**

Why: Perfect participles. [[Finnish#^fi-Q0909|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tomilla%20ei%20ollut%20mit%C3%A4%C3%A4n%20sy%C3%B6mist%C3%A4.)
^fi-Q0909-answer

**fi-Q0910** — Tomilla ei ollut mitään syömistä.

Tom had nothing to eat.

Why: Perfect participles. [[Finnish#^fi-Q0910|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tomilla%20ei%20ollut%20mit%C3%A4%C3%A4n%20sy%C3%B6mist%C3%A4.)
^fi-Q0910-answer

**fi-Q0911** — Tom kysyi Marilta oliko hän nähnyt Jonia.

Tom asked Mary if she'd seen John.

Why: Perfect participles. [[Finnish#^fi-Q0911|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tom%20kysyi%20Marilta%20oliko%20h%C3%A4n%20n%C3%A4hnyt%20Jonia.)
^fi-Q0911-answer

**fi-Q0912** — Tom kysyi Marilta oliko hän nähnyt Jonia.

Tom asked Mary if she'd seen John.

A perfect uses an olla form plus a past active participle, with number agreement in relevant forms. Negative past constructions also use a participle but differ in auxiliary pattern.

Why: Perfect participles. [[Finnish#^fi-Q0912|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tom%20kysyi%20Marilta%20oliko%20h%C3%A4n%20n%C3%A4hnyt%20Jonia.)
^fi-Q0912-answer

**fi-Q0913** — En saanut yhtään nukuttua viime yönä.

I didn't get any sleep last night.

Expected form: **saanut**

Why: Perfect participles. [[Finnish#^fi-Q0913|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=En%20saanut%20yht%C3%A4%C3%A4n%20nukuttua%20viime%20y%C3%B6n%C3%A4.)
^fi-Q0913-answer

**fi-Q0914** — En saanut yhtään nukuttua viime yönä.

I didn't get any sleep last night.

Expected form: **saanut**

Why: Perfect participles. [[Finnish#^fi-Q0914|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=En%20saanut%20yht%C3%A4%C3%A4n%20nukuttua%20viime%20y%C3%B6n%C3%A4.)
^fi-Q0914-answer

**fi-Q0915** — Tomilla ei ollut aikomusta antaa periksi.

Tom had no intention of giving up.

Expected form: **ollut**

Why: Perfect participles. [[Finnish#^fi-Q0915|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tomilla%20ei%20ollut%20aikomusta%20antaa%20periksi.)
^fi-Q0915-answer

**fi-Q0916** — Tomilla ei ollut aikomusta antaa periksi.

Tom had no intention of giving up.

Why: Perfect participles. [[Finnish#^fi-Q0916|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tomilla%20ei%20ollut%20aikomusta%20antaa%20periksi.)
^fi-Q0916-answer

**fi-Q0917** — Viimein tajusin, että en ollut rakastunut sinuun.

I finally realized that I wasn't in love with you.

Why: Perfect participles. [[Finnish#^fi-Q0917|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Viimein%20tajusin%2C%20ett%C3%A4%20en%20ollut%20rakastunut%20sinuun.)
^fi-Q0917-answer

**fi-Q0918** — Viimein tajusin, että en ollut rakastunut sinuun.

I finally realized that I wasn't in love with you.

A perfect uses an olla form plus a past active participle, with number agreement in relevant forms. Negative past constructions also use a participle but differ in auxiliary pattern.

Why: Perfect participles. [[Finnish#^fi-Q0918|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Viimein%20tajusin%2C%20ett%C3%A4%20en%20ollut%20rakastunut%20sinuun.)
^fi-Q0918-answer

**fi-Q0919** — Lapsena minä en ollut ylipainoinen.

I wasn't overweight when I was a kid.

Expected form: **ollut**

Why: Perfect participles. [[Finnish#^fi-Q0919|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Lapsena%20min%C3%A4%20en%20ollut%20ylipainoinen.)
^fi-Q0919-answer

**fi-Q0920** — Lapsena minä en ollut ylipainoinen.

I wasn't overweight when I was a kid.

Expected form: **ollut**

Why: Perfect participles. [[Finnish#^fi-Q0920|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Lapsena%20min%C3%A4%20en%20ollut%20ylipainoinen.)
^fi-Q0920-answer

**fi-Q0921** — En ole lukenut vielä uutta muistiota sisäisestä turvallisuudesta.

I haven't yet read the new memorandum on internal security.

Expected form: **lukenut**

Why: Perfect participles. [[Finnish#^fi-Q0921|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=En%20ole%20lukenut%20viel%C3%A4%20uutta%20muistiota%20sis%C3%A4isest%C3%A4%20turvallisuudesta.)
^fi-Q0921-answer

**fi-Q0922** — En ole lukenut vielä uutta muistiota sisäisestä turvallisuudesta.

I haven't yet read the new memorandum on internal security.

Why: Perfect participles. [[Finnish#^fi-Q0922|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=En%20ole%20lukenut%20viel%C3%A4%20uutta%20muistiota%20sis%C3%A4isest%C3%A4%20turvallisuudesta.)
^fi-Q0922-answer

**fi-Q0923** — Täydellinen kuvaus hänestä on ollut levityksessä jokaisessa sanomalehdessä.

A full description of him has been circulated in every newspaper.

Why: Perfect participles. [[Finnish#^fi-Q0923|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=T%C3%A4ydellinen%20kuvaus%20h%C3%A4nest%C3%A4%20on%20ollut%20levityksess%C3%A4%20jokaisessa%20sanomalehdess%C3%A4.)
^fi-Q0923-answer

**fi-Q0924** — Täydellinen kuvaus hänestä on ollut levityksessä jokaisessa sanomalehdessä.

A full description of him has been circulated in every newspaper.

A perfect uses an olla form plus a past active participle, with number agreement in relevant forms. Negative past constructions also use a participle but differ in auxiliary pattern.

Why: Perfect participles. [[Finnish#^fi-Q0924|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=T%C3%A4ydellinen%20kuvaus%20h%C3%A4nest%C3%A4%20on%20ollut%20levityksess%C3%A4%20jokaisessa%20sanomalehdess%C3%A4.)
^fi-Q0924-answer

**fi-Q0925** — En muista, milloin viimeksi olen nähnyt Tomin niin onnellisena.

I can't remember the last time I saw Tom so happy.

Expected form: **nähnyt**

Why: Perfect participles. [[Finnish#^fi-Q0925|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=En%20muista%2C%20milloin%20viimeksi%20olen%20n%C3%A4hnyt%20Tomin%20niin%20onnellisena.)
^fi-Q0925-answer

**fi-Q0926** — En muista, milloin viimeksi olen nähnyt Tomin niin onnellisena.

I can't remember the last time I saw Tom so happy.

Expected form: **nähnyt**

Why: Perfect participles. [[Finnish#^fi-Q0926|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=En%20muista%2C%20milloin%20viimeksi%20olen%20n%C3%A4hnyt%20Tomin%20niin%20onnellisena.)
^fi-Q0926-answer

**fi-Q0927** — Tämä on kiinnostavin tarina, minkä olen koskaan lukenut.

This is the most interesting story that I have ever read.

Expected form: **lukenut**

Why: Perfect participles. [[Finnish#^fi-Q0927|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=T%C3%A4m%C3%A4%20on%20kiinnostavin%20tarina%2C%20mink%C3%A4%20olen%20koskaan%20lukenut.)
^fi-Q0927-answer

**fi-Q0928** — Tämä on kiinnostavin tarina, minkä olen koskaan lukenut.

This is the most interesting story that I have ever read.

Why: Perfect participles. [[Finnish#^fi-Q0928|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=T%C3%A4m%C3%A4%20on%20kiinnostavin%20tarina%2C%20mink%C3%A4%20olen%20koskaan%20lukenut.)
^fi-Q0928-answer

**fi-Q0929** — Tomi ei mennyt tänään töihin.

Tom didn't go to work today.

Why: Perfect participles. [[Finnish#^fi-Q0929|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tomi%20ei%20mennyt%20t%C3%A4n%C3%A4%C3%A4n%20t%C3%B6ihin.)
^fi-Q0929-answer

**fi-Q0930** — Tomi ei mennyt tänään töihin.

Tom didn't go to work today.

A perfect uses an olla form plus a past active participle, with number agreement in relevant forms. Negative past constructions also use a participle but differ in auxiliary pattern.

Why: Perfect participles. [[Finnish#^fi-Q0930|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tomi%20ei%20mennyt%20t%C3%A4n%C3%A4%C3%A4n%20t%C3%B6ihin.)
^fi-Q0930-answer

**fi-Q0931** — Ehkä Tom ei ollut saatavilla.

Maybe Tom wasn't available.

Expected form: **ollut**

Why: Perfect participles. [[Finnish#^fi-Q0931|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Ehk%C3%A4%20Tom%20ei%20ollut%20saatavilla.)
^fi-Q0931-answer

**fi-Q0932** — Ehkä Tom ei ollut saatavilla.

Maybe Tom wasn't available.

Expected form: **ollut**

Why: Perfect participles. [[Finnish#^fi-Q0932|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Ehk%C3%A4%20Tom%20ei%20ollut%20saatavilla.)
^fi-Q0932-answer

**fi-Q0933** — Se ei ollut tärkeää.

It wasn't important.

Expected form: **ollut**

Why: Perfect participles. [[Finnish#^fi-Q0933|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Se%20ei%20ollut%20t%C3%A4rke%C3%A4%C3%A4.)
^fi-Q0933-answer

**fi-Q0934** — Se ei ollut tärkeää.

It wasn't important.

Why: Perfect participles. [[Finnish#^fi-Q0934|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Se%20ei%20ollut%20t%C3%A4rke%C3%A4%C3%A4.)
^fi-Q0934-answer

**fi-Q0935** — En nähnyt yhtään mitään.

I didn't see a thing.

Why: Perfect participles. [[Finnish#^fi-Q0935|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=En%20n%C3%A4hnyt%20yht%C3%A4%C3%A4n%20mit%C3%A4%C3%A4n.)
^fi-Q0935-answer

**fi-Q0936** — En nähnyt yhtään mitään.

I didn't see a thing.

A perfect uses an olla form plus a past active participle, with number agreement in relevant forms. Negative past constructions also use a participle but differ in auxiliary pattern.

Why: Perfect participles. [[Finnish#^fi-Q0936|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=En%20n%C3%A4hnyt%20yht%C3%A4%C3%A4n%20mit%C3%A4%C3%A4n.)
^fi-Q0936-answer

**fi-Q0937** — En ole koskaan nähnyt matkoillani kauniimpaa vuorta kuin Everest.

In all my travels I've never seen a more beautiful mountain than Everest.

Expected form: **nähnyt**

Why: Perfect participles. [[Finnish#^fi-Q0937|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=En%20ole%20koskaan%20n%C3%A4hnyt%20matkoillani%20kauniimpaa%20vuorta%20kuin%20Everest.)
^fi-Q0937-answer

**fi-Q0938** — En ole koskaan nähnyt matkoillani kauniimpaa vuorta kuin Everest.

In all my travels I've never seen a more beautiful mountain than Everest.

Expected form: **nähnyt**

Why: Perfect participles. [[Finnish#^fi-Q0938|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=En%20ole%20koskaan%20n%C3%A4hnyt%20matkoillani%20kauniimpaa%20vuorta%20kuin%20Everest.)
^fi-Q0938-answer

**fi-Q0939** — Tom ei ollut varma selviääkö hän.

Tom wasn't sure if he was going to make it.

Expected form: **ollut**

Why: Perfect participles. [[Finnish#^fi-Q0939|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tom%20ei%20ollut%20varma%20selvi%C3%A4%C3%A4k%C3%B6%20h%C3%A4n.)
^fi-Q0939-answer

**fi-Q0940** — Tom ei ollut varma selviääkö hän.

Tom wasn't sure if he was going to make it.

Why: Perfect participles. [[Finnish#^fi-Q0940|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tom%20ei%20ollut%20varma%20selvi%C3%A4%C3%A4k%C3%B6%20h%C3%A4n.)
^fi-Q0940-answer

**fi-Q0941** — Moderni tiede on tehnyt monista mahdottomista asioista mahdollisia.

Modern science has turned many impossibilities into possibilities.

Why: Perfect participles. [[Finnish#^fi-Q0941|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Moderni%20tiede%20on%20tehnyt%20monista%20mahdottomista%20asioista%20mahdollisia.)
^fi-Q0941-answer

**fi-Q0942** — Moderni tiede on tehnyt monista mahdottomista asioista mahdollisia.

Modern science has turned many impossibilities into possibilities.

A perfect uses an olla form plus a past active participle, with number agreement in relevant forms. Negative past constructions also use a participle but differ in auxiliary pattern.

Why: Perfect participles. [[Finnish#^fi-Q0942|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Moderni%20tiede%20on%20tehnyt%20monista%20mahdottomista%20asioista%20mahdollisia.)
^fi-Q0942-answer

**fi-Q0943** — En ole koskaan ollut Argentiinassa.

I've never been to Argentina.

Expected form: **ollut**

Why: Perfect participles. [[Finnish#^fi-Q0943|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=En%20ole%20koskaan%20ollut%20Argentiinassa.)
^fi-Q0943-answer

**fi-Q0944** — En ole koskaan ollut Argentiinassa.

I've never been to Argentina.

Expected form: **ollut**

Why: Perfect participles. [[Finnish#^fi-Q0944|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=En%20ole%20koskaan%20ollut%20Argentiinassa.)
^fi-Q0944-answer

**fi-Q0945** — En saanut tilaisuutta esittäytyä tytölle.

I didn't get a chance to introduce myself to her.

Expected form: **saanut**

Why: Perfect participles. [[Finnish#^fi-Q0945|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=En%20saanut%20tilaisuutta%20esitt%C3%A4yty%C3%A4%20tyt%C3%B6lle.)
^fi-Q0945-answer

**fi-Q0946** — En saanut tilaisuutta esittäytyä tytölle.

I didn't get a chance to introduce myself to her.

Why: Perfect participles. [[Finnish#^fi-Q0946|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=En%20saanut%20tilaisuutta%20esitt%C3%A4yty%C3%A4%20tyt%C3%B6lle.)
^fi-Q0946-answer

**fi-Q0947** — Hän on ollut vuoteen omana jonkin aikaa.

She has been sick in bed for some time.

Why: Perfect participles. [[Finnish#^fi-Q0947|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=H%C3%A4n%20on%20ollut%20vuoteen%20omana%20jonkin%20aikaa.)
^fi-Q0947-answer

**fi-Q0948** — Hän on ollut vuoteen omana jonkin aikaa.

She has been sick in bed for some time.

A perfect uses an olla form plus a past active participle, with number agreement in relevant forms. Negative past constructions also use a participle but differ in auxiliary pattern.

Why: Perfect participles. [[Finnish#^fi-Q0948|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=H%C3%A4n%20on%20ollut%20vuoteen%20omana%20jonkin%20aikaa.)
^fi-Q0948-answer

**fi-Q0949** — Jätä mennyt taakse ja jatka eteenpäin.

Leave the past behind and go on.

Expected form: **mennyt**

Why: Perfect participles. [[Finnish#^fi-Q0949|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=J%C3%A4t%C3%A4%20mennyt%20taakse%20ja%20jatka%20eteenp%C3%A4in.)
^fi-Q0949-answer

**fi-Q0950** — Jätä mennyt taakse ja jatka eteenpäin.

Leave the past behind and go on.

Expected form: **mennyt**

Why: Perfect participles. [[Finnish#^fi-Q0950|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=J%C3%A4t%C3%A4%20mennyt%20taakse%20ja%20jatka%20eteenp%C3%A4in.)
^fi-Q0950-answer


### Answers 951–1000

**fi-Q0951** — Ehkä hän on italialainen tai espanjalainen.

Maybe he is Italian or Spanish.

Expected form: **Ehkä**

Why: Comparison and stance. [[Finnish#^fi-Q0951|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Ehk%C3%A4%20h%C3%A4n%20on%20italialainen%20tai%20espanjalainen.)
^fi-Q0951-answer

**fi-Q0952** — Ehkä hän on italialainen tai espanjalainen.

Maybe he is Italian or Spanish.

Why: Comparison and stance. [[Finnish#^fi-Q0952|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Ehk%C3%A4%20h%C3%A4n%20on%20italialainen%20tai%20espanjalainen.)
^fi-Q0952-answer

**fi-Q0953** — Minä pidän enemmän kesästä kuin talvesta.

I like summer better than winter.

Why: Comparison and stance. [[Finnish#^fi-Q0953|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Min%C3%A4%20pid%C3%A4n%20enemm%C3%A4n%20kes%C3%A4st%C3%A4%20kuin%20talvesta.)
^fi-Q0953-answer

**fi-Q0954** — Minä pidän enemmän kesästä kuin talvesta.

I like summer better than winter.

Parempi is adjectival better; paremmin adverbial better. Kuitenkin marks nevertheless and siksi a consequence. Ehkä limits certainty. Compare the form’s actual role before choosing an English gloss.

Why: Comparison and stance. [[Finnish#^fi-Q0954|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Min%C3%A4%20pid%C3%A4n%20enemm%C3%A4n%20kes%C3%A4st%C3%A4%20kuin%20talvesta.)
^fi-Q0954-answer

**fi-Q0955** — Tulisitko sinä myös mukaan?

Would you care to come with us?

Expected form: **myös**

Why: Comparison and stance. [[Finnish#^fi-Q0955|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tulisitko%20sin%C3%A4%20my%C3%B6s%20mukaan%3F)
^fi-Q0955-answer

**fi-Q0956** — Tulisitko sinä myös mukaan?

Would you care to come with us?

Expected form: **myös**

Why: Comparison and stance. [[Finnish#^fi-Q0956|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tulisitko%20sin%C3%A4%20my%C3%B6s%20mukaan%3F)
^fi-Q0956-answer

**fi-Q0957** — Tomi vaikutti enemmän yllättyneeltä kuin vihaiselta.

Tom seemed more surprised than angry.

Expected form: **enemmän**

Why: Comparison and stance. [[Finnish#^fi-Q0957|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tomi%20vaikutti%20enemm%C3%A4n%20yll%C3%A4ttyneelt%C3%A4%20kuin%20vihaiselta.)
^fi-Q0957-answer

**fi-Q0958** — Tomi vaikutti enemmän yllättyneeltä kuin vihaiselta.

Tom seemed more surprised than angry.

Why: Comparison and stance. [[Finnish#^fi-Q0958|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tomi%20vaikutti%20enemm%C3%A4n%20yll%C3%A4ttyneelt%C3%A4%20kuin%20vihaiselta.)
^fi-Q0958-answer

**fi-Q0959** — Kummasta sinä pidät enemmän, Coca-colasta vai Pepsistä?

Which do you prefer, Coke or Pepsi?

Why: Comparison and stance. [[Finnish#^fi-Q0959|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Kummasta%20sin%C3%A4%20pid%C3%A4t%20enemm%C3%A4n%2C%20Coca-colasta%20vai%20Pepsist%C3%A4%3F)
^fi-Q0959-answer

**fi-Q0960** — Kummasta sinä pidät enemmän, Coca-colasta vai Pepsistä?

Which do you prefer, Coke or Pepsi?

Parempi is adjectival better; paremmin adverbial better. Kuitenkin marks nevertheless and siksi a consequence. Ehkä limits certainty. Compare the form’s actual role before choosing an English gloss.

Why: Comparison and stance. [[Finnish#^fi-Q0960|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Kummasta%20sin%C3%A4%20pid%C3%A4t%20enemm%C3%A4n%2C%20Coca-colasta%20vai%20Pepsist%C3%A4%3F)
^fi-Q0960-answer

**fi-Q0961** — Tom toivoi osaavansa enemmän kuin yhtä kieltä.

Tom wished he knew more than one language.

Expected form: **enemmän**

Why: Comparison and stance. [[Finnish#^fi-Q0961|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tom%20toivoi%20osaavansa%20enemm%C3%A4n%20kuin%20yht%C3%A4%20kielt%C3%A4.)
^fi-Q0961-answer

**fi-Q0962** — Tom toivoi osaavansa enemmän kuin yhtä kieltä.

Tom wished he knew more than one language.

Expected form: **enemmän**

Why: Comparison and stance. [[Finnish#^fi-Q0962|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tom%20toivoi%20osaavansa%20enemm%C3%A4n%20kuin%20yht%C3%A4%20kielt%C3%A4.)
^fi-Q0962-answer

**fi-Q0963** — Ilmeisesti jotkin rupikonnalajit hyötyivät enemmän selkäkyhmystä kuin sileästä selästä.

Apparently, in some toad species, to have a protuberance on their backs was more advantages than to have a smooth back.

Expected form: **enemmän**

Why: Comparison and stance. [[Finnish#^fi-Q0963|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Ilmeisesti%20jotkin%20rupikonnalajit%20hy%C3%B6tyiv%C3%A4t%20enemm%C3%A4n%20selk%C3%A4kyhmyst%C3%A4%20kuin%20sile%C3%A4st%C3%A4%20sel%C3%A4st%C3%A4.)
^fi-Q0963-answer

**fi-Q0964** — Ilmeisesti jotkin rupikonnalajit hyötyivät enemmän selkäkyhmystä kuin sileästä selästä.

Apparently, in some toad species, to have a protuberance on their backs was more advantages than to have a smooth back.

Why: Comparison and stance. [[Finnish#^fi-Q0964|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Ilmeisesti%20jotkin%20rupikonnalajit%20hy%C3%B6tyiv%C3%A4t%20enemm%C3%A4n%20selk%C3%A4kyhmyst%C3%A4%20kuin%20sile%C3%A4st%C3%A4%20sel%C3%A4st%C3%A4.)
^fi-Q0964-answer

**fi-Q0965** — Se maksaa enemmän kuin luulin.

That costs more than I thought.

Why: Comparison and stance. [[Finnish#^fi-Q0965|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Se%20maksaa%20enemm%C3%A4n%20kuin%20luulin.)
^fi-Q0965-answer

**fi-Q0966** — Se maksaa enemmän kuin luulin.

That costs more than I thought.

Parempi is adjectival better; paremmin adverbial better. Kuitenkin marks nevertheless and siksi a consequence. Ehkä limits certainty. Compare the form’s actual role before choosing an English gloss.

Why: Comparison and stance. [[Finnish#^fi-Q0966|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Se%20maksaa%20enemm%C3%A4n%20kuin%20luulin.)
^fi-Q0966-answer

**fi-Q0967** — Hän ei puhu ainoastaan englantia vaan myös saksaa.

Not only does she speak English, but also German.

Expected form: **myös**

Why: Comparison and stance. [[Finnish#^fi-Q0967|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=H%C3%A4n%20ei%20puhu%20ainoastaan%20englantia%20vaan%20my%C3%B6s%20saksaa.)
^fi-Q0967-answer

**fi-Q0968** — Hän ei puhu ainoastaan englantia vaan myös saksaa.

Not only does she speak English, but also German.

Expected form: **myös**

Why: Comparison and stance. [[Finnish#^fi-Q0968|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=H%C3%A4n%20ei%20puhu%20ainoastaan%20englantia%20vaan%20my%C3%B6s%20saksaa.)
^fi-Q0968-answer

**fi-Q0969** — Hän ei ole vain ystävällinen vaan myös antelias.

She's not just friendly but also generous.

Expected form: **myös**

Why: Comparison and stance. [[Finnish#^fi-Q0969|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=H%C3%A4n%20ei%20ole%20vain%20yst%C3%A4v%C3%A4llinen%20vaan%20my%C3%B6s%20antelias.)
^fi-Q0969-answer

**fi-Q0970** — Hän ei ole vain ystävällinen vaan myös antelias.

She's not just friendly but also generous.

Why: Comparison and stance. [[Finnish#^fi-Q0970|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=H%C3%A4n%20ei%20ole%20vain%20yst%C3%A4v%C3%A4llinen%20vaan%20my%C3%B6s%20antelias.)
^fi-Q0970-answer

**fi-Q0971** — Ilmapallon pinta ei ole euklidinen avaruus, eikä siksi noudata euklidisen geometrian sääntöjä.

The surface of a balloon is not an Euclidean space, and therefore does not follow the rules of Euclidean geometry.

Why: Comparison and stance. [[Finnish#^fi-Q0971|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Ilmapallon%20pinta%20ei%20ole%20euklidinen%20avaruus%2C%20eik%C3%A4%20siksi%20noudata%20euklidisen%20geometrian%20s%C3%A4%C3%A4nt%C3%B6j%C3%A4.)
^fi-Q0971-answer

**fi-Q0972** — Ilmapallon pinta ei ole euklidinen avaruus, eikä siksi noudata euklidisen geometrian sääntöjä.

The surface of a balloon is not an Euclidean space, and therefore does not follow the rules of Euclidean geometry.

Parempi is adjectival better; paremmin adverbial better. Kuitenkin marks nevertheless and siksi a consequence. Ehkä limits certainty. Compare the form’s actual role before choosing an English gloss.

Why: Comparison and stance. [[Finnish#^fi-Q0972|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Ilmapallon%20pinta%20ei%20ole%20euklidinen%20avaruus%2C%20eik%C3%A4%20siksi%20noudata%20euklidisen%20geometrian%20s%C3%A4%C3%A4nt%C3%B6j%C3%A4.)
^fi-Q0972-answer

**fi-Q0973** — Ehkä hänestä ei tule koskaan kuuluisaa.

Perhaps he'll never become famous.

Expected form: **Ehkä**

Why: Comparison and stance. [[Finnish#^fi-Q0973|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Ehk%C3%A4%20h%C3%A4nest%C3%A4%20ei%20tule%20koskaan%20kuuluisaa.)
^fi-Q0973-answer

**fi-Q0974** — Ehkä hänestä ei tule koskaan kuuluisaa.

Perhaps he'll never become famous.

Expected form: **Ehkä**

Why: Comparison and stance. [[Finnish#^fi-Q0974|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Ehk%C3%A4%20h%C3%A4nest%C3%A4%20ei%20tule%20koskaan%20kuuluisaa.)
^fi-Q0974-answer

**fi-Q0975** — Ehkä se on sinun ongelmasi.

Maybe that's your problem.

Expected form: **Ehkä**

Why: Comparison and stance. [[Finnish#^fi-Q0975|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Ehk%C3%A4%20se%20on%20sinun%20ongelmasi.)
^fi-Q0975-answer

**fi-Q0976** — Ehkä se on sinun ongelmasi.

Maybe that's your problem.

Why: Comparison and stance. [[Finnish#^fi-Q0976|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Ehk%C3%A4%20se%20on%20sinun%20ongelmasi.)
^fi-Q0976-answer

**fi-Q0977** — Minkä näistä kahdesta ajattelet olevan parempi.

Which of these two do you think is better?

Why: Comparison and stance. [[Finnish#^fi-Q0977|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Mink%C3%A4%20n%C3%A4ist%C3%A4%20kahdesta%20ajattelet%20olevan%20parempi.)
^fi-Q0977-answer

**fi-Q0978** — Minkä näistä kahdesta ajattelet olevan parempi.

Which of these two do you think is better?

Parempi is adjectival better; paremmin adverbial better. Kuitenkin marks nevertheless and siksi a consequence. Ehkä limits certainty. Compare the form’s actual role before choosing an English gloss.

Why: Comparison and stance. [[Finnish#^fi-Q0978|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Mink%C3%A4%20n%C3%A4ist%C3%A4%20kahdesta%20ajattelet%20olevan%20parempi.)
^fi-Q0978-answer

**fi-Q0979** — Korkeakoulutuksen suorittaneet tienaavat keskimäärin yli 50 prosenttia enemmän kuin vain toisen asteen päättötodistukselliset.

College graduates earn on average over fifty per cent more than those with only a high-school degree.

Expected form: **enemmän**

Why: Comparison and stance. [[Finnish#^fi-Q0979|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Korkeakoulutuksen%20suorittaneet%20tienaavat%20keskim%C3%A4%C3%A4rin%20yli%2050%20prosenttia%20enemm%C3%A4n%20kuin%20vain%20toisen%20asteen%20p%C3%A4%C3%A4tt%C3%B6todistukselliset.)
^fi-Q0979-answer

**fi-Q0980** — Korkeakoulutuksen suorittaneet tienaavat keskimäärin yli 50 prosenttia enemmän kuin vain toisen asteen päättötodistukselliset.

College graduates earn on average over fifty per cent more than those with only a high-school degree.

Expected form: **enemmän**

Why: Comparison and stance. [[Finnish#^fi-Q0980|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Korkeakoulutuksen%20suorittaneet%20tienaavat%20keskim%C3%A4%C3%A4rin%20yli%2050%20prosenttia%20enemm%C3%A4n%20kuin%20vain%20toisen%20asteen%20p%C3%A4%C3%A4tt%C3%B6todistukselliset.)
^fi-Q0980-answer

**fi-Q0981** — Ehkä meidän ei pitäisi mennä sinne.

Maybe we shouldn't go there.

Expected form: **Ehkä**

Why: Comparison and stance. [[Finnish#^fi-Q0981|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Ehk%C3%A4%20meid%C3%A4n%20ei%20pit%C3%A4isi%20menn%C3%A4%20sinne.)
^fi-Q0981-answer

**fi-Q0982** — Ehkä meidän ei pitäisi mennä sinne.

Maybe we shouldn't go there.

Why: Comparison and stance. [[Finnish#^fi-Q0982|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Ehk%C3%A4%20meid%C3%A4n%20ei%20pit%C3%A4isi%20menn%C3%A4%20sinne.)
^fi-Q0982-answer

**fi-Q0983** — He eivät ole vain kämppiksiä, vaan myös rakastavaisia.

They're not just roommates. They're also lovers.

Why: Comparison and stance. [[Finnish#^fi-Q0983|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=He%20eiv%C3%A4t%20ole%20vain%20k%C3%A4mppiksi%C3%A4%2C%20vaan%20my%C3%B6s%20rakastavaisia.)
^fi-Q0983-answer

**fi-Q0984** — He eivät ole vain kämppiksiä, vaan myös rakastavaisia.

They're not just roommates. They're also lovers.

Parempi is adjectival better; paremmin adverbial better. Kuitenkin marks nevertheless and siksi a consequence. Ehkä limits certainty. Compare the form’s actual role before choosing an English gloss.

Why: Comparison and stance. [[Finnish#^fi-Q0984|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=He%20eiv%C3%A4t%20ole%20vain%20k%C3%A4mppiksi%C3%A4%2C%20vaan%20my%C3%B6s%20rakastavaisia.)
^fi-Q0984-answer

**fi-Q0985** — Suuren hadronitörmäyttimen tulokset merkitsevät, että supersymmetriateoreetikoiden on ehkä keksittävä uusi alkeishiukkasteoria.

Results from the Large Hadron Collider mean that supersymmetry theorists may have to come up with a new theory of sub-atomic physics.

Expected form: **ehkä**

Why: Comparison and stance. [[Finnish#^fi-Q0985|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Suuren%20hadronit%C3%B6rm%C3%A4yttimen%20tulokset%20merkitsev%C3%A4t%2C%20ett%C3%A4%20supersymmetriateoreetikoiden%20on%20ehk%C3%A4%20keksitt%C3%A4v%C3%A4%20uusi%20alkeishiukkasteoria.)
^fi-Q0985-answer

**fi-Q0986** — Suuren hadronitörmäyttimen tulokset merkitsevät, että supersymmetriateoreetikoiden on ehkä keksittävä uusi alkeishiukkasteoria.

Results from the Large Hadron Collider mean that supersymmetry theorists may have to come up with a new theory of sub-atomic physics.

Expected form: **ehkä**

Why: Comparison and stance. [[Finnish#^fi-Q0986|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Suuren%20hadronit%C3%B6rm%C3%A4yttimen%20tulokset%20merkitsev%C3%A4t%2C%20ett%C3%A4%20supersymmetriateoreetikoiden%20on%20ehk%C3%A4%20keksitt%C3%A4v%C3%A4%20uusi%20alkeishiukkasteoria.)
^fi-Q0986-answer

**fi-Q0987** — Tomi syö kuin possu ja näyttää semmoiselta myös.

Tom eats like a pig and he looks like one, too.

Expected form: **myös**

Why: Comparison and stance. [[Finnish#^fi-Q0987|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tomi%20sy%C3%B6%20kuin%20possu%20ja%20n%C3%A4ytt%C3%A4%C3%A4%20semmoiselta%20my%C3%B6s.)
^fi-Q0987-answer

**fi-Q0988** — Tomi syö kuin possu ja näyttää semmoiselta myös.

Tom eats like a pig and he looks like one, too.

Why: Comparison and stance. [[Finnish#^fi-Q0988|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tomi%20sy%C3%B6%20kuin%20possu%20ja%20n%C3%A4ytt%C3%A4%C3%A4%20semmoiselta%20my%C3%B6s.)
^fi-Q0988-answer

**fi-Q0989** — Tom tietää enemmän tällaisesta asiasta kuin Mari.

Tom knows more about this kind of thing than Mary does.

Why: Comparison and stance. [[Finnish#^fi-Q0989|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tom%20tiet%C3%A4%C3%A4%20enemm%C3%A4n%20t%C3%A4llaisesta%20asiasta%20kuin%20Mari.)
^fi-Q0989-answer

**fi-Q0990** — Tom tietää enemmän tällaisesta asiasta kuin Mari.

Tom knows more about this kind of thing than Mary does.

Parempi is adjectival better; paremmin adverbial better. Kuitenkin marks nevertheless and siksi a consequence. Ehkä limits certainty. Compare the form’s actual role before choosing an English gloss.

Why: Comparison and stance. [[Finnish#^fi-Q0990|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Tom%20tiet%C3%A4%C3%A4%20enemm%C3%A4n%20t%C3%A4llaisesta%20asiasta%20kuin%20Mari.)
^fi-Q0990-answer

**fi-Q0991** — Suunnittelen parhaillaan seuraavaa lomaani. Menen ehkä Disney landiin perheeni ja ystävieni kanssa. Kuinka paljon minun pitäisi säästää lomaa varten?

I'm planning my next vacation. Maybe I'll go to Disneyland with my family and friends. How much should I save for it?

Expected form: **ehkä**

Why: Comparison and stance. [[Finnish#^fi-Q0991|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Suunnittelen%20parhaillaan%20seuraavaa%20lomaani.%20Menen%20ehk%C3%A4%20Disney%20landiin%20perheeni%20ja%20yst%C3%A4vieni%20kanssa.%20Kuinka%20paljon%20minun%20pit%C3%A4isi%20s%C3%A4%C3%A4st%C3%A4%C3%A4%20lomaa%20varten%3F)
^fi-Q0991-answer

**fi-Q0992** — Suunnittelen parhaillaan seuraavaa lomaani. Menen ehkä Disney landiin perheeni ja ystävieni kanssa. Kuinka paljon minun pitäisi säästää lomaa varten?

I'm planning my next vacation. Maybe I'll go to Disneyland with my family and friends. How much should I save for it?

Expected form: **ehkä**

Why: Comparison and stance. [[Finnish#^fi-Q0992|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Suunnittelen%20parhaillaan%20seuraavaa%20lomaani.%20Menen%20ehk%C3%A4%20Disney%20landiin%20perheeni%20ja%20yst%C3%A4vieni%20kanssa.%20Kuinka%20paljon%20minun%20pit%C3%A4isi%20s%C3%A4%C3%A4st%C3%A4%C3%A4%20lomaa%20varten%3F)
^fi-Q0992-answer

**fi-Q0993** — Kun ihmiset vanhenevat, heidän aivosolunsa tulevat vähemmän tehokkaiksi.

As people get older, their brain cells become less efficient.

Expected form: **vähemmän**

Why: Comparison and stance. [[Finnish#^fi-Q0993|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Kun%20ihmiset%20vanhenevat%2C%20heid%C3%A4n%20aivosolunsa%20tulevat%20v%C3%A4hemm%C3%A4n%20tehokkaiksi.)
^fi-Q0993-answer

**fi-Q0994** — Kun ihmiset vanhenevat, heidän aivosolunsa tulevat vähemmän tehokkaiksi.

As people get older, their brain cells become less efficient.

Why: Comparison and stance. [[Finnish#^fi-Q0994|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Kun%20ihmiset%20vanhenevat%2C%20heid%C3%A4n%20aivosolunsa%20tulevat%20v%C3%A4hemm%C3%A4n%20tehokkaiksi.)
^fi-Q0994-answer

**fi-Q0995** — Mitä enemmän me epäilemme heitä, sitä enemmän he epäilevät meitä.

If we suspect others, others will suspect us just as much.

Why: Comparison and stance. [[Finnish#^fi-Q0995|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Mit%C3%A4%20enemm%C3%A4n%20me%20ep%C3%A4ilemme%20heit%C3%A4%2C%20sit%C3%A4%20enemm%C3%A4n%20he%20ep%C3%A4ilev%C3%A4t%20meit%C3%A4.)
^fi-Q0995-answer

**fi-Q0996** — Mitä enemmän me epäilemme heitä, sitä enemmän he epäilevät meitä.

If we suspect others, others will suspect us just as much.

Parempi is adjectival better; paremmin adverbial better. Kuitenkin marks nevertheless and siksi a consequence. Ehkä limits certainty. Compare the form’s actual role before choosing an English gloss.

Why: Comparison and stance. [[Finnish#^fi-Q0996|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Mit%C3%A4%20enemm%C3%A4n%20me%20ep%C3%A4ilemme%20heit%C3%A4%2C%20sit%C3%A4%20enemm%C3%A4n%20he%20ep%C3%A4ilev%C3%A4t%20meit%C3%A4.)
^fi-Q0996-answer

**fi-Q0997** — Hän on parempi kuin minä.

She's better than me.

Expected form: **parempi**

Why: Comparison and stance. [[Finnish#^fi-Q0997|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=H%C3%A4n%20on%20parempi%20kuin%20min%C3%A4.)
^fi-Q0997-answer

**fi-Q0998** — Hän on parempi kuin minä.

She's better than me.

Expected form: **parempi**

Why: Comparison and stance. [[Finnish#^fi-Q0998|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=H%C3%A4n%20on%20parempi%20kuin%20min%C3%A4.)
^fi-Q0998-answer

**fi-Q0999** — Pidän myös makeisista.

I like candy, too.

Expected form: **myös**

Why: Comparison and stance. [[Finnish#^fi-Q0999|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Pid%C3%A4n%20my%C3%B6s%20makeisista.)
^fi-Q0999-answer

**fi-Q1000** — Pidän myös makeisista.

I like candy, too.

Why: Comparison and stance. [[Finnish#^fi-Q1000|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=fin&query=Pid%C3%A4n%20my%C3%B6s%20makeisista.)
^fi-Q1000-answer


## Read and speak

Read the native sentence first, identify its predicate and one grammar form, then check the translation. Say it aloud and change one detail.

### Learning with a clear purpose

Opiskelen uutta kieltä. Luen joka päivä lyhyen tekstin ja kuuntelen selkeitä esimerkkejä. Kirjoitan hyödyllisiä sanoja vihkoon. Kun teen virheen, tarkistan säännön ja yritän uudelleen. Tavoitteeni on ymmärtää ihmisiä ja ilmaista ajatukseni selkeästi.

I am learning a new language. Each day, I read a short text and listen to clear examples. I write useful words in a notebook. When I make a mistake, I check the rule and try again. My goal is to understand people and express my ideas clearly.

![[Resources/Audio/fi/Reading passage.mp3]]

**Kirjoittaja latoo koko eurooppalaisen kirjallisuuden yhteen kasaan.**

The author lumps all the different European literatures together.

**Voisitko katsoa hetken muualle kun vaihdan vaatteeni?**

Would you mind looking the other way for just a minute while I change my clothes?

**Kahden kauppa on kolmannen korvapuusti.**

When two people quarrel, a third rejoices.

**He vaativat taistelulle loppua.**

They called for an end to the fighting.

**Tomi on äreä.**

Tom is grumpy.

**Minä olen jo rakastunut sinuun.**

I'm in love with you already.

**Vannoin, että en puhuisi enää ikinä hänelle.**

I vowed that I would never speak to her again.

**Tomin operoinut kirurgi on hyvin kokenut ja erittäin arvostettu.**

The surgeon who did Tom's operation is very experienced and highly regarded.

**Pystyn syömään mitätahansa paitsi sipulia.**

I can eat anything but onions.

**”Minua ei huvita juoda tänään.” ”Älä viitsi, nyt on syntymäpäiväni.”**

"I don't feel like drinking today." "Come on, it's my birthday!"

**Tomi on kauhistunut.**

Tom's terrified.

**Tehdäänpä sitten työmme.**

Let's do our job.

**Minä en ole pingviini.**

I am not a penguin.

**Vaikuttaa siltä, että olet humalassa.**

You seem to be drunk.

**Tomilla on lounastapaaminen Maryn kanssa.**

Tom has a lunch date with Mary.

## Professional writing

Write an introduction, a polite request, an explanation of a finding, a summary of a passage and a tactful disagreement. Use the professional/advanced lessons for models.

## PDF edition

[[Resources/PDFs/Finnish.pdf|Open the complete printable book]]


<!-- individual-letter-audio -->
## Hear each letter separately

Play each letter’s own synthetic recording. English has separate US and UK models.

### A a · aa

![[Resources/Audio/fi/Letters/001.mp3]]

### B b · bee

![[Resources/Audio/fi/Letters/002.mp3]]

### C c · see

![[Resources/Audio/fi/Letters/003.mp3]]

### D d · dee

![[Resources/Audio/fi/Letters/004.mp3]]

### E e · ee

![[Resources/Audio/fi/Letters/005.mp3]]

### F f · äf

![[Resources/Audio/fi/Letters/006.mp3]]

### G g · gee

![[Resources/Audio/fi/Letters/007.mp3]]

### H h · hoo

![[Resources/Audio/fi/Letters/008.mp3]]

### I i · ii

![[Resources/Audio/fi/Letters/009.mp3]]

### J j · jii

![[Resources/Audio/fi/Letters/010.mp3]]

### K k · koo

![[Resources/Audio/fi/Letters/011.mp3]]

### L l · äl

![[Resources/Audio/fi/Letters/012.mp3]]

### M m · äm

![[Resources/Audio/fi/Letters/013.mp3]]

### N n · än

![[Resources/Audio/fi/Letters/014.mp3]]

### O o · oo

![[Resources/Audio/fi/Letters/015.mp3]]

### P p · pee

![[Resources/Audio/fi/Letters/016.mp3]]

### Q q · kuu

![[Resources/Audio/fi/Letters/017.mp3]]

### R r · är

![[Resources/Audio/fi/Letters/018.mp3]]

### S s · äs

![[Resources/Audio/fi/Letters/019.mp3]]

### T t · tee

![[Resources/Audio/fi/Letters/020.mp3]]

### U u · uu

![[Resources/Audio/fi/Letters/021.mp3]]

### V v · vee

![[Resources/Audio/fi/Letters/022.mp3]]

### W w · kaksoisvee

![[Resources/Audio/fi/Letters/023.mp3]]

### X x · äks

![[Resources/Audio/fi/Letters/024.mp3]]

### Y y · yy

![[Resources/Audio/fi/Letters/025.mp3]]

### Z z · tseta

![[Resources/Audio/fi/Letters/026.mp3]]

### Å å · ruotsalainen oo

![[Resources/Audio/fi/Letters/027.mp3]]

### Ä ä · ää

![[Resources/Audio/fi/Letters/028.mp3]]

### Ö ö · öö

![[Resources/Audio/fi/Letters/029.mp3]]
<!-- /individual-letter-audio -->
