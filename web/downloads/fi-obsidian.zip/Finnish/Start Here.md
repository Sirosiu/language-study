# Finnish study

[[Finnish|Open the complete Finnish course note]]

Audio and the printable PDF are in Resources. This vault contains one language.

[[Sources and licenses]]
