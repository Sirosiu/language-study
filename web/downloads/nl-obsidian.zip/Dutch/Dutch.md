# Dutch

Professional ambition - C1-oriented study

Everything for this language is in this note. Open a rule, read its examples and follow its practice link. Answers stay in this same note.

[[Start Here|All languages]] · [[Sources and licenses|Sources]]

## Start reading

### het alfabet

| Written form | Name / reading | Related forms |
|---|---|---|
| A a | aa  |  ·  ·  |
| B b | bee  |  ·  ·  |
| C c | cee  |  ·  ·  |
| D d | dee  |  ·  ·  |
| E e | ee  |  ·  ·  |
| F f | ef  |  ·  ·  |
| G g | gee  |  ·  ·  |
| H h | haa  |  ·  ·  |
| I i | ie  |  ·  ·  |
| J j | jee  |  ·  ·  |
| K k | kaa  |  ·  ·  |
| L l | el  |  ·  ·  |
| M m | em  |  ·  ·  |
| N n | en  |  ·  ·  |
| O o | oo  |  ·  ·  |
| P p | pee  |  ·  ·  |
| Q q | kuu  |  ·  ·  |
| R r | er  |  ·  ·  |
| S s | es  |  ·  ·  |
| T t | tee  |  ·  ·  |
| U u | uu  |  ·  ·  |
| V v | vee  |  ·  ·  |
| W w | wee  |  ·  ·  |
| X x | iks  |  ·  ·  |
| Y y | ij / i-grec  |  ·  ·  |
| Z z | zet  |  ·  ·  |

![[Resources/Audio/nl/Script and first phrases.mp3]]

The player above is synthetic speech. Word tracks below work offline.

### Letters and digraphs

Dutch uses 26 letters. ij is an important digraph, often capitalised together at the start: IJssel. It is not an additional letter in standard alphabetical ordering. Letter names differ from sounds in words.

### Vowels need length

Compare man and maan. A single vowel in an open syllable can be long: ma-ken. A doubled consonant keeps the preceding vowel short: man-nen. oe is /u/; ie is /i/; eu and ui need listening practice; English spellings are poor substitutes.

### Consonants and rhythm

g and ch are often fricatives, with softer regional realisations in the south. Word-final voiced obstruents are generally devoiced. Learn lexical stress and reduced unstressed e (schwa). Dutch speech differs in the Netherlands and Belgium.

### Add a diminutive

boek → boekje = book → little book. Diminutives take het: het boekje, even when the original noun uses de. The exact suffix can be -je, -tje, -pje, -etje or -kje.

### Build a compound

taal + cursus → taalcursus = language course. The final noun supplies the main meaning and normally its gender.

### Separate a verb

opbellen = to phone; Ik bel je op. = I phone you. In a subordinate clause: omdat ik je opbel = because I phone you.

**Goedemorgen.**

Good morning.

**Ik leer Nederlands.**

I am learning Dutch.

**Kunt u dat herhalen?**

Can you repeat that?

**Wat betekent dit woord?**

What does this word mean?

### Grammar terms in plain English

**Noun** — A word naming a person, thing or idea: student, book, freedom.

**Verb** — A word describing an action or state: read, know, be.

**Subject** — The participant linked to the main verb’s subject pattern. In The student reads a book, the student is the subject.

**Object** — A participant selected by a verb. In The student reads a book, a book is the direct object.

**Agreement** — One word changes to match another, for example an adjective matching a noun’s gender and number.

**Case** — A noun/pronoun form marking its relationship in a sentence. Cases can mark subjects, objects, possession or relations usually expressed by English prepositions.

**Gender** — A grammatical noun class. It does not always describe the sex of a person or any physical property.

**Tense** — A verb system that relates a situation to a time, often past or non-past.

**Aspect** — How a situation is viewed: unfolding, completed, habitual, experienced or in a resulting state.

**Infinitive** — A non-finite verb form often used for a dictionary entry or a complement. It does not by itself give the ordinary person/tense pattern.

**Participle** — A verb-derived form used in compound predicates or as a modifier; its exact function depends on the language and construction.

**Clause** — A unit organised around a predicate. One sentence can contain several clauses.

**Register** — Language choices suited to a situation: casual conversation, polite requests, academic writing or another context.

## Grammar, examples and practice

### Gender, articles and adjectives

Dutch distinguishes common-gender de nouns and neuter het nouns; plurals use de. Diminutives are normally neuter. Attributive adjectives usually take -e, but an indefinite singular neuter noun often has no -e: een goed boek versus het goede boek. Predicative adjectives normally remain uninflected. Lexical and fixed-expression exceptions deserve example-based study.

**een interessant boek / het interessante boek**

an interesting book / the interesting book Indefinite neuter singular adjective contrast.

**de nieuwe methode**

the new method Common-gender noun with attributive -e.

#### De and het

Dutch distinguishes common-gender de nouns and neuter het nouns; plurals use de. Een introduces an indefinite singular noun. Diminutives take het regardless of the base noun’s gender.

**Mexico-Stad is de hoofdstad van Mexico.**

Mexico City is the capital of Mexico.

**Een vrouwenhater moet je echt zo hard vertrouwen als het weer.**

We must trust misogynists as much as we can trust the weather.

![[Resources/Audio/nl/Rule 01.mp3]]

[[Dutch#^nl-Q0001|Practise this rule (50 questions)]]

#### Demonstratives

Dit/dat commonly pair with singular het nouns; deze/die with de nouns and plurals. Distance and discourse determine the near/far distinction.

**Dit boek was gemakkelijk.**

This book was easy.

**Ik heb geen idee hoe ze dat voor elkaar gekregen hebben.**

I don't know how they did it.

![[Resources/Audio/nl/Rule 02.mp3]]

[[Dutch#^nl-Q0051|Practise this rule (50 questions)]]

#### Personal pronouns

Dutch pronouns have stressed and unstressed forms. Je/ze/we are common reduced forms. U is polite you and follows its own agreement patterns.

**Jullie zijn goud waard.**

You're worth gold.

**Ik ga vandaag niet meer werken.**

I am not going to work more today.

![[Resources/Audio/nl/Rule 03.mp3]]

[[Dutch#^nl-Q0101|Practise this rule (50 questions)]]

#### Adjectives

Attributive adjectives often take -e. An indefinite singular neuter noun often has an uninflected adjective: een goed boek. A predicative adjective normally has no -e.

**Ik woon in een heel klein appartement.**

I live in a very small apartment.

**Dit is goed vlees.**

This is good meat.

![[Resources/Audio/nl/Rule 16.mp3]]

[[Dutch#^nl-Q0751|Practise this rule (50 questions)]]

<details><summary>Complete: een klein__ huis.</summary>

Een klein huis. Indefinite singular neuter pattern.

</details>

<details><summary>What article do ordinary plurals take?</summary>

De: de boeken, de huizen.

</details>

### Verb position and separable verbs

Main declaratives place the finite verb in second constituent position; a fronted adverb inverts subject and verb. Subordinate clauses often place verb material at the end. Separable verbs split in suitable main clauses: ik bel je op. Infinitives and participles form a sentence bracket; subordinate verb-cluster orders have variation and should be studied from reliable standard examples.

**Morgen bespreek ik het rapport.**

Tomorrow I will discuss the report. Verb-second after fronted morgen.

**Ik denk dat hij het rapport heeft gelezen.**

I think he has read the report. Embedded clause with final verb cluster.

#### Zijn forms

Zijn is irregular. Main statements normally place the finite verb second; yes/no questions place it first. With jij/je after the verb, the present -t is often absent in applicable verbs.

**Mijn Frans is nog steeds niet zo goed.**

My French is still not very good.

**Sommige mensen zijn allergisch voor latex.**

Some people are allergic to latex.

![[Resources/Audio/nl/Rule 04.mp3]]

[[Dutch#^nl-Q0151|Practise this rule (50 questions)]]

#### Hebben forms

Hebben expresses possession and serves as an auxiliary. The finite form agrees with the subject; a participle or infinitive can stand at the end of the clause.

**Water heeft nul calorieën.**

Water has zero calories.

**Tom heeft hoop.**

Tom has hope.

![[Resources/Audio/nl/Rule 05.mp3]]

[[Dutch#^nl-Q0201|Practise this rule (50 questions)]]

#### Subordinate connectors

Subordinate clauses usually put their verb cluster late. Of can introduce an indirect yes/no question. An ordinary main clause follows verb-second order.

**Als het weer gebeurt, laat het me meteen weten a.u.b.**

If it happens again, please let me know right away.

**Jeff was drie maanden op zoek voordat hij een baan vond.**

Jeff searched for three months before he found a job.

![[Resources/Audio/nl/Rule 06.mp3]]

[[Dutch#^nl-Q0251|Practise this rule (50 questions)]]

#### Negation

Geen negates many indefinite noun phrases; niet negates a predicate or other constituent. Niet placement controls which part is negated.

**Om het even wat ze eet, ze verdikt niet.**

However much she eats, she never gains weight.

**Ik wil niet slapen.**

I don't want to sleep.

![[Resources/Audio/nl/Rule 07.mp3]]

[[Dutch#^nl-Q0301|Practise this rule (50 questions)]]

#### Infinitives and purpose

Many infinitive complements use te; om ... te commonly expresses purpose. Te can also intensify an adjective, so identify the following phrase.

**Ze ging op haar knieën om te bidden.**

She went down on her knees to pray.

**Tom zat op de bank te roken.**

Tom sat on the bench smoking.

![[Resources/Audio/nl/Rule 15.mp3]]

[[Dutch#^nl-Q0701|Practise this rule (50 questions)]]

#### Coordination

Coordinating conjunctions connect similar structures without imposing subordinate verb-final order. Want supplies a reason with main-clause grammar.

**Tom en Maria zijn aan het liften.**

Tom and Mary are hitchhiking.

**Hij is jong, maar wel heel intelligent.**

He's young, but he's very intelligent.

![[Resources/Audio/nl/Rule 17.mp3]]

[[Dutch#^nl-Q0801|Practise this rule (50 questions)]]

<details><summary>Reorder morgen / ik / begin.</summary>

Morgen begin ik. Fronting requires the finite verb before the subject.

</details>

<details><summary>Use opbellen in a main clause.</summary>

Ik bel de collega morgen op. The prefix closes the bracket.

</details>

### Time, passive and modality

Perfect tense uses hebben or zijn with a participle, with lexical and motion-related patterns. Written narration can favour the simple past. Present tense frequently refers to planned future events. Worden + participle forms an event passive; zijn + participle can express a state or perfect passive depending on context. Zou supports polite and hypothetical meanings; moeten and hoeven differ under negation.

**Het rapport wordt gecontroleerd.**

The report is being checked. Event passive.

**U hoeft niet te wachten.**

You do not have to wait. Absence of necessity, not prohibition.

#### Modal verbs

Modals govern an infinitive and express ability, obligation, permission, desire or prediction. The finite modal occupies the normal finite-verb position; the infinitive commonly stands late.

**De tijd zal het zeggen.**

Time will tell.

**Ja, ik kan.**

Yes, I can.

![[Resources/Audio/nl/Rule 08.mp3]]

[[Dutch#^nl-Q0351|Practise this rule (50 questions)]]

#### Past zijn and hebben

Was/waren and had/hadden are common past forms. They can be main verbs or auxiliaries; a later participle determines whether a pluperfect construction is present.

**De Romeinse troepen waren uitgeput.**

The Roman troops were exhausted.

**Hoe was je biologie-examen?**

How was your biology exam?

![[Resources/Audio/nl/Rule 09.mp3]]

[[Dutch#^nl-Q0401|Practise this rule (50 questions)]]

#### Past participles

A perfect combines hebben or zijn with a past participle. Motion/change verbs may use zijn in relevant meanings; learn auxiliary choice with the verb.

**Wie heeft die doos gemaakt?**

Who made this box?

**Het maakt niet uit wat ze gezegd heeft.**

It doesn't matter what she said.

![[Resources/Audio/nl/Rule 10.mp3]]

[[Dutch#^nl-Q0451|Practise this rule (50 questions)]]

#### Conditional forms

Zou/zouden often mark a conditional or future in the past. Kon/konden can be past ability or hypothetical ability. Context determines whether the situation is factual or unreal.

**Ik wou dat ik kon stoppen met denken aan Tom.**

I wish I could stop thinking about Tom.

**Als ik het alfabet kon herschikken, dan zette ik nog steeds T voor U.**

If I could rearrange the alphabet, I would put U and I together.

![[Resources/Audio/nl/Rule 11.mp3]]

[[Dutch#^nl-Q0501|Practise this rule (50 questions)]]

#### Passives and worden

Worden plus participle commonly forms an event passive. Worden can also mean become. Inspect the complete predicate before naming the construction.

**Die hierboven vermelde zending werd behoorlijk afgeleverd.**

The above-mentioned mail item has been duly delivered.

**Frans wordt gesproken in Zwitserland.**

French is spoken in Switzerland.

![[Resources/Audio/nl/Rule 12.mp3]]

[[Dutch#^nl-Q0551|Practise this rule (50 questions)]]

#### Comparison

Comparatives commonly use dan; equality commonly uses zo ... als. Beter is the irregular comparative of goed. Distinguish comparison from other uses of dan/als.

**In alle geval kunt ge beter gehoorzamen aan uw ouders.**

In any case you had better obey your parents.

**Ze is twee jaar ouder dan jij.**

She is two years older than you.

![[Resources/Audio/nl/Rule 19.mp3]]

[[Dutch#^nl-Q0901|Practise this rule (50 questions)]]

<details><summary>Contrast niet mogen and niet hoeven.</summary>

Niet mogen forbids or denies permission; niet hoeven removes necessity.

</details>

<details><summary>Request clarification politely.</summary>

Zou u dit punt kunnen toelichten? A conventional courteous question.

</details>

### Relative clauses, er and formal structure

Die refers to de nouns and dat to singular het nouns in core relative patterns. Relative clauses are verb-final. Er has several functions: location, existence, quantities and pronominal adverbs. Er zijn drie opties introduces existence; ik heb er drie represents a quantity. Combinations such as daarmee and hierover replace preposition + thing relationships; human references can need other forms.

**het rapport dat we gisteren hebben ontvangen**

the report we received yesterday Het noun with dat and a final verb cluster.

**Er zijn verschillende mogelijkheden.**

There are several possibilities. Existential er.

#### Relative pronouns

Die generally relates to de nouns and plurals; dat to singular het nouns. Wie/wat occur in other relative and interrogative constructions. The relative clause has subordinate word order.

**Alle zinnen die we verzamelen geven we uit onder de licentie Creatieve Commons - Naamsvermelding.**

We're releasing all the sentences we collect under the Creative Commons Attribution license.

**Wat is je meest geliefde vakantiebestemming?**

What's your favorite vacation place?

![[Resources/Audio/nl/Rule 13.mp3]]

[[Dutch#^nl-Q0601|Practise this rule (50 questions)]]

#### Er in context

Er can express a location, introduce an existence statement, support a quantity or occur in a pronominal adverb. Analyse its actual construction instead of assigning one English equivalent.

**De oude man zag er wijs uit.**

The old man looked wise.

**Er zijn veel dieren te zien in dit bos.**

You can see many animals in this forest.

![[Resources/Audio/nl/Rule 14.mp3]]

[[Dutch#^nl-Q0651|Practise this rule (50 questions)]]

#### Questions

A direct question often places the finite verb before the subject. An indirect question introduced by a question word normally follows subordinate order.

**Waar is jullie zoon?**

Where's your son?

**Waar is uw huiswerk?**

Where is your homework?

![[Resources/Audio/nl/Rule 18.mp3]]

[[Dutch#^nl-Q0851|Practise this rule (50 questions)]]

<details><summary>Choose de methode die / dat we gebruiken.</summary>

Die. Methode is a de noun.

</details>

<details><summary>Explain ik heb er twee.</summary>

I have two of them. Er carries the understood quantified noun.

</details>

### Professional reading and writing

Teaching passage: De resultaten wijzen op een verband tussen twee factoren. Ze bewijzen echter niet dat de ene factor de andere veroorzaakt. Bij de beoordeling van de conclusie moeten de omstandigheden van het onderzoek worden meegenomen.
Translation: The results indicate a relationship between two factors. However, they do not prove that one causes the other. The study conditions must be included when assessing the conclusion. Echter signals contrast; wijzen op is not equivalent to proving. Use u or je according to the relationship, not a rigid claim that every workplace uses formal address.

**Kunt u aangeven waarop deze schatting is gebaseerd?**

Could you indicate what this estimate is based on? Professional clarification with a pronominal-adverb relation.

**Daaruit volgt niet noodzakelijk dat ...**

It does not necessarily follow from that that ... A limited inference, useful in argument.

#### Cause and concession

Hoewel introduces concession in a subordinate clause. Daarom and dus express a consequence; toch and echter can signal contrast. Linking meaning and word order need separate attention.

**Daarom hou ik van je.**

That's why I like you.

**Het ziet ernaar uit dat de wereld toch niet is vergaan op 21 december.**

It looks like the world didn't end on December 21st after all.

![[Resources/Audio/nl/Rule 20.mp3]]

[[Dutch#^nl-Q0951|Practise this rule (50 questions)]]

<details><summary>Summarise without claiming causation.</summary>

The passage reports a relationship, denies proof of a causal direction and asks readers to consider conditions.

</details>

<details><summary>Write a professional request in 100 words.</summary>

Check verb-second, subordinate clusters, de/het choices and a clear requested action.

</details>

## Word bank and recordings

1,000 study entries, based on dictionary selections and authored teaching glosses. Learn a word in a phrase; consult the linked entry for additional senses.

<details><summary>Words 1–50</summary>

![[Resources/Audio/nl/Words 0001-0050.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [de](https://en.wiktionary.org/wiki/de#Dutch) | the (common-gender singular and all plurals) | /də/ · article |
| [van](https://en.wiktionary.org/wiki/van#Dutch) | of (possession, property) | /vɑn/ · prep |
| [het](https://en.wiktionary.org/wiki/het#Dutch) | the (neuter singular); it | /(ɦ)ət/ · article |
| [een](https://en.wiktionary.org/wiki/een#Dutch) | a/an; one | /ən/ · det |
| [en](https://en.wiktionary.org/wiki/en#Dutch) | and | /ɛn/ · conj |
| [in](https://en.wiktionary.org/wiki/in#Dutch) | in (expressing containment) | /ɪn/ · prep |
| [op](https://en.wiktionary.org/wiki/op#Dutch) | on; up (according to context) | /ɔp/ · prep |
| [ik](https://en.wiktionary.org/wiki/ik#Dutch) | I; first-person singular subjective personal pronoun | /ɪk/ · pron |
| [dat](https://en.wiktionary.org/wiki/dat#Dutch) | that, that there | /dɑt/ · pron |
| [voor](https://en.wiktionary.org/wiki/voor#Dutch) | for | /voːr/ · prep |
| [je](https://en.wiktionary.org/wiki/je#Dutch) | one, people, you, someone, anyone; an unspecified individual or group of individuals (as subject or object) | /jə/ · pron |
| [te](https://en.wiktionary.org/wiki/te#Dutch) | too (indicating excess) | /tə/ · adv |
| [met](https://en.wiktionary.org/wiki/met#Dutch) | with, along with (another person) | /mɛt/ · prep |
| [niet](https://en.wiktionary.org/wiki/niet#Dutch) | not, no, don't: used to express negation. | /nit/ · adv |
| [zijn](https://en.wiktionary.org/wiki/zijn#Dutch) | to be, to exist | /zɛi̯n/ · verb |
| [die](https://en.wiktionary.org/wiki/die#Dutch) | that; referring to a thing or a person further away. | /di/ · det |
| [er](https://en.wiktionary.org/wiki/er#Dutch) | there (can refer to any place, used when not emphasizing the distance to the speaker, see usage notes) | /ɛr/ · adv |
| [om](https://en.wiktionary.org/wiki/om#Dutch) | around, about | /ɔm/ · prep |
| [hij](https://en.wiktionary.org/wiki/hij#Dutch) | he; third-person singular masculine subjective personal pronoun | /ɦɛi̯/ · pron |
| [ook](https://en.wiktionary.org/wiki/ook#Dutch) | also, too, moreover | /oːk/ · adv |
| [door](https://en.wiktionary.org/wiki/door#Dutch) | through | /doːr/ · prep |
| [naar](https://en.wiktionary.org/wiki/naar#Dutch) | to, towards in time, space, consequence, purpose etc. | /naːr/ · prep |
| [bij](https://en.wiktionary.org/wiki/bij#Dutch) | at, with | /bɛi̯/ · prep |
| [dan](https://en.wiktionary.org/wiki/dan#Dutch) | then, at that time (in the future) | /dɑn/ · adv |
| [was](https://en.wiktionary.org/wiki/was#Dutch) | wash, washing, laundry (act of cleaning with water) | /ʋɑs/ · noun |
| [wat](https://en.wiktionary.org/wiki/wat#Dutch) | what: e.g. (1) asking for a subject complement; (2) asking for a sentence object | /ʋɑt/ · pron |
| [of](https://en.wiktionary.org/wiki/of#Dutch) | or | /ɔf/ · conj |
| [over](https://en.wiktionary.org/wiki/over#Dutch) | over, above | /ˈoː.vər/ · adv |
| [hebben](https://en.wiktionary.org/wiki/hebben#Dutch) | to have, to possess, own, hold | /ˈɦɛbə(n)/ · verb |
| [meer](https://en.wiktionary.org/wiki/meer#Dutch) | lake | /meːr/ · noun |
| [zo](https://en.wiktionary.org/wiki/zo#Dutch) | so, thus, like that/this | /zoː/ · adv |
| [al](https://en.wiktionary.org/wiki/al#Dutch) | all, all of | /ɑl/ · det |
| [mijn](https://en.wiktionary.org/wiki/mijn#Dutch) | my; first-person singular possessive determiner | /mɛi̯n/ · det |
| [tot](https://en.wiktionary.org/wiki/tot#Dutch) | to, up to | /tɔt/ · prep |
| [u](https://en.wiktionary.org/wiki/u#Dutch) | you (polite) | /y/ · pron |
| [worden](https://en.wiktionary.org/wiki/worden#Dutch) | to become, to get, to grow, to turn | /ˈʋɔrdə(n)/ · verb |
| [nu](https://en.wiktionary.org/wiki/nu#Dutch) | now, at the present moment | /ny/ · adv |
| [haar](https://en.wiktionary.org/wiki/haar#Dutch) | her; third-person singular feminine objective personal pronoun | /ɦaːr/ · pron |
| [kunnen](https://en.wiktionary.org/wiki/kunnen#Dutch) | can, to be able to | /ˈkʏnə(n)/ · verb |
| [me](https://en.wiktionary.org/wiki/me#Dutch) | myself; first-person singular reflexive pronoun | /mə/ · pron |
| [hoe](https://en.wiktionary.org/wiki/hoe#Dutch) | how | /ɦu/ · adv |
| [na](https://en.wiktionary.org/wiki/na#Dutch) | after | /naː/ · prep |
| [ons](https://en.wiktionary.org/wiki/ons#Dutch) | us; first-person plural objective personal pronoun | /ɔns/ · pron |
| [gaan](https://en.wiktionary.org/wiki/gaan#Dutch) | to go, to move from one place to another | [xaːn] · verb |
| [doen](https://en.wiktionary.org/wiki/doen#Dutch) | to do | /dun/ · verb |
| [hier](https://en.wiktionary.org/wiki/hier#Dutch) | here | /ɦir/ · adv |
| [hun](https://en.wiktionary.org/wiki/hun#Dutch) | their; third-person plural possessive determiner | /ɦʏn/ · det |
| [twee](https://en.wiktionary.org/wiki/twee#Dutch) | two | /tʋeː/ · num |
| [weer](https://en.wiktionary.org/wiki/weer#Dutch) | again, once more | /ʋeːr/ · adv |
| [zien](https://en.wiktionary.org/wiki/zien#Dutch) | to see | /zin/ · verb |

</details>

<details><summary>Words 51–100</summary>

![[Resources/Audio/nl/Words 0051-0100.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [jij](https://en.wiktionary.org/wiki/jij#Dutch) | you; second-person singular subjective personal pronoun | /jɛi̯/ · pron |
| [wij](https://en.wiktionary.org/wiki/wij#Dutch) | we; first-person plural subjective personal pronoun | /ʋɛi̯/ · pron |
| [echt](https://en.wiktionary.org/wiki/echt#Dutch) | authentic, true, genuine, real | /ɛxt/ · adj |
| [daar](https://en.wiktionary.org/wiki/daar#Dutch) | there | /daːr/ · adv |
| [heel](https://en.wiktionary.org/wiki/heel#Dutch) | complete, full, whole | /ɦeːl/ · adj |
| [dag](https://en.wiktionary.org/wiki/dag#Dutch) | day (period of 24 hours) | /dɑx/ · noun |
| [staat](https://en.wiktionary.org/wiki/staat#Dutch) | state (political entity) | /staːt/ · noun |
| [leven](https://en.wiktionary.org/wiki/leven#Dutch) | to live | /ˈleːvə(n)/ · verb |
| [hem](https://en.wiktionary.org/wiki/hem#Dutch) | him; third-person singular masculine objective personal pronoun | /ɦɛm/ · pron |
| [ja](https://en.wiktionary.org/wiki/ja#Dutch) | yes | /jaː/ · adv |
| [wie](https://en.wiktionary.org/wiki/wie#Dutch) | who, whom | /ʋi/ · pron |
| [er was eens](https://en.wiktionary.org/wiki/er%20was%20eens#Dutch) | once upon a time there was | /ɛr ˈʋɑs eːns/ · phrase |
| [net](https://en.wiktionary.org/wiki/net#Dutch) | net (mesh) | /nɛt/ · noun |
| [via](https://en.wiktionary.org/wiki/via#Dutch) | via, through, by way of | /ˈvi.aː/ · prep |
| [even](https://en.wiktionary.org/wiki/even#Dutch) | shortly, briefly | /ˈeː.və(n)/ · adv |
| [man](https://en.wiktionary.org/wiki/man#Dutch) | man, human male, either adult or age-irrespective | /mɑn/ · noun |
| [eigen](https://en.wiktionary.org/wiki/eigen#Dutch) | own, private (not shared) | /ˈɛi̯ɣə(n)/ · adj |
| [weg](https://en.wiktionary.org/wiki/weg#Dutch) | way, road | /ʋɛx/ · noun |
| [zit](https://en.wiktionary.org/wiki/zit#Dutch) | the act of sitting | /zɪt/ · noun |
| [drie](https://en.wiktionary.org/wiki/drie#Dutch) | three | /dri/ · num |
| [geven](https://en.wiktionary.org/wiki/geven#Dutch) | to give | /ˈɣeːvə(n)/ · verb |
| [toe](https://en.wiktionary.org/wiki/toe#Dutch) | due for, ready for, in need of | /tu/ · adv |
| [want](https://en.wiktionary.org/wiki/want#Dutch) | for, because, as | /ʋɑnt/ · conj |
| [erg](https://en.wiktionary.org/wiki/erg#Dutch) | serious, considerable, severe | /ɛrx/ · adj |
| [land](https://en.wiktionary.org/wiki/land#Dutch) | land, country, realm, territory | /lɑnt/ · noun |
| [naam](https://en.wiktionary.org/wiki/naam#Dutch) | name | /naːm/ · noun |
| [zullen](https://en.wiktionary.org/wiki/zullen#Dutch) | used to form the future tense of a verb, together with an infinitive; will, going to | /ˈzʏ.lə(n)/ · verb |
| [per](https://en.wiktionary.org/wiki/per#Dutch) | for each; for every; per | /pɛr/ · prep |
| [vandaag](https://en.wiktionary.org/wiki/vandaag#Dutch) | today | /vɑnˈdaːx/ · adv |
| [werken](https://en.wiktionary.org/wiki/werken#Dutch) | to work, labour | /ˈʋɛrkə(n)/ · verb |
| [nee](https://en.wiktionary.org/wiki/nee#Dutch) | no | /neː/ · intj |
| [kom](https://en.wiktionary.org/wiki/kom#Dutch) | bowl | /kɔm/ · noun |
| [paar](https://en.wiktionary.org/wiki/paar#Dutch) | pair, couple | /paːr/ · noun |
| [geld](https://en.wiktionary.org/wiki/geld#Dutch) | money | /ɣɛlt/ · noun |
| [kijken](https://en.wiktionary.org/wiki/kijken#Dutch) | to look | /ˈkɛi̯kə(n)/ · verb |
| [week](https://en.wiktionary.org/wiki/week#Dutch) | week, period of seven days | /ʋeːk/ · noun |
| [online](https://en.wiktionary.org/wiki/online#Dutch) | online (on, via or connected to the Internet or another network) | /ɔnˈlɑi̯n/ · adv |
| [moment](https://en.wiktionary.org/wiki/moment#Dutch) | moment (very brief period of time) | /moːˈmɛnt/ · noun |
| [eten](https://en.wiktionary.org/wiki/eten#Dutch) | to eat | /ˈeː.tə(n)/ · verb |
| [hoop](https://en.wiktionary.org/wiki/hoop#Dutch) | hope, aspiration, wish | /ɦoːp/ · noun |
| [men](https://en.wiktionary.org/wiki/men#Dutch) | one, you, they, everyone; humanity, (the) people, the public opinion | /mɛn/ · pron |
| [nou](https://en.wiktionary.org/wiki/nou#Dutch) | come on; modal particle indicating a certain degree of urgency or impatience on behalf of the speaker. | /nɑu̯/ · adv |
| [open](https://en.wiktionary.org/wiki/open#Dutch) | open, not closed | /ˈoː.pə(n)/ · adj |
| [later](https://en.wiktionary.org/wiki/later#Dutch) | having to do with or occurring in the future | /ˈlaː.tər/ · adj |
| [maart](https://en.wiktionary.org/wiki/maart#Dutch) | March | /maːrt/ · noun |
| [auto](https://en.wiktionary.org/wiki/auto#Dutch) | car, automobile | /ˈɑu̯.toː/ · noun |
| [school](https://en.wiktionary.org/wiki/school#Dutch) | a school, educational institution that provides education, whether combined with research or not | /sxoːl/ · noun |
| [den](https://en.wiktionary.org/wiki/den#Dutch) | pine, pine tree | /dɛn/ · noun |
| [film](https://en.wiktionary.org/wiki/film#Dutch) | a film, thin layer or membrane; especially the physical medium film | /fɪlm/ · noun |
| [spelen](https://en.wiktionary.org/wiki/spelen#Dutch) | to play | /ˈspeːlə(n)/ · verb |

</details>

<details><summary>Words 101–150</summary>

![[Resources/Audio/nl/Words 0101-0150.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [hen](https://en.wiktionary.org/wiki/hen#Dutch) | them; third-person plural objective personal pronoun | /ɦɛn/ · pron |
| [vier](https://en.wiktionary.org/wiki/vier#Dutch) | four | /vir/ · num |
| [zeg](https://en.wiktionary.org/wiki/zeg#Dutch) | hey, used to draw the addressed person's attention. | /zɛx/ · intj |
| [informatie](https://en.wiktionary.org/wiki/informatie#Dutch) | information | /ɪn.fɔrˈmaː.(t)si/ · noun |
| [pas](https://en.wiktionary.org/wiki/pas#Dutch) | just, recently | /pɑs/ · adv |
| [video](https://en.wiktionary.org/wiki/video#Dutch) | video, movie (regardless of medium) | /ˈvi.di.oː/ · noun |
| [vast](https://en.wiktionary.org/wiki/vast#Dutch) | firm, fast, tight | /vɑst/ · adj |
| [begin](https://en.wiktionary.org/wiki/begin#Dutch) | start, beginning | /bəˈɣɪn/ · noun |
| [vrij](https://en.wiktionary.org/wiki/vrij#Dutch) | free; not imprisoned or enslaved. | /vrɛi̯/ · adj |
| [best](https://en.wiktionary.org/wiki/best#Dutch) | fine, okay | /bɛst/ · adj |
| [leren](https://en.wiktionary.org/wiki/leren#Dutch) | to learn, to study | /ˈleːrə(n)/ · verb |
| [vijf](https://en.wiktionary.org/wiki/vijf#Dutch) | five | /vɛi̯f/ · num |
| [der](https://en.wiktionary.org/wiki/der#Dutch) | there | /dɛr/ · adv |
| [oktober](https://en.wiktionary.org/wiki/oktober#Dutch) | October (the tenth month of the Gregorian calendar, following September and preceding November) | /ˌɔkˈtoː.bər/ · noun |
| [hand](https://en.wiktionary.org/wiki/hand#Dutch) | a hand of a human, other simian or other animal with fingers | /ɦɑnt/ · noun |
| [horen](https://en.wiktionary.org/wiki/horen#Dutch) | to hear | /ˈɦoːrə(n)/ · verb |
| [ik zie u graag](https://en.wiktionary.org/wiki/ik%20zie%20u%20graag#Dutch) | I love you | [ɪk ˈsij‿y ˈɣraːx] · phrase |
| [muziek](https://en.wiktionary.org/wiki/muziek#Dutch) | music (sound; art) | /myˈzik/ · noun |
| [kind](https://en.wiktionary.org/wiki/kind#Dutch) | child, kid, non-adult human | /kɪnt/ · noun |
| [boek](https://en.wiktionary.org/wiki/boek#Dutch) | book | /buk/ · noun |
| [dank](https://en.wiktionary.org/wiki/dank#Dutch) | gratitude, thanks | /dɑŋk/ · noun |
| [gratis](https://en.wiktionary.org/wiki/gratis#Dutch) | free, without charge | /ˈɣraːtɪs/ · adj |
| [lekker](https://en.wiktionary.org/wiki/lekker#Dutch) | having a nice taste, tasty, delectable | /ˈlɛ.kər/ · adj |
| [team](https://en.wiktionary.org/wiki/team#Dutch) | team (group of people) | /tiːm/ · noun |
| [miljoen](https://en.wiktionary.org/wiki/miljoen#Dutch) | a million, 10⁶ | /mɪlˈjun/ · noun |
| [o](https://en.wiktionary.org/wiki/o#Dutch) | oh | /oː/ · intj |
| [top](https://en.wiktionary.org/wiki/top#Dutch) | top (uppermost part) | /tɔp/ · noun |
| [januari](https://en.wiktionary.org/wiki/januari#Dutch) | January | /ˌjɑ.nyˈ(ʋ)aː.ri/ · noun |
| [praten](https://en.wiktionary.org/wiki/praten#Dutch) | to talk | /ˈpraːtə(n)/ · verb |
| [recht](https://en.wiktionary.org/wiki/recht#Dutch) | straight | /rɛxt/ · adj |
| [wilde](https://en.wiktionary.org/wiki/wilde#Dutch) | savage, uncivilized person |  · noun |
| [zet](https://en.wiktionary.org/wiki/zet#Dutch) | shove, push | /zɛt/ · noun |
| [kamer](https://en.wiktionary.org/wiki/kamer#Dutch) | a bedroom | /ˈkaː.mər/ · noun |
| [volgen](https://en.wiktionary.org/wiki/volgen#Dutch) | to follow (go after) | /ˈvɔl.ɣə(n)/ · verb |
| [landen](https://en.wiktionary.org/wiki/landen#Dutch) | to (arrive on) land from the air (for birds, airplanes) | /ˈlɑn.də(n)/ · verb |
| [elk](https://en.wiktionary.org/wiki/elk#Dutch) | each; every | /ɛlk/ · det |
| [euro](https://en.wiktionary.org/wiki/euro#Dutch) | euro (currency) | /ˈøːroː/ · noun |
| [juli](https://en.wiktionary.org/wiki/juli#Dutch) | July |  · noun |
| [stuk](https://en.wiktionary.org/wiki/stuk#Dutch) | a piece, part, share (of a whole) | /stʏk/ · noun |
| [februari](https://en.wiktionary.org/wiki/februari#Dutch) | February | /ˌfeː.bryˈaː.ri/ · noun |
| [juni](https://en.wiktionary.org/wiki/juni#Dutch) | June (month) | /ˈjy.ni/ · noun |
| [zes](https://en.wiktionary.org/wiki/zes#Dutch) | six | /zɛs/ · num |
| [contact](https://en.wiktionary.org/wiki/contact#Dutch) | physical contact, touching | /kɔnˈtɑkt/ · noun |
| [lid](https://en.wiktionary.org/wiki/lid#Dutch) | member (of a group) | /lɪt/ · noun |
| [minister](https://en.wiktionary.org/wiki/minister#Dutch) | minister (a politician who heads a ministry) | /miˈnɪs.tər/ · noun |
| [hart](https://en.wiktionary.org/wiki/hart#Dutch) | heart, main muscle pumping blood through the body | /ɦɑrt/ · noun |
| [tien](https://en.wiktionary.org/wiki/tien#Dutch) | ten | /tin/ · num |
| [rest](https://en.wiktionary.org/wiki/rest#Dutch) | rest (that which remains) | /rɛst/ · noun |
| [bang](https://en.wiktionary.org/wiki/bang#Dutch) | scared, frightened | /bɑŋ/ · adj |
| [direct](https://en.wiktionary.org/wiki/direct#Dutch) | direct, immediate | /diˈrɛkt/ · adj |

</details>

<details><summary>Words 151–200</summary>

![[Resources/Audio/nl/Words 0151-0200.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [god](https://en.wiktionary.org/wiki/god#Dutch) | god, deity | /ɣɔt/ · noun |
| [oh](https://en.wiktionary.org/wiki/oh#Dutch) | oh | /oː/ · intj |
| [plan](https://en.wiktionary.org/wiki/plan#Dutch) | a set of intended actions, through which one expects to achieve a goal: plan, plot, scheme | /plɑn/ · noun |
| [president](https://en.wiktionary.org/wiki/president#Dutch) | president | /preː.ziˈdɛnt/ · noun |
| [basis](https://en.wiktionary.org/wiki/basis#Dutch) | basis (principle, foundation, that which is elementary) | /ˈbaː.zəs/ · noun |
| [enkel](https://en.wiktionary.org/wiki/enkel#Dutch) | single | /ˈɛŋ.kəl/ · adj |
| [ik hou van jou](https://en.wiktionary.org/wiki/ik%20hou%20van%20jou#Dutch) | I love you |  · phrase |
| [project](https://en.wiktionary.org/wiki/project#Dutch) | project (planned endeavor) | /proːˈjɛkt/ · noun |
| [extra](https://en.wiktionary.org/wiki/extra#Dutch) | extra | /ˈɛks.traː/ · adv |
| [vallen](https://en.wiktionary.org/wiki/vallen#Dutch) | to fall, to tumble | /ˈvɑlə(n)/ · verb |
| [hard](https://en.wiktionary.org/wiki/hard#Dutch) | hard, strong | /ɦɑrt/ · adj |
| [links](https://en.wiktionary.org/wiki/links#Dutch) | on the left | /lɪŋks/ · adv |
| [meter](https://en.wiktionary.org/wiki/meter#Dutch) | meter (device that measures things or indicates a physical quantity) | /ˈmeːtər/ · noun |
| [ver](https://en.wiktionary.org/wiki/ver#Dutch) | far | /vɛr/ · adv |
| [wet](https://en.wiktionary.org/wiki/wet#Dutch) | law (rule) | /ʋɛt/ · noun |
| [boeken](https://en.wiktionary.org/wiki/boeken#Dutch) | to book, to reserve | /ˈbu.kə(n)/ · verb |
| [kleur](https://en.wiktionary.org/wiki/kleur#Dutch) | a color, colour | /kløːr/ · noun |
| [site](https://en.wiktionary.org/wiki/site#Dutch) | web site | /sɑi̯t/ · noun |
| [bed](https://en.wiktionary.org/wiki/bed#Dutch) | bed (furniture for sleeping) | /bɛt/ · noun |
| [leger](https://en.wiktionary.org/wiki/leger#Dutch) | army, armed forces | /ˈleː.ɣər/ · noun |
| [los](https://en.wiktionary.org/wiki/los#Dutch) | loose | /lɔs/ · adj |
| [stem](https://en.wiktionary.org/wiki/stem#Dutch) | voice, sound made by the mouth using airflow | /stɛm/ · noun |
| [club](https://en.wiktionary.org/wiki/club#Dutch) | club (an association of members joining together for some common purpose, especially sports or recreation) | /klʏp/ · noun |
| [la](https://en.wiktionary.org/wiki/la#Dutch) | drawer | /laː/ · noun |
| [link](https://en.wiktionary.org/wiki/link#Dutch) | dangerous | /lɪŋk/ · adj |
| [Nederlands](https://en.wiktionary.org/wiki/Nederlands#Dutch) | of the Netherlands; Dutch, Netherlandish | /ˈneː.dərˌlɑnts/ · adj |
| [live](https://en.wiktionary.org/wiki/live#Dutch) | live, being broadcast as it happens. | /lɑjf/ · adj |
| [on](https://en.wiktionary.org/wiki/on#Dutch) | rarely used as shorthand for oneven (odd), the prefix on- means not (corresponds to English un-) |  · adv |
| [zee](https://en.wiktionary.org/wiki/zee#Dutch) | sea | /zeː/ · noun |
| [reis](https://en.wiktionary.org/wiki/reis#Dutch) | travel | /rɛi̯s/ · noun |
| [slapen](https://en.wiktionary.org/wiki/slapen#Dutch) | to sleep | /ˈslaː.pə(n)/ · verb |
| [start](https://en.wiktionary.org/wiki/start#Dutch) | start | /stɑrt/ · noun |
| [acht](https://en.wiktionary.org/wiki/acht#Dutch) | eight | /ɑxt/ · num |
| [half](https://en.wiktionary.org/wiki/half#Dutch) | half | /ɦɑlf/ · adj |
| [lekker belangrijk](https://en.wiktionary.org/wiki/lekker%20belangrijk#Dutch) | literally: nicely important (ironical), hence: not interesting or not important |  · phrase |
| [rust](https://en.wiktionary.org/wiki/rust#Dutch) | rest, calm, peace | /rʏst/ · noun |
| [bank](https://en.wiktionary.org/wiki/bank#Dutch) | bench | /bɑŋk/ · noun |
| [les](https://en.wiktionary.org/wiki/les#Dutch) | course, lesson | /lɛs/ · noun |
| [pagina](https://en.wiktionary.org/wiki/pagina#Dutch) | page | /ˈpaːɣinaː/ · noun |
| [sorry](https://en.wiktionary.org/wiki/sorry#Dutch) | sorry (expressing regret) | /ˈsɔ.ri/ · intj |
| [voelen](https://en.wiktionary.org/wiki/voelen#Dutch) | to feel, to have sensation of | /ˈvulə(n)/ · verb |
| [zeven](https://en.wiktionary.org/wiki/zeven#Dutch) | seven | /ˈzeː.və(n)/ · num |
| [west](https://en.wiktionary.org/wiki/west#Dutch) | west | /ʋɛst/ · adv |
| [heet](https://en.wiktionary.org/wiki/heet#Dutch) | hot (very warm) | /ɦeːt/ · adj |
| [radio](https://en.wiktionary.org/wiki/radio#Dutch) | radio, tuner | /ˈraː.di.(j)oː/ · noun |
| [blog](https://en.wiktionary.org/wiki/blog#Dutch) | blog | /blɔx/ · noun |
| [slag](https://en.wiktionary.org/wiki/slag#Dutch) | a blow, knock, strike | /slɑx/ · noun |
| [hotel](https://en.wiktionary.org/wiki/hotel#Dutch) | hotel | /ɦoːˈtɛl/ · noun |
| [wit](https://en.wiktionary.org/wiki/wit#Dutch) | white | /ʋɪt/ · adj |
| [zomer](https://en.wiktionary.org/wiki/zomer#Dutch) | summer | /ˈzoːmər/ · noun |

</details>

<details><summary>Words 201–250</summary>

![[Resources/Audio/nl/Words 0201-0250.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [fout](https://en.wiktionary.org/wiki/fout#Dutch) | error, mistake | /fɑu̯t/ · noun |
| [val](https://en.wiktionary.org/wiki/val#Dutch) | a fall (act or event of falling) | /vɑl/ · noun |
| [brand](https://en.wiktionary.org/wiki/brand#Dutch) | destructive, catastrophic fire (such as a house fire) | /brɑnt/ · noun |
| [park](https://en.wiktionary.org/wiki/park#Dutch) | park | /pɑrk/ · noun |
| [sport](https://en.wiktionary.org/wiki/sport#Dutch) | a sport; (uncountable) sports | /spɔrt/ · noun |
| [Engels](https://en.wiktionary.org/wiki/Engels#Dutch) | English | /ˈɛŋəls/ · adj |
| [stop](https://en.wiktionary.org/wiki/stop#Dutch) | an action of stopping, cessation | /stɔp/ · noun |
| [super](https://en.wiktionary.org/wiki/super#Dutch) | very, extremely, super | /ˈsy.pər/ · adv |
| [trekken](https://en.wiktionary.org/wiki/trekken#Dutch) | to pull, to draw | /ˈtrɛkə(n)/ · verb |
| [aarde](https://en.wiktionary.org/wiki/aarde#Dutch) | earth, soil, ground | /ˈaːr.də/ · noun |
| [band](https://en.wiktionary.org/wiki/band#Dutch) | bond, connection, relationship, liaison, tie (attachment, as in a relation) | /bɑnt/ · noun |
| [g](https://en.wiktionary.org/wiki/g#Dutch) | The seventh letter of the Dutch alphabet, written in the Latin script. | /ɣeː/ · noun |
| [hond](https://en.wiktionary.org/wiki/hond#Dutch) | dog (Canis lupus familiaris) | /ɦɔnt/ · noun |
| [wees](https://en.wiktionary.org/wiki/wees#Dutch) | an orphan, person or animal having survived both parents | /ʋeːs/ · noun |
| [deur](https://en.wiktionary.org/wiki/deur#Dutch) | door | /døːr/ · noun |
| [stand](https://en.wiktionary.org/wiki/stand#Dutch) | posture, position, bearing | /stɑnt/ · noun |
| [kilometer](https://en.wiktionary.org/wiki/kilometer#Dutch) | kilometre | /ˈkiloːˌmeːtər/ · noun |
| [drinken](https://en.wiktionary.org/wiki/drinken#Dutch) | to drink, consume a liquid | /ˈdrɪŋkə(n)/ · verb |
| [zon](https://en.wiktionary.org/wiki/zon#Dutch) | sun, Sun | /zɔn/ · noun |
| [festival](https://en.wiktionary.org/wiki/festival#Dutch) | a festival (festive event or gathering) | /ˈfɛs.tiˌvɑl/ · noun |
| [last](https://en.wiktionary.org/wiki/last#Dutch) | load, weight | /lɑst/ · noun |
| [perfect](https://en.wiktionary.org/wiki/perfect#Dutch) | perfect | /pɛrˈfɛkt/ · adj |
| [respect](https://en.wiktionary.org/wiki/respect#Dutch) | respect | /rɛsˈpɛkt/ · noun |
| [schade](https://en.wiktionary.org/wiki/schade#Dutch) | damage, detrimental effect | /ˈsxaː.də/ · noun |
| [baby](https://en.wiktionary.org/wiki/baby#Dutch) | baby (infant) | /ˈbeːbi/ · noun |
| [brief](https://en.wiktionary.org/wiki/brief#Dutch) | letter (written message) | /brif/ · noun |
| [bus](https://en.wiktionary.org/wiki/bus#Dutch) | bus, omnibus (vehicle) | /bʏs/ · noun |
| [luisteren](https://en.wiktionary.org/wiki/luisteren#Dutch) | to listen | /ˈlœy̯stərə(n)/ · verb |
| [gang](https://en.wiktionary.org/wiki/gang#Dutch) | passageway, alley | /ˈɣɑŋ/ · noun |
| [mond](https://en.wiktionary.org/wiki/mond#Dutch) | mouth | /mɔnt/ · noun |
| [oog](https://en.wiktionary.org/wiki/oog#Dutch) | eye | /oːx/ · noun |
| [winkel](https://en.wiktionary.org/wiki/winkel#Dutch) | shop, store (establishment that sells goods to the public) | /ˈʋɪŋ.kəl/ · noun |
| [Spaanse](https://en.wiktionary.org/wiki/Spaanse#Dutch) | female Spanish person |  · noun |
| [weekend](https://en.wiktionary.org/wiki/weekend#Dutch) | weekend | /ˈʋikɛnt/ · noun |
| [bel](https://en.wiktionary.org/wiki/bel#Dutch) | bell | /bɛl/ · noun |
| [help](https://en.wiktionary.org/wiki/help#Dutch) | help! | /ɦɛlp/ · intj |
| [mama](https://en.wiktionary.org/wiki/mama#Dutch) | mama, mother | /ˈmɑmaː/ · noun |
| [slaan](https://en.wiktionary.org/wiki/slaan#Dutch) | to hit, to slap | /slaːn/ · verb |
| [ex](https://en.wiktionary.org/wiki/ex#Dutch) | ex (former partner) | /ɛks/ · noun |
| [frank](https://en.wiktionary.org/wiki/frank#Dutch) | frank, candid, blunt, open-hearted | /frɑŋk/ · adj |
| [show](https://en.wiktionary.org/wiki/show#Dutch) | a show (entertainment) | /ʃoː/ · noun |
| [trein](https://en.wiktionary.org/wiki/trein#Dutch) | train (railway vehicle) | /trɛi̯n/ · noun |
| [type](https://en.wiktionary.org/wiki/type#Dutch) | type: a class, someone or something from a class. The diminutive is used when made into a caricature | /ˈti.pə/ · noun |
| [warm](https://en.wiktionary.org/wiki/warm#Dutch) | warm, hot | /ʋɑr(ə)m/ · adj |
| [bos](https://en.wiktionary.org/wiki/bos#Dutch) | wood, forest | /bɔs/ · noun |
| [rechts](https://en.wiktionary.org/wiki/rechts#Dutch) | on the right | /rɛxts/ · adv |
| [rood](https://en.wiktionary.org/wiki/rood#Dutch) | red | /roːt/ · adj |
| [san](https://en.wiktionary.org/wiki/san#Dutch) | san (archaic Greek letter) |  · noun |
| [station](https://en.wiktionary.org/wiki/station#Dutch) | station (place for vehicles to stop) | /staːˈʃɔn/ · noun |
| [wapen](https://en.wiktionary.org/wiki/wapen#Dutch) | weapon | /ˈʋaː.pə(n)/ · noun |

</details>

<details><summary>Words 251–300</summary>

![[Resources/Audio/nl/Words 0251-0300.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [angst](https://en.wiktionary.org/wiki/angst#Dutch) | fear, fright, anxiety | /ɑŋst/ · noun |
| [bureau](https://en.wiktionary.org/wiki/bureau#Dutch) | desk | /byˈroː/ · noun |
| [camera](https://en.wiktionary.org/wiki/camera#Dutch) | camera | /ˈkaː.mə.raː/ · noun |
| [leek](https://en.wiktionary.org/wiki/leek#Dutch) | layman, non-clergyman | /leːk/ · noun |
| [muur](https://en.wiktionary.org/wiki/muur#Dutch) | wall | /myr/ · noun |
| [Westen](https://en.wiktionary.org/wiki/Westen#Dutch) | the West |  · noun |
| [finale](https://en.wiktionary.org/wiki/finale#Dutch) | a final, e.g. the end-round in a competition | /fiˈnaːlə/ · noun |
| [groen](https://en.wiktionary.org/wiki/groen#Dutch) | green | /ɣrun/ · adj |
| [hallo](https://en.wiktionary.org/wiki/hallo#Dutch) | hello (a general greeting used when meeting somebody) | /ɦɑˈloː/ · intj |
| [model](https://en.wiktionary.org/wiki/model#Dutch) | model (type, design) | /moːˈdɛl/ · noun |
| [premier](https://en.wiktionary.org/wiki/premier#Dutch) | prime minister | /prəˈmjeː/ · noun |
| [dollar](https://en.wiktionary.org/wiki/dollar#Dutch) | dollar (currency, especially the US dollar) | /ˈdɔlɑr/ · noun |
| [redden](https://en.wiktionary.org/wiki/redden#Dutch) | to save, rescue | /ˈrɛ.də(n)/ · verb |
| [college](https://en.wiktionary.org/wiki/college#Dutch) | a collegial board, either advisory (committee) or as an authority | /ˌkɔˈleː.ʒə/ · noun |
| [teken](https://en.wiktionary.org/wiki/teken#Dutch) | sign, indication, mark | /ˈteː.kə(n)/ · noun |
| [account](https://en.wiktionary.org/wiki/account#Dutch) | a subscription to an electronic service | /ɑˈkɑu̯nt/ · noun |
| [wind](https://en.wiktionary.org/wiki/wind#Dutch) | wind (movement of air) | /ʋɪnt/ · noun |
| [Chinese](https://en.wiktionary.org/wiki/Chinese#Dutch) | woman from China | /ʃiˈneː.sə/ · noun |
| [pro](https://en.wiktionary.org/wiki/pro#Dutch) | pro (advantage of something) | /proː/ · noun |
| [album](https://en.wiktionary.org/wiki/album#Dutch) | album (book of photographs, stamps, or autographs) | /ˈɑl.bʏm/ · noun |
| [lief](https://en.wiktionary.org/wiki/lief#Dutch) | nice, sweet, lovely | /lif/ · adj |
| [negen](https://en.wiktionary.org/wiki/negen#Dutch) | nine | /ˈneː.ɣə(n)/ · num |
| [strand](https://en.wiktionary.org/wiki/strand#Dutch) | beach, strand | /strɑnt/ · noun |
| [code](https://en.wiktionary.org/wiki/code#Dutch) | book or body of laws, code of laws, lawbook | /ˈkoː.də/ · noun |
| [leer](https://en.wiktionary.org/wiki/leer#Dutch) | leather | /leːr/ · noun |
| [partner](https://en.wiktionary.org/wiki/partner#Dutch) | partner, love interest, romantic and/or sexual companion | /ˈpɑrt.nər/ · noun |
| [regen](https://en.wiktionary.org/wiki/regen#Dutch) | rain | /ˈreː.ɣə(n)/ · noun |
| [bal](https://en.wiktionary.org/wiki/bal#Dutch) | a ball or any object with such a shape | /bɑl/ · noun |
| [boom](https://en.wiktionary.org/wiki/boom#Dutch) | tree | /boːm/ · noun |
| [des](https://en.wiktionary.org/wiki/des#Dutch) | D-flat | /dɛs/ · noun |
| [parlement](https://en.wiktionary.org/wiki/parlement#Dutch) | parliament | /ˌpɑr.ləˈmɛnt/ · noun |
| [vliegen](https://en.wiktionary.org/wiki/vliegen#Dutch) | to fly | /ˈvli.ɣə(n)/ · verb |
| [arts](https://en.wiktionary.org/wiki/arts#Dutch) | physician, doctor | /ɑrts/ · noun |
| [storm](https://en.wiktionary.org/wiki/storm#Dutch) | storm; a wind scale for very strong wind, stronger than a gale, less than a hurricane | /stɔrm/ · noun |
| [bergen](https://en.wiktionary.org/wiki/bergen#Dutch) | to store, to stash away | /ˈbɛrɣə(n)/ · verb |
| [bloed](https://en.wiktionary.org/wiki/bloed#Dutch) | blood | /blut/ · noun |
| [contract](https://en.wiktionary.org/wiki/contract#Dutch) | contract | /kɔnˈtrɑkt/ · noun |
| [baas](https://en.wiktionary.org/wiki/baas#Dutch) | boss, chief, superior | /baːs/ · noun |
| [duur](https://en.wiktionary.org/wiki/duur#Dutch) | expensive, dear | /dyr/ · adj |
| [voedsel](https://en.wiktionary.org/wiki/voedsel#Dutch) | food | /ˈvut.səl/ · noun |
| [bad](https://en.wiktionary.org/wiki/bad#Dutch) | bath (object) | /bɑt/ · noun |
| [thee](https://en.wiktionary.org/wiki/thee#Dutch) | tea | /teː/ · noun |
| [twintig](https://en.wiktionary.org/wiki/twintig#Dutch) | twenty | /ˈtʋɪn.təx/ · num |
| [zagen](https://en.wiktionary.org/wiki/zagen#Dutch) | to saw | /ˈzaːɣə(n)/ · verb |
| [as](https://en.wiktionary.org/wiki/as#Dutch) | ash | /ɑs/ · noun |
| [boot](https://en.wiktionary.org/wiki/boot#Dutch) | boat | /boːt/ · noun |
| [gast](https://en.wiktionary.org/wiki/gast#Dutch) | guest | /ɣɑst/ · noun |
| [pad](https://en.wiktionary.org/wiki/pad#Dutch) | path (narrow road, usually unpaved) | /pɑt/ · noun |
| [restaurant](https://en.wiktionary.org/wiki/restaurant#Dutch) | restaurant | /rɛstoːˈrɑnt/ · noun |
| [test](https://en.wiktionary.org/wiki/test#Dutch) | test | /tɛst/ · noun |

</details>

<details><summary>Words 301–350</summary>

![[Resources/Audio/nl/Words 0301-0350.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [voornamelijk](https://en.wiktionary.org/wiki/voornamelijk#Dutch) | mainly, mostly; predominantly |  · adv |
| [winter](https://en.wiktionary.org/wiki/winter#Dutch) | winter | /ˈʋɪn.tər/ · noun |
| [berg](https://en.wiktionary.org/wiki/berg#Dutch) | mountain, hill | /bɛrx/ · noun |
| [bier](https://en.wiktionary.org/wiki/bier#Dutch) | beer (alcoholic drink brewed from grains or other starch material) | /bir/ · noun |
| [computer](https://en.wiktionary.org/wiki/computer#Dutch) | computer | /kɔmˈpjutər/ · noun |
| [dame](https://en.wiktionary.org/wiki/dame#Dutch) | noblewoman | /ˈdaː.mə/ · noun |
| [effect](https://en.wiktionary.org/wiki/effect#Dutch) | effect | /ɛˈfɛkt/ · noun |
| [ton](https://en.wiktionary.org/wiki/ton#Dutch) | barrel | /tɔn/ · noun |
| [arm](https://en.wiktionary.org/wiki/arm#Dutch) | arm | /ɑrm/ · noun |
| [dom](https://en.wiktionary.org/wiki/dom#Dutch) | dumb, brainless | /dɔm/ · adj |
| [gent](https://en.wiktionary.org/wiki/gent#Dutch) | bird of the Sulidae family | /ɣɛnt/ · noun |
| [pers](https://en.wiktionary.org/wiki/pers#Dutch) | a press, mechanical device to exert pression | /pɛrs/ · noun |
| [professor](https://en.wiktionary.org/wiki/professor#Dutch) | professor | /ˌproːˈfɛ.sɔr/ · noun |
| [route](https://en.wiktionary.org/wiki/route#Dutch) | route, course, way (particular pathway or direction one travels) | /ˈru.tə/ · noun |
| [service](https://en.wiktionary.org/wiki/service#Dutch) | service |  · noun |
| [vis](https://en.wiktionary.org/wiki/vis#Dutch) | fish (aquatic organism) | /vɪs/ · noun |
| [vliegtuig](https://en.wiktionary.org/wiki/vliegtuig#Dutch) | aeroplane, winged aircraft | /ˈvlix.tœy̯x/ · noun |
| [Duits](https://en.wiktionary.org/wiki/Duits#Dutch) | German | /dœy̯ts/ · adj |
| [concert](https://en.wiktionary.org/wiki/concert#Dutch) | concert (musical entertainment) | /kɔnˈsɛrt/ · noun |
| [date](https://en.wiktionary.org/wiki/date#Dutch) | a date (romantic outing) | /deːt/ · noun |
| [golf](https://en.wiktionary.org/wiki/golf#Dutch) | wave | /ɣɔlf/ · noun |
| [las](https://en.wiktionary.org/wiki/las#Dutch) | joint, weld |  · noun |
| [milieu](https://en.wiktionary.org/wiki/milieu#Dutch) | environment | /mɪlˈjøː/ · noun |
| [slim](https://en.wiktionary.org/wiki/slim#Dutch) | intelligent, bright | /slɪm/ · adj |
| [tour](https://en.wiktionary.org/wiki/tour#Dutch) | tour (journey through a particular building, estate, country, etc.) | /tur/ · noun |
| [big](https://en.wiktionary.org/wiki/big#Dutch) | piglet, little pig | /bɪx/ · noun |
| [gezellig](https://en.wiktionary.org/wiki/gezellig#Dutch) | having an inviting and friendly ambiance; cosy, nice, pleasant, sociable, convivial | /ɣəˈzɛ.ləx/ · adj |
| [product](https://en.wiktionary.org/wiki/product#Dutch) | product | /proːˈdʏkt/ · noun |
| [game](https://en.wiktionary.org/wiki/game#Dutch) | a video game, an electronic game | /ɡeːm/ · noun |
| [ma](https://en.wiktionary.org/wiki/ma#Dutch) | mother | /maː/ · noun |
| [neus](https://en.wiktionary.org/wiki/neus#Dutch) | nose | /nøːs/ · noun |
| [shit](https://en.wiktionary.org/wiki/shit#Dutch) | shit, darn | /ʃɪt/ · intj |
| [slot](https://en.wiktionary.org/wiki/slot#Dutch) | lock (something used for fastening) | /slɔt/ · noun |
| [trap](https://en.wiktionary.org/wiki/trap#Dutch) | stairs, staircase | /trɑp/ · noun |
| [coach](https://en.wiktionary.org/wiki/coach#Dutch) | trainer, instructor, tutor, coach | /koːtʃ/ · noun |
| [datum](https://en.wiktionary.org/wiki/datum#Dutch) | date (point in time) | /ˈdaːtʏm/ · noun |
| [leg](https://en.wiktionary.org/wiki/leg#Dutch) | The act or process of laying something, particularly eggs. | /lɛx/ · noun |
| [platform](https://en.wiktionary.org/wiki/platform#Dutch) | a platform, flat surface, notably a dais or stage | /ˈplɑt.fɔrm/ · noun |
| [sexy](https://en.wiktionary.org/wiki/sexy#Dutch) | sexy | /ˈsɛk.si/ · adj |
| [studio](https://en.wiktionary.org/wiki/studio#Dutch) | a studio flat/apartment | /ˈstydioː/ · noun |
| [tas](https://en.wiktionary.org/wiki/tas#Dutch) | bag | /tɑs/ · noun |
| [twaalf](https://en.wiktionary.org/wiki/twaalf#Dutch) | twelve | /tʋaːl(ə)f/ · num |
| [bob](https://en.wiktionary.org/wiki/bob#Dutch) | bob, bobsleigh | /bɔp/ · noun |
| [brood](https://en.wiktionary.org/wiki/brood#Dutch) | bread | /broːt/ · noun |
| [burger](https://en.wiktionary.org/wiki/burger#Dutch) | citizen, civilian | /ˈbʏr.ɣər/ · noun |
| [jack](https://en.wiktionary.org/wiki/jack#Dutch) | jacket |  · noun |
| [ring](https://en.wiktionary.org/wiki/ring#Dutch) | ring, hollow circular object | /rɪŋ/ · noun |
| [trainer](https://en.wiktionary.org/wiki/trainer#Dutch) | trainer |  · noun |
| [begrip](https://en.wiktionary.org/wiki/begrip#Dutch) | understanding, comprehension | /bəˈɣrɪp/ · noun |
| [benen](https://en.wiktionary.org/wiki/benen#Dutch) | made of bone | /ˈbeːnə(n)/ · adj |

</details>

<details><summary>Words 351–400</summary>

![[Resources/Audio/nl/Words 0351-0400.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [crisis](https://en.wiktionary.org/wiki/crisis#Dutch) | crisis | /ˈkri.zɪs/ · noun |
| [data](https://en.wiktionary.org/wiki/data#Dutch) | data, information |  · noun |
| [held](https://en.wiktionary.org/wiki/held#Dutch) | hero | /ɦɛlt/ · noun |
| [homo](https://en.wiktionary.org/wiki/homo#Dutch) | gay, homosexual | /ˈɦoː.moː/ · noun |
| [race](https://en.wiktionary.org/wiki/race#Dutch) | a speed contest, a race | /reːs/ · noun |
| [single](https://en.wiktionary.org/wiki/single#Dutch) | a single (short music record, e.g. 45 RPM vinyl with an A side and a B side; main track of such a record) | /ˈsɪŋ.əl/ · noun |
| [zak](https://en.wiktionary.org/wiki/zak#Dutch) | sack or sack-like container, such as a bag, sachet, pouch | /zɑk/ · noun |
| [Spaans](https://en.wiktionary.org/wiki/Spaans#Dutch) | Spanish | /spaːns/ · adj |
| [bar](https://en.wiktionary.org/wiki/bar#Dutch) | a bar, counter, drink cabinet | /bɑr/ · noun |
| [dik](https://en.wiktionary.org/wiki/dik#Dutch) | thick | /dɪk/ · adj |
| [info](https://en.wiktionary.org/wiki/info#Dutch) | info, information | /ˈɪn.foː/ · noun |
| [kat](https://en.wiktionary.org/wiki/kat#Dutch) | domestic cat, pussy, Felis silvestris catus | /kɑt/ · noun |
| [kies](https://en.wiktionary.org/wiki/kies#Dutch) | molar | /kis/ · noun |
| [manager](https://en.wiktionary.org/wiki/manager#Dutch) | a manager, someone in management | /ˈmɛ.nə.dʒər/ · noun |
| [steen](https://en.wiktionary.org/wiki/steen#Dutch) | stone (small rock) | /steːn/ · noun |
| [high](https://en.wiktionary.org/wiki/high#Dutch) | high (intoxicated with a drug other than alcohol) | /ɦɑi̯/ · adj |
| [non](https://en.wiktionary.org/wiki/non#Dutch) | nun | /nɔn/ · noun |
| [papa](https://en.wiktionary.org/wiki/papa#Dutch) | dad (term of address for one’s father, especially used by young children) | /ˈpɑ.paː/ · noun |
| [aanvallen](https://en.wiktionary.org/wiki/aanvallen#Dutch) | to attack | /ˈaːnvɑlə(n)/ · verb |
| [been](https://en.wiktionary.org/wiki/been#Dutch) | leg, limb of a person, horse (other animals would have poten) and certain objects (again many have poten) | /beːn/ · noun |
| [dier](https://en.wiktionary.org/wiki/dier#Dutch) | animal (any member of the kingdom Animalia) | /dir/ · noun |
| [machine](https://en.wiktionary.org/wiki/machine#Dutch) | machine (mechanical or electrical device) | /mɑˈʃin(ə)/ · noun |
| [shirt](https://en.wiktionary.org/wiki/shirt#Dutch) | a T-shirt or other shirt, typically including undershirts | /ʃʏrt/ · noun |
| [term](https://en.wiktionary.org/wiki/term#Dutch) | term; a word or phrase, especially one from a specialised area of knowledge | /tɛrm/ · noun |
| [agenda](https://en.wiktionary.org/wiki/agenda#Dutch) | a calendar (book), a diary, a booklet or other device where one notes down one’s schedule, appointments etc. | /ɑˈɣɛn.daː/ · noun |
| [agent](https://en.wiktionary.org/wiki/agent#Dutch) | a police officer | /aːˈɣɛnt/ · noun |
| [war](https://en.wiktionary.org/wiki/war#Dutch) | confusion, disarray | /ʋɑr/ · noun |
| [T-shirt](https://en.wiktionary.org/wiki/T-shirt#Dutch) | T-shirt | /ˈti.ʃərt/ · noun |
| [breed](https://en.wiktionary.org/wiki/breed#Dutch) | broad, wide | /breːt/ · adj |
| [do](https://en.wiktionary.org/wiki/do#Dutch) | do, the musical note | /doː/ · noun |
| [gas](https://en.wiktionary.org/wiki/gas#Dutch) | gas | /ɣɑs/ · noun |
| [kim](https://en.wiktionary.org/wiki/kim#Dutch) | horizon | /kɪm/ · noun |
| [dans](https://en.wiktionary.org/wiki/dans#Dutch) | dance | /dɑns/ · noun |
| [lot](https://en.wiktionary.org/wiki/lot#Dutch) | destiny, fate, lot | /lɔt/ · noun |
| [qua](https://en.wiktionary.org/wiki/qua#Dutch) | regarding, concerning, in terms of |  · prep |
| [talent](https://en.wiktionary.org/wiki/talent#Dutch) | talent (gift, quality, capability) | /taːˈlɛnt/ · noun |
| [toilet](https://en.wiktionary.org/wiki/toilet#Dutch) | toilet, bathroom (room containing a lavatory) | /tʋaːˈlɛt/ · noun |
| [boeren](https://en.wiktionary.org/wiki/boeren#Dutch) | to farm, practice agriculture | /ˈbu.rə(n)/ · verb |
| [hout](https://en.wiktionary.org/wiki/hout#Dutch) | wood (material) | /ɦɑu̯t/ · noun |
| [humor](https://en.wiktionary.org/wiki/humor#Dutch) | humour (sense of amusement) | /ˈɦymɔr/ · noun |
| [privacy](https://en.wiktionary.org/wiki/privacy#Dutch) | privacy | /ˈpraːi̯.vəˌsi/ · noun |
| [rand](https://en.wiktionary.org/wiki/rand#Dutch) | edge, brink, rim | /rɑnt/ · noun |
| [cup](https://en.wiktionary.org/wiki/cup#Dutch) | cup (trophy) | /kʏp/ · noun |
| [go](https://en.wiktionary.org/wiki/go#Dutch) | go | /ɡoː/ · noun |
| [student](https://en.wiktionary.org/wiki/student#Dutch) | a student at an institute for academic tertiary education | /styˈdɛnt/ · noun |
| [virus](https://en.wiktionary.org/wiki/virus#Dutch) | virus | /ˈviː.rʏs/ · noun |
| [cool](https://en.wiktionary.org/wiki/cool#Dutch) | cool, fashionable | /kul/ · adj |
| [lied](https://en.wiktionary.org/wiki/lied#Dutch) | song | /lit/ · noun |
| [logo](https://en.wiktionary.org/wiki/logo#Dutch) | logo (visual symbol or emblem that acts as a trademark or a means of identification of a company or organization.) | /ˈloː.ɣoː/ · noun |
| [papier](https://en.wiktionary.org/wiki/papier#Dutch) | paper (A material used for writing or printing on, made from cellulose pulp rolled into thin sheets.) | /paːˈpiːr/ · noun |

</details>

<details><summary>Words 401–450</summary>

![[Resources/Audio/nl/Words 0401-0450.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [analyse](https://en.wiktionary.org/wiki/analyse#Dutch) | analysis (action of taking something apart to study it) | /aːnaːˈliːzə/ · noun |
| [café](https://en.wiktionary.org/wiki/caf%C3%A9#Dutch) | café; coffee shop | /kaːˈfeː/ · noun |
| [content](https://en.wiktionary.org/wiki/content#Dutch) | content(ed), satisfied | /kɔnˈtɛnt/ · adj |
| [magazine](https://en.wiktionary.org/wiki/magazine#Dutch) | magazine (periodical publication) | /ˈmɛ.ɡəˌziːn/ · noun |
| [mist](https://en.wiktionary.org/wiki/mist#Dutch) | fog, mist | /mɪst/ · noun |
| [party](https://en.wiktionary.org/wiki/party#Dutch) | party; a social gathering for celebration or fun, often in a nightlife setting. |  · noun |
| [plastic](https://en.wiktionary.org/wiki/plastic#Dutch) | plastic (synthetic polymer substance) | /ˈplɛs.tɪk/ · noun |
| [star](https://en.wiktionary.org/wiki/star#Dutch) | stiff, frozen | /stɑr/ · adj |
| [update](https://en.wiktionary.org/wiki/update#Dutch) | an update | /ˈʏp.deːt/ · noun |
| [gat](https://en.wiktionary.org/wiki/gat#Dutch) | gap, hole | /ɣɑt/ · noun |
| [house](https://en.wiktionary.org/wiki/house#Dutch) | house music, house (a genre of music) | /ɦɑu̯s/ · noun |
| [jas](https://en.wiktionary.org/wiki/jas#Dutch) | a coat (outer garment) | /jɑs/ · noun |
| [lente](https://en.wiktionary.org/wiki/lente#Dutch) | spring: the season between winter and summer | /ˈlɛn.tə/ · noun |
| [lunch](https://en.wiktionary.org/wiki/lunch#Dutch) | a lunch, a meal eaten around noon | /lʏnʃ/ · noun |
| [set](https://en.wiktionary.org/wiki/set#Dutch) | a set (collection of objects belonging together) | /sɛt/ · noun |
| [tip](https://en.wiktionary.org/wiki/tip#Dutch) | tip, extreme end of something | /tɪp/ · noun |
| [ach](https://en.wiktionary.org/wiki/ach#Dutch) | oh (expression of compassion, surprise and dismay) | /ɑx/ · intj |
| [ha](https://en.wiktionary.org/wiki/ha#Dutch) | ha |  · intj |
| [hot](https://en.wiktionary.org/wiki/hot#Dutch) | right, on the right side | /ɦɔt/ · adj |
| [lol](https://en.wiktionary.org/wiki/lol#Dutch) | fun | /lɔl/ · noun |
| [mars](https://en.wiktionary.org/wiki/mars#Dutch) | march | /mɑrs/ · noun |
| [pop](https://en.wiktionary.org/wiki/pop#Dutch) | cocoon, pupa | /pɔp/ · noun |
| [rook](https://en.wiktionary.org/wiki/rook#Dutch) | smoke | /roːk/ · noun |
| [software](https://en.wiktionary.org/wiki/software#Dutch) | software (encoded computer instructions) | /ˈsɔft.ʋɛr/ · noun |
| [wild](https://en.wiktionary.org/wiki/wild#Dutch) | wild | /ʋɪlt/ · adj |
| [elf](https://en.wiktionary.org/wiki/elf#Dutch) | eleven | /ɛl(ə)f/ · num |
| [girl](https://en.wiktionary.org/wiki/girl#Dutch) | girl, lass | /ɡəl/ · noun |
| [marine](https://en.wiktionary.org/wiki/marine#Dutch) | a navy | /maːˈri.nə/ · noun |
| [vijftig](https://en.wiktionary.org/wiki/vijftig#Dutch) | fifty | /ˈfɛi̯ftəx/ · num |
| [conflict](https://en.wiktionary.org/wiki/conflict#Dutch) | a conflict, clash or dispute | /kɔnˈflɪkt/ · noun |
| [puur](https://en.wiktionary.org/wiki/puur#Dutch) | pure | /pyr/ · adj |
| [stress](https://en.wiktionary.org/wiki/stress#Dutch) | stress | /strɛs/ · noun |
| [das](https://en.wiktionary.org/wiki/das#Dutch) | A badger, various species of genera Meles and Taxidea. | /dɑs/ · noun |
| [del](https://en.wiktionary.org/wiki/del#Dutch) | dune valley | /dɛl/ · noun |
| [mode](https://en.wiktionary.org/wiki/mode#Dutch) | fashion, trend | /ˈmoː.də/ · noun |
| [web](https://en.wiktionary.org/wiki/web#Dutch) | web (spiderweb) | /ʋɛp/ · noun |
| [Chinees](https://en.wiktionary.org/wiki/Chinees#Dutch) | Chinese | /ʃiˈneːs/ · adj |
| [chauffeur](https://en.wiktionary.org/wiki/chauffeur#Dutch) | driver (person who drives a motorized vehicle, such as a car or a bus; usually to transport others or in a professional capacity, often both) | /ʃoːˈføːr/ · noun |
| [green](https://en.wiktionary.org/wiki/green#Dutch) | green, putting green | /ɡriːn/ · noun |
| [verdedigen](https://en.wiktionary.org/wiki/verdedigen#Dutch) | to defend | /ˌvərˈdeː.də.ɣə(n)/ · verb |
| [vet](https://en.wiktionary.org/wiki/vet#Dutch) | fat | /vɛt/ · adj |
| [air](https://en.wiktionary.org/wiki/air#Dutch) | air, pretension or pretentious attitude | /ɛːr/ · noun |
| [alcohol](https://en.wiktionary.org/wiki/alcohol#Dutch) | alcohol (class of compounds) | /ˈɑl.koːˌɦɔl/ · noun |
| [bord](https://en.wiktionary.org/wiki/bord#Dutch) | plate, dish (cutlery) | /bɔrt/ · noun |
| [fan](https://en.wiktionary.org/wiki/fan#Dutch) | fan (admirer) | /fɑn/ · noun |
| [junior](https://en.wiktionary.org/wiki/junior#Dutch) | junior (younger or lower-ranked person, for example in job titles) |  · noun |
| [kaas](https://en.wiktionary.org/wiki/kaas#Dutch) | cheese | /kaːs/ · noun |
| [klok](https://en.wiktionary.org/wiki/klok#Dutch) | clock | /klɔk/ · noun |
| [plant](https://en.wiktionary.org/wiki/plant#Dutch) | plant, any member of the kingdom Plantae | /plɑnt/ · noun |
| [Russisch](https://en.wiktionary.org/wiki/Russisch#Dutch) | Russian, referring to Russia | /ˈrʏ.sis/ · adj |

</details>

<details><summary>Words 451–500</summary>

![[Resources/Audio/nl/Words 0451-0500.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [ad](https://en.wiktionary.org/wiki/ad#Dutch) | costing, totaling |  · prep |
| [ah](https://en.wiktionary.org/wiki/ah#Dutch) | ah (expressing understanding or surprise) | /aː/ · intj |
| [apart](https://en.wiktionary.org/wiki/apart#Dutch) | separate | /aːˈpɑrt/ · adj |
| [business](https://en.wiktionary.org/wiki/business#Dutch) | business (commercial activity or specific commercial enterprise) | /ˈbɪsnɪs/ · noun |
| [deal](https://en.wiktionary.org/wiki/deal#Dutch) | deal, a transaction or arrangement | /diːl/ · noun |
| [impact](https://en.wiktionary.org/wiki/impact#Dutch) | impact (strong influence or effect) | /ˈɪm.pɛkt/ · noun |
| [luxe](https://en.wiktionary.org/wiki/luxe#Dutch) | luxury | /ˈlyk.sə/ · noun |
| [metro](https://en.wiktionary.org/wiki/metro#Dutch) | an underground railway or underground-railway system, a subway, a metro | /ˈmeː.troː/ · noun |
| [rob](https://en.wiktionary.org/wiki/rob#Dutch) | seal, any member of the family Phocidae | /rɔp/ · noun |
| [roman](https://en.wiktionary.org/wiki/roman#Dutch) | a novel (work of fiction) | /roːˈmɑn/ · noun |
| [Vlaams](https://en.wiktionary.org/wiki/Vlaams#Dutch) | Flemish | /vlaːms/ · adj |
| [drama](https://en.wiktionary.org/wiki/drama#Dutch) | drama (theatrical work; anything involving play acting) | /ˈdraː.maː/ · noun |
| [blad](https://en.wiktionary.org/wiki/blad#Dutch) | a leaf (of a plant) | /blɑt/ · noun |
| [dam](https://en.wiktionary.org/wiki/dam#Dutch) | dam | /dɑm/ · noun |
| [job](https://en.wiktionary.org/wiki/job#Dutch) | job | /dʒɔp/ · noun |
| [oom](https://en.wiktionary.org/wiki/oom#Dutch) | uncle | /oːm/ · noun |
| [transport](https://en.wiktionary.org/wiki/transport#Dutch) | transport | /trɑnsˈpɔrt/ · noun |
| [constant](https://en.wiktionary.org/wiki/constant#Dutch) | constant, invariable | /kɔnˈstɑnt/ · adj |
| [gras](https://en.wiktionary.org/wiki/gras#Dutch) | grass | /ɣrɑs/ · noun |
| [kern](https://en.wiktionary.org/wiki/kern#Dutch) | nucleus, physical core | /kɛrn/ · noun |
| [kip](https://en.wiktionary.org/wiki/kip#Dutch) | a chicken, Gallus gallus domesticus | /kɪp/ · noun |
| [pa](https://en.wiktionary.org/wiki/pa#Dutch) | pa, dad | /paː/ · noun |
| [wow](https://en.wiktionary.org/wiki/wow#Dutch) | wow (exclaims surprise or amazement) | /ʋɑu̯/ · intj |
| [complex](https://en.wiktionary.org/wiki/complex#Dutch) | complex (composite) | /kɔmˈplɛks/ · adj |
| [file](https://en.wiktionary.org/wiki/file#Dutch) | traffic jam | /ˈfilə/ · noun |
| [jury](https://en.wiktionary.org/wiki/jury#Dutch) | jury | /ˈʒyː.ri/ · noun |
| [mini](https://en.wiktionary.org/wiki/mini#Dutch) | mini (tiny) |  · adj |
| [pot](https://en.wiktionary.org/wiki/pot#Dutch) | jar, pot, solid container | /pɔt/ · noun |
| [rock](https://en.wiktionary.org/wiki/rock#Dutch) | rock (style of music) | /rɔk/ · noun |
| [taxi](https://en.wiktionary.org/wiki/taxi#Dutch) | a taxi | /ˈtɑk.si/ · noun |
| [trend](https://en.wiktionary.org/wiki/trend#Dutch) | trend, tendency | /trɛnt/ · noun |
| [Japans](https://en.wiktionary.org/wiki/Japans#Dutch) | Japanese | /jaːˈpɑns/ · adj |
| [elite](https://en.wiktionary.org/wiki/elite#Dutch) | elite (group with a high or privileged status) | /ˌeːˈli.tə/ · noun |
| [rare](https://en.wiktionary.org/wiki/rare#Dutch) | weird person | /ˈraː.rə/ · noun |
| [rennen](https://en.wiktionary.org/wiki/rennen#Dutch) | to run, to move fast | /rɛ.nə(n)/ · verb |
| [douche](https://en.wiktionary.org/wiki/douche#Dutch) | shower | /duʃ/ · noun |
| [front](https://en.wiktionary.org/wiki/front#Dutch) | front | /frɔnt/ · noun |
| [hit](https://en.wiktionary.org/wiki/hit#Dutch) | a hit song, a very popular and successful song | /ɦɪt/ · noun |
| [pik](https://en.wiktionary.org/wiki/pik#Dutch) | penis | /pɪk/ · noun |
| [record](https://en.wiktionary.org/wiki/record#Dutch) | a record, a best achievement | /rəˈkoːr/ · noun |
| [wolf](https://en.wiktionary.org/wiki/wolf#Dutch) | wolf (Canis lupus; the largest wild member of the canine subfamily) | /ʋɔlf/ · noun |
| [blind](https://en.wiktionary.org/wiki/blind#Dutch) | blind (unable to see) | /blɪnt/ · adj |
| [duo](https://en.wiktionary.org/wiki/duo#Dutch) | twosome | /ˈdy(ʋ)oː/ · noun |
| [eh](https://en.wiktionary.org/wiki/eh#Dutch) | er, uh (confusion; space filling) | /ɛ(ː)/ · intj |
| [eng](https://en.wiktionary.org/wiki/eng#Dutch) | scary, creepy | /ɛŋ/ · adj |
| [formule](https://en.wiktionary.org/wiki/formule#Dutch) | formula | /ˌfɔrˈmy.lə/ · noun |
| [lift](https://en.wiktionary.org/wiki/lift#Dutch) | a lift, an elevator | /lɪft/ · noun |
| [pen](https://en.wiktionary.org/wiki/pen#Dutch) | a long feather of a bird | /pɛn/ · noun |
| [are](https://en.wiktionary.org/wiki/are#Dutch) | are, a unit of surface area | /ˈaː.rə/ · noun |
| [context](https://en.wiktionary.org/wiki/context#Dutch) | context | /ˈkɔn.tɛkst/ · noun |

</details>

<details><summary>Words 501–550</summary>

![[Resources/Audio/nl/Words 0501-0550.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [diner](https://en.wiktionary.org/wiki/diner#Dutch) | dinner, supper | /diˈneː/ · noun |
| [drank](https://en.wiktionary.org/wiki/drank#Dutch) | beverage, drink | /drɑŋk/ · noun |
| [es](https://en.wiktionary.org/wiki/es#Dutch) | ash, ash tree (Fraxinus excelsior) | /ɛs/ · noun |
| [hi](https://en.wiktionary.org/wiki/hi#Dutch) | A friendly, informal greeting; hi | /ɦɑi̯/ · intj |
| [jacht](https://en.wiktionary.org/wiki/jacht#Dutch) | hunt, hunting | /jɑxt/ · noun |
| [per se](https://en.wiktionary.org/wiki/per%20se#Dutch) | necessarily, absolutely, without fail | /pɛrˈseː/ · adv |
| [tent](https://en.wiktionary.org/wiki/tent#Dutch) | tent (for camping, special occasions, etc.) | /tɛnt/ · noun |
| [vent](https://en.wiktionary.org/wiki/vent#Dutch) | chap, fellow |  · noun |
| [check](https://en.wiktionary.org/wiki/check#Dutch) | check (inspection or examination) | /tʃɛk/ · noun |
| [circa](https://en.wiktionary.org/wiki/circa#Dutch) | circa: about, approximately | /ˈsɪr.kaː/ · prep |
| [cover](https://en.wiktionary.org/wiki/cover#Dutch) | a cover, cover song, cover version (rerecording of a previously recorded song, typically by a different artist) | /ˈkɑ.vər/ · noun |
| [dossier](https://en.wiktionary.org/wiki/dossier#Dutch) | dossier | /dɔˈʃeː/ · noun |
| [fruit](https://en.wiktionary.org/wiki/fruit#Dutch) | fruit (produced by trees or bushes, or any sweet vegetable; only literal sense) | /frœy̯t/ · noun |
| [vijftien](https://en.wiktionary.org/wiki/vijftien#Dutch) | fifteen | /ˈvɛi̯f.tin/ · num |
| [box](https://en.wiktionary.org/wiki/box#Dutch) | speaker, loudspeaker | /bɔks/ · noun |
| [chaos](https://en.wiktionary.org/wiki/chaos#Dutch) | chaos (disorder) | /ˈxaː.ɔs/ · noun |
| [design](https://en.wiktionary.org/wiki/design#Dutch) | design | /diˈzɑi̯n/ · noun |
| [duel](https://en.wiktionary.org/wiki/duel#Dutch) | a duel | /dyˈ(ʋ)ɛl/ · noun |
| [ei](https://en.wiktionary.org/wiki/ei#Dutch) | egg | /ɛi̯/ · noun |
| [focus](https://en.wiktionary.org/wiki/focus#Dutch) | focus | /ˈfoː.kʏs/ · noun |
| [jo](https://en.wiktionary.org/wiki/jo#Dutch) | hi |  · intj |
| [massa](https://en.wiktionary.org/wiki/massa#Dutch) | mass | /ˈmɑ.saː/ · noun |
| [alarm](https://en.wiktionary.org/wiki/alarm#Dutch) | alarm | /aːˈlɑrm/ · noun |
| [chef](https://en.wiktionary.org/wiki/chef#Dutch) | a boss, chief, head, leader | /ʃɛf/ · noun |
| [mes](https://en.wiktionary.org/wiki/mes#Dutch) | knife, cleaver | /mɛs/ · noun |
| [modern](https://en.wiktionary.org/wiki/modern#Dutch) | modern | /moːˈdɛrn/ · adj |
| [recent](https://en.wiktionary.org/wiki/recent#Dutch) | recent | /rəˈsɛnt/ · adj |
| [seconde](https://en.wiktionary.org/wiki/seconde#Dutch) | second (a unit of time) | /ˌsəˈkɔn.də/ · noun |
| [special](https://en.wiktionary.org/wiki/special#Dutch) | a special broadcast episode | /ˈspɛ.ʃɔl/ · noun |
| [tempo](https://en.wiktionary.org/wiki/tempo#Dutch) | tempo (pace, relative speed) | /ˈtɛm.poː/ · noun |
| [à](https://en.wiktionary.org/wiki/%C3%A0#Dutch) | indicates an approximate number |  · prep |
| [boy](https://en.wiktionary.org/wiki/boy#Dutch) | boy, young man | /bɔi̯/ · noun |
| [download](https://en.wiktionary.org/wiki/download#Dutch) | download | /ˈdɑu̯n.loːt/ · noun |
| [expert](https://en.wiktionary.org/wiki/expert#Dutch) | expert | /ɛkˈspɛːr/ · noun |
| [herfst](https://en.wiktionary.org/wiki/herfst#Dutch) | autumn, fall | /ɦɛrfst/ · noun |
| [incident](https://en.wiktionary.org/wiki/incident#Dutch) | an incident | /ˌɪn.siˈdɛnt/ · noun |
| [lui](https://en.wiktionary.org/wiki/lui#Dutch) | lazy | /lœy̯/ · adj |
| [veertig](https://en.wiktionary.org/wiki/veertig#Dutch) | forty | /ˈfeːr.təx/ · num |
| [wonder](https://en.wiktionary.org/wiki/wonder#Dutch) | wonder, miracle | /ˈʋɔn.dər/ · noun |
| [herkennen](https://en.wiktionary.org/wiki/herkennen#Dutch) | to recognize | /ˌɦɛrˈkɛ.nə(n)/ · verb |
| [laden](https://en.wiktionary.org/wiki/laden#Dutch) | to load (cargo, a weapon, data) | /ˈlaːdə(n)/ · verb |
| [rot](https://en.wiktionary.org/wiki/rot#Dutch) | rotten, spoiled, decayed, putrid | /rɔt/ · adj |
| [au](https://en.wiktionary.org/wiki/au#Dutch) | ouch! | /ɑu̯/ · intj |
| [beer](https://en.wiktionary.org/wiki/beer#Dutch) | a bear, any member of the family Ursidae | /beːr/ · noun |
| [down](https://en.wiktionary.org/wiki/down#Dutch) | down, depressed | /dɑu̯n/ · adj |
| [keel](https://en.wiktionary.org/wiki/keel#Dutch) | throat | /keːl/ · noun |
| [marathon](https://en.wiktionary.org/wiki/marathon#Dutch) | marathon | /ˈmaː.raː.tɔn/ · noun |
| [marketing](https://en.wiktionary.org/wiki/marketing#Dutch) | marketing (promotion, distribution and selling of a product or service; the work of a marketer; includes market research and advertising) | /ˈmɑr.kə.tɪŋ/ · noun |
| [plat](https://en.wiktionary.org/wiki/plat#Dutch) | flat | /plɑt/ · adj |
| [senator](https://en.wiktionary.org/wiki/senator#Dutch) | senator |  · noun |

</details>

<details><summary>Words 551–600</summary>

![[Resources/Audio/nl/Words 0551-0600.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [vers](https://en.wiktionary.org/wiki/vers#Dutch) | fresh | /vɛrs/ · adj |
| [zout](https://en.wiktionary.org/wiki/zout#Dutch) | salt | /zɑu̯t/ · noun |
| [belt](https://en.wiktionary.org/wiki/belt#Dutch) | a dumpsite, notably for waste products | /bɛlt/ · noun |
| [exact](https://en.wiktionary.org/wiki/exact#Dutch) | exact, precise | /ɛkˈsɑkt/ · adj |
| [massage](https://en.wiktionary.org/wiki/massage#Dutch) | physical massage | /mɑˈsaːʒə/ · noun |
| [re](https://en.wiktionary.org/wiki/re#Dutch) | re (second note of a major scale) | /reː/ · noun |
| [score](https://en.wiktionary.org/wiki/score#Dutch) | score (number of points earned) | /ˈskoː.rə/ · noun |
| [stage](https://en.wiktionary.org/wiki/stage#Dutch) | probation, induction | /ˈstaː.ʒə/ · noun |
| [stemming](https://en.wiktionary.org/wiki/stemming#Dutch) | mood, atmosphere | /ˈstɛ.mɪŋ/ · noun |
| [suiker](https://en.wiktionary.org/wiki/suiker#Dutch) | sugar | /ˈsœy̯.kər/ · noun |
| [zoo](https://en.wiktionary.org/wiki/zoo#Dutch) | zoo | /zoː/ · noun |
| [brandstof](https://en.wiktionary.org/wiki/brandstof#Dutch) | fuel | /ˈbrɑn(t).stɔf/ · noun |
| [fuck](https://en.wiktionary.org/wiki/fuck#Dutch) | a fuck | /fʏk/ · noun |
| [master](https://en.wiktionary.org/wiki/master#Dutch) | a master, boss, superior | /ˈmɑː.stər/ · noun |
| [mix](https://en.wiktionary.org/wiki/mix#Dutch) | mix, mixture | /mɪks/ · noun |
| [more](https://en.wiktionary.org/wiki/more#Dutch) | the unit of length (short or long) in poetic metre | /ˈmoː.rə/ · noun |
| [ambulance](https://en.wiktionary.org/wiki/ambulance#Dutch) | ambulance (emergency vehicle) | /ˌɑm.byˈlɑn.sə/ · noun |
| [cent](https://en.wiktionary.org/wiki/cent#Dutch) | cent, a subunit of currency equal to one-hundredth of the main unit of the Dutch guilder | /sɛnt/ · noun |
| [document](https://en.wiktionary.org/wiki/document#Dutch) | document | /ˌdoː.kyˈmɛnt/ · noun |
| [lab](https://en.wiktionary.org/wiki/lab#Dutch) | lab |  · noun |
| [li](https://en.wiktionary.org/wiki/li#Dutch) | li (Chinese unit of distance) |  · noun |
| [ai](https://en.wiktionary.org/wiki/ai#Dutch) | expression of pain, grief or pity: ay | /ɑi̯/ · intj |
| [duiken](https://en.wiktionary.org/wiki/duiken#Dutch) | to dive | /ˈdœy̯kə(n)/ · verb |
| [kopje](https://en.wiktionary.org/wiki/kopje#Dutch) | an act of rubbing one's face on someone or something to spread pheromones | /ˈkɔ.pjə/ · noun |
| [meet](https://en.wiktionary.org/wiki/meet#Dutch) | the finish line in a competition | /meːt/ · noun |
| [pizza](https://en.wiktionary.org/wiki/pizza#Dutch) | pizza (Italian dish) | /ˈpitsaː/ · noun |
| [sub](https://en.wiktionary.org/wiki/sub#Dutch) | submarine, sub |  · noun |
| [architect](https://en.wiktionary.org/wiki/architect#Dutch) | architect | /ˌɑrxiˈtɛkt/ · noun |
| [bloem](https://en.wiktionary.org/wiki/bloem#Dutch) | flower, bloom of flowering plant | /blum/ · noun |
| [bom](https://en.wiktionary.org/wiki/bom#Dutch) | bomb (explosive) | /bɔm/ · noun |
| [correct](https://en.wiktionary.org/wiki/correct#Dutch) | correct | /kɔˈrɛkt/ · adj |
| [label](https://en.wiktionary.org/wiki/label#Dutch) | quality label | /ˈleːbəl/ · noun |
| [liter](https://en.wiktionary.org/wiki/liter#Dutch) | litre | /ˈli.tər/ · noun |
| [monster](https://en.wiktionary.org/wiki/monster#Dutch) | a monster, terrifying and dangerous creature | /ˈmɔnstər/ · noun |
| [oor](https://en.wiktionary.org/wiki/oor#Dutch) | ear | /oːr/ · noun |
| [protest](https://en.wiktionary.org/wiki/protest#Dutch) | protest (occasion to express dissatisfaction) | /proːˈtɛst/ · noun |
| [schema](https://en.wiktionary.org/wiki/schema#Dutch) | visualisation, diagram | /ˈsxeː.maː/ · noun |
| [senior](https://en.wiktionary.org/wiki/senior#Dutch) | elderly person, senior citizen | /ˈseː.ni.ɔr/ · noun |
| [wassen](https://en.wiktionary.org/wiki/wassen#Dutch) | to wash, to clean | /ˈʋɑ.sə(n)/ · verb |
| [bol](https://en.wiktionary.org/wiki/bol#Dutch) | a sphere; a ball, globe or bulb | /bɔl/ · noun |
| [centimeter](https://en.wiktionary.org/wiki/centimeter#Dutch) | centimetre, one-hundredth of a metre | /ˈsɛntiˌmeːtər/ · noun |
| [experiment](https://en.wiktionary.org/wiki/experiment#Dutch) | experiment | /ˌɛks.peː.riˈmɛnt/ · noun |
| [instrument](https://en.wiktionary.org/wiki/instrument#Dutch) | instrument | /ˌɪn.stryˈmɛnt/ · noun |
| [like](https://en.wiktionary.org/wiki/like#Dutch) | like | /lɑi̯k/ · noun |
| [porno](https://en.wiktionary.org/wiki/porno#Dutch) | porn | /ˈpɔr.noː/ · noun |
| [research](https://en.wiktionary.org/wiki/research#Dutch) | research |  · noun |
| [ruil](https://en.wiktionary.org/wiki/ruil#Dutch) | swap, exchange | /rœy̯l/ · noun |
| [nut](https://en.wiktionary.org/wiki/nut#Dutch) | use, point, utility, sense | /nʏt/ · noun |
| [pond](https://en.wiktionary.org/wiki/pond#Dutch) | metric pound (500 grams) | /pɔnt/ · noun |
| [proeven](https://en.wiktionary.org/wiki/proeven#Dutch) | to taste (something), to test or detect by tasting | /ˈpru.və(n)/ · verb |

</details>

<details><summary>Words 601–650</summary>

![[Resources/Audio/nl/Words 0601-0650.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [server](https://en.wiktionary.org/wiki/server#Dutch) | server (a computer or software that provides services to other programs or users) | /ˈsʏrvər/ · noun |
| [tag](https://en.wiktionary.org/wiki/tag#Dutch) | tag |  · noun |
| [tong](https://en.wiktionary.org/wiki/tong#Dutch) | tongue | /tɔŋ/ · noun |
| [Italiaans](https://en.wiktionary.org/wiki/Italiaans#Dutch) | Italian | /itaːlˈjaːns/ · adj |
| [amateur](https://en.wiktionary.org/wiki/amateur#Dutch) | amateur | /ˌɑ.maːˈtøːr/ · noun |
| [bot](https://en.wiktionary.org/wiki/bot#Dutch) | not sharp, blunt, dull | /bɔt/ · adj |
| [delta](https://en.wiktionary.org/wiki/delta#Dutch) | the Greek letter delta | /ˈdɛl.taː/ · noun |
| [dirk](https://en.wiktionary.org/wiki/dirk#Dutch) | topping lift | /ˈdɪrk/ · noun |
| [foundation](https://en.wiktionary.org/wiki/foundation#Dutch) | foundation (cosmetic cream roughly skin-colored, designed to make the face appear uniform in color and texture) | /fɑu̯nˈdeː.ʃən/ · noun |
| [gave](https://en.wiktionary.org/wiki/gave#Dutch) | a gift, donation, present | /ˈɣaːvə/ · noun |
| [letter](https://en.wiktionary.org/wiki/letter#Dutch) | letter (letter of the alphabet) | /ˈlɛ.tər/ · noun |
| [object](https://en.wiktionary.org/wiki/object#Dutch) | object, item | /ɔpˈjɛkt/ · noun |
| [piano](https://en.wiktionary.org/wiki/piano#Dutch) | piano | /piˈaːnoː/ · noun |
| [flat](https://en.wiktionary.org/wiki/flat#Dutch) | flat, apartment | /ˈflɛt/ · noun |
| [port](https://en.wiktionary.org/wiki/port#Dutch) | postage | /pɔrt/ · noun |
| [schaduw](https://en.wiktionary.org/wiki/schaduw#Dutch) | shade | /ˈsxaː.dyu̯/ · noun |
| [tram](https://en.wiktionary.org/wiki/tram#Dutch) | a tram, a streetcar, vehicle on rails for passenger transport in cities | /trɛm/ · noun |
| [vos](https://en.wiktionary.org/wiki/vos#Dutch) | fox, carnivore of the tribe Vulpini | /vɔs/ · noun |
| [zestig](https://en.wiktionary.org/wiki/zestig#Dutch) | sixty | /ˈsɛs.təx/ · num |
| [detail](https://en.wiktionary.org/wiki/detail#Dutch) | detail | /deːˈtɑi̯/ · noun |
| [have](https://en.wiktionary.org/wiki/have#Dutch) | property, possession | /ˈɦaː.və/ · noun |
| [shop](https://en.wiktionary.org/wiki/shop#Dutch) | shop |  · noun |
| [tank](https://en.wiktionary.org/wiki/tank#Dutch) | tank (storage reservoir) | /tɑŋk/ · noun |
| [trio](https://en.wiktionary.org/wiki/trio#Dutch) | trio, threesome, triad (group of three people or things) | /ˈtri.oː/ · noun |
| [factor](https://en.wiktionary.org/wiki/factor#Dutch) | a factor, element | /ˈfɑk.tɔr/ · noun |
| [fit](https://en.wiktionary.org/wiki/fit#Dutch) | fit (in good shape) |  · adj |
| [index](https://en.wiktionary.org/wiki/index#Dutch) | index (list) | /ˈɪn.dɛks/ · noun |
| [kerel](https://en.wiktionary.org/wiki/kerel#Dutch) | lad, fellow, bloke | /ˈkeː.rəl/ · noun |
| [neen](https://en.wiktionary.org/wiki/neen#Dutch) | no; stressed or formal form of nee | /neːn/ · intj |
| [nest](https://en.wiktionary.org/wiki/nest#Dutch) | a nest (place to hatch young, especially bird structure) | /nɛst/ · noun |
| [nicht](https://en.wiktionary.org/wiki/nicht#Dutch) | female cousin; daughter of someone's uncle or aunt | /nɪxt/ · noun |
| [order](https://en.wiktionary.org/wiki/order#Dutch) | order (command) | /ˈɔr.dər/ · noun |
| [vat](https://en.wiktionary.org/wiki/vat#Dutch) | barrel, tank | /vɑt/ · noun |
| [database](https://en.wiktionary.org/wiki/database#Dutch) | database | /ˈdaː.taːˌbeːs/ · noun |
| [her](https://en.wiktionary.org/wiki/her#Dutch) | here | /ɦɛr/ · adv |
| [koper](https://en.wiktionary.org/wiki/koper#Dutch) | copper (metal, element) | /ˈkoːpər/ · noun |
| [nazi](https://en.wiktionary.org/wiki/nazi#Dutch) | Nazi, member of the NSDAP | /ˈnaː.zi/ · noun |
| [rapper](https://en.wiktionary.org/wiki/rapper#Dutch) | rapper (performer of rap music) | /ˈrɛpər/ · noun |
| [wijs](https://en.wiktionary.org/wiki/wijs#Dutch) | wise | /ʋɛi̯s/ · adj |
| [gram](https://en.wiktionary.org/wiki/gram#Dutch) | gram (unit of mass) | /ɣrɑm/ · noun |
| [hobby](https://en.wiktionary.org/wiki/hobby#Dutch) | hobby (activity) | /ˈɦɔ.bi/ · noun |
| [jazz](https://en.wiktionary.org/wiki/jazz#Dutch) | jazz | /dʒɛz/ · noun |
| [os](https://en.wiktionary.org/wiki/os#Dutch) | ox (castrated bull) | /ɔs/ · noun |
| [regime](https://en.wiktionary.org/wiki/regime#Dutch) | regime (political order) | /rəˈʒim/ · noun |
| [ban](https://en.wiktionary.org/wiki/ban#Dutch) | excommunication, denunciation, shunning | /bɑn/ · noun |
| [bridge](https://en.wiktionary.org/wiki/bridge#Dutch) | bridge (card game) | /brɪdʒ/ · noun |
| [community](https://en.wiktionary.org/wiki/community#Dutch) | community, particularly a virtual community or a group of people sharing common interests | /kɔˈmjunɪti/ · noun |
| [drink](https://en.wiktionary.org/wiki/drink#Dutch) | a social event were beverages are served, with or without snacks, e.g. as a celebration | /drɪŋk/ · noun |
| [eventueel](https://en.wiktionary.org/wiki/eventueel#Dutch) | possibly | /ˌeː.və(n).tyˈeːl/ · adv |
| [hectare](https://en.wiktionary.org/wiki/hectare#Dutch) | hectare | /ˌɦɛkˈtaː.rə/ · noun |

</details>

<details><summary>Words 651–700</summary>

![[Resources/Audio/nl/Words 0651-0700.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [mega](https://en.wiktionary.org/wiki/mega#Dutch) | mega (huge) |  · adj |
| [zoom](https://en.wiktionary.org/wiki/zoom#Dutch) | edge, border | /zoːm/ · noun |
| [actrice](https://en.wiktionary.org/wiki/actrice#Dutch) | actress | /ˌɑkˈtri.sə/ · noun |
| [appel](https://en.wiktionary.org/wiki/appel#Dutch) | apple (Malus domestica, fruit or tree) | /ˈɑ.pəl/ · noun |
| [argument](https://en.wiktionary.org/wiki/argument#Dutch) | an argument (fact or statement used to support a proposition) | /ˌɑr.ɣyˈmɛnt/ · noun |
| [bo](https://en.wiktionary.org/wiki/bo#Dutch) | sandwich | /boː/ · noun |
| [long](https://en.wiktionary.org/wiki/long#Dutch) | lung | /lɔŋ/ · noun |
| [smart](https://en.wiktionary.org/wiki/smart#Dutch) | pain, sorrow, grief | /smɑrt/ · noun |
| [staal](https://en.wiktionary.org/wiki/staal#Dutch) | steel | /staːl/ · noun |
| [aap](https://en.wiktionary.org/wiki/aap#Dutch) | monkey, ape, simian; any member of the infraorder Simiiformes | /aːp/ · noun |
| [chat](https://en.wiktionary.org/wiki/chat#Dutch) | chat (online conversation) | /tʃɛt/ · noun |
| [heilig](https://en.wiktionary.org/wiki/heilig#Dutch) | holy | /ˈɦɛi̯.ləx/ · adj |
| [rap](https://en.wiktionary.org/wiki/rap#Dutch) | quick, fast | /rɑp/ · adj |
| [royal](https://en.wiktionary.org/wiki/royal#Dutch) | royal |  · noun |
| [ticket](https://en.wiktionary.org/wiki/ticket#Dutch) | ticket or voucher | /ˈtɪ.kət/ · noun |
| [veertien](https://en.wiktionary.org/wiki/veertien#Dutch) | fourteen | /ˈveːr.tin/ · num |
| [Afrikaans](https://en.wiktionary.org/wiki/Afrikaans#Dutch) | African; of, from or pertaining to Africa | /aːfriˈkaːns/ · adj |
| [benzine](https://en.wiktionary.org/wiki/benzine#Dutch) | petrol, gas, gasoline (fuel containing alkanes) | /bɛnˈzi.nə/ · noun |
| [bon](https://en.wiktionary.org/wiki/bon#Dutch) | receipt | /bɔn/ · noun |
| [dertien](https://en.wiktionary.org/wiki/dertien#Dutch) | thirteen | /ˈdɛr.tin/ · num |
| [huh](https://en.wiktionary.org/wiki/huh#Dutch) | huh (an exclamation indicating puzzlement) | /ɦʏ/ · intj |
| [look](https://en.wiktionary.org/wiki/look#Dutch) | any plant of the genus Allium; leek | /loːk/ · noun |
| [masker](https://en.wiktionary.org/wiki/masker#Dutch) | mask | /ˈmɑs.kər/ · noun |
| [munt](https://en.wiktionary.org/wiki/munt#Dutch) | coin | /mʏnt/ · noun |
| [part](https://en.wiktionary.org/wiki/part#Dutch) | part | /pɑrt/ · noun |
| [scenario](https://en.wiktionary.org/wiki/scenario#Dutch) | scenario (screenplay, plot outline) | /səˈnaː.ri.oː/ · noun |
| [slang](https://en.wiktionary.org/wiki/slang#Dutch) | snake, squamate of the suborder Serpentes | /slɑŋ/ · noun |
| [straffen](https://en.wiktionary.org/wiki/straffen#Dutch) | to punish | /ˈstrɑfə(n)/ · verb |
| [volume](https://en.wiktionary.org/wiki/volume#Dutch) | volume (three-dimensional quantity of space) | /ˌvoːˈly.mə/ · noun |
| [bravo](https://en.wiktionary.org/wiki/bravo#Dutch) | bravo! | /braːˈvoː/ · intj |
| [element](https://en.wiktionary.org/wiki/element#Dutch) | element | /ˌeː.ləˈmɛnt/ · noun |
| [engel](https://en.wiktionary.org/wiki/engel#Dutch) | angel | /ˈɛŋəl/ · noun |
| [fair](https://en.wiktionary.org/wiki/fair#Dutch) | fair (just, honest, equitable, adequate) | /fɛːr/ · adj |
| [finish](https://en.wiktionary.org/wiki/finish#Dutch) | finish; end | /ˈfɪ.nɪʃ/ · noun |
| [guy](https://en.wiktionary.org/wiki/guy#Dutch) | guy |  · noun |
| [khan](https://en.wiktionary.org/wiki/khan#Dutch) | a khan (nobleman in various Central Asian countries) | /kaːn/ · noun |
| [level](https://en.wiktionary.org/wiki/level#Dutch) | level (segment of a game) | /ˈlɛ.vəl/ · noun |
| [opera](https://en.wiktionary.org/wiki/opera#Dutch) | opera | /ˈoː.pəˌraː/ · noun |
| [permanent](https://en.wiktionary.org/wiki/permanent#Dutch) | permanent | /ˌpɛr.maːˈnɛnt/ · adj |
| [spot](https://en.wiktionary.org/wiki/spot#Dutch) | mockery | /spɔt/ · noun |
| [tak](https://en.wiktionary.org/wiki/tak#Dutch) | branch, twig, bough | /tɑk/ · noun |
| [blond](https://en.wiktionary.org/wiki/blond#Dutch) | blond, fair; of light color (usually said about light hair color, but it can also refer to beer) | /blɔnt/ · adj |
| [circuit](https://en.wiktionary.org/wiki/circuit#Dutch) | racetrack | /sɪrˈkʋi/ · noun |
| [hockey](https://en.wiktionary.org/wiki/hockey#Dutch) | hockey, almost always field hockey | /ˈɦɔ.ki/ · noun |
| [musical](https://en.wiktionary.org/wiki/musical#Dutch) | musical (stage performance, show or film that involves singing, dancing and musical numbers performed by the cast as well as acting) | /ˈmju.zə.kəl/ · noun |
| [pink](https://en.wiktionary.org/wiki/pink#Dutch) | pinkie (little finger) | /pɪŋk/ · noun |
| [porto](https://en.wiktionary.org/wiki/porto#Dutch) | the postage due for having a letter or package transported and delivered by a postal service | /ˈpɔr.toː/ · noun |
| [première](https://en.wiktionary.org/wiki/premi%C3%A8re#Dutch) | premiere | /prəˈmjɛː.rə/ · noun |
| [anno](https://en.wiktionary.org/wiki/anno#Dutch) | in the year | /ˈɑ.noː/ · adv |
| [dun](https://en.wiktionary.org/wiki/dun#Dutch) | thin, slender | /dʏn/ · adj |

</details>

<details><summary>Words 701–750</summary>

![[Resources/Audio/nl/Words 0701-0750.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [duwen](https://en.wiktionary.org/wiki/duwen#Dutch) | to push | /ˈdyu̯ə(n)/ · verb |
| [firma](https://en.wiktionary.org/wiki/firma#Dutch) | a large-scale company, a firm |  · noun |
| [ham](https://en.wiktionary.org/wiki/ham#Dutch) | ham (cured pork from the thigh of a swine) | /ɦɑm/ · noun |
| [lust](https://en.wiktionary.org/wiki/lust#Dutch) | lust, desire (especially sexual, but also more generally) | /lʏst/ · noun |
| [speech](https://en.wiktionary.org/wiki/speech#Dutch) | speech, oration (oral monologic address of some length) | /spitʃ/ · noun |
| [voornaam](https://en.wiktionary.org/wiki/voornaam#Dutch) | first name | /ˈvoːrˌnaːm/ · noun |
| [aspect](https://en.wiktionary.org/wiki/aspect#Dutch) | aspect, element | /ɑˈspɛkt/ · noun |
| [bonus](https://en.wiktionary.org/wiki/bonus#Dutch) | a bonus, an extra or premium | /ˈboː.nʏs/ · noun |
| [hang](https://en.wiktionary.org/wiki/hang#Dutch) | a support for hanging objects, such as a nail for a picture frame | /ɦɑŋ/ · noun |
| [pet](https://en.wiktionary.org/wiki/pet#Dutch) | cap (headwear with a peak at the front) | /pɛt/ · noun |
| [reserve](https://en.wiktionary.org/wiki/reserve#Dutch) | reserve, emergency supply (that which is reserved, or kept back, as for future use) | /rəˈzɛr.və/ · noun |
| [stadium](https://en.wiktionary.org/wiki/stadium#Dutch) | a stage; a phase | /ˈstaː.di.ʏm/ · noun |
| [vee](https://en.wiktionary.org/wiki/vee#Dutch) | livestock, cattle | /veː/ · noun |
| [hol](https://en.wiktionary.org/wiki/hol#Dutch) | a hole, hollow, cavity | /ɦɔl/ · noun |
| [lever](https://en.wiktionary.org/wiki/lever#Dutch) | liver | /ˈleːvər/ · noun |
| [living](https://en.wiktionary.org/wiki/living#Dutch) | living room | /ˈlɪ.vɪŋ/ · noun |
| [luik](https://en.wiktionary.org/wiki/luik#Dutch) | hatch | /lœy̯k/ · noun |
| [medium](https://en.wiktionary.org/wiki/medium#Dutch) | means, system or instrument for fulfilling an end | /ˈmeːdiʏm/ · noun |
| [oven](https://en.wiktionary.org/wiki/oven#Dutch) | oven, furnace | /ˈoː.vən/ · noun |
| [producer](https://en.wiktionary.org/wiki/producer#Dutch) | producer | /proːˈdjuː.sər/ · noun |
| [robot](https://en.wiktionary.org/wiki/robot#Dutch) | robot | /ˈroː.bɔt/ · noun |
| [zeventig](https://en.wiktionary.org/wiki/zeventig#Dutch) | seventy | /ˈseːvə(n)təx/ · num |
| [doctor](https://en.wiktionary.org/wiki/doctor#Dutch) | doctor (person who has attained a doctorate) | /ˈdɔk.tɔr/ · noun |
| [hals](https://en.wiktionary.org/wiki/hals#Dutch) | the neck | /ɦɑls/ · noun |
| [hoed](https://en.wiktionary.org/wiki/hoed#Dutch) | a hat, worn on the head | /ɦut/ · noun |
| [song](https://en.wiktionary.org/wiki/song#Dutch) | song |  · noun |
| [testament](https://en.wiktionary.org/wiki/testament#Dutch) | testament (document containing a person's will) | /tɛs.taːˈmɛnt/ · noun |
| [bezitten](https://en.wiktionary.org/wiki/bezitten#Dutch) | to own, to possess | /bəˈzɪtə(n)/ · verb |
| [echo](https://en.wiktionary.org/wiki/echo#Dutch) | echo | /ˈɛ.xoː/ · noun |
| [made](https://en.wiktionary.org/wiki/made#Dutch) | maggot; a fly larva that eats decomposing flesh | /ˈmaːdə/ · noun |
| [menu](https://en.wiktionary.org/wiki/menu#Dutch) | menu | /məˈny/ · noun |
| [protocol](https://en.wiktionary.org/wiki/protocol#Dutch) | protocol (collection of rules and procedures) | /ˌproː.toːˈkɔl/ · noun |
| [room](https://en.wiktionary.org/wiki/room#Dutch) | cream (of milk) | /roːm/ · noun |
| [tech](https://en.wiktionary.org/wiki/tech#Dutch) | tech (technology), particularly high-tech or digital technology | /tɛx/ · noun |
| [CEO](https://en.wiktionary.org/wiki/CEO#Dutch) | CEO; chief executive officer | /ˈsiːˈjoː/ · noun |
| [angel](https://en.wiktionary.org/wiki/angel#Dutch) | sting, dart (insect's organ) | /ˈɑŋəl/ · noun |
| [diagnose](https://en.wiktionary.org/wiki/diagnose#Dutch) | diagnosis | /ˌdi.ɑxˈnoː.zə/ · noun |
| [klimmen](https://en.wiktionary.org/wiki/klimmen#Dutch) | to climb | /ˈklɪ.mə(n)/ · verb |
| [maximum](https://en.wiktionary.org/wiki/maximum#Dutch) | maximum | /ˈmɑk.siˌmʏm/ · noun |
| [plank](https://en.wiktionary.org/wiki/plank#Dutch) | shelf | /plɑŋk/ · noun |
| [zestien](https://en.wiktionary.org/wiki/zestien#Dutch) | sixteen | /ˈzɛs.tin/ · num |
| [accent](https://en.wiktionary.org/wiki/accent#Dutch) | accent (distinctive pronunciation of a language; phonetic and phonological aspects of a lect) | /ɑkˈsɛnt/ · noun |
| [bi](https://en.wiktionary.org/wiki/bi#Dutch) | bisexual | /bi/ · adj |
| [glad](https://en.wiktionary.org/wiki/glad#Dutch) | smooth, polished | /ɣlɑt/ · adj |
| [ijzer](https://en.wiktionary.org/wiki/ijzer#Dutch) | iron (metal) | /ˈɛi̯zər/ · noun |
| [put](https://en.wiktionary.org/wiki/put#Dutch) | pit, well | /ˈpʏt/ · noun |
| [spin](https://en.wiktionary.org/wiki/spin#Dutch) | spider (member of the order Araneae) | /spɪn/ · noun |
| [steel](https://en.wiktionary.org/wiki/steel#Dutch) | stem (of a plant) | /steːl/ · noun |
| [tape](https://en.wiktionary.org/wiki/tape#Dutch) | tape |  · noun |
| [tennis](https://en.wiktionary.org/wiki/tennis#Dutch) | tennis (sport) | /ˈtɛ.nɪs/ · noun |

</details>

<details><summary>Words 751–800</summary>

![[Resources/Audio/nl/Words 0751-0800.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [zoenen](https://en.wiktionary.org/wiki/zoenen#Dutch) | to kiss | /ˈzu.nə(n)/ · verb |
| [zuur](https://en.wiktionary.org/wiki/zuur#Dutch) | sour | /zyr/ · adj |
| [email](https://en.wiktionary.org/wiki/email#Dutch) | enamel | /eːˈmɑi̯/ · noun |
| [export](https://en.wiktionary.org/wiki/export#Dutch) | export | /ˈɛks.pɔrt/ · noun |
| [item](https://en.wiktionary.org/wiki/item#Dutch) | item (matter of discussion) | /ˈɑjtəm/ · noun |
| [nice](https://en.wiktionary.org/wiki/nice#Dutch) | nice |  · adj |
| [nova](https://en.wiktionary.org/wiki/nova#Dutch) | nova, nova star | /ˈnoː.vaː/ · noun |
| [penis](https://en.wiktionary.org/wiki/penis#Dutch) | penis | /ˈpeː.nɪs/ · noun |
| [trip](https://en.wiktionary.org/wiki/trip#Dutch) | a trip, a short excursion, a vacation, travelling | /trɪp/ · noun |
| [cola](https://en.wiktionary.org/wiki/cola#Dutch) | cola (drink) | /ˈkoː.laː/ · noun |
| [gene](https://en.wiktionary.org/wiki/gene#Dutch) | one, person (preceded by a definite article or demonstrative) | /ɣeː.nə/ · pron |
| [honing](https://en.wiktionary.org/wiki/honing#Dutch) | honey | /ˈɦoː.nɪŋ/ · noun |
| [iris](https://en.wiktionary.org/wiki/iris#Dutch) | iris (coloured part of the eye) | /ˈiː.rɪs/ · noun |
| [mat](https://en.wiktionary.org/wiki/mat#Dutch) | rug, mat | /mɑt/ · noun |
| [must](https://en.wiktionary.org/wiki/must#Dutch) | a must (necessity, prerequisite) | /mʏst/ · noun |
| [teen](https://en.wiktionary.org/wiki/teen#Dutch) | toe | /ˈteːn/ · noun |
| [vest](https://en.wiktionary.org/wiki/vest#Dutch) | fortified wall, city wall | /vɛst/ · noun |
| [wal](https://en.wiktionary.org/wiki/wal#Dutch) | coast, shore (side of land near to the water) | /ʋɑl/ · noun |
| [adel](https://en.wiktionary.org/wiki/adel#Dutch) | nobility (class of people) | /ˈaːdəl/ · noun |
| [arrest](https://en.wiktionary.org/wiki/arrest#Dutch) | sentence passed by a higher court | /ɑˈrɛst/ · noun |
| [cash](https://en.wiktionary.org/wiki/cash#Dutch) | cash | /kɛʃ/ · noun |
| [chip](https://en.wiktionary.org/wiki/chip#Dutch) | a chip (one-piece circuit or hybrid device containing a circuit and another device) | /tʃɪp/ · noun |
| [column](https://en.wiktionary.org/wiki/column#Dutch) | a recurring opinion piece in a newspaper or magazine; a column | /ˈkɔ.lʏm/ · noun |
| [ego](https://en.wiktionary.org/wiki/ego#Dutch) | ego, self | /ˈeː.ɣoː/ · noun |
| [handicap](https://en.wiktionary.org/wiki/handicap#Dutch) | disability | /ˈɦɛn.diˌkɛp/ · noun |
| [intelligent](https://en.wiktionary.org/wiki/intelligent#Dutch) | intelligent, bright, smart | /ˌɪn.tə.liˈɣɛnt/ · adj |
| [propaganda](https://en.wiktionary.org/wiki/propaganda#Dutch) | propaganda |  · noun |
| [suite](https://en.wiktionary.org/wiki/suite#Dutch) | suite (group of interconnected rooms) | /ˈsʋi.tə/ · noun |
| [zwaard](https://en.wiktionary.org/wiki/zwaard#Dutch) | a sword, heavy blade weapon | /zʋaːrt/ · noun |
| [close](https://en.wiktionary.org/wiki/close#Dutch) | close (intimate or immediate in personal relationship) | /kloːs/ · adj |
| [list](https://en.wiktionary.org/wiki/list#Dutch) | a cunning plan, a ruse, a trick | /lɪst/ · noun |
| [scan](https://en.wiktionary.org/wiki/scan#Dutch) | scan (result or output of a scanning process) | /ˈskɛn/ · noun |
| [tour de force](https://en.wiktionary.org/wiki/tour%20de%20force#Dutch) | exploit, tour de force |  · noun |
| [Brussels](https://en.wiktionary.org/wiki/Brussels#Dutch) | of, from or pertaining to Brussels | /ˈbrʏ.səls/ · adj |
| [aluminium](https://en.wiktionary.org/wiki/aluminium#Dutch) | aluminium | /ˌaː.lyˈmi.ni.ʏm/ · noun |
| [beauty](https://en.wiktionary.org/wiki/beauty#Dutch) | a beauty, looker, beautiful person | /ˈbjuː.ti/ · noun |
| [lens](https://en.wiktionary.org/wiki/lens#Dutch) | optical lens | /lɛns/ · noun |
| [map](https://en.wiktionary.org/wiki/map#Dutch) | folder | /mɑp/ · noun |
| [uh](https://en.wiktionary.org/wiki/uh#Dutch) | er, uh |  · intj |
| [RAM](https://en.wiktionary.org/wiki/RAM#Dutch) | RAM (random-access memory) | /rɑm/ · noun |
| [alert](https://en.wiktionary.org/wiki/alert#Dutch) | alert | /aːˈlɛrt/ · adj |
| [atlas](https://en.wiktionary.org/wiki/atlas#Dutch) | atlas (bound or digital collection of maps) | /ˈɑt.lɑs/ · noun |
| [boulevard](https://en.wiktionary.org/wiki/boulevard#Dutch) | boulevard | /ˌbu.ləˈvaːr/ · noun |
| [frame](https://en.wiktionary.org/wiki/frame#Dutch) | frame | /freːm/ · noun |
| [hip](https://en.wiktionary.org/wiki/hip#Dutch) | genteel (stylish, elegant) | /ɦɪp/ · adj |
| [ram](https://en.wiktionary.org/wiki/ram#Dutch) | ram (male sheep) | /rɑm/ · noun |
| [Maya](https://en.wiktionary.org/wiki/Maya#Dutch) | a Maya; a member of the Maya people | /ˈmaː.jaː/ · noun |
| [mi](https://en.wiktionary.org/wiki/mi#Dutch) | mi | /mi/ · noun |
| [minimum](https://en.wiktionary.org/wiki/minimum#Dutch) | minimum | /ˈmi.niˌmʏm/ · noun |
| [ren](https://en.wiktionary.org/wiki/ren#Dutch) | a run; an enclosed area where small or mid-sized livestock such as poultry are kept | /rɛn/ · noun |

</details>

<details><summary>Words 801–850</summary>

![[Resources/Audio/nl/Words 0801-0850.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [cake](https://en.wiktionary.org/wiki/cake#Dutch) | pound cake | /keːk/ · noun |
| [lo](https://en.wiktionary.org/wiki/lo#Dutch) | matrilineal clan within a Maroon tribe |  · noun |
| [po](https://en.wiktionary.org/wiki/po#Dutch) | chamber pot | /poː/ · noun |
| [radar](https://en.wiktionary.org/wiki/radar#Dutch) | radar (detection system operating by means of radio waves) | /ˈraː.dɑr/ · noun |
| [sap](https://en.wiktionary.org/wiki/sap#Dutch) | juice | /sɑp/ · noun |
| [yo](https://en.wiktionary.org/wiki/yo#Dutch) | yo (informal greeting, interjection similar to hey) | /joː/ · intj |
| [continent](https://en.wiktionary.org/wiki/continent#Dutch) | continent (landmass) | /ˌkɔn.tiˈnɛnt/ · noun |
| [genre](https://en.wiktionary.org/wiki/genre#Dutch) | kind, type, genre | /ˈʒɑnrə/ · noun |
| [hop](https://en.wiktionary.org/wiki/hop#Dutch) | hoopoe, the species Upupa epops or an individual of this species | /ɦɔp/ · noun |
| [kloof](https://en.wiktionary.org/wiki/kloof#Dutch) | gap, gorge, ravine | /kloːf/ · noun |
| [meeting](https://en.wiktionary.org/wiki/meeting#Dutch) | meeting |  · noun |
| [otto](https://en.wiktionary.org/wiki/otto#Dutch) | wheelie bin | /ˈɔ.toː/ · noun |
| [pap](https://en.wiktionary.org/wiki/pap#Dutch) | mush | /pɑp/ · noun |
| [pasta](https://en.wiktionary.org/wiki/pasta#Dutch) | paste | /ˈpɑs.taː/ · noun |
| [relevant](https://en.wiktionary.org/wiki/relevant#Dutch) | relevant | /reːləˈvɑnt/ · adj |
| [rooster](https://en.wiktionary.org/wiki/rooster#Dutch) | grill, grid a metallic maze-structure; some things containing one | /ˈroː.stər/ · noun |
| [spectrum](https://en.wiktionary.org/wiki/spectrum#Dutch) | spectrum |  · noun |
| [transfer](https://en.wiktionary.org/wiki/transfer#Dutch) | transfer |  · noun |
| [Thai](https://en.wiktionary.org/wiki/Thai#Dutch) | a Thai person | /tɑi̯/ · noun |
| [body](https://en.wiktionary.org/wiki/body#Dutch) | bodysuit, leotard, onesie | /ˈbɔ.di/ · noun |
| [clip](https://en.wiktionary.org/wiki/clip#Dutch) | clip (something which clips or grasps; a device for attaching one object to another) | /klɪp/ · noun |
| [crash](https://en.wiktionary.org/wiki/crash#Dutch) | crash, collision, esp. when involving aircraft | /krɛʃ/ · noun |
| [diameter](https://en.wiktionary.org/wiki/diameter#Dutch) | diameter (length of diametrical chord) | /ˈdi.aːˌmeː.tər/ · noun |
| [hamer](https://en.wiktionary.org/wiki/hamer#Dutch) | hammer | /ˈɦaː.mər/ · noun |
| [kolonie](https://en.wiktionary.org/wiki/kolonie#Dutch) | colony, dependent human settlement, state or territory | /koːˈloː.ni/ · noun |
| [sloop](https://en.wiktionary.org/wiki/sloop#Dutch) | pillowcase, pillowslip | /sloːp/ · noun |
| [stank](https://en.wiktionary.org/wiki/stank#Dutch) | stench, stink | /stɑŋk/ · noun |
| [trailer](https://en.wiktionary.org/wiki/trailer#Dutch) | trailer (unpowered vehicle towed behind another) | /ˈtreː.lər/ · noun |
| [amber](https://en.wiktionary.org/wiki/amber#Dutch) | amber (colour of fossil resin) | /ˈɑm.bər/ · noun |
| [grip](https://en.wiktionary.org/wiki/grip#Dutch) | hold (to ensure control) | /ɣrɪp/ · noun |
| [mop](https://en.wiktionary.org/wiki/mop#Dutch) | a joke, jest | /mɔp/ · noun |
| [performance](https://en.wiktionary.org/wiki/performance#Dutch) | performance (act of performing) | /pərˈfɔːrməns/ · noun |
| [pest](https://en.wiktionary.org/wiki/pest#Dutch) | a plague, pest, pestilence |  · noun |
| [achttien](https://en.wiktionary.org/wiki/achttien#Dutch) | eighteen | /ˈɑx.tin/ · num |
| [country](https://en.wiktionary.org/wiki/country#Dutch) | country music | /ˈkʏn.tri/ · noun |
| [dictator](https://en.wiktionary.org/wiki/dictator#Dutch) | dictator (tyrant, despot) | /ˌdɪkˈtaː.tɔr/ · noun |
| [lam](https://en.wiktionary.org/wiki/lam#Dutch) | lamb, the young of a sheep | /lɑm/ · noun |
| [marina](https://en.wiktionary.org/wiki/marina#Dutch) | common, ordinary girl (often with a pejorative meaning) | /ˌmaːˈri.naː/ · noun |
| [metal](https://en.wiktionary.org/wiki/metal#Dutch) | metal (rock genre) | /ˈmɛ.təl/ · noun |
| [peloton](https://en.wiktionary.org/wiki/peloton#Dutch) | platoon |  · noun |
| [rat](https://en.wiktionary.org/wiki/rat#Dutch) | a rat, medium-sized rodent belonging to the genus Rattus, or of certain other genera in the family Muridae | /rɑt/ · noun |
| [rok](https://en.wiktionary.org/wiki/rok#Dutch) | skirt (clothing) | /rɔk/ · noun |
| [alfabet](https://en.wiktionary.org/wiki/alfabet#Dutch) | alphabet | /ˈɑl.faːˌbɛt/ · noun |
| [dapper](https://en.wiktionary.org/wiki/dapper#Dutch) | brave, courageous | /ˈdɑ.pər/ · adj |
| [fragment](https://en.wiktionary.org/wiki/fragment#Dutch) | a fragment, broken portion | /frɑxˈmɛnt/ · noun |
| [maker](https://en.wiktionary.org/wiki/maker#Dutch) | maker (person or thing that makes, produces or repairs something) | /ˈmaː.kər/ · noun |
| [page](https://en.wiktionary.org/wiki/page#Dutch) | a page, a butterfly of the family Papilionidae | /ˈpaː.ʒə/ · noun |
| [absurd](https://en.wiktionary.org/wiki/absurd#Dutch) | absurd | /ɑpˈsʏrt/ · adj |
| [dal](https://en.wiktionary.org/wiki/dal#Dutch) | valley | /dɑl/ · noun |
| [kick](https://en.wiktionary.org/wiki/kick#Dutch) | kick, thrill (something that excites or gives pleasure) | /kɪk/ · noun |

</details>

<details><summary>Words 851–900</summary>

![[Resources/Audio/nl/Words 0851-0900.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [manifest](https://en.wiktionary.org/wiki/manifest#Dutch) | manifest |  · noun |
| [poker](https://en.wiktionary.org/wiki/poker#Dutch) | poker (card game) | /ˈpoː.kər/ · noun |
| [balk](https://en.wiktionary.org/wiki/balk#Dutch) | a beam, solid support | /bɑlk/ · noun |
| [eend](https://en.wiktionary.org/wiki/eend#Dutch) | A duck, waterfowl of the family Anatidae excluding the subfamily Anserinae; in non-scientific usage the term may be reserved for only the smaller (not goose-like) members of the Anatidae or reserved for females only. | /eːnt/ · noun |
| [offer](https://en.wiktionary.org/wiki/offer#Dutch) | sacrifice, offering | /ˈɔfər/ · noun |
| [som](https://en.wiktionary.org/wiki/som#Dutch) | sum | /sɔm/ · noun |
| [speed](https://en.wiktionary.org/wiki/speed#Dutch) | amphetamines |  · noun |
| [wei](https://en.wiktionary.org/wiki/wei#Dutch) | a product obtained from milk; whey | /ʋɛi̯/ · noun |
| [clan](https://en.wiktionary.org/wiki/clan#Dutch) | clan, kin group, esp. in relation to the Scottish Highlands or Scotland in general | /klɛn/ · noun |
| [essay](https://en.wiktionary.org/wiki/essay#Dutch) | essay | /ɛˈseː/ · noun |
| [pool](https://en.wiktionary.org/wiki/pool#Dutch) | magnetic pole (especially of the Earth and other celestial bodies) | /poːl/ · noun |
| [register](https://en.wiktionary.org/wiki/register#Dutch) | a register, an index, esp. as an appendix in a book | /ˌrəˈɣɪs.tər/ · noun |
| [wand](https://en.wiktionary.org/wiki/wand#Dutch) | wall | /ʋɑnt/ · noun |
| [accountant](https://en.wiktionary.org/wiki/accountant#Dutch) | an accountant; an account-keeper or auditor | /ɑˈkɑu̯n.tənt/ · noun |
| [cast](https://en.wiktionary.org/wiki/cast#Dutch) | cast (people performing a movie or play) | [kɑːst] · noun |
| [chi](https://en.wiktionary.org/wiki/chi#Dutch) | chi (letter of the Greek alphabet) | /xi/ · noun |
| [jam](https://en.wiktionary.org/wiki/jam#Dutch) | jam (congealed sweet mixture of conserved fruits) | /ʒɛm/ · noun |
| [orgaan](https://en.wiktionary.org/wiki/orgaan#Dutch) | organ (part of an organism) | /ɔrˈɣaːn/ · noun |
| [peer](https://en.wiktionary.org/wiki/peer#Dutch) | a pear, a fruit of the pear tree | /peːr/ · noun |
| [worst](https://en.wiktionary.org/wiki/worst#Dutch) | sausage | /ʋɔrst/ · noun |
| [yes](https://en.wiktionary.org/wiki/yes#Dutch) | yay (exclamation of happiness or enthusiasm) | /jɛs/ · intj |
| [Duitser](https://en.wiktionary.org/wiki/Duitser#Dutch) | German (person) | /ˈdœy̯t.sər/ · noun |
| [beet](https://en.wiktionary.org/wiki/beet#Dutch) | bite | /beːt/ · noun |
| [fauna](https://en.wiktionary.org/wiki/fauna#Dutch) | fauna, the animal life inhabiting an area | /ˈfɑu̯.naː/ · noun |
| [polder](https://en.wiktionary.org/wiki/polder#Dutch) | polder (land reclaimed from a body of water and enclosed by dykes) | /ˈpɔl.dər/ · noun |
| [tik](https://en.wiktionary.org/wiki/tik#Dutch) | tick (a kind of sound) | /tɪk/ · noun |
| [truck](https://en.wiktionary.org/wiki/truck#Dutch) | truck, lorry (heavy motor vehicle designed to carry goods) | /tryk/ · noun |
| [vrucht](https://en.wiktionary.org/wiki/vrucht#Dutch) | fruit (often edible, seed-bearing part of a plant) | /vrʏxt/ · noun |
| [wee](https://en.wiktionary.org/wiki/wee#Dutch) | nauseating | /ʋeː/ · adj |
| [clown](https://en.wiktionary.org/wiki/clown#Dutch) | clown (entertainer) | /klɑu̯n/ · noun |
| [diesel](https://en.wiktionary.org/wiki/diesel#Dutch) | diesel | /ˈdi.zəl/ · noun |
| [drone](https://en.wiktionary.org/wiki/drone#Dutch) | drone (unmanned aircraft) | /droːn/ · noun |
| [emmer](https://en.wiktionary.org/wiki/emmer#Dutch) | bucket (container) | /ˈɛ.mər/ · noun |
| [goal](https://en.wiktionary.org/wiki/goal#Dutch) | goal, target in sports, especially soccer | /ɡoːl/ · noun |
| [hamburger](https://en.wiktionary.org/wiki/hamburger#Dutch) | hamburger |  · noun |
| [hype](https://en.wiktionary.org/wiki/hype#Dutch) | hype | /ɦɑi̯p/ · noun |
| [rang](https://en.wiktionary.org/wiki/rang#Dutch) | rank | /rɑŋ/ · noun |
| [sound](https://en.wiktionary.org/wiki/sound#Dutch) | sound (distinctive style and sonority of a particular musician, orchestra etc.) | /sɑu̯nt/ · noun |
| [vel](https://en.wiktionary.org/wiki/vel#Dutch) | a skin, a hide | /vɛl/ · noun |
| [beat](https://en.wiktionary.org/wiki/beat#Dutch) | a beat, a rhythmic pattern, notably in music | /bit/ · noun |
| [dialect](https://en.wiktionary.org/wiki/dialect#Dutch) | dialect (language variety) | /ˌdijaːˈlɛkt/ · noun |
| [holocaust](https://en.wiktionary.org/wiki/holocaust#Dutch) | holocaust, genocide | /ˈɦoː.loːˌkɑu̯st/ · noun |
| [hut](https://en.wiktionary.org/wiki/hut#Dutch) | a small wooden shed, hut | /ɦʏt/ · noun |
| [keeper](https://en.wiktionary.org/wiki/keeper#Dutch) | keeper, goalie | /kipər/ · noun |
| [ode](https://en.wiktionary.org/wiki/ode#Dutch) | ode (lyrical poem, usually in praise of something or someone) | /ˈoː.də/ · noun |
| [palm](https://en.wiktionary.org/wiki/palm#Dutch) | palm (tropical tree of the family Palmae) | /pɑlm/ · noun |
| [shot](https://en.wiktionary.org/wiki/shot#Dutch) | shot (sequence of frames) | /ʃɔt/ · noun |
| [talk](https://en.wiktionary.org/wiki/talk#Dutch) | talc (soft, fine-grained mineral used in talcum powder) |  · noun |
| [baron](https://en.wiktionary.org/wiki/baron#Dutch) | baron, a specific aristocratic title | /baːˈrɔn/ · noun |
| [coup](https://en.wiktionary.org/wiki/coup#Dutch) | a coup, a coup d'état, a putsch | /ku(p)/ · noun |

</details>

<details><summary>Words 901–950</summary>

![[Resources/Audio/nl/Words 0901-0950.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [disco](https://en.wiktionary.org/wiki/disco#Dutch) | a discotheque, a nightclub | /ˈdɪs.koː/ · noun |
| [emo](https://en.wiktionary.org/wiki/emo#Dutch) | emo (form of guitar-driven alternative rock that is particularly or notably emotional; esp. a style of pop punk or hardcore punk) | /ˈiː.moː/ · noun |
| [joh](https://en.wiktionary.org/wiki/joh#Dutch) | Used to address someone, somewhat like dude or mate. | /jɔ(ː)/ · intj |
| [kit](https://en.wiktionary.org/wiki/kit#Dutch) | metal can, used mainly for coal | /kɪt/ · noun |
| [pat](https://en.wiktionary.org/wiki/pat#Dutch) | tie, draw, stalemate | /pɑt/ · noun |
| [si](https://en.wiktionary.org/wiki/si#Dutch) | musical note; ti | /si/ · noun |
| [vleugel](https://en.wiktionary.org/wiki/vleugel#Dutch) | wing to fly with | /ˈvløː.ɣəl/ · noun |
| [filter](https://en.wiktionary.org/wiki/filter#Dutch) | a filter (dense mesh or fabric used for filtration) | /ˈfɪl.tər/ · noun |
| [kam](https://en.wiktionary.org/wiki/kam#Dutch) | a comb, utensil to groom hair, fur etc. | /kɑm/ · noun |
| [pol](https://en.wiktionary.org/wiki/pol#Dutch) | a bundle of plants, with the soil it stands on or that hangs from it | /pɔl/ · noun |
| [ra](https://en.wiktionary.org/wiki/ra#Dutch) | spar (horizontal beam or pole of a ship's mastwork) | /raː/ · noun |
| [trans](https://en.wiktionary.org/wiki/trans#Dutch) | trans (transgender or transsexual) | /trɑns/ · adj |
| [bingo](https://en.wiktionary.org/wiki/bingo#Dutch) | bingo (a game of chance) | /ˈbɪŋ.ɡoː/ · noun |
| [bont](https://en.wiktionary.org/wiki/bont#Dutch) | fur | /bɔnt/ · noun |
| [canvas](https://en.wiktionary.org/wiki/canvas#Dutch) | canvas, sail | /ˈkɑn.vɑs/ · noun |
| [concern](https://en.wiktionary.org/wiki/concern#Dutch) | company, business, concern | /kɔnˈsʏrn/ · noun |
| [drop](https://en.wiktionary.org/wiki/drop#Dutch) | droplet | /drɔp/ · noun |
| [passage](https://en.wiktionary.org/wiki/passage#Dutch) | a passage, a stage of a journey | /ˌpɑˈsaː.ʒə/ · noun |
| [reus](https://en.wiktionary.org/wiki/reus#Dutch) | giant | /røːs/ · noun |
| [sec](https://en.wiktionary.org/wiki/sec#Dutch) | dry | /sɛk/ · adj |
| [sleep](https://en.wiktionary.org/wiki/sleep#Dutch) | dragging, towing | /sleːp/ · noun |
| [tool](https://en.wiktionary.org/wiki/tool#Dutch) | a tool, aid, instrument, auxiliary device | /tuːl/ · noun |
| [canon](https://en.wiktionary.org/wiki/canon#Dutch) | canon (set of representative or pre-eminent literary works) | /ˈkaː.nɔn/ · noun |
| [dos](https://en.wiktionary.org/wiki/dos#Dutch) | garb, clothing, especially extravagant or unusual clothes | /dɔs/ · noun |
| [hap](https://en.wiktionary.org/wiki/hap#Dutch) | bite | /ɦɑp/ · noun |
| [image](https://en.wiktionary.org/wiki/image#Dutch) | image (characteristic perceived by others) |  · noun |
| [klim](https://en.wiktionary.org/wiki/klim#Dutch) | climb, act of climbing | /klɪm/ · noun |
| [ladder](https://en.wiktionary.org/wiki/ladder#Dutch) | a ladder | /ˈlɑ.dər/ · noun |
| [marge](https://en.wiktionary.org/wiki/marge#Dutch) | margin |  · noun |
| [pil](https://en.wiktionary.org/wiki/pil#Dutch) | a pill, a usually ball- or oval-shaped, coated portion of a drug to be taken orally | /pɪl/ · noun |
| [pit](https://en.wiktionary.org/wiki/pit#Dutch) | a seed inside a fruit | /pɪt/ · noun |
| [resort](https://en.wiktionary.org/wiki/resort#Dutch) | a resort (place with recreational environment for holidays) | /riˈzɔrt/ · noun |
| [statement](https://en.wiktionary.org/wiki/statement#Dutch) | statement, declaration | /ˈsteːtmənt/ · noun |
| [um](https://en.wiktionary.org/wiki/um#Dutch) | um (expressing hesitation) |  · intj |
| [woordenboek](https://en.wiktionary.org/wiki/woordenboek#Dutch) | dictionary | /ˈʋoːrdə(n)ˌbuk/ · noun |
| [ark](https://en.wiktionary.org/wiki/ark#Dutch) | ark (ark of the covenant) | /ɑrk/ · noun |
| [bachelor](https://en.wiktionary.org/wiki/bachelor#Dutch) | a bachelor's degree; the first or lowest academic degree conferred by colleges and universities. | /ˈbɛ.tʃə.lər/ · noun |
| [boren](https://en.wiktionary.org/wiki/boren#Dutch) | to drill | /ˈboːrə(n)/ · verb |
| [corrupt](https://en.wiktionary.org/wiki/corrupt#Dutch) | corrupt (lacking integrity, being prone to discriminating, open to bribes, etc.) | /kɔˈrʏpt/ · adj |
| [defect](https://en.wiktionary.org/wiki/defect#Dutch) | broken, not working | /deːˈfɛkt/ · adj |
| [flirten](https://en.wiktionary.org/wiki/flirten#Dutch) | to flirt | /ˈflʏrtə(n)/ · verb |
| [gala](https://en.wiktionary.org/wiki/gala#Dutch) | a ceremonial celebration, originally a ball (formal dance), now often a prom | /ˈɣaː.laː/ · noun |
| [haas](https://en.wiktionary.org/wiki/haas#Dutch) | hare, lagomorph of the genus Lepus | /ɦaːs/ · noun |
| [pin](https://en.wiktionary.org/wiki/pin#Dutch) | peg, pin | /pɪn/ · noun |
| [roots](https://en.wiktionary.org/wiki/roots#Dutch) | roots (ancestry, origin) |  · noun |
| [spelling](https://en.wiktionary.org/wiki/spelling#Dutch) | spelling | /ˈspɛ.lɪŋ/ · noun |
| [step](https://en.wiktionary.org/wiki/step#Dutch) | kick scooter | /stɛp/ · noun |
| [stick](https://en.wiktionary.org/wiki/stick#Dutch) | a hockey stick | /stɪk/ · noun |
| [vagina](https://en.wiktionary.org/wiki/vagina#Dutch) | vagina | /ˈvaːɣinaː/ · noun |
| [visum](https://en.wiktionary.org/wiki/visum#Dutch) | visa (permit for entering or leaving a country) | /ˈvi.zʏm/ · noun |

</details>

<details><summary>Words 951–1000</summary>

![[Resources/Audio/nl/Words 0951-1000.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [whisky](https://en.wiktionary.org/wiki/whisky#Dutch) | whisky, whiskey | /ˈʋɪski/ · noun |
| [zeventien](https://en.wiktionary.org/wiki/zeventien#Dutch) | seventeen | /ˈzeːvə(n)tin/ · num |
| [arrogant](https://en.wiktionary.org/wiki/arrogant#Dutch) | arrogant | /ˌɑ.roːˈɣɑnt/ · adj |
| [baden](https://en.wiktionary.org/wiki/baden#Dutch) | to bathe | /ˈbaːdə(n)/ · verb |
| [comfort](https://en.wiktionary.org/wiki/comfort#Dutch) | physical comfort, ease | /kɔmˈfɔːr/ · noun |
| [cruise](https://en.wiktionary.org/wiki/cruise#Dutch) | cruise | /kruːs/ · noun |
| [pardon](https://en.wiktionary.org/wiki/pardon#Dutch) | I'm sorry, pardon | /pɑrˈdɔn/ · intj |
| [sol](https://en.wiktionary.org/wiki/sol#Dutch) | sol (the fifth step in the solfège scale of C, preceded by fa and followed by la) | /sɔl/ · noun |
| [tattoo](https://en.wiktionary.org/wiki/tattoo#Dutch) | tattoo | /taːˈtu/ · noun |
| [amen](https://en.wiktionary.org/wiki/amen#Dutch) | amen, so be it (at the end of a religious prayer) | /ˈaː.mə(n)/ · intj |
| [brink](https://en.wiktionary.org/wiki/brink#Dutch) | village green, functioning as a central square | /brɪŋk/ · noun |
| [coma](https://en.wiktionary.org/wiki/coma#Dutch) | coma (state of unconsciousness) | /ˈkoː.maː/ · noun |
| [gans](https://en.wiktionary.org/wiki/gans#Dutch) | whole, entire | /ɣɑns/ · det |
| [gift](https://en.wiktionary.org/wiki/gift#Dutch) | donation; something given (away) voluntarily | /ɣɪft/ · noun |
| [import](https://en.wiktionary.org/wiki/import#Dutch) | geographical import | /ˈɪm.pɔrt/ · noun |
| [intact](https://en.wiktionary.org/wiki/intact#Dutch) | intact | /ɪnˈtɑkt/ · adj |
| [kraken](https://en.wiktionary.org/wiki/kraken#Dutch) | to crack, break open (a shell) | /ˈkraːkə(n)/ · verb |
| [mal](https://en.wiktionary.org/wiki/mal#Dutch) | mold, cast (device to help creating shapes) | /mɑl/ · noun |
| [pomp](https://en.wiktionary.org/wiki/pomp#Dutch) | pump (device for moving liquid or gas) | /pɔmp/ · noun |
| [sein](https://en.wiktionary.org/wiki/sein#Dutch) | signal | /sɛi̯n/ · noun |
| [wade](https://en.wiktionary.org/wiki/wade#Dutch) | popliteus | /ˈʋaː.də/ · noun |
| [base](https://en.wiktionary.org/wiki/base#Dutch) | base, alkali | /ˈbaː.zə/ · noun |
| [copyright](https://en.wiktionary.org/wiki/copyright#Dutch) | copyright |  · noun |
| [episode](https://en.wiktionary.org/wiki/episode#Dutch) | an episode (instalment) | /ˌeː.piˈsoː.də/ · noun |
| [flow](https://en.wiktionary.org/wiki/flow#Dutch) | rhythm, flow of music (particularly in jazz) | /floː/ · noun |
| [gamma](https://en.wiktionary.org/wiki/gamma#Dutch) | gamma (Greek letter) |  · noun |
| [monitor](https://en.wiktionary.org/wiki/monitor#Dutch) | screen, display | /ˈmoː.niˌtɔr/ · noun |
| [pal](https://en.wiktionary.org/wiki/pal#Dutch) | catch (mechanism which stops something from moving the wrong way) | /pɑl/ · noun |
| [pater](https://en.wiktionary.org/wiki/pater#Dutch) | father (as a religious title) | /ˈpaː.tər/ · noun |
| [urine](https://en.wiktionary.org/wiki/urine#Dutch) | urine | /yˈri.nə/ · noun |
| [wier](https://en.wiktionary.org/wiki/wier#Dutch) | seaweed | /ʋir/ · noun |
| [cocktail](https://en.wiktionary.org/wiki/cocktail#Dutch) | cocktail | /ˈkɔkteːl/ · noun |
| [diabetes](https://en.wiktionary.org/wiki/diabetes#Dutch) | diabetes | /ˌdi.aːˈbeː.təs/ · noun |
| [para](https://en.wiktionary.org/wiki/para#Dutch) | para (paratrooper) |  · noun |
| [switch](https://en.wiktionary.org/wiki/switch#Dutch) | switch (act of switching) |  · noun |
| [volt](https://en.wiktionary.org/wiki/volt#Dutch) | volt (unit) |  · noun |
| [cannabis](https://en.wiktionary.org/wiki/cannabis#Dutch) | cannabis, plant of the genus Cannabis, especially Cannabis sativa or Cannabis indica | /ˈkɑ.naːˌbɪs/ · noun |
| [laser](https://en.wiktionary.org/wiki/laser#Dutch) | laser (monochromatic, coherent beam of light) | /ˈleː.zər/ · noun |
| [modem](https://en.wiktionary.org/wiki/modem#Dutch) | modem | /ˈmoːdəm/ · noun |
| [parallel](https://en.wiktionary.org/wiki/parallel#Dutch) | parallel (all senses) | /ˌpaː.rɑˈlɛl/ · noun |
| [quiz](https://en.wiktionary.org/wiki/quiz#Dutch) | quiz | /kʋɪs/ · noun |
| [sauna](https://en.wiktionary.org/wiki/sauna#Dutch) | sauna | /ˈsɑu̯.naː/ · noun |
| [wake](https://en.wiktionary.org/wiki/wake#Dutch) | a wake (a gathering to remember a dead person) | /ˈʋaː.kə/ · noun |
| [wieg](https://en.wiktionary.org/wiki/wieg#Dutch) | cradle | /ʋix/ · noun |
| [bah](https://en.wiktionary.org/wiki/bah#Dutch) | An exclamation of disapproval, contempt or disgust: bah, yuck | /bɑ/ · intj |
| [gate](https://en.wiktionary.org/wiki/gate#Dutch) | airport gate |  · noun |
| [joint](https://en.wiktionary.org/wiki/joint#Dutch) | joint, marijuana cigarette (generally larger than a stickie) | /dʒɔi̯nt/ · noun |
| [kin](https://en.wiktionary.org/wiki/kin#Dutch) | chin | /kɪn/ · noun |
| [kudde](https://en.wiktionary.org/wiki/kudde#Dutch) | herd; collective noun for cows, (koeien), horses (paarden), elephants (olifanten) or camels (kamelen) | /ˈkʏdə/ · noun |
| [lier](https://en.wiktionary.org/wiki/lier#Dutch) | lyre | /lir/ · noun |

</details>

## Question bank

Try before opening the answers. Different tasks use the same sentence to practise complementary skills. Open translation and explanation tasks can have valid alternatives.

### De and het · 50 questions

**nl-Q0001 · Fill the gap**

Mexico-Stad is ____ hoofdstad van Mexico.

Mexico City is the capital of Mexico.

[[Dutch#^nl-Q0001-answer|Compare the answer]]
^nl-Q0001

**nl-Q0002 · Choose the form**

Mexico-Stad is ____ hoofdstad van Mexico.

Mexico City is the capital of Mexico.

Choices: de / een / het

[[Dutch#^nl-Q0002-answer|Compare the answer]]
^nl-Q0002

**nl-Q0003 · Edit the changed sentence**

【de】 vrouwenhater moet je echt zo hard vertrouwen als het weer.

We must trust misogynists as much as we can trust the weather.

[[Dutch#^nl-Q0003-answer|Compare the answer]]
^nl-Q0003

**nl-Q0004 · Build the sentence**

Arrange: hard / vertrouwen / als / Een / het / weer. / zo / echt / moet / je / vrouwenhater

We must trust misogynists as much as we can trust the weather.

[[Dutch#^nl-Q0004-answer|Compare the answer]]
^nl-Q0004

**nl-Q0005 · Write a translation**

Write this in Dutch: I'm in the kitchen.

[[Dutch#^nl-Q0005-answer|Compare the answer]]
^nl-Q0005

**nl-Q0006 · Explain the grammar**

Ik ben in 【de】 keuken.

I'm in the kitchen.

[[Dutch#^nl-Q0006-answer|Compare the answer]]
^nl-Q0006

**nl-Q0007 · Fill the gap**

Wat ____ geluk!

How lucky!

[[Dutch#^nl-Q0007-answer|Compare the answer]]
^nl-Q0007

**nl-Q0008 · Choose the form**

Wat ____ geluk!

How lucky!

Choices: de / het / een

[[Dutch#^nl-Q0008-answer|Compare the answer]]
^nl-Q0008

**nl-Q0009 · Edit the changed sentence**

Jullie voorstel is 【de】 beetje extreem.

Your proposal is a bit extreme.

[[Dutch#^nl-Q0009-answer|Compare the answer]]
^nl-Q0009

**nl-Q0010 · Build the sentence**

Arrange: Jullie / een / extreem. / voorstel / is / beetje

Your proposal is a bit extreme.

[[Dutch#^nl-Q0010-answer|Compare the answer]]
^nl-Q0010

**nl-Q0011 · Write a translation**

Write this in Dutch: This is an orange tree.

[[Dutch#^nl-Q0011-answer|Compare the answer]]
^nl-Q0011

**nl-Q0012 · Explain the grammar**

Dit is 【een】 sinaasappelboom.

This is an orange tree.

[[Dutch#^nl-Q0012-answer|Compare the answer]]
^nl-Q0012

**nl-Q0013 · Fill the gap**

Hoeveel gaat ____ kosten?

How much will it cost?

[[Dutch#^nl-Q0013-answer|Compare the answer]]
^nl-Q0013

**nl-Q0014 · Choose the form**

Hoeveel gaat ____ kosten?

How much will it cost?

Choices: de / het / een

[[Dutch#^nl-Q0014-answer|Compare the answer]]
^nl-Q0014

**nl-Q0015 · Edit the changed sentence**

Heb je 【de】 kaartje?

Do you have a ticket?

[[Dutch#^nl-Q0015-answer|Compare the answer]]
^nl-Q0015

**nl-Q0016 · Build the sentence**

Arrange: een / Heb / je / kaartje?

Do you have a ticket?

[[Dutch#^nl-Q0016-answer|Compare the answer]]
^nl-Q0016

**nl-Q0017 · Write a translation**

Write this in Dutch: The princess must die.

[[Dutch#^nl-Q0017-answer|Compare the answer]]
^nl-Q0017

**nl-Q0018 · Explain the grammar**

【De】 prinses moet sterven.

The princess must die.

[[Dutch#^nl-Q0018-answer|Compare the answer]]
^nl-Q0018

**nl-Q0019 · Fill the gap**

Hij hervatte zijn werk na ____ korte pauze.

He continued his work after a short break.

[[Dutch#^nl-Q0019-answer|Compare the answer]]
^nl-Q0019

**nl-Q0020 · Choose the form**

Hij hervatte zijn werk na ____ korte pauze.

He continued his work after a short break.

Choices: een / het / de

[[Dutch#^nl-Q0020-answer|Compare the answer]]
^nl-Q0020

**nl-Q0021 · Edit the changed sentence**

【de】 is niet duidelijk of ze zal instemmen.

It isn't clear whether she would agree.

[[Dutch#^nl-Q0021-answer|Compare the answer]]
^nl-Q0021

**nl-Q0022 · Build the sentence**

Arrange: Het / of / instemmen. / duidelijk / ze / is / niet / zal

It isn't clear whether she would agree.

[[Dutch#^nl-Q0022-answer|Compare the answer]]
^nl-Q0022

**nl-Q0023 · Write a translation**

Write this in Dutch: The accident happened two hours ago.

[[Dutch#^nl-Q0023-answer|Compare the answer]]
^nl-Q0023

**nl-Q0024 · Explain the grammar**

【Het】 ongeval gebeurde twee uur geleden.

The accident happened two hours ago.

[[Dutch#^nl-Q0024-answer|Compare the answer]]
^nl-Q0024

**nl-Q0025 · Fill the gap**

Ik studeer ____ al vijf jaar.

I have been studying it for five years.

[[Dutch#^nl-Q0025-answer|Compare the answer]]
^nl-Q0025

**nl-Q0026 · Choose the form**

Ik studeer ____ al vijf jaar.

I have been studying it for five years.

Choices: het / een / de

[[Dutch#^nl-Q0026-answer|Compare the answer]]
^nl-Q0026

**nl-Q0027 · Edit the changed sentence**

Niet één van mijn klasgenoten woont hier in 【het】 buurt.

None of my classmates live near here.

[[Dutch#^nl-Q0027-answer|Compare the answer]]
^nl-Q0027

**nl-Q0028 · Build the sentence**

Arrange: klasgenoten / woont / Niet / van / buurt. / mijn / in / één / de / hier

None of my classmates live near here.

[[Dutch#^nl-Q0028-answer|Compare the answer]]
^nl-Q0028

**nl-Q0029 · Write a translation**

Write this in Dutch: Do you need a torch?

[[Dutch#^nl-Q0029-answer|Compare the answer]]
^nl-Q0029

**nl-Q0030 · Explain the grammar**

Hebt u 【een】 zaklamp nodig?

Do you need a torch?

[[Dutch#^nl-Q0030-answer|Compare the answer]]
^nl-Q0030

**nl-Q0031 · Fill the gap**

____ bloem is geel.

The flower is yellow.

[[Dutch#^nl-Q0031-answer|Compare the answer]]
^nl-Q0031

**nl-Q0032 · Choose the form**

____ bloem is geel.

The flower is yellow.

Choices: het / een / De

[[Dutch#^nl-Q0032-answer|Compare the answer]]
^nl-Q0032

**nl-Q0033 · Edit the changed sentence**

【de】 is erg warm vandaag.

It is very hot today.

[[Dutch#^nl-Q0033-answer|Compare the answer]]
^nl-Q0033

**nl-Q0034 · Build the sentence**

Arrange: warm / vandaag. / is / Het / erg

It is very hot today.

[[Dutch#^nl-Q0034-answer|Compare the answer]]
^nl-Q0034

**nl-Q0035 · Write a translation**

Write this in Dutch: Do you enjoy the work?

[[Dutch#^nl-Q0035-answer|Compare the answer]]
^nl-Q0035

**nl-Q0036 · Explain the grammar**

Doe je 【het】 werk graag?

Do you enjoy the work?

[[Dutch#^nl-Q0036-answer|Compare the answer]]
^nl-Q0036

**nl-Q0037 · Fill the gap**

Tom was niet in staat om ____ job te houden of om op zichzelf te leven.

Tom was unable to hold a job or live by himself.

[[Dutch#^nl-Q0037-answer|Compare the answer]]
^nl-Q0037

**nl-Q0038 · Choose the form**

Tom was niet in staat om ____ job te houden of om op zichzelf te leven.

Tom was unable to hold a job or live by himself.

Choices: de / het / een

[[Dutch#^nl-Q0038-answer|Compare the answer]]
^nl-Q0038

**nl-Q0039 · Edit the changed sentence**

【de】 hele land was bedolven onder sneeuw.

The whole country was buried under snow.

[[Dutch#^nl-Q0039-answer|Compare the answer]]
^nl-Q0039

**nl-Q0040 · Build the sentence**

Arrange: Het / sneeuw. / bedolven / hele / onder / land / was

The whole country was buried under snow.

[[Dutch#^nl-Q0040-answer|Compare the answer]]
^nl-Q0040

**nl-Q0041 · Write a translation**

Write this in Dutch: Paolo is a nice person.

[[Dutch#^nl-Q0041-answer|Compare the answer]]
^nl-Q0041

**nl-Q0042 · Explain the grammar**

Paolo is 【een】 vriendelijk persoon.

Paolo is a nice person.

[[Dutch#^nl-Q0042-answer|Compare the answer]]
^nl-Q0042

**nl-Q0043 · Fill the gap**

Laat ____ me weten als iemand iets heeft gezien.

If anyone saw anything, I want to know.

[[Dutch#^nl-Q0043-answer|Compare the answer]]
^nl-Q0043

**nl-Q0044 · Choose the form**

Laat ____ me weten als iemand iets heeft gezien.

If anyone saw anything, I want to know.

Choices: een / de / het

[[Dutch#^nl-Q0044-answer|Compare the answer]]
^nl-Q0044

**nl-Q0045 · Edit the changed sentence**

Waar is 【het】 Hongaarse ambassade?

Where is the Hungarian embassy?

[[Dutch#^nl-Q0045-answer|Compare the answer]]
^nl-Q0045

**nl-Q0046 · Build the sentence**

Arrange: Waar / de / Hongaarse / is / ambassade?

Where is the Hungarian embassy?

[[Dutch#^nl-Q0046-answer|Compare the answer]]
^nl-Q0046

**nl-Q0047 · Write a translation**

Write this in Dutch: She accompanied me on the piano.

[[Dutch#^nl-Q0047-answer|Compare the answer]]
^nl-Q0047

**nl-Q0048 · Explain the grammar**

Ze begeleidde mij op 【de】 piano.

She accompanied me on the piano.

[[Dutch#^nl-Q0048-answer|Compare the answer]]
^nl-Q0048

**nl-Q0049 · Fill the gap**

Er is niks mis met ____ idee.

There is nothing wrong with the idea.

[[Dutch#^nl-Q0049-answer|Compare the answer]]
^nl-Q0049

**nl-Q0050 · Choose the form**

Er is niks mis met ____ idee.

There is nothing wrong with the idea.

Choices: het / de / een

[[Dutch#^nl-Q0050-answer|Compare the answer]]
^nl-Q0050


### Demonstratives · 50 questions

**nl-Q0051 · Edit the changed sentence**

【dat】 boek was gemakkelijk.

This book was easy.

[[Dutch#^nl-Q0051-answer|Compare the answer]]
^nl-Q0051

**nl-Q0052 · Build the sentence**

Arrange: gemakkelijk. / was / boek / Dit

This book was easy.

[[Dutch#^nl-Q0052-answer|Compare the answer]]
^nl-Q0052

**nl-Q0053 · Write a translation**

Write this in Dutch: I don't know how they did it.

[[Dutch#^nl-Q0053-answer|Compare the answer]]
^nl-Q0053

**nl-Q0054 · Explain the grammar**

Ik heb geen idee hoe ze 【dat】 voor elkaar gekregen hebben.

I don't know how they did it.

[[Dutch#^nl-Q0054-answer|Compare the answer]]
^nl-Q0054

**nl-Q0055 · Fill the gap**

Wie heeft je ____ aangedaan?

Who did this to you?

[[Dutch#^nl-Q0055-answer|Compare the answer]]
^nl-Q0055

**nl-Q0056 · Choose the form**

Wie heeft je ____ aangedaan?

Who did this to you?

Choices: dit / dat / deze / die

[[Dutch#^nl-Q0056-answer|Compare the answer]]
^nl-Q0056

**nl-Q0057 · Edit the changed sentence**

Waarom weet jij 【dit】?

Why do you know that?

[[Dutch#^nl-Q0057-answer|Compare the answer]]
^nl-Q0057

**nl-Q0058 · Build the sentence**

Arrange: jij / dat? / Waarom / weet

Why do you know that?

[[Dutch#^nl-Q0058-answer|Compare the answer]]
^nl-Q0058

**nl-Q0059 · Write a translation**

Write this in Dutch: What the hell is that?

[[Dutch#^nl-Q0059-answer|Compare the answer]]
^nl-Q0059

**nl-Q0060 · Explain the grammar**

Wat moet 【dat】 voorstellen?

What the hell is that?

[[Dutch#^nl-Q0060-answer|Compare the answer]]
^nl-Q0060

**nl-Q0061 · Fill the gap**

Tom zei ____ hij geen vrijwilligers meer nodig had.

Tom said he didn't need any more volunteers.

[[Dutch#^nl-Q0061-answer|Compare the answer]]
^nl-Q0061

**nl-Q0062 · Choose the form**

Tom zei ____ hij geen vrijwilligers meer nodig had.

Tom said he didn't need any more volunteers.

Choices: dit / dat / die / deze

[[Dutch#^nl-Q0062-answer|Compare the answer]]
^nl-Q0062

**nl-Q0063 · Edit the changed sentence**

Denk je 【dit】 Tom kaal wordt?

Do you think Tom is going bald?

[[Dutch#^nl-Q0063-answer|Compare the answer]]
^nl-Q0063

**nl-Q0064 · Build the sentence**

Arrange: dat / wordt? / Tom / Denk / je / kaal

Do you think Tom is going bald?

[[Dutch#^nl-Q0064-answer|Compare the answer]]
^nl-Q0064

**nl-Q0065 · Write a translation**

Write this in Dutch: We've been told not to do that.

[[Dutch#^nl-Q0065-answer|Compare the answer]]
^nl-Q0065

**nl-Q0066 · Explain the grammar**

Ons is verteld 【dat】 we dat niet mogen doen.

We've been told not to do that.

[[Dutch#^nl-Q0066-answer|Compare the answer]]
^nl-Q0066

**nl-Q0067 · Fill the gap**

Op ____ moment zijn we bezig.

We're busy right now.

[[Dutch#^nl-Q0067-answer|Compare the answer]]
^nl-Q0067

**nl-Q0068 · Choose the form**

Op ____ moment zijn we bezig.

We're busy right now.

Choices: die / dit / deze / dat

[[Dutch#^nl-Q0068-answer|Compare the answer]]
^nl-Q0068

**nl-Q0069 · Edit the changed sentence**

Ik denk 【dit】 ik verliefd ben.

I think I'm in love.

[[Dutch#^nl-Q0069-answer|Compare the answer]]
^nl-Q0069

**nl-Q0070 · Build the sentence**

Arrange: denk / Ik / ben. / verliefd / dat / ik

I think I'm in love.

[[Dutch#^nl-Q0070-answer|Compare the answer]]
^nl-Q0070

**nl-Q0071 · Write a translation**

Write this in Dutch: I have to choose between these two.

[[Dutch#^nl-Q0071-answer|Compare the answer]]
^nl-Q0071

**nl-Q0072 · Explain the grammar**

Ik moet kiezen tussen 【die】 twee.

I have to choose between these two.

[[Dutch#^nl-Q0072-answer|Compare the answer]]
^nl-Q0072

**nl-Q0073 · Fill the gap**

Kun je ____ pan even voor me opbeuren, dan leg ik deze onderzetter eronder.

Could you lift that pan for me, then I'll put this mat under it.

[[Dutch#^nl-Q0073-answer|Compare the answer]]
^nl-Q0073

**nl-Q0074 · Choose the form**

Kun je ____ pan even voor me opbeuren, dan leg ik deze onderzetter eronder.

Could you lift that pan for me, then I'll put this mat under it.

Choices: dit / deze / die / dat

[[Dutch#^nl-Q0074-answer|Compare the answer]]
^nl-Q0074

**nl-Q0075 · Edit the changed sentence**

Je mag 【dit】 niet aan je ouders vertellen.

You mustn't tell that to your parents.

[[Dutch#^nl-Q0075-answer|Compare the answer]]
^nl-Q0075

**nl-Q0076 · Build the sentence**

Arrange: mag / niet / dat / Je / aan / ouders / je / vertellen.

You mustn't tell that to your parents.

[[Dutch#^nl-Q0076-answer|Compare the answer]]
^nl-Q0076

**nl-Q0077 · Write a translation**

Write this in Dutch: Tom wouldn't want to do that.

[[Dutch#^nl-Q0077-answer|Compare the answer]]
^nl-Q0077

**nl-Q0078 · Explain the grammar**

Tom zou 【dat】 niet willen doen.

Tom wouldn't want to do that.

[[Dutch#^nl-Q0078-answer|Compare the answer]]
^nl-Q0078

**nl-Q0079 · Fill the gap**

____ vork is niet schoon.

This fork isn't clean.

[[Dutch#^nl-Q0079-answer|Compare the answer]]
^nl-Q0079

**nl-Q0080 · Choose the form**

____ vork is niet schoon.

This fork isn't clean.

Choices: Deze / dat / die / dit

[[Dutch#^nl-Q0080-answer|Compare the answer]]
^nl-Q0080

**nl-Q0081 · Edit the changed sentence**

Ik heb 【dat】 stripboek van zijn zus geleend.

I borrowed this comic book from his sister.

[[Dutch#^nl-Q0081-answer|Compare the answer]]
^nl-Q0081

**nl-Q0082 · Build the sentence**

Arrange: heb / stripboek / geleend. / dit / Ik / zus / van / zijn

I borrowed this comic book from his sister.

[[Dutch#^nl-Q0082-answer|Compare the answer]]
^nl-Q0082

**nl-Q0083 · Write a translation**

Write this in Dutch: I live in this area.

[[Dutch#^nl-Q0083-answer|Compare the answer]]
^nl-Q0083

**nl-Q0084 · Explain the grammar**

Ik woon in 【dit】 gebied.

I live in this area.

[[Dutch#^nl-Q0084-answer|Compare the answer]]
^nl-Q0084

**nl-Q0085 · Fill the gap**

Mijn zoon denkt ____ vrouwen sterker dan mannen zijn.

My son thinks women are stronger than men.

[[Dutch#^nl-Q0085-answer|Compare the answer]]
^nl-Q0085

**nl-Q0086 · Choose the form**

Mijn zoon denkt ____ vrouwen sterker dan mannen zijn.

My son thinks women are stronger than men.

Choices: deze / dit / die / dat

[[Dutch#^nl-Q0086-answer|Compare the answer]]
^nl-Q0086

**nl-Q0087 · Edit the changed sentence**

Hij is precies degene 【dit】 je zoekt.

He is precisely the one you are looking for.

[[Dutch#^nl-Q0087-answer|Compare the answer]]
^nl-Q0087

**nl-Q0088 · Build the sentence**

Arrange: precies / degene / is / Hij / je / die / zoekt.

He is precisely the one you are looking for.

[[Dutch#^nl-Q0088-answer|Compare the answer]]
^nl-Q0088

**nl-Q0089 · Write a translation**

Write this in Dutch: I'm sure Tom wouldn't like it.

[[Dutch#^nl-Q0089-answer|Compare the answer]]
^nl-Q0089

**nl-Q0090 · Explain the grammar**

Ik denk wel 【dat】 het Tom niet zou bevallen.

I'm sure Tom wouldn't like it.

[[Dutch#^nl-Q0090-answer|Compare the answer]]
^nl-Q0090

**nl-Q0091 · Fill the gap**

____ stof is erg zacht.

This fabric is very soft.

[[Dutch#^nl-Q0091-answer|Compare the answer]]
^nl-Q0091

**nl-Q0092 · Choose the form**

____ stof is erg zacht.

This fabric is very soft.

Choices: Deze / die / dit / dat

[[Dutch#^nl-Q0092-answer|Compare the answer]]
^nl-Q0092

**nl-Q0093 · Edit the changed sentence**

O, ja, 【dit】 herinner ik me.

Oh, yes, I remember.

[[Dutch#^nl-Q0093-answer|Compare the answer]]
^nl-Q0093

**nl-Q0094 · Build the sentence**

Arrange: herinner / ik / O, / ja, / me. / dat

Oh, yes, I remember.

[[Dutch#^nl-Q0094-answer|Compare the answer]]
^nl-Q0094

**nl-Q0095 · Write a translation**

Write this in Dutch: Tom knew that I was sad.

[[Dutch#^nl-Q0095-answer|Compare the answer]]
^nl-Q0095

**nl-Q0096 · Explain the grammar**

Tom wist 【dat】 ik verdrietig was.

Tom knew that I was sad.

[[Dutch#^nl-Q0096-answer|Compare the answer]]
^nl-Q0096

**nl-Q0097 · Fill the gap**

____ voedsel is ongezond.

This food is unhealthy.

[[Dutch#^nl-Q0097-answer|Compare the answer]]
^nl-Q0097

**nl-Q0098 · Choose the form**

____ voedsel is ongezond.

This food is unhealthy.

Choices: die / dat / Dit / deze

[[Dutch#^nl-Q0098-answer|Compare the answer]]
^nl-Q0098

**nl-Q0099 · Edit the changed sentence**

【dat】 is een persoonlijke kwestie.

This a personal matter.

[[Dutch#^nl-Q0099-answer|Compare the answer]]
^nl-Q0099

**nl-Q0100 · Build the sentence**

Arrange: Dit / is / kwestie. / persoonlijke / een

This a personal matter.

[[Dutch#^nl-Q0100-answer|Compare the answer]]
^nl-Q0100


### Personal pronouns · 50 questions

**nl-Q0101 · Write a translation**

Write this in Dutch: You're worth gold.

[[Dutch#^nl-Q0101-answer|Compare the answer]]
^nl-Q0101

**nl-Q0102 · Explain the grammar**

【Jullie】 zijn goud waard.

You're worth gold.

[[Dutch#^nl-Q0102-answer|Compare the answer]]
^nl-Q0102

**nl-Q0103 · Fill the gap**

____ ga vandaag niet meer werken.

I am not going to work more today.

[[Dutch#^nl-Q0103-answer|Compare the answer]]
^nl-Q0103

**nl-Q0104 · Choose the form**

____ ga vandaag niet meer werken.

I am not going to work more today.

Choices: wij / Ik / hij / jij

[[Dutch#^nl-Q0104-answer|Compare the answer]]
^nl-Q0104

**nl-Q0105 · Edit the changed sentence**

Hoelang moeten 【ik】 wachten, denk je?

How long do you think we'll have to wait?

[[Dutch#^nl-Q0105-answer|Compare the answer]]
^nl-Q0105

**nl-Q0106 · Build the sentence**

Arrange: we / moeten / denk / Hoelang / je? / wachten,

How long do you think we'll have to wait?

[[Dutch#^nl-Q0106-answer|Compare the answer]]
^nl-Q0106

**nl-Q0107 · Write a translation**

Write this in Dutch: Are you allergic to anything?

[[Dutch#^nl-Q0107-answer|Compare the answer]]
^nl-Q0107

**nl-Q0108 · Explain the grammar**

Ben 【je】 voor iets allergisch?

Are you allergic to anything?

[[Dutch#^nl-Q0108-answer|Compare the answer]]
^nl-Q0108

**nl-Q0109 · Fill the gap**

____ ben vanmorgen om zeven uur opgestaan.

I got up at seven this morning.

[[Dutch#^nl-Q0109-answer|Compare the answer]]
^nl-Q0109

**nl-Q0110 · Choose the form**

____ ben vanmorgen om zeven uur opgestaan.

I got up at seven this morning.

Choices: Ik / hij / wij / jij

[[Dutch#^nl-Q0110-answer|Compare the answer]]
^nl-Q0110

**nl-Q0111 · Edit the changed sentence**

Tom had moeten doen wat 【jij】 hem gevraagd heb.

Tom should've done what I asked him to do.

[[Dutch#^nl-Q0111-answer|Compare the answer]]
^nl-Q0111

**nl-Q0112 · Build the sentence**

Arrange: wat / had / doen / moeten / hem / heb. / gevraagd / ik / Tom

Tom should've done what I asked him to do.

[[Dutch#^nl-Q0112-answer|Compare the answer]]
^nl-Q0112

**nl-Q0113 · Write a translation**

Write this in Dutch: I don't want your gold.

[[Dutch#^nl-Q0113-answer|Compare the answer]]
^nl-Q0113

**nl-Q0114 · Explain the grammar**

【Ik】 wil jouw goud niet.

I don't want your gold.

[[Dutch#^nl-Q0114-answer|Compare the answer]]
^nl-Q0114

**nl-Q0115 · Fill the gap**

Telkens wanneer ____ hem zie, herinnert hij me aan mijn overleden grootvader.

Whenever I see him he reminds me of my late grandfather.

[[Dutch#^nl-Q0115-answer|Compare the answer]]
^nl-Q0115

**nl-Q0116 · Choose the form**

Telkens wanneer ____ hem zie, herinnert hij me aan mijn overleden grootvader.

Whenever I see him he reminds me of my late grandfather.

Choices: hij / wij / jij / ik

[[Dutch#^nl-Q0116-answer|Compare the answer]]
^nl-Q0116

**nl-Q0117 · Edit the changed sentence**

Wat 【ik】 zegt is absoluut correct.

What he says is absolutely correct.

[[Dutch#^nl-Q0117-answer|Compare the answer]]
^nl-Q0117

**nl-Q0118 · Build the sentence**

Arrange: is / hij / correct. / zegt / absoluut / Wat

What he says is absolutely correct.

[[Dutch#^nl-Q0118-answer|Compare the answer]]
^nl-Q0118

**nl-Q0119 · Write a translation**

Write this in Dutch: Do you write love letters?

[[Dutch#^nl-Q0119-answer|Compare the answer]]
^nl-Q0119

**nl-Q0120 · Explain the grammar**

Schrijf 【jij】 liefdesbrieven?

Do you write love letters?

[[Dutch#^nl-Q0120-answer|Compare the answer]]
^nl-Q0120

**nl-Q0121 · Fill the gap**

____ drinkt rode wijn.

He drinks red wine.

[[Dutch#^nl-Q0121-answer|Compare the answer]]
^nl-Q0121

**nl-Q0122 · Choose the form**

____ drinkt rode wijn.

He drinks red wine.

Choices: wij / Hij / ik / jij

[[Dutch#^nl-Q0122-answer|Compare the answer]]
^nl-Q0122

**nl-Q0123 · Edit the changed sentence**

【jij】 heb zo veel aan te bieden.

I have so much to offer.

[[Dutch#^nl-Q0123-answer|Compare the answer]]
^nl-Q0123

**nl-Q0124 · Build the sentence**

Arrange: heb / Ik / bieden. / zo / te / aan / veel

I have so much to offer.

[[Dutch#^nl-Q0124-answer|Compare the answer]]
^nl-Q0124

**nl-Q0125 · Write a translation**

Write this in Dutch: Tell me what you are looking for and I will help you.

[[Dutch#^nl-Q0125-answer|Compare the answer]]
^nl-Q0125

**nl-Q0126 · Explain the grammar**

Zeg me wat 【je】 zoekt en ik zal je helpen.

Tell me what you are looking for and I will help you.

[[Dutch#^nl-Q0126-answer|Compare the answer]]
^nl-Q0126

**nl-Q0127 · Fill the gap**

____ heb met Tom geoefend.

I practiced with Tom.

[[Dutch#^nl-Q0127-answer|Compare the answer]]
^nl-Q0127

**nl-Q0128 · Choose the form**

____ heb met Tom geoefend.

I practiced with Tom.

Choices: Ik / hij / jij / wij

[[Dutch#^nl-Q0128-answer|Compare the answer]]
^nl-Q0128

**nl-Q0129 · Edit the changed sentence**

【jij】 leer Kannada.

I learn Kannada.

[[Dutch#^nl-Q0129-answer|Compare the answer]]
^nl-Q0129

**nl-Q0130 · Build the sentence**

Arrange: leer / Ik / Kannada.

I learn Kannada.

[[Dutch#^nl-Q0130-answer|Compare the answer]]
^nl-Q0130

**nl-Q0131 · Write a translation**

Write this in Dutch: Leave your radio at home.

[[Dutch#^nl-Q0131-answer|Compare the answer]]
^nl-Q0131

**nl-Q0132 · Explain the grammar**

Laat 【je】 radio thuis.

Leave your radio at home.

[[Dutch#^nl-Q0132-answer|Compare the answer]]
^nl-Q0132

**nl-Q0133 · Fill the gap**

____ begrijp niet wat me overkomt.

I don't understand what's happening to me.

[[Dutch#^nl-Q0133-answer|Compare the answer]]
^nl-Q0133

**nl-Q0134 · Choose the form**

____ begrijp niet wat me overkomt.

I don't understand what's happening to me.

Choices: wij / hij / jij / Ik

[[Dutch#^nl-Q0134-answer|Compare the answer]]
^nl-Q0134

**nl-Q0135 · Edit the changed sentence**

Zoals 【jij】 al zei, geen probleem.

Like I said, no problem.

[[Dutch#^nl-Q0135-answer|Compare the answer]]
^nl-Q0135

**nl-Q0136 · Build the sentence**

Arrange: zei, / probleem. / ik / Zoals / geen / al

Like I said, no problem.

[[Dutch#^nl-Q0136-answer|Compare the answer]]
^nl-Q0136

**nl-Q0137 · Write a translation**

Write this in Dutch: Do you speak Talossan?

[[Dutch#^nl-Q0137-answer|Compare the answer]]
^nl-Q0137

**nl-Q0138 · Explain the grammar**

Spreekt 【u】 Talossaans?

Do you speak Talossan?

[[Dutch#^nl-Q0138-answer|Compare the answer]]
^nl-Q0138

**nl-Q0139 · Fill the gap**

Tom drinkt net zo graag melk als ____.

Tom likes milk as much as I do.

[[Dutch#^nl-Q0139-answer|Compare the answer]]
^nl-Q0139

**nl-Q0140 · Choose the form**

Tom drinkt net zo graag melk als ____.

Tom likes milk as much as I do.

Choices: jij / hij / wij / ik

[[Dutch#^nl-Q0140-answer|Compare the answer]]
^nl-Q0140

**nl-Q0141 · Edit the changed sentence**

【ik】 doet me denken aan uw moeder.

You remind me of your mother.

[[Dutch#^nl-Q0141-answer|Compare the answer]]
^nl-Q0141

**nl-Q0142 · Build the sentence**

Arrange: denken / U / uw / me / moeder. / doet / aan

You remind me of your mother.

[[Dutch#^nl-Q0142-answer|Compare the answer]]
^nl-Q0142

**nl-Q0143 · Write a translation**

Write this in Dutch: Do you know where he lives?

[[Dutch#^nl-Q0143-answer|Compare the answer]]
^nl-Q0143

**nl-Q0144 · Explain the grammar**

Weet gij waar 【hij】 woont?

Do you know where he lives?

[[Dutch#^nl-Q0144-answer|Compare the answer]]
^nl-Q0144

**nl-Q0145 · Fill the gap**

Willen ____ een schone vork?

Do you want a clean fork?

[[Dutch#^nl-Q0145-answer|Compare the answer]]
^nl-Q0145

**nl-Q0146 · Choose the form**

Willen ____ een schone vork?

Do you want a clean fork?

Choices: ik / hij / jij / jullie

[[Dutch#^nl-Q0146-answer|Compare the answer]]
^nl-Q0146

**nl-Q0147 · Edit the changed sentence**

【jij】 ben geen Liechtensteiner, maar een Zwitser.

I'm not a Liechtensteiner, but a Swiss.

[[Dutch#^nl-Q0147-answer|Compare the answer]]
^nl-Q0147

**nl-Q0148 · Build the sentence**

Arrange: geen / Zwitser. / maar / Liechtensteiner, / een / ben / Ik

I'm not a Liechtensteiner, but a Swiss.

[[Dutch#^nl-Q0148-answer|Compare the answer]]
^nl-Q0148

**nl-Q0149 · Write a translation**

Write this in Dutch: Your magic won't work here.

[[Dutch#^nl-Q0149-answer|Compare the answer]]
^nl-Q0149

**nl-Q0150 · Explain the grammar**

【Je】 magie zal hier niet werken.

Your magic won't work here.

[[Dutch#^nl-Q0150-answer|Compare the answer]]
^nl-Q0150


### Zijn forms · 50 questions

**nl-Q0151 · Fill the gap**

Mijn Frans ____ nog steeds niet zo goed.

My French is still not very good.

[[Dutch#^nl-Q0151-answer|Compare the answer]]
^nl-Q0151

**nl-Q0152 · Choose the form**

Mijn Frans ____ nog steeds niet zo goed.

My French is still not very good.

Choices: is / ben / bent / zijn

[[Dutch#^nl-Q0152-answer|Compare the answer]]
^nl-Q0152

**nl-Q0153 · Edit the changed sentence**

Sommige mensen 【ben】 allergisch voor latex.

Some people are allergic to latex.

[[Dutch#^nl-Q0153-answer|Compare the answer]]
^nl-Q0153

**nl-Q0154 · Build the sentence**

Arrange: Sommige / zijn / latex. / allergisch / voor / mensen

Some people are allergic to latex.

[[Dutch#^nl-Q0154-answer|Compare the answer]]
^nl-Q0154

**nl-Q0155 · Write a translation**

Write this in Dutch: Everything is clear.

[[Dutch#^nl-Q0155-answer|Compare the answer]]
^nl-Q0155

**nl-Q0156 · Explain the grammar**

Alles 【is】 helder.

Everything is clear.

[[Dutch#^nl-Q0156-answer|Compare the answer]]
^nl-Q0156

**nl-Q0157 · Fill the gap**

Tom lijkt klaar te ____ om te gaan.

Tom seems to be ready to go.

[[Dutch#^nl-Q0157-answer|Compare the answer]]
^nl-Q0157

**nl-Q0158 · Choose the form**

Tom lijkt klaar te ____ om te gaan.

Tom seems to be ready to go.

Choices: bent / is / zijn / ben

[[Dutch#^nl-Q0158-answer|Compare the answer]]
^nl-Q0158

**nl-Q0159 · Edit the changed sentence**

Een meniscus 【ben】 geen been. Het is kraakbeen, een elastisch, buigzaam weefsel.

The meniscus is not a bone. It is a cartilage, a flexible, elastic tissue.

[[Dutch#^nl-Q0159-answer|Compare the answer]]
^nl-Q0159

**nl-Q0160 · Build the sentence**

Arrange: buigzaam / meniscus / een / Een / been. / is / Het / kraakbeen, / weefsel. / geen / elastisch, / is

The meniscus is not a bone. It is a cartilage, a flexible, elastic tissue.

[[Dutch#^nl-Q0160-answer|Compare the answer]]
^nl-Q0160

**nl-Q0161 · Write a translation**

Write this in Dutch: Yamoussoukro is the capital of Ivory Coast.

[[Dutch#^nl-Q0161-answer|Compare the answer]]
^nl-Q0161

**nl-Q0162 · Explain the grammar**

Yamoussoukro 【is】 de hoofdstad van Ivoorkust.

Yamoussoukro is the capital of Ivory Coast.

[[Dutch#^nl-Q0162-answer|Compare the answer]]
^nl-Q0162

**nl-Q0163 · Fill the gap**

Het meisje aan de piano ____ mijn zuster.

The girl playing the piano is my sister.

[[Dutch#^nl-Q0163-answer|Compare the answer]]
^nl-Q0163

**nl-Q0164 · Choose the form**

Het meisje aan de piano ____ mijn zuster.

The girl playing the piano is my sister.

Choices: is / bent / ben / zijn

[[Dutch#^nl-Q0164-answer|Compare the answer]]
^nl-Q0164

**nl-Q0165 · Edit the changed sentence**

Tokio station 【ben】 de derde halte.

Tokyo Station is the third stop.

[[Dutch#^nl-Q0165-answer|Compare the answer]]
^nl-Q0165

**nl-Q0166 · Build the sentence**

Arrange: de / derde / station / halte. / is / Tokio

Tokyo Station is the third stop.

[[Dutch#^nl-Q0166-answer|Compare the answer]]
^nl-Q0166

**nl-Q0167 · Write a translation**

Write this in Dutch: Correcting is sometimes harder than writing.

[[Dutch#^nl-Q0167-answer|Compare the answer]]
^nl-Q0167

**nl-Q0168 · Explain the grammar**

Verbeteren 【is】 soms moeilijker dan schrijven.

Correcting is sometimes harder than writing.

[[Dutch#^nl-Q0168-answer|Compare the answer]]
^nl-Q0168

**nl-Q0169 · Fill the gap**

Waarom ____ het op slot?

Why is it locked?

[[Dutch#^nl-Q0169-answer|Compare the answer]]
^nl-Q0169

**nl-Q0170 · Choose the form**

Waarom ____ het op slot?

Why is it locked?

Choices: zijn / ben / is / bent

[[Dutch#^nl-Q0170-answer|Compare the answer]]
^nl-Q0170

**nl-Q0171 · Edit the changed sentence**

Je 【ben】 rijk.

You are rich.

[[Dutch#^nl-Q0171-answer|Compare the answer]]
^nl-Q0171

**nl-Q0172 · Build the sentence**

Arrange: bent / rijk. / Je

You are rich.

[[Dutch#^nl-Q0172-answer|Compare the answer]]
^nl-Q0172

**nl-Q0173 · Write a translation**

Write this in Dutch: It's cozy in here.

[[Dutch#^nl-Q0173-answer|Compare the answer]]
^nl-Q0173

**nl-Q0174 · Explain the grammar**

Het 【is】 hier gezellig.

It's cozy in here.

[[Dutch#^nl-Q0174-answer|Compare the answer]]
^nl-Q0174

**nl-Q0175 · Fill the gap**

Jamaica ____ een Engelse kolonie.

Jamaica's an English colony.

[[Dutch#^nl-Q0175-answer|Compare the answer]]
^nl-Q0175

**nl-Q0176 · Choose the form**

Jamaica ____ een Engelse kolonie.

Jamaica's an English colony.

Choices: zijn / is / bent / ben

[[Dutch#^nl-Q0176-answer|Compare the answer]]
^nl-Q0176

**nl-Q0177 · Edit the changed sentence**

Hoe oud 【ben】 het universum?

How old is the universe?

[[Dutch#^nl-Q0177-answer|Compare the answer]]
^nl-Q0177

**nl-Q0178 · Build the sentence**

Arrange: Hoe / het / universum? / oud / is

How old is the universe?

[[Dutch#^nl-Q0178-answer|Compare the answer]]
^nl-Q0178

**nl-Q0179 · Write a translation**

Write this in Dutch: Nothing was out of place.

[[Dutch#^nl-Q0179-answer|Compare the answer]]
^nl-Q0179

**nl-Q0180 · Explain the grammar**

Niets was niet op 【zijn】 plaats.

Nothing was out of place.

[[Dutch#^nl-Q0180-answer|Compare the answer]]
^nl-Q0180

**nl-Q0181 · Fill the gap**

Het ____ interessant om dreumesen te bekijken.

Babies are interesting to watch.

[[Dutch#^nl-Q0181-answer|Compare the answer]]
^nl-Q0181

**nl-Q0182 · Choose the form**

Het ____ interessant om dreumesen te bekijken.

Babies are interesting to watch.

Choices: zijn / is / bent / ben

[[Dutch#^nl-Q0182-answer|Compare the answer]]
^nl-Q0182

**nl-Q0183 · Edit the changed sentence**

Je 【ben】 zo'n goede jongen, Tom!

What a good boy you are, Tom!

[[Dutch#^nl-Q0183-answer|Compare the answer]]
^nl-Q0183

**nl-Q0184 · Build the sentence**

Arrange: goede / Tom! / Je / zo'n / bent / jongen,

What a good boy you are, Tom!

[[Dutch#^nl-Q0184-answer|Compare the answer]]
^nl-Q0184

**nl-Q0185 · Write a translation**

Write this in Dutch: I'm sorry, but it's impossible.

[[Dutch#^nl-Q0185-answer|Compare the answer]]
^nl-Q0185

**nl-Q0186 · Explain the grammar**

Het spijt me, maar het 【is】 onmogelijk.

I'm sorry, but it's impossible.

[[Dutch#^nl-Q0186-answer|Compare the answer]]
^nl-Q0186

**nl-Q0187 · Fill the gap**

Hij ____ naar Amerika gegaan om Engels te leren.

He went to America to study English.

[[Dutch#^nl-Q0187-answer|Compare the answer]]
^nl-Q0187

**nl-Q0188 · Choose the form**

Hij ____ naar Amerika gegaan om Engels te leren.

He went to America to study English.

Choices: is / ben / bent / zijn

[[Dutch#^nl-Q0188-answer|Compare the answer]]
^nl-Q0188

**nl-Q0189 · Edit the changed sentence**

Tom verhief 【ben】 stem.

Tom raised his voice.

[[Dutch#^nl-Q0189-answer|Compare the answer]]
^nl-Q0189

**nl-Q0190 · Build the sentence**

Arrange: zijn / stem. / Tom / verhief

Tom raised his voice.

[[Dutch#^nl-Q0190-answer|Compare the answer]]
^nl-Q0190

**nl-Q0191 · Write a translation**

Write this in Dutch: There's our bus.

[[Dutch#^nl-Q0191-answer|Compare the answer]]
^nl-Q0191

**nl-Q0192 · Explain the grammar**

Daar 【is】 onze bus.

There's our bus.

[[Dutch#^nl-Q0192-answer|Compare the answer]]
^nl-Q0192

**nl-Q0193 · Fill the gap**

Mijn schuilnaam ____ Tom.

My nickname is Tom.

[[Dutch#^nl-Q0193-answer|Compare the answer]]
^nl-Q0193

**nl-Q0194 · Choose the form**

Mijn schuilnaam ____ Tom.

My nickname is Tom.

Choices: is / zijn / ben / bent

[[Dutch#^nl-Q0194-answer|Compare the answer]]
^nl-Q0194

**nl-Q0195 · Edit the changed sentence**

Tom en Maria 【ben】 allebei ouder dan Johan.

Tom and Mary are both older than John.

[[Dutch#^nl-Q0195-answer|Compare the answer]]
^nl-Q0195

**nl-Q0196 · Build the sentence**

Arrange: ouder / Tom / dan / en / Maria / allebei / Johan. / zijn

Tom and Mary are both older than John.

[[Dutch#^nl-Q0196-answer|Compare the answer]]
^nl-Q0196

**nl-Q0197 · Write a translation**

Write this in Dutch: I wonder why he is late.

[[Dutch#^nl-Q0197-answer|Compare the answer]]
^nl-Q0197

**nl-Q0198 · Explain the grammar**

Ik vraag me af waarom hij te laat 【is】.

I wonder why he is late.

[[Dutch#^nl-Q0198-answer|Compare the answer]]
^nl-Q0198

**nl-Q0199 · Fill the gap**

Mijn vader ____ een beetje ouderwets.

My father is a bit old-fashioned.

[[Dutch#^nl-Q0199-answer|Compare the answer]]
^nl-Q0199

**nl-Q0200 · Choose the form**

Mijn vader ____ een beetje ouderwets.

My father is a bit old-fashioned.

Choices: bent / is / ben / zijn

[[Dutch#^nl-Q0200-answer|Compare the answer]]
^nl-Q0200


### Hebben forms · 50 questions

**nl-Q0201 · Edit the changed sentence**

Water 【heb】 nul calorieën.

Water has zero calories.

[[Dutch#^nl-Q0201-answer|Compare the answer]]
^nl-Q0201

**nl-Q0202 · Build the sentence**

Arrange: calorieën. / Water / heeft / nul

Water has zero calories.

[[Dutch#^nl-Q0202-answer|Compare the answer]]
^nl-Q0202

**nl-Q0203 · Write a translation**

Write this in Dutch: Tom has hope.

[[Dutch#^nl-Q0203-answer|Compare the answer]]
^nl-Q0203

**nl-Q0204 · Explain the grammar**

Tom 【heeft】 hoop.

Tom has hope.

[[Dutch#^nl-Q0204-answer|Compare the answer]]
^nl-Q0204

**nl-Q0205 · Fill the gap**

Toms huis ____ een kleine keuken.

Tom's house has a tiny kitchen.

[[Dutch#^nl-Q0205-answer|Compare the answer]]
^nl-Q0205

**nl-Q0206 · Choose the form**

Toms huis ____ een kleine keuken.

Tom's house has a tiny kitchen.

Choices: heeft / hebben / hebt / heb

[[Dutch#^nl-Q0206-answer|Compare the answer]]
^nl-Q0206

**nl-Q0207 · Edit the changed sentence**

Welke landen 【heb】 u bezocht?

What countries have you visited?

[[Dutch#^nl-Q0207-answer|Compare the answer]]
^nl-Q0207

**nl-Q0208 · Build the sentence**

Arrange: bezocht? / Welke / heeft / landen / u

What countries have you visited?

[[Dutch#^nl-Q0208-answer|Compare the answer]]
^nl-Q0208

**nl-Q0209 · Write a translation**

Write this in Dutch: Aren't you hungry?

[[Dutch#^nl-Q0209-answer|Compare the answer]]
^nl-Q0209

**nl-Q0210 · Explain the grammar**

【Heb】 je geen honger?

Aren't you hungry?

[[Dutch#^nl-Q0210-answer|Compare the answer]]
^nl-Q0210

**nl-Q0211 · Fill the gap**

We ____ het examen geslaagd.

We passed the exam.

[[Dutch#^nl-Q0211-answer|Compare the answer]]
^nl-Q0211

**nl-Q0212 · Choose the form**

We ____ het examen geslaagd.

We passed the exam.

Choices: heb / hebben / heeft / hebt

[[Dutch#^nl-Q0212-answer|Compare the answer]]
^nl-Q0212

**nl-Q0213 · Edit the changed sentence**

De wind 【heb】 mijn paraplu kapotgemaakt.

The wind ruined my umbrella.

[[Dutch#^nl-Q0213-answer|Compare the answer]]
^nl-Q0213

**nl-Q0214 · Build the sentence**

Arrange: heeft / kapotgemaakt. / paraplu / mijn / wind / De

The wind ruined my umbrella.

[[Dutch#^nl-Q0214-answer|Compare the answer]]
^nl-Q0214

**nl-Q0215 · Write a translation**

Write this in Dutch: Do you regularly have sinus issues?

[[Dutch#^nl-Q0215-answer|Compare the answer]]
^nl-Q0215

**nl-Q0216 · Explain the grammar**

【Heb】 je regelmatig problemen met je sinussen?

Do you regularly have sinus issues?

[[Dutch#^nl-Q0216-answer|Compare the answer]]
^nl-Q0216

**nl-Q0217 · Fill the gap**

Tom en Mary ____ een keuze.

Tom and Mary have a choice.

[[Dutch#^nl-Q0217-answer|Compare the answer]]
^nl-Q0217

**nl-Q0218 · Choose the form**

Tom en Mary ____ een keuze.

Tom and Mary have a choice.

Choices: heeft / hebben / hebt / heb

[[Dutch#^nl-Q0218-answer|Compare the answer]]
^nl-Q0218

**nl-Q0219 · Edit the changed sentence**

Wie 【heb】 het gebouwd?

Who built it?

[[Dutch#^nl-Q0219-answer|Compare the answer]]
^nl-Q0219

**nl-Q0220 · Build the sentence**

Arrange: het / heeft / gebouwd? / Wie

Who built it?

[[Dutch#^nl-Q0220-answer|Compare the answer]]
^nl-Q0220

**nl-Q0221 · Write a translation**

Write this in Dutch: Today, I have a date with destiny.

[[Dutch#^nl-Q0221-answer|Compare the answer]]
^nl-Q0221

**nl-Q0222 · Explain the grammar**

Ik 【heb】 vandaag een afspraak met het lot.

Today, I have a date with destiny.

[[Dutch#^nl-Q0222-answer|Compare the answer]]
^nl-Q0222

**nl-Q0223 · Fill the gap**

Zij ____ het me getoond.

She showed it to me.

[[Dutch#^nl-Q0223-answer|Compare the answer]]
^nl-Q0223

**nl-Q0224 · Choose the form**

Zij ____ het me getoond.

She showed it to me.

Choices: heeft / hebt / hebben / heb

[[Dutch#^nl-Q0224-answer|Compare the answer]]
^nl-Q0224

**nl-Q0225 · Edit the changed sentence**

Ze 【heb】 haar werk voltooid.

She has finished her work.

[[Dutch#^nl-Q0225-answer|Compare the answer]]
^nl-Q0225

**nl-Q0226 · Build the sentence**

Arrange: voltooid. / haar / werk / Ze / heeft

She has finished her work.

[[Dutch#^nl-Q0226-answer|Compare the answer]]
^nl-Q0226

**nl-Q0227 · Write a translation**

Write this in Dutch: If you had a million yen, what would you do with it?

[[Dutch#^nl-Q0227-answer|Compare the answer]]
^nl-Q0227

**nl-Q0228 · Explain the grammar**

Stel dat je een miljoen yen 【hebt】, wat zou je daarmee gaan doen?

If you had a million yen, what would you do with it?

[[Dutch#^nl-Q0228-answer|Compare the answer]]
^nl-Q0228

**nl-Q0229 · Fill the gap**

____ hij er iets van gezegd?

Did he say anything about it?

[[Dutch#^nl-Q0229-answer|Compare the answer]]
^nl-Q0229

**nl-Q0230 · Choose the form**

____ hij er iets van gezegd?

Did he say anything about it?

Choices: hebben / Heeft / hebt / heb

[[Dutch#^nl-Q0230-answer|Compare the answer]]
^nl-Q0230

**nl-Q0231 · Edit the changed sentence**

Ik 【hebt】 dit nog nooit eerder gedaan. Kan je me laten zien wat ik moet doen?

I've never done this before. Could you please show me what to do?

[[Dutch#^nl-Q0231-answer|Compare the answer]]
^nl-Q0231

**nl-Q0232 · Build the sentence**

Arrange: wat / gedaan. / je / nog / Kan / Ik / laten / zien / doen? / ik / moet / heb / eerder / me / dit / nooit

I've never done this before. Could you please show me what to do?

[[Dutch#^nl-Q0232-answer|Compare the answer]]
^nl-Q0232

**nl-Q0233 · Write a translation**

Write this in Dutch: How many sides does a square have?

[[Dutch#^nl-Q0233-answer|Compare the answer]]
^nl-Q0233

**nl-Q0234 · Explain the grammar**

Hoeveel zijden 【heeft】 een vierkant?

How many sides does a square have?

[[Dutch#^nl-Q0234-answer|Compare the answer]]
^nl-Q0234

**nl-Q0235 · Fill the gap**

We ____ uw handtekening nodig.

We need your signature.

[[Dutch#^nl-Q0235-answer|Compare the answer]]
^nl-Q0235

**nl-Q0236 · Choose the form**

We ____ uw handtekening nodig.

We need your signature.

Choices: heeft / hebt / hebben / heb

[[Dutch#^nl-Q0236-answer|Compare the answer]]
^nl-Q0236

**nl-Q0237 · Edit the changed sentence**

Zij 【heb】 hem een paar vragen gesteld.

She asked him some questions.

[[Dutch#^nl-Q0237-answer|Compare the answer]]
^nl-Q0237

**nl-Q0238 · Build the sentence**

Arrange: heeft / paar / vragen / een / hem / gesteld. / Zij

She asked him some questions.

[[Dutch#^nl-Q0238-answer|Compare the answer]]
^nl-Q0238

**nl-Q0239 · Write a translation**

Write this in Dutch: Where did you find Tom?

[[Dutch#^nl-Q0239-answer|Compare the answer]]
^nl-Q0239

**nl-Q0240 · Explain the grammar**

Waar 【heb】 je Tom gevonden?

Where did you find Tom?

[[Dutch#^nl-Q0240-answer|Compare the answer]]
^nl-Q0240

**nl-Q0241 · Fill the gap**

Ze denkt dat ze altijd gelijk ____.

She thinks that she's always right.

[[Dutch#^nl-Q0241-answer|Compare the answer]]
^nl-Q0241

**nl-Q0242 · Choose the form**

Ze denkt dat ze altijd gelijk ____.

She thinks that she's always right.

Choices: hebt / hebben / heeft / heb

[[Dutch#^nl-Q0242-answer|Compare the answer]]
^nl-Q0242

**nl-Q0243 · Edit the changed sentence**

Ze 【heb】 een sterke persoonlijkheid.

She has a strong personality.

[[Dutch#^nl-Q0243-answer|Compare the answer]]
^nl-Q0243

**nl-Q0244 · Build the sentence**

Arrange: een / Ze / persoonlijkheid. / heeft / sterke

She has a strong personality.

[[Dutch#^nl-Q0244-answer|Compare the answer]]
^nl-Q0244

**nl-Q0245 · Write a translation**

Write this in Dutch: I discovered that she was better at math than I.

[[Dutch#^nl-Q0245-answer|Compare the answer]]
^nl-Q0245

**nl-Q0246 · Explain the grammar**

Ik 【heb】 ontdekt dat zij beter in wiskunde is dan ik.

I discovered that she was better at math than I.

[[Dutch#^nl-Q0246-answer|Compare the answer]]
^nl-Q0246

**nl-Q0247 · Fill the gap**

Ze ____ tomaten gegeten.

She ate tomatoes.

[[Dutch#^nl-Q0247-answer|Compare the answer]]
^nl-Q0247

**nl-Q0248 · Choose the form**

Ze ____ tomaten gegeten.

She ate tomatoes.

Choices: hebt / hebben / heb / heeft

[[Dutch#^nl-Q0248-answer|Compare the answer]]
^nl-Q0248

**nl-Q0249 · Edit the changed sentence**

Ze moet wel erg hard gewerkt 【heb】.

She must have worked very hard.

[[Dutch#^nl-Q0249-answer|Compare the answer]]
^nl-Q0249

**nl-Q0250 · Build the sentence**

Arrange: Ze / moet / erg / wel / gewerkt / hebben. / hard

She must have worked very hard.

[[Dutch#^nl-Q0250-answer|Compare the answer]]
^nl-Q0250


### Subordinate connectors · 50 questions

**nl-Q0251 · Write a translation**

Write this in Dutch: If it happens again, please let me know right away.

[[Dutch#^nl-Q0251-answer|Compare the answer]]
^nl-Q0251

**nl-Q0252 · Explain the grammar**

【Als】 het weer gebeurt, laat het me meteen weten a.u.b.

If it happens again, please let me know right away.

[[Dutch#^nl-Q0252-answer|Compare the answer]]
^nl-Q0252

**nl-Q0253 · Fill the gap**

Jeff was drie maanden op zoek ____ hij een baan vond.

Jeff searched for three months before he found a job.

[[Dutch#^nl-Q0253-answer|Compare the answer]]
^nl-Q0253

**nl-Q0254 · Choose the form**

Jeff was drie maanden op zoek ____ hij een baan vond.

Jeff searched for three months before he found a job.

Choices: of / omdat / dat / voordat

[[Dutch#^nl-Q0254-answer|Compare the answer]]
^nl-Q0254

**nl-Q0255 · Edit the changed sentence**

De motor stopt 【omdat】 je op die knop drukt.

If you pressed that button, the engine would stop.

[[Dutch#^nl-Q0255-answer|Compare the answer]]
^nl-Q0255

**nl-Q0256 · Build the sentence**

Arrange: die / knop / op / stopt / je / drukt. / De / motor / als

If you pressed that button, the engine would stop.

[[Dutch#^nl-Q0256-answer|Compare the answer]]
^nl-Q0256

**nl-Q0257 · Write a translation**

Write this in Dutch: He is proud that his father was a great scientist.

[[Dutch#^nl-Q0257-answer|Compare the answer]]
^nl-Q0257

**nl-Q0258 · Explain the grammar**

Hij is fier 【dat】 zijn vader een vooraanstaande wetenschapper was.

He is proud that his father was a great scientist.

[[Dutch#^nl-Q0258-answer|Compare the answer]]
^nl-Q0258

**nl-Q0259 · Fill the gap**

Ik denk ____ Tom en Maria weten wie er in dat huis wonen.

I think Tom and Mary know who live in that house.

[[Dutch#^nl-Q0259-answer|Compare the answer]]
^nl-Q0259

**nl-Q0260 · Choose the form**

Ik denk ____ Tom en Maria weten wie er in dat huis wonen.

I think Tom and Mary know who live in that house.

Choices: als / omdat / dat / of

[[Dutch#^nl-Q0260-answer|Compare the answer]]
^nl-Q0260

**nl-Q0261 · Edit the changed sentence**

Ik schreef hem 【omdat】 hij onmiddellijk moest te komen.

I wrote to him to come immediately.

[[Dutch#^nl-Q0261-answer|Compare the answer]]
^nl-Q0261

**nl-Q0262 · Build the sentence**

Arrange: hem / moest / Ik / te / onmiddellijk / schreef / hij / dat / komen.

I wrote to him to come immediately.

[[Dutch#^nl-Q0262-answer|Compare the answer]]
^nl-Q0262

**nl-Q0263 · Write a translation**

Write this in Dutch: I think it strange that Alice should keep silence for such a long time.

[[Dutch#^nl-Q0263-answer|Compare the answer]]
^nl-Q0263

**nl-Q0264 · Explain the grammar**

Ik vind het vreemd 【dat】 Alice zich zo lang stil houdt.

I think it strange that Alice should keep silence for such a long time.

[[Dutch#^nl-Q0264-answer|Compare the answer]]
^nl-Q0264

**nl-Q0265 · Fill the gap**

Hoe zeg je ____ in het Engels?

How do you say that in English?

[[Dutch#^nl-Q0265-answer|Compare the answer]]
^nl-Q0265

**nl-Q0266 · Choose the form**

Hoe zeg je ____ in het Engels?

How do you say that in English?

Choices: of / omdat / dat / als

[[Dutch#^nl-Q0266-answer|Compare the answer]]
^nl-Q0266

**nl-Q0267 · Edit the changed sentence**

Tom zegt 【omdat】 hij zich helemaal niets ervan herinnert.

Tom says he doesn't remember a thing.

[[Dutch#^nl-Q0267-answer|Compare the answer]]
^nl-Q0267

**nl-Q0268 · Build the sentence**

Arrange: herinnert. / niets / Tom / ervan / helemaal / hij / dat / zich / zegt

Tom says he doesn't remember a thing.

[[Dutch#^nl-Q0268-answer|Compare the answer]]
^nl-Q0268

**nl-Q0269 · Write a translation**

Write this in Dutch: Most people think so.

[[Dutch#^nl-Q0269-answer|Compare the answer]]
^nl-Q0269

**nl-Q0270 · Explain the grammar**

De meeste mensen denken 【dat】.

Most people think so.

[[Dutch#^nl-Q0270-answer|Compare the answer]]
^nl-Q0270

**nl-Q0271 · Fill the gap**

Ik wil dokter worden, ____ verpleger, of leraar.

I want to be a doctor or a nurse or a teacher.

[[Dutch#^nl-Q0271-answer|Compare the answer]]
^nl-Q0271

**nl-Q0272 · Choose the form**

Ik wil dokter worden, ____ verpleger, of leraar.

I want to be a doctor or a nurse or a teacher.

Choices: of / omdat / als / dat

[[Dutch#^nl-Q0272-answer|Compare the answer]]
^nl-Q0272

**nl-Q0273 · Edit the changed sentence**

Het probleem met deze film is 【omdat】 de gevechtsscènes en de humoristische scènes door elkaar gegooid zijn.

The problem with this movie is that the violent scenes and the funny scenes are mixed together.

[[Dutch#^nl-Q0273-answer|Compare the answer]]
^nl-Q0273

**nl-Q0274 · Build the sentence**

Arrange: zijn. / scènes / gegooid / en / de / deze / film / door / Het / gevechtsscènes / probleem / humoristische / elkaar / dat / is / met / de

The problem with this movie is that the violent scenes and the funny scenes are mixed together.

[[Dutch#^nl-Q0274-answer|Compare the answer]]
^nl-Q0274

**nl-Q0275 · Write a translation**

Write this in Dutch: Give me that book.

[[Dutch#^nl-Q0275-answer|Compare the answer]]
^nl-Q0275

**nl-Q0276 · Explain the grammar**

Geef me 【dat】 boek.

Give me that book.

[[Dutch#^nl-Q0276-answer|Compare the answer]]
^nl-Q0276

**nl-Q0277 · Fill the gap**

Ik weet ____ Tom niet allergisch is voor aardbeien.

I know that Tom isn't allergic to strawberries.

[[Dutch#^nl-Q0277-answer|Compare the answer]]
^nl-Q0277

**nl-Q0278 · Choose the form**

Ik weet ____ Tom niet allergisch is voor aardbeien.

I know that Tom isn't allergic to strawberries.

Choices: dat / of / als / omdat

[[Dutch#^nl-Q0278-answer|Compare the answer]]
^nl-Q0278

**nl-Q0279 · Edit the changed sentence**

Weet Tom 【omdat】 je komt?

Does Tom know you're coming?

[[Dutch#^nl-Q0279-answer|Compare the answer]]
^nl-Q0279

**nl-Q0280 · Build the sentence**

Arrange: je / Weet / Tom / komt? / dat

Does Tom know you're coming?

[[Dutch#^nl-Q0280-answer|Compare the answer]]
^nl-Q0280

**nl-Q0281 · Write a translation**

Write this in Dutch: I know you're not a doctor.

[[Dutch#^nl-Q0281-answer|Compare the answer]]
^nl-Q0281

**nl-Q0282 · Explain the grammar**

Ik weet 【dat】 je geen dokter bent.

I know you're not a doctor.

[[Dutch#^nl-Q0282-answer|Compare the answer]]
^nl-Q0282

**nl-Q0283 · Fill the gap**

Wanneer hebt u voor het laatst heroïne ____ methadon gebruikt?

When was the last time you used heroin or methadone?

[[Dutch#^nl-Q0283-answer|Compare the answer]]
^nl-Q0283

**nl-Q0284 · Choose the form**

Wanneer hebt u voor het laatst heroïne ____ methadon gebruikt?

When was the last time you used heroin or methadone?

Choices: als / omdat / dat / of

[[Dutch#^nl-Q0284-answer|Compare the answer]]
^nl-Q0284

**nl-Q0285 · Edit the changed sentence**

Waar heeft ze 【omdat】 boek gekocht?

Where did she buy that book?

[[Dutch#^nl-Q0285-answer|Compare the answer]]
^nl-Q0285

**nl-Q0286 · Build the sentence**

Arrange: boek / heeft / Waar / gekocht? / dat / ze

Where did she buy that book?

[[Dutch#^nl-Q0286-answer|Compare the answer]]
^nl-Q0286

**nl-Q0287 · Write a translation**

Write this in Dutch: Eat that bread!

[[Dutch#^nl-Q0287-answer|Compare the answer]]
^nl-Q0287

**nl-Q0288 · Explain the grammar**

Eet 【dat】 brood!

Eat that bread!

[[Dutch#^nl-Q0288-answer|Compare the answer]]
^nl-Q0288

**nl-Q0289 · Fill the gap**

Ik wist niet ____ jij hobo speelde.

I didn't know you played the oboe.

[[Dutch#^nl-Q0289-answer|Compare the answer]]
^nl-Q0289

**nl-Q0290 · Choose the form**

Ik wist niet ____ jij hobo speelde.

I didn't know you played the oboe.

Choices: of / omdat / dat / als

[[Dutch#^nl-Q0290-answer|Compare the answer]]
^nl-Q0290

**nl-Q0291 · Edit the changed sentence**

Er is een mogelijkheid 【omdat】 we de fabriek niet hoeven te sluiten.

There is a possibility that we won't have to shut down the factory.

[[Dutch#^nl-Q0291-answer|Compare the answer]]
^nl-Q0291

**nl-Q0292 · Build the sentence**

Arrange: niet / fabriek / te / hoeven / dat / een / we / de / is / mogelijkheid / sluiten. / Er

There is a possibility that we won't have to shut down the factory.

[[Dutch#^nl-Q0292-answer|Compare the answer]]
^nl-Q0292

**nl-Q0293 · Write a translation**

Write this in Dutch: I decided to tell him that I love her.

[[Dutch#^nl-Q0293-answer|Compare the answer]]
^nl-Q0293

**nl-Q0294 · Explain the grammar**

Ik heb besloten hem te zeggen 【dat】 ik van haar hou.

I decided to tell him that I love her.

[[Dutch#^nl-Q0294-answer|Compare the answer]]
^nl-Q0294

**nl-Q0295 · Fill the gap**

Heb je liever katten ____ honden?

Do you prefer cats or dogs?

[[Dutch#^nl-Q0295-answer|Compare the answer]]
^nl-Q0295

**nl-Q0296 · Choose the form**

Heb je liever katten ____ honden?

Do you prefer cats or dogs?

Choices: of / dat / als / omdat

[[Dutch#^nl-Q0296-answer|Compare the answer]]
^nl-Q0296

**nl-Q0297 · Edit the changed sentence**

【omdat】 een vrouw met overgewicht heeft Mary veel ervaring met mensen die over haar oordelen wegens haar omvang.

As an overweight woman, Mary has experienced many incidents of people judging her based on her size.

[[Dutch#^nl-Q0297-answer|Compare the answer]]
^nl-Q0297

**nl-Q0298 · Build the sentence**

Arrange: mensen / die / heeft / wegens / een / haar / omvang. / haar / over / met / oordelen / veel / overgewicht / ervaring / Als / vrouw / met / Mary

As an overweight woman, Mary has experienced many incidents of people judging her based on her size.

[[Dutch#^nl-Q0298-answer|Compare the answer]]
^nl-Q0298

**nl-Q0299 · Write a translation**

Write this in Dutch: Are you sure you pressed the right button?

[[Dutch#^nl-Q0299-answer|Compare the answer]]
^nl-Q0299

**nl-Q0300 · Explain the grammar**

Weet je zeker 【dat】 je op de goede knop hebt gedrukt?

Are you sure you pressed the right button?

[[Dutch#^nl-Q0300-answer|Compare the answer]]
^nl-Q0300


### Negation · 50 questions

**nl-Q0301 · Fill the gap**

Om het even wat ze eet, ze verdikt ____.

However much she eats, she never gains weight.

[[Dutch#^nl-Q0301-answer|Compare the answer]]
^nl-Q0301

**nl-Q0302 · Choose the form**

Om het even wat ze eet, ze verdikt ____.

However much she eats, she never gains weight.

Choices: niet / wel / geen

[[Dutch#^nl-Q0302-answer|Compare the answer]]
^nl-Q0302

**nl-Q0303 · Edit the changed sentence**

Ik wil 【geen】 slapen.

I don't want to sleep.

[[Dutch#^nl-Q0303-answer|Compare the answer]]
^nl-Q0303

**nl-Q0304 · Build the sentence**

Arrange: niet / Ik / wil / slapen.

I don't want to sleep.

[[Dutch#^nl-Q0304-answer|Compare the answer]]
^nl-Q0304

**nl-Q0305 · Write a translation**

Write this in Dutch: Obviously, he's not that kind of person.

[[Dutch#^nl-Q0305-answer|Compare the answer]]
^nl-Q0305

**nl-Q0306 · Explain the grammar**

Hij is duidelijk 【niet】 zo'n soort persoon.

Obviously, he's not that kind of person.

[[Dutch#^nl-Q0306-answer|Compare the answer]]
^nl-Q0306

**nl-Q0307 · Fill the gap**

We willen ____ mensen zoals jij in deze stad.

We don't want people like you in this town.

[[Dutch#^nl-Q0307-answer|Compare the answer]]
^nl-Q0307

**nl-Q0308 · Choose the form**

We willen ____ mensen zoals jij in deze stad.

We don't want people like you in this town.

Choices: wel / geen / niet

[[Dutch#^nl-Q0308-answer|Compare the answer]]
^nl-Q0308

**nl-Q0309 · Edit the changed sentence**

Ze waren 【geen】 gewaarschuwd voor de vloedgolf.

They weren't warned of the tidal wave.

[[Dutch#^nl-Q0309-answer|Compare the answer]]
^nl-Q0309

**nl-Q0310 · Build the sentence**

Arrange: de / niet / gewaarschuwd / voor / waren / Ze / vloedgolf.

They weren't warned of the tidal wave.

[[Dutch#^nl-Q0310-answer|Compare the answer]]
^nl-Q0310

**nl-Q0311 · Write a translation**

Write this in Dutch: I can't make Tom happy.

[[Dutch#^nl-Q0311-answer|Compare the answer]]
^nl-Q0311

**nl-Q0312 · Explain the grammar**

Ik kan Tom 【niet】 gelukkig maken.

I can't make Tom happy.

[[Dutch#^nl-Q0312-answer|Compare the answer]]
^nl-Q0312

**nl-Q0313 · Fill the gap**

Schrijf met een pen, ____ met een potlood.

Write with a pen, not with a pencil.

[[Dutch#^nl-Q0313-answer|Compare the answer]]
^nl-Q0313

**nl-Q0314 · Choose the form**

Schrijf met een pen, ____ met een potlood.

Write with a pen, not with a pencil.

Choices: niet / wel / geen

[[Dutch#^nl-Q0314-answer|Compare the answer]]
^nl-Q0314

**nl-Q0315 · Edit the changed sentence**

3 percent van de bevolking wil 【geen】 meer eten.

3% of the population doesn't want to eat anymore.

[[Dutch#^nl-Q0315-answer|Compare the answer]]
^nl-Q0315

**nl-Q0316 · Build the sentence**

Arrange: meer / eten. / wil / van / niet / percent / 3 / bevolking / de

3% of the population doesn't want to eat anymore.

[[Dutch#^nl-Q0316-answer|Compare the answer]]
^nl-Q0316

**nl-Q0317 · Write a translation**

Write this in Dutch: I cannot stand this anymore.

[[Dutch#^nl-Q0317-answer|Compare the answer]]
^nl-Q0317

**nl-Q0318 · Explain the grammar**

Ik kan het 【niet】 meer uithouden.

I cannot stand this anymore.

[[Dutch#^nl-Q0318-answer|Compare the answer]]
^nl-Q0318

**nl-Q0319 · Fill the gap**

Je weet daar ____ toevallig iets van, toch?

You wouldn't know anything about that, would you?

[[Dutch#^nl-Q0319-answer|Compare the answer]]
^nl-Q0319

**nl-Q0320 · Choose the form**

Je weet daar ____ toevallig iets van, toch?

You wouldn't know anything about that, would you?

Choices: wel / niet / geen

[[Dutch#^nl-Q0320-answer|Compare the answer]]
^nl-Q0320

**nl-Q0321 · Edit the changed sentence**

Hij woont 【geen】 in Sendai.

He does not live in Sendai.

[[Dutch#^nl-Q0321-answer|Compare the answer]]
^nl-Q0321

**nl-Q0322 · Build the sentence**

Arrange: Hij / niet / in / woont / Sendai.

He does not live in Sendai.

[[Dutch#^nl-Q0322-answer|Compare the answer]]
^nl-Q0322

**nl-Q0323 · Write a translation**

Write this in Dutch: I have not yet downloaded the file.

[[Dutch#^nl-Q0323-answer|Compare the answer]]
^nl-Q0323

**nl-Q0324 · Explain the grammar**

Ik heb het bestand nog 【niet】 gedownload.

I have not yet downloaded the file.

[[Dutch#^nl-Q0324-answer|Compare the answer]]
^nl-Q0324

**nl-Q0325 · Fill the gap**

Ik had ____ keuze.

I had no alternative.

[[Dutch#^nl-Q0325-answer|Compare the answer]]
^nl-Q0325

**nl-Q0326 · Choose the form**

Ik had ____ keuze.

I had no alternative.

Choices: niet / wel / geen

[[Dutch#^nl-Q0326-answer|Compare the answer]]
^nl-Q0326

**nl-Q0327 · Edit the changed sentence**

Ik ga 【geen】 op hem wachten.

I'm not going to wait for him.

[[Dutch#^nl-Q0327-answer|Compare the answer]]
^nl-Q0327

**nl-Q0328 · Build the sentence**

Arrange: wachten. / niet / op / ga / Ik / hem

I'm not going to wait for him.

[[Dutch#^nl-Q0328-answer|Compare the answer]]
^nl-Q0328

**nl-Q0329 · Write a translation**

Write this in Dutch: The clock is wrong.

[[Dutch#^nl-Q0329-answer|Compare the answer]]
^nl-Q0329

**nl-Q0330 · Explain the grammar**

De klok klopt 【niet】.

The clock is wrong.

[[Dutch#^nl-Q0330-answer|Compare the answer]]
^nl-Q0330

**nl-Q0331 · Fill the gap**

Ik moet ____ preek hebben.

I don't need a lecture.

[[Dutch#^nl-Q0331-answer|Compare the answer]]
^nl-Q0331

**nl-Q0332 · Choose the form**

Ik moet ____ preek hebben.

I don't need a lecture.

Choices: niet / wel / geen

[[Dutch#^nl-Q0332-answer|Compare the answer]]
^nl-Q0332

**nl-Q0333 · Edit the changed sentence**

Er zijn 【niet】 gele brievenbussen in Denemarken.

In Denmark, there aren't any yellow postboxes.

[[Dutch#^nl-Q0333-answer|Compare the answer]]
^nl-Q0333

**nl-Q0334 · Build the sentence**

Arrange: gele / geen / in / Denemarken. / zijn / Er / brievenbussen

In Denmark, there aren't any yellow postboxes.

[[Dutch#^nl-Q0334-answer|Compare the answer]]
^nl-Q0334

**nl-Q0335 · Write a translation**

Write this in Dutch: I don't know what we'll do.

[[Dutch#^nl-Q0335-answer|Compare the answer]]
^nl-Q0335

**nl-Q0336 · Explain the grammar**

Ik weet 【niet】 wat we gaan doen.

I don't know what we'll do.

[[Dutch#^nl-Q0336-answer|Compare the answer]]
^nl-Q0336

**nl-Q0337 · Fill the gap**

Je mag ____ naar de stad gaan.

You can't go to town.

[[Dutch#^nl-Q0337-answer|Compare the answer]]
^nl-Q0337

**nl-Q0338 · Choose the form**

Je mag ____ naar de stad gaan.

You can't go to town.

Choices: geen / niet / wel

[[Dutch#^nl-Q0338-answer|Compare the answer]]
^nl-Q0338

**nl-Q0339 · Edit the changed sentence**

Tom heeft gisteren 【niet】 pizza gegeten.

Tom didn't eat pizza yesterday.

[[Dutch#^nl-Q0339-answer|Compare the answer]]
^nl-Q0339

**nl-Q0340 · Build the sentence**

Arrange: gisteren / pizza / geen / gegeten. / heeft / Tom

Tom didn't eat pizza yesterday.

[[Dutch#^nl-Q0340-answer|Compare the answer]]
^nl-Q0340

**nl-Q0341 · Write a translation**

Write this in Dutch: His sister can't talk to you today.

[[Dutch#^nl-Q0341-answer|Compare the answer]]
^nl-Q0341

**nl-Q0342 · Explain the grammar**

Zijn zuster kan vandaag 【niet】 met u spreken.

His sister can't talk to you today.

[[Dutch#^nl-Q0342-answer|Compare the answer]]
^nl-Q0342

**nl-Q0343 · Fill the gap**

Ze werken ____ eens een beetje.

They are not working even a bit.

[[Dutch#^nl-Q0343-answer|Compare the answer]]
^nl-Q0343

**nl-Q0344 · Choose the form**

Ze werken ____ eens een beetje.

They are not working even a bit.

Choices: niet / geen / wel

[[Dutch#^nl-Q0344-answer|Compare the answer]]
^nl-Q0344

**nl-Q0345 · Edit the changed sentence**

We willen 【geen】 dat hij gewond raakt.

We don't want him to get hurt.

[[Dutch#^nl-Q0345-answer|Compare the answer]]
^nl-Q0345

**nl-Q0346 · Build the sentence**

Arrange: niet / hij / gewond / willen / dat / raakt. / We

We don't want him to get hurt.

[[Dutch#^nl-Q0346-answer|Compare the answer]]
^nl-Q0346

**nl-Q0347 · Write a translation**

Write this in Dutch: He didn't come. His excuse was that he was sick.

[[Dutch#^nl-Q0347-answer|Compare the answer]]
^nl-Q0347

**nl-Q0348 · Explain the grammar**

Hij kwam 【niet】. Zijn excuus was dat hij ziek was.

He didn't come. His excuse was that he was sick.

[[Dutch#^nl-Q0348-answer|Compare the answer]]
^nl-Q0348

**nl-Q0349 · Fill the gap**

Ik mag hem ____ meer.

I don't like him anymore.

[[Dutch#^nl-Q0349-answer|Compare the answer]]
^nl-Q0349

**nl-Q0350 · Choose the form**

Ik mag hem ____ meer.

I don't like him anymore.

Choices: wel / geen / niet

[[Dutch#^nl-Q0350-answer|Compare the answer]]
^nl-Q0350


### Modal verbs · 50 questions

**nl-Q0351 · Edit the changed sentence**

De tijd 【kan】 het zeggen.

Time will tell.

[[Dutch#^nl-Q0351-answer|Compare the answer]]
^nl-Q0351

**nl-Q0352 · Build the sentence**

Arrange: zal / het / tijd / zeggen. / De

Time will tell.

[[Dutch#^nl-Q0352-answer|Compare the answer]]
^nl-Q0352

**nl-Q0353 · Write a translation**

Write this in Dutch: Yes, I can.

[[Dutch#^nl-Q0353-answer|Compare the answer]]
^nl-Q0353

**nl-Q0354 · Explain the grammar**

Ja, ik 【kan】.

Yes, I can.

[[Dutch#^nl-Q0354-answer|Compare the answer]]
^nl-Q0354

**nl-Q0355 · Fill the gap**

Wat ____ je?

What do you want?

[[Dutch#^nl-Q0355-answer|Compare the answer]]
^nl-Q0355

**nl-Q0356 · Choose the form**

Wat ____ je?

What do you want?

Choices: wil / moet / mag / kan

[[Dutch#^nl-Q0356-answer|Compare the answer]]
^nl-Q0356

**nl-Q0357 · Edit the changed sentence**

Mijnheer, 【kan】 ik uw rijbewijs zien?

May I see your driver's license, sir?

[[Dutch#^nl-Q0357-answer|Compare the answer]]
^nl-Q0357

**nl-Q0358 · Build the sentence**

Arrange: zien? / uw / ik / mag / Mijnheer, / rijbewijs

May I see your driver's license, sir?

[[Dutch#^nl-Q0358-answer|Compare the answer]]
^nl-Q0358

**nl-Q0359 · Write a translation**

Write this in Dutch: We can change our disadvantage to our advantage.

[[Dutch#^nl-Q0359-answer|Compare the answer]]
^nl-Q0359

**nl-Q0360 · Explain the grammar**

We 【kunnen】 ons nadeel in ons voordeel veranderen.

We can change our disadvantage to our advantage.

[[Dutch#^nl-Q0360-answer|Compare the answer]]
^nl-Q0360

**nl-Q0361 · Fill the gap**

Maria ____ zo'n aansteller zijn.

Mary can be such a drama queen.

[[Dutch#^nl-Q0361-answer|Compare the answer]]
^nl-Q0361

**nl-Q0362 · Choose the form**

Maria ____ zo'n aansteller zijn.

Mary can be such a drama queen.

Choices: wil / mag / kan / moet

[[Dutch#^nl-Q0362-answer|Compare the answer]]
^nl-Q0362

**nl-Q0363 · Edit the changed sentence**

Men 【kan】 zijn plichten vervullen.

One should do one's duties.

[[Dutch#^nl-Q0363-answer|Compare the answer]]
^nl-Q0363

**nl-Q0364 · Build the sentence**

Arrange: moet / vervullen. / zijn / Men / plichten

One should do one's duties.

[[Dutch#^nl-Q0364-answer|Compare the answer]]
^nl-Q0364

**nl-Q0365 · Write a translation**

Write this in Dutch: Can I add you on Facebook?

[[Dutch#^nl-Q0365-answer|Compare the answer]]
^nl-Q0365

**nl-Q0366 · Explain the grammar**

【Kan】 ik jullie toevoegen op Facebook?

Can I add you on Facebook?

[[Dutch#^nl-Q0366-answer|Compare the answer]]
^nl-Q0366

**nl-Q0367 · Fill the gap**

Het spijt me. Ik ____ weg.

Excuse me. I need to go.

[[Dutch#^nl-Q0367-answer|Compare the answer]]
^nl-Q0367

**nl-Q0368 · Choose the form**

Het spijt me. Ik ____ weg.

Excuse me. I need to go.

Choices: kan / mag / wil / moet

[[Dutch#^nl-Q0368-answer|Compare the answer]]
^nl-Q0368

**nl-Q0369 · Edit the changed sentence**

【kan】 je wat sinaasappelsap?

Would you like some orange juice?

[[Dutch#^nl-Q0369-answer|Compare the answer]]
^nl-Q0369

**nl-Q0370 · Build the sentence**

Arrange: sinaasappelsap? / je / wat / Wil

Would you like some orange juice?

[[Dutch#^nl-Q0370-answer|Compare the answer]]
^nl-Q0370

**nl-Q0371 · Write a translation**

Write this in Dutch: I'll call you within a week.

[[Dutch#^nl-Q0371-answer|Compare the answer]]
^nl-Q0371

**nl-Q0372 · Explain the grammar**

Ik 【zal】 u bellen binnen de week.

I'll call you within a week.

[[Dutch#^nl-Q0372-answer|Compare the answer]]
^nl-Q0372

**nl-Q0373 · Fill the gap**

Men ____ deze zin op twee manieren interpreteren.

This sentence can be interpreted in two ways.

[[Dutch#^nl-Q0373-answer|Compare the answer]]
^nl-Q0373

**nl-Q0374 · Choose the form**

Men ____ deze zin op twee manieren interpreteren.

This sentence can be interpreted in two ways.

Choices: kan / moet / wil / mag

[[Dutch#^nl-Q0374-answer|Compare the answer]]
^nl-Q0374

**nl-Q0375 · Edit the changed sentence**

We 【kan】 handelen.

We have to act.

[[Dutch#^nl-Q0375-answer|Compare the answer]]
^nl-Q0375

**nl-Q0376 · Build the sentence**

Arrange: handelen. / We / moeten

We have to act.

[[Dutch#^nl-Q0376-answer|Compare the answer]]
^nl-Q0376

**nl-Q0377 · Write a translation**

Write this in Dutch: I must rest.

[[Dutch#^nl-Q0377-answer|Compare the answer]]
^nl-Q0377

**nl-Q0378 · Explain the grammar**

Ik 【moet】 rusten.

I must rest.

[[Dutch#^nl-Q0378-answer|Compare the answer]]
^nl-Q0378

**nl-Q0379 · Fill the gap**

Hé, kijk eens wat ik ____!

Hey, look what I can do!

[[Dutch#^nl-Q0379-answer|Compare the answer]]
^nl-Q0379

**nl-Q0380 · Choose the form**

Hé, kijk eens wat ik ____!

Hey, look what I can do!

Choices: kan / moet / mag / wil

[[Dutch#^nl-Q0380-answer|Compare the answer]]
^nl-Q0380

**nl-Q0381 · Edit the changed sentence**

Ik 【kan】 je nooit meer zien.

I don't ever want to see you again.

[[Dutch#^nl-Q0381-answer|Compare the answer]]
^nl-Q0381

**nl-Q0382 · Build the sentence**

Arrange: meer / je / zien. / Ik / nooit / wil

I don't ever want to see you again.

[[Dutch#^nl-Q0382-answer|Compare the answer]]
^nl-Q0382

**nl-Q0383 · Write a translation**

Write this in Dutch: Tom needs to be more careful.

[[Dutch#^nl-Q0383-answer|Compare the answer]]
^nl-Q0383

**nl-Q0384 · Explain the grammar**

Tom 【moet】 voorzichtiger zijn.

Tom needs to be more careful.

[[Dutch#^nl-Q0384-answer|Compare the answer]]
^nl-Q0384

**nl-Q0385 · Fill the gap**

Hoe ____ ik Vlaamse Gebarentaal leren?

How can I learn Flemish Sign Language?

[[Dutch#^nl-Q0385-answer|Compare the answer]]
^nl-Q0385

**nl-Q0386 · Choose the form**

Hoe ____ ik Vlaamse Gebarentaal leren?

How can I learn Flemish Sign Language?

Choices: wil / kan / moet / mag

[[Dutch#^nl-Q0386-answer|Compare the answer]]
^nl-Q0386

**nl-Q0387 · Edit the changed sentence**

Wanneer jullie naar Roemenië gaan, 【kan】 jullie het Kasteel van Dracula bezoeken.

When you go to Romania, you will visit Dracula's Castle.

[[Dutch#^nl-Q0387-answer|Compare the answer]]
^nl-Q0387

**nl-Q0388 · Build the sentence**

Arrange: naar / zullen / jullie / Kasteel / gaan, / van / Wanneer / Dracula / bezoeken. / het / Roemenië / jullie

When you go to Romania, you will visit Dracula's Castle.

[[Dutch#^nl-Q0388-answer|Compare the answer]]
^nl-Q0388

**nl-Q0389 · Write a translation**

Write this in Dutch: I still got it.

[[Dutch#^nl-Q0389-answer|Compare the answer]]
^nl-Q0389

**nl-Q0390 · Explain the grammar**

Ik 【kan】 het nog steeds.

I still got it.

[[Dutch#^nl-Q0390-answer|Compare the answer]]
^nl-Q0390

**nl-Q0391 · Fill the gap**

Ik ben maar een immigrant die de Engelse taal ____ beschermen tegen zijn moedertaalsprekers.

I'm only an immigrant trying to protect the English language from its native speakers.

[[Dutch#^nl-Q0391-answer|Compare the answer]]
^nl-Q0391

**nl-Q0392 · Choose the form**

Ik ben maar een immigrant die de Engelse taal ____ beschermen tegen zijn moedertaalsprekers.

I'm only an immigrant trying to protect the English language from its native speakers.

Choices: kan / moet / wil / mag

[[Dutch#^nl-Q0392-answer|Compare the answer]]
^nl-Q0392

**nl-Q0393 · Edit the changed sentence**

Waar een 【kan】 is, is een weg.

Where there's a will, there's a way.

[[Dutch#^nl-Q0393-answer|Compare the answer]]
^nl-Q0393

**nl-Q0394 · Build the sentence**

Arrange: is / weg. / een / Waar / wil / een / is,

Where there's a will, there's a way.

[[Dutch#^nl-Q0394-answer|Compare the answer]]
^nl-Q0394

**nl-Q0395 · Write a translation**

Write this in Dutch: Shall we talk about it over a cup of coffee?

[[Dutch#^nl-Q0395-answer|Compare the answer]]
^nl-Q0395

**nl-Q0396 · Explain the grammar**

【Zullen】 we dit bespreken onder een kop koffie?

Shall we talk about it over a cup of coffee?

[[Dutch#^nl-Q0396-answer|Compare the answer]]
^nl-Q0396

**nl-Q0397 · Fill the gap**

____ ik vragen hoe je heet?

May I ask your name?

[[Dutch#^nl-Q0397-answer|Compare the answer]]
^nl-Q0397

**nl-Q0398 · Choose the form**

____ ik vragen hoe je heet?

May I ask your name?

Choices: wil / kan / moet / Mag

[[Dutch#^nl-Q0398-answer|Compare the answer]]
^nl-Q0398

**nl-Q0399 · Edit the changed sentence**

Ik ben zo moe dat ik nauwelijks 【moet】 lopen.

I am so tired that I can hardly walk.

[[Dutch#^nl-Q0399-answer|Compare the answer]]
^nl-Q0399

**nl-Q0400 · Build the sentence**

Arrange: moe / ben / lopen. / Ik / kan / ik / nauwelijks / dat / zo

I am so tired that I can hardly walk.

[[Dutch#^nl-Q0400-answer|Compare the answer]]
^nl-Q0400


### Past zijn and hebben · 50 questions

**nl-Q0401 · Write a translation**

Write this in Dutch: The Roman troops were exhausted.

[[Dutch#^nl-Q0401-answer|Compare the answer]]
^nl-Q0401

**nl-Q0402 · Explain the grammar**

De Romeinse troepen 【waren】 uitgeput.

The Roman troops were exhausted.

[[Dutch#^nl-Q0402-answer|Compare the answer]]
^nl-Q0402

**nl-Q0403 · Fill the gap**

Hoe ____ je biologie-examen?

How was your biology exam?

[[Dutch#^nl-Q0403-answer|Compare the answer]]
^nl-Q0403

**nl-Q0404 · Choose the form**

Hoe ____ je biologie-examen?

How was your biology exam?

Choices: hadden / waren / had / was

[[Dutch#^nl-Q0404-answer|Compare the answer]]
^nl-Q0404

**nl-Q0405 · Edit the changed sentence**

Ik 【waren】 zeer trots.

I was very proud.

[[Dutch#^nl-Q0405-answer|Compare the answer]]
^nl-Q0405

**nl-Q0406 · Build the sentence**

Arrange: trots. / Ik / zeer / was

I was very proud.

[[Dutch#^nl-Q0406-answer|Compare the answer]]
^nl-Q0406

**nl-Q0407 · Write a translation**

Write this in Dutch: I wish I were rich.

[[Dutch#^nl-Q0407-answer|Compare the answer]]
^nl-Q0407

**nl-Q0408 · Explain the grammar**

【Was】 ik maar rijk.

I wish I were rich.

[[Dutch#^nl-Q0408-answer|Compare the answer]]
^nl-Q0408

**nl-Q0409 · Fill the gap**

Tom ____ toen dertien.

Tom was 13 years old at that time.

[[Dutch#^nl-Q0409-answer|Compare the answer]]
^nl-Q0409

**nl-Q0410 · Choose the form**

Tom ____ toen dertien.

Tom was 13 years old at that time.

Choices: waren / had / was / hadden

[[Dutch#^nl-Q0410-answer|Compare the answer]]
^nl-Q0410

**nl-Q0411 · Edit the changed sentence**

We 【was】 oesters eerder.

We had oysters earlier.

[[Dutch#^nl-Q0411-answer|Compare the answer]]
^nl-Q0411

**nl-Q0412 · Build the sentence**

Arrange: We / eerder. / hadden / oesters

We had oysters earlier.

[[Dutch#^nl-Q0412-answer|Compare the answer]]
^nl-Q0412

**nl-Q0413 · Write a translation**

Write this in Dutch: We had a big Christmas party.

[[Dutch#^nl-Q0413-answer|Compare the answer]]
^nl-Q0413

**nl-Q0414 · Explain the grammar**

We 【hadden】 een groot kerstfeest.

We had a big Christmas party.

[[Dutch#^nl-Q0414-answer|Compare the answer]]
^nl-Q0414

**nl-Q0415 · Fill the gap**

Tom ____ wakker.

Tom was awake.

[[Dutch#^nl-Q0415-answer|Compare the answer]]
^nl-Q0415

**nl-Q0416 · Choose the form**

Tom ____ wakker.

Tom was awake.

Choices: hadden / was / had / waren

[[Dutch#^nl-Q0416-answer|Compare the answer]]
^nl-Q0416

**nl-Q0417 · Edit the changed sentence**

Sami 【was】 een Duitse herder genaamd Farid.

Sami had a German shepherd named Farid.

[[Dutch#^nl-Q0417-answer|Compare the answer]]
^nl-Q0417

**nl-Q0418 · Build the sentence**

Arrange: een / herder / Farid. / Duitse / genaamd / had / Sami

Sami had a German shepherd named Farid.

[[Dutch#^nl-Q0418-answer|Compare the answer]]
^nl-Q0418

**nl-Q0419 · Write a translation**

Write this in Dutch: He was in the queue.

[[Dutch#^nl-Q0419-answer|Compare the answer]]
^nl-Q0419

**nl-Q0420 · Explain the grammar**

Hij 【was】 in de rij.

He was in the queue.

[[Dutch#^nl-Q0420-answer|Compare the answer]]
^nl-Q0420

**nl-Q0421 · Fill the gap**

De dieven wisten wat ze aan het doen ____.

The thieves knew what they were doing.

[[Dutch#^nl-Q0421-answer|Compare the answer]]
^nl-Q0421

**nl-Q0422 · Choose the form**

De dieven wisten wat ze aan het doen ____.

The thieves knew what they were doing.

Choices: had / was / waren / hadden

[[Dutch#^nl-Q0422-answer|Compare the answer]]
^nl-Q0422

**nl-Q0423 · Edit the changed sentence**

Toen ik thuiskwam, 【waren】 mijn broer zijn huiswerk aan het doen.

When I returned home, my brother was doing his homework.

[[Dutch#^nl-Q0423-answer|Compare the answer]]
^nl-Q0423

**nl-Q0424 · Build the sentence**

Arrange: thuiskwam, / zijn / was / het / ik / doen. / mijn / aan / huiswerk / Toen / broer

When I returned home, my brother was doing his homework.

[[Dutch#^nl-Q0424-answer|Compare the answer]]
^nl-Q0424

**nl-Q0425 · Write a translation**

Write this in Dutch: How many computers did you say you had?

[[Dutch#^nl-Q0425-answer|Compare the answer]]
^nl-Q0425

**nl-Q0426 · Explain the grammar**

Hoeveel computers zei je dat je 【had】?

How many computers did you say you had?

[[Dutch#^nl-Q0426-answer|Compare the answer]]
^nl-Q0426

**nl-Q0427 · Fill the gap**

Tom ____ degene die mij het verhaal vertelde.

Tom was the one who told me the story.

[[Dutch#^nl-Q0427-answer|Compare the answer]]
^nl-Q0427

**nl-Q0428 · Choose the form**

Tom ____ degene die mij het verhaal vertelde.

Tom was the one who told me the story.

Choices: had / was / hadden / waren

[[Dutch#^nl-Q0428-answer|Compare the answer]]
^nl-Q0428

**nl-Q0429 · Edit the changed sentence**

Sami 【was】 natuurlijke groene ogen.

Sami had natural green eyes.

[[Dutch#^nl-Q0429-answer|Compare the answer]]
^nl-Q0429

**nl-Q0430 · Build the sentence**

Arrange: groene / Sami / ogen. / natuurlijke / had

Sami had natural green eyes.

[[Dutch#^nl-Q0430-answer|Compare the answer]]
^nl-Q0430

**nl-Q0431 · Write a translation**

Write this in Dutch: I did smoke when I was young.

[[Dutch#^nl-Q0431-answer|Compare the answer]]
^nl-Q0431

**nl-Q0432 · Explain the grammar**

Ik rookte toen ik jong 【was】.

I did smoke when I was young.

[[Dutch#^nl-Q0432-answer|Compare the answer]]
^nl-Q0432

**nl-Q0433 · Fill the gap**

Ik ____ niet veel zin om uit te gaan.

I didn't really feel like going out.

[[Dutch#^nl-Q0433-answer|Compare the answer]]
^nl-Q0433

**nl-Q0434 · Choose the form**

Ik ____ niet veel zin om uit te gaan.

I didn't really feel like going out.

Choices: hadden / had / waren / was

[[Dutch#^nl-Q0434-answer|Compare the answer]]
^nl-Q0434

**nl-Q0435 · Edit the changed sentence**

Betty 【waren】 de laatste die aankwam.

Betty was the last to arrive.

[[Dutch#^nl-Q0435-answer|Compare the answer]]
^nl-Q0435

**nl-Q0436 · Build the sentence**

Arrange: Betty / die / de / was / aankwam. / laatste

Betty was the last to arrive.

[[Dutch#^nl-Q0436-answer|Compare the answer]]
^nl-Q0436

**nl-Q0437 · Write a translation**

Write this in Dutch: All our attempts were in vain.

[[Dutch#^nl-Q0437-answer|Compare the answer]]
^nl-Q0437

**nl-Q0438 · Explain the grammar**

Al onze pogingen 【waren】 tevergeefs.

All our attempts were in vain.

[[Dutch#^nl-Q0438-answer|Compare the answer]]
^nl-Q0438

**nl-Q0439 · Fill the gap**

Ik gaf het geld dat ik bij me ____ aan de bedelaar.

I gave the beggar all the money I had.

[[Dutch#^nl-Q0439-answer|Compare the answer]]
^nl-Q0439

**nl-Q0440 · Choose the form**

Ik gaf het geld dat ik bij me ____ aan de bedelaar.

I gave the beggar all the money I had.

Choices: was / had / hadden / waren

[[Dutch#^nl-Q0440-answer|Compare the answer]]
^nl-Q0440

**nl-Q0441 · Edit the changed sentence**

Hoe 【waren】 je wandeling?

How was your walk?

[[Dutch#^nl-Q0441-answer|Compare the answer]]
^nl-Q0441

**nl-Q0442 · Build the sentence**

Arrange: was / je / wandeling? / Hoe

How was your walk?

[[Dutch#^nl-Q0442-answer|Compare the answer]]
^nl-Q0442

**nl-Q0443 · Write a translation**

Write this in Dutch: Where were you yesterday?

[[Dutch#^nl-Q0443-answer|Compare the answer]]
^nl-Q0443

**nl-Q0444 · Explain the grammar**

Waar 【was】 je gisteren?

Where were you yesterday?

[[Dutch#^nl-Q0444-answer|Compare the answer]]
^nl-Q0444

**nl-Q0445 · Fill the gap**

Sami ____ het koud.

Sami was cold.

[[Dutch#^nl-Q0445-answer|Compare the answer]]
^nl-Q0445

**nl-Q0446 · Choose the form**

Sami ____ het koud.

Sami was cold.

Choices: waren / was / hadden / had

[[Dutch#^nl-Q0446-answer|Compare the answer]]
^nl-Q0446

**nl-Q0447 · Edit the changed sentence**

De slangenbeet 【waren】 fataal.

The snake bite was fatal.

[[Dutch#^nl-Q0447-answer|Compare the answer]]
^nl-Q0447

**nl-Q0448 · Build the sentence**

Arrange: De / slangenbeet / fataal. / was

The snake bite was fatal.

[[Dutch#^nl-Q0448-answer|Compare the answer]]
^nl-Q0448

**nl-Q0449 · Write a translation**

Write this in Dutch: My husband was a teacher.

[[Dutch#^nl-Q0449-answer|Compare the answer]]
^nl-Q0449

**nl-Q0450 · Explain the grammar**

Mijn man 【was】 leraar.

My husband was a teacher.

[[Dutch#^nl-Q0450-answer|Compare the answer]]
^nl-Q0450


### Past participles · 50 questions

**nl-Q0451 · Fill the gap**

Wie heeft die doos ____?

Who made this box?

[[Dutch#^nl-Q0451-answer|Compare the answer]]
^nl-Q0451

**nl-Q0452 · Choose the form**

Wie heeft die doos ____?

Who made this box?

Choices: gegaan / gezien / gemaakt / gedaan

[[Dutch#^nl-Q0452-answer|Compare the answer]]
^nl-Q0452

**nl-Q0453 · Edit the changed sentence**

Het maakt niet uit wat ze 【gedaan】 heeft.

It doesn't matter what she said.

[[Dutch#^nl-Q0453-answer|Compare the answer]]
^nl-Q0453

**nl-Q0454 · Build the sentence**

Arrange: gezegd / wat / heeft. / maakt / niet / Het / uit / ze

It doesn't matter what she said.

[[Dutch#^nl-Q0454-answer|Compare the answer]]
^nl-Q0454

**nl-Q0455 · Write a translation**

Write this in Dutch: I've never been abroad.

[[Dutch#^nl-Q0455-answer|Compare the answer]]
^nl-Q0455

**nl-Q0456 · Explain the grammar**

Ik ben nooit in het buitenland 【geweest】.

I've never been abroad.

[[Dutch#^nl-Q0456-answer|Compare the answer]]
^nl-Q0456

**nl-Q0457 · Fill the gap**

Sami heeft koffie ____.

Sami made coffee.

[[Dutch#^nl-Q0457-answer|Compare the answer]]
^nl-Q0457

**nl-Q0458 · Choose the form**

Sami heeft koffie ____.

Sami made coffee.

Choices: gegaan / gemaakt / gezien / gedaan

[[Dutch#^nl-Q0458-answer|Compare the answer]]
^nl-Q0458

**nl-Q0459 · Edit the changed sentence**

We hebben een goede film 【gedaan】.

We have seen a good movie.

[[Dutch#^nl-Q0459-answer|Compare the answer]]
^nl-Q0459

**nl-Q0460 · Build the sentence**

Arrange: film / gezien. / een / goede / We / hebben

We have seen a good movie.

[[Dutch#^nl-Q0460-answer|Compare the answer]]
^nl-Q0460

**nl-Q0461 · Write a translation**

Write this in Dutch: Have you guys seen her?

[[Dutch#^nl-Q0461-answer|Compare the answer]]
^nl-Q0461

**nl-Q0462 · Explain the grammar**

Hebben jullie haar 【gezien】?

Have you guys seen her?

[[Dutch#^nl-Q0462-answer|Compare the answer]]
^nl-Q0462

**nl-Q0463 · Fill the gap**

Ik heb een muis ____!

I saw a mouse!

[[Dutch#^nl-Q0463-answer|Compare the answer]]
^nl-Q0463

**nl-Q0464 · Choose the form**

Ik heb een muis ____!

I saw a mouse!

Choices: gegaan / gedaan / gemaakt / gezien

[[Dutch#^nl-Q0464-answer|Compare the answer]]
^nl-Q0464

**nl-Q0465 · Edit the changed sentence**

Het was niet duidelijk of ze 【gezien】 hadden of niet.

It was not clear whether they had done or not.

[[Dutch#^nl-Q0465-answer|Compare the answer]]
^nl-Q0465

**nl-Q0466 · Build the sentence**

Arrange: hadden / Het / of / duidelijk / was / niet / of / niet. / ze / gedaan

It was not clear whether they had done or not.

[[Dutch#^nl-Q0466-answer|Compare the answer]]
^nl-Q0466

**nl-Q0467 · Write a translation**

Write this in Dutch: You haven't done anything wrong.

[[Dutch#^nl-Q0467-answer|Compare the answer]]
^nl-Q0467

**nl-Q0468 · Explain the grammar**

Je hebt niets verkeerd 【gedaan】.

You haven't done anything wrong.

[[Dutch#^nl-Q0468-answer|Compare the answer]]
^nl-Q0468

**nl-Q0469 · Fill the gap**

We zijn naar het museum ____.

We went to the museum.

[[Dutch#^nl-Q0469-answer|Compare the answer]]
^nl-Q0469

**nl-Q0470 · Choose the form**

We zijn naar het museum ____.

We went to the museum.

Choices: gemaakt / gegaan / gedaan / gezien

[[Dutch#^nl-Q0470-answer|Compare the answer]]
^nl-Q0470

**nl-Q0471 · Edit the changed sentence**

We hebben een overdosis 【gedaan】.

We overdosed.

[[Dutch#^nl-Q0471-answer|Compare the answer]]
^nl-Q0471

**nl-Q0472 · Build the sentence**

Arrange: een / overdosis / hebben / gehad. / We

We overdosed.

[[Dutch#^nl-Q0472-answer|Compare the answer]]
^nl-Q0472

**nl-Q0473 · Write a translation**

Write this in Dutch: What did you do last Sunday?

[[Dutch#^nl-Q0473-answer|Compare the answer]]
^nl-Q0473

**nl-Q0474 · Explain the grammar**

Wat heb je afgelopen zondag 【gedaan】?

What did you do last Sunday?

[[Dutch#^nl-Q0474-answer|Compare the answer]]
^nl-Q0474

**nl-Q0475 · Fill the gap**

Heb je echt een ufo ____?

Did you really see a UFO?

[[Dutch#^nl-Q0475-answer|Compare the answer]]
^nl-Q0475

**nl-Q0476 · Choose the form**

Heb je echt een ufo ____?

Did you really see a UFO?

Choices: gedaan / gegaan / gezien / gemaakt

[[Dutch#^nl-Q0476-answer|Compare the answer]]
^nl-Q0476

**nl-Q0477 · Edit the changed sentence**

Ik heb niet 【gedaan】 dat jij hem gepakt hebt.

I didn't say you took it.

[[Dutch#^nl-Q0477-answer|Compare the answer]]
^nl-Q0477

**nl-Q0478 · Build the sentence**

Arrange: hem / jij / gezegd / heb / niet / dat / gepakt / hebt. / Ik

I didn't say you took it.

[[Dutch#^nl-Q0478-answer|Compare the answer]]
^nl-Q0478

**nl-Q0479 · Write a translation**

Write this in Dutch: Tom made coffee.

[[Dutch#^nl-Q0479-answer|Compare the answer]]
^nl-Q0479

**nl-Q0480 · Explain the grammar**

Tom heeft koffie 【gemaakt】.

Tom made coffee.

[[Dutch#^nl-Q0480-answer|Compare the answer]]
^nl-Q0480

**nl-Q0481 · Fill the gap**

Ik denk dat je dit al eerder hebt ____.

I think you've said that before.

[[Dutch#^nl-Q0481-answer|Compare the answer]]
^nl-Q0481

**nl-Q0482 · Choose the form**

Ik denk dat je dit al eerder hebt ____.

I think you've said that before.

Choices: gezien / gedaan / gegaan / gezegd

[[Dutch#^nl-Q0482-answer|Compare the answer]]
^nl-Q0482

**nl-Q0483 · Edit the changed sentence**

Tom gaf toe dat hij het 【gezien】 heeft.

Tom admitted that he did that.

[[Dutch#^nl-Q0483-answer|Compare the answer]]
^nl-Q0483

**nl-Q0484 · Build the sentence**

Arrange: het / hij / gaf / gedaan / dat / Tom / toe / heeft.

Tom admitted that he did that.

[[Dutch#^nl-Q0484-answer|Compare the answer]]
^nl-Q0484

**nl-Q0485 · Write a translation**

Write this in Dutch: His castle was made of wood.

[[Dutch#^nl-Q0485-answer|Compare the answer]]
^nl-Q0485

**nl-Q0486 · Explain the grammar**

Zijn kasteel was 【gemaakt】 van hout.

His castle was made of wood.

[[Dutch#^nl-Q0486-answer|Compare the answer]]
^nl-Q0486

**nl-Q0487 · Fill the gap**

Ik had het nog niet eerder ____.

I hadn't seen it before.

[[Dutch#^nl-Q0487-answer|Compare the answer]]
^nl-Q0487

**nl-Q0488 · Choose the form**

Ik had het nog niet eerder ____.

I hadn't seen it before.

Choices: gemaakt / gezien / gedaan / gegaan

[[Dutch#^nl-Q0488-answer|Compare the answer]]
^nl-Q0488

**nl-Q0489 · Edit the changed sentence**

Sami is een heel jaar moslim 【gedaan】.

Sami has been a Muslim for a whole year.

[[Dutch#^nl-Q0489-answer|Compare the answer]]
^nl-Q0489

**nl-Q0490 · Build the sentence**

Arrange: moslim / is / heel / een / jaar / Sami / geweest.

Sami has been a Muslim for a whole year.

[[Dutch#^nl-Q0490-answer|Compare the answer]]
^nl-Q0490

**nl-Q0491 · Write a translation**

Write this in Dutch: Someone put something in her drink.

[[Dutch#^nl-Q0491-answer|Compare the answer]]
^nl-Q0491

**nl-Q0492 · Explain the grammar**

Iemand heeft iets in haar drankje 【gedaan】.

Someone put something in her drink.

[[Dutch#^nl-Q0492-answer|Compare the answer]]
^nl-Q0492

**nl-Q0493 · Fill the gap**

Eerlijk ____ kunnen we je hulp wel gebruiken.

Frankly, we could use your help.

[[Dutch#^nl-Q0493-answer|Compare the answer]]
^nl-Q0493

**nl-Q0494 · Choose the form**

Eerlijk ____ kunnen we je hulp wel gebruiken.

Frankly, we could use your help.

Choices: gegaan / gedaan / gezien / gezegd

[[Dutch#^nl-Q0494-answer|Compare the answer]]
^nl-Q0494

**nl-Q0495 · Edit the changed sentence**

Ik heb nog nooit een dikke veganist 【gedaan】.

I've never seen a fat vegan.

[[Dutch#^nl-Q0495-answer|Compare the answer]]
^nl-Q0495

**nl-Q0496 · Build the sentence**

Arrange: gezien. / heb / dikke / veganist / Ik / nog / nooit / een

I've never seen a fat vegan.

[[Dutch#^nl-Q0496-answer|Compare the answer]]
^nl-Q0496

**nl-Q0497 · Write a translation**

Write this in Dutch: It's as if Tom and Mary were made for each other.

[[Dutch#^nl-Q0497-answer|Compare the answer]]
^nl-Q0497

**nl-Q0498 · Explain the grammar**

Het lijkt wel alsof Tom en Mary voor elkaar zijn 【gemaakt】.

It's as if Tom and Mary were made for each other.

[[Dutch#^nl-Q0498-answer|Compare the answer]]
^nl-Q0498

**nl-Q0499 · Fill the gap**

Dat is altijd zo ____.

This is always the way it has been.

[[Dutch#^nl-Q0499-answer|Compare the answer]]
^nl-Q0499

**nl-Q0500 · Choose the form**

Dat is altijd zo ____.

This is always the way it has been.

Choices: geweest / gedaan / gegaan / gezien

[[Dutch#^nl-Q0500-answer|Compare the answer]]
^nl-Q0500


### Conditional forms · 50 questions

**nl-Q0501 · Edit the changed sentence**

Ik wou dat ik 【zou】 stoppen met denken aan Tom.

I wish I could stop thinking about Tom.

[[Dutch#^nl-Q0501-answer|Compare the answer]]
^nl-Q0501

**nl-Q0502 · Build the sentence**

Arrange: dat / denken / met / wou / stoppen / ik / Tom. / aan / kon / Ik

I wish I could stop thinking about Tom.

[[Dutch#^nl-Q0502-answer|Compare the answer]]
^nl-Q0502

**nl-Q0503 · Write a translation**

Write this in Dutch: If I could rearrange the alphabet, I would put U and I together.

[[Dutch#^nl-Q0503-answer|Compare the answer]]
^nl-Q0503

**nl-Q0504 · Explain the grammar**

Als ik het alfabet 【kon】 herschikken, dan zette ik nog steeds T voor U.

If I could rearrange the alphabet, I would put U and I together.

[[Dutch#^nl-Q0504-answer|Compare the answer]]
^nl-Q0504

**nl-Q0505 · Fill the gap**

Ik wist wel dat Tom dorst ____ hebben.

I knew Tom would be thirsty.

[[Dutch#^nl-Q0505-answer|Compare the answer]]
^nl-Q0505

**nl-Q0506 · Choose the form**

Ik wist wel dat Tom dorst ____ hebben.

I knew Tom would be thirsty.

Choices: konden / zouden / kon / zou

[[Dutch#^nl-Q0506-answer|Compare the answer]]
^nl-Q0506

**nl-Q0507 · Edit the changed sentence**

Tom 【zou】 geen pizza eten.

Tom didn't want to eat pizza.

[[Dutch#^nl-Q0507-answer|Compare the answer]]
^nl-Q0507

**nl-Q0508 · Build the sentence**

Arrange: pizza / eten. / wilde / geen / Tom

Tom didn't want to eat pizza.

[[Dutch#^nl-Q0508-answer|Compare the answer]]
^nl-Q0508

**nl-Q0509 · Write a translation**

Write this in Dutch: I wonder if that's Tom.

[[Dutch#^nl-Q0509-answer|Compare the answer]]
^nl-Q0509

**nl-Q0510 · Explain the grammar**

【Zou】 dat Tom zijn?

I wonder if that's Tom.

[[Dutch#^nl-Q0510-answer|Compare the answer]]
^nl-Q0510

**nl-Q0511 · Fill the gap**

Hij ____ in staat zijn dat te doen.

That he would be able to do.

[[Dutch#^nl-Q0511-answer|Compare the answer]]
^nl-Q0511

**nl-Q0512 · Choose the form**

Hij ____ in staat zijn dat te doen.

That he would be able to do.

Choices: kon / konden / zouden / zou

[[Dutch#^nl-Q0512-answer|Compare the answer]]
^nl-Q0512

**nl-Q0513 · Edit the changed sentence**

Ik wou dat Tom dat ook daadwerkelijk 【zou】 doen.

I wish Tom could actually do that.

[[Dutch#^nl-Q0513-answer|Compare the answer]]
^nl-Q0513

**nl-Q0514 · Build the sentence**

Arrange: ook / dat / Tom / wou / kon / daadwerkelijk / dat / Ik / doen.

I wish Tom could actually do that.

[[Dutch#^nl-Q0514-answer|Compare the answer]]
^nl-Q0514

**nl-Q0515 · Write a translation**

Write this in Dutch: Being able to watch a drama without subtitles made me very glad I studied Japanese.

[[Dutch#^nl-Q0515-answer|Compare the answer]]
^nl-Q0515

**nl-Q0516 · Explain the grammar**

Ik was blij dat ik Japans had gestudeerd, toen ik een drama zonder ondertitels 【kon】 kijken.

Being able to watch a drama without subtitles made me very glad I studied Japanese.

[[Dutch#^nl-Q0516-answer|Compare the answer]]
^nl-Q0516

**nl-Q0517 · Fill the gap**

Ik ____ heel graag een koud glas bier willen hebben.

I would love a cold glass of beer.

[[Dutch#^nl-Q0517-answer|Compare the answer]]
^nl-Q0517

**nl-Q0518 · Choose the form**

Ik ____ heel graag een koud glas bier willen hebben.

I would love a cold glass of beer.

Choices: kon / zouden / konden / zou

[[Dutch#^nl-Q0518-answer|Compare the answer]]
^nl-Q0518

**nl-Q0519 · Edit the changed sentence**

Ze 【zou】 mij niet beoordelen.

They couldn't judge me.

[[Dutch#^nl-Q0519-answer|Compare the answer]]
^nl-Q0519

**nl-Q0520 · Build the sentence**

Arrange: niet / Ze / konden / mij / beoordelen.

They couldn't judge me.

[[Dutch#^nl-Q0520-answer|Compare the answer]]
^nl-Q0520

**nl-Q0521 · Write a translation**

Write this in Dutch: If I were you, I would wait and see.

[[Dutch#^nl-Q0521-answer|Compare the answer]]
^nl-Q0521

**nl-Q0522 · Explain the grammar**

In uw plaats, 【zou】 ik afwachten.

If I were you, I would wait and see.

[[Dutch#^nl-Q0522-answer|Compare the answer]]
^nl-Q0522

**nl-Q0523 · Fill the gap**

____ u me kunnen zeggen waar de dichtstbijzijnde kerk is a.u.b.?

Could you please tell me where the nearest church is?

[[Dutch#^nl-Q0523-answer|Compare the answer]]
^nl-Q0523

**nl-Q0524 · Choose the form**

____ u me kunnen zeggen waar de dichtstbijzijnde kerk is a.u.b.?

Could you please tell me where the nearest church is?

Choices: zouden / kon / Zou / konden

[[Dutch#^nl-Q0524-answer|Compare the answer]]
^nl-Q0524

**nl-Q0525 · Edit the changed sentence**

Het 【zouden】 me niet gelukt zijn zonder zijn hulp.

I would have failed without his help.

[[Dutch#^nl-Q0525-answer|Compare the answer]]
^nl-Q0525

**nl-Q0526 · Build the sentence**

Arrange: me / zijn / zonder / niet / gelukt / zou / Het / hulp. / zijn

I would have failed without his help.

[[Dutch#^nl-Q0526-answer|Compare the answer]]
^nl-Q0526

**nl-Q0527 · Write a translation**

Write this in Dutch: I thought I'd always be alone.

[[Dutch#^nl-Q0527-answer|Compare the answer]]
^nl-Q0527

**nl-Q0528 · Explain the grammar**

Ik dacht dat ik altijd alleen 【zou】 zijn.

I thought I'd always be alone.

[[Dutch#^nl-Q0528-answer|Compare the answer]]
^nl-Q0528

**nl-Q0529 · Fill the gap**

Hij ____ het probleem oplossen.

He was able to solve the problem.

[[Dutch#^nl-Q0529-answer|Compare the answer]]
^nl-Q0529

**nl-Q0530 · Choose the form**

Hij ____ het probleem oplossen.

He was able to solve the problem.

Choices: zou / kon / konden / zouden

[[Dutch#^nl-Q0530-answer|Compare the answer]]
^nl-Q0530

**nl-Q0531 · Edit the changed sentence**

Het 【zouden】 beter zijn dat je haar nu niet ontmoet.

You'd better not see her now.

[[Dutch#^nl-Q0531-answer|Compare the answer]]
^nl-Q0531

**nl-Q0532 · Build the sentence**

Arrange: ontmoet. / beter / haar / zijn / Het / nu / niet / je / dat / zou

You'd better not see her now.

[[Dutch#^nl-Q0532-answer|Compare the answer]]
^nl-Q0532

**nl-Q0533 · Write a translation**

Write this in Dutch: I was unable to prevent this.

[[Dutch#^nl-Q0533-answer|Compare the answer]]
^nl-Q0533

**nl-Q0534 · Explain the grammar**

Ik 【kon】 dit niet voorkomen.

I was unable to prevent this.

[[Dutch#^nl-Q0534-answer|Compare the answer]]
^nl-Q0534

**nl-Q0535 · Fill the gap**

Ze rende zo snel als ze ____.

She ran as fast as possible.

[[Dutch#^nl-Q0535-answer|Compare the answer]]
^nl-Q0535

**nl-Q0536 · Choose the form**

Ze rende zo snel als ze ____.

She ran as fast as possible.

Choices: zouden / konden / kon / zou

[[Dutch#^nl-Q0536-answer|Compare the answer]]
^nl-Q0536

**nl-Q0537 · Edit the changed sentence**

Tom vertelde me dat hij 【zou】 stoppen met zijn baan.

Tom told me he wanted to quit his job.

[[Dutch#^nl-Q0537-answer|Compare the answer]]
^nl-Q0537

**nl-Q0538 · Build the sentence**

Arrange: stoppen / met / vertelde / me / baan. / hij / zijn / Tom / dat / wilde

Tom told me he wanted to quit his job.

[[Dutch#^nl-Q0538-answer|Compare the answer]]
^nl-Q0538

**nl-Q0539 · Write a translation**

Write this in Dutch: Tom wanted to know if Mary had a boyfriend.

[[Dutch#^nl-Q0539-answer|Compare the answer]]
^nl-Q0539

**nl-Q0540 · Explain the grammar**

Tom 【wilde】 weten of Mary een vriendje had.

Tom wanted to know if Mary had a boyfriend.

[[Dutch#^nl-Q0540-answer|Compare the answer]]
^nl-Q0540

**nl-Q0541 · Fill the gap**

Ze ____ niet betrokken raken.

She didn't want to get involved.

[[Dutch#^nl-Q0541-answer|Compare the answer]]
^nl-Q0541

**nl-Q0542 · Choose the form**

Ze ____ niet betrokken raken.

She didn't want to get involved.

Choices: zouden / wilde / kon / zou

[[Dutch#^nl-Q0542-answer|Compare the answer]]
^nl-Q0542

**nl-Q0543 · Edit the changed sentence**

Bob 【zou】 zijn woede niet beheersen.

Bob could not control his anger.

[[Dutch#^nl-Q0543-answer|Compare the answer]]
^nl-Q0543

**nl-Q0544 · Build the sentence**

Arrange: zijn / Bob / kon / woede / beheersen. / niet

Bob could not control his anger.

[[Dutch#^nl-Q0544-answer|Compare the answer]]
^nl-Q0544

**nl-Q0545 · Write a translation**

Write this in Dutch: We didn't know you would be coming with us.

[[Dutch#^nl-Q0545-answer|Compare the answer]]
^nl-Q0545

**nl-Q0546 · Explain the grammar**

We wisten niet dat je met ons 【zou】 komen.

We didn't know you would be coming with us.

[[Dutch#^nl-Q0546-answer|Compare the answer]]
^nl-Q0546

**nl-Q0547 · Fill the gap**

Ik bad opdat mijn dochters mij ____ vergeven.

I prayed that my daughters would forgive me.

[[Dutch#^nl-Q0547-answer|Compare the answer]]
^nl-Q0547

**nl-Q0548 · Choose the form**

Ik bad opdat mijn dochters mij ____ vergeven.

I prayed that my daughters would forgive me.

Choices: konden / zouden / kon / zou

[[Dutch#^nl-Q0548-answer|Compare the answer]]
^nl-Q0548

**nl-Q0549 · Edit the changed sentence**

Ik 【zouden】 graag in deze rivier zwemmen.

I'd like to swim in this river.

[[Dutch#^nl-Q0549-answer|Compare the answer]]
^nl-Q0549

**nl-Q0550 · Build the sentence**

Arrange: Ik / zwemmen. / graag / in / rivier / deze / zou

I'd like to swim in this river.

[[Dutch#^nl-Q0550-answer|Compare the answer]]
^nl-Q0550


### Passives and worden · 50 questions

**nl-Q0551 · Write a translation**

Write this in Dutch: The above-mentioned mail item has been duly delivered.

[[Dutch#^nl-Q0551-answer|Compare the answer]]
^nl-Q0551

**nl-Q0552 · Explain the grammar**

Die hierboven vermelde zending 【werd】 behoorlijk afgeleverd.

The above-mentioned mail item has been duly delivered.

[[Dutch#^nl-Q0552-answer|Compare the answer]]
^nl-Q0552

**nl-Q0553 · Fill the gap**

Frans ____ gesproken in Zwitserland.

French is spoken in Switzerland.

[[Dutch#^nl-Q0553-answer|Compare the answer]]
^nl-Q0553

**nl-Q0554 · Choose the form**

Frans ____ gesproken in Zwitserland.

French is spoken in Switzerland.

Choices: worden / werden / wordt / werd

[[Dutch#^nl-Q0554-answer|Compare the answer]]
^nl-Q0554

**nl-Q0555 · Edit the changed sentence**

Het Catalaans 【worden】 gesproken in Andorra.

Catalan is spoken in Andorra.

[[Dutch#^nl-Q0555-answer|Compare the answer]]
^nl-Q0555

**nl-Q0556 · Build the sentence**

Arrange: Het / wordt / in / gesproken / Andorra. / Catalaans

Catalan is spoken in Andorra.

[[Dutch#^nl-Q0556-answer|Compare the answer]]
^nl-Q0556

**nl-Q0557 · Write a translation**

Write this in Dutch: Seychelles is called "Sesel" in Seychellois Creole.

[[Dutch#^nl-Q0557-answer|Compare the answer]]
^nl-Q0557

**nl-Q0558 · Explain the grammar**

De Seychellen 【worden】 ''Sesel'' genoemd in het Seychellencreools.

Seychelles is called "Sesel" in Seychellois Creole.

[[Dutch#^nl-Q0558-answer|Compare the answer]]
^nl-Q0558

**nl-Q0559 · Fill the gap**

Ik wou dat je niet rondslenterde. Dit is New York City... je zult omvergereden ____.

I wish you wouldn't amble; this is New York City--you'll get run over.

[[Dutch#^nl-Q0559-answer|Compare the answer]]
^nl-Q0559

**nl-Q0560 · Choose the form**

Ik wou dat je niet rondslenterde. Dit is New York City... je zult omvergereden ____.

I wish you wouldn't amble; this is New York City--you'll get run over.

Choices: werd / worden / wordt / werden

[[Dutch#^nl-Q0560-answer|Compare the answer]]
^nl-Q0560

**nl-Q0561 · Edit the changed sentence**

Ik hoop dat je vlug beter 【worden】.

I do hope you will get well soon.

[[Dutch#^nl-Q0561-answer|Compare the answer]]
^nl-Q0561

**nl-Q0562 · Build the sentence**

Arrange: je / vlug / hoop / Ik / beter / dat / wordt.

I do hope you will get well soon.

[[Dutch#^nl-Q0562-answer|Compare the answer]]
^nl-Q0562

**nl-Q0563 · Write a translation**

Write this in Dutch: I want to grow old with you.

[[Dutch#^nl-Q0563-answer|Compare the answer]]
^nl-Q0563

**nl-Q0564 · Explain the grammar**

Met jou wil ik oud 【worden】.

I want to grow old with you.

[[Dutch#^nl-Q0564-answer|Compare the answer]]
^nl-Q0564

**nl-Q0565 · Fill the gap**

Mijn grootvader ____ in de Tweede Wereldoorlog gedood.

My grandfather was killed in World War II.

[[Dutch#^nl-Q0565-answer|Compare the answer]]
^nl-Q0565

**nl-Q0566 · Choose the form**

Mijn grootvader ____ in de Tweede Wereldoorlog gedood.

My grandfather was killed in World War II.

Choices: werden / wordt / worden / werd

[[Dutch#^nl-Q0566-answer|Compare the answer]]
^nl-Q0566

**nl-Q0567 · Edit the changed sentence**

Hij 【wordt】 wakker door luid geklop op de deur.

A loud knocking at the door woke him up.

[[Dutch#^nl-Q0567-answer|Compare the answer]]
^nl-Q0567

**nl-Q0568 · Build the sentence**

Arrange: deur. / geklop / luid / wakker / op / werd / Hij / de / door

A loud knocking at the door woke him up.

[[Dutch#^nl-Q0568-answer|Compare the answer]]
^nl-Q0568

**nl-Q0569 · Write a translation**

Write this in Dutch: It's about time you went to the barber's.

[[Dutch#^nl-Q0569-answer|Compare the answer]]
^nl-Q0569

**nl-Q0570 · Explain the grammar**

Het 【wordt】 tijd dat je naar de kapper gaat.

It's about time you went to the barber's.

[[Dutch#^nl-Q0570-answer|Compare the answer]]
^nl-Q0570

**nl-Q0571 · Fill the gap**

Buiten ____ het steeds lichter.

It is getting lighter outside.

[[Dutch#^nl-Q0571-answer|Compare the answer]]
^nl-Q0571

**nl-Q0572 · Choose the form**

Buiten ____ het steeds lichter.

It is getting lighter outside.

Choices: wordt / werden / worden / werd

[[Dutch#^nl-Q0572-answer|Compare the answer]]
^nl-Q0572

**nl-Q0573 · Edit the changed sentence**

Ze 【wordt】 gedwongen hun huis tegen hun wil in te verlaten.

They were forced to leave the house against their will.

[[Dutch#^nl-Q0573-answer|Compare the answer]]
^nl-Q0573

**nl-Q0574 · Build the sentence**

Arrange: verlaten. / tegen / gedwongen / hun / huis / in / werden / te / hun / Ze / wil

They were forced to leave the house against their will.

[[Dutch#^nl-Q0574-answer|Compare the answer]]
^nl-Q0574

**nl-Q0575 · Write a translation**

Write this in Dutch: He was operated on yesterday.

[[Dutch#^nl-Q0575-answer|Compare the answer]]
^nl-Q0575

**nl-Q0576 · Explain the grammar**

Hij 【werd】 gisteren geopereerd.

He was operated on yesterday.

[[Dutch#^nl-Q0576-answer|Compare the answer]]
^nl-Q0576

**nl-Q0577 · Fill the gap**

Veel werk kan vermeden ____.

A lot of work can be avoided.

[[Dutch#^nl-Q0577-answer|Compare the answer]]
^nl-Q0577

**nl-Q0578 · Choose the form**

Veel werk kan vermeden ____.

A lot of work can be avoided.

Choices: worden / werden / wordt / werd

[[Dutch#^nl-Q0578-answer|Compare the answer]]
^nl-Q0578

**nl-Q0579 · Edit the changed sentence**

In 2003 【wordt】 Niue de eerste "wifi"-natie ter wereld.

In 2003, Niue became the first "Wi-fi" nation in the world.

[[Dutch#^nl-Q0579-answer|Compare the answer]]
^nl-Q0579

**nl-Q0580 · Build the sentence**

Arrange: "wifi"-natie / eerste / wereld. / In / werd / de / Niue / 2003 / ter

In 2003, Niue became the first "Wi-fi" nation in the world.

[[Dutch#^nl-Q0580-answer|Compare the answer]]
^nl-Q0580

**nl-Q0581 · Write a translation**

Write this in Dutch: Tom wants to be liked.

[[Dutch#^nl-Q0581-answer|Compare the answer]]
^nl-Q0581

**nl-Q0582 · Explain the grammar**

Tom wil leuk gevonden 【worden】.

Tom wants to be liked.

[[Dutch#^nl-Q0582-answer|Compare the answer]]
^nl-Q0582

**nl-Q0583 · Fill the gap**

Niemand kan een dichter ____.

No one can be a poet.

[[Dutch#^nl-Q0583-answer|Compare the answer]]
^nl-Q0583

**nl-Q0584 · Choose the form**

Niemand kan een dichter ____.

No one can be a poet.

Choices: wordt / worden / werd / werden

[[Dutch#^nl-Q0584-answer|Compare the answer]]
^nl-Q0584

**nl-Q0585 · Edit the changed sentence**

Vlaamse Gebarentaal 【worden】 afgekort als VGT.

Flemish Sign Language is abbreviated to VGT.

[[Dutch#^nl-Q0585-answer|Compare the answer]]
^nl-Q0585

**nl-Q0586 · Build the sentence**

Arrange: als / afgekort / wordt / Gebarentaal / Vlaamse / VGT.

Flemish Sign Language is abbreviated to VGT.

[[Dutch#^nl-Q0586-answer|Compare the answer]]
^nl-Q0586

**nl-Q0587 · Write a translation**

Write this in Dutch: She got tested for HIV.

[[Dutch#^nl-Q0587-answer|Compare the answer]]
^nl-Q0587

**nl-Q0588 · Explain the grammar**

Ze 【werd】 op aids getest.

She got tested for HIV.

[[Dutch#^nl-Q0588-answer|Compare the answer]]
^nl-Q0588

**nl-Q0589 · Fill the gap**

Wanneer ik met mijn vingers knip zal je wakker ____.

When I snap my fingers, you'll wake up.

[[Dutch#^nl-Q0589-answer|Compare the answer]]
^nl-Q0589

**nl-Q0590 · Choose the form**

Wanneer ik met mijn vingers knip zal je wakker ____.

When I snap my fingers, you'll wake up.

Choices: werd / werden / worden / wordt

[[Dutch#^nl-Q0590-answer|Compare the answer]]
^nl-Q0590

**nl-Q0591 · Edit the changed sentence**

Als ik later groot ben, word ik piloot. En wat wil jij 【wordt】?

When I grow up, I'll be a pilot. And what will you be?

[[Dutch#^nl-Q0591-answer|Compare the answer]]
^nl-Q0591

**nl-Q0592 · Build the sentence**

Arrange: groot / wil / worden? / later / En / word / wat / ik / jij / Als / ben, / piloot. / ik

When I grow up, I'll be a pilot. And what will you be?

[[Dutch#^nl-Q0592-answer|Compare the answer]]
^nl-Q0592

**nl-Q0593 · Write a translation**

Write this in Dutch: Apples were served as the dessert.

[[Dutch#^nl-Q0593-answer|Compare the answer]]
^nl-Q0593

**nl-Q0594 · Explain the grammar**

Appels 【werden】 als nagerecht geserveerd.

Apples were served as the dessert.

[[Dutch#^nl-Q0594-answer|Compare the answer]]
^nl-Q0594

**nl-Q0595 · Fill the gap**

Waarom wil je verpleger ____?

Why do you want to be a nurse?

[[Dutch#^nl-Q0595-answer|Compare the answer]]
^nl-Q0595

**nl-Q0596 · Choose the form**

Waarom wil je verpleger ____?

Why do you want to be a nurse?

Choices: worden / wordt / werden / werd

[[Dutch#^nl-Q0596-answer|Compare the answer]]
^nl-Q0596

**nl-Q0597 · Edit the changed sentence**

Zij wil een zanger 【wordt】.

She wants to be a singer.

[[Dutch#^nl-Q0597-answer|Compare the answer]]
^nl-Q0597

**nl-Q0598 · Build the sentence**

Arrange: Zij / wil / worden. / een / zanger

She wants to be a singer.

[[Dutch#^nl-Q0598-answer|Compare the answer]]
^nl-Q0598

**nl-Q0599 · Write a translation**

Write this in Dutch: The United Arab Emirates is called "Al-’Imārat Al-‘Arabiyyah Al-Muttaḥidah" in Arabic.

[[Dutch#^nl-Q0599-answer|Compare the answer]]
^nl-Q0599

**nl-Q0600 · Explain the grammar**

De Verenigde Arabische Emiraten 【worden】 ''Al-’Imārat Al-‘Arabiyyah Al-Muttaḥidah'' genoemd in het Arabisch.

The United Arab Emirates is called "Al-’Imārat Al-‘Arabiyyah Al-Muttaḥidah" in Arabic.

[[Dutch#^nl-Q0600-answer|Compare the answer]]
^nl-Q0600


### Relative pronouns · 50 questions

**nl-Q0601 · Fill the gap**

Alle zinnen ____ we verzamelen geven we uit onder de licentie Creatieve Commons - Naamsvermelding.

We're releasing all the sentences we collect under the Creative Commons Attribution license.

[[Dutch#^nl-Q0601-answer|Compare the answer]]
^nl-Q0601

**nl-Q0602 · Choose the form**

Alle zinnen ____ we verzamelen geven we uit onder de licentie Creatieve Commons - Naamsvermelding.

We're releasing all the sentences we collect under the Creative Commons Attribution license.

Choices: wat / die / dat / wie

[[Dutch#^nl-Q0602-answer|Compare the answer]]
^nl-Q0602

**nl-Q0603 · Edit the changed sentence**

【die】 is je meest geliefde vakantiebestemming?

What's your favorite vacation place?

[[Dutch#^nl-Q0603-answer|Compare the answer]]
^nl-Q0603

**nl-Q0604 · Build the sentence**

Arrange: Wat / vakantiebestemming? / je / meest / geliefde / is

What's your favorite vacation place?

[[Dutch#^nl-Q0604-answer|Compare the answer]]
^nl-Q0604

**nl-Q0605 · Write a translation**

Write this in Dutch: Who do the keys belong to?

[[Dutch#^nl-Q0605-answer|Compare the answer]]
^nl-Q0605

**nl-Q0606 · Explain the grammar**

Van 【wie】 zijn de sleutels?

Who do the keys belong to?

[[Dutch#^nl-Q0606-answer|Compare the answer]]
^nl-Q0606

**nl-Q0607 · Fill the gap**

____ zijt gij?

Who are you?

[[Dutch#^nl-Q0607-answer|Compare the answer]]
^nl-Q0607

**nl-Q0608 · Choose the form**

____ zijt gij?

Who are you?

Choices: die / dat / wat / Wie

[[Dutch#^nl-Q0608-answer|Compare the answer]]
^nl-Q0608

**nl-Q0609 · Edit the changed sentence**

Ik weet 【die】 Tom gemotiveerd is.

I know that Tom is motivated.

[[Dutch#^nl-Q0609-answer|Compare the answer]]
^nl-Q0609

**nl-Q0610 · Build the sentence**

Arrange: gemotiveerd / is. / dat / Tom / Ik / weet

I know that Tom is motivated.

[[Dutch#^nl-Q0610-answer|Compare the answer]]
^nl-Q0610

**nl-Q0611 · Write a translation**

Write this in Dutch: Juliana told me you're from São Paulo.

[[Dutch#^nl-Q0611-answer|Compare the answer]]
^nl-Q0611

**nl-Q0612 · Explain the grammar**

Juliana vertelde me 【dat】 je uit São Paulo komt.

Juliana told me you're from São Paulo.

[[Dutch#^nl-Q0612-answer|Compare the answer]]
^nl-Q0612

**nl-Q0613 · Fill the gap**

Tom en Maria beweren ____ ze nooit tegen elkaar liegen.

Tom and Mary claim that they never lie to each other.

[[Dutch#^nl-Q0613-answer|Compare the answer]]
^nl-Q0613

**nl-Q0614 · Choose the form**

Tom en Maria beweren ____ ze nooit tegen elkaar liegen.

Tom and Mary claim that they never lie to each other.

Choices: die / dat / wie / wat

[[Dutch#^nl-Q0614-answer|Compare the answer]]
^nl-Q0614

**nl-Q0615 · Edit the changed sentence**

【die】 kind wierp een steen naar de hond.

That child threw a stone at the dog.

[[Dutch#^nl-Q0615-answer|Compare the answer]]
^nl-Q0615

**nl-Q0616 · Build the sentence**

Arrange: hond. / naar / Dat / steen / de / wierp / een / kind

That child threw a stone at the dog.

[[Dutch#^nl-Q0616-answer|Compare the answer]]
^nl-Q0616

**nl-Q0617 · Write a translation**

Write this in Dutch: Remember well what you learn at school.

[[Dutch#^nl-Q0617-answer|Compare the answer]]
^nl-Q0617

**nl-Q0618 · Explain the grammar**

Onthou goed 【wat】 ge op school leert.

Remember well what you learn at school.

[[Dutch#^nl-Q0618-answer|Compare the answer]]
^nl-Q0618

**nl-Q0619 · Fill the gap**

____ bracht me aan het lachen.

That made me laugh.

[[Dutch#^nl-Q0619-answer|Compare the answer]]
^nl-Q0619

**nl-Q0620 · Choose the form**

____ bracht me aan het lachen.

That made me laugh.

Choices: wie / wat / die / Dat

[[Dutch#^nl-Q0620-answer|Compare the answer]]
^nl-Q0620

**nl-Q0621 · Edit the changed sentence**

Ik zag 【die】 je hond deed.

I saw what your dog did.

[[Dutch#^nl-Q0621-answer|Compare the answer]]
^nl-Q0621

**nl-Q0622 · Build the sentence**

Arrange: je / deed. / Ik / zag / wat / hond

I saw what your dog did.

[[Dutch#^nl-Q0622-answer|Compare the answer]]
^nl-Q0622

**nl-Q0623 · Write a translation**

Write this in Dutch: Who do you live with?

[[Dutch#^nl-Q0623-answer|Compare the answer]]
^nl-Q0623

**nl-Q0624 · Explain the grammar**

Met 【wie】 woon je?

Who do you live with?

[[Dutch#^nl-Q0624-answer|Compare the answer]]
^nl-Q0624

**nl-Q0625 · Fill the gap**

____ mij betreft is Twitter tijdverspilling.

In my opinion, Twitter is a waste of time.

[[Dutch#^nl-Q0625-answer|Compare the answer]]
^nl-Q0625

**nl-Q0626 · Choose the form**

____ mij betreft is Twitter tijdverspilling.

In my opinion, Twitter is a waste of time.

Choices: Wat / wie / dat / die

[[Dutch#^nl-Q0626-answer|Compare the answer]]
^nl-Q0626

**nl-Q0627 · Edit the changed sentence**

【dat】 lamp ziet er leuk uit.

That lamp looks nice.

[[Dutch#^nl-Q0627-answer|Compare the answer]]
^nl-Q0627

**nl-Q0628 · Build the sentence**

Arrange: leuk / ziet / lamp / Die / uit. / er

That lamp looks nice.

[[Dutch#^nl-Q0628-answer|Compare the answer]]
^nl-Q0628

**nl-Q0629 · Write a translation**

Write this in Dutch: Who are you emailing?

[[Dutch#^nl-Q0629-answer|Compare the answer]]
^nl-Q0629

**nl-Q0630 · Explain the grammar**

【Wie】 e-mail je?

Who are you emailing?

[[Dutch#^nl-Q0630-answer|Compare the answer]]
^nl-Q0630

**nl-Q0631 · Fill the gap**

____ zien we later wel.

We'll see about that later.

[[Dutch#^nl-Q0631-answer|Compare the answer]]
^nl-Q0631

**nl-Q0632 · Choose the form**

____ zien we later wel.

We'll see about that later.

Choices: Dat / die / wie / wat

[[Dutch#^nl-Q0632-answer|Compare the answer]]
^nl-Q0632

**nl-Q0633 · Edit the changed sentence**

Ik probeer Tom over te halen 【die】 te doen.

I'm trying to convince Tom to do that.

[[Dutch#^nl-Q0633-answer|Compare the answer]]
^nl-Q0633

**nl-Q0634 · Build the sentence**

Arrange: te / Ik / dat / probeer / over / Tom / doen. / te / halen

I'm trying to convince Tom to do that.

[[Dutch#^nl-Q0634-answer|Compare the answer]]
^nl-Q0634

**nl-Q0635 · Write a translation**

Write this in Dutch: Why do you always wear that hat?

[[Dutch#^nl-Q0635-answer|Compare the answer]]
^nl-Q0635

**nl-Q0636 · Explain the grammar**

Waarom hebt gij altijd 【die】 hoed op?

Why do you always wear that hat?

[[Dutch#^nl-Q0636-answer|Compare the answer]]
^nl-Q0636

**nl-Q0637 · Fill the gap**

Als jij nou zegt: "Ik hou van jou," dan zeg ik ____ ook tegen jou.

If you say, "I love you," then I will also say that to you.

[[Dutch#^nl-Q0637-answer|Compare the answer]]
^nl-Q0637

**nl-Q0638 · Choose the form**

Als jij nou zegt: "Ik hou van jou," dan zeg ik ____ ook tegen jou.

If you say, "I love you," then I will also say that to you.

Choices: wat / wie / die / dat

[[Dutch#^nl-Q0638-answer|Compare the answer]]
^nl-Q0638

**nl-Q0639 · Edit the changed sentence**

【die】 is te klein om op je hoofd te passen.

That's too small to fit on your head.

[[Dutch#^nl-Q0639-answer|Compare the answer]]
^nl-Q0639

**nl-Q0640 · Build the sentence**

Arrange: klein / Dat / is / om / te / passen. / hoofd / je / te / op

That's too small to fit on your head.

[[Dutch#^nl-Q0640-answer|Compare the answer]]
^nl-Q0640

**nl-Q0641 · Write a translation**

Write this in Dutch: You should begin with books you can easily understand.

[[Dutch#^nl-Q0641-answer|Compare the answer]]
^nl-Q0641

**nl-Q0642 · Explain the grammar**

Je moet beginnen met boeken 【die】 je makkelijk kan begrijpen.

You should begin with books you can easily understand.

[[Dutch#^nl-Q0642-answer|Compare the answer]]
^nl-Q0642

**nl-Q0643 · Fill the gap**

Ik ben teleurgesteld ____ mijn vrienden niet hier zijn.

I am disappointed that my friends are not here.

[[Dutch#^nl-Q0643-answer|Compare the answer]]
^nl-Q0643

**nl-Q0644 · Choose the form**

Ik ben teleurgesteld ____ mijn vrienden niet hier zijn.

I am disappointed that my friends are not here.

Choices: wat / dat / die / wie

[[Dutch#^nl-Q0644-answer|Compare the answer]]
^nl-Q0644

**nl-Q0645 · Edit the changed sentence**

Ik herinner me 【dat】 muziek ooit ergens gehoord te hebben.

I remember hearing that music somewhere.

[[Dutch#^nl-Q0645-answer|Compare the answer]]
^nl-Q0645

**nl-Q0646 · Build the sentence**

Arrange: me / muziek / te / die / Ik / ooit / gehoord / ergens / hebben. / herinner

I remember hearing that music somewhere.

[[Dutch#^nl-Q0646-answer|Compare the answer]]
^nl-Q0646

**nl-Q0647 · Write a translation**

Write this in Dutch: I can't do that alone.

[[Dutch#^nl-Q0647-answer|Compare the answer]]
^nl-Q0647

**nl-Q0648 · Explain the grammar**

Ik kan 【dat】 niet alleen doen.

I can't do that alone.

[[Dutch#^nl-Q0648-answer|Compare the answer]]
^nl-Q0648

**nl-Q0649 · Fill the gap**

Doe ____ men je zegt.

Do what you're told.

[[Dutch#^nl-Q0649-answer|Compare the answer]]
^nl-Q0649

**nl-Q0650 · Choose the form**

Doe ____ men je zegt.

Do what you're told.

Choices: wat / wie / dat / die

[[Dutch#^nl-Q0650-answer|Compare the answer]]
^nl-Q0650


### Er in context · 50 questions

**nl-Q0651 · Edit the changed sentence**

De oude man zag 【daar】 wijs uit.

The old man looked wise.

[[Dutch#^nl-Q0651-answer|Compare the answer]]
^nl-Q0651

**nl-Q0652 · Build the sentence**

Arrange: uit. / er / oude / man / zag / De / wijs

The old man looked wise.

[[Dutch#^nl-Q0652-answer|Compare the answer]]
^nl-Q0652

**nl-Q0653 · Write a translation**

Write this in Dutch: You can see many animals in this forest.

[[Dutch#^nl-Q0653-answer|Compare the answer]]
^nl-Q0653

**nl-Q0654 · Explain the grammar**

【Er】 zijn veel dieren te zien in dit bos.

You can see many animals in this forest.

[[Dutch#^nl-Q0654-answer|Compare the answer]]
^nl-Q0654

**nl-Q0655 · Fill the gap**

____ zijn veel boeken in mijn kamer.

There are many books in my room.

[[Dutch#^nl-Q0655-answer|Compare the answer]]
^nl-Q0655

**nl-Q0656 · Choose the form**

____ zijn veel boeken in mijn kamer.

There are many books in my room.

Choices: hier / daar / Er

[[Dutch#^nl-Q0656-answer|Compare the answer]]
^nl-Q0656

**nl-Q0657 · Edit the changed sentence**

【daar】 zitten veertig leerlingen in onze klas.

There are forty students in our class.

[[Dutch#^nl-Q0657-answer|Compare the answer]]
^nl-Q0657

**nl-Q0658 · Build the sentence**

Arrange: klas. / zitten / veertig / onze / leerlingen / in / Er

There are forty students in our class.

[[Dutch#^nl-Q0658-answer|Compare the answer]]
^nl-Q0658

**nl-Q0659 · Write a translation**

Write this in Dutch: A fire broke out last night.

[[Dutch#^nl-Q0659-answer|Compare the answer]]
^nl-Q0659

**nl-Q0660 · Explain the grammar**

【Er】 is gisternacht een brand uitgebroken.

A fire broke out last night.

[[Dutch#^nl-Q0660-answer|Compare the answer]]
^nl-Q0660

**nl-Q0661 · Fill the gap**

De school ziet ____ uit als een gevangenis.

The school looks like a prison.

[[Dutch#^nl-Q0661-answer|Compare the answer]]
^nl-Q0661

**nl-Q0662 · Choose the form**

De school ziet ____ uit als een gevangenis.

The school looks like a prison.

Choices: daar / er / hier

[[Dutch#^nl-Q0662-answer|Compare the answer]]
^nl-Q0662

**nl-Q0663 · Edit the changed sentence**

【daar】 bevonden zich veel vogels in de boom.

There were a lot of birds in the tree.

[[Dutch#^nl-Q0663-answer|Compare the answer]]
^nl-Q0663

**nl-Q0664 · Build the sentence**

Arrange: Er / veel / de / boom. / zich / vogels / bevonden / in

There were a lot of birds in the tree.

[[Dutch#^nl-Q0664-answer|Compare the answer]]
^nl-Q0664

**nl-Q0665 · Write a translation**

Write this in Dutch: I'm sure you meant well.

[[Dutch#^nl-Q0665-answer|Compare the answer]]
^nl-Q0665

**nl-Q0666 · Explain the grammar**

Ik ben 【er】 zeker van dat je het goed bedoelde.

I'm sure you meant well.

[[Dutch#^nl-Q0666-answer|Compare the answer]]
^nl-Q0666

**nl-Q0667 · Fill the gap**

____ is melk in de koelkast.

There is milk in the refrigerator.

[[Dutch#^nl-Q0667-answer|Compare the answer]]
^nl-Q0667

**nl-Q0668 · Choose the form**

____ is melk in de koelkast.

There is milk in the refrigerator.

Choices: Er / daar / hier

[[Dutch#^nl-Q0668-answer|Compare the answer]]
^nl-Q0668

**nl-Q0669 · Edit the changed sentence**

【daar】 stond een straffe wind.

A strong wind was blowing.

[[Dutch#^nl-Q0669-answer|Compare the answer]]
^nl-Q0669

**nl-Q0670 · Build the sentence**

Arrange: wind. / Er / straffe / stond / een

A strong wind was blowing.

[[Dutch#^nl-Q0670-answer|Compare the answer]]
^nl-Q0670

**nl-Q0671 · Write a translation**

Write this in Dutch: Who else is going with us?

[[Dutch#^nl-Q0671-answer|Compare the answer]]
^nl-Q0671

**nl-Q0672 · Explain the grammar**

Wie gaat 【er】 nog meer met ons mee?

Who else is going with us?

[[Dutch#^nl-Q0672-answer|Compare the answer]]
^nl-Q0672

**nl-Q0673 · Fill the gap**

Wie wil ____ warme chocolademelk?

Who wants some hot chocolate?

[[Dutch#^nl-Q0673-answer|Compare the answer]]
^nl-Q0673

**nl-Q0674 · Choose the form**

Wie wil ____ warme chocolademelk?

Who wants some hot chocolate?

Choices: daar / hier / er

[[Dutch#^nl-Q0674-answer|Compare the answer]]
^nl-Q0674

**nl-Q0675 · Edit the changed sentence**

Wat is 【daar】 aan de hand?

What's going on?

[[Dutch#^nl-Q0675-answer|Compare the answer]]
^nl-Q0675

**nl-Q0676 · Build the sentence**

Arrange: is / er / hand? / Wat / de / aan

What's going on?

[[Dutch#^nl-Q0676-answer|Compare the answer]]
^nl-Q0676

**nl-Q0677 · Write a translation**

Write this in Dutch: I'll go back there.

[[Dutch#^nl-Q0677-answer|Compare the answer]]
^nl-Q0677

**nl-Q0678 · Explain the grammar**

Ik keer 【er】 terug.

I'll go back there.

[[Dutch#^nl-Q0678-answer|Compare the answer]]
^nl-Q0678

**nl-Q0679 · Fill the gap**

Denk je echt dat ik ____ wat mee te maken had?

Do you really think I had something to do with that?

[[Dutch#^nl-Q0679-answer|Compare the answer]]
^nl-Q0679

**nl-Q0680 · Choose the form**

Denk je echt dat ik ____ wat mee te maken had?

Do you really think I had something to do with that?

Choices: daar / hier / er

[[Dutch#^nl-Q0680-answer|Compare the answer]]
^nl-Q0680

**nl-Q0681 · Edit the changed sentence**

【daar】 is tijd genoeg om dit huiswerk af te maken.

There is enough time to finish this homework.

[[Dutch#^nl-Q0681-answer|Compare the answer]]
^nl-Q0681

**nl-Q0682 · Build the sentence**

Arrange: af / genoeg / dit / tijd / is / Er / maken. / te / huiswerk / om

There is enough time to finish this homework.

[[Dutch#^nl-Q0682-answer|Compare the answer]]
^nl-Q0682

**nl-Q0683 · Write a translation**

Write this in Dutch: Let’s have another!

[[Dutch#^nl-Q0683-answer|Compare the answer]]
^nl-Q0683

**nl-Q0684 · Explain the grammar**

Laten we 【er】 nog eentje nemen!

Let’s have another!

[[Dutch#^nl-Q0684-answer|Compare the answer]]
^nl-Q0684

**nl-Q0685 · Fill the gap**

____ was eens een slechte koning in Engeland.

Once upon a time, there was a bad king in England.

[[Dutch#^nl-Q0685-answer|Compare the answer]]
^nl-Q0685

**nl-Q0686 · Choose the form**

____ was eens een slechte koning in Engeland.

Once upon a time, there was a bad king in England.

Choices: daar / hier / Er

[[Dutch#^nl-Q0686-answer|Compare the answer]]
^nl-Q0686

**nl-Q0687 · Edit the changed sentence**

Ik geef 【daar】 geen bal om!

I don't give a damn about it!

[[Dutch#^nl-Q0687-answer|Compare the answer]]
^nl-Q0687

**nl-Q0688 · Build the sentence**

Arrange: geen / om! / Ik / bal / geef / er

I don't give a damn about it!

[[Dutch#^nl-Q0688-answer|Compare the answer]]
^nl-Q0688

**nl-Q0689 · Write a translation**

Write this in Dutch: There are no gay people in this country.

[[Dutch#^nl-Q0689-answer|Compare the answer]]
^nl-Q0689

**nl-Q0690 · Explain the grammar**

【Er】 zijn geen gay mensen in dit land.

There are no gay people in this country.

[[Dutch#^nl-Q0690-answer|Compare the answer]]
^nl-Q0690

**nl-Q0691 · Fill the gap**

We moeten ____ zeker van zijn dat we gelijk hebben.

We have to be sure we're right.

[[Dutch#^nl-Q0691-answer|Compare the answer]]
^nl-Q0691

**nl-Q0692 · Choose the form**

We moeten ____ zeker van zijn dat we gelijk hebben.

We have to be sure we're right.

Choices: hier / er / daar

[[Dutch#^nl-Q0692-answer|Compare the answer]]
^nl-Q0692

**nl-Q0693 · Edit the changed sentence**

【daar】 zijn nu geen woorden nodig, maar daden.

Not words but action is needed now.

[[Dutch#^nl-Q0693-answer|Compare the answer]]
^nl-Q0693

**nl-Q0694 · Build the sentence**

Arrange: nu / maar / daden. / nodig, / zijn / Er / woorden / geen

Not words but action is needed now.

[[Dutch#^nl-Q0694-answer|Compare the answer]]
^nl-Q0694

**nl-Q0695 · Write a translation**

Write this in Dutch: Something about Dan has changed.

[[Dutch#^nl-Q0695-answer|Compare the answer]]
^nl-Q0695

**nl-Q0696 · Explain the grammar**

【Er】 is iets aan Dan veranderd.

Something about Dan has changed.

[[Dutch#^nl-Q0696-answer|Compare the answer]]
^nl-Q0696

**nl-Q0697 · Fill the gap**

Gisteren is ____ op dat zebrapad een voetganger door een vrachtwagen overreden.

Yesterday a pedestrian was run over by a truck at this pedestrian crossing.

[[Dutch#^nl-Q0697-answer|Compare the answer]]
^nl-Q0697

**nl-Q0698 · Choose the form**

Gisteren is ____ op dat zebrapad een voetganger door een vrachtwagen overreden.

Yesterday a pedestrian was run over by a truck at this pedestrian crossing.

Choices: hier / er / daar

[[Dutch#^nl-Q0698-answer|Compare the answer]]
^nl-Q0698

**nl-Q0699 · Edit the changed sentence**

Ik ga 【daar】 alleen heen.

I'm going there alone.

[[Dutch#^nl-Q0699-answer|Compare the answer]]
^nl-Q0699

**nl-Q0700 · Build the sentence**

Arrange: Ik / heen. / alleen / er / ga

I'm going there alone.

[[Dutch#^nl-Q0700-answer|Compare the answer]]
^nl-Q0700


### Infinitives and purpose · 50 questions

**nl-Q0701 · Write a translation**

Write this in Dutch: She went down on her knees to pray.

[[Dutch#^nl-Q0701-answer|Compare the answer]]
^nl-Q0701

**nl-Q0702 · Explain the grammar**

Ze ging op haar knieën 【om】 te bidden.

She went down on her knees to pray.

[[Dutch#^nl-Q0702-answer|Compare the answer]]
^nl-Q0702

**nl-Q0703 · Fill the gap**

Tom zat op de bank ____ roken.

Tom sat on the bench smoking.

[[Dutch#^nl-Q0703-answer|Compare the answer]]
^nl-Q0703

**nl-Q0704 · Choose the form**

Tom zat op de bank ____ roken.

Tom sat on the bench smoking.

Choices: te / om / zonder

[[Dutch#^nl-Q0704-answer|Compare the answer]]
^nl-Q0704

**nl-Q0705 · Edit the changed sentence**

Tom rijdt altijd 【om】 hard.

Tom always drives too fast.

[[Dutch#^nl-Q0705-answer|Compare the answer]]
^nl-Q0705

**nl-Q0706 · Build the sentence**

Arrange: rijdt / altijd / Tom / te / hard.

Tom always drives too fast.

[[Dutch#^nl-Q0706-answer|Compare the answer]]
^nl-Q0706

**nl-Q0707 · Write a translation**

Write this in Dutch: He offered to help me.

[[Dutch#^nl-Q0707-answer|Compare the answer]]
^nl-Q0707

**nl-Q0708 · Explain the grammar**

Hij heeft aangeboden me 【te】 helpen.

He offered to help me.

[[Dutch#^nl-Q0708-answer|Compare the answer]]
^nl-Q0708

**nl-Q0709 · Fill the gap**

Zat je naar mijn benen ____ staren?

Were you staring at my legs?

[[Dutch#^nl-Q0709-answer|Compare the answer]]
^nl-Q0709

**nl-Q0710 · Choose the form**

Zat je naar mijn benen ____ staren?

Were you staring at my legs?

Choices: om / zonder / te

[[Dutch#^nl-Q0710-answer|Compare the answer]]
^nl-Q0710

**nl-Q0711 · Edit the changed sentence**

Hoelang gaat het duren 【te】 daar te komen?

How long will it take to get there?

[[Dutch#^nl-Q0711-answer|Compare the answer]]
^nl-Q0711

**nl-Q0712 · Build the sentence**

Arrange: het / Hoelang / gaat / te / komen? / duren / daar / om

How long will it take to get there?

[[Dutch#^nl-Q0712-answer|Compare the answer]]
^nl-Q0712

**nl-Q0713 · Write a translation**

Write this in Dutch: Oh? You can type without looking at the keyboard. That's cool!

[[Dutch#^nl-Q0713-answer|Compare the answer]]
^nl-Q0713

**nl-Q0714 · Explain the grammar**

Hé, jij kunt tikken zonder 【te】 kijken naar het toetsenbord. Cool zeg!

Oh? You can type without looking at the keyboard. That's cool!

[[Dutch#^nl-Q0714-answer|Compare the answer]]
^nl-Q0714

**nl-Q0715 · Fill the gap**

De tijd is ____.

Time is up.

[[Dutch#^nl-Q0715-answer|Compare the answer]]
^nl-Q0715

**nl-Q0716 · Choose the form**

De tijd is ____.

Time is up.

Choices: zonder / te / om

[[Dutch#^nl-Q0716-answer|Compare the answer]]
^nl-Q0716

**nl-Q0717 · Edit the changed sentence**

Dima paste het pak, maar het bleek 【om】 groot te zijn.

Trying on the suit, Dima found it to be too big.

[[Dutch#^nl-Q0717-answer|Compare the answer]]
^nl-Q0717

**nl-Q0718 · Build the sentence**

Arrange: het / Dima / maar / groot / te / te / paste / pak, / bleek / het / zijn.

Trying on the suit, Dima found it to be too big.

[[Dutch#^nl-Q0718-answer|Compare the answer]]
^nl-Q0718

**nl-Q0719 · Write a translation**

Write this in Dutch: Choose which card to discard.

[[Dutch#^nl-Q0719-answer|Compare the answer]]
^nl-Q0719

**nl-Q0720 · Explain the grammar**

Kies een kaart 【om】 weg te gooien.

Choose which card to discard.

[[Dutch#^nl-Q0720-answer|Compare the answer]]
^nl-Q0720

**nl-Q0721 · Fill the gap**

Deze vogel dreigt nu uit ____ sterven.

That bird is now in danger of dying out.

[[Dutch#^nl-Q0721-answer|Compare the answer]]
^nl-Q0721

**nl-Q0722 · Choose the form**

Deze vogel dreigt nu uit ____ sterven.

That bird is now in danger of dying out.

Choices: zonder / om / te

[[Dutch#^nl-Q0722-answer|Compare the answer]]
^nl-Q0722

**nl-Q0723 · Edit the changed sentence**

Hebt ge tijd 【te】 mij te helpen?

Do you have time to help me?

[[Dutch#^nl-Q0723-answer|Compare the answer]]
^nl-Q0723

**nl-Q0724 · Build the sentence**

Arrange: tijd / Hebt / helpen? / ge / te / om / mij

Do you have time to help me?

[[Dutch#^nl-Q0724-answer|Compare the answer]]
^nl-Q0724

**nl-Q0725 · Write a translation**

Write this in Dutch: Tom decided to buy a used car instead of a new one.

[[Dutch#^nl-Q0725-answer|Compare the answer]]
^nl-Q0725

**nl-Q0726 · Explain the grammar**

Tom besloot een tweedehandsauto 【te】 kopen in plaats van een nieuwe.

Tom decided to buy a used car instead of a new one.

[[Dutch#^nl-Q0726-answer|Compare the answer]]
^nl-Q0726

**nl-Q0727 · Fill the gap**

Kan je wachten tot vanmiddag ____ 2:30 uur?

Can you wait until 2:30 this afternoon?

[[Dutch#^nl-Q0727-answer|Compare the answer]]
^nl-Q0727

**nl-Q0728 · Choose the form**

Kan je wachten tot vanmiddag ____ 2:30 uur?

Can you wait until 2:30 this afternoon?

Choices: te / zonder / om

[[Dutch#^nl-Q0728-answer|Compare the answer]]
^nl-Q0728

**nl-Q0729 · Edit the changed sentence**

Jij hoort beneden 【om】 zijn.

You're supposed to be downstairs.

[[Dutch#^nl-Q0729-answer|Compare the answer]]
^nl-Q0729

**nl-Q0730 · Build the sentence**

Arrange: hoort / te / Jij / zijn. / beneden

You're supposed to be downstairs.

[[Dutch#^nl-Q0730-answer|Compare the answer]]
^nl-Q0730

**nl-Q0731 · Write a translation**

Write this in Dutch: Shine your shoes before going out.

[[Dutch#^nl-Q0731-answer|Compare the answer]]
^nl-Q0731

**nl-Q0732 · Explain the grammar**

Poets je schoenen vooraleer weg 【te】 gaan.

Shine your shoes before going out.

[[Dutch#^nl-Q0732-answer|Compare the answer]]
^nl-Q0732

**nl-Q0733 · Fill the gap**

Ik ben vergeten brood ____ kopen.

I forgot to buy bread.

[[Dutch#^nl-Q0733-answer|Compare the answer]]
^nl-Q0733

**nl-Q0734 · Choose the form**

Ik ben vergeten brood ____ kopen.

I forgot to buy bread.

Choices: zonder / om / te

[[Dutch#^nl-Q0734-answer|Compare the answer]]
^nl-Q0734

**nl-Q0735 · Edit the changed sentence**

Tom liet me zweren het niet tegen Mary 【om】 zeggen.

Tom made me swear not to tell Mary.

[[Dutch#^nl-Q0735-answer|Compare the answer]]
^nl-Q0735

**nl-Q0736 · Build the sentence**

Arrange: liet / Tom / te / niet / me / Mary / het / zweren / zeggen. / tegen

Tom made me swear not to tell Mary.

[[Dutch#^nl-Q0736-answer|Compare the answer]]
^nl-Q0736

**nl-Q0737 · Write a translation**

Write this in Dutch: It was such a fine day that we decided to have a picnic.

[[Dutch#^nl-Q0737-answer|Compare the answer]]
^nl-Q0737

**nl-Q0738 · Explain the grammar**

Het was zo'n mooie dag, dat we besloten 【te】 gaan picknicken.

It was such a fine day that we decided to have a picnic.

[[Dutch#^nl-Q0738-answer|Compare the answer]]
^nl-Q0738

**nl-Q0739 · Fill the gap**

Ik had een uur nodig ____ het gedicht van buiten te leren.

It took me an hour to learn the poem by heart.

[[Dutch#^nl-Q0739-answer|Compare the answer]]
^nl-Q0739

**nl-Q0740 · Choose the form**

Ik had een uur nodig ____ het gedicht van buiten te leren.

It took me an hour to learn the poem by heart.

Choices: om / zonder / te

[[Dutch#^nl-Q0740-answer|Compare the answer]]
^nl-Q0740

**nl-Q0741 · Edit the changed sentence**

Het is niet goed 【om】 weten dat iets onaangenaams ons zal overkomen, zoals bijvoorbeeld een bezoek aan de tandarts, of aan Frankrijk.

If you know that something unpleasant will happen, that you will go to the dentist for example, or to France, then that is not good.

[[Dutch#^nl-Q0741-answer|Compare the answer]]
^nl-Q0741

**nl-Q0742 · Build the sentence**

Arrange: aan / overkomen, / weten / of / Het / ons / dat / tandarts, / is / een / iets / aan / de / te / niet / zal / Frankrijk. / zoals / onaangenaams / bijvoorbeeld / goed / bezoek

If you know that something unpleasant will happen, that you will go to the dentist for example, or to France, then that is not good.

[[Dutch#^nl-Q0742-answer|Compare the answer]]
^nl-Q0742

**nl-Q0743 · Write a translation**

Write this in Dutch: He decided not to wait any longer.

[[Dutch#^nl-Q0743-answer|Compare the answer]]
^nl-Q0743

**nl-Q0744 · Explain the grammar**

Hij besloot niet langer 【te】 wachten.

He decided not to wait any longer.

[[Dutch#^nl-Q0744-answer|Compare the answer]]
^nl-Q0744

**nl-Q0745 · Fill the gap**

Ik begin ____ vermoeden dat ik de liefde van mijn leven ben.

I am beginning to suspect that I am the love of my life.

[[Dutch#^nl-Q0745-answer|Compare the answer]]
^nl-Q0745

**nl-Q0746 · Choose the form**

Ik begin ____ vermoeden dat ik de liefde van mijn leven ben.

I am beginning to suspect that I am the love of my life.

Choices: zonder / om / te

[[Dutch#^nl-Q0746-answer|Compare the answer]]
^nl-Q0746

**nl-Q0747 · Edit the changed sentence**

Het lijkt een misverstand 【om】 zijn.

It seems to be a misunderstanding.

[[Dutch#^nl-Q0747-answer|Compare the answer]]
^nl-Q0747

**nl-Q0748 · Build the sentence**

Arrange: lijkt / te / een / zijn. / misverstand / Het

It seems to be a misunderstanding.

[[Dutch#^nl-Q0748-answer|Compare the answer]]
^nl-Q0748

**nl-Q0749 · Write a translation**

Write this in Dutch: I cannot thank you too much.

[[Dutch#^nl-Q0749-answer|Compare the answer]]
^nl-Q0749

**nl-Q0750 · Explain the grammar**

Ik kan u niet 【te】 veel danken.

I cannot thank you too much.

[[Dutch#^nl-Q0750-answer|Compare the answer]]
^nl-Q0750


### Adjectives · 50 questions

**nl-Q0751 · Fill the gap**

Ik woon in een heel ____ appartement.

I live in a very small apartment.

[[Dutch#^nl-Q0751-answer|Compare the answer]]
^nl-Q0751

**nl-Q0752 · Choose the form**

Ik woon in een heel ____ appartement.

I live in a very small apartment.

Choices: goede / klein / nieuw / goed

[[Dutch#^nl-Q0752-answer|Compare the answer]]
^nl-Q0752

**nl-Q0753 · Edit the changed sentence**

Dit is 【goede】 vlees.

This is good meat.

[[Dutch#^nl-Q0753-answer|Compare the answer]]
^nl-Q0753

**nl-Q0754 · Build the sentence**

Arrange: vlees. / goed / is / Dit

This is good meat.

[[Dutch#^nl-Q0754-answer|Compare the answer]]
^nl-Q0754

**nl-Q0755 · Write a translation**

Write this in Dutch: Luxembourg is a small country.

[[Dutch#^nl-Q0755-answer|Compare the answer]]
^nl-Q0755

**nl-Q0756 · Explain the grammar**

Luxemburg is een 【klein】 land.

Luxembourg is a small country.

[[Dutch#^nl-Q0756-answer|Compare the answer]]
^nl-Q0756

**nl-Q0757 · Fill the gap**

Ik at met mijn ____ broer.

I ate with my baby brother.

[[Dutch#^nl-Q0757-answer|Compare the answer]]
^nl-Q0757

**nl-Q0758 · Choose the form**

Ik at met mijn ____ broer.

I ate with my baby brother.

Choices: nieuw / goede / goed / kleine

[[Dutch#^nl-Q0758-answer|Compare the answer]]
^nl-Q0758

**nl-Q0759 · Edit the changed sentence**

Deze stof houdt zich 【goede】.

This fabric wears well.

[[Dutch#^nl-Q0759-answer|Compare the answer]]
^nl-Q0759

**nl-Q0760 · Build the sentence**

Arrange: zich / goed. / Deze / houdt / stof

This fabric wears well.

[[Dutch#^nl-Q0760-answer|Compare the answer]]
^nl-Q0760

**nl-Q0761 · Write a translation**

Write this in Dutch: Bacteria are just tiny cells, harmless.

[[Dutch#^nl-Q0761-answer|Compare the answer]]
^nl-Q0761

**nl-Q0762 · Explain the grammar**

Bacteriën zijn maar 【kleine】, onschadelijke cellen.

Bacteria are just tiny cells, harmless.

[[Dutch#^nl-Q0762-answer|Compare the answer]]
^nl-Q0762

**nl-Q0763 · Fill the gap**

Dank u, met mij gaat het ____.

Thanks, I'm fine.

[[Dutch#^nl-Q0763-answer|Compare the answer]]
^nl-Q0763

**nl-Q0764 · Choose the form**

Dank u, met mij gaat het ____.

Thanks, I'm fine.

Choices: nieuw / goed / goede / nieuwe

[[Dutch#^nl-Q0764-answer|Compare the answer]]
^nl-Q0764

**nl-Q0765 · Edit the changed sentence**

Alles komt 【goede】.

Everything will be OK.

[[Dutch#^nl-Q0765-answer|Compare the answer]]
^nl-Q0765

**nl-Q0766 · Build the sentence**

Arrange: komt / goed. / Alles

Everything will be OK.

[[Dutch#^nl-Q0766-answer|Compare the answer]]
^nl-Q0766

**nl-Q0767 · Write a translation**

Write this in Dutch: Canada is a large country.

[[Dutch#^nl-Q0767-answer|Compare the answer]]
^nl-Q0767

**nl-Q0768 · Explain the grammar**

Canada is een 【groot】 land.

Canada is a large country.

[[Dutch#^nl-Q0768-answer|Compare the answer]]
^nl-Q0768

**nl-Q0769 · Fill the gap**

Als je het geel verft, sla je twee vliegen in één klap: én het valt ____ op, én je bespaart geld omdat je verf kunt gebruiken die je al in huis hebt.

If you paint it yellow, you'll kill two birds with one stone: it'll stand out, and you'll save money because you can use paint you already have.

[[Dutch#^nl-Q0769-answer|Compare the answer]]
^nl-Q0769

**nl-Q0770 · Choose the form**

Als je het geel verft, sla je twee vliegen in één klap: én het valt ____ op, én je bespaart geld omdat je verf kunt gebruiken die je al in huis hebt.

If you paint it yellow, you'll kill two birds with one stone: it'll stand out, and you'll save money because you can use paint you already have.

Choices: goede / nieuw / goed / nieuwe

[[Dutch#^nl-Q0770-answer|Compare the answer]]
^nl-Q0770

**nl-Q0771 · Edit the changed sentence**

Plotseling kreeg ik een 【goede】 idee.

Suddenly, a good idea occurred to me.

[[Dutch#^nl-Q0771-answer|Compare the answer]]
^nl-Q0771

**nl-Q0772 · Build the sentence**

Arrange: goed / kreeg / een / idee. / Plotseling / ik

Suddenly, a good idea occurred to me.

[[Dutch#^nl-Q0772-answer|Compare the answer]]
^nl-Q0772

**nl-Q0773 · Write a translation**

Write this in Dutch: I can speak a tiny bit of French.

[[Dutch#^nl-Q0773-answer|Compare the answer]]
^nl-Q0773

**nl-Q0774 · Explain the grammar**

Ik kan een 【klein】 beetje Frans spreken.

I can speak a tiny bit of French.

[[Dutch#^nl-Q0774-answer|Compare the answer]]
^nl-Q0774

**nl-Q0775 · Fill the gap**

Gisteren ging ik naar de dierentuin en zag ik een heel ____ walrus.

Yesterday I went to the zoo and saw a huge walrus.

[[Dutch#^nl-Q0775-answer|Compare the answer]]
^nl-Q0775

**nl-Q0776 · Choose the form**

Gisteren ging ik naar de dierentuin en zag ik een heel ____ walrus.

Yesterday I went to the zoo and saw a huge walrus.

Choices: goed / goede / grote / nieuw

[[Dutch#^nl-Q0776-answer|Compare the answer]]
^nl-Q0776

**nl-Q0777 · Edit the changed sentence**

【goed】 meisjes gaan naar de hemel, slechte meisjes gaan naar overal.

Good girls go to heaven, bad girls go everywhere.

[[Dutch#^nl-Q0777-answer|Compare the answer]]
^nl-Q0777

**nl-Q0778 · Build the sentence**

Arrange: meisjes / naar / slechte / Goede / meisjes / hemel, / gaan / de / overal. / gaan / naar

Good girls go to heaven, bad girls go everywhere.

[[Dutch#^nl-Q0778-answer|Compare the answer]]
^nl-Q0778

**nl-Q0779 · Write a translation**

Write this in Dutch: He won the election by a large majority.

[[Dutch#^nl-Q0779-answer|Compare the answer]]
^nl-Q0779

**nl-Q0780 · Explain the grammar**

Hij heeft de verkiezingen gewonnen met een 【grote】 meerderheid.

He won the election by a large majority.

[[Dutch#^nl-Q0780-answer|Compare the answer]]
^nl-Q0780

**nl-Q0781 · Fill the gap**

Ik ben helemaal niet ____ in Duits.

I am not good at German at all.

[[Dutch#^nl-Q0781-answer|Compare the answer]]
^nl-Q0781

**nl-Q0782 · Choose the form**

Ik ben helemaal niet ____ in Duits.

I am not good at German at all.

Choices: nieuwe / goede / nieuw / goed

[[Dutch#^nl-Q0782-answer|Compare the answer]]
^nl-Q0782

**nl-Q0783 · Edit the changed sentence**

Komaan, alles komt 【goede】.

Come on, everything will be alright.

[[Dutch#^nl-Q0783-answer|Compare the answer]]
^nl-Q0783

**nl-Q0784 · Build the sentence**

Arrange: komt / Komaan, / alles / goed.

Come on, everything will be alright.

[[Dutch#^nl-Q0784-answer|Compare the answer]]
^nl-Q0784

**nl-Q0785 · Write a translation**

Write this in Dutch: I noticed she was wearing a new hat.

[[Dutch#^nl-Q0785-answer|Compare the answer]]
^nl-Q0785

**nl-Q0786 · Explain the grammar**

Ik merkte dat ze een 【nieuwe】 hoed droeg.

I noticed she was wearing a new hat.

[[Dutch#^nl-Q0786-answer|Compare the answer]]
^nl-Q0786

**nl-Q0787 · Fill the gap**

Hij heeft een ____ jongen van de verdrinkingsdood gered.

He saved a little boy from drowning.

[[Dutch#^nl-Q0787-answer|Compare the answer]]
^nl-Q0787

**nl-Q0788 · Choose the form**

Hij heeft een ____ jongen van de verdrinkingsdood gered.

He saved a little boy from drowning.

Choices: nieuw / kleine / goed / goede

[[Dutch#^nl-Q0788-answer|Compare the answer]]
^nl-Q0788

**nl-Q0789 · Edit the changed sentence**

Is dat jouw 【goed】 vriendin?

Is that your new girlfriend?

[[Dutch#^nl-Q0789-answer|Compare the answer]]
^nl-Q0789

**nl-Q0790 · Build the sentence**

Arrange: jouw / dat / vriendin? / Is / nieuwe

Is that your new girlfriend?

[[Dutch#^nl-Q0790-answer|Compare the answer]]
^nl-Q0790

**nl-Q0791 · Write a translation**

Write this in Dutch: There's a new restaurant on Cherry Avenue.

[[Dutch#^nl-Q0791-answer|Compare the answer]]
^nl-Q0791

**nl-Q0792 · Explain the grammar**

Er is een 【nieuw】 restaurant op Cherry Avenue.

There's a new restaurant on Cherry Avenue.

[[Dutch#^nl-Q0792-answer|Compare the answer]]
^nl-Q0792

**nl-Q0793 · Fill the gap**

Het ____ semester begint in april in Japan.

The new term starts in April in Japan.

[[Dutch#^nl-Q0793-answer|Compare the answer]]
^nl-Q0793

**nl-Q0794 · Choose the form**

Het ____ semester begint in april in Japan.

The new term starts in April in Japan.

Choices: nieuw / goede / goed / nieuwe

[[Dutch#^nl-Q0794-answer|Compare the answer]]
^nl-Q0794

**nl-Q0795 · Edit the changed sentence**

Dit woordenboek is niet 【goede】.

This dictionary is no good.

[[Dutch#^nl-Q0795-answer|Compare the answer]]
^nl-Q0795

**nl-Q0796 · Build the sentence**

Arrange: niet / woordenboek / goed. / Dit / is

This dictionary is no good.

[[Dutch#^nl-Q0796-answer|Compare the answer]]
^nl-Q0796

**nl-Q0797 · Write a translation**

Write this in Dutch: Good wine needs no bush.

[[Dutch#^nl-Q0797-answer|Compare the answer]]
^nl-Q0797

**nl-Q0798 · Explain the grammar**

【Goede】 wijn behoeft geen krans.

Good wine needs no bush.

[[Dutch#^nl-Q0798-answer|Compare the answer]]
^nl-Q0798

**nl-Q0799 · Fill the gap**

Ik verblijf in een ____ pensionnetje.

I'm staying at a small guesthouse.

[[Dutch#^nl-Q0799-answer|Compare the answer]]
^nl-Q0799

**nl-Q0800 · Choose the form**

Ik verblijf in een ____ pensionnetje.

I'm staying at a small guesthouse.

Choices: goed / goede / nieuw / klein

[[Dutch#^nl-Q0800-answer|Compare the answer]]
^nl-Q0800


### Coordination · 50 questions

**nl-Q0801 · Edit the changed sentence**

Tom 【maar】 Maria zijn aan het liften.

Tom and Mary are hitchhiking.

[[Dutch#^nl-Q0801-answer|Compare the answer]]
^nl-Q0801

**nl-Q0802 · Build the sentence**

Arrange: zijn / en / liften. / aan / het / Tom / Maria

Tom and Mary are hitchhiking.

[[Dutch#^nl-Q0802-answer|Compare the answer]]
^nl-Q0802

**nl-Q0803 · Write a translation**

Write this in Dutch: He's young, but he's very intelligent.

[[Dutch#^nl-Q0803-answer|Compare the answer]]
^nl-Q0803

**nl-Q0804 · Explain the grammar**

Hij is jong, 【maar】 wel heel intelligent.

He's young, but he's very intelligent.

[[Dutch#^nl-Q0804-answer|Compare the answer]]
^nl-Q0804

**nl-Q0805 · Fill the gap**

Ze exporteren veel fruit, zoals sinaasappels, grapefruits ____ citroenen.

They export a lot of fruit, such as oranges, grapefruits and lemons.

[[Dutch#^nl-Q0805-answer|Compare the answer]]
^nl-Q0805

**nl-Q0806 · Choose the form**

Ze exporteren veel fruit, zoals sinaasappels, grapefruits ____ citroenen.

They export a lot of fruit, such as oranges, grapefruits and lemons.

Choices: of / maar / en / want

[[Dutch#^nl-Q0806-answer|Compare the answer]]
^nl-Q0806

**nl-Q0807 · Edit the changed sentence**

Bel mij af 【maar】 toe.

Call me once in a while.

[[Dutch#^nl-Q0807-answer|Compare the answer]]
^nl-Q0807

**nl-Q0808 · Build the sentence**

Arrange: mij / en / toe. / Bel / af

Call me once in a while.

[[Dutch#^nl-Q0808-answer|Compare the answer]]
^nl-Q0808

**nl-Q0809 · Write a translation**

Write this in Dutch: Research requires a lot of energy, but it's worth the effort.

[[Dutch#^nl-Q0809-answer|Compare the answer]]
^nl-Q0809

**nl-Q0810 · Explain the grammar**

Onderzoek vergt veel energie, 【maar】 het is de moeite waard.

Research requires a lot of energy, but it's worth the effort.

[[Dutch#^nl-Q0810-answer|Compare the answer]]
^nl-Q0810

**nl-Q0811 · Fill the gap**

Het leven zuigt ____ dan ga je dood.

Life is a bitch and then you die.

[[Dutch#^nl-Q0811-answer|Compare the answer]]
^nl-Q0811

**nl-Q0812 · Choose the form**

Het leven zuigt ____ dan ga je dood.

Life is a bitch and then you die.

Choices: of / maar / want / en

[[Dutch#^nl-Q0812-answer|Compare the answer]]
^nl-Q0812

**nl-Q0813 · Edit the changed sentence**

Geef me uw naam 【maar】 telefoonnummer.

Please tell me your name and telephone number.

[[Dutch#^nl-Q0813-answer|Compare the answer]]
^nl-Q0813

**nl-Q0814 · Build the sentence**

Arrange: me / telefoonnummer. / naam / Geef / uw / en

Please tell me your name and telephone number.

[[Dutch#^nl-Q0814-answer|Compare the answer]]
^nl-Q0814

**nl-Q0815 · Write a translation**

Write this in Dutch: I only spent three dollars.

[[Dutch#^nl-Q0815-answer|Compare the answer]]
^nl-Q0815

**nl-Q0816 · Explain the grammar**

Ik heb 【maar】 drie dollar uitgegeven.

I only spent three dollars.

[[Dutch#^nl-Q0816-answer|Compare the answer]]
^nl-Q0816

**nl-Q0817 · Fill the gap**

Je kan ____ beter het licht uitdoen voordat je gaat slapen.

You had better turn off the light before you go to sleep.

[[Dutch#^nl-Q0817-answer|Compare the answer]]
^nl-Q0817

**nl-Q0818 · Choose the form**

Je kan ____ beter het licht uitdoen voordat je gaat slapen.

You had better turn off the light before you go to sleep.

Choices: of / maar / en / want

[[Dutch#^nl-Q0818-answer|Compare the answer]]
^nl-Q0818

**nl-Q0819 · Edit the changed sentence**

Halt, 【en】 ik schiet.

Stop, or I'll shoot.

[[Dutch#^nl-Q0819-answer|Compare the answer]]
^nl-Q0819

**nl-Q0820 · Build the sentence**

Arrange: ik / of / schiet. / Halt,

Stop, or I'll shoot.

[[Dutch#^nl-Q0820-answer|Compare the answer]]
^nl-Q0820

**nl-Q0821 · Write a translation**

Write this in Dutch: They met the crown princes of Sweden and Denmark.

[[Dutch#^nl-Q0821-answer|Compare the answer]]
^nl-Q0821

**nl-Q0822 · Explain the grammar**

Ze ontmoetten de kroonprinsen van Zweden 【en】 Denemarken.

They met the crown princes of Sweden and Denmark.

[[Dutch#^nl-Q0822-answer|Compare the answer]]
^nl-Q0822

**nl-Q0823 · Fill the gap**

We zijn nooit even gelukkig ____ ongelukkig als we onszelf indenken.

We are never as happy or as unhappy as we imagine.

[[Dutch#^nl-Q0823-answer|Compare the answer]]
^nl-Q0823

**nl-Q0824 · Choose the form**

We zijn nooit even gelukkig ____ ongelukkig als we onszelf indenken.

We are never as happy or as unhappy as we imagine.

Choices: maar / want / of / en

[[Dutch#^nl-Q0824-answer|Compare the answer]]
^nl-Q0824

**nl-Q0825 · Edit the changed sentence**

【maar】 waarom is dat?

And why is that?

[[Dutch#^nl-Q0825-answer|Compare the answer]]
^nl-Q0825

**nl-Q0826 · Build the sentence**

Arrange: is / dat? / En / waarom

And why is that?

[[Dutch#^nl-Q0826-answer|Compare the answer]]
^nl-Q0826

**nl-Q0827 · Write a translation**

Write this in Dutch: The sun rises in the east and sets in the west.

[[Dutch#^nl-Q0827-answer|Compare the answer]]
^nl-Q0827

**nl-Q0828 · Explain the grammar**

De zon komt op in het oosten 【en】 gaat onder in het westen.

The sun rises in the east and sets in the west.

[[Dutch#^nl-Q0828-answer|Compare the answer]]
^nl-Q0828

**nl-Q0829 · Fill the gap**

De overwinning ____ de dood!

Victory, or death!

[[Dutch#^nl-Q0829-answer|Compare the answer]]
^nl-Q0829

**nl-Q0830 · Choose the form**

De overwinning ____ de dood!

Victory, or death!

Choices: maar / of / en / want

[[Dutch#^nl-Q0830-answer|Compare the answer]]
^nl-Q0830

**nl-Q0831 · Edit the changed sentence**

U ziet, 【en】 u observeert niet.

You see, but you do not observe.

[[Dutch#^nl-Q0831-answer|Compare the answer]]
^nl-Q0831

**nl-Q0832 · Build the sentence**

Arrange: niet. / maar / U / ziet, / observeert / u

You see, but you do not observe.

[[Dutch#^nl-Q0832-answer|Compare the answer]]
^nl-Q0832

**nl-Q0833 · Write a translation**

Write this in Dutch: We tried to fool Tom, but he obviously knew something was up.

[[Dutch#^nl-Q0833-answer|Compare the answer]]
^nl-Q0833

**nl-Q0834 · Explain the grammar**

We probeerden Tom te foppen, 【maar】 hij had natuurlijk onraad geroken.

We tried to fool Tom, but he obviously knew something was up.

[[Dutch#^nl-Q0834-answer|Compare the answer]]
^nl-Q0834

**nl-Q0835 · Fill the gap**

Mijn zus houdt van meloenen ____ ik ook.

My sister likes melons and so do I.

[[Dutch#^nl-Q0835-answer|Compare the answer]]
^nl-Q0835

**nl-Q0836 · Choose the form**

Mijn zus houdt van meloenen ____ ik ook.

My sister likes melons and so do I.

Choices: of / maar / want / en

[[Dutch#^nl-Q0836-answer|Compare the answer]]
^nl-Q0836

**nl-Q0837 · Edit the changed sentence**

Ze kunnen maandag 【en】 dinsdag komen, maar niet woensdag of donderdag.

They can come on Monday or Tuesday, but not on Wednesday or Thursday.

[[Dutch#^nl-Q0837-answer|Compare the answer]]
^nl-Q0837

**nl-Q0838 · Build the sentence**

Arrange: maandag / niet / woensdag / kunnen / dinsdag / komen, / Ze / maar / of / donderdag. / of

They can come on Monday or Tuesday, but not on Wednesday or Thursday.

[[Dutch#^nl-Q0838-answer|Compare the answer]]
^nl-Q0838

**nl-Q0839 · Write a translation**

Write this in Dutch: Do you know the difference between a microscope and a telescope?

[[Dutch#^nl-Q0839-answer|Compare the answer]]
^nl-Q0839

**nl-Q0840 · Explain the grammar**

Ken jij het verschil tussen een microscoop 【en】 een telescoop?

Do you know the difference between a microscope and a telescope?

[[Dutch#^nl-Q0840-answer|Compare the answer]]
^nl-Q0840

**nl-Q0841 · Fill the gap**

Als je iemand $20 uitleent ____ je ziet die persoon daarna nooit meer, dan was het dat waarschijnlijk waard.

If you lend someone $20 and never see that person again, it was probably worth it.

[[Dutch#^nl-Q0841-answer|Compare the answer]]
^nl-Q0841

**nl-Q0842 · Choose the form**

Als je iemand $20 uitleent ____ je ziet die persoon daarna nooit meer, dan was het dat waarschijnlijk waard.

If you lend someone $20 and never see that person again, it was probably worth it.

Choices: want / maar / of / en

[[Dutch#^nl-Q0842-answer|Compare the answer]]
^nl-Q0842

**nl-Q0843 · Edit the changed sentence**

Diegene die het weet, zwijgt 【maar】 diegene die spreekt is onwetend.

He who knows does not speak, he who speaks does not know.

[[Dutch#^nl-Q0843-answer|Compare the answer]]
^nl-Q0843

**nl-Q0844 · Build the sentence**

Arrange: spreekt / weet, / die / die / diegene / het / Diegene / is / zwijgt / onwetend. / en

He who knows does not speak, he who speaks does not know.

[[Dutch#^nl-Q0844-answer|Compare the answer]]
^nl-Q0844

**nl-Q0845 · Write a translation**

Write this in Dutch: She finds fault with everything and everyone.

[[Dutch#^nl-Q0845-answer|Compare the answer]]
^nl-Q0845

**nl-Q0846 · Explain the grammar**

Ze heeft op alles 【en】 iedereen iets aan te merken.

She finds fault with everything and everyone.

[[Dutch#^nl-Q0846-answer|Compare the answer]]
^nl-Q0846

**nl-Q0847 · Fill the gap**

Waterstof, koolstof, stikstof, fosfor, zuurstof, zwavel ____ seleen zijn niet-metalen.

Hydrogen, carbon, nitrogen, phosphorus, oxygen, sulfur and selenium are nonmetals.

[[Dutch#^nl-Q0847-answer|Compare the answer]]
^nl-Q0847

**nl-Q0848 · Choose the form**

Waterstof, koolstof, stikstof, fosfor, zuurstof, zwavel ____ seleen zijn niet-metalen.

Hydrogen, carbon, nitrogen, phosphorus, oxygen, sulfur and selenium are nonmetals.

Choices: want / maar / en / of

[[Dutch#^nl-Q0848-answer|Compare the answer]]
^nl-Q0848

**nl-Q0849 · Edit the changed sentence**

Hadden we 【en】 een tuin!

If only we had a garden!

[[Dutch#^nl-Q0849-answer|Compare the answer]]
^nl-Q0849

**nl-Q0850 · Build the sentence**

Arrange: we / tuin! / maar / een / Hadden

If only we had a garden!

[[Dutch#^nl-Q0850-answer|Compare the answer]]
^nl-Q0850


### Questions · 50 questions

**nl-Q0851 · Write a translation**

Write this in Dutch: Where's your son?

[[Dutch#^nl-Q0851-answer|Compare the answer]]
^nl-Q0851

**nl-Q0852 · Explain the grammar**

【Waar】 is jullie zoon?

Where's your son?

[[Dutch#^nl-Q0852-answer|Compare the answer]]
^nl-Q0852

**nl-Q0853 · Fill the gap**

____ is uw huiswerk?

Where is your homework?

[[Dutch#^nl-Q0853-answer|Compare the answer]]
^nl-Q0853

**nl-Q0854 · Choose the form**

____ is uw huiswerk?

Where is your homework?

Choices: Waar / waarom / hoe / wanneer

[[Dutch#^nl-Q0854-answer|Compare the answer]]
^nl-Q0854

**nl-Q0855 · Edit the changed sentence**

【wanneer】 ben je nu op dit moment?

Where are you right now?

[[Dutch#^nl-Q0855-answer|Compare the answer]]
^nl-Q0855

**nl-Q0856 · Build the sentence**

Arrange: ben / je / moment? / nu / dit / op / Waar

Where are you right now?

[[Dutch#^nl-Q0856-answer|Compare the answer]]
^nl-Q0856

**nl-Q0857 · Write a translation**

Write this in Dutch: Why do you hate Instagram?

[[Dutch#^nl-Q0857-answer|Compare the answer]]
^nl-Q0857

**nl-Q0858 · Explain the grammar**

【Waarom】 haten jullie Instagram?

Why do you hate Instagram?

[[Dutch#^nl-Q0858-answer|Compare the answer]]
^nl-Q0858

**nl-Q0859 · Fill the gap**

____ doen mensen zulke dwaze dingen?

Why do people do such stupid things?

[[Dutch#^nl-Q0859-answer|Compare the answer]]
^nl-Q0859

**nl-Q0860 · Choose the form**

____ doen mensen zulke dwaze dingen?

Why do people do such stupid things?

Choices: wanneer / waar / hoe / Waarom

[[Dutch#^nl-Q0860-answer|Compare the answer]]
^nl-Q0860

**nl-Q0861 · Edit the changed sentence**

【wanneer】 is de jongen?

Where is the boy?

[[Dutch#^nl-Q0861-answer|Compare the answer]]
^nl-Q0861

**nl-Q0862 · Build the sentence**

Arrange: jongen? / is / Waar / de

Where is the boy?

[[Dutch#^nl-Q0862-answer|Compare the answer]]
^nl-Q0862

**nl-Q0863 · Write a translation**

Write this in Dutch: When does it end?

[[Dutch#^nl-Q0863-answer|Compare the answer]]
^nl-Q0863

**nl-Q0864 · Explain the grammar**

【Wanneer】 eindigt het?

When does it end?

[[Dutch#^nl-Q0864-answer|Compare the answer]]
^nl-Q0864

**nl-Q0865 · Fill the gap**

____ bevalt dit hotel Tom niet?

Why doesn't Tom like this hotel?

[[Dutch#^nl-Q0865-answer|Compare the answer]]
^nl-Q0865

**nl-Q0866 · Choose the form**

____ bevalt dit hotel Tom niet?

Why doesn't Tom like this hotel?

Choices: wanneer / waar / Waarom / hoe

[[Dutch#^nl-Q0866-answer|Compare the answer]]
^nl-Q0866

**nl-Q0867 · Edit the changed sentence**

Niemand weet 【waar】 zo'n gebruik ontstaan is.

No one knows when such a custom came into existence.

[[Dutch#^nl-Q0867-answer|Compare the answer]]
^nl-Q0867

**nl-Q0868 · Build the sentence**

Arrange: is. / zo'n / Niemand / ontstaan / gebruik / weet / wanneer

No one knows when such a custom came into existence.

[[Dutch#^nl-Q0868-answer|Compare the answer]]
^nl-Q0868

**nl-Q0869 · Write a translation**

Write this in Dutch: Why did she ask this question?

[[Dutch#^nl-Q0869-answer|Compare the answer]]
^nl-Q0869

**nl-Q0870 · Explain the grammar**

【Waarom】 vroeg ze deze vraag?

Why did she ask this question?

[[Dutch#^nl-Q0870-answer|Compare the answer]]
^nl-Q0870

**nl-Q0871 · Fill the gap**

____ kom jij vandaan? - Ik kom uit Frankrijk.

Where are you from? – I am from France.

[[Dutch#^nl-Q0871-answer|Compare the answer]]
^nl-Q0871

**nl-Q0872 · Choose the form**

____ kom jij vandaan? - Ik kom uit Frankrijk.

Where are you from? – I am from France.

Choices: Waar / hoe / waarom / wanneer

[[Dutch#^nl-Q0872-answer|Compare the answer]]
^nl-Q0872

**nl-Q0873 · Edit the changed sentence**

【waar】 zijn we hier?

Why are we here?

[[Dutch#^nl-Q0873-answer|Compare the answer]]
^nl-Q0873

**nl-Q0874 · Build the sentence**

Arrange: Waarom / hier? / zijn / we

Why are we here?

[[Dutch#^nl-Q0874-answer|Compare the answer]]
^nl-Q0874

**nl-Q0875 · Write a translation**

Write this in Dutch: When do you play tennis?

[[Dutch#^nl-Q0875-answer|Compare the answer]]
^nl-Q0875

**nl-Q0876 · Explain the grammar**

【Wanneer】 speelt u tennis?

When do you play tennis?

[[Dutch#^nl-Q0876-answer|Compare the answer]]
^nl-Q0876

**nl-Q0877 · Fill the gap**

____ een paella!

What a paella!

[[Dutch#^nl-Q0877-answer|Compare the answer]]
^nl-Q0877

**nl-Q0878 · Choose the form**

____ een paella!

What a paella!

Choices: waarom / Wat / wanneer / waar

[[Dutch#^nl-Q0878-answer|Compare the answer]]
^nl-Q0878

**nl-Q0879 · Edit the changed sentence**

【waar】 zeg je ''kaisha'' in het Engels?

How do you say "kaisha" in English?

[[Dutch#^nl-Q0879-answer|Compare the answer]]
^nl-Q0879

**nl-Q0880 · Build the sentence**

Arrange: in / ''kaisha'' / Engels? / zeg / je / het / Hoe

How do you say "kaisha" in English?

[[Dutch#^nl-Q0880-answer|Compare the answer]]
^nl-Q0880

**nl-Q0881 · Write a translation**

Write this in Dutch: Where can I try this on?

[[Dutch#^nl-Q0881-answer|Compare the answer]]
^nl-Q0881

**nl-Q0882 · Explain the grammar**

【Waar】 kan ik dit aan proberen?

Where can I try this on?

[[Dutch#^nl-Q0882-answer|Compare the answer]]
^nl-Q0882

**nl-Q0883 · Fill the gap**

____ neem je mee naar het toneelstuk?

Who are you bringing to the play?

[[Dutch#^nl-Q0883-answer|Compare the answer]]
^nl-Q0883

**nl-Q0884 · Choose the form**

____ neem je mee naar het toneelstuk?

Who are you bringing to the play?

Choices: wanneer / Wie / waarom / waar

[[Dutch#^nl-Q0884-answer|Compare the answer]]
^nl-Q0884

**nl-Q0885 · Edit the changed sentence**

【waar】 ben je toch een eikel.

You're such a jerk.

[[Dutch#^nl-Q0885-answer|Compare the answer]]
^nl-Q0885

**nl-Q0886 · Build the sentence**

Arrange: een / ben / toch / Wat / eikel. / je

You're such a jerk.

[[Dutch#^nl-Q0886-answer|Compare the answer]]
^nl-Q0886

**nl-Q0887 · Write a translation**

Write this in Dutch: Why don't you give me what I want to have?

[[Dutch#^nl-Q0887-answer|Compare the answer]]
^nl-Q0887

**nl-Q0888 · Explain the grammar**

【Waarom】 geef je me niet wat ik hebben wil?

Why don't you give me what I want to have?

[[Dutch#^nl-Q0888-answer|Compare the answer]]
^nl-Q0888

**nl-Q0889 · Fill the gap**

Sami weet niet ____ hij moet bidden.

Sami doesn't know how to pray.

[[Dutch#^nl-Q0889-answer|Compare the answer]]
^nl-Q0889

**nl-Q0890 · Choose the form**

Sami weet niet ____ hij moet bidden.

Sami doesn't know how to pray.

Choices: waarom / hoe / waar / wanneer

[[Dutch#^nl-Q0890-answer|Compare the answer]]
^nl-Q0890

**nl-Q0891 · Edit the changed sentence**

Weet je 【waar】 voor soort bloem dit is?

Do you know what kind of flower this is?

[[Dutch#^nl-Q0891-answer|Compare the answer]]
^nl-Q0891

**nl-Q0892 · Build the sentence**

Arrange: Weet / je / voor / dit / wat / soort / bloem / is?

Do you know what kind of flower this is?

[[Dutch#^nl-Q0892-answer|Compare the answer]]
^nl-Q0892

**nl-Q0893 · Write a translation**

Write this in Dutch: Where can I obtain a map of Europe?

[[Dutch#^nl-Q0893-answer|Compare the answer]]
^nl-Q0893

**nl-Q0894 · Explain the grammar**

【Waar】 kan ik een kaart van Europa verkrijgen?

Where can I obtain a map of Europe?

[[Dutch#^nl-Q0894-answer|Compare the answer]]
^nl-Q0894

**nl-Q0895 · Fill the gap**

____ bent u?

Who are you?

[[Dutch#^nl-Q0895-answer|Compare the answer]]
^nl-Q0895

**nl-Q0896 · Choose the form**

____ bent u?

Who are you?

Choices: waar / Wie / wanneer / waarom

[[Dutch#^nl-Q0896-answer|Compare the answer]]
^nl-Q0896

**nl-Q0897 · Edit the changed sentence**

Laat me weten 【waar】 je weggaat.

Let me know when you’re going to leave.

[[Dutch#^nl-Q0897-answer|Compare the answer]]
^nl-Q0897

**nl-Q0898 · Build the sentence**

Arrange: weggaat. / Laat / weten / me / je / wanneer

Let me know when you’re going to leave.

[[Dutch#^nl-Q0898-answer|Compare the answer]]
^nl-Q0898

**nl-Q0899 · Write a translation**

Write this in Dutch: What color is Mary's scarf?

[[Dutch#^nl-Q0899-answer|Compare the answer]]
^nl-Q0899

**nl-Q0900 · Explain the grammar**

【Wat】 is de kleur van Maria's sjaal?

What color is Mary's scarf?

[[Dutch#^nl-Q0900-answer|Compare the answer]]
^nl-Q0900


### Comparison · 50 questions

**nl-Q0901 · Fill the gap**

In alle geval kunt ge ____ gehoorzamen aan uw ouders.

In any case you had better obey your parents.

[[Dutch#^nl-Q0901-answer|Compare the answer]]
^nl-Q0901

**nl-Q0902 · Choose the form**

In alle geval kunt ge ____ gehoorzamen aan uw ouders.

In any case you had better obey your parents.

Choices: minder / dan / meer / beter

[[Dutch#^nl-Q0902-answer|Compare the answer]]
^nl-Q0902

**nl-Q0903 · Edit the changed sentence**

Ze is twee jaar ouder 【meer】 jij.

She is two years older than you.

[[Dutch#^nl-Q0903-answer|Compare the answer]]
^nl-Q0903

**nl-Q0904 · Build the sentence**

Arrange: is / Ze / dan / jaar / twee / jij. / ouder

She is two years older than you.

[[Dutch#^nl-Q0904-answer|Compare the answer]]
^nl-Q0904

**nl-Q0905 · Write a translation**

Write this in Dutch: The school is farther than the station.

[[Dutch#^nl-Q0905-answer|Compare the answer]]
^nl-Q0905

**nl-Q0906 · Explain the grammar**

De school is verder 【dan】 het station.

The school is farther than the station.

[[Dutch#^nl-Q0906-answer|Compare the answer]]
^nl-Q0906

**nl-Q0907 · Fill the gap**

Vanop afstand lijkt de afbeelding ____.

The picture looks better at a distance.

[[Dutch#^nl-Q0907-answer|Compare the answer]]
^nl-Q0907

**nl-Q0908 · Choose the form**

Vanop afstand lijkt de afbeelding ____.

The picture looks better at a distance.

Choices: beter / minder / dan / meer

[[Dutch#^nl-Q0908-answer|Compare the answer]]
^nl-Q0908

**nl-Q0909 · Edit the changed sentence**

【meer】 ge op de wc-bril pist, wis het af!

If you piss on the toilet seat, wipe it off!

[[Dutch#^nl-Q0909-answer|Compare the answer]]
^nl-Q0909

**nl-Q0910 · Build the sentence**

Arrange: Als / wc-bril / pist, / het / de / ge / wis / af! / op

If you piss on the toilet seat, wipe it off!

[[Dutch#^nl-Q0910-answer|Compare the answer]]
^nl-Q0910

**nl-Q0911 · Write a translation**

Write this in Dutch: The police confiscated Dan's driving licence.

[[Dutch#^nl-Q0911-answer|Compare the answer]]
^nl-Q0911

**nl-Q0912 · Explain the grammar**

De politie nam 【Dan】 zijn rijbewijs in beslag.

The police confiscated Dan's driving licence.

[[Dutch#^nl-Q0912-answer|Compare the answer]]
^nl-Q0912

**nl-Q0913 · Fill the gap**

Zowel Tom ____ Mary hebben vandaag met mij daarover gepraat.

Both Tom and Mary talked to me today about that.

[[Dutch#^nl-Q0913-answer|Compare the answer]]
^nl-Q0913

**nl-Q0914 · Choose the form**

Zowel Tom ____ Mary hebben vandaag met mij daarover gepraat.

Both Tom and Mary talked to me today about that.

Choices: als / minder / meer / beter

[[Dutch#^nl-Q0914-answer|Compare the answer]]
^nl-Q0914

**nl-Q0915 · Edit the changed sentence**

De situatie is erger 【meer】 we dachten.

The situation is worse than we believed.

[[Dutch#^nl-Q0915-answer|Compare the answer]]
^nl-Q0915

**nl-Q0916 · Build the sentence**

Arrange: dachten. / we / situatie / erger / is / dan / De

The situation is worse than we believed.

[[Dutch#^nl-Q0916-answer|Compare the answer]]
^nl-Q0916

**nl-Q0917 · Write a translation**

Write this in Dutch: Every time it rains, the roof leaks.

[[Dutch#^nl-Q0917-answer|Compare the answer]]
^nl-Q0917

**nl-Q0918 · Explain the grammar**

Iedere keer 【als】 het regent, lekt het dak.

Every time it rains, the roof leaks.

[[Dutch#^nl-Q0918-answer|Compare the answer]]
^nl-Q0918

**nl-Q0919 · Fill the gap**

Analisten beschouwen hem ____ een van de beste passers in de competitie.

Pundits consider him one of the best passers in the league.

[[Dutch#^nl-Q0919-answer|Compare the answer]]
^nl-Q0919

**nl-Q0920 · Choose the form**

Analisten beschouwen hem ____ een van de beste passers in de competitie.

Pundits consider him one of the best passers in the league.

Choices: minder / als / beter / meer

[[Dutch#^nl-Q0920-answer|Compare the answer]]
^nl-Q0920

**nl-Q0921 · Edit the changed sentence**

Je hebt een betere smaak 【meer】 ik dacht.

You have better taste than I thought.

[[Dutch#^nl-Q0921-answer|Compare the answer]]
^nl-Q0921

**nl-Q0922 · Build the sentence**

Arrange: smaak / hebt / Je / een / dan / betere / ik / dacht.

You have better taste than I thought.

[[Dutch#^nl-Q0922-answer|Compare the answer]]
^nl-Q0922

**nl-Q0923 · Write a translation**

Write this in Dutch: When the alarm clock goes off, I don’t move.

[[Dutch#^nl-Q0923-answer|Compare the answer]]
^nl-Q0923

**nl-Q0924 · Explain the grammar**

【Als】 de wekker afgaat, beweeg ik niet.

When the alarm clock goes off, I don’t move.

[[Dutch#^nl-Q0924-answer|Compare the answer]]
^nl-Q0924

**nl-Q0925 · Fill the gap**

Zij zien ____.

They see Dan.

[[Dutch#^nl-Q0925-answer|Compare the answer]]
^nl-Q0925

**nl-Q0926 · Choose the form**

Zij zien ____.

They see Dan.

Choices: minder / beter / meer / Dan

[[Dutch#^nl-Q0926-answer|Compare the answer]]
^nl-Q0926

**nl-Q0927 · Edit the changed sentence**

Goud is veel zwaarder 【meer】 water.

Gold is far heavier than water.

[[Dutch#^nl-Q0927-answer|Compare the answer]]
^nl-Q0927

**nl-Q0928 · Build the sentence**

Arrange: zwaarder / veel / Goud / is / dan / water.

Gold is far heavier than water.

[[Dutch#^nl-Q0928-answer|Compare the answer]]
^nl-Q0928

**nl-Q0929 · Write a translation**

Write this in Dutch: I assure you that an error like this will never happen again.

[[Dutch#^nl-Q0929-answer|Compare the answer]]
^nl-Q0929

**nl-Q0930 · Explain the grammar**

Ik verzeker je dat een fout zoals deze nooit 【meer】 zal voorkomen.

I assure you that an error like this will never happen again.

[[Dutch#^nl-Q0930-answer|Compare the answer]]
^nl-Q0930

**nl-Q0931 · Fill the gap**

Ik zal die fout nooit ____ maken.

I will never make that mistake again.

[[Dutch#^nl-Q0931-answer|Compare the answer]]
^nl-Q0931

**nl-Q0932 · Choose the form**

Ik zal die fout nooit ____ maken.

I will never make that mistake again.

Choices: dan / beter / meer / minder

[[Dutch#^nl-Q0932-answer|Compare the answer]]
^nl-Q0932

**nl-Q0933 · Edit the changed sentence**

De pen heeft 【minder】 macht dan het zwaard.

The pen is mightier than the sword.

[[Dutch#^nl-Q0933-answer|Compare the answer]]
^nl-Q0933

**nl-Q0934 · Build the sentence**

Arrange: meer / het / De / heeft / pen / dan / zwaard. / macht

The pen is mightier than the sword.

[[Dutch#^nl-Q0934-answer|Compare the answer]]
^nl-Q0934

**nl-Q0935 · Write a translation**

Write this in Dutch: Something is better than nothing.

[[Dutch#^nl-Q0935-answer|Compare the answer]]
^nl-Q0935

**nl-Q0936 · Explain the grammar**

Iets is 【beter】 dan niets.

Something is better than nothing.

[[Dutch#^nl-Q0936-answer|Compare the answer]]
^nl-Q0936

**nl-Q0937 · Fill the gap**

De politie beschouwt zijn dood ____ een moordgeval.

The police are treating his death as a case of murder.

[[Dutch#^nl-Q0937-answer|Compare the answer]]
^nl-Q0937

**nl-Q0938 · Choose the form**

De politie beschouwt zijn dood ____ een moordgeval.

The police are treating his death as a case of murder.

Choices: minder / als / beter / meer

[[Dutch#^nl-Q0938-answer|Compare the answer]]
^nl-Q0938

**nl-Q0939 · Edit the changed sentence**

Ik kom altijd eerder uit bed 【meer】 de rest van mijn gezin.

I always get up earlier than the rest of my family.

[[Dutch#^nl-Q0939-answer|Compare the answer]]
^nl-Q0939

**nl-Q0940 · Build the sentence**

Arrange: altijd / mijn / Ik / kom / eerder / dan / bed / uit / gezin. / van / rest / de

I always get up earlier than the rest of my family.

[[Dutch#^nl-Q0940-answer|Compare the answer]]
^nl-Q0940

**nl-Q0941 · Write a translation**

Write this in Dutch: She is about my age.

[[Dutch#^nl-Q0941-answer|Compare the answer]]
^nl-Q0941

**nl-Q0942 · Explain the grammar**

Ze is ongeveer even oud 【als】 ik.

She is about my age.

[[Dutch#^nl-Q0942-answer|Compare the answer]]
^nl-Q0942

**nl-Q0943 · Fill the gap**

Laat me alsjeblieft weten wanneer je dit niet ____ kunt horen.

Please tell me when you cannot hear this anymore.

[[Dutch#^nl-Q0943-answer|Compare the answer]]
^nl-Q0943

**nl-Q0944 · Choose the form**

Laat me alsjeblieft weten wanneer je dit niet ____ kunt horen.

Please tell me when you cannot hear this anymore.

Choices: dan / minder / beter / meer

[[Dutch#^nl-Q0944-answer|Compare the answer]]
^nl-Q0944

**nl-Q0945 · Edit the changed sentence**

Ze behandelden me 【meer】 een kind.

I was treated like a child by them.

[[Dutch#^nl-Q0945-answer|Compare the answer]]
^nl-Q0945

**nl-Q0946 · Build the sentence**

Arrange: een / Ze / als / me / kind. / behandelden

I was treated like a child by them.

[[Dutch#^nl-Q0946-answer|Compare the answer]]
^nl-Q0946

**nl-Q0947 · Write a translation**

Write this in Dutch: I don't love her anymore.

[[Dutch#^nl-Q0947-answer|Compare the answer]]
^nl-Q0947

**nl-Q0948 · Explain the grammar**

Ik hou niet 【meer】 van haar.

I don't love her anymore.

[[Dutch#^nl-Q0948-answer|Compare the answer]]
^nl-Q0948

**nl-Q0949 · Fill the gap**

Het loont zich niet dat oude gebouw te renoveren. Het is ____ het af te breken.

This old building isn't worth fixing up. It would be better to tear it down.

[[Dutch#^nl-Q0949-answer|Compare the answer]]
^nl-Q0949

**nl-Q0950 · Choose the form**

Het loont zich niet dat oude gebouw te renoveren. Het is ____ het af te breken.

This old building isn't worth fixing up. It would be better to tear it down.

Choices: minder / meer / dan / beter

[[Dutch#^nl-Q0950-answer|Compare the answer]]
^nl-Q0950


### Cause and concession · 50 questions

**nl-Q0951 · Edit the changed sentence**

【hoewel】 hou ik van je.

That's why I like you.

[[Dutch#^nl-Q0951-answer|Compare the answer]]
^nl-Q0951

**nl-Q0952 · Build the sentence**

Arrange: Daarom / je. / hou / ik / van

That's why I like you.

[[Dutch#^nl-Q0952-answer|Compare the answer]]
^nl-Q0952

**nl-Q0953 · Write a translation**

Write this in Dutch: It looks like the world didn't end on December 21st after all.

[[Dutch#^nl-Q0953-answer|Compare the answer]]
^nl-Q0953

**nl-Q0954 · Explain the grammar**

Het ziet ernaar uit dat de wereld 【toch】 niet is vergaan op 21 december.

It looks like the world didn't end on December 21st after all.

[[Dutch#^nl-Q0954-answer|Compare the answer]]
^nl-Q0954

**nl-Q0955 · Fill the gap**

Ik ben gay, ____?

I'm gay, so?

[[Dutch#^nl-Q0955-answer|Compare the answer]]
^nl-Q0955

**nl-Q0956 · Choose the form**

Ik ben gay, ____?

I'm gay, so?

Choices: toch / hoewel / dus / daarom

[[Dutch#^nl-Q0956-answer|Compare the answer]]
^nl-Q0956

**nl-Q0957 · Edit the changed sentence**

【hoewel】 zijn we hier.

That's why we're here.

[[Dutch#^nl-Q0957-answer|Compare the answer]]
^nl-Q0957

**nl-Q0958 · Build the sentence**

Arrange: zijn / we / Daarom / hier.

That's why we're here.

[[Dutch#^nl-Q0958-answer|Compare the answer]]
^nl-Q0958

**nl-Q0959 · Write a translation**

Write this in Dutch: Just where were you?

[[Dutch#^nl-Q0959-answer|Compare the answer]]
^nl-Q0959

**nl-Q0960 · Explain the grammar**

Waar was je 【toch】?

Just where were you?

[[Dutch#^nl-Q0960-answer|Compare the answer]]
^nl-Q0960

**nl-Q0961 · Fill the gap**

Fadil begon te vasten ____ hij geen moslim was.

Fadil started fasting although he wasn't a Muslim.

[[Dutch#^nl-Q0961-answer|Compare the answer]]
^nl-Q0961

**nl-Q0962 · Choose the form**

Fadil begon te vasten ____ hij geen moslim was.

Fadil started fasting although he wasn't a Muslim.

Choices: hoewel / toch / daarom / dus

[[Dutch#^nl-Q0962-answer|Compare the answer]]
^nl-Q0962

**nl-Q0963 · Edit the changed sentence**

【hoewel】 sindsdien moesten fabrikanten met echt geld betalen.

So from then on, manufacturers had to pay real cash.

[[Dutch#^nl-Q0963-answer|Compare the answer]]
^nl-Q0963

**nl-Q0964 · Build the sentence**

Arrange: betalen. / echt / met / moesten / sindsdien / fabrikanten / geld / Dus

So from then on, manufacturers had to pay real cash.

[[Dutch#^nl-Q0964-answer|Compare the answer]]
^nl-Q0964

**nl-Q0965 · Write a translation**

Write this in Dutch: I thought I told you to throw that away.

[[Dutch#^nl-Q0965-answer|Compare the answer]]
^nl-Q0965

**nl-Q0966 · Explain the grammar**

Ik heb het je 【toch】 gezegd dat je dat moest weggooien.

I thought I told you to throw that away.

[[Dutch#^nl-Q0966-answer|Compare the answer]]
^nl-Q0966

**nl-Q0967 · Fill the gap**

____ was het best een mooi jaar.

It was a pretty good year, nonetheless.

[[Dutch#^nl-Q0967-answer|Compare the answer]]
^nl-Q0967

**nl-Q0968 · Choose the form**

____ was het best een mooi jaar.

It was a pretty good year, nonetheless.

Choices: dus / Toch / hoewel / daarom

[[Dutch#^nl-Q0968-answer|Compare the answer]]
^nl-Q0968

**nl-Q0969 · Edit the changed sentence**

Hij draaide de fles ondersteboven en schudde hem, maar 【hoewel】 kwam de honing er niet uit.

He turned the bottle upside down and shook it, but still the honey wouldn't come out.

[[Dutch#^nl-Q0969-answer|Compare the answer]]
^nl-Q0969

**nl-Q0970 · Build the sentence**

Arrange: honing / maar / uit. / fles / de / toch / schudde / kwam / er / hem, / Hij / draaide / de / niet / ondersteboven / en

He turned the bottle upside down and shook it, but still the honey wouldn't come out.

[[Dutch#^nl-Q0970-answer|Compare the answer]]
^nl-Q0970

**nl-Q0971 · Write a translation**

Write this in Dutch: They did not know it was impossible, so they did it.

[[Dutch#^nl-Q0971-answer|Compare the answer]]
^nl-Q0971

**nl-Q0972 · Explain the grammar**

Ze wisten niet dat het onmogelijk was, 【dus】 ze deden het.

They did not know it was impossible, so they did it.

[[Dutch#^nl-Q0972-answer|Compare the answer]]
^nl-Q0972

**nl-Q0973 · Fill the gap**

Jij kan niet zwemmen, of ____?

You can't swim, can you?

[[Dutch#^nl-Q0973-answer|Compare the answer]]
^nl-Q0973

**nl-Q0974 · Choose the form**

Jij kan niet zwemmen, of ____?

You can't swim, can you?

Choices: daarom / dus / toch / hoewel

[[Dutch#^nl-Q0974-answer|Compare the answer]]
^nl-Q0974

**nl-Q0975 · Edit the changed sentence**

Tom trok 【hoewel】 meer dan één foto?

Tom took more than one picture, didn't he?

[[Dutch#^nl-Q0975-answer|Compare the answer]]
^nl-Q0975

**nl-Q0976 · Build the sentence**

Arrange: Tom / meer / trok / één / dan / toch / foto?

Tom took more than one picture, didn't he?

[[Dutch#^nl-Q0976-answer|Compare the answer]]
^nl-Q0976

**nl-Q0977 · Write a translation**

Write this in Dutch: Stop being such a pest!

[[Dutch#^nl-Q0977-answer|Compare the answer]]
^nl-Q0977

**nl-Q0978 · Explain the grammar**

Doe 【toch】 niet zo lastig!

Stop being such a pest!

[[Dutch#^nl-Q0978-answer|Compare the answer]]
^nl-Q0978

**nl-Q0979 · Fill the gap**

Doe wat ge wilt, gekletst wordt er ____.

Do whatever you want, there will be gossiping anyhow.

[[Dutch#^nl-Q0979-answer|Compare the answer]]
^nl-Q0979

**nl-Q0980 · Choose the form**

Doe wat ge wilt, gekletst wordt er ____.

Do whatever you want, there will be gossiping anyhow.

Choices: toch / dus / daarom / hoewel

[[Dutch#^nl-Q0980-answer|Compare the answer]]
^nl-Q0980

**nl-Q0981 · Edit the changed sentence**

Maria is een gepensioneerde tandarts, 【hoewel】?

Mary is a retired dentist, isn't she?

[[Dutch#^nl-Q0981-answer|Compare the answer]]
^nl-Q0981

**nl-Q0982 · Build the sentence**

Arrange: tandarts, / gepensioneerde / is / een / toch? / Maria

Mary is a retired dentist, isn't she?

[[Dutch#^nl-Q0982-answer|Compare the answer]]
^nl-Q0982

**nl-Q0983 · Write a translation**

Write this in Dutch: I love you anyway!

[[Dutch#^nl-Q0983-answer|Compare the answer]]
^nl-Q0983

**nl-Q0984 · Explain the grammar**

Ik hou 【toch】 van je!

I love you anyway!

[[Dutch#^nl-Q0984-answer|Compare the answer]]
^nl-Q0984

**nl-Q0985 · Fill the gap**

Dat mag ____ niet?

That's not allowed, right?

[[Dutch#^nl-Q0985-answer|Compare the answer]]
^nl-Q0985

**nl-Q0986 · Choose the form**

Dat mag ____ niet?

That's not allowed, right?

Choices: dus / daarom / hoewel / toch

[[Dutch#^nl-Q0986-answer|Compare the answer]]
^nl-Q0986

**nl-Q0987 · Edit the changed sentence**

Terwijl ik nu 【hoewel】 hier ben, denk je dat je de batterijen kunt vervangen?

But while I am here, do you think you could replace the batteries?

[[Dutch#^nl-Q0987-answer|Compare the answer]]
^nl-Q0987

**nl-Q0988 · Build the sentence**

Arrange: vervangen? / denk / kunt / de / batterijen / nu / dat / ik / ben, / je / hier / je / Terwijl / toch

But while I am here, do you think you could replace the batteries?

[[Dutch#^nl-Q0988-answer|Compare the answer]]
^nl-Q0988

**nl-Q0989 · Write a translation**

Write this in Dutch: Just imagine: he is a doctor, and yet he is a smoker.

[[Dutch#^nl-Q0989-answer|Compare the answer]]
^nl-Q0989

**nl-Q0990 · Explain the grammar**

Stel je even voor: hij is arts en 【toch】 rookt hij.

Just imagine: he is a doctor, and yet he is a smoker.

[[Dutch#^nl-Q0990-answer|Compare the answer]]
^nl-Q0990

**nl-Q0991 · Fill the gap**

____ heb ik het druk.

That's why I'm busy.

[[Dutch#^nl-Q0991-answer|Compare the answer]]
^nl-Q0991

**nl-Q0992 · Choose the form**

____ heb ik het druk.

That's why I'm busy.

Choices: dus / toch / Daarom / hoewel

[[Dutch#^nl-Q0992-answer|Compare the answer]]
^nl-Q0992

**nl-Q0993 · Edit the changed sentence**

Ik zei je 【hoewel】 dat het niet zou lukken.

I told you it wouldn't work.

[[Dutch#^nl-Q0993-answer|Compare the answer]]
^nl-Q0993

**nl-Q0994 · Build the sentence**

Arrange: toch / dat / Ik / je / zei / lukken. / zou / het / niet

I told you it wouldn't work.

[[Dutch#^nl-Q0994-answer|Compare the answer]]
^nl-Q0994

**nl-Q0995 · Write a translation**

Write this in Dutch: I knew I couldn't do it, but I tried anyway.

[[Dutch#^nl-Q0995-answer|Compare the answer]]
^nl-Q0995

**nl-Q0996 · Explain the grammar**

Ik wist dat ik het niet kon doen, maar ik heb het 【toch】 geprobeerd.

I knew I couldn't do it, but I tried anyway.

[[Dutch#^nl-Q0996-answer|Compare the answer]]
^nl-Q0996

**nl-Q0997 · Fill the gap**

Wist je dat Julia tien jaar in Moskou gewoond heeft? ____ spreekt ze zo goed Russisch.

Did you know that Julia lived 10 years in Moscow? That's why she speaks Russian so well.

[[Dutch#^nl-Q0997-answer|Compare the answer]]
^nl-Q0997

**nl-Q0998 · Choose the form**

Wist je dat Julia tien jaar in Moskou gewoond heeft? ____ spreekt ze zo goed Russisch.

Did you know that Julia lived 10 years in Moscow? That's why she speaks Russian so well.

Choices: toch / Daarom / hoewel / dus

[[Dutch#^nl-Q0998-answer|Compare the answer]]
^nl-Q0998

**nl-Q0999 · Edit the changed sentence**

Ik heb zojuist mijn paspoort verlengd, 【hoewel】 ik kan er weer tien jaar mee verder.

I've just renewed my passport, so it's good for another ten years.

[[Dutch#^nl-Q0999-answer|Compare the answer]]
^nl-Q0999

**nl-Q1000 · Build the sentence**

Arrange: dus / zojuist / Ik / weer / mee / er / paspoort / jaar / ik / mijn / kan / tien / heb / verlengd, / verder.

I've just renewed my passport, so it's good for another ten years.

[[Dutch#^nl-Q1000-answer|Compare the answer]]
^nl-Q1000


## Answers

The full sentence is a model. For translation, judge whether meaning and grammar are preserved. Each grammar rule above explains the form.

### Answers 1–50

**nl-Q0001** — Mexico-Stad is de hoofdstad van Mexico.

Mexico City is the capital of Mexico.

Expected form: **de**

Why: De and het. [[Dutch#^nl-Q0001|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Mexico-Stad%20is%20de%20hoofdstad%20van%20Mexico.)
^nl-Q0001-answer

**nl-Q0002** — Mexico-Stad is de hoofdstad van Mexico.

Mexico City is the capital of Mexico.

Expected form: **de**

Why: De and het. [[Dutch#^nl-Q0002|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Mexico-Stad%20is%20de%20hoofdstad%20van%20Mexico.)
^nl-Q0002-answer

**nl-Q0003** — Een vrouwenhater moet je echt zo hard vertrouwen als het weer.

We must trust misogynists as much as we can trust the weather.

Expected form: **Een**

Why: De and het. [[Dutch#^nl-Q0003|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Een%20vrouwenhater%20moet%20je%20echt%20zo%20hard%20vertrouwen%20als%20het%20weer.)
^nl-Q0003-answer

**nl-Q0004** — Een vrouwenhater moet je echt zo hard vertrouwen als het weer.

We must trust misogynists as much as we can trust the weather.

Why: De and het. [[Dutch#^nl-Q0004|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Een%20vrouwenhater%20moet%20je%20echt%20zo%20hard%20vertrouwen%20als%20het%20weer.)
^nl-Q0004-answer

**nl-Q0005** — Ik ben in de keuken.

I'm in the kitchen.

Why: De and het. [[Dutch#^nl-Q0005|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20ben%20in%20de%20keuken.)
^nl-Q0005-answer

**nl-Q0006** — Ik ben in de keuken.

I'm in the kitchen.

Dutch distinguishes common-gender de nouns and neuter het nouns; plurals use de. Een introduces an indefinite singular noun. Diminutives take het regardless of the base noun’s gender.

Why: De and het. [[Dutch#^nl-Q0006|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20ben%20in%20de%20keuken.)
^nl-Q0006-answer

**nl-Q0007** — Wat een geluk!

How lucky!

Expected form: **een**

Why: De and het. [[Dutch#^nl-Q0007|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Wat%20een%20geluk%21)
^nl-Q0007-answer

**nl-Q0008** — Wat een geluk!

How lucky!

Expected form: **een**

Why: De and het. [[Dutch#^nl-Q0008|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Wat%20een%20geluk%21)
^nl-Q0008-answer

**nl-Q0009** — Jullie voorstel is een beetje extreem.

Your proposal is a bit extreme.

Expected form: **een**

Why: De and het. [[Dutch#^nl-Q0009|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Jullie%20voorstel%20is%20een%20beetje%20extreem.)
^nl-Q0009-answer

**nl-Q0010** — Jullie voorstel is een beetje extreem.

Your proposal is a bit extreme.

Why: De and het. [[Dutch#^nl-Q0010|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Jullie%20voorstel%20is%20een%20beetje%20extreem.)
^nl-Q0010-answer

**nl-Q0011** — Dit is een sinaasappelboom.

This is an orange tree.

Why: De and het. [[Dutch#^nl-Q0011|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Dit%20is%20een%20sinaasappelboom.)
^nl-Q0011-answer

**nl-Q0012** — Dit is een sinaasappelboom.

This is an orange tree.

Dutch distinguishes common-gender de nouns and neuter het nouns; plurals use de. Een introduces an indefinite singular noun. Diminutives take het regardless of the base noun’s gender.

Why: De and het. [[Dutch#^nl-Q0012|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Dit%20is%20een%20sinaasappelboom.)
^nl-Q0012-answer

**nl-Q0013** — Hoeveel gaat het kosten?

How much will it cost?

Expected form: **het**

Why: De and het. [[Dutch#^nl-Q0013|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Hoeveel%20gaat%20het%20kosten%3F)
^nl-Q0013-answer

**nl-Q0014** — Hoeveel gaat het kosten?

How much will it cost?

Expected form: **het**

Why: De and het. [[Dutch#^nl-Q0014|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Hoeveel%20gaat%20het%20kosten%3F)
^nl-Q0014-answer

**nl-Q0015** — Heb je een kaartje?

Do you have a ticket?

Expected form: **een**

Why: De and het. [[Dutch#^nl-Q0015|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Heb%20je%20een%20kaartje%3F)
^nl-Q0015-answer

**nl-Q0016** — Heb je een kaartje?

Do you have a ticket?

Why: De and het. [[Dutch#^nl-Q0016|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Heb%20je%20een%20kaartje%3F)
^nl-Q0016-answer

**nl-Q0017** — De prinses moet sterven.

The princess must die.

Why: De and het. [[Dutch#^nl-Q0017|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=De%20prinses%20moet%20sterven.)
^nl-Q0017-answer

**nl-Q0018** — De prinses moet sterven.

The princess must die.

Dutch distinguishes common-gender de nouns and neuter het nouns; plurals use de. Een introduces an indefinite singular noun. Diminutives take het regardless of the base noun’s gender.

Why: De and het. [[Dutch#^nl-Q0018|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=De%20prinses%20moet%20sterven.)
^nl-Q0018-answer

**nl-Q0019** — Hij hervatte zijn werk na een korte pauze.

He continued his work after a short break.

Expected form: **een**

Why: De and het. [[Dutch#^nl-Q0019|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Hij%20hervatte%20zijn%20werk%20na%20een%20korte%20pauze.)
^nl-Q0019-answer

**nl-Q0020** — Hij hervatte zijn werk na een korte pauze.

He continued his work after a short break.

Expected form: **een**

Why: De and het. [[Dutch#^nl-Q0020|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Hij%20hervatte%20zijn%20werk%20na%20een%20korte%20pauze.)
^nl-Q0020-answer

**nl-Q0021** — Het is niet duidelijk of ze zal instemmen.

It isn't clear whether she would agree.

Expected form: **Het**

Why: De and het. [[Dutch#^nl-Q0021|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Het%20is%20niet%20duidelijk%20of%20ze%20zal%20instemmen.)
^nl-Q0021-answer

**nl-Q0022** — Het is niet duidelijk of ze zal instemmen.

It isn't clear whether she would agree.

Why: De and het. [[Dutch#^nl-Q0022|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Het%20is%20niet%20duidelijk%20of%20ze%20zal%20instemmen.)
^nl-Q0022-answer

**nl-Q0023** — Het ongeval gebeurde twee uur geleden.

The accident happened two hours ago.

Why: De and het. [[Dutch#^nl-Q0023|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Het%20ongeval%20gebeurde%20twee%20uur%20geleden.)
^nl-Q0023-answer

**nl-Q0024** — Het ongeval gebeurde twee uur geleden.

The accident happened two hours ago.

Dutch distinguishes common-gender de nouns and neuter het nouns; plurals use de. Een introduces an indefinite singular noun. Diminutives take het regardless of the base noun’s gender.

Why: De and het. [[Dutch#^nl-Q0024|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Het%20ongeval%20gebeurde%20twee%20uur%20geleden.)
^nl-Q0024-answer

**nl-Q0025** — Ik studeer het al vijf jaar.

I have been studying it for five years.

Expected form: **het**

Why: De and het. [[Dutch#^nl-Q0025|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20studeer%20het%20al%20vijf%20jaar.)
^nl-Q0025-answer

**nl-Q0026** — Ik studeer het al vijf jaar.

I have been studying it for five years.

Expected form: **het**

Why: De and het. [[Dutch#^nl-Q0026|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20studeer%20het%20al%20vijf%20jaar.)
^nl-Q0026-answer

**nl-Q0027** — Niet één van mijn klasgenoten woont hier in de buurt.

None of my classmates live near here.

Expected form: **de**

Why: De and het. [[Dutch#^nl-Q0027|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Niet%20%C3%A9%C3%A9n%20van%20mijn%20klasgenoten%20woont%20hier%20in%20de%20buurt.)
^nl-Q0027-answer

**nl-Q0028** — Niet één van mijn klasgenoten woont hier in de buurt.

None of my classmates live near here.

Why: De and het. [[Dutch#^nl-Q0028|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Niet%20%C3%A9%C3%A9n%20van%20mijn%20klasgenoten%20woont%20hier%20in%20de%20buurt.)
^nl-Q0028-answer

**nl-Q0029** — Hebt u een zaklamp nodig?

Do you need a torch?

Why: De and het. [[Dutch#^nl-Q0029|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Hebt%20u%20een%20zaklamp%20nodig%3F)
^nl-Q0029-answer

**nl-Q0030** — Hebt u een zaklamp nodig?

Do you need a torch?

Dutch distinguishes common-gender de nouns and neuter het nouns; plurals use de. Een introduces an indefinite singular noun. Diminutives take het regardless of the base noun’s gender.

Why: De and het. [[Dutch#^nl-Q0030|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Hebt%20u%20een%20zaklamp%20nodig%3F)
^nl-Q0030-answer

**nl-Q0031** — De bloem is geel.

The flower is yellow.

Expected form: **De**

Why: De and het. [[Dutch#^nl-Q0031|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=De%20bloem%20is%20geel.)
^nl-Q0031-answer

**nl-Q0032** — De bloem is geel.

The flower is yellow.

Expected form: **De**

Why: De and het. [[Dutch#^nl-Q0032|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=De%20bloem%20is%20geel.)
^nl-Q0032-answer

**nl-Q0033** — Het is erg warm vandaag.

It is very hot today.

Expected form: **Het**

Why: De and het. [[Dutch#^nl-Q0033|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Het%20is%20erg%20warm%20vandaag.)
^nl-Q0033-answer

**nl-Q0034** — Het is erg warm vandaag.

It is very hot today.

Why: De and het. [[Dutch#^nl-Q0034|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Het%20is%20erg%20warm%20vandaag.)
^nl-Q0034-answer

**nl-Q0035** — Doe je het werk graag?

Do you enjoy the work?

Why: De and het. [[Dutch#^nl-Q0035|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Doe%20je%20het%20werk%20graag%3F)
^nl-Q0035-answer

**nl-Q0036** — Doe je het werk graag?

Do you enjoy the work?

Dutch distinguishes common-gender de nouns and neuter het nouns; plurals use de. Een introduces an indefinite singular noun. Diminutives take het regardless of the base noun’s gender.

Why: De and het. [[Dutch#^nl-Q0036|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Doe%20je%20het%20werk%20graag%3F)
^nl-Q0036-answer

**nl-Q0037** — Tom was niet in staat om een job te houden of om op zichzelf te leven.

Tom was unable to hold a job or live by himself.

Expected form: **een**

Why: De and het. [[Dutch#^nl-Q0037|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Tom%20was%20niet%20in%20staat%20om%20een%20job%20te%20houden%20of%20om%20op%20zichzelf%20te%20leven.)
^nl-Q0037-answer

**nl-Q0038** — Tom was niet in staat om een job te houden of om op zichzelf te leven.

Tom was unable to hold a job or live by himself.

Expected form: **een**

Why: De and het. [[Dutch#^nl-Q0038|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Tom%20was%20niet%20in%20staat%20om%20een%20job%20te%20houden%20of%20om%20op%20zichzelf%20te%20leven.)
^nl-Q0038-answer

**nl-Q0039** — Het hele land was bedolven onder sneeuw.

The whole country was buried under snow.

Expected form: **Het**

Why: De and het. [[Dutch#^nl-Q0039|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Het%20hele%20land%20was%20bedolven%20onder%20sneeuw.)
^nl-Q0039-answer

**nl-Q0040** — Het hele land was bedolven onder sneeuw.

The whole country was buried under snow.

Why: De and het. [[Dutch#^nl-Q0040|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Het%20hele%20land%20was%20bedolven%20onder%20sneeuw.)
^nl-Q0040-answer

**nl-Q0041** — Paolo is een vriendelijk persoon.

Paolo is a nice person.

Why: De and het. [[Dutch#^nl-Q0041|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Paolo%20is%20een%20vriendelijk%20persoon.)
^nl-Q0041-answer

**nl-Q0042** — Paolo is een vriendelijk persoon.

Paolo is a nice person.

Dutch distinguishes common-gender de nouns and neuter het nouns; plurals use de. Een introduces an indefinite singular noun. Diminutives take het regardless of the base noun’s gender.

Why: De and het. [[Dutch#^nl-Q0042|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Paolo%20is%20een%20vriendelijk%20persoon.)
^nl-Q0042-answer

**nl-Q0043** — Laat het me weten als iemand iets heeft gezien.

If anyone saw anything, I want to know.

Expected form: **het**

Why: De and het. [[Dutch#^nl-Q0043|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Laat%20het%20me%20weten%20als%20iemand%20iets%20heeft%20gezien.)
^nl-Q0043-answer

**nl-Q0044** — Laat het me weten als iemand iets heeft gezien.

If anyone saw anything, I want to know.

Expected form: **het**

Why: De and het. [[Dutch#^nl-Q0044|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Laat%20het%20me%20weten%20als%20iemand%20iets%20heeft%20gezien.)
^nl-Q0044-answer

**nl-Q0045** — Waar is de Hongaarse ambassade?

Where is the Hungarian embassy?

Expected form: **de**

Why: De and het. [[Dutch#^nl-Q0045|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Waar%20is%20de%20Hongaarse%20ambassade%3F)
^nl-Q0045-answer

**nl-Q0046** — Waar is de Hongaarse ambassade?

Where is the Hungarian embassy?

Why: De and het. [[Dutch#^nl-Q0046|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Waar%20is%20de%20Hongaarse%20ambassade%3F)
^nl-Q0046-answer

**nl-Q0047** — Ze begeleidde mij op de piano.

She accompanied me on the piano.

Why: De and het. [[Dutch#^nl-Q0047|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ze%20begeleidde%20mij%20op%20de%20piano.)
^nl-Q0047-answer

**nl-Q0048** — Ze begeleidde mij op de piano.

She accompanied me on the piano.

Dutch distinguishes common-gender de nouns and neuter het nouns; plurals use de. Een introduces an indefinite singular noun. Diminutives take het regardless of the base noun’s gender.

Why: De and het. [[Dutch#^nl-Q0048|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ze%20begeleidde%20mij%20op%20de%20piano.)
^nl-Q0048-answer

**nl-Q0049** — Er is niks mis met het idee.

There is nothing wrong with the idea.

Expected form: **het**

Why: De and het. [[Dutch#^nl-Q0049|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Er%20is%20niks%20mis%20met%20het%20idee.)
^nl-Q0049-answer

**nl-Q0050** — Er is niks mis met het idee.

There is nothing wrong with the idea.

Expected form: **het**

Why: De and het. [[Dutch#^nl-Q0050|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Er%20is%20niks%20mis%20met%20het%20idee.)
^nl-Q0050-answer


### Answers 51–100

**nl-Q0051** — Dit boek was gemakkelijk.

This book was easy.

Expected form: **Dit**

Why: Demonstratives. [[Dutch#^nl-Q0051|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Dit%20boek%20was%20gemakkelijk.)
^nl-Q0051-answer

**nl-Q0052** — Dit boek was gemakkelijk.

This book was easy.

Why: Demonstratives. [[Dutch#^nl-Q0052|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Dit%20boek%20was%20gemakkelijk.)
^nl-Q0052-answer

**nl-Q0053** — Ik heb geen idee hoe ze dat voor elkaar gekregen hebben.

I don't know how they did it.

Why: Demonstratives. [[Dutch#^nl-Q0053|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20heb%20geen%20idee%20hoe%20ze%20dat%20voor%20elkaar%20gekregen%20hebben.)
^nl-Q0053-answer

**nl-Q0054** — Ik heb geen idee hoe ze dat voor elkaar gekregen hebben.

I don't know how they did it.

Dit/dat commonly pair with singular het nouns; deze/die with de nouns and plurals. Distance and discourse determine the near/far distinction.

Why: Demonstratives. [[Dutch#^nl-Q0054|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20heb%20geen%20idee%20hoe%20ze%20dat%20voor%20elkaar%20gekregen%20hebben.)
^nl-Q0054-answer

**nl-Q0055** — Wie heeft je dit aangedaan?

Who did this to you?

Expected form: **dit**

Why: Demonstratives. [[Dutch#^nl-Q0055|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Wie%20heeft%20je%20dit%20aangedaan%3F)
^nl-Q0055-answer

**nl-Q0056** — Wie heeft je dit aangedaan?

Who did this to you?

Expected form: **dit**

Why: Demonstratives. [[Dutch#^nl-Q0056|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Wie%20heeft%20je%20dit%20aangedaan%3F)
^nl-Q0056-answer

**nl-Q0057** — Waarom weet jij dat?

Why do you know that?

Expected form: **dat**

Why: Demonstratives. [[Dutch#^nl-Q0057|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Waarom%20weet%20jij%20dat%3F)
^nl-Q0057-answer

**nl-Q0058** — Waarom weet jij dat?

Why do you know that?

Why: Demonstratives. [[Dutch#^nl-Q0058|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Waarom%20weet%20jij%20dat%3F)
^nl-Q0058-answer

**nl-Q0059** — Wat moet dat voorstellen?

What the hell is that?

Why: Demonstratives. [[Dutch#^nl-Q0059|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Wat%20moet%20dat%20voorstellen%3F)
^nl-Q0059-answer

**nl-Q0060** — Wat moet dat voorstellen?

What the hell is that?

Dit/dat commonly pair with singular het nouns; deze/die with de nouns and plurals. Distance and discourse determine the near/far distinction.

Why: Demonstratives. [[Dutch#^nl-Q0060|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Wat%20moet%20dat%20voorstellen%3F)
^nl-Q0060-answer

**nl-Q0061** — Tom zei dat hij geen vrijwilligers meer nodig had.

Tom said he didn't need any more volunteers.

Expected form: **dat**

Why: Demonstratives. [[Dutch#^nl-Q0061|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Tom%20zei%20dat%20hij%20geen%20vrijwilligers%20meer%20nodig%20had.)
^nl-Q0061-answer

**nl-Q0062** — Tom zei dat hij geen vrijwilligers meer nodig had.

Tom said he didn't need any more volunteers.

Expected form: **dat**

Why: Demonstratives. [[Dutch#^nl-Q0062|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Tom%20zei%20dat%20hij%20geen%20vrijwilligers%20meer%20nodig%20had.)
^nl-Q0062-answer

**nl-Q0063** — Denk je dat Tom kaal wordt?

Do you think Tom is going bald?

Expected form: **dat**

Why: Demonstratives. [[Dutch#^nl-Q0063|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Denk%20je%20dat%20Tom%20kaal%20wordt%3F)
^nl-Q0063-answer

**nl-Q0064** — Denk je dat Tom kaal wordt?

Do you think Tom is going bald?

Why: Demonstratives. [[Dutch#^nl-Q0064|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Denk%20je%20dat%20Tom%20kaal%20wordt%3F)
^nl-Q0064-answer

**nl-Q0065** — Ons is verteld dat we dat niet mogen doen.

We've been told not to do that.

Why: Demonstratives. [[Dutch#^nl-Q0065|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ons%20is%20verteld%20dat%20we%20dat%20niet%20mogen%20doen.)
^nl-Q0065-answer

**nl-Q0066** — Ons is verteld dat we dat niet mogen doen.

We've been told not to do that.

Dit/dat commonly pair with singular het nouns; deze/die with de nouns and plurals. Distance and discourse determine the near/far distinction.

Why: Demonstratives. [[Dutch#^nl-Q0066|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ons%20is%20verteld%20dat%20we%20dat%20niet%20mogen%20doen.)
^nl-Q0066-answer

**nl-Q0067** — Op dit moment zijn we bezig.

We're busy right now.

Expected form: **dit**

Why: Demonstratives. [[Dutch#^nl-Q0067|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Op%20dit%20moment%20zijn%20we%20bezig.)
^nl-Q0067-answer

**nl-Q0068** — Op dit moment zijn we bezig.

We're busy right now.

Expected form: **dit**

Why: Demonstratives. [[Dutch#^nl-Q0068|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Op%20dit%20moment%20zijn%20we%20bezig.)
^nl-Q0068-answer

**nl-Q0069** — Ik denk dat ik verliefd ben.

I think I'm in love.

Expected form: **dat**

Why: Demonstratives. [[Dutch#^nl-Q0069|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20denk%20dat%20ik%20verliefd%20ben.)
^nl-Q0069-answer

**nl-Q0070** — Ik denk dat ik verliefd ben.

I think I'm in love.

Why: Demonstratives. [[Dutch#^nl-Q0070|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20denk%20dat%20ik%20verliefd%20ben.)
^nl-Q0070-answer

**nl-Q0071** — Ik moet kiezen tussen die twee.

I have to choose between these two.

Why: Demonstratives. [[Dutch#^nl-Q0071|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20moet%20kiezen%20tussen%20die%20twee.)
^nl-Q0071-answer

**nl-Q0072** — Ik moet kiezen tussen die twee.

I have to choose between these two.

Dit/dat commonly pair with singular het nouns; deze/die with de nouns and plurals. Distance and discourse determine the near/far distinction.

Why: Demonstratives. [[Dutch#^nl-Q0072|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20moet%20kiezen%20tussen%20die%20twee.)
^nl-Q0072-answer

**nl-Q0073** — Kun je die pan even voor me opbeuren, dan leg ik deze onderzetter eronder.

Could you lift that pan for me, then I'll put this mat under it.

Expected form: **die**

Why: Demonstratives. [[Dutch#^nl-Q0073|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Kun%20je%20die%20pan%20even%20voor%20me%20opbeuren%2C%20dan%20leg%20ik%20deze%20onderzetter%20eronder.)
^nl-Q0073-answer

**nl-Q0074** — Kun je die pan even voor me opbeuren, dan leg ik deze onderzetter eronder.

Could you lift that pan for me, then I'll put this mat under it.

Expected form: **die**

Why: Demonstratives. [[Dutch#^nl-Q0074|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Kun%20je%20die%20pan%20even%20voor%20me%20opbeuren%2C%20dan%20leg%20ik%20deze%20onderzetter%20eronder.)
^nl-Q0074-answer

**nl-Q0075** — Je mag dat niet aan je ouders vertellen.

You mustn't tell that to your parents.

Expected form: **dat**

Why: Demonstratives. [[Dutch#^nl-Q0075|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Je%20mag%20dat%20niet%20aan%20je%20ouders%20vertellen.)
^nl-Q0075-answer

**nl-Q0076** — Je mag dat niet aan je ouders vertellen.

You mustn't tell that to your parents.

Why: Demonstratives. [[Dutch#^nl-Q0076|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Je%20mag%20dat%20niet%20aan%20je%20ouders%20vertellen.)
^nl-Q0076-answer

**nl-Q0077** — Tom zou dat niet willen doen.

Tom wouldn't want to do that.

Why: Demonstratives. [[Dutch#^nl-Q0077|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Tom%20zou%20dat%20niet%20willen%20doen.)
^nl-Q0077-answer

**nl-Q0078** — Tom zou dat niet willen doen.

Tom wouldn't want to do that.

Dit/dat commonly pair with singular het nouns; deze/die with de nouns and plurals. Distance and discourse determine the near/far distinction.

Why: Demonstratives. [[Dutch#^nl-Q0078|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Tom%20zou%20dat%20niet%20willen%20doen.)
^nl-Q0078-answer

**nl-Q0079** — Deze vork is niet schoon.

This fork isn't clean.

Expected form: **Deze**

Why: Demonstratives. [[Dutch#^nl-Q0079|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Deze%20vork%20is%20niet%20schoon.)
^nl-Q0079-answer

**nl-Q0080** — Deze vork is niet schoon.

This fork isn't clean.

Expected form: **Deze**

Why: Demonstratives. [[Dutch#^nl-Q0080|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Deze%20vork%20is%20niet%20schoon.)
^nl-Q0080-answer

**nl-Q0081** — Ik heb dit stripboek van zijn zus geleend.

I borrowed this comic book from his sister.

Expected form: **dit**

Why: Demonstratives. [[Dutch#^nl-Q0081|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20heb%20dit%20stripboek%20van%20zijn%20zus%20geleend.)
^nl-Q0081-answer

**nl-Q0082** — Ik heb dit stripboek van zijn zus geleend.

I borrowed this comic book from his sister.

Why: Demonstratives. [[Dutch#^nl-Q0082|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20heb%20dit%20stripboek%20van%20zijn%20zus%20geleend.)
^nl-Q0082-answer

**nl-Q0083** — Ik woon in dit gebied.

I live in this area.

Why: Demonstratives. [[Dutch#^nl-Q0083|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20woon%20in%20dit%20gebied.)
^nl-Q0083-answer

**nl-Q0084** — Ik woon in dit gebied.

I live in this area.

Dit/dat commonly pair with singular het nouns; deze/die with de nouns and plurals. Distance and discourse determine the near/far distinction.

Why: Demonstratives. [[Dutch#^nl-Q0084|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20woon%20in%20dit%20gebied.)
^nl-Q0084-answer

**nl-Q0085** — Mijn zoon denkt dat vrouwen sterker dan mannen zijn.

My son thinks women are stronger than men.

Expected form: **dat**

Why: Demonstratives. [[Dutch#^nl-Q0085|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Mijn%20zoon%20denkt%20dat%20vrouwen%20sterker%20dan%20mannen%20zijn.)
^nl-Q0085-answer

**nl-Q0086** — Mijn zoon denkt dat vrouwen sterker dan mannen zijn.

My son thinks women are stronger than men.

Expected form: **dat**

Why: Demonstratives. [[Dutch#^nl-Q0086|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Mijn%20zoon%20denkt%20dat%20vrouwen%20sterker%20dan%20mannen%20zijn.)
^nl-Q0086-answer

**nl-Q0087** — Hij is precies degene die je zoekt.

He is precisely the one you are looking for.

Expected form: **die**

Why: Demonstratives. [[Dutch#^nl-Q0087|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Hij%20is%20precies%20degene%20die%20je%20zoekt.)
^nl-Q0087-answer

**nl-Q0088** — Hij is precies degene die je zoekt.

He is precisely the one you are looking for.

Why: Demonstratives. [[Dutch#^nl-Q0088|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Hij%20is%20precies%20degene%20die%20je%20zoekt.)
^nl-Q0088-answer

**nl-Q0089** — Ik denk wel dat het Tom niet zou bevallen.

I'm sure Tom wouldn't like it.

Why: Demonstratives. [[Dutch#^nl-Q0089|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20denk%20wel%20dat%20het%20Tom%20niet%20zou%20bevallen.)
^nl-Q0089-answer

**nl-Q0090** — Ik denk wel dat het Tom niet zou bevallen.

I'm sure Tom wouldn't like it.

Dit/dat commonly pair with singular het nouns; deze/die with de nouns and plurals. Distance and discourse determine the near/far distinction.

Why: Demonstratives. [[Dutch#^nl-Q0090|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20denk%20wel%20dat%20het%20Tom%20niet%20zou%20bevallen.)
^nl-Q0090-answer

**nl-Q0091** — Deze stof is erg zacht.

This fabric is very soft.

Expected form: **Deze**

Why: Demonstratives. [[Dutch#^nl-Q0091|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Deze%20stof%20is%20erg%20zacht.)
^nl-Q0091-answer

**nl-Q0092** — Deze stof is erg zacht.

This fabric is very soft.

Expected form: **Deze**

Why: Demonstratives. [[Dutch#^nl-Q0092|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Deze%20stof%20is%20erg%20zacht.)
^nl-Q0092-answer

**nl-Q0093** — O, ja, dat herinner ik me.

Oh, yes, I remember.

Expected form: **dat**

Why: Demonstratives. [[Dutch#^nl-Q0093|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=O%2C%20ja%2C%20dat%20herinner%20ik%20me.)
^nl-Q0093-answer

**nl-Q0094** — O, ja, dat herinner ik me.

Oh, yes, I remember.

Why: Demonstratives. [[Dutch#^nl-Q0094|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=O%2C%20ja%2C%20dat%20herinner%20ik%20me.)
^nl-Q0094-answer

**nl-Q0095** — Tom wist dat ik verdrietig was.

Tom knew that I was sad.

Why: Demonstratives. [[Dutch#^nl-Q0095|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Tom%20wist%20dat%20ik%20verdrietig%20was.)
^nl-Q0095-answer

**nl-Q0096** — Tom wist dat ik verdrietig was.

Tom knew that I was sad.

Dit/dat commonly pair with singular het nouns; deze/die with de nouns and plurals. Distance and discourse determine the near/far distinction.

Why: Demonstratives. [[Dutch#^nl-Q0096|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Tom%20wist%20dat%20ik%20verdrietig%20was.)
^nl-Q0096-answer

**nl-Q0097** — Dit voedsel is ongezond.

This food is unhealthy.

Expected form: **Dit**

Why: Demonstratives. [[Dutch#^nl-Q0097|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Dit%20voedsel%20is%20ongezond.)
^nl-Q0097-answer

**nl-Q0098** — Dit voedsel is ongezond.

This food is unhealthy.

Expected form: **Dit**

Why: Demonstratives. [[Dutch#^nl-Q0098|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Dit%20voedsel%20is%20ongezond.)
^nl-Q0098-answer

**nl-Q0099** — Dit is een persoonlijke kwestie.

This a personal matter.

Expected form: **Dit**

Why: Demonstratives. [[Dutch#^nl-Q0099|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Dit%20is%20een%20persoonlijke%20kwestie.)
^nl-Q0099-answer

**nl-Q0100** — Dit is een persoonlijke kwestie.

This a personal matter.

Why: Demonstratives. [[Dutch#^nl-Q0100|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Dit%20is%20een%20persoonlijke%20kwestie.)
^nl-Q0100-answer


### Answers 101–150

**nl-Q0101** — Jullie zijn goud waard.

You're worth gold.

Why: Personal pronouns. [[Dutch#^nl-Q0101|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Jullie%20zijn%20goud%20waard.)
^nl-Q0101-answer

**nl-Q0102** — Jullie zijn goud waard.

You're worth gold.

Dutch pronouns have stressed and unstressed forms. Je/ze/we are common reduced forms. U is polite you and follows its own agreement patterns.

Why: Personal pronouns. [[Dutch#^nl-Q0102|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Jullie%20zijn%20goud%20waard.)
^nl-Q0102-answer

**nl-Q0103** — Ik ga vandaag niet meer werken.

I am not going to work more today.

Expected form: **Ik**

Why: Personal pronouns. [[Dutch#^nl-Q0103|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20ga%20vandaag%20niet%20meer%20werken.)
^nl-Q0103-answer

**nl-Q0104** — Ik ga vandaag niet meer werken.

I am not going to work more today.

Expected form: **Ik**

Why: Personal pronouns. [[Dutch#^nl-Q0104|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20ga%20vandaag%20niet%20meer%20werken.)
^nl-Q0104-answer

**nl-Q0105** — Hoelang moeten we wachten, denk je?

How long do you think we'll have to wait?

Expected form: **we**

Why: Personal pronouns. [[Dutch#^nl-Q0105|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Hoelang%20moeten%20we%20wachten%2C%20denk%20je%3F)
^nl-Q0105-answer

**nl-Q0106** — Hoelang moeten we wachten, denk je?

How long do you think we'll have to wait?

Why: Personal pronouns. [[Dutch#^nl-Q0106|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Hoelang%20moeten%20we%20wachten%2C%20denk%20je%3F)
^nl-Q0106-answer

**nl-Q0107** — Ben je voor iets allergisch?

Are you allergic to anything?

Why: Personal pronouns. [[Dutch#^nl-Q0107|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ben%20je%20voor%20iets%20allergisch%3F)
^nl-Q0107-answer

**nl-Q0108** — Ben je voor iets allergisch?

Are you allergic to anything?

Dutch pronouns have stressed and unstressed forms. Je/ze/we are common reduced forms. U is polite you and follows its own agreement patterns.

Why: Personal pronouns. [[Dutch#^nl-Q0108|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ben%20je%20voor%20iets%20allergisch%3F)
^nl-Q0108-answer

**nl-Q0109** — Ik ben vanmorgen om zeven uur opgestaan.

I got up at seven this morning.

Expected form: **Ik**

Why: Personal pronouns. [[Dutch#^nl-Q0109|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20ben%20vanmorgen%20om%20zeven%20uur%20opgestaan.)
^nl-Q0109-answer

**nl-Q0110** — Ik ben vanmorgen om zeven uur opgestaan.

I got up at seven this morning.

Expected form: **Ik**

Why: Personal pronouns. [[Dutch#^nl-Q0110|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20ben%20vanmorgen%20om%20zeven%20uur%20opgestaan.)
^nl-Q0110-answer

**nl-Q0111** — Tom had moeten doen wat ik hem gevraagd heb.

Tom should've done what I asked him to do.

Expected form: **ik**

Why: Personal pronouns. [[Dutch#^nl-Q0111|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Tom%20had%20moeten%20doen%20wat%20ik%20hem%20gevraagd%20heb.)
^nl-Q0111-answer

**nl-Q0112** — Tom had moeten doen wat ik hem gevraagd heb.

Tom should've done what I asked him to do.

Why: Personal pronouns. [[Dutch#^nl-Q0112|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Tom%20had%20moeten%20doen%20wat%20ik%20hem%20gevraagd%20heb.)
^nl-Q0112-answer

**nl-Q0113** — Ik wil jouw goud niet.

I don't want your gold.

Why: Personal pronouns. [[Dutch#^nl-Q0113|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20wil%20jouw%20goud%20niet.)
^nl-Q0113-answer

**nl-Q0114** — Ik wil jouw goud niet.

I don't want your gold.

Dutch pronouns have stressed and unstressed forms. Je/ze/we are common reduced forms. U is polite you and follows its own agreement patterns.

Why: Personal pronouns. [[Dutch#^nl-Q0114|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20wil%20jouw%20goud%20niet.)
^nl-Q0114-answer

**nl-Q0115** — Telkens wanneer ik hem zie, herinnert hij me aan mijn overleden grootvader.

Whenever I see him he reminds me of my late grandfather.

Expected form: **ik**

Why: Personal pronouns. [[Dutch#^nl-Q0115|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Telkens%20wanneer%20ik%20hem%20zie%2C%20herinnert%20hij%20me%20aan%20mijn%20overleden%20grootvader.)
^nl-Q0115-answer

**nl-Q0116** — Telkens wanneer ik hem zie, herinnert hij me aan mijn overleden grootvader.

Whenever I see him he reminds me of my late grandfather.

Expected form: **ik**

Why: Personal pronouns. [[Dutch#^nl-Q0116|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Telkens%20wanneer%20ik%20hem%20zie%2C%20herinnert%20hij%20me%20aan%20mijn%20overleden%20grootvader.)
^nl-Q0116-answer

**nl-Q0117** — Wat hij zegt is absoluut correct.

What he says is absolutely correct.

Expected form: **hij**

Why: Personal pronouns. [[Dutch#^nl-Q0117|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Wat%20hij%20zegt%20is%20absoluut%20correct.)
^nl-Q0117-answer

**nl-Q0118** — Wat hij zegt is absoluut correct.

What he says is absolutely correct.

Why: Personal pronouns. [[Dutch#^nl-Q0118|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Wat%20hij%20zegt%20is%20absoluut%20correct.)
^nl-Q0118-answer

**nl-Q0119** — Schrijf jij liefdesbrieven?

Do you write love letters?

Why: Personal pronouns. [[Dutch#^nl-Q0119|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Schrijf%20jij%20liefdesbrieven%3F)
^nl-Q0119-answer

**nl-Q0120** — Schrijf jij liefdesbrieven?

Do you write love letters?

Dutch pronouns have stressed and unstressed forms. Je/ze/we are common reduced forms. U is polite you and follows its own agreement patterns.

Why: Personal pronouns. [[Dutch#^nl-Q0120|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Schrijf%20jij%20liefdesbrieven%3F)
^nl-Q0120-answer

**nl-Q0121** — Hij drinkt rode wijn.

He drinks red wine.

Expected form: **Hij**

Why: Personal pronouns. [[Dutch#^nl-Q0121|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Hij%20drinkt%20rode%20wijn.)
^nl-Q0121-answer

**nl-Q0122** — Hij drinkt rode wijn.

He drinks red wine.

Expected form: **Hij**

Why: Personal pronouns. [[Dutch#^nl-Q0122|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Hij%20drinkt%20rode%20wijn.)
^nl-Q0122-answer

**nl-Q0123** — Ik heb zo veel aan te bieden.

I have so much to offer.

Expected form: **Ik**

Why: Personal pronouns. [[Dutch#^nl-Q0123|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20heb%20zo%20veel%20aan%20te%20bieden.)
^nl-Q0123-answer

**nl-Q0124** — Ik heb zo veel aan te bieden.

I have so much to offer.

Why: Personal pronouns. [[Dutch#^nl-Q0124|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20heb%20zo%20veel%20aan%20te%20bieden.)
^nl-Q0124-answer

**nl-Q0125** — Zeg me wat je zoekt en ik zal je helpen.

Tell me what you are looking for and I will help you.

Why: Personal pronouns. [[Dutch#^nl-Q0125|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Zeg%20me%20wat%20je%20zoekt%20en%20ik%20zal%20je%20helpen.)
^nl-Q0125-answer

**nl-Q0126** — Zeg me wat je zoekt en ik zal je helpen.

Tell me what you are looking for and I will help you.

Dutch pronouns have stressed and unstressed forms. Je/ze/we are common reduced forms. U is polite you and follows its own agreement patterns.

Why: Personal pronouns. [[Dutch#^nl-Q0126|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Zeg%20me%20wat%20je%20zoekt%20en%20ik%20zal%20je%20helpen.)
^nl-Q0126-answer

**nl-Q0127** — Ik heb met Tom geoefend.

I practiced with Tom.

Expected form: **Ik**

Why: Personal pronouns. [[Dutch#^nl-Q0127|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20heb%20met%20Tom%20geoefend.)
^nl-Q0127-answer

**nl-Q0128** — Ik heb met Tom geoefend.

I practiced with Tom.

Expected form: **Ik**

Why: Personal pronouns. [[Dutch#^nl-Q0128|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20heb%20met%20Tom%20geoefend.)
^nl-Q0128-answer

**nl-Q0129** — Ik leer Kannada.

I learn Kannada.

Expected form: **Ik**

Why: Personal pronouns. [[Dutch#^nl-Q0129|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20leer%20Kannada.)
^nl-Q0129-answer

**nl-Q0130** — Ik leer Kannada.

I learn Kannada.

Why: Personal pronouns. [[Dutch#^nl-Q0130|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20leer%20Kannada.)
^nl-Q0130-answer

**nl-Q0131** — Laat je radio thuis.

Leave your radio at home.

Why: Personal pronouns. [[Dutch#^nl-Q0131|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Laat%20je%20radio%20thuis.)
^nl-Q0131-answer

**nl-Q0132** — Laat je radio thuis.

Leave your radio at home.

Dutch pronouns have stressed and unstressed forms. Je/ze/we are common reduced forms. U is polite you and follows its own agreement patterns.

Why: Personal pronouns. [[Dutch#^nl-Q0132|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Laat%20je%20radio%20thuis.)
^nl-Q0132-answer

**nl-Q0133** — Ik begrijp niet wat me overkomt.

I don't understand what's happening to me.

Expected form: **Ik**

Why: Personal pronouns. [[Dutch#^nl-Q0133|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20begrijp%20niet%20wat%20me%20overkomt.)
^nl-Q0133-answer

**nl-Q0134** — Ik begrijp niet wat me overkomt.

I don't understand what's happening to me.

Expected form: **Ik**

Why: Personal pronouns. [[Dutch#^nl-Q0134|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20begrijp%20niet%20wat%20me%20overkomt.)
^nl-Q0134-answer

**nl-Q0135** — Zoals ik al zei, geen probleem.

Like I said, no problem.

Expected form: **ik**

Why: Personal pronouns. [[Dutch#^nl-Q0135|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Zoals%20ik%20al%20zei%2C%20geen%20probleem.)
^nl-Q0135-answer

**nl-Q0136** — Zoals ik al zei, geen probleem.

Like I said, no problem.

Why: Personal pronouns. [[Dutch#^nl-Q0136|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Zoals%20ik%20al%20zei%2C%20geen%20probleem.)
^nl-Q0136-answer

**nl-Q0137** — Spreekt u Talossaans?

Do you speak Talossan?

Why: Personal pronouns. [[Dutch#^nl-Q0137|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Spreekt%20u%20Talossaans%3F)
^nl-Q0137-answer

**nl-Q0138** — Spreekt u Talossaans?

Do you speak Talossan?

Dutch pronouns have stressed and unstressed forms. Je/ze/we are common reduced forms. U is polite you and follows its own agreement patterns.

Why: Personal pronouns. [[Dutch#^nl-Q0138|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Spreekt%20u%20Talossaans%3F)
^nl-Q0138-answer

**nl-Q0139** — Tom drinkt net zo graag melk als ik.

Tom likes milk as much as I do.

Expected form: **ik**

Why: Personal pronouns. [[Dutch#^nl-Q0139|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Tom%20drinkt%20net%20zo%20graag%20melk%20als%20ik.)
^nl-Q0139-answer

**nl-Q0140** — Tom drinkt net zo graag melk als ik.

Tom likes milk as much as I do.

Expected form: **ik**

Why: Personal pronouns. [[Dutch#^nl-Q0140|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Tom%20drinkt%20net%20zo%20graag%20melk%20als%20ik.)
^nl-Q0140-answer

**nl-Q0141** — U doet me denken aan uw moeder.

You remind me of your mother.

Expected form: **U**

Why: Personal pronouns. [[Dutch#^nl-Q0141|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=U%20doet%20me%20denken%20aan%20uw%20moeder.)
^nl-Q0141-answer

**nl-Q0142** — U doet me denken aan uw moeder.

You remind me of your mother.

Why: Personal pronouns. [[Dutch#^nl-Q0142|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=U%20doet%20me%20denken%20aan%20uw%20moeder.)
^nl-Q0142-answer

**nl-Q0143** — Weet gij waar hij woont?

Do you know where he lives?

Why: Personal pronouns. [[Dutch#^nl-Q0143|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Weet%20gij%20waar%20hij%20woont%3F)
^nl-Q0143-answer

**nl-Q0144** — Weet gij waar hij woont?

Do you know where he lives?

Dutch pronouns have stressed and unstressed forms. Je/ze/we are common reduced forms. U is polite you and follows its own agreement patterns.

Why: Personal pronouns. [[Dutch#^nl-Q0144|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Weet%20gij%20waar%20hij%20woont%3F)
^nl-Q0144-answer

**nl-Q0145** — Willen jullie een schone vork?

Do you want a clean fork?

Expected form: **jullie**

Why: Personal pronouns. [[Dutch#^nl-Q0145|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Willen%20jullie%20een%20schone%20vork%3F)
^nl-Q0145-answer

**nl-Q0146** — Willen jullie een schone vork?

Do you want a clean fork?

Expected form: **jullie**

Why: Personal pronouns. [[Dutch#^nl-Q0146|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Willen%20jullie%20een%20schone%20vork%3F)
^nl-Q0146-answer

**nl-Q0147** — Ik ben geen Liechtensteiner, maar een Zwitser.

I'm not a Liechtensteiner, but a Swiss.

Expected form: **Ik**

Why: Personal pronouns. [[Dutch#^nl-Q0147|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20ben%20geen%20Liechtensteiner%2C%20maar%20een%20Zwitser.)
^nl-Q0147-answer

**nl-Q0148** — Ik ben geen Liechtensteiner, maar een Zwitser.

I'm not a Liechtensteiner, but a Swiss.

Why: Personal pronouns. [[Dutch#^nl-Q0148|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20ben%20geen%20Liechtensteiner%2C%20maar%20een%20Zwitser.)
^nl-Q0148-answer

**nl-Q0149** — Je magie zal hier niet werken.

Your magic won't work here.

Why: Personal pronouns. [[Dutch#^nl-Q0149|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Je%20magie%20zal%20hier%20niet%20werken.)
^nl-Q0149-answer

**nl-Q0150** — Je magie zal hier niet werken.

Your magic won't work here.

Dutch pronouns have stressed and unstressed forms. Je/ze/we are common reduced forms. U is polite you and follows its own agreement patterns.

Why: Personal pronouns. [[Dutch#^nl-Q0150|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Je%20magie%20zal%20hier%20niet%20werken.)
^nl-Q0150-answer


### Answers 151–200

**nl-Q0151** — Mijn Frans is nog steeds niet zo goed.

My French is still not very good.

Expected form: **is**

Why: Zijn forms. [[Dutch#^nl-Q0151|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Mijn%20Frans%20is%20nog%20steeds%20niet%20zo%20goed.)
^nl-Q0151-answer

**nl-Q0152** — Mijn Frans is nog steeds niet zo goed.

My French is still not very good.

Expected form: **is**

Why: Zijn forms. [[Dutch#^nl-Q0152|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Mijn%20Frans%20is%20nog%20steeds%20niet%20zo%20goed.)
^nl-Q0152-answer

**nl-Q0153** — Sommige mensen zijn allergisch voor latex.

Some people are allergic to latex.

Expected form: **zijn**

Why: Zijn forms. [[Dutch#^nl-Q0153|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Sommige%20mensen%20zijn%20allergisch%20voor%20latex.)
^nl-Q0153-answer

**nl-Q0154** — Sommige mensen zijn allergisch voor latex.

Some people are allergic to latex.

Why: Zijn forms. [[Dutch#^nl-Q0154|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Sommige%20mensen%20zijn%20allergisch%20voor%20latex.)
^nl-Q0154-answer

**nl-Q0155** — Alles is helder.

Everything is clear.

Why: Zijn forms. [[Dutch#^nl-Q0155|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Alles%20is%20helder.)
^nl-Q0155-answer

**nl-Q0156** — Alles is helder.

Everything is clear.

Zijn is irregular. Main statements normally place the finite verb second; yes/no questions place it first. With jij/je after the verb, the present -t is often absent in applicable verbs.

Why: Zijn forms. [[Dutch#^nl-Q0156|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Alles%20is%20helder.)
^nl-Q0156-answer

**nl-Q0157** — Tom lijkt klaar te zijn om te gaan.

Tom seems to be ready to go.

Expected form: **zijn**

Why: Zijn forms. [[Dutch#^nl-Q0157|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Tom%20lijkt%20klaar%20te%20zijn%20om%20te%20gaan.)
^nl-Q0157-answer

**nl-Q0158** — Tom lijkt klaar te zijn om te gaan.

Tom seems to be ready to go.

Expected form: **zijn**

Why: Zijn forms. [[Dutch#^nl-Q0158|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Tom%20lijkt%20klaar%20te%20zijn%20om%20te%20gaan.)
^nl-Q0158-answer

**nl-Q0159** — Een meniscus is geen been. Het is kraakbeen, een elastisch, buigzaam weefsel.

The meniscus is not a bone. It is a cartilage, a flexible, elastic tissue.

Expected form: **is**

Why: Zijn forms. [[Dutch#^nl-Q0159|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Een%20meniscus%20is%20geen%20been.%20Het%20is%20kraakbeen%2C%20een%20elastisch%2C%20buigzaam%20weefsel.)
^nl-Q0159-answer

**nl-Q0160** — Een meniscus is geen been. Het is kraakbeen, een elastisch, buigzaam weefsel.

The meniscus is not a bone. It is a cartilage, a flexible, elastic tissue.

Why: Zijn forms. [[Dutch#^nl-Q0160|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Een%20meniscus%20is%20geen%20been.%20Het%20is%20kraakbeen%2C%20een%20elastisch%2C%20buigzaam%20weefsel.)
^nl-Q0160-answer

**nl-Q0161** — Yamoussoukro is de hoofdstad van Ivoorkust.

Yamoussoukro is the capital of Ivory Coast.

Why: Zijn forms. [[Dutch#^nl-Q0161|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Yamoussoukro%20is%20de%20hoofdstad%20van%20Ivoorkust.)
^nl-Q0161-answer

**nl-Q0162** — Yamoussoukro is de hoofdstad van Ivoorkust.

Yamoussoukro is the capital of Ivory Coast.

Zijn is irregular. Main statements normally place the finite verb second; yes/no questions place it first. With jij/je after the verb, the present -t is often absent in applicable verbs.

Why: Zijn forms. [[Dutch#^nl-Q0162|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Yamoussoukro%20is%20de%20hoofdstad%20van%20Ivoorkust.)
^nl-Q0162-answer

**nl-Q0163** — Het meisje aan de piano is mijn zuster.

The girl playing the piano is my sister.

Expected form: **is**

Why: Zijn forms. [[Dutch#^nl-Q0163|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Het%20meisje%20aan%20de%20piano%20is%20mijn%20zuster.)
^nl-Q0163-answer

**nl-Q0164** — Het meisje aan de piano is mijn zuster.

The girl playing the piano is my sister.

Expected form: **is**

Why: Zijn forms. [[Dutch#^nl-Q0164|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Het%20meisje%20aan%20de%20piano%20is%20mijn%20zuster.)
^nl-Q0164-answer

**nl-Q0165** — Tokio station is de derde halte.

Tokyo Station is the third stop.

Expected form: **is**

Why: Zijn forms. [[Dutch#^nl-Q0165|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Tokio%20station%20is%20de%20derde%20halte.)
^nl-Q0165-answer

**nl-Q0166** — Tokio station is de derde halte.

Tokyo Station is the third stop.

Why: Zijn forms. [[Dutch#^nl-Q0166|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Tokio%20station%20is%20de%20derde%20halte.)
^nl-Q0166-answer

**nl-Q0167** — Verbeteren is soms moeilijker dan schrijven.

Correcting is sometimes harder than writing.

Why: Zijn forms. [[Dutch#^nl-Q0167|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Verbeteren%20is%20soms%20moeilijker%20dan%20schrijven.)
^nl-Q0167-answer

**nl-Q0168** — Verbeteren is soms moeilijker dan schrijven.

Correcting is sometimes harder than writing.

Zijn is irregular. Main statements normally place the finite verb second; yes/no questions place it first. With jij/je after the verb, the present -t is often absent in applicable verbs.

Why: Zijn forms. [[Dutch#^nl-Q0168|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Verbeteren%20is%20soms%20moeilijker%20dan%20schrijven.)
^nl-Q0168-answer

**nl-Q0169** — Waarom is het op slot?

Why is it locked?

Expected form: **is**

Why: Zijn forms. [[Dutch#^nl-Q0169|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Waarom%20is%20het%20op%20slot%3F)
^nl-Q0169-answer

**nl-Q0170** — Waarom is het op slot?

Why is it locked?

Expected form: **is**

Why: Zijn forms. [[Dutch#^nl-Q0170|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Waarom%20is%20het%20op%20slot%3F)
^nl-Q0170-answer

**nl-Q0171** — Je bent rijk.

You are rich.

Expected form: **bent**

Why: Zijn forms. [[Dutch#^nl-Q0171|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Je%20bent%20rijk.)
^nl-Q0171-answer

**nl-Q0172** — Je bent rijk.

You are rich.

Why: Zijn forms. [[Dutch#^nl-Q0172|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Je%20bent%20rijk.)
^nl-Q0172-answer

**nl-Q0173** — Het is hier gezellig.

It's cozy in here.

Why: Zijn forms. [[Dutch#^nl-Q0173|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Het%20is%20hier%20gezellig.)
^nl-Q0173-answer

**nl-Q0174** — Het is hier gezellig.

It's cozy in here.

Zijn is irregular. Main statements normally place the finite verb second; yes/no questions place it first. With jij/je after the verb, the present -t is often absent in applicable verbs.

Why: Zijn forms. [[Dutch#^nl-Q0174|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Het%20is%20hier%20gezellig.)
^nl-Q0174-answer

**nl-Q0175** — Jamaica is een Engelse kolonie.

Jamaica's an English colony.

Expected form: **is**

Why: Zijn forms. [[Dutch#^nl-Q0175|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Jamaica%20is%20een%20Engelse%20kolonie.)
^nl-Q0175-answer

**nl-Q0176** — Jamaica is een Engelse kolonie.

Jamaica's an English colony.

Expected form: **is**

Why: Zijn forms. [[Dutch#^nl-Q0176|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Jamaica%20is%20een%20Engelse%20kolonie.)
^nl-Q0176-answer

**nl-Q0177** — Hoe oud is het universum?

How old is the universe?

Expected form: **is**

Why: Zijn forms. [[Dutch#^nl-Q0177|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Hoe%20oud%20is%20het%20universum%3F)
^nl-Q0177-answer

**nl-Q0178** — Hoe oud is het universum?

How old is the universe?

Why: Zijn forms. [[Dutch#^nl-Q0178|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Hoe%20oud%20is%20het%20universum%3F)
^nl-Q0178-answer

**nl-Q0179** — Niets was niet op zijn plaats.

Nothing was out of place.

Why: Zijn forms. [[Dutch#^nl-Q0179|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Niets%20was%20niet%20op%20zijn%20plaats.)
^nl-Q0179-answer

**nl-Q0180** — Niets was niet op zijn plaats.

Nothing was out of place.

Zijn is irregular. Main statements normally place the finite verb second; yes/no questions place it first. With jij/je after the verb, the present -t is often absent in applicable verbs.

Why: Zijn forms. [[Dutch#^nl-Q0180|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Niets%20was%20niet%20op%20zijn%20plaats.)
^nl-Q0180-answer

**nl-Q0181** — Het is interessant om dreumesen te bekijken.

Babies are interesting to watch.

Expected form: **is**

Why: Zijn forms. [[Dutch#^nl-Q0181|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Het%20is%20interessant%20om%20dreumesen%20te%20bekijken.)
^nl-Q0181-answer

**nl-Q0182** — Het is interessant om dreumesen te bekijken.

Babies are interesting to watch.

Expected form: **is**

Why: Zijn forms. [[Dutch#^nl-Q0182|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Het%20is%20interessant%20om%20dreumesen%20te%20bekijken.)
^nl-Q0182-answer

**nl-Q0183** — Je bent zo'n goede jongen, Tom!

What a good boy you are, Tom!

Expected form: **bent**

Why: Zijn forms. [[Dutch#^nl-Q0183|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Je%20bent%20zo%27n%20goede%20jongen%2C%20Tom%21)
^nl-Q0183-answer

**nl-Q0184** — Je bent zo'n goede jongen, Tom!

What a good boy you are, Tom!

Why: Zijn forms. [[Dutch#^nl-Q0184|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Je%20bent%20zo%27n%20goede%20jongen%2C%20Tom%21)
^nl-Q0184-answer

**nl-Q0185** — Het spijt me, maar het is onmogelijk.

I'm sorry, but it's impossible.

Why: Zijn forms. [[Dutch#^nl-Q0185|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Het%20spijt%20me%2C%20maar%20het%20is%20onmogelijk.)
^nl-Q0185-answer

**nl-Q0186** — Het spijt me, maar het is onmogelijk.

I'm sorry, but it's impossible.

Zijn is irregular. Main statements normally place the finite verb second; yes/no questions place it first. With jij/je after the verb, the present -t is often absent in applicable verbs.

Why: Zijn forms. [[Dutch#^nl-Q0186|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Het%20spijt%20me%2C%20maar%20het%20is%20onmogelijk.)
^nl-Q0186-answer

**nl-Q0187** — Hij is naar Amerika gegaan om Engels te leren.

He went to America to study English.

Expected form: **is**

Why: Zijn forms. [[Dutch#^nl-Q0187|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Hij%20is%20naar%20Amerika%20gegaan%20om%20Engels%20te%20leren.)
^nl-Q0187-answer

**nl-Q0188** — Hij is naar Amerika gegaan om Engels te leren.

He went to America to study English.

Expected form: **is**

Why: Zijn forms. [[Dutch#^nl-Q0188|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Hij%20is%20naar%20Amerika%20gegaan%20om%20Engels%20te%20leren.)
^nl-Q0188-answer

**nl-Q0189** — Tom verhief zijn stem.

Tom raised his voice.

Expected form: **zijn**

Why: Zijn forms. [[Dutch#^nl-Q0189|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Tom%20verhief%20zijn%20stem.)
^nl-Q0189-answer

**nl-Q0190** — Tom verhief zijn stem.

Tom raised his voice.

Why: Zijn forms. [[Dutch#^nl-Q0190|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Tom%20verhief%20zijn%20stem.)
^nl-Q0190-answer

**nl-Q0191** — Daar is onze bus.

There's our bus.

Why: Zijn forms. [[Dutch#^nl-Q0191|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Daar%20is%20onze%20bus.)
^nl-Q0191-answer

**nl-Q0192** — Daar is onze bus.

There's our bus.

Zijn is irregular. Main statements normally place the finite verb second; yes/no questions place it first. With jij/je after the verb, the present -t is often absent in applicable verbs.

Why: Zijn forms. [[Dutch#^nl-Q0192|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Daar%20is%20onze%20bus.)
^nl-Q0192-answer

**nl-Q0193** — Mijn schuilnaam is Tom.

My nickname is Tom.

Expected form: **is**

Why: Zijn forms. [[Dutch#^nl-Q0193|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Mijn%20schuilnaam%20is%20Tom.)
^nl-Q0193-answer

**nl-Q0194** — Mijn schuilnaam is Tom.

My nickname is Tom.

Expected form: **is**

Why: Zijn forms. [[Dutch#^nl-Q0194|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Mijn%20schuilnaam%20is%20Tom.)
^nl-Q0194-answer

**nl-Q0195** — Tom en Maria zijn allebei ouder dan Johan.

Tom and Mary are both older than John.

Expected form: **zijn**

Why: Zijn forms. [[Dutch#^nl-Q0195|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Tom%20en%20Maria%20zijn%20allebei%20ouder%20dan%20Johan.)
^nl-Q0195-answer

**nl-Q0196** — Tom en Maria zijn allebei ouder dan Johan.

Tom and Mary are both older than John.

Why: Zijn forms. [[Dutch#^nl-Q0196|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Tom%20en%20Maria%20zijn%20allebei%20ouder%20dan%20Johan.)
^nl-Q0196-answer

**nl-Q0197** — Ik vraag me af waarom hij te laat is.

I wonder why he is late.

Why: Zijn forms. [[Dutch#^nl-Q0197|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20vraag%20me%20af%20waarom%20hij%20te%20laat%20is.)
^nl-Q0197-answer

**nl-Q0198** — Ik vraag me af waarom hij te laat is.

I wonder why he is late.

Zijn is irregular. Main statements normally place the finite verb second; yes/no questions place it first. With jij/je after the verb, the present -t is often absent in applicable verbs.

Why: Zijn forms. [[Dutch#^nl-Q0198|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20vraag%20me%20af%20waarom%20hij%20te%20laat%20is.)
^nl-Q0198-answer

**nl-Q0199** — Mijn vader is een beetje ouderwets.

My father is a bit old-fashioned.

Expected form: **is**

Why: Zijn forms. [[Dutch#^nl-Q0199|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Mijn%20vader%20is%20een%20beetje%20ouderwets.)
^nl-Q0199-answer

**nl-Q0200** — Mijn vader is een beetje ouderwets.

My father is a bit old-fashioned.

Expected form: **is**

Why: Zijn forms. [[Dutch#^nl-Q0200|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Mijn%20vader%20is%20een%20beetje%20ouderwets.)
^nl-Q0200-answer


### Answers 201–250

**nl-Q0201** — Water heeft nul calorieën.

Water has zero calories.

Expected form: **heeft**

Why: Hebben forms. [[Dutch#^nl-Q0201|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Water%20heeft%20nul%20calorie%C3%ABn.)
^nl-Q0201-answer

**nl-Q0202** — Water heeft nul calorieën.

Water has zero calories.

Why: Hebben forms. [[Dutch#^nl-Q0202|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Water%20heeft%20nul%20calorie%C3%ABn.)
^nl-Q0202-answer

**nl-Q0203** — Tom heeft hoop.

Tom has hope.

Why: Hebben forms. [[Dutch#^nl-Q0203|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Tom%20heeft%20hoop.)
^nl-Q0203-answer

**nl-Q0204** — Tom heeft hoop.

Tom has hope.

Hebben expresses possession and serves as an auxiliary. The finite form agrees with the subject; a participle or infinitive can stand at the end of the clause.

Why: Hebben forms. [[Dutch#^nl-Q0204|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Tom%20heeft%20hoop.)
^nl-Q0204-answer

**nl-Q0205** — Toms huis heeft een kleine keuken.

Tom's house has a tiny kitchen.

Expected form: **heeft**

Why: Hebben forms. [[Dutch#^nl-Q0205|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Toms%20huis%20heeft%20een%20kleine%20keuken.)
^nl-Q0205-answer

**nl-Q0206** — Toms huis heeft een kleine keuken.

Tom's house has a tiny kitchen.

Expected form: **heeft**

Why: Hebben forms. [[Dutch#^nl-Q0206|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Toms%20huis%20heeft%20een%20kleine%20keuken.)
^nl-Q0206-answer

**nl-Q0207** — Welke landen heeft u bezocht?

What countries have you visited?

Expected form: **heeft**

Why: Hebben forms. [[Dutch#^nl-Q0207|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Welke%20landen%20heeft%20u%20bezocht%3F)
^nl-Q0207-answer

**nl-Q0208** — Welke landen heeft u bezocht?

What countries have you visited?

Why: Hebben forms. [[Dutch#^nl-Q0208|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Welke%20landen%20heeft%20u%20bezocht%3F)
^nl-Q0208-answer

**nl-Q0209** — Heb je geen honger?

Aren't you hungry?

Why: Hebben forms. [[Dutch#^nl-Q0209|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Heb%20je%20geen%20honger%3F)
^nl-Q0209-answer

**nl-Q0210** — Heb je geen honger?

Aren't you hungry?

Hebben expresses possession and serves as an auxiliary. The finite form agrees with the subject; a participle or infinitive can stand at the end of the clause.

Why: Hebben forms. [[Dutch#^nl-Q0210|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Heb%20je%20geen%20honger%3F)
^nl-Q0210-answer

**nl-Q0211** — We hebben het examen geslaagd.

We passed the exam.

Expected form: **hebben**

Why: Hebben forms. [[Dutch#^nl-Q0211|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=We%20hebben%20het%20examen%20geslaagd.)
^nl-Q0211-answer

**nl-Q0212** — We hebben het examen geslaagd.

We passed the exam.

Expected form: **hebben**

Why: Hebben forms. [[Dutch#^nl-Q0212|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=We%20hebben%20het%20examen%20geslaagd.)
^nl-Q0212-answer

**nl-Q0213** — De wind heeft mijn paraplu kapotgemaakt.

The wind ruined my umbrella.

Expected form: **heeft**

Why: Hebben forms. [[Dutch#^nl-Q0213|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=De%20wind%20heeft%20mijn%20paraplu%20kapotgemaakt.)
^nl-Q0213-answer

**nl-Q0214** — De wind heeft mijn paraplu kapotgemaakt.

The wind ruined my umbrella.

Why: Hebben forms. [[Dutch#^nl-Q0214|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=De%20wind%20heeft%20mijn%20paraplu%20kapotgemaakt.)
^nl-Q0214-answer

**nl-Q0215** — Heb je regelmatig problemen met je sinussen?

Do you regularly have sinus issues?

Why: Hebben forms. [[Dutch#^nl-Q0215|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Heb%20je%20regelmatig%20problemen%20met%20je%20sinussen%3F)
^nl-Q0215-answer

**nl-Q0216** — Heb je regelmatig problemen met je sinussen?

Do you regularly have sinus issues?

Hebben expresses possession and serves as an auxiliary. The finite form agrees with the subject; a participle or infinitive can stand at the end of the clause.

Why: Hebben forms. [[Dutch#^nl-Q0216|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Heb%20je%20regelmatig%20problemen%20met%20je%20sinussen%3F)
^nl-Q0216-answer

**nl-Q0217** — Tom en Mary hebben een keuze.

Tom and Mary have a choice.

Expected form: **hebben**

Why: Hebben forms. [[Dutch#^nl-Q0217|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Tom%20en%20Mary%20hebben%20een%20keuze.)
^nl-Q0217-answer

**nl-Q0218** — Tom en Mary hebben een keuze.

Tom and Mary have a choice.

Expected form: **hebben**

Why: Hebben forms. [[Dutch#^nl-Q0218|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Tom%20en%20Mary%20hebben%20een%20keuze.)
^nl-Q0218-answer

**nl-Q0219** — Wie heeft het gebouwd?

Who built it?

Expected form: **heeft**

Why: Hebben forms. [[Dutch#^nl-Q0219|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Wie%20heeft%20het%20gebouwd%3F)
^nl-Q0219-answer

**nl-Q0220** — Wie heeft het gebouwd?

Who built it?

Why: Hebben forms. [[Dutch#^nl-Q0220|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Wie%20heeft%20het%20gebouwd%3F)
^nl-Q0220-answer

**nl-Q0221** — Ik heb vandaag een afspraak met het lot.

Today, I have a date with destiny.

Why: Hebben forms. [[Dutch#^nl-Q0221|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20heb%20vandaag%20een%20afspraak%20met%20het%20lot.)
^nl-Q0221-answer

**nl-Q0222** — Ik heb vandaag een afspraak met het lot.

Today, I have a date with destiny.

Hebben expresses possession and serves as an auxiliary. The finite form agrees with the subject; a participle or infinitive can stand at the end of the clause.

Why: Hebben forms. [[Dutch#^nl-Q0222|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20heb%20vandaag%20een%20afspraak%20met%20het%20lot.)
^nl-Q0222-answer

**nl-Q0223** — Zij heeft het me getoond.

She showed it to me.

Expected form: **heeft**

Why: Hebben forms. [[Dutch#^nl-Q0223|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Zij%20heeft%20het%20me%20getoond.)
^nl-Q0223-answer

**nl-Q0224** — Zij heeft het me getoond.

She showed it to me.

Expected form: **heeft**

Why: Hebben forms. [[Dutch#^nl-Q0224|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Zij%20heeft%20het%20me%20getoond.)
^nl-Q0224-answer

**nl-Q0225** — Ze heeft haar werk voltooid.

She has finished her work.

Expected form: **heeft**

Why: Hebben forms. [[Dutch#^nl-Q0225|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ze%20heeft%20haar%20werk%20voltooid.)
^nl-Q0225-answer

**nl-Q0226** — Ze heeft haar werk voltooid.

She has finished her work.

Why: Hebben forms. [[Dutch#^nl-Q0226|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ze%20heeft%20haar%20werk%20voltooid.)
^nl-Q0226-answer

**nl-Q0227** — Stel dat je een miljoen yen hebt, wat zou je daarmee gaan doen?

If you had a million yen, what would you do with it?

Why: Hebben forms. [[Dutch#^nl-Q0227|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Stel%20dat%20je%20een%20miljoen%20yen%20hebt%2C%20wat%20zou%20je%20daarmee%20gaan%20doen%3F)
^nl-Q0227-answer

**nl-Q0228** — Stel dat je een miljoen yen hebt, wat zou je daarmee gaan doen?

If you had a million yen, what would you do with it?

Hebben expresses possession and serves as an auxiliary. The finite form agrees with the subject; a participle or infinitive can stand at the end of the clause.

Why: Hebben forms. [[Dutch#^nl-Q0228|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Stel%20dat%20je%20een%20miljoen%20yen%20hebt%2C%20wat%20zou%20je%20daarmee%20gaan%20doen%3F)
^nl-Q0228-answer

**nl-Q0229** — Heeft hij er iets van gezegd?

Did he say anything about it?

Expected form: **Heeft**

Why: Hebben forms. [[Dutch#^nl-Q0229|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Heeft%20hij%20er%20iets%20van%20gezegd%3F)
^nl-Q0229-answer

**nl-Q0230** — Heeft hij er iets van gezegd?

Did he say anything about it?

Expected form: **Heeft**

Why: Hebben forms. [[Dutch#^nl-Q0230|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Heeft%20hij%20er%20iets%20van%20gezegd%3F)
^nl-Q0230-answer

**nl-Q0231** — Ik heb dit nog nooit eerder gedaan. Kan je me laten zien wat ik moet doen?

I've never done this before. Could you please show me what to do?

Expected form: **heb**

Why: Hebben forms. [[Dutch#^nl-Q0231|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20heb%20dit%20nog%20nooit%20eerder%20gedaan.%20Kan%20je%20me%20laten%20zien%20wat%20ik%20moet%20doen%3F)
^nl-Q0231-answer

**nl-Q0232** — Ik heb dit nog nooit eerder gedaan. Kan je me laten zien wat ik moet doen?

I've never done this before. Could you please show me what to do?

Why: Hebben forms. [[Dutch#^nl-Q0232|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20heb%20dit%20nog%20nooit%20eerder%20gedaan.%20Kan%20je%20me%20laten%20zien%20wat%20ik%20moet%20doen%3F)
^nl-Q0232-answer

**nl-Q0233** — Hoeveel zijden heeft een vierkant?

How many sides does a square have?

Why: Hebben forms. [[Dutch#^nl-Q0233|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Hoeveel%20zijden%20heeft%20een%20vierkant%3F)
^nl-Q0233-answer

**nl-Q0234** — Hoeveel zijden heeft een vierkant?

How many sides does a square have?

Hebben expresses possession and serves as an auxiliary. The finite form agrees with the subject; a participle or infinitive can stand at the end of the clause.

Why: Hebben forms. [[Dutch#^nl-Q0234|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Hoeveel%20zijden%20heeft%20een%20vierkant%3F)
^nl-Q0234-answer

**nl-Q0235** — We hebben uw handtekening nodig.

We need your signature.

Expected form: **hebben**

Why: Hebben forms. [[Dutch#^nl-Q0235|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=We%20hebben%20uw%20handtekening%20nodig.)
^nl-Q0235-answer

**nl-Q0236** — We hebben uw handtekening nodig.

We need your signature.

Expected form: **hebben**

Why: Hebben forms. [[Dutch#^nl-Q0236|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=We%20hebben%20uw%20handtekening%20nodig.)
^nl-Q0236-answer

**nl-Q0237** — Zij heeft hem een paar vragen gesteld.

She asked him some questions.

Expected form: **heeft**

Why: Hebben forms. [[Dutch#^nl-Q0237|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Zij%20heeft%20hem%20een%20paar%20vragen%20gesteld.)
^nl-Q0237-answer

**nl-Q0238** — Zij heeft hem een paar vragen gesteld.

She asked him some questions.

Why: Hebben forms. [[Dutch#^nl-Q0238|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Zij%20heeft%20hem%20een%20paar%20vragen%20gesteld.)
^nl-Q0238-answer

**nl-Q0239** — Waar heb je Tom gevonden?

Where did you find Tom?

Why: Hebben forms. [[Dutch#^nl-Q0239|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Waar%20heb%20je%20Tom%20gevonden%3F)
^nl-Q0239-answer

**nl-Q0240** — Waar heb je Tom gevonden?

Where did you find Tom?

Hebben expresses possession and serves as an auxiliary. The finite form agrees with the subject; a participle or infinitive can stand at the end of the clause.

Why: Hebben forms. [[Dutch#^nl-Q0240|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Waar%20heb%20je%20Tom%20gevonden%3F)
^nl-Q0240-answer

**nl-Q0241** — Ze denkt dat ze altijd gelijk heeft.

She thinks that she's always right.

Expected form: **heeft**

Why: Hebben forms. [[Dutch#^nl-Q0241|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ze%20denkt%20dat%20ze%20altijd%20gelijk%20heeft.)
^nl-Q0241-answer

**nl-Q0242** — Ze denkt dat ze altijd gelijk heeft.

She thinks that she's always right.

Expected form: **heeft**

Why: Hebben forms. [[Dutch#^nl-Q0242|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ze%20denkt%20dat%20ze%20altijd%20gelijk%20heeft.)
^nl-Q0242-answer

**nl-Q0243** — Ze heeft een sterke persoonlijkheid.

She has a strong personality.

Expected form: **heeft**

Why: Hebben forms. [[Dutch#^nl-Q0243|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ze%20heeft%20een%20sterke%20persoonlijkheid.)
^nl-Q0243-answer

**nl-Q0244** — Ze heeft een sterke persoonlijkheid.

She has a strong personality.

Why: Hebben forms. [[Dutch#^nl-Q0244|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ze%20heeft%20een%20sterke%20persoonlijkheid.)
^nl-Q0244-answer

**nl-Q0245** — Ik heb ontdekt dat zij beter in wiskunde is dan ik.

I discovered that she was better at math than I.

Why: Hebben forms. [[Dutch#^nl-Q0245|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20heb%20ontdekt%20dat%20zij%20beter%20in%20wiskunde%20is%20dan%20ik.)
^nl-Q0245-answer

**nl-Q0246** — Ik heb ontdekt dat zij beter in wiskunde is dan ik.

I discovered that she was better at math than I.

Hebben expresses possession and serves as an auxiliary. The finite form agrees with the subject; a participle or infinitive can stand at the end of the clause.

Why: Hebben forms. [[Dutch#^nl-Q0246|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20heb%20ontdekt%20dat%20zij%20beter%20in%20wiskunde%20is%20dan%20ik.)
^nl-Q0246-answer

**nl-Q0247** — Ze heeft tomaten gegeten.

She ate tomatoes.

Expected form: **heeft**

Why: Hebben forms. [[Dutch#^nl-Q0247|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ze%20heeft%20tomaten%20gegeten.)
^nl-Q0247-answer

**nl-Q0248** — Ze heeft tomaten gegeten.

She ate tomatoes.

Expected form: **heeft**

Why: Hebben forms. [[Dutch#^nl-Q0248|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ze%20heeft%20tomaten%20gegeten.)
^nl-Q0248-answer

**nl-Q0249** — Ze moet wel erg hard gewerkt hebben.

She must have worked very hard.

Expected form: **hebben**

Why: Hebben forms. [[Dutch#^nl-Q0249|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ze%20moet%20wel%20erg%20hard%20gewerkt%20hebben.)
^nl-Q0249-answer

**nl-Q0250** — Ze moet wel erg hard gewerkt hebben.

She must have worked very hard.

Why: Hebben forms. [[Dutch#^nl-Q0250|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ze%20moet%20wel%20erg%20hard%20gewerkt%20hebben.)
^nl-Q0250-answer


### Answers 251–300

**nl-Q0251** — Als het weer gebeurt, laat het me meteen weten a.u.b.

If it happens again, please let me know right away.

Why: Subordinate connectors. [[Dutch#^nl-Q0251|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Als%20het%20weer%20gebeurt%2C%20laat%20het%20me%20meteen%20weten%20a.u.b.)
^nl-Q0251-answer

**nl-Q0252** — Als het weer gebeurt, laat het me meteen weten a.u.b.

If it happens again, please let me know right away.

Subordinate clauses usually put their verb cluster late. Of can introduce an indirect yes/no question. An ordinary main clause follows verb-second order.

Why: Subordinate connectors. [[Dutch#^nl-Q0252|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Als%20het%20weer%20gebeurt%2C%20laat%20het%20me%20meteen%20weten%20a.u.b.)
^nl-Q0252-answer

**nl-Q0253** — Jeff was drie maanden op zoek voordat hij een baan vond.

Jeff searched for three months before he found a job.

Expected form: **voordat**

Why: Subordinate connectors. [[Dutch#^nl-Q0253|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Jeff%20was%20drie%20maanden%20op%20zoek%20voordat%20hij%20een%20baan%20vond.)
^nl-Q0253-answer

**nl-Q0254** — Jeff was drie maanden op zoek voordat hij een baan vond.

Jeff searched for three months before he found a job.

Expected form: **voordat**

Why: Subordinate connectors. [[Dutch#^nl-Q0254|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Jeff%20was%20drie%20maanden%20op%20zoek%20voordat%20hij%20een%20baan%20vond.)
^nl-Q0254-answer

**nl-Q0255** — De motor stopt als je op die knop drukt.

If you pressed that button, the engine would stop.

Expected form: **als**

Why: Subordinate connectors. [[Dutch#^nl-Q0255|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=De%20motor%20stopt%20als%20je%20op%20die%20knop%20drukt.)
^nl-Q0255-answer

**nl-Q0256** — De motor stopt als je op die knop drukt.

If you pressed that button, the engine would stop.

Why: Subordinate connectors. [[Dutch#^nl-Q0256|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=De%20motor%20stopt%20als%20je%20op%20die%20knop%20drukt.)
^nl-Q0256-answer

**nl-Q0257** — Hij is fier dat zijn vader een vooraanstaande wetenschapper was.

He is proud that his father was a great scientist.

Why: Subordinate connectors. [[Dutch#^nl-Q0257|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Hij%20is%20fier%20dat%20zijn%20vader%20een%20vooraanstaande%20wetenschapper%20was.)
^nl-Q0257-answer

**nl-Q0258** — Hij is fier dat zijn vader een vooraanstaande wetenschapper was.

He is proud that his father was a great scientist.

Subordinate clauses usually put their verb cluster late. Of can introduce an indirect yes/no question. An ordinary main clause follows verb-second order.

Why: Subordinate connectors. [[Dutch#^nl-Q0258|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Hij%20is%20fier%20dat%20zijn%20vader%20een%20vooraanstaande%20wetenschapper%20was.)
^nl-Q0258-answer

**nl-Q0259** — Ik denk dat Tom en Maria weten wie er in dat huis wonen.

I think Tom and Mary know who live in that house.

Expected form: **dat**

Why: Subordinate connectors. [[Dutch#^nl-Q0259|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20denk%20dat%20Tom%20en%20Maria%20weten%20wie%20er%20in%20dat%20huis%20wonen.)
^nl-Q0259-answer

**nl-Q0260** — Ik denk dat Tom en Maria weten wie er in dat huis wonen.

I think Tom and Mary know who live in that house.

Expected form: **dat**

Why: Subordinate connectors. [[Dutch#^nl-Q0260|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20denk%20dat%20Tom%20en%20Maria%20weten%20wie%20er%20in%20dat%20huis%20wonen.)
^nl-Q0260-answer

**nl-Q0261** — Ik schreef hem dat hij onmiddellijk moest te komen.

I wrote to him to come immediately.

Expected form: **dat**

Why: Subordinate connectors. [[Dutch#^nl-Q0261|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20schreef%20hem%20dat%20hij%20onmiddellijk%20moest%20te%20komen.)
^nl-Q0261-answer

**nl-Q0262** — Ik schreef hem dat hij onmiddellijk moest te komen.

I wrote to him to come immediately.

Why: Subordinate connectors. [[Dutch#^nl-Q0262|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20schreef%20hem%20dat%20hij%20onmiddellijk%20moest%20te%20komen.)
^nl-Q0262-answer

**nl-Q0263** — Ik vind het vreemd dat Alice zich zo lang stil houdt.

I think it strange that Alice should keep silence for such a long time.

Why: Subordinate connectors. [[Dutch#^nl-Q0263|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20vind%20het%20vreemd%20dat%20Alice%20zich%20zo%20lang%20stil%20houdt.)
^nl-Q0263-answer

**nl-Q0264** — Ik vind het vreemd dat Alice zich zo lang stil houdt.

I think it strange that Alice should keep silence for such a long time.

Subordinate clauses usually put their verb cluster late. Of can introduce an indirect yes/no question. An ordinary main clause follows verb-second order.

Why: Subordinate connectors. [[Dutch#^nl-Q0264|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20vind%20het%20vreemd%20dat%20Alice%20zich%20zo%20lang%20stil%20houdt.)
^nl-Q0264-answer

**nl-Q0265** — Hoe zeg je dat in het Engels?

How do you say that in English?

Expected form: **dat**

Why: Subordinate connectors. [[Dutch#^nl-Q0265|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Hoe%20zeg%20je%20dat%20in%20het%20Engels%3F)
^nl-Q0265-answer

**nl-Q0266** — Hoe zeg je dat in het Engels?

How do you say that in English?

Expected form: **dat**

Why: Subordinate connectors. [[Dutch#^nl-Q0266|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Hoe%20zeg%20je%20dat%20in%20het%20Engels%3F)
^nl-Q0266-answer

**nl-Q0267** — Tom zegt dat hij zich helemaal niets ervan herinnert.

Tom says he doesn't remember a thing.

Expected form: **dat**

Why: Subordinate connectors. [[Dutch#^nl-Q0267|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Tom%20zegt%20dat%20hij%20zich%20helemaal%20niets%20ervan%20herinnert.)
^nl-Q0267-answer

**nl-Q0268** — Tom zegt dat hij zich helemaal niets ervan herinnert.

Tom says he doesn't remember a thing.

Why: Subordinate connectors. [[Dutch#^nl-Q0268|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Tom%20zegt%20dat%20hij%20zich%20helemaal%20niets%20ervan%20herinnert.)
^nl-Q0268-answer

**nl-Q0269** — De meeste mensen denken dat.

Most people think so.

Why: Subordinate connectors. [[Dutch#^nl-Q0269|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=De%20meeste%20mensen%20denken%20dat.)
^nl-Q0269-answer

**nl-Q0270** — De meeste mensen denken dat.

Most people think so.

Subordinate clauses usually put their verb cluster late. Of can introduce an indirect yes/no question. An ordinary main clause follows verb-second order.

Why: Subordinate connectors. [[Dutch#^nl-Q0270|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=De%20meeste%20mensen%20denken%20dat.)
^nl-Q0270-answer

**nl-Q0271** — Ik wil dokter worden, of verpleger, of leraar.

I want to be a doctor or a nurse or a teacher.

Expected form: **of**

Why: Subordinate connectors. [[Dutch#^nl-Q0271|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20wil%20dokter%20worden%2C%20of%20verpleger%2C%20of%20leraar.)
^nl-Q0271-answer

**nl-Q0272** — Ik wil dokter worden, of verpleger, of leraar.

I want to be a doctor or a nurse or a teacher.

Expected form: **of**

Why: Subordinate connectors. [[Dutch#^nl-Q0272|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20wil%20dokter%20worden%2C%20of%20verpleger%2C%20of%20leraar.)
^nl-Q0272-answer

**nl-Q0273** — Het probleem met deze film is dat de gevechtsscènes en de humoristische scènes door elkaar gegooid zijn.

The problem with this movie is that the violent scenes and the funny scenes are mixed together.

Expected form: **dat**

Why: Subordinate connectors. [[Dutch#^nl-Q0273|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Het%20probleem%20met%20deze%20film%20is%20dat%20de%20gevechtssc%C3%A8nes%20en%20de%20humoristische%20sc%C3%A8nes%20door%20elkaar%20gegooid%20zijn.)
^nl-Q0273-answer

**nl-Q0274** — Het probleem met deze film is dat de gevechtsscènes en de humoristische scènes door elkaar gegooid zijn.

The problem with this movie is that the violent scenes and the funny scenes are mixed together.

Why: Subordinate connectors. [[Dutch#^nl-Q0274|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Het%20probleem%20met%20deze%20film%20is%20dat%20de%20gevechtssc%C3%A8nes%20en%20de%20humoristische%20sc%C3%A8nes%20door%20elkaar%20gegooid%20zijn.)
^nl-Q0274-answer

**nl-Q0275** — Geef me dat boek.

Give me that book.

Why: Subordinate connectors. [[Dutch#^nl-Q0275|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Geef%20me%20dat%20boek.)
^nl-Q0275-answer

**nl-Q0276** — Geef me dat boek.

Give me that book.

Subordinate clauses usually put their verb cluster late. Of can introduce an indirect yes/no question. An ordinary main clause follows verb-second order.

Why: Subordinate connectors. [[Dutch#^nl-Q0276|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Geef%20me%20dat%20boek.)
^nl-Q0276-answer

**nl-Q0277** — Ik weet dat Tom niet allergisch is voor aardbeien.

I know that Tom isn't allergic to strawberries.

Expected form: **dat**

Why: Subordinate connectors. [[Dutch#^nl-Q0277|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20weet%20dat%20Tom%20niet%20allergisch%20is%20voor%20aardbeien.)
^nl-Q0277-answer

**nl-Q0278** — Ik weet dat Tom niet allergisch is voor aardbeien.

I know that Tom isn't allergic to strawberries.

Expected form: **dat**

Why: Subordinate connectors. [[Dutch#^nl-Q0278|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20weet%20dat%20Tom%20niet%20allergisch%20is%20voor%20aardbeien.)
^nl-Q0278-answer

**nl-Q0279** — Weet Tom dat je komt?

Does Tom know you're coming?

Expected form: **dat**

Why: Subordinate connectors. [[Dutch#^nl-Q0279|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Weet%20Tom%20dat%20je%20komt%3F)
^nl-Q0279-answer

**nl-Q0280** — Weet Tom dat je komt?

Does Tom know you're coming?

Why: Subordinate connectors. [[Dutch#^nl-Q0280|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Weet%20Tom%20dat%20je%20komt%3F)
^nl-Q0280-answer

**nl-Q0281** — Ik weet dat je geen dokter bent.

I know you're not a doctor.

Why: Subordinate connectors. [[Dutch#^nl-Q0281|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20weet%20dat%20je%20geen%20dokter%20bent.)
^nl-Q0281-answer

**nl-Q0282** — Ik weet dat je geen dokter bent.

I know you're not a doctor.

Subordinate clauses usually put their verb cluster late. Of can introduce an indirect yes/no question. An ordinary main clause follows verb-second order.

Why: Subordinate connectors. [[Dutch#^nl-Q0282|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20weet%20dat%20je%20geen%20dokter%20bent.)
^nl-Q0282-answer

**nl-Q0283** — Wanneer hebt u voor het laatst heroïne of methadon gebruikt?

When was the last time you used heroin or methadone?

Expected form: **of**

Why: Subordinate connectors. [[Dutch#^nl-Q0283|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Wanneer%20hebt%20u%20voor%20het%20laatst%20hero%C3%AFne%20of%20methadon%20gebruikt%3F)
^nl-Q0283-answer

**nl-Q0284** — Wanneer hebt u voor het laatst heroïne of methadon gebruikt?

When was the last time you used heroin or methadone?

Expected form: **of**

Why: Subordinate connectors. [[Dutch#^nl-Q0284|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Wanneer%20hebt%20u%20voor%20het%20laatst%20hero%C3%AFne%20of%20methadon%20gebruikt%3F)
^nl-Q0284-answer

**nl-Q0285** — Waar heeft ze dat boek gekocht?

Where did she buy that book?

Expected form: **dat**

Why: Subordinate connectors. [[Dutch#^nl-Q0285|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Waar%20heeft%20ze%20dat%20boek%20gekocht%3F)
^nl-Q0285-answer

**nl-Q0286** — Waar heeft ze dat boek gekocht?

Where did she buy that book?

Why: Subordinate connectors. [[Dutch#^nl-Q0286|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Waar%20heeft%20ze%20dat%20boek%20gekocht%3F)
^nl-Q0286-answer

**nl-Q0287** — Eet dat brood!

Eat that bread!

Why: Subordinate connectors. [[Dutch#^nl-Q0287|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Eet%20dat%20brood%21)
^nl-Q0287-answer

**nl-Q0288** — Eet dat brood!

Eat that bread!

Subordinate clauses usually put their verb cluster late. Of can introduce an indirect yes/no question. An ordinary main clause follows verb-second order.

Why: Subordinate connectors. [[Dutch#^nl-Q0288|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Eet%20dat%20brood%21)
^nl-Q0288-answer

**nl-Q0289** — Ik wist niet dat jij hobo speelde.

I didn't know you played the oboe.

Expected form: **dat**

Why: Subordinate connectors. [[Dutch#^nl-Q0289|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20wist%20niet%20dat%20jij%20hobo%20speelde.)
^nl-Q0289-answer

**nl-Q0290** — Ik wist niet dat jij hobo speelde.

I didn't know you played the oboe.

Expected form: **dat**

Why: Subordinate connectors. [[Dutch#^nl-Q0290|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20wist%20niet%20dat%20jij%20hobo%20speelde.)
^nl-Q0290-answer

**nl-Q0291** — Er is een mogelijkheid dat we de fabriek niet hoeven te sluiten.

There is a possibility that we won't have to shut down the factory.

Expected form: **dat**

Why: Subordinate connectors. [[Dutch#^nl-Q0291|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Er%20is%20een%20mogelijkheid%20dat%20we%20de%20fabriek%20niet%20hoeven%20te%20sluiten.)
^nl-Q0291-answer

**nl-Q0292** — Er is een mogelijkheid dat we de fabriek niet hoeven te sluiten.

There is a possibility that we won't have to shut down the factory.

Why: Subordinate connectors. [[Dutch#^nl-Q0292|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Er%20is%20een%20mogelijkheid%20dat%20we%20de%20fabriek%20niet%20hoeven%20te%20sluiten.)
^nl-Q0292-answer

**nl-Q0293** — Ik heb besloten hem te zeggen dat ik van haar hou.

I decided to tell him that I love her.

Why: Subordinate connectors. [[Dutch#^nl-Q0293|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20heb%20besloten%20hem%20te%20zeggen%20dat%20ik%20van%20haar%20hou.)
^nl-Q0293-answer

**nl-Q0294** — Ik heb besloten hem te zeggen dat ik van haar hou.

I decided to tell him that I love her.

Subordinate clauses usually put their verb cluster late. Of can introduce an indirect yes/no question. An ordinary main clause follows verb-second order.

Why: Subordinate connectors. [[Dutch#^nl-Q0294|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20heb%20besloten%20hem%20te%20zeggen%20dat%20ik%20van%20haar%20hou.)
^nl-Q0294-answer

**nl-Q0295** — Heb je liever katten of honden?

Do you prefer cats or dogs?

Expected form: **of**

Why: Subordinate connectors. [[Dutch#^nl-Q0295|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Heb%20je%20liever%20katten%20of%20honden%3F)
^nl-Q0295-answer

**nl-Q0296** — Heb je liever katten of honden?

Do you prefer cats or dogs?

Expected form: **of**

Why: Subordinate connectors. [[Dutch#^nl-Q0296|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Heb%20je%20liever%20katten%20of%20honden%3F)
^nl-Q0296-answer

**nl-Q0297** — Als een vrouw met overgewicht heeft Mary veel ervaring met mensen die over haar oordelen wegens haar omvang.

As an overweight woman, Mary has experienced many incidents of people judging her based on her size.

Expected form: **Als**

Why: Subordinate connectors. [[Dutch#^nl-Q0297|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Als%20een%20vrouw%20met%20overgewicht%20heeft%20Mary%20veel%20ervaring%20met%20mensen%20die%20over%20haar%20oordelen%20wegens%20haar%20omvang.)
^nl-Q0297-answer

**nl-Q0298** — Als een vrouw met overgewicht heeft Mary veel ervaring met mensen die over haar oordelen wegens haar omvang.

As an overweight woman, Mary has experienced many incidents of people judging her based on her size.

Why: Subordinate connectors. [[Dutch#^nl-Q0298|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Als%20een%20vrouw%20met%20overgewicht%20heeft%20Mary%20veel%20ervaring%20met%20mensen%20die%20over%20haar%20oordelen%20wegens%20haar%20omvang.)
^nl-Q0298-answer

**nl-Q0299** — Weet je zeker dat je op de goede knop hebt gedrukt?

Are you sure you pressed the right button?

Why: Subordinate connectors. [[Dutch#^nl-Q0299|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Weet%20je%20zeker%20dat%20je%20op%20de%20goede%20knop%20hebt%20gedrukt%3F)
^nl-Q0299-answer

**nl-Q0300** — Weet je zeker dat je op de goede knop hebt gedrukt?

Are you sure you pressed the right button?

Subordinate clauses usually put their verb cluster late. Of can introduce an indirect yes/no question. An ordinary main clause follows verb-second order.

Why: Subordinate connectors. [[Dutch#^nl-Q0300|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Weet%20je%20zeker%20dat%20je%20op%20de%20goede%20knop%20hebt%20gedrukt%3F)
^nl-Q0300-answer


### Answers 301–350

**nl-Q0301** — Om het even wat ze eet, ze verdikt niet.

However much she eats, she never gains weight.

Expected form: **niet**

Why: Negation. [[Dutch#^nl-Q0301|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Om%20het%20even%20wat%20ze%20eet%2C%20ze%20verdikt%20niet.)
^nl-Q0301-answer

**nl-Q0302** — Om het even wat ze eet, ze verdikt niet.

However much she eats, she never gains weight.

Expected form: **niet**

Why: Negation. [[Dutch#^nl-Q0302|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Om%20het%20even%20wat%20ze%20eet%2C%20ze%20verdikt%20niet.)
^nl-Q0302-answer

**nl-Q0303** — Ik wil niet slapen.

I don't want to sleep.

Expected form: **niet**

Why: Negation. [[Dutch#^nl-Q0303|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20wil%20niet%20slapen.)
^nl-Q0303-answer

**nl-Q0304** — Ik wil niet slapen.

I don't want to sleep.

Why: Negation. [[Dutch#^nl-Q0304|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20wil%20niet%20slapen.)
^nl-Q0304-answer

**nl-Q0305** — Hij is duidelijk niet zo'n soort persoon.

Obviously, he's not that kind of person.

Why: Negation. [[Dutch#^nl-Q0305|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Hij%20is%20duidelijk%20niet%20zo%27n%20soort%20persoon.)
^nl-Q0305-answer

**nl-Q0306** — Hij is duidelijk niet zo'n soort persoon.

Obviously, he's not that kind of person.

Geen negates many indefinite noun phrases; niet negates a predicate or other constituent. Niet placement controls which part is negated.

Why: Negation. [[Dutch#^nl-Q0306|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Hij%20is%20duidelijk%20niet%20zo%27n%20soort%20persoon.)
^nl-Q0306-answer

**nl-Q0307** — We willen geen mensen zoals jij in deze stad.

We don't want people like you in this town.

Expected form: **geen**

Why: Negation. [[Dutch#^nl-Q0307|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=We%20willen%20geen%20mensen%20zoals%20jij%20in%20deze%20stad.)
^nl-Q0307-answer

**nl-Q0308** — We willen geen mensen zoals jij in deze stad.

We don't want people like you in this town.

Expected form: **geen**

Why: Negation. [[Dutch#^nl-Q0308|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=We%20willen%20geen%20mensen%20zoals%20jij%20in%20deze%20stad.)
^nl-Q0308-answer

**nl-Q0309** — Ze waren niet gewaarschuwd voor de vloedgolf.

They weren't warned of the tidal wave.

Expected form: **niet**

Why: Negation. [[Dutch#^nl-Q0309|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ze%20waren%20niet%20gewaarschuwd%20voor%20de%20vloedgolf.)
^nl-Q0309-answer

**nl-Q0310** — Ze waren niet gewaarschuwd voor de vloedgolf.

They weren't warned of the tidal wave.

Why: Negation. [[Dutch#^nl-Q0310|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ze%20waren%20niet%20gewaarschuwd%20voor%20de%20vloedgolf.)
^nl-Q0310-answer

**nl-Q0311** — Ik kan Tom niet gelukkig maken.

I can't make Tom happy.

Why: Negation. [[Dutch#^nl-Q0311|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20kan%20Tom%20niet%20gelukkig%20maken.)
^nl-Q0311-answer

**nl-Q0312** — Ik kan Tom niet gelukkig maken.

I can't make Tom happy.

Geen negates many indefinite noun phrases; niet negates a predicate or other constituent. Niet placement controls which part is negated.

Why: Negation. [[Dutch#^nl-Q0312|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20kan%20Tom%20niet%20gelukkig%20maken.)
^nl-Q0312-answer

**nl-Q0313** — Schrijf met een pen, niet met een potlood.

Write with a pen, not with a pencil.

Expected form: **niet**

Why: Negation. [[Dutch#^nl-Q0313|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Schrijf%20met%20een%20pen%2C%20niet%20met%20een%20potlood.)
^nl-Q0313-answer

**nl-Q0314** — Schrijf met een pen, niet met een potlood.

Write with a pen, not with a pencil.

Expected form: **niet**

Why: Negation. [[Dutch#^nl-Q0314|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Schrijf%20met%20een%20pen%2C%20niet%20met%20een%20potlood.)
^nl-Q0314-answer

**nl-Q0315** — 3 percent van de bevolking wil niet meer eten.

3% of the population doesn't want to eat anymore.

Expected form: **niet**

Why: Negation. [[Dutch#^nl-Q0315|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=3%20percent%20van%20de%20bevolking%20wil%20niet%20meer%20eten.)
^nl-Q0315-answer

**nl-Q0316** — 3 percent van de bevolking wil niet meer eten.

3% of the population doesn't want to eat anymore.

Why: Negation. [[Dutch#^nl-Q0316|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=3%20percent%20van%20de%20bevolking%20wil%20niet%20meer%20eten.)
^nl-Q0316-answer

**nl-Q0317** — Ik kan het niet meer uithouden.

I cannot stand this anymore.

Why: Negation. [[Dutch#^nl-Q0317|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20kan%20het%20niet%20meer%20uithouden.)
^nl-Q0317-answer

**nl-Q0318** — Ik kan het niet meer uithouden.

I cannot stand this anymore.

Geen negates many indefinite noun phrases; niet negates a predicate or other constituent. Niet placement controls which part is negated.

Why: Negation. [[Dutch#^nl-Q0318|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20kan%20het%20niet%20meer%20uithouden.)
^nl-Q0318-answer

**nl-Q0319** — Je weet daar niet toevallig iets van, toch?

You wouldn't know anything about that, would you?

Expected form: **niet**

Why: Negation. [[Dutch#^nl-Q0319|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Je%20weet%20daar%20niet%20toevallig%20iets%20van%2C%20toch%3F)
^nl-Q0319-answer

**nl-Q0320** — Je weet daar niet toevallig iets van, toch?

You wouldn't know anything about that, would you?

Expected form: **niet**

Why: Negation. [[Dutch#^nl-Q0320|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Je%20weet%20daar%20niet%20toevallig%20iets%20van%2C%20toch%3F)
^nl-Q0320-answer

**nl-Q0321** — Hij woont niet in Sendai.

He does not live in Sendai.

Expected form: **niet**

Why: Negation. [[Dutch#^nl-Q0321|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Hij%20woont%20niet%20in%20Sendai.)
^nl-Q0321-answer

**nl-Q0322** — Hij woont niet in Sendai.

He does not live in Sendai.

Why: Negation. [[Dutch#^nl-Q0322|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Hij%20woont%20niet%20in%20Sendai.)
^nl-Q0322-answer

**nl-Q0323** — Ik heb het bestand nog niet gedownload.

I have not yet downloaded the file.

Why: Negation. [[Dutch#^nl-Q0323|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20heb%20het%20bestand%20nog%20niet%20gedownload.)
^nl-Q0323-answer

**nl-Q0324** — Ik heb het bestand nog niet gedownload.

I have not yet downloaded the file.

Geen negates many indefinite noun phrases; niet negates a predicate or other constituent. Niet placement controls which part is negated.

Why: Negation. [[Dutch#^nl-Q0324|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20heb%20het%20bestand%20nog%20niet%20gedownload.)
^nl-Q0324-answer

**nl-Q0325** — Ik had geen keuze.

I had no alternative.

Expected form: **geen**

Why: Negation. [[Dutch#^nl-Q0325|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20had%20geen%20keuze.)
^nl-Q0325-answer

**nl-Q0326** — Ik had geen keuze.

I had no alternative.

Expected form: **geen**

Why: Negation. [[Dutch#^nl-Q0326|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20had%20geen%20keuze.)
^nl-Q0326-answer

**nl-Q0327** — Ik ga niet op hem wachten.

I'm not going to wait for him.

Expected form: **niet**

Why: Negation. [[Dutch#^nl-Q0327|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20ga%20niet%20op%20hem%20wachten.)
^nl-Q0327-answer

**nl-Q0328** — Ik ga niet op hem wachten.

I'm not going to wait for him.

Why: Negation. [[Dutch#^nl-Q0328|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20ga%20niet%20op%20hem%20wachten.)
^nl-Q0328-answer

**nl-Q0329** — De klok klopt niet.

The clock is wrong.

Why: Negation. [[Dutch#^nl-Q0329|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=De%20klok%20klopt%20niet.)
^nl-Q0329-answer

**nl-Q0330** — De klok klopt niet.

The clock is wrong.

Geen negates many indefinite noun phrases; niet negates a predicate or other constituent. Niet placement controls which part is negated.

Why: Negation. [[Dutch#^nl-Q0330|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=De%20klok%20klopt%20niet.)
^nl-Q0330-answer

**nl-Q0331** — Ik moet geen preek hebben.

I don't need a lecture.

Expected form: **geen**

Why: Negation. [[Dutch#^nl-Q0331|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20moet%20geen%20preek%20hebben.)
^nl-Q0331-answer

**nl-Q0332** — Ik moet geen preek hebben.

I don't need a lecture.

Expected form: **geen**

Why: Negation. [[Dutch#^nl-Q0332|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20moet%20geen%20preek%20hebben.)
^nl-Q0332-answer

**nl-Q0333** — Er zijn geen gele brievenbussen in Denemarken.

In Denmark, there aren't any yellow postboxes.

Expected form: **geen**

Why: Negation. [[Dutch#^nl-Q0333|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Er%20zijn%20geen%20gele%20brievenbussen%20in%20Denemarken.)
^nl-Q0333-answer

**nl-Q0334** — Er zijn geen gele brievenbussen in Denemarken.

In Denmark, there aren't any yellow postboxes.

Why: Negation. [[Dutch#^nl-Q0334|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Er%20zijn%20geen%20gele%20brievenbussen%20in%20Denemarken.)
^nl-Q0334-answer

**nl-Q0335** — Ik weet niet wat we gaan doen.

I don't know what we'll do.

Why: Negation. [[Dutch#^nl-Q0335|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20weet%20niet%20wat%20we%20gaan%20doen.)
^nl-Q0335-answer

**nl-Q0336** — Ik weet niet wat we gaan doen.

I don't know what we'll do.

Geen negates many indefinite noun phrases; niet negates a predicate or other constituent. Niet placement controls which part is negated.

Why: Negation. [[Dutch#^nl-Q0336|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20weet%20niet%20wat%20we%20gaan%20doen.)
^nl-Q0336-answer

**nl-Q0337** — Je mag niet naar de stad gaan.

You can't go to town.

Expected form: **niet**

Why: Negation. [[Dutch#^nl-Q0337|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Je%20mag%20niet%20naar%20de%20stad%20gaan.)
^nl-Q0337-answer

**nl-Q0338** — Je mag niet naar de stad gaan.

You can't go to town.

Expected form: **niet**

Why: Negation. [[Dutch#^nl-Q0338|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Je%20mag%20niet%20naar%20de%20stad%20gaan.)
^nl-Q0338-answer

**nl-Q0339** — Tom heeft gisteren geen pizza gegeten.

Tom didn't eat pizza yesterday.

Expected form: **geen**

Why: Negation. [[Dutch#^nl-Q0339|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Tom%20heeft%20gisteren%20geen%20pizza%20gegeten.)
^nl-Q0339-answer

**nl-Q0340** — Tom heeft gisteren geen pizza gegeten.

Tom didn't eat pizza yesterday.

Why: Negation. [[Dutch#^nl-Q0340|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Tom%20heeft%20gisteren%20geen%20pizza%20gegeten.)
^nl-Q0340-answer

**nl-Q0341** — Zijn zuster kan vandaag niet met u spreken.

His sister can't talk to you today.

Why: Negation. [[Dutch#^nl-Q0341|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Zijn%20zuster%20kan%20vandaag%20niet%20met%20u%20spreken.)
^nl-Q0341-answer

**nl-Q0342** — Zijn zuster kan vandaag niet met u spreken.

His sister can't talk to you today.

Geen negates many indefinite noun phrases; niet negates a predicate or other constituent. Niet placement controls which part is negated.

Why: Negation. [[Dutch#^nl-Q0342|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Zijn%20zuster%20kan%20vandaag%20niet%20met%20u%20spreken.)
^nl-Q0342-answer

**nl-Q0343** — Ze werken niet eens een beetje.

They are not working even a bit.

Expected form: **niet**

Why: Negation. [[Dutch#^nl-Q0343|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ze%20werken%20niet%20eens%20een%20beetje.)
^nl-Q0343-answer

**nl-Q0344** — Ze werken niet eens een beetje.

They are not working even a bit.

Expected form: **niet**

Why: Negation. [[Dutch#^nl-Q0344|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ze%20werken%20niet%20eens%20een%20beetje.)
^nl-Q0344-answer

**nl-Q0345** — We willen niet dat hij gewond raakt.

We don't want him to get hurt.

Expected form: **niet**

Why: Negation. [[Dutch#^nl-Q0345|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=We%20willen%20niet%20dat%20hij%20gewond%20raakt.)
^nl-Q0345-answer

**nl-Q0346** — We willen niet dat hij gewond raakt.

We don't want him to get hurt.

Why: Negation. [[Dutch#^nl-Q0346|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=We%20willen%20niet%20dat%20hij%20gewond%20raakt.)
^nl-Q0346-answer

**nl-Q0347** — Hij kwam niet. Zijn excuus was dat hij ziek was.

He didn't come. His excuse was that he was sick.

Why: Negation. [[Dutch#^nl-Q0347|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Hij%20kwam%20niet.%20Zijn%20excuus%20was%20dat%20hij%20ziek%20was.)
^nl-Q0347-answer

**nl-Q0348** — Hij kwam niet. Zijn excuus was dat hij ziek was.

He didn't come. His excuse was that he was sick.

Geen negates many indefinite noun phrases; niet negates a predicate or other constituent. Niet placement controls which part is negated.

Why: Negation. [[Dutch#^nl-Q0348|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Hij%20kwam%20niet.%20Zijn%20excuus%20was%20dat%20hij%20ziek%20was.)
^nl-Q0348-answer

**nl-Q0349** — Ik mag hem niet meer.

I don't like him anymore.

Expected form: **niet**

Why: Negation. [[Dutch#^nl-Q0349|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20mag%20hem%20niet%20meer.)
^nl-Q0349-answer

**nl-Q0350** — Ik mag hem niet meer.

I don't like him anymore.

Expected form: **niet**

Why: Negation. [[Dutch#^nl-Q0350|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20mag%20hem%20niet%20meer.)
^nl-Q0350-answer


### Answers 351–400

**nl-Q0351** — De tijd zal het zeggen.

Time will tell.

Expected form: **zal**

Why: Modal verbs. [[Dutch#^nl-Q0351|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=De%20tijd%20zal%20het%20zeggen.)
^nl-Q0351-answer

**nl-Q0352** — De tijd zal het zeggen.

Time will tell.

Why: Modal verbs. [[Dutch#^nl-Q0352|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=De%20tijd%20zal%20het%20zeggen.)
^nl-Q0352-answer

**nl-Q0353** — Ja, ik kan.

Yes, I can.

Why: Modal verbs. [[Dutch#^nl-Q0353|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ja%2C%20ik%20kan.)
^nl-Q0353-answer

**nl-Q0354** — Ja, ik kan.

Yes, I can.

Modals govern an infinitive and express ability, obligation, permission, desire or prediction. The finite modal occupies the normal finite-verb position; the infinitive commonly stands late.

Why: Modal verbs. [[Dutch#^nl-Q0354|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ja%2C%20ik%20kan.)
^nl-Q0354-answer

**nl-Q0355** — Wat wil je?

What do you want?

Expected form: **wil**

Why: Modal verbs. [[Dutch#^nl-Q0355|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Wat%20wil%20je%3F)
^nl-Q0355-answer

**nl-Q0356** — Wat wil je?

What do you want?

Expected form: **wil**

Why: Modal verbs. [[Dutch#^nl-Q0356|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Wat%20wil%20je%3F)
^nl-Q0356-answer

**nl-Q0357** — Mijnheer, mag ik uw rijbewijs zien?

May I see your driver's license, sir?

Expected form: **mag**

Why: Modal verbs. [[Dutch#^nl-Q0357|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Mijnheer%2C%20mag%20ik%20uw%20rijbewijs%20zien%3F)
^nl-Q0357-answer

**nl-Q0358** — Mijnheer, mag ik uw rijbewijs zien?

May I see your driver's license, sir?

Why: Modal verbs. [[Dutch#^nl-Q0358|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Mijnheer%2C%20mag%20ik%20uw%20rijbewijs%20zien%3F)
^nl-Q0358-answer

**nl-Q0359** — We kunnen ons nadeel in ons voordeel veranderen.

We can change our disadvantage to our advantage.

Why: Modal verbs. [[Dutch#^nl-Q0359|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=We%20kunnen%20ons%20nadeel%20in%20ons%20voordeel%20veranderen.)
^nl-Q0359-answer

**nl-Q0360** — We kunnen ons nadeel in ons voordeel veranderen.

We can change our disadvantage to our advantage.

Modals govern an infinitive and express ability, obligation, permission, desire or prediction. The finite modal occupies the normal finite-verb position; the infinitive commonly stands late.

Why: Modal verbs. [[Dutch#^nl-Q0360|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=We%20kunnen%20ons%20nadeel%20in%20ons%20voordeel%20veranderen.)
^nl-Q0360-answer

**nl-Q0361** — Maria kan zo'n aansteller zijn.

Mary can be such a drama queen.

Expected form: **kan**

Why: Modal verbs. [[Dutch#^nl-Q0361|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Maria%20kan%20zo%27n%20aansteller%20zijn.)
^nl-Q0361-answer

**nl-Q0362** — Maria kan zo'n aansteller zijn.

Mary can be such a drama queen.

Expected form: **kan**

Why: Modal verbs. [[Dutch#^nl-Q0362|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Maria%20kan%20zo%27n%20aansteller%20zijn.)
^nl-Q0362-answer

**nl-Q0363** — Men moet zijn plichten vervullen.

One should do one's duties.

Expected form: **moet**

Why: Modal verbs. [[Dutch#^nl-Q0363|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Men%20moet%20zijn%20plichten%20vervullen.)
^nl-Q0363-answer

**nl-Q0364** — Men moet zijn plichten vervullen.

One should do one's duties.

Why: Modal verbs. [[Dutch#^nl-Q0364|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Men%20moet%20zijn%20plichten%20vervullen.)
^nl-Q0364-answer

**nl-Q0365** — Kan ik jullie toevoegen op Facebook?

Can I add you on Facebook?

Why: Modal verbs. [[Dutch#^nl-Q0365|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Kan%20ik%20jullie%20toevoegen%20op%20Facebook%3F)
^nl-Q0365-answer

**nl-Q0366** — Kan ik jullie toevoegen op Facebook?

Can I add you on Facebook?

Modals govern an infinitive and express ability, obligation, permission, desire or prediction. The finite modal occupies the normal finite-verb position; the infinitive commonly stands late.

Why: Modal verbs. [[Dutch#^nl-Q0366|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Kan%20ik%20jullie%20toevoegen%20op%20Facebook%3F)
^nl-Q0366-answer

**nl-Q0367** — Het spijt me. Ik moet weg.

Excuse me. I need to go.

Expected form: **moet**

Why: Modal verbs. [[Dutch#^nl-Q0367|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Het%20spijt%20me.%20Ik%20moet%20weg.)
^nl-Q0367-answer

**nl-Q0368** — Het spijt me. Ik moet weg.

Excuse me. I need to go.

Expected form: **moet**

Why: Modal verbs. [[Dutch#^nl-Q0368|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Het%20spijt%20me.%20Ik%20moet%20weg.)
^nl-Q0368-answer

**nl-Q0369** — Wil je wat sinaasappelsap?

Would you like some orange juice?

Expected form: **Wil**

Why: Modal verbs. [[Dutch#^nl-Q0369|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Wil%20je%20wat%20sinaasappelsap%3F)
^nl-Q0369-answer

**nl-Q0370** — Wil je wat sinaasappelsap?

Would you like some orange juice?

Why: Modal verbs. [[Dutch#^nl-Q0370|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Wil%20je%20wat%20sinaasappelsap%3F)
^nl-Q0370-answer

**nl-Q0371** — Ik zal u bellen binnen de week.

I'll call you within a week.

Why: Modal verbs. [[Dutch#^nl-Q0371|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20zal%20u%20bellen%20binnen%20de%20week.)
^nl-Q0371-answer

**nl-Q0372** — Ik zal u bellen binnen de week.

I'll call you within a week.

Modals govern an infinitive and express ability, obligation, permission, desire or prediction. The finite modal occupies the normal finite-verb position; the infinitive commonly stands late.

Why: Modal verbs. [[Dutch#^nl-Q0372|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20zal%20u%20bellen%20binnen%20de%20week.)
^nl-Q0372-answer

**nl-Q0373** — Men kan deze zin op twee manieren interpreteren.

This sentence can be interpreted in two ways.

Expected form: **kan**

Why: Modal verbs. [[Dutch#^nl-Q0373|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Men%20kan%20deze%20zin%20op%20twee%20manieren%20interpreteren.)
^nl-Q0373-answer

**nl-Q0374** — Men kan deze zin op twee manieren interpreteren.

This sentence can be interpreted in two ways.

Expected form: **kan**

Why: Modal verbs. [[Dutch#^nl-Q0374|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Men%20kan%20deze%20zin%20op%20twee%20manieren%20interpreteren.)
^nl-Q0374-answer

**nl-Q0375** — We moeten handelen.

We have to act.

Expected form: **moeten**

Why: Modal verbs. [[Dutch#^nl-Q0375|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=We%20moeten%20handelen.)
^nl-Q0375-answer

**nl-Q0376** — We moeten handelen.

We have to act.

Why: Modal verbs. [[Dutch#^nl-Q0376|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=We%20moeten%20handelen.)
^nl-Q0376-answer

**nl-Q0377** — Ik moet rusten.

I must rest.

Why: Modal verbs. [[Dutch#^nl-Q0377|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20moet%20rusten.)
^nl-Q0377-answer

**nl-Q0378** — Ik moet rusten.

I must rest.

Modals govern an infinitive and express ability, obligation, permission, desire or prediction. The finite modal occupies the normal finite-verb position; the infinitive commonly stands late.

Why: Modal verbs. [[Dutch#^nl-Q0378|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20moet%20rusten.)
^nl-Q0378-answer

**nl-Q0379** — Hé, kijk eens wat ik kan!

Hey, look what I can do!

Expected form: **kan**

Why: Modal verbs. [[Dutch#^nl-Q0379|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=H%C3%A9%2C%20kijk%20eens%20wat%20ik%20kan%21)
^nl-Q0379-answer

**nl-Q0380** — Hé, kijk eens wat ik kan!

Hey, look what I can do!

Expected form: **kan**

Why: Modal verbs. [[Dutch#^nl-Q0380|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=H%C3%A9%2C%20kijk%20eens%20wat%20ik%20kan%21)
^nl-Q0380-answer

**nl-Q0381** — Ik wil je nooit meer zien.

I don't ever want to see you again.

Expected form: **wil**

Why: Modal verbs. [[Dutch#^nl-Q0381|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20wil%20je%20nooit%20meer%20zien.)
^nl-Q0381-answer

**nl-Q0382** — Ik wil je nooit meer zien.

I don't ever want to see you again.

Why: Modal verbs. [[Dutch#^nl-Q0382|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20wil%20je%20nooit%20meer%20zien.)
^nl-Q0382-answer

**nl-Q0383** — Tom moet voorzichtiger zijn.

Tom needs to be more careful.

Why: Modal verbs. [[Dutch#^nl-Q0383|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Tom%20moet%20voorzichtiger%20zijn.)
^nl-Q0383-answer

**nl-Q0384** — Tom moet voorzichtiger zijn.

Tom needs to be more careful.

Modals govern an infinitive and express ability, obligation, permission, desire or prediction. The finite modal occupies the normal finite-verb position; the infinitive commonly stands late.

Why: Modal verbs. [[Dutch#^nl-Q0384|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Tom%20moet%20voorzichtiger%20zijn.)
^nl-Q0384-answer

**nl-Q0385** — Hoe kan ik Vlaamse Gebarentaal leren?

How can I learn Flemish Sign Language?

Expected form: **kan**

Why: Modal verbs. [[Dutch#^nl-Q0385|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Hoe%20kan%20ik%20Vlaamse%20Gebarentaal%20leren%3F)
^nl-Q0385-answer

**nl-Q0386** — Hoe kan ik Vlaamse Gebarentaal leren?

How can I learn Flemish Sign Language?

Expected form: **kan**

Why: Modal verbs. [[Dutch#^nl-Q0386|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Hoe%20kan%20ik%20Vlaamse%20Gebarentaal%20leren%3F)
^nl-Q0386-answer

**nl-Q0387** — Wanneer jullie naar Roemenië gaan, zullen jullie het Kasteel van Dracula bezoeken.

When you go to Romania, you will visit Dracula's Castle.

Expected form: **zullen**

Why: Modal verbs. [[Dutch#^nl-Q0387|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Wanneer%20jullie%20naar%20Roemeni%C3%AB%20gaan%2C%20zullen%20jullie%20het%20Kasteel%20van%20Dracula%20bezoeken.)
^nl-Q0387-answer

**nl-Q0388** — Wanneer jullie naar Roemenië gaan, zullen jullie het Kasteel van Dracula bezoeken.

When you go to Romania, you will visit Dracula's Castle.

Why: Modal verbs. [[Dutch#^nl-Q0388|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Wanneer%20jullie%20naar%20Roemeni%C3%AB%20gaan%2C%20zullen%20jullie%20het%20Kasteel%20van%20Dracula%20bezoeken.)
^nl-Q0388-answer

**nl-Q0389** — Ik kan het nog steeds.

I still got it.

Why: Modal verbs. [[Dutch#^nl-Q0389|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20kan%20het%20nog%20steeds.)
^nl-Q0389-answer

**nl-Q0390** — Ik kan het nog steeds.

I still got it.

Modals govern an infinitive and express ability, obligation, permission, desire or prediction. The finite modal occupies the normal finite-verb position; the infinitive commonly stands late.

Why: Modal verbs. [[Dutch#^nl-Q0390|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20kan%20het%20nog%20steeds.)
^nl-Q0390-answer

**nl-Q0391** — Ik ben maar een immigrant die de Engelse taal wil beschermen tegen zijn moedertaalsprekers.

I'm only an immigrant trying to protect the English language from its native speakers.

Expected form: **wil**

Why: Modal verbs. [[Dutch#^nl-Q0391|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20ben%20maar%20een%20immigrant%20die%20de%20Engelse%20taal%20wil%20beschermen%20tegen%20zijn%20moedertaalsprekers.)
^nl-Q0391-answer

**nl-Q0392** — Ik ben maar een immigrant die de Engelse taal wil beschermen tegen zijn moedertaalsprekers.

I'm only an immigrant trying to protect the English language from its native speakers.

Expected form: **wil**

Why: Modal verbs. [[Dutch#^nl-Q0392|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20ben%20maar%20een%20immigrant%20die%20de%20Engelse%20taal%20wil%20beschermen%20tegen%20zijn%20moedertaalsprekers.)
^nl-Q0392-answer

**nl-Q0393** — Waar een wil is, is een weg.

Where there's a will, there's a way.

Expected form: **wil**

Why: Modal verbs. [[Dutch#^nl-Q0393|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Waar%20een%20wil%20is%2C%20is%20een%20weg.)
^nl-Q0393-answer

**nl-Q0394** — Waar een wil is, is een weg.

Where there's a will, there's a way.

Why: Modal verbs. [[Dutch#^nl-Q0394|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Waar%20een%20wil%20is%2C%20is%20een%20weg.)
^nl-Q0394-answer

**nl-Q0395** — Zullen we dit bespreken onder een kop koffie?

Shall we talk about it over a cup of coffee?

Why: Modal verbs. [[Dutch#^nl-Q0395|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Zullen%20we%20dit%20bespreken%20onder%20een%20kop%20koffie%3F)
^nl-Q0395-answer

**nl-Q0396** — Zullen we dit bespreken onder een kop koffie?

Shall we talk about it over a cup of coffee?

Modals govern an infinitive and express ability, obligation, permission, desire or prediction. The finite modal occupies the normal finite-verb position; the infinitive commonly stands late.

Why: Modal verbs. [[Dutch#^nl-Q0396|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Zullen%20we%20dit%20bespreken%20onder%20een%20kop%20koffie%3F)
^nl-Q0396-answer

**nl-Q0397** — Mag ik vragen hoe je heet?

May I ask your name?

Expected form: **Mag**

Why: Modal verbs. [[Dutch#^nl-Q0397|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Mag%20ik%20vragen%20hoe%20je%20heet%3F)
^nl-Q0397-answer

**nl-Q0398** — Mag ik vragen hoe je heet?

May I ask your name?

Expected form: **Mag**

Why: Modal verbs. [[Dutch#^nl-Q0398|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Mag%20ik%20vragen%20hoe%20je%20heet%3F)
^nl-Q0398-answer

**nl-Q0399** — Ik ben zo moe dat ik nauwelijks kan lopen.

I am so tired that I can hardly walk.

Expected form: **kan**

Why: Modal verbs. [[Dutch#^nl-Q0399|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20ben%20zo%20moe%20dat%20ik%20nauwelijks%20kan%20lopen.)
^nl-Q0399-answer

**nl-Q0400** — Ik ben zo moe dat ik nauwelijks kan lopen.

I am so tired that I can hardly walk.

Why: Modal verbs. [[Dutch#^nl-Q0400|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20ben%20zo%20moe%20dat%20ik%20nauwelijks%20kan%20lopen.)
^nl-Q0400-answer


### Answers 401–450

**nl-Q0401** — De Romeinse troepen waren uitgeput.

The Roman troops were exhausted.

Why: Past zijn and hebben. [[Dutch#^nl-Q0401|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=De%20Romeinse%20troepen%20waren%20uitgeput.)
^nl-Q0401-answer

**nl-Q0402** — De Romeinse troepen waren uitgeput.

The Roman troops were exhausted.

Was/waren and had/hadden are common past forms. They can be main verbs or auxiliaries; a later participle determines whether a pluperfect construction is present.

Why: Past zijn and hebben. [[Dutch#^nl-Q0402|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=De%20Romeinse%20troepen%20waren%20uitgeput.)
^nl-Q0402-answer

**nl-Q0403** — Hoe was je biologie-examen?

How was your biology exam?

Expected form: **was**

Why: Past zijn and hebben. [[Dutch#^nl-Q0403|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Hoe%20was%20je%20biologie-examen%3F)
^nl-Q0403-answer

**nl-Q0404** — Hoe was je biologie-examen?

How was your biology exam?

Expected form: **was**

Why: Past zijn and hebben. [[Dutch#^nl-Q0404|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Hoe%20was%20je%20biologie-examen%3F)
^nl-Q0404-answer

**nl-Q0405** — Ik was zeer trots.

I was very proud.

Expected form: **was**

Why: Past zijn and hebben. [[Dutch#^nl-Q0405|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20was%20zeer%20trots.)
^nl-Q0405-answer

**nl-Q0406** — Ik was zeer trots.

I was very proud.

Why: Past zijn and hebben. [[Dutch#^nl-Q0406|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20was%20zeer%20trots.)
^nl-Q0406-answer

**nl-Q0407** — Was ik maar rijk.

I wish I were rich.

Why: Past zijn and hebben. [[Dutch#^nl-Q0407|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Was%20ik%20maar%20rijk.)
^nl-Q0407-answer

**nl-Q0408** — Was ik maar rijk.

I wish I were rich.

Was/waren and had/hadden are common past forms. They can be main verbs or auxiliaries; a later participle determines whether a pluperfect construction is present.

Why: Past zijn and hebben. [[Dutch#^nl-Q0408|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Was%20ik%20maar%20rijk.)
^nl-Q0408-answer

**nl-Q0409** — Tom was toen dertien.

Tom was 13 years old at that time.

Expected form: **was**

Why: Past zijn and hebben. [[Dutch#^nl-Q0409|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Tom%20was%20toen%20dertien.)
^nl-Q0409-answer

**nl-Q0410** — Tom was toen dertien.

Tom was 13 years old at that time.

Expected form: **was**

Why: Past zijn and hebben. [[Dutch#^nl-Q0410|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Tom%20was%20toen%20dertien.)
^nl-Q0410-answer

**nl-Q0411** — We hadden oesters eerder.

We had oysters earlier.

Expected form: **hadden**

Why: Past zijn and hebben. [[Dutch#^nl-Q0411|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=We%20hadden%20oesters%20eerder.)
^nl-Q0411-answer

**nl-Q0412** — We hadden oesters eerder.

We had oysters earlier.

Why: Past zijn and hebben. [[Dutch#^nl-Q0412|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=We%20hadden%20oesters%20eerder.)
^nl-Q0412-answer

**nl-Q0413** — We hadden een groot kerstfeest.

We had a big Christmas party.

Why: Past zijn and hebben. [[Dutch#^nl-Q0413|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=We%20hadden%20een%20groot%20kerstfeest.)
^nl-Q0413-answer

**nl-Q0414** — We hadden een groot kerstfeest.

We had a big Christmas party.

Was/waren and had/hadden are common past forms. They can be main verbs or auxiliaries; a later participle determines whether a pluperfect construction is present.

Why: Past zijn and hebben. [[Dutch#^nl-Q0414|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=We%20hadden%20een%20groot%20kerstfeest.)
^nl-Q0414-answer

**nl-Q0415** — Tom was wakker.

Tom was awake.

Expected form: **was**

Why: Past zijn and hebben. [[Dutch#^nl-Q0415|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Tom%20was%20wakker.)
^nl-Q0415-answer

**nl-Q0416** — Tom was wakker.

Tom was awake.

Expected form: **was**

Why: Past zijn and hebben. [[Dutch#^nl-Q0416|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Tom%20was%20wakker.)
^nl-Q0416-answer

**nl-Q0417** — Sami had een Duitse herder genaamd Farid.

Sami had a German shepherd named Farid.

Expected form: **had**

Why: Past zijn and hebben. [[Dutch#^nl-Q0417|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Sami%20had%20een%20Duitse%20herder%20genaamd%20Farid.)
^nl-Q0417-answer

**nl-Q0418** — Sami had een Duitse herder genaamd Farid.

Sami had a German shepherd named Farid.

Why: Past zijn and hebben. [[Dutch#^nl-Q0418|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Sami%20had%20een%20Duitse%20herder%20genaamd%20Farid.)
^nl-Q0418-answer

**nl-Q0419** — Hij was in de rij.

He was in the queue.

Why: Past zijn and hebben. [[Dutch#^nl-Q0419|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Hij%20was%20in%20de%20rij.)
^nl-Q0419-answer

**nl-Q0420** — Hij was in de rij.

He was in the queue.

Was/waren and had/hadden are common past forms. They can be main verbs or auxiliaries; a later participle determines whether a pluperfect construction is present.

Why: Past zijn and hebben. [[Dutch#^nl-Q0420|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Hij%20was%20in%20de%20rij.)
^nl-Q0420-answer

**nl-Q0421** — De dieven wisten wat ze aan het doen waren.

The thieves knew what they were doing.

Expected form: **waren**

Why: Past zijn and hebben. [[Dutch#^nl-Q0421|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=De%20dieven%20wisten%20wat%20ze%20aan%20het%20doen%20waren.)
^nl-Q0421-answer

**nl-Q0422** — De dieven wisten wat ze aan het doen waren.

The thieves knew what they were doing.

Expected form: **waren**

Why: Past zijn and hebben. [[Dutch#^nl-Q0422|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=De%20dieven%20wisten%20wat%20ze%20aan%20het%20doen%20waren.)
^nl-Q0422-answer

**nl-Q0423** — Toen ik thuiskwam, was mijn broer zijn huiswerk aan het doen.

When I returned home, my brother was doing his homework.

Expected form: **was**

Why: Past zijn and hebben. [[Dutch#^nl-Q0423|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Toen%20ik%20thuiskwam%2C%20was%20mijn%20broer%20zijn%20huiswerk%20aan%20het%20doen.)
^nl-Q0423-answer

**nl-Q0424** — Toen ik thuiskwam, was mijn broer zijn huiswerk aan het doen.

When I returned home, my brother was doing his homework.

Why: Past zijn and hebben. [[Dutch#^nl-Q0424|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Toen%20ik%20thuiskwam%2C%20was%20mijn%20broer%20zijn%20huiswerk%20aan%20het%20doen.)
^nl-Q0424-answer

**nl-Q0425** — Hoeveel computers zei je dat je had?

How many computers did you say you had?

Why: Past zijn and hebben. [[Dutch#^nl-Q0425|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Hoeveel%20computers%20zei%20je%20dat%20je%20had%3F)
^nl-Q0425-answer

**nl-Q0426** — Hoeveel computers zei je dat je had?

How many computers did you say you had?

Was/waren and had/hadden are common past forms. They can be main verbs or auxiliaries; a later participle determines whether a pluperfect construction is present.

Why: Past zijn and hebben. [[Dutch#^nl-Q0426|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Hoeveel%20computers%20zei%20je%20dat%20je%20had%3F)
^nl-Q0426-answer

**nl-Q0427** — Tom was degene die mij het verhaal vertelde.

Tom was the one who told me the story.

Expected form: **was**

Why: Past zijn and hebben. [[Dutch#^nl-Q0427|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Tom%20was%20degene%20die%20mij%20het%20verhaal%20vertelde.)
^nl-Q0427-answer

**nl-Q0428** — Tom was degene die mij het verhaal vertelde.

Tom was the one who told me the story.

Expected form: **was**

Why: Past zijn and hebben. [[Dutch#^nl-Q0428|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Tom%20was%20degene%20die%20mij%20het%20verhaal%20vertelde.)
^nl-Q0428-answer

**nl-Q0429** — Sami had natuurlijke groene ogen.

Sami had natural green eyes.

Expected form: **had**

Why: Past zijn and hebben. [[Dutch#^nl-Q0429|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Sami%20had%20natuurlijke%20groene%20ogen.)
^nl-Q0429-answer

**nl-Q0430** — Sami had natuurlijke groene ogen.

Sami had natural green eyes.

Why: Past zijn and hebben. [[Dutch#^nl-Q0430|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Sami%20had%20natuurlijke%20groene%20ogen.)
^nl-Q0430-answer

**nl-Q0431** — Ik rookte toen ik jong was.

I did smoke when I was young.

Why: Past zijn and hebben. [[Dutch#^nl-Q0431|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20rookte%20toen%20ik%20jong%20was.)
^nl-Q0431-answer

**nl-Q0432** — Ik rookte toen ik jong was.

I did smoke when I was young.

Was/waren and had/hadden are common past forms. They can be main verbs or auxiliaries; a later participle determines whether a pluperfect construction is present.

Why: Past zijn and hebben. [[Dutch#^nl-Q0432|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20rookte%20toen%20ik%20jong%20was.)
^nl-Q0432-answer

**nl-Q0433** — Ik had niet veel zin om uit te gaan.

I didn't really feel like going out.

Expected form: **had**

Why: Past zijn and hebben. [[Dutch#^nl-Q0433|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20had%20niet%20veel%20zin%20om%20uit%20te%20gaan.)
^nl-Q0433-answer

**nl-Q0434** — Ik had niet veel zin om uit te gaan.

I didn't really feel like going out.

Expected form: **had**

Why: Past zijn and hebben. [[Dutch#^nl-Q0434|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20had%20niet%20veel%20zin%20om%20uit%20te%20gaan.)
^nl-Q0434-answer

**nl-Q0435** — Betty was de laatste die aankwam.

Betty was the last to arrive.

Expected form: **was**

Why: Past zijn and hebben. [[Dutch#^nl-Q0435|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Betty%20was%20de%20laatste%20die%20aankwam.)
^nl-Q0435-answer

**nl-Q0436** — Betty was de laatste die aankwam.

Betty was the last to arrive.

Why: Past zijn and hebben. [[Dutch#^nl-Q0436|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Betty%20was%20de%20laatste%20die%20aankwam.)
^nl-Q0436-answer

**nl-Q0437** — Al onze pogingen waren tevergeefs.

All our attempts were in vain.

Why: Past zijn and hebben. [[Dutch#^nl-Q0437|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Al%20onze%20pogingen%20waren%20tevergeefs.)
^nl-Q0437-answer

**nl-Q0438** — Al onze pogingen waren tevergeefs.

All our attempts were in vain.

Was/waren and had/hadden are common past forms. They can be main verbs or auxiliaries; a later participle determines whether a pluperfect construction is present.

Why: Past zijn and hebben. [[Dutch#^nl-Q0438|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Al%20onze%20pogingen%20waren%20tevergeefs.)
^nl-Q0438-answer

**nl-Q0439** — Ik gaf het geld dat ik bij me had aan de bedelaar.

I gave the beggar all the money I had.

Expected form: **had**

Why: Past zijn and hebben. [[Dutch#^nl-Q0439|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20gaf%20het%20geld%20dat%20ik%20bij%20me%20had%20aan%20de%20bedelaar.)
^nl-Q0439-answer

**nl-Q0440** — Ik gaf het geld dat ik bij me had aan de bedelaar.

I gave the beggar all the money I had.

Expected form: **had**

Why: Past zijn and hebben. [[Dutch#^nl-Q0440|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20gaf%20het%20geld%20dat%20ik%20bij%20me%20had%20aan%20de%20bedelaar.)
^nl-Q0440-answer

**nl-Q0441** — Hoe was je wandeling?

How was your walk?

Expected form: **was**

Why: Past zijn and hebben. [[Dutch#^nl-Q0441|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Hoe%20was%20je%20wandeling%3F)
^nl-Q0441-answer

**nl-Q0442** — Hoe was je wandeling?

How was your walk?

Why: Past zijn and hebben. [[Dutch#^nl-Q0442|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Hoe%20was%20je%20wandeling%3F)
^nl-Q0442-answer

**nl-Q0443** — Waar was je gisteren?

Where were you yesterday?

Why: Past zijn and hebben. [[Dutch#^nl-Q0443|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Waar%20was%20je%20gisteren%3F)
^nl-Q0443-answer

**nl-Q0444** — Waar was je gisteren?

Where were you yesterday?

Was/waren and had/hadden are common past forms. They can be main verbs or auxiliaries; a later participle determines whether a pluperfect construction is present.

Why: Past zijn and hebben. [[Dutch#^nl-Q0444|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Waar%20was%20je%20gisteren%3F)
^nl-Q0444-answer

**nl-Q0445** — Sami had het koud.

Sami was cold.

Expected form: **had**

Why: Past zijn and hebben. [[Dutch#^nl-Q0445|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Sami%20had%20het%20koud.)
^nl-Q0445-answer

**nl-Q0446** — Sami had het koud.

Sami was cold.

Expected form: **had**

Why: Past zijn and hebben. [[Dutch#^nl-Q0446|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Sami%20had%20het%20koud.)
^nl-Q0446-answer

**nl-Q0447** — De slangenbeet was fataal.

The snake bite was fatal.

Expected form: **was**

Why: Past zijn and hebben. [[Dutch#^nl-Q0447|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=De%20slangenbeet%20was%20fataal.)
^nl-Q0447-answer

**nl-Q0448** — De slangenbeet was fataal.

The snake bite was fatal.

Why: Past zijn and hebben. [[Dutch#^nl-Q0448|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=De%20slangenbeet%20was%20fataal.)
^nl-Q0448-answer

**nl-Q0449** — Mijn man was leraar.

My husband was a teacher.

Why: Past zijn and hebben. [[Dutch#^nl-Q0449|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Mijn%20man%20was%20leraar.)
^nl-Q0449-answer

**nl-Q0450** — Mijn man was leraar.

My husband was a teacher.

Was/waren and had/hadden are common past forms. They can be main verbs or auxiliaries; a later participle determines whether a pluperfect construction is present.

Why: Past zijn and hebben. [[Dutch#^nl-Q0450|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Mijn%20man%20was%20leraar.)
^nl-Q0450-answer


### Answers 451–500

**nl-Q0451** — Wie heeft die doos gemaakt?

Who made this box?

Expected form: **gemaakt**

Why: Past participles. [[Dutch#^nl-Q0451|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Wie%20heeft%20die%20doos%20gemaakt%3F)
^nl-Q0451-answer

**nl-Q0452** — Wie heeft die doos gemaakt?

Who made this box?

Expected form: **gemaakt**

Why: Past participles. [[Dutch#^nl-Q0452|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Wie%20heeft%20die%20doos%20gemaakt%3F)
^nl-Q0452-answer

**nl-Q0453** — Het maakt niet uit wat ze gezegd heeft.

It doesn't matter what she said.

Expected form: **gezegd**

Why: Past participles. [[Dutch#^nl-Q0453|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Het%20maakt%20niet%20uit%20wat%20ze%20gezegd%20heeft.)
^nl-Q0453-answer

**nl-Q0454** — Het maakt niet uit wat ze gezegd heeft.

It doesn't matter what she said.

Why: Past participles. [[Dutch#^nl-Q0454|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Het%20maakt%20niet%20uit%20wat%20ze%20gezegd%20heeft.)
^nl-Q0454-answer

**nl-Q0455** — Ik ben nooit in het buitenland geweest.

I've never been abroad.

Why: Past participles. [[Dutch#^nl-Q0455|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20ben%20nooit%20in%20het%20buitenland%20geweest.)
^nl-Q0455-answer

**nl-Q0456** — Ik ben nooit in het buitenland geweest.

I've never been abroad.

A perfect combines hebben or zijn with a past participle. Motion/change verbs may use zijn in relevant meanings; learn auxiliary choice with the verb.

Why: Past participles. [[Dutch#^nl-Q0456|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20ben%20nooit%20in%20het%20buitenland%20geweest.)
^nl-Q0456-answer

**nl-Q0457** — Sami heeft koffie gemaakt.

Sami made coffee.

Expected form: **gemaakt**

Why: Past participles. [[Dutch#^nl-Q0457|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Sami%20heeft%20koffie%20gemaakt.)
^nl-Q0457-answer

**nl-Q0458** — Sami heeft koffie gemaakt.

Sami made coffee.

Expected form: **gemaakt**

Why: Past participles. [[Dutch#^nl-Q0458|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Sami%20heeft%20koffie%20gemaakt.)
^nl-Q0458-answer

**nl-Q0459** — We hebben een goede film gezien.

We have seen a good movie.

Expected form: **gezien**

Why: Past participles. [[Dutch#^nl-Q0459|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=We%20hebben%20een%20goede%20film%20gezien.)
^nl-Q0459-answer

**nl-Q0460** — We hebben een goede film gezien.

We have seen a good movie.

Why: Past participles. [[Dutch#^nl-Q0460|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=We%20hebben%20een%20goede%20film%20gezien.)
^nl-Q0460-answer

**nl-Q0461** — Hebben jullie haar gezien?

Have you guys seen her?

Why: Past participles. [[Dutch#^nl-Q0461|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Hebben%20jullie%20haar%20gezien%3F)
^nl-Q0461-answer

**nl-Q0462** — Hebben jullie haar gezien?

Have you guys seen her?

A perfect combines hebben or zijn with a past participle. Motion/change verbs may use zijn in relevant meanings; learn auxiliary choice with the verb.

Why: Past participles. [[Dutch#^nl-Q0462|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Hebben%20jullie%20haar%20gezien%3F)
^nl-Q0462-answer

**nl-Q0463** — Ik heb een muis gezien!

I saw a mouse!

Expected form: **gezien**

Why: Past participles. [[Dutch#^nl-Q0463|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20heb%20een%20muis%20gezien%21)
^nl-Q0463-answer

**nl-Q0464** — Ik heb een muis gezien!

I saw a mouse!

Expected form: **gezien**

Why: Past participles. [[Dutch#^nl-Q0464|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20heb%20een%20muis%20gezien%21)
^nl-Q0464-answer

**nl-Q0465** — Het was niet duidelijk of ze gedaan hadden of niet.

It was not clear whether they had done or not.

Expected form: **gedaan**

Why: Past participles. [[Dutch#^nl-Q0465|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Het%20was%20niet%20duidelijk%20of%20ze%20gedaan%20hadden%20of%20niet.)
^nl-Q0465-answer

**nl-Q0466** — Het was niet duidelijk of ze gedaan hadden of niet.

It was not clear whether they had done or not.

Why: Past participles. [[Dutch#^nl-Q0466|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Het%20was%20niet%20duidelijk%20of%20ze%20gedaan%20hadden%20of%20niet.)
^nl-Q0466-answer

**nl-Q0467** — Je hebt niets verkeerd gedaan.

You haven't done anything wrong.

Why: Past participles. [[Dutch#^nl-Q0467|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Je%20hebt%20niets%20verkeerd%20gedaan.)
^nl-Q0467-answer

**nl-Q0468** — Je hebt niets verkeerd gedaan.

You haven't done anything wrong.

A perfect combines hebben or zijn with a past participle. Motion/change verbs may use zijn in relevant meanings; learn auxiliary choice with the verb.

Why: Past participles. [[Dutch#^nl-Q0468|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Je%20hebt%20niets%20verkeerd%20gedaan.)
^nl-Q0468-answer

**nl-Q0469** — We zijn naar het museum gegaan.

We went to the museum.

Expected form: **gegaan**

Why: Past participles. [[Dutch#^nl-Q0469|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=We%20zijn%20naar%20het%20museum%20gegaan.)
^nl-Q0469-answer

**nl-Q0470** — We zijn naar het museum gegaan.

We went to the museum.

Expected form: **gegaan**

Why: Past participles. [[Dutch#^nl-Q0470|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=We%20zijn%20naar%20het%20museum%20gegaan.)
^nl-Q0470-answer

**nl-Q0471** — We hebben een overdosis gehad.

We overdosed.

Expected form: **gehad**

Why: Past participles. [[Dutch#^nl-Q0471|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=We%20hebben%20een%20overdosis%20gehad.)
^nl-Q0471-answer

**nl-Q0472** — We hebben een overdosis gehad.

We overdosed.

Why: Past participles. [[Dutch#^nl-Q0472|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=We%20hebben%20een%20overdosis%20gehad.)
^nl-Q0472-answer

**nl-Q0473** — Wat heb je afgelopen zondag gedaan?

What did you do last Sunday?

Why: Past participles. [[Dutch#^nl-Q0473|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Wat%20heb%20je%20afgelopen%20zondag%20gedaan%3F)
^nl-Q0473-answer

**nl-Q0474** — Wat heb je afgelopen zondag gedaan?

What did you do last Sunday?

A perfect combines hebben or zijn with a past participle. Motion/change verbs may use zijn in relevant meanings; learn auxiliary choice with the verb.

Why: Past participles. [[Dutch#^nl-Q0474|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Wat%20heb%20je%20afgelopen%20zondag%20gedaan%3F)
^nl-Q0474-answer

**nl-Q0475** — Heb je echt een ufo gezien?

Did you really see a UFO?

Expected form: **gezien**

Why: Past participles. [[Dutch#^nl-Q0475|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Heb%20je%20echt%20een%20ufo%20gezien%3F)
^nl-Q0475-answer

**nl-Q0476** — Heb je echt een ufo gezien?

Did you really see a UFO?

Expected form: **gezien**

Why: Past participles. [[Dutch#^nl-Q0476|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Heb%20je%20echt%20een%20ufo%20gezien%3F)
^nl-Q0476-answer

**nl-Q0477** — Ik heb niet gezegd dat jij hem gepakt hebt.

I didn't say you took it.

Expected form: **gezegd**

Why: Past participles. [[Dutch#^nl-Q0477|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20heb%20niet%20gezegd%20dat%20jij%20hem%20gepakt%20hebt.)
^nl-Q0477-answer

**nl-Q0478** — Ik heb niet gezegd dat jij hem gepakt hebt.

I didn't say you took it.

Why: Past participles. [[Dutch#^nl-Q0478|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20heb%20niet%20gezegd%20dat%20jij%20hem%20gepakt%20hebt.)
^nl-Q0478-answer

**nl-Q0479** — Tom heeft koffie gemaakt.

Tom made coffee.

Why: Past participles. [[Dutch#^nl-Q0479|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Tom%20heeft%20koffie%20gemaakt.)
^nl-Q0479-answer

**nl-Q0480** — Tom heeft koffie gemaakt.

Tom made coffee.

A perfect combines hebben or zijn with a past participle. Motion/change verbs may use zijn in relevant meanings; learn auxiliary choice with the verb.

Why: Past participles. [[Dutch#^nl-Q0480|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Tom%20heeft%20koffie%20gemaakt.)
^nl-Q0480-answer

**nl-Q0481** — Ik denk dat je dit al eerder hebt gezegd.

I think you've said that before.

Expected form: **gezegd**

Why: Past participles. [[Dutch#^nl-Q0481|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20denk%20dat%20je%20dit%20al%20eerder%20hebt%20gezegd.)
^nl-Q0481-answer

**nl-Q0482** — Ik denk dat je dit al eerder hebt gezegd.

I think you've said that before.

Expected form: **gezegd**

Why: Past participles. [[Dutch#^nl-Q0482|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20denk%20dat%20je%20dit%20al%20eerder%20hebt%20gezegd.)
^nl-Q0482-answer

**nl-Q0483** — Tom gaf toe dat hij het gedaan heeft.

Tom admitted that he did that.

Expected form: **gedaan**

Why: Past participles. [[Dutch#^nl-Q0483|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Tom%20gaf%20toe%20dat%20hij%20het%20gedaan%20heeft.)
^nl-Q0483-answer

**nl-Q0484** — Tom gaf toe dat hij het gedaan heeft.

Tom admitted that he did that.

Why: Past participles. [[Dutch#^nl-Q0484|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Tom%20gaf%20toe%20dat%20hij%20het%20gedaan%20heeft.)
^nl-Q0484-answer

**nl-Q0485** — Zijn kasteel was gemaakt van hout.

His castle was made of wood.

Why: Past participles. [[Dutch#^nl-Q0485|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Zijn%20kasteel%20was%20gemaakt%20van%20hout.)
^nl-Q0485-answer

**nl-Q0486** — Zijn kasteel was gemaakt van hout.

His castle was made of wood.

A perfect combines hebben or zijn with a past participle. Motion/change verbs may use zijn in relevant meanings; learn auxiliary choice with the verb.

Why: Past participles. [[Dutch#^nl-Q0486|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Zijn%20kasteel%20was%20gemaakt%20van%20hout.)
^nl-Q0486-answer

**nl-Q0487** — Ik had het nog niet eerder gezien.

I hadn't seen it before.

Expected form: **gezien**

Why: Past participles. [[Dutch#^nl-Q0487|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20had%20het%20nog%20niet%20eerder%20gezien.)
^nl-Q0487-answer

**nl-Q0488** — Ik had het nog niet eerder gezien.

I hadn't seen it before.

Expected form: **gezien**

Why: Past participles. [[Dutch#^nl-Q0488|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20had%20het%20nog%20niet%20eerder%20gezien.)
^nl-Q0488-answer

**nl-Q0489** — Sami is een heel jaar moslim geweest.

Sami has been a Muslim for a whole year.

Expected form: **geweest**

Why: Past participles. [[Dutch#^nl-Q0489|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Sami%20is%20een%20heel%20jaar%20moslim%20geweest.)
^nl-Q0489-answer

**nl-Q0490** — Sami is een heel jaar moslim geweest.

Sami has been a Muslim for a whole year.

Why: Past participles. [[Dutch#^nl-Q0490|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Sami%20is%20een%20heel%20jaar%20moslim%20geweest.)
^nl-Q0490-answer

**nl-Q0491** — Iemand heeft iets in haar drankje gedaan.

Someone put something in her drink.

Why: Past participles. [[Dutch#^nl-Q0491|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Iemand%20heeft%20iets%20in%20haar%20drankje%20gedaan.)
^nl-Q0491-answer

**nl-Q0492** — Iemand heeft iets in haar drankje gedaan.

Someone put something in her drink.

A perfect combines hebben or zijn with a past participle. Motion/change verbs may use zijn in relevant meanings; learn auxiliary choice with the verb.

Why: Past participles. [[Dutch#^nl-Q0492|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Iemand%20heeft%20iets%20in%20haar%20drankje%20gedaan.)
^nl-Q0492-answer

**nl-Q0493** — Eerlijk gezegd kunnen we je hulp wel gebruiken.

Frankly, we could use your help.

Expected form: **gezegd**

Why: Past participles. [[Dutch#^nl-Q0493|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Eerlijk%20gezegd%20kunnen%20we%20je%20hulp%20wel%20gebruiken.)
^nl-Q0493-answer

**nl-Q0494** — Eerlijk gezegd kunnen we je hulp wel gebruiken.

Frankly, we could use your help.

Expected form: **gezegd**

Why: Past participles. [[Dutch#^nl-Q0494|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Eerlijk%20gezegd%20kunnen%20we%20je%20hulp%20wel%20gebruiken.)
^nl-Q0494-answer

**nl-Q0495** — Ik heb nog nooit een dikke veganist gezien.

I've never seen a fat vegan.

Expected form: **gezien**

Why: Past participles. [[Dutch#^nl-Q0495|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20heb%20nog%20nooit%20een%20dikke%20veganist%20gezien.)
^nl-Q0495-answer

**nl-Q0496** — Ik heb nog nooit een dikke veganist gezien.

I've never seen a fat vegan.

Why: Past participles. [[Dutch#^nl-Q0496|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20heb%20nog%20nooit%20een%20dikke%20veganist%20gezien.)
^nl-Q0496-answer

**nl-Q0497** — Het lijkt wel alsof Tom en Mary voor elkaar zijn gemaakt.

It's as if Tom and Mary were made for each other.

Why: Past participles. [[Dutch#^nl-Q0497|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Het%20lijkt%20wel%20alsof%20Tom%20en%20Mary%20voor%20elkaar%20zijn%20gemaakt.)
^nl-Q0497-answer

**nl-Q0498** — Het lijkt wel alsof Tom en Mary voor elkaar zijn gemaakt.

It's as if Tom and Mary were made for each other.

A perfect combines hebben or zijn with a past participle. Motion/change verbs may use zijn in relevant meanings; learn auxiliary choice with the verb.

Why: Past participles. [[Dutch#^nl-Q0498|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Het%20lijkt%20wel%20alsof%20Tom%20en%20Mary%20voor%20elkaar%20zijn%20gemaakt.)
^nl-Q0498-answer

**nl-Q0499** — Dat is altijd zo geweest.

This is always the way it has been.

Expected form: **geweest**

Why: Past participles. [[Dutch#^nl-Q0499|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Dat%20is%20altijd%20zo%20geweest.)
^nl-Q0499-answer

**nl-Q0500** — Dat is altijd zo geweest.

This is always the way it has been.

Expected form: **geweest**

Why: Past participles. [[Dutch#^nl-Q0500|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Dat%20is%20altijd%20zo%20geweest.)
^nl-Q0500-answer


### Answers 501–550

**nl-Q0501** — Ik wou dat ik kon stoppen met denken aan Tom.

I wish I could stop thinking about Tom.

Expected form: **kon**

Why: Conditional forms. [[Dutch#^nl-Q0501|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20wou%20dat%20ik%20kon%20stoppen%20met%20denken%20aan%20Tom.)
^nl-Q0501-answer

**nl-Q0502** — Ik wou dat ik kon stoppen met denken aan Tom.

I wish I could stop thinking about Tom.

Why: Conditional forms. [[Dutch#^nl-Q0502|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20wou%20dat%20ik%20kon%20stoppen%20met%20denken%20aan%20Tom.)
^nl-Q0502-answer

**nl-Q0503** — Als ik het alfabet kon herschikken, dan zette ik nog steeds T voor U.

If I could rearrange the alphabet, I would put U and I together.

Why: Conditional forms. [[Dutch#^nl-Q0503|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Als%20ik%20het%20alfabet%20kon%20herschikken%2C%20dan%20zette%20ik%20nog%20steeds%20T%20voor%20U.)
^nl-Q0503-answer

**nl-Q0504** — Als ik het alfabet kon herschikken, dan zette ik nog steeds T voor U.

If I could rearrange the alphabet, I would put U and I together.

Zou/zouden often mark a conditional or future in the past. Kon/konden can be past ability or hypothetical ability. Context determines whether the situation is factual or unreal.

Why: Conditional forms. [[Dutch#^nl-Q0504|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Als%20ik%20het%20alfabet%20kon%20herschikken%2C%20dan%20zette%20ik%20nog%20steeds%20T%20voor%20U.)
^nl-Q0504-answer

**nl-Q0505** — Ik wist wel dat Tom dorst zou hebben.

I knew Tom would be thirsty.

Expected form: **zou**

Why: Conditional forms. [[Dutch#^nl-Q0505|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20wist%20wel%20dat%20Tom%20dorst%20zou%20hebben.)
^nl-Q0505-answer

**nl-Q0506** — Ik wist wel dat Tom dorst zou hebben.

I knew Tom would be thirsty.

Expected form: **zou**

Why: Conditional forms. [[Dutch#^nl-Q0506|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20wist%20wel%20dat%20Tom%20dorst%20zou%20hebben.)
^nl-Q0506-answer

**nl-Q0507** — Tom wilde geen pizza eten.

Tom didn't want to eat pizza.

Expected form: **wilde**

Why: Conditional forms. [[Dutch#^nl-Q0507|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Tom%20wilde%20geen%20pizza%20eten.)
^nl-Q0507-answer

**nl-Q0508** — Tom wilde geen pizza eten.

Tom didn't want to eat pizza.

Why: Conditional forms. [[Dutch#^nl-Q0508|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Tom%20wilde%20geen%20pizza%20eten.)
^nl-Q0508-answer

**nl-Q0509** — Zou dat Tom zijn?

I wonder if that's Tom.

Why: Conditional forms. [[Dutch#^nl-Q0509|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Zou%20dat%20Tom%20zijn%3F)
^nl-Q0509-answer

**nl-Q0510** — Zou dat Tom zijn?

I wonder if that's Tom.

Zou/zouden often mark a conditional or future in the past. Kon/konden can be past ability or hypothetical ability. Context determines whether the situation is factual or unreal.

Why: Conditional forms. [[Dutch#^nl-Q0510|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Zou%20dat%20Tom%20zijn%3F)
^nl-Q0510-answer

**nl-Q0511** — Hij zou in staat zijn dat te doen.

That he would be able to do.

Expected form: **zou**

Why: Conditional forms. [[Dutch#^nl-Q0511|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Hij%20zou%20in%20staat%20zijn%20dat%20te%20doen.)
^nl-Q0511-answer

**nl-Q0512** — Hij zou in staat zijn dat te doen.

That he would be able to do.

Expected form: **zou**

Why: Conditional forms. [[Dutch#^nl-Q0512|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Hij%20zou%20in%20staat%20zijn%20dat%20te%20doen.)
^nl-Q0512-answer

**nl-Q0513** — Ik wou dat Tom dat ook daadwerkelijk kon doen.

I wish Tom could actually do that.

Expected form: **kon**

Why: Conditional forms. [[Dutch#^nl-Q0513|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20wou%20dat%20Tom%20dat%20ook%20daadwerkelijk%20kon%20doen.)
^nl-Q0513-answer

**nl-Q0514** — Ik wou dat Tom dat ook daadwerkelijk kon doen.

I wish Tom could actually do that.

Why: Conditional forms. [[Dutch#^nl-Q0514|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20wou%20dat%20Tom%20dat%20ook%20daadwerkelijk%20kon%20doen.)
^nl-Q0514-answer

**nl-Q0515** — Ik was blij dat ik Japans had gestudeerd, toen ik een drama zonder ondertitels kon kijken.

Being able to watch a drama without subtitles made me very glad I studied Japanese.

Why: Conditional forms. [[Dutch#^nl-Q0515|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20was%20blij%20dat%20ik%20Japans%20had%20gestudeerd%2C%20toen%20ik%20een%20drama%20zonder%20ondertitels%20kon%20kijken.)
^nl-Q0515-answer

**nl-Q0516** — Ik was blij dat ik Japans had gestudeerd, toen ik een drama zonder ondertitels kon kijken.

Being able to watch a drama without subtitles made me very glad I studied Japanese.

Zou/zouden often mark a conditional or future in the past. Kon/konden can be past ability or hypothetical ability. Context determines whether the situation is factual or unreal.

Why: Conditional forms. [[Dutch#^nl-Q0516|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20was%20blij%20dat%20ik%20Japans%20had%20gestudeerd%2C%20toen%20ik%20een%20drama%20zonder%20ondertitels%20kon%20kijken.)
^nl-Q0516-answer

**nl-Q0517** — Ik zou heel graag een koud glas bier willen hebben.

I would love a cold glass of beer.

Expected form: **zou**

Why: Conditional forms. [[Dutch#^nl-Q0517|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20zou%20heel%20graag%20een%20koud%20glas%20bier%20willen%20hebben.)
^nl-Q0517-answer

**nl-Q0518** — Ik zou heel graag een koud glas bier willen hebben.

I would love a cold glass of beer.

Expected form: **zou**

Why: Conditional forms. [[Dutch#^nl-Q0518|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20zou%20heel%20graag%20een%20koud%20glas%20bier%20willen%20hebben.)
^nl-Q0518-answer

**nl-Q0519** — Ze konden mij niet beoordelen.

They couldn't judge me.

Expected form: **konden**

Why: Conditional forms. [[Dutch#^nl-Q0519|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ze%20konden%20mij%20niet%20beoordelen.)
^nl-Q0519-answer

**nl-Q0520** — Ze konden mij niet beoordelen.

They couldn't judge me.

Why: Conditional forms. [[Dutch#^nl-Q0520|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ze%20konden%20mij%20niet%20beoordelen.)
^nl-Q0520-answer

**nl-Q0521** — In uw plaats, zou ik afwachten.

If I were you, I would wait and see.

Why: Conditional forms. [[Dutch#^nl-Q0521|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=In%20uw%20plaats%2C%20zou%20ik%20afwachten.)
^nl-Q0521-answer

**nl-Q0522** — In uw plaats, zou ik afwachten.

If I were you, I would wait and see.

Zou/zouden often mark a conditional or future in the past. Kon/konden can be past ability or hypothetical ability. Context determines whether the situation is factual or unreal.

Why: Conditional forms. [[Dutch#^nl-Q0522|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=In%20uw%20plaats%2C%20zou%20ik%20afwachten.)
^nl-Q0522-answer

**nl-Q0523** — Zou u me kunnen zeggen waar de dichtstbijzijnde kerk is a.u.b.?

Could you please tell me where the nearest church is?

Expected form: **Zou**

Why: Conditional forms. [[Dutch#^nl-Q0523|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Zou%20u%20me%20kunnen%20zeggen%20waar%20de%20dichtstbijzijnde%20kerk%20is%20a.u.b.%3F)
^nl-Q0523-answer

**nl-Q0524** — Zou u me kunnen zeggen waar de dichtstbijzijnde kerk is a.u.b.?

Could you please tell me where the nearest church is?

Expected form: **Zou**

Why: Conditional forms. [[Dutch#^nl-Q0524|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Zou%20u%20me%20kunnen%20zeggen%20waar%20de%20dichtstbijzijnde%20kerk%20is%20a.u.b.%3F)
^nl-Q0524-answer

**nl-Q0525** — Het zou me niet gelukt zijn zonder zijn hulp.

I would have failed without his help.

Expected form: **zou**

Why: Conditional forms. [[Dutch#^nl-Q0525|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Het%20zou%20me%20niet%20gelukt%20zijn%20zonder%20zijn%20hulp.)
^nl-Q0525-answer

**nl-Q0526** — Het zou me niet gelukt zijn zonder zijn hulp.

I would have failed without his help.

Why: Conditional forms. [[Dutch#^nl-Q0526|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Het%20zou%20me%20niet%20gelukt%20zijn%20zonder%20zijn%20hulp.)
^nl-Q0526-answer

**nl-Q0527** — Ik dacht dat ik altijd alleen zou zijn.

I thought I'd always be alone.

Why: Conditional forms. [[Dutch#^nl-Q0527|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20dacht%20dat%20ik%20altijd%20alleen%20zou%20zijn.)
^nl-Q0527-answer

**nl-Q0528** — Ik dacht dat ik altijd alleen zou zijn.

I thought I'd always be alone.

Zou/zouden often mark a conditional or future in the past. Kon/konden can be past ability or hypothetical ability. Context determines whether the situation is factual or unreal.

Why: Conditional forms. [[Dutch#^nl-Q0528|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20dacht%20dat%20ik%20altijd%20alleen%20zou%20zijn.)
^nl-Q0528-answer

**nl-Q0529** — Hij kon het probleem oplossen.

He was able to solve the problem.

Expected form: **kon**

Why: Conditional forms. [[Dutch#^nl-Q0529|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Hij%20kon%20het%20probleem%20oplossen.)
^nl-Q0529-answer

**nl-Q0530** — Hij kon het probleem oplossen.

He was able to solve the problem.

Expected form: **kon**

Why: Conditional forms. [[Dutch#^nl-Q0530|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Hij%20kon%20het%20probleem%20oplossen.)
^nl-Q0530-answer

**nl-Q0531** — Het zou beter zijn dat je haar nu niet ontmoet.

You'd better not see her now.

Expected form: **zou**

Why: Conditional forms. [[Dutch#^nl-Q0531|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Het%20zou%20beter%20zijn%20dat%20je%20haar%20nu%20niet%20ontmoet.)
^nl-Q0531-answer

**nl-Q0532** — Het zou beter zijn dat je haar nu niet ontmoet.

You'd better not see her now.

Why: Conditional forms. [[Dutch#^nl-Q0532|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Het%20zou%20beter%20zijn%20dat%20je%20haar%20nu%20niet%20ontmoet.)
^nl-Q0532-answer

**nl-Q0533** — Ik kon dit niet voorkomen.

I was unable to prevent this.

Why: Conditional forms. [[Dutch#^nl-Q0533|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20kon%20dit%20niet%20voorkomen.)
^nl-Q0533-answer

**nl-Q0534** — Ik kon dit niet voorkomen.

I was unable to prevent this.

Zou/zouden often mark a conditional or future in the past. Kon/konden can be past ability or hypothetical ability. Context determines whether the situation is factual or unreal.

Why: Conditional forms. [[Dutch#^nl-Q0534|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20kon%20dit%20niet%20voorkomen.)
^nl-Q0534-answer

**nl-Q0535** — Ze rende zo snel als ze kon.

She ran as fast as possible.

Expected form: **kon**

Why: Conditional forms. [[Dutch#^nl-Q0535|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ze%20rende%20zo%20snel%20als%20ze%20kon.)
^nl-Q0535-answer

**nl-Q0536** — Ze rende zo snel als ze kon.

She ran as fast as possible.

Expected form: **kon**

Why: Conditional forms. [[Dutch#^nl-Q0536|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ze%20rende%20zo%20snel%20als%20ze%20kon.)
^nl-Q0536-answer

**nl-Q0537** — Tom vertelde me dat hij wilde stoppen met zijn baan.

Tom told me he wanted to quit his job.

Expected form: **wilde**

Why: Conditional forms. [[Dutch#^nl-Q0537|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Tom%20vertelde%20me%20dat%20hij%20wilde%20stoppen%20met%20zijn%20baan.)
^nl-Q0537-answer

**nl-Q0538** — Tom vertelde me dat hij wilde stoppen met zijn baan.

Tom told me he wanted to quit his job.

Why: Conditional forms. [[Dutch#^nl-Q0538|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Tom%20vertelde%20me%20dat%20hij%20wilde%20stoppen%20met%20zijn%20baan.)
^nl-Q0538-answer

**nl-Q0539** — Tom wilde weten of Mary een vriendje had.

Tom wanted to know if Mary had a boyfriend.

Why: Conditional forms. [[Dutch#^nl-Q0539|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Tom%20wilde%20weten%20of%20Mary%20een%20vriendje%20had.)
^nl-Q0539-answer

**nl-Q0540** — Tom wilde weten of Mary een vriendje had.

Tom wanted to know if Mary had a boyfriend.

Zou/zouden often mark a conditional or future in the past. Kon/konden can be past ability or hypothetical ability. Context determines whether the situation is factual or unreal.

Why: Conditional forms. [[Dutch#^nl-Q0540|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Tom%20wilde%20weten%20of%20Mary%20een%20vriendje%20had.)
^nl-Q0540-answer

**nl-Q0541** — Ze wilde niet betrokken raken.

She didn't want to get involved.

Expected form: **wilde**

Why: Conditional forms. [[Dutch#^nl-Q0541|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ze%20wilde%20niet%20betrokken%20raken.)
^nl-Q0541-answer

**nl-Q0542** — Ze wilde niet betrokken raken.

She didn't want to get involved.

Expected form: **wilde**

Why: Conditional forms. [[Dutch#^nl-Q0542|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ze%20wilde%20niet%20betrokken%20raken.)
^nl-Q0542-answer

**nl-Q0543** — Bob kon zijn woede niet beheersen.

Bob could not control his anger.

Expected form: **kon**

Why: Conditional forms. [[Dutch#^nl-Q0543|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Bob%20kon%20zijn%20woede%20niet%20beheersen.)
^nl-Q0543-answer

**nl-Q0544** — Bob kon zijn woede niet beheersen.

Bob could not control his anger.

Why: Conditional forms. [[Dutch#^nl-Q0544|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Bob%20kon%20zijn%20woede%20niet%20beheersen.)
^nl-Q0544-answer

**nl-Q0545** — We wisten niet dat je met ons zou komen.

We didn't know you would be coming with us.

Why: Conditional forms. [[Dutch#^nl-Q0545|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=We%20wisten%20niet%20dat%20je%20met%20ons%20zou%20komen.)
^nl-Q0545-answer

**nl-Q0546** — We wisten niet dat je met ons zou komen.

We didn't know you would be coming with us.

Zou/zouden often mark a conditional or future in the past. Kon/konden can be past ability or hypothetical ability. Context determines whether the situation is factual or unreal.

Why: Conditional forms. [[Dutch#^nl-Q0546|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=We%20wisten%20niet%20dat%20je%20met%20ons%20zou%20komen.)
^nl-Q0546-answer

**nl-Q0547** — Ik bad opdat mijn dochters mij zouden vergeven.

I prayed that my daughters would forgive me.

Expected form: **zouden**

Why: Conditional forms. [[Dutch#^nl-Q0547|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20bad%20opdat%20mijn%20dochters%20mij%20zouden%20vergeven.)
^nl-Q0547-answer

**nl-Q0548** — Ik bad opdat mijn dochters mij zouden vergeven.

I prayed that my daughters would forgive me.

Expected form: **zouden**

Why: Conditional forms. [[Dutch#^nl-Q0548|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20bad%20opdat%20mijn%20dochters%20mij%20zouden%20vergeven.)
^nl-Q0548-answer

**nl-Q0549** — Ik zou graag in deze rivier zwemmen.

I'd like to swim in this river.

Expected form: **zou**

Why: Conditional forms. [[Dutch#^nl-Q0549|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20zou%20graag%20in%20deze%20rivier%20zwemmen.)
^nl-Q0549-answer

**nl-Q0550** — Ik zou graag in deze rivier zwemmen.

I'd like to swim in this river.

Why: Conditional forms. [[Dutch#^nl-Q0550|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20zou%20graag%20in%20deze%20rivier%20zwemmen.)
^nl-Q0550-answer


### Answers 551–600

**nl-Q0551** — Die hierboven vermelde zending werd behoorlijk afgeleverd.

The above-mentioned mail item has been duly delivered.

Why: Passives and worden. [[Dutch#^nl-Q0551|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Die%20hierboven%20vermelde%20zending%20werd%20behoorlijk%20afgeleverd.)
^nl-Q0551-answer

**nl-Q0552** — Die hierboven vermelde zending werd behoorlijk afgeleverd.

The above-mentioned mail item has been duly delivered.

Worden plus participle commonly forms an event passive. Worden can also mean become. Inspect the complete predicate before naming the construction.

Why: Passives and worden. [[Dutch#^nl-Q0552|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Die%20hierboven%20vermelde%20zending%20werd%20behoorlijk%20afgeleverd.)
^nl-Q0552-answer

**nl-Q0553** — Frans wordt gesproken in Zwitserland.

French is spoken in Switzerland.

Expected form: **wordt**

Why: Passives and worden. [[Dutch#^nl-Q0553|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Frans%20wordt%20gesproken%20in%20Zwitserland.)
^nl-Q0553-answer

**nl-Q0554** — Frans wordt gesproken in Zwitserland.

French is spoken in Switzerland.

Expected form: **wordt**

Why: Passives and worden. [[Dutch#^nl-Q0554|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Frans%20wordt%20gesproken%20in%20Zwitserland.)
^nl-Q0554-answer

**nl-Q0555** — Het Catalaans wordt gesproken in Andorra.

Catalan is spoken in Andorra.

Expected form: **wordt**

Why: Passives and worden. [[Dutch#^nl-Q0555|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Het%20Catalaans%20wordt%20gesproken%20in%20Andorra.)
^nl-Q0555-answer

**nl-Q0556** — Het Catalaans wordt gesproken in Andorra.

Catalan is spoken in Andorra.

Why: Passives and worden. [[Dutch#^nl-Q0556|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Het%20Catalaans%20wordt%20gesproken%20in%20Andorra.)
^nl-Q0556-answer

**nl-Q0557** — De Seychellen worden ''Sesel'' genoemd in het Seychellencreools.

Seychelles is called "Sesel" in Seychellois Creole.

Why: Passives and worden. [[Dutch#^nl-Q0557|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=De%20Seychellen%20worden%20%27%27Sesel%27%27%20genoemd%20in%20het%20Seychellencreools.)
^nl-Q0557-answer

**nl-Q0558** — De Seychellen worden ''Sesel'' genoemd in het Seychellencreools.

Seychelles is called "Sesel" in Seychellois Creole.

Worden plus participle commonly forms an event passive. Worden can also mean become. Inspect the complete predicate before naming the construction.

Why: Passives and worden. [[Dutch#^nl-Q0558|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=De%20Seychellen%20worden%20%27%27Sesel%27%27%20genoemd%20in%20het%20Seychellencreools.)
^nl-Q0558-answer

**nl-Q0559** — Ik wou dat je niet rondslenterde. Dit is New York City... je zult omvergereden worden.

I wish you wouldn't amble; this is New York City--you'll get run over.

Expected form: **worden**

Why: Passives and worden. [[Dutch#^nl-Q0559|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20wou%20dat%20je%20niet%20rondslenterde.%20Dit%20is%20New%20York%20City...%20je%20zult%20omvergereden%20worden.)
^nl-Q0559-answer

**nl-Q0560** — Ik wou dat je niet rondslenterde. Dit is New York City... je zult omvergereden worden.

I wish you wouldn't amble; this is New York City--you'll get run over.

Expected form: **worden**

Why: Passives and worden. [[Dutch#^nl-Q0560|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20wou%20dat%20je%20niet%20rondslenterde.%20Dit%20is%20New%20York%20City...%20je%20zult%20omvergereden%20worden.)
^nl-Q0560-answer

**nl-Q0561** — Ik hoop dat je vlug beter wordt.

I do hope you will get well soon.

Expected form: **wordt**

Why: Passives and worden. [[Dutch#^nl-Q0561|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20hoop%20dat%20je%20vlug%20beter%20wordt.)
^nl-Q0561-answer

**nl-Q0562** — Ik hoop dat je vlug beter wordt.

I do hope you will get well soon.

Why: Passives and worden. [[Dutch#^nl-Q0562|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20hoop%20dat%20je%20vlug%20beter%20wordt.)
^nl-Q0562-answer

**nl-Q0563** — Met jou wil ik oud worden.

I want to grow old with you.

Why: Passives and worden. [[Dutch#^nl-Q0563|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Met%20jou%20wil%20ik%20oud%20worden.)
^nl-Q0563-answer

**nl-Q0564** — Met jou wil ik oud worden.

I want to grow old with you.

Worden plus participle commonly forms an event passive. Worden can also mean become. Inspect the complete predicate before naming the construction.

Why: Passives and worden. [[Dutch#^nl-Q0564|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Met%20jou%20wil%20ik%20oud%20worden.)
^nl-Q0564-answer

**nl-Q0565** — Mijn grootvader werd in de Tweede Wereldoorlog gedood.

My grandfather was killed in World War II.

Expected form: **werd**

Why: Passives and worden. [[Dutch#^nl-Q0565|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Mijn%20grootvader%20werd%20in%20de%20Tweede%20Wereldoorlog%20gedood.)
^nl-Q0565-answer

**nl-Q0566** — Mijn grootvader werd in de Tweede Wereldoorlog gedood.

My grandfather was killed in World War II.

Expected form: **werd**

Why: Passives and worden. [[Dutch#^nl-Q0566|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Mijn%20grootvader%20werd%20in%20de%20Tweede%20Wereldoorlog%20gedood.)
^nl-Q0566-answer

**nl-Q0567** — Hij werd wakker door luid geklop op de deur.

A loud knocking at the door woke him up.

Expected form: **werd**

Why: Passives and worden. [[Dutch#^nl-Q0567|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Hij%20werd%20wakker%20door%20luid%20geklop%20op%20de%20deur.)
^nl-Q0567-answer

**nl-Q0568** — Hij werd wakker door luid geklop op de deur.

A loud knocking at the door woke him up.

Why: Passives and worden. [[Dutch#^nl-Q0568|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Hij%20werd%20wakker%20door%20luid%20geklop%20op%20de%20deur.)
^nl-Q0568-answer

**nl-Q0569** — Het wordt tijd dat je naar de kapper gaat.

It's about time you went to the barber's.

Why: Passives and worden. [[Dutch#^nl-Q0569|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Het%20wordt%20tijd%20dat%20je%20naar%20de%20kapper%20gaat.)
^nl-Q0569-answer

**nl-Q0570** — Het wordt tijd dat je naar de kapper gaat.

It's about time you went to the barber's.

Worden plus participle commonly forms an event passive. Worden can also mean become. Inspect the complete predicate before naming the construction.

Why: Passives and worden. [[Dutch#^nl-Q0570|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Het%20wordt%20tijd%20dat%20je%20naar%20de%20kapper%20gaat.)
^nl-Q0570-answer

**nl-Q0571** — Buiten wordt het steeds lichter.

It is getting lighter outside.

Expected form: **wordt**

Why: Passives and worden. [[Dutch#^nl-Q0571|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Buiten%20wordt%20het%20steeds%20lichter.)
^nl-Q0571-answer

**nl-Q0572** — Buiten wordt het steeds lichter.

It is getting lighter outside.

Expected form: **wordt**

Why: Passives and worden. [[Dutch#^nl-Q0572|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Buiten%20wordt%20het%20steeds%20lichter.)
^nl-Q0572-answer

**nl-Q0573** — Ze werden gedwongen hun huis tegen hun wil in te verlaten.

They were forced to leave the house against their will.

Expected form: **werden**

Why: Passives and worden. [[Dutch#^nl-Q0573|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ze%20werden%20gedwongen%20hun%20huis%20tegen%20hun%20wil%20in%20te%20verlaten.)
^nl-Q0573-answer

**nl-Q0574** — Ze werden gedwongen hun huis tegen hun wil in te verlaten.

They were forced to leave the house against their will.

Why: Passives and worden. [[Dutch#^nl-Q0574|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ze%20werden%20gedwongen%20hun%20huis%20tegen%20hun%20wil%20in%20te%20verlaten.)
^nl-Q0574-answer

**nl-Q0575** — Hij werd gisteren geopereerd.

He was operated on yesterday.

Why: Passives and worden. [[Dutch#^nl-Q0575|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Hij%20werd%20gisteren%20geopereerd.)
^nl-Q0575-answer

**nl-Q0576** — Hij werd gisteren geopereerd.

He was operated on yesterday.

Worden plus participle commonly forms an event passive. Worden can also mean become. Inspect the complete predicate before naming the construction.

Why: Passives and worden. [[Dutch#^nl-Q0576|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Hij%20werd%20gisteren%20geopereerd.)
^nl-Q0576-answer

**nl-Q0577** — Veel werk kan vermeden worden.

A lot of work can be avoided.

Expected form: **worden**

Why: Passives and worden. [[Dutch#^nl-Q0577|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Veel%20werk%20kan%20vermeden%20worden.)
^nl-Q0577-answer

**nl-Q0578** — Veel werk kan vermeden worden.

A lot of work can be avoided.

Expected form: **worden**

Why: Passives and worden. [[Dutch#^nl-Q0578|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Veel%20werk%20kan%20vermeden%20worden.)
^nl-Q0578-answer

**nl-Q0579** — In 2003 werd Niue de eerste "wifi"-natie ter wereld.

In 2003, Niue became the first "Wi-fi" nation in the world.

Expected form: **werd**

Why: Passives and worden. [[Dutch#^nl-Q0579|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=In%202003%20werd%20Niue%20de%20eerste%20%22wifi%22-natie%20ter%20wereld.)
^nl-Q0579-answer

**nl-Q0580** — In 2003 werd Niue de eerste "wifi"-natie ter wereld.

In 2003, Niue became the first "Wi-fi" nation in the world.

Why: Passives and worden. [[Dutch#^nl-Q0580|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=In%202003%20werd%20Niue%20de%20eerste%20%22wifi%22-natie%20ter%20wereld.)
^nl-Q0580-answer

**nl-Q0581** — Tom wil leuk gevonden worden.

Tom wants to be liked.

Why: Passives and worden. [[Dutch#^nl-Q0581|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Tom%20wil%20leuk%20gevonden%20worden.)
^nl-Q0581-answer

**nl-Q0582** — Tom wil leuk gevonden worden.

Tom wants to be liked.

Worden plus participle commonly forms an event passive. Worden can also mean become. Inspect the complete predicate before naming the construction.

Why: Passives and worden. [[Dutch#^nl-Q0582|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Tom%20wil%20leuk%20gevonden%20worden.)
^nl-Q0582-answer

**nl-Q0583** — Niemand kan een dichter worden.

No one can be a poet.

Expected form: **worden**

Why: Passives and worden. [[Dutch#^nl-Q0583|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Niemand%20kan%20een%20dichter%20worden.)
^nl-Q0583-answer

**nl-Q0584** — Niemand kan een dichter worden.

No one can be a poet.

Expected form: **worden**

Why: Passives and worden. [[Dutch#^nl-Q0584|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Niemand%20kan%20een%20dichter%20worden.)
^nl-Q0584-answer

**nl-Q0585** — Vlaamse Gebarentaal wordt afgekort als VGT.

Flemish Sign Language is abbreviated to VGT.

Expected form: **wordt**

Why: Passives and worden. [[Dutch#^nl-Q0585|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Vlaamse%20Gebarentaal%20wordt%20afgekort%20als%20VGT.)
^nl-Q0585-answer

**nl-Q0586** — Vlaamse Gebarentaal wordt afgekort als VGT.

Flemish Sign Language is abbreviated to VGT.

Why: Passives and worden. [[Dutch#^nl-Q0586|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Vlaamse%20Gebarentaal%20wordt%20afgekort%20als%20VGT.)
^nl-Q0586-answer

**nl-Q0587** — Ze werd op aids getest.

She got tested for HIV.

Why: Passives and worden. [[Dutch#^nl-Q0587|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ze%20werd%20op%20aids%20getest.)
^nl-Q0587-answer

**nl-Q0588** — Ze werd op aids getest.

She got tested for HIV.

Worden plus participle commonly forms an event passive. Worden can also mean become. Inspect the complete predicate before naming the construction.

Why: Passives and worden. [[Dutch#^nl-Q0588|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ze%20werd%20op%20aids%20getest.)
^nl-Q0588-answer

**nl-Q0589** — Wanneer ik met mijn vingers knip zal je wakker worden.

When I snap my fingers, you'll wake up.

Expected form: **worden**

Why: Passives and worden. [[Dutch#^nl-Q0589|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Wanneer%20ik%20met%20mijn%20vingers%20knip%20zal%20je%20wakker%20worden.)
^nl-Q0589-answer

**nl-Q0590** — Wanneer ik met mijn vingers knip zal je wakker worden.

When I snap my fingers, you'll wake up.

Expected form: **worden**

Why: Passives and worden. [[Dutch#^nl-Q0590|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Wanneer%20ik%20met%20mijn%20vingers%20knip%20zal%20je%20wakker%20worden.)
^nl-Q0590-answer

**nl-Q0591** — Als ik later groot ben, word ik piloot. En wat wil jij worden?

When I grow up, I'll be a pilot. And what will you be?

Expected form: **worden**

Why: Passives and worden. [[Dutch#^nl-Q0591|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Als%20ik%20later%20groot%20ben%2C%20word%20ik%20piloot.%20En%20wat%20wil%20jij%20worden%3F)
^nl-Q0591-answer

**nl-Q0592** — Als ik later groot ben, word ik piloot. En wat wil jij worden?

When I grow up, I'll be a pilot. And what will you be?

Why: Passives and worden. [[Dutch#^nl-Q0592|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Als%20ik%20later%20groot%20ben%2C%20word%20ik%20piloot.%20En%20wat%20wil%20jij%20worden%3F)
^nl-Q0592-answer

**nl-Q0593** — Appels werden als nagerecht geserveerd.

Apples were served as the dessert.

Why: Passives and worden. [[Dutch#^nl-Q0593|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Appels%20werden%20als%20nagerecht%20geserveerd.)
^nl-Q0593-answer

**nl-Q0594** — Appels werden als nagerecht geserveerd.

Apples were served as the dessert.

Worden plus participle commonly forms an event passive. Worden can also mean become. Inspect the complete predicate before naming the construction.

Why: Passives and worden. [[Dutch#^nl-Q0594|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Appels%20werden%20als%20nagerecht%20geserveerd.)
^nl-Q0594-answer

**nl-Q0595** — Waarom wil je verpleger worden?

Why do you want to be a nurse?

Expected form: **worden**

Why: Passives and worden. [[Dutch#^nl-Q0595|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Waarom%20wil%20je%20verpleger%20worden%3F)
^nl-Q0595-answer

**nl-Q0596** — Waarom wil je verpleger worden?

Why do you want to be a nurse?

Expected form: **worden**

Why: Passives and worden. [[Dutch#^nl-Q0596|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Waarom%20wil%20je%20verpleger%20worden%3F)
^nl-Q0596-answer

**nl-Q0597** — Zij wil een zanger worden.

She wants to be a singer.

Expected form: **worden**

Why: Passives and worden. [[Dutch#^nl-Q0597|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Zij%20wil%20een%20zanger%20worden.)
^nl-Q0597-answer

**nl-Q0598** — Zij wil een zanger worden.

She wants to be a singer.

Why: Passives and worden. [[Dutch#^nl-Q0598|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Zij%20wil%20een%20zanger%20worden.)
^nl-Q0598-answer

**nl-Q0599** — De Verenigde Arabische Emiraten worden ''Al-’Imārat Al-‘Arabiyyah Al-Muttaḥidah'' genoemd in het Arabisch.

The United Arab Emirates is called "Al-’Imārat Al-‘Arabiyyah Al-Muttaḥidah" in Arabic.

Why: Passives and worden. [[Dutch#^nl-Q0599|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=De%20Verenigde%20Arabische%20Emiraten%20worden%20%27%27Al-%E2%80%99Im%C4%81rat%20Al-%E2%80%98Arabiyyah%20Al-Mutta%E1%B8%A5idah%27%27%20genoemd%20in%20het%20Arabisch.)
^nl-Q0599-answer

**nl-Q0600** — De Verenigde Arabische Emiraten worden ''Al-’Imārat Al-‘Arabiyyah Al-Muttaḥidah'' genoemd in het Arabisch.

The United Arab Emirates is called "Al-’Imārat Al-‘Arabiyyah Al-Muttaḥidah" in Arabic.

Worden plus participle commonly forms an event passive. Worden can also mean become. Inspect the complete predicate before naming the construction.

Why: Passives and worden. [[Dutch#^nl-Q0600|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=De%20Verenigde%20Arabische%20Emiraten%20worden%20%27%27Al-%E2%80%99Im%C4%81rat%20Al-%E2%80%98Arabiyyah%20Al-Mutta%E1%B8%A5idah%27%27%20genoemd%20in%20het%20Arabisch.)
^nl-Q0600-answer


### Answers 601–650

**nl-Q0601** — Alle zinnen die we verzamelen geven we uit onder de licentie Creatieve Commons - Naamsvermelding.

We're releasing all the sentences we collect under the Creative Commons Attribution license.

Expected form: **die**

Why: Relative pronouns. [[Dutch#^nl-Q0601|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Alle%20zinnen%20die%20we%20verzamelen%20geven%20we%20uit%20onder%20de%20licentie%20Creatieve%20Commons%20-%20Naamsvermelding.)
^nl-Q0601-answer

**nl-Q0602** — Alle zinnen die we verzamelen geven we uit onder de licentie Creatieve Commons - Naamsvermelding.

We're releasing all the sentences we collect under the Creative Commons Attribution license.

Expected form: **die**

Why: Relative pronouns. [[Dutch#^nl-Q0602|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Alle%20zinnen%20die%20we%20verzamelen%20geven%20we%20uit%20onder%20de%20licentie%20Creatieve%20Commons%20-%20Naamsvermelding.)
^nl-Q0602-answer

**nl-Q0603** — Wat is je meest geliefde vakantiebestemming?

What's your favorite vacation place?

Expected form: **Wat**

Why: Relative pronouns. [[Dutch#^nl-Q0603|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Wat%20is%20je%20meest%20geliefde%20vakantiebestemming%3F)
^nl-Q0603-answer

**nl-Q0604** — Wat is je meest geliefde vakantiebestemming?

What's your favorite vacation place?

Why: Relative pronouns. [[Dutch#^nl-Q0604|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Wat%20is%20je%20meest%20geliefde%20vakantiebestemming%3F)
^nl-Q0604-answer

**nl-Q0605** — Van wie zijn de sleutels?

Who do the keys belong to?

Why: Relative pronouns. [[Dutch#^nl-Q0605|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Van%20wie%20zijn%20de%20sleutels%3F)
^nl-Q0605-answer

**nl-Q0606** — Van wie zijn de sleutels?

Who do the keys belong to?

Die generally relates to de nouns and plurals; dat to singular het nouns. Wie/wat occur in other relative and interrogative constructions. The relative clause has subordinate word order.

Why: Relative pronouns. [[Dutch#^nl-Q0606|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Van%20wie%20zijn%20de%20sleutels%3F)
^nl-Q0606-answer

**nl-Q0607** — Wie zijt gij?

Who are you?

Expected form: **Wie**

Why: Relative pronouns. [[Dutch#^nl-Q0607|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Wie%20zijt%20gij%3F)
^nl-Q0607-answer

**nl-Q0608** — Wie zijt gij?

Who are you?

Expected form: **Wie**

Why: Relative pronouns. [[Dutch#^nl-Q0608|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Wie%20zijt%20gij%3F)
^nl-Q0608-answer

**nl-Q0609** — Ik weet dat Tom gemotiveerd is.

I know that Tom is motivated.

Expected form: **dat**

Why: Relative pronouns. [[Dutch#^nl-Q0609|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20weet%20dat%20Tom%20gemotiveerd%20is.)
^nl-Q0609-answer

**nl-Q0610** — Ik weet dat Tom gemotiveerd is.

I know that Tom is motivated.

Why: Relative pronouns. [[Dutch#^nl-Q0610|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20weet%20dat%20Tom%20gemotiveerd%20is.)
^nl-Q0610-answer

**nl-Q0611** — Juliana vertelde me dat je uit São Paulo komt.

Juliana told me you're from São Paulo.

Why: Relative pronouns. [[Dutch#^nl-Q0611|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Juliana%20vertelde%20me%20dat%20je%20uit%20S%C3%A3o%20Paulo%20komt.)
^nl-Q0611-answer

**nl-Q0612** — Juliana vertelde me dat je uit São Paulo komt.

Juliana told me you're from São Paulo.

Die generally relates to de nouns and plurals; dat to singular het nouns. Wie/wat occur in other relative and interrogative constructions. The relative clause has subordinate word order.

Why: Relative pronouns. [[Dutch#^nl-Q0612|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Juliana%20vertelde%20me%20dat%20je%20uit%20S%C3%A3o%20Paulo%20komt.)
^nl-Q0612-answer

**nl-Q0613** — Tom en Maria beweren dat ze nooit tegen elkaar liegen.

Tom and Mary claim that they never lie to each other.

Expected form: **dat**

Why: Relative pronouns. [[Dutch#^nl-Q0613|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Tom%20en%20Maria%20beweren%20dat%20ze%20nooit%20tegen%20elkaar%20liegen.)
^nl-Q0613-answer

**nl-Q0614** — Tom en Maria beweren dat ze nooit tegen elkaar liegen.

Tom and Mary claim that they never lie to each other.

Expected form: **dat**

Why: Relative pronouns. [[Dutch#^nl-Q0614|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Tom%20en%20Maria%20beweren%20dat%20ze%20nooit%20tegen%20elkaar%20liegen.)
^nl-Q0614-answer

**nl-Q0615** — Dat kind wierp een steen naar de hond.

That child threw a stone at the dog.

Expected form: **Dat**

Why: Relative pronouns. [[Dutch#^nl-Q0615|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Dat%20kind%20wierp%20een%20steen%20naar%20de%20hond.)
^nl-Q0615-answer

**nl-Q0616** — Dat kind wierp een steen naar de hond.

That child threw a stone at the dog.

Why: Relative pronouns. [[Dutch#^nl-Q0616|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Dat%20kind%20wierp%20een%20steen%20naar%20de%20hond.)
^nl-Q0616-answer

**nl-Q0617** — Onthou goed wat ge op school leert.

Remember well what you learn at school.

Why: Relative pronouns. [[Dutch#^nl-Q0617|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Onthou%20goed%20wat%20ge%20op%20school%20leert.)
^nl-Q0617-answer

**nl-Q0618** — Onthou goed wat ge op school leert.

Remember well what you learn at school.

Die generally relates to de nouns and plurals; dat to singular het nouns. Wie/wat occur in other relative and interrogative constructions. The relative clause has subordinate word order.

Why: Relative pronouns. [[Dutch#^nl-Q0618|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Onthou%20goed%20wat%20ge%20op%20school%20leert.)
^nl-Q0618-answer

**nl-Q0619** — Dat bracht me aan het lachen.

That made me laugh.

Expected form: **Dat**

Why: Relative pronouns. [[Dutch#^nl-Q0619|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Dat%20bracht%20me%20aan%20het%20lachen.)
^nl-Q0619-answer

**nl-Q0620** — Dat bracht me aan het lachen.

That made me laugh.

Expected form: **Dat**

Why: Relative pronouns. [[Dutch#^nl-Q0620|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Dat%20bracht%20me%20aan%20het%20lachen.)
^nl-Q0620-answer

**nl-Q0621** — Ik zag wat je hond deed.

I saw what your dog did.

Expected form: **wat**

Why: Relative pronouns. [[Dutch#^nl-Q0621|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20zag%20wat%20je%20hond%20deed.)
^nl-Q0621-answer

**nl-Q0622** — Ik zag wat je hond deed.

I saw what your dog did.

Why: Relative pronouns. [[Dutch#^nl-Q0622|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20zag%20wat%20je%20hond%20deed.)
^nl-Q0622-answer

**nl-Q0623** — Met wie woon je?

Who do you live with?

Why: Relative pronouns. [[Dutch#^nl-Q0623|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Met%20wie%20woon%20je%3F)
^nl-Q0623-answer

**nl-Q0624** — Met wie woon je?

Who do you live with?

Die generally relates to de nouns and plurals; dat to singular het nouns. Wie/wat occur in other relative and interrogative constructions. The relative clause has subordinate word order.

Why: Relative pronouns. [[Dutch#^nl-Q0624|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Met%20wie%20woon%20je%3F)
^nl-Q0624-answer

**nl-Q0625** — Wat mij betreft is Twitter tijdverspilling.

In my opinion, Twitter is a waste of time.

Expected form: **Wat**

Why: Relative pronouns. [[Dutch#^nl-Q0625|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Wat%20mij%20betreft%20is%20Twitter%20tijdverspilling.)
^nl-Q0625-answer

**nl-Q0626** — Wat mij betreft is Twitter tijdverspilling.

In my opinion, Twitter is a waste of time.

Expected form: **Wat**

Why: Relative pronouns. [[Dutch#^nl-Q0626|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Wat%20mij%20betreft%20is%20Twitter%20tijdverspilling.)
^nl-Q0626-answer

**nl-Q0627** — Die lamp ziet er leuk uit.

That lamp looks nice.

Expected form: **Die**

Why: Relative pronouns. [[Dutch#^nl-Q0627|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Die%20lamp%20ziet%20er%20leuk%20uit.)
^nl-Q0627-answer

**nl-Q0628** — Die lamp ziet er leuk uit.

That lamp looks nice.

Why: Relative pronouns. [[Dutch#^nl-Q0628|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Die%20lamp%20ziet%20er%20leuk%20uit.)
^nl-Q0628-answer

**nl-Q0629** — Wie e-mail je?

Who are you emailing?

Why: Relative pronouns. [[Dutch#^nl-Q0629|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Wie%20e-mail%20je%3F)
^nl-Q0629-answer

**nl-Q0630** — Wie e-mail je?

Who are you emailing?

Die generally relates to de nouns and plurals; dat to singular het nouns. Wie/wat occur in other relative and interrogative constructions. The relative clause has subordinate word order.

Why: Relative pronouns. [[Dutch#^nl-Q0630|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Wie%20e-mail%20je%3F)
^nl-Q0630-answer

**nl-Q0631** — Dat zien we later wel.

We'll see about that later.

Expected form: **Dat**

Why: Relative pronouns. [[Dutch#^nl-Q0631|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Dat%20zien%20we%20later%20wel.)
^nl-Q0631-answer

**nl-Q0632** — Dat zien we later wel.

We'll see about that later.

Expected form: **Dat**

Why: Relative pronouns. [[Dutch#^nl-Q0632|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Dat%20zien%20we%20later%20wel.)
^nl-Q0632-answer

**nl-Q0633** — Ik probeer Tom over te halen dat te doen.

I'm trying to convince Tom to do that.

Expected form: **dat**

Why: Relative pronouns. [[Dutch#^nl-Q0633|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20probeer%20Tom%20over%20te%20halen%20dat%20te%20doen.)
^nl-Q0633-answer

**nl-Q0634** — Ik probeer Tom over te halen dat te doen.

I'm trying to convince Tom to do that.

Why: Relative pronouns. [[Dutch#^nl-Q0634|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20probeer%20Tom%20over%20te%20halen%20dat%20te%20doen.)
^nl-Q0634-answer

**nl-Q0635** — Waarom hebt gij altijd die hoed op?

Why do you always wear that hat?

Why: Relative pronouns. [[Dutch#^nl-Q0635|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Waarom%20hebt%20gij%20altijd%20die%20hoed%20op%3F)
^nl-Q0635-answer

**nl-Q0636** — Waarom hebt gij altijd die hoed op?

Why do you always wear that hat?

Die generally relates to de nouns and plurals; dat to singular het nouns. Wie/wat occur in other relative and interrogative constructions. The relative clause has subordinate word order.

Why: Relative pronouns. [[Dutch#^nl-Q0636|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Waarom%20hebt%20gij%20altijd%20die%20hoed%20op%3F)
^nl-Q0636-answer

**nl-Q0637** — Als jij nou zegt: "Ik hou van jou," dan zeg ik dat ook tegen jou.

If you say, "I love you," then I will also say that to you.

Expected form: **dat**

Why: Relative pronouns. [[Dutch#^nl-Q0637|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Als%20jij%20nou%20zegt%3A%20%22Ik%20hou%20van%20jou%2C%22%20dan%20zeg%20ik%20dat%20ook%20tegen%20jou.)
^nl-Q0637-answer

**nl-Q0638** — Als jij nou zegt: "Ik hou van jou," dan zeg ik dat ook tegen jou.

If you say, "I love you," then I will also say that to you.

Expected form: **dat**

Why: Relative pronouns. [[Dutch#^nl-Q0638|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Als%20jij%20nou%20zegt%3A%20%22Ik%20hou%20van%20jou%2C%22%20dan%20zeg%20ik%20dat%20ook%20tegen%20jou.)
^nl-Q0638-answer

**nl-Q0639** — Dat is te klein om op je hoofd te passen.

That's too small to fit on your head.

Expected form: **Dat**

Why: Relative pronouns. [[Dutch#^nl-Q0639|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Dat%20is%20te%20klein%20om%20op%20je%20hoofd%20te%20passen.)
^nl-Q0639-answer

**nl-Q0640** — Dat is te klein om op je hoofd te passen.

That's too small to fit on your head.

Why: Relative pronouns. [[Dutch#^nl-Q0640|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Dat%20is%20te%20klein%20om%20op%20je%20hoofd%20te%20passen.)
^nl-Q0640-answer

**nl-Q0641** — Je moet beginnen met boeken die je makkelijk kan begrijpen.

You should begin with books you can easily understand.

Why: Relative pronouns. [[Dutch#^nl-Q0641|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Je%20moet%20beginnen%20met%20boeken%20die%20je%20makkelijk%20kan%20begrijpen.)
^nl-Q0641-answer

**nl-Q0642** — Je moet beginnen met boeken die je makkelijk kan begrijpen.

You should begin with books you can easily understand.

Die generally relates to de nouns and plurals; dat to singular het nouns. Wie/wat occur in other relative and interrogative constructions. The relative clause has subordinate word order.

Why: Relative pronouns. [[Dutch#^nl-Q0642|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Je%20moet%20beginnen%20met%20boeken%20die%20je%20makkelijk%20kan%20begrijpen.)
^nl-Q0642-answer

**nl-Q0643** — Ik ben teleurgesteld dat mijn vrienden niet hier zijn.

I am disappointed that my friends are not here.

Expected form: **dat**

Why: Relative pronouns. [[Dutch#^nl-Q0643|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20ben%20teleurgesteld%20dat%20mijn%20vrienden%20niet%20hier%20zijn.)
^nl-Q0643-answer

**nl-Q0644** — Ik ben teleurgesteld dat mijn vrienden niet hier zijn.

I am disappointed that my friends are not here.

Expected form: **dat**

Why: Relative pronouns. [[Dutch#^nl-Q0644|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20ben%20teleurgesteld%20dat%20mijn%20vrienden%20niet%20hier%20zijn.)
^nl-Q0644-answer

**nl-Q0645** — Ik herinner me die muziek ooit ergens gehoord te hebben.

I remember hearing that music somewhere.

Expected form: **die**

Why: Relative pronouns. [[Dutch#^nl-Q0645|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20herinner%20me%20die%20muziek%20ooit%20ergens%20gehoord%20te%20hebben.)
^nl-Q0645-answer

**nl-Q0646** — Ik herinner me die muziek ooit ergens gehoord te hebben.

I remember hearing that music somewhere.

Why: Relative pronouns. [[Dutch#^nl-Q0646|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20herinner%20me%20die%20muziek%20ooit%20ergens%20gehoord%20te%20hebben.)
^nl-Q0646-answer

**nl-Q0647** — Ik kan dat niet alleen doen.

I can't do that alone.

Why: Relative pronouns. [[Dutch#^nl-Q0647|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20kan%20dat%20niet%20alleen%20doen.)
^nl-Q0647-answer

**nl-Q0648** — Ik kan dat niet alleen doen.

I can't do that alone.

Die generally relates to de nouns and plurals; dat to singular het nouns. Wie/wat occur in other relative and interrogative constructions. The relative clause has subordinate word order.

Why: Relative pronouns. [[Dutch#^nl-Q0648|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20kan%20dat%20niet%20alleen%20doen.)
^nl-Q0648-answer

**nl-Q0649** — Doe wat men je zegt.

Do what you're told.

Expected form: **wat**

Why: Relative pronouns. [[Dutch#^nl-Q0649|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Doe%20wat%20men%20je%20zegt.)
^nl-Q0649-answer

**nl-Q0650** — Doe wat men je zegt.

Do what you're told.

Expected form: **wat**

Why: Relative pronouns. [[Dutch#^nl-Q0650|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Doe%20wat%20men%20je%20zegt.)
^nl-Q0650-answer


### Answers 651–700

**nl-Q0651** — De oude man zag er wijs uit.

The old man looked wise.

Expected form: **er**

Why: Er in context. [[Dutch#^nl-Q0651|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=De%20oude%20man%20zag%20er%20wijs%20uit.)
^nl-Q0651-answer

**nl-Q0652** — De oude man zag er wijs uit.

The old man looked wise.

Why: Er in context. [[Dutch#^nl-Q0652|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=De%20oude%20man%20zag%20er%20wijs%20uit.)
^nl-Q0652-answer

**nl-Q0653** — Er zijn veel dieren te zien in dit bos.

You can see many animals in this forest.

Why: Er in context. [[Dutch#^nl-Q0653|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Er%20zijn%20veel%20dieren%20te%20zien%20in%20dit%20bos.)
^nl-Q0653-answer

**nl-Q0654** — Er zijn veel dieren te zien in dit bos.

You can see many animals in this forest.

Er can express a location, introduce an existence statement, support a quantity or occur in a pronominal adverb. Analyse its actual construction instead of assigning one English equivalent.

Why: Er in context. [[Dutch#^nl-Q0654|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Er%20zijn%20veel%20dieren%20te%20zien%20in%20dit%20bos.)
^nl-Q0654-answer

**nl-Q0655** — Er zijn veel boeken in mijn kamer.

There are many books in my room.

Expected form: **Er**

Why: Er in context. [[Dutch#^nl-Q0655|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Er%20zijn%20veel%20boeken%20in%20mijn%20kamer.)
^nl-Q0655-answer

**nl-Q0656** — Er zijn veel boeken in mijn kamer.

There are many books in my room.

Expected form: **Er**

Why: Er in context. [[Dutch#^nl-Q0656|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Er%20zijn%20veel%20boeken%20in%20mijn%20kamer.)
^nl-Q0656-answer

**nl-Q0657** — Er zitten veertig leerlingen in onze klas.

There are forty students in our class.

Expected form: **Er**

Why: Er in context. [[Dutch#^nl-Q0657|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Er%20zitten%20veertig%20leerlingen%20in%20onze%20klas.)
^nl-Q0657-answer

**nl-Q0658** — Er zitten veertig leerlingen in onze klas.

There are forty students in our class.

Why: Er in context. [[Dutch#^nl-Q0658|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Er%20zitten%20veertig%20leerlingen%20in%20onze%20klas.)
^nl-Q0658-answer

**nl-Q0659** — Er is gisternacht een brand uitgebroken.

A fire broke out last night.

Why: Er in context. [[Dutch#^nl-Q0659|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Er%20is%20gisternacht%20een%20brand%20uitgebroken.)
^nl-Q0659-answer

**nl-Q0660** — Er is gisternacht een brand uitgebroken.

A fire broke out last night.

Er can express a location, introduce an existence statement, support a quantity or occur in a pronominal adverb. Analyse its actual construction instead of assigning one English equivalent.

Why: Er in context. [[Dutch#^nl-Q0660|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Er%20is%20gisternacht%20een%20brand%20uitgebroken.)
^nl-Q0660-answer

**nl-Q0661** — De school ziet er uit als een gevangenis.

The school looks like a prison.

Expected form: **er**

Why: Er in context. [[Dutch#^nl-Q0661|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=De%20school%20ziet%20er%20uit%20als%20een%20gevangenis.)
^nl-Q0661-answer

**nl-Q0662** — De school ziet er uit als een gevangenis.

The school looks like a prison.

Expected form: **er**

Why: Er in context. [[Dutch#^nl-Q0662|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=De%20school%20ziet%20er%20uit%20als%20een%20gevangenis.)
^nl-Q0662-answer

**nl-Q0663** — Er bevonden zich veel vogels in de boom.

There were a lot of birds in the tree.

Expected form: **Er**

Why: Er in context. [[Dutch#^nl-Q0663|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Er%20bevonden%20zich%20veel%20vogels%20in%20de%20boom.)
^nl-Q0663-answer

**nl-Q0664** — Er bevonden zich veel vogels in de boom.

There were a lot of birds in the tree.

Why: Er in context. [[Dutch#^nl-Q0664|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Er%20bevonden%20zich%20veel%20vogels%20in%20de%20boom.)
^nl-Q0664-answer

**nl-Q0665** — Ik ben er zeker van dat je het goed bedoelde.

I'm sure you meant well.

Why: Er in context. [[Dutch#^nl-Q0665|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20ben%20er%20zeker%20van%20dat%20je%20het%20goed%20bedoelde.)
^nl-Q0665-answer

**nl-Q0666** — Ik ben er zeker van dat je het goed bedoelde.

I'm sure you meant well.

Er can express a location, introduce an existence statement, support a quantity or occur in a pronominal adverb. Analyse its actual construction instead of assigning one English equivalent.

Why: Er in context. [[Dutch#^nl-Q0666|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20ben%20er%20zeker%20van%20dat%20je%20het%20goed%20bedoelde.)
^nl-Q0666-answer

**nl-Q0667** — Er is melk in de koelkast.

There is milk in the refrigerator.

Expected form: **Er**

Why: Er in context. [[Dutch#^nl-Q0667|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Er%20is%20melk%20in%20de%20koelkast.)
^nl-Q0667-answer

**nl-Q0668** — Er is melk in de koelkast.

There is milk in the refrigerator.

Expected form: **Er**

Why: Er in context. [[Dutch#^nl-Q0668|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Er%20is%20melk%20in%20de%20koelkast.)
^nl-Q0668-answer

**nl-Q0669** — Er stond een straffe wind.

A strong wind was blowing.

Expected form: **Er**

Why: Er in context. [[Dutch#^nl-Q0669|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Er%20stond%20een%20straffe%20wind.)
^nl-Q0669-answer

**nl-Q0670** — Er stond een straffe wind.

A strong wind was blowing.

Why: Er in context. [[Dutch#^nl-Q0670|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Er%20stond%20een%20straffe%20wind.)
^nl-Q0670-answer

**nl-Q0671** — Wie gaat er nog meer met ons mee?

Who else is going with us?

Why: Er in context. [[Dutch#^nl-Q0671|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Wie%20gaat%20er%20nog%20meer%20met%20ons%20mee%3F)
^nl-Q0671-answer

**nl-Q0672** — Wie gaat er nog meer met ons mee?

Who else is going with us?

Er can express a location, introduce an existence statement, support a quantity or occur in a pronominal adverb. Analyse its actual construction instead of assigning one English equivalent.

Why: Er in context. [[Dutch#^nl-Q0672|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Wie%20gaat%20er%20nog%20meer%20met%20ons%20mee%3F)
^nl-Q0672-answer

**nl-Q0673** — Wie wil er warme chocolademelk?

Who wants some hot chocolate?

Expected form: **er**

Why: Er in context. [[Dutch#^nl-Q0673|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Wie%20wil%20er%20warme%20chocolademelk%3F)
^nl-Q0673-answer

**nl-Q0674** — Wie wil er warme chocolademelk?

Who wants some hot chocolate?

Expected form: **er**

Why: Er in context. [[Dutch#^nl-Q0674|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Wie%20wil%20er%20warme%20chocolademelk%3F)
^nl-Q0674-answer

**nl-Q0675** — Wat is er aan de hand?

What's going on?

Expected form: **er**

Why: Er in context. [[Dutch#^nl-Q0675|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Wat%20is%20er%20aan%20de%20hand%3F)
^nl-Q0675-answer

**nl-Q0676** — Wat is er aan de hand?

What's going on?

Why: Er in context. [[Dutch#^nl-Q0676|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Wat%20is%20er%20aan%20de%20hand%3F)
^nl-Q0676-answer

**nl-Q0677** — Ik keer er terug.

I'll go back there.

Why: Er in context. [[Dutch#^nl-Q0677|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20keer%20er%20terug.)
^nl-Q0677-answer

**nl-Q0678** — Ik keer er terug.

I'll go back there.

Er can express a location, introduce an existence statement, support a quantity or occur in a pronominal adverb. Analyse its actual construction instead of assigning one English equivalent.

Why: Er in context. [[Dutch#^nl-Q0678|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20keer%20er%20terug.)
^nl-Q0678-answer

**nl-Q0679** — Denk je echt dat ik er wat mee te maken had?

Do you really think I had something to do with that?

Expected form: **er**

Why: Er in context. [[Dutch#^nl-Q0679|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Denk%20je%20echt%20dat%20ik%20er%20wat%20mee%20te%20maken%20had%3F)
^nl-Q0679-answer

**nl-Q0680** — Denk je echt dat ik er wat mee te maken had?

Do you really think I had something to do with that?

Expected form: **er**

Why: Er in context. [[Dutch#^nl-Q0680|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Denk%20je%20echt%20dat%20ik%20er%20wat%20mee%20te%20maken%20had%3F)
^nl-Q0680-answer

**nl-Q0681** — Er is tijd genoeg om dit huiswerk af te maken.

There is enough time to finish this homework.

Expected form: **Er**

Why: Er in context. [[Dutch#^nl-Q0681|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Er%20is%20tijd%20genoeg%20om%20dit%20huiswerk%20af%20te%20maken.)
^nl-Q0681-answer

**nl-Q0682** — Er is tijd genoeg om dit huiswerk af te maken.

There is enough time to finish this homework.

Why: Er in context. [[Dutch#^nl-Q0682|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Er%20is%20tijd%20genoeg%20om%20dit%20huiswerk%20af%20te%20maken.)
^nl-Q0682-answer

**nl-Q0683** — Laten we er nog eentje nemen!

Let’s have another!

Why: Er in context. [[Dutch#^nl-Q0683|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Laten%20we%20er%20nog%20eentje%20nemen%21)
^nl-Q0683-answer

**nl-Q0684** — Laten we er nog eentje nemen!

Let’s have another!

Er can express a location, introduce an existence statement, support a quantity or occur in a pronominal adverb. Analyse its actual construction instead of assigning one English equivalent.

Why: Er in context. [[Dutch#^nl-Q0684|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Laten%20we%20er%20nog%20eentje%20nemen%21)
^nl-Q0684-answer

**nl-Q0685** — Er was eens een slechte koning in Engeland.

Once upon a time, there was a bad king in England.

Expected form: **Er**

Why: Er in context. [[Dutch#^nl-Q0685|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Er%20was%20eens%20een%20slechte%20koning%20in%20Engeland.)
^nl-Q0685-answer

**nl-Q0686** — Er was eens een slechte koning in Engeland.

Once upon a time, there was a bad king in England.

Expected form: **Er**

Why: Er in context. [[Dutch#^nl-Q0686|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Er%20was%20eens%20een%20slechte%20koning%20in%20Engeland.)
^nl-Q0686-answer

**nl-Q0687** — Ik geef er geen bal om!

I don't give a damn about it!

Expected form: **er**

Why: Er in context. [[Dutch#^nl-Q0687|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20geef%20er%20geen%20bal%20om%21)
^nl-Q0687-answer

**nl-Q0688** — Ik geef er geen bal om!

I don't give a damn about it!

Why: Er in context. [[Dutch#^nl-Q0688|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20geef%20er%20geen%20bal%20om%21)
^nl-Q0688-answer

**nl-Q0689** — Er zijn geen gay mensen in dit land.

There are no gay people in this country.

Why: Er in context. [[Dutch#^nl-Q0689|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Er%20zijn%20geen%20gay%20mensen%20in%20dit%20land.)
^nl-Q0689-answer

**nl-Q0690** — Er zijn geen gay mensen in dit land.

There are no gay people in this country.

Er can express a location, introduce an existence statement, support a quantity or occur in a pronominal adverb. Analyse its actual construction instead of assigning one English equivalent.

Why: Er in context. [[Dutch#^nl-Q0690|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Er%20zijn%20geen%20gay%20mensen%20in%20dit%20land.)
^nl-Q0690-answer

**nl-Q0691** — We moeten er zeker van zijn dat we gelijk hebben.

We have to be sure we're right.

Expected form: **er**

Why: Er in context. [[Dutch#^nl-Q0691|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=We%20moeten%20er%20zeker%20van%20zijn%20dat%20we%20gelijk%20hebben.)
^nl-Q0691-answer

**nl-Q0692** — We moeten er zeker van zijn dat we gelijk hebben.

We have to be sure we're right.

Expected form: **er**

Why: Er in context. [[Dutch#^nl-Q0692|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=We%20moeten%20er%20zeker%20van%20zijn%20dat%20we%20gelijk%20hebben.)
^nl-Q0692-answer

**nl-Q0693** — Er zijn nu geen woorden nodig, maar daden.

Not words but action is needed now.

Expected form: **Er**

Why: Er in context. [[Dutch#^nl-Q0693|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Er%20zijn%20nu%20geen%20woorden%20nodig%2C%20maar%20daden.)
^nl-Q0693-answer

**nl-Q0694** — Er zijn nu geen woorden nodig, maar daden.

Not words but action is needed now.

Why: Er in context. [[Dutch#^nl-Q0694|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Er%20zijn%20nu%20geen%20woorden%20nodig%2C%20maar%20daden.)
^nl-Q0694-answer

**nl-Q0695** — Er is iets aan Dan veranderd.

Something about Dan has changed.

Why: Er in context. [[Dutch#^nl-Q0695|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Er%20is%20iets%20aan%20Dan%20veranderd.)
^nl-Q0695-answer

**nl-Q0696** — Er is iets aan Dan veranderd.

Something about Dan has changed.

Er can express a location, introduce an existence statement, support a quantity or occur in a pronominal adverb. Analyse its actual construction instead of assigning one English equivalent.

Why: Er in context. [[Dutch#^nl-Q0696|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Er%20is%20iets%20aan%20Dan%20veranderd.)
^nl-Q0696-answer

**nl-Q0697** — Gisteren is er op dat zebrapad een voetganger door een vrachtwagen overreden.

Yesterday a pedestrian was run over by a truck at this pedestrian crossing.

Expected form: **er**

Why: Er in context. [[Dutch#^nl-Q0697|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Gisteren%20is%20er%20op%20dat%20zebrapad%20een%20voetganger%20door%20een%20vrachtwagen%20overreden.)
^nl-Q0697-answer

**nl-Q0698** — Gisteren is er op dat zebrapad een voetganger door een vrachtwagen overreden.

Yesterday a pedestrian was run over by a truck at this pedestrian crossing.

Expected form: **er**

Why: Er in context. [[Dutch#^nl-Q0698|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Gisteren%20is%20er%20op%20dat%20zebrapad%20een%20voetganger%20door%20een%20vrachtwagen%20overreden.)
^nl-Q0698-answer

**nl-Q0699** — Ik ga er alleen heen.

I'm going there alone.

Expected form: **er**

Why: Er in context. [[Dutch#^nl-Q0699|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20ga%20er%20alleen%20heen.)
^nl-Q0699-answer

**nl-Q0700** — Ik ga er alleen heen.

I'm going there alone.

Why: Er in context. [[Dutch#^nl-Q0700|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20ga%20er%20alleen%20heen.)
^nl-Q0700-answer


### Answers 701–750

**nl-Q0701** — Ze ging op haar knieën om te bidden.

She went down on her knees to pray.

Why: Infinitives and purpose. [[Dutch#^nl-Q0701|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ze%20ging%20op%20haar%20knie%C3%ABn%20om%20te%20bidden.)
^nl-Q0701-answer

**nl-Q0702** — Ze ging op haar knieën om te bidden.

She went down on her knees to pray.

Many infinitive complements use te; om ... te commonly expresses purpose. Te can also intensify an adjective, so identify the following phrase.

Why: Infinitives and purpose. [[Dutch#^nl-Q0702|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ze%20ging%20op%20haar%20knie%C3%ABn%20om%20te%20bidden.)
^nl-Q0702-answer

**nl-Q0703** — Tom zat op de bank te roken.

Tom sat on the bench smoking.

Expected form: **te**

Why: Infinitives and purpose. [[Dutch#^nl-Q0703|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Tom%20zat%20op%20de%20bank%20te%20roken.)
^nl-Q0703-answer

**nl-Q0704** — Tom zat op de bank te roken.

Tom sat on the bench smoking.

Expected form: **te**

Why: Infinitives and purpose. [[Dutch#^nl-Q0704|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Tom%20zat%20op%20de%20bank%20te%20roken.)
^nl-Q0704-answer

**nl-Q0705** — Tom rijdt altijd te hard.

Tom always drives too fast.

Expected form: **te**

Why: Infinitives and purpose. [[Dutch#^nl-Q0705|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Tom%20rijdt%20altijd%20te%20hard.)
^nl-Q0705-answer

**nl-Q0706** — Tom rijdt altijd te hard.

Tom always drives too fast.

Why: Infinitives and purpose. [[Dutch#^nl-Q0706|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Tom%20rijdt%20altijd%20te%20hard.)
^nl-Q0706-answer

**nl-Q0707** — Hij heeft aangeboden me te helpen.

He offered to help me.

Why: Infinitives and purpose. [[Dutch#^nl-Q0707|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Hij%20heeft%20aangeboden%20me%20te%20helpen.)
^nl-Q0707-answer

**nl-Q0708** — Hij heeft aangeboden me te helpen.

He offered to help me.

Many infinitive complements use te; om ... te commonly expresses purpose. Te can also intensify an adjective, so identify the following phrase.

Why: Infinitives and purpose. [[Dutch#^nl-Q0708|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Hij%20heeft%20aangeboden%20me%20te%20helpen.)
^nl-Q0708-answer

**nl-Q0709** — Zat je naar mijn benen te staren?

Were you staring at my legs?

Expected form: **te**

Why: Infinitives and purpose. [[Dutch#^nl-Q0709|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Zat%20je%20naar%20mijn%20benen%20te%20staren%3F)
^nl-Q0709-answer

**nl-Q0710** — Zat je naar mijn benen te staren?

Were you staring at my legs?

Expected form: **te**

Why: Infinitives and purpose. [[Dutch#^nl-Q0710|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Zat%20je%20naar%20mijn%20benen%20te%20staren%3F)
^nl-Q0710-answer

**nl-Q0711** — Hoelang gaat het duren om daar te komen?

How long will it take to get there?

Expected form: **om**

Why: Infinitives and purpose. [[Dutch#^nl-Q0711|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Hoelang%20gaat%20het%20duren%20om%20daar%20te%20komen%3F)
^nl-Q0711-answer

**nl-Q0712** — Hoelang gaat het duren om daar te komen?

How long will it take to get there?

Why: Infinitives and purpose. [[Dutch#^nl-Q0712|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Hoelang%20gaat%20het%20duren%20om%20daar%20te%20komen%3F)
^nl-Q0712-answer

**nl-Q0713** — Hé, jij kunt tikken zonder te kijken naar het toetsenbord. Cool zeg!

Oh? You can type without looking at the keyboard. That's cool!

Why: Infinitives and purpose. [[Dutch#^nl-Q0713|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=H%C3%A9%2C%20jij%20kunt%20tikken%20zonder%20te%20kijken%20naar%20het%20toetsenbord.%20Cool%20zeg%21)
^nl-Q0713-answer

**nl-Q0714** — Hé, jij kunt tikken zonder te kijken naar het toetsenbord. Cool zeg!

Oh? You can type without looking at the keyboard. That's cool!

Many infinitive complements use te; om ... te commonly expresses purpose. Te can also intensify an adjective, so identify the following phrase.

Why: Infinitives and purpose. [[Dutch#^nl-Q0714|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=H%C3%A9%2C%20jij%20kunt%20tikken%20zonder%20te%20kijken%20naar%20het%20toetsenbord.%20Cool%20zeg%21)
^nl-Q0714-answer

**nl-Q0715** — De tijd is om.

Time is up.

Expected form: **om**

Why: Infinitives and purpose. [[Dutch#^nl-Q0715|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=De%20tijd%20is%20om.)
^nl-Q0715-answer

**nl-Q0716** — De tijd is om.

Time is up.

Expected form: **om**

Why: Infinitives and purpose. [[Dutch#^nl-Q0716|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=De%20tijd%20is%20om.)
^nl-Q0716-answer

**nl-Q0717** — Dima paste het pak, maar het bleek te groot te zijn.

Trying on the suit, Dima found it to be too big.

Expected form: **te**

Why: Infinitives and purpose. [[Dutch#^nl-Q0717|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Dima%20paste%20het%20pak%2C%20maar%20het%20bleek%20te%20groot%20te%20zijn.)
^nl-Q0717-answer

**nl-Q0718** — Dima paste het pak, maar het bleek te groot te zijn.

Trying on the suit, Dima found it to be too big.

Why: Infinitives and purpose. [[Dutch#^nl-Q0718|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Dima%20paste%20het%20pak%2C%20maar%20het%20bleek%20te%20groot%20te%20zijn.)
^nl-Q0718-answer

**nl-Q0719** — Kies een kaart om weg te gooien.

Choose which card to discard.

Why: Infinitives and purpose. [[Dutch#^nl-Q0719|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Kies%20een%20kaart%20om%20weg%20te%20gooien.)
^nl-Q0719-answer

**nl-Q0720** — Kies een kaart om weg te gooien.

Choose which card to discard.

Many infinitive complements use te; om ... te commonly expresses purpose. Te can also intensify an adjective, so identify the following phrase.

Why: Infinitives and purpose. [[Dutch#^nl-Q0720|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Kies%20een%20kaart%20om%20weg%20te%20gooien.)
^nl-Q0720-answer

**nl-Q0721** — Deze vogel dreigt nu uit te sterven.

That bird is now in danger of dying out.

Expected form: **te**

Why: Infinitives and purpose. [[Dutch#^nl-Q0721|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Deze%20vogel%20dreigt%20nu%20uit%20te%20sterven.)
^nl-Q0721-answer

**nl-Q0722** — Deze vogel dreigt nu uit te sterven.

That bird is now in danger of dying out.

Expected form: **te**

Why: Infinitives and purpose. [[Dutch#^nl-Q0722|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Deze%20vogel%20dreigt%20nu%20uit%20te%20sterven.)
^nl-Q0722-answer

**nl-Q0723** — Hebt ge tijd om mij te helpen?

Do you have time to help me?

Expected form: **om**

Why: Infinitives and purpose. [[Dutch#^nl-Q0723|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Hebt%20ge%20tijd%20om%20mij%20te%20helpen%3F)
^nl-Q0723-answer

**nl-Q0724** — Hebt ge tijd om mij te helpen?

Do you have time to help me?

Why: Infinitives and purpose. [[Dutch#^nl-Q0724|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Hebt%20ge%20tijd%20om%20mij%20te%20helpen%3F)
^nl-Q0724-answer

**nl-Q0725** — Tom besloot een tweedehandsauto te kopen in plaats van een nieuwe.

Tom decided to buy a used car instead of a new one.

Why: Infinitives and purpose. [[Dutch#^nl-Q0725|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Tom%20besloot%20een%20tweedehandsauto%20te%20kopen%20in%20plaats%20van%20een%20nieuwe.)
^nl-Q0725-answer

**nl-Q0726** — Tom besloot een tweedehandsauto te kopen in plaats van een nieuwe.

Tom decided to buy a used car instead of a new one.

Many infinitive complements use te; om ... te commonly expresses purpose. Te can also intensify an adjective, so identify the following phrase.

Why: Infinitives and purpose. [[Dutch#^nl-Q0726|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Tom%20besloot%20een%20tweedehandsauto%20te%20kopen%20in%20plaats%20van%20een%20nieuwe.)
^nl-Q0726-answer

**nl-Q0727** — Kan je wachten tot vanmiddag om 2:30 uur?

Can you wait until 2:30 this afternoon?

Expected form: **om**

Why: Infinitives and purpose. [[Dutch#^nl-Q0727|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Kan%20je%20wachten%20tot%20vanmiddag%20om%202%3A30%20uur%3F)
^nl-Q0727-answer

**nl-Q0728** — Kan je wachten tot vanmiddag om 2:30 uur?

Can you wait until 2:30 this afternoon?

Expected form: **om**

Why: Infinitives and purpose. [[Dutch#^nl-Q0728|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Kan%20je%20wachten%20tot%20vanmiddag%20om%202%3A30%20uur%3F)
^nl-Q0728-answer

**nl-Q0729** — Jij hoort beneden te zijn.

You're supposed to be downstairs.

Expected form: **te**

Why: Infinitives and purpose. [[Dutch#^nl-Q0729|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Jij%20hoort%20beneden%20te%20zijn.)
^nl-Q0729-answer

**nl-Q0730** — Jij hoort beneden te zijn.

You're supposed to be downstairs.

Why: Infinitives and purpose. [[Dutch#^nl-Q0730|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Jij%20hoort%20beneden%20te%20zijn.)
^nl-Q0730-answer

**nl-Q0731** — Poets je schoenen vooraleer weg te gaan.

Shine your shoes before going out.

Why: Infinitives and purpose. [[Dutch#^nl-Q0731|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Poets%20je%20schoenen%20vooraleer%20weg%20te%20gaan.)
^nl-Q0731-answer

**nl-Q0732** — Poets je schoenen vooraleer weg te gaan.

Shine your shoes before going out.

Many infinitive complements use te; om ... te commonly expresses purpose. Te can also intensify an adjective, so identify the following phrase.

Why: Infinitives and purpose. [[Dutch#^nl-Q0732|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Poets%20je%20schoenen%20vooraleer%20weg%20te%20gaan.)
^nl-Q0732-answer

**nl-Q0733** — Ik ben vergeten brood te kopen.

I forgot to buy bread.

Expected form: **te**

Why: Infinitives and purpose. [[Dutch#^nl-Q0733|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20ben%20vergeten%20brood%20te%20kopen.)
^nl-Q0733-answer

**nl-Q0734** — Ik ben vergeten brood te kopen.

I forgot to buy bread.

Expected form: **te**

Why: Infinitives and purpose. [[Dutch#^nl-Q0734|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20ben%20vergeten%20brood%20te%20kopen.)
^nl-Q0734-answer

**nl-Q0735** — Tom liet me zweren het niet tegen Mary te zeggen.

Tom made me swear not to tell Mary.

Expected form: **te**

Why: Infinitives and purpose. [[Dutch#^nl-Q0735|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Tom%20liet%20me%20zweren%20het%20niet%20tegen%20Mary%20te%20zeggen.)
^nl-Q0735-answer

**nl-Q0736** — Tom liet me zweren het niet tegen Mary te zeggen.

Tom made me swear not to tell Mary.

Why: Infinitives and purpose. [[Dutch#^nl-Q0736|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Tom%20liet%20me%20zweren%20het%20niet%20tegen%20Mary%20te%20zeggen.)
^nl-Q0736-answer

**nl-Q0737** — Het was zo'n mooie dag, dat we besloten te gaan picknicken.

It was such a fine day that we decided to have a picnic.

Why: Infinitives and purpose. [[Dutch#^nl-Q0737|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Het%20was%20zo%27n%20mooie%20dag%2C%20dat%20we%20besloten%20te%20gaan%20picknicken.)
^nl-Q0737-answer

**nl-Q0738** — Het was zo'n mooie dag, dat we besloten te gaan picknicken.

It was such a fine day that we decided to have a picnic.

Many infinitive complements use te; om ... te commonly expresses purpose. Te can also intensify an adjective, so identify the following phrase.

Why: Infinitives and purpose. [[Dutch#^nl-Q0738|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Het%20was%20zo%27n%20mooie%20dag%2C%20dat%20we%20besloten%20te%20gaan%20picknicken.)
^nl-Q0738-answer

**nl-Q0739** — Ik had een uur nodig om het gedicht van buiten te leren.

It took me an hour to learn the poem by heart.

Expected form: **om**

Why: Infinitives and purpose. [[Dutch#^nl-Q0739|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20had%20een%20uur%20nodig%20om%20het%20gedicht%20van%20buiten%20te%20leren.)
^nl-Q0739-answer

**nl-Q0740** — Ik had een uur nodig om het gedicht van buiten te leren.

It took me an hour to learn the poem by heart.

Expected form: **om**

Why: Infinitives and purpose. [[Dutch#^nl-Q0740|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20had%20een%20uur%20nodig%20om%20het%20gedicht%20van%20buiten%20te%20leren.)
^nl-Q0740-answer

**nl-Q0741** — Het is niet goed te weten dat iets onaangenaams ons zal overkomen, zoals bijvoorbeeld een bezoek aan de tandarts, of aan Frankrijk.

If you know that something unpleasant will happen, that you will go to the dentist for example, or to France, then that is not good.

Expected form: **te**

Why: Infinitives and purpose. [[Dutch#^nl-Q0741|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Het%20is%20niet%20goed%20te%20weten%20dat%20iets%20onaangenaams%20ons%20zal%20overkomen%2C%20zoals%20bijvoorbeeld%20een%20bezoek%20aan%20de%20tandarts%2C%20of%20aan%20Frankrijk.)
^nl-Q0741-answer

**nl-Q0742** — Het is niet goed te weten dat iets onaangenaams ons zal overkomen, zoals bijvoorbeeld een bezoek aan de tandarts, of aan Frankrijk.

If you know that something unpleasant will happen, that you will go to the dentist for example, or to France, then that is not good.

Why: Infinitives and purpose. [[Dutch#^nl-Q0742|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Het%20is%20niet%20goed%20te%20weten%20dat%20iets%20onaangenaams%20ons%20zal%20overkomen%2C%20zoals%20bijvoorbeeld%20een%20bezoek%20aan%20de%20tandarts%2C%20of%20aan%20Frankrijk.)
^nl-Q0742-answer

**nl-Q0743** — Hij besloot niet langer te wachten.

He decided not to wait any longer.

Why: Infinitives and purpose. [[Dutch#^nl-Q0743|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Hij%20besloot%20niet%20langer%20te%20wachten.)
^nl-Q0743-answer

**nl-Q0744** — Hij besloot niet langer te wachten.

He decided not to wait any longer.

Many infinitive complements use te; om ... te commonly expresses purpose. Te can also intensify an adjective, so identify the following phrase.

Why: Infinitives and purpose. [[Dutch#^nl-Q0744|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Hij%20besloot%20niet%20langer%20te%20wachten.)
^nl-Q0744-answer

**nl-Q0745** — Ik begin te vermoeden dat ik de liefde van mijn leven ben.

I am beginning to suspect that I am the love of my life.

Expected form: **te**

Why: Infinitives and purpose. [[Dutch#^nl-Q0745|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20begin%20te%20vermoeden%20dat%20ik%20de%20liefde%20van%20mijn%20leven%20ben.)
^nl-Q0745-answer

**nl-Q0746** — Ik begin te vermoeden dat ik de liefde van mijn leven ben.

I am beginning to suspect that I am the love of my life.

Expected form: **te**

Why: Infinitives and purpose. [[Dutch#^nl-Q0746|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20begin%20te%20vermoeden%20dat%20ik%20de%20liefde%20van%20mijn%20leven%20ben.)
^nl-Q0746-answer

**nl-Q0747** — Het lijkt een misverstand te zijn.

It seems to be a misunderstanding.

Expected form: **te**

Why: Infinitives and purpose. [[Dutch#^nl-Q0747|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Het%20lijkt%20een%20misverstand%20te%20zijn.)
^nl-Q0747-answer

**nl-Q0748** — Het lijkt een misverstand te zijn.

It seems to be a misunderstanding.

Why: Infinitives and purpose. [[Dutch#^nl-Q0748|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Het%20lijkt%20een%20misverstand%20te%20zijn.)
^nl-Q0748-answer

**nl-Q0749** — Ik kan u niet te veel danken.

I cannot thank you too much.

Why: Infinitives and purpose. [[Dutch#^nl-Q0749|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20kan%20u%20niet%20te%20veel%20danken.)
^nl-Q0749-answer

**nl-Q0750** — Ik kan u niet te veel danken.

I cannot thank you too much.

Many infinitive complements use te; om ... te commonly expresses purpose. Te can also intensify an adjective, so identify the following phrase.

Why: Infinitives and purpose. [[Dutch#^nl-Q0750|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20kan%20u%20niet%20te%20veel%20danken.)
^nl-Q0750-answer


### Answers 751–800

**nl-Q0751** — Ik woon in een heel klein appartement.

I live in a very small apartment.

Expected form: **klein**

Why: Adjectives. [[Dutch#^nl-Q0751|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20woon%20in%20een%20heel%20klein%20appartement.)
^nl-Q0751-answer

**nl-Q0752** — Ik woon in een heel klein appartement.

I live in a very small apartment.

Expected form: **klein**

Why: Adjectives. [[Dutch#^nl-Q0752|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20woon%20in%20een%20heel%20klein%20appartement.)
^nl-Q0752-answer

**nl-Q0753** — Dit is goed vlees.

This is good meat.

Expected form: **goed**

Why: Adjectives. [[Dutch#^nl-Q0753|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Dit%20is%20goed%20vlees.)
^nl-Q0753-answer

**nl-Q0754** — Dit is goed vlees.

This is good meat.

Why: Adjectives. [[Dutch#^nl-Q0754|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Dit%20is%20goed%20vlees.)
^nl-Q0754-answer

**nl-Q0755** — Luxemburg is een klein land.

Luxembourg is a small country.

Why: Adjectives. [[Dutch#^nl-Q0755|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Luxemburg%20is%20een%20klein%20land.)
^nl-Q0755-answer

**nl-Q0756** — Luxemburg is een klein land.

Luxembourg is a small country.

Attributive adjectives often take -e. An indefinite singular neuter noun often has an uninflected adjective: een goed boek. A predicative adjective normally has no -e.

Why: Adjectives. [[Dutch#^nl-Q0756|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Luxemburg%20is%20een%20klein%20land.)
^nl-Q0756-answer

**nl-Q0757** — Ik at met mijn kleine broer.

I ate with my baby brother.

Expected form: **kleine**

Why: Adjectives. [[Dutch#^nl-Q0757|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20at%20met%20mijn%20kleine%20broer.)
^nl-Q0757-answer

**nl-Q0758** — Ik at met mijn kleine broer.

I ate with my baby brother.

Expected form: **kleine**

Why: Adjectives. [[Dutch#^nl-Q0758|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20at%20met%20mijn%20kleine%20broer.)
^nl-Q0758-answer

**nl-Q0759** — Deze stof houdt zich goed.

This fabric wears well.

Expected form: **goed**

Why: Adjectives. [[Dutch#^nl-Q0759|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Deze%20stof%20houdt%20zich%20goed.)
^nl-Q0759-answer

**nl-Q0760** — Deze stof houdt zich goed.

This fabric wears well.

Why: Adjectives. [[Dutch#^nl-Q0760|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Deze%20stof%20houdt%20zich%20goed.)
^nl-Q0760-answer

**nl-Q0761** — Bacteriën zijn maar kleine, onschadelijke cellen.

Bacteria are just tiny cells, harmless.

Why: Adjectives. [[Dutch#^nl-Q0761|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Bacteri%C3%ABn%20zijn%20maar%20kleine%2C%20onschadelijke%20cellen.)
^nl-Q0761-answer

**nl-Q0762** — Bacteriën zijn maar kleine, onschadelijke cellen.

Bacteria are just tiny cells, harmless.

Attributive adjectives often take -e. An indefinite singular neuter noun often has an uninflected adjective: een goed boek. A predicative adjective normally has no -e.

Why: Adjectives. [[Dutch#^nl-Q0762|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Bacteri%C3%ABn%20zijn%20maar%20kleine%2C%20onschadelijke%20cellen.)
^nl-Q0762-answer

**nl-Q0763** — Dank u, met mij gaat het goed.

Thanks, I'm fine.

Expected form: **goed**

Why: Adjectives. [[Dutch#^nl-Q0763|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Dank%20u%2C%20met%20mij%20gaat%20het%20goed.)
^nl-Q0763-answer

**nl-Q0764** — Dank u, met mij gaat het goed.

Thanks, I'm fine.

Expected form: **goed**

Why: Adjectives. [[Dutch#^nl-Q0764|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Dank%20u%2C%20met%20mij%20gaat%20het%20goed.)
^nl-Q0764-answer

**nl-Q0765** — Alles komt goed.

Everything will be OK.

Expected form: **goed**

Why: Adjectives. [[Dutch#^nl-Q0765|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Alles%20komt%20goed.)
^nl-Q0765-answer

**nl-Q0766** — Alles komt goed.

Everything will be OK.

Why: Adjectives. [[Dutch#^nl-Q0766|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Alles%20komt%20goed.)
^nl-Q0766-answer

**nl-Q0767** — Canada is een groot land.

Canada is a large country.

Why: Adjectives. [[Dutch#^nl-Q0767|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Canada%20is%20een%20groot%20land.)
^nl-Q0767-answer

**nl-Q0768** — Canada is een groot land.

Canada is a large country.

Attributive adjectives often take -e. An indefinite singular neuter noun often has an uninflected adjective: een goed boek. A predicative adjective normally has no -e.

Why: Adjectives. [[Dutch#^nl-Q0768|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Canada%20is%20een%20groot%20land.)
^nl-Q0768-answer

**nl-Q0769** — Als je het geel verft, sla je twee vliegen in één klap: én het valt goed op, én je bespaart geld omdat je verf kunt gebruiken die je al in huis hebt.

If you paint it yellow, you'll kill two birds with one stone: it'll stand out, and you'll save money because you can use paint you already have.

Expected form: **goed**

Why: Adjectives. [[Dutch#^nl-Q0769|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Als%20je%20het%20geel%20verft%2C%20sla%20je%20twee%20vliegen%20in%20%C3%A9%C3%A9n%20klap%3A%20%C3%A9n%20het%20valt%20goed%20op%2C%20%C3%A9n%20je%20bespaart%20geld%20omdat%20je%20verf%20kunt%20gebruiken%20die%20je%20al%20in%20huis%20hebt.)
^nl-Q0769-answer

**nl-Q0770** — Als je het geel verft, sla je twee vliegen in één klap: én het valt goed op, én je bespaart geld omdat je verf kunt gebruiken die je al in huis hebt.

If you paint it yellow, you'll kill two birds with one stone: it'll stand out, and you'll save money because you can use paint you already have.

Expected form: **goed**

Why: Adjectives. [[Dutch#^nl-Q0770|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Als%20je%20het%20geel%20verft%2C%20sla%20je%20twee%20vliegen%20in%20%C3%A9%C3%A9n%20klap%3A%20%C3%A9n%20het%20valt%20goed%20op%2C%20%C3%A9n%20je%20bespaart%20geld%20omdat%20je%20verf%20kunt%20gebruiken%20die%20je%20al%20in%20huis%20hebt.)
^nl-Q0770-answer

**nl-Q0771** — Plotseling kreeg ik een goed idee.

Suddenly, a good idea occurred to me.

Expected form: **goed**

Why: Adjectives. [[Dutch#^nl-Q0771|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Plotseling%20kreeg%20ik%20een%20goed%20idee.)
^nl-Q0771-answer

**nl-Q0772** — Plotseling kreeg ik een goed idee.

Suddenly, a good idea occurred to me.

Why: Adjectives. [[Dutch#^nl-Q0772|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Plotseling%20kreeg%20ik%20een%20goed%20idee.)
^nl-Q0772-answer

**nl-Q0773** — Ik kan een klein beetje Frans spreken.

I can speak a tiny bit of French.

Why: Adjectives. [[Dutch#^nl-Q0773|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20kan%20een%20klein%20beetje%20Frans%20spreken.)
^nl-Q0773-answer

**nl-Q0774** — Ik kan een klein beetje Frans spreken.

I can speak a tiny bit of French.

Attributive adjectives often take -e. An indefinite singular neuter noun often has an uninflected adjective: een goed boek. A predicative adjective normally has no -e.

Why: Adjectives. [[Dutch#^nl-Q0774|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20kan%20een%20klein%20beetje%20Frans%20spreken.)
^nl-Q0774-answer

**nl-Q0775** — Gisteren ging ik naar de dierentuin en zag ik een heel grote walrus.

Yesterday I went to the zoo and saw a huge walrus.

Expected form: **grote**

Why: Adjectives. [[Dutch#^nl-Q0775|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Gisteren%20ging%20ik%20naar%20de%20dierentuin%20en%20zag%20ik%20een%20heel%20grote%20walrus.)
^nl-Q0775-answer

**nl-Q0776** — Gisteren ging ik naar de dierentuin en zag ik een heel grote walrus.

Yesterday I went to the zoo and saw a huge walrus.

Expected form: **grote**

Why: Adjectives. [[Dutch#^nl-Q0776|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Gisteren%20ging%20ik%20naar%20de%20dierentuin%20en%20zag%20ik%20een%20heel%20grote%20walrus.)
^nl-Q0776-answer

**nl-Q0777** — Goede meisjes gaan naar de hemel, slechte meisjes gaan naar overal.

Good girls go to heaven, bad girls go everywhere.

Expected form: **Goede**

Why: Adjectives. [[Dutch#^nl-Q0777|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Goede%20meisjes%20gaan%20naar%20de%20hemel%2C%20slechte%20meisjes%20gaan%20naar%20overal.)
^nl-Q0777-answer

**nl-Q0778** — Goede meisjes gaan naar de hemel, slechte meisjes gaan naar overal.

Good girls go to heaven, bad girls go everywhere.

Why: Adjectives. [[Dutch#^nl-Q0778|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Goede%20meisjes%20gaan%20naar%20de%20hemel%2C%20slechte%20meisjes%20gaan%20naar%20overal.)
^nl-Q0778-answer

**nl-Q0779** — Hij heeft de verkiezingen gewonnen met een grote meerderheid.

He won the election by a large majority.

Why: Adjectives. [[Dutch#^nl-Q0779|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Hij%20heeft%20de%20verkiezingen%20gewonnen%20met%20een%20grote%20meerderheid.)
^nl-Q0779-answer

**nl-Q0780** — Hij heeft de verkiezingen gewonnen met een grote meerderheid.

He won the election by a large majority.

Attributive adjectives often take -e. An indefinite singular neuter noun often has an uninflected adjective: een goed boek. A predicative adjective normally has no -e.

Why: Adjectives. [[Dutch#^nl-Q0780|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Hij%20heeft%20de%20verkiezingen%20gewonnen%20met%20een%20grote%20meerderheid.)
^nl-Q0780-answer

**nl-Q0781** — Ik ben helemaal niet goed in Duits.

I am not good at German at all.

Expected form: **goed**

Why: Adjectives. [[Dutch#^nl-Q0781|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20ben%20helemaal%20niet%20goed%20in%20Duits.)
^nl-Q0781-answer

**nl-Q0782** — Ik ben helemaal niet goed in Duits.

I am not good at German at all.

Expected form: **goed**

Why: Adjectives. [[Dutch#^nl-Q0782|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20ben%20helemaal%20niet%20goed%20in%20Duits.)
^nl-Q0782-answer

**nl-Q0783** — Komaan, alles komt goed.

Come on, everything will be alright.

Expected form: **goed**

Why: Adjectives. [[Dutch#^nl-Q0783|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Komaan%2C%20alles%20komt%20goed.)
^nl-Q0783-answer

**nl-Q0784** — Komaan, alles komt goed.

Come on, everything will be alright.

Why: Adjectives. [[Dutch#^nl-Q0784|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Komaan%2C%20alles%20komt%20goed.)
^nl-Q0784-answer

**nl-Q0785** — Ik merkte dat ze een nieuwe hoed droeg.

I noticed she was wearing a new hat.

Why: Adjectives. [[Dutch#^nl-Q0785|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20merkte%20dat%20ze%20een%20nieuwe%20hoed%20droeg.)
^nl-Q0785-answer

**nl-Q0786** — Ik merkte dat ze een nieuwe hoed droeg.

I noticed she was wearing a new hat.

Attributive adjectives often take -e. An indefinite singular neuter noun often has an uninflected adjective: een goed boek. A predicative adjective normally has no -e.

Why: Adjectives. [[Dutch#^nl-Q0786|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20merkte%20dat%20ze%20een%20nieuwe%20hoed%20droeg.)
^nl-Q0786-answer

**nl-Q0787** — Hij heeft een kleine jongen van de verdrinkingsdood gered.

He saved a little boy from drowning.

Expected form: **kleine**

Why: Adjectives. [[Dutch#^nl-Q0787|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Hij%20heeft%20een%20kleine%20jongen%20van%20de%20verdrinkingsdood%20gered.)
^nl-Q0787-answer

**nl-Q0788** — Hij heeft een kleine jongen van de verdrinkingsdood gered.

He saved a little boy from drowning.

Expected form: **kleine**

Why: Adjectives. [[Dutch#^nl-Q0788|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Hij%20heeft%20een%20kleine%20jongen%20van%20de%20verdrinkingsdood%20gered.)
^nl-Q0788-answer

**nl-Q0789** — Is dat jouw nieuwe vriendin?

Is that your new girlfriend?

Expected form: **nieuwe**

Why: Adjectives. [[Dutch#^nl-Q0789|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Is%20dat%20jouw%20nieuwe%20vriendin%3F)
^nl-Q0789-answer

**nl-Q0790** — Is dat jouw nieuwe vriendin?

Is that your new girlfriend?

Why: Adjectives. [[Dutch#^nl-Q0790|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Is%20dat%20jouw%20nieuwe%20vriendin%3F)
^nl-Q0790-answer

**nl-Q0791** — Er is een nieuw restaurant op Cherry Avenue.

There's a new restaurant on Cherry Avenue.

Why: Adjectives. [[Dutch#^nl-Q0791|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Er%20is%20een%20nieuw%20restaurant%20op%20Cherry%20Avenue.)
^nl-Q0791-answer

**nl-Q0792** — Er is een nieuw restaurant op Cherry Avenue.

There's a new restaurant on Cherry Avenue.

Attributive adjectives often take -e. An indefinite singular neuter noun often has an uninflected adjective: een goed boek. A predicative adjective normally has no -e.

Why: Adjectives. [[Dutch#^nl-Q0792|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Er%20is%20een%20nieuw%20restaurant%20op%20Cherry%20Avenue.)
^nl-Q0792-answer

**nl-Q0793** — Het nieuwe semester begint in april in Japan.

The new term starts in April in Japan.

Expected form: **nieuwe**

Why: Adjectives. [[Dutch#^nl-Q0793|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Het%20nieuwe%20semester%20begint%20in%20april%20in%20Japan.)
^nl-Q0793-answer

**nl-Q0794** — Het nieuwe semester begint in april in Japan.

The new term starts in April in Japan.

Expected form: **nieuwe**

Why: Adjectives. [[Dutch#^nl-Q0794|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Het%20nieuwe%20semester%20begint%20in%20april%20in%20Japan.)
^nl-Q0794-answer

**nl-Q0795** — Dit woordenboek is niet goed.

This dictionary is no good.

Expected form: **goed**

Why: Adjectives. [[Dutch#^nl-Q0795|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Dit%20woordenboek%20is%20niet%20goed.)
^nl-Q0795-answer

**nl-Q0796** — Dit woordenboek is niet goed.

This dictionary is no good.

Why: Adjectives. [[Dutch#^nl-Q0796|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Dit%20woordenboek%20is%20niet%20goed.)
^nl-Q0796-answer

**nl-Q0797** — Goede wijn behoeft geen krans.

Good wine needs no bush.

Why: Adjectives. [[Dutch#^nl-Q0797|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Goede%20wijn%20behoeft%20geen%20krans.)
^nl-Q0797-answer

**nl-Q0798** — Goede wijn behoeft geen krans.

Good wine needs no bush.

Attributive adjectives often take -e. An indefinite singular neuter noun often has an uninflected adjective: een goed boek. A predicative adjective normally has no -e.

Why: Adjectives. [[Dutch#^nl-Q0798|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Goede%20wijn%20behoeft%20geen%20krans.)
^nl-Q0798-answer

**nl-Q0799** — Ik verblijf in een klein pensionnetje.

I'm staying at a small guesthouse.

Expected form: **klein**

Why: Adjectives. [[Dutch#^nl-Q0799|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20verblijf%20in%20een%20klein%20pensionnetje.)
^nl-Q0799-answer

**nl-Q0800** — Ik verblijf in een klein pensionnetje.

I'm staying at a small guesthouse.

Expected form: **klein**

Why: Adjectives. [[Dutch#^nl-Q0800|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20verblijf%20in%20een%20klein%20pensionnetje.)
^nl-Q0800-answer


### Answers 801–850

**nl-Q0801** — Tom en Maria zijn aan het liften.

Tom and Mary are hitchhiking.

Expected form: **en**

Why: Coordination. [[Dutch#^nl-Q0801|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Tom%20en%20Maria%20zijn%20aan%20het%20liften.)
^nl-Q0801-answer

**nl-Q0802** — Tom en Maria zijn aan het liften.

Tom and Mary are hitchhiking.

Why: Coordination. [[Dutch#^nl-Q0802|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Tom%20en%20Maria%20zijn%20aan%20het%20liften.)
^nl-Q0802-answer

**nl-Q0803** — Hij is jong, maar wel heel intelligent.

He's young, but he's very intelligent.

Why: Coordination. [[Dutch#^nl-Q0803|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Hij%20is%20jong%2C%20maar%20wel%20heel%20intelligent.)
^nl-Q0803-answer

**nl-Q0804** — Hij is jong, maar wel heel intelligent.

He's young, but he's very intelligent.

Coordinating conjunctions connect similar structures without imposing subordinate verb-final order. Want supplies a reason with main-clause grammar.

Why: Coordination. [[Dutch#^nl-Q0804|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Hij%20is%20jong%2C%20maar%20wel%20heel%20intelligent.)
^nl-Q0804-answer

**nl-Q0805** — Ze exporteren veel fruit, zoals sinaasappels, grapefruits en citroenen.

They export a lot of fruit, such as oranges, grapefruits and lemons.

Expected form: **en**

Why: Coordination. [[Dutch#^nl-Q0805|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ze%20exporteren%20veel%20fruit%2C%20zoals%20sinaasappels%2C%20grapefruits%20en%20citroenen.)
^nl-Q0805-answer

**nl-Q0806** — Ze exporteren veel fruit, zoals sinaasappels, grapefruits en citroenen.

They export a lot of fruit, such as oranges, grapefruits and lemons.

Expected form: **en**

Why: Coordination. [[Dutch#^nl-Q0806|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ze%20exporteren%20veel%20fruit%2C%20zoals%20sinaasappels%2C%20grapefruits%20en%20citroenen.)
^nl-Q0806-answer

**nl-Q0807** — Bel mij af en toe.

Call me once in a while.

Expected form: **en**

Why: Coordination. [[Dutch#^nl-Q0807|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Bel%20mij%20af%20en%20toe.)
^nl-Q0807-answer

**nl-Q0808** — Bel mij af en toe.

Call me once in a while.

Why: Coordination. [[Dutch#^nl-Q0808|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Bel%20mij%20af%20en%20toe.)
^nl-Q0808-answer

**nl-Q0809** — Onderzoek vergt veel energie, maar het is de moeite waard.

Research requires a lot of energy, but it's worth the effort.

Why: Coordination. [[Dutch#^nl-Q0809|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Onderzoek%20vergt%20veel%20energie%2C%20maar%20het%20is%20de%20moeite%20waard.)
^nl-Q0809-answer

**nl-Q0810** — Onderzoek vergt veel energie, maar het is de moeite waard.

Research requires a lot of energy, but it's worth the effort.

Coordinating conjunctions connect similar structures without imposing subordinate verb-final order. Want supplies a reason with main-clause grammar.

Why: Coordination. [[Dutch#^nl-Q0810|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Onderzoek%20vergt%20veel%20energie%2C%20maar%20het%20is%20de%20moeite%20waard.)
^nl-Q0810-answer

**nl-Q0811** — Het leven zuigt en dan ga je dood.

Life is a bitch and then you die.

Expected form: **en**

Why: Coordination. [[Dutch#^nl-Q0811|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Het%20leven%20zuigt%20en%20dan%20ga%20je%20dood.)
^nl-Q0811-answer

**nl-Q0812** — Het leven zuigt en dan ga je dood.

Life is a bitch and then you die.

Expected form: **en**

Why: Coordination. [[Dutch#^nl-Q0812|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Het%20leven%20zuigt%20en%20dan%20ga%20je%20dood.)
^nl-Q0812-answer

**nl-Q0813** — Geef me uw naam en telefoonnummer.

Please tell me your name and telephone number.

Expected form: **en**

Why: Coordination. [[Dutch#^nl-Q0813|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Geef%20me%20uw%20naam%20en%20telefoonnummer.)
^nl-Q0813-answer

**nl-Q0814** — Geef me uw naam en telefoonnummer.

Please tell me your name and telephone number.

Why: Coordination. [[Dutch#^nl-Q0814|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Geef%20me%20uw%20naam%20en%20telefoonnummer.)
^nl-Q0814-answer

**nl-Q0815** — Ik heb maar drie dollar uitgegeven.

I only spent three dollars.

Why: Coordination. [[Dutch#^nl-Q0815|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20heb%20maar%20drie%20dollar%20uitgegeven.)
^nl-Q0815-answer

**nl-Q0816** — Ik heb maar drie dollar uitgegeven.

I only spent three dollars.

Coordinating conjunctions connect similar structures without imposing subordinate verb-final order. Want supplies a reason with main-clause grammar.

Why: Coordination. [[Dutch#^nl-Q0816|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20heb%20maar%20drie%20dollar%20uitgegeven.)
^nl-Q0816-answer

**nl-Q0817** — Je kan maar beter het licht uitdoen voordat je gaat slapen.

You had better turn off the light before you go to sleep.

Expected form: **maar**

Why: Coordination. [[Dutch#^nl-Q0817|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Je%20kan%20maar%20beter%20het%20licht%20uitdoen%20voordat%20je%20gaat%20slapen.)
^nl-Q0817-answer

**nl-Q0818** — Je kan maar beter het licht uitdoen voordat je gaat slapen.

You had better turn off the light before you go to sleep.

Expected form: **maar**

Why: Coordination. [[Dutch#^nl-Q0818|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Je%20kan%20maar%20beter%20het%20licht%20uitdoen%20voordat%20je%20gaat%20slapen.)
^nl-Q0818-answer

**nl-Q0819** — Halt, of ik schiet.

Stop, or I'll shoot.

Expected form: **of**

Why: Coordination. [[Dutch#^nl-Q0819|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Halt%2C%20of%20ik%20schiet.)
^nl-Q0819-answer

**nl-Q0820** — Halt, of ik schiet.

Stop, or I'll shoot.

Why: Coordination. [[Dutch#^nl-Q0820|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Halt%2C%20of%20ik%20schiet.)
^nl-Q0820-answer

**nl-Q0821** — Ze ontmoetten de kroonprinsen van Zweden en Denemarken.

They met the crown princes of Sweden and Denmark.

Why: Coordination. [[Dutch#^nl-Q0821|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ze%20ontmoetten%20de%20kroonprinsen%20van%20Zweden%20en%20Denemarken.)
^nl-Q0821-answer

**nl-Q0822** — Ze ontmoetten de kroonprinsen van Zweden en Denemarken.

They met the crown princes of Sweden and Denmark.

Coordinating conjunctions connect similar structures without imposing subordinate verb-final order. Want supplies a reason with main-clause grammar.

Why: Coordination. [[Dutch#^nl-Q0822|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ze%20ontmoetten%20de%20kroonprinsen%20van%20Zweden%20en%20Denemarken.)
^nl-Q0822-answer

**nl-Q0823** — We zijn nooit even gelukkig of ongelukkig als we onszelf indenken.

We are never as happy or as unhappy as we imagine.

Expected form: **of**

Why: Coordination. [[Dutch#^nl-Q0823|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=We%20zijn%20nooit%20even%20gelukkig%20of%20ongelukkig%20als%20we%20onszelf%20indenken.)
^nl-Q0823-answer

**nl-Q0824** — We zijn nooit even gelukkig of ongelukkig als we onszelf indenken.

We are never as happy or as unhappy as we imagine.

Expected form: **of**

Why: Coordination. [[Dutch#^nl-Q0824|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=We%20zijn%20nooit%20even%20gelukkig%20of%20ongelukkig%20als%20we%20onszelf%20indenken.)
^nl-Q0824-answer

**nl-Q0825** — En waarom is dat?

And why is that?

Expected form: **En**

Why: Coordination. [[Dutch#^nl-Q0825|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=En%20waarom%20is%20dat%3F)
^nl-Q0825-answer

**nl-Q0826** — En waarom is dat?

And why is that?

Why: Coordination. [[Dutch#^nl-Q0826|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=En%20waarom%20is%20dat%3F)
^nl-Q0826-answer

**nl-Q0827** — De zon komt op in het oosten en gaat onder in het westen.

The sun rises in the east and sets in the west.

Why: Coordination. [[Dutch#^nl-Q0827|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=De%20zon%20komt%20op%20in%20het%20oosten%20en%20gaat%20onder%20in%20het%20westen.)
^nl-Q0827-answer

**nl-Q0828** — De zon komt op in het oosten en gaat onder in het westen.

The sun rises in the east and sets in the west.

Coordinating conjunctions connect similar structures without imposing subordinate verb-final order. Want supplies a reason with main-clause grammar.

Why: Coordination. [[Dutch#^nl-Q0828|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=De%20zon%20komt%20op%20in%20het%20oosten%20en%20gaat%20onder%20in%20het%20westen.)
^nl-Q0828-answer

**nl-Q0829** — De overwinning of de dood!

Victory, or death!

Expected form: **of**

Why: Coordination. [[Dutch#^nl-Q0829|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=De%20overwinning%20of%20de%20dood%21)
^nl-Q0829-answer

**nl-Q0830** — De overwinning of de dood!

Victory, or death!

Expected form: **of**

Why: Coordination. [[Dutch#^nl-Q0830|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=De%20overwinning%20of%20de%20dood%21)
^nl-Q0830-answer

**nl-Q0831** — U ziet, maar u observeert niet.

You see, but you do not observe.

Expected form: **maar**

Why: Coordination. [[Dutch#^nl-Q0831|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=U%20ziet%2C%20maar%20u%20observeert%20niet.)
^nl-Q0831-answer

**nl-Q0832** — U ziet, maar u observeert niet.

You see, but you do not observe.

Why: Coordination. [[Dutch#^nl-Q0832|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=U%20ziet%2C%20maar%20u%20observeert%20niet.)
^nl-Q0832-answer

**nl-Q0833** — We probeerden Tom te foppen, maar hij had natuurlijk onraad geroken.

We tried to fool Tom, but he obviously knew something was up.

Why: Coordination. [[Dutch#^nl-Q0833|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=We%20probeerden%20Tom%20te%20foppen%2C%20maar%20hij%20had%20natuurlijk%20onraad%20geroken.)
^nl-Q0833-answer

**nl-Q0834** — We probeerden Tom te foppen, maar hij had natuurlijk onraad geroken.

We tried to fool Tom, but he obviously knew something was up.

Coordinating conjunctions connect similar structures without imposing subordinate verb-final order. Want supplies a reason with main-clause grammar.

Why: Coordination. [[Dutch#^nl-Q0834|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=We%20probeerden%20Tom%20te%20foppen%2C%20maar%20hij%20had%20natuurlijk%20onraad%20geroken.)
^nl-Q0834-answer

**nl-Q0835** — Mijn zus houdt van meloenen en ik ook.

My sister likes melons and so do I.

Expected form: **en**

Why: Coordination. [[Dutch#^nl-Q0835|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Mijn%20zus%20houdt%20van%20meloenen%20en%20ik%20ook.)
^nl-Q0835-answer

**nl-Q0836** — Mijn zus houdt van meloenen en ik ook.

My sister likes melons and so do I.

Expected form: **en**

Why: Coordination. [[Dutch#^nl-Q0836|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Mijn%20zus%20houdt%20van%20meloenen%20en%20ik%20ook.)
^nl-Q0836-answer

**nl-Q0837** — Ze kunnen maandag of dinsdag komen, maar niet woensdag of donderdag.

They can come on Monday or Tuesday, but not on Wednesday or Thursday.

Expected form: **of**

Why: Coordination. [[Dutch#^nl-Q0837|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ze%20kunnen%20maandag%20of%20dinsdag%20komen%2C%20maar%20niet%20woensdag%20of%20donderdag.)
^nl-Q0837-answer

**nl-Q0838** — Ze kunnen maandag of dinsdag komen, maar niet woensdag of donderdag.

They can come on Monday or Tuesday, but not on Wednesday or Thursday.

Why: Coordination. [[Dutch#^nl-Q0838|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ze%20kunnen%20maandag%20of%20dinsdag%20komen%2C%20maar%20niet%20woensdag%20of%20donderdag.)
^nl-Q0838-answer

**nl-Q0839** — Ken jij het verschil tussen een microscoop en een telescoop?

Do you know the difference between a microscope and a telescope?

Why: Coordination. [[Dutch#^nl-Q0839|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ken%20jij%20het%20verschil%20tussen%20een%20microscoop%20en%20een%20telescoop%3F)
^nl-Q0839-answer

**nl-Q0840** — Ken jij het verschil tussen een microscoop en een telescoop?

Do you know the difference between a microscope and a telescope?

Coordinating conjunctions connect similar structures without imposing subordinate verb-final order. Want supplies a reason with main-clause grammar.

Why: Coordination. [[Dutch#^nl-Q0840|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ken%20jij%20het%20verschil%20tussen%20een%20microscoop%20en%20een%20telescoop%3F)
^nl-Q0840-answer

**nl-Q0841** — Als je iemand $20 uitleent en je ziet die persoon daarna nooit meer, dan was het dat waarschijnlijk waard.

If you lend someone $20 and never see that person again, it was probably worth it.

Expected form: **en**

Why: Coordination. [[Dutch#^nl-Q0841|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Als%20je%20iemand%20%2420%20uitleent%20en%20je%20ziet%20die%20persoon%20daarna%20nooit%20meer%2C%20dan%20was%20het%20dat%20waarschijnlijk%20waard.)
^nl-Q0841-answer

**nl-Q0842** — Als je iemand $20 uitleent en je ziet die persoon daarna nooit meer, dan was het dat waarschijnlijk waard.

If you lend someone $20 and never see that person again, it was probably worth it.

Expected form: **en**

Why: Coordination. [[Dutch#^nl-Q0842|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Als%20je%20iemand%20%2420%20uitleent%20en%20je%20ziet%20die%20persoon%20daarna%20nooit%20meer%2C%20dan%20was%20het%20dat%20waarschijnlijk%20waard.)
^nl-Q0842-answer

**nl-Q0843** — Diegene die het weet, zwijgt en diegene die spreekt is onwetend.

He who knows does not speak, he who speaks does not know.

Expected form: **en**

Why: Coordination. [[Dutch#^nl-Q0843|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Diegene%20die%20het%20weet%2C%20zwijgt%20en%20diegene%20die%20spreekt%20is%20onwetend.)
^nl-Q0843-answer

**nl-Q0844** — Diegene die het weet, zwijgt en diegene die spreekt is onwetend.

He who knows does not speak, he who speaks does not know.

Why: Coordination. [[Dutch#^nl-Q0844|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Diegene%20die%20het%20weet%2C%20zwijgt%20en%20diegene%20die%20spreekt%20is%20onwetend.)
^nl-Q0844-answer

**nl-Q0845** — Ze heeft op alles en iedereen iets aan te merken.

She finds fault with everything and everyone.

Why: Coordination. [[Dutch#^nl-Q0845|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ze%20heeft%20op%20alles%20en%20iedereen%20iets%20aan%20te%20merken.)
^nl-Q0845-answer

**nl-Q0846** — Ze heeft op alles en iedereen iets aan te merken.

She finds fault with everything and everyone.

Coordinating conjunctions connect similar structures without imposing subordinate verb-final order. Want supplies a reason with main-clause grammar.

Why: Coordination. [[Dutch#^nl-Q0846|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ze%20heeft%20op%20alles%20en%20iedereen%20iets%20aan%20te%20merken.)
^nl-Q0846-answer

**nl-Q0847** — Waterstof, koolstof, stikstof, fosfor, zuurstof, zwavel en seleen zijn niet-metalen.

Hydrogen, carbon, nitrogen, phosphorus, oxygen, sulfur and selenium are nonmetals.

Expected form: **en**

Why: Coordination. [[Dutch#^nl-Q0847|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Waterstof%2C%20koolstof%2C%20stikstof%2C%20fosfor%2C%20zuurstof%2C%20zwavel%20en%20seleen%20zijn%20niet-metalen.)
^nl-Q0847-answer

**nl-Q0848** — Waterstof, koolstof, stikstof, fosfor, zuurstof, zwavel en seleen zijn niet-metalen.

Hydrogen, carbon, nitrogen, phosphorus, oxygen, sulfur and selenium are nonmetals.

Expected form: **en**

Why: Coordination. [[Dutch#^nl-Q0848|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Waterstof%2C%20koolstof%2C%20stikstof%2C%20fosfor%2C%20zuurstof%2C%20zwavel%20en%20seleen%20zijn%20niet-metalen.)
^nl-Q0848-answer

**nl-Q0849** — Hadden we maar een tuin!

If only we had a garden!

Expected form: **maar**

Why: Coordination. [[Dutch#^nl-Q0849|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Hadden%20we%20maar%20een%20tuin%21)
^nl-Q0849-answer

**nl-Q0850** — Hadden we maar een tuin!

If only we had a garden!

Why: Coordination. [[Dutch#^nl-Q0850|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Hadden%20we%20maar%20een%20tuin%21)
^nl-Q0850-answer


### Answers 851–900

**nl-Q0851** — Waar is jullie zoon?

Where's your son?

Why: Questions. [[Dutch#^nl-Q0851|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Waar%20is%20jullie%20zoon%3F)
^nl-Q0851-answer

**nl-Q0852** — Waar is jullie zoon?

Where's your son?

A direct question often places the finite verb before the subject. An indirect question introduced by a question word normally follows subordinate order.

Why: Questions. [[Dutch#^nl-Q0852|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Waar%20is%20jullie%20zoon%3F)
^nl-Q0852-answer

**nl-Q0853** — Waar is uw huiswerk?

Where is your homework?

Expected form: **Waar**

Why: Questions. [[Dutch#^nl-Q0853|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Waar%20is%20uw%20huiswerk%3F)
^nl-Q0853-answer

**nl-Q0854** — Waar is uw huiswerk?

Where is your homework?

Expected form: **Waar**

Why: Questions. [[Dutch#^nl-Q0854|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Waar%20is%20uw%20huiswerk%3F)
^nl-Q0854-answer

**nl-Q0855** — Waar ben je nu op dit moment?

Where are you right now?

Expected form: **Waar**

Why: Questions. [[Dutch#^nl-Q0855|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Waar%20ben%20je%20nu%20op%20dit%20moment%3F)
^nl-Q0855-answer

**nl-Q0856** — Waar ben je nu op dit moment?

Where are you right now?

Why: Questions. [[Dutch#^nl-Q0856|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Waar%20ben%20je%20nu%20op%20dit%20moment%3F)
^nl-Q0856-answer

**nl-Q0857** — Waarom haten jullie Instagram?

Why do you hate Instagram?

Why: Questions. [[Dutch#^nl-Q0857|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Waarom%20haten%20jullie%20Instagram%3F)
^nl-Q0857-answer

**nl-Q0858** — Waarom haten jullie Instagram?

Why do you hate Instagram?

A direct question often places the finite verb before the subject. An indirect question introduced by a question word normally follows subordinate order.

Why: Questions. [[Dutch#^nl-Q0858|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Waarom%20haten%20jullie%20Instagram%3F)
^nl-Q0858-answer

**nl-Q0859** — Waarom doen mensen zulke dwaze dingen?

Why do people do such stupid things?

Expected form: **Waarom**

Why: Questions. [[Dutch#^nl-Q0859|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Waarom%20doen%20mensen%20zulke%20dwaze%20dingen%3F)
^nl-Q0859-answer

**nl-Q0860** — Waarom doen mensen zulke dwaze dingen?

Why do people do such stupid things?

Expected form: **Waarom**

Why: Questions. [[Dutch#^nl-Q0860|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Waarom%20doen%20mensen%20zulke%20dwaze%20dingen%3F)
^nl-Q0860-answer

**nl-Q0861** — Waar is de jongen?

Where is the boy?

Expected form: **Waar**

Why: Questions. [[Dutch#^nl-Q0861|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Waar%20is%20de%20jongen%3F)
^nl-Q0861-answer

**nl-Q0862** — Waar is de jongen?

Where is the boy?

Why: Questions. [[Dutch#^nl-Q0862|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Waar%20is%20de%20jongen%3F)
^nl-Q0862-answer

**nl-Q0863** — Wanneer eindigt het?

When does it end?

Why: Questions. [[Dutch#^nl-Q0863|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Wanneer%20eindigt%20het%3F)
^nl-Q0863-answer

**nl-Q0864** — Wanneer eindigt het?

When does it end?

A direct question often places the finite verb before the subject. An indirect question introduced by a question word normally follows subordinate order.

Why: Questions. [[Dutch#^nl-Q0864|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Wanneer%20eindigt%20het%3F)
^nl-Q0864-answer

**nl-Q0865** — Waarom bevalt dit hotel Tom niet?

Why doesn't Tom like this hotel?

Expected form: **Waarom**

Why: Questions. [[Dutch#^nl-Q0865|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Waarom%20bevalt%20dit%20hotel%20Tom%20niet%3F)
^nl-Q0865-answer

**nl-Q0866** — Waarom bevalt dit hotel Tom niet?

Why doesn't Tom like this hotel?

Expected form: **Waarom**

Why: Questions. [[Dutch#^nl-Q0866|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Waarom%20bevalt%20dit%20hotel%20Tom%20niet%3F)
^nl-Q0866-answer

**nl-Q0867** — Niemand weet wanneer zo'n gebruik ontstaan is.

No one knows when such a custom came into existence.

Expected form: **wanneer**

Why: Questions. [[Dutch#^nl-Q0867|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Niemand%20weet%20wanneer%20zo%27n%20gebruik%20ontstaan%20is.)
^nl-Q0867-answer

**nl-Q0868** — Niemand weet wanneer zo'n gebruik ontstaan is.

No one knows when such a custom came into existence.

Why: Questions. [[Dutch#^nl-Q0868|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Niemand%20weet%20wanneer%20zo%27n%20gebruik%20ontstaan%20is.)
^nl-Q0868-answer

**nl-Q0869** — Waarom vroeg ze deze vraag?

Why did she ask this question?

Why: Questions. [[Dutch#^nl-Q0869|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Waarom%20vroeg%20ze%20deze%20vraag%3F)
^nl-Q0869-answer

**nl-Q0870** — Waarom vroeg ze deze vraag?

Why did she ask this question?

A direct question often places the finite verb before the subject. An indirect question introduced by a question word normally follows subordinate order.

Why: Questions. [[Dutch#^nl-Q0870|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Waarom%20vroeg%20ze%20deze%20vraag%3F)
^nl-Q0870-answer

**nl-Q0871** — Waar kom jij vandaan? - Ik kom uit Frankrijk.

Where are you from? – I am from France.

Expected form: **Waar**

Why: Questions. [[Dutch#^nl-Q0871|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Waar%20kom%20jij%20vandaan%3F%20-%20Ik%20kom%20uit%20Frankrijk.)
^nl-Q0871-answer

**nl-Q0872** — Waar kom jij vandaan? - Ik kom uit Frankrijk.

Where are you from? – I am from France.

Expected form: **Waar**

Why: Questions. [[Dutch#^nl-Q0872|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Waar%20kom%20jij%20vandaan%3F%20-%20Ik%20kom%20uit%20Frankrijk.)
^nl-Q0872-answer

**nl-Q0873** — Waarom zijn we hier?

Why are we here?

Expected form: **Waarom**

Why: Questions. [[Dutch#^nl-Q0873|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Waarom%20zijn%20we%20hier%3F)
^nl-Q0873-answer

**nl-Q0874** — Waarom zijn we hier?

Why are we here?

Why: Questions. [[Dutch#^nl-Q0874|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Waarom%20zijn%20we%20hier%3F)
^nl-Q0874-answer

**nl-Q0875** — Wanneer speelt u tennis?

When do you play tennis?

Why: Questions. [[Dutch#^nl-Q0875|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Wanneer%20speelt%20u%20tennis%3F)
^nl-Q0875-answer

**nl-Q0876** — Wanneer speelt u tennis?

When do you play tennis?

A direct question often places the finite verb before the subject. An indirect question introduced by a question word normally follows subordinate order.

Why: Questions. [[Dutch#^nl-Q0876|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Wanneer%20speelt%20u%20tennis%3F)
^nl-Q0876-answer

**nl-Q0877** — Wat een paella!

What a paella!

Expected form: **Wat**

Why: Questions. [[Dutch#^nl-Q0877|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Wat%20een%20paella%21)
^nl-Q0877-answer

**nl-Q0878** — Wat een paella!

What a paella!

Expected form: **Wat**

Why: Questions. [[Dutch#^nl-Q0878|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Wat%20een%20paella%21)
^nl-Q0878-answer

**nl-Q0879** — Hoe zeg je ''kaisha'' in het Engels?

How do you say "kaisha" in English?

Expected form: **Hoe**

Why: Questions. [[Dutch#^nl-Q0879|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Hoe%20zeg%20je%20%27%27kaisha%27%27%20in%20het%20Engels%3F)
^nl-Q0879-answer

**nl-Q0880** — Hoe zeg je ''kaisha'' in het Engels?

How do you say "kaisha" in English?

Why: Questions. [[Dutch#^nl-Q0880|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Hoe%20zeg%20je%20%27%27kaisha%27%27%20in%20het%20Engels%3F)
^nl-Q0880-answer

**nl-Q0881** — Waar kan ik dit aan proberen?

Where can I try this on?

Why: Questions. [[Dutch#^nl-Q0881|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Waar%20kan%20ik%20dit%20aan%20proberen%3F)
^nl-Q0881-answer

**nl-Q0882** — Waar kan ik dit aan proberen?

Where can I try this on?

A direct question often places the finite verb before the subject. An indirect question introduced by a question word normally follows subordinate order.

Why: Questions. [[Dutch#^nl-Q0882|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Waar%20kan%20ik%20dit%20aan%20proberen%3F)
^nl-Q0882-answer

**nl-Q0883** — Wie neem je mee naar het toneelstuk?

Who are you bringing to the play?

Expected form: **Wie**

Why: Questions. [[Dutch#^nl-Q0883|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Wie%20neem%20je%20mee%20naar%20het%20toneelstuk%3F)
^nl-Q0883-answer

**nl-Q0884** — Wie neem je mee naar het toneelstuk?

Who are you bringing to the play?

Expected form: **Wie**

Why: Questions. [[Dutch#^nl-Q0884|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Wie%20neem%20je%20mee%20naar%20het%20toneelstuk%3F)
^nl-Q0884-answer

**nl-Q0885** — Wat ben je toch een eikel.

You're such a jerk.

Expected form: **Wat**

Why: Questions. [[Dutch#^nl-Q0885|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Wat%20ben%20je%20toch%20een%20eikel.)
^nl-Q0885-answer

**nl-Q0886** — Wat ben je toch een eikel.

You're such a jerk.

Why: Questions. [[Dutch#^nl-Q0886|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Wat%20ben%20je%20toch%20een%20eikel.)
^nl-Q0886-answer

**nl-Q0887** — Waarom geef je me niet wat ik hebben wil?

Why don't you give me what I want to have?

Why: Questions. [[Dutch#^nl-Q0887|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Waarom%20geef%20je%20me%20niet%20wat%20ik%20hebben%20wil%3F)
^nl-Q0887-answer

**nl-Q0888** — Waarom geef je me niet wat ik hebben wil?

Why don't you give me what I want to have?

A direct question often places the finite verb before the subject. An indirect question introduced by a question word normally follows subordinate order.

Why: Questions. [[Dutch#^nl-Q0888|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Waarom%20geef%20je%20me%20niet%20wat%20ik%20hebben%20wil%3F)
^nl-Q0888-answer

**nl-Q0889** — Sami weet niet hoe hij moet bidden.

Sami doesn't know how to pray.

Expected form: **hoe**

Why: Questions. [[Dutch#^nl-Q0889|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Sami%20weet%20niet%20hoe%20hij%20moet%20bidden.)
^nl-Q0889-answer

**nl-Q0890** — Sami weet niet hoe hij moet bidden.

Sami doesn't know how to pray.

Expected form: **hoe**

Why: Questions. [[Dutch#^nl-Q0890|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Sami%20weet%20niet%20hoe%20hij%20moet%20bidden.)
^nl-Q0890-answer

**nl-Q0891** — Weet je wat voor soort bloem dit is?

Do you know what kind of flower this is?

Expected form: **wat**

Why: Questions. [[Dutch#^nl-Q0891|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Weet%20je%20wat%20voor%20soort%20bloem%20dit%20is%3F)
^nl-Q0891-answer

**nl-Q0892** — Weet je wat voor soort bloem dit is?

Do you know what kind of flower this is?

Why: Questions. [[Dutch#^nl-Q0892|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Weet%20je%20wat%20voor%20soort%20bloem%20dit%20is%3F)
^nl-Q0892-answer

**nl-Q0893** — Waar kan ik een kaart van Europa verkrijgen?

Where can I obtain a map of Europe?

Why: Questions. [[Dutch#^nl-Q0893|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Waar%20kan%20ik%20een%20kaart%20van%20Europa%20verkrijgen%3F)
^nl-Q0893-answer

**nl-Q0894** — Waar kan ik een kaart van Europa verkrijgen?

Where can I obtain a map of Europe?

A direct question often places the finite verb before the subject. An indirect question introduced by a question word normally follows subordinate order.

Why: Questions. [[Dutch#^nl-Q0894|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Waar%20kan%20ik%20een%20kaart%20van%20Europa%20verkrijgen%3F)
^nl-Q0894-answer

**nl-Q0895** — Wie bent u?

Who are you?

Expected form: **Wie**

Why: Questions. [[Dutch#^nl-Q0895|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Wie%20bent%20u%3F)
^nl-Q0895-answer

**nl-Q0896** — Wie bent u?

Who are you?

Expected form: **Wie**

Why: Questions. [[Dutch#^nl-Q0896|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Wie%20bent%20u%3F)
^nl-Q0896-answer

**nl-Q0897** — Laat me weten wanneer je weggaat.

Let me know when you’re going to leave.

Expected form: **wanneer**

Why: Questions. [[Dutch#^nl-Q0897|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Laat%20me%20weten%20wanneer%20je%20weggaat.)
^nl-Q0897-answer

**nl-Q0898** — Laat me weten wanneer je weggaat.

Let me know when you’re going to leave.

Why: Questions. [[Dutch#^nl-Q0898|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Laat%20me%20weten%20wanneer%20je%20weggaat.)
^nl-Q0898-answer

**nl-Q0899** — Wat is de kleur van Maria's sjaal?

What color is Mary's scarf?

Why: Questions. [[Dutch#^nl-Q0899|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Wat%20is%20de%20kleur%20van%20Maria%27s%20sjaal%3F)
^nl-Q0899-answer

**nl-Q0900** — Wat is de kleur van Maria's sjaal?

What color is Mary's scarf?

A direct question often places the finite verb before the subject. An indirect question introduced by a question word normally follows subordinate order.

Why: Questions. [[Dutch#^nl-Q0900|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Wat%20is%20de%20kleur%20van%20Maria%27s%20sjaal%3F)
^nl-Q0900-answer


### Answers 901–950

**nl-Q0901** — In alle geval kunt ge beter gehoorzamen aan uw ouders.

In any case you had better obey your parents.

Expected form: **beter**

Why: Comparison. [[Dutch#^nl-Q0901|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=In%20alle%20geval%20kunt%20ge%20beter%20gehoorzamen%20aan%20uw%20ouders.)
^nl-Q0901-answer

**nl-Q0902** — In alle geval kunt ge beter gehoorzamen aan uw ouders.

In any case you had better obey your parents.

Expected form: **beter**

Why: Comparison. [[Dutch#^nl-Q0902|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=In%20alle%20geval%20kunt%20ge%20beter%20gehoorzamen%20aan%20uw%20ouders.)
^nl-Q0902-answer

**nl-Q0903** — Ze is twee jaar ouder dan jij.

She is two years older than you.

Expected form: **dan**

Why: Comparison. [[Dutch#^nl-Q0903|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ze%20is%20twee%20jaar%20ouder%20dan%20jij.)
^nl-Q0903-answer

**nl-Q0904** — Ze is twee jaar ouder dan jij.

She is two years older than you.

Why: Comparison. [[Dutch#^nl-Q0904|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ze%20is%20twee%20jaar%20ouder%20dan%20jij.)
^nl-Q0904-answer

**nl-Q0905** — De school is verder dan het station.

The school is farther than the station.

Why: Comparison. [[Dutch#^nl-Q0905|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=De%20school%20is%20verder%20dan%20het%20station.)
^nl-Q0905-answer

**nl-Q0906** — De school is verder dan het station.

The school is farther than the station.

Comparatives commonly use dan; equality commonly uses zo ... als. Beter is the irregular comparative of goed. Distinguish comparison from other uses of dan/als.

Why: Comparison. [[Dutch#^nl-Q0906|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=De%20school%20is%20verder%20dan%20het%20station.)
^nl-Q0906-answer

**nl-Q0907** — Vanop afstand lijkt de afbeelding beter.

The picture looks better at a distance.

Expected form: **beter**

Why: Comparison. [[Dutch#^nl-Q0907|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Vanop%20afstand%20lijkt%20de%20afbeelding%20beter.)
^nl-Q0907-answer

**nl-Q0908** — Vanop afstand lijkt de afbeelding beter.

The picture looks better at a distance.

Expected form: **beter**

Why: Comparison. [[Dutch#^nl-Q0908|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Vanop%20afstand%20lijkt%20de%20afbeelding%20beter.)
^nl-Q0908-answer

**nl-Q0909** — Als ge op de wc-bril pist, wis het af!

If you piss on the toilet seat, wipe it off!

Expected form: **Als**

Why: Comparison. [[Dutch#^nl-Q0909|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Als%20ge%20op%20de%20wc-bril%20pist%2C%20wis%20het%20af%21)
^nl-Q0909-answer

**nl-Q0910** — Als ge op de wc-bril pist, wis het af!

If you piss on the toilet seat, wipe it off!

Why: Comparison. [[Dutch#^nl-Q0910|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Als%20ge%20op%20de%20wc-bril%20pist%2C%20wis%20het%20af%21)
^nl-Q0910-answer

**nl-Q0911** — De politie nam Dan zijn rijbewijs in beslag.

The police confiscated Dan's driving licence.

Why: Comparison. [[Dutch#^nl-Q0911|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=De%20politie%20nam%20Dan%20zijn%20rijbewijs%20in%20beslag.)
^nl-Q0911-answer

**nl-Q0912** — De politie nam Dan zijn rijbewijs in beslag.

The police confiscated Dan's driving licence.

Comparatives commonly use dan; equality commonly uses zo ... als. Beter is the irregular comparative of goed. Distinguish comparison from other uses of dan/als.

Why: Comparison. [[Dutch#^nl-Q0912|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=De%20politie%20nam%20Dan%20zijn%20rijbewijs%20in%20beslag.)
^nl-Q0912-answer

**nl-Q0913** — Zowel Tom als Mary hebben vandaag met mij daarover gepraat.

Both Tom and Mary talked to me today about that.

Expected form: **als**

Why: Comparison. [[Dutch#^nl-Q0913|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Zowel%20Tom%20als%20Mary%20hebben%20vandaag%20met%20mij%20daarover%20gepraat.)
^nl-Q0913-answer

**nl-Q0914** — Zowel Tom als Mary hebben vandaag met mij daarover gepraat.

Both Tom and Mary talked to me today about that.

Expected form: **als**

Why: Comparison. [[Dutch#^nl-Q0914|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Zowel%20Tom%20als%20Mary%20hebben%20vandaag%20met%20mij%20daarover%20gepraat.)
^nl-Q0914-answer

**nl-Q0915** — De situatie is erger dan we dachten.

The situation is worse than we believed.

Expected form: **dan**

Why: Comparison. [[Dutch#^nl-Q0915|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=De%20situatie%20is%20erger%20dan%20we%20dachten.)
^nl-Q0915-answer

**nl-Q0916** — De situatie is erger dan we dachten.

The situation is worse than we believed.

Why: Comparison. [[Dutch#^nl-Q0916|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=De%20situatie%20is%20erger%20dan%20we%20dachten.)
^nl-Q0916-answer

**nl-Q0917** — Iedere keer als het regent, lekt het dak.

Every time it rains, the roof leaks.

Why: Comparison. [[Dutch#^nl-Q0917|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Iedere%20keer%20als%20het%20regent%2C%20lekt%20het%20dak.)
^nl-Q0917-answer

**nl-Q0918** — Iedere keer als het regent, lekt het dak.

Every time it rains, the roof leaks.

Comparatives commonly use dan; equality commonly uses zo ... als. Beter is the irregular comparative of goed. Distinguish comparison from other uses of dan/als.

Why: Comparison. [[Dutch#^nl-Q0918|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Iedere%20keer%20als%20het%20regent%2C%20lekt%20het%20dak.)
^nl-Q0918-answer

**nl-Q0919** — Analisten beschouwen hem als een van de beste passers in de competitie.

Pundits consider him one of the best passers in the league.

Expected form: **als**

Why: Comparison. [[Dutch#^nl-Q0919|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Analisten%20beschouwen%20hem%20als%20een%20van%20de%20beste%20passers%20in%20de%20competitie.)
^nl-Q0919-answer

**nl-Q0920** — Analisten beschouwen hem als een van de beste passers in de competitie.

Pundits consider him one of the best passers in the league.

Expected form: **als**

Why: Comparison. [[Dutch#^nl-Q0920|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Analisten%20beschouwen%20hem%20als%20een%20van%20de%20beste%20passers%20in%20de%20competitie.)
^nl-Q0920-answer

**nl-Q0921** — Je hebt een betere smaak dan ik dacht.

You have better taste than I thought.

Expected form: **dan**

Why: Comparison. [[Dutch#^nl-Q0921|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Je%20hebt%20een%20betere%20smaak%20dan%20ik%20dacht.)
^nl-Q0921-answer

**nl-Q0922** — Je hebt een betere smaak dan ik dacht.

You have better taste than I thought.

Why: Comparison. [[Dutch#^nl-Q0922|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Je%20hebt%20een%20betere%20smaak%20dan%20ik%20dacht.)
^nl-Q0922-answer

**nl-Q0923** — Als de wekker afgaat, beweeg ik niet.

When the alarm clock goes off, I don’t move.

Why: Comparison. [[Dutch#^nl-Q0923|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Als%20de%20wekker%20afgaat%2C%20beweeg%20ik%20niet.)
^nl-Q0923-answer

**nl-Q0924** — Als de wekker afgaat, beweeg ik niet.

When the alarm clock goes off, I don’t move.

Comparatives commonly use dan; equality commonly uses zo ... als. Beter is the irregular comparative of goed. Distinguish comparison from other uses of dan/als.

Why: Comparison. [[Dutch#^nl-Q0924|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Als%20de%20wekker%20afgaat%2C%20beweeg%20ik%20niet.)
^nl-Q0924-answer

**nl-Q0925** — Zij zien Dan.

They see Dan.

Expected form: **Dan**

Why: Comparison. [[Dutch#^nl-Q0925|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Zij%20zien%20Dan.)
^nl-Q0925-answer

**nl-Q0926** — Zij zien Dan.

They see Dan.

Expected form: **Dan**

Why: Comparison. [[Dutch#^nl-Q0926|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Zij%20zien%20Dan.)
^nl-Q0926-answer

**nl-Q0927** — Goud is veel zwaarder dan water.

Gold is far heavier than water.

Expected form: **dan**

Why: Comparison. [[Dutch#^nl-Q0927|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Goud%20is%20veel%20zwaarder%20dan%20water.)
^nl-Q0927-answer

**nl-Q0928** — Goud is veel zwaarder dan water.

Gold is far heavier than water.

Why: Comparison. [[Dutch#^nl-Q0928|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Goud%20is%20veel%20zwaarder%20dan%20water.)
^nl-Q0928-answer

**nl-Q0929** — Ik verzeker je dat een fout zoals deze nooit meer zal voorkomen.

I assure you that an error like this will never happen again.

Why: Comparison. [[Dutch#^nl-Q0929|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20verzeker%20je%20dat%20een%20fout%20zoals%20deze%20nooit%20meer%20zal%20voorkomen.)
^nl-Q0929-answer

**nl-Q0930** — Ik verzeker je dat een fout zoals deze nooit meer zal voorkomen.

I assure you that an error like this will never happen again.

Comparatives commonly use dan; equality commonly uses zo ... als. Beter is the irregular comparative of goed. Distinguish comparison from other uses of dan/als.

Why: Comparison. [[Dutch#^nl-Q0930|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20verzeker%20je%20dat%20een%20fout%20zoals%20deze%20nooit%20meer%20zal%20voorkomen.)
^nl-Q0930-answer

**nl-Q0931** — Ik zal die fout nooit meer maken.

I will never make that mistake again.

Expected form: **meer**

Why: Comparison. [[Dutch#^nl-Q0931|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20zal%20die%20fout%20nooit%20meer%20maken.)
^nl-Q0931-answer

**nl-Q0932** — Ik zal die fout nooit meer maken.

I will never make that mistake again.

Expected form: **meer**

Why: Comparison. [[Dutch#^nl-Q0932|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20zal%20die%20fout%20nooit%20meer%20maken.)
^nl-Q0932-answer

**nl-Q0933** — De pen heeft meer macht dan het zwaard.

The pen is mightier than the sword.

Expected form: **meer**

Why: Comparison. [[Dutch#^nl-Q0933|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=De%20pen%20heeft%20meer%20macht%20dan%20het%20zwaard.)
^nl-Q0933-answer

**nl-Q0934** — De pen heeft meer macht dan het zwaard.

The pen is mightier than the sword.

Why: Comparison. [[Dutch#^nl-Q0934|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=De%20pen%20heeft%20meer%20macht%20dan%20het%20zwaard.)
^nl-Q0934-answer

**nl-Q0935** — Iets is beter dan niets.

Something is better than nothing.

Why: Comparison. [[Dutch#^nl-Q0935|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Iets%20is%20beter%20dan%20niets.)
^nl-Q0935-answer

**nl-Q0936** — Iets is beter dan niets.

Something is better than nothing.

Comparatives commonly use dan; equality commonly uses zo ... als. Beter is the irregular comparative of goed. Distinguish comparison from other uses of dan/als.

Why: Comparison. [[Dutch#^nl-Q0936|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Iets%20is%20beter%20dan%20niets.)
^nl-Q0936-answer

**nl-Q0937** — De politie beschouwt zijn dood als een moordgeval.

The police are treating his death as a case of murder.

Expected form: **als**

Why: Comparison. [[Dutch#^nl-Q0937|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=De%20politie%20beschouwt%20zijn%20dood%20als%20een%20moordgeval.)
^nl-Q0937-answer

**nl-Q0938** — De politie beschouwt zijn dood als een moordgeval.

The police are treating his death as a case of murder.

Expected form: **als**

Why: Comparison. [[Dutch#^nl-Q0938|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=De%20politie%20beschouwt%20zijn%20dood%20als%20een%20moordgeval.)
^nl-Q0938-answer

**nl-Q0939** — Ik kom altijd eerder uit bed dan de rest van mijn gezin.

I always get up earlier than the rest of my family.

Expected form: **dan**

Why: Comparison. [[Dutch#^nl-Q0939|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20kom%20altijd%20eerder%20uit%20bed%20dan%20de%20rest%20van%20mijn%20gezin.)
^nl-Q0939-answer

**nl-Q0940** — Ik kom altijd eerder uit bed dan de rest van mijn gezin.

I always get up earlier than the rest of my family.

Why: Comparison. [[Dutch#^nl-Q0940|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20kom%20altijd%20eerder%20uit%20bed%20dan%20de%20rest%20van%20mijn%20gezin.)
^nl-Q0940-answer

**nl-Q0941** — Ze is ongeveer even oud als ik.

She is about my age.

Why: Comparison. [[Dutch#^nl-Q0941|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ze%20is%20ongeveer%20even%20oud%20als%20ik.)
^nl-Q0941-answer

**nl-Q0942** — Ze is ongeveer even oud als ik.

She is about my age.

Comparatives commonly use dan; equality commonly uses zo ... als. Beter is the irregular comparative of goed. Distinguish comparison from other uses of dan/als.

Why: Comparison. [[Dutch#^nl-Q0942|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ze%20is%20ongeveer%20even%20oud%20als%20ik.)
^nl-Q0942-answer

**nl-Q0943** — Laat me alsjeblieft weten wanneer je dit niet meer kunt horen.

Please tell me when you cannot hear this anymore.

Expected form: **meer**

Why: Comparison. [[Dutch#^nl-Q0943|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Laat%20me%20alsjeblieft%20weten%20wanneer%20je%20dit%20niet%20meer%20kunt%20horen.)
^nl-Q0943-answer

**nl-Q0944** — Laat me alsjeblieft weten wanneer je dit niet meer kunt horen.

Please tell me when you cannot hear this anymore.

Expected form: **meer**

Why: Comparison. [[Dutch#^nl-Q0944|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Laat%20me%20alsjeblieft%20weten%20wanneer%20je%20dit%20niet%20meer%20kunt%20horen.)
^nl-Q0944-answer

**nl-Q0945** — Ze behandelden me als een kind.

I was treated like a child by them.

Expected form: **als**

Why: Comparison. [[Dutch#^nl-Q0945|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ze%20behandelden%20me%20als%20een%20kind.)
^nl-Q0945-answer

**nl-Q0946** — Ze behandelden me als een kind.

I was treated like a child by them.

Why: Comparison. [[Dutch#^nl-Q0946|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ze%20behandelden%20me%20als%20een%20kind.)
^nl-Q0946-answer

**nl-Q0947** — Ik hou niet meer van haar.

I don't love her anymore.

Why: Comparison. [[Dutch#^nl-Q0947|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20hou%20niet%20meer%20van%20haar.)
^nl-Q0947-answer

**nl-Q0948** — Ik hou niet meer van haar.

I don't love her anymore.

Comparatives commonly use dan; equality commonly uses zo ... als. Beter is the irregular comparative of goed. Distinguish comparison from other uses of dan/als.

Why: Comparison. [[Dutch#^nl-Q0948|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20hou%20niet%20meer%20van%20haar.)
^nl-Q0948-answer

**nl-Q0949** — Het loont zich niet dat oude gebouw te renoveren. Het is beter het af te breken.

This old building isn't worth fixing up. It would be better to tear it down.

Expected form: **beter**

Why: Comparison. [[Dutch#^nl-Q0949|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Het%20loont%20zich%20niet%20dat%20oude%20gebouw%20te%20renoveren.%20Het%20is%20beter%20het%20af%20te%20breken.)
^nl-Q0949-answer

**nl-Q0950** — Het loont zich niet dat oude gebouw te renoveren. Het is beter het af te breken.

This old building isn't worth fixing up. It would be better to tear it down.

Expected form: **beter**

Why: Comparison. [[Dutch#^nl-Q0950|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Het%20loont%20zich%20niet%20dat%20oude%20gebouw%20te%20renoveren.%20Het%20is%20beter%20het%20af%20te%20breken.)
^nl-Q0950-answer


### Answers 951–1000

**nl-Q0951** — Daarom hou ik van je.

That's why I like you.

Expected form: **Daarom**

Why: Cause and concession. [[Dutch#^nl-Q0951|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Daarom%20hou%20ik%20van%20je.)
^nl-Q0951-answer

**nl-Q0952** — Daarom hou ik van je.

That's why I like you.

Why: Cause and concession. [[Dutch#^nl-Q0952|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Daarom%20hou%20ik%20van%20je.)
^nl-Q0952-answer

**nl-Q0953** — Het ziet ernaar uit dat de wereld toch niet is vergaan op 21 december.

It looks like the world didn't end on December 21st after all.

Why: Cause and concession. [[Dutch#^nl-Q0953|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Het%20ziet%20ernaar%20uit%20dat%20de%20wereld%20toch%20niet%20is%20vergaan%20op%2021%20december.)
^nl-Q0953-answer

**nl-Q0954** — Het ziet ernaar uit dat de wereld toch niet is vergaan op 21 december.

It looks like the world didn't end on December 21st after all.

Hoewel introduces concession in a subordinate clause. Daarom and dus express a consequence; toch and echter can signal contrast. Linking meaning and word order need separate attention.

Why: Cause and concession. [[Dutch#^nl-Q0954|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Het%20ziet%20ernaar%20uit%20dat%20de%20wereld%20toch%20niet%20is%20vergaan%20op%2021%20december.)
^nl-Q0954-answer

**nl-Q0955** — Ik ben gay, dus?

I'm gay, so?

Expected form: **dus**

Why: Cause and concession. [[Dutch#^nl-Q0955|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20ben%20gay%2C%20dus%3F)
^nl-Q0955-answer

**nl-Q0956** — Ik ben gay, dus?

I'm gay, so?

Expected form: **dus**

Why: Cause and concession. [[Dutch#^nl-Q0956|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20ben%20gay%2C%20dus%3F)
^nl-Q0956-answer

**nl-Q0957** — Daarom zijn we hier.

That's why we're here.

Expected form: **Daarom**

Why: Cause and concession. [[Dutch#^nl-Q0957|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Daarom%20zijn%20we%20hier.)
^nl-Q0957-answer

**nl-Q0958** — Daarom zijn we hier.

That's why we're here.

Why: Cause and concession. [[Dutch#^nl-Q0958|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Daarom%20zijn%20we%20hier.)
^nl-Q0958-answer

**nl-Q0959** — Waar was je toch?

Just where were you?

Why: Cause and concession. [[Dutch#^nl-Q0959|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Waar%20was%20je%20toch%3F)
^nl-Q0959-answer

**nl-Q0960** — Waar was je toch?

Just where were you?

Hoewel introduces concession in a subordinate clause. Daarom and dus express a consequence; toch and echter can signal contrast. Linking meaning and word order need separate attention.

Why: Cause and concession. [[Dutch#^nl-Q0960|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Waar%20was%20je%20toch%3F)
^nl-Q0960-answer

**nl-Q0961** — Fadil begon te vasten hoewel hij geen moslim was.

Fadil started fasting although he wasn't a Muslim.

Expected form: **hoewel**

Why: Cause and concession. [[Dutch#^nl-Q0961|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Fadil%20begon%20te%20vasten%20hoewel%20hij%20geen%20moslim%20was.)
^nl-Q0961-answer

**nl-Q0962** — Fadil begon te vasten hoewel hij geen moslim was.

Fadil started fasting although he wasn't a Muslim.

Expected form: **hoewel**

Why: Cause and concession. [[Dutch#^nl-Q0962|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Fadil%20begon%20te%20vasten%20hoewel%20hij%20geen%20moslim%20was.)
^nl-Q0962-answer

**nl-Q0963** — Dus sindsdien moesten fabrikanten met echt geld betalen.

So from then on, manufacturers had to pay real cash.

Expected form: **Dus**

Why: Cause and concession. [[Dutch#^nl-Q0963|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Dus%20sindsdien%20moesten%20fabrikanten%20met%20echt%20geld%20betalen.)
^nl-Q0963-answer

**nl-Q0964** — Dus sindsdien moesten fabrikanten met echt geld betalen.

So from then on, manufacturers had to pay real cash.

Why: Cause and concession. [[Dutch#^nl-Q0964|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Dus%20sindsdien%20moesten%20fabrikanten%20met%20echt%20geld%20betalen.)
^nl-Q0964-answer

**nl-Q0965** — Ik heb het je toch gezegd dat je dat moest weggooien.

I thought I told you to throw that away.

Why: Cause and concession. [[Dutch#^nl-Q0965|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20heb%20het%20je%20toch%20gezegd%20dat%20je%20dat%20moest%20weggooien.)
^nl-Q0965-answer

**nl-Q0966** — Ik heb het je toch gezegd dat je dat moest weggooien.

I thought I told you to throw that away.

Hoewel introduces concession in a subordinate clause. Daarom and dus express a consequence; toch and echter can signal contrast. Linking meaning and word order need separate attention.

Why: Cause and concession. [[Dutch#^nl-Q0966|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20heb%20het%20je%20toch%20gezegd%20dat%20je%20dat%20moest%20weggooien.)
^nl-Q0966-answer

**nl-Q0967** — Toch was het best een mooi jaar.

It was a pretty good year, nonetheless.

Expected form: **Toch**

Why: Cause and concession. [[Dutch#^nl-Q0967|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Toch%20was%20het%20best%20een%20mooi%20jaar.)
^nl-Q0967-answer

**nl-Q0968** — Toch was het best een mooi jaar.

It was a pretty good year, nonetheless.

Expected form: **Toch**

Why: Cause and concession. [[Dutch#^nl-Q0968|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Toch%20was%20het%20best%20een%20mooi%20jaar.)
^nl-Q0968-answer

**nl-Q0969** — Hij draaide de fles ondersteboven en schudde hem, maar toch kwam de honing er niet uit.

He turned the bottle upside down and shook it, but still the honey wouldn't come out.

Expected form: **toch**

Why: Cause and concession. [[Dutch#^nl-Q0969|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Hij%20draaide%20de%20fles%20ondersteboven%20en%20schudde%20hem%2C%20maar%20toch%20kwam%20de%20honing%20er%20niet%20uit.)
^nl-Q0969-answer

**nl-Q0970** — Hij draaide de fles ondersteboven en schudde hem, maar toch kwam de honing er niet uit.

He turned the bottle upside down and shook it, but still the honey wouldn't come out.

Why: Cause and concession. [[Dutch#^nl-Q0970|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Hij%20draaide%20de%20fles%20ondersteboven%20en%20schudde%20hem%2C%20maar%20toch%20kwam%20de%20honing%20er%20niet%20uit.)
^nl-Q0970-answer

**nl-Q0971** — Ze wisten niet dat het onmogelijk was, dus ze deden het.

They did not know it was impossible, so they did it.

Why: Cause and concession. [[Dutch#^nl-Q0971|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ze%20wisten%20niet%20dat%20het%20onmogelijk%20was%2C%20dus%20ze%20deden%20het.)
^nl-Q0971-answer

**nl-Q0972** — Ze wisten niet dat het onmogelijk was, dus ze deden het.

They did not know it was impossible, so they did it.

Hoewel introduces concession in a subordinate clause. Daarom and dus express a consequence; toch and echter can signal contrast. Linking meaning and word order need separate attention.

Why: Cause and concession. [[Dutch#^nl-Q0972|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ze%20wisten%20niet%20dat%20het%20onmogelijk%20was%2C%20dus%20ze%20deden%20het.)
^nl-Q0972-answer

**nl-Q0973** — Jij kan niet zwemmen, of toch?

You can't swim, can you?

Expected form: **toch**

Why: Cause and concession. [[Dutch#^nl-Q0973|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Jij%20kan%20niet%20zwemmen%2C%20of%20toch%3F)
^nl-Q0973-answer

**nl-Q0974** — Jij kan niet zwemmen, of toch?

You can't swim, can you?

Expected form: **toch**

Why: Cause and concession. [[Dutch#^nl-Q0974|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Jij%20kan%20niet%20zwemmen%2C%20of%20toch%3F)
^nl-Q0974-answer

**nl-Q0975** — Tom trok toch meer dan één foto?

Tom took more than one picture, didn't he?

Expected form: **toch**

Why: Cause and concession. [[Dutch#^nl-Q0975|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Tom%20trok%20toch%20meer%20dan%20%C3%A9%C3%A9n%20foto%3F)
^nl-Q0975-answer

**nl-Q0976** — Tom trok toch meer dan één foto?

Tom took more than one picture, didn't he?

Why: Cause and concession. [[Dutch#^nl-Q0976|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Tom%20trok%20toch%20meer%20dan%20%C3%A9%C3%A9n%20foto%3F)
^nl-Q0976-answer

**nl-Q0977** — Doe toch niet zo lastig!

Stop being such a pest!

Why: Cause and concession. [[Dutch#^nl-Q0977|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Doe%20toch%20niet%20zo%20lastig%21)
^nl-Q0977-answer

**nl-Q0978** — Doe toch niet zo lastig!

Stop being such a pest!

Hoewel introduces concession in a subordinate clause. Daarom and dus express a consequence; toch and echter can signal contrast. Linking meaning and word order need separate attention.

Why: Cause and concession. [[Dutch#^nl-Q0978|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Doe%20toch%20niet%20zo%20lastig%21)
^nl-Q0978-answer

**nl-Q0979** — Doe wat ge wilt, gekletst wordt er toch.

Do whatever you want, there will be gossiping anyhow.

Expected form: **toch**

Why: Cause and concession. [[Dutch#^nl-Q0979|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Doe%20wat%20ge%20wilt%2C%20gekletst%20wordt%20er%20toch.)
^nl-Q0979-answer

**nl-Q0980** — Doe wat ge wilt, gekletst wordt er toch.

Do whatever you want, there will be gossiping anyhow.

Expected form: **toch**

Why: Cause and concession. [[Dutch#^nl-Q0980|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Doe%20wat%20ge%20wilt%2C%20gekletst%20wordt%20er%20toch.)
^nl-Q0980-answer

**nl-Q0981** — Maria is een gepensioneerde tandarts, toch?

Mary is a retired dentist, isn't she?

Expected form: **toch**

Why: Cause and concession. [[Dutch#^nl-Q0981|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Maria%20is%20een%20gepensioneerde%20tandarts%2C%20toch%3F)
^nl-Q0981-answer

**nl-Q0982** — Maria is een gepensioneerde tandarts, toch?

Mary is a retired dentist, isn't she?

Why: Cause and concession. [[Dutch#^nl-Q0982|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Maria%20is%20een%20gepensioneerde%20tandarts%2C%20toch%3F)
^nl-Q0982-answer

**nl-Q0983** — Ik hou toch van je!

I love you anyway!

Why: Cause and concession. [[Dutch#^nl-Q0983|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20hou%20toch%20van%20je%21)
^nl-Q0983-answer

**nl-Q0984** — Ik hou toch van je!

I love you anyway!

Hoewel introduces concession in a subordinate clause. Daarom and dus express a consequence; toch and echter can signal contrast. Linking meaning and word order need separate attention.

Why: Cause and concession. [[Dutch#^nl-Q0984|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20hou%20toch%20van%20je%21)
^nl-Q0984-answer

**nl-Q0985** — Dat mag toch niet?

That's not allowed, right?

Expected form: **toch**

Why: Cause and concession. [[Dutch#^nl-Q0985|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Dat%20mag%20toch%20niet%3F)
^nl-Q0985-answer

**nl-Q0986** — Dat mag toch niet?

That's not allowed, right?

Expected form: **toch**

Why: Cause and concession. [[Dutch#^nl-Q0986|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Dat%20mag%20toch%20niet%3F)
^nl-Q0986-answer

**nl-Q0987** — Terwijl ik nu toch hier ben, denk je dat je de batterijen kunt vervangen?

But while I am here, do you think you could replace the batteries?

Expected form: **toch**

Why: Cause and concession. [[Dutch#^nl-Q0987|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Terwijl%20ik%20nu%20toch%20hier%20ben%2C%20denk%20je%20dat%20je%20de%20batterijen%20kunt%20vervangen%3F)
^nl-Q0987-answer

**nl-Q0988** — Terwijl ik nu toch hier ben, denk je dat je de batterijen kunt vervangen?

But while I am here, do you think you could replace the batteries?

Why: Cause and concession. [[Dutch#^nl-Q0988|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Terwijl%20ik%20nu%20toch%20hier%20ben%2C%20denk%20je%20dat%20je%20de%20batterijen%20kunt%20vervangen%3F)
^nl-Q0988-answer

**nl-Q0989** — Stel je even voor: hij is arts en toch rookt hij.

Just imagine: he is a doctor, and yet he is a smoker.

Why: Cause and concession. [[Dutch#^nl-Q0989|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Stel%20je%20even%20voor%3A%20hij%20is%20arts%20en%20toch%20rookt%20hij.)
^nl-Q0989-answer

**nl-Q0990** — Stel je even voor: hij is arts en toch rookt hij.

Just imagine: he is a doctor, and yet he is a smoker.

Hoewel introduces concession in a subordinate clause. Daarom and dus express a consequence; toch and echter can signal contrast. Linking meaning and word order need separate attention.

Why: Cause and concession. [[Dutch#^nl-Q0990|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Stel%20je%20even%20voor%3A%20hij%20is%20arts%20en%20toch%20rookt%20hij.)
^nl-Q0990-answer

**nl-Q0991** — Daarom heb ik het druk.

That's why I'm busy.

Expected form: **Daarom**

Why: Cause and concession. [[Dutch#^nl-Q0991|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Daarom%20heb%20ik%20het%20druk.)
^nl-Q0991-answer

**nl-Q0992** — Daarom heb ik het druk.

That's why I'm busy.

Expected form: **Daarom**

Why: Cause and concession. [[Dutch#^nl-Q0992|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Daarom%20heb%20ik%20het%20druk.)
^nl-Q0992-answer

**nl-Q0993** — Ik zei je toch dat het niet zou lukken.

I told you it wouldn't work.

Expected form: **toch**

Why: Cause and concession. [[Dutch#^nl-Q0993|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20zei%20je%20toch%20dat%20het%20niet%20zou%20lukken.)
^nl-Q0993-answer

**nl-Q0994** — Ik zei je toch dat het niet zou lukken.

I told you it wouldn't work.

Why: Cause and concession. [[Dutch#^nl-Q0994|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20zei%20je%20toch%20dat%20het%20niet%20zou%20lukken.)
^nl-Q0994-answer

**nl-Q0995** — Ik wist dat ik het niet kon doen, maar ik heb het toch geprobeerd.

I knew I couldn't do it, but I tried anyway.

Why: Cause and concession. [[Dutch#^nl-Q0995|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20wist%20dat%20ik%20het%20niet%20kon%20doen%2C%20maar%20ik%20heb%20het%20toch%20geprobeerd.)
^nl-Q0995-answer

**nl-Q0996** — Ik wist dat ik het niet kon doen, maar ik heb het toch geprobeerd.

I knew I couldn't do it, but I tried anyway.

Hoewel introduces concession in a subordinate clause. Daarom and dus express a consequence; toch and echter can signal contrast. Linking meaning and word order need separate attention.

Why: Cause and concession. [[Dutch#^nl-Q0996|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20wist%20dat%20ik%20het%20niet%20kon%20doen%2C%20maar%20ik%20heb%20het%20toch%20geprobeerd.)
^nl-Q0996-answer

**nl-Q0997** — Wist je dat Julia tien jaar in Moskou gewoond heeft? Daarom spreekt ze zo goed Russisch.

Did you know that Julia lived 10 years in Moscow? That's why she speaks Russian so well.

Expected form: **Daarom**

Why: Cause and concession. [[Dutch#^nl-Q0997|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Wist%20je%20dat%20Julia%20tien%20jaar%20in%20Moskou%20gewoond%20heeft%3F%20Daarom%20spreekt%20ze%20zo%20goed%20Russisch.)
^nl-Q0997-answer

**nl-Q0998** — Wist je dat Julia tien jaar in Moskou gewoond heeft? Daarom spreekt ze zo goed Russisch.

Did you know that Julia lived 10 years in Moscow? That's why she speaks Russian so well.

Expected form: **Daarom**

Why: Cause and concession. [[Dutch#^nl-Q0998|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Wist%20je%20dat%20Julia%20tien%20jaar%20in%20Moskou%20gewoond%20heeft%3F%20Daarom%20spreekt%20ze%20zo%20goed%20Russisch.)
^nl-Q0998-answer

**nl-Q0999** — Ik heb zojuist mijn paspoort verlengd, dus ik kan er weer tien jaar mee verder.

I've just renewed my passport, so it's good for another ten years.

Expected form: **dus**

Why: Cause and concession. [[Dutch#^nl-Q0999|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20heb%20zojuist%20mijn%20paspoort%20verlengd%2C%20dus%20ik%20kan%20er%20weer%20tien%20jaar%20mee%20verder.)
^nl-Q0999-answer

**nl-Q1000** — Ik heb zojuist mijn paspoort verlengd, dus ik kan er weer tien jaar mee verder.

I've just renewed my passport, so it's good for another ten years.

Why: Cause and concession. [[Dutch#^nl-Q1000|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=nld&query=Ik%20heb%20zojuist%20mijn%20paspoort%20verlengd%2C%20dus%20ik%20kan%20er%20weer%20tien%20jaar%20mee%20verder.)
^nl-Q1000-answer


## Read and speak

Read the native sentence first, identify its predicate and one grammar form, then check the translation. Say it aloud and change one detail.

### Learning with a clear purpose

Ik leer een nieuwe taal. Elke dag lees ik een korte tekst en luister ik naar duidelijke voorbeelden. Ik schrijf nuttige woorden in een schrift. Wanneer ik een fout maak, bekijk ik de regel en probeer ik het opnieuw. Mijn doel is mensen te begrijpen en mijn gedachten duidelijk uit te drukken.

I am learning a new language. Each day, I read a short text and listen to clear examples. I write useful words in a notebook. When I make a mistake, I check the rule and try again. My goal is to understand people and express my ideas clearly.

![[Resources/Audio/nl/Reading passage.mp3]]

**Sami gebruikt YouTube.**

Sami uses YouTube.

**Jullie zijn goud waard.**

You're worth gold.

**Dit boek was gemakkelijk.**

This book was easy.

**Ik ga vandaag niet meer werken.**

I am not going to work more today.

**Tom maakte brood.**

Tom made bread.

**John houdt van schaken.**

John likes chess.

**Hoelang moeten we wachten, denk je?**

How long do you think we'll have to wait?

**Ik heb geen idee hoe ze dat voor elkaar gekregen hebben.**

I don't know how they did it.

**Mexico-Stad is de hoofdstad van Mexico.**

Mexico City is the capital of Mexico.

**Ben je voor iets allergisch?**

Are you allergic to anything?

**Mijn Frans is nog steeds niet zo goed.**

My French is still not very good.

**Water heeft nul calorieën.**

Water has zero calories.

**Wie heeft je dit aangedaan?**

Who did this to you?

**Waarom weet jij dat?**

Why do you know that?

**Een vrouwenhater moet je echt zo hard vertrouwen als het weer.**

We must trust misogynists as much as we can trust the weather.

## Professional writing

Write an introduction, a polite request, an explanation of a finding, a summary of a passage and a tactful disagreement. Use the professional/advanced lessons for models.

## PDF edition

[[Resources/PDFs/Dutch.pdf|Open the complete printable book]]
