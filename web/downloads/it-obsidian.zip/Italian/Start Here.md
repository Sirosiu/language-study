# Italian study

[[Italian|Open the complete Italian course note]]

Audio and the printable PDF are in Resources. This vault contains one language.

[[Sources and licenses]]
