# Italian

Near-native ambition - C2-oriented study

Everything for this language is in this note. Open a rule, read its examples and follow its practice link. Answers stay in this same note.

[[Start Here|All languages]] · [[Sources and licenses|Sources]]

## Start reading

### l’alfabeto

| Written form | Name / reading | Related forms |
|---|---|---|
| A a | a  |  ·  ·  |
| B b | bi  |  ·  ·  |
| C c | ci  |  ·  ·  |
| D d | di  |  ·  ·  |
| E e | e  |  ·  ·  |
| F f | effe  |  ·  ·  |
| G g | gi  |  ·  ·  |
| H h | acca  |  ·  ·  |
| I i | i  |  ·  ·  |
| J j | i lunga  |  ·  ·  |
| K k | cappa  |  ·  ·  |
| L l | elle  |  ·  ·  |
| M m | emme  |  ·  ·  |
| N n | enne  |  ·  ·  |
| O o | o  |  ·  ·  |
| P p | pi  |  ·  ·  |
| Q q | cu  |  ·  ·  |
| R r | erre  |  ·  ·  |
| S s | esse  |  ·  ·  |
| T t | ti  |  ·  ·  |
| U u | u  |  ·  ·  |
| V v | vu / vi  |  ·  ·  |
| W w | doppia vu  |  ·  ·  |
| X x | ics  |  ·  ·  |
| Y y | ipsilon / i greca  |  ·  ·  |
| Z z | zeta  |  ·  ·  |

![[Resources/Audio/it/Script and first phrases.mp3]]

The player above is synthetic speech. Word tracks below work offline.

### Traditional and borrowed letters

The traditional Italian alphabet has 21 letters. J, K, W, X and Y appear chiefly in foreign words and names; the table includes all 26 so that you can spell those too.

### Read c and g with their neighbours

c before e/i usually gives /tʃ/; elsewhere /k/. ch keeps /k/ before e/i. g before e/i usually gives /dʒ/; gh keeps /g/. gn gives /ɲ/; gli often gives /ʎ/. sc before e/i gives /ʃ/.

### Double consonants and stress

Consonant length matters: pala = shovel; palla = ball. Most words have penultimate stress, but many do not. Written accents mark final stress and some distinctions: città, perché, è. e/o have open and closed qualities not always marked in writing.

### Agree in a noun phrase

il libro rosso → i libri rossi = the red book → the red books; la casa nuova → le case nuove = the new house → the new houses.

### Contract a preposition

a + il → al; di + il → del; in + il → nel. Vado al mercato. = I am going to the market. The article form changes with gender, number and following sound.

### Build a word family

felice → felicità = happy → happiness; possibile → impossibile. A suffix can alter stress, spelling and meaning; check the resulting word in use.

**Buongiorno.**

Good morning / hello.

**Sto imparando l’italiano.**

I am learning Italian.

**Può ripetere, per favore?**

Can you repeat, please?

**Che cosa significa questa parola?**

What does this word mean?

### Grammar terms in plain English

**Noun** — A word naming a person, thing or idea: student, book, freedom.

**Verb** — A word describing an action or state: read, know, be.

**Subject** — The participant linked to the main verb’s subject pattern. In The student reads a book, the student is the subject.

**Object** — A participant selected by a verb. In The student reads a book, a book is the direct object.

**Agreement** — One word changes to match another, for example an adjective matching a noun’s gender and number.

**Case** — A noun/pronoun form marking its relationship in a sentence. Cases can mark subjects, objects, possession or relations usually expressed by English prepositions.

**Gender** — A grammatical noun class. It does not always describe the sex of a person or any physical property.

**Tense** — A verb system that relates a situation to a time, often past or non-past.

**Aspect** — How a situation is viewed: unfolding, completed, habitual, experienced or in a resulting state.

**Infinitive** — A non-finite verb form often used for a dictionary entry or a complement. It does not by itself give the ordinary person/tense pattern.

**Participle** — A verb-derived form used in compound predicates or as a modifier; its exact function depends on the language and construction.

**Clause** — A unit organised around a predicate. One sentence can contain several clauses.

**Register** — Language choices suited to a situation: casual conversation, polite requests, academic writing or another context.

## Grammar, examples and practice

### Sound, articles and noun phrases

Consonant length can distinguish words: pala and palla. Practise holding a consonant closure or friction rather than merely stressing the following vowel. Lexical stress can be unpredictable; dictionary audio and stress marking matter. Italian has open/closed e and o distinctions that are not always shown in ordinary spelling. Regional realisations vary.
Articles depend on gender, number and initial sound. Masculine il libro, lo studente, l'amico become i libri, gli studenti, gli amici. Feminine la casa and l'amica become le case and le amiche. Un amico has no apostrophe; un'amica does. Adjectives agree with the noun, with several inflection classes. Learn irregular plurals and changes of meaning rather than treating -o/-a as infallible gender tests.

**uno studente / un’amica**

a male student / a female friend Initial sound and gender determine article choice.

**una proposta interessante / due proposte interessanti**

an interesting proposal / two interesting proposals Agreement in number is visible on noun and adjective.

#### Definite articles

Articles depend on gender, number and following sound. Lo and gli occur before particular masculine onsets, including z and s + consonant. Learn article and noun together.

**I miei doveri pubblici mi prendono molto tempo.**

My public duties take a lot of time.

**Temo che mi verrà il mal di testa pensando a quant'è fastidioso Chris.**

My head starts to hurt when I think about how annoying Chris is.

![[Resources/Audio/it/Rule 01.mp3]]

[[Italian#^it-Q0001|Practise this rule (50 questions)]]

#### Indefinite articles

Un/uno introduce masculine singular nouns; una introduces feminine singular nouns. Feminine una elides before a vowel: un’amica. Masculine un before a vowel has no apostrophe.

**Non sono una spiona.**

I'm not a tattletale.

**A voi servirà un alibi.**

You're going to need an alibi.

![[Resources/Audio/it/Rule 02.mp3]]

[[Italian#^it-Q0051|Practise this rule (50 questions)]]

#### Articulated prepositions

Many prepositions combine with definite articles. The form retains article gender/number and follows the same sound-conditioned distinctions: a + il = al, a + lo = allo.

**Ai bambini piace più giocare che studiare.**

Children like playing more than studying.

**Da quale parte del Canada venite?**

Where in Canada are you from?

![[Resources/Audio/it/Rule 03.mp3]]

[[Italian#^it-Q0101|Practise this rule (50 questions)]]

#### Negation

Non usually precedes the finite verb. Negative words can combine with non when they follow the verb. Their order affects whether a separate non is needed.

**Io non devo seguire Tom.**

I don't have to follow Tom.

**Non voglio sedermi accanto a loro.**

I don't want to sit next to them.

![[Resources/Audio/it/Rule 16.mp3]]

[[Italian#^it-Q0751|Practise this rule (50 questions)]]

#### Questions

Question words specify the missing information. Italian often keeps statement-like word order and uses intonation; a question word is not a command to add an English-style auxiliary.

**Perché state facendo delle foto?**

Why are you taking pictures?

**Capisci come funziona?**

Do you understand how it works?

![[Resources/Audio/it/Rule 17.mp3]]

[[Italian#^it-Q0801|Practise this rule (50 questions)]]

#### Comparison and agreement

Più/meno build regular comparison. Meglio is commonly adverbial; migliore commonly adjectival. Attributive and predicative adjectives agree with their nouns in gender and number.

**Faresti meglio a osservarli.**

You'd better watch them.

**Abbiamo bisogno di trovare una nuova babysitter.**

We need to find a new babysitter.

![[Resources/Audio/it/Rule 20.mp3]]

[[Italian#^it-Q0951|Practise this rule (50 questions)]]

<details><summary>Choose il / lo psicologo.</summary>

Lo psicologo. The initial cluster belongs to the lo article pattern.

</details>

<details><summary>Why does un’amica have an apostrophe but un amico does not?</summary>

The feminine una undergoes elision; masculine un is already the relevant form.

</details>

### Present and past verb perspectives

Present parlare: parlo, parli, parla, parliamo, parlate, parlano. Frequent essere, avere, andare and fare are irregular. The passato prossimo presents bounded past events; the imperfetto commonly supplies habit, background or an unfolding state. In narrative, Quando sono arrivato, lavoravano combines these perspectives.
Compound tense auxiliaries are lexical and construction-dependent. In common essere compounds the participle agrees with the subject: sono arrivata. Many transitive verbs use avere. Preceding direct-object clitics can trigger participle agreement, especially lo, la, li, le: le ho lette. The passato remoto remains important in literature and is used differently across regions. Do not classify it as merely an obsolete equivalent of passato prossimo.

**Mentre leggevo, è arrivato un messaggio.**

While I was reading, a message arrived. Imperfect activity against a bounded arrival.

**Le lettere? Le ho lette ieri.**

The letters? I read them yesterday. Let­te agrees with the preceding feminine plural object clitic.

#### Essere in the present

Essere is irregular and can act as copula or compound-tense auxiliary. Sono can mean I am or they are. Context and subject agreement resolve the form.

**So che Tom è ricco.**

I know Tom is wealthy.

**Siete state in grado di parlare con lui?**

Were you able to talk to him?

![[Resources/Audio/it/Rule 04.mp3]]

[[Italian#^it-Q0151|Practise this rule (50 questions)]]

#### Avere in the present

Avere expresses possession and forms many compound tenses. H is silent in these forms but distinguishes written homophones such as ha/a and ho/o.

**Tom ha rinunciato.**

Tom quit.

**Ti ho vista baciarlo. Non negarlo!**

I saw you kiss him. Do not deny it!

![[Resources/Audio/it/Rule 05.mp3]]

[[Italian#^it-Q0201|Practise this rule (50 questions)]]

#### Imperfect perspective

The imperfetto presents past states, habits and background. Passato prossimo or passato remoto can present events as bounded. The choice reflects viewpoint and discourse as well as regional style.

**Tom non aveva denaro.**

Tom had no money.

**Era troppo lenta.**

You were too slow.

![[Resources/Audio/it/Rule 06.mp3]]

[[Italian#^it-Q0251|Practise this rule (50 questions)]]

#### Past participles

The passato prossimo combines an auxiliary with a participle. With essere, the participle generally agrees with the subject. Direct-object clitics can affect agreement with avere.

**Non so se l'avrebbe fatto per me.**

I don't know if he would have done it for me.

**Se oggi fosse stata domenica, saremmo andati a pescare.**

If it were Sunday today, we would go fishing.

![[Resources/Audio/it/Rule 07.mp3]]

[[Italian#^it-Q0301|Practise this rule (50 questions)]]

#### Future forms

The futuro expresses future situations and can also mark a present conjecture. Many frequent verbs have irregular future stems, which recur in the conditional.

**Non penso che Tom sarà impressionato.**

I don't think Tom will be impressed.

**Lui sarà di ritorno tra un'ora.**

He will be back in an hour.

![[Resources/Audio/it/Rule 08.mp3]]

[[Italian#^it-Q0351|Practise this rule (50 questions)]]

<details><summary>Complete for a female speaker: Sono arrivat__ ieri.</summary>

Sono arrivata ieri. Essere compound with feminine singular subject agreement.

</details>

<details><summary>Contrast sapevo and ho saputo.</summary>

Sapevo presents knowing as a state; ho saputo often presents finding out or a bounded acquisition of knowledge.

</details>

### Clitics, ci, ne and relative clauses

Unstressed pronouns usually precede a finite verb or attach to an infinitive in suitable patterns. Combined pronouns change forms: mi + lo becomes me lo; gli/le with lo can form glielo. Ci can refer to place or certain complements and appears in lexical expressions; ne often represents di + complement or a quantity. Their meanings depend on the verb construction.
Che commonly functions as subject or direct-object relative. Cui follows prepositions: il metodo di cui abbiamo bisogno. Il cui marks possession and its article agrees with the possessed noun: l'autrice il cui libro ho letto. Avoid copying English preposition placement; Italian relative clauses require their own government pattern.

**Ne ho letti tre.**

I have read three of them. Ne carries a quantified noun; agreement can reflect the understood masculine plural object.

**È il metodo di cui abbiamo bisogno.**

It is the method we need. Avere bisogno di licenses di cui.

#### Direct object clitics

Lo/la/li/le can replace direct objects. They normally precede a finite verb but can attach to infinitives and some imperatives. Some identical forms also serve other roles.

**Mi piace questo quartiere.**

I like this neighborhood.

**Cosa vi piace di lui?**

What do you like about him?

![[Resources/Audio/it/Rule 11.mp3]]

[[Italian#^it-Q0501|Practise this rule (50 questions)]]

#### Indirect objects

Indirect clitics replace common recipient complements. Gli and le distinguish many singular uses; combined clitics take special forms. Always identify what is being given and to whom.

**La luna è uscita da dietro le nuvole.**

The moon came out from behind the clouds.

**Vi piace il vino bianco?**

Do you like white wine?

![[Resources/Audio/it/Rule 12.mp3]]

[[Italian#^it-Q0551|Practise this rule (50 questions)]]

#### Ci and ne

Ci can refer to place or appear in other constructions. Ne often replaces a di relation or quantity. Retain the number when needed: Ne ho due. Learn their meanings with complete verb phrases.

**Ci sono delle lettere per me nella posta di oggi?**

Are there any letters to me in today's mail?

**Ci lamentiamo dei nostri vicini.**

We complain about our neighbors.

![[Resources/Audio/it/Rule 13.mp3]]

[[Italian#^it-Q0601|Practise this rule (50 questions)]]

#### Relative clauses

Che commonly serves as relative subject or direct object. Cui commonly follows a preposition. Che also introduces complement clauses, so determine the connection rather than naming the form alone.

**Ascoltate bene quello che dico.**

Listen well to what I say.

**Pensa che Tom stia ancora dormendo?**

Do you think Tom is still asleep?

![[Resources/Audio/it/Rule 15.mp3]]

[[Italian#^it-Q0701|Practise this rule (50 questions)]]

<details><summary>Replace a questa possibilità: Penso a questa possibilità.</summary>

Ci penso. Ci can replace the thing-complement here.

</details>

<details><summary>Give it to me using dare and combined clitics.</summary>

Dammelo. Affirmative familiar imperative with attached combined pronouns; double m belongs to this form.

</details>

### Subjunctive and conditional reasoning

The congiuntivo appears after many expressions of opinion, doubt, desire, necessity and concession. Credo che sia utile is a common careful-standard pattern; ordinary usage varies, but advanced formal writing requires control. Benché normally takes subjunctive. Tense choice relates the subordinate situation to the main clause and time perspective.
Hypothetical conditions use se + imperfect subjunctive with present conditional: se avessi tempo, verrei. Past counterfactuals use pluperfect subjunctive with past conditional: se l'avessi saputo, avrei aspettato. The conditional also serves polite requests and future-in-the-past reporting. Do not put it automatically after se in the ordinary counterfactual pattern.

**Benché i risultati siano promettenti, occorre verificarli.**

Although the results are promising, they need to be verified. Subjunctive concession with a main-clause necessity statement.

**Se avessimo controllato, avremmo trovato l’errore.**

If we had checked, we would have found the error. Past counterfactual.

#### Conditional and politeness

The condizionale expresses hypothetical results, polite requests and some reported claims. Vorrei is a useful request form. Conditions with se require a separate choice of tense/mood.

**Nessuna cosa vivente potrebbe vivere senza aria.**

No living thing could live without air.

**Tom dovrebbe lasciarmi aiutare Mary.**

Tom should let me help Mary.

![[Resources/Audio/it/Rule 09.mp3]]

[[Italian#^it-Q0401|Practise this rule (50 questions)]]

#### Subjunctive forms

The congiuntivo occurs in many dependent clauses after attitude, doubt, desire or evaluation. Learn a governing expression with its subordinate form; avoid replacing every que-like clause automatically.

**Vada a dirle come si sente.**

Go tell her how you feel.

**Chi pensate che siano?**

Who do you think they are?

![[Resources/Audio/it/Rule 10.mp3]]

[[Italian#^it-Q0451|Practise this rule (50 questions)]]

#### Conditions

Se introduces if or indirect whether. Unreal present conditions commonly combine imperfect subjunctive with conditional. Unreal past conditions use pluperfect subjunctive and past conditional.

**Scrisse la lettera a se stessa.**

She wrote a letter to herself.

**Io non mi sveglierò neanche se suona la sveglia.**

I won't wake up even if the alarm rings.

![[Resources/Audio/it/Rule 18.mp3]]

[[Italian#^it-Q0851|Practise this rule (50 questions)]]

<details><summary>Correct: Se avrei tempo, verrei.</summary>

Se avessi tempo, verrei. Imperfect subjunctive in the if-clause.

</details>

<details><summary>Request clarification politely.</summary>

Potrebbe chiarire questo punto? Conditional of potere makes the request courteous.

</details>

### Passive, si and causative constructions

The passive uses essere + participle, with agreement. Venire can serve as a passive auxiliary in appropriate simple-tense contexts and emphasise the process. Andare + participle can convey necessity: il testo va rivisto means it needs revision. These are construction-specific, not freely interchangeable in every tense.
Si passivante and impersonal si must be distinguished: si vendono libri has plural agreement with libri; si lavora molto has an impersonal singular verb. Reflexive verbs interacting with impersonal si can use ci si: ci si prepara. Fare + infinitive expresses causation or arranging an action, as in far controllare i dati.

**I dati vengono controllati ogni settimana.**

The data are checked every week. Venire supports a process passive in present tense.

**Il rapporto va rivisto.**

The report needs to be revised. Andare + participle expresses a required action.

#### Reflexive and impersonal si

Si can mark a reflexive action, a passive-like construction or an impersonal statement. Its meaning and agreement depend on the verb and noun phrase; it does not always mean oneself.

**Si sente molto felice.**

He feels very happy.

**Più si lavora, più si guadagna.**

The more one works, the more one earns.

![[Resources/Audio/it/Rule 14.mp3]]

[[Italian#^it-Q0651|Practise this rule (50 questions)]]

<details><summary>Explain si pubblicano i risultati.</summary>

A passive si construction with plural agreement: the results are published.

</details>

<details><summary>Express We had the figures checked.</summary>

Abbiamo fatto controllare le cifre. Fare + infinitive describes arranged checking.

</details>

### Connectors, word formation and professional register

Tuttavia contrasts, pertanto infers, inoltre adds and nonostante introduces concession. Purché sets a condition, commonly with subjunctive. Learn useful collocations: formulare un'ipotesi, condurre uno studio, trarre una conclusione, mettere in discussione. Literal synonym replacement can sound unnatural even with correct grammar.
Professional address commonly uses Lei with third-person singular grammar; capitalisation conventions vary. A polite email should state the purpose and needed action. Dense nominalisations can hide responsibility, so revise the sentence around a clear subject and verb. Recognise journalistic and literary formulations without using them indiscriminately in conversation.

**Questi dati sostengono l’ipotesi; tuttavia, non escludono altre spiegazioni.**

These data support the hypothesis; however, they do not exclude other explanations. The qualification limits the inference.

**Le sarei grato se potesse chiarire il procedimento.**

I would be grateful if you could clarify the procedure. Formal courtesy; grammatical agreement may be adjusted to the speaker.

#### Logical connectors

Distinguish cause, concession and result. Benché generally takes subjunctive. Però/tuttavia connect a contrast without the same subordinate grammar.

**Ho cliccato sul link, però non è successo niente.**

I clicked the link, but nothing happened.

**Perché le persone hanno paura di me?**

Why are people scared of me?

![[Resources/Audio/it/Rule 19.mp3]]

[[Italian#^it-Q0901|Practise this rule (50 questions)]]

<details><summary>Replace Questo dimostra tutto with a precise limitation.</summary>

Il risultato è coerente con l’ipotesi, ma non dimostra un rapporto causale.

</details>

<details><summary>Write a clear professional email in 100 words.</summary>

Use appropriate Lei address, purpose, reason and next step. Revise unnecessary noun stacking and unclear pronouns.

</details>

### Advanced reading and inference

Original teaching passage: Una spiegazione può apparire convincente senza essere confermata dai dati disponibili. È quindi necessario distinguere ciò che si osserva da ciò che si deduce. Quanto più chiaramente vengono descritte le condizioni dello studio, tanto più agevole sarà valutarne la portata. Riconoscere un limite non significa negare l'utilità dell'intera analisi.
Translation: An explanation can appear convincing without being confirmed by the available data. It is therefore necessary to distinguish what is observed from what is inferred. The more clearly the study conditions are described, the easier it will be to assess its scope. Recognising a limitation does not mean denying the usefulness of the whole analysis.
Ciò che is a formal nominal relative; quanto più ... tanto più expresses a proportional relationship. Valutarne contains ne, linking scope to the study. The final sentence denies an overgeneralised rejection, not the existence of limitations.

**valutarne la portata**

assess its scope Ne expresses the relationship of the scope to the study.

**ciò che si osserva**

what is observed Nominal relative with an impersonal/passive-like perspective.

<details><summary>Identify the logical relation between the first two sentences.</summary>

The need to distinguish observation and inference follows from the gap between persuasiveness and confirmation.

</details>

<details><summary>Write an alternative final sentence preserving the meaning.</summary>

Un limite non rende necessariamente inutile l’analisi nel suo complesso. Other natural formulations are valid.

</details>

### Idioms, literary recognition and near-native study

Magari can express possibility, a wish or agreement depending on context. Mica can strengthen or qualify negation in conversation and is not a universal equivalent of not. Non vedo l'ora di ... means looking forward to an event. Recognise how these expressions function in complete exchanges.
Near-native ambition needs literary prose, quality nonfiction, conversation and specialised writing across topics. Learn passato remoto and literary vocabulary for recognition, but follow contemporary community norms for production. Notice irony, understatement and emotional colouring. A phrase notebook should distinguish something grammatically possible from something a speaker would conventionally say in that situation.

**Non vedo l’ora di leggere il libro.**

I am looking forward to reading the book. A fixed expression rather than a literal failure to see the time.

**Magari potessi andarci!**

If only I could go there! Magari plus subjunctive expresses a wish here.

<details><summary>Why cannot magari have one English translation in every sentence?</summary>

Its discourse functions include wishing, possibility and context-dependent responses. Interpret the whole exchange.

</details>

<details><summary>Compare a literary paragraph with a contemporary interview.</summary>

Record tense choice, address, sentence complexity and idiom. Explain which features you would imitate in a professional email and why.

</details>

## Word bank and recordings

1,000 study entries, based on dictionary selections and authored teaching glosses. Learn a word in a phrase; consult the linked entry for additional senses.

<details><summary>Words 1–50</summary>

![[Resources/Audio/it/Words 0001-0050.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [di](https://en.wiktionary.org/wiki/di#Italian) | used to indicate possession, after the thing owned and before the owner; of; ’s | /di/ · prep |
| [e](https://en.wiktionary.org/wiki/e#Italian) | and | /ˈe/ · conj |
| [che](https://en.wiktionary.org/wiki/che#Italian) | that; which; what (depending on construction) | /ˈke/ · pron |
| [la](https://en.wiktionary.org/wiki/la#Italian) | the (feminine singular); her/it as a pronoun | /la/ · article |
| [in](https://en.wiktionary.org/wiki/in#Italian) | in | /in/ · prep |
| [non](https://en.wiktionary.org/wiki/non#Italian) | not | /non/ · adv |
| [per](https://en.wiktionary.org/wiki/per#Italian) | for | /per/ · prep |
| [le](https://en.wiktionary.org/wiki/le#Italian) | the (feminine plural); them/to her as a pronoun | /le/ · article |
| [si](https://en.wiktionary.org/wiki/si#Italian) | oneself, himself, herself, itself, themselves | /si/ · pron |
| [con](https://en.wiktionary.org/wiki/con#Italian) | with, together | /kon/ · prep |
| [da](https://en.wiktionary.org/wiki/da#Italian) | from (all senses) | /da/ · prep |
| [ma](https://en.wiktionary.org/wiki/ma#Italian) | but, however | /ˈma/ · conj |
| [al](https://en.wiktionary.org/wiki/al#Italian) | with (an ingredient) | /al/ · prep |
| [ha](https://en.wiktionary.org/wiki/ha#Italian) | ah! (usually ironic or sarcastic) | /a/ · intj |
| [come](https://en.wiktionary.org/wiki/come#Italian) | how | /ˈko.me/ · adv |
| [più](https://en.wiktionary.org/wiki/pi%C3%B9#Italian) | anymore, any longer | /ˈpju/ · adv |
| [se](https://en.wiktionary.org/wiki/se#Italian) | if | /se/ · conj |
| [mi](https://en.wiktionary.org/wiki/mi#Italian) | Used as ethical dative. | /mi/ · pron |
| [alla](https://en.wiktionary.org/wiki/alla#Italian) | -style, à la | /ˈal.la/ · prep |
| [lo](https://en.wiktionary.org/wiki/lo#Italian) | the (masculine singular before certain sounds); him/it | /lo/ · article |
| [gli](https://en.wiktionary.org/wiki/gli#Italian) | him, to him; it; to it | /ʎi/ · pron |
| [o](https://en.wiktionary.org/wiki/o#Italian) | or | /ˈɔ/ · conj |
| [questo](https://en.wiktionary.org/wiki/questo#Italian) | this, these | /ˈkwes.to/ · det |
| [ci](https://en.wiktionary.org/wiki/ci#Italian) | us; there; a particle in several constructions | /ˈt͡ʃi/ · pron |
| [su](https://en.wiktionary.org/wiki/su#Italian) | up, upstairs | /ˈsu/ · adv |
| [solo](https://en.wiktionary.org/wiki/solo#Italian) | alone, by oneself, unattended, unaccompanied, lonely, lone, lonesome | /ˈso.lo/ · adj |
| [essere](https://en.wiktionary.org/wiki/essere#Italian) | Used as a copula. to be | /ˈɛs.se.re/ · verb |
| [io](https://en.wiktionary.org/wiki/io#Italian) | I (the first-person singular nominative pronoun) | /ˈi.o/ · pron |
| [ti](https://en.wiktionary.org/wiki/ti#Italian) | you (singular object); to you | /ˈti/ · pron |
| [era](https://en.wiktionary.org/wiki/era#Italian) | age, epoch, period | /ˈɛ.ra/ · noun |
| [quando](https://en.wiktionary.org/wiki/quando#Italian) | when | /ˈkwan.do/ · adv |
| [tutto](https://en.wiktionary.org/wiki/tutto#Italian) | all | /ˈtut.to/ · det |
| [tra](https://en.wiktionary.org/wiki/tra#Italian) | between | /tra/ · prep |
| [loro](https://en.wiktionary.org/wiki/loro#Italian) | they, them | /ˈlo.ro/ · pron |
| [perché](https://en.wiktionary.org/wiki/perch%C3%A9#Italian) | because, why | /perˈke/ · conj |
| [due](https://en.wiktionary.org/wiki/due#Italian) | two | /ˈdu.e/ · num |
| [sia](https://en.wiktionary.org/wiki/sia#Italian) | both ... and .. | /ˈsi.a/ · conj |
| [AI](https://en.wiktionary.org/wiki/AI#Italian) | AI |  · noun |
| [fare](https://en.wiktionary.org/wiki/fare#Italian) | to do | /ˈfa.re/ · verb |
| [uno](https://en.wiktionary.org/wiki/uno#Italian) | one | /ˈu.no/ · num |
| [ne](https://en.wiktionary.org/wiki/ne#Italian) | from there | /ne/ · adv |
| [poi](https://en.wiktionary.org/wiki/poi#Italian) | then | /ˈpɔj/ · adv |
| [quello](https://en.wiktionary.org/wiki/quello#Italian) | that, those | /ˈkwel.lo/ · det |
| [fa](https://en.wiktionary.org/wiki/fa#Italian) | ago (Note: like in English, fa follows the number.) |  · adv |
| [me](https://en.wiktionary.org/wiki/me#Italian) | me | /ˈme/ · pron |
| [chi](https://en.wiktionary.org/wiki/chi#Italian) | who, whom; whoever | /ki/ · pron |
| [ancora](https://en.wiktionary.org/wiki/ancora#Italian) | still | /anˈko.ra/ · adv |
| [molto](https://en.wiktionary.org/wiki/molto#Italian) | much, very much, a lot (with verbs) | /ˈmol.to/ · adv |
| [senza](https://en.wiktionary.org/wiki/senza#Italian) | without | /ˈsɛn.t͡sa/ · conj |
| [mai](https://en.wiktionary.org/wiki/mai#Italian) | never | /ˈma.i/ · adv |

</details>

<details><summary>Words 51–100</summary>

![[Resources/Audio/it/Words 0051-0100.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [ogni](https://en.wiktionary.org/wiki/ogni#Italian) | each, every | /ˈoɲ.ɲi/ · det |
| [ora](https://en.wiktionary.org/wiki/ora#Italian) | hour (a unit of time of one twenty-fourth of a day (sixty minutes)) | /ˈo.ra/ · noun |
| [sulla](https://en.wiktionary.org/wiki/sulla#Italian) | plant of the genus Sulla, particularly Sulla coronaria. |  · noun |
| [tempo](https://en.wiktionary.org/wiki/tempo#Italian) | time | /ˈtɛm.po/ · noun |
| [dove](https://en.wiktionary.org/wiki/dove#Italian) | where | /ˈdo.ve/ · conj |
| [vita](https://en.wiktionary.org/wiki/vita#Italian) | life | /ˈvi.ta/ · noun |
| [sei](https://en.wiktionary.org/wiki/sei#Italian) | six | /ˈsɛj/ · num |
| [secondo](https://en.wiktionary.org/wiki/secondo#Italian) | second | /seˈkon.do/ · adj |
| [c'era](https://en.wiktionary.org/wiki/c%27era#Italian) | Used other than figuratively or idiomatically: see c', era. | /ˈt͡ʃ‿ɛ.ra/ · verb |
| [bene](https://en.wiktionary.org/wiki/bene#Italian) | upper-class, posh, high | /ˈbɛ.ne/ · adj |
| [grazie](https://en.wiktionary.org/wiki/grazie#Italian) | thank you, thanks! | /ˈɡrat.t͡sje/ · intj |
| [dai](https://en.wiktionary.org/wiki/dai#Italian) | an expression of encouragement; come on! |  · intj |
| [noi](https://en.wiktionary.org/wiki/noi#Italian) | we; us | /ˈnoj/ · pron |
| [vi](https://en.wiktionary.org/wiki/vi#Italian) | second-person personal plural object pronoun: you, to you | /ˈvi/ · pron |
| [casa](https://en.wiktionary.org/wiki/casa#Italian) | house | /ˈka.sa/ · noun |
| [qui](https://en.wiktionary.org/wiki/qui#Italian) | here | /ˈkwi/ · adv |
| [te](https://en.wiktionary.org/wiki/te#Italian) | you, thee | /te/ · pron |
| [volta](https://en.wiktionary.org/wiki/volta#Italian) | time, instance, occasion | /ˈvɔl.ta/ · noun |
| [dire](https://en.wiktionary.org/wiki/dire#Italian) | to utter (produce (speech or other sounds) with one's voice) | /ˈdi.re/ · verb |
| [tu](https://en.wiktionary.org/wiki/tu#Italian) | you (singular); thou | /ˈtu/ · pron |
| [giorno](https://en.wiktionary.org/wiki/giorno#Italian) | day | /ˈd͡ʒor.no/ · noun |
| [lui](https://en.wiktionary.org/wiki/lui#Italian) | he | /ˈluj/ · pron |
| [via](https://en.wiktionary.org/wiki/via#Italian) | street, path | /ˈvi.a/ · noun |
| [grande](https://en.wiktionary.org/wiki/grande#Italian) | really (intensifier) | /ˈɡran.de/ · adv |
| [de](https://en.wiktionary.org/wiki/de#Italian) | Marche, Milan, Rome, and Venice form of di | /de/ · prep |
| [li](https://en.wiktionary.org/wiki/li#Italian) | them (masculine) | /li/ · pron |
| [oggi](https://en.wiktionary.org/wiki/oggi#Italian) | today | /ˈɔd.d͡ʒi/ · adv |
| [tanto](https://en.wiktionary.org/wiki/tanto#Italian) | so much; so many | /ˈtan.to/ · det |
| [città](https://en.wiktionary.org/wiki/citt%C3%A0#Italian) | town, city | /t͡ʃitˈta/ · noun |
| [nuovo](https://en.wiktionary.org/wiki/nuovo#Italian) | new | /ˈnwɔ.vo/ · adj |
| [fine](https://en.wiktionary.org/wiki/fine#Italian) | thin | /ˈfi.ne/ · adj |
| [anno](https://en.wiktionary.org/wiki/anno#Italian) | year (all senses) | /ˈan.no/ · noun |
| [dalle](https://en.wiktionary.org/wiki/dalle#Italian) | compound of da', the second-person singular imperative form of dare, with le | /ˈdal.le/ · verb |
| [storia](https://en.wiktionary.org/wiki/storia#Italian) | history | /ˈstɔ.rja/ · noun |
| [tre](https://en.wiktionary.org/wiki/tre#Italian) | three | /ˈtre/ · num |
| [tuo](https://en.wiktionary.org/wiki/tuo#Italian) | your (informal) | /ˈtu.o/ · det |
| [avere](https://en.wiktionary.org/wiki/avere#Italian) | to have | /aˈve.re/ · verb |
| [però](https://en.wiktionary.org/wiki/per%C3%B2#Italian) | yet, but, however, nevertheless | /peˈrɔ/ · conj |
| [vedere](https://en.wiktionary.org/wiki/vedere#Italian) | to see | /veˈde.re/ · verb |
| [vero](https://en.wiktionary.org/wiki/vero#Italian) | true | /ˈve.ro/ · adj |
| [niente](https://en.wiktionary.org/wiki/niente#Italian) | nothing | /ˈnjɛn.te/ · pron |
| [posto](https://en.wiktionary.org/wiki/posto#Italian) | place, spot | /ˈpos.to/ · noun |
| [nome](https://en.wiktionary.org/wiki/nome#Italian) | name | /ˈno.me/ · noun |
| [per niente](https://en.wiktionary.org/wiki/per%20niente#Italian) | by no means, in no way, not in the least, the least bit | /per ˈnjɛn.te/ · adv |
| [voi](https://en.wiktionary.org/wiki/voi#Italian) | you (second person plural) | /ˈvo.i/ · pron |
| [andare](https://en.wiktionary.org/wiki/andare#Italian) | to go | /anˈda.re/ · verb |
| [insieme](https://en.wiktionary.org/wiki/insieme#Italian) | together | /inˈsjɛ.me/ · adv |
| [punto](https://en.wiktionary.org/wiki/punto#Italian) | point (all senses), jot, iota | /ˈpun.to/ · noun |
| [davvero](https://en.wiktionary.org/wiki/davvero#Italian) | really, in fact | /davˈve.ro/ · adv |
| [nessuno](https://en.wiktionary.org/wiki/nessuno#Italian) | no, any | /nesˈsu.no/ · det |

</details>

<details><summary>Words 101–150</summary>

![[Resources/Audio/it/Words 0101-0150.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [lei](https://en.wiktionary.org/wiki/lei#Italian) | she | /ˈlɛj/ · pron |
| [video](https://en.wiktionary.org/wiki/video#Italian) | video (all senses) | /ˈvi.de.o/ · noun |
| [male](https://en.wiktionary.org/wiki/male#Italian) | badly, wrongly | /ˈma.le/ · adv |
| [numero](https://en.wiktionary.org/wiki/numero#Italian) | number | /ˈnu.me.ro/ · noun |
| [sì](https://en.wiktionary.org/wiki/s%C3%AC#Italian) | yes | /ˈsi/ · particle |
| [persona](https://en.wiktionary.org/wiki/persona#Italian) | person, pl people, persons | /perˈso.na/ · noun |
| [uomo](https://en.wiktionary.org/wiki/uomo#Italian) | person, man (human being) | /ˈwɔ.mo/ · noun |
| [circa](https://en.wiktionary.org/wiki/circa#Italian) | regarding, concerning | /ˈt͡ʃir.ka/ · prep |
| [italiano](https://en.wiktionary.org/wiki/italiano#Italian) | Italian (of, from or relating to Italy) | /i.taˈlja.no/ · adj |
| [adesso](https://en.wiktionary.org/wiki/adesso#Italian) | now | /aˈdɛs.so/ · adv |
| [guerra](https://en.wiktionary.org/wiki/guerra#Italian) | war, warfare | /ˈɡwɛr.ra/ · noun |
| [base](https://en.wiktionary.org/wiki/base#Italian) | base, alkaline | /ˈba.ze/ · noun |
| [film](https://en.wiktionary.org/wiki/film#Italian) | film, movie | /ˈfilm/ · noun |
| [pure](https://en.wiktionary.org/wiki/pure#Italian) | too, also, as well | /ˈpu.re/ · adv |
| [spesso](https://en.wiktionary.org/wiki/spesso#Italian) | thick | /ˈspes.so/ · adj |
| [subito](https://en.wiktionary.org/wiki/subito#Italian) | at once, immediately, as soon as possible, shortly | /ˈsu.bi.to/ · adv |
| [dio](https://en.wiktionary.org/wiki/dio#Italian) | god, deity | /ˈdi.o/ · noun |
| [fra](https://en.wiktionary.org/wiki/fra#Italian) | between | /fra/ · prep |
| [parlare](https://en.wiktionary.org/wiki/parlare#Italian) | to talk, to speak | /parˈla.re/ · verb |
| [ce](https://en.wiktionary.org/wiki/ce#Italian) | reinforcing particle, "do" | /t͡ʃe/ · adv |
| [idea](https://en.wiktionary.org/wiki/idea#Italian) | idea | /iˈdɛ.a/ · noun |
| [mano](https://en.wiktionary.org/wiki/mano#Italian) | hand | /ˈma.no/ · noun |
| [causa](https://en.wiktionary.org/wiki/causa#Italian) | cause | /ˈkaw.sa/ · noun |
| [presidente](https://en.wiktionary.org/wiki/presidente#Italian) | president (head of state of a republic) | /pre.siˈdɛn.te/ · noun |
| [basta](https://en.wiktionary.org/wiki/basta#Italian) | enough! | /ˈbas.ta/ · intj |
| [diritto](https://en.wiktionary.org/wiki/diritto#Italian) | straight, direct | /diˈrit.to/ · adj |
| [parole](https://en.wiktionary.org/wiki/parole#Italian) | lyrics, words | /paˈrɔ.le/ · noun |
| [terra](https://en.wiktionary.org/wiki/terra#Italian) | ground | /ˈtɛr.ra/ · noun |
| [che sarà, sarà](https://en.wiktionary.org/wiki/che%20sar%C3%A0%2C%20sar%C3%A0#Italian) | che sara sara; whatever happens, happens | /ˌke‿s.saˌra‿s.saˈra/ · phrase |
| [padre](https://en.wiktionary.org/wiki/padre#Italian) | father | /ˈpa.dre/ · noun |
| [prima donna](https://en.wiktionary.org/wiki/prima%20donna#Italian) | prima donna |  · noun |
| [dare](https://en.wiktionary.org/wiki/dare#Italian) | to give (to transfer the possession/holding of something to someone else) | /ˈda.re/ · verb |
| [piano](https://en.wiktionary.org/wiki/piano#Italian) | plane | /ˈpja.no/ · adj |
| [porta](https://en.wiktionary.org/wiki/porta#Italian) | gate | /ˈpɔr.ta/ · noun |
| [letto](https://en.wiktionary.org/wiki/letto#Italian) | bed | /ˈlɛt.to/ · noun |
| [pubblico](https://en.wiktionary.org/wiki/pubblico#Italian) | public | /ˈpub.bli.ko/ · adj |
| [strada](https://en.wiktionary.org/wiki/strada#Italian) | road, way, street | /ˈstra.da/ · noun |
| [mezzo](https://en.wiktionary.org/wiki/mezzo#Italian) | half, middle | /ˈmɛd.d͡zo/ · noun |
| [tale](https://en.wiktionary.org/wiki/tale#Italian) | such | /ˈta.le/ · det |
| [marzo](https://en.wiktionary.org/wiki/marzo#Italian) | March (the month) | /ˈmar.t͡so/ · noun |
| [notte](https://en.wiktionary.org/wiki/notte#Italian) | night | /ˈnɔt.te/ · noun |
| [quattro](https://en.wiktionary.org/wiki/quattro#Italian) | four | /ˈkwat.tro/ · num |
| [san](https://en.wiktionary.org/wiki/san#Italian) | san (Greek letter) | /ˈsan/ · noun |
| [libro](https://en.wiktionary.org/wiki/libro#Italian) | book | /ˈli.bro/ · noun |
| [sapere](https://en.wiktionary.org/wiki/sapere#Italian) | to know (information) | /saˈpe.re/ · verb |
| [dagli](https://en.wiktionary.org/wiki/dagli#Italian) | compound of da', the second-person singular imperative form of dare, with gli | /ˈdaʎ.ʎi/ · verb |
| [faccia](https://en.wiktionary.org/wiki/faccia#Italian) | face (of a person or an animal) | /ˈfat.t͡ʃa/ · noun |
| [figlio](https://en.wiktionary.org/wiki/figlio#Italian) | son | /ˈfiʎ.ʎo/ · noun |
| [prendere](https://en.wiktionary.org/wiki/prendere#Italian) | to take, hold, pick up, get | /ˈprɛn.de.re/ · verb |
| [progetto](https://en.wiktionary.org/wiki/progetto#Italian) | plan, project, design, scheme, layout | /proˈd͡ʒɛt.to/ · noun |

</details>

<details><summary>Words 151–200</summary>

![[Resources/Audio/it/Words 0151-0200.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [testa](https://en.wiktionary.org/wiki/testa#Italian) | head | /ˈtɛs.ta/ · noun |
| [accordo](https://en.wiktionary.org/wiki/accordo#Italian) | accord, agreement, bond | /akˈkɔr.do/ · noun |
| [capo](https://en.wiktionary.org/wiki/capo#Italian) | boss, chief, leader | /ˈka.po/ · noun |
| [giusto](https://en.wiktionary.org/wiki/giusto#Italian) | just, right | /ˈd͡ʒus.to/ · adj |
| [madre](https://en.wiktionary.org/wiki/madre#Italian) | mother | /ˈma.dre/ · noun |
| [studio](https://en.wiktionary.org/wiki/studio#Italian) | study | /ˈstu.djo/ · noun |
| [ciao](https://en.wiktionary.org/wiki/ciao#Italian) | hello! | /ˈt͡ʃa.o/ · intj |
| [voce](https://en.wiktionary.org/wiki/voce#Italian) | voice | /ˈvo.t͡ʃe/ · noun |
| [forte](https://en.wiktionary.org/wiki/forte#Italian) | fort, fortress | /ˈfɔr.te/ · noun |
| [maggio](https://en.wiktionary.org/wiki/maggio#Italian) | May (fifth month of the Gregorian calendar) | /ˈmad.d͡ʒo/ · noun |
| [mese](https://en.wiktionary.org/wiki/mese#Italian) | month | /ˈme.ze/ · noun |
| [TV](https://en.wiktionary.org/wiki/TV#Italian) | television | /tivˈvu/ · noun |
| [nemmeno](https://en.wiktionary.org/wiki/nemmeno#Italian) | not even | /nemˈme.no/ · adv |
| [passato](https://en.wiktionary.org/wiki/passato#Italian) | past | /pasˈsa.to/ · adj |
| [euro](https://en.wiktionary.org/wiki/euro#Italian) | euro (currency) | /ˈɛ.u.ro/ · noun |
| [acqua](https://en.wiktionary.org/wiki/acqua#Italian) | water | /ˈak.kwa/ · noun |
| [aprile](https://en.wiktionary.org/wiki/aprile#Italian) | April | /aˈpri.le/ · noun |
| [cuore](https://en.wiktionary.org/wiki/cuore#Italian) | muscular organ that pumps blood | /ˈkwɔ.re/ · noun |
| [bello](https://en.wiktionary.org/wiki/bello#Italian) | nice, fair, fine, pleasant; beautiful (of the weather, etc.) | /ˈbɛl.lo/ · adj |
| [lì](https://en.wiktionary.org/wiki/l%C3%AC#Italian) | there, in that place | /ˈli/ · adv |
| [media](https://en.wiktionary.org/wiki/media#Italian) | average, mean |  · noun |
| [cinque](https://en.wiktionary.org/wiki/cinque#Italian) | five | /ˈt͡ʃin.kwe/ · num |
| [luglio](https://en.wiktionary.org/wiki/luglio#Italian) | July | /ˈluʎ.ʎo/ · noun |
| [musica](https://en.wiktionary.org/wiki/musica#Italian) | music | /ˈmu.zi.ka/ · noun |
| [paura](https://en.wiktionary.org/wiki/paura#Italian) | fear | /paˈu.ra/ · noun |
| [stare](https://en.wiktionary.org/wiki/stare#Italian) | to stay, remain | /ˈsta.re/ · verb |
| [la maggiore](https://en.wiktionary.org/wiki/la%20maggiore#Italian) | A major |  · noun |
| [nord](https://en.wiktionary.org/wiki/nord#Italian) | north | /ˈnɔrd/ · noun |
| [post](https://en.wiktionary.org/wiki/post#Italian) | post (message in a forum) | /ˈpɔst/ · noun |
| [re](https://en.wiktionary.org/wiki/re#Italian) | king (male monarch) | /ˈre/ · noun |
| [vicino](https://en.wiktionary.org/wiki/vicino#Italian) | near, close | /viˈt͡ʃi.no/ · adj |
| [abbastanza](https://en.wiktionary.org/wiki/abbastanza#Italian) | enough, sufficiently | /ab.basˈtan.t͡sa/ · adv |
| [data](https://en.wiktionary.org/wiki/data#Italian) | date (“calendar date”) | /ˈda.ta/ · noun |
| [ero](https://en.wiktionary.org/wiki/ero#Italian) | heroin | /ˈɛ.ro/ · noun |
| [lingua](https://en.wiktionary.org/wiki/lingua#Italian) | tongue | /ˈlin.ɡwa/ · noun |
| [piccolo](https://en.wiktionary.org/wiki/piccolo#Italian) | small | /ˈpik.ko.lo/ · adj |
| [potere](https://en.wiktionary.org/wiki/potere#Italian) | can, could; to be able to | /poˈte.re/ · verb |
| [si maggiore](https://en.wiktionary.org/wiki/si%20maggiore#Italian) | B major |  · noun |
| [zona](https://en.wiktionary.org/wiki/zona#Italian) | a zone, area or district | /ˈd͡zɔ.na/ · noun |
| [febbraio](https://en.wiktionary.org/wiki/febbraio#Italian) | February | /febˈbra.jo/ · noun |
| [futuro](https://en.wiktionary.org/wiki/futuro#Italian) | future | /fuˈtu.ro/ · adj |
| [alto](https://en.wiktionary.org/wiki/alto#Italian) | high, tall | /ˈal.to/ · adj |
| [davanti](https://en.wiktionary.org/wiki/davanti#Italian) | at the front; in front | /daˈvan.ti/ · adv |
| [novembre](https://en.wiktionary.org/wiki/novembre#Italian) | November | /noˈvɛm.bre/ · noun |
| [possiamo](https://en.wiktionary.org/wiki/possiamo#Italian) | first-person plural present indicative/present subjunctive of potere | /posˈsja.mo/ · verb |
| [scelta](https://en.wiktionary.org/wiki/scelta#Italian) | choice | /ˈʃel.ta/ · noun |
| [agosto](https://en.wiktionary.org/wiki/agosto#Italian) | August | /aˈɡos.to/ · noun |
| [fronte](https://en.wiktionary.org/wiki/fronte#Italian) | forehead, brow | /ˈfron.te/ · noun |
| [luce](https://en.wiktionary.org/wiki/luce#Italian) | light (visible electromagnetic wave; electrical device providing light) | /ˈlu.t͡ʃe/ · noun |
| [mare](https://en.wiktionary.org/wiki/mare#Italian) | sea | /ˈma.re/ · noun |

</details>

<details><summary>Words 201–250</summary>

![[Resources/Audio/it/Words 0201-0250.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [opera](https://en.wiktionary.org/wiki/opera#Italian) | work | /ˈɔ.pe.ra/ · noun |
| [ah](https://en.wiktionary.org/wiki/ah#Italian) | ah! (usually ironic or sarcastic) | /ˈa/ · intj |
| [gennaio](https://en.wiktionary.org/wiki/gennaio#Italian) | January | /d͡ʒenˈna.jo/ · noun |
| [né](https://en.wiktionary.org/wiki/n%C3%A9#Italian) | nor | /ne/ · conj |
| [online](https://en.wiktionary.org/wiki/online#Italian) | online |  · adj |
| [OK](https://en.wiktionary.org/wiki/OK#Italian) | OK | /oˈkɛ.i/ · adj |
| [in linea](https://en.wiktionary.org/wiki/in%20linea#Italian) | online |  · adj |
| [mente](https://en.wiktionary.org/wiki/mente#Italian) | mind | /ˈmen.te/ · noun |
| [specie](https://en.wiktionary.org/wiki/specie#Italian) | especially, particularly | /ˈspɛ.t͡ʃe/ · adv |
| [facile](https://en.wiktionary.org/wiki/facile#Italian) | easy | /ˈfa.t͡ʃi.le/ · adj |
| [leggere](https://en.wiktionary.org/wiki/leggere#Italian) | to read | /ˈlɛd.d͡ʒe.re/ · verb |
| [massimo](https://en.wiktionary.org/wiki/massimo#Italian) | maximum | /ˈmas.si.mo/ · adj |
| [presto](https://en.wiktionary.org/wiki/presto#Italian) | ready | /ˈprɛs.to/ · adj |
| [spazio](https://en.wiktionary.org/wiki/spazio#Italian) | space | /ˈspat.t͡sjo/ · noun |
| [vera](https://en.wiktionary.org/wiki/vera#Italian) | wedding ring, wedding band | /ˈve.ra/ · noun |
| [bel](https://en.wiktionary.org/wiki/bel#Italian) | preconsonantal masculine singular form of bello | /bɛl/ · adj |
| [mamma](https://en.wiktionary.org/wiki/mamma#Italian) | mom/mum | /ˈmam.ma/ · noun |
| [moglie](https://en.wiktionary.org/wiki/moglie#Italian) | wife | /ˈmoʎ.ʎe/ · noun |
| [pace](https://en.wiktionary.org/wiki/pace#Italian) | peace | /ˈpa.t͡ʃe/ · noun |
| [papa](https://en.wiktionary.org/wiki/papa#Italian) | pope | /ˈpa.pa/ · noun |
| [breve](https://en.wiktionary.org/wiki/breve#Italian) | brief, short | /ˈbrɛ.ve/ · adj |
| [calcio](https://en.wiktionary.org/wiki/calcio#Italian) | a kick (with the foot) | /ˈkal.t͡ʃo/ · noun |
| [pagina](https://en.wiktionary.org/wiki/pagina#Italian) | page (of a book, etc.) | /ˈpa.d͡ʒi.na/ · noun |
| [sentire](https://en.wiktionary.org/wiki/sentire#Italian) | to feel | /senˈti.re/ · verb |
| [sole](https://en.wiktionary.org/wiki/sole#Italian) | sun | /ˈso.le/ · noun |
| [web](https://en.wiktionary.org/wiki/web#Italian) | web (Internet) | /ˈwɛb/ · noun |
| [movimento](https://en.wiktionary.org/wiki/movimento#Italian) | movement | /mo.viˈmen.to/ · noun |
| [perdere](https://en.wiktionary.org/wiki/perdere#Italian) | to lose | /ˈpɛr.de.re/ · verb |
| [età](https://en.wiktionary.org/wiki/et%C3%A0#Italian) | age (number of years in someone's life) | /eˈta/ · noun |
| [passare](https://en.wiktionary.org/wiki/passare#Italian) | to pass (all senses) | /pasˈsa.re/ · verb |
| [qua](https://en.wiktionary.org/wiki/qua#Italian) | here | /ˈkwa/ · adv |
| [camera](https://en.wiktionary.org/wiki/camera#Italian) | room; chamber (all senses) | /ˈka.me.ra/ · noun |
| [destra](https://en.wiktionary.org/wiki/destra#Italian) | right (hand, direction) | /ˈdɛs.tra/ · noun |
| [locale](https://en.wiktionary.org/wiki/locale#Italian) | local | /loˈka.le/ · adj |
| [portato](https://en.wiktionary.org/wiki/portato#Italian) | second-hand, used |  · adj |
| [terzo](https://en.wiktionary.org/wiki/terzo#Italian) | third | /ˈtɛr.t͡so/ · adj |
| [bambino](https://en.wiktionary.org/wiki/bambino#Italian) | child, baby, toddler, tot (male or of unspecified gender) | /bamˈbi.no/ · noun |
| [dieci](https://en.wiktionary.org/wiki/dieci#Italian) | ten | /ˈdjɛ.t͡ʃi/ · num |
| [diventare](https://en.wiktionary.org/wiki/diventare#Italian) | to become (rich, dry, a doctor, etc.), to go (crazy, etc.), to turn (red, blue, etc.) | /di.venˈta.re/ · verb |
| [fuoco](https://en.wiktionary.org/wiki/fuoco#Italian) | fire | /ˈfwɔ.ko/ · noun |
| [natura](https://en.wiktionary.org/wiki/natura#Italian) | nature | /naˈtu.ra/ · noun |
| [partire](https://en.wiktionary.org/wiki/partire#Italian) | to depart; to leave; to set forth | /parˈti.re/ · verb |
| [portare](https://en.wiktionary.org/wiki/portare#Italian) | to bring, fetch, take, carry | /porˈta.re/ · verb |
| [arrivare](https://en.wiktionary.org/wiki/arrivare#Italian) | to arrive, to come, to reach | /ar.riˈva.re/ · verb |
| [carta](https://en.wiktionary.org/wiki/carta#Italian) | paper (the material) | /ˈkar.ta/ · noun |
| [danno](https://en.wiktionary.org/wiki/danno#Italian) | damage, harm, injury | /ˈdan.no/ · noun |
| [francese](https://en.wiktionary.org/wiki/francese#Italian) | French (of, from or relating to France) | /franˈt͡ʃe.ze/ · adj |
| [libero](https://en.wiktionary.org/wiki/libero#Italian) | free (not imprisoned or enslaved) | /ˈli.be.ro/ · adj |
| [scrivere](https://en.wiktionary.org/wiki/scrivere#Italian) | to write | /ˈskri.ve.re/ · verb |
| [tornare](https://en.wiktionary.org/wiki/tornare#Italian) | to return, to come back | /torˈna.re/ · verb |

</details>

<details><summary>Words 251–300</summary>

![[Resources/Audio/it/Words 0251-0300.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [simile](https://en.wiktionary.org/wiki/simile#Italian) | similar | /ˈsi.mi.le/ · adj |
| [figlia](https://en.wiktionary.org/wiki/figlia#Italian) | daughter | /ˈfiʎ.ʎa/ · noun |
| [finale](https://en.wiktionary.org/wiki/finale#Italian) | final, ending | /fiˈna.le/ · adj |
| [sangue](https://en.wiktionary.org/wiki/sangue#Italian) | blood (vital liquid) | /ˈsan.ɡwe/ · noun |
| [tema](https://en.wiktionary.org/wiki/tema#Italian) | theme, subject | /ˈtɛ.ma/ · noun |
| [basso](https://en.wiktionary.org/wiki/basso#Italian) | low | /ˈbas.so/ · adj |
| [costa](https://en.wiktionary.org/wiki/costa#Italian) | rib | /ˈkɔs.ta/ · noun |
| [dallo](https://en.wiktionary.org/wiki/dallo#Italian) | compound of da' lo; give it! | /ˈdal.lo/ · verb |
| [entrare](https://en.wiktionary.org/wiki/entrare#Italian) | to enter, to go in | /enˈtra.re/ · verb |
| [azione](https://en.wiktionary.org/wiki/azione#Italian) | action, deed | /atˈt͡sjo.ne/ · noun |
| [chiedere](https://en.wiktionary.org/wiki/chiedere#Italian) | to ask (for) | /ˈkjɛ.de.re/ · verb |
| [lista](https://en.wiktionary.org/wiki/lista#Italian) | list, pile | /ˈlis.ta/ · noun |
| [telefono](https://en.wiktionary.org/wiki/telefono#Italian) | telephone, phone | /teˈlɛ.fo.no/ · noun |
| [vale](https://en.wiktionary.org/wiki/vale#Italian) | farewell, final farewell to the dying or deceased |  · noun |
| [atto](https://en.wiktionary.org/wiki/atto#Italian) | act, deed | /ˈat.to/ · noun |
| [autore](https://en.wiktionary.org/wiki/autore#Italian) | author | /a.uˈto.re/ · noun |
| [colore](https://en.wiktionary.org/wiki/colore#Italian) | color/colour | /koˈlo.re/ · noun |
| [là](https://en.wiktionary.org/wiki/l%C3%A0#Italian) | there | /ˈla/ · adv |
| [porto](https://en.wiktionary.org/wiki/porto#Italian) | port, harbour/harbor | /ˈpɔr.to/ · noun |
| [aria](https://en.wiktionary.org/wiki/aria#Italian) | air | /ˈa.rja/ · noun |
| [guardare](https://en.wiktionary.org/wiki/guardare#Italian) | to look at, to watch, to glance or gaze at | /ɡwarˈda.re/ · verb |
| [oh](https://en.wiktionary.org/wiki/oh#Italian) | oh | /ˈo/ · intj |
| [lettera](https://en.wiktionary.org/wiki/lettera#Italian) | letter (symbol in an alphabet) | /ˈlet.te.ra/ · noun |
| [mangiare](https://en.wiktionary.org/wiki/mangiare#Italian) | to eat | /manˈd͡ʒa.re/ · verb |
| [venire](https://en.wiktionary.org/wiki/venire#Italian) | to come | /veˈni.re/ · verb |
| [cielo](https://en.wiktionary.org/wiki/cielo#Italian) | sky | /ˈt͡ʃɛ.lo/ · noun |
| [diverso](https://en.wiktionary.org/wiki/diverso#Italian) | different, diverse | /diˈvɛr.so/ · adj |
| [finito](https://en.wiktionary.org/wiki/finito#Italian) | finished | /fiˈni.to/ · adj |
| [modello](https://en.wiktionary.org/wiki/modello#Italian) | model | /moˈdɛl.lo/ · noun |
| [social](https://en.wiktionary.org/wiki/social#Italian) | social network |  · noun |
| [bianco](https://en.wiktionary.org/wiki/bianco#Italian) | white (bright and colourless/colorless) | /ˈbjan.ko/ · adj |
| [medico](https://en.wiktionary.org/wiki/medico#Italian) | medical | /ˈmɛ.di.ko/ · adj |
| [mille](https://en.wiktionary.org/wiki/mille#Italian) | thousand, one thousand | /ˈmil.le/ · num |
| [radio](https://en.wiktionary.org/wiki/radio#Italian) | radius | /ˈra.djo/ · noun |
| [morire](https://en.wiktionary.org/wiki/morire#Italian) | death | /moˈri.re/ · noun |
| [normale](https://en.wiktionary.org/wiki/normale#Italian) | normal | /norˈma.le/ · adj |
| [lasciare](https://en.wiktionary.org/wiki/lasciare#Italian) | to leave (to leave something behind) | /laʃˈʃa.re/ · verb |
| [sette](https://en.wiktionary.org/wiki/sette#Italian) | seven | /ˈsɛt.te/ · num |
| [bocca](https://en.wiktionary.org/wiki/bocca#Italian) | mouth (all senses) | /ˈbok.ka/ · noun |
| [giocare](https://en.wiktionary.org/wiki/giocare#Italian) | to play a game, for fun or as a pastime | /d͡ʒoˈka.re/ · verb |
| [memoria](https://en.wiktionary.org/wiki/memoria#Italian) | memory, recall (the ability of the brain to record information) | /meˈmɔ.rja/ · noun |
| [tenere](https://en.wiktionary.org/wiki/tenere#Italian) | to hold | /teˈne.re/ · verb |
| [vinto](https://en.wiktionary.org/wiki/vinto#Italian) | loser | /ˈvin.to/ · noun |
| [domenica](https://en.wiktionary.org/wiki/domenica#Italian) | Sunday | /doˈme.ni.ka/ · noun |
| [poiché](https://en.wiktionary.org/wiki/poich%C3%A9#Italian) | since, because, as | /ˌpɔjˈke/ · conj |
| [pro](https://en.wiktionary.org/wiki/pro#Italian) | pro (as in English “pros and cons”) | /ˈprɔ/ · noun |
| [sport](https://en.wiktionary.org/wiki/sport#Italian) | sport (activity that uses physical skills, often competitive) | /ˈspɔrt/ · noun |
| [egli](https://en.wiktionary.org/wiki/egli#Italian) | he | /ˈeʎ.ʎi/ · pron |
| [marito](https://en.wiktionary.org/wiki/marito#Italian) | husband | /maˈri.to/ · noun |
| [pagare](https://en.wiktionary.org/wiki/pagare#Italian) | to pay (money, a bill, the rent, etc.) | /paˈɡa.re/ · verb |

</details>

<details><summary>Words 301–350</summary>

![[Resources/Audio/it/Words 0301-0350.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [palazzo](https://en.wiktionary.org/wiki/palazzo#Italian) | a royal palace | /paˈlat.t͡so/ · noun |
| [area](https://en.wiktionary.org/wiki/area#Italian) | area, surface | /ˈa.re.a/ · noun |
| [cane](https://en.wiktionary.org/wiki/cane#Italian) | dog, male dog | /ˈka.ne/ · noun |
| [est](https://en.wiktionary.org/wiki/est#Italian) | east | /ˈɛst/ · noun |
| [peso](https://en.wiktionary.org/wiki/peso#Italian) | weight | /ˈpe.zo/ · noun |
| [festival](https://en.wiktionary.org/wiki/festival#Italian) | festival | /ˈfɛs.ti.val/ · noun |
| [massa](https://en.wiktionary.org/wiki/massa#Italian) | mass (all senses) | /ˈmas.sa/ · noun |
| [pezzo](https://en.wiktionary.org/wiki/pezzo#Italian) | piece, chunk | /ˈpɛt.t͡so/ · noun |
| [test](https://en.wiktionary.org/wiki/test#Italian) | test | /ˈtɛst/ · noun |
| [decisione](https://en.wiktionary.org/wiki/decisione#Italian) | decision | /de.t͡ʃiˈzjo.ne/ · noun |
| [dolore](https://en.wiktionary.org/wiki/dolore#Italian) | ache, pain | /doˈlo.re/ · noun |
| [link](https://en.wiktionary.org/wiki/link#Italian) | link (hyperlink) |  · noun |
| [amo](https://en.wiktionary.org/wiki/amo#Italian) | hook | /ˈa.mo/ · noun |
| [club](https://en.wiktionary.org/wiki/club#Italian) | club (an association of members joining together for some common purpose, especially sports or recreation) | /ˈklab/ · noun |
| [essere umano](https://en.wiktionary.org/wiki/essere%20umano#Italian) | human being, human |  · noun |
| [pronto](https://en.wiktionary.org/wiki/pronto#Italian) | ready, prepared | /ˈpron.to/ · adj |
| [sala](https://en.wiktionary.org/wiki/sala#Italian) | room | /ˈsa.la/ · noun |
| [santo](https://en.wiktionary.org/wiki/santo#Italian) | holy | /ˈsan.to/ · adj |
| [finire](https://en.wiktionary.org/wiki/finire#Italian) | to finish | /fiˈni.re/ · verb |
| [otto](https://en.wiktionary.org/wiki/otto#Italian) | eight | /ˈɔt.to/ · num |
| [prego](https://en.wiktionary.org/wiki/prego#Italian) | prayer | /ˈprɛ.ɡo/ · noun |
| [banca](https://en.wiktionary.org/wiki/banca#Italian) | bank (financial institution) | /ˈban.ka/ · noun |
| [do](https://en.wiktionary.org/wiki/do#Italian) | do (musical note) | /ˈdɔ/ · noun |
| [materia](https://en.wiktionary.org/wiki/materia#Italian) | matter, substance, material, stuff | /maˈtɛ.rja/ · noun |
| [onore](https://en.wiktionary.org/wiki/onore#Italian) | honour/honor (all senses) | /oˈno.re/ · noun |
| [passato prossimo](https://en.wiktionary.org/wiki/passato%20prossimo#Italian) | the present perfect tense, the past tense |  · noun |
| [sale](https://en.wiktionary.org/wiki/sale#Italian) | salt, sal | /ˈsa.le/ · noun |
| [bagno](https://en.wiktionary.org/wiki/bagno#Italian) | bath | /ˈbaɲ.ɲo/ · noun |
| [computer](https://en.wiktionary.org/wiki/computer#Italian) | computer (calculating device) | /komˈpju.ter/ · noun |
| [grave](https://en.wiktionary.org/wiki/grave#Italian) | grave, serious | /ˈɡra.ve/ · adj |
| [occhio](https://en.wiktionary.org/wiki/occhio#Italian) | eye | /ˈɔk.kjo/ · noun |
| [sabato](https://en.wiktionary.org/wiki/sabato#Italian) | Saturday | /ˈsa.ba.to/ · noun |
| [decreto](https://en.wiktionary.org/wiki/decreto#Italian) | decree | /deˈkre.to/ · noun |
| [fame](https://en.wiktionary.org/wiki/fame#Italian) | hunger | /ˈfa.me/ · noun |
| [pelle](https://en.wiktionary.org/wiki/pelle#Italian) | skin | /ˈpɛl.le/ · noun |
| [bar](https://en.wiktionary.org/wiki/bar#Italian) | bar (place serving drinks) | /ˈbar/ · noun |
| [blog](https://en.wiktionary.org/wiki/blog#Italian) | blog |  · noun |
| [estate](https://en.wiktionary.org/wiki/estate#Italian) | summer | /esˈta.te/ · noun |
| [coraggio](https://en.wiktionary.org/wiki/coraggio#Italian) | courage, bravery, valour/valor | /koˈrad.d͡ʒo/ · noun |
| [dolce](https://en.wiktionary.org/wiki/dolce#Italian) | sweet | /ˈdol.t͡ʃe/ · adj |
| [anima](https://en.wiktionary.org/wiki/anima#Italian) | soul | /ˈa.ni.ma/ · noun |
| [carne](https://en.wiktionary.org/wiki/carne#Italian) | meat, flesh | /ˈkar.ne/ · noun |
| [rosa](https://en.wiktionary.org/wiki/rosa#Italian) | rose (plant of the genus Rosa) | /ˈrɔ.za/ · noun |
| [strano](https://en.wiktionary.org/wiki/strano#Italian) | strange, odd, dodgy | /ˈstra.no/ · adj |
| [super](https://en.wiktionary.org/wiki/super#Italian) | super | /ˈsu.per/ · adj |
| [volo](https://en.wiktionary.org/wiki/volo#Italian) | flight (of a bird; trip in a plane) | /ˈvo.lo/ · noun |
| [bellezza](https://en.wiktionary.org/wiki/bellezza#Italian) | beauty | /belˈlet.t͡sa/ · noun |
| [bravo](https://en.wiktionary.org/wiki/bravo#Italian) | good, well-behaved | /ˈbra.vo/ · adj |
| [team](https://en.wiktionary.org/wiki/team#Italian) | team (group of people) | /ˈtim/ · noun |
| [vocabolario](https://en.wiktionary.org/wiki/vocabolario) | vocabulary; dictionary |  · noun |

</details>

<details><summary>Words 351–400</summary>

![[Resources/Audio/it/Words 0351-0400.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [vino](https://en.wiktionary.org/wiki/vino#Italian) | wine (an alcoholic beverage made by fermenting grape juice, with an ABV ranging from 5.5–16%) | /ˈvi.no/ · noun |
| [zero](https://en.wiktionary.org/wiki/zero#Italian) | zero | /ˈd͡zɛ.ro/ · num |
| [caro](https://en.wiktionary.org/wiki/caro#Italian) | dear (beloved, or in the salutation of a letter), sweetheart | /ˈka.ro/ · adj |
| [cena](https://en.wiktionary.org/wiki/cena#Italian) | dinner (evening meal) | /ˈt͡ʃe.na/ · noun |
| [chat](https://en.wiktionary.org/wiki/chat#Italian) | chat (informal conversation via computer) | /ˈt͡ʃat/ · noun |
| [fiume](https://en.wiktionary.org/wiki/fiume#Italian) | river | /ˈfju.me/ · noun |
| [chiuso](https://en.wiktionary.org/wiki/chiuso#Italian) | closed | /ˈkju.zo/ · adj |
| [studiare](https://en.wiktionary.org/wiki/studiare#Italian) | to study | /stuˈdja.re/ · verb |
| [album](https://en.wiktionary.org/wiki/album#Italian) | album (book, LP) | /ˈal.bum/ · noun |
| [bianca](https://en.wiktionary.org/wiki/bianca#Italian) | cue ball (more fully bilia bianca) | /ˈbjan.ka/ · noun |
| [leader](https://en.wiktionary.org/wiki/leader#Italian) | leading (“ranking first”) | /ˈli.der/ · adj |
| [ponte](https://en.wiktionary.org/wiki/ponte#Italian) | bridge (structure) | /ˈpon.te/ · noun |
| [dormire](https://en.wiktionary.org/wiki/dormire#Italian) | to sleep | /dorˈmi.re/ · verb |
| [gratis](https://en.wiktionary.org/wiki/gratis#Italian) | for free, gratis | /ˈɡra.tis/ · adv |
| [pranzo](https://en.wiktionary.org/wiki/pranzo#Italian) | lunch or dinner (depending on context) | /ˈpran.d͡zo/ · noun |
| [rivista](https://en.wiktionary.org/wiki/rivista#Italian) | magazine | /riˈvis.ta/ · noun |
| [standard](https://en.wiktionary.org/wiki/standard#Italian) | standard | /ˈstan.dard/ · adj |
| [nave](https://en.wiktionary.org/wiki/nave#Italian) | ship | /ˈna.ve/ · noun |
| [pagamento](https://en.wiktionary.org/wiki/pagamento#Italian) | payment | /pa.ɡaˈmen.to/ · noun |
| [star](https://en.wiktionary.org/wiki/star#Italian) | star (celebrity) | /ˈstar/ · noun |
| [triste](https://en.wiktionary.org/wiki/triste#Italian) | sad, unhappy, bleak | /ˈtris.te/ · adj |
| [villa](https://en.wiktionary.org/wiki/villa#Italian) | mansion | /ˈvil.la/ · noun |
| [volume](https://en.wiktionary.org/wiki/volume#Italian) | volume | /voˈlu.me/ · noun |
| [maestro](https://en.wiktionary.org/wiki/maestro#Italian) | teacher (primary school) | /maˈɛs.tro/ · noun |
| [tratto](https://en.wiktionary.org/wiki/tratto#Italian) | taken (from), based (on) | /ˈtrat.to/ · adj |
| [vincere](https://en.wiktionary.org/wiki/vincere#Italian) | to win | /ˈvin.t͡ʃe.re/ · verb |
| [debito](https://en.wiktionary.org/wiki/debito#Italian) | due, proper | /ˈde.bi.to/ · adj |
| [luna](https://en.wiktionary.org/wiki/luna#Italian) | a natural satellite | /ˈlu.na/ · noun |
| [principio](https://en.wiktionary.org/wiki/principio#Italian) | beginning, start, inception | /prinˈt͡ʃi.pjo/ · noun |
| [aereo](https://en.wiktionary.org/wiki/aereo#Italian) | aerial | /aˈɛ.re.o/ · adj |
| [gas](https://en.wiktionary.org/wiki/gas#Italian) | gas (state of matter, petroleum) | /ˈɡas/ · noun |
| [live](https://en.wiktionary.org/wiki/live#Italian) | performed or recorded live | /ˈlajv/ · adj |
| [quarto](https://en.wiktionary.org/wiki/quarto#Italian) | fourth | /ˈkwar.to/ · adj |
| [regime](https://en.wiktionary.org/wiki/regime#Italian) | regime, régime | /reˈd͡ʒi.me/ · noun |
| [regina](https://en.wiktionary.org/wiki/regina#Italian) | queen (monarch) | /reˈd͡ʒi.na/ · noun |
| [romano](https://en.wiktionary.org/wiki/romano#Italian) | Roman | /roˈma.no/ · adj |
| [top](https://en.wiktionary.org/wiki/top#Italian) | top | /ˈtɔp/ · noun |
| [account](https://en.wiktionary.org/wiki/account#Italian) | account |  · noun |
| [don](https://en.wiktionary.org/wiki/don#Italian) | Father (a title given to priests) | /ˈdɔn/ · noun |
| [primavera](https://en.wiktionary.org/wiki/primavera#Italian) | spring (season) | /pri.maˈvɛ.ra/ · noun |
| [scrittore](https://en.wiktionary.org/wiki/scrittore#Italian) | writer, author | /skritˈto.re/ · noun |
| [tedesco](https://en.wiktionary.org/wiki/tedesco#Italian) | German (of, from or relating to Germany) | /teˈdes.ko/ · adj |
| [famoso](https://en.wiktionary.org/wiki/famoso#Italian) | famous, well-known, renowned | /faˈmo.zo/ · adj |
| [latte](https://en.wiktionary.org/wiki/latte#Italian) | milk | /ˈlat.te/ · noun |
| [muro](https://en.wiktionary.org/wiki/muro#Italian) | wall | /ˈmu.ro/ · noun |
| [punta](https://en.wiktionary.org/wiki/punta#Italian) | point, head, tip, top, peak, end | /ˈpun.ta/ · noun |
| [vento](https://en.wiktionary.org/wiki/vento#Italian) | wind (movement of air caused by differences in atmospheric pressure) | /ˈvɛn.to/ · noun |
| [brutto](https://en.wiktionary.org/wiki/brutto#Italian) | ugly, bad, nasty | /ˈbrut.to/ · adj |
| [castello](https://en.wiktionary.org/wiki/castello#Italian) | castle | /kasˈtɛl.lo/ · noun |
| [fan](https://en.wiktionary.org/wiki/fan#Italian) | fan (admirer or follower) | /ˈfan/ · noun |

</details>

<details><summary>Words 401–450</summary>

![[Resources/Audio/it/Words 0401-0450.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [nonna](https://en.wiktionary.org/wiki/nonna#Italian) | grandmother, granny | /ˈnɔn.na/ · noun |
| [software](https://en.wiktionary.org/wiki/software#Italian) | software (encoded computer instructions) | /ˈsɔf.twɛr/ · noun |
| [tesoro](https://en.wiktionary.org/wiki/tesoro#Italian) | valuable things, treasure | /teˈzɔ.ro/ · noun |
| [decidere](https://en.wiktionary.org/wiki/decidere#Italian) | to decide (on), to fix, to arrange, to determine | /deˈt͡ʃi.de.re/ · verb |
| [file](https://en.wiktionary.org/wiki/file#Italian) | file | /ˈfa.il/ · noun |
| [mica](https://en.wiktionary.org/wiki/mica#Italian) | bit, morsel | /ˈmi.ka/ · noun |
| [biblioteca](https://en.wiktionary.org/wiki/biblioteca#Italian) | library | /bi.bljoˈtɛ.ka/ · noun |
| [chiudere](https://en.wiktionary.org/wiki/chiudere#Italian) | to close, to shut | /ˈkju.de.re/ · verb |
| [concerto](https://en.wiktionary.org/wiki/concerto#Italian) | concert, recital | /konˈt͡ʃɛr.to/ · noun |
| [droga](https://en.wiktionary.org/wiki/droga#Italian) | spice | /ˈdrɔ.ɡa/ · noun |
| [legno](https://en.wiktionary.org/wiki/legno#Italian) | wood (the material) | /ˈleɲ.ɲo/ · noun |
| [nove](https://en.wiktionary.org/wiki/nove#Italian) | nine | /ˈnɔ.ve/ · num |
| [olio](https://en.wiktionary.org/wiki/olio#Italian) | oil | /ˈɔ.ljo/ · noun |
| [onda](https://en.wiktionary.org/wiki/onda#Italian) | wave | /ˈon.da/ · noun |
| [pane](https://en.wiktionary.org/wiki/pane#Italian) | bread | /ˈpa.ne/ · noun |
| [spagnolo](https://en.wiktionary.org/wiki/spagnolo#Italian) | Spanish | /spaɲˈɲɔ.lo/ · adj |
| [ascoltare](https://en.wiktionary.org/wiki/ascoltare#Italian) | to listen to | /as.kolˈta.re/ · verb |
| [crescere](https://en.wiktionary.org/wiki/crescere#Italian) | to grow, to increase, to expand | /ˈkreʃ.ʃe.re/ · verb |
| [lunedì](https://en.wiktionary.org/wiki/luned%C3%AC#Italian) | Monday | /lu.neˈdi/ · noun |
| [pianeta](https://en.wiktionary.org/wiki/pianeta#Italian) | planet | /pjaˈne.ta/ · noun |
| [restare](https://en.wiktionary.org/wiki/restare#Italian) | to stay, to remain (in a location) | /resˈta.re/ · verb |
| [vite](https://en.wiktionary.org/wiki/vite#Italian) | screw | /ˈvi.te/ · noun |
| [influenza](https://en.wiktionary.org/wiki/influenza#Italian) | influence | /in.fluˈɛn.t͡sa/ · noun |
| [papà](https://en.wiktionary.org/wiki/pap%C3%A0#Italian) | dad, papa | /paˈpa/ · noun |
| [venti](https://en.wiktionary.org/wiki/venti#Italian) | twenty | /ˈven.ti/ · num |
| [braccio](https://en.wiktionary.org/wiki/braccio#Italian) | arm | /ˈbrat.t͡ʃo/ · noun |
| [disco](https://en.wiktionary.org/wiki/disco#Italian) | disc, disk | /ˈdis.ko/ · noun |
| [forum](https://en.wiktionary.org/wiki/forum#Italian) | forum (gathering for the purposes of discussion) | /ˈfɔ.rum/ · noun |
| [hotel](https://en.wiktionary.org/wiki/hotel#Italian) | hotel(s) | /oˈtɛl/ · noun |
| [mail](https://en.wiktionary.org/wiki/mail#Italian) | email | /ˈmɛjl/ · noun |
| [marina](https://en.wiktionary.org/wiki/marina#Italian) | coast | /maˈri.na/ · noun |
| [montagna](https://en.wiktionary.org/wiki/montagna#Italian) | mountain | /monˈtaɲ.ɲa/ · noun |
| [angelo](https://en.wiktionary.org/wiki/angelo#Italian) | angel | /ˈan.d͡ʒe.lo/ · noun |
| [bere](https://en.wiktionary.org/wiki/bere#Italian) | to drink | /ˈbe.re/ · verb |
| [confine](https://en.wiktionary.org/wiki/confine#Italian) | border, frontier | /konˈfi.ne/ · noun |
| [dovere](https://en.wiktionary.org/wiki/dovere#Italian) | to owe | /doˈve.re/ · verb |
| [fuga](https://en.wiktionary.org/wiki/fuga#Italian) | flight, escape | /ˈfu.ɡa/ · noun |
| [gentile](https://en.wiktionary.org/wiki/gentile#Italian) | kind, courteous | /d͡ʒenˈti.le/ · adj |
| [lago](https://en.wiktionary.org/wiki/lago#Italian) | lake | /ˈla.ɡo/ · noun |
| [povero](https://en.wiktionary.org/wiki/povero#Italian) | poor (with little or no possessions or money) | /ˈpɔ.ve.ro/ · adj |
| [sapete](https://en.wiktionary.org/wiki/sapete#Italian) | (you) know | /saˈpe.te/ · verb |
| [borsa](https://en.wiktionary.org/wiki/borsa#Italian) | bag, handbag, purse, briefcase | /ˈbor.sa/ · noun |
| [clima](https://en.wiktionary.org/wiki/clima#Italian) | climate | /ˈkli.ma/ · noun |
| [salvo](https://en.wiktionary.org/wiki/salvo#Italian) | safe, out of danger, saved, secure from | /ˈsal.vo/ · adj |
| [canto](https://en.wiktionary.org/wiki/canto#Italian) | song | /ˈkan.to/ · noun |
| [col legno](https://en.wiktionary.org/wiki/col%20legno#Italian) | col legno (the strings must be struck with the wood of the bow) | /kol ˈleɲ.ɲo/ · adv |
| [latino](https://en.wiktionary.org/wiki/latino#Italian) | Latin | /laˈti.no/ · adj |
| [piede](https://en.wiktionary.org/wiki/piede#Italian) | foot | /ˈpjɛ.de/ · noun |
| [pizza](https://en.wiktionary.org/wiki/pizza#Italian) | pizza (Italian dish) | /ˈpit.t͡sa/ · noun |
| [destino](https://en.wiktionary.org/wiki/destino#Italian) | destiny, fate | /desˈti.no/ · noun |

</details>

<details><summary>Words 451–500</summary>

![[Resources/Audio/it/Words 0451-0500.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [firma](https://en.wiktionary.org/wiki/firma#Italian) | signature (a person's name, written by that person, used as identification or to signify approval of accompanying material, such as a legal contract) | /ˈfir.ma/ · noun |
| [legato](https://en.wiktionary.org/wiki/legato#Italian) | awkward, stiff | /leˈɡa.to/ · adj |
| [ovvio](https://en.wiktionary.org/wiki/ovvio#Italian) | obvious | /ˈɔv.vjo/ · adj |
| [pesce](https://en.wiktionary.org/wiki/pesce#Italian) | fish | /ˈpeʃ.ʃe/ · noun |
| [romanzo](https://en.wiktionary.org/wiki/romanzo#Italian) | Romance | /roˈman.d͡zo/ · adj |
| [giocatore](https://en.wiktionary.org/wiki/giocatore#Italian) | player (one who amuses himself, plays games or a musical instrument) | /d͡ʒo.kaˈto.re/ · noun |
| [addio](https://en.wiktionary.org/wiki/addio#Italian) | goodbye, farewell | /adˈdi.o/ · intj |
| [arma](https://en.wiktionary.org/wiki/arma#Italian) | weapon, arms | /ˈar.ma/ · noun |
| [bambina](https://en.wiktionary.org/wiki/bambina#Italian) | babe | /bamˈbi.na/ · noun |
| [partner](https://en.wiktionary.org/wiki/partner#Italian) | partner (all senses) | /ˈpart.ner/ · noun |
| [pasta](https://en.wiktionary.org/wiki/pasta#Italian) | paste | /ˈpas.ta/ · noun |
| [fotografia](https://en.wiktionary.org/wiki/fotografia#Italian) | photography | /fo.to.ɡraˈfi.a/ · noun |
| [mobile](https://en.wiktionary.org/wiki/mobile#Italian) | movable, mobile | /ˈmɔ.bi.le/ · adj |
| [suono](https://en.wiktionary.org/wiki/suono#Italian) | sound (that is heard) | /ˈswɔ.no/ · noun |
| [vescovo](https://en.wiktionary.org/wiki/vescovo#Italian) | bishop (clergyman) | /ˈves.ko.vo/ · noun |
| [zio](https://en.wiktionary.org/wiki/zio#Italian) | uncle (male relative) | /ˈd͡zi.o/ · noun |
| [cadere](https://en.wiktionary.org/wiki/cadere#Italian) | to fall | /kaˈde.re/ · verb |
| [grammatica](https://en.wiktionary.org/wiki/grammatica) | grammar |  · noun |
| [quota](https://en.wiktionary.org/wiki/quota#Italian) | share, amount, part | /ˈkwɔ.ta/ · noun |
| [vice](https://en.wiktionary.org/wiki/vice#Italian) | deputy, substitute, vice | /ˈvi.t͡ʃe/ · noun |
| [weekend](https://en.wiktionary.org/wiki/weekend#Italian) | weekend | /wiˈkɛnd/ · noun |
| [pioggia](https://en.wiktionary.org/wiki/pioggia#Italian) | rain | /ˈpjɔd.d͡ʒa/ · noun |
| [razza](https://en.wiktionary.org/wiki/razza#Italian) | race, breed | /ˈrat.t͡sa/ · noun |
| [fascia](https://en.wiktionary.org/wiki/fascia#Italian) | strip, band | /ˈfaʃ.ʃa/ · noun |
| [record](https://en.wiktionary.org/wiki/record#Italian) | record (achievement; computer data element) | /ˈrɛ.kord/ · noun |
| [set](https://en.wiktionary.org/wiki/set#Italian) | set (group of things in maths, tennis, cinema, etc.) | /ˈsɛt/ · noun |
| [stella](https://en.wiktionary.org/wiki/stella#Italian) | star | /ˈstel.la/ · noun |
| [studente](https://en.wiktionary.org/wiki/studente#Italian) | student | /stuˈdɛn.te/ · noun |
| [big](https://en.wiktionary.org/wiki/big#Italian) | star (entertainment) | /ˈbiɡ/ · noun |
| [city](https://en.wiktionary.org/wiki/city#Italian) | city (financial district of a city) | /ˈsi.ti/ · noun |
| [inverno](https://en.wiktionary.org/wiki/inverno#Italian) | winter | /inˈvɛr.no/ · noun |
| [milione](https://en.wiktionary.org/wiki/milione#Italian) | million | /miˈljo.ne/ · num |
| [mosca](https://en.wiktionary.org/wiki/mosca#Italian) | fly (insect) | /ˈmos.ka/ · noun |
| [propaganda](https://en.wiktionary.org/wiki/propaganda#Italian) | propaganda | /pro.paˈɡan.da/ · noun |
| [accusa](https://en.wiktionary.org/wiki/accusa#Italian) | accusation | /akˈku.za/ · noun |
| [gatto](https://en.wiktionary.org/wiki/gatto#Italian) | cat | /ˈɡat.to/ · noun |
| [albero](https://en.wiktionary.org/wiki/albero#Italian) | tree (all senses) | /ˈal.be.ro/ · noun |
| [banda](https://en.wiktionary.org/wiki/banda#Italian) | side | /ˈban.da/ · noun |
| [bandiera](https://en.wiktionary.org/wiki/bandiera#Italian) | flag | /banˈdjɛ.ra/ · noun |
| [catena](https://en.wiktionary.org/wiki/catena#Italian) | chain | /kaˈte.na/ · noun |
| [coda](https://en.wiktionary.org/wiki/coda#Italian) | tail | /ˈko.da/ · noun |
| [comma](https://en.wiktionary.org/wiki/comma#Italian) | subsection, subparagraph | /ˈkɔm.ma/ · noun |
| [leone](https://en.wiktionary.org/wiki/leone#Italian) | lion | /leˈo.ne/ · noun |
| [lupo](https://en.wiktionary.org/wiki/lupo#Italian) | wolf | /ˈlu.po/ · noun |
| [rapidamente](https://en.wiktionary.org/wiki/rapidamente#Italian) | quickly, rapidly | /ra.pi.daˈmen.te/ · adv |
| [rock](https://en.wiktionary.org/wiki/rock#Italian) | rock (style of music) | /ˈrɔk/ · noun |
| [sembrare](https://en.wiktionary.org/wiki/sembrare#Italian) | to seem, to look (like), to appear | /semˈbra.re/ · verb |
| [agire](https://en.wiktionary.org/wiki/agire#Italian) | to act or operate | /aˈd͡ʒi.re/ · verb |
| [assai](https://en.wiktionary.org/wiki/assai#Italian) | very | /asˈsaj/ · adv |
| [cattivo](https://en.wiktionary.org/wiki/cattivo#Italian) | bad | /katˈti.vo/ · adj |

</details>

<details><summary>Words 501–550</summary>

![[Resources/Audio/it/Words 0501-0550.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [fabbrica](https://en.wiktionary.org/wiki/fabbrica#Italian) | factory, plant | /ˈfab.bri.ka/ · noun |
| [manager](https://en.wiktionary.org/wiki/manager#Italian) | manager | /ˈma.na.d͡ʒer/ · noun |
| [moderno](https://en.wiktionary.org/wiki/moderno#Italian) | modern | /moˈdɛr.no/ · adj |
| [nonno](https://en.wiktionary.org/wiki/nonno#Italian) | grandfather | /ˈnɔn.no/ · noun |
| [pianta](https://en.wiktionary.org/wiki/pianta#Italian) | plant, tree | /ˈpjan.ta/ · noun |
| [abito](https://en.wiktionary.org/wiki/abito#Italian) | garment | /ˈa.bi.to/ · noun |
| [debole](https://en.wiktionary.org/wiki/debole#Italian) | weak, dim, faint | /ˈde.bo.le/ · adj |
| [email](https://en.wiktionary.org/wiki/email#Italian) | email |  · noun |
| [poeta](https://en.wiktionary.org/wiki/poeta#Italian) | poet | /poˈɛ.ta/ · noun |
| [attore](https://en.wiktionary.org/wiki/attore#Italian) | actor, player | /atˈto.re/ · noun |
| [business](https://en.wiktionary.org/wiki/business#Italian) | business (commercial enterprise) | /ˈbiz.nes/ · noun |
| [definire](https://en.wiktionary.org/wiki/definire#Italian) | to define | /de.fiˈni.re/ · verb |
| [formula](https://en.wiktionary.org/wiki/formula#Italian) | formula | /ˈfɔr.mu.la/ · noun |
| [okay](https://en.wiktionary.org/wiki/okay#Italian) | okay! |  · intj |
| [privacy](https://en.wiktionary.org/wiki/privacy#Italian) | privacy (especially online) | /ˈpraj.va.si/ · noun |
| [staff](https://en.wiktionary.org/wiki/staff#Italian) | staff (people) | /ˈstaf/ · noun |
| [ROM](https://en.wiktionary.org/wiki/ROM#Italian) | ROM |  · noun |
| [moneta](https://en.wiktionary.org/wiki/moneta#Italian) | coin | /moˈne.ta/ · noun |
| [puro](https://en.wiktionary.org/wiki/puro#Italian) | pure | /ˈpu.ro/ · adj |
| [autobus](https://en.wiktionary.org/wiki/autobus#Italian) | bus | /ˈaw.to.bus/ · noun |
| [bonus](https://en.wiktionary.org/wiki/bonus#Italian) | a bonus (all senses) | /ˈbɔ.nus/ · noun |
| [esercizio](https://en.wiktionary.org/wiki/esercizio) | exercise; practice |  · noun |
| [design](https://en.wiktionary.org/wiki/design#Italian) | design (industrial) | /deˈzajn/ · noun |
| [gloria](https://en.wiktionary.org/wiki/gloria#Italian) | glory | /ˈɡlɔ.rja/ · noun |
| [metro](https://en.wiktionary.org/wiki/metro#Italian) | metre, meter | /ˈmɛ.tro/ · noun |
| [neve](https://en.wiktionary.org/wiki/neve#Italian) | snow | /ˈne.ve/ · noun |
| [porre](https://en.wiktionary.org/wiki/porre#Italian) | to put | /ˈpor.re/ · verb |
| [zucchero](https://en.wiktionary.org/wiki/zucchero#Italian) | sugar (all senses) | /ˈd͡zuk.ke.ro/ · noun |
| [porno](https://en.wiktionary.org/wiki/porno#Italian) | pornographic | /ˈpɔr.no/ · adj |
| [virus](https://en.wiktionary.org/wiki/virus#Italian) | virus | /ˈvi.rus/ · noun |
| [dodici](https://en.wiktionary.org/wiki/dodici#Italian) | twelve | /ˈdo.di.t͡ʃi/ · num |
| [indice](https://en.wiktionary.org/wiki/indice#Italian) | index, index finger, forefinger | /ˈin.di.t͡ʃe/ · noun |
| [largo](https://en.wiktionary.org/wiki/largo#Italian) | wide, broad | /ˈlar.ɡo/ · adj |
| [martedì](https://en.wiktionary.org/wiki/marted%C3%AC#Italian) | Tuesday | /mar.teˈdi/ · noun |
| [nipote](https://en.wiktionary.org/wiki/nipote#Italian) | grandchild, grandson, granddaughter | /niˈpo.te/ · noun |
| [sexy](https://en.wiktionary.org/wiki/sexy#Italian) | sexy | /ˈsɛk.si/ · adj |
| [volere](https://en.wiktionary.org/wiki/volere#Italian) | to want | /voˈle.re/ · verb |
| [CD](https://en.wiktionary.org/wiki/CD#Italian) | CD, compact disc | /ˈt͡ʃi ˈdi/ · noun |
| [affitto](https://en.wiktionary.org/wiki/affitto#Italian) | renting, hiring | /afˈfit.to/ · noun |
| [rose](https://en.wiktionary.org/wiki/rose#Italian) | roses | /ˈrɔ.ze/ · noun |
| [server](https://en.wiktionary.org/wiki/server#Italian) | server (a computer or software that provides services to other programs or users) | /ˈsɛr.ver/ · noun |
| [specchio](https://en.wiktionary.org/wiki/specchio#Italian) | mirror | /ˈspɛk.kjo/ · noun |
| [stupido](https://en.wiktionary.org/wiki/stupido#Italian) | stupid, daft | /ˈstu.pi.do/ · adj |
| [cognome](https://en.wiktionary.org/wiki/cognome#Italian) | surname, cognomen | /koɲˈɲo.me/ · noun |
| [mercoledì](https://en.wiktionary.org/wiki/mercoled%C3%AC#Italian) | Wednesday | /ˌmɛr.ko.leˈdi/ · noun |
| [pero](https://en.wiktionary.org/wiki/pero#Italian) | pear tree | /ˈpe.ro/ · noun |
| [red](https://en.wiktionary.org/wiki/red#Italian) | a type of rice |  · noun |
| [spada](https://en.wiktionary.org/wiki/spada#Italian) | sword | /ˈspa.da/ · noun |
| [bacio](https://en.wiktionary.org/wiki/bacio#Italian) | kiss | /ˈba.t͡ʃo/ · noun |
| [ballo](https://en.wiktionary.org/wiki/ballo#Italian) | dance, ball | /ˈbal.lo/ · noun |

</details>

<details><summary>Words 551–600</summary>

![[Resources/Audio/it/Words 0551-0600.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [fiore](https://en.wiktionary.org/wiki/fiore#Italian) | flower, bloom, blossom | /ˈfjo.re/ · noun |
| [ghiaccio](https://en.wiktionary.org/wiki/ghiaccio#Italian) | icy, frozen, (very) cold, gelid | /ˈɡjat.t͡ʃo/ · adj |
| [lady](https://en.wiktionary.org/wiki/lady#Italian) | lady (wife of a lord; important woman) | /ˈlɛ.di/ · noun |
| [magia](https://en.wiktionary.org/wiki/magia#Italian) | magic | /maˈd͡ʒi.a/ · noun |
| [quinto](https://en.wiktionary.org/wiki/quinto#Italian) | fifth | /ˈkwin.to/ · adj |
| [torta](https://en.wiktionary.org/wiki/torta#Italian) | pie, tart, cake or similar | /ˈtor.ta/ · noun |
| [corona](https://en.wiktionary.org/wiki/corona#Italian) | crown (of a king, pope etc.) (also of a tooth) | /koˈro.na/ · noun |
| [eroe](https://en.wiktionary.org/wiki/eroe#Italian) | hero | /eˈrɔ.e/ · noun |
| [extra](https://en.wiktionary.org/wiki/extra#Italian) | extra | /ˈɛks.tra/ · adj |
| [lancia](https://en.wiktionary.org/wiki/lancia#Italian) | lance, spear | /ˈlan.t͡ʃa/ · noun |
| [premier](https://en.wiktionary.org/wiki/premier#Italian) | premier, prime minister (or similar title) | /ˈprɛ.mjer/ · noun |
| [robot](https://en.wiktionary.org/wiki/robot#Italian) | robot | /ˈrɔ.bot/ · noun |
| [sapore](https://en.wiktionary.org/wiki/sapore#Italian) | taste, flavour/flavor, savor | /saˈpo.re/ · noun |
| [scappare](https://en.wiktionary.org/wiki/scappare#Italian) | to run away, flee, escape, scarper or skedaddle | /skapˈpa.re/ · verb |
| [van](https://en.wiktionary.org/wiki/van#Italian) | van | /ˈvan/ · noun |
| [abilità](https://en.wiktionary.org/wiki/abilit%C3%A0#Italian) | ability, skill | /a.bi.liˈta/ · noun |
| [affetto](https://en.wiktionary.org/wiki/affetto#Italian) | affected | /afˈfɛt.to/ · adj |
| [barca](https://en.wiktionary.org/wiki/barca#Italian) | boat | /ˈbar.ka/ · noun |
| [go](https://en.wiktionary.org/wiki/go#Italian) | go | /ˈɡɔ/ · noun |
| [gratuito](https://en.wiktionary.org/wiki/gratuito#Italian) | free, free of charge, gratis | /ɡraˈtuj.to/ · adj |
| [rifugio](https://en.wiktionary.org/wiki/rifugio#Italian) | shelter, refuge | /riˈfu.d͡ʒo/ · noun |
| [sacro](https://en.wiktionary.org/wiki/sacro#Italian) | sacred | /ˈsa.kro/ · adj |
| [abbandonare](https://en.wiktionary.org/wiki/abbandonare#Italian) | to abandon (to leave behind) | /ab.ban.doˈna.re/ · verb |
| [amare](https://en.wiktionary.org/wiki/amare#Italian) | to love, to like | /aˈma.re/ · verb |
| [bus](https://en.wiktionary.org/wiki/bus#Italian) | bus |  · noun |
| [pesca](https://en.wiktionary.org/wiki/pesca#Italian) | peach (fruit) | /ˈpɛs.ka/ · noun |
| [rompere](https://en.wiktionary.org/wiki/rompere#Italian) | to break | /ˈrom.pe.re/ · verb |
| [stop](https://en.wiktionary.org/wiki/stop#Italian) | stop!, halt! | /ˈstɔp/ · intj |
| [stress](https://en.wiktionary.org/wiki/stress#Italian) | stress | /ˈstrɛs/ · noun |
| [viola](https://en.wiktionary.org/wiki/viola#Italian) | purple, violet | /viˈɔ.la/ · adj |
| [agricoltura](https://en.wiktionary.org/wiki/agricoltura#Italian) | agriculture | /a.ɡri.kolˈtu.ra/ · noun |
| [single](https://en.wiktionary.org/wiki/single#Italian) | single, loner (person who lives alone and has no emotional ties) | /ˈsin.ɡol/ · noun |
| [dia](https://en.wiktionary.org/wiki/dia#Italian) | day | /ˈdi.a/ · noun |
| [lusso](https://en.wiktionary.org/wiki/lusso#Italian) | luxury | /ˈlus.so/ · noun |
| [marketing](https://en.wiktionary.org/wiki/marketing#Italian) | marketing (the promotion, distribution and selling of a product or service) | /ˈmar.ke.tinɡ/ · noun |
| [suonare](https://en.wiktionary.org/wiki/suonare#Italian) | to play (an instrument) | /swoˈna.re/ · verb |
| [alba](https://en.wiktionary.org/wiki/alba#Italian) | dawn, daybreak, break of day | /ˈal.ba/ · noun |
| [danza](https://en.wiktionary.org/wiki/danza#Italian) | a dance | /ˈdan.t͡sa/ · noun |
| [die](https://en.wiktionary.org/wiki/die#Italian) | each day, a day, used in prescriptions to denote daily consumption of a drug | /ˈdi.e/ · adv |
| [gamba](https://en.wiktionary.org/wiki/gamba#Italian) | leg | /ˈɡam.ba/ · noun |
| [home](https://en.wiktionary.org/wiki/home#Italian) | home (initial position of various computing objects) | /ˈom/ · noun |
| [line](https://en.wiktionary.org/wiki/line#Italian) | line management | /ˈlajn/ · noun |
| [ombra](https://en.wiktionary.org/wiki/ombra#Italian) | shade, shadow | /ˈom.bra/ · noun |
| [baby](https://en.wiktionary.org/wiki/baby#Italian) | child, baby, neonate | /ˈbɛ.bi/ · noun |
| [calendario](https://en.wiktionary.org/wiki/calendario#Italian) | calendar | /ka.lenˈda.rjo/ · noun |
| [cantare](https://en.wiktionary.org/wiki/cantare#Italian) | to sing | /kanˈta.re/ · verb |
| [cioccolato](https://en.wiktionary.org/wiki/cioccolato#Italian) | chocolate (food, confectionery, colour/color) | /t͡ʃok.koˈla.to/ · noun |
| [fermata](https://en.wiktionary.org/wiki/fermata#Italian) | fermata (the holding of a note) | /ferˈma.ta/ · noun |
| [gola](https://en.wiktionary.org/wiki/gola#Italian) | throat (gullet or windpipe) | /ˈɡo.la/ · noun |
| [idiota](https://en.wiktionary.org/wiki/idiota#Italian) | idiotic | /iˈdjɔ.ta/ · adj |

</details>

<details><summary>Words 601–650</summary>

![[Resources/Audio/it/Words 0601-0650.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [imperatore](https://en.wiktionary.org/wiki/imperatore#Italian) | emperor | /im.pe.raˈto.re/ · noun |
| [martin](https://en.wiktionary.org/wiki/martin#Italian) | only used in martin pescatore |  · noun |
| [quindici](https://en.wiktionary.org/wiki/quindici#Italian) | fifteen | /ˈkwin.di.t͡ʃi/ · num |
| [status](https://en.wiktionary.org/wiki/status#Italian) | status (position in society) | /ˈsta.tus/ · noun |
| [zia](https://en.wiktionary.org/wiki/zia#Italian) | aunt | /ˈd͡zi.a/ · noun |
| [SMS](https://en.wiktionary.org/wiki/SMS#Italian) | SMS (text message) |  · noun |
| [arco](https://en.wiktionary.org/wiki/arco#Italian) | bow (weapon) | /ˈar.ko/ · noun |
| [furto](https://en.wiktionary.org/wiki/furto#Italian) | theft | /ˈfur.to/ · noun |
| [leggero](https://en.wiktionary.org/wiki/leggero#Italian) | light (in weight) | /ledˈd͡ʒɛ.ro/ · adj |
| [libreria](https://en.wiktionary.org/wiki/libreria#Italian) | bookshop, bookstore, bookhouse | /li.breˈri.a/ · noun |
| [raggio](https://en.wiktionary.org/wiki/raggio#Italian) | ray, beam, shaft (of light, etc.) | /ˈrad.d͡ʒo/ · noun |
| [ritmo](https://en.wiktionary.org/wiki/ritmo#Italian) | rhythm | /ˈrit.mo/ · noun |
| [statua](https://en.wiktionary.org/wiki/statua#Italian) | statue | /ˈsta.tu.a/ · noun |
| [tirare](https://en.wiktionary.org/wiki/tirare#Italian) | to pull, to draw, to tug, to drag | /tiˈra.re/ · verb |
| [adatto](https://en.wiktionary.org/wiki/adatto#Italian) | suitable or adapted for | /aˈdat.to/ · adj |
| [ente](https://en.wiktionary.org/wiki/ente#Italian) | corporation, body | /ˈɛn.te/ · noun |
| [occhiali](https://en.wiktionary.org/wiki/occhiali#Italian) | glasses, spectacles, eyeglasses (US) | /okˈkja.li/ · noun |
| [party](https://en.wiktionary.org/wiki/party#Italian) | party (“social gathering”) | /ˈpar.ti/ · noun |
| [pazzo](https://en.wiktionary.org/wiki/pazzo#Italian) | crazy, insane, mad | /ˈpat.t͡so/ · adj |
| [performance](https://en.wiktionary.org/wiki/performance#Italian) | performance | /perˈfɔr.mans/ · noun |
| [ritornare](https://en.wiktionary.org/wiki/ritornare#Italian) | to return, to go back | /ri.torˈna.re/ · verb |
| [schema](https://en.wiktionary.org/wiki/schema#Italian) | outline, schema, layout, diagram, plan, draft, project, arrangement | /ˈskɛ.ma/ · noun |
| [sesto](https://en.wiktionary.org/wiki/sesto#Italian) | sixth | /ˈsɛs.to/ · adj |
| [accusato](https://en.wiktionary.org/wiki/accusato#Italian) | accused | /ak.kuˈza.to/ · adj |
| [acido](https://en.wiktionary.org/wiki/acido#Italian) | acid | /ˈa.t͡ʃi.do/ · adj |
| [caos](https://en.wiktionary.org/wiki/caos#Italian) | chaos | /ˈka.os/ · noun |
| [divisa](https://en.wiktionary.org/wiki/divisa#Italian) | uniform | /diˈvi.za/ · noun |
| [doc](https://en.wiktionary.org/wiki/doc#Italian) | certified as DOC (of a product, usually wine) | /ˈdɔk/ · adj |
| [sano](https://en.wiktionary.org/wiki/sano#Italian) | free from disease | /ˈsa.no/ · adj |
| [accademia](https://en.wiktionary.org/wiki/accademia#Italian) | academy | /ak.kaˈdɛ.mja/ · noun |
| [duomo](https://en.wiktionary.org/wiki/duomo#Italian) | the principal church of a city (not having an episcopal throne) | /ˈdwɔ.mo/ · noun |
| [pavimento](https://en.wiktionary.org/wiki/pavimento#Italian) | floor | /pa.viˈmen.to/ · noun |
| [taxi](https://en.wiktionary.org/wiki/taxi#Italian) | taxi | /ˈtak.si/ · noun |
| [acciaio](https://en.wiktionary.org/wiki/acciaio#Italian) | steel | /atˈt͡ʃa.jo/ · noun |
| [esistere](https://en.wiktionary.org/wiki/esistere#Italian) | to exist, to be | /eˈzis.te.re/ · verb |
| [fresco](https://en.wiktionary.org/wiki/fresco#Italian) | fresh | /ˈfres.ko/ · adj |
| [mini](https://en.wiktionary.org/wiki/mini#Italian) | miniskirt | /ˈmi.ni/ · noun |
| [traduzione](https://en.wiktionary.org/wiki/traduzione) | translation |  · noun |
| [abitudine](https://en.wiktionary.org/wiki/abitudine#Italian) | habit, practice (customary behaviour/behavior) | /a.biˈtu.di.ne/ · noun |
| [allenatore](https://en.wiktionary.org/wiki/allenatore#Italian) | coach, manager, trainer | /al.le.naˈto.re/ · noun |
| [chitarra](https://en.wiktionary.org/wiki/chitarra#Italian) | guitar | /kiˈtar.ra/ · noun |
| [logo](https://en.wiktionary.org/wiki/logo#Italian) | logo (symbol) | /ˈlɔ.ɡo/ · noun |
| [rubare](https://en.wiktionary.org/wiki/rubare#Italian) | to steal (take something belonging to another) | /ruˈba.re/ · verb |
| [sabbia](https://en.wiktionary.org/wiki/sabbia#Italian) | sand | /ˈsab.bja/ · noun |
| [scenario](https://en.wiktionary.org/wiki/scenario#Italian) | scenery, set | /ʃeˈna.rjo/ · noun |
| [tasca](https://en.wiktionary.org/wiki/tasca#Italian) | pocket | /ˈtas.ka/ · noun |
| [bob](https://en.wiktionary.org/wiki/bob#Italian) | bobsleigh | /ˈbɔb/ · noun |
| [coro](https://en.wiktionary.org/wiki/coro#Italian) | chorus | /ˈkɔ.ro/ · noun |
| [lord](https://en.wiktionary.org/wiki/lord#Italian) | lord (British aristocrat) | /ˈlɔrd/ · noun |
| [play](https://en.wiktionary.org/wiki/play#Italian) | play (theatrical performance; start key) | /ˈplɛj/ · noun |

</details>

<details><summary>Words 651–700</summary>

![[Resources/Audio/it/Words 0651-0700.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [polo](https://en.wiktionary.org/wiki/polo#Italian) | pole (geographic, electrical or magnetic) | /ˈpɔ.lo/ · noun |
| [spot](https://en.wiktionary.org/wiki/spot#Italian) | spot (theatrical light; luminous point; brief radio or TV advertisement) | /ˈspɔt/ · noun |
| [tè](https://en.wiktionary.org/wiki/t%C3%A8#Italian) | tea (Camellia sinensis) | /ˈtɛ/ · noun |
| [volare](https://en.wiktionary.org/wiki/volare#Italian) | to fly | /voˈla.re/ · verb |
| [albergo](https://en.wiktionary.org/wiki/albergo#Italian) | hotel, inn | /alˈbɛr.ɡo/ · noun |
| [bicchiere](https://en.wiktionary.org/wiki/bicchiere#Italian) | glass (drinking vessel), cup, tumbler (glass without stem) | /bikˈkjɛ.re/ · noun |
| [condurre](https://en.wiktionary.org/wiki/condurre#Italian) | to lead, to guide, to escort | /konˈdur.re/ · verb |
| [crema](https://en.wiktionary.org/wiki/crema#Italian) | cream | /ˈkrɛ.ma/ · noun |
| [dialetto](https://en.wiktionary.org/wiki/dialetto#Italian) | dialect | /di.aˈlɛt.to/ · noun |
| [match](https://en.wiktionary.org/wiki/match#Italian) | match (sports event) | /ˈmɛt͡ʃ/ · noun |
| [pugno](https://en.wiktionary.org/wiki/pugno#Italian) | fist | /ˈpuɲ.ɲo/ · noun |
| [trend](https://en.wiktionary.org/wiki/trend#Italian) | trend | /ˈtrɛnd/ · noun |
| [a cappella](https://en.wiktionary.org/wiki/a%20cappella#Italian) | a cappella |  · adv |
| [cappella](https://en.wiktionary.org/wiki/cappella#Italian) | chapel | /kapˈpɛl.la/ · noun |
| [compare](https://en.wiktionary.org/wiki/compare#Italian) | a child's godfather in relation to their parents: a co-father; or a child's father in relation to their co-father and his family | /komˈpa.re/ · noun |
| [dose](https://en.wiktionary.org/wiki/dose#Italian) | dose | /ˈdɔ.ze/ · noun |
| [mezzogiorno](https://en.wiktionary.org/wiki/mezzogiorno#Italian) | midday, noon | /ˌmɛd.d͡zoˈd͡ʒor.no/ · noun |
| [puttana](https://en.wiktionary.org/wiki/puttana#Italian) | trollop, strumpet, whore, streetwalker | /putˈta.na/ · noun |
| [rivedere](https://en.wiktionary.org/wiki/rivedere#Italian) | to see again, meet again | /ri.veˈde.re/ · verb |
| [sistema operativo](https://en.wiktionary.org/wiki/sistema%20operativo#Italian) | operating system |  · noun |
| [sub](https://en.wiktionary.org/wiki/sub#Italian) | skin-diver, scuba diver | /ˈsub/ · noun |
| [attrice](https://en.wiktionary.org/wiki/attrice#Italian) | actress | /atˈtri.t͡ʃe/ · noun |
| [benché](https://en.wiktionary.org/wiki/bench%C3%A9#Italian) | although, though | /ˌbɛnˈke/ · conj |
| [nascere](https://en.wiktionary.org/wiki/nascere#Italian) | to be born | /ˈnaʃ.ʃe.re/ · verb |
| [penna](https://en.wiktionary.org/wiki/penna#Italian) | feather | /ˈpen.na/ · noun |
| [punizione](https://en.wiktionary.org/wiki/punizione#Italian) | punishment | /pu.nitˈt͡sjo.ne/ · noun |
| [rigore](https://en.wiktionary.org/wiki/rigore#Italian) | strictness, severity, harshness | /riˈɡo.re/ · noun |
| [spazzatura](https://en.wiktionary.org/wiki/spazzatura#Italian) | cleaning, sweep | /spat.t͡saˈtu.ra/ · noun |
| [accademico](https://en.wiktionary.org/wiki/accademico#Italian) | academician | /ak.kaˈdɛ.mi.ko/ · noun |
| [boy](https://en.wiktionary.org/wiki/boy#Italian) | a male ballet dancer | /ˈbɔj/ · noun |
| [cucinare](https://en.wiktionary.org/wiki/cucinare#Italian) | to cook | /ku.t͡ʃiˈna.re/ · verb |
| [database](https://en.wiktionary.org/wiki/database#Italian) | database |  · noun |
| [lanciare](https://en.wiktionary.org/wiki/lanciare#Italian) | to throw; to sling; to launch | /lanˈt͡ʃa.re/ · verb |
| [mancare](https://en.wiktionary.org/wiki/mancare#Italian) | to be lacking, to be missing (of objects) | /manˈka.re/ · verb |
| [pollo](https://en.wiktionary.org/wiki/pollo#Italian) | chicken | /ˈpol.lo/ · noun |
| [DNA](https://en.wiktionary.org/wiki/DNA#Italian) | DNA | /ˈdi ˈen.ne ˈa/ · noun |
| [abbandono](https://en.wiktionary.org/wiki/abbandono#Italian) | abandonment | /ab.banˈdo.no/ · noun |
| [colonia](https://en.wiktionary.org/wiki/colonia#Italian) | colony | /koˈlɔ.nja/ · noun |
| [folle](https://en.wiktionary.org/wiki/folle#Italian) | mad; insane | /ˈfɔl.le/ · adj |
| [futuro anteriore](https://en.wiktionary.org/wiki/futuro%20anteriore#Italian) | the future perfect tense |  · noun |
| [gelato](https://en.wiktionary.org/wiki/gelato#Italian) | icy, frozen, very cold | /d͡ʒeˈla.to/ · adj |
| [ginocchio](https://en.wiktionary.org/wiki/ginocchio#Italian) | knee | /d͡ʒiˈnɔk.kjo/ · noun |
| [lento](https://en.wiktionary.org/wiki/lento#Italian) | slow | /ˈlɛn.to/ · adj |
| [pasto](https://en.wiktionary.org/wiki/pasto#Italian) | meal | /ˈpas.to/ · noun |
| [raro](https://en.wiktionary.org/wiki/raro#Italian) | rare | /ˈra.ro/ · adj |
| [tubo](https://en.wiktionary.org/wiki/tubo#Italian) | tube | /ˈtu.bo/ · noun |
| [undici](https://en.wiktionary.org/wiki/undici#Italian) | eleven | /ˈun.di.t͡ʃi/ · num |
| [uni](https://en.wiktionary.org/wiki/uni#Italian) | university | /ˈu.ni/ · noun |
| [aquila](https://en.wiktionary.org/wiki/aquila#Italian) | eagle | /ˈa.kwi.la/ · noun |
| [imparare](https://en.wiktionary.org/wiki/imparare) | to learn |  · verb |

</details>

<details><summary>Words 701–750</summary>

![[Resources/Audio/it/Words 0701-0750.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [west](https://en.wiktionary.org/wiki/west#Italian) | West (historic area of America) | /ˈwɛst/ · noun |
| [ballare](https://en.wiktionary.org/wiki/ballare#Italian) | to dance | /balˈla.re/ · verb |
| [battere](https://en.wiktionary.org/wiki/battere#Italian) | to beat, to strike, to hit | /ˈbat.te.re/ · verb |
| [boom](https://en.wiktionary.org/wiki/boom#Italian) | a boom (sound) | /ˈbum/ · noun |
| [giacca](https://en.wiktionary.org/wiki/giacca#Italian) | jacket, coat | /ˈd͡ʒak.ka/ · noun |
| [ladro](https://en.wiktionary.org/wiki/ladro#Italian) | thief, lift | /ˈla.dro/ · noun |
| [password](https://en.wiktionary.org/wiki/password#Italian) | password | /ˈpas.sword/ · noun |
| [DVD](https://en.wiktionary.org/wiki/DVD#Italian) | DVD | /ˈdi ˈvu ˈdi/ · noun |
| [chef](https://en.wiktionary.org/wiki/chef#Italian) | chef (head cook) | /ˈʃɛf/ · noun |
| [fantasma](https://en.wiktionary.org/wiki/fantasma#Italian) | ghost, spectre | /fanˈtaz.ma/ · noun |
| [fegato](https://en.wiktionary.org/wiki/fegato#Italian) | liver (organ of human or animal; organ of animal used as food) | /ˈfe.ɡa.to/ · noun |
| [flash](https://en.wiktionary.org/wiki/flash#Italian) | flash, camera flash | /ˈflɛʃ/ · noun |
| [salita](https://en.wiktionary.org/wiki/salita#Italian) | climb | /saˈli.ta/ · noun |
| [abbigliamento](https://en.wiktionary.org/wiki/abbigliamento#Italian) | attire (what one wears) | /ab.biʎ.ʎaˈmen.to/ · noun |
| [affare](https://en.wiktionary.org/wiki/affare#Italian) | affair, matter | /afˈfa.re/ · noun |
| [immobile](https://en.wiktionary.org/wiki/immobile#Italian) | still, motionless, stationary | /imˈmɔ.bi.le/ · adj |
| [magnifico](https://en.wiktionary.org/wiki/magnifico#Italian) | magnificent | /maɲˈɲi.fi.ko/ · adj |
| [pronuncia](https://en.wiktionary.org/wiki/pronuncia#Italian) | pronunciation | /proˈnun.t͡ʃa/ · noun |
| [rientrare](https://en.wiktionary.org/wiki/rientrare#Italian) | to reenter; to go back (in) | /ri.enˈtra.re/ · verb |
| [Adam](https://en.wiktionary.org/wiki/Adam#Italian) | ecstasy (drug) |  · noun |
| [abuso](https://en.wiktionary.org/wiki/abuso#Italian) | overuse | /aˈbu.zo/ · noun |
| [adulto](https://en.wiktionary.org/wiki/adulto#Italian) | adult, grown-up | /aˈdul.to/ · adj |
| [basket](https://en.wiktionary.org/wiki/basket#Italian) | basketball | /ˈbas.ket/ · noun |
| [bestia](https://en.wiktionary.org/wiki/bestia#Italian) | beast | /ˈbes.tja/ · noun |
| [bicicletta](https://en.wiktionary.org/wiki/bicicletta#Italian) | bicycle | /bi.t͡ʃiˈklet.ta/ · noun |
| [burro](https://en.wiktionary.org/wiki/burro#Italian) | butter | /ˈbur.ro/ · noun |
| [canna](https://en.wiktionary.org/wiki/canna#Italian) | cane | /ˈkan.na/ · noun |
| [uovo](https://en.wiktionary.org/wiki/uovo#Italian) | egg | /ˈwɔ.vo/ · noun |
| [vapore](https://en.wiktionary.org/wiki/vapore#Italian) | steam | /vaˈpo.re/ · noun |
| [agricola](https://en.wiktionary.org/wiki/agricola#Italian) | farmer | /aˈɡri.ko.la/ · noun |
| [bimbo](https://en.wiktionary.org/wiki/bimbo#Italian) | child, baby (male) | /ˈbim.bo/ · noun |
| [boss](https://en.wiktionary.org/wiki/boss#Italian) | boss (leader of a business, company or criminal organization) | /ˈbɔs/ · noun |
| [box](https://en.wiktionary.org/wiki/box#Italian) | horsebox | /ˈbɔks/ · noun |
| [dea](https://en.wiktionary.org/wiki/dea#Italian) | goddess | /ˈdɛ.a/ · noun |
| [lama](https://en.wiktionary.org/wiki/lama#Italian) | blade (of a razor or sword) | /ˈla.ma/ · noun |
| [shock](https://en.wiktionary.org/wiki/shock#Italian) | shock (medical; violent or unexpected event) | /ˈʃɔk/ · noun |
| [tennis](https://en.wiktionary.org/wiki/tennis#Italian) | tennis | /ˈtɛn.nis/ · noun |
| [CD-ROM](https://en.wiktionary.org/wiki/CD-ROM#Italian) | CD-ROM |  · noun |
| [abitazione](https://en.wiktionary.org/wiki/abitazione#Italian) | habitation | /a.bi.tatˈt͡sjo.ne/ · noun |
| [accento](https://en.wiktionary.org/wiki/accento#Italian) | stress (in the pronunciation of a syllable, and the mark above a letter) | /atˈt͡ʃɛn.to/ · noun |
| [cattedrale](https://en.wiktionary.org/wiki/cattedrale#Italian) | cathedral | /kat.teˈdra.le/ · noun |
| [chirurgia](https://en.wiktionary.org/wiki/chirurgia#Italian) | surgery | /ki.rurˈd͡ʒi.a/ · noun |
| [corda](https://en.wiktionary.org/wiki/corda#Italian) | rope | /ˈkɔr.da/ · noun |
| [farina](https://en.wiktionary.org/wiki/farina#Italian) | flour, meal | /faˈri.na/ · noun |
| [genitore](https://en.wiktionary.org/wiki/genitore#Italian) | parent | /d͡ʒe.niˈto.re/ · noun |
| [jazz](https://en.wiktionary.org/wiki/jazz#Italian) | jazz | /ˈd͡ʒɛt͡s/ · noun |
| [killer](https://en.wiktionary.org/wiki/killer#Italian) | hitman (hired assassin) | /ˈkil.lɛr/ · noun |
| [trans](https://en.wiktionary.org/wiki/trans#Italian) | transsexual |  · noun |
| [avvenire](https://en.wiktionary.org/wiki/avvenire#Italian) | to happen, to occur | /av.veˈni.re/ · verb |
| [miele](https://en.wiktionary.org/wiki/miele#Italian) | honey | /ˈmjɛ.le/ · noun |

</details>

<details><summary>Words 751–800</summary>

![[Resources/Audio/it/Words 0751-0800.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [od](https://en.wiktionary.org/wiki/od#Italian) | or (used before a vowel for euphony instead of o) | /od/ · conj |
| [pelo](https://en.wiktionary.org/wiki/pelo#Italian) | hair (on the body) | /ˈpe.lo/ · noun |
| [radice](https://en.wiktionary.org/wiki/radice#Italian) | root | /raˈdi.t͡ʃe/ · noun |
| [replica](https://en.wiktionary.org/wiki/replica#Italian) | reply, answer | /ˈrɛ.pli.ka/ · noun |
| [tunnel](https://en.wiktionary.org/wiki/tunnel#Italian) | tunnel | /ˈtun.nel/ · noun |
| [causare](https://en.wiktionary.org/wiki/causare#Italian) | to cause | /kawˈza.re/ · verb |
| [salsa](https://en.wiktionary.org/wiki/salsa#Italian) | sauce | /ˈsal.sa/ · noun |
| [serva](https://en.wiktionary.org/wiki/serva#Italian) | (female) slave | /ˈsɛr.va/ · noun |
| [valere](https://en.wiktionary.org/wiki/valere#Italian) | to be worth | /vaˈle.re/ · verb |
| [card](https://en.wiktionary.org/wiki/card#Italian) | card (identification, financial, SIM etc., but not playing card) | /ˈkard/ · noun |
| [cast](https://en.wiktionary.org/wiki/cast#Italian) | cast (group of actors performing together) | /ˈkast/ · noun |
| [dappertutto](https://en.wiktionary.org/wiki/dappertutto#Italian) | everywhere, all over the place | /dap.perˈtut.to/ · adv |
| [football](https://en.wiktionary.org/wiki/football#Italian) | football |  · noun |
| [ordinare](https://en.wiktionary.org/wiki/ordinare#Italian) | to order | /or.diˈna.re/ · verb |
| [riga](https://en.wiktionary.org/wiki/riga#Italian) | line | /ˈri.ɡa/ · noun |
| [slogan](https://en.wiktionary.org/wiki/slogan#Italian) | slogan, specifically | /ˈzlɔ.ɡan/ · noun |
| [marine](https://en.wiktionary.org/wiki/marine#Italian) | marine (type of soldier) | /maˈrin/ · noun |
| [nido](https://en.wiktionary.org/wiki/nido#Italian) | nest | /ˈni.do/ · noun |
| [ossigeno](https://en.wiktionary.org/wiki/ossigeno#Italian) | oxygen | /osˈsi.d͡ʒe.no/ · noun |
| [sol](https://en.wiktionary.org/wiki/sol#Italian) | sol (a musical note) | /ˈsɔl/ · noun |
| [babbo](https://en.wiktionary.org/wiki/babbo#Italian) | dad, daddy | /ˈbab.bo/ · noun |
| [serra](https://en.wiktionary.org/wiki/serra#Italian) | greenhouse, glasshouse | /ˈsɛr.ra/ · noun |
| [stand](https://en.wiktionary.org/wiki/stand#Italian) | stand, booth, stall, pavilion (at a fair) | /ˈstɛnd/ · noun |
| [testata](https://en.wiktionary.org/wiki/testata#Italian) | headbutt | /tesˈta.ta/ · noun |
| [appassionato](https://en.wiktionary.org/wiki/appassionato#Italian) | passionate, ardent | /ap.pas.sjoˈna.to/ · adj |
| [basilica](https://en.wiktionary.org/wiki/basilica#Italian) | basilica | /baˈzi.li.ka/ · noun |
| [magazine](https://en.wiktionary.org/wiki/magazine#Italian) | magazine (publication, especially the supplement of a newspaper) | /ˈma.ɡa.zin/ · noun |
| [moro](https://en.wiktionary.org/wiki/moro#Italian) | mulberry tree | /ˈmɔ.ro/ · noun |
| [toro](https://en.wiktionary.org/wiki/toro#Italian) | bull (uncastrated adult male bovine) | /ˈtɔ.ro/ · noun |
| [approfondire](https://en.wiktionary.org/wiki/approfondire#Italian) | to deepen | /ap.pro.fonˈdi.re/ · verb |
| [cedere](https://en.wiktionary.org/wiki/cedere#Italian) | to withdraw, to surrender, to give up | /ˈt͡ʃɛ.de.re/ · verb |
| [centinaio](https://en.wiktionary.org/wiki/centinaio#Italian) | hundred, about a hundred, about one hundred | /t͡ʃen.tiˈna.jo/ · noun |
| [coca](https://en.wiktionary.org/wiki/coca#Italian) | Coke (serving of Coca-Cola) | /ˈkɔ.ka/ · noun |
| [cogliere](https://en.wiktionary.org/wiki/cogliere#Italian) | to pick, to gather | /ˈkɔʎ.ʎe.re/ · verb |
| [crescendo](https://en.wiktionary.org/wiki/crescendo#Italian) | crescendo (instruction to play gradually more loudly) | /kreʃˈʃɛn.do/ · noun |
| [full](https://en.wiktionary.org/wiki/full#Italian) | full house, boat |  · noun |
| [jeans](https://en.wiktionary.org/wiki/jeans#Italian) | jeans (trousers) | /ˈd͡ʒins/ · noun |
| [porco](https://en.wiktionary.org/wiki/porco#Italian) | pig, pork | /ˈpɔr.ko/ · noun |
| [agio](https://en.wiktionary.org/wiki/agio#Italian) | ease, comfort | /ˈa.d͡ʒo/ · noun |
| [ala](https://en.wiktionary.org/wiki/ala#Italian) | wing | /ˈa.la/ · noun |
| [balcone](https://en.wiktionary.org/wiki/balcone#Italian) | balcony | /balˈko.ne/ · noun |
| [passaporto](https://en.wiktionary.org/wiki/passaporto#Italian) | passport | /ˌpas.saˈpɔr.to/ · noun |
| [insegnare](https://en.wiktionary.org/wiki/insegnare) | to teach |  · verb |
| [abolizione](https://en.wiktionary.org/wiki/abolizione#Italian) | abolition | /a.bo.litˈt͡sjo.ne/ · noun |
| [frigo](https://en.wiktionary.org/wiki/frigo#Italian) | fridge, refrigerator | /ˈfri.ɡo/ · noun |
| [grido](https://en.wiktionary.org/wiki/grido#Italian) | cry, shout (made by a human) | /ˈɡri.do/ · noun |
| [mela](https://en.wiktionary.org/wiki/mela#Italian) | apple (fruit) | /ˈme.la/ · noun |
| [rame](https://en.wiktionary.org/wiki/rame#Italian) | copper (metal) | /ˈra.me/ · noun |
| [saggezza](https://en.wiktionary.org/wiki/saggezza#Italian) | wisdom | /sadˈd͡ʒet.t͡sa/ · noun |
| [settimo](https://en.wiktionary.org/wiki/settimo#Italian) | seventh | /ˈsɛt.ti.mo/ · adj |

</details>

<details><summary>Words 801–850</summary>

![[Resources/Audio/it/Words 0801-0850.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [uccello](https://en.wiktionary.org/wiki/uccello#Italian) | bird | /utˈt͡ʃɛl.lo/ · noun |
| [zitto](https://en.wiktionary.org/wiki/zitto#Italian) | quiet, silent | /ˈd͡zit.to/ · adj |
| [a posteriori](https://en.wiktionary.org/wiki/a%20posteriori#Italian) | a posteriori | /a pos.teˈrjɔ.ri/ · adj |
| [abbonamento](https://en.wiktionary.org/wiki/abbonamento#Italian) | subscription | /ab.bo.naˈmen.to/ · noun |
| [agenda](https://en.wiktionary.org/wiki/agenda#Italian) | diary | /aˈd͡ʒɛn.da/ · noun |
| [curriculum](https://en.wiktionary.org/wiki/curriculum#Italian) | curriculum | /kurˈri.ku.lum/ · noun |
| [dapprima](https://en.wiktionary.org/wiki/dapprima#Italian) | at first, firstly, first of all | /dapˈpri.ma/ · adv |
| [download](https://en.wiktionary.org/wiki/download#Italian) | download |  · noun |
| [effetto serra](https://en.wiktionary.org/wiki/effetto%20serra#Italian) | greenhouse effect |  · noun |
| [golf](https://en.wiktionary.org/wiki/golf#Italian) | golf | /ˈɡɔlf/ · noun |
| [saga](https://en.wiktionary.org/wiki/saga#Italian) | saga | /ˈsa.ɡa/ · noun |
| [telefonata](https://en.wiktionary.org/wiki/telefonata#Italian) | a phone call | /te.le.foˈna.ta/ · noun |
| [abbassare](https://en.wiktionary.org/wiki/abbassare#Italian) | to lower | /ab.basˈsa.re/ · verb |
| [barriera](https://en.wiktionary.org/wiki/barriera#Italian) | barrier, turnpike | /barˈrjɛ.ra/ · noun |
| [gallo](https://en.wiktionary.org/wiki/gallo#Italian) | rooster, cock | /ˈɡal.lo/ · noun |
| [gang](https://en.wiktionary.org/wiki/gang#Italian) | gang, specifically | /ˈɡɛnɡ/ · noun |
| [loco](https://en.wiktionary.org/wiki/loco#Italian) | lochus (a military unit headed by a lochagus) | /ˈlɔ.ko/ · noun |
| [maestà](https://en.wiktionary.org/wiki/maest%C3%A0#Italian) | majesty | /ma.esˈta/ · noun |
| [marrone](https://en.wiktionary.org/wiki/marrone#Italian) | brown | /marˈro.ne/ · adj |
| [mister](https://en.wiktionary.org/wiki/mister#Italian) | mister (appellation) |  · noun |
| [nono](https://en.wiktionary.org/wiki/nono#Italian) | ninth | /ˈnɔ.no/ · adj |
| [pregare](https://en.wiktionary.org/wiki/pregare#Italian) | to pray | /preˈɡa.re/ · verb |
| [romantico](https://en.wiktionary.org/wiki/romantico#Italian) | romantic, sentimental, emotional | /roˈman.ti.ko/ · adj |
| [stage](https://en.wiktionary.org/wiki/stage#Italian) | internship, stagiaire | /sˈtaʒ/ · noun |
| [variante](https://en.wiktionary.org/wiki/variante#Italian) | variant | /vaˈrjan.te/ · noun |
| [amen](https://en.wiktionary.org/wiki/amen#Italian) | amen, so be it | /ˈa.men/ · intj |
| [arena](https://en.wiktionary.org/wiki/arena#Italian) | sand | /aˈre.na/ · noun |
| [deficit](https://en.wiktionary.org/wiki/deficit#Italian) | deficit | /ˈdɛ.fi.t͡ʃit/ · noun |
| [faro](https://en.wiktionary.org/wiki/faro#Italian) | lighthouse | /ˈfa.ro/ · noun |
| [invidia](https://en.wiktionary.org/wiki/invidia#Italian) | envy | /inˈvi.dja/ · noun |
| [metal](https://en.wiktionary.org/wiki/metal#Italian) | metal | /ˈmɛ.tal/ · noun |
| [routine](https://en.wiktionary.org/wiki/routine#Italian) | routine | /ruˈtin/ · noun |
| [stare zitto](https://en.wiktionary.org/wiki/stare%20zitto#Italian) | to be quiet, to shut up |  · verb |
| [becco](https://en.wiktionary.org/wiki/becco#Italian) | beak (structure projecting from a bird's face) | /ˈbek.ko/ · noun |
| [management](https://en.wiktionary.org/wiki/management#Italian) | management | /ˈma.nad͡ʒ.ment/ · noun |
| [ni](https://en.wiktionary.org/wiki/ni#Italian) | neither yes nor no | /ˈni/ · adv |
| [novecento](https://en.wiktionary.org/wiki/novecento#Italian) | nine hundred | /ˌnɔ.veˈt͡ʃɛn.to/ · num |
| [pullman](https://en.wiktionary.org/wiki/pullman#Italian) | coach, bus (travelling/traveling between towns) | /ˈpul.man/ · noun |
| [ago](https://en.wiktionary.org/wiki/ago#Italian) | needle | /ˈa.ɡo/ · noun |
| [copyright](https://en.wiktionary.org/wiki/copyright#Italian) | copyright | /ko.piˈrajt/ · noun |
| [gabbia](https://en.wiktionary.org/wiki/gabbia#Italian) | cage, hutch | /ˈɡab.bja/ · noun |
| [limone](https://en.wiktionary.org/wiki/limone#Italian) | lemon (fruit & tree) | /liˈmo.ne/ · noun |
| [manga](https://en.wiktionary.org/wiki/manga#Italian) | manga (comic originating in Japan) | /ˈman.ɡa/ · noun |
| [monitor](https://en.wiktionary.org/wiki/monitor#Italian) | monitor (apparatus) | /ˈmɔ.ni.tor/ · noun |
| [ordinario](https://en.wiktionary.org/wiki/ordinario#Italian) | ordinary, usual, normal, customary | /or.diˈna.rjo/ · adj |
| [chance](https://en.wiktionary.org/wiki/chance#Italian) | chance (possibility of a certain outcome) | /ˈʃans/ · noun |
| [cinquecento](https://en.wiktionary.org/wiki/cinquecento#Italian) | five hundred | /ˌt͡ʃin.kweˈt͡ʃɛn.to/ · num |
| [dividere](https://en.wiktionary.org/wiki/dividere#Italian) | to divide, to split | /diˈvi.de.re/ · verb |
| [genovese](https://en.wiktionary.org/wiki/genovese#Italian) | of, from or relating to the city of Genoa or surrounding province, Liguria, Italy | /d͡ʒe.noˈve.ze/ · adj |
| [night](https://en.wiktionary.org/wiki/night#Italian) | nightclub | /ˈnajt/ · noun |

</details>

<details><summary>Words 851–900</summary>

![[Resources/Audio/it/Words 0851-0900.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [nostalgia](https://en.wiktionary.org/wiki/nostalgia#Italian) | nostalgia, homesickness, longing | /nos.talˈd͡ʒi.a/ · noun |
| [profeta](https://en.wiktionary.org/wiki/profeta#Italian) | prophet | /proˈfɛ.ta/ · noun |
| [troll](https://en.wiktionary.org/wiki/troll#Italian) | troll (grotesque person, Internet troll) |  · noun |
| [zaino](https://en.wiktionary.org/wiki/zaino#Italian) | satchel, rucksack, backpack | /ˈd͡zaj.no/ · noun |
| [al dente](https://en.wiktionary.org/wiki/al%20dente#Italian) | Firm to the bite, cooked just right. | /al ˈdɛn.te/ · phrase |
| [clan](https://en.wiktionary.org/wiki/clan#Italian) | clan | /ˈklan/ · noun |
| [coach](https://en.wiktionary.org/wiki/coach#Italian) | coach (sports instructor) | /ˈkot͡ʃ/ · noun |
| [decimo](https://en.wiktionary.org/wiki/decimo#Italian) | tenth | /ˈdɛ.t͡ʃi.mo/ · adj |
| [dente](https://en.wiktionary.org/wiki/dente#Italian) | tooth | /ˈdɛn.te/ · noun |
| [fattoria](https://en.wiktionary.org/wiki/fattoria#Italian) | farm | /fat.toˈri.a/ · noun |
| [fetta](https://en.wiktionary.org/wiki/fetta#Italian) | slice (of meat, cake, etc) | /ˈfet.ta/ · noun |
| [ira](https://en.wiktionary.org/wiki/ira#Italian) | anger, ire, wrath | /ˈi.ra/ · noun |
| [laser](https://en.wiktionary.org/wiki/laser#Italian) | laser | /ˈla.zer/ · noun |
| [lite](https://en.wiktionary.org/wiki/lite#Italian) | a quarrel, row, altercation, fight | /ˈli.te/ · noun |
| [temere](https://en.wiktionary.org/wiki/temere#Italian) | to fear | /teˈme.re/ · verb |
| [tessera](https://en.wiktionary.org/wiki/tessera#Italian) | card; credit card | /ˈtɛs.se.ra/ · noun |
| [tredici](https://en.wiktionary.org/wiki/tredici#Italian) | thirteen | /ˈtre.di.t͡ʃi/ · num |
| [AC](https://en.wiktionary.org/wiki/AC#Italian) | anno Christi |  · noun |
| [africano](https://en.wiktionary.org/wiki/africano#Italian) | African (of, from or relating to Africa) | /a.friˈka.no/ · adj |
| [durare](https://en.wiktionary.org/wiki/durare#Italian) | to last | /duˈra.re/ · verb |
| [ego](https://en.wiktionary.org/wiki/ego#Italian) | ego | /ˈɛ.ɡo/ · noun |
| [fragile](https://en.wiktionary.org/wiki/fragile#Italian) | fragile | /ˈfra.d͡ʒi.le/ · adj |
| [pomodoro](https://en.wiktionary.org/wiki/pomodoro#Italian) | tomato | /ˌpo.moˈdɔ.ro/ · noun |
| [pub](https://en.wiktionary.org/wiki/pub#Italian) | pub | /ˈpab/ · noun |
| [ubriaco](https://en.wiktionary.org/wiki/ubriaco#Italian) | drunk (intoxicated) | /u.briˈa.ko/ · adj |
| [brand](https://en.wiktionary.org/wiki/brand#Italian) | brand (product symbol) |  · noun |
| [cross](https://en.wiktionary.org/wiki/cross#Italian) | motocross | /ˈkrɔs/ · noun |
| [freno](https://en.wiktionary.org/wiki/freno#Italian) | brake | /ˈfre.no/ · noun |
| [hacker](https://en.wiktionary.org/wiki/hacker#Italian) | hacker (one who is expert at programming and solving problems with a computer) | /ˈa.ker/ · noun |
| [meme](https://en.wiktionary.org/wiki/meme#Italian) | meme (media, usually humorous, which is copied and circulated online with slight adaptations) | /ˈmɛ.me/ · noun |
| [servo](https://en.wiktionary.org/wiki/servo#Italian) | servile (of or pertaining to a slave) | /ˈsɛr.vo/ · adj |
| [svedese](https://en.wiktionary.org/wiki/svedese#Italian) | Swedish | /zveˈde.ze/ · adj |
| [vela](https://en.wiktionary.org/wiki/vela#Italian) | sail | /ˈve.la/ · noun |
| [abate](https://en.wiktionary.org/wiki/abate#Italian) | abbot | /aˈba.te/ · noun |
| [capra](https://en.wiktionary.org/wiki/capra#Italian) | goat (a mammal) | /ˈka.pra/ · noun |
| [dark](https://en.wiktionary.org/wiki/dark#Italian) | dark (used especially to describe a form of punk music) | /ˈdark/ · adj |
| [duecento](https://en.wiktionary.org/wiki/duecento#Italian) | two hundred | /ˌdu.eˈt͡ʃɛn.to/ · num |
| [fauna](https://en.wiktionary.org/wiki/fauna#Italian) | fauna | /ˈfaw.na/ · noun |
| [marijuana](https://en.wiktionary.org/wiki/marijuana#Italian) | marijuana | /ma.riˈwa.na/ · noun |
| [meeting](https://en.wiktionary.org/wiki/meeting#Italian) | meeting (gathering of people for a purpose) | /ˈmi.tinɡ/ · noun |
| [novanta](https://en.wiktionary.org/wiki/novanta#Italian) | ninety | /noˈvan.ta/ · num |
| [orecchio](https://en.wiktionary.org/wiki/orecchio#Italian) | ear | /oˈrek.kjo/ · noun |
| [ottanta](https://en.wiktionary.org/wiki/ottanta#Italian) | eighty | /otˈtan.ta/ · num |
| [poker](https://en.wiktionary.org/wiki/poker#Italian) | poker | /ˈpɔ.ker/ · noun |
| [USB](https://en.wiktionary.org/wiki/USB#Italian) | USB | /ˈu ˈɛs.se ˈbi/ · noun |
| [canadese](https://en.wiktionary.org/wiki/canadese#Italian) | Canadian | /ka.naˈde.ze/ · adj |
| [lavare](https://en.wiktionary.org/wiki/lavare#Italian) | to wash | /laˈva.re/ · verb |
| [abbondante](https://en.wiktionary.org/wiki/abbondante#Italian) | abundant | /ab.bonˈdan.te/ · adj |
| [bancario](https://en.wiktionary.org/wiki/bancario#Italian) | bank | /banˈka.rjo/ · adj |
| [country](https://en.wiktionary.org/wiki/country#Italian) | country music | /ˈkawn.tri/ · noun |

</details>

<details><summary>Words 901–950</summary>

![[Resources/Audio/it/Words 0901-0950.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [decadenza](https://en.wiktionary.org/wiki/decadenza#Italian) | decline, decay (deterioration of condition) | /de.kaˈdɛn.t͡sa/ · noun |
| [delta](https://en.wiktionary.org/wiki/delta#Italian) | delta (all senses) | /ˈdɛl.ta/ · noun |
| [diesel](https://en.wiktionary.org/wiki/diesel#Italian) | diesel (engine; vehicle) | /ˈdi.zel/ · noun |
| [gene](https://en.wiktionary.org/wiki/gene#Italian) | gene | /ˈd͡ʒɛ.ne/ · noun |
| [quattordici](https://en.wiktionary.org/wiki/quattordici#Italian) | fourteen | /kwatˈtor.di.t͡ʃi/ · num |
| [relax](https://en.wiktionary.org/wiki/relax#Italian) | relaxation | /reˈlaks/ · noun |
| [rugby](https://en.wiktionary.org/wiki/rugby#Italian) | rugby (form of football) | /ˈrɛɡ.bi/ · noun |
| [scimmia](https://en.wiktionary.org/wiki/scimmia#Italian) | monkey, simian | /ˈʃim.mja/ · noun |
| [uva](https://en.wiktionary.org/wiki/uva#Italian) | grapes | /ˈu.va/ · noun |
| [zoo](https://en.wiktionary.org/wiki/zoo#Italian) | zoo | /ˈd͡zɔ.o/ · noun |
| [blogger](https://en.wiktionary.org/wiki/blogger#Italian) | blogger |  · noun |
| [body](https://en.wiktionary.org/wiki/body#Italian) | leotard | /ˈbɔ.di/ · noun |
| [duo](https://en.wiktionary.org/wiki/duo#Italian) | duo | /ˈdu.o/ · noun |
| [moderato](https://en.wiktionary.org/wiki/moderato#Italian) | moderate | /mo.deˈra.to/ · adj |
| [ebreo](https://en.wiktionary.org/wiki/ebreo#Italian) | Hebrew, Jewish | /eˈbrɛ.o/ · adj |
| [gonna](https://en.wiktionary.org/wiki/gonna#Italian) | skirt | /ˈɡɔn.na/ · noun |
| [menu](https://en.wiktionary.org/wiki/menu#Italian) | menu | /meˈnu/ · noun |
| [seme](https://en.wiktionary.org/wiki/seme#Italian) | seed, pip | /ˈse.me/ · noun |
| [baseball](https://en.wiktionary.org/wiki/baseball#Italian) | baseball | /ˈbɛz.bol/ · noun |
| [coma](https://en.wiktionary.org/wiki/coma#Italian) | coma | /ˈkɔ.ma/ · noun |
| [dedicare](https://en.wiktionary.org/wiki/dedicare#Italian) | to dedicate | /de.diˈka.re/ · verb |
| [focus](https://en.wiktionary.org/wiki/focus#Italian) | focus (all senses) | /ˈfɔ.kus/ · noun |
| [lesbica](https://en.wiktionary.org/wiki/lesbica#Italian) | lesbian | /ˈlɛz.bi.ka/ · noun |
| [aglio](https://en.wiktionary.org/wiki/aglio#Italian) | garlic | /ˈaʎ.ʎo/ · noun |
| [automobile](https://en.wiktionary.org/wiki/automobile#Italian) | automobile | /aw.toˈmɔ.bi.le/ · noun |
| [sillaba](https://en.wiktionary.org/wiki/sillaba) | syllable |  · noun |
| [dote](https://en.wiktionary.org/wiki/dote#Italian) | dowry, dower | /ˈdɔ.te/ · noun |
| [lava](https://en.wiktionary.org/wiki/lava#Italian) | lava | /ˈla.va/ · noun |
| [odiare](https://en.wiktionary.org/wiki/odiare#Italian) | to hate, to detest, to loathe | /oˈdja.re/ · verb |
| [para](https://en.wiktionary.org/wiki/para#Italian) | crepe rubber | /ˈpa.ra/ · noun |
| [trio](https://en.wiktionary.org/wiki/trio#Italian) | trio, threesome | /ˈtri.o/ · noun |
| [vagina](https://en.wiktionary.org/wiki/vagina#Italian) | vagina | /vaˈd͡ʒi.na/ · noun |
| [barra](https://en.wiktionary.org/wiki/barra#Italian) | rod, bar, slat | /ˈbar.ra/ · noun |
| [dozzina](https://en.wiktionary.org/wiki/dozzina#Italian) | dozen (twelve or about twelve) | /dodˈd͡zi.na/ · noun |
| [ebraico](https://en.wiktionary.org/wiki/ebraico#Italian) | Hebrew, Hebraic, Jewish | /eˈbraj.ko/ · adj |
| [nova](https://en.wiktionary.org/wiki/nova#Italian) | nova | /ˈnɔ.va/ · noun |
| [pierre](https://en.wiktionary.org/wiki/pierre#Italian) | person who works in public relations | /piˈɛr.re/ · noun |
| [tram](https://en.wiktionary.org/wiki/tram#Italian) | tram, streetcar, trolley car | /ˈtram/ · noun |
| [a priori](https://en.wiktionary.org/wiki/a%20priori#Italian) | a priori |  · adj |
| [diga](https://en.wiktionary.org/wiki/diga#Italian) | an hydraulic barrier built for protection purposes or for the creation of a basin | /ˈdi.ɡa/ · noun |
| [hall](https://en.wiktionary.org/wiki/hall#Italian) | hall, lobby, lounge | /ˈɔl/ · noun |
| [insalata](https://en.wiktionary.org/wiki/insalata#Italian) | lettuce | /in.saˈla.ta/ · noun |
| [lente](https://en.wiktionary.org/wiki/lente#Italian) | lens | /ˈlɛn.te/ · noun |
| [lira](https://en.wiktionary.org/wiki/lira#Italian) | lira | /ˈli.ra/ · noun |
| [pallavolo](https://en.wiktionary.org/wiki/pallavolo#Italian) | volleyball (a game played on a rectangular court between two teams of two to six players which involves striking a ball back and forth over a net) | /ˌpal.laˈvo.lo/ · noun |
| [panna](https://en.wiktionary.org/wiki/panna#Italian) | cream | /ˈpan.na/ · noun |
| [polacco](https://en.wiktionary.org/wiki/polacco#Italian) | Polish | /poˈlak.ko/ · adj |
| [raid](https://en.wiktionary.org/wiki/raid#Italian) | raid, incursion | /ˈrajd/ · noun |
| [satellite](https://en.wiktionary.org/wiki/satellite#Italian) | satellite | /saˈtɛl.li.te/ · noun |
| [abolire](https://en.wiktionary.org/wiki/abolire#Italian) | to abrogate, to annul, to cancel, to repeal | /a.boˈli.re/ · verb |

</details>

<details><summary>Words 951–1000</summary>

![[Resources/Audio/it/Words 0951-1000.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [acuto](https://en.wiktionary.org/wiki/acuto#Italian) | acute | /aˈku.to/ · adj |
| [ana](https://en.wiktionary.org/wiki/ana#Italian) | ana (in equal quantities) |  · adv |
| [aurora](https://en.wiktionary.org/wiki/aurora#Italian) | aurora | /awˈrɔ.ra/ · noun |
| [bah](https://en.wiktionary.org/wiki/bah#Italian) | indicates astonishment, resignation and despise; usually used after noticing or hearing something you don't like or you don't know what to think about, to avoid commenting or giving an answer to a question | /ˈba/ · intj |
| [fieri](https://en.wiktionary.org/wiki/fieri#Italian) | See in fieri | /ˈfjɛ.ri/ · adj |
| [punire](https://en.wiktionary.org/wiki/punire#Italian) | to punish | /puˈni.re/ · verb |
| [spaghetti](https://en.wiktionary.org/wiki/spaghetti#Italian) | a dish of spaghetti | /spaˈɡet.ti/ · noun |
| [vulcano](https://en.wiktionary.org/wiki/vulcano#Italian) | volcano | /vulˈka.no/ · noun |
| [Wi-Fi](https://en.wiktionary.org/wiki/Wi-Fi#Italian) | Wi-Fi | /ˈwaj ˈfaj/ · noun |
| [abbondanza](https://en.wiktionary.org/wiki/abbondanza#Italian) | abundance | /ab.bonˈdan.t͡sa/ · noun |
| [banana](https://en.wiktionary.org/wiki/banana#Italian) | banana (fruit) | /baˈna.na/ · noun |
| [fallire](https://en.wiktionary.org/wiki/fallire#Italian) | to miss, to not hit (a target, a ball, etc.) | /falˈli.re/ · verb |
| [consonante](https://en.wiktionary.org/wiki/consonante) | consonant |  · noun |
| [hobby](https://en.wiktionary.org/wiki/hobby#Italian) | hobby (activity) | /ˈɔb.bi/ · noun |
| [khan](https://en.wiktionary.org/wiki/khan#Italian) | khan | /ˈkan/ · noun |
| [mole](https://en.wiktionary.org/wiki/mole#Italian) | mole | /ˈmɔ.le/ · noun |
| [osso](https://en.wiktionary.org/wiki/osso#Italian) | bone | /ˈɔs.so/ · noun |
| [passato remoto](https://en.wiktionary.org/wiki/passato%20remoto#Italian) | past historic tense, past historic |  · noun |
| [pirata](https://en.wiktionary.org/wiki/pirata#Italian) | pirate | /piˈra.ta/ · adj |
| [reality](https://en.wiktionary.org/wiki/reality#Italian) | reality show | /ˈre.a.li.ti/ · noun |
| [settecento](https://en.wiktionary.org/wiki/settecento#Italian) | seven hundred | /ˌsɛt.teˈt͡ʃɛn.to/ · num |
| [share](https://en.wiktionary.org/wiki/share#Italian) | percent of people watching a particular show out of the total viewing audience at a given time |  · noun |
| [soft](https://en.wiktionary.org/wiki/soft#Italian) | soft (tone etc.; temporary (computing)) | /ˈsɔft/ · adj |
| [sound](https://en.wiktionary.org/wiki/sound#Italian) | sound (distinctive style and sonority) | /ˈsawnd/ · noun |
| [ba](https://en.wiktionary.org/wiki/ba#Italian) | bah! | /ˈba/ · intj |
| [bastare](https://en.wiktionary.org/wiki/bastare#Italian) | to be enough | /basˈta.re/ · verb |
| [chic](https://en.wiktionary.org/wiki/chic#Italian) | chic | /ˈʃik/ · adj |
| [cocktail](https://en.wiktionary.org/wiki/cocktail#Italian) | cocktail | /ˈkɔk.tel/ · noun |
| [lego](https://en.wiktionary.org/wiki/lego#Italian) | Lego | /ˈle.ɡo/ · noun |
| [mouse](https://en.wiktionary.org/wiki/mouse#Italian) | mouse | /ˈma.us/ · noun |
| [nano](https://en.wiktionary.org/wiki/nano#Italian) | dwarfish | /ˈna.no/ · adj |
| [vacca](https://en.wiktionary.org/wiki/vacca#Italian) | cow | /ˈvak.ka/ · noun |
| [RAM](https://en.wiktionary.org/wiki/RAM#Italian) | RAM |  · noun |
| [bagaglio](https://en.wiktionary.org/wiki/bagaglio#Italian) | luggage, baggage | /baˈɡaʎ.ʎo/ · noun |
| [geometria](https://en.wiktionary.org/wiki/geometria#Italian) | geometry | /d͡ʒe.o.meˈtri.a/ · noun |
| [musical](https://en.wiktionary.org/wiki/musical#Italian) | musical | /ˈmju.zi.kol/ · noun |
| [panda](https://en.wiktionary.org/wiki/panda#Italian) | panda, especially the giant panda | /ˈpan.da/ · noun |
| [round](https://en.wiktionary.org/wiki/round#Italian) | round | /ˈrawnd/ · noun |
| [abile](https://en.wiktionary.org/wiki/abile#Italian) | skilful | /ˈa.bi.le/ · adj |
| [candela](https://en.wiktionary.org/wiki/candela#Italian) | candle | /kanˈde.la/ · noun |
| [chip](https://en.wiktionary.org/wiki/chip#Italian) | chip (small electronic component) | /ˈt͡ʃip/ · noun |
| [dammi](https://en.wiktionary.org/wiki/dammi#Italian) | compound of da', the second-person singular imperative form of dare, with mi (“give me”) |  · verb |
| [evviva](https://en.wiktionary.org/wiki/evviva#Italian) | hurray!, hurrah! | /evˈvi.va/ · intj |
| [intelligence](https://en.wiktionary.org/wiki/intelligence#Italian) | a political or military department, agency or unit designed to gather information | /inˈtɛl.li.d͡ʒens/ · noun |
| [sciogliere](https://en.wiktionary.org/wiki/sciogliere#Italian) | to melt, to liquify, to dissolve, to thaw | /ˈʃɔʎ.ʎe.re/ · verb |
| [tigre](https://en.wiktionary.org/wiki/tigre#Italian) | tiger (male or female) | /ˈti.ɡre/ · noun |
| [abbracciare](https://en.wiktionary.org/wiki/abbracciare#Italian) | to embrace, to hug | /ab.bratˈt͡ʃa.re/ · verb |
| [capitare](https://en.wiktionary.org/wiki/capitare#Italian) | to happen | /ka.piˈta.re/ · verb |
| [fast food](https://en.wiktionary.org/wiki/fast%20food#Italian) | fast food (type of meal that is often pre-prepared and served quickly) | /ˈfast ˈfud/ · noun |
| [accidenti](https://en.wiktionary.org/wiki/accidenti#Italian) | expression of anger; damn it! | /at.t͡ʃiˈdɛn.ti/ · intj |

</details>

## Question bank

Try before opening the answers. Different tasks use the same sentence to practise complementary skills. Open translation and explanation tasks can have valid alternatives.

### Definite articles · 50 questions

**it-Q0001 · Fill the gap**

____ miei doveri pubblici mi prendono molto tempo.

My public duties take a lot of time.

[[Italian#^it-Q0001-answer|Compare the answer]]
^it-Q0001

**it-Q0002 · Choose the form**

____ miei doveri pubblici mi prendono molto tempo.

My public duties take a lot of time.

Choices: lo / I / il / la

[[Italian#^it-Q0002-answer|Compare the answer]]
^it-Q0002

**it-Q0003 · Edit the changed sentence**

Temo che mi verrà 【lo】 mal di testa pensando a quant'è fastidioso Chris.

My head starts to hurt when I think about how annoying Chris is.

[[Italian#^it-Q0003-answer|Compare the answer]]
^it-Q0003

**it-Q0004 · Build the sentence**

Arrange: pensando / quant'è / Chris. / a / di / mal / Temo / testa / fastidioso / il / mi / verrà / che

My head starts to hurt when I think about how annoying Chris is.

[[Italian#^it-Q0004-answer|Compare the answer]]
^it-Q0004

**it-Q0005 · Write a translation**

Write this in Italian: I know you haven't done it yet.

[[Italian#^it-Q0005-answer|Compare the answer]]
^it-Q0005

**it-Q0006 · Explain the grammar**

【Lo】 so che non l'ha ancora fatta.

I know you haven't done it yet.

[[Italian#^it-Q0006-answer|Compare the answer]]
^it-Q0006

**it-Q0007 · Fill the gap**

____ mia vita non è più la stessa da quando l'ho conosciuto.

My life hasn't been the same since I met him.

[[Italian#^it-Q0007-answer|Compare the answer]]
^it-Q0007

**it-Q0008 · Choose the form**

____ mia vita non è più la stessa da quando l'ho conosciuto.

My life hasn't been the same since I met him.

Choices: i / La / lo / il

[[Italian#^it-Q0008-answer|Compare the answer]]
^it-Q0008

**it-Q0009 · Edit the changed sentence**

Per piacere, non mi comprare nulla per 【lo】 mio compleanno.

Please don't buy me anything for my birthday.

[[Italian#^it-Q0009-answer|Compare the answer]]
^it-Q0009

**it-Q0010 · Build the sentence**

Arrange: Per / mi / comprare / per / piacere, / il / compleanno. / non / nulla / mio

Please don't buy me anything for my birthday.

[[Italian#^it-Q0010-answer|Compare the answer]]
^it-Q0010

**it-Q0011 · Write a translation**

Write this in Italian: The box was full of books.

[[Italian#^it-Q0011-answer|Compare the answer]]
^it-Q0011

**it-Q0012 · Explain the grammar**

【La】 scatola era piena di libri.

The box was full of books.

[[Italian#^it-Q0012-answer|Compare the answer]]
^it-Q0012

**it-Q0013 · Fill the gap**

____ risultato del sondaggio sarà presto conosciuto.

The result of the poll will be known soon.

[[Italian#^it-Q0013-answer|Compare the answer]]
^it-Q0013

**it-Q0014 · Choose the form**

____ risultato del sondaggio sarà presto conosciuto.

The result of the poll will be known soon.

Choices: i / la / lo / Il

[[Italian#^it-Q0014-answer|Compare the answer]]
^it-Q0014

**it-Q0015 · Edit the changed sentence**

Potete aggiornare 【lo】 nostro software?

Can you update our software?

[[Italian#^it-Q0015-answer|Compare the answer]]
^it-Q0015

**it-Q0016 · Build the sentence**

Arrange: aggiornare / Potete / il / software? / nostro

Can you update our software?

[[Italian#^it-Q0016-answer|Compare the answer]]
^it-Q0016

**it-Q0017 · Write a translation**

Write this in Italian: Turn in your test papers.

[[Italian#^it-Q0017-answer|Compare the answer]]
^it-Q0017

**it-Q0018 · Explain the grammar**

Consegni 【i】 suoi fogli del test.

Turn in your test papers.

[[Italian#^it-Q0018-answer|Compare the answer]]
^it-Q0018

**it-Q0019 · Fill the gap**

____ poliziotto mi ha accusato di avere ignorato le regole del traffico.

The policeman blamed me for ignoring traffic rules.

[[Italian#^it-Q0019-answer|Compare the answer]]
^it-Q0019

**it-Q0020 · Choose the form**

____ poliziotto mi ha accusato di avere ignorato le regole del traffico.

The policeman blamed me for ignoring traffic rules.

Choices: Il / lo / la / i

[[Italian#^it-Q0020-answer|Compare the answer]]
^it-Q0020

**it-Q0021 · Edit the changed sentence**

【il】 mia camera è un po' in disordine.

My room's a little messy.

[[Italian#^it-Q0021-answer|Compare the answer]]
^it-Q0021

**it-Q0022 · Build the sentence**

Arrange: La / un / disordine. / è / po' / mia / camera / in

My room's a little messy.

[[Italian#^it-Q0022-answer|Compare the answer]]
^it-Q0022

**it-Q0023 · Write a translation**

Write this in Italian: Only your project matters.

[[Italian#^it-Q0023-answer|Compare the answer]]
^it-Q0023

**it-Q0024 · Explain the grammar**

Solamente 【il】 suo progetto conta.

Only your project matters.

[[Italian#^it-Q0024-answer|Compare the answer]]
^it-Q0024

**it-Q0025 · Fill the gap**

Hai alzato ____ sguardo, vero?

You looked up, didn't you?

[[Italian#^it-Q0025-answer|Compare the answer]]
^it-Q0025

**it-Q0026 · Choose the form**

Hai alzato ____ sguardo, vero?

You looked up, didn't you?

Choices: lo / la / il / i

[[Italian#^it-Q0026-answer|Compare the answer]]
^it-Q0026

**it-Q0027 · Edit the changed sentence**

Nessun altro 【il】 aiuterebbe.

Nobody else would help them.

[[Italian#^it-Q0027-answer|Compare the answer]]
^it-Q0027

**it-Q0028 · Build the sentence**

Arrange: altro / Nessun / le / aiuterebbe.

Nobody else would help them.

[[Italian#^it-Q0028-answer|Compare the answer]]
^it-Q0028

**it-Q0029 · Write a translation**

Write this in Italian: My mother does a laundry every day.

[[Italian#^it-Q0029-answer|Compare the answer]]
^it-Q0029

**it-Q0030 · Explain the grammar**

Mia madre fa 【il】 bucato ogni giorno.

My mother does a laundry every day.

[[Italian#^it-Q0030-answer|Compare the answer]]
^it-Q0030

**it-Q0031 · Fill the gap**

____ pizza sarà qua tra cinque minuti.

The pizza will be here in five minutes.

[[Italian#^it-Q0031-answer|Compare the answer]]
^it-Q0031

**it-Q0032 · Choose the form**

____ pizza sarà qua tra cinque minuti.

The pizza will be here in five minutes.

Choices: i / lo / La / il

[[Italian#^it-Q0032-answer|Compare the answer]]
^it-Q0032

**it-Q0033 · Edit the changed sentence**

Tom è 【lo】 mio operaio migliore.

Tom is my best worker.

[[Italian#^it-Q0033-answer|Compare the answer]]
^it-Q0033

**it-Q0034 · Build the sentence**

Arrange: operaio / è / migliore. / mio / Tom / il

Tom is my best worker.

[[Italian#^it-Q0034-answer|Compare the answer]]
^it-Q0034

**it-Q0035 · Write a translation**

Write this in Italian: Tom says he hopes that Mary does that.

[[Italian#^it-Q0035-answer|Compare the answer]]
^it-Q0035

**it-Q0036 · Explain the grammar**

Tom dice che spera che Mary 【lo】 faccia.

Tom says he hopes that Mary does that.

[[Italian#^it-Q0036-answer|Compare the answer]]
^it-Q0036

**it-Q0037 · Fill the gap**

Per piacere, mi spiegherà ____ significato di questa frase?

Will you please explain the meaning of this sentence to me?

[[Italian#^it-Q0037-answer|Compare the answer]]
^it-Q0037

**it-Q0038 · Choose the form**

Per piacere, mi spiegherà ____ significato di questa frase?

Will you please explain the meaning of this sentence to me?

Choices: la / i / il / lo

[[Italian#^it-Q0038-answer|Compare the answer]]
^it-Q0038

**it-Q0039 · Edit the changed sentence**

Sono sotto 【il】 doccia.

They're in the shower.

[[Italian#^it-Q0039-answer|Compare the answer]]
^it-Q0039

**it-Q0040 · Build the sentence**

Arrange: Sono / la / sotto / doccia.

They're in the shower.

[[Italian#^it-Q0040-answer|Compare the answer]]
^it-Q0040

**it-Q0041 · Write a translation**

Write this in Italian: Sami is the clown of the family.

[[Italian#^it-Q0041-answer|Compare the answer]]
^it-Q0041

**it-Q0042 · Explain the grammar**

Sami è 【il】 pagliaccio della famiglia.

Sami is the clown of the family.

[[Italian#^it-Q0042-answer|Compare the answer]]
^it-Q0042

**it-Q0043 · Fill the gap**

Vuole scambiare ____ nostre due pecore una per l'altra?

Do you want to trade our two sheep, one for another?

[[Italian#^it-Q0043-answer|Compare the answer]]
^it-Q0043

**it-Q0044 · Choose the form**

Vuole scambiare ____ nostre due pecore una per l'altra?

Do you want to trade our two sheep, one for another?

Choices: le / lo / la / il

[[Italian#^it-Q0044-answer|Compare the answer]]
^it-Q0044

**it-Q0045 · Edit the changed sentence**

【il】 dia le corna.

Give him the horns.

[[Italian#^it-Q0045-answer|Compare the answer]]
^it-Q0045

**it-Q0046 · Build the sentence**

Arrange: Gli / le / corna. / dia

Give him the horns.

[[Italian#^it-Q0046-answer|Compare the answer]]
^it-Q0046

**it-Q0047 · Write a translation**

Write this in Italian: He did not stop his car at the red light.

[[Italian#^it-Q0047-answer|Compare the answer]]
^it-Q0047

**it-Q0048 · Explain the grammar**

Lui non fermò 【la】 macchina al semaforo rosso.

He did not stop his car at the red light.

[[Italian#^it-Q0048-answer|Compare the answer]]
^it-Q0048

**it-Q0049 · Fill the gap**

A Sami non piacciono ____ cani.

Sami doesn't like dogs.

[[Italian#^it-Q0049-answer|Compare the answer]]
^it-Q0049

**it-Q0050 · Choose the form**

A Sami non piacciono ____ cani.

Sami doesn't like dogs.

Choices: il / i / lo / la

[[Italian#^it-Q0050-answer|Compare the answer]]
^it-Q0050


### Indefinite articles · 50 questions

**it-Q0051 · Edit the changed sentence**

Non sono 【un】 spiona.

I'm not a tattletale.

[[Italian#^it-Q0051-answer|Compare the answer]]
^it-Q0051

**it-Q0052 · Build the sentence**

Arrange: spiona. / una / sono / Non

I'm not a tattletale.

[[Italian#^it-Q0052-answer|Compare the answer]]
^it-Q0052

**it-Q0053 · Write a translation**

Write this in Italian: You're going to need an alibi.

[[Italian#^it-Q0053-answer|Compare the answer]]
^it-Q0053

**it-Q0054 · Explain the grammar**

A voi servirà 【un】 alibi.

You're going to need an alibi.

[[Italian#^it-Q0054-answer|Compare the answer]]
^it-Q0054

**it-Q0055 · Fill the gap**

Sembra ____ po' depressa.

You seem a bit depressed.

[[Italian#^it-Q0055-answer|Compare the answer]]
^it-Q0055

**it-Q0056 · Choose the form**

Sembra ____ po' depressa.

You seem a bit depressed.

Choices: un / uno / una

[[Italian#^it-Q0056-answer|Compare the answer]]
^it-Q0056

**it-Q0057 · Edit the changed sentence**

Pensavo lui fosse 【un】 donna.

I thought he was a woman.

[[Italian#^it-Q0057-answer|Compare the answer]]
^it-Q0057

**it-Q0058 · Build the sentence**

Arrange: una / donna. / fosse / Pensavo / lui

I thought he was a woman.

[[Italian#^it-Q0058-answer|Compare the answer]]
^it-Q0058

**it-Q0059 · Write a translation**

Write this in Italian: That man is a famous cabaret performer.

[[Italian#^it-Q0059-answer|Compare the answer]]
^it-Q0059

**it-Q0060 · Explain the grammar**

Quell'uomo è 【un】 celebre cabarettista.

That man is a famous cabaret performer.

[[Italian#^it-Q0060-answer|Compare the answer]]
^it-Q0060

**it-Q0061 · Fill the gap**

Lui ha ____ mente nobile.

He has a noble mind.

[[Italian#^it-Q0061-answer|Compare the answer]]
^it-Q0061

**it-Q0062 · Choose the form**

Lui ha ____ mente nobile.

He has a noble mind.

Choices: una / un / uno

[[Italian#^it-Q0062-answer|Compare the answer]]
^it-Q0062

**it-Q0063 · Edit the changed sentence**

Sei 【uno】 dottore.

You are a doctor.

[[Italian#^it-Q0063-answer|Compare the answer]]
^it-Q0063

**it-Q0064 · Build the sentence**

Arrange: un / Sei / dottore.

You are a doctor.

[[Italian#^it-Q0064-answer|Compare the answer]]
^it-Q0064

**it-Q0065 · Write a translation**

Write this in Italian: Tom ate a late breakfast.

[[Italian#^it-Q0065-answer|Compare the answer]]
^it-Q0065

**it-Q0066 · Explain the grammar**

Tom ha mangiato 【una】 tarda colazione.

Tom ate a late breakfast.

[[Italian#^it-Q0066-answer|Compare the answer]]
^it-Q0066

**it-Q0067 · Fill the gap**

Per alcune espressioni, non è così facile trovare ____ traduzione appropriata.

For some expressions, it's not so easy to find an appropriate translation.

[[Italian#^it-Q0067-answer|Compare the answer]]
^it-Q0067

**it-Q0068 · Choose the form**

Per alcune espressioni, non è così facile trovare ____ traduzione appropriata.

For some expressions, it's not so easy to find an appropriate translation.

Choices: un / una / uno

[[Italian#^it-Q0068-answer|Compare the answer]]
^it-Q0068

**it-Q0069 · Edit the changed sentence**

È 【un】 bella storia. L'unico problema è che non è vera.

That's a good story. The only problem is that it's not true.

[[Italian#^it-Q0069-answer|Compare the answer]]
^it-Q0069

**it-Q0070 · Build the sentence**

Arrange: È / una / bella / problema / non / vera. / che / storia. / è / L'unico / è

That's a good story. The only problem is that it's not true.

[[Italian#^it-Q0070-answer|Compare the answer]]
^it-Q0070

**it-Q0071 · Write a translation**

Write this in Italian: I've never fallen in love with a girl.

[[Italian#^it-Q0071-answer|Compare the answer]]
^it-Q0071

**it-Q0072 · Explain the grammar**

Non mi sono mai innamorata di 【una】 ragazza.

I've never fallen in love with a girl.

[[Italian#^it-Q0072-answer|Compare the answer]]
^it-Q0072

**it-Q0073 · Fill the gap**

____ vecchia signora è morta bruciata.

An old woman was burnt to death.

[[Italian#^it-Q0073-answer|Compare the answer]]
^it-Q0073

**it-Q0074 · Choose the form**

____ vecchia signora è morta bruciata.

An old woman was burnt to death.

Choices: uno / Una / un

[[Italian#^it-Q0074-answer|Compare the answer]]
^it-Q0074

**it-Q0075 · Edit the changed sentence**

Prenda 【uno】 po' di eggnog.

Have some eggnog.

[[Italian#^it-Q0075-answer|Compare the answer]]
^it-Q0075

**it-Q0076 · Build the sentence**

Arrange: un / eggnog. / po' / Prenda / di

Have some eggnog.

[[Italian#^it-Q0076-answer|Compare the answer]]
^it-Q0076

**it-Q0077 · Write a translation**

Write this in Italian: Tom has done a really good job.

[[Italian#^it-Q0077-answer|Compare the answer]]
^it-Q0077

**it-Q0078 · Explain the grammar**

Tom ha fatto 【un】 lavoro veramente buono.

Tom has done a really good job.

[[Italian#^it-Q0078-answer|Compare the answer]]
^it-Q0078

**it-Q0079 · Fill the gap**

Tom fece ____ lavoro fantastico.

Tom did a fantastic job.

[[Italian#^it-Q0079-answer|Compare the answer]]
^it-Q0079

**it-Q0080 · Choose the form**

Tom fece ____ lavoro fantastico.

Tom did a fantastic job.

Choices: una / uno / un

[[Italian#^it-Q0080-answer|Compare the answer]]
^it-Q0080

**it-Q0081 · Edit the changed sentence**

Voglio 【uno】 telefono cellulare.

I want a cellular phone.

[[Italian#^it-Q0081-answer|Compare the answer]]
^it-Q0081

**it-Q0082 · Build the sentence**

Arrange: un / Voglio / cellulare. / telefono

I want a cellular phone.

[[Italian#^it-Q0082-answer|Compare the answer]]
^it-Q0082

**it-Q0083 · Write a translation**

Write this in Italian: For a start, I visited Jerusalem - a sacred place for three major religions.

[[Italian#^it-Q0083-answer|Compare the answer]]
^it-Q0083

**it-Q0084 · Explain the grammar**

Come inizio ho visitato Gerusalemme - 【un】 luogo sacro per tre religioni principali.

For a start, I visited Jerusalem - a sacred place for three major religions.

[[Italian#^it-Q0084-answer|Compare the answer]]
^it-Q0084

**it-Q0085 · Fill the gap**

Tom ha chiesto ____ salario più alto.

Tom asked for a higher salary.

[[Italian#^it-Q0085-answer|Compare the answer]]
^it-Q0085

**it-Q0086 · Choose the form**

Tom ha chiesto ____ salario più alto.

Tom asked for a higher salary.

Choices: uno / un / una

[[Italian#^it-Q0086-answer|Compare the answer]]
^it-Q0086

**it-Q0087 · Edit the changed sentence**

Io sto sperando in 【un】 sconto veramente grande.

I'm hoping for a really big discount.

[[Italian#^it-Q0087-answer|Compare the answer]]
^it-Q0087

**it-Q0088 · Build the sentence**

Arrange: uno / in / sconto / grande. / veramente / Io / sperando / sto

I'm hoping for a really big discount.

[[Italian#^it-Q0088-answer|Compare the answer]]
^it-Q0088

**it-Q0089 · Write a translation**

Write this in Italian: Tatoeba: Got a PM? You're probably in trouble...

[[Italian#^it-Q0089-answer|Compare the answer]]
^it-Q0089

**it-Q0090 · Explain the grammar**

Tatoeba: Ricevuto 【un】 messaggio privato? Probabilmente è nei guai...

Tatoeba: Got a PM? You're probably in trouble...

[[Italian#^it-Q0090-answer|Compare the answer]]
^it-Q0090

**it-Q0091 · Fill the gap**

Io penso che questo sarà ____ regalo carino.

I think this will make a nice gift.

[[Italian#^it-Q0091-answer|Compare the answer]]
^it-Q0091

**it-Q0092 · Choose the form**

Io penso che questo sarà ____ regalo carino.

I think this will make a nice gift.

Choices: un / una / uno

[[Italian#^it-Q0092-answer|Compare the answer]]
^it-Q0092

**it-Q0093 · Edit the changed sentence**

Ne vorreste 【un】 ora?

Would you like one now?

[[Italian#^it-Q0093-answer|Compare the answer]]
^it-Q0093

**it-Q0094 · Build the sentence**

Arrange: ora? / Ne / vorreste / uno

Would you like one now?

[[Italian#^it-Q0094-answer|Compare the answer]]
^it-Q0094

**it-Q0095 · Write a translation**

Write this in Italian: He spent the evening reading a book.

[[Italian#^it-Q0095-answer|Compare the answer]]
^it-Q0095

**it-Q0096 · Explain the grammar**

Lui ha passato la serata a leggere 【un】 libro.

He spent the evening reading a book.

[[Italian#^it-Q0096-answer|Compare the answer]]
^it-Q0096

**it-Q0097 · Fill the gap**

Noi avevamo ____ buona opinione di vostro figlio.

We had a good opinion of your son.

[[Italian#^it-Q0097-answer|Compare the answer]]
^it-Q0097

**it-Q0098 · Choose the form**

Noi avevamo ____ buona opinione di vostro figlio.

We had a good opinion of your son.

Choices: una / un / uno

[[Italian#^it-Q0098-answer|Compare the answer]]
^it-Q0098

**it-Q0099 · Edit the changed sentence**

Tom sembra 【uno】 po' più felice.

Tom is looking a bit happier.

[[Italian#^it-Q0099-answer|Compare the answer]]
^it-Q0099

**it-Q0100 · Build the sentence**

Arrange: Tom / felice. / sembra / più / po' / un

Tom is looking a bit happier.

[[Italian#^it-Q0100-answer|Compare the answer]]
^it-Q0100


### Articulated prepositions · 50 questions

**it-Q0101 · Write a translation**

Write this in Italian: Children like playing more than studying.

[[Italian#^it-Q0101-answer|Compare the answer]]
^it-Q0101

**it-Q0102 · Explain the grammar**

【Ai】 bambini piace più giocare che studiare.

Children like playing more than studying.

[[Italian#^it-Q0102-answer|Compare the answer]]
^it-Q0102

**it-Q0103 · Fill the gap**

Da quale parte ____ Canada venite?

Where in Canada are you from?

[[Italian#^it-Q0103-answer|Compare the answer]]
^it-Q0103

**it-Q0104 · Choose the form**

Da quale parte ____ Canada venite?

Where in Canada are you from?

Choices: alla / del / al / della

[[Italian#^it-Q0104-answer|Compare the answer]]
^it-Q0104

**it-Q0105 · Edit the changed sentence**

A me serve 【della】 ghiaccio.

I need ice.

[[Italian#^it-Q0105-answer|Compare the answer]]
^it-Q0105

**it-Q0106 · Build the sentence**

Arrange: me / serve / A / ghiaccio. / del

I need ice.

[[Italian#^it-Q0106-answer|Compare the answer]]
^it-Q0106

**it-Q0107 · Write a translation**

Write this in Italian: I'm allergic to priests and religion.

[[Italian#^it-Q0107-answer|Compare the answer]]
^it-Q0107

**it-Q0108 · Explain the grammar**

Sono allergica 【ai】 preti e alla religione.

I'm allergic to priests and religion.

[[Italian#^it-Q0108-answer|Compare the answer]]
^it-Q0108

**it-Q0109 · Fill the gap**

Non avvantaggiarti delle debolezze ____ altri.

Don't take advantage of others' weakness.

[[Italian#^it-Q0109-answer|Compare the answer]]
^it-Q0109

**it-Q0110 · Choose the form**

Non avvantaggiarti delle debolezze ____ altri.

Don't take advantage of others' weakness.

Choices: degli / della / al / del

[[Italian#^it-Q0110-answer|Compare the answer]]
^it-Q0110

**it-Q0111 · Edit the changed sentence**

Tom parlò 【della】 problema con Mary.

Tom spoke about the problem with Mary.

[[Italian#^it-Q0111-answer|Compare the answer]]
^it-Q0111

**it-Q0112 · Build the sentence**

Arrange: parlò / Mary. / problema / del / con / Tom

Tom spoke about the problem with Mary.

[[Italian#^it-Q0112-answer|Compare the answer]]
^it-Q0112

**it-Q0113 · Write a translation**

Write this in Italian: He paid as much as a million dollars for the painting.

[[Italian#^it-Q0113-answer|Compare the answer]]
^it-Q0113

**it-Q0114 · Explain the grammar**

Ha pagato 【dei】 milioni di dollari per il dipinto.

He paid as much as a million dollars for the painting.

[[Italian#^it-Q0114-answer|Compare the answer]]
^it-Q0114

**it-Q0115 · Fill the gap**

Il ragazzo dorme ____ salotto.

The boy sleeps in the living room.

[[Italian#^it-Q0115-answer|Compare the answer]]
^it-Q0115

**it-Q0116 · Choose the form**

Il ragazzo dorme ____ salotto.

The boy sleeps in the living room.

Choices: della / al / del / nel

[[Italian#^it-Q0116-answer|Compare the answer]]
^it-Q0116

**it-Q0117 · Edit the changed sentence**

Io non ti voglio 【del】 mia auto.

I don't want you in my car.

[[Italian#^it-Q0117-answer|Compare the answer]]
^it-Q0117

**it-Q0118 · Build the sentence**

Arrange: mia / auto. / voglio / non / ti / nella / Io

I don't want you in my car.

[[Italian#^it-Q0118-answer|Compare the answer]]
^it-Q0118

**it-Q0119 · Write a translation**

Write this in Italian: I played video games after I finished my homework.

[[Italian#^it-Q0119-answer|Compare the answer]]
^it-Q0119

**it-Q0120 · Explain the grammar**

Io giocai 【ai】 videogiochi dopo aver finito i compiti.

I played video games after I finished my homework.

[[Italian#^it-Q0120-answer|Compare the answer]]
^it-Q0120

**it-Q0121 · Fill the gap**

Sarò felice di partecipare ____ tua festa.

I will be happy to attend your party.

[[Italian#^it-Q0121-answer|Compare the answer]]
^it-Q0121

**it-Q0122 · Choose the form**

Sarò felice di partecipare ____ tua festa.

I will be happy to attend your party.

Choices: al / alla / del / della

[[Italian#^it-Q0122-answer|Compare the answer]]
^it-Q0122

**it-Q0123 · Edit the changed sentence**

Gli immigrati entrarono 【del】 paese in un flusso costante.

The immigrants entered the country in a steady flow.

[[Italian#^it-Q0123-answer|Compare the answer]]
^it-Q0123

**it-Q0124 · Build the sentence**

Arrange: immigrati / entrarono / flusso / nel / Gli / in / costante. / paese / un

The immigrants entered the country in a steady flow.

[[Italian#^it-Q0124-answer|Compare the answer]]
^it-Q0124

**it-Q0125 · Write a translation**

Write this in Italian: The spring in my watch is broken.

[[Italian#^it-Q0125-answer|Compare the answer]]
^it-Q0125

**it-Q0126 · Explain the grammar**

La molla 【nel】 mio orologio è rotta.

The spring in my watch is broken.

[[Italian#^it-Q0126-answer|Compare the answer]]
^it-Q0126

**it-Q0127 · Fill the gap**

La voglio ____ mio ufficio.

I want it in my office.

[[Italian#^it-Q0127-answer|Compare the answer]]
^it-Q0127

**it-Q0128 · Choose the form**

La voglio ____ mio ufficio.

I want it in my office.

Choices: nel / della / del / al

[[Italian#^it-Q0128-answer|Compare the answer]]
^it-Q0128

**it-Q0129 · Edit the changed sentence**

Io non sarei dovuta andare a casa da sola tardi 【del】 notte.

I shouldn't have gone home late at night by myself.

[[Italian#^it-Q0129-answer|Compare the answer]]
^it-Q0129

**it-Q0130 · Build the sentence**

Arrange: dovuta / a / tardi / andare / casa / non / Io / da / sarei / alla / notte. / sola

I shouldn't have gone home late at night by myself.

[[Italian#^it-Q0130-answer|Compare the answer]]
^it-Q0130

**it-Q0131 · Write a translation**

Write this in Italian: Why did you lie about your age?

[[Italian#^it-Q0131-answer|Compare the answer]]
^it-Q0131

**it-Q0132 · Explain the grammar**

Perché hai mentito 【sulla】 tua età?

Why did you lie about your age?

[[Italian#^it-Q0132-answer|Compare the answer]]
^it-Q0132

**it-Q0133 · Fill the gap**

Questo cappello si abbina bene ____ vestito.

This hat goes together with the dress.

[[Italian#^it-Q0133-answer|Compare the answer]]
^it-Q0133

**it-Q0134 · Choose the form**

Questo cappello si abbina bene ____ vestito.

This hat goes together with the dress.

Choices: alla / della / del / al

[[Italian#^it-Q0134-answer|Compare the answer]]
^it-Q0134

**it-Q0135 · Edit the changed sentence**

Mi potete dire come arrivare 【del】 stazione?

Can you tell me how to get to the station?

[[Italian#^it-Q0135-answer|Compare the answer]]
^it-Q0135

**it-Q0136 · Build the sentence**

Arrange: come / alla / potete / stazione? / Mi / arrivare / dire

Can you tell me how to get to the station?

[[Italian#^it-Q0136-answer|Compare the answer]]
^it-Q0136

**it-Q0137 · Write a translation**

Write this in Italian: You should be ashamed of your ignorance.

[[Italian#^it-Q0137-answer|Compare the answer]]
^it-Q0137

**it-Q0138 · Explain the grammar**

Dovrebbe vergognarsi 【della】 sua ignoranza.

You should be ashamed of your ignorance.

[[Italian#^it-Q0138-answer|Compare the answer]]
^it-Q0138

**it-Q0139 · Fill the gap**

Il Giappone voleva il controllo ____ Manciuria.

Japan wanted control of Manchuria.

[[Italian#^it-Q0139-answer|Compare the answer]]
^it-Q0139

**it-Q0140 · Choose the form**

Il Giappone voleva il controllo ____ Manciuria.

Japan wanted control of Manchuria.

Choices: del / al / alla / della

[[Italian#^it-Q0140-answer|Compare the answer]]
^it-Q0140

**it-Q0141 · Edit the changed sentence**

Sto studiando inglese 【del】 mia stanza.

I am studying English in my room.

[[Italian#^it-Q0141-answer|Compare the answer]]
^it-Q0141

**it-Q0142 · Build the sentence**

Arrange: nella / Sto / stanza. / inglese / studiando / mia

I am studying English in my room.

[[Italian#^it-Q0142-answer|Compare the answer]]
^it-Q0142

**it-Q0143 · Write a translation**

Write this in Italian: The lion is the king of beasts.

[[Italian#^it-Q0143-answer|Compare the answer]]
^it-Q0143

**it-Q0144 · Explain the grammar**

Il leone è il re 【degli】 animali.

The lion is the king of beasts.

[[Italian#^it-Q0144-answer|Compare the answer]]
^it-Q0144

**it-Q0145 · Fill the gap**

È cresciuto ____ povertà.

He grew up in poverty.

[[Italian#^it-Q0145-answer|Compare the answer]]
^it-Q0145

**it-Q0146 · Choose the form**

È cresciuto ____ povertà.

He grew up in poverty.

Choices: del / al / della / nella

[[Italian#^it-Q0146-answer|Compare the answer]]
^it-Q0146

**it-Q0147 · Edit the changed sentence**

Perché date 【del】 soldi a Tom?

Why do you give money to Tom?

[[Italian#^it-Q0147-answer|Compare the answer]]
^it-Q0147

**it-Q0148 · Build the sentence**

Arrange: Tom? / dei / soldi / a / date / Perché

Why do you give money to Tom?

[[Italian#^it-Q0148-answer|Compare the answer]]
^it-Q0148

**it-Q0149 · Write a translation**

Write this in Italian: They brought umbrellas.

[[Italian#^it-Q0149-answer|Compare the answer]]
^it-Q0149

**it-Q0150 · Explain the grammar**

Hanno comprato 【degli】 ombrelli.

They brought umbrellas.

[[Italian#^it-Q0150-answer|Compare the answer]]
^it-Q0150


### Essere in the present · 50 questions

**it-Q0151 · Fill the gap**

So che Tom ____ ricco.

I know Tom is wealthy.

[[Italian#^it-Q0151-answer|Compare the answer]]
^it-Q0151

**it-Q0152 · Choose the form**

So che Tom ____ ricco.

I know Tom is wealthy.

Choices: è / sono / sei / siamo

[[Italian#^it-Q0152-answer|Compare the answer]]
^it-Q0152

**it-Q0153 · Edit the changed sentence**

【sono】 state in grado di parlare con lui?

Were you able to talk to him?

[[Italian#^it-Q0153-answer|Compare the answer]]
^it-Q0153

**it-Q0154 · Build the sentence**

Arrange: in / Siete / state / parlare / lui? / con / di / grado

Were you able to talk to him?

[[Italian#^it-Q0154-answer|Compare the answer]]
^it-Q0154

**it-Q0155 · Write a translation**

Write this in Italian: I was born to make you happy.

[[Italian#^it-Q0155-answer|Compare the answer]]
^it-Q0155

**it-Q0156 · Explain the grammar**

Io 【sono】 nata per renderti felice.

I was born to make you happy.

[[Italian#^it-Q0156-answer|Compare the answer]]
^it-Q0156

**it-Q0157 · Fill the gap**

Non ____ niente di straordinario.

It's nothing extraordinary.

[[Italian#^it-Q0157-answer|Compare the answer]]
^it-Q0157

**it-Q0158 · Choose the form**

Non ____ niente di straordinario.

It's nothing extraordinary.

Choices: sei / siamo / è / sono

[[Italian#^it-Q0158-answer|Compare the answer]]
^it-Q0158

**it-Q0159 · Edit the changed sentence**

Tom 【sono】 diabetico.

Tom's diabetic.

[[Italian#^it-Q0159-answer|Compare the answer]]
^it-Q0159

**it-Q0160 · Build the sentence**

Arrange: diabetico. / Tom / è

Tom's diabetic.

[[Italian#^it-Q0160-answer|Compare the answer]]
^it-Q0160

**it-Q0161 · Write a translation**

Write this in Italian: Why are you not satisfied?

[[Italian#^it-Q0161-answer|Compare the answer]]
^it-Q0161

**it-Q0162 · Explain the grammar**

Perché non 【è】 soddisfatta?

Why are you not satisfied?

[[Italian#^it-Q0162-answer|Compare the answer]]
^it-Q0162

**it-Q0163 · Fill the gap**

____ molto meglio di quanto non fosse cinque anni fa.

He is far better off than he was five years ago.

[[Italian#^it-Q0163-answer|Compare the answer]]
^it-Q0163

**it-Q0164 · Choose the form**

____ molto meglio di quanto non fosse cinque anni fa.

He is far better off than he was five years ago.

Choices: È / sei / sono / siamo

[[Italian#^it-Q0164-answer|Compare the answer]]
^it-Q0164

**it-Q0165 · Edit the changed sentence**

Sami 【sono】 ritornato dal Cairo.

Sami returned from Cairo.

[[Italian#^it-Q0165-answer|Compare the answer]]
^it-Q0165

**it-Q0166 · Build the sentence**

Arrange: dal / è / Cairo. / ritornato / Sami

Sami returned from Cairo.

[[Italian#^it-Q0166-answer|Compare the answer]]
^it-Q0166

**it-Q0167 · Write a translation**

Write this in Italian: Tom is eccentric, isn't he?

[[Italian#^it-Q0167-answer|Compare the answer]]
^it-Q0167

**it-Q0168 · Explain the grammar**

Tom 【è】 eccentrico, vero?

Tom is eccentric, isn't he?

[[Italian#^it-Q0168-answer|Compare the answer]]
^it-Q0168

**it-Q0169 · Fill the gap**

Tom e Mary ____ stati sposati per tre anni.

Tom and Mary have been married three years.

[[Italian#^it-Q0169-answer|Compare the answer]]
^it-Q0169

**it-Q0170 · Choose the form**

Tom e Mary ____ stati sposati per tre anni.

Tom and Mary have been married three years.

Choices: siamo / sei / sono / è

[[Italian#^it-Q0170-answer|Compare the answer]]
^it-Q0170

**it-Q0171 · Edit the changed sentence**

Nulla 【sono】 gratuito.

Nothing's free.

[[Italian#^it-Q0171-answer|Compare the answer]]
^it-Q0171

**it-Q0172 · Build the sentence**

Arrange: è / gratuito. / Nulla

Nothing's free.

[[Italian#^it-Q0172-answer|Compare the answer]]
^it-Q0172

**it-Q0173 · Write a translation**

Write this in Italian: I'm busy tonight.

[[Italian#^it-Q0173-answer|Compare the answer]]
^it-Q0173

**it-Q0174 · Explain the grammar**

【Sono】 impegnato questa notte.

I'm busy tonight.

[[Italian#^it-Q0174-answer|Compare the answer]]
^it-Q0174

**it-Q0175 · Fill the gap**

Tom si ____ laureato.

Tom graduated.

[[Italian#^it-Q0175-answer|Compare the answer]]
^it-Q0175

**it-Q0176 · Choose the form**

Tom si ____ laureato.

Tom graduated.

Choices: siamo / è / sei / sono

[[Italian#^it-Q0176-answer|Compare the answer]]
^it-Q0176

**it-Q0177 · Edit the changed sentence**

Tom 【sono】 metodico, vero?

Tom is methodical, isn't he?

[[Italian#^it-Q0177-answer|Compare the answer]]
^it-Q0177

**it-Q0178 · Build the sentence**

Arrange: vero? / è / Tom / metodico,

Tom is methodical, isn't he?

[[Italian#^it-Q0178-answer|Compare the answer]]
^it-Q0178

**it-Q0179 · Write a translation**

Write this in Italian: He's very fast, isn't he?

[[Italian#^it-Q0179-answer|Compare the answer]]
^it-Q0179

**it-Q0180 · Explain the grammar**

【È】 molto veloce, vero?

He's very fast, isn't he?

[[Italian#^it-Q0180-answer|Compare the answer]]
^it-Q0180

**it-Q0181 · Fill the gap**

C'____ qualcosa da mangiare?

Is there anything to eat?

[[Italian#^it-Q0181-answer|Compare the answer]]
^it-Q0181

**it-Q0182 · Choose the form**

C'____ qualcosa da mangiare?

Is there anything to eat?

Choices: siamo / è / sei / sono

[[Italian#^it-Q0182-answer|Compare the answer]]
^it-Q0182

**it-Q0183 · Edit the changed sentence**

Non 【sei】 fortunata come te.

I'm not as lucky as you.

[[Italian#^it-Q0183-answer|Compare the answer]]
^it-Q0183

**it-Q0184 · Build the sentence**

Arrange: Non / come / fortunata / sono / te.

I'm not as lucky as you.

[[Italian#^it-Q0184-answer|Compare the answer]]
^it-Q0184

**it-Q0185 · Write a translation**

Write this in Italian: I am so lonely.

[[Italian#^it-Q0185-answer|Compare the answer]]
^it-Q0185

**it-Q0186 · Explain the grammar**

【Sono】 così solo.

I am so lonely.

[[Italian#^it-Q0186-answer|Compare the answer]]
^it-Q0186

**it-Q0187 · Fill the gap**

____ andata via liscia.

It went off smoothly.

[[Italian#^it-Q0187-answer|Compare the answer]]
^it-Q0187

**it-Q0188 · Choose the form**

____ andata via liscia.

It went off smoothly.

Choices: È / sono / sei / siamo

[[Italian#^it-Q0188-answer|Compare the answer]]
^it-Q0188

**it-Q0189 · Edit the changed sentence**

Lei 【sono】 impegnata adesso, quindi non riesce a parlare con voi.

She's busy now, so she can't talk with you.

[[Italian#^it-Q0189-answer|Compare the answer]]
^it-Q0189

**it-Q0190 · Build the sentence**

Arrange: non / Lei / con / riesce / parlare / è / a / impegnata / quindi / voi. / adesso,

She's busy now, so she can't talk with you.

[[Italian#^it-Q0190-answer|Compare the answer]]
^it-Q0190

**it-Q0191 · Write a translation**

Write this in Italian: I'm almost as tall as my father.

[[Italian#^it-Q0191-answer|Compare the answer]]
^it-Q0191

**it-Q0192 · Explain the grammar**

【Sono】 quasi alta come mio padre.

I'm almost as tall as my father.

[[Italian#^it-Q0192-answer|Compare the answer]]
^it-Q0192

**it-Q0193 · Fill the gap**

Tom e Mary ____ là.

Tom and Mary are there.

[[Italian#^it-Q0193-answer|Compare the answer]]
^it-Q0193

**it-Q0194 · Choose the form**

Tom e Mary ____ là.

Tom and Mary are there.

Choices: sono / siamo / sei / è

[[Italian#^it-Q0194-answer|Compare the answer]]
^it-Q0194

**it-Q0195 · Edit the changed sentence**

Tom non 【sono】 comunista.

Tom isn't a communist.

[[Italian#^it-Q0195-answer|Compare the answer]]
^it-Q0195

**it-Q0196 · Build the sentence**

Arrange: Tom / è / comunista. / non

Tom isn't a communist.

[[Italian#^it-Q0196-answer|Compare the answer]]
^it-Q0196

**it-Q0197 · Write a translation**

Write this in Italian: What did we miss?

[[Italian#^it-Q0197-answer|Compare the answer]]
^it-Q0197

**it-Q0198 · Explain the grammar**

Che cosa ci 【siamo】 persi?

What did we miss?

[[Italian#^it-Q0198-answer|Compare the answer]]
^it-Q0198

**it-Q0199 · Fill the gap**

Lei ____ stato impegnato, vero?

You've been busy, haven't you?

[[Italian#^it-Q0199-answer|Compare the answer]]
^it-Q0199

**it-Q0200 · Choose the form**

Lei ____ stato impegnato, vero?

You've been busy, haven't you?

Choices: sei / è / sono / siamo

[[Italian#^it-Q0200-answer|Compare the answer]]
^it-Q0200


### Avere in the present · 50 questions

**it-Q0201 · Edit the changed sentence**

Tom 【ho】 rinunciato.

Tom quit.

[[Italian#^it-Q0201-answer|Compare the answer]]
^it-Q0201

**it-Q0202 · Build the sentence**

Arrange: Tom / rinunciato. / ha

Tom quit.

[[Italian#^it-Q0202-answer|Compare the answer]]
^it-Q0202

**it-Q0203 · Write a translation**

Write this in Italian: I saw you kiss him. Do not deny it!

[[Italian#^it-Q0203-answer|Compare the answer]]
^it-Q0203

**it-Q0204 · Explain the grammar**

Ti 【ho】 vista baciarlo. Non negarlo!

I saw you kiss him. Do not deny it!

[[Italian#^it-Q0204-answer|Compare the answer]]
^it-Q0204

**it-Q0205 · Fill the gap**

Lei ____ dello scotch?

Do you have any tape?

[[Italian#^it-Q0205-answer|Compare the answer]]
^it-Q0205

**it-Q0206 · Choose the form**

Lei ____ dello scotch?

Do you have any tape?

Choices: ha / abbiamo / hai / ho

[[Italian#^it-Q0206-answer|Compare the answer]]
^it-Q0206

**it-Q0207 · Edit the changed sentence**

Chi 【ho】 detto a Tom di non baciare Mary?

Who told Tom not to kiss Mary?

[[Italian#^it-Q0207-answer|Compare the answer]]
^it-Q0207

**it-Q0208 · Build the sentence**

Arrange: Mary? / non / detto / Chi / ha / Tom / di / a / baciare

Who told Tom not to kiss Mary?

[[Italian#^it-Q0208-answer|Compare the answer]]
^it-Q0208

**it-Q0209 · Write a translation**

Write this in Italian: Tom doesn't have as much free time as I do.

[[Italian#^it-Q0209-answer|Compare the answer]]
^it-Q0209

**it-Q0210 · Explain the grammar**

Tom non 【ha】 molto tempo libero come me.

Tom doesn't have as much free time as I do.

[[Italian#^it-Q0210-answer|Compare the answer]]
^it-Q0210

**it-Q0211 · Fill the gap**

Lui mi ____ calciato nelle palle.

He kicked me in the balls.

[[Italian#^it-Q0211-answer|Compare the answer]]
^it-Q0211

**it-Q0212 · Choose the form**

Lui mi ____ calciato nelle palle.

He kicked me in the balls.

Choices: ho / ha / abbiamo / hai

[[Italian#^it-Q0212-answer|Compare the answer]]
^it-Q0212

**it-Q0213 · Edit the changed sentence**

Voi 【ho】 ancora paura che possa capitare qualcosa?

Are you still afraid something might happen?

[[Italian#^it-Q0213-answer|Compare the answer]]
^it-Q0213

**it-Q0214 · Build the sentence**

Arrange: che / possa / Voi / capitare / ancora / paura / qualcosa? / avete

Are you still afraid something might happen?

[[Italian#^it-Q0214-answer|Compare the answer]]
^it-Q0214

**it-Q0215 · Write a translation**

Write this in Italian: Tom said that he wasn't done.

[[Italian#^it-Q0215-answer|Compare the answer]]
^it-Q0215

**it-Q0216 · Explain the grammar**

Tom 【ha】 detto che non aveva finito.

Tom said that he wasn't done.

[[Italian#^it-Q0216-answer|Compare the answer]]
^it-Q0216

**it-Q0217 · Fill the gap**

Qualcuno ____ provato a uccidere Tom.

Somebody tried to kill Tom.

[[Italian#^it-Q0217-answer|Compare the answer]]
^it-Q0217

**it-Q0218 · Choose the form**

Qualcuno ____ provato a uccidere Tom.

Somebody tried to kill Tom.

Choices: abbiamo / ha / hai / ho

[[Italian#^it-Q0218-answer|Compare the answer]]
^it-Q0218

**it-Q0219 · Edit the changed sentence**

Dove 【ho】 messo le mie chiavi?

Where did you put my keys?

[[Italian#^it-Q0219-answer|Compare the answer]]
^it-Q0219

**it-Q0220 · Build the sentence**

Arrange: avete / le / mie / messo / chiavi? / Dove

Where did you put my keys?

[[Italian#^it-Q0220-answer|Compare the answer]]
^it-Q0220

**it-Q0221 · Write a translation**

Write this in Italian: I asked Tom to proofread my report.

[[Italian#^it-Q0221-answer|Compare the answer]]
^it-Q0221

**it-Q0222 · Explain the grammar**

【Ho】 chiesto a Tom di controllare il mio rapporto.

I asked Tom to proofread my report.

[[Italian#^it-Q0222-answer|Compare the answer]]
^it-Q0222

**it-Q0223 · Fill the gap**

Tutti l'____ ignorata.

Everyone ignored her.

[[Italian#^it-Q0223-answer|Compare the answer]]
^it-Q0223

**it-Q0224 · Choose the form**

Tutti l'____ ignorata.

Everyone ignored her.

Choices: hanno / hai / ha / ho

[[Italian#^it-Q0224-answer|Compare the answer]]
^it-Q0224

**it-Q0225 · Edit the changed sentence**

Tom non 【ho】 parlato di voi.

Tom didn't talk about you.

[[Italian#^it-Q0225-answer|Compare the answer]]
^it-Q0225

**it-Q0226 · Build the sentence**

Arrange: voi. / ha / parlato / di / Tom / non

Tom didn't talk about you.

[[Italian#^it-Q0226-answer|Compare the answer]]
^it-Q0226

**it-Q0227 · Write a translation**

Write this in Italian: I consented to go.

[[Italian#^it-Q0227-answer|Compare the answer]]
^it-Q0227

**it-Q0228 · Explain the grammar**

【Ho】 acconsentito ad andare.

I consented to go.

[[Italian#^it-Q0228-answer|Compare the answer]]
^it-Q0228

**it-Q0229 · Fill the gap**

Voi ____ già ordinato?

Have you already ordered?

[[Italian#^it-Q0229-answer|Compare the answer]]
^it-Q0229

**it-Q0230 · Choose the form**

Voi ____ già ordinato?

Have you already ordered?

Choices: ha / avete / hai / ho

[[Italian#^it-Q0230-answer|Compare the answer]]
^it-Q0230

**it-Q0231 · Edit the changed sentence**

Noi 【ho】 camminato per diverse miglia.

We walked for miles.

[[Italian#^it-Q0231-answer|Compare the answer]]
^it-Q0231

**it-Q0232 · Build the sentence**

Arrange: diverse / per / Noi / camminato / miglia. / abbiamo

We walked for miles.

[[Italian#^it-Q0232-answer|Compare the answer]]
^it-Q0232

**it-Q0233 · Write a translation**

Write this in Italian: He banged his head.

[[Italian#^it-Q0233-answer|Compare the answer]]
^it-Q0233

**it-Q0234 · Explain the grammar**

【Ha】 battuto la testa.

He banged his head.

[[Italian#^it-Q0234-answer|Compare the answer]]
^it-Q0234

**it-Q0235 · Fill the gap**

Lei l'____ già chiamata?

Have you called her yet?

[[Italian#^it-Q0235-answer|Compare the answer]]
^it-Q0235

**it-Q0236 · Choose the form**

Lei l'____ già chiamata?

Have you called her yet?

Choices: abbiamo / hai / ha / ho

[[Italian#^it-Q0236-answer|Compare the answer]]
^it-Q0236

**it-Q0237 · Edit the changed sentence**

Non è quello che 【ho】 promesso.

That's not what you promised.

[[Italian#^it-Q0237-answer|Compare the answer]]
^it-Q0237

**it-Q0238 · Build the sentence**

Arrange: che / hai / è / quello / promesso. / Non

That's not what you promised.

[[Italian#^it-Q0238-answer|Compare the answer]]
^it-Q0238

**it-Q0239 · Write a translation**

Write this in Italian: He has a few friends.

[[Italian#^it-Q0239-answer|Compare the answer]]
^it-Q0239

**it-Q0240 · Explain the grammar**

【Ha】 qualche amico.

He has a few friends.

[[Italian#^it-Q0240-answer|Compare the answer]]
^it-Q0240

**it-Q0241 · Fill the gap**

Non l'____ mai suggerito.

I never suggested that.

[[Italian#^it-Q0241-answer|Compare the answer]]
^it-Q0241

**it-Q0242 · Choose the form**

Non l'____ mai suggerito.

I never suggested that.

Choices: ha / abbiamo / ho / hai

[[Italian#^it-Q0242-answer|Compare the answer]]
^it-Q0242

**it-Q0243 · Edit the changed sentence**

Non l'【hai】 mai visto qua.

I've never seen him here.

[[Italian#^it-Q0243-answer|Compare the answer]]
^it-Q0243

**it-Q0244 · Build the sentence**

Arrange: mai / Non / qua. / l'ho / visto

I've never seen him here.

[[Italian#^it-Q0244-answer|Compare the answer]]
^it-Q0244

**it-Q0245 · Write a translation**

Write this in Italian: We had to keep it a secret.

[[Italian#^it-Q0245-answer|Compare the answer]]
^it-Q0245

**it-Q0246 · Explain the grammar**

Noi 【abbiamo】 dovuto tenerla segreta.

We had to keep it a secret.

[[Italian#^it-Q0246-answer|Compare the answer]]
^it-Q0246

**it-Q0247 · Fill the gap**

Lei ____ rovinato i suoi vestiti.

She's ruined her clothes.

[[Italian#^it-Q0247-answer|Compare the answer]]
^it-Q0247

**it-Q0248 · Choose the form**

Lei ____ rovinato i suoi vestiti.

She's ruined her clothes.

Choices: hai / abbiamo / ho / ha

[[Italian#^it-Q0248-answer|Compare the answer]]
^it-Q0248

**it-Q0249 · Edit the changed sentence**

Quanti anni 【ho】 i vostri fratelli e sorelle?

How old are your brothers and sisters?

[[Italian#^it-Q0249-answer|Compare the answer]]
^it-Q0249

**it-Q0250 · Build the sentence**

Arrange: Quanti / anni / hanno / e / sorelle? / i / fratelli / vostri

How old are your brothers and sisters?

[[Italian#^it-Q0250-answer|Compare the answer]]
^it-Q0250


### Imperfect perspective · 50 questions

**it-Q0251 · Write a translation**

Write this in Italian: Tom had no money.

[[Italian#^it-Q0251-answer|Compare the answer]]
^it-Q0251

**it-Q0252 · Explain the grammar**

Tom non 【aveva】 denaro.

Tom had no money.

[[Italian#^it-Q0252-answer|Compare the answer]]
^it-Q0252

**it-Q0253 · Fill the gap**

____ troppo lenta.

You were too slow.

[[Italian#^it-Q0253-answer|Compare the answer]]
^it-Q0253

**it-Q0254 · Choose the form**

____ troppo lenta.

You were too slow.

Choices: faceva / erano / aveva / Era

[[Italian#^it-Q0254-answer|Compare the answer]]
^it-Q0254

**it-Q0255 · Edit the changed sentence**

Lui 【era】 aiutare le sue amiche.

He wanted to help his friends.

[[Italian#^it-Q0255-answer|Compare the answer]]
^it-Q0255

**it-Q0256 · Build the sentence**

Arrange: aiutare / sue / le / Lui / voleva / amiche.

He wanted to help his friends.

[[Italian#^it-Q0256-answer|Compare the answer]]
^it-Q0256

**it-Q0257 · Write a translation**

Write this in Italian: Who was responsible?

[[Italian#^it-Q0257-answer|Compare the answer]]
^it-Q0257

**it-Q0258 · Explain the grammar**

Chi 【era】 il responsabile?

Who was responsible?

[[Italian#^it-Q0258-answer|Compare the answer]]
^it-Q0258

**it-Q0259 · Fill the gap**

Il postino ____ di buonumore stamattina.

The postman was in good spirits this morning.

[[Italian#^it-Q0259-answer|Compare the answer]]
^it-Q0259

**it-Q0260 · Choose the form**

Il postino ____ di buonumore stamattina.

The postman was in good spirits this morning.

Choices: faceva / erano / era / aveva

[[Italian#^it-Q0260-answer|Compare the answer]]
^it-Q0260

**it-Q0261 · Edit the changed sentence**

Loro chi 【era】 esattamente?

Who exactly were they?

[[Italian#^it-Q0261-answer|Compare the answer]]
^it-Q0261

**it-Q0262 · Build the sentence**

Arrange: esattamente? / Loro / erano / chi

Who exactly were they?

[[Italian#^it-Q0262-answer|Compare the answer]]
^it-Q0262

**it-Q0263 · Write a translation**

Write this in Italian: The theater was too crowded.

[[Italian#^it-Q0263-answer|Compare the answer]]
^it-Q0263

**it-Q0264 · Explain the grammar**

Il teatro 【era】 troppo affollato.

The theater was too crowded.

[[Italian#^it-Q0264-answer|Compare the answer]]
^it-Q0264

**it-Q0265 · Fill the gap**

Tom cercò di aprire il cassetto, ma ____ bloccato.

Tom tried to open the drawer, but it was stuck.

[[Italian#^it-Q0265-answer|Compare the answer]]
^it-Q0265

**it-Q0266 · Choose the form**

Tom cercò di aprire il cassetto, ma ____ bloccato.

Tom tried to open the drawer, but it was stuck.

Choices: aveva / erano / era / faceva

[[Italian#^it-Q0266-answer|Compare the answer]]
^it-Q0266

**it-Q0267 · Edit the changed sentence**

Perché 【erano】 a Boston?

Why were you in Boston?

[[Italian#^it-Q0267-answer|Compare the answer]]
^it-Q0267

**it-Q0268 · Build the sentence**

Arrange: Boston? / era / a / Perché

Why were you in Boston?

[[Italian#^it-Q0268-answer|Compare the answer]]
^it-Q0268

**it-Q0269 · Write a translation**

Write this in Italian: Tom didn't want to go back to the orphanage.

[[Italian#^it-Q0269-answer|Compare the answer]]
^it-Q0269

**it-Q0270 · Explain the grammar**

Tom non 【voleva】 tornare all'orfanotrofio.

Tom didn't want to go back to the orphanage.

[[Italian#^it-Q0270-answer|Compare the answer]]
^it-Q0270

**it-Q0271 · Fill the gap**

Tom ____ un po' affamato.

Tom was a little hungry.

[[Italian#^it-Q0271-answer|Compare the answer]]
^it-Q0271

**it-Q0272 · Choose the form**

Tom ____ un po' affamato.

Tom was a little hungry.

Choices: era / erano / faceva / aveva

[[Italian#^it-Q0272-answer|Compare the answer]]
^it-Q0272

**it-Q0273 · Edit the changed sentence**

Il capitano 【erano】 l'ultima persona che ha lasciato la nave che affondava.

The captain was the last person to leave the sinking ship.

[[Italian#^it-Q0273-answer|Compare the answer]]
^it-Q0273

**it-Q0274 · Build the sentence**

Arrange: affondava. / era / che / persona / Il / lasciato / la / nave / ha / che / capitano / l'ultima

The captain was the last person to leave the sinking ship.

[[Italian#^it-Q0274-answer|Compare the answer]]
^it-Q0274

**it-Q0275 · Write a translation**

Write this in Italian: She wished for a more relaxing life, but that was impossible under the circumstances.

[[Italian#^it-Q0275-answer|Compare the answer]]
^it-Q0275

**it-Q0276 · Explain the grammar**

Lei avrebbe voluto una vita più rilassante, ma 【era】 impossibile, date le circostanze.

She wished for a more relaxing life, but that was impossible under the circumstances.

[[Italian#^it-Q0276-answer|Compare the answer]]
^it-Q0276

**it-Q0277 · Fill the gap**

____ freddo ieri?

Was it cold yesterday?

[[Italian#^it-Q0277-answer|Compare the answer]]
^it-Q0277

**it-Q0278 · Choose the form**

____ freddo ieri?

Was it cold yesterday?

Choices: Faceva / erano / aveva / era

[[Italian#^it-Q0278-answer|Compare the answer]]
^it-Q0278

**it-Q0279 · Edit the changed sentence**

Sarah Bernhardt 【erano】 una attrice di teatro francese.

Sarah Bernhardt was a French stage actress.

[[Italian#^it-Q0279-answer|Compare the answer]]
^it-Q0279

**it-Q0280 · Build the sentence**

Arrange: Bernhardt / una / Sarah / francese. / era / attrice / teatro / di

Sarah Bernhardt was a French stage actress.

[[Italian#^it-Q0280-answer|Compare the answer]]
^it-Q0280

**it-Q0281 · Write a translation**

Write this in Italian: She was afraid of hurting him.

[[Italian#^it-Q0281-answer|Compare the answer]]
^it-Q0281

**it-Q0282 · Explain the grammar**

Lei 【aveva】 paura di fargli del male.

She was afraid of hurting him.

[[Italian#^it-Q0282-answer|Compare the answer]]
^it-Q0282

**it-Q0283 · Fill the gap**

Come lo sapeva che Tom ____ malato?

How did you know Tom was sick?

[[Italian#^it-Q0283-answer|Compare the answer]]
^it-Q0283

**it-Q0284 · Choose the form**

Come lo sapeva che Tom ____ malato?

How did you know Tom was sick?

Choices: faceva / erano / aveva / era

[[Italian#^it-Q0284-answer|Compare the answer]]
^it-Q0284

**it-Q0285 · Edit the changed sentence**

Forse Tom non 【era】 tempo.

Maybe Tom didn't have time.

[[Italian#^it-Q0285-answer|Compare the answer]]
^it-Q0285

**it-Q0286 · Build the sentence**

Arrange: Forse / Tom / tempo. / aveva / non

Maybe Tom didn't have time.

[[Italian#^it-Q0286-answer|Compare the answer]]
^it-Q0286

**it-Q0287 · Write a translation**

Write this in Italian: I had no one to talk to.

[[Italian#^it-Q0287-answer|Compare the answer]]
^it-Q0287

**it-Q0288 · Explain the grammar**

Non 【avevo】 nessuno con cui parlare.

I had no one to talk to.

[[Italian#^it-Q0288-answer|Compare the answer]]
^it-Q0288

**it-Q0289 · Fill the gap**

La polizia dice che Tom non ____ armato.

The police say Tom wasn't armed.

[[Italian#^it-Q0289-answer|Compare the answer]]
^it-Q0289

**it-Q0290 · Choose the form**

La polizia dice che Tom non ____ armato.

The police say Tom wasn't armed.

Choices: aveva / erano / era / faceva

[[Italian#^it-Q0290-answer|Compare the answer]]
^it-Q0290

**it-Q0291 · Edit the changed sentence**

Non c'【erano】 bisogno di avere fretta. Sei arrivato troppo presto.

You needn't have hurried; you've arrived too early.

[[Italian#^it-Q0291-answer|Compare the answer]]
^it-Q0291

**it-Q0292 · Build the sentence**

Arrange: fretta. / c'era / avere / bisogno / arrivato / troppo / Sei / di / presto. / Non

You needn't have hurried; you've arrived too early.

[[Italian#^it-Q0292-answer|Compare the answer]]
^it-Q0292

**it-Q0293 · Write a translation**

Write this in Italian: I had no idea you knew how to play the trombone.

[[Italian#^it-Q0293-answer|Compare the answer]]
^it-Q0293

**it-Q0294 · Explain the grammar**

Non 【avevo】 idea che voi sapeste suonare il trombone.

I had no idea you knew how to play the trombone.

[[Italian#^it-Q0294-answer|Compare the answer]]
^it-Q0294

**it-Q0295 · Fill the gap**

____ tutti presenti.

All were present.

[[Italian#^it-Q0295-answer|Compare the answer]]
^it-Q0295

**it-Q0296 · Choose the form**

____ tutti presenti.

All were present.

Choices: Erano / aveva / faceva / era

[[Italian#^it-Q0296-answer|Compare the answer]]
^it-Q0296

**it-Q0297 · Edit the changed sentence**

Ricorderebbe ancora una volta alla gente che questa non 【erano】 solo la sua decisione personale, ma molte decisioni altrui.

He would remind people again that it was decided not only by him but by many others.

[[Italian#^it-Q0297-answer|Compare the answer]]
^it-Q0297

**it-Q0298 · Build the sentence**

Arrange: solo / la / gente / molte / ma / decisione / altrui. / decisioni / sua / era / Ricorderebbe / questa / alla / non / personale, / ancora / una / volta / che

He would remind people again that it was decided not only by him but by many others.

[[Italian#^it-Q0298-answer|Compare the answer]]
^it-Q0298

**it-Q0299 · Write a translation**

Write this in Italian: Tom had different ideas.

[[Italian#^it-Q0299-answer|Compare the answer]]
^it-Q0299

**it-Q0300 · Explain the grammar**

Tom 【aveva】 delle idee differenti.

Tom had different ideas.

[[Italian#^it-Q0300-answer|Compare the answer]]
^it-Q0300


### Past participles · 50 questions

**it-Q0301 · Fill the gap**

Non so se l'avrebbe ____ per me.

I don't know if he would have done it for me.

[[Italian#^it-Q0301-answer|Compare the answer]]
^it-Q0301

**it-Q0302 · Choose the form**

Non so se l'avrebbe ____ per me.

I don't know if he would have done it for me.

Choices: visto / fatto / stato / detto

[[Italian#^it-Q0302-answer|Compare the answer]]
^it-Q0302

**it-Q0303 · Edit the changed sentence**

Se oggi fosse 【stato】 domenica, saremmo andati a pescare.

If it were Sunday today, we would go fishing.

[[Italian#^it-Q0303-answer|Compare the answer]]
^it-Q0303

**it-Q0304 · Build the sentence**

Arrange: stata / Se / pescare. / domenica, / fosse / andati / oggi / saremmo / a

If it were Sunday today, we would go fishing.

[[Italian#^it-Q0304-answer|Compare the answer]]
^it-Q0304

**it-Q0305 · Write a translation**

Write this in Italian: I'm sorry I was so rude.

[[Italian#^it-Q0305-answer|Compare the answer]]
^it-Q0305

**it-Q0306 · Explain the grammar**

Mi dispiace di essere 【stato】 così maleducato.

I'm sorry I was so rude.

[[Italian#^it-Q0306-answer|Compare the answer]]
^it-Q0306

**it-Q0307 · Fill the gap**

Tom ha ____ che non ci aiuterà.

Tom said he isn't going to help us.

[[Italian#^it-Q0307-answer|Compare the answer]]
^it-Q0307

**it-Q0308 · Choose the form**

Tom ha ____ che non ci aiuterà.

Tom said he isn't going to help us.

Choices: stato / fatto / detto / visto

[[Italian#^it-Q0308-answer|Compare the answer]]
^it-Q0308

**it-Q0309 · Edit the changed sentence**

Il mio dottore mi ha 【stato】 di smettere di prendere l'aspirina.

My doctor told me to quit taking aspirin.

[[Italian#^it-Q0309-answer|Compare the answer]]
^it-Q0309

**it-Q0310 · Build the sentence**

Arrange: Il / l'aspirina. / di / detto / mi / smettere / di / ha / prendere / dottore / mio

My doctor told me to quit taking aspirin.

[[Italian#^it-Q0310-answer|Compare the answer]]
^it-Q0310

**it-Q0311 · Write a translation**

Write this in Italian: Did you see who did it?

[[Italian#^it-Q0311-answer|Compare the answer]]
^it-Q0311

**it-Q0312 · Explain the grammar**

Hai 【visto】 chi l'ha fatta?

Did you see who did it?

[[Italian#^it-Q0312-answer|Compare the answer]]
^it-Q0312

**it-Q0313 · Fill the gap**

Perché gli hai ____ di farla?

Why did you tell him to do it?

[[Italian#^it-Q0313-answer|Compare the answer]]
^it-Q0313

**it-Q0314 · Choose the form**

Perché gli hai ____ di farla?

Why did you tell him to do it?

Choices: fatto / detto / stato / visto

[[Italian#^it-Q0314-answer|Compare the answer]]
^it-Q0314

**it-Q0315 · Edit the changed sentence**

Non ho mai 【stato】 quel tizio prima.

I've never seen that guy before.

[[Italian#^it-Q0315-answer|Compare the answer]]
^it-Q0315

**it-Q0316 · Build the sentence**

Arrange: quel / visto / Non / mai / ho / tizio / prima.

I've never seen that guy before.

[[Italian#^it-Q0316-answer|Compare the answer]]
^it-Q0316

**it-Q0317 · Write a translation**

Write this in Italian: Everything has been arranged.

[[Italian#^it-Q0317-answer|Compare the answer]]
^it-Q0317

**it-Q0318 · Explain the grammar**

Tutto è 【stato】 preparato.

Everything has been arranged.

[[Italian#^it-Q0318-answer|Compare the answer]]
^it-Q0318

**it-Q0319 · Fill the gap**

Tom ci deve avere ____ la verità.

Tom must've told us the truth.

[[Italian#^it-Q0319-answer|Compare the answer]]
^it-Q0319

**it-Q0320 · Choose the form**

Tom ci deve avere ____ la verità.

Tom must've told us the truth.

Choices: fatto / stato / detto / visto

[[Italian#^it-Q0320-answer|Compare the answer]]
^it-Q0320

**it-Q0321 · Edit the changed sentence**

Non hai 【stato】 le mie chiavi?

Didn't you see my keys?

[[Italian#^it-Q0321-answer|Compare the answer]]
^it-Q0321

**it-Q0322 · Build the sentence**

Arrange: Non / visto / le / hai / chiavi? / mie

Didn't you see my keys?

[[Italian#^it-Q0322-answer|Compare the answer]]
^it-Q0322

**it-Q0323 · Write a translation**

Write this in Italian: Yes, I have seen one many times.

[[Italian#^it-Q0323-answer|Compare the answer]]
^it-Q0323

**it-Q0324 · Explain the grammar**

Sì, ne ho 【visto】 uno molte volte.

Yes, I have seen one many times.

[[Italian#^it-Q0324-answer|Compare the answer]]
^it-Q0324

**it-Q0325 · Fill the gap**

Tom è ____ sequestrato.

Tom was abducted.

[[Italian#^it-Q0325-answer|Compare the answer]]
^it-Q0325

**it-Q0326 · Choose the form**

Tom è ____ sequestrato.

Tom was abducted.

Choices: fatto / visto / detto / stato

[[Italian#^it-Q0326-answer|Compare the answer]]
^it-Q0326

**it-Q0327 · Edit the changed sentence**

Ha 【stato】 che non l'avrebbe fatta.

She said she wouldn't do it.

[[Italian#^it-Q0327-answer|Compare the answer]]
^it-Q0327

**it-Q0328 · Build the sentence**

Arrange: fatta. / che / non / detto / Ha / l'avrebbe

She said she wouldn't do it.

[[Italian#^it-Q0328-answer|Compare the answer]]
^it-Q0328

**it-Q0329 · Write a translation**

Write this in Italian: Have you ever written a letter to Mary?

[[Italian#^it-Q0329-answer|Compare the answer]]
^it-Q0329

**it-Q0330 · Explain the grammar**

Tu hai mai 【scritto】 una lettera a Mary?

Have you ever written a letter to Mary?

[[Italian#^it-Q0330-answer|Compare the answer]]
^it-Q0330

**it-Q0331 · Fill the gap**

Lui è un uomo che si è ____ da solo.

He is a self-made man.

[[Italian#^it-Q0331-answer|Compare the answer]]
^it-Q0331

**it-Q0332 · Choose the form**

Lui è un uomo che si è ____ da solo.

He is a self-made man.

Choices: detto / stato / visto / fatto

[[Italian#^it-Q0332-answer|Compare the answer]]
^it-Q0332

**it-Q0333 · Edit the changed sentence**

Perché nessuno ha 【stato】 nulla?

Why didn't anybody do anything?

[[Italian#^it-Q0333-answer|Compare the answer]]
^it-Q0333

**it-Q0334 · Build the sentence**

Arrange: nessuno / ha / fatto / Perché / nulla?

Why didn't anybody do anything?

[[Italian#^it-Q0334-answer|Compare the answer]]
^it-Q0334

**it-Q0335 · Write a translation**

Write this in Italian: This museum has been closed for five years.

[[Italian#^it-Q0335-answer|Compare the answer]]
^it-Q0335

**it-Q0336 · Explain the grammar**

Questo museo è 【stato】 chiuso per cinque anni.

This museum has been closed for five years.

[[Italian#^it-Q0336-answer|Compare the answer]]
^it-Q0336

**it-Q0337 · Fill the gap**

Ha ____ che è disoccupato.

He said that he's unemployed.

[[Italian#^it-Q0337-answer|Compare the answer]]
^it-Q0337

**it-Q0338 · Choose the form**

Ha ____ che è disoccupato.

He said that he's unemployed.

Choices: visto / stato / fatto / detto

[[Italian#^it-Q0338-answer|Compare the answer]]
^it-Q0338

**it-Q0339 · Edit the changed sentence**

Ha 【stato】 che li amava.

You said you loved them.

[[Italian#^it-Q0339-answer|Compare the answer]]
^it-Q0339

**it-Q0340 · Build the sentence**

Arrange: li / amava. / che / detto / Ha

You said you loved them.

[[Italian#^it-Q0340-answer|Compare the answer]]
^it-Q0340

**it-Q0341 · Write a translation**

Write this in Italian: The student read the book the night before the exam.

[[Italian#^it-Q0341-answer|Compare the answer]]
^it-Q0341

**it-Q0342 · Explain the grammar**

Lo studente ha 【letto】 il libro la notte prima dell'esame.

The student read the book the night before the exam.

[[Italian#^it-Q0342-answer|Compare the answer]]
^it-Q0342

**it-Q0343 · Fill the gap**

Quello è ____ scritto da Taro Akagawa.

That was written by Taro Akagawa.

[[Italian#^it-Q0343-answer|Compare the answer]]
^it-Q0343

**it-Q0344 · Choose the form**

Quello è ____ scritto da Taro Akagawa.

That was written by Taro Akagawa.

Choices: detto / stato / fatto / visto

[[Italian#^it-Q0344-answer|Compare the answer]]
^it-Q0344

**it-Q0345 · Edit the changed sentence**

Io sono sempre 【stato】 appassionata di football.

I've always been passionate about football.

[[Italian#^it-Q0345-answer|Compare the answer]]
^it-Q0345

**it-Q0346 · Build the sentence**

Arrange: sempre / appassionata / di / sono / stata / football. / Io

I've always been passionate about football.

[[Italian#^it-Q0346-answer|Compare the answer]]
^it-Q0346

**it-Q0347 · Write a translation**

Write this in Italian: Why didn't you go with them?

[[Italian#^it-Q0347-answer|Compare the answer]]
^it-Q0347

**it-Q0348 · Explain the grammar**

Perché non sei 【andata】 con loro?

Why didn't you go with them?

[[Italian#^it-Q0348-answer|Compare the answer]]
^it-Q0348

**it-Q0349 · Fill the gap**

L'ho ____ a William, ma non mi ha creduta.

I told William, but he didn't believe me.

[[Italian#^it-Q0349-answer|Compare the answer]]
^it-Q0349

**it-Q0350 · Choose the form**

L'ho ____ a William, ma non mi ha creduta.

I told William, but he didn't believe me.

Choices: fatto / visto / stato / detto

[[Italian#^it-Q0350-answer|Compare the answer]]
^it-Q0350


### Future forms · 50 questions

**it-Q0351 · Edit the changed sentence**

Non penso che Tom 【avrà】 impressionato.

I don't think Tom will be impressed.

[[Italian#^it-Q0351-answer|Compare the answer]]
^it-Q0351

**it-Q0352 · Build the sentence**

Arrange: penso / sarà / Tom / che / impressionato. / Non

I don't think Tom will be impressed.

[[Italian#^it-Q0352-answer|Compare the answer]]
^it-Q0352

**it-Q0353 · Write a translation**

Write this in Italian: He will be back in an hour.

[[Italian#^it-Q0353-answer|Compare the answer]]
^it-Q0353

**it-Q0354 · Explain the grammar**

Lui 【sarà】 di ritorno tra un'ora.

He will be back in an hour.

[[Italian#^it-Q0354-answer|Compare the answer]]
^it-Q0354

**it-Q0355 · Fill the gap**

____ a parlare con Tom.

I'll go talk to Tom.

[[Italian#^it-Q0355-answer|Compare the answer]]
^it-Q0355

**it-Q0356 · Choose the form**

____ a parlare con Tom.

I'll go talk to Tom.

Choices: Andrò / avrà / farà / sarà

[[Italian#^it-Q0356-answer|Compare the answer]]
^it-Q0356

**it-Q0357 · Edit the changed sentence**

È molto improbabile che Tom 【avrà】 lì.

It's very unlikely that Tom will be there.

[[Italian#^it-Q0357-answer|Compare the answer]]
^it-Q0357

**it-Q0358 · Build the sentence**

Arrange: lì. / che / improbabile / molto / È / sarà / Tom

It's very unlikely that Tom will be there.

[[Italian#^it-Q0358-answer|Compare the answer]]
^it-Q0358

**it-Q0359 · Write a translation**

Write this in Italian: He said he'll do that soon.

[[Italian#^it-Q0359-answer|Compare the answer]]
^it-Q0359

**it-Q0360 · Explain the grammar**

Ha detto che lo 【farà】 presto.

He said he'll do that soon.

[[Italian#^it-Q0360-answer|Compare the answer]]
^it-Q0360

**it-Q0361 · Fill the gap**

Questa macchia non ____ via.

This stain won't come out.

[[Italian#^it-Q0361-answer|Compare the answer]]
^it-Q0361

**it-Q0362 · Choose the form**

Questa macchia non ____ via.

This stain won't come out.

Choices: farà / avrà / andrà / sarà

[[Italian#^it-Q0362-answer|Compare the answer]]
^it-Q0362

**it-Q0363 · Edit the changed sentence**

Lei 【avrà】 qui questa sera.

She will be here this evening.

[[Italian#^it-Q0363-answer|Compare the answer]]
^it-Q0363

**it-Q0364 · Build the sentence**

Arrange: sarà / sera. / qui / Lei / questa

She will be here this evening.

[[Italian#^it-Q0364-answer|Compare the answer]]
^it-Q0364

**it-Q0365 · Write a translation**

Write this in Italian: It will make you smile.

[[Italian#^it-Q0365-answer|Compare the answer]]
^it-Q0365

**it-Q0366 · Explain the grammar**

La 【farà】 sorridere.

It will make you smile.

[[Italian#^it-Q0366-answer|Compare the answer]]
^it-Q0366

**it-Q0367 · Fill the gap**

Tom ____ bisogno di questo.

Tom will need this.

[[Italian#^it-Q0367-answer|Compare the answer]]
^it-Q0367

**it-Q0368 · Choose the form**

Tom ____ bisogno di questo.

Tom will need this.

Choices: sarà / farà / andrà / avrà

[[Italian#^it-Q0368-answer|Compare the answer]]
^it-Q0368

**it-Q0369 · Edit the changed sentence**

Forse Tom non 【avrà】 qua oggi.

Maybe Tom won't be here today.

[[Italian#^it-Q0369-answer|Compare the answer]]
^it-Q0369

**it-Q0370 · Build the sentence**

Arrange: qua / sarà / Tom / oggi. / non / Forse

Maybe Tom won't be here today.

[[Italian#^it-Q0370-answer|Compare the answer]]
^it-Q0370

**it-Q0371 · Write a translation**

Write this in Italian: I'll make an exception this time.

[[Italian#^it-Q0371-answer|Compare the answer]]
^it-Q0371

**it-Q0372 · Explain the grammar**

【Farò】 un'eccezione questa volta.

I'll make an exception this time.

[[Italian#^it-Q0372-answer|Compare the answer]]
^it-Q0372

**it-Q0373 · Fill the gap**

Le cose non ____ mai più le stesse.

Things will never be the same again.

[[Italian#^it-Q0373-answer|Compare the answer]]
^it-Q0373

**it-Q0374 · Choose the form**

Le cose non ____ mai più le stesse.

Things will never be the same again.

Choices: saranno / sarà / farà / avrà

[[Italian#^it-Q0374-answer|Compare the answer]]
^it-Q0374

**it-Q0375 · Edit the changed sentence**

Ci 【avrà】 molto molto caldo.

It will be very, very hot.

[[Italian#^it-Q0375-answer|Compare the answer]]
^it-Q0375

**it-Q0376 · Build the sentence**

Arrange: caldo. / molto / Ci / sarà / molto

It will be very, very hot.

[[Italian#^it-Q0376-answer|Compare the answer]]
^it-Q0376

**it-Q0377 · Write a translation**

Write this in Italian: By next Sunday, I'll have read through the novel.

[[Italian#^it-Q0377-answer|Compare the answer]]
^it-Q0377

**it-Q0378 · Explain the grammar**

Entro domenica prossima, io 【avrò】 letto tutto il romanzo.

By next Sunday, I'll have read through the novel.

[[Italian#^it-Q0378-answer|Compare the answer]]
^it-Q0378

**it-Q0379 · Fill the gap**

____ a dire a Tom la buona notizia.

I'll go tell Tom the good news.

[[Italian#^it-Q0379-answer|Compare the answer]]
^it-Q0379

**it-Q0380 · Choose the form**

____ a dire a Tom la buona notizia.

I'll go tell Tom the good news.

Choices: Andrò / sarà / avrà / farà

[[Italian#^it-Q0380-answer|Compare the answer]]
^it-Q0380

**it-Q0381 · Edit the changed sentence**

Cosa 【sarà】 senza Tom?

What am I going to do without Tom?

[[Italian#^it-Q0381-answer|Compare the answer]]
^it-Q0381

**it-Q0382 · Build the sentence**

Arrange: senza / Cosa / Tom? / farò

What am I going to do without Tom?

[[Italian#^it-Q0382-answer|Compare the answer]]
^it-Q0382

**it-Q0383 · Write a translation**

Write this in Italian: I'm sure Tom will be relieved.

[[Italian#^it-Q0383-answer|Compare the answer]]
^it-Q0383

**it-Q0384 · Explain the grammar**

Io sono sicura che Tom 【sarà】 rincuorato.

I'm sure Tom will be relieved.

[[Italian#^it-Q0384-answer|Compare the answer]]
^it-Q0384

**it-Q0385 · Fill the gap**

So che Tom non lo ____.

I know Tom won't do that.

[[Italian#^it-Q0385-answer|Compare the answer]]
^it-Q0385

**it-Q0386 · Choose the form**

So che Tom non lo ____.

I know Tom won't do that.

Choices: andrà / farà / sarà / avrà

[[Italian#^it-Q0386-answer|Compare the answer]]
^it-Q0386

**it-Q0387 · Edit the changed sentence**

Tom probabilmente non 【avrà】 ammanettato.

Tom won't likely be handcuffed.

[[Italian#^it-Q0387-answer|Compare the answer]]
^it-Q0387

**it-Q0388 · Build the sentence**

Arrange: non / ammanettato. / sarà / probabilmente / Tom

Tom won't likely be handcuffed.

[[Italian#^it-Q0388-answer|Compare the answer]]
^it-Q0388

**it-Q0389 · Write a translation**

Write this in Italian: Whichever you choose, you will be satisfied.

[[Italian#^it-Q0389-answer|Compare the answer]]
^it-Q0389

**it-Q0390 · Explain the grammar**

Qualsiasi sia la scelta, 【sarà】 soddisfatto.

Whichever you choose, you will be satisfied.

[[Italian#^it-Q0390-answer|Compare the answer]]
^it-Q0390

**it-Q0391 · Fill the gap**

Tom probabilmente non ____ assetato.

Tom won't likely be thirsty.

[[Italian#^it-Q0391-answer|Compare the answer]]
^it-Q0391

**it-Q0392 · Choose the form**

Tom probabilmente non ____ assetato.

Tom won't likely be thirsty.

Choices: avrà / farà / sarà / andrà

[[Italian#^it-Q0392-answer|Compare the answer]]
^it-Q0392

**it-Q0393 · Edit the changed sentence**

Lasci noi studenti contribuire al benessere delle vittime del terremoto; anche un cambiamento lento 【sarà】 molto lontano.

Let us students contribute to the welfare of the victims of the earthquake; even loose change will go a long way.

[[Italian#^it-Q0393-answer|Compare the answer]]
^it-Q0393

**it-Q0394 · Build the sentence**

Arrange: terremoto; / al / lontano. / del / benessere / lento / studenti / andrà / Lasci / anche / delle / molto / contribuire / vittime / noi / un / cambiamento

Let us students contribute to the welfare of the victims of the earthquake; even loose change will go a long way.

[[Italian#^it-Q0394-answer|Compare the answer]]
^it-Q0394

**it-Q0395 · Write a translation**

Write this in Italian: Tom is going to need our help.

[[Italian#^it-Q0395-answer|Compare the answer]]
^it-Q0395

**it-Q0396 · Explain the grammar**

Tom 【avrà】 bisogno del nostro aiuto.

Tom is going to need our help.

[[Italian#^it-Q0396-answer|Compare the answer]]
^it-Q0396

**it-Q0397 · Fill the gap**

Io non penso che Tom ____ a scuola domani.

I don't think Tom will be at school tomorrow.

[[Italian#^it-Q0397-answer|Compare the answer]]
^it-Q0397

**it-Q0398 · Choose the form**

Io non penso che Tom ____ a scuola domani.

I don't think Tom will be at school tomorrow.

Choices: andrà / avrà / farà / sarà

[[Italian#^it-Q0398-answer|Compare the answer]]
^it-Q0398

**it-Q0399 · Edit the changed sentence**

【sarà】 a prendere i moduli appropriati.

I'll go get the proper forms.

[[Italian#^it-Q0399-answer|Compare the answer]]
^it-Q0399

**it-Q0400 · Build the sentence**

Arrange: moduli / Andrò / i / prendere / a / appropriati.

I'll go get the proper forms.

[[Italian#^it-Q0400-answer|Compare the answer]]
^it-Q0400


### Conditional and politeness · 50 questions

**it-Q0401 · Write a translation**

Write this in Italian: No living thing could live without air.

[[Italian#^it-Q0401-answer|Compare the answer]]
^it-Q0401

**it-Q0402 · Explain the grammar**

Nessuna cosa vivente 【potrebbe】 vivere senza aria.

No living thing could live without air.

[[Italian#^it-Q0402-answer|Compare the answer]]
^it-Q0402

**it-Q0403 · Fill the gap**

Tom ____ lasciarmi aiutare Mary.

Tom should let me help Mary.

[[Italian#^it-Q0403-answer|Compare the answer]]
^it-Q0403

**it-Q0404 · Choose the form**

Tom ____ lasciarmi aiutare Mary.

Tom should let me help Mary.

Choices: potrebbe / vorrei / sarebbe / dovrebbe

[[Italian#^it-Q0404-answer|Compare the answer]]
^it-Q0404

**it-Q0405 · Edit the changed sentence**

Io 【sarebbe】 che Tom fosse qui.

I wish Tom was here.

[[Italian#^it-Q0405-answer|Compare the answer]]
^it-Q0405

**it-Q0406 · Build the sentence**

Arrange: che / Io / Tom / fosse / vorrei / qui.

I wish Tom was here.

[[Italian#^it-Q0406-answer|Compare the answer]]
^it-Q0406

**it-Q0407 · Write a translation**

Write this in Italian: I'd like to cook chicken tonight.

[[Italian#^it-Q0407-answer|Compare the answer]]
^it-Q0407

**it-Q0408 · Explain the grammar**

【Vorrei】 cucinare pollo stasera.

I'd like to cook chicken tonight.

[[Italian#^it-Q0408-answer|Compare the answer]]
^it-Q0408

**it-Q0409 · Fill the gap**

____ sorpresa di quello che può imparare in una settimana.

You'd be surprised what you can learn in a week.

[[Italian#^it-Q0409-answer|Compare the answer]]
^it-Q0409

**it-Q0410 · Choose the form**

____ sorpresa di quello che può imparare in una settimana.

You'd be surprised what you can learn in a week.

Choices: vorrei / potrebbe / Sarebbe / dovrebbe

[[Italian#^it-Q0410-answer|Compare the answer]]
^it-Q0410

**it-Q0411 · Edit the changed sentence**

Perché ci 【vorrei】 essere un problema?

Why should there be a problem?

[[Italian#^it-Q0411-answer|Compare the answer]]
^it-Q0411

**it-Q0412 · Build the sentence**

Arrange: Perché / ci / un / essere / dovrebbe / problema?

Why should there be a problem?

[[Italian#^it-Q0412-answer|Compare the answer]]
^it-Q0412

**it-Q0413 · Write a translation**

Write this in Italian: Tom could explain that.

[[Italian#^it-Q0413-answer|Compare the answer]]
^it-Q0413

**it-Q0414 · Explain the grammar**

Tom lo 【potrebbe】 spiegare.

Tom could explain that.

[[Italian#^it-Q0414-answer|Compare the answer]]
^it-Q0414

**it-Q0415 · Fill the gap**

Non ____ mangiare questo.

You shouldn't eat this.

[[Italian#^it-Q0415-answer|Compare the answer]]
^it-Q0415

**it-Q0416 · Choose the form**

Non ____ mangiare questo.

You shouldn't eat this.

Choices: potrebbe / dovrebbe / sarebbe / vorrei

[[Italian#^it-Q0416-answer|Compare the answer]]
^it-Q0416

**it-Q0417 · Edit the changed sentence**

【sarebbe】 smettesse di piovere.

I wish it would stop raining.

[[Italian#^it-Q0417-answer|Compare the answer]]
^it-Q0417

**it-Q0418 · Build the sentence**

Arrange: smettesse / di / piovere. / Vorrei

I wish it would stop raining.

[[Italian#^it-Q0418-answer|Compare the answer]]
^it-Q0418

**it-Q0419 · Write a translation**

Write this in Italian: He should have bought a used car.

[[Italian#^it-Q0419-answer|Compare the answer]]
^it-Q0419

**it-Q0420 · Explain the grammar**

Lui 【avrebbe】 dovuto comprare una macchina usata.

He should have bought a used car.

[[Italian#^it-Q0420-answer|Compare the answer]]
^it-Q0420

**it-Q0421 · Fill the gap**

____ accendere la luce, per piacere?

Could you turn on the light, please?

[[Italian#^it-Q0421-answer|Compare the answer]]
^it-Q0421

**it-Q0422 · Choose the form**

____ accendere la luce, per piacere?

Could you turn on the light, please?

Choices: sarebbe / vorrei / Potrebbe / dovrebbe

[[Italian#^it-Q0422-answer|Compare the answer]]
^it-Q0422

**it-Q0423 · Edit the changed sentence**

Tom non 【vorrei】 farlo?

Shouldn't Tom be doing that?

[[Italian#^it-Q0423-answer|Compare the answer]]
^it-Q0423

**it-Q0424 · Build the sentence**

Arrange: farlo? / non / Tom / dovrebbe

Shouldn't Tom be doing that?

[[Italian#^it-Q0424-answer|Compare the answer]]
^it-Q0424

**it-Q0425 · Write a translation**

Write this in Italian: Tom should leave Mary alone.

[[Italian#^it-Q0425-answer|Compare the answer]]
^it-Q0425

**it-Q0426 · Explain the grammar**

Tom 【dovrebbe】 lasciare Mary da sola.

Tom should leave Mary alone.

[[Italian#^it-Q0426-answer|Compare the answer]]
^it-Q0426

**it-Q0427 · Fill the gap**

____ del caffè o del tè?

Would you like coffee or tea?

[[Italian#^it-Q0427-answer|Compare the answer]]
^it-Q0427

**it-Q0428 · Choose the form**

____ del caffè o del tè?

Would you like coffee or tea?

Choices: sarebbe / Vorrebbe / potrebbe / vorrei

[[Italian#^it-Q0428-answer|Compare the answer]]
^it-Q0428

**it-Q0429 · Edit the changed sentence**

Io 【sarebbe】 una stanza che dia sul giardino.

I'd like a room facing the garden.

[[Italian#^it-Q0429-answer|Compare the answer]]
^it-Q0429

**it-Q0430 · Build the sentence**

Arrange: che / sul / vorrei / dia / Io / stanza / giardino. / una

I'd like a room facing the garden.

[[Italian#^it-Q0430-answer|Compare the answer]]
^it-Q0430

**it-Q0431 · Write a translation**

Write this in Italian: I thought he wouldn't come.

[[Italian#^it-Q0431-answer|Compare the answer]]
^it-Q0431

**it-Q0432 · Explain the grammar**

Pensavo che non 【sarebbe】 venuto.

I thought he wouldn't come.

[[Italian#^it-Q0432-answer|Compare the answer]]
^it-Q0432

**it-Q0433 · Fill the gap**

____ poter visitare Boston.

I wish I could visit Boston.

[[Italian#^it-Q0433-answer|Compare the answer]]
^it-Q0433

**it-Q0434 · Choose the form**

____ poter visitare Boston.

I wish I could visit Boston.

Choices: dovrebbe / Vorrei / potrebbe / sarebbe

[[Italian#^it-Q0434-answer|Compare the answer]]
^it-Q0434

**it-Q0435 · Edit the changed sentence**

【vorrei】 andare lì.

You should go there.

[[Italian#^it-Q0435-answer|Compare the answer]]
^it-Q0435

**it-Q0436 · Build the sentence**

Arrange: Dovrebbe / lì. / andare

You should go there.

[[Italian#^it-Q0436-answer|Compare the answer]]
^it-Q0436

**it-Q0437 · Write a translation**

Write this in Italian: Would you like one now?

[[Italian#^it-Q0437-answer|Compare the answer]]
^it-Q0437

**it-Q0438 · Explain the grammar**

Ne 【vorrebbe】 uno adesso?

Would you like one now?

[[Italian#^it-Q0438-answer|Compare the answer]]
^it-Q0438

**it-Q0439 · Fill the gap**

Pensate che ____ vincere?

Do you think I might win?

[[Italian#^it-Q0439-answer|Compare the answer]]
^it-Q0439

**it-Q0440 · Choose the form**

Pensate che ____ vincere?

Do you think I might win?

Choices: vorrei / potrei / potrebbe / sarebbe

[[Italian#^it-Q0440-answer|Compare the answer]]
^it-Q0440

**it-Q0441 · Edit the changed sentence**

【vorrei】 avere questa scatola?

Could I have this box?

[[Italian#^it-Q0441-answer|Compare the answer]]
^it-Q0441

**it-Q0442 · Build the sentence**

Arrange: avere / questa / scatola? / Potrei

Could I have this box?

[[Italian#^it-Q0442-answer|Compare the answer]]
^it-Q0442

**it-Q0443 · Write a translation**

Write this in Italian: What would be best for them?

[[Italian#^it-Q0443-answer|Compare the answer]]
^it-Q0443

**it-Q0444 · Explain the grammar**

Cosa 【sarebbe】 il meglio per loro?

What would be best for them?

[[Italian#^it-Q0444-answer|Compare the answer]]
^it-Q0444

**it-Q0445 · Fill the gap**

____ noleggiare un'auto.

I'd like to rent a car.

[[Italian#^it-Q0445-answer|Compare the answer]]
^it-Q0445

**it-Q0446 · Choose the form**

____ noleggiare un'auto.

I'd like to rent a car.

Choices: potrebbe / sarebbe / dovrebbe / Vorrei

[[Italian#^it-Q0446-answer|Compare the answer]]
^it-Q0446

**it-Q0447 · Edit the changed sentence**

Che altro 【vorrei】 volere?

What more could you want?

[[Italian#^it-Q0447-answer|Compare the answer]]
^it-Q0447

**it-Q0448 · Build the sentence**

Arrange: Che / altro / volere? / potrebbe

What more could you want?

[[Italian#^it-Q0448-answer|Compare the answer]]
^it-Q0448

**it-Q0449 · Write a translation**

Write this in Italian: Tom isn't as happy as he should be.

[[Italian#^it-Q0449-answer|Compare the answer]]
^it-Q0449

**it-Q0450 · Explain the grammar**

Tom non è felice come 【dovrebbe】 essere.

Tom isn't as happy as he should be.

[[Italian#^it-Q0450-answer|Compare the answer]]
^it-Q0450


### Subjunctive forms · 50 questions

**it-Q0451 · Fill the gap**

____ a dirle come si sente.

Go tell her how you feel.

[[Italian#^it-Q0451-answer|Compare the answer]]
^it-Q0451

**it-Q0452 · Choose the form**

____ a dirle come si sente.

Go tell her how you feel.

Choices: faccia / abbia / Vada / sia

[[Italian#^it-Q0452-answer|Compare the answer]]
^it-Q0452

**it-Q0453 · Edit the changed sentence**

Chi pensate che 【sia】?

Who do you think they are?

[[Italian#^it-Q0453-answer|Compare the answer]]
^it-Q0453

**it-Q0454 · Build the sentence**

Arrange: siano? / Chi / pensate / che

Who do you think they are?

[[Italian#^it-Q0454-answer|Compare the answer]]
^it-Q0454

**it-Q0455 · Write a translation**

Write this in Italian: Go with him.

[[Italian#^it-Q0455-answer|Compare the answer]]
^it-Q0455

**it-Q0456 · Explain the grammar**

【Vada】 con lui.

Go with him.

[[Italian#^it-Q0456-answer|Compare the answer]]
^it-Q0456

**it-Q0457 · Fill the gap**

Io penso che ____ vera.

I think it's true.

[[Italian#^it-Q0457-answer|Compare the answer]]
^it-Q0457

**it-Q0458 · Choose the form**

Io penso che ____ vera.

I think it's true.

Choices: possa / sia / faccia / abbia

[[Italian#^it-Q0458-answer|Compare the answer]]
^it-Q0458

**it-Q0459 · Edit the changed sentence**

Non si 【sia】 investire.

Don't get run over.

[[Italian#^it-Q0459-answer|Compare the answer]]
^it-Q0459

**it-Q0460 · Build the sentence**

Arrange: faccia / investire. / Non / si

Don't get run over.

[[Italian#^it-Q0460-answer|Compare the answer]]
^it-Q0460

**it-Q0461 · Write a translation**

Write this in Italian: I suspect that Tom is a cold-blooded murderer.

[[Italian#^it-Q0461-answer|Compare the answer]]
^it-Q0461

**it-Q0462 · Explain the grammar**

Io sospetto che Tom 【sia】 un assassino a sangue freddo.

I suspect that Tom is a cold-blooded murderer.

[[Italian#^it-Q0462-answer|Compare the answer]]
^it-Q0462

**it-Q0463 · Fill the gap**

Spero che il vino ____ di tuo gradimento.

I hope the wine is to your taste.

[[Italian#^it-Q0463-answer|Compare the answer]]
^it-Q0463

**it-Q0464 · Choose the form**

Spero che il vino ____ di tuo gradimento.

I hope the wine is to your taste.

Choices: faccia / abbia / possa / sia

[[Italian#^it-Q0464-answer|Compare the answer]]
^it-Q0464

**it-Q0465 · Edit the changed sentence**

Io penso che Tom 【sia】 piangere.

I think Tom may cry.

[[Italian#^it-Q0465-answer|Compare the answer]]
^it-Q0465

**it-Q0466 · Build the sentence**

Arrange: Io / penso / possa / che / Tom / piangere.

I think Tom may cry.

[[Italian#^it-Q0466-answer|Compare the answer]]
^it-Q0466

**it-Q0467 · Write a translation**

Write this in Italian: I demand that students always be on time.

[[Italian#^it-Q0467-answer|Compare the answer]]
^it-Q0467

**it-Q0468 · Explain the grammar**

Io insisto che gli studenti 【siano】 sempre in orario.

I demand that students always be on time.

[[Italian#^it-Q0468-answer|Compare the answer]]
^it-Q0468

**it-Q0469 · Fill the gap**

Mi chiedo di cos'____ parlato Tom e Mary.

I wonder what Tom and Mary talked about.

[[Italian#^it-Q0469-answer|Compare the answer]]
^it-Q0469

**it-Q0470 · Choose the form**

Mi chiedo di cos'____ parlato Tom e Mary.

I wonder what Tom and Mary talked about.

Choices: faccia / abbiano / sia / abbia

[[Italian#^it-Q0470-answer|Compare the answer]]
^it-Q0470

**it-Q0471 · Edit the changed sentence**

Penso 【abbia】 magnifica.

I think it's wonderful.

[[Italian#^it-Q0471-answer|Compare the answer]]
^it-Q0471

**it-Q0472 · Build the sentence**

Arrange: sia / magnifica. / Penso

I think it's wonderful.

[[Italian#^it-Q0472-answer|Compare the answer]]
^it-Q0472

**it-Q0473 · Write a translation**

Write this in Italian: Let me have a little chat with Tom.

[[Italian#^it-Q0473-answer|Compare the answer]]
^it-Q0473

**it-Q0474 · Explain the grammar**

Lasci che 【faccia】 una piccola chiacchierata con Tom.

Let me have a little chat with Tom.

[[Italian#^it-Q0474-answer|Compare the answer]]
^it-Q0474

**it-Q0475 · Fill the gap**

Lasci che ____ una domanda.

Let me ask a question.

[[Italian#^it-Q0475-answer|Compare the answer]]
^it-Q0475

**it-Q0476 · Choose the form**

Lasci che ____ una domanda.

Let me ask a question.

Choices: sia / abbia / faccia / possa

[[Italian#^it-Q0476-answer|Compare the answer]]
^it-Q0476

**it-Q0477 · Edit the changed sentence**

Lo so che pensate che questo 【abbia】 troppo costoso.

I know you think this is too expensive.

[[Italian#^it-Q0477-answer|Compare the answer]]
^it-Q0477

**it-Q0478 · Build the sentence**

Arrange: sia / questo / pensate / so / che / che / troppo / costoso. / Lo

I know you think this is too expensive.

[[Italian#^it-Q0478-answer|Compare the answer]]
^it-Q0478

**it-Q0479 · Write a translation**

Write this in Italian: I think that's horrible.

[[Italian#^it-Q0479-answer|Compare the answer]]
^it-Q0479

**it-Q0480 · Explain the grammar**

Penso che 【sia】 orribile.

I think that's horrible.

[[Italian#^it-Q0480-answer|Compare the answer]]
^it-Q0480

**it-Q0481 · Fill the gap**

Penso che ____ sbagliato.

I think it was wrong.

[[Italian#^it-Q0481-answer|Compare the answer]]
^it-Q0481

**it-Q0482 · Choose the form**

Penso che ____ sbagliato.

I think it was wrong.

Choices: abbia / sia / faccia / fosse

[[Italian#^it-Q0482-answer|Compare the answer]]
^it-Q0482

**it-Q0483 · Edit the changed sentence**

Mi 【sia】 provare ancora.

Let me try again.

[[Italian#^it-Q0483-answer|Compare the answer]]
^it-Q0483

**it-Q0484 · Build the sentence**

Arrange: provare / Mi / faccia / ancora.

Let me try again.

[[Italian#^it-Q0484-answer|Compare the answer]]
^it-Q0484

**it-Q0485 · Write a translation**

Write this in Italian: But do you think people are stupid?

[[Italian#^it-Q0485-answer|Compare the answer]]
^it-Q0485

**it-Q0486 · Explain the grammar**

Ma pensi che la gente 【sia】 stupida?

But do you think people are stupid?

[[Italian#^it-Q0486-answer|Compare the answer]]
^it-Q0486

**it-Q0487 · Fill the gap**

Sembrava che Tom ____ scettico.

Tom looked like he was skeptical.

[[Italian#^it-Q0487-answer|Compare the answer]]
^it-Q0487

**it-Q0488 · Choose the form**

Sembrava che Tom ____ scettico.

Tom looked like he was skeptical.

Choices: faccia / fosse / sia / abbia

[[Italian#^it-Q0488-answer|Compare the answer]]
^it-Q0488

**it-Q0489 · Edit the changed sentence**

Conosco 【abbia】 Mary che suo marito.

I know both Mary and her husband.

[[Italian#^it-Q0489-answer|Compare the answer]]
^it-Q0489

**it-Q0490 · Build the sentence**

Arrange: marito. / sia / che / Mary / suo / Conosco

I know both Mary and her husband.

[[Italian#^it-Q0490-answer|Compare the answer]]
^it-Q0490

**it-Q0491 · Write a translation**

Write this in Italian: I cannot consent to your going alone.

[[Italian#^it-Q0491-answer|Compare the answer]]
^it-Q0491

**it-Q0492 · Explain the grammar**

Io non posso acconsentire che lei 【vada】 da sola.

I cannot consent to your going alone.

[[Italian#^it-Q0492-answer|Compare the answer]]
^it-Q0492

**it-Q0493 · Fill the gap**

Penso che non ____ farlo.

I think he can't do that.

[[Italian#^it-Q0493-answer|Compare the answer]]
^it-Q0493

**it-Q0494 · Choose the form**

Penso che non ____ farlo.

I think he can't do that.

Choices: faccia / sia / abbia / possa

[[Italian#^it-Q0494-answer|Compare the answer]]
^it-Q0494

**it-Q0495 · Edit the changed sentence**

Io penso che 【sia】 più di quarant'anni.

I think she is over forty years old.

[[Italian#^it-Q0495-answer|Compare the answer]]
^it-Q0495

**it-Q0496 · Build the sentence**

Arrange: di / più / penso / Io / quarant'anni. / abbia / che

I think she is over forty years old.

[[Italian#^it-Q0496-answer|Compare the answer]]
^it-Q0496

**it-Q0497 · Write a translation**

Write this in Italian: What do you think's a good present for Tom's birthday?

[[Italian#^it-Q0497-answer|Compare the answer]]
^it-Q0497

**it-Q0498 · Explain the grammar**

Quale pensate che 【sia】 un bel regalo per il compleanno di Tom?

What do you think's a good present for Tom's birthday?

[[Italian#^it-Q0498-answer|Compare the answer]]
^it-Q0498

**it-Q0499 · Fill the gap**

Il bambino parla come se ____ un uomo.

The child talks as if he were a man.

[[Italian#^it-Q0499-answer|Compare the answer]]
^it-Q0499

**it-Q0500 · Choose the form**

Il bambino parla come se ____ un uomo.

The child talks as if he were a man.

Choices: fosse / sia / faccia / abbia

[[Italian#^it-Q0500-answer|Compare the answer]]
^it-Q0500


### Direct object clitics · 50 questions

**it-Q0501 · Edit the changed sentence**

【lo】 piace questo quartiere.

I like this neighborhood.

[[Italian#^it-Q0501-answer|Compare the answer]]
^it-Q0501

**it-Q0502 · Build the sentence**

Arrange: quartiere. / questo / piace / Mi

I like this neighborhood.

[[Italian#^it-Q0502-answer|Compare the answer]]
^it-Q0502

**it-Q0503 · Write a translation**

Write this in Italian: What do you like about him?

[[Italian#^it-Q0503-answer|Compare the answer]]
^it-Q0503

**it-Q0504 · Explain the grammar**

Cosa 【vi】 piace di lui?

What do you like about him?

[[Italian#^it-Q0504-answer|Compare the answer]]
^it-Q0504

**it-Q0505 · Fill the gap**

Non ____ sentite umiliate?

Don't you feel humiliated?

[[Italian#^it-Q0505-answer|Compare the answer]]
^it-Q0505

**it-Q0506 · Choose the form**

Non ____ sentite umiliate?

Don't you feel humiliated?

Choices: li / lo / la / ci

[[Italian#^it-Q0506-answer|Compare the answer]]
^it-Q0506

**it-Q0507 · Edit the changed sentence**

Perché non 【lo】 piace qui?

Why don't you like it here?

[[Italian#^it-Q0507-answer|Compare the answer]]
^it-Q0507

**it-Q0508 · Build the sentence**

Arrange: piace / qui? / non / ti / Perché

Why don't you like it here?

[[Italian#^it-Q0508-answer|Compare the answer]]
^it-Q0508

**it-Q0509 · Write a translation**

Write this in Italian: I don't want you to treat me any differently.

[[Italian#^it-Q0509-answer|Compare the answer]]
^it-Q0509

**it-Q0510 · Explain the grammar**

Io non voglio che voi 【mi】 trattiate in modo diverso.

I don't want you to treat me any differently.

[[Italian#^it-Q0510-answer|Compare the answer]]
^it-Q0510

**it-Q0511 · Fill the gap**

____ fa più rapidamente di te.

She does it faster than you.

[[Italian#^it-Q0511-answer|Compare the answer]]
^it-Q0511

**it-Q0512 · Choose the form**

____ fa più rapidamente di te.

She does it faster than you.

Choices: li / le / la / Lo

[[Italian#^it-Q0512-answer|Compare the answer]]
^it-Q0512

**it-Q0513 · Edit the changed sentence**

Perché 【lo】 dovrei scusare?

Why should I apologize?

[[Italian#^it-Q0513-answer|Compare the answer]]
^it-Q0513

**it-Q0514 · Build the sentence**

Arrange: scusare? / dovrei / mi / Perché

Why should I apologize?

[[Italian#^it-Q0514-answer|Compare the answer]]
^it-Q0514

**it-Q0515 · Write a translation**

Write this in Italian: He explained it to me.

[[Italian#^it-Q0515-answer|Compare the answer]]
^it-Q0515

**it-Q0516 · Explain the grammar**

Me 【la】 spiegò.

He explained it to me.

[[Italian#^it-Q0516-answer|Compare the answer]]
^it-Q0516

**it-Q0517 · Fill the gap**

____ assicurazioni proteggono da situazioni difficili impreviste.

Insurance protects against unforeseen predicaments.

[[Italian#^it-Q0517-answer|Compare the answer]]
^it-Q0517

**it-Q0518 · Choose the form**

____ assicurazioni proteggono da situazioni difficili impreviste.

Insurance protects against unforeseen predicaments.

Choices: la / lo / li / Le

[[Italian#^it-Q0518-answer|Compare the answer]]
^it-Q0518

**it-Q0519 · Edit the changed sentence**

Chi 【lo】 piace di più, Sachiko o Akiko?

Who do you like better, Sachiko or Akiko?

[[Italian#^it-Q0519-answer|Compare the answer]]
^it-Q0519

**it-Q0520 · Build the sentence**

Arrange: o / piace / Akiko? / ti / Chi / più, / di / Sachiko

Who do you like better, Sachiko or Akiko?

[[Italian#^it-Q0520-answer|Compare the answer]]
^it-Q0520

**it-Q0521 · Write a translation**

Write this in Italian: He lost his memory.

[[Italian#^it-Q0521-answer|Compare the answer]]
^it-Q0521

**it-Q0522 · Explain the grammar**

Lui perse 【la】 memoria.

He lost his memory.

[[Italian#^it-Q0522-answer|Compare the answer]]
^it-Q0522

**it-Q0523 · Fill the gap**

____ tenga lontano da me.

Keep him away from me.

[[Italian#^it-Q0523-answer|Compare the answer]]
^it-Q0523

**it-Q0524 · Choose the form**

____ tenga lontano da me.

Keep him away from me.

Choices: la / li / Lo / le

[[Italian#^it-Q0524-answer|Compare the answer]]
^it-Q0524

**it-Q0525 · Edit the changed sentence**

【lo】 odiano tutti.

Everybody hates her.

[[Italian#^it-Q0525-answer|Compare the answer]]
^it-Q0525

**it-Q0526 · Build the sentence**

Arrange: La / tutti. / odiano

Everybody hates her.

[[Italian#^it-Q0526-answer|Compare the answer]]
^it-Q0526

**it-Q0527 · Write a translation**

Write this in Italian: Are you still looking for her?

[[Italian#^it-Q0527-answer|Compare the answer]]
^it-Q0527

**it-Q0528 · Explain the grammar**

【La】 state ancora cercando?

Are you still looking for her?

[[Italian#^it-Q0528-answer|Compare the answer]]
^it-Q0528

**it-Q0529 · Fill the gap**

____ scusi, dov'è la biblioteca?

Excuse me, where is the library?

[[Italian#^it-Q0529-answer|Compare the answer]]
^it-Q0529

**it-Q0530 · Choose the form**

____ scusi, dov'è la biblioteca?

Excuse me, where is the library?

Choices: lo / Mi / li / la

[[Italian#^it-Q0530-answer|Compare the answer]]
^it-Q0530

**it-Q0531 · Edit the changed sentence**

Forse 【lo】 sbagliate.

Perhaps you are mistaken.

[[Italian#^it-Q0531-answer|Compare the answer]]
^it-Q0531

**it-Q0532 · Build the sentence**

Arrange: sbagliate. / vi / Forse

Perhaps you are mistaken.

[[Italian#^it-Q0532-answer|Compare the answer]]
^it-Q0532

**it-Q0533 · Write a translation**

Write this in Italian: Peel the apple before you eat it.

[[Italian#^it-Q0533-answer|Compare the answer]]
^it-Q0533

**it-Q0534 · Explain the grammar**

Sbucciate 【la】 mela prima di mangiarla.

Peel the apple before you eat it.

[[Italian#^it-Q0534-answer|Compare the answer]]
^it-Q0534

**it-Q0535 · Fill the gap**

Voi due ____ siete incontrati?

Have you two met?

[[Italian#^it-Q0535-answer|Compare the answer]]
^it-Q0535

**it-Q0536 · Choose the form**

Voi due ____ siete incontrati?

Have you two met?

Choices: la / li / vi / lo

[[Italian#^it-Q0536-answer|Compare the answer]]
^it-Q0536

**it-Q0537 · Edit the changed sentence**

【lo】 piace la storia.

I like history.

[[Italian#^it-Q0537-answer|Compare the answer]]
^it-Q0537

**it-Q0538 · Build the sentence**

Arrange: piace / Mi / storia. / la

I like history.

[[Italian#^it-Q0538-answer|Compare the answer]]
^it-Q0538

**it-Q0539 · Write a translation**

Write this in Italian: I never should've kissed Tom's girlfriend.

[[Italian#^it-Q0539-answer|Compare the answer]]
^it-Q0539

**it-Q0540 · Explain the grammar**

Io non avrei mai dovuto baciare 【la】 fidanzata di Tom.

I never should've kissed Tom's girlfriend.

[[Italian#^it-Q0540-answer|Compare the answer]]
^it-Q0540

**it-Q0541 · Fill the gap**

Tu ____ hai sparato.

You shot us.

[[Italian#^it-Q0541-answer|Compare the answer]]
^it-Q0541

**it-Q0542 · Choose the form**

Tu ____ hai sparato.

You shot us.

Choices: la / ci / li / lo

[[Italian#^it-Q0542-answer|Compare the answer]]
^it-Q0542

**it-Q0543 · Edit the changed sentence**

【lo】 patatine non ti fanno bene.

Potato chips are not good for you.

[[Italian#^it-Q0543-answer|Compare the answer]]
^it-Q0543

**it-Q0544 · Build the sentence**

Arrange: non / Le / patatine / ti / bene. / fanno

Potato chips are not good for you.

[[Italian#^it-Q0544-answer|Compare the answer]]
^it-Q0544

**it-Q0545 · Write a translation**

Write this in Italian: He is about my age.

[[Italian#^it-Q0545-answer|Compare the answer]]
^it-Q0545

**it-Q0546 · Explain the grammar**

Lui ha circa 【la】 mia età.

He is about my age.

[[Italian#^it-Q0546-answer|Compare the answer]]
^it-Q0546

**it-Q0547 · Fill the gap**

Qual è ____ tua boyband preferita?

What's your favorite boy band?

[[Italian#^it-Q0547-answer|Compare the answer]]
^it-Q0547

**it-Q0548 · Choose the form**

Qual è ____ tua boyband preferita?

What's your favorite boy band?

Choices: le / la / li / lo

[[Italian#^it-Q0548-answer|Compare the answer]]
^it-Q0548

**it-Q0549 · Edit the changed sentence**

Nessuno 【lo】 ha obbligato a farlo.

Nobody forced you to do that.

[[Italian#^it-Q0549-answer|Compare the answer]]
^it-Q0549

**it-Q0550 · Build the sentence**

Arrange: Nessuno / farlo. / ha / obbligato / a / ti

Nobody forced you to do that.

[[Italian#^it-Q0550-answer|Compare the answer]]
^it-Q0550


### Indirect objects · 50 questions

**it-Q0551 · Write a translation**

Write this in Italian: The moon came out from behind the clouds.

[[Italian#^it-Q0551-answer|Compare the answer]]
^it-Q0551

**it-Q0552 · Explain the grammar**

La luna è uscita da dietro 【le】 nuvole.

The moon came out from behind the clouds.

[[Italian#^it-Q0552-answer|Compare the answer]]
^it-Q0552

**it-Q0553 · Fill the gap**

____ piace il vino bianco?

Do you like white wine?

[[Italian#^it-Q0553-answer|Compare the answer]]
^it-Q0553

**it-Q0554 · Choose the form**

____ piace il vino bianco?

Do you like white wine?

Choices: gli / mi / Vi / le

[[Italian#^it-Q0554-answer|Compare the answer]]
^it-Q0554

**it-Q0555 · Edit the changed sentence**

Tom non 【gli】 ha ancora chiamata.

Tom hasn't called me yet.

[[Italian#^it-Q0555-answer|Compare the answer]]
^it-Q0555

**it-Q0556 · Build the sentence**

Arrange: Tom / mi / ancora / ha / chiamata. / non

Tom hasn't called me yet.

[[Italian#^it-Q0556-answer|Compare the answer]]
^it-Q0556

**it-Q0557 · Write a translation**

Write this in Italian: You should apologize to me.

[[Italian#^it-Q0557-answer|Compare the answer]]
^it-Q0557

**it-Q0558 · Explain the grammar**

【Ti】 dovresti scusare con me.

You should apologize to me.

[[Italian#^it-Q0558-answer|Compare the answer]]
^it-Q0558

**it-Q0559 · Fill the gap**

Calmatevi! Non ____ innervosite!

Calm down! Don't get nervous!

[[Italian#^it-Q0559-answer|Compare the answer]]
^it-Q0559

**it-Q0560 · Choose the form**

Calmatevi! Non ____ innervosite!

Calm down! Don't get nervous!

Choices: le / vi / gli / mi

[[Italian#^it-Q0560-answer|Compare the answer]]
^it-Q0560

**it-Q0561 · Edit the changed sentence**

"【gli】 odio." "Ti odio anch'io."

"I hate you." "I hate you, too."

[[Italian#^it-Q0561-answer|Compare the answer]]
^it-Q0561

**it-Q0562 · Build the sentence**

Arrange: odio." / "Ti / odio / anch'io." / "Ti

"I hate you." "I hate you, too."

[[Italian#^it-Q0562-answer|Compare the answer]]
^it-Q0562

**it-Q0563 · Write a translation**

Write this in Italian: Tom loved you.

[[Italian#^it-Q0563-answer|Compare the answer]]
^it-Q0563

**it-Q0564 · Explain the grammar**

Tom 【vi】 amava.

Tom loved you.

[[Italian#^it-Q0564-answer|Compare the answer]]
^it-Q0564

**it-Q0565 · Fill the gap**

____ sento sempre cupo.

I always feel gloomy.

[[Italian#^it-Q0565-answer|Compare the answer]]
^it-Q0565

**it-Q0566 · Choose the form**

____ sento sempre cupo.

I always feel gloomy.

Choices: ti / gli / le / Mi

[[Italian#^it-Q0566-answer|Compare the answer]]
^it-Q0566

**it-Q0567 · Edit the changed sentence**

【gli】 siamo aiutate l'un l'altra.

We helped one another.

[[Italian#^it-Q0567-answer|Compare the answer]]
^it-Q0567

**it-Q0568 · Build the sentence**

Arrange: l'altra. / aiutate / Ci / l'un / siamo

We helped one another.

[[Italian#^it-Q0568-answer|Compare the answer]]
^it-Q0568

**it-Q0569 · Write a translation**

Write this in Italian: It is almost ten o'clock.

[[Italian#^it-Q0569-answer|Compare the answer]]
^it-Q0569

**it-Q0570 · Explain the grammar**

Sono quasi 【le】 dieci.

It is almost ten o'clock.

[[Italian#^it-Q0570-answer|Compare the answer]]
^it-Q0570

**it-Q0571 · Fill the gap**

Tom non ____ disse tutto.

Tom didn't tell us everything.

[[Italian#^it-Q0571-answer|Compare the answer]]
^it-Q0571

**it-Q0572 · Choose the form**

Tom non ____ disse tutto.

Tom didn't tell us everything.

Choices: ci / mi / gli / le

[[Italian#^it-Q0572-answer|Compare the answer]]
^it-Q0572

**it-Q0573 · Edit the changed sentence**

【gli】 sue parole venivano dal cuore.

His words were heartfelt.

[[Italian#^it-Q0573-answer|Compare the answer]]
^it-Q0573

**it-Q0574 · Build the sentence**

Arrange: sue / parole / dal / cuore. / Le / venivano

His words were heartfelt.

[[Italian#^it-Q0574-answer|Compare the answer]]
^it-Q0574

**it-Q0575 · Write a translation**

Write this in Italian: I need some answers from him.

[[Italian#^it-Q0575-answer|Compare the answer]]
^it-Q0575

**it-Q0576 · Explain the grammar**

【Mi】 servono alcune risposte da lui.

I need some answers from him.

[[Italian#^it-Q0576-answer|Compare the answer]]
^it-Q0576

**it-Q0577 · Fill the gap**

____ esami finali stanno arrivando, per cui sono occupata.

Final exams are coming up, so I'm busy.

[[Italian#^it-Q0577-answer|Compare the answer]]
^it-Q0577

**it-Q0578 · Choose the form**

____ esami finali stanno arrivando, per cui sono occupata.

Final exams are coming up, so I'm busy.

Choices: Gli / ti / le / mi

[[Italian#^it-Q0578-answer|Compare the answer]]
^it-Q0578

**it-Q0579 · Edit the changed sentence**

La malattia 【gli】 ha impedito di andare all'estero.

Illness prevented me from going abroad.

[[Italian#^it-Q0579-answer|Compare the answer]]
^it-Q0579

**it-Q0580 · Build the sentence**

Arrange: andare / malattia / mi / ha / La / di / impedito / all'estero.

Illness prevented me from going abroad.

[[Italian#^it-Q0580-answer|Compare the answer]]
^it-Q0580

**it-Q0581 · Write a translation**

Write this in Italian: Let go of my arms!

[[Italian#^it-Q0581-answer|Compare the answer]]
^it-Q0581

**it-Q0582 · Explain the grammar**

Mollami 【le】 braccia!

Let go of my arms!

[[Italian#^it-Q0582-answer|Compare the answer]]
^it-Q0582

**it-Q0583 · Fill the gap**

Sapete mangiare con ____ bacchette?

Do you know how to eat with chopsticks?

[[Italian#^it-Q0583-answer|Compare the answer]]
^it-Q0583

**it-Q0584 · Choose the form**

Sapete mangiare con ____ bacchette?

Do you know how to eat with chopsticks?

Choices: gli / le / mi / ti

[[Italian#^it-Q0584-answer|Compare the answer]]
^it-Q0584

**it-Q0585 · Edit the changed sentence**

【gli】 piace leggere riviste.

She likes to read magazines.

[[Italian#^it-Q0585-answer|Compare the answer]]
^it-Q0585

**it-Q0586 · Build the sentence**

Arrange: leggere / piace / riviste. / Le

She likes to read magazines.

[[Italian#^it-Q0586-answer|Compare the answer]]
^it-Q0586

**it-Q0587 · Write a translation**

Write this in Italian: I don't know who killed them.

[[Italian#^it-Q0587-answer|Compare the answer]]
^it-Q0587

**it-Q0588 · Explain the grammar**

Non conosco chi 【le】 ha uccise.

I don't know who killed them.

[[Italian#^it-Q0588-answer|Compare the answer]]
^it-Q0588

**it-Q0589 · Fill the gap**

Io ____ sono sentito perso senza di lei.

I felt lost without you.

[[Italian#^it-Q0589-answer|Compare the answer]]
^it-Q0589

**it-Q0590 · Choose the form**

Io ____ sono sentito perso senza di lei.

I felt lost without you.

Choices: le / ti / mi / gli

[[Italian#^it-Q0590-answer|Compare the answer]]
^it-Q0590

**it-Q0591 · Edit the changed sentence**

Chiedi a Tom e Mary di portare 【gli】 loro chitarre.

Ask Tom and Mary to bring their guitars.

[[Italian#^it-Q0591-answer|Compare the answer]]
^it-Q0591

**it-Q0592 · Build the sentence**

Arrange: chitarre. / loro / Tom / portare / di / e / Chiedi / Mary / le / a

Ask Tom and Mary to bring their guitars.

[[Italian#^it-Q0592-answer|Compare the answer]]
^it-Q0592

**it-Q0593 · Write a translation**

Write this in Italian: He's using you.

[[Italian#^it-Q0593-answer|Compare the answer]]
^it-Q0593

**it-Q0594 · Explain the grammar**

Lui 【vi】 sta usando.

He's using you.

[[Italian#^it-Q0594-answer|Compare the answer]]
^it-Q0594

**it-Q0595 · Fill the gap**

____ comprerò una birra.

I'll buy her a beer.

[[Italian#^it-Q0595-answer|Compare the answer]]
^it-Q0595

**it-Q0596 · Choose the form**

____ comprerò una birra.

I'll buy her a beer.

Choices: Le / gli / ti / mi

[[Italian#^it-Q0596-answer|Compare the answer]]
^it-Q0596

**it-Q0597 · Edit the changed sentence**

Il bingo è qualcosa a cui giocano 【gli】 nonne.

Bingo is something that grandmothers play.

[[Italian#^it-Q0597-answer|Compare the answer]]
^it-Q0597

**it-Q0598 · Build the sentence**

Arrange: cui / Il / giocano / qualcosa / bingo / è / nonne. / a / le

Bingo is something that grandmothers play.

[[Italian#^it-Q0598-answer|Compare the answer]]
^it-Q0598

**it-Q0599 · Write a translation**

Write this in Italian: You didn't prepare me for this.

[[Italian#^it-Q0599-answer|Compare the answer]]
^it-Q0599

**it-Q0600 · Explain the grammar**

Tu non 【mi】 hai preparata per questo.

You didn't prepare me for this.

[[Italian#^it-Q0600-answer|Compare the answer]]
^it-Q0600


### Ci and ne · 50 questions

**it-Q0601 · Fill the gap**

____ sono delle lettere per me nella posta di oggi?

Are there any letters to me in today's mail?

[[Italian#^it-Q0601-answer|Compare the answer]]
^it-Q0601

**it-Q0602 · Choose the form**

____ sono delle lettere per me nella posta di oggi?

Are there any letters to me in today's mail?

Choices: gli / Ci / ne / lo

[[Italian#^it-Q0602-answer|Compare the answer]]
^it-Q0602

**it-Q0603 · Edit the changed sentence**

【ne】 lamentiamo dei nostri vicini.

We complain about our neighbors.

[[Italian#^it-Q0603-answer|Compare the answer]]
^it-Q0603

**it-Q0604 · Build the sentence**

Arrange: Ci / vicini. / dei / nostri / lamentiamo

We complain about our neighbors.

[[Italian#^it-Q0604-answer|Compare the answer]]
^it-Q0604

**it-Q0605 · Write a translation**

Write this in Italian: The other team took us lightly.

[[Italian#^it-Q0605-answer|Compare the answer]]
^it-Q0605

**it-Q0606 · Explain the grammar**

L'altra squadra 【ci】 ha presi alla leggera.

The other team took us lightly.

[[Italian#^it-Q0606-answer|Compare the answer]]
^it-Q0606

**it-Q0607 · Fill the gap**

Non ____ arriverai in tempo.

You won't get there on time.

[[Italian#^it-Q0607-answer|Compare the answer]]
^it-Q0607

**it-Q0608 · Choose the form**

Non ____ arriverai in tempo.

You won't get there on time.

Choices: ne / lo / gli / ci

[[Italian#^it-Q0608-answer|Compare the answer]]
^it-Q0608

**it-Q0609 · Edit the changed sentence**

【ne】 ha accolte con un sorriso.

She greeted us with a smile.

[[Italian#^it-Q0609-answer|Compare the answer]]
^it-Q0609

**it-Q0610 · Build the sentence**

Arrange: un / sorriso. / accolte / con / Ci / ha

She greeted us with a smile.

[[Italian#^it-Q0610-answer|Compare the answer]]
^it-Q0610

**it-Q0611 · Write a translation**

Write this in Italian: It took three hours to put the broken toy together.

[[Italian#^it-Q0611-answer|Compare the answer]]
^it-Q0611

**it-Q0612 · Explain the grammar**

【Ci】 sono volute tre ore per riparare il giocattolo rotto.

It took three hours to put the broken toy together.

[[Italian#^it-Q0612-answer|Compare the answer]]
^it-Q0612

**it-Q0613 · Fill the gap**

Pensate che ____ vorrà molto in autobus?

Do you think it will take long by bus?

[[Italian#^it-Q0613-answer|Compare the answer]]
^it-Q0613

**it-Q0614 · Choose the form**

Pensate che ____ vorrà molto in autobus?

Do you think it will take long by bus?

Choices: ne / ci / lo / gli

[[Italian#^it-Q0614-answer|Compare the answer]]
^it-Q0614

**it-Q0615 · Edit the changed sentence**

Non 【ci】 vedo davvero l'ora.

I'm really looking forward to this.

[[Italian#^it-Q0615-answer|Compare the answer]]
^it-Q0615

**it-Q0616 · Build the sentence**

Arrange: l'ora. / vedo / ne / davvero / Non

I'm really looking forward to this.

[[Italian#^it-Q0616-answer|Compare the answer]]
^it-Q0616

**it-Q0617 · Write a translation**

Write this in Italian: There are eleven people in a soccer team.

[[Italian#^it-Q0617-answer|Compare the answer]]
^it-Q0617

**it-Q0618 · Explain the grammar**

【Ci】 sono undici persone in una squadra di calcio.

There are eleven people in a soccer team.

[[Italian#^it-Q0618-answer|Compare the answer]]
^it-Q0618

**it-Q0619 · Fill the gap**

Non ____ vorrà molto prima che stia meglio.

It will not be long before he gets better.

[[Italian#^it-Q0619-answer|Compare the answer]]
^it-Q0619

**it-Q0620 · Choose the form**

Non ____ vorrà molto prima che stia meglio.

It will not be long before he gets better.

Choices: lo / gli / ne / ci

[[Italian#^it-Q0620-answer|Compare the answer]]
^it-Q0620

**it-Q0621 · Edit the changed sentence**

Se 【ci】 va presto, vero?

He's leaving soon, isn't he?

[[Italian#^it-Q0621-answer|Compare the answer]]
^it-Q0621

**it-Q0622 · Build the sentence**

Arrange: ne / Se / presto, / va / vero?

He's leaving soon, isn't he?

[[Italian#^it-Q0622-answer|Compare the answer]]
^it-Q0622

**it-Q0623 · Write a translation**

Write this in Italian: Is there any salt left?

[[Italian#^it-Q0623-answer|Compare the answer]]
^it-Q0623

**it-Q0624 · Explain the grammar**

【Ci】 rimane del sale?

Is there any salt left?

[[Italian#^it-Q0624-answer|Compare the answer]]
^it-Q0624

**it-Q0625 · Fill the gap**

Tom non ____ ha detto cos'è capitato dopo.

Tom didn't tell us what happened next.

[[Italian#^it-Q0625-answer|Compare the answer]]
^it-Q0625

**it-Q0626 · Choose the form**

Tom non ____ ha detto cos'è capitato dopo.

Tom didn't tell us what happened next.

Choices: ci / gli / lo / ne

[[Italian#^it-Q0626-answer|Compare the answer]]
^it-Q0626

**it-Q0627 · Edit the changed sentence**

【ne】 sei davvero mancato.

We really missed you.

[[Italian#^it-Q0627-answer|Compare the answer]]
^it-Q0627

**it-Q0628 · Build the sentence**

Arrange: davvero / Ci / sei / mancato.

We really missed you.

[[Italian#^it-Q0628-answer|Compare the answer]]
^it-Q0628

**it-Q0629 · Write a translation**

Write this in Italian: He brought us sad news.

[[Italian#^it-Q0629-answer|Compare the answer]]
^it-Q0629

**it-Q0630 · Explain the grammar**

【Ci】 ha portato delle notizie tristi.

He brought us sad news.

[[Italian#^it-Q0630-answer|Compare the answer]]
^it-Q0630

**it-Q0631 · Fill the gap**

Apparentemente in questa biblioteca ____ sono dei libri preziosi che il denaro non può comprare.

Apparently in this library are precious books that money can't buy.

[[Italian#^it-Q0631-answer|Compare the answer]]
^it-Q0631

**it-Q0632 · Choose the form**

Apparentemente in questa biblioteca ____ sono dei libri preziosi che il denaro non può comprare.

Apparently in this library are precious books that money can't buy.

Choices: ci / ne / lo / gli

[[Italian#^it-Q0632-answer|Compare the answer]]
^it-Q0632

**it-Q0633 · Edit the changed sentence**

Andiamo a vedere se Tom 【ne】 può aiutare.

Let's go see if Tom can help us.

[[Italian#^it-Q0633-answer|Compare the answer]]
^it-Q0633

**it-Q0634 · Build the sentence**

Arrange: a / può / Andiamo / aiutare. / vedere / se / Tom / ci

Let's go see if Tom can help us.

[[Italian#^it-Q0634-answer|Compare the answer]]
^it-Q0634

**it-Q0635 · Write a translation**

Write this in Italian: Mary has ordered one.

[[Italian#^it-Q0635-answer|Compare the answer]]
^it-Q0635

**it-Q0636 · Explain the grammar**

Mary 【ne】 ha ordinata una.

Mary has ordered one.

[[Italian#^it-Q0636-answer|Compare the answer]]
^it-Q0636

**it-Q0637 · Fill the gap**

____ si aspetta che lo faccia, vero?

He's expected to do that, isn't he?

[[Italian#^it-Q0637-answer|Compare the answer]]
^it-Q0637

**it-Q0638 · Choose the form**

____ si aspetta che lo faccia, vero?

He's expected to do that, isn't he?

Choices: gli / lo / ne / Ci

[[Italian#^it-Q0638-answer|Compare the answer]]
^it-Q0638

**it-Q0639 · Edit the changed sentence**

Per quando 【ci】 avete bisogno?

When do you need it by?

[[Italian#^it-Q0639-answer|Compare the answer]]
^it-Q0639

**it-Q0640 · Build the sentence**

Arrange: Per / bisogno? / avete / quando / ne

When do you need it by?

[[Italian#^it-Q0640-answer|Compare the answer]]
^it-Q0640

**it-Q0641 · Write a translation**

Write this in Italian: I don't give a damn about it!

[[Italian#^it-Q0641-answer|Compare the answer]]
^it-Q0641

**it-Q0642 · Explain the grammar**

Non me 【ne】 frega un accidente!

I don't give a damn about it!

[[Italian#^it-Q0642-answer|Compare the answer]]
^it-Q0642

**it-Q0643 · Fill the gap**

Tom ____ conosce.

Tom knows us.

[[Italian#^it-Q0643-answer|Compare the answer]]
^it-Q0643

**it-Q0644 · Choose the form**

Tom ____ conosce.

Tom knows us.

Choices: gli / ci / ne / lo

[[Italian#^it-Q0644-answer|Compare the answer]]
^it-Q0644

**it-Q0645 · Edit the changed sentence**

Perché non 【ne】 sono dei file audio per l'arabo?

Why aren't there audio files for Arabic?

[[Italian#^it-Q0645-answer|Compare the answer]]
^it-Q0645

**it-Q0646 · Build the sentence**

Arrange: ci / dei / per / audio / Perché / file / sono / l'arabo? / non

Why aren't there audio files for Arabic?

[[Italian#^it-Q0646-answer|Compare the answer]]
^it-Q0646

**it-Q0647 · Write a translation**

Write this in Italian: We relaxed in the living room.

[[Italian#^it-Q0647-answer|Compare the answer]]
^it-Q0647

**it-Q0648 · Explain the grammar**

【Ci】 siamo rilassate in salotto.

We relaxed in the living room.

[[Italian#^it-Q0648-answer|Compare the answer]]
^it-Q0648

**it-Q0649 · Fill the gap**

____ hanno ignorati tutti.

Everyone ignored us.

[[Italian#^it-Q0649-answer|Compare the answer]]
^it-Q0649

**it-Q0650 · Choose the form**

____ hanno ignorati tutti.

Everyone ignored us.

Choices: Ci / gli / lo / ne

[[Italian#^it-Q0650-answer|Compare the answer]]
^it-Q0650


### Reflexive and impersonal si · 50 questions

**it-Q0651 · Edit the changed sentence**

【ci】 sente molto felice.

He feels very happy.

[[Italian#^it-Q0651-answer|Compare the answer]]
^it-Q0651

**it-Q0652 · Build the sentence**

Arrange: felice. / molto / sente / Si

He feels very happy.

[[Italian#^it-Q0652-answer|Compare the answer]]
^it-Q0652

**it-Q0653 · Write a translation**

Write this in Italian: The more one works, the more one earns.

[[Italian#^it-Q0653-answer|Compare the answer]]
^it-Q0653

**it-Q0654 · Explain the grammar**

Più 【si】 lavora, più si guadagna.

The more one works, the more one earns.

[[Italian#^it-Q0654-answer|Compare the answer]]
^it-Q0654

**it-Q0655 · Fill the gap**

____ fidavano di lui.

They trusted him.

[[Italian#^it-Q0655-answer|Compare the answer]]
^it-Q0655

**it-Q0656 · Choose the form**

____ fidavano di lui.

They trusted him.

Choices: lo / ci / ne / Si

[[Italian#^it-Q0656-answer|Compare the answer]]
^it-Q0656

**it-Q0657 · Edit the changed sentence**

Goccia dopo goccia, il lago 【ci】 riempie.

Drop by drop, the lake fills.

[[Italian#^it-Q0657-answer|Compare the answer]]
^it-Q0657

**it-Q0658 · Build the sentence**

Arrange: riempie. / dopo / goccia, / si / il / lago / Goccia

Drop by drop, the lake fills.

[[Italian#^it-Q0658-answer|Compare the answer]]
^it-Q0658

**it-Q0659 · Write a translation**

Write this in Italian: Tom is meeting Mary this afternoon.

[[Italian#^it-Q0659-answer|Compare the answer]]
^it-Q0659

**it-Q0660 · Explain the grammar**

Tom 【si】 incontra con Mary questo pomeriggio.

Tom is meeting Mary this afternoon.

[[Italian#^it-Q0660-answer|Compare the answer]]
^it-Q0660

**it-Q0661 · Fill the gap**

Non ____ scordi di votare.

Don't forget to vote.

[[Italian#^it-Q0661-answer|Compare the answer]]
^it-Q0661

**it-Q0662 · Choose the form**

Non ____ scordi di votare.

Don't forget to vote.

Choices: ne / ci / lo / si

[[Italian#^it-Q0662-answer|Compare the answer]]
^it-Q0662

**it-Q0663 · Edit the changed sentence**

Tom 【ci】 ritirò dalla vita pubblica.

Tom retired from public life.

[[Italian#^it-Q0663-answer|Compare the answer]]
^it-Q0663

**it-Q0664 · Build the sentence**

Arrange: dalla / si / Tom / ritirò / pubblica. / vita

Tom retired from public life.

[[Italian#^it-Q0664-answer|Compare the answer]]
^it-Q0664

**it-Q0665 · Write a translation**

Write this in Italian: Tom got really angry.

[[Italian#^it-Q0665-answer|Compare the answer]]
^it-Q0665

**it-Q0666 · Explain the grammar**

Tom 【si】 è veramente arrabbiato.

Tom got really angry.

[[Italian#^it-Q0666-answer|Compare the answer]]
^it-Q0666

**it-Q0667 · Fill the gap**

Jack non ____ può permettere una nuova bici.

Jack can't afford a new bicycle.

[[Italian#^it-Q0667-answer|Compare the answer]]
^it-Q0667

**it-Q0668 · Choose the form**

Jack non ____ può permettere una nuova bici.

Jack can't afford a new bicycle.

Choices: lo / si / ci / ne

[[Italian#^it-Q0668-answer|Compare the answer]]
^it-Q0668

**it-Q0669 · Edit the changed sentence**

Tom 【ci】 scusò di nuovo.

Tom apologized again.

[[Italian#^it-Q0669-answer|Compare the answer]]
^it-Q0669

**it-Q0670 · Build the sentence**

Arrange: nuovo. / Tom / di / si / scusò

Tom apologized again.

[[Italian#^it-Q0670-answer|Compare the answer]]
^it-Q0670

**it-Q0671 · Write a translation**

Write this in Italian: It's getting hotter.

[[Italian#^it-Q0671-answer|Compare the answer]]
^it-Q0671

**it-Q0672 · Explain the grammar**

【Si】 sta facendo più caldo.

It's getting hotter.

[[Italian#^it-Q0672-answer|Compare the answer]]
^it-Q0672

**it-Q0673 · Fill the gap**

Nella mia città c'è un autobus speciale, chiamato BLQ, che parte dall'aeroporto e ____ ferma vicino a casa mia.

In my city there is a special bus, called BLQ, which leaves from the airport and stops near my house.

[[Italian#^it-Q0673-answer|Compare the answer]]
^it-Q0673

**it-Q0674 · Choose the form**

Nella mia città c'è un autobus speciale, chiamato BLQ, che parte dall'aeroporto e ____ ferma vicino a casa mia.

In my city there is a special bus, called BLQ, which leaves from the airport and stops near my house.

Choices: ci / lo / ne / si

[[Italian#^it-Q0674-answer|Compare the answer]]
^it-Q0674

**it-Q0675 · Edit the changed sentence**

Quando due "maschi alfa" 【ci】 riuniscono in un gruppo, è emozionante vedere chi prende il sopravvento.

When two "Alpha males" come together in a group, it is exciting to see who holds the upper hand.

[[Italian#^it-Q0675-answer|Compare the answer]]
^it-Q0675

**it-Q0676 · Build the sentence**

Arrange: in / riuniscono / chi / il / vedere / "maschi / emozionante / si / gruppo, / un / due / alfa" / prende / Quando / è / sopravvento.

When two "Alpha males" come together in a group, it is exciting to see who holds the upper hand.

[[Italian#^it-Q0676-answer|Compare the answer]]
^it-Q0676

**it-Q0677 · Write a translation**

Write this in Italian: Tom noticed that Mary was following him.

[[Italian#^it-Q0677-answer|Compare the answer]]
^it-Q0677

**it-Q0678 · Explain the grammar**

Tom 【si】 accorse che Mary lo stava seguendo.

Tom noticed that Mary was following him.

[[Italian#^it-Q0678-answer|Compare the answer]]
^it-Q0678

**it-Q0679 · Fill the gap**

La pioggia non ____ è ancora fermata.

The rain hasn't stopped yet.

[[Italian#^it-Q0679-answer|Compare the answer]]
^it-Q0679

**it-Q0680 · Choose the form**

La pioggia non ____ è ancora fermata.

The rain hasn't stopped yet.

Choices: lo / si / ne / ci

[[Italian#^it-Q0680-answer|Compare the answer]]
^it-Q0680

**it-Q0681 · Edit the changed sentence**

La coppa 【ci】 ruppe.

The cup broke.

[[Italian#^it-Q0681-answer|Compare the answer]]
^it-Q0681

**it-Q0682 · Build the sentence**

Arrange: La / coppa / ruppe. / si

The cup broke.

[[Italian#^it-Q0682-answer|Compare the answer]]
^it-Q0682

**it-Q0683 · Write a translation**

Write this in Italian: In the hospital room, the nurse wearing white clothes and the midwife were preparing for the delivery.

[[Italian#^it-Q0683-answer|Compare the answer]]
^it-Q0683

**it-Q0684 · Explain the grammar**

Nella stanza d'ospedale, l'infermiera che indossava abiti bianchi e la levatrice 【si】 stavano preparando per il parto.

In the hospital room, the nurse wearing white clothes and the midwife were preparing for the delivery.

[[Italian#^it-Q0684-answer|Compare the answer]]
^it-Q0684

**it-Q0685 · Fill the gap**

Questa città ____ trova in Francia.

This city is located in France.

[[Italian#^it-Q0685-answer|Compare the answer]]
^it-Q0685

**it-Q0686 · Choose the form**

Questa città ____ trova in Francia.

This city is located in France.

Choices: ci / ne / lo / si

[[Italian#^it-Q0686-answer|Compare the answer]]
^it-Q0686

**it-Q0687 · Edit the changed sentence**

Mescolando blu e rosso 【ci】 ottiene il viola.

If you mix blue and red, you'll get purple.

[[Italian#^it-Q0687-answer|Compare the answer]]
^it-Q0687

**it-Q0688 · Build the sentence**

Arrange: rosso / e / Mescolando / il / si / viola. / blu / ottiene

If you mix blue and red, you'll get purple.

[[Italian#^it-Q0688-answer|Compare the answer]]
^it-Q0688

**it-Q0689 · Write a translation**

Write this in Italian: Tom and Mary exchanged numbers.

[[Italian#^it-Q0689-answer|Compare the answer]]
^it-Q0689

**it-Q0690 · Explain the grammar**

Tom e Mary 【si】 scambiarono i numeri.

Tom and Mary exchanged numbers.

[[Italian#^it-Q0690-answer|Compare the answer]]
^it-Q0690

**it-Q0691 · Fill the gap**

La filosofia non è una cosa che ____ può imparare in sei mesi.

Philosophy is not a thing one can learn in six months.

[[Italian#^it-Q0691-answer|Compare the answer]]
^it-Q0691

**it-Q0692 · Choose the form**

La filosofia non è una cosa che ____ può imparare in sei mesi.

Philosophy is not a thing one can learn in six months.

Choices: ci / lo / si / ne

[[Italian#^it-Q0692-answer|Compare the answer]]
^it-Q0692

**it-Q0693 · Edit the changed sentence**

Sei sicura che Tom non 【ci】 ricorderà nulla?

Are you sure Tom won't remember anything?

[[Italian#^it-Q0693-answer|Compare the answer]]
^it-Q0693

**it-Q0694 · Build the sentence**

Arrange: che / ricorderà / nulla? / si / sicura / Sei / non / Tom

Are you sure Tom won't remember anything?

[[Italian#^it-Q0694-answer|Compare the answer]]
^it-Q0694

**it-Q0695 · Write a translation**

Write this in Italian: Tom approaches.

[[Italian#^it-Q0695-answer|Compare the answer]]
^it-Q0695

**it-Q0696 · Explain the grammar**

Tom 【si】 avvicina.

Tom approaches.

[[Italian#^it-Q0696-answer|Compare the answer]]
^it-Q0696

**it-Q0697 · Fill the gap**

____ è sposata all'età di 25 anni.

She got married at the age of 25.

[[Italian#^it-Q0697-answer|Compare the answer]]
^it-Q0697

**it-Q0698 · Choose the form**

____ è sposata all'età di 25 anni.

She got married at the age of 25.

Choices: ci / lo / Si / ne

[[Italian#^it-Q0698-answer|Compare the answer]]
^it-Q0698

**it-Q0699 · Edit the changed sentence**

Alcuni ragazzi a scuola 【ci】 prendono gioco di me.

Some boys at school make fun of me.

[[Italian#^it-Q0699-answer|Compare the answer]]
^it-Q0699

**it-Q0700 · Build the sentence**

Arrange: ragazzi / me. / Alcuni / di / scuola / si / gioco / prendono / a

Some boys at school make fun of me.

[[Italian#^it-Q0700-answer|Compare the answer]]
^it-Q0700


### Relative clauses · 50 questions

**it-Q0701 · Write a translation**

Write this in Italian: Listen well to what I say.

[[Italian#^it-Q0701-answer|Compare the answer]]
^it-Q0701

**it-Q0702 · Explain the grammar**

Ascoltate bene quello 【che】 dico.

Listen well to what I say.

[[Italian#^it-Q0702-answer|Compare the answer]]
^it-Q0702

**it-Q0703 · Fill the gap**

Pensa ____ Tom stia ancora dormendo?

Do you think Tom is still asleep?

[[Italian#^it-Q0703-answer|Compare the answer]]
^it-Q0703

**it-Q0704 · Choose the form**

Pensa ____ Tom stia ancora dormendo?

Do you think Tom is still asleep?

Choices: che / quale / cui / dove

[[Italian#^it-Q0704-answer|Compare the answer]]
^it-Q0704

**it-Q0705 · Edit the changed sentence**

Tom e Mary dissero 【cui】 non volevano più studiare il francese.

Tom and Mary said they didn't want to study French anymore.

[[Italian#^it-Q0705-answer|Compare the answer]]
^it-Q0705

**it-Q0706 · Build the sentence**

Arrange: non / che / il / più / Tom / dissero / e / Mary / volevano / francese. / studiare

Tom and Mary said they didn't want to study French anymore.

[[Italian#^it-Q0706-answer|Compare the answer]]
^it-Q0706

**it-Q0707 · Write a translation**

Write this in Italian: Be careful what you wish for.

[[Italian#^it-Q0707-answer|Compare the answer]]
^it-Q0707

**it-Q0708 · Explain the grammar**

Attenta a quello 【che】 desidera.

Be careful what you wish for.

[[Italian#^it-Q0708-answer|Compare the answer]]
^it-Q0708

**it-Q0709 · Fill the gap**

Io odio i passeggeri ____ criticano il guidatore.

I hate backseat drivers.

[[Italian#^it-Q0709-answer|Compare the answer]]
^it-Q0709

**it-Q0710 · Choose the form**

Io odio i passeggeri ____ criticano il guidatore.

I hate backseat drivers.

Choices: quale / dove / che / cui

[[Italian#^it-Q0710-answer|Compare the answer]]
^it-Q0710

**it-Q0711 · Edit the changed sentence**

【che】 va per Natale?

Where do you go for Christmas?

[[Italian#^it-Q0711-answer|Compare the answer]]
^it-Q0711

**it-Q0712 · Build the sentence**

Arrange: Dove / va / Natale? / per

Where do you go for Christmas?

[[Italian#^it-Q0712-answer|Compare the answer]]
^it-Q0712

**it-Q0713 · Write a translation**

Write this in Italian: By all means maintain an open mind, but not so open that your brain falls out.

[[Italian#^it-Q0713-answer|Compare the answer]]
^it-Q0713

**it-Q0714 · Explain the grammar**

Mantieni ad ogni costo una mente aperta, ma non così aperta 【che】 il tuo cervello caschi fuori.

By all means maintain an open mind, but not so open that your brain falls out.

[[Italian#^it-Q0714-answer|Compare the answer]]
^it-Q0714

**it-Q0715 · Fill the gap**

Lo sapeva ____ ero sposata.

You knew I was married.

[[Italian#^it-Q0715-answer|Compare the answer]]
^it-Q0715

**it-Q0716 · Choose the form**

Lo sapeva ____ ero sposata.

You knew I was married.

Choices: dove / che / quale / cui

[[Italian#^it-Q0716-answer|Compare the answer]]
^it-Q0716

**it-Q0717 · Edit the changed sentence**

Dissi a Tom 【cui】 stavo andando a Boston.

I told Tom I was going to Boston.

[[Italian#^it-Q0717-answer|Compare the answer]]
^it-Q0717

**it-Q0718 · Build the sentence**

Arrange: Tom / Boston. / Dissi / a / a / che / stavo / andando

I told Tom I was going to Boston.

[[Italian#^it-Q0718-answer|Compare the answer]]
^it-Q0718

**it-Q0719 · Write a translation**

Write this in Italian: I have nothing to do with the scandal.

[[Italian#^it-Q0719-answer|Compare the answer]]
^it-Q0719

**it-Q0720 · Explain the grammar**

Non ho niente a 【che】 fare con lo scandalo.

I have nothing to do with the scandal.

[[Italian#^it-Q0720-answer|Compare the answer]]
^it-Q0720

**it-Q0721 · Fill the gap**

Lo so ____ potete venire!

I know you can come!

[[Italian#^it-Q0721-answer|Compare the answer]]
^it-Q0721

**it-Q0722 · Choose the form**

Lo so ____ potete venire!

I know you can come!

Choices: dove / che / quale / cui

[[Italian#^it-Q0722-answer|Compare the answer]]
^it-Q0722

**it-Q0723 · Edit the changed sentence**

Io penso 【cui】 Tom stia morendo.

I think Tom is dying.

[[Italian#^it-Q0723-answer|Compare the answer]]
^it-Q0723

**it-Q0724 · Build the sentence**

Arrange: penso / Io / che / morendo. / Tom / stia

I think Tom is dying.

[[Italian#^it-Q0724-answer|Compare the answer]]
^it-Q0724

**it-Q0725 · Write a translation**

Write this in Italian: I just heard you visited Tom.

[[Italian#^it-Q0725-answer|Compare the answer]]
^it-Q0725

**it-Q0726 · Explain the grammar**

Ho appena sentito 【che】 siete andati a trovare Tom.

I just heard you visited Tom.

[[Italian#^it-Q0726-answer|Compare the answer]]
^it-Q0726

**it-Q0727 · Fill the gap**

Quella è la donna ____ vuole vedervi.

That's the woman who wants to see you.

[[Italian#^it-Q0727-answer|Compare the answer]]
^it-Q0727

**it-Q0728 · Choose the form**

Quella è la donna ____ vuole vedervi.

That's the woman who wants to see you.

Choices: quale / dove / che / cui

[[Italian#^it-Q0728-answer|Compare the answer]]
^it-Q0728

**it-Q0729 · Edit the changed sentence**

Sapeva 【cui】 la amavo.

He knew that I loved her.

[[Italian#^it-Q0729-answer|Compare the answer]]
^it-Q0729

**it-Q0730 · Build the sentence**

Arrange: amavo. / Sapeva / che / la

He knew that I loved her.

[[Italian#^it-Q0730-answer|Compare the answer]]
^it-Q0730

**it-Q0731 · Write a translation**

Write this in Italian: This is the very book you wanted.

[[Italian#^it-Q0731-answer|Compare the answer]]
^it-Q0731

**it-Q0732 · Explain the grammar**

Questo è proprio il libro 【che】 volevi.

This is the very book you wanted.

[[Italian#^it-Q0732-answer|Compare the answer]]
^it-Q0732

**it-Q0733 · Fill the gap**

Lo sapeva ____ Mesut Özil, il famoso calciatore tedesco, è anche turco?

Did you know that Mesut Özil, the famous German footballer, is also Turkish?

[[Italian#^it-Q0733-answer|Compare the answer]]
^it-Q0733

**it-Q0734 · Choose the form**

Lo sapeva ____ Mesut Özil, il famoso calciatore tedesco, è anche turco?

Did you know that Mesut Özil, the famous German footballer, is also Turkish?

Choices: dove / quale / cui / che

[[Italian#^it-Q0734-answer|Compare the answer]]
^it-Q0734

**it-Q0735 · Edit the changed sentence**

Voi pensate 【cui】 Tom avesse fame?

Do you think Tom was hungry?

[[Italian#^it-Q0735-answer|Compare the answer]]
^it-Q0735

**it-Q0736 · Build the sentence**

Arrange: Voi / avesse / che / pensate / fame? / Tom

Do you think Tom was hungry?

[[Italian#^it-Q0736-answer|Compare the answer]]
^it-Q0736

**it-Q0737 · Write a translation**

Write this in Italian: Everything that's happening is Tom's fault.

[[Italian#^it-Q0737-answer|Compare the answer]]
^it-Q0737

**it-Q0738 · Explain the grammar**

Tutto quello 【che】 sta succedendo è colpa di Tom.

Everything that's happening is Tom's fault.

[[Italian#^it-Q0738-answer|Compare the answer]]
^it-Q0738

**it-Q0739 · Fill the gap**

Dirò a Tom ____ hai finito il rapporto.

I'll tell Tom you finished the report.

[[Italian#^it-Q0739-answer|Compare the answer]]
^it-Q0739

**it-Q0740 · Choose the form**

Dirò a Tom ____ hai finito il rapporto.

I'll tell Tom you finished the report.

Choices: quale / che / cui / dove

[[Italian#^it-Q0740-answer|Compare the answer]]
^it-Q0740

**it-Q0741 · Edit the changed sentence**

【che】 sei ferita?

Where are you hurt?

[[Italian#^it-Q0741-answer|Compare the answer]]
^it-Q0741

**it-Q0742 · Build the sentence**

Arrange: ferita? / Dove / sei

Where are you hurt?

[[Italian#^it-Q0742-answer|Compare the answer]]
^it-Q0742

**it-Q0743 · Write a translation**

Write this in Italian: All that you have to do is to follow his advice.

[[Italian#^it-Q0743-answer|Compare the answer]]
^it-Q0743

**it-Q0744 · Explain the grammar**

Tutto quello 【che】 deve fare è seguire il suo consiglio.

All that you have to do is to follow his advice.

[[Italian#^it-Q0744-answer|Compare the answer]]
^it-Q0744

**it-Q0745 · Fill the gap**

Lei cosa pensa ____ stia causando questo problema?

What do you think's causing this problem?

[[Italian#^it-Q0745-answer|Compare the answer]]
^it-Q0745

**it-Q0746 · Choose the form**

Lei cosa pensa ____ stia causando questo problema?

What do you think's causing this problem?

Choices: quale / cui / dove / che

[[Italian#^it-Q0746-answer|Compare the answer]]
^it-Q0746

**it-Q0747 · Edit the changed sentence**

Tom non pensa 【cui】 io lo debba fare.

Tom doesn't think I need to do that.

[[Italian#^it-Q0747-answer|Compare the answer]]
^it-Q0747

**it-Q0748 · Build the sentence**

Arrange: fare. / debba / pensa / lo / io / Tom / che / non

Tom doesn't think I need to do that.

[[Italian#^it-Q0748-answer|Compare the answer]]
^it-Q0748

**it-Q0749 · Write a translation**

Write this in Italian: Tom doesn't seem to know the answer.

[[Italian#^it-Q0749-answer|Compare the answer]]
^it-Q0749

**it-Q0750 · Explain the grammar**

Sembra 【che】 Tom non sappia la risposta.

Tom doesn't seem to know the answer.

[[Italian#^it-Q0750-answer|Compare the answer]]
^it-Q0750


### Negation · 50 questions

**it-Q0751 · Fill the gap**

Io ____ devo seguire Tom.

I don't have to follow Tom.

[[Italian#^it-Q0751-answer|Compare the answer]]
^it-Q0751

**it-Q0752 · Choose the form**

Io ____ devo seguire Tom.

I don't have to follow Tom.

Choices: niente / non / nessuno / mai

[[Italian#^it-Q0752-answer|Compare the answer]]
^it-Q0752

**it-Q0753 · Edit the changed sentence**

【mai】 voglio sedermi accanto a loro.

I don't want to sit next to them.

[[Italian#^it-Q0753-answer|Compare the answer]]
^it-Q0753

**it-Q0754 · Build the sentence**

Arrange: a / voglio / accanto / sedermi / Non / loro.

I don't want to sit next to them.

[[Italian#^it-Q0754-answer|Compare the answer]]
^it-Q0754

**it-Q0755 · Write a translation**

Write this in Italian: She says she isn't lazy.

[[Italian#^it-Q0755-answer|Compare the answer]]
^it-Q0755

**it-Q0756 · Explain the grammar**

Dice di 【non】 essere pigra.

She says she isn't lazy.

[[Italian#^it-Q0756-answer|Compare the answer]]
^it-Q0756

**it-Q0757 · Fill the gap**

____ può permetterselo.

She can't afford it.

[[Italian#^it-Q0757-answer|Compare the answer]]
^it-Q0757

**it-Q0758 · Choose the form**

____ può permetterselo.

She can't afford it.

Choices: nessuno / niente / mai / Non

[[Italian#^it-Q0758-answer|Compare the answer]]
^it-Q0758

**it-Q0759 · Edit the changed sentence**

【mai】 leggete in questa stanza.

Don't read in this room.

[[Italian#^it-Q0759-answer|Compare the answer]]
^it-Q0759

**it-Q0760 · Build the sentence**

Arrange: questa / stanza. / Non / in / leggete

Don't read in this room.

[[Italian#^it-Q0760-answer|Compare the answer]]
^it-Q0760

**it-Q0761 · Write a translation**

Write this in Italian: I didn't ask Tom to sing.

[[Italian#^it-Q0761-answer|Compare the answer]]
^it-Q0761

**it-Q0762 · Explain the grammar**

【Non】 chiesi a Tom di cantare.

I didn't ask Tom to sing.

[[Italian#^it-Q0762-answer|Compare the answer]]
^it-Q0762

**it-Q0763 · Fill the gap**

____ posso abbracciare Tom se lui non vuole essere abbracciato.

I can't hug Tom if he doesn't want to be hugged.

[[Italian#^it-Q0763-answer|Compare the answer]]
^it-Q0763

**it-Q0764 · Choose the form**

____ posso abbracciare Tom se lui non vuole essere abbracciato.

I can't hug Tom if he doesn't want to be hugged.

Choices: niente / Non / mai / nessuno

[[Italian#^it-Q0764-answer|Compare the answer]]
^it-Q0764

**it-Q0765 · Edit the changed sentence**

【mai】 posso finire questo oggi.

I can't finish this today.

[[Italian#^it-Q0765-answer|Compare the answer]]
^it-Q0765

**it-Q0766 · Build the sentence**

Arrange: finire / oggi. / Non / posso / questo

I can't finish this today.

[[Italian#^it-Q0766-answer|Compare the answer]]
^it-Q0766

**it-Q0767 · Write a translation**

Write this in Italian: We didn't need any help.

[[Italian#^it-Q0767-answer|Compare the answer]]
^it-Q0767

**it-Q0768 · Explain the grammar**

【Non】 avevamo bisogno di alcun aiuto.

We didn't need any help.

[[Italian#^it-Q0768-answer|Compare the answer]]
^it-Q0768

**it-Q0769 · Fill the gap**

____ so cosa scrivere in questa frase.

I don't know what to write in this sentence.

[[Italian#^it-Q0769-answer|Compare the answer]]
^it-Q0769

**it-Q0770 · Choose the form**

____ so cosa scrivere in questa frase.

I don't know what to write in this sentence.

Choices: mai / niente / Non / nessuno

[[Italian#^it-Q0770-answer|Compare the answer]]
^it-Q0770

**it-Q0771 · Edit the changed sentence**

Tom 【mai】 comprerà quella macchina.

Tom won't buy that car.

[[Italian#^it-Q0771-answer|Compare the answer]]
^it-Q0771

**it-Q0772 · Build the sentence**

Arrange: quella / non / macchina. / Tom / comprerà

Tom won't buy that car.

[[Italian#^it-Q0772-answer|Compare the answer]]
^it-Q0772

**it-Q0773 · Write a translation**

Write this in Italian: I can't do it right away.

[[Italian#^it-Q0773-answer|Compare the answer]]
^it-Q0773

**it-Q0774 · Explain the grammar**

Io 【non】 posso farlo immediatamente.

I can't do it right away.

[[Italian#^it-Q0774-answer|Compare the answer]]
^it-Q0774

**it-Q0775 · Fill the gap**

____ andare da nessuna parte senza Tom.

Don't go anywhere without Tom.

[[Italian#^it-Q0775-answer|Compare the answer]]
^it-Q0775

**it-Q0776 · Choose the form**

____ andare da nessuna parte senza Tom.

Don't go anywhere without Tom.

Choices: mai / niente / Non / nessuno

[[Italian#^it-Q0776-answer|Compare the answer]]
^it-Q0776

**it-Q0777 · Edit the changed sentence**

【mai】 è in grado di capirlo.

He isn't able to understand it.

[[Italian#^it-Q0777-answer|Compare the answer]]
^it-Q0777

**it-Q0778 · Build the sentence**

Arrange: Non / in / grado / capirlo. / è / di

He isn't able to understand it.

[[Italian#^it-Q0778-answer|Compare the answer]]
^it-Q0778

**it-Q0779 · Write a translation**

Write this in Italian: Why isn't that happening now?

[[Italian#^it-Q0779-answer|Compare the answer]]
^it-Q0779

**it-Q0780 · Explain the grammar**

Perché 【non】 sta capitando ora?

Why isn't that happening now?

[[Italian#^it-Q0780-answer|Compare the answer]]
^it-Q0780

**it-Q0781 · Fill the gap**

Tom ____ disse a Mary il suo vero nome.

Tom didn't tell Mary his real name.

[[Italian#^it-Q0781-answer|Compare the answer]]
^it-Q0781

**it-Q0782 · Choose the form**

Tom ____ disse a Mary il suo vero nome.

Tom didn't tell Mary his real name.

Choices: nessuno / mai / niente / non

[[Italian#^it-Q0782-answer|Compare the answer]]
^it-Q0782

**it-Q0783 · Edit the changed sentence**

Tom 【mai】 è cambiato.

Tom hasn't changed.

[[Italian#^it-Q0783-answer|Compare the answer]]
^it-Q0783

**it-Q0784 · Build the sentence**

Arrange: è / Tom / non / cambiato.

Tom hasn't changed.

[[Italian#^it-Q0784-answer|Compare the answer]]
^it-Q0784

**it-Q0785 · Write a translation**

Write this in Italian: I can't do it.

[[Italian#^it-Q0785-answer|Compare the answer]]
^it-Q0785

**it-Q0786 · Explain the grammar**

【Non】 riesco a farlo.

I can't do it.

[[Italian#^it-Q0786-answer|Compare the answer]]
^it-Q0786

**it-Q0787 · Fill the gap**

Tom ____ legge libri in francese.

Tom doesn't read books in French.

[[Italian#^it-Q0787-answer|Compare the answer]]
^it-Q0787

**it-Q0788 · Choose the form**

Tom ____ legge libri in francese.

Tom doesn't read books in French.

Choices: nessuno / non / mai / niente

[[Italian#^it-Q0788-answer|Compare the answer]]
^it-Q0788

**it-Q0789 · Edit the changed sentence**

【mai】 riesco a raggiungerla.

I can't reach it.

[[Italian#^it-Q0789-answer|Compare the answer]]
^it-Q0789

**it-Q0790 · Build the sentence**

Arrange: riesco / a / Non / raggiungerla.

I can't reach it.

[[Italian#^it-Q0790-answer|Compare the answer]]
^it-Q0790

**it-Q0791 · Write a translation**

Write this in Italian: He isn't as stupid as he looks.

[[Italian#^it-Q0791-answer|Compare the answer]]
^it-Q0791

**it-Q0792 · Explain the grammar**

Lui 【non】 è stupido come sembra.

He isn't as stupid as he looks.

[[Italian#^it-Q0792-answer|Compare the answer]]
^it-Q0792

**it-Q0793 · Fill the gap**

____ ho una casa.

I don't have a home.

[[Italian#^it-Q0793-answer|Compare the answer]]
^it-Q0793

**it-Q0794 · Choose the form**

____ ho una casa.

I don't have a home.

Choices: nessuno / niente / mai / Non

[[Italian#^it-Q0794-answer|Compare the answer]]
^it-Q0794

**it-Q0795 · Edit the changed sentence**

【mai】 vado mai a fare acquisti il sabato.

I never go shopping on Saturdays.

[[Italian#^it-Q0795-answer|Compare the answer]]
^it-Q0795

**it-Q0796 · Build the sentence**

Arrange: mai / vado / acquisti / a / sabato. / Non / il / fare

I never go shopping on Saturdays.

[[Italian#^it-Q0796-answer|Compare the answer]]
^it-Q0796

**it-Q0797 · Write a translation**

Write this in Italian: I don't want to humiliate him.

[[Italian#^it-Q0797-answer|Compare the answer]]
^it-Q0797

**it-Q0798 · Explain the grammar**

【Non】 voglio umiliarlo.

I don't want to humiliate him.

[[Italian#^it-Q0798-answer|Compare the answer]]
^it-Q0798

**it-Q0799 · Fill the gap**

Tom ____ ha sentito il terremoto.

Tom didn't feel the earthquake.

[[Italian#^it-Q0799-answer|Compare the answer]]
^it-Q0799

**it-Q0800 · Choose the form**

Tom ____ ha sentito il terremoto.

Tom didn't feel the earthquake.

Choices: mai / niente / nessuno / non

[[Italian#^it-Q0800-answer|Compare the answer]]
^it-Q0800


### Questions · 50 questions

**it-Q0801 · Edit the changed sentence**

【chi】 state facendo delle foto?

Why are you taking pictures?

[[Italian#^it-Q0801-answer|Compare the answer]]
^it-Q0801

**it-Q0802 · Build the sentence**

Arrange: state / delle / foto? / Perché / facendo

Why are you taking pictures?

[[Italian#^it-Q0802-answer|Compare the answer]]
^it-Q0802

**it-Q0803 · Write a translation**

Write this in Italian: Do you understand how it works?

[[Italian#^it-Q0803-answer|Compare the answer]]
^it-Q0803

**it-Q0804 · Explain the grammar**

Capisci 【come】 funziona?

Do you understand how it works?

[[Italian#^it-Q0804-answer|Compare the answer]]
^it-Q0804

**it-Q0805 · Fill the gap**

____ è già qui?

Is anyone here yet?

[[Italian#^it-Q0805-answer|Compare the answer]]
^it-Q0805

**it-Q0806 · Choose the form**

____ è già qui?

Is anyone here yet?

Choices: quando / come / Chi / perché

[[Italian#^it-Q0806-answer|Compare the answer]]
^it-Q0806

**it-Q0807 · Edit the changed sentence**

【come】 altro ha intenzione di invitare?

Who else do you plan to invite?

[[Italian#^it-Q0807-answer|Compare the answer]]
^it-Q0807

**it-Q0808 · Build the sentence**

Arrange: di / invitare? / intenzione / altro / Chi / ha

Who else do you plan to invite?

[[Italian#^it-Q0808-answer|Compare the answer]]
^it-Q0808

**it-Q0809 · Write a translation**

Write this in Italian: How long do I have to stay?

[[Italian#^it-Q0809-answer|Compare the answer]]
^it-Q0809

**it-Q0810 · Explain the grammar**

【Quanto】 devo restare?

How long do I have to stay?

[[Italian#^it-Q0810-answer|Compare the answer]]
^it-Q0810

**it-Q0811 · Fill the gap**

____ non devi farlo?

Why don't you have to do that?

[[Italian#^it-Q0811-answer|Compare the answer]]
^it-Q0811

**it-Q0812 · Choose the form**

____ non devi farlo?

Why don't you have to do that?

Choices: come / chi / quando / Perché

[[Italian#^it-Q0812-answer|Compare the answer]]
^it-Q0812

**it-Q0813 · Edit the changed sentence**

【chi】 non sei tornato per lui?

Why didn't you go back for him?

[[Italian#^it-Q0813-answer|Compare the answer]]
^it-Q0813

**it-Q0814 · Build the sentence**

Arrange: non / lui? / tornato / Perché / sei / per

Why didn't you go back for him?

[[Italian#^it-Q0814-answer|Compare the answer]]
^it-Q0814

**it-Q0815 · Write a translation**

Write this in Italian: I broke down the door because I lost the key.

[[Italian#^it-Q0815-answer|Compare the answer]]
^it-Q0815

**it-Q0816 · Explain the grammar**

Io ho abbattuto la porta 【perché】 ho perso la chiave.

I broke down the door because I lost the key.

[[Italian#^it-Q0816-answer|Compare the answer]]
^it-Q0816

**it-Q0817 · Fill the gap**

____ non è preparata?

Why aren't you prepared?

[[Italian#^it-Q0817-answer|Compare the answer]]
^it-Q0817

**it-Q0818 · Choose the form**

____ non è preparata?

Why aren't you prepared?

Choices: come / Perché / chi / quando

[[Italian#^it-Q0818-answer|Compare the answer]]
^it-Q0818

**it-Q0819 · Edit the changed sentence**

【come】 altro lo sa?

Who else knows?

[[Italian#^it-Q0819-answer|Compare the answer]]
^it-Q0819

**it-Q0820 · Build the sentence**

Arrange: lo / altro / sa? / Chi

Who else knows?

[[Italian#^it-Q0820-answer|Compare the answer]]
^it-Q0820

**it-Q0821 · Write a translation**

Write this in Italian: Who's your French teacher?

[[Italian#^it-Q0821-answer|Compare the answer]]
^it-Q0821

**it-Q0822 · Explain the grammar**

【Chi】 è il suo insegnante francese?

Who's your French teacher?

[[Italian#^it-Q0822-answer|Compare the answer]]
^it-Q0822

**it-Q0823 · Fill the gap**

____ dovrei darvi questo?

Why should I give this to you?

[[Italian#^it-Q0823-answer|Compare the answer]]
^it-Q0823

**it-Q0824 · Choose the form**

____ dovrei darvi questo?

Why should I give this to you?

Choices: come / quando / Perché / chi

[[Italian#^it-Q0824-answer|Compare the answer]]
^it-Q0824

**it-Q0825 · Edit the changed sentence**

【chi】 dovrei aiutarli?

Why should I help them?

[[Italian#^it-Q0825-answer|Compare the answer]]
^it-Q0825

**it-Q0826 · Build the sentence**

Arrange: dovrei / aiutarli? / Perché

Why should I help them?

[[Italian#^it-Q0826-answer|Compare the answer]]
^it-Q0826

**it-Q0827 · Write a translation**

Write this in Italian: Who is the architect?

[[Italian#^it-Q0827-answer|Compare the answer]]
^it-Q0827

**it-Q0828 · Explain the grammar**

【Chi】 è l'architetto?

Who is the architect?

[[Italian#^it-Q0828-answer|Compare the answer]]
^it-Q0828

**it-Q0829 · Fill the gap**

____ posso fare a finire in tempo?

How can I manage to finish on time?

[[Italian#^it-Q0829-answer|Compare the answer]]
^it-Q0829

**it-Q0830 · Choose the form**

____ posso fare a finire in tempo?

How can I manage to finish on time?

Choices: quando / Come / chi / perché

[[Italian#^it-Q0830-answer|Compare the answer]]
^it-Q0830

**it-Q0831 · Edit the changed sentence**

【chi】 mi ami?

Why do you love me?

[[Italian#^it-Q0831-answer|Compare the answer]]
^it-Q0831

**it-Q0832 · Build the sentence**

Arrange: ami? / Perché / mi

Why do you love me?

[[Italian#^it-Q0832-answer|Compare the answer]]
^it-Q0832

**it-Q0833 · Write a translation**

Write this in Italian: Why is Neptune blue?

[[Italian#^it-Q0833-answer|Compare the answer]]
^it-Q0833

**it-Q0834 · Explain the grammar**

【Perché】 Nettuno è blu?

Why is Neptune blue?

[[Italian#^it-Q0834-answer|Compare the answer]]
^it-Q0834

**it-Q0835 · Fill the gap**

____ stavate urlando?

Why were you yelling?

[[Italian#^it-Q0835-answer|Compare the answer]]
^it-Q0835

**it-Q0836 · Choose the form**

____ stavate urlando?

Why were you yelling?

Choices: come / chi / quando / Perché

[[Italian#^it-Q0836-answer|Compare the answer]]
^it-Q0836

**it-Q0837 · Edit the changed sentence**

【come】 è l'amministratore?

Who is the manager?

[[Italian#^it-Q0837-answer|Compare the answer]]
^it-Q0837

**it-Q0838 · Build the sentence**

Arrange: è / l'amministratore? / Chi

Who is the manager?

[[Italian#^it-Q0838-answer|Compare the answer]]
^it-Q0838

**it-Q0839 · Write a translation**

Write this in Italian: How long have you been living in Kobe, then?

[[Italian#^it-Q0839-answer|Compare the answer]]
^it-Q0839

**it-Q0840 · Explain the grammar**

Da 【quanto】 tempo abitate a Kobe, allora?

How long have you been living in Kobe, then?

[[Italian#^it-Q0840-answer|Compare the answer]]
^it-Q0840

**it-Q0841 · Fill the gap**

Lui sa ____ sono.

He knows who I am.

[[Italian#^it-Q0841-answer|Compare the answer]]
^it-Q0841

**it-Q0842 · Choose the form**

Lui sa ____ sono.

He knows who I am.

Choices: perché / come / quando / chi

[[Italian#^it-Q0842-answer|Compare the answer]]
^it-Q0842

**it-Q0843 · Edit the changed sentence**

Lui sa 【chi】 abbattere un albero.

He knows how to fell a tree.

[[Italian#^it-Q0843-answer|Compare the answer]]
^it-Q0843

**it-Q0844 · Build the sentence**

Arrange: abbattere / Lui / sa / un / albero. / come

He knows how to fell a tree.

[[Italian#^it-Q0844-answer|Compare the answer]]
^it-Q0844

**it-Q0845 · Write a translation**

Write this in Italian: No matter how tired I might be, I have to work.

[[Italian#^it-Q0845-answer|Compare the answer]]
^it-Q0845

**it-Q0846 · Explain the grammar**

Non importa 【quanto】 sono stanco, devo lavorare.

No matter how tired I might be, I have to work.

[[Italian#^it-Q0846-answer|Compare the answer]]
^it-Q0846

**it-Q0847 · Fill the gap**

Tu ____ hai imparato a guidare?

Where did you learn to drive?

[[Italian#^it-Q0847-answer|Compare the answer]]
^it-Q0847

**it-Q0848 · Choose the form**

Tu ____ hai imparato a guidare?

Where did you learn to drive?

Choices: quando / chi / dove / come

[[Italian#^it-Q0848-answer|Compare the answer]]
^it-Q0848

**it-Q0849 · Edit the changed sentence**

【chi】 avete preso quell'acqua?

Where did you get that water?

[[Italian#^it-Q0849-answer|Compare the answer]]
^it-Q0849

**it-Q0850 · Build the sentence**

Arrange: preso / quell'acqua? / avete / Dove

Where did you get that water?

[[Italian#^it-Q0850-answer|Compare the answer]]
^it-Q0850


### Conditions · 50 questions

**it-Q0851 · Write a translation**

Write this in Italian: She wrote a letter to herself.

[[Italian#^it-Q0851-answer|Compare the answer]]
^it-Q0851

**it-Q0852 · Explain the grammar**

Scrisse la lettera a 【se】 stessa.

She wrote a letter to herself.

[[Italian#^it-Q0852-answer|Compare the answer]]
^it-Q0852

**it-Q0853 · Fill the gap**

Io non mi sveglierò neanche ____ suona la sveglia.

I won't wake up even if the alarm rings.

[[Italian#^it-Q0853-answer|Compare the answer]]
^it-Q0853

**it-Q0854 · Choose the form**

Io non mi sveglierò neanche ____ suona la sveglia.

I won't wake up even if the alarm rings.

Choices: se / perché / benché / quando

[[Italian#^it-Q0854-answer|Compare the answer]]
^it-Q0854

**it-Q0855 · Edit the changed sentence**

Pharamp augura una buona notte a Trang anche 【quando】 sa che lei non è a letto a quest'ora.

Pharamp wishes Trang good night even though she knows that she is not in bed at this hour.

[[Italian#^it-Q0855-answer|Compare the answer]]
^it-Q0855

**it-Q0856 · Build the sentence**

Arrange: è / Trang / non / sa / lei / quest'ora. / buona / Pharamp / a / anche / che / se / notte / letto / augura / a / a / una

Pharamp wishes Trang good night even though she knows that she is not in bed at this hour.

[[Italian#^it-Q0856-answer|Compare the answer]]
^it-Q0856

**it-Q0857 · Write a translation**

Write this in Italian: If I had wings, I would fly to you.

[[Italian#^it-Q0857-answer|Compare the answer]]
^it-Q0857

**it-Q0858 · Explain the grammar**

【Se】 avessi le ali, volerei verso di voi.

If I had wings, I would fly to you.

[[Italian#^it-Q0858-answer|Compare the answer]]
^it-Q0858

**it-Q0859 · Fill the gap**

Io mi chiedo ____ esista davvero Babbo Natale.

I wonder if there really is a Santa Claus.

[[Italian#^it-Q0859-answer|Compare the answer]]
^it-Q0859

**it-Q0860 · Choose the form**

Io mi chiedo ____ esista davvero Babbo Natale.

I wonder if there really is a Santa Claus.

Choices: perché / quando / benché / se

[[Italian#^it-Q0860-answer|Compare the answer]]
^it-Q0860

**it-Q0861 · Edit the changed sentence**

Si ucciderà 【quando】 non vede suo figlio.

He will kill himself if he doesn't see his child.

[[Italian#^it-Q0861-answer|Compare the answer]]
^it-Q0861

**it-Q0862 · Build the sentence**

Arrange: ucciderà / vede / figlio. / non / Si / se / suo

He will kill himself if he doesn't see his child.

[[Italian#^it-Q0862-answer|Compare the answer]]
^it-Q0862

**it-Q0863 · Write a translation**

Write this in Italian: What annoys me is that, although I object, she insists on buying it.

[[Italian#^it-Q0863-answer|Compare the answer]]
^it-Q0863

**it-Q0864 · Explain the grammar**

Ciò che mi infastidisce è che anche 【se】 obietto, lei insiste per comprarla.

What annoys me is that, although I object, she insists on buying it.

[[Italian#^it-Q0864-answer|Compare the answer]]
^it-Q0864

**it-Q0865 · Fill the gap**

Verrà ____ lo chiama.

He will come if you call him.

[[Italian#^it-Q0865-answer|Compare the answer]]
^it-Q0865

**it-Q0866 · Choose the form**

Verrà ____ lo chiama.

He will come if you call him.

Choices: perché / quando / se / benché

[[Italian#^it-Q0866-answer|Compare the answer]]
^it-Q0866

**it-Q0867 · Edit the changed sentence**

Non serve a nulla confessare i vostri peccati al prete 【quando】 non pensate due volte prima di ripeterli.

It's no use confessing your sins to the priest if you don't think twice before repeating them.

[[Italian#^it-Q0867-answer|Compare the answer]]
^it-Q0867

**it-Q0868 · Build the sentence**

Arrange: Non / prima / prete / vostri / due / se / volte / serve / non / di / a / ripeterli. / confessare / pensate / nulla / peccati / i / al

It's no use confessing your sins to the priest if you don't think twice before repeating them.

[[Italian#^it-Q0868-answer|Compare the answer]]
^it-Q0868

**it-Q0869 · Write a translation**

Write this in Italian: Mary seems very sure of herself.

[[Italian#^it-Q0869-answer|Compare the answer]]
^it-Q0869

**it-Q0870 · Explain the grammar**

Mary sembra molto sicura di 【se】 stessa.

Mary seems very sure of herself.

[[Italian#^it-Q0870-answer|Compare the answer]]
^it-Q0870

**it-Q0871 · Fill the gap**

Voglio che ____ ne vada.

I want him to leave.

[[Italian#^it-Q0871-answer|Compare the answer]]
^it-Q0871

**it-Q0872 · Choose the form**

Voglio che ____ ne vada.

I want him to leave.

Choices: se / benché / perché / quando

[[Italian#^it-Q0872-answer|Compare the answer]]
^it-Q0872

**it-Q0873 · Edit the changed sentence**

【quando】 lo sa una donna, lo sa il mondo intero.

If a woman knows, the whole world knows.

[[Italian#^it-Q0873-answer|Compare the answer]]
^it-Q0873

**it-Q0874 · Build the sentence**

Arrange: intero. / lo / sa / lo / una / mondo / Se / sa / il / donna,

If a woman knows, the whole world knows.

[[Italian#^it-Q0874-answer|Compare the answer]]
^it-Q0874

**it-Q0875 · Write a translation**

Write this in Italian: I don't know if we can do that without Tom's permission.

[[Italian#^it-Q0875-answer|Compare the answer]]
^it-Q0875

**it-Q0876 · Explain the grammar**

Non so 【se】 lo possiamo fare senza il permesso di Tom.

I don't know if we can do that without Tom's permission.

[[Italian#^it-Q0876-answer|Compare the answer]]
^it-Q0876

**it-Q0877 · Fill the gap**

Ho dimenticato ____ tu bevi vino o no.

I've forgotten whether you drink wine or not.

[[Italian#^it-Q0877-answer|Compare the answer]]
^it-Q0877

**it-Q0878 · Choose the form**

Ho dimenticato ____ tu bevi vino o no.

I've forgotten whether you drink wine or not.

Choices: benché / se / perché / quando

[[Italian#^it-Q0878-answer|Compare the answer]]
^it-Q0878

**it-Q0879 · Edit the changed sentence**

【quando】 mangi troppo, diventerai grassa.

If you eat too much, you'll become fat.

[[Italian#^it-Q0879-answer|Compare the answer]]
^it-Q0879

**it-Q0880 · Build the sentence**

Arrange: mangi / diventerai / grassa. / troppo, / Se

If you eat too much, you'll become fat.

[[Italian#^it-Q0880-answer|Compare the answer]]
^it-Q0880

**it-Q0881 · Write a translation**

Write this in Italian: I wouldn't do anything for Tom if I were you.

[[Italian#^it-Q0881-answer|Compare the answer]]
^it-Q0881

**it-Q0882 · Explain the grammar**

Io non farei nulla per Tom 【se】 fossi in te.

I wouldn't do anything for Tom if I were you.

[[Italian#^it-Q0882-answer|Compare the answer]]
^it-Q0882

**it-Q0883 · Fill the gap**

Non riesco a dire ____ Tom sta scherzando o no.

I can't tell if Tom is joking or not.

[[Italian#^it-Q0883-answer|Compare the answer]]
^it-Q0883

**it-Q0884 · Choose the form**

Non riesco a dire ____ Tom sta scherzando o no.

I can't tell if Tom is joking or not.

Choices: perché / se / benché / quando

[[Italian#^it-Q0884-answer|Compare the answer]]
^it-Q0884

**it-Q0885 · Edit the changed sentence**

【quando】 non lo dici a lei, lo farò io.

If you won't tell her, I will.

[[Italian#^it-Q0885-answer|Compare the answer]]
^it-Q0885

**it-Q0886 · Build the sentence**

Arrange: dici / non / a / farò / lo / lo / Se / io. / lei,

If you won't tell her, I will.

[[Italian#^it-Q0886-answer|Compare the answer]]
^it-Q0886

**it-Q0887 · Write a translation**

Write this in Italian: Tom acted like he didn't know Mary.

[[Italian#^it-Q0887-answer|Compare the answer]]
^it-Q0887

**it-Q0888 · Explain the grammar**

Tom si comportava come 【se】 non conoscesse Mary.

Tom acted like he didn't know Mary.

[[Italian#^it-Q0888-answer|Compare the answer]]
^it-Q0888

**it-Q0889 · Fill the gap**

Non so ____ verrà o no.

I don't know if she will come or not.

[[Italian#^it-Q0889-answer|Compare the answer]]
^it-Q0889

**it-Q0890 · Choose the form**

Non so ____ verrà o no.

I don't know if she will come or not.

Choices: benché / se / quando / perché

[[Italian#^it-Q0890-answer|Compare the answer]]
^it-Q0890

**it-Q0891 · Edit the changed sentence**

Sarebbe meglio 【quando】 voi vi riposaste qui.

It would be better if you took a rest here.

[[Italian#^it-Q0891-answer|Compare the answer]]
^it-Q0891

**it-Q0892 · Build the sentence**

Arrange: Sarebbe / qui. / meglio / se / vi / riposaste / voi

It would be better if you took a rest here.

[[Italian#^it-Q0892-answer|Compare the answer]]
^it-Q0892

**it-Q0893 · Write a translation**

Write this in Italian: You can improve your English if you try.

[[Italian#^it-Q0893-answer|Compare the answer]]
^it-Q0893

**it-Q0894 · Explain the grammar**

Puoi migliorare il tuo inglese 【se】 provi.

You can improve your English if you try.

[[Italian#^it-Q0894-answer|Compare the answer]]
^it-Q0894

**it-Q0895 · Fill the gap**

____ si mangia a quest'ora della notte, si ingrasserà.

If you eat at this time of night, you'll get fat.

[[Italian#^it-Q0895-answer|Compare the answer]]
^it-Q0895

**it-Q0896 · Choose the form**

____ si mangia a quest'ora della notte, si ingrasserà.

If you eat at this time of night, you'll get fat.

Choices: quando / Se / perché / benché

[[Italian#^it-Q0896-answer|Compare the answer]]
^it-Q0896

**it-Q0897 · Edit the changed sentence**

Ti dispiace 【quando】 uso questo dizionario?

Would you mind my using this dictionary?

[[Italian#^it-Q0897-answer|Compare the answer]]
^it-Q0897

**it-Q0898 · Build the sentence**

Arrange: dizionario? / Ti / se / dispiace / questo / uso

Would you mind my using this dictionary?

[[Italian#^it-Q0898-answer|Compare the answer]]
^it-Q0898

**it-Q0899 · Write a translation**

Write this in Italian: I wonder if Tom still likes Mary.

[[Italian#^it-Q0899-answer|Compare the answer]]
^it-Q0899

**it-Q0900 · Explain the grammar**

Mi chiedo 【se】 a Tom piaccia ancora Mary.

I wonder if Tom still likes Mary.

[[Italian#^it-Q0900-answer|Compare the answer]]
^it-Q0900


### Logical connectors · 50 questions

**it-Q0901 · Fill the gap**

Ho cliccato sul link, ____ non è successo niente.

I clicked the link, but nothing happened.

[[Italian#^it-Q0901-answer|Compare the answer]]
^it-Q0901

**it-Q0902 · Choose the form**

Ho cliccato sul link, ____ non è successo niente.

I clicked the link, but nothing happened.

Choices: anche se / quindi / perché / però

[[Italian#^it-Q0902-answer|Compare the answer]]
^it-Q0902

**it-Q0903 · Edit the changed sentence**

【anche se】 le persone hanno paura di me?

Why are people scared of me?

[[Italian#^it-Q0903-answer|Compare the answer]]
^it-Q0903

**it-Q0904 · Build the sentence**

Arrange: le / Perché / di / hanno / persone / me? / paura

Why are people scared of me?

[[Italian#^it-Q0904-answer|Compare the answer]]
^it-Q0904

**it-Q0905 · Write a translation**

Write this in Italian: Why do you want to buy this book?

[[Italian#^it-Q0905-answer|Compare the answer]]
^it-Q0905

**it-Q0906 · Explain the grammar**

【Perché】 volete comprare questo libro?

Why do you want to buy this book?

[[Italian#^it-Q0906-answer|Compare the answer]]
^it-Q0906

**it-Q0907 · Fill the gap**

Hanno detto il ____?

Did they say why?

[[Italian#^it-Q0907-answer|Compare the answer]]
^it-Q0907

**it-Q0908 · Choose the form**

Hanno detto il ____?

Did they say why?

Choices: perché / quindi / però / anche se

[[Italian#^it-Q0908-answer|Compare the answer]]
^it-Q0908

**it-Q0909 · Edit the changed sentence**

【anche se】 non mi avete consultata?

Why didn't you consult me?

[[Italian#^it-Q0909-answer|Compare the answer]]
^it-Q0909

**it-Q0910 · Build the sentence**

Arrange: mi / avete / Perché / consultata? / non

Why didn't you consult me?

[[Italian#^it-Q0910-answer|Compare the answer]]
^it-Q0910

**it-Q0911 · Write a translation**

Write this in Italian: Why don't you go ask them?

[[Italian#^it-Q0911-answer|Compare the answer]]
^it-Q0911

**it-Q0912 · Explain the grammar**

【Perché】 non va a chiedere a loro?

Why don't you go ask them?

[[Italian#^it-Q0912-answer|Compare the answer]]
^it-Q0912

**it-Q0913 · Fill the gap**

____ tutti sono sorpresi?

Why is everyone so surprised?

[[Italian#^it-Q0913-answer|Compare the answer]]
^it-Q0913

**it-Q0914 · Choose the form**

____ tutti sono sorpresi?

Why is everyone so surprised?

Choices: Perché / quindi / anche se / però

[[Italian#^it-Q0914-answer|Compare the answer]]
^it-Q0914

**it-Q0915 · Edit the changed sentence**

【anche se】 voleva che venissi qua?

Why did you want me to come here?

[[Italian#^it-Q0915-answer|Compare the answer]]
^it-Q0915

**it-Q0916 · Build the sentence**

Arrange: qua? / voleva / venissi / che / Perché

Why did you want me to come here?

[[Italian#^it-Q0916-answer|Compare the answer]]
^it-Q0916

**it-Q0917 · Write a translation**

Write this in Italian: Why does everyone hate him?

[[Italian#^it-Q0917-answer|Compare the answer]]
^it-Q0917

**it-Q0918 · Explain the grammar**

【Perché】 lo odiano tutti?

Why does everyone hate him?

[[Italian#^it-Q0918-answer|Compare the answer]]
^it-Q0918

**it-Q0919 · Fill the gap**

Non dica loro il ____.

Don't tell them why.

[[Italian#^it-Q0919-answer|Compare the answer]]
^it-Q0919

**it-Q0920 · Choose the form**

Non dica loro il ____.

Don't tell them why.

Choices: quindi / perché / però / anche se

[[Italian#^it-Q0920-answer|Compare the answer]]
^it-Q0920

**it-Q0921 · Edit the changed sentence**

Io non ho un gatto, 【perché】 Tom sì.

I don't have a cat, but Tom does.

[[Italian#^it-Q0921-answer|Compare the answer]]
^it-Q0921

**it-Q0922 · Build the sentence**

Arrange: gatto, / non / Io / ho / però / un / Tom / sì.

I don't have a cat, but Tom does.

[[Italian#^it-Q0922-answer|Compare the answer]]
^it-Q0922

**it-Q0923 · Write a translation**

Write this in Italian: It is because light travels faster than sound that some people look brilliant before sounding stupid.

[[Italian#^it-Q0923-answer|Compare the answer]]
^it-Q0923

**it-Q0924 · Explain the grammar**

È 【perché】 la velocità della luce è superiore a quella del suono che alcune persone sembrano brillanti prima di suonare stupide.

It is because light travels faster than sound that some people look brilliant before sounding stupid.

[[Italian#^it-Q0924-answer|Compare the answer]]
^it-Q0924

**it-Q0925 · Fill the gap**

____ noi abbiamo bisogno di aspartame?

Why do we need aspartame?

[[Italian#^it-Q0925-answer|Compare the answer]]
^it-Q0925

**it-Q0926 · Choose the form**

____ noi abbiamo bisogno di aspartame?

Why do we need aspartame?

Choices: quindi / però / anche se / Perché

[[Italian#^it-Q0926-answer|Compare the answer]]
^it-Q0926

**it-Q0927 · Edit the changed sentence**

Io sapevo che Tom era un insegnante di francese a Boston, 【perché】 non credetti a Mary quando mi disse che era un tassista a Chicago.

I knew that Tom was a French teacher in Boston, so I didn't believe Mary when she told me that Tom was a taxi driver in Chicago.

[[Italian#^it-Q0927-answer|Compare the answer]]
^it-Q0927

**it-Q0928 · Build the sentence**

Arrange: a / che / sapevo / un / disse / quando / quindi / di / a / Boston, / non / Tom / mi / insegnante / un / credetti / francese / Mary / a / Io / era / Chicago. / tassista / che / era

I knew that Tom was a French teacher in Boston, so I didn't believe Mary when she told me that Tom was a taxi driver in Chicago.

[[Italian#^it-Q0928-answer|Compare the answer]]
^it-Q0928

**it-Q0929 · Write a translation**

Write this in Italian: Why not try to get some sleep?

[[Italian#^it-Q0929-answer|Compare the answer]]
^it-Q0929

**it-Q0930 · Explain the grammar**

【Perché】 non prova a dormire un po'?

Why not try to get some sleep?

[[Italian#^it-Q0930-answer|Compare the answer]]
^it-Q0930

**it-Q0931 · Fill the gap**

____ non mi avete creduto?

Why didn't you believe me?

[[Italian#^it-Q0931-answer|Compare the answer]]
^it-Q0931

**it-Q0932 · Choose the form**

____ non mi avete creduto?

Why didn't you believe me?

Choices: però / quindi / Perché / anche se

[[Italian#^it-Q0932-answer|Compare the answer]]
^it-Q0932

**it-Q0933 · Edit the changed sentence**

【anche se】 la mia borsa è vuota?

Why is my bag empty?

[[Italian#^it-Q0933-answer|Compare the answer]]
^it-Q0933

**it-Q0934 · Build the sentence**

Arrange: vuota? / Perché / borsa / la / è / mia

Why is my bag empty?

[[Italian#^it-Q0934-answer|Compare the answer]]
^it-Q0934

**it-Q0935 · Write a translation**

Write this in Italian: Why are you offended?

[[Italian#^it-Q0935-answer|Compare the answer]]
^it-Q0935

**it-Q0936 · Explain the grammar**

【Perché】 è offeso?

Why are you offended?

[[Italian#^it-Q0936-answer|Compare the answer]]
^it-Q0936

**it-Q0937 · Fill the gap**

Io devo solo scoprire il ____.

I just need to find out why.

[[Italian#^it-Q0937-answer|Compare the answer]]
^it-Q0937

**it-Q0938 · Choose the form**

Io devo solo scoprire il ____.

I just need to find out why.

Choices: quindi / perché / però / anche se

[[Italian#^it-Q0938-answer|Compare the answer]]
^it-Q0938

**it-Q0939 · Edit the changed sentence**

【anche se】 non chiedete a loro di farla?

Why don't you ask them to do it?

[[Italian#^it-Q0939-answer|Compare the answer]]
^it-Q0939

**it-Q0940 · Build the sentence**

Arrange: Perché / chiedete / non / di / loro / a / farla?

Why don't you ask them to do it?

[[Italian#^it-Q0940-answer|Compare the answer]]
^it-Q0940

**it-Q0941 · Write a translation**

Write this in Italian: Why do you live here?

[[Italian#^it-Q0941-answer|Compare the answer]]
^it-Q0941

**it-Q0942 · Explain the grammar**

【Perché】 vive qui?

Why do you live here?

[[Italian#^it-Q0942-answer|Compare the answer]]
^it-Q0942

**it-Q0943 · Fill the gap**

____ state facendo quello che state facendo?

Why are you doing what you're doing?

[[Italian#^it-Q0943-answer|Compare the answer]]
^it-Q0943

**it-Q0944 · Choose the form**

____ state facendo quello che state facendo?

Why are you doing what you're doing?

Choices: però / anche se / quindi / Perché

[[Italian#^it-Q0944-answer|Compare the answer]]
^it-Q0944

**it-Q0945 · Edit the changed sentence**

【anche se】 ve ne siete andate presto?

Why did you leave early?

[[Italian#^it-Q0945-answer|Compare the answer]]
^it-Q0945

**it-Q0946 · Build the sentence**

Arrange: andate / Perché / siete / ne / presto? / ve

Why did you leave early?

[[Italian#^it-Q0946-answer|Compare the answer]]
^it-Q0946

**it-Q0947 · Write a translation**

Write this in Italian: Why didn't you call me?

[[Italian#^it-Q0947-answer|Compare the answer]]
^it-Q0947

**it-Q0948 · Explain the grammar**

【Perché】 non mi avete chiamato?

Why didn't you call me?

[[Italian#^it-Q0948-answer|Compare the answer]]
^it-Q0948

**it-Q0949 · Fill the gap**

Mi avete tradito. ____?

You betrayed me. Why?

[[Italian#^it-Q0949-answer|Compare the answer]]
^it-Q0949

**it-Q0950 · Choose the form**

Mi avete tradito. ____?

You betrayed me. Why?

Choices: quindi / anche se / però / Perché

[[Italian#^it-Q0950-answer|Compare the answer]]
^it-Q0950


### Comparison and agreement · 50 questions

**it-Q0951 · Edit the changed sentence**

Faresti 【più】 a osservarli.

You'd better watch them.

[[Italian#^it-Q0951-answer|Compare the answer]]
^it-Q0951

**it-Q0952 · Build the sentence**

Arrange: Faresti / a / meglio / osservarli.

You'd better watch them.

[[Italian#^it-Q0952-answer|Compare the answer]]
^it-Q0952

**it-Q0953 · Write a translation**

Write this in Italian: We need to find a new babysitter.

[[Italian#^it-Q0953-answer|Compare the answer]]
^it-Q0953

**it-Q0954 · Explain the grammar**

Abbiamo bisogno di trovare una 【nuova】 babysitter.

We need to find a new babysitter.

[[Italian#^it-Q0954-answer|Compare the answer]]
^it-Q0954

**it-Q0955 · Fill the gap**

Sachiko è ____ popolare di Judy.

Sachiko is more popular than Judy.

[[Italian#^it-Q0955-answer|Compare the answer]]
^it-Q0955

**it-Q0956 · Choose the form**

Sachiko è ____ popolare di Judy.

Sachiko is more popular than Judy.

Choices: meglio / meno / più / migliore

[[Italian#^it-Q0956-answer|Compare the answer]]
^it-Q0956

**it-Q0957 · Edit the changed sentence**

Mary è 【più】 attiva di sua sorella.

Mary's less active than her sister.

[[Italian#^it-Q0957-answer|Compare the answer]]
^it-Q0957

**it-Q0958 · Build the sentence**

Arrange: sorella. / Mary / meno / di / è / attiva / sua

Mary's less active than her sister.

[[Italian#^it-Q0958-answer|Compare the answer]]
^it-Q0958

**it-Q0959 · Write a translation**

Write this in Italian: I got a new cellphone.

[[Italian#^it-Q0959-answer|Compare the answer]]
^it-Q0959

**it-Q0960 · Explain the grammar**

Ho preso un cellulare 【nuovo】.

I got a new cellphone.

[[Italian#^it-Q0960-answer|Compare the answer]]
^it-Q0960

**it-Q0961 · Fill the gap**

Io non ho ____ tempo per parlare con voi.

I don't have time to talk with you anymore.

[[Italian#^it-Q0961-answer|Compare the answer]]
^it-Q0961

**it-Q0962 · Choose the form**

Io non ho ____ tempo per parlare con voi.

I don't have time to talk with you anymore.

Choices: più / meno / meglio / migliore

[[Italian#^it-Q0962-answer|Compare the answer]]
^it-Q0962

**it-Q0963 · Edit the changed sentence**

Non sei 【meno】 mia amica.

You're not my friend anymore.

[[Italian#^it-Q0963-answer|Compare the answer]]
^it-Q0963

**it-Q0964 · Build the sentence**

Arrange: più / sei / amica. / mia / Non

You're not my friend anymore.

[[Italian#^it-Q0964-answer|Compare the answer]]
^it-Q0964

**it-Q0965 · Write a translation**

Write this in Italian: He has even more apples.

[[Italian#^it-Q0965-answer|Compare the answer]]
^it-Q0965

**it-Q0966 · Explain the grammar**

Lui ha ancora 【più】 mele.

He has even more apples.

[[Italian#^it-Q0966-answer|Compare the answer]]
^it-Q0966

**it-Q0967 · Fill the gap**

Tom e Mary sono entrambi abbastanza grandi per sapere ____.

Tom and Mary are both old enough to know better.

[[Italian#^it-Q0967-answer|Compare the answer]]
^it-Q0967

**it-Q0968 · Choose the form**

Tom e Mary sono entrambi abbastanza grandi per sapere ____.

Tom and Mary are both old enough to know better.

Choices: migliore / meglio / più / meno

[[Italian#^it-Q0968-answer|Compare the answer]]
^it-Q0968

**it-Q0969 · Edit the changed sentence**

Evidenzia i momenti 【meno】 intensi del tormento interiore di Medea.

Mark the most intense moments of Medea's inner torment.

[[Italian#^it-Q0969-answer|Compare the answer]]
^it-Q0969

**it-Q0970 · Build the sentence**

Arrange: Medea. / interiore / tormento / più / del / Evidenzia / i / di / intensi / momenti

Mark the most intense moments of Medea's inner torment.

[[Italian#^it-Q0970-answer|Compare the answer]]
^it-Q0970

**it-Q0971 · Write a translation**

Write this in Italian: I don't hate them anymore.

[[Italian#^it-Q0971-answer|Compare the answer]]
^it-Q0971

**it-Q0972 · Explain the grammar**

Non li odio 【più】.

I don't hate them anymore.

[[Italian#^it-Q0972-answer|Compare the answer]]
^it-Q0972

**it-Q0973 · Fill the gap**

Io non voglio mangiare di ____ lì.

I don't want to eat there again.

[[Italian#^it-Q0973-answer|Compare the answer]]
^it-Q0973

**it-Q0974 · Choose the form**

Io non voglio mangiare di ____ lì.

I don't want to eat there again.

Choices: meno / meglio / nuovo / più

[[Italian#^it-Q0974-answer|Compare the answer]]
^it-Q0974

**it-Q0975 · Edit the changed sentence**

Non sono 【meno】 sposato con lui.

I'm not married to him anymore.

[[Italian#^it-Q0975-answer|Compare the answer]]
^it-Q0975

**it-Q0976 · Build the sentence**

Arrange: Non / sposato / sono / lui. / con / più

I'm not married to him anymore.

[[Italian#^it-Q0976-answer|Compare the answer]]
^it-Q0976

**it-Q0977 · Write a translation**

Write this in Italian: Happiness is more important than wealth.

[[Italian#^it-Q0977-answer|Compare the answer]]
^it-Q0977

**it-Q0978 · Explain the grammar**

La felicità è 【più】 importante della ricchezza.

Happiness is more important than wealth.

[[Italian#^it-Q0978-answer|Compare the answer]]
^it-Q0978

**it-Q0979 · Fill the gap**

Tu riesci a raggiungere lo scaffale ____ in alto?

Can you reach the top shelf?

[[Italian#^it-Q0979-answer|Compare the answer]]
^it-Q0979

**it-Q0980 · Choose the form**

Tu riesci a raggiungere lo scaffale ____ in alto?

Can you reach the top shelf?

Choices: più / migliore / meglio / meno

[[Italian#^it-Q0980-answer|Compare the answer]]
^it-Q0980

**it-Q0981 · Edit the changed sentence**

I capelli di Jeannie erano 【meno】 blu dei suoi occhi.

Jeannie's hair was bluer than her eyes.

[[Italian#^it-Q0981-answer|Compare the answer]]
^it-Q0981

**it-Q0982 · Build the sentence**

Arrange: più / suoi / dei / blu / occhi. / Jeannie / di / erano / I / capelli

Jeannie's hair was bluer than her eyes.

[[Italian#^it-Q0982-answer|Compare the answer]]
^it-Q0982

**it-Q0983 · Write a translation**

Write this in Italian: Tom ate less than Mary did.

[[Italian#^it-Q0983-answer|Compare the answer]]
^it-Q0983

**it-Q0984 · Explain the grammar**

Tom ha mangiato 【meno】 di Mary.

Tom ate less than Mary did.

[[Italian#^it-Q0984-answer|Compare the answer]]
^it-Q0984

**it-Q0985 · Fill the gap**

Non traduco ____ romanzi.

I don't translate novels anymore.

[[Italian#^it-Q0985-answer|Compare the answer]]
^it-Q0985

**it-Q0986 · Choose the form**

Non traduco ____ romanzi.

I don't translate novels anymore.

Choices: migliore / meglio / meno / più

[[Italian#^it-Q0986-answer|Compare the answer]]
^it-Q0986

**it-Q0987 · Edit the changed sentence**

Non vogliamo 【meno】 aspettare.

We don't want to wait any longer.

[[Italian#^it-Q0987-answer|Compare the answer]]
^it-Q0987

**it-Q0988 · Build the sentence**

Arrange: più / aspettare. / Non / vogliamo

We don't want to wait any longer.

[[Italian#^it-Q0988-answer|Compare the answer]]
^it-Q0988

**it-Q0989 · Write a translation**

Write this in Italian: Tom began to feel better.

[[Italian#^it-Q0989-answer|Compare the answer]]
^it-Q0989

**it-Q0990 · Explain the grammar**

Tom iniziò a sentirsi 【meglio】.

Tom began to feel better.

[[Italian#^it-Q0990-answer|Compare the answer]]
^it-Q0990

**it-Q0991 · Fill the gap**

Vuoi farlo di ____?

Do you want to do it again?

[[Italian#^it-Q0991-answer|Compare the answer]]
^it-Q0991

**it-Q0992 · Choose the form**

Vuoi farlo di ____?

Do you want to do it again?

Choices: meglio / meno / nuovo / più

[[Italian#^it-Q0992-answer|Compare the answer]]
^it-Q0992

**it-Q0993 · Edit the changed sentence**

Hai il 【più】 album di Stevie Wonder?

Do you have Stevie Wonder's new album?

[[Italian#^it-Q0993-answer|Compare the answer]]
^it-Q0993

**it-Q0994 · Build the sentence**

Arrange: Wonder? / di / Hai / Stevie / il / nuovo / album

Do you have Stevie Wonder's new album?

[[Italian#^it-Q0994-answer|Compare the answer]]
^it-Q0994

**it-Q0995 · Write a translation**

Write this in Italian: Sami had a better job.

[[Italian#^it-Q0995-answer|Compare the answer]]
^it-Q0995

**it-Q0996 · Explain the grammar**

Sami aveva un lavoro 【migliore】.

Sami had a better job.

[[Italian#^it-Q0996-answer|Compare the answer]]
^it-Q0996

**it-Q0997 · Fill the gap**

Tom ha sicuramente ____ di trent'anni.

Tom is certainly over thirty.

[[Italian#^it-Q0997-answer|Compare the answer]]
^it-Q0997

**it-Q0998 · Choose the form**

Tom ha sicuramente ____ di trent'anni.

Tom is certainly over thirty.

Choices: meglio / più / meno / migliore

[[Italian#^it-Q0998-answer|Compare the answer]]
^it-Q0998

**it-Q0999 · Edit the changed sentence**

Non mi piace 【meno】 il Natale.

I don't like Christmas anymore.

[[Italian#^it-Q0999-answer|Compare the answer]]
^it-Q0999

**it-Q1000 · Build the sentence**

Arrange: il / più / Natale. / mi / Non / piace

I don't like Christmas anymore.

[[Italian#^it-Q1000-answer|Compare the answer]]
^it-Q1000


## Answers

The full sentence is a model. For translation, judge whether meaning and grammar are preserved. Each grammar rule above explains the form.

### Answers 1–50

**it-Q0001** — I miei doveri pubblici mi prendono molto tempo.

My public duties take a lot of time.

Expected form: **I**

Why: Definite articles. [[Italian#^it-Q0001|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=I%20miei%20doveri%20pubblici%20mi%20prendono%20molto%20tempo.)
^it-Q0001-answer

**it-Q0002** — I miei doveri pubblici mi prendono molto tempo.

My public duties take a lot of time.

Expected form: **I**

Why: Definite articles. [[Italian#^it-Q0002|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=I%20miei%20doveri%20pubblici%20mi%20prendono%20molto%20tempo.)
^it-Q0002-answer

**it-Q0003** — Temo che mi verrà il mal di testa pensando a quant'è fastidioso Chris.

My head starts to hurt when I think about how annoying Chris is.

Expected form: **il**

Why: Definite articles. [[Italian#^it-Q0003|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Temo%20che%20mi%20verr%C3%A0%20il%20mal%20di%20testa%20pensando%20a%20quant%27%C3%A8%20fastidioso%20Chris.)
^it-Q0003-answer

**it-Q0004** — Temo che mi verrà il mal di testa pensando a quant'è fastidioso Chris.

My head starts to hurt when I think about how annoying Chris is.

Why: Definite articles. [[Italian#^it-Q0004|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Temo%20che%20mi%20verr%C3%A0%20il%20mal%20di%20testa%20pensando%20a%20quant%27%C3%A8%20fastidioso%20Chris.)
^it-Q0004-answer

**it-Q0005** — Lo so che non l'ha ancora fatta.

I know you haven't done it yet.

Why: Definite articles. [[Italian#^it-Q0005|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Lo%20so%20che%20non%20l%27ha%20ancora%20fatta.)
^it-Q0005-answer

**it-Q0006** — Lo so che non l'ha ancora fatta.

I know you haven't done it yet.

Articles depend on gender, number and following sound. Lo and gli occur before particular masculine onsets, including z and s + consonant. Learn article and noun together.

Why: Definite articles. [[Italian#^it-Q0006|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Lo%20so%20che%20non%20l%27ha%20ancora%20fatta.)
^it-Q0006-answer

**it-Q0007** — La mia vita non è più la stessa da quando l'ho conosciuto.

My life hasn't been the same since I met him.

Expected form: **La**

Why: Definite articles. [[Italian#^it-Q0007|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=La%20mia%20vita%20non%20%C3%A8%20pi%C3%B9%20la%20stessa%20da%20quando%20l%27ho%20conosciuto.)
^it-Q0007-answer

**it-Q0008** — La mia vita non è più la stessa da quando l'ho conosciuto.

My life hasn't been the same since I met him.

Expected form: **La**

Why: Definite articles. [[Italian#^it-Q0008|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=La%20mia%20vita%20non%20%C3%A8%20pi%C3%B9%20la%20stessa%20da%20quando%20l%27ho%20conosciuto.)
^it-Q0008-answer

**it-Q0009** — Per piacere, non mi comprare nulla per il mio compleanno.

Please don't buy me anything for my birthday.

Expected form: **il**

Why: Definite articles. [[Italian#^it-Q0009|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Per%20piacere%2C%20non%20mi%20comprare%20nulla%20per%20il%20mio%20compleanno.)
^it-Q0009-answer

**it-Q0010** — Per piacere, non mi comprare nulla per il mio compleanno.

Please don't buy me anything for my birthday.

Why: Definite articles. [[Italian#^it-Q0010|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Per%20piacere%2C%20non%20mi%20comprare%20nulla%20per%20il%20mio%20compleanno.)
^it-Q0010-answer

**it-Q0011** — La scatola era piena di libri.

The box was full of books.

Why: Definite articles. [[Italian#^it-Q0011|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=La%20scatola%20era%20piena%20di%20libri.)
^it-Q0011-answer

**it-Q0012** — La scatola era piena di libri.

The box was full of books.

Articles depend on gender, number and following sound. Lo and gli occur before particular masculine onsets, including z and s + consonant. Learn article and noun together.

Why: Definite articles. [[Italian#^it-Q0012|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=La%20scatola%20era%20piena%20di%20libri.)
^it-Q0012-answer

**it-Q0013** — Il risultato del sondaggio sarà presto conosciuto.

The result of the poll will be known soon.

Expected form: **Il**

Why: Definite articles. [[Italian#^it-Q0013|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Il%20risultato%20del%20sondaggio%20sar%C3%A0%20presto%20conosciuto.)
^it-Q0013-answer

**it-Q0014** — Il risultato del sondaggio sarà presto conosciuto.

The result of the poll will be known soon.

Expected form: **Il**

Why: Definite articles. [[Italian#^it-Q0014|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Il%20risultato%20del%20sondaggio%20sar%C3%A0%20presto%20conosciuto.)
^it-Q0014-answer

**it-Q0015** — Potete aggiornare il nostro software?

Can you update our software?

Expected form: **il**

Why: Definite articles. [[Italian#^it-Q0015|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Potete%20aggiornare%20il%20nostro%20software%3F)
^it-Q0015-answer

**it-Q0016** — Potete aggiornare il nostro software?

Can you update our software?

Why: Definite articles. [[Italian#^it-Q0016|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Potete%20aggiornare%20il%20nostro%20software%3F)
^it-Q0016-answer

**it-Q0017** — Consegni i suoi fogli del test.

Turn in your test papers.

Why: Definite articles. [[Italian#^it-Q0017|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Consegni%20i%20suoi%20fogli%20del%20test.)
^it-Q0017-answer

**it-Q0018** — Consegni i suoi fogli del test.

Turn in your test papers.

Articles depend on gender, number and following sound. Lo and gli occur before particular masculine onsets, including z and s + consonant. Learn article and noun together.

Why: Definite articles. [[Italian#^it-Q0018|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Consegni%20i%20suoi%20fogli%20del%20test.)
^it-Q0018-answer

**it-Q0019** — Il poliziotto mi ha accusato di avere ignorato le regole del traffico.

The policeman blamed me for ignoring traffic rules.

Expected form: **Il**

Why: Definite articles. [[Italian#^it-Q0019|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Il%20poliziotto%20mi%20ha%20accusato%20di%20avere%20ignorato%20le%20regole%20del%20traffico.)
^it-Q0019-answer

**it-Q0020** — Il poliziotto mi ha accusato di avere ignorato le regole del traffico.

The policeman blamed me for ignoring traffic rules.

Expected form: **Il**

Why: Definite articles. [[Italian#^it-Q0020|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Il%20poliziotto%20mi%20ha%20accusato%20di%20avere%20ignorato%20le%20regole%20del%20traffico.)
^it-Q0020-answer

**it-Q0021** — La mia camera è un po' in disordine.

My room's a little messy.

Expected form: **La**

Why: Definite articles. [[Italian#^it-Q0021|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=La%20mia%20camera%20%C3%A8%20un%20po%27%20in%20disordine.)
^it-Q0021-answer

**it-Q0022** — La mia camera è un po' in disordine.

My room's a little messy.

Why: Definite articles. [[Italian#^it-Q0022|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=La%20mia%20camera%20%C3%A8%20un%20po%27%20in%20disordine.)
^it-Q0022-answer

**it-Q0023** — Solamente il suo progetto conta.

Only your project matters.

Why: Definite articles. [[Italian#^it-Q0023|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Solamente%20il%20suo%20progetto%20conta.)
^it-Q0023-answer

**it-Q0024** — Solamente il suo progetto conta.

Only your project matters.

Articles depend on gender, number and following sound. Lo and gli occur before particular masculine onsets, including z and s + consonant. Learn article and noun together.

Why: Definite articles. [[Italian#^it-Q0024|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Solamente%20il%20suo%20progetto%20conta.)
^it-Q0024-answer

**it-Q0025** — Hai alzato lo sguardo, vero?

You looked up, didn't you?

Expected form: **lo**

Why: Definite articles. [[Italian#^it-Q0025|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Hai%20alzato%20lo%20sguardo%2C%20vero%3F)
^it-Q0025-answer

**it-Q0026** — Hai alzato lo sguardo, vero?

You looked up, didn't you?

Expected form: **lo**

Why: Definite articles. [[Italian#^it-Q0026|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Hai%20alzato%20lo%20sguardo%2C%20vero%3F)
^it-Q0026-answer

**it-Q0027** — Nessun altro le aiuterebbe.

Nobody else would help them.

Expected form: **le**

Why: Definite articles. [[Italian#^it-Q0027|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Nessun%20altro%20le%20aiuterebbe.)
^it-Q0027-answer

**it-Q0028** — Nessun altro le aiuterebbe.

Nobody else would help them.

Why: Definite articles. [[Italian#^it-Q0028|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Nessun%20altro%20le%20aiuterebbe.)
^it-Q0028-answer

**it-Q0029** — Mia madre fa il bucato ogni giorno.

My mother does a laundry every day.

Why: Definite articles. [[Italian#^it-Q0029|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Mia%20madre%20fa%20il%20bucato%20ogni%20giorno.)
^it-Q0029-answer

**it-Q0030** — Mia madre fa il bucato ogni giorno.

My mother does a laundry every day.

Articles depend on gender, number and following sound. Lo and gli occur before particular masculine onsets, including z and s + consonant. Learn article and noun together.

Why: Definite articles. [[Italian#^it-Q0030|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Mia%20madre%20fa%20il%20bucato%20ogni%20giorno.)
^it-Q0030-answer

**it-Q0031** — La pizza sarà qua tra cinque minuti.

The pizza will be here in five minutes.

Expected form: **La**

Why: Definite articles. [[Italian#^it-Q0031|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=La%20pizza%20sar%C3%A0%20qua%20tra%20cinque%20minuti.)
^it-Q0031-answer

**it-Q0032** — La pizza sarà qua tra cinque minuti.

The pizza will be here in five minutes.

Expected form: **La**

Why: Definite articles. [[Italian#^it-Q0032|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=La%20pizza%20sar%C3%A0%20qua%20tra%20cinque%20minuti.)
^it-Q0032-answer

**it-Q0033** — Tom è il mio operaio migliore.

Tom is my best worker.

Expected form: **il**

Why: Definite articles. [[Italian#^it-Q0033|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20%C3%A8%20il%20mio%20operaio%20migliore.)
^it-Q0033-answer

**it-Q0034** — Tom è il mio operaio migliore.

Tom is my best worker.

Why: Definite articles. [[Italian#^it-Q0034|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20%C3%A8%20il%20mio%20operaio%20migliore.)
^it-Q0034-answer

**it-Q0035** — Tom dice che spera che Mary lo faccia.

Tom says he hopes that Mary does that.

Why: Definite articles. [[Italian#^it-Q0035|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20dice%20che%20spera%20che%20Mary%20lo%20faccia.)
^it-Q0035-answer

**it-Q0036** — Tom dice che spera che Mary lo faccia.

Tom says he hopes that Mary does that.

Articles depend on gender, number and following sound. Lo and gli occur before particular masculine onsets, including z and s + consonant. Learn article and noun together.

Why: Definite articles. [[Italian#^it-Q0036|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20dice%20che%20spera%20che%20Mary%20lo%20faccia.)
^it-Q0036-answer

**it-Q0037** — Per piacere, mi spiegherà il significato di questa frase?

Will you please explain the meaning of this sentence to me?

Expected form: **il**

Why: Definite articles. [[Italian#^it-Q0037|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Per%20piacere%2C%20mi%20spiegher%C3%A0%20il%20significato%20di%20questa%20frase%3F)
^it-Q0037-answer

**it-Q0038** — Per piacere, mi spiegherà il significato di questa frase?

Will you please explain the meaning of this sentence to me?

Expected form: **il**

Why: Definite articles. [[Italian#^it-Q0038|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Per%20piacere%2C%20mi%20spiegher%C3%A0%20il%20significato%20di%20questa%20frase%3F)
^it-Q0038-answer

**it-Q0039** — Sono sotto la doccia.

They're in the shower.

Expected form: **la**

Why: Definite articles. [[Italian#^it-Q0039|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Sono%20sotto%20la%20doccia.)
^it-Q0039-answer

**it-Q0040** — Sono sotto la doccia.

They're in the shower.

Why: Definite articles. [[Italian#^it-Q0040|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Sono%20sotto%20la%20doccia.)
^it-Q0040-answer

**it-Q0041** — Sami è il pagliaccio della famiglia.

Sami is the clown of the family.

Why: Definite articles. [[Italian#^it-Q0041|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Sami%20%C3%A8%20il%20pagliaccio%20della%20famiglia.)
^it-Q0041-answer

**it-Q0042** — Sami è il pagliaccio della famiglia.

Sami is the clown of the family.

Articles depend on gender, number and following sound. Lo and gli occur before particular masculine onsets, including z and s + consonant. Learn article and noun together.

Why: Definite articles. [[Italian#^it-Q0042|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Sami%20%C3%A8%20il%20pagliaccio%20della%20famiglia.)
^it-Q0042-answer

**it-Q0043** — Vuole scambiare le nostre due pecore una per l'altra?

Do you want to trade our two sheep, one for another?

Expected form: **le**

Why: Definite articles. [[Italian#^it-Q0043|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Vuole%20scambiare%20le%20nostre%20due%20pecore%20una%20per%20l%27altra%3F)
^it-Q0043-answer

**it-Q0044** — Vuole scambiare le nostre due pecore una per l'altra?

Do you want to trade our two sheep, one for another?

Expected form: **le**

Why: Definite articles. [[Italian#^it-Q0044|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Vuole%20scambiare%20le%20nostre%20due%20pecore%20una%20per%20l%27altra%3F)
^it-Q0044-answer

**it-Q0045** — Gli dia le corna.

Give him the horns.

Expected form: **Gli**

Why: Definite articles. [[Italian#^it-Q0045|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Gli%20dia%20le%20corna.)
^it-Q0045-answer

**it-Q0046** — Gli dia le corna.

Give him the horns.

Why: Definite articles. [[Italian#^it-Q0046|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Gli%20dia%20le%20corna.)
^it-Q0046-answer

**it-Q0047** — Lui non fermò la macchina al semaforo rosso.

He did not stop his car at the red light.

Why: Definite articles. [[Italian#^it-Q0047|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Lui%20non%20ferm%C3%B2%20la%20macchina%20al%20semaforo%20rosso.)
^it-Q0047-answer

**it-Q0048** — Lui non fermò la macchina al semaforo rosso.

He did not stop his car at the red light.

Articles depend on gender, number and following sound. Lo and gli occur before particular masculine onsets, including z and s + consonant. Learn article and noun together.

Why: Definite articles. [[Italian#^it-Q0048|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Lui%20non%20ferm%C3%B2%20la%20macchina%20al%20semaforo%20rosso.)
^it-Q0048-answer

**it-Q0049** — A Sami non piacciono i cani.

Sami doesn't like dogs.

Expected form: **i**

Why: Definite articles. [[Italian#^it-Q0049|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=A%20Sami%20non%20piacciono%20i%20cani.)
^it-Q0049-answer

**it-Q0050** — A Sami non piacciono i cani.

Sami doesn't like dogs.

Expected form: **i**

Why: Definite articles. [[Italian#^it-Q0050|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=A%20Sami%20non%20piacciono%20i%20cani.)
^it-Q0050-answer


### Answers 51–100

**it-Q0051** — Non sono una spiona.

I'm not a tattletale.

Expected form: **una**

Why: Indefinite articles. [[Italian#^it-Q0051|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20sono%20una%20spiona.)
^it-Q0051-answer

**it-Q0052** — Non sono una spiona.

I'm not a tattletale.

Why: Indefinite articles. [[Italian#^it-Q0052|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20sono%20una%20spiona.)
^it-Q0052-answer

**it-Q0053** — A voi servirà un alibi.

You're going to need an alibi.

Why: Indefinite articles. [[Italian#^it-Q0053|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=A%20voi%20servir%C3%A0%20un%20alibi.)
^it-Q0053-answer

**it-Q0054** — A voi servirà un alibi.

You're going to need an alibi.

Un/uno introduce masculine singular nouns; una introduces feminine singular nouns. Feminine una elides before a vowel: un’amica. Masculine un before a vowel has no apostrophe.

Why: Indefinite articles. [[Italian#^it-Q0054|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=A%20voi%20servir%C3%A0%20un%20alibi.)
^it-Q0054-answer

**it-Q0055** — Sembra un po' depressa.

You seem a bit depressed.

Expected form: **un**

Why: Indefinite articles. [[Italian#^it-Q0055|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Sembra%20un%20po%27%20depressa.)
^it-Q0055-answer

**it-Q0056** — Sembra un po' depressa.

You seem a bit depressed.

Expected form: **un**

Why: Indefinite articles. [[Italian#^it-Q0056|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Sembra%20un%20po%27%20depressa.)
^it-Q0056-answer

**it-Q0057** — Pensavo lui fosse una donna.

I thought he was a woman.

Expected form: **una**

Why: Indefinite articles. [[Italian#^it-Q0057|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Pensavo%20lui%20fosse%20una%20donna.)
^it-Q0057-answer

**it-Q0058** — Pensavo lui fosse una donna.

I thought he was a woman.

Why: Indefinite articles. [[Italian#^it-Q0058|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Pensavo%20lui%20fosse%20una%20donna.)
^it-Q0058-answer

**it-Q0059** — Quell'uomo è un celebre cabarettista.

That man is a famous cabaret performer.

Why: Indefinite articles. [[Italian#^it-Q0059|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Quell%27uomo%20%C3%A8%20un%20celebre%20cabarettista.)
^it-Q0059-answer

**it-Q0060** — Quell'uomo è un celebre cabarettista.

That man is a famous cabaret performer.

Un/uno introduce masculine singular nouns; una introduces feminine singular nouns. Feminine una elides before a vowel: un’amica. Masculine un before a vowel has no apostrophe.

Why: Indefinite articles. [[Italian#^it-Q0060|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Quell%27uomo%20%C3%A8%20un%20celebre%20cabarettista.)
^it-Q0060-answer

**it-Q0061** — Lui ha una mente nobile.

He has a noble mind.

Expected form: **una**

Why: Indefinite articles. [[Italian#^it-Q0061|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Lui%20ha%20una%20mente%20nobile.)
^it-Q0061-answer

**it-Q0062** — Lui ha una mente nobile.

He has a noble mind.

Expected form: **una**

Why: Indefinite articles. [[Italian#^it-Q0062|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Lui%20ha%20una%20mente%20nobile.)
^it-Q0062-answer

**it-Q0063** — Sei un dottore.

You are a doctor.

Expected form: **un**

Why: Indefinite articles. [[Italian#^it-Q0063|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Sei%20un%20dottore.)
^it-Q0063-answer

**it-Q0064** — Sei un dottore.

You are a doctor.

Why: Indefinite articles. [[Italian#^it-Q0064|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Sei%20un%20dottore.)
^it-Q0064-answer

**it-Q0065** — Tom ha mangiato una tarda colazione.

Tom ate a late breakfast.

Why: Indefinite articles. [[Italian#^it-Q0065|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20ha%20mangiato%20una%20tarda%20colazione.)
^it-Q0065-answer

**it-Q0066** — Tom ha mangiato una tarda colazione.

Tom ate a late breakfast.

Un/uno introduce masculine singular nouns; una introduces feminine singular nouns. Feminine una elides before a vowel: un’amica. Masculine un before a vowel has no apostrophe.

Why: Indefinite articles. [[Italian#^it-Q0066|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20ha%20mangiato%20una%20tarda%20colazione.)
^it-Q0066-answer

**it-Q0067** — Per alcune espressioni, non è così facile trovare una traduzione appropriata.

For some expressions, it's not so easy to find an appropriate translation.

Expected form: **una**

Why: Indefinite articles. [[Italian#^it-Q0067|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Per%20alcune%20espressioni%2C%20non%20%C3%A8%20cos%C3%AC%20facile%20trovare%20una%20traduzione%20appropriata.)
^it-Q0067-answer

**it-Q0068** — Per alcune espressioni, non è così facile trovare una traduzione appropriata.

For some expressions, it's not so easy to find an appropriate translation.

Expected form: **una**

Why: Indefinite articles. [[Italian#^it-Q0068|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Per%20alcune%20espressioni%2C%20non%20%C3%A8%20cos%C3%AC%20facile%20trovare%20una%20traduzione%20appropriata.)
^it-Q0068-answer

**it-Q0069** — È una bella storia. L'unico problema è che non è vera.

That's a good story. The only problem is that it's not true.

Expected form: **una**

Why: Indefinite articles. [[Italian#^it-Q0069|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=%C3%88%20una%20bella%20storia.%20L%27unico%20problema%20%C3%A8%20che%20non%20%C3%A8%20vera.)
^it-Q0069-answer

**it-Q0070** — È una bella storia. L'unico problema è che non è vera.

That's a good story. The only problem is that it's not true.

Why: Indefinite articles. [[Italian#^it-Q0070|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=%C3%88%20una%20bella%20storia.%20L%27unico%20problema%20%C3%A8%20che%20non%20%C3%A8%20vera.)
^it-Q0070-answer

**it-Q0071** — Non mi sono mai innamorata di una ragazza.

I've never fallen in love with a girl.

Why: Indefinite articles. [[Italian#^it-Q0071|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20mi%20sono%20mai%20innamorata%20di%20una%20ragazza.)
^it-Q0071-answer

**it-Q0072** — Non mi sono mai innamorata di una ragazza.

I've never fallen in love with a girl.

Un/uno introduce masculine singular nouns; una introduces feminine singular nouns. Feminine una elides before a vowel: un’amica. Masculine un before a vowel has no apostrophe.

Why: Indefinite articles. [[Italian#^it-Q0072|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20mi%20sono%20mai%20innamorata%20di%20una%20ragazza.)
^it-Q0072-answer

**it-Q0073** — Una vecchia signora è morta bruciata.

An old woman was burnt to death.

Expected form: **Una**

Why: Indefinite articles. [[Italian#^it-Q0073|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Una%20vecchia%20signora%20%C3%A8%20morta%20bruciata.)
^it-Q0073-answer

**it-Q0074** — Una vecchia signora è morta bruciata.

An old woman was burnt to death.

Expected form: **Una**

Why: Indefinite articles. [[Italian#^it-Q0074|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Una%20vecchia%20signora%20%C3%A8%20morta%20bruciata.)
^it-Q0074-answer

**it-Q0075** — Prenda un po' di eggnog.

Have some eggnog.

Expected form: **un**

Why: Indefinite articles. [[Italian#^it-Q0075|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Prenda%20un%20po%27%20di%20eggnog.)
^it-Q0075-answer

**it-Q0076** — Prenda un po' di eggnog.

Have some eggnog.

Why: Indefinite articles. [[Italian#^it-Q0076|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Prenda%20un%20po%27%20di%20eggnog.)
^it-Q0076-answer

**it-Q0077** — Tom ha fatto un lavoro veramente buono.

Tom has done a really good job.

Why: Indefinite articles. [[Italian#^it-Q0077|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20ha%20fatto%20un%20lavoro%20veramente%20buono.)
^it-Q0077-answer

**it-Q0078** — Tom ha fatto un lavoro veramente buono.

Tom has done a really good job.

Un/uno introduce masculine singular nouns; una introduces feminine singular nouns. Feminine una elides before a vowel: un’amica. Masculine un before a vowel has no apostrophe.

Why: Indefinite articles. [[Italian#^it-Q0078|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20ha%20fatto%20un%20lavoro%20veramente%20buono.)
^it-Q0078-answer

**it-Q0079** — Tom fece un lavoro fantastico.

Tom did a fantastic job.

Expected form: **un**

Why: Indefinite articles. [[Italian#^it-Q0079|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20fece%20un%20lavoro%20fantastico.)
^it-Q0079-answer

**it-Q0080** — Tom fece un lavoro fantastico.

Tom did a fantastic job.

Expected form: **un**

Why: Indefinite articles. [[Italian#^it-Q0080|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20fece%20un%20lavoro%20fantastico.)
^it-Q0080-answer

**it-Q0081** — Voglio un telefono cellulare.

I want a cellular phone.

Expected form: **un**

Why: Indefinite articles. [[Italian#^it-Q0081|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Voglio%20un%20telefono%20cellulare.)
^it-Q0081-answer

**it-Q0082** — Voglio un telefono cellulare.

I want a cellular phone.

Why: Indefinite articles. [[Italian#^it-Q0082|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Voglio%20un%20telefono%20cellulare.)
^it-Q0082-answer

**it-Q0083** — Come inizio ho visitato Gerusalemme - un luogo sacro per tre religioni principali.

For a start, I visited Jerusalem - a sacred place for three major religions.

Why: Indefinite articles. [[Italian#^it-Q0083|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Come%20inizio%20ho%20visitato%20Gerusalemme%20-%20un%20luogo%20sacro%20per%20tre%20religioni%20principali.)
^it-Q0083-answer

**it-Q0084** — Come inizio ho visitato Gerusalemme - un luogo sacro per tre religioni principali.

For a start, I visited Jerusalem - a sacred place for three major religions.

Un/uno introduce masculine singular nouns; una introduces feminine singular nouns. Feminine una elides before a vowel: un’amica. Masculine un before a vowel has no apostrophe.

Why: Indefinite articles. [[Italian#^it-Q0084|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Come%20inizio%20ho%20visitato%20Gerusalemme%20-%20un%20luogo%20sacro%20per%20tre%20religioni%20principali.)
^it-Q0084-answer

**it-Q0085** — Tom ha chiesto un salario più alto.

Tom asked for a higher salary.

Expected form: **un**

Why: Indefinite articles. [[Italian#^it-Q0085|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20ha%20chiesto%20un%20salario%20pi%C3%B9%20alto.)
^it-Q0085-answer

**it-Q0086** — Tom ha chiesto un salario più alto.

Tom asked for a higher salary.

Expected form: **un**

Why: Indefinite articles. [[Italian#^it-Q0086|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20ha%20chiesto%20un%20salario%20pi%C3%B9%20alto.)
^it-Q0086-answer

**it-Q0087** — Io sto sperando in uno sconto veramente grande.

I'm hoping for a really big discount.

Expected form: **uno**

Why: Indefinite articles. [[Italian#^it-Q0087|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Io%20sto%20sperando%20in%20uno%20sconto%20veramente%20grande.)
^it-Q0087-answer

**it-Q0088** — Io sto sperando in uno sconto veramente grande.

I'm hoping for a really big discount.

Why: Indefinite articles. [[Italian#^it-Q0088|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Io%20sto%20sperando%20in%20uno%20sconto%20veramente%20grande.)
^it-Q0088-answer

**it-Q0089** — Tatoeba: Ricevuto un messaggio privato? Probabilmente è nei guai...

Tatoeba: Got a PM? You're probably in trouble...

Why: Indefinite articles. [[Italian#^it-Q0089|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tatoeba%3A%20Ricevuto%20un%20messaggio%20privato%3F%20Probabilmente%20%C3%A8%20nei%20guai...)
^it-Q0089-answer

**it-Q0090** — Tatoeba: Ricevuto un messaggio privato? Probabilmente è nei guai...

Tatoeba: Got a PM? You're probably in trouble...

Un/uno introduce masculine singular nouns; una introduces feminine singular nouns. Feminine una elides before a vowel: un’amica. Masculine un before a vowel has no apostrophe.

Why: Indefinite articles. [[Italian#^it-Q0090|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tatoeba%3A%20Ricevuto%20un%20messaggio%20privato%3F%20Probabilmente%20%C3%A8%20nei%20guai...)
^it-Q0090-answer

**it-Q0091** — Io penso che questo sarà un regalo carino.

I think this will make a nice gift.

Expected form: **un**

Why: Indefinite articles. [[Italian#^it-Q0091|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Io%20penso%20che%20questo%20sar%C3%A0%20un%20regalo%20carino.)
^it-Q0091-answer

**it-Q0092** — Io penso che questo sarà un regalo carino.

I think this will make a nice gift.

Expected form: **un**

Why: Indefinite articles. [[Italian#^it-Q0092|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Io%20penso%20che%20questo%20sar%C3%A0%20un%20regalo%20carino.)
^it-Q0092-answer

**it-Q0093** — Ne vorreste uno ora?

Would you like one now?

Expected form: **uno**

Why: Indefinite articles. [[Italian#^it-Q0093|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Ne%20vorreste%20uno%20ora%3F)
^it-Q0093-answer

**it-Q0094** — Ne vorreste uno ora?

Would you like one now?

Why: Indefinite articles. [[Italian#^it-Q0094|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Ne%20vorreste%20uno%20ora%3F)
^it-Q0094-answer

**it-Q0095** — Lui ha passato la serata a leggere un libro.

He spent the evening reading a book.

Why: Indefinite articles. [[Italian#^it-Q0095|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Lui%20ha%20passato%20la%20serata%20a%20leggere%20un%20libro.)
^it-Q0095-answer

**it-Q0096** — Lui ha passato la serata a leggere un libro.

He spent the evening reading a book.

Un/uno introduce masculine singular nouns; una introduces feminine singular nouns. Feminine una elides before a vowel: un’amica. Masculine un before a vowel has no apostrophe.

Why: Indefinite articles. [[Italian#^it-Q0096|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Lui%20ha%20passato%20la%20serata%20a%20leggere%20un%20libro.)
^it-Q0096-answer

**it-Q0097** — Noi avevamo una buona opinione di vostro figlio.

We had a good opinion of your son.

Expected form: **una**

Why: Indefinite articles. [[Italian#^it-Q0097|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Noi%20avevamo%20una%20buona%20opinione%20di%20vostro%20figlio.)
^it-Q0097-answer

**it-Q0098** — Noi avevamo una buona opinione di vostro figlio.

We had a good opinion of your son.

Expected form: **una**

Why: Indefinite articles. [[Italian#^it-Q0098|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Noi%20avevamo%20una%20buona%20opinione%20di%20vostro%20figlio.)
^it-Q0098-answer

**it-Q0099** — Tom sembra un po' più felice.

Tom is looking a bit happier.

Expected form: **un**

Why: Indefinite articles. [[Italian#^it-Q0099|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20sembra%20un%20po%27%20pi%C3%B9%20felice.)
^it-Q0099-answer

**it-Q0100** — Tom sembra un po' più felice.

Tom is looking a bit happier.

Why: Indefinite articles. [[Italian#^it-Q0100|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20sembra%20un%20po%27%20pi%C3%B9%20felice.)
^it-Q0100-answer


### Answers 101–150

**it-Q0101** — Ai bambini piace più giocare che studiare.

Children like playing more than studying.

Why: Articulated prepositions. [[Italian#^it-Q0101|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Ai%20bambini%20piace%20pi%C3%B9%20giocare%20che%20studiare.)
^it-Q0101-answer

**it-Q0102** — Ai bambini piace più giocare che studiare.

Children like playing more than studying.

Many prepositions combine with definite articles. The form retains article gender/number and follows the same sound-conditioned distinctions: a + il = al, a + lo = allo.

Why: Articulated prepositions. [[Italian#^it-Q0102|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Ai%20bambini%20piace%20pi%C3%B9%20giocare%20che%20studiare.)
^it-Q0102-answer

**it-Q0103** — Da quale parte del Canada venite?

Where in Canada are you from?

Expected form: **del**

Why: Articulated prepositions. [[Italian#^it-Q0103|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Da%20quale%20parte%20del%20Canada%20venite%3F)
^it-Q0103-answer

**it-Q0104** — Da quale parte del Canada venite?

Where in Canada are you from?

Expected form: **del**

Why: Articulated prepositions. [[Italian#^it-Q0104|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Da%20quale%20parte%20del%20Canada%20venite%3F)
^it-Q0104-answer

**it-Q0105** — A me serve del ghiaccio.

I need ice.

Expected form: **del**

Why: Articulated prepositions. [[Italian#^it-Q0105|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=A%20me%20serve%20del%20ghiaccio.)
^it-Q0105-answer

**it-Q0106** — A me serve del ghiaccio.

I need ice.

Why: Articulated prepositions. [[Italian#^it-Q0106|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=A%20me%20serve%20del%20ghiaccio.)
^it-Q0106-answer

**it-Q0107** — Sono allergica ai preti e alla religione.

I'm allergic to priests and religion.

Why: Articulated prepositions. [[Italian#^it-Q0107|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Sono%20allergica%20ai%20preti%20e%20alla%20religione.)
^it-Q0107-answer

**it-Q0108** — Sono allergica ai preti e alla religione.

I'm allergic to priests and religion.

Many prepositions combine with definite articles. The form retains article gender/number and follows the same sound-conditioned distinctions: a + il = al, a + lo = allo.

Why: Articulated prepositions. [[Italian#^it-Q0108|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Sono%20allergica%20ai%20preti%20e%20alla%20religione.)
^it-Q0108-answer

**it-Q0109** — Non avvantaggiarti delle debolezze degli altri.

Don't take advantage of others' weakness.

Expected form: **degli**

Why: Articulated prepositions. [[Italian#^it-Q0109|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20avvantaggiarti%20delle%20debolezze%20degli%20altri.)
^it-Q0109-answer

**it-Q0110** — Non avvantaggiarti delle debolezze degli altri.

Don't take advantage of others' weakness.

Expected form: **degli**

Why: Articulated prepositions. [[Italian#^it-Q0110|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20avvantaggiarti%20delle%20debolezze%20degli%20altri.)
^it-Q0110-answer

**it-Q0111** — Tom parlò del problema con Mary.

Tom spoke about the problem with Mary.

Expected form: **del**

Why: Articulated prepositions. [[Italian#^it-Q0111|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20parl%C3%B2%20del%20problema%20con%20Mary.)
^it-Q0111-answer

**it-Q0112** — Tom parlò del problema con Mary.

Tom spoke about the problem with Mary.

Why: Articulated prepositions. [[Italian#^it-Q0112|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20parl%C3%B2%20del%20problema%20con%20Mary.)
^it-Q0112-answer

**it-Q0113** — Ha pagato dei milioni di dollari per il dipinto.

He paid as much as a million dollars for the painting.

Why: Articulated prepositions. [[Italian#^it-Q0113|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Ha%20pagato%20dei%20milioni%20di%20dollari%20per%20il%20dipinto.)
^it-Q0113-answer

**it-Q0114** — Ha pagato dei milioni di dollari per il dipinto.

He paid as much as a million dollars for the painting.

Many prepositions combine with definite articles. The form retains article gender/number and follows the same sound-conditioned distinctions: a + il = al, a + lo = allo.

Why: Articulated prepositions. [[Italian#^it-Q0114|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Ha%20pagato%20dei%20milioni%20di%20dollari%20per%20il%20dipinto.)
^it-Q0114-answer

**it-Q0115** — Il ragazzo dorme nel salotto.

The boy sleeps in the living room.

Expected form: **nel**

Why: Articulated prepositions. [[Italian#^it-Q0115|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Il%20ragazzo%20dorme%20nel%20salotto.)
^it-Q0115-answer

**it-Q0116** — Il ragazzo dorme nel salotto.

The boy sleeps in the living room.

Expected form: **nel**

Why: Articulated prepositions. [[Italian#^it-Q0116|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Il%20ragazzo%20dorme%20nel%20salotto.)
^it-Q0116-answer

**it-Q0117** — Io non ti voglio nella mia auto.

I don't want you in my car.

Expected form: **nella**

Why: Articulated prepositions. [[Italian#^it-Q0117|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Io%20non%20ti%20voglio%20nella%20mia%20auto.)
^it-Q0117-answer

**it-Q0118** — Io non ti voglio nella mia auto.

I don't want you in my car.

Why: Articulated prepositions. [[Italian#^it-Q0118|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Io%20non%20ti%20voglio%20nella%20mia%20auto.)
^it-Q0118-answer

**it-Q0119** — Io giocai ai videogiochi dopo aver finito i compiti.

I played video games after I finished my homework.

Why: Articulated prepositions. [[Italian#^it-Q0119|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Io%20giocai%20ai%20videogiochi%20dopo%20aver%20finito%20i%20compiti.)
^it-Q0119-answer

**it-Q0120** — Io giocai ai videogiochi dopo aver finito i compiti.

I played video games after I finished my homework.

Many prepositions combine with definite articles. The form retains article gender/number and follows the same sound-conditioned distinctions: a + il = al, a + lo = allo.

Why: Articulated prepositions. [[Italian#^it-Q0120|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Io%20giocai%20ai%20videogiochi%20dopo%20aver%20finito%20i%20compiti.)
^it-Q0120-answer

**it-Q0121** — Sarò felice di partecipare alla tua festa.

I will be happy to attend your party.

Expected form: **alla**

Why: Articulated prepositions. [[Italian#^it-Q0121|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Sar%C3%B2%20felice%20di%20partecipare%20alla%20tua%20festa.)
^it-Q0121-answer

**it-Q0122** — Sarò felice di partecipare alla tua festa.

I will be happy to attend your party.

Expected form: **alla**

Why: Articulated prepositions. [[Italian#^it-Q0122|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Sar%C3%B2%20felice%20di%20partecipare%20alla%20tua%20festa.)
^it-Q0122-answer

**it-Q0123** — Gli immigrati entrarono nel paese in un flusso costante.

The immigrants entered the country in a steady flow.

Expected form: **nel**

Why: Articulated prepositions. [[Italian#^it-Q0123|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Gli%20immigrati%20entrarono%20nel%20paese%20in%20un%20flusso%20costante.)
^it-Q0123-answer

**it-Q0124** — Gli immigrati entrarono nel paese in un flusso costante.

The immigrants entered the country in a steady flow.

Why: Articulated prepositions. [[Italian#^it-Q0124|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Gli%20immigrati%20entrarono%20nel%20paese%20in%20un%20flusso%20costante.)
^it-Q0124-answer

**it-Q0125** — La molla nel mio orologio è rotta.

The spring in my watch is broken.

Why: Articulated prepositions. [[Italian#^it-Q0125|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=La%20molla%20nel%20mio%20orologio%20%C3%A8%20rotta.)
^it-Q0125-answer

**it-Q0126** — La molla nel mio orologio è rotta.

The spring in my watch is broken.

Many prepositions combine with definite articles. The form retains article gender/number and follows the same sound-conditioned distinctions: a + il = al, a + lo = allo.

Why: Articulated prepositions. [[Italian#^it-Q0126|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=La%20molla%20nel%20mio%20orologio%20%C3%A8%20rotta.)
^it-Q0126-answer

**it-Q0127** — La voglio nel mio ufficio.

I want it in my office.

Expected form: **nel**

Why: Articulated prepositions. [[Italian#^it-Q0127|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=La%20voglio%20nel%20mio%20ufficio.)
^it-Q0127-answer

**it-Q0128** — La voglio nel mio ufficio.

I want it in my office.

Expected form: **nel**

Why: Articulated prepositions. [[Italian#^it-Q0128|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=La%20voglio%20nel%20mio%20ufficio.)
^it-Q0128-answer

**it-Q0129** — Io non sarei dovuta andare a casa da sola tardi alla notte.

I shouldn't have gone home late at night by myself.

Expected form: **alla**

Why: Articulated prepositions. [[Italian#^it-Q0129|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Io%20non%20sarei%20dovuta%20andare%20a%20casa%20da%20sola%20tardi%20alla%20notte.)
^it-Q0129-answer

**it-Q0130** — Io non sarei dovuta andare a casa da sola tardi alla notte.

I shouldn't have gone home late at night by myself.

Why: Articulated prepositions. [[Italian#^it-Q0130|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Io%20non%20sarei%20dovuta%20andare%20a%20casa%20da%20sola%20tardi%20alla%20notte.)
^it-Q0130-answer

**it-Q0131** — Perché hai mentito sulla tua età?

Why did you lie about your age?

Why: Articulated prepositions. [[Italian#^it-Q0131|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Perch%C3%A9%20hai%20mentito%20sulla%20tua%20et%C3%A0%3F)
^it-Q0131-answer

**it-Q0132** — Perché hai mentito sulla tua età?

Why did you lie about your age?

Many prepositions combine with definite articles. The form retains article gender/number and follows the same sound-conditioned distinctions: a + il = al, a + lo = allo.

Why: Articulated prepositions. [[Italian#^it-Q0132|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Perch%C3%A9%20hai%20mentito%20sulla%20tua%20et%C3%A0%3F)
^it-Q0132-answer

**it-Q0133** — Questo cappello si abbina bene al vestito.

This hat goes together with the dress.

Expected form: **al**

Why: Articulated prepositions. [[Italian#^it-Q0133|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Questo%20cappello%20si%20abbina%20bene%20al%20vestito.)
^it-Q0133-answer

**it-Q0134** — Questo cappello si abbina bene al vestito.

This hat goes together with the dress.

Expected form: **al**

Why: Articulated prepositions. [[Italian#^it-Q0134|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Questo%20cappello%20si%20abbina%20bene%20al%20vestito.)
^it-Q0134-answer

**it-Q0135** — Mi potete dire come arrivare alla stazione?

Can you tell me how to get to the station?

Expected form: **alla**

Why: Articulated prepositions. [[Italian#^it-Q0135|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Mi%20potete%20dire%20come%20arrivare%20alla%20stazione%3F)
^it-Q0135-answer

**it-Q0136** — Mi potete dire come arrivare alla stazione?

Can you tell me how to get to the station?

Why: Articulated prepositions. [[Italian#^it-Q0136|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Mi%20potete%20dire%20come%20arrivare%20alla%20stazione%3F)
^it-Q0136-answer

**it-Q0137** — Dovrebbe vergognarsi della sua ignoranza.

You should be ashamed of your ignorance.

Why: Articulated prepositions. [[Italian#^it-Q0137|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Dovrebbe%20vergognarsi%20della%20sua%20ignoranza.)
^it-Q0137-answer

**it-Q0138** — Dovrebbe vergognarsi della sua ignoranza.

You should be ashamed of your ignorance.

Many prepositions combine with definite articles. The form retains article gender/number and follows the same sound-conditioned distinctions: a + il = al, a + lo = allo.

Why: Articulated prepositions. [[Italian#^it-Q0138|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Dovrebbe%20vergognarsi%20della%20sua%20ignoranza.)
^it-Q0138-answer

**it-Q0139** — Il Giappone voleva il controllo della Manciuria.

Japan wanted control of Manchuria.

Expected form: **della**

Why: Articulated prepositions. [[Italian#^it-Q0139|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Il%20Giappone%20voleva%20il%20controllo%20della%20Manciuria.)
^it-Q0139-answer

**it-Q0140** — Il Giappone voleva il controllo della Manciuria.

Japan wanted control of Manchuria.

Expected form: **della**

Why: Articulated prepositions. [[Italian#^it-Q0140|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Il%20Giappone%20voleva%20il%20controllo%20della%20Manciuria.)
^it-Q0140-answer

**it-Q0141** — Sto studiando inglese nella mia stanza.

I am studying English in my room.

Expected form: **nella**

Why: Articulated prepositions. [[Italian#^it-Q0141|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Sto%20studiando%20inglese%20nella%20mia%20stanza.)
^it-Q0141-answer

**it-Q0142** — Sto studiando inglese nella mia stanza.

I am studying English in my room.

Why: Articulated prepositions. [[Italian#^it-Q0142|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Sto%20studiando%20inglese%20nella%20mia%20stanza.)
^it-Q0142-answer

**it-Q0143** — Il leone è il re degli animali.

The lion is the king of beasts.

Why: Articulated prepositions. [[Italian#^it-Q0143|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Il%20leone%20%C3%A8%20il%20re%20degli%20animali.)
^it-Q0143-answer

**it-Q0144** — Il leone è il re degli animali.

The lion is the king of beasts.

Many prepositions combine with definite articles. The form retains article gender/number and follows the same sound-conditioned distinctions: a + il = al, a + lo = allo.

Why: Articulated prepositions. [[Italian#^it-Q0144|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Il%20leone%20%C3%A8%20il%20re%20degli%20animali.)
^it-Q0144-answer

**it-Q0145** — È cresciuto nella povertà.

He grew up in poverty.

Expected form: **nella**

Why: Articulated prepositions. [[Italian#^it-Q0145|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=%C3%88%20cresciuto%20nella%20povert%C3%A0.)
^it-Q0145-answer

**it-Q0146** — È cresciuto nella povertà.

He grew up in poverty.

Expected form: **nella**

Why: Articulated prepositions. [[Italian#^it-Q0146|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=%C3%88%20cresciuto%20nella%20povert%C3%A0.)
^it-Q0146-answer

**it-Q0147** — Perché date dei soldi a Tom?

Why do you give money to Tom?

Expected form: **dei**

Why: Articulated prepositions. [[Italian#^it-Q0147|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Perch%C3%A9%20date%20dei%20soldi%20a%20Tom%3F)
^it-Q0147-answer

**it-Q0148** — Perché date dei soldi a Tom?

Why do you give money to Tom?

Why: Articulated prepositions. [[Italian#^it-Q0148|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Perch%C3%A9%20date%20dei%20soldi%20a%20Tom%3F)
^it-Q0148-answer

**it-Q0149** — Hanno comprato degli ombrelli.

They brought umbrellas.

Why: Articulated prepositions. [[Italian#^it-Q0149|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Hanno%20comprato%20degli%20ombrelli.)
^it-Q0149-answer

**it-Q0150** — Hanno comprato degli ombrelli.

They brought umbrellas.

Many prepositions combine with definite articles. The form retains article gender/number and follows the same sound-conditioned distinctions: a + il = al, a + lo = allo.

Why: Articulated prepositions. [[Italian#^it-Q0150|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Hanno%20comprato%20degli%20ombrelli.)
^it-Q0150-answer


### Answers 151–200

**it-Q0151** — So che Tom è ricco.

I know Tom is wealthy.

Expected form: **è**

Why: Essere in the present. [[Italian#^it-Q0151|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=So%20che%20Tom%20%C3%A8%20ricco.)
^it-Q0151-answer

**it-Q0152** — So che Tom è ricco.

I know Tom is wealthy.

Expected form: **è**

Why: Essere in the present. [[Italian#^it-Q0152|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=So%20che%20Tom%20%C3%A8%20ricco.)
^it-Q0152-answer

**it-Q0153** — Siete state in grado di parlare con lui?

Were you able to talk to him?

Expected form: **Siete**

Why: Essere in the present. [[Italian#^it-Q0153|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Siete%20state%20in%20grado%20di%20parlare%20con%20lui%3F)
^it-Q0153-answer

**it-Q0154** — Siete state in grado di parlare con lui?

Were you able to talk to him?

Why: Essere in the present. [[Italian#^it-Q0154|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Siete%20state%20in%20grado%20di%20parlare%20con%20lui%3F)
^it-Q0154-answer

**it-Q0155** — Io sono nata per renderti felice.

I was born to make you happy.

Why: Essere in the present. [[Italian#^it-Q0155|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Io%20sono%20nata%20per%20renderti%20felice.)
^it-Q0155-answer

**it-Q0156** — Io sono nata per renderti felice.

I was born to make you happy.

Essere is irregular and can act as copula or compound-tense auxiliary. Sono can mean I am or they are. Context and subject agreement resolve the form.

Why: Essere in the present. [[Italian#^it-Q0156|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Io%20sono%20nata%20per%20renderti%20felice.)
^it-Q0156-answer

**it-Q0157** — Non è niente di straordinario.

It's nothing extraordinary.

Expected form: **è**

Why: Essere in the present. [[Italian#^it-Q0157|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20%C3%A8%20niente%20di%20straordinario.)
^it-Q0157-answer

**it-Q0158** — Non è niente di straordinario.

It's nothing extraordinary.

Expected form: **è**

Why: Essere in the present. [[Italian#^it-Q0158|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20%C3%A8%20niente%20di%20straordinario.)
^it-Q0158-answer

**it-Q0159** — Tom è diabetico.

Tom's diabetic.

Expected form: **è**

Why: Essere in the present. [[Italian#^it-Q0159|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20%C3%A8%20diabetico.)
^it-Q0159-answer

**it-Q0160** — Tom è diabetico.

Tom's diabetic.

Why: Essere in the present. [[Italian#^it-Q0160|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20%C3%A8%20diabetico.)
^it-Q0160-answer

**it-Q0161** — Perché non è soddisfatta?

Why are you not satisfied?

Why: Essere in the present. [[Italian#^it-Q0161|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Perch%C3%A9%20non%20%C3%A8%20soddisfatta%3F)
^it-Q0161-answer

**it-Q0162** — Perché non è soddisfatta?

Why are you not satisfied?

Essere is irregular and can act as copula or compound-tense auxiliary. Sono can mean I am or they are. Context and subject agreement resolve the form.

Why: Essere in the present. [[Italian#^it-Q0162|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Perch%C3%A9%20non%20%C3%A8%20soddisfatta%3F)
^it-Q0162-answer

**it-Q0163** — È molto meglio di quanto non fosse cinque anni fa.

He is far better off than he was five years ago.

Expected form: **È**

Why: Essere in the present. [[Italian#^it-Q0163|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=%C3%88%20molto%20meglio%20di%20quanto%20non%20fosse%20cinque%20anni%20fa.)
^it-Q0163-answer

**it-Q0164** — È molto meglio di quanto non fosse cinque anni fa.

He is far better off than he was five years ago.

Expected form: **È**

Why: Essere in the present. [[Italian#^it-Q0164|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=%C3%88%20molto%20meglio%20di%20quanto%20non%20fosse%20cinque%20anni%20fa.)
^it-Q0164-answer

**it-Q0165** — Sami è ritornato dal Cairo.

Sami returned from Cairo.

Expected form: **è**

Why: Essere in the present. [[Italian#^it-Q0165|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Sami%20%C3%A8%20ritornato%20dal%20Cairo.)
^it-Q0165-answer

**it-Q0166** — Sami è ritornato dal Cairo.

Sami returned from Cairo.

Why: Essere in the present. [[Italian#^it-Q0166|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Sami%20%C3%A8%20ritornato%20dal%20Cairo.)
^it-Q0166-answer

**it-Q0167** — Tom è eccentrico, vero?

Tom is eccentric, isn't he?

Why: Essere in the present. [[Italian#^it-Q0167|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20%C3%A8%20eccentrico%2C%20vero%3F)
^it-Q0167-answer

**it-Q0168** — Tom è eccentrico, vero?

Tom is eccentric, isn't he?

Essere is irregular and can act as copula or compound-tense auxiliary. Sono can mean I am or they are. Context and subject agreement resolve the form.

Why: Essere in the present. [[Italian#^it-Q0168|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20%C3%A8%20eccentrico%2C%20vero%3F)
^it-Q0168-answer

**it-Q0169** — Tom e Mary sono stati sposati per tre anni.

Tom and Mary have been married three years.

Expected form: **sono**

Why: Essere in the present. [[Italian#^it-Q0169|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20e%20Mary%20sono%20stati%20sposati%20per%20tre%20anni.)
^it-Q0169-answer

**it-Q0170** — Tom e Mary sono stati sposati per tre anni.

Tom and Mary have been married three years.

Expected form: **sono**

Why: Essere in the present. [[Italian#^it-Q0170|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20e%20Mary%20sono%20stati%20sposati%20per%20tre%20anni.)
^it-Q0170-answer

**it-Q0171** — Nulla è gratuito.

Nothing's free.

Expected form: **è**

Why: Essere in the present. [[Italian#^it-Q0171|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Nulla%20%C3%A8%20gratuito.)
^it-Q0171-answer

**it-Q0172** — Nulla è gratuito.

Nothing's free.

Why: Essere in the present. [[Italian#^it-Q0172|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Nulla%20%C3%A8%20gratuito.)
^it-Q0172-answer

**it-Q0173** — Sono impegnato questa notte.

I'm busy tonight.

Why: Essere in the present. [[Italian#^it-Q0173|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Sono%20impegnato%20questa%20notte.)
^it-Q0173-answer

**it-Q0174** — Sono impegnato questa notte.

I'm busy tonight.

Essere is irregular and can act as copula or compound-tense auxiliary. Sono can mean I am or they are. Context and subject agreement resolve the form.

Why: Essere in the present. [[Italian#^it-Q0174|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Sono%20impegnato%20questa%20notte.)
^it-Q0174-answer

**it-Q0175** — Tom si è laureato.

Tom graduated.

Expected form: **è**

Why: Essere in the present. [[Italian#^it-Q0175|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20si%20%C3%A8%20laureato.)
^it-Q0175-answer

**it-Q0176** — Tom si è laureato.

Tom graduated.

Expected form: **è**

Why: Essere in the present. [[Italian#^it-Q0176|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20si%20%C3%A8%20laureato.)
^it-Q0176-answer

**it-Q0177** — Tom è metodico, vero?

Tom is methodical, isn't he?

Expected form: **è**

Why: Essere in the present. [[Italian#^it-Q0177|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20%C3%A8%20metodico%2C%20vero%3F)
^it-Q0177-answer

**it-Q0178** — Tom è metodico, vero?

Tom is methodical, isn't he?

Why: Essere in the present. [[Italian#^it-Q0178|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20%C3%A8%20metodico%2C%20vero%3F)
^it-Q0178-answer

**it-Q0179** — È molto veloce, vero?

He's very fast, isn't he?

Why: Essere in the present. [[Italian#^it-Q0179|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=%C3%88%20molto%20veloce%2C%20vero%3F)
^it-Q0179-answer

**it-Q0180** — È molto veloce, vero?

He's very fast, isn't he?

Essere is irregular and can act as copula or compound-tense auxiliary. Sono can mean I am or they are. Context and subject agreement resolve the form.

Why: Essere in the present. [[Italian#^it-Q0180|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=%C3%88%20molto%20veloce%2C%20vero%3F)
^it-Q0180-answer

**it-Q0181** — C'è qualcosa da mangiare?

Is there anything to eat?

Expected form: **è**

Why: Essere in the present. [[Italian#^it-Q0181|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=C%27%C3%A8%20qualcosa%20da%20mangiare%3F)
^it-Q0181-answer

**it-Q0182** — C'è qualcosa da mangiare?

Is there anything to eat?

Expected form: **è**

Why: Essere in the present. [[Italian#^it-Q0182|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=C%27%C3%A8%20qualcosa%20da%20mangiare%3F)
^it-Q0182-answer

**it-Q0183** — Non sono fortunata come te.

I'm not as lucky as you.

Expected form: **sono**

Why: Essere in the present. [[Italian#^it-Q0183|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20sono%20fortunata%20come%20te.)
^it-Q0183-answer

**it-Q0184** — Non sono fortunata come te.

I'm not as lucky as you.

Why: Essere in the present. [[Italian#^it-Q0184|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20sono%20fortunata%20come%20te.)
^it-Q0184-answer

**it-Q0185** — Sono così solo.

I am so lonely.

Why: Essere in the present. [[Italian#^it-Q0185|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Sono%20cos%C3%AC%20solo.)
^it-Q0185-answer

**it-Q0186** — Sono così solo.

I am so lonely.

Essere is irregular and can act as copula or compound-tense auxiliary. Sono can mean I am or they are. Context and subject agreement resolve the form.

Why: Essere in the present. [[Italian#^it-Q0186|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Sono%20cos%C3%AC%20solo.)
^it-Q0186-answer

**it-Q0187** — È andata via liscia.

It went off smoothly.

Expected form: **È**

Why: Essere in the present. [[Italian#^it-Q0187|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=%C3%88%20andata%20via%20liscia.)
^it-Q0187-answer

**it-Q0188** — È andata via liscia.

It went off smoothly.

Expected form: **È**

Why: Essere in the present. [[Italian#^it-Q0188|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=%C3%88%20andata%20via%20liscia.)
^it-Q0188-answer

**it-Q0189** — Lei è impegnata adesso, quindi non riesce a parlare con voi.

She's busy now, so she can't talk with you.

Expected form: **è**

Why: Essere in the present. [[Italian#^it-Q0189|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Lei%20%C3%A8%20impegnata%20adesso%2C%20quindi%20non%20riesce%20a%20parlare%20con%20voi.)
^it-Q0189-answer

**it-Q0190** — Lei è impegnata adesso, quindi non riesce a parlare con voi.

She's busy now, so she can't talk with you.

Why: Essere in the present. [[Italian#^it-Q0190|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Lei%20%C3%A8%20impegnata%20adesso%2C%20quindi%20non%20riesce%20a%20parlare%20con%20voi.)
^it-Q0190-answer

**it-Q0191** — Sono quasi alta come mio padre.

I'm almost as tall as my father.

Why: Essere in the present. [[Italian#^it-Q0191|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Sono%20quasi%20alta%20come%20mio%20padre.)
^it-Q0191-answer

**it-Q0192** — Sono quasi alta come mio padre.

I'm almost as tall as my father.

Essere is irregular and can act as copula or compound-tense auxiliary. Sono can mean I am or they are. Context and subject agreement resolve the form.

Why: Essere in the present. [[Italian#^it-Q0192|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Sono%20quasi%20alta%20come%20mio%20padre.)
^it-Q0192-answer

**it-Q0193** — Tom e Mary sono là.

Tom and Mary are there.

Expected form: **sono**

Why: Essere in the present. [[Italian#^it-Q0193|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20e%20Mary%20sono%20l%C3%A0.)
^it-Q0193-answer

**it-Q0194** — Tom e Mary sono là.

Tom and Mary are there.

Expected form: **sono**

Why: Essere in the present. [[Italian#^it-Q0194|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20e%20Mary%20sono%20l%C3%A0.)
^it-Q0194-answer

**it-Q0195** — Tom non è comunista.

Tom isn't a communist.

Expected form: **è**

Why: Essere in the present. [[Italian#^it-Q0195|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20non%20%C3%A8%20comunista.)
^it-Q0195-answer

**it-Q0196** — Tom non è comunista.

Tom isn't a communist.

Why: Essere in the present. [[Italian#^it-Q0196|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20non%20%C3%A8%20comunista.)
^it-Q0196-answer

**it-Q0197** — Che cosa ci siamo persi?

What did we miss?

Why: Essere in the present. [[Italian#^it-Q0197|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Che%20cosa%20ci%20siamo%20persi%3F)
^it-Q0197-answer

**it-Q0198** — Che cosa ci siamo persi?

What did we miss?

Essere is irregular and can act as copula or compound-tense auxiliary. Sono can mean I am or they are. Context and subject agreement resolve the form.

Why: Essere in the present. [[Italian#^it-Q0198|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Che%20cosa%20ci%20siamo%20persi%3F)
^it-Q0198-answer

**it-Q0199** — Lei è stato impegnato, vero?

You've been busy, haven't you?

Expected form: **è**

Why: Essere in the present. [[Italian#^it-Q0199|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Lei%20%C3%A8%20stato%20impegnato%2C%20vero%3F)
^it-Q0199-answer

**it-Q0200** — Lei è stato impegnato, vero?

You've been busy, haven't you?

Expected form: **è**

Why: Essere in the present. [[Italian#^it-Q0200|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Lei%20%C3%A8%20stato%20impegnato%2C%20vero%3F)
^it-Q0200-answer


### Answers 201–250

**it-Q0201** — Tom ha rinunciato.

Tom quit.

Expected form: **ha**

Why: Avere in the present. [[Italian#^it-Q0201|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20ha%20rinunciato.)
^it-Q0201-answer

**it-Q0202** — Tom ha rinunciato.

Tom quit.

Why: Avere in the present. [[Italian#^it-Q0202|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20ha%20rinunciato.)
^it-Q0202-answer

**it-Q0203** — Ti ho vista baciarlo. Non negarlo!

I saw you kiss him. Do not deny it!

Why: Avere in the present. [[Italian#^it-Q0203|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Ti%20ho%20vista%20baciarlo.%20Non%20negarlo%21)
^it-Q0203-answer

**it-Q0204** — Ti ho vista baciarlo. Non negarlo!

I saw you kiss him. Do not deny it!

Avere expresses possession and forms many compound tenses. H is silent in these forms but distinguishes written homophones such as ha/a and ho/o.

Why: Avere in the present. [[Italian#^it-Q0204|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Ti%20ho%20vista%20baciarlo.%20Non%20negarlo%21)
^it-Q0204-answer

**it-Q0205** — Lei ha dello scotch?

Do you have any tape?

Expected form: **ha**

Why: Avere in the present. [[Italian#^it-Q0205|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Lei%20ha%20dello%20scotch%3F)
^it-Q0205-answer

**it-Q0206** — Lei ha dello scotch?

Do you have any tape?

Expected form: **ha**

Why: Avere in the present. [[Italian#^it-Q0206|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Lei%20ha%20dello%20scotch%3F)
^it-Q0206-answer

**it-Q0207** — Chi ha detto a Tom di non baciare Mary?

Who told Tom not to kiss Mary?

Expected form: **ha**

Why: Avere in the present. [[Italian#^it-Q0207|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Chi%20ha%20detto%20a%20Tom%20di%20non%20baciare%20Mary%3F)
^it-Q0207-answer

**it-Q0208** — Chi ha detto a Tom di non baciare Mary?

Who told Tom not to kiss Mary?

Why: Avere in the present. [[Italian#^it-Q0208|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Chi%20ha%20detto%20a%20Tom%20di%20non%20baciare%20Mary%3F)
^it-Q0208-answer

**it-Q0209** — Tom non ha molto tempo libero come me.

Tom doesn't have as much free time as I do.

Why: Avere in the present. [[Italian#^it-Q0209|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20non%20ha%20molto%20tempo%20libero%20come%20me.)
^it-Q0209-answer

**it-Q0210** — Tom non ha molto tempo libero come me.

Tom doesn't have as much free time as I do.

Avere expresses possession and forms many compound tenses. H is silent in these forms but distinguishes written homophones such as ha/a and ho/o.

Why: Avere in the present. [[Italian#^it-Q0210|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20non%20ha%20molto%20tempo%20libero%20come%20me.)
^it-Q0210-answer

**it-Q0211** — Lui mi ha calciato nelle palle.

He kicked me in the balls.

Expected form: **ha**

Why: Avere in the present. [[Italian#^it-Q0211|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Lui%20mi%20ha%20calciato%20nelle%20palle.)
^it-Q0211-answer

**it-Q0212** — Lui mi ha calciato nelle palle.

He kicked me in the balls.

Expected form: **ha**

Why: Avere in the present. [[Italian#^it-Q0212|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Lui%20mi%20ha%20calciato%20nelle%20palle.)
^it-Q0212-answer

**it-Q0213** — Voi avete ancora paura che possa capitare qualcosa?

Are you still afraid something might happen?

Expected form: **avete**

Why: Avere in the present. [[Italian#^it-Q0213|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Voi%20avete%20ancora%20paura%20che%20possa%20capitare%20qualcosa%3F)
^it-Q0213-answer

**it-Q0214** — Voi avete ancora paura che possa capitare qualcosa?

Are you still afraid something might happen?

Why: Avere in the present. [[Italian#^it-Q0214|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Voi%20avete%20ancora%20paura%20che%20possa%20capitare%20qualcosa%3F)
^it-Q0214-answer

**it-Q0215** — Tom ha detto che non aveva finito.

Tom said that he wasn't done.

Why: Avere in the present. [[Italian#^it-Q0215|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20ha%20detto%20che%20non%20aveva%20finito.)
^it-Q0215-answer

**it-Q0216** — Tom ha detto che non aveva finito.

Tom said that he wasn't done.

Avere expresses possession and forms many compound tenses. H is silent in these forms but distinguishes written homophones such as ha/a and ho/o.

Why: Avere in the present. [[Italian#^it-Q0216|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20ha%20detto%20che%20non%20aveva%20finito.)
^it-Q0216-answer

**it-Q0217** — Qualcuno ha provato a uccidere Tom.

Somebody tried to kill Tom.

Expected form: **ha**

Why: Avere in the present. [[Italian#^it-Q0217|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Qualcuno%20ha%20provato%20a%20uccidere%20Tom.)
^it-Q0217-answer

**it-Q0218** — Qualcuno ha provato a uccidere Tom.

Somebody tried to kill Tom.

Expected form: **ha**

Why: Avere in the present. [[Italian#^it-Q0218|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Qualcuno%20ha%20provato%20a%20uccidere%20Tom.)
^it-Q0218-answer

**it-Q0219** — Dove avete messo le mie chiavi?

Where did you put my keys?

Expected form: **avete**

Why: Avere in the present. [[Italian#^it-Q0219|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Dove%20avete%20messo%20le%20mie%20chiavi%3F)
^it-Q0219-answer

**it-Q0220** — Dove avete messo le mie chiavi?

Where did you put my keys?

Why: Avere in the present. [[Italian#^it-Q0220|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Dove%20avete%20messo%20le%20mie%20chiavi%3F)
^it-Q0220-answer

**it-Q0221** — Ho chiesto a Tom di controllare il mio rapporto.

I asked Tom to proofread my report.

Why: Avere in the present. [[Italian#^it-Q0221|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Ho%20chiesto%20a%20Tom%20di%20controllare%20il%20mio%20rapporto.)
^it-Q0221-answer

**it-Q0222** — Ho chiesto a Tom di controllare il mio rapporto.

I asked Tom to proofread my report.

Avere expresses possession and forms many compound tenses. H is silent in these forms but distinguishes written homophones such as ha/a and ho/o.

Why: Avere in the present. [[Italian#^it-Q0222|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Ho%20chiesto%20a%20Tom%20di%20controllare%20il%20mio%20rapporto.)
^it-Q0222-answer

**it-Q0223** — Tutti l'hanno ignorata.

Everyone ignored her.

Expected form: **hanno**

Why: Avere in the present. [[Italian#^it-Q0223|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tutti%20l%27hanno%20ignorata.)
^it-Q0223-answer

**it-Q0224** — Tutti l'hanno ignorata.

Everyone ignored her.

Expected form: **hanno**

Why: Avere in the present. [[Italian#^it-Q0224|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tutti%20l%27hanno%20ignorata.)
^it-Q0224-answer

**it-Q0225** — Tom non ha parlato di voi.

Tom didn't talk about you.

Expected form: **ha**

Why: Avere in the present. [[Italian#^it-Q0225|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20non%20ha%20parlato%20di%20voi.)
^it-Q0225-answer

**it-Q0226** — Tom non ha parlato di voi.

Tom didn't talk about you.

Why: Avere in the present. [[Italian#^it-Q0226|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20non%20ha%20parlato%20di%20voi.)
^it-Q0226-answer

**it-Q0227** — Ho acconsentito ad andare.

I consented to go.

Why: Avere in the present. [[Italian#^it-Q0227|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Ho%20acconsentito%20ad%20andare.)
^it-Q0227-answer

**it-Q0228** — Ho acconsentito ad andare.

I consented to go.

Avere expresses possession and forms many compound tenses. H is silent in these forms but distinguishes written homophones such as ha/a and ho/o.

Why: Avere in the present. [[Italian#^it-Q0228|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Ho%20acconsentito%20ad%20andare.)
^it-Q0228-answer

**it-Q0229** — Voi avete già ordinato?

Have you already ordered?

Expected form: **avete**

Why: Avere in the present. [[Italian#^it-Q0229|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Voi%20avete%20gi%C3%A0%20ordinato%3F)
^it-Q0229-answer

**it-Q0230** — Voi avete già ordinato?

Have you already ordered?

Expected form: **avete**

Why: Avere in the present. [[Italian#^it-Q0230|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Voi%20avete%20gi%C3%A0%20ordinato%3F)
^it-Q0230-answer

**it-Q0231** — Noi abbiamo camminato per diverse miglia.

We walked for miles.

Expected form: **abbiamo**

Why: Avere in the present. [[Italian#^it-Q0231|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Noi%20abbiamo%20camminato%20per%20diverse%20miglia.)
^it-Q0231-answer

**it-Q0232** — Noi abbiamo camminato per diverse miglia.

We walked for miles.

Why: Avere in the present. [[Italian#^it-Q0232|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Noi%20abbiamo%20camminato%20per%20diverse%20miglia.)
^it-Q0232-answer

**it-Q0233** — Ha battuto la testa.

He banged his head.

Why: Avere in the present. [[Italian#^it-Q0233|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Ha%20battuto%20la%20testa.)
^it-Q0233-answer

**it-Q0234** — Ha battuto la testa.

He banged his head.

Avere expresses possession and forms many compound tenses. H is silent in these forms but distinguishes written homophones such as ha/a and ho/o.

Why: Avere in the present. [[Italian#^it-Q0234|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Ha%20battuto%20la%20testa.)
^it-Q0234-answer

**it-Q0235** — Lei l'ha già chiamata?

Have you called her yet?

Expected form: **ha**

Why: Avere in the present. [[Italian#^it-Q0235|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Lei%20l%27ha%20gi%C3%A0%20chiamata%3F)
^it-Q0235-answer

**it-Q0236** — Lei l'ha già chiamata?

Have you called her yet?

Expected form: **ha**

Why: Avere in the present. [[Italian#^it-Q0236|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Lei%20l%27ha%20gi%C3%A0%20chiamata%3F)
^it-Q0236-answer

**it-Q0237** — Non è quello che hai promesso.

That's not what you promised.

Expected form: **hai**

Why: Avere in the present. [[Italian#^it-Q0237|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20%C3%A8%20quello%20che%20hai%20promesso.)
^it-Q0237-answer

**it-Q0238** — Non è quello che hai promesso.

That's not what you promised.

Why: Avere in the present. [[Italian#^it-Q0238|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20%C3%A8%20quello%20che%20hai%20promesso.)
^it-Q0238-answer

**it-Q0239** — Ha qualche amico.

He has a few friends.

Why: Avere in the present. [[Italian#^it-Q0239|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Ha%20qualche%20amico.)
^it-Q0239-answer

**it-Q0240** — Ha qualche amico.

He has a few friends.

Avere expresses possession and forms many compound tenses. H is silent in these forms but distinguishes written homophones such as ha/a and ho/o.

Why: Avere in the present. [[Italian#^it-Q0240|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Ha%20qualche%20amico.)
^it-Q0240-answer

**it-Q0241** — Non l'ho mai suggerito.

I never suggested that.

Expected form: **ho**

Why: Avere in the present. [[Italian#^it-Q0241|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20l%27ho%20mai%20suggerito.)
^it-Q0241-answer

**it-Q0242** — Non l'ho mai suggerito.

I never suggested that.

Expected form: **ho**

Why: Avere in the present. [[Italian#^it-Q0242|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20l%27ho%20mai%20suggerito.)
^it-Q0242-answer

**it-Q0243** — Non l'ho mai visto qua.

I've never seen him here.

Expected form: **ho**

Why: Avere in the present. [[Italian#^it-Q0243|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20l%27ho%20mai%20visto%20qua.)
^it-Q0243-answer

**it-Q0244** — Non l'ho mai visto qua.

I've never seen him here.

Why: Avere in the present. [[Italian#^it-Q0244|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20l%27ho%20mai%20visto%20qua.)
^it-Q0244-answer

**it-Q0245** — Noi abbiamo dovuto tenerla segreta.

We had to keep it a secret.

Why: Avere in the present. [[Italian#^it-Q0245|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Noi%20abbiamo%20dovuto%20tenerla%20segreta.)
^it-Q0245-answer

**it-Q0246** — Noi abbiamo dovuto tenerla segreta.

We had to keep it a secret.

Avere expresses possession and forms many compound tenses. H is silent in these forms but distinguishes written homophones such as ha/a and ho/o.

Why: Avere in the present. [[Italian#^it-Q0246|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Noi%20abbiamo%20dovuto%20tenerla%20segreta.)
^it-Q0246-answer

**it-Q0247** — Lei ha rovinato i suoi vestiti.

She's ruined her clothes.

Expected form: **ha**

Why: Avere in the present. [[Italian#^it-Q0247|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Lei%20ha%20rovinato%20i%20suoi%20vestiti.)
^it-Q0247-answer

**it-Q0248** — Lei ha rovinato i suoi vestiti.

She's ruined her clothes.

Expected form: **ha**

Why: Avere in the present. [[Italian#^it-Q0248|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Lei%20ha%20rovinato%20i%20suoi%20vestiti.)
^it-Q0248-answer

**it-Q0249** — Quanti anni hanno i vostri fratelli e sorelle?

How old are your brothers and sisters?

Expected form: **hanno**

Why: Avere in the present. [[Italian#^it-Q0249|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Quanti%20anni%20hanno%20i%20vostri%20fratelli%20e%20sorelle%3F)
^it-Q0249-answer

**it-Q0250** — Quanti anni hanno i vostri fratelli e sorelle?

How old are your brothers and sisters?

Why: Avere in the present. [[Italian#^it-Q0250|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Quanti%20anni%20hanno%20i%20vostri%20fratelli%20e%20sorelle%3F)
^it-Q0250-answer


### Answers 251–300

**it-Q0251** — Tom non aveva denaro.

Tom had no money.

Why: Imperfect perspective. [[Italian#^it-Q0251|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20non%20aveva%20denaro.)
^it-Q0251-answer

**it-Q0252** — Tom non aveva denaro.

Tom had no money.

The imperfetto presents past states, habits and background. Passato prossimo or passato remoto can present events as bounded. The choice reflects viewpoint and discourse as well as regional style.

Why: Imperfect perspective. [[Italian#^it-Q0252|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20non%20aveva%20denaro.)
^it-Q0252-answer

**it-Q0253** — Era troppo lenta.

You were too slow.

Expected form: **Era**

Why: Imperfect perspective. [[Italian#^it-Q0253|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Era%20troppo%20lenta.)
^it-Q0253-answer

**it-Q0254** — Era troppo lenta.

You were too slow.

Expected form: **Era**

Why: Imperfect perspective. [[Italian#^it-Q0254|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Era%20troppo%20lenta.)
^it-Q0254-answer

**it-Q0255** — Lui voleva aiutare le sue amiche.

He wanted to help his friends.

Expected form: **voleva**

Why: Imperfect perspective. [[Italian#^it-Q0255|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Lui%20voleva%20aiutare%20le%20sue%20amiche.)
^it-Q0255-answer

**it-Q0256** — Lui voleva aiutare le sue amiche.

He wanted to help his friends.

Why: Imperfect perspective. [[Italian#^it-Q0256|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Lui%20voleva%20aiutare%20le%20sue%20amiche.)
^it-Q0256-answer

**it-Q0257** — Chi era il responsabile?

Who was responsible?

Why: Imperfect perspective. [[Italian#^it-Q0257|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Chi%20era%20il%20responsabile%3F)
^it-Q0257-answer

**it-Q0258** — Chi era il responsabile?

Who was responsible?

The imperfetto presents past states, habits and background. Passato prossimo or passato remoto can present events as bounded. The choice reflects viewpoint and discourse as well as regional style.

Why: Imperfect perspective. [[Italian#^it-Q0258|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Chi%20era%20il%20responsabile%3F)
^it-Q0258-answer

**it-Q0259** — Il postino era di buonumore stamattina.

The postman was in good spirits this morning.

Expected form: **era**

Why: Imperfect perspective. [[Italian#^it-Q0259|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Il%20postino%20era%20di%20buonumore%20stamattina.)
^it-Q0259-answer

**it-Q0260** — Il postino era di buonumore stamattina.

The postman was in good spirits this morning.

Expected form: **era**

Why: Imperfect perspective. [[Italian#^it-Q0260|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Il%20postino%20era%20di%20buonumore%20stamattina.)
^it-Q0260-answer

**it-Q0261** — Loro chi erano esattamente?

Who exactly were they?

Expected form: **erano**

Why: Imperfect perspective. [[Italian#^it-Q0261|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Loro%20chi%20erano%20esattamente%3F)
^it-Q0261-answer

**it-Q0262** — Loro chi erano esattamente?

Who exactly were they?

Why: Imperfect perspective. [[Italian#^it-Q0262|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Loro%20chi%20erano%20esattamente%3F)
^it-Q0262-answer

**it-Q0263** — Il teatro era troppo affollato.

The theater was too crowded.

Why: Imperfect perspective. [[Italian#^it-Q0263|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Il%20teatro%20era%20troppo%20affollato.)
^it-Q0263-answer

**it-Q0264** — Il teatro era troppo affollato.

The theater was too crowded.

The imperfetto presents past states, habits and background. Passato prossimo or passato remoto can present events as bounded. The choice reflects viewpoint and discourse as well as regional style.

Why: Imperfect perspective. [[Italian#^it-Q0264|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Il%20teatro%20era%20troppo%20affollato.)
^it-Q0264-answer

**it-Q0265** — Tom cercò di aprire il cassetto, ma era bloccato.

Tom tried to open the drawer, but it was stuck.

Expected form: **era**

Why: Imperfect perspective. [[Italian#^it-Q0265|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20cerc%C3%B2%20di%20aprire%20il%20cassetto%2C%20ma%20era%20bloccato.)
^it-Q0265-answer

**it-Q0266** — Tom cercò di aprire il cassetto, ma era bloccato.

Tom tried to open the drawer, but it was stuck.

Expected form: **era**

Why: Imperfect perspective. [[Italian#^it-Q0266|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20cerc%C3%B2%20di%20aprire%20il%20cassetto%2C%20ma%20era%20bloccato.)
^it-Q0266-answer

**it-Q0267** — Perché era a Boston?

Why were you in Boston?

Expected form: **era**

Why: Imperfect perspective. [[Italian#^it-Q0267|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Perch%C3%A9%20era%20a%20Boston%3F)
^it-Q0267-answer

**it-Q0268** — Perché era a Boston?

Why were you in Boston?

Why: Imperfect perspective. [[Italian#^it-Q0268|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Perch%C3%A9%20era%20a%20Boston%3F)
^it-Q0268-answer

**it-Q0269** — Tom non voleva tornare all'orfanotrofio.

Tom didn't want to go back to the orphanage.

Why: Imperfect perspective. [[Italian#^it-Q0269|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20non%20voleva%20tornare%20all%27orfanotrofio.)
^it-Q0269-answer

**it-Q0270** — Tom non voleva tornare all'orfanotrofio.

Tom didn't want to go back to the orphanage.

The imperfetto presents past states, habits and background. Passato prossimo or passato remoto can present events as bounded. The choice reflects viewpoint and discourse as well as regional style.

Why: Imperfect perspective. [[Italian#^it-Q0270|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20non%20voleva%20tornare%20all%27orfanotrofio.)
^it-Q0270-answer

**it-Q0271** — Tom era un po' affamato.

Tom was a little hungry.

Expected form: **era**

Why: Imperfect perspective. [[Italian#^it-Q0271|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20era%20un%20po%27%20affamato.)
^it-Q0271-answer

**it-Q0272** — Tom era un po' affamato.

Tom was a little hungry.

Expected form: **era**

Why: Imperfect perspective. [[Italian#^it-Q0272|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20era%20un%20po%27%20affamato.)
^it-Q0272-answer

**it-Q0273** — Il capitano era l'ultima persona che ha lasciato la nave che affondava.

The captain was the last person to leave the sinking ship.

Expected form: **era**

Why: Imperfect perspective. [[Italian#^it-Q0273|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Il%20capitano%20era%20l%27ultima%20persona%20che%20ha%20lasciato%20la%20nave%20che%20affondava.)
^it-Q0273-answer

**it-Q0274** — Il capitano era l'ultima persona che ha lasciato la nave che affondava.

The captain was the last person to leave the sinking ship.

Why: Imperfect perspective. [[Italian#^it-Q0274|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Il%20capitano%20era%20l%27ultima%20persona%20che%20ha%20lasciato%20la%20nave%20che%20affondava.)
^it-Q0274-answer

**it-Q0275** — Lei avrebbe voluto una vita più rilassante, ma era impossibile, date le circostanze.

She wished for a more relaxing life, but that was impossible under the circumstances.

Why: Imperfect perspective. [[Italian#^it-Q0275|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Lei%20avrebbe%20voluto%20una%20vita%20pi%C3%B9%20rilassante%2C%20ma%20era%20impossibile%2C%20date%20le%20circostanze.)
^it-Q0275-answer

**it-Q0276** — Lei avrebbe voluto una vita più rilassante, ma era impossibile, date le circostanze.

She wished for a more relaxing life, but that was impossible under the circumstances.

The imperfetto presents past states, habits and background. Passato prossimo or passato remoto can present events as bounded. The choice reflects viewpoint and discourse as well as regional style.

Why: Imperfect perspective. [[Italian#^it-Q0276|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Lei%20avrebbe%20voluto%20una%20vita%20pi%C3%B9%20rilassante%2C%20ma%20era%20impossibile%2C%20date%20le%20circostanze.)
^it-Q0276-answer

**it-Q0277** — Faceva freddo ieri?

Was it cold yesterday?

Expected form: **Faceva**

Why: Imperfect perspective. [[Italian#^it-Q0277|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Faceva%20freddo%20ieri%3F)
^it-Q0277-answer

**it-Q0278** — Faceva freddo ieri?

Was it cold yesterday?

Expected form: **Faceva**

Why: Imperfect perspective. [[Italian#^it-Q0278|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Faceva%20freddo%20ieri%3F)
^it-Q0278-answer

**it-Q0279** — Sarah Bernhardt era una attrice di teatro francese.

Sarah Bernhardt was a French stage actress.

Expected form: **era**

Why: Imperfect perspective. [[Italian#^it-Q0279|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Sarah%20Bernhardt%20era%20una%20attrice%20di%20teatro%20francese.)
^it-Q0279-answer

**it-Q0280** — Sarah Bernhardt era una attrice di teatro francese.

Sarah Bernhardt was a French stage actress.

Why: Imperfect perspective. [[Italian#^it-Q0280|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Sarah%20Bernhardt%20era%20una%20attrice%20di%20teatro%20francese.)
^it-Q0280-answer

**it-Q0281** — Lei aveva paura di fargli del male.

She was afraid of hurting him.

Why: Imperfect perspective. [[Italian#^it-Q0281|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Lei%20aveva%20paura%20di%20fargli%20del%20male.)
^it-Q0281-answer

**it-Q0282** — Lei aveva paura di fargli del male.

She was afraid of hurting him.

The imperfetto presents past states, habits and background. Passato prossimo or passato remoto can present events as bounded. The choice reflects viewpoint and discourse as well as regional style.

Why: Imperfect perspective. [[Italian#^it-Q0282|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Lei%20aveva%20paura%20di%20fargli%20del%20male.)
^it-Q0282-answer

**it-Q0283** — Come lo sapeva che Tom era malato?

How did you know Tom was sick?

Expected form: **era**

Why: Imperfect perspective. [[Italian#^it-Q0283|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Come%20lo%20sapeva%20che%20Tom%20era%20malato%3F)
^it-Q0283-answer

**it-Q0284** — Come lo sapeva che Tom era malato?

How did you know Tom was sick?

Expected form: **era**

Why: Imperfect perspective. [[Italian#^it-Q0284|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Come%20lo%20sapeva%20che%20Tom%20era%20malato%3F)
^it-Q0284-answer

**it-Q0285** — Forse Tom non aveva tempo.

Maybe Tom didn't have time.

Expected form: **aveva**

Why: Imperfect perspective. [[Italian#^it-Q0285|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Forse%20Tom%20non%20aveva%20tempo.)
^it-Q0285-answer

**it-Q0286** — Forse Tom non aveva tempo.

Maybe Tom didn't have time.

Why: Imperfect perspective. [[Italian#^it-Q0286|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Forse%20Tom%20non%20aveva%20tempo.)
^it-Q0286-answer

**it-Q0287** — Non avevo nessuno con cui parlare.

I had no one to talk to.

Why: Imperfect perspective. [[Italian#^it-Q0287|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20avevo%20nessuno%20con%20cui%20parlare.)
^it-Q0287-answer

**it-Q0288** — Non avevo nessuno con cui parlare.

I had no one to talk to.

The imperfetto presents past states, habits and background. Passato prossimo or passato remoto can present events as bounded. The choice reflects viewpoint and discourse as well as regional style.

Why: Imperfect perspective. [[Italian#^it-Q0288|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20avevo%20nessuno%20con%20cui%20parlare.)
^it-Q0288-answer

**it-Q0289** — La polizia dice che Tom non era armato.

The police say Tom wasn't armed.

Expected form: **era**

Why: Imperfect perspective. [[Italian#^it-Q0289|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=La%20polizia%20dice%20che%20Tom%20non%20era%20armato.)
^it-Q0289-answer

**it-Q0290** — La polizia dice che Tom non era armato.

The police say Tom wasn't armed.

Expected form: **era**

Why: Imperfect perspective. [[Italian#^it-Q0290|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=La%20polizia%20dice%20che%20Tom%20non%20era%20armato.)
^it-Q0290-answer

**it-Q0291** — Non c'era bisogno di avere fretta. Sei arrivato troppo presto.

You needn't have hurried; you've arrived too early.

Expected form: **era**

Why: Imperfect perspective. [[Italian#^it-Q0291|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20c%27era%20bisogno%20di%20avere%20fretta.%20Sei%20arrivato%20troppo%20presto.)
^it-Q0291-answer

**it-Q0292** — Non c'era bisogno di avere fretta. Sei arrivato troppo presto.

You needn't have hurried; you've arrived too early.

Why: Imperfect perspective. [[Italian#^it-Q0292|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20c%27era%20bisogno%20di%20avere%20fretta.%20Sei%20arrivato%20troppo%20presto.)
^it-Q0292-answer

**it-Q0293** — Non avevo idea che voi sapeste suonare il trombone.

I had no idea you knew how to play the trombone.

Why: Imperfect perspective. [[Italian#^it-Q0293|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20avevo%20idea%20che%20voi%20sapeste%20suonare%20il%20trombone.)
^it-Q0293-answer

**it-Q0294** — Non avevo idea che voi sapeste suonare il trombone.

I had no idea you knew how to play the trombone.

The imperfetto presents past states, habits and background. Passato prossimo or passato remoto can present events as bounded. The choice reflects viewpoint and discourse as well as regional style.

Why: Imperfect perspective. [[Italian#^it-Q0294|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20avevo%20idea%20che%20voi%20sapeste%20suonare%20il%20trombone.)
^it-Q0294-answer

**it-Q0295** — Erano tutti presenti.

All were present.

Expected form: **Erano**

Why: Imperfect perspective. [[Italian#^it-Q0295|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Erano%20tutti%20presenti.)
^it-Q0295-answer

**it-Q0296** — Erano tutti presenti.

All were present.

Expected form: **Erano**

Why: Imperfect perspective. [[Italian#^it-Q0296|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Erano%20tutti%20presenti.)
^it-Q0296-answer

**it-Q0297** — Ricorderebbe ancora una volta alla gente che questa non era solo la sua decisione personale, ma molte decisioni altrui.

He would remind people again that it was decided not only by him but by many others.

Expected form: **era**

Why: Imperfect perspective. [[Italian#^it-Q0297|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Ricorderebbe%20ancora%20una%20volta%20alla%20gente%20che%20questa%20non%20era%20solo%20la%20sua%20decisione%20personale%2C%20ma%20molte%20decisioni%20altrui.)
^it-Q0297-answer

**it-Q0298** — Ricorderebbe ancora una volta alla gente che questa non era solo la sua decisione personale, ma molte decisioni altrui.

He would remind people again that it was decided not only by him but by many others.

Why: Imperfect perspective. [[Italian#^it-Q0298|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Ricorderebbe%20ancora%20una%20volta%20alla%20gente%20che%20questa%20non%20era%20solo%20la%20sua%20decisione%20personale%2C%20ma%20molte%20decisioni%20altrui.)
^it-Q0298-answer

**it-Q0299** — Tom aveva delle idee differenti.

Tom had different ideas.

Why: Imperfect perspective. [[Italian#^it-Q0299|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20aveva%20delle%20idee%20differenti.)
^it-Q0299-answer

**it-Q0300** — Tom aveva delle idee differenti.

Tom had different ideas.

The imperfetto presents past states, habits and background. Passato prossimo or passato remoto can present events as bounded. The choice reflects viewpoint and discourse as well as regional style.

Why: Imperfect perspective. [[Italian#^it-Q0300|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20aveva%20delle%20idee%20differenti.)
^it-Q0300-answer


### Answers 301–350

**it-Q0301** — Non so se l'avrebbe fatto per me.

I don't know if he would have done it for me.

Expected form: **fatto**

Why: Past participles. [[Italian#^it-Q0301|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20so%20se%20l%27avrebbe%20fatto%20per%20me.)
^it-Q0301-answer

**it-Q0302** — Non so se l'avrebbe fatto per me.

I don't know if he would have done it for me.

Expected form: **fatto**

Why: Past participles. [[Italian#^it-Q0302|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20so%20se%20l%27avrebbe%20fatto%20per%20me.)
^it-Q0302-answer

**it-Q0303** — Se oggi fosse stata domenica, saremmo andati a pescare.

If it were Sunday today, we would go fishing.

Expected form: **stata**

Why: Past participles. [[Italian#^it-Q0303|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Se%20oggi%20fosse%20stata%20domenica%2C%20saremmo%20andati%20a%20pescare.)
^it-Q0303-answer

**it-Q0304** — Se oggi fosse stata domenica, saremmo andati a pescare.

If it were Sunday today, we would go fishing.

Why: Past participles. [[Italian#^it-Q0304|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Se%20oggi%20fosse%20stata%20domenica%2C%20saremmo%20andati%20a%20pescare.)
^it-Q0304-answer

**it-Q0305** — Mi dispiace di essere stato così maleducato.

I'm sorry I was so rude.

Why: Past participles. [[Italian#^it-Q0305|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Mi%20dispiace%20di%20essere%20stato%20cos%C3%AC%20maleducato.)
^it-Q0305-answer

**it-Q0306** — Mi dispiace di essere stato così maleducato.

I'm sorry I was so rude.

The passato prossimo combines an auxiliary with a participle. With essere, the participle generally agrees with the subject. Direct-object clitics can affect agreement with avere.

Why: Past participles. [[Italian#^it-Q0306|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Mi%20dispiace%20di%20essere%20stato%20cos%C3%AC%20maleducato.)
^it-Q0306-answer

**it-Q0307** — Tom ha detto che non ci aiuterà.

Tom said he isn't going to help us.

Expected form: **detto**

Why: Past participles. [[Italian#^it-Q0307|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20ha%20detto%20che%20non%20ci%20aiuter%C3%A0.)
^it-Q0307-answer

**it-Q0308** — Tom ha detto che non ci aiuterà.

Tom said he isn't going to help us.

Expected form: **detto**

Why: Past participles. [[Italian#^it-Q0308|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20ha%20detto%20che%20non%20ci%20aiuter%C3%A0.)
^it-Q0308-answer

**it-Q0309** — Il mio dottore mi ha detto di smettere di prendere l'aspirina.

My doctor told me to quit taking aspirin.

Expected form: **detto**

Why: Past participles. [[Italian#^it-Q0309|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Il%20mio%20dottore%20mi%20ha%20detto%20di%20smettere%20di%20prendere%20l%27aspirina.)
^it-Q0309-answer

**it-Q0310** — Il mio dottore mi ha detto di smettere di prendere l'aspirina.

My doctor told me to quit taking aspirin.

Why: Past participles. [[Italian#^it-Q0310|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Il%20mio%20dottore%20mi%20ha%20detto%20di%20smettere%20di%20prendere%20l%27aspirina.)
^it-Q0310-answer

**it-Q0311** — Hai visto chi l'ha fatta?

Did you see who did it?

Why: Past participles. [[Italian#^it-Q0311|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Hai%20visto%20chi%20l%27ha%20fatta%3F)
^it-Q0311-answer

**it-Q0312** — Hai visto chi l'ha fatta?

Did you see who did it?

The passato prossimo combines an auxiliary with a participle. With essere, the participle generally agrees with the subject. Direct-object clitics can affect agreement with avere.

Why: Past participles. [[Italian#^it-Q0312|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Hai%20visto%20chi%20l%27ha%20fatta%3F)
^it-Q0312-answer

**it-Q0313** — Perché gli hai detto di farla?

Why did you tell him to do it?

Expected form: **detto**

Why: Past participles. [[Italian#^it-Q0313|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Perch%C3%A9%20gli%20hai%20detto%20di%20farla%3F)
^it-Q0313-answer

**it-Q0314** — Perché gli hai detto di farla?

Why did you tell him to do it?

Expected form: **detto**

Why: Past participles. [[Italian#^it-Q0314|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Perch%C3%A9%20gli%20hai%20detto%20di%20farla%3F)
^it-Q0314-answer

**it-Q0315** — Non ho mai visto quel tizio prima.

I've never seen that guy before.

Expected form: **visto**

Why: Past participles. [[Italian#^it-Q0315|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20ho%20mai%20visto%20quel%20tizio%20prima.)
^it-Q0315-answer

**it-Q0316** — Non ho mai visto quel tizio prima.

I've never seen that guy before.

Why: Past participles. [[Italian#^it-Q0316|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20ho%20mai%20visto%20quel%20tizio%20prima.)
^it-Q0316-answer

**it-Q0317** — Tutto è stato preparato.

Everything has been arranged.

Why: Past participles. [[Italian#^it-Q0317|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tutto%20%C3%A8%20stato%20preparato.)
^it-Q0317-answer

**it-Q0318** — Tutto è stato preparato.

Everything has been arranged.

The passato prossimo combines an auxiliary with a participle. With essere, the participle generally agrees with the subject. Direct-object clitics can affect agreement with avere.

Why: Past participles. [[Italian#^it-Q0318|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tutto%20%C3%A8%20stato%20preparato.)
^it-Q0318-answer

**it-Q0319** — Tom ci deve avere detto la verità.

Tom must've told us the truth.

Expected form: **detto**

Why: Past participles. [[Italian#^it-Q0319|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20ci%20deve%20avere%20detto%20la%20verit%C3%A0.)
^it-Q0319-answer

**it-Q0320** — Tom ci deve avere detto la verità.

Tom must've told us the truth.

Expected form: **detto**

Why: Past participles. [[Italian#^it-Q0320|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20ci%20deve%20avere%20detto%20la%20verit%C3%A0.)
^it-Q0320-answer

**it-Q0321** — Non hai visto le mie chiavi?

Didn't you see my keys?

Expected form: **visto**

Why: Past participles. [[Italian#^it-Q0321|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20hai%20visto%20le%20mie%20chiavi%3F)
^it-Q0321-answer

**it-Q0322** — Non hai visto le mie chiavi?

Didn't you see my keys?

Why: Past participles. [[Italian#^it-Q0322|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20hai%20visto%20le%20mie%20chiavi%3F)
^it-Q0322-answer

**it-Q0323** — Sì, ne ho visto uno molte volte.

Yes, I have seen one many times.

Why: Past participles. [[Italian#^it-Q0323|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=S%C3%AC%2C%20ne%20ho%20visto%20uno%20molte%20volte.)
^it-Q0323-answer

**it-Q0324** — Sì, ne ho visto uno molte volte.

Yes, I have seen one many times.

The passato prossimo combines an auxiliary with a participle. With essere, the participle generally agrees with the subject. Direct-object clitics can affect agreement with avere.

Why: Past participles. [[Italian#^it-Q0324|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=S%C3%AC%2C%20ne%20ho%20visto%20uno%20molte%20volte.)
^it-Q0324-answer

**it-Q0325** — Tom è stato sequestrato.

Tom was abducted.

Expected form: **stato**

Why: Past participles. [[Italian#^it-Q0325|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20%C3%A8%20stato%20sequestrato.)
^it-Q0325-answer

**it-Q0326** — Tom è stato sequestrato.

Tom was abducted.

Expected form: **stato**

Why: Past participles. [[Italian#^it-Q0326|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20%C3%A8%20stato%20sequestrato.)
^it-Q0326-answer

**it-Q0327** — Ha detto che non l'avrebbe fatta.

She said she wouldn't do it.

Expected form: **detto**

Why: Past participles. [[Italian#^it-Q0327|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Ha%20detto%20che%20non%20l%27avrebbe%20fatta.)
^it-Q0327-answer

**it-Q0328** — Ha detto che non l'avrebbe fatta.

She said she wouldn't do it.

Why: Past participles. [[Italian#^it-Q0328|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Ha%20detto%20che%20non%20l%27avrebbe%20fatta.)
^it-Q0328-answer

**it-Q0329** — Tu hai mai scritto una lettera a Mary?

Have you ever written a letter to Mary?

Why: Past participles. [[Italian#^it-Q0329|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tu%20hai%20mai%20scritto%20una%20lettera%20a%20Mary%3F)
^it-Q0329-answer

**it-Q0330** — Tu hai mai scritto una lettera a Mary?

Have you ever written a letter to Mary?

The passato prossimo combines an auxiliary with a participle. With essere, the participle generally agrees with the subject. Direct-object clitics can affect agreement with avere.

Why: Past participles. [[Italian#^it-Q0330|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tu%20hai%20mai%20scritto%20una%20lettera%20a%20Mary%3F)
^it-Q0330-answer

**it-Q0331** — Lui è un uomo che si è fatto da solo.

He is a self-made man.

Expected form: **fatto**

Why: Past participles. [[Italian#^it-Q0331|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Lui%20%C3%A8%20un%20uomo%20che%20si%20%C3%A8%20fatto%20da%20solo.)
^it-Q0331-answer

**it-Q0332** — Lui è un uomo che si è fatto da solo.

He is a self-made man.

Expected form: **fatto**

Why: Past participles. [[Italian#^it-Q0332|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Lui%20%C3%A8%20un%20uomo%20che%20si%20%C3%A8%20fatto%20da%20solo.)
^it-Q0332-answer

**it-Q0333** — Perché nessuno ha fatto nulla?

Why didn't anybody do anything?

Expected form: **fatto**

Why: Past participles. [[Italian#^it-Q0333|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Perch%C3%A9%20nessuno%20ha%20fatto%20nulla%3F)
^it-Q0333-answer

**it-Q0334** — Perché nessuno ha fatto nulla?

Why didn't anybody do anything?

Why: Past participles. [[Italian#^it-Q0334|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Perch%C3%A9%20nessuno%20ha%20fatto%20nulla%3F)
^it-Q0334-answer

**it-Q0335** — Questo museo è stato chiuso per cinque anni.

This museum has been closed for five years.

Why: Past participles. [[Italian#^it-Q0335|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Questo%20museo%20%C3%A8%20stato%20chiuso%20per%20cinque%20anni.)
^it-Q0335-answer

**it-Q0336** — Questo museo è stato chiuso per cinque anni.

This museum has been closed for five years.

The passato prossimo combines an auxiliary with a participle. With essere, the participle generally agrees with the subject. Direct-object clitics can affect agreement with avere.

Why: Past participles. [[Italian#^it-Q0336|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Questo%20museo%20%C3%A8%20stato%20chiuso%20per%20cinque%20anni.)
^it-Q0336-answer

**it-Q0337** — Ha detto che è disoccupato.

He said that he's unemployed.

Expected form: **detto**

Why: Past participles. [[Italian#^it-Q0337|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Ha%20detto%20che%20%C3%A8%20disoccupato.)
^it-Q0337-answer

**it-Q0338** — Ha detto che è disoccupato.

He said that he's unemployed.

Expected form: **detto**

Why: Past participles. [[Italian#^it-Q0338|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Ha%20detto%20che%20%C3%A8%20disoccupato.)
^it-Q0338-answer

**it-Q0339** — Ha detto che li amava.

You said you loved them.

Expected form: **detto**

Why: Past participles. [[Italian#^it-Q0339|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Ha%20detto%20che%20li%20amava.)
^it-Q0339-answer

**it-Q0340** — Ha detto che li amava.

You said you loved them.

Why: Past participles. [[Italian#^it-Q0340|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Ha%20detto%20che%20li%20amava.)
^it-Q0340-answer

**it-Q0341** — Lo studente ha letto il libro la notte prima dell'esame.

The student read the book the night before the exam.

Why: Past participles. [[Italian#^it-Q0341|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Lo%20studente%20ha%20letto%20il%20libro%20la%20notte%20prima%20dell%27esame.)
^it-Q0341-answer

**it-Q0342** — Lo studente ha letto il libro la notte prima dell'esame.

The student read the book the night before the exam.

The passato prossimo combines an auxiliary with a participle. With essere, the participle generally agrees with the subject. Direct-object clitics can affect agreement with avere.

Why: Past participles. [[Italian#^it-Q0342|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Lo%20studente%20ha%20letto%20il%20libro%20la%20notte%20prima%20dell%27esame.)
^it-Q0342-answer

**it-Q0343** — Quello è stato scritto da Taro Akagawa.

That was written by Taro Akagawa.

Expected form: **stato**

Why: Past participles. [[Italian#^it-Q0343|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Quello%20%C3%A8%20stato%20scritto%20da%20Taro%20Akagawa.)
^it-Q0343-answer

**it-Q0344** — Quello è stato scritto da Taro Akagawa.

That was written by Taro Akagawa.

Expected form: **stato**

Why: Past participles. [[Italian#^it-Q0344|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Quello%20%C3%A8%20stato%20scritto%20da%20Taro%20Akagawa.)
^it-Q0344-answer

**it-Q0345** — Io sono sempre stata appassionata di football.

I've always been passionate about football.

Expected form: **stata**

Why: Past participles. [[Italian#^it-Q0345|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Io%20sono%20sempre%20stata%20appassionata%20di%20football.)
^it-Q0345-answer

**it-Q0346** — Io sono sempre stata appassionata di football.

I've always been passionate about football.

Why: Past participles. [[Italian#^it-Q0346|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Io%20sono%20sempre%20stata%20appassionata%20di%20football.)
^it-Q0346-answer

**it-Q0347** — Perché non sei andata con loro?

Why didn't you go with them?

Why: Past participles. [[Italian#^it-Q0347|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Perch%C3%A9%20non%20sei%20andata%20con%20loro%3F)
^it-Q0347-answer

**it-Q0348** — Perché non sei andata con loro?

Why didn't you go with them?

The passato prossimo combines an auxiliary with a participle. With essere, the participle generally agrees with the subject. Direct-object clitics can affect agreement with avere.

Why: Past participles. [[Italian#^it-Q0348|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Perch%C3%A9%20non%20sei%20andata%20con%20loro%3F)
^it-Q0348-answer

**it-Q0349** — L'ho detto a William, ma non mi ha creduta.

I told William, but he didn't believe me.

Expected form: **detto**

Why: Past participles. [[Italian#^it-Q0349|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=L%27ho%20detto%20a%20William%2C%20ma%20non%20mi%20ha%20creduta.)
^it-Q0349-answer

**it-Q0350** — L'ho detto a William, ma non mi ha creduta.

I told William, but he didn't believe me.

Expected form: **detto**

Why: Past participles. [[Italian#^it-Q0350|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=L%27ho%20detto%20a%20William%2C%20ma%20non%20mi%20ha%20creduta.)
^it-Q0350-answer


### Answers 351–400

**it-Q0351** — Non penso che Tom sarà impressionato.

I don't think Tom will be impressed.

Expected form: **sarà**

Why: Future forms. [[Italian#^it-Q0351|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20penso%20che%20Tom%20sar%C3%A0%20impressionato.)
^it-Q0351-answer

**it-Q0352** — Non penso che Tom sarà impressionato.

I don't think Tom will be impressed.

Why: Future forms. [[Italian#^it-Q0352|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20penso%20che%20Tom%20sar%C3%A0%20impressionato.)
^it-Q0352-answer

**it-Q0353** — Lui sarà di ritorno tra un'ora.

He will be back in an hour.

Why: Future forms. [[Italian#^it-Q0353|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Lui%20sar%C3%A0%20di%20ritorno%20tra%20un%27ora.)
^it-Q0353-answer

**it-Q0354** — Lui sarà di ritorno tra un'ora.

He will be back in an hour.

The futuro expresses future situations and can also mark a present conjecture. Many frequent verbs have irregular future stems, which recur in the conditional.

Why: Future forms. [[Italian#^it-Q0354|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Lui%20sar%C3%A0%20di%20ritorno%20tra%20un%27ora.)
^it-Q0354-answer

**it-Q0355** — Andrò a parlare con Tom.

I'll go talk to Tom.

Expected form: **Andrò**

Why: Future forms. [[Italian#^it-Q0355|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Andr%C3%B2%20a%20parlare%20con%20Tom.)
^it-Q0355-answer

**it-Q0356** — Andrò a parlare con Tom.

I'll go talk to Tom.

Expected form: **Andrò**

Why: Future forms. [[Italian#^it-Q0356|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Andr%C3%B2%20a%20parlare%20con%20Tom.)
^it-Q0356-answer

**it-Q0357** — È molto improbabile che Tom sarà lì.

It's very unlikely that Tom will be there.

Expected form: **sarà**

Why: Future forms. [[Italian#^it-Q0357|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=%C3%88%20molto%20improbabile%20che%20Tom%20sar%C3%A0%20l%C3%AC.)
^it-Q0357-answer

**it-Q0358** — È molto improbabile che Tom sarà lì.

It's very unlikely that Tom will be there.

Why: Future forms. [[Italian#^it-Q0358|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=%C3%88%20molto%20improbabile%20che%20Tom%20sar%C3%A0%20l%C3%AC.)
^it-Q0358-answer

**it-Q0359** — Ha detto che lo farà presto.

He said he'll do that soon.

Why: Future forms. [[Italian#^it-Q0359|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Ha%20detto%20che%20lo%20far%C3%A0%20presto.)
^it-Q0359-answer

**it-Q0360** — Ha detto che lo farà presto.

He said he'll do that soon.

The futuro expresses future situations and can also mark a present conjecture. Many frequent verbs have irregular future stems, which recur in the conditional.

Why: Future forms. [[Italian#^it-Q0360|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Ha%20detto%20che%20lo%20far%C3%A0%20presto.)
^it-Q0360-answer

**it-Q0361** — Questa macchia non andrà via.

This stain won't come out.

Expected form: **andrà**

Why: Future forms. [[Italian#^it-Q0361|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Questa%20macchia%20non%20andr%C3%A0%20via.)
^it-Q0361-answer

**it-Q0362** — Questa macchia non andrà via.

This stain won't come out.

Expected form: **andrà**

Why: Future forms. [[Italian#^it-Q0362|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Questa%20macchia%20non%20andr%C3%A0%20via.)
^it-Q0362-answer

**it-Q0363** — Lei sarà qui questa sera.

She will be here this evening.

Expected form: **sarà**

Why: Future forms. [[Italian#^it-Q0363|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Lei%20sar%C3%A0%20qui%20questa%20sera.)
^it-Q0363-answer

**it-Q0364** — Lei sarà qui questa sera.

She will be here this evening.

Why: Future forms. [[Italian#^it-Q0364|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Lei%20sar%C3%A0%20qui%20questa%20sera.)
^it-Q0364-answer

**it-Q0365** — La farà sorridere.

It will make you smile.

Why: Future forms. [[Italian#^it-Q0365|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=La%20far%C3%A0%20sorridere.)
^it-Q0365-answer

**it-Q0366** — La farà sorridere.

It will make you smile.

The futuro expresses future situations and can also mark a present conjecture. Many frequent verbs have irregular future stems, which recur in the conditional.

Why: Future forms. [[Italian#^it-Q0366|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=La%20far%C3%A0%20sorridere.)
^it-Q0366-answer

**it-Q0367** — Tom avrà bisogno di questo.

Tom will need this.

Expected form: **avrà**

Why: Future forms. [[Italian#^it-Q0367|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20avr%C3%A0%20bisogno%20di%20questo.)
^it-Q0367-answer

**it-Q0368** — Tom avrà bisogno di questo.

Tom will need this.

Expected form: **avrà**

Why: Future forms. [[Italian#^it-Q0368|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20avr%C3%A0%20bisogno%20di%20questo.)
^it-Q0368-answer

**it-Q0369** — Forse Tom non sarà qua oggi.

Maybe Tom won't be here today.

Expected form: **sarà**

Why: Future forms. [[Italian#^it-Q0369|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Forse%20Tom%20non%20sar%C3%A0%20qua%20oggi.)
^it-Q0369-answer

**it-Q0370** — Forse Tom non sarà qua oggi.

Maybe Tom won't be here today.

Why: Future forms. [[Italian#^it-Q0370|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Forse%20Tom%20non%20sar%C3%A0%20qua%20oggi.)
^it-Q0370-answer

**it-Q0371** — Farò un'eccezione questa volta.

I'll make an exception this time.

Why: Future forms. [[Italian#^it-Q0371|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Far%C3%B2%20un%27eccezione%20questa%20volta.)
^it-Q0371-answer

**it-Q0372** — Farò un'eccezione questa volta.

I'll make an exception this time.

The futuro expresses future situations and can also mark a present conjecture. Many frequent verbs have irregular future stems, which recur in the conditional.

Why: Future forms. [[Italian#^it-Q0372|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Far%C3%B2%20un%27eccezione%20questa%20volta.)
^it-Q0372-answer

**it-Q0373** — Le cose non saranno mai più le stesse.

Things will never be the same again.

Expected form: **saranno**

Why: Future forms. [[Italian#^it-Q0373|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Le%20cose%20non%20saranno%20mai%20pi%C3%B9%20le%20stesse.)
^it-Q0373-answer

**it-Q0374** — Le cose non saranno mai più le stesse.

Things will never be the same again.

Expected form: **saranno**

Why: Future forms. [[Italian#^it-Q0374|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Le%20cose%20non%20saranno%20mai%20pi%C3%B9%20le%20stesse.)
^it-Q0374-answer

**it-Q0375** — Ci sarà molto molto caldo.

It will be very, very hot.

Expected form: **sarà**

Why: Future forms. [[Italian#^it-Q0375|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Ci%20sar%C3%A0%20molto%20molto%20caldo.)
^it-Q0375-answer

**it-Q0376** — Ci sarà molto molto caldo.

It will be very, very hot.

Why: Future forms. [[Italian#^it-Q0376|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Ci%20sar%C3%A0%20molto%20molto%20caldo.)
^it-Q0376-answer

**it-Q0377** — Entro domenica prossima, io avrò letto tutto il romanzo.

By next Sunday, I'll have read through the novel.

Why: Future forms. [[Italian#^it-Q0377|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Entro%20domenica%20prossima%2C%20io%20avr%C3%B2%20letto%20tutto%20il%20romanzo.)
^it-Q0377-answer

**it-Q0378** — Entro domenica prossima, io avrò letto tutto il romanzo.

By next Sunday, I'll have read through the novel.

The futuro expresses future situations and can also mark a present conjecture. Many frequent verbs have irregular future stems, which recur in the conditional.

Why: Future forms. [[Italian#^it-Q0378|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Entro%20domenica%20prossima%2C%20io%20avr%C3%B2%20letto%20tutto%20il%20romanzo.)
^it-Q0378-answer

**it-Q0379** — Andrò a dire a Tom la buona notizia.

I'll go tell Tom the good news.

Expected form: **Andrò**

Why: Future forms. [[Italian#^it-Q0379|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Andr%C3%B2%20a%20dire%20a%20Tom%20la%20buona%20notizia.)
^it-Q0379-answer

**it-Q0380** — Andrò a dire a Tom la buona notizia.

I'll go tell Tom the good news.

Expected form: **Andrò**

Why: Future forms. [[Italian#^it-Q0380|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Andr%C3%B2%20a%20dire%20a%20Tom%20la%20buona%20notizia.)
^it-Q0380-answer

**it-Q0381** — Cosa farò senza Tom?

What am I going to do without Tom?

Expected form: **farò**

Why: Future forms. [[Italian#^it-Q0381|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Cosa%20far%C3%B2%20senza%20Tom%3F)
^it-Q0381-answer

**it-Q0382** — Cosa farò senza Tom?

What am I going to do without Tom?

Why: Future forms. [[Italian#^it-Q0382|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Cosa%20far%C3%B2%20senza%20Tom%3F)
^it-Q0382-answer

**it-Q0383** — Io sono sicura che Tom sarà rincuorato.

I'm sure Tom will be relieved.

Why: Future forms. [[Italian#^it-Q0383|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Io%20sono%20sicura%20che%20Tom%20sar%C3%A0%20rincuorato.)
^it-Q0383-answer

**it-Q0384** — Io sono sicura che Tom sarà rincuorato.

I'm sure Tom will be relieved.

The futuro expresses future situations and can also mark a present conjecture. Many frequent verbs have irregular future stems, which recur in the conditional.

Why: Future forms. [[Italian#^it-Q0384|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Io%20sono%20sicura%20che%20Tom%20sar%C3%A0%20rincuorato.)
^it-Q0384-answer

**it-Q0385** — So che Tom non lo farà.

I know Tom won't do that.

Expected form: **farà**

Why: Future forms. [[Italian#^it-Q0385|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=So%20che%20Tom%20non%20lo%20far%C3%A0.)
^it-Q0385-answer

**it-Q0386** — So che Tom non lo farà.

I know Tom won't do that.

Expected form: **farà**

Why: Future forms. [[Italian#^it-Q0386|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=So%20che%20Tom%20non%20lo%20far%C3%A0.)
^it-Q0386-answer

**it-Q0387** — Tom probabilmente non sarà ammanettato.

Tom won't likely be handcuffed.

Expected form: **sarà**

Why: Future forms. [[Italian#^it-Q0387|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20probabilmente%20non%20sar%C3%A0%20ammanettato.)
^it-Q0387-answer

**it-Q0388** — Tom probabilmente non sarà ammanettato.

Tom won't likely be handcuffed.

Why: Future forms. [[Italian#^it-Q0388|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20probabilmente%20non%20sar%C3%A0%20ammanettato.)
^it-Q0388-answer

**it-Q0389** — Qualsiasi sia la scelta, sarà soddisfatto.

Whichever you choose, you will be satisfied.

Why: Future forms. [[Italian#^it-Q0389|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Qualsiasi%20sia%20la%20scelta%2C%20sar%C3%A0%20soddisfatto.)
^it-Q0389-answer

**it-Q0390** — Qualsiasi sia la scelta, sarà soddisfatto.

Whichever you choose, you will be satisfied.

The futuro expresses future situations and can also mark a present conjecture. Many frequent verbs have irregular future stems, which recur in the conditional.

Why: Future forms. [[Italian#^it-Q0390|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Qualsiasi%20sia%20la%20scelta%2C%20sar%C3%A0%20soddisfatto.)
^it-Q0390-answer

**it-Q0391** — Tom probabilmente non sarà assetato.

Tom won't likely be thirsty.

Expected form: **sarà**

Why: Future forms. [[Italian#^it-Q0391|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20probabilmente%20non%20sar%C3%A0%20assetato.)
^it-Q0391-answer

**it-Q0392** — Tom probabilmente non sarà assetato.

Tom won't likely be thirsty.

Expected form: **sarà**

Why: Future forms. [[Italian#^it-Q0392|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20probabilmente%20non%20sar%C3%A0%20assetato.)
^it-Q0392-answer

**it-Q0393** — Lasci noi studenti contribuire al benessere delle vittime del terremoto; anche un cambiamento lento andrà molto lontano.

Let us students contribute to the welfare of the victims of the earthquake; even loose change will go a long way.

Expected form: **andrà**

Why: Future forms. [[Italian#^it-Q0393|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Lasci%20noi%20studenti%20contribuire%20al%20benessere%20delle%20vittime%20del%20terremoto%3B%20anche%20un%20cambiamento%20lento%20andr%C3%A0%20molto%20lontano.)
^it-Q0393-answer

**it-Q0394** — Lasci noi studenti contribuire al benessere delle vittime del terremoto; anche un cambiamento lento andrà molto lontano.

Let us students contribute to the welfare of the victims of the earthquake; even loose change will go a long way.

Why: Future forms. [[Italian#^it-Q0394|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Lasci%20noi%20studenti%20contribuire%20al%20benessere%20delle%20vittime%20del%20terremoto%3B%20anche%20un%20cambiamento%20lento%20andr%C3%A0%20molto%20lontano.)
^it-Q0394-answer

**it-Q0395** — Tom avrà bisogno del nostro aiuto.

Tom is going to need our help.

Why: Future forms. [[Italian#^it-Q0395|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20avr%C3%A0%20bisogno%20del%20nostro%20aiuto.)
^it-Q0395-answer

**it-Q0396** — Tom avrà bisogno del nostro aiuto.

Tom is going to need our help.

The futuro expresses future situations and can also mark a present conjecture. Many frequent verbs have irregular future stems, which recur in the conditional.

Why: Future forms. [[Italian#^it-Q0396|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20avr%C3%A0%20bisogno%20del%20nostro%20aiuto.)
^it-Q0396-answer

**it-Q0397** — Io non penso che Tom sarà a scuola domani.

I don't think Tom will be at school tomorrow.

Expected form: **sarà**

Why: Future forms. [[Italian#^it-Q0397|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Io%20non%20penso%20che%20Tom%20sar%C3%A0%20a%20scuola%20domani.)
^it-Q0397-answer

**it-Q0398** — Io non penso che Tom sarà a scuola domani.

I don't think Tom will be at school tomorrow.

Expected form: **sarà**

Why: Future forms. [[Italian#^it-Q0398|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Io%20non%20penso%20che%20Tom%20sar%C3%A0%20a%20scuola%20domani.)
^it-Q0398-answer

**it-Q0399** — Andrò a prendere i moduli appropriati.

I'll go get the proper forms.

Expected form: **Andrò**

Why: Future forms. [[Italian#^it-Q0399|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Andr%C3%B2%20a%20prendere%20i%20moduli%20appropriati.)
^it-Q0399-answer

**it-Q0400** — Andrò a prendere i moduli appropriati.

I'll go get the proper forms.

Why: Future forms. [[Italian#^it-Q0400|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Andr%C3%B2%20a%20prendere%20i%20moduli%20appropriati.)
^it-Q0400-answer


### Answers 401–450

**it-Q0401** — Nessuna cosa vivente potrebbe vivere senza aria.

No living thing could live without air.

Why: Conditional and politeness. [[Italian#^it-Q0401|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Nessuna%20cosa%20vivente%20potrebbe%20vivere%20senza%20aria.)
^it-Q0401-answer

**it-Q0402** — Nessuna cosa vivente potrebbe vivere senza aria.

No living thing could live without air.

The condizionale expresses hypothetical results, polite requests and some reported claims. Vorrei is a useful request form. Conditions with se require a separate choice of tense/mood.

Why: Conditional and politeness. [[Italian#^it-Q0402|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Nessuna%20cosa%20vivente%20potrebbe%20vivere%20senza%20aria.)
^it-Q0402-answer

**it-Q0403** — Tom dovrebbe lasciarmi aiutare Mary.

Tom should let me help Mary.

Expected form: **dovrebbe**

Why: Conditional and politeness. [[Italian#^it-Q0403|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20dovrebbe%20lasciarmi%20aiutare%20Mary.)
^it-Q0403-answer

**it-Q0404** — Tom dovrebbe lasciarmi aiutare Mary.

Tom should let me help Mary.

Expected form: **dovrebbe**

Why: Conditional and politeness. [[Italian#^it-Q0404|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20dovrebbe%20lasciarmi%20aiutare%20Mary.)
^it-Q0404-answer

**it-Q0405** — Io vorrei che Tom fosse qui.

I wish Tom was here.

Expected form: **vorrei**

Why: Conditional and politeness. [[Italian#^it-Q0405|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Io%20vorrei%20che%20Tom%20fosse%20qui.)
^it-Q0405-answer

**it-Q0406** — Io vorrei che Tom fosse qui.

I wish Tom was here.

Why: Conditional and politeness. [[Italian#^it-Q0406|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Io%20vorrei%20che%20Tom%20fosse%20qui.)
^it-Q0406-answer

**it-Q0407** — Vorrei cucinare pollo stasera.

I'd like to cook chicken tonight.

Why: Conditional and politeness. [[Italian#^it-Q0407|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Vorrei%20cucinare%20pollo%20stasera.)
^it-Q0407-answer

**it-Q0408** — Vorrei cucinare pollo stasera.

I'd like to cook chicken tonight.

The condizionale expresses hypothetical results, polite requests and some reported claims. Vorrei is a useful request form. Conditions with se require a separate choice of tense/mood.

Why: Conditional and politeness. [[Italian#^it-Q0408|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Vorrei%20cucinare%20pollo%20stasera.)
^it-Q0408-answer

**it-Q0409** — Sarebbe sorpresa di quello che può imparare in una settimana.

You'd be surprised what you can learn in a week.

Expected form: **Sarebbe**

Why: Conditional and politeness. [[Italian#^it-Q0409|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Sarebbe%20sorpresa%20di%20quello%20che%20pu%C3%B2%20imparare%20in%20una%20settimana.)
^it-Q0409-answer

**it-Q0410** — Sarebbe sorpresa di quello che può imparare in una settimana.

You'd be surprised what you can learn in a week.

Expected form: **Sarebbe**

Why: Conditional and politeness. [[Italian#^it-Q0410|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Sarebbe%20sorpresa%20di%20quello%20che%20pu%C3%B2%20imparare%20in%20una%20settimana.)
^it-Q0410-answer

**it-Q0411** — Perché ci dovrebbe essere un problema?

Why should there be a problem?

Expected form: **dovrebbe**

Why: Conditional and politeness. [[Italian#^it-Q0411|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Perch%C3%A9%20ci%20dovrebbe%20essere%20un%20problema%3F)
^it-Q0411-answer

**it-Q0412** — Perché ci dovrebbe essere un problema?

Why should there be a problem?

Why: Conditional and politeness. [[Italian#^it-Q0412|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Perch%C3%A9%20ci%20dovrebbe%20essere%20un%20problema%3F)
^it-Q0412-answer

**it-Q0413** — Tom lo potrebbe spiegare.

Tom could explain that.

Why: Conditional and politeness. [[Italian#^it-Q0413|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20lo%20potrebbe%20spiegare.)
^it-Q0413-answer

**it-Q0414** — Tom lo potrebbe spiegare.

Tom could explain that.

The condizionale expresses hypothetical results, polite requests and some reported claims. Vorrei is a useful request form. Conditions with se require a separate choice of tense/mood.

Why: Conditional and politeness. [[Italian#^it-Q0414|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20lo%20potrebbe%20spiegare.)
^it-Q0414-answer

**it-Q0415** — Non dovrebbe mangiare questo.

You shouldn't eat this.

Expected form: **dovrebbe**

Why: Conditional and politeness. [[Italian#^it-Q0415|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20dovrebbe%20mangiare%20questo.)
^it-Q0415-answer

**it-Q0416** — Non dovrebbe mangiare questo.

You shouldn't eat this.

Expected form: **dovrebbe**

Why: Conditional and politeness. [[Italian#^it-Q0416|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20dovrebbe%20mangiare%20questo.)
^it-Q0416-answer

**it-Q0417** — Vorrei smettesse di piovere.

I wish it would stop raining.

Expected form: **Vorrei**

Why: Conditional and politeness. [[Italian#^it-Q0417|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Vorrei%20smettesse%20di%20piovere.)
^it-Q0417-answer

**it-Q0418** — Vorrei smettesse di piovere.

I wish it would stop raining.

Why: Conditional and politeness. [[Italian#^it-Q0418|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Vorrei%20smettesse%20di%20piovere.)
^it-Q0418-answer

**it-Q0419** — Lui avrebbe dovuto comprare una macchina usata.

He should have bought a used car.

Why: Conditional and politeness. [[Italian#^it-Q0419|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Lui%20avrebbe%20dovuto%20comprare%20una%20macchina%20usata.)
^it-Q0419-answer

**it-Q0420** — Lui avrebbe dovuto comprare una macchina usata.

He should have bought a used car.

The condizionale expresses hypothetical results, polite requests and some reported claims. Vorrei is a useful request form. Conditions with se require a separate choice of tense/mood.

Why: Conditional and politeness. [[Italian#^it-Q0420|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Lui%20avrebbe%20dovuto%20comprare%20una%20macchina%20usata.)
^it-Q0420-answer

**it-Q0421** — Potrebbe accendere la luce, per piacere?

Could you turn on the light, please?

Expected form: **Potrebbe**

Why: Conditional and politeness. [[Italian#^it-Q0421|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Potrebbe%20accendere%20la%20luce%2C%20per%20piacere%3F)
^it-Q0421-answer

**it-Q0422** — Potrebbe accendere la luce, per piacere?

Could you turn on the light, please?

Expected form: **Potrebbe**

Why: Conditional and politeness. [[Italian#^it-Q0422|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Potrebbe%20accendere%20la%20luce%2C%20per%20piacere%3F)
^it-Q0422-answer

**it-Q0423** — Tom non dovrebbe farlo?

Shouldn't Tom be doing that?

Expected form: **dovrebbe**

Why: Conditional and politeness. [[Italian#^it-Q0423|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20non%20dovrebbe%20farlo%3F)
^it-Q0423-answer

**it-Q0424** — Tom non dovrebbe farlo?

Shouldn't Tom be doing that?

Why: Conditional and politeness. [[Italian#^it-Q0424|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20non%20dovrebbe%20farlo%3F)
^it-Q0424-answer

**it-Q0425** — Tom dovrebbe lasciare Mary da sola.

Tom should leave Mary alone.

Why: Conditional and politeness. [[Italian#^it-Q0425|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20dovrebbe%20lasciare%20Mary%20da%20sola.)
^it-Q0425-answer

**it-Q0426** — Tom dovrebbe lasciare Mary da sola.

Tom should leave Mary alone.

The condizionale expresses hypothetical results, polite requests and some reported claims. Vorrei is a useful request form. Conditions with se require a separate choice of tense/mood.

Why: Conditional and politeness. [[Italian#^it-Q0426|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20dovrebbe%20lasciare%20Mary%20da%20sola.)
^it-Q0426-answer

**it-Q0427** — Vorrebbe del caffè o del tè?

Would you like coffee or tea?

Expected form: **Vorrebbe**

Why: Conditional and politeness. [[Italian#^it-Q0427|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Vorrebbe%20del%20caff%C3%A8%20o%20del%20t%C3%A8%3F)
^it-Q0427-answer

**it-Q0428** — Vorrebbe del caffè o del tè?

Would you like coffee or tea?

Expected form: **Vorrebbe**

Why: Conditional and politeness. [[Italian#^it-Q0428|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Vorrebbe%20del%20caff%C3%A8%20o%20del%20t%C3%A8%3F)
^it-Q0428-answer

**it-Q0429** — Io vorrei una stanza che dia sul giardino.

I'd like a room facing the garden.

Expected form: **vorrei**

Why: Conditional and politeness. [[Italian#^it-Q0429|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Io%20vorrei%20una%20stanza%20che%20dia%20sul%20giardino.)
^it-Q0429-answer

**it-Q0430** — Io vorrei una stanza che dia sul giardino.

I'd like a room facing the garden.

Why: Conditional and politeness. [[Italian#^it-Q0430|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Io%20vorrei%20una%20stanza%20che%20dia%20sul%20giardino.)
^it-Q0430-answer

**it-Q0431** — Pensavo che non sarebbe venuto.

I thought he wouldn't come.

Why: Conditional and politeness. [[Italian#^it-Q0431|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Pensavo%20che%20non%20sarebbe%20venuto.)
^it-Q0431-answer

**it-Q0432** — Pensavo che non sarebbe venuto.

I thought he wouldn't come.

The condizionale expresses hypothetical results, polite requests and some reported claims. Vorrei is a useful request form. Conditions with se require a separate choice of tense/mood.

Why: Conditional and politeness. [[Italian#^it-Q0432|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Pensavo%20che%20non%20sarebbe%20venuto.)
^it-Q0432-answer

**it-Q0433** — Vorrei poter visitare Boston.

I wish I could visit Boston.

Expected form: **Vorrei**

Why: Conditional and politeness. [[Italian#^it-Q0433|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Vorrei%20poter%20visitare%20Boston.)
^it-Q0433-answer

**it-Q0434** — Vorrei poter visitare Boston.

I wish I could visit Boston.

Expected form: **Vorrei**

Why: Conditional and politeness. [[Italian#^it-Q0434|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Vorrei%20poter%20visitare%20Boston.)
^it-Q0434-answer

**it-Q0435** — Dovrebbe andare lì.

You should go there.

Expected form: **Dovrebbe**

Why: Conditional and politeness. [[Italian#^it-Q0435|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Dovrebbe%20andare%20l%C3%AC.)
^it-Q0435-answer

**it-Q0436** — Dovrebbe andare lì.

You should go there.

Why: Conditional and politeness. [[Italian#^it-Q0436|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Dovrebbe%20andare%20l%C3%AC.)
^it-Q0436-answer

**it-Q0437** — Ne vorrebbe uno adesso?

Would you like one now?

Why: Conditional and politeness. [[Italian#^it-Q0437|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Ne%20vorrebbe%20uno%20adesso%3F)
^it-Q0437-answer

**it-Q0438** — Ne vorrebbe uno adesso?

Would you like one now?

The condizionale expresses hypothetical results, polite requests and some reported claims. Vorrei is a useful request form. Conditions with se require a separate choice of tense/mood.

Why: Conditional and politeness. [[Italian#^it-Q0438|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Ne%20vorrebbe%20uno%20adesso%3F)
^it-Q0438-answer

**it-Q0439** — Pensate che potrei vincere?

Do you think I might win?

Expected form: **potrei**

Why: Conditional and politeness. [[Italian#^it-Q0439|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Pensate%20che%20potrei%20vincere%3F)
^it-Q0439-answer

**it-Q0440** — Pensate che potrei vincere?

Do you think I might win?

Expected form: **potrei**

Why: Conditional and politeness. [[Italian#^it-Q0440|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Pensate%20che%20potrei%20vincere%3F)
^it-Q0440-answer

**it-Q0441** — Potrei avere questa scatola?

Could I have this box?

Expected form: **Potrei**

Why: Conditional and politeness. [[Italian#^it-Q0441|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Potrei%20avere%20questa%20scatola%3F)
^it-Q0441-answer

**it-Q0442** — Potrei avere questa scatola?

Could I have this box?

Why: Conditional and politeness. [[Italian#^it-Q0442|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Potrei%20avere%20questa%20scatola%3F)
^it-Q0442-answer

**it-Q0443** — Cosa sarebbe il meglio per loro?

What would be best for them?

Why: Conditional and politeness. [[Italian#^it-Q0443|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Cosa%20sarebbe%20il%20meglio%20per%20loro%3F)
^it-Q0443-answer

**it-Q0444** — Cosa sarebbe il meglio per loro?

What would be best for them?

The condizionale expresses hypothetical results, polite requests and some reported claims. Vorrei is a useful request form. Conditions with se require a separate choice of tense/mood.

Why: Conditional and politeness. [[Italian#^it-Q0444|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Cosa%20sarebbe%20il%20meglio%20per%20loro%3F)
^it-Q0444-answer

**it-Q0445** — Vorrei noleggiare un'auto.

I'd like to rent a car.

Expected form: **Vorrei**

Why: Conditional and politeness. [[Italian#^it-Q0445|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Vorrei%20noleggiare%20un%27auto.)
^it-Q0445-answer

**it-Q0446** — Vorrei noleggiare un'auto.

I'd like to rent a car.

Expected form: **Vorrei**

Why: Conditional and politeness. [[Italian#^it-Q0446|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Vorrei%20noleggiare%20un%27auto.)
^it-Q0446-answer

**it-Q0447** — Che altro potrebbe volere?

What more could you want?

Expected form: **potrebbe**

Why: Conditional and politeness. [[Italian#^it-Q0447|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Che%20altro%20potrebbe%20volere%3F)
^it-Q0447-answer

**it-Q0448** — Che altro potrebbe volere?

What more could you want?

Why: Conditional and politeness. [[Italian#^it-Q0448|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Che%20altro%20potrebbe%20volere%3F)
^it-Q0448-answer

**it-Q0449** — Tom non è felice come dovrebbe essere.

Tom isn't as happy as he should be.

Why: Conditional and politeness. [[Italian#^it-Q0449|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20non%20%C3%A8%20felice%20come%20dovrebbe%20essere.)
^it-Q0449-answer

**it-Q0450** — Tom non è felice come dovrebbe essere.

Tom isn't as happy as he should be.

The condizionale expresses hypothetical results, polite requests and some reported claims. Vorrei is a useful request form. Conditions with se require a separate choice of tense/mood.

Why: Conditional and politeness. [[Italian#^it-Q0450|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20non%20%C3%A8%20felice%20come%20dovrebbe%20essere.)
^it-Q0450-answer


### Answers 451–500

**it-Q0451** — Vada a dirle come si sente.

Go tell her how you feel.

Expected form: **Vada**

Why: Subjunctive forms. [[Italian#^it-Q0451|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Vada%20a%20dirle%20come%20si%20sente.)
^it-Q0451-answer

**it-Q0452** — Vada a dirle come si sente.

Go tell her how you feel.

Expected form: **Vada**

Why: Subjunctive forms. [[Italian#^it-Q0452|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Vada%20a%20dirle%20come%20si%20sente.)
^it-Q0452-answer

**it-Q0453** — Chi pensate che siano?

Who do you think they are?

Expected form: **siano**

Why: Subjunctive forms. [[Italian#^it-Q0453|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Chi%20pensate%20che%20siano%3F)
^it-Q0453-answer

**it-Q0454** — Chi pensate che siano?

Who do you think they are?

Why: Subjunctive forms. [[Italian#^it-Q0454|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Chi%20pensate%20che%20siano%3F)
^it-Q0454-answer

**it-Q0455** — Vada con lui.

Go with him.

Why: Subjunctive forms. [[Italian#^it-Q0455|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Vada%20con%20lui.)
^it-Q0455-answer

**it-Q0456** — Vada con lui.

Go with him.

The congiuntivo occurs in many dependent clauses after attitude, doubt, desire or evaluation. Learn a governing expression with its subordinate form; avoid replacing every que-like clause automatically.

Why: Subjunctive forms. [[Italian#^it-Q0456|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Vada%20con%20lui.)
^it-Q0456-answer

**it-Q0457** — Io penso che sia vera.

I think it's true.

Expected form: **sia**

Why: Subjunctive forms. [[Italian#^it-Q0457|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Io%20penso%20che%20sia%20vera.)
^it-Q0457-answer

**it-Q0458** — Io penso che sia vera.

I think it's true.

Expected form: **sia**

Why: Subjunctive forms. [[Italian#^it-Q0458|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Io%20penso%20che%20sia%20vera.)
^it-Q0458-answer

**it-Q0459** — Non si faccia investire.

Don't get run over.

Expected form: **faccia**

Why: Subjunctive forms. [[Italian#^it-Q0459|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20si%20faccia%20investire.)
^it-Q0459-answer

**it-Q0460** — Non si faccia investire.

Don't get run over.

Why: Subjunctive forms. [[Italian#^it-Q0460|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20si%20faccia%20investire.)
^it-Q0460-answer

**it-Q0461** — Io sospetto che Tom sia un assassino a sangue freddo.

I suspect that Tom is a cold-blooded murderer.

Why: Subjunctive forms. [[Italian#^it-Q0461|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Io%20sospetto%20che%20Tom%20sia%20un%20assassino%20a%20sangue%20freddo.)
^it-Q0461-answer

**it-Q0462** — Io sospetto che Tom sia un assassino a sangue freddo.

I suspect that Tom is a cold-blooded murderer.

The congiuntivo occurs in many dependent clauses after attitude, doubt, desire or evaluation. Learn a governing expression with its subordinate form; avoid replacing every que-like clause automatically.

Why: Subjunctive forms. [[Italian#^it-Q0462|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Io%20sospetto%20che%20Tom%20sia%20un%20assassino%20a%20sangue%20freddo.)
^it-Q0462-answer

**it-Q0463** — Spero che il vino sia di tuo gradimento.

I hope the wine is to your taste.

Expected form: **sia**

Why: Subjunctive forms. [[Italian#^it-Q0463|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Spero%20che%20il%20vino%20sia%20di%20tuo%20gradimento.)
^it-Q0463-answer

**it-Q0464** — Spero che il vino sia di tuo gradimento.

I hope the wine is to your taste.

Expected form: **sia**

Why: Subjunctive forms. [[Italian#^it-Q0464|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Spero%20che%20il%20vino%20sia%20di%20tuo%20gradimento.)
^it-Q0464-answer

**it-Q0465** — Io penso che Tom possa piangere.

I think Tom may cry.

Expected form: **possa**

Why: Subjunctive forms. [[Italian#^it-Q0465|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Io%20penso%20che%20Tom%20possa%20piangere.)
^it-Q0465-answer

**it-Q0466** — Io penso che Tom possa piangere.

I think Tom may cry.

Why: Subjunctive forms. [[Italian#^it-Q0466|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Io%20penso%20che%20Tom%20possa%20piangere.)
^it-Q0466-answer

**it-Q0467** — Io insisto che gli studenti siano sempre in orario.

I demand that students always be on time.

Why: Subjunctive forms. [[Italian#^it-Q0467|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Io%20insisto%20che%20gli%20studenti%20siano%20sempre%20in%20orario.)
^it-Q0467-answer

**it-Q0468** — Io insisto che gli studenti siano sempre in orario.

I demand that students always be on time.

The congiuntivo occurs in many dependent clauses after attitude, doubt, desire or evaluation. Learn a governing expression with its subordinate form; avoid replacing every que-like clause automatically.

Why: Subjunctive forms. [[Italian#^it-Q0468|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Io%20insisto%20che%20gli%20studenti%20siano%20sempre%20in%20orario.)
^it-Q0468-answer

**it-Q0469** — Mi chiedo di cos'abbiano parlato Tom e Mary.

I wonder what Tom and Mary talked about.

Expected form: **abbiano**

Why: Subjunctive forms. [[Italian#^it-Q0469|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Mi%20chiedo%20di%20cos%27abbiano%20parlato%20Tom%20e%20Mary.)
^it-Q0469-answer

**it-Q0470** — Mi chiedo di cos'abbiano parlato Tom e Mary.

I wonder what Tom and Mary talked about.

Expected form: **abbiano**

Why: Subjunctive forms. [[Italian#^it-Q0470|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Mi%20chiedo%20di%20cos%27abbiano%20parlato%20Tom%20e%20Mary.)
^it-Q0470-answer

**it-Q0471** — Penso sia magnifica.

I think it's wonderful.

Expected form: **sia**

Why: Subjunctive forms. [[Italian#^it-Q0471|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Penso%20sia%20magnifica.)
^it-Q0471-answer

**it-Q0472** — Penso sia magnifica.

I think it's wonderful.

Why: Subjunctive forms. [[Italian#^it-Q0472|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Penso%20sia%20magnifica.)
^it-Q0472-answer

**it-Q0473** — Lasci che faccia una piccola chiacchierata con Tom.

Let me have a little chat with Tom.

Why: Subjunctive forms. [[Italian#^it-Q0473|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Lasci%20che%20faccia%20una%20piccola%20chiacchierata%20con%20Tom.)
^it-Q0473-answer

**it-Q0474** — Lasci che faccia una piccola chiacchierata con Tom.

Let me have a little chat with Tom.

The congiuntivo occurs in many dependent clauses after attitude, doubt, desire or evaluation. Learn a governing expression with its subordinate form; avoid replacing every que-like clause automatically.

Why: Subjunctive forms. [[Italian#^it-Q0474|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Lasci%20che%20faccia%20una%20piccola%20chiacchierata%20con%20Tom.)
^it-Q0474-answer

**it-Q0475** — Lasci che faccia una domanda.

Let me ask a question.

Expected form: **faccia**

Why: Subjunctive forms. [[Italian#^it-Q0475|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Lasci%20che%20faccia%20una%20domanda.)
^it-Q0475-answer

**it-Q0476** — Lasci che faccia una domanda.

Let me ask a question.

Expected form: **faccia**

Why: Subjunctive forms. [[Italian#^it-Q0476|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Lasci%20che%20faccia%20una%20domanda.)
^it-Q0476-answer

**it-Q0477** — Lo so che pensate che questo sia troppo costoso.

I know you think this is too expensive.

Expected form: **sia**

Why: Subjunctive forms. [[Italian#^it-Q0477|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Lo%20so%20che%20pensate%20che%20questo%20sia%20troppo%20costoso.)
^it-Q0477-answer

**it-Q0478** — Lo so che pensate che questo sia troppo costoso.

I know you think this is too expensive.

Why: Subjunctive forms. [[Italian#^it-Q0478|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Lo%20so%20che%20pensate%20che%20questo%20sia%20troppo%20costoso.)
^it-Q0478-answer

**it-Q0479** — Penso che sia orribile.

I think that's horrible.

Why: Subjunctive forms. [[Italian#^it-Q0479|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Penso%20che%20sia%20orribile.)
^it-Q0479-answer

**it-Q0480** — Penso che sia orribile.

I think that's horrible.

The congiuntivo occurs in many dependent clauses after attitude, doubt, desire or evaluation. Learn a governing expression with its subordinate form; avoid replacing every que-like clause automatically.

Why: Subjunctive forms. [[Italian#^it-Q0480|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Penso%20che%20sia%20orribile.)
^it-Q0480-answer

**it-Q0481** — Penso che fosse sbagliato.

I think it was wrong.

Expected form: **fosse**

Why: Subjunctive forms. [[Italian#^it-Q0481|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Penso%20che%20fosse%20sbagliato.)
^it-Q0481-answer

**it-Q0482** — Penso che fosse sbagliato.

I think it was wrong.

Expected form: **fosse**

Why: Subjunctive forms. [[Italian#^it-Q0482|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Penso%20che%20fosse%20sbagliato.)
^it-Q0482-answer

**it-Q0483** — Mi faccia provare ancora.

Let me try again.

Expected form: **faccia**

Why: Subjunctive forms. [[Italian#^it-Q0483|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Mi%20faccia%20provare%20ancora.)
^it-Q0483-answer

**it-Q0484** — Mi faccia provare ancora.

Let me try again.

Why: Subjunctive forms. [[Italian#^it-Q0484|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Mi%20faccia%20provare%20ancora.)
^it-Q0484-answer

**it-Q0485** — Ma pensi che la gente sia stupida?

But do you think people are stupid?

Why: Subjunctive forms. [[Italian#^it-Q0485|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Ma%20pensi%20che%20la%20gente%20sia%20stupida%3F)
^it-Q0485-answer

**it-Q0486** — Ma pensi che la gente sia stupida?

But do you think people are stupid?

The congiuntivo occurs in many dependent clauses after attitude, doubt, desire or evaluation. Learn a governing expression with its subordinate form; avoid replacing every que-like clause automatically.

Why: Subjunctive forms. [[Italian#^it-Q0486|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Ma%20pensi%20che%20la%20gente%20sia%20stupida%3F)
^it-Q0486-answer

**it-Q0487** — Sembrava che Tom fosse scettico.

Tom looked like he was skeptical.

Expected form: **fosse**

Why: Subjunctive forms. [[Italian#^it-Q0487|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Sembrava%20che%20Tom%20fosse%20scettico.)
^it-Q0487-answer

**it-Q0488** — Sembrava che Tom fosse scettico.

Tom looked like he was skeptical.

Expected form: **fosse**

Why: Subjunctive forms. [[Italian#^it-Q0488|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Sembrava%20che%20Tom%20fosse%20scettico.)
^it-Q0488-answer

**it-Q0489** — Conosco sia Mary che suo marito.

I know both Mary and her husband.

Expected form: **sia**

Why: Subjunctive forms. [[Italian#^it-Q0489|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Conosco%20sia%20Mary%20che%20suo%20marito.)
^it-Q0489-answer

**it-Q0490** — Conosco sia Mary che suo marito.

I know both Mary and her husband.

Why: Subjunctive forms. [[Italian#^it-Q0490|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Conosco%20sia%20Mary%20che%20suo%20marito.)
^it-Q0490-answer

**it-Q0491** — Io non posso acconsentire che lei vada da sola.

I cannot consent to your going alone.

Why: Subjunctive forms. [[Italian#^it-Q0491|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Io%20non%20posso%20acconsentire%20che%20lei%20vada%20da%20sola.)
^it-Q0491-answer

**it-Q0492** — Io non posso acconsentire che lei vada da sola.

I cannot consent to your going alone.

The congiuntivo occurs in many dependent clauses after attitude, doubt, desire or evaluation. Learn a governing expression with its subordinate form; avoid replacing every que-like clause automatically.

Why: Subjunctive forms. [[Italian#^it-Q0492|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Io%20non%20posso%20acconsentire%20che%20lei%20vada%20da%20sola.)
^it-Q0492-answer

**it-Q0493** — Penso che non possa farlo.

I think he can't do that.

Expected form: **possa**

Why: Subjunctive forms. [[Italian#^it-Q0493|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Penso%20che%20non%20possa%20farlo.)
^it-Q0493-answer

**it-Q0494** — Penso che non possa farlo.

I think he can't do that.

Expected form: **possa**

Why: Subjunctive forms. [[Italian#^it-Q0494|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Penso%20che%20non%20possa%20farlo.)
^it-Q0494-answer

**it-Q0495** — Io penso che abbia più di quarant'anni.

I think she is over forty years old.

Expected form: **abbia**

Why: Subjunctive forms. [[Italian#^it-Q0495|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Io%20penso%20che%20abbia%20pi%C3%B9%20di%20quarant%27anni.)
^it-Q0495-answer

**it-Q0496** — Io penso che abbia più di quarant'anni.

I think she is over forty years old.

Why: Subjunctive forms. [[Italian#^it-Q0496|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Io%20penso%20che%20abbia%20pi%C3%B9%20di%20quarant%27anni.)
^it-Q0496-answer

**it-Q0497** — Quale pensate che sia un bel regalo per il compleanno di Tom?

What do you think's a good present for Tom's birthday?

Why: Subjunctive forms. [[Italian#^it-Q0497|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Quale%20pensate%20che%20sia%20un%20bel%20regalo%20per%20il%20compleanno%20di%20Tom%3F)
^it-Q0497-answer

**it-Q0498** — Quale pensate che sia un bel regalo per il compleanno di Tom?

What do you think's a good present for Tom's birthday?

The congiuntivo occurs in many dependent clauses after attitude, doubt, desire or evaluation. Learn a governing expression with its subordinate form; avoid replacing every que-like clause automatically.

Why: Subjunctive forms. [[Italian#^it-Q0498|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Quale%20pensate%20che%20sia%20un%20bel%20regalo%20per%20il%20compleanno%20di%20Tom%3F)
^it-Q0498-answer

**it-Q0499** — Il bambino parla come se fosse un uomo.

The child talks as if he were a man.

Expected form: **fosse**

Why: Subjunctive forms. [[Italian#^it-Q0499|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Il%20bambino%20parla%20come%20se%20fosse%20un%20uomo.)
^it-Q0499-answer

**it-Q0500** — Il bambino parla come se fosse un uomo.

The child talks as if he were a man.

Expected form: **fosse**

Why: Subjunctive forms. [[Italian#^it-Q0500|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Il%20bambino%20parla%20come%20se%20fosse%20un%20uomo.)
^it-Q0500-answer


### Answers 501–550

**it-Q0501** — Mi piace questo quartiere.

I like this neighborhood.

Expected form: **Mi**

Why: Direct object clitics. [[Italian#^it-Q0501|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Mi%20piace%20questo%20quartiere.)
^it-Q0501-answer

**it-Q0502** — Mi piace questo quartiere.

I like this neighborhood.

Why: Direct object clitics. [[Italian#^it-Q0502|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Mi%20piace%20questo%20quartiere.)
^it-Q0502-answer

**it-Q0503** — Cosa vi piace di lui?

What do you like about him?

Why: Direct object clitics. [[Italian#^it-Q0503|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Cosa%20vi%20piace%20di%20lui%3F)
^it-Q0503-answer

**it-Q0504** — Cosa vi piace di lui?

What do you like about him?

Lo/la/li/le can replace direct objects. They normally precede a finite verb but can attach to infinitives and some imperatives. Some identical forms also serve other roles.

Why: Direct object clitics. [[Italian#^it-Q0504|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Cosa%20vi%20piace%20di%20lui%3F)
^it-Q0504-answer

**it-Q0505** — Non ci sentite umiliate?

Don't you feel humiliated?

Expected form: **ci**

Why: Direct object clitics. [[Italian#^it-Q0505|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20ci%20sentite%20umiliate%3F)
^it-Q0505-answer

**it-Q0506** — Non ci sentite umiliate?

Don't you feel humiliated?

Expected form: **ci**

Why: Direct object clitics. [[Italian#^it-Q0506|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20ci%20sentite%20umiliate%3F)
^it-Q0506-answer

**it-Q0507** — Perché non ti piace qui?

Why don't you like it here?

Expected form: **ti**

Why: Direct object clitics. [[Italian#^it-Q0507|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Perch%C3%A9%20non%20ti%20piace%20qui%3F)
^it-Q0507-answer

**it-Q0508** — Perché non ti piace qui?

Why don't you like it here?

Why: Direct object clitics. [[Italian#^it-Q0508|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Perch%C3%A9%20non%20ti%20piace%20qui%3F)
^it-Q0508-answer

**it-Q0509** — Io non voglio che voi mi trattiate in modo diverso.

I don't want you to treat me any differently.

Why: Direct object clitics. [[Italian#^it-Q0509|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Io%20non%20voglio%20che%20voi%20mi%20trattiate%20in%20modo%20diverso.)
^it-Q0509-answer

**it-Q0510** — Io non voglio che voi mi trattiate in modo diverso.

I don't want you to treat me any differently.

Lo/la/li/le can replace direct objects. They normally precede a finite verb but can attach to infinitives and some imperatives. Some identical forms also serve other roles.

Why: Direct object clitics. [[Italian#^it-Q0510|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Io%20non%20voglio%20che%20voi%20mi%20trattiate%20in%20modo%20diverso.)
^it-Q0510-answer

**it-Q0511** — Lo fa più rapidamente di te.

She does it faster than you.

Expected form: **Lo**

Why: Direct object clitics. [[Italian#^it-Q0511|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Lo%20fa%20pi%C3%B9%20rapidamente%20di%20te.)
^it-Q0511-answer

**it-Q0512** — Lo fa più rapidamente di te.

She does it faster than you.

Expected form: **Lo**

Why: Direct object clitics. [[Italian#^it-Q0512|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Lo%20fa%20pi%C3%B9%20rapidamente%20di%20te.)
^it-Q0512-answer

**it-Q0513** — Perché mi dovrei scusare?

Why should I apologize?

Expected form: **mi**

Why: Direct object clitics. [[Italian#^it-Q0513|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Perch%C3%A9%20mi%20dovrei%20scusare%3F)
^it-Q0513-answer

**it-Q0514** — Perché mi dovrei scusare?

Why should I apologize?

Why: Direct object clitics. [[Italian#^it-Q0514|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Perch%C3%A9%20mi%20dovrei%20scusare%3F)
^it-Q0514-answer

**it-Q0515** — Me la spiegò.

He explained it to me.

Why: Direct object clitics. [[Italian#^it-Q0515|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Me%20la%20spieg%C3%B2.)
^it-Q0515-answer

**it-Q0516** — Me la spiegò.

He explained it to me.

Lo/la/li/le can replace direct objects. They normally precede a finite verb but can attach to infinitives and some imperatives. Some identical forms also serve other roles.

Why: Direct object clitics. [[Italian#^it-Q0516|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Me%20la%20spieg%C3%B2.)
^it-Q0516-answer

**it-Q0517** — Le assicurazioni proteggono da situazioni difficili impreviste.

Insurance protects against unforeseen predicaments.

Expected form: **Le**

Why: Direct object clitics. [[Italian#^it-Q0517|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Le%20assicurazioni%20proteggono%20da%20situazioni%20difficili%20impreviste.)
^it-Q0517-answer

**it-Q0518** — Le assicurazioni proteggono da situazioni difficili impreviste.

Insurance protects against unforeseen predicaments.

Expected form: **Le**

Why: Direct object clitics. [[Italian#^it-Q0518|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Le%20assicurazioni%20proteggono%20da%20situazioni%20difficili%20impreviste.)
^it-Q0518-answer

**it-Q0519** — Chi ti piace di più, Sachiko o Akiko?

Who do you like better, Sachiko or Akiko?

Expected form: **ti**

Why: Direct object clitics. [[Italian#^it-Q0519|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Chi%20ti%20piace%20di%20pi%C3%B9%2C%20Sachiko%20o%20Akiko%3F)
^it-Q0519-answer

**it-Q0520** — Chi ti piace di più, Sachiko o Akiko?

Who do you like better, Sachiko or Akiko?

Why: Direct object clitics. [[Italian#^it-Q0520|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Chi%20ti%20piace%20di%20pi%C3%B9%2C%20Sachiko%20o%20Akiko%3F)
^it-Q0520-answer

**it-Q0521** — Lui perse la memoria.

He lost his memory.

Why: Direct object clitics. [[Italian#^it-Q0521|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Lui%20perse%20la%20memoria.)
^it-Q0521-answer

**it-Q0522** — Lui perse la memoria.

He lost his memory.

Lo/la/li/le can replace direct objects. They normally precede a finite verb but can attach to infinitives and some imperatives. Some identical forms also serve other roles.

Why: Direct object clitics. [[Italian#^it-Q0522|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Lui%20perse%20la%20memoria.)
^it-Q0522-answer

**it-Q0523** — Lo tenga lontano da me.

Keep him away from me.

Expected form: **Lo**

Why: Direct object clitics. [[Italian#^it-Q0523|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Lo%20tenga%20lontano%20da%20me.)
^it-Q0523-answer

**it-Q0524** — Lo tenga lontano da me.

Keep him away from me.

Expected form: **Lo**

Why: Direct object clitics. [[Italian#^it-Q0524|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Lo%20tenga%20lontano%20da%20me.)
^it-Q0524-answer

**it-Q0525** — La odiano tutti.

Everybody hates her.

Expected form: **La**

Why: Direct object clitics. [[Italian#^it-Q0525|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=La%20odiano%20tutti.)
^it-Q0525-answer

**it-Q0526** — La odiano tutti.

Everybody hates her.

Why: Direct object clitics. [[Italian#^it-Q0526|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=La%20odiano%20tutti.)
^it-Q0526-answer

**it-Q0527** — La state ancora cercando?

Are you still looking for her?

Why: Direct object clitics. [[Italian#^it-Q0527|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=La%20state%20ancora%20cercando%3F)
^it-Q0527-answer

**it-Q0528** — La state ancora cercando?

Are you still looking for her?

Lo/la/li/le can replace direct objects. They normally precede a finite verb but can attach to infinitives and some imperatives. Some identical forms also serve other roles.

Why: Direct object clitics. [[Italian#^it-Q0528|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=La%20state%20ancora%20cercando%3F)
^it-Q0528-answer

**it-Q0529** — Mi scusi, dov'è la biblioteca?

Excuse me, where is the library?

Expected form: **Mi**

Why: Direct object clitics. [[Italian#^it-Q0529|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Mi%20scusi%2C%20dov%27%C3%A8%20la%20biblioteca%3F)
^it-Q0529-answer

**it-Q0530** — Mi scusi, dov'è la biblioteca?

Excuse me, where is the library?

Expected form: **Mi**

Why: Direct object clitics. [[Italian#^it-Q0530|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Mi%20scusi%2C%20dov%27%C3%A8%20la%20biblioteca%3F)
^it-Q0530-answer

**it-Q0531** — Forse vi sbagliate.

Perhaps you are mistaken.

Expected form: **vi**

Why: Direct object clitics. [[Italian#^it-Q0531|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Forse%20vi%20sbagliate.)
^it-Q0531-answer

**it-Q0532** — Forse vi sbagliate.

Perhaps you are mistaken.

Why: Direct object clitics. [[Italian#^it-Q0532|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Forse%20vi%20sbagliate.)
^it-Q0532-answer

**it-Q0533** — Sbucciate la mela prima di mangiarla.

Peel the apple before you eat it.

Why: Direct object clitics. [[Italian#^it-Q0533|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Sbucciate%20la%20mela%20prima%20di%20mangiarla.)
^it-Q0533-answer

**it-Q0534** — Sbucciate la mela prima di mangiarla.

Peel the apple before you eat it.

Lo/la/li/le can replace direct objects. They normally precede a finite verb but can attach to infinitives and some imperatives. Some identical forms also serve other roles.

Why: Direct object clitics. [[Italian#^it-Q0534|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Sbucciate%20la%20mela%20prima%20di%20mangiarla.)
^it-Q0534-answer

**it-Q0535** — Voi due vi siete incontrati?

Have you two met?

Expected form: **vi**

Why: Direct object clitics. [[Italian#^it-Q0535|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Voi%20due%20vi%20siete%20incontrati%3F)
^it-Q0535-answer

**it-Q0536** — Voi due vi siete incontrati?

Have you two met?

Expected form: **vi**

Why: Direct object clitics. [[Italian#^it-Q0536|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Voi%20due%20vi%20siete%20incontrati%3F)
^it-Q0536-answer

**it-Q0537** — Mi piace la storia.

I like history.

Expected form: **Mi**

Why: Direct object clitics. [[Italian#^it-Q0537|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Mi%20piace%20la%20storia.)
^it-Q0537-answer

**it-Q0538** — Mi piace la storia.

I like history.

Why: Direct object clitics. [[Italian#^it-Q0538|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Mi%20piace%20la%20storia.)
^it-Q0538-answer

**it-Q0539** — Io non avrei mai dovuto baciare la fidanzata di Tom.

I never should've kissed Tom's girlfriend.

Why: Direct object clitics. [[Italian#^it-Q0539|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Io%20non%20avrei%20mai%20dovuto%20baciare%20la%20fidanzata%20di%20Tom.)
^it-Q0539-answer

**it-Q0540** — Io non avrei mai dovuto baciare la fidanzata di Tom.

I never should've kissed Tom's girlfriend.

Lo/la/li/le can replace direct objects. They normally precede a finite verb but can attach to infinitives and some imperatives. Some identical forms also serve other roles.

Why: Direct object clitics. [[Italian#^it-Q0540|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Io%20non%20avrei%20mai%20dovuto%20baciare%20la%20fidanzata%20di%20Tom.)
^it-Q0540-answer

**it-Q0541** — Tu ci hai sparato.

You shot us.

Expected form: **ci**

Why: Direct object clitics. [[Italian#^it-Q0541|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tu%20ci%20hai%20sparato.)
^it-Q0541-answer

**it-Q0542** — Tu ci hai sparato.

You shot us.

Expected form: **ci**

Why: Direct object clitics. [[Italian#^it-Q0542|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tu%20ci%20hai%20sparato.)
^it-Q0542-answer

**it-Q0543** — Le patatine non ti fanno bene.

Potato chips are not good for you.

Expected form: **Le**

Why: Direct object clitics. [[Italian#^it-Q0543|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Le%20patatine%20non%20ti%20fanno%20bene.)
^it-Q0543-answer

**it-Q0544** — Le patatine non ti fanno bene.

Potato chips are not good for you.

Why: Direct object clitics. [[Italian#^it-Q0544|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Le%20patatine%20non%20ti%20fanno%20bene.)
^it-Q0544-answer

**it-Q0545** — Lui ha circa la mia età.

He is about my age.

Why: Direct object clitics. [[Italian#^it-Q0545|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Lui%20ha%20circa%20la%20mia%20et%C3%A0.)
^it-Q0545-answer

**it-Q0546** — Lui ha circa la mia età.

He is about my age.

Lo/la/li/le can replace direct objects. They normally precede a finite verb but can attach to infinitives and some imperatives. Some identical forms also serve other roles.

Why: Direct object clitics. [[Italian#^it-Q0546|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Lui%20ha%20circa%20la%20mia%20et%C3%A0.)
^it-Q0546-answer

**it-Q0547** — Qual è la tua boyband preferita?

What's your favorite boy band?

Expected form: **la**

Why: Direct object clitics. [[Italian#^it-Q0547|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Qual%20%C3%A8%20la%20tua%20boyband%20preferita%3F)
^it-Q0547-answer

**it-Q0548** — Qual è la tua boyband preferita?

What's your favorite boy band?

Expected form: **la**

Why: Direct object clitics. [[Italian#^it-Q0548|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Qual%20%C3%A8%20la%20tua%20boyband%20preferita%3F)
^it-Q0548-answer

**it-Q0549** — Nessuno ti ha obbligato a farlo.

Nobody forced you to do that.

Expected form: **ti**

Why: Direct object clitics. [[Italian#^it-Q0549|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Nessuno%20ti%20ha%20obbligato%20a%20farlo.)
^it-Q0549-answer

**it-Q0550** — Nessuno ti ha obbligato a farlo.

Nobody forced you to do that.

Why: Direct object clitics. [[Italian#^it-Q0550|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Nessuno%20ti%20ha%20obbligato%20a%20farlo.)
^it-Q0550-answer


### Answers 551–600

**it-Q0551** — La luna è uscita da dietro le nuvole.

The moon came out from behind the clouds.

Why: Indirect objects. [[Italian#^it-Q0551|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=La%20luna%20%C3%A8%20uscita%20da%20dietro%20le%20nuvole.)
^it-Q0551-answer

**it-Q0552** — La luna è uscita da dietro le nuvole.

The moon came out from behind the clouds.

Indirect clitics replace common recipient complements. Gli and le distinguish many singular uses; combined clitics take special forms. Always identify what is being given and to whom.

Why: Indirect objects. [[Italian#^it-Q0552|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=La%20luna%20%C3%A8%20uscita%20da%20dietro%20le%20nuvole.)
^it-Q0552-answer

**it-Q0553** — Vi piace il vino bianco?

Do you like white wine?

Expected form: **Vi**

Why: Indirect objects. [[Italian#^it-Q0553|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Vi%20piace%20il%20vino%20bianco%3F)
^it-Q0553-answer

**it-Q0554** — Vi piace il vino bianco?

Do you like white wine?

Expected form: **Vi**

Why: Indirect objects. [[Italian#^it-Q0554|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Vi%20piace%20il%20vino%20bianco%3F)
^it-Q0554-answer

**it-Q0555** — Tom non mi ha ancora chiamata.

Tom hasn't called me yet.

Expected form: **mi**

Why: Indirect objects. [[Italian#^it-Q0555|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20non%20mi%20ha%20ancora%20chiamata.)
^it-Q0555-answer

**it-Q0556** — Tom non mi ha ancora chiamata.

Tom hasn't called me yet.

Why: Indirect objects. [[Italian#^it-Q0556|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20non%20mi%20ha%20ancora%20chiamata.)
^it-Q0556-answer

**it-Q0557** — Ti dovresti scusare con me.

You should apologize to me.

Why: Indirect objects. [[Italian#^it-Q0557|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Ti%20dovresti%20scusare%20con%20me.)
^it-Q0557-answer

**it-Q0558** — Ti dovresti scusare con me.

You should apologize to me.

Indirect clitics replace common recipient complements. Gli and le distinguish many singular uses; combined clitics take special forms. Always identify what is being given and to whom.

Why: Indirect objects. [[Italian#^it-Q0558|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Ti%20dovresti%20scusare%20con%20me.)
^it-Q0558-answer

**it-Q0559** — Calmatevi! Non vi innervosite!

Calm down! Don't get nervous!

Expected form: **vi**

Why: Indirect objects. [[Italian#^it-Q0559|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Calmatevi%21%20Non%20vi%20innervosite%21)
^it-Q0559-answer

**it-Q0560** — Calmatevi! Non vi innervosite!

Calm down! Don't get nervous!

Expected form: **vi**

Why: Indirect objects. [[Italian#^it-Q0560|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Calmatevi%21%20Non%20vi%20innervosite%21)
^it-Q0560-answer

**it-Q0561** — "Ti odio." "Ti odio anch'io."

"I hate you." "I hate you, too."

Expected form: **Ti**

Why: Indirect objects. [[Italian#^it-Q0561|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=%22Ti%20odio.%22%20%22Ti%20odio%20anch%27io.%22)
^it-Q0561-answer

**it-Q0562** — "Ti odio." "Ti odio anch'io."

"I hate you." "I hate you, too."

Why: Indirect objects. [[Italian#^it-Q0562|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=%22Ti%20odio.%22%20%22Ti%20odio%20anch%27io.%22)
^it-Q0562-answer

**it-Q0563** — Tom vi amava.

Tom loved you.

Why: Indirect objects. [[Italian#^it-Q0563|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20vi%20amava.)
^it-Q0563-answer

**it-Q0564** — Tom vi amava.

Tom loved you.

Indirect clitics replace common recipient complements. Gli and le distinguish many singular uses; combined clitics take special forms. Always identify what is being given and to whom.

Why: Indirect objects. [[Italian#^it-Q0564|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20vi%20amava.)
^it-Q0564-answer

**it-Q0565** — Mi sento sempre cupo.

I always feel gloomy.

Expected form: **Mi**

Why: Indirect objects. [[Italian#^it-Q0565|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Mi%20sento%20sempre%20cupo.)
^it-Q0565-answer

**it-Q0566** — Mi sento sempre cupo.

I always feel gloomy.

Expected form: **Mi**

Why: Indirect objects. [[Italian#^it-Q0566|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Mi%20sento%20sempre%20cupo.)
^it-Q0566-answer

**it-Q0567** — Ci siamo aiutate l'un l'altra.

We helped one another.

Expected form: **Ci**

Why: Indirect objects. [[Italian#^it-Q0567|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Ci%20siamo%20aiutate%20l%27un%20l%27altra.)
^it-Q0567-answer

**it-Q0568** — Ci siamo aiutate l'un l'altra.

We helped one another.

Why: Indirect objects. [[Italian#^it-Q0568|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Ci%20siamo%20aiutate%20l%27un%20l%27altra.)
^it-Q0568-answer

**it-Q0569** — Sono quasi le dieci.

It is almost ten o'clock.

Why: Indirect objects. [[Italian#^it-Q0569|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Sono%20quasi%20le%20dieci.)
^it-Q0569-answer

**it-Q0570** — Sono quasi le dieci.

It is almost ten o'clock.

Indirect clitics replace common recipient complements. Gli and le distinguish many singular uses; combined clitics take special forms. Always identify what is being given and to whom.

Why: Indirect objects. [[Italian#^it-Q0570|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Sono%20quasi%20le%20dieci.)
^it-Q0570-answer

**it-Q0571** — Tom non ci disse tutto.

Tom didn't tell us everything.

Expected form: **ci**

Why: Indirect objects. [[Italian#^it-Q0571|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20non%20ci%20disse%20tutto.)
^it-Q0571-answer

**it-Q0572** — Tom non ci disse tutto.

Tom didn't tell us everything.

Expected form: **ci**

Why: Indirect objects. [[Italian#^it-Q0572|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20non%20ci%20disse%20tutto.)
^it-Q0572-answer

**it-Q0573** — Le sue parole venivano dal cuore.

His words were heartfelt.

Expected form: **Le**

Why: Indirect objects. [[Italian#^it-Q0573|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Le%20sue%20parole%20venivano%20dal%20cuore.)
^it-Q0573-answer

**it-Q0574** — Le sue parole venivano dal cuore.

His words were heartfelt.

Why: Indirect objects. [[Italian#^it-Q0574|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Le%20sue%20parole%20venivano%20dal%20cuore.)
^it-Q0574-answer

**it-Q0575** — Mi servono alcune risposte da lui.

I need some answers from him.

Why: Indirect objects. [[Italian#^it-Q0575|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Mi%20servono%20alcune%20risposte%20da%20lui.)
^it-Q0575-answer

**it-Q0576** — Mi servono alcune risposte da lui.

I need some answers from him.

Indirect clitics replace common recipient complements. Gli and le distinguish many singular uses; combined clitics take special forms. Always identify what is being given and to whom.

Why: Indirect objects. [[Italian#^it-Q0576|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Mi%20servono%20alcune%20risposte%20da%20lui.)
^it-Q0576-answer

**it-Q0577** — Gli esami finali stanno arrivando, per cui sono occupata.

Final exams are coming up, so I'm busy.

Expected form: **Gli**

Why: Indirect objects. [[Italian#^it-Q0577|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Gli%20esami%20finali%20stanno%20arrivando%2C%20per%20cui%20sono%20occupata.)
^it-Q0577-answer

**it-Q0578** — Gli esami finali stanno arrivando, per cui sono occupata.

Final exams are coming up, so I'm busy.

Expected form: **Gli**

Why: Indirect objects. [[Italian#^it-Q0578|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Gli%20esami%20finali%20stanno%20arrivando%2C%20per%20cui%20sono%20occupata.)
^it-Q0578-answer

**it-Q0579** — La malattia mi ha impedito di andare all'estero.

Illness prevented me from going abroad.

Expected form: **mi**

Why: Indirect objects. [[Italian#^it-Q0579|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=La%20malattia%20mi%20ha%20impedito%20di%20andare%20all%27estero.)
^it-Q0579-answer

**it-Q0580** — La malattia mi ha impedito di andare all'estero.

Illness prevented me from going abroad.

Why: Indirect objects. [[Italian#^it-Q0580|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=La%20malattia%20mi%20ha%20impedito%20di%20andare%20all%27estero.)
^it-Q0580-answer

**it-Q0581** — Mollami le braccia!

Let go of my arms!

Why: Indirect objects. [[Italian#^it-Q0581|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Mollami%20le%20braccia%21)
^it-Q0581-answer

**it-Q0582** — Mollami le braccia!

Let go of my arms!

Indirect clitics replace common recipient complements. Gli and le distinguish many singular uses; combined clitics take special forms. Always identify what is being given and to whom.

Why: Indirect objects. [[Italian#^it-Q0582|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Mollami%20le%20braccia%21)
^it-Q0582-answer

**it-Q0583** — Sapete mangiare con le bacchette?

Do you know how to eat with chopsticks?

Expected form: **le**

Why: Indirect objects. [[Italian#^it-Q0583|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Sapete%20mangiare%20con%20le%20bacchette%3F)
^it-Q0583-answer

**it-Q0584** — Sapete mangiare con le bacchette?

Do you know how to eat with chopsticks?

Expected form: **le**

Why: Indirect objects. [[Italian#^it-Q0584|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Sapete%20mangiare%20con%20le%20bacchette%3F)
^it-Q0584-answer

**it-Q0585** — Le piace leggere riviste.

She likes to read magazines.

Expected form: **Le**

Why: Indirect objects. [[Italian#^it-Q0585|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Le%20piace%20leggere%20riviste.)
^it-Q0585-answer

**it-Q0586** — Le piace leggere riviste.

She likes to read magazines.

Why: Indirect objects. [[Italian#^it-Q0586|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Le%20piace%20leggere%20riviste.)
^it-Q0586-answer

**it-Q0587** — Non conosco chi le ha uccise.

I don't know who killed them.

Why: Indirect objects. [[Italian#^it-Q0587|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20conosco%20chi%20le%20ha%20uccise.)
^it-Q0587-answer

**it-Q0588** — Non conosco chi le ha uccise.

I don't know who killed them.

Indirect clitics replace common recipient complements. Gli and le distinguish many singular uses; combined clitics take special forms. Always identify what is being given and to whom.

Why: Indirect objects. [[Italian#^it-Q0588|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20conosco%20chi%20le%20ha%20uccise.)
^it-Q0588-answer

**it-Q0589** — Io mi sono sentito perso senza di lei.

I felt lost without you.

Expected form: **mi**

Why: Indirect objects. [[Italian#^it-Q0589|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Io%20mi%20sono%20sentito%20perso%20senza%20di%20lei.)
^it-Q0589-answer

**it-Q0590** — Io mi sono sentito perso senza di lei.

I felt lost without you.

Expected form: **mi**

Why: Indirect objects. [[Italian#^it-Q0590|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Io%20mi%20sono%20sentito%20perso%20senza%20di%20lei.)
^it-Q0590-answer

**it-Q0591** — Chiedi a Tom e Mary di portare le loro chitarre.

Ask Tom and Mary to bring their guitars.

Expected form: **le**

Why: Indirect objects. [[Italian#^it-Q0591|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Chiedi%20a%20Tom%20e%20Mary%20di%20portare%20le%20loro%20chitarre.)
^it-Q0591-answer

**it-Q0592** — Chiedi a Tom e Mary di portare le loro chitarre.

Ask Tom and Mary to bring their guitars.

Why: Indirect objects. [[Italian#^it-Q0592|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Chiedi%20a%20Tom%20e%20Mary%20di%20portare%20le%20loro%20chitarre.)
^it-Q0592-answer

**it-Q0593** — Lui vi sta usando.

He's using you.

Why: Indirect objects. [[Italian#^it-Q0593|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Lui%20vi%20sta%20usando.)
^it-Q0593-answer

**it-Q0594** — Lui vi sta usando.

He's using you.

Indirect clitics replace common recipient complements. Gli and le distinguish many singular uses; combined clitics take special forms. Always identify what is being given and to whom.

Why: Indirect objects. [[Italian#^it-Q0594|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Lui%20vi%20sta%20usando.)
^it-Q0594-answer

**it-Q0595** — Le comprerò una birra.

I'll buy her a beer.

Expected form: **Le**

Why: Indirect objects. [[Italian#^it-Q0595|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Le%20comprer%C3%B2%20una%20birra.)
^it-Q0595-answer

**it-Q0596** — Le comprerò una birra.

I'll buy her a beer.

Expected form: **Le**

Why: Indirect objects. [[Italian#^it-Q0596|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Le%20comprer%C3%B2%20una%20birra.)
^it-Q0596-answer

**it-Q0597** — Il bingo è qualcosa a cui giocano le nonne.

Bingo is something that grandmothers play.

Expected form: **le**

Why: Indirect objects. [[Italian#^it-Q0597|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Il%20bingo%20%C3%A8%20qualcosa%20a%20cui%20giocano%20le%20nonne.)
^it-Q0597-answer

**it-Q0598** — Il bingo è qualcosa a cui giocano le nonne.

Bingo is something that grandmothers play.

Why: Indirect objects. [[Italian#^it-Q0598|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Il%20bingo%20%C3%A8%20qualcosa%20a%20cui%20giocano%20le%20nonne.)
^it-Q0598-answer

**it-Q0599** — Tu non mi hai preparata per questo.

You didn't prepare me for this.

Why: Indirect objects. [[Italian#^it-Q0599|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tu%20non%20mi%20hai%20preparata%20per%20questo.)
^it-Q0599-answer

**it-Q0600** — Tu non mi hai preparata per questo.

You didn't prepare me for this.

Indirect clitics replace common recipient complements. Gli and le distinguish many singular uses; combined clitics take special forms. Always identify what is being given and to whom.

Why: Indirect objects. [[Italian#^it-Q0600|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tu%20non%20mi%20hai%20preparata%20per%20questo.)
^it-Q0600-answer


### Answers 601–650

**it-Q0601** — Ci sono delle lettere per me nella posta di oggi?

Are there any letters to me in today's mail?

Expected form: **Ci**

Why: Ci and ne. [[Italian#^it-Q0601|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Ci%20sono%20delle%20lettere%20per%20me%20nella%20posta%20di%20oggi%3F)
^it-Q0601-answer

**it-Q0602** — Ci sono delle lettere per me nella posta di oggi?

Are there any letters to me in today's mail?

Expected form: **Ci**

Why: Ci and ne. [[Italian#^it-Q0602|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Ci%20sono%20delle%20lettere%20per%20me%20nella%20posta%20di%20oggi%3F)
^it-Q0602-answer

**it-Q0603** — Ci lamentiamo dei nostri vicini.

We complain about our neighbors.

Expected form: **Ci**

Why: Ci and ne. [[Italian#^it-Q0603|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Ci%20lamentiamo%20dei%20nostri%20vicini.)
^it-Q0603-answer

**it-Q0604** — Ci lamentiamo dei nostri vicini.

We complain about our neighbors.

Why: Ci and ne. [[Italian#^it-Q0604|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Ci%20lamentiamo%20dei%20nostri%20vicini.)
^it-Q0604-answer

**it-Q0605** — L'altra squadra ci ha presi alla leggera.

The other team took us lightly.

Why: Ci and ne. [[Italian#^it-Q0605|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=L%27altra%20squadra%20ci%20ha%20presi%20alla%20leggera.)
^it-Q0605-answer

**it-Q0606** — L'altra squadra ci ha presi alla leggera.

The other team took us lightly.

Ci can refer to place or appear in other constructions. Ne often replaces a di relation or quantity. Retain the number when needed: Ne ho due. Learn their meanings with complete verb phrases.

Why: Ci and ne. [[Italian#^it-Q0606|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=L%27altra%20squadra%20ci%20ha%20presi%20alla%20leggera.)
^it-Q0606-answer

**it-Q0607** — Non ci arriverai in tempo.

You won't get there on time.

Expected form: **ci**

Why: Ci and ne. [[Italian#^it-Q0607|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20ci%20arriverai%20in%20tempo.)
^it-Q0607-answer

**it-Q0608** — Non ci arriverai in tempo.

You won't get there on time.

Expected form: **ci**

Why: Ci and ne. [[Italian#^it-Q0608|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20ci%20arriverai%20in%20tempo.)
^it-Q0608-answer

**it-Q0609** — Ci ha accolte con un sorriso.

She greeted us with a smile.

Expected form: **Ci**

Why: Ci and ne. [[Italian#^it-Q0609|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Ci%20ha%20accolte%20con%20un%20sorriso.)
^it-Q0609-answer

**it-Q0610** — Ci ha accolte con un sorriso.

She greeted us with a smile.

Why: Ci and ne. [[Italian#^it-Q0610|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Ci%20ha%20accolte%20con%20un%20sorriso.)
^it-Q0610-answer

**it-Q0611** — Ci sono volute tre ore per riparare il giocattolo rotto.

It took three hours to put the broken toy together.

Why: Ci and ne. [[Italian#^it-Q0611|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Ci%20sono%20volute%20tre%20ore%20per%20riparare%20il%20giocattolo%20rotto.)
^it-Q0611-answer

**it-Q0612** — Ci sono volute tre ore per riparare il giocattolo rotto.

It took three hours to put the broken toy together.

Ci can refer to place or appear in other constructions. Ne often replaces a di relation or quantity. Retain the number when needed: Ne ho due. Learn their meanings with complete verb phrases.

Why: Ci and ne. [[Italian#^it-Q0612|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Ci%20sono%20volute%20tre%20ore%20per%20riparare%20il%20giocattolo%20rotto.)
^it-Q0612-answer

**it-Q0613** — Pensate che ci vorrà molto in autobus?

Do you think it will take long by bus?

Expected form: **ci**

Why: Ci and ne. [[Italian#^it-Q0613|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Pensate%20che%20ci%20vorr%C3%A0%20molto%20in%20autobus%3F)
^it-Q0613-answer

**it-Q0614** — Pensate che ci vorrà molto in autobus?

Do you think it will take long by bus?

Expected form: **ci**

Why: Ci and ne. [[Italian#^it-Q0614|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Pensate%20che%20ci%20vorr%C3%A0%20molto%20in%20autobus%3F)
^it-Q0614-answer

**it-Q0615** — Non ne vedo davvero l'ora.

I'm really looking forward to this.

Expected form: **ne**

Why: Ci and ne. [[Italian#^it-Q0615|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20ne%20vedo%20davvero%20l%27ora.)
^it-Q0615-answer

**it-Q0616** — Non ne vedo davvero l'ora.

I'm really looking forward to this.

Why: Ci and ne. [[Italian#^it-Q0616|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20ne%20vedo%20davvero%20l%27ora.)
^it-Q0616-answer

**it-Q0617** — Ci sono undici persone in una squadra di calcio.

There are eleven people in a soccer team.

Why: Ci and ne. [[Italian#^it-Q0617|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Ci%20sono%20undici%20persone%20in%20una%20squadra%20di%20calcio.)
^it-Q0617-answer

**it-Q0618** — Ci sono undici persone in una squadra di calcio.

There are eleven people in a soccer team.

Ci can refer to place or appear in other constructions. Ne often replaces a di relation or quantity. Retain the number when needed: Ne ho due. Learn their meanings with complete verb phrases.

Why: Ci and ne. [[Italian#^it-Q0618|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Ci%20sono%20undici%20persone%20in%20una%20squadra%20di%20calcio.)
^it-Q0618-answer

**it-Q0619** — Non ci vorrà molto prima che stia meglio.

It will not be long before he gets better.

Expected form: **ci**

Why: Ci and ne. [[Italian#^it-Q0619|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20ci%20vorr%C3%A0%20molto%20prima%20che%20stia%20meglio.)
^it-Q0619-answer

**it-Q0620** — Non ci vorrà molto prima che stia meglio.

It will not be long before he gets better.

Expected form: **ci**

Why: Ci and ne. [[Italian#^it-Q0620|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20ci%20vorr%C3%A0%20molto%20prima%20che%20stia%20meglio.)
^it-Q0620-answer

**it-Q0621** — Se ne va presto, vero?

He's leaving soon, isn't he?

Expected form: **ne**

Why: Ci and ne. [[Italian#^it-Q0621|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Se%20ne%20va%20presto%2C%20vero%3F)
^it-Q0621-answer

**it-Q0622** — Se ne va presto, vero?

He's leaving soon, isn't he?

Why: Ci and ne. [[Italian#^it-Q0622|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Se%20ne%20va%20presto%2C%20vero%3F)
^it-Q0622-answer

**it-Q0623** — Ci rimane del sale?

Is there any salt left?

Why: Ci and ne. [[Italian#^it-Q0623|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Ci%20rimane%20del%20sale%3F)
^it-Q0623-answer

**it-Q0624** — Ci rimane del sale?

Is there any salt left?

Ci can refer to place or appear in other constructions. Ne often replaces a di relation or quantity. Retain the number when needed: Ne ho due. Learn their meanings with complete verb phrases.

Why: Ci and ne. [[Italian#^it-Q0624|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Ci%20rimane%20del%20sale%3F)
^it-Q0624-answer

**it-Q0625** — Tom non ci ha detto cos'è capitato dopo.

Tom didn't tell us what happened next.

Expected form: **ci**

Why: Ci and ne. [[Italian#^it-Q0625|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20non%20ci%20ha%20detto%20cos%27%C3%A8%20capitato%20dopo.)
^it-Q0625-answer

**it-Q0626** — Tom non ci ha detto cos'è capitato dopo.

Tom didn't tell us what happened next.

Expected form: **ci**

Why: Ci and ne. [[Italian#^it-Q0626|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20non%20ci%20ha%20detto%20cos%27%C3%A8%20capitato%20dopo.)
^it-Q0626-answer

**it-Q0627** — Ci sei davvero mancato.

We really missed you.

Expected form: **Ci**

Why: Ci and ne. [[Italian#^it-Q0627|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Ci%20sei%20davvero%20mancato.)
^it-Q0627-answer

**it-Q0628** — Ci sei davvero mancato.

We really missed you.

Why: Ci and ne. [[Italian#^it-Q0628|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Ci%20sei%20davvero%20mancato.)
^it-Q0628-answer

**it-Q0629** — Ci ha portato delle notizie tristi.

He brought us sad news.

Why: Ci and ne. [[Italian#^it-Q0629|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Ci%20ha%20portato%20delle%20notizie%20tristi.)
^it-Q0629-answer

**it-Q0630** — Ci ha portato delle notizie tristi.

He brought us sad news.

Ci can refer to place or appear in other constructions. Ne often replaces a di relation or quantity. Retain the number when needed: Ne ho due. Learn their meanings with complete verb phrases.

Why: Ci and ne. [[Italian#^it-Q0630|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Ci%20ha%20portato%20delle%20notizie%20tristi.)
^it-Q0630-answer

**it-Q0631** — Apparentemente in questa biblioteca ci sono dei libri preziosi che il denaro non può comprare.

Apparently in this library are precious books that money can't buy.

Expected form: **ci**

Why: Ci and ne. [[Italian#^it-Q0631|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Apparentemente%20in%20questa%20biblioteca%20ci%20sono%20dei%20libri%20preziosi%20che%20il%20denaro%20non%20pu%C3%B2%20comprare.)
^it-Q0631-answer

**it-Q0632** — Apparentemente in questa biblioteca ci sono dei libri preziosi che il denaro non può comprare.

Apparently in this library are precious books that money can't buy.

Expected form: **ci**

Why: Ci and ne. [[Italian#^it-Q0632|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Apparentemente%20in%20questa%20biblioteca%20ci%20sono%20dei%20libri%20preziosi%20che%20il%20denaro%20non%20pu%C3%B2%20comprare.)
^it-Q0632-answer

**it-Q0633** — Andiamo a vedere se Tom ci può aiutare.

Let's go see if Tom can help us.

Expected form: **ci**

Why: Ci and ne. [[Italian#^it-Q0633|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Andiamo%20a%20vedere%20se%20Tom%20ci%20pu%C3%B2%20aiutare.)
^it-Q0633-answer

**it-Q0634** — Andiamo a vedere se Tom ci può aiutare.

Let's go see if Tom can help us.

Why: Ci and ne. [[Italian#^it-Q0634|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Andiamo%20a%20vedere%20se%20Tom%20ci%20pu%C3%B2%20aiutare.)
^it-Q0634-answer

**it-Q0635** — Mary ne ha ordinata una.

Mary has ordered one.

Why: Ci and ne. [[Italian#^it-Q0635|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Mary%20ne%20ha%20ordinata%20una.)
^it-Q0635-answer

**it-Q0636** — Mary ne ha ordinata una.

Mary has ordered one.

Ci can refer to place or appear in other constructions. Ne often replaces a di relation or quantity. Retain the number when needed: Ne ho due. Learn their meanings with complete verb phrases.

Why: Ci and ne. [[Italian#^it-Q0636|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Mary%20ne%20ha%20ordinata%20una.)
^it-Q0636-answer

**it-Q0637** — Ci si aspetta che lo faccia, vero?

He's expected to do that, isn't he?

Expected form: **Ci**

Why: Ci and ne. [[Italian#^it-Q0637|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Ci%20si%20aspetta%20che%20lo%20faccia%2C%20vero%3F)
^it-Q0637-answer

**it-Q0638** — Ci si aspetta che lo faccia, vero?

He's expected to do that, isn't he?

Expected form: **Ci**

Why: Ci and ne. [[Italian#^it-Q0638|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Ci%20si%20aspetta%20che%20lo%20faccia%2C%20vero%3F)
^it-Q0638-answer

**it-Q0639** — Per quando ne avete bisogno?

When do you need it by?

Expected form: **ne**

Why: Ci and ne. [[Italian#^it-Q0639|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Per%20quando%20ne%20avete%20bisogno%3F)
^it-Q0639-answer

**it-Q0640** — Per quando ne avete bisogno?

When do you need it by?

Why: Ci and ne. [[Italian#^it-Q0640|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Per%20quando%20ne%20avete%20bisogno%3F)
^it-Q0640-answer

**it-Q0641** — Non me ne frega un accidente!

I don't give a damn about it!

Why: Ci and ne. [[Italian#^it-Q0641|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20me%20ne%20frega%20un%20accidente%21)
^it-Q0641-answer

**it-Q0642** — Non me ne frega un accidente!

I don't give a damn about it!

Ci can refer to place or appear in other constructions. Ne often replaces a di relation or quantity. Retain the number when needed: Ne ho due. Learn their meanings with complete verb phrases.

Why: Ci and ne. [[Italian#^it-Q0642|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20me%20ne%20frega%20un%20accidente%21)
^it-Q0642-answer

**it-Q0643** — Tom ci conosce.

Tom knows us.

Expected form: **ci**

Why: Ci and ne. [[Italian#^it-Q0643|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20ci%20conosce.)
^it-Q0643-answer

**it-Q0644** — Tom ci conosce.

Tom knows us.

Expected form: **ci**

Why: Ci and ne. [[Italian#^it-Q0644|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20ci%20conosce.)
^it-Q0644-answer

**it-Q0645** — Perché non ci sono dei file audio per l'arabo?

Why aren't there audio files for Arabic?

Expected form: **ci**

Why: Ci and ne. [[Italian#^it-Q0645|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Perch%C3%A9%20non%20ci%20sono%20dei%20file%20audio%20per%20l%27arabo%3F)
^it-Q0645-answer

**it-Q0646** — Perché non ci sono dei file audio per l'arabo?

Why aren't there audio files for Arabic?

Why: Ci and ne. [[Italian#^it-Q0646|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Perch%C3%A9%20non%20ci%20sono%20dei%20file%20audio%20per%20l%27arabo%3F)
^it-Q0646-answer

**it-Q0647** — Ci siamo rilassate in salotto.

We relaxed in the living room.

Why: Ci and ne. [[Italian#^it-Q0647|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Ci%20siamo%20rilassate%20in%20salotto.)
^it-Q0647-answer

**it-Q0648** — Ci siamo rilassate in salotto.

We relaxed in the living room.

Ci can refer to place or appear in other constructions. Ne often replaces a di relation or quantity. Retain the number when needed: Ne ho due. Learn their meanings with complete verb phrases.

Why: Ci and ne. [[Italian#^it-Q0648|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Ci%20siamo%20rilassate%20in%20salotto.)
^it-Q0648-answer

**it-Q0649** — Ci hanno ignorati tutti.

Everyone ignored us.

Expected form: **Ci**

Why: Ci and ne. [[Italian#^it-Q0649|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Ci%20hanno%20ignorati%20tutti.)
^it-Q0649-answer

**it-Q0650** — Ci hanno ignorati tutti.

Everyone ignored us.

Expected form: **Ci**

Why: Ci and ne. [[Italian#^it-Q0650|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Ci%20hanno%20ignorati%20tutti.)
^it-Q0650-answer


### Answers 651–700

**it-Q0651** — Si sente molto felice.

He feels very happy.

Expected form: **Si**

Why: Reflexive and impersonal si. [[Italian#^it-Q0651|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Si%20sente%20molto%20felice.)
^it-Q0651-answer

**it-Q0652** — Si sente molto felice.

He feels very happy.

Why: Reflexive and impersonal si. [[Italian#^it-Q0652|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Si%20sente%20molto%20felice.)
^it-Q0652-answer

**it-Q0653** — Più si lavora, più si guadagna.

The more one works, the more one earns.

Why: Reflexive and impersonal si. [[Italian#^it-Q0653|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Pi%C3%B9%20si%20lavora%2C%20pi%C3%B9%20si%20guadagna.)
^it-Q0653-answer

**it-Q0654** — Più si lavora, più si guadagna.

The more one works, the more one earns.

Si can mark a reflexive action, a passive-like construction or an impersonal statement. Its meaning and agreement depend on the verb and noun phrase; it does not always mean oneself.

Why: Reflexive and impersonal si. [[Italian#^it-Q0654|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Pi%C3%B9%20si%20lavora%2C%20pi%C3%B9%20si%20guadagna.)
^it-Q0654-answer

**it-Q0655** — Si fidavano di lui.

They trusted him.

Expected form: **Si**

Why: Reflexive and impersonal si. [[Italian#^it-Q0655|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Si%20fidavano%20di%20lui.)
^it-Q0655-answer

**it-Q0656** — Si fidavano di lui.

They trusted him.

Expected form: **Si**

Why: Reflexive and impersonal si. [[Italian#^it-Q0656|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Si%20fidavano%20di%20lui.)
^it-Q0656-answer

**it-Q0657** — Goccia dopo goccia, il lago si riempie.

Drop by drop, the lake fills.

Expected form: **si**

Why: Reflexive and impersonal si. [[Italian#^it-Q0657|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Goccia%20dopo%20goccia%2C%20il%20lago%20si%20riempie.)
^it-Q0657-answer

**it-Q0658** — Goccia dopo goccia, il lago si riempie.

Drop by drop, the lake fills.

Why: Reflexive and impersonal si. [[Italian#^it-Q0658|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Goccia%20dopo%20goccia%2C%20il%20lago%20si%20riempie.)
^it-Q0658-answer

**it-Q0659** — Tom si incontra con Mary questo pomeriggio.

Tom is meeting Mary this afternoon.

Why: Reflexive and impersonal si. [[Italian#^it-Q0659|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20si%20incontra%20con%20Mary%20questo%20pomeriggio.)
^it-Q0659-answer

**it-Q0660** — Tom si incontra con Mary questo pomeriggio.

Tom is meeting Mary this afternoon.

Si can mark a reflexive action, a passive-like construction or an impersonal statement. Its meaning and agreement depend on the verb and noun phrase; it does not always mean oneself.

Why: Reflexive and impersonal si. [[Italian#^it-Q0660|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20si%20incontra%20con%20Mary%20questo%20pomeriggio.)
^it-Q0660-answer

**it-Q0661** — Non si scordi di votare.

Don't forget to vote.

Expected form: **si**

Why: Reflexive and impersonal si. [[Italian#^it-Q0661|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20si%20scordi%20di%20votare.)
^it-Q0661-answer

**it-Q0662** — Non si scordi di votare.

Don't forget to vote.

Expected form: **si**

Why: Reflexive and impersonal si. [[Italian#^it-Q0662|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20si%20scordi%20di%20votare.)
^it-Q0662-answer

**it-Q0663** — Tom si ritirò dalla vita pubblica.

Tom retired from public life.

Expected form: **si**

Why: Reflexive and impersonal si. [[Italian#^it-Q0663|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20si%20ritir%C3%B2%20dalla%20vita%20pubblica.)
^it-Q0663-answer

**it-Q0664** — Tom si ritirò dalla vita pubblica.

Tom retired from public life.

Why: Reflexive and impersonal si. [[Italian#^it-Q0664|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20si%20ritir%C3%B2%20dalla%20vita%20pubblica.)
^it-Q0664-answer

**it-Q0665** — Tom si è veramente arrabbiato.

Tom got really angry.

Why: Reflexive and impersonal si. [[Italian#^it-Q0665|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20si%20%C3%A8%20veramente%20arrabbiato.)
^it-Q0665-answer

**it-Q0666** — Tom si è veramente arrabbiato.

Tom got really angry.

Si can mark a reflexive action, a passive-like construction or an impersonal statement. Its meaning and agreement depend on the verb and noun phrase; it does not always mean oneself.

Why: Reflexive and impersonal si. [[Italian#^it-Q0666|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20si%20%C3%A8%20veramente%20arrabbiato.)
^it-Q0666-answer

**it-Q0667** — Jack non si può permettere una nuova bici.

Jack can't afford a new bicycle.

Expected form: **si**

Why: Reflexive and impersonal si. [[Italian#^it-Q0667|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Jack%20non%20si%20pu%C3%B2%20permettere%20una%20nuova%20bici.)
^it-Q0667-answer

**it-Q0668** — Jack non si può permettere una nuova bici.

Jack can't afford a new bicycle.

Expected form: **si**

Why: Reflexive and impersonal si. [[Italian#^it-Q0668|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Jack%20non%20si%20pu%C3%B2%20permettere%20una%20nuova%20bici.)
^it-Q0668-answer

**it-Q0669** — Tom si scusò di nuovo.

Tom apologized again.

Expected form: **si**

Why: Reflexive and impersonal si. [[Italian#^it-Q0669|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20si%20scus%C3%B2%20di%20nuovo.)
^it-Q0669-answer

**it-Q0670** — Tom si scusò di nuovo.

Tom apologized again.

Why: Reflexive and impersonal si. [[Italian#^it-Q0670|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20si%20scus%C3%B2%20di%20nuovo.)
^it-Q0670-answer

**it-Q0671** — Si sta facendo più caldo.

It's getting hotter.

Why: Reflexive and impersonal si. [[Italian#^it-Q0671|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Si%20sta%20facendo%20pi%C3%B9%20caldo.)
^it-Q0671-answer

**it-Q0672** — Si sta facendo più caldo.

It's getting hotter.

Si can mark a reflexive action, a passive-like construction or an impersonal statement. Its meaning and agreement depend on the verb and noun phrase; it does not always mean oneself.

Why: Reflexive and impersonal si. [[Italian#^it-Q0672|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Si%20sta%20facendo%20pi%C3%B9%20caldo.)
^it-Q0672-answer

**it-Q0673** — Nella mia città c'è un autobus speciale, chiamato BLQ, che parte dall'aeroporto e si ferma vicino a casa mia.

In my city there is a special bus, called BLQ, which leaves from the airport and stops near my house.

Expected form: **si**

Why: Reflexive and impersonal si. [[Italian#^it-Q0673|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Nella%20mia%20citt%C3%A0%20c%27%C3%A8%20un%20autobus%20speciale%2C%20chiamato%20BLQ%2C%20che%20parte%20dall%27aeroporto%20e%20si%20ferma%20vicino%20a%20casa%20mia.)
^it-Q0673-answer

**it-Q0674** — Nella mia città c'è un autobus speciale, chiamato BLQ, che parte dall'aeroporto e si ferma vicino a casa mia.

In my city there is a special bus, called BLQ, which leaves from the airport and stops near my house.

Expected form: **si**

Why: Reflexive and impersonal si. [[Italian#^it-Q0674|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Nella%20mia%20citt%C3%A0%20c%27%C3%A8%20un%20autobus%20speciale%2C%20chiamato%20BLQ%2C%20che%20parte%20dall%27aeroporto%20e%20si%20ferma%20vicino%20a%20casa%20mia.)
^it-Q0674-answer

**it-Q0675** — Quando due "maschi alfa" si riuniscono in un gruppo, è emozionante vedere chi prende il sopravvento.

When two "Alpha males" come together in a group, it is exciting to see who holds the upper hand.

Expected form: **si**

Why: Reflexive and impersonal si. [[Italian#^it-Q0675|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Quando%20due%20%22maschi%20alfa%22%20si%20riuniscono%20in%20un%20gruppo%2C%20%C3%A8%20emozionante%20vedere%20chi%20prende%20il%20sopravvento.)
^it-Q0675-answer

**it-Q0676** — Quando due "maschi alfa" si riuniscono in un gruppo, è emozionante vedere chi prende il sopravvento.

When two "Alpha males" come together in a group, it is exciting to see who holds the upper hand.

Why: Reflexive and impersonal si. [[Italian#^it-Q0676|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Quando%20due%20%22maschi%20alfa%22%20si%20riuniscono%20in%20un%20gruppo%2C%20%C3%A8%20emozionante%20vedere%20chi%20prende%20il%20sopravvento.)
^it-Q0676-answer

**it-Q0677** — Tom si accorse che Mary lo stava seguendo.

Tom noticed that Mary was following him.

Why: Reflexive and impersonal si. [[Italian#^it-Q0677|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20si%20accorse%20che%20Mary%20lo%20stava%20seguendo.)
^it-Q0677-answer

**it-Q0678** — Tom si accorse che Mary lo stava seguendo.

Tom noticed that Mary was following him.

Si can mark a reflexive action, a passive-like construction or an impersonal statement. Its meaning and agreement depend on the verb and noun phrase; it does not always mean oneself.

Why: Reflexive and impersonal si. [[Italian#^it-Q0678|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20si%20accorse%20che%20Mary%20lo%20stava%20seguendo.)
^it-Q0678-answer

**it-Q0679** — La pioggia non si è ancora fermata.

The rain hasn't stopped yet.

Expected form: **si**

Why: Reflexive and impersonal si. [[Italian#^it-Q0679|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=La%20pioggia%20non%20si%20%C3%A8%20ancora%20fermata.)
^it-Q0679-answer

**it-Q0680** — La pioggia non si è ancora fermata.

The rain hasn't stopped yet.

Expected form: **si**

Why: Reflexive and impersonal si. [[Italian#^it-Q0680|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=La%20pioggia%20non%20si%20%C3%A8%20ancora%20fermata.)
^it-Q0680-answer

**it-Q0681** — La coppa si ruppe.

The cup broke.

Expected form: **si**

Why: Reflexive and impersonal si. [[Italian#^it-Q0681|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=La%20coppa%20si%20ruppe.)
^it-Q0681-answer

**it-Q0682** — La coppa si ruppe.

The cup broke.

Why: Reflexive and impersonal si. [[Italian#^it-Q0682|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=La%20coppa%20si%20ruppe.)
^it-Q0682-answer

**it-Q0683** — Nella stanza d'ospedale, l'infermiera che indossava abiti bianchi e la levatrice si stavano preparando per il parto.

In the hospital room, the nurse wearing white clothes and the midwife were preparing for the delivery.

Why: Reflexive and impersonal si. [[Italian#^it-Q0683|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Nella%20stanza%20d%27ospedale%2C%20l%27infermiera%20che%20indossava%20abiti%20bianchi%20e%20la%20levatrice%20si%20stavano%20preparando%20per%20il%20parto.)
^it-Q0683-answer

**it-Q0684** — Nella stanza d'ospedale, l'infermiera che indossava abiti bianchi e la levatrice si stavano preparando per il parto.

In the hospital room, the nurse wearing white clothes and the midwife were preparing for the delivery.

Si can mark a reflexive action, a passive-like construction or an impersonal statement. Its meaning and agreement depend on the verb and noun phrase; it does not always mean oneself.

Why: Reflexive and impersonal si. [[Italian#^it-Q0684|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Nella%20stanza%20d%27ospedale%2C%20l%27infermiera%20che%20indossava%20abiti%20bianchi%20e%20la%20levatrice%20si%20stavano%20preparando%20per%20il%20parto.)
^it-Q0684-answer

**it-Q0685** — Questa città si trova in Francia.

This city is located in France.

Expected form: **si**

Why: Reflexive and impersonal si. [[Italian#^it-Q0685|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Questa%20citt%C3%A0%20si%20trova%20in%20Francia.)
^it-Q0685-answer

**it-Q0686** — Questa città si trova in Francia.

This city is located in France.

Expected form: **si**

Why: Reflexive and impersonal si. [[Italian#^it-Q0686|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Questa%20citt%C3%A0%20si%20trova%20in%20Francia.)
^it-Q0686-answer

**it-Q0687** — Mescolando blu e rosso si ottiene il viola.

If you mix blue and red, you'll get purple.

Expected form: **si**

Why: Reflexive and impersonal si. [[Italian#^it-Q0687|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Mescolando%20blu%20e%20rosso%20si%20ottiene%20il%20viola.)
^it-Q0687-answer

**it-Q0688** — Mescolando blu e rosso si ottiene il viola.

If you mix blue and red, you'll get purple.

Why: Reflexive and impersonal si. [[Italian#^it-Q0688|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Mescolando%20blu%20e%20rosso%20si%20ottiene%20il%20viola.)
^it-Q0688-answer

**it-Q0689** — Tom e Mary si scambiarono i numeri.

Tom and Mary exchanged numbers.

Why: Reflexive and impersonal si. [[Italian#^it-Q0689|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20e%20Mary%20si%20scambiarono%20i%20numeri.)
^it-Q0689-answer

**it-Q0690** — Tom e Mary si scambiarono i numeri.

Tom and Mary exchanged numbers.

Si can mark a reflexive action, a passive-like construction or an impersonal statement. Its meaning and agreement depend on the verb and noun phrase; it does not always mean oneself.

Why: Reflexive and impersonal si. [[Italian#^it-Q0690|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20e%20Mary%20si%20scambiarono%20i%20numeri.)
^it-Q0690-answer

**it-Q0691** — La filosofia non è una cosa che si può imparare in sei mesi.

Philosophy is not a thing one can learn in six months.

Expected form: **si**

Why: Reflexive and impersonal si. [[Italian#^it-Q0691|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=La%20filosofia%20non%20%C3%A8%20una%20cosa%20che%20si%20pu%C3%B2%20imparare%20in%20sei%20mesi.)
^it-Q0691-answer

**it-Q0692** — La filosofia non è una cosa che si può imparare in sei mesi.

Philosophy is not a thing one can learn in six months.

Expected form: **si**

Why: Reflexive and impersonal si. [[Italian#^it-Q0692|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=La%20filosofia%20non%20%C3%A8%20una%20cosa%20che%20si%20pu%C3%B2%20imparare%20in%20sei%20mesi.)
^it-Q0692-answer

**it-Q0693** — Sei sicura che Tom non si ricorderà nulla?

Are you sure Tom won't remember anything?

Expected form: **si**

Why: Reflexive and impersonal si. [[Italian#^it-Q0693|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Sei%20sicura%20che%20Tom%20non%20si%20ricorder%C3%A0%20nulla%3F)
^it-Q0693-answer

**it-Q0694** — Sei sicura che Tom non si ricorderà nulla?

Are you sure Tom won't remember anything?

Why: Reflexive and impersonal si. [[Italian#^it-Q0694|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Sei%20sicura%20che%20Tom%20non%20si%20ricorder%C3%A0%20nulla%3F)
^it-Q0694-answer

**it-Q0695** — Tom si avvicina.

Tom approaches.

Why: Reflexive and impersonal si. [[Italian#^it-Q0695|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20si%20avvicina.)
^it-Q0695-answer

**it-Q0696** — Tom si avvicina.

Tom approaches.

Si can mark a reflexive action, a passive-like construction or an impersonal statement. Its meaning and agreement depend on the verb and noun phrase; it does not always mean oneself.

Why: Reflexive and impersonal si. [[Italian#^it-Q0696|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20si%20avvicina.)
^it-Q0696-answer

**it-Q0697** — Si è sposata all'età di 25 anni.

She got married at the age of 25.

Expected form: **Si**

Why: Reflexive and impersonal si. [[Italian#^it-Q0697|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Si%20%C3%A8%20sposata%20all%27et%C3%A0%20di%2025%20anni.)
^it-Q0697-answer

**it-Q0698** — Si è sposata all'età di 25 anni.

She got married at the age of 25.

Expected form: **Si**

Why: Reflexive and impersonal si. [[Italian#^it-Q0698|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Si%20%C3%A8%20sposata%20all%27et%C3%A0%20di%2025%20anni.)
^it-Q0698-answer

**it-Q0699** — Alcuni ragazzi a scuola si prendono gioco di me.

Some boys at school make fun of me.

Expected form: **si**

Why: Reflexive and impersonal si. [[Italian#^it-Q0699|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Alcuni%20ragazzi%20a%20scuola%20si%20prendono%20gioco%20di%20me.)
^it-Q0699-answer

**it-Q0700** — Alcuni ragazzi a scuola si prendono gioco di me.

Some boys at school make fun of me.

Why: Reflexive and impersonal si. [[Italian#^it-Q0700|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Alcuni%20ragazzi%20a%20scuola%20si%20prendono%20gioco%20di%20me.)
^it-Q0700-answer


### Answers 701–750

**it-Q0701** — Ascoltate bene quello che dico.

Listen well to what I say.

Why: Relative clauses. [[Italian#^it-Q0701|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Ascoltate%20bene%20quello%20che%20dico.)
^it-Q0701-answer

**it-Q0702** — Ascoltate bene quello che dico.

Listen well to what I say.

Che commonly serves as relative subject or direct object. Cui commonly follows a preposition. Che also introduces complement clauses, so determine the connection rather than naming the form alone.

Why: Relative clauses. [[Italian#^it-Q0702|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Ascoltate%20bene%20quello%20che%20dico.)
^it-Q0702-answer

**it-Q0703** — Pensa che Tom stia ancora dormendo?

Do you think Tom is still asleep?

Expected form: **che**

Why: Relative clauses. [[Italian#^it-Q0703|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Pensa%20che%20Tom%20stia%20ancora%20dormendo%3F)
^it-Q0703-answer

**it-Q0704** — Pensa che Tom stia ancora dormendo?

Do you think Tom is still asleep?

Expected form: **che**

Why: Relative clauses. [[Italian#^it-Q0704|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Pensa%20che%20Tom%20stia%20ancora%20dormendo%3F)
^it-Q0704-answer

**it-Q0705** — Tom e Mary dissero che non volevano più studiare il francese.

Tom and Mary said they didn't want to study French anymore.

Expected form: **che**

Why: Relative clauses. [[Italian#^it-Q0705|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20e%20Mary%20dissero%20che%20non%20volevano%20pi%C3%B9%20studiare%20il%20francese.)
^it-Q0705-answer

**it-Q0706** — Tom e Mary dissero che non volevano più studiare il francese.

Tom and Mary said they didn't want to study French anymore.

Why: Relative clauses. [[Italian#^it-Q0706|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20e%20Mary%20dissero%20che%20non%20volevano%20pi%C3%B9%20studiare%20il%20francese.)
^it-Q0706-answer

**it-Q0707** — Attenta a quello che desidera.

Be careful what you wish for.

Why: Relative clauses. [[Italian#^it-Q0707|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Attenta%20a%20quello%20che%20desidera.)
^it-Q0707-answer

**it-Q0708** — Attenta a quello che desidera.

Be careful what you wish for.

Che commonly serves as relative subject or direct object. Cui commonly follows a preposition. Che also introduces complement clauses, so determine the connection rather than naming the form alone.

Why: Relative clauses. [[Italian#^it-Q0708|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Attenta%20a%20quello%20che%20desidera.)
^it-Q0708-answer

**it-Q0709** — Io odio i passeggeri che criticano il guidatore.

I hate backseat drivers.

Expected form: **che**

Why: Relative clauses. [[Italian#^it-Q0709|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Io%20odio%20i%20passeggeri%20che%20criticano%20il%20guidatore.)
^it-Q0709-answer

**it-Q0710** — Io odio i passeggeri che criticano il guidatore.

I hate backseat drivers.

Expected form: **che**

Why: Relative clauses. [[Italian#^it-Q0710|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Io%20odio%20i%20passeggeri%20che%20criticano%20il%20guidatore.)
^it-Q0710-answer

**it-Q0711** — Dove va per Natale?

Where do you go for Christmas?

Expected form: **Dove**

Why: Relative clauses. [[Italian#^it-Q0711|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Dove%20va%20per%20Natale%3F)
^it-Q0711-answer

**it-Q0712** — Dove va per Natale?

Where do you go for Christmas?

Why: Relative clauses. [[Italian#^it-Q0712|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Dove%20va%20per%20Natale%3F)
^it-Q0712-answer

**it-Q0713** — Mantieni ad ogni costo una mente aperta, ma non così aperta che il tuo cervello caschi fuori.

By all means maintain an open mind, but not so open that your brain falls out.

Why: Relative clauses. [[Italian#^it-Q0713|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Mantieni%20ad%20ogni%20costo%20una%20mente%20aperta%2C%20ma%20non%20cos%C3%AC%20aperta%20che%20il%20tuo%20cervello%20caschi%20fuori.)
^it-Q0713-answer

**it-Q0714** — Mantieni ad ogni costo una mente aperta, ma non così aperta che il tuo cervello caschi fuori.

By all means maintain an open mind, but not so open that your brain falls out.

Che commonly serves as relative subject or direct object. Cui commonly follows a preposition. Che also introduces complement clauses, so determine the connection rather than naming the form alone.

Why: Relative clauses. [[Italian#^it-Q0714|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Mantieni%20ad%20ogni%20costo%20una%20mente%20aperta%2C%20ma%20non%20cos%C3%AC%20aperta%20che%20il%20tuo%20cervello%20caschi%20fuori.)
^it-Q0714-answer

**it-Q0715** — Lo sapeva che ero sposata.

You knew I was married.

Expected form: **che**

Why: Relative clauses. [[Italian#^it-Q0715|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Lo%20sapeva%20che%20ero%20sposata.)
^it-Q0715-answer

**it-Q0716** — Lo sapeva che ero sposata.

You knew I was married.

Expected form: **che**

Why: Relative clauses. [[Italian#^it-Q0716|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Lo%20sapeva%20che%20ero%20sposata.)
^it-Q0716-answer

**it-Q0717** — Dissi a Tom che stavo andando a Boston.

I told Tom I was going to Boston.

Expected form: **che**

Why: Relative clauses. [[Italian#^it-Q0717|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Dissi%20a%20Tom%20che%20stavo%20andando%20a%20Boston.)
^it-Q0717-answer

**it-Q0718** — Dissi a Tom che stavo andando a Boston.

I told Tom I was going to Boston.

Why: Relative clauses. [[Italian#^it-Q0718|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Dissi%20a%20Tom%20che%20stavo%20andando%20a%20Boston.)
^it-Q0718-answer

**it-Q0719** — Non ho niente a che fare con lo scandalo.

I have nothing to do with the scandal.

Why: Relative clauses. [[Italian#^it-Q0719|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20ho%20niente%20a%20che%20fare%20con%20lo%20scandalo.)
^it-Q0719-answer

**it-Q0720** — Non ho niente a che fare con lo scandalo.

I have nothing to do with the scandal.

Che commonly serves as relative subject or direct object. Cui commonly follows a preposition. Che also introduces complement clauses, so determine the connection rather than naming the form alone.

Why: Relative clauses. [[Italian#^it-Q0720|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20ho%20niente%20a%20che%20fare%20con%20lo%20scandalo.)
^it-Q0720-answer

**it-Q0721** — Lo so che potete venire!

I know you can come!

Expected form: **che**

Why: Relative clauses. [[Italian#^it-Q0721|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Lo%20so%20che%20potete%20venire%21)
^it-Q0721-answer

**it-Q0722** — Lo so che potete venire!

I know you can come!

Expected form: **che**

Why: Relative clauses. [[Italian#^it-Q0722|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Lo%20so%20che%20potete%20venire%21)
^it-Q0722-answer

**it-Q0723** — Io penso che Tom stia morendo.

I think Tom is dying.

Expected form: **che**

Why: Relative clauses. [[Italian#^it-Q0723|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Io%20penso%20che%20Tom%20stia%20morendo.)
^it-Q0723-answer

**it-Q0724** — Io penso che Tom stia morendo.

I think Tom is dying.

Why: Relative clauses. [[Italian#^it-Q0724|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Io%20penso%20che%20Tom%20stia%20morendo.)
^it-Q0724-answer

**it-Q0725** — Ho appena sentito che siete andati a trovare Tom.

I just heard you visited Tom.

Why: Relative clauses. [[Italian#^it-Q0725|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Ho%20appena%20sentito%20che%20siete%20andati%20a%20trovare%20Tom.)
^it-Q0725-answer

**it-Q0726** — Ho appena sentito che siete andati a trovare Tom.

I just heard you visited Tom.

Che commonly serves as relative subject or direct object. Cui commonly follows a preposition. Che also introduces complement clauses, so determine the connection rather than naming the form alone.

Why: Relative clauses. [[Italian#^it-Q0726|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Ho%20appena%20sentito%20che%20siete%20andati%20a%20trovare%20Tom.)
^it-Q0726-answer

**it-Q0727** — Quella è la donna che vuole vedervi.

That's the woman who wants to see you.

Expected form: **che**

Why: Relative clauses. [[Italian#^it-Q0727|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Quella%20%C3%A8%20la%20donna%20che%20vuole%20vedervi.)
^it-Q0727-answer

**it-Q0728** — Quella è la donna che vuole vedervi.

That's the woman who wants to see you.

Expected form: **che**

Why: Relative clauses. [[Italian#^it-Q0728|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Quella%20%C3%A8%20la%20donna%20che%20vuole%20vedervi.)
^it-Q0728-answer

**it-Q0729** — Sapeva che la amavo.

He knew that I loved her.

Expected form: **che**

Why: Relative clauses. [[Italian#^it-Q0729|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Sapeva%20che%20la%20amavo.)
^it-Q0729-answer

**it-Q0730** — Sapeva che la amavo.

He knew that I loved her.

Why: Relative clauses. [[Italian#^it-Q0730|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Sapeva%20che%20la%20amavo.)
^it-Q0730-answer

**it-Q0731** — Questo è proprio il libro che volevi.

This is the very book you wanted.

Why: Relative clauses. [[Italian#^it-Q0731|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Questo%20%C3%A8%20proprio%20il%20libro%20che%20volevi.)
^it-Q0731-answer

**it-Q0732** — Questo è proprio il libro che volevi.

This is the very book you wanted.

Che commonly serves as relative subject or direct object. Cui commonly follows a preposition. Che also introduces complement clauses, so determine the connection rather than naming the form alone.

Why: Relative clauses. [[Italian#^it-Q0732|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Questo%20%C3%A8%20proprio%20il%20libro%20che%20volevi.)
^it-Q0732-answer

**it-Q0733** — Lo sapeva che Mesut Özil, il famoso calciatore tedesco, è anche turco?

Did you know that Mesut Özil, the famous German footballer, is also Turkish?

Expected form: **che**

Why: Relative clauses. [[Italian#^it-Q0733|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Lo%20sapeva%20che%20Mesut%20%C3%96zil%2C%20il%20famoso%20calciatore%20tedesco%2C%20%C3%A8%20anche%20turco%3F)
^it-Q0733-answer

**it-Q0734** — Lo sapeva che Mesut Özil, il famoso calciatore tedesco, è anche turco?

Did you know that Mesut Özil, the famous German footballer, is also Turkish?

Expected form: **che**

Why: Relative clauses. [[Italian#^it-Q0734|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Lo%20sapeva%20che%20Mesut%20%C3%96zil%2C%20il%20famoso%20calciatore%20tedesco%2C%20%C3%A8%20anche%20turco%3F)
^it-Q0734-answer

**it-Q0735** — Voi pensate che Tom avesse fame?

Do you think Tom was hungry?

Expected form: **che**

Why: Relative clauses. [[Italian#^it-Q0735|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Voi%20pensate%20che%20Tom%20avesse%20fame%3F)
^it-Q0735-answer

**it-Q0736** — Voi pensate che Tom avesse fame?

Do you think Tom was hungry?

Why: Relative clauses. [[Italian#^it-Q0736|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Voi%20pensate%20che%20Tom%20avesse%20fame%3F)
^it-Q0736-answer

**it-Q0737** — Tutto quello che sta succedendo è colpa di Tom.

Everything that's happening is Tom's fault.

Why: Relative clauses. [[Italian#^it-Q0737|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tutto%20quello%20che%20sta%20succedendo%20%C3%A8%20colpa%20di%20Tom.)
^it-Q0737-answer

**it-Q0738** — Tutto quello che sta succedendo è colpa di Tom.

Everything that's happening is Tom's fault.

Che commonly serves as relative subject or direct object. Cui commonly follows a preposition. Che also introduces complement clauses, so determine the connection rather than naming the form alone.

Why: Relative clauses. [[Italian#^it-Q0738|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tutto%20quello%20che%20sta%20succedendo%20%C3%A8%20colpa%20di%20Tom.)
^it-Q0738-answer

**it-Q0739** — Dirò a Tom che hai finito il rapporto.

I'll tell Tom you finished the report.

Expected form: **che**

Why: Relative clauses. [[Italian#^it-Q0739|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Dir%C3%B2%20a%20Tom%20che%20hai%20finito%20il%20rapporto.)
^it-Q0739-answer

**it-Q0740** — Dirò a Tom che hai finito il rapporto.

I'll tell Tom you finished the report.

Expected form: **che**

Why: Relative clauses. [[Italian#^it-Q0740|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Dir%C3%B2%20a%20Tom%20che%20hai%20finito%20il%20rapporto.)
^it-Q0740-answer

**it-Q0741** — Dove sei ferita?

Where are you hurt?

Expected form: **Dove**

Why: Relative clauses. [[Italian#^it-Q0741|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Dove%20sei%20ferita%3F)
^it-Q0741-answer

**it-Q0742** — Dove sei ferita?

Where are you hurt?

Why: Relative clauses. [[Italian#^it-Q0742|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Dove%20sei%20ferita%3F)
^it-Q0742-answer

**it-Q0743** — Tutto quello che deve fare è seguire il suo consiglio.

All that you have to do is to follow his advice.

Why: Relative clauses. [[Italian#^it-Q0743|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tutto%20quello%20che%20deve%20fare%20%C3%A8%20seguire%20il%20suo%20consiglio.)
^it-Q0743-answer

**it-Q0744** — Tutto quello che deve fare è seguire il suo consiglio.

All that you have to do is to follow his advice.

Che commonly serves as relative subject or direct object. Cui commonly follows a preposition. Che also introduces complement clauses, so determine the connection rather than naming the form alone.

Why: Relative clauses. [[Italian#^it-Q0744|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tutto%20quello%20che%20deve%20fare%20%C3%A8%20seguire%20il%20suo%20consiglio.)
^it-Q0744-answer

**it-Q0745** — Lei cosa pensa che stia causando questo problema?

What do you think's causing this problem?

Expected form: **che**

Why: Relative clauses. [[Italian#^it-Q0745|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Lei%20cosa%20pensa%20che%20stia%20causando%20questo%20problema%3F)
^it-Q0745-answer

**it-Q0746** — Lei cosa pensa che stia causando questo problema?

What do you think's causing this problem?

Expected form: **che**

Why: Relative clauses. [[Italian#^it-Q0746|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Lei%20cosa%20pensa%20che%20stia%20causando%20questo%20problema%3F)
^it-Q0746-answer

**it-Q0747** — Tom non pensa che io lo debba fare.

Tom doesn't think I need to do that.

Expected form: **che**

Why: Relative clauses. [[Italian#^it-Q0747|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20non%20pensa%20che%20io%20lo%20debba%20fare.)
^it-Q0747-answer

**it-Q0748** — Tom non pensa che io lo debba fare.

Tom doesn't think I need to do that.

Why: Relative clauses. [[Italian#^it-Q0748|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20non%20pensa%20che%20io%20lo%20debba%20fare.)
^it-Q0748-answer

**it-Q0749** — Sembra che Tom non sappia la risposta.

Tom doesn't seem to know the answer.

Why: Relative clauses. [[Italian#^it-Q0749|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Sembra%20che%20Tom%20non%20sappia%20la%20risposta.)
^it-Q0749-answer

**it-Q0750** — Sembra che Tom non sappia la risposta.

Tom doesn't seem to know the answer.

Che commonly serves as relative subject or direct object. Cui commonly follows a preposition. Che also introduces complement clauses, so determine the connection rather than naming the form alone.

Why: Relative clauses. [[Italian#^it-Q0750|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Sembra%20che%20Tom%20non%20sappia%20la%20risposta.)
^it-Q0750-answer


### Answers 751–800

**it-Q0751** — Io non devo seguire Tom.

I don't have to follow Tom.

Expected form: **non**

Why: Negation. [[Italian#^it-Q0751|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Io%20non%20devo%20seguire%20Tom.)
^it-Q0751-answer

**it-Q0752** — Io non devo seguire Tom.

I don't have to follow Tom.

Expected form: **non**

Why: Negation. [[Italian#^it-Q0752|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Io%20non%20devo%20seguire%20Tom.)
^it-Q0752-answer

**it-Q0753** — Non voglio sedermi accanto a loro.

I don't want to sit next to them.

Expected form: **Non**

Why: Negation. [[Italian#^it-Q0753|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20voglio%20sedermi%20accanto%20a%20loro.)
^it-Q0753-answer

**it-Q0754** — Non voglio sedermi accanto a loro.

I don't want to sit next to them.

Why: Negation. [[Italian#^it-Q0754|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20voglio%20sedermi%20accanto%20a%20loro.)
^it-Q0754-answer

**it-Q0755** — Dice di non essere pigra.

She says she isn't lazy.

Why: Negation. [[Italian#^it-Q0755|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Dice%20di%20non%20essere%20pigra.)
^it-Q0755-answer

**it-Q0756** — Dice di non essere pigra.

She says she isn't lazy.

Non usually precedes the finite verb. Negative words can combine with non when they follow the verb. Their order affects whether a separate non is needed.

Why: Negation. [[Italian#^it-Q0756|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Dice%20di%20non%20essere%20pigra.)
^it-Q0756-answer

**it-Q0757** — Non può permetterselo.

She can't afford it.

Expected form: **Non**

Why: Negation. [[Italian#^it-Q0757|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20pu%C3%B2%20permetterselo.)
^it-Q0757-answer

**it-Q0758** — Non può permetterselo.

She can't afford it.

Expected form: **Non**

Why: Negation. [[Italian#^it-Q0758|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20pu%C3%B2%20permetterselo.)
^it-Q0758-answer

**it-Q0759** — Non leggete in questa stanza.

Don't read in this room.

Expected form: **Non**

Why: Negation. [[Italian#^it-Q0759|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20leggete%20in%20questa%20stanza.)
^it-Q0759-answer

**it-Q0760** — Non leggete in questa stanza.

Don't read in this room.

Why: Negation. [[Italian#^it-Q0760|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20leggete%20in%20questa%20stanza.)
^it-Q0760-answer

**it-Q0761** — Non chiesi a Tom di cantare.

I didn't ask Tom to sing.

Why: Negation. [[Italian#^it-Q0761|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20chiesi%20a%20Tom%20di%20cantare.)
^it-Q0761-answer

**it-Q0762** — Non chiesi a Tom di cantare.

I didn't ask Tom to sing.

Non usually precedes the finite verb. Negative words can combine with non when they follow the verb. Their order affects whether a separate non is needed.

Why: Negation. [[Italian#^it-Q0762|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20chiesi%20a%20Tom%20di%20cantare.)
^it-Q0762-answer

**it-Q0763** — Non posso abbracciare Tom se lui non vuole essere abbracciato.

I can't hug Tom if he doesn't want to be hugged.

Expected form: **Non**

Why: Negation. [[Italian#^it-Q0763|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20posso%20abbracciare%20Tom%20se%20lui%20non%20vuole%20essere%20abbracciato.)
^it-Q0763-answer

**it-Q0764** — Non posso abbracciare Tom se lui non vuole essere abbracciato.

I can't hug Tom if he doesn't want to be hugged.

Expected form: **Non**

Why: Negation. [[Italian#^it-Q0764|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20posso%20abbracciare%20Tom%20se%20lui%20non%20vuole%20essere%20abbracciato.)
^it-Q0764-answer

**it-Q0765** — Non posso finire questo oggi.

I can't finish this today.

Expected form: **Non**

Why: Negation. [[Italian#^it-Q0765|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20posso%20finire%20questo%20oggi.)
^it-Q0765-answer

**it-Q0766** — Non posso finire questo oggi.

I can't finish this today.

Why: Negation. [[Italian#^it-Q0766|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20posso%20finire%20questo%20oggi.)
^it-Q0766-answer

**it-Q0767** — Non avevamo bisogno di alcun aiuto.

We didn't need any help.

Why: Negation. [[Italian#^it-Q0767|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20avevamo%20bisogno%20di%20alcun%20aiuto.)
^it-Q0767-answer

**it-Q0768** — Non avevamo bisogno di alcun aiuto.

We didn't need any help.

Non usually precedes the finite verb. Negative words can combine with non when they follow the verb. Their order affects whether a separate non is needed.

Why: Negation. [[Italian#^it-Q0768|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20avevamo%20bisogno%20di%20alcun%20aiuto.)
^it-Q0768-answer

**it-Q0769** — Non so cosa scrivere in questa frase.

I don't know what to write in this sentence.

Expected form: **Non**

Why: Negation. [[Italian#^it-Q0769|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20so%20cosa%20scrivere%20in%20questa%20frase.)
^it-Q0769-answer

**it-Q0770** — Non so cosa scrivere in questa frase.

I don't know what to write in this sentence.

Expected form: **Non**

Why: Negation. [[Italian#^it-Q0770|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20so%20cosa%20scrivere%20in%20questa%20frase.)
^it-Q0770-answer

**it-Q0771** — Tom non comprerà quella macchina.

Tom won't buy that car.

Expected form: **non**

Why: Negation. [[Italian#^it-Q0771|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20non%20comprer%C3%A0%20quella%20macchina.)
^it-Q0771-answer

**it-Q0772** — Tom non comprerà quella macchina.

Tom won't buy that car.

Why: Negation. [[Italian#^it-Q0772|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20non%20comprer%C3%A0%20quella%20macchina.)
^it-Q0772-answer

**it-Q0773** — Io non posso farlo immediatamente.

I can't do it right away.

Why: Negation. [[Italian#^it-Q0773|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Io%20non%20posso%20farlo%20immediatamente.)
^it-Q0773-answer

**it-Q0774** — Io non posso farlo immediatamente.

I can't do it right away.

Non usually precedes the finite verb. Negative words can combine with non when they follow the verb. Their order affects whether a separate non is needed.

Why: Negation. [[Italian#^it-Q0774|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Io%20non%20posso%20farlo%20immediatamente.)
^it-Q0774-answer

**it-Q0775** — Non andare da nessuna parte senza Tom.

Don't go anywhere without Tom.

Expected form: **Non**

Why: Negation. [[Italian#^it-Q0775|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20andare%20da%20nessuna%20parte%20senza%20Tom.)
^it-Q0775-answer

**it-Q0776** — Non andare da nessuna parte senza Tom.

Don't go anywhere without Tom.

Expected form: **Non**

Why: Negation. [[Italian#^it-Q0776|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20andare%20da%20nessuna%20parte%20senza%20Tom.)
^it-Q0776-answer

**it-Q0777** — Non è in grado di capirlo.

He isn't able to understand it.

Expected form: **Non**

Why: Negation. [[Italian#^it-Q0777|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20%C3%A8%20in%20grado%20di%20capirlo.)
^it-Q0777-answer

**it-Q0778** — Non è in grado di capirlo.

He isn't able to understand it.

Why: Negation. [[Italian#^it-Q0778|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20%C3%A8%20in%20grado%20di%20capirlo.)
^it-Q0778-answer

**it-Q0779** — Perché non sta capitando ora?

Why isn't that happening now?

Why: Negation. [[Italian#^it-Q0779|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Perch%C3%A9%20non%20sta%20capitando%20ora%3F)
^it-Q0779-answer

**it-Q0780** — Perché non sta capitando ora?

Why isn't that happening now?

Non usually precedes the finite verb. Negative words can combine with non when they follow the verb. Their order affects whether a separate non is needed.

Why: Negation. [[Italian#^it-Q0780|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Perch%C3%A9%20non%20sta%20capitando%20ora%3F)
^it-Q0780-answer

**it-Q0781** — Tom non disse a Mary il suo vero nome.

Tom didn't tell Mary his real name.

Expected form: **non**

Why: Negation. [[Italian#^it-Q0781|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20non%20disse%20a%20Mary%20il%20suo%20vero%20nome.)
^it-Q0781-answer

**it-Q0782** — Tom non disse a Mary il suo vero nome.

Tom didn't tell Mary his real name.

Expected form: **non**

Why: Negation. [[Italian#^it-Q0782|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20non%20disse%20a%20Mary%20il%20suo%20vero%20nome.)
^it-Q0782-answer

**it-Q0783** — Tom non è cambiato.

Tom hasn't changed.

Expected form: **non**

Why: Negation. [[Italian#^it-Q0783|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20non%20%C3%A8%20cambiato.)
^it-Q0783-answer

**it-Q0784** — Tom non è cambiato.

Tom hasn't changed.

Why: Negation. [[Italian#^it-Q0784|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20non%20%C3%A8%20cambiato.)
^it-Q0784-answer

**it-Q0785** — Non riesco a farlo.

I can't do it.

Why: Negation. [[Italian#^it-Q0785|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20riesco%20a%20farlo.)
^it-Q0785-answer

**it-Q0786** — Non riesco a farlo.

I can't do it.

Non usually precedes the finite verb. Negative words can combine with non when they follow the verb. Their order affects whether a separate non is needed.

Why: Negation. [[Italian#^it-Q0786|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20riesco%20a%20farlo.)
^it-Q0786-answer

**it-Q0787** — Tom non legge libri in francese.

Tom doesn't read books in French.

Expected form: **non**

Why: Negation. [[Italian#^it-Q0787|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20non%20legge%20libri%20in%20francese.)
^it-Q0787-answer

**it-Q0788** — Tom non legge libri in francese.

Tom doesn't read books in French.

Expected form: **non**

Why: Negation. [[Italian#^it-Q0788|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20non%20legge%20libri%20in%20francese.)
^it-Q0788-answer

**it-Q0789** — Non riesco a raggiungerla.

I can't reach it.

Expected form: **Non**

Why: Negation. [[Italian#^it-Q0789|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20riesco%20a%20raggiungerla.)
^it-Q0789-answer

**it-Q0790** — Non riesco a raggiungerla.

I can't reach it.

Why: Negation. [[Italian#^it-Q0790|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20riesco%20a%20raggiungerla.)
^it-Q0790-answer

**it-Q0791** — Lui non è stupido come sembra.

He isn't as stupid as he looks.

Why: Negation. [[Italian#^it-Q0791|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Lui%20non%20%C3%A8%20stupido%20come%20sembra.)
^it-Q0791-answer

**it-Q0792** — Lui non è stupido come sembra.

He isn't as stupid as he looks.

Non usually precedes the finite verb. Negative words can combine with non when they follow the verb. Their order affects whether a separate non is needed.

Why: Negation. [[Italian#^it-Q0792|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Lui%20non%20%C3%A8%20stupido%20come%20sembra.)
^it-Q0792-answer

**it-Q0793** — Non ho una casa.

I don't have a home.

Expected form: **Non**

Why: Negation. [[Italian#^it-Q0793|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20ho%20una%20casa.)
^it-Q0793-answer

**it-Q0794** — Non ho una casa.

I don't have a home.

Expected form: **Non**

Why: Negation. [[Italian#^it-Q0794|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20ho%20una%20casa.)
^it-Q0794-answer

**it-Q0795** — Non vado mai a fare acquisti il sabato.

I never go shopping on Saturdays.

Expected form: **Non**

Why: Negation. [[Italian#^it-Q0795|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20vado%20mai%20a%20fare%20acquisti%20il%20sabato.)
^it-Q0795-answer

**it-Q0796** — Non vado mai a fare acquisti il sabato.

I never go shopping on Saturdays.

Why: Negation. [[Italian#^it-Q0796|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20vado%20mai%20a%20fare%20acquisti%20il%20sabato.)
^it-Q0796-answer

**it-Q0797** — Non voglio umiliarlo.

I don't want to humiliate him.

Why: Negation. [[Italian#^it-Q0797|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20voglio%20umiliarlo.)
^it-Q0797-answer

**it-Q0798** — Non voglio umiliarlo.

I don't want to humiliate him.

Non usually precedes the finite verb. Negative words can combine with non when they follow the verb. Their order affects whether a separate non is needed.

Why: Negation. [[Italian#^it-Q0798|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20voglio%20umiliarlo.)
^it-Q0798-answer

**it-Q0799** — Tom non ha sentito il terremoto.

Tom didn't feel the earthquake.

Expected form: **non**

Why: Negation. [[Italian#^it-Q0799|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20non%20ha%20sentito%20il%20terremoto.)
^it-Q0799-answer

**it-Q0800** — Tom non ha sentito il terremoto.

Tom didn't feel the earthquake.

Expected form: **non**

Why: Negation. [[Italian#^it-Q0800|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20non%20ha%20sentito%20il%20terremoto.)
^it-Q0800-answer


### Answers 801–850

**it-Q0801** — Perché state facendo delle foto?

Why are you taking pictures?

Expected form: **Perché**

Why: Questions. [[Italian#^it-Q0801|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Perch%C3%A9%20state%20facendo%20delle%20foto%3F)
^it-Q0801-answer

**it-Q0802** — Perché state facendo delle foto?

Why are you taking pictures?

Why: Questions. [[Italian#^it-Q0802|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Perch%C3%A9%20state%20facendo%20delle%20foto%3F)
^it-Q0802-answer

**it-Q0803** — Capisci come funziona?

Do you understand how it works?

Why: Questions. [[Italian#^it-Q0803|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Capisci%20come%20funziona%3F)
^it-Q0803-answer

**it-Q0804** — Capisci come funziona?

Do you understand how it works?

Question words specify the missing information. Italian often keeps statement-like word order and uses intonation; a question word is not a command to add an English-style auxiliary.

Why: Questions. [[Italian#^it-Q0804|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Capisci%20come%20funziona%3F)
^it-Q0804-answer

**it-Q0805** — Chi è già qui?

Is anyone here yet?

Expected form: **Chi**

Why: Questions. [[Italian#^it-Q0805|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Chi%20%C3%A8%20gi%C3%A0%20qui%3F)
^it-Q0805-answer

**it-Q0806** — Chi è già qui?

Is anyone here yet?

Expected form: **Chi**

Why: Questions. [[Italian#^it-Q0806|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Chi%20%C3%A8%20gi%C3%A0%20qui%3F)
^it-Q0806-answer

**it-Q0807** — Chi altro ha intenzione di invitare?

Who else do you plan to invite?

Expected form: **Chi**

Why: Questions. [[Italian#^it-Q0807|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Chi%20altro%20ha%20intenzione%20di%20invitare%3F)
^it-Q0807-answer

**it-Q0808** — Chi altro ha intenzione di invitare?

Who else do you plan to invite?

Why: Questions. [[Italian#^it-Q0808|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Chi%20altro%20ha%20intenzione%20di%20invitare%3F)
^it-Q0808-answer

**it-Q0809** — Quanto devo restare?

How long do I have to stay?

Why: Questions. [[Italian#^it-Q0809|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Quanto%20devo%20restare%3F)
^it-Q0809-answer

**it-Q0810** — Quanto devo restare?

How long do I have to stay?

Question words specify the missing information. Italian often keeps statement-like word order and uses intonation; a question word is not a command to add an English-style auxiliary.

Why: Questions. [[Italian#^it-Q0810|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Quanto%20devo%20restare%3F)
^it-Q0810-answer

**it-Q0811** — Perché non devi farlo?

Why don't you have to do that?

Expected form: **Perché**

Why: Questions. [[Italian#^it-Q0811|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Perch%C3%A9%20non%20devi%20farlo%3F)
^it-Q0811-answer

**it-Q0812** — Perché non devi farlo?

Why don't you have to do that?

Expected form: **Perché**

Why: Questions. [[Italian#^it-Q0812|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Perch%C3%A9%20non%20devi%20farlo%3F)
^it-Q0812-answer

**it-Q0813** — Perché non sei tornato per lui?

Why didn't you go back for him?

Expected form: **Perché**

Why: Questions. [[Italian#^it-Q0813|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Perch%C3%A9%20non%20sei%20tornato%20per%20lui%3F)
^it-Q0813-answer

**it-Q0814** — Perché non sei tornato per lui?

Why didn't you go back for him?

Why: Questions. [[Italian#^it-Q0814|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Perch%C3%A9%20non%20sei%20tornato%20per%20lui%3F)
^it-Q0814-answer

**it-Q0815** — Io ho abbattuto la porta perché ho perso la chiave.

I broke down the door because I lost the key.

Why: Questions. [[Italian#^it-Q0815|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Io%20ho%20abbattuto%20la%20porta%20perch%C3%A9%20ho%20perso%20la%20chiave.)
^it-Q0815-answer

**it-Q0816** — Io ho abbattuto la porta perché ho perso la chiave.

I broke down the door because I lost the key.

Question words specify the missing information. Italian often keeps statement-like word order and uses intonation; a question word is not a command to add an English-style auxiliary.

Why: Questions. [[Italian#^it-Q0816|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Io%20ho%20abbattuto%20la%20porta%20perch%C3%A9%20ho%20perso%20la%20chiave.)
^it-Q0816-answer

**it-Q0817** — Perché non è preparata?

Why aren't you prepared?

Expected form: **Perché**

Why: Questions. [[Italian#^it-Q0817|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Perch%C3%A9%20non%20%C3%A8%20preparata%3F)
^it-Q0817-answer

**it-Q0818** — Perché non è preparata?

Why aren't you prepared?

Expected form: **Perché**

Why: Questions. [[Italian#^it-Q0818|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Perch%C3%A9%20non%20%C3%A8%20preparata%3F)
^it-Q0818-answer

**it-Q0819** — Chi altro lo sa?

Who else knows?

Expected form: **Chi**

Why: Questions. [[Italian#^it-Q0819|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Chi%20altro%20lo%20sa%3F)
^it-Q0819-answer

**it-Q0820** — Chi altro lo sa?

Who else knows?

Why: Questions. [[Italian#^it-Q0820|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Chi%20altro%20lo%20sa%3F)
^it-Q0820-answer

**it-Q0821** — Chi è il suo insegnante francese?

Who's your French teacher?

Why: Questions. [[Italian#^it-Q0821|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Chi%20%C3%A8%20il%20suo%20insegnante%20francese%3F)
^it-Q0821-answer

**it-Q0822** — Chi è il suo insegnante francese?

Who's your French teacher?

Question words specify the missing information. Italian often keeps statement-like word order and uses intonation; a question word is not a command to add an English-style auxiliary.

Why: Questions. [[Italian#^it-Q0822|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Chi%20%C3%A8%20il%20suo%20insegnante%20francese%3F)
^it-Q0822-answer

**it-Q0823** — Perché dovrei darvi questo?

Why should I give this to you?

Expected form: **Perché**

Why: Questions. [[Italian#^it-Q0823|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Perch%C3%A9%20dovrei%20darvi%20questo%3F)
^it-Q0823-answer

**it-Q0824** — Perché dovrei darvi questo?

Why should I give this to you?

Expected form: **Perché**

Why: Questions. [[Italian#^it-Q0824|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Perch%C3%A9%20dovrei%20darvi%20questo%3F)
^it-Q0824-answer

**it-Q0825** — Perché dovrei aiutarli?

Why should I help them?

Expected form: **Perché**

Why: Questions. [[Italian#^it-Q0825|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Perch%C3%A9%20dovrei%20aiutarli%3F)
^it-Q0825-answer

**it-Q0826** — Perché dovrei aiutarli?

Why should I help them?

Why: Questions. [[Italian#^it-Q0826|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Perch%C3%A9%20dovrei%20aiutarli%3F)
^it-Q0826-answer

**it-Q0827** — Chi è l'architetto?

Who is the architect?

Why: Questions. [[Italian#^it-Q0827|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Chi%20%C3%A8%20l%27architetto%3F)
^it-Q0827-answer

**it-Q0828** — Chi è l'architetto?

Who is the architect?

Question words specify the missing information. Italian often keeps statement-like word order and uses intonation; a question word is not a command to add an English-style auxiliary.

Why: Questions. [[Italian#^it-Q0828|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Chi%20%C3%A8%20l%27architetto%3F)
^it-Q0828-answer

**it-Q0829** — Come posso fare a finire in tempo?

How can I manage to finish on time?

Expected form: **Come**

Why: Questions. [[Italian#^it-Q0829|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Come%20posso%20fare%20a%20finire%20in%20tempo%3F)
^it-Q0829-answer

**it-Q0830** — Come posso fare a finire in tempo?

How can I manage to finish on time?

Expected form: **Come**

Why: Questions. [[Italian#^it-Q0830|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Come%20posso%20fare%20a%20finire%20in%20tempo%3F)
^it-Q0830-answer

**it-Q0831** — Perché mi ami?

Why do you love me?

Expected form: **Perché**

Why: Questions. [[Italian#^it-Q0831|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Perch%C3%A9%20mi%20ami%3F)
^it-Q0831-answer

**it-Q0832** — Perché mi ami?

Why do you love me?

Why: Questions. [[Italian#^it-Q0832|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Perch%C3%A9%20mi%20ami%3F)
^it-Q0832-answer

**it-Q0833** — Perché Nettuno è blu?

Why is Neptune blue?

Why: Questions. [[Italian#^it-Q0833|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Perch%C3%A9%20Nettuno%20%C3%A8%20blu%3F)
^it-Q0833-answer

**it-Q0834** — Perché Nettuno è blu?

Why is Neptune blue?

Question words specify the missing information. Italian often keeps statement-like word order and uses intonation; a question word is not a command to add an English-style auxiliary.

Why: Questions. [[Italian#^it-Q0834|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Perch%C3%A9%20Nettuno%20%C3%A8%20blu%3F)
^it-Q0834-answer

**it-Q0835** — Perché stavate urlando?

Why were you yelling?

Expected form: **Perché**

Why: Questions. [[Italian#^it-Q0835|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Perch%C3%A9%20stavate%20urlando%3F)
^it-Q0835-answer

**it-Q0836** — Perché stavate urlando?

Why were you yelling?

Expected form: **Perché**

Why: Questions. [[Italian#^it-Q0836|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Perch%C3%A9%20stavate%20urlando%3F)
^it-Q0836-answer

**it-Q0837** — Chi è l'amministratore?

Who is the manager?

Expected form: **Chi**

Why: Questions. [[Italian#^it-Q0837|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Chi%20%C3%A8%20l%27amministratore%3F)
^it-Q0837-answer

**it-Q0838** — Chi è l'amministratore?

Who is the manager?

Why: Questions. [[Italian#^it-Q0838|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Chi%20%C3%A8%20l%27amministratore%3F)
^it-Q0838-answer

**it-Q0839** — Da quanto tempo abitate a Kobe, allora?

How long have you been living in Kobe, then?

Why: Questions. [[Italian#^it-Q0839|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Da%20quanto%20tempo%20abitate%20a%20Kobe%2C%20allora%3F)
^it-Q0839-answer

**it-Q0840** — Da quanto tempo abitate a Kobe, allora?

How long have you been living in Kobe, then?

Question words specify the missing information. Italian often keeps statement-like word order and uses intonation; a question word is not a command to add an English-style auxiliary.

Why: Questions. [[Italian#^it-Q0840|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Da%20quanto%20tempo%20abitate%20a%20Kobe%2C%20allora%3F)
^it-Q0840-answer

**it-Q0841** — Lui sa chi sono.

He knows who I am.

Expected form: **chi**

Why: Questions. [[Italian#^it-Q0841|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Lui%20sa%20chi%20sono.)
^it-Q0841-answer

**it-Q0842** — Lui sa chi sono.

He knows who I am.

Expected form: **chi**

Why: Questions. [[Italian#^it-Q0842|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Lui%20sa%20chi%20sono.)
^it-Q0842-answer

**it-Q0843** — Lui sa come abbattere un albero.

He knows how to fell a tree.

Expected form: **come**

Why: Questions. [[Italian#^it-Q0843|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Lui%20sa%20come%20abbattere%20un%20albero.)
^it-Q0843-answer

**it-Q0844** — Lui sa come abbattere un albero.

He knows how to fell a tree.

Why: Questions. [[Italian#^it-Q0844|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Lui%20sa%20come%20abbattere%20un%20albero.)
^it-Q0844-answer

**it-Q0845** — Non importa quanto sono stanco, devo lavorare.

No matter how tired I might be, I have to work.

Why: Questions. [[Italian#^it-Q0845|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20importa%20quanto%20sono%20stanco%2C%20devo%20lavorare.)
^it-Q0845-answer

**it-Q0846** — Non importa quanto sono stanco, devo lavorare.

No matter how tired I might be, I have to work.

Question words specify the missing information. Italian often keeps statement-like word order and uses intonation; a question word is not a command to add an English-style auxiliary.

Why: Questions. [[Italian#^it-Q0846|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20importa%20quanto%20sono%20stanco%2C%20devo%20lavorare.)
^it-Q0846-answer

**it-Q0847** — Tu dove hai imparato a guidare?

Where did you learn to drive?

Expected form: **dove**

Why: Questions. [[Italian#^it-Q0847|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tu%20dove%20hai%20imparato%20a%20guidare%3F)
^it-Q0847-answer

**it-Q0848** — Tu dove hai imparato a guidare?

Where did you learn to drive?

Expected form: **dove**

Why: Questions. [[Italian#^it-Q0848|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tu%20dove%20hai%20imparato%20a%20guidare%3F)
^it-Q0848-answer

**it-Q0849** — Dove avete preso quell'acqua?

Where did you get that water?

Expected form: **Dove**

Why: Questions. [[Italian#^it-Q0849|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Dove%20avete%20preso%20quell%27acqua%3F)
^it-Q0849-answer

**it-Q0850** — Dove avete preso quell'acqua?

Where did you get that water?

Why: Questions. [[Italian#^it-Q0850|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Dove%20avete%20preso%20quell%27acqua%3F)
^it-Q0850-answer


### Answers 851–900

**it-Q0851** — Scrisse la lettera a se stessa.

She wrote a letter to herself.

Why: Conditions. [[Italian#^it-Q0851|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Scrisse%20la%20lettera%20a%20se%20stessa.)
^it-Q0851-answer

**it-Q0852** — Scrisse la lettera a se stessa.

She wrote a letter to herself.

Se introduces if or indirect whether. Unreal present conditions commonly combine imperfect subjunctive with conditional. Unreal past conditions use pluperfect subjunctive and past conditional.

Why: Conditions. [[Italian#^it-Q0852|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Scrisse%20la%20lettera%20a%20se%20stessa.)
^it-Q0852-answer

**it-Q0853** — Io non mi sveglierò neanche se suona la sveglia.

I won't wake up even if the alarm rings.

Expected form: **se**

Why: Conditions. [[Italian#^it-Q0853|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Io%20non%20mi%20sveglier%C3%B2%20neanche%20se%20suona%20la%20sveglia.)
^it-Q0853-answer

**it-Q0854** — Io non mi sveglierò neanche se suona la sveglia.

I won't wake up even if the alarm rings.

Expected form: **se**

Why: Conditions. [[Italian#^it-Q0854|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Io%20non%20mi%20sveglier%C3%B2%20neanche%20se%20suona%20la%20sveglia.)
^it-Q0854-answer

**it-Q0855** — Pharamp augura una buona notte a Trang anche se sa che lei non è a letto a quest'ora.

Pharamp wishes Trang good night even though she knows that she is not in bed at this hour.

Expected form: **se**

Why: Conditions. [[Italian#^it-Q0855|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Pharamp%20augura%20una%20buona%20notte%20a%20Trang%20anche%20se%20sa%20che%20lei%20non%20%C3%A8%20a%20letto%20a%20quest%27ora.)
^it-Q0855-answer

**it-Q0856** — Pharamp augura una buona notte a Trang anche se sa che lei non è a letto a quest'ora.

Pharamp wishes Trang good night even though she knows that she is not in bed at this hour.

Why: Conditions. [[Italian#^it-Q0856|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Pharamp%20augura%20una%20buona%20notte%20a%20Trang%20anche%20se%20sa%20che%20lei%20non%20%C3%A8%20a%20letto%20a%20quest%27ora.)
^it-Q0856-answer

**it-Q0857** — Se avessi le ali, volerei verso di voi.

If I had wings, I would fly to you.

Why: Conditions. [[Italian#^it-Q0857|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Se%20avessi%20le%20ali%2C%20volerei%20verso%20di%20voi.)
^it-Q0857-answer

**it-Q0858** — Se avessi le ali, volerei verso di voi.

If I had wings, I would fly to you.

Se introduces if or indirect whether. Unreal present conditions commonly combine imperfect subjunctive with conditional. Unreal past conditions use pluperfect subjunctive and past conditional.

Why: Conditions. [[Italian#^it-Q0858|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Se%20avessi%20le%20ali%2C%20volerei%20verso%20di%20voi.)
^it-Q0858-answer

**it-Q0859** — Io mi chiedo se esista davvero Babbo Natale.

I wonder if there really is a Santa Claus.

Expected form: **se**

Why: Conditions. [[Italian#^it-Q0859|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Io%20mi%20chiedo%20se%20esista%20davvero%20Babbo%20Natale.)
^it-Q0859-answer

**it-Q0860** — Io mi chiedo se esista davvero Babbo Natale.

I wonder if there really is a Santa Claus.

Expected form: **se**

Why: Conditions. [[Italian#^it-Q0860|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Io%20mi%20chiedo%20se%20esista%20davvero%20Babbo%20Natale.)
^it-Q0860-answer

**it-Q0861** — Si ucciderà se non vede suo figlio.

He will kill himself if he doesn't see his child.

Expected form: **se**

Why: Conditions. [[Italian#^it-Q0861|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Si%20uccider%C3%A0%20se%20non%20vede%20suo%20figlio.)
^it-Q0861-answer

**it-Q0862** — Si ucciderà se non vede suo figlio.

He will kill himself if he doesn't see his child.

Why: Conditions. [[Italian#^it-Q0862|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Si%20uccider%C3%A0%20se%20non%20vede%20suo%20figlio.)
^it-Q0862-answer

**it-Q0863** — Ciò che mi infastidisce è che anche se obietto, lei insiste per comprarla.

What annoys me is that, although I object, she insists on buying it.

Why: Conditions. [[Italian#^it-Q0863|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Ci%C3%B2%20che%20mi%20infastidisce%20%C3%A8%20che%20anche%20se%20obietto%2C%20lei%20insiste%20per%20comprarla.)
^it-Q0863-answer

**it-Q0864** — Ciò che mi infastidisce è che anche se obietto, lei insiste per comprarla.

What annoys me is that, although I object, she insists on buying it.

Se introduces if or indirect whether. Unreal present conditions commonly combine imperfect subjunctive with conditional. Unreal past conditions use pluperfect subjunctive and past conditional.

Why: Conditions. [[Italian#^it-Q0864|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Ci%C3%B2%20che%20mi%20infastidisce%20%C3%A8%20che%20anche%20se%20obietto%2C%20lei%20insiste%20per%20comprarla.)
^it-Q0864-answer

**it-Q0865** — Verrà se lo chiama.

He will come if you call him.

Expected form: **se**

Why: Conditions. [[Italian#^it-Q0865|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Verr%C3%A0%20se%20lo%20chiama.)
^it-Q0865-answer

**it-Q0866** — Verrà se lo chiama.

He will come if you call him.

Expected form: **se**

Why: Conditions. [[Italian#^it-Q0866|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Verr%C3%A0%20se%20lo%20chiama.)
^it-Q0866-answer

**it-Q0867** — Non serve a nulla confessare i vostri peccati al prete se non pensate due volte prima di ripeterli.

It's no use confessing your sins to the priest if you don't think twice before repeating them.

Expected form: **se**

Why: Conditions. [[Italian#^it-Q0867|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20serve%20a%20nulla%20confessare%20i%20vostri%20peccati%20al%20prete%20se%20non%20pensate%20due%20volte%20prima%20di%20ripeterli.)
^it-Q0867-answer

**it-Q0868** — Non serve a nulla confessare i vostri peccati al prete se non pensate due volte prima di ripeterli.

It's no use confessing your sins to the priest if you don't think twice before repeating them.

Why: Conditions. [[Italian#^it-Q0868|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20serve%20a%20nulla%20confessare%20i%20vostri%20peccati%20al%20prete%20se%20non%20pensate%20due%20volte%20prima%20di%20ripeterli.)
^it-Q0868-answer

**it-Q0869** — Mary sembra molto sicura di se stessa.

Mary seems very sure of herself.

Why: Conditions. [[Italian#^it-Q0869|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Mary%20sembra%20molto%20sicura%20di%20se%20stessa.)
^it-Q0869-answer

**it-Q0870** — Mary sembra molto sicura di se stessa.

Mary seems very sure of herself.

Se introduces if or indirect whether. Unreal present conditions commonly combine imperfect subjunctive with conditional. Unreal past conditions use pluperfect subjunctive and past conditional.

Why: Conditions. [[Italian#^it-Q0870|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Mary%20sembra%20molto%20sicura%20di%20se%20stessa.)
^it-Q0870-answer

**it-Q0871** — Voglio che se ne vada.

I want him to leave.

Expected form: **se**

Why: Conditions. [[Italian#^it-Q0871|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Voglio%20che%20se%20ne%20vada.)
^it-Q0871-answer

**it-Q0872** — Voglio che se ne vada.

I want him to leave.

Expected form: **se**

Why: Conditions. [[Italian#^it-Q0872|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Voglio%20che%20se%20ne%20vada.)
^it-Q0872-answer

**it-Q0873** — Se lo sa una donna, lo sa il mondo intero.

If a woman knows, the whole world knows.

Expected form: **Se**

Why: Conditions. [[Italian#^it-Q0873|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Se%20lo%20sa%20una%20donna%2C%20lo%20sa%20il%20mondo%20intero.)
^it-Q0873-answer

**it-Q0874** — Se lo sa una donna, lo sa il mondo intero.

If a woman knows, the whole world knows.

Why: Conditions. [[Italian#^it-Q0874|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Se%20lo%20sa%20una%20donna%2C%20lo%20sa%20il%20mondo%20intero.)
^it-Q0874-answer

**it-Q0875** — Non so se lo possiamo fare senza il permesso di Tom.

I don't know if we can do that without Tom's permission.

Why: Conditions. [[Italian#^it-Q0875|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20so%20se%20lo%20possiamo%20fare%20senza%20il%20permesso%20di%20Tom.)
^it-Q0875-answer

**it-Q0876** — Non so se lo possiamo fare senza il permesso di Tom.

I don't know if we can do that without Tom's permission.

Se introduces if or indirect whether. Unreal present conditions commonly combine imperfect subjunctive with conditional. Unreal past conditions use pluperfect subjunctive and past conditional.

Why: Conditions. [[Italian#^it-Q0876|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20so%20se%20lo%20possiamo%20fare%20senza%20il%20permesso%20di%20Tom.)
^it-Q0876-answer

**it-Q0877** — Ho dimenticato se tu bevi vino o no.

I've forgotten whether you drink wine or not.

Expected form: **se**

Why: Conditions. [[Italian#^it-Q0877|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Ho%20dimenticato%20se%20tu%20bevi%20vino%20o%20no.)
^it-Q0877-answer

**it-Q0878** — Ho dimenticato se tu bevi vino o no.

I've forgotten whether you drink wine or not.

Expected form: **se**

Why: Conditions. [[Italian#^it-Q0878|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Ho%20dimenticato%20se%20tu%20bevi%20vino%20o%20no.)
^it-Q0878-answer

**it-Q0879** — Se mangi troppo, diventerai grassa.

If you eat too much, you'll become fat.

Expected form: **Se**

Why: Conditions. [[Italian#^it-Q0879|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Se%20mangi%20troppo%2C%20diventerai%20grassa.)
^it-Q0879-answer

**it-Q0880** — Se mangi troppo, diventerai grassa.

If you eat too much, you'll become fat.

Why: Conditions. [[Italian#^it-Q0880|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Se%20mangi%20troppo%2C%20diventerai%20grassa.)
^it-Q0880-answer

**it-Q0881** — Io non farei nulla per Tom se fossi in te.

I wouldn't do anything for Tom if I were you.

Why: Conditions. [[Italian#^it-Q0881|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Io%20non%20farei%20nulla%20per%20Tom%20se%20fossi%20in%20te.)
^it-Q0881-answer

**it-Q0882** — Io non farei nulla per Tom se fossi in te.

I wouldn't do anything for Tom if I were you.

Se introduces if or indirect whether. Unreal present conditions commonly combine imperfect subjunctive with conditional. Unreal past conditions use pluperfect subjunctive and past conditional.

Why: Conditions. [[Italian#^it-Q0882|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Io%20non%20farei%20nulla%20per%20Tom%20se%20fossi%20in%20te.)
^it-Q0882-answer

**it-Q0883** — Non riesco a dire se Tom sta scherzando o no.

I can't tell if Tom is joking or not.

Expected form: **se**

Why: Conditions. [[Italian#^it-Q0883|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20riesco%20a%20dire%20se%20Tom%20sta%20scherzando%20o%20no.)
^it-Q0883-answer

**it-Q0884** — Non riesco a dire se Tom sta scherzando o no.

I can't tell if Tom is joking or not.

Expected form: **se**

Why: Conditions. [[Italian#^it-Q0884|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20riesco%20a%20dire%20se%20Tom%20sta%20scherzando%20o%20no.)
^it-Q0884-answer

**it-Q0885** — Se non lo dici a lei, lo farò io.

If you won't tell her, I will.

Expected form: **Se**

Why: Conditions. [[Italian#^it-Q0885|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Se%20non%20lo%20dici%20a%20lei%2C%20lo%20far%C3%B2%20io.)
^it-Q0885-answer

**it-Q0886** — Se non lo dici a lei, lo farò io.

If you won't tell her, I will.

Why: Conditions. [[Italian#^it-Q0886|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Se%20non%20lo%20dici%20a%20lei%2C%20lo%20far%C3%B2%20io.)
^it-Q0886-answer

**it-Q0887** — Tom si comportava come se non conoscesse Mary.

Tom acted like he didn't know Mary.

Why: Conditions. [[Italian#^it-Q0887|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20si%20comportava%20come%20se%20non%20conoscesse%20Mary.)
^it-Q0887-answer

**it-Q0888** — Tom si comportava come se non conoscesse Mary.

Tom acted like he didn't know Mary.

Se introduces if or indirect whether. Unreal present conditions commonly combine imperfect subjunctive with conditional. Unreal past conditions use pluperfect subjunctive and past conditional.

Why: Conditions. [[Italian#^it-Q0888|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20si%20comportava%20come%20se%20non%20conoscesse%20Mary.)
^it-Q0888-answer

**it-Q0889** — Non so se verrà o no.

I don't know if she will come or not.

Expected form: **se**

Why: Conditions. [[Italian#^it-Q0889|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20so%20se%20verr%C3%A0%20o%20no.)
^it-Q0889-answer

**it-Q0890** — Non so se verrà o no.

I don't know if she will come or not.

Expected form: **se**

Why: Conditions. [[Italian#^it-Q0890|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20so%20se%20verr%C3%A0%20o%20no.)
^it-Q0890-answer

**it-Q0891** — Sarebbe meglio se voi vi riposaste qui.

It would be better if you took a rest here.

Expected form: **se**

Why: Conditions. [[Italian#^it-Q0891|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Sarebbe%20meglio%20se%20voi%20vi%20riposaste%20qui.)
^it-Q0891-answer

**it-Q0892** — Sarebbe meglio se voi vi riposaste qui.

It would be better if you took a rest here.

Why: Conditions. [[Italian#^it-Q0892|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Sarebbe%20meglio%20se%20voi%20vi%20riposaste%20qui.)
^it-Q0892-answer

**it-Q0893** — Puoi migliorare il tuo inglese se provi.

You can improve your English if you try.

Why: Conditions. [[Italian#^it-Q0893|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Puoi%20migliorare%20il%20tuo%20inglese%20se%20provi.)
^it-Q0893-answer

**it-Q0894** — Puoi migliorare il tuo inglese se provi.

You can improve your English if you try.

Se introduces if or indirect whether. Unreal present conditions commonly combine imperfect subjunctive with conditional. Unreal past conditions use pluperfect subjunctive and past conditional.

Why: Conditions. [[Italian#^it-Q0894|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Puoi%20migliorare%20il%20tuo%20inglese%20se%20provi.)
^it-Q0894-answer

**it-Q0895** — Se si mangia a quest'ora della notte, si ingrasserà.

If you eat at this time of night, you'll get fat.

Expected form: **Se**

Why: Conditions. [[Italian#^it-Q0895|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Se%20si%20mangia%20a%20quest%27ora%20della%20notte%2C%20si%20ingrasser%C3%A0.)
^it-Q0895-answer

**it-Q0896** — Se si mangia a quest'ora della notte, si ingrasserà.

If you eat at this time of night, you'll get fat.

Expected form: **Se**

Why: Conditions. [[Italian#^it-Q0896|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Se%20si%20mangia%20a%20quest%27ora%20della%20notte%2C%20si%20ingrasser%C3%A0.)
^it-Q0896-answer

**it-Q0897** — Ti dispiace se uso questo dizionario?

Would you mind my using this dictionary?

Expected form: **se**

Why: Conditions. [[Italian#^it-Q0897|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Ti%20dispiace%20se%20uso%20questo%20dizionario%3F)
^it-Q0897-answer

**it-Q0898** — Ti dispiace se uso questo dizionario?

Would you mind my using this dictionary?

Why: Conditions. [[Italian#^it-Q0898|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Ti%20dispiace%20se%20uso%20questo%20dizionario%3F)
^it-Q0898-answer

**it-Q0899** — Mi chiedo se a Tom piaccia ancora Mary.

I wonder if Tom still likes Mary.

Why: Conditions. [[Italian#^it-Q0899|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Mi%20chiedo%20se%20a%20Tom%20piaccia%20ancora%20Mary.)
^it-Q0899-answer

**it-Q0900** — Mi chiedo se a Tom piaccia ancora Mary.

I wonder if Tom still likes Mary.

Se introduces if or indirect whether. Unreal present conditions commonly combine imperfect subjunctive with conditional. Unreal past conditions use pluperfect subjunctive and past conditional.

Why: Conditions. [[Italian#^it-Q0900|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Mi%20chiedo%20se%20a%20Tom%20piaccia%20ancora%20Mary.)
^it-Q0900-answer


### Answers 901–950

**it-Q0901** — Ho cliccato sul link, però non è successo niente.

I clicked the link, but nothing happened.

Expected form: **però**

Why: Logical connectors. [[Italian#^it-Q0901|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Ho%20cliccato%20sul%20link%2C%20per%C3%B2%20non%20%C3%A8%20successo%20niente.)
^it-Q0901-answer

**it-Q0902** — Ho cliccato sul link, però non è successo niente.

I clicked the link, but nothing happened.

Expected form: **però**

Why: Logical connectors. [[Italian#^it-Q0902|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Ho%20cliccato%20sul%20link%2C%20per%C3%B2%20non%20%C3%A8%20successo%20niente.)
^it-Q0902-answer

**it-Q0903** — Perché le persone hanno paura di me?

Why are people scared of me?

Expected form: **Perché**

Why: Logical connectors. [[Italian#^it-Q0903|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Perch%C3%A9%20le%20persone%20hanno%20paura%20di%20me%3F)
^it-Q0903-answer

**it-Q0904** — Perché le persone hanno paura di me?

Why are people scared of me?

Why: Logical connectors. [[Italian#^it-Q0904|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Perch%C3%A9%20le%20persone%20hanno%20paura%20di%20me%3F)
^it-Q0904-answer

**it-Q0905** — Perché volete comprare questo libro?

Why do you want to buy this book?

Why: Logical connectors. [[Italian#^it-Q0905|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Perch%C3%A9%20volete%20comprare%20questo%20libro%3F)
^it-Q0905-answer

**it-Q0906** — Perché volete comprare questo libro?

Why do you want to buy this book?

Distinguish cause, concession and result. Benché generally takes subjunctive. Però/tuttavia connect a contrast without the same subordinate grammar.

Why: Logical connectors. [[Italian#^it-Q0906|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Perch%C3%A9%20volete%20comprare%20questo%20libro%3F)
^it-Q0906-answer

**it-Q0907** — Hanno detto il perché?

Did they say why?

Expected form: **perché**

Why: Logical connectors. [[Italian#^it-Q0907|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Hanno%20detto%20il%20perch%C3%A9%3F)
^it-Q0907-answer

**it-Q0908** — Hanno detto il perché?

Did they say why?

Expected form: **perché**

Why: Logical connectors. [[Italian#^it-Q0908|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Hanno%20detto%20il%20perch%C3%A9%3F)
^it-Q0908-answer

**it-Q0909** — Perché non mi avete consultata?

Why didn't you consult me?

Expected form: **Perché**

Why: Logical connectors. [[Italian#^it-Q0909|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Perch%C3%A9%20non%20mi%20avete%20consultata%3F)
^it-Q0909-answer

**it-Q0910** — Perché non mi avete consultata?

Why didn't you consult me?

Why: Logical connectors. [[Italian#^it-Q0910|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Perch%C3%A9%20non%20mi%20avete%20consultata%3F)
^it-Q0910-answer

**it-Q0911** — Perché non va a chiedere a loro?

Why don't you go ask them?

Why: Logical connectors. [[Italian#^it-Q0911|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Perch%C3%A9%20non%20va%20a%20chiedere%20a%20loro%3F)
^it-Q0911-answer

**it-Q0912** — Perché non va a chiedere a loro?

Why don't you go ask them?

Distinguish cause, concession and result. Benché generally takes subjunctive. Però/tuttavia connect a contrast without the same subordinate grammar.

Why: Logical connectors. [[Italian#^it-Q0912|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Perch%C3%A9%20non%20va%20a%20chiedere%20a%20loro%3F)
^it-Q0912-answer

**it-Q0913** — Perché tutti sono sorpresi?

Why is everyone so surprised?

Expected form: **Perché**

Why: Logical connectors. [[Italian#^it-Q0913|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Perch%C3%A9%20tutti%20sono%20sorpresi%3F)
^it-Q0913-answer

**it-Q0914** — Perché tutti sono sorpresi?

Why is everyone so surprised?

Expected form: **Perché**

Why: Logical connectors. [[Italian#^it-Q0914|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Perch%C3%A9%20tutti%20sono%20sorpresi%3F)
^it-Q0914-answer

**it-Q0915** — Perché voleva che venissi qua?

Why did you want me to come here?

Expected form: **Perché**

Why: Logical connectors. [[Italian#^it-Q0915|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Perch%C3%A9%20voleva%20che%20venissi%20qua%3F)
^it-Q0915-answer

**it-Q0916** — Perché voleva che venissi qua?

Why did you want me to come here?

Why: Logical connectors. [[Italian#^it-Q0916|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Perch%C3%A9%20voleva%20che%20venissi%20qua%3F)
^it-Q0916-answer

**it-Q0917** — Perché lo odiano tutti?

Why does everyone hate him?

Why: Logical connectors. [[Italian#^it-Q0917|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Perch%C3%A9%20lo%20odiano%20tutti%3F)
^it-Q0917-answer

**it-Q0918** — Perché lo odiano tutti?

Why does everyone hate him?

Distinguish cause, concession and result. Benché generally takes subjunctive. Però/tuttavia connect a contrast without the same subordinate grammar.

Why: Logical connectors. [[Italian#^it-Q0918|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Perch%C3%A9%20lo%20odiano%20tutti%3F)
^it-Q0918-answer

**it-Q0919** — Non dica loro il perché.

Don't tell them why.

Expected form: **perché**

Why: Logical connectors. [[Italian#^it-Q0919|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20dica%20loro%20il%20perch%C3%A9.)
^it-Q0919-answer

**it-Q0920** — Non dica loro il perché.

Don't tell them why.

Expected form: **perché**

Why: Logical connectors. [[Italian#^it-Q0920|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20dica%20loro%20il%20perch%C3%A9.)
^it-Q0920-answer

**it-Q0921** — Io non ho un gatto, però Tom sì.

I don't have a cat, but Tom does.

Expected form: **però**

Why: Logical connectors. [[Italian#^it-Q0921|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Io%20non%20ho%20un%20gatto%2C%20per%C3%B2%20Tom%20s%C3%AC.)
^it-Q0921-answer

**it-Q0922** — Io non ho un gatto, però Tom sì.

I don't have a cat, but Tom does.

Why: Logical connectors. [[Italian#^it-Q0922|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Io%20non%20ho%20un%20gatto%2C%20per%C3%B2%20Tom%20s%C3%AC.)
^it-Q0922-answer

**it-Q0923** — È perché la velocità della luce è superiore a quella del suono che alcune persone sembrano brillanti prima di suonare stupide.

It is because light travels faster than sound that some people look brilliant before sounding stupid.

Why: Logical connectors. [[Italian#^it-Q0923|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=%C3%88%20perch%C3%A9%20la%20velocit%C3%A0%20della%20luce%20%C3%A8%20superiore%20a%20quella%20del%20suono%20che%20alcune%20persone%20sembrano%20brillanti%20prima%20di%20suonare%20stupide.)
^it-Q0923-answer

**it-Q0924** — È perché la velocità della luce è superiore a quella del suono che alcune persone sembrano brillanti prima di suonare stupide.

It is because light travels faster than sound that some people look brilliant before sounding stupid.

Distinguish cause, concession and result. Benché generally takes subjunctive. Però/tuttavia connect a contrast without the same subordinate grammar.

Why: Logical connectors. [[Italian#^it-Q0924|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=%C3%88%20perch%C3%A9%20la%20velocit%C3%A0%20della%20luce%20%C3%A8%20superiore%20a%20quella%20del%20suono%20che%20alcune%20persone%20sembrano%20brillanti%20prima%20di%20suonare%20stupide.)
^it-Q0924-answer

**it-Q0925** — Perché noi abbiamo bisogno di aspartame?

Why do we need aspartame?

Expected form: **Perché**

Why: Logical connectors. [[Italian#^it-Q0925|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Perch%C3%A9%20noi%20abbiamo%20bisogno%20di%20aspartame%3F)
^it-Q0925-answer

**it-Q0926** — Perché noi abbiamo bisogno di aspartame?

Why do we need aspartame?

Expected form: **Perché**

Why: Logical connectors. [[Italian#^it-Q0926|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Perch%C3%A9%20noi%20abbiamo%20bisogno%20di%20aspartame%3F)
^it-Q0926-answer

**it-Q0927** — Io sapevo che Tom era un insegnante di francese a Boston, quindi non credetti a Mary quando mi disse che era un tassista a Chicago.

I knew that Tom was a French teacher in Boston, so I didn't believe Mary when she told me that Tom was a taxi driver in Chicago.

Expected form: **quindi**

Why: Logical connectors. [[Italian#^it-Q0927|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Io%20sapevo%20che%20Tom%20era%20un%20insegnante%20di%20francese%20a%20Boston%2C%20quindi%20non%20credetti%20a%20Mary%20quando%20mi%20disse%20che%20era%20un%20tassista%20a%20Chicago.)
^it-Q0927-answer

**it-Q0928** — Io sapevo che Tom era un insegnante di francese a Boston, quindi non credetti a Mary quando mi disse che era un tassista a Chicago.

I knew that Tom was a French teacher in Boston, so I didn't believe Mary when she told me that Tom was a taxi driver in Chicago.

Why: Logical connectors. [[Italian#^it-Q0928|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Io%20sapevo%20che%20Tom%20era%20un%20insegnante%20di%20francese%20a%20Boston%2C%20quindi%20non%20credetti%20a%20Mary%20quando%20mi%20disse%20che%20era%20un%20tassista%20a%20Chicago.)
^it-Q0928-answer

**it-Q0929** — Perché non prova a dormire un po'?

Why not try to get some sleep?

Why: Logical connectors. [[Italian#^it-Q0929|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Perch%C3%A9%20non%20prova%20a%20dormire%20un%20po%27%3F)
^it-Q0929-answer

**it-Q0930** — Perché non prova a dormire un po'?

Why not try to get some sleep?

Distinguish cause, concession and result. Benché generally takes subjunctive. Però/tuttavia connect a contrast without the same subordinate grammar.

Why: Logical connectors. [[Italian#^it-Q0930|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Perch%C3%A9%20non%20prova%20a%20dormire%20un%20po%27%3F)
^it-Q0930-answer

**it-Q0931** — Perché non mi avete creduto?

Why didn't you believe me?

Expected form: **Perché**

Why: Logical connectors. [[Italian#^it-Q0931|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Perch%C3%A9%20non%20mi%20avete%20creduto%3F)
^it-Q0931-answer

**it-Q0932** — Perché non mi avete creduto?

Why didn't you believe me?

Expected form: **Perché**

Why: Logical connectors. [[Italian#^it-Q0932|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Perch%C3%A9%20non%20mi%20avete%20creduto%3F)
^it-Q0932-answer

**it-Q0933** — Perché la mia borsa è vuota?

Why is my bag empty?

Expected form: **Perché**

Why: Logical connectors. [[Italian#^it-Q0933|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Perch%C3%A9%20la%20mia%20borsa%20%C3%A8%20vuota%3F)
^it-Q0933-answer

**it-Q0934** — Perché la mia borsa è vuota?

Why is my bag empty?

Why: Logical connectors. [[Italian#^it-Q0934|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Perch%C3%A9%20la%20mia%20borsa%20%C3%A8%20vuota%3F)
^it-Q0934-answer

**it-Q0935** — Perché è offeso?

Why are you offended?

Why: Logical connectors. [[Italian#^it-Q0935|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Perch%C3%A9%20%C3%A8%20offeso%3F)
^it-Q0935-answer

**it-Q0936** — Perché è offeso?

Why are you offended?

Distinguish cause, concession and result. Benché generally takes subjunctive. Però/tuttavia connect a contrast without the same subordinate grammar.

Why: Logical connectors. [[Italian#^it-Q0936|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Perch%C3%A9%20%C3%A8%20offeso%3F)
^it-Q0936-answer

**it-Q0937** — Io devo solo scoprire il perché.

I just need to find out why.

Expected form: **perché**

Why: Logical connectors. [[Italian#^it-Q0937|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Io%20devo%20solo%20scoprire%20il%20perch%C3%A9.)
^it-Q0937-answer

**it-Q0938** — Io devo solo scoprire il perché.

I just need to find out why.

Expected form: **perché**

Why: Logical connectors. [[Italian#^it-Q0938|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Io%20devo%20solo%20scoprire%20il%20perch%C3%A9.)
^it-Q0938-answer

**it-Q0939** — Perché non chiedete a loro di farla?

Why don't you ask them to do it?

Expected form: **Perché**

Why: Logical connectors. [[Italian#^it-Q0939|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Perch%C3%A9%20non%20chiedete%20a%20loro%20di%20farla%3F)
^it-Q0939-answer

**it-Q0940** — Perché non chiedete a loro di farla?

Why don't you ask them to do it?

Why: Logical connectors. [[Italian#^it-Q0940|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Perch%C3%A9%20non%20chiedete%20a%20loro%20di%20farla%3F)
^it-Q0940-answer

**it-Q0941** — Perché vive qui?

Why do you live here?

Why: Logical connectors. [[Italian#^it-Q0941|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Perch%C3%A9%20vive%20qui%3F)
^it-Q0941-answer

**it-Q0942** — Perché vive qui?

Why do you live here?

Distinguish cause, concession and result. Benché generally takes subjunctive. Però/tuttavia connect a contrast without the same subordinate grammar.

Why: Logical connectors. [[Italian#^it-Q0942|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Perch%C3%A9%20vive%20qui%3F)
^it-Q0942-answer

**it-Q0943** — Perché state facendo quello che state facendo?

Why are you doing what you're doing?

Expected form: **Perché**

Why: Logical connectors. [[Italian#^it-Q0943|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Perch%C3%A9%20state%20facendo%20quello%20che%20state%20facendo%3F)
^it-Q0943-answer

**it-Q0944** — Perché state facendo quello che state facendo?

Why are you doing what you're doing?

Expected form: **Perché**

Why: Logical connectors. [[Italian#^it-Q0944|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Perch%C3%A9%20state%20facendo%20quello%20che%20state%20facendo%3F)
^it-Q0944-answer

**it-Q0945** — Perché ve ne siete andate presto?

Why did you leave early?

Expected form: **Perché**

Why: Logical connectors. [[Italian#^it-Q0945|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Perch%C3%A9%20ve%20ne%20siete%20andate%20presto%3F)
^it-Q0945-answer

**it-Q0946** — Perché ve ne siete andate presto?

Why did you leave early?

Why: Logical connectors. [[Italian#^it-Q0946|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Perch%C3%A9%20ve%20ne%20siete%20andate%20presto%3F)
^it-Q0946-answer

**it-Q0947** — Perché non mi avete chiamato?

Why didn't you call me?

Why: Logical connectors. [[Italian#^it-Q0947|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Perch%C3%A9%20non%20mi%20avete%20chiamato%3F)
^it-Q0947-answer

**it-Q0948** — Perché non mi avete chiamato?

Why didn't you call me?

Distinguish cause, concession and result. Benché generally takes subjunctive. Però/tuttavia connect a contrast without the same subordinate grammar.

Why: Logical connectors. [[Italian#^it-Q0948|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Perch%C3%A9%20non%20mi%20avete%20chiamato%3F)
^it-Q0948-answer

**it-Q0949** — Mi avete tradito. Perché?

You betrayed me. Why?

Expected form: **Perché**

Why: Logical connectors. [[Italian#^it-Q0949|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Mi%20avete%20tradito.%20Perch%C3%A9%3F)
^it-Q0949-answer

**it-Q0950** — Mi avete tradito. Perché?

You betrayed me. Why?

Expected form: **Perché**

Why: Logical connectors. [[Italian#^it-Q0950|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Mi%20avete%20tradito.%20Perch%C3%A9%3F)
^it-Q0950-answer


### Answers 951–1000

**it-Q0951** — Faresti meglio a osservarli.

You'd better watch them.

Expected form: **meglio**

Why: Comparison and agreement. [[Italian#^it-Q0951|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Faresti%20meglio%20a%20osservarli.)
^it-Q0951-answer

**it-Q0952** — Faresti meglio a osservarli.

You'd better watch them.

Why: Comparison and agreement. [[Italian#^it-Q0952|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Faresti%20meglio%20a%20osservarli.)
^it-Q0952-answer

**it-Q0953** — Abbiamo bisogno di trovare una nuova babysitter.

We need to find a new babysitter.

Why: Comparison and agreement. [[Italian#^it-Q0953|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Abbiamo%20bisogno%20di%20trovare%20una%20nuova%20babysitter.)
^it-Q0953-answer

**it-Q0954** — Abbiamo bisogno di trovare una nuova babysitter.

We need to find a new babysitter.

Più/meno build regular comparison. Meglio is commonly adverbial; migliore commonly adjectival. Attributive and predicative adjectives agree with their nouns in gender and number.

Why: Comparison and agreement. [[Italian#^it-Q0954|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Abbiamo%20bisogno%20di%20trovare%20una%20nuova%20babysitter.)
^it-Q0954-answer

**it-Q0955** — Sachiko è più popolare di Judy.

Sachiko is more popular than Judy.

Expected form: **più**

Why: Comparison and agreement. [[Italian#^it-Q0955|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Sachiko%20%C3%A8%20pi%C3%B9%20popolare%20di%20Judy.)
^it-Q0955-answer

**it-Q0956** — Sachiko è più popolare di Judy.

Sachiko is more popular than Judy.

Expected form: **più**

Why: Comparison and agreement. [[Italian#^it-Q0956|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Sachiko%20%C3%A8%20pi%C3%B9%20popolare%20di%20Judy.)
^it-Q0956-answer

**it-Q0957** — Mary è meno attiva di sua sorella.

Mary's less active than her sister.

Expected form: **meno**

Why: Comparison and agreement. [[Italian#^it-Q0957|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Mary%20%C3%A8%20meno%20attiva%20di%20sua%20sorella.)
^it-Q0957-answer

**it-Q0958** — Mary è meno attiva di sua sorella.

Mary's less active than her sister.

Why: Comparison and agreement. [[Italian#^it-Q0958|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Mary%20%C3%A8%20meno%20attiva%20di%20sua%20sorella.)
^it-Q0958-answer

**it-Q0959** — Ho preso un cellulare nuovo.

I got a new cellphone.

Why: Comparison and agreement. [[Italian#^it-Q0959|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Ho%20preso%20un%20cellulare%20nuovo.)
^it-Q0959-answer

**it-Q0960** — Ho preso un cellulare nuovo.

I got a new cellphone.

Più/meno build regular comparison. Meglio is commonly adverbial; migliore commonly adjectival. Attributive and predicative adjectives agree with their nouns in gender and number.

Why: Comparison and agreement. [[Italian#^it-Q0960|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Ho%20preso%20un%20cellulare%20nuovo.)
^it-Q0960-answer

**it-Q0961** — Io non ho più tempo per parlare con voi.

I don't have time to talk with you anymore.

Expected form: **più**

Why: Comparison and agreement. [[Italian#^it-Q0961|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Io%20non%20ho%20pi%C3%B9%20tempo%20per%20parlare%20con%20voi.)
^it-Q0961-answer

**it-Q0962** — Io non ho più tempo per parlare con voi.

I don't have time to talk with you anymore.

Expected form: **più**

Why: Comparison and agreement. [[Italian#^it-Q0962|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Io%20non%20ho%20pi%C3%B9%20tempo%20per%20parlare%20con%20voi.)
^it-Q0962-answer

**it-Q0963** — Non sei più mia amica.

You're not my friend anymore.

Expected form: **più**

Why: Comparison and agreement. [[Italian#^it-Q0963|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20sei%20pi%C3%B9%20mia%20amica.)
^it-Q0963-answer

**it-Q0964** — Non sei più mia amica.

You're not my friend anymore.

Why: Comparison and agreement. [[Italian#^it-Q0964|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20sei%20pi%C3%B9%20mia%20amica.)
^it-Q0964-answer

**it-Q0965** — Lui ha ancora più mele.

He has even more apples.

Why: Comparison and agreement. [[Italian#^it-Q0965|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Lui%20ha%20ancora%20pi%C3%B9%20mele.)
^it-Q0965-answer

**it-Q0966** — Lui ha ancora più mele.

He has even more apples.

Più/meno build regular comparison. Meglio is commonly adverbial; migliore commonly adjectival. Attributive and predicative adjectives agree with their nouns in gender and number.

Why: Comparison and agreement. [[Italian#^it-Q0966|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Lui%20ha%20ancora%20pi%C3%B9%20mele.)
^it-Q0966-answer

**it-Q0967** — Tom e Mary sono entrambi abbastanza grandi per sapere meglio.

Tom and Mary are both old enough to know better.

Expected form: **meglio**

Why: Comparison and agreement. [[Italian#^it-Q0967|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20e%20Mary%20sono%20entrambi%20abbastanza%20grandi%20per%20sapere%20meglio.)
^it-Q0967-answer

**it-Q0968** — Tom e Mary sono entrambi abbastanza grandi per sapere meglio.

Tom and Mary are both old enough to know better.

Expected form: **meglio**

Why: Comparison and agreement. [[Italian#^it-Q0968|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20e%20Mary%20sono%20entrambi%20abbastanza%20grandi%20per%20sapere%20meglio.)
^it-Q0968-answer

**it-Q0969** — Evidenzia i momenti più intensi del tormento interiore di Medea.

Mark the most intense moments of Medea's inner torment.

Expected form: **più**

Why: Comparison and agreement. [[Italian#^it-Q0969|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Evidenzia%20i%20momenti%20pi%C3%B9%20intensi%20del%20tormento%20interiore%20di%20Medea.)
^it-Q0969-answer

**it-Q0970** — Evidenzia i momenti più intensi del tormento interiore di Medea.

Mark the most intense moments of Medea's inner torment.

Why: Comparison and agreement. [[Italian#^it-Q0970|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Evidenzia%20i%20momenti%20pi%C3%B9%20intensi%20del%20tormento%20interiore%20di%20Medea.)
^it-Q0970-answer

**it-Q0971** — Non li odio più.

I don't hate them anymore.

Why: Comparison and agreement. [[Italian#^it-Q0971|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20li%20odio%20pi%C3%B9.)
^it-Q0971-answer

**it-Q0972** — Non li odio più.

I don't hate them anymore.

Più/meno build regular comparison. Meglio is commonly adverbial; migliore commonly adjectival. Attributive and predicative adjectives agree with their nouns in gender and number.

Why: Comparison and agreement. [[Italian#^it-Q0972|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20li%20odio%20pi%C3%B9.)
^it-Q0972-answer

**it-Q0973** — Io non voglio mangiare di nuovo lì.

I don't want to eat there again.

Expected form: **nuovo**

Why: Comparison and agreement. [[Italian#^it-Q0973|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Io%20non%20voglio%20mangiare%20di%20nuovo%20l%C3%AC.)
^it-Q0973-answer

**it-Q0974** — Io non voglio mangiare di nuovo lì.

I don't want to eat there again.

Expected form: **nuovo**

Why: Comparison and agreement. [[Italian#^it-Q0974|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Io%20non%20voglio%20mangiare%20di%20nuovo%20l%C3%AC.)
^it-Q0974-answer

**it-Q0975** — Non sono più sposato con lui.

I'm not married to him anymore.

Expected form: **più**

Why: Comparison and agreement. [[Italian#^it-Q0975|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20sono%20pi%C3%B9%20sposato%20con%20lui.)
^it-Q0975-answer

**it-Q0976** — Non sono più sposato con lui.

I'm not married to him anymore.

Why: Comparison and agreement. [[Italian#^it-Q0976|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20sono%20pi%C3%B9%20sposato%20con%20lui.)
^it-Q0976-answer

**it-Q0977** — La felicità è più importante della ricchezza.

Happiness is more important than wealth.

Why: Comparison and agreement. [[Italian#^it-Q0977|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=La%20felicit%C3%A0%20%C3%A8%20pi%C3%B9%20importante%20della%20ricchezza.)
^it-Q0977-answer

**it-Q0978** — La felicità è più importante della ricchezza.

Happiness is more important than wealth.

Più/meno build regular comparison. Meglio is commonly adverbial; migliore commonly adjectival. Attributive and predicative adjectives agree with their nouns in gender and number.

Why: Comparison and agreement. [[Italian#^it-Q0978|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=La%20felicit%C3%A0%20%C3%A8%20pi%C3%B9%20importante%20della%20ricchezza.)
^it-Q0978-answer

**it-Q0979** — Tu riesci a raggiungere lo scaffale più in alto?

Can you reach the top shelf?

Expected form: **più**

Why: Comparison and agreement. [[Italian#^it-Q0979|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tu%20riesci%20a%20raggiungere%20lo%20scaffale%20pi%C3%B9%20in%20alto%3F)
^it-Q0979-answer

**it-Q0980** — Tu riesci a raggiungere lo scaffale più in alto?

Can you reach the top shelf?

Expected form: **più**

Why: Comparison and agreement. [[Italian#^it-Q0980|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tu%20riesci%20a%20raggiungere%20lo%20scaffale%20pi%C3%B9%20in%20alto%3F)
^it-Q0980-answer

**it-Q0981** — I capelli di Jeannie erano più blu dei suoi occhi.

Jeannie's hair was bluer than her eyes.

Expected form: **più**

Why: Comparison and agreement. [[Italian#^it-Q0981|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=I%20capelli%20di%20Jeannie%20erano%20pi%C3%B9%20blu%20dei%20suoi%20occhi.)
^it-Q0981-answer

**it-Q0982** — I capelli di Jeannie erano più blu dei suoi occhi.

Jeannie's hair was bluer than her eyes.

Why: Comparison and agreement. [[Italian#^it-Q0982|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=I%20capelli%20di%20Jeannie%20erano%20pi%C3%B9%20blu%20dei%20suoi%20occhi.)
^it-Q0982-answer

**it-Q0983** — Tom ha mangiato meno di Mary.

Tom ate less than Mary did.

Why: Comparison and agreement. [[Italian#^it-Q0983|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20ha%20mangiato%20meno%20di%20Mary.)
^it-Q0983-answer

**it-Q0984** — Tom ha mangiato meno di Mary.

Tom ate less than Mary did.

Più/meno build regular comparison. Meglio is commonly adverbial; migliore commonly adjectival. Attributive and predicative adjectives agree with their nouns in gender and number.

Why: Comparison and agreement. [[Italian#^it-Q0984|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20ha%20mangiato%20meno%20di%20Mary.)
^it-Q0984-answer

**it-Q0985** — Non traduco più romanzi.

I don't translate novels anymore.

Expected form: **più**

Why: Comparison and agreement. [[Italian#^it-Q0985|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20traduco%20pi%C3%B9%20romanzi.)
^it-Q0985-answer

**it-Q0986** — Non traduco più romanzi.

I don't translate novels anymore.

Expected form: **più**

Why: Comparison and agreement. [[Italian#^it-Q0986|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20traduco%20pi%C3%B9%20romanzi.)
^it-Q0986-answer

**it-Q0987** — Non vogliamo più aspettare.

We don't want to wait any longer.

Expected form: **più**

Why: Comparison and agreement. [[Italian#^it-Q0987|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20vogliamo%20pi%C3%B9%20aspettare.)
^it-Q0987-answer

**it-Q0988** — Non vogliamo più aspettare.

We don't want to wait any longer.

Why: Comparison and agreement. [[Italian#^it-Q0988|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20vogliamo%20pi%C3%B9%20aspettare.)
^it-Q0988-answer

**it-Q0989** — Tom iniziò a sentirsi meglio.

Tom began to feel better.

Why: Comparison and agreement. [[Italian#^it-Q0989|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20inizi%C3%B2%20a%20sentirsi%20meglio.)
^it-Q0989-answer

**it-Q0990** — Tom iniziò a sentirsi meglio.

Tom began to feel better.

Più/meno build regular comparison. Meglio is commonly adverbial; migliore commonly adjectival. Attributive and predicative adjectives agree with their nouns in gender and number.

Why: Comparison and agreement. [[Italian#^it-Q0990|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20inizi%C3%B2%20a%20sentirsi%20meglio.)
^it-Q0990-answer

**it-Q0991** — Vuoi farlo di nuovo?

Do you want to do it again?

Expected form: **nuovo**

Why: Comparison and agreement. [[Italian#^it-Q0991|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Vuoi%20farlo%20di%20nuovo%3F)
^it-Q0991-answer

**it-Q0992** — Vuoi farlo di nuovo?

Do you want to do it again?

Expected form: **nuovo**

Why: Comparison and agreement. [[Italian#^it-Q0992|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Vuoi%20farlo%20di%20nuovo%3F)
^it-Q0992-answer

**it-Q0993** — Hai il nuovo album di Stevie Wonder?

Do you have Stevie Wonder's new album?

Expected form: **nuovo**

Why: Comparison and agreement. [[Italian#^it-Q0993|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Hai%20il%20nuovo%20album%20di%20Stevie%20Wonder%3F)
^it-Q0993-answer

**it-Q0994** — Hai il nuovo album di Stevie Wonder?

Do you have Stevie Wonder's new album?

Why: Comparison and agreement. [[Italian#^it-Q0994|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Hai%20il%20nuovo%20album%20di%20Stevie%20Wonder%3F)
^it-Q0994-answer

**it-Q0995** — Sami aveva un lavoro migliore.

Sami had a better job.

Why: Comparison and agreement. [[Italian#^it-Q0995|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Sami%20aveva%20un%20lavoro%20migliore.)
^it-Q0995-answer

**it-Q0996** — Sami aveva un lavoro migliore.

Sami had a better job.

Più/meno build regular comparison. Meglio is commonly adverbial; migliore commonly adjectival. Attributive and predicative adjectives agree with their nouns in gender and number.

Why: Comparison and agreement. [[Italian#^it-Q0996|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Sami%20aveva%20un%20lavoro%20migliore.)
^it-Q0996-answer

**it-Q0997** — Tom ha sicuramente più di trent'anni.

Tom is certainly over thirty.

Expected form: **più**

Why: Comparison and agreement. [[Italian#^it-Q0997|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20ha%20sicuramente%20pi%C3%B9%20di%20trent%27anni.)
^it-Q0997-answer

**it-Q0998** — Tom ha sicuramente più di trent'anni.

Tom is certainly over thirty.

Expected form: **più**

Why: Comparison and agreement. [[Italian#^it-Q0998|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Tom%20ha%20sicuramente%20pi%C3%B9%20di%20trent%27anni.)
^it-Q0998-answer

**it-Q0999** — Non mi piace più il Natale.

I don't like Christmas anymore.

Expected form: **più**

Why: Comparison and agreement. [[Italian#^it-Q0999|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20mi%20piace%20pi%C3%B9%20il%20Natale.)
^it-Q0999-answer

**it-Q1000** — Non mi piace più il Natale.

I don't like Christmas anymore.

Why: Comparison and agreement. [[Italian#^it-Q1000|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=ita&query=Non%20mi%20piace%20pi%C3%B9%20il%20Natale.)
^it-Q1000-answer


## Read and speak

Read the native sentence first, identify its predicate and one grammar form, then check the translation. Say it aloud and change one detail.

### Learning with a clear purpose

Sto imparando una nuova lingua. Ogni giorno leggo un testo breve e ascolto esempi chiari. Scrivo parole utili in un quaderno. Quando faccio un errore, controllo la regola e provo di nuovo. Il mio obiettivo è capire le persone ed esprimere le mie idee con chiarezza.

I am learning a new language. Each day, I read a short text and listen to clear examples. I write useful words in a notebook. When I make a mistake, I check the rule and try again. My goal is to understand people and express my ideas clearly.

### Public health: risk and communication

Comunicare un rischio richiede più di un numero. È importante spiegare a quale popolazione si riferisce la stima, in quale periodo e rispetto a quale situazione di confronto. Un aumento relativo può sembrare grande anche quando il rischio assoluto rimane basso. Ciò non significa che il problema debba essere ignorato, ma che il lettore deve poter capire la portata dell'affermazione. Una comunicazione responsabile distingue i dati disponibili dalle ipotesi e indica quali informazioni potrebbero modificare la valutazione.

Communicating risk requires more than a number: the population, period and comparison must be clear. A relative increase can sound large while absolute risk remains low. That does not justify ignoring the issue; readers need to understand the claim's scope. Responsible communication separates available data from hypotheses and identifies information that could change the assessment.

![[Resources/Audio/it/Reading passage.mp3]]

**Tom ha rinunciato.**

Tom quit.

**I miei doveri pubblici mi prendono molto tempo.**

My public duties take a lot of time.

**Io non devo seguire Tom.**

I don't have to follow Tom.

**Non sono una spiona.**

I'm not a tattletale.

**Ai bambini piace più giocare che studiare.**

Children like playing more than studying.

**Temo che mi verrà il mal di testa pensando a quant'è fastidioso Chris.**

My head starts to hurt when I think about how annoying Chris is.

**Mi piace questo quartiere.**

I like this neighborhood.

**Tom non aveva denaro.**

Tom had no money.

**Tom sembra molto stanco.**

Tom looks very tired.

**Lo so che non l'ha ancora fatta.**

I know you haven't done it yet.

**A voi servirà un alibi.**

You're going to need an alibi.

**Cosa vi piace di lui?**

What do you like about him?

**Da quale parte del Canada venite?**

Where in Canada are you from?

**La mia vita non è più la stessa da quando l'ho conosciuto.**

My life hasn't been the same since I met him.

**Nessuna cosa vivente potrebbe vivere senza aria.**

No living thing could live without air.

## Professional writing

Write an introduction, a polite request, an explanation of a finding, a summary of a passage and a tactful disagreement. Use the professional/advanced lessons for models.

## PDF edition

[[Resources/PDFs/Italian.pdf|Open the complete printable book]]


<!-- individual-letter-audio -->
## Hear each letter separately

Play each letter’s own synthetic recording. English has separate US and UK models.

### A a · a

![[Resources/Audio/it/Letters/001.mp3]]

### B b · bi

![[Resources/Audio/it/Letters/002.mp3]]

### C c · ci

![[Resources/Audio/it/Letters/003.mp3]]

### D d · di

![[Resources/Audio/it/Letters/004.mp3]]

### E e · e

![[Resources/Audio/it/Letters/005.mp3]]

### F f · effe

![[Resources/Audio/it/Letters/006.mp3]]

### G g · gi

![[Resources/Audio/it/Letters/007.mp3]]

### H h · acca

![[Resources/Audio/it/Letters/008.mp3]]

### I i · i

![[Resources/Audio/it/Letters/009.mp3]]

### J j · i lunga

![[Resources/Audio/it/Letters/010.mp3]]

### K k · cappa

![[Resources/Audio/it/Letters/011.mp3]]

### L l · elle

![[Resources/Audio/it/Letters/012.mp3]]

### M m · emme

![[Resources/Audio/it/Letters/013.mp3]]

### N n · enne

![[Resources/Audio/it/Letters/014.mp3]]

### O o · o

![[Resources/Audio/it/Letters/015.mp3]]

### P p · pi

![[Resources/Audio/it/Letters/016.mp3]]

### Q q · cu

![[Resources/Audio/it/Letters/017.mp3]]

### R r · erre

![[Resources/Audio/it/Letters/018.mp3]]

### S s · esse

![[Resources/Audio/it/Letters/019.mp3]]

### T t · ti

![[Resources/Audio/it/Letters/020.mp3]]

### U u · u

![[Resources/Audio/it/Letters/021.mp3]]

### V v · vu / vi

![[Resources/Audio/it/Letters/022.mp3]]

### W w · doppia vu

![[Resources/Audio/it/Letters/023.mp3]]

### X x · ics

![[Resources/Audio/it/Letters/024.mp3]]

### Y y · ipsilon / i greca

![[Resources/Audio/it/Letters/025.mp3]]

### Z z · zeta

![[Resources/Audio/it/Letters/026.mp3]]
<!-- /individual-letter-audio -->
