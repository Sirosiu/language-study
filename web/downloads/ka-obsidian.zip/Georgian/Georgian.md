# Georgian

Professional ambition - C1-oriented study

Everything for this language is in this note. Open a rule, read its examples and follow its practice link. Answers stay in this same note.

[[Start Here|All languages]] · [[Sources and licenses|Sources]]

## Start reading

### ანბანი (anbani)

| Written form | Name / reading | Related forms |
|---|---|---|
| ა | ani  |  ·  ·  |
| ბ | bani  |  ·  ·  |
| გ | gani  |  ·  ·  |
| დ | doni  |  ·  ·  |
| ე | eni  |  ·  ·  |
| ვ | vini  |  ·  ·  |
| ზ | zeni  |  ·  ·  |
| თ | tani  |  ·  ·  |
| ი | ini  |  ·  ·  |
| კ | k’ani  |  ·  ·  |
| ლ | lasi  |  ·  ·  |
| მ | mani  |  ·  ·  |
| ნ | nari  |  ·  ·  |
| ო | oni  |  ·  ·  |
| პ | p’ari  |  ·  ·  |
| ჟ | zhani  |  ·  ·  |
| რ | rae  |  ·  ·  |
| ს | sani  |  ·  ·  |
| ტ | t’ari  |  ·  ·  |
| უ | uni  |  ·  ·  |
| ფ | pari  |  ·  ·  |
| ქ | kani  |  ·  ·  |
| ღ | ghani  |  ·  ·  |
| ყ | q’ari  |  ·  ·  |
| შ | shini  |  ·  ·  |
| ჩ | chini  |  ·  ·  |
| ც | tsani  |  ·  ·  |
| ძ | dzili  |  ·  ·  |
| წ | ts’ili  |  ·  ·  |
| ჭ | ch’ari  |  ·  ·  |
| ხ | khani  |  ·  ·  |
| ჯ | jani  |  ·  ·  |
| ჰ | hae  |  ·  ·  |

![[Resources/Audio/ka/Script and first phrases.mp3]]

The player above is synthetic speech. Word tracks below work offline.

### All 33 modern letters

Mkhedruli is the ordinary modern script, written left to right. Mtavruli forms are used for display capitals. Older scripts are outside the beginner writing inventory. Start by copying each letter, then reading it in a word.

### Three consonant series

Several stops and affricates distinguish voiced, aspirated and ejective sounds. Romanisation uses an apostrophe for ejectives here: k’, p’, t’, ts’, ch’, q’. The apostrophe is a pronunciation marker, not a separate Georgian letter.

### Read clusters without extra vowels

Consonant clusters can be long. Break them into articulatory movements, then join them slowly; avoid inserting an English or Hindi vowel between every consonant. Georgian vowels are a/e/i/o/u. Stress is comparatively weak and should be learned from phrases.

### Attach a postposition

სახლი → სახლში = house → in the house. Recognise the stem and the attached relation marker.

### Use case and verb together

ბავშვი კითხულობს წიგნს. = The child reads a book. ბავშვმა წაიკითხა წიგნი. = The child read the book. A tense/aspect series can change the case alignment; do not transfer the first pattern mechanically to the second.

### Learn the full verb entry

ვისწავლი = I will learn; ვსწავლობ = I study / am studying. Georgian verbs carry information about participants and screeves; learn forms in a sentence with their noun cases.

**გამარჯობა.**

Hello.

**ქართულს ვსწავლობ.**

I am learning Georgian.

**გთხოვთ, გაიმეოროთ.**

Please repeat.

**რას ნიშნავს ეს სიტყვა?**

What does this word mean?

### Grammar terms in plain English

**Noun** — A word naming a person, thing or idea: student, book, freedom.

**Verb** — A word describing an action or state: read, know, be.

**Subject** — The participant linked to the main verb’s subject pattern. In The student reads a book, the student is the subject.

**Object** — A participant selected by a verb. In The student reads a book, a book is the direct object.

**Agreement** — One word changes to match another, for example an adjective matching a noun’s gender and number.

**Case** — A noun/pronoun form marking its relationship in a sentence. Cases can mark subjects, objects, possession or relations usually expressed by English prepositions.

**Gender** — A grammatical noun class. It does not always describe the sex of a person or any physical property.

**Tense** — A verb system that relates a situation to a time, often past or non-past.

**Aspect** — How a situation is viewed: unfolding, completed, habitual, experienced or in a resulting state.

**Infinitive** — A non-finite verb form often used for a dictionary entry or a complement. It does not by itself give the ordinary person/tense pattern.

**Participle** — A verb-derived form used in compound predicates or as a modifier; its exact function depends on the language and construction.

**Clause** — A unit organised around a predicate. One sentence can contain several clauses.

**Register** — Language choices suited to a situation: casual conversation, polite requests, academic writing or another context.

## Grammar, examples and practice

### Script, sound and case relationships

Mkhedruli has 33 letters in the modern alphabet. Learn ejectives such as კ, პ and ტ separately from aspirated ქ, ფ and თ. Consonant clusters should be practised in meaningful words rather than by inserting English vowels. Georgian cases include nominative, ergative, dative, genitive, instrumental, adverbial and vocative. Their use in subject/object relationships depends partly on verb class and screeve.

**ქართული ენა**

Georgian language Mkhedruli native script.

**თბილისში**

in/to Tbilisi A local relation expressed with -ში; exact direction is supplied by the predicate/context.

#### Independent pronouns

Pronouns identify participants; verbs often also encode participants, allowing omission. Is can refer to he/she/it without English grammatical gender. Georgian verb classes use distinct case alignments.

**მე სააფთიაქოში ვმუშაობ.**

I work in a pharmacy.

**მე დავიღალე, და დაწოლა მინდა.**

I am tired and I want to go to bed.

![[Resources/Audio/ka/Rule 01.mp3]]

[[Georgian#^ka-Q0001|Practise this rule (362 questions)]]

#### Plural forms

Many nouns form a plural with -ები, sometimes with stem changes. Other number/case combinations need their own endings. Quantified phrases do not mechanically follow English plural usage.

**მარიამს ცხენები უყვარს.**

Mary loves horses.

**სახლში თუ დამაგვიანდება წასვლა, ნუ დამელოდები.**

If I should be late getting home, please don't wait up for me.

![[Resources/Audio/ka/Rule 08.mp3]]

[[Georgian#^ka-Q0347|Practise this rule (50 questions)]]

#### Inside/location -ში

Attached -ში expresses many in/into relations. The verb and context distinguish position from movement; the suffix does not encode the full English prepositional phrase by itself.

**შემიძლია წავიდე ავსტრალიაში ტომთან ერთად?**

Can I visit Australia with Tom?

**საშას ქონდა ძლიერი ტკივილი მარჯვენა ხელში.**

Sasha had a sharp pain in her right hand.

![[Resources/Audio/ka/Rule 09.mp3]]

[[Georgian#^ka-Q0397|Practise this rule (50 questions)]]

#### Source -დან

Attached -დან expresses many from/source relations, with stem and linking changes. Learn a word’s actual inflection rather than cutting any final syllable off and adding the suffix.

**მე რუსეთიდან ვარ.**

I am from Russia.

**მე ნორვეგიადან ვარ.**

I am from Norway.

![[Resources/Audio/ka/Rule 10.mp3]]

[[Georgian#^ka-Q0447|Practise this rule (10 questions)]]

#### Possessor and relation forms

Genitive -ის and its stem changes express possession and support other relations. The governing postposition or noun phrase determines the case, not English word order alone.

**ცათამბჯენი ქალაქის ცენტრშია.**

The skyscraper is in the center of the city.

**ის სახლის კაცია.**

He's the man of the house.

![[Resources/Audio/ka/Rule 11.mp3]]

[[Georgian#^ka-Q0457|Practise this rule (8 questions)]]

<details><summary>Why is a one-case-per-English-role chart insufficient?</summary>

Subject and object marking can change with verb class and tense/aspect/mood series.

</details>

<details><summary>How should ejectives be learned?</summary>

With a reliable acoustic/articulatory model and contrasts, not by treating an apostrophe in romanisation as a sound.

</details>

### Verb classes, screeves and argument marking

A screeve is a coordinated set of tense/aspect/mood forms, not just an English tense label. Georgian verbs can index multiple participants. In many transitive patterns, nominative subject in one series contrasts with ergative subject in the aorist series; other verb classes differ. Learn a verb with its principal patterns, arguments and model sentences. Avoid extending a single transitive paradigm to all verbs.

**მე ვკითხულობ წიგნს.**

I am reading a book. A present reading construction.

**მე წავიკითხე წიგნი.**

I read the book through. A bounded past reading construction; forms should be learned as a pattern.

#### Present copula

Copula forms distinguish person and number: ვარ, ხარ, არის, ვართ, ხართ, არიან. Short/attached realisations occur in discourse. Learn a complete predicate rather than replacing every English be identically.

**ესენი არიან სტუდენტები.**

These are students.

**არის ტომი უფრო უფროსი ვიდრე შენ?**

Is Tom older than you?

![[Resources/Audio/ka/Rule 02.mp3]]

[[Georgian#^ka-Q0051|Practise this rule (50 questions)]]

#### Possession predicates

Possession predicates encode participants in a class-specific way. English I have is not a reliable model for the noun cases. Learn the possessor and possessed item together with each form.

**მწვანე პერანგი მაქვს.**

I have a green shirt.

**ბევრი მაქვს გასაკეთებლად.**

I have a lot to do.

![[Resources/Audio/ka/Rule 12.mp3]]

[[Georgian#^ka-Q0465|Practise this rule (24 questions)]]

#### Want predicates

Want predicates have their own experiencer/participant pattern. უნდა also occurs in necessity constructions. Use the complement and context to distinguish desire from should/must meanings.

**მინდა შენთან ლაპარაკი.**

I want to talk to you.

**მინდა ვიყო მსახიობი.**

I want to be an actress.

![[Resources/Audio/ka/Rule 13.mp3]]

[[Georgian#^ka-Q0489|Practise this rule (50 questions)]]

#### Common present verbs

Georgian verbs may encode multiple participants. The present-series noun cases depend on verb class. Memorise a meaningful sentence and compare a small paradigm rather than guessing from one prefix.

**მხოლოდ ვიცი ზოგიერთი სიტყვა და ფრაზა.**

I only know some words and phrases.

**მე არ ვიცი იაპონურად ლაპარაკი.**

I don't speak Japanese.

![[Resources/Audio/ka/Rule 14.mp3]]

[[Georgian#^ka-Q0539|Practise this rule (18 questions)]]

#### Past-series verbs

Past forms belong to different screeves and verb classes. Some active verbs change subject/object case marking in the aorist series. There is no single past ending that can be applied to every Georgian verb.

**50 კაცამდე მოვიდა.**

No more than 50 people came.

**მარი ერთ-ერათი ყველაზე პოპულარული გოგო იყო.**

Mary was not one of the most popular girls.

![[Resources/Audio/ka/Rule 15.mp3]]

[[Georgian#^ka-Q0557|Practise this rule (32 questions)]]

#### Future-series forms

Future forms may involve a preverb and a class-specific stem. Future morphology and argument marking must be learned together. A preverb can also contribute lexical direction or meaning.

**ის წავა სტომატოლოგში.**

He will go to the dentist.

**ძალიან კარგი იქნება.**

He will be very nice.

![[Resources/Audio/ka/Rule 16.mp3]]

[[Georgian#^ka-Q0589|Practise this rule (4 questions)]]

<details><summary>What should a Georgian verb note contain?</summary>

Class, core forms, participant marking, case patterns and verified examples.

</details>

<details><summary>Why is a screeve not identical to an English tense?</summary>

It packages multiple grammatical dimensions and interacts with argument marking.

</details>

### Possession, clauses and questions

Possession and experiencer constructions can differ from English subject-verb patterns. Postpositions and case express relationships. რომ introduces many complement structures; relative and interrogative constructions require attention to clause roles. Word order is flexible but constrained by information structure and emphasis. Flexibility does not mean all orders are pragmatically equivalent.

**ეს მნიშვნელოვანია.**

This is important. Demonstrative with a nominal/adjectival predicate.

**მე ვფიქრობ, რომ ეს სწორია.**

I think that this is correct. რომ introduces a complement proposition.

#### Negation

არ commonly negates; ვერ commonly expresses inability/failure to perform. Their interpretations interact with the verb and context. They are not interchangeable merely because both create a negative meaning.

**უბრალოდ არ ვიცი რა უნდა ვთქვა.**

I just don't know what to say.

**მე დავიფიცე, რომ არასოდეს აღარ დაველაპარაკები.**

I vowed that I would never speak to her again.

![[Resources/Audio/ka/Rule 03.mp3]]

[[Georgian#^ka-Q0101|Practise this rule (50 questions)]]

#### Demonstratives

Demonstrative forms change with case and construction. Es often points to this; is to that or a previously mentioned referent. The following noun’s relation determines an inflected form.

**გელამ თქვა, რომ მამა წავიდა ქალაქში.**

Gela said that Father went into the city.

**ჩვეს სკოლას ჯამში აქვს ოცდაოთხი კლასი.**

Our school has twenty-four classes in all.

![[Resources/Audio/ka/Rule 04.mp3]]

[[Georgian#^ka-Q0151|Practise this rule (50 questions)]]

#### Possessive pronouns

Possessive forms modify a noun and themselves inflect in relevant contexts. Learn the complete phrase. Possession predicates use particular verbal classes and participant marking.

**ჩვენი შეხვედრა შემთხვევითი იყო.**

Our meeting was quite accidental.

**აი შენი გასაღები.**

Here is your key.

![[Resources/Audio/ka/Rule 05.mp3]]

[[Georgian#^ka-Q0201|Practise this rule (50 questions)]]

#### Questions: people and things

Question words inflect for role and case. ვინ asks who; რა asks what, with forms such as რას for an appropriate oblique/object role. Case depends on the verb series and construction.

**მცივა. შეიძლება ფანჯარა დავხურო?**

I'm cold. May I close the window?

**ახალი მაღაზია მომავალ კვირას გაიხსნება.**

The new store is going to open next week.

![[Resources/Audio/ka/Rule 06.mp3]]

[[Georgian#^ka-Q0251|Practise this rule (50 questions)]]

#### Questions: place and manner

Different question forms request location, source, direction, manner, time or reason. The English word where can hide distinctions. Preserve the relation in your answer.

**სად გინდა წასვლა?**

Where do you want to go?

**აი რატომ ინგლისურს სწავლობენ.**

That is what they study English for.

![[Resources/Audio/ka/Rule 07.mp3]]

[[Georgian#^ka-Q0301|Practise this rule (46 questions)]]

#### Content and relative linking

რომ links many content and dependent clauses. Its English translation depends on the construction, and the dependent verb form may reflect the speaker’s attitude or the governing predicate.

**ის ამბობს, რომ გიცნობს.**

He says that he knows you.

**ჩვენ შევთანხმდით, რომ სამსახურში თავს შევიკავებდით მოწევისაგან.**

We agreed to refrain from smoking while we are at work.

![[Resources/Audio/ka/Rule 17.mp3]]

[[Georgian#^ka-Q0593|Practise this rule (22 questions)]]

#### Coordination and contrast

და joins, მაგრამ contrasts, and ან gives an alternative. Keep like structures parallel when coordinating. Their meaning does not replace the case and verb rules inside each clause.

**დილაობით მხოლოდ ტოსტს და ყავას მივირთმევ.**

I only have toast and coffee in the morning.

**წავალთ თქვენთან ერთად.**

We'll go with you.

![[Resources/Audio/ka/Rule 19.mp3]]

[[Georgian#^ka-Q0629|Practise this rule (50 questions)]]

<details><summary>What must a translation preserve beyond word meanings?</summary>

Participant relations, case, verb morphology, information structure and register.

</details>

<details><summary>Identify the connector in the second example.</summary>

რომ introduces the proposition represented as the thought content.

</details>

### Professional requests and uncertainty

Professional language needs precise reference and respectful requests, not a memorised greeting alone. Learn fixed courteous phrases and then vary their objects. შესაძლებელია presents possibility; საჭიროა necessity. Confirm nuanced verb forms with a modern grammar, dictionary or competent speaker. In this language especially, extensive input and feedback matter for reliable production.

**შეგიძლიათ ეს განმარტოთ?**

Could you explain this? A courteous ability-based request.

**დამატებითი ინფორმაცია საჭიროა.**

Additional information is needed. A necessity predicate.

#### Conditions

თუ introduces many if/whether contexts. Verb screeve and surrounding discourse determine the temporal/hypothetical relation. Do not treat the connector alone as a full conditional rule.

**თუ იჩქარებ, დაეწევი.**

If you hurry, you will overtake him.

**კაცი ხარ თუ ქალი?**

Are you a man or a woman?

![[Resources/Audio/ka/Rule 18.mp3]]

[[Georgian#^ka-Q0615|Practise this rule (14 questions)]]

#### Postpositions and stance

Postpositions select a noun relationship/case; ალბათ marks a probability and შეიძლება possibility in relevant constructions. Professional statements should distinguish factual evidence from a tentative reading.

**ეს სიმსუქნის შესახებ წიგნია.**

This is a book about obesity.

**ეს საქართველოს შესახებ წიგნია.**

This is a book about Georgia.

![[Resources/Audio/ka/Rule 20.mp3]]

[[Georgian#^ka-Q0679|Practise this rule (10 questions)]]

<details><summary>Ask a professional to clarify rather than guessing a technical term.</summary>

შეგიძლიათ ეს განმარტოთ? Add the exact term or quotation as the context.

</details>

<details><summary>Why keep a verified sentence bank?</summary>

Complex morphology makes an attested pattern more useful than an invented suffix combination.

</details>

### Professional reading and analysis

Teaching passage: ეს შედეგი მნიშვნელოვანია, მაგრამ დამატებითი კვლევა საჭიროა. მონაცემები უნდა შევამოწმოთ. დასკვნა ჯერ საბოლოო არ არის.
Translation: This result is important, but additional research is needed. We must check the data. The conclusion is not yet final. The passage uses a contrast and an explicit limitation; it is a controlled teaching example, not a real research report.

**დასკვნა ჯერ საბოლოო არ არის.**

The conclusion is not yet final. ჯერ and negation preserve provisional status.

**მონაცემები უნდა შევამოწმოთ.**

We must check the data. Necessity construction with a first-person plural action.

<details><summary>Summarise the practical recommendation.</summary>

Check the data and obtain further research before treating the conclusion as final.

</details>

<details><summary>Annotate an authentic Georgian page.</summary>

Identify predicates, arguments, cases, unknown terms and one clear limitation before producing a paraphrase.

</details>

## Word bank and recordings

1,000 study entries, based on dictionary selections and authored teaching glosses. Learn a word in a phrase; consult the linked entry for additional senses.

<details><summary>Words 1–50</summary>

![[Resources/Audio/ka/Words 0001-0050.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [-გან](https://en.wiktionary.org/wiki/-%E1%83%92%E1%83%90%E1%83%9C#Georgian) | from, out of, of (governs the genitive case; indicates origin, source, material, or cause) | -gan · postp |
| [-თვის](https://en.wiktionary.org/wiki/-%E1%83%97%E1%83%95%E1%83%98%E1%83%A1#Georgian) | for the sake of, for | -tvis · postp |
| [-ო](https://en.wiktionary.org/wiki/-%E1%83%9D#Georgian) | marks a phrase or sentence as the words of a third person; also often marks sayings and proverbs | [o̞] · particle |
| [აბა](https://en.wiktionary.org/wiki/%E1%83%90%E1%83%91%E1%83%90#Georgian) | used to encourage, literally or rhetorically, a particular response from the listener | aba · intj |
| [ანუ](https://en.wiktionary.org/wiki/%E1%83%90%E1%83%9C%E1%83%A3#Georgian) | Used to connect words of similar meaning when the next word clarifies, specifies the previous one; that is, i.e. | anu · conj |
| [არამედ](https://en.wiktionary.org/wiki/%E1%83%90%E1%83%A0%E1%83%90%E1%83%9B%E1%83%94%E1%83%93#Georgian) | On the contrary, but rather, but | aramed · conj |
| [ასევე](https://en.wiktionary.org/wiki/%E1%83%90%E1%83%A1%E1%83%94%E1%83%95%E1%83%94#Georgian) | also, similarly, in the same way | aseve · adv |
| [ბოდვისას](https://en.wiktionary.org/wiki/%E1%83%91%E1%83%9D%E1%83%93%E1%83%95%E1%83%98%E1%83%A1%E1%83%90%E1%83%A1#Georgian) | during the state of delirium | bodvisas · adv |
| [ბოლოს](https://en.wiktionary.org/wiki/%E1%83%91%E1%83%9D%E1%83%9A%E1%83%9D%E1%83%A1#Georgian) | finally, at last, in the end | bolos · adv |
| [ბოშა](https://en.wiktionary.org/wiki/%E1%83%91%E1%83%9D%E1%83%A8%E1%83%90#Georgian) | member of the Bosha, member of the Lom people | boša · noun |
| [განა](https://en.wiktionary.org/wiki/%E1%83%92%E1%83%90%E1%83%9C%E1%83%90#Georgian) | adds a nuance of surprise to questions, and is used when the response is expected to be negative (that is, the speaker expects the proposition in the question to be denied) | gana · particle |
| [გაჭყლეტილი](https://en.wiktionary.org/wiki/%E1%83%92%E1%83%90%E1%83%AD%E1%83%A7%E1%83%9A%E1%83%94%E1%83%A2%E1%83%98%E1%83%9A%E1%83%98#Georgian) | pressed so that something has lost the natural shape | gač̣q̇leṭili · adj |
| [გვერდი](https://en.wiktionary.org/wiki/%E1%83%92%E1%83%95%E1%83%94%E1%83%A0%E1%83%93%E1%83%98#Georgian) | the region of the human body between the armpit and the lowest rib | gverdi · noun |
| [დაჭყლეტილი](https://en.wiktionary.org/wiki/%E1%83%93%E1%83%90%E1%83%AD%E1%83%A7%E1%83%9A%E1%83%94%E1%83%A2%E1%83%98%E1%83%9A%E1%83%98#Georgian) | pressed so that something has lost the natural shape. Usually, direction of the applied pressure is vertical | dač̣q̇leṭili · adj |
| [დახმარება](https://en.wiktionary.org/wiki/%E1%83%93%E1%83%90%E1%83%AE%E1%83%9B%E1%83%90%E1%83%A0%E1%83%94%E1%83%91%E1%83%90#Georgian) | Money given to people from the government to help improve their livelihood | daxmareba · noun |
| [დედანი](https://en.wiktionary.org/wiki/%E1%83%93%E1%83%94%E1%83%93%E1%83%90%E1%83%9C%E1%83%98#Georgian) | the original; that which has not been copied | dedani · noun |
| [ვადა](https://en.wiktionary.org/wiki/%E1%83%95%E1%83%90%E1%83%93%E1%83%90#Georgian) | a crossing point of the sabre | vada · noun |
| [ზაქი](https://en.wiktionary.org/wiki/%E1%83%96%E1%83%90%E1%83%A5%E1%83%98#Georgian) | the young of animals, especially a buffalo baby | zaki · noun |
| [ზეგ](https://en.wiktionary.org/wiki/%E1%83%96%E1%83%94%E1%83%92#Georgian) | on the day after tomorrow, overmorrow | zeg · adv |
| [ზემოდან](https://en.wiktionary.org/wiki/%E1%83%96%E1%83%94%E1%83%9B%E1%83%9D%E1%83%93%E1%83%90%E1%83%9C#Georgian) | from above, from the top | zemodan · adv |
| [ზურგი](https://en.wiktionary.org/wiki/%E1%83%96%E1%83%A3%E1%83%A0%E1%83%92%E1%83%98#Georgian) | back (the rear of the body) | zurgi · noun |
| [თან](https://en.wiktionary.org/wiki/%E1%83%97%E1%83%90%E1%83%9C#Georgian) | with, alongside (mostly the listener) | tan · adv |
| [თურმე ნუ იტყვით](https://en.wiktionary.org/wiki/%E1%83%97%E1%83%A3%E1%83%A0%E1%83%9B%E1%83%94%20%E1%83%9C%E1%83%A3%20%E1%83%98%E1%83%A2%E1%83%A7%E1%83%95%E1%83%98%E1%83%97#Georgian) | usually said when the speaker learns something unexpected or surprising | turme nu iṭq̇vit · phrase |
| [კავკასია](https://en.wiktionary.org/wiki/%E1%83%99%E1%83%90%E1%83%95%E1%83%99%E1%83%90%E1%83%A1%E1%83%98%E1%83%90#Georgian) | Caucasus (region between the Black Sea and the Caspian Sea) | ḳavḳasia · noun |
| [კვადრატულად](https://en.wiktionary.org/wiki/%E1%83%99%E1%83%95%E1%83%90%E1%83%93%E1%83%A0%E1%83%90%E1%83%A2%E1%83%A3%E1%83%9A%E1%83%90%E1%83%93#Georgian) | squarely (in the shape of a square) | ḳvadraṭulad · adv |
| [კიმპალი](https://en.wiktionary.org/wiki/%E1%83%99%E1%83%98%E1%83%9B%E1%83%9E%E1%83%90%E1%83%9A%E1%83%98#Georgian) | The branch of a bunch of grapes that hangs few grapes | ḳimṗali · noun |
| [კუთრი](https://en.wiktionary.org/wiki/%E1%83%99%E1%83%A3%E1%83%97%E1%83%A0%E1%83%98#Georgian) | specific (a value divided by the mass) | ḳutri · adj |
| [კუპატი](https://en.wiktionary.org/wiki/%E1%83%99%E1%83%A3%E1%83%9E%E1%83%90%E1%83%A2%E1%83%98#Georgian) | sausage that in addition has pomegranate and is encased in a casing made from the intestine | ḳuṗaṭi · noun |
| [ლარი](https://en.wiktionary.org/wiki/%E1%83%9A%E1%83%90%E1%83%A0%E1%83%98#Georgian) | lari, the national currency of Georgia, divided into 100 tetri | lari · noun |
| [მაზეგ](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%90%E1%83%96%E1%83%94%E1%83%92#Georgian) | the day after the day after tomorrow, third day after today | mazeg · adv |
| [მარანი](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%90%E1%83%A0%E1%83%90%E1%83%9C%E1%83%98#Georgian) | building, or space within a building, intended for the storage of wine | marani · noun |
| [მარცხნივ](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%90%E1%83%A0%E1%83%AA%E1%83%AE%E1%83%9C%E1%83%98%E1%83%95#Georgian) | to the left, to the left side, leftwards | marcxniv · adv |
| [მატური](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%90%E1%83%A2%E1%83%A3%E1%83%A0%E1%83%98#Georgian) | a quarter of the cemetery, where the dead of one family are buried | maṭuri · noun |
| [მაშინ](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%90%E1%83%A8%E1%83%98%E1%83%9C#Georgian) | At the time or immediately after something happened or will happen; in that case, under those conditions; then | mašin · adv |
| [მიერ](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%98%E1%83%94%E1%83%A0#Georgian) | by, by means of, through (governs the genitive case; expresses the agent in passive or participial constructions) | mier · postp |
| [მოდი](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%9D%E1%83%93%E1%83%98#Georgian) | Intensifies the expression of a desire or order by adding a nuance of pleading, and is equivalent to the English let’s. | modi · particle |
| [მოშორებით](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%9D%E1%83%A8%E1%83%9D%E1%83%A0%E1%83%94%E1%83%91%E1%83%98%E1%83%97#Georgian) | aloof, apart, out-of-the-way | mošorebit · adv |
| [ნომერი](https://en.wiktionary.org/wiki/%E1%83%9C%E1%83%9D%E1%83%9B%E1%83%94%E1%83%A0%E1%83%98#Georgian) | number indicating the position of something in an order or list | nomeri · noun |
| [ნუ](https://en.wiktionary.org/wiki/%E1%83%9C%E1%83%A3#Georgian) | Expresses negation combined with prohibition; corresponds to the English ‘do not’. | nu · particle |
| [ნუთუ](https://en.wiktionary.org/wiki/%E1%83%9C%E1%83%A3%E1%83%97%E1%83%A3#Georgian) | Used in interrogative sentences to add a nuance of doubt, surprise, or astonishment, implying that the speaker thinks of the circumstance as improbable. | nutu · particle |
| [პირი](https://en.wiktionary.org/wiki/%E1%83%9E%E1%83%98%E1%83%A0%E1%83%98#Georgian) | mouth (opening in the face) | ṗiri · noun |
| [სარეცელზე](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%90%E1%83%A0%E1%83%94%E1%83%AA%E1%83%94%E1%83%9A%E1%83%96%E1%83%94#Georgian) | on the bed | sarecelze · noun |
| [სიზმარი](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%98%E1%83%96%E1%83%9B%E1%83%90%E1%83%A0%E1%83%98#Georgian) | dream (imaginary events seen in the mind while sleeping) | sizmari · noun |
| [სულ](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%A3%E1%83%9A#Georgian) | completely, entirely, all, the whole of | sul · adv |
| [ტაიური](https://en.wiktionary.org/wiki/%E1%83%A2%E1%83%90%E1%83%98%E1%83%A3%E1%83%A0%E1%83%98#Georgian) | the Thai language | ṭaiuri · noun |
| [უბრობა](https://en.wiktionary.org/wiki/%E1%83%A3%E1%83%91%E1%83%A0%E1%83%9D%E1%83%91%E1%83%90#Georgian) | The state of not talking to someone, especially due to a past bad deed or mistreatment | ubroba · noun |
| [უკაცრავად პასუხია](https://en.wiktionary.org/wiki/%E1%83%A3%E1%83%99%E1%83%90%E1%83%AA%E1%83%A0%E1%83%90%E1%83%95%E1%83%90%E1%83%93%20%E1%83%9E%E1%83%90%E1%83%A1%E1%83%A3%E1%83%AE%E1%83%98%E1%83%90#Georgian) | Used to apologize for the use of profanity or unpleasant phrase. | uḳacravad ṗasuxia · phrase |
| [ფესვი](https://en.wiktionary.org/wiki/%E1%83%A4%E1%83%94%E1%83%A1%E1%83%95%E1%83%98#Georgian) | root (the part of plant) | pesvi · noun |
| [ქართული](https://en.wiktionary.org/wiki/%E1%83%A5%E1%83%90%E1%83%A0%E1%83%97%E1%83%A3%E1%83%9A%E1%83%98#Georgian) | Of, from, or pertaining to the country of Georgia; Georgian | kartuli · adj |
| [ქვევრი](https://en.wiktionary.org/wiki/%E1%83%A5%E1%83%95%E1%83%94%E1%83%95%E1%83%A0%E1%83%98#Georgian) | large earthenware vessel used for the fermentation and storage of wine, often buried below ground level or set into the floors of large wine cellars | kvevri · noun |

</details>

<details><summary>Words 51–100</summary>

![[Resources/Audio/ka/Words 0051-0100.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [ღაბაბი](https://en.wiktionary.org/wiki/%E1%83%A6%E1%83%90%E1%83%91%E1%83%90%E1%83%91%E1%83%98#Georgian) | dewlap (pendulous skin under the neck) | ɣababi · noun |
| [შუქი](https://en.wiktionary.org/wiki/%E1%83%A8%E1%83%A3%E1%83%A5%E1%83%98#Georgian) | light (of the sun or other source) | šuki · noun |
| [ჩაგეთვალა](https://en.wiktionary.org/wiki/%E1%83%A9%E1%83%90%E1%83%92%E1%83%94%E1%83%97%E1%83%95%E1%83%90%E1%83%9A%E1%83%90#Georgian) | Used to approve the joke said by addressee | čagetvala · verb |
| [ცრემლი](https://en.wiktionary.org/wiki/%E1%83%AA%E1%83%A0%E1%83%94%E1%83%9B%E1%83%9A%E1%83%98#Georgian) | tear (liquid from the eyes) | cremli · noun |
| [ცხელ გულზე](https://en.wiktionary.org/wiki/%E1%83%AA%E1%83%AE%E1%83%94%E1%83%9A%20%E1%83%92%E1%83%A3%E1%83%9A%E1%83%96%E1%83%94#Georgian) | during the affect (excited, irritated etc. state) | cxel gulze · adv |
| [ხელიდან წასვლა](https://en.wiktionary.org/wiki/%E1%83%AE%E1%83%94%E1%83%9A%E1%83%98%E1%83%93%E1%83%90%E1%83%9C%20%E1%83%AC%E1%83%90%E1%83%A1%E1%83%95%E1%83%9A%E1%83%90#Georgian) | become morally wrong, deviate from the right way of life. | xelidan c̣asvla · noun |
| [ხიშტი](https://en.wiktionary.org/wiki/%E1%83%AE%E1%83%98%E1%83%A8%E1%83%A2%E1%83%98#Georgian) | the penalty in a certain card game (particularly, ჯოკერი (ǯoḳeri)) for taking no tricks while having bet one or more tricks | xišṭi · noun |
| [ხოლმე](https://en.wiktionary.org/wiki/%E1%83%AE%E1%83%9D%E1%83%9A%E1%83%9B%E1%83%94#Georgian) | Used to mark repetitive or habitual action. In past references, it is often accompanied by the conditional screeve, and corresponds to the English ‘used to, was wont to’. | xolme · particle |
| [ჯარი](https://en.wiktionary.org/wiki/%E1%83%AF%E1%83%90%E1%83%A0%E1%83%98#Georgian) | army, host (military force, not necessarily the armed forces of a nation) | ǯari · noun |
| [ჯურღმული](https://en.wiktionary.org/wiki/%E1%83%AF%E1%83%A3%E1%83%A0%E1%83%A6%E1%83%9B%E1%83%A3%E1%83%9A%E1%83%98#Georgian) | well (hole sunk into the ground as a source of water) | ǯurɣmuli · noun |
| [ჰოროველო](https://en.wiktionary.org/wiki/%E1%83%B0%E1%83%9D%E1%83%A0%E1%83%9D%E1%83%95%E1%83%94%E1%83%9A%E1%83%9D#Georgian) | the song sung during the tilling of soil intended to cheer up the animals and the peasants | horovelo · noun |
| [გულუხვი](https://en.wiktionary.org/wiki/%E1%83%92%E1%83%A3%E1%83%9A%E1%83%A3%E1%83%AE%E1%83%95%E1%83%98#Georgian) | generous (willing to give and share unsparingly) | guluxvi · adj |
| [იგი](https://en.wiktionary.org/wiki/%E1%83%98%E1%83%92%E1%83%98#Georgian) | he, she, it (third-person singular masculine, feminine and gender neutral pronoun) | igi · pron |
| [ინგლისური](https://en.wiktionary.org/wiki/%E1%83%98%E1%83%9C%E1%83%92%E1%83%9A%E1%83%98%E1%83%A1%E1%83%A3%E1%83%A0%E1%83%98#Georgian) | English (inanimate things and non-human animals) | inglisuri · adj |
| [ლავაში](https://en.wiktionary.org/wiki/%E1%83%9A%E1%83%90%E1%83%95%E1%83%90%E1%83%A8%E1%83%98#Georgian) | lavash (a soft, thin flatbread made with flour, water, yeast, and salt, baked in a tandoor, and sometimes sprinkled with sesame seeds or poppy seeds before baking) | lavaši · noun |
| [მაწონი](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%90%E1%83%AC%E1%83%9D%E1%83%9C%E1%83%98#Georgian) | matzoon, matsoni (a yoghurt-like dairy product of Armenian origin, made from fermented cow's milk, and popular mainly in Armenia and Georgia) | mac̣oni · noun |
| [მირონი](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%98%E1%83%A0%E1%83%9D%E1%83%9C%E1%83%98#Georgian) | chrism (mixture of oil and balm) | mironi · noun |
| [ნართანიანი](https://en.wiktionary.org/wiki/%E1%83%9C%E1%83%90%E1%83%A0%E1%83%97%E1%83%90%E1%83%9C%E1%83%98%E1%83%90%E1%83%9C%E1%83%98#Georgian) | containing ნარ (nar) and თან (tan) | nartaniani · adj |
| [ნეტა](https://en.wiktionary.org/wiki/%E1%83%9C%E1%83%94%E1%83%A2%E1%83%90#Georgian) | expresses wishes and desires; how good it would be if…!, how I wish that…!, if only | neṭa · particle |
| [ოქრომკედი](https://en.wiktionary.org/wiki/%E1%83%9D%E1%83%A5%E1%83%A0%E1%83%9D%E1%83%9B%E1%83%99%E1%83%94%E1%83%93%E1%83%98#Georgian) | braid made by golden and silken threads | okromḳedi · noun |
| [პორტუგალიური](https://en.wiktionary.org/wiki/%E1%83%9E%E1%83%9D%E1%83%A0%E1%83%A2%E1%83%A3%E1%83%92%E1%83%90%E1%83%9A%E1%83%98%E1%83%A3%E1%83%A0%E1%83%98#Georgian) | Portuguese (inanimate things and non-human animals) | ṗorṭugaliuri · noun |
| [რთველი](https://en.wiktionary.org/wiki/%E1%83%A0%E1%83%97%E1%83%95%E1%83%94%E1%83%9A%E1%83%98#Georgian) | Rtveli, Georgian traditional grape harvest and associated festivities | rtveli · noun |
| [სალამური](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%90%E1%83%9A%E1%83%90%E1%83%9B%E1%83%A3%E1%83%A0%E1%83%98#Georgian) | an ancient flute of Eastern Georgia, mainly found around Kartli, Kakheti, Meskheti, Tusheti, and Pshavi; it may be tongueless (with 5 or 6 finger holes) or tongued (with 6 or 7 finger holes) | salamuri · noun |
| [ტომატი](https://en.wiktionary.org/wiki/%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%90%E1%83%A2%E1%83%98#Georgian) | tomato concentrate from which sauces and such are made | ṭomaṭi · noun |
| [უწიგნური](https://en.wiktionary.org/wiki/%E1%83%A3%E1%83%AC%E1%83%98%E1%83%92%E1%83%9C%E1%83%A3%E1%83%A0%E1%83%98#Georgian) | illiterate (Lacking of familiarity with language and literature, or having little formal education.) | uc̣ignuri · adj |
| [ფრჩხილი](https://en.wiktionary.org/wiki/%E1%83%A4%E1%83%A0%E1%83%A9%E1%83%AE%E1%83%98%E1%83%9A%E1%83%98#Georgian) | nail (on fingers and toes) | prčxili · noun |
| [ყასაბი](https://en.wiktionary.org/wiki/%E1%83%A7%E1%83%90%E1%83%A1%E1%83%90%E1%83%91%E1%83%98#Georgian) | butcher (a person who prepares and sells meat) | q̇asabi · noun |
| [ჩაქაფული](https://en.wiktionary.org/wiki/%E1%83%A9%E1%83%90%E1%83%A5%E1%83%90%E1%83%A4%E1%83%A3%E1%83%9A%E1%83%98#Georgian) | chakapuli (a Georgian dish, made from onions, lamb chops, dry white wine, tarragon leaves, tkemali sauce (plum sauce), mixed fresh herbs (parsley, mint, dill, cilantro), garlic and salt) | čakapuli · noun |
| [ჩვენ](https://en.wiktionary.org/wiki/%E1%83%A9%E1%83%95%E1%83%94%E1%83%9C#Georgian) | we (with no distinction between inclusive and exclusive we) | čven · pron |
| [წაწლობა](https://en.wiktionary.org/wiki/%E1%83%AC%E1%83%90%E1%83%AC%E1%83%9A%E1%83%9D%E1%83%91%E1%83%90#Georgian) | an obsolete sexual practice in Pshavi according to which a young boy and girl would sleep together without actually having sex, which was strictly prohibited | c̣ac̣loba · noun |
| [ჭერამი](https://en.wiktionary.org/wiki/%E1%83%AD%E1%83%94%E1%83%A0%E1%83%90%E1%83%9B%E1%83%98#Georgian) | a variety of apricot, Prunus armeniaca syn. Armeniaca vulgaris (fruit and tree) | č̣erami · noun |
| [ჭუნირი](https://en.wiktionary.org/wiki/%E1%83%AD%E1%83%A3%E1%83%9C%E1%83%98%E1%83%A0%E1%83%98#Georgian) | a bowed, three-stringed viol-type instrument from Svaneti, Racha, Khevsureti and Tusheti | č̣uniri · noun |
| [ხარჩო](https://en.wiktionary.org/wiki/%E1%83%AE%E1%83%90%E1%83%A0%E1%83%A9%E1%83%9D#Georgian) | kharcho (a spicy meat and vegetables Georgian soup with grated walnuts) | xarčo · noun |
| [აბიტურიენტი](https://en.wiktionary.org/wiki/%E1%83%90%E1%83%91%E1%83%98%E1%83%A2%E1%83%A3%E1%83%A0%E1%83%98%E1%83%94%E1%83%9C%E1%83%A2%E1%83%98#Georgian) | college applicant, candidate for qualifying examination for admission to a university | abiṭurienṭi · noun |
| [ამპლუა](https://en.wiktionary.org/wiki/%E1%83%90%E1%83%9B%E1%83%9E%E1%83%9A%E1%83%A3%E1%83%90#Georgian) | certain types of roles, that an actor/actress fits most of all | amṗlua · noun |
| [ასანთი](https://en.wiktionary.org/wiki/%E1%83%90%E1%83%A1%E1%83%90%E1%83%9C%E1%83%97%E1%83%98#Georgian) | match (for lighting) | asanti · noun |
| [აღბეჭდილი](https://en.wiktionary.org/wiki/%E1%83%90%E1%83%A6%E1%83%91%E1%83%94%E1%83%AD%E1%83%93%E1%83%98%E1%83%9A%E1%83%98#Georgian) | something that has been imprinted | aɣbeč̣dili · adj |
| [ბადე](https://en.wiktionary.org/wiki/%E1%83%91%E1%83%90%E1%83%93%E1%83%94#Georgian) | net (used for catching fish) | bade · noun |
| [ბოძი](https://en.wiktionary.org/wiki/%E1%83%91%E1%83%9D%E1%83%AB%E1%83%98#Georgian) | post, pole (e.g. for blocking vehicles) | boʒi · noun |
| [გამაცხელებელი](https://en.wiktionary.org/wiki/%E1%83%92%E1%83%90%E1%83%9B%E1%83%90%E1%83%AA%E1%83%AE%E1%83%94%E1%83%9A%E1%83%94%E1%83%91%E1%83%94%E1%83%9A%E1%83%98#Georgian) | that which heats | gamacxelebeli · noun |
| [გარდა](https://en.wiktionary.org/wiki/%E1%83%92%E1%83%90%E1%83%A0%E1%83%93%E1%83%90#Georgian) | besides; except for | garda · prep |
| [გომი](https://en.wiktionary.org/wiki/%E1%83%92%E1%83%9D%E1%83%9B%E1%83%98#Georgian) | barn or stable for overwintering cattle | gomi · noun |
| [დამერხა](https://en.wiktionary.org/wiki/%E1%83%93%E1%83%90%E1%83%9B%E1%83%94%E1%83%A0%E1%83%AE%E1%83%90#Georgian) | by saying it, a teller indicates that he or she is in a bad situation | damerxa · verb |
| [ეგ](https://en.wiktionary.org/wiki/%E1%83%94%E1%83%92#Georgian) | that | eg · pron |
| [ვერ](https://en.wiktionary.org/wiki/%E1%83%95%E1%83%94%E1%83%A0#Georgian) | Used to negate an action that one is unable to perform; can't | ver · verb |
| [თავისთვის](https://en.wiktionary.org/wiki/%E1%83%97%E1%83%90%E1%83%95%E1%83%98%E1%83%A1%E1%83%97%E1%83%95%E1%83%98%E1%83%A1#Georgian) | For himself/herself/itself | tavistvis · adv |
| [თამაში](https://en.wiktionary.org/wiki/%E1%83%97%E1%83%90%E1%83%9B%E1%83%90%E1%83%A8%E1%83%98#Georgian) | game (activity for entertainment) | tamaši · noun |
| [იმაზე](https://en.wiktionary.org/wiki/%E1%83%98%E1%83%9B%E1%83%90%E1%83%96%E1%83%94#Georgian) | on that, about that, thereupon | imaze · adv |
| [ისე](https://en.wiktionary.org/wiki/%E1%83%98%E1%83%A1%E1%83%94#Georgian) | in that way, in that manner | ise · adv |
| [ისევე](https://en.wiktionary.org/wiki/%E1%83%98%E1%83%A1%E1%83%94%E1%83%95%E1%83%94#Georgian) | in that same way | iseve · adv |

</details>

<details><summary>Words 101–150</summary>

![[Resources/Audio/ka/Words 0101-0150.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [იქვე](https://en.wiktionary.org/wiki/%E1%83%98%E1%83%A5%E1%83%95%E1%83%94#Georgian) | in that very place, ibidem | ikve · adv |
| [იქიდან](https://en.wiktionary.org/wiki/%E1%83%98%E1%83%A5%E1%83%98%E1%83%93%E1%83%90%E1%83%9C#Georgian) | from there (from that place) | ikidan · adv |
| [იქით](https://en.wiktionary.org/wiki/%E1%83%98%E1%83%A5%E1%83%98%E1%83%97#Georgian) | over there, to that place | ikit · adv |
| [კვარი](https://en.wiktionary.org/wiki/%E1%83%99%E1%83%95%E1%83%90%E1%83%A0%E1%83%98#Georgian) | Fragment of spruce or pine easily set on fire (used to be an alternative for candle in villages) | ḳvari · noun |
| [მაგალითად](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%90%E1%83%92%E1%83%90%E1%83%9A%E1%83%98%E1%83%97%E1%83%90%E1%83%93#Georgian) | for example | magalitad · adv |
| [მეგრული](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%94%E1%83%92%E1%83%A0%E1%83%A3%E1%83%9A%E1%83%98#Georgian) | Mingrelian (refers to objects; for humans see მეგრელი (megreli)) | megruli · noun |
| [რატომ](https://en.wiktionary.org/wiki/%E1%83%A0%E1%83%90%E1%83%A2%E1%83%9D%E1%83%9B#Georgian) | why (interrogative adverb asking for a reason, cause, or explanation) | raṭom · adv |
| [რომ](https://en.wiktionary.org/wiki/%E1%83%A0%E1%83%9D%E1%83%9B#Georgian) | that | rom · conj |
| [სამარხვო](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%90%E1%83%9B%E1%83%90%E1%83%A0%E1%83%AE%E1%83%95%E1%83%9D#Georgian) | Food that can be eaten during fast | samarxvo · adj |
| [ყავარჯენი](https://en.wiktionary.org/wiki/%E1%83%A7%E1%83%90%E1%83%95%E1%83%90%E1%83%A0%E1%83%AF%E1%83%94%E1%83%9C%E1%83%98#Georgian) | crutch (for walking) | q̇avarǯeni · noun |
| [შეიძლება](https://en.wiktionary.org/wiki/%E1%83%A8%E1%83%94%E1%83%98%E1%83%AB%E1%83%9A%E1%83%94%E1%83%91%E1%83%90#Georgian) | it is possible, it may be that | šeiʒleba · particle |
| [ჭაშნიკი](https://en.wiktionary.org/wiki/%E1%83%AD%E1%83%90%E1%83%A8%E1%83%9C%E1%83%98%E1%83%99%E1%83%98#Georgian) | a small piece of wine intended for gustation | č̣ašniḳi · noun |
| [ხაჭო](https://en.wiktionary.org/wiki/%E1%83%AE%E1%83%90%E1%83%AD%E1%83%9D#Georgian) | curd (part of milk that coagulates) | xač̣o · noun |
| [ხეჩაკალი](https://en.wiktionary.org/wiki/%E1%83%AE%E1%83%94%E1%83%A9%E1%83%90%E1%83%99%E1%83%90%E1%83%9A%E1%83%98#Georgian) | prop (for fruit tree) | xečaḳali · noun |
| [ხუხულა](https://en.wiktionary.org/wiki/%E1%83%AE%E1%83%A3%E1%83%AE%E1%83%A3%E1%83%9A%E1%83%90#Georgian) | child-made house for playing | xuxula · noun |
| [არაფერს](https://en.wiktionary.org/wiki/%E1%83%90%E1%83%A0%E1%83%90%E1%83%A4%E1%83%94%E1%83%A0%E1%83%A1#Georgian) | you're welcome | arapers · intj |
| [არაფრის](https://en.wiktionary.org/wiki/%E1%83%90%E1%83%A0%E1%83%90%E1%83%A4%E1%83%A0%E1%83%98%E1%83%A1#Georgian) | you're welcome | arapris · intj |
| [გამარჯობა](https://en.wiktionary.org/wiki/%E1%83%92%E1%83%90%E1%83%9B%E1%83%90%E1%83%A0%E1%83%AF%E1%83%9D%E1%83%91%E1%83%90#Georgian) | hello, how do you do, good afternoon | gamarǯoba · intj |
| [გვფრცქვნით](https://en.wiktionary.org/wiki/%E1%83%92%E1%83%95%E1%83%A4%E1%83%A0%E1%83%AA%E1%83%A5%E1%83%95%E1%83%9C%E1%83%98%E1%83%97#Georgian) | second-person plural present indicative, taking first-person plural as an object, of ფრცქვნის (prckvnis) (you (plural) peel us) | gvprckvnit · verb |
| [გთხოვთ](https://en.wiktionary.org/wiki/%E1%83%92%E1%83%97%E1%83%AE%E1%83%9D%E1%83%95%E1%83%97#Georgian) | please, I ask...; I'm begging you | gtxovt · verb |
| [გმადლობთ](https://en.wiktionary.org/wiki/%E1%83%92%E1%83%9B%E1%83%90%E1%83%93%E1%83%9A%E1%83%9D%E1%83%91%E1%83%97#Georgian) | thank you (to more than one person or formally to one person) (expression of gratitude) | gmadlobt · intj |
| [თქვენ](https://en.wiktionary.org/wiki/%E1%83%97%E1%83%A5%E1%83%95%E1%83%94%E1%83%9C#Georgian) | you (plural, or polite singular) | tkven · pron |
| [ინგლისური იცით](https://en.wiktionary.org/wiki/%E1%83%98%E1%83%9C%E1%83%92%E1%83%9A%E1%83%98%E1%83%A1%E1%83%A3%E1%83%A0%E1%83%98%20%E1%83%98%E1%83%AA%E1%83%98%E1%83%97#Georgian) | Do you speak English? | inglisuri icit? · phrase |
| [მომენატრე](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%9D%E1%83%9B%E1%83%94%E1%83%9C%E1%83%90%E1%83%A2%E1%83%A0%E1%83%94#Georgian) | I miss you | momenaṭre · verb |
| [მომენატრებით](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%9D%E1%83%9B%E1%83%94%E1%83%9C%E1%83%90%E1%83%A2%E1%83%A0%E1%83%94%E1%83%91%E1%83%98%E1%83%97#Georgian) | I will miss you (pl.) | momenaṭrebit · verb |
| [როგორა ხარ](https://en.wiktionary.org/wiki/%E1%83%A0%E1%83%9D%E1%83%92%E1%83%9D%E1%83%A0%E1%83%90%20%E1%83%AE%E1%83%90%E1%83%A0#Georgian) | how are you? | rogora xar · phrase |
| [შენ](https://en.wiktionary.org/wiki/%E1%83%A8%E1%83%94%E1%83%9C#Georgian) | you (singular, personal) | šen · pron |
| [ჰგავხართ](https://en.wiktionary.org/wiki/%E1%83%B0%E1%83%92%E1%83%90%E1%83%95%E1%83%AE%E1%83%90%E1%83%A0%E1%83%97#Georgian) | you (formal or plural) resemble her/it/him | hgavxart · verb |
| [-თან](https://en.wiktionary.org/wiki/-%E1%83%97%E1%83%90%E1%83%9C#Georgian) | with (suffixed to nouns in dative case) | -tan · postp |
| [-თან ერთად](https://en.wiktionary.org/wiki/-%E1%83%97%E1%83%90%E1%83%9C%20%E1%83%94%E1%83%A0%E1%83%97%E1%83%90%E1%83%93#Georgian) | together with | -tan ertad · postp |
| [ამაში](https://en.wiktionary.org/wiki/%E1%83%90%E1%83%9B%E1%83%90%E1%83%A8%E1%83%98#Georgian) | postpositional form with -ში of ეს (es): in this, herein | amaši · pron |
| [გარემოება](https://en.wiktionary.org/wiki/%E1%83%92%E1%83%90%E1%83%A0%E1%83%94%E1%83%9B%E1%83%9D%E1%83%94%E1%83%91%E1%83%90#Georgian) | circumstance, condition, factor (a fact or event connected with or having an effect on a situation) | garemoeba · noun |
| [დომხალი](https://en.wiktionary.org/wiki/%E1%83%93%E1%83%9D%E1%83%9B%E1%83%AE%E1%83%90%E1%83%9A%E1%83%98#Georgian) | Thickened matsoni by boiling with some greens | domxali · noun |
| [კირიანი](https://en.wiktionary.org/wiki/%E1%83%99%E1%83%98%E1%83%A0%E1%83%98%E1%83%90%E1%83%9C%E1%83%98#Georgian) | Consisting of, built with, or containing lime (calcium-based substance) | ḳiriani · adj |
| [კუბდარი](https://en.wiktionary.org/wiki/%E1%83%99%E1%83%A3%E1%83%91%E1%83%93%E1%83%90%E1%83%A0%E1%83%98#Georgian) | like a khachapuri, but with meat instead of cheese | ḳubdari · noun |
| [ჟღმურტლი](https://en.wiktionary.org/wiki/%E1%83%9F%E1%83%A6%E1%83%9B%E1%83%A3%E1%83%A0%E1%83%A2%E1%83%9A%E1%83%98#Georgian) | kind of misty rain characterized with small particles; drizzle | žɣmurṭli · noun |
| [რისთვის](https://en.wiktionary.org/wiki/%E1%83%A0%E1%83%98%E1%83%A1%E1%83%97%E1%83%95%E1%83%98%E1%83%A1#Georgian) | postpositional suffixed with -თვის of რა (ra) | ristvis · pron |
| [ფენოვანი](https://en.wiktionary.org/wiki/%E1%83%A4%E1%83%94%E1%83%9C%E1%83%9D%E1%83%95%E1%83%90%E1%83%9C%E1%83%98#Georgian) | a kind of khachapuri, made with more ingredients in flour than khachapuri | penovani · noun |
| [ჭანჭური](https://en.wiktionary.org/wiki/%E1%83%AD%E1%83%90%E1%83%9C%E1%83%AD%E1%83%A3%E1%83%A0%E1%83%98#Georgian) | a cultivar of plum (Prunus domestica) indigenous to Georgia with a small, juicy, slightly tart fruit | č̣anč̣uri · noun |
| [ხოლო](https://en.wiktionary.org/wiki/%E1%83%AE%E1%83%9D%E1%83%9A%E1%83%9D#Georgian) | however, whereas (contrasts whatever follows with something mentioned earlier) | xolo · particle |
| [ამაზე](https://en.wiktionary.org/wiki/%E1%83%90%E1%83%9B%E1%83%90%E1%83%96%E1%83%94#Georgian) | on this, about this, hereof | amaze · adv |
| [აქამდე](https://en.wiktionary.org/wiki/%E1%83%90%E1%83%A5%E1%83%90%E1%83%9B%E1%83%93%E1%83%94#Georgian) | so far, until now (until this time) | akamde · adv |
| [აქეთ](https://en.wiktionary.org/wiki/%E1%83%90%E1%83%A5%E1%83%94%E1%83%97#Georgian) | over here, to this place | aket · adv |
| [ეს](https://en.wiktionary.org/wiki/%E1%83%94%E1%83%A1#Georgian) | this | es · det |
| [აქვს](https://en.wiktionary.org/wiki/%E1%83%90%E1%83%A5%E1%83%95%E1%83%A1#Georgian) | to have | akvs · verb |
| [უნდა](https://en.wiktionary.org/wiki/%E1%83%A3%E1%83%9C%E1%83%93%E1%83%90#Georgian) | have to, should, ought to, need, must | unda · particle |
| [არ](https://en.wiktionary.org/wiki/%E1%83%90%E1%83%A0#Georgian) | not, no | ar · particle |
| [აღარ](https://en.wiktionary.org/wiki/%E1%83%90%E1%83%A6%E1%83%90%E1%83%A0#Georgian) | no longer, not anymore | aɣar · adv |
| [ნუღარ](https://en.wiktionary.org/wiki/%E1%83%9C%E1%83%A3%E1%83%A6%E1%83%90%E1%83%A0#Georgian) | Do not ... any longer | nuɣar · particle |
| [-დან](https://en.wiktionary.org/wiki/-%E1%83%93%E1%83%90%E1%83%9C#Georgian) | from, out of, since | -dan · postp |

</details>

<details><summary>Words 151–200</summary>

![[Resources/Audio/ka/Words 0151-0200.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [აქედან](https://en.wiktionary.org/wiki/%E1%83%90%E1%83%A5%E1%83%94%E1%83%93%E1%83%90%E1%83%9C#Georgian) | from here | akedan · adv |
| [გარედან](https://en.wiktionary.org/wiki/%E1%83%92%E1%83%90%E1%83%A0%E1%83%94%E1%83%93%E1%83%90%E1%83%9C#Georgian) | outside, but, out, outdoors, outside, outward, outwardly, outwards, without | garedan · adv |
| [დროდადრო](https://en.wiktionary.org/wiki/%E1%83%93%E1%83%A0%E1%83%9D%E1%83%93%E1%83%90%E1%83%93%E1%83%A0%E1%83%9D#Georgian) | sometimes, from time to time, intermittently | drodadro · adv |
| [ლასტი](https://en.wiktionary.org/wiki/%E1%83%9A%E1%83%90%E1%83%A1%E1%83%A2%E1%83%98#Georgian) | a fence plaited from wicker | lasṭi · noun |
| [მაგრამ](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%90%E1%83%92%E1%83%A0%E1%83%90%E1%83%9B#Georgian) | but | magram · conj |
| [მარა](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%90%E1%83%A0%E1%83%90#Georgian) | but | mara · conj |
| [მჭადი](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%AD%E1%83%90%E1%83%93%E1%83%98#Georgian) | a Georgian dish, made from maize flour | mč̣adi · noun |
| [სომეხი](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%9D%E1%83%9B%E1%83%94%E1%83%AE%E1%83%98#Georgian) | Armenian, a person from Armenia or of Armenian descent | somexi · noun |
| [სულუგუნი](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%A3%E1%83%9A%E1%83%A3%E1%83%92%E1%83%A3%E1%83%9C%E1%83%98#Georgian) | sulguni cheese (a pickled Georgian cheese), originally from Mingrelia | suluguni · noun |
| [შქმერული](https://en.wiktionary.org/wiki/%E1%83%A8%E1%83%A5%E1%83%9B%E1%83%94%E1%83%A0%E1%83%A3%E1%83%9A%E1%83%98#Georgian) | A Georgian dish, made from bird (hen, etc) | škmeruli · noun |
| [ჩაი](https://en.wiktionary.org/wiki/%E1%83%A9%E1%83%90%E1%83%98#Georgian) | tea (drink made from leaves of tea plant) | čai · noun |
| [ხევსური](https://en.wiktionary.org/wiki/%E1%83%AE%E1%83%94%E1%83%95%E1%83%A1%E1%83%A3%E1%83%A0%E1%83%98#Georgian) | Person from Khevsureti | xevsuri · noun |
| [ბებიაშენი](https://en.wiktionary.org/wiki/%E1%83%91%E1%83%94%E1%83%91%E1%83%98%E1%83%90%E1%83%A8%E1%83%94%E1%83%9C%E1%83%98#Georgian) | your grandmother | bebiašeni · noun |
| [თქვენი](https://en.wiktionary.org/wiki/%E1%83%97%E1%83%A5%E1%83%95%E1%83%94%E1%83%9C%E1%83%98#Georgian) | your, yours | tkveni · pron |
| [შენი](https://en.wiktionary.org/wiki/%E1%83%A8%E1%83%94%E1%83%9C%E1%83%98#Georgian) | your (singular), yours | šeni · pron |
| [ყველა](https://en.wiktionary.org/wiki/%E1%83%A7%E1%83%95%E1%83%94%E1%83%9A%E1%83%90#Georgian) | all | q̇vela · noun |
| [მისი](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%98%E1%83%A1%E1%83%98#Georgian) | his/her/its | misi · pron |
| [ისინი](https://en.wiktionary.org/wiki/%E1%83%98%E1%83%A1%E1%83%98%E1%83%9C%E1%83%98#Georgian) | they, those | isini · pron |
| [არავინ](https://en.wiktionary.org/wiki/%E1%83%90%E1%83%A0%E1%83%90%E1%83%95%E1%83%98%E1%83%9C#Georgian) | nobody, no one | aravin · pron |
| [გელაქნური](https://en.wiktionary.org/wiki/%E1%83%92%E1%83%94%E1%83%9A%E1%83%90%E1%83%A5%E1%83%9C%E1%83%A3%E1%83%A0%E1%83%98#Georgian) | gegharkuni, one of four subspecies of Sevan trout | gelaknuri · noun |
| [გილოცავ](https://en.wiktionary.org/wiki/%E1%83%92%E1%83%98%E1%83%9A%E1%83%9D%E1%83%AA%E1%83%90%E1%83%95#Georgian) | congratulations (informally to one person) | gilocav · intj |
| [ერთ-ერთი](https://en.wiktionary.org/wiki/%E1%83%94%E1%83%A0%E1%83%97-%E1%83%94%E1%83%A0%E1%83%97%E1%83%98#Georgian) | one of | ert-erti · pron |
| [ერთი](https://en.wiktionary.org/wiki/%E1%83%94%E1%83%A0%E1%83%97%E1%83%98#Georgian) | one (1) | erti · num |
| [ერთხელ](https://en.wiktionary.org/wiki/%E1%83%94%E1%83%A0%E1%83%97%E1%83%AE%E1%83%94%E1%83%9A#Georgian) | once (one time) | ertxel · adv |
| [ერკემალი](https://en.wiktionary.org/wiki/%E1%83%94%E1%83%A0%E1%83%99%E1%83%94%E1%83%9B%E1%83%90%E1%83%9A%E1%83%98#Georgian) | ram (a male sheep mostly over one years of age) | erḳemali · noun |
| [მარტვილი](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%90%E1%83%A0%E1%83%A2%E1%83%95%E1%83%98%E1%83%9A%E1%83%98#Georgian) | one who devoted their life to Christianity; martyr | marṭvili · noun |
| [პანეში](https://en.wiktionary.org/wiki/%E1%83%9E%E1%83%90%E1%83%9C%E1%83%94%E1%83%A8%E1%83%98#Georgian) | one of Georgian wine species | ṗaneši · noun |
| [სიდედრი](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%98%E1%83%93%E1%83%94%E1%83%93%E1%83%A0%E1%83%98#Georgian) | mother-in-law, more specifically one's wife's mother | sidedri · noun |
| [სიმამრი](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%98%E1%83%9B%E1%83%90%E1%83%9B%E1%83%A0%E1%83%98#Georgian) | father-in-law, more specifically one's wife's father | simamri · noun |
| [სიძე](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%98%E1%83%AB%E1%83%94#Georgian) | son-in-law or husband of one's sibling | siʒe · noun |
| [ქოში](https://en.wiktionary.org/wiki/%E1%83%A5%E1%83%9D%E1%83%A8%E1%83%98#Georgian) | one-year-old goat | koši · noun |
| [ქოშიკი](https://en.wiktionary.org/wiki/%E1%83%A5%E1%83%9D%E1%83%A8%E1%83%98%E1%83%99%E1%83%98#Georgian) | one-year-old goat | košiḳi · noun |
| [წამი](https://en.wiktionary.org/wiki/%E1%83%AC%E1%83%90%E1%83%9B%E1%83%98#Georgian) | second (one-sixtieth of a minute) | c̣ami · noun |
| [წუთი](https://en.wiktionary.org/wiki/%E1%83%AC%E1%83%A3%E1%83%97%E1%83%98#Georgian) | minute (one-sixtieth of an hour) | c̣uti · noun |
| [ხრიდოლი](https://en.wiktionary.org/wiki/%E1%83%AE%E1%83%A0%E1%83%98%E1%83%93%E1%83%9D%E1%83%9A%E1%83%98#Georgian) | Khridoli (a Georgian martial art, where one fighter uses only one hand while another uses both) | xridoli · noun |
| [თვითნება](https://en.wiktionary.org/wiki/%E1%83%97%E1%83%95%E1%83%98%E1%83%97%E1%83%9C%E1%83%94%E1%83%91%E1%83%90#Georgian) | self-will, high-handed | tvitneba · adj |
| [ნება](https://en.wiktionary.org/wiki/%E1%83%9C%E1%83%94%E1%83%91%E1%83%90#Georgian) | will | neba · noun |
| [-ვით](https://en.wiktionary.org/wiki/-%E1%83%95%E1%83%98%E1%83%97#Georgian) | like, as | -vit · postp |
| [მსგავსად](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%A1%E1%83%92%E1%83%90%E1%83%95%E1%83%A1%E1%83%90%E1%83%93#Georgian) | alike, like, likewise, similarly | msgavsad · adv |
| [როგორც](https://en.wiktionary.org/wiki/%E1%83%A0%E1%83%9D%E1%83%92%E1%83%9D%E1%83%A0%E1%83%AA#Georgian) | as, like (introduces comparative or manner clauses) | rogorc · conj |
| [შესახებ](https://en.wiktionary.org/wiki/%E1%83%A8%E1%83%94%E1%83%A1%E1%83%90%E1%83%AE%E1%83%94%E1%83%91#Georgian) | about, concerning, regarding | šesaxeb · postp |
| [აი](https://en.wiktionary.org/wiki/%E1%83%90%E1%83%98#Georgian) | Used to draw attention to, or to point out, an object or event. | ai · particle |
| [გარეშე](https://en.wiktionary.org/wiki/%E1%83%92%E1%83%90%E1%83%A0%E1%83%94%E1%83%A8%E1%83%94#Georgian) | without; out of | gareše · postp |
| [დასხმა](https://en.wiktionary.org/wiki/%E1%83%93%E1%83%90%E1%83%A1%E1%83%AE%E1%83%9B%E1%83%90#Georgian) | pour out | dasxma · noun |
| [რა](https://en.wiktionary.org/wiki/%E1%83%A0%E1%83%90#Georgian) | what (interrogative pronoun) | ra · pron |
| [რაში](https://en.wiktionary.org/wiki/%E1%83%A0%E1%83%90%E1%83%A8%E1%83%98#Georgian) | wherein, in what | raši · adv |
| [როდის](https://en.wiktionary.org/wiki/%E1%83%A0%E1%83%9D%E1%83%93%E1%83%98%E1%83%A1#Georgian) | when | rodis · adv |
| [როცა](https://en.wiktionary.org/wiki/%E1%83%A0%E1%83%9D%E1%83%AA%E1%83%90#Georgian) | when | roca · adv |
| [ჰა](https://en.wiktionary.org/wiki/%E1%83%B0%E1%83%90#Georgian) | Used when calling someone. Usually used between a repeated name. | ha · intj |
| [მეტი](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%94%E1%83%A2%E1%83%98#Georgian) | more | meṭi · adv |

</details>

<details><summary>Words 201–250</summary>

![[Resources/Audio/ka/Words 0201-0250.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [გურჯი](https://en.wiktionary.org/wiki/%E1%83%92%E1%83%A3%E1%83%A0%E1%83%AF%E1%83%98#Georgian) | Muslim immigrants of Georgian descent who had settled in non-Georgian majority regions of Turkey | gurǯi · noun |
| [ვინ](https://en.wiktionary.org/wiki/%E1%83%95%E1%83%98%E1%83%9C#Georgian) | who | vin · pron |
| [მათი](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%90%E1%83%97%E1%83%98#Georgian) | their | mati · pron |
| [იქ](https://en.wiktionary.org/wiki/%E1%83%98%E1%83%A5#Georgian) | there, therein | ik · adv |
| [დედაბოძი](https://en.wiktionary.org/wiki/%E1%83%93%E1%83%94%E1%83%93%E1%83%90%E1%83%91%E1%83%9D%E1%83%AB%E1%83%98#Georgian) | a main pole which holds houses constructed earlier times in Georgia | dedaboʒi · noun |
| [იყოს](https://en.wiktionary.org/wiki/%E1%83%98%E1%83%A7%E1%83%9D%E1%83%A1#Georgian) | let it/her/him be. | iq̇os · verb |
| [ჭალი](https://en.wiktionary.org/wiki/%E1%83%AD%E1%83%90%E1%83%9A%E1%83%98#Georgian) | rods of a cart/waggon on which a cloth is spread | č̣ali · noun |
| [-მდე](https://en.wiktionary.org/wiki/-%E1%83%9B%E1%83%93%E1%83%94#Georgian) | up to, to, till, as far as, before, until (in space as well as in time) | -mde · postp |
| [დრო](https://en.wiktionary.org/wiki/%E1%83%93%E1%83%A0%E1%83%9D#Georgian) | time | dro · noun |
| [იყო და არა იყო რა](https://en.wiktionary.org/wiki/%E1%83%98%E1%83%A7%E1%83%9D%20%E1%83%93%E1%83%90%20%E1%83%90%E1%83%A0%E1%83%90%20%E1%83%98%E1%83%A7%E1%83%9D%20%E1%83%A0%E1%83%90#Georgian) | once upon a time | iq̇o da ara iq̇o ra · phrase |
| [წინასწარ](https://en.wiktionary.org/wiki/%E1%83%AC%E1%83%98%E1%83%9C%E1%83%90%E1%83%A1%E1%83%AC%E1%83%90%E1%83%A0#Georgian) | beforehand, in advance, in good time | c̣inasc̣ar · adv |
| [ის](https://en.wiktionary.org/wiki/%E1%83%98%E1%83%A1#Georgian) | he, she, it (no gender differentiation) | is · pron |
| [ახალი](https://en.wiktionary.org/wiki/%E1%83%90%E1%83%AE%E1%83%90%E1%83%9A%E1%83%98#Georgian) | new, fresh | axali · adj |
| [ახლახან](https://en.wiktionary.org/wiki/%E1%83%90%E1%83%AE%E1%83%9A%E1%83%90%E1%83%AE%E1%83%90%E1%83%9C#Georgian) | lately, latterly, new, recently | axlaxan · adv |
| [როგორ](https://en.wiktionary.org/wiki/%E1%83%A0%E1%83%9D%E1%83%92%E1%83%9D%E1%83%A0#Georgian) | how | rogor · adv |
| [ზოგი](https://en.wiktionary.org/wiki/%E1%83%96%E1%83%9D%E1%83%92%E1%83%98#Georgian) | some | zogi · pron |
| [-ც](https://en.wiktionary.org/wiki/-%E1%83%AA#Georgian) | too, also | [t͡sʰ] · particle |
| [აგრეთვე](https://en.wiktionary.org/wiki/%E1%83%90%E1%83%92%E1%83%A0%E1%83%94%E1%83%97%E1%83%95%E1%83%94#Georgian) | also, too, likewise | agretve · adv |
| [ამჟამად](https://en.wiktionary.org/wiki/%E1%83%90%E1%83%9B%E1%83%9F%E1%83%90%E1%83%9B%E1%83%90%E1%83%93#Georgian) | currently, now | amžamad · adv |
| [ახლა](https://en.wiktionary.org/wiki/%E1%83%90%E1%83%AE%E1%83%9A%E1%83%90#Georgian) | now | axla · adv |
| [მკიდია](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%99%E1%83%98%E1%83%93%E1%83%98%E1%83%90#Georgian) | Used other than figuratively or idiomatically: see მკიდია (mḳidia). (it hangs on me) | mḳidia · verb |
| [სხვა](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%AE%E1%83%95%E1%83%90#Georgian) | other | sxva · pron |
| [ცეცხლზე ნავთის დასხმა](https://en.wiktionary.org/wiki/%E1%83%AA%E1%83%94%E1%83%AA%E1%83%AE%E1%83%9A%E1%83%96%E1%83%94%20%E1%83%9C%E1%83%90%E1%83%95%E1%83%97%E1%83%98%E1%83%A1%20%E1%83%93%E1%83%90%E1%83%A1%E1%83%AE%E1%83%9B%E1%83%90#Georgian) | Used other than figuratively or idiomatically: see ცეცხლი (cecxli), ნავთი (navti), დასხმა (dasxma). | cecxlze navtis dasxma · noun |
| [ჩვენებური](https://en.wiktionary.org/wiki/%E1%83%A9%E1%83%95%E1%83%94%E1%83%9C%E1%83%94%E1%83%91%E1%83%A3%E1%83%A0%E1%83%98#Georgian) | typical of us, in our own way or manner | čveneburi · adj |
| [დილა მშვიდობისა](https://en.wiktionary.org/wiki/%E1%83%93%E1%83%98%E1%83%9A%E1%83%90%20%E1%83%9B%E1%83%A8%E1%83%95%E1%83%98%E1%83%93%E1%83%9D%E1%83%91%E1%83%98%E1%83%A1%E1%83%90#Georgian) | good morning | dila mšvidobisa · intj |
| [კარგი](https://en.wiktionary.org/wiki/%E1%83%99%E1%83%90%E1%83%A0%E1%83%92%E1%83%98#Georgian) | nice, okay, well, good | ḳargi · adj |
| [კარგი საქონელია](https://en.wiktionary.org/wiki/%E1%83%99%E1%83%90%E1%83%A0%E1%83%92%E1%83%98%20%E1%83%A1%E1%83%90%E1%83%A5%E1%83%9D%E1%83%9C%E1%83%94%E1%83%9A%E1%83%98%E1%83%90#Georgian) | It is good, needful, necessary | ḳargi sakonelia · phrase |
| [კეთილი](https://en.wiktionary.org/wiki/%E1%83%99%E1%83%94%E1%83%97%E1%83%98%E1%83%9A%E1%83%98#Georgian) | kind, good | ḳetili · adj |
| [მხოლოდ](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%AE%E1%83%9D%E1%83%9A%E1%83%9D%E1%83%93#Georgian) | only | mxolod · adv |
| [მხოლოობითი](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%AE%E1%83%9D%E1%83%9A%E1%83%9D%E1%83%9D%E1%83%91%E1%83%98%E1%83%97%E1%83%98#Georgian) | only, sole | mxoloobiti · adj |
| [ნიშნი](https://en.wiktionary.org/wiki/%E1%83%9C%E1%83%98%E1%83%A8%E1%83%9C%E1%83%98#Georgian) | meaning is uncertain; used in phrases only | nišni · noun |
| [ღამე ნებისა](https://en.wiktionary.org/wiki/%E1%83%A6%E1%83%90%E1%83%9B%E1%83%94%20%E1%83%9C%E1%83%94%E1%83%91%E1%83%98%E1%83%A1%E1%83%90#Georgian) | sweet dreams, good night | ɣame nebisa · phrase |
| [ყისმათი](https://en.wiktionary.org/wiki/%E1%83%A7%E1%83%98%E1%83%A1%E1%83%9B%E1%83%90%E1%83%97%E1%83%98#Georgian) | kismet, success, good luck | q̇ismati · noun |
| [ძილი ნებისა](https://en.wiktionary.org/wiki/%E1%83%AB%E1%83%98%E1%83%9A%E1%83%98%20%E1%83%9C%E1%83%94%E1%83%91%E1%83%98%E1%83%A1%E1%83%90#Georgian) | sweet dreams, good night | ʒili nebisa · phrase |
| [-ში](https://en.wiktionary.org/wiki/-%E1%83%A8%E1%83%98#Georgian) | in, into | -ši · postp |
| [ბრწყინვალედ](https://en.wiktionary.org/wiki/%E1%83%91%E1%83%A0%E1%83%AC%E1%83%A7%E1%83%98%E1%83%9C%E1%83%95%E1%83%90%E1%83%9A%E1%83%94%E1%83%93#Georgian) | first-rate, gloriously, gorgeously | brc̣q̇invaled · adv |
| [დიდებულად](https://en.wiktionary.org/wiki/%E1%83%93%E1%83%98%E1%83%93%E1%83%94%E1%83%91%E1%83%A3%E1%83%9A%E1%83%90%E1%83%93#Georgian) | first-class, imperially, magnificently, majestically, rankly, splendidly | didebulad · adv |
| [თავდაჯერებულად](https://en.wiktionary.org/wiki/%E1%83%97%E1%83%90%E1%83%95%E1%83%93%E1%83%90%E1%83%AF%E1%83%94%E1%83%A0%E1%83%94%E1%83%91%E1%83%A3%E1%83%9A%E1%83%90%E1%83%93#Georgian) | bumptiously, confidently, presumptuously, anew, first | tavdaǯerebulad · adv |
| [შემდეგ](https://en.wiktionary.org/wiki/%E1%83%A8%E1%83%94%E1%83%9B%E1%83%93%E1%83%94%E1%83%92#Georgian) | after | šemdeg · postp |
| [ჩემი](https://en.wiktionary.org/wiki/%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98#Georgian) | my, mine (possession), singular first person possessive pronoun | čemi · pron |
| [არ ვიცი](https://en.wiktionary.org/wiki/%E1%83%90%E1%83%A0%20%E1%83%95%E1%83%98%E1%83%AA%E1%83%98#Georgian) | I don’t know | ar vici · phrase |
| [ორი](https://en.wiktionary.org/wiki/%E1%83%9D%E1%83%A0%E1%83%98#Georgian) | two (2) | ori · num |
| [ორკარედი](https://en.wiktionary.org/wiki/%E1%83%9D%E1%83%A0%E1%83%99%E1%83%90%E1%83%A0%E1%83%94%E1%83%93%E1%83%98#Georgian) | having two latches | orḳaredi · adj |
| [ორჯერ](https://en.wiktionary.org/wiki/%E1%83%9D%E1%83%A0%E1%83%AF%E1%83%94%E1%83%A0#Georgian) | twice, two times | orǯer · adv |
| [მიაჩნია](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%98%E1%83%90%E1%83%A9%E1%83%9C%E1%83%98%E1%83%90#Georgian) | to consider, to think | miačnia · verb |
| [საქონელი](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%90%E1%83%A5%E1%83%9D%E1%83%9C%E1%83%94%E1%83%9A%E1%83%98#Georgian) | any hoofed animal | sakoneli · noun |
| [წრეს გადასული](https://en.wiktionary.org/wiki/%E1%83%AC%E1%83%A0%E1%83%94%E1%83%A1%20%E1%83%92%E1%83%90%E1%83%93%E1%83%90%E1%83%A1%E1%83%A3%E1%83%9A%E1%83%98#Georgian) | abnormal, beyond any boundaries of normality (often in negative context) | c̣res gadasuli · adj |
| [უკან](https://en.wiktionary.org/wiki/%E1%83%A3%E1%83%99%E1%83%90%E1%83%9C#Georgian) | back, backwards | uḳan · adv |
| [ბადრიჯანი](https://en.wiktionary.org/wiki/%E1%83%91%E1%83%90%E1%83%93%E1%83%A0%E1%83%98%E1%83%AF%E1%83%90%E1%83%9C%E1%83%98#Georgian) | aubergine, eggplant (fruit as well as plant) | badriǯani · noun |
| [ბარემ](https://en.wiktionary.org/wiki/%E1%83%91%E1%83%90%E1%83%A0%E1%83%94%E1%83%9B#Georgian) | might as well | barem · particle |

</details>

<details><summary>Words 251–300</summary>

![[Resources/Audio/ka/Words 0251-0300.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [გამო](https://en.wiktionary.org/wiki/%E1%83%92%E1%83%90%E1%83%9B%E1%83%9D#Georgian) | because of | gamo · postp |
| [კარგად](https://en.wiktionary.org/wiki/%E1%83%99%E1%83%90%E1%83%A0%E1%83%92%E1%83%90%E1%83%93#Georgian) | well | ḳargad · adv |
| [მშვენივრად](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%A8%E1%83%95%E1%83%94%E1%83%9C%E1%83%98%E1%83%95%E1%83%A0%E1%83%90%E1%83%93#Georgian) | fine, beautifully, very well | mšvenivrad · adv |
| [ყოჩაღ](https://en.wiktionary.org/wiki/%E1%83%A7%E1%83%9D%E1%83%A9%E1%83%90%E1%83%A6#Georgian) | well done, congratulations, bravo, attaboy | q̇očaɣ! · intj |
| [ჭა](https://en.wiktionary.org/wiki/%E1%83%AD%E1%83%90#Georgian) | well | č̣a · noun |
| [არანაირად](https://en.wiktionary.org/wiki/%E1%83%90%E1%83%A0%E1%83%90%E1%83%9C%E1%83%90%E1%83%98%E1%83%A0%E1%83%90%E1%83%93#Georgian) | in no way, nohow | aranairad · adv |
| [გზა](https://en.wiktionary.org/wiki/%E1%83%92%E1%83%96%E1%83%90#Georgian) | way, path, road | gza · noun |
| [მაპატიეთ](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%90%E1%83%9E%E1%83%90%E1%83%A2%E1%83%98%E1%83%94%E1%83%97#Georgian) | Said as a request to pass somebody. | maṗaṭiet · intj |
| [მარტივად](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%90%E1%83%A0%E1%83%A2%E1%83%98%E1%83%95%E1%83%90%E1%83%93#Georgian) | simply, easily, plainly, in an uncomplicated way | marṭivad · adv |
| [ბევრი](https://en.wiktionary.org/wiki/%E1%83%91%E1%83%94%E1%83%95%E1%83%A0%E1%83%98#Georgian) | many, much | bevri · adj |
| [მეტისმეტად](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%94%E1%83%A2%E1%83%98%E1%83%A1%E1%83%9B%E1%83%94%E1%83%A2%E1%83%90%E1%83%93#Georgian) | exorbitantly, superfluously, too, excessively, overly, too much | meṭismeṭad · adv |
| [მრავალი](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%A0%E1%83%90%E1%83%95%E1%83%90%E1%83%9A%E1%83%98#Georgian) | many, much, plenty of, a lot of | mravali · det |
| [სად](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%90%E1%83%93#Georgian) | where | sad · adv |
| [შავლეგი](https://en.wiktionary.org/wiki/%E1%83%A8%E1%83%90%E1%83%95%E1%83%9A%E1%83%94%E1%83%92%E1%83%98#Georgian) | very dark gray, brunette, black, swarthy | šavlegi · adj |
| [ძალიან](https://en.wiktionary.org/wiki/%E1%83%AB%E1%83%90%E1%83%9A%E1%83%98%E1%83%90%E1%83%9C#Georgian) | very | ʒalian · adv |
| [ხანჯლური](https://en.wiktionary.org/wiki/%E1%83%AE%E1%83%90%E1%83%9C%E1%83%AF%E1%83%9A%E1%83%A3%E1%83%A0%E1%83%98#Georgian) | A Georgian dance, where performers use swords | xanǯluri · noun |
| [ლუწი](https://en.wiktionary.org/wiki/%E1%83%9A%E1%83%A3%E1%83%AC%E1%83%98#Georgian) | even | luc̣i · adj |
| [მაისი](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%90%E1%83%98%E1%83%A1%E1%83%98#Georgian) | May | maisi · noun |
| [აქ](https://en.wiktionary.org/wiki/%E1%83%90%E1%83%A5#Georgian) | here | ak · adv |
| [მართლა](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%90%E1%83%A0%E1%83%97%E1%83%9A%E1%83%90#Georgian) | really | martla · adv |
| [ნამდვილად](https://en.wiktionary.org/wiki/%E1%83%9C%E1%83%90%E1%83%9B%E1%83%93%E1%83%95%E1%83%98%E1%83%9A%E1%83%90%E1%83%93#Georgian) | actually, authentically, indeed, really, sheer | namdvilad · adv |
| [აშკარად](https://en.wiktionary.org/wiki/%E1%83%90%E1%83%A8%E1%83%99%E1%83%90%E1%83%A0%E1%83%90%E1%83%93#Georgian) | apparently, avowedly, blatantly, clear-cut, evidently, flatly, obviously, ostensibly, plain, plainly, professedly, right-down | ašḳarad · adv |
| [მარჯვენა](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%90%E1%83%A0%E1%83%AF%E1%83%95%E1%83%94%E1%83%9C%E1%83%90#Georgian) | right-hand, right | marǯvena · adj |
| [მაშინვე](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%90%E1%83%A8%E1%83%98%E1%83%9C%E1%83%95%E1%83%94#Georgian) | as soon as, immediately, right away, forthwith | mašinve · adv |
| [მუშაობა](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%A3%E1%83%A8%E1%83%90%E1%83%9D%E1%83%91%E1%83%90#Georgian) | work | mušaoba · noun |
| [სწორი](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%AC%E1%83%9D%E1%83%A0%E1%83%98#Georgian) | correct, right | sc̣ori · adj |
| [უფლება](https://en.wiktionary.org/wiki/%E1%83%A3%E1%83%A4%E1%83%9A%E1%83%94%E1%83%91%E1%83%90#Georgian) | right, claim | upleba · noun |
| [ცვლა](https://en.wiktionary.org/wiki/%E1%83%AA%E1%83%95%E1%83%9A%E1%83%90#Georgian) | shift, turn, watch (allotted period of work) | cvla · noun |
| [წელი](https://en.wiktionary.org/wiki/%E1%83%AC%E1%83%94%E1%83%9A%E1%83%98#Georgian) | year | c̣eli · noun |
| [არსება](https://en.wiktionary.org/wiki/%E1%83%90%E1%83%A0%E1%83%A1%E1%83%94%E1%83%91%E1%83%90#Georgian) | being (a living creature) | arseba · noun |
| [გუშინწინ](https://en.wiktionary.org/wiki/%E1%83%92%E1%83%A3%E1%83%A8%E1%83%98%E1%83%9C%E1%83%AC%E1%83%98%E1%83%9C#Georgian) | day before yesterday | gušinc̣in · adv |
| [დონკიხოტობა](https://en.wiktionary.org/wiki/%E1%83%93%E1%83%9D%E1%83%9C%E1%83%99%E1%83%98%E1%83%AE%E1%83%9D%E1%83%A2%E1%83%9D%E1%83%91%E1%83%90#Georgian) | Characterized as being quixotic | donḳixoṭoba · noun |
| [დღე](https://en.wiktionary.org/wiki/%E1%83%93%E1%83%A6%E1%83%94#Georgian) | day | dɣe · noun |
| [ყოფნა](https://en.wiktionary.org/wiki/%E1%83%A7%E1%83%9D%E1%83%A4%E1%83%9C%E1%83%90#Georgian) | existence, being | q̇opna · noun |
| [რად](https://en.wiktionary.org/wiki/%E1%83%A0%E1%83%90%E1%83%93#Georgian) | why | rad · adv |
| [გაუნძრევლად](https://en.wiktionary.org/wiki/%E1%83%92%E1%83%90%E1%83%A3%E1%83%9C%E1%83%AB%E1%83%A0%E1%83%94%E1%83%95%E1%83%9A%E1%83%90%E1%83%93#Georgian) | stock-still | gaunʒrevlad · adv |
| [მაინც](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%90%E1%83%98%E1%83%9C%E1%83%AA#Georgian) | still, anyway | mainc · adv |
| [ქარაბაკი](https://en.wiktionary.org/wiki/%E1%83%A5%E1%83%90%E1%83%A0%E1%83%90%E1%83%91%E1%83%90%E1%83%99%E1%83%98#Georgian) | cattle pen made of woven branches | karabaḳi · noun |
| [ქარხნული](https://en.wiktionary.org/wiki/%E1%83%A5%E1%83%90%E1%83%A0%E1%83%AE%E1%83%9C%E1%83%A3%E1%83%9A%E1%83%98#Georgian) | made in factory | karxnuli · adj |
| [არასოდეს](https://en.wiktionary.org/wiki/%E1%83%90%E1%83%A0%E1%83%90%E1%83%A1%E1%83%9D%E1%83%93%E1%83%94%E1%83%A1#Georgian) | never, nevermore | arasodes · adv |
| [ქვეყანა](https://en.wiktionary.org/wiki/%E1%83%A5%E1%83%95%E1%83%94%E1%83%A7%E1%83%90%E1%83%9C%E1%83%90#Georgian) | many | kveq̇ana · adj |
| [მსოფლიო](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%A1%E1%83%9D%E1%83%A4%E1%83%9A%E1%83%98%E1%83%9D#Georgian) | world | msoplio · noun |
| [სამყარო](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%90%E1%83%9B%E1%83%A7%E1%83%90%E1%83%A0%E1%83%9D#Georgian) | world, Universe | samq̇aro · noun |
| [სიცოცხლე](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%98%E1%83%AA%E1%83%9D%E1%83%AA%E1%83%AE%E1%83%9A%E1%83%94#Georgian) | life | sicocxle · noun |
| [უბნობს](https://en.wiktionary.org/wiki/%E1%83%A3%E1%83%91%E1%83%9C%E1%83%9D%E1%83%91%E1%83%A1#Georgian) | to say | ubnobs · verb |
| [ქვეყნიერება](https://en.wiktionary.org/wiki/%E1%83%A5%E1%83%95%E1%83%94%E1%83%A7%E1%83%9C%E1%83%98%E1%83%94%E1%83%A0%E1%83%94%E1%83%91%E1%83%90#Georgian) | world | kveq̇niereba · noun |
| [ცხოვრება](https://en.wiktionary.org/wiki/%E1%83%AA%E1%83%AE%E1%83%9D%E1%83%95%E1%83%A0%E1%83%94%E1%83%91%E1%83%90#Georgian) | life | cxovreba · noun |
| [გნიასი](https://en.wiktionary.org/wiki/%E1%83%92%E1%83%9C%E1%83%98%E1%83%90%E1%83%A1%E1%83%98#Georgian) | great hubbub | gniasi · noun |
| [დაბლა](https://en.wiktionary.org/wiki/%E1%83%93%E1%83%90%E1%83%91%E1%83%9A%E1%83%90#Georgian) | down, downwards, downstairs | dabla · adv |
| [დიდი](https://en.wiktionary.org/wiki/%E1%83%93%E1%83%98%E1%83%93%E1%83%98#Georgian) | big, large, great | didi · adj |

</details>

<details><summary>Words 301–350</summary>

![[Resources/Audio/ka/Words 0301-0350.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [თავდაყირა](https://en.wiktionary.org/wiki/%E1%83%97%E1%83%90%E1%83%95%E1%83%93%E1%83%90%E1%83%A7%E1%83%98%E1%83%A0%E1%83%90#Georgian) | topsy-turvy, upside-down | tavdaq̇ira · adv |
| [ჩახტომა](https://en.wiktionary.org/wiki/%E1%83%A9%E1%83%90%E1%83%AE%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%90#Georgian) | jump down | čaxṭoma · noun |
| [წოლა](https://en.wiktionary.org/wiki/%E1%83%AC%E1%83%9D%E1%83%9A%E1%83%90#Georgian) | lying, lying down, reclining, resting | c̣ola · noun |
| [წუხელ](https://en.wiktionary.org/wiki/%E1%83%AC%E1%83%A3%E1%83%AE%E1%83%94%E1%83%9A#Georgian) | last night | c̣uxel · adv |
| [ასეთი](https://en.wiktionary.org/wiki/%E1%83%90%E1%83%A1%E1%83%94%E1%83%97%E1%83%98#Georgian) | such | aseti · adj |
| [ისეთი](https://en.wiktionary.org/wiki/%E1%83%98%E1%83%A1%E1%83%94%E1%83%97%E1%83%98#Georgian) | such | iseti · adj |
| [კაცი](https://en.wiktionary.org/wiki/%E1%83%99%E1%83%90%E1%83%AA%E1%83%98#Georgian) | man | ḳaci · noun |
| [სიყვარული](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%98%E1%83%A7%E1%83%95%E1%83%90%E1%83%A0%E1%83%A3%E1%83%9A%E1%83%98#Georgian) | love | siq̇varuli · noun |
| [გრძელი](https://en.wiktionary.org/wiki/%E1%83%92%E1%83%A0%E1%83%AB%E1%83%94%E1%83%9A%E1%83%98#Georgian) | long | grʒeli · adj |
| [დიდხანს](https://en.wiktionary.org/wiki/%E1%83%93%E1%83%98%E1%83%93%E1%83%AE%E1%83%90%E1%83%9C%E1%83%A1#Georgian) | long | didxans · adv |
| [მთავარი გვერდი](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%97%E1%83%90%E1%83%95%E1%83%90%E1%83%A0%E1%83%98%20%E1%83%92%E1%83%95%E1%83%94%E1%83%A0%E1%83%93%E1%83%98#Georgian) | home page | mtavari gverdi · noun |
| [რამ](https://en.wiktionary.org/wiki/%E1%83%A0%E1%83%90%E1%83%9B#Georgian) | something, thing | ram · pron |
| [რაღაც](https://en.wiktionary.org/wiki/%E1%83%A0%E1%83%90%E1%83%A6%E1%83%90%E1%83%AA#Georgian) | something | raɣac · pron |
| [სახლი](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%90%E1%83%AE%E1%83%9A%E1%83%98#Georgian) | home, house, dwelling | saxli · noun |
| [ქრისტე აღსდგა](https://en.wiktionary.org/wiki/%E1%83%A5%E1%83%A0%E1%83%98%E1%83%A1%E1%83%A2%E1%83%94%20%E1%83%90%E1%83%A6%E1%83%A1%E1%83%93%E1%83%92%E1%83%90#Georgian) | A paschal greeting used in Georgia | krisṭe aɣsdga · intj |
| [შე ჩემა](https://en.wiktionary.org/wiki/%E1%83%A8%E1%83%94%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%90#Georgian) | used as an expletive | še čema · phrase |
| [მტკივნეული](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%A2%E1%83%99%E1%83%98%E1%83%95%E1%83%9C%E1%83%94%E1%83%A3%E1%83%9A%E1%83%98#Georgian) | painful, sore (afflicted by pain: body part, site of injury, etc.) | mṭḳivneuli · adj |
| [ნაწილობრივ](https://en.wiktionary.org/wiki/%E1%83%9C%E1%83%90%E1%83%AC%E1%83%98%E1%83%9A%E1%83%9D%E1%83%91%E1%83%A0%E1%83%98%E1%83%95#Georgian) | part, partially, partly | nac̣ilobriv · adv |
| [სამი](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%90%E1%83%9B%E1%83%98#Georgian) | three (3) | sami · num |
| [სახელმწიფო](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%90%E1%83%AE%E1%83%94%E1%83%9A%E1%83%9B%E1%83%AC%E1%83%98%E1%83%A4%E1%83%9D#Georgian) | state, official | saxelmc̣ipo · adj |
| [ჩახოხბილი](https://en.wiktionary.org/wiki/%E1%83%A9%E1%83%90%E1%83%AE%E1%83%9D%E1%83%AE%E1%83%91%E1%83%98%E1%83%9A%E1%83%98#Georgian) | chakhokhbili, a meat ragout, part of Georgian cuisine | čaxoxbili · noun |
| [გარშემო](https://en.wiktionary.org/wiki/%E1%83%92%E1%83%90%E1%83%A0%E1%83%A8%E1%83%94%E1%83%9B%E1%83%9D#Georgian) | around | garšemo · postp |
| [ირგვლივ](https://en.wiktionary.org/wiki/%E1%83%98%E1%83%A0%E1%83%92%E1%83%95%E1%83%9A%E1%83%98%E1%83%95#Georgian) | around | irgvliv · postp |
| [შორის](https://en.wiktionary.org/wiki/%E1%83%A8%E1%83%9D%E1%83%A0%E1%83%98%E1%83%A1#Georgian) | between, among | šoris · postp |
| [შუა](https://en.wiktionary.org/wiki/%E1%83%A8%E1%83%A3%E1%83%90#Georgian) | between, among | šua · postp |
| [მარად](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%90%E1%83%A0%E1%83%90%E1%83%93#Georgian) | forever, always, eternally | marad · adv |
| [მუდამ](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%A3%E1%83%93%E1%83%90%E1%83%9B#Georgian) | always | mudam · adv |
| [სჯობს](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%AF%E1%83%9D%E1%83%91%E1%83%A1#Georgian) | to be better | sǯobs · verb |
| [თვითმასწავლებელი](https://en.wiktionary.org/wiki/%E1%83%97%E1%83%95%E1%83%98%E1%83%97%E1%83%9B%E1%83%90%E1%83%A1%E1%83%AC%E1%83%90%E1%83%95%E1%83%9A%E1%83%94%E1%83%91%E1%83%94%E1%83%9A%E1%83%98#Georgian) | self-help book | tvitmasc̣avlebeli · noun |
| [თვითნებად](https://en.wiktionary.org/wiki/%E1%83%97%E1%83%95%E1%83%98%E1%83%97%E1%83%9C%E1%83%94%E1%83%91%E1%83%90%E1%83%93#Georgian) | high-handedly | tvitnebad · adv |
| [კეთილშობილად](https://en.wiktionary.org/wiki/%E1%83%99%E1%83%94%E1%83%97%E1%83%98%E1%83%9A%E1%83%A8%E1%83%9D%E1%83%91%E1%83%98%E1%83%9A%E1%83%90%E1%83%93#Georgian) | high-mindedly, nobly | ḳetilšobilad · adv |
| [მაქსიმალურად](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%90%E1%83%A5%E1%83%A1%E1%83%98%E1%83%9B%E1%83%90%E1%83%9A%E1%83%A3%E1%83%A0%E1%83%90%E1%83%93#Georgian) | maximally, sky-high | maksimalurad · adv |
| [მაღლა](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%90%E1%83%A6%E1%83%9A%E1%83%90#Georgian) | high up, up, upstairs, upwards | maɣla · adv |
| [მოხუცი](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%9D%E1%83%AE%E1%83%A3%E1%83%AA%E1%83%98#Georgian) | old, elderly (person) | moxuci · adj |
| [მუხანათურად](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%A3%E1%83%AE%E1%83%90%E1%83%9C%E1%83%90%E1%83%97%E1%83%A3%E1%83%A0%E1%83%90%E1%83%93#Georgian) | traitorously, knee-deep, knee-high | muxanaturad · adv |
| [პატარა](https://en.wiktionary.org/wiki/%E1%83%9E%E1%83%90%E1%83%A2%E1%83%90%E1%83%A0%E1%83%90#Georgian) | little, small | ṗaṭara · adj |
| [ცოტა](https://en.wiktionary.org/wiki/%E1%83%AA%E1%83%9D%E1%83%A2%E1%83%90#Georgian) | a little | coṭa · adv |
| [ძველი](https://en.wiktionary.org/wiki/%E1%83%AB%E1%83%95%E1%83%94%E1%83%9A%E1%83%98#Georgian) | old | ʒveli · adj |
| [შეკოწიწებული](https://en.wiktionary.org/wiki/%E1%83%A8%E1%83%94%E1%83%99%E1%83%9D%E1%83%AC%E1%83%98%E1%83%AC%E1%83%94%E1%83%91%E1%83%A3%E1%83%9A%E1%83%98#Georgian) | to join scattered things together carefully | šeḳoc̣ic̣ebuli · adj |
| [ქვეშ](https://en.wiktionary.org/wiki/%E1%83%A5%E1%83%95%E1%83%94%E1%83%A8#Georgian) | under | kveš · postp |
| [აზარტი](https://en.wiktionary.org/wiki/%E1%83%90%E1%83%96%E1%83%90%E1%83%A0%E1%83%A2%E1%83%98#Georgian) | passion (in game) | azarṭi · noun |
| [ვიდეო თამაში](https://en.wiktionary.org/wiki/%E1%83%95%E1%83%98%E1%83%93%E1%83%94%E1%83%9D%20%E1%83%97%E1%83%90%E1%83%9B%E1%83%90%E1%83%A8%E1%83%98#Georgian) | video game | video tamaši · noun |
| [მუჰაჯირობა](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%A3%E1%83%B0%E1%83%90%E1%83%AF%E1%83%98%E1%83%A0%E1%83%9D%E1%83%91%E1%83%90#Georgian) | Ethnic cleansing of Circassians during XIX century | muhaǯiroba · noun |
| [ნივთი](https://en.wiktionary.org/wiki/%E1%83%9C%E1%83%98%E1%83%95%E1%83%97%E1%83%98#Georgian) | thing | nivti · noun |
| [რულეტი](https://en.wiktionary.org/wiki/%E1%83%A0%E1%83%A3%E1%83%9A%E1%83%94%E1%83%A2%E1%83%98#Georgian) | roulette (game) | ruleṭi · noun |
| [საგანი](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%90%E1%83%92%E1%83%90%E1%83%9C%E1%83%98#Georgian) | object, thing | sagani · noun |
| [შაბაში](https://en.wiktionary.org/wiki/%E1%83%A8%E1%83%90%E1%83%91%E1%83%90%E1%83%A8%E1%83%98#Georgian) | Money paid to musicians or dancers during a marriage or a feast | šabaši · noun |
| [აგარა](https://en.wiktionary.org/wiki/%E1%83%90%E1%83%92%E1%83%90%E1%83%A0%E1%83%90#Georgian) | dacha, country house | agara · noun |
| [ადგილი](https://en.wiktionary.org/wiki/%E1%83%90%E1%83%93%E1%83%92%E1%83%98%E1%83%9A%E1%83%98#Georgian) | place | adgili · noun |
| [ალაგი](https://en.wiktionary.org/wiki/%E1%83%90%E1%83%9A%E1%83%90%E1%83%92%E1%83%98#Georgian) | place | alagi · noun |

</details>

<details><summary>Words 351–400</summary>

![[Resources/Audio/ka/Words 0351-0400.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [შატალო](https://en.wiktionary.org/wiki/%E1%83%A8%E1%83%90%E1%83%A2%E1%83%90%E1%83%9A%E1%83%9D#Georgian) | An act of deliberately missing school (especially by a group of pupils) | šaṭalo · noun |
| [ისევ](https://en.wiktionary.org/wiki/%E1%83%98%E1%83%A1%E1%83%94%E1%83%95#Georgian) | again | isev · adv |
| [კვლავ](https://en.wiktionary.org/wiki/%E1%83%99%E1%83%95%E1%83%9A%E1%83%90%E1%83%95#Georgian) | again | ḳvlav · adv |
| [კიდევ](https://en.wiktionary.org/wiki/%E1%83%99%E1%83%98%E1%83%93%E1%83%94%E1%83%95#Georgian) | again | ḳidev · adv |
| [შემდეგი](https://en.wiktionary.org/wiki/%E1%83%A8%E1%83%94%E1%83%9B%E1%83%93%E1%83%94%E1%83%92%E1%83%98#Georgian) | next, subsequent | šemdegi · adj |
| [ხელახლა](https://en.wiktionary.org/wiki/%E1%83%AE%E1%83%94%E1%83%9A%E1%83%90%E1%83%AE%E1%83%9A%E1%83%90#Georgian) | again | xelaxla · adv |
| [ყოველი](https://en.wiktionary.org/wiki/%E1%83%A7%E1%83%9D%E1%83%95%E1%83%94%E1%83%9A%E1%83%98#Georgian) | each | q̇oveli · pron |
| [გატრუნვა](https://en.wiktionary.org/wiki/%E1%83%92%E1%83%90%E1%83%A2%E1%83%A0%E1%83%A3%E1%83%9C%E1%83%95%E1%83%90#Georgian) | to keep quiet | gaṭrunva · verb |
| [ოდესმე](https://en.wiktionary.org/wiki/%E1%83%9D%E1%83%93%E1%83%94%E1%83%A1%E1%83%9B%E1%83%94#Georgian) | ever | odesme · adv |
| [ოჯახი](https://en.wiktionary.org/wiki/%E1%83%9D%E1%83%AF%E1%83%90%E1%83%AE%E1%83%98#Georgian) | family | oǯaxi · noun |
| [ოჯახიშვილი](https://en.wiktionary.org/wiki/%E1%83%9D%E1%83%AF%E1%83%90%E1%83%AE%E1%83%98%E1%83%A8%E1%83%95%E1%83%98%E1%83%9A%E1%83%98#Georgian) | member of a family | oǯaxišvili · noun |
| [რქების დადგმა](https://en.wiktionary.org/wiki/%E1%83%A0%E1%83%A5%E1%83%94%E1%83%91%E1%83%98%E1%83%A1%20%E1%83%93%E1%83%90%E1%83%93%E1%83%92%E1%83%9B%E1%83%90#Georgian) | to cuckold (literally, to put horns on) | rkebis dadgma · phrase |
| [ფული](https://en.wiktionary.org/wiki/%E1%83%A4%E1%83%A3%E1%83%9A%E1%83%98#Georgian) | money | puli · noun |
| [დაუსჯელად](https://en.wiktionary.org/wiki/%E1%83%93%E1%83%90%E1%83%A3%E1%83%A1%E1%83%AF%E1%83%94%E1%83%9A%E1%83%90%E1%83%93#Georgian) | scot-free | dausǯelad · adv |
| [ვინმე](https://en.wiktionary.org/wiki/%E1%83%95%E1%83%98%E1%83%9C%E1%83%9B%E1%83%94#Georgian) | someone | vinme · pron |
| [უფასო](https://en.wiktionary.org/wiki/%E1%83%A3%E1%83%A4%E1%83%90%E1%83%A1%E1%83%9D#Georgian) | free, free of charge, gratis | upaso · adj |
| [გაფრენა](https://en.wiktionary.org/wiki/%E1%83%92%E1%83%90%E1%83%A4%E1%83%A0%E1%83%94%E1%83%9C%E1%83%90#Georgian) | flying away, flight, takeoff, departure (by air or aircraft) | gaprena · noun |
| [ვინმესგან](https://en.wiktionary.org/wiki/%E1%83%95%E1%83%98%E1%83%9C%E1%83%9B%E1%83%94%E1%83%A1%E1%83%92%E1%83%90%E1%83%9C#Georgian) | away | vinmesgan · adv |
| [მარტივი რიცხვი](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%90%E1%83%A0%E1%83%A2%E1%83%98%E1%83%95%E1%83%98%20%E1%83%A0%E1%83%98%E1%83%AA%E1%83%AE%E1%83%95%E1%83%98#Georgian) | prime number | marṭivi ricxvi · noun |
| [რაოდენობა](https://en.wiktionary.org/wiki/%E1%83%A0%E1%83%90%E1%83%9D%E1%83%93%E1%83%94%E1%83%9C%E1%83%9D%E1%83%91%E1%83%90#Georgian) | quantity, number | raodenoba · noun |
| [რიცხვი](https://en.wiktionary.org/wiki/%E1%83%A0%E1%83%98%E1%83%AA%E1%83%AE%E1%83%95%E1%83%98#Georgian) | number (entity) | ricxvi · noun |
| [სახელი](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%90%E1%83%AE%E1%83%94%E1%83%9A%E1%83%98#Georgian) | name | saxeli · noun |
| [ქალაქი](https://en.wiktionary.org/wiki/%E1%83%A5%E1%83%90%E1%83%9A%E1%83%90%E1%83%A5%E1%83%98#Georgian) | town, city | kalaki · noun |
| [ღამე](https://en.wiktionary.org/wiki/%E1%83%A6%E1%83%90%E1%83%9B%E1%83%94#Georgian) | night | ɣame · noun |
| [ნამდვილი](https://en.wiktionary.org/wiki/%E1%83%9C%E1%83%90%E1%83%9B%E1%83%93%E1%83%95%E1%83%98%E1%83%9A%E1%83%98#Georgian) | real | namdvili · adj |
| [ნათელი](https://en.wiktionary.org/wiki/%E1%83%9C%E1%83%90%E1%83%97%E1%83%94%E1%83%9A%E1%83%98#Georgian) | bright, lighted, light (having light; luminous, illuminated) | nateli · adj |
| [როგორმე](https://en.wiktionary.org/wiki/%E1%83%A0%E1%83%9D%E1%83%92%E1%83%9D%E1%83%A0%E1%83%9B%E1%83%94#Georgian) | however | rogorme · adv |
| [დასი](https://en.wiktionary.org/wiki/%E1%83%93%E1%83%90%E1%83%A1%E1%83%98#Georgian) | group; troupe; choir (of angels) | dasi · noun |
| [ზემო](https://en.wiktionary.org/wiki/%E1%83%96%E1%83%94%E1%83%9B%E1%83%9D#Georgian) | upper, top | zemo · adj |
| [რასა](https://en.wiktionary.org/wiki/%E1%83%A0%E1%83%90%E1%83%A1%E1%83%90#Georgian) | race (human group) | rasa · noun |
| [ღვთაება](https://en.wiktionary.org/wiki/%E1%83%A6%E1%83%95%E1%83%97%E1%83%90%E1%83%94%E1%83%91%E1%83%90#Georgian) | god (idol) | ɣvtaeba · noun |
| [ღმერთი](https://en.wiktionary.org/wiki/%E1%83%A6%E1%83%9B%E1%83%94%E1%83%A0%E1%83%97%E1%83%98#Georgian) | God | ɣmerti · noun |
| [წვერი](https://en.wiktionary.org/wiki/%E1%83%AC%E1%83%95%E1%83%94%E1%83%A0%E1%83%98#Georgian) | tip, vertex, point, top | c̣veri · noun |
| [ასჯერ](https://en.wiktionary.org/wiki/%E1%83%90%E1%83%A1%E1%83%AF%E1%83%94%E1%83%A0#Georgian) | hundred times | asǯer · adv |
| [კვირა](https://en.wiktionary.org/wiki/%E1%83%99%E1%83%95%E1%83%98%E1%83%A0%E1%83%90#Georgian) | week | ḳvira · noun |
| [სისტემა](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%98%E1%83%A1%E1%83%A2%E1%83%94%E1%83%9B%E1%83%90#Georgian) | system | sisṭema · noun |
| [ადამიანი](https://en.wiktionary.org/wiki/%E1%83%90%E1%83%93%E1%83%90%E1%83%9B%E1%83%98%E1%83%90%E1%83%9C%E1%83%98#Georgian) | human, person | adamiani · noun |
| [ამაგი](https://en.wiktionary.org/wiki/%E1%83%90%E1%83%9B%E1%83%90%E1%83%92%E1%83%98#Georgian) | Effort expended on a particular person | amagi · noun |
| [არაფერი](https://en.wiktionary.org/wiki/%E1%83%90%E1%83%A0%E1%83%90%E1%83%A4%E1%83%94%E1%83%A0%E1%83%98#Georgian) | nothing | araperi · pron |
| [აფხაზი](https://en.wiktionary.org/wiki/%E1%83%90%E1%83%A4%E1%83%AE%E1%83%90%E1%83%96%E1%83%98#Georgian) | Abkhaz person | apxazi · noun |
| [ბასკი](https://en.wiktionary.org/wiki/%E1%83%91%E1%83%90%E1%83%A1%E1%83%99%E1%83%98#Georgian) | Basque person | basḳi · noun |
| [ბერძენი](https://en.wiktionary.org/wiki/%E1%83%91%E1%83%94%E1%83%A0%E1%83%AB%E1%83%94%E1%83%9C%E1%83%98#Georgian) | Greek person | berʒeni · noun |
| [გარემო](https://en.wiktionary.org/wiki/%E1%83%92%E1%83%90%E1%83%A0%E1%83%94%E1%83%9B%E1%83%9D#Georgian) | environment, surroundings, milieu, medium, setting (external physical, natural, or social conditions surrounding an organism or person) | garemo · noun |
| [დღეს](https://en.wiktionary.org/wiki/%E1%83%93%E1%83%A6%E1%83%94%E1%83%A1#Georgian) | today | dɣes · adv |
| [პიროვნება](https://en.wiktionary.org/wiki/%E1%83%9E%E1%83%98%E1%83%A0%E1%83%9D%E1%83%95%E1%83%9C%E1%83%94%E1%83%91%E1%83%90#Georgian) | person, personality | ṗirovneba · noun |
| [უნგრელი](https://en.wiktionary.org/wiki/%E1%83%A3%E1%83%9C%E1%83%92%E1%83%A0%E1%83%94%E1%83%9A%E1%83%98#Georgian) | Hungarian person | ungreli · noun |
| [ყრუ](https://en.wiktionary.org/wiki/%E1%83%A7%E1%83%A0%E1%83%A3#Georgian) | deaf person | q̇ru · noun |
| [ჩახტა](https://en.wiktionary.org/wiki/%E1%83%A9%E1%83%90%E1%83%AE%E1%83%A2%E1%83%90#Georgian) | third-person past simple indicative of ჩახტომა (čaxṭoma) | čaxṭa · verb |
| [ჩლუნგი](https://en.wiktionary.org/wiki/%E1%83%A9%E1%83%9A%E1%83%A3%E1%83%9C%E1%83%92%E1%83%98#Georgian) | stupid, slowwitted person | člungi · noun |
| [ჭეშმარიტად](https://en.wiktionary.org/wiki/%E1%83%AD%E1%83%94%E1%83%A8%E1%83%9B%E1%83%90%E1%83%A0%E1%83%98%E1%83%A2%E1%83%90%E1%83%93#Georgian) | Adverbial case of nominalized form of ჭეშმარიტი (č̣ešmariṭi) | č̣ešmariṭad · noun |

</details>

<details><summary>Words 401–450</summary>

![[Resources/Audio/ka/Words 0401-0450.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [ყველაფერი](https://en.wiktionary.org/wiki/%E1%83%A7%E1%83%95%E1%83%94%E1%83%9A%E1%83%90%E1%83%A4%E1%83%94%E1%83%A0%E1%83%98#Georgian) | everything | q̇velaperi · pron |
| [მაგარი](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%90%E1%83%92%E1%83%90%E1%83%A0%E1%83%98#Georgian) | hard, firm, strong | magari · adj |
| [მაგრად](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%90%E1%83%92%E1%83%A0%E1%83%90%E1%83%93#Georgian) | firm, firmly, hard, robustly | magrad · adv |
| [მტკიცედ](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%A2%E1%83%99%E1%83%98%E1%83%AA%E1%83%94%E1%83%93#Georgian) | enduringly, hard, resolutely, sturdily, unfalteringly | mṭḳiced · adv |
| [ოთხი](https://en.wiktionary.org/wiki/%E1%83%9D%E1%83%97%E1%83%AE%E1%83%98#Georgian) | four (4) | otxi · num |
| [ცუდი](https://en.wiktionary.org/wiki/%E1%83%AA%E1%83%A3%E1%83%93%E1%83%98#Georgian) | bad | cudi · adj |
| [ბორჯომი](https://en.wiktionary.org/wiki/%E1%83%91%E1%83%9D%E1%83%A0%E1%83%AF%E1%83%9D%E1%83%9B%E1%83%98#Georgian) | Borjomi, a brand of naturally carbonated mineral water | borǯomi · noun |
| [გადაცემა](https://en.wiktionary.org/wiki/%E1%83%92%E1%83%90%E1%83%93%E1%83%90%E1%83%AA%E1%83%94%E1%83%9B%E1%83%90#Georgian) | transfer, handover, transmission (of information, power, rights, etc.) | gadacema · noun |
| [მუსიკა](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%A3%E1%83%A1%E1%83%98%E1%83%99%E1%83%90#Georgian) | music | musiḳa · noun |
| [რეპი](https://en.wiktionary.org/wiki/%E1%83%A0%E1%83%94%E1%83%9E%E1%83%98#Georgian) | rap music | reṗi · noun |
| [როკი](https://en.wiktionary.org/wiki/%E1%83%A0%E1%83%9D%E1%83%99%E1%83%98#Georgian) | rock music | roḳi · noun |
| [ძალა](https://en.wiktionary.org/wiki/%E1%83%AB%E1%83%90%E1%83%9A%E1%83%90#Georgian) | power, force, strength | ʒala · noun |
| [წალიკა](https://en.wiktionary.org/wiki/%E1%83%AC%E1%83%90%E1%83%9A%E1%83%98%E1%83%99%E1%83%90#Georgian) | water pepper (Persicaria hydropiper, syn. Polygonum hydropiper) | c̣aliḳa · noun |
| [წყალი](https://en.wiktionary.org/wiki/%E1%83%AC%E1%83%A7%E1%83%90%E1%83%9A%E1%83%98#Georgian) | water (clear liquid) | c̣q̇ali · noun |
| [აბი](https://en.wiktionary.org/wiki/%E1%83%90%E1%83%91%E1%83%98#Georgian) | pill (small portion of a drug or drugs to be taken orally) | abi · noun |
| [ზაზუნა](https://en.wiktionary.org/wiki/%E1%83%96%E1%83%90%E1%83%96%E1%83%A3%E1%83%9C%E1%83%90#Georgian) | hamster (small, short-tailed European rodent) | zazuna · noun |
| [თავი](https://en.wiktionary.org/wiki/%E1%83%97%E1%83%90%E1%83%95%E1%83%98#Georgian) | head | tavi · noun |
| [თავით](https://en.wiktionary.org/wiki/%E1%83%97%E1%83%90%E1%83%95%E1%83%98%E1%83%97#Georgian) | head-on | tavit · adv |
| [თეთრი](https://en.wiktionary.org/wiki/%E1%83%97%E1%83%94%E1%83%97%E1%83%A0%E1%83%98#Georgian) | white | tetri · adj |
| [მთავარი](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%97%E1%83%90%E1%83%95%E1%83%90%E1%83%A0%E1%83%98#Georgian) | main, chief, principal, head | mtavari · adj |
| [მცირე](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%AA%E1%83%98%E1%83%A0%E1%83%94#Georgian) | small, insignificant | mcire · adj |
| [ჟინჟღლი](https://en.wiktionary.org/wiki/%E1%83%9F%E1%83%98%E1%83%9C%E1%83%9F%E1%83%A6%E1%83%9A%E1%83%98#Georgian) | rain of small droplets | žinžɣli · noun |
| [ქაფი](https://en.wiktionary.org/wiki/%E1%83%A5%E1%83%90%E1%83%A4%E1%83%98#Georgian) | foam, spume, froth, head | kapi · noun |
| [ქინქლა](https://en.wiktionary.org/wiki/%E1%83%A5%E1%83%98%E1%83%9C%E1%83%A5%E1%83%9A%E1%83%90#Georgian) | small insect | kinkla · noun |
| [დიახ](https://en.wiktionary.org/wiki/%E1%83%93%E1%83%98%E1%83%90%E1%83%AE#Georgian) | yes | diax · intj |
| [კი](https://en.wiktionary.org/wiki/%E1%83%99%E1%83%98#Georgian) | yes | ḳi · intj |
| [მხარე](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%AE%E1%83%90%E1%83%A0%E1%83%94#Georgian) | side; direction | mxare · noun |
| [შორს](https://en.wiktionary.org/wiki/%E1%83%A8%E1%83%9D%E1%83%A0%E1%83%A1#Georgian) | far | šors · adv |
| [ნაკლებად](https://en.wiktionary.org/wiki/%E1%83%9C%E1%83%90%E1%83%99%E1%83%9A%E1%83%94%E1%83%91%E1%83%90%E1%83%93#Georgian) | less | naḳlebad · adv |
| [პარტია](https://en.wiktionary.org/wiki/%E1%83%9E%E1%83%90%E1%83%A0%E1%83%A2%E1%83%98%E1%83%90#Georgian) | party | ṗarṭia · noun |
| [რიგი](https://en.wiktionary.org/wiki/%E1%83%A0%E1%83%98%E1%83%92%E1%83%98#Georgian) | series, line, queue | rigi · noun |
| [ერი](https://en.wiktionary.org/wiki/%E1%83%94%E1%83%A0%E1%83%98#Georgian) | country, nation | eri · noun |
| [კოსტა-რიკა](https://en.wiktionary.org/wiki/%E1%83%99%E1%83%9D%E1%83%A1%E1%83%A2%E1%83%90-%E1%83%A0%E1%83%98%E1%83%99%E1%83%90#Georgian) | Costa Rica (a country in Central America) | ḳosṭa-riḳa · noun |
| [სოფელი](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%9D%E1%83%A4%E1%83%94%E1%83%9A%E1%83%98#Georgian) | village, country, countryside | sopeli · noun |
| [გიშერი](https://en.wiktionary.org/wiki/%E1%83%92%E1%83%98%E1%83%A8%E1%83%94%E1%83%A0%E1%83%98#Georgian) | black amber, jet | gišeri · noun |
| [ერთად](https://en.wiktionary.org/wiki/%E1%83%94%E1%83%A0%E1%83%97%E1%83%90%E1%83%93#Georgian) | conjointly, together | ertad · adv |
| [კანონი](https://en.wiktionary.org/wiki/%E1%83%99%E1%83%90%E1%83%9C%E1%83%9D%E1%83%9C%E1%83%98#Georgian) | law (legal rule) | ḳanoni · noun |
| [კანონიერი ქურდი](https://en.wiktionary.org/wiki/%E1%83%99%E1%83%90%E1%83%9C%E1%83%9D%E1%83%9C%E1%83%98%E1%83%94%E1%83%A0%E1%83%98%20%E1%83%A5%E1%83%A3%E1%83%A0%E1%83%93%E1%83%98#Georgian) | thief in law | ḳanonieri kurdi · noun |
| [მკლავი](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%99%E1%83%9A%E1%83%90%E1%83%95%E1%83%98#Georgian) | upper arm, or arm as a whole | mḳlavi · noun |
| [ომი](https://en.wiktionary.org/wiki/%E1%83%9D%E1%83%9B%E1%83%98#Georgian) | war | omi · noun |
| [უბანი](https://en.wiktionary.org/wiki/%E1%83%A3%E1%83%91%E1%83%90%E1%83%9C%E1%83%98#Georgian) | neighborhood, district, area, region | ubani · noun |
| [შავი](https://en.wiktionary.org/wiki/%E1%83%A8%E1%83%90%E1%83%95%E1%83%98#Georgian) | black | šavi · adj |
| [წმინდა ომი](https://en.wiktionary.org/wiki/%E1%83%AC%E1%83%9B%E1%83%98%E1%83%9C%E1%83%93%E1%83%90%20%E1%83%9D%E1%83%9B%E1%83%98#Georgian) | holy war | c̣minda omi · noun |
| [ავტომობილი](https://en.wiktionary.org/wiki/%E1%83%90%E1%83%95%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%9D%E1%83%91%E1%83%98%E1%83%9A%E1%83%98#Georgian) | automobile, passenger car | avṭomobili · noun |
| [არტავარი](https://en.wiktionary.org/wiki/%E1%83%90%E1%83%A0%E1%83%A2%E1%83%90%E1%83%95%E1%83%90%E1%83%A0%E1%83%98#Georgian) | artab, a kind of dry measure | arṭavari · noun |
| [აჩმა](https://en.wiktionary.org/wiki/%E1%83%90%E1%83%A9%E1%83%9B%E1%83%90#Georgian) | kind of khachapuri | ačma · noun |
| [იქნებ](https://en.wiktionary.org/wiki/%E1%83%98%E1%83%A5%E1%83%9C%E1%83%94%E1%83%91#Georgian) | maybe | ikneb · adv |
| [ლეკური](https://en.wiktionary.org/wiki/%E1%83%9A%E1%83%94%E1%83%99%E1%83%A3%E1%83%A0%E1%83%98#Georgian) | A kind of sabre | leḳuri · noun |
| [სახე](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%90%E1%83%AE%E1%83%94#Georgian) | face | saxe · noun |
| [სტატია](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%A2%E1%83%90%E1%83%A2%E1%83%98%E1%83%90#Georgian) | article (story, report, or opinion piece) | sṭaṭia · noun |

</details>

<details><summary>Words 451–500</summary>

![[Resources/Audio/ka/Words 0451-0500.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [ხუთი](https://en.wiktionary.org/wiki/%E1%83%AE%E1%83%A3%E1%83%97%E1%83%98#Georgian) | five (5) | xuti · num |
| [იმედი](https://en.wiktionary.org/wiki/%E1%83%98%E1%83%9B%E1%83%94%E1%83%93%E1%83%98#Georgian) | hope | imedi · noun |
| [მნიშვნელოვანი](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%9C%E1%83%98%E1%83%A8%E1%83%95%E1%83%9C%E1%83%94%E1%83%9A%E1%83%9D%E1%83%95%E1%83%90%E1%83%9C%E1%83%98#Georgian) | important | mnišvnelovani · adj |
| [ოცნება](https://en.wiktionary.org/wiki/%E1%83%9D%E1%83%AA%E1%83%9C%E1%83%94%E1%83%91%E1%83%90#Georgian) | dream, hope, wish | ocneba · noun |
| [საშუალება](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%90%E1%83%A8%E1%83%A3%E1%83%90%E1%83%9A%E1%83%94%E1%83%91%E1%83%90#Georgian) | opportunity, means | sašualeba · noun |
| [ჯანმრთელობა](https://en.wiktionary.org/wiki/%E1%83%AF%E1%83%90%E1%83%9C%E1%83%9B%E1%83%A0%E1%83%97%E1%83%94%E1%83%9A%E1%83%9D%E1%83%91%E1%83%90#Georgian) | health | ǯanmrteloba · noun |
| [ადრე](https://en.wiktionary.org/wiki/%E1%83%90%E1%83%93%E1%83%A0%E1%83%94#Georgian) | early | adre · adv |
| [მუტრუკი](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%A3%E1%83%A2%E1%83%A0%E1%83%A3%E1%83%99%E1%83%98#Georgian) | young donkey | muṭruḳi · noun |
| [ნაყოფიერად](https://en.wiktionary.org/wiki/%E1%83%9C%E1%83%90%E1%83%A7%E1%83%9D%E1%83%A4%E1%83%98%E1%83%94%E1%83%A0%E1%83%90%E1%83%93#Georgian) | fruitfully, post meridiem | naq̇opierad · adv |
| [წიგნი](https://en.wiktionary.org/wiki/%E1%83%AC%E1%83%98%E1%83%92%E1%83%9C%E1%83%98#Georgian) | book | c̣igni · noun |
| [წიწილა](https://en.wiktionary.org/wiki/%E1%83%AC%E1%83%98%E1%83%AC%E1%83%98%E1%83%9A%E1%83%90#Georgian) | A young chicken: chick | c̣ic̣ila · noun |
| [წიწილი](https://en.wiktionary.org/wiki/%E1%83%AC%E1%83%98%E1%83%AC%E1%83%98%E1%83%9A%E1%83%98#Georgian) | a young snake, snakelet | c̣ic̣ili · noun |
| [ლაპარაკი](https://en.wiktionary.org/wiki/%E1%83%9A%E1%83%90%E1%83%9E%E1%83%90%E1%83%A0%E1%83%90%E1%83%99%E1%83%98#Georgian) | speech, talk | laṗaraḳi · noun |
| [პაემანი](https://en.wiktionary.org/wiki/%E1%83%9E%E1%83%90%E1%83%94%E1%83%9B%E1%83%90%E1%83%9C%E1%83%98#Georgian) | date (pre-arranged social meeting) | ṗaemani · noun |
| [საუბარი](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%90%E1%83%A3%E1%83%91%E1%83%90%E1%83%A0%E1%83%98#Georgian) | conversation, talk | saubari · noun |
| [წინათ](https://en.wiktionary.org/wiki/%E1%83%AC%E1%83%98%E1%83%9C%E1%83%90%E1%83%97#Georgian) | ago | c̣inat · postp |
| [გაუბედავად](https://en.wiktionary.org/wiki/%E1%83%92%E1%83%90%E1%83%A3%E1%83%91%E1%83%94%E1%83%93%E1%83%90%E1%83%95%E1%83%90%E1%83%93#Georgian) | falteringly, half-heartedly, hesitantly, hesitatingly, timorously | gaubedavad · adv |
| [გონება](https://en.wiktionary.org/wiki/%E1%83%92%E1%83%9D%E1%83%9C%E1%83%94%E1%83%91%E1%83%90#Georgian) | mind, intellect, reason, wit | goneba · noun |
| [მარაო](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%90%E1%83%A0%E1%83%90%E1%83%9D#Georgian) | fan (hand-held device) | marao · noun |
| [ურიკა](https://en.wiktionary.org/wiki/%E1%83%A3%E1%83%A0%E1%83%98%E1%83%99%E1%83%90#Georgian) | hand truck | uriḳa · noun |
| [ჭკუა](https://en.wiktionary.org/wiki/%E1%83%AD%E1%83%99%E1%83%A3%E1%83%90#Georgian) | mind | č̣ḳua · noun |
| [ხელი](https://en.wiktionary.org/wiki/%E1%83%AE%E1%83%94%E1%83%9A%E1%83%98#Georgian) | hand | xeli · noun |
| [ხშირ-ხშირად](https://en.wiktionary.org/wiki/%E1%83%AE%E1%83%A8%E1%83%98%E1%83%A0-%E1%83%AE%E1%83%A8%E1%83%98%E1%83%A0%E1%83%90%E1%83%93#Georgian) | often | xšir-xširad · adv |
| [ხშირად](https://en.wiktionary.org/wiki/%E1%83%AE%E1%83%A8%E1%83%98%E1%83%A0%E1%83%90%E1%83%93#Georgian) | often, frequently | xširad · adv |
| [გვამი](https://en.wiktionary.org/wiki/%E1%83%92%E1%83%95%E1%83%90%E1%83%9B%E1%83%98#Georgian) | cadaver, corpse, (dead) body | gvami · noun |
| [მართლად](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%90%E1%83%A0%E1%83%97%E1%83%9A%E1%83%90%E1%83%93#Georgian) | true, truthfully | martlad · adv |
| [სამხრეთი](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%90%E1%83%9B%E1%83%AE%E1%83%A0%E1%83%94%E1%83%97%E1%83%98#Georgian) | south | samxreti · noun |
| [საჭმელი](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%90%E1%83%AD%E1%83%9B%E1%83%94%E1%83%9A%E1%83%98#Georgian) | food (substance consumed by living organisms) | sač̣meli · noun |
| [სიკვდილი](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%98%E1%83%99%E1%83%95%E1%83%93%E1%83%98%E1%83%9A%E1%83%98#Georgian) | death | siḳvdili · noun |
| [სურსათი](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%A3%E1%83%A0%E1%83%A1%E1%83%90%E1%83%97%E1%83%98#Georgian) | supply of food, provisions | sursati · noun |
| [ჭეშმარიტი](https://en.wiktionary.org/wiki/%E1%83%AD%E1%83%94%E1%83%A8%E1%83%9B%E1%83%90%E1%83%A0%E1%83%98%E1%83%A2%E1%83%98#Georgian) | true | č̣ešmariṭi · adj |
| [არასწორად](https://en.wiktionary.org/wiki/%E1%83%90%E1%83%A0%E1%83%90%E1%83%A1%E1%83%AC%E1%83%9D%E1%83%A0%E1%83%90%E1%83%93#Georgian) | unduly, unfaithfully, untruly, wrong, wrongfully, wrongly | arasc̣orad · adv |
| [გამარჯვება](https://en.wiktionary.org/wiki/%E1%83%92%E1%83%90%E1%83%9B%E1%83%90%E1%83%A0%E1%83%AF%E1%83%95%E1%83%94%E1%83%91%E1%83%90#Georgian) | win, victory | gamarǯveba · noun |
| [თითქმის](https://en.wiktionary.org/wiki/%E1%83%97%E1%83%98%E1%83%97%E1%83%A5%E1%83%9B%E1%83%98%E1%83%A1#Georgian) | almost, nearly | titkmis · adv |
| [ისტორია](https://en.wiktionary.org/wiki/%E1%83%98%E1%83%A1%E1%83%A2%E1%83%9D%E1%83%A0%E1%83%98%E1%83%90#Georgian) | history | isṭoria · noun |
| [ოთახი](https://en.wiktionary.org/wiki/%E1%83%9D%E1%83%97%E1%83%90%E1%83%AE%E1%83%98#Georgian) | room, chamber | otaxi · noun |
| [რამდენიმე](https://en.wiktionary.org/wiki/%E1%83%A0%E1%83%90%E1%83%9B%E1%83%93%E1%83%94%E1%83%9C%E1%83%98%E1%83%9B%E1%83%94#Georgian) | several | ramdenime · pron |
| [სასადილო](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%90%E1%83%A1%E1%83%90%E1%83%93%E1%83%98%E1%83%9A%E1%83%9D#Georgian) | dining room | sasadilo · noun |
| [საჭირო ოთახი](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%90%E1%83%AD%E1%83%98%E1%83%A0%E1%83%9D%20%E1%83%9D%E1%83%97%E1%83%90%E1%83%AE%E1%83%98#Georgian) | a room containing a toilet | sač̣iro otaxi · noun |
| [სტუდენტი](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%A2%E1%83%A3%E1%83%93%E1%83%94%E1%83%9C%E1%83%A2%E1%83%98#Georgian) | university student | sṭudenṭi · noun |
| [ხრამი](https://en.wiktionary.org/wiki/%E1%83%AE%E1%83%A0%E1%83%90%E1%83%9B%E1%83%98#Georgian) | canyon (a large, deep, rocky ravine) | xrami · noun |
| [გასწვრივ](https://en.wiktionary.org/wiki/%E1%83%92%E1%83%90%E1%83%A1%E1%83%AC%E1%83%95%E1%83%A0%E1%83%98%E1%83%95#Georgian) | along, parallel to | gasc̣vriv · postp |
| [გოგო](https://en.wiktionary.org/wiki/%E1%83%92%E1%83%9D%E1%83%92%E1%83%9D#Georgian) | girl | gogo · noun |
| [ლამაზმანი](https://en.wiktionary.org/wiki/%E1%83%9A%E1%83%90%E1%83%9B%E1%83%90%E1%83%96%E1%83%9B%E1%83%90%E1%83%9C%E1%83%98#Georgian) | beauty (a pretty woman) | lamazmani · noun |
| [ალბათ](https://en.wiktionary.org/wiki/%E1%83%90%E1%83%9A%E1%83%91%E1%83%90%E1%83%97#Georgian) | probably | albat · adv |
| [ანდაზა](https://en.wiktionary.org/wiki/%E1%83%90%E1%83%9C%E1%83%93%E1%83%90%E1%83%96%E1%83%90#Georgian) | proverb, saying of tutorial characteristic | andaza · noun |
| [მეგობარი](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%94%E1%83%92%E1%83%9D%E1%83%91%E1%83%90%E1%83%A0%E1%83%98#Georgian) | friend | megobari · noun |
| [ხო](https://en.wiktionary.org/wiki/%E1%83%AE%E1%83%9D#Georgian) | yeah | xo · particle |
| [ჰო](https://en.wiktionary.org/wiki/%E1%83%B0%E1%83%9D#Georgian) | yeah | ho · particle |
| [ახლოს](https://en.wiktionary.org/wiki/%E1%83%90%E1%83%AE%E1%83%9A%E1%83%9D%E1%83%A1#Georgian) | close, closely, imminently, near, thereby | axlos · adv |

</details>

<details><summary>Words 501–550</summary>

![[Resources/Audio/ka/Words 0501-0550.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [გვერდზე](https://en.wiktionary.org/wiki/%E1%83%92%E1%83%95%E1%83%94%E1%83%A0%E1%83%93%E1%83%96%E1%83%94#Georgian) | by, past | gverdze · adv |
| [თუ შეიძლება](https://en.wiktionary.org/wiki/%E1%83%97%E1%83%A3%20%E1%83%A8%E1%83%94%E1%83%98%E1%83%AB%E1%83%9A%E1%83%94%E1%83%91%E1%83%90#Georgian) | if possible | tu šeiʒleba · phrase |
| [მოკვალთული](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%9D%E1%83%99%E1%83%95%E1%83%90%E1%83%9A%E1%83%97%E1%83%A3%E1%83%9A%E1%83%98#Georgian) | close-fitting (clothes) | moḳvaltuli · adj |
| [ნამყო](https://en.wiktionary.org/wiki/%E1%83%9C%E1%83%90%E1%83%9B%E1%83%A7%E1%83%9D#Georgian) | past | namq̇o · adj |
| [სასწრაფოდ](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%90%E1%83%A1%E1%83%AC%E1%83%A0%E1%83%90%E1%83%A4%E1%83%9D%E1%83%93#Georgian) | quickly, as soon as possible, urgently | sasc̣rapod · adv |
| [შესაძლებელი](https://en.wiktionary.org/wiki/%E1%83%A8%E1%83%94%E1%83%A1%E1%83%90%E1%83%AB%E1%83%9A%E1%83%94%E1%83%91%E1%83%94%E1%83%9A%E1%83%98#Georgian) | possible, feasible | šesaʒlebeli · adj |
| [ცნება](https://en.wiktionary.org/wiki/%E1%83%AA%E1%83%9C%E1%83%94%E1%83%91%E1%83%90#Georgian) | idea, notion, concept | cneba · noun |
| [ბედნიერი](https://en.wiktionary.org/wiki/%E1%83%91%E1%83%94%E1%83%93%E1%83%9C%E1%83%98%E1%83%94%E1%83%A0%E1%83%98#Georgian) | happy | bednieri · adj |
| [ბოშა-ქალი](https://en.wiktionary.org/wiki/%E1%83%91%E1%83%9D%E1%83%A8%E1%83%90-%E1%83%A5%E1%83%90%E1%83%9A%E1%83%98#Georgian) | Bosha woman, Lom woman | boša-kali · noun |
| [გილოცავ დაბადების დღეს](https://en.wiktionary.org/wiki/%E1%83%92%E1%83%98%E1%83%9A%E1%83%9D%E1%83%AA%E1%83%90%E1%83%95%20%E1%83%93%E1%83%90%E1%83%91%E1%83%90%E1%83%93%E1%83%94%E1%83%91%E1%83%98%E1%83%A1%20%E1%83%93%E1%83%A6%E1%83%94%E1%83%A1#Georgian) | happy birthday (singular) | gilocav dabadebis dɣes · phrase |
| [კითხვა](https://en.wiktionary.org/wiki/%E1%83%99%E1%83%98%E1%83%97%E1%83%AE%E1%83%95%E1%83%90#Georgian) | question | ḳitxva · noun |
| [სერია](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%94%E1%83%A0%E1%83%98%E1%83%90#Georgian) | series | seria · noun |
| [ქალი](https://en.wiktionary.org/wiki/%E1%83%A5%E1%83%90%E1%83%9A%E1%83%98#Georgian) | woman | kali · noun |
| [გვიან](https://en.wiktionary.org/wiki/%E1%83%92%E1%83%95%E1%83%98%E1%83%90%E1%83%9C#Georgian) | late | gvian · adv |
| [ჩრდილოეთი](https://en.wiktionary.org/wiki/%E1%83%A9%E1%83%A0%E1%83%93%E1%83%98%E1%83%9A%E1%83%9D%E1%83%94%E1%83%97%E1%83%98#Georgian) | north | črdiloeti · noun |
| [დილა](https://en.wiktionary.org/wiki/%E1%83%93%E1%83%98%E1%83%9A%E1%83%90#Georgian) | morning | dila · noun |
| [მარჯვედ](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%90%E1%83%A0%E1%83%AF%E1%83%95%E1%83%94%E1%83%93#Georgian) | ably, adroitly, artfully, craftily, cunningly, deftly, dexterously, felicitously, light-handedly | marǯved · adv |
| [მკვეთრად](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%99%E1%83%95%E1%83%94%E1%83%97%E1%83%A0%E1%83%90%E1%83%93#Georgian) | abruptly, boldly, brilliantly, sharply, short, stridently, bluffly | mḳvetrad · adv |
| [მოკლე](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%9D%E1%83%99%E1%83%9A%E1%83%94#Georgian) | short | moḳle · adj |
| [მოკლედ](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%9D%E1%83%99%E1%83%9A%E1%83%94%E1%83%93#Georgian) | briefly, in short | moḳled · adv |
| [მომავალი](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%9D%E1%83%9B%E1%83%90%E1%83%95%E1%83%90%E1%83%9A%E1%83%98#Georgian) | future | momavali · adj |
| [მსუბუქი](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%A1%E1%83%A3%E1%83%91%E1%83%A3%E1%83%A5%E1%83%98#Georgian) | light (of low weight) | msubuki · adj |
| [ჩირაღი](https://en.wiktionary.org/wiki/%E1%83%A9%E1%83%98%E1%83%A0%E1%83%90%E1%83%A6%E1%83%98#Georgian) | lamp, light | čiraɣi · noun |
| [ასაკი](https://en.wiktionary.org/wiki/%E1%83%90%E1%83%A1%E1%83%90%E1%83%99%E1%83%98#Georgian) | age | asaḳi · noun |
| [ბორა](https://en.wiktionary.org/wiki/%E1%83%91%E1%83%9D%E1%83%A0%E1%83%90#Georgian) | red kite | bora · noun |
| [მალე](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%90%E1%83%9A%E1%83%94#Georgian) | soon | [mäle̞] · adv |
| [წითელი](https://en.wiktionary.org/wiki/%E1%83%AC%E1%83%98%E1%83%97%E1%83%94%E1%83%9A%E1%83%98#Georgian) | red | c̣iteli · adj |
| [გუბ](https://en.wiktionary.org/wiki/%E1%83%92%E1%83%A3%E1%83%91#Georgian) | Ingilo form of გუბე (gube) | gub · noun |
| [გუბი](https://en.wiktionary.org/wiki/%E1%83%92%E1%83%A3%E1%83%91%E1%83%98#Georgian) | Khevi form of გუბე (gube) | gubi · noun |
| [გული](https://en.wiktionary.org/wiki/%E1%83%92%E1%83%A3%E1%83%9A%E1%83%98#Georgian) | heart | guli · noun |
| [ზეპირად](https://en.wiktionary.org/wiki/%E1%83%96%E1%83%94%E1%83%9E%E1%83%98%E1%83%A0%E1%83%90%E1%83%93#Georgian) | by heart | zeṗirad · adv |
| [სულიერი ტკივილი](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%A3%E1%83%9A%E1%83%98%E1%83%94%E1%83%A0%E1%83%98%20%E1%83%A2%E1%83%99%E1%83%98%E1%83%95%E1%83%98%E1%83%9A%E1%83%98#Georgian) | heart ache | sulieri ṭḳivili · noun |
| [ალი](https://en.wiktionary.org/wiki/%E1%83%90%E1%83%9A%E1%83%98#Georgian) | blaze, flame, fire | ali · noun |
| [ბიჭი](https://en.wiktionary.org/wiki/%E1%83%91%E1%83%98%E1%83%AD%E1%83%98#Georgian) | bastard, illegitimate child | bič̣i · noun |
| [მობილური](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%9D%E1%83%91%E1%83%98%E1%83%9A%E1%83%A3%E1%83%A0%E1%83%98#Georgian) | mobile phone | mobiluri · noun |
| [სვლა](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%95%E1%83%9A%E1%83%90#Georgian) | an act of walking | svla · noun |
| [შვილი](https://en.wiktionary.org/wiki/%E1%83%A8%E1%83%95%E1%83%98%E1%83%9A%E1%83%98#Georgian) | child | švili · noun |
| [ცეცხლი](https://en.wiktionary.org/wiki/%E1%83%AA%E1%83%94%E1%83%AA%E1%83%AE%E1%83%9A%E1%83%98#Georgian) | fire | cecxli · noun |
| [ადვილი](https://en.wiktionary.org/wiki/%E1%83%90%E1%83%93%E1%83%95%E1%83%98%E1%83%9A%E1%83%98#Georgian) | easy | advili · adj |
| [გეგმა](https://en.wiktionary.org/wiki/%E1%83%92%E1%83%94%E1%83%92%E1%83%9B%E1%83%90#Georgian) | plan | gegma · noun |
| [დასავლეთი](https://en.wiktionary.org/wiki/%E1%83%93%E1%83%90%E1%83%A1%E1%83%90%E1%83%95%E1%83%9A%E1%83%94%E1%83%97%E1%83%98#Georgian) | west | dasavleti · noun |
| [დასავლეთით](https://en.wiktionary.org/wiki/%E1%83%93%E1%83%90%E1%83%A1%E1%83%90%E1%83%95%E1%83%9A%E1%83%94%E1%83%97%E1%83%98%E1%83%97#Georgian) | west, westerly, westward, westwards | dasavletit · adv |
| [ექვსი](https://en.wiktionary.org/wiki/%E1%83%94%E1%83%A5%E1%83%95%E1%83%A1%E1%83%98#Georgian) | six (6) | ekvsi · num |
| [თავისუფლად](https://en.wiktionary.org/wiki/%E1%83%97%E1%83%90%E1%83%95%E1%83%98%E1%83%A1%E1%83%A3%E1%83%A4%E1%83%9A%E1%83%90%E1%83%93#Georgian) | freely, fluently, glibly, loosely, quite, sparely, swimmingly | tavisuplad · adv |
| [იოლად](https://en.wiktionary.org/wiki/%E1%83%98%E1%83%9D%E1%83%9A%E1%83%90%E1%83%93#Georgian) | easily, easy | iolad · adv |
| [მოუბარი](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%9D%E1%83%A3%E1%83%91%E1%83%90%E1%83%A0%E1%83%98#Georgian) | talking | moubari · adj |
| [ზოგჯერ](https://en.wiktionary.org/wiki/%E1%83%96%E1%83%9D%E1%83%92%E1%83%AF%E1%83%94%E1%83%A0#Georgian) | sometimes | zogǯer · adv |
| [მიხედვით](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%98%E1%83%AE%E1%83%94%E1%83%93%E1%83%95%E1%83%98%E1%83%97#Georgian) | according to | mixedvit · postp |
| [სია](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%98%E1%83%90#Georgian) | list | sia · noun |
| [ფოლორცი](https://en.wiktionary.org/wiki/%E1%83%A4%E1%83%9D%E1%83%9A%E1%83%9D%E1%83%A0%E1%83%AA%E1%83%98#Georgian) | street | polorci · noun |

</details>

<details><summary>Words 551–600</summary>

![[Resources/Audio/ka/Words 0551-0600.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [ძე](https://en.wiktionary.org/wiki/%E1%83%AB%E1%83%94#Georgian) | son | ʒe · noun |
| [წინა](https://en.wiktionary.org/wiki/%E1%83%AC%E1%83%98%E1%83%9C%E1%83%90#Georgian) | front | c̣ina · adj |
| [ხანდახან](https://en.wiktionary.org/wiki/%E1%83%AE%E1%83%90%E1%83%9C%E1%83%93%E1%83%90%E1%83%AE%E1%83%90%E1%83%9C#Georgian) | sometimes | xandaxan · adv |
| [ასლი](https://en.wiktionary.org/wiki/%E1%83%90%E1%83%A1%E1%83%9A%E1%83%98#Georgian) | emmer, a type of wheat (Triticum dicoccum) | asli · noun |
| [მაგალითი](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%90%E1%83%92%E1%83%90%E1%83%9A%E1%83%98%E1%83%97%E1%83%98#Georgian) | example | magaliti · noun |
| [ნახევრადფენოვანი](https://en.wiktionary.org/wiki/%E1%83%9C%E1%83%90%E1%83%AE%E1%83%94%E1%83%95%E1%83%A0%E1%83%90%E1%83%93%E1%83%A4%E1%83%94%E1%83%9C%E1%83%9D%E1%83%95%E1%83%90%E1%83%9C%E1%83%98#Georgian) | A type of khachapuri | naxevradpenovani · adj |
| [ტიპი](https://en.wiktionary.org/wiki/%E1%83%A2%E1%83%98%E1%83%9E%E1%83%98#Georgian) | type | ṭiṗi · noun |
| [მამა](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%90%E1%83%9B%E1%83%90#Georgian) | father | mama · noun |
| [სიმღერა](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%98%E1%83%9B%E1%83%A6%E1%83%94%E1%83%A0%E1%83%90#Georgian) | song | simɣera · noun |
| [სიტყვა](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%98%E1%83%A2%E1%83%A7%E1%83%95%E1%83%90#Georgian) | word | siṭq̇va · noun |
| [განივ](https://en.wiktionary.org/wiki/%E1%83%92%E1%83%90%E1%83%9C%E1%83%98%E1%83%95#Georgian) | across, athwart | ganiv · adv |
| [გარდიგარდმო](https://en.wiktionary.org/wiki/%E1%83%92%E1%83%90%E1%83%A0%E1%83%93%E1%83%98%E1%83%92%E1%83%90%E1%83%A0%E1%83%93%E1%83%9B%E1%83%9D#Georgian) | across, transversely, obliquely, athwart, breadthwise | gardigardmo · adv |
| [გარე](https://en.wiktionary.org/wiki/%E1%83%92%E1%83%90%E1%83%A0%E1%83%94#Georgian) | external, outside, outward, outer | gare · adv |
| [თვე](https://en.wiktionary.org/wiki/%E1%83%97%E1%83%95%E1%83%94#Georgian) | month | tve · noun |
| [წაშლა](https://en.wiktionary.org/wiki/%E1%83%AC%E1%83%90%E1%83%A8%E1%83%9A%E1%83%90#Georgian) | delete, clear | c̣ašla · noun |
| [აგარაკი](https://en.wiktionary.org/wiki/%E1%83%90%E1%83%92%E1%83%90%E1%83%A0%E1%83%90%E1%83%99%E1%83%98#Georgian) | field; camp; dacha; village | agaraḳi · noun |
| [დედა](https://en.wiktionary.org/wiki/%E1%83%93%E1%83%94%E1%83%93%E1%83%90#Georgian) | mother | deda · noun |
| [ველი](https://en.wiktionary.org/wiki/%E1%83%95%E1%83%94%E1%83%9A%E1%83%98#Georgian) | field | veli · noun |
| [მაგივრად](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%90%E1%83%92%E1%83%98%E1%83%95%E1%83%A0%E1%83%90%E1%83%93#Georgian) | instead of | magivrad · postp |
| [მინდორი](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%98%E1%83%9C%E1%83%93%E1%83%9D%E1%83%A0%E1%83%98#Georgian) | meadow, field | mindori · noun |
| [მშობლიური ენა](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%A8%E1%83%9D%E1%83%91%E1%83%9A%E1%83%98%E1%83%A3%E1%83%A0%E1%83%98%20%E1%83%94%E1%83%9C%E1%83%90#Georgian) | mother tongue, native language | mšobliuri ena · noun |
| [ნაცვლად](https://en.wiktionary.org/wiki/%E1%83%9C%E1%83%90%E1%83%AA%E1%83%95%E1%83%9A%E1%83%90%E1%83%93#Georgian) | instead of | nacvlad · postp |
| [პირუთვნელად](https://en.wiktionary.org/wiki/%E1%83%9E%E1%83%98%E1%83%A0%E1%83%A3%E1%83%97%E1%83%95%E1%83%9C%E1%83%94%E1%83%9A%E1%83%90%E1%83%93#Georgian) | above board | ṗirutvnelad · adv |
| [ფასი](https://en.wiktionary.org/wiki/%E1%83%A4%E1%83%90%E1%83%A1%E1%83%98#Georgian) | price, cost | pasi · noun |
| [დახვეწილად](https://en.wiktionary.org/wiki/%E1%83%93%E1%83%90%E1%83%AE%E1%83%95%E1%83%94%E1%83%AC%E1%83%98%E1%83%9A%E1%83%90%E1%83%93#Georgian) | delicately, fine | daxvec̣ilad · adv |
| [ზაფხული](https://en.wiktionary.org/wiki/%E1%83%96%E1%83%90%E1%83%A4%E1%83%AE%E1%83%A3%E1%83%9A%E1%83%98#Georgian) | summer | zapxuli · noun |
| [ცოლი](https://en.wiktionary.org/wiki/%E1%83%AA%E1%83%9D%E1%83%9A%E1%83%98#Georgian) | wife | coli · noun |
| [დელგმა](https://en.wiktionary.org/wiki/%E1%83%93%E1%83%94%E1%83%9A%E1%83%92%E1%83%9B%E1%83%90#Georgian) | strong rain | delgma · noun |
| [ლამაზი](https://en.wiktionary.org/wiki/%E1%83%9A%E1%83%90%E1%83%9B%E1%83%90%E1%83%96%E1%83%98#Georgian) | beautiful, handsome | lamazi · adj |
| [მიწა](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%98%E1%83%AC%E1%83%90#Georgian) | ground, land | mic̣a · noun |
| [პიტალო](https://en.wiktionary.org/wiki/%E1%83%9E%E1%83%98%E1%83%A2%E1%83%90%E1%83%9A%E1%83%9D#Georgian) | strong, tough | ṗiṭalo · adj |
| [სექსი](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%94%E1%83%A5%E1%83%A1%E1%83%98#Georgian) | sex | seksi · noun |
| [სქესი](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%A5%E1%83%94%E1%83%A1%E1%83%98#Georgian) | sex | skesi · noun |
| [ძლიერი](https://en.wiktionary.org/wiki/%E1%83%AB%E1%83%9A%E1%83%98%E1%83%94%E1%83%A0%E1%83%98#Georgian) | strong | ʒlieri · adj |
| [ასორტი](https://en.wiktionary.org/wiki/%E1%83%90%E1%83%A1%E1%83%9D%E1%83%A0%E1%83%A2%E1%83%98#Georgian) | assortment (especially of foodstuffs) | asorṭi · noun |
| [განსაკუთრებით](https://en.wiktionary.org/wiki/%E1%83%92%E1%83%90%E1%83%9C%E1%83%A1%E1%83%90%E1%83%99%E1%83%A3%E1%83%97%E1%83%A0%E1%83%94%E1%83%91%E1%83%98%E1%83%97#Georgian) | especially, notably | gansaḳutrebit · adv |
| [განსაკუთრებულად](https://en.wiktionary.org/wiki/%E1%83%92%E1%83%90%E1%83%9C%E1%83%A1%E1%83%90%E1%83%99%E1%83%A3%E1%83%97%E1%83%A0%E1%83%94%E1%83%91%E1%83%A3%E1%83%9A%E1%83%90%E1%83%93#Georgian) | especially, exceptionally, exclusively, peculiarly | gansaḳutrebulad · adv |
| [სასმელი](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%90%E1%83%A1%E1%83%9B%E1%83%94%E1%83%9A%E1%83%98#Georgian) | drink, beverage (especially alcoholic ones) | sasmeli · noun |
| [-ზე](https://en.wiktionary.org/wiki/-%E1%83%96%E1%83%94#Georgian) | on, above, onto | -ze · postp |
| [ზემოთ](https://en.wiktionary.org/wiki/%E1%83%96%E1%83%94%E1%83%9B%E1%83%9D%E1%83%97#Georgian) | above, up, upstairs | zemot · adv |
| [მხედრული](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%AE%E1%83%94%E1%83%93%E1%83%A0%E1%83%A3%E1%83%9A%E1%83%98#Georgian) | military, cavalry | mxedruli · adj |
| [ტანკი](https://en.wiktionary.org/wiki/%E1%83%A2%E1%83%90%E1%83%9C%E1%83%99%E1%83%98#Georgian) | military tank | ṭanḳi · noun |
| [ტყვია](https://en.wiktionary.org/wiki/%E1%83%A2%E1%83%A7%E1%83%95%E1%83%98%E1%83%90#Georgian) | lead (metal, chemical element), plumbum (chemical element) | ṭq̇via · noun |
| [ფილმი](https://en.wiktionary.org/wiki/%E1%83%A4%E1%83%98%E1%83%9A%E1%83%9B%E1%83%98#Georgian) | movie, film, motion picture | pilmi · noun |
| [ვარსკვლავი](https://en.wiktionary.org/wiki/%E1%83%95%E1%83%90%E1%83%A0%E1%83%A1%E1%83%99%E1%83%95%E1%83%9A%E1%83%90%E1%83%95%E1%83%98#Georgian) | star | varsḳvlavi · noun |
| [მკვდარი](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%99%E1%83%95%E1%83%93%E1%83%90%E1%83%A0%E1%83%98#Georgian) | dead | mḳvdari · adj |
| [შიგნით](https://en.wiktionary.org/wiki/%E1%83%A8%E1%83%98%E1%83%92%E1%83%9C%E1%83%98%E1%83%97#Georgian) | inside | šignit · adv |
| [ბოდიში](https://en.wiktionary.org/wiki/%E1%83%91%E1%83%9D%E1%83%93%E1%83%98%E1%83%A8%E1%83%98#Georgian) | sorry | bodiši · intj |
| [მოვლენათა ჰორიზონტი](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%9D%E1%83%95%E1%83%9A%E1%83%94%E1%83%9C%E1%83%90%E1%83%97%E1%83%90%20%E1%83%B0%E1%83%9D%E1%83%A0%E1%83%98%E1%83%96%E1%83%9D%E1%83%9C%E1%83%A2%E1%83%98#Georgian) | event horizon | movlenata horizonṭi · noun |
| [საათი](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%90%E1%83%90%E1%83%97%E1%83%98#Georgian) | hour | saati · noun |

</details>

<details><summary>Words 601–650</summary>

![[Resources/Audio/ka/Words 0601-0650.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [უკაცრავად](https://en.wiktionary.org/wiki/%E1%83%A3%E1%83%99%E1%83%90%E1%83%AA%E1%83%A0%E1%83%90%E1%83%95%E1%83%90%E1%83%93#Georgian) | excuse me, sorry | uḳacravad · intj |
| [შედეგი](https://en.wiktionary.org/wiki/%E1%83%A8%E1%83%94%E1%83%93%E1%83%94%E1%83%92%E1%83%98#Georgian) | result | šedegi · noun |
| [წევრი](https://en.wiktionary.org/wiki/%E1%83%AC%E1%83%94%E1%83%95%E1%83%A0%E1%83%98#Georgian) | member | c̣evri · noun |
| [დაბოლოება](https://en.wiktionary.org/wiki/%E1%83%93%E1%83%90%E1%83%91%E1%83%9D%E1%83%9A%E1%83%9D%E1%83%94%E1%83%91%E1%83%90#Georgian) | finally | daboloeba · adv |
| [მეფე](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%94%E1%83%A4%E1%83%94#Georgian) | king | mepe · noun |
| [ოქრო](https://en.wiktionary.org/wiki/%E1%83%9D%E1%83%A5%E1%83%A0%E1%83%9D#Georgian) | gold | okro · noun |
| [პასუხი](https://en.wiktionary.org/wiki/%E1%83%9E%E1%83%90%E1%83%A1%E1%83%A3%E1%83%AE%E1%83%98#Georgian) | answer | ṗasuxi · noun |
| [საბოლოოდ](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%90%E1%83%91%E1%83%9D%E1%83%9A%E1%83%9D%E1%83%9D%E1%83%93#Georgian) | conclusively, decisively, eventually, terminally, ultimately, finally | sabolood · adv |
| [სირმა](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%98%E1%83%A0%E1%83%9B%E1%83%90#Georgian) | gold or silver thread | sirma · noun |
| [არმოსავლეთისა](https://en.wiktionary.org/wiki/%E1%83%90%E1%83%A0%E1%83%9B%E1%83%9D%E1%83%A1%E1%83%90%E1%83%95%E1%83%9A%E1%83%94%E1%83%97%E1%83%98%E1%83%A1%E1%83%90#Georgian) | east | armosavletisa · adv |
| [აღმოსავლეთი](https://en.wiktionary.org/wiki/%E1%83%90%E1%83%A6%E1%83%9B%E1%83%9D%E1%83%A1%E1%83%90%E1%83%95%E1%83%9A%E1%83%94%E1%83%97%E1%83%98#Georgian) | east | aɣmosavleti · noun |
| [ეკლესია](https://en.wiktionary.org/wiki/%E1%83%94%E1%83%99%E1%83%9A%E1%83%94%E1%83%A1%E1%83%98%E1%83%90#Georgian) | church | eḳlesia · noun |
| [კინო](https://en.wiktionary.org/wiki/%E1%83%99%E1%83%98%E1%83%9C%E1%83%9D#Georgian) | movie | ḳino · noun |
| [მარტო](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%90%E1%83%A0%E1%83%A2%E1%83%9D#Georgian) | alone | marṭo · adv |
| [ორიგინალი](https://en.wiktionary.org/wiki/%E1%83%9D%E1%83%A0%E1%83%98%E1%83%92%E1%83%98%E1%83%9C%E1%83%90%E1%83%9A%E1%83%98#Georgian) | original | originali · adj |
| [რამდენადმე](https://en.wiktionary.org/wiki/%E1%83%A0%E1%83%90%E1%83%9B%E1%83%93%E1%83%94%E1%83%9C%E1%83%90%E1%83%93%E1%83%9B%E1%83%94#Georgian) | To a certain extent, somewhat | ramdenadme · adv |
| [ცხელი](https://en.wiktionary.org/wiki/%E1%83%AA%E1%83%AE%E1%83%94%E1%83%9A%E1%83%98#Georgian) | hot | cxeli · adj |
| [წიწაკა](https://en.wiktionary.org/wiki/%E1%83%AC%E1%83%98%E1%83%AC%E1%83%90%E1%83%99%E1%83%90#Georgian) | hot pepper | c̣ic̣aḳa · noun |
| [ჯვარდაწერილი](https://en.wiktionary.org/wiki/%E1%83%AF%E1%83%95%E1%83%90%E1%83%A0%E1%83%93%E1%83%90%E1%83%AC%E1%83%94%E1%83%A0%E1%83%98%E1%83%9A%E1%83%98#Georgian) | married (in church) | ǯvardac̣erili · adj |
| [ჯვრისწერა](https://en.wiktionary.org/wiki/%E1%83%AF%E1%83%95%E1%83%A0%E1%83%98%E1%83%A1%E1%83%AC%E1%83%94%E1%83%A0%E1%83%90#Georgian) | wedding ceremony (in a church) | ǯvrisc̣era · noun |
| [ნისკარტი](https://en.wiktionary.org/wiki/%E1%83%9C%E1%83%98%E1%83%A1%E1%83%99%E1%83%90%E1%83%A0%E1%83%A2%E1%83%98#Georgian) | beak; bill | nisḳarṭi · noun |
| [შეხვედრა](https://en.wiktionary.org/wiki/%E1%83%A8%E1%83%94%E1%83%AE%E1%83%95%E1%83%94%E1%83%93%E1%83%A0%E1%83%90#Georgian) | meeting | šexvedra · noun |
| [ძერსკი](https://en.wiktionary.org/wiki/%E1%83%AB%E1%83%94%E1%83%A0%E1%83%A1%E1%83%99%E1%83%98#Georgian) | cool | ʒersḳi · adj |
| [მატიანე](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%90%E1%83%A2%E1%83%98%E1%83%90%E1%83%9C%E1%83%94#Georgian) | saints' lives, hagiography (of saints), hagiology | maṭiane · noun |
| [ტური](https://en.wiktionary.org/wiki/%E1%83%A2%E1%83%A3%E1%83%A0%E1%83%98#Georgian) | round | ṭuri · noun |
| [წარმოქმნა](https://en.wiktionary.org/wiki/%E1%83%AC%E1%83%90%E1%83%A0%E1%83%9B%E1%83%9D%E1%83%A5%E1%83%9B%E1%83%9C%E1%83%90#Georgian) | formation, generation, production, creation | c̣armokmna · noun |
| [ლურჯი](https://en.wiktionary.org/wiki/%E1%83%9A%E1%83%A3%E1%83%A0%E1%83%AF%E1%83%98#Georgian) | blue | lurǯi · adj |
| [მწვანე](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%AC%E1%83%95%E1%83%90%E1%83%9C%E1%83%94#Georgian) | green | mc̣vane · adj |
| [საშობაო მარხვა](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%90%E1%83%A8%E1%83%9D%E1%83%91%E1%83%90%E1%83%9D%20%E1%83%9B%E1%83%90%E1%83%A0%E1%83%AE%E1%83%95%E1%83%90#Georgian) | Nativity Fast | sašobao marxva · noun |
| [სურათი](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%A3%E1%83%A0%E1%83%90%E1%83%97%E1%83%98#Georgian) | picture | surati · noun |
| [შემოდგომა](https://en.wiktionary.org/wiki/%E1%83%A8%E1%83%94%E1%83%9B%E1%83%9D%E1%83%93%E1%83%92%E1%83%9D%E1%83%9B%E1%83%90#Georgian) | autumn, fall | šemodgoma · noun |
| [ჩქარა](https://en.wiktionary.org/wiki/%E1%83%A9%E1%83%A5%E1%83%90%E1%83%A0%E1%83%90#Georgian) | fast, quickly, rapidly | čkara · adv |
| [ცისფერი](https://en.wiktionary.org/wiki/%E1%83%AA%E1%83%98%E1%83%A1%E1%83%A4%E1%83%94%E1%83%A0%E1%83%98#Georgian) | sky blue | cisperi · adj |
| [ხარისხი](https://en.wiktionary.org/wiki/%E1%83%AE%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%E1%83%AE%E1%83%98#Georgian) | step (of a stair) | xarisxi · noun |
| [დედიკო](https://en.wiktionary.org/wiki/%E1%83%93%E1%83%94%E1%83%93%E1%83%98%E1%83%99%E1%83%9D#Georgian) | mommy, mummy, mom | dediḳo · noun |
| [წინ](https://en.wiktionary.org/wiki/%E1%83%AC%E1%83%98%E1%83%9C#Georgian) | forward, ahead | c̣in · adv |
| [თვისება](https://en.wiktionary.org/wiki/%E1%83%97%E1%83%95%E1%83%98%E1%83%A1%E1%83%94%E1%83%91%E1%83%90#Georgian) | property | tviseba · noun |
| [საკუთრება](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%90%E1%83%99%E1%83%A3%E1%83%97%E1%83%A0%E1%83%94%E1%83%91%E1%83%90#Georgian) | property | saḳutreba · noun |
| [სტილი](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%A2%E1%83%98%E1%83%9A%E1%83%98#Georgian) | style | sṭili · noun |
| [ფეხბურთი](https://en.wiktionary.org/wiki/%E1%83%A4%E1%83%94%E1%83%AE%E1%83%91%E1%83%A3%E1%83%A0%E1%83%97%E1%83%98#Georgian) | association football | pexburti · noun |
| [ქვემო](https://en.wiktionary.org/wiki/%E1%83%A5%E1%83%95%E1%83%94%E1%83%9B%E1%83%9D#Georgian) | lower, bottom | kvemo · adj |
| [ყაიდა](https://en.wiktionary.org/wiki/%E1%83%A7%E1%83%90%E1%83%98%E1%83%93%E1%83%90#Georgian) | character, temper, manner, precept, rule, principle | q̇aida · noun |
| [ძამია](https://en.wiktionary.org/wiki/%E1%83%AB%E1%83%90%E1%83%9B%E1%83%98%E1%83%90#Georgian) | brother | ʒamia · noun |
| [ძმა](https://en.wiktionary.org/wiki/%E1%83%AB%E1%83%9B%E1%83%90#Georgian) | brother | ʒma · noun |
| [ჭიქა](https://en.wiktionary.org/wiki/%E1%83%AD%E1%83%98%E1%83%A5%E1%83%90#Georgian) | glass, cup, mug | č̣ika · noun |
| [ენა](https://en.wiktionary.org/wiki/%E1%83%94%E1%83%9C%E1%83%90#Georgian) | language | ena · noun |
| [ზეთი](https://en.wiktionary.org/wiki/%E1%83%96%E1%83%94%E1%83%97%E1%83%98#Georgian) | oil | zeti · noun |
| [კოპტონი](https://en.wiktionary.org/wiki/%E1%83%99%E1%83%9D%E1%83%9E%E1%83%A2%E1%83%9D%E1%83%9C%E1%83%98#Georgian) | oil cake | ḳoṗṭoni · noun |
| [მბრძანებელი](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%91%E1%83%A0%E1%83%AB%E1%83%90%E1%83%9C%E1%83%94%E1%83%91%E1%83%94%E1%83%9A%E1%83%98#Georgian) | ruler, sovereign, lord, overlord, master | mbrʒanebeli · noun |
| [ნაგაზი](https://en.wiktionary.org/wiki/%E1%83%9C%E1%83%90%E1%83%92%E1%83%90%E1%83%96%E1%83%98#Georgian) | shepherd dog, sheepdog | nagazi · noun |

</details>

<details><summary>Words 651–700</summary>

![[Resources/Audio/ka/Words 0651-0700.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [სისხლი](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%98%E1%83%A1%E1%83%AE%E1%83%9A%E1%83%98#Georgian) | blood | sisxli · noun |
| [უნგრული ენა](https://en.wiktionary.org/wiki/%E1%83%A3%E1%83%9C%E1%83%92%E1%83%A0%E1%83%A3%E1%83%9A%E1%83%98%20%E1%83%94%E1%83%9C%E1%83%90#Georgian) | Hungarian (language) | ungruli ena · noun |
| [ჩიხუახუა](https://en.wiktionary.org/wiki/%E1%83%A9%E1%83%98%E1%83%AE%E1%83%A3%E1%83%90%E1%83%AE%E1%83%A3%E1%83%90#Georgian) | Chihuahua dog | čixuaxua · noun |
| [ძაღლი](https://en.wiktionary.org/wiki/%E1%83%AB%E1%83%90%E1%83%A6%E1%83%9A%E1%83%98#Georgian) | dog | ʒaɣli · noun |
| [ჭრაქი](https://en.wiktionary.org/wiki/%E1%83%AD%E1%83%A0%E1%83%90%E1%83%A5%E1%83%98#Georgian) | oil-lamp, wick lamp | č̣raki · noun |
| [ჯანდაბა](https://en.wiktionary.org/wiki/%E1%83%AF%E1%83%90%E1%83%9C%E1%83%93%E1%83%90%E1%83%91%E1%83%90#Georgian) | hell | ǯandaba · noun |
| [ჯოჯოხეთი](https://en.wiktionary.org/wiki/%E1%83%AF%E1%83%9D%E1%83%AF%E1%83%9D%E1%83%AE%E1%83%94%E1%83%97%E1%83%98#Georgian) | hell | ǯoǯoxeti · noun |
| [პონტი](https://en.wiktionary.org/wiki/%E1%83%9E%E1%83%9D%E1%83%9C%E1%83%A2%E1%83%98#Georgian) | situation | ṗonṭi · noun |
| [დოღი](https://en.wiktionary.org/wiki/%E1%83%93%E1%83%9D%E1%83%A6%E1%83%98#Georgian) | horse race | doɣi · noun |
| [თეთრი რასა](https://en.wiktionary.org/wiki/%E1%83%97%E1%83%94%E1%83%97%E1%83%A0%E1%83%98%20%E1%83%A0%E1%83%90%E1%83%A1%E1%83%90#Georgian) | Caucasian (race) | [tʰe̞tʰɾi ɾäsä] · noun |
| [თმა](https://en.wiktionary.org/wiki/%E1%83%97%E1%83%9B%E1%83%90#Georgian) | hair | tma · noun |
| [კანონიერი](https://en.wiktionary.org/wiki/%E1%83%99%E1%83%90%E1%83%9C%E1%83%9D%E1%83%9C%E1%83%98%E1%83%94%E1%83%A0%E1%83%98#Georgian) | lawful, legal | ḳanonieri · adj |
| [კარი](https://en.wiktionary.org/wiki/%E1%83%99%E1%83%90%E1%83%A0%E1%83%98#Georgian) | door | ḳari · noun |
| [კვერთხი](https://en.wiktionary.org/wiki/%E1%83%99%E1%83%95%E1%83%94%E1%83%A0%E1%83%97%E1%83%AE%E1%83%98#Georgian) | rod, staff | ḳvertxi · noun |
| [კოდექსი](https://en.wiktionary.org/wiki/%E1%83%99%E1%83%9D%E1%83%93%E1%83%94%E1%83%A5%E1%83%A1%E1%83%98#Georgian) | code | ḳodeksi · noun |
| [მარტივი](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%90%E1%83%A0%E1%83%A2%E1%83%98%E1%83%95%E1%83%98#Georgian) | simple | marṭivi · adj |
| [ნიშანი](https://en.wiktionary.org/wiki/%E1%83%9C%E1%83%98%E1%83%A8%E1%83%90%E1%83%9C%E1%83%98#Georgian) | sign, mark, symbol | nišani · noun |
| [სადა](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%90%E1%83%93%E1%83%90#Georgian) | simple, ordinary, plain | sada · adj |
| [სადად](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%90%E1%83%93%E1%83%90%E1%83%93#Georgian) | simply, plainly, modestly | sadad · adv |
| [სამანი](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%90%E1%83%9B%E1%83%90%E1%83%9C%E1%83%98#Georgian) | boundary sign | samani · noun |
| [უბრალო](https://en.wiktionary.org/wiki/%E1%83%A3%E1%83%91%E1%83%A0%E1%83%90%E1%83%9A%E1%83%9D#Georgian) | mere, simple | ubralo · adj |
| [შვიდი](https://en.wiktionary.org/wiki/%E1%83%A8%E1%83%95%E1%83%98%E1%83%93%E1%83%98#Georgian) | seven (7) | švidi · num |
| [ხუფი](https://en.wiktionary.org/wiki/%E1%83%AE%E1%83%A3%E1%83%A4%E1%83%98#Georgian) | lid, cover | xupi · noun |
| [ჯოხი](https://en.wiktionary.org/wiki/%E1%83%AF%E1%83%9D%E1%83%AE%E1%83%98#Georgian) | stick, staff | ǯoxi · noun |
| [ასული](https://en.wiktionary.org/wiki/%E1%83%90%E1%83%A1%E1%83%A3%E1%83%9A%E1%83%98#Georgian) | daughter | asuli · noun |
| [ლოგინი](https://en.wiktionary.org/wiki/%E1%83%9A%E1%83%9D%E1%83%92%E1%83%98%E1%83%9C%E1%83%98#Georgian) | bed | logini · noun |
| [მედდა](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%94%E1%83%93%E1%83%93%E1%83%90#Georgian) | hospital nurse | medda · noun |
| [საავადმყოფო](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%90%E1%83%90%E1%83%95%E1%83%90%E1%83%93%E1%83%9B%E1%83%A7%E1%83%9D%E1%83%A4%E1%83%9D#Georgian) | hospital | saavadmq̇opo · noun |
| [საწოლი](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%90%E1%83%AC%E1%83%9D%E1%83%9A%E1%83%98#Georgian) | bed | sac̣oli · noun |
| [ქაღალდი](https://en.wiktionary.org/wiki/%E1%83%A5%E1%83%90%E1%83%A6%E1%83%90%E1%83%9A%E1%83%93%E1%83%98#Georgian) | paper | kaɣaldi · noun |
| [-კენ](https://en.wiktionary.org/wiki/-%E1%83%99%E1%83%94%E1%83%9C#Georgian) | towards | -ḳen · postp |
| [ბატონი](https://en.wiktionary.org/wiki/%E1%83%91%E1%83%90%E1%83%A2%E1%83%9D%E1%83%9C%E1%83%98#Georgian) | gentleman, mister, sir | baṭoni · noun |
| [ზღვა](https://en.wiktionary.org/wiki/%E1%83%96%E1%83%A6%E1%83%95%E1%83%90#Georgian) | sea | zɣva · noun |
| [მოლოდინი](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%9D%E1%83%9A%E1%83%9D%E1%83%93%E1%83%98%E1%83%9C%E1%83%98#Georgian) | expectation, waiting; anticipation | molodini · noun |
| [ნიადაგი](https://en.wiktionary.org/wiki/%E1%83%9C%E1%83%98%E1%83%90%E1%83%93%E1%83%90%E1%83%92%E1%83%98#Georgian) | soil, earth | niadagi · noun |
| [შენი ჭირიმე](https://en.wiktionary.org/wiki/%E1%83%A8%E1%83%94%E1%83%9C%E1%83%98%20%E1%83%AD%E1%83%98%E1%83%A0%E1%83%98%E1%83%9B%E1%83%94#Georgian) | an untranslatable expression of endearment towards a familiar listener. | šeni č̣irime · phrase |
| [ათი](https://en.wiktionary.org/wiki/%E1%83%90%E1%83%97%E1%83%98#Georgian) | ten (10) | ati · num |
| [მაგიდა](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%90%E1%83%92%E1%83%98%E1%83%93%E1%83%90#Georgian) | table | magida · noun |
| [მკერდამდე](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%99%E1%83%94%E1%83%A0%E1%83%93%E1%83%90%E1%83%9B%E1%83%93%E1%83%94#Georgian) | breast-deep | mḳerdamde · adv |
| [ძილი](https://en.wiktionary.org/wiki/%E1%83%AB%E1%83%98%E1%83%9A%E1%83%98#Georgian) | sleep | ʒili · noun |
| [წინადადება](https://en.wiktionary.org/wiki/%E1%83%AC%E1%83%98%E1%83%9C%E1%83%90%E1%83%93%E1%83%90%E1%83%93%E1%83%94%E1%83%91%E1%83%90#Georgian) | offer, suggestion, proposal | c̣inadadeba · noun |
| [ბარათი](https://en.wiktionary.org/wiki/%E1%83%91%E1%83%90%E1%83%A0%E1%83%90%E1%83%97%E1%83%98#Georgian) | card | barati · noun |
| [ბურთი](https://en.wiktionary.org/wiki/%E1%83%91%E1%83%A3%E1%83%A0%E1%83%97%E1%83%98#Georgian) | ball | burti · noun |
| [კედელი](https://en.wiktionary.org/wiki/%E1%83%99%E1%83%94%E1%83%93%E1%83%94%E1%83%9A%E1%83%98#Georgian) | wall | ḳedeli · noun |
| [კოლოფი](https://en.wiktionary.org/wiki/%E1%83%99%E1%83%9D%E1%83%9A%E1%83%9D%E1%83%A4%E1%83%98#Georgian) | casket, box, ark | ḳolopi · noun |
| [ლითონი](https://en.wiktionary.org/wiki/%E1%83%9A%E1%83%98%E1%83%97%E1%83%9D%E1%83%9C%E1%83%98#Georgian) | mine | litoni · noun |
| [მაღარო](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%90%E1%83%A6%E1%83%90%E1%83%A0%E1%83%9D#Georgian) | mine | maɣaro · noun |
| [ნაწილ-ნაწილ](https://en.wiktionary.org/wiki/%E1%83%9C%E1%83%90%E1%83%AC%E1%83%98%E1%83%9A-%E1%83%9C%E1%83%90%E1%83%AC%E1%83%98%E1%83%9A#Georgian) | piece by piece, piecemeal | nac̣il-nac̣il · adv |
| [პირდაპირ](https://en.wiktionary.org/wiki/%E1%83%9E%E1%83%98%E1%83%A0%E1%83%93%E1%83%90%E1%83%9E%E1%83%98%E1%83%A0#Georgian) | directly, straight | ṗirdaṗir · adv |
| [ყუთი](https://en.wiktionary.org/wiki/%E1%83%A7%E1%83%A3%E1%83%97%E1%83%98#Georgian) | box | q̇uti · noun |

</details>

<details><summary>Words 701–750</summary>

![[Resources/Audio/ka/Words 0701-0750.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [ბრაწი](https://en.wiktionary.org/wiki/%E1%83%91%E1%83%A0%E1%83%90%E1%83%AC%E1%83%98#Georgian) | a plant of rock | brac̣i · noun |
| [გასინჯვა](https://en.wiktionary.org/wiki/%E1%83%92%E1%83%90%E1%83%A1%E1%83%98%E1%83%9C%E1%83%AF%E1%83%95%E1%83%90#Georgian) | examination (by a doctor, etc) | gasinǯva · noun |
| [და ა.შ.](https://en.wiktionary.org/wiki/%E1%83%93%E1%83%90%20%E1%83%90.%E1%83%A8.#Georgian) | etc. | da a.š. · adv |
| [მდინარე](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%93%E1%83%98%E1%83%9C%E1%83%90%E1%83%A0%E1%83%94#Georgian) | river, stream | mdinare · noun |
| [ნორმა](https://en.wiktionary.org/wiki/%E1%83%9C%E1%83%9D%E1%83%A0%E1%83%9B%E1%83%90#Georgian) | standard | norma · noun |
| [ქარაფი](https://en.wiktionary.org/wiki/%E1%83%A5%E1%83%90%E1%83%A0%E1%83%90%E1%83%A4%E1%83%98#Georgian) | cliff, rock | karapi · noun |
| [ქართულად ვერ ვლაპარაკობ](https://en.wiktionary.org/wiki/%E1%83%A5%E1%83%90%E1%83%A0%E1%83%97%E1%83%A3%E1%83%9A%E1%83%90%E1%83%93%20%E1%83%95%E1%83%94%E1%83%A0%20%E1%83%95%E1%83%9A%E1%83%90%E1%83%9E%E1%83%90%E1%83%A0%E1%83%90%E1%83%99%E1%83%9D%E1%83%91#Georgian) | I don’t speak Georgian | kartulad ver vlaṗaraḳob · phrase |
| [ქართულად ვლაპარაკობ](https://en.wiktionary.org/wiki/%E1%83%A5%E1%83%90%E1%83%A0%E1%83%97%E1%83%A3%E1%83%9A%E1%83%90%E1%83%93%20%E1%83%95%E1%83%9A%E1%83%90%E1%83%9E%E1%83%90%E1%83%A0%E1%83%90%E1%83%99%E1%83%9D%E1%83%91#Georgian) | I speak Georgian | kartulad vlaṗaraḳob · phrase |
| [დუქანი](https://en.wiktionary.org/wiki/%E1%83%93%E1%83%A3%E1%83%A5%E1%83%90%E1%83%9C%E1%83%98#Georgian) | shop, store | dukani · noun |
| [თვალი](https://en.wiktionary.org/wiki/%E1%83%97%E1%83%95%E1%83%90%E1%83%9A%E1%83%98#Georgian) | eye | tvali · noun |
| [თხლე](https://en.wiktionary.org/wiki/%E1%83%97%E1%83%AE%E1%83%9A%E1%83%94#Georgian) | sediment of recently pressed wine | txle · noun |
| [მაღაზია](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%90%E1%83%A6%E1%83%90%E1%83%96%E1%83%98%E1%83%90#Georgian) | shop, store | maɣazia · noun |
| [მშვიდობა](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%A8%E1%83%95%E1%83%98%E1%83%93%E1%83%9D%E1%83%91%E1%83%90#Georgian) | peace | mšvidoba · noun |
| [რვა](https://en.wiktionary.org/wiki/%E1%83%A0%E1%83%95%E1%83%90#Georgian) | eight (8) | rva · num |
| [საუკუნე](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%90%E1%83%A3%E1%83%99%E1%83%A3%E1%83%9C%E1%83%94#Georgian) | century | sauḳune · noun |
| [ცივი](https://en.wiktionary.org/wiki/%E1%83%AA%E1%83%98%E1%83%95%E1%83%98#Georgian) | cold | civi · adj |
| [წონა](https://en.wiktionary.org/wiki/%E1%83%AC%E1%83%9D%E1%83%9C%E1%83%90#Georgian) | weight | c̣ona · noun |
| [ხვალ](https://en.wiktionary.org/wiki/%E1%83%AE%E1%83%95%E1%83%90%E1%83%9A#Georgian) | tomorrow | xval · adv |
| [ბრეგვა](https://en.wiktionary.org/wiki/%E1%83%91%E1%83%A0%E1%83%94%E1%83%92%E1%83%95%E1%83%90#Georgian) | to beat | bregva · noun |
| [თათბირი](https://en.wiktionary.org/wiki/%E1%83%97%E1%83%90%E1%83%97%E1%83%91%E1%83%98%E1%83%A0%E1%83%98#Georgian) | discussion, conference, counsel | tatbiri · noun |
| [კუნძული](https://en.wiktionary.org/wiki/%E1%83%99%E1%83%A3%E1%83%9C%E1%83%AB%E1%83%A3%E1%83%9A%E1%83%98#Georgian) | island | ḳunʒuli · noun |
| [ორმაგად](https://en.wiktionary.org/wiki/%E1%83%9D%E1%83%A0%E1%83%9B%E1%83%90%E1%83%92%E1%83%90%E1%83%93#Georgian) | doubly, double | ormagad · adv |
| [რუსული](https://en.wiktionary.org/wiki/%E1%83%A0%E1%83%A3%E1%83%A1%E1%83%A3%E1%83%9A%E1%83%98#Georgian) | Russian | rusuli · adj |
| [ყავისფერი](https://en.wiktionary.org/wiki/%E1%83%A7%E1%83%90%E1%83%95%E1%83%98%E1%83%A1%E1%83%A4%E1%83%94%E1%83%A0%E1%83%98#Georgian) | brown | q̇avisperi · adj |
| [ჩინური](https://en.wiktionary.org/wiki/%E1%83%A9%E1%83%98%E1%83%9C%E1%83%A3%E1%83%A0%E1%83%98#Georgian) | Chinese | činuri · adj |
| [ვირი](https://en.wiktionary.org/wiki/%E1%83%95%E1%83%98%E1%83%A0%E1%83%98#Georgian) | donkey, ass | viri · noun |
| [ინდივიდი](https://en.wiktionary.org/wiki/%E1%83%98%E1%83%9C%E1%83%93%E1%83%98%E1%83%95%E1%83%98%E1%83%93%E1%83%98#Georgian) | individual | individi · noun |
| [ლაშქრობა](https://en.wiktionary.org/wiki/%E1%83%9A%E1%83%90%E1%83%A8%E1%83%A5%E1%83%A0%E1%83%9D%E1%83%91%E1%83%90#Georgian) | campaign | laškroba · noun |
| [მესიჯი](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%94%E1%83%A1%E1%83%98%E1%83%AF%E1%83%98#Georgian) | message | mesiǯi · noun |
| [მთლიანად](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%97%E1%83%9A%E1%83%98%E1%83%90%E1%83%9C%E1%83%90%E1%83%93#Georgian) | bodily, completely, totally | mtlianad · adv |
| [ნაყინი](https://en.wiktionary.org/wiki/%E1%83%9C%E1%83%90%E1%83%A7%E1%83%98%E1%83%9C%E1%83%98#Georgian) | ice cream | naq̇ini · noun |
| [ყინული](https://en.wiktionary.org/wiki/%E1%83%A7%E1%83%98%E1%83%9C%E1%83%A3%E1%83%9A%E1%83%98#Georgian) | ice | q̇inuli · noun |
| [წერილი](https://en.wiktionary.org/wiki/%E1%83%AC%E1%83%94%E1%83%A0%E1%83%98%E1%83%9A%E1%83%98#Georgian) | letter (message) | c̣erili · noun |
| [ჯვარი](https://en.wiktionary.org/wiki/%E1%83%AF%E1%83%95%E1%83%90%E1%83%A0%E1%83%98#Georgian) | cross | ǯvari · noun |
| [ჯვარისებრი](https://en.wiktionary.org/wiki/%E1%83%AF%E1%83%95%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%E1%83%94%E1%83%91%E1%83%A0%E1%83%98#Georgian) | cross-shaped | ǯvarisebri · adj |
| [კეთილი იყოს თქვენი მობრძანება](https://en.wiktionary.org/wiki/%E1%83%99%E1%83%94%E1%83%97%E1%83%98%E1%83%9A%E1%83%98%20%E1%83%98%E1%83%A7%E1%83%9D%E1%83%A1%20%E1%83%97%E1%83%A5%E1%83%95%E1%83%94%E1%83%9C%E1%83%98%20%E1%83%9B%E1%83%9D%E1%83%91%E1%83%A0%E1%83%AB%E1%83%90%E1%83%9C%E1%83%94%E1%83%91%E1%83%90#Georgian) | welcome | ḳetili iq̇os tkveni mobrʒaneba · phrase |
| [პატიოსნად](https://en.wiktionary.org/wiki/%E1%83%9E%E1%83%90%E1%83%A2%E1%83%98%E1%83%9D%E1%83%A1%E1%83%9C%E1%83%90%E1%83%93#Georgian) | fair, fairly, honestly | ṗaṭiosnad · adv |
| [წვეთი](https://en.wiktionary.org/wiki/%E1%83%AC%E1%83%95%E1%83%94%E1%83%97%E1%83%98#Georgian) | drop, droplet | c̣veti · noun |
| [აბსოლუტურად](https://en.wiktionary.org/wiki/%E1%83%90%E1%83%91%E1%83%A1%E1%83%9D%E1%83%9A%E1%83%A3%E1%83%A2%E1%83%A3%E1%83%A0%E1%83%90%E1%83%93#Georgian) | absolutely, profoundly, sheer, starkly | absoluṭurad · adv |
| [არსებითი](https://en.wiktionary.org/wiki/%E1%83%90%E1%83%A0%E1%83%A1%E1%83%94%E1%83%91%E1%83%98%E1%83%97%E1%83%98#Georgian) | essential, material, significant | arsebiti · adj |
| [მიღმა](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%98%E1%83%A6%E1%83%9B%E1%83%90#Georgian) | beyond | miɣma · adv |
| [სწრაფი](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%AC%E1%83%A0%E1%83%90%E1%83%A4%E1%83%98#Georgian) | quick | sc̣rapi · adj |
| [ჩქარი](https://en.wiktionary.org/wiki/%E1%83%A9%E1%83%A5%E1%83%90%E1%83%A0%E1%83%98#Georgian) | quick | čkari · adj |
| [კომპიუტერი](https://en.wiktionary.org/wiki/%E1%83%99%E1%83%9D%E1%83%9B%E1%83%9E%E1%83%98%E1%83%A3%E1%83%A2%E1%83%94%E1%83%A0%E1%83%98#Georgian) | computer | ḳomṗiuṭeri · noun |
| [გარკვევით](https://en.wiktionary.org/wiki/%E1%83%92%E1%83%90%E1%83%A0%E1%83%99%E1%83%95%E1%83%94%E1%83%95%E1%83%98%E1%83%97#Georgian) | definitely | garḳvevit · adv |
| [მატარებელი](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%90%E1%83%A2%E1%83%90%E1%83%A0%E1%83%94%E1%83%91%E1%83%94%E1%83%9A%E1%83%98#Georgian) | train | maṭarebeli · noun |
| [მძვინვარედ](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%AB%E1%83%95%E1%83%98%E1%83%9C%E1%83%95%E1%83%90%E1%83%A0%E1%83%94%E1%83%93#Georgian) | fiercely, furiously, rampantly, stormily, violently, heavily, heavy, laboriously, ponderously, stertorously, weightily | mʒvinvared · adv |
| [მძიმე](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%AB%E1%83%98%E1%83%9B%E1%83%94#Georgian) | heavy | mʒime · adj |
| [მწვრთნელი](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%AC%E1%83%95%E1%83%A0%E1%83%97%E1%83%9C%E1%83%94%E1%83%9A%E1%83%98#Georgian) | trainer, coach | mc̣vrtneli · noun |
| [პარასკევი](https://en.wiktionary.org/wiki/%E1%83%9E%E1%83%90%E1%83%A0%E1%83%90%E1%83%A1%E1%83%99%E1%83%94%E1%83%95%E1%83%98#Georgian) | Friday | ṗarasḳevi · noun |

</details>

<details><summary>Words 751–800</summary>

![[Resources/Audio/ka/Words 0751-0800.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [ტყვიამფრქვევი](https://en.wiktionary.org/wiki/%E1%83%A2%E1%83%A7%E1%83%95%E1%83%98%E1%83%90%E1%83%9B%E1%83%A4%E1%83%A0%E1%83%A5%E1%83%95%E1%83%94%E1%83%95%E1%83%98#Georgian) | machine gun | ṭq̇viamprkvevi · noun |
| [ქვემეხი](https://en.wiktionary.org/wiki/%E1%83%A5%E1%83%95%E1%83%94%E1%83%9B%E1%83%94%E1%83%AE%E1%83%98#Georgian) | gun, cannon | kvemexi · noun |
| [ცოდნა](https://en.wiktionary.org/wiki/%E1%83%AA%E1%83%9D%E1%83%93%E1%83%9C%E1%83%90#Georgian) | knowledge | codna · noun |
| [ასო](https://en.wiktionary.org/wiki/%E1%83%90%E1%83%A1%E1%83%9D#Georgian) | alphabet letter (symbol) | aso · noun |
| [და](https://en.wiktionary.org/wiki/%E1%83%93%E1%83%90#Georgian) | sister | da · noun |
| [ეჯი](https://en.wiktionary.org/wiki/%E1%83%94%E1%83%AF%E1%83%98#Georgian) | inn, hotel, lodging | eǯi · noun |
| [ზარი](https://en.wiktionary.org/wiki/%E1%83%96%E1%83%90%E1%83%A0%E1%83%98#Georgian) | terror, fear; consternation | zari · noun |
| [მინა](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%98%E1%83%9C%E1%83%90#Georgian) | glass (material) | mina · noun |
| [სასტუმრო](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%90%E1%83%A1%E1%83%A2%E1%83%A3%E1%83%9B%E1%83%A0%E1%83%9D#Georgian) | hotel | sasṭumro · noun |
| [შიში](https://en.wiktionary.org/wiki/%E1%83%A8%E1%83%98%E1%83%A8%E1%83%98#Georgian) | fear, phobia | šiši · noun |
| [აზრი](https://en.wiktionary.org/wiki/%E1%83%90%E1%83%96%E1%83%A0%E1%83%98#Georgian) | opinion | azri · noun |
| [ბრიყვი](https://en.wiktionary.org/wiki/%E1%83%91%E1%83%A0%E1%83%98%E1%83%A7%E1%83%95%E1%83%98#Georgian) | foolish, silly, stupid, ignorant, uncouth | briq̇vi · adj |
| [ბრძოლა](https://en.wiktionary.org/wiki/%E1%83%91%E1%83%A0%E1%83%AB%E1%83%9D%E1%83%9A%E1%83%90#Georgian) | battle | brʒola · noun |
| [დაზღვევა](https://en.wiktionary.org/wiki/%E1%83%93%E1%83%90%E1%83%96%E1%83%A6%E1%83%95%E1%83%94%E1%83%95%E1%83%90#Georgian) | insurance | dazɣveva · noun |
| [იატაკი](https://en.wiktionary.org/wiki/%E1%83%98%E1%83%90%E1%83%A2%E1%83%90%E1%83%99%E1%83%98#Georgian) | floor | iaṭaḳi · noun |
| [სართული](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%90%E1%83%A0%E1%83%97%E1%83%A3%E1%83%9A%E1%83%98#Georgian) | storey, floor | sartuli · noun |
| [ტვინი](https://en.wiktionary.org/wiki/%E1%83%A2%E1%83%95%E1%83%98%E1%83%9C%E1%83%98#Georgian) | brain | ṭvini · noun |
| [შტერი](https://en.wiktionary.org/wiki/%E1%83%A8%E1%83%A2%E1%83%94%E1%83%A0%E1%83%98#Georgian) | stupid | šṭeri · adj |
| [წესი](https://en.wiktionary.org/wiki/%E1%83%AC%E1%83%94%E1%83%A1%E1%83%98#Georgian) | rule (regulation) | c̣esi · noun |
| [გემი](https://en.wiktionary.org/wiki/%E1%83%92%E1%83%94%E1%83%9B%E1%83%98#Georgian) | ship | gemi · noun |
| [დავლური](https://en.wiktionary.org/wiki/%E1%83%93%E1%83%90%E1%83%95%E1%83%9A%E1%83%A3%E1%83%A0%E1%83%98#Georgian) | Georgian dance | davluri · noun |
| [კინტოური](https://en.wiktionary.org/wiki/%E1%83%99%E1%83%98%E1%83%9C%E1%83%A2%E1%83%9D%E1%83%A3%E1%83%A0%E1%83%98#Georgian) | kintouri (a Georgian dance) | ḳinṭouri · noun |
| [ცეკვა](https://en.wiktionary.org/wiki/%E1%83%AA%E1%83%94%E1%83%99%E1%83%95%E1%83%90#Georgian) | dance | ceḳva · noun |
| [გაზაფხული](https://en.wiktionary.org/wiki/%E1%83%92%E1%83%90%E1%83%96%E1%83%90%E1%83%A4%E1%83%AE%E1%83%A3%E1%83%9A%E1%83%98#Georgian) | spring | gazapxuli · noun |
| [ვენტილატორი](https://en.wiktionary.org/wiki/%E1%83%95%E1%83%94%E1%83%9C%E1%83%A2%E1%83%98%E1%83%9A%E1%83%90%E1%83%A2%E1%83%9D%E1%83%A0%E1%83%98#Georgian) | fan (wind electrical device) | venṭilaṭori · noun |
| [ზღვის ნაპირი](https://en.wiktionary.org/wiki/%E1%83%96%E1%83%A6%E1%83%95%E1%83%98%E1%83%A1%20%E1%83%9C%E1%83%90%E1%83%9E%E1%83%98%E1%83%A0%E1%83%98#Georgian) | beach | zɣvis naṗiri · noun |
| [კვირადღე](https://en.wiktionary.org/wiki/%E1%83%99%E1%83%95%E1%83%98%E1%83%A0%E1%83%90%E1%83%93%E1%83%A6%E1%83%94#Georgian) | Sunday | ḳviradɣe · noun |
| [ნათლად](https://en.wiktionary.org/wiki/%E1%83%9C%E1%83%90%E1%83%97%E1%83%9A%E1%83%90%E1%83%93#Georgian) | clearly, distinctly, vividly | natlad · adv |
| [პლაჟი](https://en.wiktionary.org/wiki/%E1%83%9E%E1%83%9A%E1%83%90%E1%83%9F%E1%83%98#Georgian) | beach | ṗlaži · noun |
| [საიდუმლო](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%90%E1%83%98%E1%83%93%E1%83%A3%E1%83%9B%E1%83%9A%E1%83%9D#Georgian) | secret, clandestine | saidumlo · noun |
| [წყარო](https://en.wiktionary.org/wiki/%E1%83%AC%E1%83%A7%E1%83%90%E1%83%A0%E1%83%9D#Georgian) | spring | c̣q̇aro · noun |
| [გუშინ](https://en.wiktionary.org/wiki/%E1%83%92%E1%83%A3%E1%83%A8%E1%83%98%E1%83%9C#Georgian) | yesterday | gušin · adv |
| [კანი](https://en.wiktionary.org/wiki/%E1%83%99%E1%83%90%E1%83%9C%E1%83%98#Georgian) | skin | ḳani · noun |
| [კანფეტი](https://en.wiktionary.org/wiki/%E1%83%99%E1%83%90%E1%83%9C%E1%83%A4%E1%83%94%E1%83%A2%E1%83%98#Georgian) | sweet (sugary confection), bonbon, sweetmeat, candy, lolly | ḳanpeṭi · noun |
| [მისამართი](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%98%E1%83%A1%E1%83%90%E1%83%9B%E1%83%90%E1%83%A0%E1%83%97%E1%83%98#Georgian) | address | misamarti · noun |
| [საშობაო ნაძვის ხე](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%90%E1%83%A8%E1%83%9D%E1%83%91%E1%83%90%E1%83%9D%20%E1%83%9C%E1%83%90%E1%83%AB%E1%83%95%E1%83%98%E1%83%A1%20%E1%83%AE%E1%83%94#Georgian) | Christmas tree | sašobao naʒvis xe · noun |
| [ტკბილი](https://en.wiktionary.org/wiki/%E1%83%A2%E1%83%99%E1%83%91%E1%83%98%E1%83%9A%E1%83%98#Georgian) | sweet | ṭḳbili · adj |
| [ფერი](https://en.wiktionary.org/wiki/%E1%83%A4%E1%83%94%E1%83%A0%E1%83%98#Georgian) | color, hue | peri · noun |
| [შობა](https://en.wiktionary.org/wiki/%E1%83%A8%E1%83%9D%E1%83%91%E1%83%90#Georgian) | Christmas | šoba · noun |
| [ექთანი](https://en.wiktionary.org/wiki/%E1%83%94%E1%83%A5%E1%83%97%E1%83%90%E1%83%9C%E1%83%98#Georgian) | doctor's assistant | ektani · noun |
| [ექიმი](https://en.wiktionary.org/wiki/%E1%83%94%E1%83%A5%E1%83%98%E1%83%9B%E1%83%98#Georgian) | physician, doctor | ekimi · noun |
| [თევზი](https://en.wiktionary.org/wiki/%E1%83%97%E1%83%94%E1%83%95%E1%83%96%E1%83%98#Georgian) | fish | tevzi · noun |
| [შეტყობინება](https://en.wiktionary.org/wiki/%E1%83%A8%E1%83%94%E1%83%A2%E1%83%A7%E1%83%9D%E1%83%91%E1%83%98%E1%83%9C%E1%83%94%E1%83%91%E1%83%90#Georgian) | notice | šeṭq̇obineba · noun |
| [ჰომოსექსუალი](https://en.wiktionary.org/wiki/%E1%83%B0%E1%83%9D%E1%83%9B%E1%83%9D%E1%83%A1%E1%83%94%E1%83%A5%E1%83%A1%E1%83%A3%E1%83%90%E1%83%9A%E1%83%98#Georgian) | homosexual, gay or lesbian | homoseksuali · noun |
| [დანაშაული](https://en.wiktionary.org/wiki/%E1%83%93%E1%83%90%E1%83%9C%E1%83%90%E1%83%A8%E1%83%90%E1%83%A3%E1%83%9A%E1%83%98#Georgian) | crime | današauli · noun |
| [ზამთარი](https://en.wiktionary.org/wiki/%E1%83%96%E1%83%90%E1%83%9B%E1%83%97%E1%83%90%E1%83%A0%E1%83%98#Georgian) | winter | zamtari · noun |
| [კურწი](https://en.wiktionary.org/wiki/%E1%83%99%E1%83%A3%E1%83%A0%E1%83%AC%E1%83%98#Georgian) | stalk (of a plant) | ḳurc̣i · noun |
| [მამალი](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%90%E1%83%9B%E1%83%90%E1%83%9A%E1%83%98#Georgian) | male animal, bird or insect | mamali · noun |
| [მცენარე](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%AA%E1%83%94%E1%83%9C%E1%83%90%E1%83%A0%E1%83%94#Georgian) | plant (organism capable of photosynthesis) | mcenare · noun |
| [ნარდი](https://en.wiktionary.org/wiki/%E1%83%9C%E1%83%90%E1%83%A0%E1%83%93%E1%83%98#Georgian) | nard plant, spikenard, nardin | nardi · noun |

</details>

<details><summary>Words 801–850</summary>

![[Resources/Audio/ka/Words 0801-0850.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [საზამთრო](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%90%E1%83%96%E1%83%90%E1%83%9B%E1%83%97%E1%83%A0%E1%83%9D#Georgian) | winter; wintry | sazamtro · adj |
| [უნდი](https://en.wiktionary.org/wiki/%E1%83%A3%E1%83%9C%E1%83%93%E1%83%98#Georgian) | an unidentified plant | undi · noun |
| [ავად](https://en.wiktionary.org/wiki/%E1%83%90%E1%83%95%E1%83%90%E1%83%93#Georgian) | sick, ill | avad · adv |
| [აღდგომა](https://en.wiktionary.org/wiki/%E1%83%90%E1%83%A6%E1%83%93%E1%83%92%E1%83%9D%E1%83%9B%E1%83%90#Georgian) | Easter (Christian holiday) | aɣdgoma · noun |
| [განზრახ](https://en.wiktionary.org/wiki/%E1%83%92%E1%83%90%E1%83%9C%E1%83%96%E1%83%A0%E1%83%90%E1%83%AE#Georgian) | on purpose, intentionally, deliberately, purposefully, willfully, purposely, advisedly, designedly | ganzrax · adv |
| [დაავადებული](https://en.wiktionary.org/wiki/%E1%83%93%E1%83%90%E1%83%90%E1%83%95%E1%83%90%E1%83%93%E1%83%94%E1%83%91%E1%83%A3%E1%83%9A%E1%83%98#Georgian) | ill, sick | daavadebuli · adj |
| [წმინდა](https://en.wiktionary.org/wiki/%E1%83%AC%E1%83%9B%E1%83%98%E1%83%9C%E1%83%93%E1%83%90#Georgian) | holy | c̣minda · adj |
| [ალალმართლად](https://en.wiktionary.org/wiki/%E1%83%90%E1%83%9A%E1%83%90%E1%83%9A%E1%83%9B%E1%83%90%E1%83%A0%E1%83%97%E1%83%9A%E1%83%90%E1%83%93#Georgian) | truly | alalmartlad · adv |
| [ამიტომ](https://en.wiktionary.org/wiki/%E1%83%90%E1%83%9B%E1%83%98%E1%83%A2%E1%83%9D%E1%83%9B#Georgian) | therefore | amiṭom · adv |
| [დარბაზი](https://en.wiktionary.org/wiki/%E1%83%93%E1%83%90%E1%83%A0%E1%83%91%E1%83%90%E1%83%96%E1%83%98#Georgian) | hall, chamber | darbazi · noun |
| [დარი](https://en.wiktionary.org/wiki/%E1%83%93%E1%83%90%E1%83%A0%E1%83%98#Georgian) | weather | dari · noun |
| [ტერფი](https://en.wiktionary.org/wiki/%E1%83%A2%E1%83%94%E1%83%A0%E1%83%A4%E1%83%98#Georgian) | foot | ṭerpi · noun |
| [შაბათი](https://en.wiktionary.org/wiki/%E1%83%A8%E1%83%90%E1%83%91%E1%83%90%E1%83%97%E1%83%98#Georgian) | Saturday | šabati · noun |
| [ცხრა](https://en.wiktionary.org/wiki/%E1%83%AA%E1%83%AE%E1%83%A0%E1%83%90#Georgian) | nine (9) | cxra · num |
| [ხატა](https://en.wiktionary.org/wiki/%E1%83%AE%E1%83%90%E1%83%A2%E1%83%90#Georgian) | prison cell | xaṭa · noun |
| [ბიბლიოთეკა](https://en.wiktionary.org/wiki/%E1%83%91%E1%83%98%E1%83%91%E1%83%9A%E1%83%98%E1%83%9D%E1%83%97%E1%83%94%E1%83%99%E1%83%90#Georgian) | library | biblioteḳa · noun |
| [დედოფალი](https://en.wiktionary.org/wiki/%E1%83%93%E1%83%94%E1%83%93%E1%83%9D%E1%83%A4%E1%83%90%E1%83%9A%E1%83%98#Georgian) | queen | dedopali · noun |
| [თავისუფლება](https://en.wiktionary.org/wiki/%E1%83%97%E1%83%90%E1%83%95%E1%83%98%E1%83%A1%E1%83%A3%E1%83%A4%E1%83%9A%E1%83%94%E1%83%91%E1%83%90#Georgian) | freedom | tavisupleba · noun |
| [კომპლექსური](https://en.wiktionary.org/wiki/%E1%83%99%E1%83%9D%E1%83%9B%E1%83%9E%E1%83%9A%E1%83%94%E1%83%A5%E1%83%A1%E1%83%A3%E1%83%A0%E1%83%98#Georgian) | complex | ḳomṗleksuri · adj |
| [მდგომი](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%93%E1%83%92%E1%83%9D%E1%83%9B%E1%83%98#Georgian) | standing | mdgomi · adj |
| [მკვლელობა](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%99%E1%83%95%E1%83%9A%E1%83%94%E1%83%9A%E1%83%9D%E1%83%91%E1%83%90#Georgian) | murder | mḳvleloba · noun |
| [საღამო](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%90%E1%83%A6%E1%83%90%E1%83%9B%E1%83%9D#Georgian) | evening | saɣamo · noun |
| [ყავა](https://en.wiktionary.org/wiki/%E1%83%A7%E1%83%90%E1%83%95%E1%83%90#Georgian) | coffee | q̇ava · noun |
| [კაკალი](https://en.wiktionary.org/wiki/%E1%83%99%E1%83%90%E1%83%99%E1%83%90%E1%83%9A%E1%83%98#Georgian) | walnut-tree, Juglans regia | ḳaḳali · noun |
| [ნევროტულად](https://en.wiktionary.org/wiki/%E1%83%9C%E1%83%94%E1%83%95%E1%83%A0%E1%83%9D%E1%83%A2%E1%83%A3%E1%83%9A%E1%83%90%E1%83%93#Georgian) | neurotically, slow, slowly, tardily | nevroṭulad · adv |
| [ნელი](https://en.wiktionary.org/wiki/%E1%83%9C%E1%83%94%E1%83%9A%E1%83%98#Georgian) | slow | neli · adj |
| [პიკაჩუ](https://en.wiktionary.org/wiki/%E1%83%9E%E1%83%98%E1%83%99%E1%83%90%E1%83%A9%E1%83%A3#Georgian) | Pikachu (a Pokémon species) | ṗiḳaču · noun |
| [საუცხოო](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%90%E1%83%A3%E1%83%AA%E1%83%AE%E1%83%9D%E1%83%9D#Georgian) | wonderful, wondrous | saucxoo · adj |
| [სახეობა](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%90%E1%83%AE%E1%83%94%E1%83%9D%E1%83%91%E1%83%90#Georgian) | species, breed | saxeoba · noun |
| [ფუტურო](https://en.wiktionary.org/wiki/%E1%83%A4%E1%83%A3%E1%83%A2%E1%83%A3%E1%83%A0%E1%83%9D#Georgian) | rotten tree | puṭuro · noun |
| [ქერქი](https://en.wiktionary.org/wiki/%E1%83%A5%E1%83%94%E1%83%A0%E1%83%A5%E1%83%98#Georgian) | bark (of a tree) | kerki · noun |
| [ღვია](https://en.wiktionary.org/wiki/%E1%83%A6%E1%83%95%E1%83%98%E1%83%90#Georgian) | juniper tree | ɣvia · noun |
| [ხე](https://en.wiktionary.org/wiki/%E1%83%AE%E1%83%94#Georgian) | tree | xe · noun |
| [ჯიში](https://en.wiktionary.org/wiki/%E1%83%AF%E1%83%98%E1%83%A8%E1%83%98#Georgian) | species, breed | ǯiši · noun |
| [აეროპორტი](https://en.wiktionary.org/wiki/%E1%83%90%E1%83%94%E1%83%A0%E1%83%9D%E1%83%9E%E1%83%9D%E1%83%A0%E1%83%A2%E1%83%98#Georgian) | airport | aeroṗorṭi · noun |
| [დარდი](https://en.wiktionary.org/wiki/%E1%83%93%E1%83%90%E1%83%A0%E1%83%93%E1%83%98#Georgian) | sorrow, worry, grief, concern | dardi · noun |
| [მგოსანი](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%92%E1%83%9D%E1%83%A1%E1%83%90%E1%83%9C%E1%83%98#Georgian) | a famous poet | mgosani · noun |
| [ოსტრი](https://en.wiktionary.org/wiki/%E1%83%9D%E1%83%A1%E1%83%A2%E1%83%A0%E1%83%98#Georgian) | a traditional Georgian beef stew | osṭri · noun |
| [ფსკერი](https://en.wiktionary.org/wiki/%E1%83%A4%E1%83%A1%E1%83%99%E1%83%94%E1%83%A0%E1%83%98#Georgian) | bottom | psḳeri · noun |
| [ქარი](https://en.wiktionary.org/wiki/%E1%83%A5%E1%83%90%E1%83%A0%E1%83%98#Georgian) | wind | kari · noun |
| [ძრავა](https://en.wiktionary.org/wiki/%E1%83%AB%E1%83%A0%E1%83%90%E1%83%95%E1%83%90#Georgian) | engine | ʒrava · noun |
| [ხაში](https://en.wiktionary.org/wiki/%E1%83%AE%E1%83%90%E1%83%A8%E1%83%98#Georgian) | khash (a traditional dish in Caucasus) | xaši · noun |
| [ავტობუსი](https://en.wiktionary.org/wiki/%E1%83%90%E1%83%95%E1%83%A2%E1%83%9D%E1%83%91%E1%83%A3%E1%83%A1%E1%83%98#Georgian) | bus | avṭobusi · noun |
| [განძი](https://en.wiktionary.org/wiki/%E1%83%92%E1%83%90%E1%83%9C%E1%83%AB%E1%83%98#Georgian) | treasure (mostly buried) | ganʒi · noun |
| [ზედაპირი](https://en.wiktionary.org/wiki/%E1%83%96%E1%83%94%E1%83%93%E1%83%90%E1%83%9E%E1%83%98%E1%83%A0%E1%83%98#Georgian) | surface | zedaṗiri · noun |
| [ტბა](https://en.wiktionary.org/wiki/%E1%83%A2%E1%83%91%E1%83%90#Georgian) | lake | ṭba · noun |
| [ტროლეიბუსი](https://en.wiktionary.org/wiki/%E1%83%A2%E1%83%A0%E1%83%9D%E1%83%9A%E1%83%94%E1%83%98%E1%83%91%E1%83%A3%E1%83%A1%E1%83%98#Georgian) | trolley bus | ṭroleibusi · noun |
| [ჭკვიანი](https://en.wiktionary.org/wiki/%E1%83%AD%E1%83%99%E1%83%95%E1%83%98%E1%83%90%E1%83%9C%E1%83%98#Georgian) | smart, gifted | č̣ḳviani · adj |
| [გორა](https://en.wiktionary.org/wiki/%E1%83%92%E1%83%9D%E1%83%A0%E1%83%90#Georgian) | hill | gora · noun |
| [ვარდი](https://en.wiktionary.org/wiki/%E1%83%95%E1%83%90%E1%83%A0%E1%83%93%E1%83%98#Georgian) | rose | vardi · noun |

</details>

<details><summary>Words 851–900</summary>

![[Resources/Audio/ka/Words 0851-0900.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [მთა](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%97%E1%83%90#Georgian) | mountain, hill | mta · noun |
| [რკინა](https://en.wiktionary.org/wiki/%E1%83%A0%E1%83%99%E1%83%98%E1%83%9C%E1%83%90#Georgian) | iron (metal) | rḳina · noun |
| [სერი](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%94%E1%83%A0%E1%83%98#Georgian) | hill | seri · noun |
| [სექსუალური ორიენტაცია](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%94%E1%83%A5%E1%83%A1%E1%83%A3%E1%83%90%E1%83%9A%E1%83%A3%E1%83%A0%E1%83%98%20%E1%83%9D%E1%83%A0%E1%83%98%E1%83%94%E1%83%9C%E1%83%A2%E1%83%90%E1%83%AA%E1%83%98%E1%83%90#Georgian) | sexual orientation | seksualuri orienṭacia · noun |
| [ბეჭედი](https://en.wiktionary.org/wiki/%E1%83%91%E1%83%94%E1%83%AD%E1%83%94%E1%83%93%E1%83%98#Georgian) | ring | beč̣edi · noun |
| [ვერცხლი](https://en.wiktionary.org/wiki/%E1%83%95%E1%83%94%E1%83%A0%E1%83%AA%E1%83%AE%E1%83%9A%E1%83%98#Georgian) | silver (chemical element) | vercxli · noun |
| [ნადირი](https://en.wiktionary.org/wiki/%E1%83%9C%E1%83%90%E1%83%93%E1%83%98%E1%83%A0%E1%83%98#Georgian) | wild animal | nadiri · noun |
| [ცხოველი](https://en.wiktionary.org/wiki/%E1%83%AA%E1%83%AE%E1%83%9D%E1%83%95%E1%83%94%E1%83%9A%E1%83%98#Georgian) | beastly animal | cxoveli · noun |
| [ვარაუდით](https://en.wiktionary.org/wiki/%E1%83%95%E1%83%90%E1%83%A0%E1%83%90%E1%83%A3%E1%83%93%E1%83%98%E1%83%97#Georgian) | supposedly, wild | varaudit · adv |
| [კატუნი](https://en.wiktionary.org/wiki/%E1%83%99%E1%83%90%E1%83%A2%E1%83%A3%E1%83%9C%E1%83%98#Georgian) | wild cat | ḳaṭuni · noun |
| [მარწყვი](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%90%E1%83%A0%E1%83%AC%E1%83%A7%E1%83%95%E1%83%98#Georgian) | wild strawberry | marc̣q̇vi · noun |
| [ნიშნის მოგებით](https://en.wiktionary.org/wiki/%E1%83%9C%E1%83%98%E1%83%A8%E1%83%9C%E1%83%98%E1%83%A1%20%E1%83%9B%E1%83%9D%E1%83%92%E1%83%94%E1%83%91%E1%83%98%E1%83%97#Georgian) | in a winner's manner, mockingly | nišnis mogebit · adv |
| [ორშაბათი](https://en.wiktionary.org/wiki/%E1%83%9D%E1%83%A0%E1%83%A8%E1%83%90%E1%83%91%E1%83%90%E1%83%97%E1%83%98#Georgian) | Monday | oršabati · noun |
| [ფანჯარა](https://en.wiktionary.org/wiki/%E1%83%A4%E1%83%90%E1%83%9C%E1%83%AF%E1%83%90%E1%83%A0%E1%83%90#Georgian) | window | panǯara · noun |
| [ქვა](https://en.wiktionary.org/wiki/%E1%83%A5%E1%83%95%E1%83%90#Georgian) | stone | kva · noun |
| [წიპწა](https://en.wiktionary.org/wiki/%E1%83%AC%E1%83%98%E1%83%9E%E1%83%AC%E1%83%90#Georgian) | stone of a grape | c̣iṗc̣a · noun |
| [ჯანმრთელი](https://en.wiktionary.org/wiki/%E1%83%AF%E1%83%90%E1%83%9C%E1%83%9B%E1%83%A0%E1%83%97%E1%83%94%E1%83%9A%E1%83%98#Georgian) | healthy | ǯanmrteli · adj |
| [აბგა](https://en.wiktionary.org/wiki/%E1%83%90%E1%83%91%E1%83%92%E1%83%90#Georgian) | shoulder bag | abga · noun |
| [ბანაკი](https://en.wiktionary.org/wiki/%E1%83%91%E1%83%90%E1%83%9C%E1%83%90%E1%83%99%E1%83%98#Georgian) | camp, encampment | banaḳi · noun |
| [გასაჭირი](https://en.wiktionary.org/wiki/%E1%83%92%E1%83%90%E1%83%A1%E1%83%90%E1%83%AD%E1%83%98%E1%83%A0%E1%83%98#Georgian) | difficulties, trouble | gasač̣iri · noun |
| [გნდე](https://en.wiktionary.org/wiki/%E1%83%92%E1%83%9C%E1%83%93%E1%83%94#Georgian) | handle | gnde · noun |
| [დასტურ](https://en.wiktionary.org/wiki/%E1%83%93%E1%83%90%E1%83%A1%E1%83%A2%E1%83%A3%E1%83%A0#Georgian) | indeed | dasṭur · adv |
| [პარკი](https://en.wiktionary.org/wiki/%E1%83%9E%E1%83%90%E1%83%A0%E1%83%99%E1%83%98#Georgian) | plastic bag | ṗarḳi · noun |
| [სული](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%A3%E1%83%9A%E1%83%98#Georgian) | spirit, ghost | suli · noun |
| [ფათერაკი](https://en.wiktionary.org/wiki/%E1%83%A4%E1%83%90%E1%83%97%E1%83%94%E1%83%A0%E1%83%90%E1%83%99%E1%83%98#Georgian) | misfortune, trouble | pateraḳi · noun |
| [დახვრეტა](https://en.wiktionary.org/wiki/%E1%83%93%E1%83%90%E1%83%AE%E1%83%95%E1%83%A0%E1%83%94%E1%83%A2%E1%83%90#Georgian) | execution by shooting | daxvreṭa · noun |
| [კატა](https://en.wiktionary.org/wiki/%E1%83%99%E1%83%90%E1%83%A2%E1%83%90#Georgian) | cat | ḳaṭa · noun |
| [მოკეტე](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%9D%E1%83%99%E1%83%94%E1%83%A2%E1%83%94#Georgian) | shut up! (imperative) | moḳeṭe · verb |
| [ტყე](https://en.wiktionary.org/wiki/%E1%83%A2%E1%83%A7%E1%83%94#Georgian) | forest, wood | ṭq̇e · noun |
| [ბაღი](https://en.wiktionary.org/wiki/%E1%83%91%E1%83%90%E1%83%A6%E1%83%98#Georgian) | garden | baɣi · noun |
| [გენაცვალე](https://en.wiktionary.org/wiki/%E1%83%92%E1%83%94%E1%83%9C%E1%83%90%E1%83%AA%E1%83%95%E1%83%90%E1%83%9A%E1%83%94#Georgian) | darling, dear (expression of endearment) | genacvale · intj |
| [შემოგევლე](https://en.wiktionary.org/wiki/%E1%83%A8%E1%83%94%E1%83%9B%E1%83%9D%E1%83%92%E1%83%94%E1%83%95%E1%83%9A%E1%83%94#Georgian) | darling, dear (expression of endearment) | šemogevle · intj |
| [ჩემო კარგო](https://en.wiktionary.org/wiki/%E1%83%A9%E1%83%94%E1%83%9B%E1%83%9D%20%E1%83%99%E1%83%90%E1%83%A0%E1%83%92%E1%83%9D#Georgian) | darling, dear (expression of endearment) | čemo ḳargo · phrase |
| [ხიდი](https://en.wiktionary.org/wiki/%E1%83%AE%E1%83%98%E1%83%93%E1%83%98#Georgian) | bridge | xidi · noun |
| [ვაშლი](https://en.wiktionary.org/wiki/%E1%83%95%E1%83%90%E1%83%A8%E1%83%9A%E1%83%98#Georgian) | apple (fruit) | vašli · noun |
| [თხოვნა](https://en.wiktionary.org/wiki/%E1%83%97%E1%83%AE%E1%83%9D%E1%83%95%E1%83%9C%E1%83%90#Georgian) | request, petition, entreaty, plea, favor | txovna · noun |
| [იცოცხლე](https://en.wiktionary.org/wiki/%E1%83%98%E1%83%AA%E1%83%9D%E1%83%AA%E1%83%AE%E1%83%9A%E1%83%94#Georgian) | be alive | icocxle · verb |
| [ცხენი](https://en.wiktionary.org/wiki/%E1%83%AA%E1%83%AE%E1%83%94%E1%83%9C%E1%83%98#Georgian) | horse | cxeni · noun |
| [დამნაშავე](https://en.wiktionary.org/wiki/%E1%83%93%E1%83%90%E1%83%9B%E1%83%9C%E1%83%90%E1%83%A8%E1%83%90%E1%83%95%E1%83%94#Georgian) | perpetrator, criminal | damnašave · noun |
| [ოდნავ](https://en.wiktionary.org/wiki/%E1%83%9D%E1%83%93%E1%83%9C%E1%83%90%E1%83%95#Georgian) | slightly | odnav · adv |
| [ტოლმა](https://en.wiktionary.org/wiki/%E1%83%A2%E1%83%9D%E1%83%9A%E1%83%9B%E1%83%90#Georgian) | dolma, cabbage roll | ṭolma · noun |
| [ქლიბი](https://en.wiktionary.org/wiki/%E1%83%A5%E1%83%9A%E1%83%98%E1%83%91%E1%83%98#Georgian) | file | klibi · noun |
| [წირანი](https://en.wiktionary.org/wiki/%E1%83%AC%E1%83%98%E1%83%A0%E1%83%90%E1%83%9C%E1%83%98#Georgian) | a variety of apricot | c̣irani · noun |
| [კიდე](https://en.wiktionary.org/wiki/%E1%83%99%E1%83%98%E1%83%93%E1%83%94#Georgian) | edge | ḳide · noun |
| [ნუნუა](https://en.wiktionary.org/wiki/%E1%83%9C%E1%83%A3%E1%83%9C%E1%83%A3%E1%83%90#Georgian) | wine | nunua · noun |
| [რელიგია](https://en.wiktionary.org/wiki/%E1%83%A0%E1%83%94%E1%83%9A%E1%83%98%E1%83%92%E1%83%98%E1%83%90#Georgian) | religion | religia · noun |
| [სადმე](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%90%E1%83%93%E1%83%9B%E1%83%94#Georgian) | somewhere, someplace | sadme · adv |
| [სადღაც](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%90%E1%83%93%E1%83%A6%E1%83%90%E1%83%AA#Georgian) | somewhere | sadɣac · adv |
| [უთო](https://en.wiktionary.org/wiki/%E1%83%A3%E1%83%97%E1%83%9D#Georgian) | clothes iron, iron | uto · noun |
| [ღვინო](https://en.wiktionary.org/wiki/%E1%83%A6%E1%83%95%E1%83%98%E1%83%9C%E1%83%9D#Georgian) | wine | ɣvino · noun |

</details>

<details><summary>Words 901–950</summary>

![[Resources/Audio/ka/Words 0901-0950.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [უბე](https://en.wiktionary.org/wiki/%E1%83%A3%E1%83%91%E1%83%94#Georgian) | bay, bight | ube · noun |
| [წამალი](https://en.wiktionary.org/wiki/%E1%83%AC%E1%83%90%E1%83%9B%E1%83%90%E1%83%9A%E1%83%98#Georgian) | medicine | c̣amali · noun |
| [ბარი](https://en.wiktionary.org/wiki/%E1%83%91%E1%83%90%E1%83%A0%E1%83%98#Georgian) | valley | bari · noun |
| [ბრტყელი](https://en.wiktionary.org/wiki/%E1%83%91%E1%83%A0%E1%83%A2%E1%83%A7%E1%83%94%E1%83%9A%E1%83%98#Georgian) | flat | brṭq̇eli · adj |
| [ბრტყლად](https://en.wiktionary.org/wiki/%E1%83%91%E1%83%A0%E1%83%A2%E1%83%A7%E1%83%9A%E1%83%90%E1%83%93#Georgian) | flat | brṭq̇lad · adv |
| [გაგიმარჯოს](https://en.wiktionary.org/wiki/%E1%83%92%E1%83%90%E1%83%92%E1%83%98%E1%83%9B%E1%83%90%E1%83%A0%E1%83%AF%E1%83%9D%E1%83%A1#Georgian) | hello | gagimarǯos · intj |
| [ერდო](https://en.wiktionary.org/wiki/%E1%83%94%E1%83%A0%E1%83%93%E1%83%9D#Georgian) | flat roof | erdo · noun |
| [ზეცა](https://en.wiktionary.org/wiki/%E1%83%96%E1%83%94%E1%83%AA%E1%83%90#Georgian) | sky | zeca · noun |
| [სალამი](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%90%E1%83%9A%E1%83%90%E1%83%9B%E1%83%98#Georgian) | hello | salami · intj |
| [ცა](https://en.wiktionary.org/wiki/%E1%83%AA%E1%83%90#Georgian) | sky, firmament | ca · noun |
| [ხეობა](https://en.wiktionary.org/wiki/%E1%83%AE%E1%83%94%E1%83%9D%E1%83%91%E1%83%90#Georgian) | valley | xeoba · noun |
| [ასი](https://en.wiktionary.org/wiki/%E1%83%90%E1%83%A1%E1%83%98#Georgian) | hundred (100) | asi · num |
| [ბაჟი](https://en.wiktionary.org/wiki/%E1%83%91%E1%83%90%E1%83%9F%E1%83%98#Georgian) | toll, tariff, duty | baži · noun |
| [ბრუნვა](https://en.wiktionary.org/wiki/%E1%83%91%E1%83%A0%E1%83%A3%E1%83%9C%E1%83%95%E1%83%90#Georgian) | rotation, revolution, turning, spinning | brunva · noun |
| [დათვი](https://en.wiktionary.org/wiki/%E1%83%93%E1%83%90%E1%83%97%E1%83%95%E1%83%98#Georgian) | bear | datvi · noun |
| [დისკუსია](https://en.wiktionary.org/wiki/%E1%83%93%E1%83%98%E1%83%A1%E1%83%99%E1%83%A3%E1%83%A1%E1%83%98%E1%83%90#Georgian) | discussion | disḳusia · noun |
| [თბილი](https://en.wiktionary.org/wiki/%E1%83%97%E1%83%91%E1%83%98%E1%83%9A%E1%83%98#Georgian) | warm | tbili · adj |
| [ნავი](https://en.wiktionary.org/wiki/%E1%83%9C%E1%83%90%E1%83%95%E1%83%98#Georgian) | boat | navi · noun |
| [პირიქით](https://en.wiktionary.org/wiki/%E1%83%9E%E1%83%98%E1%83%A0%E1%83%98%E1%83%A5%E1%83%98%E1%83%97#Georgian) | contrariwise, vice versa | ṗirikit · adv |
| [პირობა](https://en.wiktionary.org/wiki/%E1%83%9E%E1%83%98%E1%83%A0%E1%83%9D%E1%83%91%E1%83%90#Georgian) | promise | ṗiroba · noun |
| [ტევადობა](https://en.wiktionary.org/wiki/%E1%83%A2%E1%83%94%E1%83%95%E1%83%90%E1%83%93%E1%83%9D%E1%83%91%E1%83%90#Georgian) | capacity | ṭevadoba · noun |
| [ფოლადი](https://en.wiktionary.org/wiki/%E1%83%A4%E1%83%9D%E1%83%9A%E1%83%90%E1%83%93%E1%83%98#Georgian) | steel | poladi · noun |
| [ყანწი](https://en.wiktionary.org/wiki/%E1%83%A7%E1%83%90%E1%83%9C%E1%83%AC%E1%83%98#Georgian) | drinking horn | q̇anc̣i · noun |
| [წვიმა](https://en.wiktionary.org/wiki/%E1%83%AC%E1%83%95%E1%83%98%E1%83%9B%E1%83%90#Georgian) | rain | c̣vima · noun |
| [ჰავა](https://en.wiktionary.org/wiki/%E1%83%B0%E1%83%90%E1%83%95%E1%83%90#Georgian) | climate | hava · noun |
| [დამტკიცება](https://en.wiktionary.org/wiki/%E1%83%93%E1%83%90%E1%83%9B%E1%83%A2%E1%83%99%E1%83%98%E1%83%AA%E1%83%94%E1%83%91%E1%83%90#Georgian) | proof | damṭḳiceba · noun |
| [მთვარე](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%97%E1%83%95%E1%83%90%E1%83%A0%E1%83%94#Georgian) | moon | mtvare · noun |
| [მიჯნა](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%98%E1%83%AF%E1%83%9C%E1%83%90#Georgian) | border, boundary | miǯna · noun |
| [ოკეანე](https://en.wiktionary.org/wiki/%E1%83%9D%E1%83%99%E1%83%94%E1%83%90%E1%83%9C%E1%83%94#Georgian) | ocean | oḳeane · noun |
| [ტევრი](https://en.wiktionary.org/wiki/%E1%83%A2%E1%83%94%E1%83%95%E1%83%A0%E1%83%98#Georgian) | thicket, dense, impenetrable forest | ṭevri · noun |
| [ყლეზე მკიდია](https://en.wiktionary.org/wiki/%E1%83%A7%E1%83%9A%E1%83%94%E1%83%96%E1%83%94%20%E1%83%9B%E1%83%99%E1%83%98%E1%83%93%E1%83%98%E1%83%90#Georgian) | It hangs on my dick | q̇leze mḳidia · verb |
| [ბელარუსი](https://en.wiktionary.org/wiki/%E1%83%91%E1%83%94%E1%83%9A%E1%83%90%E1%83%A0%E1%83%A3%E1%83%A1%E1%83%98#Georgian) | Belarusian (native or inhabitant of Belarus) | belarusi · noun |
| [მომხმარებელი](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%9D%E1%83%9B%E1%83%AE%E1%83%9B%E1%83%90%E1%83%A0%E1%83%94%E1%83%91%E1%83%94%E1%83%9A%E1%83%98#Georgian) | user | momxmarebeli · noun |
| [მონღოლი](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%9D%E1%83%9C%E1%83%A6%E1%83%9D%E1%83%9A%E1%83%98#Georgian) | Mongolian (native or inhabitant of Mongolia) | monɣoli · noun |
| [მოულოდნელად](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%9D%E1%83%A3%E1%83%9A%E1%83%9D%E1%83%93%E1%83%9C%E1%83%94%E1%83%9A%E1%83%90%E1%83%93#Georgian) | plop, plump, suddenly, surprisingly, unexpectedly | moulodnelad · adv |
| [მწერალი](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%AC%E1%83%94%E1%83%A0%E1%83%90%E1%83%9A%E1%83%98#Georgian) | writer | mc̣erali · noun |
| [ორიგინალურად](https://en.wiktionary.org/wiki/%E1%83%9D%E1%83%A0%E1%83%98%E1%83%92%E1%83%98%E1%83%9C%E1%83%90%E1%83%9A%E1%83%A3%E1%83%A0%E1%83%90%E1%83%93#Georgian) | originally, fortnightly | originalurad · adv |
| [ოჯახური](https://en.wiktionary.org/wiki/%E1%83%9D%E1%83%AF%E1%83%90%E1%83%AE%E1%83%A3%E1%83%A0%E1%83%98#Georgian) | domestic | oǯaxuri · adj |
| [პირველდაწყებითად](https://en.wiktionary.org/wiki/%E1%83%9E%E1%83%98%E1%83%A0%E1%83%95%E1%83%94%E1%83%9A%E1%83%93%E1%83%90%E1%83%AC%E1%83%A7%E1%83%94%E1%83%91%E1%83%98%E1%83%97%E1%83%90%E1%83%93#Georgian) | originally | ṗirveldac̣q̇ebitad · adv |
| [რწმუნებული](https://en.wiktionary.org/wiki/%E1%83%A0%E1%83%AC%E1%83%9B%E1%83%A3%E1%83%9C%E1%83%94%E1%83%91%E1%83%A3%E1%83%9A%E1%83%98#Georgian) | attorney | rc̣munebuli · noun |
| [სკამი](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%99%E1%83%90%E1%83%9B%E1%83%98#Georgian) | chair | sḳami · noun |
| [ყვითელი](https://en.wiktionary.org/wiki/%E1%83%A7%E1%83%95%E1%83%98%E1%83%97%E1%83%94%E1%83%9A%E1%83%98#Georgian) | yellow | q̇viteli · adj |
| [შესახედაობა](https://en.wiktionary.org/wiki/%E1%83%A8%E1%83%94%E1%83%A1%E1%83%90%E1%83%AE%E1%83%94%E1%83%93%E1%83%90%E1%83%9D%E1%83%91%E1%83%90#Georgian) | appearance | šesaxedaoba · noun |
| [გმირი](https://en.wiktionary.org/wiki/%E1%83%92%E1%83%9B%E1%83%98%E1%83%A0%E1%83%98#Georgian) | hero | gmiri · noun |
| [ვარჯიში](https://en.wiktionary.org/wiki/%E1%83%95%E1%83%90%E1%83%A0%E1%83%AF%E1%83%98%E1%83%A8%E1%83%98#Georgian) | exercise | varǯiši · noun |
| [ნაზი](https://en.wiktionary.org/wiki/%E1%83%9C%E1%83%90%E1%83%96%E1%83%98#Georgian) | delicate, soft, tender | nazi · adj |
| [რესტორანი](https://en.wiktionary.org/wiki/%E1%83%A0%E1%83%94%E1%83%A1%E1%83%A2%E1%83%9D%E1%83%A0%E1%83%90%E1%83%9C%E1%83%98#Georgian) | restaurant | resṭorani · noun |
| [ღადაობა](https://en.wiktionary.org/wiki/%E1%83%A6%E1%83%90%E1%83%93%E1%83%90%E1%83%9D%E1%83%91%E1%83%90#Georgian) | joke | ɣadaoba · noun |
| [შაქარი](https://en.wiktionary.org/wiki/%E1%83%A8%E1%83%90%E1%83%A5%E1%83%90%E1%83%A0%E1%83%98#Georgian) | sugar | šakari · noun |
| [ხუმრობა](https://en.wiktionary.org/wiki/%E1%83%AE%E1%83%A3%E1%83%9B%E1%83%A0%E1%83%9D%E1%83%91%E1%83%90#Georgian) | joke | xumroba · noun |

</details>

<details><summary>Words 951–1000</summary>

![[Resources/Audio/ka/Words 0951-1000.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [ადვოკატი](https://en.wiktionary.org/wiki/%E1%83%90%E1%83%93%E1%83%95%E1%83%9D%E1%83%99%E1%83%90%E1%83%A2%E1%83%98#Georgian) | lawyer | advoḳaṭi · noun |
| [ბოლი](https://en.wiktionary.org/wiki/%E1%83%91%E1%83%9D%E1%83%9A%E1%83%98#Georgian) | smoke | boli · noun |
| [ბრალი](https://en.wiktionary.org/wiki/%E1%83%91%E1%83%A0%E1%83%90%E1%83%9A%E1%83%98#Georgian) | fault (mistake or error) | brali · noun |
| [გზად](https://en.wiktionary.org/wiki/%E1%83%92%E1%83%96%E1%83%90%E1%83%93#Georgian) | en route | gzad · adv |
| [ერა](https://en.wiktionary.org/wiki/%E1%83%94%E1%83%A0%E1%83%90#Georgian) | epoch, era | era · noun |
| [კვამლი](https://en.wiktionary.org/wiki/%E1%83%99%E1%83%95%E1%83%90%E1%83%9B%E1%83%9A%E1%83%98#Georgian) | smoke | ḳvamli · noun |
| [ლაზერი](https://en.wiktionary.org/wiki/%E1%83%9A%E1%83%90%E1%83%96%E1%83%94%E1%83%A0%E1%83%98#Georgian) | laser (device) | lazeri · noun |
| [მუსლიმი](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%A3%E1%83%A1%E1%83%9A%E1%83%98%E1%83%9B%E1%83%98#Georgian) | Muslim | muslimi · noun |
| [მუსულმანი](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%A3%E1%83%A1%E1%83%A3%E1%83%9A%E1%83%9B%E1%83%90%E1%83%9C%E1%83%98#Georgian) | Muslim | musulmani · noun |
| [გრიგალი](https://en.wiktionary.org/wiki/%E1%83%92%E1%83%A0%E1%83%98%E1%83%92%E1%83%90%E1%83%9A%E1%83%98#Georgian) | storm | grigali · noun |
| [თოვლი](https://en.wiktionary.org/wiki/%E1%83%97%E1%83%9D%E1%83%95%E1%83%9A%E1%83%98#Georgian) | snow | tovli · noun |
| [მელა](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%94%E1%83%9A%E1%83%90#Georgian) | fox | mela · noun |
| [რძე](https://en.wiktionary.org/wiki/%E1%83%A0%E1%83%AB%E1%83%94#Georgian) | milk | rʒe · noun |
| [სორო](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%9D%E1%83%A0%E1%83%9D#Georgian) | lair, burrow, hole | soro · noun |
| [ფეხი](https://en.wiktionary.org/wiki/%E1%83%A4%E1%83%94%E1%83%AE%E1%83%98#Georgian) | leg | pexi · noun |
| [ქარიშხალი](https://en.wiktionary.org/wiki/%E1%83%A5%E1%83%90%E1%83%A0%E1%83%98%E1%83%A8%E1%83%AE%E1%83%90%E1%83%9A%E1%83%98#Georgian) | storm | karišxali · noun |
| [შეკვრა](https://en.wiktionary.org/wiki/%E1%83%A8%E1%83%94%E1%83%99%E1%83%95%E1%83%A0%E1%83%90#Georgian) | bundle, pack, package | šeḳvra · noun |
| [ბინა](https://en.wiktionary.org/wiki/%E1%83%91%E1%83%98%E1%83%9C%E1%83%90#Georgian) | apartment | bina · noun |
| [ოცი](https://en.wiktionary.org/wiki/%E1%83%9D%E1%83%AA%E1%83%98#Georgian) | twenty (20) | oci · num |
| [სამზარეულო](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%90%E1%83%9B%E1%83%96%E1%83%90%E1%83%A0%E1%83%94%E1%83%A3%E1%83%9A%E1%83%9D#Georgian) | kitchen | samzareulo · noun |
| [საწყაო](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%90%E1%83%AC%E1%83%A7%E1%83%90%E1%83%9D#Georgian) | measure | sac̣q̇ao · noun |
| [ტოლი](https://en.wiktionary.org/wiki/%E1%83%A2%E1%83%9D%E1%83%9A%E1%83%98#Georgian) | equal | ṭoli · adj |
| [ჩაფი](https://en.wiktionary.org/wiki/%E1%83%A9%E1%83%90%E1%83%A4%E1%83%98#Georgian) | a measure of liquid | čapi · noun |
| [ჯაჭვი](https://en.wiktionary.org/wiki/%E1%83%AF%E1%83%90%E1%83%AD%E1%83%95%E1%83%98#Georgian) | chain | ǯač̣vi · noun |
| [ათასი](https://en.wiktionary.org/wiki/%E1%83%90%E1%83%97%E1%83%90%E1%83%A1%E1%83%98#Georgian) | thousand | atasi · num |
| [დაახლოებით](https://en.wiktionary.org/wiki/%E1%83%93%E1%83%90%E1%83%90%E1%83%AE%E1%83%9A%E1%83%9D%E1%83%94%E1%83%91%E1%83%98%E1%83%97#Georgian) | approximately, thereabout, thereabouts | daaxloebit · adv |
| [თვითმფრინავი](https://en.wiktionary.org/wiki/%E1%83%97%E1%83%95%E1%83%98%E1%83%97%E1%83%9B%E1%83%A4%E1%83%A0%E1%83%98%E1%83%9C%E1%83%90%E1%83%95%E1%83%98#Georgian) | airplane, aircraft | tvitmprinavi · noun |
| [მიახლოებით](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%98%E1%83%90%E1%83%AE%E1%83%9A%E1%83%9D%E1%83%94%E1%83%91%E1%83%98%E1%83%97#Georgian) | approximately | miaxloebit · adv |
| [სატვირთო მანქანა](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%90%E1%83%A2%E1%83%95%E1%83%98%E1%83%A0%E1%83%97%E1%83%9D%20%E1%83%9B%E1%83%90%E1%83%9C%E1%83%A5%E1%83%90%E1%83%9C%E1%83%90#Georgian) | truck | saṭvirto mankana · noun |
| [უცხო](https://en.wiktionary.org/wiki/%E1%83%A3%E1%83%AA%E1%83%AE%E1%83%9D#Georgian) | strange | ucxo · adj |
| [ფაქიზი](https://en.wiktionary.org/wiki/%E1%83%A4%E1%83%90%E1%83%A5%E1%83%98%E1%83%96%E1%83%98#Georgian) | pure, neat | pakizi · adj |
| [ღიმილი](https://en.wiktionary.org/wiki/%E1%83%A6%E1%83%98%E1%83%9B%E1%83%98%E1%83%9A%E1%83%98#Georgian) | smile | ɣimili · noun |
| [აშკარა](https://en.wiktionary.org/wiki/%E1%83%90%E1%83%A8%E1%83%99%E1%83%90%E1%83%A0%E1%83%90#Georgian) | obvious | ašḳara · adj |
| [თანაც](https://en.wiktionary.org/wiki/%E1%83%97%E1%83%90%E1%83%9C%E1%83%90%E1%83%AA#Georgian) | besides | tanac · adv |
| [იხვი](https://en.wiktionary.org/wiki/%E1%83%98%E1%83%AE%E1%83%95%E1%83%98#Georgian) | duck (aquatic bird) | ixvi · noun |
| [კისერი](https://en.wiktionary.org/wiki/%E1%83%99%E1%83%98%E1%83%A1%E1%83%94%E1%83%A0%E1%83%98#Georgian) | neck | ḳiseri · noun |
| [მაისური](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%90%E1%83%98%E1%83%A1%E1%83%A3%E1%83%A0%E1%83%98#Georgian) | T-shirt | maisuri · noun |
| [მერცხალი](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%94%E1%83%A0%E1%83%AA%E1%83%AE%E1%83%90%E1%83%9A%E1%83%98#Georgian) | swallow (bird) | mercxali · noun |
| [ნელა](https://en.wiktionary.org/wiki/%E1%83%9C%E1%83%94%E1%83%9A%E1%83%90#Georgian) | slowly | nela · adv |
| [ნული](https://en.wiktionary.org/wiki/%E1%83%9C%E1%83%A3%E1%83%9A%E1%83%98#Georgian) | zero | nuli · num |
| [სამშაბათი](https://en.wiktionary.org/wiki/%E1%83%A1%E1%83%90%E1%83%9B%E1%83%A8%E1%83%90%E1%83%91%E1%83%90%E1%83%97%E1%83%98#Georgian) | Tuesday | samšabati · noun |
| [ფრინველი](https://en.wiktionary.org/wiki/%E1%83%A4%E1%83%A0%E1%83%98%E1%83%9C%E1%83%95%E1%83%94%E1%83%9A%E1%83%98#Georgian) | bird | prinveli · noun |
| [ქათამი](https://en.wiktionary.org/wiki/%E1%83%A5%E1%83%90%E1%83%97%E1%83%90%E1%83%9B%E1%83%98#Georgian) | chicken | katami · noun |
| [ჩიტი](https://en.wiktionary.org/wiki/%E1%83%A9%E1%83%98%E1%83%A2%E1%83%98#Georgian) | bird | čiṭi · noun |
| [ხორცი](https://en.wiktionary.org/wiki/%E1%83%AE%E1%83%9D%E1%83%A0%E1%83%AA%E1%83%98#Georgian) | meat | xorci · noun |
| [დევი](https://en.wiktionary.org/wiki/%E1%83%93%E1%83%94%E1%83%95%E1%83%98#Georgian) | giant; monster; demon | devi · noun |
| [თემა](https://en.wiktionary.org/wiki/%E1%83%97%E1%83%94%E1%83%9B%E1%83%90#Georgian) | theme | tema · noun |
| [კრიზისი](https://en.wiktionary.org/wiki/%E1%83%99%E1%83%A0%E1%83%98%E1%83%96%E1%83%98%E1%83%A1%E1%83%98#Georgian) | crisis | ḳrizisi · noun |
| [მანდარინი](https://en.wiktionary.org/wiki/%E1%83%9B%E1%83%90%E1%83%9C%E1%83%93%E1%83%90%E1%83%A0%E1%83%98%E1%83%9C%E1%83%98#Georgian) | mandarin orange, tangerine | mandarini · noun |
| [ნარინჯისფერი](https://en.wiktionary.org/wiki/%E1%83%9C%E1%83%90%E1%83%A0%E1%83%98%E1%83%9C%E1%83%AF%E1%83%98%E1%83%A1%E1%83%A4%E1%83%94%E1%83%A0%E1%83%98#Georgian) | orange | narinǯisperi · adj |

</details>

## Question bank

Try before opening the answers. Different tasks use the same sentence to practise complementary skills. Open translation and explanation tasks can have valid alternatives.

### Independent pronouns · 362 questions

**ka-Q0001 · Fill the gap**

____ სააფთიაქოში ვმუშაობ.

I work in a pharmacy.

[[Georgian#^ka-Q0001-answer|Compare the answer]]
^ka-Q0001

**ka-Q0002 · Choose the form**

____ სააფთიაქოში ვმუშაობ.

I work in a pharmacy.

Choices: ის / მე / შენ / ჩვენ

[[Georgian#^ka-Q0002-answer|Compare the answer]]
^ka-Q0002

**ka-Q0003 · Edit the changed sentence**

【შენ】 დავიღალე, და დაწოლა მინდა.

I am tired and I want to go to bed.

[[Georgian#^ka-Q0003-answer|Compare the answer]]
^ka-Q0003

**ka-Q0004 · Build the sentence**

Arrange: და / დაწოლა / მინდა. / დავიღალე, / მე

I am tired and I want to go to bed.

[[Georgian#^ka-Q0004-answer|Compare the answer]]
^ka-Q0004

**ka-Q0005 · Write a translation**

Write this in Georgian: I think I'm drunk.

[[Georgian#^ka-Q0005-answer|Compare the answer]]
^ka-Q0005

**ka-Q0006 · Explain the grammar**

【მე】 ვფიქრობ, რომ მე ვარ მთვრალი.

I think I'm drunk.

[[Georgian#^ka-Q0006-answer|Compare the answer]]
^ka-Q0006

**ka-Q0007 · Fill the gap**

____ ძალიან დაბალი ხართ.

You're very short.

[[Georgian#^ka-Q0007-answer|Compare the answer]]
^ka-Q0007

**ka-Q0008 · Choose the form**

____ ძალიან დაბალი ხართ.

You're very short.

Choices: ის / თქვენ / შენ / მე

[[Georgian#^ka-Q0008-answer|Compare the answer]]
^ka-Q0008

**ka-Q0009 · Edit the changed sentence**

როდიდან 【მე】 ვართ მეგობრები?

Since when are we friends?

[[Georgian#^ka-Q0009-answer|Compare the answer]]
^ka-Q0009

**ka-Q0010 · Build the sentence**

Arrange: მეგობრები? / ჩვენ / როდიდან / ვართ

Since when are we friends?

[[Georgian#^ka-Q0010-answer|Compare the answer]]
^ka-Q0010

**ka-Q0011 · Write a translation**

Write this in Georgian: The owner's explanation is clear.

[[Georgian#^ka-Q0011-answer|Compare the answer]]
^ka-Q0011

**ka-Q0012 · Explain the grammar**

მესაკუთრეს ახსნა არ【ის】 გასაგები.

The owner's explanation is clear.

[[Georgian#^ka-Q0012-answer|Compare the answer]]
^ka-Q0012

**ka-Q0013 · Fill the gap**

____ არის მსოფლიო ჩემპიონი.

She's the world champion.

[[Georgian#^ka-Q0013-answer|Compare the answer]]
^ka-Q0013

**ka-Q0014 · Choose the form**

____ არის მსოფლიო ჩემპიონი.

She's the world champion.

Choices: ჩვენ / შენ / მე / ის

[[Georgian#^ka-Q0014-answer|Compare the answer]]
^ka-Q0014

**ka-Q0015 · Edit the changed sentence**

შემიძლია 【მე】 გავაკეთო ერთ კვირაში.

I can do it in a week.

[[Georgian#^ka-Q0015-answer|Compare the answer]]
^ka-Q0015

**ka-Q0016 · Build the sentence**

Arrange: ის / შემიძლია / გავაკეთო / კვირაში. / ერთ

I can do it in a week.

[[Georgian#^ka-Q0016-answer|Compare the answer]]
^ka-Q0016

**ka-Q0017 · Write a translation**

Write this in Georgian: You're lying to me now.

[[Georgian#^ka-Q0017-answer|Compare the answer]]
^ka-Q0017

**ka-Q0018 · Explain the grammar**

【შენ】 ახლა ცრუობ ჩემთვის.

You're lying to me now.

[[Georgian#^ka-Q0018-answer|Compare the answer]]
^ka-Q0018

**ka-Q0019 · Fill the gap**

მინდა რომ სამაგიერო გადაგიხადოთ თქვენი გულკეთილობისთვ____ უახლოეს მომავალში.

I would like to repay your kindness in the near future.

[[Georgian#^ka-Q0019-answer|Compare the answer]]
^ka-Q0019

**ka-Q0020 · Choose the form**

მინდა რომ სამაგიერო გადაგიხადოთ თქვენი გულკეთილობისთვ____ უახლოეს მომავალში.

I would like to repay your kindness in the near future.

Choices: ის / მე / შენ / ჩვენ

[[Georgian#^ka-Q0020-answer|Compare the answer]]
^ka-Q0020

**ka-Q0021 · Edit the changed sentence**

ტომი არ【მე】 მიკრობიოლოგი.

Tom is a microbiologist.

[[Georgian#^ka-Q0021-answer|Compare the answer]]
^ka-Q0021

**ka-Q0022 · Build the sentence**

Arrange: ტომი / მიკრობიოლოგი. / არის

Tom is a microbiologist.

[[Georgian#^ka-Q0022-answer|Compare the answer]]
^ka-Q0022

**ka-Q0023 · Write a translation**

Write this in Georgian: It's easier to get what you want with a smile than with the tip of the sword.

[[Georgian#^ka-Q0023-answer|Compare the answer]]
^ka-Q0023

**ka-Q0024 · Explain the grammar**

იმ【ის】 მიღება, რაც გინდა, ღიმილით უფრო მარტივია ვიდრე ხმლის წვერით.

It's easier to get what you want with a smile than with the tip of the sword.

[[Georgian#^ka-Q0024-answer|Compare the answer]]
^ka-Q0024

**ka-Q0025 · Fill the gap**

____ ამერიკელი ხარ?

Are you American?

[[Georgian#^ka-Q0025-answer|Compare the answer]]
^ka-Q0025

**ka-Q0026 · Choose the form**

____ ამერიკელი ხარ?

Are you American?

Choices: შენ / ის / მე / ჩვენ

[[Georgian#^ka-Q0026-answer|Compare the answer]]
^ka-Q0026

**ka-Q0027 · Edit the changed sentence**

【მე】 კარს აღებს.

He opens the door.

[[Georgian#^ka-Q0027-answer|Compare the answer]]
^ka-Q0027

**ka-Q0028 · Build the sentence**

Arrange: აღებს. / ის / კარს

He opens the door.

[[Georgian#^ka-Q0028-answer|Compare the answer]]
^ka-Q0028

**ka-Q0029 · Write a translation**

Write this in Georgian: Tom is Mary's neighbor, isn't he?

[[Georgian#^ka-Q0029-answer|Compare the answer]]
^ka-Q0029

**ka-Q0030 · Explain the grammar**

ტომი მარ【ის】 მეზობელია, არა?

Tom is Mary's neighbor, isn't he?

[[Georgian#^ka-Q0030-answer|Compare the answer]]
^ka-Q0030

**ka-Q0031 · Fill the gap**

სად არ____ სასმელი წყალი?

Where is the water drinkable?

[[Georgian#^ka-Q0031-answer|Compare the answer]]
^ka-Q0031

**ka-Q0032 · Choose the form**

სად არ____ სასმელი წყალი?

Where is the water drinkable?

Choices: ჩვენ / შენ / ის / მე

[[Georgian#^ka-Q0032-answer|Compare the answer]]
^ka-Q0032

**ka-Q0033 · Edit the changed sentence**

ორი კვირ【მე】 წინ მე პირველად დისნეილენდს ვიყავი.

Two weeks ago, I visited Disneyland for the first time.

[[Georgian#^ka-Q0033-answer|Compare the answer]]
^ka-Q0033

**ka-Q0034 · Build the sentence**

Arrange: დისნეილენდს / კვირის / ვიყავი. / პირველად / მე / ორი / წინ

Two weeks ago, I visited Disneyland for the first time.

[[Georgian#^ka-Q0034-answer|Compare the answer]]
^ka-Q0034

**ka-Q0035 · Write a translation**

Write this in Georgian: I've believed in Kylie Minogue since June 12, 1998.

[[Georgian#^ka-Q0035-answer|Compare the answer]]
^ka-Q0035

**ka-Q0036 · Explain the grammar**

【მე】 მჯერა კაილი მინოუგის, 1998 წლის 12 ივნისიდან.

I've believed in Kylie Minogue since June 12, 1998.

[[Georgian#^ka-Q0036-answer|Compare the answer]]
^ka-Q0036

**ka-Q0037 · Fill the gap**

____ მომწონს სიმარტივე

I like simplicity.

[[Georgian#^ka-Q0037-answer|Compare the answer]]
^ka-Q0037

**ka-Q0038 · Choose the form**

____ მომწონს სიმარტივე

I like simplicity.

Choices: ის / ჩვენ / მე / შენ

[[Georgian#^ka-Q0038-answer|Compare the answer]]
^ka-Q0038

**ka-Q0039 · Edit the changed sentence**

მ【მე】 გარეშე ცხოვრებას შევეჩვიე.

I learned to live without her.

[[Georgian#^ka-Q0039-answer|Compare the answer]]
^ka-Q0039

**ka-Q0040 · Build the sentence**

Arrange: მის / ცხოვრებას / გარეშე / შევეჩვიე.

I learned to live without her.

[[Georgian#^ka-Q0040-answer|Compare the answer]]
^ka-Q0040

**ka-Q0041 · Write a translation**

Write this in Georgian: I'm writing a letter to my daughter.

[[Georgian#^ka-Q0041-answer|Compare the answer]]
^ka-Q0041

**ka-Q0042 · Explain the grammar**

【მე】 წერილს ვწერ ჩემი ქალიშვილისთვის.

I'm writing a letter to my daughter.

[[Georgian#^ka-Q0042-answer|Compare the answer]]
^ka-Q0042

**ka-Q0043 · Fill the gap**

გამარჯობა, ____ ვარ ნენსი.

Hello, I am Nancy.

[[Georgian#^ka-Q0043-answer|Compare the answer]]
^ka-Q0043

**ka-Q0044 · Choose the form**

გამარჯობა, ____ ვარ ნენსი.

Hello, I am Nancy.

Choices: მე / ის / ჩვენ / შენ

[[Georgian#^ka-Q0044-answer|Compare the answer]]
^ka-Q0044

**ka-Q0045 · Edit the changed sentence**

【მე】 ფული არ გაქვს.

You don't have money.

[[Georgian#^ka-Q0045-answer|Compare the answer]]
^ka-Q0045

**ka-Q0046 · Build the sentence**

Arrange: შენ / არ / გაქვს. / ფული

You don't have money.

[[Georgian#^ka-Q0046-answer|Compare the answer]]
^ka-Q0046

**ka-Q0047 · Write a translation**

Write this in Georgian: We still work at home.

[[Georgian#^ka-Q0047-answer|Compare the answer]]
^ka-Q0047

**ka-Q0048 · Explain the grammar**

【ჩვენ】 ჯერ კიდევ ვმუშაობთ სახლში.

We still work at home.

[[Georgian#^ka-Q0048-answer|Compare the answer]]
^ka-Q0048

**ka-Q0049 · Fill the gap**

არავ____ არ ესმის ჩემი.

Nobody understands me.

[[Georgian#^ka-Q0049-answer|Compare the answer]]
^ka-Q0049

**ka-Q0050 · Choose the form**

არავ____ არ ესმის ჩემი.

Nobody understands me.

Choices: მე / ის / შენ / ჩვენ

[[Georgian#^ka-Q0050-answer|Compare the answer]]
^ka-Q0050

**ka-Q0689 · Write a translation**

Write this in Georgian: I vowed that I would never speak to her again.

[[Georgian#^ka-Q0689-answer|Compare the answer]]
^ka-Q0689

**ka-Q0690 · Explain the grammar**

【მე】 დავიფიცე, რომ არასოდეს აღარ დაველაპარაკები.

I vowed that I would never speak to her again.

[[Georgian#^ka-Q0690-answer|Compare the answer]]
^ka-Q0690

**ka-Q0691 · Fill the gap**

არ____ ტომი უფრო უფროსი ვიდრე შენ?

Is Tom older than you?

[[Georgian#^ka-Q0691-answer|Compare the answer]]
^ka-Q0691

**ka-Q0692 · Choose the form**

არ____ ტომი უფრო უფროსი ვიდრე შენ?

Is Tom older than you?

Choices: მე / ჩვენ / ის / შენ

[[Georgian#^ka-Q0692-answer|Compare the answer]]
^ka-Q0692

**ka-Q0693 · Edit the changed sentence**

არ【მე】 ტომი უფრო ახალგაზრდა ან უფრო მოხუცი ვიდრე შენ?

Is Tom younger or older than you?

[[Georgian#^ka-Q0693-answer|Compare the answer]]
^ka-Q0693

**ka-Q0694 · Build the sentence**

Arrange: უფრო / შენ? / მოხუცი / ან / არის / ვიდრე / უფრო / ტომი / ახალგაზრდა

Is Tom younger or older than you?

[[Georgian#^ka-Q0694-answer|Compare the answer]]
^ka-Q0694

**ka-Q0695 · Write a translation**

Write this in Georgian: I come from America.

[[Georgian#^ka-Q0695-answer|Compare the answer]]
^ka-Q0695

**ka-Q0696 · Explain the grammar**

【მე】 ამერიკიდან ვარ.

I come from America.

[[Georgian#^ka-Q0696-answer|Compare the answer]]
^ka-Q0696

**ka-Q0697 · Fill the gap**

____ ძალიან დაბალი ხარ.

You're very short.

[[Georgian#^ka-Q0697-answer|Compare the answer]]
^ka-Q0697

**ka-Q0698 · Choose the form**

____ ძალიან დაბალი ხარ.

You're very short.

Choices: მე / ჩვენ / შენ / ის

[[Georgian#^ka-Q0698-answer|Compare the answer]]
^ka-Q0698

**ka-Q0699 · Edit the changed sentence**

【შენ】 სკოლაში მივდივარ.

I go to school.

[[Georgian#^ka-Q0699-answer|Compare the answer]]
^ka-Q0699

**ka-Q0700 · Build the sentence**

Arrange: მივდივარ. / სკოლაში / მე

I go to school.

[[Georgian#^ka-Q0700-answer|Compare the answer]]
^ka-Q0700

**ka-Q0701 · Write a translation**

Write this in Georgian: I'm 45 years old.

[[Georgian#^ka-Q0701-answer|Compare the answer]]
^ka-Q0701

**ka-Q0702 · Explain the grammar**

45 წლ【ის】 ვარ.

I'm 45 years old.

[[Georgian#^ka-Q0702-answer|Compare the answer]]
^ka-Q0702

**ka-Q0703 · Fill the gap**

გასულ ღამეს ვესიზმრებოდი, რომ ____ ფუტკარს ვჭამდი.

Last night I dreamt I was eating bees.

[[Georgian#^ka-Q0703-answer|Compare the answer]]
^ka-Q0703

**ka-Q0704 · Choose the form**

გასულ ღამეს ვესიზმრებოდი, რომ ____ ფუტკარს ვჭამდი.

Last night I dreamt I was eating bees.

Choices: მე / ჩვენ / შენ / ის

[[Georgian#^ka-Q0704-answer|Compare the answer]]
^ka-Q0704

**ka-Q0705 · Edit the changed sentence**

ვინ არ【მე】 უფრო დაბალი, შენ თუ ტომი?

Who's shorter, you or Tom?

[[Georgian#^ka-Q0705-answer|Compare the answer]]
^ka-Q0705

**ka-Q0706 · Build the sentence**

Arrange: უფრო / თუ / ვინ / არის / დაბალი, / ტომი? / შენ

Who's shorter, you or Tom?

[[Georgian#^ka-Q0706-answer|Compare the answer]]
^ka-Q0706

**ka-Q0707 · Write a translation**

Write this in Georgian: I'm on your side.

[[Georgian#^ka-Q0707-answer|Compare the answer]]
^ka-Q0707

**ka-Q0708 · Explain the grammar**

【მე】 შენს მხარეს ვარ.

I'm on your side.

[[Georgian#^ka-Q0708-answer|Compare the answer]]
^ka-Q0708

**ka-Q0709 · Fill the gap**

წყალი არ____ ძალიან ცხელი.

The water's very hot.

[[Georgian#^ka-Q0709-answer|Compare the answer]]
^ka-Q0709

**ka-Q0710 · Choose the form**

წყალი არ____ ძალიან ცხელი.

The water's very hot.

Choices: ჩვენ / შენ / ის / მე

[[Georgian#^ka-Q0710-answer|Compare the answer]]
^ka-Q0710

**ka-Q0711 · Edit the changed sentence**

სოფელში ძროხა არ【მე】.

There is a cow in the village.

[[Georgian#^ka-Q0711-answer|Compare the answer]]
^ka-Q0711

**ka-Q0712 · Build the sentence**

Arrange: ძროხა / არის. / სოფელში

There is a cow in the village.

[[Georgian#^ka-Q0712-answer|Compare the answer]]
^ka-Q0712

**ka-Q0713 · Write a translation**

Write this in Georgian: The bear left no stone unturned in his search for fat bugs under the rocks.

[[Georgian#^ka-Q0713-answer|Compare the answer]]
^ka-Q0713

**ka-Q0714 · Explain the grammar**

დათვმა არცერთი ქვა არ დატოვა ამოუტრიალებელი მსუქალი ხოჭოებ【ის】 ძებნისას.

The bear left no stone unturned in his search for fat bugs under the rocks.

[[Georgian#^ka-Q0714-answer|Compare the answer]]
^ka-Q0714

**ka-Q0715 · Fill the gap**

____ ეგვიპტედან ვარ.

I am from Egypt.

[[Georgian#^ka-Q0715-answer|Compare the answer]]
^ka-Q0715

**ka-Q0716 · Choose the form**

____ ეგვიპტედან ვარ.

I am from Egypt.

Choices: ის / მე / ჩვენ / შენ

[[Georgian#^ka-Q0716-answer|Compare the answer]]
^ka-Q0716

**ka-Q0717 · Edit the changed sentence**

【შენ】 ვარ ჟურნალისტი.

I am a journalist.

[[Georgian#^ka-Q0717-answer|Compare the answer]]
^ka-Q0717

**ka-Q0718 · Build the sentence**

Arrange: ვარ / ჟურნალისტი. / მე

I am a journalist.

[[Georgian#^ka-Q0718-answer|Compare the answer]]
^ka-Q0718

**ka-Q0719 · Write a translation**

Write this in Georgian: I'll give you an apple.

[[Georgian#^ka-Q0719-answer|Compare the answer]]
^ka-Q0719

**ka-Q0720 · Explain the grammar**

【მე】 მოგცემ ვაშლს.

I'll give you an apple.

[[Georgian#^ka-Q0720-answer|Compare the answer]]
^ka-Q0720

**ka-Q0721 · Fill the gap**

უკაცრავად. ____ ის პიროვნება ხართ?

Excuse me. Are you that person?

[[Georgian#^ka-Q0721-answer|Compare the answer]]
^ka-Q0721

**ka-Q0722 · Choose the form**

უკაცრავად. ____ ის პიროვნება ხართ?

Excuse me. Are you that person?

Choices: შენ / თქვენ / ის / მე

[[Georgian#^ka-Q0722-answer|Compare the answer]]
^ka-Q0722

**ka-Q0723 · Edit the changed sentence**

არ მინდა, რომ თომი ჩემი პატრონი იყოს, რადგან 【მე】 იდიოტია.

I don't want Tom to be my boss because he is an idiot.

[[Georgian#^ka-Q0723-answer|Compare the answer]]
^ka-Q0723

**ka-Q0724 · Build the sentence**

Arrange: რომ / იყოს, / არ / თომი / მინდა, / პატრონი / ჩემი / ის / რადგან / იდიოტია.

I don't want Tom to be my boss because he is an idiot.

[[Georgian#^ka-Q0724-answer|Compare the answer]]
^ka-Q0724

**ka-Q0725 · Write a translation**

Write this in Georgian: This is Tom's school.

[[Georgian#^ka-Q0725-answer|Compare the answer]]
^ka-Q0725

**ka-Q0726 · Explain the grammar**

ეს ტომ【ის】 სკოლაა.

This is Tom's school.

[[Georgian#^ka-Q0726-answer|Compare the answer]]
^ka-Q0726

**ka-Q0727 · Fill the gap**

ეს არ____ გოგო.

This is a girl.

[[Georgian#^ka-Q0727-answer|Compare the answer]]
^ka-Q0727

**ka-Q0728 · Choose the form**

ეს არ____ გოგო.

This is a girl.

Choices: ჩვენ / შენ / ის / მე

[[Georgian#^ka-Q0728-answer|Compare the answer]]
^ka-Q0728

**ka-Q0729 · Edit the changed sentence**

აი შენი ძაღლი. სად არ【მე】 ჩემი?

Here is your dog. Where is mine?

[[Georgian#^ka-Q0729-answer|Compare the answer]]
^ka-Q0729

**ka-Q0730 · Build the sentence**

Arrange: შენი / არის / სად / აი / ჩემი? / ძაღლი.

Here is your dog. Where is mine?

[[Georgian#^ka-Q0730-answer|Compare the answer]]
^ka-Q0730

**ka-Q0731 · Write a translation**

Write this in Georgian: I am 19 years old.

[[Georgian#^ka-Q0731-answer|Compare the answer]]
^ka-Q0731

**ka-Q0732 · Explain the grammar**

【მე】 ცხრამეტი წლის ვარ.

I am 19 years old.

[[Georgian#^ka-Q0732-answer|Compare the answer]]
^ka-Q0732

**ka-Q0733 · Fill the gap**

____ კარს აღებენ.

They open the door.

[[Georgian#^ka-Q0733-answer|Compare the answer]]
^ka-Q0733

**ka-Q0734 · Choose the form**

____ კარს აღებენ.

They open the door.

Choices: შენ / ის / მე / ისინი

[[Georgian#^ka-Q0734-answer|Compare the answer]]
^ka-Q0734

**ka-Q0735 · Edit the changed sentence**

მას 【შენ】 უყვარვარ?

Does he love me?

[[Georgian#^ka-Q0735-answer|Compare the answer]]
^ka-Q0735

**ka-Q0736 · Build the sentence**

Arrange: მას / უყვარვარ? / მე

Does he love me?

[[Georgian#^ka-Q0736-answer|Compare the answer]]
^ka-Q0736

**ka-Q0737 · Write a translation**

Write this in Georgian: You study English.

[[Georgian#^ka-Q0737-answer|Compare the answer]]
^ka-Q0737

**ka-Q0738 · Explain the grammar**

【შენ】 ინგლისურს სწავლობ.

You study English.

[[Georgian#^ka-Q0738-answer|Compare the answer]]
^ka-Q0738

**ka-Q0739 · Fill the gap**

____ უნდა წავიდე.

I have to go.

[[Georgian#^ka-Q0739-answer|Compare the answer]]
^ka-Q0739

**ka-Q0740 · Choose the form**

____ უნდა წავიდე.

I have to go.

Choices: ჩვენ / მე / შენ / ის

[[Georgian#^ka-Q0740-answer|Compare the answer]]
^ka-Q0740

**ka-Q0741 · Edit the changed sentence**

ტუალეტ【მე】 ქაღალდი არ იყო.

There was no toilet paper.

[[Georgian#^ka-Q0741-answer|Compare the answer]]
^ka-Q0741

**ka-Q0742 · Build the sentence**

Arrange: არ / ქაღალდი / ტუალეტის / იყო.

There was no toilet paper.

[[Georgian#^ka-Q0742-answer|Compare the answer]]
^ka-Q0742

**ka-Q0743 · Write a translation**

Write this in Georgian: Yes, I am from Sapporo.

[[Georgian#^ka-Q0743-answer|Compare the answer]]
^ka-Q0743

**ka-Q0744 · Explain the grammar**

დიახ, 【მე】 საპოროდან ვარ.

Yes, I am from Sapporo.

[[Georgian#^ka-Q0744-answer|Compare the answer]]
^ka-Q0744

**ka-Q0745 · Fill the gap**

ზამთარში ცურვა არ არ____ საშიში ჯანმრთელი ხალხისთვის.

Winter swimming isn't dangerous for healthy people.

[[Georgian#^ka-Q0745-answer|Compare the answer]]
^ka-Q0745

**ka-Q0746 · Choose the form**

ზამთარში ცურვა არ არ____ საშიში ჯანმრთელი ხალხისთვის.

Winter swimming isn't dangerous for healthy people.

Choices: ჩვენ / მე / შენ / ის

[[Georgian#^ka-Q0746-answer|Compare the answer]]
^ka-Q0746

**ka-Q0747 · Edit the changed sentence**

იმ【მე】 გამო სწავლობენ ინგლისურს.

That is what they study English for.

[[Georgian#^ka-Q0747-answer|Compare the answer]]
^ka-Q0747

**ka-Q0748 · Build the sentence**

Arrange: სწავლობენ / ინგლისურს. / გამო / იმის

That is what they study English for.

[[Georgian#^ka-Q0748-answer|Compare the answer]]
^ka-Q0748

**ka-Q0749 · Write a translation**

Write this in Georgian: I'm not old.

[[Georgian#^ka-Q0749-answer|Compare the answer]]
^ka-Q0749

**ka-Q0750 · Explain the grammar**

【მე】 არ ვარ ხნიერი.

I'm not old.

[[Georgian#^ka-Q0750-answer|Compare the answer]]
^ka-Q0750

**ka-Q0751 · Fill the gap**

ტომმა ლექსიკონი იყიდა მარიამისთვ____.

Tom bought Mary a dictionary.

[[Georgian#^ka-Q0751-answer|Compare the answer]]
^ka-Q0751

**ka-Q0752 · Choose the form**

ტომმა ლექსიკონი იყიდა მარიამისთვ____.

Tom bought Mary a dictionary.

Choices: შენ / ის / ჩვენ / მე

[[Georgian#^ka-Q0752-answer|Compare the answer]]
^ka-Q0752

**ka-Q0753 · Edit the changed sentence**

【შენ】 მინდა მოვკვდე გეთერ იანი - თან ერთად.

I want to die with Getter Jaani.

[[Georgian#^ka-Q0753-answer|Compare the answer]]
^ka-Q0753

**ka-Q0754 · Build the sentence**

Arrange: მე / - / ერთად. / გეთერ / იანი / მოვკვდე / თან / მინდა

I want to die with Getter Jaani.

[[Georgian#^ka-Q0754-answer|Compare the answer]]
^ka-Q0754

**ka-Q0755 · Write a translation**

Write this in Georgian: I have no alternatives.

[[Georgian#^ka-Q0755-answer|Compare the answer]]
^ka-Q0755

**ka-Q0756 · Explain the grammar**

【მე】 არ მაქვს ალტერნატივა.

I have no alternatives.

[[Georgian#^ka-Q0756-answer|Compare the answer]]
^ka-Q0756

**ka-Q0757 · Fill the gap**

____ შენს უკან ვარ.

I'm behind you.

[[Georgian#^ka-Q0757-answer|Compare the answer]]
^ka-Q0757

**ka-Q0758 · Choose the form**

____ შენს უკან ვარ.

I'm behind you.

Choices: ჩვენ / ის / შენ / მე

[[Georgian#^ka-Q0758-answer|Compare the answer]]
^ka-Q0758

**ka-Q0759 · Edit the changed sentence**

【შენ】 კარს ვაღებ.

I open the door.

[[Georgian#^ka-Q0759-answer|Compare the answer]]
^ka-Q0759

**ka-Q0760 · Build the sentence**

Arrange: ვაღებ. / კარს / მე

I open the door.

[[Georgian#^ka-Q0760-answer|Compare the answer]]
^ka-Q0760

**ka-Q0761 · Write a translation**

Write this in Georgian: I'm not a dictator.

[[Georgian#^ka-Q0761-answer|Compare the answer]]
^ka-Q0761

**ka-Q0762 · Explain the grammar**

【მე】 არა ვარ დიქტატორი.

I'm not a dictator.

[[Georgian#^ka-Q0762-answer|Compare the answer]]
^ka-Q0762

**ka-Q0763 · Fill the gap**

ცათამბჯენი ქალაქ____ ცენტრშია.

The skyscraper is in the center of the city.

[[Georgian#^ka-Q0763-answer|Compare the answer]]
^ka-Q0763

**ka-Q0764 · Choose the form**

ცათამბჯენი ქალაქ____ ცენტრშია.

The skyscraper is in the center of the city.

Choices: შენ / ის / მე / ჩვენ

[[Georgian#^ka-Q0764-answer|Compare the answer]]
^ka-Q0764

**ka-Q0765 · Edit the changed sentence**

【მე】 წერილს დაწერა.

He wrote a letter.

[[Georgian#^ka-Q0765-answer|Compare the answer]]
^ka-Q0765

**ka-Q0766 · Build the sentence**

Arrange: წერილს / დაწერა. / ის

He wrote a letter.

[[Georgian#^ka-Q0766-answer|Compare the answer]]
^ka-Q0766

**ka-Q0767 · Write a translation**

Write this in Georgian: Am I pretty?

[[Georgian#^ka-Q0767-answer|Compare the answer]]
^ka-Q0767

**ka-Q0768 · Explain the grammar**

【მე】 ლამაზი ვარ?

Am I pretty?

[[Georgian#^ka-Q0768-answer|Compare the answer]]
^ka-Q0768

**ka-Q0769 · Fill the gap**

ეს არ____ ჩემი წიგნი.

This is my book.

[[Georgian#^ka-Q0769-answer|Compare the answer]]
^ka-Q0769

**ka-Q0770 · Choose the form**

ეს არ____ ჩემი წიგნი.

This is my book.

Choices: მე / შენ / ის / ჩვენ

[[Georgian#^ka-Q0770-answer|Compare the answer]]
^ka-Q0770

**ka-Q0771 · Edit the changed sentence**

სკოლაში წასვლ【მე】 დროა.

It's time to go to school.

[[Georgian#^ka-Q0771-answer|Compare the answer]]
^ka-Q0771

**ka-Q0772 · Build the sentence**

Arrange: დროა. / სკოლაში / წასვლის

It's time to go to school.

[[Georgian#^ka-Q0772-answer|Compare the answer]]
^ka-Q0772

**ka-Q0773 · Write a translation**

Write this in Georgian: Three people died in the car accident.

[[Georgian#^ka-Q0773-answer|Compare the answer]]
^ka-Q0773

**ka-Q0774 · Explain the grammar**

ავტოავარიამ სამი ადამიან【ის】 სიცოცხლე იმსხვერპლა.

Three people died in the car accident.

[[Georgian#^ka-Q0774-answer|Compare the answer]]
^ka-Q0774

**ka-Q0775 · Fill the gap**

ღიმილი, რომელსაც გაგზავნი, ისევ ____ დაგიბრუნდება.

The smile you send out returns to you.

[[Georgian#^ka-Q0775-answer|Compare the answer]]
^ka-Q0775

**ka-Q0776 · Choose the form**

ღიმილი, რომელსაც გაგზავნი, ისევ ____ დაგიბრუნდება.

The smile you send out returns to you.

Choices: მე / ის / შენ / ჩვენ

[[Georgian#^ka-Q0776-answer|Compare the answer]]
^ka-Q0776

**ka-Q0777 · Edit the changed sentence**

ჩემი სინდისი არ არ【მე】 სუფთა.

My conscience is not clean.

[[Georgian#^ka-Q0777-answer|Compare the answer]]
^ka-Q0777

**ka-Q0778 · Build the sentence**

Arrange: არ / არის / ჩემი / სინდისი / სუფთა.

My conscience is not clean.

[[Georgian#^ka-Q0778-answer|Compare the answer]]
^ka-Q0778

**ka-Q0779 · Write a translation**

Write this in Georgian: Excuse me, do you speak Italian?

[[Georgian#^ka-Q0779-answer|Compare the answer]]
^ka-Q0779

**ka-Q0780 · Explain the grammar**

უკაცრავად , 【თქვენ】 საუბრობთ იტალიურად?

Excuse me, do you speak Italian?

[[Georgian#^ka-Q0780-answer|Compare the answer]]
^ka-Q0780

**ka-Q0781 · Fill the gap**

____ ვერ შეასრულა ტომ.

I couldn't stop Tom.

[[Georgian#^ka-Q0781-answer|Compare the answer]]
^ka-Q0781

**ka-Q0782 · Choose the form**

____ ვერ შეასრულა ტომ.

I couldn't stop Tom.

Choices: ჩვენ / შენ / ის / მე

[[Georgian#^ka-Q0782-answer|Compare the answer]]
^ka-Q0782

**ka-Q0783 · Edit the changed sentence**

【შენ】 ცალთვალა ვარ.

I'm one-eyed.

[[Georgian#^ka-Q0783-answer|Compare the answer]]
^ka-Q0783

**ka-Q0784 · Build the sentence**

Arrange: მე / ვარ. / ცალთვალა

I'm one-eyed.

[[Georgian#^ka-Q0784-answer|Compare the answer]]
^ka-Q0784

**ka-Q0785 · Write a translation**

Write this in Georgian: Mind your own business!

[[Georgian#^ka-Q0785-answer|Compare the answer]]
^ka-Q0785

**ka-Q0786 · Explain the grammar**

【შენ】 საქმეს მიხედე!

Mind your own business!

[[Georgian#^ka-Q0786-answer|Compare the answer]]
^ka-Q0786

**ka-Q0787 · Fill the gap**

____ ამ ტენის კლუბის წევრი ვარ.

I'm a member of the tennis club.

[[Georgian#^ka-Q0787-answer|Compare the answer]]
^ka-Q0787

**ka-Q0788 · Choose the form**

____ ამ ტენის კლუბის წევრი ვარ.

I'm a member of the tennis club.

Choices: ჩვენ / მე / შენ / ის

[[Georgian#^ka-Q0788-answer|Compare the answer]]
^ka-Q0788

**ka-Q0789 · Edit the changed sentence**

【მე】 ჩემი დები არიან.

They are my sisters.

[[Georgian#^ka-Q0789-answer|Compare the answer]]
^ka-Q0789

**ka-Q0790 · Build the sentence**

Arrange: ჩემი / დები / ისინი / არიან.

They are my sisters.

[[Georgian#^ka-Q0790-answer|Compare the answer]]
^ka-Q0790

**ka-Q0791 · Write a translation**

Write this in Georgian: Fruit and vegetables are good for your health, but we don't know why.

[[Georgian#^ka-Q0791-answer|Compare the answer]]
^ka-Q0791

**ka-Q0792 · Explain the grammar**

ხილი და ბოსტნეული ჯანმრთელი არიან, მაგრამ 【ჩვენ】 არ ვიცით რატომ.

Fruit and vegetables are good for your health, but we don't know why.

[[Georgian#^ka-Q0792-answer|Compare the answer]]
^ka-Q0792

**ka-Q0793 · Fill the gap**

____ აქ მუშაობთ?

Do you work here?

[[Georgian#^ka-Q0793-answer|Compare the answer]]
^ka-Q0793

**ka-Q0794 · Choose the form**

____ აქ მუშაობთ?

Do you work here?

Choices: ის / შენ / მე / თქვენ

[[Georgian#^ka-Q0794-answer|Compare the answer]]
^ka-Q0794

**ka-Q0795 · Edit the changed sentence**

მას 【შენ】 არ უყვარვარ.

He doesn't love me.

[[Georgian#^ka-Q0795-answer|Compare the answer]]
^ka-Q0795

**ka-Q0796 · Build the sentence**

Arrange: უყვარვარ. / მე / მას / არ

He doesn't love me.

[[Georgian#^ka-Q0796-answer|Compare the answer]]
^ka-Q0796

**ka-Q0797 · Write a translation**

Write this in Georgian: I'll give you a present.

[[Georgian#^ka-Q0797-answer|Compare the answer]]
^ka-Q0797

**ka-Q0798 · Explain the grammar**

【მე】 მოგცემ საჩუქარს.

I'll give you a present.

[[Georgian#^ka-Q0798-answer|Compare the answer]]
^ka-Q0798

**ka-Q0799 · Fill the gap**

____ მოგიტან შენ.

I'll bring you.

[[Georgian#^ka-Q0799-answer|Compare the answer]]
^ka-Q0799

**ka-Q0800 · Choose the form**

____ მოგიტან შენ.

I'll bring you.

Choices: შენ / ის / ჩვენ / მე

[[Georgian#^ka-Q0800-answer|Compare the answer]]
^ka-Q0800

**ka-Q0801 · Edit the changed sentence**

მითხრა, ვინ არ【მე】 ეს ვაჟი?

Tell me; who is this young man?

[[Georgian#^ka-Q0801-answer|Compare the answer]]
^ka-Q0801

**ka-Q0802 · Build the sentence**

Arrange: ვინ / ეს / ვაჟი? / მითხრა, / არის

Tell me; who is this young man?

[[Georgian#^ka-Q0802-answer|Compare the answer]]
^ka-Q0802

**ka-Q0803 · Write a translation**

Write this in Georgian: I think Tom lives in Boston.

[[Georgian#^ka-Q0803-answer|Compare the answer]]
^ka-Q0803

**ka-Q0804 · Explain the grammar**

【მე】 მგონი ტომი ბოსტონში ცხოვრობს.

I think Tom lives in Boston.

[[Georgian#^ka-Q0804-answer|Compare the answer]]
^ka-Q0804

**ka-Q0805 · Fill the gap**

ეს წიგნები ჩემი დ____ არიან.

Those are my sister's books.

[[Georgian#^ka-Q0805-answer|Compare the answer]]
^ka-Q0805

**ka-Q0806 · Choose the form**

ეს წიგნები ჩემი დ____ არიან.

Those are my sister's books.

Choices: შენ / მე / ის / ჩვენ

[[Georgian#^ka-Q0806-answer|Compare the answer]]
^ka-Q0806

**ka-Q0807 · Edit the changed sentence**

ტომი არ არ【მე】 შიგნით.

Tom's not in.

[[Georgian#^ka-Q0807-answer|Compare the answer]]
^ka-Q0807

**ka-Q0808 · Build the sentence**

Arrange: არ / შიგნით. / ტომი / არის

Tom's not in.

[[Georgian#^ka-Q0808-answer|Compare the answer]]
^ka-Q0808

**ka-Q0809 · Write a translation**

Write this in Georgian: I just wanted to make you happy.

[[Georgian#^ka-Q0809-answer|Compare the answer]]
^ka-Q0809

**ka-Q0810 · Explain the grammar**

【მე】 უბრალოდ მინდოდა შენი გაბედნიერება.

I just wanted to make you happy.

[[Georgian#^ka-Q0810-answer|Compare the answer]]
^ka-Q0810

**ka-Q0811 · Fill the gap**

ეს არ____ ტელევიზორი.

This is a television.

[[Georgian#^ka-Q0811-answer|Compare the answer]]
^ka-Q0811

**ka-Q0812 · Choose the form**

ეს არ____ ტელევიზორი.

This is a television.

Choices: შენ / მე / ჩვენ / ის

[[Georgian#^ka-Q0812-answer|Compare the answer]]
^ka-Q0812

**ka-Q0813 · Edit the changed sentence**

ხვალ ვინ მიდ【მე】 ქალაქში?

Who is going into the city tomorrow?

[[Georgian#^ka-Q0813-answer|Compare the answer]]
^ka-Q0813

**ka-Q0814 · Build the sentence**

Arrange: ვინ / ქალაქში? / ხვალ / მიდის

Who is going into the city tomorrow?

[[Georgian#^ka-Q0814-answer|Compare the answer]]
^ka-Q0814

**ka-Q0815 · Write a translation**

Write this in Georgian: The horse is not white.

[[Georgian#^ka-Q0815-answer|Compare the answer]]
^ka-Q0815

**ka-Q0816 · Explain the grammar**

ცხენი არ არ【ის】 თეთრი.

The horse is not white.

[[Georgian#^ka-Q0816-answer|Compare the answer]]
^ka-Q0816

**ka-Q0817 · Fill the gap**

ყოველთვ____ ვუყურებ ამ სურათს მორყვნით.

I always view this photo with disgust.

[[Georgian#^ka-Q0817-answer|Compare the answer]]
^ka-Q0817

**ka-Q0818 · Choose the form**

ყოველთვ____ ვუყურებ ამ სურათს მორყვნით.

I always view this photo with disgust.

Choices: შენ / ის / მე / ჩვენ

[[Georgian#^ka-Q0818-answer|Compare the answer]]
^ka-Q0818

**ka-Q0819 · Edit the changed sentence**

სად არ【მე】 სასტუმრო?

Where is the hotel?

[[Georgian#^ka-Q0819-answer|Compare the answer]]
^ka-Q0819

**ka-Q0820 · Build the sentence**

Arrange: არის / სასტუმრო? / სად

Where is the hotel?

[[Georgian#^ka-Q0820-answer|Compare the answer]]
^ka-Q0820

**ka-Q0821 · Write a translation**

Write this in Georgian: What did you answer?

[[Georgian#^ka-Q0821-answer|Compare the answer]]
^ka-Q0821

**ka-Q0822 · Explain the grammar**

【შენ】 რა უპასუხე?

What did you answer?

[[Georgian#^ka-Q0822-answer|Compare the answer]]
^ka-Q0822

**ka-Q0823 · Fill the gap**

____ არ ვიცი იაპონურად ლაპარაკი.

I don't speak Japanese.

[[Georgian#^ka-Q0823-answer|Compare the answer]]
^ka-Q0823

**ka-Q0824 · Choose the form**

____ არ ვიცი იაპონურად ლაპარაკი.

I don't speak Japanese.

Choices: ის / ჩვენ / მე / შენ

[[Georgian#^ka-Q0824-answer|Compare the answer]]
^ka-Q0824

**ka-Q0825 · Edit the changed sentence**

【მე】 პლაჟები აქედან შორსაა.

Those beaches are far from here.

[[Georgian#^ka-Q0825-answer|Compare the answer]]
^ka-Q0825

**ka-Q0826 · Build the sentence**

Arrange: აქედან / შორსაა. / ის / პლაჟები

Those beaches are far from here.

[[Georgian#^ka-Q0826-answer|Compare the answer]]
^ka-Q0826

**ka-Q0827 · Write a translation**

Write this in Georgian: I'm in the same boat.

[[Georgian#^ka-Q0827-answer|Compare the answer]]
^ka-Q0827

**ka-Q0828 · Explain the grammar**

【მე】 ვარ იგივე ნავში.

I'm in the same boat.

[[Georgian#^ka-Q0828-answer|Compare the answer]]
^ka-Q0828

**ka-Q0829 · Fill the gap**

____ მიყვარს დონატები

I like doughnuts.

[[Georgian#^ka-Q0829-answer|Compare the answer]]
^ka-Q0829

**ka-Q0830 · Choose the form**

____ მიყვარს დონატები

I like doughnuts.

Choices: ის / მე / შენ / ჩვენ

[[Georgian#^ka-Q0830-answer|Compare the answer]]
^ka-Q0830

**ka-Q0831 · Edit the changed sentence**

ვაშლ【მე】 ტორტს ჭამა მინდა.

I want to eat apple pie.

[[Georgian#^ka-Q0831-answer|Compare the answer]]
^ka-Q0831

**ka-Q0832 · Build the sentence**

Arrange: ტორტს / ვაშლის / ჭამა / მინდა.

I want to eat apple pie.

[[Georgian#^ka-Q0832-answer|Compare the answer]]
^ka-Q0832

**ka-Q0833 · Write a translation**

Write this in Georgian: "Where do you live?" "I live in Tokyo."

[[Georgian#^ka-Q0833-answer|Compare the answer]]
^ka-Q0833

**ka-Q0834 · Explain the grammar**

„სად ცხოვრობ 【შენ】?“ „მე ტოკიოში ვცხოვრობ.“

"Where do you live?" "I live in Tokyo."

[[Georgian#^ka-Q0834-answer|Compare the answer]]
^ka-Q0834

**ka-Q0835 · Fill the gap**

____ შენ მიყვარხარ.

I love you.

[[Georgian#^ka-Q0835-answer|Compare the answer]]
^ka-Q0835

**ka-Q0836 · Choose the form**

____ შენ მიყვარხარ.

I love you.

Choices: ის / შენ / ჩვენ / მე

[[Georgian#^ka-Q0836-answer|Compare the answer]]
^ka-Q0836

**ka-Q0837 · Edit the changed sentence**

【მე】 ვაშლებს ჭამენ.

They're eating the apples.

[[Georgian#^ka-Q0837-answer|Compare the answer]]
^ka-Q0837

**ka-Q0838 · Build the sentence**

Arrange: ვაშლებს / ჭამენ. / ისინი

They're eating the apples.

[[Georgian#^ka-Q0838-answer|Compare the answer]]
^ka-Q0838

**ka-Q0839 · Write a translation**

Write this in Georgian: He's the man of the house.

[[Georgian#^ka-Q0839-answer|Compare the answer]]
^ka-Q0839

**ka-Q0840 · Explain the grammar**

【ის】 სახლის კაცია.

He's the man of the house.

[[Georgian#^ka-Q0840-answer|Compare the answer]]
^ka-Q0840

**ka-Q0841 · Fill the gap**

ჩემი გადაწყვეტილებ____ საზღვარგარეთ სწავლის გაკვირვებული ჩემი მშობლები.

My decision to study abroad surprised my parents.

[[Georgian#^ka-Q0841-answer|Compare the answer]]
^ka-Q0841

**ka-Q0842 · Choose the form**

ჩემი გადაწყვეტილებ____ საზღვარგარეთ სწავლის გაკვირვებული ჩემი მშობლები.

My decision to study abroad surprised my parents.

Choices: ჩვენ / მე / შენ / ის

[[Georgian#^ka-Q0842-answer|Compare the answer]]
^ka-Q0842

**ka-Q0843 · Edit the changed sentence**

【შენ】 ტურისტულ სააგენტოში ვმუშაობ.

I work in a tourist agency.

[[Georgian#^ka-Q0843-answer|Compare the answer]]
^ka-Q0843

**ka-Q0844 · Build the sentence**

Arrange: მე / ვმუშაობ. / ტურისტულ / სააგენტოში

I work in a tourist agency.

[[Georgian#^ka-Q0844-answer|Compare the answer]]
^ka-Q0844

**ka-Q0845 · Write a translation**

Write this in Georgian: This is the beginning of a new era.

[[Georgian#^ka-Q0845-answer|Compare the answer]]
^ka-Q0845

**ka-Q0846 · Explain the grammar**

ეს ახალი ერ【ის】 დასაწყისია.

This is the beginning of a new era.

[[Georgian#^ka-Q0846-answer|Compare the answer]]
^ka-Q0846

**ka-Q0847 · Fill the gap**

იმ____ გამო ინგლისურს სწავლობენ.

That is what they study English for.

[[Georgian#^ka-Q0847-answer|Compare the answer]]
^ka-Q0847

**ka-Q0848 · Choose the form**

იმ____ გამო ინგლისურს სწავლობენ.

That is what they study English for.

Choices: ჩვენ / მე / ის / შენ

[[Georgian#^ka-Q0848-answer|Compare the answer]]
^ka-Q0848

**ka-Q0849 · Edit the changed sentence**

【შენ】 წიგნს ვწერ.

I'm writing a book.

[[Georgian#^ka-Q0849-answer|Compare the answer]]
^ka-Q0849

**ka-Q0850 · Build the sentence**

Arrange: წიგნს / მე / ვწერ.

I'm writing a book.

[[Georgian#^ka-Q0850-answer|Compare the answer]]
^ka-Q0850

**ka-Q0851 · Write a translation**

Write this in Georgian: Do you live here?

[[Georgian#^ka-Q0851-answer|Compare the answer]]
^ka-Q0851

**ka-Q0852 · Explain the grammar**

【თქვენ】 აქ ცხოვრობთ?

Do you live here?

[[Georgian#^ka-Q0852-answer|Compare the answer]]
^ka-Q0852

**ka-Q0853 · Fill the gap**

____ მუშაობა არ მინდა ასეთ პირობებში.

I don't want to work under these conditions.

[[Georgian#^ka-Q0853-answer|Compare the answer]]
^ka-Q0853

**ka-Q0854 · Choose the form**

____ მუშაობა არ მინდა ასეთ პირობებში.

I don't want to work under these conditions.

Choices: მე / ის / ჩვენ / შენ

[[Georgian#^ka-Q0854-answer|Compare the answer]]
^ka-Q0854

**ka-Q0855 · Edit the changed sentence**

მეგობრობ【მე】 სადღეგრძელო დავლიოთ!

Cheers!

[[Georgian#^ka-Q0855-answer|Compare the answer]]
^ka-Q0855

**ka-Q0856 · Build the sentence**

Arrange: დავლიოთ! / სადღეგრძელო / მეგობრობის

Cheers!

[[Georgian#^ka-Q0856-answer|Compare the answer]]
^ka-Q0856

**ka-Q0857 · Write a translation**

Write this in Georgian: He says that he knows you.

[[Georgian#^ka-Q0857-answer|Compare the answer]]
^ka-Q0857

**ka-Q0858 · Explain the grammar**

【ის】 ამბობს, რომ გიცნობს.

He says that he knows you.

[[Georgian#^ka-Q0858-answer|Compare the answer]]
^ka-Q0858

**ka-Q0859 · Fill the gap**

____ ბანკში ვმუშაობ.

I work in a bank.

[[Georgian#^ka-Q0859-answer|Compare the answer]]
^ka-Q0859

**ka-Q0860 · Choose the form**

____ ბანკში ვმუშაობ.

I work in a bank.

Choices: ის / შენ / ჩვენ / მე

[[Georgian#^ka-Q0860-answer|Compare the answer]]
^ka-Q0860

**ka-Q0861 · Edit the changed sentence**

【მე】 შევთანხმდით, რომ სამსახურში თავს შევიკავებდით მოწევისაგან.

We agreed to refrain from smoking while we are at work.

[[Georgian#^ka-Q0861-answer|Compare the answer]]
^ka-Q0861

**ka-Q0862 · Build the sentence**

Arrange: შევთანხმდით, / თავს / მოწევისაგან. / სამსახურში / ჩვენ / რომ / შევიკავებდით

We agreed to refrain from smoking while we are at work.

[[Georgian#^ka-Q0862-answer|Compare the answer]]
^ka-Q0862

**ka-Q0863 · Write a translation**

Write this in Georgian: Those are my sister's books.

[[Georgian#^ka-Q0863-answer|Compare the answer]]
^ka-Q0863

**ka-Q0864 · Explain the grammar**

ესენი ჩემი დ【ის】 წიგნები არიან.

Those are my sister's books.

[[Georgian#^ka-Q0864-answer|Compare the answer]]
^ka-Q0864

**ka-Q0865 · Fill the gap**

სად არ____ ჩემი წიგნი?

Where is my book?

[[Georgian#^ka-Q0865-answer|Compare the answer]]
^ka-Q0865

**ka-Q0866 · Choose the form**

სად არ____ ჩემი წიგნი?

Where is my book?

Choices: შენ / მე / ის / ჩვენ

[[Georgian#^ka-Q0866-answer|Compare the answer]]
^ka-Q0866

**ka-Q0867 · Edit the changed sentence**

ტომი 15-【მე】 იყო, მარია 14-ის. სხვა ბავშვები - მათი სახელები აღარ მახსოვს - ცოტათი უმცროსები იყვნენ.

Tom was 15, Maria 14. The other children – I can no longer remember their names – were a bit younger.

[[Georgian#^ka-Q0867-answer|Compare the answer]]
^ka-Q0867

**ka-Q0868 · Build the sentence**

Arrange: სხვა / ბავშვები / 15-ის / აღარ / ტომი / - / - / უმცროსები / ცოტათი / 14-ის. / მახსოვს / მარია / სახელები / იყვნენ. / იყო, / მათი

Tom was 15, Maria 14. The other children – I can no longer remember their names – were a bit younger.

[[Georgian#^ka-Q0868-answer|Compare the answer]]
^ka-Q0868

**ka-Q0869 · Write a translation**

Write this in Georgian: You are doctors.

[[Georgian#^ka-Q0869-answer|Compare the answer]]
^ka-Q0869

**ka-Q0870 · Explain the grammar**

【თქვენ】 ექიმები ხართ.

You are doctors.

[[Georgian#^ka-Q0870-answer|Compare the answer]]
^ka-Q0870

**ka-Q0871 · Fill the gap**

____ მოვაგვარეთ პრობლემა.

We've resolved the problem.

[[Georgian#^ka-Q0871-answer|Compare the answer]]
^ka-Q0871

**ka-Q0872 · Choose the form**

____ მოვაგვარეთ პრობლემა.

We've resolved the problem.

Choices: ჩვენ / ის / შენ / მე

[[Georgian#^ka-Q0872-answer|Compare the answer]]
^ka-Q0872

**ka-Q0873 · Edit the changed sentence**

【მე】 იცის ჩემი ცოლს.

She knows my wife.

[[Georgian#^ka-Q0873-answer|Compare the answer]]
^ka-Q0873

**ka-Q0874 · Build the sentence**

Arrange: ის / ცოლს. / იცის / ჩემი

She knows my wife.

[[Georgian#^ka-Q0874-answer|Compare the answer]]
^ka-Q0874

**ka-Q0875 · Write a translation**

Write this in Georgian: I'm not a good person.

[[Georgian#^ka-Q0875-answer|Compare the answer]]
^ka-Q0875

**ka-Q0876 · Explain the grammar**

【მე】 არა ვარ კარგი ადამიანი.

I'm not a good person.

[[Georgian#^ka-Q0876-answer|Compare the answer]]
^ka-Q0876

**ka-Q0877 · Fill the gap**

____ ამერიკელი ვარ.

I come from America.

[[Georgian#^ka-Q0877-answer|Compare the answer]]
^ka-Q0877

**ka-Q0878 · Choose the form**

____ ამერიკელი ვარ.

I come from America.

Choices: ჩვენ / მე / ის / შენ

[[Georgian#^ka-Q0878-answer|Compare the answer]]
^ka-Q0878

**ka-Q0879 · Edit the changed sentence**

【მე】 ჩემთვის ყველაფერი ხარ.

You are everything to me.

[[Georgian#^ka-Q0879-answer|Compare the answer]]
^ka-Q0879

**ka-Q0880 · Build the sentence**

Arrange: ხარ. / ჩემთვის / ყველაფერი / შენ

You are everything to me.

[[Georgian#^ka-Q0880-answer|Compare the answer]]
^ka-Q0880

**ka-Q0881 · Write a translation**

Write this in Georgian: My sister is two years younger than me.

[[Georgian#^ka-Q0881-answer|Compare the answer]]
^ka-Q0881

**ka-Q0882 · Explain the grammar**

ჩემი და არ【ის】 ორი წლით უმცროსი ჩემზე.

My sister is two years younger than me.

[[Georgian#^ka-Q0882-answer|Compare the answer]]
^ka-Q0882

**ka-Q0883 · Fill the gap**

____ ახალი სურათი არის?

Is it a recent picture?

[[Georgian#^ka-Q0883-answer|Compare the answer]]
^ka-Q0883

**ka-Q0884 · Choose the form**

____ ახალი სურათი არის?

Is it a recent picture?

Choices: შენ / ის / ჩვენ / მე

[[Georgian#^ka-Q0884-answer|Compare the answer]]
^ka-Q0884

**ka-Q0885 · Edit the changed sentence**

【შენ】 არ ვარ მზად ქორწინებისთვის.

I'm not ready for marriage.

[[Georgian#^ka-Q0885-answer|Compare the answer]]
^ka-Q0885

**ka-Q0886 · Build the sentence**

Arrange: არ / მზად / მე / ქორწინებისთვის. / ვარ

I'm not ready for marriage.

[[Georgian#^ka-Q0886-answer|Compare the answer]]
^ka-Q0886

**ka-Q0887 · Write a translation**

Write this in Georgian: I'll give you money.

[[Georgian#^ka-Q0887-answer|Compare the answer]]
^ka-Q0887

**ka-Q0888 · Explain the grammar**

【მე】 მოგცემ ფულს.

I'll give you money.

[[Georgian#^ka-Q0888-answer|Compare the answer]]
^ka-Q0888

**ka-Q0889 · Fill the gap**

____ შენ ძალიან მიყვარხარ.

I love you a lot.

[[Georgian#^ka-Q0889-answer|Compare the answer]]
^ka-Q0889

**ka-Q0890 · Choose the form**

____ შენ ძალიან მიყვარხარ.

I love you a lot.

Choices: ჩვენ / მე / შენ / ის

[[Georgian#^ka-Q0890-answer|Compare the answer]]
^ka-Q0890

**ka-Q0891 · Edit the changed sentence**

【შენ】 უნდა ის გავაკეთო ახლა?

Do I have to do it now?

[[Georgian#^ka-Q0891-answer|Compare the answer]]
^ka-Q0891

**ka-Q0892 · Build the sentence**

Arrange: მე / ახლა? / უნდა / ის / გავაკეთო

Do I have to do it now?

[[Georgian#^ka-Q0892-answer|Compare the answer]]
^ka-Q0892

**ka-Q0893 · Write a translation**

Write this in Georgian: I don't doubt the reliability of his information because it comes from a trustworthy person.

[[Georgian#^ka-Q0893-answer|Compare the answer]]
^ka-Q0893

**ka-Q0894 · Explain the grammar**

ამ ინფორმაცი【ის】 საიმედოობაში ეჭვი არ მეპარება, რადგან ის სანდო ადამიანისგან მოდის.

I don't doubt the reliability of his information because it comes from a trustworthy person.

[[Georgian#^ka-Q0894-answer|Compare the answer]]
^ka-Q0894

**ka-Q0895 · Fill the gap**

იმ____ გამო ვერ მჯერა.

That's why I cannot believe it.

[[Georgian#^ka-Q0895-answer|Compare the answer]]
^ka-Q0895

**ka-Q0896 · Choose the form**

იმ____ გამო ვერ მჯერა.

That's why I cannot believe it.

Choices: მე / ის / შენ / ჩვენ

[[Georgian#^ka-Q0896-answer|Compare the answer]]
^ka-Q0896

**ka-Q0897 · Edit the changed sentence**

【მე】 ჩემი ძროხაა.

It is my cow.

[[Georgian#^ka-Q0897-answer|Compare the answer]]
^ka-Q0897

**ka-Q0898 · Build the sentence**

Arrange: ძროხაა. / ის / ჩემი

It is my cow.

[[Georgian#^ka-Q0898-answer|Compare the answer]]
^ka-Q0898

**ka-Q0899 · Write a translation**

Write this in Georgian: They're Tom's.

[[Georgian#^ka-Q0899-answer|Compare the answer]]
^ka-Q0899

**ka-Q0900 · Explain the grammar**

【ისინი】 არიან ტომის.

They're Tom's.

[[Georgian#^ka-Q0900-answer|Compare the answer]]
^ka-Q0900

**ka-Q0901 · Fill the gap**

ოდეს____ სწავლობთ ბიბლიოთეკაში?

Do you ever study in the library?

[[Georgian#^ka-Q0901-answer|Compare the answer]]
^ka-Q0901

**ka-Q0902 · Choose the form**

ოდეს____ სწავლობთ ბიბლიოთეკაში?

Do you ever study in the library?

Choices: ის / ჩვენ / შენ / მე

[[Georgian#^ka-Q0902-answer|Compare the answer]]
^ka-Q0902

**ka-Q0903 · Edit the changed sentence**

ტომი არ არ【მე】 კაპიტალისტი.

Tom isn't a capitalist.

[[Georgian#^ka-Q0903-answer|Compare the answer]]
^ka-Q0903

**ka-Q0904 · Build the sentence**

Arrange: კაპიტალისტი. / ტომი / არ / არის

Tom isn't a capitalist.

[[Georgian#^ka-Q0904-answer|Compare the answer]]
^ka-Q0904

**ka-Q0905 · Write a translation**

Write this in Georgian: I'm 25 years old.

[[Georgian#^ka-Q0905-answer|Compare the answer]]
^ka-Q0905

**ka-Q0906 · Explain the grammar**

25 წლ【ის】 ვარ.

I'm 25 years old.

[[Georgian#^ka-Q0906-answer|Compare the answer]]
^ka-Q0906

**ka-Q0907 · Fill the gap**

____ გაქვს ჩემი ნებართვა.

You have my permission.

[[Georgian#^ka-Q0907-answer|Compare the answer]]
^ka-Q0907

**ka-Q0908 · Choose the form**

____ გაქვს ჩემი ნებართვა.

You have my permission.

Choices: შენ / ის / ჩვენ / მე

[[Georgian#^ka-Q0908-answer|Compare the answer]]
^ka-Q0908

**ka-Q0909 · Edit the changed sentence**

【შენ】 ზომბი ვარ!

I'm a zombie!

[[Georgian#^ka-Q0909-answer|Compare the answer]]
^ka-Q0909

**ka-Q0910 · Build the sentence**

Arrange: ზომბი / ვარ! / მე

I'm a zombie!

[[Georgian#^ka-Q0910-answer|Compare the answer]]
^ka-Q0910

**ka-Q0911 · Write a translation**

Write this in Georgian: I am a student.

[[Georgian#^ka-Q0911-answer|Compare the answer]]
^ka-Q0911

**ka-Q0912 · Explain the grammar**

【მე】 მოსწავლე ვარ.

I am a student.

[[Georgian#^ka-Q0912-answer|Compare the answer]]
^ka-Q0912

**ka-Q0913 · Fill the gap**

აფრიკა მიგრაცი____ კონტინენტია.

Africa is a continent of migration.

[[Georgian#^ka-Q0913-answer|Compare the answer]]
^ka-Q0913

**ka-Q0914 · Choose the form**

აფრიკა მიგრაცი____ კონტინენტია.

Africa is a continent of migration.

Choices: ის / შენ / მე / ჩვენ

[[Georgian#^ka-Q0914-answer|Compare the answer]]
^ka-Q0914

**ka-Q0915 · Edit the changed sentence**

【შენ】 შენი მოქმედებების შესახებ ვსაუბრობ.

I'm talking about your actions.

[[Georgian#^ka-Q0915-answer|Compare the answer]]
^ka-Q0915

**ka-Q0916 · Build the sentence**

Arrange: ვსაუბრობ. / შენი / შესახებ / მოქმედებების / მე

I'm talking about your actions.

[[Georgian#^ka-Q0916-answer|Compare the answer]]
^ka-Q0916

**ka-Q0917 · Write a translation**

Write this in Georgian: I can't say anything bad about Tom.

[[Georgian#^ka-Q0917-answer|Compare the answer]]
^ka-Q0917

**ka-Q0918 · Explain the grammar**

【მე】 არ შემიძლია ვთქვა რამე ცუდი ტომის შესახებ.

I can't say anything bad about Tom.

[[Georgian#^ka-Q0918-answer|Compare the answer]]
^ka-Q0918

**ka-Q0919 · Fill the gap**

____ რიკარდო ვარ.

I'm Ricardo.

[[Georgian#^ka-Q0919-answer|Compare the answer]]
^ka-Q0919

**ka-Q0920 · Choose the form**

____ რიკარდო ვარ.

I'm Ricardo.

Choices: ის / მე / ჩვენ / შენ

[[Georgian#^ka-Q0920-answer|Compare the answer]]
^ka-Q0920

**ka-Q0921 · Edit the changed sentence**

【შენ】 მიყვარს ისტორიის სწავლა.

I like studying history.

[[Georgian#^ka-Q0921-answer|Compare the answer]]
^ka-Q0921

**ka-Q0922 · Build the sentence**

Arrange: მე / ისტორიის / მიყვარს / სწავლა.

I like studying history.

[[Georgian#^ka-Q0922-answer|Compare the answer]]
^ka-Q0922

**ka-Q0923 · Write a translation**

Write this in Georgian: After having anal sex with my girlfriend, we usually need to have a good wash.

[[Georgian#^ka-Q0923-answer|Compare the answer]]
^ka-Q0923

**ka-Q0924 · Explain the grammar**

ჩემს მეგობარ გოგონასთან ანალური სექს【ის】 შემდეგ, როგორც წესი, კარგი შხაპის მიღება გვჭირდება ხოლმე.

After having anal sex with my girlfriend, we usually need to have a good wash.

[[Georgian#^ka-Q0924-answer|Compare the answer]]
^ka-Q0924

**ka-Q0925 · Fill the gap**

____ ჯერ კიდევ ახალგაზრდაა.

He is still young.

[[Georgian#^ka-Q0925-answer|Compare the answer]]
^ka-Q0925

**ka-Q0926 · Choose the form**

____ ჯერ კიდევ ახალგაზრდაა.

He is still young.

Choices: შენ / ჩვენ / მე / ის

[[Georgian#^ka-Q0926-answer|Compare the answer]]
^ka-Q0926

**ka-Q0927 · Edit the changed sentence**

【შენ】 არ ვმღერი.

I do not sing.

[[Georgian#^ka-Q0927-answer|Compare the answer]]
^ka-Q0927

**ka-Q0928 · Build the sentence**

Arrange: არ / მე / ვმღერი.

I do not sing.

[[Georgian#^ka-Q0928-answer|Compare the answer]]
^ka-Q0928

**ka-Q0929 · Write a translation**

Write this in Georgian: I like chocolate.

[[Georgian#^ka-Q0929-answer|Compare the answer]]
^ka-Q0929

**ka-Q0930 · Explain the grammar**

【მე】 შოკოლადი მომწონს.

I like chocolate.

[[Georgian#^ka-Q0930-answer|Compare the answer]]
^ka-Q0930

**ka-Q0931 · Fill the gap**

ეს არ____ ჩემი ელექტრონული ფოსტის მისამართი.

This is my email address.

[[Georgian#^ka-Q0931-answer|Compare the answer]]
^ka-Q0931

**ka-Q0932 · Choose the form**

ეს არ____ ჩემი ელექტრონული ფოსტის მისამართი.

This is my email address.

Choices: ჩვენ / შენ / ის / მე

[[Georgian#^ka-Q0932-answer|Compare the answer]]
^ka-Q0932

**ka-Q0933 · Edit the changed sentence**

【მე】 მე გიყვარვარ?

Do you love me?

[[Georgian#^ka-Q0933-answer|Compare the answer]]
^ka-Q0933

**ka-Q0934 · Build the sentence**

Arrange: გიყვარვარ? / შენ / მე

Do you love me?

[[Georgian#^ka-Q0934-answer|Compare the answer]]
^ka-Q0934

**ka-Q0935 · Write a translation**

Write this in Georgian: I have to go to Boston with Tom.

[[Georgian#^ka-Q0935-answer|Compare the answer]]
^ka-Q0935

**ka-Q0936 · Explain the grammar**

【მე】 უნდა წავიდე ბოსტონში ტომთან ერთად.

I have to go to Boston with Tom.

[[Georgian#^ka-Q0936-answer|Compare the answer]]
^ka-Q0936

**ka-Q0937 · Fill the gap**

____ ქარხანაში ვმუშაობ.

I work in a factory.

[[Georgian#^ka-Q0937-answer|Compare the answer]]
^ka-Q0937

**ka-Q0938 · Choose the form**

____ ქარხანაში ვმუშაობ.

I work in a factory.

Choices: ის / მე / ჩვენ / შენ

[[Georgian#^ka-Q0938-answer|Compare the answer]]
^ka-Q0938

**ka-Q0939 · Edit the changed sentence**

კომპიუტერს თუ გამოიყენებ ინფორმაცი【მე】 შენახვას შეძლებ.

If you use a computer, you can retain information.

[[Georgian#^ka-Q0939-answer|Compare the answer]]
^ka-Q0939

**ka-Q0940 · Build the sentence**

Arrange: კომპიუტერს / გამოიყენებ / თუ / შეძლებ. / შენახვას / ინფორმაციის

If you use a computer, you can retain information.

[[Georgian#^ka-Q0940-answer|Compare the answer]]
^ka-Q0940

**ka-Q0941 · Write a translation**

Write this in Georgian: I've done this.

[[Georgian#^ka-Q0941-answer|Compare the answer]]
^ka-Q0941

**ka-Q0942 · Explain the grammar**

【მე】 ეს გავაკეთე.

I've done this.

[[Georgian#^ka-Q0942-answer|Compare the answer]]
^ka-Q0942

**ka-Q0943 · Fill the gap**

____ მივდივარ მეგობრის შესახვედრად.

I'm going to meet a friend.

[[Georgian#^ka-Q0943-answer|Compare the answer]]
^ka-Q0943

**ka-Q0944 · Choose the form**

____ მივდივარ მეგობრის შესახვედრად.

I'm going to meet a friend.

Choices: ჩვენ / შენ / ის / მე

[[Georgian#^ka-Q0944-answer|Compare the answer]]
^ka-Q0944

**ka-Q0945 · Edit the changed sentence**

არ【მე】 ტომი უფრო ახალგაზრდა ვიდრე შენ?

Is Tom younger than you?

[[Georgian#^ka-Q0945-answer|Compare the answer]]
^ka-Q0945

**ka-Q0946 · Build the sentence**

Arrange: ვიდრე / არის / ახალგაზრდა / უფრო / შენ? / ტომი

Is Tom younger than you?

[[Georgian#^ka-Q0946-answer|Compare the answer]]
^ka-Q0946

**ka-Q0947 · Write a translation**

Write this in Georgian: I am a student.

[[Georgian#^ka-Q0947-answer|Compare the answer]]
^ka-Q0947

**ka-Q0948 · Explain the grammar**

【მე】 სტუდენტი ვარ.

I am a student.

[[Georgian#^ka-Q0948-answer|Compare the answer]]
^ka-Q0948

**ka-Q0949 · Fill the gap**

____ არა ხარ ექიმი.

You're not a doctor.

[[Georgian#^ka-Q0949-answer|Compare the answer]]
^ka-Q0949

**ka-Q0950 · Choose the form**

____ არა ხარ ექიმი.

You're not a doctor.

Choices: ის / მე / ჩვენ / შენ

[[Georgian#^ka-Q0950-answer|Compare the answer]]
^ka-Q0950

**ka-Q0951 · Edit the changed sentence**

【შენ】 ვარ რიკარდო.

I'm Ricardo.

[[Georgian#^ka-Q0951-answer|Compare the answer]]
^ka-Q0951

**ka-Q0952 · Build the sentence**

Arrange: მე / რიკარდო. / ვარ

I'm Ricardo.

[[Georgian#^ka-Q0952-answer|Compare the answer]]
^ka-Q0952

**ka-Q0953 · Write a translation**

Write this in Georgian: She's pretty, but dangerous.

[[Georgian#^ka-Q0953-answer|Compare the answer]]
^ka-Q0953

**ka-Q0954 · Explain the grammar**

【ის】 ლამაზია, მაგრამ საშიში.

She's pretty, but dangerous.

[[Georgian#^ka-Q0954-answer|Compare the answer]]
^ka-Q0954

**ka-Q0955 · Fill the gap**

რამდენი____ წიგნი გაქვს.

You have few books.

[[Georgian#^ka-Q0955-answer|Compare the answer]]
^ka-Q0955

**ka-Q0956 · Choose the form**

რამდენი____ წიგნი გაქვს.

You have few books.

Choices: ის / შენ / მე / ჩვენ

[[Georgian#^ka-Q0956-answer|Compare the answer]]
^ka-Q0956

**ka-Q0957 · Edit the changed sentence**

【შენ】 არ მიყვარს ექიმები.

I don't like doctors.

[[Georgian#^ka-Q0957-answer|Compare the answer]]
^ka-Q0957

**ka-Q0958 · Build the sentence**

Arrange: არ / მიყვარს / მე / ექიმები.

I don't like doctors.

[[Georgian#^ka-Q0958-answer|Compare the answer]]
^ka-Q0958

**ka-Q0959 · Write a translation**

Write this in Georgian: What does a Sovietologist study?

[[Georgian#^ka-Q0959-answer|Compare the answer]]
^ka-Q0959

**ka-Q0960 · Explain the grammar**

რას შეისწავლ【ის】 სოვეტოლოგი?

What does a Sovietologist study?

[[Georgian#^ka-Q0960-answer|Compare the answer]]
^ka-Q0960

**ka-Q0961 · Fill the gap**

____ მინდა ვიყო ჟურნალისტი.

I want to become a journalist.

[[Georgian#^ka-Q0961-answer|Compare the answer]]
^ka-Q0961

**ka-Q0962 · Choose the form**

____ მინდა ვიყო ჟურნალისტი.

I want to become a journalist.

Choices: მე / შენ / ის / ჩვენ

[[Georgian#^ka-Q0962-answer|Compare the answer]]
^ka-Q0962

**ka-Q0963 · Edit the changed sentence**

【შენ】 წიგნის დავწერ.

I'll write a book.

[[Georgian#^ka-Q0963-answer|Compare the answer]]
^ka-Q0963

**ka-Q0964 · Build the sentence**

Arrange: დავწერ. / წიგნის / მე

I'll write a book.

[[Georgian#^ka-Q0964-answer|Compare the answer]]
^ka-Q0964

**ka-Q0965 · Write a translation**

Write this in Georgian: How is Tom going to Australia?

[[Georgian#^ka-Q0965-answer|Compare the answer]]
^ka-Q0965

**ka-Q0966 · Explain the grammar**

ტომი როგორ მიდ【ის】 ავსტრალიაში?

How is Tom going to Australia?

[[Georgian#^ka-Q0966-answer|Compare the answer]]
^ka-Q0966

**ka-Q0967 · Fill the gap**

გოგომ უარყოფ____ ნიშნად თავი გაიქნია, ბიჭი კი იდგა გაუნძრევლად.

The girl shook her head in refusal and the boy stood there shaking.

[[Georgian#^ka-Q0967-answer|Compare the answer]]
^ka-Q0967

**ka-Q0968 · Choose the form**

გოგომ უარყოფ____ ნიშნად თავი გაიქნია, ბიჭი კი იდგა გაუნძრევლად.

The girl shook her head in refusal and the boy stood there shaking.

Choices: ჩვენ / ის / მე / შენ

[[Georgian#^ka-Q0968-answer|Compare the answer]]
^ka-Q0968

**ka-Q0969 · Edit the changed sentence**

【შენ】 ცხოვრებს ვცხოვრობ.

I live life.

[[Georgian#^ka-Q0969-answer|Compare the answer]]
^ka-Q0969

**ka-Q0970 · Build the sentence**

Arrange: ვცხოვრობ. / ცხოვრებს / მე

I live life.

[[Georgian#^ka-Q0970-answer|Compare the answer]]
^ka-Q0970

**ka-Q0971 · Write a translation**

Write this in Georgian: I think Tom will make breakfast.

[[Georgian#^ka-Q0971-answer|Compare the answer]]
^ka-Q0971

**ka-Q0972 · Explain the grammar**

【მე】 ვფიქრობ ტომი მომზადებს საუზმეს.

I think Tom will make breakfast.

[[Georgian#^ka-Q0972-answer|Compare the answer]]
^ka-Q0972

**ka-Q0973 · Fill the gap**

____ ძალიან მომწონს ძაღლები.

I like dogs very much.

[[Georgian#^ka-Q0973-answer|Compare the answer]]
^ka-Q0973

**ka-Q0974 · Choose the form**

____ ძალიან მომწონს ძაღლები.

I like dogs very much.

Choices: ის / ჩვენ / მე / შენ

[[Georgian#^ka-Q0974-answer|Compare the answer]]
^ka-Q0974

**ka-Q0975 · Edit the changed sentence**

არავინ იც【მე】 რა მოხდება.

No one knows what'll happen.

[[Georgian#^ka-Q0975-answer|Compare the answer]]
^ka-Q0975

**ka-Q0976 · Build the sentence**

Arrange: არავინ / იცის / მოხდება. / რა

No one knows what'll happen.

[[Georgian#^ka-Q0976-answer|Compare the answer]]
^ka-Q0976

**ka-Q0977 · Write a translation**

Write this in Georgian: The book is on the table.

[[Georgian#^ka-Q0977-answer|Compare the answer]]
^ka-Q0977

**ka-Q0978 · Explain the grammar**

წიგნი მაგიდაზე არ【ის】.

The book is on the table.

[[Georgian#^ka-Q0978-answer|Compare the answer]]
^ka-Q0978

**ka-Q0979 · Fill the gap**

წყალი ძალიან ცხელი არ____.

The water's very hot.

[[Georgian#^ka-Q0979-answer|Compare the answer]]
^ka-Q0979

**ka-Q0980 · Choose the form**

წყალი ძალიან ცხელი არ____.

The water's very hot.

Choices: ის / ჩვენ / შენ / მე

[[Georgian#^ka-Q0980-answer|Compare the answer]]
^ka-Q0980

**ka-Q0981 · Edit the changed sentence**

სად არ【მე】 საჭმელი?

Where is the food?

[[Georgian#^ka-Q0981-answer|Compare the answer]]
^ka-Q0981

**ka-Q0982 · Build the sentence**

Arrange: არის / საჭმელი? / სად

Where is the food?

[[Georgian#^ka-Q0982-answer|Compare the answer]]
^ka-Q0982

**ka-Q0983 · Write a translation**

Write this in Georgian: I'm the man of the house.

[[Georgian#^ka-Q0983-answer|Compare the answer]]
^ka-Q0983

**ka-Q0984 · Explain the grammar**

【მე】 სახლის კაცი ვარ.

I'm the man of the house.

[[Georgian#^ka-Q0984-answer|Compare the answer]]
^ka-Q0984

**ka-Q0985 · Fill the gap**

____ წყალს ვსვამ.

I drink the water.

[[Georgian#^ka-Q0985-answer|Compare the answer]]
^ka-Q0985

**ka-Q0986 · Choose the form**

____ წყალს ვსვამ.

I drink the water.

Choices: ჩვენ / ის / შენ / მე

[[Georgian#^ka-Q0986-answer|Compare the answer]]
^ka-Q0986

**ka-Q0987 · Edit the changed sentence**

【შენ】 იქ ლამაზი ჩანჩქერი დავინახე.

I saw a beautiful waterfall there.

[[Georgian#^ka-Q0987-answer|Compare the answer]]
^ka-Q0987

**ka-Q0988 · Build the sentence**

Arrange: ჩანჩქერი / დავინახე. / ლამაზი / მე / იქ

I saw a beautiful waterfall there.

[[Georgian#^ka-Q0988-answer|Compare the answer]]
^ka-Q0988

**ka-Q0989 · Write a translation**

Write this in Georgian: I'm in the tennis club.

[[Georgian#^ka-Q0989-answer|Compare the answer]]
^ka-Q0989

**ka-Q0990 · Explain the grammar**

【მე】 ვარ ჩოგბურთის კლუბში.

I'm in the tennis club.

[[Georgian#^ka-Q0990-answer|Compare the answer]]
^ka-Q0990

**ka-Q0991 · Fill the gap**

____ მიყვარს შენი ჩანთა.

I love your bag.

[[Georgian#^ka-Q0991-answer|Compare the answer]]
^ka-Q0991

**ka-Q0992 · Choose the form**

____ მიყვარს შენი ჩანთა.

I love your bag.

Choices: ჩვენ / ის / მე / შენ

[[Georgian#^ka-Q0992-answer|Compare the answer]]
^ka-Q0992

**ka-Q0993 · Edit the changed sentence**

მან თავ【მე】 მოკვლა სცადა.

She attempted suicide.

[[Georgian#^ka-Q0993-answer|Compare the answer]]
^ka-Q0993

**ka-Q0994 · Build the sentence**

Arrange: მოკვლა / მან / თავის / სცადა.

She attempted suicide.

[[Georgian#^ka-Q0994-answer|Compare the answer]]
^ka-Q0994

**ka-Q0995 · Write a translation**

Write this in Georgian: I think that we're next.

[[Georgian#^ka-Q0995-answer|Compare the answer]]
^ka-Q0995

**ka-Q0996 · Explain the grammar**

【მე】 ვფიქრობ ჩვენ ვართ შემდეგი.

I think that we're next.

[[Georgian#^ka-Q0996-answer|Compare the answer]]
^ka-Q0996

**ka-Q0997 · Fill the gap**

ეხლა ____ თქვენ გეტყვით სიმართლეს.

Now I'll tell you the truth.

[[Georgian#^ka-Q0997-answer|Compare the answer]]
^ka-Q0997

**ka-Q0998 · Choose the form**

ეხლა ____ თქვენ გეტყვით სიმართლეს.

Now I'll tell you the truth.

Choices: ის / მე / შენ / ჩვენ

[[Georgian#^ka-Q0998-answer|Compare the answer]]
^ka-Q0998

**ka-Q0999 · Edit the changed sentence**

უფროსმა მომცა 【შენ】 ეს ხელფასი.

The boss gave me this salary.

[[Georgian#^ka-Q0999-answer|Compare the answer]]
^ka-Q0999

**ka-Q1000 · Build the sentence**

Arrange: მომცა / ეს / ხელფასი. / უფროსმა / მე

The boss gave me this salary.

[[Georgian#^ka-Q1000-answer|Compare the answer]]
^ka-Q1000


### Present copula · 50 questions

**ka-Q0051 · Edit the changed sentence**

ესენი 【ვარ】 სტუდენტები.

These are students.

[[Georgian#^ka-Q0051-answer|Compare the answer]]
^ka-Q0051

**ka-Q0052 · Build the sentence**

Arrange: არიან / ესენი / სტუდენტები.

These are students.

[[Georgian#^ka-Q0052-answer|Compare the answer]]
^ka-Q0052

**ka-Q0053 · Write a translation**

Write this in Georgian: Is Tom older than you?

[[Georgian#^ka-Q0053-answer|Compare the answer]]
^ka-Q0053

**ka-Q0054 · Explain the grammar**

【არის】 ტომი უფრო უფროსი ვიდრე შენ?

Is Tom older than you?

[[Georgian#^ka-Q0054-answer|Compare the answer]]
^ka-Q0054

**ka-Q0055 · Fill the gap**

ორივეც კარგი მასწავლებლები ____.

They are both good teachers.

[[Georgian#^ka-Q0055-answer|Compare the answer]]
^ka-Q0055

**ka-Q0056 · Choose the form**

ორივეც კარგი მასწავლებლები ____.

They are both good teachers.

Choices: არიან / ვარ / ხარ / არის

[[Georgian#^ka-Q0056-answer|Compare the answer]]
^ka-Q0056

**ka-Q0057 · Edit the changed sentence**

【ვარ】 ტომი უფრო ახალგაზრდა ან უფრო მოხუცი ვიდრე შენ?

Is Tom younger or older than you?

[[Georgian#^ka-Q0057-answer|Compare the answer]]
^ka-Q0057

**ka-Q0058 · Build the sentence**

Arrange: უფრო / ან / მოხუცი / ვიდრე / არის / შენ? / უფრო / ტომი / ახალგაზრდა

Is Tom younger or older than you?

[[Georgian#^ka-Q0058-answer|Compare the answer]]
^ka-Q0058

**ka-Q0059 · Write a translation**

Write this in Georgian: I come from America.

[[Georgian#^ka-Q0059-answer|Compare the answer]]
^ka-Q0059

**ka-Q0060 · Explain the grammar**

მე ამერიკიდან 【ვარ】.

I come from America.

[[Georgian#^ka-Q0060-answer|Compare the answer]]
^ka-Q0060

**ka-Q0061 · Fill the gap**

შენ ძალიან დაბალი ____.

You're very short.

[[Georgian#^ka-Q0061-answer|Compare the answer]]
^ka-Q0061

**ka-Q0062 · Choose the form**

შენ ძალიან დაბალი ____.

You're very short.

Choices: ვარ / ხარ / ვართ / არის

[[Georgian#^ka-Q0062-answer|Compare the answer]]
^ka-Q0062

**ka-Q0063 · Edit the changed sentence**

მე სკოლაში მივდი【ხარ】.

I go to school.

[[Georgian#^ka-Q0063-answer|Compare the answer]]
^ka-Q0063

**ka-Q0064 · Build the sentence**

Arrange: სკოლაში / მე / მივდივარ.

I go to school.

[[Georgian#^ka-Q0064-answer|Compare the answer]]
^ka-Q0064

**ka-Q0065 · Write a translation**

Write this in Georgian: I'm 45 years old.

[[Georgian#^ka-Q0065-answer|Compare the answer]]
^ka-Q0065

**ka-Q0066 · Explain the grammar**

45 წლის 【ვარ】.

I'm 45 years old.

[[Georgian#^ka-Q0066-answer|Compare the answer]]
^ka-Q0066

**ka-Q0067 · Fill the gap**

ვინ ____ უფრო დაბალი, შენ თუ ტომი?

Who's shorter, you or Tom?

[[Georgian#^ka-Q0067-answer|Compare the answer]]
^ka-Q0067

**ka-Q0068 · Choose the form**

ვინ ____ უფრო დაბალი, შენ თუ ტომი?

Who's shorter, you or Tom?

Choices: ვართ / არის / ხარ / ვარ

[[Georgian#^ka-Q0068-answer|Compare the answer]]
^ka-Q0068

**ka-Q0069 · Edit the changed sentence**

მე შენს მხარეს 【ხარ】.

I'm on your side.

[[Georgian#^ka-Q0069-answer|Compare the answer]]
^ka-Q0069

**ka-Q0070 · Build the sentence**

Arrange: მე / მხარეს / შენს / ვარ.

I'm on your side.

[[Georgian#^ka-Q0070-answer|Compare the answer]]
^ka-Q0070

**ka-Q0071 · Write a translation**

Write this in Georgian: The water's very hot.

[[Georgian#^ka-Q0071-answer|Compare the answer]]
^ka-Q0071

**ka-Q0072 · Explain the grammar**

წყალი 【არის】 ძალიან ცხელი.

The water's very hot.

[[Georgian#^ka-Q0072-answer|Compare the answer]]
^ka-Q0072

**ka-Q0073 · Fill the gap**

სოფელში ძროხა ____.

There is a cow in the village.

[[Georgian#^ka-Q0073-answer|Compare the answer]]
^ka-Q0073

**ka-Q0074 · Choose the form**

სოფელში ძროხა ____.

There is a cow in the village.

Choices: ვარ / ვართ / არის / ხარ

[[Georgian#^ka-Q0074-answer|Compare the answer]]
^ka-Q0074

**ka-Q0075 · Edit the changed sentence**

ძალიან ბედნიერი 【ხარ】 ჯორჯიაში.

I am very happy in Georgia.

[[Georgian#^ka-Q0075-answer|Compare the answer]]
^ka-Q0075

**ka-Q0076 · Build the sentence**

Arrange: ბედნიერი / ძალიან / ვარ / ჯორჯიაში.

I am very happy in Georgia.

[[Georgian#^ka-Q0076-answer|Compare the answer]]
^ka-Q0076

**ka-Q0077 · Write a translation**

Write this in Georgian: I am from Egypt.

[[Georgian#^ka-Q0077-answer|Compare the answer]]
^ka-Q0077

**ka-Q0078 · Explain the grammar**

მე ეგვიპტედან 【ვარ】.

I am from Egypt.

[[Georgian#^ka-Q0078-answer|Compare the answer]]
^ka-Q0078

**ka-Q0079 · Fill the gap**

მე ____ ჟურნალისტი.

I am a journalist.

[[Georgian#^ka-Q0079-answer|Compare the answer]]
^ka-Q0079

**ka-Q0080 · Choose the form**

მე ____ ჟურნალისტი.

I am a journalist.

Choices: ვარ / არის / ვართ / ხარ

[[Georgian#^ka-Q0080-answer|Compare the answer]]
^ka-Q0080

**ka-Q0081 · Edit the changed sentence**

უკაცრავად. თქვენ ის პიროვნება 【ვარ】?

Excuse me. Are you that person?

[[Georgian#^ka-Q0081-answer|Compare the answer]]
^ka-Q0081

**ka-Q0082 · Build the sentence**

Arrange: ხართ? / პიროვნება / თქვენ / უკაცრავად. / ის

Excuse me. Are you that person?

[[Georgian#^ka-Q0082-answer|Compare the answer]]
^ka-Q0082

**ka-Q0083 · Write a translation**

Write this in Georgian: This is a girl.

[[Georgian#^ka-Q0083-answer|Compare the answer]]
^ka-Q0083

**ka-Q0084 · Explain the grammar**

ეს 【არის】 გოგო.

This is a girl.

[[Georgian#^ka-Q0084-answer|Compare the answer]]
^ka-Q0084

**ka-Q0085 · Fill the gap**

აი შენი ძაღლი. სად ____ ჩემი?

Here is your dog. Where is mine?

[[Georgian#^ka-Q0085-answer|Compare the answer]]
^ka-Q0085

**ka-Q0086 · Choose the form**

აი შენი ძაღლი. სად ____ ჩემი?

Here is your dog. Where is mine?

Choices: ხარ / ვარ / ვართ / არის

[[Georgian#^ka-Q0086-answer|Compare the answer]]
^ka-Q0086

**ka-Q0087 · Edit the changed sentence**

მე ცხრამეტი წლის 【ხარ】.

I am 19 years old.

[[Georgian#^ka-Q0087-answer|Compare the answer]]
^ka-Q0087

**ka-Q0088 · Build the sentence**

Arrange: წლის / ვარ. / ცხრამეტი / მე

I am 19 years old.

[[Georgian#^ka-Q0088-answer|Compare the answer]]
^ka-Q0088

**ka-Q0089 · Write a translation**

Write this in Georgian: Does he love me?

[[Georgian#^ka-Q0089-answer|Compare the answer]]
^ka-Q0089

**ka-Q0090 · Explain the grammar**

მას მე უყვარ【ვარ】?

Does he love me?

[[Georgian#^ka-Q0090-answer|Compare the answer]]
^ka-Q0090

**ka-Q0091 · Fill the gap**

ძალიან დაბალი ____.

You're very short.

[[Georgian#^ka-Q0091-answer|Compare the answer]]
^ka-Q0091

**ka-Q0092 · Choose the form**

ძალიან დაბალი ____.

You're very short.

Choices: ხართ / არის / ვარ / ხარ

[[Georgian#^ka-Q0092-answer|Compare the answer]]
^ka-Q0092

**ka-Q0093 · Edit the changed sentence**

დიახ, მე საპოროდან 【ხარ】.

Yes, I am from Sapporo.

[[Georgian#^ka-Q0093-answer|Compare the answer]]
^ka-Q0093

**ka-Q0094 · Build the sentence**

Arrange: ვარ. / დიახ, / მე / საპოროდან

Yes, I am from Sapporo.

[[Georgian#^ka-Q0094-answer|Compare the answer]]
^ka-Q0094

**ka-Q0095 · Write a translation**

Write this in Georgian: Winter swimming isn't dangerous for healthy people.

[[Georgian#^ka-Q0095-answer|Compare the answer]]
^ka-Q0095

**ka-Q0096 · Explain the grammar**

ზამთარში ცურვა არ 【არის】 საშიში ჯანმრთელი ხალხისთვის.

Winter swimming isn't dangerous for healthy people.

[[Georgian#^ka-Q0096-answer|Compare the answer]]
^ka-Q0096

**ka-Q0097 · Fill the gap**

მე არ ____ ხნიერი.

I'm not old.

[[Georgian#^ka-Q0097-answer|Compare the answer]]
^ka-Q0097

**ka-Q0098 · Choose the form**

მე არ ____ ხნიერი.

I'm not old.

Choices: ვართ / ხარ / ვარ / არის

[[Georgian#^ka-Q0098-answer|Compare the answer]]
^ka-Q0098

**ka-Q0099 · Edit the changed sentence**

ემილი და მელანი ინგლისელი 【ვარ】.

Emily and Melanie are English.

[[Georgian#^ka-Q0099-answer|Compare the answer]]
^ka-Q0099

**ka-Q0100 · Build the sentence**

Arrange: ემილი / და / არიან. / ინგლისელი / მელანი

Emily and Melanie are English.

[[Georgian#^ka-Q0100-answer|Compare the answer]]
^ka-Q0100


### Negation · 50 questions

**ka-Q0101 · Write a translation**

Write this in Georgian: I just don't know what to say.

[[Georgian#^ka-Q0101-answer|Compare the answer]]
^ka-Q0101

**ka-Q0102 · Explain the grammar**

უბრალოდ 【არ】 ვიცი რა უნდა ვთქვა.

I just don't know what to say.

[[Georgian#^ka-Q0102-answer|Compare the answer]]
^ka-Q0102

**ka-Q0103 · Fill the gap**

მე დავიფიცე, რომ არასოდეს აღ____ დაველაპარაკები.

I vowed that I would never speak to her again.

[[Georgian#^ka-Q0103-answer|Compare the answer]]
^ka-Q0103

**ka-Q0104 · Choose the form**

მე დავიფიცე, რომ არასოდეს აღ____ დაველაპარაკები.

I vowed that I would never speak to her again.

Choices: ვერ / არ

[[Georgian#^ka-Q0104-answer|Compare the answer]]
^ka-Q0104

**ka-Q0105 · Edit the changed sentence**

ამ ქალაქში 【ვერ】 ვცხოვრობ.

I don't live in this city.

[[Georgian#^ka-Q0105-answer|Compare the answer]]
^ka-Q0105

**ka-Q0106 · Build the sentence**

Arrange: არ / ამ / ქალაქში / ვცხოვრობ.

I don't live in this city.

[[Georgian#^ka-Q0106-answer|Compare the answer]]
^ka-Q0106

**ka-Q0107 · Write a translation**

Write this in Georgian: Mennad won't get mad.

[[Georgian#^ka-Q0107-answer|Compare the answer]]
^ka-Q0107

**ka-Q0108 · Explain the grammar**

მენადი 【არ】 გაგიჟდება.

Mennad won't get mad.

[[Georgian#^ka-Q0108-answer|Compare the answer]]
^ka-Q0108

**ka-Q0109 · Fill the gap**

დათვმა არცერთი ქვა ____ დატოვა ამოუტრიალებელი მსუქალი ხოჭოების ძებნისას.

The bear left no stone unturned in his search for fat bugs under the rocks.

[[Georgian#^ka-Q0109-answer|Compare the answer]]
^ka-Q0109

**ka-Q0110 · Choose the form**

დათვმა არცერთი ქვა ____ დატოვა ამოუტრიალებელი მსუქალი ხოჭოების ძებნისას.

The bear left no stone unturned in his search for fat bugs under the rocks.

Choices: ვერ / არ

[[Georgian#^ka-Q0110-answer|Compare the answer]]
^ka-Q0110

**ka-Q0111 · Edit the changed sentence**

წიგნმა "ჩამითრია" და შენი ხმა 【არ】 გავიგე.

I was absorbed in a book and didn't hear you call.

[[Georgian#^ka-Q0111-answer|Compare the answer]]
^ka-Q0111

**ka-Q0112 · Build the sentence**

Arrange: "ჩამითრია" / ვერ / შენი / და / ხმა / წიგნმა / გავიგე.

I was absorbed in a book and didn't hear you call.

[[Georgian#^ka-Q0112-answer|Compare the answer]]
^ka-Q0112

**ka-Q0113 · Write a translation**

Write this in Georgian: He doesn't want to work in a factory.

[[Georgian#^ka-Q0113-answer|Compare the answer]]
^ka-Q0113

**ka-Q0114 · Explain the grammar**

【არ】 უნდა ქარხანაში მუშაობა.

He doesn't want to work in a factory.

[[Georgian#^ka-Q0114-answer|Compare the answer]]
^ka-Q0114

**ka-Q0115 · Fill the gap**

____ მინდა, რომ თომი ჩემი პატრონი იყოს, რადგან ის იდიოტია.

I don't want Tom to be my boss because he is an idiot.

[[Georgian#^ka-Q0115-answer|Compare the answer]]
^ka-Q0115

**ka-Q0116 · Choose the form**

____ მინდა, რომ თომი ჩემი პატრონი იყოს, რადგან ის იდიოტია.

I don't want Tom to be my boss because he is an idiot.

Choices: ვერ / არ

[[Georgian#^ka-Q0116-answer|Compare the answer]]
^ka-Q0116

**ka-Q0117 · Edit the changed sentence**

ტუალეტის ქაღალდი 【ვერ】 იყო.

There was no toilet paper.

[[Georgian#^ka-Q0117-answer|Compare the answer]]
^ka-Q0117

**ka-Q0118 · Build the sentence**

Arrange: იყო. / ქაღალდი / არ / ტუალეტის

There was no toilet paper.

[[Georgian#^ka-Q0118-answer|Compare the answer]]
^ka-Q0118

**ka-Q0119 · Write a translation**

Write this in Georgian: I don't want to go outside this afternoon.

[[Georgian#^ka-Q0119-answer|Compare the answer]]
^ka-Q0119

**ka-Q0120 · Explain the grammar**

სახლიდან გასხვლა 【არ】 მინდა ამ საღამოს.

I don't want to go outside this afternoon.

[[Georgian#^ka-Q0120-answer|Compare the answer]]
^ka-Q0120

**ka-Q0121 · Fill the gap**

მე ____ მაქვს ალტერნატივა.

I have no alternatives.

[[Georgian#^ka-Q0121-answer|Compare the answer]]
^ka-Q0121

**ka-Q0122 · Choose the form**

მე ____ მაქვს ალტერნატივა.

I have no alternatives.

Choices: არ / ვერ

[[Georgian#^ka-Q0122-answer|Compare the answer]]
^ka-Q0122

**ka-Q0123 · Edit the changed sentence**

მე შენს უკან ვ【ვერ】.

I'm behind you.

[[Georgian#^ka-Q0123-answer|Compare the answer]]
^ka-Q0123

**ka-Q0124 · Build the sentence**

Arrange: შენს / უკან / ვარ. / მე

I'm behind you.

[[Georgian#^ka-Q0124-answer|Compare the answer]]
^ka-Q0124

**ka-Q0125 · Write a translation**

Write this in Georgian: I'm not a dictator.

[[Georgian#^ka-Q0125-answer|Compare the answer]]
^ka-Q0125

**ka-Q0126 · Explain the grammar**

მე არა ვ【არ】 დიქტატორი.

I'm not a dictator.

[[Georgian#^ka-Q0126-answer|Compare the answer]]
^ka-Q0126

**ka-Q0127 · Fill the gap**

პედროს ____ ჰყავს დები.

Pedro has no sisters.

[[Georgian#^ka-Q0127-answer|Compare the answer]]
^ka-Q0127

**ka-Q0128 · Choose the form**

პედროს ____ ჰყავს დები.

Pedro has no sisters.

Choices: არ / ვერ

[[Georgian#^ka-Q0128-answer|Compare the answer]]
^ka-Q0128

**ka-Q0129 · Edit the changed sentence**

მე ლამაზი ვ【ვერ】?

Am I pretty?

[[Georgian#^ka-Q0129-answer|Compare the answer]]
^ka-Q0129

**ka-Q0130 · Build the sentence**

Arrange: ლამაზი / მე / ვარ?

Am I pretty?

[[Georgian#^ka-Q0130-answer|Compare the answer]]
^ka-Q0130

**ka-Q0131 · Write a translation**

Write this in Georgian: Tom doesn't eat dessert.

[[Georgian#^ka-Q0131-answer|Compare the answer]]
^ka-Q0131

**ka-Q0132 · Explain the grammar**

თომი დესერტს 【არ】 ჭამს.

Tom doesn't eat dessert.

[[Georgian#^ka-Q0132-answer|Compare the answer]]
^ka-Q0132

**ka-Q0133 · Fill the gap**

ჩემი სინდისი ____ არის სუფთა.

My conscience is not clean.

[[Georgian#^ka-Q0133-answer|Compare the answer]]
^ka-Q0133

**ka-Q0134 · Choose the form**

ჩემი სინდისი ____ არის სუფთა.

My conscience is not clean.

Choices: ვერ / არ

[[Georgian#^ka-Q0134-answer|Compare the answer]]
^ka-Q0134

**ka-Q0135 · Edit the changed sentence**

ბებიაჩემს 【ვერ】 აქვს ინტერნეტი.

My grandma doesn't have the internet.

[[Georgian#^ka-Q0135-answer|Compare the answer]]
^ka-Q0135

**ka-Q0136 · Build the sentence**

Arrange: არ / ბებიაჩემს / ინტერნეტი. / აქვს

My grandma doesn't have the internet.

[[Georgian#^ka-Q0136-answer|Compare the answer]]
^ka-Q0136

**ka-Q0137 · Write a translation**

Write this in Georgian: It's useless to keep on thinking any more.

[[Georgian#^ka-Q0137-answer|Compare the answer]]
^ka-Q0137

**ka-Q0138 · Explain the grammar**

აზრი აღ【არ】 აქვს ამაზე ფიქრს.

It's useless to keep on thinking any more.

[[Georgian#^ka-Q0138-answer|Compare the answer]]
^ka-Q0138

**ka-Q0139 · Fill the gap**

მე ____ შეასრულა ტომ.

I couldn't stop Tom.

[[Georgian#^ka-Q0139-answer|Compare the answer]]
^ka-Q0139

**ka-Q0140 · Choose the form**

მე ____ შეასრულა ტომ.

I couldn't stop Tom.

Choices: არ / ვერ

[[Georgian#^ka-Q0140-answer|Compare the answer]]
^ka-Q0140

**ka-Q0141 · Edit the changed sentence**

მე ცალთვალა ვ【ვერ】.

I'm one-eyed.

[[Georgian#^ka-Q0141-answer|Compare the answer]]
^ka-Q0141

**ka-Q0142 · Build the sentence**

Arrange: ცალთვალა / მე / ვარ.

I'm one-eyed.

[[Georgian#^ka-Q0142-answer|Compare the answer]]
^ka-Q0142

**ka-Q0143 · Write a translation**

Write this in Georgian: I'm a member of the tennis club.

[[Georgian#^ka-Q0143-answer|Compare the answer]]
^ka-Q0143

**ka-Q0144 · Explain the grammar**

მე ამ ტენის კლუბის წევრი ვ【არ】.

I'm a member of the tennis club.

[[Georgian#^ka-Q0144-answer|Compare the answer]]
^ka-Q0144

**ka-Q0145 · Fill the gap**

ხილი და ბოსტნეული ჯანმრთელი არიან, მაგრამ ჩვენ ____ ვიცით რატომ.

Fruit and vegetables are good for your health, but we don't know why.

[[Georgian#^ka-Q0145-answer|Compare the answer]]
^ka-Q0145

**ka-Q0146 · Choose the form**

ხილი და ბოსტნეული ჯანმრთელი არიან, მაგრამ ჩვენ ____ ვიცით რატომ.

Fruit and vegetables are good for your health, but we don't know why.

Choices: ვერ / არ

[[Georgian#^ka-Q0146-answer|Compare the answer]]
^ka-Q0146

**ka-Q0147 · Edit the changed sentence**

მას მე 【ვერ】 უყვარვარ.

He doesn't love me.

[[Georgian#^ka-Q0147-answer|Compare the answer]]
^ka-Q0147

**ka-Q0148 · Build the sentence**

Arrange: მე / არ / უყვარვარ. / მას

He doesn't love me.

[[Georgian#^ka-Q0148-answer|Compare the answer]]
^ka-Q0148

**ka-Q0149 · Write a translation**

Write this in Georgian: I don't want Tom to be my boss.

[[Georgian#^ka-Q0149-answer|Compare the answer]]
^ka-Q0149

**ka-Q0150 · Explain the grammar**

【არ】 მინდა, რომ თომი ჩემი პატრონი იყოს.

I don't want Tom to be my boss.

[[Georgian#^ka-Q0150-answer|Compare the answer]]
^ka-Q0150


### Demonstratives · 50 questions

**ka-Q0151 · Fill the gap**

გელ____ თქვა, რომ მამა წავიდა ქალაქში.

Gela said that Father went into the city.

[[Georgian#^ka-Q0151-answer|Compare the answer]]
^ka-Q0151

**ka-Q0152 · Choose the form**

გელ____ თქვა, რომ მამა წავიდა ქალაქში.

Gela said that Father went into the city.

Choices: ამ / ეს / ის / იმ

[[Georgian#^ka-Q0152-answer|Compare the answer]]
^ka-Q0152

**ka-Q0153 · Edit the changed sentence**

ჩვ【ის】 სკოლას ჯამში აქვს ოცდაოთხი კლასი.

Our school has twenty-four classes in all.

[[Georgian#^ka-Q0153-answer|Compare the answer]]
^ka-Q0153

**ka-Q0154 · Build the sentence**

Arrange: ჩვეს / ჯამში / კლასი. / აქვს / ოცდაოთხი / სკოლას

Our school has twenty-four classes in all.

[[Georgian#^ka-Q0154-answer|Compare the answer]]
^ka-Q0154

**ka-Q0155 · Write a translation**

Write this in Georgian: Labor created man.

[[Georgian#^ka-Q0155-answer|Compare the answer]]
^ka-Q0155

**ka-Q0156 · Explain the grammar**

შრომ【ამ】 შექმნა ადამიანი.

Labor created man.

[[Georgian#^ka-Q0156-answer|Compare the answer]]
^ka-Q0156

**ka-Q0157 · Fill the gap**

რა ფერ____ იყო ჰენრი IV თეთრი ცხენი?

What colour was Henri IV's white horse?

[[Georgian#^ka-Q0157-answer|Compare the answer]]
^ka-Q0157

**ka-Q0158 · Choose the form**

რა ფერ____ იყო ჰენრი IV თეთრი ცხენი?

What colour was Henri IV's white horse?

Choices: ამ / იმ / ის / ეს

[[Georgian#^ka-Q0158-answer|Compare the answer]]
^ka-Q0158

**ka-Q0159 · Edit the changed sentence**

【ის】 ჩემი ძაღლია.

This is my dog.

[[Georgian#^ka-Q0159-answer|Compare the answer]]
^ka-Q0159

**ka-Q0160 · Build the sentence**

Arrange: ძაღლია. / ეს / ჩემი

This is my dog.

[[Georgian#^ka-Q0160-answer|Compare the answer]]
^ka-Q0160

**ka-Q0161 · Write a translation**

Write this in Georgian: My grandfather planted this tree.

[[Georgian#^ka-Q0161-answer|Compare the answer]]
^ka-Q0161

**ka-Q0162 · Explain the grammar**

【ეს】 ხე ჩემმა ბაბუამ დარგო.

My grandfather planted this tree.

[[Georgian#^ka-Q0162-answer|Compare the answer]]
^ka-Q0162

**ka-Q0163 · Fill the gap**

ტომს უჭირს გაუმკლავდ____ ფაქტს, რომ მისმა შვილმა თავი მოიკლა.

Tom is having trouble coping with the fact that his son committed suicide.

[[Georgian#^ka-Q0163-answer|Compare the answer]]
^ka-Q0163

**ka-Q0164 · Choose the form**

ტომს უჭირს გაუმკლავდ____ ფაქტს, რომ მისმა შვილმა თავი მოიკლა.

Tom is having trouble coping with the fact that his son committed suicide.

Choices: ეს / ამ / ის / იმ

[[Georgian#^ka-Q0164-answer|Compare the answer]]
^ka-Q0164

**ka-Q0165 · Edit the changed sentence**

სილამაზე რეკომენდაცი【ეს】 წერილია, რომლის იგნორირებაც თითქმის შეუძლებელია.

Beauty is a letter of recommendation which it is almost impossible to ignore.

[[Georgian#^ka-Q0165-answer|Compare the answer]]
^ka-Q0165

**ka-Q0166 · Build the sentence**

Arrange: რომლის / იგნორირებაც / რეკომენდაციის / შეუძლებელია. / წერილია, / თითქმის / სილამაზე

Beauty is a letter of recommendation which it is almost impossible to ignore.

[[Georgian#^ka-Q0166-answer|Compare the answer]]
^ka-Q0166

**ka-Q0167 · Write a translation**

Write this in Georgian: This is my cow.

[[Georgian#^ka-Q0167-answer|Compare the answer]]
^ka-Q0167

**ka-Q0168 · Explain the grammar**

【ეს】 ჩემი ძროხაა.

This is my cow.

[[Georgian#^ka-Q0168-answer|Compare the answer]]
^ka-Q0168

**ka-Q0169 · Fill the gap**

ტომმა თქვა ____ და მისი ცოლი უნდა წავიდნენ ავსტრალიაში გაზაფხულზე.

Tom said he and his wife would go to Australia in the spring.

[[Georgian#^ka-Q0169-answer|Compare the answer]]
^ka-Q0169

**ka-Q0170 · Choose the form**

ტომმა თქვა ____ და მისი ცოლი უნდა წავიდნენ ავსტრალიაში გაზაფხულზე.

Tom said he and his wife would go to Australia in the spring.

Choices: იმ / ეს / ის / ამ

[[Georgian#^ka-Q0170-answer|Compare the answer]]
^ka-Q0170

**ka-Q0171 · Edit the changed sentence**

მ【ეს】 კომპანიაში არასოდეს მოიწყენ.

You will never get bored in her company.

[[Georgian#^ka-Q0171-answer|Compare the answer]]
^ka-Q0171

**ka-Q0172 · Build the sentence**

Arrange: კომპანიაში / მოიწყენ. / მის / არასოდეს

You will never get bored in her company.

[[Georgian#^ka-Q0172-answer|Compare the answer]]
^ka-Q0172

**ka-Q0173 · Write a translation**

Write this in Georgian: The girl is drinking tea.

[[Georgian#^ka-Q0173-answer|Compare the answer]]
^ka-Q0173

**ka-Q0174 · Explain the grammar**

გოგო ჩა【ის】 სვამს.

The girl is drinking tea.

[[Georgian#^ka-Q0174-answer|Compare the answer]]
^ka-Q0174

**ka-Q0175 · Fill the gap**

ყველა ____ ვაშლი შევჭამე.

I ate all those apples.

[[Georgian#^ka-Q0175-answer|Compare the answer]]
^ka-Q0175

**ka-Q0176 · Choose the form**

ყველა ____ ვაშლი შევჭამე.

I ate all those apples.

Choices: იმ / ის / ამ / ეს

[[Georgian#^ka-Q0176-answer|Compare the answer]]
^ka-Q0176

**ka-Q0177 · Edit the changed sentence**

【ეს】 ოთახში ბიჭია.

There is a boy in this room.

[[Georgian#^ka-Q0177-answer|Compare the answer]]
^ka-Q0177

**ka-Q0178 · Build the sentence**

Arrange: ბიჭია. / ამ / ოთახში

There is a boy in this room.

[[Georgian#^ka-Q0178-answer|Compare the answer]]
^ka-Q0178

**ka-Q0179 · Write a translation**

Write this in Georgian: Last night I dreamt I was eating bees.

[[Georgian#^ka-Q0179-answer|Compare the answer]]
^ka-Q0179

**ka-Q0180 · Explain the grammar**

გასულ ღამ【ეს】 ვესიზმრებოდი, რომ მე ფუტკარს ვჭამდი.

Last night I dreamt I was eating bees.

[[Georgian#^ka-Q0180-answer|Compare the answer]]
^ka-Q0180

**ka-Q0181 · Fill the gap**

ყველ____ გაიმეორეთ ჩემს შემდეგ.

Read after me all together.

[[Georgian#^ka-Q0181-answer|Compare the answer]]
^ka-Q0181

**ka-Q0182 · Choose the form**

ყველ____ გაიმეორეთ ჩემს შემდეგ.

Read after me all together.

Choices: იმ / ამ / ის / ეს

[[Georgian#^ka-Q0182-answer|Compare the answer]]
^ka-Q0182

**ka-Q0183 · Edit the changed sentence**

【ეს】 ჩემი მაგიდაა.

It is my table.

[[Georgian#^ka-Q0183-answer|Compare the answer]]
^ka-Q0183

**ka-Q0184 · Build the sentence**

Arrange: ჩემი / ის / მაგიდაა.

It is my table.

[[Georgian#^ka-Q0184-answer|Compare the answer]]
^ka-Q0184

**ka-Q0185 · Write a translation**

Write this in Georgian: This rug has been cleaned.

[[Georgian#^ka-Q0185-answer|Compare the answer]]
^ka-Q0185

**ka-Q0186 · Explain the grammar**

【ეს】 ნოხია გაწმენდილი.

This rug has been cleaned.

[[Georgian#^ka-Q0186-answer|Compare the answer]]
^ka-Q0186

**ka-Q0187 · Fill the gap**

____ ამ საღამოს ლენინგრადს მიემგზავრება.

He's leaving for Leningrad tonight.

[[Georgian#^ka-Q0187-answer|Compare the answer]]
^ka-Q0187

**ka-Q0188 · Choose the form**

____ ამ საღამოს ლენინგრადს მიემგზავრება.

He's leaving for Leningrad tonight.

Choices: ის / ეს / ამ / იმ

[[Georgian#^ka-Q0188-answer|Compare the answer]]
^ka-Q0188

**ka-Q0189 · Edit the changed sentence**

ვიცი, რომ ტომმა 【ის】 გააკეთა.

I know Tom did this.

[[Georgian#^ka-Q0189-answer|Compare the answer]]
^ka-Q0189

**ka-Q0190 · Build the sentence**

Arrange: ვიცი, / ეს / ტომმა / გააკეთა. / რომ

I know Tom did this.

[[Georgian#^ka-Q0190-answer|Compare the answer]]
^ka-Q0190

**ka-Q0191 · Write a translation**

Write this in Georgian: I want to eat ice cream.

[[Georgian#^ka-Q0191-answer|Compare the answer]]
^ka-Q0191

**ka-Q0192 · Explain the grammar**

ნაყინ【ის】 ჭამა მინდა.

I want to eat ice cream.

[[Georgian#^ka-Q0192-answer|Compare the answer]]
^ka-Q0192

**ka-Q0193 · Fill the gap**

სამ____ აქვს მუქი კანი.

Sami is dark-skinned.

[[Georgian#^ka-Q0193-answer|Compare the answer]]
^ka-Q0193

**ka-Q0194 · Choose the form**

სამ____ აქვს მუქი კანი.

Sami is dark-skinned.

Choices: ის / იმ / ეს / ამ

[[Georgian#^ka-Q0194-answer|Compare the answer]]
^ka-Q0194

**ka-Q0195 · Edit the changed sentence**

მარიამი ტომ【ეს】 დედაა?

Is Mary Tom's mother?

[[Georgian#^ka-Q0195-answer|Compare the answer]]
^ka-Q0195

**ka-Q0196 · Build the sentence**

Arrange: დედაა? / ტომის / მარიამი

Is Mary Tom's mother?

[[Georgian#^ka-Q0196-answer|Compare the answer]]
^ka-Q0196

**ka-Q0197 · Write a translation**

Write this in Georgian: This is Tom's school.

[[Georgian#^ka-Q0197-answer|Compare the answer]]
^ka-Q0197

**ka-Q0198 · Explain the grammar**

【ეს】 ტომის სკოლაა.

This is Tom's school.

[[Georgian#^ka-Q0198-answer|Compare the answer]]
^ka-Q0198

**ka-Q0199 · Fill the gap**

____ ჩემი ძაღლია.

It is my dog.

[[Georgian#^ka-Q0199-answer|Compare the answer]]
^ka-Q0199

**ka-Q0200 · Choose the form**

____ ჩემი ძაღლია.

It is my dog.

Choices: ამ / ის / ეს / იმ

[[Georgian#^ka-Q0200-answer|Compare the answer]]
^ka-Q0200


### Possessive pronouns · 50 questions

**ka-Q0201 · Edit the changed sentence**

【ჩემი】 შეხვედრა შემთხვევითი იყო.

Our meeting was quite accidental.

[[Georgian#^ka-Q0201-answer|Compare the answer]]
^ka-Q0201

**ka-Q0202 · Build the sentence**

Arrange: იყო. / ჩვენი / შეხვედრა / შემთხვევითი

Our meeting was quite accidental.

[[Georgian#^ka-Q0202-answer|Compare the answer]]
^ka-Q0202

**ka-Q0203 · Write a translation**

Write this in Georgian: Here is your key.

[[Georgian#^ka-Q0203-answer|Compare the answer]]
^ka-Q0203

**ka-Q0204 · Explain the grammar**

აი 【შენი】 გასაღები.

Here is your key.

[[Georgian#^ka-Q0204-answer|Compare the answer]]
^ka-Q0204

**ka-Q0205 · Fill the gap**

აი ____ ძაღლი.

Here is your dog.

[[Georgian#^ka-Q0205-answer|Compare the answer]]
^ka-Q0205

**ka-Q0206 · Choose the form**

აი ____ ძაღლი.

Here is your dog.

Choices: შენი / ჩვენი / მისი / ჩემი

[[Georgian#^ka-Q0206-answer|Compare the answer]]
^ka-Q0206

**ka-Q0207 · Edit the changed sentence**

【შენი】 ვაჟიშვილი ჟურნალისტია.

My son is a journalist.

[[Georgian#^ka-Q0207-answer|Compare the answer]]
^ka-Q0207

**ka-Q0208 · Build the sentence**

Arrange: ჟურნალისტია. / ჩემი / ვაჟიშვილი

My son is a journalist.

[[Georgian#^ka-Q0208-answer|Compare the answer]]
^ka-Q0208

**ka-Q0209 · Write a translation**

Write this in Georgian: Your mother is very beautiful!

[[Georgian#^ka-Q0209-answer|Compare the answer]]
^ka-Q0209

**ka-Q0210 · Explain the grammar**

დედა【შენი】 ძალიან ლამაზია!

Your mother is very beautiful!

[[Georgian#^ka-Q0210-answer|Compare the answer]]
^ka-Q0210

**ka-Q0211 · Fill the gap**

აი ____ მენიუ.

Here is your menu.

[[Georgian#^ka-Q0211-answer|Compare the answer]]
^ka-Q0211

**ka-Q0212 · Choose the form**

აი ____ მენიუ.

Here is your menu.

Choices: ჩემი / თქვენი / მისი / შენი

[[Georgian#^ka-Q0212-answer|Compare the answer]]
^ka-Q0212

**ka-Q0213 · Edit the changed sentence**

ეს არის 【შენი】 წიგნი.

This is my book.

[[Georgian#^ka-Q0213-answer|Compare the answer]]
^ka-Q0213

**ka-Q0214 · Build the sentence**

Arrange: ჩემი / არის / წიგნი. / ეს

This is my book.

[[Georgian#^ka-Q0214-answer|Compare the answer]]
^ka-Q0214

**ka-Q0215 · Write a translation**

Write this in Georgian: They are my sisters.

[[Georgian#^ka-Q0215-answer|Compare the answer]]
^ka-Q0215

**ka-Q0216 · Explain the grammar**

ისინი 【ჩემი】 დები არიან.

They are my sisters.

[[Georgian#^ka-Q0216-answer|Compare the answer]]
^ka-Q0216

**ka-Q0217 · Fill the gap**

ეს წიგნები ____ დის არიან.

Those are my sister's books.

[[Georgian#^ka-Q0217-answer|Compare the answer]]
^ka-Q0217

**ka-Q0218 · Choose the form**

ეს წიგნები ____ დის არიან.

Those are my sister's books.

Choices: ჩვენი / ჩემი / მისი / შენი

[[Georgian#^ka-Q0218-answer|Compare the answer]]
^ka-Q0218

**ka-Q0219 · Edit the changed sentence**

მე უბრალოდ მინდოდა 【ჩემი】 გაბედნიერება.

I just wanted to make you happy.

[[Georgian#^ka-Q0219-answer|Compare the answer]]
^ka-Q0219

**ka-Q0220 · Build the sentence**

Arrange: მინდოდა / შენი / უბრალოდ / გაბედნიერება. / მე

I just wanted to make you happy.

[[Georgian#^ka-Q0220-answer|Compare the answer]]
^ka-Q0220

**ka-Q0221 · Write a translation**

Write this in Georgian: Mennad saw his friend die.

[[Georgian#^ka-Q0221-answer|Compare the answer]]
^ka-Q0221

**ka-Q0222 · Explain the grammar**

მენადმა დაინახა რომ 【მისი】 მეგობარი მოკვდა.

Mennad saw his friend die.

[[Georgian#^ka-Q0222-answer|Compare the answer]]
^ka-Q0222

**ka-Q0223 · Fill the gap**

____ დედა ენა ესპანურია.

My mother tongue is Spanish.

[[Georgian#^ka-Q0223-answer|Compare the answer]]
^ka-Q0223

**ka-Q0224 · Choose the form**

____ დედა ენა ესპანურია.

My mother tongue is Spanish.

Choices: ჩემი / მისი / ჩვენი / შენი

[[Georgian#^ka-Q0224-answer|Compare the answer]]
^ka-Q0224

**ka-Q0225 · Edit the changed sentence**

【შენი】 გადაწყვეტილების საზღვარგარეთ სწავლის გაკვირვებული ჩემი მშობლები.

My decision to study abroad surprised my parents.

[[Georgian#^ka-Q0225-answer|Compare the answer]]
^ka-Q0225

**ka-Q0226 · Build the sentence**

Arrange: სწავლის / საზღვარგარეთ / გაკვირვებული / მშობლები. / ჩემი / ჩემი / გადაწყვეტილების

My decision to study abroad surprised my parents.

[[Georgian#^ka-Q0226-answer|Compare the answer]]
^ka-Q0226

**ka-Q0227 · Write a translation**

Write this in Georgian: Here is your bag.

[[Georgian#^ka-Q0227-answer|Compare the answer]]
^ka-Q0227

**ka-Q0228 · Explain the grammar**

აი 【შენი】 ჩანთა.

Here is your bag.

[[Georgian#^ka-Q0228-answer|Compare the answer]]
^ka-Q0228

**ka-Q0229 · Fill the gap**

ესენი ____ დის წიგნები არიან.

Those are my sister's books.

[[Georgian#^ka-Q0229-answer|Compare the answer]]
^ka-Q0229

**ka-Q0230 · Choose the form**

ესენი ____ დის წიგნები არიან.

Those are my sister's books.

Choices: ჩვენი / ჩემი / მისი / შენი

[[Georgian#^ka-Q0230-answer|Compare the answer]]
^ka-Q0230

**ka-Q0231 · Edit the changed sentence**

სად არის 【შენი】 წიგნი?

Where is my book?

[[Georgian#^ka-Q0231-answer|Compare the answer]]
^ka-Q0231

**ka-Q0232 · Build the sentence**

Arrange: ჩემი / წიგნი? / სად / არის

Where is my book?

[[Georgian#^ka-Q0232-answer|Compare the answer]]
^ka-Q0232

**ka-Q0233 · Write a translation**

Write this in Georgian: Tom was 15, Maria 14. The other children – I can no longer remember their names – were a bit younger.

[[Georgian#^ka-Q0233-answer|Compare the answer]]
^ka-Q0233

**ka-Q0234 · Explain the grammar**

ტომი 15-ის იყო, მარია 14-ის. სხვა ბავშვები - 【მათი】 სახელები აღარ მახსოვს - ცოტათი უმცროსები იყვნენ.

Tom was 15, Maria 14. The other children – I can no longer remember their names – were a bit younger.

[[Georgian#^ka-Q0234-answer|Compare the answer]]
^ka-Q0234

**ka-Q0235 · Fill the gap**

ის იცის ____ ცოლს.

She knows my wife.

[[Georgian#^ka-Q0235-answer|Compare the answer]]
^ka-Q0235

**ka-Q0236 · Choose the form**

ის იცის ____ ცოლს.

She knows my wife.

Choices: ჩვენი / მისი / ჩემი / შენი

[[Georgian#^ka-Q0236-answer|Compare the answer]]
^ka-Q0236

**ka-Q0237 · Edit the changed sentence**

რატომ გჭირდება 【შენი】 ნებართვა?

Why do you need my permission?

[[Georgian#^ka-Q0237-answer|Compare the answer]]
^ka-Q0237

**ka-Q0238 · Build the sentence**

Arrange: ჩემი / გჭირდება / ნებართვა? / რატომ

Why do you need my permission?

[[Georgian#^ka-Q0238-answer|Compare the answer]]
^ka-Q0238

**ka-Q0239 · Write a translation**

Write this in Georgian: My sister is two years younger than me.

[[Georgian#^ka-Q0239-answer|Compare the answer]]
^ka-Q0239

**ka-Q0240 · Explain the grammar**

【ჩემი】 და არის ორი წლით უმცროსი ჩემზე.

My sister is two years younger than me.

[[Georgian#^ka-Q0240-answer|Compare the answer]]
^ka-Q0240

**ka-Q0241 · Fill the gap**

ის ____ ძროხაა.

It is my cow.

[[Georgian#^ka-Q0241-answer|Compare the answer]]
^ka-Q0241

**ka-Q0242 · Choose the form**

ის ____ ძროხაა.

It is my cow.

Choices: მისი / ჩვენი / ჩემი / შენი

[[Georgian#^ka-Q0242-answer|Compare the answer]]
^ka-Q0242

**ka-Q0243 · Edit the changed sentence**

შენ გაქვს 【შენი】 ნებართვა.

You have my permission.

[[Georgian#^ka-Q0243-answer|Compare the answer]]
^ka-Q0243

**ka-Q0244 · Build the sentence**

Arrange: გაქვს / შენ / ჩემი / ნებართვა.

You have my permission.

[[Georgian#^ka-Q0244-answer|Compare the answer]]
^ka-Q0244

**ka-Q0245 · Write a translation**

Write this in Georgian: I'm talking about your actions.

[[Georgian#^ka-Q0245-answer|Compare the answer]]
^ka-Q0245

**ka-Q0246 · Explain the grammar**

მე 【შენი】 მოქმედებების შესახებ ვსაუბრობ.

I'm talking about your actions.

[[Georgian#^ka-Q0246-answer|Compare the answer]]
^ka-Q0246

**ka-Q0247 · Fill the gap**

აი ____ წიგნი.

Here is your book.

[[Georgian#^ka-Q0247-answer|Compare the answer]]
^ka-Q0247

**ka-Q0248 · Choose the form**

აი ____ წიგნი.

Here is your book.

Choices: მისი / ჩვენი / ჩემი / შენი

[[Georgian#^ka-Q0248-answer|Compare the answer]]
^ka-Q0248

**ka-Q0249 · Edit the changed sentence**

გიყვართ 【ჩემი】 დედა?

Do you love your mother?

[[Georgian#^ka-Q0249-answer|Compare the answer]]
^ka-Q0249

**ka-Q0250 · Build the sentence**

Arrange: თქვენი / დედა? / გიყვართ

Do you love your mother?

[[Georgian#^ka-Q0250-answer|Compare the answer]]
^ka-Q0250


### Questions: people and things · 50 questions

**ka-Q0251 · Write a translation**

Write this in Georgian: I'm cold. May I close the window?

[[Georgian#^ka-Q0251-answer|Compare the answer]]
^ka-Q0251

**ka-Q0252 · Explain the grammar**

მცივა. შეიძლება ფანჯა【რა】 დავხურო?

I'm cold. May I close the window?

[[Georgian#^ka-Q0252-answer|Compare the answer]]
^ka-Q0252

**ka-Q0253 · Fill the gap**

ახალი მაღაზია მომავალ კვი____ გაიხსნება.

The new store is going to open next week.

[[Georgian#^ka-Q0253-answer|Compare the answer]]
^ka-Q0253

**ka-Q0254 · Choose the form**

ახალი მაღაზია მომავალ კვი____ გაიხსნება.

The new store is going to open next week.

Choices: ვის / ვინ / რა / რას

[[Georgian#^ka-Q0254-answer|Compare the answer]]
^ka-Q0254

**ka-Q0255 · Edit the changed sentence**

【რა】 მოგცა ნებართვა?

Who gave you permission?

[[Georgian#^ka-Q0255-answer|Compare the answer]]
^ka-Q0255

**ka-Q0256 · Build the sentence**

Arrange: მოგცა / ვინ / ნებართვა?

Who gave you permission?

[[Georgian#^ka-Q0256-answer|Compare the answer]]
^ka-Q0256

**ka-Q0257 · Write a translation**

Write this in Georgian: What does a Sovietologist study?

[[Georgian#^ka-Q0257-answer|Compare the answer]]
^ka-Q0257

**ka-Q0258 · Explain the grammar**

【რას】 იკვლევს სოვეტოლოგი?

What does a Sovietologist study?

[[Georgian#^ka-Q0258-answer|Compare the answer]]
^ka-Q0258

**ka-Q0259 · Fill the gap**

____ გინდა, რომ მოიგოს?

Who do you want to win?

[[Georgian#^ka-Q0259-answer|Compare the answer]]
^ka-Q0259

**ka-Q0260 · Choose the form**

____ გინდა, რომ მოიგოს?

Who do you want to win?

Choices: ვის / რა / ვინ / რას

[[Georgian#^ka-Q0260-answer|Compare the answer]]
^ka-Q0260

**ka-Q0261 · Edit the changed sentence**

ტომმა ლექსიკონი იყიდა მარიამისთ【ვინ】.

Tom bought Mary a dictionary.

[[Georgian#^ka-Q0261-answer|Compare the answer]]
^ka-Q0261

**ka-Q0262 · Build the sentence**

Arrange: მარიამისთვის. / ტომმა / იყიდა / ლექსიკონი

Tom bought Mary a dictionary.

[[Georgian#^ka-Q0262-answer|Compare the answer]]
^ka-Q0262

**ka-Q0263 · Write a translation**

Write this in Georgian: We will begin as soon as possible.

[[Georgian#^ka-Q0263-answer|Compare the answer]]
^ka-Q0263

**ka-Q0264 · Explain the grammar**

დავიწყებთ რაც შეიძლება ჩქა【რა】.

We will begin as soon as possible.

[[Georgian#^ka-Q0264-answer|Compare the answer]]
^ka-Q0264

**ka-Q0265 · Fill the gap**

ის წერილს დაწე____.

He wrote a letter.

[[Georgian#^ka-Q0265-answer|Compare the answer]]
^ka-Q0265

**ka-Q0266 · Choose the form**

ის წერილს დაწე____.

He wrote a letter.

Choices: რას / ვინ / რა / ვის

[[Georgian#^ka-Q0266-answer|Compare the answer]]
^ka-Q0266

**ka-Q0267 · Edit the changed sentence**

【ვინ】 ქვია მას?

Which his name?

[[Georgian#^ka-Q0267-answer|Compare the answer]]
^ka-Q0267

**ka-Q0268 · Build the sentence**

Arrange: მას? / ქვია / რა

Which his name?

[[Georgian#^ka-Q0268-answer|Compare the answer]]
^ka-Q0268

**ka-Q0269 · Write a translation**

Write this in Georgian: Tell me; who is this young man?

[[Georgian#^ka-Q0269-answer|Compare the answer]]
^ka-Q0269

**ka-Q0270 · Explain the grammar**

მითხრა, 【ვინ】 არის ეს ვაჟი?

Tell me; who is this young man?

[[Georgian#^ka-Q0270-answer|Compare the answer]]
^ka-Q0270

**ka-Q0271 · Fill the gap**

ხვალ ____ მიდის ქალაქში?

Who is going into the city tomorrow?

[[Georgian#^ka-Q0271-answer|Compare the answer]]
^ka-Q0271

**ka-Q0272 · Choose the form**

ხვალ ____ მიდის ქალაქში?

Who is going into the city tomorrow?

Choices: ვინ / რა / ვის / რას

[[Georgian#^ka-Q0272-answer|Compare the answer]]
^ka-Q0272

**ka-Q0273 · Edit the changed sentence**

ყოველთ【ვინ】 ვუყურებ ამ სურათს მორყვნით.

I always view this photo with disgust.

[[Georgian#^ka-Q0273-answer|Compare the answer]]
^ka-Q0273

**ka-Q0274 · Build the sentence**

Arrange: სურათს / ამ / მორყვნით. / ყოველთვის / ვუყურებ

I always view this photo with disgust.

[[Georgian#^ka-Q0274-answer|Compare the answer]]
^ka-Q0274

**ka-Q0275 · Write a translation**

Write this in Georgian: Yesterday was Sunday, not Saturday.

[[Georgian#^ka-Q0275-answer|Compare the answer]]
^ka-Q0275

**ka-Q0276 · Explain the grammar**

გუშინ იყო კვირა, შაბათი კი ა【რა】.

Yesterday was Sunday, not Saturday.

[[Georgian#^ka-Q0276-answer|Compare the answer]]
^ka-Q0276

**ka-Q0277 · Fill the gap**

შენ ____ უპასუხე?

What did you answer?

[[Georgian#^ka-Q0277-answer|Compare the answer]]
^ka-Q0277

**ka-Q0278 · Choose the form**

შენ ____ უპასუხე?

What did you answer?

Choices: რა / რას / ვის / ვინ

[[Georgian#^ka-Q0278-answer|Compare the answer]]
^ka-Q0278

**ka-Q0279 · Edit the changed sentence**

ეს 【ვინ】 ეღირება?

How much will it cost?

[[Georgian#^ka-Q0279-answer|Compare the answer]]
^ka-Q0279

**ka-Q0280 · Build the sentence**

Arrange: ეს / ეღირება? / რა

How much will it cost?

[[Georgian#^ka-Q0280-answer|Compare the answer]]
^ka-Q0280

**ka-Q0281 · Write a translation**

Write this in Georgian: Someone will close the window.

[[Georgian#^ka-Q0281-answer|Compare the answer]]
^ka-Q0281

**ka-Q0282 · Explain the grammar**

ვიღაც დახურავს ფანჯა【რა】.

Someone will close the window.

[[Georgian#^ka-Q0282-answer|Compare the answer]]
^ka-Q0282

**ka-Q0283 · Fill the gap**

მე ა____ ვარ კარგი ადამიანი.

I'm not a good person.

[[Georgian#^ka-Q0283-answer|Compare the answer]]
^ka-Q0283

**ka-Q0284 · Choose the form**

მე ა____ ვარ კარგი ადამიანი.

I'm not a good person.

Choices: ვის / ვინ / რას / რა

[[Georgian#^ka-Q0284-answer|Compare the answer]]
^ka-Q0284

**ka-Q0285 · Edit the changed sentence**

შენ ჩემთ【ვინ】 ყველაფერი ხარ.

You are everything to me.

[[Georgian#^ka-Q0285-answer|Compare the answer]]
^ka-Q0285

**ka-Q0286 · Build the sentence**

Arrange: შენ / ხარ. / ჩემთვის / ყველაფერი

You are everything to me.

[[Georgian#^ka-Q0286-answer|Compare the answer]]
^ka-Q0286

**ka-Q0287 · Write a translation**

Write this in Georgian: He needs to know what's going on.

[[Georgian#^ka-Q0287-answer|Compare the answer]]
^ka-Q0287

**ka-Q0288 · Explain the grammar**

მან უნდა იცოდეს 【რა】 ხდება.

He needs to know what's going on.

[[Georgian#^ka-Q0288-answer|Compare the answer]]
^ka-Q0288

**ka-Q0289 · Fill the gap**

მოდი ვიმღეროთ სიმღე____ ინგლისურად.

Let's sing a song in English.

[[Georgian#^ka-Q0289-answer|Compare the answer]]
^ka-Q0289

**ka-Q0290 · Choose the form**

მოდი ვიმღეროთ სიმღე____ ინგლისურად.

Let's sing a song in English.

Choices: რას / ვინ / რა / ვის

[[Georgian#^ka-Q0290-answer|Compare the answer]]
^ka-Q0290

**ka-Q0291 · Edit the changed sentence**

ცხენზე შემჯდარმა კაცმა ჩამოგვია【ვინ】.

A man on horseback came along the path.

[[Georgian#^ka-Q0291-answer|Compare the answer]]
^ka-Q0291

**ka-Q0292 · Build the sentence**

Arrange: შემჯდარმა / კაცმა / ჩამოგვიარა. / ცხენზე

A man on horseback came along the path.

[[Georgian#^ka-Q0292-answer|Compare the answer]]
^ka-Q0292

**ka-Q0293 · Write a translation**

Write this in Georgian: I'm not ready for marriage.

[[Georgian#^ka-Q0293-answer|Compare the answer]]
^ka-Q0293

**ka-Q0294 · Explain the grammar**

მე არ ვარ მზად ქორწინებისთ【ვის】.

I'm not ready for marriage.

[[Georgian#^ka-Q0294-answer|Compare the answer]]
^ka-Q0294

**ka-Q0295 · Fill the gap**

იმის გამო ვერ მჯე____.

That's why I cannot believe it.

[[Georgian#^ka-Q0295-answer|Compare the answer]]
^ka-Q0295

**ka-Q0296 · Choose the form**

იმის გამო ვერ მჯე____.

That's why I cannot believe it.

Choices: რა / რას / ვის / ვინ

[[Georgian#^ka-Q0296-answer|Compare the answer]]
^ka-Q0296

**ka-Q0297 · Edit the changed sentence**

【ვინ】 დახმარებას მივიღებ?

What help do I get?

[[Georgian#^ka-Q0297-answer|Compare the answer]]
^ka-Q0297

**ka-Q0298 · Build the sentence**

Arrange: დახმარებას / მივიღებ? / რა

What help do I get?

[[Georgian#^ka-Q0298-answer|Compare the answer]]
^ka-Q0298

**ka-Q0299 · Write a translation**

Write this in Georgian: Who will believe this?

[[Georgian#^ka-Q0299-answer|Compare the answer]]
^ka-Q0299

**ka-Q0300 · Explain the grammar**

【ვინ】 ამას დაიჯერებს?

Who will believe this?

[[Georgian#^ka-Q0300-answer|Compare the answer]]
^ka-Q0300


### Questions: place and manner · 46 questions

**ka-Q0301 · Fill the gap**

____ გინდა წასვლა?

Where do you want to go?

[[Georgian#^ka-Q0301-answer|Compare the answer]]
^ka-Q0301

**ka-Q0302 · Choose the form**

____ გინდა წასვლა?

Where do you want to go?

Choices: რატომ / სად / საიდან / როგორ

[[Georgian#^ka-Q0302-answer|Compare the answer]]
^ka-Q0302

**ka-Q0303 · Edit the changed sentence**

აი 【სად】 ინგლისურს სწავლობენ.

That is what they study English for.

[[Georgian#^ka-Q0303-answer|Compare the answer]]
^ka-Q0303

**ka-Q0304 · Build the sentence**

Arrange: ინგლისურს / აი / რატომ / სწავლობენ.

That is what they study English for.

[[Georgian#^ka-Q0304-answer|Compare the answer]]
^ka-Q0304

**ka-Q0305 · Write a translation**

Write this in Georgian: How can I be sure?

[[Georgian#^ka-Q0305-answer|Compare the answer]]
^ka-Q0305

**ka-Q0306 · Explain the grammar**

【როგორ】 შემიძლია დავარწმუნო?

How can I be sure?

[[Georgian#^ka-Q0306-answer|Compare the answer]]
^ka-Q0306

**ka-Q0307 · Fill the gap**

არ____ ვაპირებ წასვლას.

I'm not going to go anywhere.

[[Georgian#^ka-Q0307-answer|Compare the answer]]
^ka-Q0307

**ka-Q0308 · Choose the form**

არ____ ვაპირებ წასვლას.

I'm not going to go anywhere.

Choices: საიდან / როგორ / სად / რატომ

[[Georgian#^ka-Q0308-answer|Compare the answer]]
^ka-Q0308

**ka-Q0309 · Edit the changed sentence**

ტომმა 【სად】 წავიდა ავსტრალიაში?

How did Tom go to Australia?

[[Georgian#^ka-Q0309-answer|Compare the answer]]
^ka-Q0309

**ka-Q0310 · Build the sentence**

Arrange: როგორ / წავიდა / ავსტრალიაში? / ტომმა

How did Tom go to Australia?

[[Georgian#^ka-Q0310-answer|Compare the answer]]
^ka-Q0310

**ka-Q0311 · Write a translation**

Write this in Georgian: Marina knows where the meeting will be.

[[Georgian#^ka-Q0311-answer|Compare the answer]]
^ka-Q0311

**ka-Q0312 · Explain the grammar**

მარინამ იცის, კრება 【სად】 იქნება.

Marina knows where the meeting will be.

[[Georgian#^ka-Q0312-answer|Compare the answer]]
^ka-Q0312

**ka-Q0313 · Fill the gap**

____ არის სასტუმრო?

Where is the hotel?

[[Georgian#^ka-Q0313-answer|Compare the answer]]
^ka-Q0313

**ka-Q0314 · Choose the form**

____ არის სასტუმრო?

Where is the hotel?

Choices: როგორ / სად / საიდან / რატომ

[[Georgian#^ka-Q0314-answer|Compare the answer]]
^ka-Q0314

**ka-Q0315 · Edit the changed sentence**

„【საიდან】 ცხოვრობ შენ?“ „მე ტოკიოში ვცხოვრობ.“

"Where do you live?" "I live in Tokyo."

[[Georgian#^ka-Q0315-answer|Compare the answer]]
^ka-Q0315

**ka-Q0316 · Build the sentence**

Arrange: ტოკიოში / „მე / „სად / შენ?“ / ცხოვრობ / ვცხოვრობ.“

"Where do you live?" "I live in Tokyo."

[[Georgian#^ka-Q0316-answer|Compare the answer]]
^ka-Q0316

**ka-Q0317 · Write a translation**

Write this in Georgian: Where have you seen these women?

[[Georgian#^ka-Q0317-answer|Compare the answer]]
^ka-Q0317

**ka-Q0318 · Explain the grammar**

【სად】 ნახე ამ ქალებს?

Where have you seen these women?

[[Georgian#^ka-Q0318-answer|Compare the answer]]
^ka-Q0318

**ka-Q0319 · Fill the gap**

____ იყავი წუხელ?

Where were you last night?

[[Georgian#^ka-Q0319-answer|Compare the answer]]
^ka-Q0319

**ka-Q0320 · Choose the form**

____ იყავი წუხელ?

Where were you last night?

Choices: როგორ / საიდან / სად / რატომ

[[Georgian#^ka-Q0320-answer|Compare the answer]]
^ka-Q0320

**ka-Q0321 · Edit the changed sentence**

【სად】 ეს დროშა?

Where does this flag come from?

[[Georgian#^ka-Q0321-answer|Compare the answer]]
^ka-Q0321

**ka-Q0322 · Build the sentence**

Arrange: ეს / საიდან / დროშა?

Where does this flag come from?

[[Georgian#^ka-Q0322-answer|Compare the answer]]
^ka-Q0322

**ka-Q0323 · Write a translation**

Write this in Georgian: Why do you have a knife in your hand?

[[Georgian#^ka-Q0323-answer|Compare the answer]]
^ka-Q0323

**ka-Q0324 · Explain the grammar**

【რატომ】 შენს ხელში დანაა?

Why do you have a knife in your hand?

[[Georgian#^ka-Q0324-answer|Compare the answer]]
^ka-Q0324

**ka-Q0325 · Fill the gap**

იცით, ____ იქნება კრება?

Do you know where the meeting will be?

[[Georgian#^ka-Q0325-answer|Compare the answer]]
^ka-Q0325

**ka-Q0326 · Choose the form**

იცით, ____ იქნება კრება?

Do you know where the meeting will be?

Choices: საიდან / რატომ / როგორ / სად

[[Georgian#^ka-Q0326-answer|Compare the answer]]
^ka-Q0326

**ka-Q0327 · Edit the changed sentence**

ტომი 【სად】 მიდის ავსტრალიაში?

How is Tom going to Australia?

[[Georgian#^ka-Q0327-answer|Compare the answer]]
^ka-Q0327

**ka-Q0328 · Build the sentence**

Arrange: როგორ / ავსტრალიაში? / მიდის / ტომი

How is Tom going to Australia?

[[Georgian#^ka-Q0328-answer|Compare the answer]]
^ka-Q0328

**ka-Q0329 · Write a translation**

Write this in Georgian: Where is the food?

[[Georgian#^ka-Q0329-answer|Compare the answer]]
^ka-Q0329

**ka-Q0330 · Explain the grammar**

【სად】 არის საჭმელი?

Where is the food?

[[Georgian#^ka-Q0330-answer|Compare the answer]]
^ka-Q0330

**ka-Q0331 · Fill the gap**

წიგნი მინდა. ____ არის წიგნის მაღაზია?

I want a book. Where is the bookstore?

[[Georgian#^ka-Q0331-answer|Compare the answer]]
^ka-Q0331

**ka-Q0332 · Choose the form**

წიგნი მინდა. ____ არის წიგნის მაღაზია?

I want a book. Where is the bookstore?

Choices: როგორ / საიდან / რატომ / სად

[[Georgian#^ka-Q0332-answer|Compare the answer]]
^ka-Q0332

**ka-Q0333 · Edit the changed sentence**

【საიდან】 არ გინდა წასვლა?

Where do you not want to go?

[[Georgian#^ka-Q0333-answer|Compare the answer]]
^ka-Q0333

**ka-Q0334 · Build the sentence**

Arrange: არ / გინდა / წასვლა? / სად

Where do you not want to go?

[[Georgian#^ka-Q0334-answer|Compare the answer]]
^ka-Q0334

**ka-Q0335 · Write a translation**

Write this in Georgian: That is what they study English for.

[[Georgian#^ka-Q0335-answer|Compare the answer]]
^ka-Q0335

**ka-Q0336 · Explain the grammar**

აი 【რატომ】 სწავლობენ ინგლისურს.

That is what they study English for.

[[Georgian#^ka-Q0336-answer|Compare the answer]]
^ka-Q0336

**ka-Q0337 · Fill the gap**

ქალმა 30 წიგნი დაწერა იმაზე, თუ ____ გავხდეთ ბედნიერი, და შემდეგ თავი მოიკლა.

A woman wrote 30 books about how to become happy, and then committed suicide.

[[Georgian#^ka-Q0337-answer|Compare the answer]]
^ka-Q0337

**ka-Q0338 · Choose the form**

ქალმა 30 წიგნი დაწერა იმაზე, თუ ____ გავხდეთ ბედნიერი, და შემდეგ თავი მოიკლა.

A woman wrote 30 books about how to become happy, and then committed suicide.

Choices: რატომ / სად / საიდან / როგორ

[[Georgian#^ka-Q0338-answer|Compare the answer]]
^ka-Q0338

**ka-Q0339 · Edit the changed sentence**

კვერცხები 【საიდან】 არიან, გეთაყვა?

Where are the eggs, please?

[[Georgian#^ka-Q0339-answer|Compare the answer]]
^ka-Q0339

**ka-Q0340 · Build the sentence**

Arrange: სად / არიან, / გეთაყვა? / კვერცხები

Where are the eggs, please?

[[Georgian#^ka-Q0340-answer|Compare the answer]]
^ka-Q0340

**ka-Q0341 · Write a translation**

Write this in Georgian: Where do you want to go?

[[Georgian#^ka-Q0341-answer|Compare the answer]]
^ka-Q0341

**ka-Q0342 · Explain the grammar**

【სად】 გინდათ წასვლა?

Where do you want to go?

[[Georgian#^ka-Q0342-answer|Compare the answer]]
^ka-Q0342

**ka-Q0343 · Fill the gap**

კარგი. ____ ცხოვრობ შენ?

Ok. Where do you live?

[[Georgian#^ka-Q0343-answer|Compare the answer]]
^ka-Q0343

**ka-Q0344 · Choose the form**

კარგი. ____ ცხოვრობ შენ?

Ok. Where do you live?

Choices: როგორ / სად / საიდან / რატომ

[[Georgian#^ka-Q0344-answer|Compare the answer]]
^ka-Q0344

**ka-Q0345 · Edit the changed sentence**

ტომი 【სად】 არის ავსტრალიაში?

How's Tom doing in Australia?

[[Georgian#^ka-Q0345-answer|Compare the answer]]
^ka-Q0345

**ka-Q0346 · Build the sentence**

Arrange: არის / როგორ / ავსტრალიაში? / ტომი

How's Tom doing in Australia?

[[Georgian#^ka-Q0346-answer|Compare the answer]]
^ka-Q0346


### Plural forms · 50 questions

**ka-Q0347 · Write a translation**

Write this in Georgian: Mary loves horses.

[[Georgian#^ka-Q0347-answer|Compare the answer]]
^ka-Q0347

**ka-Q0348 · Explain the grammar**

მარიამს 【ცხენები】 უყვარს.

Mary loves horses.

[[Georgian#^ka-Q0348-answer|Compare the answer]]
^ka-Q0348

**ka-Q0349 · Fill the gap**

სახლში თუ დამაგვიანდება წასვლა, ნუ ____.

If I should be late getting home, please don't wait up for me.

[[Georgian#^ka-Q0349-answer|Compare the answer]]
^ka-Q0349

**ka-Q0350 · Choose the form**

სახლში თუ დამაგვიანდება წასვლა, ნუ ____.

If I should be late getting home, please don't wait up for me.

Choices: ბავშვები / სახლები / წიგნები / დამელოდები

[[Georgian#^ka-Q0350-answer|Compare the answer]]
^ka-Q0350

**ka-Q0351 · Edit the changed sentence**

【წიგნები】 დახუჭე და ათამდე დაითვალე.

Close your eyes, and count to ten.

[[Georgian#^ka-Q0351-answer|Compare the answer]]
^ka-Q0351

**ka-Q0352 · Build the sentence**

Arrange: და / ათამდე / დახუჭე / დაითვალე. / თვალები

Close your eyes, and count to ten.

[[Georgian#^ka-Q0352-answer|Compare the answer]]
^ka-Q0352

**ka-Q0353 · Write a translation**

Write this in Georgian: Mary likes romantic comedies.

[[Georgian#^ka-Q0353-answer|Compare the answer]]
^ka-Q0353

**ka-Q0354 · Explain the grammar**

მერი რომანტიული 【კომედიები】 მოსწონს.

Mary likes romantic comedies.

[[Georgian#^ka-Q0354-answer|Compare the answer]]
^ka-Q0354

**ka-Q0355 · Fill the gap**

____ თაფლს აკეთებენ.

Bees make honey.

[[Georgian#^ka-Q0355-answer|Compare the answer]]
^ka-Q0355

**ka-Q0356 · Choose the form**

____ თაფლს აკეთებენ.

Bees make honey.

Choices: ფუტკარები / ბავშვები / სახლები / წიგნები

[[Georgian#^ka-Q0356-answer|Compare the answer]]
^ka-Q0356

**ka-Q0357 · Edit the changed sentence**

【წიგნები】 ზღვაში ცხოვრობენ.

Fish live in the sea.

[[Georgian#^ka-Q0357-answer|Compare the answer]]
^ka-Q0357

**ka-Q0358 · Build the sentence**

Arrange: ზღვაში / თევზები / ცხოვრობენ.

Fish live in the sea.

[[Georgian#^ka-Q0358-answer|Compare the answer]]
^ka-Q0358

**ka-Q0359 · Write a translation**

Write this in Georgian: The keys are in the wardrobe.

[[Georgian#^ka-Q0359-answer|Compare the answer]]
^ka-Q0359

**ka-Q0360 · Explain the grammar**

【გასაღებები】 გარდერობში არიან.

The keys are in the wardrobe.

[[Georgian#^ka-Q0360-answer|Compare the answer]]
^ka-Q0360

**ka-Q0361 · Fill the gap**

____ ცხოვრობენ უდაბნოში.

Bedouins live in the desert.

[[Georgian#^ka-Q0361-answer|Compare the answer]]
^ka-Q0361

**ka-Q0362 · Choose the form**

____ ცხოვრობენ უდაბნოში.

Bedouins live in the desert.

Choices: სახლები / ბავშვები / ბედუინები / წიგნები

[[Georgian#^ka-Q0362-answer|Compare the answer]]
^ka-Q0362

**ka-Q0363 · Edit the changed sentence**

ის 【წიგნები】 აქედან შორსაა.

Those beaches are far from here.

[[Georgian#^ka-Q0363-answer|Compare the answer]]
^ka-Q0363

**ka-Q0364 · Build the sentence**

Arrange: პლაჟები / ის / აქედან / შორსაა.

Those beaches are far from here.

[[Georgian#^ka-Q0364-answer|Compare the answer]]
^ka-Q0364

**ka-Q0365 · Write a translation**

Write this in Georgian: If I stay silent, it doesn't mean that I agree with you.

[[Georgian#^ka-Q0365-answer|Compare the answer]]
^ka-Q0365

**ka-Q0366 · Explain the grammar**

თუ ჩუმად ვარ, ეს არ ნიშნავს რომ 【გეთანხმები】.

If I stay silent, it doesn't mean that I agree with you.

[[Georgian#^ka-Q0366-answer|Compare the answer]]
^ka-Q0366

**ka-Q0367 · Fill the gap**

მე მიყვარს ____

I like doughnuts.

[[Georgian#^ka-Q0367-answer|Compare the answer]]
^ka-Q0367

**ka-Q0368 · Choose the form**

მე მიყვარს ____

I like doughnuts.

Choices: წიგნები / ბავშვები / სახლები / დონატები

[[Georgian#^ka-Q0368-answer|Compare the answer]]
^ka-Q0368

**ka-Q0369 · Edit the changed sentence**

ვერ 【წიგნები】 ავსტრალიაში. უნდა დავბრუნდე ახალ ზელანდიაში.

I can't stay in Australia. I have to get back to New Zealand.

[[Georgian#^ka-Q0369-answer|Compare the answer]]
^ka-Q0369

**ka-Q0370 · Build the sentence**

Arrange: დავბრუნდე / უნდა / ვრჩები / ზელანდიაში. / ავსტრალიაში. / ახალ / ვერ

I can't stay in Australia. I have to get back to New Zealand.

[[Georgian#^ka-Q0370-answer|Compare the answer]]
^ka-Q0370

**ka-Q0371 · Write a translation**

Write this in Georgian: You are doctors.

[[Georgian#^ka-Q0371-answer|Compare the answer]]
^ka-Q0371

**ka-Q0372 · Explain the grammar**

თქვენ 【ექიმები】 ხართ.

You are doctors.

[[Georgian#^ka-Q0372-answer|Compare the answer]]
^ka-Q0372

**ka-Q0373 · Fill the gap**

____ და კატები არ არიან მეგობრები.

Dogs and cats aren't friends.

[[Georgian#^ka-Q0373-answer|Compare the answer]]
^ka-Q0373

**ka-Q0374 · Choose the form**

____ და კატები არ არიან მეგობრები.

Dogs and cats aren't friends.

Choices: ძაღლები / წიგნები / სახლები / ბავშვები

[[Georgian#^ka-Q0374-answer|Compare the answer]]
^ka-Q0374

**ka-Q0375 · Edit the changed sentence**

ტომი და მერი 【წიგნები】 არიან.

Tom and Mary are anti-fascists.

[[Georgian#^ka-Q0375-answer|Compare the answer]]
^ka-Q0375

**ka-Q0376 · Build the sentence**

Arrange: არიან. / ანტიფაშისტები / ტომი / და / მერი

Tom and Mary are anti-fascists.

[[Georgian#^ka-Q0376-answer|Compare the answer]]
^ka-Q0376

**ka-Q0377 · Write a translation**

Write this in Georgian: I don't like doctors.

[[Georgian#^ka-Q0377-answer|Compare the answer]]
^ka-Q0377

**ka-Q0378 · Explain the grammar**

მე არ მიყვარს 【ექიმები】.

I don't like doctors.

[[Georgian#^ka-Q0378-answer|Compare the answer]]
^ka-Q0378

**ka-Q0379 · Fill the gap**

მე ძალიან მომწონს ____.

I like dogs very much.

[[Georgian#^ka-Q0379-answer|Compare the answer]]
^ka-Q0379

**ka-Q0380 · Choose the form**

მე ძალიან მომწონს ____.

I like dogs very much.

Choices: ძაღლები / წიგნები / ბავშვები / სახლები

[[Georgian#^ka-Q0380-answer|Compare the answer]]
^ka-Q0380

**ka-Q0381 · Edit the changed sentence**

კუებს 【წიგნები】 არ აქვთ.

Turtles don't have teeth.

[[Georgian#^ka-Q0381-answer|Compare the answer]]
^ka-Q0381

**ka-Q0382 · Build the sentence**

Arrange: არ / კუებს / აქვთ. / კბილები

Turtles don't have teeth.

[[Georgian#^ka-Q0382-answer|Compare the answer]]
^ka-Q0382

**ka-Q0383 · Write a translation**

Write this in Georgian: Imagination is more important than knowledge. Knowledge is limited.

[[Georgian#^ka-Q0383-answer|Compare the answer]]
^ka-Q0383

**ka-Q0384 · Explain the grammar**

ფანტაზია უფრო მნიშვნელოვანია ვიდრე ცოდნა. ცოდნას 【საზღვრები】 აქვს.

Imagination is more important than knowledge. Knowledge is limited.

[[Georgian#^ka-Q0384-answer|Compare the answer]]
^ka-Q0384

**ka-Q0385 · Fill the gap**

ჩემი ____ ხის ქვეშ არიან.

My brothers are under the tree.

[[Georgian#^ka-Q0385-answer|Compare the answer]]
^ka-Q0385

**ka-Q0386 · Choose the form**

ჩემი ____ ხის ქვეშ არიან.

My brothers are under the tree.

Choices: სახლები / ძმები / წიგნები / ბავშვები

[[Georgian#^ka-Q0386-answer|Compare the answer]]
^ka-Q0386

**ka-Q0387 · Edit the changed sentence**

【წიგნები】 კარგად გაიზარდნენ.

The tomatoes have grown well.

[[Georgian#^ka-Q0387-answer|Compare the answer]]
^ka-Q0387

**ka-Q0388 · Build the sentence**

Arrange: კარგად / გაიზარდნენ. / პომიდორები

The tomatoes have grown well.

[[Georgian#^ka-Q0388-answer|Compare the answer]]
^ka-Q0388

**ka-Q0389 · Write a translation**

Write this in Georgian: Never write the words "bortsch" and "shchi" in German!

[[Georgian#^ka-Q0389-answer|Compare the answer]]
^ka-Q0389

**ka-Q0390 · Explain the grammar**

არასოდეს დაწეროთ 【სიტყვები】 ''ბორშჩი'' და ''შჩი'' გერმანულად!

Never write the words "bortsch" and "shchi" in German!

[[Georgian#^ka-Q0390-answer|Compare the answer]]
^ka-Q0390

**ka-Q0391 · Fill the gap**

ზოგადად რვა საათზე ____.

I usually get up at eight o'clock.

[[Georgian#^ka-Q0391-answer|Compare the answer]]
^ka-Q0391

**ka-Q0392 · Choose the form**

ზოგადად რვა საათზე ____.

I usually get up at eight o'clock.

Choices: წიგნები / ბავშვები / ვდგები / სახლები

[[Georgian#^ka-Q0392-answer|Compare the answer]]
^ka-Q0392

**ka-Q0393 · Edit the changed sentence**

【წიგნები】 საკლასო ოთახში არიან.

The students are in the classroom.

[[Georgian#^ka-Q0393-answer|Compare the answer]]
^ka-Q0393

**ka-Q0394 · Build the sentence**

Arrange: საკლასო / ოთახში / არიან. / მოსწავლები

The students are in the classroom.

[[Georgian#^ka-Q0394-answer|Compare the answer]]
^ka-Q0394

**ka-Q0395 · Write a translation**

Write this in Georgian: Mary loves animals.

[[Georgian#^ka-Q0395-answer|Compare the answer]]
^ka-Q0395

**ka-Q0396 · Explain the grammar**

მარიამს 【ცხოველები】 უყვარს.

Mary loves animals.

[[Georgian#^ka-Q0396-answer|Compare the answer]]
^ka-Q0396


### Inside/location -ში · 50 questions

**ka-Q0397 · Fill the gap**

შემიძლია წავიდე ____ ტომთან ერთად?

Can I visit Australia with Tom?

[[Georgian#^ka-Q0397-answer|Compare the answer]]
^ka-Q0397

**ka-Q0398 · Choose the form**

შემიძლია წავიდე ____ ტომთან ერთად?

Can I visit Australia with Tom?

Choices: ქალაქში / სახლში / სკოლაში / ავსტრალიაში

[[Georgian#^ka-Q0398-answer|Compare the answer]]
^ka-Q0398

**ka-Q0399 · Edit the changed sentence**

საშას ქონდა ძლიერი ტკივილი მარჯვენა 【სახლში】.

Sasha had a sharp pain in her right hand.

[[Georgian#^ka-Q0399-answer|Compare the answer]]
^ka-Q0399

**ka-Q0400 · Build the sentence**

Arrange: მარჯვენა / საშას / ტკივილი / ძლიერი / ქონდა / ხელში.

Sasha had a sharp pain in her right hand.

[[Georgian#^ka-Q0400-answer|Compare the answer]]
^ka-Q0400

**ka-Q0401 · Write a translation**

Write this in Georgian: I want to go to Tokyo.

[[Georgian#^ka-Q0401-answer|Compare the answer]]
^ka-Q0401

**ka-Q0402 · Explain the grammar**

【ტოკიოში】 წასვლა მინდა.

I want to go to Tokyo.

[[Georgian#^ka-Q0402-answer|Compare the answer]]
^ka-Q0402

**ka-Q0403 · Fill the gap**

ტომიც მუშაობს ____?

Does Tom work in Australia, too?

[[Georgian#^ka-Q0403-answer|Compare the answer]]
^ka-Q0403

**ka-Q0404 · Choose the form**

ტომიც მუშაობს ____?

Does Tom work in Australia, too?

Choices: ქალაქში / სახლში / სკოლაში / ავსტრალიაში

[[Georgian#^ka-Q0404-answer|Compare the answer]]
^ka-Q0404

**ka-Q0405 · Edit the changed sentence**

წერილი ბარდება 【სახლში】 ერთხელ.

The mail is delivered once a day.

[[Georgian#^ka-Q0405-answer|Compare the answer]]
^ka-Q0405

**ka-Q0406 · Build the sentence**

Arrange: ერთხელ. / წერილი / დღეში / ბარდება

The mail is delivered once a day.

[[Georgian#^ka-Q0406-answer|Compare the answer]]
^ka-Q0406

**ka-Q0407 · Write a translation**

Write this in Georgian: I left my umbrella on the train.

[[Georgian#^ka-Q0407-answer|Compare the answer]]
^ka-Q0407

**ka-Q0408 · Explain the grammar**

ქოლგა 【მატარებელში】 დავტოვე.

I left my umbrella on the train.

[[Georgian#^ka-Q0408-answer|Compare the answer]]
^ka-Q0408

**ka-Q0409 · Fill the gap**

საღამოს ____ მივდივართ.

We are leaving for Hawaii tonight.

[[Georgian#^ka-Q0409-answer|Compare the answer]]
^ka-Q0409

**ka-Q0410 · Choose the form**

საღამოს ____ მივდივართ.

We are leaving for Hawaii tonight.

Choices: სახლში / სკოლაში / ჰავაიში / ქალაქში

[[Georgian#^ka-Q0410-answer|Compare the answer]]
^ka-Q0410

**ka-Q0411 · Edit the changed sentence**

【სახლში】 წასვლა მინდა.

I want to go to Japan.

[[Georgian#^ka-Q0411-answer|Compare the answer]]
^ka-Q0411

**ka-Q0412 · Build the sentence**

Arrange: წასვლა / მინდა. / იაპონიაში

I want to go to Japan.

[[Georgian#^ka-Q0412-answer|Compare the answer]]
^ka-Q0412

**ka-Q0413 · Write a translation**

Write this in Georgian: It's time to go to school.

[[Georgian#^ka-Q0413-answer|Compare the answer]]
^ka-Q0413

**ka-Q0414 · Explain the grammar**

【სკოლაში】 წასვლის დროა.

It's time to go to school.

[[Georgian#^ka-Q0414-answer|Compare the answer]]
^ka-Q0414

**ka-Q0415 · Fill the gap**

ტომი წასვლას აპირებს ____.

Tom is going to go to Australia.

[[Georgian#^ka-Q0415-answer|Compare the answer]]
^ka-Q0415

**ka-Q0416 · Choose the form**

ტომი წასვლას აპირებს ____.

Tom is going to go to Australia.

Choices: ქალაქში / ავსტრალიაში / სკოლაში / სახლში

[[Georgian#^ka-Q0416-answer|Compare the answer]]
^ka-Q0416

**ka-Q0417 · Edit the changed sentence**

მომეცი ნება გადავიხადო 【სახლში】.

Let me pay the bill.

[[Georgian#^ka-Q0417-answer|Compare the answer]]
^ka-Q0417

**ka-Q0418 · Build the sentence**

Arrange: ნება / გადავიხადო / ანგარიში. / მომეცი

Let me pay the bill.

[[Georgian#^ka-Q0418-answer|Compare the answer]]
^ka-Q0418

**ka-Q0419 · Write a translation**

Write this in Georgian: How long have you been in Japan?

[[Georgian#^ka-Q0419-answer|Compare the answer]]
^ka-Q0419

**ka-Q0420 · Explain the grammar**

რამდენი ხანია ხართ 【იაპონიაში】?

How long have you been in Japan?

[[Georgian#^ka-Q0420-answer|Compare the answer]]
^ka-Q0420

**ka-Q0421 · Fill the gap**

ტომმა თქვა, რომ წავიდოდა ____.

Tom said that he'd go to Boston.

[[Georgian#^ka-Q0421-answer|Compare the answer]]
^ka-Q0421

**ka-Q0422 · Choose the form**

ტომმა თქვა, რომ წავიდოდა ____.

Tom said that he'd go to Boston.

Choices: სკოლაში / სახლში / ბოსტონში / ქალაქში

[[Georgian#^ka-Q0422-answer|Compare the answer]]
^ka-Q0422

**ka-Q0423 · Edit the changed sentence**

წაეთრიე 【სახლში】! შე ზარმაცო ნაბიჭვარო!

Go to school! You lazy bastard.

[[Georgian#^ka-Q0423-answer|Compare the answer]]
^ka-Q0423

**ka-Q0424 · Build the sentence**

Arrange: ზარმაცო / ნაბიჭვარო! / სკოლაში! / წაეთრიე / შე

Go to school! You lazy bastard.

[[Georgian#^ka-Q0424-answer|Compare the answer]]
^ka-Q0424

**ka-Q0425 · Write a translation**

Write this in Georgian: I think Tom lives in Boston.

[[Georgian#^ka-Q0425-answer|Compare the answer]]
^ka-Q0425

**ka-Q0426 · Explain the grammar**

მე მგონი ტომი 【ბოსტონში】 ცხოვრობს.

I think Tom lives in Boston.

[[Georgian#^ka-Q0426-answer|Compare the answer]]
^ka-Q0426

**ka-Q0427 · Fill the gap**

ტომი დაინახე ____?

Did you see Tom in Australia?

[[Georgian#^ka-Q0427-answer|Compare the answer]]
^ka-Q0427

**ka-Q0428 · Choose the form**

ტომი დაინახე ____?

Did you see Tom in Australia?

Choices: სკოლაში / ავსტრალიაში / ქალაქში / სახლში

[[Georgian#^ka-Q0428-answer|Compare the answer]]
^ka-Q0428

**ka-Q0429 · Edit the changed sentence**

【სახლში】 წასვლა მინდა.

I want to go to India.

[[Georgian#^ka-Q0429-answer|Compare the answer]]
^ka-Q0429

**ka-Q0430 · Build the sentence**

Arrange: მინდა. / წასვლა / ინდოეთში

I want to go to India.

[[Georgian#^ka-Q0430-answer|Compare the answer]]
^ka-Q0430

**ka-Q0431 · Write a translation**

Write this in Georgian: I will go to France on holiday.

[[Georgian#^ka-Q0431-answer|Compare the answer]]
^ka-Q0431

**ka-Q0432 · Explain the grammar**

【შვებულებაში】 წავალ საფრანგეთში.

I will go to France on holiday.

[[Georgian#^ka-Q0432-answer|Compare the answer]]
^ka-Q0432

**ka-Q0433 · Fill the gap**

მე ვარ იგივე ____.

I'm in the same boat.

[[Georgian#^ka-Q0433-answer|Compare the answer]]
^ka-Q0433

**ka-Q0434 · Choose the form**

მე ვარ იგივე ____.

I'm in the same boat.

Choices: ქალაქში / ნავში / სკოლაში / სახლში

[[Georgian#^ka-Q0434-answer|Compare the answer]]
^ka-Q0434

**ka-Q0435 · Edit the changed sentence**

მე ტურისტულ 【სახლში】 ვმუშაობ.

I work in a tourist agency.

[[Georgian#^ka-Q0435-answer|Compare the answer]]
^ka-Q0435

**ka-Q0436 · Build the sentence**

Arrange: ტურისტულ / სააგენტოში / ვმუშაობ. / მე

I work in a tourist agency.

[[Georgian#^ka-Q0436-answer|Compare the answer]]
^ka-Q0436

**ka-Q0437 · Write a translation**

Write this in Georgian: Currently, Tom lives in Australia.

[[Georgian#^ka-Q0437-answer|Compare the answer]]
^ka-Q0437

**ka-Q0438 · Explain the grammar**

ამჟამად ტომი ცხოვრობს 【ავსტრალიაში】.

Currently, Tom lives in Australia.

[[Georgian#^ka-Q0438-answer|Compare the answer]]
^ka-Q0438

**ka-Q0439 · Fill the gap**

____ ხშირად ჩინელში ვეშლებოდი.

In the U.S. I was often taken to be Chinese.

[[Georgian#^ka-Q0439-answer|Compare the answer]]
^ka-Q0439

**ka-Q0440 · Choose the form**

____ ხშირად ჩინელში ვეშლებოდი.

In the U.S. I was often taken to be Chinese.

Choices: სახლში / ამერიკაში / ქალაქში / სკოლაში

[[Georgian#^ka-Q0440-answer|Compare the answer]]
^ka-Q0440

**ka-Q0441 · Edit the changed sentence**

მე მუშაობა არ მინდა ასეთ 【სახლში】.

I don't want to work under these conditions.

[[Georgian#^ka-Q0441-answer|Compare the answer]]
^ka-Q0441

**ka-Q0442 · Build the sentence**

Arrange: არ / მუშაობა / მე / ასეთ / პირობებში. / მინდა

I don't want to work under these conditions.

[[Georgian#^ka-Q0442-answer|Compare the answer]]
^ka-Q0442

**ka-Q0443 · Write a translation**

Write this in Georgian: You are in my way.

[[Georgian#^ka-Q0443-answer|Compare the answer]]
^ka-Q0443

**ka-Q0444 · Explain the grammar**

ჩემს 【გზაში】 ხარ.

You are in my way.

[[Georgian#^ka-Q0444-answer|Compare the answer]]
^ka-Q0444

**ka-Q0445 · Fill the gap**

მე ____ ვმუშაობ.

I work in a bank.

[[Georgian#^ka-Q0445-answer|Compare the answer]]
^ka-Q0445

**ka-Q0446 · Choose the form**

მე ____ ვმუშაობ.

I work in a bank.

Choices: სკოლაში / სახლში / ქალაქში / ბანკში

[[Georgian#^ka-Q0446-answer|Compare the answer]]
^ka-Q0446


### Source -დან · 10 questions

**ka-Q0447 · Edit the changed sentence**

მე 【სახლიდან】 ვარ.

I am from Russia.

[[Georgian#^ka-Q0447-answer|Compare the answer]]
^ka-Q0447

**ka-Q0448 · Build the sentence**

Arrange: მე / ვარ. / რუსეთიდან

I am from Russia.

[[Georgian#^ka-Q0448-answer|Compare the answer]]
^ka-Q0448

**ka-Q0449 · Write a translation**

Write this in Georgian: I am from Norway.

[[Georgian#^ka-Q0449-answer|Compare the answer]]
^ka-Q0449

**ka-Q0450 · Explain the grammar**

მე 【ნორვეგიადან】 ვარ.

I am from Norway.

[[Georgian#^ka-Q0450-answer|Compare the answer]]
^ka-Q0450

**ka-Q0451 · Fill the gap**

მე ვარ ____.

I come from America.

[[Georgian#^ka-Q0451-answer|Compare the answer]]
^ka-Q0451

**ka-Q0452 · Choose the form**

მე ვარ ____.

I come from America.

Choices: ქალაქიდან / სკოლიდან / ამერიკიდან / სახლიდან

[[Georgian#^ka-Q0452-answer|Compare the answer]]
^ka-Q0452

**ka-Q0453 · Edit the changed sentence**

მე 【სახლიდან】 ვარ.

I come from England.

[[Georgian#^ka-Q0453-answer|Compare the answer]]
^ka-Q0453

**ka-Q0454 · Build the sentence**

Arrange: მე / ვარ. / ინგლისიდან

I come from England.

[[Georgian#^ka-Q0454-answer|Compare the answer]]
^ka-Q0454

**ka-Q0455 · Write a translation**

Write this in Georgian: Peter got up from the table, silently poured out his glass, then sat down again.

[[Georgian#^ka-Q0455-answer|Compare the answer]]
^ka-Q0455

**ka-Q0456 · Explain the grammar**

პეტრე 【მაგიდიდან】 ადგა, უსიტყვოდ ჭიქა გამოცალა და მერე ისევ დაჯდა.

Peter got up from the table, silently poured out his glass, then sat down again.

[[Georgian#^ka-Q0456-answer|Compare the answer]]
^ka-Q0456


### Possessor and relation forms · 8 questions

**ka-Q0457 · Fill the gap**

ცათამბჯენი ____ ცენტრშია.

The skyscraper is in the center of the city.

[[Georgian#^ka-Q0457-answer|Compare the answer]]
^ka-Q0457

**ka-Q0458 · Choose the form**

ცათამბჯენი ____ ცენტრშია.

The skyscraper is in the center of the city.

Choices: ბავშვის / ქალაქის / წიგნის / სახლის

[[Georgian#^ka-Q0458-answer|Compare the answer]]
^ka-Q0458

**ka-Q0459 · Edit the changed sentence**

ის 【წიგნის】 კაცია.

He's the man of the house.

[[Georgian#^ka-Q0459-answer|Compare the answer]]
^ka-Q0459

**ka-Q0460 · Build the sentence**

Arrange: სახლის / კაცია. / ის

He's the man of the house.

[[Georgian#^ka-Q0460-answer|Compare the answer]]
^ka-Q0460

**ka-Q0461 · Write a translation**

Write this in Georgian: I'll write a book.

[[Georgian#^ka-Q0461-answer|Compare the answer]]
^ka-Q0461

**ka-Q0462 · Explain the grammar**

მე 【წიგნის】 დავწერ.

I'll write a book.

[[Georgian#^ka-Q0462-answer|Compare the answer]]
^ka-Q0462

**ka-Q0463 · Fill the gap**

მე ____ კაცი ვარ.

I'm the man of the house.

[[Georgian#^ka-Q0463-answer|Compare the answer]]
^ka-Q0463

**ka-Q0464 · Choose the form**

მე ____ კაცი ვარ.

I'm the man of the house.

Choices: წიგნის / ბავშვის / სახლის

[[Georgian#^ka-Q0464-answer|Compare the answer]]
^ka-Q0464


### Possession predicates · 24 questions

**ka-Q0465 · Edit the changed sentence**

მწვანე პერანგი 【გაქვს】.

I have a green shirt.

[[Georgian#^ka-Q0465-answer|Compare the answer]]
^ka-Q0465

**ka-Q0466 · Build the sentence**

Arrange: პერანგი / მაქვს. / მწვანე

I have a green shirt.

[[Georgian#^ka-Q0466-answer|Compare the answer]]
^ka-Q0466

**ka-Q0467 · Write a translation**

Write this in Georgian: I have a lot to do.

[[Georgian#^ka-Q0467-answer|Compare the answer]]
^ka-Q0467

**ka-Q0468 · Explain the grammar**

ბევრი 【მაქვს】 გასაკეთებლად.

I have a lot to do.

[[Georgian#^ka-Q0468-answer|Compare the answer]]
^ka-Q0468

**ka-Q0469 · Fill the gap**

დიდი სახლი ____.

I have a big house.

[[Georgian#^ka-Q0469-answer|Compare the answer]]
^ka-Q0469

**ka-Q0470 · Choose the form**

დიდი სახლი ____.

I have a big house.

Choices: გვაქვს / მაქვს / გაქვს / აქვს

[[Georgian#^ka-Q0470-answer|Compare the answer]]
^ka-Q0470

**ka-Q0471 · Edit the changed sentence**

ლურჯი სახლი 【გაქვს】.

I have a blue house.

[[Georgian#^ka-Q0471-answer|Compare the answer]]
^ka-Q0471

**ka-Q0472 · Build the sentence**

Arrange: სახლი / მაქვს. / ლურჯი

I have a blue house.

[[Georgian#^ka-Q0472-answer|Compare the answer]]
^ka-Q0472

**ka-Q0473 · Write a translation**

Write this in Georgian: You have few books.

[[Georgian#^ka-Q0473-answer|Compare the answer]]
^ka-Q0473

**ka-Q0474 · Explain the grammar**

რამდენიმე წიგნი 【გაქვს】.

You have few books.

[[Georgian#^ka-Q0474-answer|Compare the answer]]
^ka-Q0474

**ka-Q0475 · Fill the gap**

თომს ____ მუქი კანი.

Tom has dark skin.

[[Georgian#^ka-Q0475-answer|Compare the answer]]
^ka-Q0475

**ka-Q0476 · Choose the form**

თომს ____ მუქი კანი.

Tom has dark skin.

Choices: მაქვს / გაქვს / აქვს / გვაქვს

[[Georgian#^ka-Q0476-answer|Compare the answer]]
^ka-Q0476

**ka-Q0477 · Edit the changed sentence**

მას 【მაქვს】 ბევრი ცხვირსახოცი.

She has many handkerchiefs.

[[Georgian#^ka-Q0477-answer|Compare the answer]]
^ka-Q0477

**ka-Q0478 · Build the sentence**

Arrange: აქვს / ბევრი / ცხვირსახოცი. / მას

She has many handkerchiefs.

[[Georgian#^ka-Q0478-answer|Compare the answer]]
^ka-Q0478

**ka-Q0479 · Write a translation**

Write this in Georgian: I have a green house.

[[Georgian#^ka-Q0479-answer|Compare the answer]]
^ka-Q0479

**ka-Q0480 · Explain the grammar**

მწვანე სახლი 【მაქვს】.

I have a green house.

[[Georgian#^ka-Q0480-answer|Compare the answer]]
^ka-Q0480

**ka-Q0481 · Fill the gap**

თანამედროვე ქართულ დამწერლობას მხედრული ჰქვია და 33 ასო ____.

The modern-day Georgian writing system is called Mkhedruli and has 33 letters

[[Georgian#^ka-Q0481-answer|Compare the answer]]
^ka-Q0481

**ka-Q0482 · Choose the form**

თანამედროვე ქართულ დამწერლობას მხედრული ჰქვია და 33 ასო ____.

The modern-day Georgian writing system is called Mkhedruli and has 33 letters

Choices: გაქვს / მაქვს / გვაქვს / აქვს

[[Georgian#^ka-Q0482-answer|Compare the answer]]
^ka-Q0482

**ka-Q0483 · Edit the changed sentence**

ნებართვა არ 【მაქვს】 აქ გააკეთო.

You're not permitted to do that here.

[[Georgian#^ka-Q0483-answer|Compare the answer]]
^ka-Q0483

**ka-Q0484 · Build the sentence**

Arrange: გააკეთო. / არ / ნებართვა / გაქვს / აქ

You're not permitted to do that here.

[[Georgian#^ka-Q0484-answer|Compare the answer]]
^ka-Q0484

**ka-Q0485 · Write a translation**

Write this in Georgian: I have a lot to do.

[[Georgian#^ka-Q0485-answer|Compare the answer]]
^ka-Q0485

**ka-Q0486 · Explain the grammar**

ბევრი 【მაქვს】 გასაკეთებელი.

I have a lot to do.

[[Georgian#^ka-Q0486-answer|Compare the answer]]
^ka-Q0486

**ka-Q0487 · Fill the gap**

წითელი სახლი ____.

I have a red house.

[[Georgian#^ka-Q0487-answer|Compare the answer]]
^ka-Q0487

**ka-Q0488 · Choose the form**

წითელი სახლი ____.

I have a red house.

Choices: გვაქვს / მაქვს / გაქვს / აქვს

[[Georgian#^ka-Q0488-answer|Compare the answer]]
^ka-Q0488


### Want predicates · 50 questions

**ka-Q0489 · Edit the changed sentence**

【გინდა】 შენთან ლაპარაკი.

I want to talk to you.

[[Georgian#^ka-Q0489-answer|Compare the answer]]
^ka-Q0489

**ka-Q0490 · Build the sentence**

Arrange: ლაპარაკი. / შენთან / მინდა

I want to talk to you.

[[Georgian#^ka-Q0490-answer|Compare the answer]]
^ka-Q0490

**ka-Q0491 · Write a translation**

Write this in Georgian: I want to be an actress.

[[Georgian#^ka-Q0491-answer|Compare the answer]]
^ka-Q0491

**ka-Q0492 · Explain the grammar**

【მინდა】 ვიყო მსახიობი.

I want to be an actress.

[[Georgian#^ka-Q0492-answer|Compare the answer]]
^ka-Q0492

**ka-Q0493 · Fill the gap**

რომელი წიგნი ____?

Which book do you want?

[[Georgian#^ka-Q0493-answer|Compare the answer]]
^ka-Q0493

**ka-Q0494 · Choose the form**

რომელი წიგნი ____?

Which book do you want?

Choices: უნდა / მინდა / გინდა

[[Georgian#^ka-Q0494-answer|Compare the answer]]
^ka-Q0494

**ka-Q0495 · Edit the changed sentence**

【გინდა】 მასთან ლაპარაკი.

I want to talk to her.

[[Georgian#^ka-Q0495-answer|Compare the answer]]
^ka-Q0495

**ka-Q0496 · Build the sentence**

Arrange: მინდა / ლაპარაკი. / მასთან

I want to talk to her.

[[Georgian#^ka-Q0496-answer|Compare the answer]]
^ka-Q0496

**ka-Q0497 · Write a translation**

Write this in Georgian: I have to go.

[[Georgian#^ka-Q0497-answer|Compare the answer]]
^ka-Q0497

**ka-Q0498 · Explain the grammar**

მე 【უნდა】 წავიდე.

I have to go.

[[Georgian#^ka-Q0498-answer|Compare the answer]]
^ka-Q0498

**ka-Q0499 · Fill the gap**

____ ეს მიიღე?

Do you want to take that?

[[Georgian#^ka-Q0499-answer|Compare the answer]]
^ka-Q0499

**ka-Q0500 · Choose the form**

____ ეს მიიღე?

Do you want to take that?

Choices: გინდა / უნდა / მინდა

[[Georgian#^ka-Q0500-answer|Compare the answer]]
^ka-Q0500

**ka-Q0501 · Edit the changed sentence**

მე 【გინდა】 მოვკვდე გეთერ იანი - თან ერთად.

I want to die with Getter Jaani.

[[Georgian#^ka-Q0501-answer|Compare the answer]]
^ka-Q0501

**ka-Q0502 · Build the sentence**

Arrange: - / იანი / მინდა / გეთერ / ერთად. / თან / მოვკვდე / მე

I want to die with Getter Jaani.

[[Georgian#^ka-Q0502-answer|Compare the answer]]
^ka-Q0502

**ka-Q0503 · Write a translation**

Write this in Georgian: She needs to leave.

[[Georgian#^ka-Q0503-answer|Compare the answer]]
^ka-Q0503

**ka-Q0504 · Explain the grammar**

მან 【უნდა】 დატოვოს.

She needs to leave.

[[Georgian#^ka-Q0504-answer|Compare the answer]]
^ka-Q0504

**ka-Q0505 · Fill the gap**

ვაშლის ტორტს ჭამა ____.

I want to eat apple pie.

[[Georgian#^ka-Q0505-answer|Compare the answer]]
^ka-Q0505

**ka-Q0506 · Choose the form**

ვაშლის ტორტს ჭამა ____.

I want to eat apple pie.

Choices: გინდა / მინდა / უნდა

[[Georgian#^ka-Q0506-answer|Compare the answer]]
^ka-Q0506

**ka-Q0507 · Edit the changed sentence**

წასვლა არ 【მინდა】?

Don't you want to go?

[[Georgian#^ka-Q0507-answer|Compare the answer]]
^ka-Q0507

**ka-Q0508 · Build the sentence**

Arrange: გინდა? / არ / წასვლა

Don't you want to go?

[[Georgian#^ka-Q0508-answer|Compare the answer]]
^ka-Q0508

**ka-Q0509 · Write a translation**

Write this in Georgian: You can go if you want to.

[[Georgian#^ka-Q0509-answer|Compare the answer]]
^ka-Q0509

**ka-Q0510 · Explain the grammar**

შეგიძლია წახვიდე თუ 【გინდა】.

You can go if you want to.

[[Georgian#^ka-Q0510-answer|Compare the answer]]
^ka-Q0510

**ka-Q0511 · Fill the gap**

სასტუმროში წასვლა ____.

I want to go to a hotel.

[[Georgian#^ka-Q0511-answer|Compare the answer]]
^ka-Q0511

**ka-Q0512 · Choose the form**

სასტუმროში წასვლა ____.

I want to go to a hotel.

Choices: უნდა / გინდა / მინდა

[[Georgian#^ka-Q0512-answer|Compare the answer]]
^ka-Q0512

**ka-Q0513 · Edit the changed sentence**

【გინდა】 ამერიკაში წავიდე.

I want to go to America.

[[Georgian#^ka-Q0513-answer|Compare the answer]]
^ka-Q0513

**ka-Q0514 · Build the sentence**

Arrange: ამერიკაში / მინდა / წავიდე.

I want to go to America.

[[Georgian#^ka-Q0514-answer|Compare the answer]]
^ka-Q0514

**ka-Q0515 · Write a translation**

Write this in Georgian: I want to be a child.

[[Georgian#^ka-Q0515-answer|Compare the answer]]
^ka-Q0515

**ka-Q0516 · Explain the grammar**

【მინდა】 ვიყო ბავშვი.

I want to be a child.

[[Georgian#^ka-Q0516-answer|Compare the answer]]
^ka-Q0516

**ka-Q0517 · Fill the gap**

არასოდეს არ ისმენს რისი თქმაც ____.

He never hears what I'm trying to say.

[[Georgian#^ka-Q0517-answer|Compare the answer]]
^ka-Q0517

**ka-Q0518 · Choose the form**

არასოდეს არ ისმენს რისი თქმაც ____.

He never hears what I'm trying to say.

Choices: გინდა / მინდა / უნდა

[[Georgian#^ka-Q0518-answer|Compare the answer]]
^ka-Q0518

**ka-Q0519 · Edit the changed sentence**

მე 【მინდა】 ის გავაკეთო ახლა?

Do I have to do it now?

[[Georgian#^ka-Q0519-answer|Compare the answer]]
^ka-Q0519

**ka-Q0520 · Build the sentence**

Arrange: გავაკეთო / მე / უნდა / ის / ახლა?

Do I have to do it now?

[[Georgian#^ka-Q0520-answer|Compare the answer]]
^ka-Q0520

**ka-Q0521 · Write a translation**

Write this in Georgian: I want a good dictionary.

[[Georgian#^ka-Q0521-answer|Compare the answer]]
^ka-Q0521

**ka-Q0522 · Explain the grammar**

კარგი ლექსიკონი 【მინდა】.

I want a good dictionary.

[[Georgian#^ka-Q0522-answer|Compare the answer]]
^ka-Q0522

**ka-Q0523 · Fill the gap**

მე ____ წავიდე ბოსტონში ტომთან ერთად.

I have to go to Boston with Tom.

[[Georgian#^ka-Q0523-answer|Compare the answer]]
^ka-Q0523

**ka-Q0524 · Choose the form**

მე ____ წავიდე ბოსტონში ტომთან ერთად.

I have to go to Boston with Tom.

Choices: გინდა / უნდა / მინდა

[[Georgian#^ka-Q0524-answer|Compare the answer]]
^ka-Q0524

**ka-Q0525 · Edit the changed sentence**

მე 【გინდა】 ვიყო ჟურნალისტი.

I want to become a journalist.

[[Georgian#^ka-Q0525-answer|Compare the answer]]
^ka-Q0525

**ka-Q0526 · Build the sentence**

Arrange: ვიყო / მე / მინდა / ჟურნალისტი.

I want to become a journalist.

[[Georgian#^ka-Q0526-answer|Compare the answer]]
^ka-Q0526

**ka-Q0527 · Write a translation**

Write this in Georgian: I want to go to London.

[[Georgian#^ka-Q0527-answer|Compare the answer]]
^ka-Q0527

**ka-Q0528 · Explain the grammar**

ლონდონში წასვლა 【მინდა】.

I want to go to London.

[[Georgian#^ka-Q0528-answer|Compare the answer]]
^ka-Q0528

**ka-Q0529 · Fill the gap**

არ ____ სკოლაში წასვლა.

I don't want to go to school.

[[Georgian#^ka-Q0529-answer|Compare the answer]]
^ka-Q0529

**ka-Q0530 · Choose the form**

არ ____ სკოლაში წასვლა.

I don't want to go to school.

Choices: მინდა / გინდა / უნდა

[[Georgian#^ka-Q0530-answer|Compare the answer]]
^ka-Q0530

**ka-Q0531 · Edit the changed sentence**

სიეტლში წასვლა 【გინდა】.

I want to go to Seattle.

[[Georgian#^ka-Q0531-answer|Compare the answer]]
^ka-Q0531

**ka-Q0532 · Build the sentence**

Arrange: მინდა. / წასვლა / სიეტლში

I want to go to Seattle.

[[Georgian#^ka-Q0532-answer|Compare the answer]]
^ka-Q0532

**ka-Q0533 · Write a translation**

Write this in Georgian: I want to go to Germany.

[[Georgian#^ka-Q0533-answer|Compare the answer]]
^ka-Q0533

**ka-Q0534 · Explain the grammar**

გერმანიაში წასვლა 【მინდა】.

I want to go to Germany.

[[Georgian#^ka-Q0534-answer|Compare the answer]]
^ka-Q0534

**ka-Q0535 · Fill the gap**

ცოლი არ მინდა, გოგონა ____ სექსისთვის.

It's not a wife that I want, but a sex friend.

[[Georgian#^ka-Q0535-answer|Compare the answer]]
^ka-Q0535

**ka-Q0536 · Choose the form**

ცოლი არ მინდა, გოგონა ____ სექსისთვის.

It's not a wife that I want, but a sex friend.

Choices: გინდა / უნდა / მინდა

[[Georgian#^ka-Q0536-answer|Compare the answer]]
^ka-Q0536

**ka-Q0537 · Edit the changed sentence**

მან 【მინდა】 წავიდეს.

She needs to go.

[[Georgian#^ka-Q0537-answer|Compare the answer]]
^ka-Q0537

**ka-Q0538 · Build the sentence**

Arrange: წავიდეს. / მან / უნდა

She needs to go.

[[Georgian#^ka-Q0538-answer|Compare the answer]]
^ka-Q0538


### Common present verbs · 18 questions

**ka-Q0539 · Write a translation**

Write this in Georgian: I only know some words and phrases.

[[Georgian#^ka-Q0539-answer|Compare the answer]]
^ka-Q0539

**ka-Q0540 · Explain the grammar**

მხოლოდ 【ვიცი】 ზოგიერთი სიტყვა და ფრაზა.

I only know some words and phrases.

[[Georgian#^ka-Q0540-answer|Compare the answer]]
^ka-Q0540

**ka-Q0541 · Fill the gap**

მე არ ____ იაპონურად ლაპარაკი.

I don't speak Japanese.

[[Georgian#^ka-Q0541-answer|Compare the answer]]
^ka-Q0541

**ka-Q0542 · Choose the form**

მე არ ____ იაპონურად ლაპარაკი.

I don't speak Japanese.

Choices: იცის / ვიცი / ვფიქრობ / იცი

[[Georgian#^ka-Q0542-answer|Compare the answer]]
^ka-Q0542

**ka-Q0543 · Edit the changed sentence**

მე 【ვიცი】 ტომი მომზადებს საუზმეს.

I think Tom will make breakfast.

[[Georgian#^ka-Q0543-answer|Compare the answer]]
^ka-Q0543

**ka-Q0544 · Build the sentence**

Arrange: ტომი / მე / ვფიქრობ / მომზადებს / საუზმეს.

I think Tom will make breakfast.

[[Georgian#^ka-Q0544-answer|Compare the answer]]
^ka-Q0544

**ka-Q0545 · Write a translation**

Write this in Georgian: No one knows what'll happen.

[[Georgian#^ka-Q0545-answer|Compare the answer]]
^ka-Q0545

**ka-Q0546 · Explain the grammar**

არავინ 【იცის】 რა მოხდება.

No one knows what'll happen.

[[Georgian#^ka-Q0546-answer|Compare the answer]]
^ka-Q0546

**ka-Q0547 · Fill the gap**

მე ____ ჩვენ ვართ შემდეგი.

I think that we're next.

[[Georgian#^ka-Q0547-answer|Compare the answer]]
^ka-Q0547

**ka-Q0548 · Choose the form**

მე ____ ჩვენ ვართ შემდეგი.

I think that we're next.

Choices: იცის / ვფიქრობ / იცი / ვიცი

[[Georgian#^ka-Q0548-answer|Compare the answer]]
^ka-Q0548

**ka-Q0549 · Edit the changed sentence**

არ 【იცი】 სიმართლეა თუ ტყუილი.

I don't know whether it is true or not.

[[Georgian#^ka-Q0549-answer|Compare the answer]]
^ka-Q0549

**ka-Q0550 · Build the sentence**

Arrange: არ / ტყუილი. / სიმართლეა / თუ / ვიცი

I don't know whether it is true or not.

[[Georgian#^ka-Q0550-answer|Compare the answer]]
^ka-Q0550

**ka-Q0551 · Write a translation**

Write this in Georgian: Anybody knows it.

[[Georgian#^ka-Q0551-answer|Compare the answer]]
^ka-Q0551

**ka-Q0552 · Explain the grammar**

ეს ყველამ 【იცის】.

Anybody knows it.

[[Georgian#^ka-Q0552-answer|Compare the answer]]
^ka-Q0552

**ka-Q0553 · Fill the gap**

სტუდენტი სოციოლოგიას ____.

The student is working at sociology.

[[Georgian#^ka-Q0553-answer|Compare the answer]]
^ka-Q0553

**ka-Q0554 · Choose the form**

სტუდენტი სოციოლოგიას ____.

The student is working at sociology.

Choices: ვიცი / იცის / სწავლობს / იცი

[[Georgian#^ka-Q0554-answer|Compare the answer]]
^ka-Q0554

**ka-Q0555 · Edit the changed sentence**

რას 【ვიცი】 სოვეტოლოგი?

What does a Sovietologist study?

[[Georgian#^ka-Q0555-answer|Compare the answer]]
^ka-Q0555

**ka-Q0556 · Build the sentence**

Arrange: სწავლობს / სოვეტოლოგი? / რას

What does a Sovietologist study?

[[Georgian#^ka-Q0556-answer|Compare the answer]]
^ka-Q0556


### Past-series verbs · 32 questions

**ka-Q0557 · Write a translation**

Write this in Georgian: No more than 50 people came.

[[Georgian#^ka-Q0557-answer|Compare the answer]]
^ka-Q0557

**ka-Q0558 · Explain the grammar**

50 კაცამდე 【მოვიდა】.

No more than 50 people came.

[[Georgian#^ka-Q0558-answer|Compare the answer]]
^ka-Q0558

**ka-Q0559 · Fill the gap**

მარი ერთ-ერათი ყველაზე პოპულარული გოგო ____.

Mary was not one of the most popular girls.

[[Georgian#^ka-Q0559-answer|Compare the answer]]
^ka-Q0559

**ka-Q0560 · Choose the form**

მარი ერთ-ერათი ყველაზე პოპულარული გოგო ____.

Mary was not one of the most popular girls.

Choices: ნახა / იყო / ვნახე / თქვა

[[Georgian#^ka-Q0560-answer|Compare the answer]]
^ka-Q0560

**ka-Q0561 · Edit the changed sentence**

მარიამმა ცაზე 【ვნახე】.

Mary was in heaven.

[[Georgian#^ka-Q0561-answer|Compare the answer]]
^ka-Q0561

**ka-Q0562 · Build the sentence**

Arrange: მარიამმა / იყო. / ცაზე

Mary was in heaven.

[[Georgian#^ka-Q0562-answer|Compare the answer]]
^ka-Q0562

**ka-Q0563 · Write a translation**

Write this in Georgian: Houdini was a famous escapologist.

[[Georgian#^ka-Q0563-answer|Compare the answer]]
^ka-Q0563

**ka-Q0564 · Explain the grammar**

ჰუდინი 【იყო】 ცნობილი ესკაპოლოგი.

Houdini was a famous escapologist.

[[Georgian#^ka-Q0564-answer|Compare the answer]]
^ka-Q0564

**ka-Q0565 · Fill the gap**

გამოცდაზე ____ წერილობითი ნაწილი.

The exam had a written portion.

[[Georgian#^ka-Q0565-answer|Compare the answer]]
^ka-Q0565

**ka-Q0566 · Choose the form**

გამოცდაზე ____ წერილობითი ნაწილი.

The exam had a written portion.

Choices: თქვა / ვნახე / ნახა / იყო

[[Georgian#^ka-Q0566-answer|Compare the answer]]
^ka-Q0566

**ka-Q0567 · Edit the changed sentence**

რაც მან 【იყო】 სიმართლისგან შორს იყო.

What he said was far from true.

[[Georgian#^ka-Q0567-answer|Compare the answer]]
^ka-Q0567

**ka-Q0568 · Build the sentence**

Arrange: იყო. / თქვა / შორს / რაც / სიმართლისგან / მან

What he said was far from true.

[[Georgian#^ka-Q0568-answer|Compare the answer]]
^ka-Q0568

**ka-Q0569 · Write a translation**

Write this in Georgian: Forget it. It was just an idea.

[[Georgian#^ka-Q0569-answer|Compare the answer]]
^ka-Q0569

**ka-Q0570 · Explain the grammar**

დაივიწყე. ეს უბრალოდ იდეა 【იყო】.

Forget it. It was just an idea.

[[Georgian#^ka-Q0570-answer|Compare the answer]]
^ka-Q0570

**ka-Q0571 · Fill the gap**

მატარებელი დროზე ____.

The train arrived on schedule.

[[Georgian#^ka-Q0571-answer|Compare the answer]]
^ka-Q0571

**ka-Q0572 · Choose the form**

მატარებელი დროზე ____.

The train arrived on schedule.

Choices: მოვიდა / ნახა / იყო / ვნახე

[[Georgian#^ka-Q0572-answer|Compare the answer]]
^ka-Q0572

**ka-Q0573 · Edit the changed sentence**

მე არ შემიძლია ვ【იყო】 რამე ცუდი ტომის შესახებ.

I can't say anything bad about Tom.

[[Georgian#^ka-Q0573-answer|Compare the answer]]
^ka-Q0573

**ka-Q0574 · Build the sentence**

Arrange: არ / შემიძლია / რამე / ტომის / ვთქვა / ცუდი / მე / შესახებ.

I can't say anything bad about Tom.

[[Georgian#^ka-Q0574-answer|Compare the answer]]
^ka-Q0574

**ka-Q0575 · Write a translation**

Write this in Georgian: After the meeting she headed straight to her desk.

[[Georgian#^ka-Q0575-answer|Compare the answer]]
^ka-Q0575

**ka-Q0576 · Explain the grammar**

შეხვედრის შემდეგ ის პირდაპირ მის მაგიდისკენ 【წავიდა】.

After the meeting she headed straight to her desk.

[[Georgian#^ka-Q0576-answer|Compare the answer]]
^ka-Q0576

**ka-Q0577 · Fill the gap**

ალბათ თავისი ძველი მეგობრის სანახავად ____.

He must have gone to see his old friend.

[[Georgian#^ka-Q0577-answer|Compare the answer]]
^ka-Q0577

**ka-Q0578 · Choose the form**

ალბათ თავისი ძველი მეგობრის სანახავად ____.

He must have gone to see his old friend.

Choices: წავიდა / ნახა / იყო / ვნახე

[[Georgian#^ka-Q0578-answer|Compare the answer]]
^ka-Q0578

**ka-Q0579 · Edit the changed sentence**

კლიენტი არ 【იყო】.

The customer did not come.

[[Georgian#^ka-Q0579-answer|Compare the answer]]
^ka-Q0579

**ka-Q0580 · Build the sentence**

Arrange: მოვიდა. / კლიენტი / არ

The customer did not come.

[[Georgian#^ka-Q0580-answer|Compare the answer]]
^ka-Q0580

**ka-Q0581 · Write a translation**

Write this in Georgian: Tom knew he had a sister somewhere, but he had never seen her.

[[Georgian#^ka-Q0581-answer|Compare the answer]]
^ka-Q0581

**ka-Q0582 · Explain the grammar**

ტომმა იცოდა, რომ სადღაც და ჰყავდა, მაგრამ არასოდეს ე【ნახა】

Tom knew he had a sister somewhere, but he had never seen her.

[[Georgian#^ka-Q0582-answer|Compare the answer]]
^ka-Q0582

**ka-Q0583 · Fill the gap**

გემი ნაპირის გასწვრივ ____.

The ship was abreast of the shore.

[[Georgian#^ka-Q0583-answer|Compare the answer]]
^ka-Q0583

**ka-Q0584 · Choose the form**

გემი ნაპირის გასწვრივ ____.

The ship was abreast of the shore.

Choices: ვნახე / იყო / ნახა / თქვა

[[Georgian#^ka-Q0584-answer|Compare the answer]]
^ka-Q0584

**ka-Q0585 · Edit the changed sentence**

ვინ 【ვნახე】 ექსპედიციის წინამძღოლი?

Who was the leader of the expedition?

[[Georgian#^ka-Q0585-answer|Compare the answer]]
^ka-Q0585

**ka-Q0586 · Build the sentence**

Arrange: ექსპედიციის / იყო / წინამძღოლი? / ვინ

Who was the leader of the expedition?

[[Georgian#^ka-Q0586-answer|Compare the answer]]
^ka-Q0586

**ka-Q0587 · Write a translation**

Write this in Georgian: Did Tom go to Australia?

[[Georgian#^ka-Q0587-answer|Compare the answer]]
^ka-Q0587

**ka-Q0588 · Explain the grammar**

ტომმა ავსტრალიაში 【წავიდა】?

Did Tom go to Australia?

[[Georgian#^ka-Q0588-answer|Compare the answer]]
^ka-Q0588


### Future-series forms · 4 questions

**ka-Q0589 · Fill the gap**

ის ____ სტომატოლოგში.

He will go to the dentist.

[[Georgian#^ka-Q0589-answer|Compare the answer]]
^ka-Q0589

**ka-Q0590 · Choose the form**

ის ____ სტომატოლოგში.

He will go to the dentist.

Choices: წავალ / მოვა / წავა / იქნება

[[Georgian#^ka-Q0590-answer|Compare the answer]]
^ka-Q0590

**ka-Q0591 · Edit the changed sentence**

ძალიან კარგი 【წავალ】.

He will be very nice.

[[Georgian#^ka-Q0591-answer|Compare the answer]]
^ka-Q0591

**ka-Q0592 · Build the sentence**

Arrange: იქნება. / კარგი / ძალიან

He will be very nice.

[[Georgian#^ka-Q0592-answer|Compare the answer]]
^ka-Q0592


### Content and relative linking · 22 questions

**ka-Q0593 · Write a translation**

Write this in Georgian: He says that he knows you.

[[Georgian#^ka-Q0593-answer|Compare the answer]]
^ka-Q0593

**ka-Q0594 · Explain the grammar**

ის ამბობს, 【რომ】 გიცნობს.

He says that he knows you.

[[Georgian#^ka-Q0594-answer|Compare the answer]]
^ka-Q0594

**ka-Q0595 · Fill the gap**

ჩვენ შევთანხმდით, ____ სამსახურში თავს შევიკავებდით მოწევისაგან.

We agreed to refrain from smoking while we are at work.

[[Georgian#^ka-Q0595-answer|Compare the answer]]
^ka-Q0595

**ka-Q0596 · Choose the form**

ჩვენ შევთანხმდით, ____ სამსახურში თავს შევიკავებდით მოწევისაგან.

We agreed to refrain from smoking while we are at work.

Choices: რომ / თუ / რადგან

[[Georgian#^ka-Q0596-answer|Compare the answer]]
^ka-Q0596

**ka-Q0597 · Edit the changed sentence**

ეს მინდა, 【თუ】 ნინომ მოიგოს.

I want Nino to win.

[[Georgian#^ka-Q0597-answer|Compare the answer]]
^ka-Q0597

**ka-Q0598 · Build the sentence**

Arrange: ეს / მინდა, / მოიგოს. / რომ / ნინომ

I want Nino to win.

[[Georgian#^ka-Q0598-answer|Compare the answer]]
^ka-Q0598

**ka-Q0599 · Write a translation**

Write this in Georgian: Would you like to order?

[[Georgian#^ka-Q0599-answer|Compare the answer]]
^ka-Q0599

**ka-Q0600 · Explain the grammar**

გნებავთ 【რომ】 შეუკვეთოთ?

Would you like to order?

[[Georgian#^ka-Q0600-answer|Compare the answer]]
^ka-Q0600

**ka-Q0601 · Fill the gap**

არ მეგონა, ____ ტოფუ იმდენად გემრიელი იქნებოდა.

I wouldn't have thought that tofu tastes this good.

[[Georgian#^ka-Q0601-answer|Compare the answer]]
^ka-Q0601

**ka-Q0602 · Choose the form**

არ მეგონა, ____ ტოფუ იმდენად გემრიელი იქნებოდა.

I wouldn't have thought that tofu tastes this good.

Choices: რომ / თუ / რადგან

[[Georgian#^ka-Q0602-answer|Compare the answer]]
^ka-Q0602

**ka-Q0603 · Edit the changed sentence**

ამბობ 【თუ】 ჩემი ცხოვრება საფრთხეშია?

Are you saying my life is in danger?

[[Georgian#^ka-Q0603-answer|Compare the answer]]
^ka-Q0603

**ka-Q0604 · Build the sentence**

Arrange: ამბობ / საფრთხეშია? / ჩემი / ცხოვრება / რომ

Are you saying my life is in danger?

[[Georgian#^ka-Q0604-answer|Compare the answer]]
^ka-Q0604

**ka-Q0605 · Write a translation**

Write this in Georgian: Most people think I'm crazy.

[[Georgian#^ka-Q0605-answer|Compare the answer]]
^ka-Q0605

**ka-Q0606 · Explain the grammar**

ადამიანთა უმეტესობა ფიქრობს, 【რომ】 მე ვარ გიჟი.

Most people think I'm crazy.

[[Georgian#^ka-Q0606-answer|Compare the answer]]
^ka-Q0606

**ka-Q0607 · Fill the gap**

უკეთესი იქნებოდა, ____ არ წასულიყავი.

You'd better not go.

[[Georgian#^ka-Q0607-answer|Compare the answer]]
^ka-Q0607

**ka-Q0608 · Choose the form**

უკეთესი იქნებოდა, ____ არ წასულიყავი.

You'd better not go.

Choices: თუ / რადგან / რომ

[[Georgian#^ka-Q0608-answer|Compare the answer]]
^ka-Q0608

**ka-Q0609 · Edit the changed sentence**

თუკი არაფერს ვამბობ, ეს იმას არ ნიშნავს, 【თუ】 გეთანხმები.

If I don't say anything, it doesn't mean I'm agreeing with you.

[[Georgian#^ka-Q0609-answer|Compare the answer]]
^ka-Q0609

**ka-Q0610 · Build the sentence**

Arrange: არაფერს / გეთანხმები. / რომ / არ / იმას / ეს / ნიშნავს, / თუკი / ვამბობ,

If I don't say anything, it doesn't mean I'm agreeing with you.

[[Georgian#^ka-Q0610-answer|Compare the answer]]
^ka-Q0610

**ka-Q0611 · Write a translation**

Write this in Georgian: Tom definitely won't ask Mary to do that.

[[Georgian#^ka-Q0611-answer|Compare the answer]]
^ka-Q0611

**ka-Q0612 · Explain the grammar**

ტომი ნამდვილად არ სთხოვს, 【რომ】 მარია ის გააკეთოს.

Tom definitely won't ask Mary to do that.

[[Georgian#^ka-Q0612-answer|Compare the answer]]
^ka-Q0612

**ka-Q0613 · Fill the gap**

მარი გაოგნდა, როცა გაიგო, ____ ტომს თავის ბიძაშვილთან სექსი ჰქონდა.

Mary was shocked when she learned that Tom had had sex with his cousin.

[[Georgian#^ka-Q0613-answer|Compare the answer]]
^ka-Q0613

**ka-Q0614 · Choose the form**

მარი გაოგნდა, როცა გაიგო, ____ ტომს თავის ბიძაშვილთან სექსი ჰქონდა.

Mary was shocked when she learned that Tom had had sex with his cousin.

Choices: რადგან / რომ / თუ

[[Georgian#^ka-Q0614-answer|Compare the answer]]
^ka-Q0614


### Conditions · 14 questions

**ka-Q0615 · Edit the changed sentence**

【რომ】 იჩქარებ, დაეწევი.

If you hurry, you will overtake him.

[[Georgian#^ka-Q0615-answer|Compare the answer]]
^ka-Q0615

**ka-Q0616 · Build the sentence**

Arrange: დაეწევი. / იჩქარებ, / თუ

If you hurry, you will overtake him.

[[Georgian#^ka-Q0616-answer|Compare the answer]]
^ka-Q0616

**ka-Q0617 · Write a translation**

Write this in Georgian: Are you a man or a woman?

[[Georgian#^ka-Q0617-answer|Compare the answer]]
^ka-Q0617

**ka-Q0618 · Explain the grammar**

კაცი ხარ 【თუ】 ქალი?

Are you a man or a woman?

[[Georgian#^ka-Q0618-answer|Compare the answer]]
^ka-Q0618

**ka-Q0619 · Fill the gap**

კომპიუტერს ____ გამოიყენებ ინფორმაციის შენახვას შეძლებ.

If you use a computer, you can retain information.

[[Georgian#^ka-Q0619-answer|Compare the answer]]
^ka-Q0619

**ka-Q0620 · Choose the form**

კომპიუტერს ____ გამოიყენებ ინფორმაციის შენახვას შეძლებ.

If you use a computer, you can retain information.

Choices: რადგან / რომ / თუ

[[Georgian#^ka-Q0620-answer|Compare the answer]]
^ka-Q0620

**ka-Q0621 · Edit the changed sentence**

თქვენ მასწავლებელი ხართ 【რომ】 მოსწავლე?

Are you a teacher or a student?

[[Georgian#^ka-Q0621-answer|Compare the answer]]
^ka-Q0621

**ka-Q0622 · Build the sentence**

Arrange: მასწავლებელი / თქვენ / თუ / ხართ / მოსწავლე?

Are you a teacher or a student?

[[Georgian#^ka-Q0622-answer|Compare the answer]]
^ka-Q0622

**ka-Q0623 · Write a translation**

Write this in Georgian: Are you a teacher or a student?

[[Georgian#^ka-Q0623-answer|Compare the answer]]
^ka-Q0623

**ka-Q0624 · Explain the grammar**

თქვენ მასწავლებელი ხართ 【თუ】 სტუდენტი?

Are you a teacher or a student?

[[Georgian#^ka-Q0624-answer|Compare the answer]]
^ka-Q0624

**ka-Q0625 · Fill the gap**

ვინ ჭამს მეტს, შენ ____ ტომი?

Who eats more, you or Tom?

[[Georgian#^ka-Q0625-answer|Compare the answer]]
^ka-Q0625

**ka-Q0626 · Choose the form**

ვინ ჭამს მეტს, შენ ____ ტომი?

Who eats more, you or Tom?

Choices: რომ / თუ / რადგან

[[Georgian#^ka-Q0626-answer|Compare the answer]]
^ka-Q0626

**ka-Q0627 · Edit the changed sentence**

ამერიკელი ხარ 【რომ】 ფრანგი?

Are you American or French?

[[Georgian#^ka-Q0627-answer|Compare the answer]]
^ka-Q0627

**ka-Q0628 · Build the sentence**

Arrange: თუ / ამერიკელი / ხარ / ფრანგი?

Are you American or French?

[[Georgian#^ka-Q0628-answer|Compare the answer]]
^ka-Q0628


### Coordination and contrast · 50 questions

**ka-Q0629 · Write a translation**

Write this in Georgian: I only have toast and coffee in the morning.

[[Georgian#^ka-Q0629-answer|Compare the answer]]
^ka-Q0629

**ka-Q0630 · Explain the grammar**

დილაობით მხოლოდ ტოსტს 【და】 ყავას მივირთმევ.

I only have toast and coffee in the morning.

[[Georgian#^ka-Q0630-answer|Compare the answer]]
^ka-Q0630

**ka-Q0631 · Fill the gap**

წავალთ თქვენთ____ ერთად.

We'll go with you.

[[Georgian#^ka-Q0631-answer|Compare the answer]]
^ka-Q0631

**ka-Q0632 · Choose the form**

წავალთ თქვენთ____ ერთად.

We'll go with you.

Choices: ან / მაგრამ / და

[[Georgian#^ka-Q0632-answer|Compare the answer]]
^ka-Q0632

**ka-Q0633 · Edit the changed sentence**

ეს ადგილი ძალი【და】 სასიამოვნოა.

This place is very pleasant.

[[Georgian#^ka-Q0633-answer|Compare the answer]]
^ka-Q0633

**ka-Q0634 · Build the sentence**

Arrange: ეს / ადგილი / სასიამოვნოა. / ძალიან

This place is very pleasant.

[[Georgian#^ka-Q0634-answer|Compare the answer]]
^ka-Q0634

**ka-Q0635 · Write a translation**

Write this in Georgian: We'll go with you.

[[Georgian#^ka-Q0635-answer|Compare the answer]]
^ka-Q0635

**ka-Q0636 · Explain the grammar**

წავალთ შენთ【ან】 ერთად.

We'll go with you.

[[Georgian#^ka-Q0636-answer|Compare the answer]]
^ka-Q0636

**ka-Q0637 · Fill the gap**

მე მოგიტ____ შენ.

I'll bring you.

[[Georgian#^ka-Q0637-answer|Compare the answer]]
^ka-Q0637

**ka-Q0638 · Choose the form**

მე მოგიტ____ შენ.

I'll bring you.

Choices: და / ან / მაგრამ

[[Georgian#^ka-Q0638-answer|Compare the answer]]
^ka-Q0638

**ka-Q0639 · Edit the changed sentence**

ეს მანქანა ძალი【და】 სწრაფია.

That car is very fast.

[[Georgian#^ka-Q0639-answer|Compare the answer]]
^ka-Q0639

**ka-Q0640 · Build the sentence**

Arrange: სწრაფია. / მანქანა / ეს / ძალიან

That car is very fast.

[[Georgian#^ka-Q0640-answer|Compare the answer]]
^ka-Q0640

**ka-Q0641 · Write a translation**

Write this in Georgian: I found the book very interesting.

[[Georgian#^ka-Q0641-answer|Compare the answer]]
^ka-Q0641

**ka-Q0642 · Explain the grammar**

ამ წიგნმა ძალი【ან】 დამაინტერესა.

I found the book very interesting.

[[Georgian#^ka-Q0642-answer|Compare the answer]]
^ka-Q0642

**ka-Q0643 · Fill the gap**

ახლა, როცა ერთნაირსქესიანთა ქორწინება ლეგალურია, ერთი ნაბიჯით ახლოს ვარ ჩემს თავთ____ დასაქორწინებლად.

Now that same-sex marriage is legal, I'm one step closer to marrying myself.

[[Georgian#^ka-Q0643-answer|Compare the answer]]
^ka-Q0643

**ka-Q0644 · Choose the form**

ახლა, როცა ერთნაირსქესიანთა ქორწინება ლეგალურია, ერთი ნაბიჯით ახლოს ვარ ჩემს თავთ____ დასაქორწინებლად.

Now that same-sex marriage is legal, I'm one step closer to marrying myself.

Choices: ან / მაგრამ / და

[[Georgian#^ka-Q0644-answer|Compare the answer]]
^ka-Q0644

**ka-Q0645 · Edit the changed sentence**

ძალი【და】 დაბალი ხარ.

You're very short.

[[Georgian#^ka-Q0645-answer|Compare the answer]]
^ka-Q0645

**ka-Q0646 · Build the sentence**

Arrange: დაბალი / ხარ. / ძალიან

You're very short.

[[Georgian#^ka-Q0646-answer|Compare the answer]]
^ka-Q0646

**ka-Q0647 · Write a translation**

Write this in Georgian: I am very happy in Georgia.

[[Georgian#^ka-Q0647-answer|Compare the answer]]
^ka-Q0647

**ka-Q0648 · Explain the grammar**

ძალი【ან】 ბედნიერი ვარ საქართველოში.

I am very happy in Georgia.

[[Georgian#^ka-Q0648-answer|Compare the answer]]
^ka-Q0648

**ka-Q0649 · Fill the gap**

მე შენ ძალი____ მიყვარხარ.

I love you a lot.

[[Georgian#^ka-Q0649-answer|Compare the answer]]
^ka-Q0649

**ka-Q0650 · Choose the form**

მე შენ ძალი____ მიყვარხარ.

I love you a lot.

Choices: და / ან / მაგრამ

[[Georgian#^ka-Q0650-answer|Compare the answer]]
^ka-Q0650

**ka-Q0651 · Edit the changed sentence**

ამ ინფორმაციის საიმედოობაში ეჭვი არ მეპარება, რადგ【და】 ის სანდო ადამიანისგან მოდის.

I don't doubt the reliability of his information because it comes from a trustworthy person.

[[Georgian#^ka-Q0651-answer|Compare the answer]]
^ka-Q0651

**ka-Q0652 · Build the sentence**

Arrange: ადამიანისგან / ინფორმაციის / საიმედოობაში / მეპარება, / სანდო / რადგან / ეჭვი / არ / ის / ამ / მოდის.

I don't doubt the reliability of his information because it comes from a trustworthy person.

[[Georgian#^ka-Q0652-answer|Compare the answer]]
^ka-Q0652

**ka-Q0653 · Write a translation**

Write this in Georgian: They're Tom's.

[[Georgian#^ka-Q0653-answer|Compare the answer]]
^ka-Q0653

**ka-Q0654 · Explain the grammar**

ისინი არი【ან】 ტომის.

They're Tom's.

[[Georgian#^ka-Q0654-answer|Compare the answer]]
^ka-Q0654

**ka-Q0655 · Fill the gap**

ჩემს მეგობარ გოგონასთ____ ანალური სექსის შემდეგ, როგორც წესი, კარგი შხაპის მიღება გვჭირდება ხოლმე.

After having anal sex with my girlfriend, we usually need to have a good wash.

[[Georgian#^ka-Q0655-answer|Compare the answer]]
^ka-Q0655

**ka-Q0656 · Choose the form**

ჩემს მეგობარ გოგონასთ____ ანალური სექსის შემდეგ, როგორც წესი, კარგი შხაპის მიღება გვჭირდება ხოლმე.

After having anal sex with my girlfriend, we usually need to have a good wash.

Choices: მაგრამ / და / ან

[[Georgian#^ka-Q0656-answer|Compare the answer]]
^ka-Q0656

**ka-Q0657 · Edit the changed sentence**

ერთი ნაბიჯი 【მაგრამ】 მკვდარი კაცი ხარ.

One more step, and you'll be a dead man.

[[Georgian#^ka-Q0657-answer|Compare the answer]]
^ka-Q0657

**ka-Q0658 · Build the sentence**

Arrange: ხარ. / ნაბიჯი / და / მკვდარი / კაცი / ერთი

One more step, and you'll be a dead man.

[[Georgian#^ka-Q0658-answer|Compare the answer]]
^ka-Q0658

**ka-Q0659 · Write a translation**

Write this in Georgian: Is Tom younger than you?

[[Georgian#^ka-Q0659-answer|Compare the answer]]
^ka-Q0659

**ka-Q0660 · Explain the grammar**

არის ტომი უფრო ახალგაზრ【და】 ვიდრე შენ?

Is Tom younger than you?

[[Georgian#^ka-Q0660-answer|Compare the answer]]
^ka-Q0660

**ka-Q0661 · Fill the gap**

პოლიციამ დაუყოვნებლივი ქმედება მიიღო, აჯანყებასთ____ გასამკლავებლად.

The police took immediate action to deal with the riot.

[[Georgian#^ka-Q0661-answer|Compare the answer]]
^ka-Q0661

**ka-Q0662 · Choose the form**

პოლიციამ დაუყოვნებლივი ქმედება მიიღო, აჯანყებასთ____ გასამკლავებლად.

The police took immediate action to deal with the riot.

Choices: და / ან / მაგრამ

[[Georgian#^ka-Q0662-answer|Compare the answer]]
^ka-Q0662

**ka-Q0663 · Edit the changed sentence**

ის ლამაზია, 【და】 საშიში.

She's pretty, but dangerous.

[[Georgian#^ka-Q0663-answer|Compare the answer]]
^ka-Q0663

**ka-Q0664 · Build the sentence**

Arrange: საშიში. / ლამაზია, / ის / მაგრამ

She's pretty, but dangerous.

[[Georgian#^ka-Q0664-answer|Compare the answer]]
^ka-Q0664

**ka-Q0665 · Write a translation**

Write this in Georgian: He wrote this book in a very short time, spending just two weeks working on it.

[[Georgian#^ka-Q0665-answer|Compare the answer]]
^ka-Q0665

**ka-Q0666 · Explain the grammar**

მ【ან】 ეს წიგნი ძალიან მოკლე დროში დაწერა, მხოლოდ ორი კვირა მუშაობდა მასზე.

He wrote this book in a very short time, spending just two weeks working on it.

[[Georgian#^ka-Q0666-answer|Compare the answer]]
^ka-Q0666

**ka-Q0667 · Fill the gap**

ტომი წასვლას არ აპირებს შენთ____ ერთად, არა?

Tom isn't going with you, is he?

[[Georgian#^ka-Q0667-answer|Compare the answer]]
^ka-Q0667

**ka-Q0668 · Choose the form**

ტომი წასვლას არ აპირებს შენთ____ ერთად, არა?

Tom isn't going with you, is he?

Choices: ან / და / მაგრამ

[[Georgian#^ka-Q0668-answer|Compare the answer]]
^ka-Q0668

**ka-Q0669 · Edit the changed sentence**

წყალი ძალი【და】 ცხელი არის.

The water's very hot.

[[Georgian#^ka-Q0669-answer|Compare the answer]]
^ka-Q0669

**ka-Q0670 · Build the sentence**

Arrange: ძალიან / წყალი / არის. / ცხელი

The water's very hot.

[[Georgian#^ka-Q0670-answer|Compare the answer]]
^ka-Q0670

**ka-Q0671 · Write a translation**

Write this in Georgian: She attempted suicide.

[[Georgian#^ka-Q0671-answer|Compare the answer]]
^ka-Q0671

**ka-Q0672 · Explain the grammar**

მ【ან】 თავის მოკვლა სცადა.

She attempted suicide.

[[Georgian#^ka-Q0672-answer|Compare the answer]]
^ka-Q0672

**ka-Q0673 · Fill the gap**

მე ძალი____ მორცხვი ვარ.

I'm very shy.

[[Georgian#^ka-Q0673-answer|Compare the answer]]
^ka-Q0673

**ka-Q0674 · Choose the form**

მე ძალი____ მორცხვი ვარ.

I'm very shy.

Choices: და / მაგრამ / ან

[[Georgian#^ka-Q0674-answer|Compare the answer]]
^ka-Q0674

**ka-Q0675 · Edit the changed sentence**

გვინ【მაგრამ】 ბოსტონში და შიკაგოში წავიდეთ.

We want to go to Boston and Chicago.

[[Georgian#^ka-Q0675-answer|Compare the answer]]
^ka-Q0675

**ka-Q0676 · Build the sentence**

Arrange: ბოსტონში / და / წავიდეთ. / გვინდა / შიკაგოში

We want to go to Boston and Chicago.

[[Georgian#^ka-Q0676-answer|Compare the answer]]
^ka-Q0676

**ka-Q0677 · Write a translation**

Write this in Georgian: Are Tom and Mary in Australia?

[[Georgian#^ka-Q0677-answer|Compare the answer]]
^ka-Q0677

**ka-Q0678 · Explain the grammar**

ტომი 【და】 მარიამი არიან ავსტრალიაში?

Are Tom and Mary in Australia?

[[Georgian#^ka-Q0678-answer|Compare the answer]]
^ka-Q0678


### Postpositions and stance · 10 questions

**ka-Q0679 · Fill the gap**

ეს სიმსუქნის ____ წიგნია.

This is a book about obesity.

[[Georgian#^ka-Q0679-answer|Compare the answer]]
^ka-Q0679

**ka-Q0680 · Choose the form**

ეს სიმსუქნის ____ წიგნია.

This is a book about obesity.

Choices: შემდეგ / ალბათ / შესახებ

[[Georgian#^ka-Q0680-answer|Compare the answer]]
^ka-Q0680

**ka-Q0681 · Edit the changed sentence**

ეს საქართველოს 【შემდეგ】 წიგნია.

This is a book about Georgia.

[[Georgian#^ka-Q0681-answer|Compare the answer]]
^ka-Q0681

**ka-Q0682 · Build the sentence**

Arrange: ეს / საქართველოს / წიგნია. / შესახებ

This is a book about Georgia.

[[Georgian#^ka-Q0682-answer|Compare the answer]]
^ka-Q0682

**ka-Q0683 · Write a translation**

Write this in Georgian: I'll talk about you.

[[Georgian#^ka-Q0683-answer|Compare the answer]]
^ka-Q0683

**ka-Q0684 · Explain the grammar**

მე შენს 【შესახებ】 ვისაუბრებ.

I'll talk about you.

[[Georgian#^ka-Q0684-answer|Compare the answer]]
^ka-Q0684

**ka-Q0685 · Fill the gap**

სექსის დროს პრეზერვატივს თუკი არ გამოიყენებ, ____ დაავადება აიკიდო.

If you don't use a condom during sex, you can catch a disease.

[[Georgian#^ka-Q0685-answer|Compare the answer]]
^ka-Q0685

**ka-Q0686 · Choose the form**

სექსის დროს პრეზერვატივს თუკი არ გამოიყენებ, ____ დაავადება აიკიდო.

If you don't use a condom during sex, you can catch a disease.

Choices: შემდეგ / შესახებ / ალბათ / შეიძლება

[[Georgian#^ka-Q0686-answer|Compare the answer]]
^ka-Q0686

**ka-Q0687 · Edit the changed sentence**

ჩემი ცხოვრება ცარიელია მის 【შემდეგ】.

My life is empty without him.

[[Georgian#^ka-Q0687-answer|Compare the answer]]
^ka-Q0687

**ka-Q0688 · Build the sentence**

Arrange: მის / ჩემი / გარეშე. / ცხოვრება / ცარიელია

My life is empty without him.

[[Georgian#^ka-Q0688-answer|Compare the answer]]
^ka-Q0688


## Answers

The full sentence is a model. For translation, judge whether meaning and grammar are preserved. Each grammar rule above explains the form.

### Answers 1–50

**ka-Q0001** — მე სააფთიაქოში ვმუშაობ.

I work in a pharmacy.

Expected form: **მე**

Why: Independent pronouns. [[Georgian#^ka-Q0001|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%A1%E1%83%90%E1%83%90%E1%83%A4%E1%83%97%E1%83%98%E1%83%90%E1%83%A5%E1%83%9D%E1%83%A8%E1%83%98%20%E1%83%95%E1%83%9B%E1%83%A3%E1%83%A8%E1%83%90%E1%83%9D%E1%83%91.)
^ka-Q0001-answer

**ka-Q0002** — მე სააფთიაქოში ვმუშაობ.

I work in a pharmacy.

Expected form: **მე**

Why: Independent pronouns. [[Georgian#^ka-Q0002|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%A1%E1%83%90%E1%83%90%E1%83%A4%E1%83%97%E1%83%98%E1%83%90%E1%83%A5%E1%83%9D%E1%83%A8%E1%83%98%20%E1%83%95%E1%83%9B%E1%83%A3%E1%83%A8%E1%83%90%E1%83%9D%E1%83%91.)
^ka-Q0002-answer

**ka-Q0003** — მე დავიღალე, და დაწოლა მინდა.

I am tired and I want to go to bed.

Expected form: **მე**

Why: Independent pronouns. [[Georgian#^ka-Q0003|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%93%E1%83%90%E1%83%95%E1%83%98%E1%83%A6%E1%83%90%E1%83%9A%E1%83%94%2C%20%E1%83%93%E1%83%90%20%E1%83%93%E1%83%90%E1%83%AC%E1%83%9D%E1%83%9A%E1%83%90%20%E1%83%9B%E1%83%98%E1%83%9C%E1%83%93%E1%83%90.)
^ka-Q0003-answer

**ka-Q0004** — მე დავიღალე, და დაწოლა მინდა.

I am tired and I want to go to bed.

Why: Independent pronouns. [[Georgian#^ka-Q0004|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%93%E1%83%90%E1%83%95%E1%83%98%E1%83%A6%E1%83%90%E1%83%9A%E1%83%94%2C%20%E1%83%93%E1%83%90%20%E1%83%93%E1%83%90%E1%83%AC%E1%83%9D%E1%83%9A%E1%83%90%20%E1%83%9B%E1%83%98%E1%83%9C%E1%83%93%E1%83%90.)
^ka-Q0004-answer

**ka-Q0005** — მე ვფიქრობ, რომ მე ვარ მთვრალი.

I think I'm drunk.

Why: Independent pronouns. [[Georgian#^ka-Q0005|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%95%E1%83%A4%E1%83%98%E1%83%A5%E1%83%A0%E1%83%9D%E1%83%91%2C%20%E1%83%A0%E1%83%9D%E1%83%9B%20%E1%83%9B%E1%83%94%20%E1%83%95%E1%83%90%E1%83%A0%20%E1%83%9B%E1%83%97%E1%83%95%E1%83%A0%E1%83%90%E1%83%9A%E1%83%98.)
^ka-Q0005-answer

**ka-Q0006** — მე ვფიქრობ, რომ მე ვარ მთვრალი.

I think I'm drunk.

Pronouns identify participants; verbs often also encode participants, allowing omission. Is can refer to he/she/it without English grammatical gender. Georgian verb classes use distinct case alignments.

Why: Independent pronouns. [[Georgian#^ka-Q0006|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%95%E1%83%A4%E1%83%98%E1%83%A5%E1%83%A0%E1%83%9D%E1%83%91%2C%20%E1%83%A0%E1%83%9D%E1%83%9B%20%E1%83%9B%E1%83%94%20%E1%83%95%E1%83%90%E1%83%A0%20%E1%83%9B%E1%83%97%E1%83%95%E1%83%A0%E1%83%90%E1%83%9A%E1%83%98.)
^ka-Q0006-answer

**ka-Q0007** — თქვენ ძალიან დაბალი ხართ.

You're very short.

Expected form: **თქვენ**

Why: Independent pronouns. [[Georgian#^ka-Q0007|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%97%E1%83%A5%E1%83%95%E1%83%94%E1%83%9C%20%E1%83%AB%E1%83%90%E1%83%9A%E1%83%98%E1%83%90%E1%83%9C%20%E1%83%93%E1%83%90%E1%83%91%E1%83%90%E1%83%9A%E1%83%98%20%E1%83%AE%E1%83%90%E1%83%A0%E1%83%97.)
^ka-Q0007-answer

**ka-Q0008** — თქვენ ძალიან დაბალი ხართ.

You're very short.

Expected form: **თქვენ**

Why: Independent pronouns. [[Georgian#^ka-Q0008|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%97%E1%83%A5%E1%83%95%E1%83%94%E1%83%9C%20%E1%83%AB%E1%83%90%E1%83%9A%E1%83%98%E1%83%90%E1%83%9C%20%E1%83%93%E1%83%90%E1%83%91%E1%83%90%E1%83%9A%E1%83%98%20%E1%83%AE%E1%83%90%E1%83%A0%E1%83%97.)
^ka-Q0008-answer

**ka-Q0009** — როდიდან ჩვენ ვართ მეგობრები?

Since when are we friends?

Expected form: **ჩვენ**

Why: Independent pronouns. [[Georgian#^ka-Q0009|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A0%E1%83%9D%E1%83%93%E1%83%98%E1%83%93%E1%83%90%E1%83%9C%20%E1%83%A9%E1%83%95%E1%83%94%E1%83%9C%20%E1%83%95%E1%83%90%E1%83%A0%E1%83%97%20%E1%83%9B%E1%83%94%E1%83%92%E1%83%9D%E1%83%91%E1%83%A0%E1%83%94%E1%83%91%E1%83%98%3F)
^ka-Q0009-answer

**ka-Q0010** — როდიდან ჩვენ ვართ მეგობრები?

Since when are we friends?

Why: Independent pronouns. [[Georgian#^ka-Q0010|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A0%E1%83%9D%E1%83%93%E1%83%98%E1%83%93%E1%83%90%E1%83%9C%20%E1%83%A9%E1%83%95%E1%83%94%E1%83%9C%20%E1%83%95%E1%83%90%E1%83%A0%E1%83%97%20%E1%83%9B%E1%83%94%E1%83%92%E1%83%9D%E1%83%91%E1%83%A0%E1%83%94%E1%83%91%E1%83%98%3F)
^ka-Q0010-answer

**ka-Q0011** — მესაკუთრეს ახსნა არის გასაგები.

The owner's explanation is clear.

Why: Independent pronouns. [[Georgian#^ka-Q0011|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%E1%83%A1%E1%83%90%E1%83%99%E1%83%A3%E1%83%97%E1%83%A0%E1%83%94%E1%83%A1%20%E1%83%90%E1%83%AE%E1%83%A1%E1%83%9C%E1%83%90%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%92%E1%83%90%E1%83%A1%E1%83%90%E1%83%92%E1%83%94%E1%83%91%E1%83%98.)
^ka-Q0011-answer

**ka-Q0012** — მესაკუთრეს ახსნა არის გასაგები.

The owner's explanation is clear.

Pronouns identify participants; verbs often also encode participants, allowing omission. Is can refer to he/she/it without English grammatical gender. Georgian verb classes use distinct case alignments.

Why: Independent pronouns. [[Georgian#^ka-Q0012|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%E1%83%A1%E1%83%90%E1%83%99%E1%83%A3%E1%83%97%E1%83%A0%E1%83%94%E1%83%A1%20%E1%83%90%E1%83%AE%E1%83%A1%E1%83%9C%E1%83%90%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%92%E1%83%90%E1%83%A1%E1%83%90%E1%83%92%E1%83%94%E1%83%91%E1%83%98.)
^ka-Q0012-answer

**ka-Q0013** — ის არის მსოფლიო ჩემპიონი.

She's the world champion.

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0013|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%98%E1%83%A1%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%9B%E1%83%A1%E1%83%9D%E1%83%A4%E1%83%9A%E1%83%98%E1%83%9D%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%9E%E1%83%98%E1%83%9D%E1%83%9C%E1%83%98.)
^ka-Q0013-answer

**ka-Q0014** — ის არის მსოფლიო ჩემპიონი.

She's the world champion.

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0014|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%98%E1%83%A1%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%9B%E1%83%A1%E1%83%9D%E1%83%A4%E1%83%9A%E1%83%98%E1%83%9D%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%9E%E1%83%98%E1%83%9D%E1%83%9C%E1%83%98.)
^ka-Q0014-answer

**ka-Q0015** — შემიძლია ის გავაკეთო ერთ კვირაში.

I can do it in a week.

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0015|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A8%E1%83%94%E1%83%9B%E1%83%98%E1%83%AB%E1%83%9A%E1%83%98%E1%83%90%20%E1%83%98%E1%83%A1%20%E1%83%92%E1%83%90%E1%83%95%E1%83%90%E1%83%99%E1%83%94%E1%83%97%E1%83%9D%20%E1%83%94%E1%83%A0%E1%83%97%20%E1%83%99%E1%83%95%E1%83%98%E1%83%A0%E1%83%90%E1%83%A8%E1%83%98.)
^ka-Q0015-answer

**ka-Q0016** — შემიძლია ის გავაკეთო ერთ კვირაში.

I can do it in a week.

Why: Independent pronouns. [[Georgian#^ka-Q0016|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A8%E1%83%94%E1%83%9B%E1%83%98%E1%83%AB%E1%83%9A%E1%83%98%E1%83%90%20%E1%83%98%E1%83%A1%20%E1%83%92%E1%83%90%E1%83%95%E1%83%90%E1%83%99%E1%83%94%E1%83%97%E1%83%9D%20%E1%83%94%E1%83%A0%E1%83%97%20%E1%83%99%E1%83%95%E1%83%98%E1%83%A0%E1%83%90%E1%83%A8%E1%83%98.)
^ka-Q0016-answer

**ka-Q0017** — შენ ახლა ცრუობ ჩემთვის.

You're lying to me now.

Why: Independent pronouns. [[Georgian#^ka-Q0017|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A8%E1%83%94%E1%83%9C%20%E1%83%90%E1%83%AE%E1%83%9A%E1%83%90%20%E1%83%AA%E1%83%A0%E1%83%A3%E1%83%9D%E1%83%91%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%97%E1%83%95%E1%83%98%E1%83%A1.)
^ka-Q0017-answer

**ka-Q0018** — შენ ახლა ცრუობ ჩემთვის.

You're lying to me now.

Pronouns identify participants; verbs often also encode participants, allowing omission. Is can refer to he/she/it without English grammatical gender. Georgian verb classes use distinct case alignments.

Why: Independent pronouns. [[Georgian#^ka-Q0018|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A8%E1%83%94%E1%83%9C%20%E1%83%90%E1%83%AE%E1%83%9A%E1%83%90%20%E1%83%AA%E1%83%A0%E1%83%A3%E1%83%9D%E1%83%91%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%97%E1%83%95%E1%83%98%E1%83%A1.)
^ka-Q0018-answer

**ka-Q0019** — მინდა რომ სამაგიერო გადაგიხადოთ თქვენი გულკეთილობისთვის უახლოეს მომავალში.

I would like to repay your kindness in the near future.

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0019|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%98%E1%83%9C%E1%83%93%E1%83%90%20%E1%83%A0%E1%83%9D%E1%83%9B%20%E1%83%A1%E1%83%90%E1%83%9B%E1%83%90%E1%83%92%E1%83%98%E1%83%94%E1%83%A0%E1%83%9D%20%E1%83%92%E1%83%90%E1%83%93%E1%83%90%E1%83%92%E1%83%98%E1%83%AE%E1%83%90%E1%83%93%E1%83%9D%E1%83%97%20%E1%83%97%E1%83%A5%E1%83%95%E1%83%94%E1%83%9C%E1%83%98%20%E1%83%92%E1%83%A3%E1%83%9A%E1%83%99%E1%83%94%E1%83%97%E1%83%98%E1%83%9A%E1%83%9D%E1%83%91%E1%83%98%E1%83%A1%E1%83%97%E1%83%95%E1%83%98%E1%83%A1%20%E1%83%A3%E1%83%90%E1%83%AE%E1%83%9A%E1%83%9D%E1%83%94%E1%83%A1%20%E1%83%9B%E1%83%9D%E1%83%9B%E1%83%90%E1%83%95%E1%83%90%E1%83%9A%E1%83%A8%E1%83%98.)
^ka-Q0019-answer

**ka-Q0020** — მინდა რომ სამაგიერო გადაგიხადოთ თქვენი გულკეთილობისთვის უახლოეს მომავალში.

I would like to repay your kindness in the near future.

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0020|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%98%E1%83%9C%E1%83%93%E1%83%90%20%E1%83%A0%E1%83%9D%E1%83%9B%20%E1%83%A1%E1%83%90%E1%83%9B%E1%83%90%E1%83%92%E1%83%98%E1%83%94%E1%83%A0%E1%83%9D%20%E1%83%92%E1%83%90%E1%83%93%E1%83%90%E1%83%92%E1%83%98%E1%83%AE%E1%83%90%E1%83%93%E1%83%9D%E1%83%97%20%E1%83%97%E1%83%A5%E1%83%95%E1%83%94%E1%83%9C%E1%83%98%20%E1%83%92%E1%83%A3%E1%83%9A%E1%83%99%E1%83%94%E1%83%97%E1%83%98%E1%83%9A%E1%83%9D%E1%83%91%E1%83%98%E1%83%A1%E1%83%97%E1%83%95%E1%83%98%E1%83%A1%20%E1%83%A3%E1%83%90%E1%83%AE%E1%83%9A%E1%83%9D%E1%83%94%E1%83%A1%20%E1%83%9B%E1%83%9D%E1%83%9B%E1%83%90%E1%83%95%E1%83%90%E1%83%9A%E1%83%A8%E1%83%98.)
^ka-Q0020-answer

**ka-Q0021** — ტომი არის მიკრობიოლოგი.

Tom is a microbiologist.

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0021|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%98%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%9B%E1%83%98%E1%83%99%E1%83%A0%E1%83%9D%E1%83%91%E1%83%98%E1%83%9D%E1%83%9A%E1%83%9D%E1%83%92%E1%83%98.)
^ka-Q0021-answer

**ka-Q0022** — ტომი არის მიკრობიოლოგი.

Tom is a microbiologist.

Why: Independent pronouns. [[Georgian#^ka-Q0022|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%98%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%9B%E1%83%98%E1%83%99%E1%83%A0%E1%83%9D%E1%83%91%E1%83%98%E1%83%9D%E1%83%9A%E1%83%9D%E1%83%92%E1%83%98.)
^ka-Q0022-answer

**ka-Q0023** — იმის მიღება, რაც გინდა, ღიმილით უფრო მარტივია ვიდრე ხმლის წვერით.

It's easier to get what you want with a smile than with the tip of the sword.

Why: Independent pronouns. [[Georgian#^ka-Q0023|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%98%E1%83%9B%E1%83%98%E1%83%A1%20%E1%83%9B%E1%83%98%E1%83%A6%E1%83%94%E1%83%91%E1%83%90%2C%20%E1%83%A0%E1%83%90%E1%83%AA%20%E1%83%92%E1%83%98%E1%83%9C%E1%83%93%E1%83%90%2C%20%E1%83%A6%E1%83%98%E1%83%9B%E1%83%98%E1%83%9A%E1%83%98%E1%83%97%20%E1%83%A3%E1%83%A4%E1%83%A0%E1%83%9D%20%E1%83%9B%E1%83%90%E1%83%A0%E1%83%A2%E1%83%98%E1%83%95%E1%83%98%E1%83%90%20%E1%83%95%E1%83%98%E1%83%93%E1%83%A0%E1%83%94%20%E1%83%AE%E1%83%9B%E1%83%9A%E1%83%98%E1%83%A1%20%E1%83%AC%E1%83%95%E1%83%94%E1%83%A0%E1%83%98%E1%83%97.)
^ka-Q0023-answer

**ka-Q0024** — იმის მიღება, რაც გინდა, ღიმილით უფრო მარტივია ვიდრე ხმლის წვერით.

It's easier to get what you want with a smile than with the tip of the sword.

Pronouns identify participants; verbs often also encode participants, allowing omission. Is can refer to he/she/it without English grammatical gender. Georgian verb classes use distinct case alignments.

Why: Independent pronouns. [[Georgian#^ka-Q0024|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%98%E1%83%9B%E1%83%98%E1%83%A1%20%E1%83%9B%E1%83%98%E1%83%A6%E1%83%94%E1%83%91%E1%83%90%2C%20%E1%83%A0%E1%83%90%E1%83%AA%20%E1%83%92%E1%83%98%E1%83%9C%E1%83%93%E1%83%90%2C%20%E1%83%A6%E1%83%98%E1%83%9B%E1%83%98%E1%83%9A%E1%83%98%E1%83%97%20%E1%83%A3%E1%83%A4%E1%83%A0%E1%83%9D%20%E1%83%9B%E1%83%90%E1%83%A0%E1%83%A2%E1%83%98%E1%83%95%E1%83%98%E1%83%90%20%E1%83%95%E1%83%98%E1%83%93%E1%83%A0%E1%83%94%20%E1%83%AE%E1%83%9B%E1%83%9A%E1%83%98%E1%83%A1%20%E1%83%AC%E1%83%95%E1%83%94%E1%83%A0%E1%83%98%E1%83%97.)
^ka-Q0024-answer

**ka-Q0025** — შენ ამერიკელი ხარ?

Are you American?

Expected form: **შენ**

Why: Independent pronouns. [[Georgian#^ka-Q0025|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A8%E1%83%94%E1%83%9C%20%E1%83%90%E1%83%9B%E1%83%94%E1%83%A0%E1%83%98%E1%83%99%E1%83%94%E1%83%9A%E1%83%98%20%E1%83%AE%E1%83%90%E1%83%A0%3F)
^ka-Q0025-answer

**ka-Q0026** — შენ ამერიკელი ხარ?

Are you American?

Expected form: **შენ**

Why: Independent pronouns. [[Georgian#^ka-Q0026|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A8%E1%83%94%E1%83%9C%20%E1%83%90%E1%83%9B%E1%83%94%E1%83%A0%E1%83%98%E1%83%99%E1%83%94%E1%83%9A%E1%83%98%20%E1%83%AE%E1%83%90%E1%83%A0%3F)
^ka-Q0026-answer

**ka-Q0027** — ის კარს აღებს.

He opens the door.

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0027|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%98%E1%83%A1%20%E1%83%99%E1%83%90%E1%83%A0%E1%83%A1%20%E1%83%90%E1%83%A6%E1%83%94%E1%83%91%E1%83%A1.)
^ka-Q0027-answer

**ka-Q0028** — ის კარს აღებს.

He opens the door.

Why: Independent pronouns. [[Georgian#^ka-Q0028|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%98%E1%83%A1%20%E1%83%99%E1%83%90%E1%83%A0%E1%83%A1%20%E1%83%90%E1%83%A6%E1%83%94%E1%83%91%E1%83%A1.)
^ka-Q0028-answer

**ka-Q0029** — ტომი მარის მეზობელია, არა?

Tom is Mary's neighbor, isn't he?

Why: Independent pronouns. [[Georgian#^ka-Q0029|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%98%20%E1%83%9B%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%9B%E1%83%94%E1%83%96%E1%83%9D%E1%83%91%E1%83%94%E1%83%9A%E1%83%98%E1%83%90%2C%20%E1%83%90%E1%83%A0%E1%83%90%3F)
^ka-Q0029-answer

**ka-Q0030** — ტომი მარის მეზობელია, არა?

Tom is Mary's neighbor, isn't he?

Pronouns identify participants; verbs often also encode participants, allowing omission. Is can refer to he/she/it without English grammatical gender. Georgian verb classes use distinct case alignments.

Why: Independent pronouns. [[Georgian#^ka-Q0030|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%98%20%E1%83%9B%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%9B%E1%83%94%E1%83%96%E1%83%9D%E1%83%91%E1%83%94%E1%83%9A%E1%83%98%E1%83%90%2C%20%E1%83%90%E1%83%A0%E1%83%90%3F)
^ka-Q0030-answer

**ka-Q0031** — სად არის სასმელი წყალი?

Where is the water drinkable?

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0031|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A1%E1%83%90%E1%83%93%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%A1%E1%83%90%E1%83%A1%E1%83%9B%E1%83%94%E1%83%9A%E1%83%98%20%E1%83%AC%E1%83%A7%E1%83%90%E1%83%9A%E1%83%98%3F)
^ka-Q0031-answer

**ka-Q0032** — სად არის სასმელი წყალი?

Where is the water drinkable?

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0032|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A1%E1%83%90%E1%83%93%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%A1%E1%83%90%E1%83%A1%E1%83%9B%E1%83%94%E1%83%9A%E1%83%98%20%E1%83%AC%E1%83%A7%E1%83%90%E1%83%9A%E1%83%98%3F)
^ka-Q0032-answer

**ka-Q0033** — ორი კვირის წინ მე პირველად დისნეილენდს ვიყავი.

Two weeks ago, I visited Disneyland for the first time.

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0033|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9D%E1%83%A0%E1%83%98%20%E1%83%99%E1%83%95%E1%83%98%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%AC%E1%83%98%E1%83%9C%20%E1%83%9B%E1%83%94%20%E1%83%9E%E1%83%98%E1%83%A0%E1%83%95%E1%83%94%E1%83%9A%E1%83%90%E1%83%93%20%E1%83%93%E1%83%98%E1%83%A1%E1%83%9C%E1%83%94%E1%83%98%E1%83%9A%E1%83%94%E1%83%9C%E1%83%93%E1%83%A1%20%E1%83%95%E1%83%98%E1%83%A7%E1%83%90%E1%83%95%E1%83%98.)
^ka-Q0033-answer

**ka-Q0034** — ორი კვირის წინ მე პირველად დისნეილენდს ვიყავი.

Two weeks ago, I visited Disneyland for the first time.

Why: Independent pronouns. [[Georgian#^ka-Q0034|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9D%E1%83%A0%E1%83%98%20%E1%83%99%E1%83%95%E1%83%98%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%AC%E1%83%98%E1%83%9C%20%E1%83%9B%E1%83%94%20%E1%83%9E%E1%83%98%E1%83%A0%E1%83%95%E1%83%94%E1%83%9A%E1%83%90%E1%83%93%20%E1%83%93%E1%83%98%E1%83%A1%E1%83%9C%E1%83%94%E1%83%98%E1%83%9A%E1%83%94%E1%83%9C%E1%83%93%E1%83%A1%20%E1%83%95%E1%83%98%E1%83%A7%E1%83%90%E1%83%95%E1%83%98.)
^ka-Q0034-answer

**ka-Q0035** — მე მჯერა კაილი მინოუგის, 1998 წლის 12 ივნისიდან.

I've believed in Kylie Minogue since June 12, 1998.

Why: Independent pronouns. [[Georgian#^ka-Q0035|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%9B%E1%83%AF%E1%83%94%E1%83%A0%E1%83%90%20%E1%83%99%E1%83%90%E1%83%98%E1%83%9A%E1%83%98%20%E1%83%9B%E1%83%98%E1%83%9C%E1%83%9D%E1%83%A3%E1%83%92%E1%83%98%E1%83%A1%2C%201998%20%E1%83%AC%E1%83%9A%E1%83%98%E1%83%A1%2012%20%E1%83%98%E1%83%95%E1%83%9C%E1%83%98%E1%83%A1%E1%83%98%E1%83%93%E1%83%90%E1%83%9C.)
^ka-Q0035-answer

**ka-Q0036** — მე მჯერა კაილი მინოუგის, 1998 წლის 12 ივნისიდან.

I've believed in Kylie Minogue since June 12, 1998.

Pronouns identify participants; verbs often also encode participants, allowing omission. Is can refer to he/she/it without English grammatical gender. Georgian verb classes use distinct case alignments.

Why: Independent pronouns. [[Georgian#^ka-Q0036|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%9B%E1%83%AF%E1%83%94%E1%83%A0%E1%83%90%20%E1%83%99%E1%83%90%E1%83%98%E1%83%9A%E1%83%98%20%E1%83%9B%E1%83%98%E1%83%9C%E1%83%9D%E1%83%A3%E1%83%92%E1%83%98%E1%83%A1%2C%201998%20%E1%83%AC%E1%83%9A%E1%83%98%E1%83%A1%2012%20%E1%83%98%E1%83%95%E1%83%9C%E1%83%98%E1%83%A1%E1%83%98%E1%83%93%E1%83%90%E1%83%9C.)
^ka-Q0036-answer

**ka-Q0037** — მე მომწონს სიმარტივე

I like simplicity.

Expected form: **მე**

Why: Independent pronouns. [[Georgian#^ka-Q0037|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%9B%E1%83%9D%E1%83%9B%E1%83%AC%E1%83%9D%E1%83%9C%E1%83%A1%20%E1%83%A1%E1%83%98%E1%83%9B%E1%83%90%E1%83%A0%E1%83%A2%E1%83%98%E1%83%95%E1%83%94)
^ka-Q0037-answer

**ka-Q0038** — მე მომწონს სიმარტივე

I like simplicity.

Expected form: **მე**

Why: Independent pronouns. [[Georgian#^ka-Q0038|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%9B%E1%83%9D%E1%83%9B%E1%83%AC%E1%83%9D%E1%83%9C%E1%83%A1%20%E1%83%A1%E1%83%98%E1%83%9B%E1%83%90%E1%83%A0%E1%83%A2%E1%83%98%E1%83%95%E1%83%94)
^ka-Q0038-answer

**ka-Q0039** — მის გარეშე ცხოვრებას შევეჩვიე.

I learned to live without her.

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0039|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%98%E1%83%A1%20%E1%83%92%E1%83%90%E1%83%A0%E1%83%94%E1%83%A8%E1%83%94%20%E1%83%AA%E1%83%AE%E1%83%9D%E1%83%95%E1%83%A0%E1%83%94%E1%83%91%E1%83%90%E1%83%A1%20%E1%83%A8%E1%83%94%E1%83%95%E1%83%94%E1%83%A9%E1%83%95%E1%83%98%E1%83%94.)
^ka-Q0039-answer

**ka-Q0040** — მის გარეშე ცხოვრებას შევეჩვიე.

I learned to live without her.

Why: Independent pronouns. [[Georgian#^ka-Q0040|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%98%E1%83%A1%20%E1%83%92%E1%83%90%E1%83%A0%E1%83%94%E1%83%A8%E1%83%94%20%E1%83%AA%E1%83%AE%E1%83%9D%E1%83%95%E1%83%A0%E1%83%94%E1%83%91%E1%83%90%E1%83%A1%20%E1%83%A8%E1%83%94%E1%83%95%E1%83%94%E1%83%A9%E1%83%95%E1%83%98%E1%83%94.)
^ka-Q0040-answer

**ka-Q0041** — მე წერილს ვწერ ჩემი ქალიშვილისთვის.

I'm writing a letter to my daughter.

Why: Independent pronouns. [[Georgian#^ka-Q0041|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%AC%E1%83%94%E1%83%A0%E1%83%98%E1%83%9A%E1%83%A1%20%E1%83%95%E1%83%AC%E1%83%94%E1%83%A0%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%A5%E1%83%90%E1%83%9A%E1%83%98%E1%83%A8%E1%83%95%E1%83%98%E1%83%9A%E1%83%98%E1%83%A1%E1%83%97%E1%83%95%E1%83%98%E1%83%A1.)
^ka-Q0041-answer

**ka-Q0042** — მე წერილს ვწერ ჩემი ქალიშვილისთვის.

I'm writing a letter to my daughter.

Pronouns identify participants; verbs often also encode participants, allowing omission. Is can refer to he/she/it without English grammatical gender. Georgian verb classes use distinct case alignments.

Why: Independent pronouns. [[Georgian#^ka-Q0042|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%AC%E1%83%94%E1%83%A0%E1%83%98%E1%83%9A%E1%83%A1%20%E1%83%95%E1%83%AC%E1%83%94%E1%83%A0%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%A5%E1%83%90%E1%83%9A%E1%83%98%E1%83%A8%E1%83%95%E1%83%98%E1%83%9A%E1%83%98%E1%83%A1%E1%83%97%E1%83%95%E1%83%98%E1%83%A1.)
^ka-Q0042-answer

**ka-Q0043** — გამარჯობა, მე ვარ ნენსი.

Hello, I am Nancy.

Expected form: **მე**

Why: Independent pronouns. [[Georgian#^ka-Q0043|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%92%E1%83%90%E1%83%9B%E1%83%90%E1%83%A0%E1%83%AF%E1%83%9D%E1%83%91%E1%83%90%2C%20%E1%83%9B%E1%83%94%20%E1%83%95%E1%83%90%E1%83%A0%20%E1%83%9C%E1%83%94%E1%83%9C%E1%83%A1%E1%83%98.)
^ka-Q0043-answer

**ka-Q0044** — გამარჯობა, მე ვარ ნენსი.

Hello, I am Nancy.

Expected form: **მე**

Why: Independent pronouns. [[Georgian#^ka-Q0044|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%92%E1%83%90%E1%83%9B%E1%83%90%E1%83%A0%E1%83%AF%E1%83%9D%E1%83%91%E1%83%90%2C%20%E1%83%9B%E1%83%94%20%E1%83%95%E1%83%90%E1%83%A0%20%E1%83%9C%E1%83%94%E1%83%9C%E1%83%A1%E1%83%98.)
^ka-Q0044-answer

**ka-Q0045** — შენ ფული არ გაქვს.

You don't have money.

Expected form: **შენ**

Why: Independent pronouns. [[Georgian#^ka-Q0045|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A8%E1%83%94%E1%83%9C%20%E1%83%A4%E1%83%A3%E1%83%9A%E1%83%98%20%E1%83%90%E1%83%A0%20%E1%83%92%E1%83%90%E1%83%A5%E1%83%95%E1%83%A1.)
^ka-Q0045-answer

**ka-Q0046** — შენ ფული არ გაქვს.

You don't have money.

Why: Independent pronouns. [[Georgian#^ka-Q0046|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A8%E1%83%94%E1%83%9C%20%E1%83%A4%E1%83%A3%E1%83%9A%E1%83%98%20%E1%83%90%E1%83%A0%20%E1%83%92%E1%83%90%E1%83%A5%E1%83%95%E1%83%A1.)
^ka-Q0046-answer

**ka-Q0047** — ჩვენ ჯერ კიდევ ვმუშაობთ სახლში.

We still work at home.

Why: Independent pronouns. [[Georgian#^ka-Q0047|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A9%E1%83%95%E1%83%94%E1%83%9C%20%E1%83%AF%E1%83%94%E1%83%A0%20%E1%83%99%E1%83%98%E1%83%93%E1%83%94%E1%83%95%20%E1%83%95%E1%83%9B%E1%83%A3%E1%83%A8%E1%83%90%E1%83%9D%E1%83%91%E1%83%97%20%E1%83%A1%E1%83%90%E1%83%AE%E1%83%9A%E1%83%A8%E1%83%98.)
^ka-Q0047-answer

**ka-Q0048** — ჩვენ ჯერ კიდევ ვმუშაობთ სახლში.

We still work at home.

Pronouns identify participants; verbs often also encode participants, allowing omission. Is can refer to he/she/it without English grammatical gender. Georgian verb classes use distinct case alignments.

Why: Independent pronouns. [[Georgian#^ka-Q0048|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A9%E1%83%95%E1%83%94%E1%83%9C%20%E1%83%AF%E1%83%94%E1%83%A0%20%E1%83%99%E1%83%98%E1%83%93%E1%83%94%E1%83%95%20%E1%83%95%E1%83%9B%E1%83%A3%E1%83%A8%E1%83%90%E1%83%9D%E1%83%91%E1%83%97%20%E1%83%A1%E1%83%90%E1%83%AE%E1%83%9A%E1%83%A8%E1%83%98.)
^ka-Q0048-answer

**ka-Q0049** — არავის არ ესმის ჩემი.

Nobody understands me.

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0049|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%A0%E1%83%90%E1%83%95%E1%83%98%E1%83%A1%20%E1%83%90%E1%83%A0%20%E1%83%94%E1%83%A1%E1%83%9B%E1%83%98%E1%83%A1%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98.)
^ka-Q0049-answer

**ka-Q0050** — არავის არ ესმის ჩემი.

Nobody understands me.

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0050|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%A0%E1%83%90%E1%83%95%E1%83%98%E1%83%A1%20%E1%83%90%E1%83%A0%20%E1%83%94%E1%83%A1%E1%83%9B%E1%83%98%E1%83%A1%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98.)
^ka-Q0050-answer


### Answers 51–100

**ka-Q0051** — ესენი არიან სტუდენტები.

These are students.

Expected form: **არიან**

Why: Present copula. [[Georgian#^ka-Q0051|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%94%E1%83%A1%E1%83%94%E1%83%9C%E1%83%98%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%90%E1%83%9C%20%E1%83%A1%E1%83%A2%E1%83%A3%E1%83%93%E1%83%94%E1%83%9C%E1%83%A2%E1%83%94%E1%83%91%E1%83%98.)
^ka-Q0051-answer

**ka-Q0052** — ესენი არიან სტუდენტები.

These are students.

Why: Present copula. [[Georgian#^ka-Q0052|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%94%E1%83%A1%E1%83%94%E1%83%9C%E1%83%98%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%90%E1%83%9C%20%E1%83%A1%E1%83%A2%E1%83%A3%E1%83%93%E1%83%94%E1%83%9C%E1%83%A2%E1%83%94%E1%83%91%E1%83%98.)
^ka-Q0052-answer

**ka-Q0053** — არის ტომი უფრო უფროსი ვიდრე შენ?

Is Tom older than you?

Why: Present copula. [[Georgian#^ka-Q0053|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%98%20%E1%83%A3%E1%83%A4%E1%83%A0%E1%83%9D%20%E1%83%A3%E1%83%A4%E1%83%A0%E1%83%9D%E1%83%A1%E1%83%98%20%E1%83%95%E1%83%98%E1%83%93%E1%83%A0%E1%83%94%20%E1%83%A8%E1%83%94%E1%83%9C%3F)
^ka-Q0053-answer

**ka-Q0054** — არის ტომი უფრო უფროსი ვიდრე შენ?

Is Tom older than you?

Copula forms distinguish person and number: ვარ, ხარ, არის, ვართ, ხართ, არიან. Short/attached realisations occur in discourse. Learn a complete predicate rather than replacing every English be identically.

Why: Present copula. [[Georgian#^ka-Q0054|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%98%20%E1%83%A3%E1%83%A4%E1%83%A0%E1%83%9D%20%E1%83%A3%E1%83%A4%E1%83%A0%E1%83%9D%E1%83%A1%E1%83%98%20%E1%83%95%E1%83%98%E1%83%93%E1%83%A0%E1%83%94%20%E1%83%A8%E1%83%94%E1%83%9C%3F)
^ka-Q0054-answer

**ka-Q0055** — ორივეც კარგი მასწავლებლები არიან.

They are both good teachers.

Expected form: **არიან**

Why: Present copula. [[Georgian#^ka-Q0055|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9D%E1%83%A0%E1%83%98%E1%83%95%E1%83%94%E1%83%AA%20%E1%83%99%E1%83%90%E1%83%A0%E1%83%92%E1%83%98%20%E1%83%9B%E1%83%90%E1%83%A1%E1%83%AC%E1%83%90%E1%83%95%E1%83%9A%E1%83%94%E1%83%91%E1%83%9A%E1%83%94%E1%83%91%E1%83%98%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%90%E1%83%9C.)
^ka-Q0055-answer

**ka-Q0056** — ორივეც კარგი მასწავლებლები არიან.

They are both good teachers.

Expected form: **არიან**

Why: Present copula. [[Georgian#^ka-Q0056|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9D%E1%83%A0%E1%83%98%E1%83%95%E1%83%94%E1%83%AA%20%E1%83%99%E1%83%90%E1%83%A0%E1%83%92%E1%83%98%20%E1%83%9B%E1%83%90%E1%83%A1%E1%83%AC%E1%83%90%E1%83%95%E1%83%9A%E1%83%94%E1%83%91%E1%83%9A%E1%83%94%E1%83%91%E1%83%98%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%90%E1%83%9C.)
^ka-Q0056-answer

**ka-Q0057** — არის ტომი უფრო ახალგაზრდა ან უფრო მოხუცი ვიდრე შენ?

Is Tom younger or older than you?

Expected form: **არის**

Why: Present copula. [[Georgian#^ka-Q0057|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%98%20%E1%83%A3%E1%83%A4%E1%83%A0%E1%83%9D%20%E1%83%90%E1%83%AE%E1%83%90%E1%83%9A%E1%83%92%E1%83%90%E1%83%96%E1%83%A0%E1%83%93%E1%83%90%20%E1%83%90%E1%83%9C%20%E1%83%A3%E1%83%A4%E1%83%A0%E1%83%9D%20%E1%83%9B%E1%83%9D%E1%83%AE%E1%83%A3%E1%83%AA%E1%83%98%20%E1%83%95%E1%83%98%E1%83%93%E1%83%A0%E1%83%94%20%E1%83%A8%E1%83%94%E1%83%9C%3F)
^ka-Q0057-answer

**ka-Q0058** — არის ტომი უფრო ახალგაზრდა ან უფრო მოხუცი ვიდრე შენ?

Is Tom younger or older than you?

Why: Present copula. [[Georgian#^ka-Q0058|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%98%20%E1%83%A3%E1%83%A4%E1%83%A0%E1%83%9D%20%E1%83%90%E1%83%AE%E1%83%90%E1%83%9A%E1%83%92%E1%83%90%E1%83%96%E1%83%A0%E1%83%93%E1%83%90%20%E1%83%90%E1%83%9C%20%E1%83%A3%E1%83%A4%E1%83%A0%E1%83%9D%20%E1%83%9B%E1%83%9D%E1%83%AE%E1%83%A3%E1%83%AA%E1%83%98%20%E1%83%95%E1%83%98%E1%83%93%E1%83%A0%E1%83%94%20%E1%83%A8%E1%83%94%E1%83%9C%3F)
^ka-Q0058-answer

**ka-Q0059** — მე ამერიკიდან ვარ.

I come from America.

Why: Present copula. [[Georgian#^ka-Q0059|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%90%E1%83%9B%E1%83%94%E1%83%A0%E1%83%98%E1%83%99%E1%83%98%E1%83%93%E1%83%90%E1%83%9C%20%E1%83%95%E1%83%90%E1%83%A0.)
^ka-Q0059-answer

**ka-Q0060** — მე ამერიკიდან ვარ.

I come from America.

Copula forms distinguish person and number: ვარ, ხარ, არის, ვართ, ხართ, არიან. Short/attached realisations occur in discourse. Learn a complete predicate rather than replacing every English be identically.

Why: Present copula. [[Georgian#^ka-Q0060|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%90%E1%83%9B%E1%83%94%E1%83%A0%E1%83%98%E1%83%99%E1%83%98%E1%83%93%E1%83%90%E1%83%9C%20%E1%83%95%E1%83%90%E1%83%A0.)
^ka-Q0060-answer

**ka-Q0061** — შენ ძალიან დაბალი ხარ.

You're very short.

Expected form: **ხარ**

Why: Present copula. [[Georgian#^ka-Q0061|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A8%E1%83%94%E1%83%9C%20%E1%83%AB%E1%83%90%E1%83%9A%E1%83%98%E1%83%90%E1%83%9C%20%E1%83%93%E1%83%90%E1%83%91%E1%83%90%E1%83%9A%E1%83%98%20%E1%83%AE%E1%83%90%E1%83%A0.)
^ka-Q0061-answer

**ka-Q0062** — შენ ძალიან დაბალი ხარ.

You're very short.

Expected form: **ხარ**

Why: Present copula. [[Georgian#^ka-Q0062|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A8%E1%83%94%E1%83%9C%20%E1%83%AB%E1%83%90%E1%83%9A%E1%83%98%E1%83%90%E1%83%9C%20%E1%83%93%E1%83%90%E1%83%91%E1%83%90%E1%83%9A%E1%83%98%20%E1%83%AE%E1%83%90%E1%83%A0.)
^ka-Q0062-answer

**ka-Q0063** — მე სკოლაში მივდივარ.

I go to school.

Expected form: **ვარ**

Why: Present copula. [[Georgian#^ka-Q0063|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%A1%E1%83%99%E1%83%9D%E1%83%9A%E1%83%90%E1%83%A8%E1%83%98%20%E1%83%9B%E1%83%98%E1%83%95%E1%83%93%E1%83%98%E1%83%95%E1%83%90%E1%83%A0.)
^ka-Q0063-answer

**ka-Q0064** — მე სკოლაში მივდივარ.

I go to school.

Why: Present copula. [[Georgian#^ka-Q0064|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%A1%E1%83%99%E1%83%9D%E1%83%9A%E1%83%90%E1%83%A8%E1%83%98%20%E1%83%9B%E1%83%98%E1%83%95%E1%83%93%E1%83%98%E1%83%95%E1%83%90%E1%83%A0.)
^ka-Q0064-answer

**ka-Q0065** — 45 წლის ვარ.

I'm 45 years old.

Why: Present copula. [[Georgian#^ka-Q0065|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=45%20%E1%83%AC%E1%83%9A%E1%83%98%E1%83%A1%20%E1%83%95%E1%83%90%E1%83%A0.)
^ka-Q0065-answer

**ka-Q0066** — 45 წლის ვარ.

I'm 45 years old.

Copula forms distinguish person and number: ვარ, ხარ, არის, ვართ, ხართ, არიან. Short/attached realisations occur in discourse. Learn a complete predicate rather than replacing every English be identically.

Why: Present copula. [[Georgian#^ka-Q0066|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=45%20%E1%83%AC%E1%83%9A%E1%83%98%E1%83%A1%20%E1%83%95%E1%83%90%E1%83%A0.)
^ka-Q0066-answer

**ka-Q0067** — ვინ არის უფრო დაბალი, შენ თუ ტომი?

Who's shorter, you or Tom?

Expected form: **არის**

Why: Present copula. [[Georgian#^ka-Q0067|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%95%E1%83%98%E1%83%9C%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%A3%E1%83%A4%E1%83%A0%E1%83%9D%20%E1%83%93%E1%83%90%E1%83%91%E1%83%90%E1%83%9A%E1%83%98%2C%20%E1%83%A8%E1%83%94%E1%83%9C%20%E1%83%97%E1%83%A3%20%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%98%3F)
^ka-Q0067-answer

**ka-Q0068** — ვინ არის უფრო დაბალი, შენ თუ ტომი?

Who's shorter, you or Tom?

Expected form: **არის**

Why: Present copula. [[Georgian#^ka-Q0068|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%95%E1%83%98%E1%83%9C%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%A3%E1%83%A4%E1%83%A0%E1%83%9D%20%E1%83%93%E1%83%90%E1%83%91%E1%83%90%E1%83%9A%E1%83%98%2C%20%E1%83%A8%E1%83%94%E1%83%9C%20%E1%83%97%E1%83%A3%20%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%98%3F)
^ka-Q0068-answer

**ka-Q0069** — მე შენს მხარეს ვარ.

I'm on your side.

Expected form: **ვარ**

Why: Present copula. [[Georgian#^ka-Q0069|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%A8%E1%83%94%E1%83%9C%E1%83%A1%20%E1%83%9B%E1%83%AE%E1%83%90%E1%83%A0%E1%83%94%E1%83%A1%20%E1%83%95%E1%83%90%E1%83%A0.)
^ka-Q0069-answer

**ka-Q0070** — მე შენს მხარეს ვარ.

I'm on your side.

Why: Present copula. [[Georgian#^ka-Q0070|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%A8%E1%83%94%E1%83%9C%E1%83%A1%20%E1%83%9B%E1%83%AE%E1%83%90%E1%83%A0%E1%83%94%E1%83%A1%20%E1%83%95%E1%83%90%E1%83%A0.)
^ka-Q0070-answer

**ka-Q0071** — წყალი არის ძალიან ცხელი.

The water's very hot.

Why: Present copula. [[Georgian#^ka-Q0071|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%AC%E1%83%A7%E1%83%90%E1%83%9A%E1%83%98%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%AB%E1%83%90%E1%83%9A%E1%83%98%E1%83%90%E1%83%9C%20%E1%83%AA%E1%83%AE%E1%83%94%E1%83%9A%E1%83%98.)
^ka-Q0071-answer

**ka-Q0072** — წყალი არის ძალიან ცხელი.

The water's very hot.

Copula forms distinguish person and number: ვარ, ხარ, არის, ვართ, ხართ, არიან. Short/attached realisations occur in discourse. Learn a complete predicate rather than replacing every English be identically.

Why: Present copula. [[Georgian#^ka-Q0072|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%AC%E1%83%A7%E1%83%90%E1%83%9A%E1%83%98%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%AB%E1%83%90%E1%83%9A%E1%83%98%E1%83%90%E1%83%9C%20%E1%83%AA%E1%83%AE%E1%83%94%E1%83%9A%E1%83%98.)
^ka-Q0072-answer

**ka-Q0073** — სოფელში ძროხა არის.

There is a cow in the village.

Expected form: **არის**

Why: Present copula. [[Georgian#^ka-Q0073|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A1%E1%83%9D%E1%83%A4%E1%83%94%E1%83%9A%E1%83%A8%E1%83%98%20%E1%83%AB%E1%83%A0%E1%83%9D%E1%83%AE%E1%83%90%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1.)
^ka-Q0073-answer

**ka-Q0074** — სოფელში ძროხა არის.

There is a cow in the village.

Expected form: **არის**

Why: Present copula. [[Georgian#^ka-Q0074|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A1%E1%83%9D%E1%83%A4%E1%83%94%E1%83%9A%E1%83%A8%E1%83%98%20%E1%83%AB%E1%83%A0%E1%83%9D%E1%83%AE%E1%83%90%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1.)
^ka-Q0074-answer

**ka-Q0075** — ძალიან ბედნიერი ვარ ჯორჯიაში.

I am very happy in Georgia.

Expected form: **ვარ**

Why: Present copula. [[Georgian#^ka-Q0075|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%AB%E1%83%90%E1%83%9A%E1%83%98%E1%83%90%E1%83%9C%20%E1%83%91%E1%83%94%E1%83%93%E1%83%9C%E1%83%98%E1%83%94%E1%83%A0%E1%83%98%20%E1%83%95%E1%83%90%E1%83%A0%20%E1%83%AF%E1%83%9D%E1%83%A0%E1%83%AF%E1%83%98%E1%83%90%E1%83%A8%E1%83%98.)
^ka-Q0075-answer

**ka-Q0076** — ძალიან ბედნიერი ვარ ჯორჯიაში.

I am very happy in Georgia.

Why: Present copula. [[Georgian#^ka-Q0076|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%AB%E1%83%90%E1%83%9A%E1%83%98%E1%83%90%E1%83%9C%20%E1%83%91%E1%83%94%E1%83%93%E1%83%9C%E1%83%98%E1%83%94%E1%83%A0%E1%83%98%20%E1%83%95%E1%83%90%E1%83%A0%20%E1%83%AF%E1%83%9D%E1%83%A0%E1%83%AF%E1%83%98%E1%83%90%E1%83%A8%E1%83%98.)
^ka-Q0076-answer

**ka-Q0077** — მე ეგვიპტედან ვარ.

I am from Egypt.

Why: Present copula. [[Georgian#^ka-Q0077|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%94%E1%83%92%E1%83%95%E1%83%98%E1%83%9E%E1%83%A2%E1%83%94%E1%83%93%E1%83%90%E1%83%9C%20%E1%83%95%E1%83%90%E1%83%A0.)
^ka-Q0077-answer

**ka-Q0078** — მე ეგვიპტედან ვარ.

I am from Egypt.

Copula forms distinguish person and number: ვარ, ხარ, არის, ვართ, ხართ, არიან. Short/attached realisations occur in discourse. Learn a complete predicate rather than replacing every English be identically.

Why: Present copula. [[Georgian#^ka-Q0078|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%94%E1%83%92%E1%83%95%E1%83%98%E1%83%9E%E1%83%A2%E1%83%94%E1%83%93%E1%83%90%E1%83%9C%20%E1%83%95%E1%83%90%E1%83%A0.)
^ka-Q0078-answer

**ka-Q0079** — მე ვარ ჟურნალისტი.

I am a journalist.

Expected form: **ვარ**

Why: Present copula. [[Georgian#^ka-Q0079|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%95%E1%83%90%E1%83%A0%20%E1%83%9F%E1%83%A3%E1%83%A0%E1%83%9C%E1%83%90%E1%83%9A%E1%83%98%E1%83%A1%E1%83%A2%E1%83%98.)
^ka-Q0079-answer

**ka-Q0080** — მე ვარ ჟურნალისტი.

I am a journalist.

Expected form: **ვარ**

Why: Present copula. [[Georgian#^ka-Q0080|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%95%E1%83%90%E1%83%A0%20%E1%83%9F%E1%83%A3%E1%83%A0%E1%83%9C%E1%83%90%E1%83%9A%E1%83%98%E1%83%A1%E1%83%A2%E1%83%98.)
^ka-Q0080-answer

**ka-Q0081** — უკაცრავად. თქვენ ის პიროვნება ხართ?

Excuse me. Are you that person?

Expected form: **ხართ**

Why: Present copula. [[Georgian#^ka-Q0081|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A3%E1%83%99%E1%83%90%E1%83%AA%E1%83%A0%E1%83%90%E1%83%95%E1%83%90%E1%83%93.%20%E1%83%97%E1%83%A5%E1%83%95%E1%83%94%E1%83%9C%20%E1%83%98%E1%83%A1%20%E1%83%9E%E1%83%98%E1%83%A0%E1%83%9D%E1%83%95%E1%83%9C%E1%83%94%E1%83%91%E1%83%90%20%E1%83%AE%E1%83%90%E1%83%A0%E1%83%97%3F)
^ka-Q0081-answer

**ka-Q0082** — უკაცრავად. თქვენ ის პიროვნება ხართ?

Excuse me. Are you that person?

Why: Present copula. [[Georgian#^ka-Q0082|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A3%E1%83%99%E1%83%90%E1%83%AA%E1%83%A0%E1%83%90%E1%83%95%E1%83%90%E1%83%93.%20%E1%83%97%E1%83%A5%E1%83%95%E1%83%94%E1%83%9C%20%E1%83%98%E1%83%A1%20%E1%83%9E%E1%83%98%E1%83%A0%E1%83%9D%E1%83%95%E1%83%9C%E1%83%94%E1%83%91%E1%83%90%20%E1%83%AE%E1%83%90%E1%83%A0%E1%83%97%3F)
^ka-Q0082-answer

**ka-Q0083** — ეს არის გოგო.

This is a girl.

Why: Present copula. [[Georgian#^ka-Q0083|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%94%E1%83%A1%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%92%E1%83%9D%E1%83%92%E1%83%9D.)
^ka-Q0083-answer

**ka-Q0084** — ეს არის გოგო.

This is a girl.

Copula forms distinguish person and number: ვარ, ხარ, არის, ვართ, ხართ, არიან. Short/attached realisations occur in discourse. Learn a complete predicate rather than replacing every English be identically.

Why: Present copula. [[Georgian#^ka-Q0084|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%94%E1%83%A1%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%92%E1%83%9D%E1%83%92%E1%83%9D.)
^ka-Q0084-answer

**ka-Q0085** — აი შენი ძაღლი. სად არის ჩემი?

Here is your dog. Where is mine?

Expected form: **არის**

Why: Present copula. [[Georgian#^ka-Q0085|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%98%20%E1%83%A8%E1%83%94%E1%83%9C%E1%83%98%20%E1%83%AB%E1%83%90%E1%83%A6%E1%83%9A%E1%83%98.%20%E1%83%A1%E1%83%90%E1%83%93%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%3F)
^ka-Q0085-answer

**ka-Q0086** — აი შენი ძაღლი. სად არის ჩემი?

Here is your dog. Where is mine?

Expected form: **არის**

Why: Present copula. [[Georgian#^ka-Q0086|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%98%20%E1%83%A8%E1%83%94%E1%83%9C%E1%83%98%20%E1%83%AB%E1%83%90%E1%83%A6%E1%83%9A%E1%83%98.%20%E1%83%A1%E1%83%90%E1%83%93%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%3F)
^ka-Q0086-answer

**ka-Q0087** — მე ცხრამეტი წლის ვარ.

I am 19 years old.

Expected form: **ვარ**

Why: Present copula. [[Georgian#^ka-Q0087|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%AA%E1%83%AE%E1%83%A0%E1%83%90%E1%83%9B%E1%83%94%E1%83%A2%E1%83%98%20%E1%83%AC%E1%83%9A%E1%83%98%E1%83%A1%20%E1%83%95%E1%83%90%E1%83%A0.)
^ka-Q0087-answer

**ka-Q0088** — მე ცხრამეტი წლის ვარ.

I am 19 years old.

Why: Present copula. [[Georgian#^ka-Q0088|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%AA%E1%83%AE%E1%83%A0%E1%83%90%E1%83%9B%E1%83%94%E1%83%A2%E1%83%98%20%E1%83%AC%E1%83%9A%E1%83%98%E1%83%A1%20%E1%83%95%E1%83%90%E1%83%A0.)
^ka-Q0088-answer

**ka-Q0089** — მას მე უყვარვარ?

Does he love me?

Why: Present copula. [[Georgian#^ka-Q0089|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%90%E1%83%A1%20%E1%83%9B%E1%83%94%20%E1%83%A3%E1%83%A7%E1%83%95%E1%83%90%E1%83%A0%E1%83%95%E1%83%90%E1%83%A0%3F)
^ka-Q0089-answer

**ka-Q0090** — მას მე უყვარვარ?

Does he love me?

Copula forms distinguish person and number: ვარ, ხარ, არის, ვართ, ხართ, არიან. Short/attached realisations occur in discourse. Learn a complete predicate rather than replacing every English be identically.

Why: Present copula. [[Georgian#^ka-Q0090|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%90%E1%83%A1%20%E1%83%9B%E1%83%94%20%E1%83%A3%E1%83%A7%E1%83%95%E1%83%90%E1%83%A0%E1%83%95%E1%83%90%E1%83%A0%3F)
^ka-Q0090-answer

**ka-Q0091** — ძალიან დაბალი ხართ.

You're very short.

Expected form: **ხართ**

Why: Present copula. [[Georgian#^ka-Q0091|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%AB%E1%83%90%E1%83%9A%E1%83%98%E1%83%90%E1%83%9C%20%E1%83%93%E1%83%90%E1%83%91%E1%83%90%E1%83%9A%E1%83%98%20%E1%83%AE%E1%83%90%E1%83%A0%E1%83%97.)
^ka-Q0091-answer

**ka-Q0092** — ძალიან დაბალი ხართ.

You're very short.

Expected form: **ხართ**

Why: Present copula. [[Georgian#^ka-Q0092|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%AB%E1%83%90%E1%83%9A%E1%83%98%E1%83%90%E1%83%9C%20%E1%83%93%E1%83%90%E1%83%91%E1%83%90%E1%83%9A%E1%83%98%20%E1%83%AE%E1%83%90%E1%83%A0%E1%83%97.)
^ka-Q0092-answer

**ka-Q0093** — დიახ, მე საპოროდან ვარ.

Yes, I am from Sapporo.

Expected form: **ვარ**

Why: Present copula. [[Georgian#^ka-Q0093|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%93%E1%83%98%E1%83%90%E1%83%AE%2C%20%E1%83%9B%E1%83%94%20%E1%83%A1%E1%83%90%E1%83%9E%E1%83%9D%E1%83%A0%E1%83%9D%E1%83%93%E1%83%90%E1%83%9C%20%E1%83%95%E1%83%90%E1%83%A0.)
^ka-Q0093-answer

**ka-Q0094** — დიახ, მე საპოროდან ვარ.

Yes, I am from Sapporo.

Why: Present copula. [[Georgian#^ka-Q0094|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%93%E1%83%98%E1%83%90%E1%83%AE%2C%20%E1%83%9B%E1%83%94%20%E1%83%A1%E1%83%90%E1%83%9E%E1%83%9D%E1%83%A0%E1%83%9D%E1%83%93%E1%83%90%E1%83%9C%20%E1%83%95%E1%83%90%E1%83%A0.)
^ka-Q0094-answer

**ka-Q0095** — ზამთარში ცურვა არ არის საშიში ჯანმრთელი ხალხისთვის.

Winter swimming isn't dangerous for healthy people.

Why: Present copula. [[Georgian#^ka-Q0095|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%96%E1%83%90%E1%83%9B%E1%83%97%E1%83%90%E1%83%A0%E1%83%A8%E1%83%98%20%E1%83%AA%E1%83%A3%E1%83%A0%E1%83%95%E1%83%90%20%E1%83%90%E1%83%A0%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%A1%E1%83%90%E1%83%A8%E1%83%98%E1%83%A8%E1%83%98%20%E1%83%AF%E1%83%90%E1%83%9C%E1%83%9B%E1%83%A0%E1%83%97%E1%83%94%E1%83%9A%E1%83%98%20%E1%83%AE%E1%83%90%E1%83%9A%E1%83%AE%E1%83%98%E1%83%A1%E1%83%97%E1%83%95%E1%83%98%E1%83%A1.)
^ka-Q0095-answer

**ka-Q0096** — ზამთარში ცურვა არ არის საშიში ჯანმრთელი ხალხისთვის.

Winter swimming isn't dangerous for healthy people.

Copula forms distinguish person and number: ვარ, ხარ, არის, ვართ, ხართ, არიან. Short/attached realisations occur in discourse. Learn a complete predicate rather than replacing every English be identically.

Why: Present copula. [[Georgian#^ka-Q0096|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%96%E1%83%90%E1%83%9B%E1%83%97%E1%83%90%E1%83%A0%E1%83%A8%E1%83%98%20%E1%83%AA%E1%83%A3%E1%83%A0%E1%83%95%E1%83%90%20%E1%83%90%E1%83%A0%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%A1%E1%83%90%E1%83%A8%E1%83%98%E1%83%A8%E1%83%98%20%E1%83%AF%E1%83%90%E1%83%9C%E1%83%9B%E1%83%A0%E1%83%97%E1%83%94%E1%83%9A%E1%83%98%20%E1%83%AE%E1%83%90%E1%83%9A%E1%83%AE%E1%83%98%E1%83%A1%E1%83%97%E1%83%95%E1%83%98%E1%83%A1.)
^ka-Q0096-answer

**ka-Q0097** — მე არ ვარ ხნიერი.

I'm not old.

Expected form: **ვარ**

Why: Present copula. [[Georgian#^ka-Q0097|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%90%E1%83%A0%20%E1%83%95%E1%83%90%E1%83%A0%20%E1%83%AE%E1%83%9C%E1%83%98%E1%83%94%E1%83%A0%E1%83%98.)
^ka-Q0097-answer

**ka-Q0098** — მე არ ვარ ხნიერი.

I'm not old.

Expected form: **ვარ**

Why: Present copula. [[Georgian#^ka-Q0098|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%90%E1%83%A0%20%E1%83%95%E1%83%90%E1%83%A0%20%E1%83%AE%E1%83%9C%E1%83%98%E1%83%94%E1%83%A0%E1%83%98.)
^ka-Q0098-answer

**ka-Q0099** — ემილი და მელანი ინგლისელი არიან.

Emily and Melanie are English.

Expected form: **არიან**

Why: Present copula. [[Georgian#^ka-Q0099|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%94%E1%83%9B%E1%83%98%E1%83%9A%E1%83%98%20%E1%83%93%E1%83%90%20%E1%83%9B%E1%83%94%E1%83%9A%E1%83%90%E1%83%9C%E1%83%98%20%E1%83%98%E1%83%9C%E1%83%92%E1%83%9A%E1%83%98%E1%83%A1%E1%83%94%E1%83%9A%E1%83%98%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%90%E1%83%9C.)
^ka-Q0099-answer

**ka-Q0100** — ემილი და მელანი ინგლისელი არიან.

Emily and Melanie are English.

Why: Present copula. [[Georgian#^ka-Q0100|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%94%E1%83%9B%E1%83%98%E1%83%9A%E1%83%98%20%E1%83%93%E1%83%90%20%E1%83%9B%E1%83%94%E1%83%9A%E1%83%90%E1%83%9C%E1%83%98%20%E1%83%98%E1%83%9C%E1%83%92%E1%83%9A%E1%83%98%E1%83%A1%E1%83%94%E1%83%9A%E1%83%98%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%90%E1%83%9C.)
^ka-Q0100-answer


### Answers 101–150

**ka-Q0101** — უბრალოდ არ ვიცი რა უნდა ვთქვა.

I just don't know what to say.

Why: Negation. [[Georgian#^ka-Q0101|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A3%E1%83%91%E1%83%A0%E1%83%90%E1%83%9A%E1%83%9D%E1%83%93%20%E1%83%90%E1%83%A0%20%E1%83%95%E1%83%98%E1%83%AA%E1%83%98%20%E1%83%A0%E1%83%90%20%E1%83%A3%E1%83%9C%E1%83%93%E1%83%90%20%E1%83%95%E1%83%97%E1%83%A5%E1%83%95%E1%83%90.)
^ka-Q0101-answer

**ka-Q0102** — უბრალოდ არ ვიცი რა უნდა ვთქვა.

I just don't know what to say.

არ commonly negates; ვერ commonly expresses inability/failure to perform. Their interpretations interact with the verb and context. They are not interchangeable merely because both create a negative meaning.

Why: Negation. [[Georgian#^ka-Q0102|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A3%E1%83%91%E1%83%A0%E1%83%90%E1%83%9A%E1%83%9D%E1%83%93%20%E1%83%90%E1%83%A0%20%E1%83%95%E1%83%98%E1%83%AA%E1%83%98%20%E1%83%A0%E1%83%90%20%E1%83%A3%E1%83%9C%E1%83%93%E1%83%90%20%E1%83%95%E1%83%97%E1%83%A5%E1%83%95%E1%83%90.)
^ka-Q0102-answer

**ka-Q0103** — მე დავიფიცე, რომ არასოდეს აღარ დაველაპარაკები.

I vowed that I would never speak to her again.

Expected form: **არ**

Why: Negation. [[Georgian#^ka-Q0103|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%93%E1%83%90%E1%83%95%E1%83%98%E1%83%A4%E1%83%98%E1%83%AA%E1%83%94%2C%20%E1%83%A0%E1%83%9D%E1%83%9B%20%E1%83%90%E1%83%A0%E1%83%90%E1%83%A1%E1%83%9D%E1%83%93%E1%83%94%E1%83%A1%20%E1%83%90%E1%83%A6%E1%83%90%E1%83%A0%20%E1%83%93%E1%83%90%E1%83%95%E1%83%94%E1%83%9A%E1%83%90%E1%83%9E%E1%83%90%E1%83%A0%E1%83%90%E1%83%99%E1%83%94%E1%83%91%E1%83%98.)
^ka-Q0103-answer

**ka-Q0104** — მე დავიფიცე, რომ არასოდეს აღარ დაველაპარაკები.

I vowed that I would never speak to her again.

Expected form: **არ**

Why: Negation. [[Georgian#^ka-Q0104|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%93%E1%83%90%E1%83%95%E1%83%98%E1%83%A4%E1%83%98%E1%83%AA%E1%83%94%2C%20%E1%83%A0%E1%83%9D%E1%83%9B%20%E1%83%90%E1%83%A0%E1%83%90%E1%83%A1%E1%83%9D%E1%83%93%E1%83%94%E1%83%A1%20%E1%83%90%E1%83%A6%E1%83%90%E1%83%A0%20%E1%83%93%E1%83%90%E1%83%95%E1%83%94%E1%83%9A%E1%83%90%E1%83%9E%E1%83%90%E1%83%A0%E1%83%90%E1%83%99%E1%83%94%E1%83%91%E1%83%98.)
^ka-Q0104-answer

**ka-Q0105** — ამ ქალაქში არ ვცხოვრობ.

I don't live in this city.

Expected form: **არ**

Why: Negation. [[Georgian#^ka-Q0105|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%9B%20%E1%83%A5%E1%83%90%E1%83%9A%E1%83%90%E1%83%A5%E1%83%A8%E1%83%98%20%E1%83%90%E1%83%A0%20%E1%83%95%E1%83%AA%E1%83%AE%E1%83%9D%E1%83%95%E1%83%A0%E1%83%9D%E1%83%91.)
^ka-Q0105-answer

**ka-Q0106** — ამ ქალაქში არ ვცხოვრობ.

I don't live in this city.

Why: Negation. [[Georgian#^ka-Q0106|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%9B%20%E1%83%A5%E1%83%90%E1%83%9A%E1%83%90%E1%83%A5%E1%83%A8%E1%83%98%20%E1%83%90%E1%83%A0%20%E1%83%95%E1%83%AA%E1%83%AE%E1%83%9D%E1%83%95%E1%83%A0%E1%83%9D%E1%83%91.)
^ka-Q0106-answer

**ka-Q0107** — მენადი არ გაგიჟდება.

Mennad won't get mad.

Why: Negation. [[Georgian#^ka-Q0107|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%E1%83%9C%E1%83%90%E1%83%93%E1%83%98%20%E1%83%90%E1%83%A0%20%E1%83%92%E1%83%90%E1%83%92%E1%83%98%E1%83%9F%E1%83%93%E1%83%94%E1%83%91%E1%83%90.)
^ka-Q0107-answer

**ka-Q0108** — მენადი არ გაგიჟდება.

Mennad won't get mad.

არ commonly negates; ვერ commonly expresses inability/failure to perform. Their interpretations interact with the verb and context. They are not interchangeable merely because both create a negative meaning.

Why: Negation. [[Georgian#^ka-Q0108|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%E1%83%9C%E1%83%90%E1%83%93%E1%83%98%20%E1%83%90%E1%83%A0%20%E1%83%92%E1%83%90%E1%83%92%E1%83%98%E1%83%9F%E1%83%93%E1%83%94%E1%83%91%E1%83%90.)
^ka-Q0108-answer

**ka-Q0109** — დათვმა არცერთი ქვა არ დატოვა ამოუტრიალებელი მსუქალი ხოჭოების ძებნისას.

The bear left no stone unturned in his search for fat bugs under the rocks.

Expected form: **არ**

Why: Negation. [[Georgian#^ka-Q0109|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%93%E1%83%90%E1%83%97%E1%83%95%E1%83%9B%E1%83%90%20%E1%83%90%E1%83%A0%E1%83%AA%E1%83%94%E1%83%A0%E1%83%97%E1%83%98%20%E1%83%A5%E1%83%95%E1%83%90%20%E1%83%90%E1%83%A0%20%E1%83%93%E1%83%90%E1%83%A2%E1%83%9D%E1%83%95%E1%83%90%20%E1%83%90%E1%83%9B%E1%83%9D%E1%83%A3%E1%83%A2%E1%83%A0%E1%83%98%E1%83%90%E1%83%9A%E1%83%94%E1%83%91%E1%83%94%E1%83%9A%E1%83%98%20%E1%83%9B%E1%83%A1%E1%83%A3%E1%83%A5%E1%83%90%E1%83%9A%E1%83%98%20%E1%83%AE%E1%83%9D%E1%83%AD%E1%83%9D%E1%83%94%E1%83%91%E1%83%98%E1%83%A1%20%E1%83%AB%E1%83%94%E1%83%91%E1%83%9C%E1%83%98%E1%83%A1%E1%83%90%E1%83%A1.)
^ka-Q0109-answer

**ka-Q0110** — დათვმა არცერთი ქვა არ დატოვა ამოუტრიალებელი მსუქალი ხოჭოების ძებნისას.

The bear left no stone unturned in his search for fat bugs under the rocks.

Expected form: **არ**

Why: Negation. [[Georgian#^ka-Q0110|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%93%E1%83%90%E1%83%97%E1%83%95%E1%83%9B%E1%83%90%20%E1%83%90%E1%83%A0%E1%83%AA%E1%83%94%E1%83%A0%E1%83%97%E1%83%98%20%E1%83%A5%E1%83%95%E1%83%90%20%E1%83%90%E1%83%A0%20%E1%83%93%E1%83%90%E1%83%A2%E1%83%9D%E1%83%95%E1%83%90%20%E1%83%90%E1%83%9B%E1%83%9D%E1%83%A3%E1%83%A2%E1%83%A0%E1%83%98%E1%83%90%E1%83%9A%E1%83%94%E1%83%91%E1%83%94%E1%83%9A%E1%83%98%20%E1%83%9B%E1%83%A1%E1%83%A3%E1%83%A5%E1%83%90%E1%83%9A%E1%83%98%20%E1%83%AE%E1%83%9D%E1%83%AD%E1%83%9D%E1%83%94%E1%83%91%E1%83%98%E1%83%A1%20%E1%83%AB%E1%83%94%E1%83%91%E1%83%9C%E1%83%98%E1%83%A1%E1%83%90%E1%83%A1.)
^ka-Q0110-answer

**ka-Q0111** — წიგნმა "ჩამითრია" და შენი ხმა ვერ გავიგე.

I was absorbed in a book and didn't hear you call.

Expected form: **ვერ**

Why: Negation. [[Georgian#^ka-Q0111|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%AC%E1%83%98%E1%83%92%E1%83%9C%E1%83%9B%E1%83%90%20%22%E1%83%A9%E1%83%90%E1%83%9B%E1%83%98%E1%83%97%E1%83%A0%E1%83%98%E1%83%90%22%20%E1%83%93%E1%83%90%20%E1%83%A8%E1%83%94%E1%83%9C%E1%83%98%20%E1%83%AE%E1%83%9B%E1%83%90%20%E1%83%95%E1%83%94%E1%83%A0%20%E1%83%92%E1%83%90%E1%83%95%E1%83%98%E1%83%92%E1%83%94.)
^ka-Q0111-answer

**ka-Q0112** — წიგნმა "ჩამითრია" და შენი ხმა ვერ გავიგე.

I was absorbed in a book and didn't hear you call.

Why: Negation. [[Georgian#^ka-Q0112|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%AC%E1%83%98%E1%83%92%E1%83%9C%E1%83%9B%E1%83%90%20%22%E1%83%A9%E1%83%90%E1%83%9B%E1%83%98%E1%83%97%E1%83%A0%E1%83%98%E1%83%90%22%20%E1%83%93%E1%83%90%20%E1%83%A8%E1%83%94%E1%83%9C%E1%83%98%20%E1%83%AE%E1%83%9B%E1%83%90%20%E1%83%95%E1%83%94%E1%83%A0%20%E1%83%92%E1%83%90%E1%83%95%E1%83%98%E1%83%92%E1%83%94.)
^ka-Q0112-answer

**ka-Q0113** — არ უნდა ქარხანაში მუშაობა.

He doesn't want to work in a factory.

Why: Negation. [[Georgian#^ka-Q0113|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%A0%20%E1%83%A3%E1%83%9C%E1%83%93%E1%83%90%20%E1%83%A5%E1%83%90%E1%83%A0%E1%83%AE%E1%83%90%E1%83%9C%E1%83%90%E1%83%A8%E1%83%98%20%E1%83%9B%E1%83%A3%E1%83%A8%E1%83%90%E1%83%9D%E1%83%91%E1%83%90.)
^ka-Q0113-answer

**ka-Q0114** — არ უნდა ქარხანაში მუშაობა.

He doesn't want to work in a factory.

არ commonly negates; ვერ commonly expresses inability/failure to perform. Their interpretations interact with the verb and context. They are not interchangeable merely because both create a negative meaning.

Why: Negation. [[Georgian#^ka-Q0114|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%A0%20%E1%83%A3%E1%83%9C%E1%83%93%E1%83%90%20%E1%83%A5%E1%83%90%E1%83%A0%E1%83%AE%E1%83%90%E1%83%9C%E1%83%90%E1%83%A8%E1%83%98%20%E1%83%9B%E1%83%A3%E1%83%A8%E1%83%90%E1%83%9D%E1%83%91%E1%83%90.)
^ka-Q0114-answer

**ka-Q0115** — არ მინდა, რომ თომი ჩემი პატრონი იყოს, რადგან ის იდიოტია.

I don't want Tom to be my boss because he is an idiot.

Expected form: **არ**

Why: Negation. [[Georgian#^ka-Q0115|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%A0%20%E1%83%9B%E1%83%98%E1%83%9C%E1%83%93%E1%83%90%2C%20%E1%83%A0%E1%83%9D%E1%83%9B%20%E1%83%97%E1%83%9D%E1%83%9B%E1%83%98%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%9E%E1%83%90%E1%83%A2%E1%83%A0%E1%83%9D%E1%83%9C%E1%83%98%20%E1%83%98%E1%83%A7%E1%83%9D%E1%83%A1%2C%20%E1%83%A0%E1%83%90%E1%83%93%E1%83%92%E1%83%90%E1%83%9C%20%E1%83%98%E1%83%A1%20%E1%83%98%E1%83%93%E1%83%98%E1%83%9D%E1%83%A2%E1%83%98%E1%83%90.)
^ka-Q0115-answer

**ka-Q0116** — არ მინდა, რომ თომი ჩემი პატრონი იყოს, რადგან ის იდიოტია.

I don't want Tom to be my boss because he is an idiot.

Expected form: **არ**

Why: Negation. [[Georgian#^ka-Q0116|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%A0%20%E1%83%9B%E1%83%98%E1%83%9C%E1%83%93%E1%83%90%2C%20%E1%83%A0%E1%83%9D%E1%83%9B%20%E1%83%97%E1%83%9D%E1%83%9B%E1%83%98%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%9E%E1%83%90%E1%83%A2%E1%83%A0%E1%83%9D%E1%83%9C%E1%83%98%20%E1%83%98%E1%83%A7%E1%83%9D%E1%83%A1%2C%20%E1%83%A0%E1%83%90%E1%83%93%E1%83%92%E1%83%90%E1%83%9C%20%E1%83%98%E1%83%A1%20%E1%83%98%E1%83%93%E1%83%98%E1%83%9D%E1%83%A2%E1%83%98%E1%83%90.)
^ka-Q0116-answer

**ka-Q0117** — ტუალეტის ქაღალდი არ იყო.

There was no toilet paper.

Expected form: **არ**

Why: Negation. [[Georgian#^ka-Q0117|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A2%E1%83%A3%E1%83%90%E1%83%9A%E1%83%94%E1%83%A2%E1%83%98%E1%83%A1%20%E1%83%A5%E1%83%90%E1%83%A6%E1%83%90%E1%83%9A%E1%83%93%E1%83%98%20%E1%83%90%E1%83%A0%20%E1%83%98%E1%83%A7%E1%83%9D.)
^ka-Q0117-answer

**ka-Q0118** — ტუალეტის ქაღალდი არ იყო.

There was no toilet paper.

Why: Negation. [[Georgian#^ka-Q0118|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A2%E1%83%A3%E1%83%90%E1%83%9A%E1%83%94%E1%83%A2%E1%83%98%E1%83%A1%20%E1%83%A5%E1%83%90%E1%83%A6%E1%83%90%E1%83%9A%E1%83%93%E1%83%98%20%E1%83%90%E1%83%A0%20%E1%83%98%E1%83%A7%E1%83%9D.)
^ka-Q0118-answer

**ka-Q0119** — სახლიდან გასხვლა არ მინდა ამ საღამოს.

I don't want to go outside this afternoon.

Why: Negation. [[Georgian#^ka-Q0119|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A1%E1%83%90%E1%83%AE%E1%83%9A%E1%83%98%E1%83%93%E1%83%90%E1%83%9C%20%E1%83%92%E1%83%90%E1%83%A1%E1%83%AE%E1%83%95%E1%83%9A%E1%83%90%20%E1%83%90%E1%83%A0%20%E1%83%9B%E1%83%98%E1%83%9C%E1%83%93%E1%83%90%20%E1%83%90%E1%83%9B%20%E1%83%A1%E1%83%90%E1%83%A6%E1%83%90%E1%83%9B%E1%83%9D%E1%83%A1.)
^ka-Q0119-answer

**ka-Q0120** — სახლიდან გასხვლა არ მინდა ამ საღამოს.

I don't want to go outside this afternoon.

არ commonly negates; ვერ commonly expresses inability/failure to perform. Their interpretations interact with the verb and context. They are not interchangeable merely because both create a negative meaning.

Why: Negation. [[Georgian#^ka-Q0120|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A1%E1%83%90%E1%83%AE%E1%83%9A%E1%83%98%E1%83%93%E1%83%90%E1%83%9C%20%E1%83%92%E1%83%90%E1%83%A1%E1%83%AE%E1%83%95%E1%83%9A%E1%83%90%20%E1%83%90%E1%83%A0%20%E1%83%9B%E1%83%98%E1%83%9C%E1%83%93%E1%83%90%20%E1%83%90%E1%83%9B%20%E1%83%A1%E1%83%90%E1%83%A6%E1%83%90%E1%83%9B%E1%83%9D%E1%83%A1.)
^ka-Q0120-answer

**ka-Q0121** — მე არ მაქვს ალტერნატივა.

I have no alternatives.

Expected form: **არ**

Why: Negation. [[Georgian#^ka-Q0121|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%90%E1%83%A0%20%E1%83%9B%E1%83%90%E1%83%A5%E1%83%95%E1%83%A1%20%E1%83%90%E1%83%9A%E1%83%A2%E1%83%94%E1%83%A0%E1%83%9C%E1%83%90%E1%83%A2%E1%83%98%E1%83%95%E1%83%90.)
^ka-Q0121-answer

**ka-Q0122** — მე არ მაქვს ალტერნატივა.

I have no alternatives.

Expected form: **არ**

Why: Negation. [[Georgian#^ka-Q0122|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%90%E1%83%A0%20%E1%83%9B%E1%83%90%E1%83%A5%E1%83%95%E1%83%A1%20%E1%83%90%E1%83%9A%E1%83%A2%E1%83%94%E1%83%A0%E1%83%9C%E1%83%90%E1%83%A2%E1%83%98%E1%83%95%E1%83%90.)
^ka-Q0122-answer

**ka-Q0123** — მე შენს უკან ვარ.

I'm behind you.

Expected form: **არ**

Why: Negation. [[Georgian#^ka-Q0123|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%A8%E1%83%94%E1%83%9C%E1%83%A1%20%E1%83%A3%E1%83%99%E1%83%90%E1%83%9C%20%E1%83%95%E1%83%90%E1%83%A0.)
^ka-Q0123-answer

**ka-Q0124** — მე შენს უკან ვარ.

I'm behind you.

Why: Negation. [[Georgian#^ka-Q0124|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%A8%E1%83%94%E1%83%9C%E1%83%A1%20%E1%83%A3%E1%83%99%E1%83%90%E1%83%9C%20%E1%83%95%E1%83%90%E1%83%A0.)
^ka-Q0124-answer

**ka-Q0125** — მე არა ვარ დიქტატორი.

I'm not a dictator.

Why: Negation. [[Georgian#^ka-Q0125|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%90%E1%83%A0%E1%83%90%20%E1%83%95%E1%83%90%E1%83%A0%20%E1%83%93%E1%83%98%E1%83%A5%E1%83%A2%E1%83%90%E1%83%A2%E1%83%9D%E1%83%A0%E1%83%98.)
^ka-Q0125-answer

**ka-Q0126** — მე არა ვარ დიქტატორი.

I'm not a dictator.

არ commonly negates; ვერ commonly expresses inability/failure to perform. Their interpretations interact with the verb and context. They are not interchangeable merely because both create a negative meaning.

Why: Negation. [[Georgian#^ka-Q0126|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%90%E1%83%A0%E1%83%90%20%E1%83%95%E1%83%90%E1%83%A0%20%E1%83%93%E1%83%98%E1%83%A5%E1%83%A2%E1%83%90%E1%83%A2%E1%83%9D%E1%83%A0%E1%83%98.)
^ka-Q0126-answer

**ka-Q0127** — პედროს არ ჰყავს დები.

Pedro has no sisters.

Expected form: **არ**

Why: Negation. [[Georgian#^ka-Q0127|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9E%E1%83%94%E1%83%93%E1%83%A0%E1%83%9D%E1%83%A1%20%E1%83%90%E1%83%A0%20%E1%83%B0%E1%83%A7%E1%83%90%E1%83%95%E1%83%A1%20%E1%83%93%E1%83%94%E1%83%91%E1%83%98.)
^ka-Q0127-answer

**ka-Q0128** — პედროს არ ჰყავს დები.

Pedro has no sisters.

Expected form: **არ**

Why: Negation. [[Georgian#^ka-Q0128|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9E%E1%83%94%E1%83%93%E1%83%A0%E1%83%9D%E1%83%A1%20%E1%83%90%E1%83%A0%20%E1%83%B0%E1%83%A7%E1%83%90%E1%83%95%E1%83%A1%20%E1%83%93%E1%83%94%E1%83%91%E1%83%98.)
^ka-Q0128-answer

**ka-Q0129** — მე ლამაზი ვარ?

Am I pretty?

Expected form: **არ**

Why: Negation. [[Georgian#^ka-Q0129|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%9A%E1%83%90%E1%83%9B%E1%83%90%E1%83%96%E1%83%98%20%E1%83%95%E1%83%90%E1%83%A0%3F)
^ka-Q0129-answer

**ka-Q0130** — მე ლამაზი ვარ?

Am I pretty?

Why: Negation. [[Georgian#^ka-Q0130|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%9A%E1%83%90%E1%83%9B%E1%83%90%E1%83%96%E1%83%98%20%E1%83%95%E1%83%90%E1%83%A0%3F)
^ka-Q0130-answer

**ka-Q0131** — თომი დესერტს არ ჭამს.

Tom doesn't eat dessert.

Why: Negation. [[Georgian#^ka-Q0131|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%97%E1%83%9D%E1%83%9B%E1%83%98%20%E1%83%93%E1%83%94%E1%83%A1%E1%83%94%E1%83%A0%E1%83%A2%E1%83%A1%20%E1%83%90%E1%83%A0%20%E1%83%AD%E1%83%90%E1%83%9B%E1%83%A1.)
^ka-Q0131-answer

**ka-Q0132** — თომი დესერტს არ ჭამს.

Tom doesn't eat dessert.

არ commonly negates; ვერ commonly expresses inability/failure to perform. Their interpretations interact with the verb and context. They are not interchangeable merely because both create a negative meaning.

Why: Negation. [[Georgian#^ka-Q0132|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%97%E1%83%9D%E1%83%9B%E1%83%98%20%E1%83%93%E1%83%94%E1%83%A1%E1%83%94%E1%83%A0%E1%83%A2%E1%83%A1%20%E1%83%90%E1%83%A0%20%E1%83%AD%E1%83%90%E1%83%9B%E1%83%A1.)
^ka-Q0132-answer

**ka-Q0133** — ჩემი სინდისი არ არის სუფთა.

My conscience is not clean.

Expected form: **არ**

Why: Negation. [[Georgian#^ka-Q0133|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%A1%E1%83%98%E1%83%9C%E1%83%93%E1%83%98%E1%83%A1%E1%83%98%20%E1%83%90%E1%83%A0%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%A1%E1%83%A3%E1%83%A4%E1%83%97%E1%83%90.)
^ka-Q0133-answer

**ka-Q0134** — ჩემი სინდისი არ არის სუფთა.

My conscience is not clean.

Expected form: **არ**

Why: Negation. [[Georgian#^ka-Q0134|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%A1%E1%83%98%E1%83%9C%E1%83%93%E1%83%98%E1%83%A1%E1%83%98%20%E1%83%90%E1%83%A0%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%A1%E1%83%A3%E1%83%A4%E1%83%97%E1%83%90.)
^ka-Q0134-answer

**ka-Q0135** — ბებიაჩემს არ აქვს ინტერნეტი.

My grandma doesn't have the internet.

Expected form: **არ**

Why: Negation. [[Georgian#^ka-Q0135|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%91%E1%83%94%E1%83%91%E1%83%98%E1%83%90%E1%83%A9%E1%83%94%E1%83%9B%E1%83%A1%20%E1%83%90%E1%83%A0%20%E1%83%90%E1%83%A5%E1%83%95%E1%83%A1%20%E1%83%98%E1%83%9C%E1%83%A2%E1%83%94%E1%83%A0%E1%83%9C%E1%83%94%E1%83%A2%E1%83%98.)
^ka-Q0135-answer

**ka-Q0136** — ბებიაჩემს არ აქვს ინტერნეტი.

My grandma doesn't have the internet.

Why: Negation. [[Georgian#^ka-Q0136|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%91%E1%83%94%E1%83%91%E1%83%98%E1%83%90%E1%83%A9%E1%83%94%E1%83%9B%E1%83%A1%20%E1%83%90%E1%83%A0%20%E1%83%90%E1%83%A5%E1%83%95%E1%83%A1%20%E1%83%98%E1%83%9C%E1%83%A2%E1%83%94%E1%83%A0%E1%83%9C%E1%83%94%E1%83%A2%E1%83%98.)
^ka-Q0136-answer

**ka-Q0137** — აზრი აღარ აქვს ამაზე ფიქრს.

It's useless to keep on thinking any more.

Why: Negation. [[Georgian#^ka-Q0137|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%96%E1%83%A0%E1%83%98%20%E1%83%90%E1%83%A6%E1%83%90%E1%83%A0%20%E1%83%90%E1%83%A5%E1%83%95%E1%83%A1%20%E1%83%90%E1%83%9B%E1%83%90%E1%83%96%E1%83%94%20%E1%83%A4%E1%83%98%E1%83%A5%E1%83%A0%E1%83%A1.)
^ka-Q0137-answer

**ka-Q0138** — აზრი აღარ აქვს ამაზე ფიქრს.

It's useless to keep on thinking any more.

არ commonly negates; ვერ commonly expresses inability/failure to perform. Their interpretations interact with the verb and context. They are not interchangeable merely because both create a negative meaning.

Why: Negation. [[Georgian#^ka-Q0138|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%96%E1%83%A0%E1%83%98%20%E1%83%90%E1%83%A6%E1%83%90%E1%83%A0%20%E1%83%90%E1%83%A5%E1%83%95%E1%83%A1%20%E1%83%90%E1%83%9B%E1%83%90%E1%83%96%E1%83%94%20%E1%83%A4%E1%83%98%E1%83%A5%E1%83%A0%E1%83%A1.)
^ka-Q0138-answer

**ka-Q0139** — მე ვერ შეასრულა ტომ.

I couldn't stop Tom.

Expected form: **ვერ**

Why: Negation. [[Georgian#^ka-Q0139|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%95%E1%83%94%E1%83%A0%20%E1%83%A8%E1%83%94%E1%83%90%E1%83%A1%E1%83%A0%E1%83%A3%E1%83%9A%E1%83%90%20%E1%83%A2%E1%83%9D%E1%83%9B.)
^ka-Q0139-answer

**ka-Q0140** — მე ვერ შეასრულა ტომ.

I couldn't stop Tom.

Expected form: **ვერ**

Why: Negation. [[Georgian#^ka-Q0140|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%95%E1%83%94%E1%83%A0%20%E1%83%A8%E1%83%94%E1%83%90%E1%83%A1%E1%83%A0%E1%83%A3%E1%83%9A%E1%83%90%20%E1%83%A2%E1%83%9D%E1%83%9B.)
^ka-Q0140-answer

**ka-Q0141** — მე ცალთვალა ვარ.

I'm one-eyed.

Expected form: **არ**

Why: Negation. [[Georgian#^ka-Q0141|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%AA%E1%83%90%E1%83%9A%E1%83%97%E1%83%95%E1%83%90%E1%83%9A%E1%83%90%20%E1%83%95%E1%83%90%E1%83%A0.)
^ka-Q0141-answer

**ka-Q0142** — მე ცალთვალა ვარ.

I'm one-eyed.

Why: Negation. [[Georgian#^ka-Q0142|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%AA%E1%83%90%E1%83%9A%E1%83%97%E1%83%95%E1%83%90%E1%83%9A%E1%83%90%20%E1%83%95%E1%83%90%E1%83%A0.)
^ka-Q0142-answer

**ka-Q0143** — მე ამ ტენის კლუბის წევრი ვარ.

I'm a member of the tennis club.

Why: Negation. [[Georgian#^ka-Q0143|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%90%E1%83%9B%20%E1%83%A2%E1%83%94%E1%83%9C%E1%83%98%E1%83%A1%20%E1%83%99%E1%83%9A%E1%83%A3%E1%83%91%E1%83%98%E1%83%A1%20%E1%83%AC%E1%83%94%E1%83%95%E1%83%A0%E1%83%98%20%E1%83%95%E1%83%90%E1%83%A0.)
^ka-Q0143-answer

**ka-Q0144** — მე ამ ტენის კლუბის წევრი ვარ.

I'm a member of the tennis club.

არ commonly negates; ვერ commonly expresses inability/failure to perform. Their interpretations interact with the verb and context. They are not interchangeable merely because both create a negative meaning.

Why: Negation. [[Georgian#^ka-Q0144|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%90%E1%83%9B%20%E1%83%A2%E1%83%94%E1%83%9C%E1%83%98%E1%83%A1%20%E1%83%99%E1%83%9A%E1%83%A3%E1%83%91%E1%83%98%E1%83%A1%20%E1%83%AC%E1%83%94%E1%83%95%E1%83%A0%E1%83%98%20%E1%83%95%E1%83%90%E1%83%A0.)
^ka-Q0144-answer

**ka-Q0145** — ხილი და ბოსტნეული ჯანმრთელი არიან, მაგრამ ჩვენ არ ვიცით რატომ.

Fruit and vegetables are good for your health, but we don't know why.

Expected form: **არ**

Why: Negation. [[Georgian#^ka-Q0145|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%AE%E1%83%98%E1%83%9A%E1%83%98%20%E1%83%93%E1%83%90%20%E1%83%91%E1%83%9D%E1%83%A1%E1%83%A2%E1%83%9C%E1%83%94%E1%83%A3%E1%83%9A%E1%83%98%20%E1%83%AF%E1%83%90%E1%83%9C%E1%83%9B%E1%83%A0%E1%83%97%E1%83%94%E1%83%9A%E1%83%98%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%90%E1%83%9C%2C%20%E1%83%9B%E1%83%90%E1%83%92%E1%83%A0%E1%83%90%E1%83%9B%20%E1%83%A9%E1%83%95%E1%83%94%E1%83%9C%20%E1%83%90%E1%83%A0%20%E1%83%95%E1%83%98%E1%83%AA%E1%83%98%E1%83%97%20%E1%83%A0%E1%83%90%E1%83%A2%E1%83%9D%E1%83%9B.)
^ka-Q0145-answer

**ka-Q0146** — ხილი და ბოსტნეული ჯანმრთელი არიან, მაგრამ ჩვენ არ ვიცით რატომ.

Fruit and vegetables are good for your health, but we don't know why.

Expected form: **არ**

Why: Negation. [[Georgian#^ka-Q0146|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%AE%E1%83%98%E1%83%9A%E1%83%98%20%E1%83%93%E1%83%90%20%E1%83%91%E1%83%9D%E1%83%A1%E1%83%A2%E1%83%9C%E1%83%94%E1%83%A3%E1%83%9A%E1%83%98%20%E1%83%AF%E1%83%90%E1%83%9C%E1%83%9B%E1%83%A0%E1%83%97%E1%83%94%E1%83%9A%E1%83%98%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%90%E1%83%9C%2C%20%E1%83%9B%E1%83%90%E1%83%92%E1%83%A0%E1%83%90%E1%83%9B%20%E1%83%A9%E1%83%95%E1%83%94%E1%83%9C%20%E1%83%90%E1%83%A0%20%E1%83%95%E1%83%98%E1%83%AA%E1%83%98%E1%83%97%20%E1%83%A0%E1%83%90%E1%83%A2%E1%83%9D%E1%83%9B.)
^ka-Q0146-answer

**ka-Q0147** — მას მე არ უყვარვარ.

He doesn't love me.

Expected form: **არ**

Why: Negation. [[Georgian#^ka-Q0147|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%90%E1%83%A1%20%E1%83%9B%E1%83%94%20%E1%83%90%E1%83%A0%20%E1%83%A3%E1%83%A7%E1%83%95%E1%83%90%E1%83%A0%E1%83%95%E1%83%90%E1%83%A0.)
^ka-Q0147-answer

**ka-Q0148** — მას მე არ უყვარვარ.

He doesn't love me.

Why: Negation. [[Georgian#^ka-Q0148|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%90%E1%83%A1%20%E1%83%9B%E1%83%94%20%E1%83%90%E1%83%A0%20%E1%83%A3%E1%83%A7%E1%83%95%E1%83%90%E1%83%A0%E1%83%95%E1%83%90%E1%83%A0.)
^ka-Q0148-answer

**ka-Q0149** — არ მინდა, რომ თომი ჩემი პატრონი იყოს.

I don't want Tom to be my boss.

Why: Negation. [[Georgian#^ka-Q0149|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%A0%20%E1%83%9B%E1%83%98%E1%83%9C%E1%83%93%E1%83%90%2C%20%E1%83%A0%E1%83%9D%E1%83%9B%20%E1%83%97%E1%83%9D%E1%83%9B%E1%83%98%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%9E%E1%83%90%E1%83%A2%E1%83%A0%E1%83%9D%E1%83%9C%E1%83%98%20%E1%83%98%E1%83%A7%E1%83%9D%E1%83%A1.)
^ka-Q0149-answer

**ka-Q0150** — არ მინდა, რომ თომი ჩემი პატრონი იყოს.

I don't want Tom to be my boss.

არ commonly negates; ვერ commonly expresses inability/failure to perform. Their interpretations interact with the verb and context. They are not interchangeable merely because both create a negative meaning.

Why: Negation. [[Georgian#^ka-Q0150|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%A0%20%E1%83%9B%E1%83%98%E1%83%9C%E1%83%93%E1%83%90%2C%20%E1%83%A0%E1%83%9D%E1%83%9B%20%E1%83%97%E1%83%9D%E1%83%9B%E1%83%98%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%9E%E1%83%90%E1%83%A2%E1%83%A0%E1%83%9D%E1%83%9C%E1%83%98%20%E1%83%98%E1%83%A7%E1%83%9D%E1%83%A1.)
^ka-Q0150-answer


### Answers 151–200

**ka-Q0151** — გელამ თქვა, რომ მამა წავიდა ქალაქში.

Gela said that Father went into the city.

Expected form: **ამ**

Why: Demonstratives. [[Georgian#^ka-Q0151|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%92%E1%83%94%E1%83%9A%E1%83%90%E1%83%9B%20%E1%83%97%E1%83%A5%E1%83%95%E1%83%90%2C%20%E1%83%A0%E1%83%9D%E1%83%9B%20%E1%83%9B%E1%83%90%E1%83%9B%E1%83%90%20%E1%83%AC%E1%83%90%E1%83%95%E1%83%98%E1%83%93%E1%83%90%20%E1%83%A5%E1%83%90%E1%83%9A%E1%83%90%E1%83%A5%E1%83%A8%E1%83%98.)
^ka-Q0151-answer

**ka-Q0152** — გელამ თქვა, რომ მამა წავიდა ქალაქში.

Gela said that Father went into the city.

Expected form: **ამ**

Why: Demonstratives. [[Georgian#^ka-Q0152|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%92%E1%83%94%E1%83%9A%E1%83%90%E1%83%9B%20%E1%83%97%E1%83%A5%E1%83%95%E1%83%90%2C%20%E1%83%A0%E1%83%9D%E1%83%9B%20%E1%83%9B%E1%83%90%E1%83%9B%E1%83%90%20%E1%83%AC%E1%83%90%E1%83%95%E1%83%98%E1%83%93%E1%83%90%20%E1%83%A5%E1%83%90%E1%83%9A%E1%83%90%E1%83%A5%E1%83%A8%E1%83%98.)
^ka-Q0152-answer

**ka-Q0153** — ჩვეს სკოლას ჯამში აქვს ოცდაოთხი კლასი.

Our school has twenty-four classes in all.

Expected form: **ეს**

Why: Demonstratives. [[Georgian#^ka-Q0153|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A9%E1%83%95%E1%83%94%E1%83%A1%20%E1%83%A1%E1%83%99%E1%83%9D%E1%83%9A%E1%83%90%E1%83%A1%20%E1%83%AF%E1%83%90%E1%83%9B%E1%83%A8%E1%83%98%20%E1%83%90%E1%83%A5%E1%83%95%E1%83%A1%20%E1%83%9D%E1%83%AA%E1%83%93%E1%83%90%E1%83%9D%E1%83%97%E1%83%AE%E1%83%98%20%E1%83%99%E1%83%9A%E1%83%90%E1%83%A1%E1%83%98.)
^ka-Q0153-answer

**ka-Q0154** — ჩვეს სკოლას ჯამში აქვს ოცდაოთხი კლასი.

Our school has twenty-four classes in all.

Why: Demonstratives. [[Georgian#^ka-Q0154|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A9%E1%83%95%E1%83%94%E1%83%A1%20%E1%83%A1%E1%83%99%E1%83%9D%E1%83%9A%E1%83%90%E1%83%A1%20%E1%83%AF%E1%83%90%E1%83%9B%E1%83%A8%E1%83%98%20%E1%83%90%E1%83%A5%E1%83%95%E1%83%A1%20%E1%83%9D%E1%83%AA%E1%83%93%E1%83%90%E1%83%9D%E1%83%97%E1%83%AE%E1%83%98%20%E1%83%99%E1%83%9A%E1%83%90%E1%83%A1%E1%83%98.)
^ka-Q0154-answer

**ka-Q0155** — შრომამ შექმნა ადამიანი.

Labor created man.

Why: Demonstratives. [[Georgian#^ka-Q0155|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A8%E1%83%A0%E1%83%9D%E1%83%9B%E1%83%90%E1%83%9B%20%E1%83%A8%E1%83%94%E1%83%A5%E1%83%9B%E1%83%9C%E1%83%90%20%E1%83%90%E1%83%93%E1%83%90%E1%83%9B%E1%83%98%E1%83%90%E1%83%9C%E1%83%98.)
^ka-Q0155-answer

**ka-Q0156** — შრომამ შექმნა ადამიანი.

Labor created man.

Demonstrative forms change with case and construction. Es often points to this; is to that or a previously mentioned referent. The following noun’s relation determines an inflected form.

Why: Demonstratives. [[Georgian#^ka-Q0156|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A8%E1%83%A0%E1%83%9D%E1%83%9B%E1%83%90%E1%83%9B%20%E1%83%A8%E1%83%94%E1%83%A5%E1%83%9B%E1%83%9C%E1%83%90%20%E1%83%90%E1%83%93%E1%83%90%E1%83%9B%E1%83%98%E1%83%90%E1%83%9C%E1%83%98.)
^ka-Q0156-answer

**ka-Q0157** — რა ფერის იყო ჰენრი IV თეთრი ცხენი?

What colour was Henri IV's white horse?

Expected form: **ის**

Why: Demonstratives. [[Georgian#^ka-Q0157|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A0%E1%83%90%20%E1%83%A4%E1%83%94%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%98%E1%83%A7%E1%83%9D%20%E1%83%B0%E1%83%94%E1%83%9C%E1%83%A0%E1%83%98%20IV%20%E1%83%97%E1%83%94%E1%83%97%E1%83%A0%E1%83%98%20%E1%83%AA%E1%83%AE%E1%83%94%E1%83%9C%E1%83%98%3F)
^ka-Q0157-answer

**ka-Q0158** — რა ფერის იყო ჰენრი IV თეთრი ცხენი?

What colour was Henri IV's white horse?

Expected form: **ის**

Why: Demonstratives. [[Georgian#^ka-Q0158|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A0%E1%83%90%20%E1%83%A4%E1%83%94%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%98%E1%83%A7%E1%83%9D%20%E1%83%B0%E1%83%94%E1%83%9C%E1%83%A0%E1%83%98%20IV%20%E1%83%97%E1%83%94%E1%83%97%E1%83%A0%E1%83%98%20%E1%83%AA%E1%83%AE%E1%83%94%E1%83%9C%E1%83%98%3F)
^ka-Q0158-answer

**ka-Q0159** — ეს ჩემი ძაღლია.

This is my dog.

Expected form: **ეს**

Why: Demonstratives. [[Georgian#^ka-Q0159|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%94%E1%83%A1%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%AB%E1%83%90%E1%83%A6%E1%83%9A%E1%83%98%E1%83%90.)
^ka-Q0159-answer

**ka-Q0160** — ეს ჩემი ძაღლია.

This is my dog.

Why: Demonstratives. [[Georgian#^ka-Q0160|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%94%E1%83%A1%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%AB%E1%83%90%E1%83%A6%E1%83%9A%E1%83%98%E1%83%90.)
^ka-Q0160-answer

**ka-Q0161** — ეს ხე ჩემმა ბაბუამ დარგო.

My grandfather planted this tree.

Why: Demonstratives. [[Georgian#^ka-Q0161|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%94%E1%83%A1%20%E1%83%AE%E1%83%94%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%9B%E1%83%90%20%E1%83%91%E1%83%90%E1%83%91%E1%83%A3%E1%83%90%E1%83%9B%20%E1%83%93%E1%83%90%E1%83%A0%E1%83%92%E1%83%9D.)
^ka-Q0161-answer

**ka-Q0162** — ეს ხე ჩემმა ბაბუამ დარგო.

My grandfather planted this tree.

Demonstrative forms change with case and construction. Es often points to this; is to that or a previously mentioned referent. The following noun’s relation determines an inflected form.

Why: Demonstratives. [[Georgian#^ka-Q0162|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%94%E1%83%A1%20%E1%83%AE%E1%83%94%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%9B%E1%83%90%20%E1%83%91%E1%83%90%E1%83%91%E1%83%A3%E1%83%90%E1%83%9B%20%E1%83%93%E1%83%90%E1%83%A0%E1%83%92%E1%83%9D.)
^ka-Q0162-answer

**ka-Q0163** — ტომს უჭირს გაუმკლავდეს ფაქტს, რომ მისმა შვილმა თავი მოიკლა.

Tom is having trouble coping with the fact that his son committed suicide.

Expected form: **ეს**

Why: Demonstratives. [[Georgian#^ka-Q0163|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%A1%20%E1%83%A3%E1%83%AD%E1%83%98%E1%83%A0%E1%83%A1%20%E1%83%92%E1%83%90%E1%83%A3%E1%83%9B%E1%83%99%E1%83%9A%E1%83%90%E1%83%95%E1%83%93%E1%83%94%E1%83%A1%20%E1%83%A4%E1%83%90%E1%83%A5%E1%83%A2%E1%83%A1%2C%20%E1%83%A0%E1%83%9D%E1%83%9B%20%E1%83%9B%E1%83%98%E1%83%A1%E1%83%9B%E1%83%90%20%E1%83%A8%E1%83%95%E1%83%98%E1%83%9A%E1%83%9B%E1%83%90%20%E1%83%97%E1%83%90%E1%83%95%E1%83%98%20%E1%83%9B%E1%83%9D%E1%83%98%E1%83%99%E1%83%9A%E1%83%90.)
^ka-Q0163-answer

**ka-Q0164** — ტომს უჭირს გაუმკლავდეს ფაქტს, რომ მისმა შვილმა თავი მოიკლა.

Tom is having trouble coping with the fact that his son committed suicide.

Expected form: **ეს**

Why: Demonstratives. [[Georgian#^ka-Q0164|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%A1%20%E1%83%A3%E1%83%AD%E1%83%98%E1%83%A0%E1%83%A1%20%E1%83%92%E1%83%90%E1%83%A3%E1%83%9B%E1%83%99%E1%83%9A%E1%83%90%E1%83%95%E1%83%93%E1%83%94%E1%83%A1%20%E1%83%A4%E1%83%90%E1%83%A5%E1%83%A2%E1%83%A1%2C%20%E1%83%A0%E1%83%9D%E1%83%9B%20%E1%83%9B%E1%83%98%E1%83%A1%E1%83%9B%E1%83%90%20%E1%83%A8%E1%83%95%E1%83%98%E1%83%9A%E1%83%9B%E1%83%90%20%E1%83%97%E1%83%90%E1%83%95%E1%83%98%20%E1%83%9B%E1%83%9D%E1%83%98%E1%83%99%E1%83%9A%E1%83%90.)
^ka-Q0164-answer

**ka-Q0165** — სილამაზე რეკომენდაციის წერილია, რომლის იგნორირებაც თითქმის შეუძლებელია.

Beauty is a letter of recommendation which it is almost impossible to ignore.

Expected form: **ის**

Why: Demonstratives. [[Georgian#^ka-Q0165|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A1%E1%83%98%E1%83%9A%E1%83%90%E1%83%9B%E1%83%90%E1%83%96%E1%83%94%20%E1%83%A0%E1%83%94%E1%83%99%E1%83%9D%E1%83%9B%E1%83%94%E1%83%9C%E1%83%93%E1%83%90%E1%83%AA%E1%83%98%E1%83%98%E1%83%A1%20%E1%83%AC%E1%83%94%E1%83%A0%E1%83%98%E1%83%9A%E1%83%98%E1%83%90%2C%20%E1%83%A0%E1%83%9D%E1%83%9B%E1%83%9A%E1%83%98%E1%83%A1%20%E1%83%98%E1%83%92%E1%83%9C%E1%83%9D%E1%83%A0%E1%83%98%E1%83%A0%E1%83%94%E1%83%91%E1%83%90%E1%83%AA%20%E1%83%97%E1%83%98%E1%83%97%E1%83%A5%E1%83%9B%E1%83%98%E1%83%A1%20%E1%83%A8%E1%83%94%E1%83%A3%E1%83%AB%E1%83%9A%E1%83%94%E1%83%91%E1%83%94%E1%83%9A%E1%83%98%E1%83%90.)
^ka-Q0165-answer

**ka-Q0166** — სილამაზე რეკომენდაციის წერილია, რომლის იგნორირებაც თითქმის შეუძლებელია.

Beauty is a letter of recommendation which it is almost impossible to ignore.

Why: Demonstratives. [[Georgian#^ka-Q0166|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A1%E1%83%98%E1%83%9A%E1%83%90%E1%83%9B%E1%83%90%E1%83%96%E1%83%94%20%E1%83%A0%E1%83%94%E1%83%99%E1%83%9D%E1%83%9B%E1%83%94%E1%83%9C%E1%83%93%E1%83%90%E1%83%AA%E1%83%98%E1%83%98%E1%83%A1%20%E1%83%AC%E1%83%94%E1%83%A0%E1%83%98%E1%83%9A%E1%83%98%E1%83%90%2C%20%E1%83%A0%E1%83%9D%E1%83%9B%E1%83%9A%E1%83%98%E1%83%A1%20%E1%83%98%E1%83%92%E1%83%9C%E1%83%9D%E1%83%A0%E1%83%98%E1%83%A0%E1%83%94%E1%83%91%E1%83%90%E1%83%AA%20%E1%83%97%E1%83%98%E1%83%97%E1%83%A5%E1%83%9B%E1%83%98%E1%83%A1%20%E1%83%A8%E1%83%94%E1%83%A3%E1%83%AB%E1%83%9A%E1%83%94%E1%83%91%E1%83%94%E1%83%9A%E1%83%98%E1%83%90.)
^ka-Q0166-answer

**ka-Q0167** — ეს ჩემი ძროხაა.

This is my cow.

Why: Demonstratives. [[Georgian#^ka-Q0167|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%94%E1%83%A1%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%AB%E1%83%A0%E1%83%9D%E1%83%AE%E1%83%90%E1%83%90.)
^ka-Q0167-answer

**ka-Q0168** — ეს ჩემი ძროხაა.

This is my cow.

Demonstrative forms change with case and construction. Es often points to this; is to that or a previously mentioned referent. The following noun’s relation determines an inflected form.

Why: Demonstratives. [[Georgian#^ka-Q0168|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%94%E1%83%A1%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%AB%E1%83%A0%E1%83%9D%E1%83%AE%E1%83%90%E1%83%90.)
^ka-Q0168-answer

**ka-Q0169** — ტომმა თქვა ის და მისი ცოლი უნდა წავიდნენ ავსტრალიაში გაზაფხულზე.

Tom said he and his wife would go to Australia in the spring.

Expected form: **ის**

Why: Demonstratives. [[Georgian#^ka-Q0169|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%9B%E1%83%90%20%E1%83%97%E1%83%A5%E1%83%95%E1%83%90%20%E1%83%98%E1%83%A1%20%E1%83%93%E1%83%90%20%E1%83%9B%E1%83%98%E1%83%A1%E1%83%98%20%E1%83%AA%E1%83%9D%E1%83%9A%E1%83%98%20%E1%83%A3%E1%83%9C%E1%83%93%E1%83%90%20%E1%83%AC%E1%83%90%E1%83%95%E1%83%98%E1%83%93%E1%83%9C%E1%83%94%E1%83%9C%20%E1%83%90%E1%83%95%E1%83%A1%E1%83%A2%E1%83%A0%E1%83%90%E1%83%9A%E1%83%98%E1%83%90%E1%83%A8%E1%83%98%20%E1%83%92%E1%83%90%E1%83%96%E1%83%90%E1%83%A4%E1%83%AE%E1%83%A3%E1%83%9A%E1%83%96%E1%83%94.)
^ka-Q0169-answer

**ka-Q0170** — ტომმა თქვა ის და მისი ცოლი უნდა წავიდნენ ავსტრალიაში გაზაფხულზე.

Tom said he and his wife would go to Australia in the spring.

Expected form: **ის**

Why: Demonstratives. [[Georgian#^ka-Q0170|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%9B%E1%83%90%20%E1%83%97%E1%83%A5%E1%83%95%E1%83%90%20%E1%83%98%E1%83%A1%20%E1%83%93%E1%83%90%20%E1%83%9B%E1%83%98%E1%83%A1%E1%83%98%20%E1%83%AA%E1%83%9D%E1%83%9A%E1%83%98%20%E1%83%A3%E1%83%9C%E1%83%93%E1%83%90%20%E1%83%AC%E1%83%90%E1%83%95%E1%83%98%E1%83%93%E1%83%9C%E1%83%94%E1%83%9C%20%E1%83%90%E1%83%95%E1%83%A1%E1%83%A2%E1%83%A0%E1%83%90%E1%83%9A%E1%83%98%E1%83%90%E1%83%A8%E1%83%98%20%E1%83%92%E1%83%90%E1%83%96%E1%83%90%E1%83%A4%E1%83%AE%E1%83%A3%E1%83%9A%E1%83%96%E1%83%94.)
^ka-Q0170-answer

**ka-Q0171** — მის კომპანიაში არასოდეს მოიწყენ.

You will never get bored in her company.

Expected form: **ის**

Why: Demonstratives. [[Georgian#^ka-Q0171|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%98%E1%83%A1%20%E1%83%99%E1%83%9D%E1%83%9B%E1%83%9E%E1%83%90%E1%83%9C%E1%83%98%E1%83%90%E1%83%A8%E1%83%98%20%E1%83%90%E1%83%A0%E1%83%90%E1%83%A1%E1%83%9D%E1%83%93%E1%83%94%E1%83%A1%20%E1%83%9B%E1%83%9D%E1%83%98%E1%83%AC%E1%83%A7%E1%83%94%E1%83%9C.)
^ka-Q0171-answer

**ka-Q0172** — მის კომპანიაში არასოდეს მოიწყენ.

You will never get bored in her company.

Why: Demonstratives. [[Georgian#^ka-Q0172|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%98%E1%83%A1%20%E1%83%99%E1%83%9D%E1%83%9B%E1%83%9E%E1%83%90%E1%83%9C%E1%83%98%E1%83%90%E1%83%A8%E1%83%98%20%E1%83%90%E1%83%A0%E1%83%90%E1%83%A1%E1%83%9D%E1%83%93%E1%83%94%E1%83%A1%20%E1%83%9B%E1%83%9D%E1%83%98%E1%83%AC%E1%83%A7%E1%83%94%E1%83%9C.)
^ka-Q0172-answer

**ka-Q0173** — გოგო ჩაის სვამს.

The girl is drinking tea.

Why: Demonstratives. [[Georgian#^ka-Q0173|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%92%E1%83%9D%E1%83%92%E1%83%9D%20%E1%83%A9%E1%83%90%E1%83%98%E1%83%A1%20%E1%83%A1%E1%83%95%E1%83%90%E1%83%9B%E1%83%A1.)
^ka-Q0173-answer

**ka-Q0174** — გოგო ჩაის სვამს.

The girl is drinking tea.

Demonstrative forms change with case and construction. Es often points to this; is to that or a previously mentioned referent. The following noun’s relation determines an inflected form.

Why: Demonstratives. [[Georgian#^ka-Q0174|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%92%E1%83%9D%E1%83%92%E1%83%9D%20%E1%83%A9%E1%83%90%E1%83%98%E1%83%A1%20%E1%83%A1%E1%83%95%E1%83%90%E1%83%9B%E1%83%A1.)
^ka-Q0174-answer

**ka-Q0175** — ყველა ის ვაშლი შევჭამე.

I ate all those apples.

Expected form: **ის**

Why: Demonstratives. [[Georgian#^ka-Q0175|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A7%E1%83%95%E1%83%94%E1%83%9A%E1%83%90%20%E1%83%98%E1%83%A1%20%E1%83%95%E1%83%90%E1%83%A8%E1%83%9A%E1%83%98%20%E1%83%A8%E1%83%94%E1%83%95%E1%83%AD%E1%83%90%E1%83%9B%E1%83%94.)
^ka-Q0175-answer

**ka-Q0176** — ყველა ის ვაშლი შევჭამე.

I ate all those apples.

Expected form: **ის**

Why: Demonstratives. [[Georgian#^ka-Q0176|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A7%E1%83%95%E1%83%94%E1%83%9A%E1%83%90%20%E1%83%98%E1%83%A1%20%E1%83%95%E1%83%90%E1%83%A8%E1%83%9A%E1%83%98%20%E1%83%A8%E1%83%94%E1%83%95%E1%83%AD%E1%83%90%E1%83%9B%E1%83%94.)
^ka-Q0176-answer

**ka-Q0177** — ამ ოთახში ბიჭია.

There is a boy in this room.

Expected form: **ამ**

Why: Demonstratives. [[Georgian#^ka-Q0177|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%9B%20%E1%83%9D%E1%83%97%E1%83%90%E1%83%AE%E1%83%A8%E1%83%98%20%E1%83%91%E1%83%98%E1%83%AD%E1%83%98%E1%83%90.)
^ka-Q0177-answer

**ka-Q0178** — ამ ოთახში ბიჭია.

There is a boy in this room.

Why: Demonstratives. [[Georgian#^ka-Q0178|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%9B%20%E1%83%9D%E1%83%97%E1%83%90%E1%83%AE%E1%83%A8%E1%83%98%20%E1%83%91%E1%83%98%E1%83%AD%E1%83%98%E1%83%90.)
^ka-Q0178-answer

**ka-Q0179** — გასულ ღამეს ვესიზმრებოდი, რომ მე ფუტკარს ვჭამდი.

Last night I dreamt I was eating bees.

Why: Demonstratives. [[Georgian#^ka-Q0179|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%92%E1%83%90%E1%83%A1%E1%83%A3%E1%83%9A%20%E1%83%A6%E1%83%90%E1%83%9B%E1%83%94%E1%83%A1%20%E1%83%95%E1%83%94%E1%83%A1%E1%83%98%E1%83%96%E1%83%9B%E1%83%A0%E1%83%94%E1%83%91%E1%83%9D%E1%83%93%E1%83%98%2C%20%E1%83%A0%E1%83%9D%E1%83%9B%20%E1%83%9B%E1%83%94%20%E1%83%A4%E1%83%A3%E1%83%A2%E1%83%99%E1%83%90%E1%83%A0%E1%83%A1%20%E1%83%95%E1%83%AD%E1%83%90%E1%83%9B%E1%83%93%E1%83%98.)
^ka-Q0179-answer

**ka-Q0180** — გასულ ღამეს ვესიზმრებოდი, რომ მე ფუტკარს ვჭამდი.

Last night I dreamt I was eating bees.

Demonstrative forms change with case and construction. Es often points to this; is to that or a previously mentioned referent. The following noun’s relation determines an inflected form.

Why: Demonstratives. [[Georgian#^ka-Q0180|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%92%E1%83%90%E1%83%A1%E1%83%A3%E1%83%9A%20%E1%83%A6%E1%83%90%E1%83%9B%E1%83%94%E1%83%A1%20%E1%83%95%E1%83%94%E1%83%A1%E1%83%98%E1%83%96%E1%83%9B%E1%83%A0%E1%83%94%E1%83%91%E1%83%9D%E1%83%93%E1%83%98%2C%20%E1%83%A0%E1%83%9D%E1%83%9B%20%E1%83%9B%E1%83%94%20%E1%83%A4%E1%83%A3%E1%83%A2%E1%83%99%E1%83%90%E1%83%A0%E1%83%A1%20%E1%83%95%E1%83%AD%E1%83%90%E1%83%9B%E1%83%93%E1%83%98.)
^ka-Q0180-answer

**ka-Q0181** — ყველამ გაიმეორეთ ჩემს შემდეგ.

Read after me all together.

Expected form: **ამ**

Why: Demonstratives. [[Georgian#^ka-Q0181|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A7%E1%83%95%E1%83%94%E1%83%9A%E1%83%90%E1%83%9B%20%E1%83%92%E1%83%90%E1%83%98%E1%83%9B%E1%83%94%E1%83%9D%E1%83%A0%E1%83%94%E1%83%97%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%A1%20%E1%83%A8%E1%83%94%E1%83%9B%E1%83%93%E1%83%94%E1%83%92.)
^ka-Q0181-answer

**ka-Q0182** — ყველამ გაიმეორეთ ჩემს შემდეგ.

Read after me all together.

Expected form: **ამ**

Why: Demonstratives. [[Georgian#^ka-Q0182|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A7%E1%83%95%E1%83%94%E1%83%9A%E1%83%90%E1%83%9B%20%E1%83%92%E1%83%90%E1%83%98%E1%83%9B%E1%83%94%E1%83%9D%E1%83%A0%E1%83%94%E1%83%97%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%A1%20%E1%83%A8%E1%83%94%E1%83%9B%E1%83%93%E1%83%94%E1%83%92.)
^ka-Q0182-answer

**ka-Q0183** — ის ჩემი მაგიდაა.

It is my table.

Expected form: **ის**

Why: Demonstratives. [[Georgian#^ka-Q0183|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%98%E1%83%A1%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%9B%E1%83%90%E1%83%92%E1%83%98%E1%83%93%E1%83%90%E1%83%90.)
^ka-Q0183-answer

**ka-Q0184** — ის ჩემი მაგიდაა.

It is my table.

Why: Demonstratives. [[Georgian#^ka-Q0184|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%98%E1%83%A1%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%9B%E1%83%90%E1%83%92%E1%83%98%E1%83%93%E1%83%90%E1%83%90.)
^ka-Q0184-answer

**ka-Q0185** — ეს ნოხია გაწმენდილი.

This rug has been cleaned.

Why: Demonstratives. [[Georgian#^ka-Q0185|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%94%E1%83%A1%20%E1%83%9C%E1%83%9D%E1%83%AE%E1%83%98%E1%83%90%20%E1%83%92%E1%83%90%E1%83%AC%E1%83%9B%E1%83%94%E1%83%9C%E1%83%93%E1%83%98%E1%83%9A%E1%83%98.)
^ka-Q0185-answer

**ka-Q0186** — ეს ნოხია გაწმენდილი.

This rug has been cleaned.

Demonstrative forms change with case and construction. Es often points to this; is to that or a previously mentioned referent. The following noun’s relation determines an inflected form.

Why: Demonstratives. [[Georgian#^ka-Q0186|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%94%E1%83%A1%20%E1%83%9C%E1%83%9D%E1%83%AE%E1%83%98%E1%83%90%20%E1%83%92%E1%83%90%E1%83%AC%E1%83%9B%E1%83%94%E1%83%9C%E1%83%93%E1%83%98%E1%83%9A%E1%83%98.)
^ka-Q0186-answer

**ka-Q0187** — ის ამ საღამოს ლენინგრადს მიემგზავრება.

He's leaving for Leningrad tonight.

Expected form: **ის**

Why: Demonstratives. [[Georgian#^ka-Q0187|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%98%E1%83%A1%20%E1%83%90%E1%83%9B%20%E1%83%A1%E1%83%90%E1%83%A6%E1%83%90%E1%83%9B%E1%83%9D%E1%83%A1%20%E1%83%9A%E1%83%94%E1%83%9C%E1%83%98%E1%83%9C%E1%83%92%E1%83%A0%E1%83%90%E1%83%93%E1%83%A1%20%E1%83%9B%E1%83%98%E1%83%94%E1%83%9B%E1%83%92%E1%83%96%E1%83%90%E1%83%95%E1%83%A0%E1%83%94%E1%83%91%E1%83%90.)
^ka-Q0187-answer

**ka-Q0188** — ის ამ საღამოს ლენინგრადს მიემგზავრება.

He's leaving for Leningrad tonight.

Expected form: **ის**

Why: Demonstratives. [[Georgian#^ka-Q0188|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%98%E1%83%A1%20%E1%83%90%E1%83%9B%20%E1%83%A1%E1%83%90%E1%83%A6%E1%83%90%E1%83%9B%E1%83%9D%E1%83%A1%20%E1%83%9A%E1%83%94%E1%83%9C%E1%83%98%E1%83%9C%E1%83%92%E1%83%A0%E1%83%90%E1%83%93%E1%83%A1%20%E1%83%9B%E1%83%98%E1%83%94%E1%83%9B%E1%83%92%E1%83%96%E1%83%90%E1%83%95%E1%83%A0%E1%83%94%E1%83%91%E1%83%90.)
^ka-Q0188-answer

**ka-Q0189** — ვიცი, რომ ტომმა ეს გააკეთა.

I know Tom did this.

Expected form: **ეს**

Why: Demonstratives. [[Georgian#^ka-Q0189|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%95%E1%83%98%E1%83%AA%E1%83%98%2C%20%E1%83%A0%E1%83%9D%E1%83%9B%20%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%9B%E1%83%90%20%E1%83%94%E1%83%A1%20%E1%83%92%E1%83%90%E1%83%90%E1%83%99%E1%83%94%E1%83%97%E1%83%90.)
^ka-Q0189-answer

**ka-Q0190** — ვიცი, რომ ტომმა ეს გააკეთა.

I know Tom did this.

Why: Demonstratives. [[Georgian#^ka-Q0190|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%95%E1%83%98%E1%83%AA%E1%83%98%2C%20%E1%83%A0%E1%83%9D%E1%83%9B%20%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%9B%E1%83%90%20%E1%83%94%E1%83%A1%20%E1%83%92%E1%83%90%E1%83%90%E1%83%99%E1%83%94%E1%83%97%E1%83%90.)
^ka-Q0190-answer

**ka-Q0191** — ნაყინის ჭამა მინდა.

I want to eat ice cream.

Why: Demonstratives. [[Georgian#^ka-Q0191|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9C%E1%83%90%E1%83%A7%E1%83%98%E1%83%9C%E1%83%98%E1%83%A1%20%E1%83%AD%E1%83%90%E1%83%9B%E1%83%90%20%E1%83%9B%E1%83%98%E1%83%9C%E1%83%93%E1%83%90.)
^ka-Q0191-answer

**ka-Q0192** — ნაყინის ჭამა მინდა.

I want to eat ice cream.

Demonstrative forms change with case and construction. Es often points to this; is to that or a previously mentioned referent. The following noun’s relation determines an inflected form.

Why: Demonstratives. [[Georgian#^ka-Q0192|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9C%E1%83%90%E1%83%A7%E1%83%98%E1%83%9C%E1%83%98%E1%83%A1%20%E1%83%AD%E1%83%90%E1%83%9B%E1%83%90%20%E1%83%9B%E1%83%98%E1%83%9C%E1%83%93%E1%83%90.)
^ka-Q0192-answer

**ka-Q0193** — სამის აქვს მუქი კანი.

Sami is dark-skinned.

Expected form: **ის**

Why: Demonstratives. [[Georgian#^ka-Q0193|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A1%E1%83%90%E1%83%9B%E1%83%98%E1%83%A1%20%E1%83%90%E1%83%A5%E1%83%95%E1%83%A1%20%E1%83%9B%E1%83%A3%E1%83%A5%E1%83%98%20%E1%83%99%E1%83%90%E1%83%9C%E1%83%98.)
^ka-Q0193-answer

**ka-Q0194** — სამის აქვს მუქი კანი.

Sami is dark-skinned.

Expected form: **ის**

Why: Demonstratives. [[Georgian#^ka-Q0194|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A1%E1%83%90%E1%83%9B%E1%83%98%E1%83%A1%20%E1%83%90%E1%83%A5%E1%83%95%E1%83%A1%20%E1%83%9B%E1%83%A3%E1%83%A5%E1%83%98%20%E1%83%99%E1%83%90%E1%83%9C%E1%83%98.)
^ka-Q0194-answer

**ka-Q0195** — მარიამი ტომის დედაა?

Is Mary Tom's mother?

Expected form: **ის**

Why: Demonstratives. [[Georgian#^ka-Q0195|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%90%E1%83%A0%E1%83%98%E1%83%90%E1%83%9B%E1%83%98%20%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%98%E1%83%A1%20%E1%83%93%E1%83%94%E1%83%93%E1%83%90%E1%83%90%3F)
^ka-Q0195-answer

**ka-Q0196** — მარიამი ტომის დედაა?

Is Mary Tom's mother?

Why: Demonstratives. [[Georgian#^ka-Q0196|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%90%E1%83%A0%E1%83%98%E1%83%90%E1%83%9B%E1%83%98%20%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%98%E1%83%A1%20%E1%83%93%E1%83%94%E1%83%93%E1%83%90%E1%83%90%3F)
^ka-Q0196-answer

**ka-Q0197** — ეს ტომის სკოლაა.

This is Tom's school.

Why: Demonstratives. [[Georgian#^ka-Q0197|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%94%E1%83%A1%20%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%98%E1%83%A1%20%E1%83%A1%E1%83%99%E1%83%9D%E1%83%9A%E1%83%90%E1%83%90.)
^ka-Q0197-answer

**ka-Q0198** — ეს ტომის სკოლაა.

This is Tom's school.

Demonstrative forms change with case and construction. Es often points to this; is to that or a previously mentioned referent. The following noun’s relation determines an inflected form.

Why: Demonstratives. [[Georgian#^ka-Q0198|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%94%E1%83%A1%20%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%98%E1%83%A1%20%E1%83%A1%E1%83%99%E1%83%9D%E1%83%9A%E1%83%90%E1%83%90.)
^ka-Q0198-answer

**ka-Q0199** — ის ჩემი ძაღლია.

It is my dog.

Expected form: **ის**

Why: Demonstratives. [[Georgian#^ka-Q0199|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%98%E1%83%A1%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%AB%E1%83%90%E1%83%A6%E1%83%9A%E1%83%98%E1%83%90.)
^ka-Q0199-answer

**ka-Q0200** — ის ჩემი ძაღლია.

It is my dog.

Expected form: **ის**

Why: Demonstratives. [[Georgian#^ka-Q0200|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%98%E1%83%A1%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%AB%E1%83%90%E1%83%A6%E1%83%9A%E1%83%98%E1%83%90.)
^ka-Q0200-answer


### Answers 201–250

**ka-Q0201** — ჩვენი შეხვედრა შემთხვევითი იყო.

Our meeting was quite accidental.

Expected form: **ჩვენი**

Why: Possessive pronouns. [[Georgian#^ka-Q0201|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A9%E1%83%95%E1%83%94%E1%83%9C%E1%83%98%20%E1%83%A8%E1%83%94%E1%83%AE%E1%83%95%E1%83%94%E1%83%93%E1%83%A0%E1%83%90%20%E1%83%A8%E1%83%94%E1%83%9B%E1%83%97%E1%83%AE%E1%83%95%E1%83%94%E1%83%95%E1%83%98%E1%83%97%E1%83%98%20%E1%83%98%E1%83%A7%E1%83%9D.)
^ka-Q0201-answer

**ka-Q0202** — ჩვენი შეხვედრა შემთხვევითი იყო.

Our meeting was quite accidental.

Why: Possessive pronouns. [[Georgian#^ka-Q0202|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A9%E1%83%95%E1%83%94%E1%83%9C%E1%83%98%20%E1%83%A8%E1%83%94%E1%83%AE%E1%83%95%E1%83%94%E1%83%93%E1%83%A0%E1%83%90%20%E1%83%A8%E1%83%94%E1%83%9B%E1%83%97%E1%83%AE%E1%83%95%E1%83%94%E1%83%95%E1%83%98%E1%83%97%E1%83%98%20%E1%83%98%E1%83%A7%E1%83%9D.)
^ka-Q0202-answer

**ka-Q0203** — აი შენი გასაღები.

Here is your key.

Why: Possessive pronouns. [[Georgian#^ka-Q0203|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%98%20%E1%83%A8%E1%83%94%E1%83%9C%E1%83%98%20%E1%83%92%E1%83%90%E1%83%A1%E1%83%90%E1%83%A6%E1%83%94%E1%83%91%E1%83%98.)
^ka-Q0203-answer

**ka-Q0204** — აი შენი გასაღები.

Here is your key.

Possessive forms modify a noun and themselves inflect in relevant contexts. Learn the complete phrase. Possession predicates use particular verbal classes and participant marking.

Why: Possessive pronouns. [[Georgian#^ka-Q0204|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%98%20%E1%83%A8%E1%83%94%E1%83%9C%E1%83%98%20%E1%83%92%E1%83%90%E1%83%A1%E1%83%90%E1%83%A6%E1%83%94%E1%83%91%E1%83%98.)
^ka-Q0204-answer

**ka-Q0205** — აი შენი ძაღლი.

Here is your dog.

Expected form: **შენი**

Why: Possessive pronouns. [[Georgian#^ka-Q0205|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%98%20%E1%83%A8%E1%83%94%E1%83%9C%E1%83%98%20%E1%83%AB%E1%83%90%E1%83%A6%E1%83%9A%E1%83%98.)
^ka-Q0205-answer

**ka-Q0206** — აი შენი ძაღლი.

Here is your dog.

Expected form: **შენი**

Why: Possessive pronouns. [[Georgian#^ka-Q0206|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%98%20%E1%83%A8%E1%83%94%E1%83%9C%E1%83%98%20%E1%83%AB%E1%83%90%E1%83%A6%E1%83%9A%E1%83%98.)
^ka-Q0206-answer

**ka-Q0207** — ჩემი ვაჟიშვილი ჟურნალისტია.

My son is a journalist.

Expected form: **ჩემი**

Why: Possessive pronouns. [[Georgian#^ka-Q0207|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%95%E1%83%90%E1%83%9F%E1%83%98%E1%83%A8%E1%83%95%E1%83%98%E1%83%9A%E1%83%98%20%E1%83%9F%E1%83%A3%E1%83%A0%E1%83%9C%E1%83%90%E1%83%9A%E1%83%98%E1%83%A1%E1%83%A2%E1%83%98%E1%83%90.)
^ka-Q0207-answer

**ka-Q0208** — ჩემი ვაჟიშვილი ჟურნალისტია.

My son is a journalist.

Why: Possessive pronouns. [[Georgian#^ka-Q0208|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%95%E1%83%90%E1%83%9F%E1%83%98%E1%83%A8%E1%83%95%E1%83%98%E1%83%9A%E1%83%98%20%E1%83%9F%E1%83%A3%E1%83%A0%E1%83%9C%E1%83%90%E1%83%9A%E1%83%98%E1%83%A1%E1%83%A2%E1%83%98%E1%83%90.)
^ka-Q0208-answer

**ka-Q0209** — დედაშენი ძალიან ლამაზია!

Your mother is very beautiful!

Why: Possessive pronouns. [[Georgian#^ka-Q0209|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%93%E1%83%94%E1%83%93%E1%83%90%E1%83%A8%E1%83%94%E1%83%9C%E1%83%98%20%E1%83%AB%E1%83%90%E1%83%9A%E1%83%98%E1%83%90%E1%83%9C%20%E1%83%9A%E1%83%90%E1%83%9B%E1%83%90%E1%83%96%E1%83%98%E1%83%90%21)
^ka-Q0209-answer

**ka-Q0210** — დედაშენი ძალიან ლამაზია!

Your mother is very beautiful!

Possessive forms modify a noun and themselves inflect in relevant contexts. Learn the complete phrase. Possession predicates use particular verbal classes and participant marking.

Why: Possessive pronouns. [[Georgian#^ka-Q0210|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%93%E1%83%94%E1%83%93%E1%83%90%E1%83%A8%E1%83%94%E1%83%9C%E1%83%98%20%E1%83%AB%E1%83%90%E1%83%9A%E1%83%98%E1%83%90%E1%83%9C%20%E1%83%9A%E1%83%90%E1%83%9B%E1%83%90%E1%83%96%E1%83%98%E1%83%90%21)
^ka-Q0210-answer

**ka-Q0211** — აი თქვენი მენიუ.

Here is your menu.

Expected form: **თქვენი**

Why: Possessive pronouns. [[Georgian#^ka-Q0211|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%98%20%E1%83%97%E1%83%A5%E1%83%95%E1%83%94%E1%83%9C%E1%83%98%20%E1%83%9B%E1%83%94%E1%83%9C%E1%83%98%E1%83%A3.)
^ka-Q0211-answer

**ka-Q0212** — აი თქვენი მენიუ.

Here is your menu.

Expected form: **თქვენი**

Why: Possessive pronouns. [[Georgian#^ka-Q0212|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%98%20%E1%83%97%E1%83%A5%E1%83%95%E1%83%94%E1%83%9C%E1%83%98%20%E1%83%9B%E1%83%94%E1%83%9C%E1%83%98%E1%83%A3.)
^ka-Q0212-answer

**ka-Q0213** — ეს არის ჩემი წიგნი.

This is my book.

Expected form: **ჩემი**

Why: Possessive pronouns. [[Georgian#^ka-Q0213|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%94%E1%83%A1%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%AC%E1%83%98%E1%83%92%E1%83%9C%E1%83%98.)
^ka-Q0213-answer

**ka-Q0214** — ეს არის ჩემი წიგნი.

This is my book.

Why: Possessive pronouns. [[Georgian#^ka-Q0214|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%94%E1%83%A1%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%AC%E1%83%98%E1%83%92%E1%83%9C%E1%83%98.)
^ka-Q0214-answer

**ka-Q0215** — ისინი ჩემი დები არიან.

They are my sisters.

Why: Possessive pronouns. [[Georgian#^ka-Q0215|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%98%E1%83%A1%E1%83%98%E1%83%9C%E1%83%98%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%93%E1%83%94%E1%83%91%E1%83%98%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%90%E1%83%9C.)
^ka-Q0215-answer

**ka-Q0216** — ისინი ჩემი დები არიან.

They are my sisters.

Possessive forms modify a noun and themselves inflect in relevant contexts. Learn the complete phrase. Possession predicates use particular verbal classes and participant marking.

Why: Possessive pronouns. [[Georgian#^ka-Q0216|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%98%E1%83%A1%E1%83%98%E1%83%9C%E1%83%98%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%93%E1%83%94%E1%83%91%E1%83%98%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%90%E1%83%9C.)
^ka-Q0216-answer

**ka-Q0217** — ეს წიგნები ჩემი დის არიან.

Those are my sister's books.

Expected form: **ჩემი**

Why: Possessive pronouns. [[Georgian#^ka-Q0217|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%94%E1%83%A1%20%E1%83%AC%E1%83%98%E1%83%92%E1%83%9C%E1%83%94%E1%83%91%E1%83%98%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%93%E1%83%98%E1%83%A1%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%90%E1%83%9C.)
^ka-Q0217-answer

**ka-Q0218** — ეს წიგნები ჩემი დის არიან.

Those are my sister's books.

Expected form: **ჩემი**

Why: Possessive pronouns. [[Georgian#^ka-Q0218|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%94%E1%83%A1%20%E1%83%AC%E1%83%98%E1%83%92%E1%83%9C%E1%83%94%E1%83%91%E1%83%98%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%93%E1%83%98%E1%83%A1%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%90%E1%83%9C.)
^ka-Q0218-answer

**ka-Q0219** — მე უბრალოდ მინდოდა შენი გაბედნიერება.

I just wanted to make you happy.

Expected form: **შენი**

Why: Possessive pronouns. [[Georgian#^ka-Q0219|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%A3%E1%83%91%E1%83%A0%E1%83%90%E1%83%9A%E1%83%9D%E1%83%93%20%E1%83%9B%E1%83%98%E1%83%9C%E1%83%93%E1%83%9D%E1%83%93%E1%83%90%20%E1%83%A8%E1%83%94%E1%83%9C%E1%83%98%20%E1%83%92%E1%83%90%E1%83%91%E1%83%94%E1%83%93%E1%83%9C%E1%83%98%E1%83%94%E1%83%A0%E1%83%94%E1%83%91%E1%83%90.)
^ka-Q0219-answer

**ka-Q0220** — მე უბრალოდ მინდოდა შენი გაბედნიერება.

I just wanted to make you happy.

Why: Possessive pronouns. [[Georgian#^ka-Q0220|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%A3%E1%83%91%E1%83%A0%E1%83%90%E1%83%9A%E1%83%9D%E1%83%93%20%E1%83%9B%E1%83%98%E1%83%9C%E1%83%93%E1%83%9D%E1%83%93%E1%83%90%20%E1%83%A8%E1%83%94%E1%83%9C%E1%83%98%20%E1%83%92%E1%83%90%E1%83%91%E1%83%94%E1%83%93%E1%83%9C%E1%83%98%E1%83%94%E1%83%A0%E1%83%94%E1%83%91%E1%83%90.)
^ka-Q0220-answer

**ka-Q0221** — მენადმა დაინახა რომ მისი მეგობარი მოკვდა.

Mennad saw his friend die.

Why: Possessive pronouns. [[Georgian#^ka-Q0221|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%E1%83%9C%E1%83%90%E1%83%93%E1%83%9B%E1%83%90%20%E1%83%93%E1%83%90%E1%83%98%E1%83%9C%E1%83%90%E1%83%AE%E1%83%90%20%E1%83%A0%E1%83%9D%E1%83%9B%20%E1%83%9B%E1%83%98%E1%83%A1%E1%83%98%20%E1%83%9B%E1%83%94%E1%83%92%E1%83%9D%E1%83%91%E1%83%90%E1%83%A0%E1%83%98%20%E1%83%9B%E1%83%9D%E1%83%99%E1%83%95%E1%83%93%E1%83%90.)
^ka-Q0221-answer

**ka-Q0222** — მენადმა დაინახა რომ მისი მეგობარი მოკვდა.

Mennad saw his friend die.

Possessive forms modify a noun and themselves inflect in relevant contexts. Learn the complete phrase. Possession predicates use particular verbal classes and participant marking.

Why: Possessive pronouns. [[Georgian#^ka-Q0222|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%E1%83%9C%E1%83%90%E1%83%93%E1%83%9B%E1%83%90%20%E1%83%93%E1%83%90%E1%83%98%E1%83%9C%E1%83%90%E1%83%AE%E1%83%90%20%E1%83%A0%E1%83%9D%E1%83%9B%20%E1%83%9B%E1%83%98%E1%83%A1%E1%83%98%20%E1%83%9B%E1%83%94%E1%83%92%E1%83%9D%E1%83%91%E1%83%90%E1%83%A0%E1%83%98%20%E1%83%9B%E1%83%9D%E1%83%99%E1%83%95%E1%83%93%E1%83%90.)
^ka-Q0222-answer

**ka-Q0223** — ჩემი დედა ენა ესპანურია.

My mother tongue is Spanish.

Expected form: **ჩემი**

Why: Possessive pronouns. [[Georgian#^ka-Q0223|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%93%E1%83%94%E1%83%93%E1%83%90%20%E1%83%94%E1%83%9C%E1%83%90%20%E1%83%94%E1%83%A1%E1%83%9E%E1%83%90%E1%83%9C%E1%83%A3%E1%83%A0%E1%83%98%E1%83%90.)
^ka-Q0223-answer

**ka-Q0224** — ჩემი დედა ენა ესპანურია.

My mother tongue is Spanish.

Expected form: **ჩემი**

Why: Possessive pronouns. [[Georgian#^ka-Q0224|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%93%E1%83%94%E1%83%93%E1%83%90%20%E1%83%94%E1%83%9C%E1%83%90%20%E1%83%94%E1%83%A1%E1%83%9E%E1%83%90%E1%83%9C%E1%83%A3%E1%83%A0%E1%83%98%E1%83%90.)
^ka-Q0224-answer

**ka-Q0225** — ჩემი გადაწყვეტილების საზღვარგარეთ სწავლის გაკვირვებული ჩემი მშობლები.

My decision to study abroad surprised my parents.

Expected form: **ჩემი**

Why: Possessive pronouns. [[Georgian#^ka-Q0225|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%92%E1%83%90%E1%83%93%E1%83%90%E1%83%AC%E1%83%A7%E1%83%95%E1%83%94%E1%83%A2%E1%83%98%E1%83%9A%E1%83%94%E1%83%91%E1%83%98%E1%83%A1%20%E1%83%A1%E1%83%90%E1%83%96%E1%83%A6%E1%83%95%E1%83%90%E1%83%A0%E1%83%92%E1%83%90%E1%83%A0%E1%83%94%E1%83%97%20%E1%83%A1%E1%83%AC%E1%83%90%E1%83%95%E1%83%9A%E1%83%98%E1%83%A1%20%E1%83%92%E1%83%90%E1%83%99%E1%83%95%E1%83%98%E1%83%A0%E1%83%95%E1%83%94%E1%83%91%E1%83%A3%E1%83%9A%E1%83%98%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%9B%E1%83%A8%E1%83%9D%E1%83%91%E1%83%9A%E1%83%94%E1%83%91%E1%83%98.)
^ka-Q0225-answer

**ka-Q0226** — ჩემი გადაწყვეტილების საზღვარგარეთ სწავლის გაკვირვებული ჩემი მშობლები.

My decision to study abroad surprised my parents.

Why: Possessive pronouns. [[Georgian#^ka-Q0226|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%92%E1%83%90%E1%83%93%E1%83%90%E1%83%AC%E1%83%A7%E1%83%95%E1%83%94%E1%83%A2%E1%83%98%E1%83%9A%E1%83%94%E1%83%91%E1%83%98%E1%83%A1%20%E1%83%A1%E1%83%90%E1%83%96%E1%83%A6%E1%83%95%E1%83%90%E1%83%A0%E1%83%92%E1%83%90%E1%83%A0%E1%83%94%E1%83%97%20%E1%83%A1%E1%83%AC%E1%83%90%E1%83%95%E1%83%9A%E1%83%98%E1%83%A1%20%E1%83%92%E1%83%90%E1%83%99%E1%83%95%E1%83%98%E1%83%A0%E1%83%95%E1%83%94%E1%83%91%E1%83%A3%E1%83%9A%E1%83%98%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%9B%E1%83%A8%E1%83%9D%E1%83%91%E1%83%9A%E1%83%94%E1%83%91%E1%83%98.)
^ka-Q0226-answer

**ka-Q0227** — აი შენი ჩანთა.

Here is your bag.

Why: Possessive pronouns. [[Georgian#^ka-Q0227|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%98%20%E1%83%A8%E1%83%94%E1%83%9C%E1%83%98%20%E1%83%A9%E1%83%90%E1%83%9C%E1%83%97%E1%83%90.)
^ka-Q0227-answer

**ka-Q0228** — აი შენი ჩანთა.

Here is your bag.

Possessive forms modify a noun and themselves inflect in relevant contexts. Learn the complete phrase. Possession predicates use particular verbal classes and participant marking.

Why: Possessive pronouns. [[Georgian#^ka-Q0228|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%98%20%E1%83%A8%E1%83%94%E1%83%9C%E1%83%98%20%E1%83%A9%E1%83%90%E1%83%9C%E1%83%97%E1%83%90.)
^ka-Q0228-answer

**ka-Q0229** — ესენი ჩემი დის წიგნები არიან.

Those are my sister's books.

Expected form: **ჩემი**

Why: Possessive pronouns. [[Georgian#^ka-Q0229|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%94%E1%83%A1%E1%83%94%E1%83%9C%E1%83%98%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%93%E1%83%98%E1%83%A1%20%E1%83%AC%E1%83%98%E1%83%92%E1%83%9C%E1%83%94%E1%83%91%E1%83%98%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%90%E1%83%9C.)
^ka-Q0229-answer

**ka-Q0230** — ესენი ჩემი დის წიგნები არიან.

Those are my sister's books.

Expected form: **ჩემი**

Why: Possessive pronouns. [[Georgian#^ka-Q0230|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%94%E1%83%A1%E1%83%94%E1%83%9C%E1%83%98%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%93%E1%83%98%E1%83%A1%20%E1%83%AC%E1%83%98%E1%83%92%E1%83%9C%E1%83%94%E1%83%91%E1%83%98%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%90%E1%83%9C.)
^ka-Q0230-answer

**ka-Q0231** — სად არის ჩემი წიგნი?

Where is my book?

Expected form: **ჩემი**

Why: Possessive pronouns. [[Georgian#^ka-Q0231|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A1%E1%83%90%E1%83%93%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%AC%E1%83%98%E1%83%92%E1%83%9C%E1%83%98%3F)
^ka-Q0231-answer

**ka-Q0232** — სად არის ჩემი წიგნი?

Where is my book?

Why: Possessive pronouns. [[Georgian#^ka-Q0232|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A1%E1%83%90%E1%83%93%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%AC%E1%83%98%E1%83%92%E1%83%9C%E1%83%98%3F)
^ka-Q0232-answer

**ka-Q0233** — ტომი 15-ის იყო, მარია 14-ის. სხვა ბავშვები - მათი სახელები აღარ მახსოვს - ცოტათი უმცროსები იყვნენ.

Tom was 15, Maria 14. The other children – I can no longer remember their names – were a bit younger.

Why: Possessive pronouns. [[Georgian#^ka-Q0233|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%98%2015-%E1%83%98%E1%83%A1%20%E1%83%98%E1%83%A7%E1%83%9D%2C%20%E1%83%9B%E1%83%90%E1%83%A0%E1%83%98%E1%83%90%2014-%E1%83%98%E1%83%A1.%20%E1%83%A1%E1%83%AE%E1%83%95%E1%83%90%20%E1%83%91%E1%83%90%E1%83%95%E1%83%A8%E1%83%95%E1%83%94%E1%83%91%E1%83%98%20-%20%E1%83%9B%E1%83%90%E1%83%97%E1%83%98%20%E1%83%A1%E1%83%90%E1%83%AE%E1%83%94%E1%83%9A%E1%83%94%E1%83%91%E1%83%98%20%E1%83%90%E1%83%A6%E1%83%90%E1%83%A0%20%E1%83%9B%E1%83%90%E1%83%AE%E1%83%A1%E1%83%9D%E1%83%95%E1%83%A1%20-%20%E1%83%AA%E1%83%9D%E1%83%A2%E1%83%90%E1%83%97%E1%83%98%20%E1%83%A3%E1%83%9B%E1%83%AA%E1%83%A0%E1%83%9D%E1%83%A1%E1%83%94%E1%83%91%E1%83%98%20%E1%83%98%E1%83%A7%E1%83%95%E1%83%9C%E1%83%94%E1%83%9C.)
^ka-Q0233-answer

**ka-Q0234** — ტომი 15-ის იყო, მარია 14-ის. სხვა ბავშვები - მათი სახელები აღარ მახსოვს - ცოტათი უმცროსები იყვნენ.

Tom was 15, Maria 14. The other children – I can no longer remember their names – were a bit younger.

Possessive forms modify a noun and themselves inflect in relevant contexts. Learn the complete phrase. Possession predicates use particular verbal classes and participant marking.

Why: Possessive pronouns. [[Georgian#^ka-Q0234|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%98%2015-%E1%83%98%E1%83%A1%20%E1%83%98%E1%83%A7%E1%83%9D%2C%20%E1%83%9B%E1%83%90%E1%83%A0%E1%83%98%E1%83%90%2014-%E1%83%98%E1%83%A1.%20%E1%83%A1%E1%83%AE%E1%83%95%E1%83%90%20%E1%83%91%E1%83%90%E1%83%95%E1%83%A8%E1%83%95%E1%83%94%E1%83%91%E1%83%98%20-%20%E1%83%9B%E1%83%90%E1%83%97%E1%83%98%20%E1%83%A1%E1%83%90%E1%83%AE%E1%83%94%E1%83%9A%E1%83%94%E1%83%91%E1%83%98%20%E1%83%90%E1%83%A6%E1%83%90%E1%83%A0%20%E1%83%9B%E1%83%90%E1%83%AE%E1%83%A1%E1%83%9D%E1%83%95%E1%83%A1%20-%20%E1%83%AA%E1%83%9D%E1%83%A2%E1%83%90%E1%83%97%E1%83%98%20%E1%83%A3%E1%83%9B%E1%83%AA%E1%83%A0%E1%83%9D%E1%83%A1%E1%83%94%E1%83%91%E1%83%98%20%E1%83%98%E1%83%A7%E1%83%95%E1%83%9C%E1%83%94%E1%83%9C.)
^ka-Q0234-answer

**ka-Q0235** — ის იცის ჩემი ცოლს.

She knows my wife.

Expected form: **ჩემი**

Why: Possessive pronouns. [[Georgian#^ka-Q0235|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%98%E1%83%A1%20%E1%83%98%E1%83%AA%E1%83%98%E1%83%A1%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%AA%E1%83%9D%E1%83%9A%E1%83%A1.)
^ka-Q0235-answer

**ka-Q0236** — ის იცის ჩემი ცოლს.

She knows my wife.

Expected form: **ჩემი**

Why: Possessive pronouns. [[Georgian#^ka-Q0236|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%98%E1%83%A1%20%E1%83%98%E1%83%AA%E1%83%98%E1%83%A1%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%AA%E1%83%9D%E1%83%9A%E1%83%A1.)
^ka-Q0236-answer

**ka-Q0237** — რატომ გჭირდება ჩემი ნებართვა?

Why do you need my permission?

Expected form: **ჩემი**

Why: Possessive pronouns. [[Georgian#^ka-Q0237|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A0%E1%83%90%E1%83%A2%E1%83%9D%E1%83%9B%20%E1%83%92%E1%83%AD%E1%83%98%E1%83%A0%E1%83%93%E1%83%94%E1%83%91%E1%83%90%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%9C%E1%83%94%E1%83%91%E1%83%90%E1%83%A0%E1%83%97%E1%83%95%E1%83%90%3F)
^ka-Q0237-answer

**ka-Q0238** — რატომ გჭირდება ჩემი ნებართვა?

Why do you need my permission?

Why: Possessive pronouns. [[Georgian#^ka-Q0238|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A0%E1%83%90%E1%83%A2%E1%83%9D%E1%83%9B%20%E1%83%92%E1%83%AD%E1%83%98%E1%83%A0%E1%83%93%E1%83%94%E1%83%91%E1%83%90%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%9C%E1%83%94%E1%83%91%E1%83%90%E1%83%A0%E1%83%97%E1%83%95%E1%83%90%3F)
^ka-Q0238-answer

**ka-Q0239** — ჩემი და არის ორი წლით უმცროსი ჩემზე.

My sister is two years younger than me.

Why: Possessive pronouns. [[Georgian#^ka-Q0239|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%93%E1%83%90%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%9D%E1%83%A0%E1%83%98%20%E1%83%AC%E1%83%9A%E1%83%98%E1%83%97%20%E1%83%A3%E1%83%9B%E1%83%AA%E1%83%A0%E1%83%9D%E1%83%A1%E1%83%98%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%96%E1%83%94.)
^ka-Q0239-answer

**ka-Q0240** — ჩემი და არის ორი წლით უმცროსი ჩემზე.

My sister is two years younger than me.

Possessive forms modify a noun and themselves inflect in relevant contexts. Learn the complete phrase. Possession predicates use particular verbal classes and participant marking.

Why: Possessive pronouns. [[Georgian#^ka-Q0240|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%93%E1%83%90%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%9D%E1%83%A0%E1%83%98%20%E1%83%AC%E1%83%9A%E1%83%98%E1%83%97%20%E1%83%A3%E1%83%9B%E1%83%AA%E1%83%A0%E1%83%9D%E1%83%A1%E1%83%98%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%96%E1%83%94.)
^ka-Q0240-answer

**ka-Q0241** — ის ჩემი ძროხაა.

It is my cow.

Expected form: **ჩემი**

Why: Possessive pronouns. [[Georgian#^ka-Q0241|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%98%E1%83%A1%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%AB%E1%83%A0%E1%83%9D%E1%83%AE%E1%83%90%E1%83%90.)
^ka-Q0241-answer

**ka-Q0242** — ის ჩემი ძროხაა.

It is my cow.

Expected form: **ჩემი**

Why: Possessive pronouns. [[Georgian#^ka-Q0242|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%98%E1%83%A1%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%AB%E1%83%A0%E1%83%9D%E1%83%AE%E1%83%90%E1%83%90.)
^ka-Q0242-answer

**ka-Q0243** — შენ გაქვს ჩემი ნებართვა.

You have my permission.

Expected form: **ჩემი**

Why: Possessive pronouns. [[Georgian#^ka-Q0243|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A8%E1%83%94%E1%83%9C%20%E1%83%92%E1%83%90%E1%83%A5%E1%83%95%E1%83%A1%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%9C%E1%83%94%E1%83%91%E1%83%90%E1%83%A0%E1%83%97%E1%83%95%E1%83%90.)
^ka-Q0243-answer

**ka-Q0244** — შენ გაქვს ჩემი ნებართვა.

You have my permission.

Why: Possessive pronouns. [[Georgian#^ka-Q0244|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A8%E1%83%94%E1%83%9C%20%E1%83%92%E1%83%90%E1%83%A5%E1%83%95%E1%83%A1%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%9C%E1%83%94%E1%83%91%E1%83%90%E1%83%A0%E1%83%97%E1%83%95%E1%83%90.)
^ka-Q0244-answer

**ka-Q0245** — მე შენი მოქმედებების შესახებ ვსაუბრობ.

I'm talking about your actions.

Why: Possessive pronouns. [[Georgian#^ka-Q0245|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%A8%E1%83%94%E1%83%9C%E1%83%98%20%E1%83%9B%E1%83%9D%E1%83%A5%E1%83%9B%E1%83%94%E1%83%93%E1%83%94%E1%83%91%E1%83%94%E1%83%91%E1%83%98%E1%83%A1%20%E1%83%A8%E1%83%94%E1%83%A1%E1%83%90%E1%83%AE%E1%83%94%E1%83%91%20%E1%83%95%E1%83%A1%E1%83%90%E1%83%A3%E1%83%91%E1%83%A0%E1%83%9D%E1%83%91.)
^ka-Q0245-answer

**ka-Q0246** — მე შენი მოქმედებების შესახებ ვსაუბრობ.

I'm talking about your actions.

Possessive forms modify a noun and themselves inflect in relevant contexts. Learn the complete phrase. Possession predicates use particular verbal classes and participant marking.

Why: Possessive pronouns. [[Georgian#^ka-Q0246|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%A8%E1%83%94%E1%83%9C%E1%83%98%20%E1%83%9B%E1%83%9D%E1%83%A5%E1%83%9B%E1%83%94%E1%83%93%E1%83%94%E1%83%91%E1%83%94%E1%83%91%E1%83%98%E1%83%A1%20%E1%83%A8%E1%83%94%E1%83%A1%E1%83%90%E1%83%AE%E1%83%94%E1%83%91%20%E1%83%95%E1%83%A1%E1%83%90%E1%83%A3%E1%83%91%E1%83%A0%E1%83%9D%E1%83%91.)
^ka-Q0246-answer

**ka-Q0247** — აი შენი წიგნი.

Here is your book.

Expected form: **შენი**

Why: Possessive pronouns. [[Georgian#^ka-Q0247|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%98%20%E1%83%A8%E1%83%94%E1%83%9C%E1%83%98%20%E1%83%AC%E1%83%98%E1%83%92%E1%83%9C%E1%83%98.)
^ka-Q0247-answer

**ka-Q0248** — აი შენი წიგნი.

Here is your book.

Expected form: **შენი**

Why: Possessive pronouns. [[Georgian#^ka-Q0248|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%98%20%E1%83%A8%E1%83%94%E1%83%9C%E1%83%98%20%E1%83%AC%E1%83%98%E1%83%92%E1%83%9C%E1%83%98.)
^ka-Q0248-answer

**ka-Q0249** — გიყვართ თქვენი დედა?

Do you love your mother?

Expected form: **თქვენი**

Why: Possessive pronouns. [[Georgian#^ka-Q0249|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%92%E1%83%98%E1%83%A7%E1%83%95%E1%83%90%E1%83%A0%E1%83%97%20%E1%83%97%E1%83%A5%E1%83%95%E1%83%94%E1%83%9C%E1%83%98%20%E1%83%93%E1%83%94%E1%83%93%E1%83%90%3F)
^ka-Q0249-answer

**ka-Q0250** — გიყვართ თქვენი დედა?

Do you love your mother?

Why: Possessive pronouns. [[Georgian#^ka-Q0250|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%92%E1%83%98%E1%83%A7%E1%83%95%E1%83%90%E1%83%A0%E1%83%97%20%E1%83%97%E1%83%A5%E1%83%95%E1%83%94%E1%83%9C%E1%83%98%20%E1%83%93%E1%83%94%E1%83%93%E1%83%90%3F)
^ka-Q0250-answer


### Answers 251–300

**ka-Q0251** — მცივა. შეიძლება ფანჯარა დავხურო?

I'm cold. May I close the window?

Why: Questions: people and things. [[Georgian#^ka-Q0251|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%AA%E1%83%98%E1%83%95%E1%83%90.%20%E1%83%A8%E1%83%94%E1%83%98%E1%83%AB%E1%83%9A%E1%83%94%E1%83%91%E1%83%90%20%E1%83%A4%E1%83%90%E1%83%9C%E1%83%AF%E1%83%90%E1%83%A0%E1%83%90%20%E1%83%93%E1%83%90%E1%83%95%E1%83%AE%E1%83%A3%E1%83%A0%E1%83%9D%3F)
^ka-Q0251-answer

**ka-Q0252** — მცივა. შეიძლება ფანჯარა დავხურო?

I'm cold. May I close the window?

Question words inflect for role and case. ვინ asks who; რა asks what, with forms such as რას for an appropriate oblique/object role. Case depends on the verb series and construction.

Why: Questions: people and things. [[Georgian#^ka-Q0252|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%AA%E1%83%98%E1%83%95%E1%83%90.%20%E1%83%A8%E1%83%94%E1%83%98%E1%83%AB%E1%83%9A%E1%83%94%E1%83%91%E1%83%90%20%E1%83%A4%E1%83%90%E1%83%9C%E1%83%AF%E1%83%90%E1%83%A0%E1%83%90%20%E1%83%93%E1%83%90%E1%83%95%E1%83%AE%E1%83%A3%E1%83%A0%E1%83%9D%3F)
^ka-Q0252-answer

**ka-Q0253** — ახალი მაღაზია მომავალ კვირას გაიხსნება.

The new store is going to open next week.

Expected form: **რას**

Why: Questions: people and things. [[Georgian#^ka-Q0253|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%AE%E1%83%90%E1%83%9A%E1%83%98%20%E1%83%9B%E1%83%90%E1%83%A6%E1%83%90%E1%83%96%E1%83%98%E1%83%90%20%E1%83%9B%E1%83%9D%E1%83%9B%E1%83%90%E1%83%95%E1%83%90%E1%83%9A%20%E1%83%99%E1%83%95%E1%83%98%E1%83%A0%E1%83%90%E1%83%A1%20%E1%83%92%E1%83%90%E1%83%98%E1%83%AE%E1%83%A1%E1%83%9C%E1%83%94%E1%83%91%E1%83%90.)
^ka-Q0253-answer

**ka-Q0254** — ახალი მაღაზია მომავალ კვირას გაიხსნება.

The new store is going to open next week.

Expected form: **რას**

Why: Questions: people and things. [[Georgian#^ka-Q0254|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%AE%E1%83%90%E1%83%9A%E1%83%98%20%E1%83%9B%E1%83%90%E1%83%A6%E1%83%90%E1%83%96%E1%83%98%E1%83%90%20%E1%83%9B%E1%83%9D%E1%83%9B%E1%83%90%E1%83%95%E1%83%90%E1%83%9A%20%E1%83%99%E1%83%95%E1%83%98%E1%83%A0%E1%83%90%E1%83%A1%20%E1%83%92%E1%83%90%E1%83%98%E1%83%AE%E1%83%A1%E1%83%9C%E1%83%94%E1%83%91%E1%83%90.)
^ka-Q0254-answer

**ka-Q0255** — ვინ მოგცა ნებართვა?

Who gave you permission?

Expected form: **ვინ**

Why: Questions: people and things. [[Georgian#^ka-Q0255|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%95%E1%83%98%E1%83%9C%20%E1%83%9B%E1%83%9D%E1%83%92%E1%83%AA%E1%83%90%20%E1%83%9C%E1%83%94%E1%83%91%E1%83%90%E1%83%A0%E1%83%97%E1%83%95%E1%83%90%3F)
^ka-Q0255-answer

**ka-Q0256** — ვინ მოგცა ნებართვა?

Who gave you permission?

Why: Questions: people and things. [[Georgian#^ka-Q0256|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%95%E1%83%98%E1%83%9C%20%E1%83%9B%E1%83%9D%E1%83%92%E1%83%AA%E1%83%90%20%E1%83%9C%E1%83%94%E1%83%91%E1%83%90%E1%83%A0%E1%83%97%E1%83%95%E1%83%90%3F)
^ka-Q0256-answer

**ka-Q0257** — რას იკვლევს სოვეტოლოგი?

What does a Sovietologist study?

Why: Questions: people and things. [[Georgian#^ka-Q0257|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A0%E1%83%90%E1%83%A1%20%E1%83%98%E1%83%99%E1%83%95%E1%83%9A%E1%83%94%E1%83%95%E1%83%A1%20%E1%83%A1%E1%83%9D%E1%83%95%E1%83%94%E1%83%A2%E1%83%9D%E1%83%9A%E1%83%9D%E1%83%92%E1%83%98%3F)
^ka-Q0257-answer

**ka-Q0258** — რას იკვლევს სოვეტოლოგი?

What does a Sovietologist study?

Question words inflect for role and case. ვინ asks who; რა asks what, with forms such as რას for an appropriate oblique/object role. Case depends on the verb series and construction.

Why: Questions: people and things. [[Georgian#^ka-Q0258|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A0%E1%83%90%E1%83%A1%20%E1%83%98%E1%83%99%E1%83%95%E1%83%9A%E1%83%94%E1%83%95%E1%83%A1%20%E1%83%A1%E1%83%9D%E1%83%95%E1%83%94%E1%83%A2%E1%83%9D%E1%83%9A%E1%83%9D%E1%83%92%E1%83%98%3F)
^ka-Q0258-answer

**ka-Q0259** — ვინ გინდა, რომ მოიგოს?

Who do you want to win?

Expected form: **ვინ**

Why: Questions: people and things. [[Georgian#^ka-Q0259|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%95%E1%83%98%E1%83%9C%20%E1%83%92%E1%83%98%E1%83%9C%E1%83%93%E1%83%90%2C%20%E1%83%A0%E1%83%9D%E1%83%9B%20%E1%83%9B%E1%83%9D%E1%83%98%E1%83%92%E1%83%9D%E1%83%A1%3F)
^ka-Q0259-answer

**ka-Q0260** — ვინ გინდა, რომ მოიგოს?

Who do you want to win?

Expected form: **ვინ**

Why: Questions: people and things. [[Georgian#^ka-Q0260|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%95%E1%83%98%E1%83%9C%20%E1%83%92%E1%83%98%E1%83%9C%E1%83%93%E1%83%90%2C%20%E1%83%A0%E1%83%9D%E1%83%9B%20%E1%83%9B%E1%83%9D%E1%83%98%E1%83%92%E1%83%9D%E1%83%A1%3F)
^ka-Q0260-answer

**ka-Q0261** — ტომმა ლექსიკონი იყიდა მარიამისთვის.

Tom bought Mary a dictionary.

Expected form: **ვის**

Why: Questions: people and things. [[Georgian#^ka-Q0261|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%9B%E1%83%90%20%E1%83%9A%E1%83%94%E1%83%A5%E1%83%A1%E1%83%98%E1%83%99%E1%83%9D%E1%83%9C%E1%83%98%20%E1%83%98%E1%83%A7%E1%83%98%E1%83%93%E1%83%90%20%E1%83%9B%E1%83%90%E1%83%A0%E1%83%98%E1%83%90%E1%83%9B%E1%83%98%E1%83%A1%E1%83%97%E1%83%95%E1%83%98%E1%83%A1.)
^ka-Q0261-answer

**ka-Q0262** — ტომმა ლექსიკონი იყიდა მარიამისთვის.

Tom bought Mary a dictionary.

Why: Questions: people and things. [[Georgian#^ka-Q0262|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%9B%E1%83%90%20%E1%83%9A%E1%83%94%E1%83%A5%E1%83%A1%E1%83%98%E1%83%99%E1%83%9D%E1%83%9C%E1%83%98%20%E1%83%98%E1%83%A7%E1%83%98%E1%83%93%E1%83%90%20%E1%83%9B%E1%83%90%E1%83%A0%E1%83%98%E1%83%90%E1%83%9B%E1%83%98%E1%83%A1%E1%83%97%E1%83%95%E1%83%98%E1%83%A1.)
^ka-Q0262-answer

**ka-Q0263** — დავიწყებთ რაც შეიძლება ჩქარა.

We will begin as soon as possible.

Why: Questions: people and things. [[Georgian#^ka-Q0263|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%93%E1%83%90%E1%83%95%E1%83%98%E1%83%AC%E1%83%A7%E1%83%94%E1%83%91%E1%83%97%20%E1%83%A0%E1%83%90%E1%83%AA%20%E1%83%A8%E1%83%94%E1%83%98%E1%83%AB%E1%83%9A%E1%83%94%E1%83%91%E1%83%90%20%E1%83%A9%E1%83%A5%E1%83%90%E1%83%A0%E1%83%90.)
^ka-Q0263-answer

**ka-Q0264** — დავიწყებთ რაც შეიძლება ჩქარა.

We will begin as soon as possible.

Question words inflect for role and case. ვინ asks who; რა asks what, with forms such as რას for an appropriate oblique/object role. Case depends on the verb series and construction.

Why: Questions: people and things. [[Georgian#^ka-Q0264|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%93%E1%83%90%E1%83%95%E1%83%98%E1%83%AC%E1%83%A7%E1%83%94%E1%83%91%E1%83%97%20%E1%83%A0%E1%83%90%E1%83%AA%20%E1%83%A8%E1%83%94%E1%83%98%E1%83%AB%E1%83%9A%E1%83%94%E1%83%91%E1%83%90%20%E1%83%A9%E1%83%A5%E1%83%90%E1%83%A0%E1%83%90.)
^ka-Q0264-answer

**ka-Q0265** — ის წერილს დაწერა.

He wrote a letter.

Expected form: **რა**

Why: Questions: people and things. [[Georgian#^ka-Q0265|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%98%E1%83%A1%20%E1%83%AC%E1%83%94%E1%83%A0%E1%83%98%E1%83%9A%E1%83%A1%20%E1%83%93%E1%83%90%E1%83%AC%E1%83%94%E1%83%A0%E1%83%90.)
^ka-Q0265-answer

**ka-Q0266** — ის წერილს დაწერა.

He wrote a letter.

Expected form: **რა**

Why: Questions: people and things. [[Georgian#^ka-Q0266|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%98%E1%83%A1%20%E1%83%AC%E1%83%94%E1%83%A0%E1%83%98%E1%83%9A%E1%83%A1%20%E1%83%93%E1%83%90%E1%83%AC%E1%83%94%E1%83%A0%E1%83%90.)
^ka-Q0266-answer

**ka-Q0267** — რა ქვია მას?

Which his name?

Expected form: **რა**

Why: Questions: people and things. [[Georgian#^ka-Q0267|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A0%E1%83%90%20%E1%83%A5%E1%83%95%E1%83%98%E1%83%90%20%E1%83%9B%E1%83%90%E1%83%A1%3F)
^ka-Q0267-answer

**ka-Q0268** — რა ქვია მას?

Which his name?

Why: Questions: people and things. [[Georgian#^ka-Q0268|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A0%E1%83%90%20%E1%83%A5%E1%83%95%E1%83%98%E1%83%90%20%E1%83%9B%E1%83%90%E1%83%A1%3F)
^ka-Q0268-answer

**ka-Q0269** — მითხრა, ვინ არის ეს ვაჟი?

Tell me; who is this young man?

Why: Questions: people and things. [[Georgian#^ka-Q0269|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%98%E1%83%97%E1%83%AE%E1%83%A0%E1%83%90%2C%20%E1%83%95%E1%83%98%E1%83%9C%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%94%E1%83%A1%20%E1%83%95%E1%83%90%E1%83%9F%E1%83%98%3F)
^ka-Q0269-answer

**ka-Q0270** — მითხრა, ვინ არის ეს ვაჟი?

Tell me; who is this young man?

Question words inflect for role and case. ვინ asks who; რა asks what, with forms such as რას for an appropriate oblique/object role. Case depends on the verb series and construction.

Why: Questions: people and things. [[Georgian#^ka-Q0270|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%98%E1%83%97%E1%83%AE%E1%83%A0%E1%83%90%2C%20%E1%83%95%E1%83%98%E1%83%9C%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%94%E1%83%A1%20%E1%83%95%E1%83%90%E1%83%9F%E1%83%98%3F)
^ka-Q0270-answer

**ka-Q0271** — ხვალ ვინ მიდის ქალაქში?

Who is going into the city tomorrow?

Expected form: **ვინ**

Why: Questions: people and things. [[Georgian#^ka-Q0271|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%AE%E1%83%95%E1%83%90%E1%83%9A%20%E1%83%95%E1%83%98%E1%83%9C%20%E1%83%9B%E1%83%98%E1%83%93%E1%83%98%E1%83%A1%20%E1%83%A5%E1%83%90%E1%83%9A%E1%83%90%E1%83%A5%E1%83%A8%E1%83%98%3F)
^ka-Q0271-answer

**ka-Q0272** — ხვალ ვინ მიდის ქალაქში?

Who is going into the city tomorrow?

Expected form: **ვინ**

Why: Questions: people and things. [[Georgian#^ka-Q0272|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%AE%E1%83%95%E1%83%90%E1%83%9A%20%E1%83%95%E1%83%98%E1%83%9C%20%E1%83%9B%E1%83%98%E1%83%93%E1%83%98%E1%83%A1%20%E1%83%A5%E1%83%90%E1%83%9A%E1%83%90%E1%83%A5%E1%83%A8%E1%83%98%3F)
^ka-Q0272-answer

**ka-Q0273** — ყოველთვის ვუყურებ ამ სურათს მორყვნით.

I always view this photo with disgust.

Expected form: **ვის**

Why: Questions: people and things. [[Georgian#^ka-Q0273|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A7%E1%83%9D%E1%83%95%E1%83%94%E1%83%9A%E1%83%97%E1%83%95%E1%83%98%E1%83%A1%20%E1%83%95%E1%83%A3%E1%83%A7%E1%83%A3%E1%83%A0%E1%83%94%E1%83%91%20%E1%83%90%E1%83%9B%20%E1%83%A1%E1%83%A3%E1%83%A0%E1%83%90%E1%83%97%E1%83%A1%20%E1%83%9B%E1%83%9D%E1%83%A0%E1%83%A7%E1%83%95%E1%83%9C%E1%83%98%E1%83%97.)
^ka-Q0273-answer

**ka-Q0274** — ყოველთვის ვუყურებ ამ სურათს მორყვნით.

I always view this photo with disgust.

Why: Questions: people and things. [[Georgian#^ka-Q0274|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A7%E1%83%9D%E1%83%95%E1%83%94%E1%83%9A%E1%83%97%E1%83%95%E1%83%98%E1%83%A1%20%E1%83%95%E1%83%A3%E1%83%A7%E1%83%A3%E1%83%A0%E1%83%94%E1%83%91%20%E1%83%90%E1%83%9B%20%E1%83%A1%E1%83%A3%E1%83%A0%E1%83%90%E1%83%97%E1%83%A1%20%E1%83%9B%E1%83%9D%E1%83%A0%E1%83%A7%E1%83%95%E1%83%9C%E1%83%98%E1%83%97.)
^ka-Q0274-answer

**ka-Q0275** — გუშინ იყო კვირა, შაბათი კი არა.

Yesterday was Sunday, not Saturday.

Why: Questions: people and things. [[Georgian#^ka-Q0275|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%92%E1%83%A3%E1%83%A8%E1%83%98%E1%83%9C%20%E1%83%98%E1%83%A7%E1%83%9D%20%E1%83%99%E1%83%95%E1%83%98%E1%83%A0%E1%83%90%2C%20%E1%83%A8%E1%83%90%E1%83%91%E1%83%90%E1%83%97%E1%83%98%20%E1%83%99%E1%83%98%20%E1%83%90%E1%83%A0%E1%83%90.)
^ka-Q0275-answer

**ka-Q0276** — გუშინ იყო კვირა, შაბათი კი არა.

Yesterday was Sunday, not Saturday.

Question words inflect for role and case. ვინ asks who; რა asks what, with forms such as რას for an appropriate oblique/object role. Case depends on the verb series and construction.

Why: Questions: people and things. [[Georgian#^ka-Q0276|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%92%E1%83%A3%E1%83%A8%E1%83%98%E1%83%9C%20%E1%83%98%E1%83%A7%E1%83%9D%20%E1%83%99%E1%83%95%E1%83%98%E1%83%A0%E1%83%90%2C%20%E1%83%A8%E1%83%90%E1%83%91%E1%83%90%E1%83%97%E1%83%98%20%E1%83%99%E1%83%98%20%E1%83%90%E1%83%A0%E1%83%90.)
^ka-Q0276-answer

**ka-Q0277** — შენ რა უპასუხე?

What did you answer?

Expected form: **რა**

Why: Questions: people and things. [[Georgian#^ka-Q0277|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A8%E1%83%94%E1%83%9C%20%E1%83%A0%E1%83%90%20%E1%83%A3%E1%83%9E%E1%83%90%E1%83%A1%E1%83%A3%E1%83%AE%E1%83%94%3F)
^ka-Q0277-answer

**ka-Q0278** — შენ რა უპასუხე?

What did you answer?

Expected form: **რა**

Why: Questions: people and things. [[Georgian#^ka-Q0278|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A8%E1%83%94%E1%83%9C%20%E1%83%A0%E1%83%90%20%E1%83%A3%E1%83%9E%E1%83%90%E1%83%A1%E1%83%A3%E1%83%AE%E1%83%94%3F)
^ka-Q0278-answer

**ka-Q0279** — ეს რა ეღირება?

How much will it cost?

Expected form: **რა**

Why: Questions: people and things. [[Georgian#^ka-Q0279|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%94%E1%83%A1%20%E1%83%A0%E1%83%90%20%E1%83%94%E1%83%A6%E1%83%98%E1%83%A0%E1%83%94%E1%83%91%E1%83%90%3F)
^ka-Q0279-answer

**ka-Q0280** — ეს რა ეღირება?

How much will it cost?

Why: Questions: people and things. [[Georgian#^ka-Q0280|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%94%E1%83%A1%20%E1%83%A0%E1%83%90%20%E1%83%94%E1%83%A6%E1%83%98%E1%83%A0%E1%83%94%E1%83%91%E1%83%90%3F)
^ka-Q0280-answer

**ka-Q0281** — ვიღაც დახურავს ფანჯარა.

Someone will close the window.

Why: Questions: people and things. [[Georgian#^ka-Q0281|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%95%E1%83%98%E1%83%A6%E1%83%90%E1%83%AA%20%E1%83%93%E1%83%90%E1%83%AE%E1%83%A3%E1%83%A0%E1%83%90%E1%83%95%E1%83%A1%20%E1%83%A4%E1%83%90%E1%83%9C%E1%83%AF%E1%83%90%E1%83%A0%E1%83%90.)
^ka-Q0281-answer

**ka-Q0282** — ვიღაც დახურავს ფანჯარა.

Someone will close the window.

Question words inflect for role and case. ვინ asks who; რა asks what, with forms such as რას for an appropriate oblique/object role. Case depends on the verb series and construction.

Why: Questions: people and things. [[Georgian#^ka-Q0282|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%95%E1%83%98%E1%83%A6%E1%83%90%E1%83%AA%20%E1%83%93%E1%83%90%E1%83%AE%E1%83%A3%E1%83%A0%E1%83%90%E1%83%95%E1%83%A1%20%E1%83%A4%E1%83%90%E1%83%9C%E1%83%AF%E1%83%90%E1%83%A0%E1%83%90.)
^ka-Q0282-answer

**ka-Q0283** — მე არა ვარ კარგი ადამიანი.

I'm not a good person.

Expected form: **რა**

Why: Questions: people and things. [[Georgian#^ka-Q0283|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%90%E1%83%A0%E1%83%90%20%E1%83%95%E1%83%90%E1%83%A0%20%E1%83%99%E1%83%90%E1%83%A0%E1%83%92%E1%83%98%20%E1%83%90%E1%83%93%E1%83%90%E1%83%9B%E1%83%98%E1%83%90%E1%83%9C%E1%83%98.)
^ka-Q0283-answer

**ka-Q0284** — მე არა ვარ კარგი ადამიანი.

I'm not a good person.

Expected form: **რა**

Why: Questions: people and things. [[Georgian#^ka-Q0284|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%90%E1%83%A0%E1%83%90%20%E1%83%95%E1%83%90%E1%83%A0%20%E1%83%99%E1%83%90%E1%83%A0%E1%83%92%E1%83%98%20%E1%83%90%E1%83%93%E1%83%90%E1%83%9B%E1%83%98%E1%83%90%E1%83%9C%E1%83%98.)
^ka-Q0284-answer

**ka-Q0285** — შენ ჩემთვის ყველაფერი ხარ.

You are everything to me.

Expected form: **ვის**

Why: Questions: people and things. [[Georgian#^ka-Q0285|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A8%E1%83%94%E1%83%9C%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%97%E1%83%95%E1%83%98%E1%83%A1%20%E1%83%A7%E1%83%95%E1%83%94%E1%83%9A%E1%83%90%E1%83%A4%E1%83%94%E1%83%A0%E1%83%98%20%E1%83%AE%E1%83%90%E1%83%A0.)
^ka-Q0285-answer

**ka-Q0286** — შენ ჩემთვის ყველაფერი ხარ.

You are everything to me.

Why: Questions: people and things. [[Georgian#^ka-Q0286|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A8%E1%83%94%E1%83%9C%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%97%E1%83%95%E1%83%98%E1%83%A1%20%E1%83%A7%E1%83%95%E1%83%94%E1%83%9A%E1%83%90%E1%83%A4%E1%83%94%E1%83%A0%E1%83%98%20%E1%83%AE%E1%83%90%E1%83%A0.)
^ka-Q0286-answer

**ka-Q0287** — მან უნდა იცოდეს რა ხდება.

He needs to know what's going on.

Why: Questions: people and things. [[Georgian#^ka-Q0287|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%90%E1%83%9C%20%E1%83%A3%E1%83%9C%E1%83%93%E1%83%90%20%E1%83%98%E1%83%AA%E1%83%9D%E1%83%93%E1%83%94%E1%83%A1%20%E1%83%A0%E1%83%90%20%E1%83%AE%E1%83%93%E1%83%94%E1%83%91%E1%83%90.)
^ka-Q0287-answer

**ka-Q0288** — მან უნდა იცოდეს რა ხდება.

He needs to know what's going on.

Question words inflect for role and case. ვინ asks who; რა asks what, with forms such as რას for an appropriate oblique/object role. Case depends on the verb series and construction.

Why: Questions: people and things. [[Georgian#^ka-Q0288|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%90%E1%83%9C%20%E1%83%A3%E1%83%9C%E1%83%93%E1%83%90%20%E1%83%98%E1%83%AA%E1%83%9D%E1%83%93%E1%83%94%E1%83%A1%20%E1%83%A0%E1%83%90%20%E1%83%AE%E1%83%93%E1%83%94%E1%83%91%E1%83%90.)
^ka-Q0288-answer

**ka-Q0289** — მოდი ვიმღეროთ სიმღერა ინგლისურად.

Let's sing a song in English.

Expected form: **რა**

Why: Questions: people and things. [[Georgian#^ka-Q0289|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%9D%E1%83%93%E1%83%98%20%E1%83%95%E1%83%98%E1%83%9B%E1%83%A6%E1%83%94%E1%83%A0%E1%83%9D%E1%83%97%20%E1%83%A1%E1%83%98%E1%83%9B%E1%83%A6%E1%83%94%E1%83%A0%E1%83%90%20%E1%83%98%E1%83%9C%E1%83%92%E1%83%9A%E1%83%98%E1%83%A1%E1%83%A3%E1%83%A0%E1%83%90%E1%83%93.)
^ka-Q0289-answer

**ka-Q0290** — მოდი ვიმღეროთ სიმღერა ინგლისურად.

Let's sing a song in English.

Expected form: **რა**

Why: Questions: people and things. [[Georgian#^ka-Q0290|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%9D%E1%83%93%E1%83%98%20%E1%83%95%E1%83%98%E1%83%9B%E1%83%A6%E1%83%94%E1%83%A0%E1%83%9D%E1%83%97%20%E1%83%A1%E1%83%98%E1%83%9B%E1%83%A6%E1%83%94%E1%83%A0%E1%83%90%20%E1%83%98%E1%83%9C%E1%83%92%E1%83%9A%E1%83%98%E1%83%A1%E1%83%A3%E1%83%A0%E1%83%90%E1%83%93.)
^ka-Q0290-answer

**ka-Q0291** — ცხენზე შემჯდარმა კაცმა ჩამოგვიარა.

A man on horseback came along the path.

Expected form: **რა**

Why: Questions: people and things. [[Georgian#^ka-Q0291|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%AA%E1%83%AE%E1%83%94%E1%83%9C%E1%83%96%E1%83%94%20%E1%83%A8%E1%83%94%E1%83%9B%E1%83%AF%E1%83%93%E1%83%90%E1%83%A0%E1%83%9B%E1%83%90%20%E1%83%99%E1%83%90%E1%83%AA%E1%83%9B%E1%83%90%20%E1%83%A9%E1%83%90%E1%83%9B%E1%83%9D%E1%83%92%E1%83%95%E1%83%98%E1%83%90%E1%83%A0%E1%83%90.)
^ka-Q0291-answer

**ka-Q0292** — ცხენზე შემჯდარმა კაცმა ჩამოგვიარა.

A man on horseback came along the path.

Why: Questions: people and things. [[Georgian#^ka-Q0292|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%AA%E1%83%AE%E1%83%94%E1%83%9C%E1%83%96%E1%83%94%20%E1%83%A8%E1%83%94%E1%83%9B%E1%83%AF%E1%83%93%E1%83%90%E1%83%A0%E1%83%9B%E1%83%90%20%E1%83%99%E1%83%90%E1%83%AA%E1%83%9B%E1%83%90%20%E1%83%A9%E1%83%90%E1%83%9B%E1%83%9D%E1%83%92%E1%83%95%E1%83%98%E1%83%90%E1%83%A0%E1%83%90.)
^ka-Q0292-answer

**ka-Q0293** — მე არ ვარ მზად ქორწინებისთვის.

I'm not ready for marriage.

Why: Questions: people and things. [[Georgian#^ka-Q0293|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%90%E1%83%A0%20%E1%83%95%E1%83%90%E1%83%A0%20%E1%83%9B%E1%83%96%E1%83%90%E1%83%93%20%E1%83%A5%E1%83%9D%E1%83%A0%E1%83%AC%E1%83%98%E1%83%9C%E1%83%94%E1%83%91%E1%83%98%E1%83%A1%E1%83%97%E1%83%95%E1%83%98%E1%83%A1.)
^ka-Q0293-answer

**ka-Q0294** — მე არ ვარ მზად ქორწინებისთვის.

I'm not ready for marriage.

Question words inflect for role and case. ვინ asks who; რა asks what, with forms such as რას for an appropriate oblique/object role. Case depends on the verb series and construction.

Why: Questions: people and things. [[Georgian#^ka-Q0294|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%90%E1%83%A0%20%E1%83%95%E1%83%90%E1%83%A0%20%E1%83%9B%E1%83%96%E1%83%90%E1%83%93%20%E1%83%A5%E1%83%9D%E1%83%A0%E1%83%AC%E1%83%98%E1%83%9C%E1%83%94%E1%83%91%E1%83%98%E1%83%A1%E1%83%97%E1%83%95%E1%83%98%E1%83%A1.)
^ka-Q0294-answer

**ka-Q0295** — იმის გამო ვერ მჯერა.

That's why I cannot believe it.

Expected form: **რა**

Why: Questions: people and things. [[Georgian#^ka-Q0295|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%98%E1%83%9B%E1%83%98%E1%83%A1%20%E1%83%92%E1%83%90%E1%83%9B%E1%83%9D%20%E1%83%95%E1%83%94%E1%83%A0%20%E1%83%9B%E1%83%AF%E1%83%94%E1%83%A0%E1%83%90.)
^ka-Q0295-answer

**ka-Q0296** — იმის გამო ვერ მჯერა.

That's why I cannot believe it.

Expected form: **რა**

Why: Questions: people and things. [[Georgian#^ka-Q0296|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%98%E1%83%9B%E1%83%98%E1%83%A1%20%E1%83%92%E1%83%90%E1%83%9B%E1%83%9D%20%E1%83%95%E1%83%94%E1%83%A0%20%E1%83%9B%E1%83%AF%E1%83%94%E1%83%A0%E1%83%90.)
^ka-Q0296-answer

**ka-Q0297** — რა დახმარებას მივიღებ?

What help do I get?

Expected form: **რა**

Why: Questions: people and things. [[Georgian#^ka-Q0297|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A0%E1%83%90%20%E1%83%93%E1%83%90%E1%83%AE%E1%83%9B%E1%83%90%E1%83%A0%E1%83%94%E1%83%91%E1%83%90%E1%83%A1%20%E1%83%9B%E1%83%98%E1%83%95%E1%83%98%E1%83%A6%E1%83%94%E1%83%91%3F)
^ka-Q0297-answer

**ka-Q0298** — რა დახმარებას მივიღებ?

What help do I get?

Why: Questions: people and things. [[Georgian#^ka-Q0298|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A0%E1%83%90%20%E1%83%93%E1%83%90%E1%83%AE%E1%83%9B%E1%83%90%E1%83%A0%E1%83%94%E1%83%91%E1%83%90%E1%83%A1%20%E1%83%9B%E1%83%98%E1%83%95%E1%83%98%E1%83%A6%E1%83%94%E1%83%91%3F)
^ka-Q0298-answer

**ka-Q0299** — ვინ ამას დაიჯერებს?

Who will believe this?

Why: Questions: people and things. [[Georgian#^ka-Q0299|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%95%E1%83%98%E1%83%9C%20%E1%83%90%E1%83%9B%E1%83%90%E1%83%A1%20%E1%83%93%E1%83%90%E1%83%98%E1%83%AF%E1%83%94%E1%83%A0%E1%83%94%E1%83%91%E1%83%A1%3F)
^ka-Q0299-answer

**ka-Q0300** — ვინ ამას დაიჯერებს?

Who will believe this?

Question words inflect for role and case. ვინ asks who; რა asks what, with forms such as რას for an appropriate oblique/object role. Case depends on the verb series and construction.

Why: Questions: people and things. [[Georgian#^ka-Q0300|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%95%E1%83%98%E1%83%9C%20%E1%83%90%E1%83%9B%E1%83%90%E1%83%A1%20%E1%83%93%E1%83%90%E1%83%98%E1%83%AF%E1%83%94%E1%83%A0%E1%83%94%E1%83%91%E1%83%A1%3F)
^ka-Q0300-answer


### Answers 301–350

**ka-Q0301** — სად გინდა წასვლა?

Where do you want to go?

Expected form: **სად**

Why: Questions: place and manner. [[Georgian#^ka-Q0301|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A1%E1%83%90%E1%83%93%20%E1%83%92%E1%83%98%E1%83%9C%E1%83%93%E1%83%90%20%E1%83%AC%E1%83%90%E1%83%A1%E1%83%95%E1%83%9A%E1%83%90%3F)
^ka-Q0301-answer

**ka-Q0302** — სად გინდა წასვლა?

Where do you want to go?

Expected form: **სად**

Why: Questions: place and manner. [[Georgian#^ka-Q0302|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A1%E1%83%90%E1%83%93%20%E1%83%92%E1%83%98%E1%83%9C%E1%83%93%E1%83%90%20%E1%83%AC%E1%83%90%E1%83%A1%E1%83%95%E1%83%9A%E1%83%90%3F)
^ka-Q0302-answer

**ka-Q0303** — აი რატომ ინგლისურს სწავლობენ.

That is what they study English for.

Expected form: **რატომ**

Why: Questions: place and manner. [[Georgian#^ka-Q0303|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%98%20%E1%83%A0%E1%83%90%E1%83%A2%E1%83%9D%E1%83%9B%20%E1%83%98%E1%83%9C%E1%83%92%E1%83%9A%E1%83%98%E1%83%A1%E1%83%A3%E1%83%A0%E1%83%A1%20%E1%83%A1%E1%83%AC%E1%83%90%E1%83%95%E1%83%9A%E1%83%9D%E1%83%91%E1%83%94%E1%83%9C.)
^ka-Q0303-answer

**ka-Q0304** — აი რატომ ინგლისურს სწავლობენ.

That is what they study English for.

Why: Questions: place and manner. [[Georgian#^ka-Q0304|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%98%20%E1%83%A0%E1%83%90%E1%83%A2%E1%83%9D%E1%83%9B%20%E1%83%98%E1%83%9C%E1%83%92%E1%83%9A%E1%83%98%E1%83%A1%E1%83%A3%E1%83%A0%E1%83%A1%20%E1%83%A1%E1%83%AC%E1%83%90%E1%83%95%E1%83%9A%E1%83%9D%E1%83%91%E1%83%94%E1%83%9C.)
^ka-Q0304-answer

**ka-Q0305** — როგორ შემიძლია დავარწმუნო?

How can I be sure?

Why: Questions: place and manner. [[Georgian#^ka-Q0305|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A0%E1%83%9D%E1%83%92%E1%83%9D%E1%83%A0%20%E1%83%A8%E1%83%94%E1%83%9B%E1%83%98%E1%83%AB%E1%83%9A%E1%83%98%E1%83%90%20%E1%83%93%E1%83%90%E1%83%95%E1%83%90%E1%83%A0%E1%83%AC%E1%83%9B%E1%83%A3%E1%83%9C%E1%83%9D%3F)
^ka-Q0305-answer

**ka-Q0306** — როგორ შემიძლია დავარწმუნო?

How can I be sure?

Different question forms request location, source, direction, manner, time or reason. The English word where can hide distinctions. Preserve the relation in your answer.

Why: Questions: place and manner. [[Georgian#^ka-Q0306|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A0%E1%83%9D%E1%83%92%E1%83%9D%E1%83%A0%20%E1%83%A8%E1%83%94%E1%83%9B%E1%83%98%E1%83%AB%E1%83%9A%E1%83%98%E1%83%90%20%E1%83%93%E1%83%90%E1%83%95%E1%83%90%E1%83%A0%E1%83%AC%E1%83%9B%E1%83%A3%E1%83%9C%E1%83%9D%3F)
^ka-Q0306-answer

**ka-Q0307** — არსად ვაპირებ წასვლას.

I'm not going to go anywhere.

Expected form: **სად**

Why: Questions: place and manner. [[Georgian#^ka-Q0307|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%A0%E1%83%A1%E1%83%90%E1%83%93%20%E1%83%95%E1%83%90%E1%83%9E%E1%83%98%E1%83%A0%E1%83%94%E1%83%91%20%E1%83%AC%E1%83%90%E1%83%A1%E1%83%95%E1%83%9A%E1%83%90%E1%83%A1.)
^ka-Q0307-answer

**ka-Q0308** — არსად ვაპირებ წასვლას.

I'm not going to go anywhere.

Expected form: **სად**

Why: Questions: place and manner. [[Georgian#^ka-Q0308|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%A0%E1%83%A1%E1%83%90%E1%83%93%20%E1%83%95%E1%83%90%E1%83%9E%E1%83%98%E1%83%A0%E1%83%94%E1%83%91%20%E1%83%AC%E1%83%90%E1%83%A1%E1%83%95%E1%83%9A%E1%83%90%E1%83%A1.)
^ka-Q0308-answer

**ka-Q0309** — ტომმა როგორ წავიდა ავსტრალიაში?

How did Tom go to Australia?

Expected form: **როგორ**

Why: Questions: place and manner. [[Georgian#^ka-Q0309|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%9B%E1%83%90%20%E1%83%A0%E1%83%9D%E1%83%92%E1%83%9D%E1%83%A0%20%E1%83%AC%E1%83%90%E1%83%95%E1%83%98%E1%83%93%E1%83%90%20%E1%83%90%E1%83%95%E1%83%A1%E1%83%A2%E1%83%A0%E1%83%90%E1%83%9A%E1%83%98%E1%83%90%E1%83%A8%E1%83%98%3F)
^ka-Q0309-answer

**ka-Q0310** — ტომმა როგორ წავიდა ავსტრალიაში?

How did Tom go to Australia?

Why: Questions: place and manner. [[Georgian#^ka-Q0310|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%9B%E1%83%90%20%E1%83%A0%E1%83%9D%E1%83%92%E1%83%9D%E1%83%A0%20%E1%83%AC%E1%83%90%E1%83%95%E1%83%98%E1%83%93%E1%83%90%20%E1%83%90%E1%83%95%E1%83%A1%E1%83%A2%E1%83%A0%E1%83%90%E1%83%9A%E1%83%98%E1%83%90%E1%83%A8%E1%83%98%3F)
^ka-Q0310-answer

**ka-Q0311** — მარინამ იცის, კრება სად იქნება.

Marina knows where the meeting will be.

Why: Questions: place and manner. [[Georgian#^ka-Q0311|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%90%E1%83%A0%E1%83%98%E1%83%9C%E1%83%90%E1%83%9B%20%E1%83%98%E1%83%AA%E1%83%98%E1%83%A1%2C%20%E1%83%99%E1%83%A0%E1%83%94%E1%83%91%E1%83%90%20%E1%83%A1%E1%83%90%E1%83%93%20%E1%83%98%E1%83%A5%E1%83%9C%E1%83%94%E1%83%91%E1%83%90.)
^ka-Q0311-answer

**ka-Q0312** — მარინამ იცის, კრება სად იქნება.

Marina knows where the meeting will be.

Different question forms request location, source, direction, manner, time or reason. The English word where can hide distinctions. Preserve the relation in your answer.

Why: Questions: place and manner. [[Georgian#^ka-Q0312|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%90%E1%83%A0%E1%83%98%E1%83%9C%E1%83%90%E1%83%9B%20%E1%83%98%E1%83%AA%E1%83%98%E1%83%A1%2C%20%E1%83%99%E1%83%A0%E1%83%94%E1%83%91%E1%83%90%20%E1%83%A1%E1%83%90%E1%83%93%20%E1%83%98%E1%83%A5%E1%83%9C%E1%83%94%E1%83%91%E1%83%90.)
^ka-Q0312-answer

**ka-Q0313** — სად არის სასტუმრო?

Where is the hotel?

Expected form: **სად**

Why: Questions: place and manner. [[Georgian#^ka-Q0313|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A1%E1%83%90%E1%83%93%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%A1%E1%83%90%E1%83%A1%E1%83%A2%E1%83%A3%E1%83%9B%E1%83%A0%E1%83%9D%3F)
^ka-Q0313-answer

**ka-Q0314** — სად არის სასტუმრო?

Where is the hotel?

Expected form: **სად**

Why: Questions: place and manner. [[Georgian#^ka-Q0314|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A1%E1%83%90%E1%83%93%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%A1%E1%83%90%E1%83%A1%E1%83%A2%E1%83%A3%E1%83%9B%E1%83%A0%E1%83%9D%3F)
^ka-Q0314-answer

**ka-Q0315** — „სად ცხოვრობ შენ?“ „მე ტოკიოში ვცხოვრობ.“

"Where do you live?" "I live in Tokyo."

Expected form: **სად**

Why: Questions: place and manner. [[Georgian#^ka-Q0315|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E2%80%9E%E1%83%A1%E1%83%90%E1%83%93%20%E1%83%AA%E1%83%AE%E1%83%9D%E1%83%95%E1%83%A0%E1%83%9D%E1%83%91%20%E1%83%A8%E1%83%94%E1%83%9C%3F%E2%80%9C%20%E2%80%9E%E1%83%9B%E1%83%94%20%E1%83%A2%E1%83%9D%E1%83%99%E1%83%98%E1%83%9D%E1%83%A8%E1%83%98%20%E1%83%95%E1%83%AA%E1%83%AE%E1%83%9D%E1%83%95%E1%83%A0%E1%83%9D%E1%83%91.%E2%80%9C)
^ka-Q0315-answer

**ka-Q0316** — „სად ცხოვრობ შენ?“ „მე ტოკიოში ვცხოვრობ.“

"Where do you live?" "I live in Tokyo."

Why: Questions: place and manner. [[Georgian#^ka-Q0316|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E2%80%9E%E1%83%A1%E1%83%90%E1%83%93%20%E1%83%AA%E1%83%AE%E1%83%9D%E1%83%95%E1%83%A0%E1%83%9D%E1%83%91%20%E1%83%A8%E1%83%94%E1%83%9C%3F%E2%80%9C%20%E2%80%9E%E1%83%9B%E1%83%94%20%E1%83%A2%E1%83%9D%E1%83%99%E1%83%98%E1%83%9D%E1%83%A8%E1%83%98%20%E1%83%95%E1%83%AA%E1%83%AE%E1%83%9D%E1%83%95%E1%83%A0%E1%83%9D%E1%83%91.%E2%80%9C)
^ka-Q0316-answer

**ka-Q0317** — სად ნახე ამ ქალებს?

Where have you seen these women?

Why: Questions: place and manner. [[Georgian#^ka-Q0317|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A1%E1%83%90%E1%83%93%20%E1%83%9C%E1%83%90%E1%83%AE%E1%83%94%20%E1%83%90%E1%83%9B%20%E1%83%A5%E1%83%90%E1%83%9A%E1%83%94%E1%83%91%E1%83%A1%3F)
^ka-Q0317-answer

**ka-Q0318** — სად ნახე ამ ქალებს?

Where have you seen these women?

Different question forms request location, source, direction, manner, time or reason. The English word where can hide distinctions. Preserve the relation in your answer.

Why: Questions: place and manner. [[Georgian#^ka-Q0318|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A1%E1%83%90%E1%83%93%20%E1%83%9C%E1%83%90%E1%83%AE%E1%83%94%20%E1%83%90%E1%83%9B%20%E1%83%A5%E1%83%90%E1%83%9A%E1%83%94%E1%83%91%E1%83%A1%3F)
^ka-Q0318-answer

**ka-Q0319** — სად იყავი წუხელ?

Where were you last night?

Expected form: **სად**

Why: Questions: place and manner. [[Georgian#^ka-Q0319|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A1%E1%83%90%E1%83%93%20%E1%83%98%E1%83%A7%E1%83%90%E1%83%95%E1%83%98%20%E1%83%AC%E1%83%A3%E1%83%AE%E1%83%94%E1%83%9A%3F)
^ka-Q0319-answer

**ka-Q0320** — სად იყავი წუხელ?

Where were you last night?

Expected form: **სად**

Why: Questions: place and manner. [[Georgian#^ka-Q0320|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A1%E1%83%90%E1%83%93%20%E1%83%98%E1%83%A7%E1%83%90%E1%83%95%E1%83%98%20%E1%83%AC%E1%83%A3%E1%83%AE%E1%83%94%E1%83%9A%3F)
^ka-Q0320-answer

**ka-Q0321** — საიდან ეს დროშა?

Where does this flag come from?

Expected form: **საიდან**

Why: Questions: place and manner. [[Georgian#^ka-Q0321|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A1%E1%83%90%E1%83%98%E1%83%93%E1%83%90%E1%83%9C%20%E1%83%94%E1%83%A1%20%E1%83%93%E1%83%A0%E1%83%9D%E1%83%A8%E1%83%90%3F)
^ka-Q0321-answer

**ka-Q0322** — საიდან ეს დროშა?

Where does this flag come from?

Why: Questions: place and manner. [[Georgian#^ka-Q0322|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A1%E1%83%90%E1%83%98%E1%83%93%E1%83%90%E1%83%9C%20%E1%83%94%E1%83%A1%20%E1%83%93%E1%83%A0%E1%83%9D%E1%83%A8%E1%83%90%3F)
^ka-Q0322-answer

**ka-Q0323** — რატომ შენს ხელში დანაა?

Why do you have a knife in your hand?

Why: Questions: place and manner. [[Georgian#^ka-Q0323|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A0%E1%83%90%E1%83%A2%E1%83%9D%E1%83%9B%20%E1%83%A8%E1%83%94%E1%83%9C%E1%83%A1%20%E1%83%AE%E1%83%94%E1%83%9A%E1%83%A8%E1%83%98%20%E1%83%93%E1%83%90%E1%83%9C%E1%83%90%E1%83%90%3F)
^ka-Q0323-answer

**ka-Q0324** — რატომ შენს ხელში დანაა?

Why do you have a knife in your hand?

Different question forms request location, source, direction, manner, time or reason. The English word where can hide distinctions. Preserve the relation in your answer.

Why: Questions: place and manner. [[Georgian#^ka-Q0324|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A0%E1%83%90%E1%83%A2%E1%83%9D%E1%83%9B%20%E1%83%A8%E1%83%94%E1%83%9C%E1%83%A1%20%E1%83%AE%E1%83%94%E1%83%9A%E1%83%A8%E1%83%98%20%E1%83%93%E1%83%90%E1%83%9C%E1%83%90%E1%83%90%3F)
^ka-Q0324-answer

**ka-Q0325** — იცით, სად იქნება კრება?

Do you know where the meeting will be?

Expected form: **სად**

Why: Questions: place and manner. [[Georgian#^ka-Q0325|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%98%E1%83%AA%E1%83%98%E1%83%97%2C%20%E1%83%A1%E1%83%90%E1%83%93%20%E1%83%98%E1%83%A5%E1%83%9C%E1%83%94%E1%83%91%E1%83%90%20%E1%83%99%E1%83%A0%E1%83%94%E1%83%91%E1%83%90%3F)
^ka-Q0325-answer

**ka-Q0326** — იცით, სად იქნება კრება?

Do you know where the meeting will be?

Expected form: **სად**

Why: Questions: place and manner. [[Georgian#^ka-Q0326|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%98%E1%83%AA%E1%83%98%E1%83%97%2C%20%E1%83%A1%E1%83%90%E1%83%93%20%E1%83%98%E1%83%A5%E1%83%9C%E1%83%94%E1%83%91%E1%83%90%20%E1%83%99%E1%83%A0%E1%83%94%E1%83%91%E1%83%90%3F)
^ka-Q0326-answer

**ka-Q0327** — ტომი როგორ მიდის ავსტრალიაში?

How is Tom going to Australia?

Expected form: **როგორ**

Why: Questions: place and manner. [[Georgian#^ka-Q0327|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%98%20%E1%83%A0%E1%83%9D%E1%83%92%E1%83%9D%E1%83%A0%20%E1%83%9B%E1%83%98%E1%83%93%E1%83%98%E1%83%A1%20%E1%83%90%E1%83%95%E1%83%A1%E1%83%A2%E1%83%A0%E1%83%90%E1%83%9A%E1%83%98%E1%83%90%E1%83%A8%E1%83%98%3F)
^ka-Q0327-answer

**ka-Q0328** — ტომი როგორ მიდის ავსტრალიაში?

How is Tom going to Australia?

Why: Questions: place and manner. [[Georgian#^ka-Q0328|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%98%20%E1%83%A0%E1%83%9D%E1%83%92%E1%83%9D%E1%83%A0%20%E1%83%9B%E1%83%98%E1%83%93%E1%83%98%E1%83%A1%20%E1%83%90%E1%83%95%E1%83%A1%E1%83%A2%E1%83%A0%E1%83%90%E1%83%9A%E1%83%98%E1%83%90%E1%83%A8%E1%83%98%3F)
^ka-Q0328-answer

**ka-Q0329** — სად არის საჭმელი?

Where is the food?

Why: Questions: place and manner. [[Georgian#^ka-Q0329|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A1%E1%83%90%E1%83%93%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%A1%E1%83%90%E1%83%AD%E1%83%9B%E1%83%94%E1%83%9A%E1%83%98%3F)
^ka-Q0329-answer

**ka-Q0330** — სად არის საჭმელი?

Where is the food?

Different question forms request location, source, direction, manner, time or reason. The English word where can hide distinctions. Preserve the relation in your answer.

Why: Questions: place and manner. [[Georgian#^ka-Q0330|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A1%E1%83%90%E1%83%93%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%A1%E1%83%90%E1%83%AD%E1%83%9B%E1%83%94%E1%83%9A%E1%83%98%3F)
^ka-Q0330-answer

**ka-Q0331** — წიგნი მინდა. სად არის წიგნის მაღაზია?

I want a book. Where is the bookstore?

Expected form: **სად**

Why: Questions: place and manner. [[Georgian#^ka-Q0331|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%AC%E1%83%98%E1%83%92%E1%83%9C%E1%83%98%20%E1%83%9B%E1%83%98%E1%83%9C%E1%83%93%E1%83%90.%20%E1%83%A1%E1%83%90%E1%83%93%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%AC%E1%83%98%E1%83%92%E1%83%9C%E1%83%98%E1%83%A1%20%E1%83%9B%E1%83%90%E1%83%A6%E1%83%90%E1%83%96%E1%83%98%E1%83%90%3F)
^ka-Q0331-answer

**ka-Q0332** — წიგნი მინდა. სად არის წიგნის მაღაზია?

I want a book. Where is the bookstore?

Expected form: **სად**

Why: Questions: place and manner. [[Georgian#^ka-Q0332|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%AC%E1%83%98%E1%83%92%E1%83%9C%E1%83%98%20%E1%83%9B%E1%83%98%E1%83%9C%E1%83%93%E1%83%90.%20%E1%83%A1%E1%83%90%E1%83%93%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%AC%E1%83%98%E1%83%92%E1%83%9C%E1%83%98%E1%83%A1%20%E1%83%9B%E1%83%90%E1%83%A6%E1%83%90%E1%83%96%E1%83%98%E1%83%90%3F)
^ka-Q0332-answer

**ka-Q0333** — სად არ გინდა წასვლა?

Where do you not want to go?

Expected form: **სად**

Why: Questions: place and manner. [[Georgian#^ka-Q0333|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A1%E1%83%90%E1%83%93%20%E1%83%90%E1%83%A0%20%E1%83%92%E1%83%98%E1%83%9C%E1%83%93%E1%83%90%20%E1%83%AC%E1%83%90%E1%83%A1%E1%83%95%E1%83%9A%E1%83%90%3F)
^ka-Q0333-answer

**ka-Q0334** — სად არ გინდა წასვლა?

Where do you not want to go?

Why: Questions: place and manner. [[Georgian#^ka-Q0334|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A1%E1%83%90%E1%83%93%20%E1%83%90%E1%83%A0%20%E1%83%92%E1%83%98%E1%83%9C%E1%83%93%E1%83%90%20%E1%83%AC%E1%83%90%E1%83%A1%E1%83%95%E1%83%9A%E1%83%90%3F)
^ka-Q0334-answer

**ka-Q0335** — აი რატომ სწავლობენ ინგლისურს.

That is what they study English for.

Why: Questions: place and manner. [[Georgian#^ka-Q0335|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%98%20%E1%83%A0%E1%83%90%E1%83%A2%E1%83%9D%E1%83%9B%20%E1%83%A1%E1%83%AC%E1%83%90%E1%83%95%E1%83%9A%E1%83%9D%E1%83%91%E1%83%94%E1%83%9C%20%E1%83%98%E1%83%9C%E1%83%92%E1%83%9A%E1%83%98%E1%83%A1%E1%83%A3%E1%83%A0%E1%83%A1.)
^ka-Q0335-answer

**ka-Q0336** — აი რატომ სწავლობენ ინგლისურს.

That is what they study English for.

Different question forms request location, source, direction, manner, time or reason. The English word where can hide distinctions. Preserve the relation in your answer.

Why: Questions: place and manner. [[Georgian#^ka-Q0336|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%98%20%E1%83%A0%E1%83%90%E1%83%A2%E1%83%9D%E1%83%9B%20%E1%83%A1%E1%83%AC%E1%83%90%E1%83%95%E1%83%9A%E1%83%9D%E1%83%91%E1%83%94%E1%83%9C%20%E1%83%98%E1%83%9C%E1%83%92%E1%83%9A%E1%83%98%E1%83%A1%E1%83%A3%E1%83%A0%E1%83%A1.)
^ka-Q0336-answer

**ka-Q0337** — ქალმა 30 წიგნი დაწერა იმაზე, თუ როგორ გავხდეთ ბედნიერი, და შემდეგ თავი მოიკლა.

A woman wrote 30 books about how to become happy, and then committed suicide.

Expected form: **როგორ**

Why: Questions: place and manner. [[Georgian#^ka-Q0337|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A5%E1%83%90%E1%83%9A%E1%83%9B%E1%83%90%2030%20%E1%83%AC%E1%83%98%E1%83%92%E1%83%9C%E1%83%98%20%E1%83%93%E1%83%90%E1%83%AC%E1%83%94%E1%83%A0%E1%83%90%20%E1%83%98%E1%83%9B%E1%83%90%E1%83%96%E1%83%94%2C%20%E1%83%97%E1%83%A3%20%E1%83%A0%E1%83%9D%E1%83%92%E1%83%9D%E1%83%A0%20%E1%83%92%E1%83%90%E1%83%95%E1%83%AE%E1%83%93%E1%83%94%E1%83%97%20%E1%83%91%E1%83%94%E1%83%93%E1%83%9C%E1%83%98%E1%83%94%E1%83%A0%E1%83%98%2C%20%E1%83%93%E1%83%90%20%E1%83%A8%E1%83%94%E1%83%9B%E1%83%93%E1%83%94%E1%83%92%20%E1%83%97%E1%83%90%E1%83%95%E1%83%98%20%E1%83%9B%E1%83%9D%E1%83%98%E1%83%99%E1%83%9A%E1%83%90.)
^ka-Q0337-answer

**ka-Q0338** — ქალმა 30 წიგნი დაწერა იმაზე, თუ როგორ გავხდეთ ბედნიერი, და შემდეგ თავი მოიკლა.

A woman wrote 30 books about how to become happy, and then committed suicide.

Expected form: **როგორ**

Why: Questions: place and manner. [[Georgian#^ka-Q0338|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A5%E1%83%90%E1%83%9A%E1%83%9B%E1%83%90%2030%20%E1%83%AC%E1%83%98%E1%83%92%E1%83%9C%E1%83%98%20%E1%83%93%E1%83%90%E1%83%AC%E1%83%94%E1%83%A0%E1%83%90%20%E1%83%98%E1%83%9B%E1%83%90%E1%83%96%E1%83%94%2C%20%E1%83%97%E1%83%A3%20%E1%83%A0%E1%83%9D%E1%83%92%E1%83%9D%E1%83%A0%20%E1%83%92%E1%83%90%E1%83%95%E1%83%AE%E1%83%93%E1%83%94%E1%83%97%20%E1%83%91%E1%83%94%E1%83%93%E1%83%9C%E1%83%98%E1%83%94%E1%83%A0%E1%83%98%2C%20%E1%83%93%E1%83%90%20%E1%83%A8%E1%83%94%E1%83%9B%E1%83%93%E1%83%94%E1%83%92%20%E1%83%97%E1%83%90%E1%83%95%E1%83%98%20%E1%83%9B%E1%83%9D%E1%83%98%E1%83%99%E1%83%9A%E1%83%90.)
^ka-Q0338-answer

**ka-Q0339** — კვერცხები სად არიან, გეთაყვა?

Where are the eggs, please?

Expected form: **სად**

Why: Questions: place and manner. [[Georgian#^ka-Q0339|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%99%E1%83%95%E1%83%94%E1%83%A0%E1%83%AA%E1%83%AE%E1%83%94%E1%83%91%E1%83%98%20%E1%83%A1%E1%83%90%E1%83%93%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%90%E1%83%9C%2C%20%E1%83%92%E1%83%94%E1%83%97%E1%83%90%E1%83%A7%E1%83%95%E1%83%90%3F)
^ka-Q0339-answer

**ka-Q0340** — კვერცხები სად არიან, გეთაყვა?

Where are the eggs, please?

Why: Questions: place and manner. [[Georgian#^ka-Q0340|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%99%E1%83%95%E1%83%94%E1%83%A0%E1%83%AA%E1%83%AE%E1%83%94%E1%83%91%E1%83%98%20%E1%83%A1%E1%83%90%E1%83%93%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%90%E1%83%9C%2C%20%E1%83%92%E1%83%94%E1%83%97%E1%83%90%E1%83%A7%E1%83%95%E1%83%90%3F)
^ka-Q0340-answer

**ka-Q0341** — სად გინდათ წასვლა?

Where do you want to go?

Why: Questions: place and manner. [[Georgian#^ka-Q0341|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A1%E1%83%90%E1%83%93%20%E1%83%92%E1%83%98%E1%83%9C%E1%83%93%E1%83%90%E1%83%97%20%E1%83%AC%E1%83%90%E1%83%A1%E1%83%95%E1%83%9A%E1%83%90%3F)
^ka-Q0341-answer

**ka-Q0342** — სად გინდათ წასვლა?

Where do you want to go?

Different question forms request location, source, direction, manner, time or reason. The English word where can hide distinctions. Preserve the relation in your answer.

Why: Questions: place and manner. [[Georgian#^ka-Q0342|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A1%E1%83%90%E1%83%93%20%E1%83%92%E1%83%98%E1%83%9C%E1%83%93%E1%83%90%E1%83%97%20%E1%83%AC%E1%83%90%E1%83%A1%E1%83%95%E1%83%9A%E1%83%90%3F)
^ka-Q0342-answer

**ka-Q0343** — კარგი. სად ცხოვრობ შენ?

Ok. Where do you live?

Expected form: **სად**

Why: Questions: place and manner. [[Georgian#^ka-Q0343|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%99%E1%83%90%E1%83%A0%E1%83%92%E1%83%98.%20%E1%83%A1%E1%83%90%E1%83%93%20%E1%83%AA%E1%83%AE%E1%83%9D%E1%83%95%E1%83%A0%E1%83%9D%E1%83%91%20%E1%83%A8%E1%83%94%E1%83%9C%3F)
^ka-Q0343-answer

**ka-Q0344** — კარგი. სად ცხოვრობ შენ?

Ok. Where do you live?

Expected form: **სად**

Why: Questions: place and manner. [[Georgian#^ka-Q0344|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%99%E1%83%90%E1%83%A0%E1%83%92%E1%83%98.%20%E1%83%A1%E1%83%90%E1%83%93%20%E1%83%AA%E1%83%AE%E1%83%9D%E1%83%95%E1%83%A0%E1%83%9D%E1%83%91%20%E1%83%A8%E1%83%94%E1%83%9C%3F)
^ka-Q0344-answer

**ka-Q0345** — ტომი როგორ არის ავსტრალიაში?

How's Tom doing in Australia?

Expected form: **როგორ**

Why: Questions: place and manner. [[Georgian#^ka-Q0345|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%98%20%E1%83%A0%E1%83%9D%E1%83%92%E1%83%9D%E1%83%A0%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%90%E1%83%95%E1%83%A1%E1%83%A2%E1%83%A0%E1%83%90%E1%83%9A%E1%83%98%E1%83%90%E1%83%A8%E1%83%98%3F)
^ka-Q0345-answer

**ka-Q0346** — ტომი როგორ არის ავსტრალიაში?

How's Tom doing in Australia?

Why: Questions: place and manner. [[Georgian#^ka-Q0346|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%98%20%E1%83%A0%E1%83%9D%E1%83%92%E1%83%9D%E1%83%A0%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%90%E1%83%95%E1%83%A1%E1%83%A2%E1%83%A0%E1%83%90%E1%83%9A%E1%83%98%E1%83%90%E1%83%A8%E1%83%98%3F)
^ka-Q0346-answer

**ka-Q0347** — მარიამს ცხენები უყვარს.

Mary loves horses.

Why: Plural forms. [[Georgian#^ka-Q0347|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%90%E1%83%A0%E1%83%98%E1%83%90%E1%83%9B%E1%83%A1%20%E1%83%AA%E1%83%AE%E1%83%94%E1%83%9C%E1%83%94%E1%83%91%E1%83%98%20%E1%83%A3%E1%83%A7%E1%83%95%E1%83%90%E1%83%A0%E1%83%A1.)
^ka-Q0347-answer

**ka-Q0348** — მარიამს ცხენები უყვარს.

Mary loves horses.

Many nouns form a plural with -ები, sometimes with stem changes. Other number/case combinations need their own endings. Quantified phrases do not mechanically follow English plural usage.

Why: Plural forms. [[Georgian#^ka-Q0348|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%90%E1%83%A0%E1%83%98%E1%83%90%E1%83%9B%E1%83%A1%20%E1%83%AA%E1%83%AE%E1%83%94%E1%83%9C%E1%83%94%E1%83%91%E1%83%98%20%E1%83%A3%E1%83%A7%E1%83%95%E1%83%90%E1%83%A0%E1%83%A1.)
^ka-Q0348-answer

**ka-Q0349** — სახლში თუ დამაგვიანდება წასვლა, ნუ დამელოდები.

If I should be late getting home, please don't wait up for me.

Expected form: **დამელოდები**

Why: Plural forms. [[Georgian#^ka-Q0349|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A1%E1%83%90%E1%83%AE%E1%83%9A%E1%83%A8%E1%83%98%20%E1%83%97%E1%83%A3%20%E1%83%93%E1%83%90%E1%83%9B%E1%83%90%E1%83%92%E1%83%95%E1%83%98%E1%83%90%E1%83%9C%E1%83%93%E1%83%94%E1%83%91%E1%83%90%20%E1%83%AC%E1%83%90%E1%83%A1%E1%83%95%E1%83%9A%E1%83%90%2C%20%E1%83%9C%E1%83%A3%20%E1%83%93%E1%83%90%E1%83%9B%E1%83%94%E1%83%9A%E1%83%9D%E1%83%93%E1%83%94%E1%83%91%E1%83%98.)
^ka-Q0349-answer

**ka-Q0350** — სახლში თუ დამაგვიანდება წასვლა, ნუ დამელოდები.

If I should be late getting home, please don't wait up for me.

Expected form: **დამელოდები**

Why: Plural forms. [[Georgian#^ka-Q0350|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A1%E1%83%90%E1%83%AE%E1%83%9A%E1%83%A8%E1%83%98%20%E1%83%97%E1%83%A3%20%E1%83%93%E1%83%90%E1%83%9B%E1%83%90%E1%83%92%E1%83%95%E1%83%98%E1%83%90%E1%83%9C%E1%83%93%E1%83%94%E1%83%91%E1%83%90%20%E1%83%AC%E1%83%90%E1%83%A1%E1%83%95%E1%83%9A%E1%83%90%2C%20%E1%83%9C%E1%83%A3%20%E1%83%93%E1%83%90%E1%83%9B%E1%83%94%E1%83%9A%E1%83%9D%E1%83%93%E1%83%94%E1%83%91%E1%83%98.)
^ka-Q0350-answer


### Answers 351–400

**ka-Q0351** — თვალები დახუჭე და ათამდე დაითვალე.

Close your eyes, and count to ten.

Expected form: **თვალები**

Why: Plural forms. [[Georgian#^ka-Q0351|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%97%E1%83%95%E1%83%90%E1%83%9A%E1%83%94%E1%83%91%E1%83%98%20%E1%83%93%E1%83%90%E1%83%AE%E1%83%A3%E1%83%AD%E1%83%94%20%E1%83%93%E1%83%90%20%E1%83%90%E1%83%97%E1%83%90%E1%83%9B%E1%83%93%E1%83%94%20%E1%83%93%E1%83%90%E1%83%98%E1%83%97%E1%83%95%E1%83%90%E1%83%9A%E1%83%94.)
^ka-Q0351-answer

**ka-Q0352** — თვალები დახუჭე და ათამდე დაითვალე.

Close your eyes, and count to ten.

Why: Plural forms. [[Georgian#^ka-Q0352|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%97%E1%83%95%E1%83%90%E1%83%9A%E1%83%94%E1%83%91%E1%83%98%20%E1%83%93%E1%83%90%E1%83%AE%E1%83%A3%E1%83%AD%E1%83%94%20%E1%83%93%E1%83%90%20%E1%83%90%E1%83%97%E1%83%90%E1%83%9B%E1%83%93%E1%83%94%20%E1%83%93%E1%83%90%E1%83%98%E1%83%97%E1%83%95%E1%83%90%E1%83%9A%E1%83%94.)
^ka-Q0352-answer

**ka-Q0353** — მერი რომანტიული კომედიები მოსწონს.

Mary likes romantic comedies.

Why: Plural forms. [[Georgian#^ka-Q0353|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%E1%83%A0%E1%83%98%20%E1%83%A0%E1%83%9D%E1%83%9B%E1%83%90%E1%83%9C%E1%83%A2%E1%83%98%E1%83%A3%E1%83%9A%E1%83%98%20%E1%83%99%E1%83%9D%E1%83%9B%E1%83%94%E1%83%93%E1%83%98%E1%83%94%E1%83%91%E1%83%98%20%E1%83%9B%E1%83%9D%E1%83%A1%E1%83%AC%E1%83%9D%E1%83%9C%E1%83%A1.)
^ka-Q0353-answer

**ka-Q0354** — მერი რომანტიული კომედიები მოსწონს.

Mary likes romantic comedies.

Many nouns form a plural with -ები, sometimes with stem changes. Other number/case combinations need their own endings. Quantified phrases do not mechanically follow English plural usage.

Why: Plural forms. [[Georgian#^ka-Q0354|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%E1%83%A0%E1%83%98%20%E1%83%A0%E1%83%9D%E1%83%9B%E1%83%90%E1%83%9C%E1%83%A2%E1%83%98%E1%83%A3%E1%83%9A%E1%83%98%20%E1%83%99%E1%83%9D%E1%83%9B%E1%83%94%E1%83%93%E1%83%98%E1%83%94%E1%83%91%E1%83%98%20%E1%83%9B%E1%83%9D%E1%83%A1%E1%83%AC%E1%83%9D%E1%83%9C%E1%83%A1.)
^ka-Q0354-answer

**ka-Q0355** — ფუტკარები თაფლს აკეთებენ.

Bees make honey.

Expected form: **ფუტკარები**

Why: Plural forms. [[Georgian#^ka-Q0355|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A4%E1%83%A3%E1%83%A2%E1%83%99%E1%83%90%E1%83%A0%E1%83%94%E1%83%91%E1%83%98%20%E1%83%97%E1%83%90%E1%83%A4%E1%83%9A%E1%83%A1%20%E1%83%90%E1%83%99%E1%83%94%E1%83%97%E1%83%94%E1%83%91%E1%83%94%E1%83%9C.)
^ka-Q0355-answer

**ka-Q0356** — ფუტკარები თაფლს აკეთებენ.

Bees make honey.

Expected form: **ფუტკარები**

Why: Plural forms. [[Georgian#^ka-Q0356|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A4%E1%83%A3%E1%83%A2%E1%83%99%E1%83%90%E1%83%A0%E1%83%94%E1%83%91%E1%83%98%20%E1%83%97%E1%83%90%E1%83%A4%E1%83%9A%E1%83%A1%20%E1%83%90%E1%83%99%E1%83%94%E1%83%97%E1%83%94%E1%83%91%E1%83%94%E1%83%9C.)
^ka-Q0356-answer

**ka-Q0357** — თევზები ზღვაში ცხოვრობენ.

Fish live in the sea.

Expected form: **თევზები**

Why: Plural forms. [[Georgian#^ka-Q0357|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%97%E1%83%94%E1%83%95%E1%83%96%E1%83%94%E1%83%91%E1%83%98%20%E1%83%96%E1%83%A6%E1%83%95%E1%83%90%E1%83%A8%E1%83%98%20%E1%83%AA%E1%83%AE%E1%83%9D%E1%83%95%E1%83%A0%E1%83%9D%E1%83%91%E1%83%94%E1%83%9C.)
^ka-Q0357-answer

**ka-Q0358** — თევზები ზღვაში ცხოვრობენ.

Fish live in the sea.

Why: Plural forms. [[Georgian#^ka-Q0358|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%97%E1%83%94%E1%83%95%E1%83%96%E1%83%94%E1%83%91%E1%83%98%20%E1%83%96%E1%83%A6%E1%83%95%E1%83%90%E1%83%A8%E1%83%98%20%E1%83%AA%E1%83%AE%E1%83%9D%E1%83%95%E1%83%A0%E1%83%9D%E1%83%91%E1%83%94%E1%83%9C.)
^ka-Q0358-answer

**ka-Q0359** — გასაღებები გარდერობში არიან.

The keys are in the wardrobe.

Why: Plural forms. [[Georgian#^ka-Q0359|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%92%E1%83%90%E1%83%A1%E1%83%90%E1%83%A6%E1%83%94%E1%83%91%E1%83%94%E1%83%91%E1%83%98%20%E1%83%92%E1%83%90%E1%83%A0%E1%83%93%E1%83%94%E1%83%A0%E1%83%9D%E1%83%91%E1%83%A8%E1%83%98%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%90%E1%83%9C.)
^ka-Q0359-answer

**ka-Q0360** — გასაღებები გარდერობში არიან.

The keys are in the wardrobe.

Many nouns form a plural with -ები, sometimes with stem changes. Other number/case combinations need their own endings. Quantified phrases do not mechanically follow English plural usage.

Why: Plural forms. [[Georgian#^ka-Q0360|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%92%E1%83%90%E1%83%A1%E1%83%90%E1%83%A6%E1%83%94%E1%83%91%E1%83%94%E1%83%91%E1%83%98%20%E1%83%92%E1%83%90%E1%83%A0%E1%83%93%E1%83%94%E1%83%A0%E1%83%9D%E1%83%91%E1%83%A8%E1%83%98%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%90%E1%83%9C.)
^ka-Q0360-answer

**ka-Q0361** — ბედუინები ცხოვრობენ უდაბნოში.

Bedouins live in the desert.

Expected form: **ბედუინები**

Why: Plural forms. [[Georgian#^ka-Q0361|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%91%E1%83%94%E1%83%93%E1%83%A3%E1%83%98%E1%83%9C%E1%83%94%E1%83%91%E1%83%98%20%E1%83%AA%E1%83%AE%E1%83%9D%E1%83%95%E1%83%A0%E1%83%9D%E1%83%91%E1%83%94%E1%83%9C%20%E1%83%A3%E1%83%93%E1%83%90%E1%83%91%E1%83%9C%E1%83%9D%E1%83%A8%E1%83%98.)
^ka-Q0361-answer

**ka-Q0362** — ბედუინები ცხოვრობენ უდაბნოში.

Bedouins live in the desert.

Expected form: **ბედუინები**

Why: Plural forms. [[Georgian#^ka-Q0362|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%91%E1%83%94%E1%83%93%E1%83%A3%E1%83%98%E1%83%9C%E1%83%94%E1%83%91%E1%83%98%20%E1%83%AA%E1%83%AE%E1%83%9D%E1%83%95%E1%83%A0%E1%83%9D%E1%83%91%E1%83%94%E1%83%9C%20%E1%83%A3%E1%83%93%E1%83%90%E1%83%91%E1%83%9C%E1%83%9D%E1%83%A8%E1%83%98.)
^ka-Q0362-answer

**ka-Q0363** — ის პლაჟები აქედან შორსაა.

Those beaches are far from here.

Expected form: **პლაჟები**

Why: Plural forms. [[Georgian#^ka-Q0363|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%98%E1%83%A1%20%E1%83%9E%E1%83%9A%E1%83%90%E1%83%9F%E1%83%94%E1%83%91%E1%83%98%20%E1%83%90%E1%83%A5%E1%83%94%E1%83%93%E1%83%90%E1%83%9C%20%E1%83%A8%E1%83%9D%E1%83%A0%E1%83%A1%E1%83%90%E1%83%90.)
^ka-Q0363-answer

**ka-Q0364** — ის პლაჟები აქედან შორსაა.

Those beaches are far from here.

Why: Plural forms. [[Georgian#^ka-Q0364|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%98%E1%83%A1%20%E1%83%9E%E1%83%9A%E1%83%90%E1%83%9F%E1%83%94%E1%83%91%E1%83%98%20%E1%83%90%E1%83%A5%E1%83%94%E1%83%93%E1%83%90%E1%83%9C%20%E1%83%A8%E1%83%9D%E1%83%A0%E1%83%A1%E1%83%90%E1%83%90.)
^ka-Q0364-answer

**ka-Q0365** — თუ ჩუმად ვარ, ეს არ ნიშნავს რომ გეთანხმები.

If I stay silent, it doesn't mean that I agree with you.

Why: Plural forms. [[Georgian#^ka-Q0365|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%97%E1%83%A3%20%E1%83%A9%E1%83%A3%E1%83%9B%E1%83%90%E1%83%93%20%E1%83%95%E1%83%90%E1%83%A0%2C%20%E1%83%94%E1%83%A1%20%E1%83%90%E1%83%A0%20%E1%83%9C%E1%83%98%E1%83%A8%E1%83%9C%E1%83%90%E1%83%95%E1%83%A1%20%E1%83%A0%E1%83%9D%E1%83%9B%20%E1%83%92%E1%83%94%E1%83%97%E1%83%90%E1%83%9C%E1%83%AE%E1%83%9B%E1%83%94%E1%83%91%E1%83%98.)
^ka-Q0365-answer

**ka-Q0366** — თუ ჩუმად ვარ, ეს არ ნიშნავს რომ გეთანხმები.

If I stay silent, it doesn't mean that I agree with you.

Many nouns form a plural with -ები, sometimes with stem changes. Other number/case combinations need their own endings. Quantified phrases do not mechanically follow English plural usage.

Why: Plural forms. [[Georgian#^ka-Q0366|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%97%E1%83%A3%20%E1%83%A9%E1%83%A3%E1%83%9B%E1%83%90%E1%83%93%20%E1%83%95%E1%83%90%E1%83%A0%2C%20%E1%83%94%E1%83%A1%20%E1%83%90%E1%83%A0%20%E1%83%9C%E1%83%98%E1%83%A8%E1%83%9C%E1%83%90%E1%83%95%E1%83%A1%20%E1%83%A0%E1%83%9D%E1%83%9B%20%E1%83%92%E1%83%94%E1%83%97%E1%83%90%E1%83%9C%E1%83%AE%E1%83%9B%E1%83%94%E1%83%91%E1%83%98.)
^ka-Q0366-answer

**ka-Q0367** — მე მიყვარს დონატები

I like doughnuts.

Expected form: **დონატები**

Why: Plural forms. [[Georgian#^ka-Q0367|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%9B%E1%83%98%E1%83%A7%E1%83%95%E1%83%90%E1%83%A0%E1%83%A1%20%E1%83%93%E1%83%9D%E1%83%9C%E1%83%90%E1%83%A2%E1%83%94%E1%83%91%E1%83%98)
^ka-Q0367-answer

**ka-Q0368** — მე მიყვარს დონატები

I like doughnuts.

Expected form: **დონატები**

Why: Plural forms. [[Georgian#^ka-Q0368|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%9B%E1%83%98%E1%83%A7%E1%83%95%E1%83%90%E1%83%A0%E1%83%A1%20%E1%83%93%E1%83%9D%E1%83%9C%E1%83%90%E1%83%A2%E1%83%94%E1%83%91%E1%83%98)
^ka-Q0368-answer

**ka-Q0369** — ვერ ვრჩები ავსტრალიაში. უნდა დავბრუნდე ახალ ზელანდიაში.

I can't stay in Australia. I have to get back to New Zealand.

Expected form: **ვრჩები**

Why: Plural forms. [[Georgian#^ka-Q0369|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%95%E1%83%94%E1%83%A0%20%E1%83%95%E1%83%A0%E1%83%A9%E1%83%94%E1%83%91%E1%83%98%20%E1%83%90%E1%83%95%E1%83%A1%E1%83%A2%E1%83%A0%E1%83%90%E1%83%9A%E1%83%98%E1%83%90%E1%83%A8%E1%83%98.%20%E1%83%A3%E1%83%9C%E1%83%93%E1%83%90%20%E1%83%93%E1%83%90%E1%83%95%E1%83%91%E1%83%A0%E1%83%A3%E1%83%9C%E1%83%93%E1%83%94%20%E1%83%90%E1%83%AE%E1%83%90%E1%83%9A%20%E1%83%96%E1%83%94%E1%83%9A%E1%83%90%E1%83%9C%E1%83%93%E1%83%98%E1%83%90%E1%83%A8%E1%83%98.)
^ka-Q0369-answer

**ka-Q0370** — ვერ ვრჩები ავსტრალიაში. უნდა დავბრუნდე ახალ ზელანდიაში.

I can't stay in Australia. I have to get back to New Zealand.

Why: Plural forms. [[Georgian#^ka-Q0370|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%95%E1%83%94%E1%83%A0%20%E1%83%95%E1%83%A0%E1%83%A9%E1%83%94%E1%83%91%E1%83%98%20%E1%83%90%E1%83%95%E1%83%A1%E1%83%A2%E1%83%A0%E1%83%90%E1%83%9A%E1%83%98%E1%83%90%E1%83%A8%E1%83%98.%20%E1%83%A3%E1%83%9C%E1%83%93%E1%83%90%20%E1%83%93%E1%83%90%E1%83%95%E1%83%91%E1%83%A0%E1%83%A3%E1%83%9C%E1%83%93%E1%83%94%20%E1%83%90%E1%83%AE%E1%83%90%E1%83%9A%20%E1%83%96%E1%83%94%E1%83%9A%E1%83%90%E1%83%9C%E1%83%93%E1%83%98%E1%83%90%E1%83%A8%E1%83%98.)
^ka-Q0370-answer

**ka-Q0371** — თქვენ ექიმები ხართ.

You are doctors.

Why: Plural forms. [[Georgian#^ka-Q0371|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%97%E1%83%A5%E1%83%95%E1%83%94%E1%83%9C%20%E1%83%94%E1%83%A5%E1%83%98%E1%83%9B%E1%83%94%E1%83%91%E1%83%98%20%E1%83%AE%E1%83%90%E1%83%A0%E1%83%97.)
^ka-Q0371-answer

**ka-Q0372** — თქვენ ექიმები ხართ.

You are doctors.

Many nouns form a plural with -ები, sometimes with stem changes. Other number/case combinations need their own endings. Quantified phrases do not mechanically follow English plural usage.

Why: Plural forms. [[Georgian#^ka-Q0372|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%97%E1%83%A5%E1%83%95%E1%83%94%E1%83%9C%20%E1%83%94%E1%83%A5%E1%83%98%E1%83%9B%E1%83%94%E1%83%91%E1%83%98%20%E1%83%AE%E1%83%90%E1%83%A0%E1%83%97.)
^ka-Q0372-answer

**ka-Q0373** — ძაღლები და კატები არ არიან მეგობრები.

Dogs and cats aren't friends.

Expected form: **ძაღლები**

Why: Plural forms. [[Georgian#^ka-Q0373|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%AB%E1%83%90%E1%83%A6%E1%83%9A%E1%83%94%E1%83%91%E1%83%98%20%E1%83%93%E1%83%90%20%E1%83%99%E1%83%90%E1%83%A2%E1%83%94%E1%83%91%E1%83%98%20%E1%83%90%E1%83%A0%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%90%E1%83%9C%20%E1%83%9B%E1%83%94%E1%83%92%E1%83%9D%E1%83%91%E1%83%A0%E1%83%94%E1%83%91%E1%83%98.)
^ka-Q0373-answer

**ka-Q0374** — ძაღლები და კატები არ არიან მეგობრები.

Dogs and cats aren't friends.

Expected form: **ძაღლები**

Why: Plural forms. [[Georgian#^ka-Q0374|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%AB%E1%83%90%E1%83%A6%E1%83%9A%E1%83%94%E1%83%91%E1%83%98%20%E1%83%93%E1%83%90%20%E1%83%99%E1%83%90%E1%83%A2%E1%83%94%E1%83%91%E1%83%98%20%E1%83%90%E1%83%A0%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%90%E1%83%9C%20%E1%83%9B%E1%83%94%E1%83%92%E1%83%9D%E1%83%91%E1%83%A0%E1%83%94%E1%83%91%E1%83%98.)
^ka-Q0374-answer

**ka-Q0375** — ტომი და მერი ანტიფაშისტები არიან.

Tom and Mary are anti-fascists.

Expected form: **ანტიფაშისტები**

Why: Plural forms. [[Georgian#^ka-Q0375|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%98%20%E1%83%93%E1%83%90%20%E1%83%9B%E1%83%94%E1%83%A0%E1%83%98%20%E1%83%90%E1%83%9C%E1%83%A2%E1%83%98%E1%83%A4%E1%83%90%E1%83%A8%E1%83%98%E1%83%A1%E1%83%A2%E1%83%94%E1%83%91%E1%83%98%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%90%E1%83%9C.)
^ka-Q0375-answer

**ka-Q0376** — ტომი და მერი ანტიფაშისტები არიან.

Tom and Mary are anti-fascists.

Why: Plural forms. [[Georgian#^ka-Q0376|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%98%20%E1%83%93%E1%83%90%20%E1%83%9B%E1%83%94%E1%83%A0%E1%83%98%20%E1%83%90%E1%83%9C%E1%83%A2%E1%83%98%E1%83%A4%E1%83%90%E1%83%A8%E1%83%98%E1%83%A1%E1%83%A2%E1%83%94%E1%83%91%E1%83%98%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%90%E1%83%9C.)
^ka-Q0376-answer

**ka-Q0377** — მე არ მიყვარს ექიმები.

I don't like doctors.

Why: Plural forms. [[Georgian#^ka-Q0377|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%90%E1%83%A0%20%E1%83%9B%E1%83%98%E1%83%A7%E1%83%95%E1%83%90%E1%83%A0%E1%83%A1%20%E1%83%94%E1%83%A5%E1%83%98%E1%83%9B%E1%83%94%E1%83%91%E1%83%98.)
^ka-Q0377-answer

**ka-Q0378** — მე არ მიყვარს ექიმები.

I don't like doctors.

Many nouns form a plural with -ები, sometimes with stem changes. Other number/case combinations need their own endings. Quantified phrases do not mechanically follow English plural usage.

Why: Plural forms. [[Georgian#^ka-Q0378|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%90%E1%83%A0%20%E1%83%9B%E1%83%98%E1%83%A7%E1%83%95%E1%83%90%E1%83%A0%E1%83%A1%20%E1%83%94%E1%83%A5%E1%83%98%E1%83%9B%E1%83%94%E1%83%91%E1%83%98.)
^ka-Q0378-answer

**ka-Q0379** — მე ძალიან მომწონს ძაღლები.

I like dogs very much.

Expected form: **ძაღლები**

Why: Plural forms. [[Georgian#^ka-Q0379|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%AB%E1%83%90%E1%83%9A%E1%83%98%E1%83%90%E1%83%9C%20%E1%83%9B%E1%83%9D%E1%83%9B%E1%83%AC%E1%83%9D%E1%83%9C%E1%83%A1%20%E1%83%AB%E1%83%90%E1%83%A6%E1%83%9A%E1%83%94%E1%83%91%E1%83%98.)
^ka-Q0379-answer

**ka-Q0380** — მე ძალიან მომწონს ძაღლები.

I like dogs very much.

Expected form: **ძაღლები**

Why: Plural forms. [[Georgian#^ka-Q0380|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%AB%E1%83%90%E1%83%9A%E1%83%98%E1%83%90%E1%83%9C%20%E1%83%9B%E1%83%9D%E1%83%9B%E1%83%AC%E1%83%9D%E1%83%9C%E1%83%A1%20%E1%83%AB%E1%83%90%E1%83%A6%E1%83%9A%E1%83%94%E1%83%91%E1%83%98.)
^ka-Q0380-answer

**ka-Q0381** — კუებს კბილები არ აქვთ.

Turtles don't have teeth.

Expected form: **კბილები**

Why: Plural forms. [[Georgian#^ka-Q0381|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%99%E1%83%A3%E1%83%94%E1%83%91%E1%83%A1%20%E1%83%99%E1%83%91%E1%83%98%E1%83%9A%E1%83%94%E1%83%91%E1%83%98%20%E1%83%90%E1%83%A0%20%E1%83%90%E1%83%A5%E1%83%95%E1%83%97.)
^ka-Q0381-answer

**ka-Q0382** — კუებს კბილები არ აქვთ.

Turtles don't have teeth.

Why: Plural forms. [[Georgian#^ka-Q0382|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%99%E1%83%A3%E1%83%94%E1%83%91%E1%83%A1%20%E1%83%99%E1%83%91%E1%83%98%E1%83%9A%E1%83%94%E1%83%91%E1%83%98%20%E1%83%90%E1%83%A0%20%E1%83%90%E1%83%A5%E1%83%95%E1%83%97.)
^ka-Q0382-answer

**ka-Q0383** — ფანტაზია უფრო მნიშვნელოვანია ვიდრე ცოდნა. ცოდნას საზღვრები აქვს.

Imagination is more important than knowledge. Knowledge is limited.

Why: Plural forms. [[Georgian#^ka-Q0383|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A4%E1%83%90%E1%83%9C%E1%83%A2%E1%83%90%E1%83%96%E1%83%98%E1%83%90%20%E1%83%A3%E1%83%A4%E1%83%A0%E1%83%9D%20%E1%83%9B%E1%83%9C%E1%83%98%E1%83%A8%E1%83%95%E1%83%9C%E1%83%94%E1%83%9A%E1%83%9D%E1%83%95%E1%83%90%E1%83%9C%E1%83%98%E1%83%90%20%E1%83%95%E1%83%98%E1%83%93%E1%83%A0%E1%83%94%20%E1%83%AA%E1%83%9D%E1%83%93%E1%83%9C%E1%83%90.%20%E1%83%AA%E1%83%9D%E1%83%93%E1%83%9C%E1%83%90%E1%83%A1%20%E1%83%A1%E1%83%90%E1%83%96%E1%83%A6%E1%83%95%E1%83%A0%E1%83%94%E1%83%91%E1%83%98%20%E1%83%90%E1%83%A5%E1%83%95%E1%83%A1.)
^ka-Q0383-answer

**ka-Q0384** — ფანტაზია უფრო მნიშვნელოვანია ვიდრე ცოდნა. ცოდნას საზღვრები აქვს.

Imagination is more important than knowledge. Knowledge is limited.

Many nouns form a plural with -ები, sometimes with stem changes. Other number/case combinations need their own endings. Quantified phrases do not mechanically follow English plural usage.

Why: Plural forms. [[Georgian#^ka-Q0384|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A4%E1%83%90%E1%83%9C%E1%83%A2%E1%83%90%E1%83%96%E1%83%98%E1%83%90%20%E1%83%A3%E1%83%A4%E1%83%A0%E1%83%9D%20%E1%83%9B%E1%83%9C%E1%83%98%E1%83%A8%E1%83%95%E1%83%9C%E1%83%94%E1%83%9A%E1%83%9D%E1%83%95%E1%83%90%E1%83%9C%E1%83%98%E1%83%90%20%E1%83%95%E1%83%98%E1%83%93%E1%83%A0%E1%83%94%20%E1%83%AA%E1%83%9D%E1%83%93%E1%83%9C%E1%83%90.%20%E1%83%AA%E1%83%9D%E1%83%93%E1%83%9C%E1%83%90%E1%83%A1%20%E1%83%A1%E1%83%90%E1%83%96%E1%83%A6%E1%83%95%E1%83%A0%E1%83%94%E1%83%91%E1%83%98%20%E1%83%90%E1%83%A5%E1%83%95%E1%83%A1.)
^ka-Q0384-answer

**ka-Q0385** — ჩემი ძმები ხის ქვეშ არიან.

My brothers are under the tree.

Expected form: **ძმები**

Why: Plural forms. [[Georgian#^ka-Q0385|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%AB%E1%83%9B%E1%83%94%E1%83%91%E1%83%98%20%E1%83%AE%E1%83%98%E1%83%A1%20%E1%83%A5%E1%83%95%E1%83%94%E1%83%A8%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%90%E1%83%9C.)
^ka-Q0385-answer

**ka-Q0386** — ჩემი ძმები ხის ქვეშ არიან.

My brothers are under the tree.

Expected form: **ძმები**

Why: Plural forms. [[Georgian#^ka-Q0386|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%AB%E1%83%9B%E1%83%94%E1%83%91%E1%83%98%20%E1%83%AE%E1%83%98%E1%83%A1%20%E1%83%A5%E1%83%95%E1%83%94%E1%83%A8%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%90%E1%83%9C.)
^ka-Q0386-answer

**ka-Q0387** — პომიდორები კარგად გაიზარდნენ.

The tomatoes have grown well.

Expected form: **პომიდორები**

Why: Plural forms. [[Georgian#^ka-Q0387|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9E%E1%83%9D%E1%83%9B%E1%83%98%E1%83%93%E1%83%9D%E1%83%A0%E1%83%94%E1%83%91%E1%83%98%20%E1%83%99%E1%83%90%E1%83%A0%E1%83%92%E1%83%90%E1%83%93%20%E1%83%92%E1%83%90%E1%83%98%E1%83%96%E1%83%90%E1%83%A0%E1%83%93%E1%83%9C%E1%83%94%E1%83%9C.)
^ka-Q0387-answer

**ka-Q0388** — პომიდორები კარგად გაიზარდნენ.

The tomatoes have grown well.

Why: Plural forms. [[Georgian#^ka-Q0388|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9E%E1%83%9D%E1%83%9B%E1%83%98%E1%83%93%E1%83%9D%E1%83%A0%E1%83%94%E1%83%91%E1%83%98%20%E1%83%99%E1%83%90%E1%83%A0%E1%83%92%E1%83%90%E1%83%93%20%E1%83%92%E1%83%90%E1%83%98%E1%83%96%E1%83%90%E1%83%A0%E1%83%93%E1%83%9C%E1%83%94%E1%83%9C.)
^ka-Q0388-answer

**ka-Q0389** — არასოდეს დაწეროთ სიტყვები ''ბორშჩი'' და ''შჩი'' გერმანულად!

Never write the words "bortsch" and "shchi" in German!

Why: Plural forms. [[Georgian#^ka-Q0389|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%A0%E1%83%90%E1%83%A1%E1%83%9D%E1%83%93%E1%83%94%E1%83%A1%20%E1%83%93%E1%83%90%E1%83%AC%E1%83%94%E1%83%A0%E1%83%9D%E1%83%97%20%E1%83%A1%E1%83%98%E1%83%A2%E1%83%A7%E1%83%95%E1%83%94%E1%83%91%E1%83%98%20%27%27%E1%83%91%E1%83%9D%E1%83%A0%E1%83%A8%E1%83%A9%E1%83%98%27%27%20%E1%83%93%E1%83%90%20%27%27%E1%83%A8%E1%83%A9%E1%83%98%27%27%20%E1%83%92%E1%83%94%E1%83%A0%E1%83%9B%E1%83%90%E1%83%9C%E1%83%A3%E1%83%9A%E1%83%90%E1%83%93%21)
^ka-Q0389-answer

**ka-Q0390** — არასოდეს დაწეროთ სიტყვები ''ბორშჩი'' და ''შჩი'' გერმანულად!

Never write the words "bortsch" and "shchi" in German!

Many nouns form a plural with -ები, sometimes with stem changes. Other number/case combinations need their own endings. Quantified phrases do not mechanically follow English plural usage.

Why: Plural forms. [[Georgian#^ka-Q0390|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%A0%E1%83%90%E1%83%A1%E1%83%9D%E1%83%93%E1%83%94%E1%83%A1%20%E1%83%93%E1%83%90%E1%83%AC%E1%83%94%E1%83%A0%E1%83%9D%E1%83%97%20%E1%83%A1%E1%83%98%E1%83%A2%E1%83%A7%E1%83%95%E1%83%94%E1%83%91%E1%83%98%20%27%27%E1%83%91%E1%83%9D%E1%83%A0%E1%83%A8%E1%83%A9%E1%83%98%27%27%20%E1%83%93%E1%83%90%20%27%27%E1%83%A8%E1%83%A9%E1%83%98%27%27%20%E1%83%92%E1%83%94%E1%83%A0%E1%83%9B%E1%83%90%E1%83%9C%E1%83%A3%E1%83%9A%E1%83%90%E1%83%93%21)
^ka-Q0390-answer

**ka-Q0391** — ზოგადად რვა საათზე ვდგები.

I usually get up at eight o'clock.

Expected form: **ვდგები**

Why: Plural forms. [[Georgian#^ka-Q0391|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%96%E1%83%9D%E1%83%92%E1%83%90%E1%83%93%E1%83%90%E1%83%93%20%E1%83%A0%E1%83%95%E1%83%90%20%E1%83%A1%E1%83%90%E1%83%90%E1%83%97%E1%83%96%E1%83%94%20%E1%83%95%E1%83%93%E1%83%92%E1%83%94%E1%83%91%E1%83%98.)
^ka-Q0391-answer

**ka-Q0392** — ზოგადად რვა საათზე ვდგები.

I usually get up at eight o'clock.

Expected form: **ვდგები**

Why: Plural forms. [[Georgian#^ka-Q0392|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%96%E1%83%9D%E1%83%92%E1%83%90%E1%83%93%E1%83%90%E1%83%93%20%E1%83%A0%E1%83%95%E1%83%90%20%E1%83%A1%E1%83%90%E1%83%90%E1%83%97%E1%83%96%E1%83%94%20%E1%83%95%E1%83%93%E1%83%92%E1%83%94%E1%83%91%E1%83%98.)
^ka-Q0392-answer

**ka-Q0393** — მოსწავლები საკლასო ოთახში არიან.

The students are in the classroom.

Expected form: **მოსწავლები**

Why: Plural forms. [[Georgian#^ka-Q0393|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%9D%E1%83%A1%E1%83%AC%E1%83%90%E1%83%95%E1%83%9A%E1%83%94%E1%83%91%E1%83%98%20%E1%83%A1%E1%83%90%E1%83%99%E1%83%9A%E1%83%90%E1%83%A1%E1%83%9D%20%E1%83%9D%E1%83%97%E1%83%90%E1%83%AE%E1%83%A8%E1%83%98%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%90%E1%83%9C.)
^ka-Q0393-answer

**ka-Q0394** — მოსწავლები საკლასო ოთახში არიან.

The students are in the classroom.

Why: Plural forms. [[Georgian#^ka-Q0394|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%9D%E1%83%A1%E1%83%AC%E1%83%90%E1%83%95%E1%83%9A%E1%83%94%E1%83%91%E1%83%98%20%E1%83%A1%E1%83%90%E1%83%99%E1%83%9A%E1%83%90%E1%83%A1%E1%83%9D%20%E1%83%9D%E1%83%97%E1%83%90%E1%83%AE%E1%83%A8%E1%83%98%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%90%E1%83%9C.)
^ka-Q0394-answer

**ka-Q0395** — მარიამს ცხოველები უყვარს.

Mary loves animals.

Why: Plural forms. [[Georgian#^ka-Q0395|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%90%E1%83%A0%E1%83%98%E1%83%90%E1%83%9B%E1%83%A1%20%E1%83%AA%E1%83%AE%E1%83%9D%E1%83%95%E1%83%94%E1%83%9A%E1%83%94%E1%83%91%E1%83%98%20%E1%83%A3%E1%83%A7%E1%83%95%E1%83%90%E1%83%A0%E1%83%A1.)
^ka-Q0395-answer

**ka-Q0396** — მარიამს ცხოველები უყვარს.

Mary loves animals.

Many nouns form a plural with -ები, sometimes with stem changes. Other number/case combinations need their own endings. Quantified phrases do not mechanically follow English plural usage.

Why: Plural forms. [[Georgian#^ka-Q0396|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%90%E1%83%A0%E1%83%98%E1%83%90%E1%83%9B%E1%83%A1%20%E1%83%AA%E1%83%AE%E1%83%9D%E1%83%95%E1%83%94%E1%83%9A%E1%83%94%E1%83%91%E1%83%98%20%E1%83%A3%E1%83%A7%E1%83%95%E1%83%90%E1%83%A0%E1%83%A1.)
^ka-Q0396-answer

**ka-Q0397** — შემიძლია წავიდე ავსტრალიაში ტომთან ერთად?

Can I visit Australia with Tom?

Expected form: **ავსტრალიაში**

Why: Inside/location -ში. [[Georgian#^ka-Q0397|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A8%E1%83%94%E1%83%9B%E1%83%98%E1%83%AB%E1%83%9A%E1%83%98%E1%83%90%20%E1%83%AC%E1%83%90%E1%83%95%E1%83%98%E1%83%93%E1%83%94%20%E1%83%90%E1%83%95%E1%83%A1%E1%83%A2%E1%83%A0%E1%83%90%E1%83%9A%E1%83%98%E1%83%90%E1%83%A8%E1%83%98%20%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%97%E1%83%90%E1%83%9C%20%E1%83%94%E1%83%A0%E1%83%97%E1%83%90%E1%83%93%3F)
^ka-Q0397-answer

**ka-Q0398** — შემიძლია წავიდე ავსტრალიაში ტომთან ერთად?

Can I visit Australia with Tom?

Expected form: **ავსტრალიაში**

Why: Inside/location -ში. [[Georgian#^ka-Q0398|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A8%E1%83%94%E1%83%9B%E1%83%98%E1%83%AB%E1%83%9A%E1%83%98%E1%83%90%20%E1%83%AC%E1%83%90%E1%83%95%E1%83%98%E1%83%93%E1%83%94%20%E1%83%90%E1%83%95%E1%83%A1%E1%83%A2%E1%83%A0%E1%83%90%E1%83%9A%E1%83%98%E1%83%90%E1%83%A8%E1%83%98%20%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%97%E1%83%90%E1%83%9C%20%E1%83%94%E1%83%A0%E1%83%97%E1%83%90%E1%83%93%3F)
^ka-Q0398-answer

**ka-Q0399** — საშას ქონდა ძლიერი ტკივილი მარჯვენა ხელში.

Sasha had a sharp pain in her right hand.

Expected form: **ხელში**

Why: Inside/location -ში. [[Georgian#^ka-Q0399|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A1%E1%83%90%E1%83%A8%E1%83%90%E1%83%A1%20%E1%83%A5%E1%83%9D%E1%83%9C%E1%83%93%E1%83%90%20%E1%83%AB%E1%83%9A%E1%83%98%E1%83%94%E1%83%A0%E1%83%98%20%E1%83%A2%E1%83%99%E1%83%98%E1%83%95%E1%83%98%E1%83%9A%E1%83%98%20%E1%83%9B%E1%83%90%E1%83%A0%E1%83%AF%E1%83%95%E1%83%94%E1%83%9C%E1%83%90%20%E1%83%AE%E1%83%94%E1%83%9A%E1%83%A8%E1%83%98.)
^ka-Q0399-answer

**ka-Q0400** — საშას ქონდა ძლიერი ტკივილი მარჯვენა ხელში.

Sasha had a sharp pain in her right hand.

Why: Inside/location -ში. [[Georgian#^ka-Q0400|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A1%E1%83%90%E1%83%A8%E1%83%90%E1%83%A1%20%E1%83%A5%E1%83%9D%E1%83%9C%E1%83%93%E1%83%90%20%E1%83%AB%E1%83%9A%E1%83%98%E1%83%94%E1%83%A0%E1%83%98%20%E1%83%A2%E1%83%99%E1%83%98%E1%83%95%E1%83%98%E1%83%9A%E1%83%98%20%E1%83%9B%E1%83%90%E1%83%A0%E1%83%AF%E1%83%95%E1%83%94%E1%83%9C%E1%83%90%20%E1%83%AE%E1%83%94%E1%83%9A%E1%83%A8%E1%83%98.)
^ka-Q0400-answer


### Answers 401–450

**ka-Q0401** — ტოკიოში წასვლა მინდა.

I want to go to Tokyo.

Why: Inside/location -ში. [[Georgian#^ka-Q0401|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A2%E1%83%9D%E1%83%99%E1%83%98%E1%83%9D%E1%83%A8%E1%83%98%20%E1%83%AC%E1%83%90%E1%83%A1%E1%83%95%E1%83%9A%E1%83%90%20%E1%83%9B%E1%83%98%E1%83%9C%E1%83%93%E1%83%90.)
^ka-Q0401-answer

**ka-Q0402** — ტოკიოში წასვლა მინდა.

I want to go to Tokyo.

Attached -ში expresses many in/into relations. The verb and context distinguish position from movement; the suffix does not encode the full English prepositional phrase by itself.

Why: Inside/location -ში. [[Georgian#^ka-Q0402|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A2%E1%83%9D%E1%83%99%E1%83%98%E1%83%9D%E1%83%A8%E1%83%98%20%E1%83%AC%E1%83%90%E1%83%A1%E1%83%95%E1%83%9A%E1%83%90%20%E1%83%9B%E1%83%98%E1%83%9C%E1%83%93%E1%83%90.)
^ka-Q0402-answer

**ka-Q0403** — ტომიც მუშაობს ავსტრალიაში?

Does Tom work in Australia, too?

Expected form: **ავსტრალიაში**

Why: Inside/location -ში. [[Georgian#^ka-Q0403|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%98%E1%83%AA%20%E1%83%9B%E1%83%A3%E1%83%A8%E1%83%90%E1%83%9D%E1%83%91%E1%83%A1%20%E1%83%90%E1%83%95%E1%83%A1%E1%83%A2%E1%83%A0%E1%83%90%E1%83%9A%E1%83%98%E1%83%90%E1%83%A8%E1%83%98%3F)
^ka-Q0403-answer

**ka-Q0404** — ტომიც მუშაობს ავსტრალიაში?

Does Tom work in Australia, too?

Expected form: **ავსტრალიაში**

Why: Inside/location -ში. [[Georgian#^ka-Q0404|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%98%E1%83%AA%20%E1%83%9B%E1%83%A3%E1%83%A8%E1%83%90%E1%83%9D%E1%83%91%E1%83%A1%20%E1%83%90%E1%83%95%E1%83%A1%E1%83%A2%E1%83%A0%E1%83%90%E1%83%9A%E1%83%98%E1%83%90%E1%83%A8%E1%83%98%3F)
^ka-Q0404-answer

**ka-Q0405** — წერილი ბარდება დღეში ერთხელ.

The mail is delivered once a day.

Expected form: **დღეში**

Why: Inside/location -ში. [[Georgian#^ka-Q0405|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%AC%E1%83%94%E1%83%A0%E1%83%98%E1%83%9A%E1%83%98%20%E1%83%91%E1%83%90%E1%83%A0%E1%83%93%E1%83%94%E1%83%91%E1%83%90%20%E1%83%93%E1%83%A6%E1%83%94%E1%83%A8%E1%83%98%20%E1%83%94%E1%83%A0%E1%83%97%E1%83%AE%E1%83%94%E1%83%9A.)
^ka-Q0405-answer

**ka-Q0406** — წერილი ბარდება დღეში ერთხელ.

The mail is delivered once a day.

Why: Inside/location -ში. [[Georgian#^ka-Q0406|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%AC%E1%83%94%E1%83%A0%E1%83%98%E1%83%9A%E1%83%98%20%E1%83%91%E1%83%90%E1%83%A0%E1%83%93%E1%83%94%E1%83%91%E1%83%90%20%E1%83%93%E1%83%A6%E1%83%94%E1%83%A8%E1%83%98%20%E1%83%94%E1%83%A0%E1%83%97%E1%83%AE%E1%83%94%E1%83%9A.)
^ka-Q0406-answer

**ka-Q0407** — ქოლგა მატარებელში დავტოვე.

I left my umbrella on the train.

Why: Inside/location -ში. [[Georgian#^ka-Q0407|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A5%E1%83%9D%E1%83%9A%E1%83%92%E1%83%90%20%E1%83%9B%E1%83%90%E1%83%A2%E1%83%90%E1%83%A0%E1%83%94%E1%83%91%E1%83%94%E1%83%9A%E1%83%A8%E1%83%98%20%E1%83%93%E1%83%90%E1%83%95%E1%83%A2%E1%83%9D%E1%83%95%E1%83%94.)
^ka-Q0407-answer

**ka-Q0408** — ქოლგა მატარებელში დავტოვე.

I left my umbrella on the train.

Attached -ში expresses many in/into relations. The verb and context distinguish position from movement; the suffix does not encode the full English prepositional phrase by itself.

Why: Inside/location -ში. [[Georgian#^ka-Q0408|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A5%E1%83%9D%E1%83%9A%E1%83%92%E1%83%90%20%E1%83%9B%E1%83%90%E1%83%A2%E1%83%90%E1%83%A0%E1%83%94%E1%83%91%E1%83%94%E1%83%9A%E1%83%A8%E1%83%98%20%E1%83%93%E1%83%90%E1%83%95%E1%83%A2%E1%83%9D%E1%83%95%E1%83%94.)
^ka-Q0408-answer

**ka-Q0409** — საღამოს ჰავაიში მივდივართ.

We are leaving for Hawaii tonight.

Expected form: **ჰავაიში**

Why: Inside/location -ში. [[Georgian#^ka-Q0409|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A1%E1%83%90%E1%83%A6%E1%83%90%E1%83%9B%E1%83%9D%E1%83%A1%20%E1%83%B0%E1%83%90%E1%83%95%E1%83%90%E1%83%98%E1%83%A8%E1%83%98%20%E1%83%9B%E1%83%98%E1%83%95%E1%83%93%E1%83%98%E1%83%95%E1%83%90%E1%83%A0%E1%83%97.)
^ka-Q0409-answer

**ka-Q0410** — საღამოს ჰავაიში მივდივართ.

We are leaving for Hawaii tonight.

Expected form: **ჰავაიში**

Why: Inside/location -ში. [[Georgian#^ka-Q0410|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A1%E1%83%90%E1%83%A6%E1%83%90%E1%83%9B%E1%83%9D%E1%83%A1%20%E1%83%B0%E1%83%90%E1%83%95%E1%83%90%E1%83%98%E1%83%A8%E1%83%98%20%E1%83%9B%E1%83%98%E1%83%95%E1%83%93%E1%83%98%E1%83%95%E1%83%90%E1%83%A0%E1%83%97.)
^ka-Q0410-answer

**ka-Q0411** — იაპონიაში წასვლა მინდა.

I want to go to Japan.

Expected form: **იაპონიაში**

Why: Inside/location -ში. [[Georgian#^ka-Q0411|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%98%E1%83%90%E1%83%9E%E1%83%9D%E1%83%9C%E1%83%98%E1%83%90%E1%83%A8%E1%83%98%20%E1%83%AC%E1%83%90%E1%83%A1%E1%83%95%E1%83%9A%E1%83%90%20%E1%83%9B%E1%83%98%E1%83%9C%E1%83%93%E1%83%90.)
^ka-Q0411-answer

**ka-Q0412** — იაპონიაში წასვლა მინდა.

I want to go to Japan.

Why: Inside/location -ში. [[Georgian#^ka-Q0412|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%98%E1%83%90%E1%83%9E%E1%83%9D%E1%83%9C%E1%83%98%E1%83%90%E1%83%A8%E1%83%98%20%E1%83%AC%E1%83%90%E1%83%A1%E1%83%95%E1%83%9A%E1%83%90%20%E1%83%9B%E1%83%98%E1%83%9C%E1%83%93%E1%83%90.)
^ka-Q0412-answer

**ka-Q0413** — სკოლაში წასვლის დროა.

It's time to go to school.

Why: Inside/location -ში. [[Georgian#^ka-Q0413|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A1%E1%83%99%E1%83%9D%E1%83%9A%E1%83%90%E1%83%A8%E1%83%98%20%E1%83%AC%E1%83%90%E1%83%A1%E1%83%95%E1%83%9A%E1%83%98%E1%83%A1%20%E1%83%93%E1%83%A0%E1%83%9D%E1%83%90.)
^ka-Q0413-answer

**ka-Q0414** — სკოლაში წასვლის დროა.

It's time to go to school.

Attached -ში expresses many in/into relations. The verb and context distinguish position from movement; the suffix does not encode the full English prepositional phrase by itself.

Why: Inside/location -ში. [[Georgian#^ka-Q0414|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A1%E1%83%99%E1%83%9D%E1%83%9A%E1%83%90%E1%83%A8%E1%83%98%20%E1%83%AC%E1%83%90%E1%83%A1%E1%83%95%E1%83%9A%E1%83%98%E1%83%A1%20%E1%83%93%E1%83%A0%E1%83%9D%E1%83%90.)
^ka-Q0414-answer

**ka-Q0415** — ტომი წასვლას აპირებს ავსტრალიაში.

Tom is going to go to Australia.

Expected form: **ავსტრალიაში**

Why: Inside/location -ში. [[Georgian#^ka-Q0415|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%98%20%E1%83%AC%E1%83%90%E1%83%A1%E1%83%95%E1%83%9A%E1%83%90%E1%83%A1%20%E1%83%90%E1%83%9E%E1%83%98%E1%83%A0%E1%83%94%E1%83%91%E1%83%A1%20%E1%83%90%E1%83%95%E1%83%A1%E1%83%A2%E1%83%A0%E1%83%90%E1%83%9A%E1%83%98%E1%83%90%E1%83%A8%E1%83%98.)
^ka-Q0415-answer

**ka-Q0416** — ტომი წასვლას აპირებს ავსტრალიაში.

Tom is going to go to Australia.

Expected form: **ავსტრალიაში**

Why: Inside/location -ში. [[Georgian#^ka-Q0416|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%98%20%E1%83%AC%E1%83%90%E1%83%A1%E1%83%95%E1%83%9A%E1%83%90%E1%83%A1%20%E1%83%90%E1%83%9E%E1%83%98%E1%83%A0%E1%83%94%E1%83%91%E1%83%A1%20%E1%83%90%E1%83%95%E1%83%A1%E1%83%A2%E1%83%A0%E1%83%90%E1%83%9A%E1%83%98%E1%83%90%E1%83%A8%E1%83%98.)
^ka-Q0416-answer

**ka-Q0417** — მომეცი ნება გადავიხადო ანგარიში.

Let me pay the bill.

Expected form: **ანგარიში**

Why: Inside/location -ში. [[Georgian#^ka-Q0417|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%9D%E1%83%9B%E1%83%94%E1%83%AA%E1%83%98%20%E1%83%9C%E1%83%94%E1%83%91%E1%83%90%20%E1%83%92%E1%83%90%E1%83%93%E1%83%90%E1%83%95%E1%83%98%E1%83%AE%E1%83%90%E1%83%93%E1%83%9D%20%E1%83%90%E1%83%9C%E1%83%92%E1%83%90%E1%83%A0%E1%83%98%E1%83%A8%E1%83%98.)
^ka-Q0417-answer

**ka-Q0418** — მომეცი ნება გადავიხადო ანგარიში.

Let me pay the bill.

Why: Inside/location -ში. [[Georgian#^ka-Q0418|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%9D%E1%83%9B%E1%83%94%E1%83%AA%E1%83%98%20%E1%83%9C%E1%83%94%E1%83%91%E1%83%90%20%E1%83%92%E1%83%90%E1%83%93%E1%83%90%E1%83%95%E1%83%98%E1%83%AE%E1%83%90%E1%83%93%E1%83%9D%20%E1%83%90%E1%83%9C%E1%83%92%E1%83%90%E1%83%A0%E1%83%98%E1%83%A8%E1%83%98.)
^ka-Q0418-answer

**ka-Q0419** — რამდენი ხანია ხართ იაპონიაში?

How long have you been in Japan?

Why: Inside/location -ში. [[Georgian#^ka-Q0419|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A0%E1%83%90%E1%83%9B%E1%83%93%E1%83%94%E1%83%9C%E1%83%98%20%E1%83%AE%E1%83%90%E1%83%9C%E1%83%98%E1%83%90%20%E1%83%AE%E1%83%90%E1%83%A0%E1%83%97%20%E1%83%98%E1%83%90%E1%83%9E%E1%83%9D%E1%83%9C%E1%83%98%E1%83%90%E1%83%A8%E1%83%98%3F)
^ka-Q0419-answer

**ka-Q0420** — რამდენი ხანია ხართ იაპონიაში?

How long have you been in Japan?

Attached -ში expresses many in/into relations. The verb and context distinguish position from movement; the suffix does not encode the full English prepositional phrase by itself.

Why: Inside/location -ში. [[Georgian#^ka-Q0420|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A0%E1%83%90%E1%83%9B%E1%83%93%E1%83%94%E1%83%9C%E1%83%98%20%E1%83%AE%E1%83%90%E1%83%9C%E1%83%98%E1%83%90%20%E1%83%AE%E1%83%90%E1%83%A0%E1%83%97%20%E1%83%98%E1%83%90%E1%83%9E%E1%83%9D%E1%83%9C%E1%83%98%E1%83%90%E1%83%A8%E1%83%98%3F)
^ka-Q0420-answer

**ka-Q0421** — ტომმა თქვა, რომ წავიდოდა ბოსტონში.

Tom said that he'd go to Boston.

Expected form: **ბოსტონში**

Why: Inside/location -ში. [[Georgian#^ka-Q0421|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%9B%E1%83%90%20%E1%83%97%E1%83%A5%E1%83%95%E1%83%90%2C%20%E1%83%A0%E1%83%9D%E1%83%9B%20%E1%83%AC%E1%83%90%E1%83%95%E1%83%98%E1%83%93%E1%83%9D%E1%83%93%E1%83%90%20%E1%83%91%E1%83%9D%E1%83%A1%E1%83%A2%E1%83%9D%E1%83%9C%E1%83%A8%E1%83%98.)
^ka-Q0421-answer

**ka-Q0422** — ტომმა თქვა, რომ წავიდოდა ბოსტონში.

Tom said that he'd go to Boston.

Expected form: **ბოსტონში**

Why: Inside/location -ში. [[Georgian#^ka-Q0422|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%9B%E1%83%90%20%E1%83%97%E1%83%A5%E1%83%95%E1%83%90%2C%20%E1%83%A0%E1%83%9D%E1%83%9B%20%E1%83%AC%E1%83%90%E1%83%95%E1%83%98%E1%83%93%E1%83%9D%E1%83%93%E1%83%90%20%E1%83%91%E1%83%9D%E1%83%A1%E1%83%A2%E1%83%9D%E1%83%9C%E1%83%A8%E1%83%98.)
^ka-Q0422-answer

**ka-Q0423** — წაეთრიე სკოლაში! შე ზარმაცო ნაბიჭვარო!

Go to school! You lazy bastard.

Expected form: **სკოლაში**

Why: Inside/location -ში. [[Georgian#^ka-Q0423|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%AC%E1%83%90%E1%83%94%E1%83%97%E1%83%A0%E1%83%98%E1%83%94%20%E1%83%A1%E1%83%99%E1%83%9D%E1%83%9A%E1%83%90%E1%83%A8%E1%83%98%21%20%E1%83%A8%E1%83%94%20%E1%83%96%E1%83%90%E1%83%A0%E1%83%9B%E1%83%90%E1%83%AA%E1%83%9D%20%E1%83%9C%E1%83%90%E1%83%91%E1%83%98%E1%83%AD%E1%83%95%E1%83%90%E1%83%A0%E1%83%9D%21)
^ka-Q0423-answer

**ka-Q0424** — წაეთრიე სკოლაში! შე ზარმაცო ნაბიჭვარო!

Go to school! You lazy bastard.

Why: Inside/location -ში. [[Georgian#^ka-Q0424|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%AC%E1%83%90%E1%83%94%E1%83%97%E1%83%A0%E1%83%98%E1%83%94%20%E1%83%A1%E1%83%99%E1%83%9D%E1%83%9A%E1%83%90%E1%83%A8%E1%83%98%21%20%E1%83%A8%E1%83%94%20%E1%83%96%E1%83%90%E1%83%A0%E1%83%9B%E1%83%90%E1%83%AA%E1%83%9D%20%E1%83%9C%E1%83%90%E1%83%91%E1%83%98%E1%83%AD%E1%83%95%E1%83%90%E1%83%A0%E1%83%9D%21)
^ka-Q0424-answer

**ka-Q0425** — მე მგონი ტომი ბოსტონში ცხოვრობს.

I think Tom lives in Boston.

Why: Inside/location -ში. [[Georgian#^ka-Q0425|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%9B%E1%83%92%E1%83%9D%E1%83%9C%E1%83%98%20%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%98%20%E1%83%91%E1%83%9D%E1%83%A1%E1%83%A2%E1%83%9D%E1%83%9C%E1%83%A8%E1%83%98%20%E1%83%AA%E1%83%AE%E1%83%9D%E1%83%95%E1%83%A0%E1%83%9D%E1%83%91%E1%83%A1.)
^ka-Q0425-answer

**ka-Q0426** — მე მგონი ტომი ბოსტონში ცხოვრობს.

I think Tom lives in Boston.

Attached -ში expresses many in/into relations. The verb and context distinguish position from movement; the suffix does not encode the full English prepositional phrase by itself.

Why: Inside/location -ში. [[Georgian#^ka-Q0426|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%9B%E1%83%92%E1%83%9D%E1%83%9C%E1%83%98%20%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%98%20%E1%83%91%E1%83%9D%E1%83%A1%E1%83%A2%E1%83%9D%E1%83%9C%E1%83%A8%E1%83%98%20%E1%83%AA%E1%83%AE%E1%83%9D%E1%83%95%E1%83%A0%E1%83%9D%E1%83%91%E1%83%A1.)
^ka-Q0426-answer

**ka-Q0427** — ტომი დაინახე ავსტრალიაში?

Did you see Tom in Australia?

Expected form: **ავსტრალიაში**

Why: Inside/location -ში. [[Georgian#^ka-Q0427|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%98%20%E1%83%93%E1%83%90%E1%83%98%E1%83%9C%E1%83%90%E1%83%AE%E1%83%94%20%E1%83%90%E1%83%95%E1%83%A1%E1%83%A2%E1%83%A0%E1%83%90%E1%83%9A%E1%83%98%E1%83%90%E1%83%A8%E1%83%98%3F)
^ka-Q0427-answer

**ka-Q0428** — ტომი დაინახე ავსტრალიაში?

Did you see Tom in Australia?

Expected form: **ავსტრალიაში**

Why: Inside/location -ში. [[Georgian#^ka-Q0428|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%98%20%E1%83%93%E1%83%90%E1%83%98%E1%83%9C%E1%83%90%E1%83%AE%E1%83%94%20%E1%83%90%E1%83%95%E1%83%A1%E1%83%A2%E1%83%A0%E1%83%90%E1%83%9A%E1%83%98%E1%83%90%E1%83%A8%E1%83%98%3F)
^ka-Q0428-answer

**ka-Q0429** — ინდოეთში წასვლა მინდა.

I want to go to India.

Expected form: **ინდოეთში**

Why: Inside/location -ში. [[Georgian#^ka-Q0429|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%98%E1%83%9C%E1%83%93%E1%83%9D%E1%83%94%E1%83%97%E1%83%A8%E1%83%98%20%E1%83%AC%E1%83%90%E1%83%A1%E1%83%95%E1%83%9A%E1%83%90%20%E1%83%9B%E1%83%98%E1%83%9C%E1%83%93%E1%83%90.)
^ka-Q0429-answer

**ka-Q0430** — ინდოეთში წასვლა მინდა.

I want to go to India.

Why: Inside/location -ში. [[Georgian#^ka-Q0430|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%98%E1%83%9C%E1%83%93%E1%83%9D%E1%83%94%E1%83%97%E1%83%A8%E1%83%98%20%E1%83%AC%E1%83%90%E1%83%A1%E1%83%95%E1%83%9A%E1%83%90%20%E1%83%9B%E1%83%98%E1%83%9C%E1%83%93%E1%83%90.)
^ka-Q0430-answer

**ka-Q0431** — შვებულებაში წავალ საფრანგეთში.

I will go to France on holiday.

Why: Inside/location -ში. [[Georgian#^ka-Q0431|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A8%E1%83%95%E1%83%94%E1%83%91%E1%83%A3%E1%83%9A%E1%83%94%E1%83%91%E1%83%90%E1%83%A8%E1%83%98%20%E1%83%AC%E1%83%90%E1%83%95%E1%83%90%E1%83%9A%20%E1%83%A1%E1%83%90%E1%83%A4%E1%83%A0%E1%83%90%E1%83%9C%E1%83%92%E1%83%94%E1%83%97%E1%83%A8%E1%83%98.)
^ka-Q0431-answer

**ka-Q0432** — შვებულებაში წავალ საფრანგეთში.

I will go to France on holiday.

Attached -ში expresses many in/into relations. The verb and context distinguish position from movement; the suffix does not encode the full English prepositional phrase by itself.

Why: Inside/location -ში. [[Georgian#^ka-Q0432|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A8%E1%83%95%E1%83%94%E1%83%91%E1%83%A3%E1%83%9A%E1%83%94%E1%83%91%E1%83%90%E1%83%A8%E1%83%98%20%E1%83%AC%E1%83%90%E1%83%95%E1%83%90%E1%83%9A%20%E1%83%A1%E1%83%90%E1%83%A4%E1%83%A0%E1%83%90%E1%83%9C%E1%83%92%E1%83%94%E1%83%97%E1%83%A8%E1%83%98.)
^ka-Q0432-answer

**ka-Q0433** — მე ვარ იგივე ნავში.

I'm in the same boat.

Expected form: **ნავში**

Why: Inside/location -ში. [[Georgian#^ka-Q0433|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%95%E1%83%90%E1%83%A0%20%E1%83%98%E1%83%92%E1%83%98%E1%83%95%E1%83%94%20%E1%83%9C%E1%83%90%E1%83%95%E1%83%A8%E1%83%98.)
^ka-Q0433-answer

**ka-Q0434** — მე ვარ იგივე ნავში.

I'm in the same boat.

Expected form: **ნავში**

Why: Inside/location -ში. [[Georgian#^ka-Q0434|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%95%E1%83%90%E1%83%A0%20%E1%83%98%E1%83%92%E1%83%98%E1%83%95%E1%83%94%20%E1%83%9C%E1%83%90%E1%83%95%E1%83%A8%E1%83%98.)
^ka-Q0434-answer

**ka-Q0435** — მე ტურისტულ სააგენტოში ვმუშაობ.

I work in a tourist agency.

Expected form: **სააგენტოში**

Why: Inside/location -ში. [[Georgian#^ka-Q0435|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%A2%E1%83%A3%E1%83%A0%E1%83%98%E1%83%A1%E1%83%A2%E1%83%A3%E1%83%9A%20%E1%83%A1%E1%83%90%E1%83%90%E1%83%92%E1%83%94%E1%83%9C%E1%83%A2%E1%83%9D%E1%83%A8%E1%83%98%20%E1%83%95%E1%83%9B%E1%83%A3%E1%83%A8%E1%83%90%E1%83%9D%E1%83%91.)
^ka-Q0435-answer

**ka-Q0436** — მე ტურისტულ სააგენტოში ვმუშაობ.

I work in a tourist agency.

Why: Inside/location -ში. [[Georgian#^ka-Q0436|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%A2%E1%83%A3%E1%83%A0%E1%83%98%E1%83%A1%E1%83%A2%E1%83%A3%E1%83%9A%20%E1%83%A1%E1%83%90%E1%83%90%E1%83%92%E1%83%94%E1%83%9C%E1%83%A2%E1%83%9D%E1%83%A8%E1%83%98%20%E1%83%95%E1%83%9B%E1%83%A3%E1%83%A8%E1%83%90%E1%83%9D%E1%83%91.)
^ka-Q0436-answer

**ka-Q0437** — ამჟამად ტომი ცხოვრობს ავსტრალიაში.

Currently, Tom lives in Australia.

Why: Inside/location -ში. [[Georgian#^ka-Q0437|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%9B%E1%83%9F%E1%83%90%E1%83%9B%E1%83%90%E1%83%93%20%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%98%20%E1%83%AA%E1%83%AE%E1%83%9D%E1%83%95%E1%83%A0%E1%83%9D%E1%83%91%E1%83%A1%20%E1%83%90%E1%83%95%E1%83%A1%E1%83%A2%E1%83%A0%E1%83%90%E1%83%9A%E1%83%98%E1%83%90%E1%83%A8%E1%83%98.)
^ka-Q0437-answer

**ka-Q0438** — ამჟამად ტომი ცხოვრობს ავსტრალიაში.

Currently, Tom lives in Australia.

Attached -ში expresses many in/into relations. The verb and context distinguish position from movement; the suffix does not encode the full English prepositional phrase by itself.

Why: Inside/location -ში. [[Georgian#^ka-Q0438|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%9B%E1%83%9F%E1%83%90%E1%83%9B%E1%83%90%E1%83%93%20%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%98%20%E1%83%AA%E1%83%AE%E1%83%9D%E1%83%95%E1%83%A0%E1%83%9D%E1%83%91%E1%83%A1%20%E1%83%90%E1%83%95%E1%83%A1%E1%83%A2%E1%83%A0%E1%83%90%E1%83%9A%E1%83%98%E1%83%90%E1%83%A8%E1%83%98.)
^ka-Q0438-answer

**ka-Q0439** — ამერიკაში ხშირად ჩინელში ვეშლებოდი.

In the U.S. I was often taken to be Chinese.

Expected form: **ამერიკაში**

Why: Inside/location -ში. [[Georgian#^ka-Q0439|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%9B%E1%83%94%E1%83%A0%E1%83%98%E1%83%99%E1%83%90%E1%83%A8%E1%83%98%20%E1%83%AE%E1%83%A8%E1%83%98%E1%83%A0%E1%83%90%E1%83%93%20%E1%83%A9%E1%83%98%E1%83%9C%E1%83%94%E1%83%9A%E1%83%A8%E1%83%98%20%E1%83%95%E1%83%94%E1%83%A8%E1%83%9A%E1%83%94%E1%83%91%E1%83%9D%E1%83%93%E1%83%98.)
^ka-Q0439-answer

**ka-Q0440** — ამერიკაში ხშირად ჩინელში ვეშლებოდი.

In the U.S. I was often taken to be Chinese.

Expected form: **ამერიკაში**

Why: Inside/location -ში. [[Georgian#^ka-Q0440|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%9B%E1%83%94%E1%83%A0%E1%83%98%E1%83%99%E1%83%90%E1%83%A8%E1%83%98%20%E1%83%AE%E1%83%A8%E1%83%98%E1%83%A0%E1%83%90%E1%83%93%20%E1%83%A9%E1%83%98%E1%83%9C%E1%83%94%E1%83%9A%E1%83%A8%E1%83%98%20%E1%83%95%E1%83%94%E1%83%A8%E1%83%9A%E1%83%94%E1%83%91%E1%83%9D%E1%83%93%E1%83%98.)
^ka-Q0440-answer

**ka-Q0441** — მე მუშაობა არ მინდა ასეთ პირობებში.

I don't want to work under these conditions.

Expected form: **პირობებში**

Why: Inside/location -ში. [[Georgian#^ka-Q0441|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%9B%E1%83%A3%E1%83%A8%E1%83%90%E1%83%9D%E1%83%91%E1%83%90%20%E1%83%90%E1%83%A0%20%E1%83%9B%E1%83%98%E1%83%9C%E1%83%93%E1%83%90%20%E1%83%90%E1%83%A1%E1%83%94%E1%83%97%20%E1%83%9E%E1%83%98%E1%83%A0%E1%83%9D%E1%83%91%E1%83%94%E1%83%91%E1%83%A8%E1%83%98.)
^ka-Q0441-answer

**ka-Q0442** — მე მუშაობა არ მინდა ასეთ პირობებში.

I don't want to work under these conditions.

Why: Inside/location -ში. [[Georgian#^ka-Q0442|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%9B%E1%83%A3%E1%83%A8%E1%83%90%E1%83%9D%E1%83%91%E1%83%90%20%E1%83%90%E1%83%A0%20%E1%83%9B%E1%83%98%E1%83%9C%E1%83%93%E1%83%90%20%E1%83%90%E1%83%A1%E1%83%94%E1%83%97%20%E1%83%9E%E1%83%98%E1%83%A0%E1%83%9D%E1%83%91%E1%83%94%E1%83%91%E1%83%A8%E1%83%98.)
^ka-Q0442-answer

**ka-Q0443** — ჩემს გზაში ხარ.

You are in my way.

Why: Inside/location -ში. [[Georgian#^ka-Q0443|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A9%E1%83%94%E1%83%9B%E1%83%A1%20%E1%83%92%E1%83%96%E1%83%90%E1%83%A8%E1%83%98%20%E1%83%AE%E1%83%90%E1%83%A0.)
^ka-Q0443-answer

**ka-Q0444** — ჩემს გზაში ხარ.

You are in my way.

Attached -ში expresses many in/into relations. The verb and context distinguish position from movement; the suffix does not encode the full English prepositional phrase by itself.

Why: Inside/location -ში. [[Georgian#^ka-Q0444|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A9%E1%83%94%E1%83%9B%E1%83%A1%20%E1%83%92%E1%83%96%E1%83%90%E1%83%A8%E1%83%98%20%E1%83%AE%E1%83%90%E1%83%A0.)
^ka-Q0444-answer

**ka-Q0445** — მე ბანკში ვმუშაობ.

I work in a bank.

Expected form: **ბანკში**

Why: Inside/location -ში. [[Georgian#^ka-Q0445|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%91%E1%83%90%E1%83%9C%E1%83%99%E1%83%A8%E1%83%98%20%E1%83%95%E1%83%9B%E1%83%A3%E1%83%A8%E1%83%90%E1%83%9D%E1%83%91.)
^ka-Q0445-answer

**ka-Q0446** — მე ბანკში ვმუშაობ.

I work in a bank.

Expected form: **ბანკში**

Why: Inside/location -ში. [[Georgian#^ka-Q0446|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%91%E1%83%90%E1%83%9C%E1%83%99%E1%83%A8%E1%83%98%20%E1%83%95%E1%83%9B%E1%83%A3%E1%83%A8%E1%83%90%E1%83%9D%E1%83%91.)
^ka-Q0446-answer

**ka-Q0447** — მე რუსეთიდან ვარ.

I am from Russia.

Expected form: **რუსეთიდან**

Why: Source -დან. [[Georgian#^ka-Q0447|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%A0%E1%83%A3%E1%83%A1%E1%83%94%E1%83%97%E1%83%98%E1%83%93%E1%83%90%E1%83%9C%20%E1%83%95%E1%83%90%E1%83%A0.)
^ka-Q0447-answer

**ka-Q0448** — მე რუსეთიდან ვარ.

I am from Russia.

Why: Source -დან. [[Georgian#^ka-Q0448|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%A0%E1%83%A3%E1%83%A1%E1%83%94%E1%83%97%E1%83%98%E1%83%93%E1%83%90%E1%83%9C%20%E1%83%95%E1%83%90%E1%83%A0.)
^ka-Q0448-answer

**ka-Q0449** — მე ნორვეგიადან ვარ.

I am from Norway.

Why: Source -დან. [[Georgian#^ka-Q0449|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%9C%E1%83%9D%E1%83%A0%E1%83%95%E1%83%94%E1%83%92%E1%83%98%E1%83%90%E1%83%93%E1%83%90%E1%83%9C%20%E1%83%95%E1%83%90%E1%83%A0.)
^ka-Q0449-answer

**ka-Q0450** — მე ნორვეგიადან ვარ.

I am from Norway.

Attached -დან expresses many from/source relations, with stem and linking changes. Learn a word’s actual inflection rather than cutting any final syllable off and adding the suffix.

Why: Source -დან. [[Georgian#^ka-Q0450|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%9C%E1%83%9D%E1%83%A0%E1%83%95%E1%83%94%E1%83%92%E1%83%98%E1%83%90%E1%83%93%E1%83%90%E1%83%9C%20%E1%83%95%E1%83%90%E1%83%A0.)
^ka-Q0450-answer


### Answers 451–500

**ka-Q0451** — მე ვარ ამერიკიდან.

I come from America.

Expected form: **ამერიკიდან**

Why: Source -დან. [[Georgian#^ka-Q0451|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%95%E1%83%90%E1%83%A0%20%E1%83%90%E1%83%9B%E1%83%94%E1%83%A0%E1%83%98%E1%83%99%E1%83%98%E1%83%93%E1%83%90%E1%83%9C.)
^ka-Q0451-answer

**ka-Q0452** — მე ვარ ამერიკიდან.

I come from America.

Expected form: **ამერიკიდან**

Why: Source -დან. [[Georgian#^ka-Q0452|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%95%E1%83%90%E1%83%A0%20%E1%83%90%E1%83%9B%E1%83%94%E1%83%A0%E1%83%98%E1%83%99%E1%83%98%E1%83%93%E1%83%90%E1%83%9C.)
^ka-Q0452-answer

**ka-Q0453** — მე ინგლისიდან ვარ.

I come from England.

Expected form: **ინგლისიდან**

Why: Source -დან. [[Georgian#^ka-Q0453|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%98%E1%83%9C%E1%83%92%E1%83%9A%E1%83%98%E1%83%A1%E1%83%98%E1%83%93%E1%83%90%E1%83%9C%20%E1%83%95%E1%83%90%E1%83%A0.)
^ka-Q0453-answer

**ka-Q0454** — მე ინგლისიდან ვარ.

I come from England.

Why: Source -დან. [[Georgian#^ka-Q0454|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%98%E1%83%9C%E1%83%92%E1%83%9A%E1%83%98%E1%83%A1%E1%83%98%E1%83%93%E1%83%90%E1%83%9C%20%E1%83%95%E1%83%90%E1%83%A0.)
^ka-Q0454-answer

**ka-Q0455** — პეტრე მაგიდიდან ადგა, უსიტყვოდ ჭიქა გამოცალა და მერე ისევ დაჯდა.

Peter got up from the table, silently poured out his glass, then sat down again.

Why: Source -დან. [[Georgian#^ka-Q0455|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9E%E1%83%94%E1%83%A2%E1%83%A0%E1%83%94%20%E1%83%9B%E1%83%90%E1%83%92%E1%83%98%E1%83%93%E1%83%98%E1%83%93%E1%83%90%E1%83%9C%20%E1%83%90%E1%83%93%E1%83%92%E1%83%90%2C%20%E1%83%A3%E1%83%A1%E1%83%98%E1%83%A2%E1%83%A7%E1%83%95%E1%83%9D%E1%83%93%20%E1%83%AD%E1%83%98%E1%83%A5%E1%83%90%20%E1%83%92%E1%83%90%E1%83%9B%E1%83%9D%E1%83%AA%E1%83%90%E1%83%9A%E1%83%90%20%E1%83%93%E1%83%90%20%E1%83%9B%E1%83%94%E1%83%A0%E1%83%94%20%E1%83%98%E1%83%A1%E1%83%94%E1%83%95%20%E1%83%93%E1%83%90%E1%83%AF%E1%83%93%E1%83%90.)
^ka-Q0455-answer

**ka-Q0456** — პეტრე მაგიდიდან ადგა, უსიტყვოდ ჭიქა გამოცალა და მერე ისევ დაჯდა.

Peter got up from the table, silently poured out his glass, then sat down again.

Attached -დან expresses many from/source relations, with stem and linking changes. Learn a word’s actual inflection rather than cutting any final syllable off and adding the suffix.

Why: Source -დან. [[Georgian#^ka-Q0456|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9E%E1%83%94%E1%83%A2%E1%83%A0%E1%83%94%20%E1%83%9B%E1%83%90%E1%83%92%E1%83%98%E1%83%93%E1%83%98%E1%83%93%E1%83%90%E1%83%9C%20%E1%83%90%E1%83%93%E1%83%92%E1%83%90%2C%20%E1%83%A3%E1%83%A1%E1%83%98%E1%83%A2%E1%83%A7%E1%83%95%E1%83%9D%E1%83%93%20%E1%83%AD%E1%83%98%E1%83%A5%E1%83%90%20%E1%83%92%E1%83%90%E1%83%9B%E1%83%9D%E1%83%AA%E1%83%90%E1%83%9A%E1%83%90%20%E1%83%93%E1%83%90%20%E1%83%9B%E1%83%94%E1%83%A0%E1%83%94%20%E1%83%98%E1%83%A1%E1%83%94%E1%83%95%20%E1%83%93%E1%83%90%E1%83%AF%E1%83%93%E1%83%90.)
^ka-Q0456-answer

**ka-Q0457** — ცათამბჯენი ქალაქის ცენტრშია.

The skyscraper is in the center of the city.

Expected form: **ქალაქის**

Why: Possessor and relation forms. [[Georgian#^ka-Q0457|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%AA%E1%83%90%E1%83%97%E1%83%90%E1%83%9B%E1%83%91%E1%83%AF%E1%83%94%E1%83%9C%E1%83%98%20%E1%83%A5%E1%83%90%E1%83%9A%E1%83%90%E1%83%A5%E1%83%98%E1%83%A1%20%E1%83%AA%E1%83%94%E1%83%9C%E1%83%A2%E1%83%A0%E1%83%A8%E1%83%98%E1%83%90.)
^ka-Q0457-answer

**ka-Q0458** — ცათამბჯენი ქალაქის ცენტრშია.

The skyscraper is in the center of the city.

Expected form: **ქალაქის**

Why: Possessor and relation forms. [[Georgian#^ka-Q0458|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%AA%E1%83%90%E1%83%97%E1%83%90%E1%83%9B%E1%83%91%E1%83%AF%E1%83%94%E1%83%9C%E1%83%98%20%E1%83%A5%E1%83%90%E1%83%9A%E1%83%90%E1%83%A5%E1%83%98%E1%83%A1%20%E1%83%AA%E1%83%94%E1%83%9C%E1%83%A2%E1%83%A0%E1%83%A8%E1%83%98%E1%83%90.)
^ka-Q0458-answer

**ka-Q0459** — ის სახლის კაცია.

He's the man of the house.

Expected form: **სახლის**

Why: Possessor and relation forms. [[Georgian#^ka-Q0459|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%98%E1%83%A1%20%E1%83%A1%E1%83%90%E1%83%AE%E1%83%9A%E1%83%98%E1%83%A1%20%E1%83%99%E1%83%90%E1%83%AA%E1%83%98%E1%83%90.)
^ka-Q0459-answer

**ka-Q0460** — ის სახლის კაცია.

He's the man of the house.

Why: Possessor and relation forms. [[Georgian#^ka-Q0460|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%98%E1%83%A1%20%E1%83%A1%E1%83%90%E1%83%AE%E1%83%9A%E1%83%98%E1%83%A1%20%E1%83%99%E1%83%90%E1%83%AA%E1%83%98%E1%83%90.)
^ka-Q0460-answer

**ka-Q0461** — მე წიგნის დავწერ.

I'll write a book.

Why: Possessor and relation forms. [[Georgian#^ka-Q0461|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%AC%E1%83%98%E1%83%92%E1%83%9C%E1%83%98%E1%83%A1%20%E1%83%93%E1%83%90%E1%83%95%E1%83%AC%E1%83%94%E1%83%A0.)
^ka-Q0461-answer

**ka-Q0462** — მე წიგნის დავწერ.

I'll write a book.

Genitive -ის and its stem changes express possession and support other relations. The governing postposition or noun phrase determines the case, not English word order alone.

Why: Possessor and relation forms. [[Georgian#^ka-Q0462|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%AC%E1%83%98%E1%83%92%E1%83%9C%E1%83%98%E1%83%A1%20%E1%83%93%E1%83%90%E1%83%95%E1%83%AC%E1%83%94%E1%83%A0.)
^ka-Q0462-answer

**ka-Q0463** — მე სახლის კაცი ვარ.

I'm the man of the house.

Expected form: **სახლის**

Why: Possessor and relation forms. [[Georgian#^ka-Q0463|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%A1%E1%83%90%E1%83%AE%E1%83%9A%E1%83%98%E1%83%A1%20%E1%83%99%E1%83%90%E1%83%AA%E1%83%98%20%E1%83%95%E1%83%90%E1%83%A0.)
^ka-Q0463-answer

**ka-Q0464** — მე სახლის კაცი ვარ.

I'm the man of the house.

Expected form: **სახლის**

Why: Possessor and relation forms. [[Georgian#^ka-Q0464|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%A1%E1%83%90%E1%83%AE%E1%83%9A%E1%83%98%E1%83%A1%20%E1%83%99%E1%83%90%E1%83%AA%E1%83%98%20%E1%83%95%E1%83%90%E1%83%A0.)
^ka-Q0464-answer

**ka-Q0465** — მწვანე პერანგი მაქვს.

I have a green shirt.

Expected form: **მაქვს**

Why: Possession predicates. [[Georgian#^ka-Q0465|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%AC%E1%83%95%E1%83%90%E1%83%9C%E1%83%94%20%E1%83%9E%E1%83%94%E1%83%A0%E1%83%90%E1%83%9C%E1%83%92%E1%83%98%20%E1%83%9B%E1%83%90%E1%83%A5%E1%83%95%E1%83%A1.)
^ka-Q0465-answer

**ka-Q0466** — მწვანე პერანგი მაქვს.

I have a green shirt.

Why: Possession predicates. [[Georgian#^ka-Q0466|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%AC%E1%83%95%E1%83%90%E1%83%9C%E1%83%94%20%E1%83%9E%E1%83%94%E1%83%A0%E1%83%90%E1%83%9C%E1%83%92%E1%83%98%20%E1%83%9B%E1%83%90%E1%83%A5%E1%83%95%E1%83%A1.)
^ka-Q0466-answer

**ka-Q0467** — ბევრი მაქვს გასაკეთებლად.

I have a lot to do.

Why: Possession predicates. [[Georgian#^ka-Q0467|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%91%E1%83%94%E1%83%95%E1%83%A0%E1%83%98%20%E1%83%9B%E1%83%90%E1%83%A5%E1%83%95%E1%83%A1%20%E1%83%92%E1%83%90%E1%83%A1%E1%83%90%E1%83%99%E1%83%94%E1%83%97%E1%83%94%E1%83%91%E1%83%9A%E1%83%90%E1%83%93.)
^ka-Q0467-answer

**ka-Q0468** — ბევრი მაქვს გასაკეთებლად.

I have a lot to do.

Possession predicates encode participants in a class-specific way. English I have is not a reliable model for the noun cases. Learn the possessor and possessed item together with each form.

Why: Possession predicates. [[Georgian#^ka-Q0468|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%91%E1%83%94%E1%83%95%E1%83%A0%E1%83%98%20%E1%83%9B%E1%83%90%E1%83%A5%E1%83%95%E1%83%A1%20%E1%83%92%E1%83%90%E1%83%A1%E1%83%90%E1%83%99%E1%83%94%E1%83%97%E1%83%94%E1%83%91%E1%83%9A%E1%83%90%E1%83%93.)
^ka-Q0468-answer

**ka-Q0469** — დიდი სახლი მაქვს.

I have a big house.

Expected form: **მაქვს**

Why: Possession predicates. [[Georgian#^ka-Q0469|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%93%E1%83%98%E1%83%93%E1%83%98%20%E1%83%A1%E1%83%90%E1%83%AE%E1%83%9A%E1%83%98%20%E1%83%9B%E1%83%90%E1%83%A5%E1%83%95%E1%83%A1.)
^ka-Q0469-answer

**ka-Q0470** — დიდი სახლი მაქვს.

I have a big house.

Expected form: **მაქვს**

Why: Possession predicates. [[Georgian#^ka-Q0470|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%93%E1%83%98%E1%83%93%E1%83%98%20%E1%83%A1%E1%83%90%E1%83%AE%E1%83%9A%E1%83%98%20%E1%83%9B%E1%83%90%E1%83%A5%E1%83%95%E1%83%A1.)
^ka-Q0470-answer

**ka-Q0471** — ლურჯი სახლი მაქვს.

I have a blue house.

Expected form: **მაქვს**

Why: Possession predicates. [[Georgian#^ka-Q0471|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9A%E1%83%A3%E1%83%A0%E1%83%AF%E1%83%98%20%E1%83%A1%E1%83%90%E1%83%AE%E1%83%9A%E1%83%98%20%E1%83%9B%E1%83%90%E1%83%A5%E1%83%95%E1%83%A1.)
^ka-Q0471-answer

**ka-Q0472** — ლურჯი სახლი მაქვს.

I have a blue house.

Why: Possession predicates. [[Georgian#^ka-Q0472|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9A%E1%83%A3%E1%83%A0%E1%83%AF%E1%83%98%20%E1%83%A1%E1%83%90%E1%83%AE%E1%83%9A%E1%83%98%20%E1%83%9B%E1%83%90%E1%83%A5%E1%83%95%E1%83%A1.)
^ka-Q0472-answer

**ka-Q0473** — რამდენიმე წიგნი გაქვს.

You have few books.

Why: Possession predicates. [[Georgian#^ka-Q0473|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A0%E1%83%90%E1%83%9B%E1%83%93%E1%83%94%E1%83%9C%E1%83%98%E1%83%9B%E1%83%94%20%E1%83%AC%E1%83%98%E1%83%92%E1%83%9C%E1%83%98%20%E1%83%92%E1%83%90%E1%83%A5%E1%83%95%E1%83%A1.)
^ka-Q0473-answer

**ka-Q0474** — რამდენიმე წიგნი გაქვს.

You have few books.

Possession predicates encode participants in a class-specific way. English I have is not a reliable model for the noun cases. Learn the possessor and possessed item together with each form.

Why: Possession predicates. [[Georgian#^ka-Q0474|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A0%E1%83%90%E1%83%9B%E1%83%93%E1%83%94%E1%83%9C%E1%83%98%E1%83%9B%E1%83%94%20%E1%83%AC%E1%83%98%E1%83%92%E1%83%9C%E1%83%98%20%E1%83%92%E1%83%90%E1%83%A5%E1%83%95%E1%83%A1.)
^ka-Q0474-answer

**ka-Q0475** — თომს აქვს მუქი კანი.

Tom has dark skin.

Expected form: **აქვს**

Why: Possession predicates. [[Georgian#^ka-Q0475|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%97%E1%83%9D%E1%83%9B%E1%83%A1%20%E1%83%90%E1%83%A5%E1%83%95%E1%83%A1%20%E1%83%9B%E1%83%A3%E1%83%A5%E1%83%98%20%E1%83%99%E1%83%90%E1%83%9C%E1%83%98.)
^ka-Q0475-answer

**ka-Q0476** — თომს აქვს მუქი კანი.

Tom has dark skin.

Expected form: **აქვს**

Why: Possession predicates. [[Georgian#^ka-Q0476|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%97%E1%83%9D%E1%83%9B%E1%83%A1%20%E1%83%90%E1%83%A5%E1%83%95%E1%83%A1%20%E1%83%9B%E1%83%A3%E1%83%A5%E1%83%98%20%E1%83%99%E1%83%90%E1%83%9C%E1%83%98.)
^ka-Q0476-answer

**ka-Q0477** — მას აქვს ბევრი ცხვირსახოცი.

She has many handkerchiefs.

Expected form: **აქვს**

Why: Possession predicates. [[Georgian#^ka-Q0477|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%90%E1%83%A1%20%E1%83%90%E1%83%A5%E1%83%95%E1%83%A1%20%E1%83%91%E1%83%94%E1%83%95%E1%83%A0%E1%83%98%20%E1%83%AA%E1%83%AE%E1%83%95%E1%83%98%E1%83%A0%E1%83%A1%E1%83%90%E1%83%AE%E1%83%9D%E1%83%AA%E1%83%98.)
^ka-Q0477-answer

**ka-Q0478** — მას აქვს ბევრი ცხვირსახოცი.

She has many handkerchiefs.

Why: Possession predicates. [[Georgian#^ka-Q0478|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%90%E1%83%A1%20%E1%83%90%E1%83%A5%E1%83%95%E1%83%A1%20%E1%83%91%E1%83%94%E1%83%95%E1%83%A0%E1%83%98%20%E1%83%AA%E1%83%AE%E1%83%95%E1%83%98%E1%83%A0%E1%83%A1%E1%83%90%E1%83%AE%E1%83%9D%E1%83%AA%E1%83%98.)
^ka-Q0478-answer

**ka-Q0479** — მწვანე სახლი მაქვს.

I have a green house.

Why: Possession predicates. [[Georgian#^ka-Q0479|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%AC%E1%83%95%E1%83%90%E1%83%9C%E1%83%94%20%E1%83%A1%E1%83%90%E1%83%AE%E1%83%9A%E1%83%98%20%E1%83%9B%E1%83%90%E1%83%A5%E1%83%95%E1%83%A1.)
^ka-Q0479-answer

**ka-Q0480** — მწვანე სახლი მაქვს.

I have a green house.

Possession predicates encode participants in a class-specific way. English I have is not a reliable model for the noun cases. Learn the possessor and possessed item together with each form.

Why: Possession predicates. [[Georgian#^ka-Q0480|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%AC%E1%83%95%E1%83%90%E1%83%9C%E1%83%94%20%E1%83%A1%E1%83%90%E1%83%AE%E1%83%9A%E1%83%98%20%E1%83%9B%E1%83%90%E1%83%A5%E1%83%95%E1%83%A1.)
^ka-Q0480-answer

**ka-Q0481** — თანამედროვე ქართულ დამწერლობას მხედრული ჰქვია და 33 ასო აქვს.

The modern-day Georgian writing system is called Mkhedruli and has 33 letters

Expected form: **აქვს**

Why: Possession predicates. [[Georgian#^ka-Q0481|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%97%E1%83%90%E1%83%9C%E1%83%90%E1%83%9B%E1%83%94%E1%83%93%E1%83%A0%E1%83%9D%E1%83%95%E1%83%94%20%E1%83%A5%E1%83%90%E1%83%A0%E1%83%97%E1%83%A3%E1%83%9A%20%E1%83%93%E1%83%90%E1%83%9B%E1%83%AC%E1%83%94%E1%83%A0%E1%83%9A%E1%83%9D%E1%83%91%E1%83%90%E1%83%A1%20%E1%83%9B%E1%83%AE%E1%83%94%E1%83%93%E1%83%A0%E1%83%A3%E1%83%9A%E1%83%98%20%E1%83%B0%E1%83%A5%E1%83%95%E1%83%98%E1%83%90%20%E1%83%93%E1%83%90%2033%20%E1%83%90%E1%83%A1%E1%83%9D%20%E1%83%90%E1%83%A5%E1%83%95%E1%83%A1.)
^ka-Q0481-answer

**ka-Q0482** — თანამედროვე ქართულ დამწერლობას მხედრული ჰქვია და 33 ასო აქვს.

The modern-day Georgian writing system is called Mkhedruli and has 33 letters

Expected form: **აქვს**

Why: Possession predicates. [[Georgian#^ka-Q0482|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%97%E1%83%90%E1%83%9C%E1%83%90%E1%83%9B%E1%83%94%E1%83%93%E1%83%A0%E1%83%9D%E1%83%95%E1%83%94%20%E1%83%A5%E1%83%90%E1%83%A0%E1%83%97%E1%83%A3%E1%83%9A%20%E1%83%93%E1%83%90%E1%83%9B%E1%83%AC%E1%83%94%E1%83%A0%E1%83%9A%E1%83%9D%E1%83%91%E1%83%90%E1%83%A1%20%E1%83%9B%E1%83%AE%E1%83%94%E1%83%93%E1%83%A0%E1%83%A3%E1%83%9A%E1%83%98%20%E1%83%B0%E1%83%A5%E1%83%95%E1%83%98%E1%83%90%20%E1%83%93%E1%83%90%2033%20%E1%83%90%E1%83%A1%E1%83%9D%20%E1%83%90%E1%83%A5%E1%83%95%E1%83%A1.)
^ka-Q0482-answer

**ka-Q0483** — ნებართვა არ გაქვს აქ გააკეთო.

You're not permitted to do that here.

Expected form: **გაქვს**

Why: Possession predicates. [[Georgian#^ka-Q0483|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9C%E1%83%94%E1%83%91%E1%83%90%E1%83%A0%E1%83%97%E1%83%95%E1%83%90%20%E1%83%90%E1%83%A0%20%E1%83%92%E1%83%90%E1%83%A5%E1%83%95%E1%83%A1%20%E1%83%90%E1%83%A5%20%E1%83%92%E1%83%90%E1%83%90%E1%83%99%E1%83%94%E1%83%97%E1%83%9D.)
^ka-Q0483-answer

**ka-Q0484** — ნებართვა არ გაქვს აქ გააკეთო.

You're not permitted to do that here.

Why: Possession predicates. [[Georgian#^ka-Q0484|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9C%E1%83%94%E1%83%91%E1%83%90%E1%83%A0%E1%83%97%E1%83%95%E1%83%90%20%E1%83%90%E1%83%A0%20%E1%83%92%E1%83%90%E1%83%A5%E1%83%95%E1%83%A1%20%E1%83%90%E1%83%A5%20%E1%83%92%E1%83%90%E1%83%90%E1%83%99%E1%83%94%E1%83%97%E1%83%9D.)
^ka-Q0484-answer

**ka-Q0485** — ბევრი მაქვს გასაკეთებელი.

I have a lot to do.

Why: Possession predicates. [[Georgian#^ka-Q0485|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%91%E1%83%94%E1%83%95%E1%83%A0%E1%83%98%20%E1%83%9B%E1%83%90%E1%83%A5%E1%83%95%E1%83%A1%20%E1%83%92%E1%83%90%E1%83%A1%E1%83%90%E1%83%99%E1%83%94%E1%83%97%E1%83%94%E1%83%91%E1%83%94%E1%83%9A%E1%83%98.)
^ka-Q0485-answer

**ka-Q0486** — ბევრი მაქვს გასაკეთებელი.

I have a lot to do.

Possession predicates encode participants in a class-specific way. English I have is not a reliable model for the noun cases. Learn the possessor and possessed item together with each form.

Why: Possession predicates. [[Georgian#^ka-Q0486|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%91%E1%83%94%E1%83%95%E1%83%A0%E1%83%98%20%E1%83%9B%E1%83%90%E1%83%A5%E1%83%95%E1%83%A1%20%E1%83%92%E1%83%90%E1%83%A1%E1%83%90%E1%83%99%E1%83%94%E1%83%97%E1%83%94%E1%83%91%E1%83%94%E1%83%9A%E1%83%98.)
^ka-Q0486-answer

**ka-Q0487** — წითელი სახლი მაქვს.

I have a red house.

Expected form: **მაქვს**

Why: Possession predicates. [[Georgian#^ka-Q0487|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%AC%E1%83%98%E1%83%97%E1%83%94%E1%83%9A%E1%83%98%20%E1%83%A1%E1%83%90%E1%83%AE%E1%83%9A%E1%83%98%20%E1%83%9B%E1%83%90%E1%83%A5%E1%83%95%E1%83%A1.)
^ka-Q0487-answer

**ka-Q0488** — წითელი სახლი მაქვს.

I have a red house.

Expected form: **მაქვს**

Why: Possession predicates. [[Georgian#^ka-Q0488|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%AC%E1%83%98%E1%83%97%E1%83%94%E1%83%9A%E1%83%98%20%E1%83%A1%E1%83%90%E1%83%AE%E1%83%9A%E1%83%98%20%E1%83%9B%E1%83%90%E1%83%A5%E1%83%95%E1%83%A1.)
^ka-Q0488-answer

**ka-Q0489** — მინდა შენთან ლაპარაკი.

I want to talk to you.

Expected form: **მინდა**

Why: Want predicates. [[Georgian#^ka-Q0489|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%98%E1%83%9C%E1%83%93%E1%83%90%20%E1%83%A8%E1%83%94%E1%83%9C%E1%83%97%E1%83%90%E1%83%9C%20%E1%83%9A%E1%83%90%E1%83%9E%E1%83%90%E1%83%A0%E1%83%90%E1%83%99%E1%83%98.)
^ka-Q0489-answer

**ka-Q0490** — მინდა შენთან ლაპარაკი.

I want to talk to you.

Why: Want predicates. [[Georgian#^ka-Q0490|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%98%E1%83%9C%E1%83%93%E1%83%90%20%E1%83%A8%E1%83%94%E1%83%9C%E1%83%97%E1%83%90%E1%83%9C%20%E1%83%9A%E1%83%90%E1%83%9E%E1%83%90%E1%83%A0%E1%83%90%E1%83%99%E1%83%98.)
^ka-Q0490-answer

**ka-Q0491** — მინდა ვიყო მსახიობი.

I want to be an actress.

Why: Want predicates. [[Georgian#^ka-Q0491|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%98%E1%83%9C%E1%83%93%E1%83%90%20%E1%83%95%E1%83%98%E1%83%A7%E1%83%9D%20%E1%83%9B%E1%83%A1%E1%83%90%E1%83%AE%E1%83%98%E1%83%9D%E1%83%91%E1%83%98.)
^ka-Q0491-answer

**ka-Q0492** — მინდა ვიყო მსახიობი.

I want to be an actress.

Want predicates have their own experiencer/participant pattern. უნდა also occurs in necessity constructions. Use the complement and context to distinguish desire from should/must meanings.

Why: Want predicates. [[Georgian#^ka-Q0492|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%98%E1%83%9C%E1%83%93%E1%83%90%20%E1%83%95%E1%83%98%E1%83%A7%E1%83%9D%20%E1%83%9B%E1%83%A1%E1%83%90%E1%83%AE%E1%83%98%E1%83%9D%E1%83%91%E1%83%98.)
^ka-Q0492-answer

**ka-Q0493** — რომელი წიგნი გინდა?

Which book do you want?

Expected form: **გინდა**

Why: Want predicates. [[Georgian#^ka-Q0493|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A0%E1%83%9D%E1%83%9B%E1%83%94%E1%83%9A%E1%83%98%20%E1%83%AC%E1%83%98%E1%83%92%E1%83%9C%E1%83%98%20%E1%83%92%E1%83%98%E1%83%9C%E1%83%93%E1%83%90%3F)
^ka-Q0493-answer

**ka-Q0494** — რომელი წიგნი გინდა?

Which book do you want?

Expected form: **გინდა**

Why: Want predicates. [[Georgian#^ka-Q0494|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A0%E1%83%9D%E1%83%9B%E1%83%94%E1%83%9A%E1%83%98%20%E1%83%AC%E1%83%98%E1%83%92%E1%83%9C%E1%83%98%20%E1%83%92%E1%83%98%E1%83%9C%E1%83%93%E1%83%90%3F)
^ka-Q0494-answer

**ka-Q0495** — მინდა მასთან ლაპარაკი.

I want to talk to her.

Expected form: **მინდა**

Why: Want predicates. [[Georgian#^ka-Q0495|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%98%E1%83%9C%E1%83%93%E1%83%90%20%E1%83%9B%E1%83%90%E1%83%A1%E1%83%97%E1%83%90%E1%83%9C%20%E1%83%9A%E1%83%90%E1%83%9E%E1%83%90%E1%83%A0%E1%83%90%E1%83%99%E1%83%98.)
^ka-Q0495-answer

**ka-Q0496** — მინდა მასთან ლაპარაკი.

I want to talk to her.

Why: Want predicates. [[Georgian#^ka-Q0496|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%98%E1%83%9C%E1%83%93%E1%83%90%20%E1%83%9B%E1%83%90%E1%83%A1%E1%83%97%E1%83%90%E1%83%9C%20%E1%83%9A%E1%83%90%E1%83%9E%E1%83%90%E1%83%A0%E1%83%90%E1%83%99%E1%83%98.)
^ka-Q0496-answer

**ka-Q0497** — მე უნდა წავიდე.

I have to go.

Why: Want predicates. [[Georgian#^ka-Q0497|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%A3%E1%83%9C%E1%83%93%E1%83%90%20%E1%83%AC%E1%83%90%E1%83%95%E1%83%98%E1%83%93%E1%83%94.)
^ka-Q0497-answer

**ka-Q0498** — მე უნდა წავიდე.

I have to go.

Want predicates have their own experiencer/participant pattern. უნდა also occurs in necessity constructions. Use the complement and context to distinguish desire from should/must meanings.

Why: Want predicates. [[Georgian#^ka-Q0498|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%A3%E1%83%9C%E1%83%93%E1%83%90%20%E1%83%AC%E1%83%90%E1%83%95%E1%83%98%E1%83%93%E1%83%94.)
^ka-Q0498-answer

**ka-Q0499** — გინდა ეს მიიღე?

Do you want to take that?

Expected form: **გინდა**

Why: Want predicates. [[Georgian#^ka-Q0499|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%92%E1%83%98%E1%83%9C%E1%83%93%E1%83%90%20%E1%83%94%E1%83%A1%20%E1%83%9B%E1%83%98%E1%83%98%E1%83%A6%E1%83%94%3F)
^ka-Q0499-answer

**ka-Q0500** — გინდა ეს მიიღე?

Do you want to take that?

Expected form: **გინდა**

Why: Want predicates. [[Georgian#^ka-Q0500|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%92%E1%83%98%E1%83%9C%E1%83%93%E1%83%90%20%E1%83%94%E1%83%A1%20%E1%83%9B%E1%83%98%E1%83%98%E1%83%A6%E1%83%94%3F)
^ka-Q0500-answer


### Answers 501–550

**ka-Q0501** — მე მინდა მოვკვდე გეთერ იანი - თან ერთად.

I want to die with Getter Jaani.

Expected form: **მინდა**

Why: Want predicates. [[Georgian#^ka-Q0501|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%9B%E1%83%98%E1%83%9C%E1%83%93%E1%83%90%20%E1%83%9B%E1%83%9D%E1%83%95%E1%83%99%E1%83%95%E1%83%93%E1%83%94%20%E1%83%92%E1%83%94%E1%83%97%E1%83%94%E1%83%A0%20%E1%83%98%E1%83%90%E1%83%9C%E1%83%98%20-%20%E1%83%97%E1%83%90%E1%83%9C%20%E1%83%94%E1%83%A0%E1%83%97%E1%83%90%E1%83%93.)
^ka-Q0501-answer

**ka-Q0502** — მე მინდა მოვკვდე გეთერ იანი - თან ერთად.

I want to die with Getter Jaani.

Why: Want predicates. [[Georgian#^ka-Q0502|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%9B%E1%83%98%E1%83%9C%E1%83%93%E1%83%90%20%E1%83%9B%E1%83%9D%E1%83%95%E1%83%99%E1%83%95%E1%83%93%E1%83%94%20%E1%83%92%E1%83%94%E1%83%97%E1%83%94%E1%83%A0%20%E1%83%98%E1%83%90%E1%83%9C%E1%83%98%20-%20%E1%83%97%E1%83%90%E1%83%9C%20%E1%83%94%E1%83%A0%E1%83%97%E1%83%90%E1%83%93.)
^ka-Q0502-answer

**ka-Q0503** — მან უნდა დატოვოს.

She needs to leave.

Why: Want predicates. [[Georgian#^ka-Q0503|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%90%E1%83%9C%20%E1%83%A3%E1%83%9C%E1%83%93%E1%83%90%20%E1%83%93%E1%83%90%E1%83%A2%E1%83%9D%E1%83%95%E1%83%9D%E1%83%A1.)
^ka-Q0503-answer

**ka-Q0504** — მან უნდა დატოვოს.

She needs to leave.

Want predicates have their own experiencer/participant pattern. უნდა also occurs in necessity constructions. Use the complement and context to distinguish desire from should/must meanings.

Why: Want predicates. [[Georgian#^ka-Q0504|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%90%E1%83%9C%20%E1%83%A3%E1%83%9C%E1%83%93%E1%83%90%20%E1%83%93%E1%83%90%E1%83%A2%E1%83%9D%E1%83%95%E1%83%9D%E1%83%A1.)
^ka-Q0504-answer

**ka-Q0505** — ვაშლის ტორტს ჭამა მინდა.

I want to eat apple pie.

Expected form: **მინდა**

Why: Want predicates. [[Georgian#^ka-Q0505|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%95%E1%83%90%E1%83%A8%E1%83%9A%E1%83%98%E1%83%A1%20%E1%83%A2%E1%83%9D%E1%83%A0%E1%83%A2%E1%83%A1%20%E1%83%AD%E1%83%90%E1%83%9B%E1%83%90%20%E1%83%9B%E1%83%98%E1%83%9C%E1%83%93%E1%83%90.)
^ka-Q0505-answer

**ka-Q0506** — ვაშლის ტორტს ჭამა მინდა.

I want to eat apple pie.

Expected form: **მინდა**

Why: Want predicates. [[Georgian#^ka-Q0506|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%95%E1%83%90%E1%83%A8%E1%83%9A%E1%83%98%E1%83%A1%20%E1%83%A2%E1%83%9D%E1%83%A0%E1%83%A2%E1%83%A1%20%E1%83%AD%E1%83%90%E1%83%9B%E1%83%90%20%E1%83%9B%E1%83%98%E1%83%9C%E1%83%93%E1%83%90.)
^ka-Q0506-answer

**ka-Q0507** — წასვლა არ გინდა?

Don't you want to go?

Expected form: **გინდა**

Why: Want predicates. [[Georgian#^ka-Q0507|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%AC%E1%83%90%E1%83%A1%E1%83%95%E1%83%9A%E1%83%90%20%E1%83%90%E1%83%A0%20%E1%83%92%E1%83%98%E1%83%9C%E1%83%93%E1%83%90%3F)
^ka-Q0507-answer

**ka-Q0508** — წასვლა არ გინდა?

Don't you want to go?

Why: Want predicates. [[Georgian#^ka-Q0508|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%AC%E1%83%90%E1%83%A1%E1%83%95%E1%83%9A%E1%83%90%20%E1%83%90%E1%83%A0%20%E1%83%92%E1%83%98%E1%83%9C%E1%83%93%E1%83%90%3F)
^ka-Q0508-answer

**ka-Q0509** — შეგიძლია წახვიდე თუ გინდა.

You can go if you want to.

Why: Want predicates. [[Georgian#^ka-Q0509|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A8%E1%83%94%E1%83%92%E1%83%98%E1%83%AB%E1%83%9A%E1%83%98%E1%83%90%20%E1%83%AC%E1%83%90%E1%83%AE%E1%83%95%E1%83%98%E1%83%93%E1%83%94%20%E1%83%97%E1%83%A3%20%E1%83%92%E1%83%98%E1%83%9C%E1%83%93%E1%83%90.)
^ka-Q0509-answer

**ka-Q0510** — შეგიძლია წახვიდე თუ გინდა.

You can go if you want to.

Want predicates have their own experiencer/participant pattern. უნდა also occurs in necessity constructions. Use the complement and context to distinguish desire from should/must meanings.

Why: Want predicates. [[Georgian#^ka-Q0510|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A8%E1%83%94%E1%83%92%E1%83%98%E1%83%AB%E1%83%9A%E1%83%98%E1%83%90%20%E1%83%AC%E1%83%90%E1%83%AE%E1%83%95%E1%83%98%E1%83%93%E1%83%94%20%E1%83%97%E1%83%A3%20%E1%83%92%E1%83%98%E1%83%9C%E1%83%93%E1%83%90.)
^ka-Q0510-answer

**ka-Q0511** — სასტუმროში წასვლა მინდა.

I want to go to a hotel.

Expected form: **მინდა**

Why: Want predicates. [[Georgian#^ka-Q0511|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A1%E1%83%90%E1%83%A1%E1%83%A2%E1%83%A3%E1%83%9B%E1%83%A0%E1%83%9D%E1%83%A8%E1%83%98%20%E1%83%AC%E1%83%90%E1%83%A1%E1%83%95%E1%83%9A%E1%83%90%20%E1%83%9B%E1%83%98%E1%83%9C%E1%83%93%E1%83%90.)
^ka-Q0511-answer

**ka-Q0512** — სასტუმროში წასვლა მინდა.

I want to go to a hotel.

Expected form: **მინდა**

Why: Want predicates. [[Georgian#^ka-Q0512|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A1%E1%83%90%E1%83%A1%E1%83%A2%E1%83%A3%E1%83%9B%E1%83%A0%E1%83%9D%E1%83%A8%E1%83%98%20%E1%83%AC%E1%83%90%E1%83%A1%E1%83%95%E1%83%9A%E1%83%90%20%E1%83%9B%E1%83%98%E1%83%9C%E1%83%93%E1%83%90.)
^ka-Q0512-answer

**ka-Q0513** — მინდა ამერიკაში წავიდე.

I want to go to America.

Expected form: **მინდა**

Why: Want predicates. [[Georgian#^ka-Q0513|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%98%E1%83%9C%E1%83%93%E1%83%90%20%E1%83%90%E1%83%9B%E1%83%94%E1%83%A0%E1%83%98%E1%83%99%E1%83%90%E1%83%A8%E1%83%98%20%E1%83%AC%E1%83%90%E1%83%95%E1%83%98%E1%83%93%E1%83%94.)
^ka-Q0513-answer

**ka-Q0514** — მინდა ამერიკაში წავიდე.

I want to go to America.

Why: Want predicates. [[Georgian#^ka-Q0514|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%98%E1%83%9C%E1%83%93%E1%83%90%20%E1%83%90%E1%83%9B%E1%83%94%E1%83%A0%E1%83%98%E1%83%99%E1%83%90%E1%83%A8%E1%83%98%20%E1%83%AC%E1%83%90%E1%83%95%E1%83%98%E1%83%93%E1%83%94.)
^ka-Q0514-answer

**ka-Q0515** — მინდა ვიყო ბავშვი.

I want to be a child.

Why: Want predicates. [[Georgian#^ka-Q0515|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%98%E1%83%9C%E1%83%93%E1%83%90%20%E1%83%95%E1%83%98%E1%83%A7%E1%83%9D%20%E1%83%91%E1%83%90%E1%83%95%E1%83%A8%E1%83%95%E1%83%98.)
^ka-Q0515-answer

**ka-Q0516** — მინდა ვიყო ბავშვი.

I want to be a child.

Want predicates have their own experiencer/participant pattern. უნდა also occurs in necessity constructions. Use the complement and context to distinguish desire from should/must meanings.

Why: Want predicates. [[Georgian#^ka-Q0516|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%98%E1%83%9C%E1%83%93%E1%83%90%20%E1%83%95%E1%83%98%E1%83%A7%E1%83%9D%20%E1%83%91%E1%83%90%E1%83%95%E1%83%A8%E1%83%95%E1%83%98.)
^ka-Q0516-answer

**ka-Q0517** — არასოდეს არ ისმენს რისი თქმაც მინდა.

He never hears what I'm trying to say.

Expected form: **მინდა**

Why: Want predicates. [[Georgian#^ka-Q0517|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%A0%E1%83%90%E1%83%A1%E1%83%9D%E1%83%93%E1%83%94%E1%83%A1%20%E1%83%90%E1%83%A0%20%E1%83%98%E1%83%A1%E1%83%9B%E1%83%94%E1%83%9C%E1%83%A1%20%E1%83%A0%E1%83%98%E1%83%A1%E1%83%98%20%E1%83%97%E1%83%A5%E1%83%9B%E1%83%90%E1%83%AA%20%E1%83%9B%E1%83%98%E1%83%9C%E1%83%93%E1%83%90.)
^ka-Q0517-answer

**ka-Q0518** — არასოდეს არ ისმენს რისი თქმაც მინდა.

He never hears what I'm trying to say.

Expected form: **მინდა**

Why: Want predicates. [[Georgian#^ka-Q0518|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%A0%E1%83%90%E1%83%A1%E1%83%9D%E1%83%93%E1%83%94%E1%83%A1%20%E1%83%90%E1%83%A0%20%E1%83%98%E1%83%A1%E1%83%9B%E1%83%94%E1%83%9C%E1%83%A1%20%E1%83%A0%E1%83%98%E1%83%A1%E1%83%98%20%E1%83%97%E1%83%A5%E1%83%9B%E1%83%90%E1%83%AA%20%E1%83%9B%E1%83%98%E1%83%9C%E1%83%93%E1%83%90.)
^ka-Q0518-answer

**ka-Q0519** — მე უნდა ის გავაკეთო ახლა?

Do I have to do it now?

Expected form: **უნდა**

Why: Want predicates. [[Georgian#^ka-Q0519|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%A3%E1%83%9C%E1%83%93%E1%83%90%20%E1%83%98%E1%83%A1%20%E1%83%92%E1%83%90%E1%83%95%E1%83%90%E1%83%99%E1%83%94%E1%83%97%E1%83%9D%20%E1%83%90%E1%83%AE%E1%83%9A%E1%83%90%3F)
^ka-Q0519-answer

**ka-Q0520** — მე უნდა ის გავაკეთო ახლა?

Do I have to do it now?

Why: Want predicates. [[Georgian#^ka-Q0520|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%A3%E1%83%9C%E1%83%93%E1%83%90%20%E1%83%98%E1%83%A1%20%E1%83%92%E1%83%90%E1%83%95%E1%83%90%E1%83%99%E1%83%94%E1%83%97%E1%83%9D%20%E1%83%90%E1%83%AE%E1%83%9A%E1%83%90%3F)
^ka-Q0520-answer

**ka-Q0521** — კარგი ლექსიკონი მინდა.

I want a good dictionary.

Why: Want predicates. [[Georgian#^ka-Q0521|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%99%E1%83%90%E1%83%A0%E1%83%92%E1%83%98%20%E1%83%9A%E1%83%94%E1%83%A5%E1%83%A1%E1%83%98%E1%83%99%E1%83%9D%E1%83%9C%E1%83%98%20%E1%83%9B%E1%83%98%E1%83%9C%E1%83%93%E1%83%90.)
^ka-Q0521-answer

**ka-Q0522** — კარგი ლექსიკონი მინდა.

I want a good dictionary.

Want predicates have their own experiencer/participant pattern. უნდა also occurs in necessity constructions. Use the complement and context to distinguish desire from should/must meanings.

Why: Want predicates. [[Georgian#^ka-Q0522|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%99%E1%83%90%E1%83%A0%E1%83%92%E1%83%98%20%E1%83%9A%E1%83%94%E1%83%A5%E1%83%A1%E1%83%98%E1%83%99%E1%83%9D%E1%83%9C%E1%83%98%20%E1%83%9B%E1%83%98%E1%83%9C%E1%83%93%E1%83%90.)
^ka-Q0522-answer

**ka-Q0523** — მე უნდა წავიდე ბოსტონში ტომთან ერთად.

I have to go to Boston with Tom.

Expected form: **უნდა**

Why: Want predicates. [[Georgian#^ka-Q0523|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%A3%E1%83%9C%E1%83%93%E1%83%90%20%E1%83%AC%E1%83%90%E1%83%95%E1%83%98%E1%83%93%E1%83%94%20%E1%83%91%E1%83%9D%E1%83%A1%E1%83%A2%E1%83%9D%E1%83%9C%E1%83%A8%E1%83%98%20%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%97%E1%83%90%E1%83%9C%20%E1%83%94%E1%83%A0%E1%83%97%E1%83%90%E1%83%93.)
^ka-Q0523-answer

**ka-Q0524** — მე უნდა წავიდე ბოსტონში ტომთან ერთად.

I have to go to Boston with Tom.

Expected form: **უნდა**

Why: Want predicates. [[Georgian#^ka-Q0524|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%A3%E1%83%9C%E1%83%93%E1%83%90%20%E1%83%AC%E1%83%90%E1%83%95%E1%83%98%E1%83%93%E1%83%94%20%E1%83%91%E1%83%9D%E1%83%A1%E1%83%A2%E1%83%9D%E1%83%9C%E1%83%A8%E1%83%98%20%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%97%E1%83%90%E1%83%9C%20%E1%83%94%E1%83%A0%E1%83%97%E1%83%90%E1%83%93.)
^ka-Q0524-answer

**ka-Q0525** — მე მინდა ვიყო ჟურნალისტი.

I want to become a journalist.

Expected form: **მინდა**

Why: Want predicates. [[Georgian#^ka-Q0525|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%9B%E1%83%98%E1%83%9C%E1%83%93%E1%83%90%20%E1%83%95%E1%83%98%E1%83%A7%E1%83%9D%20%E1%83%9F%E1%83%A3%E1%83%A0%E1%83%9C%E1%83%90%E1%83%9A%E1%83%98%E1%83%A1%E1%83%A2%E1%83%98.)
^ka-Q0525-answer

**ka-Q0526** — მე მინდა ვიყო ჟურნალისტი.

I want to become a journalist.

Why: Want predicates. [[Georgian#^ka-Q0526|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%9B%E1%83%98%E1%83%9C%E1%83%93%E1%83%90%20%E1%83%95%E1%83%98%E1%83%A7%E1%83%9D%20%E1%83%9F%E1%83%A3%E1%83%A0%E1%83%9C%E1%83%90%E1%83%9A%E1%83%98%E1%83%A1%E1%83%A2%E1%83%98.)
^ka-Q0526-answer

**ka-Q0527** — ლონდონში წასვლა მინდა.

I want to go to London.

Why: Want predicates. [[Georgian#^ka-Q0527|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9A%E1%83%9D%E1%83%9C%E1%83%93%E1%83%9D%E1%83%9C%E1%83%A8%E1%83%98%20%E1%83%AC%E1%83%90%E1%83%A1%E1%83%95%E1%83%9A%E1%83%90%20%E1%83%9B%E1%83%98%E1%83%9C%E1%83%93%E1%83%90.)
^ka-Q0527-answer

**ka-Q0528** — ლონდონში წასვლა მინდა.

I want to go to London.

Want predicates have their own experiencer/participant pattern. უნდა also occurs in necessity constructions. Use the complement and context to distinguish desire from should/must meanings.

Why: Want predicates. [[Georgian#^ka-Q0528|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9A%E1%83%9D%E1%83%9C%E1%83%93%E1%83%9D%E1%83%9C%E1%83%A8%E1%83%98%20%E1%83%AC%E1%83%90%E1%83%A1%E1%83%95%E1%83%9A%E1%83%90%20%E1%83%9B%E1%83%98%E1%83%9C%E1%83%93%E1%83%90.)
^ka-Q0528-answer

**ka-Q0529** — არ მინდა სკოლაში წასვლა.

I don't want to go to school.

Expected form: **მინდა**

Why: Want predicates. [[Georgian#^ka-Q0529|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%A0%20%E1%83%9B%E1%83%98%E1%83%9C%E1%83%93%E1%83%90%20%E1%83%A1%E1%83%99%E1%83%9D%E1%83%9A%E1%83%90%E1%83%A8%E1%83%98%20%E1%83%AC%E1%83%90%E1%83%A1%E1%83%95%E1%83%9A%E1%83%90.)
^ka-Q0529-answer

**ka-Q0530** — არ მინდა სკოლაში წასვლა.

I don't want to go to school.

Expected form: **მინდა**

Why: Want predicates. [[Georgian#^ka-Q0530|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%A0%20%E1%83%9B%E1%83%98%E1%83%9C%E1%83%93%E1%83%90%20%E1%83%A1%E1%83%99%E1%83%9D%E1%83%9A%E1%83%90%E1%83%A8%E1%83%98%20%E1%83%AC%E1%83%90%E1%83%A1%E1%83%95%E1%83%9A%E1%83%90.)
^ka-Q0530-answer

**ka-Q0531** — სიეტლში წასვლა მინდა.

I want to go to Seattle.

Expected form: **მინდა**

Why: Want predicates. [[Georgian#^ka-Q0531|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A1%E1%83%98%E1%83%94%E1%83%A2%E1%83%9A%E1%83%A8%E1%83%98%20%E1%83%AC%E1%83%90%E1%83%A1%E1%83%95%E1%83%9A%E1%83%90%20%E1%83%9B%E1%83%98%E1%83%9C%E1%83%93%E1%83%90.)
^ka-Q0531-answer

**ka-Q0532** — სიეტლში წასვლა მინდა.

I want to go to Seattle.

Why: Want predicates. [[Georgian#^ka-Q0532|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A1%E1%83%98%E1%83%94%E1%83%A2%E1%83%9A%E1%83%A8%E1%83%98%20%E1%83%AC%E1%83%90%E1%83%A1%E1%83%95%E1%83%9A%E1%83%90%20%E1%83%9B%E1%83%98%E1%83%9C%E1%83%93%E1%83%90.)
^ka-Q0532-answer

**ka-Q0533** — გერმანიაში წასვლა მინდა.

I want to go to Germany.

Why: Want predicates. [[Georgian#^ka-Q0533|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%92%E1%83%94%E1%83%A0%E1%83%9B%E1%83%90%E1%83%9C%E1%83%98%E1%83%90%E1%83%A8%E1%83%98%20%E1%83%AC%E1%83%90%E1%83%A1%E1%83%95%E1%83%9A%E1%83%90%20%E1%83%9B%E1%83%98%E1%83%9C%E1%83%93%E1%83%90.)
^ka-Q0533-answer

**ka-Q0534** — გერმანიაში წასვლა მინდა.

I want to go to Germany.

Want predicates have their own experiencer/participant pattern. უნდა also occurs in necessity constructions. Use the complement and context to distinguish desire from should/must meanings.

Why: Want predicates. [[Georgian#^ka-Q0534|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%92%E1%83%94%E1%83%A0%E1%83%9B%E1%83%90%E1%83%9C%E1%83%98%E1%83%90%E1%83%A8%E1%83%98%20%E1%83%AC%E1%83%90%E1%83%A1%E1%83%95%E1%83%9A%E1%83%90%20%E1%83%9B%E1%83%98%E1%83%9C%E1%83%93%E1%83%90.)
^ka-Q0534-answer

**ka-Q0535** — ცოლი არ მინდა, გოგონა მინდა სექსისთვის.

It's not a wife that I want, but a sex friend.

Expected form: **მინდა**

Why: Want predicates. [[Georgian#^ka-Q0535|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%AA%E1%83%9D%E1%83%9A%E1%83%98%20%E1%83%90%E1%83%A0%20%E1%83%9B%E1%83%98%E1%83%9C%E1%83%93%E1%83%90%2C%20%E1%83%92%E1%83%9D%E1%83%92%E1%83%9D%E1%83%9C%E1%83%90%20%E1%83%9B%E1%83%98%E1%83%9C%E1%83%93%E1%83%90%20%E1%83%A1%E1%83%94%E1%83%A5%E1%83%A1%E1%83%98%E1%83%A1%E1%83%97%E1%83%95%E1%83%98%E1%83%A1.)
^ka-Q0535-answer

**ka-Q0536** — ცოლი არ მინდა, გოგონა მინდა სექსისთვის.

It's not a wife that I want, but a sex friend.

Expected form: **მინდა**

Why: Want predicates. [[Georgian#^ka-Q0536|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%AA%E1%83%9D%E1%83%9A%E1%83%98%20%E1%83%90%E1%83%A0%20%E1%83%9B%E1%83%98%E1%83%9C%E1%83%93%E1%83%90%2C%20%E1%83%92%E1%83%9D%E1%83%92%E1%83%9D%E1%83%9C%E1%83%90%20%E1%83%9B%E1%83%98%E1%83%9C%E1%83%93%E1%83%90%20%E1%83%A1%E1%83%94%E1%83%A5%E1%83%A1%E1%83%98%E1%83%A1%E1%83%97%E1%83%95%E1%83%98%E1%83%A1.)
^ka-Q0536-answer

**ka-Q0537** — მან უნდა წავიდეს.

She needs to go.

Expected form: **უნდა**

Why: Want predicates. [[Georgian#^ka-Q0537|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%90%E1%83%9C%20%E1%83%A3%E1%83%9C%E1%83%93%E1%83%90%20%E1%83%AC%E1%83%90%E1%83%95%E1%83%98%E1%83%93%E1%83%94%E1%83%A1.)
^ka-Q0537-answer

**ka-Q0538** — მან უნდა წავიდეს.

She needs to go.

Why: Want predicates. [[Georgian#^ka-Q0538|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%90%E1%83%9C%20%E1%83%A3%E1%83%9C%E1%83%93%E1%83%90%20%E1%83%AC%E1%83%90%E1%83%95%E1%83%98%E1%83%93%E1%83%94%E1%83%A1.)
^ka-Q0538-answer

**ka-Q0539** — მხოლოდ ვიცი ზოგიერთი სიტყვა და ფრაზა.

I only know some words and phrases.

Why: Common present verbs. [[Georgian#^ka-Q0539|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%AE%E1%83%9D%E1%83%9A%E1%83%9D%E1%83%93%20%E1%83%95%E1%83%98%E1%83%AA%E1%83%98%20%E1%83%96%E1%83%9D%E1%83%92%E1%83%98%E1%83%94%E1%83%A0%E1%83%97%E1%83%98%20%E1%83%A1%E1%83%98%E1%83%A2%E1%83%A7%E1%83%95%E1%83%90%20%E1%83%93%E1%83%90%20%E1%83%A4%E1%83%A0%E1%83%90%E1%83%96%E1%83%90.)
^ka-Q0539-answer

**ka-Q0540** — მხოლოდ ვიცი ზოგიერთი სიტყვა და ფრაზა.

I only know some words and phrases.

Georgian verbs may encode multiple participants. The present-series noun cases depend on verb class. Memorise a meaningful sentence and compare a small paradigm rather than guessing from one prefix.

Why: Common present verbs. [[Georgian#^ka-Q0540|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%AE%E1%83%9D%E1%83%9A%E1%83%9D%E1%83%93%20%E1%83%95%E1%83%98%E1%83%AA%E1%83%98%20%E1%83%96%E1%83%9D%E1%83%92%E1%83%98%E1%83%94%E1%83%A0%E1%83%97%E1%83%98%20%E1%83%A1%E1%83%98%E1%83%A2%E1%83%A7%E1%83%95%E1%83%90%20%E1%83%93%E1%83%90%20%E1%83%A4%E1%83%A0%E1%83%90%E1%83%96%E1%83%90.)
^ka-Q0540-answer

**ka-Q0541** — მე არ ვიცი იაპონურად ლაპარაკი.

I don't speak Japanese.

Expected form: **ვიცი**

Why: Common present verbs. [[Georgian#^ka-Q0541|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%90%E1%83%A0%20%E1%83%95%E1%83%98%E1%83%AA%E1%83%98%20%E1%83%98%E1%83%90%E1%83%9E%E1%83%9D%E1%83%9C%E1%83%A3%E1%83%A0%E1%83%90%E1%83%93%20%E1%83%9A%E1%83%90%E1%83%9E%E1%83%90%E1%83%A0%E1%83%90%E1%83%99%E1%83%98.)
^ka-Q0541-answer

**ka-Q0542** — მე არ ვიცი იაპონურად ლაპარაკი.

I don't speak Japanese.

Expected form: **ვიცი**

Why: Common present verbs. [[Georgian#^ka-Q0542|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%90%E1%83%A0%20%E1%83%95%E1%83%98%E1%83%AA%E1%83%98%20%E1%83%98%E1%83%90%E1%83%9E%E1%83%9D%E1%83%9C%E1%83%A3%E1%83%A0%E1%83%90%E1%83%93%20%E1%83%9A%E1%83%90%E1%83%9E%E1%83%90%E1%83%A0%E1%83%90%E1%83%99%E1%83%98.)
^ka-Q0542-answer

**ka-Q0543** — მე ვფიქრობ ტომი მომზადებს საუზმეს.

I think Tom will make breakfast.

Expected form: **ვფიქრობ**

Why: Common present verbs. [[Georgian#^ka-Q0543|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%95%E1%83%A4%E1%83%98%E1%83%A5%E1%83%A0%E1%83%9D%E1%83%91%20%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%98%20%E1%83%9B%E1%83%9D%E1%83%9B%E1%83%96%E1%83%90%E1%83%93%E1%83%94%E1%83%91%E1%83%A1%20%E1%83%A1%E1%83%90%E1%83%A3%E1%83%96%E1%83%9B%E1%83%94%E1%83%A1.)
^ka-Q0543-answer

**ka-Q0544** — მე ვფიქრობ ტომი მომზადებს საუზმეს.

I think Tom will make breakfast.

Why: Common present verbs. [[Georgian#^ka-Q0544|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%95%E1%83%A4%E1%83%98%E1%83%A5%E1%83%A0%E1%83%9D%E1%83%91%20%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%98%20%E1%83%9B%E1%83%9D%E1%83%9B%E1%83%96%E1%83%90%E1%83%93%E1%83%94%E1%83%91%E1%83%A1%20%E1%83%A1%E1%83%90%E1%83%A3%E1%83%96%E1%83%9B%E1%83%94%E1%83%A1.)
^ka-Q0544-answer

**ka-Q0545** — არავინ იცის რა მოხდება.

No one knows what'll happen.

Why: Common present verbs. [[Georgian#^ka-Q0545|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%A0%E1%83%90%E1%83%95%E1%83%98%E1%83%9C%20%E1%83%98%E1%83%AA%E1%83%98%E1%83%A1%20%E1%83%A0%E1%83%90%20%E1%83%9B%E1%83%9D%E1%83%AE%E1%83%93%E1%83%94%E1%83%91%E1%83%90.)
^ka-Q0545-answer

**ka-Q0546** — არავინ იცის რა მოხდება.

No one knows what'll happen.

Georgian verbs may encode multiple participants. The present-series noun cases depend on verb class. Memorise a meaningful sentence and compare a small paradigm rather than guessing from one prefix.

Why: Common present verbs. [[Georgian#^ka-Q0546|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%A0%E1%83%90%E1%83%95%E1%83%98%E1%83%9C%20%E1%83%98%E1%83%AA%E1%83%98%E1%83%A1%20%E1%83%A0%E1%83%90%20%E1%83%9B%E1%83%9D%E1%83%AE%E1%83%93%E1%83%94%E1%83%91%E1%83%90.)
^ka-Q0546-answer

**ka-Q0547** — მე ვფიქრობ ჩვენ ვართ შემდეგი.

I think that we're next.

Expected form: **ვფიქრობ**

Why: Common present verbs. [[Georgian#^ka-Q0547|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%95%E1%83%A4%E1%83%98%E1%83%A5%E1%83%A0%E1%83%9D%E1%83%91%20%E1%83%A9%E1%83%95%E1%83%94%E1%83%9C%20%E1%83%95%E1%83%90%E1%83%A0%E1%83%97%20%E1%83%A8%E1%83%94%E1%83%9B%E1%83%93%E1%83%94%E1%83%92%E1%83%98.)
^ka-Q0547-answer

**ka-Q0548** — მე ვფიქრობ ჩვენ ვართ შემდეგი.

I think that we're next.

Expected form: **ვფიქრობ**

Why: Common present verbs. [[Georgian#^ka-Q0548|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%95%E1%83%A4%E1%83%98%E1%83%A5%E1%83%A0%E1%83%9D%E1%83%91%20%E1%83%A9%E1%83%95%E1%83%94%E1%83%9C%20%E1%83%95%E1%83%90%E1%83%A0%E1%83%97%20%E1%83%A8%E1%83%94%E1%83%9B%E1%83%93%E1%83%94%E1%83%92%E1%83%98.)
^ka-Q0548-answer

**ka-Q0549** — არ ვიცი სიმართლეა თუ ტყუილი.

I don't know whether it is true or not.

Expected form: **ვიცი**

Why: Common present verbs. [[Georgian#^ka-Q0549|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%A0%20%E1%83%95%E1%83%98%E1%83%AA%E1%83%98%20%E1%83%A1%E1%83%98%E1%83%9B%E1%83%90%E1%83%A0%E1%83%97%E1%83%9A%E1%83%94%E1%83%90%20%E1%83%97%E1%83%A3%20%E1%83%A2%E1%83%A7%E1%83%A3%E1%83%98%E1%83%9A%E1%83%98.)
^ka-Q0549-answer

**ka-Q0550** — არ ვიცი სიმართლეა თუ ტყუილი.

I don't know whether it is true or not.

Why: Common present verbs. [[Georgian#^ka-Q0550|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%A0%20%E1%83%95%E1%83%98%E1%83%AA%E1%83%98%20%E1%83%A1%E1%83%98%E1%83%9B%E1%83%90%E1%83%A0%E1%83%97%E1%83%9A%E1%83%94%E1%83%90%20%E1%83%97%E1%83%A3%20%E1%83%A2%E1%83%A7%E1%83%A3%E1%83%98%E1%83%9A%E1%83%98.)
^ka-Q0550-answer


### Answers 551–600

**ka-Q0551** — ეს ყველამ იცის.

Anybody knows it.

Why: Common present verbs. [[Georgian#^ka-Q0551|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%94%E1%83%A1%20%E1%83%A7%E1%83%95%E1%83%94%E1%83%9A%E1%83%90%E1%83%9B%20%E1%83%98%E1%83%AA%E1%83%98%E1%83%A1.)
^ka-Q0551-answer

**ka-Q0552** — ეს ყველამ იცის.

Anybody knows it.

Georgian verbs may encode multiple participants. The present-series noun cases depend on verb class. Memorise a meaningful sentence and compare a small paradigm rather than guessing from one prefix.

Why: Common present verbs. [[Georgian#^ka-Q0552|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%94%E1%83%A1%20%E1%83%A7%E1%83%95%E1%83%94%E1%83%9A%E1%83%90%E1%83%9B%20%E1%83%98%E1%83%AA%E1%83%98%E1%83%A1.)
^ka-Q0552-answer

**ka-Q0553** — სტუდენტი სოციოლოგიას სწავლობს.

The student is working at sociology.

Expected form: **სწავლობს**

Why: Common present verbs. [[Georgian#^ka-Q0553|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A1%E1%83%A2%E1%83%A3%E1%83%93%E1%83%94%E1%83%9C%E1%83%A2%E1%83%98%20%E1%83%A1%E1%83%9D%E1%83%AA%E1%83%98%E1%83%9D%E1%83%9A%E1%83%9D%E1%83%92%E1%83%98%E1%83%90%E1%83%A1%20%E1%83%A1%E1%83%AC%E1%83%90%E1%83%95%E1%83%9A%E1%83%9D%E1%83%91%E1%83%A1.)
^ka-Q0553-answer

**ka-Q0554** — სტუდენტი სოციოლოგიას სწავლობს.

The student is working at sociology.

Expected form: **სწავლობს**

Why: Common present verbs. [[Georgian#^ka-Q0554|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A1%E1%83%A2%E1%83%A3%E1%83%93%E1%83%94%E1%83%9C%E1%83%A2%E1%83%98%20%E1%83%A1%E1%83%9D%E1%83%AA%E1%83%98%E1%83%9D%E1%83%9A%E1%83%9D%E1%83%92%E1%83%98%E1%83%90%E1%83%A1%20%E1%83%A1%E1%83%AC%E1%83%90%E1%83%95%E1%83%9A%E1%83%9D%E1%83%91%E1%83%A1.)
^ka-Q0554-answer

**ka-Q0555** — რას სწავლობს სოვეტოლოგი?

What does a Sovietologist study?

Expected form: **სწავლობს**

Why: Common present verbs. [[Georgian#^ka-Q0555|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A0%E1%83%90%E1%83%A1%20%E1%83%A1%E1%83%AC%E1%83%90%E1%83%95%E1%83%9A%E1%83%9D%E1%83%91%E1%83%A1%20%E1%83%A1%E1%83%9D%E1%83%95%E1%83%94%E1%83%A2%E1%83%9D%E1%83%9A%E1%83%9D%E1%83%92%E1%83%98%3F)
^ka-Q0555-answer

**ka-Q0556** — რას სწავლობს სოვეტოლოგი?

What does a Sovietologist study?

Why: Common present verbs. [[Georgian#^ka-Q0556|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A0%E1%83%90%E1%83%A1%20%E1%83%A1%E1%83%AC%E1%83%90%E1%83%95%E1%83%9A%E1%83%9D%E1%83%91%E1%83%A1%20%E1%83%A1%E1%83%9D%E1%83%95%E1%83%94%E1%83%A2%E1%83%9D%E1%83%9A%E1%83%9D%E1%83%92%E1%83%98%3F)
^ka-Q0556-answer

**ka-Q0557** — 50 კაცამდე მოვიდა.

No more than 50 people came.

Why: Past-series verbs. [[Georgian#^ka-Q0557|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=50%20%E1%83%99%E1%83%90%E1%83%AA%E1%83%90%E1%83%9B%E1%83%93%E1%83%94%20%E1%83%9B%E1%83%9D%E1%83%95%E1%83%98%E1%83%93%E1%83%90.)
^ka-Q0557-answer

**ka-Q0558** — 50 კაცამდე მოვიდა.

No more than 50 people came.

Past forms belong to different screeves and verb classes. Some active verbs change subject/object case marking in the aorist series. There is no single past ending that can be applied to every Georgian verb.

Why: Past-series verbs. [[Georgian#^ka-Q0558|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=50%20%E1%83%99%E1%83%90%E1%83%AA%E1%83%90%E1%83%9B%E1%83%93%E1%83%94%20%E1%83%9B%E1%83%9D%E1%83%95%E1%83%98%E1%83%93%E1%83%90.)
^ka-Q0558-answer

**ka-Q0559** — მარი ერთ-ერათი ყველაზე პოპულარული გოგო იყო.

Mary was not one of the most popular girls.

Expected form: **იყო**

Why: Past-series verbs. [[Georgian#^ka-Q0559|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%90%E1%83%A0%E1%83%98%20%E1%83%94%E1%83%A0%E1%83%97-%E1%83%94%E1%83%A0%E1%83%90%E1%83%97%E1%83%98%20%E1%83%A7%E1%83%95%E1%83%94%E1%83%9A%E1%83%90%E1%83%96%E1%83%94%20%E1%83%9E%E1%83%9D%E1%83%9E%E1%83%A3%E1%83%9A%E1%83%90%E1%83%A0%E1%83%A3%E1%83%9A%E1%83%98%20%E1%83%92%E1%83%9D%E1%83%92%E1%83%9D%20%E1%83%98%E1%83%A7%E1%83%9D.)
^ka-Q0559-answer

**ka-Q0560** — მარი ერთ-ერათი ყველაზე პოპულარული გოგო იყო.

Mary was not one of the most popular girls.

Expected form: **იყო**

Why: Past-series verbs. [[Georgian#^ka-Q0560|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%90%E1%83%A0%E1%83%98%20%E1%83%94%E1%83%A0%E1%83%97-%E1%83%94%E1%83%A0%E1%83%90%E1%83%97%E1%83%98%20%E1%83%A7%E1%83%95%E1%83%94%E1%83%9A%E1%83%90%E1%83%96%E1%83%94%20%E1%83%9E%E1%83%9D%E1%83%9E%E1%83%A3%E1%83%9A%E1%83%90%E1%83%A0%E1%83%A3%E1%83%9A%E1%83%98%20%E1%83%92%E1%83%9D%E1%83%92%E1%83%9D%20%E1%83%98%E1%83%A7%E1%83%9D.)
^ka-Q0560-answer

**ka-Q0561** — მარიამმა ცაზე იყო.

Mary was in heaven.

Expected form: **იყო**

Why: Past-series verbs. [[Georgian#^ka-Q0561|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%90%E1%83%A0%E1%83%98%E1%83%90%E1%83%9B%E1%83%9B%E1%83%90%20%E1%83%AA%E1%83%90%E1%83%96%E1%83%94%20%E1%83%98%E1%83%A7%E1%83%9D.)
^ka-Q0561-answer

**ka-Q0562** — მარიამმა ცაზე იყო.

Mary was in heaven.

Why: Past-series verbs. [[Georgian#^ka-Q0562|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%90%E1%83%A0%E1%83%98%E1%83%90%E1%83%9B%E1%83%9B%E1%83%90%20%E1%83%AA%E1%83%90%E1%83%96%E1%83%94%20%E1%83%98%E1%83%A7%E1%83%9D.)
^ka-Q0562-answer

**ka-Q0563** — ჰუდინი იყო ცნობილი ესკაპოლოგი.

Houdini was a famous escapologist.

Why: Past-series verbs. [[Georgian#^ka-Q0563|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%B0%E1%83%A3%E1%83%93%E1%83%98%E1%83%9C%E1%83%98%20%E1%83%98%E1%83%A7%E1%83%9D%20%E1%83%AA%E1%83%9C%E1%83%9D%E1%83%91%E1%83%98%E1%83%9A%E1%83%98%20%E1%83%94%E1%83%A1%E1%83%99%E1%83%90%E1%83%9E%E1%83%9D%E1%83%9A%E1%83%9D%E1%83%92%E1%83%98.)
^ka-Q0563-answer

**ka-Q0564** — ჰუდინი იყო ცნობილი ესკაპოლოგი.

Houdini was a famous escapologist.

Past forms belong to different screeves and verb classes. Some active verbs change subject/object case marking in the aorist series. There is no single past ending that can be applied to every Georgian verb.

Why: Past-series verbs. [[Georgian#^ka-Q0564|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%B0%E1%83%A3%E1%83%93%E1%83%98%E1%83%9C%E1%83%98%20%E1%83%98%E1%83%A7%E1%83%9D%20%E1%83%AA%E1%83%9C%E1%83%9D%E1%83%91%E1%83%98%E1%83%9A%E1%83%98%20%E1%83%94%E1%83%A1%E1%83%99%E1%83%90%E1%83%9E%E1%83%9D%E1%83%9A%E1%83%9D%E1%83%92%E1%83%98.)
^ka-Q0564-answer

**ka-Q0565** — გამოცდაზე იყო წერილობითი ნაწილი.

The exam had a written portion.

Expected form: **იყო**

Why: Past-series verbs. [[Georgian#^ka-Q0565|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%92%E1%83%90%E1%83%9B%E1%83%9D%E1%83%AA%E1%83%93%E1%83%90%E1%83%96%E1%83%94%20%E1%83%98%E1%83%A7%E1%83%9D%20%E1%83%AC%E1%83%94%E1%83%A0%E1%83%98%E1%83%9A%E1%83%9D%E1%83%91%E1%83%98%E1%83%97%E1%83%98%20%E1%83%9C%E1%83%90%E1%83%AC%E1%83%98%E1%83%9A%E1%83%98.)
^ka-Q0565-answer

**ka-Q0566** — გამოცდაზე იყო წერილობითი ნაწილი.

The exam had a written portion.

Expected form: **იყო**

Why: Past-series verbs. [[Georgian#^ka-Q0566|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%92%E1%83%90%E1%83%9B%E1%83%9D%E1%83%AA%E1%83%93%E1%83%90%E1%83%96%E1%83%94%20%E1%83%98%E1%83%A7%E1%83%9D%20%E1%83%AC%E1%83%94%E1%83%A0%E1%83%98%E1%83%9A%E1%83%9D%E1%83%91%E1%83%98%E1%83%97%E1%83%98%20%E1%83%9C%E1%83%90%E1%83%AC%E1%83%98%E1%83%9A%E1%83%98.)
^ka-Q0566-answer

**ka-Q0567** — რაც მან თქვა სიმართლისგან შორს იყო.

What he said was far from true.

Expected form: **თქვა**

Why: Past-series verbs. [[Georgian#^ka-Q0567|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A0%E1%83%90%E1%83%AA%20%E1%83%9B%E1%83%90%E1%83%9C%20%E1%83%97%E1%83%A5%E1%83%95%E1%83%90%20%E1%83%A1%E1%83%98%E1%83%9B%E1%83%90%E1%83%A0%E1%83%97%E1%83%9A%E1%83%98%E1%83%A1%E1%83%92%E1%83%90%E1%83%9C%20%E1%83%A8%E1%83%9D%E1%83%A0%E1%83%A1%20%E1%83%98%E1%83%A7%E1%83%9D.)
^ka-Q0567-answer

**ka-Q0568** — რაც მან თქვა სიმართლისგან შორს იყო.

What he said was far from true.

Why: Past-series verbs. [[Georgian#^ka-Q0568|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A0%E1%83%90%E1%83%AA%20%E1%83%9B%E1%83%90%E1%83%9C%20%E1%83%97%E1%83%A5%E1%83%95%E1%83%90%20%E1%83%A1%E1%83%98%E1%83%9B%E1%83%90%E1%83%A0%E1%83%97%E1%83%9A%E1%83%98%E1%83%A1%E1%83%92%E1%83%90%E1%83%9C%20%E1%83%A8%E1%83%9D%E1%83%A0%E1%83%A1%20%E1%83%98%E1%83%A7%E1%83%9D.)
^ka-Q0568-answer

**ka-Q0569** — დაივიწყე. ეს უბრალოდ იდეა იყო.

Forget it. It was just an idea.

Why: Past-series verbs. [[Georgian#^ka-Q0569|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%93%E1%83%90%E1%83%98%E1%83%95%E1%83%98%E1%83%AC%E1%83%A7%E1%83%94.%20%E1%83%94%E1%83%A1%20%E1%83%A3%E1%83%91%E1%83%A0%E1%83%90%E1%83%9A%E1%83%9D%E1%83%93%20%E1%83%98%E1%83%93%E1%83%94%E1%83%90%20%E1%83%98%E1%83%A7%E1%83%9D.)
^ka-Q0569-answer

**ka-Q0570** — დაივიწყე. ეს უბრალოდ იდეა იყო.

Forget it. It was just an idea.

Past forms belong to different screeves and verb classes. Some active verbs change subject/object case marking in the aorist series. There is no single past ending that can be applied to every Georgian verb.

Why: Past-series verbs. [[Georgian#^ka-Q0570|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%93%E1%83%90%E1%83%98%E1%83%95%E1%83%98%E1%83%AC%E1%83%A7%E1%83%94.%20%E1%83%94%E1%83%A1%20%E1%83%A3%E1%83%91%E1%83%A0%E1%83%90%E1%83%9A%E1%83%9D%E1%83%93%20%E1%83%98%E1%83%93%E1%83%94%E1%83%90%20%E1%83%98%E1%83%A7%E1%83%9D.)
^ka-Q0570-answer

**ka-Q0571** — მატარებელი დროზე მოვიდა.

The train arrived on schedule.

Expected form: **მოვიდა**

Why: Past-series verbs. [[Georgian#^ka-Q0571|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%90%E1%83%A2%E1%83%90%E1%83%A0%E1%83%94%E1%83%91%E1%83%94%E1%83%9A%E1%83%98%20%E1%83%93%E1%83%A0%E1%83%9D%E1%83%96%E1%83%94%20%E1%83%9B%E1%83%9D%E1%83%95%E1%83%98%E1%83%93%E1%83%90.)
^ka-Q0571-answer

**ka-Q0572** — მატარებელი დროზე მოვიდა.

The train arrived on schedule.

Expected form: **მოვიდა**

Why: Past-series verbs. [[Georgian#^ka-Q0572|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%90%E1%83%A2%E1%83%90%E1%83%A0%E1%83%94%E1%83%91%E1%83%94%E1%83%9A%E1%83%98%20%E1%83%93%E1%83%A0%E1%83%9D%E1%83%96%E1%83%94%20%E1%83%9B%E1%83%9D%E1%83%95%E1%83%98%E1%83%93%E1%83%90.)
^ka-Q0572-answer

**ka-Q0573** — მე არ შემიძლია ვთქვა რამე ცუდი ტომის შესახებ.

I can't say anything bad about Tom.

Expected form: **თქვა**

Why: Past-series verbs. [[Georgian#^ka-Q0573|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%90%E1%83%A0%20%E1%83%A8%E1%83%94%E1%83%9B%E1%83%98%E1%83%AB%E1%83%9A%E1%83%98%E1%83%90%20%E1%83%95%E1%83%97%E1%83%A5%E1%83%95%E1%83%90%20%E1%83%A0%E1%83%90%E1%83%9B%E1%83%94%20%E1%83%AA%E1%83%A3%E1%83%93%E1%83%98%20%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%98%E1%83%A1%20%E1%83%A8%E1%83%94%E1%83%A1%E1%83%90%E1%83%AE%E1%83%94%E1%83%91.)
^ka-Q0573-answer

**ka-Q0574** — მე არ შემიძლია ვთქვა რამე ცუდი ტომის შესახებ.

I can't say anything bad about Tom.

Why: Past-series verbs. [[Georgian#^ka-Q0574|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%90%E1%83%A0%20%E1%83%A8%E1%83%94%E1%83%9B%E1%83%98%E1%83%AB%E1%83%9A%E1%83%98%E1%83%90%20%E1%83%95%E1%83%97%E1%83%A5%E1%83%95%E1%83%90%20%E1%83%A0%E1%83%90%E1%83%9B%E1%83%94%20%E1%83%AA%E1%83%A3%E1%83%93%E1%83%98%20%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%98%E1%83%A1%20%E1%83%A8%E1%83%94%E1%83%A1%E1%83%90%E1%83%AE%E1%83%94%E1%83%91.)
^ka-Q0574-answer

**ka-Q0575** — შეხვედრის შემდეგ ის პირდაპირ მის მაგიდისკენ წავიდა.

After the meeting she headed straight to her desk.

Why: Past-series verbs. [[Georgian#^ka-Q0575|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A8%E1%83%94%E1%83%AE%E1%83%95%E1%83%94%E1%83%93%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%A8%E1%83%94%E1%83%9B%E1%83%93%E1%83%94%E1%83%92%20%E1%83%98%E1%83%A1%20%E1%83%9E%E1%83%98%E1%83%A0%E1%83%93%E1%83%90%E1%83%9E%E1%83%98%E1%83%A0%20%E1%83%9B%E1%83%98%E1%83%A1%20%E1%83%9B%E1%83%90%E1%83%92%E1%83%98%E1%83%93%E1%83%98%E1%83%A1%E1%83%99%E1%83%94%E1%83%9C%20%E1%83%AC%E1%83%90%E1%83%95%E1%83%98%E1%83%93%E1%83%90.)
^ka-Q0575-answer

**ka-Q0576** — შეხვედრის შემდეგ ის პირდაპირ მის მაგიდისკენ წავიდა.

After the meeting she headed straight to her desk.

Past forms belong to different screeves and verb classes. Some active verbs change subject/object case marking in the aorist series. There is no single past ending that can be applied to every Georgian verb.

Why: Past-series verbs. [[Georgian#^ka-Q0576|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A8%E1%83%94%E1%83%AE%E1%83%95%E1%83%94%E1%83%93%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%A8%E1%83%94%E1%83%9B%E1%83%93%E1%83%94%E1%83%92%20%E1%83%98%E1%83%A1%20%E1%83%9E%E1%83%98%E1%83%A0%E1%83%93%E1%83%90%E1%83%9E%E1%83%98%E1%83%A0%20%E1%83%9B%E1%83%98%E1%83%A1%20%E1%83%9B%E1%83%90%E1%83%92%E1%83%98%E1%83%93%E1%83%98%E1%83%A1%E1%83%99%E1%83%94%E1%83%9C%20%E1%83%AC%E1%83%90%E1%83%95%E1%83%98%E1%83%93%E1%83%90.)
^ka-Q0576-answer

**ka-Q0577** — ალბათ თავისი ძველი მეგობრის სანახავად წავიდა.

He must have gone to see his old friend.

Expected form: **წავიდა**

Why: Past-series verbs. [[Georgian#^ka-Q0577|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%9A%E1%83%91%E1%83%90%E1%83%97%20%E1%83%97%E1%83%90%E1%83%95%E1%83%98%E1%83%A1%E1%83%98%20%E1%83%AB%E1%83%95%E1%83%94%E1%83%9A%E1%83%98%20%E1%83%9B%E1%83%94%E1%83%92%E1%83%9D%E1%83%91%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%A1%E1%83%90%E1%83%9C%E1%83%90%E1%83%AE%E1%83%90%E1%83%95%E1%83%90%E1%83%93%20%E1%83%AC%E1%83%90%E1%83%95%E1%83%98%E1%83%93%E1%83%90.)
^ka-Q0577-answer

**ka-Q0578** — ალბათ თავისი ძველი მეგობრის სანახავად წავიდა.

He must have gone to see his old friend.

Expected form: **წავიდა**

Why: Past-series verbs. [[Georgian#^ka-Q0578|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%9A%E1%83%91%E1%83%90%E1%83%97%20%E1%83%97%E1%83%90%E1%83%95%E1%83%98%E1%83%A1%E1%83%98%20%E1%83%AB%E1%83%95%E1%83%94%E1%83%9A%E1%83%98%20%E1%83%9B%E1%83%94%E1%83%92%E1%83%9D%E1%83%91%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%A1%E1%83%90%E1%83%9C%E1%83%90%E1%83%AE%E1%83%90%E1%83%95%E1%83%90%E1%83%93%20%E1%83%AC%E1%83%90%E1%83%95%E1%83%98%E1%83%93%E1%83%90.)
^ka-Q0578-answer

**ka-Q0579** — კლიენტი არ მოვიდა.

The customer did not come.

Expected form: **მოვიდა**

Why: Past-series verbs. [[Georgian#^ka-Q0579|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%99%E1%83%9A%E1%83%98%E1%83%94%E1%83%9C%E1%83%A2%E1%83%98%20%E1%83%90%E1%83%A0%20%E1%83%9B%E1%83%9D%E1%83%95%E1%83%98%E1%83%93%E1%83%90.)
^ka-Q0579-answer

**ka-Q0580** — კლიენტი არ მოვიდა.

The customer did not come.

Why: Past-series verbs. [[Georgian#^ka-Q0580|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%99%E1%83%9A%E1%83%98%E1%83%94%E1%83%9C%E1%83%A2%E1%83%98%20%E1%83%90%E1%83%A0%20%E1%83%9B%E1%83%9D%E1%83%95%E1%83%98%E1%83%93%E1%83%90.)
^ka-Q0580-answer

**ka-Q0581** — ტომმა იცოდა, რომ სადღაც და ჰყავდა, მაგრამ არასოდეს ენახა

Tom knew he had a sister somewhere, but he had never seen her.

Why: Past-series verbs. [[Georgian#^ka-Q0581|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%9B%E1%83%90%20%E1%83%98%E1%83%AA%E1%83%9D%E1%83%93%E1%83%90%2C%20%E1%83%A0%E1%83%9D%E1%83%9B%20%E1%83%A1%E1%83%90%E1%83%93%E1%83%A6%E1%83%90%E1%83%AA%20%E1%83%93%E1%83%90%20%E1%83%B0%E1%83%A7%E1%83%90%E1%83%95%E1%83%93%E1%83%90%2C%20%E1%83%9B%E1%83%90%E1%83%92%E1%83%A0%E1%83%90%E1%83%9B%20%E1%83%90%E1%83%A0%E1%83%90%E1%83%A1%E1%83%9D%E1%83%93%E1%83%94%E1%83%A1%20%E1%83%94%E1%83%9C%E1%83%90%E1%83%AE%E1%83%90)
^ka-Q0581-answer

**ka-Q0582** — ტომმა იცოდა, რომ სადღაც და ჰყავდა, მაგრამ არასოდეს ენახა

Tom knew he had a sister somewhere, but he had never seen her.

Past forms belong to different screeves and verb classes. Some active verbs change subject/object case marking in the aorist series. There is no single past ending that can be applied to every Georgian verb.

Why: Past-series verbs. [[Georgian#^ka-Q0582|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%9B%E1%83%90%20%E1%83%98%E1%83%AA%E1%83%9D%E1%83%93%E1%83%90%2C%20%E1%83%A0%E1%83%9D%E1%83%9B%20%E1%83%A1%E1%83%90%E1%83%93%E1%83%A6%E1%83%90%E1%83%AA%20%E1%83%93%E1%83%90%20%E1%83%B0%E1%83%A7%E1%83%90%E1%83%95%E1%83%93%E1%83%90%2C%20%E1%83%9B%E1%83%90%E1%83%92%E1%83%A0%E1%83%90%E1%83%9B%20%E1%83%90%E1%83%A0%E1%83%90%E1%83%A1%E1%83%9D%E1%83%93%E1%83%94%E1%83%A1%20%E1%83%94%E1%83%9C%E1%83%90%E1%83%AE%E1%83%90)
^ka-Q0582-answer

**ka-Q0583** — გემი ნაპირის გასწვრივ იყო.

The ship was abreast of the shore.

Expected form: **იყო**

Why: Past-series verbs. [[Georgian#^ka-Q0583|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%92%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%9C%E1%83%90%E1%83%9E%E1%83%98%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%92%E1%83%90%E1%83%A1%E1%83%AC%E1%83%95%E1%83%A0%E1%83%98%E1%83%95%20%E1%83%98%E1%83%A7%E1%83%9D.)
^ka-Q0583-answer

**ka-Q0584** — გემი ნაპირის გასწვრივ იყო.

The ship was abreast of the shore.

Expected form: **იყო**

Why: Past-series verbs. [[Georgian#^ka-Q0584|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%92%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%9C%E1%83%90%E1%83%9E%E1%83%98%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%92%E1%83%90%E1%83%A1%E1%83%AC%E1%83%95%E1%83%A0%E1%83%98%E1%83%95%20%E1%83%98%E1%83%A7%E1%83%9D.)
^ka-Q0584-answer

**ka-Q0585** — ვინ იყო ექსპედიციის წინამძღოლი?

Who was the leader of the expedition?

Expected form: **იყო**

Why: Past-series verbs. [[Georgian#^ka-Q0585|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%95%E1%83%98%E1%83%9C%20%E1%83%98%E1%83%A7%E1%83%9D%20%E1%83%94%E1%83%A5%E1%83%A1%E1%83%9E%E1%83%94%E1%83%93%E1%83%98%E1%83%AA%E1%83%98%E1%83%98%E1%83%A1%20%E1%83%AC%E1%83%98%E1%83%9C%E1%83%90%E1%83%9B%E1%83%AB%E1%83%A6%E1%83%9D%E1%83%9A%E1%83%98%3F)
^ka-Q0585-answer

**ka-Q0586** — ვინ იყო ექსპედიციის წინამძღოლი?

Who was the leader of the expedition?

Why: Past-series verbs. [[Georgian#^ka-Q0586|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%95%E1%83%98%E1%83%9C%20%E1%83%98%E1%83%A7%E1%83%9D%20%E1%83%94%E1%83%A5%E1%83%A1%E1%83%9E%E1%83%94%E1%83%93%E1%83%98%E1%83%AA%E1%83%98%E1%83%98%E1%83%A1%20%E1%83%AC%E1%83%98%E1%83%9C%E1%83%90%E1%83%9B%E1%83%AB%E1%83%A6%E1%83%9D%E1%83%9A%E1%83%98%3F)
^ka-Q0586-answer

**ka-Q0587** — ტომმა ავსტრალიაში წავიდა?

Did Tom go to Australia?

Why: Past-series verbs. [[Georgian#^ka-Q0587|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%9B%E1%83%90%20%E1%83%90%E1%83%95%E1%83%A1%E1%83%A2%E1%83%A0%E1%83%90%E1%83%9A%E1%83%98%E1%83%90%E1%83%A8%E1%83%98%20%E1%83%AC%E1%83%90%E1%83%95%E1%83%98%E1%83%93%E1%83%90%3F)
^ka-Q0587-answer

**ka-Q0588** — ტომმა ავსტრალიაში წავიდა?

Did Tom go to Australia?

Past forms belong to different screeves and verb classes. Some active verbs change subject/object case marking in the aorist series. There is no single past ending that can be applied to every Georgian verb.

Why: Past-series verbs. [[Georgian#^ka-Q0588|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%9B%E1%83%90%20%E1%83%90%E1%83%95%E1%83%A1%E1%83%A2%E1%83%A0%E1%83%90%E1%83%9A%E1%83%98%E1%83%90%E1%83%A8%E1%83%98%20%E1%83%AC%E1%83%90%E1%83%95%E1%83%98%E1%83%93%E1%83%90%3F)
^ka-Q0588-answer

**ka-Q0589** — ის წავა სტომატოლოგში.

He will go to the dentist.

Expected form: **წავა**

Why: Future-series forms. [[Georgian#^ka-Q0589|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%98%E1%83%A1%20%E1%83%AC%E1%83%90%E1%83%95%E1%83%90%20%E1%83%A1%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%90%E1%83%A2%E1%83%9D%E1%83%9A%E1%83%9D%E1%83%92%E1%83%A8%E1%83%98.)
^ka-Q0589-answer

**ka-Q0590** — ის წავა სტომატოლოგში.

He will go to the dentist.

Expected form: **წავა**

Why: Future-series forms. [[Georgian#^ka-Q0590|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%98%E1%83%A1%20%E1%83%AC%E1%83%90%E1%83%95%E1%83%90%20%E1%83%A1%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%90%E1%83%A2%E1%83%9D%E1%83%9A%E1%83%9D%E1%83%92%E1%83%A8%E1%83%98.)
^ka-Q0590-answer

**ka-Q0591** — ძალიან კარგი იქნება.

He will be very nice.

Expected form: **იქნება**

Why: Future-series forms. [[Georgian#^ka-Q0591|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%AB%E1%83%90%E1%83%9A%E1%83%98%E1%83%90%E1%83%9C%20%E1%83%99%E1%83%90%E1%83%A0%E1%83%92%E1%83%98%20%E1%83%98%E1%83%A5%E1%83%9C%E1%83%94%E1%83%91%E1%83%90.)
^ka-Q0591-answer

**ka-Q0592** — ძალიან კარგი იქნება.

He will be very nice.

Why: Future-series forms. [[Georgian#^ka-Q0592|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%AB%E1%83%90%E1%83%9A%E1%83%98%E1%83%90%E1%83%9C%20%E1%83%99%E1%83%90%E1%83%A0%E1%83%92%E1%83%98%20%E1%83%98%E1%83%A5%E1%83%9C%E1%83%94%E1%83%91%E1%83%90.)
^ka-Q0592-answer

**ka-Q0593** — ის ამბობს, რომ გიცნობს.

He says that he knows you.

Why: Content and relative linking. [[Georgian#^ka-Q0593|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%98%E1%83%A1%20%E1%83%90%E1%83%9B%E1%83%91%E1%83%9D%E1%83%91%E1%83%A1%2C%20%E1%83%A0%E1%83%9D%E1%83%9B%20%E1%83%92%E1%83%98%E1%83%AA%E1%83%9C%E1%83%9D%E1%83%91%E1%83%A1.)
^ka-Q0593-answer

**ka-Q0594** — ის ამბობს, რომ გიცნობს.

He says that he knows you.

რომ links many content and dependent clauses. Its English translation depends on the construction, and the dependent verb form may reflect the speaker’s attitude or the governing predicate.

Why: Content and relative linking. [[Georgian#^ka-Q0594|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%98%E1%83%A1%20%E1%83%90%E1%83%9B%E1%83%91%E1%83%9D%E1%83%91%E1%83%A1%2C%20%E1%83%A0%E1%83%9D%E1%83%9B%20%E1%83%92%E1%83%98%E1%83%AA%E1%83%9C%E1%83%9D%E1%83%91%E1%83%A1.)
^ka-Q0594-answer

**ka-Q0595** — ჩვენ შევთანხმდით, რომ სამსახურში თავს შევიკავებდით მოწევისაგან.

We agreed to refrain from smoking while we are at work.

Expected form: **რომ**

Why: Content and relative linking. [[Georgian#^ka-Q0595|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A9%E1%83%95%E1%83%94%E1%83%9C%20%E1%83%A8%E1%83%94%E1%83%95%E1%83%97%E1%83%90%E1%83%9C%E1%83%AE%E1%83%9B%E1%83%93%E1%83%98%E1%83%97%2C%20%E1%83%A0%E1%83%9D%E1%83%9B%20%E1%83%A1%E1%83%90%E1%83%9B%E1%83%A1%E1%83%90%E1%83%AE%E1%83%A3%E1%83%A0%E1%83%A8%E1%83%98%20%E1%83%97%E1%83%90%E1%83%95%E1%83%A1%20%E1%83%A8%E1%83%94%E1%83%95%E1%83%98%E1%83%99%E1%83%90%E1%83%95%E1%83%94%E1%83%91%E1%83%93%E1%83%98%E1%83%97%20%E1%83%9B%E1%83%9D%E1%83%AC%E1%83%94%E1%83%95%E1%83%98%E1%83%A1%E1%83%90%E1%83%92%E1%83%90%E1%83%9C.)
^ka-Q0595-answer

**ka-Q0596** — ჩვენ შევთანხმდით, რომ სამსახურში თავს შევიკავებდით მოწევისაგან.

We agreed to refrain from smoking while we are at work.

Expected form: **რომ**

Why: Content and relative linking. [[Georgian#^ka-Q0596|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A9%E1%83%95%E1%83%94%E1%83%9C%20%E1%83%A8%E1%83%94%E1%83%95%E1%83%97%E1%83%90%E1%83%9C%E1%83%AE%E1%83%9B%E1%83%93%E1%83%98%E1%83%97%2C%20%E1%83%A0%E1%83%9D%E1%83%9B%20%E1%83%A1%E1%83%90%E1%83%9B%E1%83%A1%E1%83%90%E1%83%AE%E1%83%A3%E1%83%A0%E1%83%A8%E1%83%98%20%E1%83%97%E1%83%90%E1%83%95%E1%83%A1%20%E1%83%A8%E1%83%94%E1%83%95%E1%83%98%E1%83%99%E1%83%90%E1%83%95%E1%83%94%E1%83%91%E1%83%93%E1%83%98%E1%83%97%20%E1%83%9B%E1%83%9D%E1%83%AC%E1%83%94%E1%83%95%E1%83%98%E1%83%A1%E1%83%90%E1%83%92%E1%83%90%E1%83%9C.)
^ka-Q0596-answer

**ka-Q0597** — ეს მინდა, რომ ნინომ მოიგოს.

I want Nino to win.

Expected form: **რომ**

Why: Content and relative linking. [[Georgian#^ka-Q0597|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%94%E1%83%A1%20%E1%83%9B%E1%83%98%E1%83%9C%E1%83%93%E1%83%90%2C%20%E1%83%A0%E1%83%9D%E1%83%9B%20%E1%83%9C%E1%83%98%E1%83%9C%E1%83%9D%E1%83%9B%20%E1%83%9B%E1%83%9D%E1%83%98%E1%83%92%E1%83%9D%E1%83%A1.)
^ka-Q0597-answer

**ka-Q0598** — ეს მინდა, რომ ნინომ მოიგოს.

I want Nino to win.

Why: Content and relative linking. [[Georgian#^ka-Q0598|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%94%E1%83%A1%20%E1%83%9B%E1%83%98%E1%83%9C%E1%83%93%E1%83%90%2C%20%E1%83%A0%E1%83%9D%E1%83%9B%20%E1%83%9C%E1%83%98%E1%83%9C%E1%83%9D%E1%83%9B%20%E1%83%9B%E1%83%9D%E1%83%98%E1%83%92%E1%83%9D%E1%83%A1.)
^ka-Q0598-answer

**ka-Q0599** — გნებავთ რომ შეუკვეთოთ?

Would you like to order?

Why: Content and relative linking. [[Georgian#^ka-Q0599|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%92%E1%83%9C%E1%83%94%E1%83%91%E1%83%90%E1%83%95%E1%83%97%20%E1%83%A0%E1%83%9D%E1%83%9B%20%E1%83%A8%E1%83%94%E1%83%A3%E1%83%99%E1%83%95%E1%83%94%E1%83%97%E1%83%9D%E1%83%97%3F)
^ka-Q0599-answer

**ka-Q0600** — გნებავთ რომ შეუკვეთოთ?

Would you like to order?

რომ links many content and dependent clauses. Its English translation depends on the construction, and the dependent verb form may reflect the speaker’s attitude or the governing predicate.

Why: Content and relative linking. [[Georgian#^ka-Q0600|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%92%E1%83%9C%E1%83%94%E1%83%91%E1%83%90%E1%83%95%E1%83%97%20%E1%83%A0%E1%83%9D%E1%83%9B%20%E1%83%A8%E1%83%94%E1%83%A3%E1%83%99%E1%83%95%E1%83%94%E1%83%97%E1%83%9D%E1%83%97%3F)
^ka-Q0600-answer


### Answers 601–650

**ka-Q0601** — არ მეგონა, რომ ტოფუ იმდენად გემრიელი იქნებოდა.

I wouldn't have thought that tofu tastes this good.

Expected form: **რომ**

Why: Content and relative linking. [[Georgian#^ka-Q0601|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%A0%20%E1%83%9B%E1%83%94%E1%83%92%E1%83%9D%E1%83%9C%E1%83%90%2C%20%E1%83%A0%E1%83%9D%E1%83%9B%20%E1%83%A2%E1%83%9D%E1%83%A4%E1%83%A3%20%E1%83%98%E1%83%9B%E1%83%93%E1%83%94%E1%83%9C%E1%83%90%E1%83%93%20%E1%83%92%E1%83%94%E1%83%9B%E1%83%A0%E1%83%98%E1%83%94%E1%83%9A%E1%83%98%20%E1%83%98%E1%83%A5%E1%83%9C%E1%83%94%E1%83%91%E1%83%9D%E1%83%93%E1%83%90.)
^ka-Q0601-answer

**ka-Q0602** — არ მეგონა, რომ ტოფუ იმდენად გემრიელი იქნებოდა.

I wouldn't have thought that tofu tastes this good.

Expected form: **რომ**

Why: Content and relative linking. [[Georgian#^ka-Q0602|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%A0%20%E1%83%9B%E1%83%94%E1%83%92%E1%83%9D%E1%83%9C%E1%83%90%2C%20%E1%83%A0%E1%83%9D%E1%83%9B%20%E1%83%A2%E1%83%9D%E1%83%A4%E1%83%A3%20%E1%83%98%E1%83%9B%E1%83%93%E1%83%94%E1%83%9C%E1%83%90%E1%83%93%20%E1%83%92%E1%83%94%E1%83%9B%E1%83%A0%E1%83%98%E1%83%94%E1%83%9A%E1%83%98%20%E1%83%98%E1%83%A5%E1%83%9C%E1%83%94%E1%83%91%E1%83%9D%E1%83%93%E1%83%90.)
^ka-Q0602-answer

**ka-Q0603** — ამბობ რომ ჩემი ცხოვრება საფრთხეშია?

Are you saying my life is in danger?

Expected form: **რომ**

Why: Content and relative linking. [[Georgian#^ka-Q0603|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%9B%E1%83%91%E1%83%9D%E1%83%91%20%E1%83%A0%E1%83%9D%E1%83%9B%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%AA%E1%83%AE%E1%83%9D%E1%83%95%E1%83%A0%E1%83%94%E1%83%91%E1%83%90%20%E1%83%A1%E1%83%90%E1%83%A4%E1%83%A0%E1%83%97%E1%83%AE%E1%83%94%E1%83%A8%E1%83%98%E1%83%90%3F)
^ka-Q0603-answer

**ka-Q0604** — ამბობ რომ ჩემი ცხოვრება საფრთხეშია?

Are you saying my life is in danger?

Why: Content and relative linking. [[Georgian#^ka-Q0604|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%9B%E1%83%91%E1%83%9D%E1%83%91%20%E1%83%A0%E1%83%9D%E1%83%9B%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%AA%E1%83%AE%E1%83%9D%E1%83%95%E1%83%A0%E1%83%94%E1%83%91%E1%83%90%20%E1%83%A1%E1%83%90%E1%83%A4%E1%83%A0%E1%83%97%E1%83%AE%E1%83%94%E1%83%A8%E1%83%98%E1%83%90%3F)
^ka-Q0604-answer

**ka-Q0605** — ადამიანთა უმეტესობა ფიქრობს, რომ მე ვარ გიჟი.

Most people think I'm crazy.

Why: Content and relative linking. [[Georgian#^ka-Q0605|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%93%E1%83%90%E1%83%9B%E1%83%98%E1%83%90%E1%83%9C%E1%83%97%E1%83%90%20%E1%83%A3%E1%83%9B%E1%83%94%E1%83%A2%E1%83%94%E1%83%A1%E1%83%9D%E1%83%91%E1%83%90%20%E1%83%A4%E1%83%98%E1%83%A5%E1%83%A0%E1%83%9D%E1%83%91%E1%83%A1%2C%20%E1%83%A0%E1%83%9D%E1%83%9B%20%E1%83%9B%E1%83%94%20%E1%83%95%E1%83%90%E1%83%A0%20%E1%83%92%E1%83%98%E1%83%9F%E1%83%98.)
^ka-Q0605-answer

**ka-Q0606** — ადამიანთა უმეტესობა ფიქრობს, რომ მე ვარ გიჟი.

Most people think I'm crazy.

რომ links many content and dependent clauses. Its English translation depends on the construction, and the dependent verb form may reflect the speaker’s attitude or the governing predicate.

Why: Content and relative linking. [[Georgian#^ka-Q0606|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%93%E1%83%90%E1%83%9B%E1%83%98%E1%83%90%E1%83%9C%E1%83%97%E1%83%90%20%E1%83%A3%E1%83%9B%E1%83%94%E1%83%A2%E1%83%94%E1%83%A1%E1%83%9D%E1%83%91%E1%83%90%20%E1%83%A4%E1%83%98%E1%83%A5%E1%83%A0%E1%83%9D%E1%83%91%E1%83%A1%2C%20%E1%83%A0%E1%83%9D%E1%83%9B%20%E1%83%9B%E1%83%94%20%E1%83%95%E1%83%90%E1%83%A0%20%E1%83%92%E1%83%98%E1%83%9F%E1%83%98.)
^ka-Q0606-answer

**ka-Q0607** — უკეთესი იქნებოდა, რომ არ წასულიყავი.

You'd better not go.

Expected form: **რომ**

Why: Content and relative linking. [[Georgian#^ka-Q0607|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A3%E1%83%99%E1%83%94%E1%83%97%E1%83%94%E1%83%A1%E1%83%98%20%E1%83%98%E1%83%A5%E1%83%9C%E1%83%94%E1%83%91%E1%83%9D%E1%83%93%E1%83%90%2C%20%E1%83%A0%E1%83%9D%E1%83%9B%20%E1%83%90%E1%83%A0%20%E1%83%AC%E1%83%90%E1%83%A1%E1%83%A3%E1%83%9A%E1%83%98%E1%83%A7%E1%83%90%E1%83%95%E1%83%98.)
^ka-Q0607-answer

**ka-Q0608** — უკეთესი იქნებოდა, რომ არ წასულიყავი.

You'd better not go.

Expected form: **რომ**

Why: Content and relative linking. [[Georgian#^ka-Q0608|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A3%E1%83%99%E1%83%94%E1%83%97%E1%83%94%E1%83%A1%E1%83%98%20%E1%83%98%E1%83%A5%E1%83%9C%E1%83%94%E1%83%91%E1%83%9D%E1%83%93%E1%83%90%2C%20%E1%83%A0%E1%83%9D%E1%83%9B%20%E1%83%90%E1%83%A0%20%E1%83%AC%E1%83%90%E1%83%A1%E1%83%A3%E1%83%9A%E1%83%98%E1%83%A7%E1%83%90%E1%83%95%E1%83%98.)
^ka-Q0608-answer

**ka-Q0609** — თუკი არაფერს ვამბობ, ეს იმას არ ნიშნავს, რომ გეთანხმები.

If I don't say anything, it doesn't mean I'm agreeing with you.

Expected form: **რომ**

Why: Content and relative linking. [[Georgian#^ka-Q0609|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%97%E1%83%A3%E1%83%99%E1%83%98%20%E1%83%90%E1%83%A0%E1%83%90%E1%83%A4%E1%83%94%E1%83%A0%E1%83%A1%20%E1%83%95%E1%83%90%E1%83%9B%E1%83%91%E1%83%9D%E1%83%91%2C%20%E1%83%94%E1%83%A1%20%E1%83%98%E1%83%9B%E1%83%90%E1%83%A1%20%E1%83%90%E1%83%A0%20%E1%83%9C%E1%83%98%E1%83%A8%E1%83%9C%E1%83%90%E1%83%95%E1%83%A1%2C%20%E1%83%A0%E1%83%9D%E1%83%9B%20%E1%83%92%E1%83%94%E1%83%97%E1%83%90%E1%83%9C%E1%83%AE%E1%83%9B%E1%83%94%E1%83%91%E1%83%98.)
^ka-Q0609-answer

**ka-Q0610** — თუკი არაფერს ვამბობ, ეს იმას არ ნიშნავს, რომ გეთანხმები.

If I don't say anything, it doesn't mean I'm agreeing with you.

Why: Content and relative linking. [[Georgian#^ka-Q0610|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%97%E1%83%A3%E1%83%99%E1%83%98%20%E1%83%90%E1%83%A0%E1%83%90%E1%83%A4%E1%83%94%E1%83%A0%E1%83%A1%20%E1%83%95%E1%83%90%E1%83%9B%E1%83%91%E1%83%9D%E1%83%91%2C%20%E1%83%94%E1%83%A1%20%E1%83%98%E1%83%9B%E1%83%90%E1%83%A1%20%E1%83%90%E1%83%A0%20%E1%83%9C%E1%83%98%E1%83%A8%E1%83%9C%E1%83%90%E1%83%95%E1%83%A1%2C%20%E1%83%A0%E1%83%9D%E1%83%9B%20%E1%83%92%E1%83%94%E1%83%97%E1%83%90%E1%83%9C%E1%83%AE%E1%83%9B%E1%83%94%E1%83%91%E1%83%98.)
^ka-Q0610-answer

**ka-Q0611** — ტომი ნამდვილად არ სთხოვს, რომ მარია ის გააკეთოს.

Tom definitely won't ask Mary to do that.

Why: Content and relative linking. [[Georgian#^ka-Q0611|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%98%20%E1%83%9C%E1%83%90%E1%83%9B%E1%83%93%E1%83%95%E1%83%98%E1%83%9A%E1%83%90%E1%83%93%20%E1%83%90%E1%83%A0%20%E1%83%A1%E1%83%97%E1%83%AE%E1%83%9D%E1%83%95%E1%83%A1%2C%20%E1%83%A0%E1%83%9D%E1%83%9B%20%E1%83%9B%E1%83%90%E1%83%A0%E1%83%98%E1%83%90%20%E1%83%98%E1%83%A1%20%E1%83%92%E1%83%90%E1%83%90%E1%83%99%E1%83%94%E1%83%97%E1%83%9D%E1%83%A1.)
^ka-Q0611-answer

**ka-Q0612** — ტომი ნამდვილად არ სთხოვს, რომ მარია ის გააკეთოს.

Tom definitely won't ask Mary to do that.

რომ links many content and dependent clauses. Its English translation depends on the construction, and the dependent verb form may reflect the speaker’s attitude or the governing predicate.

Why: Content and relative linking. [[Georgian#^ka-Q0612|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%98%20%E1%83%9C%E1%83%90%E1%83%9B%E1%83%93%E1%83%95%E1%83%98%E1%83%9A%E1%83%90%E1%83%93%20%E1%83%90%E1%83%A0%20%E1%83%A1%E1%83%97%E1%83%AE%E1%83%9D%E1%83%95%E1%83%A1%2C%20%E1%83%A0%E1%83%9D%E1%83%9B%20%E1%83%9B%E1%83%90%E1%83%A0%E1%83%98%E1%83%90%20%E1%83%98%E1%83%A1%20%E1%83%92%E1%83%90%E1%83%90%E1%83%99%E1%83%94%E1%83%97%E1%83%9D%E1%83%A1.)
^ka-Q0612-answer

**ka-Q0613** — მარი გაოგნდა, როცა გაიგო, რომ ტომს თავის ბიძაშვილთან სექსი ჰქონდა.

Mary was shocked when she learned that Tom had had sex with his cousin.

Expected form: **რომ**

Why: Content and relative linking. [[Georgian#^ka-Q0613|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%90%E1%83%A0%E1%83%98%20%E1%83%92%E1%83%90%E1%83%9D%E1%83%92%E1%83%9C%E1%83%93%E1%83%90%2C%20%E1%83%A0%E1%83%9D%E1%83%AA%E1%83%90%20%E1%83%92%E1%83%90%E1%83%98%E1%83%92%E1%83%9D%2C%20%E1%83%A0%E1%83%9D%E1%83%9B%20%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%A1%20%E1%83%97%E1%83%90%E1%83%95%E1%83%98%E1%83%A1%20%E1%83%91%E1%83%98%E1%83%AB%E1%83%90%E1%83%A8%E1%83%95%E1%83%98%E1%83%9A%E1%83%97%E1%83%90%E1%83%9C%20%E1%83%A1%E1%83%94%E1%83%A5%E1%83%A1%E1%83%98%20%E1%83%B0%E1%83%A5%E1%83%9D%E1%83%9C%E1%83%93%E1%83%90.)
^ka-Q0613-answer

**ka-Q0614** — მარი გაოგნდა, როცა გაიგო, რომ ტომს თავის ბიძაშვილთან სექსი ჰქონდა.

Mary was shocked when she learned that Tom had had sex with his cousin.

Expected form: **რომ**

Why: Content and relative linking. [[Georgian#^ka-Q0614|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%90%E1%83%A0%E1%83%98%20%E1%83%92%E1%83%90%E1%83%9D%E1%83%92%E1%83%9C%E1%83%93%E1%83%90%2C%20%E1%83%A0%E1%83%9D%E1%83%AA%E1%83%90%20%E1%83%92%E1%83%90%E1%83%98%E1%83%92%E1%83%9D%2C%20%E1%83%A0%E1%83%9D%E1%83%9B%20%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%A1%20%E1%83%97%E1%83%90%E1%83%95%E1%83%98%E1%83%A1%20%E1%83%91%E1%83%98%E1%83%AB%E1%83%90%E1%83%A8%E1%83%95%E1%83%98%E1%83%9A%E1%83%97%E1%83%90%E1%83%9C%20%E1%83%A1%E1%83%94%E1%83%A5%E1%83%A1%E1%83%98%20%E1%83%B0%E1%83%A5%E1%83%9D%E1%83%9C%E1%83%93%E1%83%90.)
^ka-Q0614-answer

**ka-Q0615** — თუ იჩქარებ, დაეწევი.

If you hurry, you will overtake him.

Expected form: **თუ**

Why: Conditions. [[Georgian#^ka-Q0615|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%97%E1%83%A3%20%E1%83%98%E1%83%A9%E1%83%A5%E1%83%90%E1%83%A0%E1%83%94%E1%83%91%2C%20%E1%83%93%E1%83%90%E1%83%94%E1%83%AC%E1%83%94%E1%83%95%E1%83%98.)
^ka-Q0615-answer

**ka-Q0616** — თუ იჩქარებ, დაეწევი.

If you hurry, you will overtake him.

Why: Conditions. [[Georgian#^ka-Q0616|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%97%E1%83%A3%20%E1%83%98%E1%83%A9%E1%83%A5%E1%83%90%E1%83%A0%E1%83%94%E1%83%91%2C%20%E1%83%93%E1%83%90%E1%83%94%E1%83%AC%E1%83%94%E1%83%95%E1%83%98.)
^ka-Q0616-answer

**ka-Q0617** — კაცი ხარ თუ ქალი?

Are you a man or a woman?

Why: Conditions. [[Georgian#^ka-Q0617|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%99%E1%83%90%E1%83%AA%E1%83%98%20%E1%83%AE%E1%83%90%E1%83%A0%20%E1%83%97%E1%83%A3%20%E1%83%A5%E1%83%90%E1%83%9A%E1%83%98%3F)
^ka-Q0617-answer

**ka-Q0618** — კაცი ხარ თუ ქალი?

Are you a man or a woman?

თუ introduces many if/whether contexts. Verb screeve and surrounding discourse determine the temporal/hypothetical relation. Do not treat the connector alone as a full conditional rule.

Why: Conditions. [[Georgian#^ka-Q0618|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%99%E1%83%90%E1%83%AA%E1%83%98%20%E1%83%AE%E1%83%90%E1%83%A0%20%E1%83%97%E1%83%A3%20%E1%83%A5%E1%83%90%E1%83%9A%E1%83%98%3F)
^ka-Q0618-answer

**ka-Q0619** — კომპიუტერს თუ გამოიყენებ ინფორმაციის შენახვას შეძლებ.

If you use a computer, you can retain information.

Expected form: **თუ**

Why: Conditions. [[Georgian#^ka-Q0619|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%99%E1%83%9D%E1%83%9B%E1%83%9E%E1%83%98%E1%83%A3%E1%83%A2%E1%83%94%E1%83%A0%E1%83%A1%20%E1%83%97%E1%83%A3%20%E1%83%92%E1%83%90%E1%83%9B%E1%83%9D%E1%83%98%E1%83%A7%E1%83%94%E1%83%9C%E1%83%94%E1%83%91%20%E1%83%98%E1%83%9C%E1%83%A4%E1%83%9D%E1%83%A0%E1%83%9B%E1%83%90%E1%83%AA%E1%83%98%E1%83%98%E1%83%A1%20%E1%83%A8%E1%83%94%E1%83%9C%E1%83%90%E1%83%AE%E1%83%95%E1%83%90%E1%83%A1%20%E1%83%A8%E1%83%94%E1%83%AB%E1%83%9A%E1%83%94%E1%83%91.)
^ka-Q0619-answer

**ka-Q0620** — კომპიუტერს თუ გამოიყენებ ინფორმაციის შენახვას შეძლებ.

If you use a computer, you can retain information.

Expected form: **თუ**

Why: Conditions. [[Georgian#^ka-Q0620|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%99%E1%83%9D%E1%83%9B%E1%83%9E%E1%83%98%E1%83%A3%E1%83%A2%E1%83%94%E1%83%A0%E1%83%A1%20%E1%83%97%E1%83%A3%20%E1%83%92%E1%83%90%E1%83%9B%E1%83%9D%E1%83%98%E1%83%A7%E1%83%94%E1%83%9C%E1%83%94%E1%83%91%20%E1%83%98%E1%83%9C%E1%83%A4%E1%83%9D%E1%83%A0%E1%83%9B%E1%83%90%E1%83%AA%E1%83%98%E1%83%98%E1%83%A1%20%E1%83%A8%E1%83%94%E1%83%9C%E1%83%90%E1%83%AE%E1%83%95%E1%83%90%E1%83%A1%20%E1%83%A8%E1%83%94%E1%83%AB%E1%83%9A%E1%83%94%E1%83%91.)
^ka-Q0620-answer

**ka-Q0621** — თქვენ მასწავლებელი ხართ თუ მოსწავლე?

Are you a teacher or a student?

Expected form: **თუ**

Why: Conditions. [[Georgian#^ka-Q0621|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%97%E1%83%A5%E1%83%95%E1%83%94%E1%83%9C%20%E1%83%9B%E1%83%90%E1%83%A1%E1%83%AC%E1%83%90%E1%83%95%E1%83%9A%E1%83%94%E1%83%91%E1%83%94%E1%83%9A%E1%83%98%20%E1%83%AE%E1%83%90%E1%83%A0%E1%83%97%20%E1%83%97%E1%83%A3%20%E1%83%9B%E1%83%9D%E1%83%A1%E1%83%AC%E1%83%90%E1%83%95%E1%83%9A%E1%83%94%3F)
^ka-Q0621-answer

**ka-Q0622** — თქვენ მასწავლებელი ხართ თუ მოსწავლე?

Are you a teacher or a student?

Why: Conditions. [[Georgian#^ka-Q0622|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%97%E1%83%A5%E1%83%95%E1%83%94%E1%83%9C%20%E1%83%9B%E1%83%90%E1%83%A1%E1%83%AC%E1%83%90%E1%83%95%E1%83%9A%E1%83%94%E1%83%91%E1%83%94%E1%83%9A%E1%83%98%20%E1%83%AE%E1%83%90%E1%83%A0%E1%83%97%20%E1%83%97%E1%83%A3%20%E1%83%9B%E1%83%9D%E1%83%A1%E1%83%AC%E1%83%90%E1%83%95%E1%83%9A%E1%83%94%3F)
^ka-Q0622-answer

**ka-Q0623** — თქვენ მასწავლებელი ხართ თუ სტუდენტი?

Are you a teacher or a student?

Why: Conditions. [[Georgian#^ka-Q0623|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%97%E1%83%A5%E1%83%95%E1%83%94%E1%83%9C%20%E1%83%9B%E1%83%90%E1%83%A1%E1%83%AC%E1%83%90%E1%83%95%E1%83%9A%E1%83%94%E1%83%91%E1%83%94%E1%83%9A%E1%83%98%20%E1%83%AE%E1%83%90%E1%83%A0%E1%83%97%20%E1%83%97%E1%83%A3%20%E1%83%A1%E1%83%A2%E1%83%A3%E1%83%93%E1%83%94%E1%83%9C%E1%83%A2%E1%83%98%3F)
^ka-Q0623-answer

**ka-Q0624** — თქვენ მასწავლებელი ხართ თუ სტუდენტი?

Are you a teacher or a student?

თუ introduces many if/whether contexts. Verb screeve and surrounding discourse determine the temporal/hypothetical relation. Do not treat the connector alone as a full conditional rule.

Why: Conditions. [[Georgian#^ka-Q0624|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%97%E1%83%A5%E1%83%95%E1%83%94%E1%83%9C%20%E1%83%9B%E1%83%90%E1%83%A1%E1%83%AC%E1%83%90%E1%83%95%E1%83%9A%E1%83%94%E1%83%91%E1%83%94%E1%83%9A%E1%83%98%20%E1%83%AE%E1%83%90%E1%83%A0%E1%83%97%20%E1%83%97%E1%83%A3%20%E1%83%A1%E1%83%A2%E1%83%A3%E1%83%93%E1%83%94%E1%83%9C%E1%83%A2%E1%83%98%3F)
^ka-Q0624-answer

**ka-Q0625** — ვინ ჭამს მეტს, შენ თუ ტომი?

Who eats more, you or Tom?

Expected form: **თუ**

Why: Conditions. [[Georgian#^ka-Q0625|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%95%E1%83%98%E1%83%9C%20%E1%83%AD%E1%83%90%E1%83%9B%E1%83%A1%20%E1%83%9B%E1%83%94%E1%83%A2%E1%83%A1%2C%20%E1%83%A8%E1%83%94%E1%83%9C%20%E1%83%97%E1%83%A3%20%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%98%3F)
^ka-Q0625-answer

**ka-Q0626** — ვინ ჭამს მეტს, შენ თუ ტომი?

Who eats more, you or Tom?

Expected form: **თუ**

Why: Conditions. [[Georgian#^ka-Q0626|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%95%E1%83%98%E1%83%9C%20%E1%83%AD%E1%83%90%E1%83%9B%E1%83%A1%20%E1%83%9B%E1%83%94%E1%83%A2%E1%83%A1%2C%20%E1%83%A8%E1%83%94%E1%83%9C%20%E1%83%97%E1%83%A3%20%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%98%3F)
^ka-Q0626-answer

**ka-Q0627** — ამერიკელი ხარ თუ ფრანგი?

Are you American or French?

Expected form: **თუ**

Why: Conditions. [[Georgian#^ka-Q0627|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%9B%E1%83%94%E1%83%A0%E1%83%98%E1%83%99%E1%83%94%E1%83%9A%E1%83%98%20%E1%83%AE%E1%83%90%E1%83%A0%20%E1%83%97%E1%83%A3%20%E1%83%A4%E1%83%A0%E1%83%90%E1%83%9C%E1%83%92%E1%83%98%3F)
^ka-Q0627-answer

**ka-Q0628** — ამერიკელი ხარ თუ ფრანგი?

Are you American or French?

Why: Conditions. [[Georgian#^ka-Q0628|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%9B%E1%83%94%E1%83%A0%E1%83%98%E1%83%99%E1%83%94%E1%83%9A%E1%83%98%20%E1%83%AE%E1%83%90%E1%83%A0%20%E1%83%97%E1%83%A3%20%E1%83%A4%E1%83%A0%E1%83%90%E1%83%9C%E1%83%92%E1%83%98%3F)
^ka-Q0628-answer

**ka-Q0629** — დილაობით მხოლოდ ტოსტს და ყავას მივირთმევ.

I only have toast and coffee in the morning.

Why: Coordination and contrast. [[Georgian#^ka-Q0629|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%93%E1%83%98%E1%83%9A%E1%83%90%E1%83%9D%E1%83%91%E1%83%98%E1%83%97%20%E1%83%9B%E1%83%AE%E1%83%9D%E1%83%9A%E1%83%9D%E1%83%93%20%E1%83%A2%E1%83%9D%E1%83%A1%E1%83%A2%E1%83%A1%20%E1%83%93%E1%83%90%20%E1%83%A7%E1%83%90%E1%83%95%E1%83%90%E1%83%A1%20%E1%83%9B%E1%83%98%E1%83%95%E1%83%98%E1%83%A0%E1%83%97%E1%83%9B%E1%83%94%E1%83%95.)
^ka-Q0629-answer

**ka-Q0630** — დილაობით მხოლოდ ტოსტს და ყავას მივირთმევ.

I only have toast and coffee in the morning.

და joins, მაგრამ contrasts, and ან gives an alternative. Keep like structures parallel when coordinating. Their meaning does not replace the case and verb rules inside each clause.

Why: Coordination and contrast. [[Georgian#^ka-Q0630|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%93%E1%83%98%E1%83%9A%E1%83%90%E1%83%9D%E1%83%91%E1%83%98%E1%83%97%20%E1%83%9B%E1%83%AE%E1%83%9D%E1%83%9A%E1%83%9D%E1%83%93%20%E1%83%A2%E1%83%9D%E1%83%A1%E1%83%A2%E1%83%A1%20%E1%83%93%E1%83%90%20%E1%83%A7%E1%83%90%E1%83%95%E1%83%90%E1%83%A1%20%E1%83%9B%E1%83%98%E1%83%95%E1%83%98%E1%83%A0%E1%83%97%E1%83%9B%E1%83%94%E1%83%95.)
^ka-Q0630-answer

**ka-Q0631** — წავალთ თქვენთან ერთად.

We'll go with you.

Expected form: **ან**

Why: Coordination and contrast. [[Georgian#^ka-Q0631|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%AC%E1%83%90%E1%83%95%E1%83%90%E1%83%9A%E1%83%97%20%E1%83%97%E1%83%A5%E1%83%95%E1%83%94%E1%83%9C%E1%83%97%E1%83%90%E1%83%9C%20%E1%83%94%E1%83%A0%E1%83%97%E1%83%90%E1%83%93.)
^ka-Q0631-answer

**ka-Q0632** — წავალთ თქვენთან ერთად.

We'll go with you.

Expected form: **ან**

Why: Coordination and contrast. [[Georgian#^ka-Q0632|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%AC%E1%83%90%E1%83%95%E1%83%90%E1%83%9A%E1%83%97%20%E1%83%97%E1%83%A5%E1%83%95%E1%83%94%E1%83%9C%E1%83%97%E1%83%90%E1%83%9C%20%E1%83%94%E1%83%A0%E1%83%97%E1%83%90%E1%83%93.)
^ka-Q0632-answer

**ka-Q0633** — ეს ადგილი ძალიან სასიამოვნოა.

This place is very pleasant.

Expected form: **ან**

Why: Coordination and contrast. [[Georgian#^ka-Q0633|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%94%E1%83%A1%20%E1%83%90%E1%83%93%E1%83%92%E1%83%98%E1%83%9A%E1%83%98%20%E1%83%AB%E1%83%90%E1%83%9A%E1%83%98%E1%83%90%E1%83%9C%20%E1%83%A1%E1%83%90%E1%83%A1%E1%83%98%E1%83%90%E1%83%9B%E1%83%9D%E1%83%95%E1%83%9C%E1%83%9D%E1%83%90.)
^ka-Q0633-answer

**ka-Q0634** — ეს ადგილი ძალიან სასიამოვნოა.

This place is very pleasant.

Why: Coordination and contrast. [[Georgian#^ka-Q0634|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%94%E1%83%A1%20%E1%83%90%E1%83%93%E1%83%92%E1%83%98%E1%83%9A%E1%83%98%20%E1%83%AB%E1%83%90%E1%83%9A%E1%83%98%E1%83%90%E1%83%9C%20%E1%83%A1%E1%83%90%E1%83%A1%E1%83%98%E1%83%90%E1%83%9B%E1%83%9D%E1%83%95%E1%83%9C%E1%83%9D%E1%83%90.)
^ka-Q0634-answer

**ka-Q0635** — წავალთ შენთან ერთად.

We'll go with you.

Why: Coordination and contrast. [[Georgian#^ka-Q0635|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%AC%E1%83%90%E1%83%95%E1%83%90%E1%83%9A%E1%83%97%20%E1%83%A8%E1%83%94%E1%83%9C%E1%83%97%E1%83%90%E1%83%9C%20%E1%83%94%E1%83%A0%E1%83%97%E1%83%90%E1%83%93.)
^ka-Q0635-answer

**ka-Q0636** — წავალთ შენთან ერთად.

We'll go with you.

და joins, მაგრამ contrasts, and ან gives an alternative. Keep like structures parallel when coordinating. Their meaning does not replace the case and verb rules inside each clause.

Why: Coordination and contrast. [[Georgian#^ka-Q0636|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%AC%E1%83%90%E1%83%95%E1%83%90%E1%83%9A%E1%83%97%20%E1%83%A8%E1%83%94%E1%83%9C%E1%83%97%E1%83%90%E1%83%9C%20%E1%83%94%E1%83%A0%E1%83%97%E1%83%90%E1%83%93.)
^ka-Q0636-answer

**ka-Q0637** — მე მოგიტან შენ.

I'll bring you.

Expected form: **ან**

Why: Coordination and contrast. [[Georgian#^ka-Q0637|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%9B%E1%83%9D%E1%83%92%E1%83%98%E1%83%A2%E1%83%90%E1%83%9C%20%E1%83%A8%E1%83%94%E1%83%9C.)
^ka-Q0637-answer

**ka-Q0638** — მე მოგიტან შენ.

I'll bring you.

Expected form: **ან**

Why: Coordination and contrast. [[Georgian#^ka-Q0638|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%9B%E1%83%9D%E1%83%92%E1%83%98%E1%83%A2%E1%83%90%E1%83%9C%20%E1%83%A8%E1%83%94%E1%83%9C.)
^ka-Q0638-answer

**ka-Q0639** — ეს მანქანა ძალიან სწრაფია.

That car is very fast.

Expected form: **ან**

Why: Coordination and contrast. [[Georgian#^ka-Q0639|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%94%E1%83%A1%20%E1%83%9B%E1%83%90%E1%83%9C%E1%83%A5%E1%83%90%E1%83%9C%E1%83%90%20%E1%83%AB%E1%83%90%E1%83%9A%E1%83%98%E1%83%90%E1%83%9C%20%E1%83%A1%E1%83%AC%E1%83%A0%E1%83%90%E1%83%A4%E1%83%98%E1%83%90.)
^ka-Q0639-answer

**ka-Q0640** — ეს მანქანა ძალიან სწრაფია.

That car is very fast.

Why: Coordination and contrast. [[Georgian#^ka-Q0640|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%94%E1%83%A1%20%E1%83%9B%E1%83%90%E1%83%9C%E1%83%A5%E1%83%90%E1%83%9C%E1%83%90%20%E1%83%AB%E1%83%90%E1%83%9A%E1%83%98%E1%83%90%E1%83%9C%20%E1%83%A1%E1%83%AC%E1%83%A0%E1%83%90%E1%83%A4%E1%83%98%E1%83%90.)
^ka-Q0640-answer

**ka-Q0641** — ამ წიგნმა ძალიან დამაინტერესა.

I found the book very interesting.

Why: Coordination and contrast. [[Georgian#^ka-Q0641|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%9B%20%E1%83%AC%E1%83%98%E1%83%92%E1%83%9C%E1%83%9B%E1%83%90%20%E1%83%AB%E1%83%90%E1%83%9A%E1%83%98%E1%83%90%E1%83%9C%20%E1%83%93%E1%83%90%E1%83%9B%E1%83%90%E1%83%98%E1%83%9C%E1%83%A2%E1%83%94%E1%83%A0%E1%83%94%E1%83%A1%E1%83%90.)
^ka-Q0641-answer

**ka-Q0642** — ამ წიგნმა ძალიან დამაინტერესა.

I found the book very interesting.

და joins, მაგრამ contrasts, and ან gives an alternative. Keep like structures parallel when coordinating. Their meaning does not replace the case and verb rules inside each clause.

Why: Coordination and contrast. [[Georgian#^ka-Q0642|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%9B%20%E1%83%AC%E1%83%98%E1%83%92%E1%83%9C%E1%83%9B%E1%83%90%20%E1%83%AB%E1%83%90%E1%83%9A%E1%83%98%E1%83%90%E1%83%9C%20%E1%83%93%E1%83%90%E1%83%9B%E1%83%90%E1%83%98%E1%83%9C%E1%83%A2%E1%83%94%E1%83%A0%E1%83%94%E1%83%A1%E1%83%90.)
^ka-Q0642-answer

**ka-Q0643** — ახლა, როცა ერთნაირსქესიანთა ქორწინება ლეგალურია, ერთი ნაბიჯით ახლოს ვარ ჩემს თავთან დასაქორწინებლად.

Now that same-sex marriage is legal, I'm one step closer to marrying myself.

Expected form: **ან**

Why: Coordination and contrast. [[Georgian#^ka-Q0643|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%AE%E1%83%9A%E1%83%90%2C%20%E1%83%A0%E1%83%9D%E1%83%AA%E1%83%90%20%E1%83%94%E1%83%A0%E1%83%97%E1%83%9C%E1%83%90%E1%83%98%E1%83%A0%E1%83%A1%E1%83%A5%E1%83%94%E1%83%A1%E1%83%98%E1%83%90%E1%83%9C%E1%83%97%E1%83%90%20%E1%83%A5%E1%83%9D%E1%83%A0%E1%83%AC%E1%83%98%E1%83%9C%E1%83%94%E1%83%91%E1%83%90%20%E1%83%9A%E1%83%94%E1%83%92%E1%83%90%E1%83%9A%E1%83%A3%E1%83%A0%E1%83%98%E1%83%90%2C%20%E1%83%94%E1%83%A0%E1%83%97%E1%83%98%20%E1%83%9C%E1%83%90%E1%83%91%E1%83%98%E1%83%AF%E1%83%98%E1%83%97%20%E1%83%90%E1%83%AE%E1%83%9A%E1%83%9D%E1%83%A1%20%E1%83%95%E1%83%90%E1%83%A0%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%A1%20%E1%83%97%E1%83%90%E1%83%95%E1%83%97%E1%83%90%E1%83%9C%20%E1%83%93%E1%83%90%E1%83%A1%E1%83%90%E1%83%A5%E1%83%9D%E1%83%A0%E1%83%AC%E1%83%98%E1%83%9C%E1%83%94%E1%83%91%E1%83%9A%E1%83%90%E1%83%93.)
^ka-Q0643-answer

**ka-Q0644** — ახლა, როცა ერთნაირსქესიანთა ქორწინება ლეგალურია, ერთი ნაბიჯით ახლოს ვარ ჩემს თავთან დასაქორწინებლად.

Now that same-sex marriage is legal, I'm one step closer to marrying myself.

Expected form: **ან**

Why: Coordination and contrast. [[Georgian#^ka-Q0644|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%AE%E1%83%9A%E1%83%90%2C%20%E1%83%A0%E1%83%9D%E1%83%AA%E1%83%90%20%E1%83%94%E1%83%A0%E1%83%97%E1%83%9C%E1%83%90%E1%83%98%E1%83%A0%E1%83%A1%E1%83%A5%E1%83%94%E1%83%A1%E1%83%98%E1%83%90%E1%83%9C%E1%83%97%E1%83%90%20%E1%83%A5%E1%83%9D%E1%83%A0%E1%83%AC%E1%83%98%E1%83%9C%E1%83%94%E1%83%91%E1%83%90%20%E1%83%9A%E1%83%94%E1%83%92%E1%83%90%E1%83%9A%E1%83%A3%E1%83%A0%E1%83%98%E1%83%90%2C%20%E1%83%94%E1%83%A0%E1%83%97%E1%83%98%20%E1%83%9C%E1%83%90%E1%83%91%E1%83%98%E1%83%AF%E1%83%98%E1%83%97%20%E1%83%90%E1%83%AE%E1%83%9A%E1%83%9D%E1%83%A1%20%E1%83%95%E1%83%90%E1%83%A0%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%A1%20%E1%83%97%E1%83%90%E1%83%95%E1%83%97%E1%83%90%E1%83%9C%20%E1%83%93%E1%83%90%E1%83%A1%E1%83%90%E1%83%A5%E1%83%9D%E1%83%A0%E1%83%AC%E1%83%98%E1%83%9C%E1%83%94%E1%83%91%E1%83%9A%E1%83%90%E1%83%93.)
^ka-Q0644-answer

**ka-Q0645** — ძალიან დაბალი ხარ.

You're very short.

Expected form: **ან**

Why: Coordination and contrast. [[Georgian#^ka-Q0645|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%AB%E1%83%90%E1%83%9A%E1%83%98%E1%83%90%E1%83%9C%20%E1%83%93%E1%83%90%E1%83%91%E1%83%90%E1%83%9A%E1%83%98%20%E1%83%AE%E1%83%90%E1%83%A0.)
^ka-Q0645-answer

**ka-Q0646** — ძალიან დაბალი ხარ.

You're very short.

Why: Coordination and contrast. [[Georgian#^ka-Q0646|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%AB%E1%83%90%E1%83%9A%E1%83%98%E1%83%90%E1%83%9C%20%E1%83%93%E1%83%90%E1%83%91%E1%83%90%E1%83%9A%E1%83%98%20%E1%83%AE%E1%83%90%E1%83%A0.)
^ka-Q0646-answer

**ka-Q0647** — ძალიან ბედნიერი ვარ საქართველოში.

I am very happy in Georgia.

Why: Coordination and contrast. [[Georgian#^ka-Q0647|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%AB%E1%83%90%E1%83%9A%E1%83%98%E1%83%90%E1%83%9C%20%E1%83%91%E1%83%94%E1%83%93%E1%83%9C%E1%83%98%E1%83%94%E1%83%A0%E1%83%98%20%E1%83%95%E1%83%90%E1%83%A0%20%E1%83%A1%E1%83%90%E1%83%A5%E1%83%90%E1%83%A0%E1%83%97%E1%83%95%E1%83%94%E1%83%9A%E1%83%9D%E1%83%A8%E1%83%98.)
^ka-Q0647-answer

**ka-Q0648** — ძალიან ბედნიერი ვარ საქართველოში.

I am very happy in Georgia.

და joins, მაგრამ contrasts, and ან gives an alternative. Keep like structures parallel when coordinating. Their meaning does not replace the case and verb rules inside each clause.

Why: Coordination and contrast. [[Georgian#^ka-Q0648|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%AB%E1%83%90%E1%83%9A%E1%83%98%E1%83%90%E1%83%9C%20%E1%83%91%E1%83%94%E1%83%93%E1%83%9C%E1%83%98%E1%83%94%E1%83%A0%E1%83%98%20%E1%83%95%E1%83%90%E1%83%A0%20%E1%83%A1%E1%83%90%E1%83%A5%E1%83%90%E1%83%A0%E1%83%97%E1%83%95%E1%83%94%E1%83%9A%E1%83%9D%E1%83%A8%E1%83%98.)
^ka-Q0648-answer

**ka-Q0649** — მე შენ ძალიან მიყვარხარ.

I love you a lot.

Expected form: **ან**

Why: Coordination and contrast. [[Georgian#^ka-Q0649|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%A8%E1%83%94%E1%83%9C%20%E1%83%AB%E1%83%90%E1%83%9A%E1%83%98%E1%83%90%E1%83%9C%20%E1%83%9B%E1%83%98%E1%83%A7%E1%83%95%E1%83%90%E1%83%A0%E1%83%AE%E1%83%90%E1%83%A0.)
^ka-Q0649-answer

**ka-Q0650** — მე შენ ძალიან მიყვარხარ.

I love you a lot.

Expected form: **ან**

Why: Coordination and contrast. [[Georgian#^ka-Q0650|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%A8%E1%83%94%E1%83%9C%20%E1%83%AB%E1%83%90%E1%83%9A%E1%83%98%E1%83%90%E1%83%9C%20%E1%83%9B%E1%83%98%E1%83%A7%E1%83%95%E1%83%90%E1%83%A0%E1%83%AE%E1%83%90%E1%83%A0.)
^ka-Q0650-answer


### Answers 651–700

**ka-Q0651** — ამ ინფორმაციის საიმედოობაში ეჭვი არ მეპარება, რადგან ის სანდო ადამიანისგან მოდის.

I don't doubt the reliability of his information because it comes from a trustworthy person.

Expected form: **ან**

Why: Coordination and contrast. [[Georgian#^ka-Q0651|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%9B%20%E1%83%98%E1%83%9C%E1%83%A4%E1%83%9D%E1%83%A0%E1%83%9B%E1%83%90%E1%83%AA%E1%83%98%E1%83%98%E1%83%A1%20%E1%83%A1%E1%83%90%E1%83%98%E1%83%9B%E1%83%94%E1%83%93%E1%83%9D%E1%83%9D%E1%83%91%E1%83%90%E1%83%A8%E1%83%98%20%E1%83%94%E1%83%AD%E1%83%95%E1%83%98%20%E1%83%90%E1%83%A0%20%E1%83%9B%E1%83%94%E1%83%9E%E1%83%90%E1%83%A0%E1%83%94%E1%83%91%E1%83%90%2C%20%E1%83%A0%E1%83%90%E1%83%93%E1%83%92%E1%83%90%E1%83%9C%20%E1%83%98%E1%83%A1%20%E1%83%A1%E1%83%90%E1%83%9C%E1%83%93%E1%83%9D%20%E1%83%90%E1%83%93%E1%83%90%E1%83%9B%E1%83%98%E1%83%90%E1%83%9C%E1%83%98%E1%83%A1%E1%83%92%E1%83%90%E1%83%9C%20%E1%83%9B%E1%83%9D%E1%83%93%E1%83%98%E1%83%A1.)
^ka-Q0651-answer

**ka-Q0652** — ამ ინფორმაციის საიმედოობაში ეჭვი არ მეპარება, რადგან ის სანდო ადამიანისგან მოდის.

I don't doubt the reliability of his information because it comes from a trustworthy person.

Why: Coordination and contrast. [[Georgian#^ka-Q0652|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%9B%20%E1%83%98%E1%83%9C%E1%83%A4%E1%83%9D%E1%83%A0%E1%83%9B%E1%83%90%E1%83%AA%E1%83%98%E1%83%98%E1%83%A1%20%E1%83%A1%E1%83%90%E1%83%98%E1%83%9B%E1%83%94%E1%83%93%E1%83%9D%E1%83%9D%E1%83%91%E1%83%90%E1%83%A8%E1%83%98%20%E1%83%94%E1%83%AD%E1%83%95%E1%83%98%20%E1%83%90%E1%83%A0%20%E1%83%9B%E1%83%94%E1%83%9E%E1%83%90%E1%83%A0%E1%83%94%E1%83%91%E1%83%90%2C%20%E1%83%A0%E1%83%90%E1%83%93%E1%83%92%E1%83%90%E1%83%9C%20%E1%83%98%E1%83%A1%20%E1%83%A1%E1%83%90%E1%83%9C%E1%83%93%E1%83%9D%20%E1%83%90%E1%83%93%E1%83%90%E1%83%9B%E1%83%98%E1%83%90%E1%83%9C%E1%83%98%E1%83%A1%E1%83%92%E1%83%90%E1%83%9C%20%E1%83%9B%E1%83%9D%E1%83%93%E1%83%98%E1%83%A1.)
^ka-Q0652-answer

**ka-Q0653** — ისინი არიან ტომის.

They're Tom's.

Why: Coordination and contrast. [[Georgian#^ka-Q0653|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%98%E1%83%A1%E1%83%98%E1%83%9C%E1%83%98%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%90%E1%83%9C%20%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%98%E1%83%A1.)
^ka-Q0653-answer

**ka-Q0654** — ისინი არიან ტომის.

They're Tom's.

და joins, მაგრამ contrasts, and ან gives an alternative. Keep like structures parallel when coordinating. Their meaning does not replace the case and verb rules inside each clause.

Why: Coordination and contrast. [[Georgian#^ka-Q0654|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%98%E1%83%A1%E1%83%98%E1%83%9C%E1%83%98%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%90%E1%83%9C%20%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%98%E1%83%A1.)
^ka-Q0654-answer

**ka-Q0655** — ჩემს მეგობარ გოგონასთან ანალური სექსის შემდეგ, როგორც წესი, კარგი შხაპის მიღება გვჭირდება ხოლმე.

After having anal sex with my girlfriend, we usually need to have a good wash.

Expected form: **ან**

Why: Coordination and contrast. [[Georgian#^ka-Q0655|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A9%E1%83%94%E1%83%9B%E1%83%A1%20%E1%83%9B%E1%83%94%E1%83%92%E1%83%9D%E1%83%91%E1%83%90%E1%83%A0%20%E1%83%92%E1%83%9D%E1%83%92%E1%83%9D%E1%83%9C%E1%83%90%E1%83%A1%E1%83%97%E1%83%90%E1%83%9C%20%E1%83%90%E1%83%9C%E1%83%90%E1%83%9A%E1%83%A3%E1%83%A0%E1%83%98%20%E1%83%A1%E1%83%94%E1%83%A5%E1%83%A1%E1%83%98%E1%83%A1%20%E1%83%A8%E1%83%94%E1%83%9B%E1%83%93%E1%83%94%E1%83%92%2C%20%E1%83%A0%E1%83%9D%E1%83%92%E1%83%9D%E1%83%A0%E1%83%AA%20%E1%83%AC%E1%83%94%E1%83%A1%E1%83%98%2C%20%E1%83%99%E1%83%90%E1%83%A0%E1%83%92%E1%83%98%20%E1%83%A8%E1%83%AE%E1%83%90%E1%83%9E%E1%83%98%E1%83%A1%20%E1%83%9B%E1%83%98%E1%83%A6%E1%83%94%E1%83%91%E1%83%90%20%E1%83%92%E1%83%95%E1%83%AD%E1%83%98%E1%83%A0%E1%83%93%E1%83%94%E1%83%91%E1%83%90%20%E1%83%AE%E1%83%9D%E1%83%9A%E1%83%9B%E1%83%94.)
^ka-Q0655-answer

**ka-Q0656** — ჩემს მეგობარ გოგონასთან ანალური სექსის შემდეგ, როგორც წესი, კარგი შხაპის მიღება გვჭირდება ხოლმე.

After having anal sex with my girlfriend, we usually need to have a good wash.

Expected form: **ან**

Why: Coordination and contrast. [[Georgian#^ka-Q0656|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A9%E1%83%94%E1%83%9B%E1%83%A1%20%E1%83%9B%E1%83%94%E1%83%92%E1%83%9D%E1%83%91%E1%83%90%E1%83%A0%20%E1%83%92%E1%83%9D%E1%83%92%E1%83%9D%E1%83%9C%E1%83%90%E1%83%A1%E1%83%97%E1%83%90%E1%83%9C%20%E1%83%90%E1%83%9C%E1%83%90%E1%83%9A%E1%83%A3%E1%83%A0%E1%83%98%20%E1%83%A1%E1%83%94%E1%83%A5%E1%83%A1%E1%83%98%E1%83%A1%20%E1%83%A8%E1%83%94%E1%83%9B%E1%83%93%E1%83%94%E1%83%92%2C%20%E1%83%A0%E1%83%9D%E1%83%92%E1%83%9D%E1%83%A0%E1%83%AA%20%E1%83%AC%E1%83%94%E1%83%A1%E1%83%98%2C%20%E1%83%99%E1%83%90%E1%83%A0%E1%83%92%E1%83%98%20%E1%83%A8%E1%83%AE%E1%83%90%E1%83%9E%E1%83%98%E1%83%A1%20%E1%83%9B%E1%83%98%E1%83%A6%E1%83%94%E1%83%91%E1%83%90%20%E1%83%92%E1%83%95%E1%83%AD%E1%83%98%E1%83%A0%E1%83%93%E1%83%94%E1%83%91%E1%83%90%20%E1%83%AE%E1%83%9D%E1%83%9A%E1%83%9B%E1%83%94.)
^ka-Q0656-answer

**ka-Q0657** — ერთი ნაბიჯი და მკვდარი კაცი ხარ.

One more step, and you'll be a dead man.

Expected form: **და**

Why: Coordination and contrast. [[Georgian#^ka-Q0657|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%94%E1%83%A0%E1%83%97%E1%83%98%20%E1%83%9C%E1%83%90%E1%83%91%E1%83%98%E1%83%AF%E1%83%98%20%E1%83%93%E1%83%90%20%E1%83%9B%E1%83%99%E1%83%95%E1%83%93%E1%83%90%E1%83%A0%E1%83%98%20%E1%83%99%E1%83%90%E1%83%AA%E1%83%98%20%E1%83%AE%E1%83%90%E1%83%A0.)
^ka-Q0657-answer

**ka-Q0658** — ერთი ნაბიჯი და მკვდარი კაცი ხარ.

One more step, and you'll be a dead man.

Why: Coordination and contrast. [[Georgian#^ka-Q0658|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%94%E1%83%A0%E1%83%97%E1%83%98%20%E1%83%9C%E1%83%90%E1%83%91%E1%83%98%E1%83%AF%E1%83%98%20%E1%83%93%E1%83%90%20%E1%83%9B%E1%83%99%E1%83%95%E1%83%93%E1%83%90%E1%83%A0%E1%83%98%20%E1%83%99%E1%83%90%E1%83%AA%E1%83%98%20%E1%83%AE%E1%83%90%E1%83%A0.)
^ka-Q0658-answer

**ka-Q0659** — არის ტომი უფრო ახალგაზრდა ვიდრე შენ?

Is Tom younger than you?

Why: Coordination and contrast. [[Georgian#^ka-Q0659|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%98%20%E1%83%A3%E1%83%A4%E1%83%A0%E1%83%9D%20%E1%83%90%E1%83%AE%E1%83%90%E1%83%9A%E1%83%92%E1%83%90%E1%83%96%E1%83%A0%E1%83%93%E1%83%90%20%E1%83%95%E1%83%98%E1%83%93%E1%83%A0%E1%83%94%20%E1%83%A8%E1%83%94%E1%83%9C%3F)
^ka-Q0659-answer

**ka-Q0660** — არის ტომი უფრო ახალგაზრდა ვიდრე შენ?

Is Tom younger than you?

და joins, მაგრამ contrasts, and ან gives an alternative. Keep like structures parallel when coordinating. Their meaning does not replace the case and verb rules inside each clause.

Why: Coordination and contrast. [[Georgian#^ka-Q0660|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%98%20%E1%83%A3%E1%83%A4%E1%83%A0%E1%83%9D%20%E1%83%90%E1%83%AE%E1%83%90%E1%83%9A%E1%83%92%E1%83%90%E1%83%96%E1%83%A0%E1%83%93%E1%83%90%20%E1%83%95%E1%83%98%E1%83%93%E1%83%A0%E1%83%94%20%E1%83%A8%E1%83%94%E1%83%9C%3F)
^ka-Q0660-answer

**ka-Q0661** — პოლიციამ დაუყოვნებლივი ქმედება მიიღო, აჯანყებასთან გასამკლავებლად.

The police took immediate action to deal with the riot.

Expected form: **ან**

Why: Coordination and contrast. [[Georgian#^ka-Q0661|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9E%E1%83%9D%E1%83%9A%E1%83%98%E1%83%AA%E1%83%98%E1%83%90%E1%83%9B%20%E1%83%93%E1%83%90%E1%83%A3%E1%83%A7%E1%83%9D%E1%83%95%E1%83%9C%E1%83%94%E1%83%91%E1%83%9A%E1%83%98%E1%83%95%E1%83%98%20%E1%83%A5%E1%83%9B%E1%83%94%E1%83%93%E1%83%94%E1%83%91%E1%83%90%20%E1%83%9B%E1%83%98%E1%83%98%E1%83%A6%E1%83%9D%2C%20%E1%83%90%E1%83%AF%E1%83%90%E1%83%9C%E1%83%A7%E1%83%94%E1%83%91%E1%83%90%E1%83%A1%E1%83%97%E1%83%90%E1%83%9C%20%E1%83%92%E1%83%90%E1%83%A1%E1%83%90%E1%83%9B%E1%83%99%E1%83%9A%E1%83%90%E1%83%95%E1%83%94%E1%83%91%E1%83%9A%E1%83%90%E1%83%93.)
^ka-Q0661-answer

**ka-Q0662** — პოლიციამ დაუყოვნებლივი ქმედება მიიღო, აჯანყებასთან გასამკლავებლად.

The police took immediate action to deal with the riot.

Expected form: **ან**

Why: Coordination and contrast. [[Georgian#^ka-Q0662|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9E%E1%83%9D%E1%83%9A%E1%83%98%E1%83%AA%E1%83%98%E1%83%90%E1%83%9B%20%E1%83%93%E1%83%90%E1%83%A3%E1%83%A7%E1%83%9D%E1%83%95%E1%83%9C%E1%83%94%E1%83%91%E1%83%9A%E1%83%98%E1%83%95%E1%83%98%20%E1%83%A5%E1%83%9B%E1%83%94%E1%83%93%E1%83%94%E1%83%91%E1%83%90%20%E1%83%9B%E1%83%98%E1%83%98%E1%83%A6%E1%83%9D%2C%20%E1%83%90%E1%83%AF%E1%83%90%E1%83%9C%E1%83%A7%E1%83%94%E1%83%91%E1%83%90%E1%83%A1%E1%83%97%E1%83%90%E1%83%9C%20%E1%83%92%E1%83%90%E1%83%A1%E1%83%90%E1%83%9B%E1%83%99%E1%83%9A%E1%83%90%E1%83%95%E1%83%94%E1%83%91%E1%83%9A%E1%83%90%E1%83%93.)
^ka-Q0662-answer

**ka-Q0663** — ის ლამაზია, მაგრამ საშიში.

She's pretty, but dangerous.

Expected form: **მაგრამ**

Why: Coordination and contrast. [[Georgian#^ka-Q0663|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%98%E1%83%A1%20%E1%83%9A%E1%83%90%E1%83%9B%E1%83%90%E1%83%96%E1%83%98%E1%83%90%2C%20%E1%83%9B%E1%83%90%E1%83%92%E1%83%A0%E1%83%90%E1%83%9B%20%E1%83%A1%E1%83%90%E1%83%A8%E1%83%98%E1%83%A8%E1%83%98.)
^ka-Q0663-answer

**ka-Q0664** — ის ლამაზია, მაგრამ საშიში.

She's pretty, but dangerous.

Why: Coordination and contrast. [[Georgian#^ka-Q0664|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%98%E1%83%A1%20%E1%83%9A%E1%83%90%E1%83%9B%E1%83%90%E1%83%96%E1%83%98%E1%83%90%2C%20%E1%83%9B%E1%83%90%E1%83%92%E1%83%A0%E1%83%90%E1%83%9B%20%E1%83%A1%E1%83%90%E1%83%A8%E1%83%98%E1%83%A8%E1%83%98.)
^ka-Q0664-answer

**ka-Q0665** — მან ეს წიგნი ძალიან მოკლე დროში დაწერა, მხოლოდ ორი კვირა მუშაობდა მასზე.

He wrote this book in a very short time, spending just two weeks working on it.

Why: Coordination and contrast. [[Georgian#^ka-Q0665|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%90%E1%83%9C%20%E1%83%94%E1%83%A1%20%E1%83%AC%E1%83%98%E1%83%92%E1%83%9C%E1%83%98%20%E1%83%AB%E1%83%90%E1%83%9A%E1%83%98%E1%83%90%E1%83%9C%20%E1%83%9B%E1%83%9D%E1%83%99%E1%83%9A%E1%83%94%20%E1%83%93%E1%83%A0%E1%83%9D%E1%83%A8%E1%83%98%20%E1%83%93%E1%83%90%E1%83%AC%E1%83%94%E1%83%A0%E1%83%90%2C%20%E1%83%9B%E1%83%AE%E1%83%9D%E1%83%9A%E1%83%9D%E1%83%93%20%E1%83%9D%E1%83%A0%E1%83%98%20%E1%83%99%E1%83%95%E1%83%98%E1%83%A0%E1%83%90%20%E1%83%9B%E1%83%A3%E1%83%A8%E1%83%90%E1%83%9D%E1%83%91%E1%83%93%E1%83%90%20%E1%83%9B%E1%83%90%E1%83%A1%E1%83%96%E1%83%94.)
^ka-Q0665-answer

**ka-Q0666** — მან ეს წიგნი ძალიან მოკლე დროში დაწერა, მხოლოდ ორი კვირა მუშაობდა მასზე.

He wrote this book in a very short time, spending just two weeks working on it.

და joins, მაგრამ contrasts, and ან gives an alternative. Keep like structures parallel when coordinating. Their meaning does not replace the case and verb rules inside each clause.

Why: Coordination and contrast. [[Georgian#^ka-Q0666|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%90%E1%83%9C%20%E1%83%94%E1%83%A1%20%E1%83%AC%E1%83%98%E1%83%92%E1%83%9C%E1%83%98%20%E1%83%AB%E1%83%90%E1%83%9A%E1%83%98%E1%83%90%E1%83%9C%20%E1%83%9B%E1%83%9D%E1%83%99%E1%83%9A%E1%83%94%20%E1%83%93%E1%83%A0%E1%83%9D%E1%83%A8%E1%83%98%20%E1%83%93%E1%83%90%E1%83%AC%E1%83%94%E1%83%A0%E1%83%90%2C%20%E1%83%9B%E1%83%AE%E1%83%9D%E1%83%9A%E1%83%9D%E1%83%93%20%E1%83%9D%E1%83%A0%E1%83%98%20%E1%83%99%E1%83%95%E1%83%98%E1%83%A0%E1%83%90%20%E1%83%9B%E1%83%A3%E1%83%A8%E1%83%90%E1%83%9D%E1%83%91%E1%83%93%E1%83%90%20%E1%83%9B%E1%83%90%E1%83%A1%E1%83%96%E1%83%94.)
^ka-Q0666-answer

**ka-Q0667** — ტომი წასვლას არ აპირებს შენთან ერთად, არა?

Tom isn't going with you, is he?

Expected form: **ან**

Why: Coordination and contrast. [[Georgian#^ka-Q0667|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%98%20%E1%83%AC%E1%83%90%E1%83%A1%E1%83%95%E1%83%9A%E1%83%90%E1%83%A1%20%E1%83%90%E1%83%A0%20%E1%83%90%E1%83%9E%E1%83%98%E1%83%A0%E1%83%94%E1%83%91%E1%83%A1%20%E1%83%A8%E1%83%94%E1%83%9C%E1%83%97%E1%83%90%E1%83%9C%20%E1%83%94%E1%83%A0%E1%83%97%E1%83%90%E1%83%93%2C%20%E1%83%90%E1%83%A0%E1%83%90%3F)
^ka-Q0667-answer

**ka-Q0668** — ტომი წასვლას არ აპირებს შენთან ერთად, არა?

Tom isn't going with you, is he?

Expected form: **ან**

Why: Coordination and contrast. [[Georgian#^ka-Q0668|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%98%20%E1%83%AC%E1%83%90%E1%83%A1%E1%83%95%E1%83%9A%E1%83%90%E1%83%A1%20%E1%83%90%E1%83%A0%20%E1%83%90%E1%83%9E%E1%83%98%E1%83%A0%E1%83%94%E1%83%91%E1%83%A1%20%E1%83%A8%E1%83%94%E1%83%9C%E1%83%97%E1%83%90%E1%83%9C%20%E1%83%94%E1%83%A0%E1%83%97%E1%83%90%E1%83%93%2C%20%E1%83%90%E1%83%A0%E1%83%90%3F)
^ka-Q0668-answer

**ka-Q0669** — წყალი ძალიან ცხელი არის.

The water's very hot.

Expected form: **ან**

Why: Coordination and contrast. [[Georgian#^ka-Q0669|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%AC%E1%83%A7%E1%83%90%E1%83%9A%E1%83%98%20%E1%83%AB%E1%83%90%E1%83%9A%E1%83%98%E1%83%90%E1%83%9C%20%E1%83%AA%E1%83%AE%E1%83%94%E1%83%9A%E1%83%98%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1.)
^ka-Q0669-answer

**ka-Q0670** — წყალი ძალიან ცხელი არის.

The water's very hot.

Why: Coordination and contrast. [[Georgian#^ka-Q0670|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%AC%E1%83%A7%E1%83%90%E1%83%9A%E1%83%98%20%E1%83%AB%E1%83%90%E1%83%9A%E1%83%98%E1%83%90%E1%83%9C%20%E1%83%AA%E1%83%AE%E1%83%94%E1%83%9A%E1%83%98%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1.)
^ka-Q0670-answer

**ka-Q0671** — მან თავის მოკვლა სცადა.

She attempted suicide.

Why: Coordination and contrast. [[Georgian#^ka-Q0671|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%90%E1%83%9C%20%E1%83%97%E1%83%90%E1%83%95%E1%83%98%E1%83%A1%20%E1%83%9B%E1%83%9D%E1%83%99%E1%83%95%E1%83%9A%E1%83%90%20%E1%83%A1%E1%83%AA%E1%83%90%E1%83%93%E1%83%90.)
^ka-Q0671-answer

**ka-Q0672** — მან თავის მოკვლა სცადა.

She attempted suicide.

და joins, მაგრამ contrasts, and ან gives an alternative. Keep like structures parallel when coordinating. Their meaning does not replace the case and verb rules inside each clause.

Why: Coordination and contrast. [[Georgian#^ka-Q0672|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%90%E1%83%9C%20%E1%83%97%E1%83%90%E1%83%95%E1%83%98%E1%83%A1%20%E1%83%9B%E1%83%9D%E1%83%99%E1%83%95%E1%83%9A%E1%83%90%20%E1%83%A1%E1%83%AA%E1%83%90%E1%83%93%E1%83%90.)
^ka-Q0672-answer

**ka-Q0673** — მე ძალიან მორცხვი ვარ.

I'm very shy.

Expected form: **ან**

Why: Coordination and contrast. [[Georgian#^ka-Q0673|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%AB%E1%83%90%E1%83%9A%E1%83%98%E1%83%90%E1%83%9C%20%E1%83%9B%E1%83%9D%E1%83%A0%E1%83%AA%E1%83%AE%E1%83%95%E1%83%98%20%E1%83%95%E1%83%90%E1%83%A0.)
^ka-Q0673-answer

**ka-Q0674** — მე ძალიან მორცხვი ვარ.

I'm very shy.

Expected form: **ან**

Why: Coordination and contrast. [[Georgian#^ka-Q0674|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%AB%E1%83%90%E1%83%9A%E1%83%98%E1%83%90%E1%83%9C%20%E1%83%9B%E1%83%9D%E1%83%A0%E1%83%AA%E1%83%AE%E1%83%95%E1%83%98%20%E1%83%95%E1%83%90%E1%83%A0.)
^ka-Q0674-answer

**ka-Q0675** — გვინდა ბოსტონში და შიკაგოში წავიდეთ.

We want to go to Boston and Chicago.

Expected form: **და**

Why: Coordination and contrast. [[Georgian#^ka-Q0675|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%92%E1%83%95%E1%83%98%E1%83%9C%E1%83%93%E1%83%90%20%E1%83%91%E1%83%9D%E1%83%A1%E1%83%A2%E1%83%9D%E1%83%9C%E1%83%A8%E1%83%98%20%E1%83%93%E1%83%90%20%E1%83%A8%E1%83%98%E1%83%99%E1%83%90%E1%83%92%E1%83%9D%E1%83%A8%E1%83%98%20%E1%83%AC%E1%83%90%E1%83%95%E1%83%98%E1%83%93%E1%83%94%E1%83%97.)
^ka-Q0675-answer

**ka-Q0676** — გვინდა ბოსტონში და შიკაგოში წავიდეთ.

We want to go to Boston and Chicago.

Why: Coordination and contrast. [[Georgian#^ka-Q0676|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%92%E1%83%95%E1%83%98%E1%83%9C%E1%83%93%E1%83%90%20%E1%83%91%E1%83%9D%E1%83%A1%E1%83%A2%E1%83%9D%E1%83%9C%E1%83%A8%E1%83%98%20%E1%83%93%E1%83%90%20%E1%83%A8%E1%83%98%E1%83%99%E1%83%90%E1%83%92%E1%83%9D%E1%83%A8%E1%83%98%20%E1%83%AC%E1%83%90%E1%83%95%E1%83%98%E1%83%93%E1%83%94%E1%83%97.)
^ka-Q0676-answer

**ka-Q0677** — ტომი და მარიამი არიან ავსტრალიაში?

Are Tom and Mary in Australia?

Why: Coordination and contrast. [[Georgian#^ka-Q0677|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%98%20%E1%83%93%E1%83%90%20%E1%83%9B%E1%83%90%E1%83%A0%E1%83%98%E1%83%90%E1%83%9B%E1%83%98%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%90%E1%83%9C%20%E1%83%90%E1%83%95%E1%83%A1%E1%83%A2%E1%83%A0%E1%83%90%E1%83%9A%E1%83%98%E1%83%90%E1%83%A8%E1%83%98%3F)
^ka-Q0677-answer

**ka-Q0678** — ტომი და მარიამი არიან ავსტრალიაში?

Are Tom and Mary in Australia?

და joins, მაგრამ contrasts, and ან gives an alternative. Keep like structures parallel when coordinating. Their meaning does not replace the case and verb rules inside each clause.

Why: Coordination and contrast. [[Georgian#^ka-Q0678|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%98%20%E1%83%93%E1%83%90%20%E1%83%9B%E1%83%90%E1%83%A0%E1%83%98%E1%83%90%E1%83%9B%E1%83%98%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%90%E1%83%9C%20%E1%83%90%E1%83%95%E1%83%A1%E1%83%A2%E1%83%A0%E1%83%90%E1%83%9A%E1%83%98%E1%83%90%E1%83%A8%E1%83%98%3F)
^ka-Q0678-answer

**ka-Q0679** — ეს სიმსუქნის შესახებ წიგნია.

This is a book about obesity.

Expected form: **შესახებ**

Why: Postpositions and stance. [[Georgian#^ka-Q0679|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%94%E1%83%A1%20%E1%83%A1%E1%83%98%E1%83%9B%E1%83%A1%E1%83%A3%E1%83%A5%E1%83%9C%E1%83%98%E1%83%A1%20%E1%83%A8%E1%83%94%E1%83%A1%E1%83%90%E1%83%AE%E1%83%94%E1%83%91%20%E1%83%AC%E1%83%98%E1%83%92%E1%83%9C%E1%83%98%E1%83%90.)
^ka-Q0679-answer

**ka-Q0680** — ეს სიმსუქნის შესახებ წიგნია.

This is a book about obesity.

Expected form: **შესახებ**

Why: Postpositions and stance. [[Georgian#^ka-Q0680|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%94%E1%83%A1%20%E1%83%A1%E1%83%98%E1%83%9B%E1%83%A1%E1%83%A3%E1%83%A5%E1%83%9C%E1%83%98%E1%83%A1%20%E1%83%A8%E1%83%94%E1%83%A1%E1%83%90%E1%83%AE%E1%83%94%E1%83%91%20%E1%83%AC%E1%83%98%E1%83%92%E1%83%9C%E1%83%98%E1%83%90.)
^ka-Q0680-answer

**ka-Q0681** — ეს საქართველოს შესახებ წიგნია.

This is a book about Georgia.

Expected form: **შესახებ**

Why: Postpositions and stance. [[Georgian#^ka-Q0681|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%94%E1%83%A1%20%E1%83%A1%E1%83%90%E1%83%A5%E1%83%90%E1%83%A0%E1%83%97%E1%83%95%E1%83%94%E1%83%9A%E1%83%9D%E1%83%A1%20%E1%83%A8%E1%83%94%E1%83%A1%E1%83%90%E1%83%AE%E1%83%94%E1%83%91%20%E1%83%AC%E1%83%98%E1%83%92%E1%83%9C%E1%83%98%E1%83%90.)
^ka-Q0681-answer

**ka-Q0682** — ეს საქართველოს შესახებ წიგნია.

This is a book about Georgia.

Why: Postpositions and stance. [[Georgian#^ka-Q0682|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%94%E1%83%A1%20%E1%83%A1%E1%83%90%E1%83%A5%E1%83%90%E1%83%A0%E1%83%97%E1%83%95%E1%83%94%E1%83%9A%E1%83%9D%E1%83%A1%20%E1%83%A8%E1%83%94%E1%83%A1%E1%83%90%E1%83%AE%E1%83%94%E1%83%91%20%E1%83%AC%E1%83%98%E1%83%92%E1%83%9C%E1%83%98%E1%83%90.)
^ka-Q0682-answer

**ka-Q0683** — მე შენს შესახებ ვისაუბრებ.

I'll talk about you.

Why: Postpositions and stance. [[Georgian#^ka-Q0683|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%A8%E1%83%94%E1%83%9C%E1%83%A1%20%E1%83%A8%E1%83%94%E1%83%A1%E1%83%90%E1%83%AE%E1%83%94%E1%83%91%20%E1%83%95%E1%83%98%E1%83%A1%E1%83%90%E1%83%A3%E1%83%91%E1%83%A0%E1%83%94%E1%83%91.)
^ka-Q0683-answer

**ka-Q0684** — მე შენს შესახებ ვისაუბრებ.

I'll talk about you.

Postpositions select a noun relationship/case; ალბათ marks a probability and შეიძლება possibility in relevant constructions. Professional statements should distinguish factual evidence from a tentative reading.

Why: Postpositions and stance. [[Georgian#^ka-Q0684|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%A8%E1%83%94%E1%83%9C%E1%83%A1%20%E1%83%A8%E1%83%94%E1%83%A1%E1%83%90%E1%83%AE%E1%83%94%E1%83%91%20%E1%83%95%E1%83%98%E1%83%A1%E1%83%90%E1%83%A3%E1%83%91%E1%83%A0%E1%83%94%E1%83%91.)
^ka-Q0684-answer

**ka-Q0685** — სექსის დროს პრეზერვატივს თუკი არ გამოიყენებ, შეიძლება დაავადება აიკიდო.

If you don't use a condom during sex, you can catch a disease.

Expected form: **შეიძლება**

Why: Postpositions and stance. [[Georgian#^ka-Q0685|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A1%E1%83%94%E1%83%A5%E1%83%A1%E1%83%98%E1%83%A1%20%E1%83%93%E1%83%A0%E1%83%9D%E1%83%A1%20%E1%83%9E%E1%83%A0%E1%83%94%E1%83%96%E1%83%94%E1%83%A0%E1%83%95%E1%83%90%E1%83%A2%E1%83%98%E1%83%95%E1%83%A1%20%E1%83%97%E1%83%A3%E1%83%99%E1%83%98%20%E1%83%90%E1%83%A0%20%E1%83%92%E1%83%90%E1%83%9B%E1%83%9D%E1%83%98%E1%83%A7%E1%83%94%E1%83%9C%E1%83%94%E1%83%91%2C%20%E1%83%A8%E1%83%94%E1%83%98%E1%83%AB%E1%83%9A%E1%83%94%E1%83%91%E1%83%90%20%E1%83%93%E1%83%90%E1%83%90%E1%83%95%E1%83%90%E1%83%93%E1%83%94%E1%83%91%E1%83%90%20%E1%83%90%E1%83%98%E1%83%99%E1%83%98%E1%83%93%E1%83%9D.)
^ka-Q0685-answer

**ka-Q0686** — სექსის დროს პრეზერვატივს თუკი არ გამოიყენებ, შეიძლება დაავადება აიკიდო.

If you don't use a condom during sex, you can catch a disease.

Expected form: **შეიძლება**

Why: Postpositions and stance. [[Georgian#^ka-Q0686|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A1%E1%83%94%E1%83%A5%E1%83%A1%E1%83%98%E1%83%A1%20%E1%83%93%E1%83%A0%E1%83%9D%E1%83%A1%20%E1%83%9E%E1%83%A0%E1%83%94%E1%83%96%E1%83%94%E1%83%A0%E1%83%95%E1%83%90%E1%83%A2%E1%83%98%E1%83%95%E1%83%A1%20%E1%83%97%E1%83%A3%E1%83%99%E1%83%98%20%E1%83%90%E1%83%A0%20%E1%83%92%E1%83%90%E1%83%9B%E1%83%9D%E1%83%98%E1%83%A7%E1%83%94%E1%83%9C%E1%83%94%E1%83%91%2C%20%E1%83%A8%E1%83%94%E1%83%98%E1%83%AB%E1%83%9A%E1%83%94%E1%83%91%E1%83%90%20%E1%83%93%E1%83%90%E1%83%90%E1%83%95%E1%83%90%E1%83%93%E1%83%94%E1%83%91%E1%83%90%20%E1%83%90%E1%83%98%E1%83%99%E1%83%98%E1%83%93%E1%83%9D.)
^ka-Q0686-answer

**ka-Q0687** — ჩემი ცხოვრება ცარიელია მის გარეშე.

My life is empty without him.

Expected form: **გარეშე**

Why: Postpositions and stance. [[Georgian#^ka-Q0687|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%AA%E1%83%AE%E1%83%9D%E1%83%95%E1%83%A0%E1%83%94%E1%83%91%E1%83%90%20%E1%83%AA%E1%83%90%E1%83%A0%E1%83%98%E1%83%94%E1%83%9A%E1%83%98%E1%83%90%20%E1%83%9B%E1%83%98%E1%83%A1%20%E1%83%92%E1%83%90%E1%83%A0%E1%83%94%E1%83%A8%E1%83%94.)
^ka-Q0687-answer

**ka-Q0688** — ჩემი ცხოვრება ცარიელია მის გარეშე.

My life is empty without him.

Why: Postpositions and stance. [[Georgian#^ka-Q0688|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%AA%E1%83%AE%E1%83%9D%E1%83%95%E1%83%A0%E1%83%94%E1%83%91%E1%83%90%20%E1%83%AA%E1%83%90%E1%83%A0%E1%83%98%E1%83%94%E1%83%9A%E1%83%98%E1%83%90%20%E1%83%9B%E1%83%98%E1%83%A1%20%E1%83%92%E1%83%90%E1%83%A0%E1%83%94%E1%83%A8%E1%83%94.)
^ka-Q0688-answer

**ka-Q0689** — მე დავიფიცე, რომ არასოდეს აღარ დაველაპარაკები.

I vowed that I would never speak to her again.

Why: Independent pronouns. [[Georgian#^ka-Q0689|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%93%E1%83%90%E1%83%95%E1%83%98%E1%83%A4%E1%83%98%E1%83%AA%E1%83%94%2C%20%E1%83%A0%E1%83%9D%E1%83%9B%20%E1%83%90%E1%83%A0%E1%83%90%E1%83%A1%E1%83%9D%E1%83%93%E1%83%94%E1%83%A1%20%E1%83%90%E1%83%A6%E1%83%90%E1%83%A0%20%E1%83%93%E1%83%90%E1%83%95%E1%83%94%E1%83%9A%E1%83%90%E1%83%9E%E1%83%90%E1%83%A0%E1%83%90%E1%83%99%E1%83%94%E1%83%91%E1%83%98.)
^ka-Q0689-answer

**ka-Q0690** — მე დავიფიცე, რომ არასოდეს აღარ დაველაპარაკები.

I vowed that I would never speak to her again.

Pronouns identify participants; verbs often also encode participants, allowing omission. Is can refer to he/she/it without English grammatical gender. Georgian verb classes use distinct case alignments.

Why: Independent pronouns. [[Georgian#^ka-Q0690|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%93%E1%83%90%E1%83%95%E1%83%98%E1%83%A4%E1%83%98%E1%83%AA%E1%83%94%2C%20%E1%83%A0%E1%83%9D%E1%83%9B%20%E1%83%90%E1%83%A0%E1%83%90%E1%83%A1%E1%83%9D%E1%83%93%E1%83%94%E1%83%A1%20%E1%83%90%E1%83%A6%E1%83%90%E1%83%A0%20%E1%83%93%E1%83%90%E1%83%95%E1%83%94%E1%83%9A%E1%83%90%E1%83%9E%E1%83%90%E1%83%A0%E1%83%90%E1%83%99%E1%83%94%E1%83%91%E1%83%98.)
^ka-Q0690-answer

**ka-Q0691** — არის ტომი უფრო უფროსი ვიდრე შენ?

Is Tom older than you?

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0691|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%98%20%E1%83%A3%E1%83%A4%E1%83%A0%E1%83%9D%20%E1%83%A3%E1%83%A4%E1%83%A0%E1%83%9D%E1%83%A1%E1%83%98%20%E1%83%95%E1%83%98%E1%83%93%E1%83%A0%E1%83%94%20%E1%83%A8%E1%83%94%E1%83%9C%3F)
^ka-Q0691-answer

**ka-Q0692** — არის ტომი უფრო უფროსი ვიდრე შენ?

Is Tom older than you?

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0692|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%98%20%E1%83%A3%E1%83%A4%E1%83%A0%E1%83%9D%20%E1%83%A3%E1%83%A4%E1%83%A0%E1%83%9D%E1%83%A1%E1%83%98%20%E1%83%95%E1%83%98%E1%83%93%E1%83%A0%E1%83%94%20%E1%83%A8%E1%83%94%E1%83%9C%3F)
^ka-Q0692-answer

**ka-Q0693** — არის ტომი უფრო ახალგაზრდა ან უფრო მოხუცი ვიდრე შენ?

Is Tom younger or older than you?

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0693|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%98%20%E1%83%A3%E1%83%A4%E1%83%A0%E1%83%9D%20%E1%83%90%E1%83%AE%E1%83%90%E1%83%9A%E1%83%92%E1%83%90%E1%83%96%E1%83%A0%E1%83%93%E1%83%90%20%E1%83%90%E1%83%9C%20%E1%83%A3%E1%83%A4%E1%83%A0%E1%83%9D%20%E1%83%9B%E1%83%9D%E1%83%AE%E1%83%A3%E1%83%AA%E1%83%98%20%E1%83%95%E1%83%98%E1%83%93%E1%83%A0%E1%83%94%20%E1%83%A8%E1%83%94%E1%83%9C%3F)
^ka-Q0693-answer

**ka-Q0694** — არის ტომი უფრო ახალგაზრდა ან უფრო მოხუცი ვიდრე შენ?

Is Tom younger or older than you?

Why: Independent pronouns. [[Georgian#^ka-Q0694|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%98%20%E1%83%A3%E1%83%A4%E1%83%A0%E1%83%9D%20%E1%83%90%E1%83%AE%E1%83%90%E1%83%9A%E1%83%92%E1%83%90%E1%83%96%E1%83%A0%E1%83%93%E1%83%90%20%E1%83%90%E1%83%9C%20%E1%83%A3%E1%83%A4%E1%83%A0%E1%83%9D%20%E1%83%9B%E1%83%9D%E1%83%AE%E1%83%A3%E1%83%AA%E1%83%98%20%E1%83%95%E1%83%98%E1%83%93%E1%83%A0%E1%83%94%20%E1%83%A8%E1%83%94%E1%83%9C%3F)
^ka-Q0694-answer

**ka-Q0695** — მე ამერიკიდან ვარ.

I come from America.

Why: Independent pronouns. [[Georgian#^ka-Q0695|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%90%E1%83%9B%E1%83%94%E1%83%A0%E1%83%98%E1%83%99%E1%83%98%E1%83%93%E1%83%90%E1%83%9C%20%E1%83%95%E1%83%90%E1%83%A0.)
^ka-Q0695-answer

**ka-Q0696** — მე ამერიკიდან ვარ.

I come from America.

Pronouns identify participants; verbs often also encode participants, allowing omission. Is can refer to he/she/it without English grammatical gender. Georgian verb classes use distinct case alignments.

Why: Independent pronouns. [[Georgian#^ka-Q0696|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%90%E1%83%9B%E1%83%94%E1%83%A0%E1%83%98%E1%83%99%E1%83%98%E1%83%93%E1%83%90%E1%83%9C%20%E1%83%95%E1%83%90%E1%83%A0.)
^ka-Q0696-answer

**ka-Q0697** — შენ ძალიან დაბალი ხარ.

You're very short.

Expected form: **შენ**

Why: Independent pronouns. [[Georgian#^ka-Q0697|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A8%E1%83%94%E1%83%9C%20%E1%83%AB%E1%83%90%E1%83%9A%E1%83%98%E1%83%90%E1%83%9C%20%E1%83%93%E1%83%90%E1%83%91%E1%83%90%E1%83%9A%E1%83%98%20%E1%83%AE%E1%83%90%E1%83%A0.)
^ka-Q0697-answer

**ka-Q0698** — შენ ძალიან დაბალი ხარ.

You're very short.

Expected form: **შენ**

Why: Independent pronouns. [[Georgian#^ka-Q0698|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A8%E1%83%94%E1%83%9C%20%E1%83%AB%E1%83%90%E1%83%9A%E1%83%98%E1%83%90%E1%83%9C%20%E1%83%93%E1%83%90%E1%83%91%E1%83%90%E1%83%9A%E1%83%98%20%E1%83%AE%E1%83%90%E1%83%A0.)
^ka-Q0698-answer

**ka-Q0699** — მე სკოლაში მივდივარ.

I go to school.

Expected form: **მე**

Why: Independent pronouns. [[Georgian#^ka-Q0699|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%A1%E1%83%99%E1%83%9D%E1%83%9A%E1%83%90%E1%83%A8%E1%83%98%20%E1%83%9B%E1%83%98%E1%83%95%E1%83%93%E1%83%98%E1%83%95%E1%83%90%E1%83%A0.)
^ka-Q0699-answer

**ka-Q0700** — მე სკოლაში მივდივარ.

I go to school.

Why: Independent pronouns. [[Georgian#^ka-Q0700|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%A1%E1%83%99%E1%83%9D%E1%83%9A%E1%83%90%E1%83%A8%E1%83%98%20%E1%83%9B%E1%83%98%E1%83%95%E1%83%93%E1%83%98%E1%83%95%E1%83%90%E1%83%A0.)
^ka-Q0700-answer


### Answers 701–750

**ka-Q0701** — 45 წლის ვარ.

I'm 45 years old.

Why: Independent pronouns. [[Georgian#^ka-Q0701|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=45%20%E1%83%AC%E1%83%9A%E1%83%98%E1%83%A1%20%E1%83%95%E1%83%90%E1%83%A0.)
^ka-Q0701-answer

**ka-Q0702** — 45 წლის ვარ.

I'm 45 years old.

Pronouns identify participants; verbs often also encode participants, allowing omission. Is can refer to he/she/it without English grammatical gender. Georgian verb classes use distinct case alignments.

Why: Independent pronouns. [[Georgian#^ka-Q0702|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=45%20%E1%83%AC%E1%83%9A%E1%83%98%E1%83%A1%20%E1%83%95%E1%83%90%E1%83%A0.)
^ka-Q0702-answer

**ka-Q0703** — გასულ ღამეს ვესიზმრებოდი, რომ მე ფუტკარს ვჭამდი.

Last night I dreamt I was eating bees.

Expected form: **მე**

Why: Independent pronouns. [[Georgian#^ka-Q0703|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%92%E1%83%90%E1%83%A1%E1%83%A3%E1%83%9A%20%E1%83%A6%E1%83%90%E1%83%9B%E1%83%94%E1%83%A1%20%E1%83%95%E1%83%94%E1%83%A1%E1%83%98%E1%83%96%E1%83%9B%E1%83%A0%E1%83%94%E1%83%91%E1%83%9D%E1%83%93%E1%83%98%2C%20%E1%83%A0%E1%83%9D%E1%83%9B%20%E1%83%9B%E1%83%94%20%E1%83%A4%E1%83%A3%E1%83%A2%E1%83%99%E1%83%90%E1%83%A0%E1%83%A1%20%E1%83%95%E1%83%AD%E1%83%90%E1%83%9B%E1%83%93%E1%83%98.)
^ka-Q0703-answer

**ka-Q0704** — გასულ ღამეს ვესიზმრებოდი, რომ მე ფუტკარს ვჭამდი.

Last night I dreamt I was eating bees.

Expected form: **მე**

Why: Independent pronouns. [[Georgian#^ka-Q0704|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%92%E1%83%90%E1%83%A1%E1%83%A3%E1%83%9A%20%E1%83%A6%E1%83%90%E1%83%9B%E1%83%94%E1%83%A1%20%E1%83%95%E1%83%94%E1%83%A1%E1%83%98%E1%83%96%E1%83%9B%E1%83%A0%E1%83%94%E1%83%91%E1%83%9D%E1%83%93%E1%83%98%2C%20%E1%83%A0%E1%83%9D%E1%83%9B%20%E1%83%9B%E1%83%94%20%E1%83%A4%E1%83%A3%E1%83%A2%E1%83%99%E1%83%90%E1%83%A0%E1%83%A1%20%E1%83%95%E1%83%AD%E1%83%90%E1%83%9B%E1%83%93%E1%83%98.)
^ka-Q0704-answer

**ka-Q0705** — ვინ არის უფრო დაბალი, შენ თუ ტომი?

Who's shorter, you or Tom?

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0705|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%95%E1%83%98%E1%83%9C%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%A3%E1%83%A4%E1%83%A0%E1%83%9D%20%E1%83%93%E1%83%90%E1%83%91%E1%83%90%E1%83%9A%E1%83%98%2C%20%E1%83%A8%E1%83%94%E1%83%9C%20%E1%83%97%E1%83%A3%20%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%98%3F)
^ka-Q0705-answer

**ka-Q0706** — ვინ არის უფრო დაბალი, შენ თუ ტომი?

Who's shorter, you or Tom?

Why: Independent pronouns. [[Georgian#^ka-Q0706|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%95%E1%83%98%E1%83%9C%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%A3%E1%83%A4%E1%83%A0%E1%83%9D%20%E1%83%93%E1%83%90%E1%83%91%E1%83%90%E1%83%9A%E1%83%98%2C%20%E1%83%A8%E1%83%94%E1%83%9C%20%E1%83%97%E1%83%A3%20%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%98%3F)
^ka-Q0706-answer

**ka-Q0707** — მე შენს მხარეს ვარ.

I'm on your side.

Why: Independent pronouns. [[Georgian#^ka-Q0707|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%A8%E1%83%94%E1%83%9C%E1%83%A1%20%E1%83%9B%E1%83%AE%E1%83%90%E1%83%A0%E1%83%94%E1%83%A1%20%E1%83%95%E1%83%90%E1%83%A0.)
^ka-Q0707-answer

**ka-Q0708** — მე შენს მხარეს ვარ.

I'm on your side.

Pronouns identify participants; verbs often also encode participants, allowing omission. Is can refer to he/she/it without English grammatical gender. Georgian verb classes use distinct case alignments.

Why: Independent pronouns. [[Georgian#^ka-Q0708|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%A8%E1%83%94%E1%83%9C%E1%83%A1%20%E1%83%9B%E1%83%AE%E1%83%90%E1%83%A0%E1%83%94%E1%83%A1%20%E1%83%95%E1%83%90%E1%83%A0.)
^ka-Q0708-answer

**ka-Q0709** — წყალი არის ძალიან ცხელი.

The water's very hot.

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0709|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%AC%E1%83%A7%E1%83%90%E1%83%9A%E1%83%98%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%AB%E1%83%90%E1%83%9A%E1%83%98%E1%83%90%E1%83%9C%20%E1%83%AA%E1%83%AE%E1%83%94%E1%83%9A%E1%83%98.)
^ka-Q0709-answer

**ka-Q0710** — წყალი არის ძალიან ცხელი.

The water's very hot.

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0710|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%AC%E1%83%A7%E1%83%90%E1%83%9A%E1%83%98%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%AB%E1%83%90%E1%83%9A%E1%83%98%E1%83%90%E1%83%9C%20%E1%83%AA%E1%83%AE%E1%83%94%E1%83%9A%E1%83%98.)
^ka-Q0710-answer

**ka-Q0711** — სოფელში ძროხა არის.

There is a cow in the village.

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0711|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A1%E1%83%9D%E1%83%A4%E1%83%94%E1%83%9A%E1%83%A8%E1%83%98%20%E1%83%AB%E1%83%A0%E1%83%9D%E1%83%AE%E1%83%90%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1.)
^ka-Q0711-answer

**ka-Q0712** — სოფელში ძროხა არის.

There is a cow in the village.

Why: Independent pronouns. [[Georgian#^ka-Q0712|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A1%E1%83%9D%E1%83%A4%E1%83%94%E1%83%9A%E1%83%A8%E1%83%98%20%E1%83%AB%E1%83%A0%E1%83%9D%E1%83%AE%E1%83%90%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1.)
^ka-Q0712-answer

**ka-Q0713** — დათვმა არცერთი ქვა არ დატოვა ამოუტრიალებელი მსუქალი ხოჭოების ძებნისას.

The bear left no stone unturned in his search for fat bugs under the rocks.

Why: Independent pronouns. [[Georgian#^ka-Q0713|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%93%E1%83%90%E1%83%97%E1%83%95%E1%83%9B%E1%83%90%20%E1%83%90%E1%83%A0%E1%83%AA%E1%83%94%E1%83%A0%E1%83%97%E1%83%98%20%E1%83%A5%E1%83%95%E1%83%90%20%E1%83%90%E1%83%A0%20%E1%83%93%E1%83%90%E1%83%A2%E1%83%9D%E1%83%95%E1%83%90%20%E1%83%90%E1%83%9B%E1%83%9D%E1%83%A3%E1%83%A2%E1%83%A0%E1%83%98%E1%83%90%E1%83%9A%E1%83%94%E1%83%91%E1%83%94%E1%83%9A%E1%83%98%20%E1%83%9B%E1%83%A1%E1%83%A3%E1%83%A5%E1%83%90%E1%83%9A%E1%83%98%20%E1%83%AE%E1%83%9D%E1%83%AD%E1%83%9D%E1%83%94%E1%83%91%E1%83%98%E1%83%A1%20%E1%83%AB%E1%83%94%E1%83%91%E1%83%9C%E1%83%98%E1%83%A1%E1%83%90%E1%83%A1.)
^ka-Q0713-answer

**ka-Q0714** — დათვმა არცერთი ქვა არ დატოვა ამოუტრიალებელი მსუქალი ხოჭოების ძებნისას.

The bear left no stone unturned in his search for fat bugs under the rocks.

Pronouns identify participants; verbs often also encode participants, allowing omission. Is can refer to he/she/it without English grammatical gender. Georgian verb classes use distinct case alignments.

Why: Independent pronouns. [[Georgian#^ka-Q0714|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%93%E1%83%90%E1%83%97%E1%83%95%E1%83%9B%E1%83%90%20%E1%83%90%E1%83%A0%E1%83%AA%E1%83%94%E1%83%A0%E1%83%97%E1%83%98%20%E1%83%A5%E1%83%95%E1%83%90%20%E1%83%90%E1%83%A0%20%E1%83%93%E1%83%90%E1%83%A2%E1%83%9D%E1%83%95%E1%83%90%20%E1%83%90%E1%83%9B%E1%83%9D%E1%83%A3%E1%83%A2%E1%83%A0%E1%83%98%E1%83%90%E1%83%9A%E1%83%94%E1%83%91%E1%83%94%E1%83%9A%E1%83%98%20%E1%83%9B%E1%83%A1%E1%83%A3%E1%83%A5%E1%83%90%E1%83%9A%E1%83%98%20%E1%83%AE%E1%83%9D%E1%83%AD%E1%83%9D%E1%83%94%E1%83%91%E1%83%98%E1%83%A1%20%E1%83%AB%E1%83%94%E1%83%91%E1%83%9C%E1%83%98%E1%83%A1%E1%83%90%E1%83%A1.)
^ka-Q0714-answer

**ka-Q0715** — მე ეგვიპტედან ვარ.

I am from Egypt.

Expected form: **მე**

Why: Independent pronouns. [[Georgian#^ka-Q0715|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%94%E1%83%92%E1%83%95%E1%83%98%E1%83%9E%E1%83%A2%E1%83%94%E1%83%93%E1%83%90%E1%83%9C%20%E1%83%95%E1%83%90%E1%83%A0.)
^ka-Q0715-answer

**ka-Q0716** — მე ეგვიპტედან ვარ.

I am from Egypt.

Expected form: **მე**

Why: Independent pronouns. [[Georgian#^ka-Q0716|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%94%E1%83%92%E1%83%95%E1%83%98%E1%83%9E%E1%83%A2%E1%83%94%E1%83%93%E1%83%90%E1%83%9C%20%E1%83%95%E1%83%90%E1%83%A0.)
^ka-Q0716-answer

**ka-Q0717** — მე ვარ ჟურნალისტი.

I am a journalist.

Expected form: **მე**

Why: Independent pronouns. [[Georgian#^ka-Q0717|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%95%E1%83%90%E1%83%A0%20%E1%83%9F%E1%83%A3%E1%83%A0%E1%83%9C%E1%83%90%E1%83%9A%E1%83%98%E1%83%A1%E1%83%A2%E1%83%98.)
^ka-Q0717-answer

**ka-Q0718** — მე ვარ ჟურნალისტი.

I am a journalist.

Why: Independent pronouns. [[Georgian#^ka-Q0718|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%95%E1%83%90%E1%83%A0%20%E1%83%9F%E1%83%A3%E1%83%A0%E1%83%9C%E1%83%90%E1%83%9A%E1%83%98%E1%83%A1%E1%83%A2%E1%83%98.)
^ka-Q0718-answer

**ka-Q0719** — მე მოგცემ ვაშლს.

I'll give you an apple.

Why: Independent pronouns. [[Georgian#^ka-Q0719|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%9B%E1%83%9D%E1%83%92%E1%83%AA%E1%83%94%E1%83%9B%20%E1%83%95%E1%83%90%E1%83%A8%E1%83%9A%E1%83%A1.)
^ka-Q0719-answer

**ka-Q0720** — მე მოგცემ ვაშლს.

I'll give you an apple.

Pronouns identify participants; verbs often also encode participants, allowing omission. Is can refer to he/she/it without English grammatical gender. Georgian verb classes use distinct case alignments.

Why: Independent pronouns. [[Georgian#^ka-Q0720|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%9B%E1%83%9D%E1%83%92%E1%83%AA%E1%83%94%E1%83%9B%20%E1%83%95%E1%83%90%E1%83%A8%E1%83%9A%E1%83%A1.)
^ka-Q0720-answer

**ka-Q0721** — უკაცრავად. თქვენ ის პიროვნება ხართ?

Excuse me. Are you that person?

Expected form: **თქვენ**

Why: Independent pronouns. [[Georgian#^ka-Q0721|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A3%E1%83%99%E1%83%90%E1%83%AA%E1%83%A0%E1%83%90%E1%83%95%E1%83%90%E1%83%93.%20%E1%83%97%E1%83%A5%E1%83%95%E1%83%94%E1%83%9C%20%E1%83%98%E1%83%A1%20%E1%83%9E%E1%83%98%E1%83%A0%E1%83%9D%E1%83%95%E1%83%9C%E1%83%94%E1%83%91%E1%83%90%20%E1%83%AE%E1%83%90%E1%83%A0%E1%83%97%3F)
^ka-Q0721-answer

**ka-Q0722** — უკაცრავად. თქვენ ის პიროვნება ხართ?

Excuse me. Are you that person?

Expected form: **თქვენ**

Why: Independent pronouns. [[Georgian#^ka-Q0722|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A3%E1%83%99%E1%83%90%E1%83%AA%E1%83%A0%E1%83%90%E1%83%95%E1%83%90%E1%83%93.%20%E1%83%97%E1%83%A5%E1%83%95%E1%83%94%E1%83%9C%20%E1%83%98%E1%83%A1%20%E1%83%9E%E1%83%98%E1%83%A0%E1%83%9D%E1%83%95%E1%83%9C%E1%83%94%E1%83%91%E1%83%90%20%E1%83%AE%E1%83%90%E1%83%A0%E1%83%97%3F)
^ka-Q0722-answer

**ka-Q0723** — არ მინდა, რომ თომი ჩემი პატრონი იყოს, რადგან ის იდიოტია.

I don't want Tom to be my boss because he is an idiot.

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0723|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%A0%20%E1%83%9B%E1%83%98%E1%83%9C%E1%83%93%E1%83%90%2C%20%E1%83%A0%E1%83%9D%E1%83%9B%20%E1%83%97%E1%83%9D%E1%83%9B%E1%83%98%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%9E%E1%83%90%E1%83%A2%E1%83%A0%E1%83%9D%E1%83%9C%E1%83%98%20%E1%83%98%E1%83%A7%E1%83%9D%E1%83%A1%2C%20%E1%83%A0%E1%83%90%E1%83%93%E1%83%92%E1%83%90%E1%83%9C%20%E1%83%98%E1%83%A1%20%E1%83%98%E1%83%93%E1%83%98%E1%83%9D%E1%83%A2%E1%83%98%E1%83%90.)
^ka-Q0723-answer

**ka-Q0724** — არ მინდა, რომ თომი ჩემი პატრონი იყოს, რადგან ის იდიოტია.

I don't want Tom to be my boss because he is an idiot.

Why: Independent pronouns. [[Georgian#^ka-Q0724|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%A0%20%E1%83%9B%E1%83%98%E1%83%9C%E1%83%93%E1%83%90%2C%20%E1%83%A0%E1%83%9D%E1%83%9B%20%E1%83%97%E1%83%9D%E1%83%9B%E1%83%98%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%9E%E1%83%90%E1%83%A2%E1%83%A0%E1%83%9D%E1%83%9C%E1%83%98%20%E1%83%98%E1%83%A7%E1%83%9D%E1%83%A1%2C%20%E1%83%A0%E1%83%90%E1%83%93%E1%83%92%E1%83%90%E1%83%9C%20%E1%83%98%E1%83%A1%20%E1%83%98%E1%83%93%E1%83%98%E1%83%9D%E1%83%A2%E1%83%98%E1%83%90.)
^ka-Q0724-answer

**ka-Q0725** — ეს ტომის სკოლაა.

This is Tom's school.

Why: Independent pronouns. [[Georgian#^ka-Q0725|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%94%E1%83%A1%20%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%98%E1%83%A1%20%E1%83%A1%E1%83%99%E1%83%9D%E1%83%9A%E1%83%90%E1%83%90.)
^ka-Q0725-answer

**ka-Q0726** — ეს ტომის სკოლაა.

This is Tom's school.

Pronouns identify participants; verbs often also encode participants, allowing omission. Is can refer to he/she/it without English grammatical gender. Georgian verb classes use distinct case alignments.

Why: Independent pronouns. [[Georgian#^ka-Q0726|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%94%E1%83%A1%20%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%98%E1%83%A1%20%E1%83%A1%E1%83%99%E1%83%9D%E1%83%9A%E1%83%90%E1%83%90.)
^ka-Q0726-answer

**ka-Q0727** — ეს არის გოგო.

This is a girl.

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0727|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%94%E1%83%A1%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%92%E1%83%9D%E1%83%92%E1%83%9D.)
^ka-Q0727-answer

**ka-Q0728** — ეს არის გოგო.

This is a girl.

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0728|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%94%E1%83%A1%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%92%E1%83%9D%E1%83%92%E1%83%9D.)
^ka-Q0728-answer

**ka-Q0729** — აი შენი ძაღლი. სად არის ჩემი?

Here is your dog. Where is mine?

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0729|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%98%20%E1%83%A8%E1%83%94%E1%83%9C%E1%83%98%20%E1%83%AB%E1%83%90%E1%83%A6%E1%83%9A%E1%83%98.%20%E1%83%A1%E1%83%90%E1%83%93%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%3F)
^ka-Q0729-answer

**ka-Q0730** — აი შენი ძაღლი. სად არის ჩემი?

Here is your dog. Where is mine?

Why: Independent pronouns. [[Georgian#^ka-Q0730|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%98%20%E1%83%A8%E1%83%94%E1%83%9C%E1%83%98%20%E1%83%AB%E1%83%90%E1%83%A6%E1%83%9A%E1%83%98.%20%E1%83%A1%E1%83%90%E1%83%93%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%3F)
^ka-Q0730-answer

**ka-Q0731** — მე ცხრამეტი წლის ვარ.

I am 19 years old.

Why: Independent pronouns. [[Georgian#^ka-Q0731|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%AA%E1%83%AE%E1%83%A0%E1%83%90%E1%83%9B%E1%83%94%E1%83%A2%E1%83%98%20%E1%83%AC%E1%83%9A%E1%83%98%E1%83%A1%20%E1%83%95%E1%83%90%E1%83%A0.)
^ka-Q0731-answer

**ka-Q0732** — მე ცხრამეტი წლის ვარ.

I am 19 years old.

Pronouns identify participants; verbs often also encode participants, allowing omission. Is can refer to he/she/it without English grammatical gender. Georgian verb classes use distinct case alignments.

Why: Independent pronouns. [[Georgian#^ka-Q0732|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%AA%E1%83%AE%E1%83%A0%E1%83%90%E1%83%9B%E1%83%94%E1%83%A2%E1%83%98%20%E1%83%AC%E1%83%9A%E1%83%98%E1%83%A1%20%E1%83%95%E1%83%90%E1%83%A0.)
^ka-Q0732-answer

**ka-Q0733** — ისინი კარს აღებენ.

They open the door.

Expected form: **ისინი**

Why: Independent pronouns. [[Georgian#^ka-Q0733|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%98%E1%83%A1%E1%83%98%E1%83%9C%E1%83%98%20%E1%83%99%E1%83%90%E1%83%A0%E1%83%A1%20%E1%83%90%E1%83%A6%E1%83%94%E1%83%91%E1%83%94%E1%83%9C.)
^ka-Q0733-answer

**ka-Q0734** — ისინი კარს აღებენ.

They open the door.

Expected form: **ისინი**

Why: Independent pronouns. [[Georgian#^ka-Q0734|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%98%E1%83%A1%E1%83%98%E1%83%9C%E1%83%98%20%E1%83%99%E1%83%90%E1%83%A0%E1%83%A1%20%E1%83%90%E1%83%A6%E1%83%94%E1%83%91%E1%83%94%E1%83%9C.)
^ka-Q0734-answer

**ka-Q0735** — მას მე უყვარვარ?

Does he love me?

Expected form: **მე**

Why: Independent pronouns. [[Georgian#^ka-Q0735|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%90%E1%83%A1%20%E1%83%9B%E1%83%94%20%E1%83%A3%E1%83%A7%E1%83%95%E1%83%90%E1%83%A0%E1%83%95%E1%83%90%E1%83%A0%3F)
^ka-Q0735-answer

**ka-Q0736** — მას მე უყვარვარ?

Does he love me?

Why: Independent pronouns. [[Georgian#^ka-Q0736|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%90%E1%83%A1%20%E1%83%9B%E1%83%94%20%E1%83%A3%E1%83%A7%E1%83%95%E1%83%90%E1%83%A0%E1%83%95%E1%83%90%E1%83%A0%3F)
^ka-Q0736-answer

**ka-Q0737** — შენ ინგლისურს სწავლობ.

You study English.

Why: Independent pronouns. [[Georgian#^ka-Q0737|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A8%E1%83%94%E1%83%9C%20%E1%83%98%E1%83%9C%E1%83%92%E1%83%9A%E1%83%98%E1%83%A1%E1%83%A3%E1%83%A0%E1%83%A1%20%E1%83%A1%E1%83%AC%E1%83%90%E1%83%95%E1%83%9A%E1%83%9D%E1%83%91.)
^ka-Q0737-answer

**ka-Q0738** — შენ ინგლისურს სწავლობ.

You study English.

Pronouns identify participants; verbs often also encode participants, allowing omission. Is can refer to he/she/it without English grammatical gender. Georgian verb classes use distinct case alignments.

Why: Independent pronouns. [[Georgian#^ka-Q0738|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A8%E1%83%94%E1%83%9C%20%E1%83%98%E1%83%9C%E1%83%92%E1%83%9A%E1%83%98%E1%83%A1%E1%83%A3%E1%83%A0%E1%83%A1%20%E1%83%A1%E1%83%AC%E1%83%90%E1%83%95%E1%83%9A%E1%83%9D%E1%83%91.)
^ka-Q0738-answer

**ka-Q0739** — მე უნდა წავიდე.

I have to go.

Expected form: **მე**

Why: Independent pronouns. [[Georgian#^ka-Q0739|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%A3%E1%83%9C%E1%83%93%E1%83%90%20%E1%83%AC%E1%83%90%E1%83%95%E1%83%98%E1%83%93%E1%83%94.)
^ka-Q0739-answer

**ka-Q0740** — მე უნდა წავიდე.

I have to go.

Expected form: **მე**

Why: Independent pronouns. [[Georgian#^ka-Q0740|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%A3%E1%83%9C%E1%83%93%E1%83%90%20%E1%83%AC%E1%83%90%E1%83%95%E1%83%98%E1%83%93%E1%83%94.)
^ka-Q0740-answer

**ka-Q0741** — ტუალეტის ქაღალდი არ იყო.

There was no toilet paper.

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0741|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A2%E1%83%A3%E1%83%90%E1%83%9A%E1%83%94%E1%83%A2%E1%83%98%E1%83%A1%20%E1%83%A5%E1%83%90%E1%83%A6%E1%83%90%E1%83%9A%E1%83%93%E1%83%98%20%E1%83%90%E1%83%A0%20%E1%83%98%E1%83%A7%E1%83%9D.)
^ka-Q0741-answer

**ka-Q0742** — ტუალეტის ქაღალდი არ იყო.

There was no toilet paper.

Why: Independent pronouns. [[Georgian#^ka-Q0742|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A2%E1%83%A3%E1%83%90%E1%83%9A%E1%83%94%E1%83%A2%E1%83%98%E1%83%A1%20%E1%83%A5%E1%83%90%E1%83%A6%E1%83%90%E1%83%9A%E1%83%93%E1%83%98%20%E1%83%90%E1%83%A0%20%E1%83%98%E1%83%A7%E1%83%9D.)
^ka-Q0742-answer

**ka-Q0743** — დიახ, მე საპოროდან ვარ.

Yes, I am from Sapporo.

Why: Independent pronouns. [[Georgian#^ka-Q0743|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%93%E1%83%98%E1%83%90%E1%83%AE%2C%20%E1%83%9B%E1%83%94%20%E1%83%A1%E1%83%90%E1%83%9E%E1%83%9D%E1%83%A0%E1%83%9D%E1%83%93%E1%83%90%E1%83%9C%20%E1%83%95%E1%83%90%E1%83%A0.)
^ka-Q0743-answer

**ka-Q0744** — დიახ, მე საპოროდან ვარ.

Yes, I am from Sapporo.

Pronouns identify participants; verbs often also encode participants, allowing omission. Is can refer to he/she/it without English grammatical gender. Georgian verb classes use distinct case alignments.

Why: Independent pronouns. [[Georgian#^ka-Q0744|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%93%E1%83%98%E1%83%90%E1%83%AE%2C%20%E1%83%9B%E1%83%94%20%E1%83%A1%E1%83%90%E1%83%9E%E1%83%9D%E1%83%A0%E1%83%9D%E1%83%93%E1%83%90%E1%83%9C%20%E1%83%95%E1%83%90%E1%83%A0.)
^ka-Q0744-answer

**ka-Q0745** — ზამთარში ცურვა არ არის საშიში ჯანმრთელი ხალხისთვის.

Winter swimming isn't dangerous for healthy people.

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0745|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%96%E1%83%90%E1%83%9B%E1%83%97%E1%83%90%E1%83%A0%E1%83%A8%E1%83%98%20%E1%83%AA%E1%83%A3%E1%83%A0%E1%83%95%E1%83%90%20%E1%83%90%E1%83%A0%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%A1%E1%83%90%E1%83%A8%E1%83%98%E1%83%A8%E1%83%98%20%E1%83%AF%E1%83%90%E1%83%9C%E1%83%9B%E1%83%A0%E1%83%97%E1%83%94%E1%83%9A%E1%83%98%20%E1%83%AE%E1%83%90%E1%83%9A%E1%83%AE%E1%83%98%E1%83%A1%E1%83%97%E1%83%95%E1%83%98%E1%83%A1.)
^ka-Q0745-answer

**ka-Q0746** — ზამთარში ცურვა არ არის საშიში ჯანმრთელი ხალხისთვის.

Winter swimming isn't dangerous for healthy people.

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0746|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%96%E1%83%90%E1%83%9B%E1%83%97%E1%83%90%E1%83%A0%E1%83%A8%E1%83%98%20%E1%83%AA%E1%83%A3%E1%83%A0%E1%83%95%E1%83%90%20%E1%83%90%E1%83%A0%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%A1%E1%83%90%E1%83%A8%E1%83%98%E1%83%A8%E1%83%98%20%E1%83%AF%E1%83%90%E1%83%9C%E1%83%9B%E1%83%A0%E1%83%97%E1%83%94%E1%83%9A%E1%83%98%20%E1%83%AE%E1%83%90%E1%83%9A%E1%83%AE%E1%83%98%E1%83%A1%E1%83%97%E1%83%95%E1%83%98%E1%83%A1.)
^ka-Q0746-answer

**ka-Q0747** — იმის გამო სწავლობენ ინგლისურს.

That is what they study English for.

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0747|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%98%E1%83%9B%E1%83%98%E1%83%A1%20%E1%83%92%E1%83%90%E1%83%9B%E1%83%9D%20%E1%83%A1%E1%83%AC%E1%83%90%E1%83%95%E1%83%9A%E1%83%9D%E1%83%91%E1%83%94%E1%83%9C%20%E1%83%98%E1%83%9C%E1%83%92%E1%83%9A%E1%83%98%E1%83%A1%E1%83%A3%E1%83%A0%E1%83%A1.)
^ka-Q0747-answer

**ka-Q0748** — იმის გამო სწავლობენ ინგლისურს.

That is what they study English for.

Why: Independent pronouns. [[Georgian#^ka-Q0748|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%98%E1%83%9B%E1%83%98%E1%83%A1%20%E1%83%92%E1%83%90%E1%83%9B%E1%83%9D%20%E1%83%A1%E1%83%AC%E1%83%90%E1%83%95%E1%83%9A%E1%83%9D%E1%83%91%E1%83%94%E1%83%9C%20%E1%83%98%E1%83%9C%E1%83%92%E1%83%9A%E1%83%98%E1%83%A1%E1%83%A3%E1%83%A0%E1%83%A1.)
^ka-Q0748-answer

**ka-Q0749** — მე არ ვარ ხნიერი.

I'm not old.

Why: Independent pronouns. [[Georgian#^ka-Q0749|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%90%E1%83%A0%20%E1%83%95%E1%83%90%E1%83%A0%20%E1%83%AE%E1%83%9C%E1%83%98%E1%83%94%E1%83%A0%E1%83%98.)
^ka-Q0749-answer

**ka-Q0750** — მე არ ვარ ხნიერი.

I'm not old.

Pronouns identify participants; verbs often also encode participants, allowing omission. Is can refer to he/she/it without English grammatical gender. Georgian verb classes use distinct case alignments.

Why: Independent pronouns. [[Georgian#^ka-Q0750|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%90%E1%83%A0%20%E1%83%95%E1%83%90%E1%83%A0%20%E1%83%AE%E1%83%9C%E1%83%98%E1%83%94%E1%83%A0%E1%83%98.)
^ka-Q0750-answer


### Answers 751–800

**ka-Q0751** — ტომმა ლექსიკონი იყიდა მარიამისთვის.

Tom bought Mary a dictionary.

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0751|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%9B%E1%83%90%20%E1%83%9A%E1%83%94%E1%83%A5%E1%83%A1%E1%83%98%E1%83%99%E1%83%9D%E1%83%9C%E1%83%98%20%E1%83%98%E1%83%A7%E1%83%98%E1%83%93%E1%83%90%20%E1%83%9B%E1%83%90%E1%83%A0%E1%83%98%E1%83%90%E1%83%9B%E1%83%98%E1%83%A1%E1%83%97%E1%83%95%E1%83%98%E1%83%A1.)
^ka-Q0751-answer

**ka-Q0752** — ტომმა ლექსიკონი იყიდა მარიამისთვის.

Tom bought Mary a dictionary.

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0752|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%9B%E1%83%90%20%E1%83%9A%E1%83%94%E1%83%A5%E1%83%A1%E1%83%98%E1%83%99%E1%83%9D%E1%83%9C%E1%83%98%20%E1%83%98%E1%83%A7%E1%83%98%E1%83%93%E1%83%90%20%E1%83%9B%E1%83%90%E1%83%A0%E1%83%98%E1%83%90%E1%83%9B%E1%83%98%E1%83%A1%E1%83%97%E1%83%95%E1%83%98%E1%83%A1.)
^ka-Q0752-answer

**ka-Q0753** — მე მინდა მოვკვდე გეთერ იანი - თან ერთად.

I want to die with Getter Jaani.

Expected form: **მე**

Why: Independent pronouns. [[Georgian#^ka-Q0753|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%9B%E1%83%98%E1%83%9C%E1%83%93%E1%83%90%20%E1%83%9B%E1%83%9D%E1%83%95%E1%83%99%E1%83%95%E1%83%93%E1%83%94%20%E1%83%92%E1%83%94%E1%83%97%E1%83%94%E1%83%A0%20%E1%83%98%E1%83%90%E1%83%9C%E1%83%98%20-%20%E1%83%97%E1%83%90%E1%83%9C%20%E1%83%94%E1%83%A0%E1%83%97%E1%83%90%E1%83%93.)
^ka-Q0753-answer

**ka-Q0754** — მე მინდა მოვკვდე გეთერ იანი - თან ერთად.

I want to die with Getter Jaani.

Why: Independent pronouns. [[Georgian#^ka-Q0754|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%9B%E1%83%98%E1%83%9C%E1%83%93%E1%83%90%20%E1%83%9B%E1%83%9D%E1%83%95%E1%83%99%E1%83%95%E1%83%93%E1%83%94%20%E1%83%92%E1%83%94%E1%83%97%E1%83%94%E1%83%A0%20%E1%83%98%E1%83%90%E1%83%9C%E1%83%98%20-%20%E1%83%97%E1%83%90%E1%83%9C%20%E1%83%94%E1%83%A0%E1%83%97%E1%83%90%E1%83%93.)
^ka-Q0754-answer

**ka-Q0755** — მე არ მაქვს ალტერნატივა.

I have no alternatives.

Why: Independent pronouns. [[Georgian#^ka-Q0755|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%90%E1%83%A0%20%E1%83%9B%E1%83%90%E1%83%A5%E1%83%95%E1%83%A1%20%E1%83%90%E1%83%9A%E1%83%A2%E1%83%94%E1%83%A0%E1%83%9C%E1%83%90%E1%83%A2%E1%83%98%E1%83%95%E1%83%90.)
^ka-Q0755-answer

**ka-Q0756** — მე არ მაქვს ალტერნატივა.

I have no alternatives.

Pronouns identify participants; verbs often also encode participants, allowing omission. Is can refer to he/she/it without English grammatical gender. Georgian verb classes use distinct case alignments.

Why: Independent pronouns. [[Georgian#^ka-Q0756|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%90%E1%83%A0%20%E1%83%9B%E1%83%90%E1%83%A5%E1%83%95%E1%83%A1%20%E1%83%90%E1%83%9A%E1%83%A2%E1%83%94%E1%83%A0%E1%83%9C%E1%83%90%E1%83%A2%E1%83%98%E1%83%95%E1%83%90.)
^ka-Q0756-answer

**ka-Q0757** — მე შენს უკან ვარ.

I'm behind you.

Expected form: **მე**

Why: Independent pronouns. [[Georgian#^ka-Q0757|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%A8%E1%83%94%E1%83%9C%E1%83%A1%20%E1%83%A3%E1%83%99%E1%83%90%E1%83%9C%20%E1%83%95%E1%83%90%E1%83%A0.)
^ka-Q0757-answer

**ka-Q0758** — მე შენს უკან ვარ.

I'm behind you.

Expected form: **მე**

Why: Independent pronouns. [[Georgian#^ka-Q0758|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%A8%E1%83%94%E1%83%9C%E1%83%A1%20%E1%83%A3%E1%83%99%E1%83%90%E1%83%9C%20%E1%83%95%E1%83%90%E1%83%A0.)
^ka-Q0758-answer

**ka-Q0759** — მე კარს ვაღებ.

I open the door.

Expected form: **მე**

Why: Independent pronouns. [[Georgian#^ka-Q0759|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%99%E1%83%90%E1%83%A0%E1%83%A1%20%E1%83%95%E1%83%90%E1%83%A6%E1%83%94%E1%83%91.)
^ka-Q0759-answer

**ka-Q0760** — მე კარს ვაღებ.

I open the door.

Why: Independent pronouns. [[Georgian#^ka-Q0760|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%99%E1%83%90%E1%83%A0%E1%83%A1%20%E1%83%95%E1%83%90%E1%83%A6%E1%83%94%E1%83%91.)
^ka-Q0760-answer

**ka-Q0761** — მე არა ვარ დიქტატორი.

I'm not a dictator.

Why: Independent pronouns. [[Georgian#^ka-Q0761|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%90%E1%83%A0%E1%83%90%20%E1%83%95%E1%83%90%E1%83%A0%20%E1%83%93%E1%83%98%E1%83%A5%E1%83%A2%E1%83%90%E1%83%A2%E1%83%9D%E1%83%A0%E1%83%98.)
^ka-Q0761-answer

**ka-Q0762** — მე არა ვარ დიქტატორი.

I'm not a dictator.

Pronouns identify participants; verbs often also encode participants, allowing omission. Is can refer to he/she/it without English grammatical gender. Georgian verb classes use distinct case alignments.

Why: Independent pronouns. [[Georgian#^ka-Q0762|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%90%E1%83%A0%E1%83%90%20%E1%83%95%E1%83%90%E1%83%A0%20%E1%83%93%E1%83%98%E1%83%A5%E1%83%A2%E1%83%90%E1%83%A2%E1%83%9D%E1%83%A0%E1%83%98.)
^ka-Q0762-answer

**ka-Q0763** — ცათამბჯენი ქალაქის ცენტრშია.

The skyscraper is in the center of the city.

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0763|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%AA%E1%83%90%E1%83%97%E1%83%90%E1%83%9B%E1%83%91%E1%83%AF%E1%83%94%E1%83%9C%E1%83%98%20%E1%83%A5%E1%83%90%E1%83%9A%E1%83%90%E1%83%A5%E1%83%98%E1%83%A1%20%E1%83%AA%E1%83%94%E1%83%9C%E1%83%A2%E1%83%A0%E1%83%A8%E1%83%98%E1%83%90.)
^ka-Q0763-answer

**ka-Q0764** — ცათამბჯენი ქალაქის ცენტრშია.

The skyscraper is in the center of the city.

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0764|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%AA%E1%83%90%E1%83%97%E1%83%90%E1%83%9B%E1%83%91%E1%83%AF%E1%83%94%E1%83%9C%E1%83%98%20%E1%83%A5%E1%83%90%E1%83%9A%E1%83%90%E1%83%A5%E1%83%98%E1%83%A1%20%E1%83%AA%E1%83%94%E1%83%9C%E1%83%A2%E1%83%A0%E1%83%A8%E1%83%98%E1%83%90.)
^ka-Q0764-answer

**ka-Q0765** — ის წერილს დაწერა.

He wrote a letter.

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0765|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%98%E1%83%A1%20%E1%83%AC%E1%83%94%E1%83%A0%E1%83%98%E1%83%9A%E1%83%A1%20%E1%83%93%E1%83%90%E1%83%AC%E1%83%94%E1%83%A0%E1%83%90.)
^ka-Q0765-answer

**ka-Q0766** — ის წერილს დაწერა.

He wrote a letter.

Why: Independent pronouns. [[Georgian#^ka-Q0766|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%98%E1%83%A1%20%E1%83%AC%E1%83%94%E1%83%A0%E1%83%98%E1%83%9A%E1%83%A1%20%E1%83%93%E1%83%90%E1%83%AC%E1%83%94%E1%83%A0%E1%83%90.)
^ka-Q0766-answer

**ka-Q0767** — მე ლამაზი ვარ?

Am I pretty?

Why: Independent pronouns. [[Georgian#^ka-Q0767|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%9A%E1%83%90%E1%83%9B%E1%83%90%E1%83%96%E1%83%98%20%E1%83%95%E1%83%90%E1%83%A0%3F)
^ka-Q0767-answer

**ka-Q0768** — მე ლამაზი ვარ?

Am I pretty?

Pronouns identify participants; verbs often also encode participants, allowing omission. Is can refer to he/she/it without English grammatical gender. Georgian verb classes use distinct case alignments.

Why: Independent pronouns. [[Georgian#^ka-Q0768|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%9A%E1%83%90%E1%83%9B%E1%83%90%E1%83%96%E1%83%98%20%E1%83%95%E1%83%90%E1%83%A0%3F)
^ka-Q0768-answer

**ka-Q0769** — ეს არის ჩემი წიგნი.

This is my book.

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0769|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%94%E1%83%A1%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%AC%E1%83%98%E1%83%92%E1%83%9C%E1%83%98.)
^ka-Q0769-answer

**ka-Q0770** — ეს არის ჩემი წიგნი.

This is my book.

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0770|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%94%E1%83%A1%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%AC%E1%83%98%E1%83%92%E1%83%9C%E1%83%98.)
^ka-Q0770-answer

**ka-Q0771** — სკოლაში წასვლის დროა.

It's time to go to school.

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0771|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A1%E1%83%99%E1%83%9D%E1%83%9A%E1%83%90%E1%83%A8%E1%83%98%20%E1%83%AC%E1%83%90%E1%83%A1%E1%83%95%E1%83%9A%E1%83%98%E1%83%A1%20%E1%83%93%E1%83%A0%E1%83%9D%E1%83%90.)
^ka-Q0771-answer

**ka-Q0772** — სკოლაში წასვლის დროა.

It's time to go to school.

Why: Independent pronouns. [[Georgian#^ka-Q0772|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A1%E1%83%99%E1%83%9D%E1%83%9A%E1%83%90%E1%83%A8%E1%83%98%20%E1%83%AC%E1%83%90%E1%83%A1%E1%83%95%E1%83%9A%E1%83%98%E1%83%A1%20%E1%83%93%E1%83%A0%E1%83%9D%E1%83%90.)
^ka-Q0772-answer

**ka-Q0773** — ავტოავარიამ სამი ადამიანის სიცოცხლე იმსხვერპლა.

Three people died in the car accident.

Why: Independent pronouns. [[Georgian#^ka-Q0773|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%95%E1%83%A2%E1%83%9D%E1%83%90%E1%83%95%E1%83%90%E1%83%A0%E1%83%98%E1%83%90%E1%83%9B%20%E1%83%A1%E1%83%90%E1%83%9B%E1%83%98%20%E1%83%90%E1%83%93%E1%83%90%E1%83%9B%E1%83%98%E1%83%90%E1%83%9C%E1%83%98%E1%83%A1%20%E1%83%A1%E1%83%98%E1%83%AA%E1%83%9D%E1%83%AA%E1%83%AE%E1%83%9A%E1%83%94%20%E1%83%98%E1%83%9B%E1%83%A1%E1%83%AE%E1%83%95%E1%83%94%E1%83%A0%E1%83%9E%E1%83%9A%E1%83%90.)
^ka-Q0773-answer

**ka-Q0774** — ავტოავარიამ სამი ადამიანის სიცოცხლე იმსხვერპლა.

Three people died in the car accident.

Pronouns identify participants; verbs often also encode participants, allowing omission. Is can refer to he/she/it without English grammatical gender. Georgian verb classes use distinct case alignments.

Why: Independent pronouns. [[Georgian#^ka-Q0774|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%95%E1%83%A2%E1%83%9D%E1%83%90%E1%83%95%E1%83%90%E1%83%A0%E1%83%98%E1%83%90%E1%83%9B%20%E1%83%A1%E1%83%90%E1%83%9B%E1%83%98%20%E1%83%90%E1%83%93%E1%83%90%E1%83%9B%E1%83%98%E1%83%90%E1%83%9C%E1%83%98%E1%83%A1%20%E1%83%A1%E1%83%98%E1%83%AA%E1%83%9D%E1%83%AA%E1%83%AE%E1%83%9A%E1%83%94%20%E1%83%98%E1%83%9B%E1%83%A1%E1%83%AE%E1%83%95%E1%83%94%E1%83%A0%E1%83%9E%E1%83%9A%E1%83%90.)
^ka-Q0774-answer

**ka-Q0775** — ღიმილი, რომელსაც გაგზავნი, ისევ შენ დაგიბრუნდება.

The smile you send out returns to you.

Expected form: **შენ**

Why: Independent pronouns. [[Georgian#^ka-Q0775|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A6%E1%83%98%E1%83%9B%E1%83%98%E1%83%9A%E1%83%98%2C%20%E1%83%A0%E1%83%9D%E1%83%9B%E1%83%94%E1%83%9A%E1%83%A1%E1%83%90%E1%83%AA%20%E1%83%92%E1%83%90%E1%83%92%E1%83%96%E1%83%90%E1%83%95%E1%83%9C%E1%83%98%2C%20%E1%83%98%E1%83%A1%E1%83%94%E1%83%95%20%E1%83%A8%E1%83%94%E1%83%9C%20%E1%83%93%E1%83%90%E1%83%92%E1%83%98%E1%83%91%E1%83%A0%E1%83%A3%E1%83%9C%E1%83%93%E1%83%94%E1%83%91%E1%83%90.)
^ka-Q0775-answer

**ka-Q0776** — ღიმილი, რომელსაც გაგზავნი, ისევ შენ დაგიბრუნდება.

The smile you send out returns to you.

Expected form: **შენ**

Why: Independent pronouns. [[Georgian#^ka-Q0776|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A6%E1%83%98%E1%83%9B%E1%83%98%E1%83%9A%E1%83%98%2C%20%E1%83%A0%E1%83%9D%E1%83%9B%E1%83%94%E1%83%9A%E1%83%A1%E1%83%90%E1%83%AA%20%E1%83%92%E1%83%90%E1%83%92%E1%83%96%E1%83%90%E1%83%95%E1%83%9C%E1%83%98%2C%20%E1%83%98%E1%83%A1%E1%83%94%E1%83%95%20%E1%83%A8%E1%83%94%E1%83%9C%20%E1%83%93%E1%83%90%E1%83%92%E1%83%98%E1%83%91%E1%83%A0%E1%83%A3%E1%83%9C%E1%83%93%E1%83%94%E1%83%91%E1%83%90.)
^ka-Q0776-answer

**ka-Q0777** — ჩემი სინდისი არ არის სუფთა.

My conscience is not clean.

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0777|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%A1%E1%83%98%E1%83%9C%E1%83%93%E1%83%98%E1%83%A1%E1%83%98%20%E1%83%90%E1%83%A0%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%A1%E1%83%A3%E1%83%A4%E1%83%97%E1%83%90.)
^ka-Q0777-answer

**ka-Q0778** — ჩემი სინდისი არ არის სუფთა.

My conscience is not clean.

Why: Independent pronouns. [[Georgian#^ka-Q0778|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%A1%E1%83%98%E1%83%9C%E1%83%93%E1%83%98%E1%83%A1%E1%83%98%20%E1%83%90%E1%83%A0%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%A1%E1%83%A3%E1%83%A4%E1%83%97%E1%83%90.)
^ka-Q0778-answer

**ka-Q0779** — უკაცრავად , თქვენ საუბრობთ იტალიურად?

Excuse me, do you speak Italian?

Why: Independent pronouns. [[Georgian#^ka-Q0779|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A3%E1%83%99%E1%83%90%E1%83%AA%E1%83%A0%E1%83%90%E1%83%95%E1%83%90%E1%83%93%20%2C%20%E1%83%97%E1%83%A5%E1%83%95%E1%83%94%E1%83%9C%20%E1%83%A1%E1%83%90%E1%83%A3%E1%83%91%E1%83%A0%E1%83%9D%E1%83%91%E1%83%97%20%E1%83%98%E1%83%A2%E1%83%90%E1%83%9A%E1%83%98%E1%83%A3%E1%83%A0%E1%83%90%E1%83%93%3F)
^ka-Q0779-answer

**ka-Q0780** — უკაცრავად , თქვენ საუბრობთ იტალიურად?

Excuse me, do you speak Italian?

Pronouns identify participants; verbs often also encode participants, allowing omission. Is can refer to he/she/it without English grammatical gender. Georgian verb classes use distinct case alignments.

Why: Independent pronouns. [[Georgian#^ka-Q0780|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A3%E1%83%99%E1%83%90%E1%83%AA%E1%83%A0%E1%83%90%E1%83%95%E1%83%90%E1%83%93%20%2C%20%E1%83%97%E1%83%A5%E1%83%95%E1%83%94%E1%83%9C%20%E1%83%A1%E1%83%90%E1%83%A3%E1%83%91%E1%83%A0%E1%83%9D%E1%83%91%E1%83%97%20%E1%83%98%E1%83%A2%E1%83%90%E1%83%9A%E1%83%98%E1%83%A3%E1%83%A0%E1%83%90%E1%83%93%3F)
^ka-Q0780-answer

**ka-Q0781** — მე ვერ შეასრულა ტომ.

I couldn't stop Tom.

Expected form: **მე**

Why: Independent pronouns. [[Georgian#^ka-Q0781|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%95%E1%83%94%E1%83%A0%20%E1%83%A8%E1%83%94%E1%83%90%E1%83%A1%E1%83%A0%E1%83%A3%E1%83%9A%E1%83%90%20%E1%83%A2%E1%83%9D%E1%83%9B.)
^ka-Q0781-answer

**ka-Q0782** — მე ვერ შეასრულა ტომ.

I couldn't stop Tom.

Expected form: **მე**

Why: Independent pronouns. [[Georgian#^ka-Q0782|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%95%E1%83%94%E1%83%A0%20%E1%83%A8%E1%83%94%E1%83%90%E1%83%A1%E1%83%A0%E1%83%A3%E1%83%9A%E1%83%90%20%E1%83%A2%E1%83%9D%E1%83%9B.)
^ka-Q0782-answer

**ka-Q0783** — მე ცალთვალა ვარ.

I'm one-eyed.

Expected form: **მე**

Why: Independent pronouns. [[Georgian#^ka-Q0783|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%AA%E1%83%90%E1%83%9A%E1%83%97%E1%83%95%E1%83%90%E1%83%9A%E1%83%90%20%E1%83%95%E1%83%90%E1%83%A0.)
^ka-Q0783-answer

**ka-Q0784** — მე ცალთვალა ვარ.

I'm one-eyed.

Why: Independent pronouns. [[Georgian#^ka-Q0784|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%AA%E1%83%90%E1%83%9A%E1%83%97%E1%83%95%E1%83%90%E1%83%9A%E1%83%90%20%E1%83%95%E1%83%90%E1%83%A0.)
^ka-Q0784-answer

**ka-Q0785** — შენ საქმეს მიხედე!

Mind your own business!

Why: Independent pronouns. [[Georgian#^ka-Q0785|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A8%E1%83%94%E1%83%9C%20%E1%83%A1%E1%83%90%E1%83%A5%E1%83%9B%E1%83%94%E1%83%A1%20%E1%83%9B%E1%83%98%E1%83%AE%E1%83%94%E1%83%93%E1%83%94%21)
^ka-Q0785-answer

**ka-Q0786** — შენ საქმეს მიხედე!

Mind your own business!

Pronouns identify participants; verbs often also encode participants, allowing omission. Is can refer to he/she/it without English grammatical gender. Georgian verb classes use distinct case alignments.

Why: Independent pronouns. [[Georgian#^ka-Q0786|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A8%E1%83%94%E1%83%9C%20%E1%83%A1%E1%83%90%E1%83%A5%E1%83%9B%E1%83%94%E1%83%A1%20%E1%83%9B%E1%83%98%E1%83%AE%E1%83%94%E1%83%93%E1%83%94%21)
^ka-Q0786-answer

**ka-Q0787** — მე ამ ტენის კლუბის წევრი ვარ.

I'm a member of the tennis club.

Expected form: **მე**

Why: Independent pronouns. [[Georgian#^ka-Q0787|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%90%E1%83%9B%20%E1%83%A2%E1%83%94%E1%83%9C%E1%83%98%E1%83%A1%20%E1%83%99%E1%83%9A%E1%83%A3%E1%83%91%E1%83%98%E1%83%A1%20%E1%83%AC%E1%83%94%E1%83%95%E1%83%A0%E1%83%98%20%E1%83%95%E1%83%90%E1%83%A0.)
^ka-Q0787-answer

**ka-Q0788** — მე ამ ტენის კლუბის წევრი ვარ.

I'm a member of the tennis club.

Expected form: **მე**

Why: Independent pronouns. [[Georgian#^ka-Q0788|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%90%E1%83%9B%20%E1%83%A2%E1%83%94%E1%83%9C%E1%83%98%E1%83%A1%20%E1%83%99%E1%83%9A%E1%83%A3%E1%83%91%E1%83%98%E1%83%A1%20%E1%83%AC%E1%83%94%E1%83%95%E1%83%A0%E1%83%98%20%E1%83%95%E1%83%90%E1%83%A0.)
^ka-Q0788-answer

**ka-Q0789** — ისინი ჩემი დები არიან.

They are my sisters.

Expected form: **ისინი**

Why: Independent pronouns. [[Georgian#^ka-Q0789|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%98%E1%83%A1%E1%83%98%E1%83%9C%E1%83%98%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%93%E1%83%94%E1%83%91%E1%83%98%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%90%E1%83%9C.)
^ka-Q0789-answer

**ka-Q0790** — ისინი ჩემი დები არიან.

They are my sisters.

Why: Independent pronouns. [[Georgian#^ka-Q0790|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%98%E1%83%A1%E1%83%98%E1%83%9C%E1%83%98%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%93%E1%83%94%E1%83%91%E1%83%98%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%90%E1%83%9C.)
^ka-Q0790-answer

**ka-Q0791** — ხილი და ბოსტნეული ჯანმრთელი არიან, მაგრამ ჩვენ არ ვიცით რატომ.

Fruit and vegetables are good for your health, but we don't know why.

Why: Independent pronouns. [[Georgian#^ka-Q0791|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%AE%E1%83%98%E1%83%9A%E1%83%98%20%E1%83%93%E1%83%90%20%E1%83%91%E1%83%9D%E1%83%A1%E1%83%A2%E1%83%9C%E1%83%94%E1%83%A3%E1%83%9A%E1%83%98%20%E1%83%AF%E1%83%90%E1%83%9C%E1%83%9B%E1%83%A0%E1%83%97%E1%83%94%E1%83%9A%E1%83%98%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%90%E1%83%9C%2C%20%E1%83%9B%E1%83%90%E1%83%92%E1%83%A0%E1%83%90%E1%83%9B%20%E1%83%A9%E1%83%95%E1%83%94%E1%83%9C%20%E1%83%90%E1%83%A0%20%E1%83%95%E1%83%98%E1%83%AA%E1%83%98%E1%83%97%20%E1%83%A0%E1%83%90%E1%83%A2%E1%83%9D%E1%83%9B.)
^ka-Q0791-answer

**ka-Q0792** — ხილი და ბოსტნეული ჯანმრთელი არიან, მაგრამ ჩვენ არ ვიცით რატომ.

Fruit and vegetables are good for your health, but we don't know why.

Pronouns identify participants; verbs often also encode participants, allowing omission. Is can refer to he/she/it without English grammatical gender. Georgian verb classes use distinct case alignments.

Why: Independent pronouns. [[Georgian#^ka-Q0792|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%AE%E1%83%98%E1%83%9A%E1%83%98%20%E1%83%93%E1%83%90%20%E1%83%91%E1%83%9D%E1%83%A1%E1%83%A2%E1%83%9C%E1%83%94%E1%83%A3%E1%83%9A%E1%83%98%20%E1%83%AF%E1%83%90%E1%83%9C%E1%83%9B%E1%83%A0%E1%83%97%E1%83%94%E1%83%9A%E1%83%98%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%90%E1%83%9C%2C%20%E1%83%9B%E1%83%90%E1%83%92%E1%83%A0%E1%83%90%E1%83%9B%20%E1%83%A9%E1%83%95%E1%83%94%E1%83%9C%20%E1%83%90%E1%83%A0%20%E1%83%95%E1%83%98%E1%83%AA%E1%83%98%E1%83%97%20%E1%83%A0%E1%83%90%E1%83%A2%E1%83%9D%E1%83%9B.)
^ka-Q0792-answer

**ka-Q0793** — თქვენ აქ მუშაობთ?

Do you work here?

Expected form: **თქვენ**

Why: Independent pronouns. [[Georgian#^ka-Q0793|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%97%E1%83%A5%E1%83%95%E1%83%94%E1%83%9C%20%E1%83%90%E1%83%A5%20%E1%83%9B%E1%83%A3%E1%83%A8%E1%83%90%E1%83%9D%E1%83%91%E1%83%97%3F)
^ka-Q0793-answer

**ka-Q0794** — თქვენ აქ მუშაობთ?

Do you work here?

Expected form: **თქვენ**

Why: Independent pronouns. [[Georgian#^ka-Q0794|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%97%E1%83%A5%E1%83%95%E1%83%94%E1%83%9C%20%E1%83%90%E1%83%A5%20%E1%83%9B%E1%83%A3%E1%83%A8%E1%83%90%E1%83%9D%E1%83%91%E1%83%97%3F)
^ka-Q0794-answer

**ka-Q0795** — მას მე არ უყვარვარ.

He doesn't love me.

Expected form: **მე**

Why: Independent pronouns. [[Georgian#^ka-Q0795|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%90%E1%83%A1%20%E1%83%9B%E1%83%94%20%E1%83%90%E1%83%A0%20%E1%83%A3%E1%83%A7%E1%83%95%E1%83%90%E1%83%A0%E1%83%95%E1%83%90%E1%83%A0.)
^ka-Q0795-answer

**ka-Q0796** — მას მე არ უყვარვარ.

He doesn't love me.

Why: Independent pronouns. [[Georgian#^ka-Q0796|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%90%E1%83%A1%20%E1%83%9B%E1%83%94%20%E1%83%90%E1%83%A0%20%E1%83%A3%E1%83%A7%E1%83%95%E1%83%90%E1%83%A0%E1%83%95%E1%83%90%E1%83%A0.)
^ka-Q0796-answer

**ka-Q0797** — მე მოგცემ საჩუქარს.

I'll give you a present.

Why: Independent pronouns. [[Georgian#^ka-Q0797|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%9B%E1%83%9D%E1%83%92%E1%83%AA%E1%83%94%E1%83%9B%20%E1%83%A1%E1%83%90%E1%83%A9%E1%83%A3%E1%83%A5%E1%83%90%E1%83%A0%E1%83%A1.)
^ka-Q0797-answer

**ka-Q0798** — მე მოგცემ საჩუქარს.

I'll give you a present.

Pronouns identify participants; verbs often also encode participants, allowing omission. Is can refer to he/she/it without English grammatical gender. Georgian verb classes use distinct case alignments.

Why: Independent pronouns. [[Georgian#^ka-Q0798|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%9B%E1%83%9D%E1%83%92%E1%83%AA%E1%83%94%E1%83%9B%20%E1%83%A1%E1%83%90%E1%83%A9%E1%83%A3%E1%83%A5%E1%83%90%E1%83%A0%E1%83%A1.)
^ka-Q0798-answer

**ka-Q0799** — მე მოგიტან შენ.

I'll bring you.

Expected form: **მე**

Why: Independent pronouns. [[Georgian#^ka-Q0799|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%9B%E1%83%9D%E1%83%92%E1%83%98%E1%83%A2%E1%83%90%E1%83%9C%20%E1%83%A8%E1%83%94%E1%83%9C.)
^ka-Q0799-answer

**ka-Q0800** — მე მოგიტან შენ.

I'll bring you.

Expected form: **მე**

Why: Independent pronouns. [[Georgian#^ka-Q0800|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%9B%E1%83%9D%E1%83%92%E1%83%98%E1%83%A2%E1%83%90%E1%83%9C%20%E1%83%A8%E1%83%94%E1%83%9C.)
^ka-Q0800-answer


### Answers 801–850

**ka-Q0801** — მითხრა, ვინ არის ეს ვაჟი?

Tell me; who is this young man?

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0801|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%98%E1%83%97%E1%83%AE%E1%83%A0%E1%83%90%2C%20%E1%83%95%E1%83%98%E1%83%9C%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%94%E1%83%A1%20%E1%83%95%E1%83%90%E1%83%9F%E1%83%98%3F)
^ka-Q0801-answer

**ka-Q0802** — მითხრა, ვინ არის ეს ვაჟი?

Tell me; who is this young man?

Why: Independent pronouns. [[Georgian#^ka-Q0802|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%98%E1%83%97%E1%83%AE%E1%83%A0%E1%83%90%2C%20%E1%83%95%E1%83%98%E1%83%9C%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%94%E1%83%A1%20%E1%83%95%E1%83%90%E1%83%9F%E1%83%98%3F)
^ka-Q0802-answer

**ka-Q0803** — მე მგონი ტომი ბოსტონში ცხოვრობს.

I think Tom lives in Boston.

Why: Independent pronouns. [[Georgian#^ka-Q0803|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%9B%E1%83%92%E1%83%9D%E1%83%9C%E1%83%98%20%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%98%20%E1%83%91%E1%83%9D%E1%83%A1%E1%83%A2%E1%83%9D%E1%83%9C%E1%83%A8%E1%83%98%20%E1%83%AA%E1%83%AE%E1%83%9D%E1%83%95%E1%83%A0%E1%83%9D%E1%83%91%E1%83%A1.)
^ka-Q0803-answer

**ka-Q0804** — მე მგონი ტომი ბოსტონში ცხოვრობს.

I think Tom lives in Boston.

Pronouns identify participants; verbs often also encode participants, allowing omission. Is can refer to he/she/it without English grammatical gender. Georgian verb classes use distinct case alignments.

Why: Independent pronouns. [[Georgian#^ka-Q0804|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%9B%E1%83%92%E1%83%9D%E1%83%9C%E1%83%98%20%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%98%20%E1%83%91%E1%83%9D%E1%83%A1%E1%83%A2%E1%83%9D%E1%83%9C%E1%83%A8%E1%83%98%20%E1%83%AA%E1%83%AE%E1%83%9D%E1%83%95%E1%83%A0%E1%83%9D%E1%83%91%E1%83%A1.)
^ka-Q0804-answer

**ka-Q0805** — ეს წიგნები ჩემი დის არიან.

Those are my sister's books.

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0805|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%94%E1%83%A1%20%E1%83%AC%E1%83%98%E1%83%92%E1%83%9C%E1%83%94%E1%83%91%E1%83%98%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%93%E1%83%98%E1%83%A1%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%90%E1%83%9C.)
^ka-Q0805-answer

**ka-Q0806** — ეს წიგნები ჩემი დის არიან.

Those are my sister's books.

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0806|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%94%E1%83%A1%20%E1%83%AC%E1%83%98%E1%83%92%E1%83%9C%E1%83%94%E1%83%91%E1%83%98%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%93%E1%83%98%E1%83%A1%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%90%E1%83%9C.)
^ka-Q0806-answer

**ka-Q0807** — ტომი არ არის შიგნით.

Tom's not in.

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0807|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%98%20%E1%83%90%E1%83%A0%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%A8%E1%83%98%E1%83%92%E1%83%9C%E1%83%98%E1%83%97.)
^ka-Q0807-answer

**ka-Q0808** — ტომი არ არის შიგნით.

Tom's not in.

Why: Independent pronouns. [[Georgian#^ka-Q0808|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%98%20%E1%83%90%E1%83%A0%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%A8%E1%83%98%E1%83%92%E1%83%9C%E1%83%98%E1%83%97.)
^ka-Q0808-answer

**ka-Q0809** — მე უბრალოდ მინდოდა შენი გაბედნიერება.

I just wanted to make you happy.

Why: Independent pronouns. [[Georgian#^ka-Q0809|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%A3%E1%83%91%E1%83%A0%E1%83%90%E1%83%9A%E1%83%9D%E1%83%93%20%E1%83%9B%E1%83%98%E1%83%9C%E1%83%93%E1%83%9D%E1%83%93%E1%83%90%20%E1%83%A8%E1%83%94%E1%83%9C%E1%83%98%20%E1%83%92%E1%83%90%E1%83%91%E1%83%94%E1%83%93%E1%83%9C%E1%83%98%E1%83%94%E1%83%A0%E1%83%94%E1%83%91%E1%83%90.)
^ka-Q0809-answer

**ka-Q0810** — მე უბრალოდ მინდოდა შენი გაბედნიერება.

I just wanted to make you happy.

Pronouns identify participants; verbs often also encode participants, allowing omission. Is can refer to he/she/it without English grammatical gender. Georgian verb classes use distinct case alignments.

Why: Independent pronouns. [[Georgian#^ka-Q0810|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%A3%E1%83%91%E1%83%A0%E1%83%90%E1%83%9A%E1%83%9D%E1%83%93%20%E1%83%9B%E1%83%98%E1%83%9C%E1%83%93%E1%83%9D%E1%83%93%E1%83%90%20%E1%83%A8%E1%83%94%E1%83%9C%E1%83%98%20%E1%83%92%E1%83%90%E1%83%91%E1%83%94%E1%83%93%E1%83%9C%E1%83%98%E1%83%94%E1%83%A0%E1%83%94%E1%83%91%E1%83%90.)
^ka-Q0810-answer

**ka-Q0811** — ეს არის ტელევიზორი.

This is a television.

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0811|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%94%E1%83%A1%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%A2%E1%83%94%E1%83%9A%E1%83%94%E1%83%95%E1%83%98%E1%83%96%E1%83%9D%E1%83%A0%E1%83%98.)
^ka-Q0811-answer

**ka-Q0812** — ეს არის ტელევიზორი.

This is a television.

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0812|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%94%E1%83%A1%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%A2%E1%83%94%E1%83%9A%E1%83%94%E1%83%95%E1%83%98%E1%83%96%E1%83%9D%E1%83%A0%E1%83%98.)
^ka-Q0812-answer

**ka-Q0813** — ხვალ ვინ მიდის ქალაქში?

Who is going into the city tomorrow?

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0813|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%AE%E1%83%95%E1%83%90%E1%83%9A%20%E1%83%95%E1%83%98%E1%83%9C%20%E1%83%9B%E1%83%98%E1%83%93%E1%83%98%E1%83%A1%20%E1%83%A5%E1%83%90%E1%83%9A%E1%83%90%E1%83%A5%E1%83%A8%E1%83%98%3F)
^ka-Q0813-answer

**ka-Q0814** — ხვალ ვინ მიდის ქალაქში?

Who is going into the city tomorrow?

Why: Independent pronouns. [[Georgian#^ka-Q0814|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%AE%E1%83%95%E1%83%90%E1%83%9A%20%E1%83%95%E1%83%98%E1%83%9C%20%E1%83%9B%E1%83%98%E1%83%93%E1%83%98%E1%83%A1%20%E1%83%A5%E1%83%90%E1%83%9A%E1%83%90%E1%83%A5%E1%83%A8%E1%83%98%3F)
^ka-Q0814-answer

**ka-Q0815** — ცხენი არ არის თეთრი.

The horse is not white.

Why: Independent pronouns. [[Georgian#^ka-Q0815|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%AA%E1%83%AE%E1%83%94%E1%83%9C%E1%83%98%20%E1%83%90%E1%83%A0%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%97%E1%83%94%E1%83%97%E1%83%A0%E1%83%98.)
^ka-Q0815-answer

**ka-Q0816** — ცხენი არ არის თეთრი.

The horse is not white.

Pronouns identify participants; verbs often also encode participants, allowing omission. Is can refer to he/she/it without English grammatical gender. Georgian verb classes use distinct case alignments.

Why: Independent pronouns. [[Georgian#^ka-Q0816|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%AA%E1%83%AE%E1%83%94%E1%83%9C%E1%83%98%20%E1%83%90%E1%83%A0%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%97%E1%83%94%E1%83%97%E1%83%A0%E1%83%98.)
^ka-Q0816-answer

**ka-Q0817** — ყოველთვის ვუყურებ ამ სურათს მორყვნით.

I always view this photo with disgust.

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0817|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A7%E1%83%9D%E1%83%95%E1%83%94%E1%83%9A%E1%83%97%E1%83%95%E1%83%98%E1%83%A1%20%E1%83%95%E1%83%A3%E1%83%A7%E1%83%A3%E1%83%A0%E1%83%94%E1%83%91%20%E1%83%90%E1%83%9B%20%E1%83%A1%E1%83%A3%E1%83%A0%E1%83%90%E1%83%97%E1%83%A1%20%E1%83%9B%E1%83%9D%E1%83%A0%E1%83%A7%E1%83%95%E1%83%9C%E1%83%98%E1%83%97.)
^ka-Q0817-answer

**ka-Q0818** — ყოველთვის ვუყურებ ამ სურათს მორყვნით.

I always view this photo with disgust.

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0818|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A7%E1%83%9D%E1%83%95%E1%83%94%E1%83%9A%E1%83%97%E1%83%95%E1%83%98%E1%83%A1%20%E1%83%95%E1%83%A3%E1%83%A7%E1%83%A3%E1%83%A0%E1%83%94%E1%83%91%20%E1%83%90%E1%83%9B%20%E1%83%A1%E1%83%A3%E1%83%A0%E1%83%90%E1%83%97%E1%83%A1%20%E1%83%9B%E1%83%9D%E1%83%A0%E1%83%A7%E1%83%95%E1%83%9C%E1%83%98%E1%83%97.)
^ka-Q0818-answer

**ka-Q0819** — სად არის სასტუმრო?

Where is the hotel?

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0819|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A1%E1%83%90%E1%83%93%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%A1%E1%83%90%E1%83%A1%E1%83%A2%E1%83%A3%E1%83%9B%E1%83%A0%E1%83%9D%3F)
^ka-Q0819-answer

**ka-Q0820** — სად არის სასტუმრო?

Where is the hotel?

Why: Independent pronouns. [[Georgian#^ka-Q0820|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A1%E1%83%90%E1%83%93%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%A1%E1%83%90%E1%83%A1%E1%83%A2%E1%83%A3%E1%83%9B%E1%83%A0%E1%83%9D%3F)
^ka-Q0820-answer

**ka-Q0821** — შენ რა უპასუხე?

What did you answer?

Why: Independent pronouns. [[Georgian#^ka-Q0821|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A8%E1%83%94%E1%83%9C%20%E1%83%A0%E1%83%90%20%E1%83%A3%E1%83%9E%E1%83%90%E1%83%A1%E1%83%A3%E1%83%AE%E1%83%94%3F)
^ka-Q0821-answer

**ka-Q0822** — შენ რა უპასუხე?

What did you answer?

Pronouns identify participants; verbs often also encode participants, allowing omission. Is can refer to he/she/it without English grammatical gender. Georgian verb classes use distinct case alignments.

Why: Independent pronouns. [[Georgian#^ka-Q0822|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A8%E1%83%94%E1%83%9C%20%E1%83%A0%E1%83%90%20%E1%83%A3%E1%83%9E%E1%83%90%E1%83%A1%E1%83%A3%E1%83%AE%E1%83%94%3F)
^ka-Q0822-answer

**ka-Q0823** — მე არ ვიცი იაპონურად ლაპარაკი.

I don't speak Japanese.

Expected form: **მე**

Why: Independent pronouns. [[Georgian#^ka-Q0823|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%90%E1%83%A0%20%E1%83%95%E1%83%98%E1%83%AA%E1%83%98%20%E1%83%98%E1%83%90%E1%83%9E%E1%83%9D%E1%83%9C%E1%83%A3%E1%83%A0%E1%83%90%E1%83%93%20%E1%83%9A%E1%83%90%E1%83%9E%E1%83%90%E1%83%A0%E1%83%90%E1%83%99%E1%83%98.)
^ka-Q0823-answer

**ka-Q0824** — მე არ ვიცი იაპონურად ლაპარაკი.

I don't speak Japanese.

Expected form: **მე**

Why: Independent pronouns. [[Georgian#^ka-Q0824|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%90%E1%83%A0%20%E1%83%95%E1%83%98%E1%83%AA%E1%83%98%20%E1%83%98%E1%83%90%E1%83%9E%E1%83%9D%E1%83%9C%E1%83%A3%E1%83%A0%E1%83%90%E1%83%93%20%E1%83%9A%E1%83%90%E1%83%9E%E1%83%90%E1%83%A0%E1%83%90%E1%83%99%E1%83%98.)
^ka-Q0824-answer

**ka-Q0825** — ის პლაჟები აქედან შორსაა.

Those beaches are far from here.

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0825|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%98%E1%83%A1%20%E1%83%9E%E1%83%9A%E1%83%90%E1%83%9F%E1%83%94%E1%83%91%E1%83%98%20%E1%83%90%E1%83%A5%E1%83%94%E1%83%93%E1%83%90%E1%83%9C%20%E1%83%A8%E1%83%9D%E1%83%A0%E1%83%A1%E1%83%90%E1%83%90.)
^ka-Q0825-answer

**ka-Q0826** — ის პლაჟები აქედან შორსაა.

Those beaches are far from here.

Why: Independent pronouns. [[Georgian#^ka-Q0826|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%98%E1%83%A1%20%E1%83%9E%E1%83%9A%E1%83%90%E1%83%9F%E1%83%94%E1%83%91%E1%83%98%20%E1%83%90%E1%83%A5%E1%83%94%E1%83%93%E1%83%90%E1%83%9C%20%E1%83%A8%E1%83%9D%E1%83%A0%E1%83%A1%E1%83%90%E1%83%90.)
^ka-Q0826-answer

**ka-Q0827** — მე ვარ იგივე ნავში.

I'm in the same boat.

Why: Independent pronouns. [[Georgian#^ka-Q0827|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%95%E1%83%90%E1%83%A0%20%E1%83%98%E1%83%92%E1%83%98%E1%83%95%E1%83%94%20%E1%83%9C%E1%83%90%E1%83%95%E1%83%A8%E1%83%98.)
^ka-Q0827-answer

**ka-Q0828** — მე ვარ იგივე ნავში.

I'm in the same boat.

Pronouns identify participants; verbs often also encode participants, allowing omission. Is can refer to he/she/it without English grammatical gender. Georgian verb classes use distinct case alignments.

Why: Independent pronouns. [[Georgian#^ka-Q0828|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%95%E1%83%90%E1%83%A0%20%E1%83%98%E1%83%92%E1%83%98%E1%83%95%E1%83%94%20%E1%83%9C%E1%83%90%E1%83%95%E1%83%A8%E1%83%98.)
^ka-Q0828-answer

**ka-Q0829** — მე მიყვარს დონატები

I like doughnuts.

Expected form: **მე**

Why: Independent pronouns. [[Georgian#^ka-Q0829|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%9B%E1%83%98%E1%83%A7%E1%83%95%E1%83%90%E1%83%A0%E1%83%A1%20%E1%83%93%E1%83%9D%E1%83%9C%E1%83%90%E1%83%A2%E1%83%94%E1%83%91%E1%83%98)
^ka-Q0829-answer

**ka-Q0830** — მე მიყვარს დონატები

I like doughnuts.

Expected form: **მე**

Why: Independent pronouns. [[Georgian#^ka-Q0830|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%9B%E1%83%98%E1%83%A7%E1%83%95%E1%83%90%E1%83%A0%E1%83%A1%20%E1%83%93%E1%83%9D%E1%83%9C%E1%83%90%E1%83%A2%E1%83%94%E1%83%91%E1%83%98)
^ka-Q0830-answer

**ka-Q0831** — ვაშლის ტორტს ჭამა მინდა.

I want to eat apple pie.

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0831|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%95%E1%83%90%E1%83%A8%E1%83%9A%E1%83%98%E1%83%A1%20%E1%83%A2%E1%83%9D%E1%83%A0%E1%83%A2%E1%83%A1%20%E1%83%AD%E1%83%90%E1%83%9B%E1%83%90%20%E1%83%9B%E1%83%98%E1%83%9C%E1%83%93%E1%83%90.)
^ka-Q0831-answer

**ka-Q0832** — ვაშლის ტორტს ჭამა მინდა.

I want to eat apple pie.

Why: Independent pronouns. [[Georgian#^ka-Q0832|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%95%E1%83%90%E1%83%A8%E1%83%9A%E1%83%98%E1%83%A1%20%E1%83%A2%E1%83%9D%E1%83%A0%E1%83%A2%E1%83%A1%20%E1%83%AD%E1%83%90%E1%83%9B%E1%83%90%20%E1%83%9B%E1%83%98%E1%83%9C%E1%83%93%E1%83%90.)
^ka-Q0832-answer

**ka-Q0833** — „სად ცხოვრობ შენ?“ „მე ტოკიოში ვცხოვრობ.“

"Where do you live?" "I live in Tokyo."

Why: Independent pronouns. [[Georgian#^ka-Q0833|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E2%80%9E%E1%83%A1%E1%83%90%E1%83%93%20%E1%83%AA%E1%83%AE%E1%83%9D%E1%83%95%E1%83%A0%E1%83%9D%E1%83%91%20%E1%83%A8%E1%83%94%E1%83%9C%3F%E2%80%9C%20%E2%80%9E%E1%83%9B%E1%83%94%20%E1%83%A2%E1%83%9D%E1%83%99%E1%83%98%E1%83%9D%E1%83%A8%E1%83%98%20%E1%83%95%E1%83%AA%E1%83%AE%E1%83%9D%E1%83%95%E1%83%A0%E1%83%9D%E1%83%91.%E2%80%9C)
^ka-Q0833-answer

**ka-Q0834** — „სად ცხოვრობ შენ?“ „მე ტოკიოში ვცხოვრობ.“

"Where do you live?" "I live in Tokyo."

Pronouns identify participants; verbs often also encode participants, allowing omission. Is can refer to he/she/it without English grammatical gender. Georgian verb classes use distinct case alignments.

Why: Independent pronouns. [[Georgian#^ka-Q0834|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E2%80%9E%E1%83%A1%E1%83%90%E1%83%93%20%E1%83%AA%E1%83%AE%E1%83%9D%E1%83%95%E1%83%A0%E1%83%9D%E1%83%91%20%E1%83%A8%E1%83%94%E1%83%9C%3F%E2%80%9C%20%E2%80%9E%E1%83%9B%E1%83%94%20%E1%83%A2%E1%83%9D%E1%83%99%E1%83%98%E1%83%9D%E1%83%A8%E1%83%98%20%E1%83%95%E1%83%AA%E1%83%AE%E1%83%9D%E1%83%95%E1%83%A0%E1%83%9D%E1%83%91.%E2%80%9C)
^ka-Q0834-answer

**ka-Q0835** — მე შენ მიყვარხარ.

I love you.

Expected form: **მე**

Why: Independent pronouns. [[Georgian#^ka-Q0835|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%A8%E1%83%94%E1%83%9C%20%E1%83%9B%E1%83%98%E1%83%A7%E1%83%95%E1%83%90%E1%83%A0%E1%83%AE%E1%83%90%E1%83%A0.)
^ka-Q0835-answer

**ka-Q0836** — მე შენ მიყვარხარ.

I love you.

Expected form: **მე**

Why: Independent pronouns. [[Georgian#^ka-Q0836|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%A8%E1%83%94%E1%83%9C%20%E1%83%9B%E1%83%98%E1%83%A7%E1%83%95%E1%83%90%E1%83%A0%E1%83%AE%E1%83%90%E1%83%A0.)
^ka-Q0836-answer

**ka-Q0837** — ისინი ვაშლებს ჭამენ.

They're eating the apples.

Expected form: **ისინი**

Why: Independent pronouns. [[Georgian#^ka-Q0837|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%98%E1%83%A1%E1%83%98%E1%83%9C%E1%83%98%20%E1%83%95%E1%83%90%E1%83%A8%E1%83%9A%E1%83%94%E1%83%91%E1%83%A1%20%E1%83%AD%E1%83%90%E1%83%9B%E1%83%94%E1%83%9C.)
^ka-Q0837-answer

**ka-Q0838** — ისინი ვაშლებს ჭამენ.

They're eating the apples.

Why: Independent pronouns. [[Georgian#^ka-Q0838|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%98%E1%83%A1%E1%83%98%E1%83%9C%E1%83%98%20%E1%83%95%E1%83%90%E1%83%A8%E1%83%9A%E1%83%94%E1%83%91%E1%83%A1%20%E1%83%AD%E1%83%90%E1%83%9B%E1%83%94%E1%83%9C.)
^ka-Q0838-answer

**ka-Q0839** — ის სახლის კაცია.

He's the man of the house.

Why: Independent pronouns. [[Georgian#^ka-Q0839|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%98%E1%83%A1%20%E1%83%A1%E1%83%90%E1%83%AE%E1%83%9A%E1%83%98%E1%83%A1%20%E1%83%99%E1%83%90%E1%83%AA%E1%83%98%E1%83%90.)
^ka-Q0839-answer

**ka-Q0840** — ის სახლის კაცია.

He's the man of the house.

Pronouns identify participants; verbs often also encode participants, allowing omission. Is can refer to he/she/it without English grammatical gender. Georgian verb classes use distinct case alignments.

Why: Independent pronouns. [[Georgian#^ka-Q0840|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%98%E1%83%A1%20%E1%83%A1%E1%83%90%E1%83%AE%E1%83%9A%E1%83%98%E1%83%A1%20%E1%83%99%E1%83%90%E1%83%AA%E1%83%98%E1%83%90.)
^ka-Q0840-answer

**ka-Q0841** — ჩემი გადაწყვეტილების საზღვარგარეთ სწავლის გაკვირვებული ჩემი მშობლები.

My decision to study abroad surprised my parents.

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0841|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%92%E1%83%90%E1%83%93%E1%83%90%E1%83%AC%E1%83%A7%E1%83%95%E1%83%94%E1%83%A2%E1%83%98%E1%83%9A%E1%83%94%E1%83%91%E1%83%98%E1%83%A1%20%E1%83%A1%E1%83%90%E1%83%96%E1%83%A6%E1%83%95%E1%83%90%E1%83%A0%E1%83%92%E1%83%90%E1%83%A0%E1%83%94%E1%83%97%20%E1%83%A1%E1%83%AC%E1%83%90%E1%83%95%E1%83%9A%E1%83%98%E1%83%A1%20%E1%83%92%E1%83%90%E1%83%99%E1%83%95%E1%83%98%E1%83%A0%E1%83%95%E1%83%94%E1%83%91%E1%83%A3%E1%83%9A%E1%83%98%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%9B%E1%83%A8%E1%83%9D%E1%83%91%E1%83%9A%E1%83%94%E1%83%91%E1%83%98.)
^ka-Q0841-answer

**ka-Q0842** — ჩემი გადაწყვეტილების საზღვარგარეთ სწავლის გაკვირვებული ჩემი მშობლები.

My decision to study abroad surprised my parents.

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0842|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%92%E1%83%90%E1%83%93%E1%83%90%E1%83%AC%E1%83%A7%E1%83%95%E1%83%94%E1%83%A2%E1%83%98%E1%83%9A%E1%83%94%E1%83%91%E1%83%98%E1%83%A1%20%E1%83%A1%E1%83%90%E1%83%96%E1%83%A6%E1%83%95%E1%83%90%E1%83%A0%E1%83%92%E1%83%90%E1%83%A0%E1%83%94%E1%83%97%20%E1%83%A1%E1%83%AC%E1%83%90%E1%83%95%E1%83%9A%E1%83%98%E1%83%A1%20%E1%83%92%E1%83%90%E1%83%99%E1%83%95%E1%83%98%E1%83%A0%E1%83%95%E1%83%94%E1%83%91%E1%83%A3%E1%83%9A%E1%83%98%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%9B%E1%83%A8%E1%83%9D%E1%83%91%E1%83%9A%E1%83%94%E1%83%91%E1%83%98.)
^ka-Q0842-answer

**ka-Q0843** — მე ტურისტულ სააგენტოში ვმუშაობ.

I work in a tourist agency.

Expected form: **მე**

Why: Independent pronouns. [[Georgian#^ka-Q0843|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%A2%E1%83%A3%E1%83%A0%E1%83%98%E1%83%A1%E1%83%A2%E1%83%A3%E1%83%9A%20%E1%83%A1%E1%83%90%E1%83%90%E1%83%92%E1%83%94%E1%83%9C%E1%83%A2%E1%83%9D%E1%83%A8%E1%83%98%20%E1%83%95%E1%83%9B%E1%83%A3%E1%83%A8%E1%83%90%E1%83%9D%E1%83%91.)
^ka-Q0843-answer

**ka-Q0844** — მე ტურისტულ სააგენტოში ვმუშაობ.

I work in a tourist agency.

Why: Independent pronouns. [[Georgian#^ka-Q0844|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%A2%E1%83%A3%E1%83%A0%E1%83%98%E1%83%A1%E1%83%A2%E1%83%A3%E1%83%9A%20%E1%83%A1%E1%83%90%E1%83%90%E1%83%92%E1%83%94%E1%83%9C%E1%83%A2%E1%83%9D%E1%83%A8%E1%83%98%20%E1%83%95%E1%83%9B%E1%83%A3%E1%83%A8%E1%83%90%E1%83%9D%E1%83%91.)
^ka-Q0844-answer

**ka-Q0845** — ეს ახალი ერის დასაწყისია.

This is the beginning of a new era.

Why: Independent pronouns. [[Georgian#^ka-Q0845|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%94%E1%83%A1%20%E1%83%90%E1%83%AE%E1%83%90%E1%83%9A%E1%83%98%20%E1%83%94%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%93%E1%83%90%E1%83%A1%E1%83%90%E1%83%AC%E1%83%A7%E1%83%98%E1%83%A1%E1%83%98%E1%83%90.)
^ka-Q0845-answer

**ka-Q0846** — ეს ახალი ერის დასაწყისია.

This is the beginning of a new era.

Pronouns identify participants; verbs often also encode participants, allowing omission. Is can refer to he/she/it without English grammatical gender. Georgian verb classes use distinct case alignments.

Why: Independent pronouns. [[Georgian#^ka-Q0846|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%94%E1%83%A1%20%E1%83%90%E1%83%AE%E1%83%90%E1%83%9A%E1%83%98%20%E1%83%94%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%93%E1%83%90%E1%83%A1%E1%83%90%E1%83%AC%E1%83%A7%E1%83%98%E1%83%A1%E1%83%98%E1%83%90.)
^ka-Q0846-answer

**ka-Q0847** — იმის გამო ინგლისურს სწავლობენ.

That is what they study English for.

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0847|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%98%E1%83%9B%E1%83%98%E1%83%A1%20%E1%83%92%E1%83%90%E1%83%9B%E1%83%9D%20%E1%83%98%E1%83%9C%E1%83%92%E1%83%9A%E1%83%98%E1%83%A1%E1%83%A3%E1%83%A0%E1%83%A1%20%E1%83%A1%E1%83%AC%E1%83%90%E1%83%95%E1%83%9A%E1%83%9D%E1%83%91%E1%83%94%E1%83%9C.)
^ka-Q0847-answer

**ka-Q0848** — იმის გამო ინგლისურს სწავლობენ.

That is what they study English for.

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0848|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%98%E1%83%9B%E1%83%98%E1%83%A1%20%E1%83%92%E1%83%90%E1%83%9B%E1%83%9D%20%E1%83%98%E1%83%9C%E1%83%92%E1%83%9A%E1%83%98%E1%83%A1%E1%83%A3%E1%83%A0%E1%83%A1%20%E1%83%A1%E1%83%AC%E1%83%90%E1%83%95%E1%83%9A%E1%83%9D%E1%83%91%E1%83%94%E1%83%9C.)
^ka-Q0848-answer

**ka-Q0849** — მე წიგნს ვწერ.

I'm writing a book.

Expected form: **მე**

Why: Independent pronouns. [[Georgian#^ka-Q0849|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%AC%E1%83%98%E1%83%92%E1%83%9C%E1%83%A1%20%E1%83%95%E1%83%AC%E1%83%94%E1%83%A0.)
^ka-Q0849-answer

**ka-Q0850** — მე წიგნს ვწერ.

I'm writing a book.

Why: Independent pronouns. [[Georgian#^ka-Q0850|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%AC%E1%83%98%E1%83%92%E1%83%9C%E1%83%A1%20%E1%83%95%E1%83%AC%E1%83%94%E1%83%A0.)
^ka-Q0850-answer


### Answers 851–900

**ka-Q0851** — თქვენ აქ ცხოვრობთ?

Do you live here?

Why: Independent pronouns. [[Georgian#^ka-Q0851|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%97%E1%83%A5%E1%83%95%E1%83%94%E1%83%9C%20%E1%83%90%E1%83%A5%20%E1%83%AA%E1%83%AE%E1%83%9D%E1%83%95%E1%83%A0%E1%83%9D%E1%83%91%E1%83%97%3F)
^ka-Q0851-answer

**ka-Q0852** — თქვენ აქ ცხოვრობთ?

Do you live here?

Pronouns identify participants; verbs often also encode participants, allowing omission. Is can refer to he/she/it without English grammatical gender. Georgian verb classes use distinct case alignments.

Why: Independent pronouns. [[Georgian#^ka-Q0852|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%97%E1%83%A5%E1%83%95%E1%83%94%E1%83%9C%20%E1%83%90%E1%83%A5%20%E1%83%AA%E1%83%AE%E1%83%9D%E1%83%95%E1%83%A0%E1%83%9D%E1%83%91%E1%83%97%3F)
^ka-Q0852-answer

**ka-Q0853** — მე მუშაობა არ მინდა ასეთ პირობებში.

I don't want to work under these conditions.

Expected form: **მე**

Why: Independent pronouns. [[Georgian#^ka-Q0853|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%9B%E1%83%A3%E1%83%A8%E1%83%90%E1%83%9D%E1%83%91%E1%83%90%20%E1%83%90%E1%83%A0%20%E1%83%9B%E1%83%98%E1%83%9C%E1%83%93%E1%83%90%20%E1%83%90%E1%83%A1%E1%83%94%E1%83%97%20%E1%83%9E%E1%83%98%E1%83%A0%E1%83%9D%E1%83%91%E1%83%94%E1%83%91%E1%83%A8%E1%83%98.)
^ka-Q0853-answer

**ka-Q0854** — მე მუშაობა არ მინდა ასეთ პირობებში.

I don't want to work under these conditions.

Expected form: **მე**

Why: Independent pronouns. [[Georgian#^ka-Q0854|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%9B%E1%83%A3%E1%83%A8%E1%83%90%E1%83%9D%E1%83%91%E1%83%90%20%E1%83%90%E1%83%A0%20%E1%83%9B%E1%83%98%E1%83%9C%E1%83%93%E1%83%90%20%E1%83%90%E1%83%A1%E1%83%94%E1%83%97%20%E1%83%9E%E1%83%98%E1%83%A0%E1%83%9D%E1%83%91%E1%83%94%E1%83%91%E1%83%A8%E1%83%98.)
^ka-Q0854-answer

**ka-Q0855** — მეგობრობის სადღეგრძელო დავლიოთ!

Cheers!

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0855|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%E1%83%92%E1%83%9D%E1%83%91%E1%83%A0%E1%83%9D%E1%83%91%E1%83%98%E1%83%A1%20%E1%83%A1%E1%83%90%E1%83%93%E1%83%A6%E1%83%94%E1%83%92%E1%83%A0%E1%83%AB%E1%83%94%E1%83%9A%E1%83%9D%20%E1%83%93%E1%83%90%E1%83%95%E1%83%9A%E1%83%98%E1%83%9D%E1%83%97%21)
^ka-Q0855-answer

**ka-Q0856** — მეგობრობის სადღეგრძელო დავლიოთ!

Cheers!

Why: Independent pronouns. [[Georgian#^ka-Q0856|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%E1%83%92%E1%83%9D%E1%83%91%E1%83%A0%E1%83%9D%E1%83%91%E1%83%98%E1%83%A1%20%E1%83%A1%E1%83%90%E1%83%93%E1%83%A6%E1%83%94%E1%83%92%E1%83%A0%E1%83%AB%E1%83%94%E1%83%9A%E1%83%9D%20%E1%83%93%E1%83%90%E1%83%95%E1%83%9A%E1%83%98%E1%83%9D%E1%83%97%21)
^ka-Q0856-answer

**ka-Q0857** — ის ამბობს, რომ გიცნობს.

He says that he knows you.

Why: Independent pronouns. [[Georgian#^ka-Q0857|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%98%E1%83%A1%20%E1%83%90%E1%83%9B%E1%83%91%E1%83%9D%E1%83%91%E1%83%A1%2C%20%E1%83%A0%E1%83%9D%E1%83%9B%20%E1%83%92%E1%83%98%E1%83%AA%E1%83%9C%E1%83%9D%E1%83%91%E1%83%A1.)
^ka-Q0857-answer

**ka-Q0858** — ის ამბობს, რომ გიცნობს.

He says that he knows you.

Pronouns identify participants; verbs often also encode participants, allowing omission. Is can refer to he/she/it without English grammatical gender. Georgian verb classes use distinct case alignments.

Why: Independent pronouns. [[Georgian#^ka-Q0858|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%98%E1%83%A1%20%E1%83%90%E1%83%9B%E1%83%91%E1%83%9D%E1%83%91%E1%83%A1%2C%20%E1%83%A0%E1%83%9D%E1%83%9B%20%E1%83%92%E1%83%98%E1%83%AA%E1%83%9C%E1%83%9D%E1%83%91%E1%83%A1.)
^ka-Q0858-answer

**ka-Q0859** — მე ბანკში ვმუშაობ.

I work in a bank.

Expected form: **მე**

Why: Independent pronouns. [[Georgian#^ka-Q0859|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%91%E1%83%90%E1%83%9C%E1%83%99%E1%83%A8%E1%83%98%20%E1%83%95%E1%83%9B%E1%83%A3%E1%83%A8%E1%83%90%E1%83%9D%E1%83%91.)
^ka-Q0859-answer

**ka-Q0860** — მე ბანკში ვმუშაობ.

I work in a bank.

Expected form: **მე**

Why: Independent pronouns. [[Georgian#^ka-Q0860|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%91%E1%83%90%E1%83%9C%E1%83%99%E1%83%A8%E1%83%98%20%E1%83%95%E1%83%9B%E1%83%A3%E1%83%A8%E1%83%90%E1%83%9D%E1%83%91.)
^ka-Q0860-answer

**ka-Q0861** — ჩვენ შევთანხმდით, რომ სამსახურში თავს შევიკავებდით მოწევისაგან.

We agreed to refrain from smoking while we are at work.

Expected form: **ჩვენ**

Why: Independent pronouns. [[Georgian#^ka-Q0861|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A9%E1%83%95%E1%83%94%E1%83%9C%20%E1%83%A8%E1%83%94%E1%83%95%E1%83%97%E1%83%90%E1%83%9C%E1%83%AE%E1%83%9B%E1%83%93%E1%83%98%E1%83%97%2C%20%E1%83%A0%E1%83%9D%E1%83%9B%20%E1%83%A1%E1%83%90%E1%83%9B%E1%83%A1%E1%83%90%E1%83%AE%E1%83%A3%E1%83%A0%E1%83%A8%E1%83%98%20%E1%83%97%E1%83%90%E1%83%95%E1%83%A1%20%E1%83%A8%E1%83%94%E1%83%95%E1%83%98%E1%83%99%E1%83%90%E1%83%95%E1%83%94%E1%83%91%E1%83%93%E1%83%98%E1%83%97%20%E1%83%9B%E1%83%9D%E1%83%AC%E1%83%94%E1%83%95%E1%83%98%E1%83%A1%E1%83%90%E1%83%92%E1%83%90%E1%83%9C.)
^ka-Q0861-answer

**ka-Q0862** — ჩვენ შევთანხმდით, რომ სამსახურში თავს შევიკავებდით მოწევისაგან.

We agreed to refrain from smoking while we are at work.

Why: Independent pronouns. [[Georgian#^ka-Q0862|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A9%E1%83%95%E1%83%94%E1%83%9C%20%E1%83%A8%E1%83%94%E1%83%95%E1%83%97%E1%83%90%E1%83%9C%E1%83%AE%E1%83%9B%E1%83%93%E1%83%98%E1%83%97%2C%20%E1%83%A0%E1%83%9D%E1%83%9B%20%E1%83%A1%E1%83%90%E1%83%9B%E1%83%A1%E1%83%90%E1%83%AE%E1%83%A3%E1%83%A0%E1%83%A8%E1%83%98%20%E1%83%97%E1%83%90%E1%83%95%E1%83%A1%20%E1%83%A8%E1%83%94%E1%83%95%E1%83%98%E1%83%99%E1%83%90%E1%83%95%E1%83%94%E1%83%91%E1%83%93%E1%83%98%E1%83%97%20%E1%83%9B%E1%83%9D%E1%83%AC%E1%83%94%E1%83%95%E1%83%98%E1%83%A1%E1%83%90%E1%83%92%E1%83%90%E1%83%9C.)
^ka-Q0862-answer

**ka-Q0863** — ესენი ჩემი დის წიგნები არიან.

Those are my sister's books.

Why: Independent pronouns. [[Georgian#^ka-Q0863|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%94%E1%83%A1%E1%83%94%E1%83%9C%E1%83%98%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%93%E1%83%98%E1%83%A1%20%E1%83%AC%E1%83%98%E1%83%92%E1%83%9C%E1%83%94%E1%83%91%E1%83%98%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%90%E1%83%9C.)
^ka-Q0863-answer

**ka-Q0864** — ესენი ჩემი დის წიგნები არიან.

Those are my sister's books.

Pronouns identify participants; verbs often also encode participants, allowing omission. Is can refer to he/she/it without English grammatical gender. Georgian verb classes use distinct case alignments.

Why: Independent pronouns. [[Georgian#^ka-Q0864|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%94%E1%83%A1%E1%83%94%E1%83%9C%E1%83%98%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%93%E1%83%98%E1%83%A1%20%E1%83%AC%E1%83%98%E1%83%92%E1%83%9C%E1%83%94%E1%83%91%E1%83%98%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%90%E1%83%9C.)
^ka-Q0864-answer

**ka-Q0865** — სად არის ჩემი წიგნი?

Where is my book?

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0865|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A1%E1%83%90%E1%83%93%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%AC%E1%83%98%E1%83%92%E1%83%9C%E1%83%98%3F)
^ka-Q0865-answer

**ka-Q0866** — სად არის ჩემი წიგნი?

Where is my book?

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0866|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A1%E1%83%90%E1%83%93%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%AC%E1%83%98%E1%83%92%E1%83%9C%E1%83%98%3F)
^ka-Q0866-answer

**ka-Q0867** — ტომი 15-ის იყო, მარია 14-ის. სხვა ბავშვები - მათი სახელები აღარ მახსოვს - ცოტათი უმცროსები იყვნენ.

Tom was 15, Maria 14. The other children – I can no longer remember their names – were a bit younger.

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0867|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%98%2015-%E1%83%98%E1%83%A1%20%E1%83%98%E1%83%A7%E1%83%9D%2C%20%E1%83%9B%E1%83%90%E1%83%A0%E1%83%98%E1%83%90%2014-%E1%83%98%E1%83%A1.%20%E1%83%A1%E1%83%AE%E1%83%95%E1%83%90%20%E1%83%91%E1%83%90%E1%83%95%E1%83%A8%E1%83%95%E1%83%94%E1%83%91%E1%83%98%20-%20%E1%83%9B%E1%83%90%E1%83%97%E1%83%98%20%E1%83%A1%E1%83%90%E1%83%AE%E1%83%94%E1%83%9A%E1%83%94%E1%83%91%E1%83%98%20%E1%83%90%E1%83%A6%E1%83%90%E1%83%A0%20%E1%83%9B%E1%83%90%E1%83%AE%E1%83%A1%E1%83%9D%E1%83%95%E1%83%A1%20-%20%E1%83%AA%E1%83%9D%E1%83%A2%E1%83%90%E1%83%97%E1%83%98%20%E1%83%A3%E1%83%9B%E1%83%AA%E1%83%A0%E1%83%9D%E1%83%A1%E1%83%94%E1%83%91%E1%83%98%20%E1%83%98%E1%83%A7%E1%83%95%E1%83%9C%E1%83%94%E1%83%9C.)
^ka-Q0867-answer

**ka-Q0868** — ტომი 15-ის იყო, მარია 14-ის. სხვა ბავშვები - მათი სახელები აღარ მახსოვს - ცოტათი უმცროსები იყვნენ.

Tom was 15, Maria 14. The other children – I can no longer remember their names – were a bit younger.

Why: Independent pronouns. [[Georgian#^ka-Q0868|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%98%2015-%E1%83%98%E1%83%A1%20%E1%83%98%E1%83%A7%E1%83%9D%2C%20%E1%83%9B%E1%83%90%E1%83%A0%E1%83%98%E1%83%90%2014-%E1%83%98%E1%83%A1.%20%E1%83%A1%E1%83%AE%E1%83%95%E1%83%90%20%E1%83%91%E1%83%90%E1%83%95%E1%83%A8%E1%83%95%E1%83%94%E1%83%91%E1%83%98%20-%20%E1%83%9B%E1%83%90%E1%83%97%E1%83%98%20%E1%83%A1%E1%83%90%E1%83%AE%E1%83%94%E1%83%9A%E1%83%94%E1%83%91%E1%83%98%20%E1%83%90%E1%83%A6%E1%83%90%E1%83%A0%20%E1%83%9B%E1%83%90%E1%83%AE%E1%83%A1%E1%83%9D%E1%83%95%E1%83%A1%20-%20%E1%83%AA%E1%83%9D%E1%83%A2%E1%83%90%E1%83%97%E1%83%98%20%E1%83%A3%E1%83%9B%E1%83%AA%E1%83%A0%E1%83%9D%E1%83%A1%E1%83%94%E1%83%91%E1%83%98%20%E1%83%98%E1%83%A7%E1%83%95%E1%83%9C%E1%83%94%E1%83%9C.)
^ka-Q0868-answer

**ka-Q0869** — თქვენ ექიმები ხართ.

You are doctors.

Why: Independent pronouns. [[Georgian#^ka-Q0869|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%97%E1%83%A5%E1%83%95%E1%83%94%E1%83%9C%20%E1%83%94%E1%83%A5%E1%83%98%E1%83%9B%E1%83%94%E1%83%91%E1%83%98%20%E1%83%AE%E1%83%90%E1%83%A0%E1%83%97.)
^ka-Q0869-answer

**ka-Q0870** — თქვენ ექიმები ხართ.

You are doctors.

Pronouns identify participants; verbs often also encode participants, allowing omission. Is can refer to he/she/it without English grammatical gender. Georgian verb classes use distinct case alignments.

Why: Independent pronouns. [[Georgian#^ka-Q0870|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%97%E1%83%A5%E1%83%95%E1%83%94%E1%83%9C%20%E1%83%94%E1%83%A5%E1%83%98%E1%83%9B%E1%83%94%E1%83%91%E1%83%98%20%E1%83%AE%E1%83%90%E1%83%A0%E1%83%97.)
^ka-Q0870-answer

**ka-Q0871** — ჩვენ მოვაგვარეთ პრობლემა.

We've resolved the problem.

Expected form: **ჩვენ**

Why: Independent pronouns. [[Georgian#^ka-Q0871|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A9%E1%83%95%E1%83%94%E1%83%9C%20%E1%83%9B%E1%83%9D%E1%83%95%E1%83%90%E1%83%92%E1%83%95%E1%83%90%E1%83%A0%E1%83%94%E1%83%97%20%E1%83%9E%E1%83%A0%E1%83%9D%E1%83%91%E1%83%9A%E1%83%94%E1%83%9B%E1%83%90.)
^ka-Q0871-answer

**ka-Q0872** — ჩვენ მოვაგვარეთ პრობლემა.

We've resolved the problem.

Expected form: **ჩვენ**

Why: Independent pronouns. [[Georgian#^ka-Q0872|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A9%E1%83%95%E1%83%94%E1%83%9C%20%E1%83%9B%E1%83%9D%E1%83%95%E1%83%90%E1%83%92%E1%83%95%E1%83%90%E1%83%A0%E1%83%94%E1%83%97%20%E1%83%9E%E1%83%A0%E1%83%9D%E1%83%91%E1%83%9A%E1%83%94%E1%83%9B%E1%83%90.)
^ka-Q0872-answer

**ka-Q0873** — ის იცის ჩემი ცოლს.

She knows my wife.

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0873|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%98%E1%83%A1%20%E1%83%98%E1%83%AA%E1%83%98%E1%83%A1%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%AA%E1%83%9D%E1%83%9A%E1%83%A1.)
^ka-Q0873-answer

**ka-Q0874** — ის იცის ჩემი ცოლს.

She knows my wife.

Why: Independent pronouns. [[Georgian#^ka-Q0874|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%98%E1%83%A1%20%E1%83%98%E1%83%AA%E1%83%98%E1%83%A1%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%AA%E1%83%9D%E1%83%9A%E1%83%A1.)
^ka-Q0874-answer

**ka-Q0875** — მე არა ვარ კარგი ადამიანი.

I'm not a good person.

Why: Independent pronouns. [[Georgian#^ka-Q0875|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%90%E1%83%A0%E1%83%90%20%E1%83%95%E1%83%90%E1%83%A0%20%E1%83%99%E1%83%90%E1%83%A0%E1%83%92%E1%83%98%20%E1%83%90%E1%83%93%E1%83%90%E1%83%9B%E1%83%98%E1%83%90%E1%83%9C%E1%83%98.)
^ka-Q0875-answer

**ka-Q0876** — მე არა ვარ კარგი ადამიანი.

I'm not a good person.

Pronouns identify participants; verbs often also encode participants, allowing omission. Is can refer to he/she/it without English grammatical gender. Georgian verb classes use distinct case alignments.

Why: Independent pronouns. [[Georgian#^ka-Q0876|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%90%E1%83%A0%E1%83%90%20%E1%83%95%E1%83%90%E1%83%A0%20%E1%83%99%E1%83%90%E1%83%A0%E1%83%92%E1%83%98%20%E1%83%90%E1%83%93%E1%83%90%E1%83%9B%E1%83%98%E1%83%90%E1%83%9C%E1%83%98.)
^ka-Q0876-answer

**ka-Q0877** — მე ამერიკელი ვარ.

I come from America.

Expected form: **მე**

Why: Independent pronouns. [[Georgian#^ka-Q0877|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%90%E1%83%9B%E1%83%94%E1%83%A0%E1%83%98%E1%83%99%E1%83%94%E1%83%9A%E1%83%98%20%E1%83%95%E1%83%90%E1%83%A0.)
^ka-Q0877-answer

**ka-Q0878** — მე ამერიკელი ვარ.

I come from America.

Expected form: **მე**

Why: Independent pronouns. [[Georgian#^ka-Q0878|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%90%E1%83%9B%E1%83%94%E1%83%A0%E1%83%98%E1%83%99%E1%83%94%E1%83%9A%E1%83%98%20%E1%83%95%E1%83%90%E1%83%A0.)
^ka-Q0878-answer

**ka-Q0879** — შენ ჩემთვის ყველაფერი ხარ.

You are everything to me.

Expected form: **შენ**

Why: Independent pronouns. [[Georgian#^ka-Q0879|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A8%E1%83%94%E1%83%9C%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%97%E1%83%95%E1%83%98%E1%83%A1%20%E1%83%A7%E1%83%95%E1%83%94%E1%83%9A%E1%83%90%E1%83%A4%E1%83%94%E1%83%A0%E1%83%98%20%E1%83%AE%E1%83%90%E1%83%A0.)
^ka-Q0879-answer

**ka-Q0880** — შენ ჩემთვის ყველაფერი ხარ.

You are everything to me.

Why: Independent pronouns. [[Georgian#^ka-Q0880|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A8%E1%83%94%E1%83%9C%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%97%E1%83%95%E1%83%98%E1%83%A1%20%E1%83%A7%E1%83%95%E1%83%94%E1%83%9A%E1%83%90%E1%83%A4%E1%83%94%E1%83%A0%E1%83%98%20%E1%83%AE%E1%83%90%E1%83%A0.)
^ka-Q0880-answer

**ka-Q0881** — ჩემი და არის ორი წლით უმცროსი ჩემზე.

My sister is two years younger than me.

Why: Independent pronouns. [[Georgian#^ka-Q0881|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%93%E1%83%90%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%9D%E1%83%A0%E1%83%98%20%E1%83%AC%E1%83%9A%E1%83%98%E1%83%97%20%E1%83%A3%E1%83%9B%E1%83%AA%E1%83%A0%E1%83%9D%E1%83%A1%E1%83%98%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%96%E1%83%94.)
^ka-Q0881-answer

**ka-Q0882** — ჩემი და არის ორი წლით უმცროსი ჩემზე.

My sister is two years younger than me.

Pronouns identify participants; verbs often also encode participants, allowing omission. Is can refer to he/she/it without English grammatical gender. Georgian verb classes use distinct case alignments.

Why: Independent pronouns. [[Georgian#^ka-Q0882|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%93%E1%83%90%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%9D%E1%83%A0%E1%83%98%20%E1%83%AC%E1%83%9A%E1%83%98%E1%83%97%20%E1%83%A3%E1%83%9B%E1%83%AA%E1%83%A0%E1%83%9D%E1%83%A1%E1%83%98%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%96%E1%83%94.)
^ka-Q0882-answer

**ka-Q0883** — ის ახალი სურათი არის?

Is it a recent picture?

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0883|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%98%E1%83%A1%20%E1%83%90%E1%83%AE%E1%83%90%E1%83%9A%E1%83%98%20%E1%83%A1%E1%83%A3%E1%83%A0%E1%83%90%E1%83%97%E1%83%98%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%3F)
^ka-Q0883-answer

**ka-Q0884** — ის ახალი სურათი არის?

Is it a recent picture?

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0884|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%98%E1%83%A1%20%E1%83%90%E1%83%AE%E1%83%90%E1%83%9A%E1%83%98%20%E1%83%A1%E1%83%A3%E1%83%A0%E1%83%90%E1%83%97%E1%83%98%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%3F)
^ka-Q0884-answer

**ka-Q0885** — მე არ ვარ მზად ქორწინებისთვის.

I'm not ready for marriage.

Expected form: **მე**

Why: Independent pronouns. [[Georgian#^ka-Q0885|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%90%E1%83%A0%20%E1%83%95%E1%83%90%E1%83%A0%20%E1%83%9B%E1%83%96%E1%83%90%E1%83%93%20%E1%83%A5%E1%83%9D%E1%83%A0%E1%83%AC%E1%83%98%E1%83%9C%E1%83%94%E1%83%91%E1%83%98%E1%83%A1%E1%83%97%E1%83%95%E1%83%98%E1%83%A1.)
^ka-Q0885-answer

**ka-Q0886** — მე არ ვარ მზად ქორწინებისთვის.

I'm not ready for marriage.

Why: Independent pronouns. [[Georgian#^ka-Q0886|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%90%E1%83%A0%20%E1%83%95%E1%83%90%E1%83%A0%20%E1%83%9B%E1%83%96%E1%83%90%E1%83%93%20%E1%83%A5%E1%83%9D%E1%83%A0%E1%83%AC%E1%83%98%E1%83%9C%E1%83%94%E1%83%91%E1%83%98%E1%83%A1%E1%83%97%E1%83%95%E1%83%98%E1%83%A1.)
^ka-Q0886-answer

**ka-Q0887** — მე მოგცემ ფულს.

I'll give you money.

Why: Independent pronouns. [[Georgian#^ka-Q0887|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%9B%E1%83%9D%E1%83%92%E1%83%AA%E1%83%94%E1%83%9B%20%E1%83%A4%E1%83%A3%E1%83%9A%E1%83%A1.)
^ka-Q0887-answer

**ka-Q0888** — მე მოგცემ ფულს.

I'll give you money.

Pronouns identify participants; verbs often also encode participants, allowing omission. Is can refer to he/she/it without English grammatical gender. Georgian verb classes use distinct case alignments.

Why: Independent pronouns. [[Georgian#^ka-Q0888|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%9B%E1%83%9D%E1%83%92%E1%83%AA%E1%83%94%E1%83%9B%20%E1%83%A4%E1%83%A3%E1%83%9A%E1%83%A1.)
^ka-Q0888-answer

**ka-Q0889** — მე შენ ძალიან მიყვარხარ.

I love you a lot.

Expected form: **მე**

Why: Independent pronouns. [[Georgian#^ka-Q0889|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%A8%E1%83%94%E1%83%9C%20%E1%83%AB%E1%83%90%E1%83%9A%E1%83%98%E1%83%90%E1%83%9C%20%E1%83%9B%E1%83%98%E1%83%A7%E1%83%95%E1%83%90%E1%83%A0%E1%83%AE%E1%83%90%E1%83%A0.)
^ka-Q0889-answer

**ka-Q0890** — მე შენ ძალიან მიყვარხარ.

I love you a lot.

Expected form: **მე**

Why: Independent pronouns. [[Georgian#^ka-Q0890|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%A8%E1%83%94%E1%83%9C%20%E1%83%AB%E1%83%90%E1%83%9A%E1%83%98%E1%83%90%E1%83%9C%20%E1%83%9B%E1%83%98%E1%83%A7%E1%83%95%E1%83%90%E1%83%A0%E1%83%AE%E1%83%90%E1%83%A0.)
^ka-Q0890-answer

**ka-Q0891** — მე უნდა ის გავაკეთო ახლა?

Do I have to do it now?

Expected form: **მე**

Why: Independent pronouns. [[Georgian#^ka-Q0891|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%A3%E1%83%9C%E1%83%93%E1%83%90%20%E1%83%98%E1%83%A1%20%E1%83%92%E1%83%90%E1%83%95%E1%83%90%E1%83%99%E1%83%94%E1%83%97%E1%83%9D%20%E1%83%90%E1%83%AE%E1%83%9A%E1%83%90%3F)
^ka-Q0891-answer

**ka-Q0892** — მე უნდა ის გავაკეთო ახლა?

Do I have to do it now?

Why: Independent pronouns. [[Georgian#^ka-Q0892|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%A3%E1%83%9C%E1%83%93%E1%83%90%20%E1%83%98%E1%83%A1%20%E1%83%92%E1%83%90%E1%83%95%E1%83%90%E1%83%99%E1%83%94%E1%83%97%E1%83%9D%20%E1%83%90%E1%83%AE%E1%83%9A%E1%83%90%3F)
^ka-Q0892-answer

**ka-Q0893** — ამ ინფორმაციის საიმედოობაში ეჭვი არ მეპარება, რადგან ის სანდო ადამიანისგან მოდის.

I don't doubt the reliability of his information because it comes from a trustworthy person.

Why: Independent pronouns. [[Georgian#^ka-Q0893|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%9B%20%E1%83%98%E1%83%9C%E1%83%A4%E1%83%9D%E1%83%A0%E1%83%9B%E1%83%90%E1%83%AA%E1%83%98%E1%83%98%E1%83%A1%20%E1%83%A1%E1%83%90%E1%83%98%E1%83%9B%E1%83%94%E1%83%93%E1%83%9D%E1%83%9D%E1%83%91%E1%83%90%E1%83%A8%E1%83%98%20%E1%83%94%E1%83%AD%E1%83%95%E1%83%98%20%E1%83%90%E1%83%A0%20%E1%83%9B%E1%83%94%E1%83%9E%E1%83%90%E1%83%A0%E1%83%94%E1%83%91%E1%83%90%2C%20%E1%83%A0%E1%83%90%E1%83%93%E1%83%92%E1%83%90%E1%83%9C%20%E1%83%98%E1%83%A1%20%E1%83%A1%E1%83%90%E1%83%9C%E1%83%93%E1%83%9D%20%E1%83%90%E1%83%93%E1%83%90%E1%83%9B%E1%83%98%E1%83%90%E1%83%9C%E1%83%98%E1%83%A1%E1%83%92%E1%83%90%E1%83%9C%20%E1%83%9B%E1%83%9D%E1%83%93%E1%83%98%E1%83%A1.)
^ka-Q0893-answer

**ka-Q0894** — ამ ინფორმაციის საიმედოობაში ეჭვი არ მეპარება, რადგან ის სანდო ადამიანისგან მოდის.

I don't doubt the reliability of his information because it comes from a trustworthy person.

Pronouns identify participants; verbs often also encode participants, allowing omission. Is can refer to he/she/it without English grammatical gender. Georgian verb classes use distinct case alignments.

Why: Independent pronouns. [[Georgian#^ka-Q0894|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%9B%20%E1%83%98%E1%83%9C%E1%83%A4%E1%83%9D%E1%83%A0%E1%83%9B%E1%83%90%E1%83%AA%E1%83%98%E1%83%98%E1%83%A1%20%E1%83%A1%E1%83%90%E1%83%98%E1%83%9B%E1%83%94%E1%83%93%E1%83%9D%E1%83%9D%E1%83%91%E1%83%90%E1%83%A8%E1%83%98%20%E1%83%94%E1%83%AD%E1%83%95%E1%83%98%20%E1%83%90%E1%83%A0%20%E1%83%9B%E1%83%94%E1%83%9E%E1%83%90%E1%83%A0%E1%83%94%E1%83%91%E1%83%90%2C%20%E1%83%A0%E1%83%90%E1%83%93%E1%83%92%E1%83%90%E1%83%9C%20%E1%83%98%E1%83%A1%20%E1%83%A1%E1%83%90%E1%83%9C%E1%83%93%E1%83%9D%20%E1%83%90%E1%83%93%E1%83%90%E1%83%9B%E1%83%98%E1%83%90%E1%83%9C%E1%83%98%E1%83%A1%E1%83%92%E1%83%90%E1%83%9C%20%E1%83%9B%E1%83%9D%E1%83%93%E1%83%98%E1%83%A1.)
^ka-Q0894-answer

**ka-Q0895** — იმის გამო ვერ მჯერა.

That's why I cannot believe it.

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0895|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%98%E1%83%9B%E1%83%98%E1%83%A1%20%E1%83%92%E1%83%90%E1%83%9B%E1%83%9D%20%E1%83%95%E1%83%94%E1%83%A0%20%E1%83%9B%E1%83%AF%E1%83%94%E1%83%A0%E1%83%90.)
^ka-Q0895-answer

**ka-Q0896** — იმის გამო ვერ მჯერა.

That's why I cannot believe it.

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0896|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%98%E1%83%9B%E1%83%98%E1%83%A1%20%E1%83%92%E1%83%90%E1%83%9B%E1%83%9D%20%E1%83%95%E1%83%94%E1%83%A0%20%E1%83%9B%E1%83%AF%E1%83%94%E1%83%A0%E1%83%90.)
^ka-Q0896-answer

**ka-Q0897** — ის ჩემი ძროხაა.

It is my cow.

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0897|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%98%E1%83%A1%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%AB%E1%83%A0%E1%83%9D%E1%83%AE%E1%83%90%E1%83%90.)
^ka-Q0897-answer

**ka-Q0898** — ის ჩემი ძროხაა.

It is my cow.

Why: Independent pronouns. [[Georgian#^ka-Q0898|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%98%E1%83%A1%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%AB%E1%83%A0%E1%83%9D%E1%83%AE%E1%83%90%E1%83%90.)
^ka-Q0898-answer

**ka-Q0899** — ისინი არიან ტომის.

They're Tom's.

Why: Independent pronouns. [[Georgian#^ka-Q0899|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%98%E1%83%A1%E1%83%98%E1%83%9C%E1%83%98%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%90%E1%83%9C%20%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%98%E1%83%A1.)
^ka-Q0899-answer

**ka-Q0900** — ისინი არიან ტომის.

They're Tom's.

Pronouns identify participants; verbs often also encode participants, allowing omission. Is can refer to he/she/it without English grammatical gender. Georgian verb classes use distinct case alignments.

Why: Independent pronouns. [[Georgian#^ka-Q0900|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%98%E1%83%A1%E1%83%98%E1%83%9C%E1%83%98%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%90%E1%83%9C%20%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%98%E1%83%A1.)
^ka-Q0900-answer


### Answers 901–950

**ka-Q0901** — ოდესმე სწავლობთ ბიბლიოთეკაში?

Do you ever study in the library?

Expected form: **მე**

Why: Independent pronouns. [[Georgian#^ka-Q0901|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9D%E1%83%93%E1%83%94%E1%83%A1%E1%83%9B%E1%83%94%20%E1%83%A1%E1%83%AC%E1%83%90%E1%83%95%E1%83%9A%E1%83%9D%E1%83%91%E1%83%97%20%E1%83%91%E1%83%98%E1%83%91%E1%83%9A%E1%83%98%E1%83%9D%E1%83%97%E1%83%94%E1%83%99%E1%83%90%E1%83%A8%E1%83%98%3F)
^ka-Q0901-answer

**ka-Q0902** — ოდესმე სწავლობთ ბიბლიოთეკაში?

Do you ever study in the library?

Expected form: **მე**

Why: Independent pronouns. [[Georgian#^ka-Q0902|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9D%E1%83%93%E1%83%94%E1%83%A1%E1%83%9B%E1%83%94%20%E1%83%A1%E1%83%AC%E1%83%90%E1%83%95%E1%83%9A%E1%83%9D%E1%83%91%E1%83%97%20%E1%83%91%E1%83%98%E1%83%91%E1%83%9A%E1%83%98%E1%83%9D%E1%83%97%E1%83%94%E1%83%99%E1%83%90%E1%83%A8%E1%83%98%3F)
^ka-Q0902-answer

**ka-Q0903** — ტომი არ არის კაპიტალისტი.

Tom isn't a capitalist.

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0903|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%98%20%E1%83%90%E1%83%A0%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%99%E1%83%90%E1%83%9E%E1%83%98%E1%83%A2%E1%83%90%E1%83%9A%E1%83%98%E1%83%A1%E1%83%A2%E1%83%98.)
^ka-Q0903-answer

**ka-Q0904** — ტომი არ არის კაპიტალისტი.

Tom isn't a capitalist.

Why: Independent pronouns. [[Georgian#^ka-Q0904|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%98%20%E1%83%90%E1%83%A0%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%99%E1%83%90%E1%83%9E%E1%83%98%E1%83%A2%E1%83%90%E1%83%9A%E1%83%98%E1%83%A1%E1%83%A2%E1%83%98.)
^ka-Q0904-answer

**ka-Q0905** — 25 წლის ვარ.

I'm 25 years old.

Why: Independent pronouns. [[Georgian#^ka-Q0905|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=25%20%E1%83%AC%E1%83%9A%E1%83%98%E1%83%A1%20%E1%83%95%E1%83%90%E1%83%A0.)
^ka-Q0905-answer

**ka-Q0906** — 25 წლის ვარ.

I'm 25 years old.

Pronouns identify participants; verbs often also encode participants, allowing omission. Is can refer to he/she/it without English grammatical gender. Georgian verb classes use distinct case alignments.

Why: Independent pronouns. [[Georgian#^ka-Q0906|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=25%20%E1%83%AC%E1%83%9A%E1%83%98%E1%83%A1%20%E1%83%95%E1%83%90%E1%83%A0.)
^ka-Q0906-answer

**ka-Q0907** — შენ გაქვს ჩემი ნებართვა.

You have my permission.

Expected form: **შენ**

Why: Independent pronouns. [[Georgian#^ka-Q0907|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A8%E1%83%94%E1%83%9C%20%E1%83%92%E1%83%90%E1%83%A5%E1%83%95%E1%83%A1%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%9C%E1%83%94%E1%83%91%E1%83%90%E1%83%A0%E1%83%97%E1%83%95%E1%83%90.)
^ka-Q0907-answer

**ka-Q0908** — შენ გაქვს ჩემი ნებართვა.

You have my permission.

Expected form: **შენ**

Why: Independent pronouns. [[Georgian#^ka-Q0908|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A8%E1%83%94%E1%83%9C%20%E1%83%92%E1%83%90%E1%83%A5%E1%83%95%E1%83%A1%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%9C%E1%83%94%E1%83%91%E1%83%90%E1%83%A0%E1%83%97%E1%83%95%E1%83%90.)
^ka-Q0908-answer

**ka-Q0909** — მე ზომბი ვარ!

I'm a zombie!

Expected form: **მე**

Why: Independent pronouns. [[Georgian#^ka-Q0909|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%96%E1%83%9D%E1%83%9B%E1%83%91%E1%83%98%20%E1%83%95%E1%83%90%E1%83%A0%21)
^ka-Q0909-answer

**ka-Q0910** — მე ზომბი ვარ!

I'm a zombie!

Why: Independent pronouns. [[Georgian#^ka-Q0910|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%96%E1%83%9D%E1%83%9B%E1%83%91%E1%83%98%20%E1%83%95%E1%83%90%E1%83%A0%21)
^ka-Q0910-answer

**ka-Q0911** — მე მოსწავლე ვარ.

I am a student.

Why: Independent pronouns. [[Georgian#^ka-Q0911|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%9B%E1%83%9D%E1%83%A1%E1%83%AC%E1%83%90%E1%83%95%E1%83%9A%E1%83%94%20%E1%83%95%E1%83%90%E1%83%A0.)
^ka-Q0911-answer

**ka-Q0912** — მე მოსწავლე ვარ.

I am a student.

Pronouns identify participants; verbs often also encode participants, allowing omission. Is can refer to he/she/it without English grammatical gender. Georgian verb classes use distinct case alignments.

Why: Independent pronouns. [[Georgian#^ka-Q0912|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%9B%E1%83%9D%E1%83%A1%E1%83%AC%E1%83%90%E1%83%95%E1%83%9A%E1%83%94%20%E1%83%95%E1%83%90%E1%83%A0.)
^ka-Q0912-answer

**ka-Q0913** — აფრიკა მიგრაციის კონტინენტია.

Africa is a continent of migration.

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0913|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%A4%E1%83%A0%E1%83%98%E1%83%99%E1%83%90%20%E1%83%9B%E1%83%98%E1%83%92%E1%83%A0%E1%83%90%E1%83%AA%E1%83%98%E1%83%98%E1%83%A1%20%E1%83%99%E1%83%9D%E1%83%9C%E1%83%A2%E1%83%98%E1%83%9C%E1%83%94%E1%83%9C%E1%83%A2%E1%83%98%E1%83%90.)
^ka-Q0913-answer

**ka-Q0914** — აფრიკა მიგრაციის კონტინენტია.

Africa is a continent of migration.

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0914|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%A4%E1%83%A0%E1%83%98%E1%83%99%E1%83%90%20%E1%83%9B%E1%83%98%E1%83%92%E1%83%A0%E1%83%90%E1%83%AA%E1%83%98%E1%83%98%E1%83%A1%20%E1%83%99%E1%83%9D%E1%83%9C%E1%83%A2%E1%83%98%E1%83%9C%E1%83%94%E1%83%9C%E1%83%A2%E1%83%98%E1%83%90.)
^ka-Q0914-answer

**ka-Q0915** — მე შენი მოქმედებების შესახებ ვსაუბრობ.

I'm talking about your actions.

Expected form: **მე**

Why: Independent pronouns. [[Georgian#^ka-Q0915|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%A8%E1%83%94%E1%83%9C%E1%83%98%20%E1%83%9B%E1%83%9D%E1%83%A5%E1%83%9B%E1%83%94%E1%83%93%E1%83%94%E1%83%91%E1%83%94%E1%83%91%E1%83%98%E1%83%A1%20%E1%83%A8%E1%83%94%E1%83%A1%E1%83%90%E1%83%AE%E1%83%94%E1%83%91%20%E1%83%95%E1%83%A1%E1%83%90%E1%83%A3%E1%83%91%E1%83%A0%E1%83%9D%E1%83%91.)
^ka-Q0915-answer

**ka-Q0916** — მე შენი მოქმედებების შესახებ ვსაუბრობ.

I'm talking about your actions.

Why: Independent pronouns. [[Georgian#^ka-Q0916|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%A8%E1%83%94%E1%83%9C%E1%83%98%20%E1%83%9B%E1%83%9D%E1%83%A5%E1%83%9B%E1%83%94%E1%83%93%E1%83%94%E1%83%91%E1%83%94%E1%83%91%E1%83%98%E1%83%A1%20%E1%83%A8%E1%83%94%E1%83%A1%E1%83%90%E1%83%AE%E1%83%94%E1%83%91%20%E1%83%95%E1%83%A1%E1%83%90%E1%83%A3%E1%83%91%E1%83%A0%E1%83%9D%E1%83%91.)
^ka-Q0916-answer

**ka-Q0917** — მე არ შემიძლია ვთქვა რამე ცუდი ტომის შესახებ.

I can't say anything bad about Tom.

Why: Independent pronouns. [[Georgian#^ka-Q0917|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%90%E1%83%A0%20%E1%83%A8%E1%83%94%E1%83%9B%E1%83%98%E1%83%AB%E1%83%9A%E1%83%98%E1%83%90%20%E1%83%95%E1%83%97%E1%83%A5%E1%83%95%E1%83%90%20%E1%83%A0%E1%83%90%E1%83%9B%E1%83%94%20%E1%83%AA%E1%83%A3%E1%83%93%E1%83%98%20%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%98%E1%83%A1%20%E1%83%A8%E1%83%94%E1%83%A1%E1%83%90%E1%83%AE%E1%83%94%E1%83%91.)
^ka-Q0917-answer

**ka-Q0918** — მე არ შემიძლია ვთქვა რამე ცუდი ტომის შესახებ.

I can't say anything bad about Tom.

Pronouns identify participants; verbs often also encode participants, allowing omission. Is can refer to he/she/it without English grammatical gender. Georgian verb classes use distinct case alignments.

Why: Independent pronouns. [[Georgian#^ka-Q0918|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%90%E1%83%A0%20%E1%83%A8%E1%83%94%E1%83%9B%E1%83%98%E1%83%AB%E1%83%9A%E1%83%98%E1%83%90%20%E1%83%95%E1%83%97%E1%83%A5%E1%83%95%E1%83%90%20%E1%83%A0%E1%83%90%E1%83%9B%E1%83%94%20%E1%83%AA%E1%83%A3%E1%83%93%E1%83%98%20%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%98%E1%83%A1%20%E1%83%A8%E1%83%94%E1%83%A1%E1%83%90%E1%83%AE%E1%83%94%E1%83%91.)
^ka-Q0918-answer

**ka-Q0919** — მე რიკარდო ვარ.

I'm Ricardo.

Expected form: **მე**

Why: Independent pronouns. [[Georgian#^ka-Q0919|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%A0%E1%83%98%E1%83%99%E1%83%90%E1%83%A0%E1%83%93%E1%83%9D%20%E1%83%95%E1%83%90%E1%83%A0.)
^ka-Q0919-answer

**ka-Q0920** — მე რიკარდო ვარ.

I'm Ricardo.

Expected form: **მე**

Why: Independent pronouns. [[Georgian#^ka-Q0920|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%A0%E1%83%98%E1%83%99%E1%83%90%E1%83%A0%E1%83%93%E1%83%9D%20%E1%83%95%E1%83%90%E1%83%A0.)
^ka-Q0920-answer

**ka-Q0921** — მე მიყვარს ისტორიის სწავლა.

I like studying history.

Expected form: **მე**

Why: Independent pronouns. [[Georgian#^ka-Q0921|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%9B%E1%83%98%E1%83%A7%E1%83%95%E1%83%90%E1%83%A0%E1%83%A1%20%E1%83%98%E1%83%A1%E1%83%A2%E1%83%9D%E1%83%A0%E1%83%98%E1%83%98%E1%83%A1%20%E1%83%A1%E1%83%AC%E1%83%90%E1%83%95%E1%83%9A%E1%83%90.)
^ka-Q0921-answer

**ka-Q0922** — მე მიყვარს ისტორიის სწავლა.

I like studying history.

Why: Independent pronouns. [[Georgian#^ka-Q0922|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%9B%E1%83%98%E1%83%A7%E1%83%95%E1%83%90%E1%83%A0%E1%83%A1%20%E1%83%98%E1%83%A1%E1%83%A2%E1%83%9D%E1%83%A0%E1%83%98%E1%83%98%E1%83%A1%20%E1%83%A1%E1%83%AC%E1%83%90%E1%83%95%E1%83%9A%E1%83%90.)
^ka-Q0922-answer

**ka-Q0923** — ჩემს მეგობარ გოგონასთან ანალური სექსის შემდეგ, როგორც წესი, კარგი შხაპის მიღება გვჭირდება ხოლმე.

After having anal sex with my girlfriend, we usually need to have a good wash.

Why: Independent pronouns. [[Georgian#^ka-Q0923|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A9%E1%83%94%E1%83%9B%E1%83%A1%20%E1%83%9B%E1%83%94%E1%83%92%E1%83%9D%E1%83%91%E1%83%90%E1%83%A0%20%E1%83%92%E1%83%9D%E1%83%92%E1%83%9D%E1%83%9C%E1%83%90%E1%83%A1%E1%83%97%E1%83%90%E1%83%9C%20%E1%83%90%E1%83%9C%E1%83%90%E1%83%9A%E1%83%A3%E1%83%A0%E1%83%98%20%E1%83%A1%E1%83%94%E1%83%A5%E1%83%A1%E1%83%98%E1%83%A1%20%E1%83%A8%E1%83%94%E1%83%9B%E1%83%93%E1%83%94%E1%83%92%2C%20%E1%83%A0%E1%83%9D%E1%83%92%E1%83%9D%E1%83%A0%E1%83%AA%20%E1%83%AC%E1%83%94%E1%83%A1%E1%83%98%2C%20%E1%83%99%E1%83%90%E1%83%A0%E1%83%92%E1%83%98%20%E1%83%A8%E1%83%AE%E1%83%90%E1%83%9E%E1%83%98%E1%83%A1%20%E1%83%9B%E1%83%98%E1%83%A6%E1%83%94%E1%83%91%E1%83%90%20%E1%83%92%E1%83%95%E1%83%AD%E1%83%98%E1%83%A0%E1%83%93%E1%83%94%E1%83%91%E1%83%90%20%E1%83%AE%E1%83%9D%E1%83%9A%E1%83%9B%E1%83%94.)
^ka-Q0923-answer

**ka-Q0924** — ჩემს მეგობარ გოგონასთან ანალური სექსის შემდეგ, როგორც წესი, კარგი შხაპის მიღება გვჭირდება ხოლმე.

After having anal sex with my girlfriend, we usually need to have a good wash.

Pronouns identify participants; verbs often also encode participants, allowing omission. Is can refer to he/she/it without English grammatical gender. Georgian verb classes use distinct case alignments.

Why: Independent pronouns. [[Georgian#^ka-Q0924|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A9%E1%83%94%E1%83%9B%E1%83%A1%20%E1%83%9B%E1%83%94%E1%83%92%E1%83%9D%E1%83%91%E1%83%90%E1%83%A0%20%E1%83%92%E1%83%9D%E1%83%92%E1%83%9D%E1%83%9C%E1%83%90%E1%83%A1%E1%83%97%E1%83%90%E1%83%9C%20%E1%83%90%E1%83%9C%E1%83%90%E1%83%9A%E1%83%A3%E1%83%A0%E1%83%98%20%E1%83%A1%E1%83%94%E1%83%A5%E1%83%A1%E1%83%98%E1%83%A1%20%E1%83%A8%E1%83%94%E1%83%9B%E1%83%93%E1%83%94%E1%83%92%2C%20%E1%83%A0%E1%83%9D%E1%83%92%E1%83%9D%E1%83%A0%E1%83%AA%20%E1%83%AC%E1%83%94%E1%83%A1%E1%83%98%2C%20%E1%83%99%E1%83%90%E1%83%A0%E1%83%92%E1%83%98%20%E1%83%A8%E1%83%AE%E1%83%90%E1%83%9E%E1%83%98%E1%83%A1%20%E1%83%9B%E1%83%98%E1%83%A6%E1%83%94%E1%83%91%E1%83%90%20%E1%83%92%E1%83%95%E1%83%AD%E1%83%98%E1%83%A0%E1%83%93%E1%83%94%E1%83%91%E1%83%90%20%E1%83%AE%E1%83%9D%E1%83%9A%E1%83%9B%E1%83%94.)
^ka-Q0924-answer

**ka-Q0925** — ის ჯერ კიდევ ახალგაზრდაა.

He is still young.

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0925|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%98%E1%83%A1%20%E1%83%AF%E1%83%94%E1%83%A0%20%E1%83%99%E1%83%98%E1%83%93%E1%83%94%E1%83%95%20%E1%83%90%E1%83%AE%E1%83%90%E1%83%9A%E1%83%92%E1%83%90%E1%83%96%E1%83%A0%E1%83%93%E1%83%90%E1%83%90.)
^ka-Q0925-answer

**ka-Q0926** — ის ჯერ კიდევ ახალგაზრდაა.

He is still young.

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0926|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%98%E1%83%A1%20%E1%83%AF%E1%83%94%E1%83%A0%20%E1%83%99%E1%83%98%E1%83%93%E1%83%94%E1%83%95%20%E1%83%90%E1%83%AE%E1%83%90%E1%83%9A%E1%83%92%E1%83%90%E1%83%96%E1%83%A0%E1%83%93%E1%83%90%E1%83%90.)
^ka-Q0926-answer

**ka-Q0927** — მე არ ვმღერი.

I do not sing.

Expected form: **მე**

Why: Independent pronouns. [[Georgian#^ka-Q0927|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%90%E1%83%A0%20%E1%83%95%E1%83%9B%E1%83%A6%E1%83%94%E1%83%A0%E1%83%98.)
^ka-Q0927-answer

**ka-Q0928** — მე არ ვმღერი.

I do not sing.

Why: Independent pronouns. [[Georgian#^ka-Q0928|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%90%E1%83%A0%20%E1%83%95%E1%83%9B%E1%83%A6%E1%83%94%E1%83%A0%E1%83%98.)
^ka-Q0928-answer

**ka-Q0929** — მე შოკოლადი მომწონს.

I like chocolate.

Why: Independent pronouns. [[Georgian#^ka-Q0929|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%A8%E1%83%9D%E1%83%99%E1%83%9D%E1%83%9A%E1%83%90%E1%83%93%E1%83%98%20%E1%83%9B%E1%83%9D%E1%83%9B%E1%83%AC%E1%83%9D%E1%83%9C%E1%83%A1.)
^ka-Q0929-answer

**ka-Q0930** — მე შოკოლადი მომწონს.

I like chocolate.

Pronouns identify participants; verbs often also encode participants, allowing omission. Is can refer to he/she/it without English grammatical gender. Georgian verb classes use distinct case alignments.

Why: Independent pronouns. [[Georgian#^ka-Q0930|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%A8%E1%83%9D%E1%83%99%E1%83%9D%E1%83%9A%E1%83%90%E1%83%93%E1%83%98%20%E1%83%9B%E1%83%9D%E1%83%9B%E1%83%AC%E1%83%9D%E1%83%9C%E1%83%A1.)
^ka-Q0930-answer

**ka-Q0931** — ეს არის ჩემი ელექტრონული ფოსტის მისამართი.

This is my email address.

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0931|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%94%E1%83%A1%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%94%E1%83%9A%E1%83%94%E1%83%A5%E1%83%A2%E1%83%A0%E1%83%9D%E1%83%9C%E1%83%A3%E1%83%9A%E1%83%98%20%E1%83%A4%E1%83%9D%E1%83%A1%E1%83%A2%E1%83%98%E1%83%A1%20%E1%83%9B%E1%83%98%E1%83%A1%E1%83%90%E1%83%9B%E1%83%90%E1%83%A0%E1%83%97%E1%83%98.)
^ka-Q0931-answer

**ka-Q0932** — ეს არის ჩემი ელექტრონული ფოსტის მისამართი.

This is my email address.

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0932|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%94%E1%83%A1%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%A9%E1%83%94%E1%83%9B%E1%83%98%20%E1%83%94%E1%83%9A%E1%83%94%E1%83%A5%E1%83%A2%E1%83%A0%E1%83%9D%E1%83%9C%E1%83%A3%E1%83%9A%E1%83%98%20%E1%83%A4%E1%83%9D%E1%83%A1%E1%83%A2%E1%83%98%E1%83%A1%20%E1%83%9B%E1%83%98%E1%83%A1%E1%83%90%E1%83%9B%E1%83%90%E1%83%A0%E1%83%97%E1%83%98.)
^ka-Q0932-answer

**ka-Q0933** — შენ მე გიყვარვარ?

Do you love me?

Expected form: **შენ**

Why: Independent pronouns. [[Georgian#^ka-Q0933|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A8%E1%83%94%E1%83%9C%20%E1%83%9B%E1%83%94%20%E1%83%92%E1%83%98%E1%83%A7%E1%83%95%E1%83%90%E1%83%A0%E1%83%95%E1%83%90%E1%83%A0%3F)
^ka-Q0933-answer

**ka-Q0934** — შენ მე გიყვარვარ?

Do you love me?

Why: Independent pronouns. [[Georgian#^ka-Q0934|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A8%E1%83%94%E1%83%9C%20%E1%83%9B%E1%83%94%20%E1%83%92%E1%83%98%E1%83%A7%E1%83%95%E1%83%90%E1%83%A0%E1%83%95%E1%83%90%E1%83%A0%3F)
^ka-Q0934-answer

**ka-Q0935** — მე უნდა წავიდე ბოსტონში ტომთან ერთად.

I have to go to Boston with Tom.

Why: Independent pronouns. [[Georgian#^ka-Q0935|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%A3%E1%83%9C%E1%83%93%E1%83%90%20%E1%83%AC%E1%83%90%E1%83%95%E1%83%98%E1%83%93%E1%83%94%20%E1%83%91%E1%83%9D%E1%83%A1%E1%83%A2%E1%83%9D%E1%83%9C%E1%83%A8%E1%83%98%20%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%97%E1%83%90%E1%83%9C%20%E1%83%94%E1%83%A0%E1%83%97%E1%83%90%E1%83%93.)
^ka-Q0935-answer

**ka-Q0936** — მე უნდა წავიდე ბოსტონში ტომთან ერთად.

I have to go to Boston with Tom.

Pronouns identify participants; verbs often also encode participants, allowing omission. Is can refer to he/she/it without English grammatical gender. Georgian verb classes use distinct case alignments.

Why: Independent pronouns. [[Georgian#^ka-Q0936|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%A3%E1%83%9C%E1%83%93%E1%83%90%20%E1%83%AC%E1%83%90%E1%83%95%E1%83%98%E1%83%93%E1%83%94%20%E1%83%91%E1%83%9D%E1%83%A1%E1%83%A2%E1%83%9D%E1%83%9C%E1%83%A8%E1%83%98%20%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%97%E1%83%90%E1%83%9C%20%E1%83%94%E1%83%A0%E1%83%97%E1%83%90%E1%83%93.)
^ka-Q0936-answer

**ka-Q0937** — მე ქარხანაში ვმუშაობ.

I work in a factory.

Expected form: **მე**

Why: Independent pronouns. [[Georgian#^ka-Q0937|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%A5%E1%83%90%E1%83%A0%E1%83%AE%E1%83%90%E1%83%9C%E1%83%90%E1%83%A8%E1%83%98%20%E1%83%95%E1%83%9B%E1%83%A3%E1%83%A8%E1%83%90%E1%83%9D%E1%83%91.)
^ka-Q0937-answer

**ka-Q0938** — მე ქარხანაში ვმუშაობ.

I work in a factory.

Expected form: **მე**

Why: Independent pronouns. [[Georgian#^ka-Q0938|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%A5%E1%83%90%E1%83%A0%E1%83%AE%E1%83%90%E1%83%9C%E1%83%90%E1%83%A8%E1%83%98%20%E1%83%95%E1%83%9B%E1%83%A3%E1%83%A8%E1%83%90%E1%83%9D%E1%83%91.)
^ka-Q0938-answer

**ka-Q0939** — კომპიუტერს თუ გამოიყენებ ინფორმაციის შენახვას შეძლებ.

If you use a computer, you can retain information.

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0939|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%99%E1%83%9D%E1%83%9B%E1%83%9E%E1%83%98%E1%83%A3%E1%83%A2%E1%83%94%E1%83%A0%E1%83%A1%20%E1%83%97%E1%83%A3%20%E1%83%92%E1%83%90%E1%83%9B%E1%83%9D%E1%83%98%E1%83%A7%E1%83%94%E1%83%9C%E1%83%94%E1%83%91%20%E1%83%98%E1%83%9C%E1%83%A4%E1%83%9D%E1%83%A0%E1%83%9B%E1%83%90%E1%83%AA%E1%83%98%E1%83%98%E1%83%A1%20%E1%83%A8%E1%83%94%E1%83%9C%E1%83%90%E1%83%AE%E1%83%95%E1%83%90%E1%83%A1%20%E1%83%A8%E1%83%94%E1%83%AB%E1%83%9A%E1%83%94%E1%83%91.)
^ka-Q0939-answer

**ka-Q0940** — კომპიუტერს თუ გამოიყენებ ინფორმაციის შენახვას შეძლებ.

If you use a computer, you can retain information.

Why: Independent pronouns. [[Georgian#^ka-Q0940|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%99%E1%83%9D%E1%83%9B%E1%83%9E%E1%83%98%E1%83%A3%E1%83%A2%E1%83%94%E1%83%A0%E1%83%A1%20%E1%83%97%E1%83%A3%20%E1%83%92%E1%83%90%E1%83%9B%E1%83%9D%E1%83%98%E1%83%A7%E1%83%94%E1%83%9C%E1%83%94%E1%83%91%20%E1%83%98%E1%83%9C%E1%83%A4%E1%83%9D%E1%83%A0%E1%83%9B%E1%83%90%E1%83%AA%E1%83%98%E1%83%98%E1%83%A1%20%E1%83%A8%E1%83%94%E1%83%9C%E1%83%90%E1%83%AE%E1%83%95%E1%83%90%E1%83%A1%20%E1%83%A8%E1%83%94%E1%83%AB%E1%83%9A%E1%83%94%E1%83%91.)
^ka-Q0940-answer

**ka-Q0941** — მე ეს გავაკეთე.

I've done this.

Why: Independent pronouns. [[Georgian#^ka-Q0941|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%94%E1%83%A1%20%E1%83%92%E1%83%90%E1%83%95%E1%83%90%E1%83%99%E1%83%94%E1%83%97%E1%83%94.)
^ka-Q0941-answer

**ka-Q0942** — მე ეს გავაკეთე.

I've done this.

Pronouns identify participants; verbs often also encode participants, allowing omission. Is can refer to he/she/it without English grammatical gender. Georgian verb classes use distinct case alignments.

Why: Independent pronouns. [[Georgian#^ka-Q0942|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%94%E1%83%A1%20%E1%83%92%E1%83%90%E1%83%95%E1%83%90%E1%83%99%E1%83%94%E1%83%97%E1%83%94.)
^ka-Q0942-answer

**ka-Q0943** — მე მივდივარ მეგობრის შესახვედრად.

I'm going to meet a friend.

Expected form: **მე**

Why: Independent pronouns. [[Georgian#^ka-Q0943|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%9B%E1%83%98%E1%83%95%E1%83%93%E1%83%98%E1%83%95%E1%83%90%E1%83%A0%20%E1%83%9B%E1%83%94%E1%83%92%E1%83%9D%E1%83%91%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%A8%E1%83%94%E1%83%A1%E1%83%90%E1%83%AE%E1%83%95%E1%83%94%E1%83%93%E1%83%A0%E1%83%90%E1%83%93.)
^ka-Q0943-answer

**ka-Q0944** — მე მივდივარ მეგობრის შესახვედრად.

I'm going to meet a friend.

Expected form: **მე**

Why: Independent pronouns. [[Georgian#^ka-Q0944|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%9B%E1%83%98%E1%83%95%E1%83%93%E1%83%98%E1%83%95%E1%83%90%E1%83%A0%20%E1%83%9B%E1%83%94%E1%83%92%E1%83%9D%E1%83%91%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%A8%E1%83%94%E1%83%A1%E1%83%90%E1%83%AE%E1%83%95%E1%83%94%E1%83%93%E1%83%A0%E1%83%90%E1%83%93.)
^ka-Q0944-answer

**ka-Q0945** — არის ტომი უფრო ახალგაზრდა ვიდრე შენ?

Is Tom younger than you?

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0945|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%98%20%E1%83%A3%E1%83%A4%E1%83%A0%E1%83%9D%20%E1%83%90%E1%83%AE%E1%83%90%E1%83%9A%E1%83%92%E1%83%90%E1%83%96%E1%83%A0%E1%83%93%E1%83%90%20%E1%83%95%E1%83%98%E1%83%93%E1%83%A0%E1%83%94%20%E1%83%A8%E1%83%94%E1%83%9C%3F)
^ka-Q0945-answer

**ka-Q0946** — არის ტომი უფრო ახალგაზრდა ვიდრე შენ?

Is Tom younger than you?

Why: Independent pronouns. [[Georgian#^ka-Q0946|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%98%20%E1%83%A3%E1%83%A4%E1%83%A0%E1%83%9D%20%E1%83%90%E1%83%AE%E1%83%90%E1%83%9A%E1%83%92%E1%83%90%E1%83%96%E1%83%A0%E1%83%93%E1%83%90%20%E1%83%95%E1%83%98%E1%83%93%E1%83%A0%E1%83%94%20%E1%83%A8%E1%83%94%E1%83%9C%3F)
^ka-Q0946-answer

**ka-Q0947** — მე სტუდენტი ვარ.

I am a student.

Why: Independent pronouns. [[Georgian#^ka-Q0947|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%A1%E1%83%A2%E1%83%A3%E1%83%93%E1%83%94%E1%83%9C%E1%83%A2%E1%83%98%20%E1%83%95%E1%83%90%E1%83%A0.)
^ka-Q0947-answer

**ka-Q0948** — მე სტუდენტი ვარ.

I am a student.

Pronouns identify participants; verbs often also encode participants, allowing omission. Is can refer to he/she/it without English grammatical gender. Georgian verb classes use distinct case alignments.

Why: Independent pronouns. [[Georgian#^ka-Q0948|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%A1%E1%83%A2%E1%83%A3%E1%83%93%E1%83%94%E1%83%9C%E1%83%A2%E1%83%98%20%E1%83%95%E1%83%90%E1%83%A0.)
^ka-Q0948-answer

**ka-Q0949** — შენ არა ხარ ექიმი.

You're not a doctor.

Expected form: **შენ**

Why: Independent pronouns. [[Georgian#^ka-Q0949|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A8%E1%83%94%E1%83%9C%20%E1%83%90%E1%83%A0%E1%83%90%20%E1%83%AE%E1%83%90%E1%83%A0%20%E1%83%94%E1%83%A5%E1%83%98%E1%83%9B%E1%83%98.)
^ka-Q0949-answer

**ka-Q0950** — შენ არა ხარ ექიმი.

You're not a doctor.

Expected form: **შენ**

Why: Independent pronouns. [[Georgian#^ka-Q0950|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A8%E1%83%94%E1%83%9C%20%E1%83%90%E1%83%A0%E1%83%90%20%E1%83%AE%E1%83%90%E1%83%A0%20%E1%83%94%E1%83%A5%E1%83%98%E1%83%9B%E1%83%98.)
^ka-Q0950-answer


### Answers 951–1000

**ka-Q0951** — მე ვარ რიკარდო.

I'm Ricardo.

Expected form: **მე**

Why: Independent pronouns. [[Georgian#^ka-Q0951|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%95%E1%83%90%E1%83%A0%20%E1%83%A0%E1%83%98%E1%83%99%E1%83%90%E1%83%A0%E1%83%93%E1%83%9D.)
^ka-Q0951-answer

**ka-Q0952** — მე ვარ რიკარდო.

I'm Ricardo.

Why: Independent pronouns. [[Georgian#^ka-Q0952|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%95%E1%83%90%E1%83%A0%20%E1%83%A0%E1%83%98%E1%83%99%E1%83%90%E1%83%A0%E1%83%93%E1%83%9D.)
^ka-Q0952-answer

**ka-Q0953** — ის ლამაზია, მაგრამ საშიში.

She's pretty, but dangerous.

Why: Independent pronouns. [[Georgian#^ka-Q0953|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%98%E1%83%A1%20%E1%83%9A%E1%83%90%E1%83%9B%E1%83%90%E1%83%96%E1%83%98%E1%83%90%2C%20%E1%83%9B%E1%83%90%E1%83%92%E1%83%A0%E1%83%90%E1%83%9B%20%E1%83%A1%E1%83%90%E1%83%A8%E1%83%98%E1%83%A8%E1%83%98.)
^ka-Q0953-answer

**ka-Q0954** — ის ლამაზია, მაგრამ საშიში.

She's pretty, but dangerous.

Pronouns identify participants; verbs often also encode participants, allowing omission. Is can refer to he/she/it without English grammatical gender. Georgian verb classes use distinct case alignments.

Why: Independent pronouns. [[Georgian#^ka-Q0954|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%98%E1%83%A1%20%E1%83%9A%E1%83%90%E1%83%9B%E1%83%90%E1%83%96%E1%83%98%E1%83%90%2C%20%E1%83%9B%E1%83%90%E1%83%92%E1%83%A0%E1%83%90%E1%83%9B%20%E1%83%A1%E1%83%90%E1%83%A8%E1%83%98%E1%83%A8%E1%83%98.)
^ka-Q0954-answer

**ka-Q0955** — რამდენიმე წიგნი გაქვს.

You have few books.

Expected form: **მე**

Why: Independent pronouns. [[Georgian#^ka-Q0955|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A0%E1%83%90%E1%83%9B%E1%83%93%E1%83%94%E1%83%9C%E1%83%98%E1%83%9B%E1%83%94%20%E1%83%AC%E1%83%98%E1%83%92%E1%83%9C%E1%83%98%20%E1%83%92%E1%83%90%E1%83%A5%E1%83%95%E1%83%A1.)
^ka-Q0955-answer

**ka-Q0956** — რამდენიმე წიგნი გაქვს.

You have few books.

Expected form: **მე**

Why: Independent pronouns. [[Georgian#^ka-Q0956|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A0%E1%83%90%E1%83%9B%E1%83%93%E1%83%94%E1%83%9C%E1%83%98%E1%83%9B%E1%83%94%20%E1%83%AC%E1%83%98%E1%83%92%E1%83%9C%E1%83%98%20%E1%83%92%E1%83%90%E1%83%A5%E1%83%95%E1%83%A1.)
^ka-Q0956-answer

**ka-Q0957** — მე არ მიყვარს ექიმები.

I don't like doctors.

Expected form: **მე**

Why: Independent pronouns. [[Georgian#^ka-Q0957|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%90%E1%83%A0%20%E1%83%9B%E1%83%98%E1%83%A7%E1%83%95%E1%83%90%E1%83%A0%E1%83%A1%20%E1%83%94%E1%83%A5%E1%83%98%E1%83%9B%E1%83%94%E1%83%91%E1%83%98.)
^ka-Q0957-answer

**ka-Q0958** — მე არ მიყვარს ექიმები.

I don't like doctors.

Why: Independent pronouns. [[Georgian#^ka-Q0958|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%90%E1%83%A0%20%E1%83%9B%E1%83%98%E1%83%A7%E1%83%95%E1%83%90%E1%83%A0%E1%83%A1%20%E1%83%94%E1%83%A5%E1%83%98%E1%83%9B%E1%83%94%E1%83%91%E1%83%98.)
^ka-Q0958-answer

**ka-Q0959** — რას შეისწავლის სოვეტოლოგი?

What does a Sovietologist study?

Why: Independent pronouns. [[Georgian#^ka-Q0959|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A0%E1%83%90%E1%83%A1%20%E1%83%A8%E1%83%94%E1%83%98%E1%83%A1%E1%83%AC%E1%83%90%E1%83%95%E1%83%9A%E1%83%98%E1%83%A1%20%E1%83%A1%E1%83%9D%E1%83%95%E1%83%94%E1%83%A2%E1%83%9D%E1%83%9A%E1%83%9D%E1%83%92%E1%83%98%3F)
^ka-Q0959-answer

**ka-Q0960** — რას შეისწავლის სოვეტოლოგი?

What does a Sovietologist study?

Pronouns identify participants; verbs often also encode participants, allowing omission. Is can refer to he/she/it without English grammatical gender. Georgian verb classes use distinct case alignments.

Why: Independent pronouns. [[Georgian#^ka-Q0960|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A0%E1%83%90%E1%83%A1%20%E1%83%A8%E1%83%94%E1%83%98%E1%83%A1%E1%83%AC%E1%83%90%E1%83%95%E1%83%9A%E1%83%98%E1%83%A1%20%E1%83%A1%E1%83%9D%E1%83%95%E1%83%94%E1%83%A2%E1%83%9D%E1%83%9A%E1%83%9D%E1%83%92%E1%83%98%3F)
^ka-Q0960-answer

**ka-Q0961** — მე მინდა ვიყო ჟურნალისტი.

I want to become a journalist.

Expected form: **მე**

Why: Independent pronouns. [[Georgian#^ka-Q0961|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%9B%E1%83%98%E1%83%9C%E1%83%93%E1%83%90%20%E1%83%95%E1%83%98%E1%83%A7%E1%83%9D%20%E1%83%9F%E1%83%A3%E1%83%A0%E1%83%9C%E1%83%90%E1%83%9A%E1%83%98%E1%83%A1%E1%83%A2%E1%83%98.)
^ka-Q0961-answer

**ka-Q0962** — მე მინდა ვიყო ჟურნალისტი.

I want to become a journalist.

Expected form: **მე**

Why: Independent pronouns. [[Georgian#^ka-Q0962|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%9B%E1%83%98%E1%83%9C%E1%83%93%E1%83%90%20%E1%83%95%E1%83%98%E1%83%A7%E1%83%9D%20%E1%83%9F%E1%83%A3%E1%83%A0%E1%83%9C%E1%83%90%E1%83%9A%E1%83%98%E1%83%A1%E1%83%A2%E1%83%98.)
^ka-Q0962-answer

**ka-Q0963** — მე წიგნის დავწერ.

I'll write a book.

Expected form: **მე**

Why: Independent pronouns. [[Georgian#^ka-Q0963|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%AC%E1%83%98%E1%83%92%E1%83%9C%E1%83%98%E1%83%A1%20%E1%83%93%E1%83%90%E1%83%95%E1%83%AC%E1%83%94%E1%83%A0.)
^ka-Q0963-answer

**ka-Q0964** — მე წიგნის დავწერ.

I'll write a book.

Why: Independent pronouns. [[Georgian#^ka-Q0964|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%AC%E1%83%98%E1%83%92%E1%83%9C%E1%83%98%E1%83%A1%20%E1%83%93%E1%83%90%E1%83%95%E1%83%AC%E1%83%94%E1%83%A0.)
^ka-Q0964-answer

**ka-Q0965** — ტომი როგორ მიდის ავსტრალიაში?

How is Tom going to Australia?

Why: Independent pronouns. [[Georgian#^ka-Q0965|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%98%20%E1%83%A0%E1%83%9D%E1%83%92%E1%83%9D%E1%83%A0%20%E1%83%9B%E1%83%98%E1%83%93%E1%83%98%E1%83%A1%20%E1%83%90%E1%83%95%E1%83%A1%E1%83%A2%E1%83%A0%E1%83%90%E1%83%9A%E1%83%98%E1%83%90%E1%83%A8%E1%83%98%3F)
^ka-Q0965-answer

**ka-Q0966** — ტომი როგორ მიდის ავსტრალიაში?

How is Tom going to Australia?

Pronouns identify participants; verbs often also encode participants, allowing omission. Is can refer to he/she/it without English grammatical gender. Georgian verb classes use distinct case alignments.

Why: Independent pronouns. [[Georgian#^ka-Q0966|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%98%20%E1%83%A0%E1%83%9D%E1%83%92%E1%83%9D%E1%83%A0%20%E1%83%9B%E1%83%98%E1%83%93%E1%83%98%E1%83%A1%20%E1%83%90%E1%83%95%E1%83%A1%E1%83%A2%E1%83%A0%E1%83%90%E1%83%9A%E1%83%98%E1%83%90%E1%83%A8%E1%83%98%3F)
^ka-Q0966-answer

**ka-Q0967** — გოგომ უარყოფის ნიშნად თავი გაიქნია, ბიჭი კი იდგა გაუნძრევლად.

The girl shook her head in refusal and the boy stood there shaking.

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0967|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%92%E1%83%9D%E1%83%92%E1%83%9D%E1%83%9B%20%E1%83%A3%E1%83%90%E1%83%A0%E1%83%A7%E1%83%9D%E1%83%A4%E1%83%98%E1%83%A1%20%E1%83%9C%E1%83%98%E1%83%A8%E1%83%9C%E1%83%90%E1%83%93%20%E1%83%97%E1%83%90%E1%83%95%E1%83%98%20%E1%83%92%E1%83%90%E1%83%98%E1%83%A5%E1%83%9C%E1%83%98%E1%83%90%2C%20%E1%83%91%E1%83%98%E1%83%AD%E1%83%98%20%E1%83%99%E1%83%98%20%E1%83%98%E1%83%93%E1%83%92%E1%83%90%20%E1%83%92%E1%83%90%E1%83%A3%E1%83%9C%E1%83%AB%E1%83%A0%E1%83%94%E1%83%95%E1%83%9A%E1%83%90%E1%83%93.)
^ka-Q0967-answer

**ka-Q0968** — გოგომ უარყოფის ნიშნად თავი გაიქნია, ბიჭი კი იდგა გაუნძრევლად.

The girl shook her head in refusal and the boy stood there shaking.

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0968|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%92%E1%83%9D%E1%83%92%E1%83%9D%E1%83%9B%20%E1%83%A3%E1%83%90%E1%83%A0%E1%83%A7%E1%83%9D%E1%83%A4%E1%83%98%E1%83%A1%20%E1%83%9C%E1%83%98%E1%83%A8%E1%83%9C%E1%83%90%E1%83%93%20%E1%83%97%E1%83%90%E1%83%95%E1%83%98%20%E1%83%92%E1%83%90%E1%83%98%E1%83%A5%E1%83%9C%E1%83%98%E1%83%90%2C%20%E1%83%91%E1%83%98%E1%83%AD%E1%83%98%20%E1%83%99%E1%83%98%20%E1%83%98%E1%83%93%E1%83%92%E1%83%90%20%E1%83%92%E1%83%90%E1%83%A3%E1%83%9C%E1%83%AB%E1%83%A0%E1%83%94%E1%83%95%E1%83%9A%E1%83%90%E1%83%93.)
^ka-Q0968-answer

**ka-Q0969** — მე ცხოვრებს ვცხოვრობ.

I live life.

Expected form: **მე**

Why: Independent pronouns. [[Georgian#^ka-Q0969|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%AA%E1%83%AE%E1%83%9D%E1%83%95%E1%83%A0%E1%83%94%E1%83%91%E1%83%A1%20%E1%83%95%E1%83%AA%E1%83%AE%E1%83%9D%E1%83%95%E1%83%A0%E1%83%9D%E1%83%91.)
^ka-Q0969-answer

**ka-Q0970** — მე ცხოვრებს ვცხოვრობ.

I live life.

Why: Independent pronouns. [[Georgian#^ka-Q0970|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%AA%E1%83%AE%E1%83%9D%E1%83%95%E1%83%A0%E1%83%94%E1%83%91%E1%83%A1%20%E1%83%95%E1%83%AA%E1%83%AE%E1%83%9D%E1%83%95%E1%83%A0%E1%83%9D%E1%83%91.)
^ka-Q0970-answer

**ka-Q0971** — მე ვფიქრობ ტომი მომზადებს საუზმეს.

I think Tom will make breakfast.

Why: Independent pronouns. [[Georgian#^ka-Q0971|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%95%E1%83%A4%E1%83%98%E1%83%A5%E1%83%A0%E1%83%9D%E1%83%91%20%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%98%20%E1%83%9B%E1%83%9D%E1%83%9B%E1%83%96%E1%83%90%E1%83%93%E1%83%94%E1%83%91%E1%83%A1%20%E1%83%A1%E1%83%90%E1%83%A3%E1%83%96%E1%83%9B%E1%83%94%E1%83%A1.)
^ka-Q0971-answer

**ka-Q0972** — მე ვფიქრობ ტომი მომზადებს საუზმეს.

I think Tom will make breakfast.

Pronouns identify participants; verbs often also encode participants, allowing omission. Is can refer to he/she/it without English grammatical gender. Georgian verb classes use distinct case alignments.

Why: Independent pronouns. [[Georgian#^ka-Q0972|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%95%E1%83%A4%E1%83%98%E1%83%A5%E1%83%A0%E1%83%9D%E1%83%91%20%E1%83%A2%E1%83%9D%E1%83%9B%E1%83%98%20%E1%83%9B%E1%83%9D%E1%83%9B%E1%83%96%E1%83%90%E1%83%93%E1%83%94%E1%83%91%E1%83%A1%20%E1%83%A1%E1%83%90%E1%83%A3%E1%83%96%E1%83%9B%E1%83%94%E1%83%A1.)
^ka-Q0972-answer

**ka-Q0973** — მე ძალიან მომწონს ძაღლები.

I like dogs very much.

Expected form: **მე**

Why: Independent pronouns. [[Georgian#^ka-Q0973|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%AB%E1%83%90%E1%83%9A%E1%83%98%E1%83%90%E1%83%9C%20%E1%83%9B%E1%83%9D%E1%83%9B%E1%83%AC%E1%83%9D%E1%83%9C%E1%83%A1%20%E1%83%AB%E1%83%90%E1%83%A6%E1%83%9A%E1%83%94%E1%83%91%E1%83%98.)
^ka-Q0973-answer

**ka-Q0974** — მე ძალიან მომწონს ძაღლები.

I like dogs very much.

Expected form: **მე**

Why: Independent pronouns. [[Georgian#^ka-Q0974|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%AB%E1%83%90%E1%83%9A%E1%83%98%E1%83%90%E1%83%9C%20%E1%83%9B%E1%83%9D%E1%83%9B%E1%83%AC%E1%83%9D%E1%83%9C%E1%83%A1%20%E1%83%AB%E1%83%90%E1%83%A6%E1%83%9A%E1%83%94%E1%83%91%E1%83%98.)
^ka-Q0974-answer

**ka-Q0975** — არავინ იცის რა მოხდება.

No one knows what'll happen.

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0975|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%A0%E1%83%90%E1%83%95%E1%83%98%E1%83%9C%20%E1%83%98%E1%83%AA%E1%83%98%E1%83%A1%20%E1%83%A0%E1%83%90%20%E1%83%9B%E1%83%9D%E1%83%AE%E1%83%93%E1%83%94%E1%83%91%E1%83%90.)
^ka-Q0975-answer

**ka-Q0976** — არავინ იცის რა მოხდება.

No one knows what'll happen.

Why: Independent pronouns. [[Georgian#^ka-Q0976|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%90%E1%83%A0%E1%83%90%E1%83%95%E1%83%98%E1%83%9C%20%E1%83%98%E1%83%AA%E1%83%98%E1%83%A1%20%E1%83%A0%E1%83%90%20%E1%83%9B%E1%83%9D%E1%83%AE%E1%83%93%E1%83%94%E1%83%91%E1%83%90.)
^ka-Q0976-answer

**ka-Q0977** — წიგნი მაგიდაზე არის.

The book is on the table.

Why: Independent pronouns. [[Georgian#^ka-Q0977|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%AC%E1%83%98%E1%83%92%E1%83%9C%E1%83%98%20%E1%83%9B%E1%83%90%E1%83%92%E1%83%98%E1%83%93%E1%83%90%E1%83%96%E1%83%94%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1.)
^ka-Q0977-answer

**ka-Q0978** — წიგნი მაგიდაზე არის.

The book is on the table.

Pronouns identify participants; verbs often also encode participants, allowing omission. Is can refer to he/she/it without English grammatical gender. Georgian verb classes use distinct case alignments.

Why: Independent pronouns. [[Georgian#^ka-Q0978|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%AC%E1%83%98%E1%83%92%E1%83%9C%E1%83%98%20%E1%83%9B%E1%83%90%E1%83%92%E1%83%98%E1%83%93%E1%83%90%E1%83%96%E1%83%94%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1.)
^ka-Q0978-answer

**ka-Q0979** — წყალი ძალიან ცხელი არის.

The water's very hot.

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0979|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%AC%E1%83%A7%E1%83%90%E1%83%9A%E1%83%98%20%E1%83%AB%E1%83%90%E1%83%9A%E1%83%98%E1%83%90%E1%83%9C%20%E1%83%AA%E1%83%AE%E1%83%94%E1%83%9A%E1%83%98%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1.)
^ka-Q0979-answer

**ka-Q0980** — წყალი ძალიან ცხელი არის.

The water's very hot.

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0980|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%AC%E1%83%A7%E1%83%90%E1%83%9A%E1%83%98%20%E1%83%AB%E1%83%90%E1%83%9A%E1%83%98%E1%83%90%E1%83%9C%20%E1%83%AA%E1%83%AE%E1%83%94%E1%83%9A%E1%83%98%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1.)
^ka-Q0980-answer

**ka-Q0981** — სად არის საჭმელი?

Where is the food?

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0981|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A1%E1%83%90%E1%83%93%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%A1%E1%83%90%E1%83%AD%E1%83%9B%E1%83%94%E1%83%9A%E1%83%98%3F)
^ka-Q0981-answer

**ka-Q0982** — სად არის საჭმელი?

Where is the food?

Why: Independent pronouns. [[Georgian#^ka-Q0982|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A1%E1%83%90%E1%83%93%20%E1%83%90%E1%83%A0%E1%83%98%E1%83%A1%20%E1%83%A1%E1%83%90%E1%83%AD%E1%83%9B%E1%83%94%E1%83%9A%E1%83%98%3F)
^ka-Q0982-answer

**ka-Q0983** — მე სახლის კაცი ვარ.

I'm the man of the house.

Why: Independent pronouns. [[Georgian#^ka-Q0983|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%A1%E1%83%90%E1%83%AE%E1%83%9A%E1%83%98%E1%83%A1%20%E1%83%99%E1%83%90%E1%83%AA%E1%83%98%20%E1%83%95%E1%83%90%E1%83%A0.)
^ka-Q0983-answer

**ka-Q0984** — მე სახლის კაცი ვარ.

I'm the man of the house.

Pronouns identify participants; verbs often also encode participants, allowing omission. Is can refer to he/she/it without English grammatical gender. Georgian verb classes use distinct case alignments.

Why: Independent pronouns. [[Georgian#^ka-Q0984|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%A1%E1%83%90%E1%83%AE%E1%83%9A%E1%83%98%E1%83%A1%20%E1%83%99%E1%83%90%E1%83%AA%E1%83%98%20%E1%83%95%E1%83%90%E1%83%A0.)
^ka-Q0984-answer

**ka-Q0985** — მე წყალს ვსვამ.

I drink the water.

Expected form: **მე**

Why: Independent pronouns. [[Georgian#^ka-Q0985|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%AC%E1%83%A7%E1%83%90%E1%83%9A%E1%83%A1%20%E1%83%95%E1%83%A1%E1%83%95%E1%83%90%E1%83%9B.)
^ka-Q0985-answer

**ka-Q0986** — მე წყალს ვსვამ.

I drink the water.

Expected form: **მე**

Why: Independent pronouns. [[Georgian#^ka-Q0986|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%AC%E1%83%A7%E1%83%90%E1%83%9A%E1%83%A1%20%E1%83%95%E1%83%A1%E1%83%95%E1%83%90%E1%83%9B.)
^ka-Q0986-answer

**ka-Q0987** — მე იქ ლამაზი ჩანჩქერი დავინახე.

I saw a beautiful waterfall there.

Expected form: **მე**

Why: Independent pronouns. [[Georgian#^ka-Q0987|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%98%E1%83%A5%20%E1%83%9A%E1%83%90%E1%83%9B%E1%83%90%E1%83%96%E1%83%98%20%E1%83%A9%E1%83%90%E1%83%9C%E1%83%A9%E1%83%A5%E1%83%94%E1%83%A0%E1%83%98%20%E1%83%93%E1%83%90%E1%83%95%E1%83%98%E1%83%9C%E1%83%90%E1%83%AE%E1%83%94.)
^ka-Q0987-answer

**ka-Q0988** — მე იქ ლამაზი ჩანჩქერი დავინახე.

I saw a beautiful waterfall there.

Why: Independent pronouns. [[Georgian#^ka-Q0988|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%98%E1%83%A5%20%E1%83%9A%E1%83%90%E1%83%9B%E1%83%90%E1%83%96%E1%83%98%20%E1%83%A9%E1%83%90%E1%83%9C%E1%83%A9%E1%83%A5%E1%83%94%E1%83%A0%E1%83%98%20%E1%83%93%E1%83%90%E1%83%95%E1%83%98%E1%83%9C%E1%83%90%E1%83%AE%E1%83%94.)
^ka-Q0988-answer

**ka-Q0989** — მე ვარ ჩოგბურთის კლუბში.

I'm in the tennis club.

Why: Independent pronouns. [[Georgian#^ka-Q0989|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%95%E1%83%90%E1%83%A0%20%E1%83%A9%E1%83%9D%E1%83%92%E1%83%91%E1%83%A3%E1%83%A0%E1%83%97%E1%83%98%E1%83%A1%20%E1%83%99%E1%83%9A%E1%83%A3%E1%83%91%E1%83%A8%E1%83%98.)
^ka-Q0989-answer

**ka-Q0990** — მე ვარ ჩოგბურთის კლუბში.

I'm in the tennis club.

Pronouns identify participants; verbs often also encode participants, allowing omission. Is can refer to he/she/it without English grammatical gender. Georgian verb classes use distinct case alignments.

Why: Independent pronouns. [[Georgian#^ka-Q0990|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%95%E1%83%90%E1%83%A0%20%E1%83%A9%E1%83%9D%E1%83%92%E1%83%91%E1%83%A3%E1%83%A0%E1%83%97%E1%83%98%E1%83%A1%20%E1%83%99%E1%83%9A%E1%83%A3%E1%83%91%E1%83%A8%E1%83%98.)
^ka-Q0990-answer

**ka-Q0991** — მე მიყვარს შენი ჩანთა.

I love your bag.

Expected form: **მე**

Why: Independent pronouns. [[Georgian#^ka-Q0991|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%9B%E1%83%98%E1%83%A7%E1%83%95%E1%83%90%E1%83%A0%E1%83%A1%20%E1%83%A8%E1%83%94%E1%83%9C%E1%83%98%20%E1%83%A9%E1%83%90%E1%83%9C%E1%83%97%E1%83%90.)
^ka-Q0991-answer

**ka-Q0992** — მე მიყვარს შენი ჩანთა.

I love your bag.

Expected form: **მე**

Why: Independent pronouns. [[Georgian#^ka-Q0992|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%9B%E1%83%98%E1%83%A7%E1%83%95%E1%83%90%E1%83%A0%E1%83%A1%20%E1%83%A8%E1%83%94%E1%83%9C%E1%83%98%20%E1%83%A9%E1%83%90%E1%83%9C%E1%83%97%E1%83%90.)
^ka-Q0992-answer

**ka-Q0993** — მან თავის მოკვლა სცადა.

She attempted suicide.

Expected form: **ის**

Why: Independent pronouns. [[Georgian#^ka-Q0993|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%90%E1%83%9C%20%E1%83%97%E1%83%90%E1%83%95%E1%83%98%E1%83%A1%20%E1%83%9B%E1%83%9D%E1%83%99%E1%83%95%E1%83%9A%E1%83%90%20%E1%83%A1%E1%83%AA%E1%83%90%E1%83%93%E1%83%90.)
^ka-Q0993-answer

**ka-Q0994** — მან თავის მოკვლა სცადა.

She attempted suicide.

Why: Independent pronouns. [[Georgian#^ka-Q0994|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%90%E1%83%9C%20%E1%83%97%E1%83%90%E1%83%95%E1%83%98%E1%83%A1%20%E1%83%9B%E1%83%9D%E1%83%99%E1%83%95%E1%83%9A%E1%83%90%20%E1%83%A1%E1%83%AA%E1%83%90%E1%83%93%E1%83%90.)
^ka-Q0994-answer

**ka-Q0995** — მე ვფიქრობ ჩვენ ვართ შემდეგი.

I think that we're next.

Why: Independent pronouns. [[Georgian#^ka-Q0995|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%95%E1%83%A4%E1%83%98%E1%83%A5%E1%83%A0%E1%83%9D%E1%83%91%20%E1%83%A9%E1%83%95%E1%83%94%E1%83%9C%20%E1%83%95%E1%83%90%E1%83%A0%E1%83%97%20%E1%83%A8%E1%83%94%E1%83%9B%E1%83%93%E1%83%94%E1%83%92%E1%83%98.)
^ka-Q0995-answer

**ka-Q0996** — მე ვფიქრობ ჩვენ ვართ შემდეგი.

I think that we're next.

Pronouns identify participants; verbs often also encode participants, allowing omission. Is can refer to he/she/it without English grammatical gender. Georgian verb classes use distinct case alignments.

Why: Independent pronouns. [[Georgian#^ka-Q0996|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%9B%E1%83%94%20%E1%83%95%E1%83%A4%E1%83%98%E1%83%A5%E1%83%A0%E1%83%9D%E1%83%91%20%E1%83%A9%E1%83%95%E1%83%94%E1%83%9C%20%E1%83%95%E1%83%90%E1%83%A0%E1%83%97%20%E1%83%A8%E1%83%94%E1%83%9B%E1%83%93%E1%83%94%E1%83%92%E1%83%98.)
^ka-Q0996-answer

**ka-Q0997** — ეხლა მე თქვენ გეტყვით სიმართლეს.

Now I'll tell you the truth.

Expected form: **მე**

Why: Independent pronouns. [[Georgian#^ka-Q0997|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%94%E1%83%AE%E1%83%9A%E1%83%90%20%E1%83%9B%E1%83%94%20%E1%83%97%E1%83%A5%E1%83%95%E1%83%94%E1%83%9C%20%E1%83%92%E1%83%94%E1%83%A2%E1%83%A7%E1%83%95%E1%83%98%E1%83%97%20%E1%83%A1%E1%83%98%E1%83%9B%E1%83%90%E1%83%A0%E1%83%97%E1%83%9A%E1%83%94%E1%83%A1.)
^ka-Q0997-answer

**ka-Q0998** — ეხლა მე თქვენ გეტყვით სიმართლეს.

Now I'll tell you the truth.

Expected form: **მე**

Why: Independent pronouns. [[Georgian#^ka-Q0998|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%94%E1%83%AE%E1%83%9A%E1%83%90%20%E1%83%9B%E1%83%94%20%E1%83%97%E1%83%A5%E1%83%95%E1%83%94%E1%83%9C%20%E1%83%92%E1%83%94%E1%83%A2%E1%83%A7%E1%83%95%E1%83%98%E1%83%97%20%E1%83%A1%E1%83%98%E1%83%9B%E1%83%90%E1%83%A0%E1%83%97%E1%83%9A%E1%83%94%E1%83%A1.)
^ka-Q0998-answer

**ka-Q0999** — უფროსმა მომცა მე ეს ხელფასი.

The boss gave me this salary.

Expected form: **მე**

Why: Independent pronouns. [[Georgian#^ka-Q0999|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A3%E1%83%A4%E1%83%A0%E1%83%9D%E1%83%A1%E1%83%9B%E1%83%90%20%E1%83%9B%E1%83%9D%E1%83%9B%E1%83%AA%E1%83%90%20%E1%83%9B%E1%83%94%20%E1%83%94%E1%83%A1%20%E1%83%AE%E1%83%94%E1%83%9A%E1%83%A4%E1%83%90%E1%83%A1%E1%83%98.)
^ka-Q0999-answer

**ka-Q1000** — უფროსმა მომცა მე ეს ხელფასი.

The boss gave me this salary.

Why: Independent pronouns. [[Georgian#^ka-Q1000|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kat&query=%E1%83%A3%E1%83%A4%E1%83%A0%E1%83%9D%E1%83%A1%E1%83%9B%E1%83%90%20%E1%83%9B%E1%83%9D%E1%83%9B%E1%83%AA%E1%83%90%20%E1%83%9B%E1%83%94%20%E1%83%94%E1%83%A1%20%E1%83%AE%E1%83%94%E1%83%9A%E1%83%A4%E1%83%90%E1%83%A1%E1%83%98.)
^ka-Q1000-answer


## Read and speak

Read the native sentence first, identify its predicate and one grammar form, then check the translation. Say it aloud and change one detail.

### Learning with a clear purpose

ახალ ენას ვსწავლობ. ყოველდღე მოკლე ტექსტს ვკითხულობ და მკაფიო მაგალითებს ვუსმენ. სასარგებლო სიტყვებს რვეულში ვწერ. როცა შეცდომას ვუშვებ, წესს ვამოწმებ და ისევ ვცდილობ. ჩემი მიზანია, ადამიანებს გავუგო და ჩემი აზრები ნათლად გამოვხატო.

I am learning a new language. Each day, I read a short text and listen to clear examples. I write useful words in a notebook. When I make a mistake, I check the rule and try again. My goal is to understand people and express my ideas clearly.

![[Resources/Audio/ka/Reading passage.mp3]]

**დღისით ვსწავლობ, საღამოს კი ვმუშაობ.**

I study during the day, and in the evening I work.

**უბრალოდ არ ვიცი რა უნდა ვთქვა.**

I just don't know what to say.

**მე სააფთიაქოში ვმუშაობ.**

I work in a pharmacy.

**მინდა შენთან ლაპარაკი.**

I want to talk to you.

**ძაღლი ვაშლს ჭამს.**

The dog is eating an apple.

**მე დავიღალე, და დაწოლა მინდა.**

I am tired and I want to go to bed.

**მე ვფიქრობ, რომ მე ვარ მთვრალი.**

I think I'm drunk.

**მარიამს ცხენები უყვარს.**

Mary loves horses.

**თქვენ ძალიან დაბალი ხართ.**

You're very short.

**როდიდან ჩვენ ვართ მეგობრები?**

Since when are we friends?

**მესაკუთრეს ახსნა არის გასაგები.**

The owner's explanation is clear.

**ის არის მსოფლიო ჩემპიონი.**

She's the world champion.

**შემიძლია ის გავაკეთო ერთ კვირაში.**

I can do it in a week.

**შენ ახლა ცრუობ ჩემთვის.**

You're lying to me now.

**მინდა რომ სამაგიერო გადაგიხადოთ თქვენი გულკეთილობისთვის უახლოეს მომავალში.**

I would like to repay your kindness in the near future.

## Professional writing

Write an introduction, a polite request, an explanation of a finding, a summary of a passage and a tactful disagreement. Use the professional/advanced lessons for models.

## PDF edition

[[Resources/PDFs/Georgian.pdf|Open the complete printable book]]


<!-- individual-letter-audio -->
## Hear each letter separately

Play each letter’s own synthetic recording. English has separate US and UK models.

### ა · ანი

![[Resources/Audio/ka/Letters/001.mp3]]

### ბ · ბანი

![[Resources/Audio/ka/Letters/002.mp3]]

### გ · განი

![[Resources/Audio/ka/Letters/003.mp3]]

### დ · დონი

![[Resources/Audio/ka/Letters/004.mp3]]

### ე · ენი

![[Resources/Audio/ka/Letters/005.mp3]]

### ვ · ვინი

![[Resources/Audio/ka/Letters/006.mp3]]

### ზ · ზენი

![[Resources/Audio/ka/Letters/007.mp3]]

### თ · თანი

![[Resources/Audio/ka/Letters/008.mp3]]

### ი · ინი

![[Resources/Audio/ka/Letters/009.mp3]]

### კ · კანი

![[Resources/Audio/ka/Letters/010.mp3]]

### ლ · ლასი

![[Resources/Audio/ka/Letters/011.mp3]]

### მ · მანი

![[Resources/Audio/ka/Letters/012.mp3]]

### ნ · ნარი

![[Resources/Audio/ka/Letters/013.mp3]]

### ო · ონი

![[Resources/Audio/ka/Letters/014.mp3]]

### პ · პარი

![[Resources/Audio/ka/Letters/015.mp3]]

### ჟ · ჟანი

![[Resources/Audio/ka/Letters/016.mp3]]

### რ · რაე

![[Resources/Audio/ka/Letters/017.mp3]]

### ს · სანი

![[Resources/Audio/ka/Letters/018.mp3]]

### ტ · ტარი

![[Resources/Audio/ka/Letters/019.mp3]]

### უ · უნი

![[Resources/Audio/ka/Letters/020.mp3]]

### ფ · ფარი

![[Resources/Audio/ka/Letters/021.mp3]]

### ქ · ქანი

![[Resources/Audio/ka/Letters/022.mp3]]

### ღ · ღანი

![[Resources/Audio/ka/Letters/023.mp3]]

### ყ · ყარი

![[Resources/Audio/ka/Letters/024.mp3]]

### შ · შინი

![[Resources/Audio/ka/Letters/025.mp3]]

### ჩ · ჩინი

![[Resources/Audio/ka/Letters/026.mp3]]

### ც · ცანი

![[Resources/Audio/ka/Letters/027.mp3]]

### ძ · ძანი

![[Resources/Audio/ka/Letters/028.mp3]]

### წ · წანი

![[Resources/Audio/ka/Letters/029.mp3]]

### ჭ · ჭარი

![[Resources/Audio/ka/Letters/030.mp3]]

### ხ · ხანი

![[Resources/Audio/ka/Letters/031.mp3]]

### ჯ · ჯანი

![[Resources/Audio/ka/Letters/032.mp3]]

### ჰ · ჰაე

![[Resources/Audio/ka/Letters/033.mp3]]
<!-- /individual-letter-audio -->
