# Georgian study

[[Georgian|Open the complete Georgian course note]]

Audio and the printable PDF are in Resources. This vault contains one language.

[[Sources and licenses]]
