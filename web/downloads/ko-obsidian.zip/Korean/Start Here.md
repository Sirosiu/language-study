# Korean study

[[Korean|Open the complete Korean course note]]

Audio and the printable PDF are in Resources. This vault contains one language.

[[Sources and licenses]]
