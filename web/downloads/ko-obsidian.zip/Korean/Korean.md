# Korean

Professional ambition - C1-oriented study

Everything for this language is in this note. Open a rule, read its examples and follow its practice link. Answers stay in this same note.

[[Start Here|All languages]] · [[Sources and licenses|Sources]]

## Start reading

### 한글 / 자모 (Hangeul / jamo)

| Written form | Name / reading | Related forms |
|---|---|---|
| ㄱ | 기역 giyeok  |  ·  ·  |
| ㄴ | 니은 nieun  |  ·  ·  |
| ㄷ | 디귿 digeut  |  ·  ·  |
| ㄹ | 리을 rieul  |  ·  ·  |
| ㅁ | 미음 mieum  |  ·  ·  |
| ㅂ | 비읍 bieup  |  ·  ·  |
| ㅅ | 시옷 siot  |  ·  ·  |
| ㅇ | 이응 ieung  |  ·  ·  |
| ㅈ | 지읒 jieut  |  ·  ·  |
| ㅊ | 치읓 chieut  |  ·  ·  |
| ㅋ | 키읔 kieuk  |  ·  ·  |
| ㅌ | 티읕 tieut  |  ·  ·  |
| ㅍ | 피읖 pieup  |  ·  ·  |
| ㅎ | 히읗 hieut  |  ·  ·  |
| ㅏ | a  |  ·  ·  |
| ㅑ | ya  |  ·  ·  |
| ㅓ | eo  |  ·  ·  |
| ㅕ | yeo  |  ·  ·  |
| ㅗ | o  |  ·  ·  |
| ㅛ | yo  |  ·  ·  |
| ㅜ | u  |  ·  ·  |
| ㅠ | yu  |  ·  ·  |
| ㅡ | eu  |  ·  ·  |
| ㅣ | i  |  ·  ·  |
| ㄲ | kk  |  ·  ·  |
| ㄸ | tt  |  ·  ·  |
| ㅃ | pp  |  ·  ·  |
| ㅆ | ss  |  ·  ·  |
| ㅉ | jj  |  ·  ·  |
| ㅐ | ae  |  ·  ·  |
| ㅒ | yae  |  ·  ·  |
| ㅔ | e  |  ·  ·  |
| ㅖ | ye  |  ·  ·  |
| ㅘ | wa  |  ·  ·  |
| ㅙ | wae  |  ·  ·  |
| ㅚ | oe  |  ·  ·  |
| ㅝ | wo  |  ·  ·  |
| ㅞ | we  |  ·  ·  |
| ㅟ | wi  |  ·  ·  |
| ㅢ | ui  |  ·  ·  |

![[Resources/Audio/ko/Script and first phrases.mp3]]

The player above is synthetic speech. Word tracks below work offline.

### Letters make syllable blocks

The core inventory has 14 consonants and 10 vowels, with additional doubled consonants and combined vowels shown after them. A syllable block normally has an initial consonant and a vowel, optionally a final consonant (batchim). Initial ㅇ is silent; final ㅇ is /ŋ/.

### Place parts in a block

ㄱ + ㅏ → 가 (ga); ㅎ + ㅏ + ㄴ → 한 (han); ㄱ + ㅡ + ㄹ → 글 (geul). Vertical vowels sit to the right of the initial consonant; horizontal vowels sit below it. A final consonant sits at the bottom.

### Pronunciation changes across boundaries

Final consonants are restricted in sound and can link into a following vowel syllable. Nasal assimilation, tensification and aspiration alter surface pronunciation. ㄱ/ㅋ/ㄲ are distinct series; do not map them all to English k. Romanisation is a guide, not a pronunciation transcript.

### Final consonants and clusters

Batchim letters have restricted unreleased final sounds when no following vowel links them onward. Common final categories are k, n, t, l, m, p and ng. Written final clusters include ㄳ ㄵ ㄶ ㄺ ㄻ ㄼ ㄽ ㄾ ㄿ ㅀ ㅄ. Their reading changes with the following syllable; learn a recording and a linked example instead of pronouncing both letters mechanically.

### Join syllables into a word

한 + 글 → 한글 = Hangeul. Learn the shape of the complete syllable while recognising its letters.

### Attach grammar to a stem

먹다 → 먹어요 → 먹었어요 = eat → eat (polite) → ate (polite). Stem changes and vowel contraction depend on the verb.

### Choose a particle

책이 / 책은 versus 사과가 / 사과는. 이/가 marks a subject; 은/는 a topic or contrast. The variant depends on whether the preceding noun ends in a consonant.

**안녕하세요.**

Hello.

**한국어를 공부하고 있어요.**

I am studying Korean.

**다시 말해 주세요.**

Please say it again.

**이 단어는 무슨 뜻이에요?**

What does this word mean?

### Grammar terms in plain English

**Noun** — A word naming a person, thing or idea: student, book, freedom.

**Verb** — A word describing an action or state: read, know, be.

**Subject** — The participant linked to the main verb’s subject pattern. In The student reads a book, the student is the subject.

**Object** — A participant selected by a verb. In The student reads a book, a book is the direct object.

**Agreement** — One word changes to match another, for example an adjective matching a noun’s gender and number.

**Case** — A noun/pronoun form marking its relationship in a sentence. Cases can mark subjects, objects, possession or relations usually expressed by English prepositions.

**Gender** — A grammatical noun class. It does not always describe the sex of a person or any physical property.

**Tense** — A verb system that relates a situation to a time, often past or non-past.

**Aspect** — How a situation is viewed: unfolding, completed, habitual, experienced or in a resulting state.

**Infinitive** — A non-finite verb form often used for a dictionary entry or a complement. It does not by itself give the ordinary person/tense pattern.

**Participle** — A verb-derived form used in compound predicates or as a modifier; its exact function depends on the language and construction.

**Clause** — A unit organised around a predicate. One sentence can contain several clauses.

**Register** — Language choices suited to a situation: casual conversation, polite requests, academic writing or another context.

## Grammar, examples and practice

### Particles and sentence organisation

Korean commonly places the predicate last and omits recoverable subjects and objects. 은/는 frames a topic or contrast, 이/가 commonly marks a subject, 을/를 an object, 에 a goal/time or certain locations, and 에서 an action setting. Allomorphs depend on whether the preceding word ends in a consonant. Do not label 은/는 merely the same subject marker as 이/가.

**저는 도서관에서 책을 읽어요.**

I read books in the library. Topic, action setting and object precede the predicate.

**결과가 중요합니다.**

The result is important. Subject marker with a formal polite ending.

#### Topic 은 and 는

은/는 marks topic or contrast. 은 follows a consonant-final noun; 는 follows a vowel-final one. The grammatical subject can be marked separately within a topic-comment structure.

**나는 갈 거에요.**

I'm going to go.

**톰은 벽장에서 헌 구두상자를 꺼내 열었다.**

Tom pulled out an old shoebox from his closet and opened it.

![[Resources/Audio/ko/Rule 01.mp3]]

[[Korean#^ko-Q0001|Practise this rule (50 questions)]]

#### Subject 이 and 가

이/가 commonly marks a subject or focused identification. The variant follows the preceding noun’s final sound. These syllables can also appear inside lexical forms, so check the phrase boundary.

**자기가 잘못했다고 생각한다.**

I feel guilty.

**영국 영화가 미국 영화보다 낫다.**

British films are better than American films.

![[Resources/Audio/ko/Rule 02.mp3]]

[[Korean#^ko-Q0051|Practise this rule (50 questions)]]

#### Object 을 and 를

을/를 marks many direct objects. 을 follows a consonant, 를 a vowel. It is often dropped in casual speech when the relationship remains clear.

**연필을 입에 넣지 마세요, 실수로 입천장을 찌를 수 있습니다.**

Don’t put a pencil in your mouth. You might accidentally stab your palate.

**몇 번을 반복해야 해?**

How many times do I need to repeat it?

![[Resources/Audio/ko/Rule 03.mp3]]

[[Korean#^ko-Q0101|Practise this rule (50 questions)]]

#### Destination and location 에

에 marks many destinations, times and locations with existence predicates. Event location often uses 에서 instead. The predicate determines the appropriate relation.

**나 오늘밤 너의 파티에 가도 돼?**

Can I come to your party tonight?

**톰은 정원에 앉아 있어.**

Tom was sitting in the garden.

![[Resources/Audio/ko/Rule 04.mp3]]

[[Korean#^ko-Q0151|Practise this rule (50 questions)]]

#### Event location and source 에서

에서 often marks where an action happens or where movement originates. It contrasts with location 에 for many state/existence predicates.

**외국에서 살면서 좀 불편한 건 없었어?**

Don't you feel any inconvenience living abroad?

**톰과 메리는 스마트 홈에서 거주하고 있어요.**

Tom and Mary live in a smart home.

![[Resources/Audio/ko/Rule 05.mp3]]

[[Korean#^ko-Q0201|Practise this rule (50 questions)]]

#### Recipient markers

에게/한테 mark many animate recipients; 께 is honorific. Register and the person’s status influence the choice. Inanimate destinations often take another marker.

**그녀는 고급 진과 토닉 한 잔은 여름과도 같다고 했다, 그리고 그것은 나에게 진실함을 느끼게 해주었다.**

She said that a good gin and tonic is like summertime in a glass, and it struck me as being too true.

**난 톰한테 답장했어.**

I texted Tom back.

![[Resources/Audio/ko/Rule 06.mp3]]

[[Korean#^ko-Q0251|Practise this rule (50 questions)]]

#### Possession 의

의 links a possessor or modifier to a following noun. It is often reduced or omitted in familiar phrases. Pronunciation can differ from the spelling in possessive use.

**톰은 이 분야의 개척자야.**

Tom is a pioneer in this field.

**독서는 더 이상 소수의 전유물이 아니게 되었다.**

Reading books ceased to be a privilege of a minority.

![[Resources/Audio/ko/Rule 07.mp3]]

[[Korean#^ko-Q0301|Practise this rule (50 questions)]]

#### Inclusion 도

도 commonly means also/even. Its scope is the expression it follows, and it often replaces an ordinary subject/object marker.

**선물은 아직도 포장 상태야.**

The gift was still wrapped.

**그녀는 누구보다도 아름다워요.**

She is more beautiful than any other girl.

![[Resources/Audio/ko/Rule 08.mp3]]

[[Korean#^ko-Q0351|Practise this rule (50 questions)]]

#### Restriction 만

만 restricts a phrase to only. It can combine with case particles. Restriction and inclusion change the statement’s meaning even when both alternatives are grammatical.

**해결책을 찾았지만 너무 빨리 찾아서 맞는 답이 아닌거 같습니다.**

I found a solution, but I found it so fast that it can't be the right solution.

**그녀가 미소지을 땐, 녹아내릴 것만 같아.**

When she smiles, I feel like melting.

![[Resources/Audio/ko/Rule 09.mp3]]

[[Korean#^ko-Q0401|Practise this rule (50 questions)]]

<details><summary>Choose 책을 or 책를.</summary>

책을. The noun ends in a consonant.

</details>

<details><summary>Contrast 에 and 에서 for a simple location example.</summary>

학교에 있어요 is being at school; 학교에서 공부해요 is studying at school. Other governed meanings need separate study.

</details>

### Verb forms, aspect and endings

Korean predicates inflect through stems and endings. 먹다 gives 먹어요, 먹었어요 and 먹고 있어요. 아/어 selection involves vowel patterns and irregular classes. 고 있다 commonly marks ongoing action; 아/어 있다 often marks a resulting state with suitable intransitive verbs. Negative 안 and 못 distinguish ordinary negation and inability/failure in many contexts. Endings also encode speech level, connection and speaker stance.

**지금 보고서를 읽고 있어요.**

I am reading the report now. Ongoing activity with 고 있다.

**아직 확인하지 못했습니다.**

I have not been able to check it yet. Formal ending and inability/failure negation.

#### Formal polite endings

Formal polite endings serve statements and questions with related forms. The stem’s shape and predicate type determine the ending. Formal style is not the only polite style.

**오늘은 6월 18일, Muiriel의 생일입니다!**

Today is June 18th and it is Muiriel's birthday!

**Muiriel은 지금 20살입니다.**

Muiriel is 20 now.

![[Resources/Audio/ko/Rule 10.mp3]]

[[Korean#^ko-Q0451|Practise this rule (50 questions)]]

#### Conversational polite endings

The 해요 style is polite and common in everyday conversation. Stem vowels and contractions affect -아요/-어요 selection. Copulas have their own 이에요/예요 forms.

**벌써 우리가 만난 지 4년 이에요. 시간이 참 빠른 것 같아요.**

It's already been 4 years since we met. How time flies.

**한국어를 배우고 싶어요.**

I want to learn Korean.

![[Resources/Audio/ko/Rule 11.mp3]]

[[Korean#^ko-Q0501|Practise this rule (50 questions)]]

#### Past forms

Past -았/었- combines with a stem and a speech-level ending. Contractions are frequent, including 하다→했-. Retain the intended level of politeness when changing tense.

**톰은 아직 결정하지 못했다.**

Tom hasn't decided yet.

**히메쿠사 유리코는 자살했다.**

Yuriko Himekusa committed suicide.

![[Resources/Audio/ko/Rule 12.mp3]]

[[Korean#^ko-Q0551|Practise this rule (50 questions)]]

#### Negation

안 commonly negates; 못 commonly expresses inability or failure to perform. Their placement and long-form alternatives depend on the predicate and register.

**동물을 학대해서는 안 된다.**

One must not abuse animals.

**저 두 명은 사이가 안 좋다.**

Those two don't get along.

![[Resources/Audio/ko/Rule 13.mp3]]

[[Korean#^ko-Q0601|Practise this rule (50 questions)]]

#### Existence and absence

있다 and 없다 express existence/absence and some possession. Their complements do not behave exactly like English have objects. Location and subject marking remain important.

**바라는 것이 없으면 부족함이 없다.**

Not wanting is the same as having.

**다른 사람을 귀찮게 할 수 있다.**

The others can't be bothered.

![[Resources/Audio/ko/Rule 14.mp3]]

[[Korean#^ko-Q0651|Practise this rule (50 questions)]]

#### Progressive forms

A verb stem plus -고 있다 often marks ongoing activity. Some result-state readings require another pattern. The lexical verb and context determine aspect.

**톰은 수년 간 우울증과 싸우고 있어.**

Tom has been battling depression for many years.

**톰이랑 나는 집을 구하고 있어.**

Tom and I are house hunting.

![[Resources/Audio/ko/Rule 15.mp3]]

[[Korean#^ko-Q0701|Practise this rule (50 questions)]]

<details><summary>Make a polite past form of 먹다.</summary>

먹었어요. The ending follows the stem's vowel pattern.

</details>

<details><summary>Why is a dictionary form not a neutral form for every conversation?</summary>

다 dictionary/plain forms and polite endings differ in function and social appropriateness.

</details>

### Noun modifiers and complex clauses

Verb-based modifiers precede nouns, with forms related to time and predicate type: 읽는 책, 읽은 책, 읽을 책. Descriptive predicates have their own modifier patterns. Nominalisation with 기 or 것 permits propositions to occupy noun-like roles. Connectors such as 지만, 때문에 and 으면 relate contrast, reason and condition; learn their restrictions and register.

**어제 읽은 논문**

the paper read yesterday Past verb modifier precedes 논문.

**조건이 바뀌면 결과도 바뀝니다.**

If the conditions change, the result changes too. Conditional plus additive 도.

#### Conditional linking

-(으)면 builds a conditional relation. The stem’s final consonant determines the linking form. It can express a real or hypothetical situation according to context.

**사공이 많으면 배가 산으로 간다.**

Too many cooks spoil the broth.

**톰이 네가 이걸 하는 걸 본다면 울게 될 걸.**

If Tom saw you doing that, he'd cry.

![[Resources/Audio/ko/Rule 16.mp3]]

[[Korean#^ko-Q0751|Practise this rule (50 questions)]]

#### Cause and sequence

These connective endings express reason, sequence or another relation depending on context. They have restrictions on following commands and proposals; learn the whole construction.

**어제 너무 많이 먹어서 이제 난 병이 나요.**

Yesterday I ate too much and now I feel sick.

**니가 좀 외로울 것 같아서 내가 와인 한 병을 들고 왔지.**

I thought you might be lonely, so I came over with a bottle of wine.

![[Resources/Audio/ko/Rule 17.mp3]]

[[Korean#^ko-Q0801|Practise this rule (50 questions)]]

#### Contrast and coordination

-지만 marks contrast/concession; -고 often links predicates. Tense and subject interpretation can depend on the linked clauses rather than an English word-for-word connector.

**너 어디 가고 싶니?**

Where do you want to go?

**개는 잘 짖는 다고 좋은 개가 아니다.**

A dog who is a good barker is not a good dog.

![[Resources/Audio/ko/Rule 18.mp3]]

[[Korean#^ko-Q0851|Practise this rule (50 questions)]]

<details><summary>What is the head of 어제 읽은 논문?</summary>

논문. The preceding phrase specifies it.

</details>

<details><summary>Build a contrast with 지만.</summary>

결과는 흥미롭지만 추가 확인이 필요합니다. The results are interesting, but further checking is needed.

</details>

### Honorifics and professional interaction

Subject honorific 시, honorific vocabulary and speech levels are separate dimensions. A formal polite ending alone does not establish correct treatment of every participant. 드리다 and 주다 differ in the relation of giving; 말씀 can replace 말 in respectful contexts. Identify the agent and recipient before choosing an honorific form. Workplace norms vary by organisation and relationship.

**이 부분을 설명해 주시겠습니까?**

Could you explain this part? Formal courteous request with subject honorific.

**자료를 보내 드리겠습니다.**

I will send you the materials. 드리다 frames an action directed respectfully to the recipient.

#### Requests and honorific endings

-(으)세요 commonly forms polite requests and also contains honorific subject marking in other uses. -(으)십시오 is more formal. Respectful reference and polite address are related but separate choices.

**거짓말 하지 마세요.**

Don't you lie!

**와인 한 병 더 주세요.**

One more bottle of wine, please.

![[Resources/Audio/ko/Rule 19.mp3]]

[[Korean#^ko-Q0901|Practise this rule (50 questions)]]

<details><summary>What should a professional phrase note record?</summary>

Who says it to whom, the action agent, speech level and a complete example.

</details>

<details><summary>Write a clarification request.</summary>

이 표현의 의미를 조금 더 자세히 설명해 주시겠습니까? Request detail while maintaining an appropriate relationship.

</details>

### Academic reading and careful claims

Research vocabulary includes 연구 study, 방법 method, 결과 result, 근거 grounds/evidence and 한계 limitation. Formal written sentences often compress information into noun phrases.
Teaching passage: 이 결과는 두 요인 사이의 관련성을 보여 준다. 그러나 한 요인이 다른 요인의 원인임을 증명하는 것은 아니다. 결론을 평가하려면 연구 조건을 확인해야 한다.
Translation: This result shows an association between two factors. However, it does not prove that one is the cause of the other. Evaluating the conclusion requires checking the study conditions.

**원인임을 증명하는 것은 아니다**

does not prove that it is the cause Nominalised proposition and a carefully scoped negative.

**평가하려면**

in order to evaluate / if one intends to evaluate Purpose/intention-related conditional structure.

#### Questions and stance

Question words ask for specific information. 아마 marks a probability/guess rather than a question. Sentence endings communicate stance and relationship; do not translate only the lexical words.

**지금 뭐하는 건데요?**

What are you doing right now?

**어디서 전화를 걸 수 있죠?**

Where can I make a phone call?

![[Resources/Audio/ko/Rule 20.mp3]]

[[Korean#^ko-Q0951|Practise this rule (50 questions)]]

<details><summary>Distinguish 보여 주다 from 증명하다 in the passage.</summary>

The former indicates/shows a relation; the latter claims proof. The passage denies proof of causation.

</details>

<details><summary>Produce a 100-word professional summary.</summary>

Check noun modifiers, referents, formal consistency and the strength of the causal claim.

</details>

## Word bank and recordings

1,000 study entries, based on dictionary selections and authored teaching glosses. Learn a word in a phrase; consult the linked entry for additional senses.

<details><summary>Words 1–50</summary>

![[Resources/Audio/ko/Words 0001-0050.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [이](https://en.wiktionary.org/wiki/%EC%9D%B4#Korean) | subject particle after a consonant; this in a different use | i · particle |
| [는](https://en.wiktionary.org/wiki/%EB%8A%94#Korean) | topic particle after a vowel; contrasts known information | neun · particle |
| [을](https://en.wiktionary.org/wiki/%EC%9D%84#Korean) | direct-object particle after a consonant | eul · particle |
| [하](https://en.wiktionary.org/wiki/%ED%95%98#Korean) | last, lowest (grade or class) | ha · noun |
| [에](https://en.wiktionary.org/wiki/%EC%97%90#Korean) | at/in/to; a location, time or destination particle | e · particle |
| [다](https://en.wiktionary.org/wiki/%EB%8B%A4#Korean) | all; also the plain declarative ending in verb forms | da · particle |
| [의](https://en.wiktionary.org/wiki/%EC%9D%98#Korean) | possessive or genitive particle, often translated as of or 's | ui · particle |
| [고](https://en.wiktionary.org/wiki/%EA%B3%A0#Korean) | a verb-linking ending meaning and; late/deceased before a name in another use | go · particle |
| [은](https://en.wiktionary.org/wiki/%EC%9D%80#Korean) | topic particle after a consonant | eun · particle |
| [가](https://en.wiktionary.org/wiki/%EA%B0%80#Korean) | subject particle after a vowel | ga · particle |
| [들](https://en.wiktionary.org/wiki/%EB%93%A4#Korean) | meadow, field, plain | deul · noun |
| [한](https://en.wiktionary.org/wiki/%ED%95%9C#Korean) | one (as a determiner numeral before a noun or classifier) | han · num |
| [도](https://en.wiktionary.org/wiki/%EB%8F%84#Korean) | province (in both Koreas) | do · noun |
| [어](https://en.wiktionary.org/wiki/%EC%96%B4#Korean) | uh-huh, yes | eo · intj |
| [게](https://en.wiktionary.org/wiki/%EA%B2%8C#Korean) | crab | ge · noun |
| [일](https://en.wiktionary.org/wiki/%EC%9D%BC#Korean) | work (activity done for compensation or reward) | il · noun |
| [나](https://en.wiktionary.org/wiki/%EB%82%98#Korean) | I, me; the first-person singular plain (non-polite) pronoun | na · pron |
| [로](https://en.wiktionary.org/wiki/%EB%A1%9C#Korean) | by/with; toward; as (particle, with 으로 after most consonants) | ro · particle |
| [지](https://en.wiktionary.org/wiki/%EC%A7%80#Korean) | only used in -은 지 (-eun ji, “since”). | ji · noun |
| [해](https://en.wiktionary.org/wiki/%ED%95%B4#Korean) | the Sun | hae · noun |
| [아](https://en.wiktionary.org/wiki/%EC%95%84#Korean) | ah; oh | a · intj |
| [과](https://en.wiktionary.org/wiki/%EA%B3%BC#Korean) | academic department (in universities) | gwa · noun |
| [되](https://en.wiktionary.org/wiki/%EB%90%98#Korean) | A unit of volume equivalent to about 1.8 L. | doe · noun |
| [기](https://en.wiktionary.org/wiki/%EA%B8%B0#Korean) | energy, spirit (of a person) | gi · noun |
| [것](https://en.wiktionary.org/wiki/%EA%B2%83#Korean) | thing; something; that which; what; used to designate any object, action, or phenomenon, forming noun phrases. | geot · noun |
| [그](https://en.wiktionary.org/wiki/%EA%B7%B8#Korean) | that (of what has been already said or known) | geu · det |
| [수](https://en.wiktionary.org/wiki/%EC%88%98#Korean) | way, means, possibility, ability; used to express ability, in constructions equivalent to the English modal "can" | su · noun |
| [면](https://en.wiktionary.org/wiki/%EB%A9%B4#Korean) | cotton (both the fiber and the cloth) | myeon · noun |
| [와](https://en.wiktionary.org/wiki/%EC%99%80#Korean) | wa (the name of the Hangul jamo “ㅘ”, a vowel that combines the sounds of ㅗ and ㅏ) | wa · noun |
| [적](https://en.wiktionary.org/wiki/%EC%A0%81#Korean) | enemy; opponent; adversary | jeok · noun |
| [인](https://en.wiktionary.org/wiki/%EC%9D%B8#Korean) | person; people; human, human being | in · noun |
| [만](https://en.wiktionary.org/wiki/%EB%A7%8C#Korean) | ten thousand | man · num |
| [안](https://en.wiktionary.org/wiki/%EC%95%88#Korean) | inside | an · noun |
| [요](https://en.wiktionary.org/wiki/%EC%9A%94#Korean) | For the verb-final particle, see the entry at -요 (-yo). | yo · particle |
| [주](https://en.wiktionary.org/wiki/%EC%A3%BC#Korean) | week (unit of time) | ju · noun |
| [월](https://en.wiktionary.org/wiki/%EC%9B%94#Korean) | month | wol · noun |
| [말](https://en.wiktionary.org/wiki/%EB%A7%90#Korean) | speech | mal · noun |
| [내](https://en.wiktionary.org/wiki/%EB%82%B4#Korean) | stream, brook | nae · noun |
| [시](https://en.wiktionary.org/wiki/%EC%8B%9C#Korean) | hour (time) | si · noun |
| [년](https://en.wiktionary.org/wiki/%EB%85%84#Korean) | year | nyeon · noun |
| [제](https://en.wiktionary.org/wiki/%EC%A0%9C#Korean) | allomorph of 저 (jeo, first-person singular polite pronoun) before -가 (-ga, nominative suffix) | je · pron |
| [입](https://en.wiktionary.org/wiki/%EC%9E%85#Korean) | mouth | ip · noun |
| [더](https://en.wiktionary.org/wiki/%EB%8D%94#Korean) | more, -er (to a greater extent) | deo · adv |
| [사람](https://en.wiktionary.org/wiki/%EC%82%AC%EB%9E%8C#Korean) | human being, person | saram · noun |
| [자](https://en.wiktionary.org/wiki/%EC%9E%90#Korean) | 10²⁴ | ja · num |
| [야](https://en.wiktionary.org/wiki/%EC%95%BC#Korean) | hey | ya · intj |
| [여](https://en.wiktionary.org/wiki/%EC%97%AC#Korean) | woman; female | yeo · noun |
| [아니](https://en.wiktionary.org/wiki/%EC%95%84%EB%8B%88#Korean) | no; not | ani · adv |
| [우리](https://en.wiktionary.org/wiki/%EC%9A%B0%EB%A6%AC#Korean) | cage, pen, coop, enclosure (a designated area or structure for confining animals) | uri · noun |
| [때](https://en.wiktionary.org/wiki/%EB%95%8C#Korean) | time; occasion | ttae · noun |

</details>

<details><summary>Words 51–100</summary>

![[Resources/Audio/ko/Words 0051-0100.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [전](https://en.wiktionary.org/wiki/%EC%A0%84#Korean) | before | jeon · noun |
| [네](https://en.wiktionary.org/wiki/%EB%84%A4#Korean) | four (of something) | ne · det |
| [라](https://en.wiktionary.org/wiki/%EB%9D%BC#Korean) | la (sixth note in the solfège major scale) | ra · noun |
| [저](https://en.wiktionary.org/wiki/%EC%A0%80#Korean) | that (distal determiner) | jeo · det |
| [님](https://en.wiktionary.org/wiki/%EB%8B%98#Korean) | beloved (object of speaker's love) | nim · noun |
| [알](https://en.wiktionary.org/wiki/%EC%95%8C#Korean) | egg, roe (of fish) | al · noun |
| [잘](https://en.wiktionary.org/wiki/%EC%9E%98#Korean) | well | jal · adv |
| [등](https://en.wiktionary.org/wiki/%EB%93%B1#Korean) | back of a person or animal | deung · noun |
| [오](https://en.wiktionary.org/wiki/%EC%98%A4#Korean) | five | o · num |
| [중](https://en.wiktionary.org/wiki/%EC%A4%91#Korean) | average; intermediate (grade or class) | jung · noun |
| [서](https://en.wiktionary.org/wiki/%EC%84%9C#Korean) | west | seo · noun |
| [못](https://en.wiktionary.org/wiki/%EB%AA%BB#Korean) | nail, peg, spike | mot · noun |
| [생각](https://en.wiktionary.org/wiki/%EC%83%9D%EA%B0%81#Korean) | thought | saenggak · noun |
| [번](https://en.wiktionary.org/wiki/%EB%B2%88#Korean) | occasion, time (as in first time, second time, etc.) | beon · noun |
| [개](https://en.wiktionary.org/wiki/%EA%B0%9C#Korean) | dog | gae · noun |
| [대](https://en.wiktionary.org/wiki/%EB%8C%80#Korean) | something large; something great | dae · noun |
| [두](https://en.wiktionary.org/wiki/%EB%91%90#Korean) | two (as a determiner before a noun or classifier) | du · num |
| [시간](https://en.wiktionary.org/wiki/%EC%8B%9C%EA%B0%84#Korean) | time | sigan · noun |
| [성](https://en.wiktionary.org/wiki/%EC%84%B1#Korean) | anger, rage, wrath | seong · noun |
| [분](https://en.wiktionary.org/wiki/%EB%B6%84#Korean) | one tenth, ¹⁄₁₀ | bun · num |
| [명](https://en.wiktionary.org/wiki/%EB%AA%85#Korean) | name | myeong · noun |
| [원](https://en.wiktionary.org/wiki/%EC%9B%90#Korean) | won; the official currency of South Korea, sign = ₩ (KRW) | won · noun |
| [살](https://en.wiktionary.org/wiki/%EC%82%B4#Korean) | flesh; skin | sal · noun |
| [다른](https://en.wiktionary.org/wiki/%EB%8B%A4%EB%A5%B8#Korean) | different, other | dareun · det |
| [지금](https://en.wiktionary.org/wiki/%EC%A7%80%EA%B8%88#Korean) | now | jigeum · adv |
| [때문](https://en.wiktionary.org/wiki/%EB%95%8C%EB%AC%B8#Korean) | cause (almost always follows a noun or nominalized clause with the meaning of "because (of)", except in the conjunction 때문에 (ttaemun-e)) | ttaemun · noun |
| [어서](https://en.wiktionary.org/wiki/%EC%96%B4%EC%84%9C#Korean) | quickly | eoseo · adv |
| [왜](https://en.wiktionary.org/wiki/%EC%99%9C#Korean) | why | wae · adv |
| [여자](https://en.wiktionary.org/wiki/%EC%97%AC%EC%9E%90#Korean) | woman | yeoja · noun |
| [위](https://en.wiktionary.org/wiki/%EC%9C%84#Korean) | above, upper, upside, top | wi · noun |
| [화](https://en.wiktionary.org/wiki/%ED%99%94#Korean) | anger; rage | hwa · noun |
| [좀](https://en.wiktionary.org/wiki/%EC%A2%80#Korean) | little while, short time | jom · adv |
| [건](https://en.wiktionary.org/wiki/%EA%B1%B4#Korean) | past determinative of 걸다 (geolda, “to speak or suspend”): having been suspended, spoken; of a telephone call, having been made | geon · verb |
| [하나](https://en.wiktionary.org/wiki/%ED%95%98%EB%82%98#Korean) | one (independently, without a classifier) | hana · num |
| [후](https://en.wiktionary.org/wiki/%ED%9B%84#Korean) | after | hu · noun |
| [같이](https://en.wiktionary.org/wiki/%EA%B0%99%EC%9D%B4#Korean) | together with | gachi · adv |
| [날](https://en.wiktionary.org/wiki/%EB%82%A0#Korean) | day (twenty-four hours, a thirtieth of the month) | nal · noun |
| [시작](https://en.wiktionary.org/wiki/%EC%8B%9C%EC%9E%91#Korean) | start, beginning | sijak · noun |
| [신](https://en.wiktionary.org/wiki/%EC%8B%A0#Korean) | god, deity | sin · noun |
| [사랑](https://en.wiktionary.org/wiki/%EC%82%AC%EB%9E%91#Korean) | love; affection (emotion) | sarang · noun |
| [그리고](https://en.wiktionary.org/wiki/%EA%B7%B8%EB%A6%AC%EA%B3%A0#Korean) | and, also, in addition (often used at the beginning of a sentence) | geurigo · adv |
| [게임](https://en.wiktionary.org/wiki/%EA%B2%8C%EC%9E%84#Korean) | game, especially computer games. | geim · noun |
| [군](https://en.wiktionary.org/wiki/%EA%B5%B0#Korean) | army | gun · noun |
| [및](https://en.wiktionary.org/wiki/%EB%B0%8F#Korean) | and, additionally | mit · adv |
| [사용](https://en.wiktionary.org/wiki/%EC%82%AC%EC%9A%A9#Korean) | usage in order to fulfill a purpose or role | sayong · noun |
| [차](https://en.wiktionary.org/wiki/%EC%B0%A8#Korean) | vehicle (usually refers to car) | cha · noun |
| [너](https://en.wiktionary.org/wiki/%EB%84%88#Korean) | four (before certain classifiers) | neo · num |
| [줄](https://en.wiktionary.org/wiki/%EC%A4%84#Korean) | ability, method; how to | jul · noun |
| [집](https://en.wiktionary.org/wiki/%EC%A7%91#Korean) | home, house | jip · noun |
| [함께](https://en.wiktionary.org/wiki/%ED%95%A8%EA%BB%98#Korean) | together | hamkke · adv |

</details>

<details><summary>Words 101–150</summary>

![[Resources/Audio/ko/Words 0101-0150.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [가지](https://en.wiktionary.org/wiki/%EA%B0%80%EC%A7%80#Korean) | kind, sort; variety | gaji · noun |
| [남자](https://en.wiktionary.org/wiki/%EB%82%A8%EC%9E%90#Korean) | man | namja · noun |
| [또](https://en.wiktionary.org/wiki/%EB%98%90#Korean) | also | tto · adv |
| [보다](https://en.wiktionary.org/wiki/%EB%B3%B4%EB%8B%A4#Korean) | to see, to look at, to watch (to perceive with the eyes) | boda · verb |
| [너무](https://en.wiktionary.org/wiki/%EB%84%88%EB%AC%B4#Korean) | too, excessively | neomu · adv |
| [사](https://en.wiktionary.org/wiki/%EC%82%AC#Korean) | four | sa · num |
| [오늘](https://en.wiktionary.org/wiki/%EC%98%A4%EB%8A%98#Korean) | today; this day | oneul · noun |
| [이런](https://en.wiktionary.org/wiki/%EC%9D%B4%EB%9F%B0#Korean) | like this; such | ireon · det |
| [이상](https://en.wiktionary.org/wiki/%EC%9D%B4%EC%83%81#Korean) | an amount more than | isang · noun |
| [함](https://en.wiktionary.org/wiki/%ED%95%A8#Korean) | box | ham · noun |
| [길](https://en.wiktionary.org/wiki/%EA%B8%B8#Korean) | a road, a path, a street, a track; passage, thoroughfare | gil · noun |
| [다시](https://en.wiktionary.org/wiki/%EB%8B%A4%EC%8B%9C#Korean) | again, once more | dasi · adv |
| [데](https://en.wiktionary.org/wiki/%EB%8D%B0#Korean) | place | de · noun |
| [모든](https://en.wiktionary.org/wiki/%EB%AA%A8%EB%93%A0#Korean) | all, every, each | modeun · det |
| [애](https://en.wiktionary.org/wiki/%EC%95%A0#Korean) | guy, person (usually rather young) | ae · noun |
| [필요](https://en.wiktionary.org/wiki/%ED%95%84%EC%9A%94#Korean) | need; necessity | piryo · noun |
| [문제](https://en.wiktionary.org/wiki/%EB%AC%B8%EC%A0%9C#Korean) | problem, issue, question | munje · noun |
| [곳](https://en.wiktionary.org/wiki/%EA%B3%B3#Korean) | place | got · noun |
| [씨](https://en.wiktionary.org/wiki/%EC%94%A8#Korean) | seed, kernel | ssi · noun |
| [정말](https://en.wiktionary.org/wiki/%EC%A0%95%EB%A7%90#Korean) | really; truly | jeongmal · adv |
| [죽](https://en.wiktionary.org/wiki/%EC%A3%BD#Korean) | in a manner arranged in a row; while arranging in a row | juk · noun |
| [세](https://en.wiktionary.org/wiki/%EC%84%B8#Korean) | three (before a noun or classifier) | se · num |
| [아이](https://en.wiktionary.org/wiki/%EC%95%84%EC%9D%B4#Korean) | child, kid | ai · noun |
| [자신](https://en.wiktionary.org/wiki/%EC%9E%90%EC%8B%A0#Korean) | one's body | jasin · noun |
| [형](https://en.wiktionary.org/wiki/%ED%98%95#Korean) | older brother of a male | hyeong · noun |
| [난](https://en.wiktionary.org/wiki/%EB%82%9C#Korean) | topic-marked form of 나 (na) | nan · pron |
| [달](https://en.wiktionary.org/wiki/%EB%8B%AC#Korean) | moon; the Moon | dal · noun |
| [세계](https://en.wiktionary.org/wiki/%EC%84%B8%EA%B3%84#Korean) | the world, the Earth | segye · noun |
| [이름](https://en.wiktionary.org/wiki/%EC%9D%B4%EB%A6%84#Korean) | name; full name | ireum · noun |
| [친구](https://en.wiktionary.org/wiki/%EC%B9%9C%EA%B5%AC#Korean) | friend | chin'gu · noun |
| [가장](https://en.wiktionary.org/wiki/%EA%B0%80%EC%9E%A5#Korean) | most, -est | gajang · adv |
| [권](https://en.wiktionary.org/wiki/%EA%B6%8C#Korean) | volume; book | gwon · noun |
| [끝](https://en.wiktionary.org/wiki/%EB%81%9D#Korean) | end, final | kkeut · noun |
| [남](https://en.wiktionary.org/wiki/%EB%82%A8#Korean) | other person, other people; someone other than the self | nam · noun |
| [다음](https://en.wiktionary.org/wiki/%EB%8B%A4%EC%9D%8C#Korean) | the next, the following | da'eum · noun |
| [비](https://en.wiktionary.org/wiki/%EB%B9%84#Korean) | rain | bi · noun |
| [속](https://en.wiktionary.org/wiki/%EC%86%8D#Korean) | the interior or inside, especially that which is underneath or within a covering | sok · noun |
| [지역](https://en.wiktionary.org/wiki/%EC%A7%80%EC%97%AD#Korean) | area, district, particular geographic region | jiyeok · noun |
| [모두](https://en.wiktionary.org/wiki/%EB%AA%A8%EB%91%90#Korean) | all, wholly | modu · adv |
| [사실](https://en.wiktionary.org/wiki/%EC%82%AC%EC%8B%A4#Korean) | fact, reality, truth | sasil · noun |
| [많이](https://en.wiktionary.org/wiki/%EB%A7%8E%EC%9D%B4#Korean) | many, much, a lot, plenty, in abundance | mani · adv |
| [바로](https://en.wiktionary.org/wiki/%EB%B0%94%EB%A1%9C#Korean) | truly, without lie or deception | baro · adv |
| [음](https://en.wiktionary.org/wiki/%EC%9D%8C#Korean) | hmm, umm, uh; indicating thinking or pondering, often with a sense of hesitation. | [ɯm] · intj |
| [볼](https://en.wiktionary.org/wiki/%EB%B3%BC#Korean) | cheek | bol · noun |
| [학교](https://en.wiktionary.org/wiki/%ED%95%99%EA%B5%90#Korean) | school | hakgyo · noun |
| [그런](https://en.wiktionary.org/wiki/%EA%B7%B8%EB%9F%B0#Korean) | like that, such | geureon · det |
| [앞](https://en.wiktionary.org/wiki/%EC%95%9E#Korean) | fore, front | ap · noun |
| [간](https://en.wiktionary.org/wiki/%EA%B0%84#Korean) | salty seasonings | gan · noun |
| [그냥](https://en.wiktionary.org/wiki/%EA%B7%B8%EB%83%A5#Korean) | simply; just like that; just as it is. | geunyang · adv |
| [상](https://en.wiktionary.org/wiki/%EC%83%81#Korean) | top, best, first (grade or class) | sang · noun |

</details>

<details><summary>Words 151–200</summary>

![[Resources/Audio/ko/Words 0151-0200.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [이제](https://en.wiktionary.org/wiki/%EC%9D%B4%EC%A0%9C#Korean) | now, and now | ije · noun |
| [물](https://en.wiktionary.org/wiki/%EB%AC%BC#Korean) | water | mul · noun |
| [호](https://en.wiktionary.org/wiki/%ED%98%B8#Korean) | number, issue, edition (of a model, publication, version, etc.) | ho · noun |
| [회](https://en.wiktionary.org/wiki/%ED%9A%8C#Korean) | sliced raw meat or fish; sashimi | hoe · noun |
| [경우](https://en.wiktionary.org/wiki/%EA%B2%BD%EC%9A%B0#Korean) | conditions, circumstances | gyeong'u · noun |
| [동안](https://en.wiktionary.org/wiki/%EB%8F%99%EC%95%88#Korean) | interval, period of time | dong'an · noun |
| [첫](https://en.wiktionary.org/wiki/%EC%B2%AB#Korean) | first; initial | cheot · det |
| [마음](https://en.wiktionary.org/wiki/%EB%A7%88%EC%9D%8C#Korean) | mind, heart (i.e. one's emotions) | ma'eum · noun |
| [본](https://en.wiktionary.org/wiki/%EB%B3%B8#Korean) | root, basis | bon · noun |
| [손](https://en.wiktionary.org/wiki/%EC%86%90#Korean) | hand (organ of humans and humanoid animals) | son · noun |
| [예](https://en.wiktionary.org/wiki/%EC%98%88#Korean) | yes (affirms the truth of the question as stated) | ye · intj |
| [정도](https://en.wiktionary.org/wiki/%EC%A0%95%EB%8F%84#Korean) | degree, extent | jeongdo · noun |
| [조](https://en.wiktionary.org/wiki/%EC%A1%B0#Korean) | foxtail millet (Setaria italica) | jo · noun |
| [타](https://en.wiktionary.org/wiki/%ED%83%80#Korean) | others, other people | ta · noun |
| [당](https://en.wiktionary.org/wiki/%EB%8B%B9#Korean) | justice | dang · noun |
| [장](https://en.wiktionary.org/wiki/%EC%9E%A5#Korean) | sauce; marmalade; jam; compote (stewed fruit); preserved vegetables; preserved fruit | jang · noun |
| [진](https://en.wiktionary.org/wiki/%EC%A7%84#Korean) | jeans, or jean fabric | jin · noun |
| [치](https://en.wiktionary.org/wiki/%EC%B9%98#Korean) | -'s worth of | chi · noun |
| [대표](https://en.wiktionary.org/wiki/%EB%8C%80%ED%91%9C#Korean) | something which is representative | daepyo · noun |
| [영화](https://en.wiktionary.org/wiki/%EC%98%81%ED%99%94#Korean) | movie, film | yeonghwa · noun |
| [자기](https://en.wiktionary.org/wiki/%EC%9E%90%EA%B8%B0#Korean) | oneself | jagi · noun |
| [뒤](https://en.wiktionary.org/wiki/%EB%92%A4#Korean) | back, latter, rear | dwi · noun |
| [마](https://en.wiktionary.org/wiki/%EB%A7%88#Korean) | jinx; devil, demon; evil spirit / influence | ma · noun |
| [뿐](https://en.wiktionary.org/wiki/%EB%BF%90#Korean) | only, just; used with -을, the "verbal irrealis adnominal suffix". | ppun · noun |
| [세상](https://en.wiktionary.org/wiki/%EC%84%B8%EC%83%81#Korean) | world | sesang · noun |
| [부](https://en.wiktionary.org/wiki/%EB%B6%80#Korean) | father | bu · noun |
| [여기](https://en.wiktionary.org/wiki/%EC%97%AC%EA%B8%B0#Korean) | here | yeogi · pron |
| [당신](https://en.wiktionary.org/wiki/%EB%8B%B9%EC%8B%A0#Korean) | second person singular plain pronoun; you | dangsin · pron |
| [돈](https://en.wiktionary.org/wiki/%EB%8F%88#Korean) | money | don · noun |
| [어떤](https://en.wiktionary.org/wiki/%EC%96%B4%EB%96%A4#Korean) | what kind of | eotteon · det |
| [눈](https://en.wiktionary.org/wiki/%EB%88%88#Korean) | eye (organ allowing animals to see) | nun · noun |
| [처음](https://en.wiktionary.org/wiki/%EC%B2%98%EC%9D%8C#Korean) | the first time | cheo'eum · noun |
| [팀](https://en.wiktionary.org/wiki/%ED%8C%80#Korean) | team | tim · noun |
| [또한](https://en.wiktionary.org/wiki/%EB%98%90%ED%95%9C#Korean) | also, too, furthermore | ttohan · adv |
| [이번](https://en.wiktionary.org/wiki/%EC%9D%B4%EB%B2%88#Korean) | this time; this occasion | ibeon · noun |
| [이야기](https://en.wiktionary.org/wiki/%EC%9D%B4%EC%95%BC%EA%B8%B0#Korean) | talk | iyagi · noun |
| [이유](https://en.wiktionary.org/wiki/%EC%9D%B4%EC%9C%A0#Korean) | reason; cause | iyu · noun |
| [밖](https://en.wiktionary.org/wiki/%EB%B0%96#Korean) | outside | bak · noun |
| [열](https://en.wiktionary.org/wiki/%EC%97%B4#Korean) | ten | yeol · num |
| [키](https://en.wiktionary.org/wiki/%ED%82%A4#Korean) | height of a person or animal | ki · noun |
| [감사](https://en.wiktionary.org/wiki/%EA%B0%90%EC%82%AC#Korean) | gratitude; thanks | gamsa · noun |
| [또는](https://en.wiktionary.org/wiki/%EB%98%90%EB%8A%94#Korean) | if not; alternatively | ttoneun · adv |
| [밤](https://en.wiktionary.org/wiki/%EB%B0%A4#Korean) | night | bam · noun |
| [불](https://en.wiktionary.org/wiki/%EB%B6%88#Korean) | fire; flame | bul · noun |
| [사진](https://en.wiktionary.org/wiki/%EC%82%AC%EC%A7%84#Korean) | photograph, picture | sajin · noun |
| [선](https://en.wiktionary.org/wiki/%EC%84%A0#Korean) | judging the quality of a person or thing in advance (especially for an arranged marriage) | seon · noun |
| [소리](https://en.wiktionary.org/wiki/%EC%86%8C%EB%A6%AC#Korean) | sound | sori · noun |
| [여성](https://en.wiktionary.org/wiki/%EC%97%AC%EC%84%B1#Korean) | female, woman, womenfolk, womankind | yeoseong · noun |
| [현재](https://en.wiktionary.org/wiki/%ED%98%84%EC%9E%AC#Korean) | the present; now | hyeonjae · noun |
| [계속](https://en.wiktionary.org/wiki/%EA%B3%84%EC%86%8D#Korean) | continuously | gyesok · adv |

</details>

<details><summary>Words 201–250</summary>

![[Resources/Audio/ko/Words 0201-0250.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [미](https://en.wiktionary.org/wiki/%EB%AF%B8#Korean) | beauty | mi · noun |
| [방송](https://en.wiktionary.org/wiki/%EB%B0%A9%EC%86%A1#Korean) | broadcasting | bangsong · noun |
| [아직](https://en.wiktionary.org/wiki/%EC%95%84%EC%A7%81#Korean) | still | ajik · adv |
| [이거](https://en.wiktionary.org/wiki/%EC%9D%B4%EA%B1%B0#Korean) | this thing, this matter | igeo · pron |
| [점](https://en.wiktionary.org/wiki/%EC%A0%90#Korean) | point, spot; dot, period, full stop | jeom · noun |
| [구](https://en.wiktionary.org/wiki/%EA%B5%AC#Korean) | nine | gu · num |
| [별](https://en.wiktionary.org/wiki/%EB%B3%84#Korean) | a star (celestial body) | byeol · noun |
| [용](https://en.wiktionary.org/wiki/%EC%9A%A9#Korean) | dragon | yong · noun |
| [활동](https://en.wiktionary.org/wiki/%ED%99%9C%EB%8F%99#Korean) | activity | hwaldong · noun |
| [나라](https://en.wiktionary.org/wiki/%EB%82%98%EB%9D%BC#Korean) | country, nation | nara · noun |
| [단](https://en.wiktionary.org/wiki/%EB%8B%A8#Korean) | sheaf | dan · noun |
| [몇](https://en.wiktionary.org/wiki/%EB%AA%87#Korean) | how many | myeot · det |
| [방법](https://en.wiktionary.org/wiki/%EB%B0%A9%EB%B2%95#Korean) | way; means; manner; method | bangbeop · noun |
| [사회](https://en.wiktionary.org/wiki/%EC%82%AC%ED%9A%8C#Korean) | society | sahoe · noun |
| [소](https://en.wiktionary.org/wiki/%EC%86%8C#Korean) | cow; bull; ox; cattle | so · noun |
| [어디](https://en.wiktionary.org/wiki/%EC%96%B4%EB%94%94#Korean) | where | eodi · pron |
| [정보](https://en.wiktionary.org/wiki/%EC%A0%95%EB%B3%B4#Korean) | information | jeongbo · noun |
| [그래서](https://en.wiktionary.org/wiki/%EA%B7%B8%EB%9E%98%EC%84%9C#Korean) | therefore, accordingly, because of that, because things are like that, thus. | geuraeseo · adv |
| [이후](https://en.wiktionary.org/wiki/%EC%9D%B4%ED%9B%84#Korean) | the time following a given point in time; thenceforth | ihu · noun |
| [정부](https://en.wiktionary.org/wiki/%EC%A0%95%EB%B6%80#Korean) | national government, particularly the executive branch | jeongbu · noun |
| [최고](https://en.wiktionary.org/wiki/%EC%B5%9C%EA%B3%A0#Korean) | the peak, the pinnacle, the topmost point | choego · noun |
| [법](https://en.wiktionary.org/wiki/%EB%B2%95#Korean) | law | beop · noun |
| [준비](https://en.wiktionary.org/wiki/%EC%A4%80%EB%B9%84#Korean) | readiness, preparation | junbi · noun |
| [그것](https://en.wiktionary.org/wiki/%EA%B7%B8%EA%B2%83#Korean) | that (thing near the listener) | geugeot · pron |
| [근데](https://en.wiktionary.org/wiki/%EA%B7%BC%EB%8D%B0#Korean) | however; but | geunde · adv |
| [새](https://en.wiktionary.org/wiki/%EC%83%88#Korean) | bird (in general) | sae · noun |
| [재](https://en.wiktionary.org/wiki/%EC%9E%AC#Korean) | ash | jae · noun |
| [천](https://en.wiktionary.org/wiki/%EC%B2%9C#Korean) | cloth; fabric | cheon · noun |
| [확인](https://en.wiktionary.org/wiki/%ED%99%95%EC%9D%B8#Korean) | check; confirmation; verification; affirmation | hwagin · noun |
| [방](https://en.wiktionary.org/wiki/%EB%B0%A9#Korean) | room | bang · noun |
| [인간](https://en.wiktionary.org/wiki/%EC%9D%B8%EA%B0%84#Korean) | human, human being | in'gan · noun |
| [해도](https://en.wiktionary.org/wiki/%ED%95%B4%EB%8F%84#Korean) | chart (of the sea) | haedo · noun |
| [가족](https://en.wiktionary.org/wiki/%EA%B0%80%EC%A1%B1#Korean) | household; family | gajok · noun |
| [계](https://en.wiktionary.org/wiki/%EA%B3%84#Korean) | kye, a Korean rotating savings and credit association | gye · noun |
| [계획](https://en.wiktionary.org/wiki/%EA%B3%84%ED%9A%8D#Korean) | a plan | gyehoek · noun |
| [교육](https://en.wiktionary.org/wiki/%EA%B5%90%EC%9C%A1#Korean) | education | gyoyuk · noun |
| [국가](https://en.wiktionary.org/wiki/%EA%B5%AD%EA%B0%80#Korean) | political state, nation, country, polity | gukga · noun |
| [대통령](https://en.wiktionary.org/wiki/%EB%8C%80%ED%86%B5%EB%A0%B9#Korean) | president of a country | daetongnyeong · noun |
| [문](https://en.wiktionary.org/wiki/%EB%AC%B8#Korean) | door | mun · noun |
| [문화](https://en.wiktionary.org/wiki/%EB%AC%B8%ED%99%94#Korean) | culture | munhwa · noun |
| [배](https://en.wiktionary.org/wiki/%EB%B0%B0#Korean) | abdomen, belly (of a human or animal) | bae · noun |
| [약](https://en.wiktionary.org/wiki/%EC%95%BD#Korean) | drug; medicine | yak · noun |
| [연구](https://en.wiktionary.org/wiki/%EC%97%B0%EA%B5%AC#Korean) | research | yeon'gu · noun |
| [결과](https://en.wiktionary.org/wiki/%EA%B2%B0%EA%B3%BC#Korean) | as a result of | gyeolgwa · adv |
| [도시](https://en.wiktionary.org/wiki/%EB%8F%84%EC%8B%9C#Korean) | city | dosi · noun |
| [바](https://en.wiktionary.org/wiki/%EB%B0%94#Korean) | thing; what | ba · noun |
| [사건](https://en.wiktionary.org/wiki/%EC%82%AC%EA%B1%B4#Korean) | a noteworthy or remarkable incident | sageon · noun |
| [상태](https://en.wiktionary.org/wiki/%EC%83%81%ED%83%9C#Korean) | condition, status | sangtae · noun |
| [조금](https://en.wiktionary.org/wiki/%EC%A1%B0%EA%B8%88#Korean) | a little; a bit | jogeum · adv |
| [참](https://en.wiktionary.org/wiki/%EC%B0%B8#Korean) | truly, really | cham · adv |

</details>

<details><summary>Words 251–300</summary>

![[Resources/Audio/ko/Words 0251-0300.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [결정](https://en.wiktionary.org/wiki/%EA%B2%B0%EC%A0%95#Korean) | decision | gyeoljeong · noun |
| [경기](https://en.wiktionary.org/wiki/%EA%B2%BD%EA%B8%B0#Korean) | a sporting or athletic competition or match | gyeonggi · noun |
| [관련](https://en.wiktionary.org/wiki/%EA%B4%80%EB%A0%A8#Korean) | connection, relation | gwallyeon · noun |
| [그러나](https://en.wiktionary.org/wiki/%EA%B7%B8%EB%9F%AC%EB%82%98#Korean) | but, however | geureona · adv |
| [둘](https://en.wiktionary.org/wiki/%EB%91%98#Korean) | two | dul · num |
| [모습](https://en.wiktionary.org/wiki/%EB%AA%A8%EC%8A%B5#Korean) | the appearance of a person | moseup · noun |
| [없이](https://en.wiktionary.org/wiki/%EC%97%86%EC%9D%B4#Korean) | without, lacking | eopsi · adv |
| [초](https://en.wiktionary.org/wiki/%EC%B4%88#Korean) | the SI unit of time, second | cho · noun |
| [피](https://en.wiktionary.org/wiki/%ED%94%BC#Korean) | blood (bodily fluid) | pi · noun |
| [관계](https://en.wiktionary.org/wiki/%EA%B4%80%EA%B3%84#Korean) | connection; relationship | gwan'gye · noun |
| [막](https://en.wiktionary.org/wiki/%EB%A7%89#Korean) | just now, a moment ago | mak · adv |
| [무슨](https://en.wiktionary.org/wiki/%EB%AC%B4%EC%8A%A8#Korean) | what, what kind of | museun · det |
| [반](https://en.wiktionary.org/wiki/%EB%B0%98#Korean) | half | ban · noun |
| [사이](https://en.wiktionary.org/wiki/%EC%82%AC%EC%9D%B4#Korean) | gap; space between | sai · noun |
| [생](https://en.wiktionary.org/wiki/%EC%83%9D#Korean) | life | saeng · noun |
| [아들](https://en.wiktionary.org/wiki/%EC%95%84%EB%93%A4#Korean) | son | adeul · noun |
| [힘](https://en.wiktionary.org/wiki/%ED%9E%98#Korean) | strength; power | him · noun |
| [노래](https://en.wiktionary.org/wiki/%EB%85%B8%EB%9E%98#Korean) | song | norae · noun |
| [누구](https://en.wiktionary.org/wiki/%EB%88%84%EA%B5%AC#Korean) | who | nugu · pron |
| [몸](https://en.wiktionary.org/wiki/%EB%AA%B8#Korean) | body (of a human or animal) | mom · noun |
| [상황](https://en.wiktionary.org/wiki/%EC%83%81%ED%99%A9#Korean) | conditions, the situation | sanghwang · noun |
| [십](https://en.wiktionary.org/wiki/%EC%8B%AD#Korean) | ten | sip · num |
| [프로그램](https://en.wiktionary.org/wiki/%ED%94%84%EB%A1%9C%EA%B7%B8%EB%9E%A8#Korean) | program (performance of a show or other broadcast on radio or television) | peurogeuraem · noun |
| [글](https://en.wiktionary.org/wiki/%EA%B8%80#Korean) | a piece of writing; a written work such as a book or article | geul · noun |
| [기술](https://en.wiktionary.org/wiki/%EA%B8%B0%EC%88%A0#Korean) | technology | gisul · noun |
| [뜻](https://en.wiktionary.org/wiki/%EB%9C%BB#Korean) | meaning, sense, significance | tteut · noun |
| [마지막](https://en.wiktionary.org/wiki/%EB%A7%88%EC%A7%80%EB%A7%89#Korean) | the end; the last thing | majimak · noun |
| [머리](https://en.wiktionary.org/wiki/%EB%A8%B8%EB%A6%AC#Korean) | head | meori · noun |
| [이것](https://en.wiktionary.org/wiki/%EC%9D%B4%EA%B2%83#Korean) | this | igeot · pron |
| [기록](https://en.wiktionary.org/wiki/%EA%B8%B0%EB%A1%9D#Korean) | a record (of something) | girok · noun |
| [부분](https://en.wiktionary.org/wiki/%EB%B6%80%EB%B6%84#Korean) | portion; section; part | bubun · noun |
| [안녕](https://en.wiktionary.org/wiki/%EC%95%88%EB%85%95#Korean) | peace; tranquility | annyeong · noun |
| [위치](https://en.wiktionary.org/wiki/%EC%9C%84%EC%B9%98#Korean) | location | wichi · noun |
| [의미](https://en.wiktionary.org/wiki/%EC%9D%98%EB%AF%B8#Korean) | meaning (of words or deeds) | uimi · noun |
| [이미](https://en.wiktionary.org/wiki/%EC%9D%B4%EB%AF%B8#Korean) | already | imi · adv |
| [전화](https://en.wiktionary.org/wiki/%EC%A0%84%ED%99%94#Korean) | telephone, phone | jeonhwa · noun |
| [지원](https://en.wiktionary.org/wiki/%EC%A7%80%EC%9B%90#Korean) | support; aid | jiwon · noun |
| [질](https://en.wiktionary.org/wiki/%EC%A7%88#Korean) | quality | jil · noun |
| [대학](https://en.wiktionary.org/wiki/%EB%8C%80%ED%95%99#Korean) | college, university | daehak · noun |
| [물론](https://en.wiktionary.org/wiki/%EB%AC%BC%EB%A1%A0#Korean) | of course, certainly, naturally | mullon · adv |
| [여러](https://en.wiktionary.org/wiki/%EC%97%AC%EB%9F%AC#Korean) | several, various | yeoreo · det |
| [그녀](https://en.wiktionary.org/wiki/%EA%B7%B8%EB%85%80#Korean) | she | geunyeo · pron |
| [하루](https://en.wiktionary.org/wiki/%ED%95%98%EB%A3%A8#Korean) | a day, 24 hours | haru · noun |
| [그럼](https://en.wiktionary.org/wiki/%EA%B7%B8%EB%9F%BC#Korean) | then, in that case | geureom · adv |
| [아무](https://en.wiktionary.org/wiki/%EC%95%84%EB%AC%B4#Korean) | any | amu · det |
| [언제](https://en.wiktionary.org/wiki/%EC%96%B8%EC%A0%9C#Korean) | when | eonje · pron |
| [자리](https://en.wiktionary.org/wiki/%EC%9E%90%EB%A6%AC#Korean) | space, place, site (occupied by something or someone) | jari · noun |
| [기억](https://en.wiktionary.org/wiki/%EA%B8%B0%EC%96%B5#Korean) | recall; the faculty of memory | gieok · noun |
| [듯](https://en.wiktionary.org/wiki/%EB%93%AF#Korean) | as if; in a manner suggesting that | deut · noun |
| [무](https://en.wiktionary.org/wiki/%EB%AC%B4#Korean) | Korean radish, a variety of daikon commonly consumed in Korea (both the plant and its edible root) | mu · noun |

</details>

<details><summary>Words 301–350</summary>

![[Resources/Audio/ko/Words 0301-0350.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [엄마](https://en.wiktionary.org/wiki/%EC%97%84%EB%A7%88#Korean) | mum, mummy | eomma · noun |
| [여러분](https://en.wiktionary.org/wiki/%EC%97%AC%EB%9F%AC%EB%B6%84#Korean) | ladies and gentlemen; everyone (present) | yeoreobun · noun |
| [역사](https://en.wiktionary.org/wiki/%EC%97%AD%EC%82%AC#Korean) | history (the process of transformation, rise, and decline of human society, or the record of such events) | yeoksa · noun |
| [운동](https://en.wiktionary.org/wiki/%EC%9A%B4%EB%8F%99#Korean) | exercise, physical activity; sport, sports | undong · noun |
| [이해](https://en.wiktionary.org/wiki/%EC%9D%B4%ED%95%B4#Korean) | understanding, comprehension of something | ihae · noun |
| [가격](https://en.wiktionary.org/wiki/%EA%B0%80%EA%B2%A9#Korean) | monetary price | gagyeok · noun |
| [꼭](https://en.wiktionary.org/wiki/%EA%BC%AD#Korean) | absolutely; surely | kkok · adv |
| [시대](https://en.wiktionary.org/wiki/%EC%8B%9C%EB%8C%80#Korean) | historical age or period | sidae · noun |
| [아버지](https://en.wiktionary.org/wiki/%EC%95%84%EB%B2%84%EC%A7%80#Korean) | father (parent) | abeoji · noun |
| [양](https://en.wiktionary.org/wiki/%EC%96%91#Korean) | quantity, amount | yang · noun |
| [김](https://en.wiktionary.org/wiki/%EA%B9%80#Korean) | laver (nori, a type of edible seaweed in the genus Porphyra) | gim · noun |
| [삼](https://en.wiktionary.org/wiki/%EC%82%BC#Korean) | three | sam · num |
| [역시](https://en.wiktionary.org/wiki/%EC%97%AD%EC%8B%9C#Korean) | too, also | yeoksi · adv |
| [편](https://en.wiktionary.org/wiki/%ED%8E%B8#Korean) | side | pyeon · noun |
| [회사](https://en.wiktionary.org/wiki/%ED%9A%8C%EC%82%AC#Korean) | a company | hoesa · noun |
| [국민](https://en.wiktionary.org/wiki/%EA%B5%AD%EB%AF%BC#Korean) | people of a nation | gungmin · noun |
| [기준](https://en.wiktionary.org/wiki/%EA%B8%B0%EC%A4%80#Korean) | a fundamental standard or criterion | gijun · noun |
| [꿈](https://en.wiktionary.org/wiki/%EA%BF%88#Korean) | dream | kkum · noun |
| [부산](https://en.wiktionary.org/wiki/%EB%B6%80%EC%82%B0#Korean) | din; ruckus; commotion | busan · noun |
| [책](https://en.wiktionary.org/wiki/%EC%B1%85#Korean) | book | chaek · noun |
| [항상](https://en.wiktionary.org/wiki/%ED%95%AD%EC%83%81#Korean) | always | hangsang · adv |
| [각](https://en.wiktionary.org/wiki/%EA%B0%81#Korean) | each | gak · det |
| [거리](https://en.wiktionary.org/wiki/%EA%B1%B0%EB%A6%AC#Korean) | road, street | geori · noun |
| [거의](https://en.wiktionary.org/wiki/%EA%B1%B0%EC%9D%98#Korean) | almost, nearly | geoui · noun |
| [경제](https://en.wiktionary.org/wiki/%EA%B2%BD%EC%A0%9C#Korean) | economy | gyeongje · noun |
| [기분](https://en.wiktionary.org/wiki/%EA%B8%B0%EB%B6%84#Korean) | feeling, mood | gibun · noun |
| [먼저](https://en.wiktionary.org/wiki/%EB%A8%BC%EC%A0%80#Korean) | first in time or sequence | meonjeo · adv |
| [아침](https://en.wiktionary.org/wiki/%EC%95%84%EC%B9%A8#Korean) | morning | achim · noun |
| [얼굴](https://en.wiktionary.org/wiki/%EC%96%BC%EA%B5%B4#Korean) | face | eolgul · noun |
| [존재](https://en.wiktionary.org/wiki/%EC%A1%B4%EC%9E%AC#Korean) | existence | jonjae · noun |
| [내용](https://en.wiktionary.org/wiki/%EB%82%B4%EC%9A%A9#Korean) | that which is contained in a container | naeyong · noun |
| [병원](https://en.wiktionary.org/wiki/%EB%B3%91%EC%9B%90#Korean) | hospital | byeong'won · noun |
| [아주](https://en.wiktionary.org/wiki/%EC%95%84%EC%A3%BC#Korean) | very | aju · adv |
| [조사](https://en.wiktionary.org/wiki/%EC%A1%B0%EC%82%AC#Korean) | investigation; examination | josa · noun |
| [교수](https://en.wiktionary.org/wiki/%EA%B5%90%EC%88%98#Korean) | instruction | gyosu · noun |
| [구성](https://en.wiktionary.org/wiki/%EA%B5%AC%EC%84%B1#Korean) | configuration, arrangement, composition | guseong · noun |
| [기업](https://en.wiktionary.org/wiki/%EA%B8%B0%EC%97%85#Korean) | a business | gieop · noun |
| [일반](https://en.wiktionary.org/wiki/%EC%9D%BC%EB%B0%98#Korean) | general; common | ilban · noun |
| [자유](https://en.wiktionary.org/wiki/%EC%9E%90%EC%9C%A0#Korean) | freedom, liberty | jayu · noun |
| [쪽](https://en.wiktionary.org/wiki/%EC%AA%BD#Korean) | side | jjok · noun |
| [팔](https://en.wiktionary.org/wiki/%ED%8C%94#Korean) | arm | pal · noun |
| [혼자](https://en.wiktionary.org/wiki/%ED%98%BC%EC%9E%90#Korean) | solitude | honja · noun |
| [과정](https://en.wiktionary.org/wiki/%EA%B3%BC%EC%A0%95#Korean) | process, a course of events | gwajeong · noun |
| [대로](https://en.wiktionary.org/wiki/%EB%8C%80%EB%A1%9C#Korean) | the same way as, the manner of | daero · noun |
| [대부분](https://en.wiktionary.org/wiki/%EB%8C%80%EB%B6%80%EB%B6%84#Korean) | the majority, the better part | daebubun · noun |
| [매우](https://en.wiktionary.org/wiki/%EB%A7%A4%EC%9A%B0#Korean) | very, extremely | mae'u · adv |
| [백](https://en.wiktionary.org/wiki/%EB%B0%B1#Korean) | hundred | baek · num |
| [사업](https://en.wiktionary.org/wiki/%EC%82%AC%EC%97%85#Korean) | business | sa'eop · noun |
| [삶](https://en.wiktionary.org/wiki/%EC%82%B6#Korean) | life; living | sam · noun |
| [서로](https://en.wiktionary.org/wiki/%EC%84%9C%EB%A1%9C#Korean) | mutually, with each other, with one another | seoro · adv |

</details>

<details><summary>Words 351–400</summary>

![[Resources/Audio/ko/Words 0351-0400.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [선택](https://en.wiktionary.org/wiki/%EC%84%A0%ED%83%9D#Korean) | selection; choice; option | seontaek · noun |
| [작품](https://en.wiktionary.org/wiki/%EC%9E%91%ED%92%88#Korean) | a creative work or product | jakpum · noun |
| [정치](https://en.wiktionary.org/wiki/%EC%A0%95%EC%B9%98#Korean) | politics; governmental affairs | jeongchi · noun |
| [직접](https://en.wiktionary.org/wiki/%EC%A7%81%EC%A0%91#Korean) | immediateness; directness | jikjeop · noun |
| [학생](https://en.wiktionary.org/wiki/%ED%95%99%EC%83%9D#Korean) | student, scholar, school pupil | haksaeng · noun |
| [개인](https://en.wiktionary.org/wiki/%EA%B0%9C%EC%9D%B8#Korean) | an individual or individuals; a private person | gaein · noun |
| [결국](https://en.wiktionary.org/wiki/%EA%B2%B0%EA%B5%AD#Korean) | in the end, ultimately | gyeolguk · adv |
| [대회](https://en.wiktionary.org/wiki/%EB%8C%80%ED%9A%8C#Korean) | a competition, contest or tournament | daehoe · noun |
| [산](https://en.wiktionary.org/wiki/%EC%82%B0#Korean) | mountain | san · noun |
| [왕](https://en.wiktionary.org/wiki/%EC%99%95#Korean) | king; monarch | wang · noun |
| [음악](https://en.wiktionary.org/wiki/%EC%9D%8C%EC%95%85#Korean) | music | eumak · noun |
| [응](https://en.wiktionary.org/wiki/%EC%9D%91#Korean) | yes | eung · intj |
| [의원](https://en.wiktionary.org/wiki/%EC%9D%98%EC%9B%90#Korean) | member of a parliament or assembly | uiwon · noun |
| [특별](https://en.wiktionary.org/wiki/%ED%8A%B9%EB%B3%84#Korean) | The state or quality of being special. | teukbyeol · noun |
| [뉴스](https://en.wiktionary.org/wiki/%EB%89%B4%EC%8A%A4#Korean) | a news broadcast | nyuseu · noun |
| [도움](https://en.wiktionary.org/wiki/%EB%8F%84%EC%9B%80#Korean) | help; assistance; favour, favor | doum · noun |
| [부탁](https://en.wiktionary.org/wiki/%EB%B6%80%ED%83%81#Korean) | request, favor | butak · noun |
| [어느](https://en.wiktionary.org/wiki/%EC%96%B4%EB%8A%90#Korean) | which | eoneu · det |
| [인생](https://en.wiktionary.org/wiki/%EC%9D%B8%EC%83%9D#Korean) | one's life | insaeng · noun |
| [카](https://en.wiktionary.org/wiki/%EC%B9%B4#Korean) | car | ka · noun |
| [풀](https://en.wiktionary.org/wiki/%ED%92%80#Korean) | herbaceous plants, particularly grass | pul · noun |
| [결혼](https://en.wiktionary.org/wiki/%EA%B2%B0%ED%98%BC#Korean) | marriage | gyeolhon · noun |
| [국제](https://en.wiktionary.org/wiki/%EA%B5%AD%EC%A0%9C#Korean) | international, internationality | gukje · noun |
| [그거](https://en.wiktionary.org/wiki/%EA%B7%B8%EA%B1%B0#Korean) | it, that thing | geugeo · pron |
| [그래도](https://en.wiktionary.org/wiki/%EA%B7%B8%EB%9E%98%EB%8F%84#Korean) | nevertheless | geuraedo · adv |
| [딸](https://en.wiktionary.org/wiki/%EB%94%B8#Korean) | daughter (female child) | ttal · noun |
| [식](https://en.wiktionary.org/wiki/%EC%8B%9D#Korean) | ceremony, ritual, expression, type (a standard way of doing things) | sik · noun |
| [이게](https://en.wiktionary.org/wiki/%EC%9D%B4%EA%B2%8C#Korean) | this thing (as the subject of the sentence or clause) | ige · pron |
| [정신](https://en.wiktionary.org/wiki/%EC%A0%95%EC%8B%A0#Korean) | mind; consciousness; pneuma; psyche | jeongsin · noun |
| [관리](https://en.wiktionary.org/wiki/%EA%B4%80%EB%A6%AC#Korean) | administration, management, supervision | gwalli · noun |
| [돌](https://en.wiktionary.org/wiki/%EB%8F%8C#Korean) | rock, stone; pebble | dol · noun |
| [말씀](https://en.wiktionary.org/wiki/%EB%A7%90%EC%94%80#Korean) | word or speech | malsseum · noun |
| [선수](https://en.wiktionary.org/wiki/%EC%84%A0%EC%88%98#Korean) | athlete; sportsman; a person who participates in a sport | seonsu · noun |
| [설치](https://en.wiktionary.org/wiki/%EC%84%A4%EC%B9%98#Korean) | installation, establishment | seolchi · noun |
| [얼마나](https://en.wiktionary.org/wiki/%EC%96%BC%EB%A7%88%EB%82%98#Korean) | how long, how much, how many | eolmana · adv |
| [전쟁](https://en.wiktionary.org/wiki/%EC%A0%84%EC%9F%81#Korean) | war | jeonjaeng · noun |
| [층](https://en.wiktionary.org/wiki/%EC%B8%B5#Korean) | storey or floor | cheung · noun |
| [특히](https://en.wiktionary.org/wiki/%ED%8A%B9%ED%9E%88#Korean) | in particular, notably | teukhi · adv |
| [공연](https://en.wiktionary.org/wiki/%EA%B3%B5%EC%97%B0#Korean) | a public performance | gong'yeon · noun |
| [기대](https://en.wiktionary.org/wiki/%EA%B8%B0%EB%8C%80#Korean) | expectation; hope | gidae · noun |
| [당시](https://en.wiktionary.org/wiki/%EB%8B%B9%EC%8B%9C#Korean) | the time in question | dangsi · noun |
| [아래](https://en.wiktionary.org/wiki/%EC%95%84%EB%9E%98#Korean) | below, bottom, lower, underneath | arae · noun |
| [위원회](https://en.wiktionary.org/wiki/%EC%9C%84%EC%9B%90%ED%9A%8C#Korean) | committee | wiwonhoe · noun |
| [그런데](https://en.wiktionary.org/wiki/%EA%B7%B8%EB%9F%B0%EB%8D%B0#Korean) | but, however, on the other hand | geureonde · adv |
| [급](https://en.wiktionary.org/wiki/%EA%B8%89#Korean) | rank; level; grade | geup · noun |
| [내일](https://en.wiktionary.org/wiki/%EB%82%B4%EC%9D%BC#Korean) | tomorrow | naeil · noun |
| [빨리](https://en.wiktionary.org/wiki/%EB%B9%A8%EB%A6%AC#Korean) | quickly, without delay; often used when urging someone to hurry | ppalli · adv |
| [생활](https://en.wiktionary.org/wiki/%EC%83%9D%ED%99%9C#Korean) | lifestyle, way of life | saenghwal · noun |
| [서비스](https://en.wiktionary.org/wiki/%EC%84%9C%EB%B9%84%EC%8A%A4#Korean) | service | seobiseu · noun |
| [순간](https://en.wiktionary.org/wiki/%EC%88%9C%EA%B0%84#Korean) | an instant; a moment | sun'gan · noun |

</details>

<details><summary>Words 401–450</summary>

![[Resources/Audio/ko/Words 0401-0450.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [일부](https://en.wiktionary.org/wiki/%EC%9D%BC%EB%B6%80#Korean) | part of a whole | ilbu · noun |
| [지방](https://en.wiktionary.org/wiki/%EC%A7%80%EB%B0%A9#Korean) | a geographical region | jibang · noun |
| [질문](https://en.wiktionary.org/wiki/%EC%A7%88%EB%AC%B8#Korean) | a question | jilmun · noun |
| [관심](https://en.wiktionary.org/wiki/%EA%B4%80%EC%8B%AC#Korean) | interest in, or inclination to, a topic or activity | gwansim · noun |
| [그래](https://en.wiktionary.org/wiki/%EA%B7%B8%EB%9E%98#Korean) | like this, like that | geurae · adv |
| [그룹](https://en.wiktionary.org/wiki/%EA%B7%B8%EB%A3%B9#Korean) | group (number of things or persons being in some relation to each other) | geurup · noun |
| [단체](https://en.wiktionary.org/wiki/%EB%8B%A8%EC%B2%B4#Korean) | a group or organization of people | danche · noun |
| [대신](https://en.wiktionary.org/wiki/%EB%8C%80%EC%8B%A0#Korean) | substitution, replacement (with 에 (e), it is often translated as "instead of", "in place of", etc.) | daesin · noun |
| [마을](https://en.wiktionary.org/wiki/%EB%A7%88%EC%9D%84#Korean) | village, hamlet, usually in rural surroundings | ma'eul · noun |
| [무엇](https://en.wiktionary.org/wiki/%EB%AC%B4%EC%97%87#Korean) | what - used in questions | mueot · pron |
| [박](https://en.wiktionary.org/wiki/%EB%B0%95#Korean) | gourd, calabash | bak · noun |
| [방식](https://en.wiktionary.org/wiki/%EB%B0%A9%EC%8B%9D#Korean) | a specified method or form | bangsik · noun |
| [사고](https://en.wiktionary.org/wiki/%EC%82%AC%EA%B3%A0#Korean) | an accident | sago · noun |
| [선생](https://en.wiktionary.org/wiki/%EC%84%A0%EC%83%9D#Korean) | teacher | seonsaeng · noun |
| [설명](https://en.wiktionary.org/wiki/%EC%84%A4%EB%AA%85#Korean) | explanation | seolmyeong · noun |
| [영향](https://en.wiktionary.org/wiki/%EC%98%81%ED%96%A5#Korean) | influence; effect | yeonghyang · noun |
| [외](https://en.wiktionary.org/wiki/%EC%99%B8#Korean) | other things | oe · noun |
| [기간](https://en.wiktionary.org/wiki/%EA%B8%B0%EA%B0%84#Korean) | a set interval or period of time | gigan · noun |
| [자료](https://en.wiktionary.org/wiki/%EC%9E%90%EB%A3%8C#Korean) | data; documentation | jaryo · noun |
| [저희](https://en.wiktionary.org/wiki/%EC%A0%80%ED%9D%AC#Korean) | the first person plural polite pronoun; we | jeohui · pron |
| [전체](https://en.wiktionary.org/wiki/%EC%A0%84%EC%B2%B4#Korean) | the whole | jeonche · noun |
| [제발](https://en.wiktionary.org/wiki/%EC%A0%9C%EB%B0%9C#Korean) | please | jebal · adv |
| [행동](https://en.wiktionary.org/wiki/%ED%96%89%EB%8F%99#Korean) | action | haengdong · noun |
| [걱정](https://en.wiktionary.org/wiki/%EA%B1%B1%EC%A0%95#Korean) | anxiety; worry | geokjeong · noun |
| [느낌](https://en.wiktionary.org/wiki/%EB%8A%90%EB%82%8C#Korean) | feeling | neukkim · noun |
| [옷](https://en.wiktionary.org/wiki/%EC%98%B7#Korean) | clothing; clothes | ot · noun |
| [중심](https://en.wiktionary.org/wiki/%EC%A4%91%EC%8B%AC#Korean) | center, core | jungsim · noun |
| [표현](https://en.wiktionary.org/wiki/%ED%91%9C%ED%98%84#Korean) | expression (through words or actions) | pyohyeon · noun |
| [경찰](https://en.wiktionary.org/wiki/%EA%B2%BD%EC%B0%B0#Korean) | police; policing | gyeongchal · noun |
| [기회](https://en.wiktionary.org/wiki/%EA%B8%B0%ED%9A%8C#Korean) | opportunity | gihoe · noun |
| [노](https://en.wiktionary.org/wiki/%EB%85%B8#Korean) | string, cord (twisted hemp, paper, etc.) | no · noun |
| [늘](https://en.wiktionary.org/wiki/%EB%8A%98#Korean) | always | neul · adv |
| [달러](https://en.wiktionary.org/wiki/%EB%8B%AC%EB%9F%AC#Korean) | dollar | dalleo · noun |
| [담](https://en.wiktionary.org/wiki/%EB%8B%B4#Korean) | wall | dam · noun |
| [예정](https://en.wiktionary.org/wiki/%EC%98%88%EC%A0%95#Korean) | prediction, expectation | yejeong · noun |
| [작가](https://en.wiktionary.org/wiki/%EC%9E%91%EA%B0%80#Korean) | an artist or artists, including singers, painters, writers, etc. | jakga · noun |
| [제대로](https://en.wiktionary.org/wiki/%EC%A0%9C%EB%8C%80%EB%A1%9C#Korean) | properly, in the appropriate manner | jedaero · adv |
| [주장](https://en.wiktionary.org/wiki/%EC%A3%BC%EC%9E%A5#Korean) | a claim or assertion | jujang · noun |
| [파](https://en.wiktionary.org/wiki/%ED%8C%8C#Korean) | spring onion | pa · noun |
| [기관](https://en.wiktionary.org/wiki/%EA%B8%B0%EA%B4%80#Korean) | engine; machine | gigwan · noun |
| [보호](https://en.wiktionary.org/wiki/%EB%B3%B4%ED%98%B8#Korean) | protection | boho · noun |
| [시장](https://en.wiktionary.org/wiki/%EC%8B%9C%EC%9E%A5#Korean) | hunger | sijang · noun |
| [오래](https://en.wiktionary.org/wiki/%EC%98%A4%EB%9E%98#Korean) | long, for a long time or while | orae · adv |
| [짓](https://en.wiktionary.org/wiki/%EC%A7%93#Korean) | a physical act or movement | jit · noun |
| [채](https://en.wiktionary.org/wiki/%EC%B1%84#Korean) | a whip, a scourge | chae · noun |
| [감독](https://en.wiktionary.org/wiki/%EA%B0%90%EB%8F%85#Korean) | direction, supervision | gamdok · noun |
| [구조](https://en.wiktionary.org/wiki/%EA%B5%AC%EC%A1%B0#Korean) | a structure | gujo · noun |
| [노력](https://en.wiktionary.org/wiki/%EB%85%B8%EB%A0%A5#Korean) | striving, making an effort to accomplish something | noryeok · noun |
| [발](https://en.wiktionary.org/wiki/%EB%B0%9C#Korean) | foot (of a human or amother animal) | bal · noun |
| [조직](https://en.wiktionary.org/wiki/%EC%A1%B0%EC%A7%81#Korean) | organization, structure | jojik · noun |

</details>

<details><summary>Words 451–500</summary>

![[Resources/Audio/ko/Words 0451-0500.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [최](https://en.wiktionary.org/wiki/%EC%B5%9C#Korean) | Finite or limit | choe · det |
| [감](https://en.wiktionary.org/wiki/%EA%B0%90#Korean) | feeling; sense | gam · noun |
| [강](https://en.wiktionary.org/wiki/%EA%B0%95#Korean) | river | gang · noun |
| [과학](https://en.wiktionary.org/wiki/%EA%B3%BC%ED%95%99#Korean) | science | gwahak · noun |
| [대화](https://en.wiktionary.org/wiki/%EB%8C%80%ED%99%94#Korean) | dialogue, conversation | daehwa · noun |
| [상대](https://en.wiktionary.org/wiki/%EC%83%81%EB%8C%80#Korean) | Facing or confronting. | sangdae · noun |
| [술](https://en.wiktionary.org/wiki/%EC%88%A0#Korean) | alcoholic beverage; liquor | sul · noun |
| [어머니](https://en.wiktionary.org/wiki/%EC%96%B4%EB%A8%B8%EB%8B%88#Korean) | mother | eomeoni · noun |
| [영어](https://en.wiktionary.org/wiki/%EC%98%81%EC%96%B4#Korean) | the English language | yeong'eo · noun |
| [우주](https://en.wiktionary.org/wiki/%EC%9A%B0%EC%A3%BC#Korean) | space; outer space | uju · noun |
| [원래](https://en.wiktionary.org/wiki/%EC%9B%90%EB%9E%98#Korean) | originally; naturally, inherently, innately | wollae · adv |
| [입장](https://en.wiktionary.org/wiki/%EC%9E%85%EC%9E%A5#Korean) | standpoint; perspective | ipjang · noun |
| [치료](https://en.wiktionary.org/wiki/%EC%B9%98%EB%A3%8C#Korean) | Treatment for a disease or injury, usually medical in nature. | chiryo · noun |
| [평가](https://en.wiktionary.org/wiki/%ED%8F%89%EA%B0%80#Korean) | evaluation, assessment | pyeongga · noun |
| [검사](https://en.wiktionary.org/wiki/%EA%B2%80%EC%82%AC#Korean) | examination | geomsa · noun |
| [전국](https://en.wiktionary.org/wiki/%EC%A0%84%EA%B5%AD#Korean) | the whole land making up a country | jeon'guk · noun |
| [주변](https://en.wiktionary.org/wiki/%EC%A3%BC%EB%B3%80#Korean) | the vicinity | jubyeon · noun |
| [환자](https://en.wiktionary.org/wiki/%ED%99%98%EC%9E%90#Korean) | a medical patient | hwanja · noun |
| [공](https://en.wiktionary.org/wiki/%EA%B3%B5#Korean) | ball | gong · noun |
| [공원](https://en.wiktionary.org/wiki/%EA%B3%B5%EC%9B%90#Korean) | park | gong'won · noun |
| [낮](https://en.wiktionary.org/wiki/%EB%82%AE#Korean) | daytime | nat · noun |
| [능력](https://en.wiktionary.org/wiki/%EB%8A%A5%EB%A0%A5#Korean) | capacity, ability (especially of a person) | neungnyeok · noun |
| [동생](https://en.wiktionary.org/wiki/%EB%8F%99%EC%83%9D#Korean) | younger sibling | dongsaeng · noun |
| [부모](https://en.wiktionary.org/wiki/%EB%B6%80%EB%AA%A8#Korean) | parents | bumo · noun |
| [시설](https://en.wiktionary.org/wiki/%EC%8B%9C%EC%84%A4#Korean) | facilities | siseol · noun |
| [잠](https://en.wiktionary.org/wiki/%EC%9E%A0#Korean) | sleep, nap | jam · noun |
| [저녁](https://en.wiktionary.org/wiki/%EC%A0%80%EB%85%81#Korean) | evening | jeonyeok · noun |
| [축구](https://en.wiktionary.org/wiki/%EC%B6%95%EA%B5%AC#Korean) | football, (US) soccer | chukgu · noun |
| [거기](https://en.wiktionary.org/wiki/%EA%B1%B0%EA%B8%B0#Korean) | there | geogi · pron |
| [공항](https://en.wiktionary.org/wiki/%EA%B3%B5%ED%95%AD#Korean) | airport | gonghang · noun |
| [그림](https://en.wiktionary.org/wiki/%EA%B7%B8%EB%A6%BC#Korean) | picture, drawing, painting, sketch | geurim · noun |
| [맛](https://en.wiktionary.org/wiki/%EB%A7%9B#Korean) | taste, flavor | mat · noun |
| [매일](https://en.wiktionary.org/wiki/%EB%A7%A4%EC%9D%BC#Korean) | every day | maeil · adv |
| [병](https://en.wiktionary.org/wiki/%EB%B3%91#Korean) | bottle; jar | byeong · noun |
| [인사](https://en.wiktionary.org/wiki/%EC%9D%B8%EC%82%AC#Korean) | greeting | insa · noun |
| [차이](https://en.wiktionary.org/wiki/%EC%B0%A8%EC%9D%B4#Korean) | distinction; difference | chai · noun |
| [기능](https://en.wiktionary.org/wiki/%EA%B8%B0%EB%8A%A5#Korean) | function or functionality | gineung · noun |
| [놈](https://en.wiktionary.org/wiki/%EB%86%88#Korean) | kid, boy (from an older perspective) | nom · noun |
| [대전](https://en.wiktionary.org/wiki/%EB%8C%80%EC%A0%84#Korean) | electrification | daejeon · noun |
| [역할](https://en.wiktionary.org/wiki/%EC%97%AD%ED%95%A0#Korean) | a role or part | yeokhal · noun |
| [이전](https://en.wiktionary.org/wiki/%EC%9D%B4%EC%A0%84#Korean) | the time before now; heretofore | ijeon · noun |
| [정](https://en.wiktionary.org/wiki/%EC%A0%95#Korean) | attachment (to a person or an object), a feeling of connection, intimacy, rapport, warm feelings that provoke social reciprocity | jeong · noun |
| [고요](https://en.wiktionary.org/wiki/%EA%B3%A0%EC%9A%94#Korean) | calm, tranquility | goyo · noun |
| [과거](https://en.wiktionary.org/wiki/%EA%B3%BC%EA%B1%B0#Korean) | the past | gwageo · noun |
| [광고](https://en.wiktionary.org/wiki/%EA%B4%91%EA%B3%A0#Korean) | advertisement, advertising in general | gwanggo · noun |
| [그게](https://en.wiktionary.org/wiki/%EA%B7%B8%EA%B2%8C#Korean) | that thing (as the subject of the sentence or clause) | geuge · pron |
| [나이](https://en.wiktionary.org/wiki/%EB%82%98%EC%9D%B4#Korean) | age of a person or other living thing | nai · noun |
| [달리](https://en.wiktionary.org/wiki/%EB%8B%AC%EB%A6%AC#Korean) | differently, unlike | dalli · adv |
| [바람](https://en.wiktionary.org/wiki/%EB%B0%94%EB%9E%8C#Korean) | wind, air, draft | baram · noun |
| [오후](https://en.wiktionary.org/wiki/%EC%98%A4%ED%9B%84#Korean) | p.m. | ohu · noun |

</details>

<details><summary>Words 501–550</summary>

![[Resources/Audio/ko/Words 0501-0550.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [주요](https://en.wiktionary.org/wiki/%EC%A3%BC%EC%9A%94#Korean) | importance, primacy | juyo · noun |
| [지구](https://en.wiktionary.org/wiki/%EC%A7%80%EA%B5%AC#Korean) | district, zone, region | jigu · noun |
| [N](https://en.wiktionary.org/wiki/N#Korean) | an arbitrary or unspecified number of some size, normally greater than three | [e̞n] · num |
| [곧](https://en.wiktionary.org/wiki/%EA%B3%A7#Korean) | soon, at once, immediately, shortly, straightway | got · adv |
| [공간](https://en.wiktionary.org/wiki/%EA%B3%B5%EA%B0%84#Korean) | space, room | gonggan · noun |
| [공부](https://en.wiktionary.org/wiki/%EA%B3%B5%EB%B6%80#Korean) | learning; study | gongbu · noun |
| [관](https://en.wiktionary.org/wiki/%EA%B4%80#Korean) | pipe; tube; duct | gwan · noun |
| [다리](https://en.wiktionary.org/wiki/%EB%8B%A4%EB%A6%AC#Korean) | bridge | dari · noun |
| [버스](https://en.wiktionary.org/wiki/%EB%B2%84%EC%8A%A4#Korean) | bus | beoseu · noun |
| [산업](https://en.wiktionary.org/wiki/%EC%82%B0%EC%97%85#Korean) | industry | saneop · noun |
| [생산](https://en.wiktionary.org/wiki/%EC%83%9D%EC%82%B0#Korean) | production | saengsan · noun |
| [선거](https://en.wiktionary.org/wiki/%EC%84%A0%EA%B1%B0#Korean) | election | seon'geo · noun |
| [스스로](https://en.wiktionary.org/wiki/%EC%8A%A4%EC%8A%A4%EB%A1%9C#Korean) | by oneself, on one's own, without assistance | seuseuro · adv |
| [아빠](https://en.wiktionary.org/wiki/%EC%95%84%EB%B9%A0#Korean) | dad, papa | appa · noun |
| [여행](https://en.wiktionary.org/wiki/%EC%97%AC%ED%96%89#Korean) | travel | yeohaeng · noun |
| [예술](https://en.wiktionary.org/wiki/%EC%98%88%EC%88%A0#Korean) | art; fine art | yesul · noun |
| [요즘](https://en.wiktionary.org/wiki/%EC%9A%94%EC%A6%98#Korean) | recent times; recently | yojeum · noun |
| [현대](https://en.wiktionary.org/wiki/%ED%98%84%EB%8C%80#Korean) | contemporary (times); the modern age | hyeondae · noun |
| [국내](https://en.wiktionary.org/wiki/%EA%B5%AD%EB%82%B4#Korean) | that which is within a country; domestic | gungnae · noun |
| [동시](https://en.wiktionary.org/wiki/%EB%8F%99%EC%8B%9C#Korean) | the same time; concurrently | dongsi · noun |
| [땅](https://en.wiktionary.org/wiki/%EB%95%85#Korean) | earth, land (as opposed to the sea or ocean) | ttang · noun |
| [목적](https://en.wiktionary.org/wiki/%EB%AA%A9%EC%A0%81#Korean) | a goal; an objective | mokjeok · noun |
| [발전](https://en.wiktionary.org/wiki/%EB%B0%9C%EC%A0%84#Korean) | development; growth | baljeon · noun |
| [숨](https://en.wiktionary.org/wiki/%EC%88%A8#Korean) | breath, breathing | sum · noun |
| [옆](https://en.wiktionary.org/wiki/%EC%98%86#Korean) | side, flank, vicinity | yeop · noun |
| [자연](https://en.wiktionary.org/wiki/%EC%9E%90%EC%97%B0#Korean) | nature | jayeon · noun |
| [제일](https://en.wiktionary.org/wiki/%EC%A0%9C%EC%9D%BC#Korean) | most, -est; forms superlatives of adjectives | jeil · adv |
| [죽음](https://en.wiktionary.org/wiki/%EC%A3%BD%EC%9D%8C#Korean) | death, dying | jugeum · noun |
| [가운데](https://en.wiktionary.org/wiki/%EA%B0%80%EC%9A%B4%EB%8D%B0#Korean) | center; the middle | gaunde · noun |
| [그때](https://en.wiktionary.org/wiki/%EA%B7%B8%EB%95%8C#Korean) | that time, the given time | geuttae · noun |
| [기본](https://en.wiktionary.org/wiki/%EA%B8%B0%EB%B3%B8#Korean) | basis, foundation | gibon · noun |
| [나무](https://en.wiktionary.org/wiki/%EB%82%98%EB%AC%B4#Korean) | tree | namu · noun |
| [나중](https://en.wiktionary.org/wiki/%EB%82%98%EC%A4%91#Korean) | the next time; a later time | najung · noun |
| [심](https://en.wiktionary.org/wiki/%EC%8B%AC#Korean) | core of a pencil; lead | sim · noun |
| [업체](https://en.wiktionary.org/wiki/%EC%97%85%EC%B2%B4#Korean) | a firm or company | eopche · noun |
| [자체](https://en.wiktionary.org/wiki/%EC%9E%90%EC%B2%B4#Korean) | the thing itself | jache · noun |
| [작업](https://en.wiktionary.org/wiki/%EC%9E%91%EC%97%85#Korean) | work, working | jageop · noun |
| [즉](https://en.wiktionary.org/wiki/%EC%A6%89#Korean) | that is to say, in other words, i.e. | jeuk · adv |
| [컴퓨터](https://en.wiktionary.org/wiki/%EC%BB%B4%ED%93%A8%ED%84%B0#Korean) | computer | keompyuteo · noun |
| [혹시](https://en.wiktionary.org/wiki/%ED%98%B9%EC%8B%9C#Korean) | by chance | hoksi · adv |
| [효과](https://en.wiktionary.org/wiki/%ED%9A%A8%EA%B3%BC#Korean) | result, effect | hyogwa · noun |
| [미래](https://en.wiktionary.org/wiki/%EB%AF%B8%EB%9E%98#Korean) | the future | mirae · noun |
| [변화](https://en.wiktionary.org/wiki/%EB%B3%80%ED%99%94#Korean) | change; variation | byeonhwa · noun |
| [분석](https://en.wiktionary.org/wiki/%EB%B6%84%EC%84%9D#Korean) | analysis; analyze | bunseok · noun |
| [소개](https://en.wiktionary.org/wiki/%EC%86%8C%EA%B0%9C#Korean) | introduction | sogae · noun |
| [얘](https://en.wiktionary.org/wiki/%EC%96%98#Korean) | this kid; he, she, it, you, this one (who is near the speaker) | yae · pron |
| [얼마](https://en.wiktionary.org/wiki/%EC%96%BC%EB%A7%88#Korean) | how much, how many | eolma · noun |
| [조건](https://en.wiktionary.org/wiki/%EC%A1%B0%EA%B1%B4#Korean) | precondition or preconditions; terms | jogeon · noun |
| [그대로](https://en.wiktionary.org/wiki/%EA%B7%B8%EB%8C%80%EB%A1%9C#Korean) | just, exactly | geudaero · adv |
| [기자](https://en.wiktionary.org/wiki/%EA%B8%B0%EC%9E%90#Korean) | reporter, journalist, newsman, correspondent | gija · noun |

</details>

<details><summary>Words 551–600</summary>

![[Resources/Audio/ko/Words 0551-0600.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [남성](https://en.wiktionary.org/wiki/%EB%82%A8%EC%84%B1#Korean) | male, men | namseong · noun |
| [대구](https://en.wiktionary.org/wiki/%EB%8C%80%EA%B5%AC#Korean) | A cod or haddock, especially the Pacific cod. | daegu · noun |
| [여름](https://en.wiktionary.org/wiki/%EC%97%AC%EB%A6%84#Korean) | summer | yeoreum · noun |
| [일단](https://en.wiktionary.org/wiki/%EC%9D%BC%EB%8B%A8#Korean) | first and foremost | ildan · adv |
| [책임](https://en.wiktionary.org/wiki/%EC%B1%85%EC%9E%84#Korean) | responsibility, duty | chaegim · noun |
| [형태](https://en.wiktionary.org/wiki/%ED%98%95%ED%83%9C#Korean) | shape | hyeongtae · noun |
| [건물](https://en.wiktionary.org/wiki/%EA%B1%B4%EB%AC%BC#Korean) | building, construction, edifice | geonmul · noun |
| [무대](https://en.wiktionary.org/wiki/%EB%AC%B4%EB%8C%80#Korean) | a performance stage | mudae · noun |
| [시민](https://en.wiktionary.org/wiki/%EC%8B%9C%EB%AF%BC#Korean) | citizens, citizenry | simin · noun |
| [시험](https://en.wiktionary.org/wiki/%EC%8B%9C%ED%97%98#Korean) | test, exam | siheom · noun |
| [우](https://en.wiktionary.org/wiki/%EC%9A%B0#Korean) | right side | u · noun |
| [이곳](https://en.wiktionary.org/wiki/%EC%9D%B4%EA%B3%B3#Korean) | here | igot · pron |
| [전문](https://en.wiktionary.org/wiki/%EC%A0%84%EB%AC%B8#Korean) | expertise; speciality; one's field of specialization | jeonmun · noun |
| [현실](https://en.wiktionary.org/wiki/%ED%98%84%EC%8B%A4#Korean) | reality; the actual case | hyeonsil · noun |
| [공동](https://en.wiktionary.org/wiki/%EA%B3%B5%EB%8F%99#Korean) | commonality, sharedness (of assets or actions) | gongdong · noun |
| [규모](https://en.wiktionary.org/wiki/%EA%B7%9C%EB%AA%A8#Korean) | scale or dimensions | gyumo · noun |
| [꽃](https://en.wiktionary.org/wiki/%EA%BD%83#Korean) | flower; flowering plant | kkot · noun |
| [단지](https://en.wiktionary.org/wiki/%EB%8B%A8%EC%A7%80#Korean) | just, only; simply | danji · adv |
| [목](https://en.wiktionary.org/wiki/%EB%AA%A9#Korean) | neck | mok · noun |
| [뭘](https://en.wiktionary.org/wiki/%EB%AD%98#Korean) | what (interrogative direct object pronoun, mostly in spoken Korean) | mwol · pron |
| [방향](https://en.wiktionary.org/wiki/%EB%B0%A9%ED%96%A5#Korean) | direction, orientation | banghyang · noun |
| [언니](https://en.wiktionary.org/wiki/%EC%96%B8%EB%8B%88#Korean) | older sister of a female | eonni · noun |
| [요구](https://en.wiktionary.org/wiki/%EC%9A%94%EA%B5%AC#Korean) | requirement, demand | yogu · noun |
| [유](https://en.wiktionary.org/wiki/%EC%9C%A0#Korean) | existence, being (especially in contrast to the concept of nothingness or non-existence) | yu · noun |
| [음식](https://en.wiktionary.org/wiki/%EC%9D%8C%EC%8B%9D#Korean) | food, including drink | eumsik · noun |
| [현장](https://en.wiktionary.org/wiki/%ED%98%84%EC%9E%A5#Korean) | site, location, place (of an event) | hyeonjang · noun |
| [회장](https://en.wiktionary.org/wiki/%ED%9A%8C%EC%9E%A5#Korean) | the chairman or chairperson of a board, or the president of some organizations | hoejang · noun |
| [고려](https://en.wiktionary.org/wiki/%EA%B3%A0%EB%A0%A4#Korean) | consideration; reflection | goryeo · noun |
| [따라서](https://en.wiktionary.org/wiki/%EB%94%B0%EB%9D%BC%EC%84%9C#Korean) | therefore; in accordance with | ttaraseo · adv |
| [마치](https://en.wiktionary.org/wiki/%EB%A7%88%EC%B9%98#Korean) | exactly the same, as if, just like | machi · adv |
| [바다](https://en.wiktionary.org/wiki/%EB%B0%94%EB%8B%A4#Korean) | sea, ocean | bada · noun |
| [빛](https://en.wiktionary.org/wiki/%EB%B9%9B#Korean) | light, gleam, glow | bit · noun |
| [자주](https://en.wiktionary.org/wiki/%EC%9E%90%EC%A3%BC#Korean) | often, frequently | jaju · adv |
| [조선](https://en.wiktionary.org/wiki/%EC%A1%B0%EC%84%A0#Korean) | shipbuilding | joseon · noun |
| [하늘](https://en.wiktionary.org/wiki/%ED%95%98%EB%8A%98#Korean) | sky | haneul · noun |
| [한편](https://en.wiktionary.org/wiki/%ED%95%9C%ED%8E%B8#Korean) | on the other hand, while | hanpyeon · adv |
| [행위](https://en.wiktionary.org/wiki/%ED%96%89%EC%9C%84#Korean) | an act or behavior | haeng'wi · noun |
| [회의](https://en.wiktionary.org/wiki/%ED%9A%8C%EC%9D%98#Korean) | a meeting | hoe'ui · noun |
| [가슴](https://en.wiktionary.org/wiki/%EA%B0%80%EC%8A%B4#Korean) | chest, breast | gaseum · noun |
| [건강](https://en.wiktionary.org/wiki/%EA%B1%B4%EA%B0%95#Korean) | health | geon'gang · noun |
| [도착](https://en.wiktionary.org/wiki/%EB%8F%84%EC%B0%A9#Korean) | arrival | dochak · noun |
| [인기](https://en.wiktionary.org/wiki/%EC%9D%B8%EA%B8%B0#Korean) | popularity | in'gi · noun |
| [자동차](https://en.wiktionary.org/wiki/%EC%9E%90%EB%8F%99%EC%B0%A8#Korean) | automobile, car | jadongcha · noun |
| [전혀](https://en.wiktionary.org/wiki/%EC%A0%84%ED%98%80#Korean) | at all, absolutely, completely | jeonhyeo · adv |
| [환경](https://en.wiktionary.org/wiki/%ED%99%98%EA%B2%BD#Korean) | environment, as a general concept | hwan'gyeong · noun |
| [각각](https://en.wiktionary.org/wiki/%EA%B0%81%EA%B0%81#Korean) | each, every, respective | gakgak · adv |
| [모](https://en.wiktionary.org/wiki/%EB%AA%A8#Korean) | protrusion | mo · noun |
| [모양](https://en.wiktionary.org/wiki/%EB%AA%A8%EC%96%91#Korean) | surface appearance | moyang · noun |
| [목소리](https://en.wiktionary.org/wiki/%EB%AA%A9%EC%86%8C%EB%A6%AC#Korean) | voice | moksori · noun |
| [북](https://en.wiktionary.org/wiki/%EB%B6%81#Korean) | a generic term meaning drum | buk · noun |

</details>

<details><summary>Words 601–650</summary>

![[Resources/Audio/ko/Words 0601-0650.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [시절](https://en.wiktionary.org/wiki/%EC%8B%9C%EC%A0%88#Korean) | a period of time | sijeol · noun |
| [영](https://en.wiktionary.org/wiki/%EC%98%81#Korean) | zero | yeong · num |
| [혹은](https://en.wiktionary.org/wiki/%ED%98%B9%EC%9D%80#Korean) | or (if not); or else | hogeun · adv |
| [가치](https://en.wiktionary.org/wiki/%EA%B0%80%EC%B9%98#Korean) | value | gachi · noun |
| [동](https://en.wiktionary.org/wiki/%EB%8F%99#Korean) | dong (submunicipal administrative unit) | dong · noun |
| [밥](https://en.wiktionary.org/wiki/%EB%B0%A5#Korean) | cooked rice | bap · noun |
| [시기](https://en.wiktionary.org/wiki/%EC%8B%9C%EA%B8%B0#Korean) | opportunity; chance; a time, especially a time for doing something | sigi · noun |
| [신경](https://en.wiktionary.org/wiki/%EC%8B%A0%EA%B2%BD#Korean) | nerves | sin'gyeong · noun |
| [야구](https://en.wiktionary.org/wiki/%EC%95%BC%EA%B5%AC#Korean) | baseball (ball game) | yagu · noun |
| [약간](https://en.wiktionary.org/wiki/%EC%95%BD%EA%B0%84#Korean) | smallness, triviality (usually in the form of 약간의) | yakgan · noun |
| [약속](https://en.wiktionary.org/wiki/%EC%95%BD%EC%86%8D#Korean) | promise | yaksok · noun |
| [장관](https://en.wiktionary.org/wiki/%EC%9E%A5%EA%B4%80#Korean) | a minister, a member of Cabinet | janggwan · noun |
| [중앙](https://en.wiktionary.org/wiki/%EC%A4%91%EC%95%99#Korean) | center, middle | jung'ang · noun |
| [최근](https://en.wiktionary.org/wiki/%EC%B5%9C%EA%B7%BC#Korean) | the latest, the most recent | choegeun · noun |
| [커피](https://en.wiktionary.org/wiki/%EC%BB%A4%ED%94%BC#Korean) | coffee, especially the beverage | keopi · noun |
| [행사](https://en.wiktionary.org/wiki/%ED%96%89%EC%82%AC#Korean) | an event or observance. | haengsa · noun |
| [감정](https://en.wiktionary.org/wiki/%EA%B0%90%EC%A0%95#Korean) | emotion, feeling | gamjeong · noun |
| [건설](https://en.wiktionary.org/wiki/%EA%B1%B4%EC%84%A4#Korean) | construction | geonseol · noun |
| [듯이](https://en.wiktionary.org/wiki/%EB%93%AF%EC%9D%B4#Korean) | as if; in a manner suggesting that | deusi · noun |
| [색](https://en.wiktionary.org/wiki/%EC%83%89#Korean) | colour (UK), color (US) | saek · noun |
| [설](https://en.wiktionary.org/wiki/%EC%84%A4#Korean) | Korean New Year | seol · noun |
| [설정](https://en.wiktionary.org/wiki/%EC%84%A4%EC%A0%95#Korean) | creation; setup; establishment; fixing | seoljeong · noun |
| [아내](https://en.wiktionary.org/wiki/%EC%95%84%EB%82%B4#Korean) | wife, especially one's own | anae · noun |
| [이미지](https://en.wiktionary.org/wiki/%EC%9D%B4%EB%AF%B8%EC%A7%80#Korean) | public image | imiji · noun |
| [터](https://en.wiktionary.org/wiki/%ED%84%B0#Korean) | place, room, space | teo · noun |
| [희망](https://en.wiktionary.org/wiki/%ED%9D%AC%EB%A7%9D#Korean) | hope, wish | huimang · noun |
| [단계](https://en.wiktionary.org/wiki/%EB%8B%A8%EA%B3%84#Korean) | stage of progress | dan'gye · noun |
| [벌써](https://en.wiktionary.org/wiki/%EB%B2%8C%EC%8D%A8#Korean) | already | beolsseo · adv |
| [오빠](https://en.wiktionary.org/wiki/%EC%98%A4%EB%B9%A0#Korean) | elder brother of a female | oppa · noun |
| [가수](https://en.wiktionary.org/wiki/%EA%B0%80%EC%88%98#Korean) | a singer, usually professional | gasu · noun |
| [갑자기](https://en.wiktionary.org/wiki/%EA%B0%91%EC%9E%90%EA%B8%B0#Korean) | suddenly, all of a sudden | gapjagi · adv |
| [마찬가지](https://en.wiktionary.org/wiki/%EB%A7%88%EC%B0%AC%EA%B0%80%EC%A7%80#Korean) | being exactly the same; identical | machan'gaji · noun |
| [보통](https://en.wiktionary.org/wiki/%EB%B3%B4%ED%86%B5#Korean) | averageness, normality, usuality, generality, commonness, ordinariness, regularness | botong · noun |
| [삼성](https://en.wiktionary.org/wiki/%EC%82%BC%EC%84%B1#Korean) | To introspect three times daily. | samseong · noun |
| [어제](https://en.wiktionary.org/wiki/%EC%96%B4%EC%A0%9C#Korean) | yesterday | eoje · noun |
| [은행](https://en.wiktionary.org/wiki/%EC%9D%80%ED%96%89#Korean) | a bank (financial institution) | eunhaeng · noun |
| [잠시](https://en.wiktionary.org/wiki/%EC%9E%A0%EC%8B%9C#Korean) | a moment, short time | jamsi · noun |
| [전자](https://en.wiktionary.org/wiki/%EC%A0%84%EC%9E%90#Korean) | electron | jeonja · noun |
| [카메라](https://en.wiktionary.org/wiki/%EC%B9%B4%EB%A9%94%EB%9D%BC#Korean) | camera (a device for taking still or moving pictures) | kamera · noun |
| [칼](https://en.wiktionary.org/wiki/%EC%B9%BC#Korean) | knife, sword | kal · noun |
| [평화](https://en.wiktionary.org/wiki/%ED%8F%89%ED%99%94#Korean) | peace | pyeonghwa · noun |
| [포](https://en.wiktionary.org/wiki/%ED%8F%AC#Korean) | gun; cannon | po · noun |
| [학년](https://en.wiktionary.org/wiki/%ED%95%99%EB%85%84#Korean) | school year | hangnyeon · noun |
| [만약](https://en.wiktionary.org/wiki/%EB%A7%8C%EC%95%BD#Korean) | if, in the event that. | manyak · adv |
| [메](https://en.wiktionary.org/wiki/%EB%A9%94#Korean) | bindweed | me · noun |
| [벌](https://en.wiktionary.org/wiki/%EB%B2%8C#Korean) | any kind of bee, wasp, or hornet | beol · noun |
| [생명](https://en.wiktionary.org/wiki/%EC%83%9D%EB%AA%85#Korean) | life | saengmyeong · noun |
| [수준](https://en.wiktionary.org/wiki/%EC%88%98%EC%A4%80#Korean) | a standard or criterion level | sujun · noun |
| [시리즈](https://en.wiktionary.org/wiki/%EC%8B%9C%EB%A6%AC%EC%A6%88#Korean) | a series, especially in sports or entertainment | sirijeu · noun |
| [실패](https://en.wiktionary.org/wiki/%EC%8B%A4%ED%8C%A8#Korean) | failure | silpae · noun |

</details>

<details><summary>Words 651–700</summary>

![[Resources/Audio/ko/Words 0651-0700.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [피해](https://en.wiktionary.org/wiki/%ED%94%BC%ED%95%B4#Korean) | harm; damage | pihae · noun |
| [가끔](https://en.wiktionary.org/wiki/%EA%B0%80%EB%81%94#Korean) | occasionally, from time to time, not frequently or regularly | gakkeum · adv |
| [방금](https://en.wiktionary.org/wiki/%EB%B0%A9%EA%B8%88#Korean) | just a moment ago; just now | banggeum · adv |
| [분야](https://en.wiktionary.org/wiki/%EB%B6%84%EC%95%BC#Korean) | sector; field of business or study | bunya · noun |
| [여전히](https://en.wiktionary.org/wiki/%EC%97%AC%EC%A0%84%ED%9E%88#Korean) | still, just as before | yeojeonhi · adv |
| [완전히](https://en.wiktionary.org/wiki/%EC%99%84%EC%A0%84%ED%9E%88#Korean) | completely, totally | wanjeonhi · adv |
| [요리](https://en.wiktionary.org/wiki/%EC%9A%94%EB%A6%AC#Korean) | cooking; cuisine. | yori · noun |
| [울](https://en.wiktionary.org/wiki/%EC%9A%B8#Korean) | wall, fence | ul · noun |
| [전통](https://en.wiktionary.org/wiki/%EC%A0%84%ED%86%B5#Korean) | full connection (Describes the condition in which roads, tracks, or similar constructions—whether provisional or subsidiary—are completely continuous, ensuring an uninterrupted passage from one end to the other.) | jeontong · noun |
| [제품](https://en.wiktionary.org/wiki/%EC%A0%9C%ED%92%88#Korean) | product, manufacture | jepum · noun |
| [종류](https://en.wiktionary.org/wiki/%EC%A2%85%EB%A5%98#Korean) | type, kind, category | jongnyu · noun |
| [주민](https://en.wiktionary.org/wiki/%EC%A3%BC%EB%AF%BC#Korean) | residents in a place | jumin · noun |
| [주제](https://en.wiktionary.org/wiki/%EC%A3%BC%EC%A0%9C#Korean) | topic; main idea | juje · noun |
| [통신](https://en.wiktionary.org/wiki/%ED%86%B5%EC%8B%A0#Korean) | communication; the sending of information | tongsin · noun |
| [국](https://en.wiktionary.org/wiki/%EA%B5%AD#Korean) | soup | guk · noun |
| [그만](https://en.wiktionary.org/wiki/%EA%B7%B8%EB%A7%8C#Korean) | this much only; no more. often used in imperatives. | geuman · adv |
| [사과](https://en.wiktionary.org/wiki/%EC%82%AC%EA%B3%BC#Korean) | apple | sagwa · noun |
| [소식](https://en.wiktionary.org/wiki/%EC%86%8C%EC%8B%9D#Korean) | news | sosik · noun |
| [속도](https://en.wiktionary.org/wiki/%EC%86%8D%EB%8F%84#Korean) | speed | sokdo · noun |
| [자세](https://en.wiktionary.org/wiki/%EC%9E%90%EC%84%B8#Korean) | posture; carriage | jase · noun |
| [차례](https://en.wiktionary.org/wiki/%EC%B0%A8%EB%A1%80#Korean) | order; sequence | charye · noun |
| [거래](https://en.wiktionary.org/wiki/%EA%B1%B0%EB%9E%98#Korean) | transaction; trade | georae · noun |
| [경](https://en.wiktionary.org/wiki/%EA%B2%BD#Korean) | In the Joseon Dynasty (14th-19th centuries), the term used by the king to refer to any official above the second rank. | gyeong · pron |
| [경험](https://en.wiktionary.org/wiki/%EA%B2%BD%ED%97%98#Korean) | experience | gyeongheom · noun |
| [고통](https://en.wiktionary.org/wiki/%EA%B3%A0%ED%86%B5#Korean) | pain | gotong · noun |
| [국회](https://en.wiktionary.org/wiki/%EA%B5%AD%ED%9A%8C#Korean) | A national parliament or assembly. | gukhoe · noun |
| [기계](https://en.wiktionary.org/wiki/%EA%B8%B0%EA%B3%84#Korean) | machine; machinery | gigye · noun |
| [단어](https://en.wiktionary.org/wiki/%EB%8B%A8%EC%96%B4#Korean) | an individual word | daneo · noun |
| [문자](https://en.wiktionary.org/wiki/%EB%AC%B8%EC%9E%90#Korean) | letter, character, alphabet | munja · noun |
| [성장](https://en.wiktionary.org/wiki/%EC%84%B1%EC%9E%A5#Korean) | growth, expansion | seongjang · noun |
| [소녀](https://en.wiktionary.org/wiki/%EC%86%8C%EB%85%80#Korean) | girl (young female person) | sonyeo · noun |
| [언제나](https://en.wiktionary.org/wiki/%EC%96%B8%EC%A0%9C%EB%82%98#Korean) | always | eonjena · adv |
| [쥐](https://en.wiktionary.org/wiki/%EC%A5%90#Korean) | rat, mouse, (in general) rodent | jwi · noun |
| [특징](https://en.wiktionary.org/wiki/%ED%8A%B9%EC%A7%95#Korean) | distinguishing characteristic | teukjing · noun |
| [훈련](https://en.wiktionary.org/wiki/%ED%9B%88%EB%A0%A8#Korean) | training, drill, discipline | hullyeon · noun |
| [매](https://en.wiktionary.org/wiki/%EB%A7%A4#Korean) | hawk | mae · noun |
| [분위기](https://en.wiktionary.org/wiki/%EB%B6%84%EC%9C%84%EA%B8%B0#Korean) | intellectual atmosphere or environment | bunwigi · noun |
| [아기](https://en.wiktionary.org/wiki/%EC%95%84%EA%B8%B0#Korean) | unweaned baby, child | agi · noun |
| [가득](https://en.wiktionary.org/wiki/%EA%B0%80%EB%93%9D#Korean) | full; fully | gadeuk · adv |
| [남편](https://en.wiktionary.org/wiki/%EB%82%A8%ED%8E%B8#Korean) | husband | nampyeon · noun |
| [내부](https://en.wiktionary.org/wiki/%EB%82%B4%EB%B6%80#Korean) | The interior or inside. | naebu · noun |
| [목표](https://en.wiktionary.org/wiki/%EB%AA%A9%ED%91%9C#Korean) | goal, target, objective, aim, bullseye, eyemark | mokpyo · noun |
| [별로](https://en.wiktionary.org/wiki/%EB%B3%84%EB%A1%9C#Korean) | very (in a negative context) | byeollo · adv |
| [섬](https://en.wiktionary.org/wiki/%EC%84%AC#Korean) | island, islet or insular | seom · noun |
| [성격](https://en.wiktionary.org/wiki/%EC%84%B1%EA%B2%A9#Korean) | character, temperament | seonggyeok · noun |
| [소설](https://en.wiktionary.org/wiki/%EC%86%8C%EC%84%A4#Korean) | fictional literature; fictional story | soseol · noun |
| [아마](https://en.wiktionary.org/wiki/%EC%95%84%EB%A7%88#Korean) | perhaps, maybe | ama · adv |
| [언어](https://en.wiktionary.org/wiki/%EC%96%B8%EC%96%B4#Korean) | language | eoneo · noun |
| [의식](https://en.wiktionary.org/wiki/%EC%9D%98%EC%8B%9D#Korean) | consciousness; awareness | uisik · noun |
| [주로](https://en.wiktionary.org/wiki/%EC%A3%BC%EB%A1%9C#Korean) | chiefly, principally | juro · adv |

</details>

<details><summary>Words 701–750</summary>

![[Resources/Audio/ko/Words 0701-0750.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [주인](https://en.wiktionary.org/wiki/%EC%A3%BC%EC%9D%B8#Korean) | master or owner | ju'in · noun |
| [출신](https://en.wiktionary.org/wiki/%EC%B6%9C%EC%8B%A0#Korean) | a native; someone native-born to a place | chulsin · noun |
| [폰](https://en.wiktionary.org/wiki/%ED%8F%B0#Korean) | a phone, most commonly a cell phone | pon · noun |
| [낫](https://en.wiktionary.org/wiki/%EB%82%AB#Korean) | sickle, scythe | nat · noun |
| [뉴](https://en.wiktionary.org/wiki/%EB%89%B4#Korean) | the state of being new | nyu · det |
| [물질](https://en.wiktionary.org/wiki/%EB%AC%BC%EC%A7%88#Korean) | a substance; a material | muljil · noun |
| [사장](https://en.wiktionary.org/wiki/%EC%82%AC%EC%9E%A5#Korean) | CEO or director of a company | sajang · noun |
| [수사](https://en.wiktionary.org/wiki/%EC%88%98%EC%82%AC#Korean) | number; numeral | susa · noun |
| [수업](https://en.wiktionary.org/wiki/%EC%88%98%EC%97%85#Korean) | a class | sueop · noun |
| [시청](https://en.wiktionary.org/wiki/%EC%8B%9C%EC%B2%AD#Korean) | city hall | sicheong · noun |
| [신문](https://en.wiktionary.org/wiki/%EC%8B%A0%EB%AC%B8#Korean) | newspaper | sinmun · noun |
| [암](https://en.wiktionary.org/wiki/%EC%95%94#Korean) | cancer (illness) | am · noun |
| [인도](https://en.wiktionary.org/wiki/%EC%9D%B8%EB%8F%84#Korean) | sidewalk, pavement, walkway | indo · noun |
| [인물](https://en.wiktionary.org/wiki/%EC%9D%B8%EB%AC%BC#Korean) | the physical figure of a person | inmul · noun |
| [크기](https://en.wiktionary.org/wiki/%ED%81%AC%EA%B8%B0#Korean) | size | keugi · noun |
| [규정](https://en.wiktionary.org/wiki/%EA%B7%9C%EC%A0%95#Korean) | a provision or rule | gyujeong · noun |
| [너희](https://en.wiktionary.org/wiki/%EB%84%88%ED%9D%AC#Korean) | you; you guys; you all | neohui · pron |
| [봄](https://en.wiktionary.org/wiki/%EB%B4%84#Korean) | spring, springtime | bom · noun |
| [언론](https://en.wiktionary.org/wiki/%EC%96%B8%EB%A1%A0#Korean) | speech, public discourse | eollon · noun |
| [운](https://en.wiktionary.org/wiki/%EC%9A%B4#Korean) | luck, fortune, fate | un · noun |
| [금](https://en.wiktionary.org/wiki/%EA%B8%88#Korean) | gold (Au) (in general and as an element); golden... | geum · noun |
| [셋](https://en.wiktionary.org/wiki/%EC%85%8B#Korean) | three (independently, without a classifier) | set · num |
| [열심히](https://en.wiktionary.org/wiki/%EC%97%B4%EC%8B%AC%ED%9E%88#Korean) | enthusiastically, fervently, with dedication | yeolsimhi · adv |
| [올해](https://en.wiktionary.org/wiki/%EC%98%AC%ED%95%B4#Korean) | the current year, this year | olhae · noun |
| [겨울](https://en.wiktionary.org/wiki/%EA%B2%A8%EC%9A%B8#Korean) | winter | gyeoul · noun |
| [고양이](https://en.wiktionary.org/wiki/%EA%B3%A0%EC%96%91%EC%9D%B4#Korean) | cat | goyang'i · noun |
| [군대](https://en.wiktionary.org/wiki/%EA%B5%B0%EB%8C%80#Korean) | army | gundae · noun |
| [꽤](https://en.wiktionary.org/wiki/%EA%BD%A4#Korean) | To a more than ordinary degree; rather, fairly. | kkwae · adv |
| [널](https://en.wiktionary.org/wiki/%EB%84%90#Korean) | panel, board, plank | neol · noun |
| [밑](https://en.wiktionary.org/wiki/%EB%B0%91#Korean) | bottom, underneath; the lower/bottom part (of an object) | mit · noun |
| [블로그](https://en.wiktionary.org/wiki/%EB%B8%94%EB%A1%9C%EA%B7%B8#Korean) | blog | beullogeu · noun |
| [석](https://en.wiktionary.org/wiki/%EC%84%9D#Korean) | three (before certain classifiers) | seok · num |
| [숲](https://en.wiktionary.org/wiki/%EC%88%B2#Korean) | a forest or grove | sup · noun |
| [실제로](https://en.wiktionary.org/wiki/%EC%8B%A4%EC%A0%9C%EB%A1%9C#Korean) | in fact, in practice | siljero · adv |
| [어린이](https://en.wiktionary.org/wiki/%EC%96%B4%EB%A6%B0%EC%9D%B4#Korean) | child | eorini · noun |
| [위원](https://en.wiktionary.org/wiki/%EC%9C%84%EC%9B%90#Korean) | member of a committee | wiwon · noun |
| [잔](https://en.wiktionary.org/wiki/%EC%9E%94#Korean) | a drinking cup | jan · noun |
| [카페](https://en.wiktionary.org/wiki/%EC%B9%B4%ED%8E%98#Korean) | coffee shop, café | kape · noun |
| [가정](https://en.wiktionary.org/wiki/%EA%B0%80%EC%A0%95#Korean) | a household, a family | gajeong · noun |
| [부정](https://en.wiktionary.org/wiki/%EB%B6%80%EC%A0%95#Korean) | negation | bujeong · noun |
| [업무](https://en.wiktionary.org/wiki/%EC%97%85%EB%AC%B4#Korean) | business, work, task, duty, business operations, service | eommu · noun |
| [엔진](https://en.wiktionary.org/wiki/%EC%97%94%EC%A7%84#Korean) | engine | enjin · noun |
| [원인](https://en.wiktionary.org/wiki/%EC%9B%90%EC%9D%B8#Korean) | cause | wonin · noun |
| [종교](https://en.wiktionary.org/wiki/%EC%A2%85%EA%B5%90#Korean) | religion | jonggyo · noun |
| [태양](https://en.wiktionary.org/wiki/%ED%83%9C%EC%96%91#Korean) | sun; the Sun | taeyang · noun |
| [값](https://en.wiktionary.org/wiki/%EA%B0%92#Korean) | price | gap · noun |
| [공장](https://en.wiktionary.org/wiki/%EA%B3%B5%EC%9E%A5#Korean) | factory | gongjang · noun |
| [귀](https://en.wiktionary.org/wiki/%EA%B7%80#Korean) | ear, auricle | gwi · noun |
| [소년](https://en.wiktionary.org/wiki/%EC%86%8C%EB%85%84#Korean) | boy (older than 6 years old and so on) | sonyeon · noun |
| [식사](https://en.wiktionary.org/wiki/%EC%8B%9D%EC%82%AC#Korean) | meal | siksa · noun |

</details>

<details><summary>Words 751–800</summary>

![[Resources/Audio/ko/Words 0751-0800.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [훨씬](https://en.wiktionary.org/wiki/%ED%9B%A8%EC%94%AC#Korean) | much more or less (than normal); a lot; long (before or after); far more | hwolssin · adv |
| [근처](https://en.wiktionary.org/wiki/%EA%B7%BC%EC%B2%98#Korean) | neighborhood; vicinity; the nearby area | geuncheo · noun |
| [냄새](https://en.wiktionary.org/wiki/%EB%83%84%EC%83%88#Korean) | a smell, whether fragrant or offensive; odour; scent | naemsae · noun |
| [번역](https://en.wiktionary.org/wiki/%EB%B2%88%EC%97%AD#Korean) | translation | beonyeok · noun |
| [새로](https://en.wiktionary.org/wiki/%EC%83%88%EB%A1%9C#Korean) | anew, newly, for the first time | saero · adv |
| [유리](https://en.wiktionary.org/wiki/%EC%9C%A0%EB%A6%AC#Korean) | glass (substance) | yuri · noun |
| [주말](https://en.wiktionary.org/wiki/%EC%A3%BC%EB%A7%90#Korean) | weekend | jumal · noun |
| [창](https://en.wiktionary.org/wiki/%EC%B0%BD#Korean) | window | chang · noun |
| [다만](https://en.wiktionary.org/wiki/%EB%8B%A4%EB%A7%8C#Korean) | however, nonetheless | daman · adv |
| [더욱](https://en.wiktionary.org/wiki/%EB%8D%94%EC%9A%B1#Korean) | more so, even more | deouk · adv |
| [밀](https://en.wiktionary.org/wiki/%EB%B0%80#Korean) | wheat | mil · noun |
| [부문](https://en.wiktionary.org/wiki/%EB%B6%80%EB%AC%B8#Korean) | a category or classification | bumun · noun |
| [세대](https://en.wiktionary.org/wiki/%EC%84%B8%EB%8C%80#Korean) | age, generation, era | sedae · noun |
| [점점](https://en.wiktionary.org/wiki/%EC%A0%90%EC%A0%90#Korean) | gradually, bit by bit | jeomjeom · noun |
| [현상](https://en.wiktionary.org/wiki/%ED%98%84%EC%83%81#Korean) | the evident condition or state | hyeonsang · noun |
| [불편](https://en.wiktionary.org/wiki/%EB%B6%88%ED%8E%B8#Korean) | inconvenience | bulpyeon · noun |
| [세기](https://en.wiktionary.org/wiki/%EC%84%B8%EA%B8%B0#Korean) | century (100 years) | segi · noun |
| [아파트](https://en.wiktionary.org/wiki/%EC%95%84%ED%8C%8C%ED%8A%B8#Korean) | apartment building, block of flats | apateu · noun |
| [연습](https://en.wiktionary.org/wiki/%EC%97%B0%EC%8A%B5#Korean) | practice, exercise | yeonseup · noun |
| [외국인](https://en.wiktionary.org/wiki/%EC%99%B8%EA%B5%AD%EC%9D%B8#Korean) | foreigner | oegugin · noun |
| [제목](https://en.wiktionary.org/wiki/%EC%A0%9C%EB%AA%A9#Korean) | A title of a book or other work. | jemok · noun |
| [청소년](https://en.wiktionary.org/wiki/%EC%B2%AD%EC%86%8C%EB%85%84#Korean) | adolescent; teenager | cheongsonyeon · noun |
| [초기](https://en.wiktionary.org/wiki/%EC%B4%88%EA%B8%B0#Korean) | the initial period; the beginning | chogi · noun |
| [대중](https://en.wiktionary.org/wiki/%EB%8C%80%EC%A4%91#Korean) | crowd; party | daejung · noun |
| [민족](https://en.wiktionary.org/wiki/%EB%AF%BC%EC%A1%B1#Korean) | people; nation; ethnicity; race; tribe | minjok · noun |
| [실수](https://en.wiktionary.org/wiki/%EC%8B%A4%EC%88%98#Korean) | mistake | silsu · noun |
| [저장](https://en.wiktionary.org/wiki/%EC%A0%80%EC%9E%A5#Korean) | preservation; storing | jeojang · noun |
| [지식](https://en.wiktionary.org/wiki/%EC%A7%80%EC%8B%9D#Korean) | knowledge | jisik · noun |
| [거짓말](https://en.wiktionary.org/wiki/%EA%B1%B0%EC%A7%93%EB%A7%90#Korean) | a lie; a false statement | geojinmal · noun |
| [골](https://en.wiktionary.org/wiki/%EA%B3%A8#Korean) | gorge; gully; valley; alley | gol · noun |
| [바탕](https://en.wiktionary.org/wiki/%EB%B0%94%ED%83%95#Korean) | base, foundation | batang · noun |
| [셈](https://en.wiktionary.org/wiki/%EC%85%88#Korean) | counting | sem · noun |
| [직업](https://en.wiktionary.org/wiki/%EC%A7%81%EC%97%85#Korean) | job, work, occupation, career, vocation, profession, trade | jigeop · noun |
| [충분히](https://en.wiktionary.org/wiki/%EC%B6%A9%EB%B6%84%ED%9E%88#Korean) | sufficiently | chungbunhi · adv |
| [판단](https://en.wiktionary.org/wiki/%ED%8C%90%EB%8B%A8#Korean) | Judgment; decision | pandan · noun |
| [경영](https://en.wiktionary.org/wiki/%EA%B2%BD%EC%98%81#Korean) | management; administration | gyeong'yeong · noun |
| [교사](https://en.wiktionary.org/wiki/%EA%B5%90%EC%82%AC#Korean) | a teacher, the profession, especially in a primary or secondary school, of being a teacher (not used to address an individual directly) | gyosa · noun |
| [동료](https://en.wiktionary.org/wiki/%EB%8F%99%EB%A3%8C#Korean) | associate, colleague, coworker, comrade, brother | dongnyo · noun |
| [무리](https://en.wiktionary.org/wiki/%EB%AC%B4%EB%A6%AC#Korean) | group, crowd, gang, horde | muri · noun |
| [문서](https://en.wiktionary.org/wiki/%EB%AC%B8%EC%84%9C#Korean) | document | munseo · noun |
| [벽](https://en.wiktionary.org/wiki/%EB%B2%BD#Korean) | wall | byeok · noun |
| [비디오](https://en.wiktionary.org/wiki/%EB%B9%84%EB%94%94%EC%98%A4#Korean) | video | bidio · noun |
| [상품](https://en.wiktionary.org/wiki/%EC%83%81%ED%92%88#Korean) | merchandise, commodity; good(s) | sangpum · noun |
| [아저씨](https://en.wiktionary.org/wiki/%EC%95%84%EC%A0%80%EC%94%A8#Korean) | middle-aged elder male | ajeossi · noun |
| [연](https://en.wiktionary.org/wiki/%EC%97%B0#Korean) | year | yeon · noun |
| [왼쪽](https://en.wiktionary.org/wiki/%EC%99%BC%EC%AA%BD#Korean) | left side | oenjjok · noun |
| [의학](https://en.wiktionary.org/wiki/%EC%9D%98%ED%95%99#Korean) | medicine (the academic discipline) | uihak · noun |
| [장기](https://en.wiktionary.org/wiki/%EC%9E%A5%EA%B8%B0#Korean) | janggi (Korean chess) | janggi · noun |
| [집단](https://en.wiktionary.org/wiki/%EC%A7%91%EB%8B%A8#Korean) | a group of people; body | jipdan · noun |
| [충격](https://en.wiktionary.org/wiki/%EC%B6%A9%EA%B2%A9#Korean) | A blow or impact, especially from an object or event. | chunggyeok · noun |

</details>

<details><summary>Words 801–850</summary>

![[Resources/Audio/ko/Words 0801-0850.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [칠](https://en.wiktionary.org/wiki/%EC%B9%A0#Korean) | seven | chil · num |
| [통일](https://en.wiktionary.org/wiki/%ED%86%B5%EC%9D%BC#Korean) | unification or reunification | tong'il · noun |
| [그저](https://en.wiktionary.org/wiki/%EA%B7%B8%EC%A0%80#Korean) | just (only) | geujeo · adv |
| [다섯](https://en.wiktionary.org/wiki/%EB%8B%A4%EC%84%AF#Korean) | five | daseot · num |
| [생일](https://en.wiktionary.org/wiki/%EC%83%9D%EC%9D%BC#Korean) | birthday | saeng'il · noun |
| [의견](https://en.wiktionary.org/wiki/%EC%9D%98%EA%B2%AC#Korean) | an opinion about something | uigyeon · noun |
| [인구](https://en.wiktionary.org/wiki/%EC%9D%B8%EA%B5%AC#Korean) | population | in'gu · noun |
| [틀](https://en.wiktionary.org/wiki/%ED%8B%80#Korean) | frame, framework | teul · noun |
| [편지](https://en.wiktionary.org/wiki/%ED%8E%B8%EC%A7%80#Korean) | letter (written message) | pyeonji · noun |
| [폭](https://en.wiktionary.org/wiki/%ED%8F%AD#Korean) | Breadth, width. | pok · noun |
| [각종](https://en.wiktionary.org/wiki/%EA%B0%81%EC%A2%85#Korean) | every sort; all kinds | gakjong · noun |
| [그러니까](https://en.wiktionary.org/wiki/%EA%B7%B8%EB%9F%AC%EB%8B%88%EA%B9%8C#Korean) | therefore, accordingly | geureonikka · adv |
| [물건](https://en.wiktionary.org/wiki/%EB%AC%BC%EA%B1%B4#Korean) | item, article, thing, stuff | mulgeon · noun |
| [오전](https://en.wiktionary.org/wiki/%EC%98%A4%EC%A0%84#Korean) | a.m. | ojeon · noun |
| [저런](https://en.wiktionary.org/wiki/%EC%A0%80%EB%9F%B0#Korean) | such, that kind of; like that | jeoreon · det |
| [경쟁](https://en.wiktionary.org/wiki/%EA%B2%BD%EC%9F%81#Korean) | competition | gyeongjaeng · noun |
| [밴드](https://en.wiktionary.org/wiki/%EB%B0%B4%EB%93%9C#Korean) | band (strip of material wrapped around things to hold them together) | baendeu · noun |
| [이때](https://en.wiktionary.org/wiki/%EC%9D%B4%EB%95%8C#Korean) | now; (at) this time; right now | ittae · noun |
| [작용](https://en.wiktionary.org/wiki/%EC%9E%91%EC%9A%A9#Korean) | operation | jagyong · noun |
| [투자](https://en.wiktionary.org/wiki/%ED%88%AC%EC%9E%90#Korean) | investment | tuja · noun |
| [홀](https://en.wiktionary.org/wiki/%ED%99%80#Korean) | hall | hol · noun |
| [계산](https://en.wiktionary.org/wiki/%EA%B3%84%EC%82%B0#Korean) | calculation, reckoning | gyesan · noun |
| [뇌](https://en.wiktionary.org/wiki/%EB%87%8C#Korean) | brain | noe · noun |
| [바닥](https://en.wiktionary.org/wiki/%EB%B0%94%EB%8B%A5#Korean) | floor; bottom; a flat and usually low surface of a space or object | badak · noun |
| [바둑](https://en.wiktionary.org/wiki/%EB%B0%94%EB%91%91#Korean) | the game of Go (an ancient East Asian board game based on surrounding the opponent's territory) | baduk · noun |
| [아무리](https://en.wiktionary.org/wiki/%EC%95%84%EB%AC%B4%EB%A6%AC#Korean) | however much/many; no matter how much/many | amuri · adv |
| [우선](https://en.wiktionary.org/wiki/%EC%9A%B0%EC%84%A0#Korean) | first, foremost | useon · adv |
| [체](https://en.wiktionary.org/wiki/%EC%B2%B4#Korean) | physical body; (by extension) gait or build | che · noun |
| [날씨](https://en.wiktionary.org/wiki/%EB%82%A0%EC%94%A8#Korean) | weather | nalssi · noun |
| [누나](https://en.wiktionary.org/wiki/%EB%88%84%EB%82%98#Korean) | older sister of a male | nuna · noun |
| [사상](https://en.wiktionary.org/wiki/%EC%82%AC%EC%83%81#Korean) | history, historic | sasang · noun |
| [사전](https://en.wiktionary.org/wiki/%EC%82%AC%EC%A0%84#Korean) | dictionary | sajeon · noun |
| [옛날](https://en.wiktionary.org/wiki/%EC%98%9B%EB%82%A0#Korean) | the past | yennal · noun |
| [파리](https://en.wiktionary.org/wiki/%ED%8C%8C%EB%A6%AC#Korean) | fly (insect) | pari · noun |
| [피부](https://en.wiktionary.org/wiki/%ED%94%BC%EB%B6%80#Korean) | skin | pibu · noun |
| [노동](https://en.wiktionary.org/wiki/%EB%85%B8%EB%8F%99#Korean) | labor, especially industrial | nodong · noun |
| [동네](https://en.wiktionary.org/wiki/%EB%8F%99%EB%84%A4#Korean) | neighborhood | dongne · noun |
| [부담](https://en.wiktionary.org/wiki/%EB%B6%80%EB%8B%B4#Korean) | burden | budam · noun |
| [얼른](https://en.wiktionary.org/wiki/%EC%96%BC%EB%A5%B8#Korean) | quickly, at once, without delay | eolleun · adv |
| [탓](https://en.wiktionary.org/wiki/%ED%83%93#Korean) | cause, reason | tat · noun |
| [건축](https://en.wiktionary.org/wiki/%EA%B1%B4%EC%B6%95#Korean) | architecture; construction | geonchuk · noun |
| [누리](https://en.wiktionary.org/wiki/%EB%88%84%EB%A6%AC#Korean) | world | nuri · noun |
| [비용](https://en.wiktionary.org/wiki/%EB%B9%84%EC%9A%A9#Korean) | cost, expense | biyong · noun |
| [수학](https://en.wiktionary.org/wiki/%EC%88%98%ED%95%99#Korean) | mathematics | suhak · noun |
| [이젠](https://en.wiktionary.org/wiki/%EC%9D%B4%EC%A0%A0#Korean) | now (as the topic of the sentence) | ijen · noun |
| [일찍](https://en.wiktionary.org/wiki/%EC%9D%BC%EC%B0%8D#Korean) | early | iljjik · adv |
| [통](https://en.wiktionary.org/wiki/%ED%86%B5#Korean) | barrel, bucket, cask, pail, vat | tong · noun |
| [군인](https://en.wiktionary.org/wiki/%EA%B5%B0%EC%9D%B8#Korean) | military personnel; soldier | gunin · noun |
| [그곳](https://en.wiktionary.org/wiki/%EA%B7%B8%EA%B3%B3#Korean) | there; that place, that part | geugot · noun |
| [따로](https://en.wiktionary.org/wiki/%EB%94%B0%EB%A1%9C#Korean) | differently; separately | ttaro · adv |

</details>

<details><summary>Words 851–900</summary>

![[Resources/Audio/ko/Words 0851-0900.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [마련](https://en.wiktionary.org/wiki/%EB%A7%88%EB%A0%A8#Korean) | preparation, arrangement | maryeon · noun |
| [멀리](https://en.wiktionary.org/wiki/%EB%A9%80%EB%A6%AC#Korean) | afar, at a distance | meolli · adv |
| [메인](https://en.wiktionary.org/wiki/%EB%A9%94%EC%9D%B8#Korean) | the state of being the main thing | mein · noun |
| [문학](https://en.wiktionary.org/wiki/%EB%AC%B8%ED%95%99#Korean) | literature | munhak · noun |
| [미술](https://en.wiktionary.org/wiki/%EB%AF%B8%EC%88%A0#Korean) | visual art | misul · noun |
| [미터](https://en.wiktionary.org/wiki/%EB%AF%B8%ED%84%B0#Korean) | meter; metre (SI unit of length) | miteo · noun |
| [부부](https://en.wiktionary.org/wiki/%EB%B6%80%EB%B6%80#Korean) | couple, husband and wife; marital | bubu · noun |
| [세월](https://en.wiktionary.org/wiki/%EC%84%B8%EC%9B%94#Korean) | time | sewol · noun |
| [소유](https://en.wiktionary.org/wiki/%EC%86%8C%EC%9C%A0#Korean) | possession (ownership of something) | soyu · noun |
| [쓰레기](https://en.wiktionary.org/wiki/%EC%93%B0%EB%A0%88%EA%B8%B0#Korean) | trash, garbage | sseuregi · noun |
| [작년](https://en.wiktionary.org/wiki/%EC%9E%91%EB%85%84#Korean) | last year; the year before | jangnyeon · noun |
| [직장](https://en.wiktionary.org/wiki/%EC%A7%81%EC%9E%A5#Korean) | workplace, job | jikjang · noun |
| [환영](https://en.wiktionary.org/wiki/%ED%99%98%EC%98%81#Korean) | welcome | hwanyeong · noun |
| [가을](https://en.wiktionary.org/wiki/%EA%B0%80%EC%9D%84#Korean) | autumn, fall | ga'eul · noun |
| [메시지](https://en.wiktionary.org/wiki/%EB%A9%94%EC%8B%9C%EC%A7%80#Korean) | message | mesiji · noun |
| [바보](https://en.wiktionary.org/wiki/%EB%B0%94%EB%B3%B4#Korean) | The Fool (Tarot card) | babo · noun |
| [불안](https://en.wiktionary.org/wiki/%EB%B6%88%EC%95%88#Korean) | anxiety, uneasiness | buran · noun |
| [손가락](https://en.wiktionary.org/wiki/%EC%86%90%EA%B0%80%EB%9D%BD#Korean) | finger | son'garak · noun |
| [한국어](https://en.wiktionary.org/wiki/%ED%95%9C%EA%B5%AD%EC%96%B4#Korean) | the Korean language | han'gugeo · noun |
| [고향](https://en.wiktionary.org/wiki/%EA%B3%A0%ED%96%A5#Korean) | one's hometown or birthplace | gohyang · noun |
| [군사](https://en.wiktionary.org/wiki/%EA%B5%B0%EC%82%AC#Korean) | A soldier or soldiers. | gunsa · noun |
| [농구](https://en.wiktionary.org/wiki/%EB%86%8D%EA%B5%AC#Korean) | basketball (sport) | nonggu · noun |
| [둔](https://en.wiktionary.org/wiki/%EB%91%94#Korean) | stationed camp | dun · noun |
| [자식](https://en.wiktionary.org/wiki/%EC%9E%90%EC%8B%9D#Korean) | one's children, offspring | jasik · noun |
| [재산](https://en.wiktionary.org/wiki/%EC%9E%AC%EC%82%B0#Korean) | public or private property | jaesan · noun |
| [전공](https://en.wiktionary.org/wiki/%EC%A0%84%EA%B3%B5#Korean) | major (area of study) | jeon'gong · noun |
| [태풍](https://en.wiktionary.org/wiki/%ED%83%9C%ED%92%8D#Korean) | typhoon | taepung · noun |
| [할머니](https://en.wiktionary.org/wiki/%ED%95%A0%EB%A8%B8%EB%8B%88#Korean) | grandmother; (by extension) elderly female | halmeoni · noun |
| [개선](https://en.wiktionary.org/wiki/%EA%B0%9C%EC%84%A0#Korean) | reform or improvement in general | gaeseon · noun |
| [걔](https://en.wiktionary.org/wiki/%EA%B1%94#Korean) | that kid; he or she | gyae · pron |
| [반복](https://en.wiktionary.org/wiki/%EB%B0%98%EB%B3%B5#Korean) | repetition | banbok · noun |
| [신화](https://en.wiktionary.org/wiki/%EC%8B%A0%ED%99%94#Korean) | A myth or legend. | sinhwa · noun |
| [오히려](https://en.wiktionary.org/wiki/%EC%98%A4%ED%9E%88%EB%A0%A4#Korean) | rather; on the contrary; unexpectedly | ohiryeo · adv |
| [외국](https://en.wiktionary.org/wiki/%EC%99%B8%EA%B5%AD#Korean) | a foreign country | oeguk · noun |
| [인류](https://en.wiktionary.org/wiki/%EC%9D%B8%EB%A5%98#Korean) | humankind, humanity | illyu · noun |
| [형식](https://en.wiktionary.org/wiki/%ED%98%95%EC%8B%9D#Korean) | form, template | hyeongsik · noun |
| [감염](https://en.wiktionary.org/wiki/%EA%B0%90%EC%97%BC#Korean) | infection, contagion, infestation | gamyeom · noun |
| [바이러스](https://en.wiktionary.org/wiki/%EB%B0%94%EC%9D%B4%EB%9F%AC%EC%8A%A4#Korean) | virus (disease-causing pseudo-organism) | baireoseu · noun |
| [반드시](https://en.wiktionary.org/wiki/%EB%B0%98%EB%93%9C%EC%8B%9C#Korean) | surely; certainly; without fail | bandeusi · adv |
| [특성](https://en.wiktionary.org/wiki/%ED%8A%B9%EC%84%B1#Korean) | characteristic | teukseong · noun |
| [평](https://en.wiktionary.org/wiki/%ED%8F%89#Korean) | criticism | pyeong · noun |
| [표정](https://en.wiktionary.org/wiki/%ED%91%9C%EC%A0%95#Korean) | an expression of feeling, especially a facial expression | pyojeong · noun |
| [그램](https://en.wiktionary.org/wiki/%EA%B7%B8%EB%9E%A8#Korean) | gram (unit) | geuraem · noun |
| [넷](https://en.wiktionary.org/wiki/%EB%84%B7#Korean) | four (as a noun) | net · num |
| [도서관](https://en.wiktionary.org/wiki/%EB%8F%84%EC%84%9C%EA%B4%80#Korean) | library | doseogwan · noun |
| [반면](https://en.wiktionary.org/wiki/%EB%B0%98%EB%A9%B4#Korean) | the other hand, the flip side | banmyeon · noun |
| [빵](https://en.wiktionary.org/wiki/%EB%B9%B5#Korean) | bread | ppang · noun |
| [가게](https://en.wiktionary.org/wiki/%EA%B0%80%EA%B2%8C#Korean) | store, shop | gage · noun |
| [갑](https://en.wiktionary.org/wiki/%EA%B0%91#Korean) | armor; shell | gap · noun |
| [그날](https://en.wiktionary.org/wiki/%EA%B7%B8%EB%82%A0#Korean) | that day; the day in question | geunal · noun |

</details>

<details><summary>Words 901–950</summary>

![[Resources/Audio/ko/Words 0901-0950.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [그동안](https://en.wiktionary.org/wiki/%EA%B7%B8%EB%8F%99%EC%95%88#Korean) | since our last meeting or conversation | geudong'an · adv |
| [단위](https://en.wiktionary.org/wiki/%EB%8B%A8%EC%9C%84#Korean) | a unit | danwi · noun |
| [담배](https://en.wiktionary.org/wiki/%EB%8B%B4%EB%B0%B0#Korean) | tobacco | dambae · noun |
| [박물관](https://en.wiktionary.org/wiki/%EB%B0%95%EB%AC%BC%EA%B4%80#Korean) | museum | bangmulgwan · noun |
| [어른](https://en.wiktionary.org/wiki/%EC%96%B4%EB%A5%B8#Korean) | grownup, adult, elder, senior | eoreun · noun |
| [창조](https://en.wiktionary.org/wiki/%EC%B0%BD%EC%A1%B0#Korean) | creation (act of creating) | changjo · noun |
| [테스트](https://en.wiktionary.org/wiki/%ED%85%8C%EC%8A%A4%ED%8A%B8#Korean) | test, examination | teseuteu · noun |
| [고기](https://en.wiktionary.org/wiki/%EA%B3%A0%EA%B8%B0#Korean) | meat; flesh | gogi · noun |
| [너무나](https://en.wiktionary.org/wiki/%EB%84%88%EB%AC%B4%EB%82%98#Korean) | far too much; excessively | neomuna · adv |
| [눈물](https://en.wiktionary.org/wiki/%EB%88%88%EB%AC%BC#Korean) | tears | nunmul · noun |
| [대형](https://en.wiktionary.org/wiki/%EB%8C%80%ED%98%95#Korean) | Large; on a large scale. | daehyeong · noun |
| [라디오](https://en.wiktionary.org/wiki/%EB%9D%BC%EB%94%94%EC%98%A4#Korean) | radio | [ɾa̠dio̞] · noun |
| [모임](https://en.wiktionary.org/wiki/%EB%AA%A8%EC%9E%84#Korean) | a gathering or meeting | moim · noun |
| [웃음](https://en.wiktionary.org/wiki/%EC%9B%83%EC%9D%8C#Korean) | laughter | useum · noun |
| [이리](https://en.wiktionary.org/wiki/%EC%9D%B4%EB%A6%AC#Korean) | to this place, hither, here | iri · adv |
| [자치](https://en.wiktionary.org/wiki/%EC%9E%90%EC%B9%98#Korean) | The Korean taimen, Hucho ishikawae. | jachi · noun |
| [주위](https://en.wiktionary.org/wiki/%EC%A3%BC%EC%9C%84#Korean) | circumference | juwi · noun |
| [도대체](https://en.wiktionary.org/wiki/%EB%8F%84%EB%8C%80%EC%B2%B4#Korean) | on earth; the hell | dodaeche · adv |
| [모자](https://en.wiktionary.org/wiki/%EB%AA%A8%EC%9E%90#Korean) | hat, cap | moja · noun |
| [범위](https://en.wiktionary.org/wiki/%EB%B2%94%EC%9C%84#Korean) | A field, scope, or range. | beomwi · noun |
| [새벽](https://en.wiktionary.org/wiki/%EC%83%88%EB%B2%BD#Korean) | dawn; daybreak; cockcrow (also used to indicate time of the day, approximately from 1:00 a.m. to 3:00 a.m.) | saebyeok · noun |
| [임신](https://en.wiktionary.org/wiki/%EC%9E%84%EC%8B%A0#Korean) | pregnancy | imsin · noun |
| [가방](https://en.wiktionary.org/wiki/%EA%B0%80%EB%B0%A9#Korean) | bag; briefcase | gabang · noun |
| [곁](https://en.wiktionary.org/wiki/%EA%B3%81#Korean) | the vicinity or side of something | gyeot · noun |
| [노동자](https://en.wiktionary.org/wiki/%EB%85%B8%EB%8F%99%EC%9E%90#Korean) | worker | nodongja · noun |
| [맥주](https://en.wiktionary.org/wiki/%EB%A7%A5%EC%A3%BC#Korean) | beer | maekju · noun |
| [무릎](https://en.wiktionary.org/wiki/%EB%AC%B4%EB%A6%8E#Korean) | knee | mureup · noun |
| [수단](https://en.wiktionary.org/wiki/%EC%88%98%EB%8B%A8#Korean) | procedure; method; way; a means (to an end) | sudan · noun |
| [의무](https://en.wiktionary.org/wiki/%EC%9D%98%EB%AC%B4#Korean) | duty, obligation | uimu · noun |
| [의지](https://en.wiktionary.org/wiki/%EC%9D%98%EC%A7%80#Korean) | determination to accomplish something; steadfastness | uiji · noun |
| [구경](https://en.wiktionary.org/wiki/%EA%B5%AC%EA%B2%BD#Korean) | a viewing | gugyeong · noun |
| [날개](https://en.wiktionary.org/wiki/%EB%82%A0%EA%B0%9C#Korean) | wing (of a bird, insect, etc.) | nalgae · noun |
| [농업](https://en.wiktionary.org/wiki/%EB%86%8D%EC%97%85#Korean) | agriculture | nong'eop · noun |
| [맥](https://en.wiktionary.org/wiki/%EB%A7%A5#Korean) | blood vein | maek · noun |
| [철](https://en.wiktionary.org/wiki/%EC%B2%A0#Korean) | season (of the year) | cheol · noun |
| [철학](https://en.wiktionary.org/wiki/%EC%B2%A0%ED%95%99#Korean) | philosophy | cheolhak · noun |
| [PC](https://en.wiktionary.org/wiki/PC#Korean) | synonym of 피시 (pisi) | [pʰiɕ͈i] · noun |
| [사정](https://en.wiktionary.org/wiki/%EC%82%AC%EC%A0%95#Korean) | condition or status of something, or the reason for that | sajeong · noun |
| [시선](https://en.wiktionary.org/wiki/%EC%8B%9C%EC%84%A0#Korean) | one's gaze; the direction of one's vision | siseon · noun |
| [앗](https://en.wiktionary.org/wiki/%EC%95%97#Korean) | oh | at · intj |
| [할아버지](https://en.wiktionary.org/wiki/%ED%95%A0%EC%95%84%EB%B2%84%EC%A7%80#Korean) | grandfather; elderly male | harabeoji · noun |
| [똥](https://en.wiktionary.org/wiki/%EB%98%A5#Korean) | dung, poop, shit, excrement | ttong · noun |
| [식당](https://en.wiktionary.org/wiki/%EC%8B%9D%EB%8B%B9#Korean) | restaurant | sikdang · noun |
| [뿌리](https://en.wiktionary.org/wiki/%EB%BF%8C%EB%A6%AC#Korean) | root (of plants) | ppuri · noun |
| [육](https://en.wiktionary.org/wiki/%EC%9C%A1#Korean) | six | yuk · num |
| [인형](https://en.wiktionary.org/wiki/%EC%9D%B8%ED%98%95#Korean) | doll, puppet, action figure, any small human form | inhyeong · noun |
| [판결](https://en.wiktionary.org/wiki/%ED%8C%90%EA%B2%B0#Korean) | A judgment, either of fact or of right and wrong. | pan'gyeol · noun |
| [광](https://en.wiktionary.org/wiki/%EA%B4%91#Korean) | place of storage; (especially) granary | gwang · noun |
| [선배](https://en.wiktionary.org/wiki/%EC%84%A0%EB%B0%B0#Korean) | a senior or elder in an organization | seonbae · noun |
| [암호](https://en.wiktionary.org/wiki/%EC%95%94%ED%98%B8#Korean) | password, code | amho · noun |

</details>

<details><summary>Words 951–1000</summary>

![[Resources/Audio/ko/Words 0951-1000.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [어찌](https://en.wiktionary.org/wiki/%EC%96%B4%EC%B0%8C#Korean) | How, in what way or for what purpose. | eojji · adv |
| [임금](https://en.wiktionary.org/wiki/%EC%9E%84%EA%B8%88#Korean) | king; monarch | imgeum · noun |
| [진지](https://en.wiktionary.org/wiki/%EC%A7%84%EC%A7%80#Korean) | honorific of 밥 (bap, “meal; food”) | jinji · noun |
| [집안](https://en.wiktionary.org/wiki/%EC%A7%91%EC%95%88#Korean) | a household | jiban · noun |
| [한글](https://en.wiktionary.org/wiki/%ED%95%9C%EA%B8%80#Korean) | hangul; the Korean alphabet | han'geul · noun |
| [글자](https://en.wiktionary.org/wiki/%EA%B8%80%EC%9E%90#Korean) | letter, character (of a writing system) | geulja · noun |
| [민주주의](https://en.wiktionary.org/wiki/%EB%AF%BC%EC%A3%BC%EC%A3%BC%EC%9D%98#Korean) | democracy | minjujuui · noun |
| [시계](https://en.wiktionary.org/wiki/%EC%8B%9C%EA%B3%84#Korean) | a clock, a watch, a timepiece | sigye · noun |
| [쌀](https://en.wiktionary.org/wiki/%EC%8C%80#Korean) | uncooked rice | ssal · noun |
| [엉덩이](https://en.wiktionary.org/wiki/%EC%97%89%EB%8D%A9%EC%9D%B4#Korean) | buttocks, bottom | eongdeong'i · noun |
| [오늘날](https://en.wiktionary.org/wiki/%EC%98%A4%EB%8A%98%EB%82%A0#Korean) | these days; modern times | oneullal · noun |
| [일요일](https://en.wiktionary.org/wiki/%EC%9D%BC%EC%9A%94%EC%9D%BC#Korean) | Sunday | iryoil · noun |
| [중계](https://en.wiktionary.org/wiki/%EC%A4%91%EA%B3%84#Korean) | relay broadcast | junggye · noun |
| [학](https://en.wiktionary.org/wiki/%ED%95%99#Korean) | crane (bird) | hak · noun |
| [복](https://en.wiktionary.org/wiki/%EB%B3%B5#Korean) | fortune, blessing, luck | bok · noun |
| [비행기](https://en.wiktionary.org/wiki/%EB%B9%84%ED%96%89%EA%B8%B0#Korean) | airplane | bihaenggi · noun |
| [재료](https://en.wiktionary.org/wiki/%EC%9E%AC%EB%A3%8C#Korean) | ingredients, materials | jaeryo · noun |
| [나름](https://en.wiktionary.org/wiki/%EB%82%98%EB%A6%84#Korean) | dependence, essence, nature | nareum · noun |
| [독](https://en.wiktionary.org/wiki/%EB%8F%85#Korean) | jar, jug (made of clay) | dok · noun |
| [독자](https://en.wiktionary.org/wiki/%EB%8F%85%EC%9E%90#Korean) | reader (one who reads) | dokja · noun |
| [랩](https://en.wiktionary.org/wiki/%EB%9E%A9#Korean) | rap music | raep · noun |
| [며칠](https://en.wiktionary.org/wiki/%EB%A9%B0%EC%B9%A0#Korean) | how many days? | myeochil · noun |
| [상당히](https://en.wiktionary.org/wiki/%EC%83%81%EB%8B%B9%ED%9E%88#Korean) | suitably; to an appropriate degree | sangdanghi · adv |
| [설마](https://en.wiktionary.org/wiki/%EC%84%A4%EB%A7%88#Korean) | surely (in a negative context) | seolma · adv |
| [시인](https://en.wiktionary.org/wiki/%EC%8B%9C%EC%9D%B8#Korean) | poet | siin · noun |
| [아마도](https://en.wiktionary.org/wiki/%EC%95%84%EB%A7%88%EB%8F%84#Korean) | maybe | amado · adv |
| [어깨](https://en.wiktionary.org/wiki/%EC%96%B4%EA%B9%A8#Korean) | shoulders | eokkae · noun |
| [이웃](https://en.wiktionary.org/wiki/%EC%9D%B4%EC%9B%83#Korean) | neighbor (a person who lives nearby) | iut · noun |
| [즉시](https://en.wiktionary.org/wiki/%EC%A6%89%EC%8B%9C#Korean) | immediately, promptly | jeuksi · adv |
| [태도](https://en.wiktionary.org/wiki/%ED%83%9C%EB%8F%84#Korean) | attitude, stance | taedo · noun |
| [토요일](https://en.wiktionary.org/wiki/%ED%86%A0%EC%9A%94%EC%9D%BC#Korean) | Saturday | toyoil · noun |
| [공정](https://en.wiktionary.org/wiki/%EA%B3%B5%EC%A0%95#Korean) | process | gongjeong · noun |
| [바지](https://en.wiktionary.org/wiki/%EB%B0%94%EC%A7%80#Korean) | pants, trousers | baji · noun |
| [질병](https://en.wiktionary.org/wiki/%EC%A7%88%EB%B3%91#Korean) | disease, sickness | jilbyeong · noun |
| [추](https://en.wiktionary.org/wiki/%EC%B6%94#Korean) | a (balance) weight (hanja:錘) | chu · noun |
| [녀](https://en.wiktionary.org/wiki/%EB%85%80#Korean) | North Korea standard spelling of 여(女) (yeo, “woman; female”) | nyeo · noun |
| [대책](https://en.wiktionary.org/wiki/%EB%8C%80%EC%B1%85#Korean) | policy with regard to a particular issue | daechaek · noun |
| [록](https://en.wiktionary.org/wiki/%EB%A1%9D#Korean) | rock; rock music | rok · noun |
| [의자](https://en.wiktionary.org/wiki/%EC%9D%98%EC%9E%90#Korean) | chair, sofa | uija · noun |
| [중학교](https://en.wiktionary.org/wiki/%EC%A4%91%ED%95%99%EA%B5%90#Korean) | middle school | junghakgyo · noun |
| [과연](https://en.wiktionary.org/wiki/%EA%B3%BC%EC%97%B0#Korean) | indeed, really | gwayeon · adv |
| [남녀](https://en.wiktionary.org/wiki/%EB%82%A8%EB%85%80#Korean) | man and woman | namnyeo · noun |
| [아예](https://en.wiktionary.org/wiki/%EC%95%84%EC%98%88#Korean) | Altogether; entirely. | aye · adv |
| [여유](https://en.wiktionary.org/wiki/%EC%97%AC%EC%9C%A0#Korean) | leeway; remainder; extra time or space | yeoyu · noun |
| [유도](https://en.wiktionary.org/wiki/%EC%9C%A0%EB%8F%84#Korean) | judo | yudo · noun |
| [경마](https://en.wiktionary.org/wiki/%EA%B2%BD%EB%A7%88#Korean) | horse race | gyeongma · noun |
| [교실](https://en.wiktionary.org/wiki/%EA%B5%90%EC%8B%A4#Korean) | classroom | gyosil · noun |
| [굴](https://en.wiktionary.org/wiki/%EA%B5%B4#Korean) | cave | gul · noun |
| [사용자](https://en.wiktionary.org/wiki/%EC%82%AC%EC%9A%A9%EC%9E%90#Korean) | user | sayongja · noun |
| [정규](https://en.wiktionary.org/wiki/%EC%A0%95%EA%B7%9C#Korean) | formality, regularity | jeonggyu · noun |

</details>

## Question bank

Try before opening the answers. Different tasks use the same sentence to practise complementary skills. Open translation and explanation tasks can have valid alternatives.

### Topic 은 and 는 · 50 questions

**ko-Q0001 · Fill the gap**

____ 갈 거에요.

I'm going to go.

[[Korean#^ko-Q0001-answer|Compare the answer]]
^ko-Q0001

**ko-Q0002 · Choose the form**

____ 갈 거에요.

I'm going to go.

Choices: 는 / 나는 / 은 / 이

[[Korean#^ko-Q0002-answer|Compare the answer]]
^ko-Q0002

**ko-Q0003 · Edit the changed sentence**

【은】 벽장에서 헌 구두상자를 꺼내 열었다.

Tom pulled out an old shoebox from his closet and opened it.

[[Korean#^ko-Q0003-answer|Compare the answer]]
^ko-Q0003

**ko-Q0004 · Build the sentence**

Arrange: 헌 / 열었다. / 구두상자를 / 꺼내 / 벽장에서 / 톰은

Tom pulled out an old shoebox from his closet and opened it.

[[Korean#^ko-Q0004-answer|Compare the answer]]
^ko-Q0004

**ko-Q0005 · Write a translation**

Write this in Korean: You have talent, no doubt; it's just a pity that you haven't learned more.

[[Korean#^ko-Q0005-answer|Compare the answer]]
^ko-Q0005

**ko-Q0006 · Explain the grammar**

【너는】 분명히 재능이 있는데 더 많이 못 배워서 아쉽구나.

You have talent, no doubt; it's just a pity that you haven't learned more.

[[Korean#^ko-Q0006-answer|Compare the answer]]
^ko-Q0006

**ko-Q0007 · Fill the gap**

____ 열정적인 애지?

Tom is passionate, isn't he?

[[Korean#^ko-Q0007-answer|Compare the answer]]
^ko-Q0007

**ko-Q0008 · Choose the form**

____ 열정적인 애지?

Tom is passionate, isn't he?

Choices: 이 / 톰은 / 는 / 은

[[Korean#^ko-Q0008-answer|Compare the answer]]
^ko-Q0008

**ko-Q0009 · Edit the changed sentence**

그녀의 【은】 길어.

Her hair is long.

[[Korean#^ko-Q0009-answer|Compare the answer]]
^ko-Q0009

**ko-Q0010 · Build the sentence**

Arrange: 머리카락은 / 길어. / 그녀의

Her hair is long.

[[Korean#^ko-Q0010-answer|Compare the answer]]
^ko-Q0010

**ko-Q0011 · Write a translation**

Write this in Korean: Tom hasn't finished his homework yet.

[[Korean#^ko-Q0011-answer|Compare the answer]]
^ko-Q0011

**ko-Q0012 · Explain the grammar**

【톰은】 아직 숙제를 안 했다.

Tom hasn't finished his homework yet.

[[Korean#^ko-Q0012-answer|Compare the answer]]
^ko-Q0012

**ko-Q0013 · Fill the gap**

____ 그 것에 푹 빠져 있었다.

Tom was totally into it.

[[Korean#^ko-Q0013-answer|Compare the answer]]
^ko-Q0013

**ko-Q0014 · Choose the form**

____ 그 것에 푹 빠져 있었다.

Tom was totally into it.

Choices: 이 / 는 / 은 / 탐은

[[Korean#^ko-Q0014-answer|Compare the answer]]
^ko-Q0014

**ko-Q0015 · Edit the changed sentence**

【은】 진짜 바빠.

Tom is real busy.

[[Korean#^ko-Q0015-answer|Compare the answer]]
^ko-Q0015

**ko-Q0016 · Build the sentence**

Arrange: 진짜 / 바빠. / 톰은

Tom is real busy.

[[Korean#^ko-Q0016-answer|Compare the answer]]
^ko-Q0016

**ko-Q0017 · Write a translation**

Write this in Korean: Mary is addicted to coffee.

[[Korean#^ko-Q0017-answer|Compare the answer]]
^ko-Q0017

**ko-Q0018 · Explain the grammar**

【메리는】 커피 중독자야.

Mary is addicted to coffee.

[[Korean#^ko-Q0018-answer|Compare the answer]]
^ko-Q0018

**ko-Q0019 · Fill the gap**

네가 고등학교 ____ 게 사실이니?

Is it true that you're a high school teacher?

[[Korean#^ko-Q0019-answer|Compare the answer]]
^ko-Q0019

**ko-Q0020 · Choose the form**

네가 고등학교 ____ 게 사실이니?

Is it true that you're a high school teacher?

Choices: 선생님이라는 / 은 / 는 / 이

[[Korean#^ko-Q0020-answer|Compare the answer]]
^ko-Q0020

**ko-Q0021 · Edit the changed sentence**

【은】 현재 작은 아파트에서 혼자 살고 있다.

Tom currently lives alone in a small apartment.

[[Korean#^ko-Q0021-answer|Compare the answer]]
^ko-Q0021

**ko-Q0022 · Build the sentence**

Arrange: 탐은 / 살고 / 있다. / 혼자 / 현재 / 작은 / 아파트에서

Tom currently lives alone in a small apartment.

[[Korean#^ko-Q0022-answer|Compare the answer]]
^ko-Q0022

**ko-Q0023 · Write a translation**

Write this in Korean: Japan and South Korea are neighbors.

[[Korean#^ko-Q0023-answer|Compare the answer]]
^ko-Q0023

**ko-Q0024 · Explain the grammar**

일본과 【남한은】 이웃 국가다.

Japan and South Korea are neighbors.

[[Korean#^ko-Q0024-answer|Compare the answer]]
^ko-Q0024

**ko-Q0025 · Fill the gap**

____ 우리가 생각하는 것이다.

We are what we think we are.

[[Korean#^ko-Q0025-answer|Compare the answer]]
^ko-Q0025

**ko-Q0026 · Choose the form**

____ 우리가 생각하는 것이다.

We are what we think we are.

Choices: 우리는 / 는 / 은 / 이

[[Korean#^ko-Q0026-answer|Compare the answer]]
^ko-Q0026

**ko-Q0027 · Edit the changed sentence**

【은】 그녀의 모자가 싫다.

I hate her hat.

[[Korean#^ko-Q0027-answer|Compare the answer]]
^ko-Q0027

**ko-Q0028 · Build the sentence**

Arrange: 그녀의 / 나는 / 모자가 / 싫다.

I hate her hat.

[[Korean#^ko-Q0028-answer|Compare the answer]]
^ko-Q0028

**ko-Q0029 · Write a translation**

Write this in Korean: Tom is a bit scared.

[[Korean#^ko-Q0029-answer|Compare the answer]]
^ko-Q0029

**ko-Q0030 · Explain the grammar**

【톰은】 좀 무서워해하고 있어.

Tom is a bit scared.

[[Korean#^ko-Q0030-answer|Compare the answer]]
^ko-Q0030

**ko-Q0031 · Fill the gap**

____ 메리가 그에게 준 와인 한 병에 대하여 메리에게 감사함을 표시했다.

Tom thanked Mary for the bottle of wine she gave him.

[[Korean#^ko-Q0031-answer|Compare the answer]]
^ko-Q0031

**ko-Q0032 · Choose the form**

____ 메리가 그에게 준 와인 한 병에 대하여 메리에게 감사함을 표시했다.

Tom thanked Mary for the bottle of wine she gave him.

Choices: 이 / 는 / 톰은 / 은

[[Korean#^ko-Q0032-answer|Compare the answer]]
^ko-Q0032

**ko-Q0033 · Edit the changed sentence**

【은】 정말 세게 공을 찼다.

Tom kicked the ball really hard.

[[Korean#^ko-Q0033-answer|Compare the answer]]
^ko-Q0033

**ko-Q0034 · Build the sentence**

Arrange: 공을 / 찼다. / 정말 / 톰은 / 세게

Tom kicked the ball really hard.

[[Korean#^ko-Q0034-answer|Compare the answer]]
^ko-Q0034

**ko-Q0035 · Write a translation**

Write this in Korean: I was pretty young back in those days.

[[Korean#^ko-Q0035-answer|Compare the answer]]
^ko-Q0035

**ko-Q0036 · Explain the grammar**

그 【때는】 꽤 어렸었는데.

I was pretty young back in those days.

[[Korean#^ko-Q0036-answer|Compare the answer]]
^ko-Q0036

**ko-Q0037 · Fill the gap**

____ 그 사슴의 발자국을 따라갔다.

We followed the deer's tracks.

[[Korean#^ko-Q0037-answer|Compare the answer]]
^ko-Q0037

**ko-Q0038 · Choose the form**

____ 그 사슴의 발자국을 따라갔다.

We followed the deer's tracks.

Choices: 는 / 이 / 우리는 / 은

[[Korean#^ko-Q0038-answer|Compare the answer]]
^ko-Q0038

**ko-Q0039 · Edit the changed sentence**

【은】 먹은 것이 없습니다.

I haven't eaten anything.

[[Korean#^ko-Q0039-answer|Compare the answer]]
^ko-Q0039

**ko-Q0040 · Build the sentence**

Arrange: 저는 / 것이 / 먹은 / 없습니다.

I haven't eaten anything.

[[Korean#^ko-Q0040-answer|Compare the answer]]
^ko-Q0040

**ko-Q0041 · Write a translation**

Write this in Korean: Brazil is the biggest country in South America.

[[Korean#^ko-Q0041-answer|Compare the answer]]
^ko-Q0041

**ko-Q0042 · Explain the grammar**

【브라질은】 남미에서 가장 큰 나라입니다.

Brazil is the biggest country in South America.

[[Korean#^ko-Q0042-answer|Compare the answer]]
^ko-Q0042

**ko-Q0043 · Fill the gap**

____ 원하는 걸 얻을 때까지는 떠나지 않을 거야.

Tom won't leave until he gets what he wants.

[[Korean#^ko-Q0043-answer|Compare the answer]]
^ko-Q0043

**ko-Q0044 · Choose the form**

____ 원하는 걸 얻을 때까지는 떠나지 않을 거야.

Tom won't leave until he gets what he wants.

Choices: 톰은 / 는 / 이 / 은

[[Korean#^ko-Q0044-answer|Compare the answer]]
^ko-Q0044

**ko-Q0045 · Edit the changed sentence**

【은】 하루에 삼십 번 이상 손을 씻어.

Tom washes his hands more than thirty times a day.

[[Korean#^ko-Q0045-answer|Compare the answer]]
^ko-Q0045

**ko-Q0046 · Build the sentence**

Arrange: 톰은 / 손을 / 삼십 / 씻어. / 번 / 하루에 / 이상

Tom washes his hands more than thirty times a day.

[[Korean#^ko-Q0046-answer|Compare the answer]]
^ko-Q0046

**ko-Q0047 · Write a translation**

Write this in Korean: They liked each other.

[[Korean#^ko-Q0047-answer|Compare the answer]]
^ko-Q0047

**ko-Q0048 · Explain the grammar**

【그들은】 서로 좋아 합니다

They liked each other.

[[Korean#^ko-Q0048-answer|Compare the answer]]
^ko-Q0048

**ko-Q0049 · Fill the gap**

____ 대부분의 흡혈귀와는 달리 관에서 자지 않는다.

Tom doesn't sleep in a coffin like most vampires.

[[Korean#^ko-Q0049-answer|Compare the answer]]
^ko-Q0049

**ko-Q0050 · Choose the form**

____ 대부분의 흡혈귀와는 달리 관에서 자지 않는다.

Tom doesn't sleep in a coffin like most vampires.

Choices: 은 / 톰은 / 는 / 이

[[Korean#^ko-Q0050-answer|Compare the answer]]
^ko-Q0050


### Subject 이 and 가 · 50 questions

**ko-Q0051 · Edit the changed sentence**

【이】 잘못했다고 생각한다.

I feel guilty.

[[Korean#^ko-Q0051-answer|Compare the answer]]
^ko-Q0051

**ko-Q0052 · Build the sentence**

Arrange: 잘못했다고 / 자기가 / 생각한다.

I feel guilty.

[[Korean#^ko-Q0052-answer|Compare the answer]]
^ko-Q0052

**ko-Q0053 · Write a translation**

Write this in Korean: British films are better than American films.

[[Korean#^ko-Q0053-answer|Compare the answer]]
^ko-Q0053

**ko-Q0054 · Explain the grammar**

영국 【영화가】 미국 영화보다 낫다.

British films are better than American films.

[[Korean#^ko-Q0054-answer|Compare the answer]]
^ko-Q0054

**ko-Q0055 · Fill the gap**

의심할 ____ 없읍니다

It's out of the question.

[[Korean#^ko-Q0055-answer|Compare the answer]]
^ko-Q0055

**ko-Q0056 · Choose the form**

의심할 ____ 없읍니다

It's out of the question.

Choices: 여시가 / 이 / 가 / 은

[[Korean#^ko-Q0056-answer|Compare the answer]]
^ko-Q0056

**ko-Q0057 · Edit the changed sentence**

너 새차 【이】 뭐야?

What color is your new car?

[[Korean#^ko-Q0057-answer|Compare the answer]]
^ko-Q0057

**ko-Q0058 · Build the sentence**

Arrange: 색깔이 / 뭐야? / 너 / 새차

What color is your new car?

[[Korean#^ko-Q0058-answer|Compare the answer]]
^ko-Q0058

**ko-Q0059 · Write a translation**

Write this in Korean: Where is the logic in that?

[[Korean#^ko-Q0059-answer|Compare the answer]]
^ko-Q0059

**ko-Q0060 · Explain the grammar**

거기에 【논리가】 어디 있지?

Where is the logic in that?

[[Korean#^ko-Q0060-answer|Compare the answer]]
^ko-Q0060

**ko-Q0061 · Fill the gap**

____ 아실 것입니다.

Only God knows.

[[Korean#^ko-Q0061-answer|Compare the answer]]
^ko-Q0061

**ko-Q0062 · Choose the form**

____ 아실 것입니다.

Only God knows.

Choices: 이 / 신만이 / 은 / 가

[[Korean#^ko-Q0062-answer|Compare the answer]]
^ko-Q0062

**ko-Q0063 · Edit the changed sentence**

그게 【이】 말하려던 거야.

That's what I was going to say.

[[Korean#^ko-Q0063-answer|Compare the answer]]
^ko-Q0063

**ko-Q0064 · Build the sentence**

Arrange: 거야. / 말하려던 / 그게 / 내가

That's what I was going to say.

[[Korean#^ko-Q0064-answer|Compare the answer]]
^ko-Q0064

**ko-Q0065 · Write a translation**

Write this in Korean: I think Mary is way cuter than Alice.

[[Korean#^ko-Q0065-answer|Compare the answer]]
^ko-Q0065

**ko-Q0066 · Explain the grammar**

【메리가】 앨리스보다 좀 더 귀여운 것 같아.

I think Mary is way cuter than Alice.

[[Korean#^ko-Q0066-answer|Compare the answer]]
^ko-Q0066

**ko-Q0067 · Fill the gap**

군인 ____ 부상을 당했다.

Three soldiers were wounded.

[[Korean#^ko-Q0067-answer|Compare the answer]]
^ko-Q0067

**ko-Q0068 · Choose the form**

군인 ____ 부상을 당했다.

Three soldiers were wounded.

Choices: 은 / 세명이 / 가 / 이

[[Korean#^ko-Q0068-answer|Compare the answer]]
^ko-Q0068

**ko-Q0069 · Edit the changed sentence**

A와 B의 【이】 뭐예요?

What is the difference between A and B?

[[Korean#^ko-Q0069-answer|Compare the answer]]
^ko-Q0069

**ko-Q0070 · Build the sentence**

Arrange: A와 / 차이가 / B의 / 뭐예요?

What is the difference between A and B?

[[Korean#^ko-Q0070-answer|Compare the answer]]
^ko-Q0070

**ko-Q0071 · Write a translation**

Write this in Korean: I can't stand Mary's boyfriend.

[[Korean#^ko-Q0071-answer|Compare the answer]]
^ko-Q0071

**ko-Q0072 · Explain the grammar**

난 메리의 남자친구를 참을 【수가】 없어.

I can't stand Mary's boyfriend.

[[Korean#^ko-Q0072-answer|Compare the answer]]
^ko-Q0072

**ko-Q0073 · Fill the gap**

여긴 거의 ____ 안 와.

It rarely snows here.

[[Korean#^ko-Q0073-answer|Compare the answer]]
^ko-Q0073

**ko-Q0074 · Choose the form**

여긴 거의 ____ 안 와.

It rarely snows here.

Choices: 이 / 은 / 눈이 / 가

[[Korean#^ko-Q0074-answer|Compare the answer]]
^ko-Q0074

**ko-Q0075 · Edit the changed sentence**

그 사람은 진짜 【이】 우주의 중심에 있는 줄 알아.

He really thinks he's the centre of the universe.

[[Korean#^ko-Q0075-answer|Compare the answer]]
^ko-Q0075

**ko-Q0076 · Build the sentence**

Arrange: 그 / 진짜 / 중심에 / 자신이 / 알아. / 있는 / 우주의 / 사람은 / 줄

He really thinks he's the centre of the universe.

[[Korean#^ko-Q0076-answer|Compare the answer]]
^ko-Q0076

**ko-Q0077 · Write a translation**

Write this in Korean: The bag is full.

[[Korean#^ko-Q0077-answer|Compare the answer]]
^ko-Q0077

**ko-Q0078 · Explain the grammar**

【가방이】 꽉 찼습니다.

The bag is full.

[[Korean#^ko-Q0078-answer|Compare the answer]]
^ko-Q0078

**ko-Q0079 · Fill the gap**

우린 ____ 더 필요해.

We needed more money.

[[Korean#^ko-Q0079-answer|Compare the answer]]
^ko-Q0079

**ko-Q0080 · Choose the form**

우린 ____ 더 필요해.

We needed more money.

Choices: 돈이 / 가 / 은 / 이

[[Korean#^ko-Q0080-answer|Compare the answer]]
^ko-Q0080

**ko-Q0081 · Edit the changed sentence**

그 사람은 자신의 【이】 가난하다는 사실을 부끄러워하지 않아.

He’s not ashamed of the fact that his father is poor.

[[Korean#^ko-Q0081-answer|Compare the answer]]
^ko-Q0081

**ko-Q0082 · Build the sentence**

Arrange: 사람은 / 아버지가 / 않아. / 자신의 / 그 / 부끄러워하지 / 가난하다는 / 사실을

He’s not ashamed of the fact that his father is poor.

[[Korean#^ko-Q0082-answer|Compare the answer]]
^ko-Q0082

**ko-Q0083 · Write a translation**

Write this in Korean: Is there a place where I can charge my cellphone around here?

[[Korean#^ko-Q0083-answer|Compare the answer]]
^ko-Q0083

**ko-Q0084 · Explain the grammar**

이 근처에 휴대폰 충전할 수 있는 【곳이】 있나요?

Is there a place where I can charge my cellphone around here?

[[Korean#^ko-Q0084-answer|Compare the answer]]
^ko-Q0084

**ko-Q0085 · Fill the gap**

많은 서양 작곡가들에게 유감스럽게도 스틸 드럼과 스틸 팬 드럼은 완벽한 ____ 아니다.

To the chagrin of many Western composers, steel drums, or steelpans, tend not to be fully chromatic.

[[Korean#^ko-Q0085-answer|Compare the answer]]
^ko-Q0085

**ko-Q0086 · Choose the form**

많은 서양 작곡가들에게 유감스럽게도 스틸 드럼과 스틸 팬 드럼은 완벽한 ____ 아니다.

To the chagrin of many Western composers, steel drums, or steelpans, tend not to be fully chromatic.

Choices: 가 / 이 / 은 / 반음계가

[[Korean#^ko-Q0086-answer|Compare the answer]]
^ko-Q0086

**ko-Q0087 · Edit the changed sentence**

【이】 세계를 여행하는 동안, 항상 잘먹는 것이 가능하지는 않습니다.

It's not always possible to eat well when you're traveling in this part of the world.

[[Korean#^ko-Q0087-answer|Compare the answer]]
^ko-Q0087

**ko-Q0088 · Build the sentence**

Arrange: 항상 / 동안, / 잘먹는 / 가능하지는 / 것이 / 당신이 / 여행하는 / 세계를 / 않습니다.

It's not always possible to eat well when you're traveling in this part of the world.

[[Korean#^ko-Q0088-answer|Compare the answer]]
^ko-Q0088

**ko-Q0089 · Write a translation**

Write this in Korean: I'll find them.

[[Korean#^ko-Q0089-answer|Compare the answer]]
^ko-Q0089

**ko-Q0090 · Explain the grammar**

【내가】 찾아 볼게.

I'll find them.

[[Korean#^ko-Q0090-answer|Compare the answer]]
^ko-Q0090

**ko-Q0091 · Fill the gap**

학생 ____ 있어요?

Is there a student discount?

[[Korean#^ko-Q0091-answer|Compare the answer]]
^ko-Q0091

**ko-Q0092 · Choose the form**

학생 ____ 있어요?

Is there a student discount?

Choices: 할인이 / 은 / 이 / 가

[[Korean#^ko-Q0092-answer|Compare the answer]]
^ko-Q0092

**ko-Q0093 · Edit the changed sentence**

1939년에 제2차 세계 【이】 일어났다.

World war two broke out in 1939.

[[Korean#^ko-Q0093-answer|Compare the answer]]
^ko-Q0093

**ko-Q0094 · Build the sentence**

Arrange: 제2차 / 대전이 / 1939년에 / 일어났다. / 세계

World war two broke out in 1939.

[[Korean#^ko-Q0094-answer|Compare the answer]]
^ko-Q0094

**ko-Q0095 · Write a translation**

Write this in Korean: When was the last time you went canoeing?

[[Korean#^ko-Q0095-answer|Compare the answer]]
^ko-Q0095

**ko-Q0096 · Explain the grammar**

가장 최근에 카누를 탄 【적이】 언제야?

When was the last time you went canoeing?

[[Korean#^ko-Q0096-answer|Compare the answer]]
^ko-Q0096

**ko-Q0097 · Fill the gap**

____ 피를 흘리고 있어.

Mary is losing blood.

[[Korean#^ko-Q0097-answer|Compare the answer]]
^ko-Q0097

**ko-Q0098 · Choose the form**

____ 피를 흘리고 있어.

Mary is losing blood.

Choices: 은 / 이 / 메리가 / 가

[[Korean#^ko-Q0098-answer|Compare the answer]]
^ko-Q0098

**ko-Q0099 · Edit the changed sentence**

내 실수 때문에 내 【이】 싫어.

I hate myself for my mistakes.

[[Korean#^ko-Q0099-answer|Compare the answer]]
^ko-Q0099

**ko-Q0100 · Build the sentence**

Arrange: 내 / 싫어. / 실수 / 자신이 / 내 / 때문에

I hate myself for my mistakes.

[[Korean#^ko-Q0100-answer|Compare the answer]]
^ko-Q0100


### Object 을 and 를 · 50 questions

**ko-Q0101 · Write a translation**

Write this in Korean: Don’t put a pencil in your mouth. You might accidentally stab your palate.

[[Korean#^ko-Q0101-answer|Compare the answer]]
^ko-Q0101

**ko-Q0102 · Explain the grammar**

【연필을】 입에 넣지 마세요, 실수로 입천장을 찌를 수 있습니다.

Don’t put a pencil in your mouth. You might accidentally stab your palate.

[[Korean#^ko-Q0102-answer|Compare the answer]]
^ko-Q0102

**ko-Q0103 · Fill the gap**

몇 ____ 반복해야 해?

How many times do I need to repeat it?

[[Korean#^ko-Q0103-answer|Compare the answer]]
^ko-Q0103

**ko-Q0104 · Choose the form**

몇 ____ 반복해야 해?

How many times do I need to repeat it?

Choices: 에 / 번을 / 를 / 을

[[Korean#^ko-Q0104-answer|Compare the answer]]
^ko-Q0104

**ko-Q0105 · Edit the changed sentence**

그는 【을】 기다리게 했다.

He kept me waiting.

[[Korean#^ko-Q0105-answer|Compare the answer]]
^ko-Q0105

**ko-Q0106 · Build the sentence**

Arrange: 기다리게 / 그는 / 나를 / 했다.

He kept me waiting.

[[Korean#^ko-Q0106-answer|Compare the answer]]
^ko-Q0106

**ko-Q0107 · Write a translation**

Write this in Korean: Tom attempted suicide.

[[Korean#^ko-Q0107-answer|Compare the answer]]
^ko-Q0107

**ko-Q0108 · Explain the grammar**

톰은 【자살을】 시도했다.

Tom attempted suicide.

[[Korean#^ko-Q0108-answer|Compare the answer]]
^ko-Q0108

**ko-Q0109 · Fill the gap**

____ 내버려 두세요!

Leave me in peace!

[[Korean#^ko-Q0109-answer|Compare the answer]]
^ko-Q0109

**ko-Q0110 · Choose the form**

____ 내버려 두세요!

Leave me in peace!

Choices: 저를 / 를 / 에 / 을

[[Korean#^ko-Q0110-answer|Compare the answer]]
^ko-Q0110

**ko-Q0111 · Edit the changed sentence**

나는 한국에 가서 맛있는 【을】 먹고 싶다.

I'm going to Korea and weat to eat good food.

[[Korean#^ko-Q0111-answer|Compare the answer]]
^ko-Q0111

**ko-Q0112 · Build the sentence**

Arrange: 한국에 / 먹고 / 맛있는 / 가서 / 것을 / 나는 / 싶다.

I'm going to Korea and weat to eat good food.

[[Korean#^ko-Q0112-answer|Compare the answer]]
^ko-Q0112

**ko-Q0113 · Write a translation**

Write this in Korean: Tom gave it some thought.

[[Korean#^ko-Q0113-answer|Compare the answer]]
^ko-Q0113

**ko-Q0114 · Explain the grammar**

탐은 이것에 대해 【생각을】 해봤다.

Tom gave it some thought.

[[Korean#^ko-Q0114-answer|Compare the answer]]
^ko-Q0114

**ko-Q0115 · Fill the gap**

새미는 치명적인 ____ 저질렀다.

Sami made a fatal mistake.

[[Korean#^ko-Q0115-answer|Compare the answer]]
^ko-Q0115

**ko-Q0116 · Choose the form**

새미는 치명적인 ____ 저질렀다.

Sami made a fatal mistake.

Choices: 를 / 에 / 을 / 실수를

[[Korean#^ko-Q0116-answer|Compare the answer]]
^ko-Q0116

**ko-Q0117 · Edit the changed sentence**

나는 학생일 때 영어로 【을】 쓰곤 했다.

I used to keep a diary in English when I was a student.

[[Korean#^ko-Q0117-answer|Compare the answer]]
^ko-Q0117

**ko-Q0118 · Build the sentence**

Arrange: 쓰곤 / 했다. / 영어로 / 학생일 / 때 / 일기를 / 나는

I used to keep a diary in English when I was a student.

[[Korean#^ko-Q0118-answer|Compare the answer]]
^ko-Q0118

**ko-Q0119 · Write a translation**

Write this in Korean: Most women dream of a splendid wedding.

[[Korean#^ko-Q0119-answer|Compare the answer]]
^ko-Q0119

**ko-Q0120 · Explain the grammar**

여자들은 대부분 화려한 【결혼식을】 꿈꿔.

Most women dream of a splendid wedding.

[[Korean#^ko-Q0120-answer|Compare the answer]]
^ko-Q0120

**ko-Q0121 · Fill the gap**

저는 남은 ____ 그것에 대해 후회하면서 지내고 싶지 않아요.

I don't want to spend the rest of my life regretting it.

[[Korean#^ko-Q0121-answer|Compare the answer]]
^ko-Q0121

**ko-Q0122 · Choose the form**

저는 남은 ____ 그것에 대해 후회하면서 지내고 싶지 않아요.

I don't want to spend the rest of my life regretting it.

Choices: 에 / 인생을 / 을 / 를

[[Korean#^ko-Q0122-answer|Compare the answer]]
^ko-Q0122

**ko-Q0123 · Edit the changed sentence**

나는 그 【을】 좋아했어.

I loved that book!

[[Korean#^ko-Q0123-answer|Compare the answer]]
^ko-Q0123

**ko-Q0124 · Build the sentence**

Arrange: 그 / 책을 / 좋아했어. / 나는

I loved that book!

[[Korean#^ko-Q0124-answer|Compare the answer]]
^ko-Q0124

**ko-Q0125 · Write a translation**

Write this in Korean: Tom looks shocked.

[[Korean#^ko-Q0125-answer|Compare the answer]]
^ko-Q0125

**ko-Q0126 · Explain the grammar**

톰은 【충격을】 받은 것 같다.

Tom looks shocked.

[[Korean#^ko-Q0126-answer|Compare the answer]]
^ko-Q0126

**ko-Q0127 · Fill the gap**

우리는 ____ 원합니다.

We want peace.

[[Korean#^ko-Q0127-answer|Compare the answer]]
^ko-Q0127

**ko-Q0128 · Choose the form**

우리는 ____ 원합니다.

We want peace.

Choices: 평화를 / 를 / 을 / 에

[[Korean#^ko-Q0128-answer|Compare the answer]]
^ko-Q0128

**ko-Q0129 · Edit the changed sentence**

【을】 어디서 보냈어?

Where did you spend your summer vacation?

[[Korean#^ko-Q0129-answer|Compare the answer]]
^ko-Q0129

**ko-Q0130 · Build the sentence**

Arrange: 어디서 / 여름방학을 / 보냈어?

Where did you spend your summer vacation?

[[Korean#^ko-Q0130-answer|Compare the answer]]
^ko-Q0130

**ko-Q0131 · Write a translation**

Write this in Korean: She knits a wool sweater.

[[Korean#^ko-Q0131-answer|Compare the answer]]
^ko-Q0131

**ko-Q0132 · Explain the grammar**

그녀는 털실로 【스웨터를】 짠다.

She knits a wool sweater.

[[Korean#^ko-Q0132-answer|Compare the answer]]
^ko-Q0132

**ko-Q0133 · Fill the gap**

나는 내년에 ____ 배우고 싶다.

I want to learn Chinese next year.

[[Korean#^ko-Q0133-answer|Compare the answer]]
^ko-Q0133

**ko-Q0134 · Choose the form**

나는 내년에 ____ 배우고 싶다.

I want to learn Chinese next year.

Choices: 에 / 를 / 을 / 중국어를

[[Korean#^ko-Q0134-answer|Compare the answer]]
^ko-Q0134

**ko-Q0135 · Edit the changed sentence**

Emily가 【을】 쓰고 있다.

Emily is writing a letter.

[[Korean#^ko-Q0135-answer|Compare the answer]]
^ko-Q0135

**ko-Q0136 · Build the sentence**

Arrange: 편지를 / Emily가 / 있다. / 쓰고

Emily is writing a letter.

[[Korean#^ko-Q0136-answer|Compare the answer]]
^ko-Q0136

**ko-Q0137 · Write a translation**

Write this in Korean: She was heard to criticize the manager.

[[Korean#^ko-Q0137-answer|Compare the answer]]
^ko-Q0137

**ko-Q0138 · Explain the grammar**

그녀는 【관리자를】 비난했다는 소식을 듣게 되었다.

She was heard to criticize the manager.

[[Korean#^ko-Q0138-answer|Compare the answer]]
^ko-Q0138

**ko-Q0139 · Fill the gap**

나는 톰에게 ____ 요청했다.

I called Tom for help.

[[Korean#^ko-Q0139-answer|Compare the answer]]
^ko-Q0139

**ko-Q0140 · Choose the form**

나는 톰에게 ____ 요청했다.

I called Tom for help.

Choices: 을 / 를 / 에 / 도움을

[[Korean#^ko-Q0140-answer|Compare the answer]]
^ko-Q0140

**ko-Q0141 · Edit the changed sentence**

난 【을】 잊어버리기 시작했어.

I'm beginning to forget my French.

[[Korean#^ko-Q0141-answer|Compare the answer]]
^ko-Q0141

**ko-Q0142 · Build the sentence**

Arrange: 난 / 시작했어. / 잊어버리기 / 프랑스어를

I'm beginning to forget my French.

[[Korean#^ko-Q0142-answer|Compare the answer]]
^ko-Q0142

**ko-Q0143 · Write a translation**

Write this in Korean: Zoos are like prisons for animals.

[[Korean#^ko-Q0143-answer|Compare the answer]]
^ko-Q0143

**ko-Q0144 · Explain the grammar**

동물원은 【동물들을】 위한 감옥 같다.

Zoos are like prisons for animals.

[[Korean#^ko-Q0144-answer|Compare the answer]]
^ko-Q0144

**ko-Q0145 · Fill the gap**

무엇이 ____ 죽였나?

What killed them?

[[Korean#^ko-Q0145-answer|Compare the answer]]
^ko-Q0145

**ko-Q0146 · Choose the form**

무엇이 ____ 죽였나?

What killed them?

Choices: 을 / 에 / 를 / 그들을

[[Korean#^ko-Q0146-answer|Compare the answer]]
^ko-Q0146

**ko-Q0147 · Edit the changed sentence**

【을】 마저 들어보자.

Let's hear the rest of the story.

[[Korean#^ko-Q0147-answer|Compare the answer]]
^ko-Q0147

**ko-Q0148 · Build the sentence**

Arrange: 마저 / 들어보자. / 이야기를

Let's hear the rest of the story.

[[Korean#^ko-Q0148-answer|Compare the answer]]
^ko-Q0148

**ko-Q0149 · Write a translation**

Write this in Korean: Tom says he doesn't think Mary ought to do that.

[[Korean#^ko-Q0149-answer|Compare the answer]]
^ko-Q0149

**ko-Q0150 · Explain the grammar**

톰은 마리가 【그것을】 해야만 한다고 생각하지 않는다고 말했다.

Tom says he doesn't think Mary ought to do that.

[[Korean#^ko-Q0150-answer|Compare the answer]]
^ko-Q0150


### Destination and location 에 · 50 questions

**ko-Q0151 · Fill the gap**

나 오늘밤 너의 ____ 가도 돼?

Can I come to your party tonight?

[[Korean#^ko-Q0151-answer|Compare the answer]]
^ko-Q0151

**ko-Q0152 · Choose the form**

나 오늘밤 너의 ____ 가도 돼?

Can I come to your party tonight?

Choices: 파티에 / 에 / 에서 / 에게

[[Korean#^ko-Q0152-answer|Compare the answer]]
^ko-Q0152

**ko-Q0153 · Edit the changed sentence**

톰은 【에】 앉아 있어.

Tom was sitting in the garden.

[[Korean#^ko-Q0153-answer|Compare the answer]]
^ko-Q0153

**ko-Q0154 · Build the sentence**

Arrange: 톰은 / 있어. / 앉아 / 정원에

Tom was sitting in the garden.

[[Korean#^ko-Q0154-answer|Compare the answer]]
^ko-Q0154

**ko-Q0155 · Write a translation**

Write this in Korean: For the first time in ages, I slept late.

[[Korean#^ko-Q0155-answer|Compare the answer]]
^ko-Q0155

**ko-Q0156 · Explain the grammar**

【오랜만에】 늦게까지 잤는데.

For the first time in ages, I slept late.

[[Korean#^ko-Q0156-answer|Compare the answer]]
^ko-Q0156

**ko-Q0157 · Fill the gap**

아마 오늘 ____ 도착할 거예요.

Maybe he will arrive tonight.

[[Korean#^ko-Q0157-answer|Compare the answer]]
^ko-Q0157

**ko-Q0158 · Choose the form**

아마 오늘 ____ 도착할 거예요.

Maybe he will arrive tonight.

Choices: 에서 / 에게 / 밤에 / 에

[[Korean#^ko-Q0158-answer|Compare the answer]]
^ko-Q0158

**ko-Q0159 · Edit the changed sentence**

【에】 가고 싶어요.

I want to go to Korea.

[[Korean#^ko-Q0159-answer|Compare the answer]]
^ko-Q0159

**ko-Q0160 · Build the sentence**

Arrange: 싶어요. / 한국에 / 가고

I want to go to Korea.

[[Korean#^ko-Q0160-answer|Compare the answer]]
^ko-Q0160

**ko-Q0161 · Write a translation**

Write this in Korean: He lives in peace.

[[Korean#^ko-Q0161-answer|Compare the answer]]
^ko-Q0161

**ko-Q0162 · Explain the grammar**

그는 평화 【속에】 살고 있다.

He lives in peace.

[[Korean#^ko-Q0162-answer|Compare the answer]]
^ko-Q0162

**ko-Q0163 · Fill the gap**

그는 내일 ____ 떠날 예정이다.

He is going to leave tomorrow afternoon.

[[Korean#^ko-Q0163-answer|Compare the answer]]
^ko-Q0163

**ko-Q0164 · Choose the form**

그는 내일 ____ 떠날 예정이다.

He is going to leave tomorrow afternoon.

Choices: 오후에 / 에서 / 에 / 에게

[[Korean#^ko-Q0164-answer|Compare the answer]]
^ko-Q0164

**ko-Q0165 · Edit the changed sentence**

나는 남과 다르게 멋있게 보이고 싶어서 하와이안 티셔츠와 녹색 반바지 입는 걸 좋아했지만, 빠르게 흰색 셔츠와 검정 【에】 익숙해졌다.

I preferred wearing my Hawaiian T-shirt and green shorts to be cool and different, but I quickly got used to the white shirt and black slacks.

[[Korean#^ko-Q0165-answer|Compare the answer]]
^ko-Q0165

**ko-Q0166 · Build the sentence**

Arrange: 입는 / 걸 / 반바지 / 빠르게 / 좋아했지만, / 티셔츠와 / 흰색 / 다르게 / 보이고 / 남과 / 검정 / 하와이안 / 멋있게 / 싶어서 / 바지에 / 셔츠와 / 익숙해졌다. / 녹색 / 나는

I preferred wearing my Hawaiian T-shirt and green shorts to be cool and different, but I quickly got used to the white shirt and black slacks.

[[Korean#^ko-Q0166-answer|Compare the answer]]
^ko-Q0166

**ko-Q0167 · Write a translation**

Write this in Korean: Her eyes welled up with tears.

[[Korean#^ko-Q0167-answer|Compare the answer]]
^ko-Q0167

**ko-Q0168 · Explain the grammar**

그녀의 【눈에】 눈물이 고였다.

Her eyes welled up with tears.

[[Korean#^ko-Q0168-answer|Compare the answer]]
^ko-Q0168

**ko-Q0169 · Fill the gap**

사랑과 우정 ____ 경계선을 긋는 것은 매우 어려운 일이다.

It is very difficult to draw the boundary between love and friendship.

[[Korean#^ko-Q0169-answer|Compare the answer]]
^ko-Q0169

**ko-Q0170 · Choose the form**

사랑과 우정 ____ 경계선을 긋는 것은 매우 어려운 일이다.

It is very difficult to draw the boundary between love and friendship.

Choices: 에게 / 에 / 사이에 / 에서

[[Korean#^ko-Q0170-answer|Compare the answer]]
^ko-Q0170

**ko-Q0171 · Edit the changed sentence**

그는 상자 여섯 개를 한 【에】 날랐다.

He carried six boxes at a time.

[[Korean#^ko-Q0171-answer|Compare the answer]]
^ko-Q0171

**ko-Q0172 · Build the sentence**

Arrange: 상자 / 개를 / 그는 / 여섯 / 한 / 번에 / 날랐다.

He carried six boxes at a time.

[[Korean#^ko-Q0172-answer|Compare the answer]]
^ko-Q0172

**ko-Q0173 · Write a translation**

Write this in Korean: The flower needs watering. The leaves are already wilted.

[[Korean#^ko-Q0173-answer|Compare the answer]]
^ko-Q0173

**ko-Q0174 · Explain the grammar**

【꽃에】 물을 줘야겠다. 잎들이 벌써 시들었다.

The flower needs watering. The leaves are already wilted.

[[Korean#^ko-Q0174-answer|Compare the answer]]
^ko-Q0174

**ko-Q0175 · Fill the gap**

진수 씨가 저를 도와주신 것을 감사하는 뜻으로 ____ 초대하려고 해요.

I wanted to invite Mr. Jinsu this evening to thank him for helping me earlier.

[[Korean#^ko-Q0175-answer|Compare the answer]]
^ko-Q0175

**ko-Q0176 · Choose the form**

진수 씨가 저를 도와주신 것을 감사하는 뜻으로 ____ 초대하려고 해요.

I wanted to invite Mr. Jinsu this evening to thank him for helping me earlier.

Choices: 에게 / 저녁에 / 에서 / 에

[[Korean#^ko-Q0176-answer|Compare the answer]]
^ko-Q0176

**ko-Q0177 · Edit the changed sentence**

우리는 내일 【에】 집을 떠날 것이다.

We'll leave the house tomorrow morning.

[[Korean#^ko-Q0177-answer|Compare the answer]]
^ko-Q0177

**ko-Q0178 · Build the sentence**

Arrange: 떠날 / 것이다. / 우리는 / 집을 / 내일 / 아침에

We'll leave the house tomorrow morning.

[[Korean#^ko-Q0178-answer|Compare the answer]]
^ko-Q0178

**ko-Q0179 · Write a translation**

Write this in Korean: Keep Tom there.

[[Korean#^ko-Q0179-answer|Compare the answer]]
^ko-Q0179

**ko-Q0180 · Explain the grammar**

톰은 【여기에】 두세요.

Keep Tom there.

[[Korean#^ko-Q0180-answer|Compare the answer]]
^ko-Q0180

**ko-Q0181 · Fill the gap**

우리가 ____ 성공하지 못해도 내가 임신할 때까지 계속 섹스할 수 있어.

Even if we don't get lucky on the first try we can just keep fucking till I get pregnant.

[[Korean#^ko-Q0181-answer|Compare the answer]]
^ko-Q0181

**ko-Q0182 · Choose the form**

우리가 ____ 성공하지 못해도 내가 임신할 때까지 계속 섹스할 수 있어.

Even if we don't get lucky on the first try we can just keep fucking till I get pregnant.

Choices: 에게 / 단번에 / 에서 / 에

[[Korean#^ko-Q0182-answer|Compare the answer]]
^ko-Q0182

**ko-Q0183 · Edit the changed sentence**

이 가게 【에】 안들어.

I don't like this store.

[[Korean#^ko-Q0183-answer|Compare the answer]]
^ko-Q0183

**ko-Q0184 · Build the sentence**

Arrange: 이 / 안들어. / 마음에 / 가게

I don't like this store.

[[Korean#^ko-Q0184-answer|Compare the answer]]
^ko-Q0184

**ko-Q0185 · Write a translation**

Write this in Korean: I get chapped lips every winter.

[[Korean#^ko-Q0185-answer|Compare the answer]]
^ko-Q0185

**ko-Q0186 · Explain the grammar**

매년 【겨울에】 내 입술이 튼다.

I get chapped lips every winter.

[[Korean#^ko-Q0186-answer|Compare the answer]]
^ko-Q0186

**ko-Q0187 · Fill the gap**

나는 당신의 ____ 답할 수 없어요.

I can not answer your question.

[[Korean#^ko-Q0187-answer|Compare the answer]]
^ko-Q0187

**ko-Q0188 · Choose the form**

나는 당신의 ____ 답할 수 없어요.

I can not answer your question.

Choices: 질문에 / 에 / 에서 / 에게

[[Korean#^ko-Q0188-answer|Compare the answer]]
^ko-Q0188

**ko-Q0189 · Edit the changed sentence**

수면 부족이 점차 【에】 영향을 미친다.

Lack of sleep can gradually affect health.

[[Korean#^ko-Q0189-answer|Compare the answer]]
^ko-Q0189

**ko-Q0190 · Build the sentence**

Arrange: 영향을 / 수면 / 건강에 / 점차 / 미친다. / 부족이

Lack of sleep can gradually affect health.

[[Korean#^ko-Q0190-answer|Compare the answer]]
^ko-Q0190

**ko-Q0191 · Write a translation**

Write this in Korean: Where did you hide them?

[[Korean#^ko-Q0191-answer|Compare the answer]]
^ko-Q0191

**ko-Q0192 · Explain the grammar**

그걸 【어디에】 숨겼니?

Where did you hide them?

[[Korean#^ko-Q0192-answer|Compare the answer]]
^ko-Q0192

**ko-Q0193 · Fill the gap**

네가 ____ 걸린 적이 없다는 게 사실이야?

Is it true you've never had a serious illness?

[[Korean#^ko-Q0193-answer|Compare the answer]]
^ko-Q0193

**ko-Q0194 · Choose the form**

네가 ____ 걸린 적이 없다는 게 사실이야?

Is it true you've never had a serious illness?

Choices: 중병에 / 에게 / 에 / 에서

[[Korean#^ko-Q0194-answer|Compare the answer]]
^ko-Q0194

**ko-Q0195 · Edit the changed sentence**

나는 여기 온 뒤로 한 번도 【에】 들어가고 싶다는 생각을 안 했지만 지금 이 순간에 어쩐 일인지 옷을 벗어 버리고 싶었어요.

I had not once thought about going into the sea since I came here, but at this moment, for some reason, I wanted to remove my clothes.

[[Korean#^ko-Q0195-answer|Compare the answer]]
^ko-Q0195

**ko-Q0196 · Build the sentence**

Arrange: 뒤로 / 싶었어요. / 여기 / 이 / 버리고 / 바다에 / 순간에 / 생각을 / 옷을 / 벗어 / 싶다는 / 안 / 번도 / 온 / 나는 / 어쩐 / 한 / 했지만 / 일인지 / 지금 / 들어가고

I had not once thought about going into the sea since I came here, but at this moment, for some reason, I wanted to remove my clothes.

[[Korean#^ko-Q0196-answer|Compare the answer]]
^ko-Q0196

**ko-Q0197 · Write a translation**

Write this in Korean: After her first date with Tom, Mary was distracted all day, couldn't concentrate on her classes and didn't feel hungry.

[[Korean#^ko-Q0197-answer|Compare the answer]]
^ko-Q0197

**ko-Q0198 · Explain the grammar**

톰과의 데이트 【후에】 메리는 하루종일 정신이 산란했어, 수업에서 집중도 못하고 배고픔도 느끼지 못했어.

After her first date with Tom, Mary was distracted all day, couldn't concentrate on her classes and didn't feel hungry.

[[Korean#^ko-Q0198-answer|Compare the answer]]
^ko-Q0198

**ko-Q0199 · Fill the gap**

톰은 ____ 대해 솔직했다.

Tom was honest about the problem.

[[Korean#^ko-Q0199-answer|Compare the answer]]
^ko-Q0199

**ko-Q0200 · Choose the form**

톰은 ____ 대해 솔직했다.

Tom was honest about the problem.

Choices: 에서 / 문제에 / 에 / 에게

[[Korean#^ko-Q0200-answer|Compare the answer]]
^ko-Q0200


### Event location and source 에서 · 50 questions

**ko-Q0201 · Edit the changed sentence**

【에서】 살면서 좀 불편한 건 없었어?

Don't you feel any inconvenience living abroad?

[[Korean#^ko-Q0201-answer|Compare the answer]]
^ko-Q0201

**ko-Q0202 · Build the sentence**

Arrange: 불편한 / 건 / 살면서 / 외국에서 / 없었어? / 좀

Don't you feel any inconvenience living abroad?

[[Korean#^ko-Q0202-answer|Compare the answer]]
^ko-Q0202

**ko-Q0203 · Write a translation**

Write this in Korean: Tom and Mary live in a smart home.

[[Korean#^ko-Q0203-answer|Compare the answer]]
^ko-Q0203

**ko-Q0204 · Explain the grammar**

톰과 메리는 스마트 【홈에서】 거주하고 있어요.

Tom and Mary live in a smart home.

[[Korean#^ko-Q0204-answer|Compare the answer]]
^ko-Q0204

**ko-Q0205 · Fill the gap**

나는 이것이 ____ 왔는지 모른다.

I don't know where this came from.

[[Korean#^ko-Q0205-answer|Compare the answer]]
^ko-Q0205

**ko-Q0206 · Choose the form**

나는 이것이 ____ 왔는지 모른다.

I don't know where this came from.

Choices: 어디에서 / 에게 / 에 / 에서

[[Korean#^ko-Q0206-answer|Compare the answer]]
^ko-Q0206

**ko-Q0207 · Edit the changed sentence**

오늘밤 【에서】 쓸 기타좀 빌려줄래?

Would you lend me your guitar to use tonight on stage?

[[Korean#^ko-Q0207-answer|Compare the answer]]
^ko-Q0207

**ko-Q0208 · Build the sentence**

Arrange: 빌려줄래? / 오늘밤 / 쓸 / 무대에서 / 기타좀

Would you lend me your guitar to use tonight on stage?

[[Korean#^ko-Q0208-answer|Compare the answer]]
^ko-Q0208

**ko-Q0209 · Write a translation**

Write this in Korean: Wait for us in the lobby.

[[Korean#^ko-Q0209-answer|Compare the answer]]
^ko-Q0209

**ko-Q0210 · Explain the grammar**

【로비에서】 기다려 주세요.

Wait for us in the lobby.

[[Korean#^ko-Q0210-answer|Compare the answer]]
^ko-Q0210

**ko-Q0211 · Fill the gap**

제가 문학을 공부하는 사람이기 때문에, 영화를 볼 때에 예슬적인 ____ 보게 됩니다.

Because I study literature, I tend to see films from an artistic perspective.

[[Korean#^ko-Q0211-answer|Compare the answer]]
^ko-Q0211

**ko-Q0212 · Choose the form**

제가 문학을 공부하는 사람이기 때문에, 영화를 볼 때에 예슬적인 ____ 보게 됩니다.

Because I study literature, I tend to see films from an artistic perspective.

Choices: 에서 / 측면에서 / 에게 / 에

[[Korean#^ko-Q0212-answer|Compare the answer]]
^ko-Q0212

**ko-Q0213 · Edit the changed sentence**

【에서】 TV나 볼 거예요.

I'll watch TV at home or something.

[[Korean#^ko-Q0213-answer|Compare the answer]]
^ko-Q0213

**ko-Q0214 · Build the sentence**

Arrange: 볼 / TV나 / 거예요. / 집에서

I'll watch TV at home or something.

[[Korean#^ko-Q0214-answer|Compare the answer]]
^ko-Q0214

**ko-Q0215 · Write a translation**

Write this in Korean: We drank soju at the karaoke bar.

[[Korean#^ko-Q0215-answer|Compare the answer]]
^ko-Q0215

**ko-Q0216 · Explain the grammar**

우리들은 【노래방에서】 소주를 마셨어요.

We drank soju at the karaoke bar.

[[Korean#^ko-Q0216-answer|Compare the answer]]
^ko-Q0216

**ko-Q0217 · Fill the gap**

에볼라는 체액을 통하여 ____ 사람으로 전파된다.

Ebola spreads from person to person through bodily fluids.

[[Korean#^ko-Q0217-answer|Compare the answer]]
^ko-Q0217

**ko-Q0218 · Choose the form**

에볼라는 체액을 통하여 ____ 사람으로 전파된다.

Ebola spreads from person to person through bodily fluids.

Choices: 에게 / 사람에서 / 에 / 에서

[[Korean#^ko-Q0218-answer|Compare the answer]]
^ko-Q0218

**ko-Q0219 · Edit the changed sentence**

그 건물은 【에서】 보면 커 보이지만 옆에서 보면 그렇지 않다.

This building looks large from the front, but not from the side.

[[Korean#^ko-Q0219-answer|Compare the answer]]
^ko-Q0219

**ko-Q0220 · Build the sentence**

Arrange: 보면 / 앞에서 / 보이지만 / 않다. / 옆에서 / 보면 / 그렇지 / 커 / 그 / 건물은

This building looks large from the front, but not from the side.

[[Korean#^ko-Q0220-answer|Compare the answer]]
^ko-Q0220

**ko-Q0221 · Write a translation**

Write this in Korean: I rushed out of my house.

[[Korean#^ko-Q0221-answer|Compare the answer]]
^ko-Q0221

**ko-Q0222 · Explain the grammar**

나는 【집에서】 뛰쳐나갔다.

I rushed out of my house.

[[Korean#^ko-Q0222-answer|Compare the answer]]
^ko-Q0222

**ko-Q0223 · Fill the gap**

이 ____ 저희는 여러분들 발음이 좀 더 원어민처럼 들릴 수 있도록 돕는데 시간을 보내겠습니다.

In this course, we'll spend time helping you sound more like a native speaker.

[[Korean#^ko-Q0223-answer|Compare the answer]]
^ko-Q0223

**ko-Q0224 · Choose the form**

이 ____ 저희는 여러분들 발음이 좀 더 원어민처럼 들릴 수 있도록 돕는데 시간을 보내겠습니다.

In this course, we'll spend time helping you sound more like a native speaker.

Choices: 수업에서 / 에 / 에게 / 에서

[[Korean#^ko-Q0224-answer|Compare the answer]]
^ko-Q0224

**ko-Q0225 · Edit the changed sentence**

그 영화가 좋다고 하는 이유는, 예슬적인 【에서】 내용뿐만 아니라, 음악도 좋기 때문이에요.

The reason I'm saying this movie is good is that, not only is the artistic content good, the music is too.

[[Korean#^ko-Q0225-answer|Compare the answer]]
^ko-Q0225

**ko-Q0226 · Build the sentence**

Arrange: 측면에서 / 내용뿐만 / 예슬적인 / 이유는, / 아니라, / 음악도 / 영화가 / 때문이에요. / 하는 / 좋기 / 그 / 좋다고

The reason I'm saying this movie is good is that, not only is the artistic content good, the music is too.

[[Korean#^ko-Q0226-answer|Compare the answer]]
^ko-Q0226

**ko-Q0227 · Write a translation**

Write this in Korean: I found a French friend in Morocco. She told me that the atmosphere in Paris is not that of the rest of France, and that other cities and provinces are very beautiful.

[[Korean#^ko-Q0227-answer|Compare the answer]]
^ko-Q0227

**ko-Q0228 · Explain the grammar**

내가 【모로코에서】 만난 프랑스 친구가 나에게 빠리의 공기(분위기)가 프랑스의 전부를 나타내는 것이 아니며, 다른 도시들과 시골이 아주 아름답다고 말했다.

I found a French friend in Morocco. She told me that the atmosphere in Paris is not that of the rest of France, and that other cities and provinces are very beautiful.

[[Korean#^ko-Q0228-answer|Compare the answer]]
^ko-Q0228

**ko-Q0229 · Fill the gap**

나는 톰의 ____ 통화한다.

I called from Tom's house.

[[Korean#^ko-Q0229-answer|Compare the answer]]
^ko-Q0229

**ko-Q0230 · Choose the form**

나는 톰의 ____ 통화한다.

I called from Tom's house.

Choices: 에게 / 집에서 / 에 / 에서

[[Korean#^ko-Q0230-answer|Compare the answer]]
^ko-Q0230

**ko-Q0231 · Edit the changed sentence**

나는 【에서】 일해.

I work at a zoo.

[[Korean#^ko-Q0231-answer|Compare the answer]]
^ko-Q0231

**ko-Q0232 · Build the sentence**

Arrange: 동물원에서 / 일해. / 나는

I work at a zoo.

[[Korean#^ko-Q0232-answer|Compare the answer]]
^ko-Q0232

**ko-Q0233 · Write a translation**

Write this in Korean: She is always at the bottom of the class.

[[Korean#^ko-Q0233-answer|Compare the answer]]
^ko-Q0233

**ko-Q0234 · Explain the grammar**

그녀는 항상 【반에서】 꼴찌입니다.

She is always at the bottom of the class.

[[Korean#^ko-Q0234-answer|Compare the answer]]
^ko-Q0234

**ko-Q0235 · Fill the gap**

톰은 ____ 기절했다.

Tom is passed out in bed.

[[Korean#^ko-Q0235-answer|Compare the answer]]
^ko-Q0235

**ko-Q0236 · Choose the form**

톰은 ____ 기절했다.

Tom is passed out in bed.

Choices: 에게 / 에 / 침대에서 / 에서

[[Korean#^ko-Q0236-answer|Compare the answer]]
^ko-Q0236

**ko-Q0237 · Edit the changed sentence**

인간은 【에서】 기원했다.

Humans originated in Africa.

[[Korean#^ko-Q0237-answer|Compare the answer]]
^ko-Q0237

**ko-Q0238 · Build the sentence**

Arrange: 아프리카에서 / 기원했다. / 인간은

Humans originated in Africa.

[[Korean#^ko-Q0238-answer|Compare the answer]]
^ko-Q0238

**ko-Q0239 · Write a translation**

Write this in Korean: Tom is spending more and more time in Boston.

[[Korean#^ko-Q0239-answer|Compare the answer]]
^ko-Q0239

**ko-Q0240 · Explain the grammar**

톰은 점점 많은 시간을 【보스턴에서】 보내고 있어.

Tom is spending more and more time in Boston.

[[Korean#^ko-Q0240-answer|Compare the answer]]
^ko-Q0240

**ko-Q0241 · Fill the gap**

아이들은 ____ 모래로 성을 쌓고 있다.

Kids are building sand castles on the beach.

[[Korean#^ko-Q0241-answer|Compare the answer]]
^ko-Q0241

**ko-Q0242 · Choose the form**

아이들은 ____ 모래로 성을 쌓고 있다.

Kids are building sand castles on the beach.

Choices: 에 / 에게 / 바닷가에서 / 에서

[[Korean#^ko-Q0242-answer|Compare the answer]]
^ko-Q0242

**ko-Q0243 · Edit the changed sentence**

톰은 남은 인생을 【에서】 보내고 싶어하지 않아.

Tom doesn't want to spend the rest of his life in prison.

[[Korean#^ko-Q0243-answer|Compare the answer]]
^ko-Q0243

**ko-Q0244 · Build the sentence**

Arrange: 보내고 / 인생을 / 톰은 / 싶어하지 / 남은 / 감옥에서 / 않아.

Tom doesn't want to spend the rest of his life in prison.

[[Korean#^ko-Q0244-answer|Compare the answer]]
^ko-Q0244

**ko-Q0245 · Write a translation**

Write this in Korean: I met Tom outside.

[[Korean#^ko-Q0245-answer|Compare the answer]]
^ko-Q0245

**ko-Q0246 · Explain the grammar**

난 톰을 【밖에서】 봤어.

I met Tom outside.

[[Korean#^ko-Q0246-answer|Compare the answer]]
^ko-Q0246

**ko-Q0247 · Fill the gap**

"룩"이란 단어는 ____ 유래했고, "마차"란 뜻이야.

The word "rook" comes from Sanskrit and means "chariot".

[[Korean#^ko-Q0247-answer|Compare the answer]]
^ko-Q0247

**ko-Q0248 · Choose the form**

"룩"이란 단어는 ____ 유래했고, "마차"란 뜻이야.

The word "rook" comes from Sanskrit and means "chariot".

Choices: 에 / 에게 / 에서 / 산스크리트어에서

[[Korean#^ko-Q0248-answer|Compare the answer]]
^ko-Q0248

**ko-Q0249 · Edit the changed sentence**

나에게는 나의 4자녀가 언젠가는 그들의 피부색이 아닌 그들의 인격으로 평가받는 【에서】 살게 될 것이라는 꿈이 있다.

I have a dream that my four little children will one day live in a nation where they will not be judged by the color of their skin, but by the content of their character.

[[Korean#^ko-Q0249-answer|Compare the answer]]
^ko-Q0249

**ko-Q0250 · Build the sentence**

Arrange: 나의 / 그들의 / 4자녀가 / 있다. / 꿈이 / 나에게는 / 피부색이 / 언젠가는 / 그들의 / 것이라는 / 살게 / 인격으로 / 아닌 / 될 / 나라에서 / 평가받는

I have a dream that my four little children will one day live in a nation where they will not be judged by the color of their skin, but by the content of their character.

[[Korean#^ko-Q0250-answer|Compare the answer]]
^ko-Q0250


### Recipient markers · 50 questions

**ko-Q0251 · Write a translation**

Write this in Korean: She said that a good gin and tonic is like summertime in a glass, and it struck me as being too true.

[[Korean#^ko-Q0251-answer|Compare the answer]]
^ko-Q0251

**ko-Q0252 · Explain the grammar**

그녀는 고급 진과 토닉 한 잔은 여름과도 같다고 했다, 그리고 그것은 【나에게】 진실함을 느끼게 해주었다.

She said that a good gin and tonic is like summertime in a glass, and it struck me as being too true.

[[Korean#^ko-Q0252-answer|Compare the answer]]
^ko-Q0252

**ko-Q0253 · Fill the gap**

난 ____ 답장했어.

I texted Tom back.

[[Korean#^ko-Q0253-answer|Compare the answer]]
^ko-Q0253

**ko-Q0254 · Choose the form**

난 ____ 답장했어.

I texted Tom back.

Choices: 께 / 에게 / 한테 / 톰한테

[[Korean#^ko-Q0254-answer|Compare the answer]]
^ko-Q0254

**ko-Q0255 · Edit the changed sentence**

내가 이 것을 【에게】 줄거야.

I'll give this to Tom.

[[Korean#^ko-Q0255-answer|Compare the answer]]
^ko-Q0255

**ko-Q0256 · Build the sentence**

Arrange: 것을 / 줄거야. / 톰에게 / 내가 / 이

I'll give this to Tom.

[[Korean#^ko-Q0256-answer|Compare the answer]]
^ko-Q0256

**ko-Q0257 · Write a translation**

Write this in Korean: We can count on her.

[[Korean#^ko-Q0257-answer|Compare the answer]]
^ko-Q0257

**ko-Q0258 · Explain the grammar**

【그녀에게】 기대하면 돼요.

We can count on her.

[[Korean#^ko-Q0258-answer|Compare the answer]]
^ko-Q0258

**ko-Q0259 · Fill the gap**

톰은 ____ 고기를 먹은 적이 한 번도 없다고 했다.

Tom told his friends that he never ate meat.

[[Korean#^ko-Q0259-answer|Compare the answer]]
^ko-Q0259

**ko-Q0260 · Choose the form**

톰은 ____ 고기를 먹은 적이 한 번도 없다고 했다.

Tom told his friends that he never ate meat.

Choices: 께 / 에게 / 친구들에게 / 한테

[[Korean#^ko-Q0260-answer|Compare the answer]]
^ko-Q0260

**ko-Q0261 · Edit the changed sentence**

【에게】 해당되는 할인 티켓은 없나요?

Are there any discount tickets for me?

[[Korean#^ko-Q0261-answer|Compare the answer]]
^ko-Q0261

**ko-Q0262 · Build the sentence**

Arrange: 티켓은 / 저에게 / 할인 / 해당되는 / 없나요?

Are there any discount tickets for me?

[[Korean#^ko-Q0262-answer|Compare the answer]]
^ko-Q0262

**ko-Q0263 · Write a translation**

Write this in Korean: You'd better not tell him.

[[Korean#^ko-Q0263-answer|Compare the answer]]
^ko-Q0263

**ko-Q0264 · Explain the grammar**

【그에게】 말하지 않는게 좋을걸.

You'd better not tell him.

[[Korean#^ko-Q0264-answer|Compare the answer]]
^ko-Q0264

**ko-Q0265 · Fill the gap**

그는 ____ 그 책은 재미있다고 했어요.

He told me that the book was interesting.

[[Korean#^ko-Q0265-answer|Compare the answer]]
^ko-Q0265

**ko-Q0266 · Choose the form**

그는 ____ 그 책은 재미있다고 했어요.

He told me that the book was interesting.

Choices: 한테 / 에게 / 나에게 / 께

[[Korean#^ko-Q0266-answer|Compare the answer]]
^ko-Q0266

**ko-Q0267 · Edit the changed sentence**

답장을 아직도 못 받아서 혹시 내 우편물이 【에게】 배달되지 않은 건지 궁금했다.

Since I haven't received an answer, I was wondering if maybe my mail never got delivered to you.

[[Korean#^ko-Q0267-answer|Compare the answer]]
^ko-Q0267

**ko-Q0268 · Build the sentence**

Arrange: 내 / 못 / 궁금했다. / 우편물이 / 답장을 / 받아서 / 않은 / 배달되지 / 너한테 / 건지 / 혹시 / 아직도

Since I haven't received an answer, I was wondering if maybe my mail never got delivered to you.

[[Korean#^ko-Q0268-answer|Compare the answer]]
^ko-Q0268

**ko-Q0269 · Write a translation**

Write this in Korean: I find the food here to be a little too spicy for me.

[[Korean#^ko-Q0269-answer|Compare the answer]]
^ko-Q0269

**ko-Q0270 · Explain the grammar**

여기 음식이 【나한테】 좀 많이 매운 것 같아.

I find the food here to be a little too spicy for me.

[[Korean#^ko-Q0270-answer|Compare the answer]]
^ko-Q0270

**ko-Q0271 · Fill the gap**

톰은 자기 ____ 벌을 줬다.

Tom punished his children.

[[Korean#^ko-Q0271-answer|Compare the answer]]
^ko-Q0271

**ko-Q0272 · Choose the form**

톰은 자기 ____ 벌을 줬다.

Tom punished his children.

Choices: 아이들에게 / 에게 / 께 / 한테

[[Korean#^ko-Q0272-answer|Compare the answer]]
^ko-Q0272

**ko-Q0273 · Edit the changed sentence**

【에게】 더는 하지 말라고 부탁했다.

I asked Tom not to do that anymore.

[[Korean#^ko-Q0273-answer|Compare the answer]]
^ko-Q0273

**ko-Q0274 · Build the sentence**

Arrange: 말라고 / 하지 / 부탁했다. / 톰에게 / 더는

I asked Tom not to do that anymore.

[[Korean#^ko-Q0274-answer|Compare the answer]]
^ko-Q0274

**ko-Q0275 · Write a translation**

Write this in Korean: I told Tom to lie.

[[Korean#^ko-Q0275-answer|Compare the answer]]
^ko-Q0275

**ko-Q0276 · Explain the grammar**

난 【톰한테】 거짓말 하라고 말했어.

I told Tom to lie.

[[Korean#^ko-Q0276-answer|Compare the answer]]
^ko-Q0276

**ko-Q0277 · Fill the gap**

이 뉴스는 ____ 중요하다.

This news is important to us.

[[Korean#^ko-Q0277-answer|Compare the answer]]
^ko-Q0277

**ko-Q0278 · Choose the form**

이 뉴스는 ____ 중요하다.

This news is important to us.

Choices: 우리에게 / 한테 / 께 / 에게

[[Korean#^ko-Q0278-answer|Compare the answer]]
^ko-Q0278

**ko-Q0279 · Edit the changed sentence**

톰은 【에게】 베개를 던져서 정확히 얼굴을 맞았다.

Tom threw a pillow at Mary and the pillow hit her squarely in the face.

[[Korean#^ko-Q0279-answer|Compare the answer]]
^ko-Q0279

**ko-Q0280 · Build the sentence**

Arrange: 던져서 / 톰은 / 메리에게 / 얼굴을 / 정확히 / 베개를 / 맞았다.

Tom threw a pillow at Mary and the pillow hit her squarely in the face.

[[Korean#^ko-Q0280-answer|Compare the answer]]
^ko-Q0280

**ko-Q0281 · Write a translation**

Write this in Korean: Could you loan me some money until payday?

[[Korean#^ko-Q0281-answer|Compare the answer]]
^ko-Q0281

**ko-Q0282 · Explain the grammar**

월급날까지 【나한테】 돈 좀 빌려줄 수 있어?

Could you loan me some money until payday?

[[Korean#^ko-Q0282-answer|Compare the answer]]
^ko-Q0282

**ko-Q0283 · Fill the gap**

____ 하실 말씀이 있으신가요?

Is there something that you wish to tell me?

[[Korean#^ko-Q0283-answer|Compare the answer]]
^ko-Q0283

**ko-Q0284 · Choose the form**

____ 하실 말씀이 있으신가요?

Is there something that you wish to tell me?

Choices: 께 / 에게 / 한테 / 저한테

[[Korean#^ko-Q0284-answer|Compare the answer]]
^ko-Q0284

**ko-Q0285 · Edit the changed sentence**

그는 【에게】 음식에 대한 불평을 했다.

He complained to her about the food.

[[Korean#^ko-Q0285-answer|Compare the answer]]
^ko-Q0285

**ko-Q0286 · Build the sentence**

Arrange: 불평을 / 그녀에게 / 그는 / 했다. / 대한 / 음식에

He complained to her about the food.

[[Korean#^ko-Q0286-answer|Compare the answer]]
^ko-Q0286

**ko-Q0287 · Write a translation**

Write this in Korean: I need to warn Tom.

[[Korean#^ko-Q0287-answer|Compare the answer]]
^ko-Q0287

**ko-Q0288 · Explain the grammar**

나는 【톰에게】 경고해야 해.

I need to warn Tom.

[[Korean#^ko-Q0288-answer|Compare the answer]]
^ko-Q0288

**ko-Q0289 · Fill the gap**

네가 어제 ____ 말했지?

You talked to Tom yesterday, didn't you?

[[Korean#^ko-Q0289-answer|Compare the answer]]
^ko-Q0289

**ko-Q0290 · Choose the form**

네가 어제 ____ 말했지?

You talked to Tom yesterday, didn't you?

Choices: 한테 / 에게 / 톰에게 / 께

[[Korean#^ko-Q0290-answer|Compare the answer]]
^ko-Q0290

**ko-Q0291 · Edit the changed sentence**

양치기로 사는 건 【에게】 맞지 않는 일이다.

I was not made for the life of a shepherd.

[[Korean#^ko-Q0291-answer|Compare the answer]]
^ko-Q0291

**ko-Q0292 · Build the sentence**

Arrange: 나에게 / 건 / 맞지 / 않는 / 사는 / 일이다. / 양치기로

I was not made for the life of a shepherd.

[[Korean#^ko-Q0292-answer|Compare the answer]]
^ko-Q0292

**ko-Q0293 · Write a translation**

Write this in Korean: I wanted to phone you, but I thought you wouldn't get it so I didn't phone you in the end.

[[Korean#^ko-Q0293-answer|Compare the answer]]
^ko-Q0293

**ko-Q0294 · Explain the grammar**

【너에게】 전화를 걸고 싶었는데, 너가 안 받을까봐 결국 전화 못했어.

I wanted to phone you, but I thought you wouldn't get it so I didn't phone you in the end.

[[Korean#^ko-Q0294-answer|Compare the answer]]
^ko-Q0294

**ko-Q0295 · Fill the gap**

뭐든 잘 이해안되는게 생기면 ____ 와.

If anything comes up that you don't understand, come to me.

[[Korean#^ko-Q0295-answer|Compare the answer]]
^ko-Q0295

**ko-Q0296 · Choose the form**

뭐든 잘 이해안되는게 생기면 ____ 와.

If anything comes up that you don't understand, come to me.

Choices: 나한테 / 한테 / 께 / 에게

[[Korean#^ko-Q0296-answer|Compare the answer]]
^ko-Q0296

**ko-Q0297 · Edit the changed sentence**

그 사람은 【에게】 그런 얘기는 안 했어.

She didn't tell us about that.

[[Korean#^ko-Q0297-answer|Compare the answer]]
^ko-Q0297

**ko-Q0298 · Build the sentence**

Arrange: 우리한테 / 안 / 그런 / 얘기는 / 그 / 사람은 / 했어.

She didn't tell us about that.

[[Korean#^ko-Q0298-answer|Compare the answer]]
^ko-Q0298

**ko-Q0299 · Write a translation**

Write this in Korean: There is a good chance of him having a girlfriend.

[[Korean#^ko-Q0299-answer|Compare the answer]]
^ko-Q0299

**ko-Q0300 · Explain the grammar**

【그에게】 여자친구가 있다는 것은 아주 가능성이 높아요.

There is a good chance of him having a girlfriend.

[[Korean#^ko-Q0300-answer|Compare the answer]]
^ko-Q0300


### Possession 의 · 50 questions

**ko-Q0301 · Fill the gap**

톰은 이 ____ 개척자야.

Tom is a pioneer in this field.

[[Korean#^ko-Q0301-answer|Compare the answer]]
^ko-Q0301

**ko-Q0302 · Choose the form**

톰은 이 ____ 개척자야.

Tom is a pioneer in this field.

Choices: 이 / 분야의 / 의 / 에

[[Korean#^ko-Q0302-answer|Compare the answer]]
^ko-Q0302

**ko-Q0303 · Edit the changed sentence**

독서는 더 이상 【의】 전유물이 아니게 되었다.

Reading books ceased to be a privilege of a minority.

[[Korean#^ko-Q0303-answer|Compare the answer]]
^ko-Q0303

**ko-Q0304 · Build the sentence**

Arrange: 독서는 / 아니게 / 되었다. / 전유물이 / 더 / 이상 / 소수의

Reading books ceased to be a privilege of a minority.

[[Korean#^ko-Q0304-answer|Compare the answer]]
^ko-Q0304

**ko-Q0305 · Write a translation**

Write this in Korean: What kind of work do you do?

[[Korean#^ko-Q0305-answer|Compare the answer]]
^ko-Q0305

**ko-Q0306 · Explain the grammar**

어떤 【종류의】 일을 하세요?

What kind of work do you do?

[[Korean#^ko-Q0306-answer|Compare the answer]]
^ko-Q0306

**ko-Q0307 · Fill the gap**

그게 내가 하고 있는 ____ 전부야.

That's all I'm doing.

[[Korean#^ko-Q0307-answer|Compare the answer]]
^ko-Q0307

**ko-Q0308 · Choose the form**

그게 내가 하고 있는 ____ 전부야.

That's all I'm doing.

Choices: 의 / 에 / 것의 / 이

[[Korean#^ko-Q0308-answer|Compare the answer]]
^ko-Q0308

**ko-Q0309 · Edit the changed sentence**

서울은 【의】 도시다.

Seoul is the capitаl of South Korea.

[[Korean#^ko-Q0309-answer|Compare the answer]]
^ko-Q0309

**ko-Q0310 · Build the sentence**

Arrange: 남한의 / 도시다. / 서울은

Seoul is the capitаl of South Korea.

[[Korean#^ko-Q0310-answer|Compare the answer]]
^ko-Q0310

**ko-Q0311 · Write a translation**

Write this in Korean: What is the capital of Haiti?

[[Korean#^ko-Q0311-answer|Compare the answer]]
^ko-Q0311

**ko-Q0312 · Explain the grammar**

【아이티의】 수도는 이름이 무엇입니까?

What is the capital of Haiti?

[[Korean#^ko-Q0312-answer|Compare the answer]]
^ko-Q0312

**ko-Q0313 · Fill the gap**

그림은 ____ 책이다.

Images are the books of the illiterate.

[[Korean#^ko-Q0313-answer|Compare the answer]]
^ko-Q0313

**ko-Q0314 · Choose the form**

그림은 ____ 책이다.

Images are the books of the illiterate.

Choices: 에 / 문맹자의 / 의 / 이

[[Korean#^ko-Q0314-answer|Compare the answer]]
^ko-Q0314

**ko-Q0315 · Edit the changed sentence**

【의】 부피를 어떻게 계산합니까?

How do you calculate the volume of a cube?

[[Korean#^ko-Q0315-answer|Compare the answer]]
^ko-Q0315

**ko-Q0316 · Build the sentence**

Arrange: 어떻게 / 정육면체의 / 계산합니까? / 부피를

How do you calculate the volume of a cube?

[[Korean#^ko-Q0316-answer|Compare the answer]]
^ko-Q0316

**ko-Q0317 · Write a translation**

Write this in Korean: The world is a den of crazies.

[[Korean#^ko-Q0317-answer|Compare the answer]]
^ko-Q0317

**ko-Q0318 · Explain the grammar**

이 세상은 【미치광이들의】 소굴이다

The world is a den of crazies.

[[Korean#^ko-Q0318-answer|Compare the answer]]
^ko-Q0318

**ko-Q0319 · Fill the gap**

____ 인구는 60억 이상이야.

There are more than six billion people in the world.

[[Korean#^ko-Q0319-answer|Compare the answer]]
^ko-Q0319

**ko-Q0320 · Choose the form**

____ 인구는 60억 이상이야.

There are more than six billion people in the world.

Choices: 에 / 의 / 지구상의 / 이

[[Korean#^ko-Q0320-answer|Compare the answer]]
^ko-Q0320

**ko-Q0321 · Edit the changed sentence**

나는 【의】 역사에 관한 책을 찾고 있다.

I'm looking for books on Roman history.

[[Korean#^ko-Q0321-answer|Compare the answer]]
^ko-Q0321

**ko-Q0322 · Build the sentence**

Arrange: 나는 / 역사에 / 관한 / 로마의 / 찾고 / 책을 / 있다.

I'm looking for books on Roman history.

[[Korean#^ko-Q0322-answer|Compare the answer]]
^ko-Q0322

**ko-Q0323 · Write a translation**

Write this in Korean: Avocados are the fruit of the avocado tree.

[[Korean#^ko-Q0323-answer|Compare the answer]]
^ko-Q0323

**ko-Q0324 · Explain the grammar**

아보카도는 아보카도 【나무의】 열매입니다.

Avocados are the fruit of the avocado tree.

[[Korean#^ko-Q0324-answer|Compare the answer]]
^ko-Q0324

**ko-Q0325 · Fill the gap**

미국 성인은 약 65퍼센트가 비만이고 그건 ____ 건강에 좋지 않다.

About 65% of American adults are overweight, which isn't good for their health.

[[Korean#^ko-Q0325-answer|Compare the answer]]
^ko-Q0325

**ko-Q0326 · Choose the form**

미국 성인은 약 65퍼센트가 비만이고 그건 ____ 건강에 좋지 않다.

About 65% of American adults are overweight, which isn't good for their health.

Choices: 의 / 이 / 에 / 그들의

[[Korean#^ko-Q0326-answer|Compare the answer]]
^ko-Q0326

**ko-Q0327 · Edit the changed sentence**

【의】 음식 솜씨가 훌륭하다.

Susan is a good cook.

[[Korean#^ko-Q0327-answer|Compare the answer]]
^ko-Q0327

**ko-Q0328 · Build the sentence**

Arrange: 음식 / 훌륭하다. / 솜씨가 / 수잔의

Susan is a good cook.

[[Korean#^ko-Q0328-answer|Compare the answer]]
^ko-Q0328

**ko-Q0329 · Write a translation**

Write this in Korean: The music is in balance with the structure of the movie.

[[Korean#^ko-Q0329-answer|Compare the answer]]
^ko-Q0329

**ko-Q0330 · Explain the grammar**

음악과 【영화의】 구조가 조화를 이루고 있어요.

The music is in balance with the structure of the movie.

[[Korean#^ko-Q0330-answer|Compare the answer]]
^ko-Q0330

**ko-Q0331 · Fill the gap**

이 ____ 지붕은 초록색이야.

This building has a green roof.

[[Korean#^ko-Q0331-answer|Compare the answer]]
^ko-Q0331

**ko-Q0332 · Choose the form**

이 ____ 지붕은 초록색이야.

This building has a green roof.

Choices: 에 / 의 / 이 / 건물의

[[Korean#^ko-Q0332-answer|Compare the answer]]
^ko-Q0332

**ko-Q0333 · Edit the changed sentence**

새미는 두 어린 【의】 아버지이다.

Sami is the father of two young children.

[[Korean#^ko-Q0333-answer|Compare the answer]]
^ko-Q0333

**ko-Q0334 · Build the sentence**

Arrange: 두 / 어린 / 아이의 / 새미는 / 아버지이다.

Sami is the father of two young children.

[[Korean#^ko-Q0334-answer|Compare the answer]]
^ko-Q0334

**ko-Q0335 · Write a translation**

Write this in Korean: Here it really feels today like summer has ended.

[[Korean#^ko-Q0335-answer|Compare the answer]]
^ko-Q0335

**ko-Q0336 · Explain the grammar**

여긴 오늘 꼭 【여름의】 끝인 느낌이 난다.

Here it really feels today like summer has ended.

[[Korean#^ko-Q0336-answer|Compare the answer]]
^ko-Q0336

**ko-Q0337 · Fill the gap**

모든 인간은 태어날 때부터 자유로우며 그 존엄과 권리에 있어 동등하다. 인간은 천부적으로 이성과 양심을 부여받았으며 서로 ____ 정신으로 행동하여야 한다.

All human beings are born free and equal in dignity and rights. They are endowed with reason and conscience and should act towards one another in a spirit of brotherhood.

[[Korean#^ko-Q0337-answer|Compare the answer]]
^ko-Q0337

**ko-Q0338 · Choose the form**

모든 인간은 태어날 때부터 자유로우며 그 존엄과 권리에 있어 동등하다. 인간은 천부적으로 이성과 양심을 부여받았으며 서로 ____ 정신으로 행동하여야 한다.

All human beings are born free and equal in dignity and rights. They are endowed with reason and conscience and should act towards one another in a spirit of brotherhood.

Choices: 이 / 의 / 에 / 형제애의

[[Korean#^ko-Q0338-answer|Compare the answer]]
^ko-Q0338

**ko-Q0339 · Edit the changed sentence**

그는 【의】 성공을 그가 열심히 일한것에 대해 공을 돌렸다

He attributes his success to hard work.

[[Korean#^ko-Q0339-answer|Compare the answer]]
^ko-Q0339

**ko-Q0340 · Build the sentence**

Arrange: 열심히 / 공을 / 성공을 / 그의 / 돌렸다 / 대해 / 일한것에 / 그가 / 그는

He attributes his success to hard work.

[[Korean#^ko-Q0340-answer|Compare the answer]]
^ko-Q0340

**ko-Q0341 · Write a translation**

Write this in Korean: That's my goal today.

[[Korean#^ko-Q0341-answer|Compare the answer]]
^ko-Q0341

**ko-Q0342 · Explain the grammar**

그게 내 【오늘의】 목표야.

That's my goal today.

[[Korean#^ko-Q0342-answer|Compare the answer]]
^ko-Q0342

**ko-Q0343 · Fill the gap**

톰은 ____ 변화를 눈치챘다.

Tom noticed a change in Mary.

[[Korean#^ko-Q0343-answer|Compare the answer]]
^ko-Q0343

**ko-Q0344 · Choose the form**

톰은 ____ 변화를 눈치챘다.

Tom noticed a change in Mary.

Choices: 에 / 메리의 / 의 / 이

[[Korean#^ko-Q0344-answer|Compare the answer]]
^ko-Q0344

**ko-Q0345 · Edit the changed sentence**

당신은 【의】 어머니를 사랑합니까?

Do you love your mother?

[[Korean#^ko-Q0345-answer|Compare the answer]]
^ko-Q0345

**ko-Q0346 · Build the sentence**

Arrange: 어머니를 / 당신의 / 사랑합니까? / 당신은

Do you love your mother?

[[Korean#^ko-Q0346-answer|Compare the answer]]
^ko-Q0346

**ko-Q0347 · Write a translation**

Write this in Korean: This is my computer.

[[Korean#^ko-Q0347-answer|Compare the answer]]
^ko-Q0347

**ko-Q0348 · Explain the grammar**

이건 【저의】 컴퓨터예요.

This is my computer.

[[Korean#^ko-Q0348-answer|Compare the answer]]
^ko-Q0348

**ko-Q0349 · Fill the gap**

난 ____ 제안에 전적으로 동의한다.

I'm all for your suggestion.

[[Korean#^ko-Q0349-answer|Compare the answer]]
^ko-Q0349

**ko-Q0350 · Choose the form**

난 ____ 제안에 전적으로 동의한다.

I'm all for your suggestion.

Choices: 에 / 이 / 의 / 너의

[[Korean#^ko-Q0350-answer|Compare the answer]]
^ko-Q0350


### Inclusion 도 · 50 questions

**ko-Q0351 · Edit the changed sentence**

선물은 【도】 포장 상태야.

The gift was still wrapped.

[[Korean#^ko-Q0351-answer|Compare the answer]]
^ko-Q0351

**ko-Q0352 · Build the sentence**

Arrange: 포장 / 아직도 / 상태야. / 선물은

The gift was still wrapped.

[[Korean#^ko-Q0352-answer|Compare the answer]]
^ko-Q0352

**ko-Q0353 · Write a translation**

Write this in Korean: She is more beautiful than any other girl.

[[Korean#^ko-Q0353-answer|Compare the answer]]
^ko-Q0353

**ko-Q0354 · Explain the grammar**

그녀는 【누구보다도】 아름다워요.

She is more beautiful than any other girl.

[[Korean#^ko-Q0354-answer|Compare the answer]]
^ko-Q0354

**ko-Q0355 · Fill the gap**

여기는 이주 전부터 비가 ____ 오지 않았다.

There has been no rain here for the past two weeks.

[[Korean#^ko-Q0355-answer|Compare the answer]]
^ko-Q0355

**ko-Q0356 · Choose the form**

여기는 이주 전부터 비가 ____ 오지 않았다.

There has been no rain here for the past two weeks.

Choices: 하나도 / 만 / 는 / 도

[[Korean#^ko-Q0356-answer|Compare the answer]]
^ko-Q0356

**ko-Q0357 · Edit the changed sentence**

무료로 받을 【도】 있어.

You may get it free of charge.

[[Korean#^ko-Q0357-answer|Compare the answer]]
^ko-Q0357

**ko-Q0358 · Build the sentence**

Arrange: 수도 / 받을 / 있어. / 무료로

You may get it free of charge.

[[Korean#^ko-Q0358-answer|Compare the answer]]
^ko-Q0358

**ko-Q0359 · Write a translation**

Write this in Korean: Talk of the devil and he'll appear.

[[Korean#^ko-Q0359-answer|Compare the answer]]
^ko-Q0359

**ko-Q0360 · Explain the grammar**

【호랑이도】 제 말을 하면 온다.

Talk of the devil and he'll appear.

[[Korean#^ko-Q0360-answer|Compare the answer]]
^ko-Q0360

**ko-Q0361 · Fill the gap**

웃음이 ____ 해요.

Sometimes I laugh.

[[Korean#^ko-Q0361-answer|Compare the answer]]
^ko-Q0361

**ko-Q0362 · Choose the form**

웃음이 ____ 해요.

Sometimes I laugh.

Choices: 는 / 만 / 나오기도 / 도

[[Korean#^ko-Q0362-answer|Compare the answer]]
^ko-Q0362

**ko-Q0363 · Edit the changed sentence**

난 【도】 안 좋아해.

I don't like cookies, either.

[[Korean#^ko-Q0363-answer|Compare the answer]]
^ko-Q0363

**ko-Q0364 · Build the sentence**

Arrange: 쿠키도 / 난 / 안 / 좋아해.

I don't like cookies, either.

[[Korean#^ko-Q0364-answer|Compare the answer]]
^ko-Q0364

**ko-Q0365 · Write a translation**

Write this in Korean: We might need to help Tom.

[[Korean#^ko-Q0365-answer|Compare the answer]]
^ko-Q0365

**ko-Q0366 · Explain the grammar**

우리가 톰을 도울 필요가 있을 【수도】 있다.

We might need to help Tom.

[[Korean#^ko-Q0366-answer|Compare the answer]]
^ko-Q0366

**ko-Q0367 · Fill the gap**

____ 캐나다 사람이야?

Is Tom a Canadian, too?

[[Korean#^ko-Q0367-answer|Compare the answer]]
^ko-Q0367

**ko-Q0368 · Choose the form**

____ 캐나다 사람이야?

Is Tom a Canadian, too?

Choices: 도 / 만 / 는 / 톰도

[[Korean#^ko-Q0368-answer|Compare the answer]]
^ko-Q0368

**ko-Q0369 · Edit the changed sentence**

네가 꺼져 【도】 난 신경 안 쓴다!

You can fuck off for all I care!

[[Korean#^ko-Q0369-answer|Compare the answer]]
^ko-Q0369

**ko-Q0370 · Build the sentence**

Arrange: 신경 / 난 / 꺼져 / 쓴다! / 버려도 / 안 / 네가

You can fuck off for all I care!

[[Korean#^ko-Q0370-answer|Compare the answer]]
^ko-Q0370

**ko-Q0371 · Write a translation**

Write this in Korean: Tom could be seriously injured.

[[Korean#^ko-Q0371-answer|Compare the answer]]
^ko-Q0371

**ko-Q0372 · Explain the grammar**

톰은 심각한 부상을 당할 【수도】 있었다.

Tom could be seriously injured.

[[Korean#^ko-Q0372-answer|Compare the answer]]
^ko-Q0372

**ko-Q0373 · Fill the gap**

____ 지불할 수 있어요?

Can I pay with a credit card?

[[Korean#^ko-Q0373-answer|Compare the answer]]
^ko-Q0373

**ko-Q0374 · Choose the form**

____ 지불할 수 있어요?

Can I pay with a credit card?

Choices: 카드로도 / 도 / 는 / 만

[[Korean#^ko-Q0374-answer|Compare the answer]]
^ko-Q0374

**ko-Q0375 · Edit the changed sentence**

술 말고 내가 제일 좋아하는 음료수는 【도】 쉐이크야. 흑, 너무 맛있어!

My favorite nonalcoholic drink is an avocado shake. Yum, it's so delicious!

[[Korean#^ko-Q0375-answer|Compare the answer]]
^ko-Q0375

**ko-Q0376 · Build the sentence**

Arrange: 제일 / 맛있어! / 쉐이크야. / 아보카도 / 술 / 흑, / 너무 / 음료수는 / 말고 / 내가 / 좋아하는

My favorite nonalcoholic drink is an avocado shake. Yum, it's so delicious!

[[Korean#^ko-Q0376-answer|Compare the answer]]
^ko-Q0376

**ko-Q0377 · Write a translation**

Write this in Korean: Have you ever been to karaoke alone?

[[Korean#^ko-Q0377-answer|Compare the answer]]
^ko-Q0377

**ko-Q0378 · Explain the grammar**

혼자 노래방에 간 【적도】 있어요?

Have you ever been to karaoke alone?

[[Korean#^ko-Q0378-answer|Compare the answer]]
^ko-Q0378

**ko-Q0379 · Fill the gap**

갖고 다니지 않으면 잃을 ____ 없다.

He who carries nothing loses nothing.

[[Korean#^ko-Q0379-answer|Compare the answer]]
^ko-Q0379

**ko-Q0380 · Choose the form**

갖고 다니지 않으면 잃을 ____ 없다.

He who carries nothing loses nothing.

Choices: 것도 / 도 / 만 / 는

[[Korean#^ko-Q0380-answer|Compare the answer]]
^ko-Q0380

**ko-Q0381 · Edit the changed sentence**

【도】 마찬가지로 프랑스어 배워.

Tom learns French as well.

[[Korean#^ko-Q0381-answer|Compare the answer]]
^ko-Q0381

**ko-Q0382 · Build the sentence**

Arrange: 프랑스어 / 톰도 / 배워. / 마찬가지로

Tom learns French as well.

[[Korean#^ko-Q0382-answer|Compare the answer]]
^ko-Q0382

**ko-Q0383 · Write a translation**

Write this in Korean: Tom is allowed to stay. The rest of you have to leave.

[[Korean#^ko-Q0383-answer|Compare the answer]]
^ko-Q0383

**ko-Q0384 · Explain the grammar**

톰은 남아 【있어도】 돼. 너희 나머지는 나가야 해.

Tom is allowed to stay. The rest of you have to leave.

[[Korean#^ko-Q0384-answer|Compare the answer]]
^ko-Q0384

**ko-Q0385 · Fill the gap**

____ 중국어를 공부하고 있다.

He is also studying Chinese.

[[Korean#^ko-Q0385-answer|Compare the answer]]
^ko-Q0385

**ko-Q0386 · Choose the form**

____ 중국어를 공부하고 있다.

He is also studying Chinese.

Choices: 는 / 그도 / 도 / 만

[[Korean#^ko-Q0386-answer|Compare the answer]]
^ko-Q0386

**ko-Q0387 · Edit the changed sentence**

【도】 짝이 있다

Even a straw shoe belongs to a pair.

[[Korean#^ko-Q0387-answer|Compare the answer]]
^ko-Q0387

**ko-Q0388 · Build the sentence**

Arrange: 짝이 / 있다 / 짚신도

Even a straw shoe belongs to a pair.

[[Korean#^ko-Q0388-answer|Compare the answer]]
^ko-Q0388

**ko-Q0389 · Write a translation**

Write this in Korean: Nobody is perfect.

[[Korean#^ko-Q0389-answer|Compare the answer]]
^ko-Q0389

**ko-Q0390 · Explain the grammar**

그 【누구도】 완벽하지 않는다.

Nobody is perfect.

[[Korean#^ko-Q0390-answer|Compare the answer]]
^ko-Q0390

**ko-Q0391 · Fill the gap**

나는 너의 가장 친한 ____ 가장 나쁜 적도 될 수 있어.

I can be your best friend or your worst enemy.

[[Korean#^ko-Q0391-answer|Compare the answer]]
^ko-Q0391

**ko-Q0392 · Choose the form**

나는 너의 가장 친한 ____ 가장 나쁜 적도 될 수 있어.

I can be your best friend or your worst enemy.

Choices: 도 / 만 / 친구도 / 는

[[Korean#^ko-Q0392-answer|Compare the answer]]
^ko-Q0392

**ko-Q0393 · Edit the changed sentence**

손 들고 【도】 괜찮아요.

It's okay to raise your hand and ask a question.

[[Korean#^ko-Q0393-answer|Compare the answer]]
^ko-Q0393

**ko-Q0394 · Build the sentence**

Arrange: 들고 / 질문해도 / 괜찮아요. / 손

It's okay to raise your hand and ask a question.

[[Korean#^ko-Q0394-answer|Compare the answer]]
^ko-Q0394

**ko-Q0395 · Write a translation**

Write this in Korean: I'm not Indian.

[[Korean#^ko-Q0395-answer|Compare the answer]]
^ko-Q0395

**ko-Q0396 · Explain the grammar**

나는 【인도】 사람이 아니야

I'm not Indian.

[[Korean#^ko-Q0396-answer|Compare the answer]]
^ko-Q0396

**ko-Q0397 · Fill the gap**

내가 그것에 대한 너의 말을 ____ 되겠니?

Can I take your word for it?

[[Korean#^ko-Q0397-answer|Compare the answer]]
^ko-Q0397

**ko-Q0398 · Choose the form**

내가 그것에 대한 너의 말을 ____ 되겠니?

Can I take your word for it?

Choices: 는 / 도 / 만 / 믿어도

[[Korean#^ko-Q0398-answer|Compare the answer]]
^ko-Q0398

**ko-Q0399 · Edit the changed sentence**

이 기사를 【도】 그 사고가 얼마나 심각했는지 알 수 있다.

You have only to read this article to see how serious the accident was.

[[Korean#^ko-Q0399-answer|Compare the answer]]
^ko-Q0399

**ko-Q0400 · Build the sentence**

Arrange: 수 / 기사를 / 있다. / 심각했는지 / 알 / 그 / 얼마나 / 이 / 사고가 / 읽는것만으로도

You have only to read this article to see how serious the accident was.

[[Korean#^ko-Q0400-answer|Compare the answer]]
^ko-Q0400


### Restriction 만 · 50 questions

**ko-Q0401 · Write a translation**

Write this in Korean: I found a solution, but I found it so fast that it can't be the right solution.

[[Korean#^ko-Q0401-answer|Compare the answer]]
^ko-Q0401

**ko-Q0402 · Explain the grammar**

해결책을 【찾았지만】 너무 빨리 찾아서 맞는 답이 아닌거 같습니다.

I found a solution, but I found it so fast that it can't be the right solution.

[[Korean#^ko-Q0402-answer|Compare the answer]]
^ko-Q0402

**ko-Q0403 · Fill the gap**

그녀가 미소지을 땐, 녹아내릴 ____ 같아.

When she smiles, I feel like melting.

[[Korean#^ko-Q0403-answer|Compare the answer]]
^ko-Q0403

**ko-Q0404 · Choose the form**

그녀가 미소지을 땐, 녹아내릴 ____ 같아.

When she smiles, I feel like melting.

Choices: 는 / 만 / 도 / 것만

[[Korean#^ko-Q0404-answer|Compare the answer]]
^ko-Q0404

**ko-Q0405 · Edit the changed sentence**

톰은 획기적이지는 【만】 좋은 영화는 잘 만든다.

Tom doesn't innovate, but he does make good movies.

[[Korean#^ko-Q0405-answer|Compare the answer]]
^ko-Q0405

**ko-Q0406 · Build the sentence**

Arrange: 않지만 / 톰은 / 좋은 / 영화는 / 획기적이지는 / 만든다. / 잘

Tom doesn't innovate, but he does make good movies.

[[Korean#^ko-Q0406-answer|Compare the answer]]
^ko-Q0406

**ko-Q0407 · Write a translation**

Write this in Korean: Everyone except Tom went to the party.

[[Korean#^ko-Q0407-answer|Compare the answer]]
^ko-Q0407

**ko-Q0408 · Explain the grammar**

【톰만】 빼고 다들 파티에 갔어.

Everyone except Tom went to the party.

[[Korean#^ko-Q0408-answer|Compare the answer]]
^ko-Q0408

**ko-Q0409 · Fill the gap**

그의 보고서를 ____ 실수를 찾을 수 없었다.

I went over his report, but couldn't find any mistakes.

[[Korean#^ko-Q0409-answer|Compare the answer]]
^ko-Q0409

**ko-Q0410 · Choose the form**

그의 보고서를 ____ 실수를 찾을 수 없었다.

I went over his report, but couldn't find any mistakes.

Choices: 만 / 도 / 검토했지만 / 는

[[Korean#^ko-Q0410-answer|Compare the answer]]
^ko-Q0410

**ko-Q0411 · Edit the changed sentence**

나는 【만】 공부해요.

I only study in the library.

[[Korean#^ko-Q0411-answer|Compare the answer]]
^ko-Q0411

**ko-Q0412 · Build the sentence**

Arrange: 도서관에서만 / 공부해요. / 나는

I only study in the library.

[[Korean#^ko-Q0412-answer|Compare the answer]]
^ko-Q0412

**ko-Q0413 · Write a translation**

Write this in Korean: Each time I spent only a short time in Paris, and this has given me much to regret.

[[Korean#^ko-Q0413-answer|Compare the answer]]
^ko-Q0413

**ko-Q0414 · Explain the grammar**

그 기간동안 나는 오직 【빠리에서만】 짧게 머물렀기 때문에 그 기간이 매우 아쉬웠다.

Each time I spent only a short time in Paris, and this has given me much to regret.

[[Korean#^ko-Q0414-answer|Compare the answer]]
^ko-Q0414

**ko-Q0415 · Fill the gap**

나는 그 여자의 제안을 ____ 했어.

I had to refuse her offer.

[[Korean#^ko-Q0415-answer|Compare the answer]]
^ko-Q0415

**ko-Q0416 · Choose the form**

나는 그 여자의 제안을 ____ 했어.

I had to refuse her offer.

Choices: 는 / 거절해야만 / 도 / 만

[[Korean#^ko-Q0416-answer|Compare the answer]]
^ko-Q0416

**ko-Q0417 · Edit the changed sentence**

【만】 주인공은 자신의 실수를 인식하고 있다.

However the protagonist is aware of his own mistakes.

[[Korean#^ko-Q0417-answer|Compare the answer]]
^ko-Q0417

**ko-Q0418 · Build the sentence**

Arrange: 자신의 / 있다. / 실수를 / 인식하고 / 주인공은 / 하지만

However the protagonist is aware of his own mistakes.

[[Korean#^ko-Q0418-answer|Compare the answer]]
^ko-Q0418

**ko-Q0419 · Write a translation**

Write this in Korean: Tom wanted to kiss Mary, but he didn't have the nerve to try.

[[Korean#^ko-Q0419-answer|Compare the answer]]
^ko-Q0419

**ko-Q0420 · Explain the grammar**

탐은 메리와 뽀뽀하고 【싶었지만】 시도할 용기가 없었다.

Tom wanted to kiss Mary, but he didn't have the nerve to try.

[[Korean#^ko-Q0420-answer|Compare the answer]]
^ko-Q0420

**ko-Q0421 · Fill the gap**

나는 네가 그렇게 하도록 강요하지는 ____ 그렇게 해야 할거야

I won't force you to do that, but I think you should.

[[Korean#^ko-Q0421-answer|Compare the answer]]
^ko-Q0421

**ko-Q0422 · Choose the form**

나는 네가 그렇게 하도록 강요하지는 ____ 그렇게 해야 할거야

I won't force you to do that, but I think you should.

Choices: 도 / 만 / 않겠지만 / 는

[[Korean#^ko-Q0422-answer|Compare the answer]]
^ko-Q0422

**ko-Q0423 · Edit the changed sentence**

날 【만】 괴롭혀!

Stop bugging me!

[[Korean#^ko-Q0423-answer|Compare the answer]]
^ko-Q0423

**ko-Q0424 · Build the sentence**

Arrange: 괴롭혀! / 날 / 그만

Stop bugging me!

[[Korean#^ko-Q0424-answer|Compare the answer]]
^ko-Q0424

**ko-Q0425 · Write a translation**

Write this in Korean: He did nothing but cry.

[[Korean#^ko-Q0425-answer|Compare the answer]]
^ko-Q0425

**ko-Q0426 · Explain the grammar**

그는 【울기만】 했다.

He did nothing but cry.

[[Korean#^ko-Q0426-answer|Compare the answer]]
^ko-Q0426

**ko-Q0427 · Fill the gap**

난 ____ 말을할수있어.

I can only speak for myself.

[[Korean#^ko-Q0427-answer|Compare the answer]]
^ko-Q0427

**ko-Q0428 · Choose the form**

난 ____ 말을할수있어.

I can only speak for myself.

Choices: 도 / 나를위해서만 / 는 / 만

[[Korean#^ko-Q0428-answer|Compare the answer]]
^ko-Q0428

**ko-Q0429 · Edit the changed sentence**

택시 한 【만】 불러 주시겠습니까?

Would you like me to call a taxi?

[[Korean#^ko-Q0429-answer|Compare the answer]]
^ko-Q0429

**ko-Q0430 · Build the sentence**

Arrange: 불러 / 택시 / 주시겠습니까? / 대만 / 한

Would you like me to call a taxi?

[[Korean#^ko-Q0430-answer|Compare the answer]]
^ko-Q0430

**ko-Q0431 · Write a translation**

Write this in Korean: Man has reason, animals do not.

[[Korean#^ko-Q0431-answer|Compare the answer]]
^ko-Q0431

**ko-Q0432 · Explain the grammar**

인간은 이성이 【있지만】 동물은 없다.

Man has reason, animals do not.

[[Korean#^ko-Q0432-answer|Compare the answer]]
^ko-Q0432

**ko-Q0433 · Fill the gap**

어둠으로 어둠을 몰아낼 수는 없다. 오직 ____ 할수 있다. 증오로 증오를 몰아낼수는 없다. 오직 사랑만이 그것을 할 수 있다.

Darkness cannot drive out darkness; only light can do that. Hate cannot drive out hate; only love can do that.

[[Korean#^ko-Q0433-answer|Compare the answer]]
^ko-Q0433

**ko-Q0434 · Choose the form**

어둠으로 어둠을 몰아낼 수는 없다. 오직 ____ 할수 있다. 증오로 증오를 몰아낼수는 없다. 오직 사랑만이 그것을 할 수 있다.

Darkness cannot drive out darkness; only light can do that. Hate cannot drive out hate; only love can do that.

Choices: 는 / 빛으로만 / 도 / 만

[[Korean#^ko-Q0434-answer|Compare the answer]]
^ko-Q0434

**ko-Q0435 · Edit the changed sentence**

그녀는 그한테 그녀의 아버지가 차고 청소 하는 것을 도와 주라고 【만】 그는 너무 바빠서 못 도와 준대.

She asked him to help her father clean the garage, but he said that he was too busy to help.

[[Korean#^ko-Q0435-answer|Compare the answer]]
^ko-Q0435

**ko-Q0436 · Build the sentence**

Arrange: 그녀의 / 그녀는 / 주라고 / 도와 / 준대. / 너무 / 하는 / 차고 / 청소 / 그한테 / 했지만 / 것을 / 못 / 아버지가 / 그는 / 도와 / 바빠서

She asked him to help her father clean the garage, but he said that he was too busy to help.

[[Korean#^ko-Q0436-answer|Compare the answer]]
^ko-Q0436

**ko-Q0437 · Write a translation**

Write this in Korean: It's already evening, I'm tired and have to finish writing. Good night!

[[Korean#^ko-Q0437-answer|Compare the answer]]
^ko-Q0437

**ko-Q0438 · Explain the grammar**

벌써 저녁이네. 피곤해서 글쓰기는 【그만】 끝내야겠다. 잘자!

It's already evening, I'm tired and have to finish writing. Good night!

[[Korean#^ko-Q0438-answer|Compare the answer]]
^ko-Q0438

**ko-Q0439 · Fill the gap**

걔 좀 ____ 마시게 해.

Don't let her drink any more.

[[Korean#^ko-Q0439-answer|Compare the answer]]
^ko-Q0439

**ko-Q0440 · Choose the form**

걔 좀 ____ 마시게 해.

Don't let her drink any more.

Choices: 만 / 그만 / 는 / 도

[[Korean#^ko-Q0440-answer|Compare the answer]]
^ko-Q0440

**ko-Q0441 · Edit the changed sentence**

그녀는 그를 비웃었을 【만】 아니라 그를 미치게 했다

She not only ridiculed him, but also drove him out.

[[Korean#^ko-Q0441-answer|Compare the answer]]
^ko-Q0441

**ko-Q0442 · Build the sentence**

Arrange: 비웃었을 / 그를 / 그녀는 / 미치게 / 아니라 / 뿐만 / 그를 / 했다

She not only ridiculed him, but also drove him out.

[[Korean#^ko-Q0442-answer|Compare the answer]]
^ko-Q0442

**ko-Q0443 · Write a translation**

Write this in Korean: The good things about democracy is: anybody can say what's on their mind, but nobody has to listen to it.

[[Korean#^ko-Q0443-answer|Compare the answer]]
^ko-Q0443

**ko-Q0444 · Explain the grammar**

민주주의의 좋은 점은 바로 이렇다: 누구나 그들의 단편적인 생각을 말할 수 【있지만】 누구도 거기에 귀를 기울일 필요는 없다는 것이다

The good things about democracy is: anybody can say what's on their mind, but nobody has to listen to it.

[[Korean#^ko-Q0444-answer|Compare the answer]]
^ko-Q0444

**ko-Q0445 · Fill the gap**

그는 키가 ____ 세다.

He is short but strong.

[[Korean#^ko-Q0445-answer|Compare the answer]]
^ko-Q0445

**ko-Q0446 · Choose the form**

그는 키가 ____ 세다.

He is short but strong.

Choices: 도 / 만 / 는 / 작지만

[[Korean#^ko-Q0446-answer|Compare the answer]]
^ko-Q0446

**ko-Q0447 · Edit the changed sentence**

톰은 때때로 같이 운동하자고 【만】 나는 정말 운동에 관심이 없다.

Tom occasionally prods me to work out with him, but I'm really not interested.

[[Korean#^ko-Q0447-answer|Compare the answer]]
^ko-Q0447

**ko-Q0448 · Build the sentence**

Arrange: 운동에 / 정말 / 톰은 / 때때로 / 같이 / 없다. / 운동하자고 / 졸라댔지만 / 관심이 / 나는

Tom occasionally prods me to work out with him, but I'm really not interested.

[[Korean#^ko-Q0448-answer|Compare the answer]]
^ko-Q0448

**ko-Q0449 · Write a translation**

Write this in Korean: Don't pry into my private life.

[[Korean#^ko-Q0449-answer|Compare the answer]]
^ko-Q0449

**ko-Q0450 · Explain the grammar**

내 사생활 좀 【그만】 캐물어.

Don't pry into my private life.

[[Korean#^ko-Q0450-answer|Compare the answer]]
^ko-Q0450


### Formal polite endings · 50 questions

**ko-Q0451 · Fill the gap**

오늘은 6월 18일, Muiriel의 ____!

Today is June 18th and it is Muiriel's birthday!

[[Korean#^ko-Q0451-answer|Compare the answer]]
^ko-Q0451

**ko-Q0452 · Choose the form**

오늘은 6월 18일, Muiriel의 ____!

Today is June 18th and it is Muiriel's birthday!

Choices: 입니다 / 습니까 / 생일입니다 / 습니다

[[Korean#^ko-Q0452-answer|Compare the answer]]
^ko-Q0452

**ko-Q0453 · Edit the changed sentence**

Muiriel은 지금 20【습니다】.

Muiriel is 20 now.

[[Korean#^ko-Q0453-answer|Compare the answer]]
^ko-Q0453

**ko-Q0454 · Build the sentence**

Arrange: Muiriel은 / 20살입니다. / 지금

Muiriel is 20 now.

[[Korean#^ko-Q0454-answer|Compare the answer]]
^ko-Q0454

**ko-Q0455 · Write a translation**

Write this in Korean: Children are not allowed in.

[[Korean#^ko-Q0455-answer|Compare the answer]]
^ko-Q0455

**ko-Q0456 · Explain the grammar**

아이들은 들어올 수 【없습니다】.

Children are not allowed in.

[[Korean#^ko-Q0456-answer|Compare the answer]]
^ko-Q0456

**ko-Q0457 · Fill the gap**

작고 흰 토끼는 "무슨 일 있니?" 라고 ____.

"What's the matter?" asked the little white rabbit.

[[Korean#^ko-Q0457-answer|Compare the answer]]
^ko-Q0457

**ko-Q0458 · Choose the form**

작고 흰 토끼는 "무슨 일 있니?" 라고 ____.

"What's the matter?" asked the little white rabbit.

Choices: 입니다 / 물어봤습니다 / 습니까 / 습니다

[[Korean#^ko-Q0458-answer|Compare the answer]]
^ko-Q0458

**ko-Q0459 · Edit the changed sentence**

요즘 딸기가 【습니다】.

Strawberries are in season now.

[[Korean#^ko-Q0459-answer|Compare the answer]]
^ko-Q0459

**ko-Q0460 · Build the sentence**

Arrange: 딸기가 / 제철입니다. / 요즘

Strawberries are in season now.

[[Korean#^ko-Q0460-answer|Compare the answer]]
^ko-Q0460

**ko-Q0461 · Write a translation**

Write this in Korean: Can you prove the allegations?

[[Korean#^ko-Q0461-answer|Compare the answer]]
^ko-Q0461

**ko-Q0462 · Explain the grammar**

주장을 증명할 수 【있습니까】?

Can you prove the allegations?

[[Korean#^ko-Q0462-answer|Compare the answer]]
^ko-Q0462

**ko-Q0463 · Fill the gap**

이탈리아는 아주 아름다운 ____.

Italy is a very beautiful country.

[[Korean#^ko-Q0463-answer|Compare the answer]]
^ko-Q0463

**ko-Q0464 · Choose the form**

이탈리아는 아주 아름다운 ____.

Italy is a very beautiful country.

Choices: 습니까 / 습니다 / 입니다 / 나라입니다

[[Korean#^ko-Q0464-answer|Compare the answer]]
^ko-Q0464

**ko-Q0465 · Edit the changed sentence**

저는 그리스 【습니다】.

I'm from Greece.

[[Korean#^ko-Q0465-answer|Compare the answer]]
^ko-Q0465

**ko-Q0466 · Build the sentence**

Arrange: 그리스 / 사람입니다. / 저는

I'm from Greece.

[[Korean#^ko-Q0466-answer|Compare the answer]]
^ko-Q0466

**ko-Q0467 · Write a translation**

Write this in Korean: There are many words with meanings I don't know.

[[Korean#^ko-Q0467-answer|Compare the answer]]
^ko-Q0467

**ko-Q0468 · Explain the grammar**

내가 모르는 의미를 가진 단어가 많이 【있습니다】.

There are many words with meanings I don't know.

[[Korean#^ko-Q0468-answer|Compare the answer]]
^ko-Q0468

**ko-Q0469 · Fill the gap**

한국어를 1년 째 공부하고 ____.

I have been studying Korean for 1 year.

[[Korean#^ko-Q0469-answer|Compare the answer]]
^ko-Q0469

**ko-Q0470 · Choose the form**

한국어를 1년 째 공부하고 ____.

I have been studying Korean for 1 year.

Choices: 입니다 / 있습니다 / 습니다 / 습니까

[[Korean#^ko-Q0470-answer|Compare the answer]]
^ko-Q0470

**ko-Q0471 · Edit the changed sentence**

제꿈은 작가가 되는 【습니다】.

My goal in life is to be a novelist.

[[Korean#^ko-Q0471-answer|Compare the answer]]
^ko-Q0471

**ko-Q0472 · Build the sentence**

Arrange: 작가가 / 것입니다. / 되는 / 제꿈은

My goal in life is to be a novelist.

[[Korean#^ko-Q0472-answer|Compare the answer]]
^ko-Q0472

**ko-Q0473 · Write a translation**

Write this in Korean: I want to check out at 6 tomorrow morning.

[[Korean#^ko-Q0473-answer|Compare the answer]]
^ko-Q0473

**ko-Q0474 · Explain the grammar**

저는 내일 오전 6시에 체크아웃 【하겠습니다】.

I want to check out at 6 tomorrow morning.

[[Korean#^ko-Q0474-answer|Compare the answer]]
^ko-Q0474

**ko-Q0475 · Fill the gap**

내주 금요일 오전 내내 시간이 ____.

I will be free all morning next Friday.

[[Korean#^ko-Q0475-answer|Compare the answer]]
^ko-Q0475

**ko-Q0476 · Choose the form**

내주 금요일 오전 내내 시간이 ____.

I will be free all morning next Friday.

Choices: 습니다 / 습니까 / 있습니다 / 입니다

[[Korean#^ko-Q0476-answer|Compare the answer]]
^ko-Q0476

**ko-Q0477 · Edit the changed sentence**

작년 여름에 몇 번이나 수영을 하러 【습니다】?

How often did you go swimming last summer?

[[Korean#^ko-Q0477-answer|Compare the answer]]
^ko-Q0477

**ko-Q0478 · Build the sentence**

Arrange: 번이나 / 여름에 / 수영을 / 몇 / 하러 / 갔었습니까? / 작년

How often did you go swimming last summer?

[[Korean#^ko-Q0478-answer|Compare the answer]]
^ko-Q0478

**ko-Q0479 · Write a translation**

Write this in Korean: We want natural-sounding translations, not word-for-word direct translations.

[[Korean#^ko-Q0479-answer|Compare the answer]]
^ko-Q0479

**ko-Q0480 · Explain the grammar**

우리는 자연스럽게 들리는 번역문을 원하며, 단어 대 단어로 직역한 번역문을 원하지 【않습니다】.

We want natural-sounding translations, not word-for-word direct translations.

[[Korean#^ko-Q0480-answer|Compare the answer]]
^ko-Q0480

**ko-Q0481 · Fill the gap**

이곳은 눈이 거의 내리지 ____.

It rarely snows here.

[[Korean#^ko-Q0481-answer|Compare the answer]]
^ko-Q0481

**ko-Q0482 · Choose the form**

이곳은 눈이 거의 내리지 ____.

It rarely snows here.

Choices: 습니까 / 습니다 / 입니다 / 않습니다

[[Korean#^ko-Q0482-answer|Compare the answer]]
^ko-Q0482

**ko-Q0483 · Edit the changed sentence**

수건 좀 【습니다】?

Can you pass me the towel?

[[Korean#^ko-Q0483-answer|Compare the answer]]
^ko-Q0483

**ko-Q0484 · Build the sentence**

Arrange: 수건 / 주시겠습니까? / 좀

Can you pass me the towel?

[[Korean#^ko-Q0484-answer|Compare the answer]]
^ko-Q0484

**ko-Q0485 · Write a translation**

Write this in Korean: Would it suffice if I came around 7?

[[Korean#^ko-Q0485-answer|Compare the answer]]
^ko-Q0485

**ko-Q0486 · Explain the grammar**

내가 7시경에 오면 【되겠습니까】?

Would it suffice if I came around 7?

[[Korean#^ko-Q0486-answer|Compare the answer]]
^ko-Q0486

**ko-Q0487 · Fill the gap**

독서는 제 취미 중 ____.

Reading is one of my hobbies.

[[Korean#^ko-Q0487-answer|Compare the answer]]
^ko-Q0487

**ko-Q0488 · Choose the form**

독서는 제 취미 중 ____.

Reading is one of my hobbies.

Choices: 입니다 / 하나입니다 / 습니다 / 습니까

[[Korean#^ko-Q0488-answer|Compare the answer]]
^ko-Q0488

**ko-Q0489 · Edit the changed sentence**

전 많은 【습니다】.

I have a lot of dreams.

[[Korean#^ko-Q0489-answer|Compare the answer]]
^ko-Q0489

**ko-Q0490 · Build the sentence**

Arrange: 꿈을했습니다. / 많은 / 전

I have a lot of dreams.

[[Korean#^ko-Q0490-answer|Compare the answer]]
^ko-Q0490

**ko-Q0491 · Write a translation**

Write this in Korean: It's hard to learn.

[[Korean#^ko-Q0491-answer|Compare the answer]]
^ko-Q0491

**ko-Q0492 · Explain the grammar**

그것은 배우기 【어렵습니다】.

It's hard to learn.

[[Korean#^ko-Q0492-answer|Compare the answer]]
^ko-Q0492

**ko-Q0493 · Fill the gap**

그는 유엔 대사 ____.

He was ambassador to the United Nations.

[[Korean#^ko-Q0493-answer|Compare the answer]]
^ko-Q0493

**ko-Q0494 · Choose the form**

그는 유엔 대사 ____.

He was ambassador to the United Nations.

Choices: 입니다 / 습니다 / 습니까 / 였습니다

[[Korean#^ko-Q0494-answer|Compare the answer]]
^ko-Q0494

**ko-Q0495 · Edit the changed sentence**

봄에 피는 꽃은 여러 가지가 【습니다】.

In spring, there are various blooming flowers.

[[Korean#^ko-Q0495-answer|Compare the answer]]
^ko-Q0495

**ko-Q0496 · Build the sentence**

Arrange: 가지가 / 피는 / 봄에 / 있습니다. / 여러 / 꽃은

In spring, there are various blooming flowers.

[[Korean#^ko-Q0496-answer|Compare the answer]]
^ko-Q0496

**ko-Q0497 · Write a translation**

Write this in Korean: We've been waiting for your instructions.

[[Korean#^ko-Q0497-answer|Compare the answer]]
^ko-Q0497

**ko-Q0498 · Explain the grammar**

그쪽의 지시를 기다리는 【중이었습니다】.

We've been waiting for your instructions.

[[Korean#^ko-Q0498-answer|Compare the answer]]
^ko-Q0498

**ko-Q0499 · Fill the gap**

정확한 문장을 수정하지 마십시오. 대신 당신은 자연스럽게 들리는 다른 번역문을 제출할 수 ____.

Don't change sentences that are correct. You can, instead, submit natural-sounding alternative translations.

[[Korean#^ko-Q0499-answer|Compare the answer]]
^ko-Q0499

**ko-Q0500 · Choose the form**

정확한 문장을 수정하지 마십시오. 대신 당신은 자연스럽게 들리는 다른 번역문을 제출할 수 ____.

Don't change sentences that are correct. You can, instead, submit natural-sounding alternative translations.

Choices: 있습니다 / 습니다 / 입니다 / 습니까

[[Korean#^ko-Q0500-answer|Compare the answer]]
^ko-Q0500


### Conversational polite endings · 50 questions

**ko-Q0501 · Edit the changed sentence**

벌써 우리가 만난 지 4년 이에요. 시간이 참 빠른 것 【아요】.

It's already been 4 years since we met. How time flies.

[[Korean#^ko-Q0501-answer|Compare the answer]]
^ko-Q0501

**ko-Q0502 · Build the sentence**

Arrange: 만난 / 이에요. / 같아요. / 참 / 빠른 / 시간이 / 지 / 우리가 / 것 / 4년 / 벌써

It's already been 4 years since we met. How time flies.

[[Korean#^ko-Q0502-answer|Compare the answer]]
^ko-Q0502

**ko-Q0503 · Write a translation**

Write this in Korean: I want to learn Korean.

[[Korean#^ko-Q0503-answer|Compare the answer]]
^ko-Q0503

**ko-Q0504 · Explain the grammar**

한국어를 배우고 【싶어요】.

I want to learn Korean.

[[Korean#^ko-Q0504-answer|Compare the answer]]
^ko-Q0504

**ko-Q0505 · Fill the gap**

존이 한국 영화를 보고 ____?

Does John want to see a Korean movie?

[[Korean#^ko-Q0505-answer|Compare the answer]]
^ko-Q0505

**ko-Q0506 · Choose the form**

존이 한국 영화를 보고 ____?

Does John want to see a Korean movie?

Choices: 해요 / 아요 / 어요 / 싶어해요

[[Korean#^ko-Q0506-answer|Compare the answer]]
^ko-Q0506

**ko-Q0507 · Edit the changed sentence**

왜냐하면 당신은 혼자가 되고 싶지 않기 【아요】.

It's because you don't want to be alone.

[[Korean#^ko-Q0507-answer|Compare the answer]]
^ko-Q0507

**ko-Q0508 · Build the sentence**

Arrange: 되고 / 싶지 / 당신은 / 때문이에요. / 않기 / 혼자가 / 왜냐하면

It's because you don't want to be alone.

[[Korean#^ko-Q0508-answer|Compare the answer]]
^ko-Q0508

**ko-Q0509 · Write a translation**

Write this in Korean: I don't sleep a lot.

[[Korean#^ko-Q0509-answer|Compare the answer]]
^ko-Q0509

**ko-Q0510 · Explain the grammar**

나는 잠이 많지 【않아요】.

I don't sleep a lot.

[[Korean#^ko-Q0510-answer|Compare the answer]]
^ko-Q0510

**ko-Q0511 · Fill the gap**

아마 내일 일찍 일어날 ____.

I will probably get up early tomorrow.

[[Korean#^ko-Q0511-answer|Compare the answer]]
^ko-Q0511

**ko-Q0512 · Choose the form**

아마 내일 일찍 일어날 ____.

I will probably get up early tomorrow.

Choices: 어요 / 해요 / 아요 / 거예요

[[Korean#^ko-Q0512-answer|Compare the answer]]
^ko-Q0512

**ko-Q0513 · Edit the changed sentence**

사람 많은 게 【아요】.

I hate it when there are a lot of people.

[[Korean#^ko-Q0513-answer|Compare the answer]]
^ko-Q0513

**ko-Q0514 · Build the sentence**

Arrange: 싫어요. / 게 / 많은 / 사람

I hate it when there are a lot of people.

[[Korean#^ko-Q0514-answer|Compare the answer]]
^ko-Q0514

**ko-Q0515 · Write a translation**

Write this in Korean: I can't believe this is happening.

[[Korean#^ko-Q0515-answer|Compare the answer]]
^ko-Q0515

**ko-Q0516 · Explain the grammar**

이런 일이 일어난다니 믿을 수가 【없어요】.

I can't believe this is happening.

[[Korean#^ko-Q0516-answer|Compare the answer]]
^ko-Q0516

**ko-Q0517 · Fill the gap**

지난 3년동안 톰을 보지 ____.

I hadn't seen Tom in three years.

[[Korean#^ko-Q0517-answer|Compare the answer]]
^ko-Q0517

**ko-Q0518 · Choose the form**

지난 3년동안 톰을 보지 ____.

I hadn't seen Tom in three years.

Choices: 어요 / 아요 / 해요 / 못했었어요

[[Korean#^ko-Q0518-answer|Compare the answer]]
^ko-Q0518

**ko-Q0519 · Edit the changed sentence**

톰은 연구 개발을 하고 【아요】.

Tom works in research and development.

[[Korean#^ko-Q0519-answer|Compare the answer]]
^ko-Q0519

**ko-Q0520 · Build the sentence**

Arrange: 하고 / 톰은 / 연구 / 개발을 / 있어요.

Tom works in research and development.

[[Korean#^ko-Q0520-answer|Compare the answer]]
^ko-Q0520

**ko-Q0521 · Write a translation**

Write this in Korean: I want to meet the teacher.

[[Korean#^ko-Q0521-answer|Compare the answer]]
^ko-Q0521

**ko-Q0522 · Explain the grammar**

선생님을 만나고 【싶어요】.

I want to meet the teacher.

[[Korean#^ko-Q0522-answer|Compare the answer]]
^ko-Q0522

**ko-Q0523 · Fill the gap**

고릴라하고 얼룩말은 어디 ____?

Where are gorillas and zebras?

[[Korean#^ko-Q0523-answer|Compare the answer]]
^ko-Q0523

**ko-Q0524 · Choose the form**

고릴라하고 얼룩말은 어디 ____?

Where are gorillas and zebras?

Choices: 아요 / 어요 / 있어요 / 해요

[[Korean#^ko-Q0524-answer|Compare the answer]]
^ko-Q0524

**ko-Q0525 · Edit the changed sentence**

전 한국 요리를 【아요】.

I like Korean cuisine.

[[Korean#^ko-Q0525-answer|Compare the answer]]
^ko-Q0525

**ko-Q0526 · Build the sentence**

Arrange: 요리를 / 전 / 한국 / 좋아해요.

I like Korean cuisine.

[[Korean#^ko-Q0526-answer|Compare the answer]]
^ko-Q0526

**ko-Q0527 · Write a translation**

Write this in Korean: I don't sleep a lot.

[[Korean#^ko-Q0527-answer|Compare the answer]]
^ko-Q0527

**ko-Q0528 · Explain the grammar**

나는 많이 자지 【않아요】.

I don't sleep a lot.

[[Korean#^ko-Q0528-answer|Compare the answer]]
^ko-Q0528

**ko-Q0529 · Fill the gap**

은행 문은 닫혀 ____?

Was the bank closed?

[[Korean#^ko-Q0529-answer|Compare the answer]]
^ko-Q0529

**ko-Q0530 · Choose the form**

은행 문은 닫혀 ____?

Was the bank closed?

Choices: 아요 / 있었어요 / 해요 / 어요

[[Korean#^ko-Q0530-answer|Compare the answer]]
^ko-Q0530

**ko-Q0531 · Edit the changed sentence**

직접 만드신 【아요】?

Did you make it yourself?

[[Korean#^ko-Q0531-answer|Compare the answer]]
^ko-Q0531

**ko-Q0532 · Build the sentence**

Arrange: 거예요? / 만드신 / 직접

Did you make it yourself?

[[Korean#^ko-Q0532-answer|Compare the answer]]
^ko-Q0532

**ko-Q0533 · Write a translation**

Write this in Korean: There is a soccer stadium in the city where I live.

[[Korean#^ko-Q0533-answer|Compare the answer]]
^ko-Q0533

**ko-Q0534 · Explain the grammar**

우리 도시에는 축구 경기장이 【있어요】.

There is a soccer stadium in the city where I live.

[[Korean#^ko-Q0534-answer|Compare the answer]]
^ko-Q0534

**ko-Q0535 · Fill the gap**

죄송하지만, 무슨 말인지 ____.

I'm sorry, but I don't understand.

[[Korean#^ko-Q0535-answer|Compare the answer]]
^ko-Q0535

**ko-Q0536 · Choose the form**

죄송하지만, 무슨 말인지 ____.

I'm sorry, but I don't understand.

Choices: 어요 / 해요 / 모르겠어요 / 아요

[[Korean#^ko-Q0536-answer|Compare the answer]]
^ko-Q0536

**ko-Q0537 · Edit the changed sentence**

당신은 어떻게 【아요】?

How did you sleep, dear?

[[Korean#^ko-Q0537-answer|Compare the answer]]
^ko-Q0537

**ko-Q0538 · Build the sentence**

Arrange: 잤어요? / 당신은 / 어떻게

How did you sleep, dear?

[[Korean#^ko-Q0538-answer|Compare the answer]]
^ko-Q0538

**ko-Q0539 · Write a translation**

Write this in Korean: When are you going to call?

[[Korean#^ko-Q0539-answer|Compare the answer]]
^ko-Q0539

**ko-Q0540 · Explain the grammar**

언제 전화할 【거예요】?

When are you going to call?

[[Korean#^ko-Q0540-answer|Compare the answer]]
^ko-Q0540

**ko-Q0541 · Fill the gap**

크리스는 운전할 차가 ____.

Chris didn't have a car to drive.

[[Korean#^ko-Q0541-answer|Compare the answer]]
^ko-Q0541

**ko-Q0542 · Choose the form**

크리스는 운전할 차가 ____.

Chris didn't have a car to drive.

Choices: 어요 / 없었어요 / 해요 / 아요

[[Korean#^ko-Q0542-answer|Compare the answer]]
^ko-Q0542

**ko-Q0543 · Edit the changed sentence**

나는 그녀를 기다리고 【아요】.

I'm waiting for her to come here.

[[Korean#^ko-Q0543-answer|Compare the answer]]
^ko-Q0543

**ko-Q0544 · Build the sentence**

Arrange: 기다리고 / 나는 / 그녀를 / 있어요.

I'm waiting for her to come here.

[[Korean#^ko-Q0544-answer|Compare the answer]]
^ko-Q0544

**ko-Q0545 · Write a translation**

Write this in Korean: He gave it to me.

[[Korean#^ko-Q0545-answer|Compare the answer]]
^ko-Q0545

**ko-Q0546 · Explain the grammar**

그가 그것을 내게 【줬어요】.

He gave it to me.

[[Korean#^ko-Q0546-answer|Compare the answer]]
^ko-Q0546

**ko-Q0547 · Fill the gap**

밴드는 아주 잘 ____.

The band plays really well.

[[Korean#^ko-Q0547-answer|Compare the answer]]
^ko-Q0547

**ko-Q0548 · Choose the form**

밴드는 아주 잘 ____.

The band plays really well.

Choices: 해요 / 연주해요 / 어요 / 아요

[[Korean#^ko-Q0548-answer|Compare the answer]]
^ko-Q0548

**ko-Q0549 · Edit the changed sentence**

가을을 제일 【아요】.

I like autumn most.

[[Korean#^ko-Q0549-answer|Compare the answer]]
^ko-Q0549

**ko-Q0550 · Build the sentence**

Arrange: 좋아해요. / 제일 / 가을을

I like autumn most.

[[Korean#^ko-Q0550-answer|Compare the answer]]
^ko-Q0550


### Past forms · 50 questions

**ko-Q0551 · Write a translation**

Write this in Korean: Tom hasn't decided yet.

[[Korean#^ko-Q0551-answer|Compare the answer]]
^ko-Q0551

**ko-Q0552 · Explain the grammar**

톰은 아직 결정하지 【못했다】.

Tom hasn't decided yet.

[[Korean#^ko-Q0552-answer|Compare the answer]]
^ko-Q0552

**ko-Q0553 · Fill the gap**

히메쿠사 유리코는 ____.

Yuriko Himekusa committed suicide.

[[Korean#^ko-Q0553-answer|Compare the answer]]
^ko-Q0553

**ko-Q0554 · Choose the form**

히메쿠사 유리코는 ____.

Yuriko Himekusa committed suicide.

Choices: 았어요 / 했어요 / 자살했다 / 었어요

[[Korean#^ko-Q0554-answer|Compare the answer]]
^ko-Q0554

**ko-Q0555 · Edit the changed sentence**

난 정말로 돕고 【았어요】.

I really wanted to help.

[[Korean#^ko-Q0555-answer|Compare the answer]]
^ko-Q0555

**ko-Q0556 · Build the sentence**

Arrange: 돕고 / 싶었어. / 난 / 정말로

I really wanted to help.

[[Korean#^ko-Q0556-answer|Compare the answer]]
^ko-Q0556

**ko-Q0557 · Write a translation**

Write this in Korean: The president approved the use of crossbows by the police.

[[Korean#^ko-Q0557-answer|Compare the answer]]
^ko-Q0557

**ko-Q0558 · Explain the grammar**

대통령은 경찰이 석궁을 사용하는 것을 【승인했다】.

The president approved the use of crossbows by the police.

[[Korean#^ko-Q0558-answer|Compare the answer]]
^ko-Q0558

**ko-Q0559 · Fill the gap**

상황은 우리가 ____ 것보다 나쁘다.

The situation is worse than we believed.

[[Korean#^ko-Q0559-answer|Compare the answer]]
^ko-Q0559

**ko-Q0560 · Choose the form**

상황은 우리가 ____ 것보다 나쁘다.

The situation is worse than we believed.

Choices: 었어요 / 생각했던 / 았어요 / 했어요

[[Korean#^ko-Q0560-answer|Compare the answer]]
^ko-Q0560

**ko-Q0561 · Edit the changed sentence**

아이들은 조용히 앉아 【았어요】.

The children sat quietly.

[[Korean#^ko-Q0561-answer|Compare the answer]]
^ko-Q0561

**ko-Q0562 · Build the sentence**

Arrange: 있었다. / 아이들은 / 조용히 / 앉아

The children sat quietly.

[[Korean#^ko-Q0562-answer|Compare the answer]]
^ko-Q0562

**ko-Q0563 · Write a translation**

Write this in Korean: My blood was boiling.

[[Korean#^ko-Q0563-answer|Compare the answer]]
^ko-Q0563

**ko-Q0564 · Explain the grammar**

내 피가 끓고 【있었다】.

My blood was boiling.

[[Korean#^ko-Q0564-answer|Compare the answer]]
^ko-Q0564

**ko-Q0565 · Fill the gap**

나는 뭔가가 ____ 생각했다.

I thought something was wrong.

[[Korean#^ko-Q0565-answer|Compare the answer]]
^ko-Q0565

**ko-Q0566 · Choose the form**

나는 뭔가가 ____ 생각했다.

I thought something was wrong.

Choices: 했어요 / 았어요 / 었어요 / 잘못되었다고

[[Korean#^ko-Q0566-answer|Compare the answer]]
^ko-Q0566

**ko-Q0567 · Edit the changed sentence**

톰은 메리라는 캐나다 여성과 【았어요】.

Tom is married to a Canadian woman named Mary.

[[Korean#^ko-Q0567-answer|Compare the answer]]
^ko-Q0567

**ko-Q0568 · Build the sentence**

Arrange: 결혼했어. / 캐나다 / 톰은 / 여성과 / 메리라는

Tom is married to a Canadian woman named Mary.

[[Korean#^ko-Q0568-answer|Compare the answer]]
^ko-Q0568

**ko-Q0569 · Write a translation**

Write this in Korean: The company president was indicted for paying kickbacks.

[[Korean#^ko-Q0569-answer|Compare the answer]]
^ko-Q0569

**ko-Q0570 · Explain the grammar**

그 회사 회장은 리베이트를 지불한 혐의로 【기소되었다】.

The company president was indicted for paying kickbacks.

[[Korean#^ko-Q0570-answer|Compare the answer]]
^ko-Q0570

**ko-Q0571 · Fill the gap**

나는 너처럼 ____.

I used to be poor like you.

[[Korean#^ko-Q0571-answer|Compare the answer]]
^ko-Q0571

**ko-Q0572 · Choose the form**

나는 너처럼 ____.

I used to be poor like you.

Choices: 가난했었다 / 했어요 / 았어요 / 었어요

[[Korean#^ko-Q0572-answer|Compare the answer]]
^ko-Q0572

**ko-Q0573 · Edit the changed sentence**

톰은 매우 【았어요】.

Tom was very disrespectful.

[[Korean#^ko-Q0573-answer|Compare the answer]]
^ko-Q0573

**ko-Q0574 · Build the sentence**

Arrange: 무례했다. / 톰은 / 매우

Tom was very disrespectful.

[[Korean#^ko-Q0574-answer|Compare the answer]]
^ko-Q0574

**ko-Q0575 · Write a translation**

Write this in Korean: Tom was too old.

[[Korean#^ko-Q0575-answer|Compare the answer]]
^ko-Q0575

**ko-Q0576 · Explain the grammar**

톰은 너무 【늙었어】.

Tom was too old.

[[Korean#^ko-Q0576-answer|Compare the answer]]
^ko-Q0576

**ko-Q0577 · Fill the gap**

시간이 ____ 그가 일을 잘 했을 텐데.

If he had enough time, he might have done good work.

[[Korean#^ko-Q0577-answer|Compare the answer]]
^ko-Q0577

**ko-Q0578 · Choose the form**

시간이 ____ 그가 일을 잘 했을 텐데.

If he had enough time, he might have done good work.

Choices: 충분했더라면 / 했어요 / 았어요 / 었어요

[[Korean#^ko-Q0578-answer|Compare the answer]]
^ko-Q0578

**ko-Q0579 · Edit the changed sentence**

지출총액은 200,000엔 【았어요】.

The expenditure totaled 200,000 yen.

[[Korean#^ko-Q0579-answer|Compare the answer]]
^ko-Q0579

**ko-Q0580 · Build the sentence**

Arrange: 이었다. / 지출총액은 / 200,000엔

The expenditure totaled 200,000 yen.

[[Korean#^ko-Q0580-answer|Compare the answer]]
^ko-Q0580

**ko-Q0581 · Write a translation**

Write this in Korean: The text was incomprehensible.

[[Korean#^ko-Q0581-answer|Compare the answer]]
^ko-Q0581

**ko-Q0582 · Explain the grammar**

그 글은 이해할 수 【없었다】.

The text was incomprehensible.

[[Korean#^ko-Q0582-answer|Compare the answer]]
^ko-Q0582

**ko-Q0583 · Fill the gap**

톰은 실수로 동영상을 ____.

Tom deleted a video by accident.

[[Korean#^ko-Q0583-answer|Compare the answer]]
^ko-Q0583

**ko-Q0584 · Choose the form**

톰은 실수로 동영상을 ____.

Tom deleted a video by accident.

Choices: 았어요 / 삭제했어 / 었어요 / 했어요

[[Korean#^ko-Q0584-answer|Compare the answer]]
^ko-Q0584

**ko-Q0585 · Edit the changed sentence**

톰은 피를 【았어요】.

Tom vomited blood.

[[Korean#^ko-Q0585-answer|Compare the answer]]
^ko-Q0585

**ko-Q0586 · Build the sentence**

Arrange: 피를 / 톰은 / 토했다.

Tom vomited blood.

[[Korean#^ko-Q0586-answer|Compare the answer]]
^ko-Q0586

**ko-Q0587 · Write a translation**

Write this in Korean: When I last saw him, he was wearing a blue shirt and white slacks.

[[Korean#^ko-Q0587-answer|Compare the answer]]
^ko-Q0587

**ko-Q0588 · Explain the grammar**

마지막으로 그를 봤을때 그는 파란 셔츠에 흰색 바지를 입고 【있었다】.

When I last saw him, he was wearing a blue shirt and white slacks.

[[Korean#^ko-Q0588-answer|Compare the answer]]
^ko-Q0588

**ko-Q0589 · Fill the gap**

떠날 수밖에 ____.

I had no choice but to leave.

[[Korean#^ko-Q0589-answer|Compare the answer]]
^ko-Q0589

**ko-Q0590 · Choose the form**

떠날 수밖에 ____.

I had no choice but to leave.

Choices: 었어요 / 했어요 / 없었어 / 았어요

[[Korean#^ko-Q0590-answer|Compare the answer]]
^ko-Q0590

**ko-Q0591 · Edit the changed sentence**

그 여자는 자기 아들을 자랑스럽게 【았어요】.

She prides herself on her son.

[[Korean#^ko-Q0591-answer|Compare the answer]]
^ko-Q0591

**ko-Q0592 · Build the sentence**

Arrange: 자랑스럽게 / 여자는 / 생각했다. / 자기 / 아들을 / 그

She prides herself on her son.

[[Korean#^ko-Q0592-answer|Compare the answer]]
^ko-Q0592

**ko-Q0593 · Write a translation**

Write this in Korean: I had dinner with a total stranger.

[[Korean#^ko-Q0593-answer|Compare the answer]]
^ko-Q0593

**ko-Q0594 · Explain the grammar**

생판 모르는 사람과 저녁을 【먹었다】.

I had dinner with a total stranger.

[[Korean#^ko-Q0594-answer|Compare the answer]]
^ko-Q0594

**ko-Q0595 · Fill the gap**

톰은 앞 줄에 ____.

Tom sat in the front row.

[[Korean#^ko-Q0595-answer|Compare the answer]]
^ko-Q0595

**ko-Q0596 · Choose the form**

톰은 앞 줄에 ____.

Tom sat in the front row.

Choices: 앉았다 / 았어요 / 했어요 / 었어요

[[Korean#^ko-Q0596-answer|Compare the answer]]
^ko-Q0596

**ko-Q0597 · Edit the changed sentence**

톰은 메리라는 캐나다인과 【았어요】.

Tom is married to a Canadian named Mary.

[[Korean#^ko-Q0597-answer|Compare the answer]]
^ko-Q0597

**ko-Q0598 · Build the sentence**

Arrange: 톰은 / 캐나다인과 / 메리라는 / 결혼했어.

Tom is married to a Canadian named Mary.

[[Korean#^ko-Q0598-answer|Compare the answer]]
^ko-Q0598

**ko-Q0599 · Write a translation**

Write this in Korean: I shouldn't have stayed away so long.

[[Korean#^ko-Q0599-answer|Compare the answer]]
^ko-Q0599

**ko-Q0600 · Explain the grammar**

내가 그렇게 오랫동안에 멀리 있지 【않았어야】 했어.

I shouldn't have stayed away so long.

[[Korean#^ko-Q0600-answer|Compare the answer]]
^ko-Q0600


### Negation · 50 questions

**ko-Q0601 · Fill the gap**

동물을 학대해서는 ____ 된다.

One must not abuse animals.

[[Korean#^ko-Q0601-answer|Compare the answer]]
^ko-Q0601

**ko-Q0602 · Choose the form**

동물을 학대해서는 ____ 된다.

One must not abuse animals.

Choices: 안 / 못

[[Korean#^ko-Q0602-answer|Compare the answer]]
^ko-Q0602

**ko-Q0603 · Edit the changed sentence**

저 두 명은 사이가 【못】 좋다.

Those two don't get along.

[[Korean#^ko-Q0603-answer|Compare the answer]]
^ko-Q0603

**ko-Q0604 · Build the sentence**

Arrange: 저 / 좋다. / 명은 / 사이가 / 안 / 두

Those two don't get along.

[[Korean#^ko-Q0604-answer|Compare the answer]]
^ko-Q0604

**ko-Q0605 · Write a translation**

Write this in Korean: I don't drink that without sugar.

[[Korean#^ko-Q0605-answer|Compare the answer]]
^ko-Q0605

**ko-Q0606 · Explain the grammar**

저는 설탕이 없어서 【안】 마셔요.

I don't drink that without sugar.

[[Korean#^ko-Q0606-answer|Compare the answer]]
^ko-Q0606

**ko-Q0607 · Fill the gap**

나는 릭을 그가 뉴질랜드로 돌아간 뒤에는 ____ 봤어.

I haven't seen Rick since he returned from New Zealand.

[[Korean#^ko-Q0607-answer|Compare the answer]]
^ko-Q0607

**ko-Q0608 · Choose the form**

나는 릭을 그가 뉴질랜드로 돌아간 뒤에는 ____ 봤어.

I haven't seen Rick since he returned from New Zealand.

Choices: 안 / 못

[[Korean#^ko-Q0608-answer|Compare the answer]]
^ko-Q0608

**ko-Q0609 · Edit the changed sentence**

저는 춤을 잘 【안】 춰요.

I'm not good at dancing.

[[Korean#^ko-Q0609-answer|Compare the answer]]
^ko-Q0609

**ko-Q0610 · Build the sentence**

Arrange: 못 / 잘 / 춰요. / 저는 / 춤을

I'm not good at dancing.

[[Korean#^ko-Q0610-answer|Compare the answer]]
^ko-Q0610

**ko-Q0611 · Write a translation**

Write this in Korean: Since their comeback three years ago, how have they been doing?

[[Korean#^ko-Q0611-answer|Compare the answer]]
^ko-Q0611

**ko-Q0612 · Explain the grammar**

3년 만에 컴백, 그동【안】 어떻게 지냈는가.

Since their comeback three years ago, how have they been doing?

[[Korean#^ko-Q0612-answer|Compare the answer]]
^ko-Q0612

**ko-Q0613 · Fill the gap**

택시로 ____ 왔어.

I didn't come by taxi.

[[Korean#^ko-Q0613-answer|Compare the answer]]
^ko-Q0613

**ko-Q0614 · Choose the form**

택시로 ____ 왔어.

I didn't come by taxi.

Choices: 안 / 못

[[Korean#^ko-Q0614-answer|Compare the answer]]
^ko-Q0614

**ko-Q0615 · Edit the changed sentence**

내 눈에 흙이 들어가기 전까지는 그런 꼴 【안】 보오이다!

Over my dead body shall I witness such a shameful sight.

[[Korean#^ko-Q0615-answer|Compare the answer]]
^ko-Q0615

**ko-Q0616 · Build the sentence**

Arrange: 전까지는 / 내 / 못 / 보오이다! / 그런 / 들어가기 / 흙이 / 꼴 / 눈에

Over my dead body shall I witness such a shameful sight.

[[Korean#^ko-Q0616-answer|Compare the answer]]
^ko-Q0616

**ko-Q0617 · Write a translation**

Write this in Korean: Tom don't care how crazy he looks.

[[Korean#^ko-Q0617-answer|Compare the answer]]
^ko-Q0617

**ko-Q0618 · Explain the grammar**

톰은 자기가 얼마나 미쳐보이는지 신경 【안】 써.

Tom don't care how crazy he looks.

[[Korean#^ko-Q0618-answer|Compare the answer]]
^ko-Q0618

**ko-Q0619 · Fill the gap**

너는 음식 생각 밖에 ____ 한다.

You only think about food.

[[Korean#^ko-Q0619-answer|Compare the answer]]
^ko-Q0619

**ko-Q0620 · Choose the form**

너는 음식 생각 밖에 ____ 한다.

You only think about food.

Choices: 못 / 안

[[Korean#^ko-Q0620-answer|Compare the answer]]
^ko-Q0620

**ko-Q0621 · Edit the changed sentence**

톰은 투표 【못】 했어.

Tom didn't vote.

[[Korean#^ko-Q0621-answer|Compare the answer]]
^ko-Q0621

**ko-Q0622 · Build the sentence**

Arrange: 투표 / 톰은 / 했어. / 안

Tom didn't vote.

[[Korean#^ko-Q0622-answer|Compare the answer]]
^ko-Q0622

**ko-Q0623 · Write a translation**

Write this in Korean: I can't live without you.

[[Korean#^ko-Q0623-answer|Compare the answer]]
^ko-Q0623

**ko-Q0624 · Explain the grammar**

너 없인 【못】 살아.

I can't live without you.

[[Korean#^ko-Q0624-answer|Compare the answer]]
^ko-Q0624

**ko-Q0625 · Fill the gap**

엄마는 운동하는 걸 ____ 좋아한다.

Mom doesn't like to exercise.

[[Korean#^ko-Q0625-answer|Compare the answer]]
^ko-Q0625

**ko-Q0626 · Choose the form**

엄마는 운동하는 걸 ____ 좋아한다.

Mom doesn't like to exercise.

Choices: 못 / 안

[[Korean#^ko-Q0626-answer|Compare the answer]]
^ko-Q0626

**ko-Q0627 · Edit the changed sentence**

내가 버스를 잘【안】 타 가지고 다른 곳으로 갔어.

I took the wrong bus, so I went somewhere else.

[[Korean#^ko-Q0627-answer|Compare the answer]]
^ko-Q0627

**ko-Q0628 · Build the sentence**

Arrange: 다른 / 갔어. / 버스를 / 가지고 / 잘못 / 내가 / 타 / 곳으로

I took the wrong bus, so I went somewhere else.

[[Korean#^ko-Q0628-answer|Compare the answer]]
^ko-Q0628

**ko-Q0629 · Write a translation**

Write this in Korean: Tom didn't seem to be so busy.

[[Korean#^ko-Q0629-answer|Compare the answer]]
^ko-Q0629

**ko-Q0630 · Explain the grammar**

톰 별로 【안】 바빠 보이던데.

Tom didn't seem to be so busy.

[[Korean#^ko-Q0630-answer|Compare the answer]]
^ko-Q0630

**ko-Q0631 · Fill the gap**

8시간 동____ 운전을 한 후에 톰은 더이상 운전을 할 수 없었다.

After driving for eight hours, Tom just couldn't drive any longer.

[[Korean#^ko-Q0631-answer|Compare the answer]]
^ko-Q0631

**ko-Q0632 · Choose the form**

8시간 동____ 운전을 한 후에 톰은 더이상 운전을 할 수 없었다.

After driving for eight hours, Tom just couldn't drive any longer.

Choices: 안 / 못

[[Korean#^ko-Q0632-answer|Compare the answer]]
^ko-Q0632

**ko-Q0633 · Edit the changed sentence**

우리 한동【못】 못 봤지!

We haven't seen you in a while.

[[Korean#^ko-Q0633-answer|Compare the answer]]
^ko-Q0633

**ko-Q0634 · Build the sentence**

Arrange: 우리 / 한동안 / 봤지! / 못

We haven't seen you in a while.

[[Korean#^ko-Q0634-answer|Compare the answer]]
^ko-Q0634

**ko-Q0635 · Write a translation**

Write this in Korean: This is difficult to believe.

[[Korean#^ko-Q0635-answer|Compare the answer]]
^ko-Q0635

**ko-Q0636 · Explain the grammar**

이건 정말 【못】 믿겠다.

This is difficult to believe.

[[Korean#^ko-Q0636-answer|Compare the answer]]
^ko-Q0636

**ko-Q0637 · Fill the gap**

톰은 마리가 존이 그걸 하면 ____ 될 거라는 걸 알았다고 말했다.

Tom said that Mary knew that John might not be allowed to do that.

[[Korean#^ko-Q0637-answer|Compare the answer]]
^ko-Q0637

**ko-Q0638 · Choose the form**

톰은 마리가 존이 그걸 하면 ____ 될 거라는 걸 알았다고 말했다.

Tom said that Mary knew that John might not be allowed to do that.

Choices: 못 / 안

[[Korean#^ko-Q0638-answer|Compare the answer]]
^ko-Q0638

**ko-Q0639 · Edit the changed sentence**

아직 10 분 【못】 됬어요.

It hasn' been 10 minutes yet.

[[Korean#^ko-Q0639-answer|Compare the answer]]
^ko-Q0639

**ko-Q0640 · Build the sentence**

Arrange: 아직 / 됬어요. / 안 / 10 / 분

It hasn' been 10 minutes yet.

[[Korean#^ko-Q0640-answer|Compare the answer]]
^ko-Q0640

**ko-Q0641 · Write a translation**

Write this in Korean: I'm ugly.

[[Korean#^ko-Q0641-answer|Compare the answer]]
^ko-Q0641

**ko-Q0642 · Explain the grammar**

나는 【못】 생겼다.

I'm ugly.

[[Korean#^ko-Q0642-answer|Compare the answer]]
^ko-Q0642

**ko-Q0643 · Fill the gap**

넌 오늘 누가 왔었는지 ____ 믿을걸.

You won't believe who came by today.

[[Korean#^ko-Q0643-answer|Compare the answer]]
^ko-Q0643

**ko-Q0644 · Choose the form**

넌 오늘 누가 왔었는지 ____ 믿을걸.

You won't believe who came by today.

Choices: 못 / 안

[[Korean#^ko-Q0644-answer|Compare the answer]]
^ko-Q0644

**ko-Q0645 · Edit the changed sentence**

일을 안하니까, 돈을 【안】 모으겠어.

Since I don't have a job, I can't save money.

[[Korean#^ko-Q0645-answer|Compare the answer]]
^ko-Q0645

**ko-Q0646 · Build the sentence**

Arrange: 돈을 / 못 / 안하니까, / 모으겠어. / 일을

Since I don't have a job, I can't save money.

[[Korean#^ko-Q0646-answer|Compare the answer]]
^ko-Q0646

**ko-Q0647 · Write a translation**

Write this in Korean: I don't think this is going to work.

[[Korean#^ko-Q0647-answer|Compare the answer]]
^ko-Q0647

**ko-Q0648 · Explain the grammar**

이건 【안】 될 것 같다.

I don't think this is going to work.

[[Korean#^ko-Q0648-answer|Compare the answer]]
^ko-Q0648

**ko-Q0649 · Fill the gap**

난 비벤디 파일을 더 이상 ____ 찾겠다.

I can no longer find the Vivendi file.

[[Korean#^ko-Q0649-answer|Compare the answer]]
^ko-Q0649

**ko-Q0650 · Choose the form**

난 비벤디 파일을 더 이상 ____ 찾겠다.

I can no longer find the Vivendi file.

Choices: 안 / 못

[[Korean#^ko-Q0650-answer|Compare the answer]]
^ko-Q0650


### Existence and absence · 50 questions

**ko-Q0651 · Edit the changed sentence**

바라는 것이 없으면 부족함이 【있어요】.

Not wanting is the same as having.

[[Korean#^ko-Q0651-answer|Compare the answer]]
^ko-Q0651

**ko-Q0652 · Build the sentence**

Arrange: 없다. / 없으면 / 것이 / 부족함이 / 바라는

Not wanting is the same as having.

[[Korean#^ko-Q0652-answer|Compare the answer]]
^ko-Q0652

**ko-Q0653 · Write a translation**

Write this in Korean: The others can't be bothered.

[[Korean#^ko-Q0653-answer|Compare the answer]]
^ko-Q0653

**ko-Q0654 · Explain the grammar**

다른 사람을 귀찮게 할 수 【있다】.

The others can't be bothered.

[[Korean#^ko-Q0654-answer|Compare the answer]]
^ko-Q0654

**ko-Q0655 · Fill the gap**

새로운 친구를 만드는 건 어려울 수 ____.

It can be hard to make new friends.

[[Korean#^ko-Q0655-answer|Compare the answer]]
^ko-Q0655

**ko-Q0656 · Choose the form**

새로운 친구를 만드는 건 어려울 수 ____.

It can be hard to make new friends.

Choices: 없어요 / 있어요 / 있다

[[Korean#^ko-Q0656-answer|Compare the answer]]
^ko-Q0656

**ko-Q0657 · Edit the changed sentence**

이 투명한 액체는 독을 포함하고 【있어요】.

This transparent liquid contains poison.

[[Korean#^ko-Q0657-answer|Compare the answer]]
^ko-Q0657

**ko-Q0658 · Build the sentence**

Arrange: 있다. / 투명한 / 액체는 / 독을 / 포함하고 / 이

This transparent liquid contains poison.

[[Korean#^ko-Q0658-answer|Compare the answer]]
^ko-Q0658

**ko-Q0659 · Write a translation**

Write this in Korean: Do you think Tom is lying?

[[Korean#^ko-Q0659-answer|Compare the answer]]
^ko-Q0659

**ko-Q0660 · Explain the grammar**

너는 톰이 거짓말을 하고 【있다】고 생각하니?

Do you think Tom is lying?

[[Korean#^ko-Q0660-answer|Compare the answer]]
^ko-Q0660

**ko-Q0661 · Fill the gap**

목초지에 양이 많이 ____.

There are a lot of sheep in the pasture.

[[Korean#^ko-Q0661-answer|Compare the answer]]
^ko-Q0661

**ko-Q0662 · Choose the form**

목초지에 양이 많이 ____.

There are a lot of sheep in the pasture.

Choices: 있어요 / 있다 / 없어요

[[Korean#^ko-Q0662-answer|Compare the answer]]
^ko-Q0662

**ko-Q0663 · Edit the changed sentence**

나는 이 소음을 참을 수 【있어요】.

I cannot stand this noise.

[[Korean#^ko-Q0663-answer|Compare the answer]]
^ko-Q0663

**ko-Q0664 · Build the sentence**

Arrange: 참을 / 이 / 나는 / 소음을 / 없다. / 수

I cannot stand this noise.

[[Korean#^ko-Q0664-answer|Compare the answer]]
^ko-Q0664

**ko-Q0665 · Write a translation**

Write this in Korean: We have one kid.

[[Korean#^ko-Q0665-answer|Compare the answer]]
^ko-Q0665

**ko-Q0666 · Explain the grammar**

우린 애가 한 명 【있다】.

We have one kid.

[[Korean#^ko-Q0666-answer|Compare the answer]]
^ko-Q0666

**ko-Q0667 · Fill the gap**

너는 톰에게서 많은 동정심을 바랄 수는 ____.

You can't expect much sympathy from Tom.

[[Korean#^ko-Q0667-answer|Compare the answer]]
^ko-Q0667

**ko-Q0668 · Choose the form**

너는 톰에게서 많은 동정심을 바랄 수는 ____.

You can't expect much sympathy from Tom.

Choices: 없다 / 있어요 / 없어요

[[Korean#^ko-Q0668-answer|Compare the answer]]
^ko-Q0668

**ko-Q0669 · Edit the changed sentence**

글쓴이들은 저 집에 【있어요】.

The writers are in that house.

[[Korean#^ko-Q0669-answer|Compare the answer]]
^ko-Q0669

**ko-Q0670 · Build the sentence**

Arrange: 저 / 글쓴이들은 / 있다. / 집에

The writers are in that house.

[[Korean#^ko-Q0670-answer|Compare the answer]]
^ko-Q0670

**ko-Q0671 · Write a translation**

Write this in Korean: I already know you did that.

[[Korean#^ko-Q0671-answer|Compare the answer]]
^ko-Q0671

**ko-Q0672 · Explain the grammar**

네가 그것을 했다는 것을 이미 알고 【있다】.

I already know you did that.

[[Korean#^ko-Q0672-answer|Compare the answer]]
^ko-Q0672

**ko-Q0673 · Fill the gap**

이 타워의 꼭대기에 회전하는 식당이 ____.

There is a rotating restaurant at the top of this tower.

[[Korean#^ko-Q0673-answer|Compare the answer]]
^ko-Q0673

**ko-Q0674 · Choose the form**

이 타워의 꼭대기에 회전하는 식당이 ____.

There is a rotating restaurant at the top of this tower.

Choices: 있어요 / 없어요 / 있다

[[Korean#^ko-Q0674-answer|Compare the answer]]
^ko-Q0674

**ko-Q0675 · Edit the changed sentence**

공부할 방이 【있어요】.

I have no room to study in.

[[Korean#^ko-Q0675-answer|Compare the answer]]
^ko-Q0675

**ko-Q0676 · Build the sentence**

Arrange: 없다. / 공부할 / 방이

I have no room to study in.

[[Korean#^ko-Q0676-answer|Compare the answer]]
^ko-Q0676

**ko-Q0677 · Write a translation**

Write this in Korean: Hope of finding the child alive is fading rapidly.

[[Korean#^ko-Q0677-answer|Compare the answer]]
^ko-Q0677

**ko-Q0678 · Explain the grammar**

아이를 살아 있는 상태로 찾을 희망이 빠르게 사라지고 【있다】.

Hope of finding the child alive is fading rapidly.

[[Korean#^ko-Q0678-answer|Compare the answer]]
^ko-Q0678

**ko-Q0679 · Fill the gap**

나는 정말 피곤해지고 ____.

I'm getting really tired.

[[Korean#^ko-Q0679-answer|Compare the answer]]
^ko-Q0679

**ko-Q0680 · Choose the form**

나는 정말 피곤해지고 ____.

I'm getting really tired.

Choices: 있어요 / 없어요 / 있다

[[Korean#^ko-Q0680-answer|Compare the answer]]
^ko-Q0680

**ko-Q0681 · Edit the changed sentence**

톰은 응접실에 【있어요】.

Tom is in the drawing room.

[[Korean#^ko-Q0681-answer|Compare the answer]]
^ko-Q0681

**ko-Q0682 · Build the sentence**

Arrange: 톰은 / 있다. / 응접실에

Tom is in the drawing room.

[[Korean#^ko-Q0682-answer|Compare the answer]]
^ko-Q0682

**ko-Q0683 · Write a translation**

Write this in Korean: I wish I could fly.

[[Korean#^ko-Q0683-answer|Compare the answer]]
^ko-Q0683

**ko-Q0684 · Explain the grammar**

내가 날 수 【있다】면 좋을 텐데.

I wish I could fly.

[[Korean#^ko-Q0684-answer|Compare the answer]]
^ko-Q0684

**ko-Q0685 · Fill the gap**

그 남자는 자가용이 ____.

He has his own car.

[[Korean#^ko-Q0685-answer|Compare the answer]]
^ko-Q0685

**ko-Q0686 · Choose the form**

그 남자는 자가용이 ____.

He has his own car.

Choices: 있어요 / 없어요 / 있다

[[Korean#^ko-Q0686-answer|Compare the answer]]
^ko-Q0686

**ko-Q0687 · Edit the changed sentence**

톰은 이해하고 【있어요】는 듯이 고개를 끄덕였다.

Tom nodded understandingly.

[[Korean#^ko-Q0687-answer|Compare the answer]]
^ko-Q0687

**ko-Q0688 · Build the sentence**

Arrange: 듯이 / 끄덕였다. / 톰은 / 고개를 / 이해하고 / 있다는

Tom nodded understandingly.

[[Korean#^ko-Q0688-answer|Compare the answer]]
^ko-Q0688

**ko-Q0689 · Write a translation**

Write this in Korean: Elementary schools are gradually disappearing.

[[Korean#^ko-Q0689-answer|Compare the answer]]
^ko-Q0689

**ko-Q0690 · Explain the grammar**

초등 학교가 점점 사라지고 【있다】.

Elementary schools are gradually disappearing.

[[Korean#^ko-Q0690-answer|Compare the answer]]
^ko-Q0690

**ko-Q0691 · Fill the gap**

너무 어두워서 잘 볼 수 ____.

It's too dark so I can't see very well.

[[Korean#^ko-Q0691-answer|Compare the answer]]
^ko-Q0691

**ko-Q0692 · Choose the form**

너무 어두워서 잘 볼 수 ____.

It's too dark so I can't see very well.

Choices: 없어요 / 없다 / 있어요

[[Korean#^ko-Q0692-answer|Compare the answer]]
^ko-Q0692

**ko-Q0693 · Edit the changed sentence**

바다에는 섬들이 【있어요】.

There are islands in the sea.

[[Korean#^ko-Q0693-answer|Compare the answer]]
^ko-Q0693

**ko-Q0694 · Build the sentence**

Arrange: 섬들이 / 있다. / 바다에는

There are islands in the sea.

[[Korean#^ko-Q0694-answer|Compare the answer]]
^ko-Q0694

**ko-Q0695 · Write a translation**

Write this in Korean: I can't stand him holding forth about his life experience.

[[Korean#^ko-Q0695-answer|Compare the answer]]
^ko-Q0695

**ko-Q0696 · Explain the grammar**

나는 그가 자신의 인생 경험에 대해 열변을 토하는 것을 참을 수가 【없다】.

I can't stand him holding forth about his life experience.

[[Korean#^ko-Q0696-answer|Compare the answer]]
^ko-Q0696

**ko-Q0697 · Fill the gap**

전혀 위험을 감수하지 않으면, 아무 것도 얻을 수 ____.

One who doesn't take risks will not win.

[[Korean#^ko-Q0697-answer|Compare the answer]]
^ko-Q0697

**ko-Q0698 · Choose the form**

전혀 위험을 감수하지 않으면, 아무 것도 얻을 수 ____.

One who doesn't take risks will not win.

Choices: 없어요 / 없다 / 있어요

[[Korean#^ko-Q0698-answer|Compare the answer]]
^ko-Q0698

**ko-Q0699 · Edit the changed sentence**

나는 일찍 자기 때문에 일출을 보려 일찍 일어날 수 【있어요】.

I go to bed early so I can get up to capture the sunrise.

[[Korean#^ko-Q0699-answer|Compare the answer]]
^ko-Q0699

**ko-Q0700 · Build the sentence**

Arrange: 나는 / 수 / 있다. / 일어날 / 일찍 / 때문에 / 일출을 / 일찍 / 보려 / 자기

I go to bed early so I can get up to capture the sunrise.

[[Korean#^ko-Q0700-answer|Compare the answer]]
^ko-Q0700


### Progressive forms · 50 questions

**ko-Q0701 · Write a translation**

Write this in Korean: Tom has been battling depression for many years.

[[Korean#^ko-Q0701-answer|Compare the answer]]
^ko-Q0701

**ko-Q0702 · Explain the grammar**

톰은 수년 간 우울증과 싸우【고 있어】.

Tom has been battling depression for many years.

[[Korean#^ko-Q0702-answer|Compare the answer]]
^ko-Q0702

**ko-Q0703 · Fill the gap**

톰이랑 나는 집을 구하____.

Tom and I are house hunting.

[[Korean#^ko-Q0703-answer|Compare the answer]]
^ko-Q0703

**ko-Q0704 · Choose the form**

톰이랑 나는 집을 구하____.

Tom and I are house hunting.

Choices: 고 있어 / 고 있다 / 고 있어요

[[Korean#^ko-Q0704-answer|Compare the answer]]
^ko-Q0704

**ko-Q0705 · Edit the changed sentence**

나 기대하【고 있다】.

I look forward to it.

[[Korean#^ko-Q0705-answer|Compare the answer]]
^ko-Q0705

**ko-Q0706 · Build the sentence**

Arrange: 기대하고 / 있어. / 나

I look forward to it.

[[Korean#^ko-Q0706-answer|Compare the answer]]
^ko-Q0706

**ko-Q0707 · Write a translation**

Write this in Korean: I'm listening to music, and you?

[[Korean#^ko-Q0707-answer|Compare the answer]]
^ko-Q0707

**ko-Q0708 · Explain the grammar**

나는 음악듣【고 있어】. 넌?

I'm listening to music, and you?

[[Korean#^ko-Q0708-answer|Compare the answer]]
^ko-Q0708

**ko-Q0709 · Fill the gap**

톰은 파란 바지를 입____.

Tom is wearing a blue jeans.

[[Korean#^ko-Q0709-answer|Compare the answer]]
^ko-Q0709

**ko-Q0710 · Choose the form**

톰은 파란 바지를 입____.

Tom is wearing a blue jeans.

Choices: 고 있다 / 고 있어요 / 고 있어

[[Korean#^ko-Q0710-answer|Compare the answer]]
^ko-Q0710

**ko-Q0711 · Edit the changed sentence**

나는 양심의 가책을 느끼【고 있어요】.

I have a guilty consciousness.

[[Korean#^ko-Q0711-answer|Compare the answer]]
^ko-Q0711

**ko-Q0712 · Build the sentence**

Arrange: 나는 / 양심의 / 느끼고 / 가책을 / 있다.

I have a guilty consciousness.

[[Korean#^ko-Q0712-answer|Compare the answer]]
^ko-Q0712

**ko-Q0713 · Write a translation**

Write this in Korean: Korea is now up and coming.

[[Korean#^ko-Q0713-answer|Compare the answer]]
^ko-Q0713

**ko-Q0714 · Explain the grammar**

한국은 떠오르【고 있다】.

Korea is now up and coming.

[[Korean#^ko-Q0714-answer|Compare the answer]]
^ko-Q0714

**ko-Q0715 · Fill the gap**

그는 전화를 기다리____.

He is waiting for a telephone call.

[[Korean#^ko-Q0715-answer|Compare the answer]]
^ko-Q0715

**ko-Q0716 · Choose the form**

그는 전화를 기다리____.

He is waiting for a telephone call.

Choices: 고 있어요 / 고 있다

[[Korean#^ko-Q0716-answer|Compare the answer]]
^ko-Q0716

**ko-Q0717 · Edit the changed sentence**

난 프랑스 소설을 읽【고 있다】.

I'm reading a French novel.

[[Korean#^ko-Q0717-answer|Compare the answer]]
^ko-Q0717

**ko-Q0718 · Build the sentence**

Arrange: 프랑스 / 난 / 있어. / 읽고 / 소설을

I'm reading a French novel.

[[Korean#^ko-Q0718-answer|Compare the answer]]
^ko-Q0718

**ko-Q0719 · Write a translation**

Write this in Korean: Society is changing.

[[Korean#^ko-Q0719-answer|Compare the answer]]
^ko-Q0719

**ko-Q0720 · Explain the grammar**

사회가 변화하【고 있다】.

Society is changing.

[[Korean#^ko-Q0720-answer|Compare the answer]]
^ko-Q0720

**ko-Q0721 · Fill the gap**

톰은 뭔가를 쏘____.

Tom is shouting something.

[[Korean#^ko-Q0721-answer|Compare the answer]]
^ko-Q0721

**ko-Q0722 · Choose the form**

톰은 뭔가를 쏘____.

Tom is shouting something.

Choices: 고 있어요 / 고 있다 / 고 있어

[[Korean#^ko-Q0722-answer|Compare the answer]]
^ko-Q0722

**ko-Q0723 · Edit the changed sentence**

톰은 노란 셔츠를 입【고 있다】.

Tom is wearing a yellow shirt.

[[Korean#^ko-Q0723-answer|Compare the answer]]
^ko-Q0723

**ko-Q0724 · Build the sentence**

Arrange: 셔츠를 / 톰은 / 노란 / 입고 / 있어.

Tom is wearing a yellow shirt.

[[Korean#^ko-Q0724-answer|Compare the answer]]
^ko-Q0724

**ko-Q0725 · Write a translation**

Write this in Korean: The prices of raw materials such as oil or coal continue to rise.

[[Korean#^ko-Q0725-answer|Compare the answer]]
^ko-Q0725

**ko-Q0726 · Explain the grammar**

기름이나 석탄과 같은 원자재의 가격이 계속 상승하【고 있다】.

The prices of raw materials such as oil or coal continue to rise.

[[Korean#^ko-Q0726-answer|Compare the answer]]
^ko-Q0726

**ko-Q0727 · Fill the gap**

나는 고양이 두 마리를 가지____.

I have two cats.

[[Korean#^ko-Q0727-answer|Compare the answer]]
^ko-Q0727

**ko-Q0728 · Choose the form**

나는 고양이 두 마리를 가지____.

I have two cats.

Choices: 고 있어요 / 고 있다

[[Korean#^ko-Q0728-answer|Compare the answer]]
^ko-Q0728

**ko-Q0729 · Edit the changed sentence**

이 투명한 액체는 독 성분을 포함하【고 있어요】.

This transparent liquid contains a kind of poison.

[[Korean#^ko-Q0729-answer|Compare the answer]]
^ko-Q0729

**ko-Q0730 · Build the sentence**

Arrange: 독 / 성분을 / 포함하고 / 투명한 / 이 / 있다. / 액체는

This transparent liquid contains a kind of poison.

[[Korean#^ko-Q0730-answer|Compare the answer]]
^ko-Q0730

**ko-Q0731 · Write a translation**

Write this in Korean: Why are you still working?

[[Korean#^ko-Q0731-answer|Compare the answer]]
^ko-Q0731

**ko-Q0732 · Explain the grammar**

왜 아직도 일하【고 있어】?

Why are you still working?

[[Korean#^ko-Q0732-answer|Compare the answer]]
^ko-Q0732

**ko-Q0733 · Fill the gap**

밀리는 사과를 먹____요.

Millie is eating an apple.

[[Korean#^ko-Q0733-answer|Compare the answer]]
^ko-Q0733

**ko-Q0734 · Choose the form**

밀리는 사과를 먹____요.

Millie is eating an apple.

Choices: 고 있어요 / 고 있다 / 고 있어

[[Korean#^ko-Q0734-answer|Compare the answer]]
^ko-Q0734

**ko-Q0735 · Edit the changed sentence**

톰은 총을 들【고 있다】.

Tom is holding a gun.

[[Korean#^ko-Q0735-answer|Compare the answer]]
^ko-Q0735

**ko-Q0736 · Build the sentence**

Arrange: 들고 / 톰은 / 총을 / 있어.

Tom is holding a gun.

[[Korean#^ko-Q0736-answer|Compare the answer]]
^ko-Q0736

**ko-Q0737 · Write a translation**

Write this in Korean: People are dying now.

[[Korean#^ko-Q0737-answer|Compare the answer]]
^ko-Q0737

**ko-Q0738 · Explain the grammar**

사람들이 지금 죽어가【고 있어】.

People are dying now.

[[Korean#^ko-Q0738-answer|Compare the answer]]
^ko-Q0738

**ko-Q0739 · Fill the gap**

너는 날 천천히 죽이____.

You are killing me slowly.

[[Korean#^ko-Q0739-answer|Compare the answer]]
^ko-Q0739

**ko-Q0740 · Choose the form**

너는 날 천천히 죽이____.

You are killing me slowly.

Choices: 고 있어 / 고 있어요 / 고 있다

[[Korean#^ko-Q0740-answer|Compare the answer]]
^ko-Q0740

**ko-Q0741 · Edit the changed sentence**

그녀는 의학을 전공하【고 있다】.

She majors in medicine.

[[Korean#^ko-Q0741-answer|Compare the answer]]
^ko-Q0741

**ko-Q0742 · Build the sentence**

Arrange: 전공하고 / 의학을 / 그녀는 / 있습니다.

She majors in medicine.

[[Korean#^ko-Q0742-answer|Compare the answer]]
^ko-Q0742

**ko-Q0743 · Write a translation**

Write this in Korean: I'm still learning French.

[[Korean#^ko-Q0743-answer|Compare the answer]]
^ko-Q0743

**ko-Q0744 · Explain the grammar**

난 아직도 프랑스어를 배우【고 있어】.

I'm still learning French.

[[Korean#^ko-Q0744-answer|Compare the answer]]
^ko-Q0744

**ko-Q0745 · Fill the gap**

미국에서는 아편유사제 오남용으로 인해 매일 130명 이상의 사람들이 숨지____.

More than 130 people in the United States die each day after abusing opioids.

[[Korean#^ko-Q0745-answer|Compare the answer]]
^ko-Q0745

**ko-Q0746 · Choose the form**

미국에서는 아편유사제 오남용으로 인해 매일 130명 이상의 사람들이 숨지____.

More than 130 people in the United States die each day after abusing opioids.

Choices: 고 있어요 / 고 있다

[[Korean#^ko-Q0746-answer|Compare the answer]]
^ko-Q0746

**ko-Q0747 · Edit the changed sentence**

흥! 아무도 내가 만드는 문장을 번역 안하【고 있다】!

Hey! Nobody is translating my sentences!

[[Korean#^ko-Q0747-answer|Compare the answer]]
^ko-Q0747

**ko-Q0748 · Build the sentence**

Arrange: 있어! / 안하고 / 내가 / 번역 / 문장을 / 흥! / 만드는 / 아무도

Hey! Nobody is translating my sentences!

[[Korean#^ko-Q0748-answer|Compare the answer]]
^ko-Q0748

**ko-Q0749 · Write a translation**

Write this in Korean: The anthropologist says old customs still prevail in the province.

[[Korean#^ko-Q0749-answer|Compare the answer]]
^ko-Q0749

**ko-Q0750 · Explain the grammar**

이 인류학자에 따르면 이 지역에서는 옛날 관습이 아직도 행해지【고 있다】.

The anthropologist says old customs still prevail in the province.

[[Korean#^ko-Q0750-answer|Compare the answer]]
^ko-Q0750


### Conditional linking · 50 questions

**ko-Q0751 · Fill the gap**

사공이 ____ 배가 산으로 간다.

Too many cooks spoil the broth.

[[Korean#^ko-Q0751-answer|Compare the answer]]
^ko-Q0751

**ko-Q0752 · Choose the form**

사공이 ____ 배가 산으로 간다.

Too many cooks spoil the broth.

Choices: 면 / 많으면 / 지만 / 으면

[[Korean#^ko-Q0752-answer|Compare the answer]]
^ko-Q0752

**ko-Q0753 · Edit the changed sentence**

톰이 네가 이걸 하는 걸 【으면】 울게 될 걸.

If Tom saw you doing that, he'd cry.

[[Korean#^ko-Q0753-answer|Compare the answer]]
^ko-Q0753

**ko-Q0754 · Build the sentence**

Arrange: 톰이 / 걸. / 울게 / 본다면 / 이걸 / 하는 / 될 / 걸 / 네가

If Tom saw you doing that, he'd cry.

[[Korean#^ko-Q0754-answer|Compare the answer]]
^ko-Q0754

**ko-Q0755 · Write a translation**

Write this in Korean: Do you love him like a brother or do you love-love him?

[[Korean#^ko-Q0755-answer|Compare the answer]]
^ko-Q0755

**ko-Q0756 · Explain the grammar**

너 그 사람을 오빠-동생으로 생각하니? 【아니면】 애인으로 사랑하니?

Do you love him like a brother or do you love-love him?

[[Korean#^ko-Q0756-answer|Compare the answer]]
^ko-Q0756

**ko-Q0757 · Fill the gap**

전하실 말씀 ____ 남겨주세요.

I can take a message.

[[Korean#^ko-Q0757-answer|Compare the answer]]
^ko-Q0757

**ko-Q0758 · Choose the form**

전하실 말씀 ____ 남겨주세요.

I can take a message.

Choices: 지만 / 면 / 으면 / 있으시면

[[Korean#^ko-Q0758-answer|Compare the answer]]
^ko-Q0758

**ko-Q0759 · Edit the changed sentence**

내가 할 수 있는게 더 【으면】 좋았을 걸.

I wish there was more I could've done.

[[Korean#^ko-Q0759-answer|Compare the answer]]
^ko-Q0759

**ko-Q0760 · Build the sentence**

Arrange: 있는게 / 할 / 더 / 좋았을 / 내가 / 걸. / 있었으면 / 수

I wish there was more I could've done.

[[Korean#^ko-Q0760-answer|Compare the answer]]
^ko-Q0760

**ko-Q0761 · Write a translation**

Write this in Korean: Tom would be very surprised if Mary did that.

[[Korean#^ko-Q0761-answer|Compare the answer]]
^ko-Q0761

**ko-Q0762 · Explain the grammar**

메리가 그걸 【한다면】 톰이 아주 놀라겠는걸.

Tom would be very surprised if Mary did that.

[[Korean#^ko-Q0762-answer|Compare the answer]]
^ko-Q0762

**ko-Q0763 · Fill the gap**

만약에 네가 나쁜 짓을 ____ 알려주는게 좋을거야.

You'd better tell me if you did something wrong.

[[Korean#^ko-Q0763-answer|Compare the answer]]
^ko-Q0763

**ko-Q0764 · Choose the form**

만약에 네가 나쁜 짓을 ____ 알려주는게 좋을거야.

You'd better tell me if you did something wrong.

Choices: 면 / 했다면 / 으면 / 지만

[[Korean#^ko-Q0764-answer|Compare the answer]]
^ko-Q0764

**ko-Q0765 · Edit the changed sentence**

네가 톰을 도와주지 【으면】 톰은 곤란에 처할 거야.

If you don't help Tom, he'll have trouble doing it.

[[Korean#^ko-Q0765-answer|Compare the answer]]
^ko-Q0765

**ko-Q0766 · Build the sentence**

Arrange: 처할 / 않는다면 / 곤란에 / 도와주지 / 톰은 / 네가 / 톰을 / 거야.

If you don't help Tom, he'll have trouble doing it.

[[Korean#^ko-Q0766-answer|Compare the answer]]
^ko-Q0766

**ko-Q0767 · Write a translation**

Write this in Korean: It'd be good if it wouldn't rain tomorrow.

[[Korean#^ko-Q0767-answer|Compare the answer]]
^ko-Q0767

**ko-Q0768 · Explain the grammar**

내일 비가 【안오면】 좋겠는데.

It'd be good if it wouldn't rain tomorrow.

[[Korean#^ko-Q0768-answer|Compare the answer]]
^ko-Q0768

**ko-Q0769 · Fill the gap**

사공이 ____ 배가 거꾸로 간다.

Too many cooks spoil the broth.

[[Korean#^ko-Q0769-answer|Compare the answer]]
^ko-Q0769

**ko-Q0770 · Choose the form**

사공이 ____ 배가 거꾸로 간다.

Too many cooks spoil the broth.

Choices: 으면 / 면 / 많으면 / 지만

[[Korean#^ko-Q0770-answer|Compare the answer]]
^ko-Q0770

**ko-Q0771 · Edit the changed sentence**

이 【으면】 될까요?

Will this dictionary do?

[[Korean#^ko-Q0771-answer|Compare the answer]]
^ko-Q0771

**ko-Q0772 · Build the sentence**

Arrange: 될까요? / 이 / 사전이면

Will this dictionary do?

[[Korean#^ko-Q0772-answer|Compare the answer]]
^ko-Q0772

**ko-Q0773 · Write a translation**

Write this in Korean: I'd like you to go away.

[[Korean#^ko-Q0773-answer|Compare the answer]]
^ko-Q0773

**ko-Q0774 · Explain the grammar**

네가 저리 【갔으면】 좋겠어.

I'd like you to go away.

[[Korean#^ko-Q0774-answer|Compare the answer]]
^ko-Q0774

**ko-Q0775 · Fill the gap**

메리는 보스턴으로 ____ 더 행복할 것이라고 확신했다.

Mary was convinced that she'd be happier if she moved to Boston.

[[Korean#^ko-Q0775-answer|Compare the answer]]
^ko-Q0775

**ko-Q0776 · Choose the form**

메리는 보스턴으로 ____ 더 행복할 것이라고 확신했다.

Mary was convinced that she'd be happier if she moved to Boston.

Choices: 으면 / 면 / 이사가면 / 지만

[[Korean#^ko-Q0776-answer|Compare the answer]]
^ko-Q0776

**ko-Q0777 · Edit the changed sentence**

내 일을 어떻게 【으면】 되는지 나한테 말하고 있는거에요?

Are you telling me how to do my job?

[[Korean#^ko-Q0777-answer|Compare the answer]]
^ko-Q0777

**ko-Q0778 · Build the sentence**

Arrange: 말하고 / 하면 / 되는지 / 내 / 나한테 / 있는거에요? / 일을 / 어떻게

Are you telling me how to do my job?

[[Korean#^ko-Q0778-answer|Compare the answer]]
^ko-Q0778

**ko-Q0779 · Write a translation**

Write this in Korean: I want Tom to understand why he has to leave.

[[Korean#^ko-Q0779-answer|Compare the answer]]
^ko-Q0779

**ko-Q0780 · Explain the grammar**

톰이 자신이 왜 떠나야 하는지를 【이해했으면】 좋겠어.

I want Tom to understand why he has to leave.

[[Korean#^ko-Q0780-answer|Compare the answer]]
^ko-Q0780

**ko-Q0781 · Fill the gap**

톰이 그렇게 어리지 ____ 그걸 함으로써 용서받지 못했을 거야.

I think Tom wouldn't be forgiven for doing that if he weren't so young.

[[Korean#^ko-Q0781-answer|Compare the answer]]
^ko-Q0781

**ko-Q0782 · Choose the form**

톰이 그렇게 어리지 ____ 그걸 함으로써 용서받지 못했을 거야.

I think Tom wouldn't be forgiven for doing that if he weren't so young.

Choices: 지만 / 으면 / 면 / 않았다면

[[Korean#^ko-Q0782-answer|Compare the answer]]
^ko-Q0782

**ko-Q0783 · Edit the changed sentence**

내가 만약 진실을 【으면】 난 살해 당할 거야.

If I tell the truth, I'll be killed.

[[Korean#^ko-Q0783-answer|Compare the answer]]
^ko-Q0783

**ko-Q0784 · Build the sentence**

Arrange: 만약 / 말하면 / 난 / 살해 / 거야. / 내가 / 진실을 / 당할

If I tell the truth, I'll be killed.

[[Korean#^ko-Q0784-answer|Compare the answer]]
^ko-Q0784

**ko-Q0785 · Write a translation**

Write this in Korean: If I were in your position I wouldn't do that job.

[[Korean#^ko-Q0785-answer|Compare the answer]]
^ko-Q0785

**ko-Q0786 · Explain the grammar**

네 【입장이라면】 나는 그 일을 하지 않겠다.

If I were in your position I wouldn't do that job.

[[Korean#^ko-Q0786-answer|Compare the answer]]
^ko-Q0786

**ko-Q0787 · Fill the gap**

문장에 틀렸거나 ____ 꼭 고쳐주시기 바랍니다!

Please edit the sentence if it is wrong or awkward.

[[Korean#^ko-Q0787-answer|Compare the answer]]
^ko-Q0787

**ko-Q0788 · Choose the form**

문장에 틀렸거나 ____ 꼭 고쳐주시기 바랍니다!

Please edit the sentence if it is wrong or awkward.

Choices: 지만 / 어색하다면 / 으면 / 면

[[Korean#^ko-Q0788-answer|Compare the answer]]
^ko-Q0788

**ko-Q0789 · Edit the changed sentence**

그가 【으면】 메모를 전해주세요.

Give him the message when he comes back.

[[Korean#^ko-Q0789-answer|Compare the answer]]
^ko-Q0789

**ko-Q0790 · Build the sentence**

Arrange: 돌아오면 / 메모를 / 그가 / 전해주세요.

Give him the message when he comes back.

[[Korean#^ko-Q0790-answer|Compare the answer]]
^ko-Q0790

**ko-Q0791 · Write a translation**

Write this in Korean: I wish I were an only child.

[[Korean#^ko-Q0791-answer|Compare the answer]]
^ko-Q0791

**ko-Q0792 · Explain the grammar**

내가 【외동이었으면】 좋았을 텐데.

I wish I were an only child.

[[Korean#^ko-Q0792-answer|Compare the answer]]
^ko-Q0792

**ko-Q0793 · Fill the gap**

물이 ____ 인류의 생존은 가능하지 않았을 겁니다.

If it were not for water, human life would be impossible.

[[Korean#^ko-Q0793-answer|Compare the answer]]
^ko-Q0793

**ko-Q0794 · Choose the form**

물이 ____ 인류의 생존은 가능하지 않았을 겁니다.

If it were not for water, human life would be impossible.

Choices: 지만 / 면 / 으면 / 없었다면

[[Korean#^ko-Q0794-answer|Compare the answer]]
^ko-Q0794

**ko-Q0795 · Edit the changed sentence**

내가 원어민이랑 【으면】 내 프랑스어 실력은 훨씬 더 나을 텐데.

My French would likely be much better today if I'd studied with a native speaker.

[[Korean#^ko-Q0795-answer|Compare the answer]]
^ko-Q0795

**ko-Q0796 · Build the sentence**

Arrange: 원어민이랑 / 훨씬 / 내 / 실력은 / 공부한다면 / 텐데. / 나을 / 더 / 내가 / 프랑스어

My French would likely be much better today if I'd studied with a native speaker.

[[Korean#^ko-Q0796-answer|Compare the answer]]
^ko-Q0796

**ko-Q0797 · Write a translation**

Write this in Korean: I hope my Spanish improves quickly.

[[Korean#^ko-Q0797-answer|Compare the answer]]
^ko-Q0797

**ko-Q0798 · Explain the grammar**

빨리 스페인어가 【늘었으면】 좋겠네.

I hope my Spanish improves quickly.

[[Korean#^ko-Q0798-answer|Compare the answer]]
^ko-Q0798

**ko-Q0799 · Fill the gap**

난 톰이 내 친구들을 ____ 했어.

I wanted Tom to meet my friends.

[[Korean#^ko-Q0799-answer|Compare the answer]]
^ko-Q0799

**ko-Q0800 · Choose the form**

난 톰이 내 친구들을 ____ 했어.

I wanted Tom to meet my friends.

Choices: 으면 / 면 / 지만 / 만났으면

[[Korean#^ko-Q0800-answer|Compare the answer]]
^ko-Q0800


### Cause and sequence · 50 questions

**ko-Q0801 · Edit the changed sentence**

어제 너무 많이 【니까】 이제 난 병이 나요.

Yesterday I ate too much and now I feel sick.

[[Korean#^ko-Q0801-answer|Compare the answer]]
^ko-Q0801

**ko-Q0802 · Build the sentence**

Arrange: 먹어서 / 너무 / 많이 / 나요. / 난 / 어제 / 병이 / 이제

Yesterday I ate too much and now I feel sick.

[[Korean#^ko-Q0802-answer|Compare the answer]]
^ko-Q0802

**ko-Q0803 · Write a translation**

Write this in Korean: I thought you might be lonely, so I came over with a bottle of wine.

[[Korean#^ko-Q0803-answer|Compare the answer]]
^ko-Q0803

**ko-Q0804 · Explain the grammar**

니가 좀 외로울 것 【같아서】 내가 와인 한 병을 들고 왔지.

I thought you might be lonely, so I came over with a bottle of wine.

[[Korean#^ko-Q0804-answer|Compare the answer]]
^ko-Q0804

**ko-Q0805 · Fill the gap**

오늘 ____ 두껍게 입고 다녀.

It's cold today, so wear thick clothes.

[[Korean#^ko-Q0805-answer|Compare the answer]]
^ko-Q0805

**ko-Q0806 · Choose the form**

오늘 ____ 두껍게 입고 다녀.

It's cold today, so wear thick clothes.

Choices: 아서 / 니까 / 추우니까 / 어서

[[Korean#^ko-Q0806-answer|Compare the answer]]
^ko-Q0806

**ko-Q0807 · Edit the changed sentence**

먹기 【니까】 살지 말고, 살기 위해서 먹어라.

One must eat to live, and not live to eat.

[[Korean#^ko-Q0807-answer|Compare the answer]]
^ko-Q0807

**ko-Q0808 · Build the sentence**

Arrange: 위해서 / 먹어라. / 말고, / 위해서 / 살기 / 먹기 / 살지

One must eat to live, and not live to eat.

[[Korean#^ko-Q0808-answer|Compare the answer]]
^ko-Q0808

**ko-Q0809 · Write a translation**

Write this in Korean: You look tired, so you should go to bed early.

[[Korean#^ko-Q0809-answer|Compare the answer]]
^ko-Q0809

**ko-Q0810 · Explain the grammar**

피곤해 【보이니까】 일찍 자는 것이 좋겠다.

You look tired, so you should go to bed early.

[[Korean#^ko-Q0810-answer|Compare the answer]]
^ko-Q0810

**ko-Q0811 · Fill the gap**

3달전에 학생이 너무 ____ 수업이 없어졌던 거다.

Three months ago there were so few students we stopped the class.

[[Korean#^ko-Q0811-answer|Compare the answer]]
^ko-Q0811

**ko-Q0812 · Choose the form**

3달전에 학생이 너무 ____ 수업이 없어졌던 거다.

Three months ago there were so few students we stopped the class.

Choices: 아서 / 니까 / 어서 / 적어서

[[Korean#^ko-Q0812-answer|Compare the answer]]
^ko-Q0812

**ko-Q0813 · Edit the changed sentence**

내가 그를 꽉 【니까】 울었다.

I hugged him tightly and cried.

[[Korean#^ko-Q0813-answer|Compare the answer]]
^ko-Q0813

**ko-Q0814 · Build the sentence**

Arrange: 그를 / 안아서 / 내가 / 꽉 / 울었다.

I hugged him tightly and cried.

[[Korean#^ko-Q0814-answer|Compare the answer]]
^ko-Q0814

**ko-Q0815 · Write a translation**

Write this in Korean: Today was so hard I think I'll sleep well tonight.

[[Korean#^ko-Q0815-answer|Compare the answer]]
^ko-Q0815

**ko-Q0816 · Explain the grammar**

오늘은 이렇게 【힘들었어서】 깊게 잘 잘 것 같다.

Today was so hard I think I'll sleep well tonight.

[[Korean#^ko-Q0816-answer|Compare the answer]]
^ko-Q0816

**ko-Q0817 · Fill the gap**

____ 운전 하세요.

Please drive carefully.

[[Korean#^ko-Q0817-answer|Compare the answer]]
^ko-Q0817

**ko-Q0818 · Choose the form**

____ 운전 하세요.

Please drive carefully.

Choices: 아서 / 조심해서 / 니까 / 어서

[[Korean#^ko-Q0818-answer|Compare the answer]]
^ko-Q0818

**ko-Q0819 · Edit the changed sentence**

톰은 손을 【니까】 지팡이를 잡았다.

Tom reached for his cane.

[[Korean#^ko-Q0819-answer|Compare the answer]]
^ko-Q0819

**ko-Q0820 · Build the sentence**

Arrange: 지팡이를 / 뻗어서 / 손을 / 잡았다. / 톰은

Tom reached for his cane.

[[Korean#^ko-Q0820-answer|Compare the answer]]
^ko-Q0820

**ko-Q0821 · Write a translation**

Write this in Korean: Customer satisfaction is our number one priority.

[[Korean#^ko-Q0821-answer|Compare the answer]]
^ko-Q0821

**ko-Q0822 · Explain the grammar**

우리는 고객의 만족을 【위해서】 최선을 다한다.

Customer satisfaction is our number one priority.

[[Korean#^ko-Q0822-answer|Compare the answer]]
^ko-Q0822

**ko-Q0823 · Fill the gap**

____ 고객 서비스 상담원에게 말하기 전까지 연결 대기 큐에서 20분이나 기다렸어야 했어.

I had to wait 20 minutes on the phone before reaching the customer service rep.

[[Korean#^ko-Q0823-answer|Compare the answer]]
^ko-Q0823

**ko-Q0824 · Choose the form**

____ 고객 서비스 상담원에게 말하기 전까지 연결 대기 큐에서 20분이나 기다렸어야 했어.

I had to wait 20 minutes on the phone before reaching the customer service rep.

Choices: 아서 / 어서 / 통화해서 / 니까

[[Korean#^ko-Q0824-answer|Compare the answer]]
^ko-Q0824

**ko-Q0825 · Edit the changed sentence**

끼어 【니까】 죄송합니다.

I'm sorry for interrupting.

[[Korean#^ko-Q0825-answer|Compare the answer]]
^ko-Q0825

**ko-Q0826 · Build the sentence**

Arrange: 들어서 / 죄송합니다. / 끼어

I'm sorry for interrupting.

[[Korean#^ko-Q0826-answer|Compare the answer]]
^ko-Q0826

**ko-Q0827 · Write a translation**

Write this in Korean: This information is very important to us.

[[Korean#^ko-Q0827-answer|Compare the answer]]
^ko-Q0827

**ko-Q0828 · Explain the grammar**

이 정보는 우리한테 【있어서】 정말 중요해요.

This information is very important to us.

[[Korean#^ko-Q0828-answer|Compare the answer]]
^ko-Q0828

**ko-Q0829 · Fill the gap**

나는 수학에 ____ 최고다.

I'm best at math.

[[Korean#^ko-Q0829-answer|Compare the answer]]
^ko-Q0829

**ko-Q0830 · Choose the form**

나는 수학에 ____ 최고다.

I'm best at math.

Choices: 아서 / 있어서 / 니까 / 어서

[[Korean#^ko-Q0830-answer|Compare the answer]]
^ko-Q0830

**ko-Q0831 · Edit the changed sentence**

그에 【니까】 뭘 알아?

What do you know about him?

[[Korean#^ko-Q0831-answer|Compare the answer]]
^ko-Q0831

**ko-Q0832 · Build the sentence**

Arrange: 대해서 / 그에 / 뭘 / 알아?

What do you know about him?

[[Korean#^ko-Q0832-answer|Compare the answer]]
^ko-Q0832

**ko-Q0833 · Write a translation**

Write this in Korean: Mathematics is the part of science you could continue to do if you woke up tomorrow and discovered the universe was gone.

[[Korean#^ko-Q0833-answer|Compare the answer]]
^ko-Q0833

**ko-Q0834 · Explain the grammar**

당신이 내일 아침에 일어나서 우주가 사라졌다는 것을 알게 된다면 수학은 당신이 【계속해서】 연구할 수 있는 과학의 한 부분입니다.

Mathematics is the part of science you could continue to do if you woke up tomorrow and discovered the universe was gone.

[[Korean#^ko-Q0834-answer|Compare the answer]]
^ko-Q0834

**ko-Q0835 · Fill the gap**

정말 ____ 그러는데, 두 사람 무슨 사이야?

I am really curious, how do you two know each other?

[[Korean#^ko-Q0835-answer|Compare the answer]]
^ko-Q0835

**ko-Q0836 · Choose the form**

정말 ____ 그러는데, 두 사람 무슨 사이야?

I am really curious, how do you two know each other?

Choices: 아서 / 니까 / 어서 / 궁금해서

[[Korean#^ko-Q0836-answer|Compare the answer]]
^ko-Q0836

**ko-Q0837 · Edit the changed sentence**

탐을 메리를 【니까】 설거지를 했다.

Tom did the dishes for Mary.

[[Korean#^ko-Q0837-answer|Compare the answer]]
^ko-Q0837

**ko-Q0838 · Build the sentence**

Arrange: 위해서 / 설거지를 / 탐을 / 했다. / 메리를

Tom did the dishes for Mary.

[[Korean#^ko-Q0838-answer|Compare the answer]]
^ko-Q0838

**ko-Q0839 · Write a translation**

Write this in Korean: Today one of my colleague told about his job.

[[Korean#^ko-Q0839-answer|Compare the answer]]
^ko-Q0839

**ko-Q0840 · Explain the grammar**

오늘 동료 한명이 본인 직장에 【대해서】 애기해줬어.

Today one of my colleague told about his job.

[[Korean#^ko-Q0840-answer|Compare the answer]]
^ko-Q0840

**ko-Q0841 · Fill the gap**

하늘을 ____ 보면 그 산은 참 예뻐 보였다.

Seen against the sky, the mountain looked really beautiful.

[[Korean#^ko-Q0841-answer|Compare the answer]]
^ko-Q0841

**ko-Q0842 · Choose the form**

하늘을 ____ 보면 그 산은 참 예뻐 보였다.

Seen against the sky, the mountain looked really beautiful.

Choices: 어서 / 니까 / 아서 / 마주해서

[[Korean#^ko-Q0842-answer|Compare the answer]]
^ko-Q0842

**ko-Q0843 · Edit the changed sentence**

톰이 【니까】 내 자신이 싫어.

I hate myself for hating Tom.

[[Korean#^ko-Q0843-answer|Compare the answer]]
^ko-Q0843

**ko-Q0844 · Build the sentence**

Arrange: 톰이 / 싫어서 / 자신이 / 싫어. / 내

I hate myself for hating Tom.

[[Korean#^ko-Q0844-answer|Compare the answer]]
^ko-Q0844

**ko-Q0845 · Write a translation**

Write this in Korean: Tom thinks Mary is too old for him.

[[Korean#^ko-Q0845-answer|Compare the answer]]
^ko-Q0845

**ko-Q0846 · Explain the grammar**

톰은 메리가 자신한테 【있어서】 너무 나이가 많다고 여기고 있어.

Tom thinks Mary is too old for him.

[[Korean#^ko-Q0846-answer|Compare the answer]]
^ko-Q0846

**ko-Q0847 · Fill the gap**

비가 ____ 우산을 가지고 오세요.

It's raining, so please bring your umbrella.

[[Korean#^ko-Q0847-answer|Compare the answer]]
^ko-Q0847

**ko-Q0848 · Choose the form**

비가 ____ 우산을 가지고 오세요.

It's raining, so please bring your umbrella.

Choices: 어서 / 니까 / 오니까 / 아서

[[Korean#^ko-Q0848-answer|Compare the answer]]
^ko-Q0848

**ko-Q0849 · Edit the changed sentence**

사무총장은 전쟁 중인 두 파벌 간에 평화조약을 협상하기 【니까】 필사적으로 노력하고 있다.

The Secretary General is making a last-ditch effort to negotiate a peace treaty between the two warring factions.

[[Korean#^ko-Q0849-answer|Compare the answer]]
^ko-Q0849

**ko-Q0850 · Build the sentence**

Arrange: 협상하기 / 파벌 / 노력하고 / 간에 / 위해서 / 필사적으로 / 전쟁 / 중인 / 두 / 평화조약을 / 사무총장은 / 있다.

The Secretary General is making a last-ditch effort to negotiate a peace treaty between the two warring factions.

[[Korean#^ko-Q0850-answer|Compare the answer]]
^ko-Q0850


### Contrast and coordination · 50 questions

**ko-Q0851 · Write a translation**

Write this in Korean: Where do you want to go?

[[Korean#^ko-Q0851-answer|Compare the answer]]
^ko-Q0851

**ko-Q0852 · Explain the grammar**

너 어디 【가고】 싶니?

Where do you want to go?

[[Korean#^ko-Q0852-answer|Compare the answer]]
^ko-Q0852

**ko-Q0853 · Fill the gap**

개는 잘 짖는 ____ 좋은 개가 아니다.

A dog who is a good barker is not a good dog.

[[Korean#^ko-Q0853-answer|Compare the answer]]
^ko-Q0853

**ko-Q0854 · Choose the form**

개는 잘 짖는 ____ 좋은 개가 아니다.

A dog who is a good barker is not a good dog.

Choices: 고 / 지만 / 다고

[[Korean#^ko-Q0854-answer|Compare the answer]]
^ko-Q0854

**ko-Q0855 · Edit the changed sentence**

그게 내가 【지만】 있는 전부야.

That's all I'm doing.

[[Korean#^ko-Q0855-answer|Compare the answer]]
^ko-Q0855

**ko-Q0856 · Build the sentence**

Arrange: 내가 / 하고 / 전부야. / 있는 / 그게

That's all I'm doing.

[[Korean#^ko-Q0856-answer|Compare the answer]]
^ko-Q0856

**ko-Q0857 · Write a translation**

Write this in Korean: I want to donate money.

[[Korean#^ko-Q0857-answer|Compare the answer]]
^ko-Q0857

**ko-Q0858 · Explain the grammar**

나는 기부를 【하고】 싶다.

I want to donate money.

[[Korean#^ko-Q0858-answer|Compare the answer]]
^ko-Q0858

**ko-Q0859 · Fill the gap**

그게 네가 ____ 싶은 말 전부니?

Is that all you want to say?

[[Korean#^ko-Q0859-answer|Compare the answer]]
^ko-Q0859

**ko-Q0860 · Choose the form**

그게 네가 ____ 싶은 말 전부니?

Is that all you want to say?

Choices: 지만 / 하고 / 고

[[Korean#^ko-Q0860-answer|Compare the answer]]
^ko-Q0860

**ko-Q0861 · Edit the changed sentence**

집주인이 집세를 【지만】 싶어한다.

The landlord wants to raise the rent.

[[Korean#^ko-Q0861-answer|Compare the answer]]
^ko-Q0861

**ko-Q0862 · Build the sentence**

Arrange: 싶어한다. / 집세를 / 집주인이 / 올리고

The landlord wants to raise the rent.

[[Korean#^ko-Q0862-answer|Compare the answer]]
^ko-Q0862

**ko-Q0863 · Write a translation**

Write this in Korean: That's why I like traveling, and would like to experience many different cultures.

[[Korean#^ko-Q0863-answer|Compare the answer]]
^ko-Q0863

**ko-Q0864 · Explain the grammar**

그래서 나는 여행을 사랑하고, 많은 문화와 언어를 【경험하고】 싶다.

That's why I like traveling, and would like to experience many different cultures.

[[Korean#^ko-Q0864-answer|Compare the answer]]
^ko-Q0864

**ko-Q0865 · Fill the gap**

고슴도치에 놀란 호랑이 밤송이 ____ 절한다.

A tiger surprised by a hedgehog will bow before the chestnut burrs.

[[Korean#^ko-Q0865-answer|Compare the answer]]
^ko-Q0865

**ko-Q0866 · Choose the form**

고슴도치에 놀란 호랑이 밤송이 ____ 절한다.

A tiger surprised by a hedgehog will bow before the chestnut burrs.

Choices: 보고 / 지만 / 고

[[Korean#^ko-Q0866-answer|Compare the answer]]
^ko-Q0866

**ko-Q0867 · Edit the changed sentence**

이번 주는 운전연습을 【지만】 바빠요.

I am busy this week because I practice driving.

[[Korean#^ko-Q0867-answer|Compare the answer]]
^ko-Q0867

**ko-Q0868 · Build the sentence**

Arrange: 하느라고 / 이번 / 바빠요. / 주는 / 운전연습을

I am busy this week because I practice driving.

[[Korean#^ko-Q0868-answer|Compare the answer]]
^ko-Q0868

**ko-Q0869 · Write a translation**

Write this in Korean: I want to see that again.

[[Korean#^ko-Q0869-answer|Compare the answer]]
^ko-Q0869

**ko-Q0870 · Explain the grammar**

그를 다시 【보고】 싶다.

I want to see that again.

[[Korean#^ko-Q0870-answer|Compare the answer]]
^ko-Q0870

**ko-Q0871 · Fill the gap**

톰은 메리가 ____ 했다.

Tom said Mary was overweight.

[[Korean#^ko-Q0871-answer|Compare the answer]]
^ko-Q0871

**ko-Q0872 · Choose the form**

톰은 메리가 ____ 했다.

Tom said Mary was overweight.

Choices: 고 / 지만 / 과다체중이라고

[[Korean#^ko-Q0872-answer|Compare the answer]]
^ko-Q0872

**ko-Q0873 · Edit the changed sentence**

나는 북한에 【지만】 싶다.

I want to go to North Korea.

[[Korean#^ko-Q0873-answer|Compare the answer]]
^ko-Q0873

**ko-Q0874 · Build the sentence**

Arrange: 나는 / 싶다. / 북한에 / 가고

I want to go to North Korea.

[[Korean#^ko-Q0874-answer|Compare the answer]]
^ko-Q0874

**ko-Q0875 · Write a translation**

Write this in Korean: She didn't want to know anything about his personal life.

[[Korean#^ko-Q0875-answer|Compare the answer]]
^ko-Q0875

**ko-Q0876 · Explain the grammar**

그 여자는 그 남자의 사생활에 대해 전혀 【알고】 싶어하질 않던데.

She didn't want to know anything about his personal life.

[[Korean#^ko-Q0876-answer|Compare the answer]]
^ko-Q0876

**ko-Q0877 · Fill the gap**

탐은 메리가 어디에 있었는지 ____ 싶었다.

Tom wanted to know where Mary had been.

[[Korean#^ko-Q0877-answer|Compare the answer]]
^ko-Q0877

**ko-Q0878 · Choose the form**

탐은 메리가 어디에 있었는지 ____ 싶었다.

Tom wanted to know where Mary had been.

Choices: 지만 / 고 / 알고

[[Korean#^ko-Q0878-answer|Compare the answer]]
^ko-Q0878

**ko-Q0879 · Edit the changed sentence**

딸기가 있는데 너 【지만】 싶니?

I have some strawberries. Do you want some?

[[Korean#^ko-Q0879-answer|Compare the answer]]
^ko-Q0879

**ko-Q0880 · Build the sentence**

Arrange: 있는데 / 먹고 / 싶니? / 너 / 딸기가

I have some strawberries. Do you want some?

[[Korean#^ko-Q0880-answer|Compare the answer]]
^ko-Q0880

**ko-Q0881 · Write a translation**

Write this in Korean: He tried to open the door.

[[Korean#^ko-Q0881-answer|Compare the answer]]
^ko-Q0881

**ko-Q0882 · Explain the grammar**

그가 문을 【열려고】 하였다.

He tried to open the door.

[[Korean#^ko-Q0882-answer|Compare the answer]]
^ko-Q0882

**ko-Q0883 · Fill the gap**

그래서 나는 프랑스에 오래 ____ 싶고, 그러기 위한 돈이 필요하다.

This is why I would like an extended visa as well as as funds for my stay.

[[Korean#^ko-Q0883-answer|Compare the answer]]
^ko-Q0883

**ko-Q0884 · Choose the form**

그래서 나는 프랑스에 오래 ____ 싶고, 그러기 위한 돈이 필요하다.

This is why I would like an extended visa as well as as funds for my stay.

Choices: 고 / 지만 / 머무르고

[[Korean#^ko-Q0884-answer|Compare the answer]]
^ko-Q0884

**ko-Q0885 · Edit the changed sentence**

난 톰이 【지만】 믿지 않아.

I don't believe Tom is a murderer.

[[Korean#^ko-Q0885-answer|Compare the answer]]
^ko-Q0885

**ko-Q0886 · Build the sentence**

Arrange: 톰이 / 믿지 / 난 / 않아. / 살인자라고

I don't believe Tom is a murderer.

[[Korean#^ko-Q0886-answer|Compare the answer]]
^ko-Q0886

**ko-Q0887 · Write a translation**

Write this in Korean: Since I heard this, I want to travel french cities and provinces, learn beautiful French, and more than anything prepare French cuisine with my own hands. And feel the atmosphere of France.

[[Korean#^ko-Q0887-answer|Compare the answer]]
^ko-Q0887

**ko-Q0888 · Explain the grammar**

그 말을 들은 후부터 나는 프랑스의 도시들과 시골을 【여행하고】 싶어졌고, 아름다운 언어인 프랑스어를 배우고 싶어졌으며, 무엇보다도, 프랑스 음식을 내 손으로 직접 만들고 싶어졌다.또한 프랑스의 분위기를 느끼고 싶다.

Since I heard this, I want to travel french cities and provinces, learn beautiful French, and more than anything prepare French cuisine with my own hands. And feel the atmosphere of France.

[[Korean#^ko-Q0888-answer|Compare the answer]]
^ko-Q0888

**ko-Q0889 · Fill the gap**

____ 집 전화 번호를 쓰세요.

Write the address and the home phone number.

[[Korean#^ko-Q0889-answer|Compare the answer]]
^ko-Q0889

**ko-Q0890 · Choose the form**

____ 집 전화 번호를 쓰세요.

Write the address and the home phone number.

Choices: 주소하고 / 고 / 지만

[[Korean#^ko-Q0890-answer|Compare the answer]]
^ko-Q0890

**ko-Q0891 · Edit the changed sentence**

톰은 왜 자기 집에 개가 있었는지 【지만】 싶었다.

Tom wondered why there was a dog in his house.

[[Korean#^ko-Q0891-answer|Compare the answer]]
^ko-Q0891

**ko-Q0892 · Build the sentence**

Arrange: 톰은 / 왜 / 집에 / 알고 / 자기 / 개가 / 있었는지 / 싶었다.

Tom wondered why there was a dog in his house.

[[Korean#^ko-Q0892-answer|Compare the answer]]
^ko-Q0892

**ko-Q0893 · Write a translation**

Write this in Korean: We were retreating.

[[Korean#^ko-Q0893-answer|Compare the answer]]
^ko-Q0893

**ko-Q0894 · Explain the grammar**

우리는 【후퇴하고】 있었다.

We were retreating.

[[Korean#^ko-Q0894-answer|Compare the answer]]
^ko-Q0894

**ko-Q0895 · Fill the gap**

바로 그게 내가 ____ 싶은 말이었다.

You took the words right out of my mouth.

[[Korean#^ko-Q0895-answer|Compare the answer]]
^ko-Q0895

**ko-Q0896 · Choose the form**

바로 그게 내가 ____ 싶은 말이었다.

You took the words right out of my mouth.

Choices: 고 / 하고 / 지만

[[Korean#^ko-Q0896-answer|Compare the answer]]
^ko-Q0896

**ko-Q0897 · Edit the changed sentence**

어째서 네가 프랑스어를 【지만】 있는지 모르겠어.

I don't know why you're studying French.

[[Korean#^ko-Q0897-answer|Compare the answer]]
^ko-Q0897

**ko-Q0898 · Build the sentence**

Arrange: 모르겠어. / 어째서 / 프랑스어를 / 네가 / 있는지 / 공부하고

I don't know why you're studying French.

[[Korean#^ko-Q0898-answer|Compare the answer]]
^ko-Q0898

**ko-Q0899 · Write a translation**

Write this in Korean: I am dying to see her again.

[[Korean#^ko-Q0899-answer|Compare the answer]]
^ko-Q0899

**ko-Q0900 · Explain the grammar**

나는 그녀를 다시 【보고】 싶어 미치겠다.

I am dying to see her again.

[[Korean#^ko-Q0900-answer|Compare the answer]]
^ko-Q0900


### Requests and honorific endings · 50 questions

**ko-Q0901 · Fill the gap**

거짓말 하지 ____.

Don't you lie!

[[Korean#^ko-Q0901-answer|Compare the answer]]
^ko-Q0901

**ko-Q0902 · Choose the form**

거짓말 하지 ____.

Don't you lie!

Choices: 십시오 / 세요 / 마세요

[[Korean#^ko-Q0902-answer|Compare the answer]]
^ko-Q0902

**ko-Q0903 · Edit the changed sentence**

와인 한 병 더 【세요】.

One more bottle of wine, please.

[[Korean#^ko-Q0903-answer|Compare the answer]]
^ko-Q0903

**ko-Q0904 · Build the sentence**

Arrange: 더 / 와인 / 한 / 병 / 주세요.

One more bottle of wine, please.

[[Korean#^ko-Q0904-answer|Compare the answer]]
^ko-Q0904

**ko-Q0905 · Write a translation**

Write this in Korean: In case something is not clear, please contact us.

[[Korean#^ko-Q0905-answer|Compare the answer]]
^ko-Q0905

**ko-Q0906 · Explain the grammar**

혹시 불분명한 점이 있을 경우 연락 【주십시오】.

In case something is not clear, please contact us.

[[Korean#^ko-Q0906-answer|Compare the answer]]
^ko-Q0906

**ko-Q0907 · Fill the gap**

먹으러 갈만한 괜찮은 식당을 ____.

Choose a good restaurant to go to eat at.

[[Korean#^ko-Q0907-answer|Compare the answer]]
^ko-Q0907

**ko-Q0908 · Choose the form**

먹으러 갈만한 괜찮은 식당을 ____.

Choose a good restaurant to go to eat at.

Choices: 십시오 / 세요 / 골라주세요

[[Korean#^ko-Q0908-answer|Compare the answer]]
^ko-Q0908

**ko-Q0909 · Edit the changed sentence**

물 좀 【세요】, 제발.

Some water, please.

[[Korean#^ko-Q0909-answer|Compare the answer]]
^ko-Q0909

**ko-Q0910 · Build the sentence**

Arrange: 제발. / 주세요, / 물 / 좀

Some water, please.

[[Korean#^ko-Q0910-answer|Compare the answer]]
^ko-Q0910

**ko-Q0911 · Write a translation**

Write this in Korean: Please, don't kill me.

[[Korean#^ko-Q0911-answer|Compare the answer]]
^ko-Q0911

**ko-Q0912 · Explain the grammar**

제발, 절 죽이지 【마세요】.

Please, don't kill me.

[[Korean#^ko-Q0912-answer|Compare the answer]]
^ko-Q0912

**ko-Q0913 · Fill the gap**

저작권이 있는 출처의 문장을 추가하지 ____.

Don't add sentences from copyrighted sources.

[[Korean#^ko-Q0913-answer|Compare the answer]]
^ko-Q0913

**ko-Q0914 · Choose the form**

저작권이 있는 출처의 문장을 추가하지 ____.

Don't add sentences from copyrighted sources.

Choices: 마십시오 / 세요 / 십시오

[[Korean#^ko-Q0914-answer|Compare the answer]]
^ko-Q0914

**ko-Q0915 · Edit the changed sentence**

제 사과를 받아 【세요】.

Please accept my apology.

[[Korean#^ko-Q0915-answer|Compare the answer]]
^ko-Q0915

**ko-Q0916 · Build the sentence**

Arrange: 주세요. / 사과를 / 받아 / 제

Please accept my apology.

[[Korean#^ko-Q0916-answer|Compare the answer]]
^ko-Q0916

**ko-Q0917 · Write a translation**

Write this in Korean: Don't lie anymore, OK?

[[Korean#^ko-Q0917-answer|Compare the answer]]
^ko-Q0917

**ko-Q0918 · Explain the grammar**

거짓말 하지 【마세요】, 알았죠?

Don't lie anymore, OK?

[[Korean#^ko-Q0918-answer|Compare the answer]]
^ko-Q0918

**ko-Q0919 · Fill the gap**

지금부터 제 얘기 잘 ____.

Now, listen carefully to what I am saying.

[[Korean#^ko-Q0919-answer|Compare the answer]]
^ko-Q0919

**ko-Q0920 · Choose the form**

지금부터 제 얘기 잘 ____.

Now, listen carefully to what I am saying.

Choices: 세요 / 들으세요 / 십시오

[[Korean#^ko-Q0920-answer|Compare the answer]]
^ko-Q0920

**ko-Q0921 · Edit the changed sentence**

음악 소리를 좀 【세요】.

Please turn the music down a bit.

[[Korean#^ko-Q0921-answer|Compare the answer]]
^ko-Q0921

**ko-Q0922 · Build the sentence**

Arrange: 음악 / 좀 / 소리를 / 줄이세요.

Please turn the music down a bit.

[[Korean#^ko-Q0922-answer|Compare the answer]]
^ko-Q0922

**ko-Q0923 · Write a translation**

Write this in Korean: Do what you want.

[[Korean#^ko-Q0923-answer|Compare the answer]]
^ko-Q0923

**ko-Q0924 · Explain the grammar**

니 맘대로 【하세요】.

Do what you want.

[[Korean#^ko-Q0924-answer|Compare the answer]]
^ko-Q0924

**ko-Q0925 · Fill the gap**

혼자 내버려 ____!

Please leave me alone!

[[Korean#^ko-Q0925-answer|Compare the answer]]
^ko-Q0925

**ko-Q0926 · Choose the form**

혼자 내버려 ____!

Please leave me alone!

Choices: 세요 / 두십시오 / 십시오

[[Korean#^ko-Q0926-answer|Compare the answer]]
^ko-Q0926

**ko-Q0927 · Edit the changed sentence**

식물에 물을 【세요】.

Water the plants.

[[Korean#^ko-Q0927-answer|Compare the answer]]
^ko-Q0927

**ko-Q0928 · Build the sentence**

Arrange: 물을 / 식물에 / 주세요.

Water the plants.

[[Korean#^ko-Q0928-answer|Compare the answer]]
^ko-Q0928

**ko-Q0929 · Write a translation**

Write this in Korean: Please take me to the hospital.

[[Korean#^ko-Q0929-answer|Compare the answer]]
^ko-Q0929

**ko-Q0930 · Explain the grammar**

병원으로 데려다 【주세요】.

Please take me to the hospital.

[[Korean#^ko-Q0930-answer|Compare the answer]]
^ko-Q0930

**ko-Q0931 · Fill the gap**

냉장고에 있는 거 아무거나 편하게 마음껏 ____.

Please feel free to help yourself to anything in the fridge.

[[Korean#^ko-Q0931-answer|Compare the answer]]
^ko-Q0931

**ko-Q0932 · Choose the form**

냉장고에 있는 거 아무거나 편하게 마음껏 ____.

Please feel free to help yourself to anything in the fridge.

Choices: 세요 / 십시오 / 드세요

[[Korean#^ko-Q0932-answer|Compare the answer]]
^ko-Q0932

**ko-Q0933 · Edit the changed sentence**

당신이 번역할 문장에 충실하게 【세요】. 다른 언어로 번역된 문장의 영향을 받지 마십시오.

Make a good translation of the sentence that you are translating. Don't let translations into other languages influence you.

[[Korean#^ko-Q0933-answer|Compare the answer]]
^ko-Q0933

**ko-Q0934 · Build the sentence**

Arrange: 언어로 / 문장의 / 번역된 / 마십시오. / 당신이 / 번역할 / 받지 / 충실하게 / 다른 / 문장에 / 영향을 / 번역하십시오.

Make a good translation of the sentence that you are translating. Don't let translations into other languages influence you.

[[Korean#^ko-Q0934-answer|Compare the answer]]
^ko-Q0934

**ko-Q0935 · Write a translation**

Write this in Korean: Wait here until I come back.

[[Korean#^ko-Q0935-answer|Compare the answer]]
^ko-Q0935

**ko-Q0936 · Explain the grammar**

제가 올 때까지 기다려 【주세요】.

Wait here until I come back.

[[Korean#^ko-Q0936-answer|Compare the answer]]
^ko-Q0936

**ko-Q0937 · Fill the gap**

이 책을 ____.

Read this book.

[[Korean#^ko-Q0937-answer|Compare the answer]]
^ko-Q0937

**ko-Q0938 · Choose the form**

이 책을 ____.

Read this book.

Choices: 십시오 / 세요 / 읽으세요

[[Korean#^ko-Q0938-answer|Compare the answer]]
^ko-Q0938

**ko-Q0939 · Edit the changed sentence**

게임 어떻게 하는지 【세요】.

Please teach me how to play this game.

[[Korean#^ko-Q0939-answer|Compare the answer]]
^ko-Q0939

**ko-Q0940 · Build the sentence**

Arrange: 어떻게 / 하는지 / 가르쳐주세요. / 게임

Please teach me how to play this game.

[[Korean#^ko-Q0940-answer|Compare the answer]]
^ko-Q0940

**ko-Q0941 · Write a translation**

Write this in Korean: Write high-quality sentences.

[[Korean#^ko-Q0941-answer|Compare the answer]]
^ko-Q0941

**ko-Q0942 · Explain the grammar**

양질의 문장을 【쓰세요】.

Write high-quality sentences.

[[Korean#^ko-Q0942-answer|Compare the answer]]
^ko-Q0942

**ko-Q0943 · Fill the gap**

창백해 보이네요. 어디 ____?

You look pale. Are you ill?

[[Korean#^ko-Q0943-answer|Compare the answer]]
^ko-Q0943

**ko-Q0944 · Choose the form**

창백해 보이네요. 어디 ____?

You look pale. Are you ill?

Choices: 세요 / 아프세요 / 십시오

[[Korean#^ko-Q0944-answer|Compare the answer]]
^ko-Q0944

**ko-Q0945 · Edit the changed sentence**

감자와 당근의 껍질을 【세요】.

Peel the potatoes and carrots.

[[Korean#^ko-Q0945-answer|Compare the answer]]
^ko-Q0945

**ko-Q0946 · Build the sentence**

Arrange: 껍질을 / 벗겨주세요. / 감자와 / 당근의

Peel the potatoes and carrots.

[[Korean#^ko-Q0946-answer|Compare the answer]]
^ko-Q0946

**ko-Q0947 · Write a translation**

Write this in Korean: Please keep your voices down.

[[Korean#^ko-Q0947-answer|Compare the answer]]
^ko-Q0947

**ko-Q0948 · Explain the grammar**

조용히 해 【주세요】.

Please keep your voices down.

[[Korean#^ko-Q0948-answer|Compare the answer]]
^ko-Q0948

**ko-Q0949 · Fill the gap**

할 가치가 있는 일이면, 제대로 ____.

If it is worth doing at all, it is worth doing well.

[[Korean#^ko-Q0949-answer|Compare the answer]]
^ko-Q0949

**ko-Q0950 · Choose the form**

할 가치가 있는 일이면, 제대로 ____.

If it is worth doing at all, it is worth doing well.

Choices: 세요 / 십시오 / 하십시오

[[Korean#^ko-Q0950-answer|Compare the answer]]
^ko-Q0950


### Questions and stance · 50 questions

**ko-Q0951 · Edit the changed sentence**

지금 【왜】하는 건데요?

What are you doing right now?

[[Korean#^ko-Q0951-answer|Compare the answer]]
^ko-Q0951

**ko-Q0952 · Build the sentence**

Arrange: 지금 / 건데요? / 뭐하는

What are you doing right now?

[[Korean#^ko-Q0952-answer|Compare the answer]]
^ko-Q0952

**ko-Q0953 · Write a translation**

Write this in Korean: Where can I make a phone call?

[[Korean#^ko-Q0953-answer|Compare the answer]]
^ko-Q0953

**ko-Q0954 · Explain the grammar**

【어디】서 전화를 걸 수 있죠?

Where can I make a phone call?

[[Korean#^ko-Q0954-answer|Compare the answer]]
^ko-Q0954

**ko-Q0955 · Fill the gap**

그 은행은 ____ 있어?

Where is the bank?

[[Korean#^ko-Q0955-answer|Compare the answer]]
^ko-Q0955

**ko-Q0956 · Choose the form**

그 은행은 ____ 있어?

Where is the bank?

Choices: 어떻게 / 왜 / 어디 / 언제

[[Korean#^ko-Q0956-answer|Compare the answer]]
^ko-Q0956

**ko-Q0957 · Edit the changed sentence**

너는 【왜】 그렇게 인기가 많니?

Why are you so popular?

[[Korean#^ko-Q0957-answer|Compare the answer]]
^ko-Q0957

**ko-Q0958 · Build the sentence**

Arrange: 많니? / 그렇게 / 너는 / 어떻게 / 인기가

Why are you so popular?

[[Korean#^ko-Q0958-answer|Compare the answer]]
^ko-Q0958

**ko-Q0959 · Write a translation**

Write this in Korean: Tom is probably on the spectrum.

[[Korean#^ko-Q0959-answer|Compare the answer]]
^ko-Q0959

**ko-Q0960 · Explain the grammar**

톰은 【아마】 자폐 스펙트럼에 속해.

Tom is probably on the spectrum.

[[Korean#^ko-Q0960-answer|Compare the answer]]
^ko-Q0960

**ko-Q0961 · Fill the gap**

____ 그 단어를 잊어버렸니?

Why have you forgotten the word?

[[Korean#^ko-Q0961-answer|Compare the answer]]
^ko-Q0961

**ko-Q0962 · Choose the form**

____ 그 단어를 잊어버렸니?

Why have you forgotten the word?

Choices: 왜 / 어떻게 / 언제 / 어디

[[Korean#^ko-Q0962-answer|Compare the answer]]
^ko-Q0962

**ko-Q0963 · Edit the changed sentence**

보스턴에 【왜】 왔어?

When did you come to Boston?

[[Korean#^ko-Q0963-answer|Compare the answer]]
^ko-Q0963

**ko-Q0964 · Build the sentence**

Arrange: 왔어? / 언제 / 보스턴에

When did you come to Boston?

[[Korean#^ko-Q0964-answer|Compare the answer]]
^ko-Q0964

**ko-Q0965 · Write a translation**

Write this in Korean: Where is the closest hospital?

[[Korean#^ko-Q0965-answer|Compare the answer]]
^ko-Q0965

**ko-Q0966 · Explain the grammar**

제일 가까운 병원이 【어디】에요?

Where is the closest hospital?

[[Korean#^ko-Q0966-answer|Compare the answer]]
^ko-Q0966

**ko-Q0967 · Fill the gap**

씨발 ____ 상관해?

Who the fuck cares?

[[Korean#^ko-Q0967-answer|Compare the answer]]
^ko-Q0967

**ko-Q0968 · Choose the form**

씨발 ____ 상관해?

Who the fuck cares?

Choices: 언제 / 누가 / 왜 / 어떻게

[[Korean#^ko-Q0968-answer|Compare the answer]]
^ko-Q0968

**ko-Q0969 · Edit the changed sentence**

검도와 거합도는 【왜】가 다르죠?

What is the difference between Iaido and Kendo?

[[Korean#^ko-Q0969-answer|Compare the answer]]
^ko-Q0969

**ko-Q0970 · Build the sentence**

Arrange: 검도와 / 뭐가 / 다르죠? / 거합도는

What is the difference between Iaido and Kendo?

[[Korean#^ko-Q0970-answer|Compare the answer]]
^ko-Q0970

**ko-Q0971 · Write a translation**

Write this in Korean: Why do you lie?

[[Korean#^ko-Q0971-answer|Compare the answer]]
^ko-Q0971

**ko-Q0972 · Explain the grammar**

【왜】 거짓말을 해요?

Why do you lie?

[[Korean#^ko-Q0972-answer|Compare the answer]]
^ko-Q0972

**ko-Q0973 · Fill the gap**

그들은 ____ 그것을 할 수 없죠?

Why can't they do it?

[[Korean#^ko-Q0973-answer|Compare the answer]]
^ko-Q0973

**ko-Q0974 · Choose the form**

그들은 ____ 그것을 할 수 없죠?

Why can't they do it?

Choices: 언제 / 어디 / 왜 / 어떻게

[[Korean#^ko-Q0974-answer|Compare the answer]]
^ko-Q0974

**ko-Q0975 · Edit the changed sentence**

종교와 철학의 차이점은 【왜】입니까?

What's the difference between religion and philosophy?

[[Korean#^ko-Q0975-answer|Compare the answer]]
^ko-Q0975

**ko-Q0976 · Build the sentence**

Arrange: 종교와 / 철학의 / 무엇입니까? / 차이점은

What's the difference between religion and philosophy?

[[Korean#^ko-Q0976-answer|Compare the answer]]
^ko-Q0976

**ko-Q0977 · Write a translation**

Write this in Korean: Are you saying that you don't know how to do this?

[[Korean#^ko-Q0977-answer|Compare the answer]]
^ko-Q0977

**ko-Q0978 · Explain the grammar**

이걸 【어떻게】 하는지 모른다고 말하는 거야?

Are you saying that you don't know how to do this?

[[Korean#^ko-Q0978-answer|Compare the answer]]
^ko-Q0978

**ko-Q0979 · Fill the gap**

겨울 방학은 ____ 지냈나요?

How did you spend your winter vacation?

[[Korean#^ko-Q0979-answer|Compare the answer]]
^ko-Q0979

**ko-Q0980 · Choose the form**

겨울 방학은 ____ 지냈나요?

How did you spend your winter vacation?

Choices: 어떻게 / 어디 / 언제 / 왜

[[Korean#^ko-Q0980-answer|Compare the answer]]
^ko-Q0980

**ko-Q0981 · Edit the changed sentence**

슬론 스퀘어로 가는 다음 기차가 【왜】 있습니까?

When is the next train to Sloane Square?

[[Korean#^ko-Q0981-answer|Compare the answer]]
^ko-Q0981

**ko-Q0982 · Build the sentence**

Arrange: 다음 / 언제 / 스퀘어로 / 기차가 / 가는 / 있습니까? / 슬론

When is the next train to Sloane Square?

[[Korean#^ko-Q0982-answer|Compare the answer]]
^ko-Q0982

**ko-Q0983 · Write a translation**

Write this in Korean: Perhaps the weather will get better tomorrow.

[[Korean#^ko-Q0983-answer|Compare the answer]]
^ko-Q0983

**ko-Q0984 · Explain the grammar**

【아마】 내일은 날씨가 나아질 거예요.

Perhaps the weather will get better tomorrow.

[[Korean#^ko-Q0984-answer|Compare the answer]]
^ko-Q0984

**ko-Q0985 · Fill the gap**

사랑받고 있는 사람 중에 가난한 사람이 ____ 있나?

Who, being loved, is poor?

[[Korean#^ko-Q0985-answer|Compare the answer]]
^ko-Q0985

**ko-Q0986 · Choose the form**

사랑받고 있는 사람 중에 가난한 사람이 ____ 있나?

Who, being loved, is poor?

Choices: 언제 / 어떻게 / 왜 / 누가

[[Korean#^ko-Q0986-answer|Compare the answer]]
^ko-Q0986

**ko-Q0987 · Edit the changed sentence**

【어떻게】 여자가 싫은 거야?

Why do you hate women?

[[Korean#^ko-Q0987-answer|Compare the answer]]
^ko-Q0987

**ko-Q0988 · Build the sentence**

Arrange: 싫은 / 거야? / 왜 / 여자가

Why do you hate women?

[[Korean#^ko-Q0988-answer|Compare the answer]]
^ko-Q0988

**ko-Q0989 · Write a translation**

Write this in Korean: Tom found out what went wrong.

[[Korean#^ko-Q0989-answer|Compare the answer]]
^ko-Q0989

**ko-Q0990 · Explain the grammar**

톰은 【뭐】가 잘못됐는지 알아챘어.

Tom found out what went wrong.

[[Korean#^ko-Q0990-answer|Compare the answer]]
^ko-Q0990

**ko-Q0991 · Fill the gap**

그 고양이는 ____을 원해요?

What does the cat want?

[[Korean#^ko-Q0991-answer|Compare the answer]]
^ko-Q0991

**ko-Q0992 · Choose the form**

그 고양이는 ____을 원해요?

What does the cat want?

Choices: 언제 / 어떻게 / 무엇 / 왜

[[Korean#^ko-Q0992-answer|Compare the answer]]
^ko-Q0992

**ko-Q0993 · Edit the changed sentence**

【왜】 그들을 죽였나?

Who killed them?

[[Korean#^ko-Q0993-answer|Compare the answer]]
^ko-Q0993

**ko-Q0994 · Build the sentence**

Arrange: 누가 / 죽였나? / 그들을

Who killed them?

[[Korean#^ko-Q0994-answer|Compare the answer]]
^ko-Q0994

**ko-Q0995 · Write a translation**

Write this in Korean: What's the real goal?

[[Korean#^ko-Q0995-answer|Compare the answer]]
^ko-Q0995

**ko-Q0996 · Explain the grammar**

진짜 목표는 【뭐】야?

What's the real goal?

[[Korean#^ko-Q0996-answer|Compare the answer]]
^ko-Q0996

**ko-Q0997 · Fill the gap**

지혜로운 리더는 ____ 들어야 할지를 안다.

A wise leader knows when to listen.

[[Korean#^ko-Q0997-answer|Compare the answer]]
^ko-Q0997

**ko-Q0998 · Choose the form**

지혜로운 리더는 ____ 들어야 할지를 안다.

A wise leader knows when to listen.

Choices: 어떻게 / 언제 / 왜 / 어디

[[Korean#^ko-Q0998-answer|Compare the answer]]
^ko-Q0998

**ko-Q0999 · Edit the changed sentence**

그걸 【왜】에 숨겼어?

Where did you hide them?

[[Korean#^ko-Q0999-answer|Compare the answer]]
^ko-Q0999

**ko-Q1000 · Build the sentence**

Arrange: 숨겼어? / 그걸 / 어디에

Where did you hide them?

[[Korean#^ko-Q1000-answer|Compare the answer]]
^ko-Q1000


## Answers

The full sentence is a model. For translation, judge whether meaning and grammar are preserved. Each grammar rule above explains the form.

### Answers 1–50

**ko-Q0001** — 나는 갈 거에요.

I'm going to go.

Expected form: **나는**

Why: Topic 은 and 는. [[Korean#^ko-Q0001|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%EA%B0%88%20%EA%B1%B0%EC%97%90%EC%9A%94.)
^ko-Q0001-answer

**ko-Q0002** — 나는 갈 거에요.

I'm going to go.

Expected form: **나는**

Why: Topic 은 and 는. [[Korean#^ko-Q0002|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%EA%B0%88%20%EA%B1%B0%EC%97%90%EC%9A%94.)
^ko-Q0002-answer

**ko-Q0003** — 톰은 벽장에서 헌 구두상자를 꺼내 열었다.

Tom pulled out an old shoebox from his closet and opened it.

Expected form: **톰은**

Why: Topic 은 and 는. [[Korean#^ko-Q0003|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EB%B2%BD%EC%9E%A5%EC%97%90%EC%84%9C%20%ED%97%8C%20%EA%B5%AC%EB%91%90%EC%83%81%EC%9E%90%EB%A5%BC%20%EA%BA%BC%EB%82%B4%20%EC%97%B4%EC%97%88%EB%8B%A4.)
^ko-Q0003-answer

**ko-Q0004** — 톰은 벽장에서 헌 구두상자를 꺼내 열었다.

Tom pulled out an old shoebox from his closet and opened it.

Why: Topic 은 and 는. [[Korean#^ko-Q0004|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EB%B2%BD%EC%9E%A5%EC%97%90%EC%84%9C%20%ED%97%8C%20%EA%B5%AC%EB%91%90%EC%83%81%EC%9E%90%EB%A5%BC%20%EA%BA%BC%EB%82%B4%20%EC%97%B4%EC%97%88%EB%8B%A4.)
^ko-Q0004-answer

**ko-Q0005** — 너는 분명히 재능이 있는데 더 많이 못 배워서 아쉽구나.

You have talent, no doubt; it's just a pity that you haven't learned more.

Why: Topic 은 and 는. [[Korean#^ko-Q0005|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%84%88%EB%8A%94%20%EB%B6%84%EB%AA%85%ED%9E%88%20%EC%9E%AC%EB%8A%A5%EC%9D%B4%20%EC%9E%88%EB%8A%94%EB%8D%B0%20%EB%8D%94%20%EB%A7%8E%EC%9D%B4%20%EB%AA%BB%20%EB%B0%B0%EC%9B%8C%EC%84%9C%20%EC%95%84%EC%89%BD%EA%B5%AC%EB%82%98.)
^ko-Q0005-answer

**ko-Q0006** — 너는 분명히 재능이 있는데 더 많이 못 배워서 아쉽구나.

You have talent, no doubt; it's just a pity that you haven't learned more.

은/는 marks topic or contrast. 은 follows a consonant-final noun; 는 follows a vowel-final one. The grammatical subject can be marked separately within a topic-comment structure.

Why: Topic 은 and 는. [[Korean#^ko-Q0006|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%84%88%EB%8A%94%20%EB%B6%84%EB%AA%85%ED%9E%88%20%EC%9E%AC%EB%8A%A5%EC%9D%B4%20%EC%9E%88%EB%8A%94%EB%8D%B0%20%EB%8D%94%20%EB%A7%8E%EC%9D%B4%20%EB%AA%BB%20%EB%B0%B0%EC%9B%8C%EC%84%9C%20%EC%95%84%EC%89%BD%EA%B5%AC%EB%82%98.)
^ko-Q0006-answer

**ko-Q0007** — 톰은 열정적인 애지?

Tom is passionate, isn't he?

Expected form: **톰은**

Why: Topic 은 and 는. [[Korean#^ko-Q0007|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EC%97%B4%EC%A0%95%EC%A0%81%EC%9D%B8%20%EC%95%A0%EC%A7%80%3F)
^ko-Q0007-answer

**ko-Q0008** — 톰은 열정적인 애지?

Tom is passionate, isn't he?

Expected form: **톰은**

Why: Topic 은 and 는. [[Korean#^ko-Q0008|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EC%97%B4%EC%A0%95%EC%A0%81%EC%9D%B8%20%EC%95%A0%EC%A7%80%3F)
^ko-Q0008-answer

**ko-Q0009** — 그녀의 머리카락은 길어.

Her hair is long.

Expected form: **머리카락은**

Why: Topic 은 and 는. [[Korean#^ko-Q0009|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EB%85%80%EC%9D%98%20%EB%A8%B8%EB%A6%AC%EC%B9%B4%EB%9D%BD%EC%9D%80%20%EA%B8%B8%EC%96%B4.)
^ko-Q0009-answer

**ko-Q0010** — 그녀의 머리카락은 길어.

Her hair is long.

Why: Topic 은 and 는. [[Korean#^ko-Q0010|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EB%85%80%EC%9D%98%20%EB%A8%B8%EB%A6%AC%EC%B9%B4%EB%9D%BD%EC%9D%80%20%EA%B8%B8%EC%96%B4.)
^ko-Q0010-answer

**ko-Q0011** — 톰은 아직 숙제를 안 했다.

Tom hasn't finished his homework yet.

Why: Topic 은 and 는. [[Korean#^ko-Q0011|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EC%95%84%EC%A7%81%20%EC%88%99%EC%A0%9C%EB%A5%BC%20%EC%95%88%20%ED%96%88%EB%8B%A4.)
^ko-Q0011-answer

**ko-Q0012** — 톰은 아직 숙제를 안 했다.

Tom hasn't finished his homework yet.

은/는 marks topic or contrast. 은 follows a consonant-final noun; 는 follows a vowel-final one. The grammatical subject can be marked separately within a topic-comment structure.

Why: Topic 은 and 는. [[Korean#^ko-Q0012|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EC%95%84%EC%A7%81%20%EC%88%99%EC%A0%9C%EB%A5%BC%20%EC%95%88%20%ED%96%88%EB%8B%A4.)
^ko-Q0012-answer

**ko-Q0013** — 탐은 그 것에 푹 빠져 있었다.

Tom was totally into it.

Expected form: **탐은**

Why: Topic 은 and 는. [[Korean#^ko-Q0013|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%83%90%EC%9D%80%20%EA%B7%B8%20%EA%B2%83%EC%97%90%20%ED%91%B9%20%EB%B9%A0%EC%A0%B8%20%EC%9E%88%EC%97%88%EB%8B%A4.)
^ko-Q0013-answer

**ko-Q0014** — 탐은 그 것에 푹 빠져 있었다.

Tom was totally into it.

Expected form: **탐은**

Why: Topic 은 and 는. [[Korean#^ko-Q0014|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%83%90%EC%9D%80%20%EA%B7%B8%20%EA%B2%83%EC%97%90%20%ED%91%B9%20%EB%B9%A0%EC%A0%B8%20%EC%9E%88%EC%97%88%EB%8B%A4.)
^ko-Q0014-answer

**ko-Q0015** — 톰은 진짜 바빠.

Tom is real busy.

Expected form: **톰은**

Why: Topic 은 and 는. [[Korean#^ko-Q0015|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EC%A7%84%EC%A7%9C%20%EB%B0%94%EB%B9%A0.)
^ko-Q0015-answer

**ko-Q0016** — 톰은 진짜 바빠.

Tom is real busy.

Why: Topic 은 and 는. [[Korean#^ko-Q0016|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EC%A7%84%EC%A7%9C%20%EB%B0%94%EB%B9%A0.)
^ko-Q0016-answer

**ko-Q0017** — 메리는 커피 중독자야.

Mary is addicted to coffee.

Why: Topic 은 and 는. [[Korean#^ko-Q0017|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%A9%94%EB%A6%AC%EB%8A%94%20%EC%BB%A4%ED%94%BC%20%EC%A4%91%EB%8F%85%EC%9E%90%EC%95%BC.)
^ko-Q0017-answer

**ko-Q0018** — 메리는 커피 중독자야.

Mary is addicted to coffee.

은/는 marks topic or contrast. 은 follows a consonant-final noun; 는 follows a vowel-final one. The grammatical subject can be marked separately within a topic-comment structure.

Why: Topic 은 and 는. [[Korean#^ko-Q0018|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%A9%94%EB%A6%AC%EB%8A%94%20%EC%BB%A4%ED%94%BC%20%EC%A4%91%EB%8F%85%EC%9E%90%EC%95%BC.)
^ko-Q0018-answer

**ko-Q0019** — 네가 고등학교 선생님이라는 게 사실이니?

Is it true that you're a high school teacher?

Expected form: **선생님이라는**

Why: Topic 은 and 는. [[Korean#^ko-Q0019|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%84%A4%EA%B0%80%20%EA%B3%A0%EB%93%B1%ED%95%99%EA%B5%90%20%EC%84%A0%EC%83%9D%EB%8B%98%EC%9D%B4%EB%9D%BC%EB%8A%94%20%EA%B2%8C%20%EC%82%AC%EC%8B%A4%EC%9D%B4%EB%8B%88%3F)
^ko-Q0019-answer

**ko-Q0020** — 네가 고등학교 선생님이라는 게 사실이니?

Is it true that you're a high school teacher?

Expected form: **선생님이라는**

Why: Topic 은 and 는. [[Korean#^ko-Q0020|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%84%A4%EA%B0%80%20%EA%B3%A0%EB%93%B1%ED%95%99%EA%B5%90%20%EC%84%A0%EC%83%9D%EB%8B%98%EC%9D%B4%EB%9D%BC%EB%8A%94%20%EA%B2%8C%20%EC%82%AC%EC%8B%A4%EC%9D%B4%EB%8B%88%3F)
^ko-Q0020-answer

**ko-Q0021** — 탐은 현재 작은 아파트에서 혼자 살고 있다.

Tom currently lives alone in a small apartment.

Expected form: **탐은**

Why: Topic 은 and 는. [[Korean#^ko-Q0021|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%83%90%EC%9D%80%20%ED%98%84%EC%9E%AC%20%EC%9E%91%EC%9D%80%20%EC%95%84%ED%8C%8C%ED%8A%B8%EC%97%90%EC%84%9C%20%ED%98%BC%EC%9E%90%20%EC%82%B4%EA%B3%A0%20%EC%9E%88%EB%8B%A4.)
^ko-Q0021-answer

**ko-Q0022** — 탐은 현재 작은 아파트에서 혼자 살고 있다.

Tom currently lives alone in a small apartment.

Why: Topic 은 and 는. [[Korean#^ko-Q0022|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%83%90%EC%9D%80%20%ED%98%84%EC%9E%AC%20%EC%9E%91%EC%9D%80%20%EC%95%84%ED%8C%8C%ED%8A%B8%EC%97%90%EC%84%9C%20%ED%98%BC%EC%9E%90%20%EC%82%B4%EA%B3%A0%20%EC%9E%88%EB%8B%A4.)
^ko-Q0022-answer

**ko-Q0023** — 일본과 남한은 이웃 국가다.

Japan and South Korea are neighbors.

Why: Topic 은 and 는. [[Korean#^ko-Q0023|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9D%BC%EB%B3%B8%EA%B3%BC%20%EB%82%A8%ED%95%9C%EC%9D%80%20%EC%9D%B4%EC%9B%83%20%EA%B5%AD%EA%B0%80%EB%8B%A4.)
^ko-Q0023-answer

**ko-Q0024** — 일본과 남한은 이웃 국가다.

Japan and South Korea are neighbors.

은/는 marks topic or contrast. 은 follows a consonant-final noun; 는 follows a vowel-final one. The grammatical subject can be marked separately within a topic-comment structure.

Why: Topic 은 and 는. [[Korean#^ko-Q0024|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9D%BC%EB%B3%B8%EA%B3%BC%20%EB%82%A8%ED%95%9C%EC%9D%80%20%EC%9D%B4%EC%9B%83%20%EA%B5%AD%EA%B0%80%EB%8B%A4.)
^ko-Q0024-answer

**ko-Q0025** — 우리는 우리가 생각하는 것이다.

We are what we think we are.

Expected form: **우리는**

Why: Topic 은 and 는. [[Korean#^ko-Q0025|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9A%B0%EB%A6%AC%EB%8A%94%20%EC%9A%B0%EB%A6%AC%EA%B0%80%20%EC%83%9D%EA%B0%81%ED%95%98%EB%8A%94%20%EA%B2%83%EC%9D%B4%EB%8B%A4.)
^ko-Q0025-answer

**ko-Q0026** — 우리는 우리가 생각하는 것이다.

We are what we think we are.

Expected form: **우리는**

Why: Topic 은 and 는. [[Korean#^ko-Q0026|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9A%B0%EB%A6%AC%EB%8A%94%20%EC%9A%B0%EB%A6%AC%EA%B0%80%20%EC%83%9D%EA%B0%81%ED%95%98%EB%8A%94%20%EA%B2%83%EC%9D%B4%EB%8B%A4.)
^ko-Q0026-answer

**ko-Q0027** — 나는 그녀의 모자가 싫다.

I hate her hat.

Expected form: **나는**

Why: Topic 은 and 는. [[Korean#^ko-Q0027|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%EA%B7%B8%EB%85%80%EC%9D%98%20%EB%AA%A8%EC%9E%90%EA%B0%80%20%EC%8B%AB%EB%8B%A4.)
^ko-Q0027-answer

**ko-Q0028** — 나는 그녀의 모자가 싫다.

I hate her hat.

Why: Topic 은 and 는. [[Korean#^ko-Q0028|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%EA%B7%B8%EB%85%80%EC%9D%98%20%EB%AA%A8%EC%9E%90%EA%B0%80%20%EC%8B%AB%EB%8B%A4.)
^ko-Q0028-answer

**ko-Q0029** — 톰은 좀 무서워해하고 있어.

Tom is a bit scared.

Why: Topic 은 and 는. [[Korean#^ko-Q0029|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EC%A2%80%20%EB%AC%B4%EC%84%9C%EC%9B%8C%ED%95%B4%ED%95%98%EA%B3%A0%20%EC%9E%88%EC%96%B4.)
^ko-Q0029-answer

**ko-Q0030** — 톰은 좀 무서워해하고 있어.

Tom is a bit scared.

은/는 marks topic or contrast. 은 follows a consonant-final noun; 는 follows a vowel-final one. The grammatical subject can be marked separately within a topic-comment structure.

Why: Topic 은 and 는. [[Korean#^ko-Q0030|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EC%A2%80%20%EB%AC%B4%EC%84%9C%EC%9B%8C%ED%95%B4%ED%95%98%EA%B3%A0%20%EC%9E%88%EC%96%B4.)
^ko-Q0030-answer

**ko-Q0031** — 톰은 메리가 그에게 준 와인 한 병에 대하여 메리에게 감사함을 표시했다.

Tom thanked Mary for the bottle of wine she gave him.

Expected form: **톰은**

Why: Topic 은 and 는. [[Korean#^ko-Q0031|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EB%A9%94%EB%A6%AC%EA%B0%80%20%EA%B7%B8%EC%97%90%EA%B2%8C%20%EC%A4%80%20%EC%99%80%EC%9D%B8%20%ED%95%9C%20%EB%B3%91%EC%97%90%20%EB%8C%80%ED%95%98%EC%97%AC%20%EB%A9%94%EB%A6%AC%EC%97%90%EA%B2%8C%20%EA%B0%90%EC%82%AC%ED%95%A8%EC%9D%84%20%ED%91%9C%EC%8B%9C%ED%96%88%EB%8B%A4.)
^ko-Q0031-answer

**ko-Q0032** — 톰은 메리가 그에게 준 와인 한 병에 대하여 메리에게 감사함을 표시했다.

Tom thanked Mary for the bottle of wine she gave him.

Expected form: **톰은**

Why: Topic 은 and 는. [[Korean#^ko-Q0032|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EB%A9%94%EB%A6%AC%EA%B0%80%20%EA%B7%B8%EC%97%90%EA%B2%8C%20%EC%A4%80%20%EC%99%80%EC%9D%B8%20%ED%95%9C%20%EB%B3%91%EC%97%90%20%EB%8C%80%ED%95%98%EC%97%AC%20%EB%A9%94%EB%A6%AC%EC%97%90%EA%B2%8C%20%EA%B0%90%EC%82%AC%ED%95%A8%EC%9D%84%20%ED%91%9C%EC%8B%9C%ED%96%88%EB%8B%A4.)
^ko-Q0032-answer

**ko-Q0033** — 톰은 정말 세게 공을 찼다.

Tom kicked the ball really hard.

Expected form: **톰은**

Why: Topic 은 and 는. [[Korean#^ko-Q0033|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EC%A0%95%EB%A7%90%20%EC%84%B8%EA%B2%8C%20%EA%B3%B5%EC%9D%84%20%EC%B0%BC%EB%8B%A4.)
^ko-Q0033-answer

**ko-Q0034** — 톰은 정말 세게 공을 찼다.

Tom kicked the ball really hard.

Why: Topic 은 and 는. [[Korean#^ko-Q0034|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EC%A0%95%EB%A7%90%20%EC%84%B8%EA%B2%8C%20%EA%B3%B5%EC%9D%84%20%EC%B0%BC%EB%8B%A4.)
^ko-Q0034-answer

**ko-Q0035** — 그 때는 꽤 어렸었는데.

I was pretty young back in those days.

Why: Topic 은 and 는. [[Korean#^ko-Q0035|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%20%EB%95%8C%EB%8A%94%20%EA%BD%A4%20%EC%96%B4%EB%A0%B8%EC%97%88%EB%8A%94%EB%8D%B0.)
^ko-Q0035-answer

**ko-Q0036** — 그 때는 꽤 어렸었는데.

I was pretty young back in those days.

은/는 marks topic or contrast. 은 follows a consonant-final noun; 는 follows a vowel-final one. The grammatical subject can be marked separately within a topic-comment structure.

Why: Topic 은 and 는. [[Korean#^ko-Q0036|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%20%EB%95%8C%EB%8A%94%20%EA%BD%A4%20%EC%96%B4%EB%A0%B8%EC%97%88%EB%8A%94%EB%8D%B0.)
^ko-Q0036-answer

**ko-Q0037** — 우리는 그 사슴의 발자국을 따라갔다.

We followed the deer's tracks.

Expected form: **우리는**

Why: Topic 은 and 는. [[Korean#^ko-Q0037|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9A%B0%EB%A6%AC%EB%8A%94%20%EA%B7%B8%20%EC%82%AC%EC%8A%B4%EC%9D%98%20%EB%B0%9C%EC%9E%90%EA%B5%AD%EC%9D%84%20%EB%94%B0%EB%9D%BC%EA%B0%94%EB%8B%A4.)
^ko-Q0037-answer

**ko-Q0038** — 우리는 그 사슴의 발자국을 따라갔다.

We followed the deer's tracks.

Expected form: **우리는**

Why: Topic 은 and 는. [[Korean#^ko-Q0038|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9A%B0%EB%A6%AC%EB%8A%94%20%EA%B7%B8%20%EC%82%AC%EC%8A%B4%EC%9D%98%20%EB%B0%9C%EC%9E%90%EA%B5%AD%EC%9D%84%20%EB%94%B0%EB%9D%BC%EA%B0%94%EB%8B%A4.)
^ko-Q0038-answer

**ko-Q0039** — 저는 먹은 것이 없습니다.

I haven't eaten anything.

Expected form: **저는**

Why: Topic 은 and 는. [[Korean#^ko-Q0039|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A0%80%EB%8A%94%20%EB%A8%B9%EC%9D%80%20%EA%B2%83%EC%9D%B4%20%EC%97%86%EC%8A%B5%EB%8B%88%EB%8B%A4.)
^ko-Q0039-answer

**ko-Q0040** — 저는 먹은 것이 없습니다.

I haven't eaten anything.

Why: Topic 은 and 는. [[Korean#^ko-Q0040|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A0%80%EB%8A%94%20%EB%A8%B9%EC%9D%80%20%EA%B2%83%EC%9D%B4%20%EC%97%86%EC%8A%B5%EB%8B%88%EB%8B%A4.)
^ko-Q0040-answer

**ko-Q0041** — 브라질은 남미에서 가장 큰 나라입니다.

Brazil is the biggest country in South America.

Why: Topic 은 and 는. [[Korean#^ko-Q0041|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%B8%8C%EB%9D%BC%EC%A7%88%EC%9D%80%20%EB%82%A8%EB%AF%B8%EC%97%90%EC%84%9C%20%EA%B0%80%EC%9E%A5%20%ED%81%B0%20%EB%82%98%EB%9D%BC%EC%9E%85%EB%8B%88%EB%8B%A4.)
^ko-Q0041-answer

**ko-Q0042** — 브라질은 남미에서 가장 큰 나라입니다.

Brazil is the biggest country in South America.

은/는 marks topic or contrast. 은 follows a consonant-final noun; 는 follows a vowel-final one. The grammatical subject can be marked separately within a topic-comment structure.

Why: Topic 은 and 는. [[Korean#^ko-Q0042|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%B8%8C%EB%9D%BC%EC%A7%88%EC%9D%80%20%EB%82%A8%EB%AF%B8%EC%97%90%EC%84%9C%20%EA%B0%80%EC%9E%A5%20%ED%81%B0%20%EB%82%98%EB%9D%BC%EC%9E%85%EB%8B%88%EB%8B%A4.)
^ko-Q0042-answer

**ko-Q0043** — 톰은 원하는 걸 얻을 때까지는 떠나지 않을 거야.

Tom won't leave until he gets what he wants.

Expected form: **톰은**

Why: Topic 은 and 는. [[Korean#^ko-Q0043|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EC%9B%90%ED%95%98%EB%8A%94%20%EA%B1%B8%20%EC%96%BB%EC%9D%84%20%EB%95%8C%EA%B9%8C%EC%A7%80%EB%8A%94%20%EB%96%A0%EB%82%98%EC%A7%80%20%EC%95%8A%EC%9D%84%20%EA%B1%B0%EC%95%BC.)
^ko-Q0043-answer

**ko-Q0044** — 톰은 원하는 걸 얻을 때까지는 떠나지 않을 거야.

Tom won't leave until he gets what he wants.

Expected form: **톰은**

Why: Topic 은 and 는. [[Korean#^ko-Q0044|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EC%9B%90%ED%95%98%EB%8A%94%20%EA%B1%B8%20%EC%96%BB%EC%9D%84%20%EB%95%8C%EA%B9%8C%EC%A7%80%EB%8A%94%20%EB%96%A0%EB%82%98%EC%A7%80%20%EC%95%8A%EC%9D%84%20%EA%B1%B0%EC%95%BC.)
^ko-Q0044-answer

**ko-Q0045** — 톰은 하루에 삼십 번 이상 손을 씻어.

Tom washes his hands more than thirty times a day.

Expected form: **톰은**

Why: Topic 은 and 는. [[Korean#^ko-Q0045|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%ED%95%98%EB%A3%A8%EC%97%90%20%EC%82%BC%EC%8B%AD%20%EB%B2%88%20%EC%9D%B4%EC%83%81%20%EC%86%90%EC%9D%84%20%EC%94%BB%EC%96%B4.)
^ko-Q0045-answer

**ko-Q0046** — 톰은 하루에 삼십 번 이상 손을 씻어.

Tom washes his hands more than thirty times a day.

Why: Topic 은 and 는. [[Korean#^ko-Q0046|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%ED%95%98%EB%A3%A8%EC%97%90%20%EC%82%BC%EC%8B%AD%20%EB%B2%88%20%EC%9D%B4%EC%83%81%20%EC%86%90%EC%9D%84%20%EC%94%BB%EC%96%B4.)
^ko-Q0046-answer

**ko-Q0047** — 그들은 서로 좋아 합니다

They liked each other.

Why: Topic 은 and 는. [[Korean#^ko-Q0047|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EB%93%A4%EC%9D%80%20%EC%84%9C%EB%A1%9C%20%EC%A2%8B%EC%95%84%20%ED%95%A9%EB%8B%88%EB%8B%A4)
^ko-Q0047-answer

**ko-Q0048** — 그들은 서로 좋아 합니다

They liked each other.

은/는 marks topic or contrast. 은 follows a consonant-final noun; 는 follows a vowel-final one. The grammatical subject can be marked separately within a topic-comment structure.

Why: Topic 은 and 는. [[Korean#^ko-Q0048|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EB%93%A4%EC%9D%80%20%EC%84%9C%EB%A1%9C%20%EC%A2%8B%EC%95%84%20%ED%95%A9%EB%8B%88%EB%8B%A4)
^ko-Q0048-answer

**ko-Q0049** — 톰은 대부분의 흡혈귀와는 달리 관에서 자지 않는다.

Tom doesn't sleep in a coffin like most vampires.

Expected form: **톰은**

Why: Topic 은 and 는. [[Korean#^ko-Q0049|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EB%8C%80%EB%B6%80%EB%B6%84%EC%9D%98%20%ED%9D%A1%ED%98%88%EA%B7%80%EC%99%80%EB%8A%94%20%EB%8B%AC%EB%A6%AC%20%EA%B4%80%EC%97%90%EC%84%9C%20%EC%9E%90%EC%A7%80%20%EC%95%8A%EB%8A%94%EB%8B%A4.)
^ko-Q0049-answer

**ko-Q0050** — 톰은 대부분의 흡혈귀와는 달리 관에서 자지 않는다.

Tom doesn't sleep in a coffin like most vampires.

Expected form: **톰은**

Why: Topic 은 and 는. [[Korean#^ko-Q0050|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EB%8C%80%EB%B6%80%EB%B6%84%EC%9D%98%20%ED%9D%A1%ED%98%88%EA%B7%80%EC%99%80%EB%8A%94%20%EB%8B%AC%EB%A6%AC%20%EA%B4%80%EC%97%90%EC%84%9C%20%EC%9E%90%EC%A7%80%20%EC%95%8A%EB%8A%94%EB%8B%A4.)
^ko-Q0050-answer


### Answers 51–100

**ko-Q0051** — 자기가 잘못했다고 생각한다.

I feel guilty.

Expected form: **자기가**

Why: Subject 이 and 가. [[Korean#^ko-Q0051|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9E%90%EA%B8%B0%EA%B0%80%20%EC%9E%98%EB%AA%BB%ED%96%88%EB%8B%A4%EA%B3%A0%20%EC%83%9D%EA%B0%81%ED%95%9C%EB%8B%A4.)
^ko-Q0051-answer

**ko-Q0052** — 자기가 잘못했다고 생각한다.

I feel guilty.

Why: Subject 이 and 가. [[Korean#^ko-Q0052|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9E%90%EA%B8%B0%EA%B0%80%20%EC%9E%98%EB%AA%BB%ED%96%88%EB%8B%A4%EA%B3%A0%20%EC%83%9D%EA%B0%81%ED%95%9C%EB%8B%A4.)
^ko-Q0052-answer

**ko-Q0053** — 영국 영화가 미국 영화보다 낫다.

British films are better than American films.

Why: Subject 이 and 가. [[Korean#^ko-Q0053|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%98%81%EA%B5%AD%20%EC%98%81%ED%99%94%EA%B0%80%20%EB%AF%B8%EA%B5%AD%20%EC%98%81%ED%99%94%EB%B3%B4%EB%8B%A4%20%EB%82%AB%EB%8B%A4.)
^ko-Q0053-answer

**ko-Q0054** — 영국 영화가 미국 영화보다 낫다.

British films are better than American films.

이/가 commonly marks a subject or focused identification. The variant follows the preceding noun’s final sound. These syllables can also appear inside lexical forms, so check the phrase boundary.

Why: Subject 이 and 가. [[Korean#^ko-Q0054|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%98%81%EA%B5%AD%20%EC%98%81%ED%99%94%EA%B0%80%20%EB%AF%B8%EA%B5%AD%20%EC%98%81%ED%99%94%EB%B3%B4%EB%8B%A4%20%EB%82%AB%EB%8B%A4.)
^ko-Q0054-answer

**ko-Q0055** — 의심할 여시가 없읍니다

It's out of the question.

Expected form: **여시가**

Why: Subject 이 and 가. [[Korean#^ko-Q0055|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9D%98%EC%8B%AC%ED%95%A0%20%EC%97%AC%EC%8B%9C%EA%B0%80%20%EC%97%86%EC%9D%8D%EB%8B%88%EB%8B%A4)
^ko-Q0055-answer

**ko-Q0056** — 의심할 여시가 없읍니다

It's out of the question.

Expected form: **여시가**

Why: Subject 이 and 가. [[Korean#^ko-Q0056|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9D%98%EC%8B%AC%ED%95%A0%20%EC%97%AC%EC%8B%9C%EA%B0%80%20%EC%97%86%EC%9D%8D%EB%8B%88%EB%8B%A4)
^ko-Q0056-answer

**ko-Q0057** — 너 새차 색깔이 뭐야?

What color is your new car?

Expected form: **색깔이**

Why: Subject 이 and 가. [[Korean#^ko-Q0057|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%84%88%20%EC%83%88%EC%B0%A8%20%EC%83%89%EA%B9%94%EC%9D%B4%20%EB%AD%90%EC%95%BC%3F)
^ko-Q0057-answer

**ko-Q0058** — 너 새차 색깔이 뭐야?

What color is your new car?

Why: Subject 이 and 가. [[Korean#^ko-Q0058|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%84%88%20%EC%83%88%EC%B0%A8%20%EC%83%89%EA%B9%94%EC%9D%B4%20%EB%AD%90%EC%95%BC%3F)
^ko-Q0058-answer

**ko-Q0059** — 거기에 논리가 어디 있지?

Where is the logic in that?

Why: Subject 이 and 가. [[Korean#^ko-Q0059|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B1%B0%EA%B8%B0%EC%97%90%20%EB%85%BC%EB%A6%AC%EA%B0%80%20%EC%96%B4%EB%94%94%20%EC%9E%88%EC%A7%80%3F)
^ko-Q0059-answer

**ko-Q0060** — 거기에 논리가 어디 있지?

Where is the logic in that?

이/가 commonly marks a subject or focused identification. The variant follows the preceding noun’s final sound. These syllables can also appear inside lexical forms, so check the phrase boundary.

Why: Subject 이 and 가. [[Korean#^ko-Q0060|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B1%B0%EA%B8%B0%EC%97%90%20%EB%85%BC%EB%A6%AC%EA%B0%80%20%EC%96%B4%EB%94%94%20%EC%9E%88%EC%A7%80%3F)
^ko-Q0060-answer

**ko-Q0061** — 신만이 아실 것입니다.

Only God knows.

Expected form: **신만이**

Why: Subject 이 and 가. [[Korean#^ko-Q0061|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%8B%A0%EB%A7%8C%EC%9D%B4%20%EC%95%84%EC%8B%A4%20%EA%B2%83%EC%9E%85%EB%8B%88%EB%8B%A4.)
^ko-Q0061-answer

**ko-Q0062** — 신만이 아실 것입니다.

Only God knows.

Expected form: **신만이**

Why: Subject 이 and 가. [[Korean#^ko-Q0062|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%8B%A0%EB%A7%8C%EC%9D%B4%20%EC%95%84%EC%8B%A4%20%EA%B2%83%EC%9E%85%EB%8B%88%EB%8B%A4.)
^ko-Q0062-answer

**ko-Q0063** — 그게 내가 말하려던 거야.

That's what I was going to say.

Expected form: **내가**

Why: Subject 이 and 가. [[Korean#^ko-Q0063|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EA%B2%8C%20%EB%82%B4%EA%B0%80%20%EB%A7%90%ED%95%98%EB%A0%A4%EB%8D%98%20%EA%B1%B0%EC%95%BC.)
^ko-Q0063-answer

**ko-Q0064** — 그게 내가 말하려던 거야.

That's what I was going to say.

Why: Subject 이 and 가. [[Korean#^ko-Q0064|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EA%B2%8C%20%EB%82%B4%EA%B0%80%20%EB%A7%90%ED%95%98%EB%A0%A4%EB%8D%98%20%EA%B1%B0%EC%95%BC.)
^ko-Q0064-answer

**ko-Q0065** — 메리가 앨리스보다 좀 더 귀여운 것 같아.

I think Mary is way cuter than Alice.

Why: Subject 이 and 가. [[Korean#^ko-Q0065|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%A9%94%EB%A6%AC%EA%B0%80%20%EC%95%A8%EB%A6%AC%EC%8A%A4%EB%B3%B4%EB%8B%A4%20%EC%A2%80%20%EB%8D%94%20%EA%B7%80%EC%97%AC%EC%9A%B4%20%EA%B2%83%20%EA%B0%99%EC%95%84.)
^ko-Q0065-answer

**ko-Q0066** — 메리가 앨리스보다 좀 더 귀여운 것 같아.

I think Mary is way cuter than Alice.

이/가 commonly marks a subject or focused identification. The variant follows the preceding noun’s final sound. These syllables can also appear inside lexical forms, so check the phrase boundary.

Why: Subject 이 and 가. [[Korean#^ko-Q0066|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%A9%94%EB%A6%AC%EA%B0%80%20%EC%95%A8%EB%A6%AC%EC%8A%A4%EB%B3%B4%EB%8B%A4%20%EC%A2%80%20%EB%8D%94%20%EA%B7%80%EC%97%AC%EC%9A%B4%20%EA%B2%83%20%EA%B0%99%EC%95%84.)
^ko-Q0066-answer

**ko-Q0067** — 군인 세명이 부상을 당했다.

Three soldiers were wounded.

Expected form: **세명이**

Why: Subject 이 and 가. [[Korean#^ko-Q0067|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B5%B0%EC%9D%B8%20%EC%84%B8%EB%AA%85%EC%9D%B4%20%EB%B6%80%EC%83%81%EC%9D%84%20%EB%8B%B9%ED%96%88%EB%8B%A4.)
^ko-Q0067-answer

**ko-Q0068** — 군인 세명이 부상을 당했다.

Three soldiers were wounded.

Expected form: **세명이**

Why: Subject 이 and 가. [[Korean#^ko-Q0068|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B5%B0%EC%9D%B8%20%EC%84%B8%EB%AA%85%EC%9D%B4%20%EB%B6%80%EC%83%81%EC%9D%84%20%EB%8B%B9%ED%96%88%EB%8B%A4.)
^ko-Q0068-answer

**ko-Q0069** — A와 B의 차이가 뭐예요?

What is the difference between A and B?

Expected form: **차이가**

Why: Subject 이 and 가. [[Korean#^ko-Q0069|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=A%EC%99%80%20B%EC%9D%98%20%EC%B0%A8%EC%9D%B4%EA%B0%80%20%EB%AD%90%EC%98%88%EC%9A%94%3F)
^ko-Q0069-answer

**ko-Q0070** — A와 B의 차이가 뭐예요?

What is the difference between A and B?

Why: Subject 이 and 가. [[Korean#^ko-Q0070|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=A%EC%99%80%20B%EC%9D%98%20%EC%B0%A8%EC%9D%B4%EA%B0%80%20%EB%AD%90%EC%98%88%EC%9A%94%3F)
^ko-Q0070-answer

**ko-Q0071** — 난 메리의 남자친구를 참을 수가 없어.

I can't stand Mary's boyfriend.

Why: Subject 이 and 가. [[Korean#^ko-Q0071|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%9C%20%EB%A9%94%EB%A6%AC%EC%9D%98%20%EB%82%A8%EC%9E%90%EC%B9%9C%EA%B5%AC%EB%A5%BC%20%EC%B0%B8%EC%9D%84%20%EC%88%98%EA%B0%80%20%EC%97%86%EC%96%B4.)
^ko-Q0071-answer

**ko-Q0072** — 난 메리의 남자친구를 참을 수가 없어.

I can't stand Mary's boyfriend.

이/가 commonly marks a subject or focused identification. The variant follows the preceding noun’s final sound. These syllables can also appear inside lexical forms, so check the phrase boundary.

Why: Subject 이 and 가. [[Korean#^ko-Q0072|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%9C%20%EB%A9%94%EB%A6%AC%EC%9D%98%20%EB%82%A8%EC%9E%90%EC%B9%9C%EA%B5%AC%EB%A5%BC%20%EC%B0%B8%EC%9D%84%20%EC%88%98%EA%B0%80%20%EC%97%86%EC%96%B4.)
^ko-Q0072-answer

**ko-Q0073** — 여긴 거의 눈이 안 와.

It rarely snows here.

Expected form: **눈이**

Why: Subject 이 and 가. [[Korean#^ko-Q0073|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%97%AC%EA%B8%B4%20%EA%B1%B0%EC%9D%98%20%EB%88%88%EC%9D%B4%20%EC%95%88%20%EC%99%80.)
^ko-Q0073-answer

**ko-Q0074** — 여긴 거의 눈이 안 와.

It rarely snows here.

Expected form: **눈이**

Why: Subject 이 and 가. [[Korean#^ko-Q0074|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%97%AC%EA%B8%B4%20%EA%B1%B0%EC%9D%98%20%EB%88%88%EC%9D%B4%20%EC%95%88%20%EC%99%80.)
^ko-Q0074-answer

**ko-Q0075** — 그 사람은 진짜 자신이 우주의 중심에 있는 줄 알아.

He really thinks he's the centre of the universe.

Expected form: **자신이**

Why: Subject 이 and 가. [[Korean#^ko-Q0075|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%20%EC%82%AC%EB%9E%8C%EC%9D%80%20%EC%A7%84%EC%A7%9C%20%EC%9E%90%EC%8B%A0%EC%9D%B4%20%EC%9A%B0%EC%A3%BC%EC%9D%98%20%EC%A4%91%EC%8B%AC%EC%97%90%20%EC%9E%88%EB%8A%94%20%EC%A4%84%20%EC%95%8C%EC%95%84.)
^ko-Q0075-answer

**ko-Q0076** — 그 사람은 진짜 자신이 우주의 중심에 있는 줄 알아.

He really thinks he's the centre of the universe.

Why: Subject 이 and 가. [[Korean#^ko-Q0076|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%20%EC%82%AC%EB%9E%8C%EC%9D%80%20%EC%A7%84%EC%A7%9C%20%EC%9E%90%EC%8B%A0%EC%9D%B4%20%EC%9A%B0%EC%A3%BC%EC%9D%98%20%EC%A4%91%EC%8B%AC%EC%97%90%20%EC%9E%88%EB%8A%94%20%EC%A4%84%20%EC%95%8C%EC%95%84.)
^ko-Q0076-answer

**ko-Q0077** — 가방이 꽉 찼습니다.

The bag is full.

Why: Subject 이 and 가. [[Korean#^ko-Q0077|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B0%80%EB%B0%A9%EC%9D%B4%20%EA%BD%89%20%EC%B0%BC%EC%8A%B5%EB%8B%88%EB%8B%A4.)
^ko-Q0077-answer

**ko-Q0078** — 가방이 꽉 찼습니다.

The bag is full.

이/가 commonly marks a subject or focused identification. The variant follows the preceding noun’s final sound. These syllables can also appear inside lexical forms, so check the phrase boundary.

Why: Subject 이 and 가. [[Korean#^ko-Q0078|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B0%80%EB%B0%A9%EC%9D%B4%20%EA%BD%89%20%EC%B0%BC%EC%8A%B5%EB%8B%88%EB%8B%A4.)
^ko-Q0078-answer

**ko-Q0079** — 우린 돈이 더 필요해.

We needed more money.

Expected form: **돈이**

Why: Subject 이 and 가. [[Korean#^ko-Q0079|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9A%B0%EB%A6%B0%20%EB%8F%88%EC%9D%B4%20%EB%8D%94%20%ED%95%84%EC%9A%94%ED%95%B4.)
^ko-Q0079-answer

**ko-Q0080** — 우린 돈이 더 필요해.

We needed more money.

Expected form: **돈이**

Why: Subject 이 and 가. [[Korean#^ko-Q0080|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9A%B0%EB%A6%B0%20%EB%8F%88%EC%9D%B4%20%EB%8D%94%20%ED%95%84%EC%9A%94%ED%95%B4.)
^ko-Q0080-answer

**ko-Q0081** — 그 사람은 자신의 아버지가 가난하다는 사실을 부끄러워하지 않아.

He’s not ashamed of the fact that his father is poor.

Expected form: **아버지가**

Why: Subject 이 and 가. [[Korean#^ko-Q0081|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%20%EC%82%AC%EB%9E%8C%EC%9D%80%20%EC%9E%90%EC%8B%A0%EC%9D%98%20%EC%95%84%EB%B2%84%EC%A7%80%EA%B0%80%20%EA%B0%80%EB%82%9C%ED%95%98%EB%8B%A4%EB%8A%94%20%EC%82%AC%EC%8B%A4%EC%9D%84%20%EB%B6%80%EB%81%84%EB%9F%AC%EC%9B%8C%ED%95%98%EC%A7%80%20%EC%95%8A%EC%95%84.)
^ko-Q0081-answer

**ko-Q0082** — 그 사람은 자신의 아버지가 가난하다는 사실을 부끄러워하지 않아.

He’s not ashamed of the fact that his father is poor.

Why: Subject 이 and 가. [[Korean#^ko-Q0082|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%20%EC%82%AC%EB%9E%8C%EC%9D%80%20%EC%9E%90%EC%8B%A0%EC%9D%98%20%EC%95%84%EB%B2%84%EC%A7%80%EA%B0%80%20%EA%B0%80%EB%82%9C%ED%95%98%EB%8B%A4%EB%8A%94%20%EC%82%AC%EC%8B%A4%EC%9D%84%20%EB%B6%80%EB%81%84%EB%9F%AC%EC%9B%8C%ED%95%98%EC%A7%80%20%EC%95%8A%EC%95%84.)
^ko-Q0082-answer

**ko-Q0083** — 이 근처에 휴대폰 충전할 수 있는 곳이 있나요?

Is there a place where I can charge my cellphone around here?

Why: Subject 이 and 가. [[Korean#^ko-Q0083|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9D%B4%20%EA%B7%BC%EC%B2%98%EC%97%90%20%ED%9C%B4%EB%8C%80%ED%8F%B0%20%EC%B6%A9%EC%A0%84%ED%95%A0%20%EC%88%98%20%EC%9E%88%EB%8A%94%20%EA%B3%B3%EC%9D%B4%20%EC%9E%88%EB%82%98%EC%9A%94%3F)
^ko-Q0083-answer

**ko-Q0084** — 이 근처에 휴대폰 충전할 수 있는 곳이 있나요?

Is there a place where I can charge my cellphone around here?

이/가 commonly marks a subject or focused identification. The variant follows the preceding noun’s final sound. These syllables can also appear inside lexical forms, so check the phrase boundary.

Why: Subject 이 and 가. [[Korean#^ko-Q0084|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9D%B4%20%EA%B7%BC%EC%B2%98%EC%97%90%20%ED%9C%B4%EB%8C%80%ED%8F%B0%20%EC%B6%A9%EC%A0%84%ED%95%A0%20%EC%88%98%20%EC%9E%88%EB%8A%94%20%EA%B3%B3%EC%9D%B4%20%EC%9E%88%EB%82%98%EC%9A%94%3F)
^ko-Q0084-answer

**ko-Q0085** — 많은 서양 작곡가들에게 유감스럽게도 스틸 드럼과 스틸 팬 드럼은 완벽한 반음계가 아니다.

To the chagrin of many Western composers, steel drums, or steelpans, tend not to be fully chromatic.

Expected form: **반음계가**

Why: Subject 이 and 가. [[Korean#^ko-Q0085|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%A7%8E%EC%9D%80%20%EC%84%9C%EC%96%91%20%EC%9E%91%EA%B3%A1%EA%B0%80%EB%93%A4%EC%97%90%EA%B2%8C%20%EC%9C%A0%EA%B0%90%EC%8A%A4%EB%9F%BD%EA%B2%8C%EB%8F%84%20%EC%8A%A4%ED%8B%B8%20%EB%93%9C%EB%9F%BC%EA%B3%BC%20%EC%8A%A4%ED%8B%B8%20%ED%8C%AC%20%EB%93%9C%EB%9F%BC%EC%9D%80%20%EC%99%84%EB%B2%BD%ED%95%9C%20%EB%B0%98%EC%9D%8C%EA%B3%84%EA%B0%80%20%EC%95%84%EB%8B%88%EB%8B%A4.)
^ko-Q0085-answer

**ko-Q0086** — 많은 서양 작곡가들에게 유감스럽게도 스틸 드럼과 스틸 팬 드럼은 완벽한 반음계가 아니다.

To the chagrin of many Western composers, steel drums, or steelpans, tend not to be fully chromatic.

Expected form: **반음계가**

Why: Subject 이 and 가. [[Korean#^ko-Q0086|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%A7%8E%EC%9D%80%20%EC%84%9C%EC%96%91%20%EC%9E%91%EA%B3%A1%EA%B0%80%EB%93%A4%EC%97%90%EA%B2%8C%20%EC%9C%A0%EA%B0%90%EC%8A%A4%EB%9F%BD%EA%B2%8C%EB%8F%84%20%EC%8A%A4%ED%8B%B8%20%EB%93%9C%EB%9F%BC%EA%B3%BC%20%EC%8A%A4%ED%8B%B8%20%ED%8C%AC%20%EB%93%9C%EB%9F%BC%EC%9D%80%20%EC%99%84%EB%B2%BD%ED%95%9C%20%EB%B0%98%EC%9D%8C%EA%B3%84%EA%B0%80%20%EC%95%84%EB%8B%88%EB%8B%A4.)
^ko-Q0086-answer

**ko-Q0087** — 당신이 세계를 여행하는 동안, 항상 잘먹는 것이 가능하지는 않습니다.

It's not always possible to eat well when you're traveling in this part of the world.

Expected form: **당신이**

Why: Subject 이 and 가. [[Korean#^ko-Q0087|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%8B%B9%EC%8B%A0%EC%9D%B4%20%EC%84%B8%EA%B3%84%EB%A5%BC%20%EC%97%AC%ED%96%89%ED%95%98%EB%8A%94%20%EB%8F%99%EC%95%88%2C%20%ED%95%AD%EC%83%81%20%EC%9E%98%EB%A8%B9%EB%8A%94%20%EA%B2%83%EC%9D%B4%20%EA%B0%80%EB%8A%A5%ED%95%98%EC%A7%80%EB%8A%94%20%EC%95%8A%EC%8A%B5%EB%8B%88%EB%8B%A4.)
^ko-Q0087-answer

**ko-Q0088** — 당신이 세계를 여행하는 동안, 항상 잘먹는 것이 가능하지는 않습니다.

It's not always possible to eat well when you're traveling in this part of the world.

Why: Subject 이 and 가. [[Korean#^ko-Q0088|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%8B%B9%EC%8B%A0%EC%9D%B4%20%EC%84%B8%EA%B3%84%EB%A5%BC%20%EC%97%AC%ED%96%89%ED%95%98%EB%8A%94%20%EB%8F%99%EC%95%88%2C%20%ED%95%AD%EC%83%81%20%EC%9E%98%EB%A8%B9%EB%8A%94%20%EA%B2%83%EC%9D%B4%20%EA%B0%80%EB%8A%A5%ED%95%98%EC%A7%80%EB%8A%94%20%EC%95%8A%EC%8A%B5%EB%8B%88%EB%8B%A4.)
^ko-Q0088-answer

**ko-Q0089** — 내가 찾아 볼게.

I'll find them.

Why: Subject 이 and 가. [[Korean#^ko-Q0089|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%B4%EA%B0%80%20%EC%B0%BE%EC%95%84%20%EB%B3%BC%EA%B2%8C.)
^ko-Q0089-answer

**ko-Q0090** — 내가 찾아 볼게.

I'll find them.

이/가 commonly marks a subject or focused identification. The variant follows the preceding noun’s final sound. These syllables can also appear inside lexical forms, so check the phrase boundary.

Why: Subject 이 and 가. [[Korean#^ko-Q0090|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%B4%EA%B0%80%20%EC%B0%BE%EC%95%84%20%EB%B3%BC%EA%B2%8C.)
^ko-Q0090-answer

**ko-Q0091** — 학생 할인이 있어요?

Is there a student discount?

Expected form: **할인이**

Why: Subject 이 and 가. [[Korean#^ko-Q0091|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%95%99%EC%83%9D%20%ED%95%A0%EC%9D%B8%EC%9D%B4%20%EC%9E%88%EC%96%B4%EC%9A%94%3F)
^ko-Q0091-answer

**ko-Q0092** — 학생 할인이 있어요?

Is there a student discount?

Expected form: **할인이**

Why: Subject 이 and 가. [[Korean#^ko-Q0092|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%95%99%EC%83%9D%20%ED%95%A0%EC%9D%B8%EC%9D%B4%20%EC%9E%88%EC%96%B4%EC%9A%94%3F)
^ko-Q0092-answer

**ko-Q0093** — 1939년에 제2차 세계 대전이 일어났다.

World war two broke out in 1939.

Expected form: **대전이**

Why: Subject 이 and 가. [[Korean#^ko-Q0093|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=1939%EB%85%84%EC%97%90%20%EC%A0%9C2%EC%B0%A8%20%EC%84%B8%EA%B3%84%20%EB%8C%80%EC%A0%84%EC%9D%B4%20%EC%9D%BC%EC%96%B4%EB%82%AC%EB%8B%A4.)
^ko-Q0093-answer

**ko-Q0094** — 1939년에 제2차 세계 대전이 일어났다.

World war two broke out in 1939.

Why: Subject 이 and 가. [[Korean#^ko-Q0094|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=1939%EB%85%84%EC%97%90%20%EC%A0%9C2%EC%B0%A8%20%EC%84%B8%EA%B3%84%20%EB%8C%80%EC%A0%84%EC%9D%B4%20%EC%9D%BC%EC%96%B4%EB%82%AC%EB%8B%A4.)
^ko-Q0094-answer

**ko-Q0095** — 가장 최근에 카누를 탄 적이 언제야?

When was the last time you went canoeing?

Why: Subject 이 and 가. [[Korean#^ko-Q0095|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B0%80%EC%9E%A5%20%EC%B5%9C%EA%B7%BC%EC%97%90%20%EC%B9%B4%EB%88%84%EB%A5%BC%20%ED%83%84%20%EC%A0%81%EC%9D%B4%20%EC%96%B8%EC%A0%9C%EC%95%BC%3F)
^ko-Q0095-answer

**ko-Q0096** — 가장 최근에 카누를 탄 적이 언제야?

When was the last time you went canoeing?

이/가 commonly marks a subject or focused identification. The variant follows the preceding noun’s final sound. These syllables can also appear inside lexical forms, so check the phrase boundary.

Why: Subject 이 and 가. [[Korean#^ko-Q0096|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B0%80%EC%9E%A5%20%EC%B5%9C%EA%B7%BC%EC%97%90%20%EC%B9%B4%EB%88%84%EB%A5%BC%20%ED%83%84%20%EC%A0%81%EC%9D%B4%20%EC%96%B8%EC%A0%9C%EC%95%BC%3F)
^ko-Q0096-answer

**ko-Q0097** — 메리가 피를 흘리고 있어.

Mary is losing blood.

Expected form: **메리가**

Why: Subject 이 and 가. [[Korean#^ko-Q0097|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%A9%94%EB%A6%AC%EA%B0%80%20%ED%94%BC%EB%A5%BC%20%ED%9D%98%EB%A6%AC%EA%B3%A0%20%EC%9E%88%EC%96%B4.)
^ko-Q0097-answer

**ko-Q0098** — 메리가 피를 흘리고 있어.

Mary is losing blood.

Expected form: **메리가**

Why: Subject 이 and 가. [[Korean#^ko-Q0098|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%A9%94%EB%A6%AC%EA%B0%80%20%ED%94%BC%EB%A5%BC%20%ED%9D%98%EB%A6%AC%EA%B3%A0%20%EC%9E%88%EC%96%B4.)
^ko-Q0098-answer

**ko-Q0099** — 내 실수 때문에 내 자신이 싫어.

I hate myself for my mistakes.

Expected form: **자신이**

Why: Subject 이 and 가. [[Korean#^ko-Q0099|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%B4%20%EC%8B%A4%EC%88%98%20%EB%95%8C%EB%AC%B8%EC%97%90%20%EB%82%B4%20%EC%9E%90%EC%8B%A0%EC%9D%B4%20%EC%8B%AB%EC%96%B4.)
^ko-Q0099-answer

**ko-Q0100** — 내 실수 때문에 내 자신이 싫어.

I hate myself for my mistakes.

Why: Subject 이 and 가. [[Korean#^ko-Q0100|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%B4%20%EC%8B%A4%EC%88%98%20%EB%95%8C%EB%AC%B8%EC%97%90%20%EB%82%B4%20%EC%9E%90%EC%8B%A0%EC%9D%B4%20%EC%8B%AB%EC%96%B4.)
^ko-Q0100-answer


### Answers 101–150

**ko-Q0101** — 연필을 입에 넣지 마세요, 실수로 입천장을 찌를 수 있습니다.

Don’t put a pencil in your mouth. You might accidentally stab your palate.

Why: Object 을 and 를. [[Korean#^ko-Q0101|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%97%B0%ED%95%84%EC%9D%84%20%EC%9E%85%EC%97%90%20%EB%84%A3%EC%A7%80%20%EB%A7%88%EC%84%B8%EC%9A%94%2C%20%EC%8B%A4%EC%88%98%EB%A1%9C%20%EC%9E%85%EC%B2%9C%EC%9E%A5%EC%9D%84%20%EC%B0%8C%EB%A5%BC%20%EC%88%98%20%EC%9E%88%EC%8A%B5%EB%8B%88%EB%8B%A4.)
^ko-Q0101-answer

**ko-Q0102** — 연필을 입에 넣지 마세요, 실수로 입천장을 찌를 수 있습니다.

Don’t put a pencil in your mouth. You might accidentally stab your palate.

을/를 marks many direct objects. 을 follows a consonant, 를 a vowel. It is often dropped in casual speech when the relationship remains clear.

Why: Object 을 and 를. [[Korean#^ko-Q0102|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%97%B0%ED%95%84%EC%9D%84%20%EC%9E%85%EC%97%90%20%EB%84%A3%EC%A7%80%20%EB%A7%88%EC%84%B8%EC%9A%94%2C%20%EC%8B%A4%EC%88%98%EB%A1%9C%20%EC%9E%85%EC%B2%9C%EC%9E%A5%EC%9D%84%20%EC%B0%8C%EB%A5%BC%20%EC%88%98%20%EC%9E%88%EC%8A%B5%EB%8B%88%EB%8B%A4.)
^ko-Q0102-answer

**ko-Q0103** — 몇 번을 반복해야 해?

How many times do I need to repeat it?

Expected form: **번을**

Why: Object 을 and 를. [[Korean#^ko-Q0103|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%AA%87%20%EB%B2%88%EC%9D%84%20%EB%B0%98%EB%B3%B5%ED%95%B4%EC%95%BC%20%ED%95%B4%3F)
^ko-Q0103-answer

**ko-Q0104** — 몇 번을 반복해야 해?

How many times do I need to repeat it?

Expected form: **번을**

Why: Object 을 and 를. [[Korean#^ko-Q0104|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%AA%87%20%EB%B2%88%EC%9D%84%20%EB%B0%98%EB%B3%B5%ED%95%B4%EC%95%BC%20%ED%95%B4%3F)
^ko-Q0104-answer

**ko-Q0105** — 그는 나를 기다리게 했다.

He kept me waiting.

Expected form: **나를**

Why: Object 을 and 를. [[Korean#^ko-Q0105|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EB%8A%94%20%EB%82%98%EB%A5%BC%20%EA%B8%B0%EB%8B%A4%EB%A6%AC%EA%B2%8C%20%ED%96%88%EB%8B%A4.)
^ko-Q0105-answer

**ko-Q0106** — 그는 나를 기다리게 했다.

He kept me waiting.

Why: Object 을 and 를. [[Korean#^ko-Q0106|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EB%8A%94%20%EB%82%98%EB%A5%BC%20%EA%B8%B0%EB%8B%A4%EB%A6%AC%EA%B2%8C%20%ED%96%88%EB%8B%A4.)
^ko-Q0106-answer

**ko-Q0107** — 톰은 자살을 시도했다.

Tom attempted suicide.

Why: Object 을 and 를. [[Korean#^ko-Q0107|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EC%9E%90%EC%82%B4%EC%9D%84%20%EC%8B%9C%EB%8F%84%ED%96%88%EB%8B%A4.)
^ko-Q0107-answer

**ko-Q0108** — 톰은 자살을 시도했다.

Tom attempted suicide.

을/를 marks many direct objects. 을 follows a consonant, 를 a vowel. It is often dropped in casual speech when the relationship remains clear.

Why: Object 을 and 를. [[Korean#^ko-Q0108|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EC%9E%90%EC%82%B4%EC%9D%84%20%EC%8B%9C%EB%8F%84%ED%96%88%EB%8B%A4.)
^ko-Q0108-answer

**ko-Q0109** — 저를 내버려 두세요!

Leave me in peace!

Expected form: **저를**

Why: Object 을 and 를. [[Korean#^ko-Q0109|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A0%80%EB%A5%BC%20%EB%82%B4%EB%B2%84%EB%A0%A4%20%EB%91%90%EC%84%B8%EC%9A%94%21)
^ko-Q0109-answer

**ko-Q0110** — 저를 내버려 두세요!

Leave me in peace!

Expected form: **저를**

Why: Object 을 and 를. [[Korean#^ko-Q0110|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A0%80%EB%A5%BC%20%EB%82%B4%EB%B2%84%EB%A0%A4%20%EB%91%90%EC%84%B8%EC%9A%94%21)
^ko-Q0110-answer

**ko-Q0111** — 나는 한국에 가서 맛있는 것을 먹고 싶다.

I'm going to Korea and weat to eat good food.

Expected form: **것을**

Why: Object 을 and 를. [[Korean#^ko-Q0111|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%ED%95%9C%EA%B5%AD%EC%97%90%20%EA%B0%80%EC%84%9C%20%EB%A7%9B%EC%9E%88%EB%8A%94%20%EA%B2%83%EC%9D%84%20%EB%A8%B9%EA%B3%A0%20%EC%8B%B6%EB%8B%A4.)
^ko-Q0111-answer

**ko-Q0112** — 나는 한국에 가서 맛있는 것을 먹고 싶다.

I'm going to Korea and weat to eat good food.

Why: Object 을 and 를. [[Korean#^ko-Q0112|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%ED%95%9C%EA%B5%AD%EC%97%90%20%EA%B0%80%EC%84%9C%20%EB%A7%9B%EC%9E%88%EB%8A%94%20%EA%B2%83%EC%9D%84%20%EB%A8%B9%EA%B3%A0%20%EC%8B%B6%EB%8B%A4.)
^ko-Q0112-answer

**ko-Q0113** — 탐은 이것에 대해 생각을 해봤다.

Tom gave it some thought.

Why: Object 을 and 를. [[Korean#^ko-Q0113|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%83%90%EC%9D%80%20%EC%9D%B4%EA%B2%83%EC%97%90%20%EB%8C%80%ED%95%B4%20%EC%83%9D%EA%B0%81%EC%9D%84%20%ED%95%B4%EB%B4%A4%EB%8B%A4.)
^ko-Q0113-answer

**ko-Q0114** — 탐은 이것에 대해 생각을 해봤다.

Tom gave it some thought.

을/를 marks many direct objects. 을 follows a consonant, 를 a vowel. It is often dropped in casual speech when the relationship remains clear.

Why: Object 을 and 를. [[Korean#^ko-Q0114|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%83%90%EC%9D%80%20%EC%9D%B4%EA%B2%83%EC%97%90%20%EB%8C%80%ED%95%B4%20%EC%83%9D%EA%B0%81%EC%9D%84%20%ED%95%B4%EB%B4%A4%EB%8B%A4.)
^ko-Q0114-answer

**ko-Q0115** — 새미는 치명적인 실수를 저질렀다.

Sami made a fatal mistake.

Expected form: **실수를**

Why: Object 을 and 를. [[Korean#^ko-Q0115|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%83%88%EB%AF%B8%EB%8A%94%20%EC%B9%98%EB%AA%85%EC%A0%81%EC%9D%B8%20%EC%8B%A4%EC%88%98%EB%A5%BC%20%EC%A0%80%EC%A7%88%EB%A0%80%EB%8B%A4.)
^ko-Q0115-answer

**ko-Q0116** — 새미는 치명적인 실수를 저질렀다.

Sami made a fatal mistake.

Expected form: **실수를**

Why: Object 을 and 를. [[Korean#^ko-Q0116|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%83%88%EB%AF%B8%EB%8A%94%20%EC%B9%98%EB%AA%85%EC%A0%81%EC%9D%B8%20%EC%8B%A4%EC%88%98%EB%A5%BC%20%EC%A0%80%EC%A7%88%EB%A0%80%EB%8B%A4.)
^ko-Q0116-answer

**ko-Q0117** — 나는 학생일 때 영어로 일기를 쓰곤 했다.

I used to keep a diary in English when I was a student.

Expected form: **일기를**

Why: Object 을 and 를. [[Korean#^ko-Q0117|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%ED%95%99%EC%83%9D%EC%9D%BC%20%EB%95%8C%20%EC%98%81%EC%96%B4%EB%A1%9C%20%EC%9D%BC%EA%B8%B0%EB%A5%BC%20%EC%93%B0%EA%B3%A4%20%ED%96%88%EB%8B%A4.)
^ko-Q0117-answer

**ko-Q0118** — 나는 학생일 때 영어로 일기를 쓰곤 했다.

I used to keep a diary in English when I was a student.

Why: Object 을 and 를. [[Korean#^ko-Q0118|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%ED%95%99%EC%83%9D%EC%9D%BC%20%EB%95%8C%20%EC%98%81%EC%96%B4%EB%A1%9C%20%EC%9D%BC%EA%B8%B0%EB%A5%BC%20%EC%93%B0%EA%B3%A4%20%ED%96%88%EB%8B%A4.)
^ko-Q0118-answer

**ko-Q0119** — 여자들은 대부분 화려한 결혼식을 꿈꿔.

Most women dream of a splendid wedding.

Why: Object 을 and 를. [[Korean#^ko-Q0119|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%97%AC%EC%9E%90%EB%93%A4%EC%9D%80%20%EB%8C%80%EB%B6%80%EB%B6%84%20%ED%99%94%EB%A0%A4%ED%95%9C%20%EA%B2%B0%ED%98%BC%EC%8B%9D%EC%9D%84%20%EA%BF%88%EA%BF%94.)
^ko-Q0119-answer

**ko-Q0120** — 여자들은 대부분 화려한 결혼식을 꿈꿔.

Most women dream of a splendid wedding.

을/를 marks many direct objects. 을 follows a consonant, 를 a vowel. It is often dropped in casual speech when the relationship remains clear.

Why: Object 을 and 를. [[Korean#^ko-Q0120|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%97%AC%EC%9E%90%EB%93%A4%EC%9D%80%20%EB%8C%80%EB%B6%80%EB%B6%84%20%ED%99%94%EB%A0%A4%ED%95%9C%20%EA%B2%B0%ED%98%BC%EC%8B%9D%EC%9D%84%20%EA%BF%88%EA%BF%94.)
^ko-Q0120-answer

**ko-Q0121** — 저는 남은 인생을 그것에 대해 후회하면서 지내고 싶지 않아요.

I don't want to spend the rest of my life regretting it.

Expected form: **인생을**

Why: Object 을 and 를. [[Korean#^ko-Q0121|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A0%80%EB%8A%94%20%EB%82%A8%EC%9D%80%20%EC%9D%B8%EC%83%9D%EC%9D%84%20%EA%B7%B8%EA%B2%83%EC%97%90%20%EB%8C%80%ED%95%B4%20%ED%9B%84%ED%9A%8C%ED%95%98%EB%A9%B4%EC%84%9C%20%EC%A7%80%EB%82%B4%EA%B3%A0%20%EC%8B%B6%EC%A7%80%20%EC%95%8A%EC%95%84%EC%9A%94.)
^ko-Q0121-answer

**ko-Q0122** — 저는 남은 인생을 그것에 대해 후회하면서 지내고 싶지 않아요.

I don't want to spend the rest of my life regretting it.

Expected form: **인생을**

Why: Object 을 and 를. [[Korean#^ko-Q0122|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A0%80%EB%8A%94%20%EB%82%A8%EC%9D%80%20%EC%9D%B8%EC%83%9D%EC%9D%84%20%EA%B7%B8%EA%B2%83%EC%97%90%20%EB%8C%80%ED%95%B4%20%ED%9B%84%ED%9A%8C%ED%95%98%EB%A9%B4%EC%84%9C%20%EC%A7%80%EB%82%B4%EA%B3%A0%20%EC%8B%B6%EC%A7%80%20%EC%95%8A%EC%95%84%EC%9A%94.)
^ko-Q0122-answer

**ko-Q0123** — 나는 그 책을 좋아했어.

I loved that book!

Expected form: **책을**

Why: Object 을 and 를. [[Korean#^ko-Q0123|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%EA%B7%B8%20%EC%B1%85%EC%9D%84%20%EC%A2%8B%EC%95%84%ED%96%88%EC%96%B4.)
^ko-Q0123-answer

**ko-Q0124** — 나는 그 책을 좋아했어.

I loved that book!

Why: Object 을 and 를. [[Korean#^ko-Q0124|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%EA%B7%B8%20%EC%B1%85%EC%9D%84%20%EC%A2%8B%EC%95%84%ED%96%88%EC%96%B4.)
^ko-Q0124-answer

**ko-Q0125** — 톰은 충격을 받은 것 같다.

Tom looks shocked.

Why: Object 을 and 를. [[Korean#^ko-Q0125|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EC%B6%A9%EA%B2%A9%EC%9D%84%20%EB%B0%9B%EC%9D%80%20%EA%B2%83%20%EA%B0%99%EB%8B%A4.)
^ko-Q0125-answer

**ko-Q0126** — 톰은 충격을 받은 것 같다.

Tom looks shocked.

을/를 marks many direct objects. 을 follows a consonant, 를 a vowel. It is often dropped in casual speech when the relationship remains clear.

Why: Object 을 and 를. [[Korean#^ko-Q0126|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EC%B6%A9%EA%B2%A9%EC%9D%84%20%EB%B0%9B%EC%9D%80%20%EA%B2%83%20%EA%B0%99%EB%8B%A4.)
^ko-Q0126-answer

**ko-Q0127** — 우리는 평화를 원합니다.

We want peace.

Expected form: **평화를**

Why: Object 을 and 를. [[Korean#^ko-Q0127|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9A%B0%EB%A6%AC%EB%8A%94%20%ED%8F%89%ED%99%94%EB%A5%BC%20%EC%9B%90%ED%95%A9%EB%8B%88%EB%8B%A4.)
^ko-Q0127-answer

**ko-Q0128** — 우리는 평화를 원합니다.

We want peace.

Expected form: **평화를**

Why: Object 을 and 를. [[Korean#^ko-Q0128|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9A%B0%EB%A6%AC%EB%8A%94%20%ED%8F%89%ED%99%94%EB%A5%BC%20%EC%9B%90%ED%95%A9%EB%8B%88%EB%8B%A4.)
^ko-Q0128-answer

**ko-Q0129** — 여름방학을 어디서 보냈어?

Where did you spend your summer vacation?

Expected form: **여름방학을**

Why: Object 을 and 를. [[Korean#^ko-Q0129|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%97%AC%EB%A6%84%EB%B0%A9%ED%95%99%EC%9D%84%20%EC%96%B4%EB%94%94%EC%84%9C%20%EB%B3%B4%EB%83%88%EC%96%B4%3F)
^ko-Q0129-answer

**ko-Q0130** — 여름방학을 어디서 보냈어?

Where did you spend your summer vacation?

Why: Object 을 and 를. [[Korean#^ko-Q0130|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%97%AC%EB%A6%84%EB%B0%A9%ED%95%99%EC%9D%84%20%EC%96%B4%EB%94%94%EC%84%9C%20%EB%B3%B4%EB%83%88%EC%96%B4%3F)
^ko-Q0130-answer

**ko-Q0131** — 그녀는 털실로 스웨터를 짠다.

She knits a wool sweater.

Why: Object 을 and 를. [[Korean#^ko-Q0131|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EB%85%80%EB%8A%94%20%ED%84%B8%EC%8B%A4%EB%A1%9C%20%EC%8A%A4%EC%9B%A8%ED%84%B0%EB%A5%BC%20%EC%A7%A0%EB%8B%A4.)
^ko-Q0131-answer

**ko-Q0132** — 그녀는 털실로 스웨터를 짠다.

She knits a wool sweater.

을/를 marks many direct objects. 을 follows a consonant, 를 a vowel. It is often dropped in casual speech when the relationship remains clear.

Why: Object 을 and 를. [[Korean#^ko-Q0132|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EB%85%80%EB%8A%94%20%ED%84%B8%EC%8B%A4%EB%A1%9C%20%EC%8A%A4%EC%9B%A8%ED%84%B0%EB%A5%BC%20%EC%A7%A0%EB%8B%A4.)
^ko-Q0132-answer

**ko-Q0133** — 나는 내년에 중국어를 배우고 싶다.

I want to learn Chinese next year.

Expected form: **중국어를**

Why: Object 을 and 를. [[Korean#^ko-Q0133|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%EB%82%B4%EB%85%84%EC%97%90%20%EC%A4%91%EA%B5%AD%EC%96%B4%EB%A5%BC%20%EB%B0%B0%EC%9A%B0%EA%B3%A0%20%EC%8B%B6%EB%8B%A4.)
^ko-Q0133-answer

**ko-Q0134** — 나는 내년에 중국어를 배우고 싶다.

I want to learn Chinese next year.

Expected form: **중국어를**

Why: Object 을 and 를. [[Korean#^ko-Q0134|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%EB%82%B4%EB%85%84%EC%97%90%20%EC%A4%91%EA%B5%AD%EC%96%B4%EB%A5%BC%20%EB%B0%B0%EC%9A%B0%EA%B3%A0%20%EC%8B%B6%EB%8B%A4.)
^ko-Q0134-answer

**ko-Q0135** — Emily가 편지를 쓰고 있다.

Emily is writing a letter.

Expected form: **편지를**

Why: Object 을 and 를. [[Korean#^ko-Q0135|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=Emily%EA%B0%80%20%ED%8E%B8%EC%A7%80%EB%A5%BC%20%EC%93%B0%EA%B3%A0%20%EC%9E%88%EB%8B%A4.)
^ko-Q0135-answer

**ko-Q0136** — Emily가 편지를 쓰고 있다.

Emily is writing a letter.

Why: Object 을 and 를. [[Korean#^ko-Q0136|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=Emily%EA%B0%80%20%ED%8E%B8%EC%A7%80%EB%A5%BC%20%EC%93%B0%EA%B3%A0%20%EC%9E%88%EB%8B%A4.)
^ko-Q0136-answer

**ko-Q0137** — 그녀는 관리자를 비난했다는 소식을 듣게 되었다.

She was heard to criticize the manager.

Why: Object 을 and 를. [[Korean#^ko-Q0137|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EB%85%80%EB%8A%94%20%EA%B4%80%EB%A6%AC%EC%9E%90%EB%A5%BC%20%EB%B9%84%EB%82%9C%ED%96%88%EB%8B%A4%EB%8A%94%20%EC%86%8C%EC%8B%9D%EC%9D%84%20%EB%93%A3%EA%B2%8C%20%EB%90%98%EC%97%88%EB%8B%A4.)
^ko-Q0137-answer

**ko-Q0138** — 그녀는 관리자를 비난했다는 소식을 듣게 되었다.

She was heard to criticize the manager.

을/를 marks many direct objects. 을 follows a consonant, 를 a vowel. It is often dropped in casual speech when the relationship remains clear.

Why: Object 을 and 를. [[Korean#^ko-Q0138|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EB%85%80%EB%8A%94%20%EA%B4%80%EB%A6%AC%EC%9E%90%EB%A5%BC%20%EB%B9%84%EB%82%9C%ED%96%88%EB%8B%A4%EB%8A%94%20%EC%86%8C%EC%8B%9D%EC%9D%84%20%EB%93%A3%EA%B2%8C%20%EB%90%98%EC%97%88%EB%8B%A4.)
^ko-Q0138-answer

**ko-Q0139** — 나는 톰에게 도움을 요청했다.

I called Tom for help.

Expected form: **도움을**

Why: Object 을 and 를. [[Korean#^ko-Q0139|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%ED%86%B0%EC%97%90%EA%B2%8C%20%EB%8F%84%EC%9B%80%EC%9D%84%20%EC%9A%94%EC%B2%AD%ED%96%88%EB%8B%A4.)
^ko-Q0139-answer

**ko-Q0140** — 나는 톰에게 도움을 요청했다.

I called Tom for help.

Expected form: **도움을**

Why: Object 을 and 를. [[Korean#^ko-Q0140|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%ED%86%B0%EC%97%90%EA%B2%8C%20%EB%8F%84%EC%9B%80%EC%9D%84%20%EC%9A%94%EC%B2%AD%ED%96%88%EB%8B%A4.)
^ko-Q0140-answer

**ko-Q0141** — 난 프랑스어를 잊어버리기 시작했어.

I'm beginning to forget my French.

Expected form: **프랑스어를**

Why: Object 을 and 를. [[Korean#^ko-Q0141|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%9C%20%ED%94%84%EB%9E%91%EC%8A%A4%EC%96%B4%EB%A5%BC%20%EC%9E%8A%EC%96%B4%EB%B2%84%EB%A6%AC%EA%B8%B0%20%EC%8B%9C%EC%9E%91%ED%96%88%EC%96%B4.)
^ko-Q0141-answer

**ko-Q0142** — 난 프랑스어를 잊어버리기 시작했어.

I'm beginning to forget my French.

Why: Object 을 and 를. [[Korean#^ko-Q0142|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%9C%20%ED%94%84%EB%9E%91%EC%8A%A4%EC%96%B4%EB%A5%BC%20%EC%9E%8A%EC%96%B4%EB%B2%84%EB%A6%AC%EA%B8%B0%20%EC%8B%9C%EC%9E%91%ED%96%88%EC%96%B4.)
^ko-Q0142-answer

**ko-Q0143** — 동물원은 동물들을 위한 감옥 같다.

Zoos are like prisons for animals.

Why: Object 을 and 를. [[Korean#^ko-Q0143|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%8F%99%EB%AC%BC%EC%9B%90%EC%9D%80%20%EB%8F%99%EB%AC%BC%EB%93%A4%EC%9D%84%20%EC%9C%84%ED%95%9C%20%EA%B0%90%EC%98%A5%20%EA%B0%99%EB%8B%A4.)
^ko-Q0143-answer

**ko-Q0144** — 동물원은 동물들을 위한 감옥 같다.

Zoos are like prisons for animals.

을/를 marks many direct objects. 을 follows a consonant, 를 a vowel. It is often dropped in casual speech when the relationship remains clear.

Why: Object 을 and 를. [[Korean#^ko-Q0144|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%8F%99%EB%AC%BC%EC%9B%90%EC%9D%80%20%EB%8F%99%EB%AC%BC%EB%93%A4%EC%9D%84%20%EC%9C%84%ED%95%9C%20%EA%B0%90%EC%98%A5%20%EA%B0%99%EB%8B%A4.)
^ko-Q0144-answer

**ko-Q0145** — 무엇이 그들을 죽였나?

What killed them?

Expected form: **그들을**

Why: Object 을 and 를. [[Korean#^ko-Q0145|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%AC%B4%EC%97%87%EC%9D%B4%20%EA%B7%B8%EB%93%A4%EC%9D%84%20%EC%A3%BD%EC%98%80%EB%82%98%3F)
^ko-Q0145-answer

**ko-Q0146** — 무엇이 그들을 죽였나?

What killed them?

Expected form: **그들을**

Why: Object 을 and 를. [[Korean#^ko-Q0146|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%AC%B4%EC%97%87%EC%9D%B4%20%EA%B7%B8%EB%93%A4%EC%9D%84%20%EC%A3%BD%EC%98%80%EB%82%98%3F)
^ko-Q0146-answer

**ko-Q0147** — 이야기를 마저 들어보자.

Let's hear the rest of the story.

Expected form: **이야기를**

Why: Object 을 and 를. [[Korean#^ko-Q0147|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9D%B4%EC%95%BC%EA%B8%B0%EB%A5%BC%20%EB%A7%88%EC%A0%80%20%EB%93%A4%EC%96%B4%EB%B3%B4%EC%9E%90.)
^ko-Q0147-answer

**ko-Q0148** — 이야기를 마저 들어보자.

Let's hear the rest of the story.

Why: Object 을 and 를. [[Korean#^ko-Q0148|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9D%B4%EC%95%BC%EA%B8%B0%EB%A5%BC%20%EB%A7%88%EC%A0%80%20%EB%93%A4%EC%96%B4%EB%B3%B4%EC%9E%90.)
^ko-Q0148-answer

**ko-Q0149** — 톰은 마리가 그것을 해야만 한다고 생각하지 않는다고 말했다.

Tom says he doesn't think Mary ought to do that.

Why: Object 을 and 를. [[Korean#^ko-Q0149|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EB%A7%88%EB%A6%AC%EA%B0%80%20%EA%B7%B8%EA%B2%83%EC%9D%84%20%ED%95%B4%EC%95%BC%EB%A7%8C%20%ED%95%9C%EB%8B%A4%EA%B3%A0%20%EC%83%9D%EA%B0%81%ED%95%98%EC%A7%80%20%EC%95%8A%EB%8A%94%EB%8B%A4%EA%B3%A0%20%EB%A7%90%ED%96%88%EB%8B%A4.)
^ko-Q0149-answer

**ko-Q0150** — 톰은 마리가 그것을 해야만 한다고 생각하지 않는다고 말했다.

Tom says he doesn't think Mary ought to do that.

을/를 marks many direct objects. 을 follows a consonant, 를 a vowel. It is often dropped in casual speech when the relationship remains clear.

Why: Object 을 and 를. [[Korean#^ko-Q0150|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EB%A7%88%EB%A6%AC%EA%B0%80%20%EA%B7%B8%EA%B2%83%EC%9D%84%20%ED%95%B4%EC%95%BC%EB%A7%8C%20%ED%95%9C%EB%8B%A4%EA%B3%A0%20%EC%83%9D%EA%B0%81%ED%95%98%EC%A7%80%20%EC%95%8A%EB%8A%94%EB%8B%A4%EA%B3%A0%20%EB%A7%90%ED%96%88%EB%8B%A4.)
^ko-Q0150-answer


### Answers 151–200

**ko-Q0151** — 나 오늘밤 너의 파티에 가도 돼?

Can I come to your party tonight?

Expected form: **파티에**

Why: Destination and location 에. [[Korean#^ko-Q0151|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%20%EC%98%A4%EB%8A%98%EB%B0%A4%20%EB%84%88%EC%9D%98%20%ED%8C%8C%ED%8B%B0%EC%97%90%20%EA%B0%80%EB%8F%84%20%EB%8F%BC%3F)
^ko-Q0151-answer

**ko-Q0152** — 나 오늘밤 너의 파티에 가도 돼?

Can I come to your party tonight?

Expected form: **파티에**

Why: Destination and location 에. [[Korean#^ko-Q0152|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%20%EC%98%A4%EB%8A%98%EB%B0%A4%20%EB%84%88%EC%9D%98%20%ED%8C%8C%ED%8B%B0%EC%97%90%20%EA%B0%80%EB%8F%84%20%EB%8F%BC%3F)
^ko-Q0152-answer

**ko-Q0153** — 톰은 정원에 앉아 있어.

Tom was sitting in the garden.

Expected form: **정원에**

Why: Destination and location 에. [[Korean#^ko-Q0153|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EC%A0%95%EC%9B%90%EC%97%90%20%EC%95%89%EC%95%84%20%EC%9E%88%EC%96%B4.)
^ko-Q0153-answer

**ko-Q0154** — 톰은 정원에 앉아 있어.

Tom was sitting in the garden.

Why: Destination and location 에. [[Korean#^ko-Q0154|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EC%A0%95%EC%9B%90%EC%97%90%20%EC%95%89%EC%95%84%20%EC%9E%88%EC%96%B4.)
^ko-Q0154-answer

**ko-Q0155** — 오랜만에 늦게까지 잤는데.

For the first time in ages, I slept late.

Why: Destination and location 에. [[Korean#^ko-Q0155|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%98%A4%EB%9E%9C%EB%A7%8C%EC%97%90%20%EB%8A%A6%EA%B2%8C%EA%B9%8C%EC%A7%80%20%EC%9E%A4%EB%8A%94%EB%8D%B0.)
^ko-Q0155-answer

**ko-Q0156** — 오랜만에 늦게까지 잤는데.

For the first time in ages, I slept late.

에 marks many destinations, times and locations with existence predicates. Event location often uses 에서 instead. The predicate determines the appropriate relation.

Why: Destination and location 에. [[Korean#^ko-Q0156|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%98%A4%EB%9E%9C%EB%A7%8C%EC%97%90%20%EB%8A%A6%EA%B2%8C%EA%B9%8C%EC%A7%80%20%EC%9E%A4%EB%8A%94%EB%8D%B0.)
^ko-Q0156-answer

**ko-Q0157** — 아마 오늘 밤에 도착할 거예요.

Maybe he will arrive tonight.

Expected form: **밤에**

Why: Destination and location 에. [[Korean#^ko-Q0157|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%95%84%EB%A7%88%20%EC%98%A4%EB%8A%98%20%EB%B0%A4%EC%97%90%20%EB%8F%84%EC%B0%A9%ED%95%A0%20%EA%B1%B0%EC%98%88%EC%9A%94.)
^ko-Q0157-answer

**ko-Q0158** — 아마 오늘 밤에 도착할 거예요.

Maybe he will arrive tonight.

Expected form: **밤에**

Why: Destination and location 에. [[Korean#^ko-Q0158|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%95%84%EB%A7%88%20%EC%98%A4%EB%8A%98%20%EB%B0%A4%EC%97%90%20%EB%8F%84%EC%B0%A9%ED%95%A0%20%EA%B1%B0%EC%98%88%EC%9A%94.)
^ko-Q0158-answer

**ko-Q0159** — 한국에 가고 싶어요.

I want to go to Korea.

Expected form: **한국에**

Why: Destination and location 에. [[Korean#^ko-Q0159|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%95%9C%EA%B5%AD%EC%97%90%20%EA%B0%80%EA%B3%A0%20%EC%8B%B6%EC%96%B4%EC%9A%94.)
^ko-Q0159-answer

**ko-Q0160** — 한국에 가고 싶어요.

I want to go to Korea.

Why: Destination and location 에. [[Korean#^ko-Q0160|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%95%9C%EA%B5%AD%EC%97%90%20%EA%B0%80%EA%B3%A0%20%EC%8B%B6%EC%96%B4%EC%9A%94.)
^ko-Q0160-answer

**ko-Q0161** — 그는 평화 속에 살고 있다.

He lives in peace.

Why: Destination and location 에. [[Korean#^ko-Q0161|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EB%8A%94%20%ED%8F%89%ED%99%94%20%EC%86%8D%EC%97%90%20%EC%82%B4%EA%B3%A0%20%EC%9E%88%EB%8B%A4.)
^ko-Q0161-answer

**ko-Q0162** — 그는 평화 속에 살고 있다.

He lives in peace.

에 marks many destinations, times and locations with existence predicates. Event location often uses 에서 instead. The predicate determines the appropriate relation.

Why: Destination and location 에. [[Korean#^ko-Q0162|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EB%8A%94%20%ED%8F%89%ED%99%94%20%EC%86%8D%EC%97%90%20%EC%82%B4%EA%B3%A0%20%EC%9E%88%EB%8B%A4.)
^ko-Q0162-answer

**ko-Q0163** — 그는 내일 오후에 떠날 예정이다.

He is going to leave tomorrow afternoon.

Expected form: **오후에**

Why: Destination and location 에. [[Korean#^ko-Q0163|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EB%8A%94%20%EB%82%B4%EC%9D%BC%20%EC%98%A4%ED%9B%84%EC%97%90%20%EB%96%A0%EB%82%A0%20%EC%98%88%EC%A0%95%EC%9D%B4%EB%8B%A4.)
^ko-Q0163-answer

**ko-Q0164** — 그는 내일 오후에 떠날 예정이다.

He is going to leave tomorrow afternoon.

Expected form: **오후에**

Why: Destination and location 에. [[Korean#^ko-Q0164|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EB%8A%94%20%EB%82%B4%EC%9D%BC%20%EC%98%A4%ED%9B%84%EC%97%90%20%EB%96%A0%EB%82%A0%20%EC%98%88%EC%A0%95%EC%9D%B4%EB%8B%A4.)
^ko-Q0164-answer

**ko-Q0165** — 나는 남과 다르게 멋있게 보이고 싶어서 하와이안 티셔츠와 녹색 반바지 입는 걸 좋아했지만, 빠르게 흰색 셔츠와 검정 바지에 익숙해졌다.

I preferred wearing my Hawaiian T-shirt and green shorts to be cool and different, but I quickly got used to the white shirt and black slacks.

Expected form: **바지에**

Why: Destination and location 에. [[Korean#^ko-Q0165|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%EB%82%A8%EA%B3%BC%20%EB%8B%A4%EB%A5%B4%EA%B2%8C%20%EB%A9%8B%EC%9E%88%EA%B2%8C%20%EB%B3%B4%EC%9D%B4%EA%B3%A0%20%EC%8B%B6%EC%96%B4%EC%84%9C%20%ED%95%98%EC%99%80%EC%9D%B4%EC%95%88%20%ED%8B%B0%EC%85%94%EC%B8%A0%EC%99%80%20%EB%85%B9%EC%83%89%20%EB%B0%98%EB%B0%94%EC%A7%80%20%EC%9E%85%EB%8A%94%20%EA%B1%B8%20%EC%A2%8B%EC%95%84%ED%96%88%EC%A7%80%EB%A7%8C%2C%20%EB%B9%A0%EB%A5%B4%EA%B2%8C%20%ED%9D%B0%EC%83%89%20%EC%85%94%EC%B8%A0%EC%99%80%20%EA%B2%80%EC%A0%95%20%EB%B0%94%EC%A7%80%EC%97%90%20%EC%9D%B5%EC%88%99%ED%95%B4%EC%A1%8C%EB%8B%A4.)
^ko-Q0165-answer

**ko-Q0166** — 나는 남과 다르게 멋있게 보이고 싶어서 하와이안 티셔츠와 녹색 반바지 입는 걸 좋아했지만, 빠르게 흰색 셔츠와 검정 바지에 익숙해졌다.

I preferred wearing my Hawaiian T-shirt and green shorts to be cool and different, but I quickly got used to the white shirt and black slacks.

Why: Destination and location 에. [[Korean#^ko-Q0166|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%EB%82%A8%EA%B3%BC%20%EB%8B%A4%EB%A5%B4%EA%B2%8C%20%EB%A9%8B%EC%9E%88%EA%B2%8C%20%EB%B3%B4%EC%9D%B4%EA%B3%A0%20%EC%8B%B6%EC%96%B4%EC%84%9C%20%ED%95%98%EC%99%80%EC%9D%B4%EC%95%88%20%ED%8B%B0%EC%85%94%EC%B8%A0%EC%99%80%20%EB%85%B9%EC%83%89%20%EB%B0%98%EB%B0%94%EC%A7%80%20%EC%9E%85%EB%8A%94%20%EA%B1%B8%20%EC%A2%8B%EC%95%84%ED%96%88%EC%A7%80%EB%A7%8C%2C%20%EB%B9%A0%EB%A5%B4%EA%B2%8C%20%ED%9D%B0%EC%83%89%20%EC%85%94%EC%B8%A0%EC%99%80%20%EA%B2%80%EC%A0%95%20%EB%B0%94%EC%A7%80%EC%97%90%20%EC%9D%B5%EC%88%99%ED%95%B4%EC%A1%8C%EB%8B%A4.)
^ko-Q0166-answer

**ko-Q0167** — 그녀의 눈에 눈물이 고였다.

Her eyes welled up with tears.

Why: Destination and location 에. [[Korean#^ko-Q0167|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EB%85%80%EC%9D%98%20%EB%88%88%EC%97%90%20%EB%88%88%EB%AC%BC%EC%9D%B4%20%EA%B3%A0%EC%98%80%EB%8B%A4.)
^ko-Q0167-answer

**ko-Q0168** — 그녀의 눈에 눈물이 고였다.

Her eyes welled up with tears.

에 marks many destinations, times and locations with existence predicates. Event location often uses 에서 instead. The predicate determines the appropriate relation.

Why: Destination and location 에. [[Korean#^ko-Q0168|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EB%85%80%EC%9D%98%20%EB%88%88%EC%97%90%20%EB%88%88%EB%AC%BC%EC%9D%B4%20%EA%B3%A0%EC%98%80%EB%8B%A4.)
^ko-Q0168-answer

**ko-Q0169** — 사랑과 우정 사이에 경계선을 긋는 것은 매우 어려운 일이다.

It is very difficult to draw the boundary between love and friendship.

Expected form: **사이에**

Why: Destination and location 에. [[Korean#^ko-Q0169|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%82%AC%EB%9E%91%EA%B3%BC%20%EC%9A%B0%EC%A0%95%20%EC%82%AC%EC%9D%B4%EC%97%90%20%EA%B2%BD%EA%B3%84%EC%84%A0%EC%9D%84%20%EA%B8%8B%EB%8A%94%20%EA%B2%83%EC%9D%80%20%EB%A7%A4%EC%9A%B0%20%EC%96%B4%EB%A0%A4%EC%9A%B4%20%EC%9D%BC%EC%9D%B4%EB%8B%A4.)
^ko-Q0169-answer

**ko-Q0170** — 사랑과 우정 사이에 경계선을 긋는 것은 매우 어려운 일이다.

It is very difficult to draw the boundary between love and friendship.

Expected form: **사이에**

Why: Destination and location 에. [[Korean#^ko-Q0170|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%82%AC%EB%9E%91%EA%B3%BC%20%EC%9A%B0%EC%A0%95%20%EC%82%AC%EC%9D%B4%EC%97%90%20%EA%B2%BD%EA%B3%84%EC%84%A0%EC%9D%84%20%EA%B8%8B%EB%8A%94%20%EA%B2%83%EC%9D%80%20%EB%A7%A4%EC%9A%B0%20%EC%96%B4%EB%A0%A4%EC%9A%B4%20%EC%9D%BC%EC%9D%B4%EB%8B%A4.)
^ko-Q0170-answer

**ko-Q0171** — 그는 상자 여섯 개를 한 번에 날랐다.

He carried six boxes at a time.

Expected form: **번에**

Why: Destination and location 에. [[Korean#^ko-Q0171|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EB%8A%94%20%EC%83%81%EC%9E%90%20%EC%97%AC%EC%84%AF%20%EA%B0%9C%EB%A5%BC%20%ED%95%9C%20%EB%B2%88%EC%97%90%20%EB%82%A0%EB%9E%90%EB%8B%A4.)
^ko-Q0171-answer

**ko-Q0172** — 그는 상자 여섯 개를 한 번에 날랐다.

He carried six boxes at a time.

Why: Destination and location 에. [[Korean#^ko-Q0172|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EB%8A%94%20%EC%83%81%EC%9E%90%20%EC%97%AC%EC%84%AF%20%EA%B0%9C%EB%A5%BC%20%ED%95%9C%20%EB%B2%88%EC%97%90%20%EB%82%A0%EB%9E%90%EB%8B%A4.)
^ko-Q0172-answer

**ko-Q0173** — 꽃에 물을 줘야겠다. 잎들이 벌써 시들었다.

The flower needs watering. The leaves are already wilted.

Why: Destination and location 에. [[Korean#^ko-Q0173|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%BD%83%EC%97%90%20%EB%AC%BC%EC%9D%84%20%EC%A4%98%EC%95%BC%EA%B2%A0%EB%8B%A4.%20%EC%9E%8E%EB%93%A4%EC%9D%B4%20%EB%B2%8C%EC%8D%A8%20%EC%8B%9C%EB%93%A4%EC%97%88%EB%8B%A4.)
^ko-Q0173-answer

**ko-Q0174** — 꽃에 물을 줘야겠다. 잎들이 벌써 시들었다.

The flower needs watering. The leaves are already wilted.

에 marks many destinations, times and locations with existence predicates. Event location often uses 에서 instead. The predicate determines the appropriate relation.

Why: Destination and location 에. [[Korean#^ko-Q0174|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%BD%83%EC%97%90%20%EB%AC%BC%EC%9D%84%20%EC%A4%98%EC%95%BC%EA%B2%A0%EB%8B%A4.%20%EC%9E%8E%EB%93%A4%EC%9D%B4%20%EB%B2%8C%EC%8D%A8%20%EC%8B%9C%EB%93%A4%EC%97%88%EB%8B%A4.)
^ko-Q0174-answer

**ko-Q0175** — 진수 씨가 저를 도와주신 것을 감사하는 뜻으로 저녁에 초대하려고 해요.

I wanted to invite Mr. Jinsu this evening to thank him for helping me earlier.

Expected form: **저녁에**

Why: Destination and location 에. [[Korean#^ko-Q0175|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A7%84%EC%88%98%20%EC%94%A8%EA%B0%80%20%EC%A0%80%EB%A5%BC%20%EB%8F%84%EC%99%80%EC%A3%BC%EC%8B%A0%20%EA%B2%83%EC%9D%84%20%EA%B0%90%EC%82%AC%ED%95%98%EB%8A%94%20%EB%9C%BB%EC%9C%BC%EB%A1%9C%20%EC%A0%80%EB%85%81%EC%97%90%20%EC%B4%88%EB%8C%80%ED%95%98%EB%A0%A4%EA%B3%A0%20%ED%95%B4%EC%9A%94.)
^ko-Q0175-answer

**ko-Q0176** — 진수 씨가 저를 도와주신 것을 감사하는 뜻으로 저녁에 초대하려고 해요.

I wanted to invite Mr. Jinsu this evening to thank him for helping me earlier.

Expected form: **저녁에**

Why: Destination and location 에. [[Korean#^ko-Q0176|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A7%84%EC%88%98%20%EC%94%A8%EA%B0%80%20%EC%A0%80%EB%A5%BC%20%EB%8F%84%EC%99%80%EC%A3%BC%EC%8B%A0%20%EA%B2%83%EC%9D%84%20%EA%B0%90%EC%82%AC%ED%95%98%EB%8A%94%20%EB%9C%BB%EC%9C%BC%EB%A1%9C%20%EC%A0%80%EB%85%81%EC%97%90%20%EC%B4%88%EB%8C%80%ED%95%98%EB%A0%A4%EA%B3%A0%20%ED%95%B4%EC%9A%94.)
^ko-Q0176-answer

**ko-Q0177** — 우리는 내일 아침에 집을 떠날 것이다.

We'll leave the house tomorrow morning.

Expected form: **아침에**

Why: Destination and location 에. [[Korean#^ko-Q0177|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9A%B0%EB%A6%AC%EB%8A%94%20%EB%82%B4%EC%9D%BC%20%EC%95%84%EC%B9%A8%EC%97%90%20%EC%A7%91%EC%9D%84%20%EB%96%A0%EB%82%A0%20%EA%B2%83%EC%9D%B4%EB%8B%A4.)
^ko-Q0177-answer

**ko-Q0178** — 우리는 내일 아침에 집을 떠날 것이다.

We'll leave the house tomorrow morning.

Why: Destination and location 에. [[Korean#^ko-Q0178|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9A%B0%EB%A6%AC%EB%8A%94%20%EB%82%B4%EC%9D%BC%20%EC%95%84%EC%B9%A8%EC%97%90%20%EC%A7%91%EC%9D%84%20%EB%96%A0%EB%82%A0%20%EA%B2%83%EC%9D%B4%EB%8B%A4.)
^ko-Q0178-answer

**ko-Q0179** — 톰은 여기에 두세요.

Keep Tom there.

Why: Destination and location 에. [[Korean#^ko-Q0179|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EC%97%AC%EA%B8%B0%EC%97%90%20%EB%91%90%EC%84%B8%EC%9A%94.)
^ko-Q0179-answer

**ko-Q0180** — 톰은 여기에 두세요.

Keep Tom there.

에 marks many destinations, times and locations with existence predicates. Event location often uses 에서 instead. The predicate determines the appropriate relation.

Why: Destination and location 에. [[Korean#^ko-Q0180|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EC%97%AC%EA%B8%B0%EC%97%90%20%EB%91%90%EC%84%B8%EC%9A%94.)
^ko-Q0180-answer

**ko-Q0181** — 우리가 단번에 성공하지 못해도 내가 임신할 때까지 계속 섹스할 수 있어.

Even if we don't get lucky on the first try we can just keep fucking till I get pregnant.

Expected form: **단번에**

Why: Destination and location 에. [[Korean#^ko-Q0181|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9A%B0%EB%A6%AC%EA%B0%80%20%EB%8B%A8%EB%B2%88%EC%97%90%20%EC%84%B1%EA%B3%B5%ED%95%98%EC%A7%80%20%EB%AA%BB%ED%95%B4%EB%8F%84%20%EB%82%B4%EA%B0%80%20%EC%9E%84%EC%8B%A0%ED%95%A0%20%EB%95%8C%EA%B9%8C%EC%A7%80%20%EA%B3%84%EC%86%8D%20%EC%84%B9%EC%8A%A4%ED%95%A0%20%EC%88%98%20%EC%9E%88%EC%96%B4.)
^ko-Q0181-answer

**ko-Q0182** — 우리가 단번에 성공하지 못해도 내가 임신할 때까지 계속 섹스할 수 있어.

Even if we don't get lucky on the first try we can just keep fucking till I get pregnant.

Expected form: **단번에**

Why: Destination and location 에. [[Korean#^ko-Q0182|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9A%B0%EB%A6%AC%EA%B0%80%20%EB%8B%A8%EB%B2%88%EC%97%90%20%EC%84%B1%EA%B3%B5%ED%95%98%EC%A7%80%20%EB%AA%BB%ED%95%B4%EB%8F%84%20%EB%82%B4%EA%B0%80%20%EC%9E%84%EC%8B%A0%ED%95%A0%20%EB%95%8C%EA%B9%8C%EC%A7%80%20%EA%B3%84%EC%86%8D%20%EC%84%B9%EC%8A%A4%ED%95%A0%20%EC%88%98%20%EC%9E%88%EC%96%B4.)
^ko-Q0182-answer

**ko-Q0183** — 이 가게 마음에 안들어.

I don't like this store.

Expected form: **마음에**

Why: Destination and location 에. [[Korean#^ko-Q0183|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9D%B4%20%EA%B0%80%EA%B2%8C%20%EB%A7%88%EC%9D%8C%EC%97%90%20%EC%95%88%EB%93%A4%EC%96%B4.)
^ko-Q0183-answer

**ko-Q0184** — 이 가게 마음에 안들어.

I don't like this store.

Why: Destination and location 에. [[Korean#^ko-Q0184|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9D%B4%20%EA%B0%80%EA%B2%8C%20%EB%A7%88%EC%9D%8C%EC%97%90%20%EC%95%88%EB%93%A4%EC%96%B4.)
^ko-Q0184-answer

**ko-Q0185** — 매년 겨울에 내 입술이 튼다.

I get chapped lips every winter.

Why: Destination and location 에. [[Korean#^ko-Q0185|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%A7%A4%EB%85%84%20%EA%B2%A8%EC%9A%B8%EC%97%90%20%EB%82%B4%20%EC%9E%85%EC%88%A0%EC%9D%B4%20%ED%8A%BC%EB%8B%A4.)
^ko-Q0185-answer

**ko-Q0186** — 매년 겨울에 내 입술이 튼다.

I get chapped lips every winter.

에 marks many destinations, times and locations with existence predicates. Event location often uses 에서 instead. The predicate determines the appropriate relation.

Why: Destination and location 에. [[Korean#^ko-Q0186|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%A7%A4%EB%85%84%20%EA%B2%A8%EC%9A%B8%EC%97%90%20%EB%82%B4%20%EC%9E%85%EC%88%A0%EC%9D%B4%20%ED%8A%BC%EB%8B%A4.)
^ko-Q0186-answer

**ko-Q0187** — 나는 당신의 질문에 답할 수 없어요.

I can not answer your question.

Expected form: **질문에**

Why: Destination and location 에. [[Korean#^ko-Q0187|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%EB%8B%B9%EC%8B%A0%EC%9D%98%20%EC%A7%88%EB%AC%B8%EC%97%90%20%EB%8B%B5%ED%95%A0%20%EC%88%98%20%EC%97%86%EC%96%B4%EC%9A%94.)
^ko-Q0187-answer

**ko-Q0188** — 나는 당신의 질문에 답할 수 없어요.

I can not answer your question.

Expected form: **질문에**

Why: Destination and location 에. [[Korean#^ko-Q0188|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%EB%8B%B9%EC%8B%A0%EC%9D%98%20%EC%A7%88%EB%AC%B8%EC%97%90%20%EB%8B%B5%ED%95%A0%20%EC%88%98%20%EC%97%86%EC%96%B4%EC%9A%94.)
^ko-Q0188-answer

**ko-Q0189** — 수면 부족이 점차 건강에 영향을 미친다.

Lack of sleep can gradually affect health.

Expected form: **건강에**

Why: Destination and location 에. [[Korean#^ko-Q0189|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%88%98%EB%A9%B4%20%EB%B6%80%EC%A1%B1%EC%9D%B4%20%EC%A0%90%EC%B0%A8%20%EA%B1%B4%EA%B0%95%EC%97%90%20%EC%98%81%ED%96%A5%EC%9D%84%20%EB%AF%B8%EC%B9%9C%EB%8B%A4.)
^ko-Q0189-answer

**ko-Q0190** — 수면 부족이 점차 건강에 영향을 미친다.

Lack of sleep can gradually affect health.

Why: Destination and location 에. [[Korean#^ko-Q0190|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%88%98%EB%A9%B4%20%EB%B6%80%EC%A1%B1%EC%9D%B4%20%EC%A0%90%EC%B0%A8%20%EA%B1%B4%EA%B0%95%EC%97%90%20%EC%98%81%ED%96%A5%EC%9D%84%20%EB%AF%B8%EC%B9%9C%EB%8B%A4.)
^ko-Q0190-answer

**ko-Q0191** — 그걸 어디에 숨겼니?

Where did you hide them?

Why: Destination and location 에. [[Korean#^ko-Q0191|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EA%B1%B8%20%EC%96%B4%EB%94%94%EC%97%90%20%EC%88%A8%EA%B2%BC%EB%8B%88%3F)
^ko-Q0191-answer

**ko-Q0192** — 그걸 어디에 숨겼니?

Where did you hide them?

에 marks many destinations, times and locations with existence predicates. Event location often uses 에서 instead. The predicate determines the appropriate relation.

Why: Destination and location 에. [[Korean#^ko-Q0192|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EA%B1%B8%20%EC%96%B4%EB%94%94%EC%97%90%20%EC%88%A8%EA%B2%BC%EB%8B%88%3F)
^ko-Q0192-answer

**ko-Q0193** — 네가 중병에 걸린 적이 없다는 게 사실이야?

Is it true you've never had a serious illness?

Expected form: **중병에**

Why: Destination and location 에. [[Korean#^ko-Q0193|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%84%A4%EA%B0%80%20%EC%A4%91%EB%B3%91%EC%97%90%20%EA%B1%B8%EB%A6%B0%20%EC%A0%81%EC%9D%B4%20%EC%97%86%EB%8B%A4%EB%8A%94%20%EA%B2%8C%20%EC%82%AC%EC%8B%A4%EC%9D%B4%EC%95%BC%3F)
^ko-Q0193-answer

**ko-Q0194** — 네가 중병에 걸린 적이 없다는 게 사실이야?

Is it true you've never had a serious illness?

Expected form: **중병에**

Why: Destination and location 에. [[Korean#^ko-Q0194|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%84%A4%EA%B0%80%20%EC%A4%91%EB%B3%91%EC%97%90%20%EA%B1%B8%EB%A6%B0%20%EC%A0%81%EC%9D%B4%20%EC%97%86%EB%8B%A4%EB%8A%94%20%EA%B2%8C%20%EC%82%AC%EC%8B%A4%EC%9D%B4%EC%95%BC%3F)
^ko-Q0194-answer

**ko-Q0195** — 나는 여기 온 뒤로 한 번도 바다에 들어가고 싶다는 생각을 안 했지만 지금 이 순간에 어쩐 일인지 옷을 벗어 버리고 싶었어요.

I had not once thought about going into the sea since I came here, but at this moment, for some reason, I wanted to remove my clothes.

Expected form: **바다에**

Why: Destination and location 에. [[Korean#^ko-Q0195|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%EC%97%AC%EA%B8%B0%20%EC%98%A8%20%EB%92%A4%EB%A1%9C%20%ED%95%9C%20%EB%B2%88%EB%8F%84%20%EB%B0%94%EB%8B%A4%EC%97%90%20%EB%93%A4%EC%96%B4%EA%B0%80%EA%B3%A0%20%EC%8B%B6%EB%8B%A4%EB%8A%94%20%EC%83%9D%EA%B0%81%EC%9D%84%20%EC%95%88%20%ED%96%88%EC%A7%80%EB%A7%8C%20%EC%A7%80%EA%B8%88%20%EC%9D%B4%20%EC%88%9C%EA%B0%84%EC%97%90%20%EC%96%B4%EC%A9%90%20%EC%9D%BC%EC%9D%B8%EC%A7%80%20%EC%98%B7%EC%9D%84%20%EB%B2%97%EC%96%B4%20%EB%B2%84%EB%A6%AC%EA%B3%A0%20%EC%8B%B6%EC%97%88%EC%96%B4%EC%9A%94.)
^ko-Q0195-answer

**ko-Q0196** — 나는 여기 온 뒤로 한 번도 바다에 들어가고 싶다는 생각을 안 했지만 지금 이 순간에 어쩐 일인지 옷을 벗어 버리고 싶었어요.

I had not once thought about going into the sea since I came here, but at this moment, for some reason, I wanted to remove my clothes.

Why: Destination and location 에. [[Korean#^ko-Q0196|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%EC%97%AC%EA%B8%B0%20%EC%98%A8%20%EB%92%A4%EB%A1%9C%20%ED%95%9C%20%EB%B2%88%EB%8F%84%20%EB%B0%94%EB%8B%A4%EC%97%90%20%EB%93%A4%EC%96%B4%EA%B0%80%EA%B3%A0%20%EC%8B%B6%EB%8B%A4%EB%8A%94%20%EC%83%9D%EA%B0%81%EC%9D%84%20%EC%95%88%20%ED%96%88%EC%A7%80%EB%A7%8C%20%EC%A7%80%EA%B8%88%20%EC%9D%B4%20%EC%88%9C%EA%B0%84%EC%97%90%20%EC%96%B4%EC%A9%90%20%EC%9D%BC%EC%9D%B8%EC%A7%80%20%EC%98%B7%EC%9D%84%20%EB%B2%97%EC%96%B4%20%EB%B2%84%EB%A6%AC%EA%B3%A0%20%EC%8B%B6%EC%97%88%EC%96%B4%EC%9A%94.)
^ko-Q0196-answer

**ko-Q0197** — 톰과의 데이트 후에 메리는 하루종일 정신이 산란했어, 수업에서 집중도 못하고 배고픔도 느끼지 못했어.

After her first date with Tom, Mary was distracted all day, couldn't concentrate on her classes and didn't feel hungry.

Why: Destination and location 에. [[Korean#^ko-Q0197|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EA%B3%BC%EC%9D%98%20%EB%8D%B0%EC%9D%B4%ED%8A%B8%20%ED%9B%84%EC%97%90%20%EB%A9%94%EB%A6%AC%EB%8A%94%20%ED%95%98%EB%A3%A8%EC%A2%85%EC%9D%BC%20%EC%A0%95%EC%8B%A0%EC%9D%B4%20%EC%82%B0%EB%9E%80%ED%96%88%EC%96%B4%2C%20%EC%88%98%EC%97%85%EC%97%90%EC%84%9C%20%EC%A7%91%EC%A4%91%EB%8F%84%20%EB%AA%BB%ED%95%98%EA%B3%A0%20%EB%B0%B0%EA%B3%A0%ED%94%94%EB%8F%84%20%EB%8A%90%EB%81%BC%EC%A7%80%20%EB%AA%BB%ED%96%88%EC%96%B4.)
^ko-Q0197-answer

**ko-Q0198** — 톰과의 데이트 후에 메리는 하루종일 정신이 산란했어, 수업에서 집중도 못하고 배고픔도 느끼지 못했어.

After her first date with Tom, Mary was distracted all day, couldn't concentrate on her classes and didn't feel hungry.

에 marks many destinations, times and locations with existence predicates. Event location often uses 에서 instead. The predicate determines the appropriate relation.

Why: Destination and location 에. [[Korean#^ko-Q0198|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EA%B3%BC%EC%9D%98%20%EB%8D%B0%EC%9D%B4%ED%8A%B8%20%ED%9B%84%EC%97%90%20%EB%A9%94%EB%A6%AC%EB%8A%94%20%ED%95%98%EB%A3%A8%EC%A2%85%EC%9D%BC%20%EC%A0%95%EC%8B%A0%EC%9D%B4%20%EC%82%B0%EB%9E%80%ED%96%88%EC%96%B4%2C%20%EC%88%98%EC%97%85%EC%97%90%EC%84%9C%20%EC%A7%91%EC%A4%91%EB%8F%84%20%EB%AA%BB%ED%95%98%EA%B3%A0%20%EB%B0%B0%EA%B3%A0%ED%94%94%EB%8F%84%20%EB%8A%90%EB%81%BC%EC%A7%80%20%EB%AA%BB%ED%96%88%EC%96%B4.)
^ko-Q0198-answer

**ko-Q0199** — 톰은 문제에 대해 솔직했다.

Tom was honest about the problem.

Expected form: **문제에**

Why: Destination and location 에. [[Korean#^ko-Q0199|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EB%AC%B8%EC%A0%9C%EC%97%90%20%EB%8C%80%ED%95%B4%20%EC%86%94%EC%A7%81%ED%96%88%EB%8B%A4.)
^ko-Q0199-answer

**ko-Q0200** — 톰은 문제에 대해 솔직했다.

Tom was honest about the problem.

Expected form: **문제에**

Why: Destination and location 에. [[Korean#^ko-Q0200|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EB%AC%B8%EC%A0%9C%EC%97%90%20%EB%8C%80%ED%95%B4%20%EC%86%94%EC%A7%81%ED%96%88%EB%8B%A4.)
^ko-Q0200-answer


### Answers 201–250

**ko-Q0201** — 외국에서 살면서 좀 불편한 건 없었어?

Don't you feel any inconvenience living abroad?

Expected form: **외국에서**

Why: Event location and source 에서. [[Korean#^ko-Q0201|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%99%B8%EA%B5%AD%EC%97%90%EC%84%9C%20%EC%82%B4%EB%A9%B4%EC%84%9C%20%EC%A2%80%20%EB%B6%88%ED%8E%B8%ED%95%9C%20%EA%B1%B4%20%EC%97%86%EC%97%88%EC%96%B4%3F)
^ko-Q0201-answer

**ko-Q0202** — 외국에서 살면서 좀 불편한 건 없었어?

Don't you feel any inconvenience living abroad?

Why: Event location and source 에서. [[Korean#^ko-Q0202|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%99%B8%EA%B5%AD%EC%97%90%EC%84%9C%20%EC%82%B4%EB%A9%B4%EC%84%9C%20%EC%A2%80%20%EB%B6%88%ED%8E%B8%ED%95%9C%20%EA%B1%B4%20%EC%97%86%EC%97%88%EC%96%B4%3F)
^ko-Q0202-answer

**ko-Q0203** — 톰과 메리는 스마트 홈에서 거주하고 있어요.

Tom and Mary live in a smart home.

Why: Event location and source 에서. [[Korean#^ko-Q0203|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EA%B3%BC%20%EB%A9%94%EB%A6%AC%EB%8A%94%20%EC%8A%A4%EB%A7%88%ED%8A%B8%20%ED%99%88%EC%97%90%EC%84%9C%20%EA%B1%B0%EC%A3%BC%ED%95%98%EA%B3%A0%20%EC%9E%88%EC%96%B4%EC%9A%94.)
^ko-Q0203-answer

**ko-Q0204** — 톰과 메리는 스마트 홈에서 거주하고 있어요.

Tom and Mary live in a smart home.

에서 often marks where an action happens or where movement originates. It contrasts with location 에 for many state/existence predicates.

Why: Event location and source 에서. [[Korean#^ko-Q0204|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EA%B3%BC%20%EB%A9%94%EB%A6%AC%EB%8A%94%20%EC%8A%A4%EB%A7%88%ED%8A%B8%20%ED%99%88%EC%97%90%EC%84%9C%20%EA%B1%B0%EC%A3%BC%ED%95%98%EA%B3%A0%20%EC%9E%88%EC%96%B4%EC%9A%94.)
^ko-Q0204-answer

**ko-Q0205** — 나는 이것이 어디에서 왔는지 모른다.

I don't know where this came from.

Expected form: **어디에서**

Why: Event location and source 에서. [[Korean#^ko-Q0205|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%EC%9D%B4%EA%B2%83%EC%9D%B4%20%EC%96%B4%EB%94%94%EC%97%90%EC%84%9C%20%EC%99%94%EB%8A%94%EC%A7%80%20%EB%AA%A8%EB%A5%B8%EB%8B%A4.)
^ko-Q0205-answer

**ko-Q0206** — 나는 이것이 어디에서 왔는지 모른다.

I don't know where this came from.

Expected form: **어디에서**

Why: Event location and source 에서. [[Korean#^ko-Q0206|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%EC%9D%B4%EA%B2%83%EC%9D%B4%20%EC%96%B4%EB%94%94%EC%97%90%EC%84%9C%20%EC%99%94%EB%8A%94%EC%A7%80%20%EB%AA%A8%EB%A5%B8%EB%8B%A4.)
^ko-Q0206-answer

**ko-Q0207** — 오늘밤 무대에서 쓸 기타좀 빌려줄래?

Would you lend me your guitar to use tonight on stage?

Expected form: **무대에서**

Why: Event location and source 에서. [[Korean#^ko-Q0207|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%98%A4%EB%8A%98%EB%B0%A4%20%EB%AC%B4%EB%8C%80%EC%97%90%EC%84%9C%20%EC%93%B8%20%EA%B8%B0%ED%83%80%EC%A2%80%20%EB%B9%8C%EB%A0%A4%EC%A4%84%EB%9E%98%3F)
^ko-Q0207-answer

**ko-Q0208** — 오늘밤 무대에서 쓸 기타좀 빌려줄래?

Would you lend me your guitar to use tonight on stage?

Why: Event location and source 에서. [[Korean#^ko-Q0208|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%98%A4%EB%8A%98%EB%B0%A4%20%EB%AC%B4%EB%8C%80%EC%97%90%EC%84%9C%20%EC%93%B8%20%EA%B8%B0%ED%83%80%EC%A2%80%20%EB%B9%8C%EB%A0%A4%EC%A4%84%EB%9E%98%3F)
^ko-Q0208-answer

**ko-Q0209** — 로비에서 기다려 주세요.

Wait for us in the lobby.

Why: Event location and source 에서. [[Korean#^ko-Q0209|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%A1%9C%EB%B9%84%EC%97%90%EC%84%9C%20%EA%B8%B0%EB%8B%A4%EB%A0%A4%20%EC%A3%BC%EC%84%B8%EC%9A%94.)
^ko-Q0209-answer

**ko-Q0210** — 로비에서 기다려 주세요.

Wait for us in the lobby.

에서 often marks where an action happens or where movement originates. It contrasts with location 에 for many state/existence predicates.

Why: Event location and source 에서. [[Korean#^ko-Q0210|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%A1%9C%EB%B9%84%EC%97%90%EC%84%9C%20%EA%B8%B0%EB%8B%A4%EB%A0%A4%20%EC%A3%BC%EC%84%B8%EC%9A%94.)
^ko-Q0210-answer

**ko-Q0211** — 제가 문학을 공부하는 사람이기 때문에, 영화를 볼 때에 예슬적인 측면에서 보게 됩니다.

Because I study literature, I tend to see films from an artistic perspective.

Expected form: **측면에서**

Why: Event location and source 에서. [[Korean#^ko-Q0211|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A0%9C%EA%B0%80%20%EB%AC%B8%ED%95%99%EC%9D%84%20%EA%B3%B5%EB%B6%80%ED%95%98%EB%8A%94%20%EC%82%AC%EB%9E%8C%EC%9D%B4%EA%B8%B0%20%EB%95%8C%EB%AC%B8%EC%97%90%2C%20%EC%98%81%ED%99%94%EB%A5%BC%20%EB%B3%BC%20%EB%95%8C%EC%97%90%20%EC%98%88%EC%8A%AC%EC%A0%81%EC%9D%B8%20%EC%B8%A1%EB%A9%B4%EC%97%90%EC%84%9C%20%EB%B3%B4%EA%B2%8C%20%EB%90%A9%EB%8B%88%EB%8B%A4.)
^ko-Q0211-answer

**ko-Q0212** — 제가 문학을 공부하는 사람이기 때문에, 영화를 볼 때에 예슬적인 측면에서 보게 됩니다.

Because I study literature, I tend to see films from an artistic perspective.

Expected form: **측면에서**

Why: Event location and source 에서. [[Korean#^ko-Q0212|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A0%9C%EA%B0%80%20%EB%AC%B8%ED%95%99%EC%9D%84%20%EA%B3%B5%EB%B6%80%ED%95%98%EB%8A%94%20%EC%82%AC%EB%9E%8C%EC%9D%B4%EA%B8%B0%20%EB%95%8C%EB%AC%B8%EC%97%90%2C%20%EC%98%81%ED%99%94%EB%A5%BC%20%EB%B3%BC%20%EB%95%8C%EC%97%90%20%EC%98%88%EC%8A%AC%EC%A0%81%EC%9D%B8%20%EC%B8%A1%EB%A9%B4%EC%97%90%EC%84%9C%20%EB%B3%B4%EA%B2%8C%20%EB%90%A9%EB%8B%88%EB%8B%A4.)
^ko-Q0212-answer

**ko-Q0213** — 집에서 TV나 볼 거예요.

I'll watch TV at home or something.

Expected form: **집에서**

Why: Event location and source 에서. [[Korean#^ko-Q0213|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A7%91%EC%97%90%EC%84%9C%20TV%EB%82%98%20%EB%B3%BC%20%EA%B1%B0%EC%98%88%EC%9A%94.)
^ko-Q0213-answer

**ko-Q0214** — 집에서 TV나 볼 거예요.

I'll watch TV at home or something.

Why: Event location and source 에서. [[Korean#^ko-Q0214|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A7%91%EC%97%90%EC%84%9C%20TV%EB%82%98%20%EB%B3%BC%20%EA%B1%B0%EC%98%88%EC%9A%94.)
^ko-Q0214-answer

**ko-Q0215** — 우리들은 노래방에서 소주를 마셨어요.

We drank soju at the karaoke bar.

Why: Event location and source 에서. [[Korean#^ko-Q0215|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9A%B0%EB%A6%AC%EB%93%A4%EC%9D%80%20%EB%85%B8%EB%9E%98%EB%B0%A9%EC%97%90%EC%84%9C%20%EC%86%8C%EC%A3%BC%EB%A5%BC%20%EB%A7%88%EC%85%A8%EC%96%B4%EC%9A%94.)
^ko-Q0215-answer

**ko-Q0216** — 우리들은 노래방에서 소주를 마셨어요.

We drank soju at the karaoke bar.

에서 often marks where an action happens or where movement originates. It contrasts with location 에 for many state/existence predicates.

Why: Event location and source 에서. [[Korean#^ko-Q0216|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9A%B0%EB%A6%AC%EB%93%A4%EC%9D%80%20%EB%85%B8%EB%9E%98%EB%B0%A9%EC%97%90%EC%84%9C%20%EC%86%8C%EC%A3%BC%EB%A5%BC%20%EB%A7%88%EC%85%A8%EC%96%B4%EC%9A%94.)
^ko-Q0216-answer

**ko-Q0217** — 에볼라는 체액을 통하여 사람에서 사람으로 전파된다.

Ebola spreads from person to person through bodily fluids.

Expected form: **사람에서**

Why: Event location and source 에서. [[Korean#^ko-Q0217|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%97%90%EB%B3%BC%EB%9D%BC%EB%8A%94%20%EC%B2%B4%EC%95%A1%EC%9D%84%20%ED%86%B5%ED%95%98%EC%97%AC%20%EC%82%AC%EB%9E%8C%EC%97%90%EC%84%9C%20%EC%82%AC%EB%9E%8C%EC%9C%BC%EB%A1%9C%20%EC%A0%84%ED%8C%8C%EB%90%9C%EB%8B%A4.)
^ko-Q0217-answer

**ko-Q0218** — 에볼라는 체액을 통하여 사람에서 사람으로 전파된다.

Ebola spreads from person to person through bodily fluids.

Expected form: **사람에서**

Why: Event location and source 에서. [[Korean#^ko-Q0218|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%97%90%EB%B3%BC%EB%9D%BC%EB%8A%94%20%EC%B2%B4%EC%95%A1%EC%9D%84%20%ED%86%B5%ED%95%98%EC%97%AC%20%EC%82%AC%EB%9E%8C%EC%97%90%EC%84%9C%20%EC%82%AC%EB%9E%8C%EC%9C%BC%EB%A1%9C%20%EC%A0%84%ED%8C%8C%EB%90%9C%EB%8B%A4.)
^ko-Q0218-answer

**ko-Q0219** — 그 건물은 앞에서 보면 커 보이지만 옆에서 보면 그렇지 않다.

This building looks large from the front, but not from the side.

Expected form: **앞에서**

Why: Event location and source 에서. [[Korean#^ko-Q0219|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%20%EA%B1%B4%EB%AC%BC%EC%9D%80%20%EC%95%9E%EC%97%90%EC%84%9C%20%EB%B3%B4%EB%A9%B4%20%EC%BB%A4%20%EB%B3%B4%EC%9D%B4%EC%A7%80%EB%A7%8C%20%EC%98%86%EC%97%90%EC%84%9C%20%EB%B3%B4%EB%A9%B4%20%EA%B7%B8%EB%A0%87%EC%A7%80%20%EC%95%8A%EB%8B%A4.)
^ko-Q0219-answer

**ko-Q0220** — 그 건물은 앞에서 보면 커 보이지만 옆에서 보면 그렇지 않다.

This building looks large from the front, but not from the side.

Why: Event location and source 에서. [[Korean#^ko-Q0220|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%20%EA%B1%B4%EB%AC%BC%EC%9D%80%20%EC%95%9E%EC%97%90%EC%84%9C%20%EB%B3%B4%EB%A9%B4%20%EC%BB%A4%20%EB%B3%B4%EC%9D%B4%EC%A7%80%EB%A7%8C%20%EC%98%86%EC%97%90%EC%84%9C%20%EB%B3%B4%EB%A9%B4%20%EA%B7%B8%EB%A0%87%EC%A7%80%20%EC%95%8A%EB%8B%A4.)
^ko-Q0220-answer

**ko-Q0221** — 나는 집에서 뛰쳐나갔다.

I rushed out of my house.

Why: Event location and source 에서. [[Korean#^ko-Q0221|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%EC%A7%91%EC%97%90%EC%84%9C%20%EB%9B%B0%EC%B3%90%EB%82%98%EA%B0%94%EB%8B%A4.)
^ko-Q0221-answer

**ko-Q0222** — 나는 집에서 뛰쳐나갔다.

I rushed out of my house.

에서 often marks where an action happens or where movement originates. It contrasts with location 에 for many state/existence predicates.

Why: Event location and source 에서. [[Korean#^ko-Q0222|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%EC%A7%91%EC%97%90%EC%84%9C%20%EB%9B%B0%EC%B3%90%EB%82%98%EA%B0%94%EB%8B%A4.)
^ko-Q0222-answer

**ko-Q0223** — 이 수업에서 저희는 여러분들 발음이 좀 더 원어민처럼 들릴 수 있도록 돕는데 시간을 보내겠습니다.

In this course, we'll spend time helping you sound more like a native speaker.

Expected form: **수업에서**

Why: Event location and source 에서. [[Korean#^ko-Q0223|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9D%B4%20%EC%88%98%EC%97%85%EC%97%90%EC%84%9C%20%EC%A0%80%ED%9D%AC%EB%8A%94%20%EC%97%AC%EB%9F%AC%EB%B6%84%EB%93%A4%20%EB%B0%9C%EC%9D%8C%EC%9D%B4%20%EC%A2%80%20%EB%8D%94%20%EC%9B%90%EC%96%B4%EB%AF%BC%EC%B2%98%EB%9F%BC%20%EB%93%A4%EB%A6%B4%20%EC%88%98%20%EC%9E%88%EB%8F%84%EB%A1%9D%20%EB%8F%95%EB%8A%94%EB%8D%B0%20%EC%8B%9C%EA%B0%84%EC%9D%84%20%EB%B3%B4%EB%82%B4%EA%B2%A0%EC%8A%B5%EB%8B%88%EB%8B%A4.)
^ko-Q0223-answer

**ko-Q0224** — 이 수업에서 저희는 여러분들 발음이 좀 더 원어민처럼 들릴 수 있도록 돕는데 시간을 보내겠습니다.

In this course, we'll spend time helping you sound more like a native speaker.

Expected form: **수업에서**

Why: Event location and source 에서. [[Korean#^ko-Q0224|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9D%B4%20%EC%88%98%EC%97%85%EC%97%90%EC%84%9C%20%EC%A0%80%ED%9D%AC%EB%8A%94%20%EC%97%AC%EB%9F%AC%EB%B6%84%EB%93%A4%20%EB%B0%9C%EC%9D%8C%EC%9D%B4%20%EC%A2%80%20%EB%8D%94%20%EC%9B%90%EC%96%B4%EB%AF%BC%EC%B2%98%EB%9F%BC%20%EB%93%A4%EB%A6%B4%20%EC%88%98%20%EC%9E%88%EB%8F%84%EB%A1%9D%20%EB%8F%95%EB%8A%94%EB%8D%B0%20%EC%8B%9C%EA%B0%84%EC%9D%84%20%EB%B3%B4%EB%82%B4%EA%B2%A0%EC%8A%B5%EB%8B%88%EB%8B%A4.)
^ko-Q0224-answer

**ko-Q0225** — 그 영화가 좋다고 하는 이유는, 예슬적인 측면에서 내용뿐만 아니라, 음악도 좋기 때문이에요.

The reason I'm saying this movie is good is that, not only is the artistic content good, the music is too.

Expected form: **측면에서**

Why: Event location and source 에서. [[Korean#^ko-Q0225|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%20%EC%98%81%ED%99%94%EA%B0%80%20%EC%A2%8B%EB%8B%A4%EA%B3%A0%20%ED%95%98%EB%8A%94%20%EC%9D%B4%EC%9C%A0%EB%8A%94%2C%20%EC%98%88%EC%8A%AC%EC%A0%81%EC%9D%B8%20%EC%B8%A1%EB%A9%B4%EC%97%90%EC%84%9C%20%EB%82%B4%EC%9A%A9%EB%BF%90%EB%A7%8C%20%EC%95%84%EB%8B%88%EB%9D%BC%2C%20%EC%9D%8C%EC%95%85%EB%8F%84%20%EC%A2%8B%EA%B8%B0%20%EB%95%8C%EB%AC%B8%EC%9D%B4%EC%97%90%EC%9A%94.)
^ko-Q0225-answer

**ko-Q0226** — 그 영화가 좋다고 하는 이유는, 예슬적인 측면에서 내용뿐만 아니라, 음악도 좋기 때문이에요.

The reason I'm saying this movie is good is that, not only is the artistic content good, the music is too.

Why: Event location and source 에서. [[Korean#^ko-Q0226|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%20%EC%98%81%ED%99%94%EA%B0%80%20%EC%A2%8B%EB%8B%A4%EA%B3%A0%20%ED%95%98%EB%8A%94%20%EC%9D%B4%EC%9C%A0%EB%8A%94%2C%20%EC%98%88%EC%8A%AC%EC%A0%81%EC%9D%B8%20%EC%B8%A1%EB%A9%B4%EC%97%90%EC%84%9C%20%EB%82%B4%EC%9A%A9%EB%BF%90%EB%A7%8C%20%EC%95%84%EB%8B%88%EB%9D%BC%2C%20%EC%9D%8C%EC%95%85%EB%8F%84%20%EC%A2%8B%EA%B8%B0%20%EB%95%8C%EB%AC%B8%EC%9D%B4%EC%97%90%EC%9A%94.)
^ko-Q0226-answer

**ko-Q0227** — 내가 모로코에서 만난 프랑스 친구가 나에게 빠리의 공기(분위기)가 프랑스의 전부를 나타내는 것이 아니며, 다른 도시들과 시골이 아주 아름답다고 말했다.

I found a French friend in Morocco. She told me that the atmosphere in Paris is not that of the rest of France, and that other cities and provinces are very beautiful.

Why: Event location and source 에서. [[Korean#^ko-Q0227|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%B4%EA%B0%80%20%EB%AA%A8%EB%A1%9C%EC%BD%94%EC%97%90%EC%84%9C%20%EB%A7%8C%EB%82%9C%20%ED%94%84%EB%9E%91%EC%8A%A4%20%EC%B9%9C%EA%B5%AC%EA%B0%80%20%EB%82%98%EC%97%90%EA%B2%8C%20%EB%B9%A0%EB%A6%AC%EC%9D%98%20%EA%B3%B5%EA%B8%B0%28%EB%B6%84%EC%9C%84%EA%B8%B0%29%EA%B0%80%20%ED%94%84%EB%9E%91%EC%8A%A4%EC%9D%98%20%EC%A0%84%EB%B6%80%EB%A5%BC%20%EB%82%98%ED%83%80%EB%82%B4%EB%8A%94%20%EA%B2%83%EC%9D%B4%20%EC%95%84%EB%8B%88%EB%A9%B0%2C%20%EB%8B%A4%EB%A5%B8%20%EB%8F%84%EC%8B%9C%EB%93%A4%EA%B3%BC%20%EC%8B%9C%EA%B3%A8%EC%9D%B4%20%EC%95%84%EC%A3%BC%20%EC%95%84%EB%A6%84%EB%8B%B5%EB%8B%A4%EA%B3%A0%20%EB%A7%90%ED%96%88%EB%8B%A4.)
^ko-Q0227-answer

**ko-Q0228** — 내가 모로코에서 만난 프랑스 친구가 나에게 빠리의 공기(분위기)가 프랑스의 전부를 나타내는 것이 아니며, 다른 도시들과 시골이 아주 아름답다고 말했다.

I found a French friend in Morocco. She told me that the atmosphere in Paris is not that of the rest of France, and that other cities and provinces are very beautiful.

에서 often marks where an action happens or where movement originates. It contrasts with location 에 for many state/existence predicates.

Why: Event location and source 에서. [[Korean#^ko-Q0228|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%B4%EA%B0%80%20%EB%AA%A8%EB%A1%9C%EC%BD%94%EC%97%90%EC%84%9C%20%EB%A7%8C%EB%82%9C%20%ED%94%84%EB%9E%91%EC%8A%A4%20%EC%B9%9C%EA%B5%AC%EA%B0%80%20%EB%82%98%EC%97%90%EA%B2%8C%20%EB%B9%A0%EB%A6%AC%EC%9D%98%20%EA%B3%B5%EA%B8%B0%28%EB%B6%84%EC%9C%84%EA%B8%B0%29%EA%B0%80%20%ED%94%84%EB%9E%91%EC%8A%A4%EC%9D%98%20%EC%A0%84%EB%B6%80%EB%A5%BC%20%EB%82%98%ED%83%80%EB%82%B4%EB%8A%94%20%EA%B2%83%EC%9D%B4%20%EC%95%84%EB%8B%88%EB%A9%B0%2C%20%EB%8B%A4%EB%A5%B8%20%EB%8F%84%EC%8B%9C%EB%93%A4%EA%B3%BC%20%EC%8B%9C%EA%B3%A8%EC%9D%B4%20%EC%95%84%EC%A3%BC%20%EC%95%84%EB%A6%84%EB%8B%B5%EB%8B%A4%EA%B3%A0%20%EB%A7%90%ED%96%88%EB%8B%A4.)
^ko-Q0228-answer

**ko-Q0229** — 나는 톰의 집에서 통화한다.

I called from Tom's house.

Expected form: **집에서**

Why: Event location and source 에서. [[Korean#^ko-Q0229|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%ED%86%B0%EC%9D%98%20%EC%A7%91%EC%97%90%EC%84%9C%20%ED%86%B5%ED%99%94%ED%95%9C%EB%8B%A4.)
^ko-Q0229-answer

**ko-Q0230** — 나는 톰의 집에서 통화한다.

I called from Tom's house.

Expected form: **집에서**

Why: Event location and source 에서. [[Korean#^ko-Q0230|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%ED%86%B0%EC%9D%98%20%EC%A7%91%EC%97%90%EC%84%9C%20%ED%86%B5%ED%99%94%ED%95%9C%EB%8B%A4.)
^ko-Q0230-answer

**ko-Q0231** — 나는 동물원에서 일해.

I work at a zoo.

Expected form: **동물원에서**

Why: Event location and source 에서. [[Korean#^ko-Q0231|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%EB%8F%99%EB%AC%BC%EC%9B%90%EC%97%90%EC%84%9C%20%EC%9D%BC%ED%95%B4.)
^ko-Q0231-answer

**ko-Q0232** — 나는 동물원에서 일해.

I work at a zoo.

Why: Event location and source 에서. [[Korean#^ko-Q0232|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%EB%8F%99%EB%AC%BC%EC%9B%90%EC%97%90%EC%84%9C%20%EC%9D%BC%ED%95%B4.)
^ko-Q0232-answer

**ko-Q0233** — 그녀는 항상 반에서 꼴찌입니다.

She is always at the bottom of the class.

Why: Event location and source 에서. [[Korean#^ko-Q0233|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EB%85%80%EB%8A%94%20%ED%95%AD%EC%83%81%20%EB%B0%98%EC%97%90%EC%84%9C%20%EA%BC%B4%EC%B0%8C%EC%9E%85%EB%8B%88%EB%8B%A4.)
^ko-Q0233-answer

**ko-Q0234** — 그녀는 항상 반에서 꼴찌입니다.

She is always at the bottom of the class.

에서 often marks where an action happens or where movement originates. It contrasts with location 에 for many state/existence predicates.

Why: Event location and source 에서. [[Korean#^ko-Q0234|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EB%85%80%EB%8A%94%20%ED%95%AD%EC%83%81%20%EB%B0%98%EC%97%90%EC%84%9C%20%EA%BC%B4%EC%B0%8C%EC%9E%85%EB%8B%88%EB%8B%A4.)
^ko-Q0234-answer

**ko-Q0235** — 톰은 침대에서 기절했다.

Tom is passed out in bed.

Expected form: **침대에서**

Why: Event location and source 에서. [[Korean#^ko-Q0235|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EC%B9%A8%EB%8C%80%EC%97%90%EC%84%9C%20%EA%B8%B0%EC%A0%88%ED%96%88%EB%8B%A4.)
^ko-Q0235-answer

**ko-Q0236** — 톰은 침대에서 기절했다.

Tom is passed out in bed.

Expected form: **침대에서**

Why: Event location and source 에서. [[Korean#^ko-Q0236|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EC%B9%A8%EB%8C%80%EC%97%90%EC%84%9C%20%EA%B8%B0%EC%A0%88%ED%96%88%EB%8B%A4.)
^ko-Q0236-answer

**ko-Q0237** — 인간은 아프리카에서 기원했다.

Humans originated in Africa.

Expected form: **아프리카에서**

Why: Event location and source 에서. [[Korean#^ko-Q0237|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9D%B8%EA%B0%84%EC%9D%80%20%EC%95%84%ED%94%84%EB%A6%AC%EC%B9%B4%EC%97%90%EC%84%9C%20%EA%B8%B0%EC%9B%90%ED%96%88%EB%8B%A4.)
^ko-Q0237-answer

**ko-Q0238** — 인간은 아프리카에서 기원했다.

Humans originated in Africa.

Why: Event location and source 에서. [[Korean#^ko-Q0238|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9D%B8%EA%B0%84%EC%9D%80%20%EC%95%84%ED%94%84%EB%A6%AC%EC%B9%B4%EC%97%90%EC%84%9C%20%EA%B8%B0%EC%9B%90%ED%96%88%EB%8B%A4.)
^ko-Q0238-answer

**ko-Q0239** — 톰은 점점 많은 시간을 보스턴에서 보내고 있어.

Tom is spending more and more time in Boston.

Why: Event location and source 에서. [[Korean#^ko-Q0239|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EC%A0%90%EC%A0%90%20%EB%A7%8E%EC%9D%80%20%EC%8B%9C%EA%B0%84%EC%9D%84%20%EB%B3%B4%EC%8A%A4%ED%84%B4%EC%97%90%EC%84%9C%20%EB%B3%B4%EB%82%B4%EA%B3%A0%20%EC%9E%88%EC%96%B4.)
^ko-Q0239-answer

**ko-Q0240** — 톰은 점점 많은 시간을 보스턴에서 보내고 있어.

Tom is spending more and more time in Boston.

에서 often marks where an action happens or where movement originates. It contrasts with location 에 for many state/existence predicates.

Why: Event location and source 에서. [[Korean#^ko-Q0240|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EC%A0%90%EC%A0%90%20%EB%A7%8E%EC%9D%80%20%EC%8B%9C%EA%B0%84%EC%9D%84%20%EB%B3%B4%EC%8A%A4%ED%84%B4%EC%97%90%EC%84%9C%20%EB%B3%B4%EB%82%B4%EA%B3%A0%20%EC%9E%88%EC%96%B4.)
^ko-Q0240-answer

**ko-Q0241** — 아이들은 바닷가에서 모래로 성을 쌓고 있다.

Kids are building sand castles on the beach.

Expected form: **바닷가에서**

Why: Event location and source 에서. [[Korean#^ko-Q0241|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%95%84%EC%9D%B4%EB%93%A4%EC%9D%80%20%EB%B0%94%EB%8B%B7%EA%B0%80%EC%97%90%EC%84%9C%20%EB%AA%A8%EB%9E%98%EB%A1%9C%20%EC%84%B1%EC%9D%84%20%EC%8C%93%EA%B3%A0%20%EC%9E%88%EB%8B%A4.)
^ko-Q0241-answer

**ko-Q0242** — 아이들은 바닷가에서 모래로 성을 쌓고 있다.

Kids are building sand castles on the beach.

Expected form: **바닷가에서**

Why: Event location and source 에서. [[Korean#^ko-Q0242|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%95%84%EC%9D%B4%EB%93%A4%EC%9D%80%20%EB%B0%94%EB%8B%B7%EA%B0%80%EC%97%90%EC%84%9C%20%EB%AA%A8%EB%9E%98%EB%A1%9C%20%EC%84%B1%EC%9D%84%20%EC%8C%93%EA%B3%A0%20%EC%9E%88%EB%8B%A4.)
^ko-Q0242-answer

**ko-Q0243** — 톰은 남은 인생을 감옥에서 보내고 싶어하지 않아.

Tom doesn't want to spend the rest of his life in prison.

Expected form: **감옥에서**

Why: Event location and source 에서. [[Korean#^ko-Q0243|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EB%82%A8%EC%9D%80%20%EC%9D%B8%EC%83%9D%EC%9D%84%20%EA%B0%90%EC%98%A5%EC%97%90%EC%84%9C%20%EB%B3%B4%EB%82%B4%EA%B3%A0%20%EC%8B%B6%EC%96%B4%ED%95%98%EC%A7%80%20%EC%95%8A%EC%95%84.)
^ko-Q0243-answer

**ko-Q0244** — 톰은 남은 인생을 감옥에서 보내고 싶어하지 않아.

Tom doesn't want to spend the rest of his life in prison.

Why: Event location and source 에서. [[Korean#^ko-Q0244|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EB%82%A8%EC%9D%80%20%EC%9D%B8%EC%83%9D%EC%9D%84%20%EA%B0%90%EC%98%A5%EC%97%90%EC%84%9C%20%EB%B3%B4%EB%82%B4%EA%B3%A0%20%EC%8B%B6%EC%96%B4%ED%95%98%EC%A7%80%20%EC%95%8A%EC%95%84.)
^ko-Q0244-answer

**ko-Q0245** — 난 톰을 밖에서 봤어.

I met Tom outside.

Why: Event location and source 에서. [[Korean#^ko-Q0245|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%9C%20%ED%86%B0%EC%9D%84%20%EB%B0%96%EC%97%90%EC%84%9C%20%EB%B4%A4%EC%96%B4.)
^ko-Q0245-answer

**ko-Q0246** — 난 톰을 밖에서 봤어.

I met Tom outside.

에서 often marks where an action happens or where movement originates. It contrasts with location 에 for many state/existence predicates.

Why: Event location and source 에서. [[Korean#^ko-Q0246|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%9C%20%ED%86%B0%EC%9D%84%20%EB%B0%96%EC%97%90%EC%84%9C%20%EB%B4%A4%EC%96%B4.)
^ko-Q0246-answer

**ko-Q0247** — "룩"이란 단어는 산스크리트어에서 유래했고, "마차"란 뜻이야.

The word "rook" comes from Sanskrit and means "chariot".

Expected form: **산스크리트어에서**

Why: Event location and source 에서. [[Korean#^ko-Q0247|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%22%EB%A3%A9%22%EC%9D%B4%EB%9E%80%20%EB%8B%A8%EC%96%B4%EB%8A%94%20%EC%82%B0%EC%8A%A4%ED%81%AC%EB%A6%AC%ED%8A%B8%EC%96%B4%EC%97%90%EC%84%9C%20%EC%9C%A0%EB%9E%98%ED%96%88%EA%B3%A0%2C%20%22%EB%A7%88%EC%B0%A8%22%EB%9E%80%20%EB%9C%BB%EC%9D%B4%EC%95%BC.)
^ko-Q0247-answer

**ko-Q0248** — "룩"이란 단어는 산스크리트어에서 유래했고, "마차"란 뜻이야.

The word "rook" comes from Sanskrit and means "chariot".

Expected form: **산스크리트어에서**

Why: Event location and source 에서. [[Korean#^ko-Q0248|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%22%EB%A3%A9%22%EC%9D%B4%EB%9E%80%20%EB%8B%A8%EC%96%B4%EB%8A%94%20%EC%82%B0%EC%8A%A4%ED%81%AC%EB%A6%AC%ED%8A%B8%EC%96%B4%EC%97%90%EC%84%9C%20%EC%9C%A0%EB%9E%98%ED%96%88%EA%B3%A0%2C%20%22%EB%A7%88%EC%B0%A8%22%EB%9E%80%20%EB%9C%BB%EC%9D%B4%EC%95%BC.)
^ko-Q0248-answer

**ko-Q0249** — 나에게는 나의 4자녀가 언젠가는 그들의 피부색이 아닌 그들의 인격으로 평가받는 나라에서 살게 될 것이라는 꿈이 있다.

I have a dream that my four little children will one day live in a nation where they will not be judged by the color of their skin, but by the content of their character.

Expected form: **나라에서**

Why: Event location and source 에서. [[Korean#^ko-Q0249|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EC%97%90%EA%B2%8C%EB%8A%94%20%EB%82%98%EC%9D%98%204%EC%9E%90%EB%85%80%EA%B0%80%20%EC%96%B8%EC%A0%A0%EA%B0%80%EB%8A%94%20%EA%B7%B8%EB%93%A4%EC%9D%98%20%ED%94%BC%EB%B6%80%EC%83%89%EC%9D%B4%20%EC%95%84%EB%8B%8C%20%EA%B7%B8%EB%93%A4%EC%9D%98%20%EC%9D%B8%EA%B2%A9%EC%9C%BC%EB%A1%9C%20%ED%8F%89%EA%B0%80%EB%B0%9B%EB%8A%94%20%EB%82%98%EB%9D%BC%EC%97%90%EC%84%9C%20%EC%82%B4%EA%B2%8C%20%EB%90%A0%20%EA%B2%83%EC%9D%B4%EB%9D%BC%EB%8A%94%20%EA%BF%88%EC%9D%B4%20%EC%9E%88%EB%8B%A4.)
^ko-Q0249-answer

**ko-Q0250** — 나에게는 나의 4자녀가 언젠가는 그들의 피부색이 아닌 그들의 인격으로 평가받는 나라에서 살게 될 것이라는 꿈이 있다.

I have a dream that my four little children will one day live in a nation where they will not be judged by the color of their skin, but by the content of their character.

Why: Event location and source 에서. [[Korean#^ko-Q0250|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EC%97%90%EA%B2%8C%EB%8A%94%20%EB%82%98%EC%9D%98%204%EC%9E%90%EB%85%80%EA%B0%80%20%EC%96%B8%EC%A0%A0%EA%B0%80%EB%8A%94%20%EA%B7%B8%EB%93%A4%EC%9D%98%20%ED%94%BC%EB%B6%80%EC%83%89%EC%9D%B4%20%EC%95%84%EB%8B%8C%20%EA%B7%B8%EB%93%A4%EC%9D%98%20%EC%9D%B8%EA%B2%A9%EC%9C%BC%EB%A1%9C%20%ED%8F%89%EA%B0%80%EB%B0%9B%EB%8A%94%20%EB%82%98%EB%9D%BC%EC%97%90%EC%84%9C%20%EC%82%B4%EA%B2%8C%20%EB%90%A0%20%EA%B2%83%EC%9D%B4%EB%9D%BC%EB%8A%94%20%EA%BF%88%EC%9D%B4%20%EC%9E%88%EB%8B%A4.)
^ko-Q0250-answer


### Answers 251–300

**ko-Q0251** — 그녀는 고급 진과 토닉 한 잔은 여름과도 같다고 했다, 그리고 그것은 나에게 진실함을 느끼게 해주었다.

She said that a good gin and tonic is like summertime in a glass, and it struck me as being too true.

Why: Recipient markers. [[Korean#^ko-Q0251|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EB%85%80%EB%8A%94%20%EA%B3%A0%EA%B8%89%20%EC%A7%84%EA%B3%BC%20%ED%86%A0%EB%8B%89%20%ED%95%9C%20%EC%9E%94%EC%9D%80%20%EC%97%AC%EB%A6%84%EA%B3%BC%EB%8F%84%20%EA%B0%99%EB%8B%A4%EA%B3%A0%20%ED%96%88%EB%8B%A4%2C%20%EA%B7%B8%EB%A6%AC%EA%B3%A0%20%EA%B7%B8%EA%B2%83%EC%9D%80%20%EB%82%98%EC%97%90%EA%B2%8C%20%EC%A7%84%EC%8B%A4%ED%95%A8%EC%9D%84%20%EB%8A%90%EB%81%BC%EA%B2%8C%20%ED%95%B4%EC%A3%BC%EC%97%88%EB%8B%A4.)
^ko-Q0251-answer

**ko-Q0252** — 그녀는 고급 진과 토닉 한 잔은 여름과도 같다고 했다, 그리고 그것은 나에게 진실함을 느끼게 해주었다.

She said that a good gin and tonic is like summertime in a glass, and it struck me as being too true.

에게/한테 mark many animate recipients; 께 is honorific. Register and the person’s status influence the choice. Inanimate destinations often take another marker.

Why: Recipient markers. [[Korean#^ko-Q0252|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EB%85%80%EB%8A%94%20%EA%B3%A0%EA%B8%89%20%EC%A7%84%EA%B3%BC%20%ED%86%A0%EB%8B%89%20%ED%95%9C%20%EC%9E%94%EC%9D%80%20%EC%97%AC%EB%A6%84%EA%B3%BC%EB%8F%84%20%EA%B0%99%EB%8B%A4%EA%B3%A0%20%ED%96%88%EB%8B%A4%2C%20%EA%B7%B8%EB%A6%AC%EA%B3%A0%20%EA%B7%B8%EA%B2%83%EC%9D%80%20%EB%82%98%EC%97%90%EA%B2%8C%20%EC%A7%84%EC%8B%A4%ED%95%A8%EC%9D%84%20%EB%8A%90%EB%81%BC%EA%B2%8C%20%ED%95%B4%EC%A3%BC%EC%97%88%EB%8B%A4.)
^ko-Q0252-answer

**ko-Q0253** — 난 톰한테 답장했어.

I texted Tom back.

Expected form: **톰한테**

Why: Recipient markers. [[Korean#^ko-Q0253|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%9C%20%ED%86%B0%ED%95%9C%ED%85%8C%20%EB%8B%B5%EC%9E%A5%ED%96%88%EC%96%B4.)
^ko-Q0253-answer

**ko-Q0254** — 난 톰한테 답장했어.

I texted Tom back.

Expected form: **톰한테**

Why: Recipient markers. [[Korean#^ko-Q0254|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%9C%20%ED%86%B0%ED%95%9C%ED%85%8C%20%EB%8B%B5%EC%9E%A5%ED%96%88%EC%96%B4.)
^ko-Q0254-answer

**ko-Q0255** — 내가 이 것을 톰에게 줄거야.

I'll give this to Tom.

Expected form: **톰에게**

Why: Recipient markers. [[Korean#^ko-Q0255|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%B4%EA%B0%80%20%EC%9D%B4%20%EA%B2%83%EC%9D%84%20%ED%86%B0%EC%97%90%EA%B2%8C%20%EC%A4%84%EA%B1%B0%EC%95%BC.)
^ko-Q0255-answer

**ko-Q0256** — 내가 이 것을 톰에게 줄거야.

I'll give this to Tom.

Why: Recipient markers. [[Korean#^ko-Q0256|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%B4%EA%B0%80%20%EC%9D%B4%20%EA%B2%83%EC%9D%84%20%ED%86%B0%EC%97%90%EA%B2%8C%20%EC%A4%84%EA%B1%B0%EC%95%BC.)
^ko-Q0256-answer

**ko-Q0257** — 그녀에게 기대하면 돼요.

We can count on her.

Why: Recipient markers. [[Korean#^ko-Q0257|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EB%85%80%EC%97%90%EA%B2%8C%20%EA%B8%B0%EB%8C%80%ED%95%98%EB%A9%B4%20%EB%8F%BC%EC%9A%94.)
^ko-Q0257-answer

**ko-Q0258** — 그녀에게 기대하면 돼요.

We can count on her.

에게/한테 mark many animate recipients; 께 is honorific. Register and the person’s status influence the choice. Inanimate destinations often take another marker.

Why: Recipient markers. [[Korean#^ko-Q0258|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EB%85%80%EC%97%90%EA%B2%8C%20%EA%B8%B0%EB%8C%80%ED%95%98%EB%A9%B4%20%EB%8F%BC%EC%9A%94.)
^ko-Q0258-answer

**ko-Q0259** — 톰은 친구들에게 고기를 먹은 적이 한 번도 없다고 했다.

Tom told his friends that he never ate meat.

Expected form: **친구들에게**

Why: Recipient markers. [[Korean#^ko-Q0259|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EC%B9%9C%EA%B5%AC%EB%93%A4%EC%97%90%EA%B2%8C%20%EA%B3%A0%EA%B8%B0%EB%A5%BC%20%EB%A8%B9%EC%9D%80%20%EC%A0%81%EC%9D%B4%20%ED%95%9C%20%EB%B2%88%EB%8F%84%20%EC%97%86%EB%8B%A4%EA%B3%A0%20%ED%96%88%EB%8B%A4.)
^ko-Q0259-answer

**ko-Q0260** — 톰은 친구들에게 고기를 먹은 적이 한 번도 없다고 했다.

Tom told his friends that he never ate meat.

Expected form: **친구들에게**

Why: Recipient markers. [[Korean#^ko-Q0260|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EC%B9%9C%EA%B5%AC%EB%93%A4%EC%97%90%EA%B2%8C%20%EA%B3%A0%EA%B8%B0%EB%A5%BC%20%EB%A8%B9%EC%9D%80%20%EC%A0%81%EC%9D%B4%20%ED%95%9C%20%EB%B2%88%EB%8F%84%20%EC%97%86%EB%8B%A4%EA%B3%A0%20%ED%96%88%EB%8B%A4.)
^ko-Q0260-answer

**ko-Q0261** — 저에게 해당되는 할인 티켓은 없나요?

Are there any discount tickets for me?

Expected form: **저에게**

Why: Recipient markers. [[Korean#^ko-Q0261|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A0%80%EC%97%90%EA%B2%8C%20%ED%95%B4%EB%8B%B9%EB%90%98%EB%8A%94%20%ED%95%A0%EC%9D%B8%20%ED%8B%B0%EC%BC%93%EC%9D%80%20%EC%97%86%EB%82%98%EC%9A%94%3F)
^ko-Q0261-answer

**ko-Q0262** — 저에게 해당되는 할인 티켓은 없나요?

Are there any discount tickets for me?

Why: Recipient markers. [[Korean#^ko-Q0262|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A0%80%EC%97%90%EA%B2%8C%20%ED%95%B4%EB%8B%B9%EB%90%98%EB%8A%94%20%ED%95%A0%EC%9D%B8%20%ED%8B%B0%EC%BC%93%EC%9D%80%20%EC%97%86%EB%82%98%EC%9A%94%3F)
^ko-Q0262-answer

**ko-Q0263** — 그에게 말하지 않는게 좋을걸.

You'd better not tell him.

Why: Recipient markers. [[Korean#^ko-Q0263|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EC%97%90%EA%B2%8C%20%EB%A7%90%ED%95%98%EC%A7%80%20%EC%95%8A%EB%8A%94%EA%B2%8C%20%EC%A2%8B%EC%9D%84%EA%B1%B8.)
^ko-Q0263-answer

**ko-Q0264** — 그에게 말하지 않는게 좋을걸.

You'd better not tell him.

에게/한테 mark many animate recipients; 께 is honorific. Register and the person’s status influence the choice. Inanimate destinations often take another marker.

Why: Recipient markers. [[Korean#^ko-Q0264|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EC%97%90%EA%B2%8C%20%EB%A7%90%ED%95%98%EC%A7%80%20%EC%95%8A%EB%8A%94%EA%B2%8C%20%EC%A2%8B%EC%9D%84%EA%B1%B8.)
^ko-Q0264-answer

**ko-Q0265** — 그는 나에게 그 책은 재미있다고 했어요.

He told me that the book was interesting.

Expected form: **나에게**

Why: Recipient markers. [[Korean#^ko-Q0265|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EB%8A%94%20%EB%82%98%EC%97%90%EA%B2%8C%20%EA%B7%B8%20%EC%B1%85%EC%9D%80%20%EC%9E%AC%EB%AF%B8%EC%9E%88%EB%8B%A4%EA%B3%A0%20%ED%96%88%EC%96%B4%EC%9A%94.)
^ko-Q0265-answer

**ko-Q0266** — 그는 나에게 그 책은 재미있다고 했어요.

He told me that the book was interesting.

Expected form: **나에게**

Why: Recipient markers. [[Korean#^ko-Q0266|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EB%8A%94%20%EB%82%98%EC%97%90%EA%B2%8C%20%EA%B7%B8%20%EC%B1%85%EC%9D%80%20%EC%9E%AC%EB%AF%B8%EC%9E%88%EB%8B%A4%EA%B3%A0%20%ED%96%88%EC%96%B4%EC%9A%94.)
^ko-Q0266-answer

**ko-Q0267** — 답장을 아직도 못 받아서 혹시 내 우편물이 너한테 배달되지 않은 건지 궁금했다.

Since I haven't received an answer, I was wondering if maybe my mail never got delivered to you.

Expected form: **너한테**

Why: Recipient markers. [[Korean#^ko-Q0267|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%8B%B5%EC%9E%A5%EC%9D%84%20%EC%95%84%EC%A7%81%EB%8F%84%20%EB%AA%BB%20%EB%B0%9B%EC%95%84%EC%84%9C%20%ED%98%B9%EC%8B%9C%20%EB%82%B4%20%EC%9A%B0%ED%8E%B8%EB%AC%BC%EC%9D%B4%20%EB%84%88%ED%95%9C%ED%85%8C%20%EB%B0%B0%EB%8B%AC%EB%90%98%EC%A7%80%20%EC%95%8A%EC%9D%80%20%EA%B1%B4%EC%A7%80%20%EA%B6%81%EA%B8%88%ED%96%88%EB%8B%A4.)
^ko-Q0267-answer

**ko-Q0268** — 답장을 아직도 못 받아서 혹시 내 우편물이 너한테 배달되지 않은 건지 궁금했다.

Since I haven't received an answer, I was wondering if maybe my mail never got delivered to you.

Why: Recipient markers. [[Korean#^ko-Q0268|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%8B%B5%EC%9E%A5%EC%9D%84%20%EC%95%84%EC%A7%81%EB%8F%84%20%EB%AA%BB%20%EB%B0%9B%EC%95%84%EC%84%9C%20%ED%98%B9%EC%8B%9C%20%EB%82%B4%20%EC%9A%B0%ED%8E%B8%EB%AC%BC%EC%9D%B4%20%EB%84%88%ED%95%9C%ED%85%8C%20%EB%B0%B0%EB%8B%AC%EB%90%98%EC%A7%80%20%EC%95%8A%EC%9D%80%20%EA%B1%B4%EC%A7%80%20%EA%B6%81%EA%B8%88%ED%96%88%EB%8B%A4.)
^ko-Q0268-answer

**ko-Q0269** — 여기 음식이 나한테 좀 많이 매운 것 같아.

I find the food here to be a little too spicy for me.

Why: Recipient markers. [[Korean#^ko-Q0269|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%97%AC%EA%B8%B0%20%EC%9D%8C%EC%8B%9D%EC%9D%B4%20%EB%82%98%ED%95%9C%ED%85%8C%20%EC%A2%80%20%EB%A7%8E%EC%9D%B4%20%EB%A7%A4%EC%9A%B4%20%EA%B2%83%20%EA%B0%99%EC%95%84.)
^ko-Q0269-answer

**ko-Q0270** — 여기 음식이 나한테 좀 많이 매운 것 같아.

I find the food here to be a little too spicy for me.

에게/한테 mark many animate recipients; 께 is honorific. Register and the person’s status influence the choice. Inanimate destinations often take another marker.

Why: Recipient markers. [[Korean#^ko-Q0270|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%97%AC%EA%B8%B0%20%EC%9D%8C%EC%8B%9D%EC%9D%B4%20%EB%82%98%ED%95%9C%ED%85%8C%20%EC%A2%80%20%EB%A7%8E%EC%9D%B4%20%EB%A7%A4%EC%9A%B4%20%EA%B2%83%20%EA%B0%99%EC%95%84.)
^ko-Q0270-answer

**ko-Q0271** — 톰은 자기 아이들에게 벌을 줬다.

Tom punished his children.

Expected form: **아이들에게**

Why: Recipient markers. [[Korean#^ko-Q0271|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EC%9E%90%EA%B8%B0%20%EC%95%84%EC%9D%B4%EB%93%A4%EC%97%90%EA%B2%8C%20%EB%B2%8C%EC%9D%84%20%EC%A4%AC%EB%8B%A4.)
^ko-Q0271-answer

**ko-Q0272** — 톰은 자기 아이들에게 벌을 줬다.

Tom punished his children.

Expected form: **아이들에게**

Why: Recipient markers. [[Korean#^ko-Q0272|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EC%9E%90%EA%B8%B0%20%EC%95%84%EC%9D%B4%EB%93%A4%EC%97%90%EA%B2%8C%20%EB%B2%8C%EC%9D%84%20%EC%A4%AC%EB%8B%A4.)
^ko-Q0272-answer

**ko-Q0273** — 톰에게 더는 하지 말라고 부탁했다.

I asked Tom not to do that anymore.

Expected form: **톰에게**

Why: Recipient markers. [[Korean#^ko-Q0273|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%97%90%EA%B2%8C%20%EB%8D%94%EB%8A%94%20%ED%95%98%EC%A7%80%20%EB%A7%90%EB%9D%BC%EA%B3%A0%20%EB%B6%80%ED%83%81%ED%96%88%EB%8B%A4.)
^ko-Q0273-answer

**ko-Q0274** — 톰에게 더는 하지 말라고 부탁했다.

I asked Tom not to do that anymore.

Why: Recipient markers. [[Korean#^ko-Q0274|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%97%90%EA%B2%8C%20%EB%8D%94%EB%8A%94%20%ED%95%98%EC%A7%80%20%EB%A7%90%EB%9D%BC%EA%B3%A0%20%EB%B6%80%ED%83%81%ED%96%88%EB%8B%A4.)
^ko-Q0274-answer

**ko-Q0275** — 난 톰한테 거짓말 하라고 말했어.

I told Tom to lie.

Why: Recipient markers. [[Korean#^ko-Q0275|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%9C%20%ED%86%B0%ED%95%9C%ED%85%8C%20%EA%B1%B0%EC%A7%93%EB%A7%90%20%ED%95%98%EB%9D%BC%EA%B3%A0%20%EB%A7%90%ED%96%88%EC%96%B4.)
^ko-Q0275-answer

**ko-Q0276** — 난 톰한테 거짓말 하라고 말했어.

I told Tom to lie.

에게/한테 mark many animate recipients; 께 is honorific. Register and the person’s status influence the choice. Inanimate destinations often take another marker.

Why: Recipient markers. [[Korean#^ko-Q0276|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%9C%20%ED%86%B0%ED%95%9C%ED%85%8C%20%EA%B1%B0%EC%A7%93%EB%A7%90%20%ED%95%98%EB%9D%BC%EA%B3%A0%20%EB%A7%90%ED%96%88%EC%96%B4.)
^ko-Q0276-answer

**ko-Q0277** — 이 뉴스는 우리에게 중요하다.

This news is important to us.

Expected form: **우리에게**

Why: Recipient markers. [[Korean#^ko-Q0277|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9D%B4%20%EB%89%B4%EC%8A%A4%EB%8A%94%20%EC%9A%B0%EB%A6%AC%EC%97%90%EA%B2%8C%20%EC%A4%91%EC%9A%94%ED%95%98%EB%8B%A4.)
^ko-Q0277-answer

**ko-Q0278** — 이 뉴스는 우리에게 중요하다.

This news is important to us.

Expected form: **우리에게**

Why: Recipient markers. [[Korean#^ko-Q0278|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9D%B4%20%EB%89%B4%EC%8A%A4%EB%8A%94%20%EC%9A%B0%EB%A6%AC%EC%97%90%EA%B2%8C%20%EC%A4%91%EC%9A%94%ED%95%98%EB%8B%A4.)
^ko-Q0278-answer

**ko-Q0279** — 톰은 메리에게 베개를 던져서 정확히 얼굴을 맞았다.

Tom threw a pillow at Mary and the pillow hit her squarely in the face.

Expected form: **메리에게**

Why: Recipient markers. [[Korean#^ko-Q0279|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EB%A9%94%EB%A6%AC%EC%97%90%EA%B2%8C%20%EB%B2%A0%EA%B0%9C%EB%A5%BC%20%EB%8D%98%EC%A0%B8%EC%84%9C%20%EC%A0%95%ED%99%95%ED%9E%88%20%EC%96%BC%EA%B5%B4%EC%9D%84%20%EB%A7%9E%EC%95%98%EB%8B%A4.)
^ko-Q0279-answer

**ko-Q0280** — 톰은 메리에게 베개를 던져서 정확히 얼굴을 맞았다.

Tom threw a pillow at Mary and the pillow hit her squarely in the face.

Why: Recipient markers. [[Korean#^ko-Q0280|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EB%A9%94%EB%A6%AC%EC%97%90%EA%B2%8C%20%EB%B2%A0%EA%B0%9C%EB%A5%BC%20%EB%8D%98%EC%A0%B8%EC%84%9C%20%EC%A0%95%ED%99%95%ED%9E%88%20%EC%96%BC%EA%B5%B4%EC%9D%84%20%EB%A7%9E%EC%95%98%EB%8B%A4.)
^ko-Q0280-answer

**ko-Q0281** — 월급날까지 나한테 돈 좀 빌려줄 수 있어?

Could you loan me some money until payday?

Why: Recipient markers. [[Korean#^ko-Q0281|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9B%94%EA%B8%89%EB%82%A0%EA%B9%8C%EC%A7%80%20%EB%82%98%ED%95%9C%ED%85%8C%20%EB%8F%88%20%EC%A2%80%20%EB%B9%8C%EB%A0%A4%EC%A4%84%20%EC%88%98%20%EC%9E%88%EC%96%B4%3F)
^ko-Q0281-answer

**ko-Q0282** — 월급날까지 나한테 돈 좀 빌려줄 수 있어?

Could you loan me some money until payday?

에게/한테 mark many animate recipients; 께 is honorific. Register and the person’s status influence the choice. Inanimate destinations often take another marker.

Why: Recipient markers. [[Korean#^ko-Q0282|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9B%94%EA%B8%89%EB%82%A0%EA%B9%8C%EC%A7%80%20%EB%82%98%ED%95%9C%ED%85%8C%20%EB%8F%88%20%EC%A2%80%20%EB%B9%8C%EB%A0%A4%EC%A4%84%20%EC%88%98%20%EC%9E%88%EC%96%B4%3F)
^ko-Q0282-answer

**ko-Q0283** — 저한테 하실 말씀이 있으신가요?

Is there something that you wish to tell me?

Expected form: **저한테**

Why: Recipient markers. [[Korean#^ko-Q0283|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A0%80%ED%95%9C%ED%85%8C%20%ED%95%98%EC%8B%A4%20%EB%A7%90%EC%94%80%EC%9D%B4%20%EC%9E%88%EC%9C%BC%EC%8B%A0%EA%B0%80%EC%9A%94%3F)
^ko-Q0283-answer

**ko-Q0284** — 저한테 하실 말씀이 있으신가요?

Is there something that you wish to tell me?

Expected form: **저한테**

Why: Recipient markers. [[Korean#^ko-Q0284|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A0%80%ED%95%9C%ED%85%8C%20%ED%95%98%EC%8B%A4%20%EB%A7%90%EC%94%80%EC%9D%B4%20%EC%9E%88%EC%9C%BC%EC%8B%A0%EA%B0%80%EC%9A%94%3F)
^ko-Q0284-answer

**ko-Q0285** — 그는 그녀에게 음식에 대한 불평을 했다.

He complained to her about the food.

Expected form: **그녀에게**

Why: Recipient markers. [[Korean#^ko-Q0285|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EB%8A%94%20%EA%B7%B8%EB%85%80%EC%97%90%EA%B2%8C%20%EC%9D%8C%EC%8B%9D%EC%97%90%20%EB%8C%80%ED%95%9C%20%EB%B6%88%ED%8F%89%EC%9D%84%20%ED%96%88%EB%8B%A4.)
^ko-Q0285-answer

**ko-Q0286** — 그는 그녀에게 음식에 대한 불평을 했다.

He complained to her about the food.

Why: Recipient markers. [[Korean#^ko-Q0286|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EB%8A%94%20%EA%B7%B8%EB%85%80%EC%97%90%EA%B2%8C%20%EC%9D%8C%EC%8B%9D%EC%97%90%20%EB%8C%80%ED%95%9C%20%EB%B6%88%ED%8F%89%EC%9D%84%20%ED%96%88%EB%8B%A4.)
^ko-Q0286-answer

**ko-Q0287** — 나는 톰에게 경고해야 해.

I need to warn Tom.

Why: Recipient markers. [[Korean#^ko-Q0287|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%ED%86%B0%EC%97%90%EA%B2%8C%20%EA%B2%BD%EA%B3%A0%ED%95%B4%EC%95%BC%20%ED%95%B4.)
^ko-Q0287-answer

**ko-Q0288** — 나는 톰에게 경고해야 해.

I need to warn Tom.

에게/한테 mark many animate recipients; 께 is honorific. Register and the person’s status influence the choice. Inanimate destinations often take another marker.

Why: Recipient markers. [[Korean#^ko-Q0288|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%ED%86%B0%EC%97%90%EA%B2%8C%20%EA%B2%BD%EA%B3%A0%ED%95%B4%EC%95%BC%20%ED%95%B4.)
^ko-Q0288-answer

**ko-Q0289** — 네가 어제 톰에게 말했지?

You talked to Tom yesterday, didn't you?

Expected form: **톰에게**

Why: Recipient markers. [[Korean#^ko-Q0289|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%84%A4%EA%B0%80%20%EC%96%B4%EC%A0%9C%20%ED%86%B0%EC%97%90%EA%B2%8C%20%EB%A7%90%ED%96%88%EC%A7%80%3F)
^ko-Q0289-answer

**ko-Q0290** — 네가 어제 톰에게 말했지?

You talked to Tom yesterday, didn't you?

Expected form: **톰에게**

Why: Recipient markers. [[Korean#^ko-Q0290|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%84%A4%EA%B0%80%20%EC%96%B4%EC%A0%9C%20%ED%86%B0%EC%97%90%EA%B2%8C%20%EB%A7%90%ED%96%88%EC%A7%80%3F)
^ko-Q0290-answer

**ko-Q0291** — 양치기로 사는 건 나에게 맞지 않는 일이다.

I was not made for the life of a shepherd.

Expected form: **나에게**

Why: Recipient markers. [[Korean#^ko-Q0291|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%96%91%EC%B9%98%EA%B8%B0%EB%A1%9C%20%EC%82%AC%EB%8A%94%20%EA%B1%B4%20%EB%82%98%EC%97%90%EA%B2%8C%20%EB%A7%9E%EC%A7%80%20%EC%95%8A%EB%8A%94%20%EC%9D%BC%EC%9D%B4%EB%8B%A4.)
^ko-Q0291-answer

**ko-Q0292** — 양치기로 사는 건 나에게 맞지 않는 일이다.

I was not made for the life of a shepherd.

Why: Recipient markers. [[Korean#^ko-Q0292|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%96%91%EC%B9%98%EA%B8%B0%EB%A1%9C%20%EC%82%AC%EB%8A%94%20%EA%B1%B4%20%EB%82%98%EC%97%90%EA%B2%8C%20%EB%A7%9E%EC%A7%80%20%EC%95%8A%EB%8A%94%20%EC%9D%BC%EC%9D%B4%EB%8B%A4.)
^ko-Q0292-answer

**ko-Q0293** — 너에게 전화를 걸고 싶었는데, 너가 안 받을까봐 결국 전화 못했어.

I wanted to phone you, but I thought you wouldn't get it so I didn't phone you in the end.

Why: Recipient markers. [[Korean#^ko-Q0293|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%84%88%EC%97%90%EA%B2%8C%20%EC%A0%84%ED%99%94%EB%A5%BC%20%EA%B1%B8%EA%B3%A0%20%EC%8B%B6%EC%97%88%EB%8A%94%EB%8D%B0%2C%20%EB%84%88%EA%B0%80%20%EC%95%88%20%EB%B0%9B%EC%9D%84%EA%B9%8C%EB%B4%90%20%EA%B2%B0%EA%B5%AD%20%EC%A0%84%ED%99%94%20%EB%AA%BB%ED%96%88%EC%96%B4.)
^ko-Q0293-answer

**ko-Q0294** — 너에게 전화를 걸고 싶었는데, 너가 안 받을까봐 결국 전화 못했어.

I wanted to phone you, but I thought you wouldn't get it so I didn't phone you in the end.

에게/한테 mark many animate recipients; 께 is honorific. Register and the person’s status influence the choice. Inanimate destinations often take another marker.

Why: Recipient markers. [[Korean#^ko-Q0294|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%84%88%EC%97%90%EA%B2%8C%20%EC%A0%84%ED%99%94%EB%A5%BC%20%EA%B1%B8%EA%B3%A0%20%EC%8B%B6%EC%97%88%EB%8A%94%EB%8D%B0%2C%20%EB%84%88%EA%B0%80%20%EC%95%88%20%EB%B0%9B%EC%9D%84%EA%B9%8C%EB%B4%90%20%EA%B2%B0%EA%B5%AD%20%EC%A0%84%ED%99%94%20%EB%AA%BB%ED%96%88%EC%96%B4.)
^ko-Q0294-answer

**ko-Q0295** — 뭐든 잘 이해안되는게 생기면 나한테 와.

If anything comes up that you don't understand, come to me.

Expected form: **나한테**

Why: Recipient markers. [[Korean#^ko-Q0295|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%AD%90%EB%93%A0%20%EC%9E%98%20%EC%9D%B4%ED%95%B4%EC%95%88%EB%90%98%EB%8A%94%EA%B2%8C%20%EC%83%9D%EA%B8%B0%EB%A9%B4%20%EB%82%98%ED%95%9C%ED%85%8C%20%EC%99%80.)
^ko-Q0295-answer

**ko-Q0296** — 뭐든 잘 이해안되는게 생기면 나한테 와.

If anything comes up that you don't understand, come to me.

Expected form: **나한테**

Why: Recipient markers. [[Korean#^ko-Q0296|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%AD%90%EB%93%A0%20%EC%9E%98%20%EC%9D%B4%ED%95%B4%EC%95%88%EB%90%98%EB%8A%94%EA%B2%8C%20%EC%83%9D%EA%B8%B0%EB%A9%B4%20%EB%82%98%ED%95%9C%ED%85%8C%20%EC%99%80.)
^ko-Q0296-answer

**ko-Q0297** — 그 사람은 우리한테 그런 얘기는 안 했어.

She didn't tell us about that.

Expected form: **우리한테**

Why: Recipient markers. [[Korean#^ko-Q0297|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%20%EC%82%AC%EB%9E%8C%EC%9D%80%20%EC%9A%B0%EB%A6%AC%ED%95%9C%ED%85%8C%20%EA%B7%B8%EB%9F%B0%20%EC%96%98%EA%B8%B0%EB%8A%94%20%EC%95%88%20%ED%96%88%EC%96%B4.)
^ko-Q0297-answer

**ko-Q0298** — 그 사람은 우리한테 그런 얘기는 안 했어.

She didn't tell us about that.

Why: Recipient markers. [[Korean#^ko-Q0298|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%20%EC%82%AC%EB%9E%8C%EC%9D%80%20%EC%9A%B0%EB%A6%AC%ED%95%9C%ED%85%8C%20%EA%B7%B8%EB%9F%B0%20%EC%96%98%EA%B8%B0%EB%8A%94%20%EC%95%88%20%ED%96%88%EC%96%B4.)
^ko-Q0298-answer

**ko-Q0299** — 그에게 여자친구가 있다는 것은 아주 가능성이 높아요.

There is a good chance of him having a girlfriend.

Why: Recipient markers. [[Korean#^ko-Q0299|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EC%97%90%EA%B2%8C%20%EC%97%AC%EC%9E%90%EC%B9%9C%EA%B5%AC%EA%B0%80%20%EC%9E%88%EB%8B%A4%EB%8A%94%20%EA%B2%83%EC%9D%80%20%EC%95%84%EC%A3%BC%20%EA%B0%80%EB%8A%A5%EC%84%B1%EC%9D%B4%20%EB%86%92%EC%95%84%EC%9A%94.)
^ko-Q0299-answer

**ko-Q0300** — 그에게 여자친구가 있다는 것은 아주 가능성이 높아요.

There is a good chance of him having a girlfriend.

에게/한테 mark many animate recipients; 께 is honorific. Register and the person’s status influence the choice. Inanimate destinations often take another marker.

Why: Recipient markers. [[Korean#^ko-Q0300|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EC%97%90%EA%B2%8C%20%EC%97%AC%EC%9E%90%EC%B9%9C%EA%B5%AC%EA%B0%80%20%EC%9E%88%EB%8B%A4%EB%8A%94%20%EA%B2%83%EC%9D%80%20%EC%95%84%EC%A3%BC%20%EA%B0%80%EB%8A%A5%EC%84%B1%EC%9D%B4%20%EB%86%92%EC%95%84%EC%9A%94.)
^ko-Q0300-answer


### Answers 301–350

**ko-Q0301** — 톰은 이 분야의 개척자야.

Tom is a pioneer in this field.

Expected form: **분야의**

Why: Possession 의. [[Korean#^ko-Q0301|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EC%9D%B4%20%EB%B6%84%EC%95%BC%EC%9D%98%20%EA%B0%9C%EC%B2%99%EC%9E%90%EC%95%BC.)
^ko-Q0301-answer

**ko-Q0302** — 톰은 이 분야의 개척자야.

Tom is a pioneer in this field.

Expected form: **분야의**

Why: Possession 의. [[Korean#^ko-Q0302|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EC%9D%B4%20%EB%B6%84%EC%95%BC%EC%9D%98%20%EA%B0%9C%EC%B2%99%EC%9E%90%EC%95%BC.)
^ko-Q0302-answer

**ko-Q0303** — 독서는 더 이상 소수의 전유물이 아니게 되었다.

Reading books ceased to be a privilege of a minority.

Expected form: **소수의**

Why: Possession 의. [[Korean#^ko-Q0303|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%8F%85%EC%84%9C%EB%8A%94%20%EB%8D%94%20%EC%9D%B4%EC%83%81%20%EC%86%8C%EC%88%98%EC%9D%98%20%EC%A0%84%EC%9C%A0%EB%AC%BC%EC%9D%B4%20%EC%95%84%EB%8B%88%EA%B2%8C%20%EB%90%98%EC%97%88%EB%8B%A4.)
^ko-Q0303-answer

**ko-Q0304** — 독서는 더 이상 소수의 전유물이 아니게 되었다.

Reading books ceased to be a privilege of a minority.

Why: Possession 의. [[Korean#^ko-Q0304|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%8F%85%EC%84%9C%EB%8A%94%20%EB%8D%94%20%EC%9D%B4%EC%83%81%20%EC%86%8C%EC%88%98%EC%9D%98%20%EC%A0%84%EC%9C%A0%EB%AC%BC%EC%9D%B4%20%EC%95%84%EB%8B%88%EA%B2%8C%20%EB%90%98%EC%97%88%EB%8B%A4.)
^ko-Q0304-answer

**ko-Q0305** — 어떤 종류의 일을 하세요?

What kind of work do you do?

Why: Possession 의. [[Korean#^ko-Q0305|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%96%B4%EB%96%A4%20%EC%A2%85%EB%A5%98%EC%9D%98%20%EC%9D%BC%EC%9D%84%20%ED%95%98%EC%84%B8%EC%9A%94%3F)
^ko-Q0305-answer

**ko-Q0306** — 어떤 종류의 일을 하세요?

What kind of work do you do?

의 links a possessor or modifier to a following noun. It is often reduced or omitted in familiar phrases. Pronunciation can differ from the spelling in possessive use.

Why: Possession 의. [[Korean#^ko-Q0306|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%96%B4%EB%96%A4%20%EC%A2%85%EB%A5%98%EC%9D%98%20%EC%9D%BC%EC%9D%84%20%ED%95%98%EC%84%B8%EC%9A%94%3F)
^ko-Q0306-answer

**ko-Q0307** — 그게 내가 하고 있는 것의 전부야.

That's all I'm doing.

Expected form: **것의**

Why: Possession 의. [[Korean#^ko-Q0307|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EA%B2%8C%20%EB%82%B4%EA%B0%80%20%ED%95%98%EA%B3%A0%20%EC%9E%88%EB%8A%94%20%EA%B2%83%EC%9D%98%20%EC%A0%84%EB%B6%80%EC%95%BC.)
^ko-Q0307-answer

**ko-Q0308** — 그게 내가 하고 있는 것의 전부야.

That's all I'm doing.

Expected form: **것의**

Why: Possession 의. [[Korean#^ko-Q0308|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EA%B2%8C%20%EB%82%B4%EA%B0%80%20%ED%95%98%EA%B3%A0%20%EC%9E%88%EB%8A%94%20%EA%B2%83%EC%9D%98%20%EC%A0%84%EB%B6%80%EC%95%BC.)
^ko-Q0308-answer

**ko-Q0309** — 서울은 남한의 도시다.

Seoul is the capitаl of South Korea.

Expected form: **남한의**

Why: Possession 의. [[Korean#^ko-Q0309|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%84%9C%EC%9A%B8%EC%9D%80%20%EB%82%A8%ED%95%9C%EC%9D%98%20%EB%8F%84%EC%8B%9C%EB%8B%A4.)
^ko-Q0309-answer

**ko-Q0310** — 서울은 남한의 도시다.

Seoul is the capitаl of South Korea.

Why: Possession 의. [[Korean#^ko-Q0310|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%84%9C%EC%9A%B8%EC%9D%80%20%EB%82%A8%ED%95%9C%EC%9D%98%20%EB%8F%84%EC%8B%9C%EB%8B%A4.)
^ko-Q0310-answer

**ko-Q0311** — 아이티의 수도는 이름이 무엇입니까?

What is the capital of Haiti?

Why: Possession 의. [[Korean#^ko-Q0311|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%95%84%EC%9D%B4%ED%8B%B0%EC%9D%98%20%EC%88%98%EB%8F%84%EB%8A%94%20%EC%9D%B4%EB%A6%84%EC%9D%B4%20%EB%AC%B4%EC%97%87%EC%9E%85%EB%8B%88%EA%B9%8C%3F)
^ko-Q0311-answer

**ko-Q0312** — 아이티의 수도는 이름이 무엇입니까?

What is the capital of Haiti?

의 links a possessor or modifier to a following noun. It is often reduced or omitted in familiar phrases. Pronunciation can differ from the spelling in possessive use.

Why: Possession 의. [[Korean#^ko-Q0312|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%95%84%EC%9D%B4%ED%8B%B0%EC%9D%98%20%EC%88%98%EB%8F%84%EB%8A%94%20%EC%9D%B4%EB%A6%84%EC%9D%B4%20%EB%AC%B4%EC%97%87%EC%9E%85%EB%8B%88%EA%B9%8C%3F)
^ko-Q0312-answer

**ko-Q0313** — 그림은 문맹자의 책이다.

Images are the books of the illiterate.

Expected form: **문맹자의**

Why: Possession 의. [[Korean#^ko-Q0313|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EB%A6%BC%EC%9D%80%20%EB%AC%B8%EB%A7%B9%EC%9E%90%EC%9D%98%20%EC%B1%85%EC%9D%B4%EB%8B%A4.)
^ko-Q0313-answer

**ko-Q0314** — 그림은 문맹자의 책이다.

Images are the books of the illiterate.

Expected form: **문맹자의**

Why: Possession 의. [[Korean#^ko-Q0314|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EB%A6%BC%EC%9D%80%20%EB%AC%B8%EB%A7%B9%EC%9E%90%EC%9D%98%20%EC%B1%85%EC%9D%B4%EB%8B%A4.)
^ko-Q0314-answer

**ko-Q0315** — 정육면체의 부피를 어떻게 계산합니까?

How do you calculate the volume of a cube?

Expected form: **정육면체의**

Why: Possession 의. [[Korean#^ko-Q0315|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A0%95%EC%9C%A1%EB%A9%B4%EC%B2%B4%EC%9D%98%20%EB%B6%80%ED%94%BC%EB%A5%BC%20%EC%96%B4%EB%96%BB%EA%B2%8C%20%EA%B3%84%EC%82%B0%ED%95%A9%EB%8B%88%EA%B9%8C%3F)
^ko-Q0315-answer

**ko-Q0316** — 정육면체의 부피를 어떻게 계산합니까?

How do you calculate the volume of a cube?

Why: Possession 의. [[Korean#^ko-Q0316|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A0%95%EC%9C%A1%EB%A9%B4%EC%B2%B4%EC%9D%98%20%EB%B6%80%ED%94%BC%EB%A5%BC%20%EC%96%B4%EB%96%BB%EA%B2%8C%20%EA%B3%84%EC%82%B0%ED%95%A9%EB%8B%88%EA%B9%8C%3F)
^ko-Q0316-answer

**ko-Q0317** — 이 세상은 미치광이들의 소굴이다

The world is a den of crazies.

Why: Possession 의. [[Korean#^ko-Q0317|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9D%B4%20%EC%84%B8%EC%83%81%EC%9D%80%20%EB%AF%B8%EC%B9%98%EA%B4%91%EC%9D%B4%EB%93%A4%EC%9D%98%20%EC%86%8C%EA%B5%B4%EC%9D%B4%EB%8B%A4)
^ko-Q0317-answer

**ko-Q0318** — 이 세상은 미치광이들의 소굴이다

The world is a den of crazies.

의 links a possessor or modifier to a following noun. It is often reduced or omitted in familiar phrases. Pronunciation can differ from the spelling in possessive use.

Why: Possession 의. [[Korean#^ko-Q0318|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9D%B4%20%EC%84%B8%EC%83%81%EC%9D%80%20%EB%AF%B8%EC%B9%98%EA%B4%91%EC%9D%B4%EB%93%A4%EC%9D%98%20%EC%86%8C%EA%B5%B4%EC%9D%B4%EB%8B%A4)
^ko-Q0318-answer

**ko-Q0319** — 지구상의 인구는 60억 이상이야.

There are more than six billion people in the world.

Expected form: **지구상의**

Why: Possession 의. [[Korean#^ko-Q0319|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A7%80%EA%B5%AC%EC%83%81%EC%9D%98%20%EC%9D%B8%EA%B5%AC%EB%8A%94%2060%EC%96%B5%20%EC%9D%B4%EC%83%81%EC%9D%B4%EC%95%BC.)
^ko-Q0319-answer

**ko-Q0320** — 지구상의 인구는 60억 이상이야.

There are more than six billion people in the world.

Expected form: **지구상의**

Why: Possession 의. [[Korean#^ko-Q0320|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A7%80%EA%B5%AC%EC%83%81%EC%9D%98%20%EC%9D%B8%EA%B5%AC%EB%8A%94%2060%EC%96%B5%20%EC%9D%B4%EC%83%81%EC%9D%B4%EC%95%BC.)
^ko-Q0320-answer

**ko-Q0321** — 나는 로마의 역사에 관한 책을 찾고 있다.

I'm looking for books on Roman history.

Expected form: **로마의**

Why: Possession 의. [[Korean#^ko-Q0321|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%EB%A1%9C%EB%A7%88%EC%9D%98%20%EC%97%AD%EC%82%AC%EC%97%90%20%EA%B4%80%ED%95%9C%20%EC%B1%85%EC%9D%84%20%EC%B0%BE%EA%B3%A0%20%EC%9E%88%EB%8B%A4.)
^ko-Q0321-answer

**ko-Q0322** — 나는 로마의 역사에 관한 책을 찾고 있다.

I'm looking for books on Roman history.

Why: Possession 의. [[Korean#^ko-Q0322|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%EB%A1%9C%EB%A7%88%EC%9D%98%20%EC%97%AD%EC%82%AC%EC%97%90%20%EA%B4%80%ED%95%9C%20%EC%B1%85%EC%9D%84%20%EC%B0%BE%EA%B3%A0%20%EC%9E%88%EB%8B%A4.)
^ko-Q0322-answer

**ko-Q0323** — 아보카도는 아보카도 나무의 열매입니다.

Avocados are the fruit of the avocado tree.

Why: Possession 의. [[Korean#^ko-Q0323|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%95%84%EB%B3%B4%EC%B9%B4%EB%8F%84%EB%8A%94%20%EC%95%84%EB%B3%B4%EC%B9%B4%EB%8F%84%20%EB%82%98%EB%AC%B4%EC%9D%98%20%EC%97%B4%EB%A7%A4%EC%9E%85%EB%8B%88%EB%8B%A4.)
^ko-Q0323-answer

**ko-Q0324** — 아보카도는 아보카도 나무의 열매입니다.

Avocados are the fruit of the avocado tree.

의 links a possessor or modifier to a following noun. It is often reduced or omitted in familiar phrases. Pronunciation can differ from the spelling in possessive use.

Why: Possession 의. [[Korean#^ko-Q0324|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%95%84%EB%B3%B4%EC%B9%B4%EB%8F%84%EB%8A%94%20%EC%95%84%EB%B3%B4%EC%B9%B4%EB%8F%84%20%EB%82%98%EB%AC%B4%EC%9D%98%20%EC%97%B4%EB%A7%A4%EC%9E%85%EB%8B%88%EB%8B%A4.)
^ko-Q0324-answer

**ko-Q0325** — 미국 성인은 약 65퍼센트가 비만이고 그건 그들의 건강에 좋지 않다.

About 65% of American adults are overweight, which isn't good for their health.

Expected form: **그들의**

Why: Possession 의. [[Korean#^ko-Q0325|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%AF%B8%EA%B5%AD%20%EC%84%B1%EC%9D%B8%EC%9D%80%20%EC%95%BD%2065%ED%8D%BC%EC%84%BC%ED%8A%B8%EA%B0%80%20%EB%B9%84%EB%A7%8C%EC%9D%B4%EA%B3%A0%20%EA%B7%B8%EA%B1%B4%20%EA%B7%B8%EB%93%A4%EC%9D%98%20%EA%B1%B4%EA%B0%95%EC%97%90%20%EC%A2%8B%EC%A7%80%20%EC%95%8A%EB%8B%A4.)
^ko-Q0325-answer

**ko-Q0326** — 미국 성인은 약 65퍼센트가 비만이고 그건 그들의 건강에 좋지 않다.

About 65% of American adults are overweight, which isn't good for their health.

Expected form: **그들의**

Why: Possession 의. [[Korean#^ko-Q0326|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%AF%B8%EA%B5%AD%20%EC%84%B1%EC%9D%B8%EC%9D%80%20%EC%95%BD%2065%ED%8D%BC%EC%84%BC%ED%8A%B8%EA%B0%80%20%EB%B9%84%EB%A7%8C%EC%9D%B4%EA%B3%A0%20%EA%B7%B8%EA%B1%B4%20%EA%B7%B8%EB%93%A4%EC%9D%98%20%EA%B1%B4%EA%B0%95%EC%97%90%20%EC%A2%8B%EC%A7%80%20%EC%95%8A%EB%8B%A4.)
^ko-Q0326-answer

**ko-Q0327** — 수잔의 음식 솜씨가 훌륭하다.

Susan is a good cook.

Expected form: **수잔의**

Why: Possession 의. [[Korean#^ko-Q0327|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%88%98%EC%9E%94%EC%9D%98%20%EC%9D%8C%EC%8B%9D%20%EC%86%9C%EC%94%A8%EA%B0%80%20%ED%9B%8C%EB%A5%AD%ED%95%98%EB%8B%A4.)
^ko-Q0327-answer

**ko-Q0328** — 수잔의 음식 솜씨가 훌륭하다.

Susan is a good cook.

Why: Possession 의. [[Korean#^ko-Q0328|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%88%98%EC%9E%94%EC%9D%98%20%EC%9D%8C%EC%8B%9D%20%EC%86%9C%EC%94%A8%EA%B0%80%20%ED%9B%8C%EB%A5%AD%ED%95%98%EB%8B%A4.)
^ko-Q0328-answer

**ko-Q0329** — 음악과 영화의 구조가 조화를 이루고 있어요.

The music is in balance with the structure of the movie.

Why: Possession 의. [[Korean#^ko-Q0329|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9D%8C%EC%95%85%EA%B3%BC%20%EC%98%81%ED%99%94%EC%9D%98%20%EA%B5%AC%EC%A1%B0%EA%B0%80%20%EC%A1%B0%ED%99%94%EB%A5%BC%20%EC%9D%B4%EB%A3%A8%EA%B3%A0%20%EC%9E%88%EC%96%B4%EC%9A%94.)
^ko-Q0329-answer

**ko-Q0330** — 음악과 영화의 구조가 조화를 이루고 있어요.

The music is in balance with the structure of the movie.

의 links a possessor or modifier to a following noun. It is often reduced or omitted in familiar phrases. Pronunciation can differ from the spelling in possessive use.

Why: Possession 의. [[Korean#^ko-Q0330|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9D%8C%EC%95%85%EA%B3%BC%20%EC%98%81%ED%99%94%EC%9D%98%20%EA%B5%AC%EC%A1%B0%EA%B0%80%20%EC%A1%B0%ED%99%94%EB%A5%BC%20%EC%9D%B4%EB%A3%A8%EA%B3%A0%20%EC%9E%88%EC%96%B4%EC%9A%94.)
^ko-Q0330-answer

**ko-Q0331** — 이 건물의 지붕은 초록색이야.

This building has a green roof.

Expected form: **건물의**

Why: Possession 의. [[Korean#^ko-Q0331|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9D%B4%20%EA%B1%B4%EB%AC%BC%EC%9D%98%20%EC%A7%80%EB%B6%95%EC%9D%80%20%EC%B4%88%EB%A1%9D%EC%83%89%EC%9D%B4%EC%95%BC.)
^ko-Q0331-answer

**ko-Q0332** — 이 건물의 지붕은 초록색이야.

This building has a green roof.

Expected form: **건물의**

Why: Possession 의. [[Korean#^ko-Q0332|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9D%B4%20%EA%B1%B4%EB%AC%BC%EC%9D%98%20%EC%A7%80%EB%B6%95%EC%9D%80%20%EC%B4%88%EB%A1%9D%EC%83%89%EC%9D%B4%EC%95%BC.)
^ko-Q0332-answer

**ko-Q0333** — 새미는 두 어린 아이의 아버지이다.

Sami is the father of two young children.

Expected form: **아이의**

Why: Possession 의. [[Korean#^ko-Q0333|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%83%88%EB%AF%B8%EB%8A%94%20%EB%91%90%20%EC%96%B4%EB%A6%B0%20%EC%95%84%EC%9D%B4%EC%9D%98%20%EC%95%84%EB%B2%84%EC%A7%80%EC%9D%B4%EB%8B%A4.)
^ko-Q0333-answer

**ko-Q0334** — 새미는 두 어린 아이의 아버지이다.

Sami is the father of two young children.

Why: Possession 의. [[Korean#^ko-Q0334|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%83%88%EB%AF%B8%EB%8A%94%20%EB%91%90%20%EC%96%B4%EB%A6%B0%20%EC%95%84%EC%9D%B4%EC%9D%98%20%EC%95%84%EB%B2%84%EC%A7%80%EC%9D%B4%EB%8B%A4.)
^ko-Q0334-answer

**ko-Q0335** — 여긴 오늘 꼭 여름의 끝인 느낌이 난다.

Here it really feels today like summer has ended.

Why: Possession 의. [[Korean#^ko-Q0335|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%97%AC%EA%B8%B4%20%EC%98%A4%EB%8A%98%20%EA%BC%AD%20%EC%97%AC%EB%A6%84%EC%9D%98%20%EB%81%9D%EC%9D%B8%20%EB%8A%90%EB%82%8C%EC%9D%B4%20%EB%82%9C%EB%8B%A4.)
^ko-Q0335-answer

**ko-Q0336** — 여긴 오늘 꼭 여름의 끝인 느낌이 난다.

Here it really feels today like summer has ended.

의 links a possessor or modifier to a following noun. It is often reduced or omitted in familiar phrases. Pronunciation can differ from the spelling in possessive use.

Why: Possession 의. [[Korean#^ko-Q0336|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%97%AC%EA%B8%B4%20%EC%98%A4%EB%8A%98%20%EA%BC%AD%20%EC%97%AC%EB%A6%84%EC%9D%98%20%EB%81%9D%EC%9D%B8%20%EB%8A%90%EB%82%8C%EC%9D%B4%20%EB%82%9C%EB%8B%A4.)
^ko-Q0336-answer

**ko-Q0337** — 모든 인간은 태어날 때부터 자유로우며 그 존엄과 권리에 있어 동등하다. 인간은 천부적으로 이성과 양심을 부여받았으며 서로 형제애의 정신으로 행동하여야 한다.

All human beings are born free and equal in dignity and rights. They are endowed with reason and conscience and should act towards one another in a spirit of brotherhood.

Expected form: **형제애의**

Why: Possession 의. [[Korean#^ko-Q0337|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%AA%A8%EB%93%A0%20%EC%9D%B8%EA%B0%84%EC%9D%80%20%ED%83%9C%EC%96%B4%EB%82%A0%20%EB%95%8C%EB%B6%80%ED%84%B0%20%EC%9E%90%EC%9C%A0%EB%A1%9C%EC%9A%B0%EB%A9%B0%20%EA%B7%B8%20%EC%A1%B4%EC%97%84%EA%B3%BC%20%EA%B6%8C%EB%A6%AC%EC%97%90%20%EC%9E%88%EC%96%B4%20%EB%8F%99%EB%93%B1%ED%95%98%EB%8B%A4.%20%EC%9D%B8%EA%B0%84%EC%9D%80%20%EC%B2%9C%EB%B6%80%EC%A0%81%EC%9C%BC%EB%A1%9C%20%EC%9D%B4%EC%84%B1%EA%B3%BC%20%EC%96%91%EC%8B%AC%EC%9D%84%20%EB%B6%80%EC%97%AC%EB%B0%9B%EC%95%98%EC%9C%BC%EB%A9%B0%20%EC%84%9C%EB%A1%9C%20%ED%98%95%EC%A0%9C%EC%95%A0%EC%9D%98%20%EC%A0%95%EC%8B%A0%EC%9C%BC%EB%A1%9C%20%ED%96%89%EB%8F%99%ED%95%98%EC%97%AC%EC%95%BC%20%ED%95%9C%EB%8B%A4.)
^ko-Q0337-answer

**ko-Q0338** — 모든 인간은 태어날 때부터 자유로우며 그 존엄과 권리에 있어 동등하다. 인간은 천부적으로 이성과 양심을 부여받았으며 서로 형제애의 정신으로 행동하여야 한다.

All human beings are born free and equal in dignity and rights. They are endowed with reason and conscience and should act towards one another in a spirit of brotherhood.

Expected form: **형제애의**

Why: Possession 의. [[Korean#^ko-Q0338|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%AA%A8%EB%93%A0%20%EC%9D%B8%EA%B0%84%EC%9D%80%20%ED%83%9C%EC%96%B4%EB%82%A0%20%EB%95%8C%EB%B6%80%ED%84%B0%20%EC%9E%90%EC%9C%A0%EB%A1%9C%EC%9A%B0%EB%A9%B0%20%EA%B7%B8%20%EC%A1%B4%EC%97%84%EA%B3%BC%20%EA%B6%8C%EB%A6%AC%EC%97%90%20%EC%9E%88%EC%96%B4%20%EB%8F%99%EB%93%B1%ED%95%98%EB%8B%A4.%20%EC%9D%B8%EA%B0%84%EC%9D%80%20%EC%B2%9C%EB%B6%80%EC%A0%81%EC%9C%BC%EB%A1%9C%20%EC%9D%B4%EC%84%B1%EA%B3%BC%20%EC%96%91%EC%8B%AC%EC%9D%84%20%EB%B6%80%EC%97%AC%EB%B0%9B%EC%95%98%EC%9C%BC%EB%A9%B0%20%EC%84%9C%EB%A1%9C%20%ED%98%95%EC%A0%9C%EC%95%A0%EC%9D%98%20%EC%A0%95%EC%8B%A0%EC%9C%BC%EB%A1%9C%20%ED%96%89%EB%8F%99%ED%95%98%EC%97%AC%EC%95%BC%20%ED%95%9C%EB%8B%A4.)
^ko-Q0338-answer

**ko-Q0339** — 그는 그의 성공을 그가 열심히 일한것에 대해 공을 돌렸다

He attributes his success to hard work.

Expected form: **그의**

Why: Possession 의. [[Korean#^ko-Q0339|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EB%8A%94%20%EA%B7%B8%EC%9D%98%20%EC%84%B1%EA%B3%B5%EC%9D%84%20%EA%B7%B8%EA%B0%80%20%EC%97%B4%EC%8B%AC%ED%9E%88%20%EC%9D%BC%ED%95%9C%EA%B2%83%EC%97%90%20%EB%8C%80%ED%95%B4%20%EA%B3%B5%EC%9D%84%20%EB%8F%8C%EB%A0%B8%EB%8B%A4)
^ko-Q0339-answer

**ko-Q0340** — 그는 그의 성공을 그가 열심히 일한것에 대해 공을 돌렸다

He attributes his success to hard work.

Why: Possession 의. [[Korean#^ko-Q0340|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EB%8A%94%20%EA%B7%B8%EC%9D%98%20%EC%84%B1%EA%B3%B5%EC%9D%84%20%EA%B7%B8%EA%B0%80%20%EC%97%B4%EC%8B%AC%ED%9E%88%20%EC%9D%BC%ED%95%9C%EA%B2%83%EC%97%90%20%EB%8C%80%ED%95%B4%20%EA%B3%B5%EC%9D%84%20%EB%8F%8C%EB%A0%B8%EB%8B%A4)
^ko-Q0340-answer

**ko-Q0341** — 그게 내 오늘의 목표야.

That's my goal today.

Why: Possession 의. [[Korean#^ko-Q0341|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EA%B2%8C%20%EB%82%B4%20%EC%98%A4%EB%8A%98%EC%9D%98%20%EB%AA%A9%ED%91%9C%EC%95%BC.)
^ko-Q0341-answer

**ko-Q0342** — 그게 내 오늘의 목표야.

That's my goal today.

의 links a possessor or modifier to a following noun. It is often reduced or omitted in familiar phrases. Pronunciation can differ from the spelling in possessive use.

Why: Possession 의. [[Korean#^ko-Q0342|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EA%B2%8C%20%EB%82%B4%20%EC%98%A4%EB%8A%98%EC%9D%98%20%EB%AA%A9%ED%91%9C%EC%95%BC.)
^ko-Q0342-answer

**ko-Q0343** — 톰은 메리의 변화를 눈치챘다.

Tom noticed a change in Mary.

Expected form: **메리의**

Why: Possession 의. [[Korean#^ko-Q0343|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EB%A9%94%EB%A6%AC%EC%9D%98%20%EB%B3%80%ED%99%94%EB%A5%BC%20%EB%88%88%EC%B9%98%EC%B1%98%EB%8B%A4.)
^ko-Q0343-answer

**ko-Q0344** — 톰은 메리의 변화를 눈치챘다.

Tom noticed a change in Mary.

Expected form: **메리의**

Why: Possession 의. [[Korean#^ko-Q0344|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EB%A9%94%EB%A6%AC%EC%9D%98%20%EB%B3%80%ED%99%94%EB%A5%BC%20%EB%88%88%EC%B9%98%EC%B1%98%EB%8B%A4.)
^ko-Q0344-answer

**ko-Q0345** — 당신은 당신의 어머니를 사랑합니까?

Do you love your mother?

Expected form: **당신의**

Why: Possession 의. [[Korean#^ko-Q0345|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%8B%B9%EC%8B%A0%EC%9D%80%20%EB%8B%B9%EC%8B%A0%EC%9D%98%20%EC%96%B4%EB%A8%B8%EB%8B%88%EB%A5%BC%20%EC%82%AC%EB%9E%91%ED%95%A9%EB%8B%88%EA%B9%8C%3F)
^ko-Q0345-answer

**ko-Q0346** — 당신은 당신의 어머니를 사랑합니까?

Do you love your mother?

Why: Possession 의. [[Korean#^ko-Q0346|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%8B%B9%EC%8B%A0%EC%9D%80%20%EB%8B%B9%EC%8B%A0%EC%9D%98%20%EC%96%B4%EB%A8%B8%EB%8B%88%EB%A5%BC%20%EC%82%AC%EB%9E%91%ED%95%A9%EB%8B%88%EA%B9%8C%3F)
^ko-Q0346-answer

**ko-Q0347** — 이건 저의 컴퓨터예요.

This is my computer.

Why: Possession 의. [[Korean#^ko-Q0347|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9D%B4%EA%B1%B4%20%EC%A0%80%EC%9D%98%20%EC%BB%B4%ED%93%A8%ED%84%B0%EC%98%88%EC%9A%94.)
^ko-Q0347-answer

**ko-Q0348** — 이건 저의 컴퓨터예요.

This is my computer.

의 links a possessor or modifier to a following noun. It is often reduced or omitted in familiar phrases. Pronunciation can differ from the spelling in possessive use.

Why: Possession 의. [[Korean#^ko-Q0348|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9D%B4%EA%B1%B4%20%EC%A0%80%EC%9D%98%20%EC%BB%B4%ED%93%A8%ED%84%B0%EC%98%88%EC%9A%94.)
^ko-Q0348-answer

**ko-Q0349** — 난 너의 제안에 전적으로 동의한다.

I'm all for your suggestion.

Expected form: **너의**

Why: Possession 의. [[Korean#^ko-Q0349|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%9C%20%EB%84%88%EC%9D%98%20%EC%A0%9C%EC%95%88%EC%97%90%20%EC%A0%84%EC%A0%81%EC%9C%BC%EB%A1%9C%20%EB%8F%99%EC%9D%98%ED%95%9C%EB%8B%A4.)
^ko-Q0349-answer

**ko-Q0350** — 난 너의 제안에 전적으로 동의한다.

I'm all for your suggestion.

Expected form: **너의**

Why: Possession 의. [[Korean#^ko-Q0350|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%9C%20%EB%84%88%EC%9D%98%20%EC%A0%9C%EC%95%88%EC%97%90%20%EC%A0%84%EC%A0%81%EC%9C%BC%EB%A1%9C%20%EB%8F%99%EC%9D%98%ED%95%9C%EB%8B%A4.)
^ko-Q0350-answer


### Answers 351–400

**ko-Q0351** — 선물은 아직도 포장 상태야.

The gift was still wrapped.

Expected form: **아직도**

Why: Inclusion 도. [[Korean#^ko-Q0351|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%84%A0%EB%AC%BC%EC%9D%80%20%EC%95%84%EC%A7%81%EB%8F%84%20%ED%8F%AC%EC%9E%A5%20%EC%83%81%ED%83%9C%EC%95%BC.)
^ko-Q0351-answer

**ko-Q0352** — 선물은 아직도 포장 상태야.

The gift was still wrapped.

Why: Inclusion 도. [[Korean#^ko-Q0352|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%84%A0%EB%AC%BC%EC%9D%80%20%EC%95%84%EC%A7%81%EB%8F%84%20%ED%8F%AC%EC%9E%A5%20%EC%83%81%ED%83%9C%EC%95%BC.)
^ko-Q0352-answer

**ko-Q0353** — 그녀는 누구보다도 아름다워요.

She is more beautiful than any other girl.

Why: Inclusion 도. [[Korean#^ko-Q0353|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EB%85%80%EB%8A%94%20%EB%88%84%EA%B5%AC%EB%B3%B4%EB%8B%A4%EB%8F%84%20%EC%95%84%EB%A6%84%EB%8B%A4%EC%9B%8C%EC%9A%94.)
^ko-Q0353-answer

**ko-Q0354** — 그녀는 누구보다도 아름다워요.

She is more beautiful than any other girl.

도 commonly means also/even. Its scope is the expression it follows, and it often replaces an ordinary subject/object marker.

Why: Inclusion 도. [[Korean#^ko-Q0354|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EB%85%80%EB%8A%94%20%EB%88%84%EA%B5%AC%EB%B3%B4%EB%8B%A4%EB%8F%84%20%EC%95%84%EB%A6%84%EB%8B%A4%EC%9B%8C%EC%9A%94.)
^ko-Q0354-answer

**ko-Q0355** — 여기는 이주 전부터 비가 하나도 오지 않았다.

There has been no rain here for the past two weeks.

Expected form: **하나도**

Why: Inclusion 도. [[Korean#^ko-Q0355|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%97%AC%EA%B8%B0%EB%8A%94%20%EC%9D%B4%EC%A3%BC%20%EC%A0%84%EB%B6%80%ED%84%B0%20%EB%B9%84%EA%B0%80%20%ED%95%98%EB%82%98%EB%8F%84%20%EC%98%A4%EC%A7%80%20%EC%95%8A%EC%95%98%EB%8B%A4.)
^ko-Q0355-answer

**ko-Q0356** — 여기는 이주 전부터 비가 하나도 오지 않았다.

There has been no rain here for the past two weeks.

Expected form: **하나도**

Why: Inclusion 도. [[Korean#^ko-Q0356|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%97%AC%EA%B8%B0%EB%8A%94%20%EC%9D%B4%EC%A3%BC%20%EC%A0%84%EB%B6%80%ED%84%B0%20%EB%B9%84%EA%B0%80%20%ED%95%98%EB%82%98%EB%8F%84%20%EC%98%A4%EC%A7%80%20%EC%95%8A%EC%95%98%EB%8B%A4.)
^ko-Q0356-answer

**ko-Q0357** — 무료로 받을 수도 있어.

You may get it free of charge.

Expected form: **수도**

Why: Inclusion 도. [[Korean#^ko-Q0357|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%AC%B4%EB%A3%8C%EB%A1%9C%20%EB%B0%9B%EC%9D%84%20%EC%88%98%EB%8F%84%20%EC%9E%88%EC%96%B4.)
^ko-Q0357-answer

**ko-Q0358** — 무료로 받을 수도 있어.

You may get it free of charge.

Why: Inclusion 도. [[Korean#^ko-Q0358|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%AC%B4%EB%A3%8C%EB%A1%9C%20%EB%B0%9B%EC%9D%84%20%EC%88%98%EB%8F%84%20%EC%9E%88%EC%96%B4.)
^ko-Q0358-answer

**ko-Q0359** — 호랑이도 제 말을 하면 온다.

Talk of the devil and he'll appear.

Why: Inclusion 도. [[Korean#^ko-Q0359|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%98%B8%EB%9E%91%EC%9D%B4%EB%8F%84%20%EC%A0%9C%20%EB%A7%90%EC%9D%84%20%ED%95%98%EB%A9%B4%20%EC%98%A8%EB%8B%A4.)
^ko-Q0359-answer

**ko-Q0360** — 호랑이도 제 말을 하면 온다.

Talk of the devil and he'll appear.

도 commonly means also/even. Its scope is the expression it follows, and it often replaces an ordinary subject/object marker.

Why: Inclusion 도. [[Korean#^ko-Q0360|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%98%B8%EB%9E%91%EC%9D%B4%EB%8F%84%20%EC%A0%9C%20%EB%A7%90%EC%9D%84%20%ED%95%98%EB%A9%B4%20%EC%98%A8%EB%8B%A4.)
^ko-Q0360-answer

**ko-Q0361** — 웃음이 나오기도 해요.

Sometimes I laugh.

Expected form: **나오기도**

Why: Inclusion 도. [[Korean#^ko-Q0361|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9B%83%EC%9D%8C%EC%9D%B4%20%EB%82%98%EC%98%A4%EA%B8%B0%EB%8F%84%20%ED%95%B4%EC%9A%94.)
^ko-Q0361-answer

**ko-Q0362** — 웃음이 나오기도 해요.

Sometimes I laugh.

Expected form: **나오기도**

Why: Inclusion 도. [[Korean#^ko-Q0362|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9B%83%EC%9D%8C%EC%9D%B4%20%EB%82%98%EC%98%A4%EA%B8%B0%EB%8F%84%20%ED%95%B4%EC%9A%94.)
^ko-Q0362-answer

**ko-Q0363** — 난 쿠키도 안 좋아해.

I don't like cookies, either.

Expected form: **쿠키도**

Why: Inclusion 도. [[Korean#^ko-Q0363|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%9C%20%EC%BF%A0%ED%82%A4%EB%8F%84%20%EC%95%88%20%EC%A2%8B%EC%95%84%ED%95%B4.)
^ko-Q0363-answer

**ko-Q0364** — 난 쿠키도 안 좋아해.

I don't like cookies, either.

Why: Inclusion 도. [[Korean#^ko-Q0364|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%9C%20%EC%BF%A0%ED%82%A4%EB%8F%84%20%EC%95%88%20%EC%A2%8B%EC%95%84%ED%95%B4.)
^ko-Q0364-answer

**ko-Q0365** — 우리가 톰을 도울 필요가 있을 수도 있다.

We might need to help Tom.

Why: Inclusion 도. [[Korean#^ko-Q0365|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9A%B0%EB%A6%AC%EA%B0%80%20%ED%86%B0%EC%9D%84%20%EB%8F%84%EC%9A%B8%20%ED%95%84%EC%9A%94%EA%B0%80%20%EC%9E%88%EC%9D%84%20%EC%88%98%EB%8F%84%20%EC%9E%88%EB%8B%A4.)
^ko-Q0365-answer

**ko-Q0366** — 우리가 톰을 도울 필요가 있을 수도 있다.

We might need to help Tom.

도 commonly means also/even. Its scope is the expression it follows, and it often replaces an ordinary subject/object marker.

Why: Inclusion 도. [[Korean#^ko-Q0366|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9A%B0%EB%A6%AC%EA%B0%80%20%ED%86%B0%EC%9D%84%20%EB%8F%84%EC%9A%B8%20%ED%95%84%EC%9A%94%EA%B0%80%20%EC%9E%88%EC%9D%84%20%EC%88%98%EB%8F%84%20%EC%9E%88%EB%8B%A4.)
^ko-Q0366-answer

**ko-Q0367** — 톰도 캐나다 사람이야?

Is Tom a Canadian, too?

Expected form: **톰도**

Why: Inclusion 도. [[Korean#^ko-Q0367|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EB%8F%84%20%EC%BA%90%EB%82%98%EB%8B%A4%20%EC%82%AC%EB%9E%8C%EC%9D%B4%EC%95%BC%3F)
^ko-Q0367-answer

**ko-Q0368** — 톰도 캐나다 사람이야?

Is Tom a Canadian, too?

Expected form: **톰도**

Why: Inclusion 도. [[Korean#^ko-Q0368|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EB%8F%84%20%EC%BA%90%EB%82%98%EB%8B%A4%20%EC%82%AC%EB%9E%8C%EC%9D%B4%EC%95%BC%3F)
^ko-Q0368-answer

**ko-Q0369** — 네가 꺼져 버려도 난 신경 안 쓴다!

You can fuck off for all I care!

Expected form: **버려도**

Why: Inclusion 도. [[Korean#^ko-Q0369|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%84%A4%EA%B0%80%20%EA%BA%BC%EC%A0%B8%20%EB%B2%84%EB%A0%A4%EB%8F%84%20%EB%82%9C%20%EC%8B%A0%EA%B2%BD%20%EC%95%88%20%EC%93%B4%EB%8B%A4%21)
^ko-Q0369-answer

**ko-Q0370** — 네가 꺼져 버려도 난 신경 안 쓴다!

You can fuck off for all I care!

Why: Inclusion 도. [[Korean#^ko-Q0370|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%84%A4%EA%B0%80%20%EA%BA%BC%EC%A0%B8%20%EB%B2%84%EB%A0%A4%EB%8F%84%20%EB%82%9C%20%EC%8B%A0%EA%B2%BD%20%EC%95%88%20%EC%93%B4%EB%8B%A4%21)
^ko-Q0370-answer

**ko-Q0371** — 톰은 심각한 부상을 당할 수도 있었다.

Tom could be seriously injured.

Why: Inclusion 도. [[Korean#^ko-Q0371|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EC%8B%AC%EA%B0%81%ED%95%9C%20%EB%B6%80%EC%83%81%EC%9D%84%20%EB%8B%B9%ED%95%A0%20%EC%88%98%EB%8F%84%20%EC%9E%88%EC%97%88%EB%8B%A4.)
^ko-Q0371-answer

**ko-Q0372** — 톰은 심각한 부상을 당할 수도 있었다.

Tom could be seriously injured.

도 commonly means also/even. Its scope is the expression it follows, and it often replaces an ordinary subject/object marker.

Why: Inclusion 도. [[Korean#^ko-Q0372|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EC%8B%AC%EA%B0%81%ED%95%9C%20%EB%B6%80%EC%83%81%EC%9D%84%20%EB%8B%B9%ED%95%A0%20%EC%88%98%EB%8F%84%20%EC%9E%88%EC%97%88%EB%8B%A4.)
^ko-Q0372-answer

**ko-Q0373** — 카드로도 지불할 수 있어요?

Can I pay with a credit card?

Expected form: **카드로도**

Why: Inclusion 도. [[Korean#^ko-Q0373|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%B9%B4%EB%93%9C%EB%A1%9C%EB%8F%84%20%EC%A7%80%EB%B6%88%ED%95%A0%20%EC%88%98%20%EC%9E%88%EC%96%B4%EC%9A%94%3F)
^ko-Q0373-answer

**ko-Q0374** — 카드로도 지불할 수 있어요?

Can I pay with a credit card?

Expected form: **카드로도**

Why: Inclusion 도. [[Korean#^ko-Q0374|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%B9%B4%EB%93%9C%EB%A1%9C%EB%8F%84%20%EC%A7%80%EB%B6%88%ED%95%A0%20%EC%88%98%20%EC%9E%88%EC%96%B4%EC%9A%94%3F)
^ko-Q0374-answer

**ko-Q0375** — 술 말고 내가 제일 좋아하는 음료수는 아보카도 쉐이크야. 흑, 너무 맛있어!

My favorite nonalcoholic drink is an avocado shake. Yum, it's so delicious!

Expected form: **아보카도**

Why: Inclusion 도. [[Korean#^ko-Q0375|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%88%A0%20%EB%A7%90%EA%B3%A0%20%EB%82%B4%EA%B0%80%20%EC%A0%9C%EC%9D%BC%20%EC%A2%8B%EC%95%84%ED%95%98%EB%8A%94%20%EC%9D%8C%EB%A3%8C%EC%88%98%EB%8A%94%20%EC%95%84%EB%B3%B4%EC%B9%B4%EB%8F%84%20%EC%89%90%EC%9D%B4%ED%81%AC%EC%95%BC.%20%ED%9D%91%2C%20%EB%84%88%EB%AC%B4%20%EB%A7%9B%EC%9E%88%EC%96%B4%21)
^ko-Q0375-answer

**ko-Q0376** — 술 말고 내가 제일 좋아하는 음료수는 아보카도 쉐이크야. 흑, 너무 맛있어!

My favorite nonalcoholic drink is an avocado shake. Yum, it's so delicious!

Why: Inclusion 도. [[Korean#^ko-Q0376|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%88%A0%20%EB%A7%90%EA%B3%A0%20%EB%82%B4%EA%B0%80%20%EC%A0%9C%EC%9D%BC%20%EC%A2%8B%EC%95%84%ED%95%98%EB%8A%94%20%EC%9D%8C%EB%A3%8C%EC%88%98%EB%8A%94%20%EC%95%84%EB%B3%B4%EC%B9%B4%EB%8F%84%20%EC%89%90%EC%9D%B4%ED%81%AC%EC%95%BC.%20%ED%9D%91%2C%20%EB%84%88%EB%AC%B4%20%EB%A7%9B%EC%9E%88%EC%96%B4%21)
^ko-Q0376-answer

**ko-Q0377** — 혼자 노래방에 간 적도 있어요?

Have you ever been to karaoke alone?

Why: Inclusion 도. [[Korean#^ko-Q0377|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%98%BC%EC%9E%90%20%EB%85%B8%EB%9E%98%EB%B0%A9%EC%97%90%20%EA%B0%84%20%EC%A0%81%EB%8F%84%20%EC%9E%88%EC%96%B4%EC%9A%94%3F)
^ko-Q0377-answer

**ko-Q0378** — 혼자 노래방에 간 적도 있어요?

Have you ever been to karaoke alone?

도 commonly means also/even. Its scope is the expression it follows, and it often replaces an ordinary subject/object marker.

Why: Inclusion 도. [[Korean#^ko-Q0378|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%98%BC%EC%9E%90%20%EB%85%B8%EB%9E%98%EB%B0%A9%EC%97%90%20%EA%B0%84%20%EC%A0%81%EB%8F%84%20%EC%9E%88%EC%96%B4%EC%9A%94%3F)
^ko-Q0378-answer

**ko-Q0379** — 갖고 다니지 않으면 잃을 것도 없다.

He who carries nothing loses nothing.

Expected form: **것도**

Why: Inclusion 도. [[Korean#^ko-Q0379|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B0%96%EA%B3%A0%20%EB%8B%A4%EB%8B%88%EC%A7%80%20%EC%95%8A%EC%9C%BC%EB%A9%B4%20%EC%9E%83%EC%9D%84%20%EA%B2%83%EB%8F%84%20%EC%97%86%EB%8B%A4.)
^ko-Q0379-answer

**ko-Q0380** — 갖고 다니지 않으면 잃을 것도 없다.

He who carries nothing loses nothing.

Expected form: **것도**

Why: Inclusion 도. [[Korean#^ko-Q0380|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B0%96%EA%B3%A0%20%EB%8B%A4%EB%8B%88%EC%A7%80%20%EC%95%8A%EC%9C%BC%EB%A9%B4%20%EC%9E%83%EC%9D%84%20%EA%B2%83%EB%8F%84%20%EC%97%86%EB%8B%A4.)
^ko-Q0380-answer

**ko-Q0381** — 톰도 마찬가지로 프랑스어 배워.

Tom learns French as well.

Expected form: **톰도**

Why: Inclusion 도. [[Korean#^ko-Q0381|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EB%8F%84%20%EB%A7%88%EC%B0%AC%EA%B0%80%EC%A7%80%EB%A1%9C%20%ED%94%84%EB%9E%91%EC%8A%A4%EC%96%B4%20%EB%B0%B0%EC%9B%8C.)
^ko-Q0381-answer

**ko-Q0382** — 톰도 마찬가지로 프랑스어 배워.

Tom learns French as well.

Why: Inclusion 도. [[Korean#^ko-Q0382|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EB%8F%84%20%EB%A7%88%EC%B0%AC%EA%B0%80%EC%A7%80%EB%A1%9C%20%ED%94%84%EB%9E%91%EC%8A%A4%EC%96%B4%20%EB%B0%B0%EC%9B%8C.)
^ko-Q0382-answer

**ko-Q0383** — 톰은 남아 있어도 돼. 너희 나머지는 나가야 해.

Tom is allowed to stay. The rest of you have to leave.

Why: Inclusion 도. [[Korean#^ko-Q0383|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EB%82%A8%EC%95%84%20%EC%9E%88%EC%96%B4%EB%8F%84%20%EB%8F%BC.%20%EB%84%88%ED%9D%AC%20%EB%82%98%EB%A8%B8%EC%A7%80%EB%8A%94%20%EB%82%98%EA%B0%80%EC%95%BC%20%ED%95%B4.)
^ko-Q0383-answer

**ko-Q0384** — 톰은 남아 있어도 돼. 너희 나머지는 나가야 해.

Tom is allowed to stay. The rest of you have to leave.

도 commonly means also/even. Its scope is the expression it follows, and it often replaces an ordinary subject/object marker.

Why: Inclusion 도. [[Korean#^ko-Q0384|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EB%82%A8%EC%95%84%20%EC%9E%88%EC%96%B4%EB%8F%84%20%EB%8F%BC.%20%EB%84%88%ED%9D%AC%20%EB%82%98%EB%A8%B8%EC%A7%80%EB%8A%94%20%EB%82%98%EA%B0%80%EC%95%BC%20%ED%95%B4.)
^ko-Q0384-answer

**ko-Q0385** — 그도 중국어를 공부하고 있다.

He is also studying Chinese.

Expected form: **그도**

Why: Inclusion 도. [[Korean#^ko-Q0385|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EB%8F%84%20%EC%A4%91%EA%B5%AD%EC%96%B4%EB%A5%BC%20%EA%B3%B5%EB%B6%80%ED%95%98%EA%B3%A0%20%EC%9E%88%EB%8B%A4.)
^ko-Q0385-answer

**ko-Q0386** — 그도 중국어를 공부하고 있다.

He is also studying Chinese.

Expected form: **그도**

Why: Inclusion 도. [[Korean#^ko-Q0386|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EB%8F%84%20%EC%A4%91%EA%B5%AD%EC%96%B4%EB%A5%BC%20%EA%B3%B5%EB%B6%80%ED%95%98%EA%B3%A0%20%EC%9E%88%EB%8B%A4.)
^ko-Q0386-answer

**ko-Q0387** — 짚신도 짝이 있다

Even a straw shoe belongs to a pair.

Expected form: **짚신도**

Why: Inclusion 도. [[Korean#^ko-Q0387|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A7%9A%EC%8B%A0%EB%8F%84%20%EC%A7%9D%EC%9D%B4%20%EC%9E%88%EB%8B%A4)
^ko-Q0387-answer

**ko-Q0388** — 짚신도 짝이 있다

Even a straw shoe belongs to a pair.

Why: Inclusion 도. [[Korean#^ko-Q0388|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A7%9A%EC%8B%A0%EB%8F%84%20%EC%A7%9D%EC%9D%B4%20%EC%9E%88%EB%8B%A4)
^ko-Q0388-answer

**ko-Q0389** — 그 누구도 완벽하지 않는다.

Nobody is perfect.

Why: Inclusion 도. [[Korean#^ko-Q0389|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%20%EB%88%84%EA%B5%AC%EB%8F%84%20%EC%99%84%EB%B2%BD%ED%95%98%EC%A7%80%20%EC%95%8A%EB%8A%94%EB%8B%A4.)
^ko-Q0389-answer

**ko-Q0390** — 그 누구도 완벽하지 않는다.

Nobody is perfect.

도 commonly means also/even. Its scope is the expression it follows, and it often replaces an ordinary subject/object marker.

Why: Inclusion 도. [[Korean#^ko-Q0390|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%20%EB%88%84%EA%B5%AC%EB%8F%84%20%EC%99%84%EB%B2%BD%ED%95%98%EC%A7%80%20%EC%95%8A%EB%8A%94%EB%8B%A4.)
^ko-Q0390-answer

**ko-Q0391** — 나는 너의 가장 친한 친구도 가장 나쁜 적도 될 수 있어.

I can be your best friend or your worst enemy.

Expected form: **친구도**

Why: Inclusion 도. [[Korean#^ko-Q0391|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%EB%84%88%EC%9D%98%20%EA%B0%80%EC%9E%A5%20%EC%B9%9C%ED%95%9C%20%EC%B9%9C%EA%B5%AC%EB%8F%84%20%EA%B0%80%EC%9E%A5%20%EB%82%98%EC%81%9C%20%EC%A0%81%EB%8F%84%20%EB%90%A0%20%EC%88%98%20%EC%9E%88%EC%96%B4.)
^ko-Q0391-answer

**ko-Q0392** — 나는 너의 가장 친한 친구도 가장 나쁜 적도 될 수 있어.

I can be your best friend or your worst enemy.

Expected form: **친구도**

Why: Inclusion 도. [[Korean#^ko-Q0392|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%EB%84%88%EC%9D%98%20%EA%B0%80%EC%9E%A5%20%EC%B9%9C%ED%95%9C%20%EC%B9%9C%EA%B5%AC%EB%8F%84%20%EA%B0%80%EC%9E%A5%20%EB%82%98%EC%81%9C%20%EC%A0%81%EB%8F%84%20%EB%90%A0%20%EC%88%98%20%EC%9E%88%EC%96%B4.)
^ko-Q0392-answer

**ko-Q0393** — 손 들고 질문해도 괜찮아요.

It's okay to raise your hand and ask a question.

Expected form: **질문해도**

Why: Inclusion 도. [[Korean#^ko-Q0393|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%86%90%20%EB%93%A4%EA%B3%A0%20%EC%A7%88%EB%AC%B8%ED%95%B4%EB%8F%84%20%EA%B4%9C%EC%B0%AE%EC%95%84%EC%9A%94.)
^ko-Q0393-answer

**ko-Q0394** — 손 들고 질문해도 괜찮아요.

It's okay to raise your hand and ask a question.

Why: Inclusion 도. [[Korean#^ko-Q0394|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%86%90%20%EB%93%A4%EA%B3%A0%20%EC%A7%88%EB%AC%B8%ED%95%B4%EB%8F%84%20%EA%B4%9C%EC%B0%AE%EC%95%84%EC%9A%94.)
^ko-Q0394-answer

**ko-Q0395** — 나는 인도 사람이 아니야

I'm not Indian.

Why: Inclusion 도. [[Korean#^ko-Q0395|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%EC%9D%B8%EB%8F%84%20%EC%82%AC%EB%9E%8C%EC%9D%B4%20%EC%95%84%EB%8B%88%EC%95%BC)
^ko-Q0395-answer

**ko-Q0396** — 나는 인도 사람이 아니야

I'm not Indian.

도 commonly means also/even. Its scope is the expression it follows, and it often replaces an ordinary subject/object marker.

Why: Inclusion 도. [[Korean#^ko-Q0396|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%EC%9D%B8%EB%8F%84%20%EC%82%AC%EB%9E%8C%EC%9D%B4%20%EC%95%84%EB%8B%88%EC%95%BC)
^ko-Q0396-answer

**ko-Q0397** — 내가 그것에 대한 너의 말을 믿어도 되겠니?

Can I take your word for it?

Expected form: **믿어도**

Why: Inclusion 도. [[Korean#^ko-Q0397|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%B4%EA%B0%80%20%EA%B7%B8%EA%B2%83%EC%97%90%20%EB%8C%80%ED%95%9C%20%EB%84%88%EC%9D%98%20%EB%A7%90%EC%9D%84%20%EB%AF%BF%EC%96%B4%EB%8F%84%20%EB%90%98%EA%B2%A0%EB%8B%88%3F)
^ko-Q0397-answer

**ko-Q0398** — 내가 그것에 대한 너의 말을 믿어도 되겠니?

Can I take your word for it?

Expected form: **믿어도**

Why: Inclusion 도. [[Korean#^ko-Q0398|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%B4%EA%B0%80%20%EA%B7%B8%EA%B2%83%EC%97%90%20%EB%8C%80%ED%95%9C%20%EB%84%88%EC%9D%98%20%EB%A7%90%EC%9D%84%20%EB%AF%BF%EC%96%B4%EB%8F%84%20%EB%90%98%EA%B2%A0%EB%8B%88%3F)
^ko-Q0398-answer

**ko-Q0399** — 이 기사를 읽는것만으로도 그 사고가 얼마나 심각했는지 알 수 있다.

You have only to read this article to see how serious the accident was.

Expected form: **읽는것만으로도**

Why: Inclusion 도. [[Korean#^ko-Q0399|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9D%B4%20%EA%B8%B0%EC%82%AC%EB%A5%BC%20%EC%9D%BD%EB%8A%94%EA%B2%83%EB%A7%8C%EC%9C%BC%EB%A1%9C%EB%8F%84%20%EA%B7%B8%20%EC%82%AC%EA%B3%A0%EA%B0%80%20%EC%96%BC%EB%A7%88%EB%82%98%20%EC%8B%AC%EA%B0%81%ED%96%88%EB%8A%94%EC%A7%80%20%EC%95%8C%20%EC%88%98%20%EC%9E%88%EB%8B%A4.)
^ko-Q0399-answer

**ko-Q0400** — 이 기사를 읽는것만으로도 그 사고가 얼마나 심각했는지 알 수 있다.

You have only to read this article to see how serious the accident was.

Why: Inclusion 도. [[Korean#^ko-Q0400|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9D%B4%20%EA%B8%B0%EC%82%AC%EB%A5%BC%20%EC%9D%BD%EB%8A%94%EA%B2%83%EB%A7%8C%EC%9C%BC%EB%A1%9C%EB%8F%84%20%EA%B7%B8%20%EC%82%AC%EA%B3%A0%EA%B0%80%20%EC%96%BC%EB%A7%88%EB%82%98%20%EC%8B%AC%EA%B0%81%ED%96%88%EB%8A%94%EC%A7%80%20%EC%95%8C%20%EC%88%98%20%EC%9E%88%EB%8B%A4.)
^ko-Q0400-answer


### Answers 401–450

**ko-Q0401** — 해결책을 찾았지만 너무 빨리 찾아서 맞는 답이 아닌거 같습니다.

I found a solution, but I found it so fast that it can't be the right solution.

Why: Restriction 만. [[Korean#^ko-Q0401|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%95%B4%EA%B2%B0%EC%B1%85%EC%9D%84%20%EC%B0%BE%EC%95%98%EC%A7%80%EB%A7%8C%20%EB%84%88%EB%AC%B4%20%EB%B9%A8%EB%A6%AC%20%EC%B0%BE%EC%95%84%EC%84%9C%20%EB%A7%9E%EB%8A%94%20%EB%8B%B5%EC%9D%B4%20%EC%95%84%EB%8B%8C%EA%B1%B0%20%EA%B0%99%EC%8A%B5%EB%8B%88%EB%8B%A4.)
^ko-Q0401-answer

**ko-Q0402** — 해결책을 찾았지만 너무 빨리 찾아서 맞는 답이 아닌거 같습니다.

I found a solution, but I found it so fast that it can't be the right solution.

만 restricts a phrase to only. It can combine with case particles. Restriction and inclusion change the statement’s meaning even when both alternatives are grammatical.

Why: Restriction 만. [[Korean#^ko-Q0402|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%95%B4%EA%B2%B0%EC%B1%85%EC%9D%84%20%EC%B0%BE%EC%95%98%EC%A7%80%EB%A7%8C%20%EB%84%88%EB%AC%B4%20%EB%B9%A8%EB%A6%AC%20%EC%B0%BE%EC%95%84%EC%84%9C%20%EB%A7%9E%EB%8A%94%20%EB%8B%B5%EC%9D%B4%20%EC%95%84%EB%8B%8C%EA%B1%B0%20%EA%B0%99%EC%8A%B5%EB%8B%88%EB%8B%A4.)
^ko-Q0402-answer

**ko-Q0403** — 그녀가 미소지을 땐, 녹아내릴 것만 같아.

When she smiles, I feel like melting.

Expected form: **것만**

Why: Restriction 만. [[Korean#^ko-Q0403|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EB%85%80%EA%B0%80%20%EB%AF%B8%EC%86%8C%EC%A7%80%EC%9D%84%20%EB%95%90%2C%20%EB%85%B9%EC%95%84%EB%82%B4%EB%A6%B4%20%EA%B2%83%EB%A7%8C%20%EA%B0%99%EC%95%84.)
^ko-Q0403-answer

**ko-Q0404** — 그녀가 미소지을 땐, 녹아내릴 것만 같아.

When she smiles, I feel like melting.

Expected form: **것만**

Why: Restriction 만. [[Korean#^ko-Q0404|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EB%85%80%EA%B0%80%20%EB%AF%B8%EC%86%8C%EC%A7%80%EC%9D%84%20%EB%95%90%2C%20%EB%85%B9%EC%95%84%EB%82%B4%EB%A6%B4%20%EA%B2%83%EB%A7%8C%20%EA%B0%99%EC%95%84.)
^ko-Q0404-answer

**ko-Q0405** — 톰은 획기적이지는 않지만 좋은 영화는 잘 만든다.

Tom doesn't innovate, but he does make good movies.

Expected form: **않지만**

Why: Restriction 만. [[Korean#^ko-Q0405|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%ED%9A%8D%EA%B8%B0%EC%A0%81%EC%9D%B4%EC%A7%80%EB%8A%94%20%EC%95%8A%EC%A7%80%EB%A7%8C%20%EC%A2%8B%EC%9D%80%20%EC%98%81%ED%99%94%EB%8A%94%20%EC%9E%98%20%EB%A7%8C%EB%93%A0%EB%8B%A4.)
^ko-Q0405-answer

**ko-Q0406** — 톰은 획기적이지는 않지만 좋은 영화는 잘 만든다.

Tom doesn't innovate, but he does make good movies.

Why: Restriction 만. [[Korean#^ko-Q0406|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%ED%9A%8D%EA%B8%B0%EC%A0%81%EC%9D%B4%EC%A7%80%EB%8A%94%20%EC%95%8A%EC%A7%80%EB%A7%8C%20%EC%A2%8B%EC%9D%80%20%EC%98%81%ED%99%94%EB%8A%94%20%EC%9E%98%20%EB%A7%8C%EB%93%A0%EB%8B%A4.)
^ko-Q0406-answer

**ko-Q0407** — 톰만 빼고 다들 파티에 갔어.

Everyone except Tom went to the party.

Why: Restriction 만. [[Korean#^ko-Q0407|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EB%A7%8C%20%EB%B9%BC%EA%B3%A0%20%EB%8B%A4%EB%93%A4%20%ED%8C%8C%ED%8B%B0%EC%97%90%20%EA%B0%94%EC%96%B4.)
^ko-Q0407-answer

**ko-Q0408** — 톰만 빼고 다들 파티에 갔어.

Everyone except Tom went to the party.

만 restricts a phrase to only. It can combine with case particles. Restriction and inclusion change the statement’s meaning even when both alternatives are grammatical.

Why: Restriction 만. [[Korean#^ko-Q0408|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EB%A7%8C%20%EB%B9%BC%EA%B3%A0%20%EB%8B%A4%EB%93%A4%20%ED%8C%8C%ED%8B%B0%EC%97%90%20%EA%B0%94%EC%96%B4.)
^ko-Q0408-answer

**ko-Q0409** — 그의 보고서를 검토했지만 실수를 찾을 수 없었다.

I went over his report, but couldn't find any mistakes.

Expected form: **검토했지만**

Why: Restriction 만. [[Korean#^ko-Q0409|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EC%9D%98%20%EB%B3%B4%EA%B3%A0%EC%84%9C%EB%A5%BC%20%EA%B2%80%ED%86%A0%ED%96%88%EC%A7%80%EB%A7%8C%20%EC%8B%A4%EC%88%98%EB%A5%BC%20%EC%B0%BE%EC%9D%84%20%EC%88%98%20%EC%97%86%EC%97%88%EB%8B%A4.)
^ko-Q0409-answer

**ko-Q0410** — 그의 보고서를 검토했지만 실수를 찾을 수 없었다.

I went over his report, but couldn't find any mistakes.

Expected form: **검토했지만**

Why: Restriction 만. [[Korean#^ko-Q0410|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EC%9D%98%20%EB%B3%B4%EA%B3%A0%EC%84%9C%EB%A5%BC%20%EA%B2%80%ED%86%A0%ED%96%88%EC%A7%80%EB%A7%8C%20%EC%8B%A4%EC%88%98%EB%A5%BC%20%EC%B0%BE%EC%9D%84%20%EC%88%98%20%EC%97%86%EC%97%88%EB%8B%A4.)
^ko-Q0410-answer

**ko-Q0411** — 나는 도서관에서만 공부해요.

I only study in the library.

Expected form: **도서관에서만**

Why: Restriction 만. [[Korean#^ko-Q0411|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%EB%8F%84%EC%84%9C%EA%B4%80%EC%97%90%EC%84%9C%EB%A7%8C%20%EA%B3%B5%EB%B6%80%ED%95%B4%EC%9A%94.)
^ko-Q0411-answer

**ko-Q0412** — 나는 도서관에서만 공부해요.

I only study in the library.

Why: Restriction 만. [[Korean#^ko-Q0412|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%EB%8F%84%EC%84%9C%EA%B4%80%EC%97%90%EC%84%9C%EB%A7%8C%20%EA%B3%B5%EB%B6%80%ED%95%B4%EC%9A%94.)
^ko-Q0412-answer

**ko-Q0413** — 그 기간동안 나는 오직 빠리에서만 짧게 머물렀기 때문에 그 기간이 매우 아쉬웠다.

Each time I spent only a short time in Paris, and this has given me much to regret.

Why: Restriction 만. [[Korean#^ko-Q0413|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%20%EA%B8%B0%EA%B0%84%EB%8F%99%EC%95%88%20%EB%82%98%EB%8A%94%20%EC%98%A4%EC%A7%81%20%EB%B9%A0%EB%A6%AC%EC%97%90%EC%84%9C%EB%A7%8C%20%EC%A7%A7%EA%B2%8C%20%EB%A8%B8%EB%AC%BC%EB%A0%80%EA%B8%B0%20%EB%95%8C%EB%AC%B8%EC%97%90%20%EA%B7%B8%20%EA%B8%B0%EA%B0%84%EC%9D%B4%20%EB%A7%A4%EC%9A%B0%20%EC%95%84%EC%89%AC%EC%9B%A0%EB%8B%A4.)
^ko-Q0413-answer

**ko-Q0414** — 그 기간동안 나는 오직 빠리에서만 짧게 머물렀기 때문에 그 기간이 매우 아쉬웠다.

Each time I spent only a short time in Paris, and this has given me much to regret.

만 restricts a phrase to only. It can combine with case particles. Restriction and inclusion change the statement’s meaning even when both alternatives are grammatical.

Why: Restriction 만. [[Korean#^ko-Q0414|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%20%EA%B8%B0%EA%B0%84%EB%8F%99%EC%95%88%20%EB%82%98%EB%8A%94%20%EC%98%A4%EC%A7%81%20%EB%B9%A0%EB%A6%AC%EC%97%90%EC%84%9C%EB%A7%8C%20%EC%A7%A7%EA%B2%8C%20%EB%A8%B8%EB%AC%BC%EB%A0%80%EA%B8%B0%20%EB%95%8C%EB%AC%B8%EC%97%90%20%EA%B7%B8%20%EA%B8%B0%EA%B0%84%EC%9D%B4%20%EB%A7%A4%EC%9A%B0%20%EC%95%84%EC%89%AC%EC%9B%A0%EB%8B%A4.)
^ko-Q0414-answer

**ko-Q0415** — 나는 그 여자의 제안을 거절해야만 했어.

I had to refuse her offer.

Expected form: **거절해야만**

Why: Restriction 만. [[Korean#^ko-Q0415|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%EA%B7%B8%20%EC%97%AC%EC%9E%90%EC%9D%98%20%EC%A0%9C%EC%95%88%EC%9D%84%20%EA%B1%B0%EC%A0%88%ED%95%B4%EC%95%BC%EB%A7%8C%20%ED%96%88%EC%96%B4.)
^ko-Q0415-answer

**ko-Q0416** — 나는 그 여자의 제안을 거절해야만 했어.

I had to refuse her offer.

Expected form: **거절해야만**

Why: Restriction 만. [[Korean#^ko-Q0416|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%EA%B7%B8%20%EC%97%AC%EC%9E%90%EC%9D%98%20%EC%A0%9C%EC%95%88%EC%9D%84%20%EA%B1%B0%EC%A0%88%ED%95%B4%EC%95%BC%EB%A7%8C%20%ED%96%88%EC%96%B4.)
^ko-Q0416-answer

**ko-Q0417** — 하지만 주인공은 자신의 실수를 인식하고 있다.

However the protagonist is aware of his own mistakes.

Expected form: **하지만**

Why: Restriction 만. [[Korean#^ko-Q0417|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%95%98%EC%A7%80%EB%A7%8C%20%EC%A3%BC%EC%9D%B8%EA%B3%B5%EC%9D%80%20%EC%9E%90%EC%8B%A0%EC%9D%98%20%EC%8B%A4%EC%88%98%EB%A5%BC%20%EC%9D%B8%EC%8B%9D%ED%95%98%EA%B3%A0%20%EC%9E%88%EB%8B%A4.)
^ko-Q0417-answer

**ko-Q0418** — 하지만 주인공은 자신의 실수를 인식하고 있다.

However the protagonist is aware of his own mistakes.

Why: Restriction 만. [[Korean#^ko-Q0418|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%95%98%EC%A7%80%EB%A7%8C%20%EC%A3%BC%EC%9D%B8%EA%B3%B5%EC%9D%80%20%EC%9E%90%EC%8B%A0%EC%9D%98%20%EC%8B%A4%EC%88%98%EB%A5%BC%20%EC%9D%B8%EC%8B%9D%ED%95%98%EA%B3%A0%20%EC%9E%88%EB%8B%A4.)
^ko-Q0418-answer

**ko-Q0419** — 탐은 메리와 뽀뽀하고 싶었지만 시도할 용기가 없었다.

Tom wanted to kiss Mary, but he didn't have the nerve to try.

Why: Restriction 만. [[Korean#^ko-Q0419|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%83%90%EC%9D%80%20%EB%A9%94%EB%A6%AC%EC%99%80%20%EB%BD%80%EB%BD%80%ED%95%98%EA%B3%A0%20%EC%8B%B6%EC%97%88%EC%A7%80%EB%A7%8C%20%EC%8B%9C%EB%8F%84%ED%95%A0%20%EC%9A%A9%EA%B8%B0%EA%B0%80%20%EC%97%86%EC%97%88%EB%8B%A4.)
^ko-Q0419-answer

**ko-Q0420** — 탐은 메리와 뽀뽀하고 싶었지만 시도할 용기가 없었다.

Tom wanted to kiss Mary, but he didn't have the nerve to try.

만 restricts a phrase to only. It can combine with case particles. Restriction and inclusion change the statement’s meaning even when both alternatives are grammatical.

Why: Restriction 만. [[Korean#^ko-Q0420|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%83%90%EC%9D%80%20%EB%A9%94%EB%A6%AC%EC%99%80%20%EB%BD%80%EB%BD%80%ED%95%98%EA%B3%A0%20%EC%8B%B6%EC%97%88%EC%A7%80%EB%A7%8C%20%EC%8B%9C%EB%8F%84%ED%95%A0%20%EC%9A%A9%EA%B8%B0%EA%B0%80%20%EC%97%86%EC%97%88%EB%8B%A4.)
^ko-Q0420-answer

**ko-Q0421** — 나는 네가 그렇게 하도록 강요하지는 않겠지만 그렇게 해야 할거야

I won't force you to do that, but I think you should.

Expected form: **않겠지만**

Why: Restriction 만. [[Korean#^ko-Q0421|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%EB%84%A4%EA%B0%80%20%EA%B7%B8%EB%A0%87%EA%B2%8C%20%ED%95%98%EB%8F%84%EB%A1%9D%20%EA%B0%95%EC%9A%94%ED%95%98%EC%A7%80%EB%8A%94%20%EC%95%8A%EA%B2%A0%EC%A7%80%EB%A7%8C%20%EA%B7%B8%EB%A0%87%EA%B2%8C%20%ED%95%B4%EC%95%BC%20%ED%95%A0%EA%B1%B0%EC%95%BC)
^ko-Q0421-answer

**ko-Q0422** — 나는 네가 그렇게 하도록 강요하지는 않겠지만 그렇게 해야 할거야

I won't force you to do that, but I think you should.

Expected form: **않겠지만**

Why: Restriction 만. [[Korean#^ko-Q0422|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%EB%84%A4%EA%B0%80%20%EA%B7%B8%EB%A0%87%EA%B2%8C%20%ED%95%98%EB%8F%84%EB%A1%9D%20%EA%B0%95%EC%9A%94%ED%95%98%EC%A7%80%EB%8A%94%20%EC%95%8A%EA%B2%A0%EC%A7%80%EB%A7%8C%20%EA%B7%B8%EB%A0%87%EA%B2%8C%20%ED%95%B4%EC%95%BC%20%ED%95%A0%EA%B1%B0%EC%95%BC)
^ko-Q0422-answer

**ko-Q0423** — 날 그만 괴롭혀!

Stop bugging me!

Expected form: **그만**

Why: Restriction 만. [[Korean#^ko-Q0423|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%A0%20%EA%B7%B8%EB%A7%8C%20%EA%B4%B4%EB%A1%AD%ED%98%80%21)
^ko-Q0423-answer

**ko-Q0424** — 날 그만 괴롭혀!

Stop bugging me!

Why: Restriction 만. [[Korean#^ko-Q0424|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%A0%20%EA%B7%B8%EB%A7%8C%20%EA%B4%B4%EB%A1%AD%ED%98%80%21)
^ko-Q0424-answer

**ko-Q0425** — 그는 울기만 했다.

He did nothing but cry.

Why: Restriction 만. [[Korean#^ko-Q0425|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EB%8A%94%20%EC%9A%B8%EA%B8%B0%EB%A7%8C%20%ED%96%88%EB%8B%A4.)
^ko-Q0425-answer

**ko-Q0426** — 그는 울기만 했다.

He did nothing but cry.

만 restricts a phrase to only. It can combine with case particles. Restriction and inclusion change the statement’s meaning even when both alternatives are grammatical.

Why: Restriction 만. [[Korean#^ko-Q0426|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EB%8A%94%20%EC%9A%B8%EA%B8%B0%EB%A7%8C%20%ED%96%88%EB%8B%A4.)
^ko-Q0426-answer

**ko-Q0427** — 난 나를위해서만 말을할수있어.

I can only speak for myself.

Expected form: **나를위해서만**

Why: Restriction 만. [[Korean#^ko-Q0427|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%9C%20%EB%82%98%EB%A5%BC%EC%9C%84%ED%95%B4%EC%84%9C%EB%A7%8C%20%EB%A7%90%EC%9D%84%ED%95%A0%EC%88%98%EC%9E%88%EC%96%B4.)
^ko-Q0427-answer

**ko-Q0428** — 난 나를위해서만 말을할수있어.

I can only speak for myself.

Expected form: **나를위해서만**

Why: Restriction 만. [[Korean#^ko-Q0428|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%9C%20%EB%82%98%EB%A5%BC%EC%9C%84%ED%95%B4%EC%84%9C%EB%A7%8C%20%EB%A7%90%EC%9D%84%ED%95%A0%EC%88%98%EC%9E%88%EC%96%B4.)
^ko-Q0428-answer

**ko-Q0429** — 택시 한 대만 불러 주시겠습니까?

Would you like me to call a taxi?

Expected form: **대만**

Why: Restriction 만. [[Korean#^ko-Q0429|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%83%9D%EC%8B%9C%20%ED%95%9C%20%EB%8C%80%EB%A7%8C%20%EB%B6%88%EB%9F%AC%20%EC%A3%BC%EC%8B%9C%EA%B2%A0%EC%8A%B5%EB%8B%88%EA%B9%8C%3F)
^ko-Q0429-answer

**ko-Q0430** — 택시 한 대만 불러 주시겠습니까?

Would you like me to call a taxi?

Why: Restriction 만. [[Korean#^ko-Q0430|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%83%9D%EC%8B%9C%20%ED%95%9C%20%EB%8C%80%EB%A7%8C%20%EB%B6%88%EB%9F%AC%20%EC%A3%BC%EC%8B%9C%EA%B2%A0%EC%8A%B5%EB%8B%88%EA%B9%8C%3F)
^ko-Q0430-answer

**ko-Q0431** — 인간은 이성이 있지만 동물은 없다.

Man has reason, animals do not.

Why: Restriction 만. [[Korean#^ko-Q0431|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9D%B8%EA%B0%84%EC%9D%80%20%EC%9D%B4%EC%84%B1%EC%9D%B4%20%EC%9E%88%EC%A7%80%EB%A7%8C%20%EB%8F%99%EB%AC%BC%EC%9D%80%20%EC%97%86%EB%8B%A4.)
^ko-Q0431-answer

**ko-Q0432** — 인간은 이성이 있지만 동물은 없다.

Man has reason, animals do not.

만 restricts a phrase to only. It can combine with case particles. Restriction and inclusion change the statement’s meaning even when both alternatives are grammatical.

Why: Restriction 만. [[Korean#^ko-Q0432|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9D%B8%EA%B0%84%EC%9D%80%20%EC%9D%B4%EC%84%B1%EC%9D%B4%20%EC%9E%88%EC%A7%80%EB%A7%8C%20%EB%8F%99%EB%AC%BC%EC%9D%80%20%EC%97%86%EB%8B%A4.)
^ko-Q0432-answer

**ko-Q0433** — 어둠으로 어둠을 몰아낼 수는 없다. 오직 빛으로만 할수 있다. 증오로 증오를 몰아낼수는 없다. 오직 사랑만이 그것을 할 수 있다.

Darkness cannot drive out darkness; only light can do that. Hate cannot drive out hate; only love can do that.

Expected form: **빛으로만**

Why: Restriction 만. [[Korean#^ko-Q0433|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%96%B4%EB%91%A0%EC%9C%BC%EB%A1%9C%20%EC%96%B4%EB%91%A0%EC%9D%84%20%EB%AA%B0%EC%95%84%EB%82%BC%20%EC%88%98%EB%8A%94%20%EC%97%86%EB%8B%A4.%20%EC%98%A4%EC%A7%81%20%EB%B9%9B%EC%9C%BC%EB%A1%9C%EB%A7%8C%20%ED%95%A0%EC%88%98%20%EC%9E%88%EB%8B%A4.%20%EC%A6%9D%EC%98%A4%EB%A1%9C%20%EC%A6%9D%EC%98%A4%EB%A5%BC%20%EB%AA%B0%EC%95%84%EB%82%BC%EC%88%98%EB%8A%94%20%EC%97%86%EB%8B%A4.%20%EC%98%A4%EC%A7%81%20%EC%82%AC%EB%9E%91%EB%A7%8C%EC%9D%B4%20%EA%B7%B8%EA%B2%83%EC%9D%84%20%ED%95%A0%20%EC%88%98%20%EC%9E%88%EB%8B%A4.)
^ko-Q0433-answer

**ko-Q0434** — 어둠으로 어둠을 몰아낼 수는 없다. 오직 빛으로만 할수 있다. 증오로 증오를 몰아낼수는 없다. 오직 사랑만이 그것을 할 수 있다.

Darkness cannot drive out darkness; only light can do that. Hate cannot drive out hate; only love can do that.

Expected form: **빛으로만**

Why: Restriction 만. [[Korean#^ko-Q0434|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%96%B4%EB%91%A0%EC%9C%BC%EB%A1%9C%20%EC%96%B4%EB%91%A0%EC%9D%84%20%EB%AA%B0%EC%95%84%EB%82%BC%20%EC%88%98%EB%8A%94%20%EC%97%86%EB%8B%A4.%20%EC%98%A4%EC%A7%81%20%EB%B9%9B%EC%9C%BC%EB%A1%9C%EB%A7%8C%20%ED%95%A0%EC%88%98%20%EC%9E%88%EB%8B%A4.%20%EC%A6%9D%EC%98%A4%EB%A1%9C%20%EC%A6%9D%EC%98%A4%EB%A5%BC%20%EB%AA%B0%EC%95%84%EB%82%BC%EC%88%98%EB%8A%94%20%EC%97%86%EB%8B%A4.%20%EC%98%A4%EC%A7%81%20%EC%82%AC%EB%9E%91%EB%A7%8C%EC%9D%B4%20%EA%B7%B8%EA%B2%83%EC%9D%84%20%ED%95%A0%20%EC%88%98%20%EC%9E%88%EB%8B%A4.)
^ko-Q0434-answer

**ko-Q0435** — 그녀는 그한테 그녀의 아버지가 차고 청소 하는 것을 도와 주라고 했지만 그는 너무 바빠서 못 도와 준대.

She asked him to help her father clean the garage, but he said that he was too busy to help.

Expected form: **했지만**

Why: Restriction 만. [[Korean#^ko-Q0435|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EB%85%80%EB%8A%94%20%EA%B7%B8%ED%95%9C%ED%85%8C%20%EA%B7%B8%EB%85%80%EC%9D%98%20%EC%95%84%EB%B2%84%EC%A7%80%EA%B0%80%20%EC%B0%A8%EA%B3%A0%20%EC%B2%AD%EC%86%8C%20%ED%95%98%EB%8A%94%20%EA%B2%83%EC%9D%84%20%EB%8F%84%EC%99%80%20%EC%A3%BC%EB%9D%BC%EA%B3%A0%20%ED%96%88%EC%A7%80%EB%A7%8C%20%EA%B7%B8%EB%8A%94%20%EB%84%88%EB%AC%B4%20%EB%B0%94%EB%B9%A0%EC%84%9C%20%EB%AA%BB%20%EB%8F%84%EC%99%80%20%EC%A4%80%EB%8C%80.)
^ko-Q0435-answer

**ko-Q0436** — 그녀는 그한테 그녀의 아버지가 차고 청소 하는 것을 도와 주라고 했지만 그는 너무 바빠서 못 도와 준대.

She asked him to help her father clean the garage, but he said that he was too busy to help.

Why: Restriction 만. [[Korean#^ko-Q0436|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EB%85%80%EB%8A%94%20%EA%B7%B8%ED%95%9C%ED%85%8C%20%EA%B7%B8%EB%85%80%EC%9D%98%20%EC%95%84%EB%B2%84%EC%A7%80%EA%B0%80%20%EC%B0%A8%EA%B3%A0%20%EC%B2%AD%EC%86%8C%20%ED%95%98%EB%8A%94%20%EA%B2%83%EC%9D%84%20%EB%8F%84%EC%99%80%20%EC%A3%BC%EB%9D%BC%EA%B3%A0%20%ED%96%88%EC%A7%80%EB%A7%8C%20%EA%B7%B8%EB%8A%94%20%EB%84%88%EB%AC%B4%20%EB%B0%94%EB%B9%A0%EC%84%9C%20%EB%AA%BB%20%EB%8F%84%EC%99%80%20%EC%A4%80%EB%8C%80.)
^ko-Q0436-answer

**ko-Q0437** — 벌써 저녁이네. 피곤해서 글쓰기는 그만 끝내야겠다. 잘자!

It's already evening, I'm tired and have to finish writing. Good night!

Why: Restriction 만. [[Korean#^ko-Q0437|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%B2%8C%EC%8D%A8%20%EC%A0%80%EB%85%81%EC%9D%B4%EB%84%A4.%20%ED%94%BC%EA%B3%A4%ED%95%B4%EC%84%9C%20%EA%B8%80%EC%93%B0%EA%B8%B0%EB%8A%94%20%EA%B7%B8%EB%A7%8C%20%EB%81%9D%EB%82%B4%EC%95%BC%EA%B2%A0%EB%8B%A4.%20%EC%9E%98%EC%9E%90%21)
^ko-Q0437-answer

**ko-Q0438** — 벌써 저녁이네. 피곤해서 글쓰기는 그만 끝내야겠다. 잘자!

It's already evening, I'm tired and have to finish writing. Good night!

만 restricts a phrase to only. It can combine with case particles. Restriction and inclusion change the statement’s meaning even when both alternatives are grammatical.

Why: Restriction 만. [[Korean#^ko-Q0438|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%B2%8C%EC%8D%A8%20%EC%A0%80%EB%85%81%EC%9D%B4%EB%84%A4.%20%ED%94%BC%EA%B3%A4%ED%95%B4%EC%84%9C%20%EA%B8%80%EC%93%B0%EA%B8%B0%EB%8A%94%20%EA%B7%B8%EB%A7%8C%20%EB%81%9D%EB%82%B4%EC%95%BC%EA%B2%A0%EB%8B%A4.%20%EC%9E%98%EC%9E%90%21)
^ko-Q0438-answer

**ko-Q0439** — 걔 좀 그만 마시게 해.

Don't let her drink any more.

Expected form: **그만**

Why: Restriction 만. [[Korean#^ko-Q0439|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B1%94%20%EC%A2%80%20%EA%B7%B8%EB%A7%8C%20%EB%A7%88%EC%8B%9C%EA%B2%8C%20%ED%95%B4.)
^ko-Q0439-answer

**ko-Q0440** — 걔 좀 그만 마시게 해.

Don't let her drink any more.

Expected form: **그만**

Why: Restriction 만. [[Korean#^ko-Q0440|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B1%94%20%EC%A2%80%20%EA%B7%B8%EB%A7%8C%20%EB%A7%88%EC%8B%9C%EA%B2%8C%20%ED%95%B4.)
^ko-Q0440-answer

**ko-Q0441** — 그녀는 그를 비웃었을 뿐만 아니라 그를 미치게 했다

She not only ridiculed him, but also drove him out.

Expected form: **뿐만**

Why: Restriction 만. [[Korean#^ko-Q0441|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EB%85%80%EB%8A%94%20%EA%B7%B8%EB%A5%BC%20%EB%B9%84%EC%9B%83%EC%97%88%EC%9D%84%20%EB%BF%90%EB%A7%8C%20%EC%95%84%EB%8B%88%EB%9D%BC%20%EA%B7%B8%EB%A5%BC%20%EB%AF%B8%EC%B9%98%EA%B2%8C%20%ED%96%88%EB%8B%A4)
^ko-Q0441-answer

**ko-Q0442** — 그녀는 그를 비웃었을 뿐만 아니라 그를 미치게 했다

She not only ridiculed him, but also drove him out.

Why: Restriction 만. [[Korean#^ko-Q0442|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EB%85%80%EB%8A%94%20%EA%B7%B8%EB%A5%BC%20%EB%B9%84%EC%9B%83%EC%97%88%EC%9D%84%20%EB%BF%90%EB%A7%8C%20%EC%95%84%EB%8B%88%EB%9D%BC%20%EA%B7%B8%EB%A5%BC%20%EB%AF%B8%EC%B9%98%EA%B2%8C%20%ED%96%88%EB%8B%A4)
^ko-Q0442-answer

**ko-Q0443** — 민주주의의 좋은 점은 바로 이렇다: 누구나 그들의 단편적인 생각을 말할 수 있지만 누구도 거기에 귀를 기울일 필요는 없다는 것이다

The good things about democracy is: anybody can say what's on their mind, but nobody has to listen to it.

Why: Restriction 만. [[Korean#^ko-Q0443|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%AF%BC%EC%A3%BC%EC%A3%BC%EC%9D%98%EC%9D%98%20%EC%A2%8B%EC%9D%80%20%EC%A0%90%EC%9D%80%20%EB%B0%94%EB%A1%9C%20%EC%9D%B4%EB%A0%87%EB%8B%A4%3A%20%EB%88%84%EA%B5%AC%EB%82%98%20%EA%B7%B8%EB%93%A4%EC%9D%98%20%EB%8B%A8%ED%8E%B8%EC%A0%81%EC%9D%B8%20%EC%83%9D%EA%B0%81%EC%9D%84%20%EB%A7%90%ED%95%A0%20%EC%88%98%20%EC%9E%88%EC%A7%80%EB%A7%8C%20%EB%88%84%EA%B5%AC%EB%8F%84%20%EA%B1%B0%EA%B8%B0%EC%97%90%20%EA%B7%80%EB%A5%BC%20%EA%B8%B0%EC%9A%B8%EC%9D%BC%20%ED%95%84%EC%9A%94%EB%8A%94%20%EC%97%86%EB%8B%A4%EB%8A%94%20%EA%B2%83%EC%9D%B4%EB%8B%A4)
^ko-Q0443-answer

**ko-Q0444** — 민주주의의 좋은 점은 바로 이렇다: 누구나 그들의 단편적인 생각을 말할 수 있지만 누구도 거기에 귀를 기울일 필요는 없다는 것이다

The good things about democracy is: anybody can say what's on their mind, but nobody has to listen to it.

만 restricts a phrase to only. It can combine with case particles. Restriction and inclusion change the statement’s meaning even when both alternatives are grammatical.

Why: Restriction 만. [[Korean#^ko-Q0444|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%AF%BC%EC%A3%BC%EC%A3%BC%EC%9D%98%EC%9D%98%20%EC%A2%8B%EC%9D%80%20%EC%A0%90%EC%9D%80%20%EB%B0%94%EB%A1%9C%20%EC%9D%B4%EB%A0%87%EB%8B%A4%3A%20%EB%88%84%EA%B5%AC%EB%82%98%20%EA%B7%B8%EB%93%A4%EC%9D%98%20%EB%8B%A8%ED%8E%B8%EC%A0%81%EC%9D%B8%20%EC%83%9D%EA%B0%81%EC%9D%84%20%EB%A7%90%ED%95%A0%20%EC%88%98%20%EC%9E%88%EC%A7%80%EB%A7%8C%20%EB%88%84%EA%B5%AC%EB%8F%84%20%EA%B1%B0%EA%B8%B0%EC%97%90%20%EA%B7%80%EB%A5%BC%20%EA%B8%B0%EC%9A%B8%EC%9D%BC%20%ED%95%84%EC%9A%94%EB%8A%94%20%EC%97%86%EB%8B%A4%EB%8A%94%20%EA%B2%83%EC%9D%B4%EB%8B%A4)
^ko-Q0444-answer

**ko-Q0445** — 그는 키가 작지만 세다.

He is short but strong.

Expected form: **작지만**

Why: Restriction 만. [[Korean#^ko-Q0445|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EB%8A%94%20%ED%82%A4%EA%B0%80%20%EC%9E%91%EC%A7%80%EB%A7%8C%20%EC%84%B8%EB%8B%A4.)
^ko-Q0445-answer

**ko-Q0446** — 그는 키가 작지만 세다.

He is short but strong.

Expected form: **작지만**

Why: Restriction 만. [[Korean#^ko-Q0446|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EB%8A%94%20%ED%82%A4%EA%B0%80%20%EC%9E%91%EC%A7%80%EB%A7%8C%20%EC%84%B8%EB%8B%A4.)
^ko-Q0446-answer

**ko-Q0447** — 톰은 때때로 같이 운동하자고 졸라댔지만 나는 정말 운동에 관심이 없다.

Tom occasionally prods me to work out with him, but I'm really not interested.

Expected form: **졸라댔지만**

Why: Restriction 만. [[Korean#^ko-Q0447|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EB%95%8C%EB%95%8C%EB%A1%9C%20%EA%B0%99%EC%9D%B4%20%EC%9A%B4%EB%8F%99%ED%95%98%EC%9E%90%EA%B3%A0%20%EC%A1%B8%EB%9D%BC%EB%8C%94%EC%A7%80%EB%A7%8C%20%EB%82%98%EB%8A%94%20%EC%A0%95%EB%A7%90%20%EC%9A%B4%EB%8F%99%EC%97%90%20%EA%B4%80%EC%8B%AC%EC%9D%B4%20%EC%97%86%EB%8B%A4.)
^ko-Q0447-answer

**ko-Q0448** — 톰은 때때로 같이 운동하자고 졸라댔지만 나는 정말 운동에 관심이 없다.

Tom occasionally prods me to work out with him, but I'm really not interested.

Why: Restriction 만. [[Korean#^ko-Q0448|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EB%95%8C%EB%95%8C%EB%A1%9C%20%EA%B0%99%EC%9D%B4%20%EC%9A%B4%EB%8F%99%ED%95%98%EC%9E%90%EA%B3%A0%20%EC%A1%B8%EB%9D%BC%EB%8C%94%EC%A7%80%EB%A7%8C%20%EB%82%98%EB%8A%94%20%EC%A0%95%EB%A7%90%20%EC%9A%B4%EB%8F%99%EC%97%90%20%EA%B4%80%EC%8B%AC%EC%9D%B4%20%EC%97%86%EB%8B%A4.)
^ko-Q0448-answer

**ko-Q0449** — 내 사생활 좀 그만 캐물어.

Don't pry into my private life.

Why: Restriction 만. [[Korean#^ko-Q0449|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%B4%20%EC%82%AC%EC%83%9D%ED%99%9C%20%EC%A2%80%20%EA%B7%B8%EB%A7%8C%20%EC%BA%90%EB%AC%BC%EC%96%B4.)
^ko-Q0449-answer

**ko-Q0450** — 내 사생활 좀 그만 캐물어.

Don't pry into my private life.

만 restricts a phrase to only. It can combine with case particles. Restriction and inclusion change the statement’s meaning even when both alternatives are grammatical.

Why: Restriction 만. [[Korean#^ko-Q0450|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%B4%20%EC%82%AC%EC%83%9D%ED%99%9C%20%EC%A2%80%20%EA%B7%B8%EB%A7%8C%20%EC%BA%90%EB%AC%BC%EC%96%B4.)
^ko-Q0450-answer


### Answers 451–500

**ko-Q0451** — 오늘은 6월 18일, Muiriel의 생일입니다!

Today is June 18th and it is Muiriel's birthday!

Expected form: **생일입니다**

Why: Formal polite endings. [[Korean#^ko-Q0451|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%98%A4%EB%8A%98%EC%9D%80%206%EC%9B%94%2018%EC%9D%BC%2C%20Muiriel%EC%9D%98%20%EC%83%9D%EC%9D%BC%EC%9E%85%EB%8B%88%EB%8B%A4%21)
^ko-Q0451-answer

**ko-Q0452** — 오늘은 6월 18일, Muiriel의 생일입니다!

Today is June 18th and it is Muiriel's birthday!

Expected form: **생일입니다**

Why: Formal polite endings. [[Korean#^ko-Q0452|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%98%A4%EB%8A%98%EC%9D%80%206%EC%9B%94%2018%EC%9D%BC%2C%20Muiriel%EC%9D%98%20%EC%83%9D%EC%9D%BC%EC%9E%85%EB%8B%88%EB%8B%A4%21)
^ko-Q0452-answer

**ko-Q0453** — Muiriel은 지금 20살입니다.

Muiriel is 20 now.

Expected form: **살입니다**

Why: Formal polite endings. [[Korean#^ko-Q0453|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=Muiriel%EC%9D%80%20%EC%A7%80%EA%B8%88%2020%EC%82%B4%EC%9E%85%EB%8B%88%EB%8B%A4.)
^ko-Q0453-answer

**ko-Q0454** — Muiriel은 지금 20살입니다.

Muiriel is 20 now.

Why: Formal polite endings. [[Korean#^ko-Q0454|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=Muiriel%EC%9D%80%20%EC%A7%80%EA%B8%88%2020%EC%82%B4%EC%9E%85%EB%8B%88%EB%8B%A4.)
^ko-Q0454-answer

**ko-Q0455** — 아이들은 들어올 수 없습니다.

Children are not allowed in.

Why: Formal polite endings. [[Korean#^ko-Q0455|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%95%84%EC%9D%B4%EB%93%A4%EC%9D%80%20%EB%93%A4%EC%96%B4%EC%98%AC%20%EC%88%98%20%EC%97%86%EC%8A%B5%EB%8B%88%EB%8B%A4.)
^ko-Q0455-answer

**ko-Q0456** — 아이들은 들어올 수 없습니다.

Children are not allowed in.

Formal polite endings serve statements and questions with related forms. The stem’s shape and predicate type determine the ending. Formal style is not the only polite style.

Why: Formal polite endings. [[Korean#^ko-Q0456|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%95%84%EC%9D%B4%EB%93%A4%EC%9D%80%20%EB%93%A4%EC%96%B4%EC%98%AC%20%EC%88%98%20%EC%97%86%EC%8A%B5%EB%8B%88%EB%8B%A4.)
^ko-Q0456-answer

**ko-Q0457** — 작고 흰 토끼는 "무슨 일 있니?" 라고 물어봤습니다.

"What's the matter?" asked the little white rabbit.

Expected form: **물어봤습니다**

Why: Formal polite endings. [[Korean#^ko-Q0457|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9E%91%EA%B3%A0%20%ED%9D%B0%20%ED%86%A0%EB%81%BC%EB%8A%94%20%22%EB%AC%B4%EC%8A%A8%20%EC%9D%BC%20%EC%9E%88%EB%8B%88%3F%22%20%EB%9D%BC%EA%B3%A0%20%EB%AC%BC%EC%96%B4%EB%B4%A4%EC%8A%B5%EB%8B%88%EB%8B%A4.)
^ko-Q0457-answer

**ko-Q0458** — 작고 흰 토끼는 "무슨 일 있니?" 라고 물어봤습니다.

"What's the matter?" asked the little white rabbit.

Expected form: **물어봤습니다**

Why: Formal polite endings. [[Korean#^ko-Q0458|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9E%91%EA%B3%A0%20%ED%9D%B0%20%ED%86%A0%EB%81%BC%EB%8A%94%20%22%EB%AC%B4%EC%8A%A8%20%EC%9D%BC%20%EC%9E%88%EB%8B%88%3F%22%20%EB%9D%BC%EA%B3%A0%20%EB%AC%BC%EC%96%B4%EB%B4%A4%EC%8A%B5%EB%8B%88%EB%8B%A4.)
^ko-Q0458-answer

**ko-Q0459** — 요즘 딸기가 제철입니다.

Strawberries are in season now.

Expected form: **제철입니다**

Why: Formal polite endings. [[Korean#^ko-Q0459|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9A%94%EC%A6%98%20%EB%94%B8%EA%B8%B0%EA%B0%80%20%EC%A0%9C%EC%B2%A0%EC%9E%85%EB%8B%88%EB%8B%A4.)
^ko-Q0459-answer

**ko-Q0460** — 요즘 딸기가 제철입니다.

Strawberries are in season now.

Why: Formal polite endings. [[Korean#^ko-Q0460|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9A%94%EC%A6%98%20%EB%94%B8%EA%B8%B0%EA%B0%80%20%EC%A0%9C%EC%B2%A0%EC%9E%85%EB%8B%88%EB%8B%A4.)
^ko-Q0460-answer

**ko-Q0461** — 주장을 증명할 수 있습니까?

Can you prove the allegations?

Why: Formal polite endings. [[Korean#^ko-Q0461|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A3%BC%EC%9E%A5%EC%9D%84%20%EC%A6%9D%EB%AA%85%ED%95%A0%20%EC%88%98%20%EC%9E%88%EC%8A%B5%EB%8B%88%EA%B9%8C%3F)
^ko-Q0461-answer

**ko-Q0462** — 주장을 증명할 수 있습니까?

Can you prove the allegations?

Formal polite endings serve statements and questions with related forms. The stem’s shape and predicate type determine the ending. Formal style is not the only polite style.

Why: Formal polite endings. [[Korean#^ko-Q0462|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A3%BC%EC%9E%A5%EC%9D%84%20%EC%A6%9D%EB%AA%85%ED%95%A0%20%EC%88%98%20%EC%9E%88%EC%8A%B5%EB%8B%88%EA%B9%8C%3F)
^ko-Q0462-answer

**ko-Q0463** — 이탈리아는 아주 아름다운 나라입니다.

Italy is a very beautiful country.

Expected form: **나라입니다**

Why: Formal polite endings. [[Korean#^ko-Q0463|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9D%B4%ED%83%88%EB%A6%AC%EC%95%84%EB%8A%94%20%EC%95%84%EC%A3%BC%20%EC%95%84%EB%A6%84%EB%8B%A4%EC%9A%B4%20%EB%82%98%EB%9D%BC%EC%9E%85%EB%8B%88%EB%8B%A4.)
^ko-Q0463-answer

**ko-Q0464** — 이탈리아는 아주 아름다운 나라입니다.

Italy is a very beautiful country.

Expected form: **나라입니다**

Why: Formal polite endings. [[Korean#^ko-Q0464|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9D%B4%ED%83%88%EB%A6%AC%EC%95%84%EB%8A%94%20%EC%95%84%EC%A3%BC%20%EC%95%84%EB%A6%84%EB%8B%A4%EC%9A%B4%20%EB%82%98%EB%9D%BC%EC%9E%85%EB%8B%88%EB%8B%A4.)
^ko-Q0464-answer

**ko-Q0465** — 저는 그리스 사람입니다.

I'm from Greece.

Expected form: **사람입니다**

Why: Formal polite endings. [[Korean#^ko-Q0465|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A0%80%EB%8A%94%20%EA%B7%B8%EB%A6%AC%EC%8A%A4%20%EC%82%AC%EB%9E%8C%EC%9E%85%EB%8B%88%EB%8B%A4.)
^ko-Q0465-answer

**ko-Q0466** — 저는 그리스 사람입니다.

I'm from Greece.

Why: Formal polite endings. [[Korean#^ko-Q0466|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A0%80%EB%8A%94%20%EA%B7%B8%EB%A6%AC%EC%8A%A4%20%EC%82%AC%EB%9E%8C%EC%9E%85%EB%8B%88%EB%8B%A4.)
^ko-Q0466-answer

**ko-Q0467** — 내가 모르는 의미를 가진 단어가 많이 있습니다.

There are many words with meanings I don't know.

Why: Formal polite endings. [[Korean#^ko-Q0467|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%B4%EA%B0%80%20%EB%AA%A8%EB%A5%B4%EB%8A%94%20%EC%9D%98%EB%AF%B8%EB%A5%BC%20%EA%B0%80%EC%A7%84%20%EB%8B%A8%EC%96%B4%EA%B0%80%20%EB%A7%8E%EC%9D%B4%20%EC%9E%88%EC%8A%B5%EB%8B%88%EB%8B%A4.)
^ko-Q0467-answer

**ko-Q0468** — 내가 모르는 의미를 가진 단어가 많이 있습니다.

There are many words with meanings I don't know.

Formal polite endings serve statements and questions with related forms. The stem’s shape and predicate type determine the ending. Formal style is not the only polite style.

Why: Formal polite endings. [[Korean#^ko-Q0468|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%B4%EA%B0%80%20%EB%AA%A8%EB%A5%B4%EB%8A%94%20%EC%9D%98%EB%AF%B8%EB%A5%BC%20%EA%B0%80%EC%A7%84%20%EB%8B%A8%EC%96%B4%EA%B0%80%20%EB%A7%8E%EC%9D%B4%20%EC%9E%88%EC%8A%B5%EB%8B%88%EB%8B%A4.)
^ko-Q0468-answer

**ko-Q0469** — 한국어를 1년 째 공부하고 있습니다.

I have been studying Korean for 1 year.

Expected form: **있습니다**

Why: Formal polite endings. [[Korean#^ko-Q0469|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%95%9C%EA%B5%AD%EC%96%B4%EB%A5%BC%201%EB%85%84%20%EC%A7%B8%20%EA%B3%B5%EB%B6%80%ED%95%98%EA%B3%A0%20%EC%9E%88%EC%8A%B5%EB%8B%88%EB%8B%A4.)
^ko-Q0469-answer

**ko-Q0470** — 한국어를 1년 째 공부하고 있습니다.

I have been studying Korean for 1 year.

Expected form: **있습니다**

Why: Formal polite endings. [[Korean#^ko-Q0470|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%95%9C%EA%B5%AD%EC%96%B4%EB%A5%BC%201%EB%85%84%20%EC%A7%B8%20%EA%B3%B5%EB%B6%80%ED%95%98%EA%B3%A0%20%EC%9E%88%EC%8A%B5%EB%8B%88%EB%8B%A4.)
^ko-Q0470-answer

**ko-Q0471** — 제꿈은 작가가 되는 것입니다.

My goal in life is to be a novelist.

Expected form: **것입니다**

Why: Formal polite endings. [[Korean#^ko-Q0471|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A0%9C%EA%BF%88%EC%9D%80%20%EC%9E%91%EA%B0%80%EA%B0%80%20%EB%90%98%EB%8A%94%20%EA%B2%83%EC%9E%85%EB%8B%88%EB%8B%A4.)
^ko-Q0471-answer

**ko-Q0472** — 제꿈은 작가가 되는 것입니다.

My goal in life is to be a novelist.

Why: Formal polite endings. [[Korean#^ko-Q0472|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A0%9C%EA%BF%88%EC%9D%80%20%EC%9E%91%EA%B0%80%EA%B0%80%20%EB%90%98%EB%8A%94%20%EA%B2%83%EC%9E%85%EB%8B%88%EB%8B%A4.)
^ko-Q0472-answer

**ko-Q0473** — 저는 내일 오전 6시에 체크아웃 하겠습니다.

I want to check out at 6 tomorrow morning.

Why: Formal polite endings. [[Korean#^ko-Q0473|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A0%80%EB%8A%94%20%EB%82%B4%EC%9D%BC%20%EC%98%A4%EC%A0%84%206%EC%8B%9C%EC%97%90%20%EC%B2%B4%ED%81%AC%EC%95%84%EC%9B%83%20%ED%95%98%EA%B2%A0%EC%8A%B5%EB%8B%88%EB%8B%A4.)
^ko-Q0473-answer

**ko-Q0474** — 저는 내일 오전 6시에 체크아웃 하겠습니다.

I want to check out at 6 tomorrow morning.

Formal polite endings serve statements and questions with related forms. The stem’s shape and predicate type determine the ending. Formal style is not the only polite style.

Why: Formal polite endings. [[Korean#^ko-Q0474|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A0%80%EB%8A%94%20%EB%82%B4%EC%9D%BC%20%EC%98%A4%EC%A0%84%206%EC%8B%9C%EC%97%90%20%EC%B2%B4%ED%81%AC%EC%95%84%EC%9B%83%20%ED%95%98%EA%B2%A0%EC%8A%B5%EB%8B%88%EB%8B%A4.)
^ko-Q0474-answer

**ko-Q0475** — 내주 금요일 오전 내내 시간이 있습니다.

I will be free all morning next Friday.

Expected form: **있습니다**

Why: Formal polite endings. [[Korean#^ko-Q0475|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%B4%EC%A3%BC%20%EA%B8%88%EC%9A%94%EC%9D%BC%20%EC%98%A4%EC%A0%84%20%EB%82%B4%EB%82%B4%20%EC%8B%9C%EA%B0%84%EC%9D%B4%20%EC%9E%88%EC%8A%B5%EB%8B%88%EB%8B%A4.)
^ko-Q0475-answer

**ko-Q0476** — 내주 금요일 오전 내내 시간이 있습니다.

I will be free all morning next Friday.

Expected form: **있습니다**

Why: Formal polite endings. [[Korean#^ko-Q0476|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%B4%EC%A3%BC%20%EA%B8%88%EC%9A%94%EC%9D%BC%20%EC%98%A4%EC%A0%84%20%EB%82%B4%EB%82%B4%20%EC%8B%9C%EA%B0%84%EC%9D%B4%20%EC%9E%88%EC%8A%B5%EB%8B%88%EB%8B%A4.)
^ko-Q0476-answer

**ko-Q0477** — 작년 여름에 몇 번이나 수영을 하러 갔었습니까?

How often did you go swimming last summer?

Expected form: **갔었습니까**

Why: Formal polite endings. [[Korean#^ko-Q0477|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9E%91%EB%85%84%20%EC%97%AC%EB%A6%84%EC%97%90%20%EB%AA%87%20%EB%B2%88%EC%9D%B4%EB%82%98%20%EC%88%98%EC%98%81%EC%9D%84%20%ED%95%98%EB%9F%AC%20%EA%B0%94%EC%97%88%EC%8A%B5%EB%8B%88%EA%B9%8C%3F)
^ko-Q0477-answer

**ko-Q0478** — 작년 여름에 몇 번이나 수영을 하러 갔었습니까?

How often did you go swimming last summer?

Why: Formal polite endings. [[Korean#^ko-Q0478|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9E%91%EB%85%84%20%EC%97%AC%EB%A6%84%EC%97%90%20%EB%AA%87%20%EB%B2%88%EC%9D%B4%EB%82%98%20%EC%88%98%EC%98%81%EC%9D%84%20%ED%95%98%EB%9F%AC%20%EA%B0%94%EC%97%88%EC%8A%B5%EB%8B%88%EA%B9%8C%3F)
^ko-Q0478-answer

**ko-Q0479** — 우리는 자연스럽게 들리는 번역문을 원하며, 단어 대 단어로 직역한 번역문을 원하지 않습니다.

We want natural-sounding translations, not word-for-word direct translations.

Why: Formal polite endings. [[Korean#^ko-Q0479|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9A%B0%EB%A6%AC%EB%8A%94%20%EC%9E%90%EC%97%B0%EC%8A%A4%EB%9F%BD%EA%B2%8C%20%EB%93%A4%EB%A6%AC%EB%8A%94%20%EB%B2%88%EC%97%AD%EB%AC%B8%EC%9D%84%20%EC%9B%90%ED%95%98%EB%A9%B0%2C%20%EB%8B%A8%EC%96%B4%20%EB%8C%80%20%EB%8B%A8%EC%96%B4%EB%A1%9C%20%EC%A7%81%EC%97%AD%ED%95%9C%20%EB%B2%88%EC%97%AD%EB%AC%B8%EC%9D%84%20%EC%9B%90%ED%95%98%EC%A7%80%20%EC%95%8A%EC%8A%B5%EB%8B%88%EB%8B%A4.)
^ko-Q0479-answer

**ko-Q0480** — 우리는 자연스럽게 들리는 번역문을 원하며, 단어 대 단어로 직역한 번역문을 원하지 않습니다.

We want natural-sounding translations, not word-for-word direct translations.

Formal polite endings serve statements and questions with related forms. The stem’s shape and predicate type determine the ending. Formal style is not the only polite style.

Why: Formal polite endings. [[Korean#^ko-Q0480|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9A%B0%EB%A6%AC%EB%8A%94%20%EC%9E%90%EC%97%B0%EC%8A%A4%EB%9F%BD%EA%B2%8C%20%EB%93%A4%EB%A6%AC%EB%8A%94%20%EB%B2%88%EC%97%AD%EB%AC%B8%EC%9D%84%20%EC%9B%90%ED%95%98%EB%A9%B0%2C%20%EB%8B%A8%EC%96%B4%20%EB%8C%80%20%EB%8B%A8%EC%96%B4%EB%A1%9C%20%EC%A7%81%EC%97%AD%ED%95%9C%20%EB%B2%88%EC%97%AD%EB%AC%B8%EC%9D%84%20%EC%9B%90%ED%95%98%EC%A7%80%20%EC%95%8A%EC%8A%B5%EB%8B%88%EB%8B%A4.)
^ko-Q0480-answer

**ko-Q0481** — 이곳은 눈이 거의 내리지 않습니다.

It rarely snows here.

Expected form: **않습니다**

Why: Formal polite endings. [[Korean#^ko-Q0481|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9D%B4%EA%B3%B3%EC%9D%80%20%EB%88%88%EC%9D%B4%20%EA%B1%B0%EC%9D%98%20%EB%82%B4%EB%A6%AC%EC%A7%80%20%EC%95%8A%EC%8A%B5%EB%8B%88%EB%8B%A4.)
^ko-Q0481-answer

**ko-Q0482** — 이곳은 눈이 거의 내리지 않습니다.

It rarely snows here.

Expected form: **않습니다**

Why: Formal polite endings. [[Korean#^ko-Q0482|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9D%B4%EA%B3%B3%EC%9D%80%20%EB%88%88%EC%9D%B4%20%EA%B1%B0%EC%9D%98%20%EB%82%B4%EB%A6%AC%EC%A7%80%20%EC%95%8A%EC%8A%B5%EB%8B%88%EB%8B%A4.)
^ko-Q0482-answer

**ko-Q0483** — 수건 좀 주시겠습니까?

Can you pass me the towel?

Expected form: **주시겠습니까**

Why: Formal polite endings. [[Korean#^ko-Q0483|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%88%98%EA%B1%B4%20%EC%A2%80%20%EC%A3%BC%EC%8B%9C%EA%B2%A0%EC%8A%B5%EB%8B%88%EA%B9%8C%3F)
^ko-Q0483-answer

**ko-Q0484** — 수건 좀 주시겠습니까?

Can you pass me the towel?

Why: Formal polite endings. [[Korean#^ko-Q0484|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%88%98%EA%B1%B4%20%EC%A2%80%20%EC%A3%BC%EC%8B%9C%EA%B2%A0%EC%8A%B5%EB%8B%88%EA%B9%8C%3F)
^ko-Q0484-answer

**ko-Q0485** — 내가 7시경에 오면 되겠습니까?

Would it suffice if I came around 7?

Why: Formal polite endings. [[Korean#^ko-Q0485|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%B4%EA%B0%80%207%EC%8B%9C%EA%B2%BD%EC%97%90%20%EC%98%A4%EB%A9%B4%20%EB%90%98%EA%B2%A0%EC%8A%B5%EB%8B%88%EA%B9%8C%3F)
^ko-Q0485-answer

**ko-Q0486** — 내가 7시경에 오면 되겠습니까?

Would it suffice if I came around 7?

Formal polite endings serve statements and questions with related forms. The stem’s shape and predicate type determine the ending. Formal style is not the only polite style.

Why: Formal polite endings. [[Korean#^ko-Q0486|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%B4%EA%B0%80%207%EC%8B%9C%EA%B2%BD%EC%97%90%20%EC%98%A4%EB%A9%B4%20%EB%90%98%EA%B2%A0%EC%8A%B5%EB%8B%88%EA%B9%8C%3F)
^ko-Q0486-answer

**ko-Q0487** — 독서는 제 취미 중 하나입니다.

Reading is one of my hobbies.

Expected form: **하나입니다**

Why: Formal polite endings. [[Korean#^ko-Q0487|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%8F%85%EC%84%9C%EB%8A%94%20%EC%A0%9C%20%EC%B7%A8%EB%AF%B8%20%EC%A4%91%20%ED%95%98%EB%82%98%EC%9E%85%EB%8B%88%EB%8B%A4.)
^ko-Q0487-answer

**ko-Q0488** — 독서는 제 취미 중 하나입니다.

Reading is one of my hobbies.

Expected form: **하나입니다**

Why: Formal polite endings. [[Korean#^ko-Q0488|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%8F%85%EC%84%9C%EB%8A%94%20%EC%A0%9C%20%EC%B7%A8%EB%AF%B8%20%EC%A4%91%20%ED%95%98%EB%82%98%EC%9E%85%EB%8B%88%EB%8B%A4.)
^ko-Q0488-answer

**ko-Q0489** — 전 많은 꿈을했습니다.

I have a lot of dreams.

Expected form: **꿈을했습니다**

Why: Formal polite endings. [[Korean#^ko-Q0489|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A0%84%20%EB%A7%8E%EC%9D%80%20%EA%BF%88%EC%9D%84%ED%96%88%EC%8A%B5%EB%8B%88%EB%8B%A4.)
^ko-Q0489-answer

**ko-Q0490** — 전 많은 꿈을했습니다.

I have a lot of dreams.

Why: Formal polite endings. [[Korean#^ko-Q0490|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A0%84%20%EB%A7%8E%EC%9D%80%20%EA%BF%88%EC%9D%84%ED%96%88%EC%8A%B5%EB%8B%88%EB%8B%A4.)
^ko-Q0490-answer

**ko-Q0491** — 그것은 배우기 어렵습니다.

It's hard to learn.

Why: Formal polite endings. [[Korean#^ko-Q0491|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EA%B2%83%EC%9D%80%20%EB%B0%B0%EC%9A%B0%EA%B8%B0%20%EC%96%B4%EB%A0%B5%EC%8A%B5%EB%8B%88%EB%8B%A4.)
^ko-Q0491-answer

**ko-Q0492** — 그것은 배우기 어렵습니다.

It's hard to learn.

Formal polite endings serve statements and questions with related forms. The stem’s shape and predicate type determine the ending. Formal style is not the only polite style.

Why: Formal polite endings. [[Korean#^ko-Q0492|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EA%B2%83%EC%9D%80%20%EB%B0%B0%EC%9A%B0%EA%B8%B0%20%EC%96%B4%EB%A0%B5%EC%8A%B5%EB%8B%88%EB%8B%A4.)
^ko-Q0492-answer

**ko-Q0493** — 그는 유엔 대사 였습니다.

He was ambassador to the United Nations.

Expected form: **였습니다**

Why: Formal polite endings. [[Korean#^ko-Q0493|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EB%8A%94%20%EC%9C%A0%EC%97%94%20%EB%8C%80%EC%82%AC%20%EC%98%80%EC%8A%B5%EB%8B%88%EB%8B%A4.)
^ko-Q0493-answer

**ko-Q0494** — 그는 유엔 대사 였습니다.

He was ambassador to the United Nations.

Expected form: **였습니다**

Why: Formal polite endings. [[Korean#^ko-Q0494|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EB%8A%94%20%EC%9C%A0%EC%97%94%20%EB%8C%80%EC%82%AC%20%EC%98%80%EC%8A%B5%EB%8B%88%EB%8B%A4.)
^ko-Q0494-answer

**ko-Q0495** — 봄에 피는 꽃은 여러 가지가 있습니다.

In spring, there are various blooming flowers.

Expected form: **있습니다**

Why: Formal polite endings. [[Korean#^ko-Q0495|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%B4%84%EC%97%90%20%ED%94%BC%EB%8A%94%20%EA%BD%83%EC%9D%80%20%EC%97%AC%EB%9F%AC%20%EA%B0%80%EC%A7%80%EA%B0%80%20%EC%9E%88%EC%8A%B5%EB%8B%88%EB%8B%A4.)
^ko-Q0495-answer

**ko-Q0496** — 봄에 피는 꽃은 여러 가지가 있습니다.

In spring, there are various blooming flowers.

Why: Formal polite endings. [[Korean#^ko-Q0496|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%B4%84%EC%97%90%20%ED%94%BC%EB%8A%94%20%EA%BD%83%EC%9D%80%20%EC%97%AC%EB%9F%AC%20%EA%B0%80%EC%A7%80%EA%B0%80%20%EC%9E%88%EC%8A%B5%EB%8B%88%EB%8B%A4.)
^ko-Q0496-answer

**ko-Q0497** — 그쪽의 지시를 기다리는 중이었습니다.

We've been waiting for your instructions.

Why: Formal polite endings. [[Korean#^ko-Q0497|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EC%AA%BD%EC%9D%98%20%EC%A7%80%EC%8B%9C%EB%A5%BC%20%EA%B8%B0%EB%8B%A4%EB%A6%AC%EB%8A%94%20%EC%A4%91%EC%9D%B4%EC%97%88%EC%8A%B5%EB%8B%88%EB%8B%A4.)
^ko-Q0497-answer

**ko-Q0498** — 그쪽의 지시를 기다리는 중이었습니다.

We've been waiting for your instructions.

Formal polite endings serve statements and questions with related forms. The stem’s shape and predicate type determine the ending. Formal style is not the only polite style.

Why: Formal polite endings. [[Korean#^ko-Q0498|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EC%AA%BD%EC%9D%98%20%EC%A7%80%EC%8B%9C%EB%A5%BC%20%EA%B8%B0%EB%8B%A4%EB%A6%AC%EB%8A%94%20%EC%A4%91%EC%9D%B4%EC%97%88%EC%8A%B5%EB%8B%88%EB%8B%A4.)
^ko-Q0498-answer

**ko-Q0499** — 정확한 문장을 수정하지 마십시오. 대신 당신은 자연스럽게 들리는 다른 번역문을 제출할 수 있습니다.

Don't change sentences that are correct. You can, instead, submit natural-sounding alternative translations.

Expected form: **있습니다**

Why: Formal polite endings. [[Korean#^ko-Q0499|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A0%95%ED%99%95%ED%95%9C%20%EB%AC%B8%EC%9E%A5%EC%9D%84%20%EC%88%98%EC%A0%95%ED%95%98%EC%A7%80%20%EB%A7%88%EC%8B%AD%EC%8B%9C%EC%98%A4.%20%EB%8C%80%EC%8B%A0%20%EB%8B%B9%EC%8B%A0%EC%9D%80%20%EC%9E%90%EC%97%B0%EC%8A%A4%EB%9F%BD%EA%B2%8C%20%EB%93%A4%EB%A6%AC%EB%8A%94%20%EB%8B%A4%EB%A5%B8%20%EB%B2%88%EC%97%AD%EB%AC%B8%EC%9D%84%20%EC%A0%9C%EC%B6%9C%ED%95%A0%20%EC%88%98%20%EC%9E%88%EC%8A%B5%EB%8B%88%EB%8B%A4.)
^ko-Q0499-answer

**ko-Q0500** — 정확한 문장을 수정하지 마십시오. 대신 당신은 자연스럽게 들리는 다른 번역문을 제출할 수 있습니다.

Don't change sentences that are correct. You can, instead, submit natural-sounding alternative translations.

Expected form: **있습니다**

Why: Formal polite endings. [[Korean#^ko-Q0500|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A0%95%ED%99%95%ED%95%9C%20%EB%AC%B8%EC%9E%A5%EC%9D%84%20%EC%88%98%EC%A0%95%ED%95%98%EC%A7%80%20%EB%A7%88%EC%8B%AD%EC%8B%9C%EC%98%A4.%20%EB%8C%80%EC%8B%A0%20%EB%8B%B9%EC%8B%A0%EC%9D%80%20%EC%9E%90%EC%97%B0%EC%8A%A4%EB%9F%BD%EA%B2%8C%20%EB%93%A4%EB%A6%AC%EB%8A%94%20%EB%8B%A4%EB%A5%B8%20%EB%B2%88%EC%97%AD%EB%AC%B8%EC%9D%84%20%EC%A0%9C%EC%B6%9C%ED%95%A0%20%EC%88%98%20%EC%9E%88%EC%8A%B5%EB%8B%88%EB%8B%A4.)
^ko-Q0500-answer


### Answers 501–550

**ko-Q0501** — 벌써 우리가 만난 지 4년 이에요. 시간이 참 빠른 것 같아요.

It's already been 4 years since we met. How time flies.

Expected form: **같아요**

Why: Conversational polite endings. [[Korean#^ko-Q0501|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%B2%8C%EC%8D%A8%20%EC%9A%B0%EB%A6%AC%EA%B0%80%20%EB%A7%8C%EB%82%9C%20%EC%A7%80%204%EB%85%84%20%EC%9D%B4%EC%97%90%EC%9A%94.%20%EC%8B%9C%EA%B0%84%EC%9D%B4%20%EC%B0%B8%20%EB%B9%A0%EB%A5%B8%20%EA%B2%83%20%EA%B0%99%EC%95%84%EC%9A%94.)
^ko-Q0501-answer

**ko-Q0502** — 벌써 우리가 만난 지 4년 이에요. 시간이 참 빠른 것 같아요.

It's already been 4 years since we met. How time flies.

Why: Conversational polite endings. [[Korean#^ko-Q0502|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%B2%8C%EC%8D%A8%20%EC%9A%B0%EB%A6%AC%EA%B0%80%20%EB%A7%8C%EB%82%9C%20%EC%A7%80%204%EB%85%84%20%EC%9D%B4%EC%97%90%EC%9A%94.%20%EC%8B%9C%EA%B0%84%EC%9D%B4%20%EC%B0%B8%20%EB%B9%A0%EB%A5%B8%20%EA%B2%83%20%EA%B0%99%EC%95%84%EC%9A%94.)
^ko-Q0502-answer

**ko-Q0503** — 한국어를 배우고 싶어요.

I want to learn Korean.

Why: Conversational polite endings. [[Korean#^ko-Q0503|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%95%9C%EA%B5%AD%EC%96%B4%EB%A5%BC%20%EB%B0%B0%EC%9A%B0%EA%B3%A0%20%EC%8B%B6%EC%96%B4%EC%9A%94.)
^ko-Q0503-answer

**ko-Q0504** — 한국어를 배우고 싶어요.

I want to learn Korean.

The 해요 style is polite and common in everyday conversation. Stem vowels and contractions affect -아요/-어요 selection. Copulas have their own 이에요/예요 forms.

Why: Conversational polite endings. [[Korean#^ko-Q0504|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%95%9C%EA%B5%AD%EC%96%B4%EB%A5%BC%20%EB%B0%B0%EC%9A%B0%EA%B3%A0%20%EC%8B%B6%EC%96%B4%EC%9A%94.)
^ko-Q0504-answer

**ko-Q0505** — 존이 한국 영화를 보고 싶어해요?

Does John want to see a Korean movie?

Expected form: **싶어해요**

Why: Conversational polite endings. [[Korean#^ko-Q0505|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A1%B4%EC%9D%B4%20%ED%95%9C%EA%B5%AD%20%EC%98%81%ED%99%94%EB%A5%BC%20%EB%B3%B4%EA%B3%A0%20%EC%8B%B6%EC%96%B4%ED%95%B4%EC%9A%94%3F)
^ko-Q0505-answer

**ko-Q0506** — 존이 한국 영화를 보고 싶어해요?

Does John want to see a Korean movie?

Expected form: **싶어해요**

Why: Conversational polite endings. [[Korean#^ko-Q0506|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A1%B4%EC%9D%B4%20%ED%95%9C%EA%B5%AD%20%EC%98%81%ED%99%94%EB%A5%BC%20%EB%B3%B4%EA%B3%A0%20%EC%8B%B6%EC%96%B4%ED%95%B4%EC%9A%94%3F)
^ko-Q0506-answer

**ko-Q0507** — 왜냐하면 당신은 혼자가 되고 싶지 않기 때문이에요.

It's because you don't want to be alone.

Expected form: **때문이에요**

Why: Conversational polite endings. [[Korean#^ko-Q0507|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%99%9C%EB%83%90%ED%95%98%EB%A9%B4%20%EB%8B%B9%EC%8B%A0%EC%9D%80%20%ED%98%BC%EC%9E%90%EA%B0%80%20%EB%90%98%EA%B3%A0%20%EC%8B%B6%EC%A7%80%20%EC%95%8A%EA%B8%B0%20%EB%95%8C%EB%AC%B8%EC%9D%B4%EC%97%90%EC%9A%94.)
^ko-Q0507-answer

**ko-Q0508** — 왜냐하면 당신은 혼자가 되고 싶지 않기 때문이에요.

It's because you don't want to be alone.

Why: Conversational polite endings. [[Korean#^ko-Q0508|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%99%9C%EB%83%90%ED%95%98%EB%A9%B4%20%EB%8B%B9%EC%8B%A0%EC%9D%80%20%ED%98%BC%EC%9E%90%EA%B0%80%20%EB%90%98%EA%B3%A0%20%EC%8B%B6%EC%A7%80%20%EC%95%8A%EA%B8%B0%20%EB%95%8C%EB%AC%B8%EC%9D%B4%EC%97%90%EC%9A%94.)
^ko-Q0508-answer

**ko-Q0509** — 나는 잠이 많지 않아요.

I don't sleep a lot.

Why: Conversational polite endings. [[Korean#^ko-Q0509|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%EC%9E%A0%EC%9D%B4%20%EB%A7%8E%EC%A7%80%20%EC%95%8A%EC%95%84%EC%9A%94.)
^ko-Q0509-answer

**ko-Q0510** — 나는 잠이 많지 않아요.

I don't sleep a lot.

The 해요 style is polite and common in everyday conversation. Stem vowels and contractions affect -아요/-어요 selection. Copulas have their own 이에요/예요 forms.

Why: Conversational polite endings. [[Korean#^ko-Q0510|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%EC%9E%A0%EC%9D%B4%20%EB%A7%8E%EC%A7%80%20%EC%95%8A%EC%95%84%EC%9A%94.)
^ko-Q0510-answer

**ko-Q0511** — 아마 내일 일찍 일어날 거예요.

I will probably get up early tomorrow.

Expected form: **거예요**

Why: Conversational polite endings. [[Korean#^ko-Q0511|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%95%84%EB%A7%88%20%EB%82%B4%EC%9D%BC%20%EC%9D%BC%EC%B0%8D%20%EC%9D%BC%EC%96%B4%EB%82%A0%20%EA%B1%B0%EC%98%88%EC%9A%94.)
^ko-Q0511-answer

**ko-Q0512** — 아마 내일 일찍 일어날 거예요.

I will probably get up early tomorrow.

Expected form: **거예요**

Why: Conversational polite endings. [[Korean#^ko-Q0512|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%95%84%EB%A7%88%20%EB%82%B4%EC%9D%BC%20%EC%9D%BC%EC%B0%8D%20%EC%9D%BC%EC%96%B4%EB%82%A0%20%EA%B1%B0%EC%98%88%EC%9A%94.)
^ko-Q0512-answer

**ko-Q0513** — 사람 많은 게 싫어요.

I hate it when there are a lot of people.

Expected form: **싫어요**

Why: Conversational polite endings. [[Korean#^ko-Q0513|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%82%AC%EB%9E%8C%20%EB%A7%8E%EC%9D%80%20%EA%B2%8C%20%EC%8B%AB%EC%96%B4%EC%9A%94.)
^ko-Q0513-answer

**ko-Q0514** — 사람 많은 게 싫어요.

I hate it when there are a lot of people.

Why: Conversational polite endings. [[Korean#^ko-Q0514|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%82%AC%EB%9E%8C%20%EB%A7%8E%EC%9D%80%20%EA%B2%8C%20%EC%8B%AB%EC%96%B4%EC%9A%94.)
^ko-Q0514-answer

**ko-Q0515** — 이런 일이 일어난다니 믿을 수가 없어요.

I can't believe this is happening.

Why: Conversational polite endings. [[Korean#^ko-Q0515|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9D%B4%EB%9F%B0%20%EC%9D%BC%EC%9D%B4%20%EC%9D%BC%EC%96%B4%EB%82%9C%EB%8B%A4%EB%8B%88%20%EB%AF%BF%EC%9D%84%20%EC%88%98%EA%B0%80%20%EC%97%86%EC%96%B4%EC%9A%94.)
^ko-Q0515-answer

**ko-Q0516** — 이런 일이 일어난다니 믿을 수가 없어요.

I can't believe this is happening.

The 해요 style is polite and common in everyday conversation. Stem vowels and contractions affect -아요/-어요 selection. Copulas have their own 이에요/예요 forms.

Why: Conversational polite endings. [[Korean#^ko-Q0516|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9D%B4%EB%9F%B0%20%EC%9D%BC%EC%9D%B4%20%EC%9D%BC%EC%96%B4%EB%82%9C%EB%8B%A4%EB%8B%88%20%EB%AF%BF%EC%9D%84%20%EC%88%98%EA%B0%80%20%EC%97%86%EC%96%B4%EC%9A%94.)
^ko-Q0516-answer

**ko-Q0517** — 지난 3년동안 톰을 보지 못했었어요.

I hadn't seen Tom in three years.

Expected form: **못했었어요**

Why: Conversational polite endings. [[Korean#^ko-Q0517|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A7%80%EB%82%9C%203%EB%85%84%EB%8F%99%EC%95%88%20%ED%86%B0%EC%9D%84%20%EB%B3%B4%EC%A7%80%20%EB%AA%BB%ED%96%88%EC%97%88%EC%96%B4%EC%9A%94.)
^ko-Q0517-answer

**ko-Q0518** — 지난 3년동안 톰을 보지 못했었어요.

I hadn't seen Tom in three years.

Expected form: **못했었어요**

Why: Conversational polite endings. [[Korean#^ko-Q0518|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A7%80%EB%82%9C%203%EB%85%84%EB%8F%99%EC%95%88%20%ED%86%B0%EC%9D%84%20%EB%B3%B4%EC%A7%80%20%EB%AA%BB%ED%96%88%EC%97%88%EC%96%B4%EC%9A%94.)
^ko-Q0518-answer

**ko-Q0519** — 톰은 연구 개발을 하고 있어요.

Tom works in research and development.

Expected form: **있어요**

Why: Conversational polite endings. [[Korean#^ko-Q0519|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EC%97%B0%EA%B5%AC%20%EA%B0%9C%EB%B0%9C%EC%9D%84%20%ED%95%98%EA%B3%A0%20%EC%9E%88%EC%96%B4%EC%9A%94.)
^ko-Q0519-answer

**ko-Q0520** — 톰은 연구 개발을 하고 있어요.

Tom works in research and development.

Why: Conversational polite endings. [[Korean#^ko-Q0520|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EC%97%B0%EA%B5%AC%20%EA%B0%9C%EB%B0%9C%EC%9D%84%20%ED%95%98%EA%B3%A0%20%EC%9E%88%EC%96%B4%EC%9A%94.)
^ko-Q0520-answer

**ko-Q0521** — 선생님을 만나고 싶어요.

I want to meet the teacher.

Why: Conversational polite endings. [[Korean#^ko-Q0521|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%84%A0%EC%83%9D%EB%8B%98%EC%9D%84%20%EB%A7%8C%EB%82%98%EA%B3%A0%20%EC%8B%B6%EC%96%B4%EC%9A%94.)
^ko-Q0521-answer

**ko-Q0522** — 선생님을 만나고 싶어요.

I want to meet the teacher.

The 해요 style is polite and common in everyday conversation. Stem vowels and contractions affect -아요/-어요 selection. Copulas have their own 이에요/예요 forms.

Why: Conversational polite endings. [[Korean#^ko-Q0522|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%84%A0%EC%83%9D%EB%8B%98%EC%9D%84%20%EB%A7%8C%EB%82%98%EA%B3%A0%20%EC%8B%B6%EC%96%B4%EC%9A%94.)
^ko-Q0522-answer

**ko-Q0523** — 고릴라하고 얼룩말은 어디 있어요?

Where are gorillas and zebras?

Expected form: **있어요**

Why: Conversational polite endings. [[Korean#^ko-Q0523|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B3%A0%EB%A6%B4%EB%9D%BC%ED%95%98%EA%B3%A0%20%EC%96%BC%EB%A3%A9%EB%A7%90%EC%9D%80%20%EC%96%B4%EB%94%94%20%EC%9E%88%EC%96%B4%EC%9A%94%3F)
^ko-Q0523-answer

**ko-Q0524** — 고릴라하고 얼룩말은 어디 있어요?

Where are gorillas and zebras?

Expected form: **있어요**

Why: Conversational polite endings. [[Korean#^ko-Q0524|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B3%A0%EB%A6%B4%EB%9D%BC%ED%95%98%EA%B3%A0%20%EC%96%BC%EB%A3%A9%EB%A7%90%EC%9D%80%20%EC%96%B4%EB%94%94%20%EC%9E%88%EC%96%B4%EC%9A%94%3F)
^ko-Q0524-answer

**ko-Q0525** — 전 한국 요리를 좋아해요.

I like Korean cuisine.

Expected form: **좋아해요**

Why: Conversational polite endings. [[Korean#^ko-Q0525|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A0%84%20%ED%95%9C%EA%B5%AD%20%EC%9A%94%EB%A6%AC%EB%A5%BC%20%EC%A2%8B%EC%95%84%ED%95%B4%EC%9A%94.)
^ko-Q0525-answer

**ko-Q0526** — 전 한국 요리를 좋아해요.

I like Korean cuisine.

Why: Conversational polite endings. [[Korean#^ko-Q0526|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A0%84%20%ED%95%9C%EA%B5%AD%20%EC%9A%94%EB%A6%AC%EB%A5%BC%20%EC%A2%8B%EC%95%84%ED%95%B4%EC%9A%94.)
^ko-Q0526-answer

**ko-Q0527** — 나는 많이 자지 않아요.

I don't sleep a lot.

Why: Conversational polite endings. [[Korean#^ko-Q0527|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%EB%A7%8E%EC%9D%B4%20%EC%9E%90%EC%A7%80%20%EC%95%8A%EC%95%84%EC%9A%94.)
^ko-Q0527-answer

**ko-Q0528** — 나는 많이 자지 않아요.

I don't sleep a lot.

The 해요 style is polite and common in everyday conversation. Stem vowels and contractions affect -아요/-어요 selection. Copulas have their own 이에요/예요 forms.

Why: Conversational polite endings. [[Korean#^ko-Q0528|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%EB%A7%8E%EC%9D%B4%20%EC%9E%90%EC%A7%80%20%EC%95%8A%EC%95%84%EC%9A%94.)
^ko-Q0528-answer

**ko-Q0529** — 은행 문은 닫혀 있었어요?

Was the bank closed?

Expected form: **있었어요**

Why: Conversational polite endings. [[Korean#^ko-Q0529|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9D%80%ED%96%89%20%EB%AC%B8%EC%9D%80%20%EB%8B%AB%ED%98%80%20%EC%9E%88%EC%97%88%EC%96%B4%EC%9A%94%3F)
^ko-Q0529-answer

**ko-Q0530** — 은행 문은 닫혀 있었어요?

Was the bank closed?

Expected form: **있었어요**

Why: Conversational polite endings. [[Korean#^ko-Q0530|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9D%80%ED%96%89%20%EB%AC%B8%EC%9D%80%20%EB%8B%AB%ED%98%80%20%EC%9E%88%EC%97%88%EC%96%B4%EC%9A%94%3F)
^ko-Q0530-answer

**ko-Q0531** — 직접 만드신 거예요?

Did you make it yourself?

Expected form: **거예요**

Why: Conversational polite endings. [[Korean#^ko-Q0531|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A7%81%EC%A0%91%20%EB%A7%8C%EB%93%9C%EC%8B%A0%20%EA%B1%B0%EC%98%88%EC%9A%94%3F)
^ko-Q0531-answer

**ko-Q0532** — 직접 만드신 거예요?

Did you make it yourself?

Why: Conversational polite endings. [[Korean#^ko-Q0532|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A7%81%EC%A0%91%20%EB%A7%8C%EB%93%9C%EC%8B%A0%20%EA%B1%B0%EC%98%88%EC%9A%94%3F)
^ko-Q0532-answer

**ko-Q0533** — 우리 도시에는 축구 경기장이 있어요.

There is a soccer stadium in the city where I live.

Why: Conversational polite endings. [[Korean#^ko-Q0533|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9A%B0%EB%A6%AC%20%EB%8F%84%EC%8B%9C%EC%97%90%EB%8A%94%20%EC%B6%95%EA%B5%AC%20%EA%B2%BD%EA%B8%B0%EC%9E%A5%EC%9D%B4%20%EC%9E%88%EC%96%B4%EC%9A%94.)
^ko-Q0533-answer

**ko-Q0534** — 우리 도시에는 축구 경기장이 있어요.

There is a soccer stadium in the city where I live.

The 해요 style is polite and common in everyday conversation. Stem vowels and contractions affect -아요/-어요 selection. Copulas have their own 이에요/예요 forms.

Why: Conversational polite endings. [[Korean#^ko-Q0534|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9A%B0%EB%A6%AC%20%EB%8F%84%EC%8B%9C%EC%97%90%EB%8A%94%20%EC%B6%95%EA%B5%AC%20%EA%B2%BD%EA%B8%B0%EC%9E%A5%EC%9D%B4%20%EC%9E%88%EC%96%B4%EC%9A%94.)
^ko-Q0534-answer

**ko-Q0535** — 죄송하지만, 무슨 말인지 모르겠어요.

I'm sorry, but I don't understand.

Expected form: **모르겠어요**

Why: Conversational polite endings. [[Korean#^ko-Q0535|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A3%84%EC%86%A1%ED%95%98%EC%A7%80%EB%A7%8C%2C%20%EB%AC%B4%EC%8A%A8%20%EB%A7%90%EC%9D%B8%EC%A7%80%20%EB%AA%A8%EB%A5%B4%EA%B2%A0%EC%96%B4%EC%9A%94.)
^ko-Q0535-answer

**ko-Q0536** — 죄송하지만, 무슨 말인지 모르겠어요.

I'm sorry, but I don't understand.

Expected form: **모르겠어요**

Why: Conversational polite endings. [[Korean#^ko-Q0536|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A3%84%EC%86%A1%ED%95%98%EC%A7%80%EB%A7%8C%2C%20%EB%AC%B4%EC%8A%A8%20%EB%A7%90%EC%9D%B8%EC%A7%80%20%EB%AA%A8%EB%A5%B4%EA%B2%A0%EC%96%B4%EC%9A%94.)
^ko-Q0536-answer

**ko-Q0537** — 당신은 어떻게 잤어요?

How did you sleep, dear?

Expected form: **잤어요**

Why: Conversational polite endings. [[Korean#^ko-Q0537|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%8B%B9%EC%8B%A0%EC%9D%80%20%EC%96%B4%EB%96%BB%EA%B2%8C%20%EC%9E%A4%EC%96%B4%EC%9A%94%3F)
^ko-Q0537-answer

**ko-Q0538** — 당신은 어떻게 잤어요?

How did you sleep, dear?

Why: Conversational polite endings. [[Korean#^ko-Q0538|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%8B%B9%EC%8B%A0%EC%9D%80%20%EC%96%B4%EB%96%BB%EA%B2%8C%20%EC%9E%A4%EC%96%B4%EC%9A%94%3F)
^ko-Q0538-answer

**ko-Q0539** — 언제 전화할 거예요?

When are you going to call?

Why: Conversational polite endings. [[Korean#^ko-Q0539|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%96%B8%EC%A0%9C%20%EC%A0%84%ED%99%94%ED%95%A0%20%EA%B1%B0%EC%98%88%EC%9A%94%3F)
^ko-Q0539-answer

**ko-Q0540** — 언제 전화할 거예요?

When are you going to call?

The 해요 style is polite and common in everyday conversation. Stem vowels and contractions affect -아요/-어요 selection. Copulas have their own 이에요/예요 forms.

Why: Conversational polite endings. [[Korean#^ko-Q0540|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%96%B8%EC%A0%9C%20%EC%A0%84%ED%99%94%ED%95%A0%20%EA%B1%B0%EC%98%88%EC%9A%94%3F)
^ko-Q0540-answer

**ko-Q0541** — 크리스는 운전할 차가 없었어요.

Chris didn't have a car to drive.

Expected form: **없었어요**

Why: Conversational polite endings. [[Korean#^ko-Q0541|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%81%AC%EB%A6%AC%EC%8A%A4%EB%8A%94%20%EC%9A%B4%EC%A0%84%ED%95%A0%20%EC%B0%A8%EA%B0%80%20%EC%97%86%EC%97%88%EC%96%B4%EC%9A%94.)
^ko-Q0541-answer

**ko-Q0542** — 크리스는 운전할 차가 없었어요.

Chris didn't have a car to drive.

Expected form: **없었어요**

Why: Conversational polite endings. [[Korean#^ko-Q0542|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%81%AC%EB%A6%AC%EC%8A%A4%EB%8A%94%20%EC%9A%B4%EC%A0%84%ED%95%A0%20%EC%B0%A8%EA%B0%80%20%EC%97%86%EC%97%88%EC%96%B4%EC%9A%94.)
^ko-Q0542-answer

**ko-Q0543** — 나는 그녀를 기다리고 있어요.

I'm waiting for her to come here.

Expected form: **있어요**

Why: Conversational polite endings. [[Korean#^ko-Q0543|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%EA%B7%B8%EB%85%80%EB%A5%BC%20%EA%B8%B0%EB%8B%A4%EB%A6%AC%EA%B3%A0%20%EC%9E%88%EC%96%B4%EC%9A%94.)
^ko-Q0543-answer

**ko-Q0544** — 나는 그녀를 기다리고 있어요.

I'm waiting for her to come here.

Why: Conversational polite endings. [[Korean#^ko-Q0544|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%EA%B7%B8%EB%85%80%EB%A5%BC%20%EA%B8%B0%EB%8B%A4%EB%A6%AC%EA%B3%A0%20%EC%9E%88%EC%96%B4%EC%9A%94.)
^ko-Q0544-answer

**ko-Q0545** — 그가 그것을 내게 줬어요.

He gave it to me.

Why: Conversational polite endings. [[Korean#^ko-Q0545|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EA%B0%80%20%EA%B7%B8%EA%B2%83%EC%9D%84%20%EB%82%B4%EA%B2%8C%20%EC%A4%AC%EC%96%B4%EC%9A%94.)
^ko-Q0545-answer

**ko-Q0546** — 그가 그것을 내게 줬어요.

He gave it to me.

The 해요 style is polite and common in everyday conversation. Stem vowels and contractions affect -아요/-어요 selection. Copulas have their own 이에요/예요 forms.

Why: Conversational polite endings. [[Korean#^ko-Q0546|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EA%B0%80%20%EA%B7%B8%EA%B2%83%EC%9D%84%20%EB%82%B4%EA%B2%8C%20%EC%A4%AC%EC%96%B4%EC%9A%94.)
^ko-Q0546-answer

**ko-Q0547** — 밴드는 아주 잘 연주해요.

The band plays really well.

Expected form: **연주해요**

Why: Conversational polite endings. [[Korean#^ko-Q0547|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%B0%B4%EB%93%9C%EB%8A%94%20%EC%95%84%EC%A3%BC%20%EC%9E%98%20%EC%97%B0%EC%A3%BC%ED%95%B4%EC%9A%94.)
^ko-Q0547-answer

**ko-Q0548** — 밴드는 아주 잘 연주해요.

The band plays really well.

Expected form: **연주해요**

Why: Conversational polite endings. [[Korean#^ko-Q0548|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%B0%B4%EB%93%9C%EB%8A%94%20%EC%95%84%EC%A3%BC%20%EC%9E%98%20%EC%97%B0%EC%A3%BC%ED%95%B4%EC%9A%94.)
^ko-Q0548-answer

**ko-Q0549** — 가을을 제일 좋아해요.

I like autumn most.

Expected form: **좋아해요**

Why: Conversational polite endings. [[Korean#^ko-Q0549|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B0%80%EC%9D%84%EC%9D%84%20%EC%A0%9C%EC%9D%BC%20%EC%A2%8B%EC%95%84%ED%95%B4%EC%9A%94.)
^ko-Q0549-answer

**ko-Q0550** — 가을을 제일 좋아해요.

I like autumn most.

Why: Conversational polite endings. [[Korean#^ko-Q0550|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B0%80%EC%9D%84%EC%9D%84%20%EC%A0%9C%EC%9D%BC%20%EC%A2%8B%EC%95%84%ED%95%B4%EC%9A%94.)
^ko-Q0550-answer


### Answers 551–600

**ko-Q0551** — 톰은 아직 결정하지 못했다.

Tom hasn't decided yet.

Why: Past forms. [[Korean#^ko-Q0551|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EC%95%84%EC%A7%81%20%EA%B2%B0%EC%A0%95%ED%95%98%EC%A7%80%20%EB%AA%BB%ED%96%88%EB%8B%A4.)
^ko-Q0551-answer

**ko-Q0552** — 톰은 아직 결정하지 못했다.

Tom hasn't decided yet.

Past -았/었- combines with a stem and a speech-level ending. Contractions are frequent, including 하다→했-. Retain the intended level of politeness when changing tense.

Why: Past forms. [[Korean#^ko-Q0552|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EC%95%84%EC%A7%81%20%EA%B2%B0%EC%A0%95%ED%95%98%EC%A7%80%20%EB%AA%BB%ED%96%88%EB%8B%A4.)
^ko-Q0552-answer

**ko-Q0553** — 히메쿠사 유리코는 자살했다.

Yuriko Himekusa committed suicide.

Expected form: **자살했다**

Why: Past forms. [[Korean#^ko-Q0553|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%9E%88%EB%A9%94%EC%BF%A0%EC%82%AC%20%EC%9C%A0%EB%A6%AC%EC%BD%94%EB%8A%94%20%EC%9E%90%EC%82%B4%ED%96%88%EB%8B%A4.)
^ko-Q0553-answer

**ko-Q0554** — 히메쿠사 유리코는 자살했다.

Yuriko Himekusa committed suicide.

Expected form: **자살했다**

Why: Past forms. [[Korean#^ko-Q0554|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%9E%88%EB%A9%94%EC%BF%A0%EC%82%AC%20%EC%9C%A0%EB%A6%AC%EC%BD%94%EB%8A%94%20%EC%9E%90%EC%82%B4%ED%96%88%EB%8B%A4.)
^ko-Q0554-answer

**ko-Q0555** — 난 정말로 돕고 싶었어.

I really wanted to help.

Expected form: **싶었어**

Why: Past forms. [[Korean#^ko-Q0555|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%9C%20%EC%A0%95%EB%A7%90%EB%A1%9C%20%EB%8F%95%EA%B3%A0%20%EC%8B%B6%EC%97%88%EC%96%B4.)
^ko-Q0555-answer

**ko-Q0556** — 난 정말로 돕고 싶었어.

I really wanted to help.

Why: Past forms. [[Korean#^ko-Q0556|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%9C%20%EC%A0%95%EB%A7%90%EB%A1%9C%20%EB%8F%95%EA%B3%A0%20%EC%8B%B6%EC%97%88%EC%96%B4.)
^ko-Q0556-answer

**ko-Q0557** — 대통령은 경찰이 석궁을 사용하는 것을 승인했다.

The president approved the use of crossbows by the police.

Why: Past forms. [[Korean#^ko-Q0557|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%8C%80%ED%86%B5%EB%A0%B9%EC%9D%80%20%EA%B2%BD%EC%B0%B0%EC%9D%B4%20%EC%84%9D%EA%B6%81%EC%9D%84%20%EC%82%AC%EC%9A%A9%ED%95%98%EB%8A%94%20%EA%B2%83%EC%9D%84%20%EC%8A%B9%EC%9D%B8%ED%96%88%EB%8B%A4.)
^ko-Q0557-answer

**ko-Q0558** — 대통령은 경찰이 석궁을 사용하는 것을 승인했다.

The president approved the use of crossbows by the police.

Past -았/었- combines with a stem and a speech-level ending. Contractions are frequent, including 하다→했-. Retain the intended level of politeness when changing tense.

Why: Past forms. [[Korean#^ko-Q0558|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%8C%80%ED%86%B5%EB%A0%B9%EC%9D%80%20%EA%B2%BD%EC%B0%B0%EC%9D%B4%20%EC%84%9D%EA%B6%81%EC%9D%84%20%EC%82%AC%EC%9A%A9%ED%95%98%EB%8A%94%20%EA%B2%83%EC%9D%84%20%EC%8A%B9%EC%9D%B8%ED%96%88%EB%8B%A4.)
^ko-Q0558-answer

**ko-Q0559** — 상황은 우리가 생각했던 것보다 나쁘다.

The situation is worse than we believed.

Expected form: **생각했던**

Why: Past forms. [[Korean#^ko-Q0559|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%83%81%ED%99%A9%EC%9D%80%20%EC%9A%B0%EB%A6%AC%EA%B0%80%20%EC%83%9D%EA%B0%81%ED%96%88%EB%8D%98%20%EA%B2%83%EB%B3%B4%EB%8B%A4%20%EB%82%98%EC%81%98%EB%8B%A4.)
^ko-Q0559-answer

**ko-Q0560** — 상황은 우리가 생각했던 것보다 나쁘다.

The situation is worse than we believed.

Expected form: **생각했던**

Why: Past forms. [[Korean#^ko-Q0560|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%83%81%ED%99%A9%EC%9D%80%20%EC%9A%B0%EB%A6%AC%EA%B0%80%20%EC%83%9D%EA%B0%81%ED%96%88%EB%8D%98%20%EA%B2%83%EB%B3%B4%EB%8B%A4%20%EB%82%98%EC%81%98%EB%8B%A4.)
^ko-Q0560-answer

**ko-Q0561** — 아이들은 조용히 앉아 있었다.

The children sat quietly.

Expected form: **있었다**

Why: Past forms. [[Korean#^ko-Q0561|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%95%84%EC%9D%B4%EB%93%A4%EC%9D%80%20%EC%A1%B0%EC%9A%A9%ED%9E%88%20%EC%95%89%EC%95%84%20%EC%9E%88%EC%97%88%EB%8B%A4.)
^ko-Q0561-answer

**ko-Q0562** — 아이들은 조용히 앉아 있었다.

The children sat quietly.

Why: Past forms. [[Korean#^ko-Q0562|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%95%84%EC%9D%B4%EB%93%A4%EC%9D%80%20%EC%A1%B0%EC%9A%A9%ED%9E%88%20%EC%95%89%EC%95%84%20%EC%9E%88%EC%97%88%EB%8B%A4.)
^ko-Q0562-answer

**ko-Q0563** — 내 피가 끓고 있었다.

My blood was boiling.

Why: Past forms. [[Korean#^ko-Q0563|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%B4%20%ED%94%BC%EA%B0%80%20%EB%81%93%EA%B3%A0%20%EC%9E%88%EC%97%88%EB%8B%A4.)
^ko-Q0563-answer

**ko-Q0564** — 내 피가 끓고 있었다.

My blood was boiling.

Past -았/었- combines with a stem and a speech-level ending. Contractions are frequent, including 하다→했-. Retain the intended level of politeness when changing tense.

Why: Past forms. [[Korean#^ko-Q0564|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%B4%20%ED%94%BC%EA%B0%80%20%EB%81%93%EA%B3%A0%20%EC%9E%88%EC%97%88%EB%8B%A4.)
^ko-Q0564-answer

**ko-Q0565** — 나는 뭔가가 잘못되었다고 생각했다.

I thought something was wrong.

Expected form: **잘못되었다고**

Why: Past forms. [[Korean#^ko-Q0565|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%EB%AD%94%EA%B0%80%EA%B0%80%20%EC%9E%98%EB%AA%BB%EB%90%98%EC%97%88%EB%8B%A4%EA%B3%A0%20%EC%83%9D%EA%B0%81%ED%96%88%EB%8B%A4.)
^ko-Q0565-answer

**ko-Q0566** — 나는 뭔가가 잘못되었다고 생각했다.

I thought something was wrong.

Expected form: **잘못되었다고**

Why: Past forms. [[Korean#^ko-Q0566|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%EB%AD%94%EA%B0%80%EA%B0%80%20%EC%9E%98%EB%AA%BB%EB%90%98%EC%97%88%EB%8B%A4%EA%B3%A0%20%EC%83%9D%EA%B0%81%ED%96%88%EB%8B%A4.)
^ko-Q0566-answer

**ko-Q0567** — 톰은 메리라는 캐나다 여성과 결혼했어.

Tom is married to a Canadian woman named Mary.

Expected form: **결혼했어**

Why: Past forms. [[Korean#^ko-Q0567|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EB%A9%94%EB%A6%AC%EB%9D%BC%EB%8A%94%20%EC%BA%90%EB%82%98%EB%8B%A4%20%EC%97%AC%EC%84%B1%EA%B3%BC%20%EA%B2%B0%ED%98%BC%ED%96%88%EC%96%B4.)
^ko-Q0567-answer

**ko-Q0568** — 톰은 메리라는 캐나다 여성과 결혼했어.

Tom is married to a Canadian woman named Mary.

Why: Past forms. [[Korean#^ko-Q0568|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EB%A9%94%EB%A6%AC%EB%9D%BC%EB%8A%94%20%EC%BA%90%EB%82%98%EB%8B%A4%20%EC%97%AC%EC%84%B1%EA%B3%BC%20%EA%B2%B0%ED%98%BC%ED%96%88%EC%96%B4.)
^ko-Q0568-answer

**ko-Q0569** — 그 회사 회장은 리베이트를 지불한 혐의로 기소되었다.

The company president was indicted for paying kickbacks.

Why: Past forms. [[Korean#^ko-Q0569|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%20%ED%9A%8C%EC%82%AC%20%ED%9A%8C%EC%9E%A5%EC%9D%80%20%EB%A6%AC%EB%B2%A0%EC%9D%B4%ED%8A%B8%EB%A5%BC%20%EC%A7%80%EB%B6%88%ED%95%9C%20%ED%98%90%EC%9D%98%EB%A1%9C%20%EA%B8%B0%EC%86%8C%EB%90%98%EC%97%88%EB%8B%A4.)
^ko-Q0569-answer

**ko-Q0570** — 그 회사 회장은 리베이트를 지불한 혐의로 기소되었다.

The company president was indicted for paying kickbacks.

Past -았/었- combines with a stem and a speech-level ending. Contractions are frequent, including 하다→했-. Retain the intended level of politeness when changing tense.

Why: Past forms. [[Korean#^ko-Q0570|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%20%ED%9A%8C%EC%82%AC%20%ED%9A%8C%EC%9E%A5%EC%9D%80%20%EB%A6%AC%EB%B2%A0%EC%9D%B4%ED%8A%B8%EB%A5%BC%20%EC%A7%80%EB%B6%88%ED%95%9C%20%ED%98%90%EC%9D%98%EB%A1%9C%20%EA%B8%B0%EC%86%8C%EB%90%98%EC%97%88%EB%8B%A4.)
^ko-Q0570-answer

**ko-Q0571** — 나는 너처럼 가난했었다.

I used to be poor like you.

Expected form: **가난했었다**

Why: Past forms. [[Korean#^ko-Q0571|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%EB%84%88%EC%B2%98%EB%9F%BC%20%EA%B0%80%EB%82%9C%ED%96%88%EC%97%88%EB%8B%A4.)
^ko-Q0571-answer

**ko-Q0572** — 나는 너처럼 가난했었다.

I used to be poor like you.

Expected form: **가난했었다**

Why: Past forms. [[Korean#^ko-Q0572|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%EB%84%88%EC%B2%98%EB%9F%BC%20%EA%B0%80%EB%82%9C%ED%96%88%EC%97%88%EB%8B%A4.)
^ko-Q0572-answer

**ko-Q0573** — 톰은 매우 무례했다.

Tom was very disrespectful.

Expected form: **무례했다**

Why: Past forms. [[Korean#^ko-Q0573|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EB%A7%A4%EC%9A%B0%20%EB%AC%B4%EB%A1%80%ED%96%88%EB%8B%A4.)
^ko-Q0573-answer

**ko-Q0574** — 톰은 매우 무례했다.

Tom was very disrespectful.

Why: Past forms. [[Korean#^ko-Q0574|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EB%A7%A4%EC%9A%B0%20%EB%AC%B4%EB%A1%80%ED%96%88%EB%8B%A4.)
^ko-Q0574-answer

**ko-Q0575** — 톰은 너무 늙었어.

Tom was too old.

Why: Past forms. [[Korean#^ko-Q0575|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EB%84%88%EB%AC%B4%20%EB%8A%99%EC%97%88%EC%96%B4.)
^ko-Q0575-answer

**ko-Q0576** — 톰은 너무 늙었어.

Tom was too old.

Past -았/었- combines with a stem and a speech-level ending. Contractions are frequent, including 하다→했-. Retain the intended level of politeness when changing tense.

Why: Past forms. [[Korean#^ko-Q0576|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EB%84%88%EB%AC%B4%20%EB%8A%99%EC%97%88%EC%96%B4.)
^ko-Q0576-answer

**ko-Q0577** — 시간이 충분했더라면 그가 일을 잘 했을 텐데.

If he had enough time, he might have done good work.

Expected form: **충분했더라면**

Why: Past forms. [[Korean#^ko-Q0577|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%8B%9C%EA%B0%84%EC%9D%B4%20%EC%B6%A9%EB%B6%84%ED%96%88%EB%8D%94%EB%9D%BC%EB%A9%B4%20%EA%B7%B8%EA%B0%80%20%EC%9D%BC%EC%9D%84%20%EC%9E%98%20%ED%96%88%EC%9D%84%20%ED%85%90%EB%8D%B0.)
^ko-Q0577-answer

**ko-Q0578** — 시간이 충분했더라면 그가 일을 잘 했을 텐데.

If he had enough time, he might have done good work.

Expected form: **충분했더라면**

Why: Past forms. [[Korean#^ko-Q0578|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%8B%9C%EA%B0%84%EC%9D%B4%20%EC%B6%A9%EB%B6%84%ED%96%88%EB%8D%94%EB%9D%BC%EB%A9%B4%20%EA%B7%B8%EA%B0%80%20%EC%9D%BC%EC%9D%84%20%EC%9E%98%20%ED%96%88%EC%9D%84%20%ED%85%90%EB%8D%B0.)
^ko-Q0578-answer

**ko-Q0579** — 지출총액은 200,000엔 이었다.

The expenditure totaled 200,000 yen.

Expected form: **이었다**

Why: Past forms. [[Korean#^ko-Q0579|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A7%80%EC%B6%9C%EC%B4%9D%EC%95%A1%EC%9D%80%20200%2C000%EC%97%94%20%EC%9D%B4%EC%97%88%EB%8B%A4.)
^ko-Q0579-answer

**ko-Q0580** — 지출총액은 200,000엔 이었다.

The expenditure totaled 200,000 yen.

Why: Past forms. [[Korean#^ko-Q0580|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A7%80%EC%B6%9C%EC%B4%9D%EC%95%A1%EC%9D%80%20200%2C000%EC%97%94%20%EC%9D%B4%EC%97%88%EB%8B%A4.)
^ko-Q0580-answer

**ko-Q0581** — 그 글은 이해할 수 없었다.

The text was incomprehensible.

Why: Past forms. [[Korean#^ko-Q0581|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%20%EA%B8%80%EC%9D%80%20%EC%9D%B4%ED%95%B4%ED%95%A0%20%EC%88%98%20%EC%97%86%EC%97%88%EB%8B%A4.)
^ko-Q0581-answer

**ko-Q0582** — 그 글은 이해할 수 없었다.

The text was incomprehensible.

Past -았/었- combines with a stem and a speech-level ending. Contractions are frequent, including 하다→했-. Retain the intended level of politeness when changing tense.

Why: Past forms. [[Korean#^ko-Q0582|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%20%EA%B8%80%EC%9D%80%20%EC%9D%B4%ED%95%B4%ED%95%A0%20%EC%88%98%20%EC%97%86%EC%97%88%EB%8B%A4.)
^ko-Q0582-answer

**ko-Q0583** — 톰은 실수로 동영상을 삭제했어.

Tom deleted a video by accident.

Expected form: **삭제했어**

Why: Past forms. [[Korean#^ko-Q0583|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EC%8B%A4%EC%88%98%EB%A1%9C%20%EB%8F%99%EC%98%81%EC%83%81%EC%9D%84%20%EC%82%AD%EC%A0%9C%ED%96%88%EC%96%B4.)
^ko-Q0583-answer

**ko-Q0584** — 톰은 실수로 동영상을 삭제했어.

Tom deleted a video by accident.

Expected form: **삭제했어**

Why: Past forms. [[Korean#^ko-Q0584|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EC%8B%A4%EC%88%98%EB%A1%9C%20%EB%8F%99%EC%98%81%EC%83%81%EC%9D%84%20%EC%82%AD%EC%A0%9C%ED%96%88%EC%96%B4.)
^ko-Q0584-answer

**ko-Q0585** — 톰은 피를 토했다.

Tom vomited blood.

Expected form: **토했다**

Why: Past forms. [[Korean#^ko-Q0585|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%ED%94%BC%EB%A5%BC%20%ED%86%A0%ED%96%88%EB%8B%A4.)
^ko-Q0585-answer

**ko-Q0586** — 톰은 피를 토했다.

Tom vomited blood.

Why: Past forms. [[Korean#^ko-Q0586|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%ED%94%BC%EB%A5%BC%20%ED%86%A0%ED%96%88%EB%8B%A4.)
^ko-Q0586-answer

**ko-Q0587** — 마지막으로 그를 봤을때 그는 파란 셔츠에 흰색 바지를 입고 있었다.

When I last saw him, he was wearing a blue shirt and white slacks.

Why: Past forms. [[Korean#^ko-Q0587|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%A7%88%EC%A7%80%EB%A7%89%EC%9C%BC%EB%A1%9C%20%EA%B7%B8%EB%A5%BC%20%EB%B4%A4%EC%9D%84%EB%95%8C%20%EA%B7%B8%EB%8A%94%20%ED%8C%8C%EB%9E%80%20%EC%85%94%EC%B8%A0%EC%97%90%20%ED%9D%B0%EC%83%89%20%EB%B0%94%EC%A7%80%EB%A5%BC%20%EC%9E%85%EA%B3%A0%20%EC%9E%88%EC%97%88%EB%8B%A4.)
^ko-Q0587-answer

**ko-Q0588** — 마지막으로 그를 봤을때 그는 파란 셔츠에 흰색 바지를 입고 있었다.

When I last saw him, he was wearing a blue shirt and white slacks.

Past -았/었- combines with a stem and a speech-level ending. Contractions are frequent, including 하다→했-. Retain the intended level of politeness when changing tense.

Why: Past forms. [[Korean#^ko-Q0588|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%A7%88%EC%A7%80%EB%A7%89%EC%9C%BC%EB%A1%9C%20%EA%B7%B8%EB%A5%BC%20%EB%B4%A4%EC%9D%84%EB%95%8C%20%EA%B7%B8%EB%8A%94%20%ED%8C%8C%EB%9E%80%20%EC%85%94%EC%B8%A0%EC%97%90%20%ED%9D%B0%EC%83%89%20%EB%B0%94%EC%A7%80%EB%A5%BC%20%EC%9E%85%EA%B3%A0%20%EC%9E%88%EC%97%88%EB%8B%A4.)
^ko-Q0588-answer

**ko-Q0589** — 떠날 수밖에 없었어.

I had no choice but to leave.

Expected form: **없었어**

Why: Past forms. [[Korean#^ko-Q0589|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%96%A0%EB%82%A0%20%EC%88%98%EB%B0%96%EC%97%90%20%EC%97%86%EC%97%88%EC%96%B4.)
^ko-Q0589-answer

**ko-Q0590** — 떠날 수밖에 없었어.

I had no choice but to leave.

Expected form: **없었어**

Why: Past forms. [[Korean#^ko-Q0590|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%96%A0%EB%82%A0%20%EC%88%98%EB%B0%96%EC%97%90%20%EC%97%86%EC%97%88%EC%96%B4.)
^ko-Q0590-answer

**ko-Q0591** — 그 여자는 자기 아들을 자랑스럽게 생각했다.

She prides herself on her son.

Expected form: **생각했다**

Why: Past forms. [[Korean#^ko-Q0591|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%20%EC%97%AC%EC%9E%90%EB%8A%94%20%EC%9E%90%EA%B8%B0%20%EC%95%84%EB%93%A4%EC%9D%84%20%EC%9E%90%EB%9E%91%EC%8A%A4%EB%9F%BD%EA%B2%8C%20%EC%83%9D%EA%B0%81%ED%96%88%EB%8B%A4.)
^ko-Q0591-answer

**ko-Q0592** — 그 여자는 자기 아들을 자랑스럽게 생각했다.

She prides herself on her son.

Why: Past forms. [[Korean#^ko-Q0592|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%20%EC%97%AC%EC%9E%90%EB%8A%94%20%EC%9E%90%EA%B8%B0%20%EC%95%84%EB%93%A4%EC%9D%84%20%EC%9E%90%EB%9E%91%EC%8A%A4%EB%9F%BD%EA%B2%8C%20%EC%83%9D%EA%B0%81%ED%96%88%EB%8B%A4.)
^ko-Q0592-answer

**ko-Q0593** — 생판 모르는 사람과 저녁을 먹었다.

I had dinner with a total stranger.

Why: Past forms. [[Korean#^ko-Q0593|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%83%9D%ED%8C%90%20%EB%AA%A8%EB%A5%B4%EB%8A%94%20%EC%82%AC%EB%9E%8C%EA%B3%BC%20%EC%A0%80%EB%85%81%EC%9D%84%20%EB%A8%B9%EC%97%88%EB%8B%A4.)
^ko-Q0593-answer

**ko-Q0594** — 생판 모르는 사람과 저녁을 먹었다.

I had dinner with a total stranger.

Past -았/었- combines with a stem and a speech-level ending. Contractions are frequent, including 하다→했-. Retain the intended level of politeness when changing tense.

Why: Past forms. [[Korean#^ko-Q0594|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%83%9D%ED%8C%90%20%EB%AA%A8%EB%A5%B4%EB%8A%94%20%EC%82%AC%EB%9E%8C%EA%B3%BC%20%EC%A0%80%EB%85%81%EC%9D%84%20%EB%A8%B9%EC%97%88%EB%8B%A4.)
^ko-Q0594-answer

**ko-Q0595** — 톰은 앞 줄에 앉았다.

Tom sat in the front row.

Expected form: **앉았다**

Why: Past forms. [[Korean#^ko-Q0595|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EC%95%9E%20%EC%A4%84%EC%97%90%20%EC%95%89%EC%95%98%EB%8B%A4.)
^ko-Q0595-answer

**ko-Q0596** — 톰은 앞 줄에 앉았다.

Tom sat in the front row.

Expected form: **앉았다**

Why: Past forms. [[Korean#^ko-Q0596|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EC%95%9E%20%EC%A4%84%EC%97%90%20%EC%95%89%EC%95%98%EB%8B%A4.)
^ko-Q0596-answer

**ko-Q0597** — 톰은 메리라는 캐나다인과 결혼했어.

Tom is married to a Canadian named Mary.

Expected form: **결혼했어**

Why: Past forms. [[Korean#^ko-Q0597|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EB%A9%94%EB%A6%AC%EB%9D%BC%EB%8A%94%20%EC%BA%90%EB%82%98%EB%8B%A4%EC%9D%B8%EA%B3%BC%20%EA%B2%B0%ED%98%BC%ED%96%88%EC%96%B4.)
^ko-Q0597-answer

**ko-Q0598** — 톰은 메리라는 캐나다인과 결혼했어.

Tom is married to a Canadian named Mary.

Why: Past forms. [[Korean#^ko-Q0598|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EB%A9%94%EB%A6%AC%EB%9D%BC%EB%8A%94%20%EC%BA%90%EB%82%98%EB%8B%A4%EC%9D%B8%EA%B3%BC%20%EA%B2%B0%ED%98%BC%ED%96%88%EC%96%B4.)
^ko-Q0598-answer

**ko-Q0599** — 내가 그렇게 오랫동안에 멀리 있지 않았어야 했어.

I shouldn't have stayed away so long.

Why: Past forms. [[Korean#^ko-Q0599|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%B4%EA%B0%80%20%EA%B7%B8%EB%A0%87%EA%B2%8C%20%EC%98%A4%EB%9E%AB%EB%8F%99%EC%95%88%EC%97%90%20%EB%A9%80%EB%A6%AC%20%EC%9E%88%EC%A7%80%20%EC%95%8A%EC%95%98%EC%96%B4%EC%95%BC%20%ED%96%88%EC%96%B4.)
^ko-Q0599-answer

**ko-Q0600** — 내가 그렇게 오랫동안에 멀리 있지 않았어야 했어.

I shouldn't have stayed away so long.

Past -았/었- combines with a stem and a speech-level ending. Contractions are frequent, including 하다→했-. Retain the intended level of politeness when changing tense.

Why: Past forms. [[Korean#^ko-Q0600|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%B4%EA%B0%80%20%EA%B7%B8%EB%A0%87%EA%B2%8C%20%EC%98%A4%EB%9E%AB%EB%8F%99%EC%95%88%EC%97%90%20%EB%A9%80%EB%A6%AC%20%EC%9E%88%EC%A7%80%20%EC%95%8A%EC%95%98%EC%96%B4%EC%95%BC%20%ED%96%88%EC%96%B4.)
^ko-Q0600-answer


### Answers 601–650

**ko-Q0601** — 동물을 학대해서는 안 된다.

One must not abuse animals.

Expected form: **안**

Why: Negation. [[Korean#^ko-Q0601|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%8F%99%EB%AC%BC%EC%9D%84%20%ED%95%99%EB%8C%80%ED%95%B4%EC%84%9C%EB%8A%94%20%EC%95%88%20%EB%90%9C%EB%8B%A4.)
^ko-Q0601-answer

**ko-Q0602** — 동물을 학대해서는 안 된다.

One must not abuse animals.

Expected form: **안**

Why: Negation. [[Korean#^ko-Q0602|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%8F%99%EB%AC%BC%EC%9D%84%20%ED%95%99%EB%8C%80%ED%95%B4%EC%84%9C%EB%8A%94%20%EC%95%88%20%EB%90%9C%EB%8B%A4.)
^ko-Q0602-answer

**ko-Q0603** — 저 두 명은 사이가 안 좋다.

Those two don't get along.

Expected form: **안**

Why: Negation. [[Korean#^ko-Q0603|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A0%80%20%EB%91%90%20%EB%AA%85%EC%9D%80%20%EC%82%AC%EC%9D%B4%EA%B0%80%20%EC%95%88%20%EC%A2%8B%EB%8B%A4.)
^ko-Q0603-answer

**ko-Q0604** — 저 두 명은 사이가 안 좋다.

Those two don't get along.

Why: Negation. [[Korean#^ko-Q0604|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A0%80%20%EB%91%90%20%EB%AA%85%EC%9D%80%20%EC%82%AC%EC%9D%B4%EA%B0%80%20%EC%95%88%20%EC%A2%8B%EB%8B%A4.)
^ko-Q0604-answer

**ko-Q0605** — 저는 설탕이 없어서 안 마셔요.

I don't drink that without sugar.

Why: Negation. [[Korean#^ko-Q0605|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A0%80%EB%8A%94%20%EC%84%A4%ED%83%95%EC%9D%B4%20%EC%97%86%EC%96%B4%EC%84%9C%20%EC%95%88%20%EB%A7%88%EC%85%94%EC%9A%94.)
^ko-Q0605-answer

**ko-Q0606** — 저는 설탕이 없어서 안 마셔요.

I don't drink that without sugar.

안 commonly negates; 못 commonly expresses inability or failure to perform. Their placement and long-form alternatives depend on the predicate and register.

Why: Negation. [[Korean#^ko-Q0606|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A0%80%EB%8A%94%20%EC%84%A4%ED%83%95%EC%9D%B4%20%EC%97%86%EC%96%B4%EC%84%9C%20%EC%95%88%20%EB%A7%88%EC%85%94%EC%9A%94.)
^ko-Q0606-answer

**ko-Q0607** — 나는 릭을 그가 뉴질랜드로 돌아간 뒤에는 못 봤어.

I haven't seen Rick since he returned from New Zealand.

Expected form: **못**

Why: Negation. [[Korean#^ko-Q0607|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%EB%A6%AD%EC%9D%84%20%EA%B7%B8%EA%B0%80%20%EB%89%B4%EC%A7%88%EB%9E%9C%EB%93%9C%EB%A1%9C%20%EB%8F%8C%EC%95%84%EA%B0%84%20%EB%92%A4%EC%97%90%EB%8A%94%20%EB%AA%BB%20%EB%B4%A4%EC%96%B4.)
^ko-Q0607-answer

**ko-Q0608** — 나는 릭을 그가 뉴질랜드로 돌아간 뒤에는 못 봤어.

I haven't seen Rick since he returned from New Zealand.

Expected form: **못**

Why: Negation. [[Korean#^ko-Q0608|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%EB%A6%AD%EC%9D%84%20%EA%B7%B8%EA%B0%80%20%EB%89%B4%EC%A7%88%EB%9E%9C%EB%93%9C%EB%A1%9C%20%EB%8F%8C%EC%95%84%EA%B0%84%20%EB%92%A4%EC%97%90%EB%8A%94%20%EB%AA%BB%20%EB%B4%A4%EC%96%B4.)
^ko-Q0608-answer

**ko-Q0609** — 저는 춤을 잘 못 춰요.

I'm not good at dancing.

Expected form: **못**

Why: Negation. [[Korean#^ko-Q0609|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A0%80%EB%8A%94%20%EC%B6%A4%EC%9D%84%20%EC%9E%98%20%EB%AA%BB%20%EC%B6%B0%EC%9A%94.)
^ko-Q0609-answer

**ko-Q0610** — 저는 춤을 잘 못 춰요.

I'm not good at dancing.

Why: Negation. [[Korean#^ko-Q0610|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A0%80%EB%8A%94%20%EC%B6%A4%EC%9D%84%20%EC%9E%98%20%EB%AA%BB%20%EC%B6%B0%EC%9A%94.)
^ko-Q0610-answer

**ko-Q0611** — 3년 만에 컴백, 그동안 어떻게 지냈는가.

Since their comeback three years ago, how have they been doing?

Why: Negation. [[Korean#^ko-Q0611|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=3%EB%85%84%20%EB%A7%8C%EC%97%90%20%EC%BB%B4%EB%B0%B1%2C%20%EA%B7%B8%EB%8F%99%EC%95%88%20%EC%96%B4%EB%96%BB%EA%B2%8C%20%EC%A7%80%EB%83%88%EB%8A%94%EA%B0%80.)
^ko-Q0611-answer

**ko-Q0612** — 3년 만에 컴백, 그동안 어떻게 지냈는가.

Since their comeback three years ago, how have they been doing?

안 commonly negates; 못 commonly expresses inability or failure to perform. Their placement and long-form alternatives depend on the predicate and register.

Why: Negation. [[Korean#^ko-Q0612|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=3%EB%85%84%20%EB%A7%8C%EC%97%90%20%EC%BB%B4%EB%B0%B1%2C%20%EA%B7%B8%EB%8F%99%EC%95%88%20%EC%96%B4%EB%96%BB%EA%B2%8C%20%EC%A7%80%EB%83%88%EB%8A%94%EA%B0%80.)
^ko-Q0612-answer

**ko-Q0613** — 택시로 안 왔어.

I didn't come by taxi.

Expected form: **안**

Why: Negation. [[Korean#^ko-Q0613|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%83%9D%EC%8B%9C%EB%A1%9C%20%EC%95%88%20%EC%99%94%EC%96%B4.)
^ko-Q0613-answer

**ko-Q0614** — 택시로 안 왔어.

I didn't come by taxi.

Expected form: **안**

Why: Negation. [[Korean#^ko-Q0614|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%83%9D%EC%8B%9C%EB%A1%9C%20%EC%95%88%20%EC%99%94%EC%96%B4.)
^ko-Q0614-answer

**ko-Q0615** — 내 눈에 흙이 들어가기 전까지는 그런 꼴 못 보오이다!

Over my dead body shall I witness such a shameful sight.

Expected form: **못**

Why: Negation. [[Korean#^ko-Q0615|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%B4%20%EB%88%88%EC%97%90%20%ED%9D%99%EC%9D%B4%20%EB%93%A4%EC%96%B4%EA%B0%80%EA%B8%B0%20%EC%A0%84%EA%B9%8C%EC%A7%80%EB%8A%94%20%EA%B7%B8%EB%9F%B0%20%EA%BC%B4%20%EB%AA%BB%20%EB%B3%B4%EC%98%A4%EC%9D%B4%EB%8B%A4%21)
^ko-Q0615-answer

**ko-Q0616** — 내 눈에 흙이 들어가기 전까지는 그런 꼴 못 보오이다!

Over my dead body shall I witness such a shameful sight.

Why: Negation. [[Korean#^ko-Q0616|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%B4%20%EB%88%88%EC%97%90%20%ED%9D%99%EC%9D%B4%20%EB%93%A4%EC%96%B4%EA%B0%80%EA%B8%B0%20%EC%A0%84%EA%B9%8C%EC%A7%80%EB%8A%94%20%EA%B7%B8%EB%9F%B0%20%EA%BC%B4%20%EB%AA%BB%20%EB%B3%B4%EC%98%A4%EC%9D%B4%EB%8B%A4%21)
^ko-Q0616-answer

**ko-Q0617** — 톰은 자기가 얼마나 미쳐보이는지 신경 안 써.

Tom don't care how crazy he looks.

Why: Negation. [[Korean#^ko-Q0617|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EC%9E%90%EA%B8%B0%EA%B0%80%20%EC%96%BC%EB%A7%88%EB%82%98%20%EB%AF%B8%EC%B3%90%EB%B3%B4%EC%9D%B4%EB%8A%94%EC%A7%80%20%EC%8B%A0%EA%B2%BD%20%EC%95%88%20%EC%8D%A8.)
^ko-Q0617-answer

**ko-Q0618** — 톰은 자기가 얼마나 미쳐보이는지 신경 안 써.

Tom don't care how crazy he looks.

안 commonly negates; 못 commonly expresses inability or failure to perform. Their placement and long-form alternatives depend on the predicate and register.

Why: Negation. [[Korean#^ko-Q0618|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EC%9E%90%EA%B8%B0%EA%B0%80%20%EC%96%BC%EB%A7%88%EB%82%98%20%EB%AF%B8%EC%B3%90%EB%B3%B4%EC%9D%B4%EB%8A%94%EC%A7%80%20%EC%8B%A0%EA%B2%BD%20%EC%95%88%20%EC%8D%A8.)
^ko-Q0618-answer

**ko-Q0619** — 너는 음식 생각 밖에 안 한다.

You only think about food.

Expected form: **안**

Why: Negation. [[Korean#^ko-Q0619|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%84%88%EB%8A%94%20%EC%9D%8C%EC%8B%9D%20%EC%83%9D%EA%B0%81%20%EB%B0%96%EC%97%90%20%EC%95%88%20%ED%95%9C%EB%8B%A4.)
^ko-Q0619-answer

**ko-Q0620** — 너는 음식 생각 밖에 안 한다.

You only think about food.

Expected form: **안**

Why: Negation. [[Korean#^ko-Q0620|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%84%88%EB%8A%94%20%EC%9D%8C%EC%8B%9D%20%EC%83%9D%EA%B0%81%20%EB%B0%96%EC%97%90%20%EC%95%88%20%ED%95%9C%EB%8B%A4.)
^ko-Q0620-answer

**ko-Q0621** — 톰은 투표 안 했어.

Tom didn't vote.

Expected form: **안**

Why: Negation. [[Korean#^ko-Q0621|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%ED%88%AC%ED%91%9C%20%EC%95%88%20%ED%96%88%EC%96%B4.)
^ko-Q0621-answer

**ko-Q0622** — 톰은 투표 안 했어.

Tom didn't vote.

Why: Negation. [[Korean#^ko-Q0622|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%ED%88%AC%ED%91%9C%20%EC%95%88%20%ED%96%88%EC%96%B4.)
^ko-Q0622-answer

**ko-Q0623** — 너 없인 못 살아.

I can't live without you.

Why: Negation. [[Korean#^ko-Q0623|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%84%88%20%EC%97%86%EC%9D%B8%20%EB%AA%BB%20%EC%82%B4%EC%95%84.)
^ko-Q0623-answer

**ko-Q0624** — 너 없인 못 살아.

I can't live without you.

안 commonly negates; 못 commonly expresses inability or failure to perform. Their placement and long-form alternatives depend on the predicate and register.

Why: Negation. [[Korean#^ko-Q0624|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%84%88%20%EC%97%86%EC%9D%B8%20%EB%AA%BB%20%EC%82%B4%EC%95%84.)
^ko-Q0624-answer

**ko-Q0625** — 엄마는 운동하는 걸 안 좋아한다.

Mom doesn't like to exercise.

Expected form: **안**

Why: Negation. [[Korean#^ko-Q0625|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%97%84%EB%A7%88%EB%8A%94%20%EC%9A%B4%EB%8F%99%ED%95%98%EB%8A%94%20%EA%B1%B8%20%EC%95%88%20%EC%A2%8B%EC%95%84%ED%95%9C%EB%8B%A4.)
^ko-Q0625-answer

**ko-Q0626** — 엄마는 운동하는 걸 안 좋아한다.

Mom doesn't like to exercise.

Expected form: **안**

Why: Negation. [[Korean#^ko-Q0626|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%97%84%EB%A7%88%EB%8A%94%20%EC%9A%B4%EB%8F%99%ED%95%98%EB%8A%94%20%EA%B1%B8%20%EC%95%88%20%EC%A2%8B%EC%95%84%ED%95%9C%EB%8B%A4.)
^ko-Q0626-answer

**ko-Q0627** — 내가 버스를 잘못 타 가지고 다른 곳으로 갔어.

I took the wrong bus, so I went somewhere else.

Expected form: **못**

Why: Negation. [[Korean#^ko-Q0627|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%B4%EA%B0%80%20%EB%B2%84%EC%8A%A4%EB%A5%BC%20%EC%9E%98%EB%AA%BB%20%ED%83%80%20%EA%B0%80%EC%A7%80%EA%B3%A0%20%EB%8B%A4%EB%A5%B8%20%EA%B3%B3%EC%9C%BC%EB%A1%9C%20%EA%B0%94%EC%96%B4.)
^ko-Q0627-answer

**ko-Q0628** — 내가 버스를 잘못 타 가지고 다른 곳으로 갔어.

I took the wrong bus, so I went somewhere else.

Why: Negation. [[Korean#^ko-Q0628|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%B4%EA%B0%80%20%EB%B2%84%EC%8A%A4%EB%A5%BC%20%EC%9E%98%EB%AA%BB%20%ED%83%80%20%EA%B0%80%EC%A7%80%EA%B3%A0%20%EB%8B%A4%EB%A5%B8%20%EA%B3%B3%EC%9C%BC%EB%A1%9C%20%EA%B0%94%EC%96%B4.)
^ko-Q0628-answer

**ko-Q0629** — 톰 별로 안 바빠 보이던데.

Tom didn't seem to be so busy.

Why: Negation. [[Korean#^ko-Q0629|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%20%EB%B3%84%EB%A1%9C%20%EC%95%88%20%EB%B0%94%EB%B9%A0%20%EB%B3%B4%EC%9D%B4%EB%8D%98%EB%8D%B0.)
^ko-Q0629-answer

**ko-Q0630** — 톰 별로 안 바빠 보이던데.

Tom didn't seem to be so busy.

안 commonly negates; 못 commonly expresses inability or failure to perform. Their placement and long-form alternatives depend on the predicate and register.

Why: Negation. [[Korean#^ko-Q0630|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%20%EB%B3%84%EB%A1%9C%20%EC%95%88%20%EB%B0%94%EB%B9%A0%20%EB%B3%B4%EC%9D%B4%EB%8D%98%EB%8D%B0.)
^ko-Q0630-answer

**ko-Q0631** — 8시간 동안 운전을 한 후에 톰은 더이상 운전을 할 수 없었다.

After driving for eight hours, Tom just couldn't drive any longer.

Expected form: **안**

Why: Negation. [[Korean#^ko-Q0631|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=8%EC%8B%9C%EA%B0%84%20%EB%8F%99%EC%95%88%20%EC%9A%B4%EC%A0%84%EC%9D%84%20%ED%95%9C%20%ED%9B%84%EC%97%90%20%ED%86%B0%EC%9D%80%20%EB%8D%94%EC%9D%B4%EC%83%81%20%EC%9A%B4%EC%A0%84%EC%9D%84%20%ED%95%A0%20%EC%88%98%20%EC%97%86%EC%97%88%EB%8B%A4.)
^ko-Q0631-answer

**ko-Q0632** — 8시간 동안 운전을 한 후에 톰은 더이상 운전을 할 수 없었다.

After driving for eight hours, Tom just couldn't drive any longer.

Expected form: **안**

Why: Negation. [[Korean#^ko-Q0632|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=8%EC%8B%9C%EA%B0%84%20%EB%8F%99%EC%95%88%20%EC%9A%B4%EC%A0%84%EC%9D%84%20%ED%95%9C%20%ED%9B%84%EC%97%90%20%ED%86%B0%EC%9D%80%20%EB%8D%94%EC%9D%B4%EC%83%81%20%EC%9A%B4%EC%A0%84%EC%9D%84%20%ED%95%A0%20%EC%88%98%20%EC%97%86%EC%97%88%EB%8B%A4.)
^ko-Q0632-answer

**ko-Q0633** — 우리 한동안 못 봤지!

We haven't seen you in a while.

Expected form: **안**

Why: Negation. [[Korean#^ko-Q0633|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9A%B0%EB%A6%AC%20%ED%95%9C%EB%8F%99%EC%95%88%20%EB%AA%BB%20%EB%B4%A4%EC%A7%80%21)
^ko-Q0633-answer

**ko-Q0634** — 우리 한동안 못 봤지!

We haven't seen you in a while.

Why: Negation. [[Korean#^ko-Q0634|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9A%B0%EB%A6%AC%20%ED%95%9C%EB%8F%99%EC%95%88%20%EB%AA%BB%20%EB%B4%A4%EC%A7%80%21)
^ko-Q0634-answer

**ko-Q0635** — 이건 정말 못 믿겠다.

This is difficult to believe.

Why: Negation. [[Korean#^ko-Q0635|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9D%B4%EA%B1%B4%20%EC%A0%95%EB%A7%90%20%EB%AA%BB%20%EB%AF%BF%EA%B2%A0%EB%8B%A4.)
^ko-Q0635-answer

**ko-Q0636** — 이건 정말 못 믿겠다.

This is difficult to believe.

안 commonly negates; 못 commonly expresses inability or failure to perform. Their placement and long-form alternatives depend on the predicate and register.

Why: Negation. [[Korean#^ko-Q0636|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9D%B4%EA%B1%B4%20%EC%A0%95%EB%A7%90%20%EB%AA%BB%20%EB%AF%BF%EA%B2%A0%EB%8B%A4.)
^ko-Q0636-answer

**ko-Q0637** — 톰은 마리가 존이 그걸 하면 안 될 거라는 걸 알았다고 말했다.

Tom said that Mary knew that John might not be allowed to do that.

Expected form: **안**

Why: Negation. [[Korean#^ko-Q0637|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EB%A7%88%EB%A6%AC%EA%B0%80%20%EC%A1%B4%EC%9D%B4%20%EA%B7%B8%EA%B1%B8%20%ED%95%98%EB%A9%B4%20%EC%95%88%20%EB%90%A0%20%EA%B1%B0%EB%9D%BC%EB%8A%94%20%EA%B1%B8%20%EC%95%8C%EC%95%98%EB%8B%A4%EA%B3%A0%20%EB%A7%90%ED%96%88%EB%8B%A4.)
^ko-Q0637-answer

**ko-Q0638** — 톰은 마리가 존이 그걸 하면 안 될 거라는 걸 알았다고 말했다.

Tom said that Mary knew that John might not be allowed to do that.

Expected form: **안**

Why: Negation. [[Korean#^ko-Q0638|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EB%A7%88%EB%A6%AC%EA%B0%80%20%EC%A1%B4%EC%9D%B4%20%EA%B7%B8%EA%B1%B8%20%ED%95%98%EB%A9%B4%20%EC%95%88%20%EB%90%A0%20%EA%B1%B0%EB%9D%BC%EB%8A%94%20%EA%B1%B8%20%EC%95%8C%EC%95%98%EB%8B%A4%EA%B3%A0%20%EB%A7%90%ED%96%88%EB%8B%A4.)
^ko-Q0638-answer

**ko-Q0639** — 아직 10 분 안 됬어요.

It hasn' been 10 minutes yet.

Expected form: **안**

Why: Negation. [[Korean#^ko-Q0639|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%95%84%EC%A7%81%2010%20%EB%B6%84%20%EC%95%88%20%EB%90%AC%EC%96%B4%EC%9A%94.)
^ko-Q0639-answer

**ko-Q0640** — 아직 10 분 안 됬어요.

It hasn' been 10 minutes yet.

Why: Negation. [[Korean#^ko-Q0640|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%95%84%EC%A7%81%2010%20%EB%B6%84%20%EC%95%88%20%EB%90%AC%EC%96%B4%EC%9A%94.)
^ko-Q0640-answer

**ko-Q0641** — 나는 못 생겼다.

I'm ugly.

Why: Negation. [[Korean#^ko-Q0641|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%EB%AA%BB%20%EC%83%9D%EA%B2%BC%EB%8B%A4.)
^ko-Q0641-answer

**ko-Q0642** — 나는 못 생겼다.

I'm ugly.

안 commonly negates; 못 commonly expresses inability or failure to perform. Their placement and long-form alternatives depend on the predicate and register.

Why: Negation. [[Korean#^ko-Q0642|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%EB%AA%BB%20%EC%83%9D%EA%B2%BC%EB%8B%A4.)
^ko-Q0642-answer

**ko-Q0643** — 넌 오늘 누가 왔었는지 못 믿을걸.

You won't believe who came by today.

Expected form: **못**

Why: Negation. [[Korean#^ko-Q0643|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%84%8C%20%EC%98%A4%EB%8A%98%20%EB%88%84%EA%B0%80%20%EC%99%94%EC%97%88%EB%8A%94%EC%A7%80%20%EB%AA%BB%20%EB%AF%BF%EC%9D%84%EA%B1%B8.)
^ko-Q0643-answer

**ko-Q0644** — 넌 오늘 누가 왔었는지 못 믿을걸.

You won't believe who came by today.

Expected form: **못**

Why: Negation. [[Korean#^ko-Q0644|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%84%8C%20%EC%98%A4%EB%8A%98%20%EB%88%84%EA%B0%80%20%EC%99%94%EC%97%88%EB%8A%94%EC%A7%80%20%EB%AA%BB%20%EB%AF%BF%EC%9D%84%EA%B1%B8.)
^ko-Q0644-answer

**ko-Q0645** — 일을 안하니까, 돈을 못 모으겠어.

Since I don't have a job, I can't save money.

Expected form: **못**

Why: Negation. [[Korean#^ko-Q0645|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9D%BC%EC%9D%84%20%EC%95%88%ED%95%98%EB%8B%88%EA%B9%8C%2C%20%EB%8F%88%EC%9D%84%20%EB%AA%BB%20%EB%AA%A8%EC%9C%BC%EA%B2%A0%EC%96%B4.)
^ko-Q0645-answer

**ko-Q0646** — 일을 안하니까, 돈을 못 모으겠어.

Since I don't have a job, I can't save money.

Why: Negation. [[Korean#^ko-Q0646|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9D%BC%EC%9D%84%20%EC%95%88%ED%95%98%EB%8B%88%EA%B9%8C%2C%20%EB%8F%88%EC%9D%84%20%EB%AA%BB%20%EB%AA%A8%EC%9C%BC%EA%B2%A0%EC%96%B4.)
^ko-Q0646-answer

**ko-Q0647** — 이건 안 될 것 같다.

I don't think this is going to work.

Why: Negation. [[Korean#^ko-Q0647|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9D%B4%EA%B1%B4%20%EC%95%88%20%EB%90%A0%20%EA%B2%83%20%EA%B0%99%EB%8B%A4.)
^ko-Q0647-answer

**ko-Q0648** — 이건 안 될 것 같다.

I don't think this is going to work.

안 commonly negates; 못 commonly expresses inability or failure to perform. Their placement and long-form alternatives depend on the predicate and register.

Why: Negation. [[Korean#^ko-Q0648|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9D%B4%EA%B1%B4%20%EC%95%88%20%EB%90%A0%20%EA%B2%83%20%EA%B0%99%EB%8B%A4.)
^ko-Q0648-answer

**ko-Q0649** — 난 비벤디 파일을 더 이상 못 찾겠다.

I can no longer find the Vivendi file.

Expected form: **못**

Why: Negation. [[Korean#^ko-Q0649|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%9C%20%EB%B9%84%EB%B2%A4%EB%94%94%20%ED%8C%8C%EC%9D%BC%EC%9D%84%20%EB%8D%94%20%EC%9D%B4%EC%83%81%20%EB%AA%BB%20%EC%B0%BE%EA%B2%A0%EB%8B%A4.)
^ko-Q0649-answer

**ko-Q0650** — 난 비벤디 파일을 더 이상 못 찾겠다.

I can no longer find the Vivendi file.

Expected form: **못**

Why: Negation. [[Korean#^ko-Q0650|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%9C%20%EB%B9%84%EB%B2%A4%EB%94%94%20%ED%8C%8C%EC%9D%BC%EC%9D%84%20%EB%8D%94%20%EC%9D%B4%EC%83%81%20%EB%AA%BB%20%EC%B0%BE%EA%B2%A0%EB%8B%A4.)
^ko-Q0650-answer


### Answers 651–700

**ko-Q0651** — 바라는 것이 없으면 부족함이 없다.

Not wanting is the same as having.

Expected form: **없다**

Why: Existence and absence. [[Korean#^ko-Q0651|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%B0%94%EB%9D%BC%EB%8A%94%20%EA%B2%83%EC%9D%B4%20%EC%97%86%EC%9C%BC%EB%A9%B4%20%EB%B6%80%EC%A1%B1%ED%95%A8%EC%9D%B4%20%EC%97%86%EB%8B%A4.)
^ko-Q0651-answer

**ko-Q0652** — 바라는 것이 없으면 부족함이 없다.

Not wanting is the same as having.

Why: Existence and absence. [[Korean#^ko-Q0652|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%B0%94%EB%9D%BC%EB%8A%94%20%EA%B2%83%EC%9D%B4%20%EC%97%86%EC%9C%BC%EB%A9%B4%20%EB%B6%80%EC%A1%B1%ED%95%A8%EC%9D%B4%20%EC%97%86%EB%8B%A4.)
^ko-Q0652-answer

**ko-Q0653** — 다른 사람을 귀찮게 할 수 있다.

The others can't be bothered.

Why: Existence and absence. [[Korean#^ko-Q0653|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%8B%A4%EB%A5%B8%20%EC%82%AC%EB%9E%8C%EC%9D%84%20%EA%B7%80%EC%B0%AE%EA%B2%8C%20%ED%95%A0%20%EC%88%98%20%EC%9E%88%EB%8B%A4.)
^ko-Q0653-answer

**ko-Q0654** — 다른 사람을 귀찮게 할 수 있다.

The others can't be bothered.

있다 and 없다 express existence/absence and some possession. Their complements do not behave exactly like English have objects. Location and subject marking remain important.

Why: Existence and absence. [[Korean#^ko-Q0654|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%8B%A4%EB%A5%B8%20%EC%82%AC%EB%9E%8C%EC%9D%84%20%EA%B7%80%EC%B0%AE%EA%B2%8C%20%ED%95%A0%20%EC%88%98%20%EC%9E%88%EB%8B%A4.)
^ko-Q0654-answer

**ko-Q0655** — 새로운 친구를 만드는 건 어려울 수 있다.

It can be hard to make new friends.

Expected form: **있다**

Why: Existence and absence. [[Korean#^ko-Q0655|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%83%88%EB%A1%9C%EC%9A%B4%20%EC%B9%9C%EA%B5%AC%EB%A5%BC%20%EB%A7%8C%EB%93%9C%EB%8A%94%20%EA%B1%B4%20%EC%96%B4%EB%A0%A4%EC%9A%B8%20%EC%88%98%20%EC%9E%88%EB%8B%A4.)
^ko-Q0655-answer

**ko-Q0656** — 새로운 친구를 만드는 건 어려울 수 있다.

It can be hard to make new friends.

Expected form: **있다**

Why: Existence and absence. [[Korean#^ko-Q0656|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%83%88%EB%A1%9C%EC%9A%B4%20%EC%B9%9C%EA%B5%AC%EB%A5%BC%20%EB%A7%8C%EB%93%9C%EB%8A%94%20%EA%B1%B4%20%EC%96%B4%EB%A0%A4%EC%9A%B8%20%EC%88%98%20%EC%9E%88%EB%8B%A4.)
^ko-Q0656-answer

**ko-Q0657** — 이 투명한 액체는 독을 포함하고 있다.

This transparent liquid contains poison.

Expected form: **있다**

Why: Existence and absence. [[Korean#^ko-Q0657|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9D%B4%20%ED%88%AC%EB%AA%85%ED%95%9C%20%EC%95%A1%EC%B2%B4%EB%8A%94%20%EB%8F%85%EC%9D%84%20%ED%8F%AC%ED%95%A8%ED%95%98%EA%B3%A0%20%EC%9E%88%EB%8B%A4.)
^ko-Q0657-answer

**ko-Q0658** — 이 투명한 액체는 독을 포함하고 있다.

This transparent liquid contains poison.

Why: Existence and absence. [[Korean#^ko-Q0658|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9D%B4%20%ED%88%AC%EB%AA%85%ED%95%9C%20%EC%95%A1%EC%B2%B4%EB%8A%94%20%EB%8F%85%EC%9D%84%20%ED%8F%AC%ED%95%A8%ED%95%98%EA%B3%A0%20%EC%9E%88%EB%8B%A4.)
^ko-Q0658-answer

**ko-Q0659** — 너는 톰이 거짓말을 하고 있다고 생각하니?

Do you think Tom is lying?

Why: Existence and absence. [[Korean#^ko-Q0659|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%84%88%EB%8A%94%20%ED%86%B0%EC%9D%B4%20%EA%B1%B0%EC%A7%93%EB%A7%90%EC%9D%84%20%ED%95%98%EA%B3%A0%20%EC%9E%88%EB%8B%A4%EA%B3%A0%20%EC%83%9D%EA%B0%81%ED%95%98%EB%8B%88%3F)
^ko-Q0659-answer

**ko-Q0660** — 너는 톰이 거짓말을 하고 있다고 생각하니?

Do you think Tom is lying?

있다 and 없다 express existence/absence and some possession. Their complements do not behave exactly like English have objects. Location and subject marking remain important.

Why: Existence and absence. [[Korean#^ko-Q0660|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%84%88%EB%8A%94%20%ED%86%B0%EC%9D%B4%20%EA%B1%B0%EC%A7%93%EB%A7%90%EC%9D%84%20%ED%95%98%EA%B3%A0%20%EC%9E%88%EB%8B%A4%EA%B3%A0%20%EC%83%9D%EA%B0%81%ED%95%98%EB%8B%88%3F)
^ko-Q0660-answer

**ko-Q0661** — 목초지에 양이 많이 있다.

There are a lot of sheep in the pasture.

Expected form: **있다**

Why: Existence and absence. [[Korean#^ko-Q0661|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%AA%A9%EC%B4%88%EC%A7%80%EC%97%90%20%EC%96%91%EC%9D%B4%20%EB%A7%8E%EC%9D%B4%20%EC%9E%88%EB%8B%A4.)
^ko-Q0661-answer

**ko-Q0662** — 목초지에 양이 많이 있다.

There are a lot of sheep in the pasture.

Expected form: **있다**

Why: Existence and absence. [[Korean#^ko-Q0662|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%AA%A9%EC%B4%88%EC%A7%80%EC%97%90%20%EC%96%91%EC%9D%B4%20%EB%A7%8E%EC%9D%B4%20%EC%9E%88%EB%8B%A4.)
^ko-Q0662-answer

**ko-Q0663** — 나는 이 소음을 참을 수 없다.

I cannot stand this noise.

Expected form: **없다**

Why: Existence and absence. [[Korean#^ko-Q0663|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%EC%9D%B4%20%EC%86%8C%EC%9D%8C%EC%9D%84%20%EC%B0%B8%EC%9D%84%20%EC%88%98%20%EC%97%86%EB%8B%A4.)
^ko-Q0663-answer

**ko-Q0664** — 나는 이 소음을 참을 수 없다.

I cannot stand this noise.

Why: Existence and absence. [[Korean#^ko-Q0664|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%EC%9D%B4%20%EC%86%8C%EC%9D%8C%EC%9D%84%20%EC%B0%B8%EC%9D%84%20%EC%88%98%20%EC%97%86%EB%8B%A4.)
^ko-Q0664-answer

**ko-Q0665** — 우린 애가 한 명 있다.

We have one kid.

Why: Existence and absence. [[Korean#^ko-Q0665|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9A%B0%EB%A6%B0%20%EC%95%A0%EA%B0%80%20%ED%95%9C%20%EB%AA%85%20%EC%9E%88%EB%8B%A4.)
^ko-Q0665-answer

**ko-Q0666** — 우린 애가 한 명 있다.

We have one kid.

있다 and 없다 express existence/absence and some possession. Their complements do not behave exactly like English have objects. Location and subject marking remain important.

Why: Existence and absence. [[Korean#^ko-Q0666|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9A%B0%EB%A6%B0%20%EC%95%A0%EA%B0%80%20%ED%95%9C%20%EB%AA%85%20%EC%9E%88%EB%8B%A4.)
^ko-Q0666-answer

**ko-Q0667** — 너는 톰에게서 많은 동정심을 바랄 수는 없다.

You can't expect much sympathy from Tom.

Expected form: **없다**

Why: Existence and absence. [[Korean#^ko-Q0667|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%84%88%EB%8A%94%20%ED%86%B0%EC%97%90%EA%B2%8C%EC%84%9C%20%EB%A7%8E%EC%9D%80%20%EB%8F%99%EC%A0%95%EC%8B%AC%EC%9D%84%20%EB%B0%94%EB%9E%84%20%EC%88%98%EB%8A%94%20%EC%97%86%EB%8B%A4.)
^ko-Q0667-answer

**ko-Q0668** — 너는 톰에게서 많은 동정심을 바랄 수는 없다.

You can't expect much sympathy from Tom.

Expected form: **없다**

Why: Existence and absence. [[Korean#^ko-Q0668|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%84%88%EB%8A%94%20%ED%86%B0%EC%97%90%EA%B2%8C%EC%84%9C%20%EB%A7%8E%EC%9D%80%20%EB%8F%99%EC%A0%95%EC%8B%AC%EC%9D%84%20%EB%B0%94%EB%9E%84%20%EC%88%98%EB%8A%94%20%EC%97%86%EB%8B%A4.)
^ko-Q0668-answer

**ko-Q0669** — 글쓴이들은 저 집에 있다.

The writers are in that house.

Expected form: **있다**

Why: Existence and absence. [[Korean#^ko-Q0669|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B8%80%EC%93%B4%EC%9D%B4%EB%93%A4%EC%9D%80%20%EC%A0%80%20%EC%A7%91%EC%97%90%20%EC%9E%88%EB%8B%A4.)
^ko-Q0669-answer

**ko-Q0670** — 글쓴이들은 저 집에 있다.

The writers are in that house.

Why: Existence and absence. [[Korean#^ko-Q0670|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B8%80%EC%93%B4%EC%9D%B4%EB%93%A4%EC%9D%80%20%EC%A0%80%20%EC%A7%91%EC%97%90%20%EC%9E%88%EB%8B%A4.)
^ko-Q0670-answer

**ko-Q0671** — 네가 그것을 했다는 것을 이미 알고 있다.

I already know you did that.

Why: Existence and absence. [[Korean#^ko-Q0671|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%84%A4%EA%B0%80%20%EA%B7%B8%EA%B2%83%EC%9D%84%20%ED%96%88%EB%8B%A4%EB%8A%94%20%EA%B2%83%EC%9D%84%20%EC%9D%B4%EB%AF%B8%20%EC%95%8C%EA%B3%A0%20%EC%9E%88%EB%8B%A4.)
^ko-Q0671-answer

**ko-Q0672** — 네가 그것을 했다는 것을 이미 알고 있다.

I already know you did that.

있다 and 없다 express existence/absence and some possession. Their complements do not behave exactly like English have objects. Location and subject marking remain important.

Why: Existence and absence. [[Korean#^ko-Q0672|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%84%A4%EA%B0%80%20%EA%B7%B8%EA%B2%83%EC%9D%84%20%ED%96%88%EB%8B%A4%EB%8A%94%20%EA%B2%83%EC%9D%84%20%EC%9D%B4%EB%AF%B8%20%EC%95%8C%EA%B3%A0%20%EC%9E%88%EB%8B%A4.)
^ko-Q0672-answer

**ko-Q0673** — 이 타워의 꼭대기에 회전하는 식당이 있다.

There is a rotating restaurant at the top of this tower.

Expected form: **있다**

Why: Existence and absence. [[Korean#^ko-Q0673|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9D%B4%20%ED%83%80%EC%9B%8C%EC%9D%98%20%EA%BC%AD%EB%8C%80%EA%B8%B0%EC%97%90%20%ED%9A%8C%EC%A0%84%ED%95%98%EB%8A%94%20%EC%8B%9D%EB%8B%B9%EC%9D%B4%20%EC%9E%88%EB%8B%A4.)
^ko-Q0673-answer

**ko-Q0674** — 이 타워의 꼭대기에 회전하는 식당이 있다.

There is a rotating restaurant at the top of this tower.

Expected form: **있다**

Why: Existence and absence. [[Korean#^ko-Q0674|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9D%B4%20%ED%83%80%EC%9B%8C%EC%9D%98%20%EA%BC%AD%EB%8C%80%EA%B8%B0%EC%97%90%20%ED%9A%8C%EC%A0%84%ED%95%98%EB%8A%94%20%EC%8B%9D%EB%8B%B9%EC%9D%B4%20%EC%9E%88%EB%8B%A4.)
^ko-Q0674-answer

**ko-Q0675** — 공부할 방이 없다.

I have no room to study in.

Expected form: **없다**

Why: Existence and absence. [[Korean#^ko-Q0675|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B3%B5%EB%B6%80%ED%95%A0%20%EB%B0%A9%EC%9D%B4%20%EC%97%86%EB%8B%A4.)
^ko-Q0675-answer

**ko-Q0676** — 공부할 방이 없다.

I have no room to study in.

Why: Existence and absence. [[Korean#^ko-Q0676|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B3%B5%EB%B6%80%ED%95%A0%20%EB%B0%A9%EC%9D%B4%20%EC%97%86%EB%8B%A4.)
^ko-Q0676-answer

**ko-Q0677** — 아이를 살아 있는 상태로 찾을 희망이 빠르게 사라지고 있다.

Hope of finding the child alive is fading rapidly.

Why: Existence and absence. [[Korean#^ko-Q0677|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%95%84%EC%9D%B4%EB%A5%BC%20%EC%82%B4%EC%95%84%20%EC%9E%88%EB%8A%94%20%EC%83%81%ED%83%9C%EB%A1%9C%20%EC%B0%BE%EC%9D%84%20%ED%9D%AC%EB%A7%9D%EC%9D%B4%20%EB%B9%A0%EB%A5%B4%EA%B2%8C%20%EC%82%AC%EB%9D%BC%EC%A7%80%EA%B3%A0%20%EC%9E%88%EB%8B%A4.)
^ko-Q0677-answer

**ko-Q0678** — 아이를 살아 있는 상태로 찾을 희망이 빠르게 사라지고 있다.

Hope of finding the child alive is fading rapidly.

있다 and 없다 express existence/absence and some possession. Their complements do not behave exactly like English have objects. Location and subject marking remain important.

Why: Existence and absence. [[Korean#^ko-Q0678|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%95%84%EC%9D%B4%EB%A5%BC%20%EC%82%B4%EC%95%84%20%EC%9E%88%EB%8A%94%20%EC%83%81%ED%83%9C%EB%A1%9C%20%EC%B0%BE%EC%9D%84%20%ED%9D%AC%EB%A7%9D%EC%9D%B4%20%EB%B9%A0%EB%A5%B4%EA%B2%8C%20%EC%82%AC%EB%9D%BC%EC%A7%80%EA%B3%A0%20%EC%9E%88%EB%8B%A4.)
^ko-Q0678-answer

**ko-Q0679** — 나는 정말 피곤해지고 있다.

I'm getting really tired.

Expected form: **있다**

Why: Existence and absence. [[Korean#^ko-Q0679|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%EC%A0%95%EB%A7%90%20%ED%94%BC%EA%B3%A4%ED%95%B4%EC%A7%80%EA%B3%A0%20%EC%9E%88%EB%8B%A4.)
^ko-Q0679-answer

**ko-Q0680** — 나는 정말 피곤해지고 있다.

I'm getting really tired.

Expected form: **있다**

Why: Existence and absence. [[Korean#^ko-Q0680|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%EC%A0%95%EB%A7%90%20%ED%94%BC%EA%B3%A4%ED%95%B4%EC%A7%80%EA%B3%A0%20%EC%9E%88%EB%8B%A4.)
^ko-Q0680-answer

**ko-Q0681** — 톰은 응접실에 있다.

Tom is in the drawing room.

Expected form: **있다**

Why: Existence and absence. [[Korean#^ko-Q0681|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EC%9D%91%EC%A0%91%EC%8B%A4%EC%97%90%20%EC%9E%88%EB%8B%A4.)
^ko-Q0681-answer

**ko-Q0682** — 톰은 응접실에 있다.

Tom is in the drawing room.

Why: Existence and absence. [[Korean#^ko-Q0682|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EC%9D%91%EC%A0%91%EC%8B%A4%EC%97%90%20%EC%9E%88%EB%8B%A4.)
^ko-Q0682-answer

**ko-Q0683** — 내가 날 수 있다면 좋을 텐데.

I wish I could fly.

Why: Existence and absence. [[Korean#^ko-Q0683|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%B4%EA%B0%80%20%EB%82%A0%20%EC%88%98%20%EC%9E%88%EB%8B%A4%EB%A9%B4%20%EC%A2%8B%EC%9D%84%20%ED%85%90%EB%8D%B0.)
^ko-Q0683-answer

**ko-Q0684** — 내가 날 수 있다면 좋을 텐데.

I wish I could fly.

있다 and 없다 express existence/absence and some possession. Their complements do not behave exactly like English have objects. Location and subject marking remain important.

Why: Existence and absence. [[Korean#^ko-Q0684|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%B4%EA%B0%80%20%EB%82%A0%20%EC%88%98%20%EC%9E%88%EB%8B%A4%EB%A9%B4%20%EC%A2%8B%EC%9D%84%20%ED%85%90%EB%8D%B0.)
^ko-Q0684-answer

**ko-Q0685** — 그 남자는 자가용이 있다.

He has his own car.

Expected form: **있다**

Why: Existence and absence. [[Korean#^ko-Q0685|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%20%EB%82%A8%EC%9E%90%EB%8A%94%20%EC%9E%90%EA%B0%80%EC%9A%A9%EC%9D%B4%20%EC%9E%88%EB%8B%A4.)
^ko-Q0685-answer

**ko-Q0686** — 그 남자는 자가용이 있다.

He has his own car.

Expected form: **있다**

Why: Existence and absence. [[Korean#^ko-Q0686|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%20%EB%82%A8%EC%9E%90%EB%8A%94%20%EC%9E%90%EA%B0%80%EC%9A%A9%EC%9D%B4%20%EC%9E%88%EB%8B%A4.)
^ko-Q0686-answer

**ko-Q0687** — 톰은 이해하고 있다는 듯이 고개를 끄덕였다.

Tom nodded understandingly.

Expected form: **있다**

Why: Existence and absence. [[Korean#^ko-Q0687|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EC%9D%B4%ED%95%B4%ED%95%98%EA%B3%A0%20%EC%9E%88%EB%8B%A4%EB%8A%94%20%EB%93%AF%EC%9D%B4%20%EA%B3%A0%EA%B0%9C%EB%A5%BC%20%EB%81%84%EB%8D%95%EC%98%80%EB%8B%A4.)
^ko-Q0687-answer

**ko-Q0688** — 톰은 이해하고 있다는 듯이 고개를 끄덕였다.

Tom nodded understandingly.

Why: Existence and absence. [[Korean#^ko-Q0688|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EC%9D%B4%ED%95%B4%ED%95%98%EA%B3%A0%20%EC%9E%88%EB%8B%A4%EB%8A%94%20%EB%93%AF%EC%9D%B4%20%EA%B3%A0%EA%B0%9C%EB%A5%BC%20%EB%81%84%EB%8D%95%EC%98%80%EB%8B%A4.)
^ko-Q0688-answer

**ko-Q0689** — 초등 학교가 점점 사라지고 있다.

Elementary schools are gradually disappearing.

Why: Existence and absence. [[Korean#^ko-Q0689|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%B4%88%EB%93%B1%20%ED%95%99%EA%B5%90%EA%B0%80%20%EC%A0%90%EC%A0%90%20%EC%82%AC%EB%9D%BC%EC%A7%80%EA%B3%A0%20%EC%9E%88%EB%8B%A4.)
^ko-Q0689-answer

**ko-Q0690** — 초등 학교가 점점 사라지고 있다.

Elementary schools are gradually disappearing.

있다 and 없다 express existence/absence and some possession. Their complements do not behave exactly like English have objects. Location and subject marking remain important.

Why: Existence and absence. [[Korean#^ko-Q0690|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%B4%88%EB%93%B1%20%ED%95%99%EA%B5%90%EA%B0%80%20%EC%A0%90%EC%A0%90%20%EC%82%AC%EB%9D%BC%EC%A7%80%EA%B3%A0%20%EC%9E%88%EB%8B%A4.)
^ko-Q0690-answer

**ko-Q0691** — 너무 어두워서 잘 볼 수 없다.

It's too dark so I can't see very well.

Expected form: **없다**

Why: Existence and absence. [[Korean#^ko-Q0691|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%84%88%EB%AC%B4%20%EC%96%B4%EB%91%90%EC%9B%8C%EC%84%9C%20%EC%9E%98%20%EB%B3%BC%20%EC%88%98%20%EC%97%86%EB%8B%A4.)
^ko-Q0691-answer

**ko-Q0692** — 너무 어두워서 잘 볼 수 없다.

It's too dark so I can't see very well.

Expected form: **없다**

Why: Existence and absence. [[Korean#^ko-Q0692|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%84%88%EB%AC%B4%20%EC%96%B4%EB%91%90%EC%9B%8C%EC%84%9C%20%EC%9E%98%20%EB%B3%BC%20%EC%88%98%20%EC%97%86%EB%8B%A4.)
^ko-Q0692-answer

**ko-Q0693** — 바다에는 섬들이 있다.

There are islands in the sea.

Expected form: **있다**

Why: Existence and absence. [[Korean#^ko-Q0693|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%B0%94%EB%8B%A4%EC%97%90%EB%8A%94%20%EC%84%AC%EB%93%A4%EC%9D%B4%20%EC%9E%88%EB%8B%A4.)
^ko-Q0693-answer

**ko-Q0694** — 바다에는 섬들이 있다.

There are islands in the sea.

Why: Existence and absence. [[Korean#^ko-Q0694|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%B0%94%EB%8B%A4%EC%97%90%EB%8A%94%20%EC%84%AC%EB%93%A4%EC%9D%B4%20%EC%9E%88%EB%8B%A4.)
^ko-Q0694-answer

**ko-Q0695** — 나는 그가 자신의 인생 경험에 대해 열변을 토하는 것을 참을 수가 없다.

I can't stand him holding forth about his life experience.

Why: Existence and absence. [[Korean#^ko-Q0695|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%EA%B7%B8%EA%B0%80%20%EC%9E%90%EC%8B%A0%EC%9D%98%20%EC%9D%B8%EC%83%9D%20%EA%B2%BD%ED%97%98%EC%97%90%20%EB%8C%80%ED%95%B4%20%EC%97%B4%EB%B3%80%EC%9D%84%20%ED%86%A0%ED%95%98%EB%8A%94%20%EA%B2%83%EC%9D%84%20%EC%B0%B8%EC%9D%84%20%EC%88%98%EA%B0%80%20%EC%97%86%EB%8B%A4.)
^ko-Q0695-answer

**ko-Q0696** — 나는 그가 자신의 인생 경험에 대해 열변을 토하는 것을 참을 수가 없다.

I can't stand him holding forth about his life experience.

있다 and 없다 express existence/absence and some possession. Their complements do not behave exactly like English have objects. Location and subject marking remain important.

Why: Existence and absence. [[Korean#^ko-Q0696|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%EA%B7%B8%EA%B0%80%20%EC%9E%90%EC%8B%A0%EC%9D%98%20%EC%9D%B8%EC%83%9D%20%EA%B2%BD%ED%97%98%EC%97%90%20%EB%8C%80%ED%95%B4%20%EC%97%B4%EB%B3%80%EC%9D%84%20%ED%86%A0%ED%95%98%EB%8A%94%20%EA%B2%83%EC%9D%84%20%EC%B0%B8%EC%9D%84%20%EC%88%98%EA%B0%80%20%EC%97%86%EB%8B%A4.)
^ko-Q0696-answer

**ko-Q0697** — 전혀 위험을 감수하지 않으면, 아무 것도 얻을 수 없다.

One who doesn't take risks will not win.

Expected form: **없다**

Why: Existence and absence. [[Korean#^ko-Q0697|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A0%84%ED%98%80%20%EC%9C%84%ED%97%98%EC%9D%84%20%EA%B0%90%EC%88%98%ED%95%98%EC%A7%80%20%EC%95%8A%EC%9C%BC%EB%A9%B4%2C%20%EC%95%84%EB%AC%B4%20%EA%B2%83%EB%8F%84%20%EC%96%BB%EC%9D%84%20%EC%88%98%20%EC%97%86%EB%8B%A4.)
^ko-Q0697-answer

**ko-Q0698** — 전혀 위험을 감수하지 않으면, 아무 것도 얻을 수 없다.

One who doesn't take risks will not win.

Expected form: **없다**

Why: Existence and absence. [[Korean#^ko-Q0698|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A0%84%ED%98%80%20%EC%9C%84%ED%97%98%EC%9D%84%20%EA%B0%90%EC%88%98%ED%95%98%EC%A7%80%20%EC%95%8A%EC%9C%BC%EB%A9%B4%2C%20%EC%95%84%EB%AC%B4%20%EA%B2%83%EB%8F%84%20%EC%96%BB%EC%9D%84%20%EC%88%98%20%EC%97%86%EB%8B%A4.)
^ko-Q0698-answer

**ko-Q0699** — 나는 일찍 자기 때문에 일출을 보려 일찍 일어날 수 있다.

I go to bed early so I can get up to capture the sunrise.

Expected form: **있다**

Why: Existence and absence. [[Korean#^ko-Q0699|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%EC%9D%BC%EC%B0%8D%20%EC%9E%90%EA%B8%B0%20%EB%95%8C%EB%AC%B8%EC%97%90%20%EC%9D%BC%EC%B6%9C%EC%9D%84%20%EB%B3%B4%EB%A0%A4%20%EC%9D%BC%EC%B0%8D%20%EC%9D%BC%EC%96%B4%EB%82%A0%20%EC%88%98%20%EC%9E%88%EB%8B%A4.)
^ko-Q0699-answer

**ko-Q0700** — 나는 일찍 자기 때문에 일출을 보려 일찍 일어날 수 있다.

I go to bed early so I can get up to capture the sunrise.

Why: Existence and absence. [[Korean#^ko-Q0700|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%EC%9D%BC%EC%B0%8D%20%EC%9E%90%EA%B8%B0%20%EB%95%8C%EB%AC%B8%EC%97%90%20%EC%9D%BC%EC%B6%9C%EC%9D%84%20%EB%B3%B4%EB%A0%A4%20%EC%9D%BC%EC%B0%8D%20%EC%9D%BC%EC%96%B4%EB%82%A0%20%EC%88%98%20%EC%9E%88%EB%8B%A4.)
^ko-Q0700-answer


### Answers 701–750

**ko-Q0701** — 톰은 수년 간 우울증과 싸우고 있어.

Tom has been battling depression for many years.

Why: Progressive forms. [[Korean#^ko-Q0701|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EC%88%98%EB%85%84%20%EA%B0%84%20%EC%9A%B0%EC%9A%B8%EC%A6%9D%EA%B3%BC%20%EC%8B%B8%EC%9A%B0%EA%B3%A0%20%EC%9E%88%EC%96%B4.)
^ko-Q0701-answer

**ko-Q0702** — 톰은 수년 간 우울증과 싸우고 있어.

Tom has been battling depression for many years.

A verb stem plus -고 있다 often marks ongoing activity. Some result-state readings require another pattern. The lexical verb and context determine aspect.

Why: Progressive forms. [[Korean#^ko-Q0702|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EC%88%98%EB%85%84%20%EA%B0%84%20%EC%9A%B0%EC%9A%B8%EC%A6%9D%EA%B3%BC%20%EC%8B%B8%EC%9A%B0%EA%B3%A0%20%EC%9E%88%EC%96%B4.)
^ko-Q0702-answer

**ko-Q0703** — 톰이랑 나는 집을 구하고 있어.

Tom and I are house hunting.

Expected form: **고 있어**

Why: Progressive forms. [[Korean#^ko-Q0703|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%B4%EB%9E%91%20%EB%82%98%EB%8A%94%20%EC%A7%91%EC%9D%84%20%EA%B5%AC%ED%95%98%EA%B3%A0%20%EC%9E%88%EC%96%B4.)
^ko-Q0703-answer

**ko-Q0704** — 톰이랑 나는 집을 구하고 있어.

Tom and I are house hunting.

Expected form: **고 있어**

Why: Progressive forms. [[Korean#^ko-Q0704|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%B4%EB%9E%91%20%EB%82%98%EB%8A%94%20%EC%A7%91%EC%9D%84%20%EA%B5%AC%ED%95%98%EA%B3%A0%20%EC%9E%88%EC%96%B4.)
^ko-Q0704-answer

**ko-Q0705** — 나 기대하고 있어.

I look forward to it.

Expected form: **고 있어**

Why: Progressive forms. [[Korean#^ko-Q0705|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%20%EA%B8%B0%EB%8C%80%ED%95%98%EA%B3%A0%20%EC%9E%88%EC%96%B4.)
^ko-Q0705-answer

**ko-Q0706** — 나 기대하고 있어.

I look forward to it.

Why: Progressive forms. [[Korean#^ko-Q0706|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%20%EA%B8%B0%EB%8C%80%ED%95%98%EA%B3%A0%20%EC%9E%88%EC%96%B4.)
^ko-Q0706-answer

**ko-Q0707** — 나는 음악듣고 있어. 넌?

I'm listening to music, and you?

Why: Progressive forms. [[Korean#^ko-Q0707|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%EC%9D%8C%EC%95%85%EB%93%A3%EA%B3%A0%20%EC%9E%88%EC%96%B4.%20%EB%84%8C%3F)
^ko-Q0707-answer

**ko-Q0708** — 나는 음악듣고 있어. 넌?

I'm listening to music, and you?

A verb stem plus -고 있다 often marks ongoing activity. Some result-state readings require another pattern. The lexical verb and context determine aspect.

Why: Progressive forms. [[Korean#^ko-Q0708|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%EC%9D%8C%EC%95%85%EB%93%A3%EA%B3%A0%20%EC%9E%88%EC%96%B4.%20%EB%84%8C%3F)
^ko-Q0708-answer

**ko-Q0709** — 톰은 파란 바지를 입고 있어.

Tom is wearing a blue jeans.

Expected form: **고 있어**

Why: Progressive forms. [[Korean#^ko-Q0709|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%ED%8C%8C%EB%9E%80%20%EB%B0%94%EC%A7%80%EB%A5%BC%20%EC%9E%85%EA%B3%A0%20%EC%9E%88%EC%96%B4.)
^ko-Q0709-answer

**ko-Q0710** — 톰은 파란 바지를 입고 있어.

Tom is wearing a blue jeans.

Expected form: **고 있어**

Why: Progressive forms. [[Korean#^ko-Q0710|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%ED%8C%8C%EB%9E%80%20%EB%B0%94%EC%A7%80%EB%A5%BC%20%EC%9E%85%EA%B3%A0%20%EC%9E%88%EC%96%B4.)
^ko-Q0710-answer

**ko-Q0711** — 나는 양심의 가책을 느끼고 있다.

I have a guilty consciousness.

Expected form: **고 있다**

Why: Progressive forms. [[Korean#^ko-Q0711|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%EC%96%91%EC%8B%AC%EC%9D%98%20%EA%B0%80%EC%B1%85%EC%9D%84%20%EB%8A%90%EB%81%BC%EA%B3%A0%20%EC%9E%88%EB%8B%A4.)
^ko-Q0711-answer

**ko-Q0712** — 나는 양심의 가책을 느끼고 있다.

I have a guilty consciousness.

Why: Progressive forms. [[Korean#^ko-Q0712|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%EC%96%91%EC%8B%AC%EC%9D%98%20%EA%B0%80%EC%B1%85%EC%9D%84%20%EB%8A%90%EB%81%BC%EA%B3%A0%20%EC%9E%88%EB%8B%A4.)
^ko-Q0712-answer

**ko-Q0713** — 한국은 떠오르고 있다.

Korea is now up and coming.

Why: Progressive forms. [[Korean#^ko-Q0713|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%95%9C%EA%B5%AD%EC%9D%80%20%EB%96%A0%EC%98%A4%EB%A5%B4%EA%B3%A0%20%EC%9E%88%EB%8B%A4.)
^ko-Q0713-answer

**ko-Q0714** — 한국은 떠오르고 있다.

Korea is now up and coming.

A verb stem plus -고 있다 often marks ongoing activity. Some result-state readings require another pattern. The lexical verb and context determine aspect.

Why: Progressive forms. [[Korean#^ko-Q0714|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%95%9C%EA%B5%AD%EC%9D%80%20%EB%96%A0%EC%98%A4%EB%A5%B4%EA%B3%A0%20%EC%9E%88%EB%8B%A4.)
^ko-Q0714-answer

**ko-Q0715** — 그는 전화를 기다리고 있다.

He is waiting for a telephone call.

Expected form: **고 있다**

Why: Progressive forms. [[Korean#^ko-Q0715|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EB%8A%94%20%EC%A0%84%ED%99%94%EB%A5%BC%20%EA%B8%B0%EB%8B%A4%EB%A6%AC%EA%B3%A0%20%EC%9E%88%EB%8B%A4.)
^ko-Q0715-answer

**ko-Q0716** — 그는 전화를 기다리고 있다.

He is waiting for a telephone call.

Expected form: **고 있다**

Why: Progressive forms. [[Korean#^ko-Q0716|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EB%8A%94%20%EC%A0%84%ED%99%94%EB%A5%BC%20%EA%B8%B0%EB%8B%A4%EB%A6%AC%EA%B3%A0%20%EC%9E%88%EB%8B%A4.)
^ko-Q0716-answer

**ko-Q0717** — 난 프랑스 소설을 읽고 있어.

I'm reading a French novel.

Expected form: **고 있어**

Why: Progressive forms. [[Korean#^ko-Q0717|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%9C%20%ED%94%84%EB%9E%91%EC%8A%A4%20%EC%86%8C%EC%84%A4%EC%9D%84%20%EC%9D%BD%EA%B3%A0%20%EC%9E%88%EC%96%B4.)
^ko-Q0717-answer

**ko-Q0718** — 난 프랑스 소설을 읽고 있어.

I'm reading a French novel.

Why: Progressive forms. [[Korean#^ko-Q0718|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%9C%20%ED%94%84%EB%9E%91%EC%8A%A4%20%EC%86%8C%EC%84%A4%EC%9D%84%20%EC%9D%BD%EA%B3%A0%20%EC%9E%88%EC%96%B4.)
^ko-Q0718-answer

**ko-Q0719** — 사회가 변화하고 있다.

Society is changing.

Why: Progressive forms. [[Korean#^ko-Q0719|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%82%AC%ED%9A%8C%EA%B0%80%20%EB%B3%80%ED%99%94%ED%95%98%EA%B3%A0%20%EC%9E%88%EB%8B%A4.)
^ko-Q0719-answer

**ko-Q0720** — 사회가 변화하고 있다.

Society is changing.

A verb stem plus -고 있다 often marks ongoing activity. Some result-state readings require another pattern. The lexical verb and context determine aspect.

Why: Progressive forms. [[Korean#^ko-Q0720|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%82%AC%ED%9A%8C%EA%B0%80%20%EB%B3%80%ED%99%94%ED%95%98%EA%B3%A0%20%EC%9E%88%EB%8B%A4.)
^ko-Q0720-answer

**ko-Q0721** — 톰은 뭔가를 쏘고 있어.

Tom is shouting something.

Expected form: **고 있어**

Why: Progressive forms. [[Korean#^ko-Q0721|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EB%AD%94%EA%B0%80%EB%A5%BC%20%EC%8F%98%EA%B3%A0%20%EC%9E%88%EC%96%B4.)
^ko-Q0721-answer

**ko-Q0722** — 톰은 뭔가를 쏘고 있어.

Tom is shouting something.

Expected form: **고 있어**

Why: Progressive forms. [[Korean#^ko-Q0722|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EB%AD%94%EA%B0%80%EB%A5%BC%20%EC%8F%98%EA%B3%A0%20%EC%9E%88%EC%96%B4.)
^ko-Q0722-answer

**ko-Q0723** — 톰은 노란 셔츠를 입고 있어.

Tom is wearing a yellow shirt.

Expected form: **고 있어**

Why: Progressive forms. [[Korean#^ko-Q0723|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EB%85%B8%EB%9E%80%20%EC%85%94%EC%B8%A0%EB%A5%BC%20%EC%9E%85%EA%B3%A0%20%EC%9E%88%EC%96%B4.)
^ko-Q0723-answer

**ko-Q0724** — 톰은 노란 셔츠를 입고 있어.

Tom is wearing a yellow shirt.

Why: Progressive forms. [[Korean#^ko-Q0724|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EB%85%B8%EB%9E%80%20%EC%85%94%EC%B8%A0%EB%A5%BC%20%EC%9E%85%EA%B3%A0%20%EC%9E%88%EC%96%B4.)
^ko-Q0724-answer

**ko-Q0725** — 기름이나 석탄과 같은 원자재의 가격이 계속 상승하고 있다.

The prices of raw materials such as oil or coal continue to rise.

Why: Progressive forms. [[Korean#^ko-Q0725|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B8%B0%EB%A6%84%EC%9D%B4%EB%82%98%20%EC%84%9D%ED%83%84%EA%B3%BC%20%EA%B0%99%EC%9D%80%20%EC%9B%90%EC%9E%90%EC%9E%AC%EC%9D%98%20%EA%B0%80%EA%B2%A9%EC%9D%B4%20%EA%B3%84%EC%86%8D%20%EC%83%81%EC%8A%B9%ED%95%98%EA%B3%A0%20%EC%9E%88%EB%8B%A4.)
^ko-Q0725-answer

**ko-Q0726** — 기름이나 석탄과 같은 원자재의 가격이 계속 상승하고 있다.

The prices of raw materials such as oil or coal continue to rise.

A verb stem plus -고 있다 often marks ongoing activity. Some result-state readings require another pattern. The lexical verb and context determine aspect.

Why: Progressive forms. [[Korean#^ko-Q0726|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B8%B0%EB%A6%84%EC%9D%B4%EB%82%98%20%EC%84%9D%ED%83%84%EA%B3%BC%20%EA%B0%99%EC%9D%80%20%EC%9B%90%EC%9E%90%EC%9E%AC%EC%9D%98%20%EA%B0%80%EA%B2%A9%EC%9D%B4%20%EA%B3%84%EC%86%8D%20%EC%83%81%EC%8A%B9%ED%95%98%EA%B3%A0%20%EC%9E%88%EB%8B%A4.)
^ko-Q0726-answer

**ko-Q0727** — 나는 고양이 두 마리를 가지고 있다.

I have two cats.

Expected form: **고 있다**

Why: Progressive forms. [[Korean#^ko-Q0727|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%EA%B3%A0%EC%96%91%EC%9D%B4%20%EB%91%90%20%EB%A7%88%EB%A6%AC%EB%A5%BC%20%EA%B0%80%EC%A7%80%EA%B3%A0%20%EC%9E%88%EB%8B%A4.)
^ko-Q0727-answer

**ko-Q0728** — 나는 고양이 두 마리를 가지고 있다.

I have two cats.

Expected form: **고 있다**

Why: Progressive forms. [[Korean#^ko-Q0728|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%EA%B3%A0%EC%96%91%EC%9D%B4%20%EB%91%90%20%EB%A7%88%EB%A6%AC%EB%A5%BC%20%EA%B0%80%EC%A7%80%EA%B3%A0%20%EC%9E%88%EB%8B%A4.)
^ko-Q0728-answer

**ko-Q0729** — 이 투명한 액체는 독 성분을 포함하고 있다.

This transparent liquid contains a kind of poison.

Expected form: **고 있다**

Why: Progressive forms. [[Korean#^ko-Q0729|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9D%B4%20%ED%88%AC%EB%AA%85%ED%95%9C%20%EC%95%A1%EC%B2%B4%EB%8A%94%20%EB%8F%85%20%EC%84%B1%EB%B6%84%EC%9D%84%20%ED%8F%AC%ED%95%A8%ED%95%98%EA%B3%A0%20%EC%9E%88%EB%8B%A4.)
^ko-Q0729-answer

**ko-Q0730** — 이 투명한 액체는 독 성분을 포함하고 있다.

This transparent liquid contains a kind of poison.

Why: Progressive forms. [[Korean#^ko-Q0730|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9D%B4%20%ED%88%AC%EB%AA%85%ED%95%9C%20%EC%95%A1%EC%B2%B4%EB%8A%94%20%EB%8F%85%20%EC%84%B1%EB%B6%84%EC%9D%84%20%ED%8F%AC%ED%95%A8%ED%95%98%EA%B3%A0%20%EC%9E%88%EB%8B%A4.)
^ko-Q0730-answer

**ko-Q0731** — 왜 아직도 일하고 있어?

Why are you still working?

Why: Progressive forms. [[Korean#^ko-Q0731|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%99%9C%20%EC%95%84%EC%A7%81%EB%8F%84%20%EC%9D%BC%ED%95%98%EA%B3%A0%20%EC%9E%88%EC%96%B4%3F)
^ko-Q0731-answer

**ko-Q0732** — 왜 아직도 일하고 있어?

Why are you still working?

A verb stem plus -고 있다 often marks ongoing activity. Some result-state readings require another pattern. The lexical verb and context determine aspect.

Why: Progressive forms. [[Korean#^ko-Q0732|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%99%9C%20%EC%95%84%EC%A7%81%EB%8F%84%20%EC%9D%BC%ED%95%98%EA%B3%A0%20%EC%9E%88%EC%96%B4%3F)
^ko-Q0732-answer

**ko-Q0733** — 밀리는 사과를 먹고 있어요.

Millie is eating an apple.

Expected form: **고 있어**

Why: Progressive forms. [[Korean#^ko-Q0733|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%B0%80%EB%A6%AC%EB%8A%94%20%EC%82%AC%EA%B3%BC%EB%A5%BC%20%EB%A8%B9%EA%B3%A0%20%EC%9E%88%EC%96%B4%EC%9A%94.)
^ko-Q0733-answer

**ko-Q0734** — 밀리는 사과를 먹고 있어요.

Millie is eating an apple.

Expected form: **고 있어**

Why: Progressive forms. [[Korean#^ko-Q0734|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%B0%80%EB%A6%AC%EB%8A%94%20%EC%82%AC%EA%B3%BC%EB%A5%BC%20%EB%A8%B9%EA%B3%A0%20%EC%9E%88%EC%96%B4%EC%9A%94.)
^ko-Q0734-answer

**ko-Q0735** — 톰은 총을 들고 있어.

Tom is holding a gun.

Expected form: **고 있어**

Why: Progressive forms. [[Korean#^ko-Q0735|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EC%B4%9D%EC%9D%84%20%EB%93%A4%EA%B3%A0%20%EC%9E%88%EC%96%B4.)
^ko-Q0735-answer

**ko-Q0736** — 톰은 총을 들고 있어.

Tom is holding a gun.

Why: Progressive forms. [[Korean#^ko-Q0736|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EC%B4%9D%EC%9D%84%20%EB%93%A4%EA%B3%A0%20%EC%9E%88%EC%96%B4.)
^ko-Q0736-answer

**ko-Q0737** — 사람들이 지금 죽어가고 있어.

People are dying now.

Why: Progressive forms. [[Korean#^ko-Q0737|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%82%AC%EB%9E%8C%EB%93%A4%EC%9D%B4%20%EC%A7%80%EA%B8%88%20%EC%A3%BD%EC%96%B4%EA%B0%80%EA%B3%A0%20%EC%9E%88%EC%96%B4.)
^ko-Q0737-answer

**ko-Q0738** — 사람들이 지금 죽어가고 있어.

People are dying now.

A verb stem plus -고 있다 often marks ongoing activity. Some result-state readings require another pattern. The lexical verb and context determine aspect.

Why: Progressive forms. [[Korean#^ko-Q0738|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%82%AC%EB%9E%8C%EB%93%A4%EC%9D%B4%20%EC%A7%80%EA%B8%88%20%EC%A3%BD%EC%96%B4%EA%B0%80%EA%B3%A0%20%EC%9E%88%EC%96%B4.)
^ko-Q0738-answer

**ko-Q0739** — 너는 날 천천히 죽이고 있어.

You are killing me slowly.

Expected form: **고 있어**

Why: Progressive forms. [[Korean#^ko-Q0739|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%84%88%EB%8A%94%20%EB%82%A0%20%EC%B2%9C%EC%B2%9C%ED%9E%88%20%EC%A3%BD%EC%9D%B4%EA%B3%A0%20%EC%9E%88%EC%96%B4.)
^ko-Q0739-answer

**ko-Q0740** — 너는 날 천천히 죽이고 있어.

You are killing me slowly.

Expected form: **고 있어**

Why: Progressive forms. [[Korean#^ko-Q0740|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%84%88%EB%8A%94%20%EB%82%A0%20%EC%B2%9C%EC%B2%9C%ED%9E%88%20%EC%A3%BD%EC%9D%B4%EA%B3%A0%20%EC%9E%88%EC%96%B4.)
^ko-Q0740-answer

**ko-Q0741** — 그녀는 의학을 전공하고 있습니다.

She majors in medicine.

Expected form: **고 있습니다**

Why: Progressive forms. [[Korean#^ko-Q0741|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EB%85%80%EB%8A%94%20%EC%9D%98%ED%95%99%EC%9D%84%20%EC%A0%84%EA%B3%B5%ED%95%98%EA%B3%A0%20%EC%9E%88%EC%8A%B5%EB%8B%88%EB%8B%A4.)
^ko-Q0741-answer

**ko-Q0742** — 그녀는 의학을 전공하고 있습니다.

She majors in medicine.

Why: Progressive forms. [[Korean#^ko-Q0742|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EB%85%80%EB%8A%94%20%EC%9D%98%ED%95%99%EC%9D%84%20%EC%A0%84%EA%B3%B5%ED%95%98%EA%B3%A0%20%EC%9E%88%EC%8A%B5%EB%8B%88%EB%8B%A4.)
^ko-Q0742-answer

**ko-Q0743** — 난 아직도 프랑스어를 배우고 있어.

I'm still learning French.

Why: Progressive forms. [[Korean#^ko-Q0743|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%9C%20%EC%95%84%EC%A7%81%EB%8F%84%20%ED%94%84%EB%9E%91%EC%8A%A4%EC%96%B4%EB%A5%BC%20%EB%B0%B0%EC%9A%B0%EA%B3%A0%20%EC%9E%88%EC%96%B4.)
^ko-Q0743-answer

**ko-Q0744** — 난 아직도 프랑스어를 배우고 있어.

I'm still learning French.

A verb stem plus -고 있다 often marks ongoing activity. Some result-state readings require another pattern. The lexical verb and context determine aspect.

Why: Progressive forms. [[Korean#^ko-Q0744|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%9C%20%EC%95%84%EC%A7%81%EB%8F%84%20%ED%94%84%EB%9E%91%EC%8A%A4%EC%96%B4%EB%A5%BC%20%EB%B0%B0%EC%9A%B0%EA%B3%A0%20%EC%9E%88%EC%96%B4.)
^ko-Q0744-answer

**ko-Q0745** — 미국에서는 아편유사제 오남용으로 인해 매일 130명 이상의 사람들이 숨지고 있다.

More than 130 people in the United States die each day after abusing opioids.

Expected form: **고 있다**

Why: Progressive forms. [[Korean#^ko-Q0745|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%AF%B8%EA%B5%AD%EC%97%90%EC%84%9C%EB%8A%94%20%EC%95%84%ED%8E%B8%EC%9C%A0%EC%82%AC%EC%A0%9C%20%EC%98%A4%EB%82%A8%EC%9A%A9%EC%9C%BC%EB%A1%9C%20%EC%9D%B8%ED%95%B4%20%EB%A7%A4%EC%9D%BC%20130%EB%AA%85%20%EC%9D%B4%EC%83%81%EC%9D%98%20%EC%82%AC%EB%9E%8C%EB%93%A4%EC%9D%B4%20%EC%88%A8%EC%A7%80%EA%B3%A0%20%EC%9E%88%EB%8B%A4.)
^ko-Q0745-answer

**ko-Q0746** — 미국에서는 아편유사제 오남용으로 인해 매일 130명 이상의 사람들이 숨지고 있다.

More than 130 people in the United States die each day after abusing opioids.

Expected form: **고 있다**

Why: Progressive forms. [[Korean#^ko-Q0746|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%AF%B8%EA%B5%AD%EC%97%90%EC%84%9C%EB%8A%94%20%EC%95%84%ED%8E%B8%EC%9C%A0%EC%82%AC%EC%A0%9C%20%EC%98%A4%EB%82%A8%EC%9A%A9%EC%9C%BC%EB%A1%9C%20%EC%9D%B8%ED%95%B4%20%EB%A7%A4%EC%9D%BC%20130%EB%AA%85%20%EC%9D%B4%EC%83%81%EC%9D%98%20%EC%82%AC%EB%9E%8C%EB%93%A4%EC%9D%B4%20%EC%88%A8%EC%A7%80%EA%B3%A0%20%EC%9E%88%EB%8B%A4.)
^ko-Q0746-answer

**ko-Q0747** — 흥! 아무도 내가 만드는 문장을 번역 안하고 있어!

Hey! Nobody is translating my sentences!

Expected form: **고 있어**

Why: Progressive forms. [[Korean#^ko-Q0747|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%9D%A5%21%20%EC%95%84%EB%AC%B4%EB%8F%84%20%EB%82%B4%EA%B0%80%20%EB%A7%8C%EB%93%9C%EB%8A%94%20%EB%AC%B8%EC%9E%A5%EC%9D%84%20%EB%B2%88%EC%97%AD%20%EC%95%88%ED%95%98%EA%B3%A0%20%EC%9E%88%EC%96%B4%21)
^ko-Q0747-answer

**ko-Q0748** — 흥! 아무도 내가 만드는 문장을 번역 안하고 있어!

Hey! Nobody is translating my sentences!

Why: Progressive forms. [[Korean#^ko-Q0748|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%9D%A5%21%20%EC%95%84%EB%AC%B4%EB%8F%84%20%EB%82%B4%EA%B0%80%20%EB%A7%8C%EB%93%9C%EB%8A%94%20%EB%AC%B8%EC%9E%A5%EC%9D%84%20%EB%B2%88%EC%97%AD%20%EC%95%88%ED%95%98%EA%B3%A0%20%EC%9E%88%EC%96%B4%21)
^ko-Q0748-answer

**ko-Q0749** — 이 인류학자에 따르면 이 지역에서는 옛날 관습이 아직도 행해지고 있다.

The anthropologist says old customs still prevail in the province.

Why: Progressive forms. [[Korean#^ko-Q0749|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9D%B4%20%EC%9D%B8%EB%A5%98%ED%95%99%EC%9E%90%EC%97%90%20%EB%94%B0%EB%A5%B4%EB%A9%B4%20%EC%9D%B4%20%EC%A7%80%EC%97%AD%EC%97%90%EC%84%9C%EB%8A%94%20%EC%98%9B%EB%82%A0%20%EA%B4%80%EC%8A%B5%EC%9D%B4%20%EC%95%84%EC%A7%81%EB%8F%84%20%ED%96%89%ED%95%B4%EC%A7%80%EA%B3%A0%20%EC%9E%88%EB%8B%A4.)
^ko-Q0749-answer

**ko-Q0750** — 이 인류학자에 따르면 이 지역에서는 옛날 관습이 아직도 행해지고 있다.

The anthropologist says old customs still prevail in the province.

A verb stem plus -고 있다 often marks ongoing activity. Some result-state readings require another pattern. The lexical verb and context determine aspect.

Why: Progressive forms. [[Korean#^ko-Q0750|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9D%B4%20%EC%9D%B8%EB%A5%98%ED%95%99%EC%9E%90%EC%97%90%20%EB%94%B0%EB%A5%B4%EB%A9%B4%20%EC%9D%B4%20%EC%A7%80%EC%97%AD%EC%97%90%EC%84%9C%EB%8A%94%20%EC%98%9B%EB%82%A0%20%EA%B4%80%EC%8A%B5%EC%9D%B4%20%EC%95%84%EC%A7%81%EB%8F%84%20%ED%96%89%ED%95%B4%EC%A7%80%EA%B3%A0%20%EC%9E%88%EB%8B%A4.)
^ko-Q0750-answer


### Answers 751–800

**ko-Q0751** — 사공이 많으면 배가 산으로 간다.

Too many cooks spoil the broth.

Expected form: **많으면**

Why: Conditional linking. [[Korean#^ko-Q0751|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%82%AC%EA%B3%B5%EC%9D%B4%20%EB%A7%8E%EC%9C%BC%EB%A9%B4%20%EB%B0%B0%EA%B0%80%20%EC%82%B0%EC%9C%BC%EB%A1%9C%20%EA%B0%84%EB%8B%A4.)
^ko-Q0751-answer

**ko-Q0752** — 사공이 많으면 배가 산으로 간다.

Too many cooks spoil the broth.

Expected form: **많으면**

Why: Conditional linking. [[Korean#^ko-Q0752|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%82%AC%EA%B3%B5%EC%9D%B4%20%EB%A7%8E%EC%9C%BC%EB%A9%B4%20%EB%B0%B0%EA%B0%80%20%EC%82%B0%EC%9C%BC%EB%A1%9C%20%EA%B0%84%EB%8B%A4.)
^ko-Q0752-answer

**ko-Q0753** — 톰이 네가 이걸 하는 걸 본다면 울게 될 걸.

If Tom saw you doing that, he'd cry.

Expected form: **본다면**

Why: Conditional linking. [[Korean#^ko-Q0753|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%B4%20%EB%84%A4%EA%B0%80%20%EC%9D%B4%EA%B1%B8%20%ED%95%98%EB%8A%94%20%EA%B1%B8%20%EB%B3%B8%EB%8B%A4%EB%A9%B4%20%EC%9A%B8%EA%B2%8C%20%EB%90%A0%20%EA%B1%B8.)
^ko-Q0753-answer

**ko-Q0754** — 톰이 네가 이걸 하는 걸 본다면 울게 될 걸.

If Tom saw you doing that, he'd cry.

Why: Conditional linking. [[Korean#^ko-Q0754|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%B4%20%EB%84%A4%EA%B0%80%20%EC%9D%B4%EA%B1%B8%20%ED%95%98%EB%8A%94%20%EA%B1%B8%20%EB%B3%B8%EB%8B%A4%EB%A9%B4%20%EC%9A%B8%EA%B2%8C%20%EB%90%A0%20%EA%B1%B8.)
^ko-Q0754-answer

**ko-Q0755** — 너 그 사람을 오빠-동생으로 생각하니? 아니면 애인으로 사랑하니?

Do you love him like a brother or do you love-love him?

Why: Conditional linking. [[Korean#^ko-Q0755|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%84%88%20%EA%B7%B8%20%EC%82%AC%EB%9E%8C%EC%9D%84%20%EC%98%A4%EB%B9%A0-%EB%8F%99%EC%83%9D%EC%9C%BC%EB%A1%9C%20%EC%83%9D%EA%B0%81%ED%95%98%EB%8B%88%3F%20%EC%95%84%EB%8B%88%EB%A9%B4%20%EC%95%A0%EC%9D%B8%EC%9C%BC%EB%A1%9C%20%EC%82%AC%EB%9E%91%ED%95%98%EB%8B%88%3F)
^ko-Q0755-answer

**ko-Q0756** — 너 그 사람을 오빠-동생으로 생각하니? 아니면 애인으로 사랑하니?

Do you love him like a brother or do you love-love him?

-(으)면 builds a conditional relation. The stem’s final consonant determines the linking form. It can express a real or hypothetical situation according to context.

Why: Conditional linking. [[Korean#^ko-Q0756|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%84%88%20%EA%B7%B8%20%EC%82%AC%EB%9E%8C%EC%9D%84%20%EC%98%A4%EB%B9%A0-%EB%8F%99%EC%83%9D%EC%9C%BC%EB%A1%9C%20%EC%83%9D%EA%B0%81%ED%95%98%EB%8B%88%3F%20%EC%95%84%EB%8B%88%EB%A9%B4%20%EC%95%A0%EC%9D%B8%EC%9C%BC%EB%A1%9C%20%EC%82%AC%EB%9E%91%ED%95%98%EB%8B%88%3F)
^ko-Q0756-answer

**ko-Q0757** — 전하실 말씀 있으시면 남겨주세요.

I can take a message.

Expected form: **있으시면**

Why: Conditional linking. [[Korean#^ko-Q0757|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A0%84%ED%95%98%EC%8B%A4%20%EB%A7%90%EC%94%80%20%EC%9E%88%EC%9C%BC%EC%8B%9C%EB%A9%B4%20%EB%82%A8%EA%B2%A8%EC%A3%BC%EC%84%B8%EC%9A%94.)
^ko-Q0757-answer

**ko-Q0758** — 전하실 말씀 있으시면 남겨주세요.

I can take a message.

Expected form: **있으시면**

Why: Conditional linking. [[Korean#^ko-Q0758|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A0%84%ED%95%98%EC%8B%A4%20%EB%A7%90%EC%94%80%20%EC%9E%88%EC%9C%BC%EC%8B%9C%EB%A9%B4%20%EB%82%A8%EA%B2%A8%EC%A3%BC%EC%84%B8%EC%9A%94.)
^ko-Q0758-answer

**ko-Q0759** — 내가 할 수 있는게 더 있었으면 좋았을 걸.

I wish there was more I could've done.

Expected form: **있었으면**

Why: Conditional linking. [[Korean#^ko-Q0759|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%B4%EA%B0%80%20%ED%95%A0%20%EC%88%98%20%EC%9E%88%EB%8A%94%EA%B2%8C%20%EB%8D%94%20%EC%9E%88%EC%97%88%EC%9C%BC%EB%A9%B4%20%EC%A2%8B%EC%95%98%EC%9D%84%20%EA%B1%B8.)
^ko-Q0759-answer

**ko-Q0760** — 내가 할 수 있는게 더 있었으면 좋았을 걸.

I wish there was more I could've done.

Why: Conditional linking. [[Korean#^ko-Q0760|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%B4%EA%B0%80%20%ED%95%A0%20%EC%88%98%20%EC%9E%88%EB%8A%94%EA%B2%8C%20%EB%8D%94%20%EC%9E%88%EC%97%88%EC%9C%BC%EB%A9%B4%20%EC%A2%8B%EC%95%98%EC%9D%84%20%EA%B1%B8.)
^ko-Q0760-answer

**ko-Q0761** — 메리가 그걸 한다면 톰이 아주 놀라겠는걸.

Tom would be very surprised if Mary did that.

Why: Conditional linking. [[Korean#^ko-Q0761|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%A9%94%EB%A6%AC%EA%B0%80%20%EA%B7%B8%EA%B1%B8%20%ED%95%9C%EB%8B%A4%EB%A9%B4%20%ED%86%B0%EC%9D%B4%20%EC%95%84%EC%A3%BC%20%EB%86%80%EB%9D%BC%EA%B2%A0%EB%8A%94%EA%B1%B8.)
^ko-Q0761-answer

**ko-Q0762** — 메리가 그걸 한다면 톰이 아주 놀라겠는걸.

Tom would be very surprised if Mary did that.

-(으)면 builds a conditional relation. The stem’s final consonant determines the linking form. It can express a real or hypothetical situation according to context.

Why: Conditional linking. [[Korean#^ko-Q0762|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%A9%94%EB%A6%AC%EA%B0%80%20%EA%B7%B8%EA%B1%B8%20%ED%95%9C%EB%8B%A4%EB%A9%B4%20%ED%86%B0%EC%9D%B4%20%EC%95%84%EC%A3%BC%20%EB%86%80%EB%9D%BC%EA%B2%A0%EB%8A%94%EA%B1%B8.)
^ko-Q0762-answer

**ko-Q0763** — 만약에 네가 나쁜 짓을 했다면 알려주는게 좋을거야.

You'd better tell me if you did something wrong.

Expected form: **했다면**

Why: Conditional linking. [[Korean#^ko-Q0763|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%A7%8C%EC%95%BD%EC%97%90%20%EB%84%A4%EA%B0%80%20%EB%82%98%EC%81%9C%20%EC%A7%93%EC%9D%84%20%ED%96%88%EB%8B%A4%EB%A9%B4%20%EC%95%8C%EB%A0%A4%EC%A3%BC%EB%8A%94%EA%B2%8C%20%EC%A2%8B%EC%9D%84%EA%B1%B0%EC%95%BC.)
^ko-Q0763-answer

**ko-Q0764** — 만약에 네가 나쁜 짓을 했다면 알려주는게 좋을거야.

You'd better tell me if you did something wrong.

Expected form: **했다면**

Why: Conditional linking. [[Korean#^ko-Q0764|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%A7%8C%EC%95%BD%EC%97%90%20%EB%84%A4%EA%B0%80%20%EB%82%98%EC%81%9C%20%EC%A7%93%EC%9D%84%20%ED%96%88%EB%8B%A4%EB%A9%B4%20%EC%95%8C%EB%A0%A4%EC%A3%BC%EB%8A%94%EA%B2%8C%20%EC%A2%8B%EC%9D%84%EA%B1%B0%EC%95%BC.)
^ko-Q0764-answer

**ko-Q0765** — 네가 톰을 도와주지 않는다면 톰은 곤란에 처할 거야.

If you don't help Tom, he'll have trouble doing it.

Expected form: **않는다면**

Why: Conditional linking. [[Korean#^ko-Q0765|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%84%A4%EA%B0%80%20%ED%86%B0%EC%9D%84%20%EB%8F%84%EC%99%80%EC%A3%BC%EC%A7%80%20%EC%95%8A%EB%8A%94%EB%8B%A4%EB%A9%B4%20%ED%86%B0%EC%9D%80%20%EA%B3%A4%EB%9E%80%EC%97%90%20%EC%B2%98%ED%95%A0%20%EA%B1%B0%EC%95%BC.)
^ko-Q0765-answer

**ko-Q0766** — 네가 톰을 도와주지 않는다면 톰은 곤란에 처할 거야.

If you don't help Tom, he'll have trouble doing it.

Why: Conditional linking. [[Korean#^ko-Q0766|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%84%A4%EA%B0%80%20%ED%86%B0%EC%9D%84%20%EB%8F%84%EC%99%80%EC%A3%BC%EC%A7%80%20%EC%95%8A%EB%8A%94%EB%8B%A4%EB%A9%B4%20%ED%86%B0%EC%9D%80%20%EA%B3%A4%EB%9E%80%EC%97%90%20%EC%B2%98%ED%95%A0%20%EA%B1%B0%EC%95%BC.)
^ko-Q0766-answer

**ko-Q0767** — 내일 비가 안오면 좋겠는데.

It'd be good if it wouldn't rain tomorrow.

Why: Conditional linking. [[Korean#^ko-Q0767|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%B4%EC%9D%BC%20%EB%B9%84%EA%B0%80%20%EC%95%88%EC%98%A4%EB%A9%B4%20%EC%A2%8B%EA%B2%A0%EB%8A%94%EB%8D%B0.)
^ko-Q0767-answer

**ko-Q0768** — 내일 비가 안오면 좋겠는데.

It'd be good if it wouldn't rain tomorrow.

-(으)면 builds a conditional relation. The stem’s final consonant determines the linking form. It can express a real or hypothetical situation according to context.

Why: Conditional linking. [[Korean#^ko-Q0768|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%B4%EC%9D%BC%20%EB%B9%84%EA%B0%80%20%EC%95%88%EC%98%A4%EB%A9%B4%20%EC%A2%8B%EA%B2%A0%EB%8A%94%EB%8D%B0.)
^ko-Q0768-answer

**ko-Q0769** — 사공이 많으면 배가 거꾸로 간다.

Too many cooks spoil the broth.

Expected form: **많으면**

Why: Conditional linking. [[Korean#^ko-Q0769|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%82%AC%EA%B3%B5%EC%9D%B4%20%EB%A7%8E%EC%9C%BC%EB%A9%B4%20%EB%B0%B0%EA%B0%80%20%EA%B1%B0%EA%BE%B8%EB%A1%9C%20%EA%B0%84%EB%8B%A4.)
^ko-Q0769-answer

**ko-Q0770** — 사공이 많으면 배가 거꾸로 간다.

Too many cooks spoil the broth.

Expected form: **많으면**

Why: Conditional linking. [[Korean#^ko-Q0770|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%82%AC%EA%B3%B5%EC%9D%B4%20%EB%A7%8E%EC%9C%BC%EB%A9%B4%20%EB%B0%B0%EA%B0%80%20%EA%B1%B0%EA%BE%B8%EB%A1%9C%20%EA%B0%84%EB%8B%A4.)
^ko-Q0770-answer

**ko-Q0771** — 이 사전이면 될까요?

Will this dictionary do?

Expected form: **사전이면**

Why: Conditional linking. [[Korean#^ko-Q0771|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9D%B4%20%EC%82%AC%EC%A0%84%EC%9D%B4%EB%A9%B4%20%EB%90%A0%EA%B9%8C%EC%9A%94%3F)
^ko-Q0771-answer

**ko-Q0772** — 이 사전이면 될까요?

Will this dictionary do?

Why: Conditional linking. [[Korean#^ko-Q0772|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9D%B4%20%EC%82%AC%EC%A0%84%EC%9D%B4%EB%A9%B4%20%EB%90%A0%EA%B9%8C%EC%9A%94%3F)
^ko-Q0772-answer

**ko-Q0773** — 네가 저리 갔으면 좋겠어.

I'd like you to go away.

Why: Conditional linking. [[Korean#^ko-Q0773|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%84%A4%EA%B0%80%20%EC%A0%80%EB%A6%AC%20%EA%B0%94%EC%9C%BC%EB%A9%B4%20%EC%A2%8B%EA%B2%A0%EC%96%B4.)
^ko-Q0773-answer

**ko-Q0774** — 네가 저리 갔으면 좋겠어.

I'd like you to go away.

-(으)면 builds a conditional relation. The stem’s final consonant determines the linking form. It can express a real or hypothetical situation according to context.

Why: Conditional linking. [[Korean#^ko-Q0774|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%84%A4%EA%B0%80%20%EC%A0%80%EB%A6%AC%20%EA%B0%94%EC%9C%BC%EB%A9%B4%20%EC%A2%8B%EA%B2%A0%EC%96%B4.)
^ko-Q0774-answer

**ko-Q0775** — 메리는 보스턴으로 이사가면 더 행복할 것이라고 확신했다.

Mary was convinced that she'd be happier if she moved to Boston.

Expected form: **이사가면**

Why: Conditional linking. [[Korean#^ko-Q0775|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%A9%94%EB%A6%AC%EB%8A%94%20%EB%B3%B4%EC%8A%A4%ED%84%B4%EC%9C%BC%EB%A1%9C%20%EC%9D%B4%EC%82%AC%EA%B0%80%EB%A9%B4%20%EB%8D%94%20%ED%96%89%EB%B3%B5%ED%95%A0%20%EA%B2%83%EC%9D%B4%EB%9D%BC%EA%B3%A0%20%ED%99%95%EC%8B%A0%ED%96%88%EB%8B%A4.)
^ko-Q0775-answer

**ko-Q0776** — 메리는 보스턴으로 이사가면 더 행복할 것이라고 확신했다.

Mary was convinced that she'd be happier if she moved to Boston.

Expected form: **이사가면**

Why: Conditional linking. [[Korean#^ko-Q0776|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%A9%94%EB%A6%AC%EB%8A%94%20%EB%B3%B4%EC%8A%A4%ED%84%B4%EC%9C%BC%EB%A1%9C%20%EC%9D%B4%EC%82%AC%EA%B0%80%EB%A9%B4%20%EB%8D%94%20%ED%96%89%EB%B3%B5%ED%95%A0%20%EA%B2%83%EC%9D%B4%EB%9D%BC%EA%B3%A0%20%ED%99%95%EC%8B%A0%ED%96%88%EB%8B%A4.)
^ko-Q0776-answer

**ko-Q0777** — 내 일을 어떻게 하면 되는지 나한테 말하고 있는거에요?

Are you telling me how to do my job?

Expected form: **하면**

Why: Conditional linking. [[Korean#^ko-Q0777|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%B4%20%EC%9D%BC%EC%9D%84%20%EC%96%B4%EB%96%BB%EA%B2%8C%20%ED%95%98%EB%A9%B4%20%EB%90%98%EB%8A%94%EC%A7%80%20%EB%82%98%ED%95%9C%ED%85%8C%20%EB%A7%90%ED%95%98%EA%B3%A0%20%EC%9E%88%EB%8A%94%EA%B1%B0%EC%97%90%EC%9A%94%3F)
^ko-Q0777-answer

**ko-Q0778** — 내 일을 어떻게 하면 되는지 나한테 말하고 있는거에요?

Are you telling me how to do my job?

Why: Conditional linking. [[Korean#^ko-Q0778|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%B4%20%EC%9D%BC%EC%9D%84%20%EC%96%B4%EB%96%BB%EA%B2%8C%20%ED%95%98%EB%A9%B4%20%EB%90%98%EB%8A%94%EC%A7%80%20%EB%82%98%ED%95%9C%ED%85%8C%20%EB%A7%90%ED%95%98%EA%B3%A0%20%EC%9E%88%EB%8A%94%EA%B1%B0%EC%97%90%EC%9A%94%3F)
^ko-Q0778-answer

**ko-Q0779** — 톰이 자신이 왜 떠나야 하는지를 이해했으면 좋겠어.

I want Tom to understand why he has to leave.

Why: Conditional linking. [[Korean#^ko-Q0779|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%B4%20%EC%9E%90%EC%8B%A0%EC%9D%B4%20%EC%99%9C%20%EB%96%A0%EB%82%98%EC%95%BC%20%ED%95%98%EB%8A%94%EC%A7%80%EB%A5%BC%20%EC%9D%B4%ED%95%B4%ED%96%88%EC%9C%BC%EB%A9%B4%20%EC%A2%8B%EA%B2%A0%EC%96%B4.)
^ko-Q0779-answer

**ko-Q0780** — 톰이 자신이 왜 떠나야 하는지를 이해했으면 좋겠어.

I want Tom to understand why he has to leave.

-(으)면 builds a conditional relation. The stem’s final consonant determines the linking form. It can express a real or hypothetical situation according to context.

Why: Conditional linking. [[Korean#^ko-Q0780|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%B4%20%EC%9E%90%EC%8B%A0%EC%9D%B4%20%EC%99%9C%20%EB%96%A0%EB%82%98%EC%95%BC%20%ED%95%98%EB%8A%94%EC%A7%80%EB%A5%BC%20%EC%9D%B4%ED%95%B4%ED%96%88%EC%9C%BC%EB%A9%B4%20%EC%A2%8B%EA%B2%A0%EC%96%B4.)
^ko-Q0780-answer

**ko-Q0781** — 톰이 그렇게 어리지 않았다면 그걸 함으로써 용서받지 못했을 거야.

I think Tom wouldn't be forgiven for doing that if he weren't so young.

Expected form: **않았다면**

Why: Conditional linking. [[Korean#^ko-Q0781|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%B4%20%EA%B7%B8%EB%A0%87%EA%B2%8C%20%EC%96%B4%EB%A6%AC%EC%A7%80%20%EC%95%8A%EC%95%98%EB%8B%A4%EB%A9%B4%20%EA%B7%B8%EA%B1%B8%20%ED%95%A8%EC%9C%BC%EB%A1%9C%EC%8D%A8%20%EC%9A%A9%EC%84%9C%EB%B0%9B%EC%A7%80%20%EB%AA%BB%ED%96%88%EC%9D%84%20%EA%B1%B0%EC%95%BC.)
^ko-Q0781-answer

**ko-Q0782** — 톰이 그렇게 어리지 않았다면 그걸 함으로써 용서받지 못했을 거야.

I think Tom wouldn't be forgiven for doing that if he weren't so young.

Expected form: **않았다면**

Why: Conditional linking. [[Korean#^ko-Q0782|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%B4%20%EA%B7%B8%EB%A0%87%EA%B2%8C%20%EC%96%B4%EB%A6%AC%EC%A7%80%20%EC%95%8A%EC%95%98%EB%8B%A4%EB%A9%B4%20%EA%B7%B8%EA%B1%B8%20%ED%95%A8%EC%9C%BC%EB%A1%9C%EC%8D%A8%20%EC%9A%A9%EC%84%9C%EB%B0%9B%EC%A7%80%20%EB%AA%BB%ED%96%88%EC%9D%84%20%EA%B1%B0%EC%95%BC.)
^ko-Q0782-answer

**ko-Q0783** — 내가 만약 진실을 말하면 난 살해 당할 거야.

If I tell the truth, I'll be killed.

Expected form: **말하면**

Why: Conditional linking. [[Korean#^ko-Q0783|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%B4%EA%B0%80%20%EB%A7%8C%EC%95%BD%20%EC%A7%84%EC%8B%A4%EC%9D%84%20%EB%A7%90%ED%95%98%EB%A9%B4%20%EB%82%9C%20%EC%82%B4%ED%95%B4%20%EB%8B%B9%ED%95%A0%20%EA%B1%B0%EC%95%BC.)
^ko-Q0783-answer

**ko-Q0784** — 내가 만약 진실을 말하면 난 살해 당할 거야.

If I tell the truth, I'll be killed.

Why: Conditional linking. [[Korean#^ko-Q0784|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%B4%EA%B0%80%20%EB%A7%8C%EC%95%BD%20%EC%A7%84%EC%8B%A4%EC%9D%84%20%EB%A7%90%ED%95%98%EB%A9%B4%20%EB%82%9C%20%EC%82%B4%ED%95%B4%20%EB%8B%B9%ED%95%A0%20%EA%B1%B0%EC%95%BC.)
^ko-Q0784-answer

**ko-Q0785** — 네 입장이라면 나는 그 일을 하지 않겠다.

If I were in your position I wouldn't do that job.

Why: Conditional linking. [[Korean#^ko-Q0785|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%84%A4%20%EC%9E%85%EC%9E%A5%EC%9D%B4%EB%9D%BC%EB%A9%B4%20%EB%82%98%EB%8A%94%20%EA%B7%B8%20%EC%9D%BC%EC%9D%84%20%ED%95%98%EC%A7%80%20%EC%95%8A%EA%B2%A0%EB%8B%A4.)
^ko-Q0785-answer

**ko-Q0786** — 네 입장이라면 나는 그 일을 하지 않겠다.

If I were in your position I wouldn't do that job.

-(으)면 builds a conditional relation. The stem’s final consonant determines the linking form. It can express a real or hypothetical situation according to context.

Why: Conditional linking. [[Korean#^ko-Q0786|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%84%A4%20%EC%9E%85%EC%9E%A5%EC%9D%B4%EB%9D%BC%EB%A9%B4%20%EB%82%98%EB%8A%94%20%EA%B7%B8%20%EC%9D%BC%EC%9D%84%20%ED%95%98%EC%A7%80%20%EC%95%8A%EA%B2%A0%EB%8B%A4.)
^ko-Q0786-answer

**ko-Q0787** — 문장에 틀렸거나 어색하다면 꼭 고쳐주시기 바랍니다!

Please edit the sentence if it is wrong or awkward.

Expected form: **어색하다면**

Why: Conditional linking. [[Korean#^ko-Q0787|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%AC%B8%EC%9E%A5%EC%97%90%20%ED%8B%80%EB%A0%B8%EA%B1%B0%EB%82%98%20%EC%96%B4%EC%83%89%ED%95%98%EB%8B%A4%EB%A9%B4%20%EA%BC%AD%20%EA%B3%A0%EC%B3%90%EC%A3%BC%EC%8B%9C%EA%B8%B0%20%EB%B0%94%EB%9E%8D%EB%8B%88%EB%8B%A4%21)
^ko-Q0787-answer

**ko-Q0788** — 문장에 틀렸거나 어색하다면 꼭 고쳐주시기 바랍니다!

Please edit the sentence if it is wrong or awkward.

Expected form: **어색하다면**

Why: Conditional linking. [[Korean#^ko-Q0788|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%AC%B8%EC%9E%A5%EC%97%90%20%ED%8B%80%EB%A0%B8%EA%B1%B0%EB%82%98%20%EC%96%B4%EC%83%89%ED%95%98%EB%8B%A4%EB%A9%B4%20%EA%BC%AD%20%EA%B3%A0%EC%B3%90%EC%A3%BC%EC%8B%9C%EA%B8%B0%20%EB%B0%94%EB%9E%8D%EB%8B%88%EB%8B%A4%21)
^ko-Q0788-answer

**ko-Q0789** — 그가 돌아오면 메모를 전해주세요.

Give him the message when he comes back.

Expected form: **돌아오면**

Why: Conditional linking. [[Korean#^ko-Q0789|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EA%B0%80%20%EB%8F%8C%EC%95%84%EC%98%A4%EB%A9%B4%20%EB%A9%94%EB%AA%A8%EB%A5%BC%20%EC%A0%84%ED%95%B4%EC%A3%BC%EC%84%B8%EC%9A%94.)
^ko-Q0789-answer

**ko-Q0790** — 그가 돌아오면 메모를 전해주세요.

Give him the message when he comes back.

Why: Conditional linking. [[Korean#^ko-Q0790|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EA%B0%80%20%EB%8F%8C%EC%95%84%EC%98%A4%EB%A9%B4%20%EB%A9%94%EB%AA%A8%EB%A5%BC%20%EC%A0%84%ED%95%B4%EC%A3%BC%EC%84%B8%EC%9A%94.)
^ko-Q0790-answer

**ko-Q0791** — 내가 외동이었으면 좋았을 텐데.

I wish I were an only child.

Why: Conditional linking. [[Korean#^ko-Q0791|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%B4%EA%B0%80%20%EC%99%B8%EB%8F%99%EC%9D%B4%EC%97%88%EC%9C%BC%EB%A9%B4%20%EC%A2%8B%EC%95%98%EC%9D%84%20%ED%85%90%EB%8D%B0.)
^ko-Q0791-answer

**ko-Q0792** — 내가 외동이었으면 좋았을 텐데.

I wish I were an only child.

-(으)면 builds a conditional relation. The stem’s final consonant determines the linking form. It can express a real or hypothetical situation according to context.

Why: Conditional linking. [[Korean#^ko-Q0792|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%B4%EA%B0%80%20%EC%99%B8%EB%8F%99%EC%9D%B4%EC%97%88%EC%9C%BC%EB%A9%B4%20%EC%A2%8B%EC%95%98%EC%9D%84%20%ED%85%90%EB%8D%B0.)
^ko-Q0792-answer

**ko-Q0793** — 물이 없었다면 인류의 생존은 가능하지 않았을 겁니다.

If it were not for water, human life would be impossible.

Expected form: **없었다면**

Why: Conditional linking. [[Korean#^ko-Q0793|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%AC%BC%EC%9D%B4%20%EC%97%86%EC%97%88%EB%8B%A4%EB%A9%B4%20%EC%9D%B8%EB%A5%98%EC%9D%98%20%EC%83%9D%EC%A1%B4%EC%9D%80%20%EA%B0%80%EB%8A%A5%ED%95%98%EC%A7%80%20%EC%95%8A%EC%95%98%EC%9D%84%20%EA%B2%81%EB%8B%88%EB%8B%A4.)
^ko-Q0793-answer

**ko-Q0794** — 물이 없었다면 인류의 생존은 가능하지 않았을 겁니다.

If it were not for water, human life would be impossible.

Expected form: **없었다면**

Why: Conditional linking. [[Korean#^ko-Q0794|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%AC%BC%EC%9D%B4%20%EC%97%86%EC%97%88%EB%8B%A4%EB%A9%B4%20%EC%9D%B8%EB%A5%98%EC%9D%98%20%EC%83%9D%EC%A1%B4%EC%9D%80%20%EA%B0%80%EB%8A%A5%ED%95%98%EC%A7%80%20%EC%95%8A%EC%95%98%EC%9D%84%20%EA%B2%81%EB%8B%88%EB%8B%A4.)
^ko-Q0794-answer

**ko-Q0795** — 내가 원어민이랑 공부한다면 내 프랑스어 실력은 훨씬 더 나을 텐데.

My French would likely be much better today if I'd studied with a native speaker.

Expected form: **공부한다면**

Why: Conditional linking. [[Korean#^ko-Q0795|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%B4%EA%B0%80%20%EC%9B%90%EC%96%B4%EB%AF%BC%EC%9D%B4%EB%9E%91%20%EA%B3%B5%EB%B6%80%ED%95%9C%EB%8B%A4%EB%A9%B4%20%EB%82%B4%20%ED%94%84%EB%9E%91%EC%8A%A4%EC%96%B4%20%EC%8B%A4%EB%A0%A5%EC%9D%80%20%ED%9B%A8%EC%94%AC%20%EB%8D%94%20%EB%82%98%EC%9D%84%20%ED%85%90%EB%8D%B0.)
^ko-Q0795-answer

**ko-Q0796** — 내가 원어민이랑 공부한다면 내 프랑스어 실력은 훨씬 더 나을 텐데.

My French would likely be much better today if I'd studied with a native speaker.

Why: Conditional linking. [[Korean#^ko-Q0796|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%B4%EA%B0%80%20%EC%9B%90%EC%96%B4%EB%AF%BC%EC%9D%B4%EB%9E%91%20%EA%B3%B5%EB%B6%80%ED%95%9C%EB%8B%A4%EB%A9%B4%20%EB%82%B4%20%ED%94%84%EB%9E%91%EC%8A%A4%EC%96%B4%20%EC%8B%A4%EB%A0%A5%EC%9D%80%20%ED%9B%A8%EC%94%AC%20%EB%8D%94%20%EB%82%98%EC%9D%84%20%ED%85%90%EB%8D%B0.)
^ko-Q0796-answer

**ko-Q0797** — 빨리 스페인어가 늘었으면 좋겠네.

I hope my Spanish improves quickly.

Why: Conditional linking. [[Korean#^ko-Q0797|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%B9%A8%EB%A6%AC%20%EC%8A%A4%ED%8E%98%EC%9D%B8%EC%96%B4%EA%B0%80%20%EB%8A%98%EC%97%88%EC%9C%BC%EB%A9%B4%20%EC%A2%8B%EA%B2%A0%EB%84%A4.)
^ko-Q0797-answer

**ko-Q0798** — 빨리 스페인어가 늘었으면 좋겠네.

I hope my Spanish improves quickly.

-(으)면 builds a conditional relation. The stem’s final consonant determines the linking form. It can express a real or hypothetical situation according to context.

Why: Conditional linking. [[Korean#^ko-Q0798|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%B9%A8%EB%A6%AC%20%EC%8A%A4%ED%8E%98%EC%9D%B8%EC%96%B4%EA%B0%80%20%EB%8A%98%EC%97%88%EC%9C%BC%EB%A9%B4%20%EC%A2%8B%EA%B2%A0%EB%84%A4.)
^ko-Q0798-answer

**ko-Q0799** — 난 톰이 내 친구들을 만났으면 했어.

I wanted Tom to meet my friends.

Expected form: **만났으면**

Why: Conditional linking. [[Korean#^ko-Q0799|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%9C%20%ED%86%B0%EC%9D%B4%20%EB%82%B4%20%EC%B9%9C%EA%B5%AC%EB%93%A4%EC%9D%84%20%EB%A7%8C%EB%82%AC%EC%9C%BC%EB%A9%B4%20%ED%96%88%EC%96%B4.)
^ko-Q0799-answer

**ko-Q0800** — 난 톰이 내 친구들을 만났으면 했어.

I wanted Tom to meet my friends.

Expected form: **만났으면**

Why: Conditional linking. [[Korean#^ko-Q0800|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%9C%20%ED%86%B0%EC%9D%B4%20%EB%82%B4%20%EC%B9%9C%EA%B5%AC%EB%93%A4%EC%9D%84%20%EB%A7%8C%EB%82%AC%EC%9C%BC%EB%A9%B4%20%ED%96%88%EC%96%B4.)
^ko-Q0800-answer


### Answers 801–850

**ko-Q0801** — 어제 너무 많이 먹어서 이제 난 병이 나요.

Yesterday I ate too much and now I feel sick.

Expected form: **먹어서**

Why: Cause and sequence. [[Korean#^ko-Q0801|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%96%B4%EC%A0%9C%20%EB%84%88%EB%AC%B4%20%EB%A7%8E%EC%9D%B4%20%EB%A8%B9%EC%96%B4%EC%84%9C%20%EC%9D%B4%EC%A0%9C%20%EB%82%9C%20%EB%B3%91%EC%9D%B4%20%EB%82%98%EC%9A%94.)
^ko-Q0801-answer

**ko-Q0802** — 어제 너무 많이 먹어서 이제 난 병이 나요.

Yesterday I ate too much and now I feel sick.

Why: Cause and sequence. [[Korean#^ko-Q0802|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%96%B4%EC%A0%9C%20%EB%84%88%EB%AC%B4%20%EB%A7%8E%EC%9D%B4%20%EB%A8%B9%EC%96%B4%EC%84%9C%20%EC%9D%B4%EC%A0%9C%20%EB%82%9C%20%EB%B3%91%EC%9D%B4%20%EB%82%98%EC%9A%94.)
^ko-Q0802-answer

**ko-Q0803** — 니가 좀 외로울 것 같아서 내가 와인 한 병을 들고 왔지.

I thought you might be lonely, so I came over with a bottle of wine.

Why: Cause and sequence. [[Korean#^ko-Q0803|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%8B%88%EA%B0%80%20%EC%A2%80%20%EC%99%B8%EB%A1%9C%EC%9A%B8%20%EA%B2%83%20%EA%B0%99%EC%95%84%EC%84%9C%20%EB%82%B4%EA%B0%80%20%EC%99%80%EC%9D%B8%20%ED%95%9C%20%EB%B3%91%EC%9D%84%20%EB%93%A4%EA%B3%A0%20%EC%99%94%EC%A7%80.)
^ko-Q0803-answer

**ko-Q0804** — 니가 좀 외로울 것 같아서 내가 와인 한 병을 들고 왔지.

I thought you might be lonely, so I came over with a bottle of wine.

These connective endings express reason, sequence or another relation depending on context. They have restrictions on following commands and proposals; learn the whole construction.

Why: Cause and sequence. [[Korean#^ko-Q0804|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%8B%88%EA%B0%80%20%EC%A2%80%20%EC%99%B8%EB%A1%9C%EC%9A%B8%20%EA%B2%83%20%EA%B0%99%EC%95%84%EC%84%9C%20%EB%82%B4%EA%B0%80%20%EC%99%80%EC%9D%B8%20%ED%95%9C%20%EB%B3%91%EC%9D%84%20%EB%93%A4%EA%B3%A0%20%EC%99%94%EC%A7%80.)
^ko-Q0804-answer

**ko-Q0805** — 오늘 추우니까 두껍게 입고 다녀.

It's cold today, so wear thick clothes.

Expected form: **추우니까**

Why: Cause and sequence. [[Korean#^ko-Q0805|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%98%A4%EB%8A%98%20%EC%B6%94%EC%9A%B0%EB%8B%88%EA%B9%8C%20%EB%91%90%EA%BB%8D%EA%B2%8C%20%EC%9E%85%EA%B3%A0%20%EB%8B%A4%EB%85%80.)
^ko-Q0805-answer

**ko-Q0806** — 오늘 추우니까 두껍게 입고 다녀.

It's cold today, so wear thick clothes.

Expected form: **추우니까**

Why: Cause and sequence. [[Korean#^ko-Q0806|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%98%A4%EB%8A%98%20%EC%B6%94%EC%9A%B0%EB%8B%88%EA%B9%8C%20%EB%91%90%EA%BB%8D%EA%B2%8C%20%EC%9E%85%EA%B3%A0%20%EB%8B%A4%EB%85%80.)
^ko-Q0806-answer

**ko-Q0807** — 먹기 위해서 살지 말고, 살기 위해서 먹어라.

One must eat to live, and not live to eat.

Expected form: **위해서**

Why: Cause and sequence. [[Korean#^ko-Q0807|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%A8%B9%EA%B8%B0%20%EC%9C%84%ED%95%B4%EC%84%9C%20%EC%82%B4%EC%A7%80%20%EB%A7%90%EA%B3%A0%2C%20%EC%82%B4%EA%B8%B0%20%EC%9C%84%ED%95%B4%EC%84%9C%20%EB%A8%B9%EC%96%B4%EB%9D%BC.)
^ko-Q0807-answer

**ko-Q0808** — 먹기 위해서 살지 말고, 살기 위해서 먹어라.

One must eat to live, and not live to eat.

Why: Cause and sequence. [[Korean#^ko-Q0808|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%A8%B9%EA%B8%B0%20%EC%9C%84%ED%95%B4%EC%84%9C%20%EC%82%B4%EC%A7%80%20%EB%A7%90%EA%B3%A0%2C%20%EC%82%B4%EA%B8%B0%20%EC%9C%84%ED%95%B4%EC%84%9C%20%EB%A8%B9%EC%96%B4%EB%9D%BC.)
^ko-Q0808-answer

**ko-Q0809** — 피곤해 보이니까 일찍 자는 것이 좋겠다.

You look tired, so you should go to bed early.

Why: Cause and sequence. [[Korean#^ko-Q0809|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%94%BC%EA%B3%A4%ED%95%B4%20%EB%B3%B4%EC%9D%B4%EB%8B%88%EA%B9%8C%20%EC%9D%BC%EC%B0%8D%20%EC%9E%90%EB%8A%94%20%EA%B2%83%EC%9D%B4%20%EC%A2%8B%EA%B2%A0%EB%8B%A4.)
^ko-Q0809-answer

**ko-Q0810** — 피곤해 보이니까 일찍 자는 것이 좋겠다.

You look tired, so you should go to bed early.

These connective endings express reason, sequence or another relation depending on context. They have restrictions on following commands and proposals; learn the whole construction.

Why: Cause and sequence. [[Korean#^ko-Q0810|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%94%BC%EA%B3%A4%ED%95%B4%20%EB%B3%B4%EC%9D%B4%EB%8B%88%EA%B9%8C%20%EC%9D%BC%EC%B0%8D%20%EC%9E%90%EB%8A%94%20%EA%B2%83%EC%9D%B4%20%EC%A2%8B%EA%B2%A0%EB%8B%A4.)
^ko-Q0810-answer

**ko-Q0811** — 3달전에 학생이 너무 적어서 수업이 없어졌던 거다.

Three months ago there were so few students we stopped the class.

Expected form: **적어서**

Why: Cause and sequence. [[Korean#^ko-Q0811|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=3%EB%8B%AC%EC%A0%84%EC%97%90%20%ED%95%99%EC%83%9D%EC%9D%B4%20%EB%84%88%EB%AC%B4%20%EC%A0%81%EC%96%B4%EC%84%9C%20%EC%88%98%EC%97%85%EC%9D%B4%20%EC%97%86%EC%96%B4%EC%A1%8C%EB%8D%98%20%EA%B1%B0%EB%8B%A4.)
^ko-Q0811-answer

**ko-Q0812** — 3달전에 학생이 너무 적어서 수업이 없어졌던 거다.

Three months ago there were so few students we stopped the class.

Expected form: **적어서**

Why: Cause and sequence. [[Korean#^ko-Q0812|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=3%EB%8B%AC%EC%A0%84%EC%97%90%20%ED%95%99%EC%83%9D%EC%9D%B4%20%EB%84%88%EB%AC%B4%20%EC%A0%81%EC%96%B4%EC%84%9C%20%EC%88%98%EC%97%85%EC%9D%B4%20%EC%97%86%EC%96%B4%EC%A1%8C%EB%8D%98%20%EA%B1%B0%EB%8B%A4.)
^ko-Q0812-answer

**ko-Q0813** — 내가 그를 꽉 안아서 울었다.

I hugged him tightly and cried.

Expected form: **안아서**

Why: Cause and sequence. [[Korean#^ko-Q0813|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%B4%EA%B0%80%20%EA%B7%B8%EB%A5%BC%20%EA%BD%89%20%EC%95%88%EC%95%84%EC%84%9C%20%EC%9A%B8%EC%97%88%EB%8B%A4.)
^ko-Q0813-answer

**ko-Q0814** — 내가 그를 꽉 안아서 울었다.

I hugged him tightly and cried.

Why: Cause and sequence. [[Korean#^ko-Q0814|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%B4%EA%B0%80%20%EA%B7%B8%EB%A5%BC%20%EA%BD%89%20%EC%95%88%EC%95%84%EC%84%9C%20%EC%9A%B8%EC%97%88%EB%8B%A4.)
^ko-Q0814-answer

**ko-Q0815** — 오늘은 이렇게 힘들었어서 깊게 잘 잘 것 같다.

Today was so hard I think I'll sleep well tonight.

Why: Cause and sequence. [[Korean#^ko-Q0815|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%98%A4%EB%8A%98%EC%9D%80%20%EC%9D%B4%EB%A0%87%EA%B2%8C%20%ED%9E%98%EB%93%A4%EC%97%88%EC%96%B4%EC%84%9C%20%EA%B9%8A%EA%B2%8C%20%EC%9E%98%20%EC%9E%98%20%EA%B2%83%20%EA%B0%99%EB%8B%A4.)
^ko-Q0815-answer

**ko-Q0816** — 오늘은 이렇게 힘들었어서 깊게 잘 잘 것 같다.

Today was so hard I think I'll sleep well tonight.

These connective endings express reason, sequence or another relation depending on context. They have restrictions on following commands and proposals; learn the whole construction.

Why: Cause and sequence. [[Korean#^ko-Q0816|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%98%A4%EB%8A%98%EC%9D%80%20%EC%9D%B4%EB%A0%87%EA%B2%8C%20%ED%9E%98%EB%93%A4%EC%97%88%EC%96%B4%EC%84%9C%20%EA%B9%8A%EA%B2%8C%20%EC%9E%98%20%EC%9E%98%20%EA%B2%83%20%EA%B0%99%EB%8B%A4.)
^ko-Q0816-answer

**ko-Q0817** — 조심해서 운전 하세요.

Please drive carefully.

Expected form: **조심해서**

Why: Cause and sequence. [[Korean#^ko-Q0817|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A1%B0%EC%8B%AC%ED%95%B4%EC%84%9C%20%EC%9A%B4%EC%A0%84%20%ED%95%98%EC%84%B8%EC%9A%94.)
^ko-Q0817-answer

**ko-Q0818** — 조심해서 운전 하세요.

Please drive carefully.

Expected form: **조심해서**

Why: Cause and sequence. [[Korean#^ko-Q0818|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A1%B0%EC%8B%AC%ED%95%B4%EC%84%9C%20%EC%9A%B4%EC%A0%84%20%ED%95%98%EC%84%B8%EC%9A%94.)
^ko-Q0818-answer

**ko-Q0819** — 톰은 손을 뻗어서 지팡이를 잡았다.

Tom reached for his cane.

Expected form: **뻗어서**

Why: Cause and sequence. [[Korean#^ko-Q0819|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EC%86%90%EC%9D%84%20%EB%BB%97%EC%96%B4%EC%84%9C%20%EC%A7%80%ED%8C%A1%EC%9D%B4%EB%A5%BC%20%EC%9E%A1%EC%95%98%EB%8B%A4.)
^ko-Q0819-answer

**ko-Q0820** — 톰은 손을 뻗어서 지팡이를 잡았다.

Tom reached for his cane.

Why: Cause and sequence. [[Korean#^ko-Q0820|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EC%86%90%EC%9D%84%20%EB%BB%97%EC%96%B4%EC%84%9C%20%EC%A7%80%ED%8C%A1%EC%9D%B4%EB%A5%BC%20%EC%9E%A1%EC%95%98%EB%8B%A4.)
^ko-Q0820-answer

**ko-Q0821** — 우리는 고객의 만족을 위해서 최선을 다한다.

Customer satisfaction is our number one priority.

Why: Cause and sequence. [[Korean#^ko-Q0821|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9A%B0%EB%A6%AC%EB%8A%94%20%EA%B3%A0%EA%B0%9D%EC%9D%98%20%EB%A7%8C%EC%A1%B1%EC%9D%84%20%EC%9C%84%ED%95%B4%EC%84%9C%20%EC%B5%9C%EC%84%A0%EC%9D%84%20%EB%8B%A4%ED%95%9C%EB%8B%A4.)
^ko-Q0821-answer

**ko-Q0822** — 우리는 고객의 만족을 위해서 최선을 다한다.

Customer satisfaction is our number one priority.

These connective endings express reason, sequence or another relation depending on context. They have restrictions on following commands and proposals; learn the whole construction.

Why: Cause and sequence. [[Korean#^ko-Q0822|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9A%B0%EB%A6%AC%EB%8A%94%20%EA%B3%A0%EA%B0%9D%EC%9D%98%20%EB%A7%8C%EC%A1%B1%EC%9D%84%20%EC%9C%84%ED%95%B4%EC%84%9C%20%EC%B5%9C%EC%84%A0%EC%9D%84%20%EB%8B%A4%ED%95%9C%EB%8B%A4.)
^ko-Q0822-answer

**ko-Q0823** — 통화해서 고객 서비스 상담원에게 말하기 전까지 연결 대기 큐에서 20분이나 기다렸어야 했어.

I had to wait 20 minutes on the phone before reaching the customer service rep.

Expected form: **통화해서**

Why: Cause and sequence. [[Korean#^ko-Q0823|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B5%ED%99%94%ED%95%B4%EC%84%9C%20%EA%B3%A0%EA%B0%9D%20%EC%84%9C%EB%B9%84%EC%8A%A4%20%EC%83%81%EB%8B%B4%EC%9B%90%EC%97%90%EA%B2%8C%20%EB%A7%90%ED%95%98%EA%B8%B0%20%EC%A0%84%EA%B9%8C%EC%A7%80%20%EC%97%B0%EA%B2%B0%20%EB%8C%80%EA%B8%B0%20%ED%81%90%EC%97%90%EC%84%9C%2020%EB%B6%84%EC%9D%B4%EB%82%98%20%EA%B8%B0%EB%8B%A4%EB%A0%B8%EC%96%B4%EC%95%BC%20%ED%96%88%EC%96%B4.)
^ko-Q0823-answer

**ko-Q0824** — 통화해서 고객 서비스 상담원에게 말하기 전까지 연결 대기 큐에서 20분이나 기다렸어야 했어.

I had to wait 20 minutes on the phone before reaching the customer service rep.

Expected form: **통화해서**

Why: Cause and sequence. [[Korean#^ko-Q0824|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B5%ED%99%94%ED%95%B4%EC%84%9C%20%EA%B3%A0%EA%B0%9D%20%EC%84%9C%EB%B9%84%EC%8A%A4%20%EC%83%81%EB%8B%B4%EC%9B%90%EC%97%90%EA%B2%8C%20%EB%A7%90%ED%95%98%EA%B8%B0%20%EC%A0%84%EA%B9%8C%EC%A7%80%20%EC%97%B0%EA%B2%B0%20%EB%8C%80%EA%B8%B0%20%ED%81%90%EC%97%90%EC%84%9C%2020%EB%B6%84%EC%9D%B4%EB%82%98%20%EA%B8%B0%EB%8B%A4%EB%A0%B8%EC%96%B4%EC%95%BC%20%ED%96%88%EC%96%B4.)
^ko-Q0824-answer

**ko-Q0825** — 끼어 들어서 죄송합니다.

I'm sorry for interrupting.

Expected form: **들어서**

Why: Cause and sequence. [[Korean#^ko-Q0825|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%81%BC%EC%96%B4%20%EB%93%A4%EC%96%B4%EC%84%9C%20%EC%A3%84%EC%86%A1%ED%95%A9%EB%8B%88%EB%8B%A4.)
^ko-Q0825-answer

**ko-Q0826** — 끼어 들어서 죄송합니다.

I'm sorry for interrupting.

Why: Cause and sequence. [[Korean#^ko-Q0826|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%81%BC%EC%96%B4%20%EB%93%A4%EC%96%B4%EC%84%9C%20%EC%A3%84%EC%86%A1%ED%95%A9%EB%8B%88%EB%8B%A4.)
^ko-Q0826-answer

**ko-Q0827** — 이 정보는 우리한테 있어서 정말 중요해요.

This information is very important to us.

Why: Cause and sequence. [[Korean#^ko-Q0827|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9D%B4%20%EC%A0%95%EB%B3%B4%EB%8A%94%20%EC%9A%B0%EB%A6%AC%ED%95%9C%ED%85%8C%20%EC%9E%88%EC%96%B4%EC%84%9C%20%EC%A0%95%EB%A7%90%20%EC%A4%91%EC%9A%94%ED%95%B4%EC%9A%94.)
^ko-Q0827-answer

**ko-Q0828** — 이 정보는 우리한테 있어서 정말 중요해요.

This information is very important to us.

These connective endings express reason, sequence or another relation depending on context. They have restrictions on following commands and proposals; learn the whole construction.

Why: Cause and sequence. [[Korean#^ko-Q0828|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9D%B4%20%EC%A0%95%EB%B3%B4%EB%8A%94%20%EC%9A%B0%EB%A6%AC%ED%95%9C%ED%85%8C%20%EC%9E%88%EC%96%B4%EC%84%9C%20%EC%A0%95%EB%A7%90%20%EC%A4%91%EC%9A%94%ED%95%B4%EC%9A%94.)
^ko-Q0828-answer

**ko-Q0829** — 나는 수학에 있어서 최고다.

I'm best at math.

Expected form: **있어서**

Why: Cause and sequence. [[Korean#^ko-Q0829|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%EC%88%98%ED%95%99%EC%97%90%20%EC%9E%88%EC%96%B4%EC%84%9C%20%EC%B5%9C%EA%B3%A0%EB%8B%A4.)
^ko-Q0829-answer

**ko-Q0830** — 나는 수학에 있어서 최고다.

I'm best at math.

Expected form: **있어서**

Why: Cause and sequence. [[Korean#^ko-Q0830|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%EC%88%98%ED%95%99%EC%97%90%20%EC%9E%88%EC%96%B4%EC%84%9C%20%EC%B5%9C%EA%B3%A0%EB%8B%A4.)
^ko-Q0830-answer

**ko-Q0831** — 그에 대해서 뭘 알아?

What do you know about him?

Expected form: **대해서**

Why: Cause and sequence. [[Korean#^ko-Q0831|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EC%97%90%20%EB%8C%80%ED%95%B4%EC%84%9C%20%EB%AD%98%20%EC%95%8C%EC%95%84%3F)
^ko-Q0831-answer

**ko-Q0832** — 그에 대해서 뭘 알아?

What do you know about him?

Why: Cause and sequence. [[Korean#^ko-Q0832|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EC%97%90%20%EB%8C%80%ED%95%B4%EC%84%9C%20%EB%AD%98%20%EC%95%8C%EC%95%84%3F)
^ko-Q0832-answer

**ko-Q0833** — 당신이 내일 아침에 일어나서 우주가 사라졌다는 것을 알게 된다면 수학은 당신이 계속해서 연구할 수 있는 과학의 한 부분입니다.

Mathematics is the part of science you could continue to do if you woke up tomorrow and discovered the universe was gone.

Why: Cause and sequence. [[Korean#^ko-Q0833|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%8B%B9%EC%8B%A0%EC%9D%B4%20%EB%82%B4%EC%9D%BC%20%EC%95%84%EC%B9%A8%EC%97%90%20%EC%9D%BC%EC%96%B4%EB%82%98%EC%84%9C%20%EC%9A%B0%EC%A3%BC%EA%B0%80%20%EC%82%AC%EB%9D%BC%EC%A1%8C%EB%8B%A4%EB%8A%94%20%EA%B2%83%EC%9D%84%20%EC%95%8C%EA%B2%8C%20%EB%90%9C%EB%8B%A4%EB%A9%B4%20%EC%88%98%ED%95%99%EC%9D%80%20%EB%8B%B9%EC%8B%A0%EC%9D%B4%20%EA%B3%84%EC%86%8D%ED%95%B4%EC%84%9C%20%EC%97%B0%EA%B5%AC%ED%95%A0%20%EC%88%98%20%EC%9E%88%EB%8A%94%20%EA%B3%BC%ED%95%99%EC%9D%98%20%ED%95%9C%20%EB%B6%80%EB%B6%84%EC%9E%85%EB%8B%88%EB%8B%A4.)
^ko-Q0833-answer

**ko-Q0834** — 당신이 내일 아침에 일어나서 우주가 사라졌다는 것을 알게 된다면 수학은 당신이 계속해서 연구할 수 있는 과학의 한 부분입니다.

Mathematics is the part of science you could continue to do if you woke up tomorrow and discovered the universe was gone.

These connective endings express reason, sequence or another relation depending on context. They have restrictions on following commands and proposals; learn the whole construction.

Why: Cause and sequence. [[Korean#^ko-Q0834|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%8B%B9%EC%8B%A0%EC%9D%B4%20%EB%82%B4%EC%9D%BC%20%EC%95%84%EC%B9%A8%EC%97%90%20%EC%9D%BC%EC%96%B4%EB%82%98%EC%84%9C%20%EC%9A%B0%EC%A3%BC%EA%B0%80%20%EC%82%AC%EB%9D%BC%EC%A1%8C%EB%8B%A4%EB%8A%94%20%EA%B2%83%EC%9D%84%20%EC%95%8C%EA%B2%8C%20%EB%90%9C%EB%8B%A4%EB%A9%B4%20%EC%88%98%ED%95%99%EC%9D%80%20%EB%8B%B9%EC%8B%A0%EC%9D%B4%20%EA%B3%84%EC%86%8D%ED%95%B4%EC%84%9C%20%EC%97%B0%EA%B5%AC%ED%95%A0%20%EC%88%98%20%EC%9E%88%EB%8A%94%20%EA%B3%BC%ED%95%99%EC%9D%98%20%ED%95%9C%20%EB%B6%80%EB%B6%84%EC%9E%85%EB%8B%88%EB%8B%A4.)
^ko-Q0834-answer

**ko-Q0835** — 정말 궁금해서 그러는데, 두 사람 무슨 사이야?

I am really curious, how do you two know each other?

Expected form: **궁금해서**

Why: Cause and sequence. [[Korean#^ko-Q0835|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A0%95%EB%A7%90%20%EA%B6%81%EA%B8%88%ED%95%B4%EC%84%9C%20%EA%B7%B8%EB%9F%AC%EB%8A%94%EB%8D%B0%2C%20%EB%91%90%20%EC%82%AC%EB%9E%8C%20%EB%AC%B4%EC%8A%A8%20%EC%82%AC%EC%9D%B4%EC%95%BC%3F)
^ko-Q0835-answer

**ko-Q0836** — 정말 궁금해서 그러는데, 두 사람 무슨 사이야?

I am really curious, how do you two know each other?

Expected form: **궁금해서**

Why: Cause and sequence. [[Korean#^ko-Q0836|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A0%95%EB%A7%90%20%EA%B6%81%EA%B8%88%ED%95%B4%EC%84%9C%20%EA%B7%B8%EB%9F%AC%EB%8A%94%EB%8D%B0%2C%20%EB%91%90%20%EC%82%AC%EB%9E%8C%20%EB%AC%B4%EC%8A%A8%20%EC%82%AC%EC%9D%B4%EC%95%BC%3F)
^ko-Q0836-answer

**ko-Q0837** — 탐을 메리를 위해서 설거지를 했다.

Tom did the dishes for Mary.

Expected form: **위해서**

Why: Cause and sequence. [[Korean#^ko-Q0837|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%83%90%EC%9D%84%20%EB%A9%94%EB%A6%AC%EB%A5%BC%20%EC%9C%84%ED%95%B4%EC%84%9C%20%EC%84%A4%EA%B1%B0%EC%A7%80%EB%A5%BC%20%ED%96%88%EB%8B%A4.)
^ko-Q0837-answer

**ko-Q0838** — 탐을 메리를 위해서 설거지를 했다.

Tom did the dishes for Mary.

Why: Cause and sequence. [[Korean#^ko-Q0838|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%83%90%EC%9D%84%20%EB%A9%94%EB%A6%AC%EB%A5%BC%20%EC%9C%84%ED%95%B4%EC%84%9C%20%EC%84%A4%EA%B1%B0%EC%A7%80%EB%A5%BC%20%ED%96%88%EB%8B%A4.)
^ko-Q0838-answer

**ko-Q0839** — 오늘 동료 한명이 본인 직장에 대해서 애기해줬어.

Today one of my colleague told about his job.

Why: Cause and sequence. [[Korean#^ko-Q0839|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%98%A4%EB%8A%98%20%EB%8F%99%EB%A3%8C%20%ED%95%9C%EB%AA%85%EC%9D%B4%20%EB%B3%B8%EC%9D%B8%20%EC%A7%81%EC%9E%A5%EC%97%90%20%EB%8C%80%ED%95%B4%EC%84%9C%20%EC%95%A0%EA%B8%B0%ED%95%B4%EC%A4%AC%EC%96%B4.)
^ko-Q0839-answer

**ko-Q0840** — 오늘 동료 한명이 본인 직장에 대해서 애기해줬어.

Today one of my colleague told about his job.

These connective endings express reason, sequence or another relation depending on context. They have restrictions on following commands and proposals; learn the whole construction.

Why: Cause and sequence. [[Korean#^ko-Q0840|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%98%A4%EB%8A%98%20%EB%8F%99%EB%A3%8C%20%ED%95%9C%EB%AA%85%EC%9D%B4%20%EB%B3%B8%EC%9D%B8%20%EC%A7%81%EC%9E%A5%EC%97%90%20%EB%8C%80%ED%95%B4%EC%84%9C%20%EC%95%A0%EA%B8%B0%ED%95%B4%EC%A4%AC%EC%96%B4.)
^ko-Q0840-answer

**ko-Q0841** — 하늘을 마주해서 보면 그 산은 참 예뻐 보였다.

Seen against the sky, the mountain looked really beautiful.

Expected form: **마주해서**

Why: Cause and sequence. [[Korean#^ko-Q0841|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%95%98%EB%8A%98%EC%9D%84%20%EB%A7%88%EC%A3%BC%ED%95%B4%EC%84%9C%20%EB%B3%B4%EB%A9%B4%20%EA%B7%B8%20%EC%82%B0%EC%9D%80%20%EC%B0%B8%20%EC%98%88%EB%BB%90%20%EB%B3%B4%EC%98%80%EB%8B%A4.)
^ko-Q0841-answer

**ko-Q0842** — 하늘을 마주해서 보면 그 산은 참 예뻐 보였다.

Seen against the sky, the mountain looked really beautiful.

Expected form: **마주해서**

Why: Cause and sequence. [[Korean#^ko-Q0842|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%95%98%EB%8A%98%EC%9D%84%20%EB%A7%88%EC%A3%BC%ED%95%B4%EC%84%9C%20%EB%B3%B4%EB%A9%B4%20%EA%B7%B8%20%EC%82%B0%EC%9D%80%20%EC%B0%B8%20%EC%98%88%EB%BB%90%20%EB%B3%B4%EC%98%80%EB%8B%A4.)
^ko-Q0842-answer

**ko-Q0843** — 톰이 싫어서 내 자신이 싫어.

I hate myself for hating Tom.

Expected form: **싫어서**

Why: Cause and sequence. [[Korean#^ko-Q0843|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%B4%20%EC%8B%AB%EC%96%B4%EC%84%9C%20%EB%82%B4%20%EC%9E%90%EC%8B%A0%EC%9D%B4%20%EC%8B%AB%EC%96%B4.)
^ko-Q0843-answer

**ko-Q0844** — 톰이 싫어서 내 자신이 싫어.

I hate myself for hating Tom.

Why: Cause and sequence. [[Korean#^ko-Q0844|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%B4%20%EC%8B%AB%EC%96%B4%EC%84%9C%20%EB%82%B4%20%EC%9E%90%EC%8B%A0%EC%9D%B4%20%EC%8B%AB%EC%96%B4.)
^ko-Q0844-answer

**ko-Q0845** — 톰은 메리가 자신한테 있어서 너무 나이가 많다고 여기고 있어.

Tom thinks Mary is too old for him.

Why: Cause and sequence. [[Korean#^ko-Q0845|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EB%A9%94%EB%A6%AC%EA%B0%80%20%EC%9E%90%EC%8B%A0%ED%95%9C%ED%85%8C%20%EC%9E%88%EC%96%B4%EC%84%9C%20%EB%84%88%EB%AC%B4%20%EB%82%98%EC%9D%B4%EA%B0%80%20%EB%A7%8E%EB%8B%A4%EA%B3%A0%20%EC%97%AC%EA%B8%B0%EA%B3%A0%20%EC%9E%88%EC%96%B4.)
^ko-Q0845-answer

**ko-Q0846** — 톰은 메리가 자신한테 있어서 너무 나이가 많다고 여기고 있어.

Tom thinks Mary is too old for him.

These connective endings express reason, sequence or another relation depending on context. They have restrictions on following commands and proposals; learn the whole construction.

Why: Cause and sequence. [[Korean#^ko-Q0846|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EB%A9%94%EB%A6%AC%EA%B0%80%20%EC%9E%90%EC%8B%A0%ED%95%9C%ED%85%8C%20%EC%9E%88%EC%96%B4%EC%84%9C%20%EB%84%88%EB%AC%B4%20%EB%82%98%EC%9D%B4%EA%B0%80%20%EB%A7%8E%EB%8B%A4%EA%B3%A0%20%EC%97%AC%EA%B8%B0%EA%B3%A0%20%EC%9E%88%EC%96%B4.)
^ko-Q0846-answer

**ko-Q0847** — 비가 오니까 우산을 가지고 오세요.

It's raining, so please bring your umbrella.

Expected form: **오니까**

Why: Cause and sequence. [[Korean#^ko-Q0847|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%B9%84%EA%B0%80%20%EC%98%A4%EB%8B%88%EA%B9%8C%20%EC%9A%B0%EC%82%B0%EC%9D%84%20%EA%B0%80%EC%A7%80%EA%B3%A0%20%EC%98%A4%EC%84%B8%EC%9A%94.)
^ko-Q0847-answer

**ko-Q0848** — 비가 오니까 우산을 가지고 오세요.

It's raining, so please bring your umbrella.

Expected form: **오니까**

Why: Cause and sequence. [[Korean#^ko-Q0848|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%B9%84%EA%B0%80%20%EC%98%A4%EB%8B%88%EA%B9%8C%20%EC%9A%B0%EC%82%B0%EC%9D%84%20%EA%B0%80%EC%A7%80%EA%B3%A0%20%EC%98%A4%EC%84%B8%EC%9A%94.)
^ko-Q0848-answer

**ko-Q0849** — 사무총장은 전쟁 중인 두 파벌 간에 평화조약을 협상하기 위해서 필사적으로 노력하고 있다.

The Secretary General is making a last-ditch effort to negotiate a peace treaty between the two warring factions.

Expected form: **위해서**

Why: Cause and sequence. [[Korean#^ko-Q0849|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%82%AC%EB%AC%B4%EC%B4%9D%EC%9E%A5%EC%9D%80%20%EC%A0%84%EC%9F%81%20%EC%A4%91%EC%9D%B8%20%EB%91%90%20%ED%8C%8C%EB%B2%8C%20%EA%B0%84%EC%97%90%20%ED%8F%89%ED%99%94%EC%A1%B0%EC%95%BD%EC%9D%84%20%ED%98%91%EC%83%81%ED%95%98%EA%B8%B0%20%EC%9C%84%ED%95%B4%EC%84%9C%20%ED%95%84%EC%82%AC%EC%A0%81%EC%9C%BC%EB%A1%9C%20%EB%85%B8%EB%A0%A5%ED%95%98%EA%B3%A0%20%EC%9E%88%EB%8B%A4.)
^ko-Q0849-answer

**ko-Q0850** — 사무총장은 전쟁 중인 두 파벌 간에 평화조약을 협상하기 위해서 필사적으로 노력하고 있다.

The Secretary General is making a last-ditch effort to negotiate a peace treaty between the two warring factions.

Why: Cause and sequence. [[Korean#^ko-Q0850|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%82%AC%EB%AC%B4%EC%B4%9D%EC%9E%A5%EC%9D%80%20%EC%A0%84%EC%9F%81%20%EC%A4%91%EC%9D%B8%20%EB%91%90%20%ED%8C%8C%EB%B2%8C%20%EA%B0%84%EC%97%90%20%ED%8F%89%ED%99%94%EC%A1%B0%EC%95%BD%EC%9D%84%20%ED%98%91%EC%83%81%ED%95%98%EA%B8%B0%20%EC%9C%84%ED%95%B4%EC%84%9C%20%ED%95%84%EC%82%AC%EC%A0%81%EC%9C%BC%EB%A1%9C%20%EB%85%B8%EB%A0%A5%ED%95%98%EA%B3%A0%20%EC%9E%88%EB%8B%A4.)
^ko-Q0850-answer


### Answers 851–900

**ko-Q0851** — 너 어디 가고 싶니?

Where do you want to go?

Why: Contrast and coordination. [[Korean#^ko-Q0851|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%84%88%20%EC%96%B4%EB%94%94%20%EA%B0%80%EA%B3%A0%20%EC%8B%B6%EB%8B%88%3F)
^ko-Q0851-answer

**ko-Q0852** — 너 어디 가고 싶니?

Where do you want to go?

-지만 marks contrast/concession; -고 often links predicates. Tense and subject interpretation can depend on the linked clauses rather than an English word-for-word connector.

Why: Contrast and coordination. [[Korean#^ko-Q0852|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%84%88%20%EC%96%B4%EB%94%94%20%EA%B0%80%EA%B3%A0%20%EC%8B%B6%EB%8B%88%3F)
^ko-Q0852-answer

**ko-Q0853** — 개는 잘 짖는 다고 좋은 개가 아니다.

A dog who is a good barker is not a good dog.

Expected form: **다고**

Why: Contrast and coordination. [[Korean#^ko-Q0853|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B0%9C%EB%8A%94%20%EC%9E%98%20%EC%A7%96%EB%8A%94%20%EB%8B%A4%EA%B3%A0%20%EC%A2%8B%EC%9D%80%20%EA%B0%9C%EA%B0%80%20%EC%95%84%EB%8B%88%EB%8B%A4.)
^ko-Q0853-answer

**ko-Q0854** — 개는 잘 짖는 다고 좋은 개가 아니다.

A dog who is a good barker is not a good dog.

Expected form: **다고**

Why: Contrast and coordination. [[Korean#^ko-Q0854|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B0%9C%EB%8A%94%20%EC%9E%98%20%EC%A7%96%EB%8A%94%20%EB%8B%A4%EA%B3%A0%20%EC%A2%8B%EC%9D%80%20%EA%B0%9C%EA%B0%80%20%EC%95%84%EB%8B%88%EB%8B%A4.)
^ko-Q0854-answer

**ko-Q0855** — 그게 내가 하고 있는 전부야.

That's all I'm doing.

Expected form: **하고**

Why: Contrast and coordination. [[Korean#^ko-Q0855|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EA%B2%8C%20%EB%82%B4%EA%B0%80%20%ED%95%98%EA%B3%A0%20%EC%9E%88%EB%8A%94%20%EC%A0%84%EB%B6%80%EC%95%BC.)
^ko-Q0855-answer

**ko-Q0856** — 그게 내가 하고 있는 전부야.

That's all I'm doing.

Why: Contrast and coordination. [[Korean#^ko-Q0856|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EA%B2%8C%20%EB%82%B4%EA%B0%80%20%ED%95%98%EA%B3%A0%20%EC%9E%88%EB%8A%94%20%EC%A0%84%EB%B6%80%EC%95%BC.)
^ko-Q0856-answer

**ko-Q0857** — 나는 기부를 하고 싶다.

I want to donate money.

Why: Contrast and coordination. [[Korean#^ko-Q0857|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%EA%B8%B0%EB%B6%80%EB%A5%BC%20%ED%95%98%EA%B3%A0%20%EC%8B%B6%EB%8B%A4.)
^ko-Q0857-answer

**ko-Q0858** — 나는 기부를 하고 싶다.

I want to donate money.

-지만 marks contrast/concession; -고 often links predicates. Tense and subject interpretation can depend on the linked clauses rather than an English word-for-word connector.

Why: Contrast and coordination. [[Korean#^ko-Q0858|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%EA%B8%B0%EB%B6%80%EB%A5%BC%20%ED%95%98%EA%B3%A0%20%EC%8B%B6%EB%8B%A4.)
^ko-Q0858-answer

**ko-Q0859** — 그게 네가 하고 싶은 말 전부니?

Is that all you want to say?

Expected form: **하고**

Why: Contrast and coordination. [[Korean#^ko-Q0859|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EA%B2%8C%20%EB%84%A4%EA%B0%80%20%ED%95%98%EA%B3%A0%20%EC%8B%B6%EC%9D%80%20%EB%A7%90%20%EC%A0%84%EB%B6%80%EB%8B%88%3F)
^ko-Q0859-answer

**ko-Q0860** — 그게 네가 하고 싶은 말 전부니?

Is that all you want to say?

Expected form: **하고**

Why: Contrast and coordination. [[Korean#^ko-Q0860|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EA%B2%8C%20%EB%84%A4%EA%B0%80%20%ED%95%98%EA%B3%A0%20%EC%8B%B6%EC%9D%80%20%EB%A7%90%20%EC%A0%84%EB%B6%80%EB%8B%88%3F)
^ko-Q0860-answer

**ko-Q0861** — 집주인이 집세를 올리고 싶어한다.

The landlord wants to raise the rent.

Expected form: **올리고**

Why: Contrast and coordination. [[Korean#^ko-Q0861|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A7%91%EC%A3%BC%EC%9D%B8%EC%9D%B4%20%EC%A7%91%EC%84%B8%EB%A5%BC%20%EC%98%AC%EB%A6%AC%EA%B3%A0%20%EC%8B%B6%EC%96%B4%ED%95%9C%EB%8B%A4.)
^ko-Q0861-answer

**ko-Q0862** — 집주인이 집세를 올리고 싶어한다.

The landlord wants to raise the rent.

Why: Contrast and coordination. [[Korean#^ko-Q0862|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A7%91%EC%A3%BC%EC%9D%B8%EC%9D%B4%20%EC%A7%91%EC%84%B8%EB%A5%BC%20%EC%98%AC%EB%A6%AC%EA%B3%A0%20%EC%8B%B6%EC%96%B4%ED%95%9C%EB%8B%A4.)
^ko-Q0862-answer

**ko-Q0863** — 그래서 나는 여행을 사랑하고, 많은 문화와 언어를 경험하고 싶다.

That's why I like traveling, and would like to experience many different cultures.

Why: Contrast and coordination. [[Korean#^ko-Q0863|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EB%9E%98%EC%84%9C%20%EB%82%98%EB%8A%94%20%EC%97%AC%ED%96%89%EC%9D%84%20%EC%82%AC%EB%9E%91%ED%95%98%EA%B3%A0%2C%20%EB%A7%8E%EC%9D%80%20%EB%AC%B8%ED%99%94%EC%99%80%20%EC%96%B8%EC%96%B4%EB%A5%BC%20%EA%B2%BD%ED%97%98%ED%95%98%EA%B3%A0%20%EC%8B%B6%EB%8B%A4.)
^ko-Q0863-answer

**ko-Q0864** — 그래서 나는 여행을 사랑하고, 많은 문화와 언어를 경험하고 싶다.

That's why I like traveling, and would like to experience many different cultures.

-지만 marks contrast/concession; -고 often links predicates. Tense and subject interpretation can depend on the linked clauses rather than an English word-for-word connector.

Why: Contrast and coordination. [[Korean#^ko-Q0864|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EB%9E%98%EC%84%9C%20%EB%82%98%EB%8A%94%20%EC%97%AC%ED%96%89%EC%9D%84%20%EC%82%AC%EB%9E%91%ED%95%98%EA%B3%A0%2C%20%EB%A7%8E%EC%9D%80%20%EB%AC%B8%ED%99%94%EC%99%80%20%EC%96%B8%EC%96%B4%EB%A5%BC%20%EA%B2%BD%ED%97%98%ED%95%98%EA%B3%A0%20%EC%8B%B6%EB%8B%A4.)
^ko-Q0864-answer

**ko-Q0865** — 고슴도치에 놀란 호랑이 밤송이 보고 절한다.

A tiger surprised by a hedgehog will bow before the chestnut burrs.

Expected form: **보고**

Why: Contrast and coordination. [[Korean#^ko-Q0865|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B3%A0%EC%8A%B4%EB%8F%84%EC%B9%98%EC%97%90%20%EB%86%80%EB%9E%80%20%ED%98%B8%EB%9E%91%EC%9D%B4%20%EB%B0%A4%EC%86%A1%EC%9D%B4%20%EB%B3%B4%EA%B3%A0%20%EC%A0%88%ED%95%9C%EB%8B%A4.)
^ko-Q0865-answer

**ko-Q0866** — 고슴도치에 놀란 호랑이 밤송이 보고 절한다.

A tiger surprised by a hedgehog will bow before the chestnut burrs.

Expected form: **보고**

Why: Contrast and coordination. [[Korean#^ko-Q0866|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B3%A0%EC%8A%B4%EB%8F%84%EC%B9%98%EC%97%90%20%EB%86%80%EB%9E%80%20%ED%98%B8%EB%9E%91%EC%9D%B4%20%EB%B0%A4%EC%86%A1%EC%9D%B4%20%EB%B3%B4%EA%B3%A0%20%EC%A0%88%ED%95%9C%EB%8B%A4.)
^ko-Q0866-answer

**ko-Q0867** — 이번 주는 운전연습을 하느라고 바빠요.

I am busy this week because I practice driving.

Expected form: **하느라고**

Why: Contrast and coordination. [[Korean#^ko-Q0867|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9D%B4%EB%B2%88%20%EC%A3%BC%EB%8A%94%20%EC%9A%B4%EC%A0%84%EC%97%B0%EC%8A%B5%EC%9D%84%20%ED%95%98%EB%8A%90%EB%9D%BC%EA%B3%A0%20%EB%B0%94%EB%B9%A0%EC%9A%94.)
^ko-Q0867-answer

**ko-Q0868** — 이번 주는 운전연습을 하느라고 바빠요.

I am busy this week because I practice driving.

Why: Contrast and coordination. [[Korean#^ko-Q0868|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9D%B4%EB%B2%88%20%EC%A3%BC%EB%8A%94%20%EC%9A%B4%EC%A0%84%EC%97%B0%EC%8A%B5%EC%9D%84%20%ED%95%98%EB%8A%90%EB%9D%BC%EA%B3%A0%20%EB%B0%94%EB%B9%A0%EC%9A%94.)
^ko-Q0868-answer

**ko-Q0869** — 그를 다시 보고 싶다.

I want to see that again.

Why: Contrast and coordination. [[Korean#^ko-Q0869|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EB%A5%BC%20%EB%8B%A4%EC%8B%9C%20%EB%B3%B4%EA%B3%A0%20%EC%8B%B6%EB%8B%A4.)
^ko-Q0869-answer

**ko-Q0870** — 그를 다시 보고 싶다.

I want to see that again.

-지만 marks contrast/concession; -고 often links predicates. Tense and subject interpretation can depend on the linked clauses rather than an English word-for-word connector.

Why: Contrast and coordination. [[Korean#^ko-Q0870|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EB%A5%BC%20%EB%8B%A4%EC%8B%9C%20%EB%B3%B4%EA%B3%A0%20%EC%8B%B6%EB%8B%A4.)
^ko-Q0870-answer

**ko-Q0871** — 톰은 메리가 과다체중이라고 했다.

Tom said Mary was overweight.

Expected form: **과다체중이라고**

Why: Contrast and coordination. [[Korean#^ko-Q0871|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EB%A9%94%EB%A6%AC%EA%B0%80%20%EA%B3%BC%EB%8B%A4%EC%B2%B4%EC%A4%91%EC%9D%B4%EB%9D%BC%EA%B3%A0%20%ED%96%88%EB%8B%A4.)
^ko-Q0871-answer

**ko-Q0872** — 톰은 메리가 과다체중이라고 했다.

Tom said Mary was overweight.

Expected form: **과다체중이라고**

Why: Contrast and coordination. [[Korean#^ko-Q0872|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EB%A9%94%EB%A6%AC%EA%B0%80%20%EA%B3%BC%EB%8B%A4%EC%B2%B4%EC%A4%91%EC%9D%B4%EB%9D%BC%EA%B3%A0%20%ED%96%88%EB%8B%A4.)
^ko-Q0872-answer

**ko-Q0873** — 나는 북한에 가고 싶다.

I want to go to North Korea.

Expected form: **가고**

Why: Contrast and coordination. [[Korean#^ko-Q0873|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%EB%B6%81%ED%95%9C%EC%97%90%20%EA%B0%80%EA%B3%A0%20%EC%8B%B6%EB%8B%A4.)
^ko-Q0873-answer

**ko-Q0874** — 나는 북한에 가고 싶다.

I want to go to North Korea.

Why: Contrast and coordination. [[Korean#^ko-Q0874|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%EB%B6%81%ED%95%9C%EC%97%90%20%EA%B0%80%EA%B3%A0%20%EC%8B%B6%EB%8B%A4.)
^ko-Q0874-answer

**ko-Q0875** — 그 여자는 그 남자의 사생활에 대해 전혀 알고 싶어하질 않던데.

She didn't want to know anything about his personal life.

Why: Contrast and coordination. [[Korean#^ko-Q0875|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%20%EC%97%AC%EC%9E%90%EB%8A%94%20%EA%B7%B8%20%EB%82%A8%EC%9E%90%EC%9D%98%20%EC%82%AC%EC%83%9D%ED%99%9C%EC%97%90%20%EB%8C%80%ED%95%B4%20%EC%A0%84%ED%98%80%20%EC%95%8C%EA%B3%A0%20%EC%8B%B6%EC%96%B4%ED%95%98%EC%A7%88%20%EC%95%8A%EB%8D%98%EB%8D%B0.)
^ko-Q0875-answer

**ko-Q0876** — 그 여자는 그 남자의 사생활에 대해 전혀 알고 싶어하질 않던데.

She didn't want to know anything about his personal life.

-지만 marks contrast/concession; -고 often links predicates. Tense and subject interpretation can depend on the linked clauses rather than an English word-for-word connector.

Why: Contrast and coordination. [[Korean#^ko-Q0876|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%20%EC%97%AC%EC%9E%90%EB%8A%94%20%EA%B7%B8%20%EB%82%A8%EC%9E%90%EC%9D%98%20%EC%82%AC%EC%83%9D%ED%99%9C%EC%97%90%20%EB%8C%80%ED%95%B4%20%EC%A0%84%ED%98%80%20%EC%95%8C%EA%B3%A0%20%EC%8B%B6%EC%96%B4%ED%95%98%EC%A7%88%20%EC%95%8A%EB%8D%98%EB%8D%B0.)
^ko-Q0876-answer

**ko-Q0877** — 탐은 메리가 어디에 있었는지 알고 싶었다.

Tom wanted to know where Mary had been.

Expected form: **알고**

Why: Contrast and coordination. [[Korean#^ko-Q0877|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%83%90%EC%9D%80%20%EB%A9%94%EB%A6%AC%EA%B0%80%20%EC%96%B4%EB%94%94%EC%97%90%20%EC%9E%88%EC%97%88%EB%8A%94%EC%A7%80%20%EC%95%8C%EA%B3%A0%20%EC%8B%B6%EC%97%88%EB%8B%A4.)
^ko-Q0877-answer

**ko-Q0878** — 탐은 메리가 어디에 있었는지 알고 싶었다.

Tom wanted to know where Mary had been.

Expected form: **알고**

Why: Contrast and coordination. [[Korean#^ko-Q0878|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%83%90%EC%9D%80%20%EB%A9%94%EB%A6%AC%EA%B0%80%20%EC%96%B4%EB%94%94%EC%97%90%20%EC%9E%88%EC%97%88%EB%8A%94%EC%A7%80%20%EC%95%8C%EA%B3%A0%20%EC%8B%B6%EC%97%88%EB%8B%A4.)
^ko-Q0878-answer

**ko-Q0879** — 딸기가 있는데 너 먹고 싶니?

I have some strawberries. Do you want some?

Expected form: **먹고**

Why: Contrast and coordination. [[Korean#^ko-Q0879|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%94%B8%EA%B8%B0%EA%B0%80%20%EC%9E%88%EB%8A%94%EB%8D%B0%20%EB%84%88%20%EB%A8%B9%EA%B3%A0%20%EC%8B%B6%EB%8B%88%3F)
^ko-Q0879-answer

**ko-Q0880** — 딸기가 있는데 너 먹고 싶니?

I have some strawberries. Do you want some?

Why: Contrast and coordination. [[Korean#^ko-Q0880|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%94%B8%EA%B8%B0%EA%B0%80%20%EC%9E%88%EB%8A%94%EB%8D%B0%20%EB%84%88%20%EB%A8%B9%EA%B3%A0%20%EC%8B%B6%EB%8B%88%3F)
^ko-Q0880-answer

**ko-Q0881** — 그가 문을 열려고 하였다.

He tried to open the door.

Why: Contrast and coordination. [[Korean#^ko-Q0881|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EA%B0%80%20%EB%AC%B8%EC%9D%84%20%EC%97%B4%EB%A0%A4%EA%B3%A0%20%ED%95%98%EC%98%80%EB%8B%A4.)
^ko-Q0881-answer

**ko-Q0882** — 그가 문을 열려고 하였다.

He tried to open the door.

-지만 marks contrast/concession; -고 often links predicates. Tense and subject interpretation can depend on the linked clauses rather than an English word-for-word connector.

Why: Contrast and coordination. [[Korean#^ko-Q0882|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EA%B0%80%20%EB%AC%B8%EC%9D%84%20%EC%97%B4%EB%A0%A4%EA%B3%A0%20%ED%95%98%EC%98%80%EB%8B%A4.)
^ko-Q0882-answer

**ko-Q0883** — 그래서 나는 프랑스에 오래 머무르고 싶고, 그러기 위한 돈이 필요하다.

This is why I would like an extended visa as well as as funds for my stay.

Expected form: **머무르고**

Why: Contrast and coordination. [[Korean#^ko-Q0883|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EB%9E%98%EC%84%9C%20%EB%82%98%EB%8A%94%20%ED%94%84%EB%9E%91%EC%8A%A4%EC%97%90%20%EC%98%A4%EB%9E%98%20%EB%A8%B8%EB%AC%B4%EB%A5%B4%EA%B3%A0%20%EC%8B%B6%EA%B3%A0%2C%20%EA%B7%B8%EB%9F%AC%EA%B8%B0%20%EC%9C%84%ED%95%9C%20%EB%8F%88%EC%9D%B4%20%ED%95%84%EC%9A%94%ED%95%98%EB%8B%A4.)
^ko-Q0883-answer

**ko-Q0884** — 그래서 나는 프랑스에 오래 머무르고 싶고, 그러기 위한 돈이 필요하다.

This is why I would like an extended visa as well as as funds for my stay.

Expected form: **머무르고**

Why: Contrast and coordination. [[Korean#^ko-Q0884|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EB%9E%98%EC%84%9C%20%EB%82%98%EB%8A%94%20%ED%94%84%EB%9E%91%EC%8A%A4%EC%97%90%20%EC%98%A4%EB%9E%98%20%EB%A8%B8%EB%AC%B4%EB%A5%B4%EA%B3%A0%20%EC%8B%B6%EA%B3%A0%2C%20%EA%B7%B8%EB%9F%AC%EA%B8%B0%20%EC%9C%84%ED%95%9C%20%EB%8F%88%EC%9D%B4%20%ED%95%84%EC%9A%94%ED%95%98%EB%8B%A4.)
^ko-Q0884-answer

**ko-Q0885** — 난 톰이 살인자라고 믿지 않아.

I don't believe Tom is a murderer.

Expected form: **살인자라고**

Why: Contrast and coordination. [[Korean#^ko-Q0885|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%9C%20%ED%86%B0%EC%9D%B4%20%EC%82%B4%EC%9D%B8%EC%9E%90%EB%9D%BC%EA%B3%A0%20%EB%AF%BF%EC%A7%80%20%EC%95%8A%EC%95%84.)
^ko-Q0885-answer

**ko-Q0886** — 난 톰이 살인자라고 믿지 않아.

I don't believe Tom is a murderer.

Why: Contrast and coordination. [[Korean#^ko-Q0886|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%9C%20%ED%86%B0%EC%9D%B4%20%EC%82%B4%EC%9D%B8%EC%9E%90%EB%9D%BC%EA%B3%A0%20%EB%AF%BF%EC%A7%80%20%EC%95%8A%EC%95%84.)
^ko-Q0886-answer

**ko-Q0887** — 그 말을 들은 후부터 나는 프랑스의 도시들과 시골을 여행하고 싶어졌고, 아름다운 언어인 프랑스어를 배우고 싶어졌으며, 무엇보다도, 프랑스 음식을 내 손으로 직접 만들고 싶어졌다.또한 프랑스의 분위기를 느끼고 싶다.

Since I heard this, I want to travel french cities and provinces, learn beautiful French, and more than anything prepare French cuisine with my own hands. And feel the atmosphere of France.

Why: Contrast and coordination. [[Korean#^ko-Q0887|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%20%EB%A7%90%EC%9D%84%20%EB%93%A4%EC%9D%80%20%ED%9B%84%EB%B6%80%ED%84%B0%20%EB%82%98%EB%8A%94%20%ED%94%84%EB%9E%91%EC%8A%A4%EC%9D%98%20%EB%8F%84%EC%8B%9C%EB%93%A4%EA%B3%BC%20%EC%8B%9C%EA%B3%A8%EC%9D%84%20%EC%97%AC%ED%96%89%ED%95%98%EA%B3%A0%20%EC%8B%B6%EC%96%B4%EC%A1%8C%EA%B3%A0%2C%20%EC%95%84%EB%A6%84%EB%8B%A4%EC%9A%B4%20%EC%96%B8%EC%96%B4%EC%9D%B8%20%ED%94%84%EB%9E%91%EC%8A%A4%EC%96%B4%EB%A5%BC%20%EB%B0%B0%EC%9A%B0%EA%B3%A0%20%EC%8B%B6%EC%96%B4%EC%A1%8C%EC%9C%BC%EB%A9%B0%2C%20%EB%AC%B4%EC%97%87%EB%B3%B4%EB%8B%A4%EB%8F%84%2C%20%ED%94%84%EB%9E%91%EC%8A%A4%20%EC%9D%8C%EC%8B%9D%EC%9D%84%20%EB%82%B4%20%EC%86%90%EC%9C%BC%EB%A1%9C%20%EC%A7%81%EC%A0%91%20%EB%A7%8C%EB%93%A4%EA%B3%A0%20%EC%8B%B6%EC%96%B4%EC%A1%8C%EB%8B%A4.%EB%98%90%ED%95%9C%20%ED%94%84%EB%9E%91%EC%8A%A4%EC%9D%98%20%EB%B6%84%EC%9C%84%EA%B8%B0%EB%A5%BC%20%EB%8A%90%EB%81%BC%EA%B3%A0%20%EC%8B%B6%EB%8B%A4.)
^ko-Q0887-answer

**ko-Q0888** — 그 말을 들은 후부터 나는 프랑스의 도시들과 시골을 여행하고 싶어졌고, 아름다운 언어인 프랑스어를 배우고 싶어졌으며, 무엇보다도, 프랑스 음식을 내 손으로 직접 만들고 싶어졌다.또한 프랑스의 분위기를 느끼고 싶다.

Since I heard this, I want to travel french cities and provinces, learn beautiful French, and more than anything prepare French cuisine with my own hands. And feel the atmosphere of France.

-지만 marks contrast/concession; -고 often links predicates. Tense and subject interpretation can depend on the linked clauses rather than an English word-for-word connector.

Why: Contrast and coordination. [[Korean#^ko-Q0888|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%20%EB%A7%90%EC%9D%84%20%EB%93%A4%EC%9D%80%20%ED%9B%84%EB%B6%80%ED%84%B0%20%EB%82%98%EB%8A%94%20%ED%94%84%EB%9E%91%EC%8A%A4%EC%9D%98%20%EB%8F%84%EC%8B%9C%EB%93%A4%EA%B3%BC%20%EC%8B%9C%EA%B3%A8%EC%9D%84%20%EC%97%AC%ED%96%89%ED%95%98%EA%B3%A0%20%EC%8B%B6%EC%96%B4%EC%A1%8C%EA%B3%A0%2C%20%EC%95%84%EB%A6%84%EB%8B%A4%EC%9A%B4%20%EC%96%B8%EC%96%B4%EC%9D%B8%20%ED%94%84%EB%9E%91%EC%8A%A4%EC%96%B4%EB%A5%BC%20%EB%B0%B0%EC%9A%B0%EA%B3%A0%20%EC%8B%B6%EC%96%B4%EC%A1%8C%EC%9C%BC%EB%A9%B0%2C%20%EB%AC%B4%EC%97%87%EB%B3%B4%EB%8B%A4%EB%8F%84%2C%20%ED%94%84%EB%9E%91%EC%8A%A4%20%EC%9D%8C%EC%8B%9D%EC%9D%84%20%EB%82%B4%20%EC%86%90%EC%9C%BC%EB%A1%9C%20%EC%A7%81%EC%A0%91%20%EB%A7%8C%EB%93%A4%EA%B3%A0%20%EC%8B%B6%EC%96%B4%EC%A1%8C%EB%8B%A4.%EB%98%90%ED%95%9C%20%ED%94%84%EB%9E%91%EC%8A%A4%EC%9D%98%20%EB%B6%84%EC%9C%84%EA%B8%B0%EB%A5%BC%20%EB%8A%90%EB%81%BC%EA%B3%A0%20%EC%8B%B6%EB%8B%A4.)
^ko-Q0888-answer

**ko-Q0889** — 주소하고 집 전화 번호를 쓰세요.

Write the address and the home phone number.

Expected form: **주소하고**

Why: Contrast and coordination. [[Korean#^ko-Q0889|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A3%BC%EC%86%8C%ED%95%98%EA%B3%A0%20%EC%A7%91%20%EC%A0%84%ED%99%94%20%EB%B2%88%ED%98%B8%EB%A5%BC%20%EC%93%B0%EC%84%B8%EC%9A%94.)
^ko-Q0889-answer

**ko-Q0890** — 주소하고 집 전화 번호를 쓰세요.

Write the address and the home phone number.

Expected form: **주소하고**

Why: Contrast and coordination. [[Korean#^ko-Q0890|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A3%BC%EC%86%8C%ED%95%98%EA%B3%A0%20%EC%A7%91%20%EC%A0%84%ED%99%94%20%EB%B2%88%ED%98%B8%EB%A5%BC%20%EC%93%B0%EC%84%B8%EC%9A%94.)
^ko-Q0890-answer

**ko-Q0891** — 톰은 왜 자기 집에 개가 있었는지 알고 싶었다.

Tom wondered why there was a dog in his house.

Expected form: **알고**

Why: Contrast and coordination. [[Korean#^ko-Q0891|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EC%99%9C%20%EC%9E%90%EA%B8%B0%20%EC%A7%91%EC%97%90%20%EA%B0%9C%EA%B0%80%20%EC%9E%88%EC%97%88%EB%8A%94%EC%A7%80%20%EC%95%8C%EA%B3%A0%20%EC%8B%B6%EC%97%88%EB%8B%A4.)
^ko-Q0891-answer

**ko-Q0892** — 톰은 왜 자기 집에 개가 있었는지 알고 싶었다.

Tom wondered why there was a dog in his house.

Why: Contrast and coordination. [[Korean#^ko-Q0892|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EC%99%9C%20%EC%9E%90%EA%B8%B0%20%EC%A7%91%EC%97%90%20%EA%B0%9C%EA%B0%80%20%EC%9E%88%EC%97%88%EB%8A%94%EC%A7%80%20%EC%95%8C%EA%B3%A0%20%EC%8B%B6%EC%97%88%EB%8B%A4.)
^ko-Q0892-answer

**ko-Q0893** — 우리는 후퇴하고 있었다.

We were retreating.

Why: Contrast and coordination. [[Korean#^ko-Q0893|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9A%B0%EB%A6%AC%EB%8A%94%20%ED%9B%84%ED%87%B4%ED%95%98%EA%B3%A0%20%EC%9E%88%EC%97%88%EB%8B%A4.)
^ko-Q0893-answer

**ko-Q0894** — 우리는 후퇴하고 있었다.

We were retreating.

-지만 marks contrast/concession; -고 often links predicates. Tense and subject interpretation can depend on the linked clauses rather than an English word-for-word connector.

Why: Contrast and coordination. [[Korean#^ko-Q0894|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9A%B0%EB%A6%AC%EB%8A%94%20%ED%9B%84%ED%87%B4%ED%95%98%EA%B3%A0%20%EC%9E%88%EC%97%88%EB%8B%A4.)
^ko-Q0894-answer

**ko-Q0895** — 바로 그게 내가 하고 싶은 말이었다.

You took the words right out of my mouth.

Expected form: **하고**

Why: Contrast and coordination. [[Korean#^ko-Q0895|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%B0%94%EB%A1%9C%20%EA%B7%B8%EA%B2%8C%20%EB%82%B4%EA%B0%80%20%ED%95%98%EA%B3%A0%20%EC%8B%B6%EC%9D%80%20%EB%A7%90%EC%9D%B4%EC%97%88%EB%8B%A4.)
^ko-Q0895-answer

**ko-Q0896** — 바로 그게 내가 하고 싶은 말이었다.

You took the words right out of my mouth.

Expected form: **하고**

Why: Contrast and coordination. [[Korean#^ko-Q0896|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%B0%94%EB%A1%9C%20%EA%B7%B8%EA%B2%8C%20%EB%82%B4%EA%B0%80%20%ED%95%98%EA%B3%A0%20%EC%8B%B6%EC%9D%80%20%EB%A7%90%EC%9D%B4%EC%97%88%EB%8B%A4.)
^ko-Q0896-answer

**ko-Q0897** — 어째서 네가 프랑스어를 공부하고 있는지 모르겠어.

I don't know why you're studying French.

Expected form: **공부하고**

Why: Contrast and coordination. [[Korean#^ko-Q0897|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%96%B4%EC%A7%B8%EC%84%9C%20%EB%84%A4%EA%B0%80%20%ED%94%84%EB%9E%91%EC%8A%A4%EC%96%B4%EB%A5%BC%20%EA%B3%B5%EB%B6%80%ED%95%98%EA%B3%A0%20%EC%9E%88%EB%8A%94%EC%A7%80%20%EB%AA%A8%EB%A5%B4%EA%B2%A0%EC%96%B4.)
^ko-Q0897-answer

**ko-Q0898** — 어째서 네가 프랑스어를 공부하고 있는지 모르겠어.

I don't know why you're studying French.

Why: Contrast and coordination. [[Korean#^ko-Q0898|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%96%B4%EC%A7%B8%EC%84%9C%20%EB%84%A4%EA%B0%80%20%ED%94%84%EB%9E%91%EC%8A%A4%EC%96%B4%EB%A5%BC%20%EA%B3%B5%EB%B6%80%ED%95%98%EA%B3%A0%20%EC%9E%88%EB%8A%94%EC%A7%80%20%EB%AA%A8%EB%A5%B4%EA%B2%A0%EC%96%B4.)
^ko-Q0898-answer

**ko-Q0899** — 나는 그녀를 다시 보고 싶어 미치겠다.

I am dying to see her again.

Why: Contrast and coordination. [[Korean#^ko-Q0899|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%EA%B7%B8%EB%85%80%EB%A5%BC%20%EB%8B%A4%EC%8B%9C%20%EB%B3%B4%EA%B3%A0%20%EC%8B%B6%EC%96%B4%20%EB%AF%B8%EC%B9%98%EA%B2%A0%EB%8B%A4.)
^ko-Q0899-answer

**ko-Q0900** — 나는 그녀를 다시 보고 싶어 미치겠다.

I am dying to see her again.

-지만 marks contrast/concession; -고 often links predicates. Tense and subject interpretation can depend on the linked clauses rather than an English word-for-word connector.

Why: Contrast and coordination. [[Korean#^ko-Q0900|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%82%98%EB%8A%94%20%EA%B7%B8%EB%85%80%EB%A5%BC%20%EB%8B%A4%EC%8B%9C%20%EB%B3%B4%EA%B3%A0%20%EC%8B%B6%EC%96%B4%20%EB%AF%B8%EC%B9%98%EA%B2%A0%EB%8B%A4.)
^ko-Q0900-answer


### Answers 901–950

**ko-Q0901** — 거짓말 하지 마세요.

Don't you lie!

Expected form: **마세요**

Why: Requests and honorific endings. [[Korean#^ko-Q0901|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B1%B0%EC%A7%93%EB%A7%90%20%ED%95%98%EC%A7%80%20%EB%A7%88%EC%84%B8%EC%9A%94.)
^ko-Q0901-answer

**ko-Q0902** — 거짓말 하지 마세요.

Don't you lie!

Expected form: **마세요**

Why: Requests and honorific endings. [[Korean#^ko-Q0902|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B1%B0%EC%A7%93%EB%A7%90%20%ED%95%98%EC%A7%80%20%EB%A7%88%EC%84%B8%EC%9A%94.)
^ko-Q0902-answer

**ko-Q0903** — 와인 한 병 더 주세요.

One more bottle of wine, please.

Expected form: **주세요**

Why: Requests and honorific endings. [[Korean#^ko-Q0903|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%99%80%EC%9D%B8%20%ED%95%9C%20%EB%B3%91%20%EB%8D%94%20%EC%A3%BC%EC%84%B8%EC%9A%94.)
^ko-Q0903-answer

**ko-Q0904** — 와인 한 병 더 주세요.

One more bottle of wine, please.

Why: Requests and honorific endings. [[Korean#^ko-Q0904|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%99%80%EC%9D%B8%20%ED%95%9C%20%EB%B3%91%20%EB%8D%94%20%EC%A3%BC%EC%84%B8%EC%9A%94.)
^ko-Q0904-answer

**ko-Q0905** — 혹시 불분명한 점이 있을 경우 연락 주십시오.

In case something is not clear, please contact us.

Why: Requests and honorific endings. [[Korean#^ko-Q0905|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%98%B9%EC%8B%9C%20%EB%B6%88%EB%B6%84%EB%AA%85%ED%95%9C%20%EC%A0%90%EC%9D%B4%20%EC%9E%88%EC%9D%84%20%EA%B2%BD%EC%9A%B0%20%EC%97%B0%EB%9D%BD%20%EC%A3%BC%EC%8B%AD%EC%8B%9C%EC%98%A4.)
^ko-Q0905-answer

**ko-Q0906** — 혹시 불분명한 점이 있을 경우 연락 주십시오.

In case something is not clear, please contact us.

-(으)세요 commonly forms polite requests and also contains honorific subject marking in other uses. -(으)십시오 is more formal. Respectful reference and polite address are related but separate choices.

Why: Requests and honorific endings. [[Korean#^ko-Q0906|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%98%B9%EC%8B%9C%20%EB%B6%88%EB%B6%84%EB%AA%85%ED%95%9C%20%EC%A0%90%EC%9D%B4%20%EC%9E%88%EC%9D%84%20%EA%B2%BD%EC%9A%B0%20%EC%97%B0%EB%9D%BD%20%EC%A3%BC%EC%8B%AD%EC%8B%9C%EC%98%A4.)
^ko-Q0906-answer

**ko-Q0907** — 먹으러 갈만한 괜찮은 식당을 골라주세요.

Choose a good restaurant to go to eat at.

Expected form: **골라주세요**

Why: Requests and honorific endings. [[Korean#^ko-Q0907|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%A8%B9%EC%9C%BC%EB%9F%AC%20%EA%B0%88%EB%A7%8C%ED%95%9C%20%EA%B4%9C%EC%B0%AE%EC%9D%80%20%EC%8B%9D%EB%8B%B9%EC%9D%84%20%EA%B3%A8%EB%9D%BC%EC%A3%BC%EC%84%B8%EC%9A%94.)
^ko-Q0907-answer

**ko-Q0908** — 먹으러 갈만한 괜찮은 식당을 골라주세요.

Choose a good restaurant to go to eat at.

Expected form: **골라주세요**

Why: Requests and honorific endings. [[Korean#^ko-Q0908|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%A8%B9%EC%9C%BC%EB%9F%AC%20%EA%B0%88%EB%A7%8C%ED%95%9C%20%EA%B4%9C%EC%B0%AE%EC%9D%80%20%EC%8B%9D%EB%8B%B9%EC%9D%84%20%EA%B3%A8%EB%9D%BC%EC%A3%BC%EC%84%B8%EC%9A%94.)
^ko-Q0908-answer

**ko-Q0909** — 물 좀 주세요, 제발.

Some water, please.

Expected form: **주세요**

Why: Requests and honorific endings. [[Korean#^ko-Q0909|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%AC%BC%20%EC%A2%80%20%EC%A3%BC%EC%84%B8%EC%9A%94%2C%20%EC%A0%9C%EB%B0%9C.)
^ko-Q0909-answer

**ko-Q0910** — 물 좀 주세요, 제발.

Some water, please.

Why: Requests and honorific endings. [[Korean#^ko-Q0910|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%AC%BC%20%EC%A2%80%20%EC%A3%BC%EC%84%B8%EC%9A%94%2C%20%EC%A0%9C%EB%B0%9C.)
^ko-Q0910-answer

**ko-Q0911** — 제발, 절 죽이지 마세요.

Please, don't kill me.

Why: Requests and honorific endings. [[Korean#^ko-Q0911|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A0%9C%EB%B0%9C%2C%20%EC%A0%88%20%EC%A3%BD%EC%9D%B4%EC%A7%80%20%EB%A7%88%EC%84%B8%EC%9A%94.)
^ko-Q0911-answer

**ko-Q0912** — 제발, 절 죽이지 마세요.

Please, don't kill me.

-(으)세요 commonly forms polite requests and also contains honorific subject marking in other uses. -(으)십시오 is more formal. Respectful reference and polite address are related but separate choices.

Why: Requests and honorific endings. [[Korean#^ko-Q0912|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A0%9C%EB%B0%9C%2C%20%EC%A0%88%20%EC%A3%BD%EC%9D%B4%EC%A7%80%20%EB%A7%88%EC%84%B8%EC%9A%94.)
^ko-Q0912-answer

**ko-Q0913** — 저작권이 있는 출처의 문장을 추가하지 마십시오.

Don't add sentences from copyrighted sources.

Expected form: **마십시오**

Why: Requests and honorific endings. [[Korean#^ko-Q0913|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A0%80%EC%9E%91%EA%B6%8C%EC%9D%B4%20%EC%9E%88%EB%8A%94%20%EC%B6%9C%EC%B2%98%EC%9D%98%20%EB%AC%B8%EC%9E%A5%EC%9D%84%20%EC%B6%94%EA%B0%80%ED%95%98%EC%A7%80%20%EB%A7%88%EC%8B%AD%EC%8B%9C%EC%98%A4.)
^ko-Q0913-answer

**ko-Q0914** — 저작권이 있는 출처의 문장을 추가하지 마십시오.

Don't add sentences from copyrighted sources.

Expected form: **마십시오**

Why: Requests and honorific endings. [[Korean#^ko-Q0914|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A0%80%EC%9E%91%EA%B6%8C%EC%9D%B4%20%EC%9E%88%EB%8A%94%20%EC%B6%9C%EC%B2%98%EC%9D%98%20%EB%AC%B8%EC%9E%A5%EC%9D%84%20%EC%B6%94%EA%B0%80%ED%95%98%EC%A7%80%20%EB%A7%88%EC%8B%AD%EC%8B%9C%EC%98%A4.)
^ko-Q0914-answer

**ko-Q0915** — 제 사과를 받아 주세요.

Please accept my apology.

Expected form: **주세요**

Why: Requests and honorific endings. [[Korean#^ko-Q0915|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A0%9C%20%EC%82%AC%EA%B3%BC%EB%A5%BC%20%EB%B0%9B%EC%95%84%20%EC%A3%BC%EC%84%B8%EC%9A%94.)
^ko-Q0915-answer

**ko-Q0916** — 제 사과를 받아 주세요.

Please accept my apology.

Why: Requests and honorific endings. [[Korean#^ko-Q0916|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A0%9C%20%EC%82%AC%EA%B3%BC%EB%A5%BC%20%EB%B0%9B%EC%95%84%20%EC%A3%BC%EC%84%B8%EC%9A%94.)
^ko-Q0916-answer

**ko-Q0917** — 거짓말 하지 마세요, 알았죠?

Don't lie anymore, OK?

Why: Requests and honorific endings. [[Korean#^ko-Q0917|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B1%B0%EC%A7%93%EB%A7%90%20%ED%95%98%EC%A7%80%20%EB%A7%88%EC%84%B8%EC%9A%94%2C%20%EC%95%8C%EC%95%98%EC%A3%A0%3F)
^ko-Q0917-answer

**ko-Q0918** — 거짓말 하지 마세요, 알았죠?

Don't lie anymore, OK?

-(으)세요 commonly forms polite requests and also contains honorific subject marking in other uses. -(으)십시오 is more formal. Respectful reference and polite address are related but separate choices.

Why: Requests and honorific endings. [[Korean#^ko-Q0918|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B1%B0%EC%A7%93%EB%A7%90%20%ED%95%98%EC%A7%80%20%EB%A7%88%EC%84%B8%EC%9A%94%2C%20%EC%95%8C%EC%95%98%EC%A3%A0%3F)
^ko-Q0918-answer

**ko-Q0919** — 지금부터 제 얘기 잘 들으세요.

Now, listen carefully to what I am saying.

Expected form: **들으세요**

Why: Requests and honorific endings. [[Korean#^ko-Q0919|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A7%80%EA%B8%88%EB%B6%80%ED%84%B0%20%EC%A0%9C%20%EC%96%98%EA%B8%B0%20%EC%9E%98%20%EB%93%A4%EC%9C%BC%EC%84%B8%EC%9A%94.)
^ko-Q0919-answer

**ko-Q0920** — 지금부터 제 얘기 잘 들으세요.

Now, listen carefully to what I am saying.

Expected form: **들으세요**

Why: Requests and honorific endings. [[Korean#^ko-Q0920|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A7%80%EA%B8%88%EB%B6%80%ED%84%B0%20%EC%A0%9C%20%EC%96%98%EA%B8%B0%20%EC%9E%98%20%EB%93%A4%EC%9C%BC%EC%84%B8%EC%9A%94.)
^ko-Q0920-answer

**ko-Q0921** — 음악 소리를 좀 줄이세요.

Please turn the music down a bit.

Expected form: **줄이세요**

Why: Requests and honorific endings. [[Korean#^ko-Q0921|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9D%8C%EC%95%85%20%EC%86%8C%EB%A6%AC%EB%A5%BC%20%EC%A2%80%20%EC%A4%84%EC%9D%B4%EC%84%B8%EC%9A%94.)
^ko-Q0921-answer

**ko-Q0922** — 음악 소리를 좀 줄이세요.

Please turn the music down a bit.

Why: Requests and honorific endings. [[Korean#^ko-Q0922|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9D%8C%EC%95%85%20%EC%86%8C%EB%A6%AC%EB%A5%BC%20%EC%A2%80%20%EC%A4%84%EC%9D%B4%EC%84%B8%EC%9A%94.)
^ko-Q0922-answer

**ko-Q0923** — 니 맘대로 하세요.

Do what you want.

Why: Requests and honorific endings. [[Korean#^ko-Q0923|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%8B%88%20%EB%A7%98%EB%8C%80%EB%A1%9C%20%ED%95%98%EC%84%B8%EC%9A%94.)
^ko-Q0923-answer

**ko-Q0924** — 니 맘대로 하세요.

Do what you want.

-(으)세요 commonly forms polite requests and also contains honorific subject marking in other uses. -(으)십시오 is more formal. Respectful reference and polite address are related but separate choices.

Why: Requests and honorific endings. [[Korean#^ko-Q0924|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%8B%88%20%EB%A7%98%EB%8C%80%EB%A1%9C%20%ED%95%98%EC%84%B8%EC%9A%94.)
^ko-Q0924-answer

**ko-Q0925** — 혼자 내버려 두십시오!

Please leave me alone!

Expected form: **두십시오**

Why: Requests and honorific endings. [[Korean#^ko-Q0925|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%98%BC%EC%9E%90%20%EB%82%B4%EB%B2%84%EB%A0%A4%20%EB%91%90%EC%8B%AD%EC%8B%9C%EC%98%A4%21)
^ko-Q0925-answer

**ko-Q0926** — 혼자 내버려 두십시오!

Please leave me alone!

Expected form: **두십시오**

Why: Requests and honorific endings. [[Korean#^ko-Q0926|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%98%BC%EC%9E%90%20%EB%82%B4%EB%B2%84%EB%A0%A4%20%EB%91%90%EC%8B%AD%EC%8B%9C%EC%98%A4%21)
^ko-Q0926-answer

**ko-Q0927** — 식물에 물을 주세요.

Water the plants.

Expected form: **주세요**

Why: Requests and honorific endings. [[Korean#^ko-Q0927|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%8B%9D%EB%AC%BC%EC%97%90%20%EB%AC%BC%EC%9D%84%20%EC%A3%BC%EC%84%B8%EC%9A%94.)
^ko-Q0927-answer

**ko-Q0928** — 식물에 물을 주세요.

Water the plants.

Why: Requests and honorific endings. [[Korean#^ko-Q0928|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%8B%9D%EB%AC%BC%EC%97%90%20%EB%AC%BC%EC%9D%84%20%EC%A3%BC%EC%84%B8%EC%9A%94.)
^ko-Q0928-answer

**ko-Q0929** — 병원으로 데려다 주세요.

Please take me to the hospital.

Why: Requests and honorific endings. [[Korean#^ko-Q0929|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%B3%91%EC%9B%90%EC%9C%BC%EB%A1%9C%20%EB%8D%B0%EB%A0%A4%EB%8B%A4%20%EC%A3%BC%EC%84%B8%EC%9A%94.)
^ko-Q0929-answer

**ko-Q0930** — 병원으로 데려다 주세요.

Please take me to the hospital.

-(으)세요 commonly forms polite requests and also contains honorific subject marking in other uses. -(으)십시오 is more formal. Respectful reference and polite address are related but separate choices.

Why: Requests and honorific endings. [[Korean#^ko-Q0930|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%B3%91%EC%9B%90%EC%9C%BC%EB%A1%9C%20%EB%8D%B0%EB%A0%A4%EB%8B%A4%20%EC%A3%BC%EC%84%B8%EC%9A%94.)
^ko-Q0930-answer

**ko-Q0931** — 냉장고에 있는 거 아무거나 편하게 마음껏 드세요.

Please feel free to help yourself to anything in the fridge.

Expected form: **드세요**

Why: Requests and honorific endings. [[Korean#^ko-Q0931|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%83%89%EC%9E%A5%EA%B3%A0%EC%97%90%20%EC%9E%88%EB%8A%94%20%EA%B1%B0%20%EC%95%84%EB%AC%B4%EA%B1%B0%EB%82%98%20%ED%8E%B8%ED%95%98%EA%B2%8C%20%EB%A7%88%EC%9D%8C%EA%BB%8F%20%EB%93%9C%EC%84%B8%EC%9A%94.)
^ko-Q0931-answer

**ko-Q0932** — 냉장고에 있는 거 아무거나 편하게 마음껏 드세요.

Please feel free to help yourself to anything in the fridge.

Expected form: **드세요**

Why: Requests and honorific endings. [[Korean#^ko-Q0932|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%83%89%EC%9E%A5%EA%B3%A0%EC%97%90%20%EC%9E%88%EB%8A%94%20%EA%B1%B0%20%EC%95%84%EB%AC%B4%EA%B1%B0%EB%82%98%20%ED%8E%B8%ED%95%98%EA%B2%8C%20%EB%A7%88%EC%9D%8C%EA%BB%8F%20%EB%93%9C%EC%84%B8%EC%9A%94.)
^ko-Q0932-answer

**ko-Q0933** — 당신이 번역할 문장에 충실하게 번역하십시오. 다른 언어로 번역된 문장의 영향을 받지 마십시오.

Make a good translation of the sentence that you are translating. Don't let translations into other languages influence you.

Expected form: **번역하십시오**

Why: Requests and honorific endings. [[Korean#^ko-Q0933|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%8B%B9%EC%8B%A0%EC%9D%B4%20%EB%B2%88%EC%97%AD%ED%95%A0%20%EB%AC%B8%EC%9E%A5%EC%97%90%20%EC%B6%A9%EC%8B%A4%ED%95%98%EA%B2%8C%20%EB%B2%88%EC%97%AD%ED%95%98%EC%8B%AD%EC%8B%9C%EC%98%A4.%20%EB%8B%A4%EB%A5%B8%20%EC%96%B8%EC%96%B4%EB%A1%9C%20%EB%B2%88%EC%97%AD%EB%90%9C%20%EB%AC%B8%EC%9E%A5%EC%9D%98%20%EC%98%81%ED%96%A5%EC%9D%84%20%EB%B0%9B%EC%A7%80%20%EB%A7%88%EC%8B%AD%EC%8B%9C%EC%98%A4.)
^ko-Q0933-answer

**ko-Q0934** — 당신이 번역할 문장에 충실하게 번역하십시오. 다른 언어로 번역된 문장의 영향을 받지 마십시오.

Make a good translation of the sentence that you are translating. Don't let translations into other languages influence you.

Why: Requests and honorific endings. [[Korean#^ko-Q0934|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%8B%B9%EC%8B%A0%EC%9D%B4%20%EB%B2%88%EC%97%AD%ED%95%A0%20%EB%AC%B8%EC%9E%A5%EC%97%90%20%EC%B6%A9%EC%8B%A4%ED%95%98%EA%B2%8C%20%EB%B2%88%EC%97%AD%ED%95%98%EC%8B%AD%EC%8B%9C%EC%98%A4.%20%EB%8B%A4%EB%A5%B8%20%EC%96%B8%EC%96%B4%EB%A1%9C%20%EB%B2%88%EC%97%AD%EB%90%9C%20%EB%AC%B8%EC%9E%A5%EC%9D%98%20%EC%98%81%ED%96%A5%EC%9D%84%20%EB%B0%9B%EC%A7%80%20%EB%A7%88%EC%8B%AD%EC%8B%9C%EC%98%A4.)
^ko-Q0934-answer

**ko-Q0935** — 제가 올 때까지 기다려 주세요.

Wait here until I come back.

Why: Requests and honorific endings. [[Korean#^ko-Q0935|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A0%9C%EA%B0%80%20%EC%98%AC%20%EB%95%8C%EA%B9%8C%EC%A7%80%20%EA%B8%B0%EB%8B%A4%EB%A0%A4%20%EC%A3%BC%EC%84%B8%EC%9A%94.)
^ko-Q0935-answer

**ko-Q0936** — 제가 올 때까지 기다려 주세요.

Wait here until I come back.

-(으)세요 commonly forms polite requests and also contains honorific subject marking in other uses. -(으)십시오 is more formal. Respectful reference and polite address are related but separate choices.

Why: Requests and honorific endings. [[Korean#^ko-Q0936|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A0%9C%EA%B0%80%20%EC%98%AC%20%EB%95%8C%EA%B9%8C%EC%A7%80%20%EA%B8%B0%EB%8B%A4%EB%A0%A4%20%EC%A3%BC%EC%84%B8%EC%9A%94.)
^ko-Q0936-answer

**ko-Q0937** — 이 책을 읽으세요.

Read this book.

Expected form: **읽으세요**

Why: Requests and honorific endings. [[Korean#^ko-Q0937|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9D%B4%20%EC%B1%85%EC%9D%84%20%EC%9D%BD%EC%9C%BC%EC%84%B8%EC%9A%94.)
^ko-Q0937-answer

**ko-Q0938** — 이 책을 읽으세요.

Read this book.

Expected form: **읽으세요**

Why: Requests and honorific endings. [[Korean#^ko-Q0938|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9D%B4%20%EC%B1%85%EC%9D%84%20%EC%9D%BD%EC%9C%BC%EC%84%B8%EC%9A%94.)
^ko-Q0938-answer

**ko-Q0939** — 게임 어떻게 하는지 가르쳐주세요.

Please teach me how to play this game.

Expected form: **가르쳐주세요**

Why: Requests and honorific endings. [[Korean#^ko-Q0939|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B2%8C%EC%9E%84%20%EC%96%B4%EB%96%BB%EA%B2%8C%20%ED%95%98%EB%8A%94%EC%A7%80%20%EA%B0%80%EB%A5%B4%EC%B3%90%EC%A3%BC%EC%84%B8%EC%9A%94.)
^ko-Q0939-answer

**ko-Q0940** — 게임 어떻게 하는지 가르쳐주세요.

Please teach me how to play this game.

Why: Requests and honorific endings. [[Korean#^ko-Q0940|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B2%8C%EC%9E%84%20%EC%96%B4%EB%96%BB%EA%B2%8C%20%ED%95%98%EB%8A%94%EC%A7%80%20%EA%B0%80%EB%A5%B4%EC%B3%90%EC%A3%BC%EC%84%B8%EC%9A%94.)
^ko-Q0940-answer

**ko-Q0941** — 양질의 문장을 쓰세요.

Write high-quality sentences.

Why: Requests and honorific endings. [[Korean#^ko-Q0941|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%96%91%EC%A7%88%EC%9D%98%20%EB%AC%B8%EC%9E%A5%EC%9D%84%20%EC%93%B0%EC%84%B8%EC%9A%94.)
^ko-Q0941-answer

**ko-Q0942** — 양질의 문장을 쓰세요.

Write high-quality sentences.

-(으)세요 commonly forms polite requests and also contains honorific subject marking in other uses. -(으)십시오 is more formal. Respectful reference and polite address are related but separate choices.

Why: Requests and honorific endings. [[Korean#^ko-Q0942|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%96%91%EC%A7%88%EC%9D%98%20%EB%AC%B8%EC%9E%A5%EC%9D%84%20%EC%93%B0%EC%84%B8%EC%9A%94.)
^ko-Q0942-answer

**ko-Q0943** — 창백해 보이네요. 어디 아프세요?

You look pale. Are you ill?

Expected form: **아프세요**

Why: Requests and honorific endings. [[Korean#^ko-Q0943|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%B0%BD%EB%B0%B1%ED%95%B4%20%EB%B3%B4%EC%9D%B4%EB%84%A4%EC%9A%94.%20%EC%96%B4%EB%94%94%20%EC%95%84%ED%94%84%EC%84%B8%EC%9A%94%3F)
^ko-Q0943-answer

**ko-Q0944** — 창백해 보이네요. 어디 아프세요?

You look pale. Are you ill?

Expected form: **아프세요**

Why: Requests and honorific endings. [[Korean#^ko-Q0944|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%B0%BD%EB%B0%B1%ED%95%B4%20%EB%B3%B4%EC%9D%B4%EB%84%A4%EC%9A%94.%20%EC%96%B4%EB%94%94%20%EC%95%84%ED%94%84%EC%84%B8%EC%9A%94%3F)
^ko-Q0944-answer

**ko-Q0945** — 감자와 당근의 껍질을 벗겨주세요.

Peel the potatoes and carrots.

Expected form: **벗겨주세요**

Why: Requests and honorific endings. [[Korean#^ko-Q0945|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B0%90%EC%9E%90%EC%99%80%20%EB%8B%B9%EA%B7%BC%EC%9D%98%20%EA%BB%8D%EC%A7%88%EC%9D%84%20%EB%B2%97%EA%B2%A8%EC%A3%BC%EC%84%B8%EC%9A%94.)
^ko-Q0945-answer

**ko-Q0946** — 감자와 당근의 껍질을 벗겨주세요.

Peel the potatoes and carrots.

Why: Requests and honorific endings. [[Korean#^ko-Q0946|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B0%90%EC%9E%90%EC%99%80%20%EB%8B%B9%EA%B7%BC%EC%9D%98%20%EA%BB%8D%EC%A7%88%EC%9D%84%20%EB%B2%97%EA%B2%A8%EC%A3%BC%EC%84%B8%EC%9A%94.)
^ko-Q0946-answer

**ko-Q0947** — 조용히 해 주세요.

Please keep your voices down.

Why: Requests and honorific endings. [[Korean#^ko-Q0947|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A1%B0%EC%9A%A9%ED%9E%88%20%ED%95%B4%20%EC%A3%BC%EC%84%B8%EC%9A%94.)
^ko-Q0947-answer

**ko-Q0948** — 조용히 해 주세요.

Please keep your voices down.

-(으)세요 commonly forms polite requests and also contains honorific subject marking in other uses. -(으)십시오 is more formal. Respectful reference and polite address are related but separate choices.

Why: Requests and honorific endings. [[Korean#^ko-Q0948|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A1%B0%EC%9A%A9%ED%9E%88%20%ED%95%B4%20%EC%A3%BC%EC%84%B8%EC%9A%94.)
^ko-Q0948-answer

**ko-Q0949** — 할 가치가 있는 일이면, 제대로 하십시오.

If it is worth doing at all, it is worth doing well.

Expected form: **하십시오**

Why: Requests and honorific endings. [[Korean#^ko-Q0949|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%95%A0%20%EA%B0%80%EC%B9%98%EA%B0%80%20%EC%9E%88%EB%8A%94%20%EC%9D%BC%EC%9D%B4%EB%A9%B4%2C%20%EC%A0%9C%EB%8C%80%EB%A1%9C%20%ED%95%98%EC%8B%AD%EC%8B%9C%EC%98%A4.)
^ko-Q0949-answer

**ko-Q0950** — 할 가치가 있는 일이면, 제대로 하십시오.

If it is worth doing at all, it is worth doing well.

Expected form: **하십시오**

Why: Requests and honorific endings. [[Korean#^ko-Q0950|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%95%A0%20%EA%B0%80%EC%B9%98%EA%B0%80%20%EC%9E%88%EB%8A%94%20%EC%9D%BC%EC%9D%B4%EB%A9%B4%2C%20%EC%A0%9C%EB%8C%80%EB%A1%9C%20%ED%95%98%EC%8B%AD%EC%8B%9C%EC%98%A4.)
^ko-Q0950-answer


### Answers 951–1000

**ko-Q0951** — 지금 뭐하는 건데요?

What are you doing right now?

Expected form: **뭐**

Why: Questions and stance. [[Korean#^ko-Q0951|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A7%80%EA%B8%88%20%EB%AD%90%ED%95%98%EB%8A%94%20%EA%B1%B4%EB%8D%B0%EC%9A%94%3F)
^ko-Q0951-answer

**ko-Q0952** — 지금 뭐하는 건데요?

What are you doing right now?

Why: Questions and stance. [[Korean#^ko-Q0952|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A7%80%EA%B8%88%20%EB%AD%90%ED%95%98%EB%8A%94%20%EA%B1%B4%EB%8D%B0%EC%9A%94%3F)
^ko-Q0952-answer

**ko-Q0953** — 어디서 전화를 걸 수 있죠?

Where can I make a phone call?

Why: Questions and stance. [[Korean#^ko-Q0953|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%96%B4%EB%94%94%EC%84%9C%20%EC%A0%84%ED%99%94%EB%A5%BC%20%EA%B1%B8%20%EC%88%98%20%EC%9E%88%EC%A3%A0%3F)
^ko-Q0953-answer

**ko-Q0954** — 어디서 전화를 걸 수 있죠?

Where can I make a phone call?

Question words ask for specific information. 아마 marks a probability/guess rather than a question. Sentence endings communicate stance and relationship; do not translate only the lexical words.

Why: Questions and stance. [[Korean#^ko-Q0954|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%96%B4%EB%94%94%EC%84%9C%20%EC%A0%84%ED%99%94%EB%A5%BC%20%EA%B1%B8%20%EC%88%98%20%EC%9E%88%EC%A3%A0%3F)
^ko-Q0954-answer

**ko-Q0955** — 그 은행은 어디 있어?

Where is the bank?

Expected form: **어디**

Why: Questions and stance. [[Korean#^ko-Q0955|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%20%EC%9D%80%ED%96%89%EC%9D%80%20%EC%96%B4%EB%94%94%20%EC%9E%88%EC%96%B4%3F)
^ko-Q0955-answer

**ko-Q0956** — 그 은행은 어디 있어?

Where is the bank?

Expected form: **어디**

Why: Questions and stance. [[Korean#^ko-Q0956|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%20%EC%9D%80%ED%96%89%EC%9D%80%20%EC%96%B4%EB%94%94%20%EC%9E%88%EC%96%B4%3F)
^ko-Q0956-answer

**ko-Q0957** — 너는 어떻게 그렇게 인기가 많니?

Why are you so popular?

Expected form: **어떻게**

Why: Questions and stance. [[Korean#^ko-Q0957|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%84%88%EB%8A%94%20%EC%96%B4%EB%96%BB%EA%B2%8C%20%EA%B7%B8%EB%A0%87%EA%B2%8C%20%EC%9D%B8%EA%B8%B0%EA%B0%80%20%EB%A7%8E%EB%8B%88%3F)
^ko-Q0957-answer

**ko-Q0958** — 너는 어떻게 그렇게 인기가 많니?

Why are you so popular?

Why: Questions and stance. [[Korean#^ko-Q0958|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%84%88%EB%8A%94%20%EC%96%B4%EB%96%BB%EA%B2%8C%20%EA%B7%B8%EB%A0%87%EA%B2%8C%20%EC%9D%B8%EA%B8%B0%EA%B0%80%20%EB%A7%8E%EB%8B%88%3F)
^ko-Q0958-answer

**ko-Q0959** — 톰은 아마 자폐 스펙트럼에 속해.

Tom is probably on the spectrum.

Why: Questions and stance. [[Korean#^ko-Q0959|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EC%95%84%EB%A7%88%20%EC%9E%90%ED%8F%90%20%EC%8A%A4%ED%8E%99%ED%8A%B8%EB%9F%BC%EC%97%90%20%EC%86%8D%ED%95%B4.)
^ko-Q0959-answer

**ko-Q0960** — 톰은 아마 자폐 스펙트럼에 속해.

Tom is probably on the spectrum.

Question words ask for specific information. 아마 marks a probability/guess rather than a question. Sentence endings communicate stance and relationship; do not translate only the lexical words.

Why: Questions and stance. [[Korean#^ko-Q0960|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EC%95%84%EB%A7%88%20%EC%9E%90%ED%8F%90%20%EC%8A%A4%ED%8E%99%ED%8A%B8%EB%9F%BC%EC%97%90%20%EC%86%8D%ED%95%B4.)
^ko-Q0960-answer

**ko-Q0961** — 왜 그 단어를 잊어버렸니?

Why have you forgotten the word?

Expected form: **왜**

Why: Questions and stance. [[Korean#^ko-Q0961|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%99%9C%20%EA%B7%B8%20%EB%8B%A8%EC%96%B4%EB%A5%BC%20%EC%9E%8A%EC%96%B4%EB%B2%84%EB%A0%B8%EB%8B%88%3F)
^ko-Q0961-answer

**ko-Q0962** — 왜 그 단어를 잊어버렸니?

Why have you forgotten the word?

Expected form: **왜**

Why: Questions and stance. [[Korean#^ko-Q0962|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%99%9C%20%EA%B7%B8%20%EB%8B%A8%EC%96%B4%EB%A5%BC%20%EC%9E%8A%EC%96%B4%EB%B2%84%EB%A0%B8%EB%8B%88%3F)
^ko-Q0962-answer

**ko-Q0963** — 보스턴에 언제 왔어?

When did you come to Boston?

Expected form: **언제**

Why: Questions and stance. [[Korean#^ko-Q0963|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%B3%B4%EC%8A%A4%ED%84%B4%EC%97%90%20%EC%96%B8%EC%A0%9C%20%EC%99%94%EC%96%B4%3F)
^ko-Q0963-answer

**ko-Q0964** — 보스턴에 언제 왔어?

When did you come to Boston?

Why: Questions and stance. [[Korean#^ko-Q0964|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%B3%B4%EC%8A%A4%ED%84%B4%EC%97%90%20%EC%96%B8%EC%A0%9C%20%EC%99%94%EC%96%B4%3F)
^ko-Q0964-answer

**ko-Q0965** — 제일 가까운 병원이 어디에요?

Where is the closest hospital?

Why: Questions and stance. [[Korean#^ko-Q0965|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A0%9C%EC%9D%BC%20%EA%B0%80%EA%B9%8C%EC%9A%B4%20%EB%B3%91%EC%9B%90%EC%9D%B4%20%EC%96%B4%EB%94%94%EC%97%90%EC%9A%94%3F)
^ko-Q0965-answer

**ko-Q0966** — 제일 가까운 병원이 어디에요?

Where is the closest hospital?

Question words ask for specific information. 아마 marks a probability/guess rather than a question. Sentence endings communicate stance and relationship; do not translate only the lexical words.

Why: Questions and stance. [[Korean#^ko-Q0966|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A0%9C%EC%9D%BC%20%EA%B0%80%EA%B9%8C%EC%9A%B4%20%EB%B3%91%EC%9B%90%EC%9D%B4%20%EC%96%B4%EB%94%94%EC%97%90%EC%9A%94%3F)
^ko-Q0966-answer

**ko-Q0967** — 씨발 누가 상관해?

Who the fuck cares?

Expected form: **누가**

Why: Questions and stance. [[Korean#^ko-Q0967|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%94%A8%EB%B0%9C%20%EB%88%84%EA%B0%80%20%EC%83%81%EA%B4%80%ED%95%B4%3F)
^ko-Q0967-answer

**ko-Q0968** — 씨발 누가 상관해?

Who the fuck cares?

Expected form: **누가**

Why: Questions and stance. [[Korean#^ko-Q0968|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%94%A8%EB%B0%9C%20%EB%88%84%EA%B0%80%20%EC%83%81%EA%B4%80%ED%95%B4%3F)
^ko-Q0968-answer

**ko-Q0969** — 검도와 거합도는 뭐가 다르죠?

What is the difference between Iaido and Kendo?

Expected form: **뭐**

Why: Questions and stance. [[Korean#^ko-Q0969|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B2%80%EB%8F%84%EC%99%80%20%EA%B1%B0%ED%95%A9%EB%8F%84%EB%8A%94%20%EB%AD%90%EA%B0%80%20%EB%8B%A4%EB%A5%B4%EC%A3%A0%3F)
^ko-Q0969-answer

**ko-Q0970** — 검도와 거합도는 뭐가 다르죠?

What is the difference between Iaido and Kendo?

Why: Questions and stance. [[Korean#^ko-Q0970|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B2%80%EB%8F%84%EC%99%80%20%EA%B1%B0%ED%95%A9%EB%8F%84%EB%8A%94%20%EB%AD%90%EA%B0%80%20%EB%8B%A4%EB%A5%B4%EC%A3%A0%3F)
^ko-Q0970-answer

**ko-Q0971** — 왜 거짓말을 해요?

Why do you lie?

Why: Questions and stance. [[Korean#^ko-Q0971|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%99%9C%20%EA%B1%B0%EC%A7%93%EB%A7%90%EC%9D%84%20%ED%95%B4%EC%9A%94%3F)
^ko-Q0971-answer

**ko-Q0972** — 왜 거짓말을 해요?

Why do you lie?

Question words ask for specific information. 아마 marks a probability/guess rather than a question. Sentence endings communicate stance and relationship; do not translate only the lexical words.

Why: Questions and stance. [[Korean#^ko-Q0972|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%99%9C%20%EA%B1%B0%EC%A7%93%EB%A7%90%EC%9D%84%20%ED%95%B4%EC%9A%94%3F)
^ko-Q0972-answer

**ko-Q0973** — 그들은 왜 그것을 할 수 없죠?

Why can't they do it?

Expected form: **왜**

Why: Questions and stance. [[Korean#^ko-Q0973|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EB%93%A4%EC%9D%80%20%EC%99%9C%20%EA%B7%B8%EA%B2%83%EC%9D%84%20%ED%95%A0%20%EC%88%98%20%EC%97%86%EC%A3%A0%3F)
^ko-Q0973-answer

**ko-Q0974** — 그들은 왜 그것을 할 수 없죠?

Why can't they do it?

Expected form: **왜**

Why: Questions and stance. [[Korean#^ko-Q0974|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EB%93%A4%EC%9D%80%20%EC%99%9C%20%EA%B7%B8%EA%B2%83%EC%9D%84%20%ED%95%A0%20%EC%88%98%20%EC%97%86%EC%A3%A0%3F)
^ko-Q0974-answer

**ko-Q0975** — 종교와 철학의 차이점은 무엇입니까?

What's the difference between religion and philosophy?

Expected form: **무엇**

Why: Questions and stance. [[Korean#^ko-Q0975|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A2%85%EA%B5%90%EC%99%80%20%EC%B2%A0%ED%95%99%EC%9D%98%20%EC%B0%A8%EC%9D%B4%EC%A0%90%EC%9D%80%20%EB%AC%B4%EC%97%87%EC%9E%85%EB%8B%88%EA%B9%8C%3F)
^ko-Q0975-answer

**ko-Q0976** — 종교와 철학의 차이점은 무엇입니까?

What's the difference between religion and philosophy?

Why: Questions and stance. [[Korean#^ko-Q0976|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A2%85%EA%B5%90%EC%99%80%20%EC%B2%A0%ED%95%99%EC%9D%98%20%EC%B0%A8%EC%9D%B4%EC%A0%90%EC%9D%80%20%EB%AC%B4%EC%97%87%EC%9E%85%EB%8B%88%EA%B9%8C%3F)
^ko-Q0976-answer

**ko-Q0977** — 이걸 어떻게 하는지 모른다고 말하는 거야?

Are you saying that you don't know how to do this?

Why: Questions and stance. [[Korean#^ko-Q0977|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9D%B4%EA%B1%B8%20%EC%96%B4%EB%96%BB%EA%B2%8C%20%ED%95%98%EB%8A%94%EC%A7%80%20%EB%AA%A8%EB%A5%B8%EB%8B%A4%EA%B3%A0%20%EB%A7%90%ED%95%98%EB%8A%94%20%EA%B1%B0%EC%95%BC%3F)
^ko-Q0977-answer

**ko-Q0978** — 이걸 어떻게 하는지 모른다고 말하는 거야?

Are you saying that you don't know how to do this?

Question words ask for specific information. 아마 marks a probability/guess rather than a question. Sentence endings communicate stance and relationship; do not translate only the lexical words.

Why: Questions and stance. [[Korean#^ko-Q0978|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%9D%B4%EA%B1%B8%20%EC%96%B4%EB%96%BB%EA%B2%8C%20%ED%95%98%EB%8A%94%EC%A7%80%20%EB%AA%A8%EB%A5%B8%EB%8B%A4%EA%B3%A0%20%EB%A7%90%ED%95%98%EB%8A%94%20%EA%B1%B0%EC%95%BC%3F)
^ko-Q0978-answer

**ko-Q0979** — 겨울 방학은 어떻게 지냈나요?

How did you spend your winter vacation?

Expected form: **어떻게**

Why: Questions and stance. [[Korean#^ko-Q0979|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B2%A8%EC%9A%B8%20%EB%B0%A9%ED%95%99%EC%9D%80%20%EC%96%B4%EB%96%BB%EA%B2%8C%20%EC%A7%80%EB%83%88%EB%82%98%EC%9A%94%3F)
^ko-Q0979-answer

**ko-Q0980** — 겨울 방학은 어떻게 지냈나요?

How did you spend your winter vacation?

Expected form: **어떻게**

Why: Questions and stance. [[Korean#^ko-Q0980|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B2%A8%EC%9A%B8%20%EB%B0%A9%ED%95%99%EC%9D%80%20%EC%96%B4%EB%96%BB%EA%B2%8C%20%EC%A7%80%EB%83%88%EB%82%98%EC%9A%94%3F)
^ko-Q0980-answer

**ko-Q0981** — 슬론 스퀘어로 가는 다음 기차가 언제 있습니까?

When is the next train to Sloane Square?

Expected form: **언제**

Why: Questions and stance. [[Korean#^ko-Q0981|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%8A%AC%EB%A1%A0%20%EC%8A%A4%ED%80%98%EC%96%B4%EB%A1%9C%20%EA%B0%80%EB%8A%94%20%EB%8B%A4%EC%9D%8C%20%EA%B8%B0%EC%B0%A8%EA%B0%80%20%EC%96%B8%EC%A0%9C%20%EC%9E%88%EC%8A%B5%EB%8B%88%EA%B9%8C%3F)
^ko-Q0981-answer

**ko-Q0982** — 슬론 스퀘어로 가는 다음 기차가 언제 있습니까?

When is the next train to Sloane Square?

Why: Questions and stance. [[Korean#^ko-Q0982|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%8A%AC%EB%A1%A0%20%EC%8A%A4%ED%80%98%EC%96%B4%EB%A1%9C%20%EA%B0%80%EB%8A%94%20%EB%8B%A4%EC%9D%8C%20%EA%B8%B0%EC%B0%A8%EA%B0%80%20%EC%96%B8%EC%A0%9C%20%EC%9E%88%EC%8A%B5%EB%8B%88%EA%B9%8C%3F)
^ko-Q0982-answer

**ko-Q0983** — 아마 내일은 날씨가 나아질 거예요.

Perhaps the weather will get better tomorrow.

Why: Questions and stance. [[Korean#^ko-Q0983|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%95%84%EB%A7%88%20%EB%82%B4%EC%9D%BC%EC%9D%80%20%EB%82%A0%EC%94%A8%EA%B0%80%20%EB%82%98%EC%95%84%EC%A7%88%20%EA%B1%B0%EC%98%88%EC%9A%94.)
^ko-Q0983-answer

**ko-Q0984** — 아마 내일은 날씨가 나아질 거예요.

Perhaps the weather will get better tomorrow.

Question words ask for specific information. 아마 marks a probability/guess rather than a question. Sentence endings communicate stance and relationship; do not translate only the lexical words.

Why: Questions and stance. [[Korean#^ko-Q0984|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%95%84%EB%A7%88%20%EB%82%B4%EC%9D%BC%EC%9D%80%20%EB%82%A0%EC%94%A8%EA%B0%80%20%EB%82%98%EC%95%84%EC%A7%88%20%EA%B1%B0%EC%98%88%EC%9A%94.)
^ko-Q0984-answer

**ko-Q0985** — 사랑받고 있는 사람 중에 가난한 사람이 누가 있나?

Who, being loved, is poor?

Expected form: **누가**

Why: Questions and stance. [[Korean#^ko-Q0985|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%82%AC%EB%9E%91%EB%B0%9B%EA%B3%A0%20%EC%9E%88%EB%8A%94%20%EC%82%AC%EB%9E%8C%20%EC%A4%91%EC%97%90%20%EA%B0%80%EB%82%9C%ED%95%9C%20%EC%82%AC%EB%9E%8C%EC%9D%B4%20%EB%88%84%EA%B0%80%20%EC%9E%88%EB%82%98%3F)
^ko-Q0985-answer

**ko-Q0986** — 사랑받고 있는 사람 중에 가난한 사람이 누가 있나?

Who, being loved, is poor?

Expected form: **누가**

Why: Questions and stance. [[Korean#^ko-Q0986|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%82%AC%EB%9E%91%EB%B0%9B%EA%B3%A0%20%EC%9E%88%EB%8A%94%20%EC%82%AC%EB%9E%8C%20%EC%A4%91%EC%97%90%20%EA%B0%80%EB%82%9C%ED%95%9C%20%EC%82%AC%EB%9E%8C%EC%9D%B4%20%EB%88%84%EA%B0%80%20%EC%9E%88%EB%82%98%3F)
^ko-Q0986-answer

**ko-Q0987** — 왜 여자가 싫은 거야?

Why do you hate women?

Expected form: **왜**

Why: Questions and stance. [[Korean#^ko-Q0987|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%99%9C%20%EC%97%AC%EC%9E%90%EA%B0%80%20%EC%8B%AB%EC%9D%80%20%EA%B1%B0%EC%95%BC%3F)
^ko-Q0987-answer

**ko-Q0988** — 왜 여자가 싫은 거야?

Why do you hate women?

Why: Questions and stance. [[Korean#^ko-Q0988|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%99%9C%20%EC%97%AC%EC%9E%90%EA%B0%80%20%EC%8B%AB%EC%9D%80%20%EA%B1%B0%EC%95%BC%3F)
^ko-Q0988-answer

**ko-Q0989** — 톰은 뭐가 잘못됐는지 알아챘어.

Tom found out what went wrong.

Why: Questions and stance. [[Korean#^ko-Q0989|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EB%AD%90%EA%B0%80%20%EC%9E%98%EB%AA%BB%EB%90%90%EB%8A%94%EC%A7%80%20%EC%95%8C%EC%95%84%EC%B1%98%EC%96%B4.)
^ko-Q0989-answer

**ko-Q0990** — 톰은 뭐가 잘못됐는지 알아챘어.

Tom found out what went wrong.

Question words ask for specific information. 아마 marks a probability/guess rather than a question. Sentence endings communicate stance and relationship; do not translate only the lexical words.

Why: Questions and stance. [[Korean#^ko-Q0990|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%ED%86%B0%EC%9D%80%20%EB%AD%90%EA%B0%80%20%EC%9E%98%EB%AA%BB%EB%90%90%EB%8A%94%EC%A7%80%20%EC%95%8C%EC%95%84%EC%B1%98%EC%96%B4.)
^ko-Q0990-answer

**ko-Q0991** — 그 고양이는 무엇을 원해요?

What does the cat want?

Expected form: **무엇**

Why: Questions and stance. [[Korean#^ko-Q0991|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%20%EA%B3%A0%EC%96%91%EC%9D%B4%EB%8A%94%20%EB%AC%B4%EC%97%87%EC%9D%84%20%EC%9B%90%ED%95%B4%EC%9A%94%3F)
^ko-Q0991-answer

**ko-Q0992** — 그 고양이는 무엇을 원해요?

What does the cat want?

Expected form: **무엇**

Why: Questions and stance. [[Korean#^ko-Q0992|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%20%EA%B3%A0%EC%96%91%EC%9D%B4%EB%8A%94%20%EB%AC%B4%EC%97%87%EC%9D%84%20%EC%9B%90%ED%95%B4%EC%9A%94%3F)
^ko-Q0992-answer

**ko-Q0993** — 누가 그들을 죽였나?

Who killed them?

Expected form: **누가**

Why: Questions and stance. [[Korean#^ko-Q0993|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%88%84%EA%B0%80%20%EA%B7%B8%EB%93%A4%EC%9D%84%20%EC%A3%BD%EC%98%80%EB%82%98%3F)
^ko-Q0993-answer

**ko-Q0994** — 누가 그들을 죽였나?

Who killed them?

Why: Questions and stance. [[Korean#^ko-Q0994|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EB%88%84%EA%B0%80%20%EA%B7%B8%EB%93%A4%EC%9D%84%20%EC%A3%BD%EC%98%80%EB%82%98%3F)
^ko-Q0994-answer

**ko-Q0995** — 진짜 목표는 뭐야?

What's the real goal?

Why: Questions and stance. [[Korean#^ko-Q0995|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A7%84%EC%A7%9C%20%EB%AA%A9%ED%91%9C%EB%8A%94%20%EB%AD%90%EC%95%BC%3F)
^ko-Q0995-answer

**ko-Q0996** — 진짜 목표는 뭐야?

What's the real goal?

Question words ask for specific information. 아마 marks a probability/guess rather than a question. Sentence endings communicate stance and relationship; do not translate only the lexical words.

Why: Questions and stance. [[Korean#^ko-Q0996|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A7%84%EC%A7%9C%20%EB%AA%A9%ED%91%9C%EB%8A%94%20%EB%AD%90%EC%95%BC%3F)
^ko-Q0996-answer

**ko-Q0997** — 지혜로운 리더는 언제 들어야 할지를 안다.

A wise leader knows when to listen.

Expected form: **언제**

Why: Questions and stance. [[Korean#^ko-Q0997|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A7%80%ED%98%9C%EB%A1%9C%EC%9A%B4%20%EB%A6%AC%EB%8D%94%EB%8A%94%20%EC%96%B8%EC%A0%9C%20%EB%93%A4%EC%96%B4%EC%95%BC%20%ED%95%A0%EC%A7%80%EB%A5%BC%20%EC%95%88%EB%8B%A4.)
^ko-Q0997-answer

**ko-Q0998** — 지혜로운 리더는 언제 들어야 할지를 안다.

A wise leader knows when to listen.

Expected form: **언제**

Why: Questions and stance. [[Korean#^ko-Q0998|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EC%A7%80%ED%98%9C%EB%A1%9C%EC%9A%B4%20%EB%A6%AC%EB%8D%94%EB%8A%94%20%EC%96%B8%EC%A0%9C%20%EB%93%A4%EC%96%B4%EC%95%BC%20%ED%95%A0%EC%A7%80%EB%A5%BC%20%EC%95%88%EB%8B%A4.)
^ko-Q0998-answer

**ko-Q0999** — 그걸 어디에 숨겼어?

Where did you hide them?

Expected form: **어디**

Why: Questions and stance. [[Korean#^ko-Q0999|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EA%B1%B8%20%EC%96%B4%EB%94%94%EC%97%90%20%EC%88%A8%EA%B2%BC%EC%96%B4%3F)
^ko-Q0999-answer

**ko-Q1000** — 그걸 어디에 숨겼어?

Where did you hide them?

Why: Questions and stance. [[Korean#^ko-Q1000|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=kor&query=%EA%B7%B8%EA%B1%B8%20%EC%96%B4%EB%94%94%EC%97%90%20%EC%88%A8%EA%B2%BC%EC%96%B4%3F)
^ko-Q1000-answer


## Read and speak

Read the native sentence first, identify its predicate and one grammar form, then check the translation. Say it aloud and change one detail.

### Learning with a clear purpose

새로운 언어를 공부하고 있어요. 매일 짧은 글을 읽고 명확한 예문을 들어요. 유용한 단어를 공책에 써요. 실수를 하면 규칙을 확인하고 다시 시도해요. 제 목표는 사람들의 말을 이해하고 제 생각을 명확하게 표현하는 것이에요.

I am learning a new language. Each day, I read a short text and listen to clear examples. I write useful words in a notebook. When I make a mistake, I check the rule and try again. My goal is to understand people and express my ideas clearly.

![[Resources/Audio/ko/Reading passage.mp3]]

**자기가 잘못했다고 생각한다.**

I feel guilty.

**나는 갈 거에요.**

I'm going to go.

**영국 영화가 미국 영화보다 낫다.**

British films are better than American films.

**톰은 벽장에서 헌 구두상자를 꺼내 열었다.**

Tom pulled out an old shoebox from his closet and opened it.

**의심할 여시가 없읍니다**

It's out of the question.

**너는 분명히 재능이 있는데 더 많이 못 배워서 아쉽구나.**

You have talent, no doubt; it's just a pity that you haven't learned more.

**톰은 열정적인 애지?**

Tom is passionate, isn't he?

**그녀의 머리카락은 길어.**

Her hair is long.

**외국에서 살면서 좀 불편한 건 없었어?**

Don't you feel any inconvenience living abroad?

**톰은 아직 숙제를 안 했다.**

Tom hasn't finished his homework yet.

**탐은 그 것에 푹 빠져 있었다.**

Tom was totally into it.

**너 새차 색깔이 뭐야?**

What color is your new car?

**톰은 진짜 바빠.**

Tom is real busy.

**메리는 커피 중독자야.**

Mary is addicted to coffee.

**네가 고등학교 선생님이라는 게 사실이니?**

Is it true that you're a high school teacher?

## Professional writing

Write an introduction, a polite request, an explanation of a finding, a summary of a passage and a tactful disagreement. Use the professional/advanced lessons for models.

## PDF edition

[[Resources/PDFs/Korean.pdf|Open the complete printable book]]
