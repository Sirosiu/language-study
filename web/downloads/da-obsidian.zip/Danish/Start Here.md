# Danish study

[[Danish|Open the complete Danish course note]]

Audio and the printable PDF are in Resources. This vault contains one language.

[[Sources and licenses]]
