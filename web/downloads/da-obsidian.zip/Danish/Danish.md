# Danish

Professional ambition - C1-oriented study

Everything for this language is in this note. Open a rule, read its examples and follow its practice link. Answers stay in this same note.

[[Start Here|All languages]] · [[Sources and licenses|Sources]]

## Start reading

### alfabetet

| Written form | Name / reading | Related forms |
|---|---|---|
| A a | a  |  ·  ·  |
| B b | be  |  ·  ·  |
| C c | ce  |  ·  ·  |
| D d | de  |  ·  ·  |
| E e | e  |  ·  ·  |
| F f | ef  |  ·  ·  |
| G g | ge  |  ·  ·  |
| H h | hå  |  ·  ·  |
| I i | i  |  ·  ·  |
| J j | jåd  |  ·  ·  |
| K k | kå  |  ·  ·  |
| L l | el  |  ·  ·  |
| M m | em  |  ·  ·  |
| N n | en  |  ·  ·  |
| O o | o  |  ·  ·  |
| P p | pe  |  ·  ·  |
| Q q | ku  |  ·  ·  |
| R r | er  |  ·  ·  |
| S s | es  |  ·  ·  |
| T t | te  |  ·  ·  |
| U u | u  |  ·  ·  |
| V v | ve  |  ·  ·  |
| W w | dobbelt-ve  |  ·  ·  |
| X x | eks  |  ·  ·  |
| Y y | y  |  ·  ·  |
| Z z | sæt  |  ·  ·  |
| Æ æ | æ  |  ·  ·  |
| Ø ø | ø  |  ·  ·  |
| Å å | å  |  ·  ·  |

![[Resources/Audio/da/Script and first phrases.mp3]]

The player above is synthetic speech. Word tracks below work offline.

### All 29 letters

Æ, Ø and Å come after Z in that order. They are distinct letters. aa sometimes remains in names and older spellings for å. Letter names are for spelling; spelling alone does not reliably predict the spoken vowel.

### Hear reduced speech

Danish has a large vowel inventory, reductions and the soft d, which is not an ordinary English d. Stød is a laryngeal feature in many words, not simply stress. Learn it from a clear recording and imitation rather than an English respelling.

### Read endings, even when quiet

An ending may be weakly pronounced while still carrying a grammatical distinction. Learn en/et with each noun and listen to singular/plural and indefinite/definite pairs.

### Build definiteness

en bog → bogen = a book → the book; et hus → huset = a house → the house. With an adjective: den gode bog = the good book.

### Build agreement

en stor bil, et stort hus, store huse = a large car, a large house, large houses. Many adjectives show common-gender, neuter and plural forms, but exceptions must be learned.

### Build a compound

arbejde + plads → arbejdsplads = workplace. Linking -s- is lexical; do not insert it in every compound.

**Godmorgen.**

Good morning.

**Jeg lærer dansk.**

I am learning Danish.

**Kan du gentage det?**

Can you repeat that?

**Hvad betyder det her ord?**

What does this word mean?

### Grammar terms in plain English

**Noun** — A word naming a person, thing or idea: student, book, freedom.

**Verb** — A word describing an action or state: read, know, be.

**Subject** — The participant linked to the main verb’s subject pattern. In The student reads a book, the student is the subject.

**Object** — A participant selected by a verb. In The student reads a book, a book is the direct object.

**Agreement** — One word changes to match another, for example an adjective matching a noun’s gender and number.

**Case** — A noun/pronoun form marking its relationship in a sentence. Cases can mark subjects, objects, possession or relations usually expressed by English prepositions.

**Gender** — A grammatical noun class. It does not always describe the sex of a person or any physical property.

**Tense** — A verb system that relates a situation to a time, often past or non-past.

**Aspect** — How a situation is viewed: unfolding, completed, habitual, experienced or in a resulting state.

**Infinitive** — A non-finite verb form often used for a dictionary entry or a complement. It does not by itself give the ordinary person/tense pattern.

**Participle** — A verb-derived form used in compound predicates or as a modifier; its exact function depends on the language and construction.

**Clause** — A unit organised around a predicate. One sentence can contain several clauses.

**Register** — Language choices suited to a situation: casual conversation, polite requests, academic writing or another context.

## Grammar, examples and practice

### Nouns and adjective agreement

Danish has common-gender en and neuter et nouns, with suffixed definite forms: en bog/bogen, et hus/huset. Plural patterns are lexical. Adjectives commonly use -t in neuter singular and -e in plural or definite phrases. Standard definite adjective phrases use a separate determiner with a normally non-suffixed noun: det store hus, unlike the typical Swedish double-definite construction.

**et nyt forslag / det nye forslag**

a new proposal / the new proposal Neuter and definite adjective patterns.

**vigtige resultater**

important results Plural adjective form.

#### En and et nouns

Danish has common and neuter grammatical gender. En/et is part of a noun’s lexical information. Definite singular often adds -en/-et directly to the noun.

**"Oh, var jeg dog sådant et stort træ, som de andre!" sukkede det lille grantræ.**

"Oh, if I were only as great a tree as the others!" sighed the little Fir.

**Marathi er navnet på et vigtigt indoarisk sprog, der tales i det vestlige og centrale Indien.**

Marathi is the name of an important Indo-Aryan language spoken in western and central India.

![[Resources/Audio/da/Rule 01.mp3]]

[[Danish#^da-Q0001|Practise this rule (50 questions)]]

#### Definite and demonstrative forms

Den/det/de precede many definite adjective phrases and can serve as pronouns. Their form depends on gender/number. Context distinguishes article and demonstrative functions.

**Bærer din kone det muslimske tørklæde?**

Does your wife wear the Muslim headscarf?

**Gør bare det færdigt som du er i gang med.**

Just finish what you're doing.

![[Resources/Audio/da/Rule 02.mp3]]

[[Danish#^da-Q0051|Practise this rule (50 questions)]]

#### Personal pronouns

Subject and object pronoun forms differ. Danish finite verbs generally do not change for person. Capital I means plural you and differs from lowercase i, in.

**Vi kender ham ikke.**

We don't know him.

**Tom havde al ret til at gøre, hvad han gjorde.**

Tom had every right to do what he did.

![[Resources/Audio/da/Rule 03.mp3]]

[[Danish#^da-Q0101|Practise this rule (50 questions)]]

#### Adjective agreement

Adjectives often distinguish common singular, neuter singular and plural/definite forms. Lille has irregular plural små. Predicative adjectives also show relevant agreement.

**Jeg trænger til en ny cykel.**

I need a new bicycle.

**Han kan virkelig godt lide at rejse.**

He really likes traveling a lot.

![[Resources/Audio/da/Rule 12.mp3]]

[[Danish#^da-Q0551|Practise this rule (50 questions)]]

<details><summary>Choose det store hus or det store huset in the core standard Danish pattern.</summary>

Det store hus. The separate definite determiner accompanies the adjective and unsuffixed noun.

</details>

<details><summary>What must a noun card preserve?</summary>

En/et, definite and plural forms, pronunciation and usage.

</details>

### Verb-second and subordinate negation

Main declaratives use verb-second: I dag læser jeg rapporten. In subordinate clauses, ikke commonly precedes the finite verb: fordi jeg ikke ved. Main-clause ikke commonly follows the finite verb. Clause boundaries determine the pattern; a long initial constituent does not license English word order afterward.

**I morgen begynder vi.**

Tomorrow we begin. Fronted time with verb-second.

**Jeg ved, at hun ikke kommer.**

I know that she is not coming. Embedded negation precedes the verb.

#### Copula and past

Er is a present form for all persons; var is past; været is the participle. Subject changes do not create English-style am/is/are variation.

**Mørke er fravær af lys.**

Darkness is the absence of light.

**At fejle er menneskeligt, at tilgive er guddommeligt.**

To err is human; to forgive, divine.

![[Resources/Audio/da/Rule 04.mp3]]

[[Danish#^da-Q0151|Practise this rule (50 questions)]]

#### Main-clause negation

In many ordinary main statements the finite verb precedes ikke. In a subordinate clause, sentence adverbs often precede the finite verb. The connector and clause status determine the pattern.

**Tom kan endnu ikke køre bil.**

Tom can't drive a car yet.

**Tom drak ikke noget.**

Tom didn't drink anything.

![[Resources/Audio/da/Rule 06.mp3]]

[[Danish#^da-Q0251|Practise this rule (50 questions)]]

#### Subordinate connectors

These connectors commonly introduce subordinate structures. Compare Jeg kommer ikke with fordi jeg ikke kommer. Main-clause verb-second order counts constituents, not words.

**Hun nægtede at skrive under på andragendet.**

She refused to sign the petition.

**Sami forsøgte at sælge sin bil.**

Sami tried to sell his car.

![[Resources/Audio/da/Rule 07.mp3]]

[[Danish#^da-Q0301|Practise this rule (50 questions)]]

#### Coordination

Coordinating connectors link phrases or clauses. For can function as a causal conjunction or as a preposition; analyse the following structure.

**Tak for indsatsen.**

Thanks for the effort.

**Han så til højre og gik.**

He looked right and left.

![[Resources/Audio/da/Rule 08.mp3]]

[[Danish#^da-Q0351|Practise this rule (50 questions)]]

<details><summary>Reorder i morgen / vi / mødes.</summary>

I morgen mødes vi.

</details>

<details><summary>Place ikke after fordi in fordi han ved det.</summary>

Fordi han ikke ved det.

</details>

### Tense, passive and modal meanings

Verbs normally do not vary by person. Perfect uses an auxiliary and participle; learn har/er choices in actual verbs. The -s passive and blive + participle are common passive strategies with lexical and register differences. Må can express permission in many contexts and should not be mechanically equated with Norwegian må. Skal, bør and behøver express different obligation or necessity meanings.

**Rapporten bliver gennemgået.**

The report is being reviewed. Blive passive.

**Du behøver ikke at vente.**

You do not need to wait. Absence of necessity.

#### Have forms

Har expresses present possession or serves as an auxiliary; havde is past and haft a participle. Learn a perfect together with its auxiliary and intended meaning.

**Hun har blondt hår.**

She has blonde hair.

**Alle havde meget travlt.**

Everybody was very busy.

![[Resources/Audio/da/Rule 05.mp3]]

[[Danish#^da-Q0201|Practise this rule (50 questions)]]

#### Modals

Modals express ability, duty, permission, prediction or intention. They normally combine with a bare infinitive. Their past forms can also create polite or hypothetical distance.

**Tom vil lære serbisk.**

Tom wants to learn Serbian.

**Tom ville sælge sin bil.**

Tom wanted to sell his car.

![[Resources/Audio/da/Rule 09.mp3]]

[[Danish#^da-Q0401|Practise this rule (50 questions)]]

#### Perfect participles

A perfect combines har or er with a participle. Auxiliary choice can depend on the verb and meaning. A participle may also appear in a passive or as an adjective.

**Jeg har set dig gøre det.**

I've seen you doing that.

**Hun er ikke kommet.**

She did not come.

![[Resources/Audio/da/Rule 10.mp3]]

[[Danish#^da-Q0451|Practise this rule (50 questions)]]

#### Past lexical verbs

Common strong verbs have irregular past forms. Practice the subject and time frame with the form; Danish verbs do not normally conjugate for person.

**Undskyld, noget gik galt.**

Sorry, something went wrong.

**Alt gik op i røg.**

Everything went up in smoke.

![[Resources/Audio/da/Rule 11.mp3]]

[[Danish#^da-Q0501|Practise this rule (50 questions)]]

#### Infinitives

At can mark an infinitive or introduce a finite complement clause. Distinguish at læse from at hun læser. Modals normally take an infinitive without at.

**Tom tog fra Boston til Chicago.**

Tom went from Boston to Chicago.

**Toget ankom til Kyoto til tiden.**

The train arrived in Kyoto on time.

![[Resources/Audio/da/Rule 17.mp3]]

[[Danish#^da-Q0801|Practise this rule (50 questions)]]

#### Comparison

Comparatives commonly use end; equality uses forms such as lige så ... som. Bedre and større are irregular/common comparative forms.

**Det er koldere i år end sidste år.**

It is colder this year than last year.

**I burde være mere forsigtige.**

You guys should be more careful.

![[Resources/Audio/da/Rule 18.mp3]]

[[Danish#^da-Q0851|Practise this rule (50 questions)]]

<details><summary>Why is transferring a cognate modal from Norwegian risky?</summary>

Similar forms can have different conventional meanings; Danish må often concerns permission.

</details>

<details><summary>Ask May I ask a question?</summary>

Må jeg stille et spørgsmål? Permission question.

</details>

### Relatives, possession and discourse

Som and der occur in relative structures with distributional differences, including subject-relative contexts. Sin/sit/sine refer reflexively to an appropriate singular subject in core patterns; hans/hendes are nonreflexive. The possessed noun selects the form. Derfor expresses consequence, derimod contrast and alligevel concession.

**Hun læser sin rapport.**

She reads her own report. Reflexive possession.

**Det er metoden, som vi bruger.**

It is the method we use. Relative clause.

#### Reflexive possession

Sin/sit/sine refers back to a third-person subject in suitable contexts. Hans/hendes can refer to somebody else. Reflexive possession does not simply mean any English his/her.

**Tom fodrer sin hund to gange om dagen.**

Tom feeds his dog twice a day.

**De tændte stearinlys på deres værelse.**

They lit candles in their room.

![[Resources/Audio/da/Rule 13.mp3]]

[[Danish#^da-Q0601|Practise this rule (50 questions)]]

#### Relative clauses

Som is a common relative marker; der can be a relative subject. Der also occurs in existence statements. Identify the role inside the relative clause.

**Alle æblerne, der falder ned, bliver spist af grisene.**

All the apples that fall are eaten by the pigs.

**Alle æblerne er der.**

All the apples are there.

![[Resources/Audio/da/Rule 14.mp3]]

[[Danish#^da-Q0651|Practise this rule (50 questions)]]

#### Existence and place

Der can mean there or support an existential construction. Her means here. A grammatical existence marker and a stressed location are not always interchangeable.

**Tom boede her hos os i tre måneder.**

Tom lived here with us for three months.

**Jeg græder altid, når jeg ser det her billede.**

I always cry when I see this picture.

![[Resources/Audio/da/Rule 15.mp3]]

[[Danish#^da-Q0701|Practise this rule (50 questions)]]

#### Questions

Direct questions often place the finite verb before the subject. An indirect question takes subordinate order. A question word specifies the information requested.

**Oh, hvor træet bævede!**

Oh, how the Tree trembled!

**Kan du fortælle mig, hvordan man justerer lydstyrken?**

Could you tell me how to adjust the volume?

![[Resources/Audio/da/Rule 16.mp3]]

[[Danish#^da-Q0751|Practise this rule (50 questions)]]

#### Prepositions

Prepositions encode relations and belong to learned phrases. A location choice between i and på cannot always be predicted from English in/on.

**Jeg bor i Boston nu.**

I live in Boston now.

**Tom arbejder på deltid.**

Tom works part-time.

![[Resources/Audio/da/Rule 19.mp3]]

[[Danish#^da-Q0901|Practise this rule (50 questions)]]

<details><summary>Choose sin/sit with forslag.</summary>

Sit forslag, since forslag is neuter.

</details>

<details><summary>Write a concession with alligevel.</summary>

Resultaterne er interessante. Alligevel har vi brug for flere oplysninger.

</details>

### Professional reading

Teaching passage: Resultaterne viser en sammenhæng mellem to faktorer. De beviser dog ikke, at den ene faktor forårsager den anden. Undersøgelsens betingelser skal indgå i vurderingen.
Translation: The results show an association between two factors. However, they do not prove that one causes the other. The study conditions must be included in the assessment.

**Kan du uddybe dette punkt?**

Could you elaborate on this point? A practical professional request.

**Konklusionen er foreløbig.**

The conclusion is provisional. Explicit evidential status.

#### Concession and inference

Selvom introduces concession; alligevel means nevertheless; derfor supplies a consequence; måske limits certainty. Connectors carry argument meaning as well as clause structure.

**Tom er måske lun på dig.**

Tom may have a crush on you.

**Politiet tror at Tom måske har forgiftet Mary.**

The police think that Tom might've poisoned Mary.

![[Resources/Audio/da/Rule 20.mp3]]

[[Danish#^da-Q0951|Practise this rule (50 questions)]]

<details><summary>Summarise the reasoning.</summary>

Association is shown, causal proof is denied and study conditions must be assessed.

</details>

<details><summary>Record a short summary after reading.</summary>

Use a real Danish model for vowels, reduction and stød; the book supplies the content, not the acoustic model.

</details>

## Word bank and recordings

1,000 study entries, based on dictionary selections and authored teaching glosses. Learn a word in a phrase; consult the linked entry for additional senses.

<details><summary>Words 1–50</summary>

![[Resources/Audio/da/Words 0001-0050.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [I](https://en.wiktionary.org/wiki/I#Danish) | you, you all (second person plural) | [i] · pron |
| [og](https://en.wiktionary.org/wiki/og#Danish) | and | [ʌ] · conj |
| [af](https://en.wiktionary.org/wiki/af#Danish) | by | [a] · prep |
| [det](https://en.wiktionary.org/wiki/det#Danish) | it; that; the (neuter determiner) | /de/ · pron |
| [at](https://en.wiktionary.org/wiki/at#Danish) | that (introduces a noun clause functioning as the subject, object or predicative of a verb, or as the object of a prepositional phrase) | /ad/ · conj |
| [en](https://en.wiktionary.org/wiki/en#Danish) | a/an (common gender); one | /en/ · det |
| [til](https://en.wiktionary.org/wiki/til#Danish) | to, towards (the direction or goal of a physical movement) | /te(l)/ · prep |
| [på](https://en.wiktionary.org/wiki/p%C3%A5#Danish) | on | [pʰɔ̽] · prep |
| [jeg](https://en.wiktionary.org/wiki/jeg#Danish) | I | [jɑ̈(j)] · pron |
| [for](https://en.wiktionary.org/wiki/for#Danish) | lining (covering for the inside of something) | /foːr/ · noun |
| [med](https://en.wiktionary.org/wiki/med#Danish) | with | /mɛð/ · prep |
| [den](https://en.wiktionary.org/wiki/den#Danish) | it; that; the (common-gender determiner) | /dɛnˀ/ · pron |
| [der](https://en.wiktionary.org/wiki/der#Danish) | there (in or at that place) | /ˈdɛːˀr/ · adv |
| [de](https://en.wiktionary.org/wiki/de#Danish) | they (third-person plural) | /di/ · pron |
| [du](https://en.wiktionary.org/wiki/du#Danish) | thou, you (2nd person singular subject pronoun, informal) | [ˈd̥u] · pron |
| [som](https://en.wiktionary.org/wiki/som#Danish) | as, like (introduces comparisons, both noun phrases and dependent clauses) | /sɔm/ · conj |
| [så](https://en.wiktionary.org/wiki/s%C3%A5#Danish) | so (with adjectives, to the extent (that), often with a following dependent result clause introduced with the conjunction at) | /ˈsɔ/ · adv |
| [var](https://en.wiktionary.org/wiki/var#Danish) | only used in blive var (“become aware”) | [ˈʋɑˀ] · adj |
| [vi](https://en.wiktionary.org/wiki/vi#Danish) | we | /vi/ · pron |
| [om](https://en.wiktionary.org/wiki/om#Danish) | about | [ˈʌmˀ · prep |
| [han](https://en.wiktionary.org/wiki/han#Danish) | he | /han/ · pron |
| [fra](https://en.wiktionary.org/wiki/fra#Danish) | from | /fra/ · prep |
| [men](https://en.wiktionary.org/wiki/men#Danish) | injury | /meːn/ · noun |
| [være](https://en.wiktionary.org/wiki/v%C3%A6re#Danish) | to be (expresses identity between the subject and a predicative) | /ˈvɛːʁə/ · verb |
| [nu](https://en.wiktionary.org/wiki/nu#Danish) | now (present time), present (current time) | /nu/ · noun |
| [man](https://en.wiktionary.org/wiki/man#Danish) | you, one, they, people (a general, unspecified person) | /man/ · pron |
| [sig](https://en.wiktionary.org/wiki/sig#Danish) | third-person pronoun | /saj/ · pron |
| [efter](https://en.wiktionary.org/wiki/efter#Danish) | after; subsequent; later in time than | /ˈɛfdɐ/ · prep |
| [mig](https://en.wiktionary.org/wiki/mig#Danish) | first person singular accusative personal pronoun; me | /mɑj/ · pron |
| [jeg ved det ikke](https://en.wiktionary.org/wiki/jeg%20ved%20det%20ikke#Danish) | I don't know |  · phrase |
| [eller](https://en.wiktionary.org/wiki/eller#Danish) | or | /ˈɛlər/ · conj |
| [her](https://en.wiktionary.org/wiki/her#Danish) | here | /hɛr/ · adv |
| [ud](https://en.wiktionary.org/wiki/ud#Danish) | out | /uðˀ/ · adv |
| [da](https://en.wiktionary.org/wiki/da#Danish) | then, at that time | /da/ · adv |
| [dig](https://en.wiktionary.org/wiki/dig#Danish) | you (2nd person singular object pronoun) | /dɑj/ · pron |
| [min](https://en.wiktionary.org/wiki/min#Danish) | mine 1.st person singular possessive pronoun | /miːn/ · pron |
| [op](https://en.wiktionary.org/wiki/op#Danish) | up (away from earth’s centre) | [ˈʌb] · adv |
| [mere](https://en.wiktionary.org/wiki/mere#Danish) | more; to a higher degree | /meːrə/ · adj |
| [over](https://en.wiktionary.org/wiki/over#Danish) | above |  · prep |
| [hun](https://en.wiktionary.org/wiki/hun#Danish) | she | [hun] · pron |
| [se](https://en.wiktionary.org/wiki/se#Danish) | to see | [ˈseˀ] · verb |
| [år](https://en.wiktionary.org/wiki/%C3%A5r#Danish) | year | /ɔːˀr/ · noun |
| [bare](https://en.wiktionary.org/wiki/bare#Danish) | just | /ˈbaːrə/ · adv |
| [få](https://en.wiktionary.org/wiki/f%C3%A5#Danish) | few | [ˈfɔˀ] · adj |
| [have](https://en.wiktionary.org/wiki/have#Danish) | garden | /ˈhaːvə/ · noun |
| [Dem](https://en.wiktionary.org/wiki/Dem#Danish) | you (object pronoun: the person being addressed) | /dɛm/ · pron |
| [dem](https://en.wiktionary.org/wiki/dem#Danish) | them (3rd person plural, objective case) | /dɛm/ · pron |
| [to](https://en.wiktionary.org/wiki/to#Danish) | two | [ˈtˢoˀ] · num |
| [din](https://en.wiktionary.org/wiki/din#Danish) | your, thy (singular; one owner) | /diːn/ · det |
| [får](https://en.wiktionary.org/wiki/f%C3%A5r#Danish) | sheep (Ovis aries) | /fɒːˀ/ · noun |

</details>

<details><summary>Words 51–100</summary>

![[Resources/Audio/da/Words 0051-0100.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [kun](https://en.wiktionary.org/wiki/kun#Danish) | only | [ˈkʰɔn] · adv |
| [end](https://en.wiktionary.org/wiki/end#Danish) | than (in comparisons) | /ɛn/ · conj |
| [jo](https://en.wiktionary.org/wiki/jo#Danish) | as you know or should know (sometimes vaguely translatable as after all or obviously) | [jo] · adv |
| [dag](https://en.wiktionary.org/wiki/dag#Danish) | day | /daːˀɣ/ · noun |
| [flere](https://en.wiktionary.org/wiki/flere#Danish) | more (in relation to number, with countable nouns) | [ˈfleːɐ] · adj |
| [ja](https://en.wiktionary.org/wiki/ja#Danish) | yes | /ja/ · intj |
| [mod](https://en.wiktionary.org/wiki/mod#Danish) | courage | [ˈmoˀð] · noun |
| [god](https://en.wiktionary.org/wiki/god#Danish) | good | [ˈɡ̊oˀð] · adj |
| [igen](https://en.wiktionary.org/wiki/igen#Danish) | again |  · adv |
| [os](https://en.wiktionary.org/wiki/os#Danish) | us, objective of vi | /ɔs/ · pron |
| [i går](https://en.wiktionary.org/wiki/i%20g%C3%A5r#Danish) | yesterday (the day before today) | [iˈɡ̊ɒ̝ˀ] · phrase |
| [gang](https://en.wiktionary.org/wiki/gang#Danish) | the act of walking, a walk | /ɡ̊anɡ̊/ · noun |
| [ville](https://en.wiktionary.org/wiki/ville#Danish) | to want to, be willing to | /vilə/ · verb |
| [hvordan](https://en.wiktionary.org/wiki/hvordan#Danish) | how | [ʋʌˈd̥an] · adv |
| [skulle](https://en.wiktionary.org/wiki/skulle#Danish) | will, would, shall, should (modal verbs) | [ˈsɡ̊ulə] · verb |
| [tid](https://en.wiktionary.org/wiki/tid#Danish) | time | [ˈtˢiˀð] · noun |
| [dansk](https://en.wiktionary.org/wiki/dansk#Danish) | Danish (of or pertaining to Denmark) | /dansk/ · adj |
| [ham](https://en.wiktionary.org/wiki/ham#Danish) | slough, skin | /ˈhɑmˀ/ · noun |
| [under](https://en.wiktionary.org/wiki/under#Danish) | under | /on(ˀ)ər/ · prep |
| [sin](https://en.wiktionary.org/wiki/sin#Danish) | third-person sg pronoun, meaning his/her/its (own) |  · pron |
| [ingen](https://en.wiktionary.org/wiki/ingen#Danish) | no | /ˈenɡən/ · pron |
| [anden](https://en.wiktionary.org/wiki/anden#Danish) | other, another, else | /ˈanən/ · pron |
| [A](https://en.wiktionary.org/wiki/A#Danish) | The first letter of the Danish alphabet, written in the Latin script. | /æː/ · noun |
| [udtale](https://en.wiktionary.org/wiki/udtale) | pronunciation |  · noun |
| [del](https://en.wiktionary.org/wiki/del#Danish) | part, portion | [ˈd̥eˀl] · noun |
| [tak](https://en.wiktionary.org/wiki/tak#Danish) | thanks | /tak/ · noun |
| [brug](https://en.wiktionary.org/wiki/brug#Danish) | use, application | [ˈb̥ʁuˀ] · noun |
| [-s](https://en.wiktionary.org/wiki/-s#Danish) | Used to form genitive/possessive phrases, attached to the last word in a noun phrase. |  · particle |
| [gå](https://en.wiktionary.org/wiki/g%C3%A5#Danish) | to go | [ˈɡ̊ɔˀ] · verb |
| [hos](https://en.wiktionary.org/wiki/hos#Danish) | at X's abode | [hɔs] · prep |
| [ret](https://en.wiktionary.org/wiki/ret#Danish) | straight | /rɛt/ · adj |
| [stor](https://en.wiktionary.org/wiki/stor#Danish) | large (of a great size) | /stoːˀr/ · adj |
| [komme](https://en.wiktionary.org/wiki/komme#Danish) | to come | [ˈkʰʌmə] · verb |
| [tre](https://en.wiktionary.org/wiki/tre#Danish) | three | [ˈtˢʁ̥ɛˀ] · num |
| [giver](https://en.wiktionary.org/wiki/giver#Danish) | giver | [ˈɡ̊iːʋɐ] · noun |
| [mest](https://en.wiktionary.org/wiki/mest#Danish) | most; to the highest degree | /mest/ · adj |
| [folk](https://en.wiktionary.org/wiki/folk#Danish) | a people, a nation (not necessarily politically or geographically united) | /fɔlk/ · noun |
| [ny](https://en.wiktionary.org/wiki/ny#Danish) | new | /nyː/ · adj |
| [aldrig](https://en.wiktionary.org/wiki/aldrig#Danish) | never (at no time) | /aldri/ · adv |
| [ned](https://en.wiktionary.org/wiki/ned#Danish) | down, downwards | /nɛð/ · adv |
| [disse](https://en.wiktionary.org/wiki/disse#Danish) | only used in ikke en disse (“not a scrap”) | [ˈd̥isə] · noun |
| [hold](https://en.wiktionary.org/wiki/hold#Danish) | team (group of persons working or playing together) | [ˈhʌlˀ] · noun |
| [mand](https://en.wiktionary.org/wiki/mand#Danish) | man (adult male human) | /manˀ/ · noun |
| [nej](https://en.wiktionary.org/wiki/nej#Danish) | no | /nɛj/ · intj |
| [gode](https://en.wiktionary.org/wiki/gode#Danish) | advantage, blessing, boon | [ˈɡ̊oːðə] · noun |
| [mine](https://en.wiktionary.org/wiki/mine#Danish) | look, air, mien | /miːnə/ · noun |
| [give](https://en.wiktionary.org/wiki/give#Danish) | to give | [ˈɡ̊iˀ] · verb |
| [klar](https://en.wiktionary.org/wiki/klar#Danish) | clear | [ˈkʰl̥ɑˀ] · adj |
| [hver](https://en.wiktionary.org/wiki/hver#Danish) | every, each | /ˈvɛːˀr/ · pron |
| [par](https://en.wiktionary.org/wiki/par#Danish) | pair | [ˈpʰɑ] · noun |

</details>

<details><summary>Words 101–150</summary>

![[Resources/Audio/da/Words 0101-0150.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [sted](https://en.wiktionary.org/wiki/sted#Danish) | place | [ˈsd̥ɛð] · noun |
| [mens](https://en.wiktionary.org/wiki/mens#Danish) | while, when (during the same time that) | /mɛns/ · conj |
| [tog](https://en.wiktionary.org/wiki/tog#Danish) | train | /tɔː(ˀ)ɣ/ · noun |
| [navn](https://en.wiktionary.org/wiki/navn#Danish) | name (word or phrase indicating a particular person, place, class or thing) | [ˈnɑwˀn] · noun |
| [vel](https://en.wiktionary.org/wiki/vel#Danish) | well | /ˈvɛl/ · adv |
| [liv](https://en.wiktionary.org/wiki/liv#Danish) | life | /liːv/ · noun |
| [grund](https://en.wiktionary.org/wiki/grund#Danish) | shallow | [ɡ̊ʁɔnˀ] · adj |
| [sit](https://en.wiktionary.org/wiki/sit#Danish) | third-person sg pronoun, meaning his/her/its (own) |  · pron |
| [side](https://en.wiktionary.org/wiki/side#Danish) | side; a bounding straight edge or surface | /ˈsiːdə/ · noun |
| [tv](https://en.wiktionary.org/wiki/tv#Danish) | TV |  · noun |
| [lave](https://en.wiktionary.org/wiki/lave#Danish) | to make, create, construct, produce | /ˈlaːvə/ · verb |
| [morgen](https://en.wiktionary.org/wiki/morgen#Danish) | morning (the part of the day after midnight and before midday) | /ˈmɔrən/ · noun |
| [kort](https://en.wiktionary.org/wiki/kort#Danish) | short | /kɔrt/ · adj |
| [unge](https://en.wiktionary.org/wiki/unge#Danish) | young one (offspring of animals) | [ˈɔŋə] · noun |
| [holder](https://en.wiktionary.org/wiki/holder#Danish) | holder | [ˈhʌlɐ] · noun |
| [lang](https://en.wiktionary.org/wiki/lang#Danish) | long (having great distance) | /lanɡ/ · adj |
| [tale](https://en.wiktionary.org/wiki/tale#Danish) | speech, talk, address, discourse | /tsʰaːlə/ · noun |
| [videre](https://en.wiktionary.org/wiki/videre#Danish) | further (comparative of far) | /vidərə/ · adj |
| [lad](https://en.wiktionary.org/wiki/lad#Danish) | languid, lazy, indolent |  · adj |
| [fire](https://en.wiktionary.org/wiki/fire#Danish) | four | /fiːrə/ · num |
| [mål](https://en.wiktionary.org/wiki/m%C3%A5l#Danish) | language | /mɔːl/ · noun |
| [via](https://en.wiktionary.org/wiki/via#Danish) | via; by way of; passing through. | /ˈviːæ/ · prep |
| [bag](https://en.wiktionary.org/wiki/bag#Danish) | behind, bottom, butt, buttocks | /baːɣ/ · noun |
| [spørgsmål](https://en.wiktionary.org/wiki/sp%C3%B8rgsm%C3%A5l#Danish) | question | /ˈspœɐ̯sˌmɔˀl/ · noun |
| [mor](https://en.wiktionary.org/wiki/mor#Danish) | mother (woman who has, conceives, gives birth to, or raises a child) | /moːɐ̯/ · noun |
| [ord](https://en.wiktionary.org/wiki/ord#Danish) | word (a single word) | /oːˀr/ · noun |
| [mad](https://en.wiktionary.org/wiki/mad#Danish) | food | /mað/ · noun |
| [fem](https://en.wiktionary.org/wiki/fem#Danish) | five | [ˈfɛmˀ] · num |
| [hej](https://en.wiktionary.org/wiki/hej#Danish) | hi, hello | /hɑj/ · intj |
| [timer](https://en.wiktionary.org/wiki/timer#Danish) | timer | /tajmər/ · noun |
| [fast](https://en.wiktionary.org/wiki/fast#Danish) | firm | /fast/ · adj |
| [film](https://en.wiktionary.org/wiki/film#Danish) | a movie, a film, motion picture | /film/ · noun |
| [far](https://en.wiktionary.org/wiki/far#Danish) | father, dad | /fɑː/ · noun |
| [glad](https://en.wiktionary.org/wiki/glad#Danish) | happy, glad | /ˈɡlað/ · adj |
| [vide](https://en.wiktionary.org/wiki/vide#Danish) | to know (be certain or sure about (something)) | /viːðə/ · verb |
| [by](https://en.wiktionary.org/wiki/by#Danish) | town, city | [ˈb̥yˀ] · noun |
| [form](https://en.wiktionary.org/wiki/form#Danish) | form | /fɔrm/ · noun |
| [historie](https://en.wiktionary.org/wiki/historie#Danish) | history | /histoːˀriɘ/ · noun |
| [familie](https://en.wiktionary.org/wiki/familie#Danish) | family (father, mother and their sons and daughters) | /faˈmilˀjə/ · noun |
| [valg](https://en.wiktionary.org/wiki/valg#Danish) | choice | /valˀɣ/ · noun |
| [stå](https://en.wiktionary.org/wiki/st%C3%A5#Danish) | to stand | [ˈsd̥ɔˀ] · verb |
| [al](https://en.wiktionary.org/wiki/al#Danish) | all | /al/ · pron |
| [blot](https://en.wiktionary.org/wiki/blot#Danish) | only, merely | [ˈb̥lʌd̥] · adv |
| [job](https://en.wiktionary.org/wiki/job#Danish) | job | [ˈd̥jʌb̥] · noun |
| [et al.](https://en.wiktionary.org/wiki/et%20al.#Danish) | et al.; used to complete a list of authors |  · phrase |
| [in](https://en.wiktionary.org/wiki/in#Danish) | fashionable, in |  · adj |
| [lade](https://en.wiktionary.org/wiki/lade#Danish) | barn (building) | [ˈlæːðə] · noun |
| [bog](https://en.wiktionary.org/wiki/bog#Danish) | book | /bɔːˀɣ/ · noun |
| [nå](https://en.wiktionary.org/wiki/n%C3%A5#Danish) | to reach | /nɔːˀ/ · verb |
| [live](https://en.wiktionary.org/wiki/live#Danish) | to enliven | /liːvə/ · verb |

</details>

<details><summary>Words 151–200</summary>

![[Resources/Audio/da/Words 0151-0200.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [barn](https://en.wiktionary.org/wiki/barn#Danish) | child (immature human) | /barn/ · noun |
| [fri](https://en.wiktionary.org/wiki/fri#Danish) | to propose (to ask for one's hand in marriage) | /friː/ · verb |
| [ad](https://en.wiktionary.org/wiki/ad#Danish) | by | [að] · prep |
| [bad](https://en.wiktionary.org/wiki/bad#Danish) | bath, shower, swim | [ˈb̥að] · noun |
| [hus](https://en.wiktionary.org/wiki/hus#Danish) | house | [ˈhuˀs] · noun |
| [spille](https://en.wiktionary.org/wiki/spille#Danish) | to play (music, a game, in a theatrical performance) | /spelə/ · verb |
| [datter](https://en.wiktionary.org/wiki/datter#Danish) | daughter | /ˈdadɐ/ · noun |
| [svar](https://en.wiktionary.org/wiki/svar#Danish) | answer (response) | /svɑːˀ/ · noun |
| [taler](https://en.wiktionary.org/wiki/taler#Danish) | speaker | /taːlər/ · noun |
| [hen](https://en.wiktionary.org/wiki/hen#Danish) | Used with a verb, indicating a movement towards or to something. | [ˈhɛn] · adv |
| [lyst](https://en.wiktionary.org/wiki/lyst#Danish) | inclination, desire, wish | /løst/ · noun |
| [t](https://en.wiktionary.org/wiki/t#Danish) | ton | /teː/ · noun |
| [tag](https://en.wiktionary.org/wiki/tag#Danish) | roof | /taːˀɣ/ · noun |
| [bil](https://en.wiktionary.org/wiki/bil#Danish) | car, automobile | /biːl/ · noun |
| [land](https://en.wiktionary.org/wiki/land#Danish) | country (a geographical area that is politically independent) | /lanˀ/ · noun |
| [passer](https://en.wiktionary.org/wiki/passer#Danish) | compass, pair of compasses (tool for drawing circles and arcs) | /pasər/ · noun |
| [sat](https://en.wiktionary.org/wiki/sat#Danish) | lethargic, sluggish, indolent |  · adj |
| [problem](https://en.wiktionary.org/wiki/problem#Danish) | problem |  · noun |
| [skrive](https://en.wiktionary.org/wiki/skrive#Danish) | to write (on any medium, including electronic ones) | /skriːvə/ · verb |
| [venstre](https://en.wiktionary.org/wiki/venstre#Danish) | left (direction) |  · adj |
| [bor](https://en.wiktionary.org/wiki/bor#Danish) | boron (chemical element) | /boːr/ · noun |
| [inde](https://en.wiktionary.org/wiki/inde#Danish) | inside, indoors | [ˈenə] · adv |
| [nummer](https://en.wiktionary.org/wiki/nummer#Danish) | number | [ˈnɔmˀɐ] · noun |
| [seks](https://en.wiktionary.org/wiki/seks#Danish) | six | /sɛks/ · num |
| [prøve](https://en.wiktionary.org/wiki/pr%C3%B8ve#Danish) | trial, test, examination | /prøːvə/ · noun |
| [time](https://en.wiktionary.org/wiki/time#Danish) | hour | /ˈtiːmə/ · noun |
| [and](https://en.wiktionary.org/wiki/and#Danish) | duck (Anatinae) | /anˀ/ · noun |
| [tro](https://en.wiktionary.org/wiki/tro#Danish) | belief | /troːˀ/ · noun |
| [musik](https://en.wiktionary.org/wiki/musik#Danish) | music | /musik/ · noun |
| [person](https://en.wiktionary.org/wiki/person#Danish) | person |  · noun |
| [maj](https://en.wiktionary.org/wiki/maj#Danish) | May (the fifth month of the Gregorian calendar) | /maj/ · noun |
| [gratis](https://en.wiktionary.org/wiki/gratis#Danish) | gratis, free (obtainable without payment) | /ɡraːtis/ · adj |
| [lange](https://en.wiktionary.org/wiki/lange#Danish) | ling, common ling (the fish Molva molva, similar to the cod) | /laŋə/ · noun |
| [mening](https://en.wiktionary.org/wiki/mening#Danish) | an opinion (subjective thought) | [ˈmeːneŋ] · noun |
| [råd](https://en.wiktionary.org/wiki/r%C3%A5d#Danish) | council | [ˈʁɔˀð] · noun |
| [september](https://en.wiktionary.org/wiki/september#Danish) | September (the ninth month of the Gregorian calendar, following August and preceding October, containing the southward equinox) | /səptɛmbər/ · noun |
| [fly](https://en.wiktionary.org/wiki/fly#Danish) | airplane, aeroplane | [ˈflyˀ] · noun |
| [gift](https://en.wiktionary.org/wiki/gift#Danish) | poison (substance harmful to a living organism) | /ɡift/ · noun |
| [plan](https://en.wiktionary.org/wiki/plan#Danish) | a plan |  · noun |
| [sag](https://en.wiktionary.org/wiki/sag#Danish) | matter, affair | /saːɡ/ · noun |
| [super](https://en.wiktionary.org/wiki/super#Danish) | terrific | [ˈsuˀb̥ɐ] · adj |
| [pris](https://en.wiktionary.org/wiki/pris#Danish) | price | /priːs/ · noun |
| [video](https://en.wiktionary.org/wiki/video#Danish) | video |  · noun |
| [vise](https://en.wiktionary.org/wiki/vise#Danish) | song, ballad, ditty | [ˈʋiːsə] · noun |
| [el](https://en.wiktionary.org/wiki/el#Danish) | alder | /ɛl/ · noun |
| [let](https://en.wiktionary.org/wiki/let#Danish) | light (not heavy) | [ˈlɛd̥] · adj |
| [mulighed](https://en.wiktionary.org/wiki/mulighed#Danish) | possibility | /muːliheːd/ · noun |
| [slå](https://en.wiktionary.org/wiki/sl%C3%A5#Danish) | bolt | /slɔːˀ/ · noun |
| [april](https://en.wiktionary.org/wiki/april#Danish) | April (the fourth month of the Gregorian calendar) | /aˈpʁiːˀl/ · noun |
| [blå](https://en.wiktionary.org/wiki/bl%C3%A5#Danish) | blue (blue-colored) | /blɔːˀ/ · adj |

</details>

<details><summary>Words 201–250</summary>

![[Resources/Audio/da/Words 0201-0250.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [lever](https://en.wiktionary.org/wiki/lever#Danish) | liver | [ˈlewˀɐ] · noun |
| [tal](https://en.wiktionary.org/wiki/tal#Danish) | number | /tal/ · noun |
| [juni](https://en.wiktionary.org/wiki/juni#Danish) | June (the sixth month of the Gregorian calendar) | /ˈjuːˀni/ · noun |
| [leve](https://en.wiktionary.org/wiki/leve#Danish) | to live, be alive | [ˈleːʋə] · verb |
| [sex](https://en.wiktionary.org/wiki/sex#Danish) | Sexual intercourse, sex. |  · noun |
| [spise](https://en.wiktionary.org/wiki/spise#Danish) | food | /spiːsə/ · noun |
| [dyr](https://en.wiktionary.org/wiki/dyr#Danish) | animal, beast (as opposed to human beings, or of human beings acting brutally) | /dyːˀɐ̯/ · noun |
| [ej](https://en.wiktionary.org/wiki/ej#Danish) | not | /aj/ · adv |
| [grad](https://en.wiktionary.org/wiki/grad#Danish) | degree | [ˈɡ̊ʁɑˀð] · noun |
| [kaffe](https://en.wiktionary.org/wiki/kaffe#Danish) | coffee | /ˈkɑfə/ · noun |
| [sort](https://en.wiktionary.org/wiki/sort#Danish) | black (color/colour) | [ˈsoɐ̯d̥] · adj |
| [vis](https://en.wiktionary.org/wiki/vis#Danish) | manner, way | [ˈʋiˀs] · noun |
| [ha](https://en.wiktionary.org/wiki/ha#Danish) | ha! (an exclamation of triumph or discovery) | /ha/ · intj |
| [højre](https://en.wiktionary.org/wiki/h%C3%B8jre#Danish) | right (direction) | /hɔjrə/ · adj |
| [stand](https://en.wiktionary.org/wiki/stand#Danish) | position, social status, station | [ˈsd̥anˀ] · noun |
| [gud](https://en.wiktionary.org/wiki/gud#Danish) | god, God (deity, supernatural being) | [ˈɡ̊uð] · noun |
| [love](https://en.wiktionary.org/wiki/love#Danish) | to promise | /ˈlɔːvə/ · verb |
| [meter](https://en.wiktionary.org/wiki/meter#Danish) | a metre, or meter (US) (SI unit of measurement) |  · noun |
| [starter](https://en.wiktionary.org/wiki/starter#Danish) | starter |  · noun |
| [tøj](https://en.wiktionary.org/wiki/t%C3%B8j#Danish) | fabric, material | /ˈtɔj/ · noun |
| [bo](https://en.wiktionary.org/wiki/bo#Danish) | estate (the property of a deceased person) | /boː/ · noun |
| [januar](https://en.wiktionary.org/wiki/januar#Danish) | January (the first month of the Gregorian calendar) | /ˈjanuˌɑˀ/ · noun |
| [moderne](https://en.wiktionary.org/wiki/moderne#Danish) | modern (pertaining to the current time and style) |  · adj |
| [o](https://en.wiktionary.org/wiki/o#Danish) | Vocative particle. |  · particle |
| [politik](https://en.wiktionary.org/wiki/politik#Danish) | politics | [pʰoliˈtˢiɡ̊] · noun |
| [stil](https://en.wiktionary.org/wiki/stil#Danish) | style | /sdiːl/ · noun |
| [is](https://en.wiktionary.org/wiki/is#Danish) | ice (water in frozen form) | /ˈiːˀs/ · noun |
| [gruppe](https://en.wiktionary.org/wiki/gruppe#Danish) | A group, a unit, a team. | [ˈɡ̊ʁub̥ə] · noun |
| [lys](https://en.wiktionary.org/wiki/lys#Danish) | light, bright | [ˈlyˀs] · adj |
| [oktober](https://en.wiktionary.org/wiki/oktober#Danish) | October (the tenth month of the Gregorian calendar, following September and preceding November) |  · noun |
| [syv](https://en.wiktionary.org/wiki/syv#Danish) | seven | [ˈsywˀ] · num |
| [august](https://en.wiktionary.org/wiki/august#Danish) | August (the eighth month of the Roman, Julian, and Gregorian calendars, following July and preceding September) | /avˈɡost/ · noun |
| [type](https://en.wiktionary.org/wiki/type#Danish) | a type (kind, sort) |  · noun |
| [ung](https://en.wiktionary.org/wiki/ung#Danish) | young | [ˈɔŋˀ] · adj |
| [dens](https://en.wiktionary.org/wiki/dens#Danish) | its, possessive form of den |  · pron |
| [periode](https://en.wiktionary.org/wiki/periode#Danish) | period |  · noun |
| [start](https://en.wiktionary.org/wiki/start#Danish) | start |  · noun |
| [ændre](https://en.wiktionary.org/wiki/%C3%A6ndre#Danish) | to change, to alter | /ɛndrə/ · verb |
| [økonomi](https://en.wiktionary.org/wiki/%C3%B8konomi#Danish) | economy | /økonomiː/ · noun |
| [fest](https://en.wiktionary.org/wiki/fest#Danish) | party | /ˈfɛsd/ · noun |
| [fin](https://en.wiktionary.org/wiki/fin#Danish) | fine | /fin/ · adj |
| [måned](https://en.wiktionary.org/wiki/m%C3%A5ned#Danish) | month | /ˈmɔːnəð/ · noun |
| [point](https://en.wiktionary.org/wiki/point#Danish) | a point (in a game) | [pʰoˈɛŋ] · noun |
| [rent](https://en.wiktionary.org/wiki/rent#Danish) | purely (morally) | /reːˀnt/ · adv |
| [sommer](https://en.wiktionary.org/wiki/sommer#Danish) | summer (hottest season) | /ˈsɔmɐ/ · noun |
| [øje](https://en.wiktionary.org/wiki/%C3%B8je#Danish) | eye | /ɔjə/ · noun |
| [data](https://en.wiktionary.org/wiki/data#Danish) | datum, data |  · noun |
| [niveau](https://en.wiktionary.org/wiki/niveau#Danish) | level | /nivo/ · noun |
| [sang](https://en.wiktionary.org/wiki/sang#Danish) | song | [sɑŋˀ] · noun |
| [succes](https://en.wiktionary.org/wiki/succes#Danish) | success (achievement of one's aim or goal) | /sykse/ · noun |

</details>

<details><summary>Words 251–300</summary>

![[Resources/Audio/da/Words 0251-0300.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [ti](https://en.wiktionary.org/wiki/ti#Danish) | ten | /tiːˀ/ · num |
| [top](https://en.wiktionary.org/wiki/top#Danish) | summit, peak |  · noun |
| [øl](https://en.wiktionary.org/wiki/%C3%B8l#Danish) | beer (liquid) | /øl/ · noun |
| [hår](https://en.wiktionary.org/wiki/h%C3%A5r#Danish) | hair (collectively) | /hɔːˀr/ · noun |
| [sprog](https://en.wiktionary.org/wiki/sprog#Danish) | language | /sprɔːˀɣ/ · noun |
| [stemme](https://en.wiktionary.org/wiki/stemme#Danish) | voice (sound uttered by the mouth, especially that uttered by human beings in speech or song) | [ˈsd̥ɛmə] · noun |
| [december](https://en.wiktionary.org/wiki/december#Danish) | December (the twelfth and last month of the Gregorian calendar) | /deˈsɛˀmbɐ/ · noun |
| [slut](https://en.wiktionary.org/wiki/slut#Danish) | over | /slut/ · adj |
| [bror](https://en.wiktionary.org/wiki/bror#Danish) | brother (male sibling) | /ˈbʁoɐ̯/ · noun |
| [kone](https://en.wiktionary.org/wiki/kone#Danish) | wife (married woman) | [ˈkʰoːnə] · noun |
| [nat](https://en.wiktionary.org/wiki/nat#Danish) | night (period between sunset and sunrise) | /nad̥/ · noun |
| [november](https://en.wiktionary.org/wiki/november#Danish) | November (the eleventh month of the Gregorian calendar, following October and preceding December) |  · noun |
| [ven](https://en.wiktionary.org/wiki/ven#Danish) | friend | /vɛn/ · noun |
| [ben](https://en.wiktionary.org/wiki/ben#Danish) | leg (a limb of a human or an animal used for walking; also, by analogy, the legs of a desk or a chair) | /beːˀn/ · noun |
| [engelsk](https://en.wiktionary.org/wiki/engelsk#Danish) | English (of or pertaining to England) | /ˈɛŋˀəlsɡ/ · adj |
| [klasse](https://en.wiktionary.org/wiki/klasse#Danish) | class (a group of students in a school) |  · noun |
| [pas](https://en.wiktionary.org/wiki/pas#Danish) | passport |  · noun |
| [spor](https://en.wiktionary.org/wiki/spor#Danish) | track | /spoːr/ · noun |
| [telefon](https://en.wiktionary.org/wiki/telefon#Danish) | telephone (an electronic device used for two-way talking with other people) | /teləfoːn/ · noun |
| [an](https://en.wiktionary.org/wiki/an#Danish) | on (only used in lexicalized expressions) | [ˈan] · adv |
| [baby](https://en.wiktionary.org/wiki/baby#Danish) | A baby, an infant. |  · noun |
| [februar](https://en.wiktionary.org/wiki/februar#Danish) | February (the second month of the Gregorian calendar) | /ˈfebʁuˌɑːˀ/ · noun |
| [fyr](https://en.wiktionary.org/wiki/fyr#Danish) | guy (a younger male person) | /fyːˀr/ · noun |
| [spørge](https://en.wiktionary.org/wiki/sp%C3%B8rge#Danish) | to ask, inquire | [ˈsb̥ɶɐ̯wə] · verb |
| [system](https://en.wiktionary.org/wiki/system#Danish) | system | /systeːm/ · noun |
| [tredje](https://en.wiktionary.org/wiki/tredje#Danish) | third | /ˈtreðjə/ · num |
| [menneske](https://en.wiktionary.org/wiki/menneske#Danish) | human, human being, man (a member of the species Homo sapiens or related prehistoric species of the genus Homo) | /mɛnəskə/ · noun |
| [per](https://en.wiktionary.org/wiki/per#Danish) | for each; for every |  · prep |
| [social](https://en.wiktionary.org/wiki/social#Danish) | social | [soˈɕæˀl] · adj |
| [chef](https://en.wiktionary.org/wiki/chef#Danish) | A boss; person in charge, person who directly oversees the work being done | /ˈsjɛːˀf/ · noun |
| [klub](https://en.wiktionary.org/wiki/klub#Danish) | a club (organisation) |  · noun |
| [ren](https://en.wiktionary.org/wiki/ren#Danish) | reindeer | /reːˀn/ · noun |
| [sport](https://en.wiktionary.org/wiki/sport#Danish) | sport |  · noun |
| [alder](https://en.wiktionary.org/wiki/alder#Danish) | age |  · noun |
| [bank](https://en.wiktionary.org/wiki/bank#Danish) | bank (financial institution, branch office, controller of a game, a safe and guaranteed place of storage) | /ˈbɑŋˀɡ/ · noun |
| [brød](https://en.wiktionary.org/wiki/br%C3%B8d#Danish) | bread | /brøːˀð/ · noun |
| [lav](https://en.wiktionary.org/wiki/lav#Danish) | low (all senses) | /ˈlaːˀv/ · adj |
| [ni](https://en.wiktionary.org/wiki/ni#Danish) | nine | /niː/ · num |
| [per se](https://en.wiktionary.org/wiki/per%20se#Danish) | per se |  · adv |
| [ro](https://en.wiktionary.org/wiki/ro#Danish) | calmness | /roː/ · noun |
| [chance](https://en.wiktionary.org/wiki/chance#Danish) | chance | [ˈɕɑŋsə] · noun |
| [led](https://en.wiktionary.org/wiki/led#Danish) | joint (movable connection between the bones in a body or a minor exterior part of the body; also of joints in a plant) | /leð/ · noun |
| [parti](https://en.wiktionary.org/wiki/parti#Danish) | lot, quantity, batch | /parti/ · noun |
| [passe](https://en.wiktionary.org/wiki/passe#Danish) | to look after |  · verb |
| [sko](https://en.wiktionary.org/wiki/sko#Danish) | shoe | /sɡoːˀ/ · noun |
| [orden](https://en.wiktionary.org/wiki/orden#Danish) | order, neatness (proper arrangement of things) | /ɔrˀdən/ · noun |
| [sove](https://en.wiktionary.org/wiki/sove#Danish) | to sleep | /sɔvə/ · verb |
| [tysk](https://en.wiktionary.org/wiki/tysk#Danish) | German (relating to the country, people or language of Germany) | /tysk/ · adj |
| [lørdag](https://en.wiktionary.org/wiki/l%C3%B8rdag#Danish) | Saturday | /lørda/ · noun |
| [fred](https://en.wiktionary.org/wiki/fred#Danish) | peace | /freð/ · noun |

</details>

<details><summary>Words 301–350</summary>

![[Resources/Audio/da/Words 0301-0350.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [fredag](https://en.wiktionary.org/wiki/fredag#Danish) | Friday | /freːda/ · noun |
| [hotel](https://en.wiktionary.org/wiki/hotel#Danish) | hotel |  · noun |
| [hund](https://en.wiktionary.org/wiki/hund#Danish) | dog | [hunˀ] · noun |
| [hård](https://en.wiktionary.org/wiki/h%C3%A5rd#Danish) | hard | [hɒˀ] · adj |
| [rum](https://en.wiktionary.org/wiki/rum#Danish) | room (part of a building) | /rom/ · noun |
| [søndag](https://en.wiktionary.org/wiki/s%C3%B8ndag#Danish) | Sunday | /sœnda/ · noun |
| [træ](https://en.wiktionary.org/wiki/tr%C3%A6#Danish) | tree | /trɛːˀ/ · noun |
| [fuck](https://en.wiktionary.org/wiki/fuck#Danish) | Expresses dislike of the postpositive complement. |  · particle |
| [smart](https://en.wiktionary.org/wiki/smart#Danish) | well thought-out, neat |  · adj |
| [tom](https://en.wiktionary.org/wiki/tom#Danish) | empty | [ˈtˢʌmˀ] · adj |
| [hel](https://en.wiktionary.org/wiki/hel#Danish) | whole, entire, complete, full (undivided, with all elements) | /heːˀl/ · adj |
| [information](https://en.wiktionary.org/wiki/information#Danish) | information |  · noun |
| [mon](https://en.wiktionary.org/wiki/mon#Danish) | I wonder | /mon/ · adv |
| [my](https://en.wiktionary.org/wiki/my#Danish) | The Greek letter μ (mu) |  · noun |
| [nord](https://en.wiktionary.org/wiki/nord#Danish) | north | /noːr/ · noun |
| [post](https://en.wiktionary.org/wiki/post#Danish) | post (position, job) | /ˈpɔst/ · noun |
| [procent](https://en.wiktionary.org/wiki/procent#Danish) | percent | [pʁ̥oˈsɛnˀd̥] · noun |
| [seng](https://en.wiktionary.org/wiki/seng#Danish) | bed (a piece of furniture to sleep on) | /ˈsɛnɡ/ · noun |
| [sten](https://en.wiktionary.org/wiki/sten#Danish) | stone | /steːn/ · noun |
| [tanker](https://en.wiktionary.org/wiki/tanker#Danish) | a tanker (a ship fitted with tanks for carrying liquid cargoes) | /tankər/ · noun |
| [hurtig](https://en.wiktionary.org/wiki/hurtig#Danish) | quick, rapid, fast | /horti/ · adj |
| [mandag](https://en.wiktionary.org/wiki/mandag#Danish) | Monday | /ˈmanˀda/ · noun |
| [mark](https://en.wiktionary.org/wiki/mark#Danish) | field (wide, open space used to grow crops or to hold farm animals) | /mark/ · noun |
| [region](https://en.wiktionary.org/wiki/region#Danish) | region |  · noun |
| [ø](https://en.wiktionary.org/wiki/%C3%B8#Danish) | island | [ˈøˀ] · noun |
| [aktiv](https://en.wiktionary.org/wiki/aktiv#Danish) | active | /aktiːˀv/ · adj |
| [bar](https://en.wiktionary.org/wiki/bar#Danish) | bare, naked | /ˈbaːˀr/ · adj |
| [bud](https://en.wiktionary.org/wiki/bud#Danish) | command | [ˈb̥uð] · noun |
| [konge](https://en.wiktionary.org/wiki/konge#Danish) | king (male monarch) | /kɔnɡə/ · noun |
| [lege](https://en.wiktionary.org/wiki/lege#Danish) | to play | /lajə/ · verb |
| [drikke](https://en.wiktionary.org/wiki/drikke#Danish) | drink | [ˈd̥ʁɛɡ̊ə] · verb |
| [flytte](https://en.wiktionary.org/wiki/flytte#Danish) | move, remove (move a thing or a person from one place to another) | /fløtə/ · verb |
| [kim](https://en.wiktionary.org/wiki/kim#Danish) | germ | /kiːm/ · noun |
| [natur](https://en.wiktionary.org/wiki/natur#Danish) | nature | /natuːr/ · noun |
| [tekst](https://en.wiktionary.org/wiki/tekst#Danish) | a text | /tɛkst/ · noun |
| [tit](https://en.wiktionary.org/wiki/tit#Danish) | often | /tit/ · adv |
| [absolut](https://en.wiktionary.org/wiki/absolut#Danish) | absolute, full, complete | [ɑbsoˈlud] · adj |
| [hjerte](https://en.wiktionary.org/wiki/hjerte#Danish) | heart | /jɛrtə/ · noun |
| [kritik](https://en.wiktionary.org/wiki/kritik#Danish) | criticism |  · noun |
| [ring](https://en.wiktionary.org/wiki/ring#Danish) | ring | /renɡ/ · noun |
| [show](https://en.wiktionary.org/wiki/show#Danish) | show (play, dance, or other entertainment) | /ˈɕɔːw/ · noun |
| [fødselsdag](https://en.wiktionary.org/wiki/f%C3%B8dselsdag#Danish) | birthday (occasion and date of birth) | [ˈføsl̩sˌd̥æˀ] · noun |
| [jul](https://en.wiktionary.org/wiki/jul#Danish) | Christmas (the time around 25 December) | [ˈjuˀl] · noun |
| [status](https://en.wiktionary.org/wiki/status#Danish) | status (condition) | [ˈsdæːtus] · noun |
| [test](https://en.wiktionary.org/wiki/test#Danish) | A test, assessment or examination. | /ˈtɛsd/ · noun |
| [vor](https://en.wiktionary.org/wiki/vor#Danish) | our, ours | /vɔr/ · pron |
| [service](https://en.wiktionary.org/wiki/service#Danish) | tableware |  · noun |
| [søster](https://en.wiktionary.org/wiki/s%C3%B8ster#Danish) | sister (woman or girl having the same parents) | [ˈsøsd̥ɐ] · noun |
| [tab](https://en.wiktionary.org/wiki/tab#Danish) | loss | [ˈtˢæˀb̥] · noun |
| [van](https://en.wiktionary.org/wiki/van#Danish) | one of the Vanir | /vaːn/ · noun |

</details>

<details><summary>Words 351–400</summary>

![[Resources/Audio/da/Words 0351-0400.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [amerikansk](https://en.wiktionary.org/wiki/amerikansk#Danish) | American; of or pertaining to the Americas. |  · adj |
| [bord](https://en.wiktionary.org/wiki/bord#Danish) | table, desk | /ˈboːˀr/ · noun |
| [føle](https://en.wiktionary.org/wiki/f%C3%B8le#Danish) | to feel, sense | [ˈføːlə] · verb |
| [god jul](https://en.wiktionary.org/wiki/god%20jul#Danish) | Merry Christmas |  · phrase |
| [knap](https://en.wiktionary.org/wiki/knap#Danish) | scant, scarce | /knap/ · adj |
| [kunst](https://en.wiktionary.org/wiki/kunst#Danish) | art | [ˈkʰɔnˀsd̥] · noun |
| [svare](https://en.wiktionary.org/wiki/svare#Danish) | to answer, reply, respond (give a reply to a question; with a noun phrase or a noun clause as its object, with or without an indirect object) | /svaːrə/ · verb |
| [vis-a-vis](https://en.wiktionary.org/wiki/vis-a-vis#Danish) | vis-à-vis, face-to-face | [ˌvisaˈvi] · adv |
| [brand](https://en.wiktionary.org/wiki/brand#Danish) | fire (large, destructive fire, as in a building) | /branˀ/ · noun |
| [te](https://en.wiktionary.org/wiki/te#Danish) | tea (plant) (Camellia sinensis) | /ˈteːˀ/ · noun |
| [art](https://en.wiktionary.org/wiki/art#Danish) | kind | [ˈɑˀd̥] · noun |
| [general](https://en.wiktionary.org/wiki/general#Danish) | general |  · noun |
| [google](https://en.wiktionary.org/wiki/google#Danish) | to google; to search on an Internet search engine, especially Google |  · verb |
| [park](https://en.wiktionary.org/wiki/park#Danish) | park | /paːrk/ · noun |
| [torsdag](https://en.wiktionary.org/wiki/torsdag#Danish) | Thursday | /tɔrsda/ · noun |
| [frisk](https://en.wiktionary.org/wiki/frisk#Danish) | fresh | /frɛsk/ · adj |
| [luft](https://en.wiktionary.org/wiki/luft#Danish) | air | [ˈlɔfd̥] · noun |
| [mobil](https://en.wiktionary.org/wiki/mobil#Danish) | mobile, mobile phone, cell phone | /mobiːl/ · noun |
| [station](https://en.wiktionary.org/wiki/station#Danish) | station (major stopping place for busses or trains) | [sd̥aˈɕoˀn] · noun |
| [vin](https://en.wiktionary.org/wiki/vin#Danish) | wine (an alcoholic beverage made from grapes) | /viːˀn/ · noun |
| [fed](https://en.wiktionary.org/wiki/fed#Danish) | fat (carrying a larger than normal amount of fat on one's body), obese | [feˀð] · adj |
| [international](https://en.wiktionary.org/wiki/international#Danish) | international, having to do with more nations | [ˈentˢɐnaɕoˈnæˀl] · adj |
| [professor](https://en.wiktionary.org/wiki/professor#Danish) | professor |  · noun |
| [weekend](https://en.wiktionary.org/wiki/weekend#Danish) | weekend | [ˈviːˌɡ̊ɛnˀd̥] · noun |
| [analyse](https://en.wiktionary.org/wiki/analyse#Danish) | analysis (action of taking something apart to study it) |  · noun |
| [digital](https://en.wiktionary.org/wiki/digital#Danish) | digital (representing discrete values) | /diɡiˈtæˀl/ · adj |
| [ed](https://en.wiktionary.org/wiki/ed#Danish) | an oath (solemn pledge) |  · noun |
| [radio](https://en.wiktionary.org/wiki/radio#Danish) | radio |  · noun |
| [tirsdag](https://en.wiktionary.org/wiki/tirsdag#Danish) | Tuesday | /tiːrsda/ · noun |
| [brev](https://en.wiktionary.org/wiki/brev#Danish) | letter (written message) | /breːˀv/ · noun |
| [centrum](https://en.wiktionary.org/wiki/centrum#Danish) | centre | [ˈsɛn.tʁɔm] · noun |
| [kilometer](https://en.wiktionary.org/wiki/kilometer#Danish) | kilometre (SI unit of length) |  · noun |
| [ordre](https://en.wiktionary.org/wiki/ordre#Danish) | order (command,) | /ɔrˀdrə/ · noun |
| [pause](https://en.wiktionary.org/wiki/pause#Danish) | pause |  · noun |
| [skib](https://en.wiktionary.org/wiki/skib#Danish) | ship, boat, vessel | /ˈskiːp/ · noun |
| [glas](https://en.wiktionary.org/wiki/glas#Danish) | glass (substance) |  · noun |
| [hr.](https://en.wiktionary.org/wiki/hr.#Danish) | mister, Mr. | /hɛr/ · noun |
| [link](https://en.wiktionary.org/wiki/link#Danish) | link (hyperlink) | /lenk/ · noun |
| [mail](https://en.wiktionary.org/wiki/mail#Danish) | email |  · noun |
| [onsdag](https://en.wiktionary.org/wiki/onsdag#Danish) | Wednesday | /onsda/ · noun |
| [position](https://en.wiktionary.org/wiki/position#Danish) | a place, a location, a position. |  · noun |
| [bred](https://en.wiktionary.org/wiki/bred#Danish) | broad, wide | /breːˀð/ · adj |
| [dum](https://en.wiktionary.org/wiki/dum#Danish) | stupid, dense, dumb, thick, dim | /dom/ · adj |
| [firma](https://en.wiktionary.org/wiki/firma#Danish) | a company, a firm |  · noun |
| [gave](https://en.wiktionary.org/wiki/gave#Danish) | gift, present | [ˈɡ̊æːʋə] · noun |
| [handle](https://en.wiktionary.org/wiki/handle#Danish) | act (to do something) | /hanlə/ · verb |
| [linje](https://en.wiktionary.org/wiki/linje#Danish) | line |  · noun |
| [vest](https://en.wiktionary.org/wiki/vest#Danish) | west (compass point) | /vɛst/ · noun |
| [dame](https://en.wiktionary.org/wiki/dame#Danish) | lady, woman (adult female) | /daːmə/ · noun |
| [blod](https://en.wiktionary.org/wiki/blod#Danish) | blood | [ˈb̥loˀð] · noun |

</details>

<details><summary>Words 401–450</summary>

![[Resources/Audio/da/Words 0401-0450.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [date](https://en.wiktionary.org/wiki/date#Danish) | a date (meeting with a lover or potential lover) | /deɪt/ · noun |
| [etc.](https://en.wiktionary.org/wiki/etc.#Danish) | etc. |  · adv |
| [huse](https://en.wiktionary.org/wiki/huse#Danish) | house, harbour | /huːsə/ · verb |
| [slag](https://en.wiktionary.org/wiki/slag#Danish) | A hit, punch | /slaːˀɣ/ · noun |
| [stat](https://en.wiktionary.org/wiki/stat#Danish) | A state (polity). |  · noun |
| [sur](https://en.wiktionary.org/wiki/sur#Danish) | whirr (a sibilant buzz or vibration from insect wings) | /sur/ · noun |
| [æg](https://en.wiktionary.org/wiki/%C3%A6g#Danish) | egg | /ɛːˀɡ/ · noun |
| [blog](https://en.wiktionary.org/wiki/blog#Danish) | blog |  · noun |
| [bro](https://en.wiktionary.org/wiki/bro#Danish) | bridge | /broː/ · noun |
| [dialog](https://en.wiktionary.org/wiki/dialog#Danish) | dialogue | [diaˈloˀ] · noun |
| [drift](https://en.wiktionary.org/wiki/drift#Danish) | operation, running (of a company, a service or a mashine) | /dreft/ · noun |
| [dronning](https://en.wiktionary.org/wiki/dronning#Danish) | queen (a female monarch) | /drɔnenɡ/ · noun |
| [held](https://en.wiktionary.org/wiki/held#Danish) | luck, fortune | [ˈhɛlˀ] · noun |
| [rapport](https://en.wiktionary.org/wiki/rapport#Danish) | a report (information describing events) |  · noun |
| [rom](https://en.wiktionary.org/wiki/rom#Danish) | rum | /rɔm/ · noun |
| [strand](https://en.wiktionary.org/wiki/strand#Danish) | beach | /stran/ · noun |
| [udstyr](https://en.wiktionary.org/wiki/udstyr#Danish) | equipment |  · noun |
| [computer](https://en.wiktionary.org/wiki/computer#Danish) | computer (machine) | [kʰʌmˈpʰj̊uːd̥ɐ] · noun |
| [dans](https://en.wiktionary.org/wiki/dans#Danish) | a dance |  · noun |
| [hot](https://en.wiktionary.org/wiki/hot#Danish) | modern, in, fashionable, trendy (for a while) |  · adj |
| [internet](https://en.wiktionary.org/wiki/internet#Danish) | internet |  · noun |
| [lede](https://en.wiktionary.org/wiki/lede#Danish) | to manage, run | /ˈleːðə/ · verb |
| [rør](https://en.wiktionary.org/wiki/r%C3%B8r#Danish) | reed | /røːr/ · noun |
| [av](https://en.wiktionary.org/wiki/av#Danish) | ouch (expression of one's own physical pain) |  · intj |
| [big time](https://en.wiktionary.org/wiki/big%20time#Danish) | to a great extent, very |  · adv |
| [diverse](https://en.wiktionary.org/wiki/diverse#Danish) | various, sundry, miscellaneous, incidental. |  · adj |
| [gravid](https://en.wiktionary.org/wiki/gravid#Danish) | pregnant (carrying an unborn child) | /ɡraviːd/ · adj |
| [sand](https://en.wiktionary.org/wiki/sand#Danish) | true | /san/ · adj |
| [standard](https://en.wiktionary.org/wiki/standard#Danish) | standard | /ˈstanˌdarˀt/ · noun |
| [kaste](https://en.wiktionary.org/wiki/kaste#Danish) | caste | [ˈkʰasd̥ə] · noun |
| [mund](https://en.wiktionary.org/wiki/mund#Danish) | mouth (the opening of an animal through which food is ingested) | /monˀ/ · noun |
| [pik](https://en.wiktionary.org/wiki/pik#Danish) | peck (like a bird's peck) | /pik/ · noun |
| [å](https://en.wiktionary.org/wiki/%C3%A5#Danish) | river, creek, stream (only used of rivers in Denmark) | [ˈɔˀ] · noun |
| [fader](https://en.wiktionary.org/wiki/fader#Danish) | father |  · noun |
| [kat](https://en.wiktionary.org/wiki/kat#Danish) | cat | /kat/ · noun |
| [marked](https://en.wiktionary.org/wiki/marked#Danish) | market | /markəd/ · noun |
| [partner](https://en.wiktionary.org/wiki/partner#Danish) | partner |  · noun |
| [rose](https://en.wiktionary.org/wiki/rose#Danish) | rose (flower, shrub of the genus Rosa) | /roːsə/ · noun |
| [stof](https://en.wiktionary.org/wiki/stof#Danish) | cloth, fabric | /ˈsdʌf/ · noun |
| [stress](https://en.wiktionary.org/wiki/stress#Danish) | stress | [ˈsd̥ʁɛs] · noun |
| [avis](https://en.wiktionary.org/wiki/avis#Danish) | newspaper | /aˈviːˀs/ · noun |
| [fart](https://en.wiktionary.org/wiki/fart#Danish) | speed | /farˀt/ · noun |
| [generation](https://en.wiktionary.org/wiki/generation#Danish) | generation (organisms or devices born or designed at the same time) |  · noun |
| [svensk](https://en.wiktionary.org/wiki/svensk#Danish) | Swedish (relating to the country, people or language of Sweden) | /ˈsvɛnˀsk/ · adj |
| [syn](https://en.wiktionary.org/wiki/syn#Danish) | vision, faculty of sight |  · noun |
| [bane](https://en.wiktionary.org/wiki/bane#Danish) | track | [ˈbæːnə] · noun |
| [dato](https://en.wiktionary.org/wiki/dato#Danish) | date (a given point of time) | /ˈdaːto/ · noun |
| [inspiration](https://en.wiktionary.org/wiki/inspiration#Danish) | inspiration |  · noun |
| [lig](https://en.wiktionary.org/wiki/lig#Danish) | equal to | [ˈliˀ] · adj |
| [olie](https://en.wiktionary.org/wiki/olie#Danish) | oil (liquid fat from plants) | /ˈoljə/ · noun |

</details>

<details><summary>Words 451–500</summary>

![[Resources/Audio/da/Words 0451-0500.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [slap](https://en.wiktionary.org/wiki/slap#Danish) | loose |  · adj |
| [sol](https://en.wiktionary.org/wiki/sol#Danish) | sun | /soːl/ · noun |
| [varm](https://en.wiktionary.org/wiki/varm#Danish) | warm, hot |  · adj |
| [handling](https://en.wiktionary.org/wiki/handling#Danish) | action, act |  · noun |
| [hospital](https://en.wiktionary.org/wiki/hospital#Danish) | hospital | /hɔspitaːl/ · noun |
| [kong](https://en.wiktionary.org/wiki/kong#Danish) | king (used as a title before the name of a king) | /kɔnɡ/ · noun |
| [minister](https://en.wiktionary.org/wiki/minister#Danish) | minister (a politician who heads a ministry) |  · noun |
| [organisation](https://en.wiktionary.org/wiki/organisation#Danish) | organization |  · noun |
| [religion](https://en.wiktionary.org/wiki/religion#Danish) | religion | [ʁɛliɡˈjoˀn] · noun |
| [ringer](https://en.wiktionary.org/wiki/ringer#Danish) | bell ringer / bell-ringer / bellringer (in a church) |  · noun |
| [trist](https://en.wiktionary.org/wiki/trist#Danish) | sad |  · adj |
| [lag](https://en.wiktionary.org/wiki/lag#Danish) | layer, coat (a coherent mass spread on the top or on the outside of something else) | /laːˀɣ/ · noun |
| [mulig](https://en.wiktionary.org/wiki/mulig#Danish) | possible, feasible | /muːli/ · adj |
| [stammer](https://en.wiktionary.org/wiki/stammer#Danish) | stutterer |  · noun |
| [advokat](https://en.wiktionary.org/wiki/advokat#Danish) | lawyer, attorney | /advokaːt/ · noun |
| [app](https://en.wiktionary.org/wiki/app#Danish) | app |  · noun |
| [drive](https://en.wiktionary.org/wiki/drive#Danish) | to force, drive, impel (to put in motion) | /driːvə/ · verb |
| [jagt](https://en.wiktionary.org/wiki/jagt#Danish) | hunting, shooting |  · noun |
| [kors](https://en.wiktionary.org/wiki/kors#Danish) | cross (execution instrument) | /kɔːrs/ · noun |
| [nøgen](https://en.wiktionary.org/wiki/n%C3%B8gen#Danish) | naked, nude | /nøjən/ · adj |
| [tema](https://en.wiktionary.org/wiki/tema#Danish) | a theme |  · noun |
| [album](https://en.wiktionary.org/wiki/album#Danish) | An album. | /albɔm/ · noun |
| [festival](https://en.wiktionary.org/wiki/festival#Danish) | a festival |  · noun |
| [flag](https://en.wiktionary.org/wiki/flag#Danish) | flag (cloth) | [flæˀj] · noun |
| [kop](https://en.wiktionary.org/wiki/kop#Danish) | A cup; A concave vessel for holding liquid, generally adorned with either a handle or a stem (confer goblet, glass.) | /kop/ · noun |
| [operation](https://en.wiktionary.org/wiki/operation#Danish) | an operation, undertaking |  · noun |
| [rig](https://en.wiktionary.org/wiki/rig#Danish) | rich (having wealth), wealthy, affluent | [ˈʁiˀ] · adj |
| [ære](https://en.wiktionary.org/wiki/%C3%A6re#Danish) | honor | /ˈɛːʌ/ · noun |
| [adresse](https://en.wiktionary.org/wiki/adresse#Danish) | address, abbreviated adr. | /adrɛsə/ · noun |
| [los](https://en.wiktionary.org/wiki/los#Danish) | loose |  · adj |
| [million](https://en.wiktionary.org/wiki/million#Danish) | A million, 10⁶. | [miliˈoˀn] · num |
| [museum](https://en.wiktionary.org/wiki/museum#Danish) | museum | [muˈsɛːɔm] · noun |
| [tunge](https://en.wiktionary.org/wiki/tunge#Danish) | tongue | [ˈtˢɔŋə] · noun |
| [dom](https://en.wiktionary.org/wiki/dom#Danish) | sentence | [ˈd̥ʌmˀ] · noun |
| [foto](https://en.wiktionary.org/wiki/foto#Danish) | photo | [ˈfod̥o] · noun |
| [gal](https://en.wiktionary.org/wiki/gal#Danish) | crazy, mad, insane (mentally ill) | /ɡaːˀl/ · adj |
| [grin](https://en.wiktionary.org/wiki/grin#Danish) | laugh | /ɡriːn/ · noun |
| [hest](https://en.wiktionary.org/wiki/hest#Danish) | horse | /ˈhɛsd/ · noun |
| [leg](https://en.wiktionary.org/wiki/leg#Danish) | play, game | [ˈlɑjˀ] · noun |
| [normal](https://en.wiktionary.org/wiki/normal#Danish) | a normal value or quantity (e.g. tempature etc.) | [nɒˈmæˀl] · noun |
| [papir](https://en.wiktionary.org/wiki/papir#Danish) | paper | /papiːr/ · noun |
| [skive](https://en.wiktionary.org/wiki/skive#Danish) | slice, shive |  · noun |
| [talent](https://en.wiktionary.org/wiki/talent#Danish) | talent (potential or factual ability to perform a skill better than most people) | /talɛnt/ · noun |
| [bus](https://en.wiktionary.org/wiki/bus#Danish) | bus, coach | /bus/ · noun |
| [hit](https://en.wiktionary.org/wiki/hit#Danish) | hit (something very successful) | /hit/ · noun |
| [journalist](https://en.wiktionary.org/wiki/journalist#Danish) | a journalist, a reporter (reporter on a newspaper) |  · noun |
| [le](https://en.wiktionary.org/wiki/le#Danish) | scythe (farm tool) | [leˀ] · noun |
| [restaurant](https://en.wiktionary.org/wiki/restaurant#Danish) | restaurant | [ʁɛsd̥oˈʁɑŋ] · noun |
| [stole](https://en.wiktionary.org/wiki/stole#Danish) | Only used with på: see stole på. | /stoːlə/ · verb |
| [strøm](https://en.wiktionary.org/wiki/str%C3%B8m#Danish) | flow, stream, spate | [ˈsd̥ʁœmˀ] · noun |

</details>

<details><summary>Words 501–550</summary>

![[Resources/Audio/da/Words 0501-0550.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [titel](https://en.wiktionary.org/wiki/titel#Danish) | A title. |  · noun |
| [fag](https://en.wiktionary.org/wiki/fag#Danish) | subject (of study) | /faːˀɣ/ · noun |
| [fare](https://en.wiktionary.org/wiki/fare#Danish) | danger, hazard | /ˈfaːrə/ · noun |
| [green](https://en.wiktionary.org/wiki/green#Danish) | a green, putting green (the closely mown area surrounding each hole on a golf course) |  · noun |
| [metal](https://en.wiktionary.org/wiki/metal#Danish) | metal | /metal/ · noun |
| [pension](https://en.wiktionary.org/wiki/pension#Danish) | a pension, boarding house |  · noun |
| [ah](https://en.wiktionary.org/wiki/ah#Danish) | used to express pleasure, e.g. because something tastes good or feels nice | /ɛː/ · intj |
| [båd](https://en.wiktionary.org/wiki/b%C3%A5d#Danish) | boat | /bɔːd/ · noun |
| [cd](https://en.wiktionary.org/wiki/cd#Danish) | CD, compact disc | /sedeːˀ/ · noun |
| [dagligt](https://en.wiktionary.org/wiki/dagligt#Danish) | daily, every day, on a daily basis | /daɣlit/ · adv |
| [em](https://en.wiktionary.org/wiki/em#Danish) | steam, vapour | [ˈɛmˀ] · noun |
| [gas](https://en.wiktionary.org/wiki/gas#Danish) | gas; a state of matter |  · noun |
| [id](https://en.wiktionary.org/wiki/id#Danish) | id (one of the three components of the personality in the Freudian psychoanalytic model) |  · noun |
| [mælk](https://en.wiktionary.org/wiki/m%C3%A6lk#Danish) | milk | /ˈmɛlˀɡ/ · noun |
| [spare](https://en.wiktionary.org/wiki/spare#Danish) | spare (the act of knocking down all remaining pins in second ball of a frame) | /spɛːr/ · noun |
| [villa](https://en.wiktionary.org/wiki/villa#Danish) | a villa (detached house with garden around, intended for living, often larger, individually built, older house) |  · noun |
| [national](https://en.wiktionary.org/wiki/national#Danish) | national, having to do with a particular country in opposition to other nations | [naɕoˈnæˀl] · adj |
| [relevant](https://en.wiktionary.org/wiki/relevant#Danish) | relevant |  · adj |
| [rod](https://en.wiktionary.org/wiki/rod#Danish) | root | [ˈʁoˀð] · noun |
| [sal](https://en.wiktionary.org/wiki/sal#Danish) | hall, room | [ˈsæˀl] · noun |
| [agent](https://en.wiktionary.org/wiki/agent#Danish) | agent (all senses) |  · noun |
| [chokolade](https://en.wiktionary.org/wiki/chokolade#Danish) | chocolate (food made from ground roasted cocoa beans; small piece of confectionery made from chocolate) | [sjokoˈlaːdə] · noun |
| [norsk](https://en.wiktionary.org/wiki/norsk#Danish) | Norwegian (of or relating to Norway, Norwegians or the Norwegian language) | /nɔrsk/ · adj |
| [pizza](https://en.wiktionary.org/wiki/pizza#Danish) | pizza | /pitsa/ · noun |
| [produkt](https://en.wiktionary.org/wiki/produkt#Danish) | product |  · noun |
| [ur](https://en.wiktionary.org/wiki/ur#Danish) | clock | [ˈuɐ̯ˀ] · noun |
| [bed](https://en.wiktionary.org/wiki/bed#Danish) | bed (a garden plot) | [ˈb̥eð] · noun |
| [central](https://en.wiktionary.org/wiki/central#Danish) | headquarters, place whence organizations are administrated |  · noun |
| [elev](https://en.wiktionary.org/wiki/elev#Danish) | pupil | /eleːv/ · noun |
| [matematik](https://en.wiktionary.org/wiki/matematik#Danish) | mathematics |  · noun |
| [motor](https://en.wiktionary.org/wiki/motor#Danish) | motor, engine | /moːtɔr/ · noun |
| [prins](https://en.wiktionary.org/wiki/prins#Danish) | prince (son or male-line grandson of a reigning monarch) | /prenˀs/ · noun |
| [prinsesse](https://en.wiktionary.org/wiki/prinsesse#Danish) | princess (a female member of the royal family, especially the daughter or daughter-in-law of a ruling monarch) | /prensɛsə/ · noun |
| [felt](https://en.wiktionary.org/wiki/felt#Danish) | field (the practical part of something) |  · noun |
| [not](https://en.wiktionary.org/wiki/not#Danish) | A groove. |  · noun |
| [næse](https://en.wiktionary.org/wiki/n%C3%A6se#Danish) | nose | [ˈnɛːsə] · noun |
| [old](https://en.wiktionary.org/wiki/old#Danish) | Classical Civilization (a course in secondary school) | /ɔlˀ/ · noun |
| [total](https://en.wiktionary.org/wiki/total#Danish) | total | /totaːl/ · adj |
| [cykel](https://en.wiktionary.org/wiki/cykel#Danish) | bicycle, bike | /sykəl/ · noun |
| [danse](https://en.wiktionary.org/wiki/danse#Danish) | to dance |  · verb |
| [debut](https://en.wiktionary.org/wiki/debut#Danish) | debut |  · noun |
| [farlig](https://en.wiktionary.org/wiki/farlig#Danish) | dangerous |  · adj |
| [pis](https://en.wiktionary.org/wiki/pis#Danish) | dammit |  · intj |
| [regn](https://en.wiktionary.org/wiki/regn#Danish) | rain | [ˈʁɑɪ̯ˀn] · noun |
| [roman](https://en.wiktionary.org/wiki/roman#Danish) | A novel (work of fiction). |  · noun |
| [drama](https://en.wiktionary.org/wiki/drama#Danish) | drama |  · noun |
| [front](https://en.wiktionary.org/wiki/front#Danish) | front |  · noun |
| [net](https://en.wiktionary.org/wiki/net#Danish) | visually pleasing and proper; well-groomed | /nɛt/ · adj |
| [note](https://en.wiktionary.org/wiki/note#Danish) | note |  · noun |
| [opmærksom](https://en.wiktionary.org/wiki/opm%C3%A6rksom#Danish) | alert, attentive, mindful, observant, observing, watchful | /ˈɔpˌmæɐ̯ɡsɒm/ · adj |

</details>

<details><summary>Words 551–600</summary>

![[Resources/Audio/da/Words 0551-0600.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [sind](https://en.wiktionary.org/wiki/sind#Danish) | mind | /ˈsen/ · noun |
| [arme](https://en.wiktionary.org/wiki/arme#Danish) | army | /armeː/ · noun |
| [danser](https://en.wiktionary.org/wiki/danser#Danish) | a dancer |  · noun |
| [hud](https://en.wiktionary.org/wiki/hud#Danish) | skin (outer covering of living tissue of a person) | /huːˀð/ · noun |
| [last](https://en.wiktionary.org/wiki/last#Danish) | cargo | /last/ · noun |
| [scene](https://en.wiktionary.org/wiki/scene#Danish) | stage (platform for performing in a theatre) | /seːnə/ · noun |
| [score](https://en.wiktionary.org/wiki/score#Danish) | A score, a number of points earned. | /skoːrə/ · noun |
| [so](https://en.wiktionary.org/wiki/so#Danish) | sow (female pig) |  · noun |
| [synge](https://en.wiktionary.org/wiki/synge#Danish) | sing (to produce harmonious sounds with one’s voice) | /ˈsønɡə/ · verb |
| [tradition](https://en.wiktionary.org/wiki/tradition#Danish) | tradition | /tradiˈsjoːn/ · noun |
| [kopi](https://en.wiktionary.org/wiki/kopi#Danish) | copy |  · noun |
| [band](https://en.wiktionary.org/wiki/band#Danish) | band | /baːnd/ · noun |
| [budget](https://en.wiktionary.org/wiki/budget#Danish) | budget | /byˈɕɛt/ · noun |
| [check](https://en.wiktionary.org/wiki/check#Danish) | cheque, check | [ˈɕɛɡ̊] · noun |
| [kant](https://en.wiktionary.org/wiki/kant#Danish) | edge, border |  · noun |
| [out](https://en.wiktionary.org/wiki/out#Danish) | unfashionable (out of fashion) |  · adj |
| [oven](https://en.wiktionary.org/wiki/oven#Danish) | above |  · adv |
| [sande](https://en.wiktionary.org/wiki/sande#Danish) | to sprinkle with sand; to strew (with) sand |  · verb |
| [sne](https://en.wiktionary.org/wiki/sne#Danish) | snow | /sneːˀ/ · noun |
| [as](https://en.wiktionary.org/wiki/as#Danish) | one of the Æsir |  · noun |
| [café](https://en.wiktionary.org/wiki/caf%C3%A9#Danish) | café |  · noun |
| [fund](https://en.wiktionary.org/wiki/fund#Danish) | find | [ˈfɔnˀ] · noun |
| [like](https://en.wiktionary.org/wiki/like#Danish) | like | [lɑjɡ̊] · noun |
| [liter](https://en.wiktionary.org/wiki/liter#Danish) | a litre |  · noun |
| [lund](https://en.wiktionary.org/wiki/lund#Danish) | grove | /lonˀ/ · noun |
| [permanent](https://en.wiktionary.org/wiki/permanent#Danish) | permanent | [pæɐ̯maˈnɛnˀd] · adj |
| [temperatur](https://en.wiktionary.org/wiki/temperatur#Danish) | temperature (all senses) |  · noun |
| [bund](https://en.wiktionary.org/wiki/bund#Danish) | bottom (the lowest part) | [ˈb̥ɔnˀ] · noun |
| [division](https://en.wiktionary.org/wiki/division#Danish) | league |  · noun |
| [karl](https://en.wiktionary.org/wiki/karl#Danish) | farmhand (a man working at a farm) | /kaːˀl/ · noun |
| [kylling](https://en.wiktionary.org/wiki/kylling#Danish) | chicken | /ˈkyleŋ/ · noun |
| [billet](https://en.wiktionary.org/wiki/billet#Danish) | ticket (admission to entertainment, pass for transportation) |  · noun |
| [daglig](https://en.wiktionary.org/wiki/daglig#Danish) | daily | /daɣli/ · adj |
| [drage](https://en.wiktionary.org/wiki/drage#Danish) | dragon (mythical creature) | [ˈd̥ʁɑːwə] · noun |
| [more](https://en.wiktionary.org/wiki/more#Danish) | To amuse, entertain | /ˈmoːʌ/ · verb |
| [race](https://en.wiktionary.org/wiki/race#Danish) | race (subdivision of species) | [ˈʁɑːsə] · noun |
| [salt](https://en.wiktionary.org/wiki/salt#Danish) | salty, salt | /salˀd/ · adj |
| [spring](https://en.wiktionary.org/wiki/spring#Danish) | spring, jump, vault, leap |  · noun |
| [tone](https://en.wiktionary.org/wiki/tone#Danish) | tone | /toːnə/ · noun |
| [ændring](https://en.wiktionary.org/wiki/%C3%A6ndring#Danish) | change | /ɛndreŋ/ · noun |
| [administration](https://en.wiktionary.org/wiki/administration#Danish) | administration |  · noun |
| [base](https://en.wiktionary.org/wiki/base#Danish) | base (generally understood to be a Brønsted-Lowry base) |  · noun |
| [offer](https://en.wiktionary.org/wiki/offer#Danish) | sacrifice |  · noun |
| [onkel](https://en.wiktionary.org/wiki/onkel#Danish) | uncle | /ˈonˀɡəl/ · noun |
| [ost](https://en.wiktionary.org/wiki/ost#Danish) | cheese | /ˈost/ · noun |
| [ånd](https://en.wiktionary.org/wiki/%C3%A5nd#Danish) | spirit, mind | /ɔn/ · noun |
| [øre](https://en.wiktionary.org/wiki/%C3%B8re#Danish) | ear (organ of hearing) | /øːrə/ · noun |
| [ar](https://en.wiktionary.org/wiki/ar#Danish) | scar | /ɑːr/ · noun |
| [arm](https://en.wiktionary.org/wiki/arm#Danish) | arm | /arm/ · noun |
| [bonus](https://en.wiktionary.org/wiki/bonus#Danish) | bonus (an extra sum given as a premium, e.g. to an employee or to a shareholder) | [ˈb̥oːnus] · noun |

</details>

<details><summary>Words 601–650</summary>

![[Resources/Audio/da/Words 0601-0650.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [boss](https://en.wiktionary.org/wiki/boss#Danish) | boss (leader of a company etc.) |  · noun |
| [gram](https://en.wiktionary.org/wiki/gram#Danish) | irate | /ɡram/ · adj |
| [nabo](https://en.wiktionary.org/wiki/nabo#Danish) | neighbour | /naːbo/ · noun |
| [nem](https://en.wiktionary.org/wiki/nem#Danish) | easy | /nɛm/ · adj |
| [svin](https://en.wiktionary.org/wiki/svin#Danish) | (member of family Suidae) hog, pig, swine | /sviːˀn/ · noun |
| [blind](https://en.wiktionary.org/wiki/blind#Danish) | blind |  · adj |
| [bronze](https://en.wiktionary.org/wiki/bronze#Danish) | bronze (element; colour) | [ˈb̥ʁʌŋsə] · noun |
| [ff.](https://en.wiktionary.org/wiki/ff.#Danish) | flere følgende (and the following pages) |  · phrase |
| [fotograf](https://en.wiktionary.org/wiki/fotograf#Danish) | photographer | [fod̥oˈɡ̊ʁɒːˀf] · noun |
| [humor](https://en.wiktionary.org/wiki/humor#Danish) | humour (amusement and the sense of amusement) | /huːmɔr/ · noun |
| [innovation](https://en.wiktionary.org/wiki/innovation#Danish) | innovation |  · noun |
| [signal](https://en.wiktionary.org/wiki/signal#Danish) | a signal | /siˈnæˀl/ · noun |
| [areal](https://en.wiktionary.org/wiki/areal#Danish) | area, space | /areaːl/ · noun |
| [basis](https://en.wiktionary.org/wiki/basis#Danish) | basis |  · noun |
| [femte](https://en.wiktionary.org/wiki/femte#Danish) | fifth | [ˈfɛmˀd̥ə] · num |
| [golf](https://en.wiktionary.org/wiki/golf#Danish) | golf (a game played with a golf club and golf ball) |  · noun |
| [gul](https://en.wiktionary.org/wiki/gul#Danish) | yellow | /ɡuːˀl/ · adj |
| [hals](https://en.wiktionary.org/wiki/hals#Danish) | throat | /hals/ · noun |
| [kalender](https://en.wiktionary.org/wiki/kalender#Danish) | calendar | /kaˈlɛnˀɐ/ · noun |
| [mega](https://en.wiktionary.org/wiki/mega#Danish) | very |  · adv |
| [pilot](https://en.wiktionary.org/wiki/pilot#Danish) | pilot |  · noun |
| [slot](https://en.wiktionary.org/wiki/slot#Danish) | castle, palace, manor house | [ˈslʌd̥] · noun |
| [spar](https://en.wiktionary.org/wiki/spar#Danish) | spade (One of the four suits of playing cards, marked with the symbol ♠) |  · noun |
| [stol](https://en.wiktionary.org/wiki/stol#Danish) | chair | /stoːl/ · noun |
| [website](https://en.wiktionary.org/wiki/website#Danish) | web site | [ˈwɛb̥ˌsɑjd̥] · noun |
| [ab](https://en.wiktionary.org/wiki/ab#Danish) | ex (out of, sold from) | /ab/ · prep |
| [elegant](https://en.wiktionary.org/wiki/elegant#Danish) | elegant, smart | /eləɡant/ · adj |
| [krone](https://en.wiktionary.org/wiki/krone#Danish) | crown (a royal or imperial headdress, and in a wider sense: the royal or imperial power) | [ˈkʰʁ̞oːnə] · noun |
| [mode](https://en.wiktionary.org/wiki/mode#Danish) | fashion | /moːdə/ · noun |
| [orange](https://en.wiktionary.org/wiki/orange#Danish) | orange (the taste of an orange) | [oˈʁɑŋɕə] · noun |
| [rabat](https://en.wiktionary.org/wiki/rabat#Danish) | discount | /ʁaˈpæt/ · noun |
| [skarp](https://en.wiktionary.org/wiki/skarp#Danish) | sharp |  · adj |
| [storm](https://en.wiktionary.org/wiki/storm#Danish) | storm |  · noun |
| [ton](https://en.wiktionary.org/wiki/ton#Danish) | tonne, metric ton (unit of weight, equivalent to 1000 kilograms) | /tʌn/ · noun |
| [virus](https://en.wiktionary.org/wiki/virus#Danish) | virus |  · noun |
| [vrede](https://en.wiktionary.org/wiki/vrede#Danish) | anger, wrath | /vreːdə/ · noun |
| [alarm](https://en.wiktionary.org/wiki/alarm#Danish) | alarm |  · noun |
| [amok](https://en.wiktionary.org/wiki/amok#Danish) | Out of control, especially when armed and dangerous. |  · adj |
| [angst](https://en.wiktionary.org/wiki/angst#Danish) | afraid, anxious, alarmed |  · adj |
| [gymnasium](https://en.wiktionary.org/wiki/gymnasium#Danish) | gymnasium (a type of secondary school) | /ɡymnaːsjɔm/ · noun |
| [had](https://en.wiktionary.org/wiki/had#Danish) | hate, hatred |  · noun |
| [assistent](https://en.wiktionary.org/wiki/assistent#Danish) | assistant |  · noun |
| [bold](https://en.wiktionary.org/wiki/bold#Danish) | ball | [ˈb̥ʌlˀd̥] · noun |
| [from](https://en.wiktionary.org/wiki/from#Danish) | pious, devout (religious in a serious way) | /frɔmˀ/ · adj |
| [fødsel](https://en.wiktionary.org/wiki/f%C3%B8dsel#Danish) | birth | /føsəl/ · noun |
| [grave](https://en.wiktionary.org/wiki/grave#Danish) | dig (to move hard-packed earth out of the way) | /ɡraːʋə/ · verb |
| [holm](https://en.wiktionary.org/wiki/holm#Danish) | a small island |  · noun |
| [lager](https://en.wiktionary.org/wiki/lager#Danish) | store, warehouse | /ˈlaːˀɣər/ · noun |
| [pop](https://en.wiktionary.org/wiki/pop#Danish) | pop music |  · noun |
| [royal](https://en.wiktionary.org/wiki/royal#Danish) | Of or relating to a monarch or his (or her) family. | [ʁʌˈjæˀl] · adj |

</details>

<details><summary>Words 651–700</summary>

![[Resources/Audio/da/Words 0651-0700.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [das](https://en.wiktionary.org/wiki/das#Danish) | privy, outhouse |  · noun |
| [landsby](https://en.wiktionary.org/wiki/landsby#Danish) | village | /lansbyː/ · noun |
| [nul](https://en.wiktionary.org/wiki/nul#Danish) | zero (the cardinal number occurring before one and that denotes no quantity or amount at all, represented in Arabic numerals as 0) | /ˈnol/ · num |
| [teste](https://en.wiktionary.org/wiki/teste#Danish) | to test, examine | /ˈtɛsdə/ · verb |
| [vært](https://en.wiktionary.org/wiki/v%C3%A6rt#Danish) | host (person who allows a guest) | [ˈʋaɐ̯d̥] · noun |
| [frue](https://en.wiktionary.org/wiki/frue#Danish) | wife | /fruːə/ · noun |
| [grim](https://en.wiktionary.org/wiki/grim#Danish) | ugly, unsightly | [ɡ̊ʁɛmˀ] · adj |
| [luk](https://en.wiktionary.org/wiki/luk#Danish) | shut it!, stop talking |  · verb |
| [male](https://en.wiktionary.org/wiki/male#Danish) | to paint | /ˈmaːlə/ · verb |
| [sorg](https://en.wiktionary.org/wiki/sorg#Danish) | sorrow, grief | /sɔrˀɣ/ · noun |
| [euro](https://en.wiktionary.org/wiki/euro#Danish) | euro (currency) | /øvro/ · noun |
| [mus](https://en.wiktionary.org/wiki/mus#Danish) | mouse (animal) | /muːˀs/ · noun |
| [planet](https://en.wiktionary.org/wiki/planet#Danish) | a planet |  · noun |
| [præstation](https://en.wiktionary.org/wiki/pr%C3%A6station#Danish) | performance |  · noun |
| [union](https://en.wiktionary.org/wiki/union#Danish) | union | /uniˈoˀn/ · noun |
| [balance](https://en.wiktionary.org/wiki/balance#Danish) | balance |  · noun |
| [brun](https://en.wiktionary.org/wiki/brun#Danish) | brown (color/colour) | /bʁuːˀn/ · adj |
| [die](https://en.wiktionary.org/wiki/die#Danish) | breast milk, mother's milk, when sucked from the breast | /diːə/ · noun |
| [dollar](https://en.wiktionary.org/wiki/dollar#Danish) | a dollar (monetary unit) |  · noun |
| [element](https://en.wiktionary.org/wiki/element#Danish) | element |  · noun |
| [football](https://en.wiktionary.org/wiki/football#Danish) | American football |  · noun |
| [hat](https://en.wiktionary.org/wiki/hat#Danish) | hat | /had/ · noun |
| [moder](https://en.wiktionary.org/wiki/moder#Danish) | mother |  · noun |
| [original](https://en.wiktionary.org/wiki/original#Danish) | original |  · adj |
| [patient](https://en.wiktionary.org/wiki/patient#Danish) | patient (person or animal who receives treatment from a doctor or other medically educated person) | [pʰaˈɕɛnˀd̥] · noun |
| [tempo](https://en.wiktionary.org/wiki/tempo#Danish) | pace | /tɛmpo/ · noun |
| [true](https://en.wiktionary.org/wiki/true#Danish) | to threaten | /truːə/ · verb |
| [drab](https://en.wiktionary.org/wiki/drab#Danish) | homicide |  · noun |
| [fort](https://en.wiktionary.org/wiki/fort#Danish) | fort |  · noun |
| [solid](https://en.wiktionary.org/wiki/solid#Danish) | solid, robust |  · adj |
| [institution](https://en.wiktionary.org/wiki/institution#Danish) | institution |  · noun |
| [maler](https://en.wiktionary.org/wiki/maler#Danish) | painter (artist) | /maːlər/ · noun |
| [pink](https://en.wiktionary.org/wiki/pink#Danish) | pink |  · adj |
| [porno](https://en.wiktionary.org/wiki/porno#Danish) | short form of pornografi (“pornography”) | /pɔrno/ · noun |
| [tennis](https://en.wiktionary.org/wiki/tennis#Danish) | tennis |  · noun |
| [Sankt](https://en.wiktionary.org/wiki/Sankt#Danish) | Saint: title given to a saint. |  · adj |
| [benzin](https://en.wiktionary.org/wiki/benzin#Danish) | gasoline, petrol |  · noun |
| [jern](https://en.wiktionary.org/wiki/jern#Danish) | iron (metallic chemical element having atomic number 26, and symbol Fe) | [ˈjɛɐ̯ˀn] · noun |
| [las](https://en.wiktionary.org/wiki/las#Danish) | rag |  · noun |
| [lo](https://en.wiktionary.org/wiki/lo#Danish) | a barn or large room in a barn where grain is threshed |  · noun |
| [lyse](https://en.wiktionary.org/wiki/lyse#Danish) | to shine | /lyːsə/ · verb |
| [port](https://en.wiktionary.org/wiki/port#Danish) | gate | /ˈpoːˀrt/ · noun |
| [pose](https://en.wiktionary.org/wiki/pose#Danish) | bag | [ˈpʰoːsə] · noun |
| [symbol](https://en.wiktionary.org/wiki/symbol#Danish) | symbol | /symboːl/ · noun |
| [tung](https://en.wiktionary.org/wiki/tung#Danish) | heavy | [ˈtˢɔŋˀ] · adj |
| [reel](https://en.wiktionary.org/wiki/reel#Danish) | real, proper | /rɛɛl/ · adj |
| [tolv](https://en.wiktionary.org/wiki/tolv#Danish) | twelve | [ˈtˢʌlˀ] · num |
| [eje](https://en.wiktionary.org/wiki/eje#Danish) | own | [ˈɑjə] · verb |
| [elite](https://en.wiktionary.org/wiki/elite#Danish) | elite |  · noun |
| [finger](https://en.wiktionary.org/wiki/finger#Danish) | finger | /fenɡər/ · noun |

</details>

<details><summary>Words 701–750</summary>

![[Resources/Audio/da/Words 0701-0750.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [hop](https://en.wiktionary.org/wiki/hop#Danish) | jump | /hɔp/ · noun |
| [joke](https://en.wiktionary.org/wiki/joke#Danish) | joke | [ˈd̥jɔwɡ̊] · noun |
| [ko](https://en.wiktionary.org/wiki/ko#Danish) | cow | /koːˀ/ · noun |
| [magi](https://en.wiktionary.org/wiki/magi#Danish) | magic |  · noun |
| [penis](https://en.wiktionary.org/wiki/penis#Danish) | penis |  · noun |
| [rosa](https://en.wiktionary.org/wiki/rosa#Danish) | rose-coloured, rose |  · adj |
| [sans](https://en.wiktionary.org/wiki/sans#Danish) | sense |  · noun |
| [zone](https://en.wiktionary.org/wiki/zone#Danish) | zone | /soːnɘ/ · noun |
| [bio](https://en.wiktionary.org/wiki/bio#Danish) | cinema |  · noun |
| [dam](https://en.wiktionary.org/wiki/dam#Danish) | pond |  · noun |
| [des](https://en.wiktionary.org/wiki/des#Danish) | the |  · conj |
| [himmel](https://en.wiktionary.org/wiki/himmel#Danish) | sky | /heməl/ · noun |
| [hjul](https://en.wiktionary.org/wiki/hjul#Danish) | wheel | [juːˀl] · noun |
| [tegning](https://en.wiktionary.org/wiki/tegning#Danish) | drawing |  · noun |
| [CV](https://en.wiktionary.org/wiki/CV#Danish) | resumé, curriculum vitae |  · noun |
| [bi](https://en.wiktionary.org/wiki/bi#Danish) | bee | [ˈb̥iˀ] · noun |
| [boks](https://en.wiktionary.org/wiki/boks#Danish) | box, case, container |  · noun |
| [event](https://en.wiktionary.org/wiki/event#Danish) | An event, a prearranged social activity (function, etc.). | /ɛˈvɛnt/ · noun |
| [motion](https://en.wiktionary.org/wiki/motion#Danish) | exercise (physical activity intended to improve strength and fitness) | /mosjoːn/ · noun |
| [si](https://en.wiktionary.org/wiki/si#Danish) | sieve | /siː/ · noun |
| [simpel](https://en.wiktionary.org/wiki/simpel#Danish) | simple; trivial |  · adj |
| [sky](https://en.wiktionary.org/wiki/sky#Danish) | shy | [ˈskyˀ] · adj |
| [the shit](https://en.wiktionary.org/wiki/the%20shit#Danish) | the shit |  · noun |
| [toilet](https://en.wiktionary.org/wiki/toilet#Danish) | toilet, bathroom (room containing a lavatory) | /toalɛt/ · noun |
| [alliance](https://en.wiktionary.org/wiki/alliance#Danish) | an alliance |  · noun |
| [blad](https://en.wiktionary.org/wiki/blad#Danish) | leaf | /blad/ · noun |
| [brune](https://en.wiktionary.org/wiki/brune#Danish) | to brown |  · verb |
| [døgn](https://en.wiktionary.org/wiki/d%C3%B8gn#Danish) | day - the 24 hour period stretching from midnight to midnight. | /døjn/ · noun |
| [ho](https://en.wiktionary.org/wiki/ho#Danish) | Signifies a hearty laugh. |  · intj |
| [opdage](https://en.wiktionary.org/wiki/opdage#Danish) | to discover, detect |  · verb |
| [yoga](https://en.wiktionary.org/wiki/yoga#Danish) | yoga | [ˈjoːɡ̊a] · noun |
| [arrangement](https://en.wiktionary.org/wiki/arrangement#Danish) | arrangement | [ɑɑŋɕəˈmɑŋ] · noun |
| [hal](https://en.wiktionary.org/wiki/hal#Danish) | hall | /hal/ · noun |
| [juice](https://en.wiktionary.org/wiki/juice#Danish) | juice | [ˈd̥juːs] · noun |
| [klippe](https://en.wiktionary.org/wiki/klippe#Danish) | bedrock, rock; large, contiguous body of immobile stone |  · noun |
| [ledig](https://en.wiktionary.org/wiki/ledig#Danish) | unoccupied | /ˈleːð̞i/ · adj |
| [ligne](https://en.wiktionary.org/wiki/ligne#Danish) | resemble, look like | [ˈliːnə] · verb |
| [mel](https://en.wiktionary.org/wiki/mel#Danish) | flour |  · noun |
| [basketball](https://en.wiktionary.org/wiki/basketball#Danish) | basketball | /baːskətbaːl/ · noun |
| [bombe](https://en.wiktionary.org/wiki/bombe#Danish) | bomb | /bombə/ · noun |
| [feber](https://en.wiktionary.org/wiki/feber#Danish) | fever | [ˈfeˀb̥ɐ] · noun |
| [hallo](https://en.wiktionary.org/wiki/hallo#Danish) | hello (a greeting usually used to answer the telephone) | /halɔ/ · intj |
| [hang](https://en.wiktionary.org/wiki/hang#Danish) | inclination or disposition towards something | [ˈhɑŋˀ] · noun |
| [he](https://en.wiktionary.org/wiki/he#Danish) | Signifies a laugh, especially one that is slightly mischievous. |  · intj |
| [japansk](https://en.wiktionary.org/wiki/japansk#Danish) | Japanese (of or relating to Japan or its people or language) | /japaːnsk/ · adj |
| [minimum](https://en.wiktionary.org/wiki/minimum#Danish) | minimum |  · noun |
| [rede](https://en.wiktionary.org/wiki/rede#Danish) | nest (bird-built structure) | /reːðə/ · noun |
| [skala](https://en.wiktionary.org/wiki/skala#Danish) | a scale |  · noun |
| [smut](https://en.wiktionary.org/wiki/smut#Danish) | a quick or spontaneous trip, visit, stay or errand etc. | [ˈsmud] · noun |
| [univers](https://en.wiktionary.org/wiki/univers#Danish) | universe | /univɛrs/ · noun |

</details>

<details><summary>Words 751–800</summary>

![[Resources/Audio/da/Words 0751-0800.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [viking](https://en.wiktionary.org/wiki/viking#Danish) | Viking | [ˈvikeŋ] · noun |
| [yo](https://en.wiktionary.org/wiki/yo#Danish) | yo |  · intj |
| [BNP](https://en.wiktionary.org/wiki/BNP#Danish) | bruttonationalprodukt (GNP) |  · noun |
| [centimeter](https://en.wiktionary.org/wiki/centimeter#Danish) | centimetre, or centimeter (US) (SI unit of length) |  · noun |
| [fjord](https://en.wiktionary.org/wiki/fjord#Danish) | firth, fjord, inlet | [ˈfjoɐ̯ˀ] · noun |
| [gods](https://en.wiktionary.org/wiki/gods#Danish) | goods, freight, stores | /ˈɡos/ · noun |
| [intelligent](https://en.wiktionary.org/wiki/intelligent#Danish) | intelligent | /enteliɡɛnt/ · adj |
| [ordbog](https://en.wiktionary.org/wiki/ordbog#Danish) | dictionary, lexicon (a reference work with a compilation of words from a language or type of language with explanations or translations) | /orbɔːˀɣ/ · noun |
| [protest](https://en.wiktionary.org/wiki/protest#Danish) | protest |  · noun |
| [satan](https://en.wiktionary.org/wiki/satan#Danish) | a bastard; a sly, wicked, vicious person |  · noun |
| [anker](https://en.wiktionary.org/wiki/anker#Danish) | anchor |  · noun |
| [hall](https://en.wiktionary.org/wiki/hall#Danish) | hall (a corridor or a hallway) | [hɒːl] · noun |
| [nøgle](https://en.wiktionary.org/wiki/n%C3%B8gle#Danish) | key | /ˈnɔɣlə/ · noun |
| [rap](https://en.wiktionary.org/wiki/rap#Danish) | quack (imitating the sound of a duck) |  · intj |
| [relation](https://en.wiktionary.org/wiki/relation#Danish) | relation |  · noun |
| [sen](https://en.wiktionary.org/wiki/sen#Danish) | late (proximate in time) | [ˈseˀn] · adj |
| [badminton](https://en.wiktionary.org/wiki/badminton#Danish) | badminton | /badməntɔn/ · noun |
| [ballet](https://en.wiktionary.org/wiki/ballet#Danish) | ballet | /balɛt/ · noun |
| [bid](https://en.wiktionary.org/wiki/bid#Danish) | bite, biting | [ˈb̥ið] · noun |
| [guitar](https://en.wiktionary.org/wiki/guitar#Danish) | guitar | /ɡitar/ · noun |
| [ler](https://en.wiktionary.org/wiki/ler#Danish) | clay | /leːˀr/ · noun |
| [ond](https://en.wiktionary.org/wiki/ond#Danish) | evil | [ˈɔnˀ] · adj |
| [pil](https://en.wiktionary.org/wiki/pil#Danish) | arrow | /piːl/ · noun |
| [ride](https://en.wiktionary.org/wiki/ride#Danish) | black-legged kittiwake (Rissa tridactyla) | /riːðə/ · noun |
| [shop](https://en.wiktionary.org/wiki/shop#Danish) | shop (Smaller store with a special or exquisite product range in e.g. fashion, clothing, cosmetics or gift items) |  · noun |
| [terror](https://en.wiktionary.org/wiki/terror#Danish) | terror | [ˈtæɐ̯ʌ] · noun |
| [tunnel](https://en.wiktionary.org/wiki/tunnel#Danish) | tunnel |  · noun |
| [vid](https://en.wiktionary.org/wiki/vid#Danish) | wide | [ˈʋiˀð] · adj |
| [fond](https://en.wiktionary.org/wiki/fond#Danish) | fund | [ˈfʌnˀd̥] · noun |
| [fugl](https://en.wiktionary.org/wiki/fugl#Danish) | bird | /fuːˀl/ · noun |
| [gris](https://en.wiktionary.org/wiki/gris#Danish) | pig (a mammal of the family Suidae) | /ɡriːˀs/ · noun |
| [hale](https://en.wiktionary.org/wiki/hale#Danish) | tail, brush, scut | /haːlə/ · noun |
| [nevø](https://en.wiktionary.org/wiki/nev%C3%B8#Danish) | nephew (son of one's sister or brother, or son of the brother or sister of one's spouse) | /nevø/ · noun |
| [porto](https://en.wiktionary.org/wiki/porto#Danish) | postage; payment for sending a letter or package |  · noun |
| [revolution](https://en.wiktionary.org/wiki/revolution#Danish) | revolution (political upheaval) | /rɛvolusjoːn/ · noun |
| [sofa](https://en.wiktionary.org/wiki/sofa#Danish) | sofa, couch, divan, settee |  · noun |
| [database](https://en.wiktionary.org/wiki/database#Danish) | database | /daːtabaːsə/ · noun |
| [engel](https://en.wiktionary.org/wiki/engel#Danish) | angel | [ˈɛŋəl] · noun |
| [enkel](https://en.wiktionary.org/wiki/enkel#Danish) | single, singular |  · adj |
| [hive](https://en.wiktionary.org/wiki/hive#Danish) | to pull, heave, tow |  · verb |
| [tank](https://en.wiktionary.org/wiki/tank#Danish) | tank (for storage) | /tanˀk/ · noun |
| [zoo](https://en.wiktionary.org/wiki/zoo#Danish) | a zoo, zoological garden |  · noun |
| [bær](https://en.wiktionary.org/wiki/b%C3%A6r#Danish) | berry | /bɛr/ · noun |
| [frost](https://en.wiktionary.org/wiki/frost#Danish) | frost | /frɔst/ · noun |
| [hade](https://en.wiktionary.org/wiki/hade#Danish) | to hate | /haːdə/ · verb |
| [hammer](https://en.wiktionary.org/wiki/hammer#Danish) | hammer | /hamər/ · noun |
| [korn](https://en.wiktionary.org/wiki/korn#Danish) | corn, cereal | /korn/ · noun |
| [redder](https://en.wiktionary.org/wiki/redder#Danish) | a rescuer |  · noun |
| [robot](https://en.wiktionary.org/wiki/robot#Danish) | robot | [ʁoˈbʌd] · noun |
| [tiger](https://en.wiktionary.org/wiki/tiger#Danish) | tiger | /ˈtiːər/ · noun |

</details>

<details><summary>Words 801–850</summary>

![[Resources/Audio/da/Words 0801-0850.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [chili](https://en.wiktionary.org/wiki/chili#Danish) | chili |  · noun |
| [cirkel](https://en.wiktionary.org/wiki/cirkel#Danish) | circle |  · noun |
| [fantasy](https://en.wiktionary.org/wiki/fantasy#Danish) | fantasy (literary genre) |  · noun |
| [gran](https://en.wiktionary.org/wiki/gran#Danish) | spruce (Picea) | [ˈɡʁɑn] · noun |
| [haver](https://en.wiktionary.org/wiki/haver#Danish) | a person who possesses or is in possession of something |  · noun |
| [mil](https://en.wiktionary.org/wiki/mil#Danish) | mile, unit of length of varying value |  · noun |
| [skæg](https://en.wiktionary.org/wiki/sk%C3%A6g#Danish) | fun, funny | /skɛːɡ/ · adj |
| [celle](https://en.wiktionary.org/wiki/celle#Danish) | cell |  · noun |
| [genial](https://en.wiktionary.org/wiki/genial#Danish) | ingenious, brilliant |  · adj |
| [given](https://en.wiktionary.org/wiki/given#Danish) | certain | [ˈɡ̊iːʋən] · adj |
| [journal](https://en.wiktionary.org/wiki/journal#Danish) | journal (daily record) |  · noun |
| [reform](https://en.wiktionary.org/wiki/reform#Danish) | reform | /reˈfɔrm/ · noun |
| [rektor](https://en.wiktionary.org/wiki/rektor#Danish) | headmaster or headmistress, head teacher (gender-neutral), principal (of a school or college) | /rɛktɔr/ · noun |
| [rev](https://en.wiktionary.org/wiki/rev#Danish) | reef (ridge of rock or coral in the sea) | /rev/ · noun |
| [depression](https://en.wiktionary.org/wiki/depression#Danish) | depression |  · noun |
| [engagement](https://en.wiktionary.org/wiki/engagement#Danish) | involvement, participation |  · noun |
| [fe](https://en.wiktionary.org/wiki/fe#Danish) | fairy, fay (mythical being (of female gender)) |  · noun |
| [fil](https://en.wiktionary.org/wiki/fil#Danish) | file (tool) | /fiːl/ · noun |
| [gold](https://en.wiktionary.org/wiki/gold#Danish) | barren, desolate | /ɡɔl/ · adj |
| [kid](https://en.wiktionary.org/wiki/kid#Danish) | A young goat. |  · noun |
| [nation](https://en.wiktionary.org/wiki/nation#Danish) | a nation, a people with a common identity, united in history, culture or language | [naˈɕoˀn] · noun |
| [ski](https://en.wiktionary.org/wiki/ski#Danish) | ski |  · noun |
| [sy](https://en.wiktionary.org/wiki/sy#Danish) | sew | /syː/ · verb |
| [teenager](https://en.wiktionary.org/wiki/teenager#Danish) | teenager |  · noun |
| [ane](https://en.wiktionary.org/wiki/ane#Danish) | forefather |  · noun |
| [country](https://en.wiktionary.org/wiki/country#Danish) | country, country music |  · noun |
| [dale](https://en.wiktionary.org/wiki/dale#Danish) | fall | /daːlə/ · verb |
| [ego](https://en.wiktionary.org/wiki/ego#Danish) | ego, self | [ˈeːɡo] · noun |
| [invitation](https://en.wiktionary.org/wiki/invitation#Danish) | invitation |  · noun |
| [moral](https://en.wiktionary.org/wiki/moral#Danish) | morale, motivation (capacity to maintain belief in an institution or a goal) |  · noun |
| [variation](https://en.wiktionary.org/wiki/variation#Danish) | variation |  · noun |
| [dessert](https://en.wiktionary.org/wiki/dessert#Danish) | dessert |  · noun |
| [diameter](https://en.wiktionary.org/wiki/diameter#Danish) | a diameter |  · noun |
| [eg](https://en.wiktionary.org/wiki/eg#Danish) | oak, oak tree (tree or wood) | /eːɡ/ · noun |
| [fryser](https://en.wiktionary.org/wiki/fryser#Danish) | freezer (part of refrigerator) | /fryːsər/ · noun |
| [lam](https://en.wiktionary.org/wiki/lam#Danish) | lame | /lam/ · adj |
| [opdagelse](https://en.wiktionary.org/wiki/opdagelse#Danish) | A discovery. |  · noun |
| [patent](https://en.wiktionary.org/wiki/patent#Danish) | patent |  · noun |
| [pistol](https://en.wiktionary.org/wiki/pistol#Danish) | handgun, pistol | /pistoːl/ · noun |
| [vane](https://en.wiktionary.org/wiki/vane#Danish) | habit | /vaːnə/ · noun |
| [genre](https://en.wiktionary.org/wiki/genre#Danish) | genre, a special type of literature, music or art with its own defining features | [ˈɕɑŋʁɐ] · noun |
| [hip](https://en.wiktionary.org/wiki/hip#Danish) | modern, in, fashionable, trendy |  · adj |
| [horn](https://en.wiktionary.org/wiki/horn#Danish) | horn | /hoɐ̯ˀn/ · noun |
| [jazz](https://en.wiktionary.org/wiki/jazz#Danish) | jazz (form of music) |  · noun |
| [latin](https://en.wiktionary.org/wiki/latin#Danish) | the Latin language | [laˈtˢiˀn] · noun |
| [mat](https://en.wiktionary.org/wiki/mat#Danish) | dull, not shiny |  · adj |
| [rode](https://en.wiktionary.org/wiki/rode#Danish) | file | /roːdə/ · noun |
| [slave](https://en.wiktionary.org/wiki/slave#Danish) | slave |  · noun |
| [tester](https://en.wiktionary.org/wiki/tester#Danish) | a tester; someone who tests |  · noun |
| [vers](https://en.wiktionary.org/wiki/vers#Danish) | verse (in songs) |  · noun |

</details>

<details><summary>Words 851–900</summary>

![[Resources/Audio/da/Words 0851-0900.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [kast](https://en.wiktionary.org/wiki/kast#Danish) | throw |  · noun |
| [mobiltelefon](https://en.wiktionary.org/wiki/mobiltelefon#Danish) | cell phone, mobile phone |  · noun |
| [smile](https://en.wiktionary.org/wiki/smile#Danish) | to smile | /smiːlø/ · verb |
| [fundament](https://en.wiktionary.org/wiki/fundament#Danish) | foundation (of a house etc.) |  · noun |
| [hi](https://en.wiktionary.org/wiki/hi#Danish) | winter quarters, winter lair (for hibernation); hibernation (used literally or figuratively) |  · noun |
| [kost](https://en.wiktionary.org/wiki/kost#Danish) | food (any substance consumed by living organisms to sustain life) | [ˈkʰʌsd̥] · noun |
| [lind](https://en.wiktionary.org/wiki/lind#Danish) | soft |  · adj |
| [loft](https://en.wiktionary.org/wiki/loft#Danish) | attic, room immediately below the roof of a building | [ˈlʌfd] · noun |
| [lyn](https://en.wiktionary.org/wiki/lyn#Danish) | lightning | /lyːn/ · noun |
| [eksperiment](https://en.wiktionary.org/wiki/eksperiment#Danish) | an experiment |  · noun |
| [flod](https://en.wiktionary.org/wiki/flod#Danish) | river | /ˈfloːð/ · noun |
| [gen](https://en.wiktionary.org/wiki/gen#Danish) | gene |  · noun |
| [kok](https://en.wiktionary.org/wiki/kok#Danish) | cook, chef | /kɔɡ/ · noun |
| [protein](https://en.wiktionary.org/wiki/protein#Danish) | protein | /ˈpʁotəˈiˀn/ · noun |
| [rune](https://en.wiktionary.org/wiki/rune#Danish) | rune |  · noun |
| [sult](https://en.wiktionary.org/wiki/sult#Danish) | hunger (need for food) |  · noun |
| [told](https://en.wiktionary.org/wiki/told#Danish) | duty, tariff (tax placed on imports or exports) | /tɔl/ · noun |
| [burger](https://en.wiktionary.org/wiki/burger#Danish) | burger |  · noun |
| [chips](https://en.wiktionary.org/wiki/chips#Danish) | potato chips, crisps | [ˈtɕib̥s] · noun |
| [import](https://en.wiktionary.org/wiki/import#Danish) | import |  · noun |
| [jura](https://en.wiktionary.org/wiki/jura#Danish) | law (the practice and profession of law) | /juːra/ · noun |
| [sushi](https://en.wiktionary.org/wiki/sushi#Danish) | sushi |  · noun |
| [telefonnummer](https://en.wiktionary.org/wiki/telefonnummer#Danish) | telephone number |  · noun |
| [argument](https://en.wiktionary.org/wiki/argument#Danish) | argument |  · noun |
| [ask](https://en.wiktionary.org/wiki/ask#Danish) | ash tree (Fraxinus spp.), especially, common ash (tree, Fraxinus excelsior) | /ask/ · noun |
| [bande](https://en.wiktionary.org/wiki/bande#Danish) | gang (a group of people united for the purpose of crime or vandalism) | /bandə/ · noun |
| [loyal](https://en.wiktionary.org/wiki/loyal#Danish) | loyal | /løjaːl/ · adj |
| [mos](https://en.wiktionary.org/wiki/mos#Danish) | mash, puree | /moːs/ · noun |
| [ram](https://en.wiktionary.org/wiki/ram#Danish) | acrid, rancid |  · adj |
| [sandwich](https://en.wiktionary.org/wiki/sandwich#Danish) | sandwich | /sanvitsj/ · noun |
| [ambulance](https://en.wiktionary.org/wiki/ambulance#Danish) | ambulance (emergency vehicle) | /ɑm.buˈlɑŋ.sə/ · noun |
| [bitter](https://en.wiktionary.org/wiki/bitter#Danish) | bitter (all meanings) |  · adj |
| [comeback](https://en.wiktionary.org/wiki/comeback#Danish) | comeback (after an absence) | [kʌmˈbaɡ] · noun |
| [hash](https://en.wiktionary.org/wiki/hash#Danish) | hash, hashish Not used anymore to denote dried herbs. | /hasj/ · noun |
| [marina](https://en.wiktionary.org/wiki/marina#Danish) | marina |  · noun |
| [maske](https://en.wiktionary.org/wiki/maske#Danish) | mask | /maskə/ · noun |
| [rest](https://en.wiktionary.org/wiki/rest#Danish) | remnant, remainder, rest | [ˈʁasd̥] · noun |
| [rive](https://en.wiktionary.org/wiki/rive#Danish) | rake | /riːvə/ · noun |
| [slange](https://en.wiktionary.org/wiki/slange#Danish) | snake, serpent | [ˈslɑŋə] · noun |
| [spark](https://en.wiktionary.org/wiki/spark#Danish) | kick | /spark/ · noun |
| [spore](https://en.wiktionary.org/wiki/spore#Danish) | spore (reproductive particle) | /spoːrə/ · noun |
| [variant](https://en.wiktionary.org/wiki/variant#Danish) | variant | [vɑiˈanˀd] · noun |
| [amerikaner](https://en.wiktionary.org/wiki/amerikaner#Danish) | American (a person from USA) | /amɛrikaːˀnər/ · noun |
| [anonym](https://en.wiktionary.org/wiki/anonym#Danish) | anonymous |  · adj |
| [es](https://en.wiktionary.org/wiki/es#Danish) | ace |  · noun |
| [pen](https://en.wiktionary.org/wiki/pen#Danish) | pen | /pɛnˀ/ · noun |
| [sild](https://en.wiktionary.org/wiki/sild#Danish) | herring | [ˈsilˀ] · noun |
| [spot](https://en.wiktionary.org/wiki/spot#Danish) | mockery, ridicule | [ˈsb̥ʌd̥] · noun |
| [tante](https://en.wiktionary.org/wiki/tante#Danish) | aunt | /ˈtandə/ · noun |
| [apropos](https://en.wiktionary.org/wiki/apropos#Danish) | aside | /apropo/ · noun |

</details>

<details><summary>Words 901–950</summary>

![[Resources/Audio/da/Words 0901-0950.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [delta](https://en.wiktionary.org/wiki/delta#Danish) | a river delta |  · noun |
| [demonstration](https://en.wiktionary.org/wiki/demonstration#Danish) | demonstration | /ˌdemʌnsdʁɑˈɕoˀn/ · noun |
| [logik](https://en.wiktionary.org/wiki/logik#Danish) | logic |  · noun |
| [plast](https://en.wiktionary.org/wiki/plast#Danish) | plastic | [ˈplasd] · noun |
| [tand](https://en.wiktionary.org/wiki/tand#Danish) | tooth | /tan/ · noun |
| [ve](https://en.wiktionary.org/wiki/ve#Danish) | pain | /veːˀ/ · noun |
| [vend](https://en.wiktionary.org/wiki/vend#Danish) | a quick trip, run, visit | /vɛn/ · noun |
| [baseball](https://en.wiktionary.org/wiki/baseball#Danish) | baseball (ball game) |  · noun |
| [dagblad](https://en.wiktionary.org/wiki/dagblad#Danish) | daily newspaper |  · noun |
| [drink](https://en.wiktionary.org/wiki/drink#Danish) | drink; a (mixed) alcoholic beverage |  · noun |
| [hug](https://en.wiktionary.org/wiki/hug#Danish) | stroke | /hoɡ/ · noun |
| [kaj](https://en.wiktionary.org/wiki/kaj#Danish) | quay, pier, dock, wharf |  · noun |
| [ocean](https://en.wiktionary.org/wiki/ocean#Danish) | ocean |  · noun |
| [senator](https://en.wiktionary.org/wiki/senator#Danish) | senator |  · noun |
| [separat](https://en.wiktionary.org/wiki/separat#Danish) | separate |  · adj |
| [sum](https://en.wiktionary.org/wiki/sum#Danish) | a sum (addition or aggregation) |  · noun |
| [bureau](https://en.wiktionary.org/wiki/bureau#Danish) | bureau | /byˈʁo/ · noun |
| [mis](https://en.wiktionary.org/wiki/mis#Danish) | kitty, puss, pussy, pussycat (see Thesaurus:cat) | /mis/ · noun |
| [poker](https://en.wiktionary.org/wiki/poker#Danish) | poker | [ˈpoˀɡʌ] · noun |
| [bod](https://en.wiktionary.org/wiki/bod#Danish) | booth, stall | /boːˀð/ · noun |
| [doktor](https://en.wiktionary.org/wiki/doktor#Danish) | doctor (a physician) | /ˈdɔɡdɐ/ · noun |
| [genere](https://en.wiktionary.org/wiki/genere#Danish) | to bother, trouble, disturb, annoy (to be an annoyance) | /sjeneːˀrə/ · verb |
| [trang](https://en.wiktionary.org/wiki/trang#Danish) | tight, narrow |  · adj |
| [ty](https://en.wiktionary.org/wiki/ty#Danish) | to turn to, resort to | [ˈtˢyˀ] · verb |
| [ark](https://en.wiktionary.org/wiki/ark#Danish) | a sheet (of paper) | [ˈɑːɡ̊] · noun |
| [bur](https://en.wiktionary.org/wiki/bur#Danish) | cage | /buːr/ · noun |
| [gene](https://en.wiktionary.org/wiki/gene#Danish) | inconvenience, nuisance (something that bothers) | /sjeːnə/ · noun |
| [made](https://en.wiktionary.org/wiki/made#Danish) | feed |  · verb |
| [mentor](https://en.wiktionary.org/wiki/mentor#Danish) | mentor | /mɛntər/ · noun |
| [milliard](https://en.wiktionary.org/wiki/milliard#Danish) | a billion; 10⁹ | [miliˈɑˀd̥] · noun |
| [morder](https://en.wiktionary.org/wiki/morder#Danish) | murderer, killer | /morder/ · noun |
| [yes](https://en.wiktionary.org/wiki/yes#Danish) | Expression of triumph, vehement approval, etc. |  · intj |
| [ånde](https://en.wiktionary.org/wiki/%C3%A5nde#Danish) | breath (air expelled from the lungs) | /ɔnə/ · noun |
| [avenue](https://en.wiktionary.org/wiki/avenue#Danish) | avenue | /avəny/ · noun |
| [diabetes](https://en.wiktionary.org/wiki/diabetes#Danish) | diabetes |  · noun |
| [jag](https://en.wiktionary.org/wiki/jag#Danish) | hurry, rush | /jaːɡ/ · noun |
| [pels](https://en.wiktionary.org/wiki/pels#Danish) | A fur, coat | /pɛls/ · noun |
| [trailer](https://en.wiktionary.org/wiki/trailer#Danish) | trailer (vehicle towed behind another vehicle) |  · noun |
| [whisky](https://en.wiktionary.org/wiki/whisky#Danish) | whiskey |  · noun |
| [you name it](https://en.wiktionary.org/wiki/you%20name%20it#Danish) | you name it | [juˈnɛjmˌed̥] · phrase |
| [HP](https://en.wiktionary.org/wiki/HP#Danish) | hit point(s) |  · noun |
| [abort](https://en.wiktionary.org/wiki/abort#Danish) | abortion | /abʌɐ̯t/ · noun |
| [absurd](https://en.wiktionary.org/wiki/absurd#Danish) | absurd | /absurd/ · adj |
| [hobby](https://en.wiktionary.org/wiki/hobby#Danish) | hobby (activity) |  · noun |
| [menstruation](https://en.wiktionary.org/wiki/menstruation#Danish) | menstruation | /mɛnsdʁuɑˈɕoˀn/ · noun |
| [mild](https://en.wiktionary.org/wiki/mild#Danish) | mild, gentle, soft | /mil/ · adj |
| [mile](https://en.wiktionary.org/wiki/mile#Danish) | dune | /miːlə/ · noun |
| [smal](https://en.wiktionary.org/wiki/smal#Danish) | narrow, thin | /smal/ · adj |
| [fodre](https://en.wiktionary.org/wiki/fodre#Danish) | To feed |  · verb |
| [goddag](https://en.wiktionary.org/wiki/goddag#Danish) | good day (as a greeting) | /ɡoˈdaːˀɣ/ · intj |

</details>

<details><summary>Words 951–1000</summary>

![[Resources/Audio/da/Words 0951-1000.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [helikopter](https://en.wiktionary.org/wiki/helikopter#Danish) | helicopter |  · noun |
| [invasion](https://en.wiktionary.org/wiki/invasion#Danish) | invasion |  · noun |
| [mental](https://en.wiktionary.org/wiki/mental#Danish) | mental (pertaining to the mind) |  · adj |
| [propaganda](https://en.wiktionary.org/wiki/propaganda#Danish) | propaganda |  · noun |
| [pølse](https://en.wiktionary.org/wiki/p%C3%B8lse#Danish) | sausage, banger | [ˈpʰølsə] · noun |
| [skipper](https://en.wiktionary.org/wiki/skipper#Danish) | a skipper |  · noun |
| [slim](https://en.wiktionary.org/wiki/slim#Danish) | slime | /sliːm/ · noun |
| [student](https://en.wiktionary.org/wiki/student#Danish) | a person who has graduated from gymnasium | [sd̥uˈd̥enˀd̥] · noun |
| [bade](https://en.wiktionary.org/wiki/bade#Danish) | to bathe, take a bath, take a swim | [ˈb̥æːðə] · verb |
| [brag](https://en.wiktionary.org/wiki/brag#Danish) | bang, crash |  · noun |
| [browser](https://en.wiktionary.org/wiki/browser#Danish) | web browser | /bravsər/ · noun |
| [bue](https://en.wiktionary.org/wiki/bue#Danish) | bow (weapon) | [ˈb̥uːə] · noun |
| [grus](https://en.wiktionary.org/wiki/grus#Danish) | gravel | /ɡruːs/ · noun |
| [illustration](https://en.wiktionary.org/wiki/illustration#Danish) | illustration |  · noun |
| [rang](https://en.wiktionary.org/wiki/rang#Danish) | rank | /ranɡ/ · noun |
| [ABC](https://en.wiktionary.org/wiki/ABC#Danish) | ABC (a primer for teaching the Latin alphabet and first elements of reading; the rudiments of any subject) | /abeseː/ · noun |
| [ADHD](https://en.wiktionary.org/wiki/ADHD#Danish) | attention deficit hyperactivity disorder | [ˈɛˀˈte̝ˀˈhɔˀˈte̝ˀ] · noun |
| [abc](https://en.wiktionary.org/wiki/abc#Danish) | ABC (a primer for teaching the Latin alphabet and first elements of reading; the rudiments of any subject) | /abeseː/ · noun |
| [boulevard](https://en.wiktionary.org/wiki/boulevard#Danish) | boulevard | [b̥uləˈʋɑˀd̥] · noun |
| [diagnose](https://en.wiktionary.org/wiki/diagnose#Danish) | diagnosis |  · noun |
| [dimension](https://en.wiktionary.org/wiki/dimension#Danish) | dimension |  · noun |
| [gale](https://en.wiktionary.org/wiki/gale#Danish) | to crow (mostly of the sound of the cock) | /ɡaːlə/ · verb |
| [grande](https://en.wiktionary.org/wiki/grande#Danish) | grandee |  · noun |
| [instrument](https://en.wiktionary.org/wiki/instrument#Danish) | instrument |  · noun |
| [materiel](https://en.wiktionary.org/wiki/materiel#Danish) | material |  · adj |
| [neutral](https://en.wiktionary.org/wiki/neutral#Danish) | neutral | [nœwˈtˢʁ̥ɑˀl] · adj |
| [rapper](https://en.wiktionary.org/wiki/rapper#Danish) | rapper (practitioner of rap music) |  · noun |
| [temperament](https://en.wiktionary.org/wiki/temperament#Danish) | temperament |  · noun |
| [bridge](https://en.wiktionary.org/wiki/bridge#Danish) | bridge (a card game) | /britsj/ · noun |
| [busk](https://en.wiktionary.org/wiki/busk#Danish) | bush |  · noun |
| [flink](https://en.wiktionary.org/wiki/flink#Danish) | nice, friendly | /flenk/ · adj |
| [garage](https://en.wiktionary.org/wiki/garage#Danish) | garage (building (or section of a building) used to store a car, tools and other miscellaneous items.) |  · noun |
| [laser](https://en.wiktionary.org/wiki/laser#Danish) | laser | /lɛjsər/ · noun |
| [majs](https://en.wiktionary.org/wiki/majs#Danish) | corn, maize |  · noun |
| [pung](https://en.wiktionary.org/wiki/pung#Danish) | purse (small bag for carrying money) |  · noun |
| [radius](https://en.wiktionary.org/wiki/radius#Danish) | radius |  · noun |
| [tang](https://en.wiktionary.org/wiki/tang#Danish) | tongs | /tanɡ/ · noun |
| [visdom](https://en.wiktionary.org/wiki/visdom#Danish) | wisdom | /viːsdɔm/ · noun |
| [abe](https://en.wiktionary.org/wiki/abe#Danish) | monkey | /aːbə/ · noun |
| [elleve](https://en.wiktionary.org/wiki/elleve#Danish) | eleven | [ˈɛlvə] · num |
| [human](https://en.wiktionary.org/wiki/human#Danish) | human (having the nature or attributes of a human being) |  · adj |
| [jungle](https://en.wiktionary.org/wiki/jungle#Danish) | jungle | /djɔnɡlə/ · noun |
| [kanin](https://en.wiktionary.org/wiki/kanin#Danish) | rabbit | [kʰaˈniˀn] · noun |
| [manual](https://en.wiktionary.org/wiki/manual#Danish) | manual, a booklet that instructs on the usage of a particular machine |  · noun |
| [medium](https://en.wiktionary.org/wiki/medium#Danish) | medium | /meːdiɔm/ · noun |
| [stave](https://en.wiktionary.org/wiki/stave#Danish) | to spell (words) |  · verb |
| [aluminium](https://en.wiktionary.org/wiki/aluminium#Danish) | aluminium | /aluminjɔm/ · noun |
| [bly](https://en.wiktionary.org/wiki/bly#Danish) | lead (metal) | [ˈb̥lyːˀ] · noun |
| [femten](https://en.wiktionary.org/wiki/femten#Danish) | fifteen | /fɛmtən/ · num |
| [foster](https://en.wiktionary.org/wiki/foster#Danish) | fetus |  · noun |

</details>

## Question bank

Try before opening the answers. Different tasks use the same sentence to practise complementary skills. Open translation and explanation tasks can have valid alternatives.

### En and et nouns · 50 questions

**da-Q0001 · Fill the gap**

"Oh, var jeg dog sådant ____ stort træ, som de andre!" sukkede det lille grantræ.

"Oh, if I were only as great a tree as the others!" sighed the little Fir.

[[Danish#^da-Q0001-answer|Compare the answer]]
^da-Q0001

**da-Q0002 · Choose the form**

"Oh, var jeg dog sådant ____ stort træ, som de andre!" sukkede det lille grantræ.

"Oh, if I were only as great a tree as the others!" sighed the little Fir.

Choices: et / en

[[Danish#^da-Q0002-answer|Compare the answer]]
^da-Q0002

**da-Q0003 · Edit the changed sentence**

Marathi er navnet på 【en】 vigtigt indoarisk sprog, der tales i det vestlige og centrale Indien.

Marathi is the name of an important Indo-Aryan language spoken in western and central India.

[[Danish#^da-Q0003-answer|Compare the answer]]
^da-Q0003

**da-Q0004 · Build the sentence**

Arrange: i / er / indoarisk / vigtigt / det / vestlige / tales / der / Marathi / sprog, / og / et / Indien. / på / centrale / navnet

Marathi is the name of an important Indo-Aryan language spoken in western and central India.

[[Danish#^da-Q0004-answer|Compare the answer]]
^da-Q0004

**da-Q0005 · Write a translation**

Write this in Danish: This is a public street, not a racetrack.

[[Danish#^da-Q0005-answer|Compare the answer]]
^da-Q0005

**da-Q0006 · Explain the grammar**

Dette er 【en】 offentlig gade, ikke en væddeløbsbane!

This is a public street, not a racetrack.

[[Danish#^da-Q0006-answer|Compare the answer]]
^da-Q0006

**da-Q0007 · Fill the gap**

Lad os få ____ drink.

Have a drink with me.

[[Danish#^da-Q0007-answer|Compare the answer]]
^da-Q0007

**da-Q0008 · Choose the form**

Lad os få ____ drink.

Have a drink with me.

Choices: et / en

[[Danish#^da-Q0008-answer|Compare the answer]]
^da-Q0008

**da-Q0009 · Edit the changed sentence**

Hun er 【et】 skør heks.

She's a crazy witch.

[[Danish#^da-Q0009-answer|Compare the answer]]
^da-Q0009

**da-Q0010 · Build the sentence**

Arrange: skør / er / Hun / en / heks.

She's a crazy witch.

[[Danish#^da-Q0010-answer|Compare the answer]]
^da-Q0010

**da-Q0011 · Write a translation**

Write this in Danish: She's an airhead.

[[Danish#^da-Q0011-answer|Compare the answer]]
^da-Q0011

**da-Q0012 · Explain the grammar**

Hun er 【et】 fjols.

She's an airhead.

[[Danish#^da-Q0012-answer|Compare the answer]]
^da-Q0012

**da-Q0013 · Fill the gap**

I Europa betragter man punktlighed som ____ selvfølge.

In Europe, people regard punctuality as a matter of course.

[[Danish#^da-Q0013-answer|Compare the answer]]
^da-Q0013

**da-Q0014 · Choose the form**

I Europa betragter man punktlighed som ____ selvfølge.

In Europe, people regard punctuality as a matter of course.

Choices: et / en

[[Danish#^da-Q0014-answer|Compare the answer]]
^da-Q0014

**da-Q0015 · Edit the changed sentence**

Tom gav mig 【et】 harmonika til jul.

Tom gave me a harmonica for Christmas.

[[Danish#^da-Q0015-answer|Compare the answer]]
^da-Q0015

**da-Q0016 · Build the sentence**

Arrange: mig / gav / harmonika / Tom / jul. / en / til

Tom gave me a harmonica for Christmas.

[[Danish#^da-Q0016-answer|Compare the answer]]
^da-Q0016

**da-Q0017 · Write a translation**

Write this in Danish: Tom works in a pasta factory.

[[Danish#^da-Q0017-answer|Compare the answer]]
^da-Q0017

**da-Q0018 · Explain the grammar**

Tom arbejder på 【en】 pastafabrik.

Tom works in a pasta factory.

[[Danish#^da-Q0018-answer|Compare the answer]]
^da-Q0018

**da-Q0019 · Fill the gap**

Tom havde ____ dåse øl i hånden og tre til i rygsækken.

Tom had one can of beer in his hand and three more in his pack.

[[Danish#^da-Q0019-answer|Compare the answer]]
^da-Q0019

**da-Q0020 · Choose the form**

Tom havde ____ dåse øl i hånden og tre til i rygsækken.

Tom had one can of beer in his hand and three more in his pack.

Choices: en / et

[[Danish#^da-Q0020-answer|Compare the answer]]
^da-Q0020

**da-Q0021 · Edit the changed sentence**

Jeg har aldrig før set 【et】 så stor vandmelon.

I've never seen such a giant watermelon!

[[Danish#^da-Q0021-answer|Compare the answer]]
^da-Q0021

**da-Q0022 · Build the sentence**

Arrange: Jeg / stor / set / aldrig / før / vandmelon. / har / en / så

I've never seen such a giant watermelon!

[[Danish#^da-Q0022-answer|Compare the answer]]
^da-Q0022

**da-Q0023 · Write a translation**

Write this in Danish: This missile is a mobile weapon which can be moved rapidly from one place to another.

[[Danish#^da-Q0023-answer|Compare the answer]]
^da-Q0023

**da-Q0024 · Explain the grammar**

Denne raket er 【et】 mobilt våben, der hurtigt kan flyttes fra et sted til et andet.

This missile is a mobile weapon which can be moved rapidly from one place to another.

[[Danish#^da-Q0024-answer|Compare the answer]]
^da-Q0024

**da-Q0025 · Fill the gap**

Hans hund har været syg i ____ uge.

His dog has been ill for a week.

[[Danish#^da-Q0025-answer|Compare the answer]]
^da-Q0025

**da-Q0026 · Choose the form**

Hans hund har været syg i ____ uge.

His dog has been ill for a week.

Choices: en / et

[[Danish#^da-Q0026-answer|Compare the answer]]
^da-Q0026

**da-Q0027 · Edit the changed sentence**

Du er 【et】 gavstrik, Tom.

You're a rogue, Tom.

[[Danish#^da-Q0027-answer|Compare the answer]]
^da-Q0027

**da-Q0028 · Build the sentence**

Arrange: en / er / Tom. / Du / gavstrik,

You're a rogue, Tom.

[[Danish#^da-Q0028-answer|Compare the answer]]
^da-Q0028

**da-Q0029 · Write a translation**

Write this in Danish: When Tom looked down at the apple he was eating, he realized that he had eaten half a worm.

[[Danish#^da-Q0029-answer|Compare the answer]]
^da-Q0029

**da-Q0030 · Explain the grammar**

Da Tom kiggede ned på æblet han var ved at spise, blev han klar over at han havde spist 【en】 halv orm.

When Tom looked down at the apple he was eating, he realized that he had eaten half a worm.

[[Danish#^da-Q0030-answer|Compare the answer]]
^da-Q0030

**da-Q0031 · Fill the gap**

Jeg modtog ____ brev, der informerede mig om hans ankomst.

I received a letter informing me of his arrival.

[[Danish#^da-Q0031-answer|Compare the answer]]
^da-Q0031

**da-Q0032 · Choose the form**

Jeg modtog ____ brev, der informerede mig om hans ankomst.

I received a letter informing me of his arrival.

Choices: en / et

[[Danish#^da-Q0032-answer|Compare the answer]]
^da-Q0032

**da-Q0033 · Edit the changed sentence**

Tom tog ikke 【en】 bad.

Tom didn't take a shower.

[[Danish#^da-Q0033-answer|Compare the answer]]
^da-Q0033

**da-Q0034 · Build the sentence**

Arrange: et / bad. / tog / Tom / ikke

Tom didn't take a shower.

[[Danish#^da-Q0034-answer|Compare the answer]]
^da-Q0034

**da-Q0035 · Write a translation**

Write this in Danish: He's got terrible handwriting.

[[Danish#^da-Q0035-answer|Compare the answer]]
^da-Q0035

**da-Q0036 · Explain the grammar**

Han har 【en】 forfærdelig håndskrift.

He's got terrible handwriting.

[[Danish#^da-Q0036-answer|Compare the answer]]
^da-Q0036

**da-Q0037 · Fill the gap**

Folk har ____ tendens til at undervurdere deres fremtidige behov.

People have a tendency to underestimate their future needs.

[[Danish#^da-Q0037-answer|Compare the answer]]
^da-Q0037

**da-Q0038 · Choose the form**

Folk har ____ tendens til at undervurdere deres fremtidige behov.

People have a tendency to underestimate their future needs.

Choices: et / en

[[Danish#^da-Q0038-answer|Compare the answer]]
^da-Q0038

**da-Q0039 · Edit the changed sentence**

Økonomien var i 【et】 elendig stand.

The economy was in miserable condition.

[[Danish#^da-Q0039-answer|Compare the answer]]
^da-Q0039

**da-Q0040 · Build the sentence**

Arrange: var / Økonomien / stand. / elendig / i / en

The economy was in miserable condition.

[[Danish#^da-Q0040-answer|Compare the answer]]
^da-Q0040

**da-Q0041 · Write a translation**

Write this in Danish: Let's go someplace where we can talk in private.

[[Danish#^da-Q0041-answer|Compare the answer]]
^da-Q0041

**da-Q0042 · Explain the grammar**

Lad os gå 【et】 sted hen, hvor vi kan tale privat.

Let's go someplace where we can talk in private.

[[Danish#^da-Q0042-answer|Compare the answer]]
^da-Q0042

**da-Q0043 · Fill the gap**

Har du købt ____ ny bil?

Did you buy a new car?

[[Danish#^da-Q0043-answer|Compare the answer]]
^da-Q0043

**da-Q0044 · Choose the form**

Har du købt ____ ny bil?

Did you buy a new car?

Choices: et / en

[[Danish#^da-Q0044-answer|Compare the answer]]
^da-Q0044

**da-Q0045 · Edit the changed sentence**

Han blev sendt på 【en】 psykiatrisk hospital.

He was sent to a mental hospital.

[[Danish#^da-Q0045-answer|Compare the answer]]
^da-Q0045

**da-Q0046 · Build the sentence**

Arrange: Han / psykiatrisk / sendt / hospital. / på / blev / et

He was sent to a mental hospital.

[[Danish#^da-Q0046-answer|Compare the answer]]
^da-Q0046

**da-Q0047 · Write a translation**

Write this in Danish: The Greeks built a wooden horse.

[[Danish#^da-Q0047-answer|Compare the answer]]
^da-Q0047

**da-Q0048 · Explain the grammar**

Grækerne byggede 【en】 træhest.

The Greeks built a wooden horse.

[[Danish#^da-Q0048-answer|Compare the answer]]
^da-Q0048

**da-Q0049 · Fill the gap**

Har I taget ____ hårtørrer med?

Did you bring a hair dryer?

[[Danish#^da-Q0049-answer|Compare the answer]]
^da-Q0049

**da-Q0050 · Choose the form**

Har I taget ____ hårtørrer med?

Did you bring a hair dryer?

Choices: en / et

[[Danish#^da-Q0050-answer|Compare the answer]]
^da-Q0050


### Definite and demonstrative forms · 50 questions

**da-Q0051 · Edit the changed sentence**

Bærer din kone 【den】 muslimske tørklæde?

Does your wife wear the Muslim headscarf?

[[Danish#^da-Q0051-answer|Compare the answer]]
^da-Q0051

**da-Q0052 · Build the sentence**

Arrange: tørklæde? / din / kone / det / Bærer / muslimske

Does your wife wear the Muslim headscarf?

[[Danish#^da-Q0052-answer|Compare the answer]]
^da-Q0052

**da-Q0053 · Write a translation**

Write this in Danish: Just finish what you're doing.

[[Danish#^da-Q0053-answer|Compare the answer]]
^da-Q0053

**da-Q0054 · Explain the grammar**

Gør bare 【det】 færdigt som du er i gang med.

Just finish what you're doing.

[[Danish#^da-Q0054-answer|Compare the answer]]
^da-Q0054

**da-Q0055 · Fill the gap**

Hvor er ____ koldt!

How cold it is!

[[Danish#^da-Q0055-answer|Compare the answer]]
^da-Q0055

**da-Q0056 · Choose the form**

Hvor er ____ koldt!

How cold it is!

Choices: det / den / de / denne

[[Danish#^da-Q0056-answer|Compare the answer]]
^da-Q0056

**da-Q0057 · Edit the changed sentence**

Kun Tom ved 【den】.

Only Tom knows that.

[[Danish#^da-Q0057-answer|Compare the answer]]
^da-Q0057

**da-Q0058 · Build the sentence**

Arrange: ved / det. / Kun / Tom

Only Tom knows that.

[[Danish#^da-Q0058-answer|Compare the answer]]
^da-Q0058

**da-Q0059 · Write a translation**

Write this in Danish: It's quite hot, isn't it?

[[Danish#^da-Q0059-answer|Compare the answer]]
^da-Q0059

**da-Q0060 · Explain the grammar**

Det er ret varmt, er 【det】 ikke?

It's quite hot, isn't it?

[[Danish#^da-Q0060-answer|Compare the answer]]
^da-Q0060

**da-Q0061 · Fill the gap**

Enhver af ____ elevatorer kan bære ti personer.

These elevators are each capable of carrying ten persons.

[[Danish#^da-Q0061-answer|Compare the answer]]
^da-Q0061

**da-Q0062 · Choose the form**

Enhver af ____ elevatorer kan bære ti personer.

These elevators are each capable of carrying ten persons.

Choices: den / disse / de / det

[[Danish#^da-Q0062-answer|Compare the answer]]
^da-Q0062

**da-Q0063 · Edit the changed sentence**

Jeg har ikke hørt 【den】 ord i lang tid.

I haven't heard that word in a long time.

[[Danish#^da-Q0063-answer|Compare the answer]]
^da-Q0063

**da-Q0064 · Build the sentence**

Arrange: Jeg / ord / det / tid. / hørt / lang / i / har / ikke

I haven't heard that word in a long time.

[[Danish#^da-Q0064-answer|Compare the answer]]
^da-Q0064

**da-Q0065 · Write a translation**

Write this in Danish: Tom and Mary knew they'd made the right choice.

[[Danish#^da-Q0065-answer|Compare the answer]]
^da-Q0065

**da-Q0066 · Explain the grammar**

Tom og Mary vidste at 【de】 ville tage det rigtige valg.

Tom and Mary knew they'd made the right choice.

[[Danish#^da-Q0066-answer|Compare the answer]]
^da-Q0066

**da-Q0067 · Fill the gap**

Hvor er ____ danske ambassade?

Where is the Danish embassy?

[[Danish#^da-Q0067-answer|Compare the answer]]
^da-Q0067

**da-Q0068 · Choose the form**

Hvor er ____ danske ambassade?

Where is the Danish embassy?

Choices: denne / den / de / det

[[Danish#^da-Q0068-answer|Compare the answer]]
^da-Q0068

**da-Q0069 · Edit the changed sentence**

Jeg kan ikke tro at 【den】 her virkelig sker.

I can't believe this is really happening.

[[Danish#^da-Q0069-answer|Compare the answer]]
^da-Q0069

**da-Q0070 · Build the sentence**

Arrange: Jeg / sker. / det / tro / kan / virkelig / ikke / at / her

I can't believe this is really happening.

[[Danish#^da-Q0070-answer|Compare the answer]]
^da-Q0070

**da-Q0071 · Write a translation**

Write this in Danish: Show me that.

[[Danish#^da-Q0071-answer|Compare the answer]]
^da-Q0071

**da-Q0072 · Explain the grammar**

Vis mig 【det】.

Show me that.

[[Danish#^da-Q0072-answer|Compare the answer]]
^da-Q0072

**da-Q0073 · Fill the gap**

Tom er ikke bange for slanger, end ikke ____ giftige.

Tom isn't afraid of snakes, even poisonous ones.

[[Danish#^da-Q0073-answer|Compare the answer]]
^da-Q0073

**da-Q0074 · Choose the form**

Tom er ikke bange for slanger, end ikke ____ giftige.

Tom isn't afraid of snakes, even poisonous ones.

Choices: den / denne / de / det

[[Danish#^da-Q0074-answer|Compare the answer]]
^da-Q0074

**da-Q0075 · Edit the changed sentence**

Frederik 【det】 Store indførte kartoflen i Preussen.

Frederick the Great introduced the potato to Prussia.

[[Danish#^da-Q0075-answer|Compare the answer]]
^da-Q0075

**da-Q0076 · Build the sentence**

Arrange: den / Preussen. / Store / Frederik / kartoflen / indførte / i

Frederick the Great introduced the potato to Prussia.

[[Danish#^da-Q0076-answer|Compare the answer]]
^da-Q0076

**da-Q0077 · Write a translation**

Write this in Danish: I think you're the only one who needs help.

[[Danish#^da-Q0077-answer|Compare the answer]]
^da-Q0077

**da-Q0078 · Explain the grammar**

Jeg tror du er 【den】 eneste der har brug for hjælp.

I think you're the only one who needs help.

[[Danish#^da-Q0078-answer|Compare the answer]]
^da-Q0078

**da-Q0079 · Fill the gap**

Vi kunne ikke andet end at beundre ____ smukke solnedgang.

We could not help admiring the beautiful sunset.

[[Danish#^da-Q0079-answer|Compare the answer]]
^da-Q0079

**da-Q0080 · Choose the form**

Vi kunne ikke andet end at beundre ____ smukke solnedgang.

We could not help admiring the beautiful sunset.

Choices: den / de / denne / det

[[Danish#^da-Q0080-answer|Compare the answer]]
^da-Q0080

**da-Q0081 · Edit the changed sentence**

Tom er 【det】 bedste der er.

Tom's the best there is.

[[Danish#^da-Q0081-answer|Compare the answer]]
^da-Q0081

**da-Q0082 · Build the sentence**

Arrange: er. / bedste / er / Tom / der / den

Tom's the best there is.

[[Danish#^da-Q0082-answer|Compare the answer]]
^da-Q0082

**da-Q0083 · Write a translation**

Write this in Danish: At least 10 Russians have died this year taking selfies.

[[Danish#^da-Q0083-answer|Compare the answer]]
^da-Q0083

**da-Q0084 · Explain the grammar**

Mindst 10 russere er omkommet i år mens 【de】 tog selfies.

At least 10 Russians have died this year taking selfies.

[[Danish#^da-Q0084-answer|Compare the answer]]
^da-Q0084

**da-Q0085 · Fill the gap**

Jeg ønskede ikke at ____ skulle tage afsted.

I didn't want them to leave.

[[Danish#^da-Q0085-answer|Compare the answer]]
^da-Q0085

**da-Q0086 · Choose the form**

Jeg ønskede ikke at ____ skulle tage afsted.

I didn't want them to leave.

Choices: det / den / denne / de

[[Danish#^da-Q0086-answer|Compare the answer]]
^da-Q0086

**da-Q0087 · Edit the changed sentence**

I 【den】 tid med postfaktuel politik er det nemt at håndplukke data og komme til hvilken som helst konklusion man ønsker.

In this era of post-truth politics, it's easy to cherry-pick data and come to whatever conclusion you desire.

[[Danish#^da-Q0087-answer|Compare the answer]]
^da-Q0087

**da-Q0088 · Build the sentence**

Arrange: data / I / er / nemt / til / helst / og / postfaktuel / hvilken / det / denne / politik / ønsker. / komme / tid / at / konklusion / håndplukke / med / som / man

In this era of post-truth politics, it's easy to cherry-pick data and come to whatever conclusion you desire.

[[Danish#^da-Q0088-answer|Compare the answer]]
^da-Q0088

**da-Q0089 · Write a translation**

Write this in Danish: I will sell it as soon as I find a buyer.

[[Danish#^da-Q0089-answer|Compare the answer]]
^da-Q0089

**da-Q0090 · Explain the grammar**

Jeg vil sælge 【den】 så snart jeg finder en køber.

I will sell it as soon as I find a buyer.

[[Danish#^da-Q0090-answer|Compare the answer]]
^da-Q0090

**da-Q0091 · Fill the gap**

"Jeg er helt alene." "Men ____ passer jo slet ikke! Du har da venner!"

"I'm all alone." "But that's not true at all! You have friends!"

[[Danish#^da-Q0091-answer|Compare the answer]]
^da-Q0091

**da-Q0092 · Choose the form**

"Jeg er helt alene." "Men ____ passer jo slet ikke! Du har da venner!"

"I'm all alone." "But that's not true at all! You have friends!"

Choices: det / denne / den / de

[[Danish#^da-Q0092-answer|Compare the answer]]
^da-Q0092

**da-Q0093 · Edit the changed sentence**

Jeg elsker kandiserede kastanjer, men 【den】 er meget søde.

I love candied chestnuts, but they are very sweet.

[[Danish#^da-Q0093-answer|Compare the answer]]
^da-Q0093

**da-Q0094 · Build the sentence**

Arrange: kastanjer, / kandiserede / søde. / Jeg / meget / er / elsker / de / men

I love candied chestnuts, but they are very sweet.

[[Danish#^da-Q0094-answer|Compare the answer]]
^da-Q0094

**da-Q0095 · Write a translation**

Write this in Danish: The poor support the rich.

[[Danish#^da-Q0095-answer|Compare the answer]]
^da-Q0095

**da-Q0096 · Explain the grammar**

De fattige støtter 【de】 rige.

The poor support the rich.

[[Danish#^da-Q0096-answer|Compare the answer]]
^da-Q0096

**da-Q0097 · Fill the gap**

Jeg syntes at ____ lød så underligt.

I thought that it sounded so odd.

[[Danish#^da-Q0097-answer|Compare the answer]]
^da-Q0097

**da-Q0098 · Choose the form**

Jeg syntes at ____ lød så underligt.

I thought that it sounded so odd.

Choices: denne / den / det / de

[[Danish#^da-Q0098-answer|Compare the answer]]
^da-Q0098

**da-Q0099 · Edit the changed sentence**

Hvis jeg kunne sende dig en skumfidus, Trang, ville jeg gøre 【den】.

If I could send you a marshmallow, Trang, I would.

[[Danish#^da-Q0099-answer|Compare the answer]]
^da-Q0099

**da-Q0100 · Build the sentence**

Arrange: Trang, / jeg / Hvis / jeg / sende / det. / kunne / en / gøre / ville / skumfidus, / dig

If I could send you a marshmallow, Trang, I would.

[[Danish#^da-Q0100-answer|Compare the answer]]
^da-Q0100


### Personal pronouns · 50 questions

**da-Q0101 · Write a translation**

Write this in Danish: We don't know him.

[[Danish#^da-Q0101-answer|Compare the answer]]
^da-Q0101

**da-Q0102 · Explain the grammar**

Vi kender 【ham】 ikke.

We don't know him.

[[Danish#^da-Q0102-answer|Compare the answer]]
^da-Q0102

**da-Q0103 · Fill the gap**

Tom havde al ret til at gøre, hvad ____ gjorde.

Tom had every right to do what he did.

[[Danish#^da-Q0103-answer|Compare the answer]]
^da-Q0103

**da-Q0104 · Choose the form**

Tom havde al ret til at gøre, hvad ____ gjorde.

Tom had every right to do what he did.

Choices: du / han / mig / jeg

[[Danish#^da-Q0104-answer|Compare the answer]]
^da-Q0104

**da-Q0105 · Edit the changed sentence**

Jeg ville gøre alt for 【jeg】.

I'd do anything for you.

[[Danish#^da-Q0105-answer|Compare the answer]]
^da-Q0105

**da-Q0106 · Build the sentence**

Arrange: gøre / ville / for / Jeg / dig. / alt

I'd do anything for you.

[[Danish#^da-Q0106-answer|Compare the answer]]
^da-Q0106

**da-Q0107 · Write a translation**

Write this in Danish: Never spend your money before you have earned it.

[[Danish#^da-Q0107-answer|Compare the answer]]
^da-Q0107

**da-Q0108 · Explain the grammar**

Brug aldrig dine penge, før 【du】 har tjent dem.

Never spend your money before you have earned it.

[[Danish#^da-Q0108-answer|Compare the answer]]
^da-Q0108

**da-Q0109 · Fill the gap**

Det er aldrig sket for ____; bank under bordet.

That has never happened to me, touch wood.

[[Danish#^da-Q0109-answer|Compare the answer]]
^da-Q0109

**da-Q0110 · Choose the form**

Det er aldrig sket for ____; bank under bordet.

That has never happened to me, touch wood.

Choices: mig / du / dig / jeg

[[Danish#^da-Q0110-answer|Compare the answer]]
^da-Q0110

**da-Q0111 · Edit the changed sentence**

De begravede 【jeg】.

They buried her.

[[Danish#^da-Q0111-answer|Compare the answer]]
^da-Q0111

**da-Q0112 · Build the sentence**

Arrange: hende. / begravede / De

They buried her.

[[Danish#^da-Q0112-answer|Compare the answer]]
^da-Q0112

**da-Q0113 · Write a translation**

Write this in Danish: I told him good night.

[[Danish#^da-Q0113-answer|Compare the answer]]
^da-Q0113

**da-Q0114 · Explain the grammar**

Jeg sagde godnat til 【ham】.

I told him good night.

[[Danish#^da-Q0114-answer|Compare the answer]]
^da-Q0114

**da-Q0115 · Fill the gap**

Jeg ser ____ på lørdag.

I'll see you Saturday.

[[Danish#^da-Q0115-answer|Compare the answer]]
^da-Q0115

**da-Q0116 · Choose the form**

Jeg ser ____ på lørdag.

I'll see you Saturday.

Choices: mig / du / jeg / dig

[[Danish#^da-Q0116-answer|Compare the answer]]
^da-Q0116

**da-Q0117 · Edit the changed sentence**

Hvor mange katte har 【jeg】?

How many cats do you have?

[[Danish#^da-Q0117-answer|Compare the answer]]
^da-Q0117

**da-Q0118 · Build the sentence**

Arrange: har / mange / du? / katte / Hvor

How many cats do you have?

[[Danish#^da-Q0118-answer|Compare the answer]]
^da-Q0118

**da-Q0119 · Write a translation**

Write this in Danish: Doctor, I've got an itch in my crotch.

[[Danish#^da-Q0119-answer|Compare the answer]]
^da-Q0119

**da-Q0120 · Explain the grammar**

Doktor, 【jeg】 har kløe i skridtet.

Doctor, I've got an itch in my crotch.

[[Danish#^da-Q0120-answer|Compare the answer]]
^da-Q0120

**da-Q0121 · Fill the gap**

Jeg har ikke set ____ i evigheder.

I haven't seen her for ages.

[[Danish#^da-Q0121-answer|Compare the answer]]
^da-Q0121

**da-Q0122 · Choose the form**

Jeg har ikke set ____ i evigheder.

I haven't seen her for ages.

Choices: du / hende / jeg / mig

[[Danish#^da-Q0122-answer|Compare the answer]]
^da-Q0122

**da-Q0123 · Edit the changed sentence**

Jeg så hvad 【jeg】 gjorde.

I saw what you did.

[[Danish#^da-Q0123-answer|Compare the answer]]
^da-Q0123

**da-Q0124 · Build the sentence**

Arrange: så / Jeg / gjorde. / hvad / du

I saw what you did.

[[Danish#^da-Q0124-answer|Compare the answer]]
^da-Q0124

**da-Q0125 · Write a translation**

Write this in Danish: Is he a doctor?

[[Danish#^da-Q0125-answer|Compare the answer]]
^da-Q0125

**da-Q0126 · Explain the grammar**

Er 【han】 læge?

Is he a doctor?

[[Danish#^da-Q0126-answer|Compare the answer]]
^da-Q0126

**da-Q0127 · Fill the gap**

Han kender ____.

He knows her.

[[Danish#^da-Q0127-answer|Compare the answer]]
^da-Q0127

**da-Q0128 · Choose the form**

Han kender ____.

He knows her.

Choices: hende / mig / jeg / du

[[Danish#^da-Q0128-answer|Compare the answer]]
^da-Q0128

**da-Q0129 · Edit the changed sentence**

【jeg】 ser mig aldrig igen.

You'll never see me again.

[[Danish#^da-Q0129-answer|Compare the answer]]
^da-Q0129

**da-Q0130 · Build the sentence**

Arrange: mig / I / aldrig / ser / igen.

You'll never see me again.

[[Danish#^da-Q0130-answer|Compare the answer]]
^da-Q0130

**da-Q0131 · Write a translation**

Write this in Danish: I'm afraid I've run short of coffee.

[[Danish#^da-Q0131-answer|Compare the answer]]
^da-Q0131

**da-Q0132 · Explain the grammar**

Jeg er bange for at 【jeg】 er løbet tør for kaffe.

I'm afraid I've run short of coffee.

[[Danish#^da-Q0132-answer|Compare the answer]]
^da-Q0132

**da-Q0133 · Fill the gap**

Du gjorde ____ forskrækket!

You startled me!

[[Danish#^da-Q0133-answer|Compare the answer]]
^da-Q0133

**da-Q0134 · Choose the form**

Du gjorde ____ forskrækket!

You startled me!

Choices: dig / du / jeg / mig

[[Danish#^da-Q0134-answer|Compare the answer]]
^da-Q0134

**da-Q0135 · Edit the changed sentence**

Har 【jeg】 læst Toms bog?

Have you read Tom's book?

[[Danish#^da-Q0135-answer|Compare the answer]]
^da-Q0135

**da-Q0136 · Build the sentence**

Arrange: Toms / bog? / du / Har / læst

Have you read Tom's book?

[[Danish#^da-Q0136-answer|Compare the answer]]
^da-Q0136

**da-Q0137 · Write a translation**

Write this in Danish: I beat him at chess.

[[Danish#^da-Q0137-answer|Compare the answer]]
^da-Q0137

**da-Q0138 · Explain the grammar**

Jeg slog 【ham】 i skak.

I beat him at chess.

[[Danish#^da-Q0138-answer|Compare the answer]]
^da-Q0138

**da-Q0139 · Fill the gap**

Hvor vover ____ at fornærme profeten Maria!

How dare you insult the prophetess Mary!

[[Danish#^da-Q0139-answer|Compare the answer]]
^da-Q0139

**da-Q0140 · Choose the form**

Hvor vover ____ at fornærme profeten Maria!

How dare you insult the prophetess Mary!

Choices: jeg / mig / dig / du

[[Danish#^da-Q0140-answer|Compare the answer]]
^da-Q0140

**da-Q0141 · Edit the changed sentence**

Tom siger at 【jeg】 aldrig har prøvet at spise hundemad.

Tom says that he's never tried eating dog food.

[[Danish#^da-Q0141-answer|Compare the answer]]
^da-Q0141

**da-Q0142 · Build the sentence**

Arrange: prøvet / at / at / siger / aldrig / Tom / spise / har / han / hundemad.

Tom says that he's never tried eating dog food.

[[Danish#^da-Q0142-answer|Compare the answer]]
^da-Q0142

**da-Q0143 · Write a translation**

Write this in Danish: She was in love with me, but I wasn't in love with her.

[[Danish#^da-Q0143-answer|Compare the answer]]
^da-Q0143

**da-Q0144 · Explain the grammar**

Hun var forelsket i 【mig】, men jeg var ikke forelsket i hende.

She was in love with me, but I wasn't in love with her.

[[Danish#^da-Q0144-answer|Compare the answer]]
^da-Q0144

**da-Q0145 · Fill the gap**

Ingen ville hjælpe ____, ikke engang Tom.

Nobody would help me, not even Tom.

[[Danish#^da-Q0145-answer|Compare the answer]]
^da-Q0145

**da-Q0146 · Choose the form**

Ingen ville hjælpe ____, ikke engang Tom.

Nobody would help me, not even Tom.

Choices: jeg / dig / du / mig

[[Danish#^da-Q0146-answer|Compare the answer]]
^da-Q0146

**da-Q0147 · Edit the changed sentence**

Hvornår bliver 【mig】 fri?

When shall I be free?

[[Danish#^da-Q0147-answer|Compare the answer]]
^da-Q0147

**da-Q0148 · Build the sentence**

Arrange: bliver / jeg / fri? / Hvornår

When shall I be free?

[[Danish#^da-Q0148-answer|Compare the answer]]
^da-Q0148

**da-Q0149 · Write a translation**

Write this in Danish: If only I'd done my homework!

[[Danish#^da-Q0149-answer|Compare the answer]]
^da-Q0149

**da-Q0150 · Explain the grammar**

Hvis bare 【jeg】 havde lavet mine lektier!

If only I'd done my homework!

[[Danish#^da-Q0150-answer|Compare the answer]]
^da-Q0150


### Copula and past · 50 questions

**da-Q0151 · Fill the gap**

Mørke ____ fravær af lys.

Darkness is the absence of light.

[[Danish#^da-Q0151-answer|Compare the answer]]
^da-Q0151

**da-Q0152 · Choose the form**

Mørke ____ fravær af lys.

Darkness is the absence of light.

Choices: er / været / var

[[Danish#^da-Q0152-answer|Compare the answer]]
^da-Q0152

**da-Q0153 · Edit the changed sentence**

At fejle 【var】 menneskeligt, at tilgive er guddommeligt.

To err is human; to forgive, divine.

[[Danish#^da-Q0153-answer|Compare the answer]]
^da-Q0153

**da-Q0154 · Build the sentence**

Arrange: er / At / fejle / tilgive / guddommeligt. / er / at / menneskeligt,

To err is human; to forgive, divine.

[[Danish#^da-Q0154-answer|Compare the answer]]
^da-Q0154

**da-Q0155 · Write a translation**

Write this in Danish: This is their house.

[[Danish#^da-Q0155-answer|Compare the answer]]
^da-Q0155

**da-Q0156 · Explain the grammar**

Dette 【er】 deres hus.

This is their house.

[[Danish#^da-Q0156-answer|Compare the answer]]
^da-Q0156

**da-Q0157 · Fill the gap**

Dette hus ____ berømt.

This house is famous.

[[Danish#^da-Q0157-answer|Compare the answer]]
^da-Q0157

**da-Q0158 · Choose the form**

Dette hus ____ berømt.

This house is famous.

Choices: var / været / er

[[Danish#^da-Q0158-answer|Compare the answer]]
^da-Q0158

**da-Q0159 · Edit the changed sentence**

Der 【er】 to kager.

There were two cakes.

[[Danish#^da-Q0159-answer|Compare the answer]]
^da-Q0159

**da-Q0160 · Build the sentence**

Arrange: var / Der / to / kager.

There were two cakes.

[[Danish#^da-Q0160-answer|Compare the answer]]
^da-Q0160

**da-Q0161 · Write a translation**

Write this in Danish: There is not enough meat.

[[Danish#^da-Q0161-answer|Compare the answer]]
^da-Q0161

**da-Q0162 · Explain the grammar**

Der 【er】 ikke nok kød.

There is not enough meat.

[[Danish#^da-Q0162-answer|Compare the answer]]
^da-Q0162

**da-Q0163 · Fill the gap**

Tom ____ dobbelt så tung som Mary.

Tom is twice as heavy as Mary.

[[Danish#^da-Q0163-answer|Compare the answer]]
^da-Q0163

**da-Q0164 · Choose the form**

Tom ____ dobbelt så tung som Mary.

Tom is twice as heavy as Mary.

Choices: er / var / været

[[Danish#^da-Q0164-answer|Compare the answer]]
^da-Q0164

**da-Q0165 · Edit the changed sentence**

Hjemmesiden 【var】 nede.

The website is down.

[[Danish#^da-Q0165-answer|Compare the answer]]
^da-Q0165

**da-Q0166 · Build the sentence**

Arrange: nede. / er / Hjemmesiden

The website is down.

[[Danish#^da-Q0166-answer|Compare the answer]]
^da-Q0166

**da-Q0167 · Write a translation**

Write this in Danish: Atlantis is real.

[[Danish#^da-Q0167-answer|Compare the answer]]
^da-Q0167

**da-Q0168 · Explain the grammar**

Atlantis 【er】 virkelig.

Atlantis is real.

[[Danish#^da-Q0168-answer|Compare the answer]]
^da-Q0168

**da-Q0169 · Fill the gap**

Døden ____ alle menneskers skæbne.

Death is the fate of all people.

[[Danish#^da-Q0169-answer|Compare the answer]]
^da-Q0169

**da-Q0170 · Choose the form**

Døden ____ alle menneskers skæbne.

Death is the fate of all people.

Choices: er / var / været

[[Danish#^da-Q0170-answer|Compare the answer]]
^da-Q0170

**da-Q0171 · Edit the changed sentence**

Det 【var】 bedre at vente på at politiet ankommer.

It's better to wait for the police to arrive.

[[Danish#^da-Q0171-answer|Compare the answer]]
^da-Q0171

**da-Q0172 · Build the sentence**

Arrange: politiet / bedre / at / er / at / på / Det / vente / ankommer.

It's better to wait for the police to arrive.

[[Danish#^da-Q0172-answer|Compare the answer]]
^da-Q0172

**da-Q0173 · Write a translation**

Write this in Danish: There are a lot of students in the gym.

[[Danish#^da-Q0173-answer|Compare the answer]]
^da-Q0173

**da-Q0174 · Explain the grammar**

Der 【er】 mange elever i gymnastiksalen.

There are a lot of students in the gym.

[[Danish#^da-Q0174-answer|Compare the answer]]
^da-Q0174

**da-Q0175 · Fill the gap**

Intet ____ mere vigtigt end tid.

Nothing is more important than time.

[[Danish#^da-Q0175-answer|Compare the answer]]
^da-Q0175

**da-Q0176 · Choose the form**

Intet ____ mere vigtigt end tid.

Nothing is more important than time.

Choices: var / været / er

[[Danish#^da-Q0176-answer|Compare the answer]]
^da-Q0176

**da-Q0177 · Edit the changed sentence**

De fleste japanske templer 【var】 lavet af træ.

Most Japanese temples are made of wood.

[[Danish#^da-Q0177-answer|Compare the answer]]
^da-Q0177

**da-Q0178 · Build the sentence**

Arrange: af / japanske / De / templer / træ. / lavet / fleste / er

Most Japanese temples are made of wood.

[[Danish#^da-Q0178-answer|Compare the answer]]
^da-Q0178

**da-Q0179 · Write a translation**

Write this in Danish: Tom was dying of thirst.

[[Danish#^da-Q0179-answer|Compare the answer]]
^da-Q0179

**da-Q0180 · Explain the grammar**

Tom 【var】 ved at dø af tørst.

Tom was dying of thirst.

[[Danish#^da-Q0180-answer|Compare the answer]]
^da-Q0180

**da-Q0181 · Fill the gap**

Hvor længe har du ____ ryger?

How long have you been a smoker?

[[Danish#^da-Q0181-answer|Compare the answer]]
^da-Q0181

**da-Q0182 · Choose the form**

Hvor længe har du ____ ryger?

How long have you been a smoker?

Choices: er / var / været

[[Danish#^da-Q0182-answer|Compare the answer]]
^da-Q0182

**da-Q0183 · Edit the changed sentence**

Verden udenfor 【var】 meget frygtindgydende.

The world outside is very scary.

[[Danish#^da-Q0183-answer|Compare the answer]]
^da-Q0183

**da-Q0184 · Build the sentence**

Arrange: Verden / meget / er / udenfor / frygtindgydende.

The world outside is very scary.

[[Danish#^da-Q0184-answer|Compare the answer]]
^da-Q0184

**da-Q0185 · Write a translation**

Write this in Danish: I'm a freelance journalist.

[[Danish#^da-Q0185-answer|Compare the answer]]
^da-Q0185

**da-Q0186 · Explain the grammar**

Jeg 【er】 uafhængig journalist.

I'm a freelance journalist.

[[Danish#^da-Q0186-answer|Compare the answer]]
^da-Q0186

**da-Q0187 · Fill the gap**

Hvad ville du gøre hvis jeg ____ dig utro?

What would you do if I were untrue to you?

[[Danish#^da-Q0187-answer|Compare the answer]]
^da-Q0187

**da-Q0188 · Choose the form**

Hvad ville du gøre hvis jeg ____ dig utro?

What would you do if I were untrue to you?

Choices: var / været / er

[[Danish#^da-Q0188-answer|Compare the answer]]
^da-Q0188

**da-Q0189 · Edit the changed sentence**

Tom 【var】 ikke jøde.

Tom isn't a Jew.

[[Danish#^da-Q0189-answer|Compare the answer]]
^da-Q0189

**da-Q0190 · Build the sentence**

Arrange: ikke / jøde. / Tom / er

Tom isn't a Jew.

[[Danish#^da-Q0190-answer|Compare the answer]]
^da-Q0190

**da-Q0191 · Write a translation**

Write this in Danish: Tom is my best friend.

[[Danish#^da-Q0191-answer|Compare the answer]]
^da-Q0191

**da-Q0192 · Explain the grammar**

Tom 【er】 min bedste ven.

Tom is my best friend.

[[Danish#^da-Q0192-answer|Compare the answer]]
^da-Q0192

**da-Q0193 · Fill the gap**

Tom ____ ikke Trump.

Tom is not Trump.

[[Danish#^da-Q0193-answer|Compare the answer]]
^da-Q0193

**da-Q0194 · Choose the form**

Tom ____ ikke Trump.

Tom is not Trump.

Choices: er / været / var

[[Danish#^da-Q0194-answer|Compare the answer]]
^da-Q0194

**da-Q0195 · Edit the changed sentence**

Han 【var】 syndebukken.

He's the scapegoat.

[[Danish#^da-Q0195-answer|Compare the answer]]
^da-Q0195

**da-Q0196 · Build the sentence**

Arrange: syndebukken. / er / Han

He's the scapegoat.

[[Danish#^da-Q0196-answer|Compare the answer]]
^da-Q0196

**da-Q0197 · Write a translation**

Write this in Danish: Sami was a YouTuber.

[[Danish#^da-Q0197-answer|Compare the answer]]
^da-Q0197

**da-Q0198 · Explain the grammar**

Sami 【var】 youtuber.

Sami was a YouTuber.

[[Danish#^da-Q0198-answer|Compare the answer]]
^da-Q0198

**da-Q0199 · Fill the gap**

Lagnerne ____ gennemblødt af sved.

The sheets were soaked with sweat.

[[Danish#^da-Q0199-answer|Compare the answer]]
^da-Q0199

**da-Q0200 · Choose the form**

Lagnerne ____ gennemblødt af sved.

The sheets were soaked with sweat.

Choices: var / været / er

[[Danish#^da-Q0200-answer|Compare the answer]]
^da-Q0200


### Have forms · 50 questions

**da-Q0201 · Edit the changed sentence**

Hun 【havde】 blondt hår.

She has blonde hair.

[[Danish#^da-Q0201-answer|Compare the answer]]
^da-Q0201

**da-Q0202 · Build the sentence**

Arrange: hår. / Hun / har / blondt

She has blonde hair.

[[Danish#^da-Q0202-answer|Compare the answer]]
^da-Q0202

**da-Q0203 · Write a translation**

Write this in Danish: Everybody was very busy.

[[Danish#^da-Q0203-answer|Compare the answer]]
^da-Q0203

**da-Q0204 · Explain the grammar**

Alle 【havde】 meget travlt.

Everybody was very busy.

[[Danish#^da-Q0204-answer|Compare the answer]]
^da-Q0204

**da-Q0205 · Fill the gap**

Kunden ____ ikke altid ret.

The customer isn't always right.

[[Danish#^da-Q0205-answer|Compare the answer]]
^da-Q0205

**da-Q0206 · Choose the form**

Kunden ____ ikke altid ret.

The customer isn't always right.

Choices: haft / havde / har

[[Danish#^da-Q0206-answer|Compare the answer]]
^da-Q0206

**da-Q0207 · Edit the changed sentence**

Ekstremister 【havde】 bortført præsidentens hustru.

Extremists kidnapped the president's wife.

[[Danish#^da-Q0207-answer|Compare the answer]]
^da-Q0207

**da-Q0208 · Build the sentence**

Arrange: hustru. / Ekstremister / bortført / har / præsidentens

Extremists kidnapped the president's wife.

[[Danish#^da-Q0208-answer|Compare the answer]]
^da-Q0208

**da-Q0209 · Write a translation**

Write this in Danish: I haven't eaten all day.

[[Danish#^da-Q0209-answer|Compare the answer]]
^da-Q0209

**da-Q0210 · Explain the grammar**

Jeg 【har】 ikke spist hele dagen.

I haven't eaten all day.

[[Danish#^da-Q0210-answer|Compare the answer]]
^da-Q0210

**da-Q0211 · Fill the gap**

Du ____ ikke feber.

You have no fever.

[[Danish#^da-Q0211-answer|Compare the answer]]
^da-Q0211

**da-Q0212 · Choose the form**

Du ____ ikke feber.

You have no fever.

Choices: har / havde / haft

[[Danish#^da-Q0212-answer|Compare the answer]]
^da-Q0212

**da-Q0213 · Edit the changed sentence**

Tro ikke jeg ikke 【havde】 prøvet.

Don't think I didn't try.

[[Danish#^da-Q0213-answer|Compare the answer]]
^da-Q0213

**da-Q0214 · Build the sentence**

Arrange: jeg / prøvet. / har / ikke / ikke / Tro

Don't think I didn't try.

[[Danish#^da-Q0214-answer|Compare the answer]]
^da-Q0214

**da-Q0215 · Write a translation**

Write this in Danish: He explained in detail what he had seen.

[[Danish#^da-Q0215-answer|Compare the answer]]
^da-Q0215

**da-Q0216 · Explain the grammar**

Han forklarede detaljeret, hvad han 【havde】 set.

He explained in detail what he had seen.

[[Danish#^da-Q0216-answer|Compare the answer]]
^da-Q0216

**da-Q0217 · Fill the gap**

Jeg ____ noget som jeg vil fortælle dig.

I have something I want to tell you.

[[Danish#^da-Q0217-answer|Compare the answer]]
^da-Q0217

**da-Q0218 · Choose the form**

Jeg ____ noget som jeg vil fortælle dig.

I have something I want to tell you.

Choices: havde / haft / har

[[Danish#^da-Q0218-answer|Compare the answer]]
^da-Q0218

**da-Q0219 · Edit the changed sentence**

Tom 【havde】 en overraskelse til dig.

Tom has a surprise for you.

[[Danish#^da-Q0219-answer|Compare the answer]]
^da-Q0219

**da-Q0220 · Build the sentence**

Arrange: har / overraskelse / til / en / dig. / Tom

Tom has a surprise for you.

[[Danish#^da-Q0220-answer|Compare the answer]]
^da-Q0220

**da-Q0221 · Write a translation**

Write this in Danish: God has a plan for you.

[[Danish#^da-Q0221-answer|Compare the answer]]
^da-Q0221

**da-Q0222 · Explain the grammar**

Gud 【har】 en plan for jer.

God has a plan for you.

[[Danish#^da-Q0222-answer|Compare the answer]]
^da-Q0222

**da-Q0223 · Fill the gap**

Jeg ____ været over det hele.

I've been all over.

[[Danish#^da-Q0223-answer|Compare the answer]]
^da-Q0223

**da-Q0224 · Choose the form**

Jeg ____ været over det hele.

I've been all over.

Choices: haft / havde / har

[[Danish#^da-Q0224-answer|Compare the answer]]
^da-Q0224

**da-Q0225 · Edit the changed sentence**

Fordi min cykel 【har】 et fladt dæk, missede jeg syvtoget.

My bicycle had a flat tire, so I missed the seven o'clock train.

[[Danish#^da-Q0225-answer|Compare the answer]]
^da-Q0225

**da-Q0226 · Build the sentence**

Arrange: havde / et / syvtoget. / missede / fladt / dæk, / min / jeg / Fordi / cykel

My bicycle had a flat tire, so I missed the seven o'clock train.

[[Danish#^da-Q0226-answer|Compare the answer]]
^da-Q0226

**da-Q0227 · Write a translation**

Write this in Danish: I haven't read either of his novels.

[[Danish#^da-Q0227-answer|Compare the answer]]
^da-Q0227

**da-Q0228 · Explain the grammar**

Jeg 【har】 ikke læst nogen af hans to romaner.

I haven't read either of his novels.

[[Danish#^da-Q0228-answer|Compare the answer]]
^da-Q0228

**da-Q0229 · Fill the gap**

Hvor ____ du gemt julegaven?

Where have you hidden the Christmas present?

[[Danish#^da-Q0229-answer|Compare the answer]]
^da-Q0229

**da-Q0230 · Choose the form**

Hvor ____ du gemt julegaven?

Where have you hidden the Christmas present?

Choices: havde / haft / har

[[Danish#^da-Q0230-answer|Compare the answer]]
^da-Q0230

**da-Q0231 · Edit the changed sentence**

Jeg 【havde】 hovedpine.

I have a headache.

[[Danish#^da-Q0231-answer|Compare the answer]]
^da-Q0231

**da-Q0232 · Build the sentence**

Arrange: har / hovedpine. / Jeg

I have a headache.

[[Danish#^da-Q0232-answer|Compare the answer]]
^da-Q0232

**da-Q0233 · Write a translation**

Write this in Danish: I've seen him before.

[[Danish#^da-Q0233-answer|Compare the answer]]
^da-Q0233

**da-Q0234 · Explain the grammar**

Jeg 【har】 set ham før.

I've seen him before.

[[Danish#^da-Q0234-answer|Compare the answer]]
^da-Q0234

**da-Q0235 · Fill the gap**

I slutningen af ​​oktober blev en græsk journalist, der i sit eget tidsskrift ____ offentliggjort navnene på mere end to tusinde skatteunddragere, arresteret.

By the end of October a Greek journalist who had published the names of over two thousand tax evaders in his own magazine was arrested.

[[Danish#^da-Q0235-answer|Compare the answer]]
^da-Q0235

**da-Q0236 · Choose the form**

I slutningen af ​​oktober blev en græsk journalist, der i sit eget tidsskrift ____ offentliggjort navnene på mere end to tusinde skatteunddragere, arresteret.

By the end of October a Greek journalist who had published the names of over two thousand tax evaders in his own magazine was arrested.

Choices: har / haft / havde

[[Danish#^da-Q0236-answer|Compare the answer]]
^da-Q0236

**da-Q0237 · Edit the changed sentence**

Jeg 【havde】 advaret dem imod at komme her.

I warned them not to come here.

[[Danish#^da-Q0237-answer|Compare the answer]]
^da-Q0237

**da-Q0238 · Build the sentence**

Arrange: imod / at / komme / her. / dem / advaret / Jeg / har

I warned them not to come here.

[[Danish#^da-Q0238-answer|Compare the answer]]
^da-Q0238

**da-Q0239 · Write a translation**

Write this in Danish: Tom has asked me to come to his house tomorrow.

[[Danish#^da-Q0239-answer|Compare the answer]]
^da-Q0239

**da-Q0240 · Explain the grammar**

Tom 【har】 bedt mig om at komme hjem til ham i morgen.

Tom has asked me to come to his house tomorrow.

[[Danish#^da-Q0240-answer|Compare the answer]]
^da-Q0240

**da-Q0241 · Fill the gap**

Jeg tror, nogen ____ spædet punchen op.

I think someone spiked the punch.

[[Danish#^da-Q0241-answer|Compare the answer]]
^da-Q0241

**da-Q0242 · Choose the form**

Jeg tror, nogen ____ spædet punchen op.

I think someone spiked the punch.

Choices: havde / har / haft

[[Danish#^da-Q0242-answer|Compare the answer]]
^da-Q0242

**da-Q0243 · Edit the changed sentence**

Hvorfor 【havde】 du valgt at bo i Australien?

Why did you choose to live in Australia?

[[Danish#^da-Q0243-answer|Compare the answer]]
^da-Q0243

**da-Q0244 · Build the sentence**

Arrange: at / du / Hvorfor / Australien? / valgt / har / bo / i

Why did you choose to live in Australia?

[[Danish#^da-Q0244-answer|Compare the answer]]
^da-Q0244

**da-Q0245 · Write a translation**

Write this in Danish: Why do the largest banks need the biggest bailout?

[[Danish#^da-Q0245-answer|Compare the answer]]
^da-Q0245

**da-Q0246 · Explain the grammar**

Hvorfor 【har】 de største banker brug for den største redningspakke?

Why do the largest banks need the biggest bailout?

[[Danish#^da-Q0246-answer|Compare the answer]]
^da-Q0246

**da-Q0247 · Fill the gap**

Vi ____ noget endnu bedre.

We have something even better.

[[Danish#^da-Q0247-answer|Compare the answer]]
^da-Q0247

**da-Q0248 · Choose the form**

Vi ____ noget endnu bedre.

We have something even better.

Choices: haft / havde / har

[[Danish#^da-Q0248-answer|Compare the answer]]
^da-Q0248

**da-Q0249 · Edit the changed sentence**

Han glemmer tit hvad han 【havde】 lovet.

He will often forget his promise.

[[Danish#^da-Q0249-answer|Compare the answer]]
^da-Q0249

**da-Q0250 · Build the sentence**

Arrange: Han / glemmer / hvad / tit / har / lovet. / han

He will often forget his promise.

[[Danish#^da-Q0250-answer|Compare the answer]]
^da-Q0250


### Main-clause negation · 50 questions

**da-Q0251 · Write a translation**

Write this in Danish: Tom can't drive a car yet.

[[Danish#^da-Q0251-answer|Compare the answer]]
^da-Q0251

**da-Q0252 · Explain the grammar**

Tom kan endnu 【ikke】 køre bil.

Tom can't drive a car yet.

[[Danish#^da-Q0252-answer|Compare the answer]]
^da-Q0252

**da-Q0253 · Fill the gap**

Tom drak ____ noget.

Tom didn't drink anything.

[[Danish#^da-Q0253-answer|Compare the answer]]
^da-Q0253

**da-Q0254 · Choose the form**

Tom drak ____ noget.

Tom didn't drink anything.

Choices: aldrig / ikke / altid

[[Danish#^da-Q0254-answer|Compare the answer]]
^da-Q0254

**da-Q0255 · Edit the changed sentence**

Lyt 【aldrig】 til dem.

Don't listen to them.

[[Danish#^da-Q0255-answer|Compare the answer]]
^da-Q0255

**da-Q0256 · Build the sentence**

Arrange: dem. / til / Lyt / ikke

Don't listen to them.

[[Danish#^da-Q0256-answer|Compare the answer]]
^da-Q0256

**da-Q0257 · Write a translation**

Write this in Danish: Don't be so hard on yourself.

[[Danish#^da-Q0257-answer|Compare the answer]]
^da-Q0257

**da-Q0258 · Explain the grammar**

Vær 【ikke】 så hård ved dig selv!

Don't be so hard on yourself.

[[Danish#^da-Q0258-answer|Compare the answer]]
^da-Q0258

**da-Q0259 · Fill the gap**

Tom er ____ villig til at fortælle sandheden.

Tom isn't willing to tell the truth.

[[Danish#^da-Q0259-answer|Compare the answer]]
^da-Q0259

**da-Q0260 · Choose the form**

Tom er ____ villig til at fortælle sandheden.

Tom isn't willing to tell the truth.

Choices: ikke / aldrig / altid

[[Danish#^da-Q0260-answer|Compare the answer]]
^da-Q0260

**da-Q0261 · Edit the changed sentence**

Det er 【aldrig】 lovstridigt.

It's not against the law.

[[Danish#^da-Q0261-answer|Compare the answer]]
^da-Q0261

**da-Q0262 · Build the sentence**

Arrange: lovstridigt. / Det / ikke / er

It's not against the law.

[[Danish#^da-Q0262-answer|Compare the answer]]
^da-Q0262

**da-Q0263 · Write a translation**

Write this in Danish: Jim doesn't like apples, does he?

[[Danish#^da-Q0263-answer|Compare the answer]]
^da-Q0263

**da-Q0264 · Explain the grammar**

Jim kan 【ikke】 lide æbler, kan han vel?

Jim doesn't like apples, does he?

[[Danish#^da-Q0264-answer|Compare the answer]]
^da-Q0264

**da-Q0265 · Fill the gap**

Nu ved vi ____ hvad vi skal lave.

Now we don't know what to do.

[[Danish#^da-Q0265-answer|Compare the answer]]
^da-Q0265

**da-Q0266 · Choose the form**

Nu ved vi ____ hvad vi skal lave.

Now we don't know what to do.

Choices: altid / ikke / aldrig

[[Danish#^da-Q0266-answer|Compare the answer]]
^da-Q0266

**da-Q0267 · Edit the changed sentence**

Hun kom 【aldrig】.

She did not come.

[[Danish#^da-Q0267-answer|Compare the answer]]
^da-Q0267

**da-Q0268 · Build the sentence**

Arrange: ikke. / kom / Hun

She did not come.

[[Danish#^da-Q0268-answer|Compare the answer]]
^da-Q0268

**da-Q0269 · Write a translation**

Write this in Danish: No idea.

[[Danish#^da-Q0269-answer|Compare the answer]]
^da-Q0269

**da-Q0270 · Explain the grammar**

Aner det 【ikke】.

No idea.

[[Danish#^da-Q0270-answer|Compare the answer]]
^da-Q0270

**da-Q0271 · Fill the gap**

Jeg forstår ____ selv hvordan det er sket.

I myself do not understand how it happened.

[[Danish#^da-Q0271-answer|Compare the answer]]
^da-Q0271

**da-Q0272 · Choose the form**

Jeg forstår ____ selv hvordan det er sket.

I myself do not understand how it happened.

Choices: ikke / aldrig / altid

[[Danish#^da-Q0272-answer|Compare the answer]]
^da-Q0272

**da-Q0273 · Edit the changed sentence**

Han ønskede at sige noget til hende, men han vidste 【aldrig】 hvad han skulle sige.

He wanted to say something to her, but he didn't know what to say.

[[Danish#^da-Q0273-answer|Compare the answer]]
^da-Q0273

**da-Q0274 · Build the sentence**

Arrange: vidste / at / men / han / ikke / noget / sige. / Han / han / hvad / hende, / til / ønskede / skulle / sige

He wanted to say something to her, but he didn't know what to say.

[[Danish#^da-Q0274-answer|Compare the answer]]
^da-Q0274

**da-Q0275 · Write a translation**

Write this in Danish: I can't think of any alternatives.

[[Danish#^da-Q0275-answer|Compare the answer]]
^da-Q0275

**da-Q0276 · Explain the grammar**

Jeg kan 【ikke】 forestille mig nogen alternativer.

I can't think of any alternatives.

[[Danish#^da-Q0276-answer|Compare the answer]]
^da-Q0276

**da-Q0277 · Fill the gap**

Jeg kan ____ høre et ord.

I can't hear a word.

[[Danish#^da-Q0277-answer|Compare the answer]]
^da-Q0277

**da-Q0278 · Choose the form**

Jeg kan ____ høre et ord.

I can't hear a word.

Choices: altid / aldrig / ikke

[[Danish#^da-Q0278-answer|Compare the answer]]
^da-Q0278

**da-Q0279 · Edit the changed sentence**

Jeg er bange for at det 【aldrig】 er så let.

I am afraid it's not so easy.

[[Danish#^da-Q0279-answer|Compare the answer]]
^da-Q0279

**da-Q0280 · Build the sentence**

Arrange: er / ikke / for / at / bange / er / Jeg / så / let. / det

I am afraid it's not so easy.

[[Danish#^da-Q0280-answer|Compare the answer]]
^da-Q0280

**da-Q0281 · Write a translation**

Write this in Danish: Why don't we try and get a few hours sleep?

[[Danish#^da-Q0281-answer|Compare the answer]]
^da-Q0281

**da-Q0282 · Explain the grammar**

Hvorfor forsøger vi 【ikke】 at få et par timers søvn?

Why don't we try and get a few hours sleep?

[[Danish#^da-Q0282-answer|Compare the answer]]
^da-Q0282

**da-Q0283 · Fill the gap**

Tom drak ____ mælken.

Tom didn't drink the milk.

[[Danish#^da-Q0283-answer|Compare the answer]]
^da-Q0283

**da-Q0284 · Choose the form**

Tom drak ____ mælken.

Tom didn't drink the milk.

Choices: aldrig / ikke / altid

[[Danish#^da-Q0284-answer|Compare the answer]]
^da-Q0284

**da-Q0285 · Edit the changed sentence**

Vi kan endnu 【aldrig】 oversætte fra esperanto til dansk.

We can't yet translate from Esperanto to Danish.

[[Danish#^da-Q0285-answer|Compare the answer]]
^da-Q0285

**da-Q0286 · Build the sentence**

Arrange: ikke / kan / Vi / endnu / oversætte / esperanto / dansk. / til / fra

We can't yet translate from Esperanto to Danish.

[[Danish#^da-Q0286-answer|Compare the answer]]
^da-Q0286

**da-Q0287 · Write a translation**

Write this in Danish: The United States have been dubbed the "world policeman", but some American intellectuals do not hesitate to call their own country "rogue state."

[[Danish#^da-Q0287-answer|Compare the answer]]
^da-Q0287

**da-Q0288 · Explain the grammar**

USA er blevet kaldt »verdens politimand«, men nogle amerikanske intellektuelle tøver 【ikke】 med at kalde deres eget land en »slyngelstat«.

The United States have been dubbed the "world policeman", but some American intellectuals do not hesitate to call their own country "rogue state."

[[Danish#^da-Q0288-answer|Compare the answer]]
^da-Q0288

**da-Q0289 · Fill the gap**

Jeg skrev hans navn ned for at jeg ____ skulle glemme det.

I wrote down his name so I wouldn't forget it.

[[Danish#^da-Q0289-answer|Compare the answer]]
^da-Q0289

**da-Q0290 · Choose the form**

Jeg skrev hans navn ned for at jeg ____ skulle glemme det.

I wrote down his name so I wouldn't forget it.

Choices: altid / ikke / aldrig

[[Danish#^da-Q0290-answer|Compare the answer]]
^da-Q0290

**da-Q0291 · Edit the changed sentence**

Du stemte 【aldrig】, gjorde du vel?

You didn't vote, did you?

[[Danish#^da-Q0291-answer|Compare the answer]]
^da-Q0291

**da-Q0292 · Build the sentence**

Arrange: ikke, / gjorde / du / stemte / vel? / Du

You didn't vote, did you?

[[Danish#^da-Q0292-answer|Compare the answer]]
^da-Q0292

**da-Q0293 · Write a translation**

Write this in Danish: Tom and I aren't that stupid.

[[Danish#^da-Q0293-answer|Compare the answer]]
^da-Q0293

**da-Q0294 · Explain the grammar**

Tom og jeg er 【ikke】 så dumme.

Tom and I aren't that stupid.

[[Danish#^da-Q0294-answer|Compare the answer]]
^da-Q0294

**da-Q0295 · Fill the gap**

Dit navn er Tom, ____ sandt?

Your name is Tom, right?

[[Danish#^da-Q0295-answer|Compare the answer]]
^da-Q0295

**da-Q0296 · Choose the form**

Dit navn er Tom, ____ sandt?

Your name is Tom, right?

Choices: aldrig / ikke / altid

[[Danish#^da-Q0296-answer|Compare the answer]]
^da-Q0296

**da-Q0297 · Edit the changed sentence**

Tom opfører sig som om han 【aldrig】 ønsker at blive set sammen med os.

Tom acts like he doesn't want to be seen with us.

[[Danish#^da-Q0297-answer|Compare the answer]]
^da-Q0297

**da-Q0298 · Build the sentence**

Arrange: set / ikke / han / sig / ønsker / blive / med / om / at / Tom / sammen / opfører / som / os.

Tom acts like he doesn't want to be seen with us.

[[Danish#^da-Q0298-answer|Compare the answer]]
^da-Q0298

**da-Q0299 · Write a translation**

Write this in Danish: I don't want him to leave.

[[Danish#^da-Q0299-answer|Compare the answer]]
^da-Q0299

**da-Q0300 · Explain the grammar**

Jeg ønsker 【ikke】 at han tager afsted.

I don't want him to leave.

[[Danish#^da-Q0300-answer|Compare the answer]]
^da-Q0300


### Subordinate connectors · 50 questions

**da-Q0301 · Fill the gap**

Hun nægtede ____ skrive under på andragendet.

She refused to sign the petition.

[[Danish#^da-Q0301-answer|Compare the answer]]
^da-Q0301

**da-Q0302 · Choose the form**

Hun nægtede ____ skrive under på andragendet.

She refused to sign the petition.

Choices: når / at / fordi / hvis

[[Danish#^da-Q0302-answer|Compare the answer]]
^da-Q0302

**da-Q0303 · Edit the changed sentence**

Sami forsøgte 【fordi】 sælge sin bil.

Sami tried to sell his car.

[[Danish#^da-Q0303-answer|Compare the answer]]
^da-Q0303

**da-Q0304 · Build the sentence**

Arrange: sin / bil. / Sami / forsøgte / at / sælge

Sami tried to sell his car.

[[Danish#^da-Q0304-answer|Compare the answer]]
^da-Q0304

**da-Q0305 · Write a translation**

Write this in Danish: I assumed she was your girlfriend.

[[Danish#^da-Q0305-answer|Compare the answer]]
^da-Q0305

**da-Q0306 · Explain the grammar**

Jeg antog 【at】 hun var din kæreste.

I assumed she was your girlfriend.

[[Danish#^da-Q0306-answer|Compare the answer]]
^da-Q0306

**da-Q0307 · Fill the gap**

Det er vanskeligt for mig ____ udtale ordet.

It is difficult for me to pronounce the word.

[[Danish#^da-Q0307-answer|Compare the answer]]
^da-Q0307

**da-Q0308 · Choose the form**

Det er vanskeligt for mig ____ udtale ordet.

It is difficult for me to pronounce the word.

Choices: fordi / hvis / at / når

[[Danish#^da-Q0308-answer|Compare the answer]]
^da-Q0308

**da-Q0309 · Edit the changed sentence**

Tom sagde 【fordi】 han ville dræbe Mary.

Tom said he was going to kill Mary.

[[Danish#^da-Q0309-answer|Compare the answer]]
^da-Q0309

**da-Q0310 · Build the sentence**

Arrange: dræbe / at / han / ville / sagde / Tom / Mary.

Tom said he was going to kill Mary.

[[Danish#^da-Q0310-answer|Compare the answer]]
^da-Q0310

**da-Q0311 · Write a translation**

Write this in Danish: She wanted to help her friends.

[[Danish#^da-Q0311-answer|Compare the answer]]
^da-Q0311

**da-Q0312 · Explain the grammar**

Hun ønskede 【at】 hjælpe sine venner.

She wanted to help her friends.

[[Danish#^da-Q0312-answer|Compare the answer]]
^da-Q0312

**da-Q0313 · Fill the gap**

Selv guder dør ____ ingen længere tror på dem.

Even gods die when no one believes in them any longer.

[[Danish#^da-Q0313-answer|Compare the answer]]
^da-Q0313

**da-Q0314 · Choose the form**

Selv guder dør ____ ingen længere tror på dem.

Even gods die when no one believes in them any longer.

Choices: at / når / fordi / hvis

[[Danish#^da-Q0314-answer|Compare the answer]]
^da-Q0314

**da-Q0315 · Edit the changed sentence**

Marys kat behøver kun 【fordi】 hvæse én gang for at jage naboernes hunde på flugt.

Mary's cat needs to hiss only once, to scare away the neighbours' dogs.

[[Danish#^da-Q0315-answer|Compare the answer]]
^da-Q0315

**da-Q0316 · Build the sentence**

Arrange: én / jage / for / gang / hvæse / behøver / at / på / kat / flugt. / Marys / at / kun / naboernes / hunde

Mary's cat needs to hiss only once, to scare away the neighbours' dogs.

[[Danish#^da-Q0316-answer|Compare the answer]]
^da-Q0316

**da-Q0317 · Write a translation**

Write this in Danish: It is best to wash the dishes with environmentally friendly dishwashing liquid.

[[Danish#^da-Q0317-answer|Compare the answer]]
^da-Q0317

**da-Q0318 · Explain the grammar**

Det er bedst 【at】 bruge et økologisk opvaskemiddel når man vasker op.

It is best to wash the dishes with environmentally friendly dishwashing liquid.

[[Danish#^da-Q0318-answer|Compare the answer]]
^da-Q0318

**da-Q0319 · Fill the gap**

Jeg tror ____ du hellere må holde lav profil indtil hun tilgiver dig.

I think you'd better lie low until she forgives you.

[[Danish#^da-Q0319-answer|Compare the answer]]
^da-Q0319

**da-Q0320 · Choose the form**

Jeg tror ____ du hellere må holde lav profil indtil hun tilgiver dig.

I think you'd better lie low until she forgives you.

Choices: hvis / fordi / at / når

[[Danish#^da-Q0320-answer|Compare the answer]]
^da-Q0320

**da-Q0321 · Edit the changed sentence**

Hvad vil du være 【fordi】 du bliver stor?

What will you do when you grow up?

[[Danish#^da-Q0321-answer|Compare the answer]]
^da-Q0321

**da-Q0322 · Build the sentence**

Arrange: vil / når / stor? / Hvad / du / være / bliver / du

What will you do when you grow up?

[[Danish#^da-Q0322-answer|Compare the answer]]
^da-Q0322

**da-Q0323 · Write a translation**

Write this in Danish: I can see you're in a good mood.

[[Danish#^da-Q0323-answer|Compare the answer]]
^da-Q0323

**da-Q0324 · Explain the grammar**

Jeg kan se 【at】 du er i godt humør.

I can see you're in a good mood.

[[Danish#^da-Q0324-answer|Compare the answer]]
^da-Q0324

**da-Q0325 · Fill the gap**

De er nødt til ____ tage konsekvenserne af deres handlinger.

They need to face the consequences.

[[Danish#^da-Q0325-answer|Compare the answer]]
^da-Q0325

**da-Q0326 · Choose the form**

De er nødt til ____ tage konsekvenserne af deres handlinger.

They need to face the consequences.

Choices: fordi / når / hvis / at

[[Danish#^da-Q0326-answer|Compare the answer]]
^da-Q0326

**da-Q0327 · Edit the changed sentence**

Han gør aldrig noget uden 【fordi】 hun får færten af det.

He never does anything but she smells it out.

[[Danish#^da-Q0327-answer|Compare the answer]]
^da-Q0327

**da-Q0328 · Build the sentence**

Arrange: Han / det. / får / uden / hun / færten / noget / at / aldrig / gør / af

He never does anything but she smells it out.

[[Danish#^da-Q0328-answer|Compare the answer]]
^da-Q0328

**da-Q0329 · Write a translation**

Write this in Danish: Would you please help me translate this?

[[Danish#^da-Q0329-answer|Compare the answer]]
^da-Q0329

**da-Q0330 · Explain the grammar**

Vil du være så venlig 【at】 hjælpe mig med at oversætte dette?

Would you please help me translate this?

[[Danish#^da-Q0330-answer|Compare the answer]]
^da-Q0330

**da-Q0331 · Fill the gap**

Tom venter på ____ se, hvad der vil ske.

Tom is waiting to see what will happen.

[[Danish#^da-Q0331-answer|Compare the answer]]
^da-Q0331

**da-Q0332 · Choose the form**

Tom venter på ____ se, hvad der vil ske.

Tom is waiting to see what will happen.

Choices: hvis / fordi / når / at

[[Danish#^da-Q0332-answer|Compare the answer]]
^da-Q0332

**da-Q0333 · Edit the changed sentence**

Er det en forbrydelse 【fordi】 brænde det amerikanske flag af i USA?

Is it a crime to burn the American flag in the United States?

[[Danish#^da-Q0333-answer|Compare the answer]]
^da-Q0333

**da-Q0334 · Build the sentence**

Arrange: USA? / det / forbrydelse / amerikanske / at / det / brænde / i / af / en / Er / flag

Is it a crime to burn the American flag in the United States?

[[Danish#^da-Q0334-answer|Compare the answer]]
^da-Q0334

**da-Q0335 · Write a translation**

Write this in Danish: You should know, I am in love with Mary.

[[Danish#^da-Q0335-answer|Compare the answer]]
^da-Q0335

**da-Q0336 · Explain the grammar**

Du skal vide 【at】 jeg er forelsket i Mary.

You should know, I am in love with Mary.

[[Danish#^da-Q0336-answer|Compare the answer]]
^da-Q0336

**da-Q0337 · Fill the gap**

Hvordan træner du en kat til ____ bruge en kattebakke?

How do you train a cat to use a litter box?

[[Danish#^da-Q0337-answer|Compare the answer]]
^da-Q0337

**da-Q0338 · Choose the form**

Hvordan træner du en kat til ____ bruge en kattebakke?

How do you train a cat to use a litter box?

Choices: når / fordi / hvis / at

[[Danish#^da-Q0338-answer|Compare the answer]]
^da-Q0338

**da-Q0339 · Edit the changed sentence**

Den eneste fisk Tom kan lide 【fordi】 spise, er laks.

The only fish Tom likes to eat is salmon.

[[Danish#^da-Q0339-answer|Compare the answer]]
^da-Q0339

**da-Q0340 · Build the sentence**

Arrange: er / at / lide / spise, / fisk / kan / eneste / laks. / Tom / Den

The only fish Tom likes to eat is salmon.

[[Danish#^da-Q0340-answer|Compare the answer]]
^da-Q0340

**da-Q0341 · Write a translation**

Write this in Danish: Of the three candidates, I think Mr Smith is the best.

[[Danish#^da-Q0341-answer|Compare the answer]]
^da-Q0341

**da-Q0342 · Explain the grammar**

Af de tre kandidater mener jeg 【at】 hr. Smith er den bedste.

Of the three candidates, I think Mr Smith is the best.

[[Danish#^da-Q0342-answer|Compare the answer]]
^da-Q0342

**da-Q0343 · Fill the gap**

Jeg tror ____ vi vinder.

I think we'll win.

[[Danish#^da-Q0343-answer|Compare the answer]]
^da-Q0343

**da-Q0344 · Choose the form**

Jeg tror ____ vi vinder.

I think we'll win.

Choices: hvis / at / fordi / når

[[Danish#^da-Q0344-answer|Compare the answer]]
^da-Q0344

**da-Q0345 · Edit the changed sentence**

Hold op med 【fordi】 drille Tom.

Stop teasing Tom.

[[Danish#^da-Q0345-answer|Compare the answer]]
^da-Q0345

**da-Q0346 · Build the sentence**

Arrange: op / drille / med / at / Tom. / Hold

Stop teasing Tom.

[[Danish#^da-Q0346-answer|Compare the answer]]
^da-Q0346

**da-Q0347 · Write a translation**

Write this in Danish: How did you learn how to play the violin?

[[Danish#^da-Q0347-answer|Compare the answer]]
^da-Q0347

**da-Q0348 · Explain the grammar**

Hvordan lærte du 【at】 spille på violin?

How did you learn how to play the violin?

[[Danish#^da-Q0348-answer|Compare the answer]]
^da-Q0348

**da-Q0349 · Fill the gap**

Det glæder mig ____ se dig.

I am pleased to see you.

[[Danish#^da-Q0349-answer|Compare the answer]]
^da-Q0349

**da-Q0350 · Choose the form**

Det glæder mig ____ se dig.

I am pleased to see you.

Choices: hvis / når / fordi / at

[[Danish#^da-Q0350-answer|Compare the answer]]
^da-Q0350


### Coordination · 50 questions

**da-Q0351 · Edit the changed sentence**

Tak 【og】 indsatsen.

Thanks for the effort.

[[Danish#^da-Q0351-answer|Compare the answer]]
^da-Q0351

**da-Q0352 · Build the sentence**

Arrange: for / indsatsen. / Tak

Thanks for the effort.

[[Danish#^da-Q0352-answer|Compare the answer]]
^da-Q0352

**da-Q0353 · Write a translation**

Write this in Danish: He looked right and left.

[[Danish#^da-Q0353-answer|Compare the answer]]
^da-Q0353

**da-Q0354 · Explain the grammar**

Han så til højre 【og】 gik.

He looked right and left.

[[Danish#^da-Q0354-answer|Compare the answer]]
^da-Q0354

**da-Q0355 · Fill the gap**

Min bror taler ____ meget.

My brother talks too much.

[[Danish#^da-Q0355-answer|Compare the answer]]
^da-Q0355

**da-Q0356 · Choose the form**

Min bror taler ____ meget.

My brother talks too much.

Choices: for / men / eller / og

[[Danish#^da-Q0356-answer|Compare the answer]]
^da-Q0356

**da-Q0357 · Edit the changed sentence**

Du betyder alt 【og】 mig. Det gør du virkelig!

You mean the world to me, you really do.

[[Danish#^da-Q0357-answer|Compare the answer]]
^da-Q0357

**da-Q0358 · Build the sentence**

Arrange: gør / for / Det / du / alt / mig. / betyder / Du / virkelig!

You mean the world to me, you really do.

[[Danish#^da-Q0358-answer|Compare the answer]]
^da-Q0358

**da-Q0359 · Write a translation**

Write this in Danish: The sun set a while ago.

[[Danish#^da-Q0359-answer|Compare the answer]]
^da-Q0359

**da-Q0360 · Explain the grammar**

Solen gik ned 【for】 et stykke tid siden.

The sun set a while ago.

[[Danish#^da-Q0360-answer|Compare the answer]]
^da-Q0360

**da-Q0361 · Fill the gap**

Bedstefar åbnede bilens vindue ____ sigtede på en fugl med geværet.

Grandfather opened the car window and aimed the gun at a bird.

[[Danish#^da-Q0361-answer|Compare the answer]]
^da-Q0361

**da-Q0362 · Choose the form**

Bedstefar åbnede bilens vindue ____ sigtede på en fugl med geværet.

Grandfather opened the car window and aimed the gun at a bird.

Choices: for / eller / og / men

[[Danish#^da-Q0362-answer|Compare the answer]]
^da-Q0362

**da-Q0363 · Edit the changed sentence**

Den Engelske Kanal skiller England 【men】 Frankrig.

The English Channel separates England and France.

[[Danish#^da-Q0363-answer|Compare the answer]]
^da-Q0363

**da-Q0364 · Build the sentence**

Arrange: Kanal / Frankrig. / Engelske / og / Den / England / skiller

The English Channel separates England and France.

[[Danish#^da-Q0364-answer|Compare the answer]]
^da-Q0364

**da-Q0365 · Write a translation**

Write this in Danish: It's too big.

[[Danish#^da-Q0365-answer|Compare the answer]]
^da-Q0365

**da-Q0366 · Explain the grammar**

Den er 【for】 stor.

It's too big.

[[Danish#^da-Q0366-answer|Compare the answer]]
^da-Q0366

**da-Q0367 · Fill the gap**

Da Tom satte sig, stødte han til bordet, ____ hans kaffe blev spildt ud over dugen.

As Tom sat down, he bumped the table and his coffee spilled onto the tablecloth.

[[Danish#^da-Q0367-answer|Compare the answer]]
^da-Q0367

**da-Q0368 · Choose the form**

Da Tom satte sig, stødte han til bordet, ____ hans kaffe blev spildt ud over dugen.

As Tom sat down, he bumped the table and his coffee spilled onto the tablecloth.

Choices: men / eller / for / og

[[Danish#^da-Q0368-answer|Compare the answer]]
^da-Q0368

**da-Q0369 · Edit the changed sentence**

Tom købte en pose æbler, 【men】 han spiste en tredjedel af dem på én dag.

Tom bought a bag of apples and he ate a third of them in one day.

[[Danish#^da-Q0369-answer|Compare the answer]]
^da-Q0369

**da-Q0370 · Build the sentence**

Arrange: en / han / på / spiste / en / tredjedel / én / dag. / dem / pose / æbler, / købte / og / af / Tom

Tom bought a bag of apples and he ate a third of them in one day.

[[Danish#^da-Q0370-answer|Compare the answer]]
^da-Q0370

**da-Q0371 · Write a translation**

Write this in Danish: Tomorrow I am going shopping.

[[Danish#^da-Q0371-answer|Compare the answer]]
^da-Q0371

**da-Q0372 · Explain the grammar**

I morgen skal jeg ud 【og】 shoppe.

Tomorrow I am going shopping.

[[Danish#^da-Q0372-answer|Compare the answer]]
^da-Q0372

**da-Q0373 · Fill the gap**

Havet er forurenet af bittesmå plastpartikler der er skadelige ____ havdyr.

The sea is polluted by tiny plastic particles that are harmful to marine animals.

[[Danish#^da-Q0373-answer|Compare the answer]]
^da-Q0373

**da-Q0374 · Choose the form**

Havet er forurenet af bittesmå plastpartikler der er skadelige ____ havdyr.

The sea is polluted by tiny plastic particles that are harmful to marine animals.

Choices: for / og / eller / men

[[Danish#^da-Q0374-answer|Compare the answer]]
^da-Q0374

**da-Q0375 · Edit the changed sentence**

Min skolekammerat skrev af efter mine lektier 【men】 læreren opdagede det.

My friend copied my homework and the teacher found out.

[[Danish#^da-Q0375-answer|Compare the answer]]
^da-Q0375

**da-Q0376 · Build the sentence**

Arrange: af / det. / og / lektier / Min / læreren / opdagede / mine / skolekammerat / skrev / efter

My friend copied my homework and the teacher found out.

[[Danish#^da-Q0376-answer|Compare the answer]]
^da-Q0376

**da-Q0377 · Write a translation**

Write this in Danish: One, two, three, four, five, six, seven, eight, nine, and ten are numbers.

[[Danish#^da-Q0377-answer|Compare the answer]]
^da-Q0377

**da-Q0378 · Explain the grammar**

En, to, tre, fire, fem, seks, syv, otte, ni 【og】 ti er tal.

One, two, three, four, five, six, seven, eight, nine, and ten are numbers.

[[Danish#^da-Q0378-answer|Compare the answer]]
^da-Q0378

**da-Q0379 · Fill the gap**

Vi er meget glade ____ det.

We're very happy about it.

[[Danish#^da-Q0379-answer|Compare the answer]]
^da-Q0379

**da-Q0380 · Choose the form**

Vi er meget glade ____ det.

We're very happy about it.

Choices: for / og / men / eller

[[Danish#^da-Q0380-answer|Compare the answer]]
^da-Q0380

**da-Q0381 · Edit the changed sentence**

Jeg spiser frugter 【men】 drikker vand.

I eat fruit and drink water.

[[Danish#^da-Q0381-answer|Compare the answer]]
^da-Q0381

**da-Q0382 · Build the sentence**

Arrange: drikker / frugter / vand. / Jeg / og / spiser

I eat fruit and drink water.

[[Danish#^da-Q0382-answer|Compare the answer]]
^da-Q0382

**da-Q0383 · Write a translation**

Write this in Danish: Japanese young people like rock and jazz.

[[Danish#^da-Q0383-answer|Compare the answer]]
^da-Q0383

**da-Q0384 · Explain the grammar**

Japanske unge kan godt lide rock 【og】 jazz.

Japanese young people like rock and jazz.

[[Danish#^da-Q0384-answer|Compare the answer]]
^da-Q0384

**da-Q0385 · Fill the gap**

Røde hunde kaldes også »tyske mæslinger« på engelsk, mens tyskerne kalder rakitis dvs. engelsk syge ____ »den engelske syge«.

Rubella is also called 'German measles' in English, while Germans call rickets 'the English disease'.

[[Danish#^da-Q0385-answer|Compare the answer]]
^da-Q0385

**da-Q0386 · Choose the form**

Røde hunde kaldes også »tyske mæslinger« på engelsk, mens tyskerne kalder rakitis dvs. engelsk syge ____ »den engelske syge«.

Rubella is also called 'German measles' in English, while Germans call rickets 'the English disease'.

Choices: eller / for / og / men

[[Danish#^da-Q0386-answer|Compare the answer]]
^da-Q0386

**da-Q0387 · Edit the changed sentence**

Nu 【og】 aldrig!

It's now or never.

[[Danish#^da-Q0387-answer|Compare the answer]]
^da-Q0387

**da-Q0388 · Build the sentence**

Arrange: eller / aldrig! / Nu

It's now or never.

[[Danish#^da-Q0388-answer|Compare the answer]]
^da-Q0388

**da-Q0389 · Write a translation**

Write this in Danish: Ashkenazim experienced a population bottleneck around 700 years ago.

[[Danish#^da-Q0389-answer|Compare the answer]]
^da-Q0389

**da-Q0390 · Explain the grammar**

Askenaserne gennemgik en genetisk flaskehals 【for】 omkring 700 år siden.

Ashkenazim experienced a population bottleneck around 700 years ago.

[[Danish#^da-Q0390-answer|Compare the answer]]
^da-Q0390

**da-Q0391 · Fill the gap**

Af en ____ anden grund kunne jeg ikke tilgå min e-mail.

For some reason I couldn't access my e-mail.

[[Danish#^da-Q0391-answer|Compare the answer]]
^da-Q0391

**da-Q0392 · Choose the form**

Af en ____ anden grund kunne jeg ikke tilgå min e-mail.

For some reason I couldn't access my e-mail.

Choices: og / men / eller / for

[[Danish#^da-Q0392-answer|Compare the answer]]
^da-Q0392

**da-Q0393 · Edit the changed sentence**

Tom 【men】 Mary kommer ikke til festen.

Tom and Mary aren't coming to the party.

[[Danish#^da-Q0393-answer|Compare the answer]]
^da-Q0393

**da-Q0394 · Build the sentence**

Arrange: ikke / festen. / og / Tom / Mary / til / kommer

Tom and Mary aren't coming to the party.

[[Danish#^da-Q0394-answer|Compare the answer]]
^da-Q0394

**da-Q0395 · Write a translation**

Write this in Danish: Say hello to your mum for me.

[[Danish#^da-Q0395-answer|Compare the answer]]
^da-Q0395

**da-Q0396 · Explain the grammar**

Sig goddag til din mor 【for】 mig.

Say hello to your mum for me.

[[Danish#^da-Q0396-answer|Compare the answer]]
^da-Q0396

**da-Q0397 · Fill the gap**

Tom ____ Mary vil holde deres løfte.

Tom and Mary will keep their promise.

[[Danish#^da-Q0397-answer|Compare the answer]]
^da-Q0397

**da-Q0398 · Choose the form**

Tom ____ Mary vil holde deres løfte.

Tom and Mary will keep their promise.

Choices: for / men / eller / og

[[Danish#^da-Q0398-answer|Compare the answer]]
^da-Q0398

**da-Q0399 · Edit the changed sentence**

Han er læge 【men】 tillige forfatter.

He is a doctor and also a novelist.

[[Danish#^da-Q0399-answer|Compare the answer]]
^da-Q0399

**da-Q0400 · Build the sentence**

Arrange: tillige / Han / og / læge / er / forfatter.

He is a doctor and also a novelist.

[[Danish#^da-Q0400-answer|Compare the answer]]
^da-Q0400


### Modals · 50 questions

**da-Q0401 · Write a translation**

Write this in Danish: Tom wants to learn Serbian.

[[Danish#^da-Q0401-answer|Compare the answer]]
^da-Q0401

**da-Q0402 · Explain the grammar**

Tom 【vil】 lære serbisk.

Tom wants to learn Serbian.

[[Danish#^da-Q0402-answer|Compare the answer]]
^da-Q0402

**da-Q0403 · Fill the gap**

Tom ____ sælge sin bil.

Tom wanted to sell his car.

[[Danish#^da-Q0403-answer|Compare the answer]]
^da-Q0403

**da-Q0404 · Choose the form**

Tom ____ sælge sin bil.

Tom wanted to sell his car.

Choices: må / kan / skal / ville

[[Danish#^da-Q0404-answer|Compare the answer]]
^da-Q0404

**da-Q0405 · Edit the changed sentence**

Dit ønske 【kan】 gå i opfyldelse i nær fremtid.

Your wish will come true in the near future.

[[Danish#^da-Q0405-answer|Compare the answer]]
^da-Q0405

**da-Q0406 · Build the sentence**

Arrange: opfyldelse / fremtid. / Dit / ønske / i / nær / i / gå / vil

Your wish will come true in the near future.

[[Danish#^da-Q0406-answer|Compare the answer]]
^da-Q0406

**da-Q0407 · Write a translation**

Write this in Danish: She can speak English, of course.

[[Danish#^da-Q0407-answer|Compare the answer]]
^da-Q0407

**da-Q0408 · Explain the grammar**

Hun 【kan】 selvfølgelig tale engelsk.

She can speak English, of course.

[[Danish#^da-Q0408-answer|Compare the answer]]
^da-Q0408

**da-Q0409 · Fill the gap**

Jeg ____ altid elske dig.

I will always love you.

[[Danish#^da-Q0409-answer|Compare the answer]]
^da-Q0409

**da-Q0410 · Choose the form**

Jeg ____ altid elske dig.

I will always love you.

Choices: kan / skal / vil / må

[[Danish#^da-Q0410-answer|Compare the answer]]
^da-Q0410

**da-Q0411 · Edit the changed sentence**

Der findes mange amerikanere som 【skal】 tale japansk.

There are many Americans who can speak Japanese.

[[Danish#^da-Q0411-answer|Compare the answer]]
^da-Q0411

**da-Q0412 · Build the sentence**

Arrange: som / tale / findes / Der / mange / japansk. / amerikanere / kan

There are many Americans who can speak Japanese.

[[Danish#^da-Q0412-answer|Compare the answer]]
^da-Q0412

**da-Q0413 · Write a translation**

Write this in Danish: Justice must be done.

[[Danish#^da-Q0413-answer|Compare the answer]]
^da-Q0413

**da-Q0414 · Explain the grammar**

Retfærdigheden 【må】 ske fyldest.

Justice must be done.

[[Danish#^da-Q0414-answer|Compare the answer]]
^da-Q0414

**da-Q0415 · Fill the gap**

Jeg ____ hjælpe dig.

I'll help you.

[[Danish#^da-Q0415-answer|Compare the answer]]
^da-Q0415

**da-Q0416 · Choose the form**

Jeg ____ hjælpe dig.

I'll help you.

Choices: må / vil / skal / kan

[[Danish#^da-Q0416-answer|Compare the answer]]
^da-Q0416

**da-Q0417 · Edit the changed sentence**

Tom 【kan】 begynde forfra.

Tom had to start over again.

[[Danish#^da-Q0417-answer|Compare the answer]]
^da-Q0417

**da-Q0418 · Build the sentence**

Arrange: måtte / begynde / forfra. / Tom

Tom had to start over again.

[[Danish#^da-Q0418-answer|Compare the answer]]
^da-Q0418

**da-Q0419 · Write a translation**

Write this in Danish: We need to be cautious.

[[Danish#^da-Q0419-answer|Compare the answer]]
^da-Q0419

**da-Q0420 · Explain the grammar**

Vi 【må】 være forsigtige.

We need to be cautious.

[[Danish#^da-Q0420-answer|Compare the answer]]
^da-Q0420

**da-Q0421 · Fill the gap**

Hvor mange sprog ____ din kone tale?

How many languages does your wife speak?

[[Danish#^da-Q0421-answer|Compare the answer]]
^da-Q0421

**da-Q0422 · Choose the form**

Hvor mange sprog ____ din kone tale?

How many languages does your wife speak?

Choices: må / skal / kan / vil

[[Danish#^da-Q0422-answer|Compare the answer]]
^da-Q0422

**da-Q0423 · Edit the changed sentence**

Du 【kan】 have set noget.

You must've seen something.

[[Danish#^da-Q0423-answer|Compare the answer]]
^da-Q0423

**da-Q0424 · Build the sentence**

Arrange: set / noget. / må / Du / have

You must've seen something.

[[Danish#^da-Q0424-answer|Compare the answer]]
^da-Q0424

**da-Q0425 · Write a translation**

Write this in Danish: I'd like to buy a refrigerator.

[[Danish#^da-Q0425-answer|Compare the answer]]
^da-Q0425

**da-Q0426 · Explain the grammar**

Jeg 【vil】 gerne købe et køleskab.

I'd like to buy a refrigerator.

[[Danish#^da-Q0426-answer|Compare the answer]]
^da-Q0426

**da-Q0427 · Fill the gap**

Hvad ____ din far tænke?

What would your father think?

[[Danish#^da-Q0427-answer|Compare the answer]]
^da-Q0427

**da-Q0428 · Choose the form**

Hvad ____ din far tænke?

What would your father think?

Choices: skal / ville / må / kan

[[Danish#^da-Q0428-answer|Compare the answer]]
^da-Q0428

**da-Q0429 · Edit the changed sentence**

Tom spekulerede over, hvor længe han 【kan】 vente på Mary.

Tom wondered how long he'd have to wait for Mary.

[[Danish#^da-Q0429-answer|Compare the answer]]
^da-Q0429

**da-Q0430 · Build the sentence**

Arrange: spekulerede / på / skulle / han / Mary. / hvor / Tom / vente / længe / over,

Tom wondered how long he'd have to wait for Mary.

[[Danish#^da-Q0430-answer|Compare the answer]]
^da-Q0430

**da-Q0431 · Write a translation**

Write this in Danish: Tom would probably choose this one.

[[Danish#^da-Q0431-answer|Compare the answer]]
^da-Q0431

**da-Q0432 · Explain the grammar**

Tom 【ville】 nok vælge den her.

Tom would probably choose this one.

[[Danish#^da-Q0432-answer|Compare the answer]]
^da-Q0432

**da-Q0433 · Fill the gap**

Du ____ komme.

You must come.

[[Danish#^da-Q0433-answer|Compare the answer]]
^da-Q0433

**da-Q0434 · Choose the form**

Du ____ komme.

You must come.

Choices: vil / skal / må / kan

[[Danish#^da-Q0434-answer|Compare the answer]]
^da-Q0434

**da-Q0435 · Edit the changed sentence**

Tom 【skal】 på tredive sprog sige "Jeg taler kun fransk."

Tom can say "I can only speak French" in thirty languages.

[[Danish#^da-Q0435-answer|Compare the answer]]
^da-Q0435

**da-Q0436 · Build the sentence**

Arrange: sprog / fransk." / kan / på / Tom / kun / sige / tredive / taler / "Jeg

Tom can say "I can only speak French" in thirty languages.

[[Danish#^da-Q0436-answer|Compare the answer]]
^da-Q0436

**da-Q0437 · Write a translation**

Write this in Danish: I know someone who can help you.

[[Danish#^da-Q0437-answer|Compare the answer]]
^da-Q0437

**da-Q0438 · Explain the grammar**

Jeg kender nogen som 【kan】 hjælpe dig.

I know someone who can help you.

[[Danish#^da-Q0438-answer|Compare the answer]]
^da-Q0438

**da-Q0439 · Fill the gap**

Du ____ tage tyren ved hornene.

You must take the bull by the horns.

[[Danish#^da-Q0439-answer|Compare the answer]]
^da-Q0439

**da-Q0440 · Choose the form**

Du ____ tage tyren ved hornene.

You must take the bull by the horns.

Choices: kan / skal / vil / må

[[Danish#^da-Q0440-answer|Compare the answer]]
^da-Q0440

**da-Q0441 · Edit the changed sentence**

I morgen 【kan】 vi proklamere en republik.

Tomorrow we shall proclaim a republic.

[[Danish#^da-Q0441-answer|Compare the answer]]
^da-Q0441

**da-Q0442 · Build the sentence**

Arrange: vil / morgen / I / proklamere / republik. / en / vi

Tomorrow we shall proclaim a republic.

[[Danish#^da-Q0442-answer|Compare the answer]]
^da-Q0442

**da-Q0443 · Write a translation**

Write this in Danish: He is the last person to speak ill of others.

[[Danish#^da-Q0443-answer|Compare the answer]]
^da-Q0443

**da-Q0444 · Explain the grammar**

Han er den sidste person der 【vil】 tale dårligt om andre.

He is the last person to speak ill of others.

[[Danish#^da-Q0444-answer|Compare the answer]]
^da-Q0444

**da-Q0445 · Fill the gap**

Din far ____ ikke købe det.

Your father will not buy it.

[[Danish#^da-Q0445-answer|Compare the answer]]
^da-Q0445

**da-Q0446 · Choose the form**

Din far ____ ikke købe det.

Your father will not buy it.

Choices: skal / kan / må / vil

[[Danish#^da-Q0446-answer|Compare the answer]]
^da-Q0446

**da-Q0447 · Edit the changed sentence**

Tom 【skal】 lide berlinerpfannkuchen.

Tom likes jelly donuts.

[[Danish#^da-Q0447-answer|Compare the answer]]
^da-Q0447

**da-Q0448 · Build the sentence**

Arrange: Tom / kan / berlinerpfannkuchen. / lide

Tom likes jelly donuts.

[[Danish#^da-Q0448-answer|Compare the answer]]
^da-Q0448

**da-Q0449 · Write a translation**

Write this in Danish: I like to ride motorcycles.

[[Danish#^da-Q0449-answer|Compare the answer]]
^da-Q0449

**da-Q0450 · Explain the grammar**

Jeg 【kan】 lide at køre på motorcykler.

I like to ride motorcycles.

[[Danish#^da-Q0450-answer|Compare the answer]]
^da-Q0450


### Perfect participles · 50 questions

**da-Q0451 · Fill the gap**

Jeg har ____ dig gøre det.

I've seen you doing that.

[[Danish#^da-Q0451-answer|Compare the answer]]
^da-Q0451

**da-Q0452 · Choose the form**

Jeg har ____ dig gøre det.

I've seen you doing that.

Choices: gået / sagt / set / gjort

[[Danish#^da-Q0452-answer|Compare the answer]]
^da-Q0452

**da-Q0453 · Edit the changed sentence**

Hun er ikke 【gjort】.

She did not come.

[[Danish#^da-Q0453-answer|Compare the answer]]
^da-Q0453

**da-Q0454 · Build the sentence**

Arrange: kommet. / Hun / er / ikke

She did not come.

[[Danish#^da-Q0454-answer|Compare the answer]]
^da-Q0454

**da-Q0455 · Write a translation**

Write this in Danish: Tom said that he's scared that his phone is smarter than he is.

[[Danish#^da-Q0455-answer|Compare the answer]]
^da-Q0455

**da-Q0456 · Explain the grammar**

Tom har 【sagt】 at han er bange for at hans telefon er klogere end han er.

Tom said that he's scared that his phone is smarter than he is.

[[Danish#^da-Q0456-answer|Compare the answer]]
^da-Q0456

**da-Q0457 · Fill the gap**

Tom har ____ det så meget bedre.

Tom has gotten so much better.

[[Danish#^da-Q0457-answer|Compare the answer]]
^da-Q0457

**da-Q0458 · Choose the form**

Tom har ____ det så meget bedre.

Tom has gotten so much better.

Choices: set / fået / sagt / gjort

[[Danish#^da-Q0458-answer|Compare the answer]]
^da-Q0458

**da-Q0459 · Edit the changed sentence**

Jeg har ikke 【sagt】 det.

I didn't do it.

[[Danish#^da-Q0459-answer|Compare the answer]]
^da-Q0459

**da-Q0460 · Build the sentence**

Arrange: gjort / ikke / det. / Jeg / har

I didn't do it.

[[Danish#^da-Q0460-answer|Compare the answer]]
^da-Q0460

**da-Q0461 · Write a translation**

Write this in Danish: It's not like it used to be.

[[Danish#^da-Q0461-answer|Compare the answer]]
^da-Q0461

**da-Q0462 · Explain the grammar**

Det er ikke som det har 【været】.

It's not like it used to be.

[[Danish#^da-Q0462-answer|Compare the answer]]
^da-Q0462

**da-Q0463 · Fill the gap**

Jeg har ____ det forkerte ben ud af sengen i dag.

I woke up on the wrong side of the bed today.

[[Danish#^da-Q0463-answer|Compare the answer]]
^da-Q0463

**da-Q0464 · Choose the form**

Jeg har ____ det forkerte ben ud af sengen i dag.

I woke up on the wrong side of the bed today.

Choices: sagt / gjort / set / fået

[[Danish#^da-Q0464-answer|Compare the answer]]
^da-Q0464

**da-Q0465 · Edit the changed sentence**

Jeg er lige 【gjort】 hjem.

I just got home.

[[Danish#^da-Q0465-answer|Compare the answer]]
^da-Q0465

**da-Q0466 · Build the sentence**

Arrange: Jeg / er / hjem. / lige / kommet

I just got home.

[[Danish#^da-Q0466-answer|Compare the answer]]
^da-Q0466

**da-Q0467 · Write a translation**

Write this in Danish: Have you seen my car keys?

[[Danish#^da-Q0467-answer|Compare the answer]]
^da-Q0467

**da-Q0468 · Explain the grammar**

Har du 【set】 mine bilnøgler?

Have you seen my car keys?

[[Danish#^da-Q0468-answer|Compare the answer]]
^da-Q0468

**da-Q0469 · Fill the gap**

Jeg har ____ en masse bøger.

I've read a lot of books.

[[Danish#^da-Q0469-answer|Compare the answer]]
^da-Q0469

**da-Q0470 · Choose the form**

Jeg har ____ en masse bøger.

I've read a lot of books.

Choices: set / læst / gjort / sagt

[[Danish#^da-Q0470-answer|Compare the answer]]
^da-Q0470

**da-Q0471 · Edit the changed sentence**

Har du 【gjort】 nok søvn?

Did you get enough sleep?

[[Danish#^da-Q0471-answer|Compare the answer]]
^da-Q0471

**da-Q0472 · Build the sentence**

Arrange: fået / nok / du / søvn? / Har

Did you get enough sleep?

[[Danish#^da-Q0472-answer|Compare the answer]]
^da-Q0472

**da-Q0473 · Write a translation**

Write this in Danish: I've enjoyed talking to you.

[[Danish#^da-Q0473-answer|Compare the answer]]
^da-Q0473

**da-Q0474 · Explain the grammar**

Det har 【været】 hyggeligt at snakke med dig.

I've enjoyed talking to you.

[[Danish#^da-Q0474-answer|Compare the answer]]
^da-Q0474

**da-Q0475 · Fill the gap**

Hun viste mig et brev ____ på engelsk.

She showed me a letter written in English.

[[Danish#^da-Q0475-answer|Compare the answer]]
^da-Q0475

**da-Q0476 · Choose the form**

Hun viste mig et brev ____ på engelsk.

She showed me a letter written in English.

Choices: gjort / sagt / skrevet / set

[[Danish#^da-Q0476-answer|Compare the answer]]
^da-Q0476

**da-Q0477 · Edit the changed sentence**

Tom har 【gjort】 en bog om fugle.

Tom has written a book about birds.

[[Danish#^da-Q0477-answer|Compare the answer]]
^da-Q0477

**da-Q0478 · Build the sentence**

Arrange: en / har / bog / skrevet / om / fugle. / Tom

Tom has written a book about birds.

[[Danish#^da-Q0478-answer|Compare the answer]]
^da-Q0478

**da-Q0479 · Write a translation**

Write this in Danish: I've been everywhere.

[[Danish#^da-Q0479-answer|Compare the answer]]
^da-Q0479

**da-Q0480 · Explain the grammar**

Jeg har 【været】 overalt.

I've been everywhere.

[[Danish#^da-Q0480-answer|Compare the answer]]
^da-Q0480

**da-Q0481 · Fill the gap**

Vi har ____ hendes dans.

We saw her dance.

[[Danish#^da-Q0481-answer|Compare the answer]]
^da-Q0481

**da-Q0482 · Choose the form**

Vi har ____ hendes dans.

We saw her dance.

Choices: sagt / gjort / gået / set

[[Danish#^da-Q0482-answer|Compare the answer]]
^da-Q0482

**da-Q0483 · Edit the changed sentence**

Dette er det højeste stillads, jeg nogensinde har 【gjort】.

This is the tallest scaffolding I've ever seen in my life.

[[Danish#^da-Q0483-answer|Compare the answer]]
^da-Q0483

**da-Q0484 · Build the sentence**

Arrange: nogensinde / stillads, / er / det / højeste / set. / Dette / jeg / har

This is the tallest scaffolding I've ever seen in my life.

[[Danish#^da-Q0484-answer|Compare the answer]]
^da-Q0484

**da-Q0485 · Write a translation**

Write this in Danish: Wikipedia has been blocked in Turkey since April 29, 2017.

[[Danish#^da-Q0485-answer|Compare the answer]]
^da-Q0485

**da-Q0486 · Explain the grammar**

I Tyrkiet har Wikipedia 【været】 blokeret siden 29. april 2017.

Wikipedia has been blocked in Turkey since April 29, 2017.

[[Danish#^da-Q0486-answer|Compare the answer]]
^da-Q0486

**da-Q0487 · Fill the gap**

Jeg har ____ i flere end ti fremmede lande indtil nu.

I have been to more than ten foreign countries so far.

[[Danish#^da-Q0487-answer|Compare the answer]]
^da-Q0487

**da-Q0488 · Choose the form**

Jeg har ____ i flere end ti fremmede lande indtil nu.

I have been to more than ten foreign countries so far.

Choices: set / været / gjort / sagt

[[Danish#^da-Q0488-answer|Compare the answer]]
^da-Q0488

**da-Q0489 · Edit the changed sentence**

Har du nogensinde 【gjort】 Tom danse?

Have you ever seen Tom dance?

[[Danish#^da-Q0489-answer|Compare the answer]]
^da-Q0489

**da-Q0490 · Build the sentence**

Arrange: danse? / du / set / nogensinde / Tom / Har

Have you ever seen Tom dance?

[[Danish#^da-Q0490-answer|Compare the answer]]
^da-Q0490

**da-Q0491 · Write a translation**

Write this in Danish: What have we done to be punished like this?

[[Danish#^da-Q0491-answer|Compare the answer]]
^da-Q0491

**da-Q0492 · Explain the grammar**

Hvad har vi 【gjort】 for at blive straffet på den måde?

What have we done to be punished like this?

[[Danish#^da-Q0492-answer|Compare the answer]]
^da-Q0492

**da-Q0493 · Fill the gap**

Du må have ____ noget.

You must've done something.

[[Danish#^da-Q0493-answer|Compare the answer]]
^da-Q0493

**da-Q0494 · Choose the form**

Du må have ____ noget.

You must've done something.

Choices: gået / sagt / set / gjort

[[Danish#^da-Q0494-answer|Compare the answer]]
^da-Q0494

**da-Q0495 · Edit the changed sentence**

Jeg burde være 【gjort】 i seng noget før.

I should have gone to bed earlier.

[[Danish#^da-Q0495-answer|Compare the answer]]
^da-Q0495

**da-Q0496 · Build the sentence**

Arrange: før. / burde / seng / noget / Jeg / være / gået / i

I should have gone to bed earlier.

[[Danish#^da-Q0496-answer|Compare the answer]]
^da-Q0496

**da-Q0497 · Write a translation**

Write this in Danish: Mary says she's never seen you before.

[[Danish#^da-Q0497-answer|Compare the answer]]
^da-Q0497

**da-Q0498 · Explain the grammar**

Mary siger, at hun aldrig har 【set】 dig før.

Mary says she's never seen you before.

[[Danish#^da-Q0498-answer|Compare the answer]]
^da-Q0498

**da-Q0499 · Fill the gap**

Jeg har kun ____ den første del af bogen.

I've only read the first part of the book.

[[Danish#^da-Q0499-answer|Compare the answer]]
^da-Q0499

**da-Q0500 · Choose the form**

Jeg har kun ____ den første del af bogen.

I've only read the first part of the book.

Choices: læst / gjort / set / sagt

[[Danish#^da-Q0500-answer|Compare the answer]]
^da-Q0500


### Past lexical verbs · 50 questions

**da-Q0501 · Edit the changed sentence**

Undskyld, noget 【sagde】 galt.

Sorry, something went wrong.

[[Danish#^da-Q0501-answer|Compare the answer]]
^da-Q0501

**da-Q0502 · Build the sentence**

Arrange: galt. / gik / noget / Undskyld,

Sorry, something went wrong.

[[Danish#^da-Q0502-answer|Compare the answer]]
^da-Q0502

**da-Q0503 · Write a translation**

Write this in Danish: Everything went up in smoke.

[[Danish#^da-Q0503-answer|Compare the answer]]
^da-Q0503

**da-Q0504 · Explain the grammar**

Alt 【gik】 op i røg.

Everything went up in smoke.

[[Danish#^da-Q0504-answer|Compare the answer]]
^da-Q0504

**da-Q0505 · Fill the gap**

Jeg ____ til min kone: Liliane, pak kufferterne, vi tager tilbage til Paris.

I told my wife: Liliane, pack up the bags, we're going back to Paris.

[[Danish#^da-Q0505-answer|Compare the answer]]
^da-Q0505

**da-Q0506 · Choose the form**

Jeg ____ til min kone: Liliane, pak kufferterne, vi tager tilbage til Paris.

I told my wife: Liliane, pack up the bags, we're going back to Paris.

Choices: kom / gjorde / gik / sagde

[[Danish#^da-Q0506-answer|Compare the answer]]
^da-Q0506

**da-Q0507 · Edit the changed sentence**

Jeg 【sagde】 på dig.

I was thinking about you.

[[Danish#^da-Q0507-answer|Compare the answer]]
^da-Q0507

**da-Q0508 · Build the sentence**

Arrange: dig. / på / tænkte / Jeg

I was thinking about you.

[[Danish#^da-Q0508-answer|Compare the answer]]
^da-Q0508

**da-Q0509 · Write a translation**

Write this in Danish: She was telling the truth.

[[Danish#^da-Q0509-answer|Compare the answer]]
^da-Q0509

**da-Q0510 · Explain the grammar**

Hun 【sagde】 sandheden.

She was telling the truth.

[[Danish#^da-Q0510-answer|Compare the answer]]
^da-Q0510

**da-Q0511 · Fill the gap**

Han, ____ vel som du, er en god golfspiller.

He, just like you, is a good golfer.

[[Danish#^da-Q0511-answer|Compare the answer]]
^da-Q0511

**da-Q0512 · Choose the form**

Han, ____ vel som du, er en god golfspiller.

He, just like you, is a good golfer.

Choices: gjorde / gik / sagde / så

[[Danish#^da-Q0512-answer|Compare the answer]]
^da-Q0512

**da-Q0513 · Edit the changed sentence**

Hvis jeg var en fugl, 【sagde】 kunne jeg flyve hen til dig.

If I were a bird, I could fly to you.

[[Danish#^da-Q0513-answer|Compare the answer]]
^da-Q0513

**da-Q0514 · Build the sentence**

Arrange: hen / var / til / kunne / dig. / en / jeg / jeg / fugl, / så / Hvis / flyve

If I were a bird, I could fly to you.

[[Danish#^da-Q0514-answer|Compare the answer]]
^da-Q0514

**da-Q0515 · Write a translation**

Write this in Danish: Tom was given a six-month suspended sentence.

[[Danish#^da-Q0515-answer|Compare the answer]]
^da-Q0515

**da-Q0516 · Explain the grammar**

Tom 【fik】 en seks måneders betinget dom.

Tom was given a six-month suspended sentence.

[[Danish#^da-Q0516-answer|Compare the answer]]
^da-Q0516

**da-Q0517 · Fill the gap**

Jeg ____ tre film i går.

I watched three movies yesterday.

[[Danish#^da-Q0517-answer|Compare the answer]]
^da-Q0517

**da-Q0518 · Choose the form**

Jeg ____ tre film i går.

I watched three movies yesterday.

Choices: gjorde / sagde / gik / så

[[Danish#^da-Q0518-answer|Compare the answer]]
^da-Q0518

**da-Q0519 · Edit the changed sentence**

Tom taler fransk lige 【sagde】 godt som Mary.

Tom speaks French as well as Mary.

[[Danish#^da-Q0519-answer|Compare the answer]]
^da-Q0519

**da-Q0520 · Build the sentence**

Arrange: som / fransk / Mary. / taler / Tom / så / lige / godt

Tom speaks French as well as Mary.

[[Danish#^da-Q0520-answer|Compare the answer]]
^da-Q0520

**da-Q0521 · Write a translation**

Write this in Danish: The problem isn't so much the money as it is the time.

[[Danish#^da-Q0521-answer|Compare the answer]]
^da-Q0521

**da-Q0522 · Explain the grammar**

Problemet er ikke 【så】 meget pengene, som det er tiden.

The problem isn't so much the money as it is the time.

[[Danish#^da-Q0522-answer|Compare the answer]]
^da-Q0522

**da-Q0523 · Fill the gap**

Den modige mand ____ på gangsteren med had og foragt.

The bold man glanced at the gangster with hatred and contempt.

[[Danish#^da-Q0523-answer|Compare the answer]]
^da-Q0523

**da-Q0524 · Choose the form**

Den modige mand ____ på gangsteren med had og foragt.

The bold man glanced at the gangster with hatred and contempt.

Choices: sagde / gjorde / så / gik

[[Danish#^da-Q0524-answer|Compare the answer]]
^da-Q0524

**da-Q0525 · Edit the changed sentence**

Når du ser fjernsyn eller hører radio, 【sagde】 er den musik du hører, ofte af afrikansk oprindelse.

When you watch television or listen to the radio, the music which you hear is often African in origin.

[[Danish#^da-Q0525-answer|Compare the answer]]
^da-Q0525

**da-Q0526 · Build the sentence**

Arrange: ser / musik / ofte / Når / den / du / eller / hører / så / af / radio, / hører, / er / fjernsyn / du / oprindelse. / afrikansk

When you watch television or listen to the radio, the music which you hear is often African in origin.

[[Danish#^da-Q0526-answer|Compare the answer]]
^da-Q0526

**da-Q0527 · Write a translation**

Write this in Danish: I was not as strong as my father.

[[Danish#^da-Q0527-answer|Compare the answer]]
^da-Q0527

**da-Q0528 · Explain the grammar**

Jeg var ikke 【så】 stærk som min far.

I was not as strong as my father.

[[Danish#^da-Q0528-answer|Compare the answer]]
^da-Q0528

**da-Q0529 · Fill the gap**

Han døde inden ambulancen ____.

He died before the ambulance arrived.

[[Danish#^da-Q0529-answer|Compare the answer]]
^da-Q0529

**da-Q0530 · Choose the form**

Han døde inden ambulancen ____.

He died before the ambulance arrived.

Choices: sagde / kom / gik / gjorde

[[Danish#^da-Q0530-answer|Compare the answer]]
^da-Q0530

**da-Q0531 · Edit the changed sentence**

Jeg 【sagde】 jeg ikke var skør.

I knew I wasn't crazy.

[[Danish#^da-Q0531-answer|Compare the answer]]
^da-Q0531

**da-Q0532 · Build the sentence**

Arrange: vidste / skør. / ikke / var / jeg / Jeg

I knew I wasn't crazy.

[[Danish#^da-Q0532-answer|Compare the answer]]
^da-Q0532

**da-Q0533 · Write a translation**

Write this in Danish: Tom went too far.

[[Danish#^da-Q0533-answer|Compare the answer]]
^da-Q0533

**da-Q0534 · Explain the grammar**

Tom 【gik】 for langt.

Tom went too far.

[[Danish#^da-Q0534-answer|Compare the answer]]
^da-Q0534

**da-Q0535 · Fill the gap**

Den stakkels ælling ____ hverken, hvor den turde stå eller gå, den var så bedrøvet, fordi den så så styg ud og var til spot for hele andegården.

The poor duckling did not know where to go, and was quite miserable because he was so ugly and laughed at by the whole farmyard.

[[Danish#^da-Q0535-answer|Compare the answer]]
^da-Q0535

**da-Q0536 · Choose the form**

Den stakkels ælling ____ hverken, hvor den turde stå eller gå, den var så bedrøvet, fordi den så så styg ud og var til spot for hele andegården.

The poor duckling did not know where to go, and was quite miserable because he was so ugly and laughed at by the whole farmyard.

Choices: gjorde / gik / vidste / sagde

[[Danish#^da-Q0536-answer|Compare the answer]]
^da-Q0536

**da-Q0537 · Edit the changed sentence**

Mario er 【sagde】 syg at han knap nok kan bevæge sig.

Mario is so sick that he can barely move.

[[Danish#^da-Q0537-answer|Compare the answer]]
^da-Q0537

**da-Q0538 · Build the sentence**

Arrange: knap / nok / er / så / sig. / at / kan / Mario / syg / bevæge / han

Mario is so sick that he can barely move.

[[Danish#^da-Q0538-answer|Compare the answer]]
^da-Q0538

**da-Q0539 · Write a translation**

Write this in Danish: Why are you so troubled?

[[Danish#^da-Q0539-answer|Compare the answer]]
^da-Q0539

**da-Q0540 · Explain the grammar**

Hvorfor er du 【så】 ængstelig?

Why are you so troubled?

[[Danish#^da-Q0540-answer|Compare the answer]]
^da-Q0540

**da-Q0541 · Fill the gap**

Du er ikke ____ ung som Tom.

You're not as young as Tom.

[[Danish#^da-Q0541-answer|Compare the answer]]
^da-Q0541

**da-Q0542 · Choose the form**

Du er ikke ____ ung som Tom.

You're not as young as Tom.

Choices: gjorde / så / gik / sagde

[[Danish#^da-Q0542-answer|Compare the answer]]
^da-Q0542

**da-Q0543 · Edit the changed sentence**

Som I alle sandsynligvis ved, 【sagde】 er jeg Maria.

As all of you probably know, I'm Maria.

[[Danish#^da-Q0543-answer|Compare the answer]]
^da-Q0543

**da-Q0544 · Build the sentence**

Arrange: alle / ved, / så / jeg / Som / I / sandsynligvis / er / Maria.

As all of you probably know, I'm Maria.

[[Danish#^da-Q0544-answer|Compare the answer]]
^da-Q0544

**da-Q0545 · Write a translation**

Write this in Danish: This letter arrived while you were out.

[[Danish#^da-Q0545-answer|Compare the answer]]
^da-Q0545

**da-Q0546 · Explain the grammar**

Dette brev 【kom】 mens du var ude.

This letter arrived while you were out.

[[Danish#^da-Q0546-answer|Compare the answer]]
^da-Q0546

**da-Q0547 · Fill the gap**

Jeg ____ ikke du kunne lide Mary.

I didn't know you liked Mary.

[[Danish#^da-Q0547-answer|Compare the answer]]
^da-Q0547

**da-Q0548 · Choose the form**

Jeg ____ ikke du kunne lide Mary.

I didn't know you liked Mary.

Choices: gik / vidste / gjorde / sagde

[[Danish#^da-Q0548-answer|Compare the answer]]
^da-Q0548

**da-Q0549 · Edit the changed sentence**

Jeg havde indtryk af at Tom ikke 【sagde】 hvad der foregik.

I had the impression that Tom didn't know what was going on.

[[Danish#^da-Q0549-answer|Compare the answer]]
^da-Q0549

**da-Q0550 · Build the sentence**

Arrange: foregik. / af / Jeg / Tom / hvad / havde / vidste / at / ikke / der / indtryk

I had the impression that Tom didn't know what was going on.

[[Danish#^da-Q0550-answer|Compare the answer]]
^da-Q0550


### Adjective agreement · 50 questions

**da-Q0551 · Write a translation**

Write this in Danish: I need a new bicycle.

[[Danish#^da-Q0551-answer|Compare the answer]]
^da-Q0551

**da-Q0552 · Explain the grammar**

Jeg trænger til en 【ny】 cykel.

I need a new bicycle.

[[Danish#^da-Q0552-answer|Compare the answer]]
^da-Q0552

**da-Q0553 · Fill the gap**

Han kan virkelig ____ lide at rejse.

He really likes traveling a lot.

[[Danish#^da-Q0553-answer|Compare the answer]]
^da-Q0553

**da-Q0554 · Choose the form**

Han kan virkelig ____ lide at rejse.

He really likes traveling a lot.

Choices: gode / godt / god

[[Danish#^da-Q0554-answer|Compare the answer]]
^da-Q0554

**da-Q0555 · Edit the changed sentence**

Jeg er ikke ret 【godt】 til at lave mad; derfor spiser jeg tit ude.

I'm not very good at cooking, so I eat out a lot.

[[Danish#^da-Q0555-answer|Compare the answer]]
^da-Q0555

**da-Q0556 · Build the sentence**

Arrange: Jeg / jeg / lave / derfor / tit / ret / er / god / mad; / spiser / til / at / ude. / ikke

I'm not very good at cooking, so I eat out a lot.

[[Danish#^da-Q0556-answer|Compare the answer]]
^da-Q0556

**da-Q0557 · Write a translation**

Write this in Danish: Russia is big.

[[Danish#^da-Q0557-answer|Compare the answer]]
^da-Q0557

**da-Q0558 · Explain the grammar**

Rusland er 【stort】.

Russia is big.

[[Danish#^da-Q0558-answer|Compare the answer]]
^da-Q0558

**da-Q0559 · Fill the gap**

Tom er ikke ____ til at synge.

Tom can't sing well.

[[Danish#^da-Q0559-answer|Compare the answer]]
^da-Q0559

**da-Q0560 · Choose the form**

Tom er ikke ____ til at synge.

Tom can't sing well.

Choices: god / gode / godt

[[Danish#^da-Q0560-answer|Compare the answer]]
^da-Q0560

**da-Q0561 · Edit the changed sentence**

Gører dem 【god】, som hade eder.

Do good to those who hate you.

[[Danish#^da-Q0561-answer|Compare the answer]]
^da-Q0561

**da-Q0562 · Build the sentence**

Arrange: som / hade / dem / Gører / eder. / godt,

Do good to those who hate you.

[[Danish#^da-Q0562-answer|Compare the answer]]
^da-Q0562

**da-Q0563 · Write a translation**

Write this in Danish: Tom's coffee is good.

[[Danish#^da-Q0563-answer|Compare the answer]]
^da-Q0563

**da-Q0564 · Explain the grammar**

Toms kaffe er 【god】.

Tom's coffee is good.

[[Danish#^da-Q0564-answer|Compare the answer]]
^da-Q0564

**da-Q0565 · Fill the gap**

Min ____ kollega er en robot.

My new colleague is a robot.

[[Danish#^da-Q0565-answer|Compare the answer]]
^da-Q0565

**da-Q0566 · Choose the form**

Min ____ kollega er en robot.

My new colleague is a robot.

Choices: gode / god / godt / nye

[[Danish#^da-Q0566-answer|Compare the answer]]
^da-Q0566

**da-Q0567 · Edit the changed sentence**

Tom ødelagde sin 【god】 smartphone.

Tom broke his new smartphone.

[[Danish#^da-Q0567-answer|Compare the answer]]
^da-Q0567

**da-Q0568 · Build the sentence**

Arrange: smartphone. / sin / Tom / nye / ødelagde

Tom broke his new smartphone.

[[Danish#^da-Q0568-answer|Compare the answer]]
^da-Q0568

**da-Q0569 · Write a translation**

Write this in Danish: That television is both big and expensive.

[[Danish#^da-Q0569-answer|Compare the answer]]
^da-Q0569

**da-Q0570 · Explain the grammar**

Dette tv-apparat er både 【stort】 og dyrt.

That television is both big and expensive.

[[Danish#^da-Q0570-answer|Compare the answer]]
^da-Q0570

**da-Q0571 · Fill the gap**

Ha' en ____ dag, Tom!

Have a nice day, Tom.

[[Danish#^da-Q0571-answer|Compare the answer]]
^da-Q0571

**da-Q0572 · Choose the form**

Ha' en ____ dag, Tom!

Have a nice day, Tom.

Choices: god / godt / gode

[[Danish#^da-Q0572-answer|Compare the answer]]
^da-Q0572

**da-Q0573 · Edit the changed sentence**

I går samlede vi inden for en time næsten et halvt kilo glasskår på stranden, hvilket var 【god】 rekord.

Yesterday we collected nearly half a kilo of pieces of broken glass on the beach within an hour, which was a record result.

[[Danish#^da-Q0573-answer|Compare the answer]]
^da-Q0573

**da-Q0574 · Build the sentence**

Arrange: et / hvilket / går / var / på / en / samlede / for / inden / halvt / kilo / time / næsten / rekord. / vi / ny / glasskår / I / stranden,

Yesterday we collected nearly half a kilo of pieces of broken glass on the beach within an hour, which was a record result.

[[Danish#^da-Q0574-answer|Compare the answer]]
^da-Q0574

**da-Q0575 · Write a translation**

Write this in Danish: I like to talk to kids.

[[Danish#^da-Q0575-answer|Compare the answer]]
^da-Q0575

**da-Q0576 · Explain the grammar**

Jeg kan 【godt】 lide at snakke med børn.

I like to talk to kids.

[[Danish#^da-Q0576-answer|Compare the answer]]
^da-Q0576

**da-Q0577 · Fill the gap**

De her farver harmonerer meget ____.

These colors harmonize very well.

[[Danish#^da-Q0577-answer|Compare the answer]]
^da-Q0577

**da-Q0578 · Choose the form**

De her farver harmonerer meget ____.

These colors harmonize very well.

Choices: godt / gode / god

[[Danish#^da-Q0578-answer|Compare the answer]]
^da-Q0578

**da-Q0579 · Edit the changed sentence**

Hans 【god】 job gav ham en god indtjening.

His new job brought him a handsome income.

[[Danish#^da-Q0579-answer|Compare the answer]]
^da-Q0579

**da-Q0580 · Build the sentence**

Arrange: god / nye / job / gav / Hans / en / ham / indtjening.

His new job brought him a handsome income.

[[Danish#^da-Q0580-answer|Compare the answer]]
^da-Q0580

**da-Q0581 · Write a translation**

Write this in Danish: Tom has big hands.

[[Danish#^da-Q0581-answer|Compare the answer]]
^da-Q0581

**da-Q0582 · Explain the grammar**

Tom har 【store】 hænder.

Tom has big hands.

[[Danish#^da-Q0582-answer|Compare the answer]]
^da-Q0582

**da-Q0583 · Fill the gap**

Mor dig ____ i Boston!

Have fun in Boston.

[[Danish#^da-Q0583-answer|Compare the answer]]
^da-Q0583

**da-Q0584 · Choose the form**

Mor dig ____ i Boston!

Have fun in Boston.

Choices: godt / god / gode

[[Danish#^da-Q0584-answer|Compare the answer]]
^da-Q0584

**da-Q0585 · Edit the changed sentence**

Tom og Mary blev gift i en 【god】 kirke.

Tom and Mary got married in a small church.

[[Danish#^da-Q0585-answer|Compare the answer]]
^da-Q0585

**da-Q0586 · Build the sentence**

Arrange: en / i / kirke. / blev / Tom / lille / gift / Mary / og

Tom and Mary got married in a small church.

[[Danish#^da-Q0586-answer|Compare the answer]]
^da-Q0586

**da-Q0587 · Write a translation**

Write this in Danish: Tom is taking a big risk.

[[Danish#^da-Q0587-answer|Compare the answer]]
^da-Q0587

**da-Q0588 · Explain the grammar**

Tom løber en 【stor】 risiko.

Tom is taking a big risk.

[[Danish#^da-Q0588-answer|Compare the answer]]
^da-Q0588

**da-Q0589 · Fill the gap**

Kaffen kunne ____ være en smule stærkere.

The coffee could be a bit stronger.

[[Danish#^da-Q0589-answer|Compare the answer]]
^da-Q0589

**da-Q0590 · Choose the form**

Kaffen kunne ____ være en smule stærkere.

The coffee could be a bit stronger.

Choices: god / gode / godt

[[Danish#^da-Q0590-answer|Compare the answer]]
^da-Q0590

**da-Q0591 · Edit the changed sentence**

Han er en 【god】 videnskabsmand.

He's a great scientist.

[[Danish#^da-Q0591-answer|Compare the answer]]
^da-Q0591

**da-Q0592 · Build the sentence**

Arrange: en / videnskabsmand. / er / stor / Han

He's a great scientist.

[[Danish#^da-Q0592-answer|Compare the answer]]
^da-Q0592

**da-Q0593 · Write a translation**

Write this in Danish: No news is good news.

[[Danish#^da-Q0593-answer|Compare the answer]]
^da-Q0593

**da-Q0594 · Explain the grammar**

Intet 【nyt】 er godt nyt.

No news is good news.

[[Danish#^da-Q0594-answer|Compare the answer]]
^da-Q0594

**da-Q0595 · Fill the gap**

Tom har planer om at købe en ____ motorcykel.

Tom plans to buy a new motorcycle.

[[Danish#^da-Q0595-answer|Compare the answer]]
^da-Q0595

**da-Q0596 · Choose the form**

Tom har planer om at købe en ____ motorcykel.

Tom plans to buy a new motorcycle.

Choices: ny / god / gode / godt

[[Danish#^da-Q0596-answer|Compare the answer]]
^da-Q0596

**da-Q0597 · Edit the changed sentence**

De kommer 【god】 ud af det med naboerne.

They're on good terms with their neighbors.

[[Danish#^da-Q0597-answer|Compare the answer]]
^da-Q0597

**da-Q0598 · Build the sentence**

Arrange: De / det / ud / kommer / med / af / godt / naboerne.

They're on good terms with their neighbors.

[[Danish#^da-Q0598-answer|Compare the answer]]
^da-Q0598

**da-Q0599 · Write a translation**

Write this in Danish: I had a small dog when I was small.

[[Danish#^da-Q0599-answer|Compare the answer]]
^da-Q0599

**da-Q0600 · Explain the grammar**

Jeg havde en 【lille】 hund da jeg var lille.

I had a small dog when I was small.

[[Danish#^da-Q0600-answer|Compare the answer]]
^da-Q0600


### Reflexive possession · 50 questions

**da-Q0601 · Fill the gap**

Tom fodrer ____ hund to gange om dagen.

Tom feeds his dog twice a day.

[[Danish#^da-Q0601-answer|Compare the answer]]
^da-Q0601

**da-Q0602 · Choose the form**

Tom fodrer ____ hund to gange om dagen.

Tom feeds his dog twice a day.

Choices: hans / sin / sit / sine

[[Danish#^da-Q0602-answer|Compare the answer]]
^da-Q0602

**da-Q0603 · Edit the changed sentence**

De tændte stearinlys på 【sin】 værelse.

They lit candles in their room.

[[Danish#^da-Q0603-answer|Compare the answer]]
^da-Q0603

**da-Q0604 · Build the sentence**

Arrange: De / værelse. / stearinlys / på / deres / tændte

They lit candles in their room.

[[Danish#^da-Q0604-answer|Compare the answer]]
^da-Q0604

**da-Q0605 · Write a translation**

Write this in Danish: Tom never talks about his exes.

[[Danish#^da-Q0605-answer|Compare the answer]]
^da-Q0605

**da-Q0606 · Explain the grammar**

Tom taler aldrig om 【sine】 ekser.

Tom never talks about his exes.

[[Danish#^da-Q0606-answer|Compare the answer]]
^da-Q0606

**da-Q0607 · Fill the gap**

Han mødte ____ ven medens han badede i havet.

He met his friend while bathing in the sea.

[[Danish#^da-Q0607-answer|Compare the answer]]
^da-Q0607

**da-Q0608 · Choose the form**

Han mødte ____ ven medens han badede i havet.

He met his friend while bathing in the sea.

Choices: sit / sine / hans / sin

[[Danish#^da-Q0608-answer|Compare the answer]]
^da-Q0608

**da-Q0609 · Edit the changed sentence**

De ler ad ham bag 【sin】 ryg.

They laugh at him behind his back.

[[Danish#^da-Q0609-answer|Compare the answer]]
^da-Q0609

**da-Q0610 · Build the sentence**

Arrange: ryg. / ad / hans / bag / ham / De / ler

They laugh at him behind his back.

[[Danish#^da-Q0610-answer|Compare the answer]]
^da-Q0610

**da-Q0611 · Write a translation**

Write this in Danish: Tom is always a little irritable in the morning before he drinks his first cup of coffee.

[[Danish#^da-Q0611-answer|Compare the answer]]
^da-Q0611

**da-Q0612 · Explain the grammar**

Tom er altid lidt irritabel om morgenen, før han drikker 【sin】 første kop kaffe.

Tom is always a little irritable in the morning before he drinks his first cup of coffee.

[[Danish#^da-Q0612-answer|Compare the answer]]
^da-Q0612

**da-Q0613 · Fill the gap**

Han besejrede ____ fjende.

He defeated his enemy.

[[Danish#^da-Q0613-answer|Compare the answer]]
^da-Q0613

**da-Q0614 · Choose the form**

Han besejrede ____ fjende.

He defeated his enemy.

Choices: sit / sin / sine / hans

[[Danish#^da-Q0614-answer|Compare the answer]]
^da-Q0614

**da-Q0615 · Edit the changed sentence**

Hans forældre hjalp enhver der bad om 【sin】 hjælp.

His parents helped whoever asked for their help.

[[Danish#^da-Q0615-answer|Compare the answer]]
^da-Q0615

**da-Q0616 · Build the sentence**

Arrange: der / Hans / deres / hjælp. / bad / enhver / hjalp / om / forældre

His parents helped whoever asked for their help.

[[Danish#^da-Q0616-answer|Compare the answer]]
^da-Q0616

**da-Q0617 · Write a translation**

Write this in Danish: The boy is playing with his tin soldiers.

[[Danish#^da-Q0617-answer|Compare the answer]]
^da-Q0617

**da-Q0618 · Explain the grammar**

Drengen leger med 【sine】 tinsoldater.

The boy is playing with his tin soldiers.

[[Danish#^da-Q0618-answer|Compare the answer]]
^da-Q0618

**da-Q0619 · Fill the gap**

Skifter skildpadder ____ skjolde?

Do tortoises change their shells?

[[Danish#^da-Q0619-answer|Compare the answer]]
^da-Q0619

**da-Q0620 · Choose the form**

Skifter skildpadder ____ skjolde?

Do tortoises change their shells?

Choices: sit / sine / sin / deres

[[Danish#^da-Q0620-answer|Compare the answer]]
^da-Q0620

**da-Q0621 · Edit the changed sentence**

Jeg husker mandens ansigt, men har glemt 【sin】 navn.

I remember the man's face, but forgot his name.

[[Danish#^da-Q0621-answer|Compare the answer]]
^da-Q0621

**da-Q0622 · Build the sentence**

Arrange: husker / har / ansigt, / hans / navn. / glemt / Jeg / mandens / men

I remember the man's face, but forgot his name.

[[Danish#^da-Q0622-answer|Compare the answer]]
^da-Q0622

**da-Q0623 · Write a translation**

Write this in Danish: He walked his three dogs every day.

[[Danish#^da-Q0623-answer|Compare the answer]]
^da-Q0623

**da-Q0624 · Explain the grammar**

Han luftede 【sine】 tre hunde hver dag.

He walked his three dogs every day.

[[Danish#^da-Q0624-answer|Compare the answer]]
^da-Q0624

**da-Q0625 · Fill the gap**

Har Tom fundet ____ nøgler?

Has Tom found his keys yet?

[[Danish#^da-Q0625-answer|Compare the answer]]
^da-Q0625

**da-Q0626 · Choose the form**

Har Tom fundet ____ nøgler?

Has Tom found his keys yet?

Choices: sine / hans / sit / sin

[[Danish#^da-Q0626-answer|Compare the answer]]
^da-Q0626

**da-Q0627 · Edit the changed sentence**

Han reddede ham på bekostning af 【sin】 eget liv.

He saved him at the cost of his own life.

[[Danish#^da-Q0627-answer|Compare the answer]]
^da-Q0627

**da-Q0628 · Build the sentence**

Arrange: eget / på / reddede / af / bekostning / ham / Han / liv. / sit

He saved him at the cost of his own life.

[[Danish#^da-Q0628-answer|Compare the answer]]
^da-Q0628

**da-Q0629 · Write a translation**

Write this in Danish: I don't know what his real intentions are.

[[Danish#^da-Q0629-answer|Compare the answer]]
^da-Q0629

**da-Q0630 · Explain the grammar**

Jeg ved ikke hvad 【hans】 virkelige intentioner er.

I don't know what his real intentions are.

[[Danish#^da-Q0630-answer|Compare the answer]]
^da-Q0630

**da-Q0631 · Fill the gap**

Tom hader ____ navn.

Tom hates his name.

[[Danish#^da-Q0631-answer|Compare the answer]]
^da-Q0631

**da-Q0632 · Choose the form**

Tom hader ____ navn.

Tom hates his name.

Choices: sit / sin / sine / hans

[[Danish#^da-Q0632-answer|Compare the answer]]
^da-Q0632

**da-Q0633 · Edit the changed sentence**

En knap fra 【sin】 overfrakke faldt af.

A button from his overcoat fell off.

[[Danish#^da-Q0633-answer|Compare the answer]]
^da-Q0633

**da-Q0634 · Build the sentence**

Arrange: faldt / En / knap / af. / hans / overfrakke / fra

A button from his overcoat fell off.

[[Danish#^da-Q0634-answer|Compare the answer]]
^da-Q0634

**da-Q0635 · Write a translation**

Write this in Danish: Tom is playing with his toy truck.

[[Danish#^da-Q0635-answer|Compare the answer]]
^da-Q0635

**da-Q0636 · Explain the grammar**

Tom leger med 【sin】 legetøjslastbil.

Tom is playing with his toy truck.

[[Danish#^da-Q0636-answer|Compare the answer]]
^da-Q0636

**da-Q0637 · Fill the gap**

Sammenlignet med vores hus, er ____ et palads.

Compared to our house, his is a palace.

[[Danish#^da-Q0637-answer|Compare the answer]]
^da-Q0637

**da-Q0638 · Choose the form**

Sammenlignet med vores hus, er ____ et palads.

Compared to our house, his is a palace.

Choices: sine / sit / sin / hans

[[Danish#^da-Q0638-answer|Compare the answer]]
^da-Q0638

**da-Q0639 · Edit the changed sentence**

Tom fortalte Mary at han ikke kunne lide 【sin】 sans for humor.

Tom told Mary that he didn't like her sense of humor.

[[Danish#^da-Q0639-answer|Compare the answer]]
^da-Q0639

**da-Q0640 · Build the sentence**

Arrange: lide / Tom / sans / at / han / fortalte / for / hendes / humor. / kunne / Mary / ikke

Tom told Mary that he didn't like her sense of humor.

[[Danish#^da-Q0640-answer|Compare the answer]]
^da-Q0640

**da-Q0641 · Write a translation**

Write this in Danish: What am I gonna do with his letter?

[[Danish#^da-Q0641-answer|Compare the answer]]
^da-Q0641

**da-Q0642 · Explain the grammar**

Hvad skal jeg stille op med 【hans】 brev?

What am I gonna do with his letter?

[[Danish#^da-Q0642-answer|Compare the answer]]
^da-Q0642

**da-Q0643 · Fill the gap**

Hun gik på indkøb med ____ veninde.

She went shopping with her friend.

[[Danish#^da-Q0643-answer|Compare the answer]]
^da-Q0643

**da-Q0644 · Choose the form**

Hun gik på indkøb med ____ veninde.

She went shopping with her friend.

Choices: hans / sin / sit / sine

[[Danish#^da-Q0644-answer|Compare the answer]]
^da-Q0644

**da-Q0645 · Edit the changed sentence**

Tom hadede 【sit】 fransklærer.

Tom hated his French teacher.

[[Danish#^da-Q0645-answer|Compare the answer]]
^da-Q0645

**da-Q0646 · Build the sentence**

Arrange: sin / hadede / fransklærer. / Tom

Tom hated his French teacher.

[[Danish#^da-Q0646-answer|Compare the answer]]
^da-Q0646

**da-Q0647 · Write a translation**

Write this in Danish: He put milk in his coffee.

[[Danish#^da-Q0647-answer|Compare the answer]]
^da-Q0647

**da-Q0648 · Explain the grammar**

Han puttede mælk i 【sin】 kaffe.

He put milk in his coffee.

[[Danish#^da-Q0648-answer|Compare the answer]]
^da-Q0648

**da-Q0649 · Fill the gap**

Han tog ____ tøj af.

He took off her clothes.

[[Danish#^da-Q0649-answer|Compare the answer]]
^da-Q0649

**da-Q0650 · Choose the form**

Han tog ____ tøj af.

He took off her clothes.

Choices: hendes / sine / sit / sin

[[Danish#^da-Q0650-answer|Compare the answer]]
^da-Q0650


### Relative clauses · 50 questions

**da-Q0651 · Edit the changed sentence**

Alle æblerne, 【som】 falder ned, bliver spist af grisene.

All the apples that fall are eaten by the pigs.

[[Danish#^da-Q0651-answer|Compare the answer]]
^da-Q0651

**da-Q0652 · Build the sentence**

Arrange: grisene. / æblerne, / bliver / ned, / falder / der / spist / af / Alle

All the apples that fall are eaten by the pigs.

[[Danish#^da-Q0652-answer|Compare the answer]]
^da-Q0652

**da-Q0653 · Write a translation**

Write this in Danish: All the apples are there.

[[Danish#^da-Q0653-answer|Compare the answer]]
^da-Q0653

**da-Q0654 · Explain the grammar**

Alle æblerne er 【der】.

All the apples are there.

[[Danish#^da-Q0654-answer|Compare the answer]]
^da-Q0654

**da-Q0655 · Fill the gap**

Hun arbejder ____ au pair.

She works as an au pair.

[[Danish#^da-Q0655-answer|Compare the answer]]
^da-Q0655

**da-Q0656 · Choose the form**

Hun arbejder ____ au pair.

She works as an au pair.

Choices: hvilket / der / hvilken / som

[[Danish#^da-Q0656-answer|Compare the answer]]
^da-Q0656

**da-Q0657 · Edit the changed sentence**

Er 【som】 en bus der kører til storcentret?

Is there a bus that goes to the mall?

[[Danish#^da-Q0657-answer|Compare the answer]]
^da-Q0657

**da-Q0658 · Build the sentence**

Arrange: Er / storcentret? / en / kører / til / bus / der / der

Is there a bus that goes to the mall?

[[Danish#^da-Q0658-answer|Compare the answer]]
^da-Q0658

**da-Q0659 · Write a translation**

Write this in Danish: From here, it's about three kilometers to the coast.

[[Danish#^da-Q0659-answer|Compare the answer]]
^da-Q0659

**da-Q0660 · Explain the grammar**

Herfra er 【der】 omkring tre kilometer til kysten.

From here, it's about three kilometers to the coast.

[[Danish#^da-Q0660-answer|Compare the answer]]
^da-Q0660

**da-Q0661 · Fill the gap**

Der er mange huse ____ er blevet ødelagt af jordskælvet.

There are many houses destroyed by the earthquake.

[[Danish#^da-Q0661-answer|Compare the answer]]
^da-Q0661

**da-Q0662 · Choose the form**

Der er mange huse ____ er blevet ødelagt af jordskælvet.

There are many houses destroyed by the earthquake.

Choices: hvilken / som / hvilket / der

[[Danish#^da-Q0662-answer|Compare the answer]]
^da-Q0662

**da-Q0663 · Edit the changed sentence**

De behandler mig 【der】 et barn.

They are treating me like a child.

[[Danish#^da-Q0663-answer|Compare the answer]]
^da-Q0663

**da-Q0664 · Build the sentence**

Arrange: som / behandler / De / mig / barn. / et

They are treating me like a child.

[[Danish#^da-Q0664-answer|Compare the answer]]
^da-Q0664

**da-Q0665 · Write a translation**

Write this in Danish: Tom was the only one who got hurt.

[[Danish#^da-Q0665-answer|Compare the answer]]
^da-Q0665

**da-Q0666 · Explain the grammar**

Tom var den eneste 【som】 blev såret.

Tom was the only one who got hurt.

[[Danish#^da-Q0666-answer|Compare the answer]]
^da-Q0666

**da-Q0667 · Fill the gap**

Han er ikke en mand ____ spilder tiden.

He's not a man to waste time.

[[Danish#^da-Q0667-answer|Compare the answer]]
^da-Q0667

**da-Q0668 · Choose the form**

Han er ikke en mand ____ spilder tiden.

He's not a man to waste time.

Choices: hvilket / der / som / hvilken

[[Danish#^da-Q0668-answer|Compare the answer]]
^da-Q0668

**da-Q0669 · Edit the changed sentence**

Hvad sker 【som】, Sarah?

What's going on, Sarah?

[[Danish#^da-Q0669-answer|Compare the answer]]
^da-Q0669

**da-Q0670 · Build the sentence**

Arrange: sker / Hvad / Sarah? / der,

What's going on, Sarah?

[[Danish#^da-Q0670-answer|Compare the answer]]
^da-Q0670

**da-Q0671 · Write a translation**

Write this in Danish: The tree that is in the garden is an ancient oak.

[[Danish#^da-Q0671-answer|Compare the answer]]
^da-Q0671

**da-Q0672 · Explain the grammar**

Træet, 【der】 er i haven, er en gammel eg.

The tree that is in the garden is an ancient oak.

[[Danish#^da-Q0672-answer|Compare the answer]]
^da-Q0672

**da-Q0673 · Fill the gap**

Det er den kvinde ____ jeg er forelsket i.

That's the woman I'm in love with.

[[Danish#^da-Q0673-answer|Compare the answer]]
^da-Q0673

**da-Q0674 · Choose the form**

Det er den kvinde ____ jeg er forelsket i.

That's the woman I'm in love with.

Choices: der / hvilket / hvilken / som

[[Danish#^da-Q0674-answer|Compare the answer]]
^da-Q0674

**da-Q0675 · Edit the changed sentence**

Hunde 【som】 gør, bider sjældent.

Barking dogs seldom bite.

[[Danish#^da-Q0675-answer|Compare the answer]]
^da-Q0675

**da-Q0676 · Build the sentence**

Arrange: der / gør, / sjældent. / Hunde / bider

Barking dogs seldom bite.

[[Danish#^da-Q0676-answer|Compare the answer]]
^da-Q0676

**da-Q0677 · Write a translation**

Write this in Danish: There are four pieces of furniture in the room.

[[Danish#^da-Q0677-answer|Compare the answer]]
^da-Q0677

**da-Q0678 · Explain the grammar**

I værelset er 【der】 fire møbler.

There are four pieces of furniture in the room.

[[Danish#^da-Q0678-answer|Compare the answer]]
^da-Q0678

**da-Q0679 · Fill the gap**

Tom, ____ er noget, jeg glemte at fortælle dig.

Tom, there's something I forgot to tell you.

[[Danish#^da-Q0679-answer|Compare the answer]]
^da-Q0679

**da-Q0680 · Choose the form**

Tom, ____ er noget, jeg glemte at fortælle dig.

Tom, there's something I forgot to tell you.

Choices: hvilket / der / hvilken / som

[[Danish#^da-Q0680-answer|Compare the answer]]
^da-Q0680

**da-Q0681 · Edit the changed sentence**

Jeg er bange for at krydse gaden i Beijing da bilisterne 【som】 ikke tager hensyn til fodgængerne.

I'm afraid to cross the street in Beijing since drivers don't respect pedestrians there.

[[Danish#^da-Q0681-answer|Compare the answer]]
^da-Q0681

**da-Q0682 · Build the sentence**

Arrange: ikke / bange / bilisterne / til / i / at / hensyn / Beijing / der / Jeg / krydse / for / er / fodgængerne. / gaden / tager / da

I'm afraid to cross the street in Beijing since drivers don't respect pedestrians there.

[[Danish#^da-Q0682-answer|Compare the answer]]
^da-Q0682

**da-Q0683 · Write a translation**

Write this in Danish: Are you allergic to anything else?

[[Danish#^da-Q0683-answer|Compare the answer]]
^da-Q0683

**da-Q0684 · Explain the grammar**

Er 【der】 andet du er allergisk over for?

Are you allergic to anything else?

[[Danish#^da-Q0684-answer|Compare the answer]]
^da-Q0684

**da-Q0685 · Fill the gap**

Jeg boede ____ i fem år.

I lived there for five years.

[[Danish#^da-Q0685-answer|Compare the answer]]
^da-Q0685

**da-Q0686 · Choose the form**

Jeg boede ____ i fem år.

I lived there for five years.

Choices: som / hvilken / hvilket / der

[[Danish#^da-Q0686-answer|Compare the answer]]
^da-Q0686

**da-Q0687 · Edit the changed sentence**

Hvad skal 【som】 blive af os?

What is going to become of us?

[[Danish#^da-Q0687-answer|Compare the answer]]
^da-Q0687

**da-Q0688 · Build the sentence**

Arrange: blive / os? / Hvad / af / skal / der

What is going to become of us?

[[Danish#^da-Q0688-answer|Compare the answer]]
^da-Q0688

**da-Q0689 · Write a translation**

Write this in Danish: Tom has a dog named Cookie.

[[Danish#^da-Q0689-answer|Compare the answer]]
^da-Q0689

**da-Q0690 · Explain the grammar**

Tom har en hund 【som】 hedder Cookie.

Tom has a dog named Cookie.

[[Danish#^da-Q0690-answer|Compare the answer]]
^da-Q0690

**da-Q0691 · Fill the gap**

Han behandler mig altid ____ et barn.

He always treats me like a child.

[[Danish#^da-Q0691-answer|Compare the answer]]
^da-Q0691

**da-Q0692 · Choose the form**

Han behandler mig altid ____ et barn.

He always treats me like a child.

Choices: der / hvilket / som / hvilken

[[Danish#^da-Q0692-answer|Compare the answer]]
^da-Q0692

**da-Q0693 · Edit the changed sentence**

Det var hende 【som】 anmodede om skilsmissen.

She was the one who demanded the divorce.

[[Danish#^da-Q0693-answer|Compare the answer]]
^da-Q0693

**da-Q0694 · Build the sentence**

Arrange: der / hende / om / skilsmissen. / Det / anmodede / var

She was the one who demanded the divorce.

[[Danish#^da-Q0694-answer|Compare the answer]]
^da-Q0694

**da-Q0695 · Write a translation**

Write this in Danish: There are no dogs bigger than this one.

[[Danish#^da-Q0695-answer|Compare the answer]]
^da-Q0695

**da-Q0696 · Explain the grammar**

Der er ingen hunde 【der】 er større end denne her.

There are no dogs bigger than this one.

[[Danish#^da-Q0696-answer|Compare the answer]]
^da-Q0696

**da-Q0697 · Fill the gap**

Af og til går tingene ikke ____ planlagt.

Occasionally, things don't go as planned.

[[Danish#^da-Q0697-answer|Compare the answer]]
^da-Q0697

**da-Q0698 · Choose the form**

Af og til går tingene ikke ____ planlagt.

Occasionally, things don't go as planned.

Choices: der / hvilket / som / hvilken

[[Danish#^da-Q0698-answer|Compare the answer]]
^da-Q0698

**da-Q0699 · Edit the changed sentence**

Jeg sigter på den and 【som】.

I am aiming at that duck.

[[Danish#^da-Q0699-answer|Compare the answer]]
^da-Q0699

**da-Q0700 · Build the sentence**

Arrange: Jeg / der. / and / den / på / sigter

I am aiming at that duck.

[[Danish#^da-Q0700-answer|Compare the answer]]
^da-Q0700


### Existence and place · 50 questions

**da-Q0701 · Write a translation**

Write this in Danish: Tom lived here with us for three months.

[[Danish#^da-Q0701-answer|Compare the answer]]
^da-Q0701

**da-Q0702 · Explain the grammar**

Tom boede 【her】 hos os i tre måneder.

Tom lived here with us for three months.

[[Danish#^da-Q0702-answer|Compare the answer]]
^da-Q0702

**da-Q0703 · Fill the gap**

Jeg græder altid, når jeg ser det ____ billede.

I always cry when I see this picture.

[[Danish#^da-Q0703-answer|Compare the answer]]
^da-Q0703

**da-Q0704 · Choose the form**

Jeg græder altid, når jeg ser det ____ billede.

I always cry when I see this picture.

Choices: her / der

[[Danish#^da-Q0704-answer|Compare the answer]]
^da-Q0704

**da-Q0705 · Edit the changed sentence**

Der bor mange rige mennesker i det 【der】 kvarter.

Many rich people live in this neighborhood.

[[Danish#^da-Q0705-answer|Compare the answer]]
^da-Q0705

**da-Q0706 · Build the sentence**

Arrange: mennesker / i / mange / Der / rige / her / bor / det / kvarter.

Many rich people live in this neighborhood.

[[Danish#^da-Q0706-answer|Compare the answer]]
^da-Q0706

**da-Q0707 · Write a translation**

Write this in Danish: I have lived here since I was a boy.

[[Danish#^da-Q0707-answer|Compare the answer]]
^da-Q0707

**da-Q0708 · Explain the grammar**

Jeg har boet 【her】 siden jeg var dreng.

I have lived here since I was a boy.

[[Danish#^da-Q0708-answer|Compare the answer]]
^da-Q0708

**da-Q0709 · Fill the gap**

Kan nogen ____ tale fransk?

Can anyone here speak French?

[[Danish#^da-Q0709-answer|Compare the answer]]
^da-Q0709

**da-Q0710 · Choose the form**

Kan nogen ____ tale fransk?

Can anyone here speak French?

Choices: der / her

[[Danish#^da-Q0710-answer|Compare the answer]]
^da-Q0710

**da-Q0711 · Edit the changed sentence**

Jeg er led og ked af at arbejde 【der】.

I'm fed up with working here.

[[Danish#^da-Q0711-answer|Compare the answer]]
^da-Q0711

**da-Q0712 · Build the sentence**

Arrange: er / arbejde / led / Jeg / af / og / her. / at / ked

I'm fed up with working here.

[[Danish#^da-Q0712-answer|Compare the answer]]
^da-Q0712

**da-Q0713 · Write a translation**

Write this in Danish: I'll be right there.

[[Danish#^da-Q0713-answer|Compare the answer]]
^da-Q0713

**da-Q0714 · Explain the grammar**

Jeg er 【der】 straks.

I'll be right there.

[[Danish#^da-Q0714-answer|Compare the answer]]
^da-Q0714

**da-Q0715 · Fill the gap**

Vi er ____ hele dagen.

We're here for the day.

[[Danish#^da-Q0715-answer|Compare the answer]]
^da-Q0715

**da-Q0716 · Choose the form**

Vi er ____ hele dagen.

We're here for the day.

Choices: der / her

[[Danish#^da-Q0716-answer|Compare the answer]]
^da-Q0716

**da-Q0717 · Edit the changed sentence**

Tom er 【der】 for at købe nogle æbler.

Tom is here to buy some apples.

[[Danish#^da-Q0717-answer|Compare the answer]]
^da-Q0717

**da-Q0718 · Build the sentence**

Arrange: her / æbler. / Tom / er / nogle / for / at / købe

Tom is here to buy some apples.

[[Danish#^da-Q0718-answer|Compare the answer]]
^da-Q0718

**da-Q0719 · Write a translation**

Write this in Danish: There are more seniors living in Canada than children.

[[Danish#^da-Q0719-answer|Compare the answer]]
^da-Q0719

**da-Q0720 · Explain the grammar**

Der bor flere ældre i Canada end 【der】 bor børn.

There are more seniors living in Canada than children.

[[Danish#^da-Q0720-answer|Compare the answer]]
^da-Q0720

**da-Q0721 · Fill the gap**

Har du noget ____ er billigere?

Do you have anything cheaper?

[[Danish#^da-Q0721-answer|Compare the answer]]
^da-Q0721

**da-Q0722 · Choose the form**

Har du noget ____ er billigere?

Do you have anything cheaper?

Choices: her / der

[[Danish#^da-Q0722-answer|Compare the answer]]
^da-Q0722

**da-Q0723 · Edit the changed sentence**

Jeg var 【der】 hele eftermiddagen.

I was here all afternoon.

[[Danish#^da-Q0723-answer|Compare the answer]]
^da-Q0723

**da-Q0724 · Build the sentence**

Arrange: her / Jeg / var / hele / eftermiddagen.

I was here all afternoon.

[[Danish#^da-Q0724-answer|Compare the answer]]
^da-Q0724

**da-Q0725 · Write a translation**

Write this in Danish: What's wrong?

[[Danish#^da-Q0725-answer|Compare the answer]]
^da-Q0725

**da-Q0726 · Explain the grammar**

Hvad er 【der】 galt?

What's wrong?

[[Danish#^da-Q0726-answer|Compare the answer]]
^da-Q0726

**da-Q0727 · Fill the gap**

Jeg bliver måske ____ indtil mandag.

I may stay here until Monday.

[[Danish#^da-Q0727-answer|Compare the answer]]
^da-Q0727

**da-Q0728 · Choose the form**

Jeg bliver måske ____ indtil mandag.

I may stay here until Monday.

Choices: der / her

[[Danish#^da-Q0728-answer|Compare the answer]]
^da-Q0728

**da-Q0729 · Edit the changed sentence**

Hvad er det 【her】 virkelig foregår?

What's really going on?

[[Danish#^da-Q0729-answer|Compare the answer]]
^da-Q0729

**da-Q0730 · Build the sentence**

Arrange: er / virkelig / der / Hvad / foregår? / det

What's really going on?

[[Danish#^da-Q0730-answer|Compare the answer]]
^da-Q0730

**da-Q0731 · Write a translation**

Write this in Danish: "Do you know anything about Bill?" "No, what happened to him?"

[[Danish#^da-Q0731-answer|Compare the answer]]
^da-Q0731

**da-Q0732 · Explain the grammar**

"Ved du noget om Bill?" "Nej, hvad skete 【der】 med ham?"

"Do you know anything about Bill?" "No, what happened to him?"

[[Danish#^da-Q0732-answer|Compare the answer]]
^da-Q0732

**da-Q0733 · Fill the gap**

På begge sider af vejen er ____ kirsebærtræer.

On both sides of the road there are cherry trees.

[[Danish#^da-Q0733-answer|Compare the answer]]
^da-Q0733

**da-Q0734 · Choose the form**

På begge sider af vejen er ____ kirsebærtræer.

On both sides of the road there are cherry trees.

Choices: her / der

[[Danish#^da-Q0734-answer|Compare the answer]]
^da-Q0734

**da-Q0735 · Edit the changed sentence**

Der er noget 【der】, der ikke stemmer.

There's something here that doesn't add up.

[[Danish#^da-Q0735-answer|Compare the answer]]
^da-Q0735

**da-Q0736 · Build the sentence**

Arrange: Der / noget / der / ikke / er / stemmer. / her,

There's something here that doesn't add up.

[[Danish#^da-Q0736-answer|Compare the answer]]
^da-Q0736

**da-Q0737 · Write a translation**

Write this in Danish: Tom doesn't like women who wear way too much makeup.

[[Danish#^da-Q0737-answer|Compare the answer]]
^da-Q0737

**da-Q0738 · Explain the grammar**

Tom kan ikke lide kvinder, 【der】 har alt for meget makeup på.

Tom doesn't like women who wear way too much makeup.

[[Danish#^da-Q0738-answer|Compare the answer]]
^da-Q0738

**da-Q0739 · Fill the gap**

Tom tilgang til sprogindlæring er at smide alt op på væggen og se hvad ____ hænger ved.

Tom's strategy for language learning is to throw everything against the wall and see what sticks.

[[Danish#^da-Q0739-answer|Compare the answer]]
^da-Q0739

**da-Q0740 · Choose the form**

Tom tilgang til sprogindlæring er at smide alt op på væggen og se hvad ____ hænger ved.

Tom's strategy for language learning is to throw everything against the wall and see what sticks.

Choices: der / her

[[Danish#^da-Q0740-answer|Compare the answer]]
^da-Q0740

**da-Q0741 · Edit the changed sentence**

Er den 【der】 en hingst eller en hoppe?

Is this a stallion or a mare?

[[Danish#^da-Q0741-answer|Compare the answer]]
^da-Q0741

**da-Q0742 · Build the sentence**

Arrange: en / hingst / den / eller / her / en / Er / hoppe?

Is this a stallion or a mare?

[[Danish#^da-Q0742-answer|Compare the answer]]
^da-Q0742

**da-Q0743 · Write a translation**

Write this in Danish: Man is the only animal that uses fire.

[[Danish#^da-Q0743-answer|Compare the answer]]
^da-Q0743

**da-Q0744 · Explain the grammar**

Mennesket er det eneste dyr 【der】 gør brug af ild.

Man is the only animal that uses fire.

[[Danish#^da-Q0744-answer|Compare the answer]]
^da-Q0744

**da-Q0745 · Fill the gap**

Denne ordbog er bedre end den ____.

This dictionary is better than that one.

[[Danish#^da-Q0745-answer|Compare the answer]]
^da-Q0745

**da-Q0746 · Choose the form**

Denne ordbog er bedre end den ____.

This dictionary is better than that one.

Choices: her / der

[[Danish#^da-Q0746-answer|Compare the answer]]
^da-Q0746

**da-Q0747 · Edit the changed sentence**

Jeg leder efter en læbestift 【her】 passer til denne neglelak.

I'm looking for a lipstick to go with this nail polish.

[[Danish#^da-Q0747-answer|Compare the answer]]
^da-Q0747

**da-Q0748 · Build the sentence**

Arrange: efter / en / neglelak. / der / denne / til / læbestift / Jeg / passer / leder

I'm looking for a lipstick to go with this nail polish.

[[Danish#^da-Q0748-answer|Compare the answer]]
^da-Q0748

**da-Q0749 · Write a translation**

Write this in Danish: Many countries have passed laws to prohibit people from smoking in public places.

[[Danish#^da-Q0749-answer|Compare the answer]]
^da-Q0749

**da-Q0750 · Explain the grammar**

Mange lande har lavet love 【der】 forbyder rygning på offentlige steder.

Many countries have passed laws to prohibit people from smoking in public places.

[[Danish#^da-Q0750-answer|Compare the answer]]
^da-Q0750


### Questions · 50 questions

**da-Q0751 · Fill the gap**

Oh, ____ træet bævede!

Oh, how the Tree trembled!

[[Danish#^da-Q0751-answer|Compare the answer]]
^da-Q0751

**da-Q0752 · Choose the form**

Oh, ____ træet bævede!

Oh, how the Tree trembled!

Choices: hvem / hvor / hvorfor / hvad

[[Danish#^da-Q0752-answer|Compare the answer]]
^da-Q0752

**da-Q0753 · Edit the changed sentence**

Kan du fortælle mig, 【hvad】 man justerer lydstyrken?

Could you tell me how to adjust the volume?

[[Danish#^da-Q0753-answer|Compare the answer]]
^da-Q0753

**da-Q0754 · Build the sentence**

Arrange: Kan / man / lydstyrken? / mig, / hvordan / fortælle / justerer / du

Could you tell me how to adjust the volume?

[[Danish#^da-Q0754-answer|Compare the answer]]
^da-Q0754

**da-Q0755 · Write a translation**

Write this in Danish: And where is the money coming from?

[[Danish#^da-Q0755-answer|Compare the answer]]
^da-Q0755

**da-Q0756 · Explain the grammar**

Og 【hvor】 kommer pengene fra?

And where is the money coming from?

[[Danish#^da-Q0756-answer|Compare the answer]]
^da-Q0756

**da-Q0757 · Fill the gap**

Jeg ved præcis ____ jeg er.

I know exactly where I am.

[[Danish#^da-Q0757-answer|Compare the answer]]
^da-Q0757

**da-Q0758 · Choose the form**

Jeg ved præcis ____ jeg er.

I know exactly where I am.

Choices: hvorfor / hvem / hvad / hvor

[[Danish#^da-Q0758-answer|Compare the answer]]
^da-Q0758

**da-Q0759 · Edit the changed sentence**

Så, 【hvem】 anbefaler du?

So, what do you recommend?

[[Danish#^da-Q0759-answer|Compare the answer]]
^da-Q0759

**da-Q0760 · Build the sentence**

Arrange: Så, / du? / anbefaler / hvad

So, what do you recommend?

[[Danish#^da-Q0760-answer|Compare the answer]]
^da-Q0760

**da-Q0761 · Write a translation**

Write this in Danish: She left home with everything she owned.

[[Danish#^da-Q0761-answer|Compare the answer]]
^da-Q0761

**da-Q0762 · Explain the grammar**

Hun flyttede hjemmefra med alt 【hvad】 hun ejede.

She left home with everything she owned.

[[Danish#^da-Q0762-answer|Compare the answer]]
^da-Q0762

**da-Q0763 · Fill the gap**

Du kan sige lige ____ du ønsker.

You can say whatever you want.

[[Danish#^da-Q0763-answer|Compare the answer]]
^da-Q0763

**da-Q0764 · Choose the form**

Du kan sige lige ____ du ønsker.

You can say whatever you want.

Choices: hvor / hvad / hvem / hvorfor

[[Danish#^da-Q0764-answer|Compare the answer]]
^da-Q0764

**da-Q0765 · Edit the changed sentence**

Jeg ved 【hvem】 den pige hedder.

I know that girl's name.

[[Danish#^da-Q0765-answer|Compare the answer]]
^da-Q0765

**da-Q0766 · Build the sentence**

Arrange: hvad / pige / Jeg / ved / den / hedder.

I know that girl's name.

[[Danish#^da-Q0766-answer|Compare the answer]]
^da-Q0766

**da-Q0767 · Write a translation**

Write this in Danish: Don't you know how beautiful you are?

[[Danish#^da-Q0767-answer|Compare the answer]]
^da-Q0767

**da-Q0768 · Explain the grammar**

Ved du ikke 【hvor】 smuk du er?

Don't you know how beautiful you are?

[[Danish#^da-Q0768-answer|Compare the answer]]
^da-Q0768

**da-Q0769 · Fill the gap**

Jeg ved ikke ____ klokken er.

I don't know what time it is.

[[Danish#^da-Q0769-answer|Compare the answer]]
^da-Q0769

**da-Q0770 · Choose the form**

Jeg ved ikke ____ klokken er.

I don't know what time it is.

Choices: hvem / hvor / hvad / hvorfor

[[Danish#^da-Q0770-answer|Compare the answer]]
^da-Q0770

**da-Q0771 · Edit the changed sentence**

Ved Tom 【hvad】 Mary blev født?

Does Tom know where Mary was born?

[[Danish#^da-Q0771-answer|Compare the answer]]
^da-Q0771

**da-Q0772 · Build the sentence**

Arrange: blev / Tom / Mary / født? / Ved / hvor

Does Tom know where Mary was born?

[[Danish#^da-Q0772-answer|Compare the answer]]
^da-Q0772

**da-Q0773 · Write a translation**

Write this in Danish: You'd be amazed how many apples you can buy for two hundred dollars.

[[Danish#^da-Q0773-answer|Compare the answer]]
^da-Q0773

**da-Q0774 · Explain the grammar**

Du ville blive overrasket over 【hvor】 mange æbler du kan købe for to hundrede dollars.

You'd be amazed how many apples you can buy for two hundred dollars.

[[Danish#^da-Q0774-answer|Compare the answer]]
^da-Q0774

**da-Q0775 · Fill the gap**

Han spurgte mig ____ min onkel boede.

He asked me where my uncle lived.

[[Danish#^da-Q0775-answer|Compare the answer]]
^da-Q0775

**da-Q0776 · Choose the form**

Han spurgte mig ____ min onkel boede.

He asked me where my uncle lived.

Choices: hvad / hvem / hvor / hvorfor

[[Danish#^da-Q0776-answer|Compare the answer]]
^da-Q0776

**da-Q0777 · Edit the changed sentence**

De ved 【hvad】 du er.

They know where you are.

[[Danish#^da-Q0777-answer|Compare the answer]]
^da-Q0777

**da-Q0778 · Build the sentence**

Arrange: hvor / du / De / ved / er.

They know where you are.

[[Danish#^da-Q0778-answer|Compare the answer]]
^da-Q0778

**da-Q0779 · Write a translation**

Write this in Danish: This is not at all what I had expected.

[[Danish#^da-Q0779-answer|Compare the answer]]
^da-Q0779

**da-Q0780 · Explain the grammar**

Dette er slet ikke 【hvad】 jeg havde forventet.

This is not at all what I had expected.

[[Danish#^da-Q0780-answer|Compare the answer]]
^da-Q0780

**da-Q0781 · Fill the gap**

Jeg kan ikke gå før jeg finder ud af ____ Tom er.

I can't leave until I find out who Tom is.

[[Danish#^da-Q0781-answer|Compare the answer]]
^da-Q0781

**da-Q0782 · Choose the form**

Jeg kan ikke gå før jeg finder ud af ____ Tom er.

I can't leave until I find out who Tom is.

Choices: hvorfor / hvad / hvor / hvem

[[Danish#^da-Q0782-answer|Compare the answer]]
^da-Q0782

**da-Q0783 · Edit the changed sentence**

Ved du 【hvad】 man behandler en førstegradsbrænding?

Do you know how to treat a first-degree burn?

[[Danish#^da-Q0783-answer|Compare the answer]]
^da-Q0783

**da-Q0784 · Build the sentence**

Arrange: du / behandler / førstegradsbrænding? / en / Ved / hvordan / man

Do you know how to treat a first-degree burn?

[[Danish#^da-Q0784-answer|Compare the answer]]
^da-Q0784

**da-Q0785 · Write a translation**

Write this in Danish: Tom knows how to push my buttons.

[[Danish#^da-Q0785-answer|Compare the answer]]
^da-Q0785

**da-Q0786 · Explain the grammar**

Tom ved lige, 【hvordan】 han kan få mig til at reagere.

Tom knows how to push my buttons.

[[Danish#^da-Q0786-answer|Compare the answer]]
^da-Q0786

**da-Q0787 · Fill the gap**

Sig mig, ____ tænker du på?

Tell me, what are you thinking about?

[[Danish#^da-Q0787-answer|Compare the answer]]
^da-Q0787

**da-Q0788 · Choose the form**

Sig mig, ____ tænker du på?

Tell me, what are you thinking about?

Choices: hvorfor / hvad / hvem / hvor

[[Danish#^da-Q0788-answer|Compare the answer]]
^da-Q0788

**da-Q0789 · Edit the changed sentence**

"Ved du 【hvad】 Lapland er?", spurgte hun rensdyret.

"Do you know where Lapland is?" she asked the reindeer.

[[Danish#^da-Q0789-answer|Compare the answer]]
^da-Q0789

**da-Q0790 · Build the sentence**

Arrange: spurgte / Lapland / er?", / rensdyret. / hvor / du / "Ved / hun

"Do you know where Lapland is?" she asked the reindeer.

[[Danish#^da-Q0790-answer|Compare the answer]]
^da-Q0790

**da-Q0791 · Write a translation**

Write this in Danish: I want to teach you how to do that.

[[Danish#^da-Q0791-answer|Compare the answer]]
^da-Q0791

**da-Q0792 · Explain the grammar**

Jeg vil gerne lære dig, 【hvordan】 du gør det.

I want to teach you how to do that.

[[Danish#^da-Q0792-answer|Compare the answer]]
^da-Q0792

**da-Q0793 · Fill the gap**

Gid jeg vidste ____ han var!

I wish I knew where he was!

[[Danish#^da-Q0793-answer|Compare the answer]]
^da-Q0793

**da-Q0794 · Choose the form**

Gid jeg vidste ____ han var!

I wish I knew where he was!

Choices: hvorfor / hvem / hvad / hvor

[[Danish#^da-Q0794-answer|Compare the answer]]
^da-Q0794

**da-Q0795 · Edit the changed sentence**

Jeg undrer mig over, 【hvad】 vi har øreflipper.

I wonder why we have ear lobes.

[[Danish#^da-Q0795-answer|Compare the answer]]
^da-Q0795

**da-Q0796 · Build the sentence**

Arrange: mig / undrer / vi / over, / øreflipper. / Jeg / har / hvorfor

I wonder why we have ear lobes.

[[Danish#^da-Q0796-answer|Compare the answer]]
^da-Q0796

**da-Q0797 · Write a translation**

Write this in Danish: Excuse me, what time is it?

[[Danish#^da-Q0797-answer|Compare the answer]]
^da-Q0797

**da-Q0798 · Explain the grammar**

Undskyld, 【hvad】 er klokken?

Excuse me, what time is it?

[[Danish#^da-Q0798-answer|Compare the answer]]
^da-Q0798

**da-Q0799 · Fill the gap**

Han ved ____ vi er.

He knows where we are.

[[Danish#^da-Q0799-answer|Compare the answer]]
^da-Q0799

**da-Q0800 · Choose the form**

Han ved ____ vi er.

He knows where we are.

Choices: hvad / hvem / hvorfor / hvor

[[Danish#^da-Q0800-answer|Compare the answer]]
^da-Q0800


### Infinitives · 50 questions

**da-Q0801 · Edit the changed sentence**

Tom tog fra Boston 【at】 Chicago.

Tom went from Boston to Chicago.

[[Danish#^da-Q0801-answer|Compare the answer]]
^da-Q0801

**da-Q0802 · Build the sentence**

Arrange: Chicago. / tog / Boston / til / Tom / fra

Tom went from Boston to Chicago.

[[Danish#^da-Q0802-answer|Compare the answer]]
^da-Q0802

**da-Q0803 · Write a translation**

Write this in Danish: The train arrived in Kyoto on time.

[[Danish#^da-Q0803-answer|Compare the answer]]
^da-Q0803

**da-Q0804 · Explain the grammar**

Toget ankom 【til】 Kyoto til tiden.

The train arrived in Kyoto on time.

[[Danish#^da-Q0804-answer|Compare the answer]]
^da-Q0804

**da-Q0805 · Fill the gap**

Brevet var adresseret ____ mig.

The letter was addressed to me.

[[Danish#^da-Q0805-answer|Compare the answer]]
^da-Q0805

**da-Q0806 · Choose the form**

Brevet var adresseret ____ mig.

The letter was addressed to me.

Choices: til / at

[[Danish#^da-Q0806-answer|Compare the answer]]
^da-Q0806

**da-Q0807 · Edit the changed sentence**

Vær munter! Tilføj et udråbstegn 【at】 alle dine sætninger!

Be cheerful! Add an exclamation mark to all of your sentences!

[[Danish#^da-Q0807-answer|Compare the answer]]
^da-Q0807

**da-Q0808 · Build the sentence**

Arrange: sætninger! / alle / Vær / Tilføj / et / dine / udråbstegn / munter! / til

Be cheerful! Add an exclamation mark to all of your sentences!

[[Danish#^da-Q0808-answer|Compare the answer]]
^da-Q0808

**da-Q0809 · Write a translation**

Write this in Danish: Is it still for sale?

[[Danish#^da-Q0809-answer|Compare the answer]]
^da-Q0809

**da-Q0810 · Explain the grammar**

Er den stadig 【til】 salg?

Is it still for sale?

[[Danish#^da-Q0810-answer|Compare the answer]]
^da-Q0810

**da-Q0811 · Fill the gap**

Svaret er nej ____ begge dine spørgsmål.

The answer is no to both of your questions.

[[Danish#^da-Q0811-answer|Compare the answer]]
^da-Q0811

**da-Q0812 · Choose the form**

Svaret er nej ____ begge dine spørgsmål.

The answer is no to both of your questions.

Choices: at / til

[[Danish#^da-Q0812-answer|Compare the answer]]
^da-Q0812

**da-Q0813 · Edit the changed sentence**

Ingen taler 【at】 mig.

Nobody speaks to me.

[[Danish#^da-Q0813-answer|Compare the answer]]
^da-Q0813

**da-Q0814 · Build the sentence**

Arrange: taler / mig. / Ingen / til

Nobody speaks to me.

[[Danish#^da-Q0814-answer|Compare the answer]]
^da-Q0814

**da-Q0815 · Write a translation**

Write this in Danish: They seem to be enjoying themselves.

[[Danish#^da-Q0815-answer|Compare the answer]]
^da-Q0815

**da-Q0816 · Explain the grammar**

De ser ud 【til】 at more sig.

They seem to be enjoying themselves.

[[Danish#^da-Q0816-answer|Compare the answer]]
^da-Q0816

**da-Q0817 · Fill the gap**

Er netledningen sat ____ en stikkontakt.

Is the power cord plugged into a power outlet?

[[Danish#^da-Q0817-answer|Compare the answer]]
^da-Q0817

**da-Q0818 · Choose the form**

Er netledningen sat ____ en stikkontakt.

Is the power cord plugged into a power outlet?

Choices: til / at

[[Danish#^da-Q0818-answer|Compare the answer]]
^da-Q0818

**da-Q0819 · Edit the changed sentence**

Jeg lovede Tom 【til】 jeg ikke ville græde.

I promised Tom that I wouldn't cry.

[[Danish#^da-Q0819-answer|Compare the answer]]
^da-Q0819

**da-Q0820 · Build the sentence**

Arrange: græde. / at / ikke / jeg / Tom / Jeg / ville / lovede

I promised Tom that I wouldn't cry.

[[Danish#^da-Q0820-answer|Compare the answer]]
^da-Q0820

**da-Q0821 · Write a translation**

Write this in Danish: Don't forget to flush.

[[Danish#^da-Q0821-answer|Compare the answer]]
^da-Q0821

**da-Q0822 · Explain the grammar**

Glem ikke 【at】 skylle ud.

Don't forget to flush.

[[Danish#^da-Q0822-answer|Compare the answer]]
^da-Q0822

**da-Q0823 · Fill the gap**

Vi er endnu ikke klar ____ at kaste håndklædet i ringen.

We're not ready to throw in the towel yet.

[[Danish#^da-Q0823-answer|Compare the answer]]
^da-Q0823

**da-Q0824 · Choose the form**

Vi er endnu ikke klar ____ at kaste håndklædet i ringen.

We're not ready to throw in the towel yet.

Choices: at / til

[[Danish#^da-Q0824-answer|Compare the answer]]
^da-Q0824

**da-Q0825 · Edit the changed sentence**

Jeg sender penge 【at】 Algeriet cirka en gang om måneden.

I send money to Algeria every month or so.

[[Danish#^da-Q0825-answer|Compare the answer]]
^da-Q0825

**da-Q0826 · Build the sentence**

Arrange: sender / til / gang / cirka / om / en / måneden. / Algeriet / Jeg / penge

I send money to Algeria every month or so.

[[Danish#^da-Q0826-answer|Compare the answer]]
^da-Q0826

**da-Q0827 · Write a translation**

Write this in Danish: Are you going to invite her to the party?

[[Danish#^da-Q0827-answer|Compare the answer]]
^da-Q0827

**da-Q0828 · Explain the grammar**

Vil du invitere hende 【til】 festen?

Are you going to invite her to the party?

[[Danish#^da-Q0828-answer|Compare the answer]]
^da-Q0828

**da-Q0829 · Fill the gap**

Glem ikke ____ skrive til mig.

Don't forget to write me.

[[Danish#^da-Q0829-answer|Compare the answer]]
^da-Q0829

**da-Q0830 · Choose the form**

Glem ikke ____ skrive til mig.

Don't forget to write me.

Choices: at / til

[[Danish#^da-Q0830-answer|Compare the answer]]
^da-Q0830

**da-Q0831 · Edit the changed sentence**

Tom fortalte mig 【til】 han talte fransk.

Tom told me that he spoke French.

[[Danish#^da-Q0831-answer|Compare the answer]]
^da-Q0831

**da-Q0832 · Build the sentence**

Arrange: talte / mig / Tom / fortalte / han / at / fransk.

Tom told me that he spoke French.

[[Danish#^da-Q0832-answer|Compare the answer]]
^da-Q0832

**da-Q0833 · Write a translation**

Write this in Danish: He took a taxi to the hospital.

[[Danish#^da-Q0833-answer|Compare the answer]]
^da-Q0833

**da-Q0834 · Explain the grammar**

Han tog en taxi 【til】 hospitalet.

He took a taxi to the hospital.

[[Danish#^da-Q0834-answer|Compare the answer]]
^da-Q0834

**da-Q0835 · Fill the gap**

Jeg lovede ____ adlyde ham.

I promised to obey him.

[[Danish#^da-Q0835-answer|Compare the answer]]
^da-Q0835

**da-Q0836 · Choose the form**

Jeg lovede ____ adlyde ham.

I promised to obey him.

Choices: til / at

[[Danish#^da-Q0836-answer|Compare the answer]]
^da-Q0836

**da-Q0837 · Edit the changed sentence**

Hold op med 【til】 surmule!

Stop sulking!

[[Danish#^da-Q0837-answer|Compare the answer]]
^da-Q0837

**da-Q0838 · Build the sentence**

Arrange: med / at / Hold / surmule! / op

Stop sulking!

[[Danish#^da-Q0838-answer|Compare the answer]]
^da-Q0838

**da-Q0839 · Write a translation**

Write this in Danish: Dick tried to solve the problem, in vain.

[[Danish#^da-Q0839-answer|Compare the answer]]
^da-Q0839

**da-Q0840 · Explain the grammar**

Dick forsøgte forgæves 【at】 løse problemet.

Dick tried to solve the problem, in vain.

[[Danish#^da-Q0840-answer|Compare the answer]]
^da-Q0840

**da-Q0841 · Fill the gap**

Jeg glæder mig ____ at se ham.

I'm looking forward to seeing him.

[[Danish#^da-Q0841-answer|Compare the answer]]
^da-Q0841

**da-Q0842 · Choose the form**

Jeg glæder mig ____ at se ham.

I'm looking forward to seeing him.

Choices: at / til

[[Danish#^da-Q0842-answer|Compare the answer]]
^da-Q0842

**da-Q0843 · Edit the changed sentence**

Tom mente 【til】 det ville være spild af tid at tage til det møde.

Tom thought that it would be a waste of time to go to that meeting.

[[Danish#^da-Q0843-answer|Compare the answer]]
^da-Q0843

**da-Q0844 · Build the sentence**

Arrange: spild / at / tid / det / af / Tom / at / mente / det / ville / til / tage / møde. / være

Tom thought that it would be a waste of time to go to that meeting.

[[Danish#^da-Q0844-answer|Compare the answer]]
^da-Q0844

**da-Q0845 · Write a translation**

Write this in Danish: Call me!

[[Danish#^da-Q0845-answer|Compare the answer]]
^da-Q0845

**da-Q0846 · Explain the grammar**

Ring 【til】 mig!

Call me!

[[Danish#^da-Q0846-answer|Compare the answer]]
^da-Q0846

**da-Q0847 · Fill the gap**

Hvor vil du holde ferie ____ næste sommer?

Where do you plan to go on vacation next summer?

[[Danish#^da-Q0847-answer|Compare the answer]]
^da-Q0847

**da-Q0848 · Choose the form**

Hvor vil du holde ferie ____ næste sommer?

Where do you plan to go on vacation next summer?

Choices: til / at

[[Danish#^da-Q0848-answer|Compare the answer]]
^da-Q0848

**da-Q0849 · Edit the changed sentence**

Vi er ved 【til】 lære fransk.

We're learning French.

[[Danish#^da-Q0849-answer|Compare the answer]]
^da-Q0849

**da-Q0850 · Build the sentence**

Arrange: er / lære / ved / at / Vi / fransk.

We're learning French.

[[Danish#^da-Q0850-answer|Compare the answer]]
^da-Q0850


### Comparison · 50 questions

**da-Q0851 · Write a translation**

Write this in Danish: It is colder this year than last year.

[[Danish#^da-Q0851-answer|Compare the answer]]
^da-Q0851

**da-Q0852 · Explain the grammar**

Det er koldere i år 【end】 sidste år.

It is colder this year than last year.

[[Danish#^da-Q0852-answer|Compare the answer]]
^da-Q0852

**da-Q0853 · Fill the gap**

I burde være ____ forsigtige.

You guys should be more careful.

[[Danish#^da-Q0853-answer|Compare the answer]]
^da-Q0853

**da-Q0854 · Choose the form**

I burde være ____ forsigtige.

You guys should be more careful.

Choices: mere / bedre / end / mindre

[[Danish#^da-Q0854-answer|Compare the answer]]
^da-Q0854

**da-Q0855 · Edit the changed sentence**

Jeg er fire måneder yngre 【mere】 dig.

I am four months younger than you.

[[Danish#^da-Q0855-answer|Compare the answer]]
^da-Q0855

**da-Q0856 · Build the sentence**

Arrange: er / fire / dig. / måneder / end / yngre / Jeg

I am four months younger than you.

[[Danish#^da-Q0856-answer|Compare the answer]]
^da-Q0856

**da-Q0857 · Write a translation**

Write this in Danish: The sooner you start learning Berber, the better.

[[Danish#^da-Q0857-answer|Compare the answer]]
^da-Q0857

**da-Q0858 · Explain the grammar**

Jo før man begynder at lære berberisk, jo 【bedre】.

The sooner you start learning Berber, the better.

[[Danish#^da-Q0858-answer|Compare the answer]]
^da-Q0858

**da-Q0859 · Fill the gap**

Mine forældre har ____ haft sølvbryllup.

My parents just had their silver wedding anniversary.

[[Danish#^da-Q0859-answer|Compare the answer]]
^da-Q0859

**da-Q0860 · Choose the form**

Mine forældre har ____ haft sølvbryllup.

My parents just had their silver wedding anniversary.

Choices: mindre / mere / bedre / lige

[[Danish#^da-Q0860-answer|Compare the answer]]
^da-Q0860

**da-Q0861 · Edit the changed sentence**

Måske vil Tom ikke lyve for os 【mindre】.

Perhaps Tom won't lie to us anymore.

[[Danish#^da-Q0861-answer|Compare the answer]]
^da-Q0861

**da-Q0862 · Build the sentence**

Arrange: vil / mere. / Tom / ikke / lyve / Måske / os / for

Perhaps Tom won't lie to us anymore.

[[Danish#^da-Q0862-answer|Compare the answer]]
^da-Q0862

**da-Q0863 · Write a translation**

Write this in Danish: He's far more experienced than me.

[[Danish#^da-Q0863-answer|Compare the answer]]
^da-Q0863

**da-Q0864 · Explain the grammar**

Han er langt 【mere】 erfaren end mig.

He's far more experienced than me.

[[Danish#^da-Q0864-answer|Compare the answer]]
^da-Q0864

**da-Q0865 · Fill the gap**

Jeg er klog nok til at tro, at hvis man er født som fisk, er det ____ værdigt at dø under vand end i stegepanden.

I am wise enough to think that if one is born a fish, it is more dignified to die under the water than in the frying pan.

[[Danish#^da-Q0865-answer|Compare the answer]]
^da-Q0865

**da-Q0866 · Choose the form**

Jeg er klog nok til at tro, at hvis man er født som fisk, er det ____ værdigt at dø under vand end i stegepanden.

I am wise enough to think that if one is born a fish, it is more dignified to die under the water than in the frying pan.

Choices: bedre / mindre / mere / end

[[Danish#^da-Q0866-answer|Compare the answer]]
^da-Q0866

**da-Q0867 · Edit the changed sentence**

Vi har 【mere】 haft nogle få problemer.

We just had a few problems.

[[Danish#^da-Q0867-answer|Compare the answer]]
^da-Q0867

**da-Q0868 · Build the sentence**

Arrange: problemer. / haft / Vi / få / nogle / har / lige

We just had a few problems.

[[Danish#^da-Q0868-answer|Compare the answer]]
^da-Q0868

**da-Q0869 · Write a translation**

Write this in Danish: His aunt's apple pie was delicious, so he had a second helping.

[[Danish#^da-Q0869-answer|Compare the answer]]
^da-Q0869

**da-Q0870 · Explain the grammar**

Hans tantes æblekage var velsmagende, og derfor fik han en portion 【mere】.

His aunt's apple pie was delicious, so he had a second helping.

[[Danish#^da-Q0870-answer|Compare the answer]]
^da-Q0870

**da-Q0871 · Fill the gap**

Er Tom yngre ____ Mary?

Is Tom younger than Mary?

[[Danish#^da-Q0871-answer|Compare the answer]]
^da-Q0871

**da-Q0872 · Choose the form**

Er Tom yngre ____ Mary?

Is Tom younger than Mary?

Choices: end / bedre / mindre / mere

[[Danish#^da-Q0872-answer|Compare the answer]]
^da-Q0872

**da-Q0873 · Edit the changed sentence**

Du må huske på at hun er meget yngre 【mere】 dig.

You must keep in mind that she's much younger than you.

[[Danish#^da-Q0873-answer|Compare the answer]]
^da-Q0873

**da-Q0874 · Build the sentence**

Arrange: dig. / hun / end / huske / yngre / på / Du / må / er / meget / at

You must keep in mind that she's much younger than you.

[[Danish#^da-Q0874-answer|Compare the answer]]
^da-Q0874

**da-Q0875 · Write a translation**

Write this in Danish: I barely managed to catch the train.

[[Danish#^da-Q0875-answer|Compare the answer]]
^da-Q0875

**da-Q0876 · Explain the grammar**

Jeg nåede 【lige】 akkurat toget.

I barely managed to catch the train.

[[Danish#^da-Q0876-answer|Compare the answer]]
^da-Q0876

**da-Q0877 · Fill the gap**

Jeg var ____ ved at glemme mit pas.

I almost forgot my passport.

[[Danish#^da-Q0877-answer|Compare the answer]]
^da-Q0877

**da-Q0878 · Choose the form**

Jeg var ____ ved at glemme mit pas.

I almost forgot my passport.

Choices: bedre / lige / mindre / mere

[[Danish#^da-Q0878-answer|Compare the answer]]
^da-Q0878

**da-Q0879 · Edit the changed sentence**

Man siger at marts kommer ind som en løve og går ud som et lam, men det er 【mindre】 kompliceret end som så.

They say March goes in like a lion and out like a lamb, but it's more complicated than that.

[[Danish#^da-Q0879-answer|Compare the answer]]
^da-Q0879

**da-Q0880 · Build the sentence**

Arrange: kompliceret / lam, / mere / at / en / så. / går / løve / som / og / er / end / Man / som / et / som / marts / men / det / kommer / ind / ud / siger

They say March goes in like a lion and out like a lamb, but it's more complicated than that.

[[Danish#^da-Q0880-answer|Compare the answer]]
^da-Q0880

**da-Q0881 · Write a translation**

Write this in Danish: Can you speak a language other than English?

[[Danish#^da-Q0881-answer|Compare the answer]]
^da-Q0881

**da-Q0882 · Explain the grammar**

Kan du tale andre sprοg 【end】 engelsk?

Can you speak a language other than English?

[[Danish#^da-Q0882-answer|Compare the answer]]
^da-Q0882

**da-Q0883 · Fill the gap**

Jeg sov ____ end jeg gjorde sidste nat.

I slept better than I did last night.

[[Danish#^da-Q0883-answer|Compare the answer]]
^da-Q0883

**da-Q0884 · Choose the form**

Jeg sov ____ end jeg gjorde sidste nat.

I slept better than I did last night.

Choices: mindre / bedre / end / mere

[[Danish#^da-Q0884-answer|Compare the answer]]
^da-Q0884

**da-Q0885 · Edit the changed sentence**

Alle dyr er 【mere】, men nogle dyr er mere lige end andre.

All animals are equal, but some animals are more equal than others.

[[Danish#^da-Q0885-answer|Compare the answer]]
^da-Q0885

**da-Q0886 · Build the sentence**

Arrange: lige, / dyr / dyr / men / er / mere / er / end / lige / Alle / andre. / nogle

All animals are equal, but some animals are more equal than others.

[[Danish#^da-Q0886-answer|Compare the answer]]
^da-Q0886

**da-Q0887 · Write a translation**

Write this in Danish: I need more coffee.

[[Danish#^da-Q0887-answer|Compare the answer]]
^da-Q0887

**da-Q0888 · Explain the grammar**

Jeg har brug for 【mere】 kaffe.

I need more coffee.

[[Danish#^da-Q0888-answer|Compare the answer]]
^da-Q0888

**da-Q0889 · Fill the gap**

Min Mercedes er ____ end din.

My Mercedes is bigger than yours.

[[Danish#^da-Q0889-answer|Compare the answer]]
^da-Q0889

**da-Q0890 · Choose the form**

Min Mercedes er ____ end din.

My Mercedes is bigger than yours.

Choices: bedre / større / mere / mindre

[[Danish#^da-Q0890-answer|Compare the answer]]
^da-Q0890

**da-Q0891 · Edit the changed sentence**

Det er 【mere】, ikke sandt?

That's better, isn't it?

[[Danish#^da-Q0891-answer|Compare the answer]]
^da-Q0891

**da-Q0892 · Build the sentence**

Arrange: Det / sandt? / er / bedre, / ikke

That's better, isn't it?

[[Danish#^da-Q0892-answer|Compare the answer]]
^da-Q0892

**da-Q0893 · Write a translation**

Write this in Danish: Tom is taking a bath now.

[[Danish#^da-Q0893-answer|Compare the answer]]
^da-Q0893

**da-Q0894 · Explain the grammar**

Tom tager 【lige】 nu et bad.

Tom is taking a bath now.

[[Danish#^da-Q0894-answer|Compare the answer]]
^da-Q0894

**da-Q0895 · Fill the gap**

Der er ikke ____ toiletpapir.

There is no TP left.

[[Danish#^da-Q0895-answer|Compare the answer]]
^da-Q0895

**da-Q0896 · Choose the form**

Der er ikke ____ toiletpapir.

There is no TP left.

Choices: mindre / mere / bedre / end

[[Danish#^da-Q0896-answer|Compare the answer]]
^da-Q0896

**da-Q0897 · Edit the changed sentence**

Han er ældre 【mere】 mig.

He's older than me.

[[Danish#^da-Q0897-answer|Compare the answer]]
^da-Q0897

**da-Q0898 · Build the sentence**

Arrange: mig. / Han / ældre / er / end

He's older than me.

[[Danish#^da-Q0898-answer|Compare the answer]]
^da-Q0898

**da-Q0899 · Write a translation**

Write this in Danish: From a thicket close by came three beautiful white swans, rustling their feathers, and swimming lightly over the smooth water.

[[Danish#^da-Q0899-answer|Compare the answer]]
^da-Q0899

**da-Q0900 · Explain the grammar**

Og 【lige】 foran, ud af tykningen, kom tre dejlige, hvide svaner; de bruste med fjerene og flød så let på vandet.

From a thicket close by came three beautiful white swans, rustling their feathers, and swimming lightly over the smooth water.

[[Danish#^da-Q0900-answer|Compare the answer]]
^da-Q0900


### Prepositions · 50 questions

**da-Q0901 · Fill the gap**

Jeg bor ____ Boston nu.

I live in Boston now.

[[Danish#^da-Q0901-answer|Compare the answer]]
^da-Q0901

**da-Q0902 · Choose the form**

Jeg bor ____ Boston nu.

I live in Boston now.

Choices: med / fra / på / i

[[Danish#^da-Q0902-answer|Compare the answer]]
^da-Q0902

**da-Q0903 · Edit the changed sentence**

Tom arbejder 【i】 deltid.

Tom works part-time.

[[Danish#^da-Q0903-answer|Compare the answer]]
^da-Q0903

**da-Q0904 · Build the sentence**

Arrange: deltid. / Tom / arbejder / på

Tom works part-time.

[[Danish#^da-Q0904-answer|Compare the answer]]
^da-Q0904

**da-Q0905 · Write a translation**

Write this in Danish: Tom stood facing the wall.

[[Danish#^da-Q0905-answer|Compare the answer]]
^da-Q0905

**da-Q0906 · Explain the grammar**

Tom stod 【med】 ansigtet mod muren.

Tom stood facing the wall.

[[Danish#^da-Q0906-answer|Compare the answer]]
^da-Q0906

**da-Q0907 · Fill the gap**

Kvæg lever ____ græs.

Cattle feed on grass.

[[Danish#^da-Q0907-answer|Compare the answer]]
^da-Q0907

**da-Q0908 · Choose the form**

Kvæg lever ____ græs.

Cattle feed on grass.

Choices: af / på / med / i

[[Danish#^da-Q0908-answer|Compare the answer]]
^da-Q0908

**da-Q0909 · Edit the changed sentence**

Hvordan siger man "børnehave" 【i】 tysk?

How do you say kindergarten in German?

[[Danish#^da-Q0909-answer|Compare the answer]]
^da-Q0909

**da-Q0910 · Build the sentence**

Arrange: Hvordan / man / "børnehave" / på / tysk? / siger

How do you say kindergarten in German?

[[Danish#^da-Q0910-answer|Compare the answer]]
^da-Q0910

**da-Q0911 · Write a translation**

Write this in Danish: Tom raced Mary down the hill.

[[Danish#^da-Q0911-answer|Compare the answer]]
^da-Q0911

**da-Q0912 · Explain the grammar**

Tom løb om kap 【med】 Mary ned ad bakken.

Tom raced Mary down the hill.

[[Danish#^da-Q0912-answer|Compare the answer]]
^da-Q0912

**da-Q0913 · Fill the gap**

Jeg kører aldrig bil ____ alkoholpåvirket tilstand.

I don't ever drink and drive.

[[Danish#^da-Q0913-answer|Compare the answer]]
^da-Q0913

**da-Q0914 · Choose the form**

Jeg kører aldrig bil ____ alkoholpåvirket tilstand.

I don't ever drink and drive.

Choices: i / med / på / fra

[[Danish#^da-Q0914-answer|Compare the answer]]
^da-Q0914

**da-Q0915 · Edit the changed sentence**

Han sammenlignede kopien 【i】 originalen.

He compared the copy with the original.

[[Danish#^da-Q0915-answer|Compare the answer]]
^da-Q0915

**da-Q0916 · Build the sentence**

Arrange: originalen. / sammenlignede / med / kopien / Han

He compared the copy with the original.

[[Danish#^da-Q0916-answer|Compare the answer]]
^da-Q0916

**da-Q0917 · Write a translation**

Write this in Danish: Let me eat in peace.

[[Danish#^da-Q0917-answer|Compare the answer]]
^da-Q0917

**da-Q0918 · Explain the grammar**

Lad mig spise 【i】 fred.

Let me eat in peace.

[[Danish#^da-Q0918-answer|Compare the answer]]
^da-Q0918

**da-Q0919 · Fill the gap**

Tom er gift ____ Marys lillesøster.

Tom is married to Mary's younger sister.

[[Danish#^da-Q0919-answer|Compare the answer]]
^da-Q0919

**da-Q0920 · Choose the form**

Tom er gift ____ Marys lillesøster.

Tom is married to Mary's younger sister.

Choices: på / med / fra / i

[[Danish#^da-Q0920-answer|Compare the answer]]
^da-Q0920

**da-Q0921 · Edit the changed sentence**

Facebook er blokeret 【på】 Kina.

Facebook is blocked in China.

[[Danish#^da-Q0921-answer|Compare the answer]]
^da-Q0921

**da-Q0922 · Build the sentence**

Arrange: Facebook / blokeret / er / Kina. / i

Facebook is blocked in China.

[[Danish#^da-Q0922-answer|Compare the answer]]
^da-Q0922

**da-Q0923 · Write a translation**

Write this in Danish: The fields lay covered with deep snow.

[[Danish#^da-Q0923-answer|Compare the answer]]
^da-Q0923

**da-Q0924 · Explain the grammar**

Markerne var dækket 【af】 et tykt lag sne.

The fields lay covered with deep snow.

[[Danish#^da-Q0924-answer|Compare the answer]]
^da-Q0924

**da-Q0925 · Fill the gap**

Der er ingen post ____ postkassen.

There's no mail in the mailbox.

[[Danish#^da-Q0925-answer|Compare the answer]]
^da-Q0925

**da-Q0926 · Choose the form**

Der er ingen post ____ postkassen.

There's no mail in the mailbox.

Choices: med / fra / på / i

[[Danish#^da-Q0926-answer|Compare the answer]]
^da-Q0926

**da-Q0927 · Edit the changed sentence**

Det er koldt 【på】 dag!

It's cold today.

[[Danish#^da-Q0927-answer|Compare the answer]]
^da-Q0927

**da-Q0928 · Build the sentence**

Arrange: i / koldt / Det / er / dag!

It's cold today.

[[Danish#^da-Q0928-answer|Compare the answer]]
^da-Q0928

**da-Q0929 · Write a translation**

Write this in Danish: The villages in the Alps are very picturesque.

[[Danish#^da-Q0929-answer|Compare the answer]]
^da-Q0929

**da-Q0930 · Explain the grammar**

Landsbyerne 【i】 Alperne er meget pittoreske.

The villages in the Alps are very picturesque.

[[Danish#^da-Q0930-answer|Compare the answer]]
^da-Q0930

**da-Q0931 · Fill the gap**

Tom spiste de tre æbler ____ under fem minutter.

Tom ate the three apples in less than five minutes.

[[Danish#^da-Q0931-answer|Compare the answer]]
^da-Q0931

**da-Q0932 · Choose the form**

Tom spiste de tre æbler ____ under fem minutter.

Tom ate the three apples in less than five minutes.

Choices: fra / med / på / i

[[Danish#^da-Q0932-answer|Compare the answer]]
^da-Q0932

**da-Q0933 · Edit the changed sentence**

Bogen ligger 【i】 bordet.

The book is on the table.

[[Danish#^da-Q0933-answer|Compare the answer]]
^da-Q0933

**da-Q0934 · Build the sentence**

Arrange: ligger / Bogen / bordet. / på

The book is on the table.

[[Danish#^da-Q0934-answer|Compare the answer]]
^da-Q0934

**da-Q0935 · Write a translation**

Write this in Danish: He wrote a book in China.

[[Danish#^da-Q0935-answer|Compare the answer]]
^da-Q0935

**da-Q0936 · Explain the grammar**

Han skrev en bog 【i】 Kina.

He wrote a book in China.

[[Danish#^da-Q0936-answer|Compare the answer]]
^da-Q0936

**da-Q0937 · Fill the gap**

Vi er kabylere, ____ Kabylien, Algeriet.

We are Kabyles, from Kabylie, Algeria.

[[Danish#^da-Q0937-answer|Compare the answer]]
^da-Q0937

**da-Q0938 · Choose the form**

Vi er kabylere, ____ Kabylien, Algeriet.

We are Kabyles, from Kabylie, Algeria.

Choices: på / fra / med / i

[[Danish#^da-Q0938-answer|Compare the answer]]
^da-Q0938

**da-Q0939 · Edit the changed sentence**

Disse sommerfugle er sjældne 【på】 vort land.

These butterflies are rare in our country.

[[Danish#^da-Q0939-answer|Compare the answer]]
^da-Q0939

**da-Q0940 · Build the sentence**

Arrange: Disse / er / sommerfugle / vort / i / sjældne / land.

These butterflies are rare in our country.

[[Danish#^da-Q0940-answer|Compare the answer]]
^da-Q0940

**da-Q0941 · Write a translation**

Write this in Danish: Sami was riding that motorbike.

[[Danish#^da-Q0941-answer|Compare the answer]]
^da-Q0941

**da-Q0942 · Explain the grammar**

Sami kørte 【på】 den motorcykel.

Sami was riding that motorbike.

[[Danish#^da-Q0942-answer|Compare the answer]]
^da-Q0942

**da-Q0943 · Fill the gap**

Du er ____ tynd is.

You're treading on thin ice.

[[Danish#^da-Q0943-answer|Compare the answer]]
^da-Q0943

**da-Q0944 · Choose the form**

Du er ____ tynd is.

You're treading on thin ice.

Choices: fra / i / med / på

[[Danish#^da-Q0944-answer|Compare the answer]]
^da-Q0944

**da-Q0945 · Edit the changed sentence**

Tom blev forelsket 【på】 en smuk ung kvinde.

Tom fell in love with a beautiful young woman.

[[Danish#^da-Q0945-answer|Compare the answer]]
^da-Q0945

**da-Q0946 · Build the sentence**

Arrange: smuk / Tom / en / i / ung / kvinde. / blev / forelsket

Tom fell in love with a beautiful young woman.

[[Danish#^da-Q0946-answer|Compare the answer]]
^da-Q0946

**da-Q0947 · Write a translation**

Write this in Danish: I'm going to write a sentence in German.

[[Danish#^da-Q0947-answer|Compare the answer]]
^da-Q0947

**da-Q0948 · Explain the grammar**

Jeg skriver en sætning 【på】 tysk.

I'm going to write a sentence in German.

[[Danish#^da-Q0948-answer|Compare the answer]]
^da-Q0948

**da-Q0949 · Fill the gap**

Tom åbnede døren ____ klem.

Tom opened the door just a crack.

[[Danish#^da-Q0949-answer|Compare the answer]]
^da-Q0949

**da-Q0950 · Choose the form**

Tom åbnede døren ____ klem.

Tom opened the door just a crack.

Choices: med / i / fra / på

[[Danish#^da-Q0950-answer|Compare the answer]]
^da-Q0950


### Concession and inference · 50 questions

**da-Q0951 · Edit the changed sentence**

Tom er 【selvom】 lun på dig.

Tom may have a crush on you.

[[Danish#^da-Q0951-answer|Compare the answer]]
^da-Q0951

**da-Q0952 · Build the sentence**

Arrange: Tom / er / på / dig. / måske / lun

Tom may have a crush on you.

[[Danish#^da-Q0952-answer|Compare the answer]]
^da-Q0952

**da-Q0953 · Write a translation**

Write this in Danish: The police think that Tom might've poisoned Mary.

[[Danish#^da-Q0953-answer|Compare the answer]]
^da-Q0953

**da-Q0954 · Explain the grammar**

Politiet tror at Tom 【måske】 har forgiftet Mary.

The police think that Tom might've poisoned Mary.

[[Danish#^da-Q0954-answer|Compare the answer]]
^da-Q0954

**da-Q0955 · Fill the gap**

Det er ____ en skør ide, men jeg synes at vi burde besøge Tom og Mary lige nu.

It may seem like a crazy idea, but I think we should go visit Tom and Mary right now.

[[Danish#^da-Q0955-answer|Compare the answer]]
^da-Q0955

**da-Q0956 · Choose the form**

Det er ____ en skør ide, men jeg synes at vi burde besøge Tom og Mary lige nu.

It may seem like a crazy idea, but I think we should go visit Tom and Mary right now.

Choices: alligevel / selvom / måske / derfor

[[Danish#^da-Q0956-answer|Compare the answer]]
^da-Q0956

**da-Q0957 · Edit the changed sentence**

Tom blev ved med at køre helt op bag ved bilen foran os 【alligevel】 jeg fortalte ham at det kunne være farligt at gøre det.

Tom kept tailgating the car in front of us even though I told him it was unsafe to do so.

[[Danish#^da-Q0957-answer|Compare the answer]]
^da-Q0957

**da-Q0958 · Build the sentence**

Arrange: ved / bilen / fortalte / det. / kunne / foran / op / blev / farligt / at / gøre / jeg / ham / Tom / være / os / ved / bag / det / med / at / køre / helt / selvom / at

Tom kept tailgating the car in front of us even though I told him it was unsafe to do so.

[[Danish#^da-Q0958-answer|Compare the answer]]
^da-Q0958

**da-Q0959 · Write a translation**

Write this in Danish: The game will be held even if it rains.

[[Danish#^da-Q0959-answer|Compare the answer]]
^da-Q0959

**da-Q0960 · Explain the grammar**

Kampen vil blive spillet 【selvom】 det regner.

The game will be held even if it rains.

[[Danish#^da-Q0960-answer|Compare the answer]]
^da-Q0960

**da-Q0961 · Fill the gap**

Du har ____ hørt om mig.

You might have heard of me.

[[Danish#^da-Q0961-answer|Compare the answer]]
^da-Q0961

**da-Q0962 · Choose the form**

Du har ____ hørt om mig.

You might have heard of me.

Choices: måske / selvom / alligevel / derfor

[[Danish#^da-Q0962-answer|Compare the answer]]
^da-Q0962

**da-Q0963 · Edit the changed sentence**

Det vil 【selvom】 regne i aften.

It may rain tonight.

[[Danish#^da-Q0963-answer|Compare the answer]]
^da-Q0963

**da-Q0964 · Build the sentence**

Arrange: aften. / måske / i / vil / regne / Det

It may rain tonight.

[[Danish#^da-Q0964-answer|Compare the answer]]
^da-Q0964

**da-Q0965 · Write a translation**

Write this in Danish: Is that why Tom wanted to talk to you?

[[Danish#^da-Q0965-answer|Compare the answer]]
^da-Q0965

**da-Q0966 · Explain the grammar**

Er det 【derfor】 at Tom gerne ville tale med dig?

Is that why Tom wanted to talk to you?

[[Danish#^da-Q0966-answer|Compare the answer]]
^da-Q0966

**da-Q0967 · Fill the gap**

Problemet med rotteræset er, at ____ du vinder, er du stadig en rotte.

The trouble with the rat race is that even if you win, you're still a rat.

[[Danish#^da-Q0967-answer|Compare the answer]]
^da-Q0967

**da-Q0968 · Choose the form**

Problemet med rotteræset er, at ____ du vinder, er du stadig en rotte.

The trouble with the rat race is that even if you win, you're still a rat.

Choices: måske / selvom / alligevel / derfor

[[Danish#^da-Q0968-answer|Compare the answer]]
^da-Q0968

**da-Q0969 · Edit the changed sentence**

Som regel taler mine forældre med hinanden på fransk, 【alligevel】 min mor har engelsk som modersmål.

My parents usually speak to each other in French, even though my mother is a native English speaker.

[[Danish#^da-Q0969-answer|Compare the answer]]
^da-Q0969

**da-Q0970 · Build the sentence**

Arrange: har / fransk, / modersmål. / mine / mor / selvom / hinanden / min / engelsk / på / Som / regel / taler / som / forældre / med

My parents usually speak to each other in French, even though my mother is a native English speaker.

[[Danish#^da-Q0970-answer|Compare the answer]]
^da-Q0970

**da-Q0971 · Write a translation**

Write this in Danish: Hey, slow down!

[[Danish#^da-Q0971-answer|Compare the answer]]
^da-Q0971

**da-Q0972 · Explain the grammar**

Så sagtn 【dog】 farten!

Hey, slow down!

[[Danish#^da-Q0972-answer|Compare the answer]]
^da-Q0972

**da-Q0973 · Fill the gap**

Han gav mig kaffe, ____ jeg havde bedt om te.

He gave me coffee even though I had asked for tea.

[[Danish#^da-Q0973-answer|Compare the answer]]
^da-Q0973

**da-Q0974 · Choose the form**

Han gav mig kaffe, ____ jeg havde bedt om te.

He gave me coffee even though I had asked for tea.

Choices: derfor / måske / selvom / alligevel

[[Danish#^da-Q0974-answer|Compare the answer]]
^da-Q0974

**da-Q0975 · Edit the changed sentence**

Mine meninger har 【selvom】 ændret sig, men ikke det faktum at jeg har ret.

My opinions may have changed, but not the fact that I'm right.

[[Danish#^da-Q0975-answer|Compare the answer]]
^da-Q0975

**da-Q0976 · Build the sentence**

Arrange: har / men / Mine / måske / jeg / meninger / at / ikke / faktum / ændret / har / det / sig, / ret.

My opinions may have changed, but not the fact that I'm right.

[[Danish#^da-Q0976-answer|Compare the answer]]
^da-Q0976

**da-Q0977 · Write a translation**

Write this in Danish: It may rain tonight.

[[Danish#^da-Q0977-answer|Compare the answer]]
^da-Q0977

**da-Q0978 · Explain the grammar**

Det regner 【måske】 i aften.

It may rain tonight.

[[Danish#^da-Q0978-answer|Compare the answer]]
^da-Q0978

**da-Q0979 · Fill the gap**

Hun kommer ____.

She might come.

[[Danish#^da-Q0979-answer|Compare the answer]]
^da-Q0979

**da-Q0980 · Choose the form**

Hun kommer ____.

She might come.

Choices: måske / derfor / alligevel / selvom

[[Danish#^da-Q0980-answer|Compare the answer]]
^da-Q0980

**da-Q0981 · Edit the changed sentence**

Tom vil 【selvom】 vidne.

Tom might testify.

[[Danish#^da-Q0981-answer|Compare the answer]]
^da-Q0981

**da-Q0982 · Build the sentence**

Arrange: måske / vil / vidne. / Tom

Tom might testify.

[[Danish#^da-Q0982-answer|Compare the answer]]
^da-Q0982

**da-Q0983 · Write a translation**

Write this in Danish: He is very smart and yet not arrogant.

[[Danish#^da-Q0983-answer|Compare the answer]]
^da-Q0983

**da-Q0984 · Explain the grammar**

Han er meget klog og 【alligevel】 ikke arrogant.

He is very smart and yet not arrogant.

[[Danish#^da-Q0984-answer|Compare the answer]]
^da-Q0984

**da-Q0985 · Fill the gap**

Jeg tænker, ____ er jeg.

I think, therefore I am.

[[Danish#^da-Q0985-answer|Compare the answer]]
^da-Q0985

**da-Q0986 · Choose the form**

Jeg tænker, ____ er jeg.

I think, therefore I am.

Choices: måske / alligevel / selvom / derfor

[[Danish#^da-Q0986-answer|Compare the answer]]
^da-Q0986

**da-Q0987 · Edit the changed sentence**

Han åbnede døren, 【alligevel】 jeg bad ham lade være.

He opened the door, though I told him not to.

[[Danish#^da-Q0987-answer|Compare the answer]]
^da-Q0987

**da-Q0988 · Build the sentence**

Arrange: ham / åbnede / lade / bad / være. / døren, / jeg / Han / selvom

He opened the door, though I told him not to.

[[Danish#^da-Q0988-answer|Compare the answer]]
^da-Q0988

**da-Q0989 · Write a translation**

Write this in Danish: The bread was moldy, but Tom ate it anyway.

[[Danish#^da-Q0989-answer|Compare the answer]]
^da-Q0989

**da-Q0990 · Explain the grammar**

Brødet var muggent, men Tom spiste det 【alligevel】.

The bread was moldy, but Tom ate it anyway.

[[Danish#^da-Q0990-answer|Compare the answer]]
^da-Q0990

**da-Q0991 · Fill the gap**

Det er ____ han blev vred.

That's why he got angry.

[[Danish#^da-Q0991-answer|Compare the answer]]
^da-Q0991

**da-Q0992 · Choose the form**

Det er ____ han blev vred.

That's why he got angry.

Choices: måske / alligevel / derfor / selvom

[[Danish#^da-Q0992-answer|Compare the answer]]
^da-Q0992

**da-Q0993 · Edit the changed sentence**

Problemet er ikke så simpelt som det 【selvom】 kan synes ved første øjekast.

The problem is not as simple as it might seem at first sight.

[[Danish#^da-Q0993-answer|Compare the answer]]
^da-Q0993

**da-Q0994 · Build the sentence**

Arrange: er / måske / øjekast. / kan / Problemet / simpelt / synes / så / første / ikke / ved / som / det

The problem is not as simple as it might seem at first sight.

[[Danish#^da-Q0994-answer|Compare the answer]]
^da-Q0994

**da-Q0995 · Write a translation**

Write this in Danish: If something is an apple, then it's either red or green, or possibly both.

[[Danish#^da-Q0995-answer|Compare the answer]]
^da-Q0995

**da-Q0996 · Explain the grammar**

Hvis noget er et æble, så er det enten rødt eller grønt eller 【måske】 begge dele.

If something is an apple, then it's either red or green, or possibly both.

[[Danish#^da-Q0996-answer|Compare the answer]]
^da-Q0996

**da-Q0997 · Fill the gap**

Jeg har ____ ikke en universitetsgrad, men jeg er ikke komplet idiot.

I may not have a degree, but I'm not entirely stupid.

[[Danish#^da-Q0997-answer|Compare the answer]]
^da-Q0997

**da-Q0998 · Choose the form**

Jeg har ____ ikke en universitetsgrad, men jeg er ikke komplet idiot.

I may not have a degree, but I'm not entirely stupid.

Choices: alligevel / måske / selvom / derfor

[[Danish#^da-Q0998-answer|Compare the answer]]
^da-Q0998

**da-Q0999 · Edit the changed sentence**

Hvad der skræmte Tom mest, var tanken om at han 【selvom】 ikke kunne komme til at gå igen.

What scared Tom the most was the thought that he might not be able to walk again.

[[Danish#^da-Q0999-answer|Compare the answer]]
^da-Q0999

**da-Q1000 · Build the sentence**

Arrange: var / ikke / gå / til / mest, / igen. / Hvad / skræmte / komme / tanken / at / der / at / han / kunne / om / Tom / måske

What scared Tom the most was the thought that he might not be able to walk again.

[[Danish#^da-Q1000-answer|Compare the answer]]
^da-Q1000


## Answers

The full sentence is a model. For translation, judge whether meaning and grammar are preserved. Each grammar rule above explains the form.

### Answers 1–50

**da-Q0001** — "Oh, var jeg dog sådant et stort træ, som de andre!" sukkede det lille grantræ.

"Oh, if I were only as great a tree as the others!" sighed the little Fir.

Expected form: **et**

Why: En and et nouns. [[Danish#^da-Q0001|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=%22Oh%2C%20var%20jeg%20dog%20s%C3%A5dant%20et%20stort%20tr%C3%A6%2C%20som%20de%20andre%21%22%20sukkede%20det%20lille%20grantr%C3%A6.)
^da-Q0001-answer

**da-Q0002** — "Oh, var jeg dog sådant et stort træ, som de andre!" sukkede det lille grantræ.

"Oh, if I were only as great a tree as the others!" sighed the little Fir.

Expected form: **et**

Why: En and et nouns. [[Danish#^da-Q0002|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=%22Oh%2C%20var%20jeg%20dog%20s%C3%A5dant%20et%20stort%20tr%C3%A6%2C%20som%20de%20andre%21%22%20sukkede%20det%20lille%20grantr%C3%A6.)
^da-Q0002-answer

**da-Q0003** — Marathi er navnet på et vigtigt indoarisk sprog, der tales i det vestlige og centrale Indien.

Marathi is the name of an important Indo-Aryan language spoken in western and central India.

Expected form: **et**

Why: En and et nouns. [[Danish#^da-Q0003|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Marathi%20er%20navnet%20p%C3%A5%20et%20vigtigt%20indoarisk%20sprog%2C%20der%20tales%20i%20det%20vestlige%20og%20centrale%20Indien.)
^da-Q0003-answer

**da-Q0004** — Marathi er navnet på et vigtigt indoarisk sprog, der tales i det vestlige og centrale Indien.

Marathi is the name of an important Indo-Aryan language spoken in western and central India.

Why: En and et nouns. [[Danish#^da-Q0004|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Marathi%20er%20navnet%20p%C3%A5%20et%20vigtigt%20indoarisk%20sprog%2C%20der%20tales%20i%20det%20vestlige%20og%20centrale%20Indien.)
^da-Q0004-answer

**da-Q0005** — Dette er en offentlig gade, ikke en væddeløbsbane!

This is a public street, not a racetrack.

Why: En and et nouns. [[Danish#^da-Q0005|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Dette%20er%20en%20offentlig%20gade%2C%20ikke%20en%20v%C3%A6ddel%C3%B8bsbane%21)
^da-Q0005-answer

**da-Q0006** — Dette er en offentlig gade, ikke en væddeløbsbane!

This is a public street, not a racetrack.

Danish has common and neuter grammatical gender. En/et is part of a noun’s lexical information. Definite singular often adds -en/-et directly to the noun.

Why: En and et nouns. [[Danish#^da-Q0006|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Dette%20er%20en%20offentlig%20gade%2C%20ikke%20en%20v%C3%A6ddel%C3%B8bsbane%21)
^da-Q0006-answer

**da-Q0007** — Lad os få en drink.

Have a drink with me.

Expected form: **en**

Why: En and et nouns. [[Danish#^da-Q0007|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Lad%20os%20f%C3%A5%20en%20drink.)
^da-Q0007-answer

**da-Q0008** — Lad os få en drink.

Have a drink with me.

Expected form: **en**

Why: En and et nouns. [[Danish#^da-Q0008|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Lad%20os%20f%C3%A5%20en%20drink.)
^da-Q0008-answer

**da-Q0009** — Hun er en skør heks.

She's a crazy witch.

Expected form: **en**

Why: En and et nouns. [[Danish#^da-Q0009|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hun%20er%20en%20sk%C3%B8r%20heks.)
^da-Q0009-answer

**da-Q0010** — Hun er en skør heks.

She's a crazy witch.

Why: En and et nouns. [[Danish#^da-Q0010|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hun%20er%20en%20sk%C3%B8r%20heks.)
^da-Q0010-answer

**da-Q0011** — Hun er et fjols.

She's an airhead.

Why: En and et nouns. [[Danish#^da-Q0011|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hun%20er%20et%20fjols.)
^da-Q0011-answer

**da-Q0012** — Hun er et fjols.

She's an airhead.

Danish has common and neuter grammatical gender. En/et is part of a noun’s lexical information. Definite singular often adds -en/-et directly to the noun.

Why: En and et nouns. [[Danish#^da-Q0012|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hun%20er%20et%20fjols.)
^da-Q0012-answer

**da-Q0013** — I Europa betragter man punktlighed som en selvfølge.

In Europe, people regard punctuality as a matter of course.

Expected form: **en**

Why: En and et nouns. [[Danish#^da-Q0013|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=I%20Europa%20betragter%20man%20punktlighed%20som%20en%20selvf%C3%B8lge.)
^da-Q0013-answer

**da-Q0014** — I Europa betragter man punktlighed som en selvfølge.

In Europe, people regard punctuality as a matter of course.

Expected form: **en**

Why: En and et nouns. [[Danish#^da-Q0014|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=I%20Europa%20betragter%20man%20punktlighed%20som%20en%20selvf%C3%B8lge.)
^da-Q0014-answer

**da-Q0015** — Tom gav mig en harmonika til jul.

Tom gave me a harmonica for Christmas.

Expected form: **en**

Why: En and et nouns. [[Danish#^da-Q0015|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20gav%20mig%20en%20harmonika%20til%20jul.)
^da-Q0015-answer

**da-Q0016** — Tom gav mig en harmonika til jul.

Tom gave me a harmonica for Christmas.

Why: En and et nouns. [[Danish#^da-Q0016|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20gav%20mig%20en%20harmonika%20til%20jul.)
^da-Q0016-answer

**da-Q0017** — Tom arbejder på en pastafabrik.

Tom works in a pasta factory.

Why: En and et nouns. [[Danish#^da-Q0017|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20arbejder%20p%C3%A5%20en%20pastafabrik.)
^da-Q0017-answer

**da-Q0018** — Tom arbejder på en pastafabrik.

Tom works in a pasta factory.

Danish has common and neuter grammatical gender. En/et is part of a noun’s lexical information. Definite singular often adds -en/-et directly to the noun.

Why: En and et nouns. [[Danish#^da-Q0018|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20arbejder%20p%C3%A5%20en%20pastafabrik.)
^da-Q0018-answer

**da-Q0019** — Tom havde en dåse øl i hånden og tre til i rygsækken.

Tom had one can of beer in his hand and three more in his pack.

Expected form: **en**

Why: En and et nouns. [[Danish#^da-Q0019|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20havde%20en%20d%C3%A5se%20%C3%B8l%20i%20h%C3%A5nden%20og%20tre%20til%20i%20rygs%C3%A6kken.)
^da-Q0019-answer

**da-Q0020** — Tom havde en dåse øl i hånden og tre til i rygsækken.

Tom had one can of beer in his hand and three more in his pack.

Expected form: **en**

Why: En and et nouns. [[Danish#^da-Q0020|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20havde%20en%20d%C3%A5se%20%C3%B8l%20i%20h%C3%A5nden%20og%20tre%20til%20i%20rygs%C3%A6kken.)
^da-Q0020-answer

**da-Q0021** — Jeg har aldrig før set en så stor vandmelon.

I've never seen such a giant watermelon!

Expected form: **en**

Why: En and et nouns. [[Danish#^da-Q0021|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20har%20aldrig%20f%C3%B8r%20set%20en%20s%C3%A5%20stor%20vandmelon.)
^da-Q0021-answer

**da-Q0022** — Jeg har aldrig før set en så stor vandmelon.

I've never seen such a giant watermelon!

Why: En and et nouns. [[Danish#^da-Q0022|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20har%20aldrig%20f%C3%B8r%20set%20en%20s%C3%A5%20stor%20vandmelon.)
^da-Q0022-answer

**da-Q0023** — Denne raket er et mobilt våben, der hurtigt kan flyttes fra et sted til et andet.

This missile is a mobile weapon which can be moved rapidly from one place to another.

Why: En and et nouns. [[Danish#^da-Q0023|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Denne%20raket%20er%20et%20mobilt%20v%C3%A5ben%2C%20der%20hurtigt%20kan%20flyttes%20fra%20et%20sted%20til%20et%20andet.)
^da-Q0023-answer

**da-Q0024** — Denne raket er et mobilt våben, der hurtigt kan flyttes fra et sted til et andet.

This missile is a mobile weapon which can be moved rapidly from one place to another.

Danish has common and neuter grammatical gender. En/et is part of a noun’s lexical information. Definite singular often adds -en/-et directly to the noun.

Why: En and et nouns. [[Danish#^da-Q0024|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Denne%20raket%20er%20et%20mobilt%20v%C3%A5ben%2C%20der%20hurtigt%20kan%20flyttes%20fra%20et%20sted%20til%20et%20andet.)
^da-Q0024-answer

**da-Q0025** — Hans hund har været syg i en uge.

His dog has been ill for a week.

Expected form: **en**

Why: En and et nouns. [[Danish#^da-Q0025|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hans%20hund%20har%20v%C3%A6ret%20syg%20i%20en%20uge.)
^da-Q0025-answer

**da-Q0026** — Hans hund har været syg i en uge.

His dog has been ill for a week.

Expected form: **en**

Why: En and et nouns. [[Danish#^da-Q0026|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hans%20hund%20har%20v%C3%A6ret%20syg%20i%20en%20uge.)
^da-Q0026-answer

**da-Q0027** — Du er en gavstrik, Tom.

You're a rogue, Tom.

Expected form: **en**

Why: En and et nouns. [[Danish#^da-Q0027|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Du%20er%20en%20gavstrik%2C%20Tom.)
^da-Q0027-answer

**da-Q0028** — Du er en gavstrik, Tom.

You're a rogue, Tom.

Why: En and et nouns. [[Danish#^da-Q0028|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Du%20er%20en%20gavstrik%2C%20Tom.)
^da-Q0028-answer

**da-Q0029** — Da Tom kiggede ned på æblet han var ved at spise, blev han klar over at han havde spist en halv orm.

When Tom looked down at the apple he was eating, he realized that he had eaten half a worm.

Why: En and et nouns. [[Danish#^da-Q0029|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Da%20Tom%20kiggede%20ned%20p%C3%A5%20%C3%A6blet%20han%20var%20ved%20at%20spise%2C%20blev%20han%20klar%20over%20at%20han%20havde%20spist%20en%20halv%20orm.)
^da-Q0029-answer

**da-Q0030** — Da Tom kiggede ned på æblet han var ved at spise, blev han klar over at han havde spist en halv orm.

When Tom looked down at the apple he was eating, he realized that he had eaten half a worm.

Danish has common and neuter grammatical gender. En/et is part of a noun’s lexical information. Definite singular often adds -en/-et directly to the noun.

Why: En and et nouns. [[Danish#^da-Q0030|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Da%20Tom%20kiggede%20ned%20p%C3%A5%20%C3%A6blet%20han%20var%20ved%20at%20spise%2C%20blev%20han%20klar%20over%20at%20han%20havde%20spist%20en%20halv%20orm.)
^da-Q0030-answer

**da-Q0031** — Jeg modtog et brev, der informerede mig om hans ankomst.

I received a letter informing me of his arrival.

Expected form: **et**

Why: En and et nouns. [[Danish#^da-Q0031|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20modtog%20et%20brev%2C%20der%20informerede%20mig%20om%20hans%20ankomst.)
^da-Q0031-answer

**da-Q0032** — Jeg modtog et brev, der informerede mig om hans ankomst.

I received a letter informing me of his arrival.

Expected form: **et**

Why: En and et nouns. [[Danish#^da-Q0032|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20modtog%20et%20brev%2C%20der%20informerede%20mig%20om%20hans%20ankomst.)
^da-Q0032-answer

**da-Q0033** — Tom tog ikke et bad.

Tom didn't take a shower.

Expected form: **et**

Why: En and et nouns. [[Danish#^da-Q0033|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20tog%20ikke%20et%20bad.)
^da-Q0033-answer

**da-Q0034** — Tom tog ikke et bad.

Tom didn't take a shower.

Why: En and et nouns. [[Danish#^da-Q0034|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20tog%20ikke%20et%20bad.)
^da-Q0034-answer

**da-Q0035** — Han har en forfærdelig håndskrift.

He's got terrible handwriting.

Why: En and et nouns. [[Danish#^da-Q0035|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Han%20har%20en%20forf%C3%A6rdelig%20h%C3%A5ndskrift.)
^da-Q0035-answer

**da-Q0036** — Han har en forfærdelig håndskrift.

He's got terrible handwriting.

Danish has common and neuter grammatical gender. En/et is part of a noun’s lexical information. Definite singular often adds -en/-et directly to the noun.

Why: En and et nouns. [[Danish#^da-Q0036|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Han%20har%20en%20forf%C3%A6rdelig%20h%C3%A5ndskrift.)
^da-Q0036-answer

**da-Q0037** — Folk har en tendens til at undervurdere deres fremtidige behov.

People have a tendency to underestimate their future needs.

Expected form: **en**

Why: En and et nouns. [[Danish#^da-Q0037|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Folk%20har%20en%20tendens%20til%20at%20undervurdere%20deres%20fremtidige%20behov.)
^da-Q0037-answer

**da-Q0038** — Folk har en tendens til at undervurdere deres fremtidige behov.

People have a tendency to underestimate their future needs.

Expected form: **en**

Why: En and et nouns. [[Danish#^da-Q0038|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Folk%20har%20en%20tendens%20til%20at%20undervurdere%20deres%20fremtidige%20behov.)
^da-Q0038-answer

**da-Q0039** — Økonomien var i en elendig stand.

The economy was in miserable condition.

Expected form: **en**

Why: En and et nouns. [[Danish#^da-Q0039|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=%C3%98konomien%20var%20i%20en%20elendig%20stand.)
^da-Q0039-answer

**da-Q0040** — Økonomien var i en elendig stand.

The economy was in miserable condition.

Why: En and et nouns. [[Danish#^da-Q0040|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=%C3%98konomien%20var%20i%20en%20elendig%20stand.)
^da-Q0040-answer

**da-Q0041** — Lad os gå et sted hen, hvor vi kan tale privat.

Let's go someplace where we can talk in private.

Why: En and et nouns. [[Danish#^da-Q0041|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Lad%20os%20g%C3%A5%20et%20sted%20hen%2C%20hvor%20vi%20kan%20tale%20privat.)
^da-Q0041-answer

**da-Q0042** — Lad os gå et sted hen, hvor vi kan tale privat.

Let's go someplace where we can talk in private.

Danish has common and neuter grammatical gender. En/et is part of a noun’s lexical information. Definite singular often adds -en/-et directly to the noun.

Why: En and et nouns. [[Danish#^da-Q0042|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Lad%20os%20g%C3%A5%20et%20sted%20hen%2C%20hvor%20vi%20kan%20tale%20privat.)
^da-Q0042-answer

**da-Q0043** — Har du købt en ny bil?

Did you buy a new car?

Expected form: **en**

Why: En and et nouns. [[Danish#^da-Q0043|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Har%20du%20k%C3%B8bt%20en%20ny%20bil%3F)
^da-Q0043-answer

**da-Q0044** — Har du købt en ny bil?

Did you buy a new car?

Expected form: **en**

Why: En and et nouns. [[Danish#^da-Q0044|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Har%20du%20k%C3%B8bt%20en%20ny%20bil%3F)
^da-Q0044-answer

**da-Q0045** — Han blev sendt på et psykiatrisk hospital.

He was sent to a mental hospital.

Expected form: **et**

Why: En and et nouns. [[Danish#^da-Q0045|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Han%20blev%20sendt%20p%C3%A5%20et%20psykiatrisk%20hospital.)
^da-Q0045-answer

**da-Q0046** — Han blev sendt på et psykiatrisk hospital.

He was sent to a mental hospital.

Why: En and et nouns. [[Danish#^da-Q0046|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Han%20blev%20sendt%20p%C3%A5%20et%20psykiatrisk%20hospital.)
^da-Q0046-answer

**da-Q0047** — Grækerne byggede en træhest.

The Greeks built a wooden horse.

Why: En and et nouns. [[Danish#^da-Q0047|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Gr%C3%A6kerne%20byggede%20en%20tr%C3%A6hest.)
^da-Q0047-answer

**da-Q0048** — Grækerne byggede en træhest.

The Greeks built a wooden horse.

Danish has common and neuter grammatical gender. En/et is part of a noun’s lexical information. Definite singular often adds -en/-et directly to the noun.

Why: En and et nouns. [[Danish#^da-Q0048|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Gr%C3%A6kerne%20byggede%20en%20tr%C3%A6hest.)
^da-Q0048-answer

**da-Q0049** — Har I taget en hårtørrer med?

Did you bring a hair dryer?

Expected form: **en**

Why: En and et nouns. [[Danish#^da-Q0049|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Har%20I%20taget%20en%20h%C3%A5rt%C3%B8rrer%20med%3F)
^da-Q0049-answer

**da-Q0050** — Har I taget en hårtørrer med?

Did you bring a hair dryer?

Expected form: **en**

Why: En and et nouns. [[Danish#^da-Q0050|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Har%20I%20taget%20en%20h%C3%A5rt%C3%B8rrer%20med%3F)
^da-Q0050-answer


### Answers 51–100

**da-Q0051** — Bærer din kone det muslimske tørklæde?

Does your wife wear the Muslim headscarf?

Expected form: **det**

Why: Definite and demonstrative forms. [[Danish#^da-Q0051|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=B%C3%A6rer%20din%20kone%20det%20muslimske%20t%C3%B8rkl%C3%A6de%3F)
^da-Q0051-answer

**da-Q0052** — Bærer din kone det muslimske tørklæde?

Does your wife wear the Muslim headscarf?

Why: Definite and demonstrative forms. [[Danish#^da-Q0052|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=B%C3%A6rer%20din%20kone%20det%20muslimske%20t%C3%B8rkl%C3%A6de%3F)
^da-Q0052-answer

**da-Q0053** — Gør bare det færdigt som du er i gang med.

Just finish what you're doing.

Why: Definite and demonstrative forms. [[Danish#^da-Q0053|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=G%C3%B8r%20bare%20det%20f%C3%A6rdigt%20som%20du%20er%20i%20gang%20med.)
^da-Q0053-answer

**da-Q0054** — Gør bare det færdigt som du er i gang med.

Just finish what you're doing.

Den/det/de precede many definite adjective phrases and can serve as pronouns. Their form depends on gender/number. Context distinguishes article and demonstrative functions.

Why: Definite and demonstrative forms. [[Danish#^da-Q0054|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=G%C3%B8r%20bare%20det%20f%C3%A6rdigt%20som%20du%20er%20i%20gang%20med.)
^da-Q0054-answer

**da-Q0055** — Hvor er det koldt!

How cold it is!

Expected form: **det**

Why: Definite and demonstrative forms. [[Danish#^da-Q0055|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hvor%20er%20det%20koldt%21)
^da-Q0055-answer

**da-Q0056** — Hvor er det koldt!

How cold it is!

Expected form: **det**

Why: Definite and demonstrative forms. [[Danish#^da-Q0056|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hvor%20er%20det%20koldt%21)
^da-Q0056-answer

**da-Q0057** — Kun Tom ved det.

Only Tom knows that.

Expected form: **det**

Why: Definite and demonstrative forms. [[Danish#^da-Q0057|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Kun%20Tom%20ved%20det.)
^da-Q0057-answer

**da-Q0058** — Kun Tom ved det.

Only Tom knows that.

Why: Definite and demonstrative forms. [[Danish#^da-Q0058|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Kun%20Tom%20ved%20det.)
^da-Q0058-answer

**da-Q0059** — Det er ret varmt, er det ikke?

It's quite hot, isn't it?

Why: Definite and demonstrative forms. [[Danish#^da-Q0059|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Det%20er%20ret%20varmt%2C%20er%20det%20ikke%3F)
^da-Q0059-answer

**da-Q0060** — Det er ret varmt, er det ikke?

It's quite hot, isn't it?

Den/det/de precede many definite adjective phrases and can serve as pronouns. Their form depends on gender/number. Context distinguishes article and demonstrative functions.

Why: Definite and demonstrative forms. [[Danish#^da-Q0060|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Det%20er%20ret%20varmt%2C%20er%20det%20ikke%3F)
^da-Q0060-answer

**da-Q0061** — Enhver af disse elevatorer kan bære ti personer.

These elevators are each capable of carrying ten persons.

Expected form: **disse**

Why: Definite and demonstrative forms. [[Danish#^da-Q0061|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Enhver%20af%20disse%20elevatorer%20kan%20b%C3%A6re%20ti%20personer.)
^da-Q0061-answer

**da-Q0062** — Enhver af disse elevatorer kan bære ti personer.

These elevators are each capable of carrying ten persons.

Expected form: **disse**

Why: Definite and demonstrative forms. [[Danish#^da-Q0062|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Enhver%20af%20disse%20elevatorer%20kan%20b%C3%A6re%20ti%20personer.)
^da-Q0062-answer

**da-Q0063** — Jeg har ikke hørt det ord i lang tid.

I haven't heard that word in a long time.

Expected form: **det**

Why: Definite and demonstrative forms. [[Danish#^da-Q0063|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20har%20ikke%20h%C3%B8rt%20det%20ord%20i%20lang%20tid.)
^da-Q0063-answer

**da-Q0064** — Jeg har ikke hørt det ord i lang tid.

I haven't heard that word in a long time.

Why: Definite and demonstrative forms. [[Danish#^da-Q0064|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20har%20ikke%20h%C3%B8rt%20det%20ord%20i%20lang%20tid.)
^da-Q0064-answer

**da-Q0065** — Tom og Mary vidste at de ville tage det rigtige valg.

Tom and Mary knew they'd made the right choice.

Why: Definite and demonstrative forms. [[Danish#^da-Q0065|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20og%20Mary%20vidste%20at%20de%20ville%20tage%20det%20rigtige%20valg.)
^da-Q0065-answer

**da-Q0066** — Tom og Mary vidste at de ville tage det rigtige valg.

Tom and Mary knew they'd made the right choice.

Den/det/de precede many definite adjective phrases and can serve as pronouns. Their form depends on gender/number. Context distinguishes article and demonstrative functions.

Why: Definite and demonstrative forms. [[Danish#^da-Q0066|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20og%20Mary%20vidste%20at%20de%20ville%20tage%20det%20rigtige%20valg.)
^da-Q0066-answer

**da-Q0067** — Hvor er den danske ambassade?

Where is the Danish embassy?

Expected form: **den**

Why: Definite and demonstrative forms. [[Danish#^da-Q0067|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hvor%20er%20den%20danske%20ambassade%3F)
^da-Q0067-answer

**da-Q0068** — Hvor er den danske ambassade?

Where is the Danish embassy?

Expected form: **den**

Why: Definite and demonstrative forms. [[Danish#^da-Q0068|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hvor%20er%20den%20danske%20ambassade%3F)
^da-Q0068-answer

**da-Q0069** — Jeg kan ikke tro at det her virkelig sker.

I can't believe this is really happening.

Expected form: **det**

Why: Definite and demonstrative forms. [[Danish#^da-Q0069|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20kan%20ikke%20tro%20at%20det%20her%20virkelig%20sker.)
^da-Q0069-answer

**da-Q0070** — Jeg kan ikke tro at det her virkelig sker.

I can't believe this is really happening.

Why: Definite and demonstrative forms. [[Danish#^da-Q0070|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20kan%20ikke%20tro%20at%20det%20her%20virkelig%20sker.)
^da-Q0070-answer

**da-Q0071** — Vis mig det.

Show me that.

Why: Definite and demonstrative forms. [[Danish#^da-Q0071|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Vis%20mig%20det.)
^da-Q0071-answer

**da-Q0072** — Vis mig det.

Show me that.

Den/det/de precede many definite adjective phrases and can serve as pronouns. Their form depends on gender/number. Context distinguishes article and demonstrative functions.

Why: Definite and demonstrative forms. [[Danish#^da-Q0072|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Vis%20mig%20det.)
^da-Q0072-answer

**da-Q0073** — Tom er ikke bange for slanger, end ikke de giftige.

Tom isn't afraid of snakes, even poisonous ones.

Expected form: **de**

Why: Definite and demonstrative forms. [[Danish#^da-Q0073|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20er%20ikke%20bange%20for%20slanger%2C%20end%20ikke%20de%20giftige.)
^da-Q0073-answer

**da-Q0074** — Tom er ikke bange for slanger, end ikke de giftige.

Tom isn't afraid of snakes, even poisonous ones.

Expected form: **de**

Why: Definite and demonstrative forms. [[Danish#^da-Q0074|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20er%20ikke%20bange%20for%20slanger%2C%20end%20ikke%20de%20giftige.)
^da-Q0074-answer

**da-Q0075** — Frederik den Store indførte kartoflen i Preussen.

Frederick the Great introduced the potato to Prussia.

Expected form: **den**

Why: Definite and demonstrative forms. [[Danish#^da-Q0075|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Frederik%20den%20Store%20indf%C3%B8rte%20kartoflen%20i%20Preussen.)
^da-Q0075-answer

**da-Q0076** — Frederik den Store indførte kartoflen i Preussen.

Frederick the Great introduced the potato to Prussia.

Why: Definite and demonstrative forms. [[Danish#^da-Q0076|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Frederik%20den%20Store%20indf%C3%B8rte%20kartoflen%20i%20Preussen.)
^da-Q0076-answer

**da-Q0077** — Jeg tror du er den eneste der har brug for hjælp.

I think you're the only one who needs help.

Why: Definite and demonstrative forms. [[Danish#^da-Q0077|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20tror%20du%20er%20den%20eneste%20der%20har%20brug%20for%20hj%C3%A6lp.)
^da-Q0077-answer

**da-Q0078** — Jeg tror du er den eneste der har brug for hjælp.

I think you're the only one who needs help.

Den/det/de precede many definite adjective phrases and can serve as pronouns. Their form depends on gender/number. Context distinguishes article and demonstrative functions.

Why: Definite and demonstrative forms. [[Danish#^da-Q0078|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20tror%20du%20er%20den%20eneste%20der%20har%20brug%20for%20hj%C3%A6lp.)
^da-Q0078-answer

**da-Q0079** — Vi kunne ikke andet end at beundre den smukke solnedgang.

We could not help admiring the beautiful sunset.

Expected form: **den**

Why: Definite and demonstrative forms. [[Danish#^da-Q0079|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Vi%20kunne%20ikke%20andet%20end%20at%20beundre%20den%20smukke%20solnedgang.)
^da-Q0079-answer

**da-Q0080** — Vi kunne ikke andet end at beundre den smukke solnedgang.

We could not help admiring the beautiful sunset.

Expected form: **den**

Why: Definite and demonstrative forms. [[Danish#^da-Q0080|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Vi%20kunne%20ikke%20andet%20end%20at%20beundre%20den%20smukke%20solnedgang.)
^da-Q0080-answer

**da-Q0081** — Tom er den bedste der er.

Tom's the best there is.

Expected form: **den**

Why: Definite and demonstrative forms. [[Danish#^da-Q0081|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20er%20den%20bedste%20der%20er.)
^da-Q0081-answer

**da-Q0082** — Tom er den bedste der er.

Tom's the best there is.

Why: Definite and demonstrative forms. [[Danish#^da-Q0082|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20er%20den%20bedste%20der%20er.)
^da-Q0082-answer

**da-Q0083** — Mindst 10 russere er omkommet i år mens de tog selfies.

At least 10 Russians have died this year taking selfies.

Why: Definite and demonstrative forms. [[Danish#^da-Q0083|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Mindst%2010%20russere%20er%20omkommet%20i%20%C3%A5r%20mens%20de%20tog%20selfies.)
^da-Q0083-answer

**da-Q0084** — Mindst 10 russere er omkommet i år mens de tog selfies.

At least 10 Russians have died this year taking selfies.

Den/det/de precede many definite adjective phrases and can serve as pronouns. Their form depends on gender/number. Context distinguishes article and demonstrative functions.

Why: Definite and demonstrative forms. [[Danish#^da-Q0084|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Mindst%2010%20russere%20er%20omkommet%20i%20%C3%A5r%20mens%20de%20tog%20selfies.)
^da-Q0084-answer

**da-Q0085** — Jeg ønskede ikke at de skulle tage afsted.

I didn't want them to leave.

Expected form: **de**

Why: Definite and demonstrative forms. [[Danish#^da-Q0085|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20%C3%B8nskede%20ikke%20at%20de%20skulle%20tage%20afsted.)
^da-Q0085-answer

**da-Q0086** — Jeg ønskede ikke at de skulle tage afsted.

I didn't want them to leave.

Expected form: **de**

Why: Definite and demonstrative forms. [[Danish#^da-Q0086|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20%C3%B8nskede%20ikke%20at%20de%20skulle%20tage%20afsted.)
^da-Q0086-answer

**da-Q0087** — I denne tid med postfaktuel politik er det nemt at håndplukke data og komme til hvilken som helst konklusion man ønsker.

In this era of post-truth politics, it's easy to cherry-pick data and come to whatever conclusion you desire.

Expected form: **denne**

Why: Definite and demonstrative forms. [[Danish#^da-Q0087|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=I%20denne%20tid%20med%20postfaktuel%20politik%20er%20det%20nemt%20at%20h%C3%A5ndplukke%20data%20og%20komme%20til%20hvilken%20som%20helst%20konklusion%20man%20%C3%B8nsker.)
^da-Q0087-answer

**da-Q0088** — I denne tid med postfaktuel politik er det nemt at håndplukke data og komme til hvilken som helst konklusion man ønsker.

In this era of post-truth politics, it's easy to cherry-pick data and come to whatever conclusion you desire.

Why: Definite and demonstrative forms. [[Danish#^da-Q0088|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=I%20denne%20tid%20med%20postfaktuel%20politik%20er%20det%20nemt%20at%20h%C3%A5ndplukke%20data%20og%20komme%20til%20hvilken%20som%20helst%20konklusion%20man%20%C3%B8nsker.)
^da-Q0088-answer

**da-Q0089** — Jeg vil sælge den så snart jeg finder en køber.

I will sell it as soon as I find a buyer.

Why: Definite and demonstrative forms. [[Danish#^da-Q0089|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20vil%20s%C3%A6lge%20den%20s%C3%A5%20snart%20jeg%20finder%20en%20k%C3%B8ber.)
^da-Q0089-answer

**da-Q0090** — Jeg vil sælge den så snart jeg finder en køber.

I will sell it as soon as I find a buyer.

Den/det/de precede many definite adjective phrases and can serve as pronouns. Their form depends on gender/number. Context distinguishes article and demonstrative functions.

Why: Definite and demonstrative forms. [[Danish#^da-Q0090|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20vil%20s%C3%A6lge%20den%20s%C3%A5%20snart%20jeg%20finder%20en%20k%C3%B8ber.)
^da-Q0090-answer

**da-Q0091** — "Jeg er helt alene." "Men det passer jo slet ikke! Du har da venner!"

"I'm all alone." "But that's not true at all! You have friends!"

Expected form: **det**

Why: Definite and demonstrative forms. [[Danish#^da-Q0091|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=%22Jeg%20er%20helt%20alene.%22%20%22Men%20det%20passer%20jo%20slet%20ikke%21%20Du%20har%20da%20venner%21%22)
^da-Q0091-answer

**da-Q0092** — "Jeg er helt alene." "Men det passer jo slet ikke! Du har da venner!"

"I'm all alone." "But that's not true at all! You have friends!"

Expected form: **det**

Why: Definite and demonstrative forms. [[Danish#^da-Q0092|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=%22Jeg%20er%20helt%20alene.%22%20%22Men%20det%20passer%20jo%20slet%20ikke%21%20Du%20har%20da%20venner%21%22)
^da-Q0092-answer

**da-Q0093** — Jeg elsker kandiserede kastanjer, men de er meget søde.

I love candied chestnuts, but they are very sweet.

Expected form: **de**

Why: Definite and demonstrative forms. [[Danish#^da-Q0093|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20elsker%20kandiserede%20kastanjer%2C%20men%20de%20er%20meget%20s%C3%B8de.)
^da-Q0093-answer

**da-Q0094** — Jeg elsker kandiserede kastanjer, men de er meget søde.

I love candied chestnuts, but they are very sweet.

Why: Definite and demonstrative forms. [[Danish#^da-Q0094|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20elsker%20kandiserede%20kastanjer%2C%20men%20de%20er%20meget%20s%C3%B8de.)
^da-Q0094-answer

**da-Q0095** — De fattige støtter de rige.

The poor support the rich.

Why: Definite and demonstrative forms. [[Danish#^da-Q0095|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=De%20fattige%20st%C3%B8tter%20de%20rige.)
^da-Q0095-answer

**da-Q0096** — De fattige støtter de rige.

The poor support the rich.

Den/det/de precede many definite adjective phrases and can serve as pronouns. Their form depends on gender/number. Context distinguishes article and demonstrative functions.

Why: Definite and demonstrative forms. [[Danish#^da-Q0096|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=De%20fattige%20st%C3%B8tter%20de%20rige.)
^da-Q0096-answer

**da-Q0097** — Jeg syntes at det lød så underligt.

I thought that it sounded so odd.

Expected form: **det**

Why: Definite and demonstrative forms. [[Danish#^da-Q0097|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20syntes%20at%20det%20l%C3%B8d%20s%C3%A5%20underligt.)
^da-Q0097-answer

**da-Q0098** — Jeg syntes at det lød så underligt.

I thought that it sounded so odd.

Expected form: **det**

Why: Definite and demonstrative forms. [[Danish#^da-Q0098|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20syntes%20at%20det%20l%C3%B8d%20s%C3%A5%20underligt.)
^da-Q0098-answer

**da-Q0099** — Hvis jeg kunne sende dig en skumfidus, Trang, ville jeg gøre det.

If I could send you a marshmallow, Trang, I would.

Expected form: **det**

Why: Definite and demonstrative forms. [[Danish#^da-Q0099|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hvis%20jeg%20kunne%20sende%20dig%20en%20skumfidus%2C%20Trang%2C%20ville%20jeg%20g%C3%B8re%20det.)
^da-Q0099-answer

**da-Q0100** — Hvis jeg kunne sende dig en skumfidus, Trang, ville jeg gøre det.

If I could send you a marshmallow, Trang, I would.

Why: Definite and demonstrative forms. [[Danish#^da-Q0100|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hvis%20jeg%20kunne%20sende%20dig%20en%20skumfidus%2C%20Trang%2C%20ville%20jeg%20g%C3%B8re%20det.)
^da-Q0100-answer


### Answers 101–150

**da-Q0101** — Vi kender ham ikke.

We don't know him.

Why: Personal pronouns. [[Danish#^da-Q0101|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Vi%20kender%20ham%20ikke.)
^da-Q0101-answer

**da-Q0102** — Vi kender ham ikke.

We don't know him.

Subject and object pronoun forms differ. Danish finite verbs generally do not change for person. Capital I means plural you and differs from lowercase i, in.

Why: Personal pronouns. [[Danish#^da-Q0102|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Vi%20kender%20ham%20ikke.)
^da-Q0102-answer

**da-Q0103** — Tom havde al ret til at gøre, hvad han gjorde.

Tom had every right to do what he did.

Expected form: **han**

Why: Personal pronouns. [[Danish#^da-Q0103|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20havde%20al%20ret%20til%20at%20g%C3%B8re%2C%20hvad%20han%20gjorde.)
^da-Q0103-answer

**da-Q0104** — Tom havde al ret til at gøre, hvad han gjorde.

Tom had every right to do what he did.

Expected form: **han**

Why: Personal pronouns. [[Danish#^da-Q0104|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20havde%20al%20ret%20til%20at%20g%C3%B8re%2C%20hvad%20han%20gjorde.)
^da-Q0104-answer

**da-Q0105** — Jeg ville gøre alt for dig.

I'd do anything for you.

Expected form: **dig**

Why: Personal pronouns. [[Danish#^da-Q0105|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20ville%20g%C3%B8re%20alt%20for%20dig.)
^da-Q0105-answer

**da-Q0106** — Jeg ville gøre alt for dig.

I'd do anything for you.

Why: Personal pronouns. [[Danish#^da-Q0106|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20ville%20g%C3%B8re%20alt%20for%20dig.)
^da-Q0106-answer

**da-Q0107** — Brug aldrig dine penge, før du har tjent dem.

Never spend your money before you have earned it.

Why: Personal pronouns. [[Danish#^da-Q0107|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Brug%20aldrig%20dine%20penge%2C%20f%C3%B8r%20du%20har%20tjent%20dem.)
^da-Q0107-answer

**da-Q0108** — Brug aldrig dine penge, før du har tjent dem.

Never spend your money before you have earned it.

Subject and object pronoun forms differ. Danish finite verbs generally do not change for person. Capital I means plural you and differs from lowercase i, in.

Why: Personal pronouns. [[Danish#^da-Q0108|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Brug%20aldrig%20dine%20penge%2C%20f%C3%B8r%20du%20har%20tjent%20dem.)
^da-Q0108-answer

**da-Q0109** — Det er aldrig sket for mig; bank under bordet.

That has never happened to me, touch wood.

Expected form: **mig**

Why: Personal pronouns. [[Danish#^da-Q0109|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Det%20er%20aldrig%20sket%20for%20mig%3B%20bank%20under%20bordet.)
^da-Q0109-answer

**da-Q0110** — Det er aldrig sket for mig; bank under bordet.

That has never happened to me, touch wood.

Expected form: **mig**

Why: Personal pronouns. [[Danish#^da-Q0110|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Det%20er%20aldrig%20sket%20for%20mig%3B%20bank%20under%20bordet.)
^da-Q0110-answer

**da-Q0111** — De begravede hende.

They buried her.

Expected form: **hende**

Why: Personal pronouns. [[Danish#^da-Q0111|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=De%20begravede%20hende.)
^da-Q0111-answer

**da-Q0112** — De begravede hende.

They buried her.

Why: Personal pronouns. [[Danish#^da-Q0112|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=De%20begravede%20hende.)
^da-Q0112-answer

**da-Q0113** — Jeg sagde godnat til ham.

I told him good night.

Why: Personal pronouns. [[Danish#^da-Q0113|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20sagde%20godnat%20til%20ham.)
^da-Q0113-answer

**da-Q0114** — Jeg sagde godnat til ham.

I told him good night.

Subject and object pronoun forms differ. Danish finite verbs generally do not change for person. Capital I means plural you and differs from lowercase i, in.

Why: Personal pronouns. [[Danish#^da-Q0114|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20sagde%20godnat%20til%20ham.)
^da-Q0114-answer

**da-Q0115** — Jeg ser dig på lørdag.

I'll see you Saturday.

Expected form: **dig**

Why: Personal pronouns. [[Danish#^da-Q0115|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20ser%20dig%20p%C3%A5%20l%C3%B8rdag.)
^da-Q0115-answer

**da-Q0116** — Jeg ser dig på lørdag.

I'll see you Saturday.

Expected form: **dig**

Why: Personal pronouns. [[Danish#^da-Q0116|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20ser%20dig%20p%C3%A5%20l%C3%B8rdag.)
^da-Q0116-answer

**da-Q0117** — Hvor mange katte har du?

How many cats do you have?

Expected form: **du**

Why: Personal pronouns. [[Danish#^da-Q0117|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hvor%20mange%20katte%20har%20du%3F)
^da-Q0117-answer

**da-Q0118** — Hvor mange katte har du?

How many cats do you have?

Why: Personal pronouns. [[Danish#^da-Q0118|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hvor%20mange%20katte%20har%20du%3F)
^da-Q0118-answer

**da-Q0119** — Doktor, jeg har kløe i skridtet.

Doctor, I've got an itch in my crotch.

Why: Personal pronouns. [[Danish#^da-Q0119|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Doktor%2C%20jeg%20har%20kl%C3%B8e%20i%20skridtet.)
^da-Q0119-answer

**da-Q0120** — Doktor, jeg har kløe i skridtet.

Doctor, I've got an itch in my crotch.

Subject and object pronoun forms differ. Danish finite verbs generally do not change for person. Capital I means plural you and differs from lowercase i, in.

Why: Personal pronouns. [[Danish#^da-Q0120|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Doktor%2C%20jeg%20har%20kl%C3%B8e%20i%20skridtet.)
^da-Q0120-answer

**da-Q0121** — Jeg har ikke set hende i evigheder.

I haven't seen her for ages.

Expected form: **hende**

Why: Personal pronouns. [[Danish#^da-Q0121|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20har%20ikke%20set%20hende%20i%20evigheder.)
^da-Q0121-answer

**da-Q0122** — Jeg har ikke set hende i evigheder.

I haven't seen her for ages.

Expected form: **hende**

Why: Personal pronouns. [[Danish#^da-Q0122|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20har%20ikke%20set%20hende%20i%20evigheder.)
^da-Q0122-answer

**da-Q0123** — Jeg så hvad du gjorde.

I saw what you did.

Expected form: **du**

Why: Personal pronouns. [[Danish#^da-Q0123|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20s%C3%A5%20hvad%20du%20gjorde.)
^da-Q0123-answer

**da-Q0124** — Jeg så hvad du gjorde.

I saw what you did.

Why: Personal pronouns. [[Danish#^da-Q0124|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20s%C3%A5%20hvad%20du%20gjorde.)
^da-Q0124-answer

**da-Q0125** — Er han læge?

Is he a doctor?

Why: Personal pronouns. [[Danish#^da-Q0125|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Er%20han%20l%C3%A6ge%3F)
^da-Q0125-answer

**da-Q0126** — Er han læge?

Is he a doctor?

Subject and object pronoun forms differ. Danish finite verbs generally do not change for person. Capital I means plural you and differs from lowercase i, in.

Why: Personal pronouns. [[Danish#^da-Q0126|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Er%20han%20l%C3%A6ge%3F)
^da-Q0126-answer

**da-Q0127** — Han kender hende.

He knows her.

Expected form: **hende**

Why: Personal pronouns. [[Danish#^da-Q0127|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Han%20kender%20hende.)
^da-Q0127-answer

**da-Q0128** — Han kender hende.

He knows her.

Expected form: **hende**

Why: Personal pronouns. [[Danish#^da-Q0128|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Han%20kender%20hende.)
^da-Q0128-answer

**da-Q0129** — I ser mig aldrig igen.

You'll never see me again.

Expected form: **I**

Why: Personal pronouns. [[Danish#^da-Q0129|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=I%20ser%20mig%20aldrig%20igen.)
^da-Q0129-answer

**da-Q0130** — I ser mig aldrig igen.

You'll never see me again.

Why: Personal pronouns. [[Danish#^da-Q0130|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=I%20ser%20mig%20aldrig%20igen.)
^da-Q0130-answer

**da-Q0131** — Jeg er bange for at jeg er løbet tør for kaffe.

I'm afraid I've run short of coffee.

Why: Personal pronouns. [[Danish#^da-Q0131|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20er%20bange%20for%20at%20jeg%20er%20l%C3%B8bet%20t%C3%B8r%20for%20kaffe.)
^da-Q0131-answer

**da-Q0132** — Jeg er bange for at jeg er løbet tør for kaffe.

I'm afraid I've run short of coffee.

Subject and object pronoun forms differ. Danish finite verbs generally do not change for person. Capital I means plural you and differs from lowercase i, in.

Why: Personal pronouns. [[Danish#^da-Q0132|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20er%20bange%20for%20at%20jeg%20er%20l%C3%B8bet%20t%C3%B8r%20for%20kaffe.)
^da-Q0132-answer

**da-Q0133** — Du gjorde mig forskrækket!

You startled me!

Expected form: **mig**

Why: Personal pronouns. [[Danish#^da-Q0133|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Du%20gjorde%20mig%20forskr%C3%A6kket%21)
^da-Q0133-answer

**da-Q0134** — Du gjorde mig forskrækket!

You startled me!

Expected form: **mig**

Why: Personal pronouns. [[Danish#^da-Q0134|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Du%20gjorde%20mig%20forskr%C3%A6kket%21)
^da-Q0134-answer

**da-Q0135** — Har du læst Toms bog?

Have you read Tom's book?

Expected form: **du**

Why: Personal pronouns. [[Danish#^da-Q0135|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Har%20du%20l%C3%A6st%20Toms%20bog%3F)
^da-Q0135-answer

**da-Q0136** — Har du læst Toms bog?

Have you read Tom's book?

Why: Personal pronouns. [[Danish#^da-Q0136|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Har%20du%20l%C3%A6st%20Toms%20bog%3F)
^da-Q0136-answer

**da-Q0137** — Jeg slog ham i skak.

I beat him at chess.

Why: Personal pronouns. [[Danish#^da-Q0137|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20slog%20ham%20i%20skak.)
^da-Q0137-answer

**da-Q0138** — Jeg slog ham i skak.

I beat him at chess.

Subject and object pronoun forms differ. Danish finite verbs generally do not change for person. Capital I means plural you and differs from lowercase i, in.

Why: Personal pronouns. [[Danish#^da-Q0138|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20slog%20ham%20i%20skak.)
^da-Q0138-answer

**da-Q0139** — Hvor vover du at fornærme profeten Maria!

How dare you insult the prophetess Mary!

Expected form: **du**

Why: Personal pronouns. [[Danish#^da-Q0139|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hvor%20vover%20du%20at%20forn%C3%A6rme%20profeten%20Maria%21)
^da-Q0139-answer

**da-Q0140** — Hvor vover du at fornærme profeten Maria!

How dare you insult the prophetess Mary!

Expected form: **du**

Why: Personal pronouns. [[Danish#^da-Q0140|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hvor%20vover%20du%20at%20forn%C3%A6rme%20profeten%20Maria%21)
^da-Q0140-answer

**da-Q0141** — Tom siger at han aldrig har prøvet at spise hundemad.

Tom says that he's never tried eating dog food.

Expected form: **han**

Why: Personal pronouns. [[Danish#^da-Q0141|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20siger%20at%20han%20aldrig%20har%20pr%C3%B8vet%20at%20spise%20hundemad.)
^da-Q0141-answer

**da-Q0142** — Tom siger at han aldrig har prøvet at spise hundemad.

Tom says that he's never tried eating dog food.

Why: Personal pronouns. [[Danish#^da-Q0142|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20siger%20at%20han%20aldrig%20har%20pr%C3%B8vet%20at%20spise%20hundemad.)
^da-Q0142-answer

**da-Q0143** — Hun var forelsket i mig, men jeg var ikke forelsket i hende.

She was in love with me, but I wasn't in love with her.

Why: Personal pronouns. [[Danish#^da-Q0143|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hun%20var%20forelsket%20i%20mig%2C%20men%20jeg%20var%20ikke%20forelsket%20i%20hende.)
^da-Q0143-answer

**da-Q0144** — Hun var forelsket i mig, men jeg var ikke forelsket i hende.

She was in love with me, but I wasn't in love with her.

Subject and object pronoun forms differ. Danish finite verbs generally do not change for person. Capital I means plural you and differs from lowercase i, in.

Why: Personal pronouns. [[Danish#^da-Q0144|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hun%20var%20forelsket%20i%20mig%2C%20men%20jeg%20var%20ikke%20forelsket%20i%20hende.)
^da-Q0144-answer

**da-Q0145** — Ingen ville hjælpe mig, ikke engang Tom.

Nobody would help me, not even Tom.

Expected form: **mig**

Why: Personal pronouns. [[Danish#^da-Q0145|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Ingen%20ville%20hj%C3%A6lpe%20mig%2C%20ikke%20engang%20Tom.)
^da-Q0145-answer

**da-Q0146** — Ingen ville hjælpe mig, ikke engang Tom.

Nobody would help me, not even Tom.

Expected form: **mig**

Why: Personal pronouns. [[Danish#^da-Q0146|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Ingen%20ville%20hj%C3%A6lpe%20mig%2C%20ikke%20engang%20Tom.)
^da-Q0146-answer

**da-Q0147** — Hvornår bliver jeg fri?

When shall I be free?

Expected form: **jeg**

Why: Personal pronouns. [[Danish#^da-Q0147|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hvorn%C3%A5r%20bliver%20jeg%20fri%3F)
^da-Q0147-answer

**da-Q0148** — Hvornår bliver jeg fri?

When shall I be free?

Why: Personal pronouns. [[Danish#^da-Q0148|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hvorn%C3%A5r%20bliver%20jeg%20fri%3F)
^da-Q0148-answer

**da-Q0149** — Hvis bare jeg havde lavet mine lektier!

If only I'd done my homework!

Why: Personal pronouns. [[Danish#^da-Q0149|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hvis%20bare%20jeg%20havde%20lavet%20mine%20lektier%21)
^da-Q0149-answer

**da-Q0150** — Hvis bare jeg havde lavet mine lektier!

If only I'd done my homework!

Subject and object pronoun forms differ. Danish finite verbs generally do not change for person. Capital I means plural you and differs from lowercase i, in.

Why: Personal pronouns. [[Danish#^da-Q0150|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hvis%20bare%20jeg%20havde%20lavet%20mine%20lektier%21)
^da-Q0150-answer


### Answers 151–200

**da-Q0151** — Mørke er fravær af lys.

Darkness is the absence of light.

Expected form: **er**

Why: Copula and past. [[Danish#^da-Q0151|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=M%C3%B8rke%20er%20frav%C3%A6r%20af%20lys.)
^da-Q0151-answer

**da-Q0152** — Mørke er fravær af lys.

Darkness is the absence of light.

Expected form: **er**

Why: Copula and past. [[Danish#^da-Q0152|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=M%C3%B8rke%20er%20frav%C3%A6r%20af%20lys.)
^da-Q0152-answer

**da-Q0153** — At fejle er menneskeligt, at tilgive er guddommeligt.

To err is human; to forgive, divine.

Expected form: **er**

Why: Copula and past. [[Danish#^da-Q0153|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=At%20fejle%20er%20menneskeligt%2C%20at%20tilgive%20er%20guddommeligt.)
^da-Q0153-answer

**da-Q0154** — At fejle er menneskeligt, at tilgive er guddommeligt.

To err is human; to forgive, divine.

Why: Copula and past. [[Danish#^da-Q0154|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=At%20fejle%20er%20menneskeligt%2C%20at%20tilgive%20er%20guddommeligt.)
^da-Q0154-answer

**da-Q0155** — Dette er deres hus.

This is their house.

Why: Copula and past. [[Danish#^da-Q0155|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Dette%20er%20deres%20hus.)
^da-Q0155-answer

**da-Q0156** — Dette er deres hus.

This is their house.

Er is a present form for all persons; var is past; været is the participle. Subject changes do not create English-style am/is/are variation.

Why: Copula and past. [[Danish#^da-Q0156|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Dette%20er%20deres%20hus.)
^da-Q0156-answer

**da-Q0157** — Dette hus er berømt.

This house is famous.

Expected form: **er**

Why: Copula and past. [[Danish#^da-Q0157|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Dette%20hus%20er%20ber%C3%B8mt.)
^da-Q0157-answer

**da-Q0158** — Dette hus er berømt.

This house is famous.

Expected form: **er**

Why: Copula and past. [[Danish#^da-Q0158|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Dette%20hus%20er%20ber%C3%B8mt.)
^da-Q0158-answer

**da-Q0159** — Der var to kager.

There were two cakes.

Expected form: **var**

Why: Copula and past. [[Danish#^da-Q0159|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Der%20var%20to%20kager.)
^da-Q0159-answer

**da-Q0160** — Der var to kager.

There were two cakes.

Why: Copula and past. [[Danish#^da-Q0160|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Der%20var%20to%20kager.)
^da-Q0160-answer

**da-Q0161** — Der er ikke nok kød.

There is not enough meat.

Why: Copula and past. [[Danish#^da-Q0161|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Der%20er%20ikke%20nok%20k%C3%B8d.)
^da-Q0161-answer

**da-Q0162** — Der er ikke nok kød.

There is not enough meat.

Er is a present form for all persons; var is past; været is the participle. Subject changes do not create English-style am/is/are variation.

Why: Copula and past. [[Danish#^da-Q0162|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Der%20er%20ikke%20nok%20k%C3%B8d.)
^da-Q0162-answer

**da-Q0163** — Tom er dobbelt så tung som Mary.

Tom is twice as heavy as Mary.

Expected form: **er**

Why: Copula and past. [[Danish#^da-Q0163|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20er%20dobbelt%20s%C3%A5%20tung%20som%20Mary.)
^da-Q0163-answer

**da-Q0164** — Tom er dobbelt så tung som Mary.

Tom is twice as heavy as Mary.

Expected form: **er**

Why: Copula and past. [[Danish#^da-Q0164|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20er%20dobbelt%20s%C3%A5%20tung%20som%20Mary.)
^da-Q0164-answer

**da-Q0165** — Hjemmesiden er nede.

The website is down.

Expected form: **er**

Why: Copula and past. [[Danish#^da-Q0165|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hjemmesiden%20er%20nede.)
^da-Q0165-answer

**da-Q0166** — Hjemmesiden er nede.

The website is down.

Why: Copula and past. [[Danish#^da-Q0166|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hjemmesiden%20er%20nede.)
^da-Q0166-answer

**da-Q0167** — Atlantis er virkelig.

Atlantis is real.

Why: Copula and past. [[Danish#^da-Q0167|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Atlantis%20er%20virkelig.)
^da-Q0167-answer

**da-Q0168** — Atlantis er virkelig.

Atlantis is real.

Er is a present form for all persons; var is past; været is the participle. Subject changes do not create English-style am/is/are variation.

Why: Copula and past. [[Danish#^da-Q0168|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Atlantis%20er%20virkelig.)
^da-Q0168-answer

**da-Q0169** — Døden er alle menneskers skæbne.

Death is the fate of all people.

Expected form: **er**

Why: Copula and past. [[Danish#^da-Q0169|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=D%C3%B8den%20er%20alle%20menneskers%20sk%C3%A6bne.)
^da-Q0169-answer

**da-Q0170** — Døden er alle menneskers skæbne.

Death is the fate of all people.

Expected form: **er**

Why: Copula and past. [[Danish#^da-Q0170|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=D%C3%B8den%20er%20alle%20menneskers%20sk%C3%A6bne.)
^da-Q0170-answer

**da-Q0171** — Det er bedre at vente på at politiet ankommer.

It's better to wait for the police to arrive.

Expected form: **er**

Why: Copula and past. [[Danish#^da-Q0171|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Det%20er%20bedre%20at%20vente%20p%C3%A5%20at%20politiet%20ankommer.)
^da-Q0171-answer

**da-Q0172** — Det er bedre at vente på at politiet ankommer.

It's better to wait for the police to arrive.

Why: Copula and past. [[Danish#^da-Q0172|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Det%20er%20bedre%20at%20vente%20p%C3%A5%20at%20politiet%20ankommer.)
^da-Q0172-answer

**da-Q0173** — Der er mange elever i gymnastiksalen.

There are a lot of students in the gym.

Why: Copula and past. [[Danish#^da-Q0173|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Der%20er%20mange%20elever%20i%20gymnastiksalen.)
^da-Q0173-answer

**da-Q0174** — Der er mange elever i gymnastiksalen.

There are a lot of students in the gym.

Er is a present form for all persons; var is past; været is the participle. Subject changes do not create English-style am/is/are variation.

Why: Copula and past. [[Danish#^da-Q0174|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Der%20er%20mange%20elever%20i%20gymnastiksalen.)
^da-Q0174-answer

**da-Q0175** — Intet er mere vigtigt end tid.

Nothing is more important than time.

Expected form: **er**

Why: Copula and past. [[Danish#^da-Q0175|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Intet%20er%20mere%20vigtigt%20end%20tid.)
^da-Q0175-answer

**da-Q0176** — Intet er mere vigtigt end tid.

Nothing is more important than time.

Expected form: **er**

Why: Copula and past. [[Danish#^da-Q0176|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Intet%20er%20mere%20vigtigt%20end%20tid.)
^da-Q0176-answer

**da-Q0177** — De fleste japanske templer er lavet af træ.

Most Japanese temples are made of wood.

Expected form: **er**

Why: Copula and past. [[Danish#^da-Q0177|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=De%20fleste%20japanske%20templer%20er%20lavet%20af%20tr%C3%A6.)
^da-Q0177-answer

**da-Q0178** — De fleste japanske templer er lavet af træ.

Most Japanese temples are made of wood.

Why: Copula and past. [[Danish#^da-Q0178|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=De%20fleste%20japanske%20templer%20er%20lavet%20af%20tr%C3%A6.)
^da-Q0178-answer

**da-Q0179** — Tom var ved at dø af tørst.

Tom was dying of thirst.

Why: Copula and past. [[Danish#^da-Q0179|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20var%20ved%20at%20d%C3%B8%20af%20t%C3%B8rst.)
^da-Q0179-answer

**da-Q0180** — Tom var ved at dø af tørst.

Tom was dying of thirst.

Er is a present form for all persons; var is past; været is the participle. Subject changes do not create English-style am/is/are variation.

Why: Copula and past. [[Danish#^da-Q0180|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20var%20ved%20at%20d%C3%B8%20af%20t%C3%B8rst.)
^da-Q0180-answer

**da-Q0181** — Hvor længe har du været ryger?

How long have you been a smoker?

Expected form: **været**

Why: Copula and past. [[Danish#^da-Q0181|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hvor%20l%C3%A6nge%20har%20du%20v%C3%A6ret%20ryger%3F)
^da-Q0181-answer

**da-Q0182** — Hvor længe har du været ryger?

How long have you been a smoker?

Expected form: **været**

Why: Copula and past. [[Danish#^da-Q0182|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hvor%20l%C3%A6nge%20har%20du%20v%C3%A6ret%20ryger%3F)
^da-Q0182-answer

**da-Q0183** — Verden udenfor er meget frygtindgydende.

The world outside is very scary.

Expected form: **er**

Why: Copula and past. [[Danish#^da-Q0183|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Verden%20udenfor%20er%20meget%20frygtindgydende.)
^da-Q0183-answer

**da-Q0184** — Verden udenfor er meget frygtindgydende.

The world outside is very scary.

Why: Copula and past. [[Danish#^da-Q0184|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Verden%20udenfor%20er%20meget%20frygtindgydende.)
^da-Q0184-answer

**da-Q0185** — Jeg er uafhængig journalist.

I'm a freelance journalist.

Why: Copula and past. [[Danish#^da-Q0185|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20er%20uafh%C3%A6ngig%20journalist.)
^da-Q0185-answer

**da-Q0186** — Jeg er uafhængig journalist.

I'm a freelance journalist.

Er is a present form for all persons; var is past; været is the participle. Subject changes do not create English-style am/is/are variation.

Why: Copula and past. [[Danish#^da-Q0186|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20er%20uafh%C3%A6ngig%20journalist.)
^da-Q0186-answer

**da-Q0187** — Hvad ville du gøre hvis jeg var dig utro?

What would you do if I were untrue to you?

Expected form: **var**

Why: Copula and past. [[Danish#^da-Q0187|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hvad%20ville%20du%20g%C3%B8re%20hvis%20jeg%20var%20dig%20utro%3F)
^da-Q0187-answer

**da-Q0188** — Hvad ville du gøre hvis jeg var dig utro?

What would you do if I were untrue to you?

Expected form: **var**

Why: Copula and past. [[Danish#^da-Q0188|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hvad%20ville%20du%20g%C3%B8re%20hvis%20jeg%20var%20dig%20utro%3F)
^da-Q0188-answer

**da-Q0189** — Tom er ikke jøde.

Tom isn't a Jew.

Expected form: **er**

Why: Copula and past. [[Danish#^da-Q0189|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20er%20ikke%20j%C3%B8de.)
^da-Q0189-answer

**da-Q0190** — Tom er ikke jøde.

Tom isn't a Jew.

Why: Copula and past. [[Danish#^da-Q0190|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20er%20ikke%20j%C3%B8de.)
^da-Q0190-answer

**da-Q0191** — Tom er min bedste ven.

Tom is my best friend.

Why: Copula and past. [[Danish#^da-Q0191|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20er%20min%20bedste%20ven.)
^da-Q0191-answer

**da-Q0192** — Tom er min bedste ven.

Tom is my best friend.

Er is a present form for all persons; var is past; været is the participle. Subject changes do not create English-style am/is/are variation.

Why: Copula and past. [[Danish#^da-Q0192|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20er%20min%20bedste%20ven.)
^da-Q0192-answer

**da-Q0193** — Tom er ikke Trump.

Tom is not Trump.

Expected form: **er**

Why: Copula and past. [[Danish#^da-Q0193|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20er%20ikke%20Trump.)
^da-Q0193-answer

**da-Q0194** — Tom er ikke Trump.

Tom is not Trump.

Expected form: **er**

Why: Copula and past. [[Danish#^da-Q0194|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20er%20ikke%20Trump.)
^da-Q0194-answer

**da-Q0195** — Han er syndebukken.

He's the scapegoat.

Expected form: **er**

Why: Copula and past. [[Danish#^da-Q0195|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Han%20er%20syndebukken.)
^da-Q0195-answer

**da-Q0196** — Han er syndebukken.

He's the scapegoat.

Why: Copula and past. [[Danish#^da-Q0196|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Han%20er%20syndebukken.)
^da-Q0196-answer

**da-Q0197** — Sami var youtuber.

Sami was a YouTuber.

Why: Copula and past. [[Danish#^da-Q0197|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Sami%20var%20youtuber.)
^da-Q0197-answer

**da-Q0198** — Sami var youtuber.

Sami was a YouTuber.

Er is a present form for all persons; var is past; været is the participle. Subject changes do not create English-style am/is/are variation.

Why: Copula and past. [[Danish#^da-Q0198|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Sami%20var%20youtuber.)
^da-Q0198-answer

**da-Q0199** — Lagnerne var gennemblødt af sved.

The sheets were soaked with sweat.

Expected form: **var**

Why: Copula and past. [[Danish#^da-Q0199|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Lagnerne%20var%20gennembl%C3%B8dt%20af%20sved.)
^da-Q0199-answer

**da-Q0200** — Lagnerne var gennemblødt af sved.

The sheets were soaked with sweat.

Expected form: **var**

Why: Copula and past. [[Danish#^da-Q0200|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Lagnerne%20var%20gennembl%C3%B8dt%20af%20sved.)
^da-Q0200-answer


### Answers 201–250

**da-Q0201** — Hun har blondt hår.

She has blonde hair.

Expected form: **har**

Why: Have forms. [[Danish#^da-Q0201|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hun%20har%20blondt%20h%C3%A5r.)
^da-Q0201-answer

**da-Q0202** — Hun har blondt hår.

She has blonde hair.

Why: Have forms. [[Danish#^da-Q0202|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hun%20har%20blondt%20h%C3%A5r.)
^da-Q0202-answer

**da-Q0203** — Alle havde meget travlt.

Everybody was very busy.

Why: Have forms. [[Danish#^da-Q0203|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Alle%20havde%20meget%20travlt.)
^da-Q0203-answer

**da-Q0204** — Alle havde meget travlt.

Everybody was very busy.

Har expresses present possession or serves as an auxiliary; havde is past and haft a participle. Learn a perfect together with its auxiliary and intended meaning.

Why: Have forms. [[Danish#^da-Q0204|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Alle%20havde%20meget%20travlt.)
^da-Q0204-answer

**da-Q0205** — Kunden har ikke altid ret.

The customer isn't always right.

Expected form: **har**

Why: Have forms. [[Danish#^da-Q0205|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Kunden%20har%20ikke%20altid%20ret.)
^da-Q0205-answer

**da-Q0206** — Kunden har ikke altid ret.

The customer isn't always right.

Expected form: **har**

Why: Have forms. [[Danish#^da-Q0206|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Kunden%20har%20ikke%20altid%20ret.)
^da-Q0206-answer

**da-Q0207** — Ekstremister har bortført præsidentens hustru.

Extremists kidnapped the president's wife.

Expected form: **har**

Why: Have forms. [[Danish#^da-Q0207|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Ekstremister%20har%20bortf%C3%B8rt%20pr%C3%A6sidentens%20hustru.)
^da-Q0207-answer

**da-Q0208** — Ekstremister har bortført præsidentens hustru.

Extremists kidnapped the president's wife.

Why: Have forms. [[Danish#^da-Q0208|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Ekstremister%20har%20bortf%C3%B8rt%20pr%C3%A6sidentens%20hustru.)
^da-Q0208-answer

**da-Q0209** — Jeg har ikke spist hele dagen.

I haven't eaten all day.

Why: Have forms. [[Danish#^da-Q0209|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20har%20ikke%20spist%20hele%20dagen.)
^da-Q0209-answer

**da-Q0210** — Jeg har ikke spist hele dagen.

I haven't eaten all day.

Har expresses present possession or serves as an auxiliary; havde is past and haft a participle. Learn a perfect together with its auxiliary and intended meaning.

Why: Have forms. [[Danish#^da-Q0210|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20har%20ikke%20spist%20hele%20dagen.)
^da-Q0210-answer

**da-Q0211** — Du har ikke feber.

You have no fever.

Expected form: **har**

Why: Have forms. [[Danish#^da-Q0211|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Du%20har%20ikke%20feber.)
^da-Q0211-answer

**da-Q0212** — Du har ikke feber.

You have no fever.

Expected form: **har**

Why: Have forms. [[Danish#^da-Q0212|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Du%20har%20ikke%20feber.)
^da-Q0212-answer

**da-Q0213** — Tro ikke jeg ikke har prøvet.

Don't think I didn't try.

Expected form: **har**

Why: Have forms. [[Danish#^da-Q0213|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tro%20ikke%20jeg%20ikke%20har%20pr%C3%B8vet.)
^da-Q0213-answer

**da-Q0214** — Tro ikke jeg ikke har prøvet.

Don't think I didn't try.

Why: Have forms. [[Danish#^da-Q0214|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tro%20ikke%20jeg%20ikke%20har%20pr%C3%B8vet.)
^da-Q0214-answer

**da-Q0215** — Han forklarede detaljeret, hvad han havde set.

He explained in detail what he had seen.

Why: Have forms. [[Danish#^da-Q0215|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Han%20forklarede%20detaljeret%2C%20hvad%20han%20havde%20set.)
^da-Q0215-answer

**da-Q0216** — Han forklarede detaljeret, hvad han havde set.

He explained in detail what he had seen.

Har expresses present possession or serves as an auxiliary; havde is past and haft a participle. Learn a perfect together with its auxiliary and intended meaning.

Why: Have forms. [[Danish#^da-Q0216|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Han%20forklarede%20detaljeret%2C%20hvad%20han%20havde%20set.)
^da-Q0216-answer

**da-Q0217** — Jeg har noget som jeg vil fortælle dig.

I have something I want to tell you.

Expected form: **har**

Why: Have forms. [[Danish#^da-Q0217|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20har%20noget%20som%20jeg%20vil%20fort%C3%A6lle%20dig.)
^da-Q0217-answer

**da-Q0218** — Jeg har noget som jeg vil fortælle dig.

I have something I want to tell you.

Expected form: **har**

Why: Have forms. [[Danish#^da-Q0218|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20har%20noget%20som%20jeg%20vil%20fort%C3%A6lle%20dig.)
^da-Q0218-answer

**da-Q0219** — Tom har en overraskelse til dig.

Tom has a surprise for you.

Expected form: **har**

Why: Have forms. [[Danish#^da-Q0219|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20har%20en%20overraskelse%20til%20dig.)
^da-Q0219-answer

**da-Q0220** — Tom har en overraskelse til dig.

Tom has a surprise for you.

Why: Have forms. [[Danish#^da-Q0220|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20har%20en%20overraskelse%20til%20dig.)
^da-Q0220-answer

**da-Q0221** — Gud har en plan for jer.

God has a plan for you.

Why: Have forms. [[Danish#^da-Q0221|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Gud%20har%20en%20plan%20for%20jer.)
^da-Q0221-answer

**da-Q0222** — Gud har en plan for jer.

God has a plan for you.

Har expresses present possession or serves as an auxiliary; havde is past and haft a participle. Learn a perfect together with its auxiliary and intended meaning.

Why: Have forms. [[Danish#^da-Q0222|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Gud%20har%20en%20plan%20for%20jer.)
^da-Q0222-answer

**da-Q0223** — Jeg har været over det hele.

I've been all over.

Expected form: **har**

Why: Have forms. [[Danish#^da-Q0223|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20har%20v%C3%A6ret%20over%20det%20hele.)
^da-Q0223-answer

**da-Q0224** — Jeg har været over det hele.

I've been all over.

Expected form: **har**

Why: Have forms. [[Danish#^da-Q0224|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20har%20v%C3%A6ret%20over%20det%20hele.)
^da-Q0224-answer

**da-Q0225** — Fordi min cykel havde et fladt dæk, missede jeg syvtoget.

My bicycle had a flat tire, so I missed the seven o'clock train.

Expected form: **havde**

Why: Have forms. [[Danish#^da-Q0225|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Fordi%20min%20cykel%20havde%20et%20fladt%20d%C3%A6k%2C%20missede%20jeg%20syvtoget.)
^da-Q0225-answer

**da-Q0226** — Fordi min cykel havde et fladt dæk, missede jeg syvtoget.

My bicycle had a flat tire, so I missed the seven o'clock train.

Why: Have forms. [[Danish#^da-Q0226|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Fordi%20min%20cykel%20havde%20et%20fladt%20d%C3%A6k%2C%20missede%20jeg%20syvtoget.)
^da-Q0226-answer

**da-Q0227** — Jeg har ikke læst nogen af hans to romaner.

I haven't read either of his novels.

Why: Have forms. [[Danish#^da-Q0227|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20har%20ikke%20l%C3%A6st%20nogen%20af%20hans%20to%20romaner.)
^da-Q0227-answer

**da-Q0228** — Jeg har ikke læst nogen af hans to romaner.

I haven't read either of his novels.

Har expresses present possession or serves as an auxiliary; havde is past and haft a participle. Learn a perfect together with its auxiliary and intended meaning.

Why: Have forms. [[Danish#^da-Q0228|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20har%20ikke%20l%C3%A6st%20nogen%20af%20hans%20to%20romaner.)
^da-Q0228-answer

**da-Q0229** — Hvor har du gemt julegaven?

Where have you hidden the Christmas present?

Expected form: **har**

Why: Have forms. [[Danish#^da-Q0229|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hvor%20har%20du%20gemt%20julegaven%3F)
^da-Q0229-answer

**da-Q0230** — Hvor har du gemt julegaven?

Where have you hidden the Christmas present?

Expected form: **har**

Why: Have forms. [[Danish#^da-Q0230|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hvor%20har%20du%20gemt%20julegaven%3F)
^da-Q0230-answer

**da-Q0231** — Jeg har hovedpine.

I have a headache.

Expected form: **har**

Why: Have forms. [[Danish#^da-Q0231|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20har%20hovedpine.)
^da-Q0231-answer

**da-Q0232** — Jeg har hovedpine.

I have a headache.

Why: Have forms. [[Danish#^da-Q0232|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20har%20hovedpine.)
^da-Q0232-answer

**da-Q0233** — Jeg har set ham før.

I've seen him before.

Why: Have forms. [[Danish#^da-Q0233|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20har%20set%20ham%20f%C3%B8r.)
^da-Q0233-answer

**da-Q0234** — Jeg har set ham før.

I've seen him before.

Har expresses present possession or serves as an auxiliary; havde is past and haft a participle. Learn a perfect together with its auxiliary and intended meaning.

Why: Have forms. [[Danish#^da-Q0234|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20har%20set%20ham%20f%C3%B8r.)
^da-Q0234-answer

**da-Q0235** — I slutningen af ​​oktober blev en græsk journalist, der i sit eget tidsskrift havde offentliggjort navnene på mere end to tusinde skatteunddragere, arresteret.

By the end of October a Greek journalist who had published the names of over two thousand tax evaders in his own magazine was arrested.

Expected form: **havde**

Why: Have forms. [[Danish#^da-Q0235|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=I%20slutningen%20af%20%E2%80%8B%E2%80%8Boktober%20blev%20en%20gr%C3%A6sk%20journalist%2C%20der%20i%20sit%20eget%20tidsskrift%20havde%20offentliggjort%20navnene%20p%C3%A5%20mere%20end%20to%20tusinde%20skatteunddragere%2C%20arresteret.)
^da-Q0235-answer

**da-Q0236** — I slutningen af ​​oktober blev en græsk journalist, der i sit eget tidsskrift havde offentliggjort navnene på mere end to tusinde skatteunddragere, arresteret.

By the end of October a Greek journalist who had published the names of over two thousand tax evaders in his own magazine was arrested.

Expected form: **havde**

Why: Have forms. [[Danish#^da-Q0236|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=I%20slutningen%20af%20%E2%80%8B%E2%80%8Boktober%20blev%20en%20gr%C3%A6sk%20journalist%2C%20der%20i%20sit%20eget%20tidsskrift%20havde%20offentliggjort%20navnene%20p%C3%A5%20mere%20end%20to%20tusinde%20skatteunddragere%2C%20arresteret.)
^da-Q0236-answer

**da-Q0237** — Jeg har advaret dem imod at komme her.

I warned them not to come here.

Expected form: **har**

Why: Have forms. [[Danish#^da-Q0237|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20har%20advaret%20dem%20imod%20at%20komme%20her.)
^da-Q0237-answer

**da-Q0238** — Jeg har advaret dem imod at komme her.

I warned them not to come here.

Why: Have forms. [[Danish#^da-Q0238|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20har%20advaret%20dem%20imod%20at%20komme%20her.)
^da-Q0238-answer

**da-Q0239** — Tom har bedt mig om at komme hjem til ham i morgen.

Tom has asked me to come to his house tomorrow.

Why: Have forms. [[Danish#^da-Q0239|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20har%20bedt%20mig%20om%20at%20komme%20hjem%20til%20ham%20i%20morgen.)
^da-Q0239-answer

**da-Q0240** — Tom har bedt mig om at komme hjem til ham i morgen.

Tom has asked me to come to his house tomorrow.

Har expresses present possession or serves as an auxiliary; havde is past and haft a participle. Learn a perfect together with its auxiliary and intended meaning.

Why: Have forms. [[Danish#^da-Q0240|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20har%20bedt%20mig%20om%20at%20komme%20hjem%20til%20ham%20i%20morgen.)
^da-Q0240-answer

**da-Q0241** — Jeg tror, nogen har spædet punchen op.

I think someone spiked the punch.

Expected form: **har**

Why: Have forms. [[Danish#^da-Q0241|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20tror%2C%20nogen%20har%20sp%C3%A6det%20punchen%20op.)
^da-Q0241-answer

**da-Q0242** — Jeg tror, nogen har spædet punchen op.

I think someone spiked the punch.

Expected form: **har**

Why: Have forms. [[Danish#^da-Q0242|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20tror%2C%20nogen%20har%20sp%C3%A6det%20punchen%20op.)
^da-Q0242-answer

**da-Q0243** — Hvorfor har du valgt at bo i Australien?

Why did you choose to live in Australia?

Expected form: **har**

Why: Have forms. [[Danish#^da-Q0243|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hvorfor%20har%20du%20valgt%20at%20bo%20i%20Australien%3F)
^da-Q0243-answer

**da-Q0244** — Hvorfor har du valgt at bo i Australien?

Why did you choose to live in Australia?

Why: Have forms. [[Danish#^da-Q0244|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hvorfor%20har%20du%20valgt%20at%20bo%20i%20Australien%3F)
^da-Q0244-answer

**da-Q0245** — Hvorfor har de største banker brug for den største redningspakke?

Why do the largest banks need the biggest bailout?

Why: Have forms. [[Danish#^da-Q0245|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hvorfor%20har%20de%20st%C3%B8rste%20banker%20brug%20for%20den%20st%C3%B8rste%20redningspakke%3F)
^da-Q0245-answer

**da-Q0246** — Hvorfor har de største banker brug for den største redningspakke?

Why do the largest banks need the biggest bailout?

Har expresses present possession or serves as an auxiliary; havde is past and haft a participle. Learn a perfect together with its auxiliary and intended meaning.

Why: Have forms. [[Danish#^da-Q0246|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hvorfor%20har%20de%20st%C3%B8rste%20banker%20brug%20for%20den%20st%C3%B8rste%20redningspakke%3F)
^da-Q0246-answer

**da-Q0247** — Vi har noget endnu bedre.

We have something even better.

Expected form: **har**

Why: Have forms. [[Danish#^da-Q0247|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Vi%20har%20noget%20endnu%20bedre.)
^da-Q0247-answer

**da-Q0248** — Vi har noget endnu bedre.

We have something even better.

Expected form: **har**

Why: Have forms. [[Danish#^da-Q0248|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Vi%20har%20noget%20endnu%20bedre.)
^da-Q0248-answer

**da-Q0249** — Han glemmer tit hvad han har lovet.

He will often forget his promise.

Expected form: **har**

Why: Have forms. [[Danish#^da-Q0249|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Han%20glemmer%20tit%20hvad%20han%20har%20lovet.)
^da-Q0249-answer

**da-Q0250** — Han glemmer tit hvad han har lovet.

He will often forget his promise.

Why: Have forms. [[Danish#^da-Q0250|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Han%20glemmer%20tit%20hvad%20han%20har%20lovet.)
^da-Q0250-answer


### Answers 251–300

**da-Q0251** — Tom kan endnu ikke køre bil.

Tom can't drive a car yet.

Why: Main-clause negation. [[Danish#^da-Q0251|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20kan%20endnu%20ikke%20k%C3%B8re%20bil.)
^da-Q0251-answer

**da-Q0252** — Tom kan endnu ikke køre bil.

Tom can't drive a car yet.

In many ordinary main statements the finite verb precedes ikke. In a subordinate clause, sentence adverbs often precede the finite verb. The connector and clause status determine the pattern.

Why: Main-clause negation. [[Danish#^da-Q0252|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20kan%20endnu%20ikke%20k%C3%B8re%20bil.)
^da-Q0252-answer

**da-Q0253** — Tom drak ikke noget.

Tom didn't drink anything.

Expected form: **ikke**

Why: Main-clause negation. [[Danish#^da-Q0253|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20drak%20ikke%20noget.)
^da-Q0253-answer

**da-Q0254** — Tom drak ikke noget.

Tom didn't drink anything.

Expected form: **ikke**

Why: Main-clause negation. [[Danish#^da-Q0254|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20drak%20ikke%20noget.)
^da-Q0254-answer

**da-Q0255** — Lyt ikke til dem.

Don't listen to them.

Expected form: **ikke**

Why: Main-clause negation. [[Danish#^da-Q0255|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Lyt%20ikke%20til%20dem.)
^da-Q0255-answer

**da-Q0256** — Lyt ikke til dem.

Don't listen to them.

Why: Main-clause negation. [[Danish#^da-Q0256|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Lyt%20ikke%20til%20dem.)
^da-Q0256-answer

**da-Q0257** — Vær ikke så hård ved dig selv!

Don't be so hard on yourself.

Why: Main-clause negation. [[Danish#^da-Q0257|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=V%C3%A6r%20ikke%20s%C3%A5%20h%C3%A5rd%20ved%20dig%20selv%21)
^da-Q0257-answer

**da-Q0258** — Vær ikke så hård ved dig selv!

Don't be so hard on yourself.

In many ordinary main statements the finite verb precedes ikke. In a subordinate clause, sentence adverbs often precede the finite verb. The connector and clause status determine the pattern.

Why: Main-clause negation. [[Danish#^da-Q0258|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=V%C3%A6r%20ikke%20s%C3%A5%20h%C3%A5rd%20ved%20dig%20selv%21)
^da-Q0258-answer

**da-Q0259** — Tom er ikke villig til at fortælle sandheden.

Tom isn't willing to tell the truth.

Expected form: **ikke**

Why: Main-clause negation. [[Danish#^da-Q0259|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20er%20ikke%20villig%20til%20at%20fort%C3%A6lle%20sandheden.)
^da-Q0259-answer

**da-Q0260** — Tom er ikke villig til at fortælle sandheden.

Tom isn't willing to tell the truth.

Expected form: **ikke**

Why: Main-clause negation. [[Danish#^da-Q0260|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20er%20ikke%20villig%20til%20at%20fort%C3%A6lle%20sandheden.)
^da-Q0260-answer

**da-Q0261** — Det er ikke lovstridigt.

It's not against the law.

Expected form: **ikke**

Why: Main-clause negation. [[Danish#^da-Q0261|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Det%20er%20ikke%20lovstridigt.)
^da-Q0261-answer

**da-Q0262** — Det er ikke lovstridigt.

It's not against the law.

Why: Main-clause negation. [[Danish#^da-Q0262|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Det%20er%20ikke%20lovstridigt.)
^da-Q0262-answer

**da-Q0263** — Jim kan ikke lide æbler, kan han vel?

Jim doesn't like apples, does he?

Why: Main-clause negation. [[Danish#^da-Q0263|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jim%20kan%20ikke%20lide%20%C3%A6bler%2C%20kan%20han%20vel%3F)
^da-Q0263-answer

**da-Q0264** — Jim kan ikke lide æbler, kan han vel?

Jim doesn't like apples, does he?

In many ordinary main statements the finite verb precedes ikke. In a subordinate clause, sentence adverbs often precede the finite verb. The connector and clause status determine the pattern.

Why: Main-clause negation. [[Danish#^da-Q0264|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jim%20kan%20ikke%20lide%20%C3%A6bler%2C%20kan%20han%20vel%3F)
^da-Q0264-answer

**da-Q0265** — Nu ved vi ikke hvad vi skal lave.

Now we don't know what to do.

Expected form: **ikke**

Why: Main-clause negation. [[Danish#^da-Q0265|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Nu%20ved%20vi%20ikke%20hvad%20vi%20skal%20lave.)
^da-Q0265-answer

**da-Q0266** — Nu ved vi ikke hvad vi skal lave.

Now we don't know what to do.

Expected form: **ikke**

Why: Main-clause negation. [[Danish#^da-Q0266|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Nu%20ved%20vi%20ikke%20hvad%20vi%20skal%20lave.)
^da-Q0266-answer

**da-Q0267** — Hun kom ikke.

She did not come.

Expected form: **ikke**

Why: Main-clause negation. [[Danish#^da-Q0267|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hun%20kom%20ikke.)
^da-Q0267-answer

**da-Q0268** — Hun kom ikke.

She did not come.

Why: Main-clause negation. [[Danish#^da-Q0268|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hun%20kom%20ikke.)
^da-Q0268-answer

**da-Q0269** — Aner det ikke.

No idea.

Why: Main-clause negation. [[Danish#^da-Q0269|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Aner%20det%20ikke.)
^da-Q0269-answer

**da-Q0270** — Aner det ikke.

No idea.

In many ordinary main statements the finite verb precedes ikke. In a subordinate clause, sentence adverbs often precede the finite verb. The connector and clause status determine the pattern.

Why: Main-clause negation. [[Danish#^da-Q0270|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Aner%20det%20ikke.)
^da-Q0270-answer

**da-Q0271** — Jeg forstår ikke selv hvordan det er sket.

I myself do not understand how it happened.

Expected form: **ikke**

Why: Main-clause negation. [[Danish#^da-Q0271|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20forst%C3%A5r%20ikke%20selv%20hvordan%20det%20er%20sket.)
^da-Q0271-answer

**da-Q0272** — Jeg forstår ikke selv hvordan det er sket.

I myself do not understand how it happened.

Expected form: **ikke**

Why: Main-clause negation. [[Danish#^da-Q0272|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20forst%C3%A5r%20ikke%20selv%20hvordan%20det%20er%20sket.)
^da-Q0272-answer

**da-Q0273** — Han ønskede at sige noget til hende, men han vidste ikke hvad han skulle sige.

He wanted to say something to her, but he didn't know what to say.

Expected form: **ikke**

Why: Main-clause negation. [[Danish#^da-Q0273|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Han%20%C3%B8nskede%20at%20sige%20noget%20til%20hende%2C%20men%20han%20vidste%20ikke%20hvad%20han%20skulle%20sige.)
^da-Q0273-answer

**da-Q0274** — Han ønskede at sige noget til hende, men han vidste ikke hvad han skulle sige.

He wanted to say something to her, but he didn't know what to say.

Why: Main-clause negation. [[Danish#^da-Q0274|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Han%20%C3%B8nskede%20at%20sige%20noget%20til%20hende%2C%20men%20han%20vidste%20ikke%20hvad%20han%20skulle%20sige.)
^da-Q0274-answer

**da-Q0275** — Jeg kan ikke forestille mig nogen alternativer.

I can't think of any alternatives.

Why: Main-clause negation. [[Danish#^da-Q0275|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20kan%20ikke%20forestille%20mig%20nogen%20alternativer.)
^da-Q0275-answer

**da-Q0276** — Jeg kan ikke forestille mig nogen alternativer.

I can't think of any alternatives.

In many ordinary main statements the finite verb precedes ikke. In a subordinate clause, sentence adverbs often precede the finite verb. The connector and clause status determine the pattern.

Why: Main-clause negation. [[Danish#^da-Q0276|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20kan%20ikke%20forestille%20mig%20nogen%20alternativer.)
^da-Q0276-answer

**da-Q0277** — Jeg kan ikke høre et ord.

I can't hear a word.

Expected form: **ikke**

Why: Main-clause negation. [[Danish#^da-Q0277|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20kan%20ikke%20h%C3%B8re%20et%20ord.)
^da-Q0277-answer

**da-Q0278** — Jeg kan ikke høre et ord.

I can't hear a word.

Expected form: **ikke**

Why: Main-clause negation. [[Danish#^da-Q0278|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20kan%20ikke%20h%C3%B8re%20et%20ord.)
^da-Q0278-answer

**da-Q0279** — Jeg er bange for at det ikke er så let.

I am afraid it's not so easy.

Expected form: **ikke**

Why: Main-clause negation. [[Danish#^da-Q0279|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20er%20bange%20for%20at%20det%20ikke%20er%20s%C3%A5%20let.)
^da-Q0279-answer

**da-Q0280** — Jeg er bange for at det ikke er så let.

I am afraid it's not so easy.

Why: Main-clause negation. [[Danish#^da-Q0280|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20er%20bange%20for%20at%20det%20ikke%20er%20s%C3%A5%20let.)
^da-Q0280-answer

**da-Q0281** — Hvorfor forsøger vi ikke at få et par timers søvn?

Why don't we try and get a few hours sleep?

Why: Main-clause negation. [[Danish#^da-Q0281|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hvorfor%20fors%C3%B8ger%20vi%20ikke%20at%20f%C3%A5%20et%20par%20timers%20s%C3%B8vn%3F)
^da-Q0281-answer

**da-Q0282** — Hvorfor forsøger vi ikke at få et par timers søvn?

Why don't we try and get a few hours sleep?

In many ordinary main statements the finite verb precedes ikke. In a subordinate clause, sentence adverbs often precede the finite verb. The connector and clause status determine the pattern.

Why: Main-clause negation. [[Danish#^da-Q0282|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hvorfor%20fors%C3%B8ger%20vi%20ikke%20at%20f%C3%A5%20et%20par%20timers%20s%C3%B8vn%3F)
^da-Q0282-answer

**da-Q0283** — Tom drak ikke mælken.

Tom didn't drink the milk.

Expected form: **ikke**

Why: Main-clause negation. [[Danish#^da-Q0283|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20drak%20ikke%20m%C3%A6lken.)
^da-Q0283-answer

**da-Q0284** — Tom drak ikke mælken.

Tom didn't drink the milk.

Expected form: **ikke**

Why: Main-clause negation. [[Danish#^da-Q0284|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20drak%20ikke%20m%C3%A6lken.)
^da-Q0284-answer

**da-Q0285** — Vi kan endnu ikke oversætte fra esperanto til dansk.

We can't yet translate from Esperanto to Danish.

Expected form: **ikke**

Why: Main-clause negation. [[Danish#^da-Q0285|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Vi%20kan%20endnu%20ikke%20overs%C3%A6tte%20fra%20esperanto%20til%20dansk.)
^da-Q0285-answer

**da-Q0286** — Vi kan endnu ikke oversætte fra esperanto til dansk.

We can't yet translate from Esperanto to Danish.

Why: Main-clause negation. [[Danish#^da-Q0286|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Vi%20kan%20endnu%20ikke%20overs%C3%A6tte%20fra%20esperanto%20til%20dansk.)
^da-Q0286-answer

**da-Q0287** — USA er blevet kaldt »verdens politimand«, men nogle amerikanske intellektuelle tøver ikke med at kalde deres eget land en »slyngelstat«.

The United States have been dubbed the "world policeman", but some American intellectuals do not hesitate to call their own country "rogue state."

Why: Main-clause negation. [[Danish#^da-Q0287|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=USA%20er%20blevet%20kaldt%20%C2%BBverdens%20politimand%C2%AB%2C%20men%20nogle%20amerikanske%20intellektuelle%20t%C3%B8ver%20ikke%20med%20at%20kalde%20deres%20eget%20land%20en%20%C2%BBslyngelstat%C2%AB.)
^da-Q0287-answer

**da-Q0288** — USA er blevet kaldt »verdens politimand«, men nogle amerikanske intellektuelle tøver ikke med at kalde deres eget land en »slyngelstat«.

The United States have been dubbed the "world policeman", but some American intellectuals do not hesitate to call their own country "rogue state."

In many ordinary main statements the finite verb precedes ikke. In a subordinate clause, sentence adverbs often precede the finite verb. The connector and clause status determine the pattern.

Why: Main-clause negation. [[Danish#^da-Q0288|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=USA%20er%20blevet%20kaldt%20%C2%BBverdens%20politimand%C2%AB%2C%20men%20nogle%20amerikanske%20intellektuelle%20t%C3%B8ver%20ikke%20med%20at%20kalde%20deres%20eget%20land%20en%20%C2%BBslyngelstat%C2%AB.)
^da-Q0288-answer

**da-Q0289** — Jeg skrev hans navn ned for at jeg ikke skulle glemme det.

I wrote down his name so I wouldn't forget it.

Expected form: **ikke**

Why: Main-clause negation. [[Danish#^da-Q0289|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20skrev%20hans%20navn%20ned%20for%20at%20jeg%20ikke%20skulle%20glemme%20det.)
^da-Q0289-answer

**da-Q0290** — Jeg skrev hans navn ned for at jeg ikke skulle glemme det.

I wrote down his name so I wouldn't forget it.

Expected form: **ikke**

Why: Main-clause negation. [[Danish#^da-Q0290|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20skrev%20hans%20navn%20ned%20for%20at%20jeg%20ikke%20skulle%20glemme%20det.)
^da-Q0290-answer

**da-Q0291** — Du stemte ikke, gjorde du vel?

You didn't vote, did you?

Expected form: **ikke**

Why: Main-clause negation. [[Danish#^da-Q0291|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Du%20stemte%20ikke%2C%20gjorde%20du%20vel%3F)
^da-Q0291-answer

**da-Q0292** — Du stemte ikke, gjorde du vel?

You didn't vote, did you?

Why: Main-clause negation. [[Danish#^da-Q0292|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Du%20stemte%20ikke%2C%20gjorde%20du%20vel%3F)
^da-Q0292-answer

**da-Q0293** — Tom og jeg er ikke så dumme.

Tom and I aren't that stupid.

Why: Main-clause negation. [[Danish#^da-Q0293|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20og%20jeg%20er%20ikke%20s%C3%A5%20dumme.)
^da-Q0293-answer

**da-Q0294** — Tom og jeg er ikke så dumme.

Tom and I aren't that stupid.

In many ordinary main statements the finite verb precedes ikke. In a subordinate clause, sentence adverbs often precede the finite verb. The connector and clause status determine the pattern.

Why: Main-clause negation. [[Danish#^da-Q0294|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20og%20jeg%20er%20ikke%20s%C3%A5%20dumme.)
^da-Q0294-answer

**da-Q0295** — Dit navn er Tom, ikke sandt?

Your name is Tom, right?

Expected form: **ikke**

Why: Main-clause negation. [[Danish#^da-Q0295|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Dit%20navn%20er%20Tom%2C%20ikke%20sandt%3F)
^da-Q0295-answer

**da-Q0296** — Dit navn er Tom, ikke sandt?

Your name is Tom, right?

Expected form: **ikke**

Why: Main-clause negation. [[Danish#^da-Q0296|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Dit%20navn%20er%20Tom%2C%20ikke%20sandt%3F)
^da-Q0296-answer

**da-Q0297** — Tom opfører sig som om han ikke ønsker at blive set sammen med os.

Tom acts like he doesn't want to be seen with us.

Expected form: **ikke**

Why: Main-clause negation. [[Danish#^da-Q0297|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20opf%C3%B8rer%20sig%20som%20om%20han%20ikke%20%C3%B8nsker%20at%20blive%20set%20sammen%20med%20os.)
^da-Q0297-answer

**da-Q0298** — Tom opfører sig som om han ikke ønsker at blive set sammen med os.

Tom acts like he doesn't want to be seen with us.

Why: Main-clause negation. [[Danish#^da-Q0298|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20opf%C3%B8rer%20sig%20som%20om%20han%20ikke%20%C3%B8nsker%20at%20blive%20set%20sammen%20med%20os.)
^da-Q0298-answer

**da-Q0299** — Jeg ønsker ikke at han tager afsted.

I don't want him to leave.

Why: Main-clause negation. [[Danish#^da-Q0299|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20%C3%B8nsker%20ikke%20at%20han%20tager%20afsted.)
^da-Q0299-answer

**da-Q0300** — Jeg ønsker ikke at han tager afsted.

I don't want him to leave.

In many ordinary main statements the finite verb precedes ikke. In a subordinate clause, sentence adverbs often precede the finite verb. The connector and clause status determine the pattern.

Why: Main-clause negation. [[Danish#^da-Q0300|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20%C3%B8nsker%20ikke%20at%20han%20tager%20afsted.)
^da-Q0300-answer


### Answers 301–350

**da-Q0301** — Hun nægtede at skrive under på andragendet.

She refused to sign the petition.

Expected form: **at**

Why: Subordinate connectors. [[Danish#^da-Q0301|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hun%20n%C3%A6gtede%20at%20skrive%20under%20p%C3%A5%20andragendet.)
^da-Q0301-answer

**da-Q0302** — Hun nægtede at skrive under på andragendet.

She refused to sign the petition.

Expected form: **at**

Why: Subordinate connectors. [[Danish#^da-Q0302|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hun%20n%C3%A6gtede%20at%20skrive%20under%20p%C3%A5%20andragendet.)
^da-Q0302-answer

**da-Q0303** — Sami forsøgte at sælge sin bil.

Sami tried to sell his car.

Expected form: **at**

Why: Subordinate connectors. [[Danish#^da-Q0303|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Sami%20fors%C3%B8gte%20at%20s%C3%A6lge%20sin%20bil.)
^da-Q0303-answer

**da-Q0304** — Sami forsøgte at sælge sin bil.

Sami tried to sell his car.

Why: Subordinate connectors. [[Danish#^da-Q0304|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Sami%20fors%C3%B8gte%20at%20s%C3%A6lge%20sin%20bil.)
^da-Q0304-answer

**da-Q0305** — Jeg antog at hun var din kæreste.

I assumed she was your girlfriend.

Why: Subordinate connectors. [[Danish#^da-Q0305|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20antog%20at%20hun%20var%20din%20k%C3%A6reste.)
^da-Q0305-answer

**da-Q0306** — Jeg antog at hun var din kæreste.

I assumed she was your girlfriend.

These connectors commonly introduce subordinate structures. Compare Jeg kommer ikke with fordi jeg ikke kommer. Main-clause verb-second order counts constituents, not words.

Why: Subordinate connectors. [[Danish#^da-Q0306|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20antog%20at%20hun%20var%20din%20k%C3%A6reste.)
^da-Q0306-answer

**da-Q0307** — Det er vanskeligt for mig at udtale ordet.

It is difficult for me to pronounce the word.

Expected form: **at**

Why: Subordinate connectors. [[Danish#^da-Q0307|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Det%20er%20vanskeligt%20for%20mig%20at%20udtale%20ordet.)
^da-Q0307-answer

**da-Q0308** — Det er vanskeligt for mig at udtale ordet.

It is difficult for me to pronounce the word.

Expected form: **at**

Why: Subordinate connectors. [[Danish#^da-Q0308|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Det%20er%20vanskeligt%20for%20mig%20at%20udtale%20ordet.)
^da-Q0308-answer

**da-Q0309** — Tom sagde at han ville dræbe Mary.

Tom said he was going to kill Mary.

Expected form: **at**

Why: Subordinate connectors. [[Danish#^da-Q0309|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20sagde%20at%20han%20ville%20dr%C3%A6be%20Mary.)
^da-Q0309-answer

**da-Q0310** — Tom sagde at han ville dræbe Mary.

Tom said he was going to kill Mary.

Why: Subordinate connectors. [[Danish#^da-Q0310|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20sagde%20at%20han%20ville%20dr%C3%A6be%20Mary.)
^da-Q0310-answer

**da-Q0311** — Hun ønskede at hjælpe sine venner.

She wanted to help her friends.

Why: Subordinate connectors. [[Danish#^da-Q0311|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hun%20%C3%B8nskede%20at%20hj%C3%A6lpe%20sine%20venner.)
^da-Q0311-answer

**da-Q0312** — Hun ønskede at hjælpe sine venner.

She wanted to help her friends.

These connectors commonly introduce subordinate structures. Compare Jeg kommer ikke with fordi jeg ikke kommer. Main-clause verb-second order counts constituents, not words.

Why: Subordinate connectors. [[Danish#^da-Q0312|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hun%20%C3%B8nskede%20at%20hj%C3%A6lpe%20sine%20venner.)
^da-Q0312-answer

**da-Q0313** — Selv guder dør når ingen længere tror på dem.

Even gods die when no one believes in them any longer.

Expected form: **når**

Why: Subordinate connectors. [[Danish#^da-Q0313|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Selv%20guder%20d%C3%B8r%20n%C3%A5r%20ingen%20l%C3%A6ngere%20tror%20p%C3%A5%20dem.)
^da-Q0313-answer

**da-Q0314** — Selv guder dør når ingen længere tror på dem.

Even gods die when no one believes in them any longer.

Expected form: **når**

Why: Subordinate connectors. [[Danish#^da-Q0314|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Selv%20guder%20d%C3%B8r%20n%C3%A5r%20ingen%20l%C3%A6ngere%20tror%20p%C3%A5%20dem.)
^da-Q0314-answer

**da-Q0315** — Marys kat behøver kun at hvæse én gang for at jage naboernes hunde på flugt.

Mary's cat needs to hiss only once, to scare away the neighbours' dogs.

Expected form: **at**

Why: Subordinate connectors. [[Danish#^da-Q0315|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Marys%20kat%20beh%C3%B8ver%20kun%20at%20hv%C3%A6se%20%C3%A9n%20gang%20for%20at%20jage%20naboernes%20hunde%20p%C3%A5%20flugt.)
^da-Q0315-answer

**da-Q0316** — Marys kat behøver kun at hvæse én gang for at jage naboernes hunde på flugt.

Mary's cat needs to hiss only once, to scare away the neighbours' dogs.

Why: Subordinate connectors. [[Danish#^da-Q0316|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Marys%20kat%20beh%C3%B8ver%20kun%20at%20hv%C3%A6se%20%C3%A9n%20gang%20for%20at%20jage%20naboernes%20hunde%20p%C3%A5%20flugt.)
^da-Q0316-answer

**da-Q0317** — Det er bedst at bruge et økologisk opvaskemiddel når man vasker op.

It is best to wash the dishes with environmentally friendly dishwashing liquid.

Why: Subordinate connectors. [[Danish#^da-Q0317|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Det%20er%20bedst%20at%20bruge%20et%20%C3%B8kologisk%20opvaskemiddel%20n%C3%A5r%20man%20vasker%20op.)
^da-Q0317-answer

**da-Q0318** — Det er bedst at bruge et økologisk opvaskemiddel når man vasker op.

It is best to wash the dishes with environmentally friendly dishwashing liquid.

These connectors commonly introduce subordinate structures. Compare Jeg kommer ikke with fordi jeg ikke kommer. Main-clause verb-second order counts constituents, not words.

Why: Subordinate connectors. [[Danish#^da-Q0318|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Det%20er%20bedst%20at%20bruge%20et%20%C3%B8kologisk%20opvaskemiddel%20n%C3%A5r%20man%20vasker%20op.)
^da-Q0318-answer

**da-Q0319** — Jeg tror at du hellere må holde lav profil indtil hun tilgiver dig.

I think you'd better lie low until she forgives you.

Expected form: **at**

Why: Subordinate connectors. [[Danish#^da-Q0319|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20tror%20at%20du%20hellere%20m%C3%A5%20holde%20lav%20profil%20indtil%20hun%20tilgiver%20dig.)
^da-Q0319-answer

**da-Q0320** — Jeg tror at du hellere må holde lav profil indtil hun tilgiver dig.

I think you'd better lie low until she forgives you.

Expected form: **at**

Why: Subordinate connectors. [[Danish#^da-Q0320|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20tror%20at%20du%20hellere%20m%C3%A5%20holde%20lav%20profil%20indtil%20hun%20tilgiver%20dig.)
^da-Q0320-answer

**da-Q0321** — Hvad vil du være når du bliver stor?

What will you do when you grow up?

Expected form: **når**

Why: Subordinate connectors. [[Danish#^da-Q0321|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hvad%20vil%20du%20v%C3%A6re%20n%C3%A5r%20du%20bliver%20stor%3F)
^da-Q0321-answer

**da-Q0322** — Hvad vil du være når du bliver stor?

What will you do when you grow up?

Why: Subordinate connectors. [[Danish#^da-Q0322|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hvad%20vil%20du%20v%C3%A6re%20n%C3%A5r%20du%20bliver%20stor%3F)
^da-Q0322-answer

**da-Q0323** — Jeg kan se at du er i godt humør.

I can see you're in a good mood.

Why: Subordinate connectors. [[Danish#^da-Q0323|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20kan%20se%20at%20du%20er%20i%20godt%20hum%C3%B8r.)
^da-Q0323-answer

**da-Q0324** — Jeg kan se at du er i godt humør.

I can see you're in a good mood.

These connectors commonly introduce subordinate structures. Compare Jeg kommer ikke with fordi jeg ikke kommer. Main-clause verb-second order counts constituents, not words.

Why: Subordinate connectors. [[Danish#^da-Q0324|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20kan%20se%20at%20du%20er%20i%20godt%20hum%C3%B8r.)
^da-Q0324-answer

**da-Q0325** — De er nødt til at tage konsekvenserne af deres handlinger.

They need to face the consequences.

Expected form: **at**

Why: Subordinate connectors. [[Danish#^da-Q0325|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=De%20er%20n%C3%B8dt%20til%20at%20tage%20konsekvenserne%20af%20deres%20handlinger.)
^da-Q0325-answer

**da-Q0326** — De er nødt til at tage konsekvenserne af deres handlinger.

They need to face the consequences.

Expected form: **at**

Why: Subordinate connectors. [[Danish#^da-Q0326|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=De%20er%20n%C3%B8dt%20til%20at%20tage%20konsekvenserne%20af%20deres%20handlinger.)
^da-Q0326-answer

**da-Q0327** — Han gør aldrig noget uden at hun får færten af det.

He never does anything but she smells it out.

Expected form: **at**

Why: Subordinate connectors. [[Danish#^da-Q0327|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Han%20g%C3%B8r%20aldrig%20noget%20uden%20at%20hun%20f%C3%A5r%20f%C3%A6rten%20af%20det.)
^da-Q0327-answer

**da-Q0328** — Han gør aldrig noget uden at hun får færten af det.

He never does anything but she smells it out.

Why: Subordinate connectors. [[Danish#^da-Q0328|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Han%20g%C3%B8r%20aldrig%20noget%20uden%20at%20hun%20f%C3%A5r%20f%C3%A6rten%20af%20det.)
^da-Q0328-answer

**da-Q0329** — Vil du være så venlig at hjælpe mig med at oversætte dette?

Would you please help me translate this?

Why: Subordinate connectors. [[Danish#^da-Q0329|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Vil%20du%20v%C3%A6re%20s%C3%A5%20venlig%20at%20hj%C3%A6lpe%20mig%20med%20at%20overs%C3%A6tte%20dette%3F)
^da-Q0329-answer

**da-Q0330** — Vil du være så venlig at hjælpe mig med at oversætte dette?

Would you please help me translate this?

These connectors commonly introduce subordinate structures. Compare Jeg kommer ikke with fordi jeg ikke kommer. Main-clause verb-second order counts constituents, not words.

Why: Subordinate connectors. [[Danish#^da-Q0330|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Vil%20du%20v%C3%A6re%20s%C3%A5%20venlig%20at%20hj%C3%A6lpe%20mig%20med%20at%20overs%C3%A6tte%20dette%3F)
^da-Q0330-answer

**da-Q0331** — Tom venter på at se, hvad der vil ske.

Tom is waiting to see what will happen.

Expected form: **at**

Why: Subordinate connectors. [[Danish#^da-Q0331|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20venter%20p%C3%A5%20at%20se%2C%20hvad%20der%20vil%20ske.)
^da-Q0331-answer

**da-Q0332** — Tom venter på at se, hvad der vil ske.

Tom is waiting to see what will happen.

Expected form: **at**

Why: Subordinate connectors. [[Danish#^da-Q0332|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20venter%20p%C3%A5%20at%20se%2C%20hvad%20der%20vil%20ske.)
^da-Q0332-answer

**da-Q0333** — Er det en forbrydelse at brænde det amerikanske flag af i USA?

Is it a crime to burn the American flag in the United States?

Expected form: **at**

Why: Subordinate connectors. [[Danish#^da-Q0333|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Er%20det%20en%20forbrydelse%20at%20br%C3%A6nde%20det%20amerikanske%20flag%20af%20i%20USA%3F)
^da-Q0333-answer

**da-Q0334** — Er det en forbrydelse at brænde det amerikanske flag af i USA?

Is it a crime to burn the American flag in the United States?

Why: Subordinate connectors. [[Danish#^da-Q0334|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Er%20det%20en%20forbrydelse%20at%20br%C3%A6nde%20det%20amerikanske%20flag%20af%20i%20USA%3F)
^da-Q0334-answer

**da-Q0335** — Du skal vide at jeg er forelsket i Mary.

You should know, I am in love with Mary.

Why: Subordinate connectors. [[Danish#^da-Q0335|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Du%20skal%20vide%20at%20jeg%20er%20forelsket%20i%20Mary.)
^da-Q0335-answer

**da-Q0336** — Du skal vide at jeg er forelsket i Mary.

You should know, I am in love with Mary.

These connectors commonly introduce subordinate structures. Compare Jeg kommer ikke with fordi jeg ikke kommer. Main-clause verb-second order counts constituents, not words.

Why: Subordinate connectors. [[Danish#^da-Q0336|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Du%20skal%20vide%20at%20jeg%20er%20forelsket%20i%20Mary.)
^da-Q0336-answer

**da-Q0337** — Hvordan træner du en kat til at bruge en kattebakke?

How do you train a cat to use a litter box?

Expected form: **at**

Why: Subordinate connectors. [[Danish#^da-Q0337|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hvordan%20tr%C3%A6ner%20du%20en%20kat%20til%20at%20bruge%20en%20kattebakke%3F)
^da-Q0337-answer

**da-Q0338** — Hvordan træner du en kat til at bruge en kattebakke?

How do you train a cat to use a litter box?

Expected form: **at**

Why: Subordinate connectors. [[Danish#^da-Q0338|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hvordan%20tr%C3%A6ner%20du%20en%20kat%20til%20at%20bruge%20en%20kattebakke%3F)
^da-Q0338-answer

**da-Q0339** — Den eneste fisk Tom kan lide at spise, er laks.

The only fish Tom likes to eat is salmon.

Expected form: **at**

Why: Subordinate connectors. [[Danish#^da-Q0339|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Den%20eneste%20fisk%20Tom%20kan%20lide%20at%20spise%2C%20er%20laks.)
^da-Q0339-answer

**da-Q0340** — Den eneste fisk Tom kan lide at spise, er laks.

The only fish Tom likes to eat is salmon.

Why: Subordinate connectors. [[Danish#^da-Q0340|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Den%20eneste%20fisk%20Tom%20kan%20lide%20at%20spise%2C%20er%20laks.)
^da-Q0340-answer

**da-Q0341** — Af de tre kandidater mener jeg at hr. Smith er den bedste.

Of the three candidates, I think Mr Smith is the best.

Why: Subordinate connectors. [[Danish#^da-Q0341|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Af%20de%20tre%20kandidater%20mener%20jeg%20at%20hr.%20Smith%20er%20den%20bedste.)
^da-Q0341-answer

**da-Q0342** — Af de tre kandidater mener jeg at hr. Smith er den bedste.

Of the three candidates, I think Mr Smith is the best.

These connectors commonly introduce subordinate structures. Compare Jeg kommer ikke with fordi jeg ikke kommer. Main-clause verb-second order counts constituents, not words.

Why: Subordinate connectors. [[Danish#^da-Q0342|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Af%20de%20tre%20kandidater%20mener%20jeg%20at%20hr.%20Smith%20er%20den%20bedste.)
^da-Q0342-answer

**da-Q0343** — Jeg tror at vi vinder.

I think we'll win.

Expected form: **at**

Why: Subordinate connectors. [[Danish#^da-Q0343|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20tror%20at%20vi%20vinder.)
^da-Q0343-answer

**da-Q0344** — Jeg tror at vi vinder.

I think we'll win.

Expected form: **at**

Why: Subordinate connectors. [[Danish#^da-Q0344|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20tror%20at%20vi%20vinder.)
^da-Q0344-answer

**da-Q0345** — Hold op med at drille Tom.

Stop teasing Tom.

Expected form: **at**

Why: Subordinate connectors. [[Danish#^da-Q0345|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hold%20op%20med%20at%20drille%20Tom.)
^da-Q0345-answer

**da-Q0346** — Hold op med at drille Tom.

Stop teasing Tom.

Why: Subordinate connectors. [[Danish#^da-Q0346|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hold%20op%20med%20at%20drille%20Tom.)
^da-Q0346-answer

**da-Q0347** — Hvordan lærte du at spille på violin?

How did you learn how to play the violin?

Why: Subordinate connectors. [[Danish#^da-Q0347|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hvordan%20l%C3%A6rte%20du%20at%20spille%20p%C3%A5%20violin%3F)
^da-Q0347-answer

**da-Q0348** — Hvordan lærte du at spille på violin?

How did you learn how to play the violin?

These connectors commonly introduce subordinate structures. Compare Jeg kommer ikke with fordi jeg ikke kommer. Main-clause verb-second order counts constituents, not words.

Why: Subordinate connectors. [[Danish#^da-Q0348|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hvordan%20l%C3%A6rte%20du%20at%20spille%20p%C3%A5%20violin%3F)
^da-Q0348-answer

**da-Q0349** — Det glæder mig at se dig.

I am pleased to see you.

Expected form: **at**

Why: Subordinate connectors. [[Danish#^da-Q0349|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Det%20gl%C3%A6der%20mig%20at%20se%20dig.)
^da-Q0349-answer

**da-Q0350** — Det glæder mig at se dig.

I am pleased to see you.

Expected form: **at**

Why: Subordinate connectors. [[Danish#^da-Q0350|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Det%20gl%C3%A6der%20mig%20at%20se%20dig.)
^da-Q0350-answer


### Answers 351–400

**da-Q0351** — Tak for indsatsen.

Thanks for the effort.

Expected form: **for**

Why: Coordination. [[Danish#^da-Q0351|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tak%20for%20indsatsen.)
^da-Q0351-answer

**da-Q0352** — Tak for indsatsen.

Thanks for the effort.

Why: Coordination. [[Danish#^da-Q0352|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tak%20for%20indsatsen.)
^da-Q0352-answer

**da-Q0353** — Han så til højre og gik.

He looked right and left.

Why: Coordination. [[Danish#^da-Q0353|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Han%20s%C3%A5%20til%20h%C3%B8jre%20og%20gik.)
^da-Q0353-answer

**da-Q0354** — Han så til højre og gik.

He looked right and left.

Coordinating connectors link phrases or clauses. For can function as a causal conjunction or as a preposition; analyse the following structure.

Why: Coordination. [[Danish#^da-Q0354|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Han%20s%C3%A5%20til%20h%C3%B8jre%20og%20gik.)
^da-Q0354-answer

**da-Q0355** — Min bror taler for meget.

My brother talks too much.

Expected form: **for**

Why: Coordination. [[Danish#^da-Q0355|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Min%20bror%20taler%20for%20meget.)
^da-Q0355-answer

**da-Q0356** — Min bror taler for meget.

My brother talks too much.

Expected form: **for**

Why: Coordination. [[Danish#^da-Q0356|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Min%20bror%20taler%20for%20meget.)
^da-Q0356-answer

**da-Q0357** — Du betyder alt for mig. Det gør du virkelig!

You mean the world to me, you really do.

Expected form: **for**

Why: Coordination. [[Danish#^da-Q0357|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Du%20betyder%20alt%20for%20mig.%20Det%20g%C3%B8r%20du%20virkelig%21)
^da-Q0357-answer

**da-Q0358** — Du betyder alt for mig. Det gør du virkelig!

You mean the world to me, you really do.

Why: Coordination. [[Danish#^da-Q0358|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Du%20betyder%20alt%20for%20mig.%20Det%20g%C3%B8r%20du%20virkelig%21)
^da-Q0358-answer

**da-Q0359** — Solen gik ned for et stykke tid siden.

The sun set a while ago.

Why: Coordination. [[Danish#^da-Q0359|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Solen%20gik%20ned%20for%20et%20stykke%20tid%20siden.)
^da-Q0359-answer

**da-Q0360** — Solen gik ned for et stykke tid siden.

The sun set a while ago.

Coordinating connectors link phrases or clauses. For can function as a causal conjunction or as a preposition; analyse the following structure.

Why: Coordination. [[Danish#^da-Q0360|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Solen%20gik%20ned%20for%20et%20stykke%20tid%20siden.)
^da-Q0360-answer

**da-Q0361** — Bedstefar åbnede bilens vindue og sigtede på en fugl med geværet.

Grandfather opened the car window and aimed the gun at a bird.

Expected form: **og**

Why: Coordination. [[Danish#^da-Q0361|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Bedstefar%20%C3%A5bnede%20bilens%20vindue%20og%20sigtede%20p%C3%A5%20en%20fugl%20med%20gev%C3%A6ret.)
^da-Q0361-answer

**da-Q0362** — Bedstefar åbnede bilens vindue og sigtede på en fugl med geværet.

Grandfather opened the car window and aimed the gun at a bird.

Expected form: **og**

Why: Coordination. [[Danish#^da-Q0362|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Bedstefar%20%C3%A5bnede%20bilens%20vindue%20og%20sigtede%20p%C3%A5%20en%20fugl%20med%20gev%C3%A6ret.)
^da-Q0362-answer

**da-Q0363** — Den Engelske Kanal skiller England og Frankrig.

The English Channel separates England and France.

Expected form: **og**

Why: Coordination. [[Danish#^da-Q0363|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Den%20Engelske%20Kanal%20skiller%20England%20og%20Frankrig.)
^da-Q0363-answer

**da-Q0364** — Den Engelske Kanal skiller England og Frankrig.

The English Channel separates England and France.

Why: Coordination. [[Danish#^da-Q0364|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Den%20Engelske%20Kanal%20skiller%20England%20og%20Frankrig.)
^da-Q0364-answer

**da-Q0365** — Den er for stor.

It's too big.

Why: Coordination. [[Danish#^da-Q0365|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Den%20er%20for%20stor.)
^da-Q0365-answer

**da-Q0366** — Den er for stor.

It's too big.

Coordinating connectors link phrases or clauses. For can function as a causal conjunction or as a preposition; analyse the following structure.

Why: Coordination. [[Danish#^da-Q0366|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Den%20er%20for%20stor.)
^da-Q0366-answer

**da-Q0367** — Da Tom satte sig, stødte han til bordet, og hans kaffe blev spildt ud over dugen.

As Tom sat down, he bumped the table and his coffee spilled onto the tablecloth.

Expected form: **og**

Why: Coordination. [[Danish#^da-Q0367|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Da%20Tom%20satte%20sig%2C%20st%C3%B8dte%20han%20til%20bordet%2C%20og%20hans%20kaffe%20blev%20spildt%20ud%20over%20dugen.)
^da-Q0367-answer

**da-Q0368** — Da Tom satte sig, stødte han til bordet, og hans kaffe blev spildt ud over dugen.

As Tom sat down, he bumped the table and his coffee spilled onto the tablecloth.

Expected form: **og**

Why: Coordination. [[Danish#^da-Q0368|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Da%20Tom%20satte%20sig%2C%20st%C3%B8dte%20han%20til%20bordet%2C%20og%20hans%20kaffe%20blev%20spildt%20ud%20over%20dugen.)
^da-Q0368-answer

**da-Q0369** — Tom købte en pose æbler, og han spiste en tredjedel af dem på én dag.

Tom bought a bag of apples and he ate a third of them in one day.

Expected form: **og**

Why: Coordination. [[Danish#^da-Q0369|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20k%C3%B8bte%20en%20pose%20%C3%A6bler%2C%20og%20han%20spiste%20en%20tredjedel%20af%20dem%20p%C3%A5%20%C3%A9n%20dag.)
^da-Q0369-answer

**da-Q0370** — Tom købte en pose æbler, og han spiste en tredjedel af dem på én dag.

Tom bought a bag of apples and he ate a third of them in one day.

Why: Coordination. [[Danish#^da-Q0370|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20k%C3%B8bte%20en%20pose%20%C3%A6bler%2C%20og%20han%20spiste%20en%20tredjedel%20af%20dem%20p%C3%A5%20%C3%A9n%20dag.)
^da-Q0370-answer

**da-Q0371** — I morgen skal jeg ud og shoppe.

Tomorrow I am going shopping.

Why: Coordination. [[Danish#^da-Q0371|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=I%20morgen%20skal%20jeg%20ud%20og%20shoppe.)
^da-Q0371-answer

**da-Q0372** — I morgen skal jeg ud og shoppe.

Tomorrow I am going shopping.

Coordinating connectors link phrases or clauses. For can function as a causal conjunction or as a preposition; analyse the following structure.

Why: Coordination. [[Danish#^da-Q0372|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=I%20morgen%20skal%20jeg%20ud%20og%20shoppe.)
^da-Q0372-answer

**da-Q0373** — Havet er forurenet af bittesmå plastpartikler der er skadelige for havdyr.

The sea is polluted by tiny plastic particles that are harmful to marine animals.

Expected form: **for**

Why: Coordination. [[Danish#^da-Q0373|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Havet%20er%20forurenet%20af%20bittesm%C3%A5%20plastpartikler%20der%20er%20skadelige%20for%20havdyr.)
^da-Q0373-answer

**da-Q0374** — Havet er forurenet af bittesmå plastpartikler der er skadelige for havdyr.

The sea is polluted by tiny plastic particles that are harmful to marine animals.

Expected form: **for**

Why: Coordination. [[Danish#^da-Q0374|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Havet%20er%20forurenet%20af%20bittesm%C3%A5%20plastpartikler%20der%20er%20skadelige%20for%20havdyr.)
^da-Q0374-answer

**da-Q0375** — Min skolekammerat skrev af efter mine lektier og læreren opdagede det.

My friend copied my homework and the teacher found out.

Expected form: **og**

Why: Coordination. [[Danish#^da-Q0375|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Min%20skolekammerat%20skrev%20af%20efter%20mine%20lektier%20og%20l%C3%A6reren%20opdagede%20det.)
^da-Q0375-answer

**da-Q0376** — Min skolekammerat skrev af efter mine lektier og læreren opdagede det.

My friend copied my homework and the teacher found out.

Why: Coordination. [[Danish#^da-Q0376|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Min%20skolekammerat%20skrev%20af%20efter%20mine%20lektier%20og%20l%C3%A6reren%20opdagede%20det.)
^da-Q0376-answer

**da-Q0377** — En, to, tre, fire, fem, seks, syv, otte, ni og ti er tal.

One, two, three, four, five, six, seven, eight, nine, and ten are numbers.

Why: Coordination. [[Danish#^da-Q0377|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=En%2C%20to%2C%20tre%2C%20fire%2C%20fem%2C%20seks%2C%20syv%2C%20otte%2C%20ni%20og%20ti%20er%20tal.)
^da-Q0377-answer

**da-Q0378** — En, to, tre, fire, fem, seks, syv, otte, ni og ti er tal.

One, two, three, four, five, six, seven, eight, nine, and ten are numbers.

Coordinating connectors link phrases or clauses. For can function as a causal conjunction or as a preposition; analyse the following structure.

Why: Coordination. [[Danish#^da-Q0378|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=En%2C%20to%2C%20tre%2C%20fire%2C%20fem%2C%20seks%2C%20syv%2C%20otte%2C%20ni%20og%20ti%20er%20tal.)
^da-Q0378-answer

**da-Q0379** — Vi er meget glade for det.

We're very happy about it.

Expected form: **for**

Why: Coordination. [[Danish#^da-Q0379|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Vi%20er%20meget%20glade%20for%20det.)
^da-Q0379-answer

**da-Q0380** — Vi er meget glade for det.

We're very happy about it.

Expected form: **for**

Why: Coordination. [[Danish#^da-Q0380|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Vi%20er%20meget%20glade%20for%20det.)
^da-Q0380-answer

**da-Q0381** — Jeg spiser frugter og drikker vand.

I eat fruit and drink water.

Expected form: **og**

Why: Coordination. [[Danish#^da-Q0381|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20spiser%20frugter%20og%20drikker%20vand.)
^da-Q0381-answer

**da-Q0382** — Jeg spiser frugter og drikker vand.

I eat fruit and drink water.

Why: Coordination. [[Danish#^da-Q0382|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20spiser%20frugter%20og%20drikker%20vand.)
^da-Q0382-answer

**da-Q0383** — Japanske unge kan godt lide rock og jazz.

Japanese young people like rock and jazz.

Why: Coordination. [[Danish#^da-Q0383|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Japanske%20unge%20kan%20godt%20lide%20rock%20og%20jazz.)
^da-Q0383-answer

**da-Q0384** — Japanske unge kan godt lide rock og jazz.

Japanese young people like rock and jazz.

Coordinating connectors link phrases or clauses. For can function as a causal conjunction or as a preposition; analyse the following structure.

Why: Coordination. [[Danish#^da-Q0384|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Japanske%20unge%20kan%20godt%20lide%20rock%20og%20jazz.)
^da-Q0384-answer

**da-Q0385** — Røde hunde kaldes også »tyske mæslinger« på engelsk, mens tyskerne kalder rakitis dvs. engelsk syge for »den engelske syge«.

Rubella is also called 'German measles' in English, while Germans call rickets 'the English disease'.

Expected form: **for**

Why: Coordination. [[Danish#^da-Q0385|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=R%C3%B8de%20hunde%20kaldes%20ogs%C3%A5%20%C2%BBtyske%20m%C3%A6slinger%C2%AB%20p%C3%A5%20engelsk%2C%20mens%20tyskerne%20kalder%20rakitis%20dvs.%20engelsk%20syge%20for%20%C2%BBden%20engelske%20syge%C2%AB.)
^da-Q0385-answer

**da-Q0386** — Røde hunde kaldes også »tyske mæslinger« på engelsk, mens tyskerne kalder rakitis dvs. engelsk syge for »den engelske syge«.

Rubella is also called 'German measles' in English, while Germans call rickets 'the English disease'.

Expected form: **for**

Why: Coordination. [[Danish#^da-Q0386|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=R%C3%B8de%20hunde%20kaldes%20ogs%C3%A5%20%C2%BBtyske%20m%C3%A6slinger%C2%AB%20p%C3%A5%20engelsk%2C%20mens%20tyskerne%20kalder%20rakitis%20dvs.%20engelsk%20syge%20for%20%C2%BBden%20engelske%20syge%C2%AB.)
^da-Q0386-answer

**da-Q0387** — Nu eller aldrig!

It's now or never.

Expected form: **eller**

Why: Coordination. [[Danish#^da-Q0387|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Nu%20eller%20aldrig%21)
^da-Q0387-answer

**da-Q0388** — Nu eller aldrig!

It's now or never.

Why: Coordination. [[Danish#^da-Q0388|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Nu%20eller%20aldrig%21)
^da-Q0388-answer

**da-Q0389** — Askenaserne gennemgik en genetisk flaskehals for omkring 700 år siden.

Ashkenazim experienced a population bottleneck around 700 years ago.

Why: Coordination. [[Danish#^da-Q0389|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Askenaserne%20gennemgik%20en%20genetisk%20flaskehals%20for%20omkring%20700%20%C3%A5r%20siden.)
^da-Q0389-answer

**da-Q0390** — Askenaserne gennemgik en genetisk flaskehals for omkring 700 år siden.

Ashkenazim experienced a population bottleneck around 700 years ago.

Coordinating connectors link phrases or clauses. For can function as a causal conjunction or as a preposition; analyse the following structure.

Why: Coordination. [[Danish#^da-Q0390|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Askenaserne%20gennemgik%20en%20genetisk%20flaskehals%20for%20omkring%20700%20%C3%A5r%20siden.)
^da-Q0390-answer

**da-Q0391** — Af en eller anden grund kunne jeg ikke tilgå min e-mail.

For some reason I couldn't access my e-mail.

Expected form: **eller**

Why: Coordination. [[Danish#^da-Q0391|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Af%20en%20eller%20anden%20grund%20kunne%20jeg%20ikke%20tilg%C3%A5%20min%20e-mail.)
^da-Q0391-answer

**da-Q0392** — Af en eller anden grund kunne jeg ikke tilgå min e-mail.

For some reason I couldn't access my e-mail.

Expected form: **eller**

Why: Coordination. [[Danish#^da-Q0392|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Af%20en%20eller%20anden%20grund%20kunne%20jeg%20ikke%20tilg%C3%A5%20min%20e-mail.)
^da-Q0392-answer

**da-Q0393** — Tom og Mary kommer ikke til festen.

Tom and Mary aren't coming to the party.

Expected form: **og**

Why: Coordination. [[Danish#^da-Q0393|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20og%20Mary%20kommer%20ikke%20til%20festen.)
^da-Q0393-answer

**da-Q0394** — Tom og Mary kommer ikke til festen.

Tom and Mary aren't coming to the party.

Why: Coordination. [[Danish#^da-Q0394|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20og%20Mary%20kommer%20ikke%20til%20festen.)
^da-Q0394-answer

**da-Q0395** — Sig goddag til din mor for mig.

Say hello to your mum for me.

Why: Coordination. [[Danish#^da-Q0395|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Sig%20goddag%20til%20din%20mor%20for%20mig.)
^da-Q0395-answer

**da-Q0396** — Sig goddag til din mor for mig.

Say hello to your mum for me.

Coordinating connectors link phrases or clauses. For can function as a causal conjunction or as a preposition; analyse the following structure.

Why: Coordination. [[Danish#^da-Q0396|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Sig%20goddag%20til%20din%20mor%20for%20mig.)
^da-Q0396-answer

**da-Q0397** — Tom og Mary vil holde deres løfte.

Tom and Mary will keep their promise.

Expected form: **og**

Why: Coordination. [[Danish#^da-Q0397|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20og%20Mary%20vil%20holde%20deres%20l%C3%B8fte.)
^da-Q0397-answer

**da-Q0398** — Tom og Mary vil holde deres løfte.

Tom and Mary will keep their promise.

Expected form: **og**

Why: Coordination. [[Danish#^da-Q0398|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20og%20Mary%20vil%20holde%20deres%20l%C3%B8fte.)
^da-Q0398-answer

**da-Q0399** — Han er læge og tillige forfatter.

He is a doctor and also a novelist.

Expected form: **og**

Why: Coordination. [[Danish#^da-Q0399|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Han%20er%20l%C3%A6ge%20og%20tillige%20forfatter.)
^da-Q0399-answer

**da-Q0400** — Han er læge og tillige forfatter.

He is a doctor and also a novelist.

Why: Coordination. [[Danish#^da-Q0400|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Han%20er%20l%C3%A6ge%20og%20tillige%20forfatter.)
^da-Q0400-answer


### Answers 401–450

**da-Q0401** — Tom vil lære serbisk.

Tom wants to learn Serbian.

Why: Modals. [[Danish#^da-Q0401|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20vil%20l%C3%A6re%20serbisk.)
^da-Q0401-answer

**da-Q0402** — Tom vil lære serbisk.

Tom wants to learn Serbian.

Modals express ability, duty, permission, prediction or intention. They normally combine with a bare infinitive. Their past forms can also create polite or hypothetical distance.

Why: Modals. [[Danish#^da-Q0402|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20vil%20l%C3%A6re%20serbisk.)
^da-Q0402-answer

**da-Q0403** — Tom ville sælge sin bil.

Tom wanted to sell his car.

Expected form: **ville**

Why: Modals. [[Danish#^da-Q0403|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20ville%20s%C3%A6lge%20sin%20bil.)
^da-Q0403-answer

**da-Q0404** — Tom ville sælge sin bil.

Tom wanted to sell his car.

Expected form: **ville**

Why: Modals. [[Danish#^da-Q0404|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20ville%20s%C3%A6lge%20sin%20bil.)
^da-Q0404-answer

**da-Q0405** — Dit ønske vil gå i opfyldelse i nær fremtid.

Your wish will come true in the near future.

Expected form: **vil**

Why: Modals. [[Danish#^da-Q0405|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Dit%20%C3%B8nske%20vil%20g%C3%A5%20i%20opfyldelse%20i%20n%C3%A6r%20fremtid.)
^da-Q0405-answer

**da-Q0406** — Dit ønske vil gå i opfyldelse i nær fremtid.

Your wish will come true in the near future.

Why: Modals. [[Danish#^da-Q0406|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Dit%20%C3%B8nske%20vil%20g%C3%A5%20i%20opfyldelse%20i%20n%C3%A6r%20fremtid.)
^da-Q0406-answer

**da-Q0407** — Hun kan selvfølgelig tale engelsk.

She can speak English, of course.

Why: Modals. [[Danish#^da-Q0407|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hun%20kan%20selvf%C3%B8lgelig%20tale%20engelsk.)
^da-Q0407-answer

**da-Q0408** — Hun kan selvfølgelig tale engelsk.

She can speak English, of course.

Modals express ability, duty, permission, prediction or intention. They normally combine with a bare infinitive. Their past forms can also create polite or hypothetical distance.

Why: Modals. [[Danish#^da-Q0408|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hun%20kan%20selvf%C3%B8lgelig%20tale%20engelsk.)
^da-Q0408-answer

**da-Q0409** — Jeg vil altid elske dig.

I will always love you.

Expected form: **vil**

Why: Modals. [[Danish#^da-Q0409|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20vil%20altid%20elske%20dig.)
^da-Q0409-answer

**da-Q0410** — Jeg vil altid elske dig.

I will always love you.

Expected form: **vil**

Why: Modals. [[Danish#^da-Q0410|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20vil%20altid%20elske%20dig.)
^da-Q0410-answer

**da-Q0411** — Der findes mange amerikanere som kan tale japansk.

There are many Americans who can speak Japanese.

Expected form: **kan**

Why: Modals. [[Danish#^da-Q0411|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Der%20findes%20mange%20amerikanere%20som%20kan%20tale%20japansk.)
^da-Q0411-answer

**da-Q0412** — Der findes mange amerikanere som kan tale japansk.

There are many Americans who can speak Japanese.

Why: Modals. [[Danish#^da-Q0412|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Der%20findes%20mange%20amerikanere%20som%20kan%20tale%20japansk.)
^da-Q0412-answer

**da-Q0413** — Retfærdigheden må ske fyldest.

Justice must be done.

Why: Modals. [[Danish#^da-Q0413|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Retf%C3%A6rdigheden%20m%C3%A5%20ske%20fyldest.)
^da-Q0413-answer

**da-Q0414** — Retfærdigheden må ske fyldest.

Justice must be done.

Modals express ability, duty, permission, prediction or intention. They normally combine with a bare infinitive. Their past forms can also create polite or hypothetical distance.

Why: Modals. [[Danish#^da-Q0414|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Retf%C3%A6rdigheden%20m%C3%A5%20ske%20fyldest.)
^da-Q0414-answer

**da-Q0415** — Jeg vil hjælpe dig.

I'll help you.

Expected form: **vil**

Why: Modals. [[Danish#^da-Q0415|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20vil%20hj%C3%A6lpe%20dig.)
^da-Q0415-answer

**da-Q0416** — Jeg vil hjælpe dig.

I'll help you.

Expected form: **vil**

Why: Modals. [[Danish#^da-Q0416|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20vil%20hj%C3%A6lpe%20dig.)
^da-Q0416-answer

**da-Q0417** — Tom måtte begynde forfra.

Tom had to start over again.

Expected form: **måtte**

Why: Modals. [[Danish#^da-Q0417|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20m%C3%A5tte%20begynde%20forfra.)
^da-Q0417-answer

**da-Q0418** — Tom måtte begynde forfra.

Tom had to start over again.

Why: Modals. [[Danish#^da-Q0418|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20m%C3%A5tte%20begynde%20forfra.)
^da-Q0418-answer

**da-Q0419** — Vi må være forsigtige.

We need to be cautious.

Why: Modals. [[Danish#^da-Q0419|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Vi%20m%C3%A5%20v%C3%A6re%20forsigtige.)
^da-Q0419-answer

**da-Q0420** — Vi må være forsigtige.

We need to be cautious.

Modals express ability, duty, permission, prediction or intention. They normally combine with a bare infinitive. Their past forms can also create polite or hypothetical distance.

Why: Modals. [[Danish#^da-Q0420|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Vi%20m%C3%A5%20v%C3%A6re%20forsigtige.)
^da-Q0420-answer

**da-Q0421** — Hvor mange sprog kan din kone tale?

How many languages does your wife speak?

Expected form: **kan**

Why: Modals. [[Danish#^da-Q0421|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hvor%20mange%20sprog%20kan%20din%20kone%20tale%3F)
^da-Q0421-answer

**da-Q0422** — Hvor mange sprog kan din kone tale?

How many languages does your wife speak?

Expected form: **kan**

Why: Modals. [[Danish#^da-Q0422|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hvor%20mange%20sprog%20kan%20din%20kone%20tale%3F)
^da-Q0422-answer

**da-Q0423** — Du må have set noget.

You must've seen something.

Expected form: **må**

Why: Modals. [[Danish#^da-Q0423|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Du%20m%C3%A5%20have%20set%20noget.)
^da-Q0423-answer

**da-Q0424** — Du må have set noget.

You must've seen something.

Why: Modals. [[Danish#^da-Q0424|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Du%20m%C3%A5%20have%20set%20noget.)
^da-Q0424-answer

**da-Q0425** — Jeg vil gerne købe et køleskab.

I'd like to buy a refrigerator.

Why: Modals. [[Danish#^da-Q0425|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20vil%20gerne%20k%C3%B8be%20et%20k%C3%B8leskab.)
^da-Q0425-answer

**da-Q0426** — Jeg vil gerne købe et køleskab.

I'd like to buy a refrigerator.

Modals express ability, duty, permission, prediction or intention. They normally combine with a bare infinitive. Their past forms can also create polite or hypothetical distance.

Why: Modals. [[Danish#^da-Q0426|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20vil%20gerne%20k%C3%B8be%20et%20k%C3%B8leskab.)
^da-Q0426-answer

**da-Q0427** — Hvad ville din far tænke?

What would your father think?

Expected form: **ville**

Why: Modals. [[Danish#^da-Q0427|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hvad%20ville%20din%20far%20t%C3%A6nke%3F)
^da-Q0427-answer

**da-Q0428** — Hvad ville din far tænke?

What would your father think?

Expected form: **ville**

Why: Modals. [[Danish#^da-Q0428|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hvad%20ville%20din%20far%20t%C3%A6nke%3F)
^da-Q0428-answer

**da-Q0429** — Tom spekulerede over, hvor længe han skulle vente på Mary.

Tom wondered how long he'd have to wait for Mary.

Expected form: **skulle**

Why: Modals. [[Danish#^da-Q0429|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20spekulerede%20over%2C%20hvor%20l%C3%A6nge%20han%20skulle%20vente%20p%C3%A5%20Mary.)
^da-Q0429-answer

**da-Q0430** — Tom spekulerede over, hvor længe han skulle vente på Mary.

Tom wondered how long he'd have to wait for Mary.

Why: Modals. [[Danish#^da-Q0430|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20spekulerede%20over%2C%20hvor%20l%C3%A6nge%20han%20skulle%20vente%20p%C3%A5%20Mary.)
^da-Q0430-answer

**da-Q0431** — Tom ville nok vælge den her.

Tom would probably choose this one.

Why: Modals. [[Danish#^da-Q0431|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20ville%20nok%20v%C3%A6lge%20den%20her.)
^da-Q0431-answer

**da-Q0432** — Tom ville nok vælge den her.

Tom would probably choose this one.

Modals express ability, duty, permission, prediction or intention. They normally combine with a bare infinitive. Their past forms can also create polite or hypothetical distance.

Why: Modals. [[Danish#^da-Q0432|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20ville%20nok%20v%C3%A6lge%20den%20her.)
^da-Q0432-answer

**da-Q0433** — Du skal komme.

You must come.

Expected form: **skal**

Why: Modals. [[Danish#^da-Q0433|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Du%20skal%20komme.)
^da-Q0433-answer

**da-Q0434** — Du skal komme.

You must come.

Expected form: **skal**

Why: Modals. [[Danish#^da-Q0434|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Du%20skal%20komme.)
^da-Q0434-answer

**da-Q0435** — Tom kan på tredive sprog sige "Jeg taler kun fransk."

Tom can say "I can only speak French" in thirty languages.

Expected form: **kan**

Why: Modals. [[Danish#^da-Q0435|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20kan%20p%C3%A5%20tredive%20sprog%20sige%20%22Jeg%20taler%20kun%20fransk.%22)
^da-Q0435-answer

**da-Q0436** — Tom kan på tredive sprog sige "Jeg taler kun fransk."

Tom can say "I can only speak French" in thirty languages.

Why: Modals. [[Danish#^da-Q0436|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20kan%20p%C3%A5%20tredive%20sprog%20sige%20%22Jeg%20taler%20kun%20fransk.%22)
^da-Q0436-answer

**da-Q0437** — Jeg kender nogen som kan hjælpe dig.

I know someone who can help you.

Why: Modals. [[Danish#^da-Q0437|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20kender%20nogen%20som%20kan%20hj%C3%A6lpe%20dig.)
^da-Q0437-answer

**da-Q0438** — Jeg kender nogen som kan hjælpe dig.

I know someone who can help you.

Modals express ability, duty, permission, prediction or intention. They normally combine with a bare infinitive. Their past forms can also create polite or hypothetical distance.

Why: Modals. [[Danish#^da-Q0438|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20kender%20nogen%20som%20kan%20hj%C3%A6lpe%20dig.)
^da-Q0438-answer

**da-Q0439** — Du skal tage tyren ved hornene.

You must take the bull by the horns.

Expected form: **skal**

Why: Modals. [[Danish#^da-Q0439|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Du%20skal%20tage%20tyren%20ved%20hornene.)
^da-Q0439-answer

**da-Q0440** — Du skal tage tyren ved hornene.

You must take the bull by the horns.

Expected form: **skal**

Why: Modals. [[Danish#^da-Q0440|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Du%20skal%20tage%20tyren%20ved%20hornene.)
^da-Q0440-answer

**da-Q0441** — I morgen vil vi proklamere en republik.

Tomorrow we shall proclaim a republic.

Expected form: **vil**

Why: Modals. [[Danish#^da-Q0441|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=I%20morgen%20vil%20vi%20proklamere%20en%20republik.)
^da-Q0441-answer

**da-Q0442** — I morgen vil vi proklamere en republik.

Tomorrow we shall proclaim a republic.

Why: Modals. [[Danish#^da-Q0442|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=I%20morgen%20vil%20vi%20proklamere%20en%20republik.)
^da-Q0442-answer

**da-Q0443** — Han er den sidste person der vil tale dårligt om andre.

He is the last person to speak ill of others.

Why: Modals. [[Danish#^da-Q0443|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Han%20er%20den%20sidste%20person%20der%20vil%20tale%20d%C3%A5rligt%20om%20andre.)
^da-Q0443-answer

**da-Q0444** — Han er den sidste person der vil tale dårligt om andre.

He is the last person to speak ill of others.

Modals express ability, duty, permission, prediction or intention. They normally combine with a bare infinitive. Their past forms can also create polite or hypothetical distance.

Why: Modals. [[Danish#^da-Q0444|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Han%20er%20den%20sidste%20person%20der%20vil%20tale%20d%C3%A5rligt%20om%20andre.)
^da-Q0444-answer

**da-Q0445** — Din far vil ikke købe det.

Your father will not buy it.

Expected form: **vil**

Why: Modals. [[Danish#^da-Q0445|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Din%20far%20vil%20ikke%20k%C3%B8be%20det.)
^da-Q0445-answer

**da-Q0446** — Din far vil ikke købe det.

Your father will not buy it.

Expected form: **vil**

Why: Modals. [[Danish#^da-Q0446|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Din%20far%20vil%20ikke%20k%C3%B8be%20det.)
^da-Q0446-answer

**da-Q0447** — Tom kan lide berlinerpfannkuchen.

Tom likes jelly donuts.

Expected form: **kan**

Why: Modals. [[Danish#^da-Q0447|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20kan%20lide%20berlinerpfannkuchen.)
^da-Q0447-answer

**da-Q0448** — Tom kan lide berlinerpfannkuchen.

Tom likes jelly donuts.

Why: Modals. [[Danish#^da-Q0448|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20kan%20lide%20berlinerpfannkuchen.)
^da-Q0448-answer

**da-Q0449** — Jeg kan lide at køre på motorcykler.

I like to ride motorcycles.

Why: Modals. [[Danish#^da-Q0449|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20kan%20lide%20at%20k%C3%B8re%20p%C3%A5%20motorcykler.)
^da-Q0449-answer

**da-Q0450** — Jeg kan lide at køre på motorcykler.

I like to ride motorcycles.

Modals express ability, duty, permission, prediction or intention. They normally combine with a bare infinitive. Their past forms can also create polite or hypothetical distance.

Why: Modals. [[Danish#^da-Q0450|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20kan%20lide%20at%20k%C3%B8re%20p%C3%A5%20motorcykler.)
^da-Q0450-answer


### Answers 451–500

**da-Q0451** — Jeg har set dig gøre det.

I've seen you doing that.

Expected form: **set**

Why: Perfect participles. [[Danish#^da-Q0451|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20har%20set%20dig%20g%C3%B8re%20det.)
^da-Q0451-answer

**da-Q0452** — Jeg har set dig gøre det.

I've seen you doing that.

Expected form: **set**

Why: Perfect participles. [[Danish#^da-Q0452|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20har%20set%20dig%20g%C3%B8re%20det.)
^da-Q0452-answer

**da-Q0453** — Hun er ikke kommet.

She did not come.

Expected form: **kommet**

Why: Perfect participles. [[Danish#^da-Q0453|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hun%20er%20ikke%20kommet.)
^da-Q0453-answer

**da-Q0454** — Hun er ikke kommet.

She did not come.

Why: Perfect participles. [[Danish#^da-Q0454|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hun%20er%20ikke%20kommet.)
^da-Q0454-answer

**da-Q0455** — Tom har sagt at han er bange for at hans telefon er klogere end han er.

Tom said that he's scared that his phone is smarter than he is.

Why: Perfect participles. [[Danish#^da-Q0455|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20har%20sagt%20at%20han%20er%20bange%20for%20at%20hans%20telefon%20er%20klogere%20end%20han%20er.)
^da-Q0455-answer

**da-Q0456** — Tom har sagt at han er bange for at hans telefon er klogere end han er.

Tom said that he's scared that his phone is smarter than he is.

A perfect combines har or er with a participle. Auxiliary choice can depend on the verb and meaning. A participle may also appear in a passive or as an adjective.

Why: Perfect participles. [[Danish#^da-Q0456|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20har%20sagt%20at%20han%20er%20bange%20for%20at%20hans%20telefon%20er%20klogere%20end%20han%20er.)
^da-Q0456-answer

**da-Q0457** — Tom har fået det så meget bedre.

Tom has gotten so much better.

Expected form: **fået**

Why: Perfect participles. [[Danish#^da-Q0457|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20har%20f%C3%A5et%20det%20s%C3%A5%20meget%20bedre.)
^da-Q0457-answer

**da-Q0458** — Tom har fået det så meget bedre.

Tom has gotten so much better.

Expected form: **fået**

Why: Perfect participles. [[Danish#^da-Q0458|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20har%20f%C3%A5et%20det%20s%C3%A5%20meget%20bedre.)
^da-Q0458-answer

**da-Q0459** — Jeg har ikke gjort det.

I didn't do it.

Expected form: **gjort**

Why: Perfect participles. [[Danish#^da-Q0459|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20har%20ikke%20gjort%20det.)
^da-Q0459-answer

**da-Q0460** — Jeg har ikke gjort det.

I didn't do it.

Why: Perfect participles. [[Danish#^da-Q0460|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20har%20ikke%20gjort%20det.)
^da-Q0460-answer

**da-Q0461** — Det er ikke som det har været.

It's not like it used to be.

Why: Perfect participles. [[Danish#^da-Q0461|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Det%20er%20ikke%20som%20det%20har%20v%C3%A6ret.)
^da-Q0461-answer

**da-Q0462** — Det er ikke som det har været.

It's not like it used to be.

A perfect combines har or er with a participle. Auxiliary choice can depend on the verb and meaning. A participle may also appear in a passive or as an adjective.

Why: Perfect participles. [[Danish#^da-Q0462|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Det%20er%20ikke%20som%20det%20har%20v%C3%A6ret.)
^da-Q0462-answer

**da-Q0463** — Jeg har fået det forkerte ben ud af sengen i dag.

I woke up on the wrong side of the bed today.

Expected form: **fået**

Why: Perfect participles. [[Danish#^da-Q0463|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20har%20f%C3%A5et%20det%20forkerte%20ben%20ud%20af%20sengen%20i%20dag.)
^da-Q0463-answer

**da-Q0464** — Jeg har fået det forkerte ben ud af sengen i dag.

I woke up on the wrong side of the bed today.

Expected form: **fået**

Why: Perfect participles. [[Danish#^da-Q0464|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20har%20f%C3%A5et%20det%20forkerte%20ben%20ud%20af%20sengen%20i%20dag.)
^da-Q0464-answer

**da-Q0465** — Jeg er lige kommet hjem.

I just got home.

Expected form: **kommet**

Why: Perfect participles. [[Danish#^da-Q0465|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20er%20lige%20kommet%20hjem.)
^da-Q0465-answer

**da-Q0466** — Jeg er lige kommet hjem.

I just got home.

Why: Perfect participles. [[Danish#^da-Q0466|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20er%20lige%20kommet%20hjem.)
^da-Q0466-answer

**da-Q0467** — Har du set mine bilnøgler?

Have you seen my car keys?

Why: Perfect participles. [[Danish#^da-Q0467|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Har%20du%20set%20mine%20biln%C3%B8gler%3F)
^da-Q0467-answer

**da-Q0468** — Har du set mine bilnøgler?

Have you seen my car keys?

A perfect combines har or er with a participle. Auxiliary choice can depend on the verb and meaning. A participle may also appear in a passive or as an adjective.

Why: Perfect participles. [[Danish#^da-Q0468|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Har%20du%20set%20mine%20biln%C3%B8gler%3F)
^da-Q0468-answer

**da-Q0469** — Jeg har læst en masse bøger.

I've read a lot of books.

Expected form: **læst**

Why: Perfect participles. [[Danish#^da-Q0469|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20har%20l%C3%A6st%20en%20masse%20b%C3%B8ger.)
^da-Q0469-answer

**da-Q0470** — Jeg har læst en masse bøger.

I've read a lot of books.

Expected form: **læst**

Why: Perfect participles. [[Danish#^da-Q0470|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20har%20l%C3%A6st%20en%20masse%20b%C3%B8ger.)
^da-Q0470-answer

**da-Q0471** — Har du fået nok søvn?

Did you get enough sleep?

Expected form: **fået**

Why: Perfect participles. [[Danish#^da-Q0471|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Har%20du%20f%C3%A5et%20nok%20s%C3%B8vn%3F)
^da-Q0471-answer

**da-Q0472** — Har du fået nok søvn?

Did you get enough sleep?

Why: Perfect participles. [[Danish#^da-Q0472|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Har%20du%20f%C3%A5et%20nok%20s%C3%B8vn%3F)
^da-Q0472-answer

**da-Q0473** — Det har været hyggeligt at snakke med dig.

I've enjoyed talking to you.

Why: Perfect participles. [[Danish#^da-Q0473|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Det%20har%20v%C3%A6ret%20hyggeligt%20at%20snakke%20med%20dig.)
^da-Q0473-answer

**da-Q0474** — Det har været hyggeligt at snakke med dig.

I've enjoyed talking to you.

A perfect combines har or er with a participle. Auxiliary choice can depend on the verb and meaning. A participle may also appear in a passive or as an adjective.

Why: Perfect participles. [[Danish#^da-Q0474|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Det%20har%20v%C3%A6ret%20hyggeligt%20at%20snakke%20med%20dig.)
^da-Q0474-answer

**da-Q0475** — Hun viste mig et brev skrevet på engelsk.

She showed me a letter written in English.

Expected form: **skrevet**

Why: Perfect participles. [[Danish#^da-Q0475|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hun%20viste%20mig%20et%20brev%20skrevet%20p%C3%A5%20engelsk.)
^da-Q0475-answer

**da-Q0476** — Hun viste mig et brev skrevet på engelsk.

She showed me a letter written in English.

Expected form: **skrevet**

Why: Perfect participles. [[Danish#^da-Q0476|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hun%20viste%20mig%20et%20brev%20skrevet%20p%C3%A5%20engelsk.)
^da-Q0476-answer

**da-Q0477** — Tom har skrevet en bog om fugle.

Tom has written a book about birds.

Expected form: **skrevet**

Why: Perfect participles. [[Danish#^da-Q0477|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20har%20skrevet%20en%20bog%20om%20fugle.)
^da-Q0477-answer

**da-Q0478** — Tom har skrevet en bog om fugle.

Tom has written a book about birds.

Why: Perfect participles. [[Danish#^da-Q0478|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20har%20skrevet%20en%20bog%20om%20fugle.)
^da-Q0478-answer

**da-Q0479** — Jeg har været overalt.

I've been everywhere.

Why: Perfect participles. [[Danish#^da-Q0479|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20har%20v%C3%A6ret%20overalt.)
^da-Q0479-answer

**da-Q0480** — Jeg har været overalt.

I've been everywhere.

A perfect combines har or er with a participle. Auxiliary choice can depend on the verb and meaning. A participle may also appear in a passive or as an adjective.

Why: Perfect participles. [[Danish#^da-Q0480|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20har%20v%C3%A6ret%20overalt.)
^da-Q0480-answer

**da-Q0481** — Vi har set hendes dans.

We saw her dance.

Expected form: **set**

Why: Perfect participles. [[Danish#^da-Q0481|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Vi%20har%20set%20hendes%20dans.)
^da-Q0481-answer

**da-Q0482** — Vi har set hendes dans.

We saw her dance.

Expected form: **set**

Why: Perfect participles. [[Danish#^da-Q0482|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Vi%20har%20set%20hendes%20dans.)
^da-Q0482-answer

**da-Q0483** — Dette er det højeste stillads, jeg nogensinde har set.

This is the tallest scaffolding I've ever seen in my life.

Expected form: **set**

Why: Perfect participles. [[Danish#^da-Q0483|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Dette%20er%20det%20h%C3%B8jeste%20stillads%2C%20jeg%20nogensinde%20har%20set.)
^da-Q0483-answer

**da-Q0484** — Dette er det højeste stillads, jeg nogensinde har set.

This is the tallest scaffolding I've ever seen in my life.

Why: Perfect participles. [[Danish#^da-Q0484|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Dette%20er%20det%20h%C3%B8jeste%20stillads%2C%20jeg%20nogensinde%20har%20set.)
^da-Q0484-answer

**da-Q0485** — I Tyrkiet har Wikipedia været blokeret siden 29. april 2017.

Wikipedia has been blocked in Turkey since April 29, 2017.

Why: Perfect participles. [[Danish#^da-Q0485|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=I%20Tyrkiet%20har%20Wikipedia%20v%C3%A6ret%20blokeret%20siden%2029.%20april%202017.)
^da-Q0485-answer

**da-Q0486** — I Tyrkiet har Wikipedia været blokeret siden 29. april 2017.

Wikipedia has been blocked in Turkey since April 29, 2017.

A perfect combines har or er with a participle. Auxiliary choice can depend on the verb and meaning. A participle may also appear in a passive or as an adjective.

Why: Perfect participles. [[Danish#^da-Q0486|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=I%20Tyrkiet%20har%20Wikipedia%20v%C3%A6ret%20blokeret%20siden%2029.%20april%202017.)
^da-Q0486-answer

**da-Q0487** — Jeg har været i flere end ti fremmede lande indtil nu.

I have been to more than ten foreign countries so far.

Expected form: **været**

Why: Perfect participles. [[Danish#^da-Q0487|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20har%20v%C3%A6ret%20i%20flere%20end%20ti%20fremmede%20lande%20indtil%20nu.)
^da-Q0487-answer

**da-Q0488** — Jeg har været i flere end ti fremmede lande indtil nu.

I have been to more than ten foreign countries so far.

Expected form: **været**

Why: Perfect participles. [[Danish#^da-Q0488|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20har%20v%C3%A6ret%20i%20flere%20end%20ti%20fremmede%20lande%20indtil%20nu.)
^da-Q0488-answer

**da-Q0489** — Har du nogensinde set Tom danse?

Have you ever seen Tom dance?

Expected form: **set**

Why: Perfect participles. [[Danish#^da-Q0489|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Har%20du%20nogensinde%20set%20Tom%20danse%3F)
^da-Q0489-answer

**da-Q0490** — Har du nogensinde set Tom danse?

Have you ever seen Tom dance?

Why: Perfect participles. [[Danish#^da-Q0490|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Har%20du%20nogensinde%20set%20Tom%20danse%3F)
^da-Q0490-answer

**da-Q0491** — Hvad har vi gjort for at blive straffet på den måde?

What have we done to be punished like this?

Why: Perfect participles. [[Danish#^da-Q0491|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hvad%20har%20vi%20gjort%20for%20at%20blive%20straffet%20p%C3%A5%20den%20m%C3%A5de%3F)
^da-Q0491-answer

**da-Q0492** — Hvad har vi gjort for at blive straffet på den måde?

What have we done to be punished like this?

A perfect combines har or er with a participle. Auxiliary choice can depend on the verb and meaning. A participle may also appear in a passive or as an adjective.

Why: Perfect participles. [[Danish#^da-Q0492|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hvad%20har%20vi%20gjort%20for%20at%20blive%20straffet%20p%C3%A5%20den%20m%C3%A5de%3F)
^da-Q0492-answer

**da-Q0493** — Du må have gjort noget.

You must've done something.

Expected form: **gjort**

Why: Perfect participles. [[Danish#^da-Q0493|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Du%20m%C3%A5%20have%20gjort%20noget.)
^da-Q0493-answer

**da-Q0494** — Du må have gjort noget.

You must've done something.

Expected form: **gjort**

Why: Perfect participles. [[Danish#^da-Q0494|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Du%20m%C3%A5%20have%20gjort%20noget.)
^da-Q0494-answer

**da-Q0495** — Jeg burde være gået i seng noget før.

I should have gone to bed earlier.

Expected form: **gået**

Why: Perfect participles. [[Danish#^da-Q0495|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20burde%20v%C3%A6re%20g%C3%A5et%20i%20seng%20noget%20f%C3%B8r.)
^da-Q0495-answer

**da-Q0496** — Jeg burde være gået i seng noget før.

I should have gone to bed earlier.

Why: Perfect participles. [[Danish#^da-Q0496|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20burde%20v%C3%A6re%20g%C3%A5et%20i%20seng%20noget%20f%C3%B8r.)
^da-Q0496-answer

**da-Q0497** — Mary siger, at hun aldrig har set dig før.

Mary says she's never seen you before.

Why: Perfect participles. [[Danish#^da-Q0497|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Mary%20siger%2C%20at%20hun%20aldrig%20har%20set%20dig%20f%C3%B8r.)
^da-Q0497-answer

**da-Q0498** — Mary siger, at hun aldrig har set dig før.

Mary says she's never seen you before.

A perfect combines har or er with a participle. Auxiliary choice can depend on the verb and meaning. A participle may also appear in a passive or as an adjective.

Why: Perfect participles. [[Danish#^da-Q0498|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Mary%20siger%2C%20at%20hun%20aldrig%20har%20set%20dig%20f%C3%B8r.)
^da-Q0498-answer

**da-Q0499** — Jeg har kun læst den første del af bogen.

I've only read the first part of the book.

Expected form: **læst**

Why: Perfect participles. [[Danish#^da-Q0499|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20har%20kun%20l%C3%A6st%20den%20f%C3%B8rste%20del%20af%20bogen.)
^da-Q0499-answer

**da-Q0500** — Jeg har kun læst den første del af bogen.

I've only read the first part of the book.

Expected form: **læst**

Why: Perfect participles. [[Danish#^da-Q0500|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20har%20kun%20l%C3%A6st%20den%20f%C3%B8rste%20del%20af%20bogen.)
^da-Q0500-answer


### Answers 501–550

**da-Q0501** — Undskyld, noget gik galt.

Sorry, something went wrong.

Expected form: **gik**

Why: Past lexical verbs. [[Danish#^da-Q0501|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Undskyld%2C%20noget%20gik%20galt.)
^da-Q0501-answer

**da-Q0502** — Undskyld, noget gik galt.

Sorry, something went wrong.

Why: Past lexical verbs. [[Danish#^da-Q0502|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Undskyld%2C%20noget%20gik%20galt.)
^da-Q0502-answer

**da-Q0503** — Alt gik op i røg.

Everything went up in smoke.

Why: Past lexical verbs. [[Danish#^da-Q0503|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Alt%20gik%20op%20i%20r%C3%B8g.)
^da-Q0503-answer

**da-Q0504** — Alt gik op i røg.

Everything went up in smoke.

Common strong verbs have irregular past forms. Practice the subject and time frame with the form; Danish verbs do not normally conjugate for person.

Why: Past lexical verbs. [[Danish#^da-Q0504|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Alt%20gik%20op%20i%20r%C3%B8g.)
^da-Q0504-answer

**da-Q0505** — Jeg sagde til min kone: Liliane, pak kufferterne, vi tager tilbage til Paris.

I told my wife: Liliane, pack up the bags, we're going back to Paris.

Expected form: **sagde**

Why: Past lexical verbs. [[Danish#^da-Q0505|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20sagde%20til%20min%20kone%3A%20Liliane%2C%20pak%20kufferterne%2C%20vi%20tager%20tilbage%20til%20Paris.)
^da-Q0505-answer

**da-Q0506** — Jeg sagde til min kone: Liliane, pak kufferterne, vi tager tilbage til Paris.

I told my wife: Liliane, pack up the bags, we're going back to Paris.

Expected form: **sagde**

Why: Past lexical verbs. [[Danish#^da-Q0506|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20sagde%20til%20min%20kone%3A%20Liliane%2C%20pak%20kufferterne%2C%20vi%20tager%20tilbage%20til%20Paris.)
^da-Q0506-answer

**da-Q0507** — Jeg tænkte på dig.

I was thinking about you.

Expected form: **tænkte**

Why: Past lexical verbs. [[Danish#^da-Q0507|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20t%C3%A6nkte%20p%C3%A5%20dig.)
^da-Q0507-answer

**da-Q0508** — Jeg tænkte på dig.

I was thinking about you.

Why: Past lexical verbs. [[Danish#^da-Q0508|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20t%C3%A6nkte%20p%C3%A5%20dig.)
^da-Q0508-answer

**da-Q0509** — Hun sagde sandheden.

She was telling the truth.

Why: Past lexical verbs. [[Danish#^da-Q0509|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hun%20sagde%20sandheden.)
^da-Q0509-answer

**da-Q0510** — Hun sagde sandheden.

She was telling the truth.

Common strong verbs have irregular past forms. Practice the subject and time frame with the form; Danish verbs do not normally conjugate for person.

Why: Past lexical verbs. [[Danish#^da-Q0510|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hun%20sagde%20sandheden.)
^da-Q0510-answer

**da-Q0511** — Han, så vel som du, er en god golfspiller.

He, just like you, is a good golfer.

Expected form: **så**

Why: Past lexical verbs. [[Danish#^da-Q0511|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Han%2C%20s%C3%A5%20vel%20som%20du%2C%20er%20en%20god%20golfspiller.)
^da-Q0511-answer

**da-Q0512** — Han, så vel som du, er en god golfspiller.

He, just like you, is a good golfer.

Expected form: **så**

Why: Past lexical verbs. [[Danish#^da-Q0512|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Han%2C%20s%C3%A5%20vel%20som%20du%2C%20er%20en%20god%20golfspiller.)
^da-Q0512-answer

**da-Q0513** — Hvis jeg var en fugl, så kunne jeg flyve hen til dig.

If I were a bird, I could fly to you.

Expected form: **så**

Why: Past lexical verbs. [[Danish#^da-Q0513|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hvis%20jeg%20var%20en%20fugl%2C%20s%C3%A5%20kunne%20jeg%20flyve%20hen%20til%20dig.)
^da-Q0513-answer

**da-Q0514** — Hvis jeg var en fugl, så kunne jeg flyve hen til dig.

If I were a bird, I could fly to you.

Why: Past lexical verbs. [[Danish#^da-Q0514|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hvis%20jeg%20var%20en%20fugl%2C%20s%C3%A5%20kunne%20jeg%20flyve%20hen%20til%20dig.)
^da-Q0514-answer

**da-Q0515** — Tom fik en seks måneders betinget dom.

Tom was given a six-month suspended sentence.

Why: Past lexical verbs. [[Danish#^da-Q0515|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20fik%20en%20seks%20m%C3%A5neders%20betinget%20dom.)
^da-Q0515-answer

**da-Q0516** — Tom fik en seks måneders betinget dom.

Tom was given a six-month suspended sentence.

Common strong verbs have irregular past forms. Practice the subject and time frame with the form; Danish verbs do not normally conjugate for person.

Why: Past lexical verbs. [[Danish#^da-Q0516|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20fik%20en%20seks%20m%C3%A5neders%20betinget%20dom.)
^da-Q0516-answer

**da-Q0517** — Jeg så tre film i går.

I watched three movies yesterday.

Expected form: **så**

Why: Past lexical verbs. [[Danish#^da-Q0517|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20s%C3%A5%20tre%20film%20i%20g%C3%A5r.)
^da-Q0517-answer

**da-Q0518** — Jeg så tre film i går.

I watched three movies yesterday.

Expected form: **så**

Why: Past lexical verbs. [[Danish#^da-Q0518|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20s%C3%A5%20tre%20film%20i%20g%C3%A5r.)
^da-Q0518-answer

**da-Q0519** — Tom taler fransk lige så godt som Mary.

Tom speaks French as well as Mary.

Expected form: **så**

Why: Past lexical verbs. [[Danish#^da-Q0519|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20taler%20fransk%20lige%20s%C3%A5%20godt%20som%20Mary.)
^da-Q0519-answer

**da-Q0520** — Tom taler fransk lige så godt som Mary.

Tom speaks French as well as Mary.

Why: Past lexical verbs. [[Danish#^da-Q0520|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20taler%20fransk%20lige%20s%C3%A5%20godt%20som%20Mary.)
^da-Q0520-answer

**da-Q0521** — Problemet er ikke så meget pengene, som det er tiden.

The problem isn't so much the money as it is the time.

Why: Past lexical verbs. [[Danish#^da-Q0521|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Problemet%20er%20ikke%20s%C3%A5%20meget%20pengene%2C%20som%20det%20er%20tiden.)
^da-Q0521-answer

**da-Q0522** — Problemet er ikke så meget pengene, som det er tiden.

The problem isn't so much the money as it is the time.

Common strong verbs have irregular past forms. Practice the subject and time frame with the form; Danish verbs do not normally conjugate for person.

Why: Past lexical verbs. [[Danish#^da-Q0522|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Problemet%20er%20ikke%20s%C3%A5%20meget%20pengene%2C%20som%20det%20er%20tiden.)
^da-Q0522-answer

**da-Q0523** — Den modige mand så på gangsteren med had og foragt.

The bold man glanced at the gangster with hatred and contempt.

Expected form: **så**

Why: Past lexical verbs. [[Danish#^da-Q0523|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Den%20modige%20mand%20s%C3%A5%20p%C3%A5%20gangsteren%20med%20had%20og%20foragt.)
^da-Q0523-answer

**da-Q0524** — Den modige mand så på gangsteren med had og foragt.

The bold man glanced at the gangster with hatred and contempt.

Expected form: **så**

Why: Past lexical verbs. [[Danish#^da-Q0524|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Den%20modige%20mand%20s%C3%A5%20p%C3%A5%20gangsteren%20med%20had%20og%20foragt.)
^da-Q0524-answer

**da-Q0525** — Når du ser fjernsyn eller hører radio, så er den musik du hører, ofte af afrikansk oprindelse.

When you watch television or listen to the radio, the music which you hear is often African in origin.

Expected form: **så**

Why: Past lexical verbs. [[Danish#^da-Q0525|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=N%C3%A5r%20du%20ser%20fjernsyn%20eller%20h%C3%B8rer%20radio%2C%20s%C3%A5%20er%20den%20musik%20du%20h%C3%B8rer%2C%20ofte%20af%20afrikansk%20oprindelse.)
^da-Q0525-answer

**da-Q0526** — Når du ser fjernsyn eller hører radio, så er den musik du hører, ofte af afrikansk oprindelse.

When you watch television or listen to the radio, the music which you hear is often African in origin.

Why: Past lexical verbs. [[Danish#^da-Q0526|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=N%C3%A5r%20du%20ser%20fjernsyn%20eller%20h%C3%B8rer%20radio%2C%20s%C3%A5%20er%20den%20musik%20du%20h%C3%B8rer%2C%20ofte%20af%20afrikansk%20oprindelse.)
^da-Q0526-answer

**da-Q0527** — Jeg var ikke så stærk som min far.

I was not as strong as my father.

Why: Past lexical verbs. [[Danish#^da-Q0527|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20var%20ikke%20s%C3%A5%20st%C3%A6rk%20som%20min%20far.)
^da-Q0527-answer

**da-Q0528** — Jeg var ikke så stærk som min far.

I was not as strong as my father.

Common strong verbs have irregular past forms. Practice the subject and time frame with the form; Danish verbs do not normally conjugate for person.

Why: Past lexical verbs. [[Danish#^da-Q0528|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20var%20ikke%20s%C3%A5%20st%C3%A6rk%20som%20min%20far.)
^da-Q0528-answer

**da-Q0529** — Han døde inden ambulancen kom.

He died before the ambulance arrived.

Expected form: **kom**

Why: Past lexical verbs. [[Danish#^da-Q0529|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Han%20d%C3%B8de%20inden%20ambulancen%20kom.)
^da-Q0529-answer

**da-Q0530** — Han døde inden ambulancen kom.

He died before the ambulance arrived.

Expected form: **kom**

Why: Past lexical verbs. [[Danish#^da-Q0530|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Han%20d%C3%B8de%20inden%20ambulancen%20kom.)
^da-Q0530-answer

**da-Q0531** — Jeg vidste jeg ikke var skør.

I knew I wasn't crazy.

Expected form: **vidste**

Why: Past lexical verbs. [[Danish#^da-Q0531|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20vidste%20jeg%20ikke%20var%20sk%C3%B8r.)
^da-Q0531-answer

**da-Q0532** — Jeg vidste jeg ikke var skør.

I knew I wasn't crazy.

Why: Past lexical verbs. [[Danish#^da-Q0532|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20vidste%20jeg%20ikke%20var%20sk%C3%B8r.)
^da-Q0532-answer

**da-Q0533** — Tom gik for langt.

Tom went too far.

Why: Past lexical verbs. [[Danish#^da-Q0533|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20gik%20for%20langt.)
^da-Q0533-answer

**da-Q0534** — Tom gik for langt.

Tom went too far.

Common strong verbs have irregular past forms. Practice the subject and time frame with the form; Danish verbs do not normally conjugate for person.

Why: Past lexical verbs. [[Danish#^da-Q0534|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20gik%20for%20langt.)
^da-Q0534-answer

**da-Q0535** — Den stakkels ælling vidste hverken, hvor den turde stå eller gå, den var så bedrøvet, fordi den så så styg ud og var til spot for hele andegården.

The poor duckling did not know where to go, and was quite miserable because he was so ugly and laughed at by the whole farmyard.

Expected form: **vidste**

Why: Past lexical verbs. [[Danish#^da-Q0535|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Den%20stakkels%20%C3%A6lling%20vidste%20hverken%2C%20hvor%20den%20turde%20st%C3%A5%20eller%20g%C3%A5%2C%20den%20var%20s%C3%A5%20bedr%C3%B8vet%2C%20fordi%20den%20s%C3%A5%20s%C3%A5%20styg%20ud%20og%20var%20til%20spot%20for%20hele%20andeg%C3%A5rden.)
^da-Q0535-answer

**da-Q0536** — Den stakkels ælling vidste hverken, hvor den turde stå eller gå, den var så bedrøvet, fordi den så så styg ud og var til spot for hele andegården.

The poor duckling did not know where to go, and was quite miserable because he was so ugly and laughed at by the whole farmyard.

Expected form: **vidste**

Why: Past lexical verbs. [[Danish#^da-Q0536|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Den%20stakkels%20%C3%A6lling%20vidste%20hverken%2C%20hvor%20den%20turde%20st%C3%A5%20eller%20g%C3%A5%2C%20den%20var%20s%C3%A5%20bedr%C3%B8vet%2C%20fordi%20den%20s%C3%A5%20s%C3%A5%20styg%20ud%20og%20var%20til%20spot%20for%20hele%20andeg%C3%A5rden.)
^da-Q0536-answer

**da-Q0537** — Mario er så syg at han knap nok kan bevæge sig.

Mario is so sick that he can barely move.

Expected form: **så**

Why: Past lexical verbs. [[Danish#^da-Q0537|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Mario%20er%20s%C3%A5%20syg%20at%20han%20knap%20nok%20kan%20bev%C3%A6ge%20sig.)
^da-Q0537-answer

**da-Q0538** — Mario er så syg at han knap nok kan bevæge sig.

Mario is so sick that he can barely move.

Why: Past lexical verbs. [[Danish#^da-Q0538|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Mario%20er%20s%C3%A5%20syg%20at%20han%20knap%20nok%20kan%20bev%C3%A6ge%20sig.)
^da-Q0538-answer

**da-Q0539** — Hvorfor er du så ængstelig?

Why are you so troubled?

Why: Past lexical verbs. [[Danish#^da-Q0539|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hvorfor%20er%20du%20s%C3%A5%20%C3%A6ngstelig%3F)
^da-Q0539-answer

**da-Q0540** — Hvorfor er du så ængstelig?

Why are you so troubled?

Common strong verbs have irregular past forms. Practice the subject and time frame with the form; Danish verbs do not normally conjugate for person.

Why: Past lexical verbs. [[Danish#^da-Q0540|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hvorfor%20er%20du%20s%C3%A5%20%C3%A6ngstelig%3F)
^da-Q0540-answer

**da-Q0541** — Du er ikke så ung som Tom.

You're not as young as Tom.

Expected form: **så**

Why: Past lexical verbs. [[Danish#^da-Q0541|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Du%20er%20ikke%20s%C3%A5%20ung%20som%20Tom.)
^da-Q0541-answer

**da-Q0542** — Du er ikke så ung som Tom.

You're not as young as Tom.

Expected form: **så**

Why: Past lexical verbs. [[Danish#^da-Q0542|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Du%20er%20ikke%20s%C3%A5%20ung%20som%20Tom.)
^da-Q0542-answer

**da-Q0543** — Som I alle sandsynligvis ved, så er jeg Maria.

As all of you probably know, I'm Maria.

Expected form: **så**

Why: Past lexical verbs. [[Danish#^da-Q0543|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Som%20I%20alle%20sandsynligvis%20ved%2C%20s%C3%A5%20er%20jeg%20Maria.)
^da-Q0543-answer

**da-Q0544** — Som I alle sandsynligvis ved, så er jeg Maria.

As all of you probably know, I'm Maria.

Why: Past lexical verbs. [[Danish#^da-Q0544|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Som%20I%20alle%20sandsynligvis%20ved%2C%20s%C3%A5%20er%20jeg%20Maria.)
^da-Q0544-answer

**da-Q0545** — Dette brev kom mens du var ude.

This letter arrived while you were out.

Why: Past lexical verbs. [[Danish#^da-Q0545|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Dette%20brev%20kom%20mens%20du%20var%20ude.)
^da-Q0545-answer

**da-Q0546** — Dette brev kom mens du var ude.

This letter arrived while you were out.

Common strong verbs have irregular past forms. Practice the subject and time frame with the form; Danish verbs do not normally conjugate for person.

Why: Past lexical verbs. [[Danish#^da-Q0546|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Dette%20brev%20kom%20mens%20du%20var%20ude.)
^da-Q0546-answer

**da-Q0547** — Jeg vidste ikke du kunne lide Mary.

I didn't know you liked Mary.

Expected form: **vidste**

Why: Past lexical verbs. [[Danish#^da-Q0547|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20vidste%20ikke%20du%20kunne%20lide%20Mary.)
^da-Q0547-answer

**da-Q0548** — Jeg vidste ikke du kunne lide Mary.

I didn't know you liked Mary.

Expected form: **vidste**

Why: Past lexical verbs. [[Danish#^da-Q0548|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20vidste%20ikke%20du%20kunne%20lide%20Mary.)
^da-Q0548-answer

**da-Q0549** — Jeg havde indtryk af at Tom ikke vidste hvad der foregik.

I had the impression that Tom didn't know what was going on.

Expected form: **vidste**

Why: Past lexical verbs. [[Danish#^da-Q0549|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20havde%20indtryk%20af%20at%20Tom%20ikke%20vidste%20hvad%20der%20foregik.)
^da-Q0549-answer

**da-Q0550** — Jeg havde indtryk af at Tom ikke vidste hvad der foregik.

I had the impression that Tom didn't know what was going on.

Why: Past lexical verbs. [[Danish#^da-Q0550|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20havde%20indtryk%20af%20at%20Tom%20ikke%20vidste%20hvad%20der%20foregik.)
^da-Q0550-answer


### Answers 551–600

**da-Q0551** — Jeg trænger til en ny cykel.

I need a new bicycle.

Why: Adjective agreement. [[Danish#^da-Q0551|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20tr%C3%A6nger%20til%20en%20ny%20cykel.)
^da-Q0551-answer

**da-Q0552** — Jeg trænger til en ny cykel.

I need a new bicycle.

Adjectives often distinguish common singular, neuter singular and plural/definite forms. Lille has irregular plural små. Predicative adjectives also show relevant agreement.

Why: Adjective agreement. [[Danish#^da-Q0552|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20tr%C3%A6nger%20til%20en%20ny%20cykel.)
^da-Q0552-answer

**da-Q0553** — Han kan virkelig godt lide at rejse.

He really likes traveling a lot.

Expected form: **godt**

Why: Adjective agreement. [[Danish#^da-Q0553|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Han%20kan%20virkelig%20godt%20lide%20at%20rejse.)
^da-Q0553-answer

**da-Q0554** — Han kan virkelig godt lide at rejse.

He really likes traveling a lot.

Expected form: **godt**

Why: Adjective agreement. [[Danish#^da-Q0554|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Han%20kan%20virkelig%20godt%20lide%20at%20rejse.)
^da-Q0554-answer

**da-Q0555** — Jeg er ikke ret god til at lave mad; derfor spiser jeg tit ude.

I'm not very good at cooking, so I eat out a lot.

Expected form: **god**

Why: Adjective agreement. [[Danish#^da-Q0555|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20er%20ikke%20ret%20god%20til%20at%20lave%20mad%3B%20derfor%20spiser%20jeg%20tit%20ude.)
^da-Q0555-answer

**da-Q0556** — Jeg er ikke ret god til at lave mad; derfor spiser jeg tit ude.

I'm not very good at cooking, so I eat out a lot.

Why: Adjective agreement. [[Danish#^da-Q0556|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20er%20ikke%20ret%20god%20til%20at%20lave%20mad%3B%20derfor%20spiser%20jeg%20tit%20ude.)
^da-Q0556-answer

**da-Q0557** — Rusland er stort.

Russia is big.

Why: Adjective agreement. [[Danish#^da-Q0557|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Rusland%20er%20stort.)
^da-Q0557-answer

**da-Q0558** — Rusland er stort.

Russia is big.

Adjectives often distinguish common singular, neuter singular and plural/definite forms. Lille has irregular plural små. Predicative adjectives also show relevant agreement.

Why: Adjective agreement. [[Danish#^da-Q0558|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Rusland%20er%20stort.)
^da-Q0558-answer

**da-Q0559** — Tom er ikke god til at synge.

Tom can't sing well.

Expected form: **god**

Why: Adjective agreement. [[Danish#^da-Q0559|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20er%20ikke%20god%20til%20at%20synge.)
^da-Q0559-answer

**da-Q0560** — Tom er ikke god til at synge.

Tom can't sing well.

Expected form: **god**

Why: Adjective agreement. [[Danish#^da-Q0560|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20er%20ikke%20god%20til%20at%20synge.)
^da-Q0560-answer

**da-Q0561** — Gører dem godt, som hade eder.

Do good to those who hate you.

Expected form: **godt**

Why: Adjective agreement. [[Danish#^da-Q0561|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=G%C3%B8rer%20dem%20godt%2C%20som%20hade%20eder.)
^da-Q0561-answer

**da-Q0562** — Gører dem godt, som hade eder.

Do good to those who hate you.

Why: Adjective agreement. [[Danish#^da-Q0562|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=G%C3%B8rer%20dem%20godt%2C%20som%20hade%20eder.)
^da-Q0562-answer

**da-Q0563** — Toms kaffe er god.

Tom's coffee is good.

Why: Adjective agreement. [[Danish#^da-Q0563|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Toms%20kaffe%20er%20god.)
^da-Q0563-answer

**da-Q0564** — Toms kaffe er god.

Tom's coffee is good.

Adjectives often distinguish common singular, neuter singular and plural/definite forms. Lille has irregular plural små. Predicative adjectives also show relevant agreement.

Why: Adjective agreement. [[Danish#^da-Q0564|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Toms%20kaffe%20er%20god.)
^da-Q0564-answer

**da-Q0565** — Min nye kollega er en robot.

My new colleague is a robot.

Expected form: **nye**

Why: Adjective agreement. [[Danish#^da-Q0565|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Min%20nye%20kollega%20er%20en%20robot.)
^da-Q0565-answer

**da-Q0566** — Min nye kollega er en robot.

My new colleague is a robot.

Expected form: **nye**

Why: Adjective agreement. [[Danish#^da-Q0566|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Min%20nye%20kollega%20er%20en%20robot.)
^da-Q0566-answer

**da-Q0567** — Tom ødelagde sin nye smartphone.

Tom broke his new smartphone.

Expected form: **nye**

Why: Adjective agreement. [[Danish#^da-Q0567|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20%C3%B8delagde%20sin%20nye%20smartphone.)
^da-Q0567-answer

**da-Q0568** — Tom ødelagde sin nye smartphone.

Tom broke his new smartphone.

Why: Adjective agreement. [[Danish#^da-Q0568|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20%C3%B8delagde%20sin%20nye%20smartphone.)
^da-Q0568-answer

**da-Q0569** — Dette tv-apparat er både stort og dyrt.

That television is both big and expensive.

Why: Adjective agreement. [[Danish#^da-Q0569|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Dette%20tv-apparat%20er%20b%C3%A5de%20stort%20og%20dyrt.)
^da-Q0569-answer

**da-Q0570** — Dette tv-apparat er både stort og dyrt.

That television is both big and expensive.

Adjectives often distinguish common singular, neuter singular and plural/definite forms. Lille has irregular plural små. Predicative adjectives also show relevant agreement.

Why: Adjective agreement. [[Danish#^da-Q0570|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Dette%20tv-apparat%20er%20b%C3%A5de%20stort%20og%20dyrt.)
^da-Q0570-answer

**da-Q0571** — Ha' en god dag, Tom!

Have a nice day, Tom.

Expected form: **god**

Why: Adjective agreement. [[Danish#^da-Q0571|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Ha%27%20en%20god%20dag%2C%20Tom%21)
^da-Q0571-answer

**da-Q0572** — Ha' en god dag, Tom!

Have a nice day, Tom.

Expected form: **god**

Why: Adjective agreement. [[Danish#^da-Q0572|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Ha%27%20en%20god%20dag%2C%20Tom%21)
^da-Q0572-answer

**da-Q0573** — I går samlede vi inden for en time næsten et halvt kilo glasskår på stranden, hvilket var ny rekord.

Yesterday we collected nearly half a kilo of pieces of broken glass on the beach within an hour, which was a record result.

Expected form: **ny**

Why: Adjective agreement. [[Danish#^da-Q0573|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=I%20g%C3%A5r%20samlede%20vi%20inden%20for%20en%20time%20n%C3%A6sten%20et%20halvt%20kilo%20glassk%C3%A5r%20p%C3%A5%20stranden%2C%20hvilket%20var%20ny%20rekord.)
^da-Q0573-answer

**da-Q0574** — I går samlede vi inden for en time næsten et halvt kilo glasskår på stranden, hvilket var ny rekord.

Yesterday we collected nearly half a kilo of pieces of broken glass on the beach within an hour, which was a record result.

Why: Adjective agreement. [[Danish#^da-Q0574|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=I%20g%C3%A5r%20samlede%20vi%20inden%20for%20en%20time%20n%C3%A6sten%20et%20halvt%20kilo%20glassk%C3%A5r%20p%C3%A5%20stranden%2C%20hvilket%20var%20ny%20rekord.)
^da-Q0574-answer

**da-Q0575** — Jeg kan godt lide at snakke med børn.

I like to talk to kids.

Why: Adjective agreement. [[Danish#^da-Q0575|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20kan%20godt%20lide%20at%20snakke%20med%20b%C3%B8rn.)
^da-Q0575-answer

**da-Q0576** — Jeg kan godt lide at snakke med børn.

I like to talk to kids.

Adjectives often distinguish common singular, neuter singular and plural/definite forms. Lille has irregular plural små. Predicative adjectives also show relevant agreement.

Why: Adjective agreement. [[Danish#^da-Q0576|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20kan%20godt%20lide%20at%20snakke%20med%20b%C3%B8rn.)
^da-Q0576-answer

**da-Q0577** — De her farver harmonerer meget godt.

These colors harmonize very well.

Expected form: **godt**

Why: Adjective agreement. [[Danish#^da-Q0577|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=De%20her%20farver%20harmonerer%20meget%20godt.)
^da-Q0577-answer

**da-Q0578** — De her farver harmonerer meget godt.

These colors harmonize very well.

Expected form: **godt**

Why: Adjective agreement. [[Danish#^da-Q0578|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=De%20her%20farver%20harmonerer%20meget%20godt.)
^da-Q0578-answer

**da-Q0579** — Hans nye job gav ham en god indtjening.

His new job brought him a handsome income.

Expected form: **nye**

Why: Adjective agreement. [[Danish#^da-Q0579|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hans%20nye%20job%20gav%20ham%20en%20god%20indtjening.)
^da-Q0579-answer

**da-Q0580** — Hans nye job gav ham en god indtjening.

His new job brought him a handsome income.

Why: Adjective agreement. [[Danish#^da-Q0580|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hans%20nye%20job%20gav%20ham%20en%20god%20indtjening.)
^da-Q0580-answer

**da-Q0581** — Tom har store hænder.

Tom has big hands.

Why: Adjective agreement. [[Danish#^da-Q0581|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20har%20store%20h%C3%A6nder.)
^da-Q0581-answer

**da-Q0582** — Tom har store hænder.

Tom has big hands.

Adjectives often distinguish common singular, neuter singular and plural/definite forms. Lille has irregular plural små. Predicative adjectives also show relevant agreement.

Why: Adjective agreement. [[Danish#^da-Q0582|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20har%20store%20h%C3%A6nder.)
^da-Q0582-answer

**da-Q0583** — Mor dig godt i Boston!

Have fun in Boston.

Expected form: **godt**

Why: Adjective agreement. [[Danish#^da-Q0583|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Mor%20dig%20godt%20i%20Boston%21)
^da-Q0583-answer

**da-Q0584** — Mor dig godt i Boston!

Have fun in Boston.

Expected form: **godt**

Why: Adjective agreement. [[Danish#^da-Q0584|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Mor%20dig%20godt%20i%20Boston%21)
^da-Q0584-answer

**da-Q0585** — Tom og Mary blev gift i en lille kirke.

Tom and Mary got married in a small church.

Expected form: **lille**

Why: Adjective agreement. [[Danish#^da-Q0585|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20og%20Mary%20blev%20gift%20i%20en%20lille%20kirke.)
^da-Q0585-answer

**da-Q0586** — Tom og Mary blev gift i en lille kirke.

Tom and Mary got married in a small church.

Why: Adjective agreement. [[Danish#^da-Q0586|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20og%20Mary%20blev%20gift%20i%20en%20lille%20kirke.)
^da-Q0586-answer

**da-Q0587** — Tom løber en stor risiko.

Tom is taking a big risk.

Why: Adjective agreement. [[Danish#^da-Q0587|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20l%C3%B8ber%20en%20stor%20risiko.)
^da-Q0587-answer

**da-Q0588** — Tom løber en stor risiko.

Tom is taking a big risk.

Adjectives often distinguish common singular, neuter singular and plural/definite forms. Lille has irregular plural små. Predicative adjectives also show relevant agreement.

Why: Adjective agreement. [[Danish#^da-Q0588|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20l%C3%B8ber%20en%20stor%20risiko.)
^da-Q0588-answer

**da-Q0589** — Kaffen kunne godt være en smule stærkere.

The coffee could be a bit stronger.

Expected form: **godt**

Why: Adjective agreement. [[Danish#^da-Q0589|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Kaffen%20kunne%20godt%20v%C3%A6re%20en%20smule%20st%C3%A6rkere.)
^da-Q0589-answer

**da-Q0590** — Kaffen kunne godt være en smule stærkere.

The coffee could be a bit stronger.

Expected form: **godt**

Why: Adjective agreement. [[Danish#^da-Q0590|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Kaffen%20kunne%20godt%20v%C3%A6re%20en%20smule%20st%C3%A6rkere.)
^da-Q0590-answer

**da-Q0591** — Han er en stor videnskabsmand.

He's a great scientist.

Expected form: **stor**

Why: Adjective agreement. [[Danish#^da-Q0591|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Han%20er%20en%20stor%20videnskabsmand.)
^da-Q0591-answer

**da-Q0592** — Han er en stor videnskabsmand.

He's a great scientist.

Why: Adjective agreement. [[Danish#^da-Q0592|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Han%20er%20en%20stor%20videnskabsmand.)
^da-Q0592-answer

**da-Q0593** — Intet nyt er godt nyt.

No news is good news.

Why: Adjective agreement. [[Danish#^da-Q0593|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Intet%20nyt%20er%20godt%20nyt.)
^da-Q0593-answer

**da-Q0594** — Intet nyt er godt nyt.

No news is good news.

Adjectives often distinguish common singular, neuter singular and plural/definite forms. Lille has irregular plural små. Predicative adjectives also show relevant agreement.

Why: Adjective agreement. [[Danish#^da-Q0594|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Intet%20nyt%20er%20godt%20nyt.)
^da-Q0594-answer

**da-Q0595** — Tom har planer om at købe en ny motorcykel.

Tom plans to buy a new motorcycle.

Expected form: **ny**

Why: Adjective agreement. [[Danish#^da-Q0595|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20har%20planer%20om%20at%20k%C3%B8be%20en%20ny%20motorcykel.)
^da-Q0595-answer

**da-Q0596** — Tom har planer om at købe en ny motorcykel.

Tom plans to buy a new motorcycle.

Expected form: **ny**

Why: Adjective agreement. [[Danish#^da-Q0596|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20har%20planer%20om%20at%20k%C3%B8be%20en%20ny%20motorcykel.)
^da-Q0596-answer

**da-Q0597** — De kommer godt ud af det med naboerne.

They're on good terms with their neighbors.

Expected form: **godt**

Why: Adjective agreement. [[Danish#^da-Q0597|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=De%20kommer%20godt%20ud%20af%20det%20med%20naboerne.)
^da-Q0597-answer

**da-Q0598** — De kommer godt ud af det med naboerne.

They're on good terms with their neighbors.

Why: Adjective agreement. [[Danish#^da-Q0598|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=De%20kommer%20godt%20ud%20af%20det%20med%20naboerne.)
^da-Q0598-answer

**da-Q0599** — Jeg havde en lille hund da jeg var lille.

I had a small dog when I was small.

Why: Adjective agreement. [[Danish#^da-Q0599|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20havde%20en%20lille%20hund%20da%20jeg%20var%20lille.)
^da-Q0599-answer

**da-Q0600** — Jeg havde en lille hund da jeg var lille.

I had a small dog when I was small.

Adjectives often distinguish common singular, neuter singular and plural/definite forms. Lille has irregular plural små. Predicative adjectives also show relevant agreement.

Why: Adjective agreement. [[Danish#^da-Q0600|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20havde%20en%20lille%20hund%20da%20jeg%20var%20lille.)
^da-Q0600-answer


### Answers 601–650

**da-Q0601** — Tom fodrer sin hund to gange om dagen.

Tom feeds his dog twice a day.

Expected form: **sin**

Why: Reflexive possession. [[Danish#^da-Q0601|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20fodrer%20sin%20hund%20to%20gange%20om%20dagen.)
^da-Q0601-answer

**da-Q0602** — Tom fodrer sin hund to gange om dagen.

Tom feeds his dog twice a day.

Expected form: **sin**

Why: Reflexive possession. [[Danish#^da-Q0602|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20fodrer%20sin%20hund%20to%20gange%20om%20dagen.)
^da-Q0602-answer

**da-Q0603** — De tændte stearinlys på deres værelse.

They lit candles in their room.

Expected form: **deres**

Why: Reflexive possession. [[Danish#^da-Q0603|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=De%20t%C3%A6ndte%20stearinlys%20p%C3%A5%20deres%20v%C3%A6relse.)
^da-Q0603-answer

**da-Q0604** — De tændte stearinlys på deres værelse.

They lit candles in their room.

Why: Reflexive possession. [[Danish#^da-Q0604|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=De%20t%C3%A6ndte%20stearinlys%20p%C3%A5%20deres%20v%C3%A6relse.)
^da-Q0604-answer

**da-Q0605** — Tom taler aldrig om sine ekser.

Tom never talks about his exes.

Why: Reflexive possession. [[Danish#^da-Q0605|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20taler%20aldrig%20om%20sine%20ekser.)
^da-Q0605-answer

**da-Q0606** — Tom taler aldrig om sine ekser.

Tom never talks about his exes.

Sin/sit/sine refers back to a third-person subject in suitable contexts. Hans/hendes can refer to somebody else. Reflexive possession does not simply mean any English his/her.

Why: Reflexive possession. [[Danish#^da-Q0606|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20taler%20aldrig%20om%20sine%20ekser.)
^da-Q0606-answer

**da-Q0607** — Han mødte sin ven medens han badede i havet.

He met his friend while bathing in the sea.

Expected form: **sin**

Why: Reflexive possession. [[Danish#^da-Q0607|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Han%20m%C3%B8dte%20sin%20ven%20medens%20han%20badede%20i%20havet.)
^da-Q0607-answer

**da-Q0608** — Han mødte sin ven medens han badede i havet.

He met his friend while bathing in the sea.

Expected form: **sin**

Why: Reflexive possession. [[Danish#^da-Q0608|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Han%20m%C3%B8dte%20sin%20ven%20medens%20han%20badede%20i%20havet.)
^da-Q0608-answer

**da-Q0609** — De ler ad ham bag hans ryg.

They laugh at him behind his back.

Expected form: **hans**

Why: Reflexive possession. [[Danish#^da-Q0609|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=De%20ler%20ad%20ham%20bag%20hans%20ryg.)
^da-Q0609-answer

**da-Q0610** — De ler ad ham bag hans ryg.

They laugh at him behind his back.

Why: Reflexive possession. [[Danish#^da-Q0610|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=De%20ler%20ad%20ham%20bag%20hans%20ryg.)
^da-Q0610-answer

**da-Q0611** — Tom er altid lidt irritabel om morgenen, før han drikker sin første kop kaffe.

Tom is always a little irritable in the morning before he drinks his first cup of coffee.

Why: Reflexive possession. [[Danish#^da-Q0611|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20er%20altid%20lidt%20irritabel%20om%20morgenen%2C%20f%C3%B8r%20han%20drikker%20sin%20f%C3%B8rste%20kop%20kaffe.)
^da-Q0611-answer

**da-Q0612** — Tom er altid lidt irritabel om morgenen, før han drikker sin første kop kaffe.

Tom is always a little irritable in the morning before he drinks his first cup of coffee.

Sin/sit/sine refers back to a third-person subject in suitable contexts. Hans/hendes can refer to somebody else. Reflexive possession does not simply mean any English his/her.

Why: Reflexive possession. [[Danish#^da-Q0612|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20er%20altid%20lidt%20irritabel%20om%20morgenen%2C%20f%C3%B8r%20han%20drikker%20sin%20f%C3%B8rste%20kop%20kaffe.)
^da-Q0612-answer

**da-Q0613** — Han besejrede sin fjende.

He defeated his enemy.

Expected form: **sin**

Why: Reflexive possession. [[Danish#^da-Q0613|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Han%20besejrede%20sin%20fjende.)
^da-Q0613-answer

**da-Q0614** — Han besejrede sin fjende.

He defeated his enemy.

Expected form: **sin**

Why: Reflexive possession. [[Danish#^da-Q0614|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Han%20besejrede%20sin%20fjende.)
^da-Q0614-answer

**da-Q0615** — Hans forældre hjalp enhver der bad om deres hjælp.

His parents helped whoever asked for their help.

Expected form: **deres**

Why: Reflexive possession. [[Danish#^da-Q0615|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hans%20for%C3%A6ldre%20hjalp%20enhver%20der%20bad%20om%20deres%20hj%C3%A6lp.)
^da-Q0615-answer

**da-Q0616** — Hans forældre hjalp enhver der bad om deres hjælp.

His parents helped whoever asked for their help.

Why: Reflexive possession. [[Danish#^da-Q0616|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hans%20for%C3%A6ldre%20hjalp%20enhver%20der%20bad%20om%20deres%20hj%C3%A6lp.)
^da-Q0616-answer

**da-Q0617** — Drengen leger med sine tinsoldater.

The boy is playing with his tin soldiers.

Why: Reflexive possession. [[Danish#^da-Q0617|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Drengen%20leger%20med%20sine%20tinsoldater.)
^da-Q0617-answer

**da-Q0618** — Drengen leger med sine tinsoldater.

The boy is playing with his tin soldiers.

Sin/sit/sine refers back to a third-person subject in suitable contexts. Hans/hendes can refer to somebody else. Reflexive possession does not simply mean any English his/her.

Why: Reflexive possession. [[Danish#^da-Q0618|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Drengen%20leger%20med%20sine%20tinsoldater.)
^da-Q0618-answer

**da-Q0619** — Skifter skildpadder deres skjolde?

Do tortoises change their shells?

Expected form: **deres**

Why: Reflexive possession. [[Danish#^da-Q0619|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Skifter%20skildpadder%20deres%20skjolde%3F)
^da-Q0619-answer

**da-Q0620** — Skifter skildpadder deres skjolde?

Do tortoises change their shells?

Expected form: **deres**

Why: Reflexive possession. [[Danish#^da-Q0620|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Skifter%20skildpadder%20deres%20skjolde%3F)
^da-Q0620-answer

**da-Q0621** — Jeg husker mandens ansigt, men har glemt hans navn.

I remember the man's face, but forgot his name.

Expected form: **hans**

Why: Reflexive possession. [[Danish#^da-Q0621|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20husker%20mandens%20ansigt%2C%20men%20har%20glemt%20hans%20navn.)
^da-Q0621-answer

**da-Q0622** — Jeg husker mandens ansigt, men har glemt hans navn.

I remember the man's face, but forgot his name.

Why: Reflexive possession. [[Danish#^da-Q0622|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20husker%20mandens%20ansigt%2C%20men%20har%20glemt%20hans%20navn.)
^da-Q0622-answer

**da-Q0623** — Han luftede sine tre hunde hver dag.

He walked his three dogs every day.

Why: Reflexive possession. [[Danish#^da-Q0623|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Han%20luftede%20sine%20tre%20hunde%20hver%20dag.)
^da-Q0623-answer

**da-Q0624** — Han luftede sine tre hunde hver dag.

He walked his three dogs every day.

Sin/sit/sine refers back to a third-person subject in suitable contexts. Hans/hendes can refer to somebody else. Reflexive possession does not simply mean any English his/her.

Why: Reflexive possession. [[Danish#^da-Q0624|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Han%20luftede%20sine%20tre%20hunde%20hver%20dag.)
^da-Q0624-answer

**da-Q0625** — Har Tom fundet sine nøgler?

Has Tom found his keys yet?

Expected form: **sine**

Why: Reflexive possession. [[Danish#^da-Q0625|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Har%20Tom%20fundet%20sine%20n%C3%B8gler%3F)
^da-Q0625-answer

**da-Q0626** — Har Tom fundet sine nøgler?

Has Tom found his keys yet?

Expected form: **sine**

Why: Reflexive possession. [[Danish#^da-Q0626|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Har%20Tom%20fundet%20sine%20n%C3%B8gler%3F)
^da-Q0626-answer

**da-Q0627** — Han reddede ham på bekostning af sit eget liv.

He saved him at the cost of his own life.

Expected form: **sit**

Why: Reflexive possession. [[Danish#^da-Q0627|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Han%20reddede%20ham%20p%C3%A5%20bekostning%20af%20sit%20eget%20liv.)
^da-Q0627-answer

**da-Q0628** — Han reddede ham på bekostning af sit eget liv.

He saved him at the cost of his own life.

Why: Reflexive possession. [[Danish#^da-Q0628|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Han%20reddede%20ham%20p%C3%A5%20bekostning%20af%20sit%20eget%20liv.)
^da-Q0628-answer

**da-Q0629** — Jeg ved ikke hvad hans virkelige intentioner er.

I don't know what his real intentions are.

Why: Reflexive possession. [[Danish#^da-Q0629|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20ved%20ikke%20hvad%20hans%20virkelige%20intentioner%20er.)
^da-Q0629-answer

**da-Q0630** — Jeg ved ikke hvad hans virkelige intentioner er.

I don't know what his real intentions are.

Sin/sit/sine refers back to a third-person subject in suitable contexts. Hans/hendes can refer to somebody else. Reflexive possession does not simply mean any English his/her.

Why: Reflexive possession. [[Danish#^da-Q0630|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20ved%20ikke%20hvad%20hans%20virkelige%20intentioner%20er.)
^da-Q0630-answer

**da-Q0631** — Tom hader sit navn.

Tom hates his name.

Expected form: **sit**

Why: Reflexive possession. [[Danish#^da-Q0631|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20hader%20sit%20navn.)
^da-Q0631-answer

**da-Q0632** — Tom hader sit navn.

Tom hates his name.

Expected form: **sit**

Why: Reflexive possession. [[Danish#^da-Q0632|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20hader%20sit%20navn.)
^da-Q0632-answer

**da-Q0633** — En knap fra hans overfrakke faldt af.

A button from his overcoat fell off.

Expected form: **hans**

Why: Reflexive possession. [[Danish#^da-Q0633|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=En%20knap%20fra%20hans%20overfrakke%20faldt%20af.)
^da-Q0633-answer

**da-Q0634** — En knap fra hans overfrakke faldt af.

A button from his overcoat fell off.

Why: Reflexive possession. [[Danish#^da-Q0634|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=En%20knap%20fra%20hans%20overfrakke%20faldt%20af.)
^da-Q0634-answer

**da-Q0635** — Tom leger med sin legetøjslastbil.

Tom is playing with his toy truck.

Why: Reflexive possession. [[Danish#^da-Q0635|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20leger%20med%20sin%20leget%C3%B8jslastbil.)
^da-Q0635-answer

**da-Q0636** — Tom leger med sin legetøjslastbil.

Tom is playing with his toy truck.

Sin/sit/sine refers back to a third-person subject in suitable contexts. Hans/hendes can refer to somebody else. Reflexive possession does not simply mean any English his/her.

Why: Reflexive possession. [[Danish#^da-Q0636|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20leger%20med%20sin%20leget%C3%B8jslastbil.)
^da-Q0636-answer

**da-Q0637** — Sammenlignet med vores hus, er hans et palads.

Compared to our house, his is a palace.

Expected form: **hans**

Why: Reflexive possession. [[Danish#^da-Q0637|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Sammenlignet%20med%20vores%20hus%2C%20er%20hans%20et%20palads.)
^da-Q0637-answer

**da-Q0638** — Sammenlignet med vores hus, er hans et palads.

Compared to our house, his is a palace.

Expected form: **hans**

Why: Reflexive possession. [[Danish#^da-Q0638|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Sammenlignet%20med%20vores%20hus%2C%20er%20hans%20et%20palads.)
^da-Q0638-answer

**da-Q0639** — Tom fortalte Mary at han ikke kunne lide hendes sans for humor.

Tom told Mary that he didn't like her sense of humor.

Expected form: **hendes**

Why: Reflexive possession. [[Danish#^da-Q0639|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20fortalte%20Mary%20at%20han%20ikke%20kunne%20lide%20hendes%20sans%20for%20humor.)
^da-Q0639-answer

**da-Q0640** — Tom fortalte Mary at han ikke kunne lide hendes sans for humor.

Tom told Mary that he didn't like her sense of humor.

Why: Reflexive possession. [[Danish#^da-Q0640|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20fortalte%20Mary%20at%20han%20ikke%20kunne%20lide%20hendes%20sans%20for%20humor.)
^da-Q0640-answer

**da-Q0641** — Hvad skal jeg stille op med hans brev?

What am I gonna do with his letter?

Why: Reflexive possession. [[Danish#^da-Q0641|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hvad%20skal%20jeg%20stille%20op%20med%20hans%20brev%3F)
^da-Q0641-answer

**da-Q0642** — Hvad skal jeg stille op med hans brev?

What am I gonna do with his letter?

Sin/sit/sine refers back to a third-person subject in suitable contexts. Hans/hendes can refer to somebody else. Reflexive possession does not simply mean any English his/her.

Why: Reflexive possession. [[Danish#^da-Q0642|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hvad%20skal%20jeg%20stille%20op%20med%20hans%20brev%3F)
^da-Q0642-answer

**da-Q0643** — Hun gik på indkøb med sin veninde.

She went shopping with her friend.

Expected form: **sin**

Why: Reflexive possession. [[Danish#^da-Q0643|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hun%20gik%20p%C3%A5%20indk%C3%B8b%20med%20sin%20veninde.)
^da-Q0643-answer

**da-Q0644** — Hun gik på indkøb med sin veninde.

She went shopping with her friend.

Expected form: **sin**

Why: Reflexive possession. [[Danish#^da-Q0644|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hun%20gik%20p%C3%A5%20indk%C3%B8b%20med%20sin%20veninde.)
^da-Q0644-answer

**da-Q0645** — Tom hadede sin fransklærer.

Tom hated his French teacher.

Expected form: **sin**

Why: Reflexive possession. [[Danish#^da-Q0645|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20hadede%20sin%20franskl%C3%A6rer.)
^da-Q0645-answer

**da-Q0646** — Tom hadede sin fransklærer.

Tom hated his French teacher.

Why: Reflexive possession. [[Danish#^da-Q0646|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20hadede%20sin%20franskl%C3%A6rer.)
^da-Q0646-answer

**da-Q0647** — Han puttede mælk i sin kaffe.

He put milk in his coffee.

Why: Reflexive possession. [[Danish#^da-Q0647|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Han%20puttede%20m%C3%A6lk%20i%20sin%20kaffe.)
^da-Q0647-answer

**da-Q0648** — Han puttede mælk i sin kaffe.

He put milk in his coffee.

Sin/sit/sine refers back to a third-person subject in suitable contexts. Hans/hendes can refer to somebody else. Reflexive possession does not simply mean any English his/her.

Why: Reflexive possession. [[Danish#^da-Q0648|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Han%20puttede%20m%C3%A6lk%20i%20sin%20kaffe.)
^da-Q0648-answer

**da-Q0649** — Han tog hendes tøj af.

He took off her clothes.

Expected form: **hendes**

Why: Reflexive possession. [[Danish#^da-Q0649|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Han%20tog%20hendes%20t%C3%B8j%20af.)
^da-Q0649-answer

**da-Q0650** — Han tog hendes tøj af.

He took off her clothes.

Expected form: **hendes**

Why: Reflexive possession. [[Danish#^da-Q0650|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Han%20tog%20hendes%20t%C3%B8j%20af.)
^da-Q0650-answer


### Answers 651–700

**da-Q0651** — Alle æblerne, der falder ned, bliver spist af grisene.

All the apples that fall are eaten by the pigs.

Expected form: **der**

Why: Relative clauses. [[Danish#^da-Q0651|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Alle%20%C3%A6blerne%2C%20der%20falder%20ned%2C%20bliver%20spist%20af%20grisene.)
^da-Q0651-answer

**da-Q0652** — Alle æblerne, der falder ned, bliver spist af grisene.

All the apples that fall are eaten by the pigs.

Why: Relative clauses. [[Danish#^da-Q0652|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Alle%20%C3%A6blerne%2C%20der%20falder%20ned%2C%20bliver%20spist%20af%20grisene.)
^da-Q0652-answer

**da-Q0653** — Alle æblerne er der.

All the apples are there.

Why: Relative clauses. [[Danish#^da-Q0653|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Alle%20%C3%A6blerne%20er%20der.)
^da-Q0653-answer

**da-Q0654** — Alle æblerne er der.

All the apples are there.

Som is a common relative marker; der can be a relative subject. Der also occurs in existence statements. Identify the role inside the relative clause.

Why: Relative clauses. [[Danish#^da-Q0654|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Alle%20%C3%A6blerne%20er%20der.)
^da-Q0654-answer

**da-Q0655** — Hun arbejder som au pair.

She works as an au pair.

Expected form: **som**

Why: Relative clauses. [[Danish#^da-Q0655|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hun%20arbejder%20som%20au%20pair.)
^da-Q0655-answer

**da-Q0656** — Hun arbejder som au pair.

She works as an au pair.

Expected form: **som**

Why: Relative clauses. [[Danish#^da-Q0656|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hun%20arbejder%20som%20au%20pair.)
^da-Q0656-answer

**da-Q0657** — Er der en bus der kører til storcentret?

Is there a bus that goes to the mall?

Expected form: **der**

Why: Relative clauses. [[Danish#^da-Q0657|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Er%20der%20en%20bus%20der%20k%C3%B8rer%20til%20storcentret%3F)
^da-Q0657-answer

**da-Q0658** — Er der en bus der kører til storcentret?

Is there a bus that goes to the mall?

Why: Relative clauses. [[Danish#^da-Q0658|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Er%20der%20en%20bus%20der%20k%C3%B8rer%20til%20storcentret%3F)
^da-Q0658-answer

**da-Q0659** — Herfra er der omkring tre kilometer til kysten.

From here, it's about three kilometers to the coast.

Why: Relative clauses. [[Danish#^da-Q0659|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Herfra%20er%20der%20omkring%20tre%20kilometer%20til%20kysten.)
^da-Q0659-answer

**da-Q0660** — Herfra er der omkring tre kilometer til kysten.

From here, it's about three kilometers to the coast.

Som is a common relative marker; der can be a relative subject. Der also occurs in existence statements. Identify the role inside the relative clause.

Why: Relative clauses. [[Danish#^da-Q0660|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Herfra%20er%20der%20omkring%20tre%20kilometer%20til%20kysten.)
^da-Q0660-answer

**da-Q0661** — Der er mange huse der er blevet ødelagt af jordskælvet.

There are many houses destroyed by the earthquake.

Expected form: **der**

Why: Relative clauses. [[Danish#^da-Q0661|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Der%20er%20mange%20huse%20der%20er%20blevet%20%C3%B8delagt%20af%20jordsk%C3%A6lvet.)
^da-Q0661-answer

**da-Q0662** — Der er mange huse der er blevet ødelagt af jordskælvet.

There are many houses destroyed by the earthquake.

Expected form: **der**

Why: Relative clauses. [[Danish#^da-Q0662|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Der%20er%20mange%20huse%20der%20er%20blevet%20%C3%B8delagt%20af%20jordsk%C3%A6lvet.)
^da-Q0662-answer

**da-Q0663** — De behandler mig som et barn.

They are treating me like a child.

Expected form: **som**

Why: Relative clauses. [[Danish#^da-Q0663|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=De%20behandler%20mig%20som%20et%20barn.)
^da-Q0663-answer

**da-Q0664** — De behandler mig som et barn.

They are treating me like a child.

Why: Relative clauses. [[Danish#^da-Q0664|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=De%20behandler%20mig%20som%20et%20barn.)
^da-Q0664-answer

**da-Q0665** — Tom var den eneste som blev såret.

Tom was the only one who got hurt.

Why: Relative clauses. [[Danish#^da-Q0665|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20var%20den%20eneste%20som%20blev%20s%C3%A5ret.)
^da-Q0665-answer

**da-Q0666** — Tom var den eneste som blev såret.

Tom was the only one who got hurt.

Som is a common relative marker; der can be a relative subject. Der also occurs in existence statements. Identify the role inside the relative clause.

Why: Relative clauses. [[Danish#^da-Q0666|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20var%20den%20eneste%20som%20blev%20s%C3%A5ret.)
^da-Q0666-answer

**da-Q0667** — Han er ikke en mand der spilder tiden.

He's not a man to waste time.

Expected form: **der**

Why: Relative clauses. [[Danish#^da-Q0667|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Han%20er%20ikke%20en%20mand%20der%20spilder%20tiden.)
^da-Q0667-answer

**da-Q0668** — Han er ikke en mand der spilder tiden.

He's not a man to waste time.

Expected form: **der**

Why: Relative clauses. [[Danish#^da-Q0668|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Han%20er%20ikke%20en%20mand%20der%20spilder%20tiden.)
^da-Q0668-answer

**da-Q0669** — Hvad sker der, Sarah?

What's going on, Sarah?

Expected form: **der**

Why: Relative clauses. [[Danish#^da-Q0669|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hvad%20sker%20der%2C%20Sarah%3F)
^da-Q0669-answer

**da-Q0670** — Hvad sker der, Sarah?

What's going on, Sarah?

Why: Relative clauses. [[Danish#^da-Q0670|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hvad%20sker%20der%2C%20Sarah%3F)
^da-Q0670-answer

**da-Q0671** — Træet, der er i haven, er en gammel eg.

The tree that is in the garden is an ancient oak.

Why: Relative clauses. [[Danish#^da-Q0671|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tr%C3%A6et%2C%20der%20er%20i%20haven%2C%20er%20en%20gammel%20eg.)
^da-Q0671-answer

**da-Q0672** — Træet, der er i haven, er en gammel eg.

The tree that is in the garden is an ancient oak.

Som is a common relative marker; der can be a relative subject. Der also occurs in existence statements. Identify the role inside the relative clause.

Why: Relative clauses. [[Danish#^da-Q0672|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tr%C3%A6et%2C%20der%20er%20i%20haven%2C%20er%20en%20gammel%20eg.)
^da-Q0672-answer

**da-Q0673** — Det er den kvinde som jeg er forelsket i.

That's the woman I'm in love with.

Expected form: **som**

Why: Relative clauses. [[Danish#^da-Q0673|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Det%20er%20den%20kvinde%20som%20jeg%20er%20forelsket%20i.)
^da-Q0673-answer

**da-Q0674** — Det er den kvinde som jeg er forelsket i.

That's the woman I'm in love with.

Expected form: **som**

Why: Relative clauses. [[Danish#^da-Q0674|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Det%20er%20den%20kvinde%20som%20jeg%20er%20forelsket%20i.)
^da-Q0674-answer

**da-Q0675** — Hunde der gør, bider sjældent.

Barking dogs seldom bite.

Expected form: **der**

Why: Relative clauses. [[Danish#^da-Q0675|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hunde%20der%20g%C3%B8r%2C%20bider%20sj%C3%A6ldent.)
^da-Q0675-answer

**da-Q0676** — Hunde der gør, bider sjældent.

Barking dogs seldom bite.

Why: Relative clauses. [[Danish#^da-Q0676|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hunde%20der%20g%C3%B8r%2C%20bider%20sj%C3%A6ldent.)
^da-Q0676-answer

**da-Q0677** — I værelset er der fire møbler.

There are four pieces of furniture in the room.

Why: Relative clauses. [[Danish#^da-Q0677|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=I%20v%C3%A6relset%20er%20der%20fire%20m%C3%B8bler.)
^da-Q0677-answer

**da-Q0678** — I værelset er der fire møbler.

There are four pieces of furniture in the room.

Som is a common relative marker; der can be a relative subject. Der also occurs in existence statements. Identify the role inside the relative clause.

Why: Relative clauses. [[Danish#^da-Q0678|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=I%20v%C3%A6relset%20er%20der%20fire%20m%C3%B8bler.)
^da-Q0678-answer

**da-Q0679** — Tom, der er noget, jeg glemte at fortælle dig.

Tom, there's something I forgot to tell you.

Expected form: **der**

Why: Relative clauses. [[Danish#^da-Q0679|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%2C%20der%20er%20noget%2C%20jeg%20glemte%20at%20fort%C3%A6lle%20dig.)
^da-Q0679-answer

**da-Q0680** — Tom, der er noget, jeg glemte at fortælle dig.

Tom, there's something I forgot to tell you.

Expected form: **der**

Why: Relative clauses. [[Danish#^da-Q0680|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%2C%20der%20er%20noget%2C%20jeg%20glemte%20at%20fort%C3%A6lle%20dig.)
^da-Q0680-answer

**da-Q0681** — Jeg er bange for at krydse gaden i Beijing da bilisterne der ikke tager hensyn til fodgængerne.

I'm afraid to cross the street in Beijing since drivers don't respect pedestrians there.

Expected form: **der**

Why: Relative clauses. [[Danish#^da-Q0681|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20er%20bange%20for%20at%20krydse%20gaden%20i%20Beijing%20da%20bilisterne%20der%20ikke%20tager%20hensyn%20til%20fodg%C3%A6ngerne.)
^da-Q0681-answer

**da-Q0682** — Jeg er bange for at krydse gaden i Beijing da bilisterne der ikke tager hensyn til fodgængerne.

I'm afraid to cross the street in Beijing since drivers don't respect pedestrians there.

Why: Relative clauses. [[Danish#^da-Q0682|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20er%20bange%20for%20at%20krydse%20gaden%20i%20Beijing%20da%20bilisterne%20der%20ikke%20tager%20hensyn%20til%20fodg%C3%A6ngerne.)
^da-Q0682-answer

**da-Q0683** — Er der andet du er allergisk over for?

Are you allergic to anything else?

Why: Relative clauses. [[Danish#^da-Q0683|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Er%20der%20andet%20du%20er%20allergisk%20over%20for%3F)
^da-Q0683-answer

**da-Q0684** — Er der andet du er allergisk over for?

Are you allergic to anything else?

Som is a common relative marker; der can be a relative subject. Der also occurs in existence statements. Identify the role inside the relative clause.

Why: Relative clauses. [[Danish#^da-Q0684|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Er%20der%20andet%20du%20er%20allergisk%20over%20for%3F)
^da-Q0684-answer

**da-Q0685** — Jeg boede der i fem år.

I lived there for five years.

Expected form: **der**

Why: Relative clauses. [[Danish#^da-Q0685|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20boede%20der%20i%20fem%20%C3%A5r.)
^da-Q0685-answer

**da-Q0686** — Jeg boede der i fem år.

I lived there for five years.

Expected form: **der**

Why: Relative clauses. [[Danish#^da-Q0686|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20boede%20der%20i%20fem%20%C3%A5r.)
^da-Q0686-answer

**da-Q0687** — Hvad skal der blive af os?

What is going to become of us?

Expected form: **der**

Why: Relative clauses. [[Danish#^da-Q0687|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hvad%20skal%20der%20blive%20af%20os%3F)
^da-Q0687-answer

**da-Q0688** — Hvad skal der blive af os?

What is going to become of us?

Why: Relative clauses. [[Danish#^da-Q0688|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hvad%20skal%20der%20blive%20af%20os%3F)
^da-Q0688-answer

**da-Q0689** — Tom har en hund som hedder Cookie.

Tom has a dog named Cookie.

Why: Relative clauses. [[Danish#^da-Q0689|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20har%20en%20hund%20som%20hedder%20Cookie.)
^da-Q0689-answer

**da-Q0690** — Tom har en hund som hedder Cookie.

Tom has a dog named Cookie.

Som is a common relative marker; der can be a relative subject. Der also occurs in existence statements. Identify the role inside the relative clause.

Why: Relative clauses. [[Danish#^da-Q0690|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20har%20en%20hund%20som%20hedder%20Cookie.)
^da-Q0690-answer

**da-Q0691** — Han behandler mig altid som et barn.

He always treats me like a child.

Expected form: **som**

Why: Relative clauses. [[Danish#^da-Q0691|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Han%20behandler%20mig%20altid%20som%20et%20barn.)
^da-Q0691-answer

**da-Q0692** — Han behandler mig altid som et barn.

He always treats me like a child.

Expected form: **som**

Why: Relative clauses. [[Danish#^da-Q0692|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Han%20behandler%20mig%20altid%20som%20et%20barn.)
^da-Q0692-answer

**da-Q0693** — Det var hende der anmodede om skilsmissen.

She was the one who demanded the divorce.

Expected form: **der**

Why: Relative clauses. [[Danish#^da-Q0693|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Det%20var%20hende%20der%20anmodede%20om%20skilsmissen.)
^da-Q0693-answer

**da-Q0694** — Det var hende der anmodede om skilsmissen.

She was the one who demanded the divorce.

Why: Relative clauses. [[Danish#^da-Q0694|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Det%20var%20hende%20der%20anmodede%20om%20skilsmissen.)
^da-Q0694-answer

**da-Q0695** — Der er ingen hunde der er større end denne her.

There are no dogs bigger than this one.

Why: Relative clauses. [[Danish#^da-Q0695|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Der%20er%20ingen%20hunde%20der%20er%20st%C3%B8rre%20end%20denne%20her.)
^da-Q0695-answer

**da-Q0696** — Der er ingen hunde der er større end denne her.

There are no dogs bigger than this one.

Som is a common relative marker; der can be a relative subject. Der also occurs in existence statements. Identify the role inside the relative clause.

Why: Relative clauses. [[Danish#^da-Q0696|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Der%20er%20ingen%20hunde%20der%20er%20st%C3%B8rre%20end%20denne%20her.)
^da-Q0696-answer

**da-Q0697** — Af og til går tingene ikke som planlagt.

Occasionally, things don't go as planned.

Expected form: **som**

Why: Relative clauses. [[Danish#^da-Q0697|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Af%20og%20til%20g%C3%A5r%20tingene%20ikke%20som%20planlagt.)
^da-Q0697-answer

**da-Q0698** — Af og til går tingene ikke som planlagt.

Occasionally, things don't go as planned.

Expected form: **som**

Why: Relative clauses. [[Danish#^da-Q0698|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Af%20og%20til%20g%C3%A5r%20tingene%20ikke%20som%20planlagt.)
^da-Q0698-answer

**da-Q0699** — Jeg sigter på den and der.

I am aiming at that duck.

Expected form: **der**

Why: Relative clauses. [[Danish#^da-Q0699|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20sigter%20p%C3%A5%20den%20and%20der.)
^da-Q0699-answer

**da-Q0700** — Jeg sigter på den and der.

I am aiming at that duck.

Why: Relative clauses. [[Danish#^da-Q0700|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20sigter%20p%C3%A5%20den%20and%20der.)
^da-Q0700-answer


### Answers 701–750

**da-Q0701** — Tom boede her hos os i tre måneder.

Tom lived here with us for three months.

Why: Existence and place. [[Danish#^da-Q0701|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20boede%20her%20hos%20os%20i%20tre%20m%C3%A5neder.)
^da-Q0701-answer

**da-Q0702** — Tom boede her hos os i tre måneder.

Tom lived here with us for three months.

Der can mean there or support an existential construction. Her means here. A grammatical existence marker and a stressed location are not always interchangeable.

Why: Existence and place. [[Danish#^da-Q0702|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20boede%20her%20hos%20os%20i%20tre%20m%C3%A5neder.)
^da-Q0702-answer

**da-Q0703** — Jeg græder altid, når jeg ser det her billede.

I always cry when I see this picture.

Expected form: **her**

Why: Existence and place. [[Danish#^da-Q0703|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20gr%C3%A6der%20altid%2C%20n%C3%A5r%20jeg%20ser%20det%20her%20billede.)
^da-Q0703-answer

**da-Q0704** — Jeg græder altid, når jeg ser det her billede.

I always cry when I see this picture.

Expected form: **her**

Why: Existence and place. [[Danish#^da-Q0704|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20gr%C3%A6der%20altid%2C%20n%C3%A5r%20jeg%20ser%20det%20her%20billede.)
^da-Q0704-answer

**da-Q0705** — Der bor mange rige mennesker i det her kvarter.

Many rich people live in this neighborhood.

Expected form: **her**

Why: Existence and place. [[Danish#^da-Q0705|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Der%20bor%20mange%20rige%20mennesker%20i%20det%20her%20kvarter.)
^da-Q0705-answer

**da-Q0706** — Der bor mange rige mennesker i det her kvarter.

Many rich people live in this neighborhood.

Why: Existence and place. [[Danish#^da-Q0706|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Der%20bor%20mange%20rige%20mennesker%20i%20det%20her%20kvarter.)
^da-Q0706-answer

**da-Q0707** — Jeg har boet her siden jeg var dreng.

I have lived here since I was a boy.

Why: Existence and place. [[Danish#^da-Q0707|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20har%20boet%20her%20siden%20jeg%20var%20dreng.)
^da-Q0707-answer

**da-Q0708** — Jeg har boet her siden jeg var dreng.

I have lived here since I was a boy.

Der can mean there or support an existential construction. Her means here. A grammatical existence marker and a stressed location are not always interchangeable.

Why: Existence and place. [[Danish#^da-Q0708|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20har%20boet%20her%20siden%20jeg%20var%20dreng.)
^da-Q0708-answer

**da-Q0709** — Kan nogen her tale fransk?

Can anyone here speak French?

Expected form: **her**

Why: Existence and place. [[Danish#^da-Q0709|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Kan%20nogen%20her%20tale%20fransk%3F)
^da-Q0709-answer

**da-Q0710** — Kan nogen her tale fransk?

Can anyone here speak French?

Expected form: **her**

Why: Existence and place. [[Danish#^da-Q0710|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Kan%20nogen%20her%20tale%20fransk%3F)
^da-Q0710-answer

**da-Q0711** — Jeg er led og ked af at arbejde her.

I'm fed up with working here.

Expected form: **her**

Why: Existence and place. [[Danish#^da-Q0711|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20er%20led%20og%20ked%20af%20at%20arbejde%20her.)
^da-Q0711-answer

**da-Q0712** — Jeg er led og ked af at arbejde her.

I'm fed up with working here.

Why: Existence and place. [[Danish#^da-Q0712|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20er%20led%20og%20ked%20af%20at%20arbejde%20her.)
^da-Q0712-answer

**da-Q0713** — Jeg er der straks.

I'll be right there.

Why: Existence and place. [[Danish#^da-Q0713|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20er%20der%20straks.)
^da-Q0713-answer

**da-Q0714** — Jeg er der straks.

I'll be right there.

Der can mean there or support an existential construction. Her means here. A grammatical existence marker and a stressed location are not always interchangeable.

Why: Existence and place. [[Danish#^da-Q0714|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20er%20der%20straks.)
^da-Q0714-answer

**da-Q0715** — Vi er her hele dagen.

We're here for the day.

Expected form: **her**

Why: Existence and place. [[Danish#^da-Q0715|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Vi%20er%20her%20hele%20dagen.)
^da-Q0715-answer

**da-Q0716** — Vi er her hele dagen.

We're here for the day.

Expected form: **her**

Why: Existence and place. [[Danish#^da-Q0716|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Vi%20er%20her%20hele%20dagen.)
^da-Q0716-answer

**da-Q0717** — Tom er her for at købe nogle æbler.

Tom is here to buy some apples.

Expected form: **her**

Why: Existence and place. [[Danish#^da-Q0717|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20er%20her%20for%20at%20k%C3%B8be%20nogle%20%C3%A6bler.)
^da-Q0717-answer

**da-Q0718** — Tom er her for at købe nogle æbler.

Tom is here to buy some apples.

Why: Existence and place. [[Danish#^da-Q0718|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20er%20her%20for%20at%20k%C3%B8be%20nogle%20%C3%A6bler.)
^da-Q0718-answer

**da-Q0719** — Der bor flere ældre i Canada end der bor børn.

There are more seniors living in Canada than children.

Why: Existence and place. [[Danish#^da-Q0719|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Der%20bor%20flere%20%C3%A6ldre%20i%20Canada%20end%20der%20bor%20b%C3%B8rn.)
^da-Q0719-answer

**da-Q0720** — Der bor flere ældre i Canada end der bor børn.

There are more seniors living in Canada than children.

Der can mean there or support an existential construction. Her means here. A grammatical existence marker and a stressed location are not always interchangeable.

Why: Existence and place. [[Danish#^da-Q0720|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Der%20bor%20flere%20%C3%A6ldre%20i%20Canada%20end%20der%20bor%20b%C3%B8rn.)
^da-Q0720-answer

**da-Q0721** — Har du noget der er billigere?

Do you have anything cheaper?

Expected form: **der**

Why: Existence and place. [[Danish#^da-Q0721|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Har%20du%20noget%20der%20er%20billigere%3F)
^da-Q0721-answer

**da-Q0722** — Har du noget der er billigere?

Do you have anything cheaper?

Expected form: **der**

Why: Existence and place. [[Danish#^da-Q0722|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Har%20du%20noget%20der%20er%20billigere%3F)
^da-Q0722-answer

**da-Q0723** — Jeg var her hele eftermiddagen.

I was here all afternoon.

Expected form: **her**

Why: Existence and place. [[Danish#^da-Q0723|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20var%20her%20hele%20eftermiddagen.)
^da-Q0723-answer

**da-Q0724** — Jeg var her hele eftermiddagen.

I was here all afternoon.

Why: Existence and place. [[Danish#^da-Q0724|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20var%20her%20hele%20eftermiddagen.)
^da-Q0724-answer

**da-Q0725** — Hvad er der galt?

What's wrong?

Why: Existence and place. [[Danish#^da-Q0725|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hvad%20er%20der%20galt%3F)
^da-Q0725-answer

**da-Q0726** — Hvad er der galt?

What's wrong?

Der can mean there or support an existential construction. Her means here. A grammatical existence marker and a stressed location are not always interchangeable.

Why: Existence and place. [[Danish#^da-Q0726|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hvad%20er%20der%20galt%3F)
^da-Q0726-answer

**da-Q0727** — Jeg bliver måske her indtil mandag.

I may stay here until Monday.

Expected form: **her**

Why: Existence and place. [[Danish#^da-Q0727|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20bliver%20m%C3%A5ske%20her%20indtil%20mandag.)
^da-Q0727-answer

**da-Q0728** — Jeg bliver måske her indtil mandag.

I may stay here until Monday.

Expected form: **her**

Why: Existence and place. [[Danish#^da-Q0728|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20bliver%20m%C3%A5ske%20her%20indtil%20mandag.)
^da-Q0728-answer

**da-Q0729** — Hvad er det der virkelig foregår?

What's really going on?

Expected form: **der**

Why: Existence and place. [[Danish#^da-Q0729|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hvad%20er%20det%20der%20virkelig%20foreg%C3%A5r%3F)
^da-Q0729-answer

**da-Q0730** — Hvad er det der virkelig foregår?

What's really going on?

Why: Existence and place. [[Danish#^da-Q0730|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hvad%20er%20det%20der%20virkelig%20foreg%C3%A5r%3F)
^da-Q0730-answer

**da-Q0731** — "Ved du noget om Bill?" "Nej, hvad skete der med ham?"

"Do you know anything about Bill?" "No, what happened to him?"

Why: Existence and place. [[Danish#^da-Q0731|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=%22Ved%20du%20noget%20om%20Bill%3F%22%20%22Nej%2C%20hvad%20skete%20der%20med%20ham%3F%22)
^da-Q0731-answer

**da-Q0732** — "Ved du noget om Bill?" "Nej, hvad skete der med ham?"

"Do you know anything about Bill?" "No, what happened to him?"

Der can mean there or support an existential construction. Her means here. A grammatical existence marker and a stressed location are not always interchangeable.

Why: Existence and place. [[Danish#^da-Q0732|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=%22Ved%20du%20noget%20om%20Bill%3F%22%20%22Nej%2C%20hvad%20skete%20der%20med%20ham%3F%22)
^da-Q0732-answer

**da-Q0733** — På begge sider af vejen er der kirsebærtræer.

On both sides of the road there are cherry trees.

Expected form: **der**

Why: Existence and place. [[Danish#^da-Q0733|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=P%C3%A5%20begge%20sider%20af%20vejen%20er%20der%20kirseb%C3%A6rtr%C3%A6er.)
^da-Q0733-answer

**da-Q0734** — På begge sider af vejen er der kirsebærtræer.

On both sides of the road there are cherry trees.

Expected form: **der**

Why: Existence and place. [[Danish#^da-Q0734|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=P%C3%A5%20begge%20sider%20af%20vejen%20er%20der%20kirseb%C3%A6rtr%C3%A6er.)
^da-Q0734-answer

**da-Q0735** — Der er noget her, der ikke stemmer.

There's something here that doesn't add up.

Expected form: **her**

Why: Existence and place. [[Danish#^da-Q0735|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Der%20er%20noget%20her%2C%20der%20ikke%20stemmer.)
^da-Q0735-answer

**da-Q0736** — Der er noget her, der ikke stemmer.

There's something here that doesn't add up.

Why: Existence and place. [[Danish#^da-Q0736|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Der%20er%20noget%20her%2C%20der%20ikke%20stemmer.)
^da-Q0736-answer

**da-Q0737** — Tom kan ikke lide kvinder, der har alt for meget makeup på.

Tom doesn't like women who wear way too much makeup.

Why: Existence and place. [[Danish#^da-Q0737|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20kan%20ikke%20lide%20kvinder%2C%20der%20har%20alt%20for%20meget%20makeup%20p%C3%A5.)
^da-Q0737-answer

**da-Q0738** — Tom kan ikke lide kvinder, der har alt for meget makeup på.

Tom doesn't like women who wear way too much makeup.

Der can mean there or support an existential construction. Her means here. A grammatical existence marker and a stressed location are not always interchangeable.

Why: Existence and place. [[Danish#^da-Q0738|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20kan%20ikke%20lide%20kvinder%2C%20der%20har%20alt%20for%20meget%20makeup%20p%C3%A5.)
^da-Q0738-answer

**da-Q0739** — Tom tilgang til sprogindlæring er at smide alt op på væggen og se hvad der hænger ved.

Tom's strategy for language learning is to throw everything against the wall and see what sticks.

Expected form: **der**

Why: Existence and place. [[Danish#^da-Q0739|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20tilgang%20til%20sprogindl%C3%A6ring%20er%20at%20smide%20alt%20op%20p%C3%A5%20v%C3%A6ggen%20og%20se%20hvad%20der%20h%C3%A6nger%20ved.)
^da-Q0739-answer

**da-Q0740** — Tom tilgang til sprogindlæring er at smide alt op på væggen og se hvad der hænger ved.

Tom's strategy for language learning is to throw everything against the wall and see what sticks.

Expected form: **der**

Why: Existence and place. [[Danish#^da-Q0740|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20tilgang%20til%20sprogindl%C3%A6ring%20er%20at%20smide%20alt%20op%20p%C3%A5%20v%C3%A6ggen%20og%20se%20hvad%20der%20h%C3%A6nger%20ved.)
^da-Q0740-answer

**da-Q0741** — Er den her en hingst eller en hoppe?

Is this a stallion or a mare?

Expected form: **her**

Why: Existence and place. [[Danish#^da-Q0741|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Er%20den%20her%20en%20hingst%20eller%20en%20hoppe%3F)
^da-Q0741-answer

**da-Q0742** — Er den her en hingst eller en hoppe?

Is this a stallion or a mare?

Why: Existence and place. [[Danish#^da-Q0742|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Er%20den%20her%20en%20hingst%20eller%20en%20hoppe%3F)
^da-Q0742-answer

**da-Q0743** — Mennesket er det eneste dyr der gør brug af ild.

Man is the only animal that uses fire.

Why: Existence and place. [[Danish#^da-Q0743|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Mennesket%20er%20det%20eneste%20dyr%20der%20g%C3%B8r%20brug%20af%20ild.)
^da-Q0743-answer

**da-Q0744** — Mennesket er det eneste dyr der gør brug af ild.

Man is the only animal that uses fire.

Der can mean there or support an existential construction. Her means here. A grammatical existence marker and a stressed location are not always interchangeable.

Why: Existence and place. [[Danish#^da-Q0744|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Mennesket%20er%20det%20eneste%20dyr%20der%20g%C3%B8r%20brug%20af%20ild.)
^da-Q0744-answer

**da-Q0745** — Denne ordbog er bedre end den der.

This dictionary is better than that one.

Expected form: **der**

Why: Existence and place. [[Danish#^da-Q0745|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Denne%20ordbog%20er%20bedre%20end%20den%20der.)
^da-Q0745-answer

**da-Q0746** — Denne ordbog er bedre end den der.

This dictionary is better than that one.

Expected form: **der**

Why: Existence and place. [[Danish#^da-Q0746|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Denne%20ordbog%20er%20bedre%20end%20den%20der.)
^da-Q0746-answer

**da-Q0747** — Jeg leder efter en læbestift der passer til denne neglelak.

I'm looking for a lipstick to go with this nail polish.

Expected form: **der**

Why: Existence and place. [[Danish#^da-Q0747|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20leder%20efter%20en%20l%C3%A6bestift%20der%20passer%20til%20denne%20neglelak.)
^da-Q0747-answer

**da-Q0748** — Jeg leder efter en læbestift der passer til denne neglelak.

I'm looking for a lipstick to go with this nail polish.

Why: Existence and place. [[Danish#^da-Q0748|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20leder%20efter%20en%20l%C3%A6bestift%20der%20passer%20til%20denne%20neglelak.)
^da-Q0748-answer

**da-Q0749** — Mange lande har lavet love der forbyder rygning på offentlige steder.

Many countries have passed laws to prohibit people from smoking in public places.

Why: Existence and place. [[Danish#^da-Q0749|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Mange%20lande%20har%20lavet%20love%20der%20forbyder%20rygning%20p%C3%A5%20offentlige%20steder.)
^da-Q0749-answer

**da-Q0750** — Mange lande har lavet love der forbyder rygning på offentlige steder.

Many countries have passed laws to prohibit people from smoking in public places.

Der can mean there or support an existential construction. Her means here. A grammatical existence marker and a stressed location are not always interchangeable.

Why: Existence and place. [[Danish#^da-Q0750|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Mange%20lande%20har%20lavet%20love%20der%20forbyder%20rygning%20p%C3%A5%20offentlige%20steder.)
^da-Q0750-answer


### Answers 751–800

**da-Q0751** — Oh, hvor træet bævede!

Oh, how the Tree trembled!

Expected form: **hvor**

Why: Questions. [[Danish#^da-Q0751|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Oh%2C%20hvor%20tr%C3%A6et%20b%C3%A6vede%21)
^da-Q0751-answer

**da-Q0752** — Oh, hvor træet bævede!

Oh, how the Tree trembled!

Expected form: **hvor**

Why: Questions. [[Danish#^da-Q0752|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Oh%2C%20hvor%20tr%C3%A6et%20b%C3%A6vede%21)
^da-Q0752-answer

**da-Q0753** — Kan du fortælle mig, hvordan man justerer lydstyrken?

Could you tell me how to adjust the volume?

Expected form: **hvordan**

Why: Questions. [[Danish#^da-Q0753|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Kan%20du%20fort%C3%A6lle%20mig%2C%20hvordan%20man%20justerer%20lydstyrken%3F)
^da-Q0753-answer

**da-Q0754** — Kan du fortælle mig, hvordan man justerer lydstyrken?

Could you tell me how to adjust the volume?

Why: Questions. [[Danish#^da-Q0754|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Kan%20du%20fort%C3%A6lle%20mig%2C%20hvordan%20man%20justerer%20lydstyrken%3F)
^da-Q0754-answer

**da-Q0755** — Og hvor kommer pengene fra?

And where is the money coming from?

Why: Questions. [[Danish#^da-Q0755|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Og%20hvor%20kommer%20pengene%20fra%3F)
^da-Q0755-answer

**da-Q0756** — Og hvor kommer pengene fra?

And where is the money coming from?

Direct questions often place the finite verb before the subject. An indirect question takes subordinate order. A question word specifies the information requested.

Why: Questions. [[Danish#^da-Q0756|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Og%20hvor%20kommer%20pengene%20fra%3F)
^da-Q0756-answer

**da-Q0757** — Jeg ved præcis hvor jeg er.

I know exactly where I am.

Expected form: **hvor**

Why: Questions. [[Danish#^da-Q0757|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20ved%20pr%C3%A6cis%20hvor%20jeg%20er.)
^da-Q0757-answer

**da-Q0758** — Jeg ved præcis hvor jeg er.

I know exactly where I am.

Expected form: **hvor**

Why: Questions. [[Danish#^da-Q0758|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20ved%20pr%C3%A6cis%20hvor%20jeg%20er.)
^da-Q0758-answer

**da-Q0759** — Så, hvad anbefaler du?

So, what do you recommend?

Expected form: **hvad**

Why: Questions. [[Danish#^da-Q0759|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=S%C3%A5%2C%20hvad%20anbefaler%20du%3F)
^da-Q0759-answer

**da-Q0760** — Så, hvad anbefaler du?

So, what do you recommend?

Why: Questions. [[Danish#^da-Q0760|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=S%C3%A5%2C%20hvad%20anbefaler%20du%3F)
^da-Q0760-answer

**da-Q0761** — Hun flyttede hjemmefra med alt hvad hun ejede.

She left home with everything she owned.

Why: Questions. [[Danish#^da-Q0761|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hun%20flyttede%20hjemmefra%20med%20alt%20hvad%20hun%20ejede.)
^da-Q0761-answer

**da-Q0762** — Hun flyttede hjemmefra med alt hvad hun ejede.

She left home with everything she owned.

Direct questions often place the finite verb before the subject. An indirect question takes subordinate order. A question word specifies the information requested.

Why: Questions. [[Danish#^da-Q0762|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hun%20flyttede%20hjemmefra%20med%20alt%20hvad%20hun%20ejede.)
^da-Q0762-answer

**da-Q0763** — Du kan sige lige hvad du ønsker.

You can say whatever you want.

Expected form: **hvad**

Why: Questions. [[Danish#^da-Q0763|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Du%20kan%20sige%20lige%20hvad%20du%20%C3%B8nsker.)
^da-Q0763-answer

**da-Q0764** — Du kan sige lige hvad du ønsker.

You can say whatever you want.

Expected form: **hvad**

Why: Questions. [[Danish#^da-Q0764|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Du%20kan%20sige%20lige%20hvad%20du%20%C3%B8nsker.)
^da-Q0764-answer

**da-Q0765** — Jeg ved hvad den pige hedder.

I know that girl's name.

Expected form: **hvad**

Why: Questions. [[Danish#^da-Q0765|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20ved%20hvad%20den%20pige%20hedder.)
^da-Q0765-answer

**da-Q0766** — Jeg ved hvad den pige hedder.

I know that girl's name.

Why: Questions. [[Danish#^da-Q0766|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20ved%20hvad%20den%20pige%20hedder.)
^da-Q0766-answer

**da-Q0767** — Ved du ikke hvor smuk du er?

Don't you know how beautiful you are?

Why: Questions. [[Danish#^da-Q0767|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Ved%20du%20ikke%20hvor%20smuk%20du%20er%3F)
^da-Q0767-answer

**da-Q0768** — Ved du ikke hvor smuk du er?

Don't you know how beautiful you are?

Direct questions often place the finite verb before the subject. An indirect question takes subordinate order. A question word specifies the information requested.

Why: Questions. [[Danish#^da-Q0768|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Ved%20du%20ikke%20hvor%20smuk%20du%20er%3F)
^da-Q0768-answer

**da-Q0769** — Jeg ved ikke hvad klokken er.

I don't know what time it is.

Expected form: **hvad**

Why: Questions. [[Danish#^da-Q0769|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20ved%20ikke%20hvad%20klokken%20er.)
^da-Q0769-answer

**da-Q0770** — Jeg ved ikke hvad klokken er.

I don't know what time it is.

Expected form: **hvad**

Why: Questions. [[Danish#^da-Q0770|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20ved%20ikke%20hvad%20klokken%20er.)
^da-Q0770-answer

**da-Q0771** — Ved Tom hvor Mary blev født?

Does Tom know where Mary was born?

Expected form: **hvor**

Why: Questions. [[Danish#^da-Q0771|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Ved%20Tom%20hvor%20Mary%20blev%20f%C3%B8dt%3F)
^da-Q0771-answer

**da-Q0772** — Ved Tom hvor Mary blev født?

Does Tom know where Mary was born?

Why: Questions. [[Danish#^da-Q0772|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Ved%20Tom%20hvor%20Mary%20blev%20f%C3%B8dt%3F)
^da-Q0772-answer

**da-Q0773** — Du ville blive overrasket over hvor mange æbler du kan købe for to hundrede dollars.

You'd be amazed how many apples you can buy for two hundred dollars.

Why: Questions. [[Danish#^da-Q0773|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Du%20ville%20blive%20overrasket%20over%20hvor%20mange%20%C3%A6bler%20du%20kan%20k%C3%B8be%20for%20to%20hundrede%20dollars.)
^da-Q0773-answer

**da-Q0774** — Du ville blive overrasket over hvor mange æbler du kan købe for to hundrede dollars.

You'd be amazed how many apples you can buy for two hundred dollars.

Direct questions often place the finite verb before the subject. An indirect question takes subordinate order. A question word specifies the information requested.

Why: Questions. [[Danish#^da-Q0774|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Du%20ville%20blive%20overrasket%20over%20hvor%20mange%20%C3%A6bler%20du%20kan%20k%C3%B8be%20for%20to%20hundrede%20dollars.)
^da-Q0774-answer

**da-Q0775** — Han spurgte mig hvor min onkel boede.

He asked me where my uncle lived.

Expected form: **hvor**

Why: Questions. [[Danish#^da-Q0775|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Han%20spurgte%20mig%20hvor%20min%20onkel%20boede.)
^da-Q0775-answer

**da-Q0776** — Han spurgte mig hvor min onkel boede.

He asked me where my uncle lived.

Expected form: **hvor**

Why: Questions. [[Danish#^da-Q0776|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Han%20spurgte%20mig%20hvor%20min%20onkel%20boede.)
^da-Q0776-answer

**da-Q0777** — De ved hvor du er.

They know where you are.

Expected form: **hvor**

Why: Questions. [[Danish#^da-Q0777|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=De%20ved%20hvor%20du%20er.)
^da-Q0777-answer

**da-Q0778** — De ved hvor du er.

They know where you are.

Why: Questions. [[Danish#^da-Q0778|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=De%20ved%20hvor%20du%20er.)
^da-Q0778-answer

**da-Q0779** — Dette er slet ikke hvad jeg havde forventet.

This is not at all what I had expected.

Why: Questions. [[Danish#^da-Q0779|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Dette%20er%20slet%20ikke%20hvad%20jeg%20havde%20forventet.)
^da-Q0779-answer

**da-Q0780** — Dette er slet ikke hvad jeg havde forventet.

This is not at all what I had expected.

Direct questions often place the finite verb before the subject. An indirect question takes subordinate order. A question word specifies the information requested.

Why: Questions. [[Danish#^da-Q0780|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Dette%20er%20slet%20ikke%20hvad%20jeg%20havde%20forventet.)
^da-Q0780-answer

**da-Q0781** — Jeg kan ikke gå før jeg finder ud af hvem Tom er.

I can't leave until I find out who Tom is.

Expected form: **hvem**

Why: Questions. [[Danish#^da-Q0781|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20kan%20ikke%20g%C3%A5%20f%C3%B8r%20jeg%20finder%20ud%20af%20hvem%20Tom%20er.)
^da-Q0781-answer

**da-Q0782** — Jeg kan ikke gå før jeg finder ud af hvem Tom er.

I can't leave until I find out who Tom is.

Expected form: **hvem**

Why: Questions. [[Danish#^da-Q0782|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20kan%20ikke%20g%C3%A5%20f%C3%B8r%20jeg%20finder%20ud%20af%20hvem%20Tom%20er.)
^da-Q0782-answer

**da-Q0783** — Ved du hvordan man behandler en førstegradsbrænding?

Do you know how to treat a first-degree burn?

Expected form: **hvordan**

Why: Questions. [[Danish#^da-Q0783|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Ved%20du%20hvordan%20man%20behandler%20en%20f%C3%B8rstegradsbr%C3%A6nding%3F)
^da-Q0783-answer

**da-Q0784** — Ved du hvordan man behandler en førstegradsbrænding?

Do you know how to treat a first-degree burn?

Why: Questions. [[Danish#^da-Q0784|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Ved%20du%20hvordan%20man%20behandler%20en%20f%C3%B8rstegradsbr%C3%A6nding%3F)
^da-Q0784-answer

**da-Q0785** — Tom ved lige, hvordan han kan få mig til at reagere.

Tom knows how to push my buttons.

Why: Questions. [[Danish#^da-Q0785|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20ved%20lige%2C%20hvordan%20han%20kan%20f%C3%A5%20mig%20til%20at%20reagere.)
^da-Q0785-answer

**da-Q0786** — Tom ved lige, hvordan han kan få mig til at reagere.

Tom knows how to push my buttons.

Direct questions often place the finite verb before the subject. An indirect question takes subordinate order. A question word specifies the information requested.

Why: Questions. [[Danish#^da-Q0786|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20ved%20lige%2C%20hvordan%20han%20kan%20f%C3%A5%20mig%20til%20at%20reagere.)
^da-Q0786-answer

**da-Q0787** — Sig mig, hvad tænker du på?

Tell me, what are you thinking about?

Expected form: **hvad**

Why: Questions. [[Danish#^da-Q0787|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Sig%20mig%2C%20hvad%20t%C3%A6nker%20du%20p%C3%A5%3F)
^da-Q0787-answer

**da-Q0788** — Sig mig, hvad tænker du på?

Tell me, what are you thinking about?

Expected form: **hvad**

Why: Questions. [[Danish#^da-Q0788|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Sig%20mig%2C%20hvad%20t%C3%A6nker%20du%20p%C3%A5%3F)
^da-Q0788-answer

**da-Q0789** — "Ved du hvor Lapland er?", spurgte hun rensdyret.

"Do you know where Lapland is?" she asked the reindeer.

Expected form: **hvor**

Why: Questions. [[Danish#^da-Q0789|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=%22Ved%20du%20hvor%20Lapland%20er%3F%22%2C%20spurgte%20hun%20rensdyret.)
^da-Q0789-answer

**da-Q0790** — "Ved du hvor Lapland er?", spurgte hun rensdyret.

"Do you know where Lapland is?" she asked the reindeer.

Why: Questions. [[Danish#^da-Q0790|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=%22Ved%20du%20hvor%20Lapland%20er%3F%22%2C%20spurgte%20hun%20rensdyret.)
^da-Q0790-answer

**da-Q0791** — Jeg vil gerne lære dig, hvordan du gør det.

I want to teach you how to do that.

Why: Questions. [[Danish#^da-Q0791|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20vil%20gerne%20l%C3%A6re%20dig%2C%20hvordan%20du%20g%C3%B8r%20det.)
^da-Q0791-answer

**da-Q0792** — Jeg vil gerne lære dig, hvordan du gør det.

I want to teach you how to do that.

Direct questions often place the finite verb before the subject. An indirect question takes subordinate order. A question word specifies the information requested.

Why: Questions. [[Danish#^da-Q0792|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20vil%20gerne%20l%C3%A6re%20dig%2C%20hvordan%20du%20g%C3%B8r%20det.)
^da-Q0792-answer

**da-Q0793** — Gid jeg vidste hvor han var!

I wish I knew where he was!

Expected form: **hvor**

Why: Questions. [[Danish#^da-Q0793|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Gid%20jeg%20vidste%20hvor%20han%20var%21)
^da-Q0793-answer

**da-Q0794** — Gid jeg vidste hvor han var!

I wish I knew where he was!

Expected form: **hvor**

Why: Questions. [[Danish#^da-Q0794|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Gid%20jeg%20vidste%20hvor%20han%20var%21)
^da-Q0794-answer

**da-Q0795** — Jeg undrer mig over, hvorfor vi har øreflipper.

I wonder why we have ear lobes.

Expected form: **hvorfor**

Why: Questions. [[Danish#^da-Q0795|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20undrer%20mig%20over%2C%20hvorfor%20vi%20har%20%C3%B8reflipper.)
^da-Q0795-answer

**da-Q0796** — Jeg undrer mig over, hvorfor vi har øreflipper.

I wonder why we have ear lobes.

Why: Questions. [[Danish#^da-Q0796|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20undrer%20mig%20over%2C%20hvorfor%20vi%20har%20%C3%B8reflipper.)
^da-Q0796-answer

**da-Q0797** — Undskyld, hvad er klokken?

Excuse me, what time is it?

Why: Questions. [[Danish#^da-Q0797|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Undskyld%2C%20hvad%20er%20klokken%3F)
^da-Q0797-answer

**da-Q0798** — Undskyld, hvad er klokken?

Excuse me, what time is it?

Direct questions often place the finite verb before the subject. An indirect question takes subordinate order. A question word specifies the information requested.

Why: Questions. [[Danish#^da-Q0798|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Undskyld%2C%20hvad%20er%20klokken%3F)
^da-Q0798-answer

**da-Q0799** — Han ved hvor vi er.

He knows where we are.

Expected form: **hvor**

Why: Questions. [[Danish#^da-Q0799|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Han%20ved%20hvor%20vi%20er.)
^da-Q0799-answer

**da-Q0800** — Han ved hvor vi er.

He knows where we are.

Expected form: **hvor**

Why: Questions. [[Danish#^da-Q0800|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Han%20ved%20hvor%20vi%20er.)
^da-Q0800-answer


### Answers 801–850

**da-Q0801** — Tom tog fra Boston til Chicago.

Tom went from Boston to Chicago.

Expected form: **til**

Why: Infinitives. [[Danish#^da-Q0801|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20tog%20fra%20Boston%20til%20Chicago.)
^da-Q0801-answer

**da-Q0802** — Tom tog fra Boston til Chicago.

Tom went from Boston to Chicago.

Why: Infinitives. [[Danish#^da-Q0802|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20tog%20fra%20Boston%20til%20Chicago.)
^da-Q0802-answer

**da-Q0803** — Toget ankom til Kyoto til tiden.

The train arrived in Kyoto on time.

Why: Infinitives. [[Danish#^da-Q0803|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Toget%20ankom%20til%20Kyoto%20til%20tiden.)
^da-Q0803-answer

**da-Q0804** — Toget ankom til Kyoto til tiden.

The train arrived in Kyoto on time.

At can mark an infinitive or introduce a finite complement clause. Distinguish at læse from at hun læser. Modals normally take an infinitive without at.

Why: Infinitives. [[Danish#^da-Q0804|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Toget%20ankom%20til%20Kyoto%20til%20tiden.)
^da-Q0804-answer

**da-Q0805** — Brevet var adresseret til mig.

The letter was addressed to me.

Expected form: **til**

Why: Infinitives. [[Danish#^da-Q0805|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Brevet%20var%20adresseret%20til%20mig.)
^da-Q0805-answer

**da-Q0806** — Brevet var adresseret til mig.

The letter was addressed to me.

Expected form: **til**

Why: Infinitives. [[Danish#^da-Q0806|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Brevet%20var%20adresseret%20til%20mig.)
^da-Q0806-answer

**da-Q0807** — Vær munter! Tilføj et udråbstegn til alle dine sætninger!

Be cheerful! Add an exclamation mark to all of your sentences!

Expected form: **til**

Why: Infinitives. [[Danish#^da-Q0807|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=V%C3%A6r%20munter%21%20Tilf%C3%B8j%20et%20udr%C3%A5bstegn%20til%20alle%20dine%20s%C3%A6tninger%21)
^da-Q0807-answer

**da-Q0808** — Vær munter! Tilføj et udråbstegn til alle dine sætninger!

Be cheerful! Add an exclamation mark to all of your sentences!

Why: Infinitives. [[Danish#^da-Q0808|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=V%C3%A6r%20munter%21%20Tilf%C3%B8j%20et%20udr%C3%A5bstegn%20til%20alle%20dine%20s%C3%A6tninger%21)
^da-Q0808-answer

**da-Q0809** — Er den stadig til salg?

Is it still for sale?

Why: Infinitives. [[Danish#^da-Q0809|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Er%20den%20stadig%20til%20salg%3F)
^da-Q0809-answer

**da-Q0810** — Er den stadig til salg?

Is it still for sale?

At can mark an infinitive or introduce a finite complement clause. Distinguish at læse from at hun læser. Modals normally take an infinitive without at.

Why: Infinitives. [[Danish#^da-Q0810|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Er%20den%20stadig%20til%20salg%3F)
^da-Q0810-answer

**da-Q0811** — Svaret er nej til begge dine spørgsmål.

The answer is no to both of your questions.

Expected form: **til**

Why: Infinitives. [[Danish#^da-Q0811|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Svaret%20er%20nej%20til%20begge%20dine%20sp%C3%B8rgsm%C3%A5l.)
^da-Q0811-answer

**da-Q0812** — Svaret er nej til begge dine spørgsmål.

The answer is no to both of your questions.

Expected form: **til**

Why: Infinitives. [[Danish#^da-Q0812|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Svaret%20er%20nej%20til%20begge%20dine%20sp%C3%B8rgsm%C3%A5l.)
^da-Q0812-answer

**da-Q0813** — Ingen taler til mig.

Nobody speaks to me.

Expected form: **til**

Why: Infinitives. [[Danish#^da-Q0813|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Ingen%20taler%20til%20mig.)
^da-Q0813-answer

**da-Q0814** — Ingen taler til mig.

Nobody speaks to me.

Why: Infinitives. [[Danish#^da-Q0814|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Ingen%20taler%20til%20mig.)
^da-Q0814-answer

**da-Q0815** — De ser ud til at more sig.

They seem to be enjoying themselves.

Why: Infinitives. [[Danish#^da-Q0815|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=De%20ser%20ud%20til%20at%20more%20sig.)
^da-Q0815-answer

**da-Q0816** — De ser ud til at more sig.

They seem to be enjoying themselves.

At can mark an infinitive or introduce a finite complement clause. Distinguish at læse from at hun læser. Modals normally take an infinitive without at.

Why: Infinitives. [[Danish#^da-Q0816|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=De%20ser%20ud%20til%20at%20more%20sig.)
^da-Q0816-answer

**da-Q0817** — Er netledningen sat til en stikkontakt.

Is the power cord plugged into a power outlet?

Expected form: **til**

Why: Infinitives. [[Danish#^da-Q0817|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Er%20netledningen%20sat%20til%20en%20stikkontakt.)
^da-Q0817-answer

**da-Q0818** — Er netledningen sat til en stikkontakt.

Is the power cord plugged into a power outlet?

Expected form: **til**

Why: Infinitives. [[Danish#^da-Q0818|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Er%20netledningen%20sat%20til%20en%20stikkontakt.)
^da-Q0818-answer

**da-Q0819** — Jeg lovede Tom at jeg ikke ville græde.

I promised Tom that I wouldn't cry.

Expected form: **at**

Why: Infinitives. [[Danish#^da-Q0819|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20lovede%20Tom%20at%20jeg%20ikke%20ville%20gr%C3%A6de.)
^da-Q0819-answer

**da-Q0820** — Jeg lovede Tom at jeg ikke ville græde.

I promised Tom that I wouldn't cry.

Why: Infinitives. [[Danish#^da-Q0820|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20lovede%20Tom%20at%20jeg%20ikke%20ville%20gr%C3%A6de.)
^da-Q0820-answer

**da-Q0821** — Glem ikke at skylle ud.

Don't forget to flush.

Why: Infinitives. [[Danish#^da-Q0821|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Glem%20ikke%20at%20skylle%20ud.)
^da-Q0821-answer

**da-Q0822** — Glem ikke at skylle ud.

Don't forget to flush.

At can mark an infinitive or introduce a finite complement clause. Distinguish at læse from at hun læser. Modals normally take an infinitive without at.

Why: Infinitives. [[Danish#^da-Q0822|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Glem%20ikke%20at%20skylle%20ud.)
^da-Q0822-answer

**da-Q0823** — Vi er endnu ikke klar til at kaste håndklædet i ringen.

We're not ready to throw in the towel yet.

Expected form: **til**

Why: Infinitives. [[Danish#^da-Q0823|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Vi%20er%20endnu%20ikke%20klar%20til%20at%20kaste%20h%C3%A5ndkl%C3%A6det%20i%20ringen.)
^da-Q0823-answer

**da-Q0824** — Vi er endnu ikke klar til at kaste håndklædet i ringen.

We're not ready to throw in the towel yet.

Expected form: **til**

Why: Infinitives. [[Danish#^da-Q0824|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Vi%20er%20endnu%20ikke%20klar%20til%20at%20kaste%20h%C3%A5ndkl%C3%A6det%20i%20ringen.)
^da-Q0824-answer

**da-Q0825** — Jeg sender penge til Algeriet cirka en gang om måneden.

I send money to Algeria every month or so.

Expected form: **til**

Why: Infinitives. [[Danish#^da-Q0825|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20sender%20penge%20til%20Algeriet%20cirka%20en%20gang%20om%20m%C3%A5neden.)
^da-Q0825-answer

**da-Q0826** — Jeg sender penge til Algeriet cirka en gang om måneden.

I send money to Algeria every month or so.

Why: Infinitives. [[Danish#^da-Q0826|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20sender%20penge%20til%20Algeriet%20cirka%20en%20gang%20om%20m%C3%A5neden.)
^da-Q0826-answer

**da-Q0827** — Vil du invitere hende til festen?

Are you going to invite her to the party?

Why: Infinitives. [[Danish#^da-Q0827|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Vil%20du%20invitere%20hende%20til%20festen%3F)
^da-Q0827-answer

**da-Q0828** — Vil du invitere hende til festen?

Are you going to invite her to the party?

At can mark an infinitive or introduce a finite complement clause. Distinguish at læse from at hun læser. Modals normally take an infinitive without at.

Why: Infinitives. [[Danish#^da-Q0828|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Vil%20du%20invitere%20hende%20til%20festen%3F)
^da-Q0828-answer

**da-Q0829** — Glem ikke at skrive til mig.

Don't forget to write me.

Expected form: **at**

Why: Infinitives. [[Danish#^da-Q0829|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Glem%20ikke%20at%20skrive%20til%20mig.)
^da-Q0829-answer

**da-Q0830** — Glem ikke at skrive til mig.

Don't forget to write me.

Expected form: **at**

Why: Infinitives. [[Danish#^da-Q0830|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Glem%20ikke%20at%20skrive%20til%20mig.)
^da-Q0830-answer

**da-Q0831** — Tom fortalte mig at han talte fransk.

Tom told me that he spoke French.

Expected form: **at**

Why: Infinitives. [[Danish#^da-Q0831|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20fortalte%20mig%20at%20han%20talte%20fransk.)
^da-Q0831-answer

**da-Q0832** — Tom fortalte mig at han talte fransk.

Tom told me that he spoke French.

Why: Infinitives. [[Danish#^da-Q0832|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20fortalte%20mig%20at%20han%20talte%20fransk.)
^da-Q0832-answer

**da-Q0833** — Han tog en taxi til hospitalet.

He took a taxi to the hospital.

Why: Infinitives. [[Danish#^da-Q0833|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Han%20tog%20en%20taxi%20til%20hospitalet.)
^da-Q0833-answer

**da-Q0834** — Han tog en taxi til hospitalet.

He took a taxi to the hospital.

At can mark an infinitive or introduce a finite complement clause. Distinguish at læse from at hun læser. Modals normally take an infinitive without at.

Why: Infinitives. [[Danish#^da-Q0834|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Han%20tog%20en%20taxi%20til%20hospitalet.)
^da-Q0834-answer

**da-Q0835** — Jeg lovede at adlyde ham.

I promised to obey him.

Expected form: **at**

Why: Infinitives. [[Danish#^da-Q0835|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20lovede%20at%20adlyde%20ham.)
^da-Q0835-answer

**da-Q0836** — Jeg lovede at adlyde ham.

I promised to obey him.

Expected form: **at**

Why: Infinitives. [[Danish#^da-Q0836|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20lovede%20at%20adlyde%20ham.)
^da-Q0836-answer

**da-Q0837** — Hold op med at surmule!

Stop sulking!

Expected form: **at**

Why: Infinitives. [[Danish#^da-Q0837|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hold%20op%20med%20at%20surmule%21)
^da-Q0837-answer

**da-Q0838** — Hold op med at surmule!

Stop sulking!

Why: Infinitives. [[Danish#^da-Q0838|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hold%20op%20med%20at%20surmule%21)
^da-Q0838-answer

**da-Q0839** — Dick forsøgte forgæves at løse problemet.

Dick tried to solve the problem, in vain.

Why: Infinitives. [[Danish#^da-Q0839|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Dick%20fors%C3%B8gte%20forg%C3%A6ves%20at%20l%C3%B8se%20problemet.)
^da-Q0839-answer

**da-Q0840** — Dick forsøgte forgæves at løse problemet.

Dick tried to solve the problem, in vain.

At can mark an infinitive or introduce a finite complement clause. Distinguish at læse from at hun læser. Modals normally take an infinitive without at.

Why: Infinitives. [[Danish#^da-Q0840|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Dick%20fors%C3%B8gte%20forg%C3%A6ves%20at%20l%C3%B8se%20problemet.)
^da-Q0840-answer

**da-Q0841** — Jeg glæder mig til at se ham.

I'm looking forward to seeing him.

Expected form: **til**

Why: Infinitives. [[Danish#^da-Q0841|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20gl%C3%A6der%20mig%20til%20at%20se%20ham.)
^da-Q0841-answer

**da-Q0842** — Jeg glæder mig til at se ham.

I'm looking forward to seeing him.

Expected form: **til**

Why: Infinitives. [[Danish#^da-Q0842|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20gl%C3%A6der%20mig%20til%20at%20se%20ham.)
^da-Q0842-answer

**da-Q0843** — Tom mente at det ville være spild af tid at tage til det møde.

Tom thought that it would be a waste of time to go to that meeting.

Expected form: **at**

Why: Infinitives. [[Danish#^da-Q0843|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20mente%20at%20det%20ville%20v%C3%A6re%20spild%20af%20tid%20at%20tage%20til%20det%20m%C3%B8de.)
^da-Q0843-answer

**da-Q0844** — Tom mente at det ville være spild af tid at tage til det møde.

Tom thought that it would be a waste of time to go to that meeting.

Why: Infinitives. [[Danish#^da-Q0844|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20mente%20at%20det%20ville%20v%C3%A6re%20spild%20af%20tid%20at%20tage%20til%20det%20m%C3%B8de.)
^da-Q0844-answer

**da-Q0845** — Ring til mig!

Call me!

Why: Infinitives. [[Danish#^da-Q0845|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Ring%20til%20mig%21)
^da-Q0845-answer

**da-Q0846** — Ring til mig!

Call me!

At can mark an infinitive or introduce a finite complement clause. Distinguish at læse from at hun læser. Modals normally take an infinitive without at.

Why: Infinitives. [[Danish#^da-Q0846|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Ring%20til%20mig%21)
^da-Q0846-answer

**da-Q0847** — Hvor vil du holde ferie til næste sommer?

Where do you plan to go on vacation next summer?

Expected form: **til**

Why: Infinitives. [[Danish#^da-Q0847|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hvor%20vil%20du%20holde%20ferie%20til%20n%C3%A6ste%20sommer%3F)
^da-Q0847-answer

**da-Q0848** — Hvor vil du holde ferie til næste sommer?

Where do you plan to go on vacation next summer?

Expected form: **til**

Why: Infinitives. [[Danish#^da-Q0848|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hvor%20vil%20du%20holde%20ferie%20til%20n%C3%A6ste%20sommer%3F)
^da-Q0848-answer

**da-Q0849** — Vi er ved at lære fransk.

We're learning French.

Expected form: **at**

Why: Infinitives. [[Danish#^da-Q0849|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Vi%20er%20ved%20at%20l%C3%A6re%20fransk.)
^da-Q0849-answer

**da-Q0850** — Vi er ved at lære fransk.

We're learning French.

Why: Infinitives. [[Danish#^da-Q0850|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Vi%20er%20ved%20at%20l%C3%A6re%20fransk.)
^da-Q0850-answer


### Answers 851–900

**da-Q0851** — Det er koldere i år end sidste år.

It is colder this year than last year.

Why: Comparison. [[Danish#^da-Q0851|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Det%20er%20koldere%20i%20%C3%A5r%20end%20sidste%20%C3%A5r.)
^da-Q0851-answer

**da-Q0852** — Det er koldere i år end sidste år.

It is colder this year than last year.

Comparatives commonly use end; equality uses forms such as lige så ... som. Bedre and større are irregular/common comparative forms.

Why: Comparison. [[Danish#^da-Q0852|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Det%20er%20koldere%20i%20%C3%A5r%20end%20sidste%20%C3%A5r.)
^da-Q0852-answer

**da-Q0853** — I burde være mere forsigtige.

You guys should be more careful.

Expected form: **mere**

Why: Comparison. [[Danish#^da-Q0853|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=I%20burde%20v%C3%A6re%20mere%20forsigtige.)
^da-Q0853-answer

**da-Q0854** — I burde være mere forsigtige.

You guys should be more careful.

Expected form: **mere**

Why: Comparison. [[Danish#^da-Q0854|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=I%20burde%20v%C3%A6re%20mere%20forsigtige.)
^da-Q0854-answer

**da-Q0855** — Jeg er fire måneder yngre end dig.

I am four months younger than you.

Expected form: **end**

Why: Comparison. [[Danish#^da-Q0855|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20er%20fire%20m%C3%A5neder%20yngre%20end%20dig.)
^da-Q0855-answer

**da-Q0856** — Jeg er fire måneder yngre end dig.

I am four months younger than you.

Why: Comparison. [[Danish#^da-Q0856|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20er%20fire%20m%C3%A5neder%20yngre%20end%20dig.)
^da-Q0856-answer

**da-Q0857** — Jo før man begynder at lære berberisk, jo bedre.

The sooner you start learning Berber, the better.

Why: Comparison. [[Danish#^da-Q0857|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jo%20f%C3%B8r%20man%20begynder%20at%20l%C3%A6re%20berberisk%2C%20jo%20bedre.)
^da-Q0857-answer

**da-Q0858** — Jo før man begynder at lære berberisk, jo bedre.

The sooner you start learning Berber, the better.

Comparatives commonly use end; equality uses forms such as lige så ... som. Bedre and større are irregular/common comparative forms.

Why: Comparison. [[Danish#^da-Q0858|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jo%20f%C3%B8r%20man%20begynder%20at%20l%C3%A6re%20berberisk%2C%20jo%20bedre.)
^da-Q0858-answer

**da-Q0859** — Mine forældre har lige haft sølvbryllup.

My parents just had their silver wedding anniversary.

Expected form: **lige**

Why: Comparison. [[Danish#^da-Q0859|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Mine%20for%C3%A6ldre%20har%20lige%20haft%20s%C3%B8lvbryllup.)
^da-Q0859-answer

**da-Q0860** — Mine forældre har lige haft sølvbryllup.

My parents just had their silver wedding anniversary.

Expected form: **lige**

Why: Comparison. [[Danish#^da-Q0860|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Mine%20for%C3%A6ldre%20har%20lige%20haft%20s%C3%B8lvbryllup.)
^da-Q0860-answer

**da-Q0861** — Måske vil Tom ikke lyve for os mere.

Perhaps Tom won't lie to us anymore.

Expected form: **mere**

Why: Comparison. [[Danish#^da-Q0861|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=M%C3%A5ske%20vil%20Tom%20ikke%20lyve%20for%20os%20mere.)
^da-Q0861-answer

**da-Q0862** — Måske vil Tom ikke lyve for os mere.

Perhaps Tom won't lie to us anymore.

Why: Comparison. [[Danish#^da-Q0862|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=M%C3%A5ske%20vil%20Tom%20ikke%20lyve%20for%20os%20mere.)
^da-Q0862-answer

**da-Q0863** — Han er langt mere erfaren end mig.

He's far more experienced than me.

Why: Comparison. [[Danish#^da-Q0863|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Han%20er%20langt%20mere%20erfaren%20end%20mig.)
^da-Q0863-answer

**da-Q0864** — Han er langt mere erfaren end mig.

He's far more experienced than me.

Comparatives commonly use end; equality uses forms such as lige så ... som. Bedre and større are irregular/common comparative forms.

Why: Comparison. [[Danish#^da-Q0864|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Han%20er%20langt%20mere%20erfaren%20end%20mig.)
^da-Q0864-answer

**da-Q0865** — Jeg er klog nok til at tro, at hvis man er født som fisk, er det mere værdigt at dø under vand end i stegepanden.

I am wise enough to think that if one is born a fish, it is more dignified to die under the water than in the frying pan.

Expected form: **mere**

Why: Comparison. [[Danish#^da-Q0865|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20er%20klog%20nok%20til%20at%20tro%2C%20at%20hvis%20man%20er%20f%C3%B8dt%20som%20fisk%2C%20er%20det%20mere%20v%C3%A6rdigt%20at%20d%C3%B8%20under%20vand%20end%20i%20stegepanden.)
^da-Q0865-answer

**da-Q0866** — Jeg er klog nok til at tro, at hvis man er født som fisk, er det mere værdigt at dø under vand end i stegepanden.

I am wise enough to think that if one is born a fish, it is more dignified to die under the water than in the frying pan.

Expected form: **mere**

Why: Comparison. [[Danish#^da-Q0866|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20er%20klog%20nok%20til%20at%20tro%2C%20at%20hvis%20man%20er%20f%C3%B8dt%20som%20fisk%2C%20er%20det%20mere%20v%C3%A6rdigt%20at%20d%C3%B8%20under%20vand%20end%20i%20stegepanden.)
^da-Q0866-answer

**da-Q0867** — Vi har lige haft nogle få problemer.

We just had a few problems.

Expected form: **lige**

Why: Comparison. [[Danish#^da-Q0867|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Vi%20har%20lige%20haft%20nogle%20f%C3%A5%20problemer.)
^da-Q0867-answer

**da-Q0868** — Vi har lige haft nogle få problemer.

We just had a few problems.

Why: Comparison. [[Danish#^da-Q0868|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Vi%20har%20lige%20haft%20nogle%20f%C3%A5%20problemer.)
^da-Q0868-answer

**da-Q0869** — Hans tantes æblekage var velsmagende, og derfor fik han en portion mere.

His aunt's apple pie was delicious, so he had a second helping.

Why: Comparison. [[Danish#^da-Q0869|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hans%20tantes%20%C3%A6blekage%20var%20velsmagende%2C%20og%20derfor%20fik%20han%20en%20portion%20mere.)
^da-Q0869-answer

**da-Q0870** — Hans tantes æblekage var velsmagende, og derfor fik han en portion mere.

His aunt's apple pie was delicious, so he had a second helping.

Comparatives commonly use end; equality uses forms such as lige så ... som. Bedre and større are irregular/common comparative forms.

Why: Comparison. [[Danish#^da-Q0870|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hans%20tantes%20%C3%A6blekage%20var%20velsmagende%2C%20og%20derfor%20fik%20han%20en%20portion%20mere.)
^da-Q0870-answer

**da-Q0871** — Er Tom yngre end Mary?

Is Tom younger than Mary?

Expected form: **end**

Why: Comparison. [[Danish#^da-Q0871|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Er%20Tom%20yngre%20end%20Mary%3F)
^da-Q0871-answer

**da-Q0872** — Er Tom yngre end Mary?

Is Tom younger than Mary?

Expected form: **end**

Why: Comparison. [[Danish#^da-Q0872|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Er%20Tom%20yngre%20end%20Mary%3F)
^da-Q0872-answer

**da-Q0873** — Du må huske på at hun er meget yngre end dig.

You must keep in mind that she's much younger than you.

Expected form: **end**

Why: Comparison. [[Danish#^da-Q0873|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Du%20m%C3%A5%20huske%20p%C3%A5%20at%20hun%20er%20meget%20yngre%20end%20dig.)
^da-Q0873-answer

**da-Q0874** — Du må huske på at hun er meget yngre end dig.

You must keep in mind that she's much younger than you.

Why: Comparison. [[Danish#^da-Q0874|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Du%20m%C3%A5%20huske%20p%C3%A5%20at%20hun%20er%20meget%20yngre%20end%20dig.)
^da-Q0874-answer

**da-Q0875** — Jeg nåede lige akkurat toget.

I barely managed to catch the train.

Why: Comparison. [[Danish#^da-Q0875|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20n%C3%A5ede%20lige%20akkurat%20toget.)
^da-Q0875-answer

**da-Q0876** — Jeg nåede lige akkurat toget.

I barely managed to catch the train.

Comparatives commonly use end; equality uses forms such as lige så ... som. Bedre and større are irregular/common comparative forms.

Why: Comparison. [[Danish#^da-Q0876|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20n%C3%A5ede%20lige%20akkurat%20toget.)
^da-Q0876-answer

**da-Q0877** — Jeg var lige ved at glemme mit pas.

I almost forgot my passport.

Expected form: **lige**

Why: Comparison. [[Danish#^da-Q0877|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20var%20lige%20ved%20at%20glemme%20mit%20pas.)
^da-Q0877-answer

**da-Q0878** — Jeg var lige ved at glemme mit pas.

I almost forgot my passport.

Expected form: **lige**

Why: Comparison. [[Danish#^da-Q0878|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20var%20lige%20ved%20at%20glemme%20mit%20pas.)
^da-Q0878-answer

**da-Q0879** — Man siger at marts kommer ind som en løve og går ud som et lam, men det er mere kompliceret end som så.

They say March goes in like a lion and out like a lamb, but it's more complicated than that.

Expected form: **mere**

Why: Comparison. [[Danish#^da-Q0879|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Man%20siger%20at%20marts%20kommer%20ind%20som%20en%20l%C3%B8ve%20og%20g%C3%A5r%20ud%20som%20et%20lam%2C%20men%20det%20er%20mere%20kompliceret%20end%20som%20s%C3%A5.)
^da-Q0879-answer

**da-Q0880** — Man siger at marts kommer ind som en løve og går ud som et lam, men det er mere kompliceret end som så.

They say March goes in like a lion and out like a lamb, but it's more complicated than that.

Why: Comparison. [[Danish#^da-Q0880|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Man%20siger%20at%20marts%20kommer%20ind%20som%20en%20l%C3%B8ve%20og%20g%C3%A5r%20ud%20som%20et%20lam%2C%20men%20det%20er%20mere%20kompliceret%20end%20som%20s%C3%A5.)
^da-Q0880-answer

**da-Q0881** — Kan du tale andre sprοg end engelsk?

Can you speak a language other than English?

Why: Comparison. [[Danish#^da-Q0881|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Kan%20du%20tale%20andre%20spr%CE%BFg%20end%20engelsk%3F)
^da-Q0881-answer

**da-Q0882** — Kan du tale andre sprοg end engelsk?

Can you speak a language other than English?

Comparatives commonly use end; equality uses forms such as lige så ... som. Bedre and større are irregular/common comparative forms.

Why: Comparison. [[Danish#^da-Q0882|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Kan%20du%20tale%20andre%20spr%CE%BFg%20end%20engelsk%3F)
^da-Q0882-answer

**da-Q0883** — Jeg sov bedre end jeg gjorde sidste nat.

I slept better than I did last night.

Expected form: **bedre**

Why: Comparison. [[Danish#^da-Q0883|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20sov%20bedre%20end%20jeg%20gjorde%20sidste%20nat.)
^da-Q0883-answer

**da-Q0884** — Jeg sov bedre end jeg gjorde sidste nat.

I slept better than I did last night.

Expected form: **bedre**

Why: Comparison. [[Danish#^da-Q0884|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20sov%20bedre%20end%20jeg%20gjorde%20sidste%20nat.)
^da-Q0884-answer

**da-Q0885** — Alle dyr er lige, men nogle dyr er mere lige end andre.

All animals are equal, but some animals are more equal than others.

Expected form: **lige**

Why: Comparison. [[Danish#^da-Q0885|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Alle%20dyr%20er%20lige%2C%20men%20nogle%20dyr%20er%20mere%20lige%20end%20andre.)
^da-Q0885-answer

**da-Q0886** — Alle dyr er lige, men nogle dyr er mere lige end andre.

All animals are equal, but some animals are more equal than others.

Why: Comparison. [[Danish#^da-Q0886|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Alle%20dyr%20er%20lige%2C%20men%20nogle%20dyr%20er%20mere%20lige%20end%20andre.)
^da-Q0886-answer

**da-Q0887** — Jeg har brug for mere kaffe.

I need more coffee.

Why: Comparison. [[Danish#^da-Q0887|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20har%20brug%20for%20mere%20kaffe.)
^da-Q0887-answer

**da-Q0888** — Jeg har brug for mere kaffe.

I need more coffee.

Comparatives commonly use end; equality uses forms such as lige så ... som. Bedre and større are irregular/common comparative forms.

Why: Comparison. [[Danish#^da-Q0888|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20har%20brug%20for%20mere%20kaffe.)
^da-Q0888-answer

**da-Q0889** — Min Mercedes er større end din.

My Mercedes is bigger than yours.

Expected form: **større**

Why: Comparison. [[Danish#^da-Q0889|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Min%20Mercedes%20er%20st%C3%B8rre%20end%20din.)
^da-Q0889-answer

**da-Q0890** — Min Mercedes er større end din.

My Mercedes is bigger than yours.

Expected form: **større**

Why: Comparison. [[Danish#^da-Q0890|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Min%20Mercedes%20er%20st%C3%B8rre%20end%20din.)
^da-Q0890-answer

**da-Q0891** — Det er bedre, ikke sandt?

That's better, isn't it?

Expected form: **bedre**

Why: Comparison. [[Danish#^da-Q0891|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Det%20er%20bedre%2C%20ikke%20sandt%3F)
^da-Q0891-answer

**da-Q0892** — Det er bedre, ikke sandt?

That's better, isn't it?

Why: Comparison. [[Danish#^da-Q0892|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Det%20er%20bedre%2C%20ikke%20sandt%3F)
^da-Q0892-answer

**da-Q0893** — Tom tager lige nu et bad.

Tom is taking a bath now.

Why: Comparison. [[Danish#^da-Q0893|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20tager%20lige%20nu%20et%20bad.)
^da-Q0893-answer

**da-Q0894** — Tom tager lige nu et bad.

Tom is taking a bath now.

Comparatives commonly use end; equality uses forms such as lige så ... som. Bedre and større are irregular/common comparative forms.

Why: Comparison. [[Danish#^da-Q0894|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20tager%20lige%20nu%20et%20bad.)
^da-Q0894-answer

**da-Q0895** — Der er ikke mere toiletpapir.

There is no TP left.

Expected form: **mere**

Why: Comparison. [[Danish#^da-Q0895|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Der%20er%20ikke%20mere%20toiletpapir.)
^da-Q0895-answer

**da-Q0896** — Der er ikke mere toiletpapir.

There is no TP left.

Expected form: **mere**

Why: Comparison. [[Danish#^da-Q0896|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Der%20er%20ikke%20mere%20toiletpapir.)
^da-Q0896-answer

**da-Q0897** — Han er ældre end mig.

He's older than me.

Expected form: **end**

Why: Comparison. [[Danish#^da-Q0897|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Han%20er%20%C3%A6ldre%20end%20mig.)
^da-Q0897-answer

**da-Q0898** — Han er ældre end mig.

He's older than me.

Why: Comparison. [[Danish#^da-Q0898|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Han%20er%20%C3%A6ldre%20end%20mig.)
^da-Q0898-answer

**da-Q0899** — Og lige foran, ud af tykningen, kom tre dejlige, hvide svaner; de bruste med fjerene og flød så let på vandet.

From a thicket close by came three beautiful white swans, rustling their feathers, and swimming lightly over the smooth water.

Why: Comparison. [[Danish#^da-Q0899|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Og%20lige%20foran%2C%20ud%20af%20tykningen%2C%20kom%20tre%20dejlige%2C%20hvide%20svaner%3B%20de%20bruste%20med%20fjerene%20og%20fl%C3%B8d%20s%C3%A5%20let%20p%C3%A5%20vandet.)
^da-Q0899-answer

**da-Q0900** — Og lige foran, ud af tykningen, kom tre dejlige, hvide svaner; de bruste med fjerene og flød så let på vandet.

From a thicket close by came three beautiful white swans, rustling their feathers, and swimming lightly over the smooth water.

Comparatives commonly use end; equality uses forms such as lige så ... som. Bedre and større are irregular/common comparative forms.

Why: Comparison. [[Danish#^da-Q0900|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Og%20lige%20foran%2C%20ud%20af%20tykningen%2C%20kom%20tre%20dejlige%2C%20hvide%20svaner%3B%20de%20bruste%20med%20fjerene%20og%20fl%C3%B8d%20s%C3%A5%20let%20p%C3%A5%20vandet.)
^da-Q0900-answer


### Answers 901–950

**da-Q0901** — Jeg bor i Boston nu.

I live in Boston now.

Expected form: **i**

Why: Prepositions. [[Danish#^da-Q0901|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20bor%20i%20Boston%20nu.)
^da-Q0901-answer

**da-Q0902** — Jeg bor i Boston nu.

I live in Boston now.

Expected form: **i**

Why: Prepositions. [[Danish#^da-Q0902|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20bor%20i%20Boston%20nu.)
^da-Q0902-answer

**da-Q0903** — Tom arbejder på deltid.

Tom works part-time.

Expected form: **på**

Why: Prepositions. [[Danish#^da-Q0903|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20arbejder%20p%C3%A5%20deltid.)
^da-Q0903-answer

**da-Q0904** — Tom arbejder på deltid.

Tom works part-time.

Why: Prepositions. [[Danish#^da-Q0904|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20arbejder%20p%C3%A5%20deltid.)
^da-Q0904-answer

**da-Q0905** — Tom stod med ansigtet mod muren.

Tom stood facing the wall.

Why: Prepositions. [[Danish#^da-Q0905|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20stod%20med%20ansigtet%20mod%20muren.)
^da-Q0905-answer

**da-Q0906** — Tom stod med ansigtet mod muren.

Tom stood facing the wall.

Prepositions encode relations and belong to learned phrases. A location choice between i and på cannot always be predicted from English in/on.

Why: Prepositions. [[Danish#^da-Q0906|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20stod%20med%20ansigtet%20mod%20muren.)
^da-Q0906-answer

**da-Q0907** — Kvæg lever af græs.

Cattle feed on grass.

Expected form: **af**

Why: Prepositions. [[Danish#^da-Q0907|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Kv%C3%A6g%20lever%20af%20gr%C3%A6s.)
^da-Q0907-answer

**da-Q0908** — Kvæg lever af græs.

Cattle feed on grass.

Expected form: **af**

Why: Prepositions. [[Danish#^da-Q0908|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Kv%C3%A6g%20lever%20af%20gr%C3%A6s.)
^da-Q0908-answer

**da-Q0909** — Hvordan siger man "børnehave" på tysk?

How do you say kindergarten in German?

Expected form: **på**

Why: Prepositions. [[Danish#^da-Q0909|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hvordan%20siger%20man%20%22b%C3%B8rnehave%22%20p%C3%A5%20tysk%3F)
^da-Q0909-answer

**da-Q0910** — Hvordan siger man "børnehave" på tysk?

How do you say kindergarten in German?

Why: Prepositions. [[Danish#^da-Q0910|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hvordan%20siger%20man%20%22b%C3%B8rnehave%22%20p%C3%A5%20tysk%3F)
^da-Q0910-answer

**da-Q0911** — Tom løb om kap med Mary ned ad bakken.

Tom raced Mary down the hill.

Why: Prepositions. [[Danish#^da-Q0911|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20l%C3%B8b%20om%20kap%20med%20Mary%20ned%20ad%20bakken.)
^da-Q0911-answer

**da-Q0912** — Tom løb om kap med Mary ned ad bakken.

Tom raced Mary down the hill.

Prepositions encode relations and belong to learned phrases. A location choice between i and på cannot always be predicted from English in/on.

Why: Prepositions. [[Danish#^da-Q0912|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20l%C3%B8b%20om%20kap%20med%20Mary%20ned%20ad%20bakken.)
^da-Q0912-answer

**da-Q0913** — Jeg kører aldrig bil i alkoholpåvirket tilstand.

I don't ever drink and drive.

Expected form: **i**

Why: Prepositions. [[Danish#^da-Q0913|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20k%C3%B8rer%20aldrig%20bil%20i%20alkoholp%C3%A5virket%20tilstand.)
^da-Q0913-answer

**da-Q0914** — Jeg kører aldrig bil i alkoholpåvirket tilstand.

I don't ever drink and drive.

Expected form: **i**

Why: Prepositions. [[Danish#^da-Q0914|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20k%C3%B8rer%20aldrig%20bil%20i%20alkoholp%C3%A5virket%20tilstand.)
^da-Q0914-answer

**da-Q0915** — Han sammenlignede kopien med originalen.

He compared the copy with the original.

Expected form: **med**

Why: Prepositions. [[Danish#^da-Q0915|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Han%20sammenlignede%20kopien%20med%20originalen.)
^da-Q0915-answer

**da-Q0916** — Han sammenlignede kopien med originalen.

He compared the copy with the original.

Why: Prepositions. [[Danish#^da-Q0916|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Han%20sammenlignede%20kopien%20med%20originalen.)
^da-Q0916-answer

**da-Q0917** — Lad mig spise i fred.

Let me eat in peace.

Why: Prepositions. [[Danish#^da-Q0917|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Lad%20mig%20spise%20i%20fred.)
^da-Q0917-answer

**da-Q0918** — Lad mig spise i fred.

Let me eat in peace.

Prepositions encode relations and belong to learned phrases. A location choice between i and på cannot always be predicted from English in/on.

Why: Prepositions. [[Danish#^da-Q0918|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Lad%20mig%20spise%20i%20fred.)
^da-Q0918-answer

**da-Q0919** — Tom er gift med Marys lillesøster.

Tom is married to Mary's younger sister.

Expected form: **med**

Why: Prepositions. [[Danish#^da-Q0919|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20er%20gift%20med%20Marys%20lilles%C3%B8ster.)
^da-Q0919-answer

**da-Q0920** — Tom er gift med Marys lillesøster.

Tom is married to Mary's younger sister.

Expected form: **med**

Why: Prepositions. [[Danish#^da-Q0920|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20er%20gift%20med%20Marys%20lilles%C3%B8ster.)
^da-Q0920-answer

**da-Q0921** — Facebook er blokeret i Kina.

Facebook is blocked in China.

Expected form: **i**

Why: Prepositions. [[Danish#^da-Q0921|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Facebook%20er%20blokeret%20i%20Kina.)
^da-Q0921-answer

**da-Q0922** — Facebook er blokeret i Kina.

Facebook is blocked in China.

Why: Prepositions. [[Danish#^da-Q0922|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Facebook%20er%20blokeret%20i%20Kina.)
^da-Q0922-answer

**da-Q0923** — Markerne var dækket af et tykt lag sne.

The fields lay covered with deep snow.

Why: Prepositions. [[Danish#^da-Q0923|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Markerne%20var%20d%C3%A6kket%20af%20et%20tykt%20lag%20sne.)
^da-Q0923-answer

**da-Q0924** — Markerne var dækket af et tykt lag sne.

The fields lay covered with deep snow.

Prepositions encode relations and belong to learned phrases. A location choice between i and på cannot always be predicted from English in/on.

Why: Prepositions. [[Danish#^da-Q0924|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Markerne%20var%20d%C3%A6kket%20af%20et%20tykt%20lag%20sne.)
^da-Q0924-answer

**da-Q0925** — Der er ingen post i postkassen.

There's no mail in the mailbox.

Expected form: **i**

Why: Prepositions. [[Danish#^da-Q0925|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Der%20er%20ingen%20post%20i%20postkassen.)
^da-Q0925-answer

**da-Q0926** — Der er ingen post i postkassen.

There's no mail in the mailbox.

Expected form: **i**

Why: Prepositions. [[Danish#^da-Q0926|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Der%20er%20ingen%20post%20i%20postkassen.)
^da-Q0926-answer

**da-Q0927** — Det er koldt i dag!

It's cold today.

Expected form: **i**

Why: Prepositions. [[Danish#^da-Q0927|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Det%20er%20koldt%20i%20dag%21)
^da-Q0927-answer

**da-Q0928** — Det er koldt i dag!

It's cold today.

Why: Prepositions. [[Danish#^da-Q0928|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Det%20er%20koldt%20i%20dag%21)
^da-Q0928-answer

**da-Q0929** — Landsbyerne i Alperne er meget pittoreske.

The villages in the Alps are very picturesque.

Why: Prepositions. [[Danish#^da-Q0929|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Landsbyerne%20i%20Alperne%20er%20meget%20pittoreske.)
^da-Q0929-answer

**da-Q0930** — Landsbyerne i Alperne er meget pittoreske.

The villages in the Alps are very picturesque.

Prepositions encode relations and belong to learned phrases. A location choice between i and på cannot always be predicted from English in/on.

Why: Prepositions. [[Danish#^da-Q0930|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Landsbyerne%20i%20Alperne%20er%20meget%20pittoreske.)
^da-Q0930-answer

**da-Q0931** — Tom spiste de tre æbler på under fem minutter.

Tom ate the three apples in less than five minutes.

Expected form: **på**

Why: Prepositions. [[Danish#^da-Q0931|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20spiste%20de%20tre%20%C3%A6bler%20p%C3%A5%20under%20fem%20minutter.)
^da-Q0931-answer

**da-Q0932** — Tom spiste de tre æbler på under fem minutter.

Tom ate the three apples in less than five minutes.

Expected form: **på**

Why: Prepositions. [[Danish#^da-Q0932|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20spiste%20de%20tre%20%C3%A6bler%20p%C3%A5%20under%20fem%20minutter.)
^da-Q0932-answer

**da-Q0933** — Bogen ligger på bordet.

The book is on the table.

Expected form: **på**

Why: Prepositions. [[Danish#^da-Q0933|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Bogen%20ligger%20p%C3%A5%20bordet.)
^da-Q0933-answer

**da-Q0934** — Bogen ligger på bordet.

The book is on the table.

Why: Prepositions. [[Danish#^da-Q0934|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Bogen%20ligger%20p%C3%A5%20bordet.)
^da-Q0934-answer

**da-Q0935** — Han skrev en bog i Kina.

He wrote a book in China.

Why: Prepositions. [[Danish#^da-Q0935|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Han%20skrev%20en%20bog%20i%20Kina.)
^da-Q0935-answer

**da-Q0936** — Han skrev en bog i Kina.

He wrote a book in China.

Prepositions encode relations and belong to learned phrases. A location choice between i and på cannot always be predicted from English in/on.

Why: Prepositions. [[Danish#^da-Q0936|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Han%20skrev%20en%20bog%20i%20Kina.)
^da-Q0936-answer

**da-Q0937** — Vi er kabylere, fra Kabylien, Algeriet.

We are Kabyles, from Kabylie, Algeria.

Expected form: **fra**

Why: Prepositions. [[Danish#^da-Q0937|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Vi%20er%20kabylere%2C%20fra%20Kabylien%2C%20Algeriet.)
^da-Q0937-answer

**da-Q0938** — Vi er kabylere, fra Kabylien, Algeriet.

We are Kabyles, from Kabylie, Algeria.

Expected form: **fra**

Why: Prepositions. [[Danish#^da-Q0938|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Vi%20er%20kabylere%2C%20fra%20Kabylien%2C%20Algeriet.)
^da-Q0938-answer

**da-Q0939** — Disse sommerfugle er sjældne i vort land.

These butterflies are rare in our country.

Expected form: **i**

Why: Prepositions. [[Danish#^da-Q0939|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Disse%20sommerfugle%20er%20sj%C3%A6ldne%20i%20vort%20land.)
^da-Q0939-answer

**da-Q0940** — Disse sommerfugle er sjældne i vort land.

These butterflies are rare in our country.

Why: Prepositions. [[Danish#^da-Q0940|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Disse%20sommerfugle%20er%20sj%C3%A6ldne%20i%20vort%20land.)
^da-Q0940-answer

**da-Q0941** — Sami kørte på den motorcykel.

Sami was riding that motorbike.

Why: Prepositions. [[Danish#^da-Q0941|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Sami%20k%C3%B8rte%20p%C3%A5%20den%20motorcykel.)
^da-Q0941-answer

**da-Q0942** — Sami kørte på den motorcykel.

Sami was riding that motorbike.

Prepositions encode relations and belong to learned phrases. A location choice between i and på cannot always be predicted from English in/on.

Why: Prepositions. [[Danish#^da-Q0942|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Sami%20k%C3%B8rte%20p%C3%A5%20den%20motorcykel.)
^da-Q0942-answer

**da-Q0943** — Du er på tynd is.

You're treading on thin ice.

Expected form: **på**

Why: Prepositions. [[Danish#^da-Q0943|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Du%20er%20p%C3%A5%20tynd%20is.)
^da-Q0943-answer

**da-Q0944** — Du er på tynd is.

You're treading on thin ice.

Expected form: **på**

Why: Prepositions. [[Danish#^da-Q0944|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Du%20er%20p%C3%A5%20tynd%20is.)
^da-Q0944-answer

**da-Q0945** — Tom blev forelsket i en smuk ung kvinde.

Tom fell in love with a beautiful young woman.

Expected form: **i**

Why: Prepositions. [[Danish#^da-Q0945|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20blev%20forelsket%20i%20en%20smuk%20ung%20kvinde.)
^da-Q0945-answer

**da-Q0946** — Tom blev forelsket i en smuk ung kvinde.

Tom fell in love with a beautiful young woman.

Why: Prepositions. [[Danish#^da-Q0946|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20blev%20forelsket%20i%20en%20smuk%20ung%20kvinde.)
^da-Q0946-answer

**da-Q0947** — Jeg skriver en sætning på tysk.

I'm going to write a sentence in German.

Why: Prepositions. [[Danish#^da-Q0947|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20skriver%20en%20s%C3%A6tning%20p%C3%A5%20tysk.)
^da-Q0947-answer

**da-Q0948** — Jeg skriver en sætning på tysk.

I'm going to write a sentence in German.

Prepositions encode relations and belong to learned phrases. A location choice between i and på cannot always be predicted from English in/on.

Why: Prepositions. [[Danish#^da-Q0948|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20skriver%20en%20s%C3%A6tning%20p%C3%A5%20tysk.)
^da-Q0948-answer

**da-Q0949** — Tom åbnede døren på klem.

Tom opened the door just a crack.

Expected form: **på**

Why: Prepositions. [[Danish#^da-Q0949|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20%C3%A5bnede%20d%C3%B8ren%20p%C3%A5%20klem.)
^da-Q0949-answer

**da-Q0950** — Tom åbnede døren på klem.

Tom opened the door just a crack.

Expected form: **på**

Why: Prepositions. [[Danish#^da-Q0950|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20%C3%A5bnede%20d%C3%B8ren%20p%C3%A5%20klem.)
^da-Q0950-answer


### Answers 951–1000

**da-Q0951** — Tom er måske lun på dig.

Tom may have a crush on you.

Expected form: **måske**

Why: Concession and inference. [[Danish#^da-Q0951|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20er%20m%C3%A5ske%20lun%20p%C3%A5%20dig.)
^da-Q0951-answer

**da-Q0952** — Tom er måske lun på dig.

Tom may have a crush on you.

Why: Concession and inference. [[Danish#^da-Q0952|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20er%20m%C3%A5ske%20lun%20p%C3%A5%20dig.)
^da-Q0952-answer

**da-Q0953** — Politiet tror at Tom måske har forgiftet Mary.

The police think that Tom might've poisoned Mary.

Why: Concession and inference. [[Danish#^da-Q0953|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Politiet%20tror%20at%20Tom%20m%C3%A5ske%20har%20forgiftet%20Mary.)
^da-Q0953-answer

**da-Q0954** — Politiet tror at Tom måske har forgiftet Mary.

The police think that Tom might've poisoned Mary.

Selvom introduces concession; alligevel means nevertheless; derfor supplies a consequence; måske limits certainty. Connectors carry argument meaning as well as clause structure.

Why: Concession and inference. [[Danish#^da-Q0954|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Politiet%20tror%20at%20Tom%20m%C3%A5ske%20har%20forgiftet%20Mary.)
^da-Q0954-answer

**da-Q0955** — Det er måske en skør ide, men jeg synes at vi burde besøge Tom og Mary lige nu.

It may seem like a crazy idea, but I think we should go visit Tom and Mary right now.

Expected form: **måske**

Why: Concession and inference. [[Danish#^da-Q0955|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Det%20er%20m%C3%A5ske%20en%20sk%C3%B8r%20ide%2C%20men%20jeg%20synes%20at%20vi%20burde%20bes%C3%B8ge%20Tom%20og%20Mary%20lige%20nu.)
^da-Q0955-answer

**da-Q0956** — Det er måske en skør ide, men jeg synes at vi burde besøge Tom og Mary lige nu.

It may seem like a crazy idea, but I think we should go visit Tom and Mary right now.

Expected form: **måske**

Why: Concession and inference. [[Danish#^da-Q0956|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Det%20er%20m%C3%A5ske%20en%20sk%C3%B8r%20ide%2C%20men%20jeg%20synes%20at%20vi%20burde%20bes%C3%B8ge%20Tom%20og%20Mary%20lige%20nu.)
^da-Q0956-answer

**da-Q0957** — Tom blev ved med at køre helt op bag ved bilen foran os selvom jeg fortalte ham at det kunne være farligt at gøre det.

Tom kept tailgating the car in front of us even though I told him it was unsafe to do so.

Expected form: **selvom**

Why: Concession and inference. [[Danish#^da-Q0957|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20blev%20ved%20med%20at%20k%C3%B8re%20helt%20op%20bag%20ved%20bilen%20foran%20os%20selvom%20jeg%20fortalte%20ham%20at%20det%20kunne%20v%C3%A6re%20farligt%20at%20g%C3%B8re%20det.)
^da-Q0957-answer

**da-Q0958** — Tom blev ved med at køre helt op bag ved bilen foran os selvom jeg fortalte ham at det kunne være farligt at gøre det.

Tom kept tailgating the car in front of us even though I told him it was unsafe to do so.

Why: Concession and inference. [[Danish#^da-Q0958|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20blev%20ved%20med%20at%20k%C3%B8re%20helt%20op%20bag%20ved%20bilen%20foran%20os%20selvom%20jeg%20fortalte%20ham%20at%20det%20kunne%20v%C3%A6re%20farligt%20at%20g%C3%B8re%20det.)
^da-Q0958-answer

**da-Q0959** — Kampen vil blive spillet selvom det regner.

The game will be held even if it rains.

Why: Concession and inference. [[Danish#^da-Q0959|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Kampen%20vil%20blive%20spillet%20selvom%20det%20regner.)
^da-Q0959-answer

**da-Q0960** — Kampen vil blive spillet selvom det regner.

The game will be held even if it rains.

Selvom introduces concession; alligevel means nevertheless; derfor supplies a consequence; måske limits certainty. Connectors carry argument meaning as well as clause structure.

Why: Concession and inference. [[Danish#^da-Q0960|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Kampen%20vil%20blive%20spillet%20selvom%20det%20regner.)
^da-Q0960-answer

**da-Q0961** — Du har måske hørt om mig.

You might have heard of me.

Expected form: **måske**

Why: Concession and inference. [[Danish#^da-Q0961|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Du%20har%20m%C3%A5ske%20h%C3%B8rt%20om%20mig.)
^da-Q0961-answer

**da-Q0962** — Du har måske hørt om mig.

You might have heard of me.

Expected form: **måske**

Why: Concession and inference. [[Danish#^da-Q0962|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Du%20har%20m%C3%A5ske%20h%C3%B8rt%20om%20mig.)
^da-Q0962-answer

**da-Q0963** — Det vil måske regne i aften.

It may rain tonight.

Expected form: **måske**

Why: Concession and inference. [[Danish#^da-Q0963|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Det%20vil%20m%C3%A5ske%20regne%20i%20aften.)
^da-Q0963-answer

**da-Q0964** — Det vil måske regne i aften.

It may rain tonight.

Why: Concession and inference. [[Danish#^da-Q0964|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Det%20vil%20m%C3%A5ske%20regne%20i%20aften.)
^da-Q0964-answer

**da-Q0965** — Er det derfor at Tom gerne ville tale med dig?

Is that why Tom wanted to talk to you?

Why: Concession and inference. [[Danish#^da-Q0965|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Er%20det%20derfor%20at%20Tom%20gerne%20ville%20tale%20med%20dig%3F)
^da-Q0965-answer

**da-Q0966** — Er det derfor at Tom gerne ville tale med dig?

Is that why Tom wanted to talk to you?

Selvom introduces concession; alligevel means nevertheless; derfor supplies a consequence; måske limits certainty. Connectors carry argument meaning as well as clause structure.

Why: Concession and inference. [[Danish#^da-Q0966|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Er%20det%20derfor%20at%20Tom%20gerne%20ville%20tale%20med%20dig%3F)
^da-Q0966-answer

**da-Q0967** — Problemet med rotteræset er, at selvom du vinder, er du stadig en rotte.

The trouble with the rat race is that even if you win, you're still a rat.

Expected form: **selvom**

Why: Concession and inference. [[Danish#^da-Q0967|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Problemet%20med%20rotter%C3%A6set%20er%2C%20at%20selvom%20du%20vinder%2C%20er%20du%20stadig%20en%20rotte.)
^da-Q0967-answer

**da-Q0968** — Problemet med rotteræset er, at selvom du vinder, er du stadig en rotte.

The trouble with the rat race is that even if you win, you're still a rat.

Expected form: **selvom**

Why: Concession and inference. [[Danish#^da-Q0968|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Problemet%20med%20rotter%C3%A6set%20er%2C%20at%20selvom%20du%20vinder%2C%20er%20du%20stadig%20en%20rotte.)
^da-Q0968-answer

**da-Q0969** — Som regel taler mine forældre med hinanden på fransk, selvom min mor har engelsk som modersmål.

My parents usually speak to each other in French, even though my mother is a native English speaker.

Expected form: **selvom**

Why: Concession and inference. [[Danish#^da-Q0969|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Som%20regel%20taler%20mine%20for%C3%A6ldre%20med%20hinanden%20p%C3%A5%20fransk%2C%20selvom%20min%20mor%20har%20engelsk%20som%20modersm%C3%A5l.)
^da-Q0969-answer

**da-Q0970** — Som regel taler mine forældre med hinanden på fransk, selvom min mor har engelsk som modersmål.

My parents usually speak to each other in French, even though my mother is a native English speaker.

Why: Concession and inference. [[Danish#^da-Q0970|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Som%20regel%20taler%20mine%20for%C3%A6ldre%20med%20hinanden%20p%C3%A5%20fransk%2C%20selvom%20min%20mor%20har%20engelsk%20som%20modersm%C3%A5l.)
^da-Q0970-answer

**da-Q0971** — Så sagtn dog farten!

Hey, slow down!

Why: Concession and inference. [[Danish#^da-Q0971|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=S%C3%A5%20sagtn%20dog%20farten%21)
^da-Q0971-answer

**da-Q0972** — Så sagtn dog farten!

Hey, slow down!

Selvom introduces concession; alligevel means nevertheless; derfor supplies a consequence; måske limits certainty. Connectors carry argument meaning as well as clause structure.

Why: Concession and inference. [[Danish#^da-Q0972|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=S%C3%A5%20sagtn%20dog%20farten%21)
^da-Q0972-answer

**da-Q0973** — Han gav mig kaffe, selvom jeg havde bedt om te.

He gave me coffee even though I had asked for tea.

Expected form: **selvom**

Why: Concession and inference. [[Danish#^da-Q0973|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Han%20gav%20mig%20kaffe%2C%20selvom%20jeg%20havde%20bedt%20om%20te.)
^da-Q0973-answer

**da-Q0974** — Han gav mig kaffe, selvom jeg havde bedt om te.

He gave me coffee even though I had asked for tea.

Expected form: **selvom**

Why: Concession and inference. [[Danish#^da-Q0974|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Han%20gav%20mig%20kaffe%2C%20selvom%20jeg%20havde%20bedt%20om%20te.)
^da-Q0974-answer

**da-Q0975** — Mine meninger har måske ændret sig, men ikke det faktum at jeg har ret.

My opinions may have changed, but not the fact that I'm right.

Expected form: **måske**

Why: Concession and inference. [[Danish#^da-Q0975|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Mine%20meninger%20har%20m%C3%A5ske%20%C3%A6ndret%20sig%2C%20men%20ikke%20det%20faktum%20at%20jeg%20har%20ret.)
^da-Q0975-answer

**da-Q0976** — Mine meninger har måske ændret sig, men ikke det faktum at jeg har ret.

My opinions may have changed, but not the fact that I'm right.

Why: Concession and inference. [[Danish#^da-Q0976|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Mine%20meninger%20har%20m%C3%A5ske%20%C3%A6ndret%20sig%2C%20men%20ikke%20det%20faktum%20at%20jeg%20har%20ret.)
^da-Q0976-answer

**da-Q0977** — Det regner måske i aften.

It may rain tonight.

Why: Concession and inference. [[Danish#^da-Q0977|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Det%20regner%20m%C3%A5ske%20i%20aften.)
^da-Q0977-answer

**da-Q0978** — Det regner måske i aften.

It may rain tonight.

Selvom introduces concession; alligevel means nevertheless; derfor supplies a consequence; måske limits certainty. Connectors carry argument meaning as well as clause structure.

Why: Concession and inference. [[Danish#^da-Q0978|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Det%20regner%20m%C3%A5ske%20i%20aften.)
^da-Q0978-answer

**da-Q0979** — Hun kommer måske.

She might come.

Expected form: **måske**

Why: Concession and inference. [[Danish#^da-Q0979|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hun%20kommer%20m%C3%A5ske.)
^da-Q0979-answer

**da-Q0980** — Hun kommer måske.

She might come.

Expected form: **måske**

Why: Concession and inference. [[Danish#^da-Q0980|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hun%20kommer%20m%C3%A5ske.)
^da-Q0980-answer

**da-Q0981** — Tom vil måske vidne.

Tom might testify.

Expected form: **måske**

Why: Concession and inference. [[Danish#^da-Q0981|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20vil%20m%C3%A5ske%20vidne.)
^da-Q0981-answer

**da-Q0982** — Tom vil måske vidne.

Tom might testify.

Why: Concession and inference. [[Danish#^da-Q0982|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Tom%20vil%20m%C3%A5ske%20vidne.)
^da-Q0982-answer

**da-Q0983** — Han er meget klog og alligevel ikke arrogant.

He is very smart and yet not arrogant.

Why: Concession and inference. [[Danish#^da-Q0983|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Han%20er%20meget%20klog%20og%20alligevel%20ikke%20arrogant.)
^da-Q0983-answer

**da-Q0984** — Han er meget klog og alligevel ikke arrogant.

He is very smart and yet not arrogant.

Selvom introduces concession; alligevel means nevertheless; derfor supplies a consequence; måske limits certainty. Connectors carry argument meaning as well as clause structure.

Why: Concession and inference. [[Danish#^da-Q0984|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Han%20er%20meget%20klog%20og%20alligevel%20ikke%20arrogant.)
^da-Q0984-answer

**da-Q0985** — Jeg tænker, derfor er jeg.

I think, therefore I am.

Expected form: **derfor**

Why: Concession and inference. [[Danish#^da-Q0985|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20t%C3%A6nker%2C%20derfor%20er%20jeg.)
^da-Q0985-answer

**da-Q0986** — Jeg tænker, derfor er jeg.

I think, therefore I am.

Expected form: **derfor**

Why: Concession and inference. [[Danish#^da-Q0986|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20t%C3%A6nker%2C%20derfor%20er%20jeg.)
^da-Q0986-answer

**da-Q0987** — Han åbnede døren, selvom jeg bad ham lade være.

He opened the door, though I told him not to.

Expected form: **selvom**

Why: Concession and inference. [[Danish#^da-Q0987|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Han%20%C3%A5bnede%20d%C3%B8ren%2C%20selvom%20jeg%20bad%20ham%20lade%20v%C3%A6re.)
^da-Q0987-answer

**da-Q0988** — Han åbnede døren, selvom jeg bad ham lade være.

He opened the door, though I told him not to.

Why: Concession and inference. [[Danish#^da-Q0988|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Han%20%C3%A5bnede%20d%C3%B8ren%2C%20selvom%20jeg%20bad%20ham%20lade%20v%C3%A6re.)
^da-Q0988-answer

**da-Q0989** — Brødet var muggent, men Tom spiste det alligevel.

The bread was moldy, but Tom ate it anyway.

Why: Concession and inference. [[Danish#^da-Q0989|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Br%C3%B8det%20var%20muggent%2C%20men%20Tom%20spiste%20det%20alligevel.)
^da-Q0989-answer

**da-Q0990** — Brødet var muggent, men Tom spiste det alligevel.

The bread was moldy, but Tom ate it anyway.

Selvom introduces concession; alligevel means nevertheless; derfor supplies a consequence; måske limits certainty. Connectors carry argument meaning as well as clause structure.

Why: Concession and inference. [[Danish#^da-Q0990|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Br%C3%B8det%20var%20muggent%2C%20men%20Tom%20spiste%20det%20alligevel.)
^da-Q0990-answer

**da-Q0991** — Det er derfor han blev vred.

That's why he got angry.

Expected form: **derfor**

Why: Concession and inference. [[Danish#^da-Q0991|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Det%20er%20derfor%20han%20blev%20vred.)
^da-Q0991-answer

**da-Q0992** — Det er derfor han blev vred.

That's why he got angry.

Expected form: **derfor**

Why: Concession and inference. [[Danish#^da-Q0992|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Det%20er%20derfor%20han%20blev%20vred.)
^da-Q0992-answer

**da-Q0993** — Problemet er ikke så simpelt som det måske kan synes ved første øjekast.

The problem is not as simple as it might seem at first sight.

Expected form: **måske**

Why: Concession and inference. [[Danish#^da-Q0993|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Problemet%20er%20ikke%20s%C3%A5%20simpelt%20som%20det%20m%C3%A5ske%20kan%20synes%20ved%20f%C3%B8rste%20%C3%B8jekast.)
^da-Q0993-answer

**da-Q0994** — Problemet er ikke så simpelt som det måske kan synes ved første øjekast.

The problem is not as simple as it might seem at first sight.

Why: Concession and inference. [[Danish#^da-Q0994|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Problemet%20er%20ikke%20s%C3%A5%20simpelt%20som%20det%20m%C3%A5ske%20kan%20synes%20ved%20f%C3%B8rste%20%C3%B8jekast.)
^da-Q0994-answer

**da-Q0995** — Hvis noget er et æble, så er det enten rødt eller grønt eller måske begge dele.

If something is an apple, then it's either red or green, or possibly both.

Why: Concession and inference. [[Danish#^da-Q0995|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hvis%20noget%20er%20et%20%C3%A6ble%2C%20s%C3%A5%20er%20det%20enten%20r%C3%B8dt%20eller%20gr%C3%B8nt%20eller%20m%C3%A5ske%20begge%20dele.)
^da-Q0995-answer

**da-Q0996** — Hvis noget er et æble, så er det enten rødt eller grønt eller måske begge dele.

If something is an apple, then it's either red or green, or possibly both.

Selvom introduces concession; alligevel means nevertheless; derfor supplies a consequence; måske limits certainty. Connectors carry argument meaning as well as clause structure.

Why: Concession and inference. [[Danish#^da-Q0996|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hvis%20noget%20er%20et%20%C3%A6ble%2C%20s%C3%A5%20er%20det%20enten%20r%C3%B8dt%20eller%20gr%C3%B8nt%20eller%20m%C3%A5ske%20begge%20dele.)
^da-Q0996-answer

**da-Q0997** — Jeg har måske ikke en universitetsgrad, men jeg er ikke komplet idiot.

I may not have a degree, but I'm not entirely stupid.

Expected form: **måske**

Why: Concession and inference. [[Danish#^da-Q0997|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20har%20m%C3%A5ske%20ikke%20en%20universitetsgrad%2C%20men%20jeg%20er%20ikke%20komplet%20idiot.)
^da-Q0997-answer

**da-Q0998** — Jeg har måske ikke en universitetsgrad, men jeg er ikke komplet idiot.

I may not have a degree, but I'm not entirely stupid.

Expected form: **måske**

Why: Concession and inference. [[Danish#^da-Q0998|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Jeg%20har%20m%C3%A5ske%20ikke%20en%20universitetsgrad%2C%20men%20jeg%20er%20ikke%20komplet%20idiot.)
^da-Q0998-answer

**da-Q0999** — Hvad der skræmte Tom mest, var tanken om at han måske ikke kunne komme til at gå igen.

What scared Tom the most was the thought that he might not be able to walk again.

Expected form: **måske**

Why: Concession and inference. [[Danish#^da-Q0999|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hvad%20der%20skr%C3%A6mte%20Tom%20mest%2C%20var%20tanken%20om%20at%20han%20m%C3%A5ske%20ikke%20kunne%20komme%20til%20at%20g%C3%A5%20igen.)
^da-Q0999-answer

**da-Q1000** — Hvad der skræmte Tom mest, var tanken om at han måske ikke kunne komme til at gå igen.

What scared Tom the most was the thought that he might not be able to walk again.

Why: Concession and inference. [[Danish#^da-Q1000|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=dan&query=Hvad%20der%20skr%C3%A6mte%20Tom%20mest%2C%20var%20tanken%20om%20at%20han%20m%C3%A5ske%20ikke%20kunne%20komme%20til%20at%20g%C3%A5%20igen.)
^da-Q1000-answer


## Read and speak

Read the native sentence first, identify its predicate and one grammar form, then check the translation. Say it aloud and change one detail.

### Learning with a clear purpose

Jeg lærer et nyt sprog. Hver dag læser jeg en kort tekst og lytter til tydelige eksempler. Jeg skriver nyttige ord i en notesbog. Når jeg laver en fejl, ser jeg på reglen og prøver igen. Mit mål er at forstå mennesker og udtrykke mine tanker klart.

I am learning a new language. Each day, I read a short text and listen to clear examples. I write useful words in a notebook. When I make a mistake, I check the rule and try again. My goal is to understand people and express my ideas clearly.

![[Resources/Audio/da/Reading passage.mp3]]

**Tom kan endnu ikke køre bil.**

Tom can't drive a car yet.

**Vi kender ham ikke.**

We don't know him.

**Tom havde al ret til at gøre, hvad han gjorde.**

Tom had every right to do what he did.

**Mørke er fravær af lys.**

Darkness is the absence of light.

**"Oh, var jeg dog sådant et stort træ, som de andre!" sukkede det lille grantræ.**

"Oh, if I were only as great a tree as the others!" sighed the little Fir.

**Marathi er navnet på et vigtigt indoarisk sprog, der tales i det vestlige og centrale Indien.**

Marathi is the name of an important Indo-Aryan language spoken in western and central India.

**Bærer din kone det muslimske tørklæde?**

Does your wife wear the Muslim headscarf?

**Jeg ville gøre alt for dig.**

I'd do anything for you.

**At fejle er menneskeligt, at tilgive er guddommeligt.**

To err is human; to forgive, divine.

**Brug aldrig dine penge, før du har tjent dem.**

Never spend your money before you have earned it.

**Det er aldrig sket for mig; bank under bordet.**

That has never happened to me, touch wood.

**Dette er en offentlig gade, ikke en væddeløbsbane!**

This is a public street, not a racetrack.

**De begravede hende.**

They buried her.

**Jeg sagde godnat til ham.**

I told him good night.

**Dette er deres hus.**

This is their house.

## Professional writing

Write an introduction, a polite request, an explanation of a finding, a summary of a passage and a tactful disagreement. Use the professional/advanced lessons for models.

## PDF edition

[[Resources/PDFs/Danish.pdf|Open the complete printable book]]
