# Spanish study

[[Spanish|Open the complete Spanish course note]]

Audio and the printable PDF are in Resources. This vault contains one language.

[[Sources and licenses]]
