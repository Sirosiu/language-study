# Spanish

Near-native ambition - C2-oriented study

Everything for this language is in this note. Open a rule, read its examples and follow its practice link. Answers stay in this same note.

[[Start Here|All languages]] · [[Sources and licenses|Sources]]

## Start reading

### el abecedario / el alfabeto

| Written form | Name / reading | Related forms |
|---|---|---|
| A a | a  |  ·  ·  |
| B b | be  |  ·  ·  |
| C c | ce  |  ·  ·  |
| D d | de  |  ·  ·  |
| E e | e  |  ·  ·  |
| F f | efe  |  ·  ·  |
| G g | ge  |  ·  ·  |
| H h | hache  |  ·  ·  |
| I i | i  |  ·  ·  |
| J j | jota  |  ·  ·  |
| K k | ka  |  ·  ·  |
| L l | ele  |  ·  ·  |
| M m | eme  |  ·  ·  |
| N n | ene  |  ·  ·  |
| Ñ ñ | eñe  |  ·  ·  |
| O o | o  |  ·  ·  |
| P p | pe  |  ·  ·  |
| Q q | cu  |  ·  ·  |
| R r | erre  |  ·  ·  |
| S s | ese  |  ·  ·  |
| T t | te  |  ·  ·  |
| U u | u  |  ·  ·  |
| V v | uve  |  ·  ·  |
| W w | uve doble  |  ·  ·  |
| X x | equis  |  ·  ·  |
| Y y | ye  |  ·  ·  |
| Z z | zeta  |  ·  ·  |

![[Resources/Audio/es/Script and first phrases.mp3]]

The player above is synthetic speech. Word tracks below work offline.

### All 27 letters

Ñ is a letter after N. ch and ll are digraphs, not separate letters in current alphabetical ordering. Letter names for b/v/w/y vary regionally. h is normally silent; j is a fricative whose realisation varies.

### Vowels and regional sounds

The five vowel phonemes are relatively stable. In much of Spain, c before e/i and z give /θ/; across Latin America and other regions they give /s/. b and v do not form the English /b/ versus /v/ contrast. ll/y pronunciation varies regionally.

### Stress and marks

Without an accent, words ending in a vowel, n or s normally stress the penultimate syllable; other endings normally stress the final syllable. Written accents override this: teléfono, café. Accent marks also distinguish some grammatical words: tú/tu, él/el, sí/si.

### Agree in a phrase

el libro nuevo → los libros nuevos; la casa blanca → las casas blancas. = the new book(s); the white house(s). Learn gender with el/la.

### Build a word family

hablar → hablante = speak → speaker; feliz → felicidad = happy → happiness; posible → imposible. Stem and accent changes are not always predictable.

### Build a question

¿Dónde está el libro? = Where is the book? Use opening and closing question/exclamation marks in formal writing. Spanish can omit a subject pronoun when the verb and context identify it.

**Buenos días.**

Good morning.

**Estoy aprendiendo español.**

I am learning Spanish.

**¿Puede repetirlo, por favor?**

Can you repeat it, please?

**¿Qué significa esta palabra?**

What does this word mean?

### Grammar terms in plain English

**Noun** — A word naming a person, thing or idea: student, book, freedom.

**Verb** — A word describing an action or state: read, know, be.

**Subject** — The participant linked to the main verb’s subject pattern. In The student reads a book, the student is the subject.

**Object** — A participant selected by a verb. In The student reads a book, a book is the direct object.

**Agreement** — One word changes to match another, for example an adjective matching a noun’s gender and number.

**Case** — A noun/pronoun form marking its relationship in a sentence. Cases can mark subjects, objects, possession or relations usually expressed by English prepositions.

**Gender** — A grammatical noun class. It does not always describe the sex of a person or any physical property.

**Tense** — A verb system that relates a situation to a time, often past or non-past.

**Aspect** — How a situation is viewed: unfolding, completed, habitual, experienced or in a resulting state.

**Infinitive** — A non-finite verb form often used for a dictionary entry or a complement. It does not by itself give the ordinary person/tense pattern.

**Participle** — A verb-derived form used in compound predicates or as a modifier; its exact function depends on the language and construction.

**Clause** — A unit organised around a predicate. One sentence can contain several clauses.

**Register** — Language choices suited to a situation: casual conversation, polite requests, academic writing or another context.

## Grammar, examples and practice

### Pronunciation, spelling and noun agreement

Spanish has a comparatively stable five-vowel system; avoid reducing unstressed vowels as strongly as in English. Lexical stress is predictable from spelling rules with written accents marking exceptions and some grammatical distinctions. The tap and trill contrast in pero/perro needs targeted audio practice. Many speakers use seseo, pronouncing z and soft c like s; much of Spain distinguishes them from s with /θ/. Yeísmo and regional variants of ll/y are widespread.
Articles and adjectives agree with nouns: el problema importante, la cuestión importante, los datos nuevos. Some feminine nouns with stressed initial /a/ take el immediately before them in singular: el agua fría. They remain feminine; una, adjectives and plural forms follow the appropriate rules. Noun endings are useful clues but not guarantees: el día, la mano.

**el agua fría / las aguas frías**

the cold water / the cold waters Agua remains feminine even when singular el is used.

**pero / perro**

but / dog A single tap contrasts with a trill in this word pair.

#### Articles and gender

Articles agree in gender and number. Learn el/la with the noun. El can also occur before a stressed initial a sound in some feminine singular nouns; the noun remains feminine.

**No han igualado la carretera.**

The road hasn't been leveled.

**Yo tengo un anillo.**

I have a ring.

![[Resources/Audio/es/Rule 01.mp3]]

[[Spanish#^es-Q0001|Practise this rule (50 questions)]]

#### Adjective agreement

Most adjectives agree with the noun. Some change only for number. Position and shortened forms can affect meaning: un buen libro versus el libro es bueno.

**Ésta si que va a ser buena.**

This is going to be swell.

**No puedo dejarte desembarcar sin darte un beso grande.**

I can't let you disembark without giving you a big kiss.

![[Resources/Audio/es/Rule 02.mp3]]

[[Spanish#^es-Q0051|Practise this rule (50 questions)]]

#### Question words

Question and exclamation words take written accents, including many indirect questions. Compare donde as a relative with dónde in a question. Use the opening question mark in standard writing.

**¿Por qué estabas enfadado conmigo?**

Why were you angry with me?

**¿Qué quieres decir con relativismo cultural?**

What do you mean by cultural relativism?

![[Resources/Audio/es/Rule 16.mp3]]

[[Spanish#^es-Q0751|Practise this rule (50 questions)]]

#### Contractions and prepositions

Al contracts a + el and del contracts de + el. Por and para encode different relationships, including route/cause versus purpose/recipient in common uses. Learn contrasts in complete phrases.

**Pruébalo por favor.**

Please have a try.

**¿Estarías de acuerdo con eso?**

Would you agree with that?

![[Resources/Audio/es/Rule 19.mp3]]

[[Spanish#^es-Q0901|Practise this rule (50 questions)]]

<details><summary>Correct: la problema difícil.</summary>

El problema difícil. Problema is masculine despite ending in -a.

</details>

<details><summary>Does seseo make a speaker’s Spanish incorrect?</summary>

No. It is standard across many Spanish-speaking communities.

</details>

### Ser, estar and past-time perspective

Ser and estar are not a simple permanent/temporary split. Ser identifies and characterises; estar often locates entities and presents states. Event location commonly uses ser: La reunión es en la biblioteca. Adjectives can change interpretation: es listo means clever; está listo means ready.
The preterite presents a bounded past event; the imperfect presents background, habit or an unfolding situation. Supe can mean found out, while sabía presents knowing as a state. The present perfect's relationship to a current time frame differs regionally; many Spain varieties use it for recent events within the current period, while many Latin American varieties prefer the preterite in more contexts. Do not mark a regional choice wrong merely because it differs from one textbook model.

**Cuando llegué, estaban trabajando.**

When I arrived, they were working. Preterite arrival against imperfect background.

**La conferencia es mañana; el edificio está cerca.**

The conference is tomorrow; the building is nearby. Event timing with ser; entity location with estar.

#### Ser forms

Ser identifies or characterises a referent and expresses many classifications. Do not reduce the distinction to permanent versus temporary; events and time also use ser.

**¿Es ésta tu cartera?**

Is this your wallet?

**Ésas no son vuestras sillas.**

Those are not your chairs.

![[Resources/Audio/es/Rule 03.mp3]]

[[Spanish#^es-Q0101|Practise this rule (50 questions)]]

#### Estar forms

Estar commonly locates entities and describes states or results. The same adjective with ser and estar can express different meanings. Estar plus gerund marks an ongoing situation.

**Tomás también está nervioso.**

Tom is nervous, too.

**¿Qué estáis haciendo vosotros dos?**

What are you two doing?

![[Resources/Audio/es/Rule 04.mp3]]

[[Spanish#^es-Q0151|Practise this rule (50 questions)]]

#### Existence with haber

Impersonal haber states existence: hay un libro. It normally remains singular in standard usage even with a plural following noun. It differs from locating a known referent with estar.

**Tom le dijo a Mary lo que había pasado.**

Tom told Mary what had happened.

**No hay escapatoria.**

There is no escape.

![[Resources/Audio/es/Rule 05.mp3]]

[[Spanish#^es-Q0201|Practise this rule (50 questions)]]

#### Present possession

Tener agrees with the subject and expresses possession. It also occurs in expressions such as tener hambre and tener que + infinitive. Spanish often omits an understood subject pronoun.

**Él tiene mucho pegue.**

He's got lots of sex appeal.

**No tienen ningún impacto sobre el ambiente.**

They have no impact on the environment.

![[Resources/Audio/es/Rule 06.mp3]]

[[Spanish#^es-Q0251|Practise this rule (50 questions)]]

#### Past background

The imperfect typically presents background, a past state or a habit. A preterite presents an event as bounded in its narrative frame. The difference is viewpoint, not a simple long/short duration rule.

**Ella estaba profundamente emocionada.**

She was deeply moved.

**Los antiguos egipcios creían que el Sol era el ojo del dios Ra.**

The ancient Egyptians believed that the Sun was the eye of the god Ra.

![[Resources/Audio/es/Rule 07.mp3]]

[[Spanish#^es-Q0301|Practise this rule (50 questions)]]

#### Bounded past forms

The preterite presents past events as bounded. Fue may be a form of ser or ir; context determines the verb. Common irregular forms need direct practice in sentences.

**Él me dio todo pero no aceptó nada a cambio.**

He gave me everything but took nothing in return.

**La primera máquina imprenta fue inventada por Gutenberg.**

The first printing machine was invented by Gutenberg.

![[Resources/Audio/es/Rule 08.mp3]]

[[Spanish#^es-Q0351|Practise this rule (50 questions)]]

#### Progressive constructions

Estar + gerund focuses on an ongoing action. Spanish does not use the progressive in all situations where English does. A gerund can also appear with other verbs or as an adverbial.

**«Solo estaba hablando con él.» «¿Hablando con él de qué?» «Eso no es asunto tuyo.»**

"I was just talking to him." "Talking to him about what?" "That's none of your business."

**¿Por qué Tom sigue haciendo eso?**

Why's Tom still doing that?

![[Resources/Audio/es/Rule 11.mp3]]

[[Spanish#^es-Q0501|Practise this rule (50 questions)]]

<details><summary>Contrast era interesante and fue interesante.</summary>

The imperfect frames interest as background or ongoing description; the preterite presents the experience as bounded in context.

</details>

<details><summary>Translate She is ready with estar.</summary>

Está lista. Subject can be omitted when context identifies her.

</details>

### Pronouns, clitics and relative clauses

Object pronouns normally precede a finite verb and can attach to an infinitive, gerund or affirmative imperative in suitable constructions. Lo/la often mark direct objects, le indirect objects. Regional leísmo is nuanced; some uses are accepted in particular contexts, but learn a clear core system first. Before lo/la/los/las, le/les becomes se: se lo expliqué.
The personal a commonly marks specific human direct objects: vi a la profesora. It is not simply an indirect-object marker. Que is a flexible relative pronoun; quien and el cual have particular distributions, and cuyo agrees with the possessed noun: la autora cuyo libro leí. Track each pronoun's role rather than translating English who/which one-to-one.

**Se lo expliqué ayer.**

I explained it to him/her/them yesterday. Se replaces le/les before lo; context resolves the recipient.

**La investigadora cuyo artículo leí ...**

The researcher whose article I read ... Cuyo agrees with artículo, not investigadora.

#### Object pronouns

Lo/la/los/las generally mark direct objects; le/les generally mark indirect objects. Regional leísmo complicates some personal direct objects. Before lo/la/los/las, an indirect le/les becomes se.

**Tom no le creyó a Mary.**

Tom didn't believe Mary.

**Ha de haber alguna razón por lo que ha hecho.**

There must be some reason for what he has done.

![[Resources/Audio/es/Rule 12.mp3]]

[[Spanish#^es-Q0551|Practise this rule (50 questions)]]

#### Reflexive and other se

Se can mark reflexivity, reciprocal action, an impersonal/passive-like construction or an indirect object before a direct clitic. Decide from the verb and participants rather than treating all se alike.

**Tom se bebió un vaso de leche.**

Tom drank a glass of milk.

**¿Qué se puede encontrar más allá del final del universo?**

What can be found beyond the end of the universe?

![[Resources/Audio/es/Rule 13.mp3]]

[[Spanish#^es-Q0601|Practise this rule (50 questions)]]

#### Relative words

Relative words connect a clause to a referent. Cuyo agrees with the possessed noun, not the possessor. Que also introduces complement clauses; compare functions in the whole sentence.

**No puedo, a pesar que quiero.**

I can't even if I want to.

**No puedo creer que Tom aceptara nuestra oferta.**

I can't believe Tom accepted our offer.

![[Resources/Audio/es/Rule 14.mp3]]

[[Spanish#^es-Q0651|Practise this rule (50 questions)]]

<details><summary>Combine le + lo in Le expliqué el problema.</summary>

Se lo expliqué. The recipient remains represented by se; lo represents the problem.

</details>

<details><summary>Why is vi a la profesora not automatically an indirect-object sentence?</summary>

The personal a marks a human direct object here. Ver takes the person as what was seen.

</details>

### Subjunctive, stance and relative meaning

The subjunctive appears in constructions expressing desire, evaluation, doubt, purpose and certain nonasserted situations. Espero que venga; es importante que lo sepas. Do not equate it with an event being unreal. A factual concession may use aun­que with different moods depending on how information is framed. Standard indicative assertions and subjunctive framing differ in commitment and discourse status.
Relative clauses can distinguish a known identified entity from an unspecified sought one: busco un libro que explica esto suggests an identified kind or asserted property; busco un libro que explique esto presents the desired property without asserting an available example. Cuando + subjunctive commonly refers to a future pending event. Learn triggers with their meaning and context, not an indiscriminate list.

**Cuando termine el informe, te lo enviaré.**

When I finish the report, I will send it to you. Future pending completion takes subjunctive in the temporal clause.

**Busco una explicación que sea clara.**

I am looking for an explanation that is clear. The desired explanation is not presented as an identified existing one.

#### Subjunctive forms

Subjunctive selection depends on a governing expression and the status of the proposition. Wishes, evaluation, negation and non-specific relatives often matter. It is not merely a marker of anything uncertain.

**«Quiero que mi elfo oscuro sea azul.» «De acuerdo... Ése es morado. Serás morado esta semana.»**

"I want my dark elf to be blue." "OK... That one's purple. You'll be purple for this week."

**Recojan tantas monedas como sea posible.**

Collect as many coins as possible.

![[Resources/Audio/es/Rule 09.mp3]]

[[Spanish#^es-Q0401|Practise this rule (50 questions)]]

#### Negation

Spanish permits negative concord: No vi a nadie. A negative word before the verb normally makes a separate no unnecessary: Nadie vino. Concord does not cancel the negative meaning.

**Esa clase de cosas no puede encontrarse en cualquier parte.**

That kind of thing can't be found just anywhere.

**No nací sabiendo.**

I wasn't born knowing.

![[Resources/Audio/es/Rule 15.mp3]]

[[Spanish#^es-Q0701|Practise this rule (50 questions)]]

#### Conditions with si

Si has no accent when it means if or whether; sí means yes or emphatic affirmation. A real condition often uses present; an unreal one often uses imperfect subjunctive.

**Si yo hubiera sabido su dirección, le habría mandado una carta.**

If I had known her address, I would have written to her.

**Léela tú misma, si quieres.**

Read it yourself, if you like.

![[Resources/Audio/es/Rule 17.mp3]]

[[Spanish#^es-Q0801|Practise this rule (50 questions)]]

<details><summary>Complete: Es necesario que nosotros revis__ los datos.</summary>

Revisemos. Necessity frames the subordinate proposition in the subjunctive.

</details>

<details><summary>Why is subjunctive not simply imaginary grammar?</summary>

Factual content can be backgrounded or evaluated in subjunctive constructions. Mood also depends on construction and speaker stance.

</details>

### Conditionals, passive and impersonal se

Ordinary counterfactual si clauses use imperfect subjunctive with conditional: si tuviera tiempo, iría. Past counterfactuals use pluperfect subjunctive with conditional perfect: si lo hubiera sabido, habría esperado. The -ra and -se imperfect-subjunctive forms have overlapping standard uses with differences in some contexts.
The passive uses ser + participle with agreement, but se constructions are frequent. Se publicaron los resultados is a passive-like construction with plural agreement. Se entrevistó a los candidatos is impersonal with a-marked human object and singular verb in the core standard pattern. Do not assume every se sentence is reflexive. Estar + participle often describes a resulting state rather than the event passive.

**Si hubiéramos revisado el texto, habríamos encontrado el error.**

If we had reviewed the text, we would have found the error. Past counterfactual.

**Se publicaron los resultados.**

The results were published. Plural subject agreement in a passive se construction.

#### Conditional forms

The conditional can express a hypothetical result or politeness. A common unreal present pattern is si + imperfect subjunctive followed by conditional.

**Por favor, ¿Podría canjear estos cheques de viaje?**

Would you cash these travelers checks, please?

**Si fuera invisible no tendría que vestirme.**

If I were invisible I wouldn't have to dress myself.

![[Resources/Audio/es/Rule 10.mp3]]

[[Spanish#^es-Q0451|Practise this rule (50 questions)]]

<details><summary>Correct the ordinary conditional: Si tendría tiempo, iría.</summary>

Si tuviera tiempo, iría. Use imperfect subjunctive in the if-clause.

</details>

<details><summary>Contrast fue cerrado and estaba cerrado.</summary>

Fue cerrado presents a closing event in passive form; estaba cerrado presents the closed state.

</details>

### Aspectual constructions and argument connectors

Periphrases add aspect and stance: acabar de + infinitive for a recent completion in the relevant tense; seguir + gerund for continuation; volver a + infinitive for repetition; dejar de + infinitive for cessation. Their meaning is not obtained by translating each verb separately. Deber and deber de are associated with obligation and inference respectively, although actual usage overlaps.
Sin embargo contrasts; por tanto infers; aun así concedes despite a preceding point; en cambio sets a contrasting comparison. Spanish academic prose often allows long sentences, but clarity still depends on clause boundaries and explicit references. Use collocations such as plantear una hipótesis, llevar a cabo un estudio and llegar a una conclusión.

**El equipo sigue revisando los datos.**

The team is continuing to review the data. Seguir + gerund marks continuation.

**Los resultados son prometedores; aun así, hace falta confirmarlos.**

The results are promising; even so, they need confirmation. Concession prevents an overstrong conclusion.

#### Cause and concession

Porque supplies a reason; aunque introduces concession; por eso supplies a consequence. Aunque can take indicative or subjunctive according to how its content is presented.

**A la gente no le gusta trabajar con Tom porque es difícil llevarse bien con él.**

People don't like working with Tom because he's hard to get along with.

**Ya que estamos todos de acuerdo, empecemos la reunión.**

Now we all agree, let's start the meeting.

![[Resources/Audio/es/Rule 18.mp3]]

[[Spanish#^es-Q0851|Practise this rule (50 questions)]]

#### Comparison

Más/menos ... que compare. Tan ... como compares a quality; tanto ... como compares quantity and may require agreement. Mejor and peor are common irregular comparatives.

**Cuanto peor mejor.**

The worse the better.

**Sé tan poco como tú.**

I know as little as you do.

![[Resources/Audio/es/Rule 20.mp3]]

[[Spanish#^es-Q0951|Practise this rule (50 questions)]]

<details><summary>Express We stopped using that method.</summary>

Dejamos de usar ese método. Dejar de marks cessation.

</details>

<details><summary>Replace Esto prueba todo with a limited claim.</summary>

Estos datos apoyan la hipótesis, pero no descartan otras explicaciones. The conclusion stays evidentially limited.

</details>

### Advanced reading and discourse analysis

Original teaching passage: Una explicación puede resultar convincente sin que los datos disponibles la confirmen de manera concluyente. Por ello, conviene distinguir entre lo que se observa y lo que se infiere. Cuanto más claramente se describan las condiciones del estudio, más fácil será evaluar el alcance de sus conclusiones. Reconocer una limitación no equivale a rechazar todo el análisis.
Translation: An explanation can be convincing without the available data confirming it conclusively. Therefore, it is appropriate to distinguish what is observed from what is inferred. The more clearly the study conditions are described, the easier it will be to assess the scope of its conclusions. Recognising a limitation does not amount to rejecting the whole analysis.
Sin que introduces subjunctive; la points back to explicación. Lo que creates a neutral nominal relative. Alcance denotes scope. No equivale a blocks a false equivalence. Analyse the logical roles before making a fluent paraphrase.

**sin que los datos la confirmen**

without the data confirming it Subjunctive after sin que; la refers to explicación.

**no equivale a rechazar todo el análisis**

does not amount to rejecting the whole analysis Equivaler a licenses an infinitive complement here.

<details><summary>What is the passage’s central distinction?</summary>

Observed data and inferred explanations must be separated; persuasiveness is not conclusive confirmation.

</details>

<details><summary>Write a 150-word summary and a 150-word objection.</summary>

Preserve the author’s scope in the summary. In the objection, criticise a precise assumption and distinguish it from your own claim.

</details>

### Regional competence, idiom and advanced production

Recognise vosotros conjugation in Spain and ustedes in most of Latin America. Voseo has several regional systems and should be studied from a specific community's models, not assumed to have one universal conjugation. Differences in vocabulary can be neutral, affectionate or offensive depending on region. Verify context before imitating a colloquial expression.
Advanced production requires more than subjunctive accuracy. Study conventional openings, hedging, irony, indirect criticism, conversational turn-taking and natural collocations. Compare an informal voice note with an academic paragraph expressing the same idea. Avoid excessive literal translations of English passive sentences or pronoun subjects where Spanish discourse normally omits them.

**¿Podría aclarar este punto?**

Could you clarify this point? A conventional courteous professional request.

**En fin, habrá que revisarlo otra vez.**

Well/anyway, it will have to be reviewed again. Discourse meaning and impersonal necessity depend on context.

<details><summary>What should a regional-expression note contain?</summary>

Community, context, register, meaning, an authentic example and any offensive or misleading interpretation elsewhere.

</details>

<details><summary>Revise a formal paragraph into natural conversation.</summary>

Preserve the facts while reducing dense nominalisations and adjusting connectors, address and sentence length. Obtain feedback on naturalness.

</details>

## Word bank and recordings

1,000 study entries, based on dictionary selections and authored teaching glosses. Learn a word in a phrase; consult the linked entry for additional senses.

<details><summary>Words 1–50</summary>

![[Resources/Audio/es/Words 0001-0050.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [de](https://en.wiktionary.org/wiki/de#Spanish) | of; from | /de/ · prep |
| [la](https://en.wiktionary.org/wiki/la#Spanish) | the (feminine singular); her/it as an object pronoun | /la/ · article |
| [en](https://en.wiktionary.org/wiki/en#Spanish) | in, at, on | /en/ · prep |
| [y](https://en.wiktionary.org/wiki/y#Spanish) | and | /i/ · conj |
| [pronunciación](https://en.wiktionary.org/wiki/pronunciaci%C3%B3n) | pronunciation |  · noun |
| [los](https://en.wiktionary.org/wiki/los#Spanish) | the (masculine plural); them as an object pronoun | /los/ · article |
| [a la](https://en.wiktionary.org/wiki/a%20la#Spanish) | a la; in the style or manner of | /a la/ · prep |
| [se](https://en.wiktionary.org/wiki/se#Spanish) | A reflexive or reciprocal pronoun: oneself, himself, herself, itself, yourself; themselves; yourselves; each other; one another | /se/ · pron |
| [por](https://en.wiktionary.org/wiki/por#Spanish) | by | /poɾ/ · prep |
| [las](https://en.wiktionary.org/wiki/las#Spanish) | the (feminine plural); them as an object pronoun | /las/ · article |
| [con](https://en.wiktionary.org/wiki/con#Spanish) | with | /kon/ · prep |
| [una](https://en.wiktionary.org/wiki/una#Spanish) | a/an (feminine singular); one | /ˈuna/ · det |
| [para](https://en.wiktionary.org/wiki/para#Spanish) | for, to (expressing a recipient) | /paɾa/ · prep |
| [su](https://en.wiktionary.org/wiki/su#Spanish) | used to express an approximate number: about, approximately | /su/ · det |
| [me](https://en.wiktionary.org/wiki/me#Spanish) | Used as an emphatic pronoun or as an expletive. | /me/ · pron |
| [más](https://en.wiktionary.org/wiki/m%C3%A1s#Spanish) | more; -er (used to make comparisons) | /ˈmas/ · adv |
| [si](https://en.wiktionary.org/wiki/si#Spanish) | if, whether | /si/ · conj |
| [pero](https://en.wiktionary.org/wiki/pero#Spanish) | but | /ˈpeɾo/ · conj |
| [te](https://en.wiktionary.org/wiki/te#Spanish) | you (singular object); to you | /te/ · pron |
| [o](https://en.wiktionary.org/wiki/o#Spanish) | or | /o/ · conj |
| [mi](https://en.wiktionary.org/wiki/mi#Spanish) | mu; the Greek letter Μ, μ | /mi/ · noun |
| [le](https://en.wiktionary.org/wiki/le#Spanish) | to him, for him; dative of él | /le/ · pron |
| [todo](https://en.wiktionary.org/wiki/todo#Spanish) | all; every | /ˈtodo/ · det |
| [yo](https://en.wiktionary.org/wiki/yo#Spanish) | Freud's concept of the ego | /ˈʝo/ · noun |
| [ser](https://en.wiktionary.org/wiki/ser#Spanish) | to be (essentially or identified as) | /ˈseɾ/ · verb |
| [son](https://en.wiktionary.org/wiki/son#Spanish) | are (ser, third-person plural) | /ˈson/ · verb |
| [sin](https://en.wiktionary.org/wiki/sin#Spanish) | without | /ˈsin/ · prep |
| [sobre](https://en.wiktionary.org/wiki/sobre#Spanish) | over, above, on, upon, atop | /ˈsobɾe/ · prep |
| [nos](https://en.wiktionary.org/wiki/nos#Spanish) | we (masculine plural) | /nos/ · pron |
| [dos](https://en.wiktionary.org/wiki/dos#Spanish) | two | /ˈdos/ · num |
| [bien](https://en.wiktionary.org/wiki/bien#Spanish) | well (adverbial form of bueno) | /ˈbjen/ · adv |
| [hacer](https://en.wiktionary.org/wiki/hacer#Spanish) | to do, perform, execute, carry out | /aˈθeɾ/ · verb |
| [era](https://en.wiktionary.org/wiki/era#Spanish) | era, age | /ˈeɾa/ · noun |
| [vez](https://en.wiktionary.org/wiki/vez#Spanish) | time, instance | /ˈbeθ/ · noun |
| [nada](https://en.wiktionary.org/wiki/nada#Spanish) | nothing, zero, zilch, not...anything | /ˈnada/ · pron |
| [ni](https://en.wiktionary.org/wiki/ni#Spanish) | Used when negating two or more elements, and not, not A or B, not A nor B, neither A nor B | /ˈni/ · conj |
| [algo](https://en.wiktionary.org/wiki/algo#Spanish) | something, anything | /ˈalɡo/ · pron |
| [día](https://en.wiktionary.org/wiki/d%C3%ADa#Spanish) | day (any period of 24 hours) | /ˈdia/ · noun |
| [uno](https://en.wiktionary.org/wiki/uno#Spanish) | one | /ˈuno/ · num |
| [tan](https://en.wiktionary.org/wiki/tan#Spanish) | so, as | /tan/ · adv |
| [ver](https://en.wiktionary.org/wiki/ver#Spanish) | to see, to spot | /ˈbeɾ/ · verb |
| [e](https://en.wiktionary.org/wiki/e#Spanish) | and (used before an initial i sound) | /e/ · conj |
| [vocabulario](https://en.wiktionary.org/wiki/vocabulario) | vocabulary |  · noun |
| [gente](https://en.wiktionary.org/wiki/gente#Spanish) | people | /ˈxente/ · noun |
| [estado](https://en.wiktionary.org/wiki/estado#Spanish) | country, land (any broad area or territory) | /esˈtado/ · noun |
| [mundo](https://en.wiktionary.org/wiki/mundo#Spanish) | world, earth (human collective existence) | /ˈmundo/ · noun |
| [va](https://en.wiktionary.org/wiki/va#Spanish) | okay | /ˈba/ · intj |
| [año](https://en.wiktionary.org/wiki/a%C3%B1o#Spanish) | year | /ˈaɲo/ · noun |
| [gracias](https://en.wiktionary.org/wiki/gracias#Spanish) | thank you, thanks | /ˈɡɾaθjas/ [ˈɡɾa.θjas] · intj |
| [menos](https://en.wiktionary.org/wiki/menos#Spanish) | less | /ˈmenos/ · adv |

</details>

<details><summary>Words 51–100</summary>

![[Resources/Audio/es/Words 0051-0100.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [tanto](https://en.wiktionary.org/wiki/tanto#Spanish) | so much; as much; that much | /ˈtanto/ · det |
| [antes](https://en.wiktionary.org/wiki/antes#Spanish) | earlier; before; sooner; previously; formerly; beforehand (at an earlier time) | /ˈantes/ · adv |
| [dos a dos](https://en.wiktionary.org/wiki/dos%20a%20dos#Spanish) | mutually | /ˌdos a ˈdos/ · adv |
| [trabajo](https://en.wiktionary.org/wiki/trabajo#Spanish) | work, job | /tɾaˈbaxo/ · noun |
| [hecho](https://en.wiktionary.org/wiki/hecho#Spanish) | done, completed | /ˈet͡ʃo/ · adj |
| [gobierno](https://en.wiktionary.org/wiki/gobierno#Spanish) | government | /ɡoˈbjeɾno/ · noun |
| [país](https://en.wiktionary.org/wiki/pa%C3%ADs#Spanish) | country (the territory of a nation) | /paˈis/ · noun |
| [casa](https://en.wiktionary.org/wiki/casa#Spanish) | house | /ˈkasa/ · noun |
| [he](https://en.wiktionary.org/wiki/he#Spanish) | here is | /ˈe/ · adv |
| [nuevo](https://en.wiktionary.org/wiki/nuevo#Spanish) | new | /ˈnwebo/ · adj |
| [él](https://en.wiktionary.org/wiki/%C3%A9l#Spanish) | he, him, masculine personal third person subject and disjunctive pronoun (used as a subject and after prepositions) | /ˈel/ · pron |
| [aquí](https://en.wiktionary.org/wiki/aqu%C3%AD#Spanish) | here (in the speaker's location) | /aˈki/ · adv |
| [sí](https://en.wiktionary.org/wiki/s%C3%AD#Spanish) | yes, yeah, (used to respond affirmatively to a question, used both informally and formally) | /ˈsi/ · particle |
| [estar](https://en.wiktionary.org/wiki/estar#Spanish) | to be (have a temporary or permanent location in space) | /esˈtaɾ/ · verb |
| [hoy](https://en.wiktionary.org/wiki/hoy#Spanish) | today, tonight (on the current day) | /ˈoi/ · adv |
| [alguien](https://en.wiktionary.org/wiki/alguien#Spanish) | someone, somebody | /ˈalɡjen/ · pron |
| [te quiero](https://en.wiktionary.org/wiki/te%20quiero#Spanish) | I love you; I care about you | /te ˈkjeɾo/ · phrase |
| [tres](https://en.wiktionary.org/wiki/tres#Spanish) | three | /ˈtɾes/ · num |
| [pues](https://en.wiktionary.org/wiki/pues#Spanish) | so, then; in that case | /ˈpwes/ · conj |
| [historia](https://en.wiktionary.org/wiki/historia#Spanish) | history (the aggregate of past events) | /isˈtoɾja/ · noun |
| [nadie](https://en.wiktionary.org/wiki/nadie#Spanish) | no one; nobody (anyone or anybody) | /ˈnadje/ · pron |
| [primera](https://en.wiktionary.org/wiki/primera#Spanish) | first gear (lowest gear in a motor vehicle) | /pɾiˈmeɾa/ · noun |
| [entonces](https://en.wiktionary.org/wiki/entonces#Spanish) | then, next, thereupon, at that time, at that point | /enˈtonθes/ · adv |
| [ir](https://en.wiktionary.org/wiki/ir#Spanish) | to go (away from speaker and listener) | /ˈiɾ/ · verb |
| [general](https://en.wiktionary.org/wiki/general#Spanish) | general, overall | /xeneˈɾal/ · adj |
| [mayor](https://en.wiktionary.org/wiki/mayor#Spanish) | of age; adult; grown-up | /maˈʝoɾ/ · adj |
| [mal](https://en.wiktionary.org/wiki/mal#Spanish) | badly, poorly, ill | /ˈmal/ · adv |
| [dios](https://en.wiktionary.org/wiki/dios#Spanish) | god | /ˈdjos/ · noun |
| [ley](https://en.wiktionary.org/wiki/ley#Spanish) | law (a well-established characteristic of nature) | /ˈlei/ · noun |
| [había una vez](https://en.wiktionary.org/wiki/hab%C3%ADa%20una%20vez#Spanish) | once upon a time | /aˌbia ˌuna ˈbeθ/ · phrase |
| [sino](https://en.wiktionary.org/wiki/sino#Spanish) | destiny, fate, lot | /ˈsino/ · noun |
| [grupo](https://en.wiktionary.org/wiki/grupo#Spanish) | group | /ˈɡɾupo/ · noun |
| [hombre](https://en.wiktionary.org/wiki/hombre#Spanish) | man (adult male human) | /ˈombɾe/ · noun |
| [mujer](https://en.wiktionary.org/wiki/mujer#Spanish) | woman | /muˈxeɾ/ · noun |
| [persona](https://en.wiktionary.org/wiki/persona#Spanish) | person (an individual; usually a human being) | /peɾˈsona/ · noun |
| [casi](https://en.wiktionary.org/wiki/casi#Spanish) | almost | /ˈkasi/ · adv |
| [ahí](https://en.wiktionary.org/wiki/ah%C3%AD#Spanish) | there (away from the speaker) | /aˈi/ · adv |
| [familia](https://en.wiktionary.org/wiki/familia#Spanish) | family (group of people related to each other) | /faˈmilja/ · noun |
| [al fin](https://en.wiktionary.org/wiki/al%20fin#Spanish) | at last; finally | /al ˈfin/ · adv |
| [pueblo](https://en.wiktionary.org/wiki/pueblo#Spanish) | town, village | /ˈpweblo/ · noun |
| [final](https://en.wiktionary.org/wiki/final#Spanish) | final (last, ultimate) | /fiˈnal/ · adj |
| [punto](https://en.wiktionary.org/wiki/punto#Spanish) | point (specific spot, location, or place) | /ˈpunto/ · noun |
| [agua](https://en.wiktionary.org/wiki/agua#Spanish) | water | /ˈaɡwa/ · noun |
| [guerra](https://en.wiktionary.org/wiki/guerra#Spanish) | war, warfare | /ˈɡera/ · noun |
| [saber](https://en.wiktionary.org/wiki/saber#Spanish) | to know, to understand (a fact) | /saˈbeɾ/ · verb |
| [van](https://en.wiktionary.org/wiki/van#Spanish) | van (vehicle) | /ˈban/ · noun |
| [ante](https://en.wiktionary.org/wiki/ante#Spanish) | in front of, before | /ˈante/ · prep |
| [dar](https://en.wiktionary.org/wiki/dar#Spanish) | to give, to give out | /ˈdaɾ/ · verb |
| [embargo](https://en.wiktionary.org/wiki/embargo#Spanish) | embargo | /emˈbaɾɡo/ · noun |
| [favor](https://en.wiktionary.org/wiki/favor#Spanish) | favor/favour | /faˈboɾ/ · noun |

</details>

<details><summary>Words 101–150</summary>

![[Resources/Audio/es/Words 0101-0150.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [información](https://en.wiktionary.org/wiki/informaci%C3%B3n#Spanish) | information, data | /infoɾmaˈθjon/ · noun |
| [san](https://en.wiktionary.org/wiki/san#Spanish) | financial, temporal-savings scheme; the participants periodically contribute a quota to a communal pot that is given to one member, based on his/her turn amongst all the others | /ˈsan/ · noun |
| [social](https://en.wiktionary.org/wiki/social#Spanish) | social | /soˈθjal/ · adj |
| [ejemplo](https://en.wiktionary.org/wiki/ejemplo#Spanish) | example | /eˈxemplo/ · noun |
| [hora](https://en.wiktionary.org/wiki/hora#Spanish) | hour (a time period of sixty minutes) | /ˈoɾa/ · noun |
| [madre](https://en.wiktionary.org/wiki/madre#Spanish) | mother | /ˈmadɾe/ · noun |
| [derecho](https://en.wiktionary.org/wiki/derecho#Spanish) | straight (not crooked or bent; having a constant direction throughout its length) | /deˈɾet͡ʃo/ · adj |
| [idea](https://en.wiktionary.org/wiki/idea#Spanish) | idea | /iˈdea/ · noun |
| [gracias a Dios](https://en.wiktionary.org/wiki/gracias%20a%20Dios#Spanish) | thanks be to God, thank God | /ˌɡɾaθjas a ˈdjos/ · adv |
| [real](https://en.wiktionary.org/wiki/real#Spanish) | real | /reˈal/ · adj |
| [cuatro](https://en.wiktionary.org/wiki/cuatro#Spanish) | four | /ˈkwatɾo/ · num |
| [hijo](https://en.wiktionary.org/wiki/hijo#Spanish) | son | /ˈixo/ · noun |
| [hombre del mundo](https://en.wiktionary.org/wiki/hombre%20del%20mundo#Spanish) | man of the world (worldly man) | /ˌombɾe del ˈmundo/ · noun |
| [tema](https://en.wiktionary.org/wiki/tema#Spanish) | theme; plot (of a book, film or other media) | /ˈtema/ · noun |
| [llegar](https://en.wiktionary.org/wiki/llegar#Spanish) | to arrive, get (to) | /ʝeˈɡaɾ/ · verb |
| [mano](https://en.wiktionary.org/wiki/mano#Spanish) | hand | /ˈmano/ · noun |
| [amigo](https://en.wiktionary.org/wiki/amigo#Spanish) | friend | /aˈmiɡo/ · noun |
| [padre](https://en.wiktionary.org/wiki/padre#Spanish) | father, parent | /ˈpadɾe/ · noun |
| [tierra](https://en.wiktionary.org/wiki/tierra#Spanish) | Earth (planet of the Solar System in which all of humanity resides) | /ˈtjera/ · noun |
| [cuerpo](https://en.wiktionary.org/wiki/cuerpo#Spanish) | body (the physical structure of a human or animal) | /ˈkweɾpo/ · noun |
| [segundo](https://en.wiktionary.org/wiki/segundo#Spanish) | second (after the first) | /seˈɡundo/ · adj |
| [libro](https://en.wiktionary.org/wiki/libro#Spanish) | book | /ˈlibɾo/ · noun |
| [cinco](https://en.wiktionary.org/wiki/cinco#Spanish) | five | /ˈθinko/ · num |
| [mes](https://en.wiktionary.org/wiki/mes#Spanish) | month | /ˈmes/ · noun |
| [largo](https://en.wiktionary.org/wiki/largo#Spanish) | long (having much distance from one terminating point to another) | /ˈlaɾɡo/ · adj |
| [alto](https://en.wiktionary.org/wiki/alto#Spanish) | tall | /ˈalto/ · adj |
| [español](https://en.wiktionary.org/wiki/espa%C3%B1ol#Spanish) | Spanish (from or native to Spain) | /espaˈɲol/ · adj |
| [hombre de Dios](https://en.wiktionary.org/wiki/hombre%20de%20Dios#Spanish) | a man of God, a godly man | /ˌombɾe de ˈdjos/ · noun |
| [lista](https://en.wiktionary.org/wiki/lista#Spanish) | list, roll | /ˈlista/ · noun |
| [personal](https://en.wiktionary.org/wiki/personal#Spanish) | personal | /peɾsoˈnal/ · adj |
| [video](https://en.wiktionary.org/wiki/video#Spanish) | video | /biˈdeo/ · noun |
| [web](https://en.wiktionary.org/wiki/web#Spanish) | web (Internet) | /ˈw̝eb/ · noun |
| [a la buena de Dios](https://en.wiktionary.org/wiki/a%20la%20buena%20de%20Dios#Spanish) | casually; as God wills | /a la ˌbwena de ˈdjos/ · adv |
| [base](https://en.wiktionary.org/wiki/base#Spanish) | base | /ˈbase/ · noun |
| [hola](https://en.wiktionary.org/wiki/hola#Spanish) | hello, hi, hey | /ˈola/ · intj |
| [paz](https://en.wiktionary.org/wiki/paz#Spanish) | peace (warlessness) | /ˈpaθ/ · noun |
| [salud](https://en.wiktionary.org/wiki/salud#Spanish) | health | /saˈlud/ · noun |
| [zona](https://en.wiktionary.org/wiki/zona#Spanish) | zone, district, area | /ˈθona/ · noun |
| [calle](https://en.wiktionary.org/wiki/calle#Spanish) | street | /ˈkaʝe/ · noun |
| [mundial](https://en.wiktionary.org/wiki/mundial#Spanish) | related to all parts of the world; global | /munˈdjal/ · adj |
| [pensar](https://en.wiktionary.org/wiki/pensar#Spanish) | to think, ponder | /penˈsaɾ/ · verb |
| [allí](https://en.wiktionary.org/wiki/all%C3%AD#Spanish) | there (away from the speaker and the listener) | /aˈʝi/ · adv |
| [dicho y hecho](https://en.wiktionary.org/wiki/dicho%20y%20hecho#Spanish) | said and done; no sooner said than done | /ˌdit͡ʃo i ˈet͡ʃo/ · phrase |
| [capital](https://en.wiktionary.org/wiki/capital#Spanish) | capital (important) | /kapiˈtal/ · adj |
| [libre](https://en.wiktionary.org/wiki/libre#Spanish) | free (not imprisoned or enslaved) | /ˈlibɾe/ · adj |
| [luz](https://en.wiktionary.org/wiki/luz#Spanish) | light | /ˈluθ/ · noun |
| [música](https://en.wiktionary.org/wiki/m%C3%BAsica#Spanish) | music | /ˈmusika/ · noun |
| [poner](https://en.wiktionary.org/wiki/poner#Spanish) | to put, to place (cause to assume a specified position) | /poˈneɾ/ · verb |
| [rey](https://en.wiktionary.org/wiki/rey#Spanish) | king | /ˈrei/ · noun |
| [vos](https://en.wiktionary.org/wiki/vos#Spanish) | you, familiar form of the second-person singular pronoun | /ˈbos/ · pron |

</details>

<details><summary>Words 151–200</summary>

![[Resources/Audio/es/Words 0151-0200.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [hombre de guerra](https://en.wiktionary.org/wiki/hombre%20de%20guerra#Spanish) | a man of war, a military man | /ˌombɾe de ˈɡera/ · noun |
| [mayo](https://en.wiktionary.org/wiki/mayo#Spanish) | May | /ˈmaʝo/ · noun |
| [control](https://en.wiktionary.org/wiki/control#Spanish) | control, or running of a business | /konˈtɾol/ · noun |
| [marzo](https://en.wiktionary.org/wiki/marzo#Spanish) | March | /ˈmaɾθo/ · noun |
| [trabajar](https://en.wiktionary.org/wiki/trabajar#Spanish) | to work | /tɾabaˈxaɾ/ · verb |
| [justicia](https://en.wiktionary.org/wiki/justicia#Spanish) | justice | /xusˈtiθja/ · noun |
| [allá](https://en.wiktionary.org/wiki/all%C3%A1#Spanish) | there, over there, thither, yonder (in a direction away from the speaker and the listener) | /aˈʝa/ · adv |
| [corazón](https://en.wiktionary.org/wiki/coraz%C3%B3n#Spanish) | heart (organ of the body) | /koɾaˈθon/ · noun |
| [principal](https://en.wiktionary.org/wiki/principal#Spanish) | main, most important | /pɾinθiˈpal/ · adj |
| [voz](https://en.wiktionary.org/wiki/voz#Spanish) | voice | /ˈboθ/ · noun |
| [actual](https://en.wiktionary.org/wiki/actual#Spanish) | present, current | /aɡˈtwal/ · adj |
| [media](https://en.wiktionary.org/wiki/media#Spanish) | half (one of two equal parts of any whole) | /ˈmedja/ · noun |
| [palabra](https://en.wiktionary.org/wiki/palabra#Spanish) | word | /paˈlabɾa/ · noun |
| [abril](https://en.wiktionary.org/wiki/abril#Spanish) | April | /aˈbɾil/ · noun |
| [plan](https://en.wiktionary.org/wiki/plan#Spanish) | plan | /ˈplan/ · noun |
| [partir](https://en.wiktionary.org/wiki/partir#Spanish) | to divide, split | /paɾˈtiɾ/ · verb |
| [dan](https://en.wiktionary.org/wiki/dan#Spanish) | dan | /ˈdan/ · noun |
| [seis](https://en.wiktionary.org/wiki/seis#Spanish) | six | /ˈseis/ · num |
| [agosto](https://en.wiktionary.org/wiki/agosto#Spanish) | August | /aˈɡosto/ · noun |
| [cargo](https://en.wiktionary.org/wiki/cargo#Spanish) | charge, burden | /ˈkaɾɡo/ · noun |
| [comida](https://en.wiktionary.org/wiki/comida#Spanish) | food | /koˈmida/ · noun |
| [enero](https://en.wiktionary.org/wiki/enero#Spanish) | January | /eˈneɾo/ · noun |
| [leer](https://en.wiktionary.org/wiki/leer#Spanish) | to read | /leˈeɾ/ · verb |
| [llama](https://en.wiktionary.org/wiki/llama#Spanish) | flame | /ˈʝama/ · noun |
| [Santa](https://en.wiktionary.org/wiki/Santa#Spanish) | Saint (title), feminine singular of San | /ˈsanta/ · adj |
| [vale](https://en.wiktionary.org/wiki/vale#Spanish) | a voucher; an IOU | /ˈbale/ · noun |
| [acción](https://en.wiktionary.org/wiki/acci%C3%B3n#Spanish) | action, act, deed (something done) | /aɡˈθjon/ · noun |
| [conocer](https://en.wiktionary.org/wiki/conocer#Spanish) | to know (a person or a place), to be familiar with, to be acquainted with | /konoˈθeɾ/ · verb |
| [plaza](https://en.wiktionary.org/wiki/plaza#Spanish) | plaza, town square | /ˈplaθa/ · noun |
| [u](https://en.wiktionary.org/wiki/u#Spanish) | or | /u/ · conj |
| [valor](https://en.wiktionary.org/wiki/valor#Spanish) | value (all senses) | /baˈloɾ/ · noun |
| [causa](https://en.wiktionary.org/wiki/causa#Spanish) | cause | /ˈkausa/ · noun |
| [central](https://en.wiktionary.org/wiki/central#Spanish) | central | /θenˈtɾal/ · adj |
| [director](https://en.wiktionary.org/wiki/director#Spanish) | director | /diɾeɡˈtoɾ/ · noun |
| [duda](https://en.wiktionary.org/wiki/duda#Spanish) | doubt | /ˈduda/ · noun |
| [pronto](https://en.wiktionary.org/wiki/pronto#Spanish) | prompt, on time | /ˈpɾonto/ · adj |
| [civil](https://en.wiktionary.org/wiki/civil#Spanish) | civil (all senses) | /θiˈbil/ · adj |
| [hermano](https://en.wiktionary.org/wiki/hermano#Spanish) | brother | /eɾˈmano/ · noun |
| [local](https://en.wiktionary.org/wiki/local#Spanish) | local | /loˈkal/ · adj |
| [mar](https://en.wiktionary.org/wiki/mar#Spanish) | sea | /ˈmaɾ/ · noun |
| [acá](https://en.wiktionary.org/wiki/ac%C3%A1#Spanish) | here (in the speaker's location) | /aˈka/ · adv |
| [negro](https://en.wiktionary.org/wiki/negro#Spanish) | black (the color perceived in the absence of light) | /ˈneɡɾo/ · noun |
| [popular](https://en.wiktionary.org/wiki/popular#Spanish) | popular | /popuˈlaɾ/ · adj |
| [principio](https://en.wiktionary.org/wiki/principio#Spanish) | principle | /pɾinˈθipjo/ · noun |
| [red](https://en.wiktionary.org/wiki/red#Spanish) | web, mesh | /ˈred/ · noun |
| [río](https://en.wiktionary.org/wiki/r%C3%ADo#Spanish) | river | /ˈrio/ · noun |
| [ah](https://en.wiktionary.org/wiki/ah#Spanish) | ah (expression of relief, realization, awe) | /ˈa/ · intj |
| [blanco](https://en.wiktionary.org/wiki/blanco#Spanish) | white | /ˈblanko/ · adj |
| [comer](https://en.wiktionary.org/wiki/comer#Spanish) | to eat | /koˈmeɾ/ · verb |
| [ganar](https://en.wiktionary.org/wiki/ganar#Spanish) | to gain | /ɡaˈnaɾ/ · verb |

</details>

<details><summary>Words 201–250</summary>

![[Resources/Audio/es/Words 0201-0250.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [interior](https://en.wiktionary.org/wiki/interior#Spanish) | inner, interior | /inteˈɾjoɾ/ · adj |
| [sol](https://en.wiktionary.org/wiki/sol#Spanish) | sun | /ˈsol/ · noun |
| [anterior](https://en.wiktionary.org/wiki/anterior#Spanish) | anterior (in time), previous, earlier, former, past | /anteˈɾjoɾ/ · adj |
| [buscar](https://en.wiktionary.org/wiki/buscar#Spanish) | to seek, search for, look for, try to find, to scour | /busˈkaɾ/ · verb |
| [aire](https://en.wiktionary.org/wiki/aire#Spanish) | air (the substance constituting earth's atmosphere) | /ˈaiɾe/ · noun |
| [autor](https://en.wiktionary.org/wiki/autor#Spanish) | author | /auˈtoɾ/ · noun |
| [entrar](https://en.wiktionary.org/wiki/entrar#Spanish) | to enter; to come in; to get in; to go in; to get inside; to come on in | /enˈtɾaɾ/ · verb |
| [ex](https://en.wiktionary.org/wiki/ex#Spanish) | ex (ex-husband, ex-wife or ex-partner) | /ˈeɡs/ · noun |
| [par](https://en.wiktionary.org/wiki/par#Spanish) | even (divisible by two) | /ˈpaɾ/ · adj |
| [plata](https://en.wiktionary.org/wiki/plata#Spanish) | argent | /ˈplata/ · adj |
| [puerta](https://en.wiktionary.org/wiki/puerta#Spanish) | door (portal of entry into a building) | /ˈpweɾta/ · noun |
| [quién sabe](https://en.wiktionary.org/wiki/qui%C3%A9n%20sabe#Spanish) | who knows? | /ˌkjen ˈsabe/ · phrase |
| [r](https://en.wiktionary.org/wiki/r#Spanish) | the letter r | /ɾ/ · noun |
| [color](https://en.wiktionary.org/wiki/color#Spanish) | color / colour, hue | /koˈloɾ/ · noun |
| [contigo](https://en.wiktionary.org/wiki/contigo#Spanish) | with you (singular) | /konˈtiɡo/ · adv |
| [hija](https://en.wiktionary.org/wiki/hija#Spanish) | daughter; female equivalent of hijo | /ˈixa/ · noun |
| [dar a luz](https://en.wiktionary.org/wiki/dar%20a%20luz#Spanish) | to give birth | /ˌdaɾ a ˈluθ/ · verb |
| [diez](https://en.wiktionary.org/wiki/diez#Spanish) | ten | /ˈdjeθ/ · num |
| [por supuesto](https://en.wiktionary.org/wiki/por%20supuesto#Spanish) | of course, for sure, certainly (affirmative answer) | /poɾ suˈpwesto/ · adv |
| [superior](https://en.wiktionary.org/wiki/superior#Spanish) | superior | /supeˈɾjoɾ/ · adj |
| [comprar](https://en.wiktionary.org/wiki/comprar#Spanish) | to buy (to obtain in exchange of money or goods) | /komˈpɾaɾ/ · verb |
| [crear](https://en.wiktionary.org/wiki/crear#Spanish) | to create | /kɾeˈaɾ/ · verb |
| [natural](https://en.wiktionary.org/wiki/natural#Spanish) | natural (of or relating to nature) | /natuˈɾal/ · adj |
| [radio](https://en.wiktionary.org/wiki/radio#Spanish) | radio (device) | /ˈradjo/ · noun |
| [sale](https://en.wiktionary.org/wiki/sale#Spanish) | ok | /ˈsale/ · intj |
| [conmigo](https://en.wiktionary.org/wiki/conmigo#Spanish) | with me | /komˈmiɡo/ · adv |
| [costa](https://en.wiktionary.org/wiki/costa#Spanish) | coast, coastline | /ˈkosta/ · noun |
| [crisis](https://en.wiktionary.org/wiki/crisis#Spanish) | crisis | /ˈkɾisis/ · noun |
| [cámara](https://en.wiktionary.org/wiki/c%C3%A1mara#Spanish) | room | /ˈkamaɾa/ · noun |
| [domingo](https://en.wiktionary.org/wiki/domingo#Spanish) | Sunday | /doˈminɡo/ · noun |
| [perder](https://en.wiktionary.org/wiki/perder#Spanish) | to lose | /peɾˈdeɾ/ · verb |
| [creer](https://en.wiktionary.org/wiki/creer#Spanish) | to believe | /kɾeˈeɾ/ · verb |
| [sangre](https://en.wiktionary.org/wiki/sangre#Spanish) | blood | /ˈsanɡɾe/ · noun |
| [auto](https://en.wiktionary.org/wiki/auto#Spanish) | car, automobile | /ˈauto/ · noun |
| [carta](https://en.wiktionary.org/wiki/carta#Spanish) | letter (document) | /ˈkaɾta/ · noun |
| [al fin y al cabo](https://en.wiktionary.org/wiki/al%20fin%20y%20al%20cabo#Spanish) | when all is said and done | /al ˌfin i al ˈkabo/ · phrase |
| [club](https://en.wiktionary.org/wiki/club#Spanish) | club (an association of members joining together for some common purpose, especially sports or recreation) | /ˈklub/ · noun |
| [di](https://en.wiktionary.org/wiki/di#Spanish) | Used as a friendly particle. | /ˈdi/ · particle |
| [error](https://en.wiktionary.org/wiki/error#Spanish) | error | /eˈroɾ/ · noun |
| [normal](https://en.wiktionary.org/wiki/normal#Spanish) | normal (customary, standard, not deviating from a norm) | /noɾˈmal/ · adj |
| [siete](https://en.wiktionary.org/wiki/siete#Spanish) | seven | /ˈsjete/ · num |
| [constitución](https://en.wiktionary.org/wiki/constituci%C3%B3n#Spanish) | constitution (all senses) | /konstituˈθjon/ · noun |
| [mente](https://en.wiktionary.org/wiki/mente#Spanish) | mind, intellect | /ˈmente/ · noun |
| [post](https://en.wiktionary.org/wiki/post#Spanish) | post | /ˈpost/ · noun |
| [cielo](https://en.wiktionary.org/wiki/cielo#Spanish) | sky | /ˈθjelo/ · noun |
| [loco](https://en.wiktionary.org/wiki/loco#Spanish) | crazy, insane, mad, nuts (asserting that something is out of place in the head) | /ˈloko/ · adj |
| [re](https://en.wiktionary.org/wiki/re#Spanish) | re | /ˈre/ · noun |
| [se habla español](https://en.wiktionary.org/wiki/se%20habla%20espa%C3%B1ol#Spanish) | "we speak Spanish". More precisely, "Spanish is spoken (here)." | /se ˌabla espaˈɲol/ · phrase |
| [simple](https://en.wiktionary.org/wiki/simple#Spanish) | simple (uncomplicated) | /ˈsimple/ · adj |
| [vino](https://en.wiktionary.org/wiki/vino#Spanish) | wine (an alcoholic beverage made by fermenting grape juice, with an ABV ranging from 5.5–16%) | /ˈbino/ · noun |

</details>

<details><summary>Words 251–300</summary>

![[Resources/Audio/es/Words 0251-0300.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [canal](https://en.wiktionary.org/wiki/canal#Spanish) | canal, flume, waterway (artificial) | /kaˈnal/ · noun |
| [original](https://en.wiktionary.org/wiki/original#Spanish) | original | /oɾixiˈnal/ · adj |
| [peso](https://en.wiktionary.org/wiki/peso#Spanish) | weight (the force on an object due to gravitational attraction) | /ˈpeso/ · noun |
| [alma](https://en.wiktionary.org/wiki/alma#Spanish) | soul | /ˈalma/ · noun |
| [conocimiento](https://en.wiktionary.org/wiki/conocimiento#Spanish) | knowledge | /konoθiˈmjento/ · noun |
| [hospital](https://en.wiktionary.org/wiki/hospital#Spanish) | hospital | /ospiˈtal/ · noun |
| [pie](https://en.wiktionary.org/wiki/pie#Spanish) | foot (a part of the body) | /ˈpje/ · noun |
| [democracia](https://en.wiktionary.org/wiki/democracia#Spanish) | democracy (rule by the people) | /demoˈkɾaθja/ · noun |
| [don](https://en.wiktionary.org/wiki/don#Spanish) | a title of respect to a man, prefixed to first names | /ˈdon/ · noun |
| [fe](https://en.wiktionary.org/wiki/fe#Spanish) | faith | /ˈfe/ · noun |
| [ocho](https://en.wiktionary.org/wiki/ocho#Spanish) | eight (8) | /ˈot͡ʃo/ · num |
| [particular](https://en.wiktionary.org/wiki/particular#Spanish) | specific, particular | /paɾtikuˈlaɾ/ · adj |
| [se habla inglés](https://en.wiktionary.org/wiki/se%20habla%20ingl%C3%A9s#Spanish) | "we speak English" | /se ˌabla inˈɡles/ · phrase |
| [mesa](https://en.wiktionary.org/wiki/mesa#Spanish) | table | /ˈmesa/ · noun |
| [sala](https://en.wiktionary.org/wiki/sala#Spanish) | room (a separate part of a building) | /ˈsala/ · noun |
| [ser humano](https://en.wiktionary.org/wiki/ser%20humano#Spanish) | human being | /ˌseɾ uˈmano/ · noun |
| [teléfono](https://en.wiktionary.org/wiki/tel%C3%A9fono#Spanish) | telephone (a telecommunication device used for two-way talking with another person) | /teˈlefono/ · noun |
| [doctor](https://en.wiktionary.org/wiki/doctor#Spanish) | doctor (Ph.D.) | /doɡˈtoɾ/ · noun |
| [material](https://en.wiktionary.org/wiki/material#Spanish) | material | /mateˈɾjal/ · adj |
| [destino](https://en.wiktionary.org/wiki/destino#Spanish) | destiny, fate | /desˈtino/ · noun |
| [legal](https://en.wiktionary.org/wiki/legal#Spanish) | legal | /leˈɡal/ · adj |
| [pedir](https://en.wiktionary.org/wiki/pedir#Spanish) | to ask for something | /peˈdiɾ/ · verb |
| [perro](https://en.wiktionary.org/wiki/perro#Spanish) | dog (the species Canis familiaris (sometimes designated Canis lupus familiaris), domesticated for thousands of years and of highly variable appearance because of human breeding) | /ˈpero/ · noun |
| [to](https://en.wiktionary.org/wiki/to#Spanish) | whoa |  · intj |
| [diga](https://en.wiktionary.org/wiki/diga#Spanish) | way to say hello on the telephone | /ˈdiɡa/ · intj |
| [memoria](https://en.wiktionary.org/wiki/memoria#Spanish) | memory (the ability of the brain to record information) | /meˈmoɾja/ · noun |
| [sacar](https://en.wiktionary.org/wiki/sacar#Spanish) | to put out, to get out (e.g. a public statement, an APB, a release of media or entertainment) | /saˈkaɾ/ · verb |
| [sentir](https://en.wiktionary.org/wiki/sentir#Spanish) | to feel | /senˈtiɾ/ · verb |
| [f](https://en.wiktionary.org/wiki/f#Spanish) | bad luck | /ˈefe/ · intj |
| [gratis](https://en.wiktionary.org/wiki/gratis#Spanish) | free, without charge | /ˈɡɾatis/ · adj |
| [santo](https://en.wiktionary.org/wiki/santo#Spanish) | holy, godly | /ˈsanto/ · adj |
| [dormir](https://en.wiktionary.org/wiki/dormir#Spanish) | to sleep | /doɾˈmiɾ/ · verb |
| [fiscal](https://en.wiktionary.org/wiki/fiscal#Spanish) | fiscal | /fisˈkal/ · adj |
| [ido](https://en.wiktionary.org/wiki/ido#Spanish) | away with the fairies; absent-minded | /ˈido/ · adj |
| [rato](https://en.wiktionary.org/wiki/rato#Spanish) | a while, bit (a short period of time) | /ˈrato/ · noun |
| [amo](https://en.wiktionary.org/wiki/amo#Spanish) | master (man who owns a slave) | /ˈamo/ · noun |
| [exterior](https://en.wiktionary.org/wiki/exterior#Spanish) | external, outer | /eɡsteˈɾjoɾ/ · adj |
| [honor](https://en.wiktionary.org/wiki/honor#Spanish) | honor | /oˈnoɾ/ · noun |
| [triste](https://en.wiktionary.org/wiki/triste#Spanish) | As a temporary state. | /ˈtɾiste/ · adj |
| [debate](https://en.wiktionary.org/wiki/debate#Spanish) | debate | /deˈbate/ · noun |
| [hogar](https://en.wiktionary.org/wiki/hogar#Spanish) | home | /oˈɡaɾ/ · noun |
| [rojo](https://en.wiktionary.org/wiki/rojo#Spanish) | red (colour) | /ˈroxo/ · adj |
| [similar](https://en.wiktionary.org/wiki/similar#Spanish) | similar | /simiˈlaɾ/ · adj |
| [te amo](https://en.wiktionary.org/wiki/te%20amo#Spanish) | I love you (affirmation of romantic feeling) | /te ˈamo/ · phrase |
| [azul](https://en.wiktionary.org/wiki/azul#Spanish) | blue | /aˈθul/ · adj |
| [carne](https://en.wiktionary.org/wiki/carne#Spanish) | flesh, the soft part of a body which covers the bones | /ˈkaɾne/ · noun |
| [cumplir](https://en.wiktionary.org/wiki/cumplir#Spanish) | to fulfil, to fulfill, to meet, to deliver (e.g., requirements, prerequisites, promise, vow) | /kumˈpliɾ/ · verb |
| [juez](https://en.wiktionary.org/wiki/juez#Spanish) | judge | /ˈxweθ/ · noun |
| [maestro](https://en.wiktionary.org/wiki/maestro#Spanish) | master | /maˈestɾo/ · noun |
| [materia](https://en.wiktionary.org/wiki/materia#Spanish) | matter (the basic structural component of the universe) | /maˈteɾja/ · noun |

</details>

<details><summary>Words 301–350</summary>

![[Resources/Audio/es/Words 0301-0350.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [hombre de negocios](https://en.wiktionary.org/wiki/hombre%20de%20negocios#Spanish) | a businessman | /ˌombɾe de neˈɡoθjos/ · noun |
| [pelo](https://en.wiktionary.org/wiki/pelo#Spanish) | hair (a single hair) | /ˈpelo/ · noun |
| [café](https://en.wiktionary.org/wiki/caf%C3%A9#Spanish) | brown | /kaˈfe/ · adj |
| [eh](https://en.wiktionary.org/wiki/eh#Spanish) | hey! (used to call, draw attention, warn or reprehend) | /ˈe/ · intj |
| [lunes](https://en.wiktionary.org/wiki/lunes#Spanish) | Monday | /ˈlunes/ · noun |
| [novia](https://en.wiktionary.org/wiki/novia#Spanish) | a type of sweet roll | /ˈnobja/ · noun |
| [papa](https://en.wiktionary.org/wiki/papa#Spanish) | pope (an honorary title of the Roman Catholic bishop of Rome) | /ˈpapa/ · noun |
| [festival](https://en.wiktionary.org/wiki/festival#Spanish) | festival | /festiˈbal/ · noun |
| [hotel](https://en.wiktionary.org/wiki/hotel#Spanish) | hotel | /oˈtel/ · noun |
| [in vivo](https://en.wiktionary.org/wiki/in%20vivo#Spanish) | in vivo | /ˌim ˈbibo/ · adj |
| [matar](https://en.wiktionary.org/wiki/matar#Spanish) | to kill, slay | /maˈtaɾ/ · verb |
| [raro](https://en.wiktionary.org/wiki/raro#Spanish) | rare | /ˈraɾo/ · adj |
| [abierto](https://en.wiktionary.org/wiki/abierto#Spanish) | open, unlocked (not closed, accessible) | /aˈbjeɾto/ · adj |
| [clave](https://en.wiktionary.org/wiki/clave#Spanish) | key (to a problem or puzzle) | /ˈklabe/ · noun |
| [luna](https://en.wiktionary.org/wiki/luna#Spanish) | moon | /ˈluna/ · noun |
| [ojo](https://en.wiktionary.org/wiki/ojo#Spanish) | eye | /ˈoxo/ · noun |
| [pro](https://en.wiktionary.org/wiki/pro#Spanish) | usefulness, advantage, benefit | /ˈpɾo/ · noun |
| [reina](https://en.wiktionary.org/wiki/reina#Spanish) | queen | /ˈreina/ · noun |
| [salvo](https://en.wiktionary.org/wiki/salvo#Spanish) | safe | /ˈsalbo/ · adj |
| [sábado](https://en.wiktionary.org/wiki/s%C3%A1bado#Spanish) | Saturday | /ˈsabado/ · noun |
| [velocidad](https://en.wiktionary.org/wiki/velocidad#Spanish) | speed | /beloθiˈdad/ · noun |
| [abogado](https://en.wiktionary.org/wiki/abogado#Spanish) | lawyer, solicitor, counsel. | /aboˈɡado/ · noun |
| [anda](https://en.wiktionary.org/wiki/anda#Spanish) | a bier or small platform, when carried by people (usually 4 or more individuals) to move a corpse or religious image | /ˈanda/ · noun |
| [nueve](https://en.wiktionary.org/wiki/nueve#Spanish) | nine | /ˈnwebe/ · num |
| [digital](https://en.wiktionary.org/wiki/digital#Spanish) | digital; having to do with the fingers or toes | /dixiˈtal/ · adj |
| [distrito](https://en.wiktionary.org/wiki/distrito#Spanish) | district | /disˈtɾito/ · noun |
| [junta](https://en.wiktionary.org/wiki/junta#Spanish) | board, council, committee | /ˈxunta/ · noun |
| [listo](https://en.wiktionary.org/wiki/listo#Spanish) | clever, smart | /ˈlisto/ · adj |
| [ay](https://en.wiktionary.org/wiki/ay#Spanish) | ah!, alas! | /ˈai/ · intj |
| [mexicano](https://en.wiktionary.org/wiki/mexicano#Spanish) | Mexican (native or pertaining to the country of the United Mexican States: compare mexiquense) | /mexiˈkano/ · adj |
| [online](https://en.wiktionary.org/wiki/online#Spanish) | online | /onˈlain/ · adj |
| [querer](https://en.wiktionary.org/wiki/querer#Spanish) | to desire, to want, to want to | /keˈɾeɾ/ · verb |
| [espíritu](https://en.wiktionary.org/wiki/esp%C3%ADritu#Spanish) | spirit, soul | /esˈpiɾitu/ · noun |
| [leche](https://en.wiktionary.org/wiki/leche#Spanish) | milk | /ˈlet͡ʃe/ · noun |
| [mirar](https://en.wiktionary.org/wiki/mirar#Spanish) | to look at (to try to see, to pay attention to with one’s eyes) | /miˈɾaɾ/ · verb |
| [sexual](https://en.wiktionary.org/wiki/sexual#Spanish) | sexual (pertaining to the sex of an organism) | /seɡˈswal/ · adj |
| [super](https://en.wiktionary.org/wiki/super#Spanish) | very, mega |  · adj |
| [blog](https://en.wiktionary.org/wiki/blog#Spanish) | blog | /ˈbloɡ/ · noun |
| [estadounidense](https://en.wiktionary.org/wiki/estadounidense#Spanish) | American, U.S. American (of, from or relating to the United States) | /esˌtadouniˈdense/ · adj |
| [OK](https://en.wiktionary.org/wiki/OK#Spanish) | OK | /ˌoˈkei/ · adj |
| [caer](https://en.wiktionary.org/wiki/caer#Spanish) | to fall (to move to a lower position due to gravity) | /kaˈeɾ/ · verb |
| [gas](https://en.wiktionary.org/wiki/gas#Spanish) | gas (matter between liquid and plasma) | /ˈɡas/ · noun |
| [grave](https://en.wiktionary.org/wiki/grave#Spanish) | serious, grave | /ˈɡɾabe/ · adj |
| [playa](https://en.wiktionary.org/wiki/playa#Spanish) | beach | /ˈplaʝa/ · noun |
| [jueves](https://en.wiktionary.org/wiki/jueves#Spanish) | Thursday | /ˈxwebes/ · noun |
| [oh](https://en.wiktionary.org/wiki/oh#Spanish) | oh (expression of awe, surprise, pain or realization) | /ˈo/ · intj |
| [puente](https://en.wiktionary.org/wiki/puente#Spanish) | bridge (construction spanning a waterway, ravine, or valley from an elevated height) | /ˈpwente/ · noun |
| [rosa](https://en.wiktionary.org/wiki/rosa#Spanish) | rose (flower) | /ˈrosa/ · noun |
| [tren](https://en.wiktionary.org/wiki/tren#Spanish) | train | /ˈtɾen/ · noun |
| [accidente](https://en.wiktionary.org/wiki/accidente#Spanish) | accident (unexpected event with negative consequences) | /aɡθiˈdente/ · noun |

</details>

<details><summary>Words 351–400</summary>

![[Resources/Audio/es/Words 0351-0400.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [biblioteca](https://en.wiktionary.org/wiki/biblioteca#Spanish) | library | /bibljoˈteka/ · noun |
| [disco](https://en.wiktionary.org/wiki/disco#Spanish) | club, discotheque | /ˈdisko/ · noun |
| [escritor](https://en.wiktionary.org/wiki/escritor#Spanish) | writer | /eskɾiˈtoɾ/ · noun |
| [secreto](https://en.wiktionary.org/wiki/secreto#Spanish) | secret | /seˈkɾeto/ · adj |
| [global](https://en.wiktionary.org/wiki/global#Spanish) | global (concerning all parts of the world) | /ɡloˈbal/ · adj |
| [animal](https://en.wiktionary.org/wiki/animal#Spanish) | animal | /aniˈmal/ · adj |
| [humor](https://en.wiktionary.org/wiki/humor#Spanish) | mood (a mental or emotional state) | /uˈmoɾ/ · noun |
| [lima](https://en.wiktionary.org/wiki/lima#Spanish) | lime (fruit) | /ˈlima/ · noun |
| [moral](https://en.wiktionary.org/wiki/moral#Spanish) | moral (relating to right and wrong) | /moˈɾal/ · adj |
| [rápidamente](https://en.wiktionary.org/wiki/r%C3%A1pidamente#Spanish) | rapidly, quickly | /ˌrapidaˈmente/ · adv |
| [as](https://en.wiktionary.org/wiki/as#Spanish) | an ace (in a game of cards) | /ˈas/ · noun |
| [bonito](https://en.wiktionary.org/wiki/bonito#Spanish) | pretty, cute | /boˈnito/ · adj |
| [breve](https://en.wiktionary.org/wiki/breve#Spanish) | brief, short | /ˈbɾebe/ · adj |
| [cumpleaños](https://en.wiktionary.org/wiki/cumplea%C3%B1os#Spanish) | birthday | /kumpleˈaɲos/ · noun |
| [firma](https://en.wiktionary.org/wiki/firma#Spanish) | signature | /ˈfiɾma/ · noun |
| [martes](https://en.wiktionary.org/wiki/martes#Spanish) | Tuesday (the third day of the week in many religious traditions, and the second day of the week in systems that use the ISO 8601 norm; it follows Monday and precedes Wednesday) | /ˈmaɾtes/ · noun |
| [metro](https://en.wiktionary.org/wiki/metro#Spanish) | meter | /ˈmetɾo/ · noun |
| [probable](https://en.wiktionary.org/wiki/probable#Spanish) | probable, likely | /pɾoˈbable/ · adj |
| [arma](https://en.wiktionary.org/wiki/arma#Spanish) | weapon, arm | /ˈaɾma/ · noun |
| [onda](https://en.wiktionary.org/wiki/onda#Spanish) | wave (on the surface of a liquid) | /ˈonda/ · noun |
| [software](https://en.wiktionary.org/wiki/software#Spanish) | software (encoded computer instructions) | /ˈsofdw̝eɾ/ · noun |
| [clima](https://en.wiktionary.org/wiki/clima#Spanish) | climate, weather | /ˈklima/ · noun |
| [do](https://en.wiktionary.org/wiki/do#Spanish) | do (musical note) | /ˈdo/ · noun |
| [gracia](https://en.wiktionary.org/wiki/gracia#Spanish) | grace, charm | /ˈɡɾaθja/ · noun |
| [nunca mucho cuesta poco](https://en.wiktionary.org/wiki/nunca%20mucho%20cuesta%20poco#Spanish) | you get what you pay for | /ˌnunka ˌmut͡ʃo ˌkwesta ˈpoko/ · phrase |
| [show](https://en.wiktionary.org/wiki/show#Spanish) | show, spectacle | /ˈʃow/ · noun |
| [vergüenza](https://en.wiktionary.org/wiki/verg%C3%BCenza#Spanish) | shame | /beɾˈɡwenθa/ · noun |
| [ayuntamiento](https://en.wiktionary.org/wiki/ayuntamiento#Spanish) | city council, town council, council (a corporation or body of magistrates in cities and towns, corresponding to mayor and aldermen) | /aʝuntaˈmjento/ · noun |
| [fundamental](https://en.wiktionary.org/wiki/fundamental#Spanish) | fundamental | /fundamenˈtal/ · adj |
| [industrial](https://en.wiktionary.org/wiki/industrial#Spanish) | industrial | /indusˈtɾjal/ · adj |
| [mapa](https://en.wiktionary.org/wiki/mapa#Spanish) | map (sheet with geographical information on it) | /ˈmapa/ · noun |
| [novio](https://en.wiktionary.org/wiki/novio#Spanish) | boyfriend (romantic partner) | /ˈnobjo/ · noun |
| [placer](https://en.wiktionary.org/wiki/placer#Spanish) | to like (something or someone) | /plaˈθeɾ/ · verb |
| [vender](https://en.wiktionary.org/wiki/vender#Spanish) | to sell | /benˈdeɾ/ · verb |
| [viajar](https://en.wiktionary.org/wiki/viajar#Spanish) | to travel, journey | /bjaˈxaɾ/ · verb |
| [famoso](https://en.wiktionary.org/wiki/famoso#Spanish) | well-known, famous | /faˈmoso/ · adj |
| [gato](https://en.wiktionary.org/wiki/gato#Spanish) | cat (unspecified gender) | /ˈɡato/ · noun |
| [hombre de letras](https://en.wiktionary.org/wiki/hombre%20de%20letras#Spanish) | man of letters, a literary man | /ˌombɾe de ˈletɾas/ · noun |
| [abuela](https://en.wiktionary.org/wiki/abuela#Spanish) | grandmother, female equivalent of abuelo | /aˈbwela/ · noun |
| [cola](https://en.wiktionary.org/wiki/cola#Spanish) | tail | /ˈkola/ · noun |
| [labor](https://en.wiktionary.org/wiki/labor#Spanish) | labor | /laˈboɾ/ · noun |
| [universal](https://en.wiktionary.org/wiki/universal#Spanish) | universal | /unibeɾˈsal/ · adj |
| [correr](https://en.wiktionary.org/wiki/correr#Spanish) | to run, to jog | /koˈreɾ/ · verb |
| [dale](https://en.wiktionary.org/wiki/dale#Spanish) | OK, okey dokey, right | /ˈdale/ · intj |
| [moneda](https://en.wiktionary.org/wiki/moneda#Spanish) | coin (piece of currency in the shape of a disc) | /moˈneda/ · noun |
| [motor](https://en.wiktionary.org/wiki/motor#Spanish) | moving | /moˈtoɾ/ · adj |
| [occidental](https://en.wiktionary.org/wiki/occidental#Spanish) | western | /oɡθidenˈtal/ · adj |
| [punta](https://en.wiktionary.org/wiki/punta#Spanish) | tip, point, end | /ˈpunta/ · noun |
| [sub](https://en.wiktionary.org/wiki/sub#Spanish) | under | /ˈsub/ · prep |
| [ángel](https://en.wiktionary.org/wiki/%C3%A1ngel#Spanish) | angel (an incorporeal and sometimes divine messenger from a deity) | /ˈanxel/ · noun |

</details>

<details><summary>Words 401–450</summary>

![[Resources/Audio/es/Words 0401-0450.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [disfrutar](https://en.wiktionary.org/wiki/disfrutar#Spanish) | to enjoy | /disfɾuˈtaɾ/ · verb |
| [millón](https://en.wiktionary.org/wiki/mill%C3%B3n#Spanish) | million (10⁶) | /miˈʝon/ · noun |
| [tío](https://en.wiktionary.org/wiki/t%C3%ADo#Spanish) | uncle (the brother, brother-in-law, or male cousin or cousin-in-law of either parent) | /ˈtio/ · noun |
| [castillo](https://en.wiktionary.org/wiki/castillo#Spanish) | castle (a large building that is fortified and contains many defences) | /kasˈtiʝo/ · noun |
| [parar](https://en.wiktionary.org/wiki/parar#Spanish) | to stop, halt | /paˈɾaɾ/ · verb |
| [árbol](https://en.wiktionary.org/wiki/%C3%A1rbol#Spanish) | tree (perennial woody plant) | /ˈaɾbol/ · noun |
| [bosque](https://en.wiktionary.org/wiki/bosque#Spanish) | forest | /ˈboske/ · noun |
| [ideal](https://en.wiktionary.org/wiki/ideal#Spanish) | ideal | /ideˈal/ · adj |
| [primavera](https://en.wiktionary.org/wiki/primavera#Spanish) | spring (season) | /pɾimaˈbeɾa/ · noun |
| [sal](https://en.wiktionary.org/wiki/sal#Spanish) | salt; table salt | /ˈsal/ · noun |
| [alcohol](https://en.wiktionary.org/wiki/alcohol#Spanish) | alcohol | /alˈkol/ · noun |
| [desastre](https://en.wiktionary.org/wiki/desastre#Spanish) | disaster, catastrophe, calamity | /deˈsastɾe/ · noun |
| [enlace](https://en.wiktionary.org/wiki/enlace#Spanish) | link, connection | /enˈlaθe/ · noun |
| [rock](https://en.wiktionary.org/wiki/rock#Spanish) | rock (music style) | /ˈrok/ · noun |
| [agricultura](https://en.wiktionary.org/wiki/agricultura#Spanish) | agriculture, farming | /aɡɾikulˈtuɾa/ · noun |
| [co](https://en.wiktionary.org/wiki/co#Spanish) | dude, friend | /ˈko/ · noun |
| [enviar](https://en.wiktionary.org/wiki/enviar#Spanish) | to send | /emˈbjaɾ/ · verb |
| [gas natural](https://en.wiktionary.org/wiki/gas%20natural#Spanish) | natural gas | /ˌɡas natuˈɾal/ · noun |
| [generar](https://en.wiktionary.org/wiki/generar#Spanish) | to generate, to create, to produce, to cause | /xeneˈɾaɾ/ · verb |
| [inferior](https://en.wiktionary.org/wiki/inferior#Spanish) | inferior (of lower quality) | /infeˈɾjoɾ/ · adj |
| [mental](https://en.wiktionary.org/wiki/mental#Spanish) | mental | /menˈtal/ · adj |
| [musical](https://en.wiktionary.org/wiki/musical#Spanish) | musical | /musiˈkal/ · adj |
| [ritmo](https://en.wiktionary.org/wiki/ritmo#Spanish) | rhythm | /ˈridmo/ · noun |
| [et](https://en.wiktionary.org/wiki/et#Spanish) | ampersand | /ˈet/ · noun |
| [rural](https://en.wiktionary.org/wiki/rural#Spanish) | rural | /ruˈɾal/ · adj |
| [suelo de fundación](https://en.wiktionary.org/wiki/suelo%20de%20fundaci%C3%B3n#Spanish) | area where the foundations of a building or a complex are located | /ˌswelo de fundaˈθjon/ · noun |
| [ventana](https://en.wiktionary.org/wiki/ventana#Spanish) | window (opening for light and air) | /benˈtana/ · noun |
| [acceder](https://en.wiktionary.org/wiki/acceder#Spanish) | to accede, to agree, to concur | /aɡθeˈdeɾ/ · verb |
| [actor](https://en.wiktionary.org/wiki/actor#Spanish) | actor (person who performs in a theatrical play or movie) | /aɡˈtoɾ/ · noun |
| [andar](https://en.wiktionary.org/wiki/andar#Spanish) | to walk, to go | /anˈdaɾ/ · verb |
| [bar](https://en.wiktionary.org/wiki/bar#Spanish) | bar, coffee shop, café, pub (an establishment where refreshments and alcohol drinks are served) | /ˈbaɾ/ · noun |
| [marina](https://en.wiktionary.org/wiki/marina#Spanish) | navy | /maˈɾina/ · noun |
| [mm](https://en.wiktionary.org/wiki/mm#Spanish) | mamá |  · noun |
| [poeta](https://en.wiktionary.org/wiki/poeta#Spanish) | poet (person who writes poems) | /poˈeta/ · noun |
| [puro](https://en.wiktionary.org/wiki/puro#Spanish) | pure, clear | /ˈpuɾo/ · adj |
| [gloria](https://en.wiktionary.org/wiki/gloria#Spanish) | glory | /ˈɡloɾja/ · noun |
| [granada](https://en.wiktionary.org/wiki/granada#Spanish) | pomegranate (fruit) | /ɡɾaˈnada/ · noun |
| [man](https://en.wiktionary.org/wiki/man#Spanish) | man, guy, dude | /ˈman/ · noun |
| [aviso](https://en.wiktionary.org/wiki/aviso#Spanish) | warning | /aˈbiso/ · noun |
| [leo](https://en.wiktionary.org/wiki/leo#Spanish) | Leo | /ˈleo/ · adj |
| [regular](https://en.wiktionary.org/wiki/regular#Spanish) | to regulate | /reɡuˈlaɾ/ · verb |
| [huevo](https://en.wiktionary.org/wiki/huevo#Spanish) | egg | /ˈw̝ebo/ · noun |
| [paro](https://en.wiktionary.org/wiki/paro#Spanish) | stop, stagnation (action of stopping) | /ˈpaɾo/ · noun |
| [abuelo](https://en.wiktionary.org/wiki/abuelo#Spanish) | grandfather | /aˈbwelo/ · noun |
| [colonia](https://en.wiktionary.org/wiki/colonia#Spanish) | colony | /koˈlonja/ · noun |
| [encuesta](https://en.wiktionary.org/wiki/encuesta#Spanish) | inquest | /enˈkwesta/ · noun |
| [extra](https://en.wiktionary.org/wiki/extra#Spanish) | additional, extra | /ˈeɡstɾa/ · adj |
| [individual](https://en.wiktionary.org/wiki/individual#Spanish) | individual | /indibiˈdwal/ · adj |
| [liberal](https://en.wiktionary.org/wiki/liberal#Spanish) | liberal | /libeˈɾal/ · adj |
| [criminal](https://en.wiktionary.org/wiki/criminal#Spanish) | criminal | /kɾimiˈnal/ · adj |

</details>

<details><summary>Words 451–500</summary>

![[Resources/Audio/es/Words 0451-0500.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [ja](https://en.wiktionary.org/wiki/ja#Spanish) | representation of laughter, ha | /ˈxa/ · intj |
| [lago](https://en.wiktionary.org/wiki/lago#Spanish) | lake | /ˈlaɡo/ · noun |
| [posterior](https://en.wiktionary.org/wiki/posterior#Spanish) | posterior, later | /posteˈɾjoɾ/ · adj |
| [corona](https://en.wiktionary.org/wiki/corona#Spanish) | crown | /koˈɾona/ · noun |
| [dedo](https://en.wiktionary.org/wiki/dedo#Spanish) | digit: finger or toe, literally translated as "finger" and thought of that way by Spanish-speaking learners of English | /ˈdedo/ · noun |
| [flor](https://en.wiktionary.org/wiki/flor#Spanish) | flower (structure in angiosperms) | /ˈfloɾ/ · noun |
| [aceite](https://en.wiktionary.org/wiki/aceite#Spanish) | oil | /aˈθeite/ · noun |
| [castellano](https://en.wiktionary.org/wiki/castellano#Spanish) | Castilian (of, from or relating to the geographic region or former kingdom of Castile, now approximately divided into the autonomous communities of Castile and León, Castilla-La Mancha and the Community of Madrid) | /kasteˈʝano/ · adj |
| [pedo](https://en.wiktionary.org/wiki/pedo#Spanish) | fart | /ˈpedo/ · noun |
| [repente](https://en.wiktionary.org/wiki/repente#Spanish) | attack, upsurge | /reˈpente/ · noun |
| [AM](https://en.wiktionary.org/wiki/AM#Spanish) | AM (before noon) |  · adv |
| [am](https://en.wiktionary.org/wiki/am#Spanish) | a.m. (before noon) | /a ˈeme/ · adv |
| [drama](https://en.wiktionary.org/wiki/drama#Spanish) | drama (genre in art, film, theatre and literature or a work of said genre) | /ˈdɾama/ · noun |
| [magia](https://en.wiktionary.org/wiki/magia#Spanish) | magic | /ˈmaxja/ · noun |
| [moderno](https://en.wiktionary.org/wiki/moderno#Spanish) | modern | /moˈdeɾno/ · adj |
| [muro](https://en.wiktionary.org/wiki/muro#Spanish) | wall | /ˈmuɾo/ · noun |
| [queso](https://en.wiktionary.org/wiki/queso#Spanish) | cheese | /ˈkeso/ · noun |
| [temporal](https://en.wiktionary.org/wiki/temporal#Spanish) | temporal (of or relating to time) | /tempoˈɾal/ · adj |
| [virus](https://en.wiktionary.org/wiki/virus#Spanish) | virus | /ˈbiɾus/ · noun |
| [beso](https://en.wiktionary.org/wiki/beso#Spanish) | kiss | /ˈbeso/ · noun |
| [factor](https://en.wiktionary.org/wiki/factor#Spanish) | factor | /faɡˈtoɾ/ · noun |
| [hacienda](https://en.wiktionary.org/wiki/hacienda#Spanish) | ranch, hacienda | /aˈθjenda/ · noun |
| [ma](https://en.wiktionary.org/wiki/ma#Spanish) | mum; mom | /ˈma/ · noun |
| [mandar](https://en.wiktionary.org/wiki/mandar#Spanish) | to send | /manˈdaɾ/ · verb |
| [metal](https://en.wiktionary.org/wiki/metal#Spanish) | metal | /meˈtal/ · noun |
| [terror](https://en.wiktionary.org/wiki/terror#Spanish) | terror | /teˈroɾ/ · noun |
| [top](https://en.wiktionary.org/wiki/top#Spanish) | top (first positions of a ranking) | /ˈtop/ · noun |
| [PC](https://en.wiktionary.org/wiki/PC#Spanish) | computer | /peˈθe/ · noun |
| [cable](https://en.wiktionary.org/wiki/cable#Spanish) | cable, cord | /ˈkable/ · noun |
| [cantar](https://en.wiktionary.org/wiki/cantar#Spanish) | to sing | /kanˈtaɾ/ · verb |
| [voy y vengo](https://en.wiktionary.org/wiki/voy%20y%20vengo#Spanish) | I'll be right back | /ˌboi i ˈbenɡo/ · phrase |
| [abandonar](https://en.wiktionary.org/wiki/abandonar#Spanish) | to abandon, to leave | /abandoˈnaɾ/ · verb |
| [cena](https://en.wiktionary.org/wiki/cena#Spanish) | supper, dinner | /ˈθena/ · noun |
| [diablo](https://en.wiktionary.org/wiki/diablo#Spanish) | devil | /ˈdjablo/ · noun |
| [idiota](https://en.wiktionary.org/wiki/idiota#Spanish) | idiotic | /iˈdjota/ · adj |
| [italiano](https://en.wiktionary.org/wiki/italiano#Spanish) | Italian (from or native to Italy) | /itaˈljano/ · adj |
| [meter](https://en.wiktionary.org/wiki/meter#Spanish) | to put in, insert | /meˈteɾ/ · verb |
| [portal](https://en.wiktionary.org/wiki/portal#Spanish) | portal; porch | /poɾˈtal/ · noun |
| [so](https://en.wiktionary.org/wiki/so#Spanish) | so | /ˈso/ · intj |
| [chocolate](https://en.wiktionary.org/wiki/chocolate#Spanish) | chocolate (food made from cocoa beans) | /t͡ʃokoˈlate/ · noun |
| [per se](https://en.wiktionary.org/wiki/per%20se#Spanish) | per se | /ˌpeɾ ˈse/ · adv |
| [propaganda](https://en.wiktionary.org/wiki/propaganda#Spanish) | propaganda | /pɾopaˈɡanda/ · noun |
| [agenda](https://en.wiktionary.org/wiki/agenda#Spanish) | agenda, planner (notebook) | /aˈxenda/ · noun |
| [che](https://en.wiktionary.org/wiki/che#Spanish) | name of the digraph Ch/ch; previously considered a letter | /ˈt͡ʃe/ · noun |
| [dibujo](https://en.wiktionary.org/wiki/dibujo#Spanish) | drawing | /diˈbuxo/ · noun |
| [humo](https://en.wiktionary.org/wiki/humo#Spanish) | smoke | /ˈumo/ · noun |
| [levantar](https://en.wiktionary.org/wiki/levantar#Spanish) | to lift | /lebanˈtaɾ/ · verb |
| [link](https://en.wiktionary.org/wiki/link#Spanish) | link (text or a graphic that can be activated to open another document) | /ˈlink/ · noun |
| [pico](https://en.wiktionary.org/wiki/pico#Spanish) | beak (of a bird) | /ˈpiko/ · noun |
| [caro](https://en.wiktionary.org/wiki/caro#Spanish) | dear (loved) | /ˈkaɾo/ · adj |

</details>

<details><summary>Words 501–550</summary>

![[Resources/Audio/es/Words 0501-0550.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [gordo](https://en.wiktionary.org/wiki/gordo#Spanish) | fat | /ˈɡoɾdo/ · adj |
| [habitual](https://en.wiktionary.org/wiki/habitual#Spanish) | habitual | /abiˈtwal/ · adj |
| [japonés](https://en.wiktionary.org/wiki/japon%C3%A9s#Spanish) | of Japan; Japanese | /xapoˈnes/ · adj |
| [nave](https://en.wiktionary.org/wiki/nave#Spanish) | ship, vessel (with a concave hull) | /ˈnabe/ · noun |
| [once](https://en.wiktionary.org/wiki/once#Spanish) | eleven | /ˈonθe/ · num |
| [droga](https://en.wiktionary.org/wiki/droga#Spanish) | drug | /ˈdɾoɡa/ · noun |
| [débil](https://en.wiktionary.org/wiki/d%C3%A9bil#Spanish) | weak | /ˈdebil/ · adj |
| [emperador](https://en.wiktionary.org/wiki/emperador#Spanish) | emperor | /empeɾaˈdoɾ/ · noun |
| [ensayo](https://en.wiktionary.org/wiki/ensayo#Spanish) | essay; paper; nonfiction (in genre-labeling contexts) | /enˈsaʝo/ · noun |
| [funcionar](https://en.wiktionary.org/wiki/funcionar#Spanish) | to work, to function | /funθjoˈnaɾ/ · verb |
| [lento](https://en.wiktionary.org/wiki/lento#Spanish) | slow | /ˈlento/ · adj |
| [pollo](https://en.wiktionary.org/wiki/pollo#Spanish) | chicken (meat) | /ˈpoʝo/ · noun |
| [radical](https://en.wiktionary.org/wiki/radical#Spanish) | radical, seismic | /radiˈkal/ · adj |
| [reloj](https://en.wiktionary.org/wiki/reloj#Spanish) | clock | /reˈlox/ · noun |
| [abuso](https://en.wiktionary.org/wiki/abuso#Spanish) | abuse | /aˈbuso/ · noun |
| [computadora](https://en.wiktionary.org/wiki/computadora#Spanish) | computer | /komputaˈdoɾa/ · noun |
| [mama](https://en.wiktionary.org/wiki/mama#Spanish) | mamma, breast | /ˈmama/ · noun |
| [nuclear](https://en.wiktionary.org/wiki/nuclear#Spanish) | nuclear | /nukleˈaɾ/ · adj |
| [porno](https://en.wiktionary.org/wiki/porno#Spanish) | porn, pornography | /ˈpoɾno/ · noun |
| [virtual](https://en.wiktionary.org/wiki/virtual#Spanish) | virtual (in effect or essence, not in fact or reality) | /biɾˈtwal/ · adj |
| [canto](https://en.wiktionary.org/wiki/canto#Spanish) | singing | /ˈkanto/ · noun |
| [conductor](https://en.wiktionary.org/wiki/conductor#Spanish) | driver | /konduɡˈtoɾ/ · noun |
| [editor](https://en.wiktionary.org/wiki/editor#Spanish) | editor | /ediˈtoɾ/ · noun |
| [manga](https://en.wiktionary.org/wiki/manga#Spanish) | sleeve | /ˈmanɡa/ · noun |
| [quinto](https://en.wiktionary.org/wiki/quinto#Spanish) | fifth | /ˈkinto/ · adj |
| [acusado](https://en.wiktionary.org/wiki/acusado#Spanish) | accused | /akuˈsado/ · adj |
| [arco](https://en.wiktionary.org/wiki/arco#Spanish) | bow (weapon) | /ˈaɾko/ · noun |
| [riqueza cultural](https://en.wiktionary.org/wiki/riqueza%20cultural#Spanish) | cultural wealth (the collection of arts, architecture, etc. that help to define the culture of a region) | /riˌkeθa kultuˈɾal/ · noun |
| [bienvenido](https://en.wiktionary.org/wiki/bienvenido#Spanish) | welcome | /bjembeˈnido/ · adj |
| [consigo](https://en.wiktionary.org/wiki/consigo#Spanish) | with himself, herself, itself, themselves | /konˈsiɡo/ · adv |
| [data](https://en.wiktionary.org/wiki/data#Spanish) | date (point of time at which a transaction or event takes place) | /ˈdata/ · noun |
| [go](https://en.wiktionary.org/wiki/go#Spanish) | go (game) | /ˈɡo/ · noun |
| [lanza](https://en.wiktionary.org/wiki/lanza#Spanish) | lance, spear, glaive | /ˈlanθa/ · noun |
| [manual](https://en.wiktionary.org/wiki/manual#Spanish) | manual (performed by the hands) | /maˈnwal/ · adj |
| [mate](https://en.wiktionary.org/wiki/mate#Spanish) | matte (not reflective of light) | /ˈmate/ · adj |
| [bello](https://en.wiktionary.org/wiki/bello#Spanish) | beautiful, fair | /ˈbeʝo/ · adj |
| [bravo](https://en.wiktionary.org/wiki/bravo#Spanish) | angry, furious | /ˈbɾabo/ · adj |
| [catalán](https://en.wiktionary.org/wiki/catal%C3%A1n#Spanish) | Catalan, Catalonian (of, from or relating to Catalonia) | /kataˈlan/ · adj |
| [espada](https://en.wiktionary.org/wiki/espada#Spanish) | sword (a long bladed weapon with a grip and typically a pommel and crossguard (together forming a hilt), which is designed to cut, stab, slash and/or hack) | /esˈpada/ · noun |
| [gasolina](https://en.wiktionary.org/wiki/gasolina#Spanish) | petrol, gasoline | /ɡasoˈlina/ · noun |
| [formal](https://en.wiktionary.org/wiki/formal#Spanish) | formal | /foɾˈmal/ · adj |
| [gris](https://en.wiktionary.org/wiki/gris#Spanish) | grey / gray | /ˈɡɾis/ · adj |
| [ira](https://en.wiktionary.org/wiki/ira#Spanish) | anger, ire | /ˈiɾa/ · noun |
| [jean](https://en.wiktionary.org/wiki/jean#Spanish) | jeans |  · noun |
| [pesca](https://en.wiktionary.org/wiki/pesca#Spanish) | fishing | /ˈpeska/ · noun |
| [pinta](https://en.wiktionary.org/wiki/pinta#Spanish) | look, appearance | /ˈpinta/ · noun |
| [salsa](https://en.wiktionary.org/wiki/salsa#Spanish) | sauce, gravy (liquid condiment) | /ˈsalsa/ · noun |
| [tesoro](https://en.wiktionary.org/wiki/tesoro#Spanish) | treasure, trove, treasure trove | /teˈsoɾo/ · noun |
| [toledo](https://en.wiktionary.org/wiki/toledo#Spanish) | toilet |  · noun |
| [ala](https://en.wiktionary.org/wiki/ala#Spanish) | wing (of a bird or insect) | /ˈala/ · noun |

</details>

<details><summary>Words 551–600</summary>

![[Resources/Audio/es/Words 0551-0600.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [bicicleta](https://en.wiktionary.org/wiki/bicicleta#Spanish) | bicycle, pushbike, cycle | /biθiˈkleta/ · noun |
| [bolsillo](https://en.wiktionary.org/wiki/bolsillo#Spanish) | pocket | /bolˈsiʝo/ · noun |
| [cinta](https://en.wiktionary.org/wiki/cinta#Spanish) | ribbon, worn by girls in the hair | /ˈθinta/ · noun |
| [coca](https://en.wiktionary.org/wiki/coca#Spanish) | coca (any of the four cultivated plants which belong to the family Erythroxylaceae, native to western South America) | /ˈkoka/ · noun |
| [taxi](https://en.wiktionary.org/wiki/taxi#Spanish) | taxi | /ˈtaɡsi/ · noun |
| [beber](https://en.wiktionary.org/wiki/beber#Spanish) | to drink | /beˈbeɾ/ · verb |
| [cansado](https://en.wiktionary.org/wiki/cansado#Spanish) | tired, weary, wearied | /kanˈsado/ · adj |
| [pop](https://en.wiktionary.org/wiki/pop#Spanish) | pop, pop music | /ˈpop/ · noun |
| [banca](https://en.wiktionary.org/wiki/banca#Spanish) | small bench | /ˈbanka/ · noun |
| [caos](https://en.wiktionary.org/wiki/caos#Spanish) | chaos | /ˈkaos/ · noun |
| [integral](https://en.wiktionary.org/wiki/integral#Spanish) | integral | /inteˈɡɾal/ · adj |
| [pastor](https://en.wiktionary.org/wiki/pastor#Spanish) | shepherd | /pasˈtoɾ/ · noun |
| [té](https://en.wiktionary.org/wiki/t%C3%A9#Spanish) | tea | /ˈte/ · noun |
| [grito](https://en.wiktionary.org/wiki/grito#Spanish) | a cry, a yell, a scream, a growl | /ˈɡɾito/ · noun |
| [juzgado](https://en.wiktionary.org/wiki/juzgado#Spanish) | a court of law with a judge | /xuθˈɡado/ · noun |
| [locos y niños dicen la verdad](https://en.wiktionary.org/wiki/locos%20y%20ni%C3%B1os%20dicen%20la%20verdad#Spanish) | Crazy people and children tell the truth, meaning they have no inhibition to express how they see things. Compare both in vino veritas and out of the mouths of babes. | /ˌlokos i ˌniɲos ˌdiθen la beɾˈdad/ · phrase |
| [otoño](https://en.wiktionary.org/wiki/oto%C3%B1o#Spanish) | autumn, fall | /oˈtoɲo/ · noun |
| [seco](https://en.wiktionary.org/wiki/seco#Spanish) | dry | /ˈseko/ · adj |
| [toro](https://en.wiktionary.org/wiki/toro#Spanish) | bull | /ˈtoɾo/ · noun |
| [barato](https://en.wiktionary.org/wiki/barato#Spanish) | cheap; inexpensive; sold at a low price | /baˈɾato/ · adj |
| [notable](https://en.wiktionary.org/wiki/notable#Spanish) | remarkable, notable, noteworthy, noticeable, significant, marked, outstanding, striking, noted | /noˈtable/ · adj |
| [pasta](https://en.wiktionary.org/wiki/pasta#Spanish) | pasta | /ˈpasta/ · noun |
| [we](https://en.wiktionary.org/wiki/we#Spanish) | dude, guy, buddy | /ˈwe/ · noun |
| [amar](https://en.wiktionary.org/wiki/amar#Spanish) | to love, have great affection for, care about | /aˈmaɾ/ · verb |
| [calendario](https://en.wiktionary.org/wiki/calendario#Spanish) | calendar | /kalenˈdaɾjo/ · noun |
| [circular](https://en.wiktionary.org/wiki/circular#Spanish) | circular | /θiɾkuˈlaɾ/ · adj |
| [cruel](https://en.wiktionary.org/wiki/cruel#Spanish) | cruel | /ˈkɾwel/ · adj |
| [noble](https://en.wiktionary.org/wiki/noble#Spanish) | noble | /ˈnoble/ · adj |
| [tour](https://en.wiktionary.org/wiki/tour#Spanish) | tour, guided visit to a country, museum, etc. | /ˈtuɾ/ · noun |
| [CD](https://en.wiktionary.org/wiki/CD#Spanish) | CD (compact disc) | /θeˈde/ · noun |
| [ca](https://en.wiktionary.org/wiki/ca#Spanish) | Denotes incredulity or negation; oh no! | /ˈka/ · intj |
| [descubrimiento](https://en.wiktionary.org/wiki/descubrimiento#Spanish) | discovery (something discovered) | /deskubɾiˈmjento/ · noun |
| [info](https://en.wiktionary.org/wiki/info#Spanish) | info | /ˈinfo/ · noun |
| [wow](https://en.wiktionary.org/wiki/wow#Spanish) | wow (an indication of excitement or surprise) | /ˈwau/ · intj |
| [bob](https://en.wiktionary.org/wiki/bob#Spanish) | bob, bob haircut (hairstyle) | /ˈbob/ · noun |
| [camión](https://en.wiktionary.org/wiki/cami%C3%B3n#Spanish) | lorry (UK); truck (US) | /kaˈmjon/ · noun |
| [latino](https://en.wiktionary.org/wiki/latino#Spanish) | of Latin America or Latin American people | /laˈtino/ · adj |
| [pizza](https://en.wiktionary.org/wiki/pizza#Spanish) | pizza (Italian dish) | /ˈpitsa/ · noun |
| [rival](https://en.wiktionary.org/wiki/rival#Spanish) | rival | /riˈbal/ · adj |
| [fan](https://en.wiktionary.org/wiki/fan#Spanish) | fan | /ˈfan/ · noun |
| [play](https://en.wiktionary.org/wiki/play#Spanish) | play (button) | /ˈplei/ · noun |
| [sano](https://en.wiktionary.org/wiki/sano#Spanish) | healthy, sound | /ˈsano/ · adj |
| [abandonado](https://en.wiktionary.org/wiki/abandonado#Spanish) | abandoned | /abandoˈnado/ · adj |
| [bus](https://en.wiktionary.org/wiki/bus#Spanish) | bus | /ˈbus/ · noun |
| [diccionario](https://en.wiktionary.org/wiki/diccionario#Spanish) | dictionary, wordbook | /ˌdiɡθjoˈnaɾjo/ · noun |
| [fresco](https://en.wiktionary.org/wiki/fresco#Spanish) | fresh | /ˈfɾesko/ · adj |
| [misa](https://en.wiktionary.org/wiki/misa#Spanish) | mass (church) | /ˈmisa/ · noun |
| [pesado](https://en.wiktionary.org/wiki/pesado#Spanish) | heavy in weight, weighty | /peˈsado/ · adj |
| [xi](https://en.wiktionary.org/wiki/xi#Spanish) | xi; the Greek letter Ξ, ξ | /ˈsi/ · noun |
| [gramática](https://en.wiktionary.org/wiki/gram%C3%A1tica) | grammar |  · noun |

</details>

<details><summary>Words 601–650</summary>

![[Resources/Audio/es/Words 0601-0650.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [macho](https://en.wiktionary.org/wiki/macho#Spanish) | male | /ˈmat͡ʃo/ · adj |
| [mail](https://en.wiktionary.org/wiki/mail#Spanish) | email | /ˈmeil/ · noun |
| [maíz](https://en.wiktionary.org/wiki/ma%C3%ADz#Spanish) | corn, maize | /maˈiθ/ · noun |
| [ola](https://en.wiktionary.org/wiki/ola#Spanish) | wave (on the surface of a liquid) | /ˈola/ · noun |
| [oral](https://en.wiktionary.org/wiki/oral#Spanish) | oral | /oˈɾal/ · adj |
| [escudo](https://en.wiktionary.org/wiki/escudo#Spanish) | shield | /esˈkudo/ · noun |
| [fuga](https://en.wiktionary.org/wiki/fuga#Spanish) | escape, flight | /ˈfuɡa/ · noun |
| [garganta](https://en.wiktionary.org/wiki/garganta#Spanish) | throat | /ɡaɾˈɡanta/ · noun |
| [helado](https://en.wiktionary.org/wiki/helado#Spanish) | icy, frozen | /eˈlado/ · adj |
| [house](https://en.wiktionary.org/wiki/house#Spanish) | house music, house (a genre of music) | /ˈxaus/ · noun |
| [lobo](https://en.wiktionary.org/wiki/lobo#Spanish) | wolf (wild Canis lupus) | /ˈlobo/ · noun |
| [visible](https://en.wiktionary.org/wiki/visible#Spanish) | visible | /biˈsible/ · adj |
| [bahía](https://en.wiktionary.org/wiki/bah%C3%ADa#Spanish) | bay (geographical feature) | /baˈia/ · noun |
| [hey](https://en.wiktionary.org/wiki/hey#Spanish) | hey! | /ˈei/ · intj |
| [marketing](https://en.wiktionary.org/wiki/marketing#Spanish) | marketing | /ˈmaɾketin/ · noun |
| [mini](https://en.wiktionary.org/wiki/mini#Spanish) | mini | /ˈmini/ · adj |
| [pez](https://en.wiktionary.org/wiki/pez#Spanish) | fish (especially if alive or not intended for consumption) | /ˈpeθ/ · noun |
| [po](https://en.wiktionary.org/wiki/po#Spanish) | emphatic, well | /ˈpo/ · intj |
| [sistema operativo](https://en.wiktionary.org/wiki/sistema%20operativo#Spanish) | operating system | /sisˌtema opeɾaˈtibo/ · noun |
| [terminal](https://en.wiktionary.org/wiki/terminal#Spanish) | final, last | /teɾmiˈnal/ · adj |
| [triple](https://en.wiktionary.org/wiki/triple#Spanish) | triple | /ˈtɾiple/ · adj |
| [vela](https://en.wiktionary.org/wiki/vela#Spanish) | candle | /ˈbela/ · noun |
| [adulto](https://en.wiktionary.org/wiki/adulto#Spanish) | adult | /aˈdulto/ · adj |
| [continental](https://en.wiktionary.org/wiki/continental#Spanish) | continental | /kontinenˈtal/ · adj |
| [crema](https://en.wiktionary.org/wiki/crema#Spanish) | cream (cosmetic product) | /ˈkɾema/ · noun |
| [fa](https://en.wiktionary.org/wiki/fa#Spanish) | fa (fourth diatonic (or sixth chromatic) musical note) | /ˈfa/ · noun |
| [mortal](https://en.wiktionary.org/wiki/mortal#Spanish) | deadly | /moɾˈtal/ · adj |
| [romano](https://en.wiktionary.org/wiki/romano#Spanish) | Roman (of, from or relating to the city of Rome, capital of Italy) | /roˈmano/ · adj |
| [anime](https://en.wiktionary.org/wiki/anime#Spanish) | anime (artistic style originating in Japan) | /ˈanime/ · noun |
| [boy](https://en.wiktionary.org/wiki/boy#Spanish) | a male stripper | /ˈboi/ · noun |
| [inevitable](https://en.wiktionary.org/wiki/inevitable#Spanish) | inevitable, inescapable, unavoidable (unable to be avoided) | /inebiˈtable/ · adj |
| [miel](https://en.wiktionary.org/wiki/miel#Spanish) | honey | /ˈmjel/ · noun |
| [piano](https://en.wiktionary.org/wiki/piano#Spanish) | piano | /ˈpjano/ · noun |
| [balance](https://en.wiktionary.org/wiki/balance#Spanish) | balance; weighing up | /baˈlanθe/ · noun |
| [considerable](https://en.wiktionary.org/wiki/considerable#Spanish) | considerable (significant) | /konsideˈɾable/ · adj |
| [coro](https://en.wiktionary.org/wiki/coro#Spanish) | choir | /ˈkoɾo/ · noun |
| [full](https://en.wiktionary.org/wiki/full#Spanish) | full house | /ˈful/ · noun |
| [hueso](https://en.wiktionary.org/wiki/hueso#Spanish) | bone | /ˈw̝eso/ · noun |
| [mentir](https://en.wiktionary.org/wiki/mentir#Spanish) | to lie (say something untrue) | /menˈtiɾ/ · verb |
| [pilar](https://en.wiktionary.org/wiki/pilar#Spanish) | pillar, pier, mainstay | /piˈlaɾ/ · noun |
| [test](https://en.wiktionary.org/wiki/test#Spanish) | test | /ˈtest/ · noun |
| [abandono](https://en.wiktionary.org/wiki/abandono#Spanish) | abandonment | /abanˈdono/ · noun |
| [center](https://en.wiktionary.org/wiki/center#Spanish) | center | /ˈsenteɾ/ · noun |
| [manzana](https://en.wiktionary.org/wiki/manzana#Spanish) | apple | /manˈθana/ · noun |
| [mato](https://en.wiktionary.org/wiki/mato#Spanish) | bushes | /ˈmato/ · noun |
| [natal](https://en.wiktionary.org/wiki/natal#Spanish) | natal | /naˈtal/ · adj |
| [ordenador](https://en.wiktionary.org/wiki/ordenador#Spanish) | computer | /oɾdenaˈdoɾ/ · noun |
| [tubo](https://en.wiktionary.org/wiki/tubo#Spanish) | tube | /ˈtubo/ · noun |
| [vapor](https://en.wiktionary.org/wiki/vapor#Spanish) | steam, vapor (water vapor) | /baˈpoɾ/ · noun |
| [alba](https://en.wiktionary.org/wiki/alba#Spanish) | dawn | /ˈalba/ · noun |

</details>

<details><summary>Words 651–700</summary>

![[Resources/Audio/es/Words 0651-0700.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [artificial](https://en.wiktionary.org/wiki/artificial#Spanish) | artificial | /aɾtifiˈθjal/ · adj |
| [escritorio](https://en.wiktionary.org/wiki/escritorio#Spanish) | writing desk | /eskɾiˈtoɾjo/ · noun |
| [laguna](https://en.wiktionary.org/wiki/laguna#Spanish) | lagoon | /laˈɡuna/ · noun |
| [press](https://en.wiktionary.org/wiki/press#Spanish) | exercise press | /ˈpɾes/ · noun |
| [tigre](https://en.wiktionary.org/wiki/tigre#Spanish) | tiger | /ˈtiɡɾe/ · noun |
| [can](https://en.wiktionary.org/wiki/can#Spanish) | dog, hound | /ˈkan/ · noun |
| [delgado](https://en.wiktionary.org/wiki/delgado#Spanish) | thin, slender, skinny | /delˈɡado/ · adj |
| [dictador](https://en.wiktionary.org/wiki/dictador#Spanish) | dictator | /diɡtaˈdoɾ/ · noun |
| [fantasma](https://en.wiktionary.org/wiki/fantasma#Spanish) | ghost, phantom, wraith | /fanˈtasma/ · noun |
| [harina](https://en.wiktionary.org/wiki/harina#Spanish) | flour | /aˈɾina/ · noun |
| [mono](https://en.wiktionary.org/wiki/mono#Spanish) | monkey | /ˈmono/ · noun |
| [plus](https://en.wiktionary.org/wiki/plus#Spanish) | bonus (extra earnings) | /ˈplus/ · noun |
| [satisfacer](https://en.wiktionary.org/wiki/satisfacer#Spanish) | to satisfy, fulfil / fulfill | /satisfaˈθeɾ/ · verb |
| [tapa](https://en.wiktionary.org/wiki/tapa#Spanish) | lid, cap (the top or cover of a container) | /ˈtapa/ · noun |
| [vera](https://en.wiktionary.org/wiki/vera#Spanish) | side, face | /ˈbeɾa/ · noun |
| [ave](https://en.wiktionary.org/wiki/ave#Spanish) | bird | /ˈabe/ · noun |
| [coma](https://en.wiktionary.org/wiki/coma#Spanish) | comma (punctuation mark) | /ˈkoma/ · noun |
| [ida y vuelta](https://en.wiktionary.org/wiki/ida%20y%20vuelta#Spanish) | round trip, return trip | /ˌida i ˈbwelta/ · noun |
| [like](https://en.wiktionary.org/wiki/like#Spanish) | like | /ˈlaik/ · noun |
| [cadáver](https://en.wiktionary.org/wiki/cad%C3%A1ver#Spanish) | cadaver, corpse | /kaˈdabeɾ/ · noun |
| [nazi](https://en.wiktionary.org/wiki/nazi#Spanish) | Nazi | /ˈnaθi/ · noun |
| [pata](https://en.wiktionary.org/wiki/pata#Spanish) | paw, foot, leg (of an animal) | /ˈpata/ · noun |
| [saga](https://en.wiktionary.org/wiki/saga#Spanish) | saga | /ˈsaɡa/ · noun |
| [sombrero](https://en.wiktionary.org/wiki/sombrero#Spanish) | hat | /somˈbɾeɾo/ · noun |
| [baby](https://en.wiktionary.org/wiki/baby#Spanish) | baby | /ˈbeibi/ · noun |
| [cerdo](https://en.wiktionary.org/wiki/cerdo#Spanish) | dirty | /ˈθeɾdo/ · adj |
| [chat](https://en.wiktionary.org/wiki/chat#Spanish) | chat (exchange of text or voice messages in real time through a computer network) | /ˈt͡ʃat/ · noun |
| [cuchillo](https://en.wiktionary.org/wiki/cuchillo#Spanish) | knife | /kuˈt͡ʃiʝo/ · noun |
| [eta](https://en.wiktionary.org/wiki/eta#Spanish) | eta; the Greek letter Η, η | /ˈeta/ · noun |
| [limón](https://en.wiktionary.org/wiki/lim%C3%B3n#Spanish) | lemon (fruit) | /liˈmon/ · noun |
| [micro](https://en.wiktionary.org/wiki/micro#Spanish) | minibus | /ˈmikɾo/ · noun |
| [uh](https://en.wiktionary.org/wiki/uh#Spanish) | used to express disappointment or disdain | /u/ · intj |
| [variable](https://en.wiktionary.org/wiki/variable#Spanish) | variable | /baˈɾjable/ · adj |
| [cobra](https://en.wiktionary.org/wiki/cobra#Spanish) | cobra | /ˈkobɾa/ · noun |
| [gratuito](https://en.wiktionary.org/wiki/gratuito#Spanish) | free, free of charge, gratis | /ɡɾaˈtwito/ · adj |
| [lateral](https://en.wiktionary.org/wiki/lateral#Spanish) | lateral, to the side | /lateˈɾal/ · adj |
| [pos](https://en.wiktionary.org/wiki/pos#Spanish) | synonym of pues | /ˈpos/ · conj |
| [arroyo](https://en.wiktionary.org/wiki/arroyo#Spanish) | stream, brook, creek (whether it flows year-round or only seasonally) | /aˈroʝo/ · noun |
| [cenar](https://en.wiktionary.org/wiki/cenar#Spanish) | to dine; to have supper; to have a lavish meal | /θeˈnaɾ/ · verb |
| [lord](https://en.wiktionary.org/wiki/lord#Spanish) | lord (British title) | /ˈloɾd/ · noun |
| [polo](https://en.wiktionary.org/wiki/polo#Spanish) | pole | /ˈpolo/ · noun |
| [racismo](https://en.wiktionary.org/wiki/racismo#Spanish) | racism (discrimination based on race) | /raˈθismo/ · noun |
| [sonar](https://en.wiktionary.org/wiki/sonar#Spanish) | to sound, to ring | /soˈnaɾ/ · verb |
| [tomate](https://en.wiktionary.org/wiki/tomate#Spanish) | tomato (plant) | /toˈmate/ · noun |
| [bestia](https://en.wiktionary.org/wiki/bestia#Spanish) | beast | /ˈbestja/ · noun |
| [euro](https://en.wiktionary.org/wiki/euro#Spanish) | euro (currency) | /ˈeuɾo/ · noun |
| [fi](https://en.wiktionary.org/wiki/fi#Spanish) | phi; the Greek letter Φ, φ | /ˈfi/ · noun |
| [jo](https://en.wiktionary.org/wiki/jo#Spanish) | stop, whoa (especially when commanding a horse or imitative thereof) | /ˈxo/ · intj |
| [lady](https://en.wiktionary.org/wiki/lady#Spanish) | lady (wife of a lord; important woman) | /ˈleidi/ · noun |
| [open](https://en.wiktionary.org/wiki/open#Spanish) | open | /ˈopen/ · noun |

</details>

<details><summary>Words 701–750</summary>

![[Resources/Audio/es/Words 0701-0750.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [rata](https://en.wiktionary.org/wiki/rata#Spanish) | rat (medium-sized rodent belonging to the Rattus genus) | /ˈrata/ · noun |
| [saltar](https://en.wiktionary.org/wiki/saltar#Spanish) | to jump | /salˈtaɾ/ · verb |
| [escape](https://en.wiktionary.org/wiki/escape#Spanish) | escape | /esˈkape/ · noun |
| [fatal](https://en.wiktionary.org/wiki/fatal#Spanish) | fatal | /faˈtal/ · adj |
| [golf](https://en.wiktionary.org/wiki/golf#Spanish) | golf | /ˈɡolf/ · noun |
| [green](https://en.wiktionary.org/wiki/green#Spanish) | green | /ˈɡɾin/ · noun |
| [set](https://en.wiktionary.org/wiki/set#Spanish) | set | /ˈset/ · noun |
| [cerebral](https://en.wiktionary.org/wiki/cerebral#Spanish) | cerebral | /θeɾeˈbɾal/ · adj |
| [coco](https://en.wiktionary.org/wiki/coco#Spanish) | coconut | /ˈkoko/ · noun |
| [funeral](https://en.wiktionary.org/wiki/funeral#Spanish) | funerary, funeral | /funeˈɾal/ · adj |
| [fórmula química](https://en.wiktionary.org/wiki/f%C3%B3rmula%20qu%C3%ADmica#Spanish) | molecular formula | /ˌfoɾmula ˈkimika/ · noun |
| [invisible](https://en.wiktionary.org/wiki/invisible#Spanish) | invisible | /imbiˈsible/ · adj |
| [robot](https://en.wiktionary.org/wiki/robot#Spanish) | robot | /roˈbot/ · noun |
| [rubia](https://en.wiktionary.org/wiki/rubia#Spanish) | station wagon; estate car | /ˈrubja/ · noun |
| [trigo](https://en.wiktionary.org/wiki/trigo#Spanish) | wheat | /ˈtɾiɡo/ · noun |
| [vertical](https://en.wiktionary.org/wiki/vertical#Spanish) | vertical | /beɾtiˈkal/ · adj |
| [altar](https://en.wiktionary.org/wiki/altar#Spanish) | altar (flat-topped structure used for religious rites) | /alˈtaɾ/ · noun |
| [gala](https://en.wiktionary.org/wiki/gala#Spanish) | gala | /ˈɡala/ · noun |
| [mineral](https://en.wiktionary.org/wiki/mineral#Spanish) | mineral | /mineˈɾal/ · adj |
| [ejercicio](https://en.wiktionary.org/wiki/ejercicio) | exercise; practice |  · noun |
| [pila](https://en.wiktionary.org/wiki/pila#Spanish) | small battery | /ˈpila/ · noun |
| [visa](https://en.wiktionary.org/wiki/visa#Spanish) | visa | /ˈbisa/ · noun |
| [line](https://en.wiktionary.org/wiki/line#Spanish) | lineout | /ˈlain/ · noun |
| [off](https://en.wiktionary.org/wiki/off#Spanish) | off-screen | /ˈof/ · adj |
| [ritual](https://en.wiktionary.org/wiki/ritual#Spanish) | ritual | /riˈtwal/ · adj |
| [verme](https://en.wiktionary.org/wiki/verme#Spanish) | worm | /ˈbeɾme/ · noun |
| [cole](https://en.wiktionary.org/wiki/cole#Spanish) | school | /ˈkole/ · noun |
| [ego](https://en.wiktionary.org/wiki/ego#Spanish) | ego | /ˈeɡo/ · noun |
| [hueco](https://en.wiktionary.org/wiki/hueco#Spanish) | hollow, empty | /ˈw̝eko/ · adj |
| [imperial](https://en.wiktionary.org/wiki/imperial#Spanish) | imperial | /impeˈɾjal/ · adj |
| [out](https://en.wiktionary.org/wiki/out#Spanish) | out |  · noun |
| [panel](https://en.wiktionary.org/wiki/panel#Spanish) | panel (“material object”) | /paˈnel/ · noun |
| [bolso](https://en.wiktionary.org/wiki/bolso#Spanish) | purse | /ˈbolso/ · noun |
| [fauna](https://en.wiktionary.org/wiki/fauna#Spanish) | fauna | /ˈfauna/ · noun |
| [flash](https://en.wiktionary.org/wiki/flash#Spanish) | flash | /ˈflaʃ/ · noun |
| [funda](https://en.wiktionary.org/wiki/funda#Spanish) | a case, a covering or bag used to wrap something up and protect it | /ˈfunda/ · noun |
| [miserable](https://en.wiktionary.org/wiki/miserable#Spanish) | miserable | /miseˈɾable/ · adj |
| [cuadrado](https://en.wiktionary.org/wiki/cuadrado#Spanish) | square | /kwaˈdɾado/ · adj |
| [ente](https://en.wiktionary.org/wiki/ente#Spanish) | being | /ˈente/ · noun |
| [homosexual](https://en.wiktionary.org/wiki/homosexual#Spanish) | homosexual | /omoseɡˈswal/ · adj |
| [inspector](https://en.wiktionary.org/wiki/inspector#Spanish) | inspector | /inspeɡˈtoɾ/ · noun |
| [jazz](https://en.wiktionary.org/wiki/jazz#Spanish) | jazz | /ˈʝas/ · noun |
| [latín](https://en.wiktionary.org/wiki/lat%C3%ADn#Spanish) | Latin (the language of the ancient Romans) | /laˈtin/ · noun |
| [rumor](https://en.wiktionary.org/wiki/rumor#Spanish) | rumor | /ruˈmoɾ/ · noun |
| [muñeca](https://en.wiktionary.org/wiki/mu%C3%B1eca#Spanish) | wrist | /muˈɲeka/ · noun |
| [máscara](https://en.wiktionary.org/wiki/m%C3%A1scara#Spanish) | mask | /ˈmaskaɾa/ · noun |
| [potable](https://en.wiktionary.org/wiki/potable#Spanish) | potable, drinkable | /poˈtable/ · adj |
| [singular](https://en.wiktionary.org/wiki/singular#Spanish) | singular | /sinɡuˈlaɾ/ · adj |
| [frenar](https://en.wiktionary.org/wiki/frenar#Spanish) | to brake (a vehicle) | /fɾeˈnaɾ/ · verb |
| [je](https://en.wiktionary.org/wiki/je#Spanish) | Used to represent laughter, mockery or disbelief; heh. |  · intj |

</details>

<details><summary>Words 751–800</summary>

![[Resources/Audio/es/Words 0751-0800.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [jersey](https://en.wiktionary.org/wiki/jersey#Spanish) | sweater, pullover | /xeɾˈsei/ · noun |
| [monitor](https://en.wiktionary.org/wiki/monitor#Spanish) | monitor (electronic device) | /moniˈtoɾ/ · noun |
| [col](https://en.wiktionary.org/wiki/col#Spanish) | cabbage | /ˈkol/ · noun |
| [gallo](https://en.wiktionary.org/wiki/gallo#Spanish) | rooster, cock (male domestic chicken) | /ˈɡaʝo/ · noun |
| [juramento](https://en.wiktionary.org/wiki/juramento#Spanish) | an oath | /xuɾaˈmento/ · noun |
| [relieve](https://en.wiktionary.org/wiki/relieve#Spanish) | relief (protrusion) | /reˈljebe/ · noun |
| [sumo](https://en.wiktionary.org/wiki/sumo#Spanish) | highest, greatest, superlative | /ˈsumo/ · adj |
| [tic](https://en.wiktionary.org/wiki/tic#Spanish) | tic (movement) | /ˈtik/ · noun |
| [bo](https://en.wiktionary.org/wiki/bo#Spanish) | hey, mate, dude | /ˈbo/ · intj |
| [corporal](https://en.wiktionary.org/wiki/corporal#Spanish) | body; corporal | /koɾpoˈɾal/ · adj |
| [pirata](https://en.wiktionary.org/wiki/pirata#Spanish) | pirate (person who commits robbery at sea against other ships) | /piˈɾata/ · noun |
| [serpiente](https://en.wiktionary.org/wiki/serpiente#Spanish) | snake, serpent (legless reptile of the sub-order Serpentes) | /seɾˈpjente/ · noun |
| [sinónimo](https://en.wiktionary.org/wiki/sin%C3%B3nimo#Spanish) | synonymous | /siˈnonimo/ · adj |
| [vice](https://en.wiktionary.org/wiki/vice#Spanish) | vice (second in command) |  · noun |
| [DVD](https://en.wiktionary.org/wiki/DVD#Spanish) | DVD (optical disc) | /debeˈde/ · noun |
| [bot](https://en.wiktionary.org/wiki/bot#Spanish) | bot (robot) | /ˈbot/ · noun |
| [iris](https://en.wiktionary.org/wiki/iris#Spanish) | iris | /ˈiɾis/ · noun |
| [matanza](https://en.wiktionary.org/wiki/matanza#Spanish) | kill, killing (the act of killing) | /maˈtanθa/ · noun |
| [naval](https://en.wiktionary.org/wiki/naval#Spanish) | naval (of or relating to a navy) | /naˈbal/ · adj |
| [nostalgia](https://en.wiktionary.org/wiki/nostalgia#Spanish) | nostalgia | /nosˈtalxja/ · noun |
| [pato](https://en.wiktionary.org/wiki/pato#Spanish) | duck, drake | /ˈpato/ · noun |
| [abra](https://en.wiktionary.org/wiki/abra#Spanish) | small bay, inlet | /ˈabɾa/ · noun |
| [adelantado](https://en.wiktionary.org/wiki/adelantado#Spanish) | ahead of one's time, advanced | /adelanˈtado/ · adj |
| [clan](https://en.wiktionary.org/wiki/clan#Spanish) | clan | /ˈklan/ · noun |
| [nido](https://en.wiktionary.org/wiki/nido#Spanish) | nest | /ˈnido/ · noun |
| [semi](https://en.wiktionary.org/wiki/semi#Spanish) | semifinal, semi-final |  · noun |
| [torta](https://en.wiktionary.org/wiki/torta#Spanish) | cake | /ˈtoɾta/ · noun |
| [africano](https://en.wiktionary.org/wiki/africano#Spanish) | African (of, from or relating to Africa) | /afɾiˈkano/ · adj |
| [face](https://en.wiktionary.org/wiki/face#Spanish) | face | /ˈfaθe/ · noun |
| [gripe](https://en.wiktionary.org/wiki/gripe#Spanish) | flu, influenza | /ˈɡɾipe/ · noun |
| [horizontal](https://en.wiktionary.org/wiki/horizontal#Spanish) | horizontal | /oɾiθonˈtal/ · adj |
| [hot](https://en.wiktionary.org/wiki/hot#Spanish) | hot; sexy | /ˈxot/ · adj |
| [medieval](https://en.wiktionary.org/wiki/medieval#Spanish) | medieval | /medjeˈbal/ · adj |
| [meme](https://en.wiktionary.org/wiki/meme#Spanish) | meme (unit of cultural information) | /ˈmeme/ · noun |
| [pasto](https://en.wiktionary.org/wiki/pasto#Spanish) | pasture | /ˈpasto/ · noun |
| [profeta](https://en.wiktionary.org/wiki/profeta#Spanish) | prophet | /pɾoˈfeta/ · noun |
| [viral](https://en.wiktionary.org/wiki/viral#Spanish) | viral (of or relating to a biologic virus) | /biˈɾal/ · adj |
| [boom](https://en.wiktionary.org/wiki/boom#Spanish) | a boom (sound) | /ˈbum/ · noun |
| [chaqueta](https://en.wiktionary.org/wiki/chaqueta#Spanish) | jacket, piece of clothing worn on the upper body outside a shirt or blouse, often waist length to thigh length | /t͡ʃaˈketa/ · noun |
| [cool](https://en.wiktionary.org/wiki/cool#Spanish) | cool (in its informal sense) | /ˈkul/ · adj |
| [hall](https://en.wiktionary.org/wiki/hall#Spanish) | hall, lobby, lounge | /ˈxol/ · noun |
| [pare](https://en.wiktionary.org/wiki/pare#Spanish) | stop, an act of stopping | /ˈpaɾe/ · noun |
| [spam](https://en.wiktionary.org/wiki/spam#Spanish) | spam | /ˈspam/ · noun |
| [superficial](https://en.wiktionary.org/wiki/superficial#Spanish) | superficial | /supeɾfiˈθjal/ · adj |
| [viola](https://en.wiktionary.org/wiki/viola#Spanish) | viola (musical instrument) | /ˈbjola/ · noun |
| [traducción](https://en.wiktionary.org/wiki/traducci%C3%B3n) | translation |  · noun |
| [conejo](https://en.wiktionary.org/wiki/conejo#Spanish) | rabbit, cony, coney (male or unspecified sex) | /koˈnexo/ · noun |
| [pluma](https://en.wiktionary.org/wiki/pluma#Spanish) | feather | /ˈpluma/ · noun |
| [viña](https://en.wiktionary.org/wiki/vi%C3%B1a#Spanish) | vineyard | /ˈbiɲa/ · noun |
| [araña](https://en.wiktionary.org/wiki/ara%C3%B1a#Spanish) | spider | /aˈɾaɲa/ · noun |

</details>

<details><summary>Words 801–850</summary>

![[Resources/Audio/es/Words 0801-0850.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [boliviano](https://en.wiktionary.org/wiki/boliviano#Spanish) | Bolivian | /boliˈbjano/ · adj |
| [chip](https://en.wiktionary.org/wiki/chip#Spanish) | chip (circuit) | /ˈt͡ʃip/ · noun |
| [hipocresía](https://en.wiktionary.org/wiki/hipocres%C3%ADa#Spanish) | hypocrisy | /ipokɾeˈsia/ · noun |
| [informal](https://en.wiktionary.org/wiki/informal#Spanish) | informal | /infoɾˈmal/ · adj |
| [irregular](https://en.wiktionary.org/wiki/irregular#Spanish) | irregular, uneven, erratic, haphazard | /ireɡuˈlaɾ/ · adj |
| [libra](https://en.wiktionary.org/wiki/libra#Spanish) | English or American pound avoirdupois (a unit of mass equivalent to 453.6 g) | /ˈlibɾa/ · noun |
| [party](https://en.wiktionary.org/wiki/party#Spanish) | party; celebration, festivity | /ˈpaɾti/ · noun |
| [rap](https://en.wiktionary.org/wiki/rap#Spanish) | rap (music genre) | /ˈrap/ · noun |
| [shock](https://en.wiktionary.org/wiki/shock#Spanish) | shock | /ˈʃok/ · noun |
| [calibre](https://en.wiktionary.org/wiki/calibre#Spanish) | calibre | /kaˈlibɾe/ · noun |
| [freno](https://en.wiktionary.org/wiki/freno#Spanish) | brake (device used to slow or stop the motion of a wheel or vehicle) | /ˈfɾeno/ · noun |
| [perfume](https://en.wiktionary.org/wiki/perfume#Spanish) | perfume | /peɾˈfume/ · noun |
| [plural](https://en.wiktionary.org/wiki/plural#Spanish) | plural, multiple | /pluˈɾal/ · adj |
| [soltar](https://en.wiktionary.org/wiki/soltar#Spanish) | to release | /solˈtaɾ/ · verb |
| [alias](https://en.wiktionary.org/wiki/alias#Spanish) | also known as; alias | /ˈaljas/ · adv |
| [chef](https://en.wiktionary.org/wiki/chef#Spanish) | chef, head cook | /ˈt͡ʃef/ · noun |
| [delta](https://en.wiktionary.org/wiki/delta#Spanish) | Greek letter delta | /ˈdelta/ · noun |
| [down](https://en.wiktionary.org/wiki/down#Spanish) | down, depressed | /ˈdaun/ · adj |
| [librería](https://en.wiktionary.org/wiki/librer%C3%ADa#Spanish) | bookshop, bookstore | /libɾeˈɾia/ · noun |
| [look](https://en.wiktionary.org/wiki/look#Spanish) | a look; style, appearance | /ˈluk/ · noun |
| [ratón](https://en.wiktionary.org/wiki/rat%C3%B3n#Spanish) | mouse (small rodent) | /raˈton/ · noun |
| [trans](https://en.wiktionary.org/wiki/trans#Spanish) | transgender, trans | /ˈtɾans/ · adj |
| [kilo](https://en.wiktionary.org/wiki/kilo#Spanish) | kilo (kilogram) | /ˈkilo/ · noun |
| [lava](https://en.wiktionary.org/wiki/lava#Spanish) | lava | /ˈlaba/ · noun |
| [light](https://en.wiktionary.org/wiki/light#Spanish) | light (low in fat, calories, salt, alcohol, etc.) | /ˈlait/ · adj |
| [pariente](https://en.wiktionary.org/wiki/pariente#Spanish) | relative, relation (member of one's family) | /paˈɾjente/ · noun |
| [pretender](https://en.wiktionary.org/wiki/pretender#Spanish) | to intend, to aim (for/to) | /pɾetenˈdeɾ/ · verb |
| [varón](https://en.wiktionary.org/wiki/var%C3%B3n#Spanish) | person of male sex | /baˈɾon/ · noun |
| [GPS](https://en.wiktionary.org/wiki/GPS#Spanish) | GPS, Global Positioning System | /ˌxe ˌpe ˈese/ · noun |
| [beta](https://en.wiktionary.org/wiki/beta#Spanish) | beta; the Greek letter Β, β | /ˈbeta/ · noun |
| [bruja](https://en.wiktionary.org/wiki/bruja#Spanish) | witch, sorceress (woman who practices witchcraft) | /ˈbɾuxa/ · noun |
| [burro](https://en.wiktionary.org/wiki/burro#Spanish) | donkey, especially one used as a pack animal | /ˈburo/ · noun |
| [chance](https://en.wiktionary.org/wiki/chance#Spanish) | chance | /ˈt͡ʃanθe/ · noun |
| [collar](https://en.wiktionary.org/wiki/collar#Spanish) | necklace | /koˈʝaɾ/ · noun |
| [crucial](https://en.wiktionary.org/wiki/crucial#Spanish) | crucial | /kɾuˈθjal/ · adj |
| [game](https://en.wiktionary.org/wiki/game#Spanish) | game |  · noun |
| [mango](https://en.wiktionary.org/wiki/mango#Spanish) | handle (part of an object which is held in the hand) | /ˈmanɡo/ · noun |
| [neutral](https://en.wiktionary.org/wiki/neutral#Spanish) | neutral | /neuˈtɾal/ · adj |
| [peculiar](https://en.wiktionary.org/wiki/peculiar#Spanish) | peculiar | /pekuˈljaɾ/ · adj |
| [pi](https://en.wiktionary.org/wiki/pi#Spanish) | pi; the Greek letter Π, π | /ˈpi/ · noun |
| [record](https://en.wiktionary.org/wiki/record#Spanish) | record |  · noun |
| [vendo](https://en.wiktionary.org/wiki/vendo#Spanish) | Wend (a member of a Slavic people from the borders of Germany and Poland) | /ˈbendo/ · noun |
| [cabra](https://en.wiktionary.org/wiki/cabra#Spanish) | female goat | /ˈkabɾa/ · noun |
| [cultivar](https://en.wiktionary.org/wiki/cultivar#Spanish) | to cultivate; to grow (plants, etc.) | /kultiˈbaɾ/ · verb |
| [email](https://en.wiktionary.org/wiki/email#Spanish) | email | /ˈimeil/ · noun |
| [menú](https://en.wiktionary.org/wiki/men%C3%BA#Spanish) | menu (list of foods to be served at a meal) | /meˈnu/ · noun |
| [mona](https://en.wiktionary.org/wiki/mona#Spanish) | copycat | /ˈmona/ · noun |
| [olla](https://en.wiktionary.org/wiki/olla#Spanish) | pot, pan; kettle (vessel used for cooking food) | /ˈoʝa/ · noun |
| [vocal](https://en.wiktionary.org/wiki/vocal#Spanish) | vowel | /boˈkal/ · noun |
| [RAM](https://en.wiktionary.org/wiki/RAM#Spanish) | RAM | /ˈram/ · noun |

</details>

<details><summary>Words 851–900</summary>

![[Resources/Audio/es/Words 0851-0900.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [aurora](https://en.wiktionary.org/wiki/aurora#Spanish) | aurora | /auˈɾoɾa/ · noun |
| [bancario](https://en.wiktionary.org/wiki/bancario#Spanish) | related to banks (financial institution) | /banˈkaɾjo/ · adj |
| [mariposa](https://en.wiktionary.org/wiki/mariposa#Spanish) | butterfly | /maɾiˈposa/ · noun |
| [non](https://en.wiktionary.org/wiki/non#Spanish) | odd (indivisible by two) | /ˈnon/ · adj |
| [pack](https://en.wiktionary.org/wiki/pack#Spanish) | pack, package | /ˈpak/ · noun |
| [verbal](https://en.wiktionary.org/wiki/verbal#Spanish) | verbal (of or relating to words) | /beɾˈbal/ · adj |
| [was](https://en.wiktionary.org/wiki/was#Spanish) | a message sent or received over WhatsApp |  · noun |
| [ajo](https://en.wiktionary.org/wiki/ajo#Spanish) | garlic | /ˈaxo/ · noun |
| [ano](https://en.wiktionary.org/wiki/ano#Spanish) | anus | /ˈano/ · noun |
| [atlas](https://en.wiktionary.org/wiki/atlas#Spanish) | atlas (a bound collection of maps often including tables, illustrations or other text) | /ˈatlas/ · noun |
| [elefante](https://en.wiktionary.org/wiki/elefante#Spanish) | elephant | /eleˈfante/ · noun |
| [hockey](https://en.wiktionary.org/wiki/hockey#Spanish) | hockey | /ˈoki/ · noun |
| [kit](https://en.wiktionary.org/wiki/kit#Spanish) | kit | /ˈkit/ · noun |
| [mu](https://en.wiktionary.org/wiki/mu#Spanish) | moo (sound of a cow) | /ˈmu/ · intj |
| [pal](https://en.wiktionary.org/wiki/pal#Spanish) | large pawl |  · noun |
| [polaco](https://en.wiktionary.org/wiki/polaco#Spanish) | Polish (from or native to Poland) | /poˈlako/ · adj |
| [timbre](https://en.wiktionary.org/wiki/timbre#Spanish) | bell | /ˈtimbɾe/ · noun |
| [cheque](https://en.wiktionary.org/wiki/cheque#Spanish) | cheque, blank cheque | /ˈt͡ʃeke/ · noun |
| [crack](https://en.wiktionary.org/wiki/crack#Spanish) | crack cocaine | /ˈkɾak/ · noun |
| [fray](https://en.wiktionary.org/wiki/fray#Spanish) | friar | /ˈfɾai/ · noun |
| [radar](https://en.wiktionary.org/wiki/radar#Spanish) | radar | /raˈdaɾ/ · noun |
| [stop](https://en.wiktionary.org/wiki/stop#Spanish) | stop | /esˈtop/ · intj |
| [abad](https://en.wiktionary.org/wiki/abad#Spanish) | abbot | /aˈbad/ · noun |
| [bay](https://en.wiktionary.org/wiki/bay#Spanish) | bye; so long | /ˈbai/ · intj |
| [bro](https://en.wiktionary.org/wiki/bro#Spanish) | bro (a male comrade or friend) | /ˈbɾo/ · noun |
| [canon](https://en.wiktionary.org/wiki/canon#Spanish) | canon (principle, literary works, prayer, religious law, music piece) | /ˈkanon/ · noun |
| [chi](https://en.wiktionary.org/wiki/chi#Spanish) | synonym of sí (yes) | /ˈt͡ʃi/ · particle |
| [diabetes](https://en.wiktionary.org/wiki/diabetes#Spanish) | diabetes | /djaˈbetes/ · noun |
| [hardware](https://en.wiktionary.org/wiki/hardware#Spanish) | hardware | /ˈxaɾdw̝eɾ/ · noun |
| [siesta](https://en.wiktionary.org/wiki/siesta#Spanish) | siesta (a nap, especially an afternoon one taken during the hottest part of the day in some cultures) | /ˈsjesta/ · noun |
| [uva](https://en.wiktionary.org/wiki/uva#Spanish) | grape | /ˈuba/ · noun |
| [vagina](https://en.wiktionary.org/wiki/vagina#Spanish) | vagina | /baˈxina/ · noun |
| [SMS](https://en.wiktionary.org/wiki/SMS#Spanish) | SMS | /ˌese ˌeme ˈese/ · noun |
| [enano](https://en.wiktionary.org/wiki/enano#Spanish) | dwarf | /eˈnano/ · adj |
| [grey](https://en.wiktionary.org/wiki/grey#Spanish) | flock (people served by a pastor, priest, etc., also all believers in a church or religion) | /ˈɡɾei/ · noun |
| [living](https://en.wiktionary.org/wiki/living#Spanish) | living room | /ˈlibin/ · noun |
| [monetario](https://en.wiktionary.org/wiki/monetario#Spanish) | currency; monetary | /moneˈtaɾjo/ · adj |
| [ordinario](https://en.wiktionary.org/wiki/ordinario#Spanish) | ordinary, standard | /oɾdiˈnaɾjo/ · adj |
| [punk](https://en.wiktionary.org/wiki/punk#Spanish) | punk (a member of the punk movement or fan of punk rock) | /ˈpunk/ · noun |
| [racial](https://en.wiktionary.org/wiki/racial#Spanish) | racial | /raˈθjal/ · adj |
| [res](https://en.wiktionary.org/wiki/res#Spanish) | head of quadrupedal livestock or game (e.g. cattle, sheep, deer) | /ˈres/ · noun |
| [stand](https://en.wiktionary.org/wiki/stand#Spanish) | stand (enclosed structure in the street) | /ˈstand/ · noun |
| [tumor](https://en.wiktionary.org/wiki/tumor#Spanish) | tumor | /tuˈmoɾ/ · noun |
| [usual](https://en.wiktionary.org/wiki/usual#Spanish) | usual | /uˈswal/ · adj |
| [acusar](https://en.wiktionary.org/wiki/acusar#Spanish) | to accuse, charge, indict | /akuˈsaɾ/ · verb |
| [aroma](https://en.wiktionary.org/wiki/aroma#Spanish) | aroma | /aˈɾoma/ · noun |
| [ea](https://en.wiktionary.org/wiki/ea#Spanish) | come on!, come now! (expressing encouragement) | /ˈea/ · intj |
| [pito](https://en.wiktionary.org/wiki/pito#Spanish) | whistle | /ˈpito/ · noun |
| [premier](https://en.wiktionary.org/wiki/premier#Spanish) | premier (head of government) | /pɾeˈmjeɾ/ · noun |
| [box](https://en.wiktionary.org/wiki/box#Spanish) | pit | /ˈboɡs/ · noun |

</details>

<details><summary>Words 901–950</summary>

![[Resources/Audio/es/Words 0901-0950.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [coral](https://en.wiktionary.org/wiki/coral#Spanish) | coral | /koˈɾal/ · noun |
| [coreano](https://en.wiktionary.org/wiki/coreano#Spanish) | Korean (relating to the Korean Peninsula) | /koɾeˈano/ · adj |
| [flexible](https://en.wiktionary.org/wiki/flexible#Spanish) | flexible | /fleɡˈsible/ · adj |
| [lunar](https://en.wiktionary.org/wiki/lunar#Spanish) | lunar | /luˈnaɾ/ · adj |
| [mates](https://en.wiktionary.org/wiki/mates#Spanish) | maths, math (study) | /ˈmates/ · noun |
| [paraguas](https://en.wiktionary.org/wiki/paraguas#Spanish) | umbrella, brolly (UK) | /paˈɾaɡwas/ · noun |
| [stock](https://en.wiktionary.org/wiki/stock#Spanish) | stock, inventory | /ˈstok/ · noun |
| [vara](https://en.wiktionary.org/wiki/vara#Spanish) | rod, pole (a long thin stick) | /ˈbaɾa/ · noun |
| [vulgar](https://en.wiktionary.org/wiki/vulgar#Spanish) | vulgar (all senses) | /bulˈɡaɾ/ · adj |
| [buscar pelos en la sopa](https://en.wiktionary.org/wiki/buscar%20pelos%20en%20la%20sopa#Spanish) | to look for excuses to complain | /busˌkaɾ ˌpelos en la ˈsopa/ · phrase |
| [jerez](https://en.wiktionary.org/wiki/jerez#Spanish) | sherry | /xeˈɾeθ/ · noun |
| [land](https://en.wiktionary.org/wiki/land#Spanish) | one of the federal states of Germany | /ˈland/ · noun |
| [mosca](https://en.wiktionary.org/wiki/mosca#Spanish) | fly (any insect of the order Diptera) | /ˈmoska/ · noun |
| [porta](https://en.wiktionary.org/wiki/porta#Spanish) | porthole | /ˈpoɾta/ · noun |
| [quite](https://en.wiktionary.org/wiki/quite#Spanish) | the action of removal | /ˈkite/ · noun |
| [single](https://en.wiktionary.org/wiki/single#Spanish) | single (song released) | /ˈsinɡle/ · noun |
| [suite](https://en.wiktionary.org/wiki/suite#Spanish) | suite (rooms, hotel) | /ˈswit/ · noun |
| [viable](https://en.wiktionary.org/wiki/viable#Spanish) | viable | /ˈbjable/ · adj |
| [abdomen](https://en.wiktionary.org/wiki/abdomen#Spanish) | abdomen | /abˈdomen/ · noun |
| [country](https://en.wiktionary.org/wiki/country#Spanish) | country music | /ˈkantɾi/ · noun |
| [filial](https://en.wiktionary.org/wiki/filial#Spanish) | filial | /fiˈljal/ · adj |
| [odiar](https://en.wiktionary.org/wiki/odiar#Spanish) | to hate, to loathe | /oˈdjaɾ/ · verb |
| [pica](https://en.wiktionary.org/wiki/pica#Spanish) | pike, lance | /ˈpika/ · noun |
| [right](https://en.wiktionary.org/wiki/right#Spanish) | right fielder | /ˈrait/ · noun |
| [virrey](https://en.wiktionary.org/wiki/virrey#Spanish) | viceroy | /biˈrei/ · noun |
| [anal](https://en.wiktionary.org/wiki/anal#Spanish) | anal | /aˈnal/ · adj |
| [cacao](https://en.wiktionary.org/wiki/cacao#Spanish) | cacao tree | /kaˈkao/ · noun |
| [office](https://en.wiktionary.org/wiki/office#Spanish) | a dining area in a kitchen | /ˈofis/ · noun |
| [page](https://en.wiktionary.org/wiki/page#Spanish) | page, pageboy |  · noun |
| [pisa](https://en.wiktionary.org/wiki/pisa#Spanish) | tread; step | /ˈpisa/ · noun |
| [sport](https://en.wiktionary.org/wiki/sport#Spanish) | casual |  · adj |
| [CEO](https://en.wiktionary.org/wiki/CEO#Spanish) | CEO; chief executive officer | /ˈθeo/ · noun |
| [de facto](https://en.wiktionary.org/wiki/de%20facto#Spanish) | de facto; in fact | /de ˈfaɡto/ · adv |
| [faro](https://en.wiktionary.org/wiki/faro#Spanish) | lighthouse | /ˈfaɾo/ · noun |
| [loma](https://en.wiktionary.org/wiki/loma#Spanish) | a long hill or mountain | /ˈloma/ · noun |
| [ny](https://en.wiktionary.org/wiki/ny#Spanish) | nu; the Greek letter Ν, ν | /ˈni/ · noun |
| [pampa](https://en.wiktionary.org/wiki/pampa#Spanish) | pampas (plains of South America south of the Amazon) | /ˈpampa/ · noun |
| [USB](https://en.wiktionary.org/wiki/USB#Spanish) | USB | /u ˌese ˈbe/ · noun |
| [amateur](https://en.wiktionary.org/wiki/amateur#Spanish) | amateurish, amateur | /amaˈteɾ/ · adj |
| [avatar](https://en.wiktionary.org/wiki/avatar#Spanish) | avatar | /abaˈtaɾ/ · noun |
| [barón](https://en.wiktionary.org/wiki/bar%C3%B3n#Spanish) | baron (male ruler of a barony) | /baˈɾon/ · noun |
| [heavy](https://en.wiktionary.org/wiki/heavy#Spanish) | heavy (pertaining to heavy metal) | /ˈxebi/ · adj |
| [húngaro](https://en.wiktionary.org/wiki/h%C3%BAngaro#Spanish) | Hungarian (from or native to Hungary) | /ˈunɡaɾo/ · adj |
| [pala](https://en.wiktionary.org/wiki/pala#Spanish) | shovel, spade | /ˈpala/ · noun |
| [rana](https://en.wiktionary.org/wiki/rana#Spanish) | frog | /ˈrana/ · noun |
| [calcio](https://en.wiktionary.org/wiki/calcio#Spanish) | calcium | /ˈkalθjo/ · noun |
| [mediocre](https://en.wiktionary.org/wiki/mediocre#Spanish) | mediocre | /meˈdjokɾe/ · adj |
| [nuca](https://en.wiktionary.org/wiki/nuca#Spanish) | nape (back of the neck) | /ˈnuka/ · noun |
| [panda](https://en.wiktionary.org/wiki/panda#Spanish) | gang, bunch | /ˈpanda/ · noun |
| [plasma](https://en.wiktionary.org/wiki/plasma#Spanish) | plasma | /ˈplasma/ · noun |

</details>

<details><summary>Words 951–1000</summary>

![[Resources/Audio/es/Words 0951-1000.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [whisky](https://en.wiktionary.org/wiki/whisky#Spanish) | whisky (alcoholic liquor) | /ˈw̝iski/ · noun |
| [capo](https://en.wiktionary.org/wiki/capo#Spanish) | gangster | /ˈkapo/ · noun |
| [no pasarán](https://en.wiktionary.org/wiki/no%20pasar%C3%A1n#Spanish) | they shall not pass (expressing determination to defend a position) | /ˌno pasaˈɾan/ · intj |
| [prime](https://en.wiktionary.org/wiki/prime#Spanish) | prime (the most active, thriving, or successful stage or period) | /ˈpɾaim/ · noun |
| [prosa](https://en.wiktionary.org/wiki/prosa#Spanish) | prose | /ˈpɾosa/ · noun |
| [rugby](https://en.wiktionary.org/wiki/rugby#Spanish) | rugby | /ˈraɡbi/ · noun |
| [sic](https://en.wiktionary.org/wiki/sic#Spanish) | sic (thus; as written) | /ˈsik/ · adv |
| [sorry](https://en.wiktionary.org/wiki/sorry#Spanish) | sorry (expressing regret) | /ˈsori/ · intj |
| [sueco](https://en.wiktionary.org/wiki/sueco#Spanish) | Swedish (from or native to Sweden) | /ˈsweko/ · adj |
| [variante](https://en.wiktionary.org/wiki/variante#Spanish) | varying | /baˈɾjante/ · adj |
| [colon](https://en.wiktionary.org/wiki/colon#Spanish) | colon (punctuation mark) | /ˈkolon/ · noun |
| [net](https://en.wiktionary.org/wiki/net#Spanish) | net (“mesh to divide courts”) | /ˈnet/ · noun |
| [sensual](https://en.wiktionary.org/wiki/sensual#Spanish) | sensual | /senˈswal/ · adj |
| [short](https://en.wiktionary.org/wiki/short#Spanish) | shorts | /ˈʃoɾt/ · noun |
| [WA](https://en.wiktionary.org/wiki/WA#Spanish) | a user account belonging to WhatsApp. | /ˈwa/ · noun |
| [brisa](https://en.wiktionary.org/wiki/brisa#Spanish) | breeze | /ˈbɾisa/ · noun |
| [chimenea](https://en.wiktionary.org/wiki/chimenea#Spanish) | chimney | /t͡ʃimeˈnea/ · noun |
| [eclipse](https://en.wiktionary.org/wiki/eclipse#Spanish) | eclipse | /eˈklibse/ · noun |
| [gata](https://en.wiktionary.org/wiki/gata#Spanish) | carjack, jack | /ˈɡata/ · noun |
| [profundizar](https://en.wiktionary.org/wiki/profundizar#Spanish) | to deepen | /pɾofundiˈθaɾ/ · verb |
| [reality](https://en.wiktionary.org/wiki/reality#Spanish) | reality show | /reˈaliti/ · noun |
| [remonta](https://en.wiktionary.org/wiki/remonta#Spanish) | a re-mount, a fresh horse to ride on | /reˈmonta/ · noun |
| [royal](https://en.wiktionary.org/wiki/royal#Spanish) | royal (member of the British royal family) | /roˈʝal/ · noun |
| [transversal](https://en.wiktionary.org/wiki/transversal#Spanish) | transversal | /tɾansbeɾˈsal/ · adj |
| [check](https://en.wiktionary.org/wiki/check#Spanish) | check (mark) | /ˈt͡ʃek/ · noun |
| [clip](https://en.wiktionary.org/wiki/clip#Spanish) | paper clip | /ˈklip/ · noun |
| [homo](https://en.wiktionary.org/wiki/homo#Spanish) | homo (homosexual) |  · adj |
| [recital](https://en.wiktionary.org/wiki/recital#Spanish) | recital | /reθiˈtal/ · noun |
| [tenor](https://en.wiktionary.org/wiki/tenor#Spanish) | tenor | /teˈnoɾ/ · noun |
| [corpus](https://en.wiktionary.org/wiki/corpus#Spanish) | corpus (a collection of writings) | /ˈkoɾpus/ · noun |
| [dental](https://en.wiktionary.org/wiki/dental#Spanish) | dental | /denˈtal/ · adj |
| [instrumental](https://en.wiktionary.org/wiki/instrumental#Spanish) | instrumental | /instɾumenˈtal/ · adj |
| [madame](https://en.wiktionary.org/wiki/madame#Spanish) | madam (polite term of address to a woman) |  · noun |
| [nova](https://en.wiktionary.org/wiki/nova#Spanish) | nova | /ˈnoba/ · noun |
| [porteño](https://en.wiktionary.org/wiki/porte%C3%B1o#Spanish) | native to or inhabiting a port town | /poɾˈteɲo/ · adj |
| [cordial](https://en.wiktionary.org/wiki/cordial#Spanish) | cordial | /koɾˈdjal/ · adj |
| [cuerno](https://en.wiktionary.org/wiki/cuerno#Spanish) | horn | /ˈkweɾno/ · noun |
| [improbable](https://en.wiktionary.org/wiki/improbable#Spanish) | improbable, unlikely | /impɾoˈbable/ · adj |
| [laurel](https://en.wiktionary.org/wiki/laurel#Spanish) | laurel | /lauˈɾel/ · noun |
| [led](https://en.wiktionary.org/wiki/led#Spanish) | LED (light-emitting diode) | /ˈled/ · noun |
| [oveja](https://en.wiktionary.org/wiki/oveja#Spanish) | sheep | /oˈbexa/ · noun |
| [ring](https://en.wiktionary.org/wiki/ring#Spanish) | ring | /ˈrin/ · noun |
| [rob](https://en.wiktionary.org/wiki/rob#Spanish) | fruit syrup | /ˈrob/ · noun |
| [tuberculosis](https://en.wiktionary.org/wiki/tuberculosis#Spanish) | tuberculosis | /tubeɾkuˈlosis/ · noun |
| [wiki](https://en.wiktionary.org/wiki/wiki#Spanish) | wiki | /ˈwiki/ · noun |
| [adaptar](https://en.wiktionary.org/wiki/adaptar#Spanish) | to adapt, to adjust, to tailor (to make suitable) | /adabˈtaɾ/ · verb |
| [admirable](https://en.wiktionary.org/wiki/admirable#Spanish) | admirable | /admiˈɾable/ · adj |
| [blues](https://en.wiktionary.org/wiki/blues#Spanish) | blues (a musical genre of African American origin) | /ˈblus/ · noun |
| [chupar](https://en.wiktionary.org/wiki/chupar#Spanish) | to suck | /t͡ʃuˈpaɾ/ · verb |
| [contable](https://en.wiktionary.org/wiki/contable#Spanish) | countable | /konˈtable/ · adj |

</details>

## Question bank

Try before opening the answers. Different tasks use the same sentence to practise complementary skills. Open translation and explanation tasks can have valid alternatives.

### Articles and gender · 50 questions

**es-Q0001 · Fill the gap**

No han igualado ____ carretera.

The road hasn't been leveled.

[[Spanish#^es-Q0001-answer|Compare the answer]]
^es-Q0001

**es-Q0002 · Choose the form**

No han igualado ____ carretera.

The road hasn't been leveled.

Choices: los / la / el / las

[[Spanish#^es-Q0002-answer|Compare the answer]]
^es-Q0002

**es-Q0003 · Edit the changed sentence**

Yo tengo 【el】 anillo.

I have a ring.

[[Spanish#^es-Q0003-answer|Compare the answer]]
^es-Q0003

**es-Q0004 · Build the sentence**

Arrange: tengo / un / anillo. / Yo

I have a ring.

[[Spanish#^es-Q0004-answer|Compare the answer]]
^es-Q0004

**es-Q0005 · Write a translation**

Write this in Spanish: There's a mouse in the pantry.

[[Spanish#^es-Q0005-answer|Compare the answer]]
^es-Q0005

**es-Q0006 · Explain the grammar**

Hay 【un】 ratón en la despensa.

There's a mouse in the pantry.

[[Spanish#^es-Q0006-answer|Compare the answer]]
^es-Q0006

**es-Q0007 · Fill the gap**

Ken juega fútbol todos ____ días.

Ken plays soccer every day.

[[Spanish#^es-Q0007-answer|Compare the answer]]
^es-Q0007

**es-Q0008 · Choose the form**

Ken juega fútbol todos ____ días.

Ken plays soccer every day.

Choices: las / los / la / el

[[Spanish#^es-Q0008-answer|Compare the answer]]
^es-Q0008

**es-Q0009 · Edit the changed sentence**

【el】 multitud esperaba verlo.

A crowd waited to see him.

[[Spanish#^es-Q0009-answer|Compare the answer]]
^es-Q0009

**es-Q0010 · Build the sentence**

Arrange: verlo. / multitud / Una / esperaba

A crowd waited to see him.

[[Spanish#^es-Q0010-answer|Compare the answer]]
^es-Q0010

**es-Q0011 · Write a translation**

Write this in Spanish: May I wash all my laundry at once?

[[Spanish#^es-Q0011-answer|Compare the answer]]
^es-Q0011

**es-Q0012 · Explain the grammar**

¿Puedo lavar toda mi ropa de 【una】 sola vez?

May I wash all my laundry at once?

[[Spanish#^es-Q0012-answer|Compare the answer]]
^es-Q0012

**es-Q0013 · Fill the gap**

Muchos peruanos tienen ____ hábito de mascar hojas de coca.

Many Peruvians have the habit of chewing coca leaves.

[[Spanish#^es-Q0013-answer|Compare the answer]]
^es-Q0013

**es-Q0014 · Choose the form**

Muchos peruanos tienen ____ hábito de mascar hojas de coca.

Many Peruvians have the habit of chewing coca leaves.

Choices: las / los / la / el

[[Spanish#^es-Q0014-answer|Compare the answer]]
^es-Q0014

**es-Q0015 · Edit the changed sentence**

【el】 capital del Estado está justo en el ecuador.

The capital of the state is right on the equator.

[[Spanish#^es-Q0015-answer|Compare the answer]]
^es-Q0015

**es-Q0016 · Build the sentence**

Arrange: Estado / del / capital / está / La / justo / el / ecuador. / en

The capital of the state is right on the equator.

[[Spanish#^es-Q0016-answer|Compare the answer]]
^es-Q0016

**es-Q0017 · Write a translation**

Write this in Spanish: You can't judge a person if you don't know him well.

[[Spanish#^es-Q0017-answer|Compare the answer]]
^es-Q0017

**es-Q0018 · Explain the grammar**

No puedes juzgar a 【una】 persona si no la conoces bien.

You can't judge a person if you don't know him well.

[[Spanish#^es-Q0018-answer|Compare the answer]]
^es-Q0018

**es-Q0019 · Fill the gap**

Tiene que haber habido ____ acuerdo tácito entre ellos.

There must've been a tacit understanding between them.

[[Spanish#^es-Q0019-answer|Compare the answer]]
^es-Q0019

**es-Q0020 · Choose the form**

Tiene que haber habido ____ acuerdo tácito entre ellos.

There must've been a tacit understanding between them.

Choices: un / el / la / los

[[Spanish#^es-Q0020-answer|Compare the answer]]
^es-Q0020

**es-Q0021 · Edit the changed sentence**

Hoy fue mi último día en 【el】 escuela.

Today was my last day of school.

[[Spanish#^es-Q0021-answer|Compare the answer]]
^es-Q0021

**es-Q0022 · Build the sentence**

Arrange: Hoy / día / escuela. / último / en / fue / mi / la

Today was my last day of school.

[[Spanish#^es-Q0022-answer|Compare the answer]]
^es-Q0022

**es-Q0023 · Write a translation**

Write this in Spanish: The alibi points to her innocence.

[[Spanish#^es-Q0023-answer|Compare the answer]]
^es-Q0023

**es-Q0024 · Explain the grammar**

【La】 coartada apunta su inocencia.

The alibi points to her innocence.

[[Spanish#^es-Q0024-answer|Compare the answer]]
^es-Q0024

**es-Q0025 · Fill the gap**

¡Presente ____ informe policial!

File a police report!

[[Spanish#^es-Q0025-answer|Compare the answer]]
^es-Q0025

**es-Q0026 · Choose the form**

¡Presente ____ informe policial!

File a police report!

Choices: un / la / el / los

[[Spanish#^es-Q0026-answer|Compare the answer]]
^es-Q0026

**es-Q0027 · Edit the changed sentence**

【el】 felicidad depende, no tanto de las circunstancias, sino de la forma de mirar la vida.

Happiness depends, not so much on circumstances, as on one's way of looking at one's life.

[[Spanish#^es-Q0027-answer|Compare the answer]]
^es-Q0027

**es-Q0028 · Build the sentence**

Arrange: de / la / vida. / circunstancias, / de / de / La / tanto / no / las / depende, / felicidad / forma / la / sino / mirar

Happiness depends, not so much on circumstances, as on one's way of looking at one's life.

[[Spanish#^es-Q0028-answer|Compare the answer]]
^es-Q0028

**es-Q0029 · Write a translation**

Write this in Spanish: Please do not walk on the grass.

[[Spanish#^es-Q0029-answer|Compare the answer]]
^es-Q0029

**es-Q0030 · Explain the grammar**

Por favor, no camines por 【el】 césped.

Please do not walk on the grass.

[[Spanish#^es-Q0030-answer|Compare the answer]]
^es-Q0030

**es-Q0031 · Fill the gap**

____ aeropuerto está cerca.

The airport is close at hand.

[[Spanish#^es-Q0031-answer|Compare the answer]]
^es-Q0031

**es-Q0032 · Choose the form**

____ aeropuerto está cerca.

The airport is close at hand.

Choices: las / los / El / la

[[Spanish#^es-Q0032-answer|Compare the answer]]
^es-Q0032

**es-Q0033 · Edit the changed sentence**

【la】 lunes fue tan ajetreado.

Monday was so hectic.

[[Spanish#^es-Q0033-answer|Compare the answer]]
^es-Q0033

**es-Q0034 · Build the sentence**

Arrange: tan / ajetreado. / lunes / El / fue

Monday was so hectic.

[[Spanish#^es-Q0034-answer|Compare the answer]]
^es-Q0034

**es-Q0035 · Write a translation**

Write this in Spanish: Do not put any objects on the console.

[[Spanish#^es-Q0035-answer|Compare the answer]]
^es-Q0035

**es-Q0036 · Explain the grammar**

No ponga ningún objeto sobre 【la】 consola.

Do not put any objects on the console.

[[Spanish#^es-Q0036-answer|Compare the answer]]
^es-Q0036

**es-Q0037 · Fill the gap**

Juega al tenis todos ____ días.

He plays tennis every day.

[[Spanish#^es-Q0037-answer|Compare the answer]]
^es-Q0037

**es-Q0038 · Choose the form**

Juega al tenis todos ____ días.

He plays tennis every day.

Choices: la / las / los / el

[[Spanish#^es-Q0038-answer|Compare the answer]]
^es-Q0038

**es-Q0039 · Edit the changed sentence**

Como se esperaba, 【el】 expresión del gen se redujo significativamente.

As expected, expression of the gene was significantly reduced.

[[Spanish#^es-Q0039-answer|Compare the answer]]
^es-Q0039

**es-Q0040 · Build the sentence**

Arrange: redujo / gen / Como / esperaba, / la / se / significativamente. / del / expresión / se

As expected, expression of the gene was significantly reduced.

[[Spanish#^es-Q0040-answer|Compare the answer]]
^es-Q0040

**es-Q0041 · Write a translation**

Write this in Spanish: Mental exercise is particularly important for young children.

[[Spanish#^es-Q0041-answer|Compare the answer]]
^es-Q0041

**es-Q0042 · Explain the grammar**

【El】 ejercicio mental es particularmente importante para los chiquillos.

Mental exercise is particularly important for young children.

[[Spanish#^es-Q0042-answer|Compare the answer]]
^es-Q0042

**es-Q0043 · Fill the gap**

Espera ____ poquito. Te voy a preparar un poco.

Wait a bit. I'll prepare some for you.

[[Spanish#^es-Q0043-answer|Compare the answer]]
^es-Q0043

**es-Q0044 · Choose the form**

Espera ____ poquito. Te voy a preparar un poco.

Wait a bit. I'll prepare some for you.

Choices: un / la / los / el

[[Spanish#^es-Q0044-answer|Compare the answer]]
^es-Q0044

**es-Q0045 · Edit the changed sentence**

【la】 dentista me arregló los dientes.

The dentist treated my teeth.

[[Spanish#^es-Q0045-answer|Compare the answer]]
^es-Q0045

**es-Q0046 · Build the sentence**

Arrange: El / dientes. / me / arregló / dentista / los

The dentist treated my teeth.

[[Spanish#^es-Q0046-answer|Compare the answer]]
^es-Q0046

**es-Q0047 · Write a translation**

Write this in Spanish: You're an amateur with the sword.

[[Spanish#^es-Q0047-answer|Compare the answer]]
^es-Q0047

**es-Q0048 · Explain the grammar**

Eres 【un】 aficionado con la espada.

You're an amateur with the sword.

[[Spanish#^es-Q0048-answer|Compare the answer]]
^es-Q0048

**es-Q0049 · Fill the gap**

A mi hijo no le gusta ____ dentista.

My child dislikes the dentist.

[[Spanish#^es-Q0049-answer|Compare the answer]]
^es-Q0049

**es-Q0050 · Choose the form**

A mi hijo no le gusta ____ dentista.

My child dislikes the dentist.

Choices: la / el / los / las

[[Spanish#^es-Q0050-answer|Compare the answer]]
^es-Q0050


### Adjective agreement · 50 questions

**es-Q0051 · Edit the changed sentence**

Ésta si que va a ser 【bueno】.

This is going to be swell.

[[Spanish#^es-Q0051-answer|Compare the answer]]
^es-Q0051

**es-Q0052 · Build the sentence**

Arrange: ser / si / que / va / Ésta / a / buena.

This is going to be swell.

[[Spanish#^es-Q0052-answer|Compare the answer]]
^es-Q0052

**es-Q0053 · Write a translation**

Write this in Spanish: I can't let you disembark without giving you a big kiss.

[[Spanish#^es-Q0053-answer|Compare the answer]]
^es-Q0053

**es-Q0054 · Explain the grammar**

No puedo dejarte desembarcar sin darte un beso 【grande】.

I can't let you disembark without giving you a big kiss.

[[Spanish#^es-Q0054-answer|Compare the answer]]
^es-Q0054

**es-Q0055 · Fill the gap**

Los abejorros son más ____ que las abejas.

Bumblebees are bigger than bees.

[[Spanish#^es-Q0055-answer|Compare the answer]]
^es-Q0055

**es-Q0056 · Choose the form**

Los abejorros son más ____ que las abejas.

Bumblebees are bigger than bees.

Choices: grandes / bueno / buena / buenos

[[Spanish#^es-Q0056-answer|Compare the answer]]
^es-Q0056

**es-Q0057 · Edit the changed sentence**

Esa pieza no es muy 【bueno】.

That room is not very large.

[[Spanish#^es-Q0057-answer|Compare the answer]]
^es-Q0057

**es-Q0058 · Build the sentence**

Arrange: grande. / no / muy / es / Esa / pieza

That room is not very large.

[[Spanish#^es-Q0058-answer|Compare the answer]]
^es-Q0058

**es-Q0059 · Write a translation**

Write this in Spanish: Nobody knows that I have bought a new car.

[[Spanish#^es-Q0059-answer|Compare the answer]]
^es-Q0059

**es-Q0060 · Explain the grammar**

Nadie sabe que he comprado un coche 【nuevo】.

Nobody knows that I have bought a new car.

[[Spanish#^es-Q0060-answer|Compare the answer]]
^es-Q0060

**es-Q0061 · Fill the gap**

Esperamos ansiosamente verlo de ____.

We anxiously wait to see it again.

[[Spanish#^es-Q0061-answer|Compare the answer]]
^es-Q0061

**es-Q0062 · Choose the form**

Esperamos ansiosamente verlo de ____.

We anxiously wait to see it again.

Choices: bueno / nuevo / buenos / buena

[[Spanish#^es-Q0062-answer|Compare the answer]]
^es-Q0062

**es-Q0063 · Edit the changed sentence**

Este traje es demasiado 【buena】 para mí.

This suit is too good for me.

[[Spanish#^es-Q0063-answer|Compare the answer]]
^es-Q0063

**es-Q0064 · Build the sentence**

Arrange: mí. / es / demasiado / para / Este / traje / bueno

This suit is too good for me.

[[Spanish#^es-Q0064-answer|Compare the answer]]
^es-Q0064

**es-Q0065 · Write a translation**

Write this in Spanish: Tom has a new car.

[[Spanish#^es-Q0065-answer|Compare the answer]]
^es-Q0065

**es-Q0066 · Explain the grammar**

Tom tiene un coche 【nuevo】.

Tom has a new car.

[[Spanish#^es-Q0066-answer|Compare the answer]]
^es-Q0066

**es-Q0067 · Fill the gap**

Los ____ artistas jamás ven las cosas tal como realmente son. Si lo hicieran, dejarían de ser artistas.

No great artist ever sees things as they really are. If he did, he would cease to be an artist.

[[Spanish#^es-Q0067-answer|Compare the answer]]
^es-Q0067

**es-Q0068 · Choose the form**

Los ____ artistas jamás ven las cosas tal como realmente son. Si lo hicieran, dejarían de ser artistas.

No great artist ever sees things as they really are. If he did, he would cease to be an artist.

Choices: buenos / grandes / buena / bueno

[[Spanish#^es-Q0068-answer|Compare the answer]]
^es-Q0068

**es-Q0069 · Edit the changed sentence**

Te voy a presentar a una 【bueno】 chica.

I'll introduce you to a nice girl.

[[Spanish#^es-Q0069-answer|Compare the answer]]
^es-Q0069

**es-Q0070 · Build the sentence**

Arrange: Te / una / presentar / voy / a / chica. / a / buena

I'll introduce you to a nice girl.

[[Spanish#^es-Q0070-answer|Compare the answer]]
^es-Q0070

**es-Q0071 · Write a translation**

Write this in Spanish: The new office is more spacious.

[[Spanish#^es-Q0071-answer|Compare the answer]]
^es-Q0071

**es-Q0072 · Explain the grammar**

La oficina 【nueva】 es más amplia.

The new office is more spacious.

[[Spanish#^es-Q0072-answer|Compare the answer]]
^es-Q0072

**es-Q0073 · Fill the gap**

Busqué por todos lados un departamento ____.

I've searched everywhere for a small apartment.

[[Spanish#^es-Q0073-answer|Compare the answer]]
^es-Q0073

**es-Q0074 · Choose the form**

Busqué por todos lados un departamento ____.

I've searched everywhere for a small apartment.

Choices: bueno / buenos / pequeño / buena

[[Spanish#^es-Q0074-answer|Compare the answer]]
^es-Q0074

**es-Q0075 · Edit the changed sentence**

Tom no cree que la pronunciación francesa de Mary sea muy 【bueno】.

Tom doesn't think Mary's French pronunciation is very good.

[[Spanish#^es-Q0075-answer|Compare the answer]]
^es-Q0075

**es-Q0076 · Build the sentence**

Arrange: Tom / pronunciación / sea / la / cree / francesa / muy / que / no / Mary / de / buena.

Tom doesn't think Mary's French pronunciation is very good.

[[Spanish#^es-Q0076-answer|Compare the answer]]
^es-Q0076

**es-Q0077 · Write a translation**

Write this in Spanish: I was just thinking of a new job.

[[Spanish#^es-Q0077-answer|Compare the answer]]
^es-Q0077

**es-Q0078 · Explain the grammar**

Estaba pensando en un 【nuevo】 trabajo.

I was just thinking of a new job.

[[Spanish#^es-Q0078-answer|Compare the answer]]
^es-Q0078

**es-Q0079 · Fill the gap**

Ese escritorio es demasiado ____ para Meg.

That desk is too small for Meg.

[[Spanish#^es-Q0079-answer|Compare the answer]]
^es-Q0079

**es-Q0080 · Choose the form**

Ese escritorio es demasiado ____ para Meg.

That desk is too small for Meg.

Choices: pequeño / buena / buenos / bueno

[[Spanish#^es-Q0080-answer|Compare the answer]]
^es-Q0080

**es-Q0081 · Edit the changed sentence**

【bueno】 días. ¿Cómo está usted?

Good morning. How are you?

[[Spanish#^es-Q0081-answer|Compare the answer]]
^es-Q0081

**es-Q0082 · Build the sentence**

Arrange: usted? / está / días. / Buenos / ¿Cómo

Good morning. How are you?

[[Spanish#^es-Q0082-answer|Compare the answer]]
^es-Q0082

**es-Q0083 · Write a translation**

Write this in Spanish: Won't it be too little?

[[Spanish#^es-Q0083-answer|Compare the answer]]
^es-Q0083

**es-Q0084 · Explain the grammar**

¿No lo será demasiado 【pequeño】?

Won't it be too little?

[[Spanish#^es-Q0084-answer|Compare the answer]]
^es-Q0084

**es-Q0085 · Fill the gap**

Anoche, alguien se metió a la ____ tienda cerca de mi casa.

Last night someone broke into the small shop near my house.

[[Spanish#^es-Q0085-answer|Compare the answer]]
^es-Q0085

**es-Q0086 · Choose the form**

Anoche, alguien se metió a la ____ tienda cerca de mi casa.

Last night someone broke into the small shop near my house.

Choices: buena / bueno / buenos / pequeña

[[Spanish#^es-Q0086-answer|Compare the answer]]
^es-Q0086

**es-Q0087 · Edit the changed sentence**

Elijas el que elijas, asegúrate de que es uno 【buena】.

Whichever you choose, make sure it is a good one.

[[Spanish#^es-Q0087-answer|Compare the answer]]
^es-Q0087

**es-Q0088 · Build the sentence**

Arrange: asegúrate / elijas, / de / es / que / Elijas / que / el / uno / bueno.

Whichever you choose, make sure it is a good one.

[[Spanish#^es-Q0088-answer|Compare the answer]]
^es-Q0088

**es-Q0089 · Write a translation**

Write this in Spanish: He found it very difficult to adjust himself to life in the new school.

[[Spanish#^es-Q0089-answer|Compare the answer]]
^es-Q0089

**es-Q0090 · Explain the grammar**

Él encontró muy difícil adaptarse a la vida en la 【nueva】 escuela.

He found it very difficult to adjust himself to life in the new school.

[[Spanish#^es-Q0090-answer|Compare the answer]]
^es-Q0090

**es-Q0091 · Fill the gap**

Probablemente eso no sea ____.

That's probably not good.

[[Spanish#^es-Q0091-answer|Compare the answer]]
^es-Q0091

**es-Q0092 · Choose the form**

Probablemente eso no sea ____.

That's probably not good.

Choices: bueno / buenas / buena / buenos

[[Spanish#^es-Q0092-answer|Compare the answer]]
^es-Q0092

**es-Q0093 · Edit the changed sentence**

Él era un hombre 【bueno】 y pesado.

He was a big, heavy man.

[[Spanish#^es-Q0093-answer|Compare the answer]]
^es-Q0093

**es-Q0094 · Build the sentence**

Arrange: hombre / grande / Él / era / y / un / pesado.

He was a big, heavy man.

[[Spanish#^es-Q0094-answer|Compare the answer]]
^es-Q0094

**es-Q0095 · Write a translation**

Write this in Spanish: It seemed too good to be true.

[[Spanish#^es-Q0095-answer|Compare the answer]]
^es-Q0095

**es-Q0096 · Explain the grammar**

Parecía demasiado 【bueno】 para ser verdad.

It seemed too good to be true.

[[Spanish#^es-Q0096-answer|Compare the answer]]
^es-Q0096

**es-Q0097 · Fill the gap**

El Gulasch está muy ____ en Budapest.

The goulash is very good in Budapest.

[[Spanish#^es-Q0097-answer|Compare the answer]]
^es-Q0097

**es-Q0098 · Choose the form**

El Gulasch está muy ____ en Budapest.

The goulash is very good in Budapest.

Choices: buenas / buena / bueno / buenos

[[Spanish#^es-Q0098-answer|Compare the answer]]
^es-Q0098

**es-Q0099 · Edit the changed sentence**

【bueno】 noches. Que sueñes con los angelitos.

Good night. Sweet dreams.

[[Spanish#^es-Q0099-answer|Compare the answer]]
^es-Q0099

**es-Q0100 · Build the sentence**

Arrange: Buenas / angelitos. / noches. / los / con / sueñes / Que

Good night. Sweet dreams.

[[Spanish#^es-Q0100-answer|Compare the answer]]
^es-Q0100


### Ser forms · 50 questions

**es-Q0101 · Write a translation**

Write this in Spanish: Is this your wallet?

[[Spanish#^es-Q0101-answer|Compare the answer]]
^es-Q0101

**es-Q0102 · Explain the grammar**

¿【Es】 ésta tu cartera?

Is this your wallet?

[[Spanish#^es-Q0102-answer|Compare the answer]]
^es-Q0102

**es-Q0103 · Fill the gap**

Ésas no ____ vuestras sillas.

Those are not your chairs.

[[Spanish#^es-Q0103-answer|Compare the answer]]
^es-Q0103

**es-Q0104 · Choose the form**

Ésas no ____ vuestras sillas.

Those are not your chairs.

Choices: es / son / eres / soy

[[Spanish#^es-Q0104-answer|Compare the answer]]
^es-Q0104

**es-Q0105 · Edit the changed sentence**

Uno 【soy】 juzgado por su forma de hablar en primera instancia.

One is judged by one's speech first of all.

[[Spanish#^es-Q0105-answer|Compare the answer]]
^es-Q0105

**es-Q0106 · Build the sentence**

Arrange: de / primera / su / en / forma / Uno / por / juzgado / es / instancia. / hablar

One is judged by one's speech first of all.

[[Spanish#^es-Q0106-answer|Compare the answer]]
^es-Q0106

**es-Q0107 · Write a translation**

Write this in Spanish: Apples are produced in this district.

[[Spanish#^es-Q0107-answer|Compare the answer]]
^es-Q0107

**es-Q0108 · Explain the grammar**

Las manzanas 【son】 producidas en este sector.

Apples are produced in this district.

[[Spanish#^es-Q0108-answer|Compare the answer]]
^es-Q0108

**es-Q0109 · Fill the gap**

El danés y el noruego ____ dos idiomas muy semejantes.

Danish and Norwegian are two very similar languages.

[[Spanish#^es-Q0109-answer|Compare the answer]]
^es-Q0109

**es-Q0110 · Choose the form**

El danés y el noruego ____ dos idiomas muy semejantes.

Danish and Norwegian are two very similar languages.

Choices: son / eres / es / soy

[[Spanish#^es-Q0110-answer|Compare the answer]]
^es-Q0110

**es-Q0111 · Edit the changed sentence**

Yo digo "yo 【eres】 John".

I say, “I’m John”.

[[Spanish#^es-Q0111-answer|Compare the answer]]
^es-Q0111

**es-Q0112 · Build the sentence**

Arrange: digo / John". / soy / "yo / Yo

I say, “I’m John”.

[[Spanish#^es-Q0112-answer|Compare the answer]]
^es-Q0112

**es-Q0113 · Write a translation**

Write this in Spanish: She is by far the best player in that country.

[[Spanish#^es-Q0113-answer|Compare the answer]]
^es-Q0113

**es-Q0114 · Explain the grammar**

Ella 【es】 de lejos la mejor jugadora en ese país.

She is by far the best player in that country.

[[Spanish#^es-Q0114-answer|Compare the answer]]
^es-Q0114

**es-Q0115 · Fill the gap**

Éstos ____ los míos.

These are mine.

[[Spanish#^es-Q0115-answer|Compare the answer]]
^es-Q0115

**es-Q0116 · Choose the form**

Éstos ____ los míos.

These are mine.

Choices: eres / es / soy / son

[[Spanish#^es-Q0116-answer|Compare the answer]]
^es-Q0116

**es-Q0117 · Edit the changed sentence**

¿Cuál 【soy】 tu lugar vacacional favorito de Japón?

What's your favorite place to vacation in Japan?

[[Spanish#^es-Q0117-answer|Compare the answer]]
^es-Q0117

**es-Q0118 · Build the sentence**

Arrange: favorito / ¿Cuál / lugar / Japón? / tu / vacacional / de / es

What's your favorite place to vacation in Japan?

[[Spanish#^es-Q0118-answer|Compare the answer]]
^es-Q0118

**es-Q0119 · Write a translation**

Write this in Spanish: Tom's French is almost perfect.

[[Spanish#^es-Q0119-answer|Compare the answer]]
^es-Q0119

**es-Q0120 · Explain the grammar**

El francés de Tom 【es】 casi perfecto.

Tom's French is almost perfect.

[[Spanish#^es-Q0120-answer|Compare the answer]]
^es-Q0120

**es-Q0121 · Fill the gap**

No ____ materialista.

I'm not materialistic.

[[Spanish#^es-Q0121-answer|Compare the answer]]
^es-Q0121

**es-Q0122 · Choose the form**

No ____ materialista.

I'm not materialistic.

Choices: somos / soy / eres / es

[[Spanish#^es-Q0122-answer|Compare the answer]]
^es-Q0122

**es-Q0123 · Edit the changed sentence**

Este 【soy】 un diccionario de versión reducida.

This dictionary is an abridged edition.

[[Spanish#^es-Q0123-answer|Compare the answer]]
^es-Q0123

**es-Q0124 · Build the sentence**

Arrange: es / Este / reducida. / un / versión / de / diccionario

This dictionary is an abridged edition.

[[Spanish#^es-Q0124-answer|Compare the answer]]
^es-Q0124

**es-Q0125 · Write a translation**

Write this in Spanish: I think it's unlikely that I'll be able to pass my driving test.

[[Spanish#^es-Q0125-answer|Compare the answer]]
^es-Q0125

**es-Q0126 · Explain the grammar**

Creo que 【es】 improbable que yo pase el test de conducir.

I think it's unlikely that I'll be able to pass my driving test.

[[Spanish#^es-Q0126-answer|Compare the answer]]
^es-Q0126

**es-Q0127 · Fill the gap**

«¿De quién ____ estos CD?» «Son de Samir.»

"Whose CD's are these?" "They are Samir's."

[[Spanish#^es-Q0127-answer|Compare the answer]]
^es-Q0127

**es-Q0128 · Choose the form**

«¿De quién ____ estos CD?» «Son de Samir.»

"Whose CD's are these?" "They are Samir's."

Choices: son / eres / soy / es

[[Spanish#^es-Q0128-answer|Compare the answer]]
^es-Q0128

**es-Q0129 · Edit the changed sentence**

¡Tú 【soy】 un adicto a las drogas como yo!

You're a drug addict like me!

[[Spanish#^es-Q0129-answer|Compare the answer]]
^es-Q0129

**es-Q0130 · Build the sentence**

Arrange: a / drogas / como / las / eres / ¡Tú / adicto / un / yo!

You're a drug addict like me!

[[Spanish#^es-Q0130-answer|Compare the answer]]
^es-Q0130

**es-Q0131 · Write a translation**

Write this in Spanish: You can't imagine how humiliating this is.

[[Spanish#^es-Q0131-answer|Compare the answer]]
^es-Q0131

**es-Q0132 · Explain the grammar**

No te puedes imaginar lo humillante que 【es】 esto.

You can't imagine how humiliating this is.

[[Spanish#^es-Q0132-answer|Compare the answer]]
^es-Q0132

**es-Q0133 · Fill the gap**

La ciudad ____ famosa por su viejo castillo.

The town is famous for its old castle.

[[Spanish#^es-Q0133-answer|Compare the answer]]
^es-Q0133

**es-Q0134 · Choose the form**

La ciudad ____ famosa por su viejo castillo.

The town is famous for its old castle.

Choices: somos / eres / soy / es

[[Spanish#^es-Q0134-answer|Compare the answer]]
^es-Q0134

**es-Q0135 · Edit the changed sentence**

Considero que los Testigos de Jehová que vienen constantemente a llamar a mi puerta no 【soy】 diferentes de los fanáticos religiosos que intentan convertirme.

I consider the Jehovah's witnesses who knock on my door all the time to be no different from religious zealots trying to force their beliefs on me.

[[Spanish#^es-Q0135-answer|Compare the answer]]
^es-Q0135

**es-Q0136 · Build the sentence**

Arrange: diferentes / intentan / fanáticos / de / de / no / religiosos / constantemente / llamar / Jehová / Considero / que / Testigos / vienen / mi / los / a / son / que / puerta / convertirme. / que / los / a

I consider the Jehovah's witnesses who knock on my door all the time to be no different from religious zealots trying to force their beliefs on me.

[[Spanish#^es-Q0136-answer|Compare the answer]]
^es-Q0136

**es-Q0137 · Write a translation**

Write this in Spanish: He's a bread junkie.

[[Spanish#^es-Q0137-answer|Compare the answer]]
^es-Q0137

**es-Q0138 · Explain the grammar**

Él 【es】 adicto al pan.

He's a bread junkie.

[[Spanish#^es-Q0138-answer|Compare the answer]]
^es-Q0138

**es-Q0139 · Fill the gap**

Esa estudiante ____ muy activa.

That student is very active.

[[Spanish#^es-Q0139-answer|Compare the answer]]
^es-Q0139

**es-Q0140 · Choose the form**

Esa estudiante ____ muy activa.

That student is very active.

Choices: soy / eres / somos / es

[[Spanish#^es-Q0140-answer|Compare the answer]]
^es-Q0140

**es-Q0141 · Edit the changed sentence**

No 【soy】 mi tipo.

This is not my type.

[[Spanish#^es-Q0141-answer|Compare the answer]]
^es-Q0141

**es-Q0142 · Build the sentence**

Arrange: No / tipo. / mi / es

This is not my type.

[[Spanish#^es-Q0142-answer|Compare the answer]]
^es-Q0142

**es-Q0143 · Write a translation**

Write this in Spanish: I'm allergic to corn.

[[Spanish#^es-Q0143-answer|Compare the answer]]
^es-Q0143

**es-Q0144 · Explain the grammar**

【Soy】 alérgico al maíz.

I'm allergic to corn.

[[Spanish#^es-Q0144-answer|Compare the answer]]
^es-Q0144

**es-Q0145 · Fill the gap**

¿Cuál ____ el propósito de la belleza?

What is the use of beauty?

[[Spanish#^es-Q0145-answer|Compare the answer]]
^es-Q0145

**es-Q0146 · Choose the form**

¿Cuál ____ el propósito de la belleza?

What is the use of beauty?

Choices: soy / somos / eres / es

[[Spanish#^es-Q0146-answer|Compare the answer]]
^es-Q0146

**es-Q0147 · Edit the changed sentence**

El trabajo 【soy】 muy divertido.

The job is a lot of fun.

[[Spanish#^es-Q0147-answer|Compare the answer]]
^es-Q0147

**es-Q0148 · Build the sentence**

Arrange: muy / divertido. / es / trabajo / El

The job is a lot of fun.

[[Spanish#^es-Q0148-answer|Compare the answer]]
^es-Q0148

**es-Q0149 · Write a translation**

Write this in Spanish: A language is a living system that evolves over time.

[[Spanish#^es-Q0149-answer|Compare the answer]]
^es-Q0149

**es-Q0150 · Explain the grammar**

Un idioma 【es】 un sistema vivo que evoluciona con el tiempo.

A language is a living system that evolves over time.

[[Spanish#^es-Q0150-answer|Compare the answer]]
^es-Q0150


### Estar forms · 50 questions

**es-Q0151 · Fill the gap**

Tomás también ____ nervioso.

Tom is nervous, too.

[[Spanish#^es-Q0151-answer|Compare the answer]]
^es-Q0151

**es-Q0152 · Choose the form**

Tomás también ____ nervioso.

Tom is nervous, too.

Choices: está / estoy / estás / estamos

[[Spanish#^es-Q0152-answer|Compare the answer]]
^es-Q0152

**es-Q0153 · Edit the changed sentence**

¿Qué 【estoy】 haciendo vosotros dos?

What are you two doing?

[[Spanish#^es-Q0153-answer|Compare the answer]]
^es-Q0153

**es-Q0154 · Build the sentence**

Arrange: ¿Qué / haciendo / dos? / vosotros / estáis

What are you two doing?

[[Spanish#^es-Q0154-answer|Compare the answer]]
^es-Q0154

**es-Q0155 · Write a translation**

Write this in Spanish: I see the house.

[[Spanish#^es-Q0155-answer|Compare the answer]]
^es-Q0155

**es-Q0156 · Explain the grammar**

【Estoy】 viendo la casa.

I see the house.

[[Spanish#^es-Q0156-answer|Compare the answer]]
^es-Q0156

**es-Q0157 · Fill the gap**

Tom ____ en su oficina.

Tom is in his office.

[[Spanish#^es-Q0157-answer|Compare the answer]]
^es-Q0157

**es-Q0158 · Choose the form**

Tom ____ en su oficina.

Tom is in his office.

Choices: estás / estamos / está / estoy

[[Spanish#^es-Q0158-answer|Compare the answer]]
^es-Q0158

**es-Q0159 · Edit the changed sentence**

Aquí 【estoy】 su menú.

Here is your menu.

[[Spanish#^es-Q0159-answer|Compare the answer]]
^es-Q0159

**es-Q0160 · Build the sentence**

Arrange: está / Aquí / su / menú.

Here is your menu.

[[Spanish#^es-Q0160-answer|Compare the answer]]
^es-Q0160

**es-Q0161 · Write a translation**

Write this in Spanish: I'm ready. And you?

[[Spanish#^es-Q0161-answer|Compare the answer]]
^es-Q0161

**es-Q0162 · Explain the grammar**

【Estoy】 lista, ¿y usted?

I'm ready. And you?

[[Spanish#^es-Q0162-answer|Compare the answer]]
^es-Q0162

**es-Q0163 · Fill the gap**

Jill ____ comprometida a Jack.

Jill is engaged to Jack.

[[Spanish#^es-Q0163-answer|Compare the answer]]
^es-Q0163

**es-Q0164 · Choose the form**

Jill ____ comprometida a Jack.

Jill is engaged to Jack.

Choices: está / estás / estoy / estamos

[[Spanish#^es-Q0164-answer|Compare the answer]]
^es-Q0164

**es-Q0165 · Edit the changed sentence**

No 【estás】 preocupado.

I'm not alarmed.

[[Spanish#^es-Q0165-answer|Compare the answer]]
^es-Q0165

**es-Q0166 · Build the sentence**

Arrange: preocupado. / estoy / No

I'm not alarmed.

[[Spanish#^es-Q0166-answer|Compare the answer]]
^es-Q0166

**es-Q0167 · Write a translation**

Write this in Spanish: They're at home now.

[[Spanish#^es-Q0167-answer|Compare the answer]]
^es-Q0167

**es-Q0168 · Explain the grammar**

Ellos 【están】 en casa ahora.

They're at home now.

[[Spanish#^es-Q0168-answer|Compare the answer]]
^es-Q0168

**es-Q0169 · Fill the gap**

____ cerrando todo.

He's closing everything.

[[Spanish#^es-Q0169-answer|Compare the answer]]
^es-Q0169

**es-Q0170 · Choose the form**

____ cerrando todo.

He's closing everything.

Choices: estamos / estoy / Está / estás

[[Spanish#^es-Q0170-answer|Compare the answer]]
^es-Q0170

**es-Q0171 · Edit the changed sentence**

Mary, ¿【estoy】 decente?

Mary, are you decent?

[[Spanish#^es-Q0171-answer|Compare the answer]]
^es-Q0171

**es-Q0172 · Build the sentence**

Arrange: ¿estás / decente? / Mary,

Mary, are you decent?

[[Spanish#^es-Q0172-answer|Compare the answer]]
^es-Q0172

**es-Q0173 · Write a translation**

Write this in Spanish: I am glad that you have succeeded.

[[Spanish#^es-Q0173-answer|Compare the answer]]
^es-Q0173

**es-Q0174 · Explain the grammar**

【Estoy】 feliz de que ganaste.

I am glad that you have succeeded.

[[Spanish#^es-Q0174-answer|Compare the answer]]
^es-Q0174

**es-Q0175 · Fill the gap**

Me temo que ____ avanzando en la dirección equivocada.

I am afraid we are advancing in the wrong direction.

[[Spanish#^es-Q0175-answer|Compare the answer]]
^es-Q0175

**es-Q0176 · Choose the form**

Me temo que ____ avanzando en la dirección equivocada.

I am afraid we are advancing in the wrong direction.

Choices: está / estamos / estás / estoy

[[Spanish#^es-Q0176-answer|Compare the answer]]
^es-Q0176

**es-Q0177 · Edit the changed sentence**

Me 【estoy】 dando un poco de hambre.

I'm getting a little hungry.

[[Spanish#^es-Q0177-answer|Compare the answer]]
^es-Q0177

**es-Q0178 · Build the sentence**

Arrange: de / hambre. / Me / un / poco / está / dando

I'm getting a little hungry.

[[Spanish#^es-Q0178-answer|Compare the answer]]
^es-Q0178

**es-Q0179 · Write a translation**

Write this in Spanish: The bank is closed on Sunday.

[[Spanish#^es-Q0179-answer|Compare the answer]]
^es-Q0179

**es-Q0180 · Explain the grammar**

El banco 【está】 cerrado los domingos.

The bank is closed on Sunday.

[[Spanish#^es-Q0180-answer|Compare the answer]]
^es-Q0180

**es-Q0181 · Fill the gap**

Las campanas de la iglesia ____ sonando.

The church bells are ringing.

[[Spanish#^es-Q0181-answer|Compare the answer]]
^es-Q0181

**es-Q0182 · Choose the form**

Las campanas de la iglesia ____ sonando.

The church bells are ringing.

Choices: está / están / estás / estoy

[[Spanish#^es-Q0182-answer|Compare the answer]]
^es-Q0182

**es-Q0183 · Edit the changed sentence**

Nuestro televisor 【estoy】 averiado.

Our TV is out of order.

[[Spanish#^es-Q0183-answer|Compare the answer]]
^es-Q0183

**es-Q0184 · Build the sentence**

Arrange: Nuestro / averiado. / está / televisor

Our TV is out of order.

[[Spanish#^es-Q0184-answer|Compare the answer]]
^es-Q0184

**es-Q0185 · Write a translation**

Write this in Spanish: She is 35 years old and in the prime of life.

[[Spanish#^es-Q0185-answer|Compare the answer]]
^es-Q0185

**es-Q0186 · Explain the grammar**

Tiene 35 años y 【está】 en lo mejor de la vida.

She is 35 years old and in the prime of life.

[[Spanish#^es-Q0186-answer|Compare the answer]]
^es-Q0186

**es-Q0187 · Fill the gap**

____ hasta las narices de tus lamentos.

We're fed up with your complaining.

[[Spanish#^es-Q0187-answer|Compare the answer]]
^es-Q0187

**es-Q0188 · Choose the form**

____ hasta las narices de tus lamentos.

We're fed up with your complaining.

Choices: Estamos / estoy / estás / está

[[Spanish#^es-Q0188-answer|Compare the answer]]
^es-Q0188

**es-Q0189 · Edit the changed sentence**

Tom 【estoy】 atarantado.

Tom is restless.

[[Spanish#^es-Q0189-answer|Compare the answer]]
^es-Q0189

**es-Q0190 · Build the sentence**

Arrange: está / atarantado. / Tom

Tom is restless.

[[Spanish#^es-Q0190-answer|Compare the answer]]
^es-Q0190

**es-Q0191 · Write a translation**

Write this in Spanish: Are you here to help us?

[[Spanish#^es-Q0191-answer|Compare the answer]]
^es-Q0191

**es-Q0192 · Explain the grammar**

¿【Está】 usted aquí para ayudarnos?

Are you here to help us?

[[Spanish#^es-Q0192-answer|Compare the answer]]
^es-Q0192

**es-Q0193 · Fill the gap**

La evidencia ____ puesta en frente de nosotros. Considerando eso, junto con el hecho de que él no tiene coartada, no cabe duda de que él es el culpable.

The evidence is laid out before us. Considering that, together with the fact that he has no alibi, there's no question that he's the guilty one.

[[Spanish#^es-Q0193-answer|Compare the answer]]
^es-Q0193

**es-Q0194 · Choose the form**

La evidencia ____ puesta en frente de nosotros. Considerando eso, junto con el hecho de que él no tiene coartada, no cabe duda de que él es el culpable.

The evidence is laid out before us. Considering that, together with the fact that he has no alibi, there's no question that he's the guilty one.

Choices: está / estamos / estoy / estás

[[Spanish#^es-Q0194-answer|Compare the answer]]
^es-Q0194

**es-Q0195 · Edit the changed sentence**

La economía mundial 【estoy】 ahora en recesión.

The world economy is in recession now.

[[Spanish#^es-Q0195-answer|Compare the answer]]
^es-Q0195

**es-Q0196 · Build the sentence**

Arrange: ahora / en / La / mundial / está / economía / recesión.

The world economy is in recession now.

[[Spanish#^es-Q0196-answer|Compare the answer]]
^es-Q0196

**es-Q0197 · Write a translation**

Write this in Spanish: Tom is calculating his salary.

[[Spanish#^es-Q0197-answer|Compare the answer]]
^es-Q0197

**es-Q0198 · Explain the grammar**

Tom 【está】 calculando su sueldo.

Tom is calculating his salary.

[[Spanish#^es-Q0198-answer|Compare the answer]]
^es-Q0198

**es-Q0199 · Fill the gap**

Él ____ parado en el escenario.

He is standing on the stage.

[[Spanish#^es-Q0199-answer|Compare the answer]]
^es-Q0199

**es-Q0200 · Choose the form**

Él ____ parado en el escenario.

He is standing on the stage.

Choices: estás / está / estoy / estamos

[[Spanish#^es-Q0200-answer|Compare the answer]]
^es-Q0200


### Existence with haber · 50 questions

**es-Q0201 · Edit the changed sentence**

Tom le dijo a Mary lo que 【hay】 pasado.

Tom told Mary what had happened.

[[Spanish#^es-Q0201-answer|Compare the answer]]
^es-Q0201

**es-Q0202 · Build the sentence**

Arrange: dijo / había / le / a / Tom / Mary / que / pasado. / lo

Tom told Mary what had happened.

[[Spanish#^es-Q0202-answer|Compare the answer]]
^es-Q0202

**es-Q0203 · Write a translation**

Write this in Spanish: There is no escape.

[[Spanish#^es-Q0203-answer|Compare the answer]]
^es-Q0203

**es-Q0204 · Explain the grammar**

No 【hay】 escapatoria.

There is no escape.

[[Spanish#^es-Q0204-answer|Compare the answer]]
^es-Q0204

**es-Q0205 · Fill the gap**

Tom se preguntó qué le ____ pasado a Mary.

Tom wondered what happened to Mary.

[[Spanish#^es-Q0205-answer|Compare the answer]]
^es-Q0205

**es-Q0206 · Choose the form**

Tom se preguntó qué le ____ pasado a Mary.

Tom wondered what happened to Mary.

Choices: había / habrá / hubo / hay

[[Spanish#^es-Q0206-answer|Compare the answer]]
^es-Q0206

**es-Q0207 · Edit the changed sentence**

【hay】 cincuenta concursantes para la carrera.

There were fifty entries for the race.

[[Spanish#^es-Q0207-answer|Compare the answer]]
^es-Q0207

**es-Q0208 · Build the sentence**

Arrange: carrera. / Había / concursantes / cincuenta / la / para

There were fifty entries for the race.

[[Spanish#^es-Q0208-answer|Compare the answer]]
^es-Q0208

**es-Q0209 · Write a translation**

Write this in Spanish: There were no more questions.

[[Spanish#^es-Q0209-answer|Compare the answer]]
^es-Q0209

**es-Q0210 · Explain the grammar**

No 【había】 más preguntas.

There were no more questions.

[[Spanish#^es-Q0210-answer|Compare the answer]]
^es-Q0210

**es-Q0211 · Fill the gap**

____ muchos terremotos en Japón.

There are many earthquakes in Japan.

[[Spanish#^es-Q0211-answer|Compare the answer]]
^es-Q0211

**es-Q0212 · Choose the form**

____ muchos terremotos en Japón.

There are many earthquakes in Japan.

Choices: había / Hay / habrá / hubo

[[Spanish#^es-Q0212-answer|Compare the answer]]
^es-Q0212

**es-Q0213 · Edit the changed sentence**

¿Cuántos pasajeros 【había】?

How many passengers are there?

[[Spanish#^es-Q0213-answer|Compare the answer]]
^es-Q0213

**es-Q0214 · Build the sentence**

Arrange: pasajeros / hay? / ¿Cuántos

How many passengers are there?

[[Spanish#^es-Q0214-answer|Compare the answer]]
^es-Q0214

**es-Q0215 · Write a translation**

Write this in Spanish: Are there still enough chairs for everyone?

[[Spanish#^es-Q0215-answer|Compare the answer]]
^es-Q0215

**es-Q0216 · Explain the grammar**

¿Todavía 【hay】 suficientes sillas para todos?

Are there still enough chairs for everyone?

[[Spanish#^es-Q0216-answer|Compare the answer]]
^es-Q0216

**es-Q0217 · Fill the gap**

Mientras que existe preocupación por el desarrollo de los niños, ____ incertidumbre sobre si darles mucho margen de libertad.

While there is concern about children's development, there is uncertainty about giving them a lot of lee-way.

[[Spanish#^es-Q0217-answer|Compare the answer]]
^es-Q0217

**es-Q0218 · Choose the form**

Mientras que existe preocupación por el desarrollo de los niños, ____ incertidumbre sobre si darles mucho margen de libertad.

While there is concern about children's development, there is uncertainty about giving them a lot of lee-way.

Choices: habrá / hay / hubo / había

[[Spanish#^es-Q0218-answer|Compare the answer]]
^es-Q0218

**es-Q0219 · Edit the changed sentence**

No 【había】 mucha lógica en lo que dices.

There isn't much logic in what you're saying.

[[Spanish#^es-Q0219-answer|Compare the answer]]
^es-Q0219

**es-Q0220 · Build the sentence**

Arrange: dices. / lógica / lo / en / que / mucha / No / hay

There isn't much logic in what you're saying.

[[Spanish#^es-Q0220-answer|Compare the answer]]
^es-Q0220

**es-Q0221 · Write a translation**

Write this in Spanish: Is there hot water?

[[Spanish#^es-Q0221-answer|Compare the answer]]
^es-Q0221

**es-Q0222 · Explain the grammar**

¿【Hay】 agua caliente?

Is there hot water?

[[Spanish#^es-Q0222-answer|Compare the answer]]
^es-Q0222

**es-Q0223 · Fill the gap**

____ una limusina esperando a Tom afuera del hotel.

There was a limousine waiting for Tom outside the hotel.

[[Spanish#^es-Q0223-answer|Compare the answer]]
^es-Q0223

**es-Q0224 · Choose the form**

____ una limusina esperando a Tom afuera del hotel.

There was a limousine waiting for Tom outside the hotel.

Choices: Había / hubo / habrá / hay

[[Spanish#^es-Q0224-answer|Compare the answer]]
^es-Q0224

**es-Q0225 · Edit the changed sentence**

【había】 frases que todo el mundo conoce.

There are sentences which everybody knows.

[[Spanish#^es-Q0225-answer|Compare the answer]]
^es-Q0225

**es-Q0226 · Build the sentence**

Arrange: todo / que / el / conoce. / mundo / Hay / frases

There are sentences which everybody knows.

[[Spanish#^es-Q0226-answer|Compare the answer]]
^es-Q0226

**es-Q0227 · Write a translation**

Write this in Spanish: I haven't been back here since the incident.

[[Spanish#^es-Q0227-answer|Compare the answer]]
^es-Q0227

**es-Q0228 · Explain the grammar**

Yo no 【había】 vuelto aquí desde el incidente.

I haven't been back here since the incident.

[[Spanish#^es-Q0228-answer|Compare the answer]]
^es-Q0228

**es-Q0229 · Fill the gap**

____ algo ahí.

There's something there.

[[Spanish#^es-Q0229-answer|Compare the answer]]
^es-Q0229

**es-Q0230 · Choose the form**

____ algo ahí.

There's something there.

Choices: habrá / Hay / hubo / había

[[Spanish#^es-Q0230-answer|Compare the answer]]
^es-Q0230

**es-Q0231 · Edit the changed sentence**

¿Cuántas preguntas 【hay】 en el test?

How many questions were there on the test?

[[Spanish#^es-Q0231-answer|Compare the answer]]
^es-Q0231

**es-Q0232 · Build the sentence**

Arrange: el / en / ¿Cuántas / había / test? / preguntas

How many questions were there on the test?

[[Spanish#^es-Q0232-answer|Compare the answer]]
^es-Q0232

**es-Q0233 · Write a translation**

Write this in Spanish: Never have I seen such a thing.

[[Spanish#^es-Q0233-answer|Compare the answer]]
^es-Q0233

**es-Q0234 · Explain the grammar**

Nunca 【había】 visto una cosa así.

Never have I seen such a thing.

[[Spanish#^es-Q0234-answer|Compare the answer]]
^es-Q0234

**es-Q0235 · Fill the gap**

Cuando los padres están lejos de sus hijos, no ____ nada que puedan hacer respecto a su seguridad o su bienestar.

When parents are far away from their children, there is nothing they can do about their safety or welfare.

[[Spanish#^es-Q0235-answer|Compare the answer]]
^es-Q0235

**es-Q0236 · Choose the form**

Cuando los padres están lejos de sus hijos, no ____ nada que puedan hacer respecto a su seguridad o su bienestar.

When parents are far away from their children, there is nothing they can do about their safety or welfare.

Choices: habrá / hubo / hay / había

[[Spanish#^es-Q0236-answer|Compare the answer]]
^es-Q0236

**es-Q0237 · Edit the changed sentence**

【había】 treinta personas aquí.

There are thirty people here.

[[Spanish#^es-Q0237-answer|Compare the answer]]
^es-Q0237

**es-Q0238 · Build the sentence**

Arrange: personas / treinta / aquí. / Hay

There are thirty people here.

[[Spanish#^es-Q0238-answer|Compare the answer]]
^es-Q0238

**es-Q0239 · Write a translation**

Write this in Spanish: What about me?

[[Spanish#^es-Q0239-answer|Compare the answer]]
^es-Q0239

**es-Q0240 · Explain the grammar**

¿Qué 【hay】 de mí?

What about me?

[[Spanish#^es-Q0240-answer|Compare the answer]]
^es-Q0240

**es-Q0241 · Fill the gap**

En este asunto ____ que caminar con pies de plomo.

You have to move cautiously in this matter.

[[Spanish#^es-Q0241-answer|Compare the answer]]
^es-Q0241

**es-Q0242 · Choose the form**

En este asunto ____ que caminar con pies de plomo.

You have to move cautiously in this matter.

Choices: hubo / habrá / hay / había

[[Spanish#^es-Q0242-answer|Compare the answer]]
^es-Q0242

**es-Q0243 · Edit the changed sentence**

Ahora bien, 【había】 que aclarar este problema.

Now then, let's get this problem cleared up.

[[Spanish#^es-Q0243-answer|Compare the answer]]
^es-Q0243

**es-Q0244 · Build the sentence**

Arrange: aclarar / hay / Ahora / este / bien, / que / problema.

Now then, let's get this problem cleared up.

[[Spanish#^es-Q0244-answer|Compare the answer]]
^es-Q0244

**es-Q0245 · Write a translation**

Write this in Spanish: In everything, one should consider the end.

[[Spanish#^es-Q0245-answer|Compare the answer]]
^es-Q0245

**es-Q0246 · Explain the grammar**

En toda cosa 【hay】 que considerar el fin.

In everything, one should consider the end.

[[Spanish#^es-Q0246-answer|Compare the answer]]
^es-Q0246

**es-Q0247 · Fill the gap**

¿____ algo extraño?

Is there anything strange?

[[Spanish#^es-Q0247-answer|Compare the answer]]
^es-Q0247

**es-Q0248 · Choose the form**

¿____ algo extraño?

Is there anything strange?

Choices: hubo / habrá / había / Hay

[[Spanish#^es-Q0248-answer|Compare the answer]]
^es-Q0248

**es-Q0249 · Edit the changed sentence**

¿Cuándo descubriste que tu hermana se 【hay】 muerto?

When did you find out that your sister had died?

[[Spanish#^es-Q0249-answer|Compare the answer]]
^es-Q0249

**es-Q0250 · Build the sentence**

Arrange: ¿Cuándo / descubriste / que / había / muerto? / tu / se / hermana

When did you find out that your sister had died?

[[Spanish#^es-Q0250-answer|Compare the answer]]
^es-Q0250


### Present possession · 50 questions

**es-Q0251 · Write a translation**

Write this in Spanish: He's got lots of sex appeal.

[[Spanish#^es-Q0251-answer|Compare the answer]]
^es-Q0251

**es-Q0252 · Explain the grammar**

Él 【tiene】 mucho pegue.

He's got lots of sex appeal.

[[Spanish#^es-Q0252-answer|Compare the answer]]
^es-Q0252

**es-Q0253 · Fill the gap**

No ____ ningún impacto sobre el ambiente.

They have no impact on the environment.

[[Spanish#^es-Q0253-answer|Compare the answer]]
^es-Q0253

**es-Q0254 · Choose the form**

No ____ ningún impacto sobre el ambiente.

They have no impact on the environment.

Choices: tiene / tengo / tienes / tienen

[[Spanish#^es-Q0254-answer|Compare the answer]]
^es-Q0254

**es-Q0255 · Edit the changed sentence**

¿Cuánto tiempo 【tienes】 que quedarme aquí?

How long do I have to stay here?

[[Spanish#^es-Q0255-answer|Compare the answer]]
^es-Q0255

**es-Q0256 · Build the sentence**

Arrange: tengo / quedarme / que / ¿Cuánto / tiempo / aquí?

How long do I have to stay here?

[[Spanish#^es-Q0256-answer|Compare the answer]]
^es-Q0256

**es-Q0257 · Write a translation**

Write this in Spanish: You have a telephone at your house.

[[Spanish#^es-Q0257-answer|Compare the answer]]
^es-Q0257

**es-Q0258 · Explain the grammar**

【Tienes】 un teléfono en tu casa.

You have a telephone at your house.

[[Spanish#^es-Q0258-answer|Compare the answer]]
^es-Q0258

**es-Q0259 · Fill the gap**

No ____ idea de su paradero.

We have no idea about his whereabouts.

[[Spanish#^es-Q0259-answer|Compare the answer]]
^es-Q0259

**es-Q0260 · Choose the form**

No ____ idea de su paradero.

We have no idea about his whereabouts.

Choices: tiene / tengo / tenemos / tienes

[[Spanish#^es-Q0260-answer|Compare the answer]]
^es-Q0260

**es-Q0261 · Edit the changed sentence**

【tienes】 que hacer un intento.

I have to try.

[[Spanish#^es-Q0261-answer|Compare the answer]]
^es-Q0261

**es-Q0262 · Build the sentence**

Arrange: un / Tengo / hacer / que / intento.

I have to try.

[[Spanish#^es-Q0262-answer|Compare the answer]]
^es-Q0262

**es-Q0263 · Write a translation**

Write this in Spanish: Computers learned to play chess many years ago, but they didn't always have the strength they have today.

[[Spanish#^es-Q0263-answer|Compare the answer]]
^es-Q0263

**es-Q0264 · Explain the grammar**

Las computadoras aprendieron a jugar al ajedrez hace muchos años, pero no siempre tuvieron la fuerza que 【tienen】 hoy.

Computers learned to play chess many years ago, but they didn't always have the strength they have today.

[[Spanish#^es-Q0264-answer|Compare the answer]]
^es-Q0264

**es-Q0265 · Fill the gap**

La sala ____ una capacidad de 200 asientos.

The room has a seating capacity of 200.

[[Spanish#^es-Q0265-answer|Compare the answer]]
^es-Q0265

**es-Q0266 · Choose the form**

La sala ____ una capacidad de 200 asientos.

The room has a seating capacity of 200.

Choices: tienes / tengo / tiene / tenemos

[[Spanish#^es-Q0266-answer|Compare the answer]]
^es-Q0266

**es-Q0267 · Edit the changed sentence**

Pedro no 【tengo】 ninguna hermana.

Pedro doesn't have a sister.

[[Spanish#^es-Q0267-answer|Compare the answer]]
^es-Q0267

**es-Q0268 · Build the sentence**

Arrange: hermana. / ninguna / no / tiene / Pedro

Pedro doesn't have a sister.

[[Spanish#^es-Q0268-answer|Compare the answer]]
^es-Q0268

**es-Q0269 · Write a translation**

Write this in Spanish: Young people have new ideas very often.

[[Spanish#^es-Q0269-answer|Compare the answer]]
^es-Q0269

**es-Q0270 · Explain the grammar**

La gente joven muy a menudo 【tiene】 las ideas novedosas.

Young people have new ideas very often.

[[Spanish#^es-Q0270-answer|Compare the answer]]
^es-Q0270

**es-Q0271 · Fill the gap**

¿No ____ miedo?

Aren't you afraid?

[[Spanish#^es-Q0271-answer|Compare the answer]]
^es-Q0271

**es-Q0272 · Choose the form**

¿No ____ miedo?

Aren't you afraid?

Choices: tienes / tengo / tenemos / tiene

[[Spanish#^es-Q0272-answer|Compare the answer]]
^es-Q0272

**es-Q0273 · Edit the changed sentence**

Aquí 【tengo】 la lista de hoteles de la capital y de la provincia.

Here's a list of hotels in the capital and province.

[[Spanish#^es-Q0273-answer|Compare the answer]]
^es-Q0273

**es-Q0274 · Build the sentence**

Arrange: provincia. / la / la / Aquí / de / capital / y / la / de / de / hoteles / tiene / lista

Here's a list of hotels in the capital and province.

[[Spanish#^es-Q0274-answer|Compare the answer]]
^es-Q0274

**es-Q0275 · Write a translation**

Write this in Spanish: Even if polluted water serves no other purpose, it can put out a fire.

[[Spanish#^es-Q0275-answer|Compare the answer]]
^es-Q0275

**es-Q0276 · Explain the grammar**

Incluso el agua contaminada que no 【tiene】 otro propósito, puede apagar un fuego.

Even if polluted water serves no other purpose, it can put out a fire.

[[Spanish#^es-Q0276-answer|Compare the answer]]
^es-Q0276

**es-Q0277 · Fill the gap**

¿____ algo más barato?

Do you have anything cheaper?

[[Spanish#^es-Q0277-answer|Compare the answer]]
^es-Q0277

**es-Q0278 · Choose the form**

¿____ algo más barato?

Do you have anything cheaper?

Choices: Tiene / tienes / tenemos / tengo

[[Spanish#^es-Q0278-answer|Compare the answer]]
^es-Q0278

**es-Q0279 · Edit the changed sentence**

¿Cuántas cobijas 【tengo】 la cama?

How many blankets are there on the bed?

[[Spanish#^es-Q0279-answer|Compare the answer]]
^es-Q0279

**es-Q0280 · Build the sentence**

Arrange: la / ¿Cuántas / cobijas / cama? / tiene

How many blankets are there on the bed?

[[Spanish#^es-Q0280-answer|Compare the answer]]
^es-Q0280

**es-Q0281 · Write a translation**

Write this in Spanish: Tom doesn't have to pay attention to what Mary says.

[[Spanish#^es-Q0281-answer|Compare the answer]]
^es-Q0281

**es-Q0282 · Explain the grammar**

Tom no le 【tiene】 que prestar atención a lo que Mary dice.

Tom doesn't have to pay attention to what Mary says.

[[Spanish#^es-Q0282-answer|Compare the answer]]
^es-Q0282

**es-Q0283 · Fill the gap**

____ talento para el dibujo.

He has a gift for drawing.

[[Spanish#^es-Q0283-answer|Compare the answer]]
^es-Q0283

**es-Q0284 · Choose the form**

____ talento para el dibujo.

He has a gift for drawing.

Choices: tenemos / tengo / tienes / Tiene

[[Spanish#^es-Q0284-answer|Compare the answer]]
^es-Q0284

**es-Q0285 · Edit the changed sentence**

【tengo】 un acuerdo.

We have an agreement.

[[Spanish#^es-Q0285-answer|Compare the answer]]
^es-Q0285

**es-Q0286 · Build the sentence**

Arrange: Tenemos / acuerdo. / un

We have an agreement.

[[Spanish#^es-Q0286-answer|Compare the answer]]
^es-Q0286

**es-Q0287 · Write a translation**

Write this in Spanish: You have to be patient.

[[Spanish#^es-Q0287-answer|Compare the answer]]
^es-Q0287

**es-Q0288 · Explain the grammar**

【Tienes】 que tener paciencia.

You have to be patient.

[[Spanish#^es-Q0288-answer|Compare the answer]]
^es-Q0288

**es-Q0289 · Fill the gap**

Tom ____ cosas más importantes de que preocuparse.

Tom has more important things to worry about.

[[Spanish#^es-Q0289-answer|Compare the answer]]
^es-Q0289

**es-Q0290 · Choose the form**

Tom ____ cosas más importantes de que preocuparse.

Tom has more important things to worry about.

Choices: tienes / tengo / tiene / tenemos

[[Spanish#^es-Q0290-answer|Compare the answer]]
^es-Q0290

**es-Q0291 · Edit the changed sentence**

¿【tengo】 hermanos o hermanas?

Do you have brothers and sisters?

[[Spanish#^es-Q0291-answer|Compare the answer]]
^es-Q0291

**es-Q0292 · Build the sentence**

Arrange: hermanos / o / hermanas? / ¿Tienes

Do you have brothers and sisters?

[[Spanish#^es-Q0292-answer|Compare the answer]]
^es-Q0292

**es-Q0293 · Write a translation**

Write this in Spanish: I have one question for you.

[[Spanish#^es-Q0293-answer|Compare the answer]]
^es-Q0293

**es-Q0294 · Explain the grammar**

【Tengo】 una pregunta para vosotras.

I have one question for you.

[[Spanish#^es-Q0294-answer|Compare the answer]]
^es-Q0294

**es-Q0295 · Fill the gap**

John ____ un auto de Japón.

John has a car from Japan.

[[Spanish#^es-Q0295-answer|Compare the answer]]
^es-Q0295

**es-Q0296 · Choose the form**

John ____ un auto de Japón.

John has a car from Japan.

Choices: tiene / tienes / tenemos / tengo

[[Spanish#^es-Q0296-answer|Compare the answer]]
^es-Q0296

**es-Q0297 · Edit the changed sentence**

【tengo】 cinco dedos en cada mano.

We have five fingers on each hand.

[[Spanish#^es-Q0297-answer|Compare the answer]]
^es-Q0297

**es-Q0298 · Build the sentence**

Arrange: dedos / mano. / en / cada / Tenemos / cinco

We have five fingers on each hand.

[[Spanish#^es-Q0298-answer|Compare the answer]]
^es-Q0298

**es-Q0299 · Write a translation**

Write this in Spanish: I have three times as much money as you.

[[Spanish#^es-Q0299-answer|Compare the answer]]
^es-Q0299

**es-Q0300 · Explain the grammar**

【Tengo】 el triple de dinero que tú.

I have three times as much money as you.

[[Spanish#^es-Q0300-answer|Compare the answer]]
^es-Q0300


### Past background · 50 questions

**es-Q0301 · Fill the gap**

Ella ____ profundamente emocionada.

She was deeply moved.

[[Spanish#^es-Q0301-answer|Compare the answer]]
^es-Q0301

**es-Q0302 · Choose the form**

Ella ____ profundamente emocionada.

She was deeply moved.

Choices: tenía / estaba / era / eran

[[Spanish#^es-Q0302-answer|Compare the answer]]
^es-Q0302

**es-Q0303 · Edit the changed sentence**

Los antiguos egipcios creían que el Sol 【eran】 el ojo del dios Ra.

The ancient Egyptians believed that the Sun was the eye of the god Ra.

[[Spanish#^es-Q0303-answer|Compare the answer]]
^es-Q0303

**es-Q0304 · Build the sentence**

Arrange: ojo / antiguos / que / Ra. / Sol / Los / egipcios / el / dios / del / creían / el / era

The ancient Egyptians believed that the Sun was the eye of the god Ra.

[[Spanish#^es-Q0304-answer|Compare the answer]]
^es-Q0304

**es-Q0305 · Write a translation**

Write this in Spanish: When my mother was young, she was very beautiful.

[[Spanish#^es-Q0305-answer|Compare the answer]]
^es-Q0305

**es-Q0306 · Explain the grammar**

Cuando mi madre 【era】 joven, era muy guapa.

When my mother was young, she was very beautiful.

[[Spanish#^es-Q0306-answer|Compare the answer]]
^es-Q0306

**es-Q0307 · Fill the gap**

Mi abuela ____ granjera.

My grandmother was a farmer.

[[Spanish#^es-Q0307-answer|Compare the answer]]
^es-Q0307

**es-Q0308 · Choose the form**

Mi abuela ____ granjera.

My grandmother was a farmer.

Choices: eran / estaba / era / tenía

[[Spanish#^es-Q0308-answer|Compare the answer]]
^es-Q0308

**es-Q0309 · Edit the changed sentence**

【era】 vivir solo, no en una casa de retiro.

I wanted to live alone, not in a retirement home.

[[Spanish#^es-Q0309-answer|Compare the answer]]
^es-Q0309

**es-Q0310 · Build the sentence**

Arrange: Quería / una / casa / no / en / de / retiro. / solo, / vivir

I wanted to live alone, not in a retirement home.

[[Spanish#^es-Q0310-answer|Compare the answer]]
^es-Q0310

**es-Q0311 · Write a translation**

Write this in Spanish: I really wanted to go to the party, but I couldn't.

[[Spanish#^es-Q0311-answer|Compare the answer]]
^es-Q0311

**es-Q0312 · Explain the grammar**

【Tenía】 muchas ganas de ir a la fiesta, pero no pude.

I really wanted to go to the party, but I couldn't.

[[Spanish#^es-Q0312-answer|Compare the answer]]
^es-Q0312

**es-Q0313 · Fill the gap**

La noche ____ fresca.

The night was cool.

[[Spanish#^es-Q0313-answer|Compare the answer]]
^es-Q0313

**es-Q0314 · Choose the form**

La noche ____ fresca.

The night was cool.

Choices: eran / estaba / era / tenía

[[Spanish#^es-Q0314-answer|Compare the answer]]
^es-Q0314

**es-Q0315 · Edit the changed sentence**

Mucha gente le 【era】 esperando.

A lot of people were waiting for him.

[[Spanish#^es-Q0315-answer|Compare the answer]]
^es-Q0315

**es-Q0316 · Build the sentence**

Arrange: esperando. / estaba / Mucha / le / gente

A lot of people were waiting for him.

[[Spanish#^es-Q0316-answer|Compare the answer]]
^es-Q0316

**es-Q0317 · Write a translation**

Write this in Spanish: It was very dark.

[[Spanish#^es-Q0317-answer|Compare the answer]]
^es-Q0317

**es-Q0318 · Explain the grammar**

【Estaba】 muy oscuro.

It was very dark.

[[Spanish#^es-Q0318-answer|Compare the answer]]
^es-Q0318

**es-Q0319 · Fill the gap**

Él ____ inglés.

He was English.

[[Spanish#^es-Q0319-answer|Compare the answer]]
^es-Q0319

**es-Q0320 · Choose the form**

Él ____ inglés.

He was English.

Choices: estaba / eran / era / tenía

[[Spanish#^es-Q0320-answer|Compare the answer]]
^es-Q0320

**es-Q0321 · Edit the changed sentence**

No 【era】 que las cosas acabaran así.

I didn't want things to end up like this.

[[Spanish#^es-Q0321-answer|Compare the answer]]
^es-Q0321

**es-Q0322 · Build the sentence**

Arrange: No / que / las / quería / acabaran / cosas / así.

I didn't want things to end up like this.

[[Spanish#^es-Q0322-answer|Compare the answer]]
^es-Q0322

**es-Q0323 · Write a translation**

Write this in Spanish: I attempted to get up, but my body was heavy as lead.

[[Spanish#^es-Q0323-answer|Compare the answer]]
^es-Q0323

**es-Q0324 · Explain the grammar**

Traté de levantarme, pero mi cuerpo 【estaba】 pesado como plomo.

I attempted to get up, but my body was heavy as lead.

[[Spanish#^es-Q0324-answer|Compare the answer]]
^es-Q0324

**es-Q0325 · Fill the gap**

Yo ____ hablando con Andrea cuando Valentina interrumpió.

I was talking to Andrea when Valentina broke in.

[[Spanish#^es-Q0325-answer|Compare the answer]]
^es-Q0325

**es-Q0326 · Choose the form**

Yo ____ hablando con Andrea cuando Valentina interrumpió.

I was talking to Andrea when Valentina broke in.

Choices: era / tenía / eran / estaba

[[Spanish#^es-Q0326-answer|Compare the answer]]
^es-Q0326

**es-Q0327 · Edit the changed sentence**

Ella no 【era】 ofender a nadie con su comentario.

She didn't mean to offend anyone with her remark.

[[Spanish#^es-Q0327-answer|Compare the answer]]
^es-Q0327

**es-Q0328 · Build the sentence**

Arrange: Ella / comentario. / a / nadie / con / ofender / su / quería / no

She didn't mean to offend anyone with her remark.

[[Spanish#^es-Q0328-answer|Compare the answer]]
^es-Q0328

**es-Q0329 · Write a translation**

Write this in Spanish: It was getting late.

[[Spanish#^es-Q0329-answer|Compare the answer]]
^es-Q0329

**es-Q0330 · Explain the grammar**

Se 【estaba】 haciendo tarde.

It was getting late.

[[Spanish#^es-Q0330-answer|Compare the answer]]
^es-Q0330

**es-Q0331 · Fill the gap**

Tom ____ expectativas demasiado altas.

Tom's expectations were too high.

[[Spanish#^es-Q0331-answer|Compare the answer]]
^es-Q0331

**es-Q0332 · Choose the form**

Tom ____ expectativas demasiado altas.

Tom's expectations were too high.

Choices: eran / era / estaba / tenía

[[Spanish#^es-Q0332-answer|Compare the answer]]
^es-Q0332

**es-Q0333 · Edit the changed sentence**

【era】 la esperanza de ahorrar más dinero.

I had hoped to save more money.

[[Spanish#^es-Q0333-answer|Compare the answer]]
^es-Q0333

**es-Q0334 · Build the sentence**

Arrange: de / esperanza / más / dinero. / la / Tenía / ahorrar

I had hoped to save more money.

[[Spanish#^es-Q0334-answer|Compare the answer]]
^es-Q0334

**es-Q0335 · Write a translation**

Write this in Spanish: I didn't know Guillermo and Tamara were brother and sister.

[[Spanish#^es-Q0335-answer|Compare the answer]]
^es-Q0335

**es-Q0336 · Explain the grammar**

No sabía que Guillermo y Tamara 【eran】 hermanos.

I didn't know Guillermo and Tamara were brother and sister.

[[Spanish#^es-Q0336-answer|Compare the answer]]
^es-Q0336

**es-Q0337 · Fill the gap**

¿Qué te crees que ____ haciendo?

What do you think I was doing?

[[Spanish#^es-Q0337-answer|Compare the answer]]
^es-Q0337

**es-Q0338 · Choose the form**

¿Qué te crees que ____ haciendo?

What do you think I was doing?

Choices: tenía / era / eran / estaba

[[Spanish#^es-Q0338-answer|Compare the answer]]
^es-Q0338

**es-Q0339 · Edit the changed sentence**

Él 【era】 dos hijos que se hicieron doctores.

He had two sons, who became doctors.

[[Spanish#^es-Q0339-answer|Compare the answer]]
^es-Q0339

**es-Q0340 · Build the sentence**

Arrange: que / hijos / dos / hicieron / doctores. / se / tenía / Él

He had two sons, who became doctors.

[[Spanish#^es-Q0340-answer|Compare the answer]]
^es-Q0340

**es-Q0341 · Write a translation**

Write this in Spanish: Tom didn't feel like talking.

[[Spanish#^es-Q0341-answer|Compare the answer]]
^es-Q0341

**es-Q0342 · Explain the grammar**

Tom no 【tenía】 ganas de hablar.

Tom didn't feel like talking.

[[Spanish#^es-Q0342-answer|Compare the answer]]
^es-Q0342

**es-Q0343 · Fill the gap**

Tom no ____ volver a casa.

Tom didn't want to return home.

[[Spanish#^es-Q0343-answer|Compare the answer]]
^es-Q0343

**es-Q0344 · Choose the form**

Tom no ____ volver a casa.

Tom didn't want to return home.

Choices: eran / quería / era / estaba

[[Spanish#^es-Q0344-answer|Compare the answer]]
^es-Q0344

**es-Q0345 · Edit the changed sentence**

Tom no 【era】 nada más que añadir.

Tom had nothing more to add.

[[Spanish#^es-Q0345-answer|Compare the answer]]
^es-Q0345

**es-Q0346 · Build the sentence**

Arrange: tenía / más / que / no / nada / añadir. / Tom

Tom had nothing more to add.

[[Spanish#^es-Q0346-answer|Compare the answer]]
^es-Q0346

**es-Q0347 · Write a translation**

Write this in Spanish: I was the happiest man on earth.

[[Spanish#^es-Q0347-answer|Compare the answer]]
^es-Q0347

**es-Q0348 · Explain the grammar**

Yo 【era】 la persona más feliz del mundo.

I was the happiest man on earth.

[[Spanish#^es-Q0348-answer|Compare the answer]]
^es-Q0348

**es-Q0349 · Fill the gap**

____ que Tom que viera primero.

I wanted Tom to see me first.

[[Spanish#^es-Q0349-answer|Compare the answer]]
^es-Q0349

**es-Q0350 · Choose the form**

____ que Tom que viera primero.

I wanted Tom to see me first.

Choices: eran / estaba / era / Quería

[[Spanish#^es-Q0350-answer|Compare the answer]]
^es-Q0350


### Bounded past forms · 50 questions

**es-Q0351 · Edit the changed sentence**

Él me 【fue】 todo pero no aceptó nada a cambio.

He gave me everything but took nothing in return.

[[Spanish#^es-Q0351-answer|Compare the answer]]
^es-Q0351

**es-Q0352 · Build the sentence**

Arrange: todo / dio / cambio. / nada / aceptó / a / no / pero / me / Él

He gave me everything but took nothing in return.

[[Spanish#^es-Q0352-answer|Compare the answer]]
^es-Q0352

**es-Q0353 · Write a translation**

Write this in Spanish: The first printing machine was invented by Gutenberg.

[[Spanish#^es-Q0353-answer|Compare the answer]]
^es-Q0353

**es-Q0354 · Explain the grammar**

La primera máquina imprenta 【fue】 inventada por Gutenberg.

The first printing machine was invented by Gutenberg.

[[Spanish#^es-Q0354-answer|Compare the answer]]
^es-Q0354

**es-Q0355 · Fill the gap**

Le picó una avispa y ____ una reacción alérgica.

A wasp stung him and he had an allergic reaction.

[[Spanish#^es-Q0355-answer|Compare the answer]]
^es-Q0355

**es-Q0356 · Choose the form**

Le picó una avispa y ____ una reacción alérgica.

A wasp stung him and he had an allergic reaction.

Choices: tuvo / hizo / dijo / fue

[[Spanish#^es-Q0356-answer|Compare the answer]]
^es-Q0356

**es-Q0357 · Edit the changed sentence**

Alguien 【fue】 algo, pero no pudimos entenderlo.

Someone said something, but we could not understand it.

[[Spanish#^es-Q0357-answer|Compare the answer]]
^es-Q0357

**es-Q0358 · Build the sentence**

Arrange: entenderlo. / pero / algo, / dijo / Alguien / pudimos / no

Someone said something, but we could not understand it.

[[Spanish#^es-Q0358-answer|Compare the answer]]
^es-Q0358

**es-Q0359 · Write a translation**

Write this in Spanish: He gave it to me for nothing.

[[Spanish#^es-Q0359-answer|Compare the answer]]
^es-Q0359

**es-Q0360 · Explain the grammar**

Él me la 【dio】 a cambio de nada.

He gave it to me for nothing.

[[Spanish#^es-Q0360-answer|Compare the answer]]
^es-Q0360

**es-Q0361 · Fill the gap**

Las mujeres ____ las que sufrieron más en la época de la Santa Inquisición.

Women were the ones who suffered the most during the Inquisition.

[[Spanish#^es-Q0361-answer|Compare the answer]]
^es-Q0361

**es-Q0362 · Choose the form**

Las mujeres ____ las que sufrieron más en la época de la Santa Inquisición.

Women were the ones who suffered the most during the Inquisition.

Choices: dijo / hizo / fueron / fue

[[Spanish#^es-Q0362-answer|Compare the answer]]
^es-Q0362

**es-Q0363 · Edit the changed sentence**

Tom se paró y 【hizo】 hacia la ventana.

Tom stood up and walked to the window.

[[Spanish#^es-Q0363-answer|Compare the answer]]
^es-Q0363

**es-Q0364 · Build the sentence**

Arrange: paró / y / se / hacia / ventana. / Tom / fue / la

Tom stood up and walked to the window.

[[Spanish#^es-Q0364-answer|Compare the answer]]
^es-Q0364

**es-Q0365 · Write a translation**

Write this in Spanish: The final match was not so exciting.

[[Spanish#^es-Q0365-answer|Compare the answer]]
^es-Q0365

**es-Q0366 · Explain the grammar**

El partido final no 【fue】 tan emocionante.

The final match was not so exciting.

[[Spanish#^es-Q0366-answer|Compare the answer]]
^es-Q0366

**es-Q0367 · Fill the gap**

Mi comentario ____ que el grupo empezara a discutir.

My comment sparked off an argument in the group.

[[Spanish#^es-Q0367-answer|Compare the answer]]
^es-Q0367

**es-Q0368 · Choose the form**

Mi comentario ____ que el grupo empezara a discutir.

My comment sparked off an argument in the group.

Choices: fue / dijo / vino / hizo

[[Spanish#^es-Q0368-answer|Compare the answer]]
^es-Q0368

**es-Q0369 · Edit the changed sentence**

Él 【fue】 a Japón hace dos años.

He came to Japan two years ago.

[[Spanish#^es-Q0369-answer|Compare the answer]]
^es-Q0369

**es-Q0370 · Build the sentence**

Arrange: hace / Japón / vino / años. / a / dos / Él

He came to Japan two years ago.

[[Spanish#^es-Q0370-answer|Compare the answer]]
^es-Q0370

**es-Q0371 · Write a translation**

Write this in Spanish: A Mr. Tanaka came to see you yesterday.

[[Spanish#^es-Q0371-answer|Compare the answer]]
^es-Q0371

**es-Q0372 · Explain the grammar**

Un tal señor Tanaka 【vino】 a verte ayer.

A Mr. Tanaka came to see you yesterday.

[[Spanish#^es-Q0372-answer|Compare the answer]]
^es-Q0372

**es-Q0373 · Fill the gap**

Él le ____ un consejo.

He gave her a piece of advice.

[[Spanish#^es-Q0373-answer|Compare the answer]]
^es-Q0373

**es-Q0374 · Choose the form**

Él le ____ un consejo.

He gave her a piece of advice.

Choices: dio / fue / dijo / hizo

[[Spanish#^es-Q0374-answer|Compare the answer]]
^es-Q0374

**es-Q0375 · Edit the changed sentence**

Él me lo 【fue】 a cambio de nada.

He gave it to me for nothing.

[[Spanish#^es-Q0375-answer|Compare the answer]]
^es-Q0375

**es-Q0376 · Build the sentence**

Arrange: dio / cambio / de / lo / nada. / Él / me / a

He gave it to me for nothing.

[[Spanish#^es-Q0376-answer|Compare the answer]]
^es-Q0376

**es-Q0377 · Write a translation**

Write this in Spanish: The women went to the celebration dressed to the nines.

[[Spanish#^es-Q0377-answer|Compare the answer]]
^es-Q0377

**es-Q0378 · Explain the grammar**

Las mujeres 【fueron】 a la fiesta muy encopetadas.

The women went to the celebration dressed to the nines.

[[Spanish#^es-Q0378-answer|Compare the answer]]
^es-Q0378

**es-Q0379 · Fill the gap**

Un amigo mío lo ____ con una máscara.

A friend of mine made it with a mask.

[[Spanish#^es-Q0379-answer|Compare the answer]]
^es-Q0379

**es-Q0380 · Choose the form**

Un amigo mío lo ____ con una máscara.

A friend of mine made it with a mask.

Choices: hizo / fue / dijo / vino

[[Spanish#^es-Q0380-answer|Compare the answer]]
^es-Q0380

**es-Q0381 · Edit the changed sentence**

Cristóbal Colón, como todo el mundo sabe, es reverenciado por la posteridad, porque él 【hizo】 el último en descubrir América.

Christopher Columbus, as everyone knows, is honored by posterity because he was the last to discover America.

[[Spanish#^es-Q0381-answer|Compare the answer]]
^es-Q0381

**es-Q0382 · Build the sentence**

Arrange: por / el / posteridad, / la / sabe, / en / Cristóbal / Colón, / América. / fue / mundo / todo / porque / descubrir / último / reverenciado / el / como / él / es

Christopher Columbus, as everyone knows, is honored by posterity because he was the last to discover America.

[[Spanish#^es-Q0382-answer|Compare the answer]]
^es-Q0382

**es-Q0383 · Write a translation**

Write this in Spanish: The capital was bombed again and again.

[[Spanish#^es-Q0383-answer|Compare the answer]]
^es-Q0383

**es-Q0384 · Explain the grammar**

La capital 【fue】 bombardeada una y otra vez.

The capital was bombed again and again.

[[Spanish#^es-Q0384-answer|Compare the answer]]
^es-Q0384

**es-Q0385 · Fill the gap**

Su última obra ____ un gran éxito.

His last play was a great success.

[[Spanish#^es-Q0385-answer|Compare the answer]]
^es-Q0385

**es-Q0386 · Choose the form**

Su última obra ____ un gran éxito.

His last play was a great success.

Choices: dijo / tuvo / fue / hizo

[[Spanish#^es-Q0386-answer|Compare the answer]]
^es-Q0386

**es-Q0387 · Edit the changed sentence**

Este es mi 【fue】.

This is my wine.

[[Spanish#^es-Q0387-answer|Compare the answer]]
^es-Q0387

**es-Q0388 · Build the sentence**

Arrange: mi / es / vino. / Este

This is my wine.

[[Spanish#^es-Q0388-answer|Compare the answer]]
^es-Q0388

**es-Q0389 · Write a translation**

Write this in Spanish: I saw a bear driving a van.

[[Spanish#^es-Q0389-answer|Compare the answer]]
^es-Q0389

**es-Q0390 · Explain the grammar**

【Vi】 a un oso manejando una van.

I saw a bear driving a van.

[[Spanish#^es-Q0390-answer|Compare the answer]]
^es-Q0390

**es-Q0391 · Fill the gap**

Tom ____ que la caja pesaba mucho para levantarla él solo.

Tom said that the box was too heavy to lift by himself.

[[Spanish#^es-Q0391-answer|Compare the answer]]
^es-Q0391

**es-Q0392 · Choose the form**

Tom ____ que la caja pesaba mucho para levantarla él solo.

Tom said that the box was too heavy to lift by himself.

Choices: fue / hizo / dijo / vino

[[Spanish#^es-Q0392-answer|Compare the answer]]
^es-Q0392

**es-Q0393 · Edit the changed sentence**

La vieja mezquita 【hizo】 abandonada y caye a pedazos.

The old mosque was derelict and rotting.

[[Spanish#^es-Q0393-answer|Compare the answer]]
^es-Q0393

**es-Q0394 · Build the sentence**

Arrange: mezquita / pedazos. / abandonada / a / vieja / fue / La / y / caye

The old mosque was derelict and rotting.

[[Spanish#^es-Q0394-answer|Compare the answer]]
^es-Q0394

**es-Q0395 · Write a translation**

Write this in Spanish: He did his best.

[[Spanish#^es-Q0395-answer|Compare the answer]]
^es-Q0395

**es-Q0396 · Explain the grammar**

Él 【dio】 lo mejor que pudo.

He did his best.

[[Spanish#^es-Q0396-answer|Compare the answer]]
^es-Q0396

**es-Q0397 · Fill the gap**

La experiencia le ____ una ventaja sobre los demás.

The experience gave him an advantage over the others.

[[Spanish#^es-Q0397-answer|Compare the answer]]
^es-Q0397

**es-Q0398 · Choose the form**

La experiencia le ____ una ventaja sobre los demás.

The experience gave him an advantage over the others.

Choices: dijo / fue / hizo / dio

[[Spanish#^es-Q0398-answer|Compare the answer]]
^es-Q0398

**es-Q0399 · Edit the changed sentence**

Su concierto 【hizo】 un gran éxito.

Their concert was a big hit.

[[Spanish#^es-Q0399-answer|Compare the answer]]
^es-Q0399

**es-Q0400 · Build the sentence**

Arrange: gran / Su / un / fue / concierto / éxito.

Their concert was a big hit.

[[Spanish#^es-Q0400-answer|Compare the answer]]
^es-Q0400


### Subjunctive forms · 50 questions

**es-Q0401 · Write a translation**

Write this in Spanish: "I want my dark elf to be blue." "OK... That one's purple. You'll be purple for this week."

[[Spanish#^es-Q0401-answer|Compare the answer]]
^es-Q0401

**es-Q0402 · Explain the grammar**

«Quiero que mi elfo oscuro 【sea】 azul.» «De acuerdo... Ése es morado. Serás morado esta semana.»

"I want my dark elf to be blue." "OK... That one's purple. You'll be purple for this week."

[[Spanish#^es-Q0402-answer|Compare the answer]]
^es-Q0402

**es-Q0403 · Fill the gap**

Recojan tantas monedas como ____ posible.

Collect as many coins as possible.

[[Spanish#^es-Q0403-answer|Compare the answer]]
^es-Q0403

**es-Q0404 · Choose the form**

Recojan tantas monedas como ____ posible.

Collect as many coins as possible.

Choices: haga / esté / tenga / sea

[[Spanish#^es-Q0404-answer|Compare the answer]]
^es-Q0404

**es-Q0405 · Edit the changed sentence**

No creo que esto 【esté】 gracioso.

I don't think this is funny.

[[Spanish#^es-Q0405-answer|Compare the answer]]
^es-Q0405

**es-Q0406 · Build the sentence**

Arrange: que / No / esto / sea / creo / gracioso.

I don't think this is funny.

[[Spanish#^es-Q0406-answer|Compare the answer]]
^es-Q0406

**es-Q0407 · Write a translation**

Write this in Spanish: Our company needs someone who is at home in advanced technology.

[[Spanish#^es-Q0407-answer|Compare the answer]]
^es-Q0407

**es-Q0408 · Explain the grammar**

Nuestra empresa necesita a alguien que 【esté】 adaptado a tecnología avanzada.

Our company needs someone who is at home in advanced technology.

[[Spanish#^es-Q0408-answer|Compare the answer]]
^es-Q0408

**es-Q0409 · Fill the gap**

No creo que ella ____ feliz.

I don't think she is happy.

[[Spanish#^es-Q0409-answer|Compare the answer]]
^es-Q0409

**es-Q0410 · Choose the form**

No creo que ella ____ feliz.

I don't think she is happy.

Choices: sea / tenga / esté / haga

[[Spanish#^es-Q0410-answer|Compare the answer]]
^es-Q0410

**es-Q0411 · Edit the changed sentence**

Quizá Tom 【sea】 problemas.

Maybe Tom has problems.

[[Spanish#^es-Q0411-answer|Compare the answer]]
^es-Q0411

**es-Q0412 · Build the sentence**

Arrange: Quizá / problemas. / Tom / tenga

Maybe Tom has problems.

[[Spanish#^es-Q0412-answer|Compare the answer]]
^es-Q0412

**es-Q0413 · Write a translation**

Write this in Spanish: Chew your food well so it can be digested properly.

[[Spanish#^es-Q0413-answer|Compare the answer]]
^es-Q0413

**es-Q0414 · Explain the grammar**

Mastica bien tu comida para que se 【pueda】 digerir bien.

Chew your food well so it can be digested properly.

[[Spanish#^es-Q0414-answer|Compare the answer]]
^es-Q0414

**es-Q0415 · Fill the gap**

Tal vez no ____ una mala idea después de todo.

Maybe it's not such a bad idea after all.

[[Spanish#^es-Q0415-answer|Compare the answer]]
^es-Q0415

**es-Q0416 · Choose the form**

Tal vez no ____ una mala idea después de todo.

Maybe it's not such a bad idea after all.

Choices: haga / sea / tenga / esté

[[Spanish#^es-Q0416-answer|Compare the answer]]
^es-Q0416

**es-Q0417 · Edit the changed sentence**

En Brasil, el pronombre "você" se utiliza de modo informal como "tú". En cambio, en Portugal se utiliza como forma de cortesía, o 【esté】, "usted".

In Brazil, the pronoun "você" is the casual way of saying "you", whilst in Portugal it's used in more formal contexts to denote courteousness.

[[Spanish#^es-Q0417-answer|Compare the answer]]
^es-Q0417

**es-Q0418 · Build the sentence**

Arrange: modo / utiliza / forma / sea, / se / de / informal / en / el / como / En / cortesía, / se / Portugal / En / como / "tú". / Brasil, / de / "usted". / cambio, / "você" / o / utiliza / pronombre

In Brazil, the pronoun "você" is the casual way of saying "you", whilst in Portugal it's used in more formal contexts to denote courteousness.

[[Spanish#^es-Q0418-answer|Compare the answer]]
^es-Q0418

**es-Q0419 · Write a translation**

Write this in Spanish: Anyone whose comfort level depends on what someone else is wearing really needs to take a long, hard look at themselves.

[[Spanish#^es-Q0419-answer|Compare the answer]]
^es-Q0419

**es-Q0420 · Explain the grammar**

Cualquier persona cuyo nivel de comodidad dependa de lo que los demás 【estén】 vistiendo realmente necesita echarse una larga y escrutadora mirada a sí mismo.

Anyone whose comfort level depends on what someone else is wearing really needs to take a long, hard look at themselves.

[[Spanish#^es-Q0420-answer|Compare the answer]]
^es-Q0420

**es-Q0421 · Fill the gap**

Haz lo que ____ necesario.

Do whatever it takes.

[[Spanish#^es-Q0421-answer|Compare the answer]]
^es-Q0421

**es-Q0422 · Choose the form**

Haz lo que ____ necesario.

Do whatever it takes.

Choices: tenga / esté / sea / haga

[[Spanish#^es-Q0422-answer|Compare the answer]]
^es-Q0422

**es-Q0423 · Edit the changed sentence**

Me pides que 【sea】 lo imposible.

You ask me to do the impossible.

[[Spanish#^es-Q0423-answer|Compare the answer]]
^es-Q0423

**es-Q0424 · Build the sentence**

Arrange: lo / pides / imposible. / haga / Me / que

You ask me to do the impossible.

[[Spanish#^es-Q0424-answer|Compare the answer]]
^es-Q0424

**es-Q0425 · Write a translation**

Write this in Spanish: We want everybody to have a good Christmas.

[[Spanish#^es-Q0425-answer|Compare the answer]]
^es-Q0425

**es-Q0426 · Explain the grammar**

Queremos que todo el mundo 【tenga】 una feliz Navidad.

We want everybody to have a good Christmas.

[[Spanish#^es-Q0426-answer|Compare the answer]]
^es-Q0426

**es-Q0427 · Fill the gap**

Dudo que Tom ____ feliz con su nuevo empleo.

I doubt that Tom is happy with his new job.

[[Spanish#^es-Q0427-answer|Compare the answer]]
^es-Q0427

**es-Q0428 · Choose the form**

Dudo que Tom ____ feliz con su nuevo empleo.

I doubt that Tom is happy with his new job.

Choices: tenga / sea / haga / esté

[[Spanish#^es-Q0428-answer|Compare the answer]]
^es-Q0428

**es-Q0429 · Edit the changed sentence**

No puedo creer que todo esto 【sea】 pasando.

I can't really believe all this is happening.

[[Spanish#^es-Q0429-answer|Compare the answer]]
^es-Q0429

**es-Q0430 · Build the sentence**

Arrange: todo / esté / puedo / esto / No / que / pasando. / creer

I can't really believe all this is happening.

[[Spanish#^es-Q0430-answer|Compare the answer]]
^es-Q0430

**es-Q0431 · Write a translation**

Write this in Spanish: Keep in mind what I tell you.

[[Spanish#^es-Q0431-answer|Compare the answer]]
^es-Q0431

**es-Q0432 · Explain the grammar**

【Tenga】 en cuenta lo que le digo.

Keep in mind what I tell you.

[[Spanish#^es-Q0432-answer|Compare the answer]]
^es-Q0432

**es-Q0433 · Fill the gap**

No creo que ella ____ de vuelta para las cinco.

I don't think she will come back by five.

[[Spanish#^es-Q0433-answer|Compare the answer]]
^es-Q0433

**es-Q0434 · Choose the form**

No creo que ella ____ de vuelta para las cinco.

I don't think she will come back by five.

Choices: haga / esté / tenga / sea

[[Spanish#^es-Q0434-answer|Compare the answer]]
^es-Q0434

**es-Q0435 · Edit the changed sentence**

¡No 【sea】 tan ligero!

Don't go so fast!

[[Spanish#^es-Q0435-answer|Compare the answer]]
^es-Q0435

**es-Q0436 · Build the sentence**

Arrange: vaya / tan / ligero! / ¡No

Don't go so fast!

[[Spanish#^es-Q0436-answer|Compare the answer]]
^es-Q0436

**es-Q0437 · Write a translation**

Write this in Spanish: The police can't question Tom until his lawyer gets here.

[[Spanish#^es-Q0437-answer|Compare the answer]]
^es-Q0437

**es-Q0438 · Explain the grammar**

La Policía no puede cuestionar a Tom hasta que su abogado 【esté】 aquí.

The police can't question Tom until his lawyer gets here.

[[Spanish#^es-Q0438-answer|Compare the answer]]
^es-Q0438

**es-Q0439 · Fill the gap**

Tengo que salvar como ____ al niño que se está ahogando.

I must save the drowning child by all means.

[[Spanish#^es-Q0439-answer|Compare the answer]]
^es-Q0439

**es-Q0440 · Choose the form**

Tengo que salvar como ____ al niño que se está ahogando.

I must save the drowning child by all means.

Choices: esté / sea / haga / tenga

[[Spanish#^es-Q0440-answer|Compare the answer]]
^es-Q0440

**es-Q0441 · Edit the changed sentence**

Para editar una frase, 【sea】 clic en el icono de lápiz.

To edit a sentence, click on the pencil icon.

[[Spanish#^es-Q0441-answer|Compare the answer]]
^es-Q0441

**es-Q0442 · Build the sentence**

Arrange: una / haga / editar / Para / de / clic / icono / frase, / lápiz. / en / el

To edit a sentence, click on the pencil icon.

[[Spanish#^es-Q0442-answer|Compare the answer]]
^es-Q0442

**es-Q0443 · Write a translation**

Write this in Spanish: Calm down. I'll come over as soon as possible.

[[Spanish#^es-Q0443-answer|Compare the answer]]
^es-Q0443

**es-Q0444 · Explain the grammar**

Tranquilízate. Iré tan pronto como 【sea】 posible.

Calm down. I'll come over as soon as possible.

[[Spanish#^es-Q0444-answer|Compare the answer]]
^es-Q0444

**es-Q0445 · Fill the gap**

Probablemente ____ un mal modo de empezar.

That's probably a bad way to start.

[[Spanish#^es-Q0445-answer|Compare the answer]]
^es-Q0445

**es-Q0446 · Choose the form**

Probablemente ____ un mal modo de empezar.

That's probably a bad way to start.

Choices: tenga / esté / haga / sea

[[Spanish#^es-Q0446-answer|Compare the answer]]
^es-Q0446

**es-Q0447 · Edit the changed sentence**

【sea】 el favor de llamarme un taxi.

Please call a taxi for me.

[[Spanish#^es-Q0447-answer|Compare the answer]]
^es-Q0447

**es-Q0448 · Build the sentence**

Arrange: Haga / el / un / de / taxi. / llamarme / favor

Please call a taxi for me.

[[Spanish#^es-Q0448-answer|Compare the answer]]
^es-Q0448

**es-Q0449 · Write a translation**

Write this in Spanish: Be careful. Don't throw away those papers.

[[Spanish#^es-Q0449-answer|Compare the answer]]
^es-Q0449

**es-Q0450 · Explain the grammar**

【Tenga】 cuidado, no bote esos papeles.

Be careful. Don't throw away those papers.

[[Spanish#^es-Q0450-answer|Compare the answer]]
^es-Q0450


### Conditional forms · 50 questions

**es-Q0451 · Fill the gap**

Por favor, ¿____ canjear estos cheques de viaje?

Would you cash these travelers checks, please?

[[Spanish#^es-Q0451-answer|Compare the answer]]
^es-Q0451

**es-Q0452 · Choose the form**

Por favor, ¿____ canjear estos cheques de viaje?

Would you cash these travelers checks, please?

Choices: haría / tendría / Podría / sería

[[Spanish#^es-Q0452-answer|Compare the answer]]
^es-Q0452

**es-Q0453 · Edit the changed sentence**

Si fuera invisible no 【sería】 que vestirme.

If I were invisible I wouldn't have to dress myself.

[[Spanish#^es-Q0453-answer|Compare the answer]]
^es-Q0453

**es-Q0454 · Build the sentence**

Arrange: fuera / tendría / que / vestirme. / Si / no / invisible

If I were invisible I wouldn't have to dress myself.

[[Spanish#^es-Q0454-answer|Compare the answer]]
^es-Q0454

**es-Q0455 · Write a translation**

Write this in Spanish: With your skills, I'm sure it wouldn't be too hard to find another job.

[[Spanish#^es-Q0455-answer|Compare the answer]]
^es-Q0455

**es-Q0456 · Explain the grammar**

Con tus habilidades, estoy seguro de que no te 【sería】 muy difícil encontrar otro trabajo.

With your skills, I'm sure it wouldn't be too hard to find another job.

[[Spanish#^es-Q0456-answer|Compare the answer]]
^es-Q0456

**es-Q0457 · Fill the gap**

¿Cuántos años ____ tener su abuelo?

How old might his grandfather be?

[[Spanish#^es-Q0457-answer|Compare the answer]]
^es-Q0457

**es-Q0458 · Choose the form**

¿Cuántos años ____ tener su abuelo?

How old might his grandfather be?

Choices: haría / podría / tendría / sería

[[Spanish#^es-Q0458-answer|Compare the answer]]
^es-Q0458

**es-Q0459 · Edit the changed sentence**

Nada más no entiendo por qué la gente 【sería】 vivir aquí.

I just don't understand why people would want to live here.

[[Spanish#^es-Q0459-answer|Compare the answer]]
^es-Q0459

**es-Q0460 · Build the sentence**

Arrange: aquí. / por / querría / no / Nada / qué / vivir / gente / la / más / entiendo

I just don't understand why people would want to live here.

[[Spanish#^es-Q0460-answer|Compare the answer]]
^es-Q0460

**es-Q0461 · Write a translation**

Write this in Spanish: I'd like some cheese.

[[Spanish#^es-Q0461-answer|Compare the answer]]
^es-Q0461

**es-Q0462 · Explain the grammar**

【Querría】 un poco de queso.

I'd like some cheese.

[[Spanish#^es-Q0462-answer|Compare the answer]]
^es-Q0462

**es-Q0463 · Fill the gap**

Nos ____ escalar esa montaña.

We'd like to climb that mountain.

[[Spanish#^es-Q0463-answer|Compare the answer]]
^es-Q0463

**es-Q0464 · Choose the form**

Nos ____ escalar esa montaña.

We'd like to climb that mountain.

Choices: tendría / sería / podría / gustaría

[[Spanish#^es-Q0464-answer|Compare the answer]]
^es-Q0464

**es-Q0465 · Edit the changed sentence**

Tom 【sería】 ir contigo.

Tom might go with you.

[[Spanish#^es-Q0465-answer|Compare the answer]]
^es-Q0465

**es-Q0466 · Build the sentence**

Arrange: Tom / ir / podría / contigo.

Tom might go with you.

[[Spanish#^es-Q0466-answer|Compare the answer]]
^es-Q0466

**es-Q0467 · Write a translation**

Write this in Spanish: Will you please wait on me, miss?

[[Spanish#^es-Q0467-answer|Compare the answer]]
^es-Q0467

**es-Q0468 · Explain the grammar**

Señorita, ¿【podría】 atenderme?

Will you please wait on me, miss?

[[Spanish#^es-Q0468-answer|Compare the answer]]
^es-Q0468

**es-Q0469 · Fill the gap**

Yo nunca les ____ eso.

I'd never do that to them.

[[Spanish#^es-Q0469-answer|Compare the answer]]
^es-Q0469

**es-Q0470 · Choose the form**

Yo nunca les ____ eso.

I'd never do that to them.

Choices: podría / haría / sería / tendría

[[Spanish#^es-Q0470-answer|Compare the answer]]
^es-Q0470

**es-Q0471 · Edit the changed sentence**

【tendría】 mejor que no comieses demasiado.

You'd better not eat too much.

[[Spanish#^es-Q0471-answer|Compare the answer]]
^es-Q0471

**es-Q0472 · Build the sentence**

Arrange: que / no / mejor / demasiado. / comieses / Sería

You'd better not eat too much.

[[Spanish#^es-Q0472-answer|Compare the answer]]
^es-Q0472

**es-Q0473 · Write a translation**

Write this in Spanish: She might come.

[[Spanish#^es-Q0473-answer|Compare the answer]]
^es-Q0473

**es-Q0474 · Explain the grammar**

Ella 【podría】 venir.

She might come.

[[Spanish#^es-Q0474-answer|Compare the answer]]
^es-Q0474

**es-Q0475 · Fill the gap**

Me ____ hacerte una pregunta.

I would like to ask you a question.

[[Spanish#^es-Q0475-answer|Compare the answer]]
^es-Q0475

**es-Q0476 · Choose the form**

Me ____ hacerte una pregunta.

I would like to ask you a question.

Choices: sería / tendría / gustaría / podría

[[Spanish#^es-Q0476-answer|Compare the answer]]
^es-Q0476

**es-Q0477 · Edit the changed sentence**

【sería】 un poco de té caliente, por favor.

I'd like some hot tea, please.

[[Spanish#^es-Q0477-answer|Compare the answer]]
^es-Q0477

**es-Q0478 · Build the sentence**

Arrange: de / un / caliente, / poco / té / por / favor. / Querría

I'd like some hot tea, please.

[[Spanish#^es-Q0478-answer|Compare the answer]]
^es-Q0478

**es-Q0479 · Write a translation**

Write this in Spanish: For when a woman is left too much alone, sooner or later she begins to think;- And no man knows what then she may discover.

[[Spanish#^es-Q0479-answer|Compare the answer]]
^es-Q0479

**es-Q0480 · Explain the grammar**

Cuando a una mujer se la deja sola mucho tiempo, tarde o temprano, ésta empieza a pensar; y ningún hombre sabe lo que ella 【podría】 descubrir.

For when a woman is left too much alone, sooner or later she begins to think;- And no man knows what then she may discover.

[[Spanish#^es-Q0480-answer|Compare the answer]]
^es-Q0480

**es-Q0481 · Fill the gap**

Si me hubieras dicho la verdad, yo no ____ enojada ahora.

If you had told me the truth, I would not be angry now.

[[Spanish#^es-Q0481-answer|Compare the answer]]
^es-Q0481

**es-Q0482 · Choose the form**

Si me hubieras dicho la verdad, yo no ____ enojada ahora.

If you had told me the truth, I would not be angry now.

Choices: tendría / sería / podría / estaría

[[Spanish#^es-Q0482-answer|Compare the answer]]
^es-Q0482

**es-Q0483 · Edit the changed sentence**

Alguien quizás 【sería】 resultar herido.

Someone might get hurt.

[[Spanish#^es-Q0483-answer|Compare the answer]]
^es-Q0483

**es-Q0484 · Build the sentence**

Arrange: herido. / quizás / Alguien / podría / resultar

Someone might get hurt.

[[Spanish#^es-Q0484-answer|Compare the answer]]
^es-Q0484

**es-Q0485 · Write a translation**

Write this in Spanish: That would be outstanding.

[[Spanish#^es-Q0485-answer|Compare the answer]]
^es-Q0485

**es-Q0486 · Explain the grammar**

Eso 【sería】 excelente.

That would be outstanding.

[[Spanish#^es-Q0486-answer|Compare the answer]]
^es-Q0486

**es-Q0487 · Fill the gap**

Me ____ ir a verte.

I would like to come and see you.

[[Spanish#^es-Q0487-answer|Compare the answer]]
^es-Q0487

**es-Q0488 · Choose the form**

Me ____ ir a verte.

I would like to come and see you.

Choices: podría / gustaría / sería / tendría

[[Spanish#^es-Q0488-answer|Compare the answer]]
^es-Q0488

**es-Q0489 · Edit the changed sentence**

Me 【sería】 saber cuando podrás enviarlo.

I'd like to know when you can send it out.

[[Spanish#^es-Q0489-answer|Compare the answer]]
^es-Q0489

**es-Q0490 · Build the sentence**

Arrange: enviarlo. / gustaría / cuando / saber / podrás / Me

I'd like to know when you can send it out.

[[Spanish#^es-Q0490-answer|Compare the answer]]
^es-Q0490

**es-Q0491 · Write a translation**

Write this in Spanish: I think I'd like to be your friend.

[[Spanish#^es-Q0491-answer|Compare the answer]]
^es-Q0491

**es-Q0492 · Explain the grammar**

Creo que me 【gustaría】 ser tu amigo.

I think I'd like to be your friend.

[[Spanish#^es-Q0492-answer|Compare the answer]]
^es-Q0492

**es-Q0493 · Fill the gap**

Me ____ hablar contigo a solas.

I'd like to talk with you in private.

[[Spanish#^es-Q0493-answer|Compare the answer]]
^es-Q0493

**es-Q0494 · Choose the form**

Me ____ hablar contigo a solas.

I'd like to talk with you in private.

Choices: podría / sería / tendría / gustaría

[[Spanish#^es-Q0494-answer|Compare the answer]]
^es-Q0494

**es-Q0495 · Edit the changed sentence**

【tendría】 mejor que os dierais prisa, el tren sale a las tres.

You had better hurry. The train leaves at three.

[[Spanish#^es-Q0495-answer|Compare the answer]]
^es-Q0495

**es-Q0496 · Build the sentence**

Arrange: a / mejor / sale / que / os / el / prisa, / las / Sería / tres. / tren / dierais

You had better hurry. The train leaves at three.

[[Spanish#^es-Q0496-answer|Compare the answer]]
^es-Q0496

**es-Q0497 · Write a translation**

Write this in Spanish: I'd like to know when you can send it out.

[[Spanish#^es-Q0497-answer|Compare the answer]]
^es-Q0497

**es-Q0498 · Explain the grammar**

Me 【gustaría】 saber cuándo lo puede enviar.

I'd like to know when you can send it out.

[[Spanish#^es-Q0498-answer|Compare the answer]]
^es-Q0498

**es-Q0499 · Fill the gap**

Le ____ enormemente agradecido si me ayudara.

I'd be very grateful if you'd help me.

[[Spanish#^es-Q0499-answer|Compare the answer]]
^es-Q0499

**es-Q0500 · Choose the form**

Le ____ enormemente agradecido si me ayudara.

I'd be very grateful if you'd help me.

Choices: estaría / sería / podría / tendría

[[Spanish#^es-Q0500-answer|Compare the answer]]
^es-Q0500


### Progressive constructions · 50 questions

**es-Q0501 · Edit the changed sentence**

«Solo estaba 【leyendo】 con él.» «¿Hablando con él de qué?» «Eso no es asunto tuyo.»

"I was just talking to him." "Talking to him about what?" "That's none of your business."

[[Spanish#^es-Q0501-answer|Compare the answer]]
^es-Q0501

**es-Q0502 · Build the sentence**

Arrange: no / «¿Hablando / qué?» / hablando / es / tuyo.» / con / con / de / «Eso / él / estaba / asunto / él.» / «Solo

"I was just talking to him." "Talking to him about what?" "That's none of your business."

[[Spanish#^es-Q0502-answer|Compare the answer]]
^es-Q0502

**es-Q0503 · Write a translation**

Write this in Spanish: Why's Tom still doing that?

[[Spanish#^es-Q0503-answer|Compare the answer]]
^es-Q0503

**es-Q0504 · Explain the grammar**

¿Por qué Tom sigue 【haciendo】 eso?

Why's Tom still doing that?

[[Spanish#^es-Q0504-answer|Compare the answer]]
^es-Q0504

**es-Q0505 · Fill the gap**

Como muchos de los estudiantes de nuestra escuela, Tom se queda despierto hasta tarde en la noche ____.

Like many students at our school, Tom stays up until late at night studying.

[[Spanish#^es-Q0505-answer|Compare the answer]]
^es-Q0505

**es-Q0506 · Choose the form**

Como muchos de los estudiantes de nuestra escuela, Tom se queda despierto hasta tarde en la noche ____.

Like many students at our school, Tom stays up until late at night studying.

Choices: comiendo / hablando / leyendo / estudiando

[[Spanish#^es-Q0506-answer|Compare the answer]]
^es-Q0506

**es-Q0507 · Edit the changed sentence**

Tom está 【hablando】 patología ocular.

Tom is studying ocular pathology.

[[Spanish#^es-Q0507-answer|Compare the answer]]
^es-Q0507

**es-Q0508 · Build the sentence**

Arrange: patología / ocular. / está / estudiando / Tom

Tom is studying ocular pathology.

[[Spanish#^es-Q0508-answer|Compare the answer]]
^es-Q0508

**es-Q0509 · Write a translation**

Write this in Spanish: What was your mother doing when you got home?

[[Spanish#^es-Q0509-answer|Compare the answer]]
^es-Q0509

**es-Q0510 · Explain the grammar**

¿Qué estaba 【haciendo】 tu madre cuando llegaste a casa?

What was your mother doing when you got home?

[[Spanish#^es-Q0510-answer|Compare the answer]]
^es-Q0510

**es-Q0511 · Fill the gap**

¿Ha estado Tom ____ sus labores?

Has Tom been doing his chores?

[[Spanish#^es-Q0511-answer|Compare the answer]]
^es-Q0511

**es-Q0512 · Choose the form**

¿Ha estado Tom ____ sus labores?

Has Tom been doing his chores?

Choices: leyendo / comiendo / hablando / haciendo

[[Spanish#^es-Q0512-answer|Compare the answer]]
^es-Q0512

**es-Q0513 · Edit the changed sentence**

La inspiración existe, pero tiene que encontrarte 【hablando】.

Inspiration exists, but it has to find you working.

[[Spanish#^es-Q0513-answer|Compare the answer]]
^es-Q0513

**es-Q0514 · Build the sentence**

Arrange: que / tiene / pero / inspiración / trabajando. / encontrarte / existe, / La

Inspiration exists, but it has to find you working.

[[Spanish#^es-Q0514-answer|Compare the answer]]
^es-Q0514

**es-Q0515 · Write a translation**

Write this in Spanish: He was working at the office yesterday evening.

[[Spanish#^es-Q0515-answer|Compare the answer]]
^es-Q0515

**es-Q0516 · Explain the grammar**

Él estaba 【trabajando】 en la oficina ayer por la tarde.

He was working at the office yesterday evening.

[[Spanish#^es-Q0516-answer|Compare the answer]]
^es-Q0516

**es-Q0517 · Fill the gap**

Creo que estoy ____ todo lo que puedo en ese trabajo.

I think I'm doing all I can in that job.

[[Spanish#^es-Q0517-answer|Compare the answer]]
^es-Q0517

**es-Q0518 · Choose the form**

Creo que estoy ____ todo lo que puedo en ese trabajo.

I think I'm doing all I can in that job.

Choices: leyendo / hablando / comiendo / haciendo

[[Spanish#^es-Q0518-answer|Compare the answer]]
^es-Q0518

**es-Q0519 · Edit the changed sentence**

¿Qué me estás 【hablando】?

What are you doing to me?

[[Spanish#^es-Q0519-answer|Compare the answer]]
^es-Q0519

**es-Q0520 · Build the sentence**

Arrange: haciendo? / ¿Qué / me / estás

What are you doing to me?

[[Spanish#^es-Q0520-answer|Compare the answer]]
^es-Q0520

**es-Q0521 · Write a translation**

Write this in Spanish: Tom doesn't know whether Mary is telling the truth or not.

[[Spanish#^es-Q0521-answer|Compare the answer]]
^es-Q0521

**es-Q0522 · Explain the grammar**

Tom no sabe si Mary está 【diciendo】 la verdad o no.

Tom doesn't know whether Mary is telling the truth or not.

[[Spanish#^es-Q0522-answer|Compare the answer]]
^es-Q0522

**es-Q0523 · Fill the gap**

Estoy ____ con Tom.

I am talking with Tom.

[[Spanish#^es-Q0523-answer|Compare the answer]]
^es-Q0523

**es-Q0524 · Choose the form**

Estoy ____ con Tom.

I am talking with Tom.

Choices: leyendo / comiendo / hablando / haciendo

[[Spanish#^es-Q0524-answer|Compare the answer]]
^es-Q0524

**es-Q0525 · Edit the changed sentence**

Tengo una idea muy vaga de lo que estás 【leyendo】.

I have a very vague idea of what you are talking about.

[[Spanish#^es-Q0525-answer|Compare the answer]]
^es-Q0525

**es-Q0526 · Build the sentence**

Arrange: idea / lo / Tengo / muy / de / vaga / estás / una / hablando. / que

I have a very vague idea of what you are talking about.

[[Spanish#^es-Q0526-answer|Compare the answer]]
^es-Q0526

**es-Q0527 · Write a translation**

Write this in Spanish: The man is making a long-distance call.

[[Spanish#^es-Q0527-answer|Compare the answer]]
^es-Q0527

**es-Q0528 · Explain the grammar**

El hombre está 【haciendo】 una llamada de larga distancia.

The man is making a long-distance call.

[[Spanish#^es-Q0528-answer|Compare the answer]]
^es-Q0528

**es-Q0529 · Fill the gap**

¿Con quién estabas ____ en el teléfono?

Who were you speaking to on the phone?

[[Spanish#^es-Q0529-answer|Compare the answer]]
^es-Q0529

**es-Q0530 · Choose the form**

¿Con quién estabas ____ en el teléfono?

Who were you speaking to on the phone?

Choices: leyendo / hablando / haciendo / comiendo

[[Spanish#^es-Q0530-answer|Compare the answer]]
^es-Q0530

**es-Q0531 · Edit the changed sentence**

Estoy convencida de que Tom no nos está 【hablando】 todo.

I'm convinced that Tom isn't telling us everything.

[[Spanish#^es-Q0531-answer|Compare the answer]]
^es-Q0531

**es-Q0532 · Build the sentence**

Arrange: todo. / de / nos / que / Estoy / está / diciendo / no / Tom / convencida

I'm convinced that Tom isn't telling us everything.

[[Spanish#^es-Q0532-answer|Compare the answer]]
^es-Q0532

**es-Q0533 · Write a translation**

Write this in Spanish: Who is he talking to?

[[Spanish#^es-Q0533-answer|Compare the answer]]
^es-Q0533

**es-Q0534 · Explain the grammar**

¿A quién le está 【hablando】?

Who is he talking to?

[[Spanish#^es-Q0534-answer|Compare the answer]]
^es-Q0534

**es-Q0535 · Fill the gap**

De verdad espero que nadie nos viera ____ eso.

I really hope nobody saw us doing that.

[[Spanish#^es-Q0535-answer|Compare the answer]]
^es-Q0535

**es-Q0536 · Choose the form**

De verdad espero que nadie nos viera ____ eso.

I really hope nobody saw us doing that.

Choices: leyendo / comiendo / haciendo / hablando

[[Spanish#^es-Q0536-answer|Compare the answer]]
^es-Q0536

**es-Q0537 · Edit the changed sentence**

Mi hermana no está 【hablando】 ahora.

My sister isn't studying now.

[[Spanish#^es-Q0537-answer|Compare the answer]]
^es-Q0537

**es-Q0538 · Build the sentence**

Arrange: ahora. / está / Mi / hermana / estudiando / no

My sister isn't studying now.

[[Spanish#^es-Q0538-answer|Compare the answer]]
^es-Q0538

**es-Q0539 · Write a translation**

Write this in Spanish: Tom keeps saying he's innocent.

[[Spanish#^es-Q0539-answer|Compare the answer]]
^es-Q0539

**es-Q0540 · Explain the grammar**

Tom sigue 【diciendo】 que es inocente.

Tom keeps saying he's innocent.

[[Spanish#^es-Q0540-answer|Compare the answer]]
^es-Q0540

**es-Q0541 · Fill the gap**

Pasé toda la mañana ____ inglés.

I spent the whole morning studying English.

[[Spanish#^es-Q0541-answer|Compare the answer]]
^es-Q0541

**es-Q0542 · Choose the form**

Pasé toda la mañana ____ inglés.

I spent the whole morning studying English.

Choices: leyendo / estudiando / comiendo / hablando

[[Spanish#^es-Q0542-answer|Compare the answer]]
^es-Q0542

**es-Q0543 · Edit the changed sentence**

¿Con quién estás 【leyendo】 ahora?

Who are you talking with now?

[[Spanish#^es-Q0543-answer|Compare the answer]]
^es-Q0543

**es-Q0544 · Build the sentence**

Arrange: estás / ¿Con / quién / hablando / ahora?

Who are you talking with now?

[[Spanish#^es-Q0544-answer|Compare the answer]]
^es-Q0544

**es-Q0545 · Write a translation**

Write this in Spanish: It is getting hotter day by day.

[[Spanish#^es-Q0545-answer|Compare the answer]]
^es-Q0545

**es-Q0546 · Explain the grammar**

Va 【haciendo】 más calor día a día.

It is getting hotter day by day.

[[Spanish#^es-Q0546-answer|Compare the answer]]
^es-Q0546

**es-Q0547 · Fill the gap**

Dejen a Tom terminar lo que está ____.

Let Tom finish what he's doing.

[[Spanish#^es-Q0547-answer|Compare the answer]]
^es-Q0547

**es-Q0548 · Choose the form**

Dejen a Tom terminar lo que está ____.

Let Tom finish what he's doing.

Choices: comiendo / haciendo / leyendo / hablando

[[Spanish#^es-Q0548-answer|Compare the answer]]
^es-Q0548

**es-Q0549 · Edit the changed sentence**

¿Qué está 【hablando】 Tom aquí fuera?

What's Tom doing out here?

[[Spanish#^es-Q0549-answer|Compare the answer]]
^es-Q0549

**es-Q0550 · Build the sentence**

Arrange: ¿Qué / fuera? / haciendo / Tom / aquí / está

What's Tom doing out here?

[[Spanish#^es-Q0550-answer|Compare the answer]]
^es-Q0550


### Object pronouns · 50 questions

**es-Q0551 · Write a translation**

Write this in Spanish: Tom didn't believe Mary.

[[Spanish#^es-Q0551-answer|Compare the answer]]
^es-Q0551

**es-Q0552 · Explain the grammar**

Tom no 【le】 creyó a Mary.

Tom didn't believe Mary.

[[Spanish#^es-Q0552-answer|Compare the answer]]
^es-Q0552

**es-Q0553 · Fill the gap**

Ha de haber alguna razón por ____ que ha hecho.

There must be some reason for what he has done.

[[Spanish#^es-Q0553-answer|Compare the answer]]
^es-Q0553

**es-Q0554 · Choose the form**

Ha de haber alguna razón por ____ que ha hecho.

There must be some reason for what he has done.

Choices: la / las / lo / los

[[Spanish#^es-Q0554-answer|Compare the answer]]
^es-Q0554

**es-Q0555 · Edit the changed sentence**

【lo】 siento totalmente fuera de lugar.

I feel so out of place.

[[Spanish#^es-Q0555-answer|Compare the answer]]
^es-Q0555

**es-Q0556 · Build the sentence**

Arrange: Me / totalmente / de / fuera / lugar. / siento

I feel so out of place.

[[Spanish#^es-Q0556-answer|Compare the answer]]
^es-Q0556

**es-Q0557 · Write a translation**

Write this in Spanish: Sorry. I beg your pardon?

[[Spanish#^es-Q0557-answer|Compare the answer]]
^es-Q0557

**es-Q0558 · Explain the grammar**

¿Cómo dices? No 【te】 he entendido.

Sorry. I beg your pardon?

[[Spanish#^es-Q0558-answer|Compare the answer]]
^es-Q0558

**es-Q0559 · Fill the gap**

No ____ veo como arte.

I don't see it as art.

[[Spanish#^es-Q0559-answer|Compare the answer]]
^es-Q0559

**es-Q0560 · Choose the form**

No ____ veo como arte.

I don't see it as art.

Choices: los / lo / la / las

[[Spanish#^es-Q0560-answer|Compare the answer]]
^es-Q0560

**es-Q0561 · Edit the changed sentence**

El costo de reparar el techo 【lo】 dejó pasmada.

The cost of repairing the roof shocked her.

[[Spanish#^es-Q0561-answer|Compare the answer]]
^es-Q0561

**es-Q0562 · Build the sentence**

Arrange: de / costo / la / dejó / reparar / El / techo / pasmada. / el

The cost of repairing the roof shocked her.

[[Spanish#^es-Q0562-answer|Compare the answer]]
^es-Q0562

**es-Q0563 · Write a translation**

Write this in Spanish: What if you're wrong?

[[Spanish#^es-Q0563-answer|Compare the answer]]
^es-Q0563

**es-Q0564 · Explain the grammar**

¿Y si 【te】 equivocas?

What if you're wrong?

[[Spanish#^es-Q0564-answer|Compare the answer]]
^es-Q0564

**es-Q0565 · Fill the gap**

Estuvimos viendo ____ tele ayer.

We were watching TV yesterday.

[[Spanish#^es-Q0565-answer|Compare the answer]]
^es-Q0565

**es-Q0566 · Choose the form**

Estuvimos viendo ____ tele ayer.

We were watching TV yesterday.

Choices: las / lo / los / la

[[Spanish#^es-Q0566-answer|Compare the answer]]
^es-Q0566

**es-Q0567 · Edit the changed sentence**

A ella también 【lo】 encanta el chocolate.

She loves chocolate, too.

[[Spanish#^es-Q0567-answer|Compare the answer]]
^es-Q0567

**es-Q0568 · Build the sentence**

Arrange: también / el / encanta / chocolate. / A / le / ella

She loves chocolate, too.

[[Spanish#^es-Q0568-answer|Compare the answer]]
^es-Q0568

**es-Q0569 · Write a translation**

Write this in Spanish: I didn't know that trick.

[[Spanish#^es-Q0569-answer|Compare the answer]]
^es-Q0569

**es-Q0570 · Explain the grammar**

Ese truco yo no 【lo】 sabía.

I didn't know that trick.

[[Spanish#^es-Q0570-answer|Compare the answer]]
^es-Q0570

**es-Q0571 · Fill the gap**

No ____ preocupéis por mí.

Don't worry about me.

[[Spanish#^es-Q0571-answer|Compare the answer]]
^es-Q0571

**es-Q0572 · Choose the form**

No ____ preocupéis por mí.

Don't worry about me.

Choices: os / los / lo / la

[[Spanish#^es-Q0572-answer|Compare the answer]]
^es-Q0572

**es-Q0573 · Edit the changed sentence**

Por favor, ponga 【lo】 palanca hacia arriba.

Please push up the lever.

[[Spanish#^es-Q0573-answer|Compare the answer]]
^es-Q0573

**es-Q0574 · Build the sentence**

Arrange: favor, / ponga / palanca / hacia / arriba. / Por / la

Please push up the lever.

[[Spanish#^es-Q0574-answer|Compare the answer]]
^es-Q0574

**es-Q0575 · Write a translation**

Write this in Spanish: Everybody likes money.

[[Spanish#^es-Q0575-answer|Compare the answer]]
^es-Q0575

**es-Q0576 · Explain the grammar**

El dinero 【le】 gusta a todo el mundo.

Everybody likes money.

[[Spanish#^es-Q0576-answer|Compare the answer]]
^es-Q0576

**es-Q0577 · Fill the gap**

____ chicas excitadas a veces parecen bonitas.

Excited girls look pretty sometimes.

[[Spanish#^es-Q0577-answer|Compare the answer]]
^es-Q0577

**es-Q0578 · Choose the form**

____ chicas excitadas a veces parecen bonitas.

Excited girls look pretty sometimes.

Choices: Las / los / lo / la

[[Spanish#^es-Q0578-answer|Compare the answer]]
^es-Q0578

**es-Q0579 · Edit the changed sentence**

Compré 【lo】 mesa de caoba por ser la más elegante.

I bought the mahogany table because it was the most elegant.

[[Spanish#^es-Q0579-answer|Compare the answer]]
^es-Q0579

**es-Q0580 · Build the sentence**

Arrange: ser / por / elegante. / Compré / mesa / caoba / de / la / más / la

I bought the mahogany table because it was the most elegant.

[[Spanish#^es-Q0580-answer|Compare the answer]]
^es-Q0580

**es-Q0581 · Write a translation**

Write this in Spanish: Yanni won the lottery in Algeria.

[[Spanish#^es-Q0581-answer|Compare the answer]]
^es-Q0581

**es-Q0582 · Explain the grammar**

Yanni ganó 【la】 lotería en Argelia.

Yanni won the lottery in Algeria.

[[Spanish#^es-Q0582-answer|Compare the answer]]
^es-Q0582

**es-Q0583 · Fill the gap**

He visto cada fotograma de ____ películas de Dan.

I have seen every frame of Dan's movies.

[[Spanish#^es-Q0583-answer|Compare the answer]]
^es-Q0583

**es-Q0584 · Choose the form**

He visto cada fotograma de ____ películas de Dan.

I have seen every frame of Dan's movies.

Choices: lo / las / la / los

[[Spanish#^es-Q0584-answer|Compare the answer]]
^es-Q0584

**es-Q0585 · Edit the changed sentence**

【la】 ha hecho mejor que la vez pasada.

He has done better than last time.

[[Spanish#^es-Q0585-answer|Compare the answer]]
^es-Q0585

**es-Q0586 · Build the sentence**

Arrange: mejor / vez / la / Lo / hecho / que / pasada. / ha

He has done better than last time.

[[Spanish#^es-Q0586-answer|Compare the answer]]
^es-Q0586

**es-Q0587 · Write a translation**

Write this in Spanish: There are numerous theories about the origin of life.

[[Spanish#^es-Q0587-answer|Compare the answer]]
^es-Q0587

**es-Q0588 · Explain the grammar**

Existen numerosas teorías acerca del origen de 【la】 vida.

There are numerous theories about the origin of life.

[[Spanish#^es-Q0588-answer|Compare the answer]]
^es-Q0588

**es-Q0589 · Fill the gap**

¿Se ____ ha olvidado hacer los deberes?

Did you forget to do your homework?

[[Spanish#^es-Q0589-answer|Compare the answer]]
^es-Q0589

**es-Q0590 · Choose the form**

¿Se ____ ha olvidado hacer los deberes?

Did you forget to do your homework?

Choices: la / los / os / lo

[[Spanish#^es-Q0590-answer|Compare the answer]]
^es-Q0590

**es-Q0591 · Edit the changed sentence**

Devuélvete a 【lo】 casa.

Go back home.

[[Spanish#^es-Q0591-answer|Compare the answer]]
^es-Q0591

**es-Q0592 · Build the sentence**

Arrange: casa. / la / a / Devuélvete

Go back home.

[[Spanish#^es-Q0592-answer|Compare the answer]]
^es-Q0592

**es-Q0593 · Write a translation**

Write this in Spanish: I am going to go play ball with Mohan.

[[Spanish#^es-Q0593-answer|Compare the answer]]
^es-Q0593

**es-Q0594 · Explain the grammar**

Voy a ir a jugar a 【la】 pelota con Mohan.

I am going to go play ball with Mohan.

[[Spanish#^es-Q0594-answer|Compare the answer]]
^es-Q0594

**es-Q0595 · Fill the gap**

____ gusta jugar al futbol.

I like to play soccer.

[[Spanish#^es-Q0595-answer|Compare the answer]]
^es-Q0595

**es-Q0596 · Choose the form**

____ gusta jugar al futbol.

I like to play soccer.

Choices: Me / lo / los / la

[[Spanish#^es-Q0596-answer|Compare the answer]]
^es-Q0596

**es-Q0597 · Edit the changed sentence**

【lo】 propia voluntad supera cualquier orden.

One's own will overrides any command.

[[Spanish#^es-Q0597-answer|Compare the answer]]
^es-Q0597

**es-Q0598 · Build the sentence**

Arrange: orden. / propia / La / cualquier / voluntad / supera

One's own will overrides any command.

[[Spanish#^es-Q0598-answer|Compare the answer]]
^es-Q0598

**es-Q0599 · Write a translation**

Write this in Spanish: The signal turned from red to green.

[[Spanish#^es-Q0599-answer|Compare the answer]]
^es-Q0599

**es-Q0600 · Explain the grammar**

【La】 señal cambió de roja a verde.

The signal turned from red to green.

[[Spanish#^es-Q0600-answer|Compare the answer]]
^es-Q0600


### Reflexive and other se · 50 questions

**es-Q0601 · Fill the gap**

Tom ____ bebió un vaso de leche.

Tom drank a glass of milk.

[[Spanish#^es-Q0601-answer|Compare the answer]]
^es-Q0601

**es-Q0602 · Choose the form**

Tom ____ bebió un vaso de leche.

Tom drank a glass of milk.

Choices: la / se / le / lo

[[Spanish#^es-Q0602-answer|Compare the answer]]
^es-Q0602

**es-Q0603 · Edit the changed sentence**

¿Qué 【le】 puede encontrar más allá del final del universo?

What can be found beyond the end of the universe?

[[Spanish#^es-Q0603-answer|Compare the answer]]
^es-Q0603

**es-Q0604 · Build the sentence**

Arrange: final / puede / ¿Qué / se / universo? / más / allá / del / del / encontrar

What can be found beyond the end of the universe?

[[Spanish#^es-Q0604-answer|Compare the answer]]
^es-Q0604

**es-Q0605 · Write a translation**

Write this in Spanish: What's it called in Kabyle?

[[Spanish#^es-Q0605-answer|Compare the answer]]
^es-Q0605

**es-Q0606 · Explain the grammar**

¿Como 【se】 dice eso en cabilio?

What's it called in Kabyle?

[[Spanish#^es-Q0606-answer|Compare the answer]]
^es-Q0606

**es-Q0607 · Fill the gap**

Parece que Tony ____ compró un auto costoso.

It seems that Tony bought an expensive car.

[[Spanish#^es-Q0607-answer|Compare the answer]]
^es-Q0607

**es-Q0608 · Choose the form**

Parece que Tony ____ compró un auto costoso.

It seems that Tony bought an expensive car.

Choices: le / lo / la / se

[[Spanish#^es-Q0608-answer|Compare the answer]]
^es-Q0608

**es-Q0609 · Edit the changed sentence**

Si la pintamos de blanco, la habitación 【le】 volverá más luminosa.

White paint will brighten the room.

[[Spanish#^es-Q0609-answer|Compare the answer]]
^es-Q0609

**es-Q0610 · Build the sentence**

Arrange: blanco, / luminosa. / de / la / la / más / volverá / habitación / se / Si / pintamos

White paint will brighten the room.

[[Spanish#^es-Q0610-answer|Compare the answer]]
^es-Q0610

**es-Q0611 · Write a translation**

Write this in Spanish: Courage is needed to change a custom.

[[Spanish#^es-Q0611-answer|Compare the answer]]
^es-Q0611

**es-Q0612 · Explain the grammar**

【Se】 requiere coraje para cambiar una costumbre.

Courage is needed to change a custom.

[[Spanish#^es-Q0612-answer|Compare the answer]]
^es-Q0612

**es-Q0613 · Fill the gap**

Desde que ____ hirió en un accidente, no ha podido volver a andar.

Since he was injured in an accident, he could no longer walk.

[[Spanish#^es-Q0613-answer|Compare the answer]]
^es-Q0613

**es-Q0614 · Choose the form**

Desde que ____ hirió en un accidente, no ha podido volver a andar.

Since he was injured in an accident, he could no longer walk.

Choices: le / se / lo / la

[[Spanish#^es-Q0614-answer|Compare the answer]]
^es-Q0614

**es-Q0615 · Edit the changed sentence**

Los huevos 【le】 pueden ocupar como armas.

Eggs can be used as weapons.

[[Spanish#^es-Q0615-answer|Compare the answer]]
^es-Q0615

**es-Q0616 · Build the sentence**

Arrange: ocupar / armas. / huevos / como / se / pueden / Los

Eggs can be used as weapons.

[[Spanish#^es-Q0616-answer|Compare the answer]]
^es-Q0616

**es-Q0617 · Write a translation**

Write this in Spanish: She composed herself before speaking.

[[Spanish#^es-Q0617-answer|Compare the answer]]
^es-Q0617

**es-Q0618 · Explain the grammar**

Ella 【se】 tranquilizó antes de hablar.

She composed herself before speaking.

[[Spanish#^es-Q0618-answer|Compare the answer]]
^es-Q0618

**es-Q0619 · Fill the gap**

Tom ____ vio obligado a abandonar la misión.

Tom was forced to abandon the mission.

[[Spanish#^es-Q0619-answer|Compare the answer]]
^es-Q0619

**es-Q0620 · Choose the form**

Tom ____ vio obligado a abandonar la misión.

Tom was forced to abandon the mission.

Choices: lo / la / le / se

[[Spanish#^es-Q0620-answer|Compare the answer]]
^es-Q0620

**es-Q0621 · Edit the changed sentence**

Tom 【le】 subió al bus equivocado.

Tom got on the wrong bus.

[[Spanish#^es-Q0621-answer|Compare the answer]]
^es-Q0621

**es-Q0622 · Build the sentence**

Arrange: al / equivocado. / Tom / se / subió / bus

Tom got on the wrong bus.

[[Spanish#^es-Q0622-answer|Compare the answer]]
^es-Q0622

**es-Q0623 · Write a translation**

Write this in Spanish: This is why he got angry with you.

[[Spanish#^es-Q0623-answer|Compare the answer]]
^es-Q0623

**es-Q0624 · Explain the grammar**

Es por esto que él 【se】 enojó contigo.

This is why he got angry with you.

[[Spanish#^es-Q0624-answer|Compare the answer]]
^es-Q0624

**es-Q0625 · Fill the gap**

Él ____ metió las manos en los bolsillos.

He put his hands in his pockets.

[[Spanish#^es-Q0625-answer|Compare the answer]]
^es-Q0625

**es-Q0626 · Choose the form**

Él ____ metió las manos en los bolsillos.

He put his hands in his pockets.

Choices: se / la / lo / le

[[Spanish#^es-Q0626-answer|Compare the answer]]
^es-Q0626

**es-Q0627 · Edit the changed sentence**

【le】 situó en el centro de la calle con un cartel que decía "Abrazos gratis".

He placed himself in the middle of the street with a sign that said, "Free hugs."

[[Spanish#^es-Q0627-answer|Compare the answer]]
^es-Q0627

**es-Q0628 · Build the sentence**

Arrange: Se / decía / un / calle / en / "Abrazos / el / que / de / con / cartel / centro / situó / gratis". / la

He placed himself in the middle of the street with a sign that said, "Free hugs."

[[Spanish#^es-Q0628-answer|Compare the answer]]
^es-Q0628

**es-Q0629 · Write a translation**

Write this in Spanish: A fire broke out during the night.

[[Spanish#^es-Q0629-answer|Compare the answer]]
^es-Q0629

**es-Q0630 · Explain the grammar**

【Se】 produjo un incendio durante la noche.

A fire broke out during the night.

[[Spanish#^es-Q0630-answer|Compare the answer]]
^es-Q0630

**es-Q0631 · Fill the gap**

No ____ permiten mascotas.

No pets allowed.

[[Spanish#^es-Q0631-answer|Compare the answer]]
^es-Q0631

**es-Q0632 · Choose the form**

No ____ permiten mascotas.

No pets allowed.

Choices: se / le / lo / la

[[Spanish#^es-Q0632-answer|Compare the answer]]
^es-Q0632

**es-Q0633 · Edit the changed sentence**

¿【le】 te ha ido la pinza?

Are you out of your mind?

[[Spanish#^es-Q0633-answer|Compare the answer]]
^es-Q0633

**es-Q0634 · Build the sentence**

Arrange: ¿Se / te / pinza? / ido / la / ha

Are you out of your mind?

[[Spanish#^es-Q0634-answer|Compare the answer]]
^es-Q0634

**es-Q0635 · Write a translation**

Write this in Spanish: Because of his score of zero, he didn't dare to return.

[[Spanish#^es-Q0635-answer|Compare the answer]]
^es-Q0635

**es-Q0636 · Explain the grammar**

Debido a su puntaje de cero, no 【se】 atrevía a volver.

Because of his score of zero, he didn't dare to return.

[[Spanish#^es-Q0636-answer|Compare the answer]]
^es-Q0636

**es-Q0637 · Fill the gap**

Mary no ____ puede decidir si comprar el vestido o no.

Mary can't decide whether or not to buy the dress.

[[Spanish#^es-Q0637-answer|Compare the answer]]
^es-Q0637

**es-Q0638 · Choose the form**

Mary no ____ puede decidir si comprar el vestido o no.

Mary can't decide whether or not to buy the dress.

Choices: la / lo / le / se

[[Spanish#^es-Q0638-answer|Compare the answer]]
^es-Q0638

**es-Q0639 · Edit the changed sentence**

Los cursos intermedios y avanzados de una lengua 【le】 dan en la lengua que se está aprendiendo.

Intermediate and advanced language courses are given in the language being learned.

[[Spanish#^es-Q0639-answer|Compare the answer]]
^es-Q0639

**es-Q0640 · Build the sentence**

Arrange: lengua / Los / se / dan / cursos / y / se / intermedios / avanzados / aprendiendo. / lengua / está / en / que / una / de / la

Intermediate and advanced language courses are given in the language being learned.

[[Spanish#^es-Q0640-answer|Compare the answer]]
^es-Q0640

**es-Q0641 · Write a translation**

Write this in Spanish: My brother bought an electric guitar.

[[Spanish#^es-Q0641-answer|Compare the answer]]
^es-Q0641

**es-Q0642 · Explain the grammar**

Mi hermano 【se】 ha comprado una guitarra eléctrica.

My brother bought an electric guitar.

[[Spanish#^es-Q0642-answer|Compare the answer]]
^es-Q0642

**es-Q0643 · Fill the gap**

Ella ____ casó con ella.

She got married to her.

[[Spanish#^es-Q0643-answer|Compare the answer]]
^es-Q0643

**es-Q0644 · Choose the form**

Ella ____ casó con ella.

She got married to her.

Choices: la / se / le / lo

[[Spanish#^es-Q0644-answer|Compare the answer]]
^es-Q0644

**es-Q0645 · Edit the changed sentence**

No creo que 【le】 me necesite más aquí.

I don't think I'm needed here any longer.

[[Spanish#^es-Q0645-answer|Compare the answer]]
^es-Q0645

**es-Q0646 · Build the sentence**

Arrange: que / me / aquí. / necesite / más / se / No / creo

I don't think I'm needed here any longer.

[[Spanish#^es-Q0646-answer|Compare the answer]]
^es-Q0646

**es-Q0647 · Write a translation**

Write this in Spanish: Lots of people get married on Saturdays.

[[Spanish#^es-Q0647-answer|Compare the answer]]
^es-Q0647

**es-Q0648 · Explain the grammar**

Mucha gente 【se】 casa los sábados.

Lots of people get married on Saturdays.

[[Spanish#^es-Q0648-answer|Compare the answer]]
^es-Q0648

**es-Q0649 · Fill the gap**

Deseo oír la historia completa, y no ____ salte ningún detalle.

I want to hear the whole story, and don't skip any details.

[[Spanish#^es-Q0649-answer|Compare the answer]]
^es-Q0649

**es-Q0650 · Choose the form**

Deseo oír la historia completa, y no ____ salte ningún detalle.

I want to hear the whole story, and don't skip any details.

Choices: se / la / lo / le

[[Spanish#^es-Q0650-answer|Compare the answer]]
^es-Q0650


### Relative words · 50 questions

**es-Q0651 · Edit the changed sentence**

No puedo, a pesar 【quien】 quiero.

I can't even if I want to.

[[Spanish#^es-Q0651-answer|Compare the answer]]
^es-Q0651

**es-Q0652 · Build the sentence**

Arrange: que / a / puedo, / pesar / No / quiero.

I can't even if I want to.

[[Spanish#^es-Q0652-answer|Compare the answer]]
^es-Q0652

**es-Q0653 · Write a translation**

Write this in Spanish: I can't believe Tom accepted our offer.

[[Spanish#^es-Q0653-answer|Compare the answer]]
^es-Q0653

**es-Q0654 · Explain the grammar**

No puedo creer 【que】 Tom aceptara nuestra oferta.

I can't believe Tom accepted our offer.

[[Spanish#^es-Q0654-answer|Compare the answer]]
^es-Q0654

**es-Q0655 · Fill the gap**

Tuve ____ ir ahí solo.

I had to go there alone.

[[Spanish#^es-Q0655-answer|Compare the answer]]
^es-Q0655

**es-Q0656 · Choose the form**

Tuve ____ ir ahí solo.

I had to go there alone.

Choices: donde / quien / cuyo / que

[[Spanish#^es-Q0656-answer|Compare the answer]]
^es-Q0656

**es-Q0657 · Edit the changed sentence**

Suba la persiana para 【quien】 entre un poquito de luz.

Raise the blinds to let in a little light.

[[Spanish#^es-Q0657-answer|Compare the answer]]
^es-Q0657

**es-Q0658 · Build the sentence**

Arrange: entre / Suba / luz. / persiana / poquito / para / que / un / de / la

Raise the blinds to let in a little light.

[[Spanish#^es-Q0658-answer|Compare the answer]]
^es-Q0658

**es-Q0659 · Write a translation**

Write this in Spanish: I made Tom promise not to tell Mary.

[[Spanish#^es-Q0659-answer|Compare the answer]]
^es-Q0659

**es-Q0660 · Explain the grammar**

Hice a Tom prometer 【que】 no le dijera a Mary.

I made Tom promise not to tell Mary.

[[Spanish#^es-Q0660-answer|Compare the answer]]
^es-Q0660

**es-Q0661 · Fill the gap**

Solo necesito ____ vengas conmigo.

I just need you to come with me.

[[Spanish#^es-Q0661-answer|Compare the answer]]
^es-Q0661

**es-Q0662 · Choose the form**

Solo necesito ____ vengas conmigo.

I just need you to come with me.

Choices: cuyo / quien / donde / que

[[Spanish#^es-Q0662-answer|Compare the answer]]
^es-Q0662

**es-Q0663 · Edit the changed sentence**

Tom espera 【quien】 Mary venga el próximo fin de semana.

Tom hopes that Mary will come next weekend.

[[Spanish#^es-Q0663-answer|Compare the answer]]
^es-Q0663

**es-Q0664 · Build the sentence**

Arrange: Tom / Mary / próximo / fin / que / venga / espera / el / semana. / de

Tom hopes that Mary will come next weekend.

[[Spanish#^es-Q0664-answer|Compare the answer]]
^es-Q0664

**es-Q0665 · Write a translation**

Write this in Spanish: You never know what you can do till you try.

[[Spanish#^es-Q0665-answer|Compare the answer]]
^es-Q0665

**es-Q0666 · Explain the grammar**

Si no lo intentas, nunca sabrás lo 【que】 eres capaz de hacer.

You never know what you can do till you try.

[[Spanish#^es-Q0666-answer|Compare the answer]]
^es-Q0666

**es-Q0667 · Fill the gap**

Tom sostiene ____ no sabe nada acerca de Mary.

Tom claims he knows nothing about Mary.

[[Spanish#^es-Q0667-answer|Compare the answer]]
^es-Q0667

**es-Q0668 · Choose the form**

Tom sostiene ____ no sabe nada acerca de Mary.

Tom claims he knows nothing about Mary.

Choices: donde / que / quien / cuyo

[[Spanish#^es-Q0668-answer|Compare the answer]]
^es-Q0668

**es-Q0669 · Edit the changed sentence**

¿Crees 【quien】 Tom tendrá éxito?

Do you think Tom will succeed?

[[Spanish#^es-Q0669-answer|Compare the answer]]
^es-Q0669

**es-Q0670 · Build the sentence**

Arrange: éxito? / ¿Crees / tendrá / que / Tom

Do you think Tom will succeed?

[[Spanish#^es-Q0670-answer|Compare the answer]]
^es-Q0670

**es-Q0671 · Write a translation**

Write this in Spanish: It is not surprising that he was elected mayor.

[[Spanish#^es-Q0671-answer|Compare the answer]]
^es-Q0671

**es-Q0672 · Explain the grammar**

No es de sorprenderse 【que】 saliera electo alcalde.

It is not surprising that he was elected mayor.

[[Spanish#^es-Q0672-answer|Compare the answer]]
^es-Q0672

**es-Q0673 · Fill the gap**

No permito ____ duerman durante la clase.

I do not allow sleeping in class.

[[Spanish#^es-Q0673-answer|Compare the answer]]
^es-Q0673

**es-Q0674 · Choose the form**

No permito ____ duerman durante la clase.

I do not allow sleeping in class.

Choices: quien / donde / cuyo / que

[[Spanish#^es-Q0674-answer|Compare the answer]]
^es-Q0674

**es-Q0675 · Edit the changed sentence**

María piensa 【quien】 aprender idiomas extranjeros es tedioso y aburrido.

Mary thinks that learning foreign languages is tedious and boring.

[[Spanish#^es-Q0675-answer|Compare the answer]]
^es-Q0675

**es-Q0676 · Build the sentence**

Arrange: idiomas / es / extranjeros / que / aprender / aburrido. / piensa / y / María / tedioso

Mary thinks that learning foreign languages is tedious and boring.

[[Spanish#^es-Q0676-answer|Compare the answer]]
^es-Q0676

**es-Q0677 · Write a translation**

Write this in Spanish: My Chinese is not perfect, but I could understand enough of what he said.

[[Spanish#^es-Q0677-answer|Compare the answer]]
^es-Q0677

**es-Q0678 · Explain the grammar**

Mi chino no es perfecto, pero pude entender bastante de lo 【que】 él habló.

My Chinese is not perfect, but I could understand enough of what he said.

[[Spanish#^es-Q0678-answer|Compare the answer]]
^es-Q0678

**es-Q0679 · Fill the gap**

El ____ lucha puede perder, el que no lucha ya perdió.

He who fights may lose, but he who doesn't has already lost.

[[Spanish#^es-Q0679-answer|Compare the answer]]
^es-Q0679

**es-Q0680 · Choose the form**

El ____ lucha puede perder, el que no lucha ya perdió.

He who fights may lose, but he who doesn't has already lost.

Choices: donde / que / cuyo / quien

[[Spanish#^es-Q0680-answer|Compare the answer]]
^es-Q0680

**es-Q0681 · Edit the changed sentence**

Finjamos 【quien】 somos ninjas.

Let's make believe we are ninja.

[[Spanish#^es-Q0681-answer|Compare the answer]]
^es-Q0681

**es-Q0682 · Build the sentence**

Arrange: Finjamos / que / ninjas. / somos

Let's make believe we are ninja.

[[Spanish#^es-Q0682-answer|Compare the answer]]
^es-Q0682

**es-Q0683 · Write a translation**

Write this in Spanish: You'd better leave it.

[[Spanish#^es-Q0683-answer|Compare the answer]]
^es-Q0683

**es-Q0684 · Explain the grammar**

Será mejor 【que】 pares.

You'd better leave it.

[[Spanish#^es-Q0684-answer|Compare the answer]]
^es-Q0684

**es-Q0685 · Fill the gap**

Puedes hacer lo ____ gustes.

You can do whatever you like.

[[Spanish#^es-Q0685-answer|Compare the answer]]
^es-Q0685

**es-Q0686 · Choose the form**

Puedes hacer lo ____ gustes.

You can do whatever you like.

Choices: quien / cuyo / donde / que

[[Spanish#^es-Q0686-answer|Compare the answer]]
^es-Q0686

**es-Q0687 · Edit the changed sentence**

A la hora 【quien】 llegue a casa estaré demasiado cansado para hacerlo.

By the time I get home I'll be too tired to do that.

[[Spanish#^es-Q0687-answer|Compare the answer]]
^es-Q0687

**es-Q0688 · Build the sentence**

Arrange: A / estaré / que / la / llegue / hacerlo. / casa / cansado / para / demasiado / hora / a

By the time I get home I'll be too tired to do that.

[[Spanish#^es-Q0688-answer|Compare the answer]]
^es-Q0688

**es-Q0689 · Write a translation**

Write this in Spanish: It's important that you share your pain.

[[Spanish#^es-Q0689-answer|Compare the answer]]
^es-Q0689

**es-Q0690 · Explain the grammar**

Es importante 【que】 comparta su dolor.

It's important that you share your pain.

[[Spanish#^es-Q0690-answer|Compare the answer]]
^es-Q0690

**es-Q0691 · Fill the gap**

Dicen ____ ella es la mujer más amable del mundo.

They say she is the kindest woman on earth.

[[Spanish#^es-Q0691-answer|Compare the answer]]
^es-Q0691

**es-Q0692 · Choose the form**

Dicen ____ ella es la mujer más amable del mundo.

They say she is the kindest woman on earth.

Choices: quien / donde / que / cuyo

[[Spanish#^es-Q0692-answer|Compare the answer]]
^es-Q0692

**es-Q0693 · Edit the changed sentence**

Quiero 【quien】 conozcas a mis padres.

I want you to meet my parents.

[[Spanish#^es-Q0693-answer|Compare the answer]]
^es-Q0693

**es-Q0694 · Build the sentence**

Arrange: padres. / a / conozcas / Quiero / mis / que

I want you to meet my parents.

[[Spanish#^es-Q0694-answer|Compare the answer]]
^es-Q0694

**es-Q0695 · Write a translation**

Write this in Spanish: Did you find what you were looking for?

[[Spanish#^es-Q0695-answer|Compare the answer]]
^es-Q0695

**es-Q0696 · Explain the grammar**

¿Encontraste lo 【que】 estabas buscando?

Did you find what you were looking for?

[[Spanish#^es-Q0696-answer|Compare the answer]]
^es-Q0696

**es-Q0697 · Fill the gap**

Sin importar lo ____ pase, Tom siempre llega a tiempo.

No matter what happens, Tom always shows up on time.

[[Spanish#^es-Q0697-answer|Compare the answer]]
^es-Q0697

**es-Q0698 · Choose the form**

Sin importar lo ____ pase, Tom siempre llega a tiempo.

No matter what happens, Tom always shows up on time.

Choices: quien / donde / que / cuyo

[[Spanish#^es-Q0698-answer|Compare the answer]]
^es-Q0698

**es-Q0699 · Edit the changed sentence**

Pateó al perro 【quien】 corrió hacia él.

He kicked the dog which ran at him.

[[Spanish#^es-Q0699-answer|Compare the answer]]
^es-Q0699

**es-Q0700 · Build the sentence**

Arrange: Pateó / él. / hacia / que / corrió / perro / al

He kicked the dog which ran at him.

[[Spanish#^es-Q0700-answer|Compare the answer]]
^es-Q0700


### Negation · 50 questions

**es-Q0701 · Write a translation**

Write this in Spanish: That kind of thing can't be found just anywhere.

[[Spanish#^es-Q0701-answer|Compare the answer]]
^es-Q0701

**es-Q0702 · Explain the grammar**

Esa clase de cosas 【no】 puede encontrarse en cualquier parte.

That kind of thing can't be found just anywhere.

[[Spanish#^es-Q0702-answer|Compare the answer]]
^es-Q0702

**es-Q0703 · Fill the gap**

____ nací sabiendo.

I wasn't born knowing.

[[Spanish#^es-Q0703-answer|Compare the answer]]
^es-Q0703

**es-Q0704 · Choose the form**

____ nací sabiendo.

I wasn't born knowing.

Choices: No / nada / nunca / nadie

[[Spanish#^es-Q0704-answer|Compare the answer]]
^es-Q0704

**es-Q0705 · Edit the changed sentence**

Si tú 【nunca】 vas a esquiar, yo tampoco iré.

If you don't go skiing, I won't, either.

[[Spanish#^es-Q0705-answer|Compare the answer]]
^es-Q0705

**es-Q0706 · Build the sentence**

Arrange: a / esquiar, / no / Si / vas / tampoco / tú / yo / iré.

If you don't go skiing, I won't, either.

[[Spanish#^es-Q0706-answer|Compare the answer]]
^es-Q0706

**es-Q0707 · Write a translation**

Write this in Spanish: She doesn't believe in God.

[[Spanish#^es-Q0707-answer|Compare the answer]]
^es-Q0707

**es-Q0708 · Explain the grammar**

Ella 【no】 cree en Dios.

She doesn't believe in God.

[[Spanish#^es-Q0708-answer|Compare the answer]]
^es-Q0708

**es-Q0709 · Fill the gap**

____ sabe nada.

He knows nothing.

[[Spanish#^es-Q0709-answer|Compare the answer]]
^es-Q0709

**es-Q0710 · Choose the form**

____ sabe nada.

He knows nothing.

Choices: nada / nadie / No / nunca

[[Spanish#^es-Q0710-answer|Compare the answer]]
^es-Q0710

**es-Q0711 · Edit the changed sentence**

Para mi sorpresa, él 【nunca】 sabía usar el diccionario.

To my surprise, he didn't know how to use the dictionary.

[[Spanish#^es-Q0711-answer|Compare the answer]]
^es-Q0711

**es-Q0712 · Build the sentence**

Arrange: mi / el / sorpresa, / Para / sabía / él / diccionario. / usar / no

To my surprise, he didn't know how to use the dictionary.

[[Spanish#^es-Q0712-answer|Compare the answer]]
^es-Q0712

**es-Q0713 · Write a translation**

Write this in Spanish: He can't come with us.

[[Spanish#^es-Q0713-answer|Compare the answer]]
^es-Q0713

**es-Q0714 · Explain the grammar**

Él 【no】 puede venir con nosotros.

He can't come with us.

[[Spanish#^es-Q0714-answer|Compare the answer]]
^es-Q0714

**es-Q0715 · Fill the gap**

Lamentablemente, Apple ____ provee una garantía contra daños accidentales.

Unfortunately, Apple does not provide a warranty for accidental damages.

[[Spanish#^es-Q0715-answer|Compare the answer]]
^es-Q0715

**es-Q0716 · Choose the form**

Lamentablemente, Apple ____ provee una garantía contra daños accidentales.

Unfortunately, Apple does not provide a warranty for accidental damages.

Choices: nadie / no / nada / nunca

[[Spanish#^es-Q0716-answer|Compare the answer]]
^es-Q0716

**es-Q0717 · Edit the changed sentence**

【nunca】 seas tan ruidoso, por favor.

Don't be so noisy, please.

[[Spanish#^es-Q0717-answer|Compare the answer]]
^es-Q0717

**es-Q0718 · Build the sentence**

Arrange: seas / No / por / ruidoso, / tan / favor.

Don't be so noisy, please.

[[Spanish#^es-Q0718-answer|Compare the answer]]
^es-Q0718

**es-Q0719 · Write a translation**

Write this in Spanish: I don't ever tend to have an afternoon meal.

[[Spanish#^es-Q0719-answer|Compare the answer]]
^es-Q0719

**es-Q0720 · Explain the grammar**

【No】 suelo merendar nunca.

I don't ever tend to have an afternoon meal.

[[Spanish#^es-Q0720-answer|Compare the answer]]
^es-Q0720

**es-Q0721 · Fill the gap**

Tom ____ habla francés con tanta fluidez como Mary.

Tom doesn't speak French as fluently as Mary does.

[[Spanish#^es-Q0721-answer|Compare the answer]]
^es-Q0721

**es-Q0722 · Choose the form**

Tom ____ habla francés con tanta fluidez como Mary.

Tom doesn't speak French as fluently as Mary does.

Choices: nadie / no / nada / nunca

[[Spanish#^es-Q0722-answer|Compare the answer]]
^es-Q0722

**es-Q0723 · Edit the changed sentence**

【nunca】 quiero ver a Tom.

I don't want to see Tom.

[[Spanish#^es-Q0723-answer|Compare the answer]]
^es-Q0723

**es-Q0724 · Build the sentence**

Arrange: ver / No / quiero / a / Tom.

I don't want to see Tom.

[[Spanish#^es-Q0724-answer|Compare the answer]]
^es-Q0724

**es-Q0725 · Write a translation**

Write this in Spanish: He never gave in to temptation.

[[Spanish#^es-Q0725-answer|Compare the answer]]
^es-Q0725

**es-Q0726 · Explain the grammar**

Él 【nunca】 cedió a la tentación.

He never gave in to temptation.

[[Spanish#^es-Q0726-answer|Compare the answer]]
^es-Q0726

**es-Q0727 · Fill the gap**

Si estuviera en su lugar ____ dejaría la escuela.

I wouldn't drop out of school if I were you.

[[Spanish#^es-Q0727-answer|Compare the answer]]
^es-Q0727

**es-Q0728 · Choose the form**

Si estuviera en su lugar ____ dejaría la escuela.

I wouldn't drop out of school if I were you.

Choices: nada / nadie / no / nunca

[[Spanish#^es-Q0728-answer|Compare the answer]]
^es-Q0728

**es-Q0729 · Edit the changed sentence**

Ya 【nunca】 trabajo.

I don't work anymore.

[[Spanish#^es-Q0729-answer|Compare the answer]]
^es-Q0729

**es-Q0730 · Build the sentence**

Arrange: Ya / trabajo. / no

I don't work anymore.

[[Spanish#^es-Q0730-answer|Compare the answer]]
^es-Q0730

**es-Q0731 · Write a translation**

Write this in Spanish: I haven't heard from him since last June.

[[Spanish#^es-Q0731-answer|Compare the answer]]
^es-Q0731

**es-Q0732 · Explain the grammar**

【No】 he oído de él desde junio pasado.

I haven't heard from him since last June.

[[Spanish#^es-Q0732-answer|Compare the answer]]
^es-Q0732

**es-Q0733 · Fill the gap**

Tú ____ eres perdedor.

You're not a loser.

[[Spanish#^es-Q0733-answer|Compare the answer]]
^es-Q0733

**es-Q0734 · Choose the form**

Tú ____ eres perdedor.

You're not a loser.

Choices: nadie / nada / nunca / no

[[Spanish#^es-Q0734-answer|Compare the answer]]
^es-Q0734

**es-Q0735 · Edit the changed sentence**

【nunca】 es tu turno.

It's not your turn.

[[Spanish#^es-Q0735-answer|Compare the answer]]
^es-Q0735

**es-Q0736 · Build the sentence**

Arrange: tu / No / es / turno.

It's not your turn.

[[Spanish#^es-Q0736-answer|Compare the answer]]
^es-Q0736

**es-Q0737 · Write a translation**

Write this in Spanish: If the sun were to rise in the west, I wouldn't change my mind.

[[Spanish#^es-Q0737-answer|Compare the answer]]
^es-Q0737

**es-Q0738 · Explain the grammar**

Si el sol saliera por el oeste, 【no】 cambiaría de idea.

If the sun were to rise in the west, I wouldn't change my mind.

[[Spanish#^es-Q0738-answer|Compare the answer]]
^es-Q0738

**es-Q0739 · Fill the gap**

Tú me desprecias, ¿o ____?

You despise me, don't you?

[[Spanish#^es-Q0739-answer|Compare the answer]]
^es-Q0739

**es-Q0740 · Choose the form**

Tú me desprecias, ¿o ____?

You despise me, don't you?

Choices: nada / no / nunca / nadie

[[Spanish#^es-Q0740-answer|Compare the answer]]
^es-Q0740

**es-Q0741 · Edit the changed sentence**

【nunca】 tires las mascarillas al suelo.

Don’t throw masks to the ground.

[[Spanish#^es-Q0741-answer|Compare the answer]]
^es-Q0741

**es-Q0742 · Build the sentence**

Arrange: al / las / tires / suelo. / No / mascarillas

Don’t throw masks to the ground.

[[Spanish#^es-Q0742-answer|Compare the answer]]
^es-Q0742

**es-Q0743 · Write a translation**

Write this in Spanish: Now, let's not get discouraged.

[[Spanish#^es-Q0743-answer|Compare the answer]]
^es-Q0743

**es-Q0744 · Explain the grammar**

【No】 nos desanimemos ahora.

Now, let's not get discouraged.

[[Spanish#^es-Q0744-answer|Compare the answer]]
^es-Q0744

**es-Q0745 · Fill the gap**

María ____ puede ver ni oír.

Mary cannot see or hear.

[[Spanish#^es-Q0745-answer|Compare the answer]]
^es-Q0745

**es-Q0746 · Choose the form**

María ____ puede ver ni oír.

Mary cannot see or hear.

Choices: nada / nunca / nadie / no

[[Spanish#^es-Q0746-answer|Compare the answer]]
^es-Q0746

**es-Q0747 · Edit the changed sentence**

Michael ya 【nunca】 vive aquí.

Michael doesn't live here anymore.

[[Spanish#^es-Q0747-answer|Compare the answer]]
^es-Q0747

**es-Q0748 · Build the sentence**

Arrange: ya / no / aquí. / vive / Michael

Michael doesn't live here anymore.

[[Spanish#^es-Q0748-answer|Compare the answer]]
^es-Q0748

**es-Q0749 · Write a translation**

Write this in Spanish: I can't understand what happened.

[[Spanish#^es-Q0749-answer|Compare the answer]]
^es-Q0749

**es-Q0750 · Explain the grammar**

【No】 puedo explicarme lo ocurrido.

I can't understand what happened.

[[Spanish#^es-Q0750-answer|Compare the answer]]
^es-Q0750


### Question words · 50 questions

**es-Q0751 · Fill the gap**

¿____ estabas enfadado conmigo?

Why were you angry with me?

[[Spanish#^es-Q0751-answer|Compare the answer]]
^es-Q0751

**es-Q0752 · Choose the form**

¿____ estabas enfadado conmigo?

Why were you angry with me?

Choices: quién / Por qué / cómo / qué

[[Spanish#^es-Q0752-answer|Compare the answer]]
^es-Q0752

**es-Q0753 · Edit the changed sentence**

¿【quién】 quieres decir con relativismo cultural?

What do you mean by cultural relativism?

[[Spanish#^es-Q0753-answer|Compare the answer]]
^es-Q0753

**es-Q0754 · Build the sentence**

Arrange: relativismo / quieres / con / decir / ¿Qué / cultural?

What do you mean by cultural relativism?

[[Spanish#^es-Q0754-answer|Compare the answer]]
^es-Q0754

**es-Q0755 · Write a translation**

Write this in Spanish: What do you know?

[[Spanish#^es-Q0755-answer|Compare the answer]]
^es-Q0755

**es-Q0756 · Explain the grammar**

¿【Qué】 saben ustedes?

What do you know?

[[Spanish#^es-Q0756-answer|Compare the answer]]
^es-Q0756

**es-Q0757 · Fill the gap**

¿____ has pagado por este ordenador?

How much have you paid for this computer?

[[Spanish#^es-Q0757-answer|Compare the answer]]
^es-Q0757

**es-Q0758 · Choose the form**

¿____ has pagado por este ordenador?

How much have you paid for this computer?

Choices: cómo / quién / qué / Cuánto

[[Spanish#^es-Q0758-answer|Compare the answer]]
^es-Q0758

**es-Q0759 · Edit the changed sentence**

¿A 【qué】 le habla Tom?

Who's Tom talking to?

[[Spanish#^es-Q0759-answer|Compare the answer]]
^es-Q0759

**es-Q0760 · Build the sentence**

Arrange: habla / Tom? / ¿A / le / quién

Who's Tom talking to?

[[Spanish#^es-Q0760-answer|Compare the answer]]
^es-Q0760

**es-Q0761 · Write a translation**

Write this in Spanish: Who else uses Tatoeba in your office?

[[Spanish#^es-Q0761-answer|Compare the answer]]
^es-Q0761

**es-Q0762 · Explain the grammar**

¿【Quién】 más usa Tatoeba en tu oficina?

Who else uses Tatoeba in your office?

[[Spanish#^es-Q0762-answer|Compare the answer]]
^es-Q0762

**es-Q0763 · Fill the gap**

Eres la única persona en ____ puedo confiar.

You're the only person that I can trust.

[[Spanish#^es-Q0763-answer|Compare the answer]]
^es-Q0763

**es-Q0764 · Choose the form**

Eres la única persona en ____ puedo confiar.

You're the only person that I can trust.

Choices: cómo / quién / qué / cuándo

[[Spanish#^es-Q0764-answer|Compare the answer]]
^es-Q0764

**es-Q0765 · Edit the changed sentence**

¿【qué】 es tu compositor favorito?

Who is your favorite composer?

[[Spanish#^es-Q0765-answer|Compare the answer]]
^es-Q0765

**es-Q0766 · Build the sentence**

Arrange: tu / favorito? / ¿Quién / es / compositor

Who is your favorite composer?

[[Spanish#^es-Q0766-answer|Compare the answer]]
^es-Q0766

**es-Q0767 · Write a translation**

Write this in Spanish: Why don't you shut the window?

[[Spanish#^es-Q0767-answer|Compare the answer]]
^es-Q0767

**es-Q0768 · Explain the grammar**

¿【Por qué】 no cierras la ventana?

Why don't you shut the window?

[[Spanish#^es-Q0768-answer|Compare the answer]]
^es-Q0768

**es-Q0769 · Fill the gap**

¿____ flor es esa?

What's that flower?

[[Spanish#^es-Q0769-answer|Compare the answer]]
^es-Q0769

**es-Q0770 · Choose the form**

¿____ flor es esa?

What's that flower?

Choices: quién / cómo / Qué / cuándo

[[Spanish#^es-Q0770-answer|Compare the answer]]
^es-Q0770

**es-Q0771 · Edit the changed sentence**

¿【qué】 no vamos a mi casa en vez de volver a la fiesta?

Instead of going back to the party, why don't we go to my place?

[[Spanish#^es-Q0771-answer|Compare the answer]]
^es-Q0771

**es-Q0772 · Build the sentence**

Arrange: a / qué / no / la / vamos / casa / en / mi / fiesta? / volver / de / vez / ¿Por / a

Instead of going back to the party, why don't we go to my place?

[[Spanish#^es-Q0772-answer|Compare the answer]]
^es-Q0772

**es-Q0773 · Write a translation**

Write this in Spanish: Do you know how to operate this machine?

[[Spanish#^es-Q0773-answer|Compare the answer]]
^es-Q0773

**es-Q0774 · Explain the grammar**

¿Vos sabés 【cómo】 operar esta máquina?

Do you know how to operate this machine?

[[Spanish#^es-Q0774-answer|Compare the answer]]
^es-Q0774

**es-Q0775 · Fill the gap**

Tom no entiende ____ usar un ordenador.

Tom doesn't understand how to use a computer.

[[Spanish#^es-Q0775-answer|Compare the answer]]
^es-Q0775

**es-Q0776 · Choose the form**

Tom no entiende ____ usar un ordenador.

Tom doesn't understand how to use a computer.

Choices: qué / quién / cómo / cuándo

[[Spanish#^es-Q0776-answer|Compare the answer]]
^es-Q0776

**es-Q0777 · Edit the changed sentence**

¿Y tú 【quién】 tal?

And you, how are you?

[[Spanish#^es-Q0777-answer|Compare the answer]]
^es-Q0777

**es-Q0778 · Build the sentence**

Arrange: qué / tal? / ¿Y / tú

And you, how are you?

[[Spanish#^es-Q0778-answer|Compare the answer]]
^es-Q0778

**es-Q0779 · Write a translation**

Write this in Spanish: What's the weather like this morning?

[[Spanish#^es-Q0779-answer|Compare the answer]]
^es-Q0779

**es-Q0780 · Explain the grammar**

¿【Qué】 tiempo hace esta mañana?

What's the weather like this morning?

[[Spanish#^es-Q0780-answer|Compare the answer]]
^es-Q0780

**es-Q0781 · Fill the gap**

¿____ le impidió venir más temprano?

What prevented you from coming earlier?

[[Spanish#^es-Q0781-answer|Compare the answer]]
^es-Q0781

**es-Q0782 · Choose the form**

¿____ le impidió venir más temprano?

What prevented you from coming earlier?

Choices: cuándo / quién / cómo / Qué

[[Spanish#^es-Q0782-answer|Compare the answer]]
^es-Q0782

**es-Q0783 · Edit the changed sentence**

¡【quién】 conjunto tan feo!

What an ugly outfit!

[[Spanish#^es-Q0783-answer|Compare the answer]]
^es-Q0783

**es-Q0784 · Build the sentence**

Arrange: tan / ¡Qué / conjunto / feo!

What an ugly outfit!

[[Spanish#^es-Q0784-answer|Compare the answer]]
^es-Q0784

**es-Q0785 · Write a translation**

Write this in Spanish: Mom, where's my handkerchief?

[[Spanish#^es-Q0785-answer|Compare the answer]]
^es-Q0785

**es-Q0786 · Explain the grammar**

Mamá, ¿【dónde】 está mi pañuelo?

Mom, where's my handkerchief?

[[Spanish#^es-Q0786-answer|Compare the answer]]
^es-Q0786

**es-Q0787 · Fill the gap**

¿A ____ quieres ir este verano?

Where do you want to go this summer?

[[Spanish#^es-Q0787-answer|Compare the answer]]
^es-Q0787

**es-Q0788 · Choose the form**

¿A ____ quieres ir este verano?

Where do you want to go this summer?

Choices: cómo / dónde / qué / quién

[[Spanish#^es-Q0788-answer|Compare the answer]]
^es-Q0788

**es-Q0789 · Edit the changed sentence**

Sé exactamente con 【qué】 planea casarse Tom.

I know exactly who Tom plans to marry.

[[Spanish#^es-Q0789-answer|Compare the answer]]
^es-Q0789

**es-Q0790 · Build the sentence**

Arrange: planea / Tom. / casarse / con / exactamente / Sé / quién

I know exactly who Tom plans to marry.

[[Spanish#^es-Q0790-answer|Compare the answer]]
^es-Q0790

**es-Q0791 · Write a translation**

Write this in Spanish: Which group is your friend in?

[[Spanish#^es-Q0791-answer|Compare the answer]]
^es-Q0791

**es-Q0792 · Explain the grammar**

¿En 【qué】 grupo está su amigo?

Which group is your friend in?

[[Spanish#^es-Q0792-answer|Compare the answer]]
^es-Q0792

**es-Q0793 · Fill the gap**

¿____ no nos vamos a cenar?

Why don't we have dinner?

[[Spanish#^es-Q0793-answer|Compare the answer]]
^es-Q0793

**es-Q0794 · Choose the form**

¿____ no nos vamos a cenar?

Why don't we have dinner?

Choices: cómo / quién / qué / Por qué

[[Spanish#^es-Q0794-answer|Compare the answer]]
^es-Q0794

**es-Q0795 · Edit the changed sentence**

Él explicó 【qué】 hacer un fuego.

He explained how to make a fire.

[[Spanish#^es-Q0795-answer|Compare the answer]]
^es-Q0795

**es-Q0796 · Build the sentence**

Arrange: fuego. / explicó / un / hacer / Él / cómo

He explained how to make a fire.

[[Spanish#^es-Q0796-answer|Compare the answer]]
^es-Q0796

**es-Q0797 · Write a translation**

Write this in Spanish: What tea do you drink? Is lemon tea okay?

[[Spanish#^es-Q0797-answer|Compare the answer]]
^es-Q0797

**es-Q0798 · Explain the grammar**

¿【Qué】 té tomas? ¿Té de limón está bien?

What tea do you drink? Is lemon tea okay?

[[Spanish#^es-Q0798-answer|Compare the answer]]
^es-Q0798

**es-Q0799 · Fill the gap**

¿Sabe Tom ____ hacer con esto?

Does Tom know what to do with this?

[[Spanish#^es-Q0799-answer|Compare the answer]]
^es-Q0799

**es-Q0800 · Choose the form**

¿Sabe Tom ____ hacer con esto?

Does Tom know what to do with this?

Choices: quién / cómo / cuándo / qué

[[Spanish#^es-Q0800-answer|Compare the answer]]
^es-Q0800


### Conditions with si · 50 questions

**es-Q0801 · Edit the changed sentence**

【cuando】 yo hubiera sabido su dirección, le habría mandado una carta.

If I had known her address, I would have written to her.

[[Spanish#^es-Q0801-answer|Compare the answer]]
^es-Q0801

**es-Q0802 · Build the sentence**

Arrange: le / habría / hubiera / carta. / yo / sabido / dirección, / mandado / una / Si / su

If I had known her address, I would have written to her.

[[Spanish#^es-Q0802-answer|Compare the answer]]
^es-Q0802

**es-Q0803 · Write a translation**

Write this in Spanish: Read it yourself, if you like.

[[Spanish#^es-Q0803-answer|Compare the answer]]
^es-Q0803

**es-Q0804 · Explain the grammar**

Léela tú misma, 【si】 quieres.

Read it yourself, if you like.

[[Spanish#^es-Q0804-answer|Compare the answer]]
^es-Q0804

**es-Q0805 · Fill the gap**

____ te agachas un poco, verás la bandera de señalización apareciendo y ocultándose de la vista.

If you just crouch a little, the signal flag can just be seen flicking in and out of sight.

[[Spanish#^es-Q0805-answer|Compare the answer]]
^es-Q0805

**es-Q0806 · Choose the form**

____ te agachas un poco, verás la bandera de señalización apareciendo y ocultándose de la vista.

If you just crouch a little, the signal flag can just be seen flicking in and out of sight.

Choices: porque / cuando / Si / aunque

[[Spanish#^es-Q0806-answer|Compare the answer]]
^es-Q0806

**es-Q0807 · Edit the changed sentence**

Me sentía gracioso, como 【cuando】 todavía siguiera soñando.

I felt as happy as if I were still dreaming.

[[Spanish#^es-Q0807-answer|Compare the answer]]
^es-Q0807

**es-Q0808 · Build the sentence**

Arrange: siguiera / soñando. / gracioso, / como / sentía / si / Me / todavía

I felt as happy as if I were still dreaming.

[[Spanish#^es-Q0808-answer|Compare the answer]]
^es-Q0808

**es-Q0809 · Write a translation**

Write this in Spanish: I feel like I've become someone else.

[[Spanish#^es-Q0809-answer|Compare the answer]]
^es-Q0809

**es-Q0810 · Explain the grammar**

Siento como 【si】 estuviera convirtiéndome en alguien más.

I feel like I've become someone else.

[[Spanish#^es-Q0810-answer|Compare the answer]]
^es-Q0810

**es-Q0811 · Fill the gap**

____ yo fuera un ave, volaría hacia ti.

Were I a bird, I would fly to you.

[[Spanish#^es-Q0811-answer|Compare the answer]]
^es-Q0811

**es-Q0812 · Choose the form**

____ yo fuera un ave, volaría hacia ti.

Were I a bird, I would fly to you.

Choices: porque / cuando / aunque / Si

[[Spanish#^es-Q0812-answer|Compare the answer]]
^es-Q0812

**es-Q0813 · Edit the changed sentence**

Tom actúa como 【cuando】 estuviera agotado.

Tom acts like he's exhausted.

[[Spanish#^es-Q0813-answer|Compare the answer]]
^es-Q0813

**es-Q0814 · Build the sentence**

Arrange: actúa / agotado. / si / Tom / como / estuviera

Tom acts like he's exhausted.

[[Spanish#^es-Q0814-answer|Compare the answer]]
^es-Q0814

**es-Q0815 · Write a translation**

Write this in Spanish: If I had been rich, I would have given you some money.

[[Spanish#^es-Q0815-answer|Compare the answer]]
^es-Q0815

**es-Q0816 · Explain the grammar**

【Si】 hubiera sido rico, os habría dado dinero.

If I had been rich, I would have given you some money.

[[Spanish#^es-Q0816-answer|Compare the answer]]
^es-Q0816

**es-Q0817 · Fill the gap**

Siento como ____ alguien nos estuviera observando.

I feel like someone is watching us.

[[Spanish#^es-Q0817-answer|Compare the answer]]
^es-Q0817

**es-Q0818 · Choose the form**

Siento como ____ alguien nos estuviera observando.

I feel like someone is watching us.

Choices: porque / si / cuando / aunque

[[Spanish#^es-Q0818-answer|Compare the answer]]
^es-Q0818

**es-Q0819 · Edit the changed sentence**

Los dioses ayudan a los que se ayudan a 【cuando】 mismos.

The gods help them that help themselves.

[[Spanish#^es-Q0819-answer|Compare the answer]]
^es-Q0819

**es-Q0820 · Build the sentence**

Arrange: ayudan / a / ayudan / Los / que / se / si / a / los / mismos. / dioses

The gods help them that help themselves.

[[Spanish#^es-Q0820-answer|Compare the answer]]
^es-Q0820

**es-Q0821 · Write a translation**

Write this in Spanish: If you eat that you will die.

[[Spanish#^es-Q0821-answer|Compare the answer]]
^es-Q0821

**es-Q0822 · Explain the grammar**

【Si】 te comes eso, morirás.

If you eat that you will die.

[[Spanish#^es-Q0822-answer|Compare the answer]]
^es-Q0822

**es-Q0823 · Fill the gap**

____ quieres evitar el colesterol, come carnes magras sin grasa.

If you want to avoid cholesterol, eat lean meat with no fat.

[[Spanish#^es-Q0823-answer|Compare the answer]]
^es-Q0823

**es-Q0824 · Choose the form**

____ quieres evitar el colesterol, come carnes magras sin grasa.

If you want to avoid cholesterol, eat lean meat with no fat.

Choices: porque / aunque / Si / cuando

[[Spanish#^es-Q0824-answer|Compare the answer]]
^es-Q0824

**es-Q0825 · Edit the changed sentence**

Él me trata como 【cuando】 fuera un extraño.

He treats me as if I am a stranger.

[[Spanish#^es-Q0825-answer|Compare the answer]]
^es-Q0825

**es-Q0826 · Build the sentence**

Arrange: como / un / me / si / extraño. / fuera / Él / trata

He treats me as if I am a stranger.

[[Spanish#^es-Q0826-answer|Compare the answer]]
^es-Q0826

**es-Q0827 · Write a translation**

Write this in Spanish: If you heat ice, it melts.

[[Spanish#^es-Q0827-answer|Compare the answer]]
^es-Q0827

**es-Q0828 · Explain the grammar**

【Si】 calientas hielo, se derrite.

If you heat ice, it melts.

[[Spanish#^es-Q0828-answer|Compare the answer]]
^es-Q0828

**es-Q0829 · Fill the gap**

Estás jugando con fuego ____ seguís andando en moto sin casco.

You're playing with fire if you insist on riding your motorcycle without a helmet on.

[[Spanish#^es-Q0829-answer|Compare the answer]]
^es-Q0829

**es-Q0830 · Choose the form**

Estás jugando con fuego ____ seguís andando en moto sin casco.

You're playing with fire if you insist on riding your motorcycle without a helmet on.

Choices: porque / si / cuando / aunque

[[Spanish#^es-Q0830-answer|Compare the answer]]
^es-Q0830

**es-Q0831 · Edit the changed sentence**

Me pregunto 【cuando】 verdaderamente se trataba de una coincidencia.

I wonder if it really was a coincidence.

[[Spanish#^es-Q0831-answer|Compare the answer]]
^es-Q0831

**es-Q0832 · Build the sentence**

Arrange: si / Me / se / trataba / coincidencia. / de / pregunto / verdaderamente / una

I wonder if it really was a coincidence.

[[Spanish#^es-Q0832-answer|Compare the answer]]
^es-Q0832

**es-Q0833 · Write a translation**

Write this in Spanish: Don't come near to the bulldog in case it bites.

[[Spanish#^es-Q0833-answer|Compare the answer]]
^es-Q0833

**es-Q0834 · Explain the grammar**

No te acerques al bulldog por 【si】 muerde.

Don't come near to the bulldog in case it bites.

[[Spanish#^es-Q0834-answer|Compare the answer]]
^es-Q0834

**es-Q0835 · Fill the gap**

Avíseme ____ le puedo dar alguna información adicional, o si desea contactarme para hacer alguna pregunta.

Please let me know if I can provide you with any further information, or if you would like to contact me for questions.

[[Spanish#^es-Q0835-answer|Compare the answer]]
^es-Q0835

**es-Q0836 · Choose the form**

Avíseme ____ le puedo dar alguna información adicional, o si desea contactarme para hacer alguna pregunta.

Please let me know if I can provide you with any further information, or if you would like to contact me for questions.

Choices: porque / cuando / aunque / si

[[Spanish#^es-Q0836-answer|Compare the answer]]
^es-Q0836

**es-Q0837 · Edit the changed sentence**

Me preguntó 【cuando】 tenía experiencia en esa área, y le dije que no.

He asked me if I had experience in this area, and I said no.

[[Spanish#^es-Q0837-answer|Compare the answer]]
^es-Q0837

**es-Q0838 · Build the sentence**

Arrange: y / en / experiencia / le / si / Me / área, / dije / preguntó / esa / que / no. / tenía

He asked me if I had experience in this area, and I said no.

[[Spanish#^es-Q0838-answer|Compare the answer]]
^es-Q0838

**es-Q0839 · Write a translation**

Write this in Spanish: I'm not sure if you're interested, but I translated your article into French.

[[Spanish#^es-Q0839-answer|Compare the answer]]
^es-Q0839

**es-Q0840 · Explain the grammar**

No sé 【si】 le interesa, pero traduje su artículo al francés.

I'm not sure if you're interested, but I translated your article into French.

[[Spanish#^es-Q0840-answer|Compare the answer]]
^es-Q0840

**es-Q0841 · Fill the gap**

____ tú quieres ir, iremos.

If you want to go, we'll go.

[[Spanish#^es-Q0841-answer|Compare the answer]]
^es-Q0841

**es-Q0842 · Choose the form**

____ tú quieres ir, iremos.

If you want to go, we'll go.

Choices: aunque / cuando / porque / Si

[[Spanish#^es-Q0842-answer|Compare the answer]]
^es-Q0842

**es-Q0843 · Edit the changed sentence**

No sé 【cuando】 he respondido a tu pregunta.

I don't know if I've answered your question.

[[Spanish#^es-Q0843-answer|Compare the answer]]
^es-Q0843

**es-Q0844 · Build the sentence**

Arrange: he / sé / No / respondido / tu / pregunta. / si / a

I don't know if I've answered your question.

[[Spanish#^es-Q0844-answer|Compare the answer]]
^es-Q0844

**es-Q0845 · Write a translation**

Write this in Spanish: If someone criticize you, it's because you have something that he will never have.

[[Spanish#^es-Q0845-answer|Compare the answer]]
^es-Q0845

**es-Q0846 · Explain the grammar**

【Si】 alguien te critica, es porque tu tienes algo que él nunca tendrá.

If someone criticize you, it's because you have something that he will never have.

[[Spanish#^es-Q0846-answer|Compare the answer]]
^es-Q0846

**es-Q0847 · Fill the gap**

____ querés, puedo volver.

If you want, I can come back.

[[Spanish#^es-Q0847-answer|Compare the answer]]
^es-Q0847

**es-Q0848 · Choose the form**

____ querés, puedo volver.

If you want, I can come back.

Choices: aunque / cuando / Si / porque

[[Spanish#^es-Q0848-answer|Compare the answer]]
^es-Q0848

**es-Q0849 · Edit the changed sentence**

【cuando】 el medicamento no surte efecto, quizá deberíamos aumentar la dosis.

If the medicine isn't working, maybe we should up the dosage.

[[Spanish#^es-Q0849-answer|Compare the answer]]
^es-Q0849

**es-Q0850 · Build the sentence**

Arrange: deberíamos / surte / dosis. / efecto, / aumentar / la / el / medicamento / no / quizá / Si

If the medicine isn't working, maybe we should up the dosage.

[[Spanish#^es-Q0850-answer|Compare the answer]]
^es-Q0850


### Cause and concession · 50 questions

**es-Q0851 · Write a translation**

Write this in Spanish: People don't like working with Tom because he's hard to get along with.

[[Spanish#^es-Q0851-answer|Compare the answer]]
^es-Q0851

**es-Q0852 · Explain the grammar**

A la gente no le gusta trabajar con Tom 【porque】 es difícil llevarse bien con él.

People don't like working with Tom because he's hard to get along with.

[[Spanish#^es-Q0852-answer|Compare the answer]]
^es-Q0852

**es-Q0853 · Fill the gap**

____ estamos todos de acuerdo, empecemos la reunión.

Now we all agree, let's start the meeting.

[[Spanish#^es-Q0853-answer|Compare the answer]]
^es-Q0853

**es-Q0854 · Choose the form**

____ estamos todos de acuerdo, empecemos la reunión.

Now we all agree, let's start the meeting.

Choices: Ya que / aunque / por eso / porque

[[Spanish#^es-Q0854-answer|Compare the answer]]
^es-Q0854

**es-Q0855 · Edit the changed sentence**

No te tienes que sentir mal 【porque】.

You don't have to feel bad for that.

[[Spanish#^es-Q0855-answer|Compare the answer]]
^es-Q0855

**es-Q0856 · Build the sentence**

Arrange: tienes / eso. / mal / No / que / por / sentir / te

You don't have to feel bad for that.

[[Spanish#^es-Q0856-answer|Compare the answer]]
^es-Q0856

**es-Q0857 · Write a translation**

Write this in Spanish: That's why he got angry.

[[Spanish#^es-Q0857-answer|Compare the answer]]
^es-Q0857

**es-Q0858 · Explain the grammar**

Es 【por eso】 que él se enojó.

That's why he got angry.

[[Spanish#^es-Q0858-answer|Compare the answer]]
^es-Q0858

**es-Q0859 · Fill the gap**

____ estaba ocupada, ayudé a mi madre.

I helped my mother even though I was busy.

[[Spanish#^es-Q0859-answer|Compare the answer]]
^es-Q0859

**es-Q0860 · Choose the form**

____ estaba ocupada, ayudé a mi madre.

I helped my mother even though I was busy.

Choices: por eso / porque / sin embargo / Aunque

[[Spanish#^es-Q0860-answer|Compare the answer]]
^es-Q0860

**es-Q0861 · Edit the changed sentence**

Hay que alistarse temprano 【aunque】 el tren no espera.

We'd better get ready early because the train won't wait.

[[Spanish#^es-Q0861-answer|Compare the answer]]
^es-Q0861

**es-Q0862 · Build the sentence**

Arrange: no / Hay / alistarse / temprano / espera. / tren / porque / que / el

We'd better get ready early because the train won't wait.

[[Spanish#^es-Q0862-answer|Compare the answer]]
^es-Q0862

**es-Q0863 · Write a translation**

Write this in Spanish: I am going to go to sleep right away because I'm very sleepy.

[[Spanish#^es-Q0863-answer|Compare the answer]]
^es-Q0863

**es-Q0864 · Explain the grammar**

Me voy a dormir de inmediato 【porque】 estoy con mucho sueño.

I am going to go to sleep right away because I'm very sleepy.

[[Spanish#^es-Q0864-answer|Compare the answer]]
^es-Q0864

**es-Q0865 · Fill the gap**

Esta chica sonríe continuamente, ____ no es feliz.

This girl is always smiling, but she's not happy.

[[Spanish#^es-Q0865-answer|Compare the answer]]
^es-Q0865

**es-Q0866 · Choose the form**

Esta chica sonríe continuamente, ____ no es feliz.

This girl is always smiling, but she's not happy.

Choices: aunque / porque / sin embargo / por eso

[[Spanish#^es-Q0866-answer|Compare the answer]]
^es-Q0866

**es-Q0867 · Edit the changed sentence**

Agradecimos a Tomás 【porque】.

We thanked Tom for that.

[[Spanish#^es-Q0867-answer|Compare the answer]]
^es-Q0867

**es-Q0868 · Build the sentence**

Arrange: por / Agradecimos / eso. / a / Tomás

We thanked Tom for that.

[[Spanish#^es-Q0868-answer|Compare the answer]]
^es-Q0868

**es-Q0869 · Write a translation**

Write this in Spanish: Even though her vet told her not to, she continued to feed her dog raw vegetables.

[[Spanish#^es-Q0869-answer|Compare the answer]]
^es-Q0869

**es-Q0870 · Explain the grammar**

【Aunque】 su veterinario le dijo que no, ella continuó dando de comer a su perro verduras crudas.

Even though her vet told her not to, she continued to feed her dog raw vegetables.

[[Spanish#^es-Q0870-answer|Compare the answer]]
^es-Q0870

**es-Q0871 · Fill the gap**

Tengo que irme ____ he quedado con un amigo.

I have to go off because I have an appointment with a friend.

[[Spanish#^es-Q0871-answer|Compare the answer]]
^es-Q0871

**es-Q0872 · Choose the form**

Tengo que irme ____ he quedado con un amigo.

I have to go off because I have an appointment with a friend.

Choices: porque / sin embargo / por eso / aunque

[[Spanish#^es-Q0872-answer|Compare the answer]]
^es-Q0872

**es-Q0873 · Edit the changed sentence**

Se me pegaron las sábanas 【aunque】 mi alarma no sonó.

I overslept because my alarm didn't go off.

[[Spanish#^es-Q0873-answer|Compare the answer]]
^es-Q0873

**es-Q0874 · Build the sentence**

Arrange: sonó. / me / pegaron / porque / las / no / Se / mi / alarma / sábanas

I overslept because my alarm didn't go off.

[[Spanish#^es-Q0874-answer|Compare the answer]]
^es-Q0874

**es-Q0875 · Write a translation**

Write this in Spanish: Even if you make great efforts, you won't be able to achieve it.

[[Spanish#^es-Q0875-answer|Compare the answer]]
^es-Q0875

**es-Q0876 · Explain the grammar**

【Aunque】 hagas un gran esfuerzo, no serás capaz de conseguirlo.

Even if you make great efforts, you won't be able to achieve it.

[[Spanish#^es-Q0876-answer|Compare the answer]]
^es-Q0876

**es-Q0877 · Fill the gap**

Ella abrió la ventana ____ le dije que no lo hiciera.

She opened the window, even though I told her not to.

[[Spanish#^es-Q0877-answer|Compare the answer]]
^es-Q0877

**es-Q0878 · Choose the form**

Ella abrió la ventana ____ le dije que no lo hiciera.

She opened the window, even though I told her not to.

Choices: sin embargo / aunque / por eso / porque

[[Spanish#^es-Q0878-answer|Compare the answer]]
^es-Q0878

**es-Q0879 · Edit the changed sentence**

Tom se interesó por la música 【aunque】 su vecino tenía harto de músico.

Tom became interested in music because his neighbor was quite a musician.

[[Spanish#^es-Q0879-answer|Compare the answer]]
^es-Q0879

**es-Q0880 · Build the sentence**

Arrange: vecino / se / porque / la / por / músico. / harto / su / tenía / interesó / música / de / Tom

Tom became interested in music because his neighbor was quite a musician.

[[Spanish#^es-Q0880-answer|Compare the answer]]
^es-Q0880

**es-Q0881 · Write a translation**

Write this in Spanish: Is that why you won't help Tom?

[[Spanish#^es-Q0881-answer|Compare the answer]]
^es-Q0881

**es-Q0882 · Explain the grammar**

¿【Por eso】 no ayudarás a Tom?

Is that why you won't help Tom?

[[Spanish#^es-Q0882-answer|Compare the answer]]
^es-Q0882

**es-Q0883 · Fill the gap**

Nosotros llamamos "Doremon" a nuestro instructor, ____ él es gordo.

We call our teacher "Doraemon" because he's fat.

[[Spanish#^es-Q0883-answer|Compare the answer]]
^es-Q0883

**es-Q0884 · Choose the form**

Nosotros llamamos "Doremon" a nuestro instructor, ____ él es gordo.

We call our teacher "Doraemon" because he's fat.

Choices: por eso / porque / sin embargo / aunque

[[Spanish#^es-Q0884-answer|Compare the answer]]
^es-Q0884

**es-Q0885 · Edit the changed sentence**

【aunque】 ningún hombre sabe hablar mi idioma.

Because no man can speak my language.

[[Spanish#^es-Q0885-answer|Compare the answer]]
^es-Q0885

**es-Q0886 · Build the sentence**

Arrange: mi / sabe / ningún / hablar / Porque / idioma. / hombre

Because no man can speak my language.

[[Spanish#^es-Q0886-answer|Compare the answer]]
^es-Q0886

**es-Q0887 · Write a translation**

Write this in Spanish: She said absolutely nothing, and yet I guessed it all.

[[Spanish#^es-Q0887-answer|Compare the answer]]
^es-Q0887

**es-Q0888 · Explain the grammar**

Ella no dijo nada de nada, 【sin embargo】 yo adiviné todo.

She said absolutely nothing, and yet I guessed it all.

[[Spanish#^es-Q0888-answer|Compare the answer]]
^es-Q0888

**es-Q0889 · Fill the gap**

No tengo ganas de irme, ____ aquí estoy sentado muy cómodamente.

I don't feel like going, because I am sitting here quite comfortably.

[[Spanish#^es-Q0889-answer|Compare the answer]]
^es-Q0889

**es-Q0890 · Choose the form**

No tengo ganas de irme, ____ aquí estoy sentado muy cómodamente.

I don't feel like going, because I am sitting here quite comfortably.

Choices: sin embargo / porque / aunque / por eso

[[Spanish#^es-Q0890-answer|Compare the answer]]
^es-Q0890

**es-Q0891 · Edit the changed sentence**

No te iguales a tu hermano 【aunque】 vale más que tú.

Don't compare yourself with your brother because he's a better man than you.

[[Spanish#^es-Q0891-answer|Compare the answer]]
^es-Q0891

**es-Q0892 · Build the sentence**

Arrange: tú. / te / No / porque / a / iguales / más / hermano / tu / que / vale

Don't compare yourself with your brother because he's a better man than you.

[[Spanish#^es-Q0892-answer|Compare the answer]]
^es-Q0892

**es-Q0893 · Write a translation**

Write this in Spanish: Don't go picking the flowers in the flower bed, or else you'll be caught.

[[Spanish#^es-Q0893-answer|Compare the answer]]
^es-Q0893

**es-Q0894 · Explain the grammar**

No vayas a por flores del parterre 【porque】 te pillarán.

Don't go picking the flowers in the flower bed, or else you'll be caught.

[[Spanish#^es-Q0894-answer|Compare the answer]]
^es-Q0894

**es-Q0895 · Fill the gap**

Lo de ellos es un matrimonio por conveniencia, ____, funciona.

Theirs is a marriage of convenience, however, it works.

[[Spanish#^es-Q0895-answer|Compare the answer]]
^es-Q0895

**es-Q0896 · Choose the form**

Lo de ellos es un matrimonio por conveniencia, ____, funciona.

Theirs is a marriage of convenience, however, it works.

Choices: porque / sin embargo / aunque / por eso

[[Spanish#^es-Q0896-answer|Compare the answer]]
^es-Q0896

**es-Q0897 · Edit the changed sentence**

Hoy estaba cansado, 【porque】 me fui temprano a la cama.

I was tired today so I went to bed early.

[[Spanish#^es-Q0897-answer|Compare the answer]]
^es-Q0897

**es-Q0898 · Build the sentence**

Arrange: por / temprano / Hoy / me / estaba / eso / cama. / cansado, / la / a / fui

I was tired today so I went to bed early.

[[Spanish#^es-Q0898-answer|Compare the answer]]
^es-Q0898

**es-Q0899 · Write a translation**

Write this in Spanish: That's why I came to talk to you.

[[Spanish#^es-Q0899-answer|Compare the answer]]
^es-Q0899

**es-Q0900 · Explain the grammar**

Es 【por eso】 que vine a hablar contigo.

That's why I came to talk to you.

[[Spanish#^es-Q0900-answer|Compare the answer]]
^es-Q0900


### Contractions and prepositions · 50 questions

**es-Q0901 · Fill the gap**

Pruébalo ____ favor.

Please have a try.

[[Spanish#^es-Q0901-answer|Compare the answer]]
^es-Q0901

**es-Q0902 · Choose the form**

Pruébalo ____ favor.

Please have a try.

Choices: del / para / al / por

[[Spanish#^es-Q0902-answer|Compare the answer]]
^es-Q0902

**es-Q0903 · Edit the changed sentence**

¿Estarías de acuerdo 【al】 eso?

Would you agree with that?

[[Spanish#^es-Q0903-answer|Compare the answer]]
^es-Q0903

**es-Q0904 · Build the sentence**

Arrange: con / ¿Estarías / de / acuerdo / eso?

Would you agree with that?

[[Spanish#^es-Q0904-answer|Compare the answer]]
^es-Q0904

**es-Q0905 · Write a translation**

Write this in Spanish: I will play with Naoko this afternoon.

[[Spanish#^es-Q0905-answer|Compare the answer]]
^es-Q0905

**es-Q0906 · Explain the grammar**

Esta tarde voy a jugar 【con】 Naoko.

I will play with Naoko this afternoon.

[[Spanish#^es-Q0906-answer|Compare the answer]]
^es-Q0906

**es-Q0907 · Fill the gap**

Deberías presentarte ____ alcalde.

You should run for mayor.

[[Spanish#^es-Q0907-answer|Compare the answer]]
^es-Q0907

**es-Q0908 · Choose the form**

Deberías presentarte ____ alcalde.

You should run for mayor.

Choices: para / del / por / al

[[Spanish#^es-Q0908-answer|Compare the answer]]
^es-Q0908

**es-Q0909 · Edit the changed sentence**

Hagámonos compañía 【al】 un rato.

Let's keep each other company for a while.

[[Spanish#^es-Q0909-answer|Compare the answer]]
^es-Q0909

**es-Q0910 · Build the sentence**

Arrange: por / un / Hagámonos / rato. / compañía

Let's keep each other company for a while.

[[Spanish#^es-Q0910-answer|Compare the answer]]
^es-Q0910

**es-Q0911 · Write a translation**

Write this in Spanish: I'll sleep on it.

[[Spanish#^es-Q0911-answer|Compare the answer]]
^es-Q0911

**es-Q0912 · Explain the grammar**

Lo consultaré 【con】 la almohada.

I'll sleep on it.

[[Spanish#^es-Q0912-answer|Compare the answer]]
^es-Q0912

**es-Q0913 · Fill the gap**

Él prometió recompensarme ____ mi trabajo.

He promised to reward me for my work.

[[Spanish#^es-Q0913-answer|Compare the answer]]
^es-Q0913

**es-Q0914 · Choose the form**

Él prometió recompensarme ____ mi trabajo.

He promised to reward me for my work.

Choices: por / del / al / para

[[Spanish#^es-Q0914-answer|Compare the answer]]
^es-Q0914

**es-Q0915 · Edit the changed sentence**

Yo te aliento a venir y arrodillarte conmigo 【del】 pie de la Cruz del Calvario y ser lavados por la sangre de Nuestro Salvador Jesucristo.

I encourage you to come and kneel with me at the foot of Calvary's Cross and be washed in the blood of Our Savior Jesus Christ.

[[Spanish#^es-Q0915-answer|Compare the answer]]
^es-Q0915

**es-Q0916 · Build the sentence**

Arrange: arrodillarte / Nuestro / Calvario / Jesucristo. / la / Yo / del / al / venir / la / te / conmigo / aliento / y / y / por / de / pie / Cruz / lavados / sangre / Salvador / de / ser / a

I encourage you to come and kneel with me at the foot of Calvary's Cross and be washed in the blood of Our Savior Jesus Christ.

[[Spanish#^es-Q0916-answer|Compare the answer]]
^es-Q0916

**es-Q0917 · Write a translation**

Write this in Spanish: Tom climbed over the fence.

[[Spanish#^es-Q0917-answer|Compare the answer]]
^es-Q0917

**es-Q0918 · Explain the grammar**

Tom trepó 【por】 encima de la cerca.

Tom climbed over the fence.

[[Spanish#^es-Q0918-answer|Compare the answer]]
^es-Q0918

**es-Q0919 · Fill the gap**

¿Es ____ mí?

Is that for me?

[[Spanish#^es-Q0919-answer|Compare the answer]]
^es-Q0919

**es-Q0920 · Choose the form**

¿Es ____ mí?

Is that for me?

Choices: del / para / por / al

[[Spanish#^es-Q0920-answer|Compare the answer]]
^es-Q0920

**es-Q0921 · Edit the changed sentence**

¿Habla usted 【al】 franqueza?

Are you speaking frankly?

[[Spanish#^es-Q0921-answer|Compare the answer]]
^es-Q0921

**es-Q0922 · Build the sentence**

Arrange: ¿Habla / con / usted / franqueza?

Are you speaking frankly?

[[Spanish#^es-Q0922-answer|Compare the answer]]
^es-Q0922

**es-Q0923 · Write a translation**

Write this in Spanish: I need to exchange dollars for pesos.

[[Spanish#^es-Q0923-answer|Compare the answer]]
^es-Q0923

**es-Q0924 · Explain the grammar**

Necesito cambiar dólares 【por】 pesos.

I need to exchange dollars for pesos.

[[Spanish#^es-Q0924-answer|Compare the answer]]
^es-Q0924

**es-Q0925 · Fill the gap**

Nuevamente quiero agradecerte ____ creerme.

I want to thank you again for believing me.

[[Spanish#^es-Q0925-answer|Compare the answer]]
^es-Q0925

**es-Q0926 · Choose the form**

Nuevamente quiero agradecerte ____ creerme.

I want to thank you again for believing me.

Choices: del / para / al / por

[[Spanish#^es-Q0926-answer|Compare the answer]]
^es-Q0926

**es-Q0927 · Edit the changed sentence**

Él esperaba 【al】 ansias la cita de esa noche.

He was looking forward to that evening's date.

[[Spanish#^es-Q0927-answer|Compare the answer]]
^es-Q0927

**es-Q0928 · Build the sentence**

Arrange: de / la / esperaba / noche. / ansias / cita / esa / Él / con

He was looking forward to that evening's date.

[[Spanish#^es-Q0928-answer|Compare the answer]]
^es-Q0928

**es-Q0929 · Write a translation**

Write this in Spanish: Thanks for explaining it to me.

[[Spanish#^es-Q0929-answer|Compare the answer]]
^es-Q0929

**es-Q0930 · Explain the grammar**

Gracias 【por】 explicármelo.

Thanks for explaining it to me.

[[Spanish#^es-Q0930-answer|Compare the answer]]
^es-Q0930

**es-Q0931 · Fill the gap**

Los italianos hacen una gran comida dos veces ____ día.

Italians eat a big meal twice a day.

[[Spanish#^es-Q0931-answer|Compare the answer]]
^es-Q0931

**es-Q0932 · Choose the form**

Los italianos hacen una gran comida dos veces ____ día.

Italians eat a big meal twice a day.

Choices: por / para / al / del

[[Spanish#^es-Q0932-answer|Compare the answer]]
^es-Q0932

**es-Q0933 · Edit the changed sentence**

Sacá un vaso limpio 【al】 aparador.

Take a clean glass from the cupboard.

[[Spanish#^es-Q0933-answer|Compare the answer]]
^es-Q0933

**es-Q0934 · Build the sentence**

Arrange: aparador. / Sacá / limpio / un / del / vaso

Take a clean glass from the cupboard.

[[Spanish#^es-Q0934-answer|Compare the answer]]
^es-Q0934

**es-Q0935 · Write a translation**

Write this in Spanish: When you encounter difficulties, friends can help you deal with them.

[[Spanish#^es-Q0935-answer|Compare the answer]]
^es-Q0935

**es-Q0936 · Explain the grammar**

Cuando te encuentres 【con】 dificultades, los amigos pueden ayudarte a sobrellevarlas.

When you encounter difficulties, friends can help you deal with them.

[[Spanish#^es-Q0936-answer|Compare the answer]]
^es-Q0936

**es-Q0937 · Fill the gap**

Yo no sé como tratar ____ niños.

I don't know how to handle children.

[[Spanish#^es-Q0937-answer|Compare the answer]]
^es-Q0937

**es-Q0938 · Choose the form**

Yo no sé como tratar ____ niños.

I don't know how to handle children.

Choices: del / con / para / al

[[Spanish#^es-Q0938-answer|Compare the answer]]
^es-Q0938

**es-Q0939 · Edit the changed sentence**

Tom y Mary podrían aprender mucho el uno 【al】 otro.

Tom and Mary could learn a lot from each other.

[[Spanish#^es-Q0939-answer|Compare the answer]]
^es-Q0939

**es-Q0940 · Build the sentence**

Arrange: el / aprender / Tom / y / podrían / mucho / Mary / otro. / del / uno

Tom and Mary could learn a lot from each other.

[[Spanish#^es-Q0940-answer|Compare the answer]]
^es-Q0940

**es-Q0941 · Write a translation**

Write this in Spanish: Everybody without exception must take the test.

[[Spanish#^es-Q0941-answer|Compare the answer]]
^es-Q0941

**es-Q0942 · Explain the grammar**

Todo el mundo 【sin】 excepción debe realizar la prueba.

Everybody without exception must take the test.

[[Spanish#^es-Q0942-answer|Compare the answer]]
^es-Q0942

**es-Q0943 · Fill the gap**

Él es rico ____ duda, pero no confío en él.

He is without a doubt rich, but I don't trust him.

[[Spanish#^es-Q0943-answer|Compare the answer]]
^es-Q0943

**es-Q0944 · Choose the form**

Él es rico ____ duda, pero no confío en él.

He is without a doubt rich, but I don't trust him.

Choices: para / al / del / sin

[[Spanish#^es-Q0944-answer|Compare the answer]]
^es-Q0944

**es-Q0945 · Edit the changed sentence**

Es la mejor casa 【al】 pueblo.

It's the best house in town.

[[Spanish#^es-Q0945-answer|Compare the answer]]
^es-Q0945

**es-Q0946 · Build the sentence**

Arrange: del / Es / casa / mejor / pueblo. / la

It's the best house in town.

[[Spanish#^es-Q0946-answer|Compare the answer]]
^es-Q0946

**es-Q0947 · Write a translation**

Write this in Spanish: Talk to her.

[[Spanish#^es-Q0947-answer|Compare the answer]]
^es-Q0947

**es-Q0948 · Explain the grammar**

Hable 【con】 ella.

Talk to her.

[[Spanish#^es-Q0948-answer|Compare the answer]]
^es-Q0948

**es-Q0949 · Fill the gap**

Ella toca piano ____ las tardes o las noches.

She practices the piano in the afternoon or in the evening.

[[Spanish#^es-Q0949-answer|Compare the answer]]
^es-Q0949

**es-Q0950 · Choose the form**

Ella toca piano ____ las tardes o las noches.

She practices the piano in the afternoon or in the evening.

Choices: del / al / para / por

[[Spanish#^es-Q0950-answer|Compare the answer]]
^es-Q0950


### Comparison · 50 questions

**es-Q0951 · Edit the changed sentence**

Cuanto 【más】 mejor.

The worse the better.

[[Spanish#^es-Q0951-answer|Compare the answer]]
^es-Q0951

**es-Q0952 · Build the sentence**

Arrange: Cuanto / mejor. / peor

The worse the better.

[[Spanish#^es-Q0952-answer|Compare the answer]]
^es-Q0952

**es-Q0953 · Write a translation**

Write this in Spanish: I know as little as you do.

[[Spanish#^es-Q0953-answer|Compare the answer]]
^es-Q0953

**es-Q0954 · Explain the grammar**

Sé 【tan】 poco como tú.

I know as little as you do.

[[Spanish#^es-Q0954-answer|Compare the answer]]
^es-Q0954

**es-Q0955 · Fill the gap**

Hasta un niño chico sabe algo ____ simple.

The smallest child knows such a simple thing.

[[Spanish#^es-Q0955-answer|Compare the answer]]
^es-Q0955

**es-Q0956 · Choose the form**

Hasta un niño chico sabe algo ____ simple.

The smallest child knows such a simple thing.

Choices: menos / más / tan / mejor

[[Spanish#^es-Q0956-answer|Compare the answer]]
^es-Q0956

**es-Q0957 · Edit the changed sentence**

¿Necesitamos 【menos】 inflación?

Do we need more inflation?

[[Spanish#^es-Q0957-answer|Compare the answer]]
^es-Q0957

**es-Q0958 · Build the sentence**

Arrange: más / inflación? / ¿Necesitamos

Do we need more inflation?

[[Spanish#^es-Q0958-answer|Compare the answer]]
^es-Q0958

**es-Q0959 · Write a translation**

Write this in Spanish: Insist on the best.

[[Spanish#^es-Q0959-answer|Compare the answer]]
^es-Q0959

**es-Q0960 · Explain the grammar**

Exige lo 【mejor】.

Insist on the best.

[[Spanish#^es-Q0960-answer|Compare the answer]]
^es-Q0960

**es-Q0961 · Fill the gap**

El final es mucho ____ interesante.

The ending is much more interesting.

[[Spanish#^es-Q0961-answer|Compare the answer]]
^es-Q0961

**es-Q0962 · Choose the form**

El final es mucho ____ interesante.

The ending is much more interesting.

Choices: más / menos / mejor / peor

[[Spanish#^es-Q0962-answer|Compare the answer]]
^es-Q0962

**es-Q0963 · Edit the changed sentence**

No la veré 【menos】.

I'll see her no more.

[[Spanish#^es-Q0963-answer|Compare the answer]]
^es-Q0963

**es-Q0964 · Build the sentence**

Arrange: veré / más. / la / No

I'll see her no more.

[[Spanish#^es-Q0964-answer|Compare the answer]]
^es-Q0964

**es-Q0965 · Write a translation**

Write this in Spanish: The secret of influencing people lies not so much in being a good talker as in being a good listener.

[[Spanish#^es-Q0965-answer|Compare the answer]]
^es-Q0965

**es-Q0966 · Explain the grammar**

El secreto de influenciar a la gente no recae 【tanto】 en ser un buen orador como en ser un buen oidor.

The secret of influencing people lies not so much in being a good talker as in being a good listener.

[[Spanish#^es-Q0966-answer|Compare the answer]]
^es-Q0966

**es-Q0967 · Fill the gap**

Ambos, Tom y Mary, ____ sólo miran a John.

Tom and Mary both just stare at John.

[[Spanish#^es-Q0967-answer|Compare the answer]]
^es-Q0967

**es-Q0968 · Choose the form**

Ambos, Tom y Mary, ____ sólo miran a John.

Tom and Mary both just stare at John.

Choices: mejor / tan / más / menos

[[Spanish#^es-Q0968-answer|Compare the answer]]
^es-Q0968

**es-Q0969 · Edit the changed sentence**

No puedo seguirlo, ¿puede dictar 【menos】 despacio?

I can't keep up with you. Could you dictate a bit slower?

[[Spanish#^es-Q0969-answer|Compare the answer]]
^es-Q0969

**es-Q0970 · Build the sentence**

Arrange: ¿puede / dictar / No / despacio? / más / seguirlo, / puedo

I can't keep up with you. Could you dictate a bit slower?

[[Spanish#^es-Q0970-answer|Compare the answer]]
^es-Q0970

**es-Q0971 · Write a translation**

Write this in Spanish: Ben's not as young as he looks.

[[Spanish#^es-Q0971-answer|Compare the answer]]
^es-Q0971

**es-Q0972 · Explain the grammar**

Ben no es 【tan】 joven como aparenta.

Ben's not as young as he looks.

[[Spanish#^es-Q0972-answer|Compare the answer]]
^es-Q0972

**es-Q0973 · Fill the gap**

Por lo ____ la física cuántica revela una unidad básica del universo.

Quantum physics thus reveals a basic oneness of the universe.

[[Spanish#^es-Q0973-answer|Compare the answer]]
^es-Q0973

**es-Q0974 · Choose the form**

Por lo ____ la física cuántica revela una unidad básica del universo.

Quantum physics thus reveals a basic oneness of the universe.

Choices: menos / mejor / tanto / más

[[Spanish#^es-Q0974-answer|Compare the answer]]
^es-Q0974

**es-Q0975 · Edit the changed sentence**

Me parece que las patinetas en general son 【menos】 baratas que los patines.

I think skateboards are usually cheaper than rollerblades.

[[Spanish#^es-Q0975-answer|Compare the answer]]
^es-Q0975

**es-Q0976 · Build the sentence**

Arrange: que / general / Me / las / los / parece / que / son / baratas / patinetas / patines. / más / en

I think skateboards are usually cheaper than rollerblades.

[[Spanish#^es-Q0976-answer|Compare the answer]]
^es-Q0976

**es-Q0977 · Write a translation**

Write this in Spanish: Sometimes, questions provide us with more information than answers.

[[Spanish#^es-Q0977-answer|Compare the answer]]
^es-Q0977

**es-Q0978 · Explain the grammar**

A veces, las preguntas nos proporcionan 【más】 información que las respuestas.

Sometimes, questions provide us with more information than answers.

[[Spanish#^es-Q0978-answer|Compare the answer]]
^es-Q0978

**es-Q0979 · Fill the gap**

Pienso que es poco saludable comer ____ de 20 naranjas en un día.

I think it's unhealthy to eat more than 20 oranges a day.

[[Spanish#^es-Q0979-answer|Compare the answer]]
^es-Q0979

**es-Q0980 · Choose the form**

Pienso que es poco saludable comer ____ de 20 naranjas en un día.

I think it's unhealthy to eat more than 20 oranges a day.

Choices: más / peor / mejor / menos

[[Spanish#^es-Q0980-answer|Compare the answer]]
^es-Q0980

**es-Q0981 · Edit the changed sentence**

Mi amor por ti no me deja contarte todo. Es 【más】 no contar algunas cosas.

My love for you won't let me tell you everything. Some things are better left unsaid.

[[Spanish#^es-Q0981-answer|Compare the answer]]
^es-Q0981

**es-Q0982 · Build the sentence**

Arrange: ti / mejor / cosas. / no / Es / contarte / algunas / todo. / me / por / deja / contar / no / Mi / amor

My love for you won't let me tell you everything. Some things are better left unsaid.

[[Spanish#^es-Q0982-answer|Compare the answer]]
^es-Q0982

**es-Q0983 · Write a translation**

Write this in Spanish: Maybe later.

[[Spanish#^es-Q0983-answer|Compare the answer]]
^es-Q0983

**es-Q0984 · Explain the grammar**

Quizá 【más】 tarde.

Maybe later.

[[Spanish#^es-Q0984-answer|Compare the answer]]
^es-Q0984

**es-Q0985 · Fill the gap**

Fumar te hace ____ daño que bien.

Smoking does you more harm than good.

[[Spanish#^es-Q0985-answer|Compare the answer]]
^es-Q0985

**es-Q0986 · Choose the form**

Fumar te hace ____ daño que bien.

Smoking does you more harm than good.

Choices: peor / mejor / menos / más

[[Spanish#^es-Q0986-answer|Compare the answer]]
^es-Q0986

**es-Q0987 · Edit the changed sentence**

Tom tiene 【menos】 corazón que cabeza.

Tom has more heart than brains.

[[Spanish#^es-Q0987-answer|Compare the answer]]
^es-Q0987

**es-Q0988 · Build the sentence**

Arrange: que / corazón / cabeza. / más / Tom / tiene

Tom has more heart than brains.

[[Spanish#^es-Q0988-answer|Compare the answer]]
^es-Q0988

**es-Q0989 · Write a translation**

Write this in Spanish: The Great Wall of China is more than 5,500 miles long.

[[Spanish#^es-Q0989-answer|Compare the answer]]
^es-Q0989

**es-Q0990 · Explain the grammar**

La Gran Muralla China tiene 【más】 de 5,500 millas de largo.

The Great Wall of China is more than 5,500 miles long.

[[Spanish#^es-Q0990-answer|Compare the answer]]
^es-Q0990

**es-Q0991 · Fill the gap**

Mi ____ amigo está en Roma en este momento.

My best friend is in Rome now.

[[Spanish#^es-Q0991-answer|Compare the answer]]
^es-Q0991

**es-Q0992 · Choose the form**

Mi ____ amigo está en Roma en este momento.

My best friend is in Rome now.

Choices: peor / menos / mejor / más

[[Spanish#^es-Q0992-answer|Compare the answer]]
^es-Q0992

**es-Q0993 · Edit the changed sentence**

El viejo método probó ser 【más】 después de todo.

The old method proved to be best after all.

[[Spanish#^es-Q0993-answer|Compare the answer]]
^es-Q0993

**es-Q0994 · Build the sentence**

Arrange: probó / ser / El / método / viejo / todo. / de / mejor / después

The old method proved to be best after all.

[[Spanish#^es-Q0994-answer|Compare the answer]]
^es-Q0994

**es-Q0995 · Write a translation**

Write this in Spanish: It will become more and more difficult to live in the village.

[[Spanish#^es-Q0995-answer|Compare the answer]]
^es-Q0995

**es-Q0996 · Explain the grammar**

Se volverá 【más】 y más difícil vivir en la villa.

It will become more and more difficult to live in the village.

[[Spanish#^es-Q0996-answer|Compare the answer]]
^es-Q0996

**es-Q0997 · Fill the gap**

La montaña ____ alta del mundo es el monte Everest.

The tallest mountain in the world is Mount Everest.

[[Spanish#^es-Q0997-answer|Compare the answer]]
^es-Q0997

**es-Q0998 · Choose the form**

La montaña ____ alta del mundo es el monte Everest.

The tallest mountain in the world is Mount Everest.

Choices: mejor / más / menos / peor

[[Spanish#^es-Q0998-answer|Compare the answer]]
^es-Q0998

**es-Q0999 · Edit the changed sentence**

Él no es 【más】 activo como solía ser.

He is not the active person he used to be.

[[Spanish#^es-Q0999-answer|Compare the answer]]
^es-Q0999

**es-Q1000 · Build the sentence**

Arrange: solía / tan / es / no / activo / ser. / Él / como

He is not the active person he used to be.

[[Spanish#^es-Q1000-answer|Compare the answer]]
^es-Q1000


## Answers

The full sentence is a model. For translation, judge whether meaning and grammar are preserved. Each grammar rule above explains the form.

### Answers 1–50

**es-Q0001** — No han igualado la carretera.

The road hasn't been leveled.

Expected form: **la**

Why: Articles and gender. [[Spanish#^es-Q0001|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20han%20igualado%20la%20carretera.)
^es-Q0001-answer

**es-Q0002** — No han igualado la carretera.

The road hasn't been leveled.

Expected form: **la**

Why: Articles and gender. [[Spanish#^es-Q0002|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20han%20igualado%20la%20carretera.)
^es-Q0002-answer

**es-Q0003** — Yo tengo un anillo.

I have a ring.

Expected form: **un**

Why: Articles and gender. [[Spanish#^es-Q0003|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Yo%20tengo%20un%20anillo.)
^es-Q0003-answer

**es-Q0004** — Yo tengo un anillo.

I have a ring.

Why: Articles and gender. [[Spanish#^es-Q0004|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Yo%20tengo%20un%20anillo.)
^es-Q0004-answer

**es-Q0005** — Hay un ratón en la despensa.

There's a mouse in the pantry.

Why: Articles and gender. [[Spanish#^es-Q0005|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Hay%20un%20rat%C3%B3n%20en%20la%20despensa.)
^es-Q0005-answer

**es-Q0006** — Hay un ratón en la despensa.

There's a mouse in the pantry.

Articles agree in gender and number. Learn el/la with the noun. El can also occur before a stressed initial a sound in some feminine singular nouns; the noun remains feminine.

Why: Articles and gender. [[Spanish#^es-Q0006|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Hay%20un%20rat%C3%B3n%20en%20la%20despensa.)
^es-Q0006-answer

**es-Q0007** — Ken juega fútbol todos los días.

Ken plays soccer every day.

Expected form: **los**

Why: Articles and gender. [[Spanish#^es-Q0007|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Ken%20juega%20f%C3%BAtbol%20todos%20los%20d%C3%ADas.)
^es-Q0007-answer

**es-Q0008** — Ken juega fútbol todos los días.

Ken plays soccer every day.

Expected form: **los**

Why: Articles and gender. [[Spanish#^es-Q0008|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Ken%20juega%20f%C3%BAtbol%20todos%20los%20d%C3%ADas.)
^es-Q0008-answer

**es-Q0009** — Una multitud esperaba verlo.

A crowd waited to see him.

Expected form: **Una**

Why: Articles and gender. [[Spanish#^es-Q0009|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Una%20multitud%20esperaba%20verlo.)
^es-Q0009-answer

**es-Q0010** — Una multitud esperaba verlo.

A crowd waited to see him.

Why: Articles and gender. [[Spanish#^es-Q0010|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Una%20multitud%20esperaba%20verlo.)
^es-Q0010-answer

**es-Q0011** — ¿Puedo lavar toda mi ropa de una sola vez?

May I wash all my laundry at once?

Why: Articles and gender. [[Spanish#^es-Q0011|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFPuedo%20lavar%20toda%20mi%20ropa%20de%20una%20sola%20vez%3F)
^es-Q0011-answer

**es-Q0012** — ¿Puedo lavar toda mi ropa de una sola vez?

May I wash all my laundry at once?

Articles agree in gender and number. Learn el/la with the noun. El can also occur before a stressed initial a sound in some feminine singular nouns; the noun remains feminine.

Why: Articles and gender. [[Spanish#^es-Q0012|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFPuedo%20lavar%20toda%20mi%20ropa%20de%20una%20sola%20vez%3F)
^es-Q0012-answer

**es-Q0013** — Muchos peruanos tienen el hábito de mascar hojas de coca.

Many Peruvians have the habit of chewing coca leaves.

Expected form: **el**

Why: Articles and gender. [[Spanish#^es-Q0013|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Muchos%20peruanos%20tienen%20el%20h%C3%A1bito%20de%20mascar%20hojas%20de%20coca.)
^es-Q0013-answer

**es-Q0014** — Muchos peruanos tienen el hábito de mascar hojas de coca.

Many Peruvians have the habit of chewing coca leaves.

Expected form: **el**

Why: Articles and gender. [[Spanish#^es-Q0014|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Muchos%20peruanos%20tienen%20el%20h%C3%A1bito%20de%20mascar%20hojas%20de%20coca.)
^es-Q0014-answer

**es-Q0015** — La capital del Estado está justo en el ecuador.

The capital of the state is right on the equator.

Expected form: **La**

Why: Articles and gender. [[Spanish#^es-Q0015|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=La%20capital%20del%20Estado%20est%C3%A1%20justo%20en%20el%20ecuador.)
^es-Q0015-answer

**es-Q0016** — La capital del Estado está justo en el ecuador.

The capital of the state is right on the equator.

Why: Articles and gender. [[Spanish#^es-Q0016|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=La%20capital%20del%20Estado%20est%C3%A1%20justo%20en%20el%20ecuador.)
^es-Q0016-answer

**es-Q0017** — No puedes juzgar a una persona si no la conoces bien.

You can't judge a person if you don't know him well.

Why: Articles and gender. [[Spanish#^es-Q0017|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20puedes%20juzgar%20a%20una%20persona%20si%20no%20la%20conoces%20bien.)
^es-Q0017-answer

**es-Q0018** — No puedes juzgar a una persona si no la conoces bien.

You can't judge a person if you don't know him well.

Articles agree in gender and number. Learn el/la with the noun. El can also occur before a stressed initial a sound in some feminine singular nouns; the noun remains feminine.

Why: Articles and gender. [[Spanish#^es-Q0018|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20puedes%20juzgar%20a%20una%20persona%20si%20no%20la%20conoces%20bien.)
^es-Q0018-answer

**es-Q0019** — Tiene que haber habido un acuerdo tácito entre ellos.

There must've been a tacit understanding between them.

Expected form: **un**

Why: Articles and gender. [[Spanish#^es-Q0019|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tiene%20que%20haber%20habido%20un%20acuerdo%20t%C3%A1cito%20entre%20ellos.)
^es-Q0019-answer

**es-Q0020** — Tiene que haber habido un acuerdo tácito entre ellos.

There must've been a tacit understanding between them.

Expected form: **un**

Why: Articles and gender. [[Spanish#^es-Q0020|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tiene%20que%20haber%20habido%20un%20acuerdo%20t%C3%A1cito%20entre%20ellos.)
^es-Q0020-answer

**es-Q0021** — Hoy fue mi último día en la escuela.

Today was my last day of school.

Expected form: **la**

Why: Articles and gender. [[Spanish#^es-Q0021|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Hoy%20fue%20mi%20%C3%BAltimo%20d%C3%ADa%20en%20la%20escuela.)
^es-Q0021-answer

**es-Q0022** — Hoy fue mi último día en la escuela.

Today was my last day of school.

Why: Articles and gender. [[Spanish#^es-Q0022|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Hoy%20fue%20mi%20%C3%BAltimo%20d%C3%ADa%20en%20la%20escuela.)
^es-Q0022-answer

**es-Q0023** — La coartada apunta su inocencia.

The alibi points to her innocence.

Why: Articles and gender. [[Spanish#^es-Q0023|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=La%20coartada%20apunta%20su%20inocencia.)
^es-Q0023-answer

**es-Q0024** — La coartada apunta su inocencia.

The alibi points to her innocence.

Articles agree in gender and number. Learn el/la with the noun. El can also occur before a stressed initial a sound in some feminine singular nouns; the noun remains feminine.

Why: Articles and gender. [[Spanish#^es-Q0024|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=La%20coartada%20apunta%20su%20inocencia.)
^es-Q0024-answer

**es-Q0025** — ¡Presente un informe policial!

File a police report!

Expected form: **un**

Why: Articles and gender. [[Spanish#^es-Q0025|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%A1Presente%20un%20informe%20policial%21)
^es-Q0025-answer

**es-Q0026** — ¡Presente un informe policial!

File a police report!

Expected form: **un**

Why: Articles and gender. [[Spanish#^es-Q0026|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%A1Presente%20un%20informe%20policial%21)
^es-Q0026-answer

**es-Q0027** — La felicidad depende, no tanto de las circunstancias, sino de la forma de mirar la vida.

Happiness depends, not so much on circumstances, as on one's way of looking at one's life.

Expected form: **La**

Why: Articles and gender. [[Spanish#^es-Q0027|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=La%20felicidad%20depende%2C%20no%20tanto%20de%20las%20circunstancias%2C%20sino%20de%20la%20forma%20de%20mirar%20la%20vida.)
^es-Q0027-answer

**es-Q0028** — La felicidad depende, no tanto de las circunstancias, sino de la forma de mirar la vida.

Happiness depends, not so much on circumstances, as on one's way of looking at one's life.

Why: Articles and gender. [[Spanish#^es-Q0028|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=La%20felicidad%20depende%2C%20no%20tanto%20de%20las%20circunstancias%2C%20sino%20de%20la%20forma%20de%20mirar%20la%20vida.)
^es-Q0028-answer

**es-Q0029** — Por favor, no camines por el césped.

Please do not walk on the grass.

Why: Articles and gender. [[Spanish#^es-Q0029|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Por%20favor%2C%20no%20camines%20por%20el%20c%C3%A9sped.)
^es-Q0029-answer

**es-Q0030** — Por favor, no camines por el césped.

Please do not walk on the grass.

Articles agree in gender and number. Learn el/la with the noun. El can also occur before a stressed initial a sound in some feminine singular nouns; the noun remains feminine.

Why: Articles and gender. [[Spanish#^es-Q0030|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Por%20favor%2C%20no%20camines%20por%20el%20c%C3%A9sped.)
^es-Q0030-answer

**es-Q0031** — El aeropuerto está cerca.

The airport is close at hand.

Expected form: **El**

Why: Articles and gender. [[Spanish#^es-Q0031|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=El%20aeropuerto%20est%C3%A1%20cerca.)
^es-Q0031-answer

**es-Q0032** — El aeropuerto está cerca.

The airport is close at hand.

Expected form: **El**

Why: Articles and gender. [[Spanish#^es-Q0032|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=El%20aeropuerto%20est%C3%A1%20cerca.)
^es-Q0032-answer

**es-Q0033** — El lunes fue tan ajetreado.

Monday was so hectic.

Expected form: **El**

Why: Articles and gender. [[Spanish#^es-Q0033|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=El%20lunes%20fue%20tan%20ajetreado.)
^es-Q0033-answer

**es-Q0034** — El lunes fue tan ajetreado.

Monday was so hectic.

Why: Articles and gender. [[Spanish#^es-Q0034|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=El%20lunes%20fue%20tan%20ajetreado.)
^es-Q0034-answer

**es-Q0035** — No ponga ningún objeto sobre la consola.

Do not put any objects on the console.

Why: Articles and gender. [[Spanish#^es-Q0035|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20ponga%20ning%C3%BAn%20objeto%20sobre%20la%20consola.)
^es-Q0035-answer

**es-Q0036** — No ponga ningún objeto sobre la consola.

Do not put any objects on the console.

Articles agree in gender and number. Learn el/la with the noun. El can also occur before a stressed initial a sound in some feminine singular nouns; the noun remains feminine.

Why: Articles and gender. [[Spanish#^es-Q0036|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20ponga%20ning%C3%BAn%20objeto%20sobre%20la%20consola.)
^es-Q0036-answer

**es-Q0037** — Juega al tenis todos los días.

He plays tennis every day.

Expected form: **los**

Why: Articles and gender. [[Spanish#^es-Q0037|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Juega%20al%20tenis%20todos%20los%20d%C3%ADas.)
^es-Q0037-answer

**es-Q0038** — Juega al tenis todos los días.

He plays tennis every day.

Expected form: **los**

Why: Articles and gender. [[Spanish#^es-Q0038|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Juega%20al%20tenis%20todos%20los%20d%C3%ADas.)
^es-Q0038-answer

**es-Q0039** — Como se esperaba, la expresión del gen se redujo significativamente.

As expected, expression of the gene was significantly reduced.

Expected form: **la**

Why: Articles and gender. [[Spanish#^es-Q0039|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Como%20se%20esperaba%2C%20la%20expresi%C3%B3n%20del%20gen%20se%20redujo%20significativamente.)
^es-Q0039-answer

**es-Q0040** — Como se esperaba, la expresión del gen se redujo significativamente.

As expected, expression of the gene was significantly reduced.

Why: Articles and gender. [[Spanish#^es-Q0040|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Como%20se%20esperaba%2C%20la%20expresi%C3%B3n%20del%20gen%20se%20redujo%20significativamente.)
^es-Q0040-answer

**es-Q0041** — El ejercicio mental es particularmente importante para los chiquillos.

Mental exercise is particularly important for young children.

Why: Articles and gender. [[Spanish#^es-Q0041|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=El%20ejercicio%20mental%20es%20particularmente%20importante%20para%20los%20chiquillos.)
^es-Q0041-answer

**es-Q0042** — El ejercicio mental es particularmente importante para los chiquillos.

Mental exercise is particularly important for young children.

Articles agree in gender and number. Learn el/la with the noun. El can also occur before a stressed initial a sound in some feminine singular nouns; the noun remains feminine.

Why: Articles and gender. [[Spanish#^es-Q0042|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=El%20ejercicio%20mental%20es%20particularmente%20importante%20para%20los%20chiquillos.)
^es-Q0042-answer

**es-Q0043** — Espera un poquito. Te voy a preparar un poco.

Wait a bit. I'll prepare some for you.

Expected form: **un**

Why: Articles and gender. [[Spanish#^es-Q0043|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Espera%20un%20poquito.%20Te%20voy%20a%20preparar%20un%20poco.)
^es-Q0043-answer

**es-Q0044** — Espera un poquito. Te voy a preparar un poco.

Wait a bit. I'll prepare some for you.

Expected form: **un**

Why: Articles and gender. [[Spanish#^es-Q0044|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Espera%20un%20poquito.%20Te%20voy%20a%20preparar%20un%20poco.)
^es-Q0044-answer

**es-Q0045** — El dentista me arregló los dientes.

The dentist treated my teeth.

Expected form: **El**

Why: Articles and gender. [[Spanish#^es-Q0045|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=El%20dentista%20me%20arregl%C3%B3%20los%20dientes.)
^es-Q0045-answer

**es-Q0046** — El dentista me arregló los dientes.

The dentist treated my teeth.

Why: Articles and gender. [[Spanish#^es-Q0046|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=El%20dentista%20me%20arregl%C3%B3%20los%20dientes.)
^es-Q0046-answer

**es-Q0047** — Eres un aficionado con la espada.

You're an amateur with the sword.

Why: Articles and gender. [[Spanish#^es-Q0047|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Eres%20un%20aficionado%20con%20la%20espada.)
^es-Q0047-answer

**es-Q0048** — Eres un aficionado con la espada.

You're an amateur with the sword.

Articles agree in gender and number. Learn el/la with the noun. El can also occur before a stressed initial a sound in some feminine singular nouns; the noun remains feminine.

Why: Articles and gender. [[Spanish#^es-Q0048|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Eres%20un%20aficionado%20con%20la%20espada.)
^es-Q0048-answer

**es-Q0049** — A mi hijo no le gusta el dentista.

My child dislikes the dentist.

Expected form: **el**

Why: Articles and gender. [[Spanish#^es-Q0049|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=A%20mi%20hijo%20no%20le%20gusta%20el%20dentista.)
^es-Q0049-answer

**es-Q0050** — A mi hijo no le gusta el dentista.

My child dislikes the dentist.

Expected form: **el**

Why: Articles and gender. [[Spanish#^es-Q0050|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=A%20mi%20hijo%20no%20le%20gusta%20el%20dentista.)
^es-Q0050-answer


### Answers 51–100

**es-Q0051** — Ésta si que va a ser buena.

This is going to be swell.

Expected form: **buena**

Why: Adjective agreement. [[Spanish#^es-Q0051|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C3%89sta%20si%20que%20va%20a%20ser%20buena.)
^es-Q0051-answer

**es-Q0052** — Ésta si que va a ser buena.

This is going to be swell.

Why: Adjective agreement. [[Spanish#^es-Q0052|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C3%89sta%20si%20que%20va%20a%20ser%20buena.)
^es-Q0052-answer

**es-Q0053** — No puedo dejarte desembarcar sin darte un beso grande.

I can't let you disembark without giving you a big kiss.

Why: Adjective agreement. [[Spanish#^es-Q0053|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20puedo%20dejarte%20desembarcar%20sin%20darte%20un%20beso%20grande.)
^es-Q0053-answer

**es-Q0054** — No puedo dejarte desembarcar sin darte un beso grande.

I can't let you disembark without giving you a big kiss.

Most adjectives agree with the noun. Some change only for number. Position and shortened forms can affect meaning: un buen libro versus el libro es bueno.

Why: Adjective agreement. [[Spanish#^es-Q0054|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20puedo%20dejarte%20desembarcar%20sin%20darte%20un%20beso%20grande.)
^es-Q0054-answer

**es-Q0055** — Los abejorros son más grandes que las abejas.

Bumblebees are bigger than bees.

Expected form: **grandes**

Why: Adjective agreement. [[Spanish#^es-Q0055|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Los%20abejorros%20son%20m%C3%A1s%20grandes%20que%20las%20abejas.)
^es-Q0055-answer

**es-Q0056** — Los abejorros son más grandes que las abejas.

Bumblebees are bigger than bees.

Expected form: **grandes**

Why: Adjective agreement. [[Spanish#^es-Q0056|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Los%20abejorros%20son%20m%C3%A1s%20grandes%20que%20las%20abejas.)
^es-Q0056-answer

**es-Q0057** — Esa pieza no es muy grande.

That room is not very large.

Expected form: **grande**

Why: Adjective agreement. [[Spanish#^es-Q0057|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Esa%20pieza%20no%20es%20muy%20grande.)
^es-Q0057-answer

**es-Q0058** — Esa pieza no es muy grande.

That room is not very large.

Why: Adjective agreement. [[Spanish#^es-Q0058|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Esa%20pieza%20no%20es%20muy%20grande.)
^es-Q0058-answer

**es-Q0059** — Nadie sabe que he comprado un coche nuevo.

Nobody knows that I have bought a new car.

Why: Adjective agreement. [[Spanish#^es-Q0059|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Nadie%20sabe%20que%20he%20comprado%20un%20coche%20nuevo.)
^es-Q0059-answer

**es-Q0060** — Nadie sabe que he comprado un coche nuevo.

Nobody knows that I have bought a new car.

Most adjectives agree with the noun. Some change only for number. Position and shortened forms can affect meaning: un buen libro versus el libro es bueno.

Why: Adjective agreement. [[Spanish#^es-Q0060|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Nadie%20sabe%20que%20he%20comprado%20un%20coche%20nuevo.)
^es-Q0060-answer

**es-Q0061** — Esperamos ansiosamente verlo de nuevo.

We anxiously wait to see it again.

Expected form: **nuevo**

Why: Adjective agreement. [[Spanish#^es-Q0061|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Esperamos%20ansiosamente%20verlo%20de%20nuevo.)
^es-Q0061-answer

**es-Q0062** — Esperamos ansiosamente verlo de nuevo.

We anxiously wait to see it again.

Expected form: **nuevo**

Why: Adjective agreement. [[Spanish#^es-Q0062|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Esperamos%20ansiosamente%20verlo%20de%20nuevo.)
^es-Q0062-answer

**es-Q0063** — Este traje es demasiado bueno para mí.

This suit is too good for me.

Expected form: **bueno**

Why: Adjective agreement. [[Spanish#^es-Q0063|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Este%20traje%20es%20demasiado%20bueno%20para%20m%C3%AD.)
^es-Q0063-answer

**es-Q0064** — Este traje es demasiado bueno para mí.

This suit is too good for me.

Why: Adjective agreement. [[Spanish#^es-Q0064|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Este%20traje%20es%20demasiado%20bueno%20para%20m%C3%AD.)
^es-Q0064-answer

**es-Q0065** — Tom tiene un coche nuevo.

Tom has a new car.

Why: Adjective agreement. [[Spanish#^es-Q0065|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tom%20tiene%20un%20coche%20nuevo.)
^es-Q0065-answer

**es-Q0066** — Tom tiene un coche nuevo.

Tom has a new car.

Most adjectives agree with the noun. Some change only for number. Position and shortened forms can affect meaning: un buen libro versus el libro es bueno.

Why: Adjective agreement. [[Spanish#^es-Q0066|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tom%20tiene%20un%20coche%20nuevo.)
^es-Q0066-answer

**es-Q0067** — Los grandes artistas jamás ven las cosas tal como realmente son. Si lo hicieran, dejarían de ser artistas.

No great artist ever sees things as they really are. If he did, he would cease to be an artist.

Expected form: **grandes**

Why: Adjective agreement. [[Spanish#^es-Q0067|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Los%20grandes%20artistas%20jam%C3%A1s%20ven%20las%20cosas%20tal%20como%20realmente%20son.%20Si%20lo%20hicieran%2C%20dejar%C3%ADan%20de%20ser%20artistas.)
^es-Q0067-answer

**es-Q0068** — Los grandes artistas jamás ven las cosas tal como realmente son. Si lo hicieran, dejarían de ser artistas.

No great artist ever sees things as they really are. If he did, he would cease to be an artist.

Expected form: **grandes**

Why: Adjective agreement. [[Spanish#^es-Q0068|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Los%20grandes%20artistas%20jam%C3%A1s%20ven%20las%20cosas%20tal%20como%20realmente%20son.%20Si%20lo%20hicieran%2C%20dejar%C3%ADan%20de%20ser%20artistas.)
^es-Q0068-answer

**es-Q0069** — Te voy a presentar a una buena chica.

I'll introduce you to a nice girl.

Expected form: **buena**

Why: Adjective agreement. [[Spanish#^es-Q0069|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Te%20voy%20a%20presentar%20a%20una%20buena%20chica.)
^es-Q0069-answer

**es-Q0070** — Te voy a presentar a una buena chica.

I'll introduce you to a nice girl.

Why: Adjective agreement. [[Spanish#^es-Q0070|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Te%20voy%20a%20presentar%20a%20una%20buena%20chica.)
^es-Q0070-answer

**es-Q0071** — La oficina nueva es más amplia.

The new office is more spacious.

Why: Adjective agreement. [[Spanish#^es-Q0071|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=La%20oficina%20nueva%20es%20m%C3%A1s%20amplia.)
^es-Q0071-answer

**es-Q0072** — La oficina nueva es más amplia.

The new office is more spacious.

Most adjectives agree with the noun. Some change only for number. Position and shortened forms can affect meaning: un buen libro versus el libro es bueno.

Why: Adjective agreement. [[Spanish#^es-Q0072|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=La%20oficina%20nueva%20es%20m%C3%A1s%20amplia.)
^es-Q0072-answer

**es-Q0073** — Busqué por todos lados un departamento pequeño.

I've searched everywhere for a small apartment.

Expected form: **pequeño**

Why: Adjective agreement. [[Spanish#^es-Q0073|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Busqu%C3%A9%20por%20todos%20lados%20un%20departamento%20peque%C3%B1o.)
^es-Q0073-answer

**es-Q0074** — Busqué por todos lados un departamento pequeño.

I've searched everywhere for a small apartment.

Expected form: **pequeño**

Why: Adjective agreement. [[Spanish#^es-Q0074|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Busqu%C3%A9%20por%20todos%20lados%20un%20departamento%20peque%C3%B1o.)
^es-Q0074-answer

**es-Q0075** — Tom no cree que la pronunciación francesa de Mary sea muy buena.

Tom doesn't think Mary's French pronunciation is very good.

Expected form: **buena**

Why: Adjective agreement. [[Spanish#^es-Q0075|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tom%20no%20cree%20que%20la%20pronunciaci%C3%B3n%20francesa%20de%20Mary%20sea%20muy%20buena.)
^es-Q0075-answer

**es-Q0076** — Tom no cree que la pronunciación francesa de Mary sea muy buena.

Tom doesn't think Mary's French pronunciation is very good.

Why: Adjective agreement. [[Spanish#^es-Q0076|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tom%20no%20cree%20que%20la%20pronunciaci%C3%B3n%20francesa%20de%20Mary%20sea%20muy%20buena.)
^es-Q0076-answer

**es-Q0077** — Estaba pensando en un nuevo trabajo.

I was just thinking of a new job.

Why: Adjective agreement. [[Spanish#^es-Q0077|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Estaba%20pensando%20en%20un%20nuevo%20trabajo.)
^es-Q0077-answer

**es-Q0078** — Estaba pensando en un nuevo trabajo.

I was just thinking of a new job.

Most adjectives agree with the noun. Some change only for number. Position and shortened forms can affect meaning: un buen libro versus el libro es bueno.

Why: Adjective agreement. [[Spanish#^es-Q0078|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Estaba%20pensando%20en%20un%20nuevo%20trabajo.)
^es-Q0078-answer

**es-Q0079** — Ese escritorio es demasiado pequeño para Meg.

That desk is too small for Meg.

Expected form: **pequeño**

Why: Adjective agreement. [[Spanish#^es-Q0079|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Ese%20escritorio%20es%20demasiado%20peque%C3%B1o%20para%20Meg.)
^es-Q0079-answer

**es-Q0080** — Ese escritorio es demasiado pequeño para Meg.

That desk is too small for Meg.

Expected form: **pequeño**

Why: Adjective agreement. [[Spanish#^es-Q0080|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Ese%20escritorio%20es%20demasiado%20peque%C3%B1o%20para%20Meg.)
^es-Q0080-answer

**es-Q0081** — Buenos días. ¿Cómo está usted?

Good morning. How are you?

Expected form: **Buenos**

Why: Adjective agreement. [[Spanish#^es-Q0081|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Buenos%20d%C3%ADas.%20%C2%BFC%C3%B3mo%20est%C3%A1%20usted%3F)
^es-Q0081-answer

**es-Q0082** — Buenos días. ¿Cómo está usted?

Good morning. How are you?

Why: Adjective agreement. [[Spanish#^es-Q0082|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Buenos%20d%C3%ADas.%20%C2%BFC%C3%B3mo%20est%C3%A1%20usted%3F)
^es-Q0082-answer

**es-Q0083** — ¿No lo será demasiado pequeño?

Won't it be too little?

Why: Adjective agreement. [[Spanish#^es-Q0083|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFNo%20lo%20ser%C3%A1%20demasiado%20peque%C3%B1o%3F)
^es-Q0083-answer

**es-Q0084** — ¿No lo será demasiado pequeño?

Won't it be too little?

Most adjectives agree with the noun. Some change only for number. Position and shortened forms can affect meaning: un buen libro versus el libro es bueno.

Why: Adjective agreement. [[Spanish#^es-Q0084|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFNo%20lo%20ser%C3%A1%20demasiado%20peque%C3%B1o%3F)
^es-Q0084-answer

**es-Q0085** — Anoche, alguien se metió a la pequeña tienda cerca de mi casa.

Last night someone broke into the small shop near my house.

Expected form: **pequeña**

Why: Adjective agreement. [[Spanish#^es-Q0085|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Anoche%2C%20alguien%20se%20meti%C3%B3%20a%20la%20peque%C3%B1a%20tienda%20cerca%20de%20mi%20casa.)
^es-Q0085-answer

**es-Q0086** — Anoche, alguien se metió a la pequeña tienda cerca de mi casa.

Last night someone broke into the small shop near my house.

Expected form: **pequeña**

Why: Adjective agreement. [[Spanish#^es-Q0086|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Anoche%2C%20alguien%20se%20meti%C3%B3%20a%20la%20peque%C3%B1a%20tienda%20cerca%20de%20mi%20casa.)
^es-Q0086-answer

**es-Q0087** — Elijas el que elijas, asegúrate de que es uno bueno.

Whichever you choose, make sure it is a good one.

Expected form: **bueno**

Why: Adjective agreement. [[Spanish#^es-Q0087|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Elijas%20el%20que%20elijas%2C%20aseg%C3%BArate%20de%20que%20es%20uno%20bueno.)
^es-Q0087-answer

**es-Q0088** — Elijas el que elijas, asegúrate de que es uno bueno.

Whichever you choose, make sure it is a good one.

Why: Adjective agreement. [[Spanish#^es-Q0088|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Elijas%20el%20que%20elijas%2C%20aseg%C3%BArate%20de%20que%20es%20uno%20bueno.)
^es-Q0088-answer

**es-Q0089** — Él encontró muy difícil adaptarse a la vida en la nueva escuela.

He found it very difficult to adjust himself to life in the new school.

Why: Adjective agreement. [[Spanish#^es-Q0089|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C3%89l%20encontr%C3%B3%20muy%20dif%C3%ADcil%20adaptarse%20a%20la%20vida%20en%20la%20nueva%20escuela.)
^es-Q0089-answer

**es-Q0090** — Él encontró muy difícil adaptarse a la vida en la nueva escuela.

He found it very difficult to adjust himself to life in the new school.

Most adjectives agree with the noun. Some change only for number. Position and shortened forms can affect meaning: un buen libro versus el libro es bueno.

Why: Adjective agreement. [[Spanish#^es-Q0090|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C3%89l%20encontr%C3%B3%20muy%20dif%C3%ADcil%20adaptarse%20a%20la%20vida%20en%20la%20nueva%20escuela.)
^es-Q0090-answer

**es-Q0091** — Probablemente eso no sea bueno.

That's probably not good.

Expected form: **bueno**

Why: Adjective agreement. [[Spanish#^es-Q0091|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Probablemente%20eso%20no%20sea%20bueno.)
^es-Q0091-answer

**es-Q0092** — Probablemente eso no sea bueno.

That's probably not good.

Expected form: **bueno**

Why: Adjective agreement. [[Spanish#^es-Q0092|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Probablemente%20eso%20no%20sea%20bueno.)
^es-Q0092-answer

**es-Q0093** — Él era un hombre grande y pesado.

He was a big, heavy man.

Expected form: **grande**

Why: Adjective agreement. [[Spanish#^es-Q0093|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C3%89l%20era%20un%20hombre%20grande%20y%20pesado.)
^es-Q0093-answer

**es-Q0094** — Él era un hombre grande y pesado.

He was a big, heavy man.

Why: Adjective agreement. [[Spanish#^es-Q0094|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C3%89l%20era%20un%20hombre%20grande%20y%20pesado.)
^es-Q0094-answer

**es-Q0095** — Parecía demasiado bueno para ser verdad.

It seemed too good to be true.

Why: Adjective agreement. [[Spanish#^es-Q0095|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Parec%C3%ADa%20demasiado%20bueno%20para%20ser%20verdad.)
^es-Q0095-answer

**es-Q0096** — Parecía demasiado bueno para ser verdad.

It seemed too good to be true.

Most adjectives agree with the noun. Some change only for number. Position and shortened forms can affect meaning: un buen libro versus el libro es bueno.

Why: Adjective agreement. [[Spanish#^es-Q0096|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Parec%C3%ADa%20demasiado%20bueno%20para%20ser%20verdad.)
^es-Q0096-answer

**es-Q0097** — El Gulasch está muy bueno en Budapest.

The goulash is very good in Budapest.

Expected form: **bueno**

Why: Adjective agreement. [[Spanish#^es-Q0097|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=El%20Gulasch%20est%C3%A1%20muy%20bueno%20en%20Budapest.)
^es-Q0097-answer

**es-Q0098** — El Gulasch está muy bueno en Budapest.

The goulash is very good in Budapest.

Expected form: **bueno**

Why: Adjective agreement. [[Spanish#^es-Q0098|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=El%20Gulasch%20est%C3%A1%20muy%20bueno%20en%20Budapest.)
^es-Q0098-answer

**es-Q0099** — Buenas noches. Que sueñes con los angelitos.

Good night. Sweet dreams.

Expected form: **Buenas**

Why: Adjective agreement. [[Spanish#^es-Q0099|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Buenas%20noches.%20Que%20sue%C3%B1es%20con%20los%20angelitos.)
^es-Q0099-answer

**es-Q0100** — Buenas noches. Que sueñes con los angelitos.

Good night. Sweet dreams.

Why: Adjective agreement. [[Spanish#^es-Q0100|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Buenas%20noches.%20Que%20sue%C3%B1es%20con%20los%20angelitos.)
^es-Q0100-answer


### Answers 101–150

**es-Q0101** — ¿Es ésta tu cartera?

Is this your wallet?

Why: Ser forms. [[Spanish#^es-Q0101|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFEs%20%C3%A9sta%20tu%20cartera%3F)
^es-Q0101-answer

**es-Q0102** — ¿Es ésta tu cartera?

Is this your wallet?

Ser identifies or characterises a referent and expresses many classifications. Do not reduce the distinction to permanent versus temporary; events and time also use ser.

Why: Ser forms. [[Spanish#^es-Q0102|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFEs%20%C3%A9sta%20tu%20cartera%3F)
^es-Q0102-answer

**es-Q0103** — Ésas no son vuestras sillas.

Those are not your chairs.

Expected form: **son**

Why: Ser forms. [[Spanish#^es-Q0103|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C3%89sas%20no%20son%20vuestras%20sillas.)
^es-Q0103-answer

**es-Q0104** — Ésas no son vuestras sillas.

Those are not your chairs.

Expected form: **son**

Why: Ser forms. [[Spanish#^es-Q0104|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C3%89sas%20no%20son%20vuestras%20sillas.)
^es-Q0104-answer

**es-Q0105** — Uno es juzgado por su forma de hablar en primera instancia.

One is judged by one's speech first of all.

Expected form: **es**

Why: Ser forms. [[Spanish#^es-Q0105|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Uno%20es%20juzgado%20por%20su%20forma%20de%20hablar%20en%20primera%20instancia.)
^es-Q0105-answer

**es-Q0106** — Uno es juzgado por su forma de hablar en primera instancia.

One is judged by one's speech first of all.

Why: Ser forms. [[Spanish#^es-Q0106|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Uno%20es%20juzgado%20por%20su%20forma%20de%20hablar%20en%20primera%20instancia.)
^es-Q0106-answer

**es-Q0107** — Las manzanas son producidas en este sector.

Apples are produced in this district.

Why: Ser forms. [[Spanish#^es-Q0107|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Las%20manzanas%20son%20producidas%20en%20este%20sector.)
^es-Q0107-answer

**es-Q0108** — Las manzanas son producidas en este sector.

Apples are produced in this district.

Ser identifies or characterises a referent and expresses many classifications. Do not reduce the distinction to permanent versus temporary; events and time also use ser.

Why: Ser forms. [[Spanish#^es-Q0108|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Las%20manzanas%20son%20producidas%20en%20este%20sector.)
^es-Q0108-answer

**es-Q0109** — El danés y el noruego son dos idiomas muy semejantes.

Danish and Norwegian are two very similar languages.

Expected form: **son**

Why: Ser forms. [[Spanish#^es-Q0109|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=El%20dan%C3%A9s%20y%20el%20noruego%20son%20dos%20idiomas%20muy%20semejantes.)
^es-Q0109-answer

**es-Q0110** — El danés y el noruego son dos idiomas muy semejantes.

Danish and Norwegian are two very similar languages.

Expected form: **son**

Why: Ser forms. [[Spanish#^es-Q0110|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=El%20dan%C3%A9s%20y%20el%20noruego%20son%20dos%20idiomas%20muy%20semejantes.)
^es-Q0110-answer

**es-Q0111** — Yo digo "yo soy John".

I say, “I’m John”.

Expected form: **soy**

Why: Ser forms. [[Spanish#^es-Q0111|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Yo%20digo%20%22yo%20soy%20John%22.)
^es-Q0111-answer

**es-Q0112** — Yo digo "yo soy John".

I say, “I’m John”.

Why: Ser forms. [[Spanish#^es-Q0112|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Yo%20digo%20%22yo%20soy%20John%22.)
^es-Q0112-answer

**es-Q0113** — Ella es de lejos la mejor jugadora en ese país.

She is by far the best player in that country.

Why: Ser forms. [[Spanish#^es-Q0113|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Ella%20es%20de%20lejos%20la%20mejor%20jugadora%20en%20ese%20pa%C3%ADs.)
^es-Q0113-answer

**es-Q0114** — Ella es de lejos la mejor jugadora en ese país.

She is by far the best player in that country.

Ser identifies or characterises a referent and expresses many classifications. Do not reduce the distinction to permanent versus temporary; events and time also use ser.

Why: Ser forms. [[Spanish#^es-Q0114|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Ella%20es%20de%20lejos%20la%20mejor%20jugadora%20en%20ese%20pa%C3%ADs.)
^es-Q0114-answer

**es-Q0115** — Éstos son los míos.

These are mine.

Expected form: **son**

Why: Ser forms. [[Spanish#^es-Q0115|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C3%89stos%20son%20los%20m%C3%ADos.)
^es-Q0115-answer

**es-Q0116** — Éstos son los míos.

These are mine.

Expected form: **son**

Why: Ser forms. [[Spanish#^es-Q0116|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C3%89stos%20son%20los%20m%C3%ADos.)
^es-Q0116-answer

**es-Q0117** — ¿Cuál es tu lugar vacacional favorito de Japón?

What's your favorite place to vacation in Japan?

Expected form: **es**

Why: Ser forms. [[Spanish#^es-Q0117|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFCu%C3%A1l%20es%20tu%20lugar%20vacacional%20favorito%20de%20Jap%C3%B3n%3F)
^es-Q0117-answer

**es-Q0118** — ¿Cuál es tu lugar vacacional favorito de Japón?

What's your favorite place to vacation in Japan?

Why: Ser forms. [[Spanish#^es-Q0118|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFCu%C3%A1l%20es%20tu%20lugar%20vacacional%20favorito%20de%20Jap%C3%B3n%3F)
^es-Q0118-answer

**es-Q0119** — El francés de Tom es casi perfecto.

Tom's French is almost perfect.

Why: Ser forms. [[Spanish#^es-Q0119|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=El%20franc%C3%A9s%20de%20Tom%20es%20casi%20perfecto.)
^es-Q0119-answer

**es-Q0120** — El francés de Tom es casi perfecto.

Tom's French is almost perfect.

Ser identifies or characterises a referent and expresses many classifications. Do not reduce the distinction to permanent versus temporary; events and time also use ser.

Why: Ser forms. [[Spanish#^es-Q0120|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=El%20franc%C3%A9s%20de%20Tom%20es%20casi%20perfecto.)
^es-Q0120-answer

**es-Q0121** — No soy materialista.

I'm not materialistic.

Expected form: **soy**

Why: Ser forms. [[Spanish#^es-Q0121|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20soy%20materialista.)
^es-Q0121-answer

**es-Q0122** — No soy materialista.

I'm not materialistic.

Expected form: **soy**

Why: Ser forms. [[Spanish#^es-Q0122|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20soy%20materialista.)
^es-Q0122-answer

**es-Q0123** — Este es un diccionario de versión reducida.

This dictionary is an abridged edition.

Expected form: **es**

Why: Ser forms. [[Spanish#^es-Q0123|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Este%20es%20un%20diccionario%20de%20versi%C3%B3n%20reducida.)
^es-Q0123-answer

**es-Q0124** — Este es un diccionario de versión reducida.

This dictionary is an abridged edition.

Why: Ser forms. [[Spanish#^es-Q0124|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Este%20es%20un%20diccionario%20de%20versi%C3%B3n%20reducida.)
^es-Q0124-answer

**es-Q0125** — Creo que es improbable que yo pase el test de conducir.

I think it's unlikely that I'll be able to pass my driving test.

Why: Ser forms. [[Spanish#^es-Q0125|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Creo%20que%20es%20improbable%20que%20yo%20pase%20el%20test%20de%20conducir.)
^es-Q0125-answer

**es-Q0126** — Creo que es improbable que yo pase el test de conducir.

I think it's unlikely that I'll be able to pass my driving test.

Ser identifies or characterises a referent and expresses many classifications. Do not reduce the distinction to permanent versus temporary; events and time also use ser.

Why: Ser forms. [[Spanish#^es-Q0126|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Creo%20que%20es%20improbable%20que%20yo%20pase%20el%20test%20de%20conducir.)
^es-Q0126-answer

**es-Q0127** — «¿De quién son estos CD?» «Son de Samir.»

"Whose CD's are these?" "They are Samir's."

Expected form: **son**

Why: Ser forms. [[Spanish#^es-Q0127|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%AB%C2%BFDe%20qui%C3%A9n%20son%20estos%20CD%3F%C2%BB%20%C2%ABSon%20de%20Samir.%C2%BB)
^es-Q0127-answer

**es-Q0128** — «¿De quién son estos CD?» «Son de Samir.»

"Whose CD's are these?" "They are Samir's."

Expected form: **son**

Why: Ser forms. [[Spanish#^es-Q0128|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%AB%C2%BFDe%20qui%C3%A9n%20son%20estos%20CD%3F%C2%BB%20%C2%ABSon%20de%20Samir.%C2%BB)
^es-Q0128-answer

**es-Q0129** — ¡Tú eres un adicto a las drogas como yo!

You're a drug addict like me!

Expected form: **eres**

Why: Ser forms. [[Spanish#^es-Q0129|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%A1T%C3%BA%20eres%20un%20adicto%20a%20las%20drogas%20como%20yo%21)
^es-Q0129-answer

**es-Q0130** — ¡Tú eres un adicto a las drogas como yo!

You're a drug addict like me!

Why: Ser forms. [[Spanish#^es-Q0130|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%A1T%C3%BA%20eres%20un%20adicto%20a%20las%20drogas%20como%20yo%21)
^es-Q0130-answer

**es-Q0131** — No te puedes imaginar lo humillante que es esto.

You can't imagine how humiliating this is.

Why: Ser forms. [[Spanish#^es-Q0131|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20te%20puedes%20imaginar%20lo%20humillante%20que%20es%20esto.)
^es-Q0131-answer

**es-Q0132** — No te puedes imaginar lo humillante que es esto.

You can't imagine how humiliating this is.

Ser identifies or characterises a referent and expresses many classifications. Do not reduce the distinction to permanent versus temporary; events and time also use ser.

Why: Ser forms. [[Spanish#^es-Q0132|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20te%20puedes%20imaginar%20lo%20humillante%20que%20es%20esto.)
^es-Q0132-answer

**es-Q0133** — La ciudad es famosa por su viejo castillo.

The town is famous for its old castle.

Expected form: **es**

Why: Ser forms. [[Spanish#^es-Q0133|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=La%20ciudad%20es%20famosa%20por%20su%20viejo%20castillo.)
^es-Q0133-answer

**es-Q0134** — La ciudad es famosa por su viejo castillo.

The town is famous for its old castle.

Expected form: **es**

Why: Ser forms. [[Spanish#^es-Q0134|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=La%20ciudad%20es%20famosa%20por%20su%20viejo%20castillo.)
^es-Q0134-answer

**es-Q0135** — Considero que los Testigos de Jehová que vienen constantemente a llamar a mi puerta no son diferentes de los fanáticos religiosos que intentan convertirme.

I consider the Jehovah's witnesses who knock on my door all the time to be no different from religious zealots trying to force their beliefs on me.

Expected form: **son**

Why: Ser forms. [[Spanish#^es-Q0135|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Considero%20que%20los%20Testigos%20de%20Jehov%C3%A1%20que%20vienen%20constantemente%20a%20llamar%20a%20mi%20puerta%20no%20son%20diferentes%20de%20los%20fan%C3%A1ticos%20religiosos%20que%20intentan%20convertirme.)
^es-Q0135-answer

**es-Q0136** — Considero que los Testigos de Jehová que vienen constantemente a llamar a mi puerta no son diferentes de los fanáticos religiosos que intentan convertirme.

I consider the Jehovah's witnesses who knock on my door all the time to be no different from religious zealots trying to force their beliefs on me.

Why: Ser forms. [[Spanish#^es-Q0136|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Considero%20que%20los%20Testigos%20de%20Jehov%C3%A1%20que%20vienen%20constantemente%20a%20llamar%20a%20mi%20puerta%20no%20son%20diferentes%20de%20los%20fan%C3%A1ticos%20religiosos%20que%20intentan%20convertirme.)
^es-Q0136-answer

**es-Q0137** — Él es adicto al pan.

He's a bread junkie.

Why: Ser forms. [[Spanish#^es-Q0137|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C3%89l%20es%20adicto%20al%20pan.)
^es-Q0137-answer

**es-Q0138** — Él es adicto al pan.

He's a bread junkie.

Ser identifies or characterises a referent and expresses many classifications. Do not reduce the distinction to permanent versus temporary; events and time also use ser.

Why: Ser forms. [[Spanish#^es-Q0138|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C3%89l%20es%20adicto%20al%20pan.)
^es-Q0138-answer

**es-Q0139** — Esa estudiante es muy activa.

That student is very active.

Expected form: **es**

Why: Ser forms. [[Spanish#^es-Q0139|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Esa%20estudiante%20es%20muy%20activa.)
^es-Q0139-answer

**es-Q0140** — Esa estudiante es muy activa.

That student is very active.

Expected form: **es**

Why: Ser forms. [[Spanish#^es-Q0140|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Esa%20estudiante%20es%20muy%20activa.)
^es-Q0140-answer

**es-Q0141** — No es mi tipo.

This is not my type.

Expected form: **es**

Why: Ser forms. [[Spanish#^es-Q0141|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20es%20mi%20tipo.)
^es-Q0141-answer

**es-Q0142** — No es mi tipo.

This is not my type.

Why: Ser forms. [[Spanish#^es-Q0142|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20es%20mi%20tipo.)
^es-Q0142-answer

**es-Q0143** — Soy alérgico al maíz.

I'm allergic to corn.

Why: Ser forms. [[Spanish#^es-Q0143|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Soy%20al%C3%A9rgico%20al%20ma%C3%ADz.)
^es-Q0143-answer

**es-Q0144** — Soy alérgico al maíz.

I'm allergic to corn.

Ser identifies or characterises a referent and expresses many classifications. Do not reduce the distinction to permanent versus temporary; events and time also use ser.

Why: Ser forms. [[Spanish#^es-Q0144|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Soy%20al%C3%A9rgico%20al%20ma%C3%ADz.)
^es-Q0144-answer

**es-Q0145** — ¿Cuál es el propósito de la belleza?

What is the use of beauty?

Expected form: **es**

Why: Ser forms. [[Spanish#^es-Q0145|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFCu%C3%A1l%20es%20el%20prop%C3%B3sito%20de%20la%20belleza%3F)
^es-Q0145-answer

**es-Q0146** — ¿Cuál es el propósito de la belleza?

What is the use of beauty?

Expected form: **es**

Why: Ser forms. [[Spanish#^es-Q0146|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFCu%C3%A1l%20es%20el%20prop%C3%B3sito%20de%20la%20belleza%3F)
^es-Q0146-answer

**es-Q0147** — El trabajo es muy divertido.

The job is a lot of fun.

Expected form: **es**

Why: Ser forms. [[Spanish#^es-Q0147|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=El%20trabajo%20es%20muy%20divertido.)
^es-Q0147-answer

**es-Q0148** — El trabajo es muy divertido.

The job is a lot of fun.

Why: Ser forms. [[Spanish#^es-Q0148|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=El%20trabajo%20es%20muy%20divertido.)
^es-Q0148-answer

**es-Q0149** — Un idioma es un sistema vivo que evoluciona con el tiempo.

A language is a living system that evolves over time.

Why: Ser forms. [[Spanish#^es-Q0149|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Un%20idioma%20es%20un%20sistema%20vivo%20que%20evoluciona%20con%20el%20tiempo.)
^es-Q0149-answer

**es-Q0150** — Un idioma es un sistema vivo que evoluciona con el tiempo.

A language is a living system that evolves over time.

Ser identifies or characterises a referent and expresses many classifications. Do not reduce the distinction to permanent versus temporary; events and time also use ser.

Why: Ser forms. [[Spanish#^es-Q0150|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Un%20idioma%20es%20un%20sistema%20vivo%20que%20evoluciona%20con%20el%20tiempo.)
^es-Q0150-answer


### Answers 151–200

**es-Q0151** — Tomás también está nervioso.

Tom is nervous, too.

Expected form: **está**

Why: Estar forms. [[Spanish#^es-Q0151|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tom%C3%A1s%20tambi%C3%A9n%20est%C3%A1%20nervioso.)
^es-Q0151-answer

**es-Q0152** — Tomás también está nervioso.

Tom is nervous, too.

Expected form: **está**

Why: Estar forms. [[Spanish#^es-Q0152|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tom%C3%A1s%20tambi%C3%A9n%20est%C3%A1%20nervioso.)
^es-Q0152-answer

**es-Q0153** — ¿Qué estáis haciendo vosotros dos?

What are you two doing?

Expected form: **estáis**

Why: Estar forms. [[Spanish#^es-Q0153|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFQu%C3%A9%20est%C3%A1is%20haciendo%20vosotros%20dos%3F)
^es-Q0153-answer

**es-Q0154** — ¿Qué estáis haciendo vosotros dos?

What are you two doing?

Why: Estar forms. [[Spanish#^es-Q0154|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFQu%C3%A9%20est%C3%A1is%20haciendo%20vosotros%20dos%3F)
^es-Q0154-answer

**es-Q0155** — Estoy viendo la casa.

I see the house.

Why: Estar forms. [[Spanish#^es-Q0155|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Estoy%20viendo%20la%20casa.)
^es-Q0155-answer

**es-Q0156** — Estoy viendo la casa.

I see the house.

Estar commonly locates entities and describes states or results. The same adjective with ser and estar can express different meanings. Estar plus gerund marks an ongoing situation.

Why: Estar forms. [[Spanish#^es-Q0156|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Estoy%20viendo%20la%20casa.)
^es-Q0156-answer

**es-Q0157** — Tom está en su oficina.

Tom is in his office.

Expected form: **está**

Why: Estar forms. [[Spanish#^es-Q0157|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tom%20est%C3%A1%20en%20su%20oficina.)
^es-Q0157-answer

**es-Q0158** — Tom está en su oficina.

Tom is in his office.

Expected form: **está**

Why: Estar forms. [[Spanish#^es-Q0158|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tom%20est%C3%A1%20en%20su%20oficina.)
^es-Q0158-answer

**es-Q0159** — Aquí está su menú.

Here is your menu.

Expected form: **está**

Why: Estar forms. [[Spanish#^es-Q0159|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Aqu%C3%AD%20est%C3%A1%20su%20men%C3%BA.)
^es-Q0159-answer

**es-Q0160** — Aquí está su menú.

Here is your menu.

Why: Estar forms. [[Spanish#^es-Q0160|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Aqu%C3%AD%20est%C3%A1%20su%20men%C3%BA.)
^es-Q0160-answer

**es-Q0161** — Estoy lista, ¿y usted?

I'm ready. And you?

Why: Estar forms. [[Spanish#^es-Q0161|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Estoy%20lista%2C%20%C2%BFy%20usted%3F)
^es-Q0161-answer

**es-Q0162** — Estoy lista, ¿y usted?

I'm ready. And you?

Estar commonly locates entities and describes states or results. The same adjective with ser and estar can express different meanings. Estar plus gerund marks an ongoing situation.

Why: Estar forms. [[Spanish#^es-Q0162|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Estoy%20lista%2C%20%C2%BFy%20usted%3F)
^es-Q0162-answer

**es-Q0163** — Jill está comprometida a Jack.

Jill is engaged to Jack.

Expected form: **está**

Why: Estar forms. [[Spanish#^es-Q0163|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Jill%20est%C3%A1%20comprometida%20a%20Jack.)
^es-Q0163-answer

**es-Q0164** — Jill está comprometida a Jack.

Jill is engaged to Jack.

Expected form: **está**

Why: Estar forms. [[Spanish#^es-Q0164|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Jill%20est%C3%A1%20comprometida%20a%20Jack.)
^es-Q0164-answer

**es-Q0165** — No estoy preocupado.

I'm not alarmed.

Expected form: **estoy**

Why: Estar forms. [[Spanish#^es-Q0165|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20estoy%20preocupado.)
^es-Q0165-answer

**es-Q0166** — No estoy preocupado.

I'm not alarmed.

Why: Estar forms. [[Spanish#^es-Q0166|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20estoy%20preocupado.)
^es-Q0166-answer

**es-Q0167** — Ellos están en casa ahora.

They're at home now.

Why: Estar forms. [[Spanish#^es-Q0167|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Ellos%20est%C3%A1n%20en%20casa%20ahora.)
^es-Q0167-answer

**es-Q0168** — Ellos están en casa ahora.

They're at home now.

Estar commonly locates entities and describes states or results. The same adjective with ser and estar can express different meanings. Estar plus gerund marks an ongoing situation.

Why: Estar forms. [[Spanish#^es-Q0168|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Ellos%20est%C3%A1n%20en%20casa%20ahora.)
^es-Q0168-answer

**es-Q0169** — Está cerrando todo.

He's closing everything.

Expected form: **Está**

Why: Estar forms. [[Spanish#^es-Q0169|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Est%C3%A1%20cerrando%20todo.)
^es-Q0169-answer

**es-Q0170** — Está cerrando todo.

He's closing everything.

Expected form: **Está**

Why: Estar forms. [[Spanish#^es-Q0170|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Est%C3%A1%20cerrando%20todo.)
^es-Q0170-answer

**es-Q0171** — Mary, ¿estás decente?

Mary, are you decent?

Expected form: **estás**

Why: Estar forms. [[Spanish#^es-Q0171|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Mary%2C%20%C2%BFest%C3%A1s%20decente%3F)
^es-Q0171-answer

**es-Q0172** — Mary, ¿estás decente?

Mary, are you decent?

Why: Estar forms. [[Spanish#^es-Q0172|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Mary%2C%20%C2%BFest%C3%A1s%20decente%3F)
^es-Q0172-answer

**es-Q0173** — Estoy feliz de que ganaste.

I am glad that you have succeeded.

Why: Estar forms. [[Spanish#^es-Q0173|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Estoy%20feliz%20de%20que%20ganaste.)
^es-Q0173-answer

**es-Q0174** — Estoy feliz de que ganaste.

I am glad that you have succeeded.

Estar commonly locates entities and describes states or results. The same adjective with ser and estar can express different meanings. Estar plus gerund marks an ongoing situation.

Why: Estar forms. [[Spanish#^es-Q0174|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Estoy%20feliz%20de%20que%20ganaste.)
^es-Q0174-answer

**es-Q0175** — Me temo que estamos avanzando en la dirección equivocada.

I am afraid we are advancing in the wrong direction.

Expected form: **estamos**

Why: Estar forms. [[Spanish#^es-Q0175|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Me%20temo%20que%20estamos%20avanzando%20en%20la%20direcci%C3%B3n%20equivocada.)
^es-Q0175-answer

**es-Q0176** — Me temo que estamos avanzando en la dirección equivocada.

I am afraid we are advancing in the wrong direction.

Expected form: **estamos**

Why: Estar forms. [[Spanish#^es-Q0176|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Me%20temo%20que%20estamos%20avanzando%20en%20la%20direcci%C3%B3n%20equivocada.)
^es-Q0176-answer

**es-Q0177** — Me está dando un poco de hambre.

I'm getting a little hungry.

Expected form: **está**

Why: Estar forms. [[Spanish#^es-Q0177|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Me%20est%C3%A1%20dando%20un%20poco%20de%20hambre.)
^es-Q0177-answer

**es-Q0178** — Me está dando un poco de hambre.

I'm getting a little hungry.

Why: Estar forms. [[Spanish#^es-Q0178|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Me%20est%C3%A1%20dando%20un%20poco%20de%20hambre.)
^es-Q0178-answer

**es-Q0179** — El banco está cerrado los domingos.

The bank is closed on Sunday.

Why: Estar forms. [[Spanish#^es-Q0179|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=El%20banco%20est%C3%A1%20cerrado%20los%20domingos.)
^es-Q0179-answer

**es-Q0180** — El banco está cerrado los domingos.

The bank is closed on Sunday.

Estar commonly locates entities and describes states or results. The same adjective with ser and estar can express different meanings. Estar plus gerund marks an ongoing situation.

Why: Estar forms. [[Spanish#^es-Q0180|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=El%20banco%20est%C3%A1%20cerrado%20los%20domingos.)
^es-Q0180-answer

**es-Q0181** — Las campanas de la iglesia están sonando.

The church bells are ringing.

Expected form: **están**

Why: Estar forms. [[Spanish#^es-Q0181|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Las%20campanas%20de%20la%20iglesia%20est%C3%A1n%20sonando.)
^es-Q0181-answer

**es-Q0182** — Las campanas de la iglesia están sonando.

The church bells are ringing.

Expected form: **están**

Why: Estar forms. [[Spanish#^es-Q0182|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Las%20campanas%20de%20la%20iglesia%20est%C3%A1n%20sonando.)
^es-Q0182-answer

**es-Q0183** — Nuestro televisor está averiado.

Our TV is out of order.

Expected form: **está**

Why: Estar forms. [[Spanish#^es-Q0183|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Nuestro%20televisor%20est%C3%A1%20averiado.)
^es-Q0183-answer

**es-Q0184** — Nuestro televisor está averiado.

Our TV is out of order.

Why: Estar forms. [[Spanish#^es-Q0184|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Nuestro%20televisor%20est%C3%A1%20averiado.)
^es-Q0184-answer

**es-Q0185** — Tiene 35 años y está en lo mejor de la vida.

She is 35 years old and in the prime of life.

Why: Estar forms. [[Spanish#^es-Q0185|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tiene%2035%20a%C3%B1os%20y%20est%C3%A1%20en%20lo%20mejor%20de%20la%20vida.)
^es-Q0185-answer

**es-Q0186** — Tiene 35 años y está en lo mejor de la vida.

She is 35 years old and in the prime of life.

Estar commonly locates entities and describes states or results. The same adjective with ser and estar can express different meanings. Estar plus gerund marks an ongoing situation.

Why: Estar forms. [[Spanish#^es-Q0186|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tiene%2035%20a%C3%B1os%20y%20est%C3%A1%20en%20lo%20mejor%20de%20la%20vida.)
^es-Q0186-answer

**es-Q0187** — Estamos hasta las narices de tus lamentos.

We're fed up with your complaining.

Expected form: **Estamos**

Why: Estar forms. [[Spanish#^es-Q0187|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Estamos%20hasta%20las%20narices%20de%20tus%20lamentos.)
^es-Q0187-answer

**es-Q0188** — Estamos hasta las narices de tus lamentos.

We're fed up with your complaining.

Expected form: **Estamos**

Why: Estar forms. [[Spanish#^es-Q0188|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Estamos%20hasta%20las%20narices%20de%20tus%20lamentos.)
^es-Q0188-answer

**es-Q0189** — Tom está atarantado.

Tom is restless.

Expected form: **está**

Why: Estar forms. [[Spanish#^es-Q0189|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tom%20est%C3%A1%20atarantado.)
^es-Q0189-answer

**es-Q0190** — Tom está atarantado.

Tom is restless.

Why: Estar forms. [[Spanish#^es-Q0190|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tom%20est%C3%A1%20atarantado.)
^es-Q0190-answer

**es-Q0191** — ¿Está usted aquí para ayudarnos?

Are you here to help us?

Why: Estar forms. [[Spanish#^es-Q0191|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFEst%C3%A1%20usted%20aqu%C3%AD%20para%20ayudarnos%3F)
^es-Q0191-answer

**es-Q0192** — ¿Está usted aquí para ayudarnos?

Are you here to help us?

Estar commonly locates entities and describes states or results. The same adjective with ser and estar can express different meanings. Estar plus gerund marks an ongoing situation.

Why: Estar forms. [[Spanish#^es-Q0192|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFEst%C3%A1%20usted%20aqu%C3%AD%20para%20ayudarnos%3F)
^es-Q0192-answer

**es-Q0193** — La evidencia está puesta en frente de nosotros. Considerando eso, junto con el hecho de que él no tiene coartada, no cabe duda de que él es el culpable.

The evidence is laid out before us. Considering that, together with the fact that he has no alibi, there's no question that he's the guilty one.

Expected form: **está**

Why: Estar forms. [[Spanish#^es-Q0193|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=La%20evidencia%20est%C3%A1%20puesta%20en%20frente%20de%20nosotros.%20Considerando%20eso%2C%20junto%20con%20el%20hecho%20de%20que%20%C3%A9l%20no%20tiene%20coartada%2C%20no%20cabe%20duda%20de%20que%20%C3%A9l%20es%20el%20culpable.)
^es-Q0193-answer

**es-Q0194** — La evidencia está puesta en frente de nosotros. Considerando eso, junto con el hecho de que él no tiene coartada, no cabe duda de que él es el culpable.

The evidence is laid out before us. Considering that, together with the fact that he has no alibi, there's no question that he's the guilty one.

Expected form: **está**

Why: Estar forms. [[Spanish#^es-Q0194|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=La%20evidencia%20est%C3%A1%20puesta%20en%20frente%20de%20nosotros.%20Considerando%20eso%2C%20junto%20con%20el%20hecho%20de%20que%20%C3%A9l%20no%20tiene%20coartada%2C%20no%20cabe%20duda%20de%20que%20%C3%A9l%20es%20el%20culpable.)
^es-Q0194-answer

**es-Q0195** — La economía mundial está ahora en recesión.

The world economy is in recession now.

Expected form: **está**

Why: Estar forms. [[Spanish#^es-Q0195|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=La%20econom%C3%ADa%20mundial%20est%C3%A1%20ahora%20en%20recesi%C3%B3n.)
^es-Q0195-answer

**es-Q0196** — La economía mundial está ahora en recesión.

The world economy is in recession now.

Why: Estar forms. [[Spanish#^es-Q0196|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=La%20econom%C3%ADa%20mundial%20est%C3%A1%20ahora%20en%20recesi%C3%B3n.)
^es-Q0196-answer

**es-Q0197** — Tom está calculando su sueldo.

Tom is calculating his salary.

Why: Estar forms. [[Spanish#^es-Q0197|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tom%20est%C3%A1%20calculando%20su%20sueldo.)
^es-Q0197-answer

**es-Q0198** — Tom está calculando su sueldo.

Tom is calculating his salary.

Estar commonly locates entities and describes states or results. The same adjective with ser and estar can express different meanings. Estar plus gerund marks an ongoing situation.

Why: Estar forms. [[Spanish#^es-Q0198|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tom%20est%C3%A1%20calculando%20su%20sueldo.)
^es-Q0198-answer

**es-Q0199** — Él está parado en el escenario.

He is standing on the stage.

Expected form: **está**

Why: Estar forms. [[Spanish#^es-Q0199|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C3%89l%20est%C3%A1%20parado%20en%20el%20escenario.)
^es-Q0199-answer

**es-Q0200** — Él está parado en el escenario.

He is standing on the stage.

Expected form: **está**

Why: Estar forms. [[Spanish#^es-Q0200|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C3%89l%20est%C3%A1%20parado%20en%20el%20escenario.)
^es-Q0200-answer


### Answers 201–250

**es-Q0201** — Tom le dijo a Mary lo que había pasado.

Tom told Mary what had happened.

Expected form: **había**

Why: Existence with haber. [[Spanish#^es-Q0201|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tom%20le%20dijo%20a%20Mary%20lo%20que%20hab%C3%ADa%20pasado.)
^es-Q0201-answer

**es-Q0202** — Tom le dijo a Mary lo que había pasado.

Tom told Mary what had happened.

Why: Existence with haber. [[Spanish#^es-Q0202|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tom%20le%20dijo%20a%20Mary%20lo%20que%20hab%C3%ADa%20pasado.)
^es-Q0202-answer

**es-Q0203** — No hay escapatoria.

There is no escape.

Why: Existence with haber. [[Spanish#^es-Q0203|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20hay%20escapatoria.)
^es-Q0203-answer

**es-Q0204** — No hay escapatoria.

There is no escape.

Impersonal haber states existence: hay un libro. It normally remains singular in standard usage even with a plural following noun. It differs from locating a known referent with estar.

Why: Existence with haber. [[Spanish#^es-Q0204|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20hay%20escapatoria.)
^es-Q0204-answer

**es-Q0205** — Tom se preguntó qué le había pasado a Mary.

Tom wondered what happened to Mary.

Expected form: **había**

Why: Existence with haber. [[Spanish#^es-Q0205|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tom%20se%20pregunt%C3%B3%20qu%C3%A9%20le%20hab%C3%ADa%20pasado%20a%20Mary.)
^es-Q0205-answer

**es-Q0206** — Tom se preguntó qué le había pasado a Mary.

Tom wondered what happened to Mary.

Expected form: **había**

Why: Existence with haber. [[Spanish#^es-Q0206|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tom%20se%20pregunt%C3%B3%20qu%C3%A9%20le%20hab%C3%ADa%20pasado%20a%20Mary.)
^es-Q0206-answer

**es-Q0207** — Había cincuenta concursantes para la carrera.

There were fifty entries for the race.

Expected form: **Había**

Why: Existence with haber. [[Spanish#^es-Q0207|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Hab%C3%ADa%20cincuenta%20concursantes%20para%20la%20carrera.)
^es-Q0207-answer

**es-Q0208** — Había cincuenta concursantes para la carrera.

There were fifty entries for the race.

Why: Existence with haber. [[Spanish#^es-Q0208|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Hab%C3%ADa%20cincuenta%20concursantes%20para%20la%20carrera.)
^es-Q0208-answer

**es-Q0209** — No había más preguntas.

There were no more questions.

Why: Existence with haber. [[Spanish#^es-Q0209|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20hab%C3%ADa%20m%C3%A1s%20preguntas.)
^es-Q0209-answer

**es-Q0210** — No había más preguntas.

There were no more questions.

Impersonal haber states existence: hay un libro. It normally remains singular in standard usage even with a plural following noun. It differs from locating a known referent with estar.

Why: Existence with haber. [[Spanish#^es-Q0210|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20hab%C3%ADa%20m%C3%A1s%20preguntas.)
^es-Q0210-answer

**es-Q0211** — Hay muchos terremotos en Japón.

There are many earthquakes in Japan.

Expected form: **Hay**

Why: Existence with haber. [[Spanish#^es-Q0211|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Hay%20muchos%20terremotos%20en%20Jap%C3%B3n.)
^es-Q0211-answer

**es-Q0212** — Hay muchos terremotos en Japón.

There are many earthquakes in Japan.

Expected form: **Hay**

Why: Existence with haber. [[Spanish#^es-Q0212|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Hay%20muchos%20terremotos%20en%20Jap%C3%B3n.)
^es-Q0212-answer

**es-Q0213** — ¿Cuántos pasajeros hay?

How many passengers are there?

Expected form: **hay**

Why: Existence with haber. [[Spanish#^es-Q0213|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFCu%C3%A1ntos%20pasajeros%20hay%3F)
^es-Q0213-answer

**es-Q0214** — ¿Cuántos pasajeros hay?

How many passengers are there?

Why: Existence with haber. [[Spanish#^es-Q0214|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFCu%C3%A1ntos%20pasajeros%20hay%3F)
^es-Q0214-answer

**es-Q0215** — ¿Todavía hay suficientes sillas para todos?

Are there still enough chairs for everyone?

Why: Existence with haber. [[Spanish#^es-Q0215|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFTodav%C3%ADa%20hay%20suficientes%20sillas%20para%20todos%3F)
^es-Q0215-answer

**es-Q0216** — ¿Todavía hay suficientes sillas para todos?

Are there still enough chairs for everyone?

Impersonal haber states existence: hay un libro. It normally remains singular in standard usage even with a plural following noun. It differs from locating a known referent with estar.

Why: Existence with haber. [[Spanish#^es-Q0216|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFTodav%C3%ADa%20hay%20suficientes%20sillas%20para%20todos%3F)
^es-Q0216-answer

**es-Q0217** — Mientras que existe preocupación por el desarrollo de los niños, hay incertidumbre sobre si darles mucho margen de libertad.

While there is concern about children's development, there is uncertainty about giving them a lot of lee-way.

Expected form: **hay**

Why: Existence with haber. [[Spanish#^es-Q0217|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Mientras%20que%20existe%20preocupaci%C3%B3n%20por%20el%20desarrollo%20de%20los%20ni%C3%B1os%2C%20hay%20incertidumbre%20sobre%20si%20darles%20mucho%20margen%20de%20libertad.)
^es-Q0217-answer

**es-Q0218** — Mientras que existe preocupación por el desarrollo de los niños, hay incertidumbre sobre si darles mucho margen de libertad.

While there is concern about children's development, there is uncertainty about giving them a lot of lee-way.

Expected form: **hay**

Why: Existence with haber. [[Spanish#^es-Q0218|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Mientras%20que%20existe%20preocupaci%C3%B3n%20por%20el%20desarrollo%20de%20los%20ni%C3%B1os%2C%20hay%20incertidumbre%20sobre%20si%20darles%20mucho%20margen%20de%20libertad.)
^es-Q0218-answer

**es-Q0219** — No hay mucha lógica en lo que dices.

There isn't much logic in what you're saying.

Expected form: **hay**

Why: Existence with haber. [[Spanish#^es-Q0219|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20hay%20mucha%20l%C3%B3gica%20en%20lo%20que%20dices.)
^es-Q0219-answer

**es-Q0220** — No hay mucha lógica en lo que dices.

There isn't much logic in what you're saying.

Why: Existence with haber. [[Spanish#^es-Q0220|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20hay%20mucha%20l%C3%B3gica%20en%20lo%20que%20dices.)
^es-Q0220-answer

**es-Q0221** — ¿Hay agua caliente?

Is there hot water?

Why: Existence with haber. [[Spanish#^es-Q0221|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFHay%20agua%20caliente%3F)
^es-Q0221-answer

**es-Q0222** — ¿Hay agua caliente?

Is there hot water?

Impersonal haber states existence: hay un libro. It normally remains singular in standard usage even with a plural following noun. It differs from locating a known referent with estar.

Why: Existence with haber. [[Spanish#^es-Q0222|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFHay%20agua%20caliente%3F)
^es-Q0222-answer

**es-Q0223** — Había una limusina esperando a Tom afuera del hotel.

There was a limousine waiting for Tom outside the hotel.

Expected form: **Había**

Why: Existence with haber. [[Spanish#^es-Q0223|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Hab%C3%ADa%20una%20limusina%20esperando%20a%20Tom%20afuera%20del%20hotel.)
^es-Q0223-answer

**es-Q0224** — Había una limusina esperando a Tom afuera del hotel.

There was a limousine waiting for Tom outside the hotel.

Expected form: **Había**

Why: Existence with haber. [[Spanish#^es-Q0224|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Hab%C3%ADa%20una%20limusina%20esperando%20a%20Tom%20afuera%20del%20hotel.)
^es-Q0224-answer

**es-Q0225** — Hay frases que todo el mundo conoce.

There are sentences which everybody knows.

Expected form: **Hay**

Why: Existence with haber. [[Spanish#^es-Q0225|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Hay%20frases%20que%20todo%20el%20mundo%20conoce.)
^es-Q0225-answer

**es-Q0226** — Hay frases que todo el mundo conoce.

There are sentences which everybody knows.

Why: Existence with haber. [[Spanish#^es-Q0226|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Hay%20frases%20que%20todo%20el%20mundo%20conoce.)
^es-Q0226-answer

**es-Q0227** — Yo no había vuelto aquí desde el incidente.

I haven't been back here since the incident.

Why: Existence with haber. [[Spanish#^es-Q0227|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Yo%20no%20hab%C3%ADa%20vuelto%20aqu%C3%AD%20desde%20el%20incidente.)
^es-Q0227-answer

**es-Q0228** — Yo no había vuelto aquí desde el incidente.

I haven't been back here since the incident.

Impersonal haber states existence: hay un libro. It normally remains singular in standard usage even with a plural following noun. It differs from locating a known referent with estar.

Why: Existence with haber. [[Spanish#^es-Q0228|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Yo%20no%20hab%C3%ADa%20vuelto%20aqu%C3%AD%20desde%20el%20incidente.)
^es-Q0228-answer

**es-Q0229** — Hay algo ahí.

There's something there.

Expected form: **Hay**

Why: Existence with haber. [[Spanish#^es-Q0229|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Hay%20algo%20ah%C3%AD.)
^es-Q0229-answer

**es-Q0230** — Hay algo ahí.

There's something there.

Expected form: **Hay**

Why: Existence with haber. [[Spanish#^es-Q0230|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Hay%20algo%20ah%C3%AD.)
^es-Q0230-answer

**es-Q0231** — ¿Cuántas preguntas había en el test?

How many questions were there on the test?

Expected form: **había**

Why: Existence with haber. [[Spanish#^es-Q0231|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFCu%C3%A1ntas%20preguntas%20hab%C3%ADa%20en%20el%20test%3F)
^es-Q0231-answer

**es-Q0232** — ¿Cuántas preguntas había en el test?

How many questions were there on the test?

Why: Existence with haber. [[Spanish#^es-Q0232|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFCu%C3%A1ntas%20preguntas%20hab%C3%ADa%20en%20el%20test%3F)
^es-Q0232-answer

**es-Q0233** — Nunca había visto una cosa así.

Never have I seen such a thing.

Why: Existence with haber. [[Spanish#^es-Q0233|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Nunca%20hab%C3%ADa%20visto%20una%20cosa%20as%C3%AD.)
^es-Q0233-answer

**es-Q0234** — Nunca había visto una cosa así.

Never have I seen such a thing.

Impersonal haber states existence: hay un libro. It normally remains singular in standard usage even with a plural following noun. It differs from locating a known referent with estar.

Why: Existence with haber. [[Spanish#^es-Q0234|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Nunca%20hab%C3%ADa%20visto%20una%20cosa%20as%C3%AD.)
^es-Q0234-answer

**es-Q0235** — Cuando los padres están lejos de sus hijos, no hay nada que puedan hacer respecto a su seguridad o su bienestar.

When parents are far away from their children, there is nothing they can do about their safety or welfare.

Expected form: **hay**

Why: Existence with haber. [[Spanish#^es-Q0235|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Cuando%20los%20padres%20est%C3%A1n%20lejos%20de%20sus%20hijos%2C%20no%20hay%20nada%20que%20puedan%20hacer%20respecto%20a%20su%20seguridad%20o%20su%20bienestar.)
^es-Q0235-answer

**es-Q0236** — Cuando los padres están lejos de sus hijos, no hay nada que puedan hacer respecto a su seguridad o su bienestar.

When parents are far away from their children, there is nothing they can do about their safety or welfare.

Expected form: **hay**

Why: Existence with haber. [[Spanish#^es-Q0236|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Cuando%20los%20padres%20est%C3%A1n%20lejos%20de%20sus%20hijos%2C%20no%20hay%20nada%20que%20puedan%20hacer%20respecto%20a%20su%20seguridad%20o%20su%20bienestar.)
^es-Q0236-answer

**es-Q0237** — Hay treinta personas aquí.

There are thirty people here.

Expected form: **Hay**

Why: Existence with haber. [[Spanish#^es-Q0237|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Hay%20treinta%20personas%20aqu%C3%AD.)
^es-Q0237-answer

**es-Q0238** — Hay treinta personas aquí.

There are thirty people here.

Why: Existence with haber. [[Spanish#^es-Q0238|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Hay%20treinta%20personas%20aqu%C3%AD.)
^es-Q0238-answer

**es-Q0239** — ¿Qué hay de mí?

What about me?

Why: Existence with haber. [[Spanish#^es-Q0239|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFQu%C3%A9%20hay%20de%20m%C3%AD%3F)
^es-Q0239-answer

**es-Q0240** — ¿Qué hay de mí?

What about me?

Impersonal haber states existence: hay un libro. It normally remains singular in standard usage even with a plural following noun. It differs from locating a known referent with estar.

Why: Existence with haber. [[Spanish#^es-Q0240|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFQu%C3%A9%20hay%20de%20m%C3%AD%3F)
^es-Q0240-answer

**es-Q0241** — En este asunto hay que caminar con pies de plomo.

You have to move cautiously in this matter.

Expected form: **hay**

Why: Existence with haber. [[Spanish#^es-Q0241|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=En%20este%20asunto%20hay%20que%20caminar%20con%20pies%20de%20plomo.)
^es-Q0241-answer

**es-Q0242** — En este asunto hay que caminar con pies de plomo.

You have to move cautiously in this matter.

Expected form: **hay**

Why: Existence with haber. [[Spanish#^es-Q0242|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=En%20este%20asunto%20hay%20que%20caminar%20con%20pies%20de%20plomo.)
^es-Q0242-answer

**es-Q0243** — Ahora bien, hay que aclarar este problema.

Now then, let's get this problem cleared up.

Expected form: **hay**

Why: Existence with haber. [[Spanish#^es-Q0243|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Ahora%20bien%2C%20hay%20que%20aclarar%20este%20problema.)
^es-Q0243-answer

**es-Q0244** — Ahora bien, hay que aclarar este problema.

Now then, let's get this problem cleared up.

Why: Existence with haber. [[Spanish#^es-Q0244|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Ahora%20bien%2C%20hay%20que%20aclarar%20este%20problema.)
^es-Q0244-answer

**es-Q0245** — En toda cosa hay que considerar el fin.

In everything, one should consider the end.

Why: Existence with haber. [[Spanish#^es-Q0245|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=En%20toda%20cosa%20hay%20que%20considerar%20el%20fin.)
^es-Q0245-answer

**es-Q0246** — En toda cosa hay que considerar el fin.

In everything, one should consider the end.

Impersonal haber states existence: hay un libro. It normally remains singular in standard usage even with a plural following noun. It differs from locating a known referent with estar.

Why: Existence with haber. [[Spanish#^es-Q0246|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=En%20toda%20cosa%20hay%20que%20considerar%20el%20fin.)
^es-Q0246-answer

**es-Q0247** — ¿Hay algo extraño?

Is there anything strange?

Expected form: **Hay**

Why: Existence with haber. [[Spanish#^es-Q0247|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFHay%20algo%20extra%C3%B1o%3F)
^es-Q0247-answer

**es-Q0248** — ¿Hay algo extraño?

Is there anything strange?

Expected form: **Hay**

Why: Existence with haber. [[Spanish#^es-Q0248|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFHay%20algo%20extra%C3%B1o%3F)
^es-Q0248-answer

**es-Q0249** — ¿Cuándo descubriste que tu hermana se había muerto?

When did you find out that your sister had died?

Expected form: **había**

Why: Existence with haber. [[Spanish#^es-Q0249|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFCu%C3%A1ndo%20descubriste%20que%20tu%20hermana%20se%20hab%C3%ADa%20muerto%3F)
^es-Q0249-answer

**es-Q0250** — ¿Cuándo descubriste que tu hermana se había muerto?

When did you find out that your sister had died?

Why: Existence with haber. [[Spanish#^es-Q0250|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFCu%C3%A1ndo%20descubriste%20que%20tu%20hermana%20se%20hab%C3%ADa%20muerto%3F)
^es-Q0250-answer


### Answers 251–300

**es-Q0251** — Él tiene mucho pegue.

He's got lots of sex appeal.

Why: Present possession. [[Spanish#^es-Q0251|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C3%89l%20tiene%20mucho%20pegue.)
^es-Q0251-answer

**es-Q0252** — Él tiene mucho pegue.

He's got lots of sex appeal.

Tener agrees with the subject and expresses possession. It also occurs in expressions such as tener hambre and tener que + infinitive. Spanish often omits an understood subject pronoun.

Why: Present possession. [[Spanish#^es-Q0252|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C3%89l%20tiene%20mucho%20pegue.)
^es-Q0252-answer

**es-Q0253** — No tienen ningún impacto sobre el ambiente.

They have no impact on the environment.

Expected form: **tienen**

Why: Present possession. [[Spanish#^es-Q0253|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20tienen%20ning%C3%BAn%20impacto%20sobre%20el%20ambiente.)
^es-Q0253-answer

**es-Q0254** — No tienen ningún impacto sobre el ambiente.

They have no impact on the environment.

Expected form: **tienen**

Why: Present possession. [[Spanish#^es-Q0254|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20tienen%20ning%C3%BAn%20impacto%20sobre%20el%20ambiente.)
^es-Q0254-answer

**es-Q0255** — ¿Cuánto tiempo tengo que quedarme aquí?

How long do I have to stay here?

Expected form: **tengo**

Why: Present possession. [[Spanish#^es-Q0255|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFCu%C3%A1nto%20tiempo%20tengo%20que%20quedarme%20aqu%C3%AD%3F)
^es-Q0255-answer

**es-Q0256** — ¿Cuánto tiempo tengo que quedarme aquí?

How long do I have to stay here?

Why: Present possession. [[Spanish#^es-Q0256|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFCu%C3%A1nto%20tiempo%20tengo%20que%20quedarme%20aqu%C3%AD%3F)
^es-Q0256-answer

**es-Q0257** — Tienes un teléfono en tu casa.

You have a telephone at your house.

Why: Present possession. [[Spanish#^es-Q0257|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tienes%20un%20tel%C3%A9fono%20en%20tu%20casa.)
^es-Q0257-answer

**es-Q0258** — Tienes un teléfono en tu casa.

You have a telephone at your house.

Tener agrees with the subject and expresses possession. It also occurs in expressions such as tener hambre and tener que + infinitive. Spanish often omits an understood subject pronoun.

Why: Present possession. [[Spanish#^es-Q0258|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tienes%20un%20tel%C3%A9fono%20en%20tu%20casa.)
^es-Q0258-answer

**es-Q0259** — No tenemos idea de su paradero.

We have no idea about his whereabouts.

Expected form: **tenemos**

Why: Present possession. [[Spanish#^es-Q0259|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20tenemos%20idea%20de%20su%20paradero.)
^es-Q0259-answer

**es-Q0260** — No tenemos idea de su paradero.

We have no idea about his whereabouts.

Expected form: **tenemos**

Why: Present possession. [[Spanish#^es-Q0260|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20tenemos%20idea%20de%20su%20paradero.)
^es-Q0260-answer

**es-Q0261** — Tengo que hacer un intento.

I have to try.

Expected form: **Tengo**

Why: Present possession. [[Spanish#^es-Q0261|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tengo%20que%20hacer%20un%20intento.)
^es-Q0261-answer

**es-Q0262** — Tengo que hacer un intento.

I have to try.

Why: Present possession. [[Spanish#^es-Q0262|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tengo%20que%20hacer%20un%20intento.)
^es-Q0262-answer

**es-Q0263** — Las computadoras aprendieron a jugar al ajedrez hace muchos años, pero no siempre tuvieron la fuerza que tienen hoy.

Computers learned to play chess many years ago, but they didn't always have the strength they have today.

Why: Present possession. [[Spanish#^es-Q0263|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Las%20computadoras%20aprendieron%20a%20jugar%20al%20ajedrez%20hace%20muchos%20a%C3%B1os%2C%20pero%20no%20siempre%20tuvieron%20la%20fuerza%20que%20tienen%20hoy.)
^es-Q0263-answer

**es-Q0264** — Las computadoras aprendieron a jugar al ajedrez hace muchos años, pero no siempre tuvieron la fuerza que tienen hoy.

Computers learned to play chess many years ago, but they didn't always have the strength they have today.

Tener agrees with the subject and expresses possession. It also occurs in expressions such as tener hambre and tener que + infinitive. Spanish often omits an understood subject pronoun.

Why: Present possession. [[Spanish#^es-Q0264|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Las%20computadoras%20aprendieron%20a%20jugar%20al%20ajedrez%20hace%20muchos%20a%C3%B1os%2C%20pero%20no%20siempre%20tuvieron%20la%20fuerza%20que%20tienen%20hoy.)
^es-Q0264-answer

**es-Q0265** — La sala tiene una capacidad de 200 asientos.

The room has a seating capacity of 200.

Expected form: **tiene**

Why: Present possession. [[Spanish#^es-Q0265|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=La%20sala%20tiene%20una%20capacidad%20de%20200%20asientos.)
^es-Q0265-answer

**es-Q0266** — La sala tiene una capacidad de 200 asientos.

The room has a seating capacity of 200.

Expected form: **tiene**

Why: Present possession. [[Spanish#^es-Q0266|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=La%20sala%20tiene%20una%20capacidad%20de%20200%20asientos.)
^es-Q0266-answer

**es-Q0267** — Pedro no tiene ninguna hermana.

Pedro doesn't have a sister.

Expected form: **tiene**

Why: Present possession. [[Spanish#^es-Q0267|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Pedro%20no%20tiene%20ninguna%20hermana.)
^es-Q0267-answer

**es-Q0268** — Pedro no tiene ninguna hermana.

Pedro doesn't have a sister.

Why: Present possession. [[Spanish#^es-Q0268|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Pedro%20no%20tiene%20ninguna%20hermana.)
^es-Q0268-answer

**es-Q0269** — La gente joven muy a menudo tiene las ideas novedosas.

Young people have new ideas very often.

Why: Present possession. [[Spanish#^es-Q0269|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=La%20gente%20joven%20muy%20a%20menudo%20tiene%20las%20ideas%20novedosas.)
^es-Q0269-answer

**es-Q0270** — La gente joven muy a menudo tiene las ideas novedosas.

Young people have new ideas very often.

Tener agrees with the subject and expresses possession. It also occurs in expressions such as tener hambre and tener que + infinitive. Spanish often omits an understood subject pronoun.

Why: Present possession. [[Spanish#^es-Q0270|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=La%20gente%20joven%20muy%20a%20menudo%20tiene%20las%20ideas%20novedosas.)
^es-Q0270-answer

**es-Q0271** — ¿No tienes miedo?

Aren't you afraid?

Expected form: **tienes**

Why: Present possession. [[Spanish#^es-Q0271|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFNo%20tienes%20miedo%3F)
^es-Q0271-answer

**es-Q0272** — ¿No tienes miedo?

Aren't you afraid?

Expected form: **tienes**

Why: Present possession. [[Spanish#^es-Q0272|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFNo%20tienes%20miedo%3F)
^es-Q0272-answer

**es-Q0273** — Aquí tiene la lista de hoteles de la capital y de la provincia.

Here's a list of hotels in the capital and province.

Expected form: **tiene**

Why: Present possession. [[Spanish#^es-Q0273|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Aqu%C3%AD%20tiene%20la%20lista%20de%20hoteles%20de%20la%20capital%20y%20de%20la%20provincia.)
^es-Q0273-answer

**es-Q0274** — Aquí tiene la lista de hoteles de la capital y de la provincia.

Here's a list of hotels in the capital and province.

Why: Present possession. [[Spanish#^es-Q0274|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Aqu%C3%AD%20tiene%20la%20lista%20de%20hoteles%20de%20la%20capital%20y%20de%20la%20provincia.)
^es-Q0274-answer

**es-Q0275** — Incluso el agua contaminada que no tiene otro propósito, puede apagar un fuego.

Even if polluted water serves no other purpose, it can put out a fire.

Why: Present possession. [[Spanish#^es-Q0275|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Incluso%20el%20agua%20contaminada%20que%20no%20tiene%20otro%20prop%C3%B3sito%2C%20puede%20apagar%20un%20fuego.)
^es-Q0275-answer

**es-Q0276** — Incluso el agua contaminada que no tiene otro propósito, puede apagar un fuego.

Even if polluted water serves no other purpose, it can put out a fire.

Tener agrees with the subject and expresses possession. It also occurs in expressions such as tener hambre and tener que + infinitive. Spanish often omits an understood subject pronoun.

Why: Present possession. [[Spanish#^es-Q0276|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Incluso%20el%20agua%20contaminada%20que%20no%20tiene%20otro%20prop%C3%B3sito%2C%20puede%20apagar%20un%20fuego.)
^es-Q0276-answer

**es-Q0277** — ¿Tiene algo más barato?

Do you have anything cheaper?

Expected form: **Tiene**

Why: Present possession. [[Spanish#^es-Q0277|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFTiene%20algo%20m%C3%A1s%20barato%3F)
^es-Q0277-answer

**es-Q0278** — ¿Tiene algo más barato?

Do you have anything cheaper?

Expected form: **Tiene**

Why: Present possession. [[Spanish#^es-Q0278|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFTiene%20algo%20m%C3%A1s%20barato%3F)
^es-Q0278-answer

**es-Q0279** — ¿Cuántas cobijas tiene la cama?

How many blankets are there on the bed?

Expected form: **tiene**

Why: Present possession. [[Spanish#^es-Q0279|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFCu%C3%A1ntas%20cobijas%20tiene%20la%20cama%3F)
^es-Q0279-answer

**es-Q0280** — ¿Cuántas cobijas tiene la cama?

How many blankets are there on the bed?

Why: Present possession. [[Spanish#^es-Q0280|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFCu%C3%A1ntas%20cobijas%20tiene%20la%20cama%3F)
^es-Q0280-answer

**es-Q0281** — Tom no le tiene que prestar atención a lo que Mary dice.

Tom doesn't have to pay attention to what Mary says.

Why: Present possession. [[Spanish#^es-Q0281|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tom%20no%20le%20tiene%20que%20prestar%20atenci%C3%B3n%20a%20lo%20que%20Mary%20dice.)
^es-Q0281-answer

**es-Q0282** — Tom no le tiene que prestar atención a lo que Mary dice.

Tom doesn't have to pay attention to what Mary says.

Tener agrees with the subject and expresses possession. It also occurs in expressions such as tener hambre and tener que + infinitive. Spanish often omits an understood subject pronoun.

Why: Present possession. [[Spanish#^es-Q0282|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tom%20no%20le%20tiene%20que%20prestar%20atenci%C3%B3n%20a%20lo%20que%20Mary%20dice.)
^es-Q0282-answer

**es-Q0283** — Tiene talento para el dibujo.

He has a gift for drawing.

Expected form: **Tiene**

Why: Present possession. [[Spanish#^es-Q0283|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tiene%20talento%20para%20el%20dibujo.)
^es-Q0283-answer

**es-Q0284** — Tiene talento para el dibujo.

He has a gift for drawing.

Expected form: **Tiene**

Why: Present possession. [[Spanish#^es-Q0284|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tiene%20talento%20para%20el%20dibujo.)
^es-Q0284-answer

**es-Q0285** — Tenemos un acuerdo.

We have an agreement.

Expected form: **Tenemos**

Why: Present possession. [[Spanish#^es-Q0285|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tenemos%20un%20acuerdo.)
^es-Q0285-answer

**es-Q0286** — Tenemos un acuerdo.

We have an agreement.

Why: Present possession. [[Spanish#^es-Q0286|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tenemos%20un%20acuerdo.)
^es-Q0286-answer

**es-Q0287** — Tienes que tener paciencia.

You have to be patient.

Why: Present possession. [[Spanish#^es-Q0287|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tienes%20que%20tener%20paciencia.)
^es-Q0287-answer

**es-Q0288** — Tienes que tener paciencia.

You have to be patient.

Tener agrees with the subject and expresses possession. It also occurs in expressions such as tener hambre and tener que + infinitive. Spanish often omits an understood subject pronoun.

Why: Present possession. [[Spanish#^es-Q0288|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tienes%20que%20tener%20paciencia.)
^es-Q0288-answer

**es-Q0289** — Tom tiene cosas más importantes de que preocuparse.

Tom has more important things to worry about.

Expected form: **tiene**

Why: Present possession. [[Spanish#^es-Q0289|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tom%20tiene%20cosas%20m%C3%A1s%20importantes%20de%20que%20preocuparse.)
^es-Q0289-answer

**es-Q0290** — Tom tiene cosas más importantes de que preocuparse.

Tom has more important things to worry about.

Expected form: **tiene**

Why: Present possession. [[Spanish#^es-Q0290|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tom%20tiene%20cosas%20m%C3%A1s%20importantes%20de%20que%20preocuparse.)
^es-Q0290-answer

**es-Q0291** — ¿Tienes hermanos o hermanas?

Do you have brothers and sisters?

Expected form: **Tienes**

Why: Present possession. [[Spanish#^es-Q0291|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFTienes%20hermanos%20o%20hermanas%3F)
^es-Q0291-answer

**es-Q0292** — ¿Tienes hermanos o hermanas?

Do you have brothers and sisters?

Why: Present possession. [[Spanish#^es-Q0292|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFTienes%20hermanos%20o%20hermanas%3F)
^es-Q0292-answer

**es-Q0293** — Tengo una pregunta para vosotras.

I have one question for you.

Why: Present possession. [[Spanish#^es-Q0293|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tengo%20una%20pregunta%20para%20vosotras.)
^es-Q0293-answer

**es-Q0294** — Tengo una pregunta para vosotras.

I have one question for you.

Tener agrees with the subject and expresses possession. It also occurs in expressions such as tener hambre and tener que + infinitive. Spanish often omits an understood subject pronoun.

Why: Present possession. [[Spanish#^es-Q0294|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tengo%20una%20pregunta%20para%20vosotras.)
^es-Q0294-answer

**es-Q0295** — John tiene un auto de Japón.

John has a car from Japan.

Expected form: **tiene**

Why: Present possession. [[Spanish#^es-Q0295|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=John%20tiene%20un%20auto%20de%20Jap%C3%B3n.)
^es-Q0295-answer

**es-Q0296** — John tiene un auto de Japón.

John has a car from Japan.

Expected form: **tiene**

Why: Present possession. [[Spanish#^es-Q0296|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=John%20tiene%20un%20auto%20de%20Jap%C3%B3n.)
^es-Q0296-answer

**es-Q0297** — Tenemos cinco dedos en cada mano.

We have five fingers on each hand.

Expected form: **Tenemos**

Why: Present possession. [[Spanish#^es-Q0297|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tenemos%20cinco%20dedos%20en%20cada%20mano.)
^es-Q0297-answer

**es-Q0298** — Tenemos cinco dedos en cada mano.

We have five fingers on each hand.

Why: Present possession. [[Spanish#^es-Q0298|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tenemos%20cinco%20dedos%20en%20cada%20mano.)
^es-Q0298-answer

**es-Q0299** — Tengo el triple de dinero que tú.

I have three times as much money as you.

Why: Present possession. [[Spanish#^es-Q0299|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tengo%20el%20triple%20de%20dinero%20que%20t%C3%BA.)
^es-Q0299-answer

**es-Q0300** — Tengo el triple de dinero que tú.

I have three times as much money as you.

Tener agrees with the subject and expresses possession. It also occurs in expressions such as tener hambre and tener que + infinitive. Spanish often omits an understood subject pronoun.

Why: Present possession. [[Spanish#^es-Q0300|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tengo%20el%20triple%20de%20dinero%20que%20t%C3%BA.)
^es-Q0300-answer


### Answers 301–350

**es-Q0301** — Ella estaba profundamente emocionada.

She was deeply moved.

Expected form: **estaba**

Why: Past background. [[Spanish#^es-Q0301|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Ella%20estaba%20profundamente%20emocionada.)
^es-Q0301-answer

**es-Q0302** — Ella estaba profundamente emocionada.

She was deeply moved.

Expected form: **estaba**

Why: Past background. [[Spanish#^es-Q0302|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Ella%20estaba%20profundamente%20emocionada.)
^es-Q0302-answer

**es-Q0303** — Los antiguos egipcios creían que el Sol era el ojo del dios Ra.

The ancient Egyptians believed that the Sun was the eye of the god Ra.

Expected form: **era**

Why: Past background. [[Spanish#^es-Q0303|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Los%20antiguos%20egipcios%20cre%C3%ADan%20que%20el%20Sol%20era%20el%20ojo%20del%20dios%20Ra.)
^es-Q0303-answer

**es-Q0304** — Los antiguos egipcios creían que el Sol era el ojo del dios Ra.

The ancient Egyptians believed that the Sun was the eye of the god Ra.

Why: Past background. [[Spanish#^es-Q0304|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Los%20antiguos%20egipcios%20cre%C3%ADan%20que%20el%20Sol%20era%20el%20ojo%20del%20dios%20Ra.)
^es-Q0304-answer

**es-Q0305** — Cuando mi madre era joven, era muy guapa.

When my mother was young, she was very beautiful.

Why: Past background. [[Spanish#^es-Q0305|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Cuando%20mi%20madre%20era%20joven%2C%20era%20muy%20guapa.)
^es-Q0305-answer

**es-Q0306** — Cuando mi madre era joven, era muy guapa.

When my mother was young, she was very beautiful.

The imperfect typically presents background, a past state or a habit. A preterite presents an event as bounded in its narrative frame. The difference is viewpoint, not a simple long/short duration rule.

Why: Past background. [[Spanish#^es-Q0306|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Cuando%20mi%20madre%20era%20joven%2C%20era%20muy%20guapa.)
^es-Q0306-answer

**es-Q0307** — Mi abuela era granjera.

My grandmother was a farmer.

Expected form: **era**

Why: Past background. [[Spanish#^es-Q0307|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Mi%20abuela%20era%20granjera.)
^es-Q0307-answer

**es-Q0308** — Mi abuela era granjera.

My grandmother was a farmer.

Expected form: **era**

Why: Past background. [[Spanish#^es-Q0308|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Mi%20abuela%20era%20granjera.)
^es-Q0308-answer

**es-Q0309** — Quería vivir solo, no en una casa de retiro.

I wanted to live alone, not in a retirement home.

Expected form: **Quería**

Why: Past background. [[Spanish#^es-Q0309|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Quer%C3%ADa%20vivir%20solo%2C%20no%20en%20una%20casa%20de%20retiro.)
^es-Q0309-answer

**es-Q0310** — Quería vivir solo, no en una casa de retiro.

I wanted to live alone, not in a retirement home.

Why: Past background. [[Spanish#^es-Q0310|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Quer%C3%ADa%20vivir%20solo%2C%20no%20en%20una%20casa%20de%20retiro.)
^es-Q0310-answer

**es-Q0311** — Tenía muchas ganas de ir a la fiesta, pero no pude.

I really wanted to go to the party, but I couldn't.

Why: Past background. [[Spanish#^es-Q0311|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Ten%C3%ADa%20muchas%20ganas%20de%20ir%20a%20la%20fiesta%2C%20pero%20no%20pude.)
^es-Q0311-answer

**es-Q0312** — Tenía muchas ganas de ir a la fiesta, pero no pude.

I really wanted to go to the party, but I couldn't.

The imperfect typically presents background, a past state or a habit. A preterite presents an event as bounded in its narrative frame. The difference is viewpoint, not a simple long/short duration rule.

Why: Past background. [[Spanish#^es-Q0312|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Ten%C3%ADa%20muchas%20ganas%20de%20ir%20a%20la%20fiesta%2C%20pero%20no%20pude.)
^es-Q0312-answer

**es-Q0313** — La noche estaba fresca.

The night was cool.

Expected form: **estaba**

Why: Past background. [[Spanish#^es-Q0313|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=La%20noche%20estaba%20fresca.)
^es-Q0313-answer

**es-Q0314** — La noche estaba fresca.

The night was cool.

Expected form: **estaba**

Why: Past background. [[Spanish#^es-Q0314|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=La%20noche%20estaba%20fresca.)
^es-Q0314-answer

**es-Q0315** — Mucha gente le estaba esperando.

A lot of people were waiting for him.

Expected form: **estaba**

Why: Past background. [[Spanish#^es-Q0315|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Mucha%20gente%20le%20estaba%20esperando.)
^es-Q0315-answer

**es-Q0316** — Mucha gente le estaba esperando.

A lot of people were waiting for him.

Why: Past background. [[Spanish#^es-Q0316|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Mucha%20gente%20le%20estaba%20esperando.)
^es-Q0316-answer

**es-Q0317** — Estaba muy oscuro.

It was very dark.

Why: Past background. [[Spanish#^es-Q0317|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Estaba%20muy%20oscuro.)
^es-Q0317-answer

**es-Q0318** — Estaba muy oscuro.

It was very dark.

The imperfect typically presents background, a past state or a habit. A preterite presents an event as bounded in its narrative frame. The difference is viewpoint, not a simple long/short duration rule.

Why: Past background. [[Spanish#^es-Q0318|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Estaba%20muy%20oscuro.)
^es-Q0318-answer

**es-Q0319** — Él era inglés.

He was English.

Expected form: **era**

Why: Past background. [[Spanish#^es-Q0319|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C3%89l%20era%20ingl%C3%A9s.)
^es-Q0319-answer

**es-Q0320** — Él era inglés.

He was English.

Expected form: **era**

Why: Past background. [[Spanish#^es-Q0320|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C3%89l%20era%20ingl%C3%A9s.)
^es-Q0320-answer

**es-Q0321** — No quería que las cosas acabaran así.

I didn't want things to end up like this.

Expected form: **quería**

Why: Past background. [[Spanish#^es-Q0321|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20quer%C3%ADa%20que%20las%20cosas%20acabaran%20as%C3%AD.)
^es-Q0321-answer

**es-Q0322** — No quería que las cosas acabaran así.

I didn't want things to end up like this.

Why: Past background. [[Spanish#^es-Q0322|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20quer%C3%ADa%20que%20las%20cosas%20acabaran%20as%C3%AD.)
^es-Q0322-answer

**es-Q0323** — Traté de levantarme, pero mi cuerpo estaba pesado como plomo.

I attempted to get up, but my body was heavy as lead.

Why: Past background. [[Spanish#^es-Q0323|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Trat%C3%A9%20de%20levantarme%2C%20pero%20mi%20cuerpo%20estaba%20pesado%20como%20plomo.)
^es-Q0323-answer

**es-Q0324** — Traté de levantarme, pero mi cuerpo estaba pesado como plomo.

I attempted to get up, but my body was heavy as lead.

The imperfect typically presents background, a past state or a habit. A preterite presents an event as bounded in its narrative frame. The difference is viewpoint, not a simple long/short duration rule.

Why: Past background. [[Spanish#^es-Q0324|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Trat%C3%A9%20de%20levantarme%2C%20pero%20mi%20cuerpo%20estaba%20pesado%20como%20plomo.)
^es-Q0324-answer

**es-Q0325** — Yo estaba hablando con Andrea cuando Valentina interrumpió.

I was talking to Andrea when Valentina broke in.

Expected form: **estaba**

Why: Past background. [[Spanish#^es-Q0325|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Yo%20estaba%20hablando%20con%20Andrea%20cuando%20Valentina%20interrumpi%C3%B3.)
^es-Q0325-answer

**es-Q0326** — Yo estaba hablando con Andrea cuando Valentina interrumpió.

I was talking to Andrea when Valentina broke in.

Expected form: **estaba**

Why: Past background. [[Spanish#^es-Q0326|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Yo%20estaba%20hablando%20con%20Andrea%20cuando%20Valentina%20interrumpi%C3%B3.)
^es-Q0326-answer

**es-Q0327** — Ella no quería ofender a nadie con su comentario.

She didn't mean to offend anyone with her remark.

Expected form: **quería**

Why: Past background. [[Spanish#^es-Q0327|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Ella%20no%20quer%C3%ADa%20ofender%20a%20nadie%20con%20su%20comentario.)
^es-Q0327-answer

**es-Q0328** — Ella no quería ofender a nadie con su comentario.

She didn't mean to offend anyone with her remark.

Why: Past background. [[Spanish#^es-Q0328|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Ella%20no%20quer%C3%ADa%20ofender%20a%20nadie%20con%20su%20comentario.)
^es-Q0328-answer

**es-Q0329** — Se estaba haciendo tarde.

It was getting late.

Why: Past background. [[Spanish#^es-Q0329|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Se%20estaba%20haciendo%20tarde.)
^es-Q0329-answer

**es-Q0330** — Se estaba haciendo tarde.

It was getting late.

The imperfect typically presents background, a past state or a habit. A preterite presents an event as bounded in its narrative frame. The difference is viewpoint, not a simple long/short duration rule.

Why: Past background. [[Spanish#^es-Q0330|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Se%20estaba%20haciendo%20tarde.)
^es-Q0330-answer

**es-Q0331** — Tom tenía expectativas demasiado altas.

Tom's expectations were too high.

Expected form: **tenía**

Why: Past background. [[Spanish#^es-Q0331|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tom%20ten%C3%ADa%20expectativas%20demasiado%20altas.)
^es-Q0331-answer

**es-Q0332** — Tom tenía expectativas demasiado altas.

Tom's expectations were too high.

Expected form: **tenía**

Why: Past background. [[Spanish#^es-Q0332|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tom%20ten%C3%ADa%20expectativas%20demasiado%20altas.)
^es-Q0332-answer

**es-Q0333** — Tenía la esperanza de ahorrar más dinero.

I had hoped to save more money.

Expected form: **Tenía**

Why: Past background. [[Spanish#^es-Q0333|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Ten%C3%ADa%20la%20esperanza%20de%20ahorrar%20m%C3%A1s%20dinero.)
^es-Q0333-answer

**es-Q0334** — Tenía la esperanza de ahorrar más dinero.

I had hoped to save more money.

Why: Past background. [[Spanish#^es-Q0334|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Ten%C3%ADa%20la%20esperanza%20de%20ahorrar%20m%C3%A1s%20dinero.)
^es-Q0334-answer

**es-Q0335** — No sabía que Guillermo y Tamara eran hermanos.

I didn't know Guillermo and Tamara were brother and sister.

Why: Past background. [[Spanish#^es-Q0335|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20sab%C3%ADa%20que%20Guillermo%20y%20Tamara%20eran%20hermanos.)
^es-Q0335-answer

**es-Q0336** — No sabía que Guillermo y Tamara eran hermanos.

I didn't know Guillermo and Tamara were brother and sister.

The imperfect typically presents background, a past state or a habit. A preterite presents an event as bounded in its narrative frame. The difference is viewpoint, not a simple long/short duration rule.

Why: Past background. [[Spanish#^es-Q0336|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20sab%C3%ADa%20que%20Guillermo%20y%20Tamara%20eran%20hermanos.)
^es-Q0336-answer

**es-Q0337** — ¿Qué te crees que estaba haciendo?

What do you think I was doing?

Expected form: **estaba**

Why: Past background. [[Spanish#^es-Q0337|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFQu%C3%A9%20te%20crees%20que%20estaba%20haciendo%3F)
^es-Q0337-answer

**es-Q0338** — ¿Qué te crees que estaba haciendo?

What do you think I was doing?

Expected form: **estaba**

Why: Past background. [[Spanish#^es-Q0338|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFQu%C3%A9%20te%20crees%20que%20estaba%20haciendo%3F)
^es-Q0338-answer

**es-Q0339** — Él tenía dos hijos que se hicieron doctores.

He had two sons, who became doctors.

Expected form: **tenía**

Why: Past background. [[Spanish#^es-Q0339|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C3%89l%20ten%C3%ADa%20dos%20hijos%20que%20se%20hicieron%20doctores.)
^es-Q0339-answer

**es-Q0340** — Él tenía dos hijos que se hicieron doctores.

He had two sons, who became doctors.

Why: Past background. [[Spanish#^es-Q0340|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C3%89l%20ten%C3%ADa%20dos%20hijos%20que%20se%20hicieron%20doctores.)
^es-Q0340-answer

**es-Q0341** — Tom no tenía ganas de hablar.

Tom didn't feel like talking.

Why: Past background. [[Spanish#^es-Q0341|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tom%20no%20ten%C3%ADa%20ganas%20de%20hablar.)
^es-Q0341-answer

**es-Q0342** — Tom no tenía ganas de hablar.

Tom didn't feel like talking.

The imperfect typically presents background, a past state or a habit. A preterite presents an event as bounded in its narrative frame. The difference is viewpoint, not a simple long/short duration rule.

Why: Past background. [[Spanish#^es-Q0342|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tom%20no%20ten%C3%ADa%20ganas%20de%20hablar.)
^es-Q0342-answer

**es-Q0343** — Tom no quería volver a casa.

Tom didn't want to return home.

Expected form: **quería**

Why: Past background. [[Spanish#^es-Q0343|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tom%20no%20quer%C3%ADa%20volver%20a%20casa.)
^es-Q0343-answer

**es-Q0344** — Tom no quería volver a casa.

Tom didn't want to return home.

Expected form: **quería**

Why: Past background. [[Spanish#^es-Q0344|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tom%20no%20quer%C3%ADa%20volver%20a%20casa.)
^es-Q0344-answer

**es-Q0345** — Tom no tenía nada más que añadir.

Tom had nothing more to add.

Expected form: **tenía**

Why: Past background. [[Spanish#^es-Q0345|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tom%20no%20ten%C3%ADa%20nada%20m%C3%A1s%20que%20a%C3%B1adir.)
^es-Q0345-answer

**es-Q0346** — Tom no tenía nada más que añadir.

Tom had nothing more to add.

Why: Past background. [[Spanish#^es-Q0346|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tom%20no%20ten%C3%ADa%20nada%20m%C3%A1s%20que%20a%C3%B1adir.)
^es-Q0346-answer

**es-Q0347** — Yo era la persona más feliz del mundo.

I was the happiest man on earth.

Why: Past background. [[Spanish#^es-Q0347|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Yo%20era%20la%20persona%20m%C3%A1s%20feliz%20del%20mundo.)
^es-Q0347-answer

**es-Q0348** — Yo era la persona más feliz del mundo.

I was the happiest man on earth.

The imperfect typically presents background, a past state or a habit. A preterite presents an event as bounded in its narrative frame. The difference is viewpoint, not a simple long/short duration rule.

Why: Past background. [[Spanish#^es-Q0348|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Yo%20era%20la%20persona%20m%C3%A1s%20feliz%20del%20mundo.)
^es-Q0348-answer

**es-Q0349** — Quería que Tom que viera primero.

I wanted Tom to see me first.

Expected form: **Quería**

Why: Past background. [[Spanish#^es-Q0349|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Quer%C3%ADa%20que%20Tom%20que%20viera%20primero.)
^es-Q0349-answer

**es-Q0350** — Quería que Tom que viera primero.

I wanted Tom to see me first.

Expected form: **Quería**

Why: Past background. [[Spanish#^es-Q0350|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Quer%C3%ADa%20que%20Tom%20que%20viera%20primero.)
^es-Q0350-answer


### Answers 351–400

**es-Q0351** — Él me dio todo pero no aceptó nada a cambio.

He gave me everything but took nothing in return.

Expected form: **dio**

Why: Bounded past forms. [[Spanish#^es-Q0351|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C3%89l%20me%20dio%20todo%20pero%20no%20acept%C3%B3%20nada%20a%20cambio.)
^es-Q0351-answer

**es-Q0352** — Él me dio todo pero no aceptó nada a cambio.

He gave me everything but took nothing in return.

Why: Bounded past forms. [[Spanish#^es-Q0352|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C3%89l%20me%20dio%20todo%20pero%20no%20acept%C3%B3%20nada%20a%20cambio.)
^es-Q0352-answer

**es-Q0353** — La primera máquina imprenta fue inventada por Gutenberg.

The first printing machine was invented by Gutenberg.

Why: Bounded past forms. [[Spanish#^es-Q0353|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=La%20primera%20m%C3%A1quina%20imprenta%20fue%20inventada%20por%20Gutenberg.)
^es-Q0353-answer

**es-Q0354** — La primera máquina imprenta fue inventada por Gutenberg.

The first printing machine was invented by Gutenberg.

The preterite presents past events as bounded. Fue may be a form of ser or ir; context determines the verb. Common irregular forms need direct practice in sentences.

Why: Bounded past forms. [[Spanish#^es-Q0354|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=La%20primera%20m%C3%A1quina%20imprenta%20fue%20inventada%20por%20Gutenberg.)
^es-Q0354-answer

**es-Q0355** — Le picó una avispa y tuvo una reacción alérgica.

A wasp stung him and he had an allergic reaction.

Expected form: **tuvo**

Why: Bounded past forms. [[Spanish#^es-Q0355|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Le%20pic%C3%B3%20una%20avispa%20y%20tuvo%20una%20reacci%C3%B3n%20al%C3%A9rgica.)
^es-Q0355-answer

**es-Q0356** — Le picó una avispa y tuvo una reacción alérgica.

A wasp stung him and he had an allergic reaction.

Expected form: **tuvo**

Why: Bounded past forms. [[Spanish#^es-Q0356|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Le%20pic%C3%B3%20una%20avispa%20y%20tuvo%20una%20reacci%C3%B3n%20al%C3%A9rgica.)
^es-Q0356-answer

**es-Q0357** — Alguien dijo algo, pero no pudimos entenderlo.

Someone said something, but we could not understand it.

Expected form: **dijo**

Why: Bounded past forms. [[Spanish#^es-Q0357|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Alguien%20dijo%20algo%2C%20pero%20no%20pudimos%20entenderlo.)
^es-Q0357-answer

**es-Q0358** — Alguien dijo algo, pero no pudimos entenderlo.

Someone said something, but we could not understand it.

Why: Bounded past forms. [[Spanish#^es-Q0358|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Alguien%20dijo%20algo%2C%20pero%20no%20pudimos%20entenderlo.)
^es-Q0358-answer

**es-Q0359** — Él me la dio a cambio de nada.

He gave it to me for nothing.

Why: Bounded past forms. [[Spanish#^es-Q0359|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C3%89l%20me%20la%20dio%20a%20cambio%20de%20nada.)
^es-Q0359-answer

**es-Q0360** — Él me la dio a cambio de nada.

He gave it to me for nothing.

The preterite presents past events as bounded. Fue may be a form of ser or ir; context determines the verb. Common irregular forms need direct practice in sentences.

Why: Bounded past forms. [[Spanish#^es-Q0360|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C3%89l%20me%20la%20dio%20a%20cambio%20de%20nada.)
^es-Q0360-answer

**es-Q0361** — Las mujeres fueron las que sufrieron más en la época de la Santa Inquisición.

Women were the ones who suffered the most during the Inquisition.

Expected form: **fueron**

Why: Bounded past forms. [[Spanish#^es-Q0361|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Las%20mujeres%20fueron%20las%20que%20sufrieron%20m%C3%A1s%20en%20la%20%C3%A9poca%20de%20la%20Santa%20Inquisici%C3%B3n.)
^es-Q0361-answer

**es-Q0362** — Las mujeres fueron las que sufrieron más en la época de la Santa Inquisición.

Women were the ones who suffered the most during the Inquisition.

Expected form: **fueron**

Why: Bounded past forms. [[Spanish#^es-Q0362|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Las%20mujeres%20fueron%20las%20que%20sufrieron%20m%C3%A1s%20en%20la%20%C3%A9poca%20de%20la%20Santa%20Inquisici%C3%B3n.)
^es-Q0362-answer

**es-Q0363** — Tom se paró y fue hacia la ventana.

Tom stood up and walked to the window.

Expected form: **fue**

Why: Bounded past forms. [[Spanish#^es-Q0363|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tom%20se%20par%C3%B3%20y%20fue%20hacia%20la%20ventana.)
^es-Q0363-answer

**es-Q0364** — Tom se paró y fue hacia la ventana.

Tom stood up and walked to the window.

Why: Bounded past forms. [[Spanish#^es-Q0364|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tom%20se%20par%C3%B3%20y%20fue%20hacia%20la%20ventana.)
^es-Q0364-answer

**es-Q0365** — El partido final no fue tan emocionante.

The final match was not so exciting.

Why: Bounded past forms. [[Spanish#^es-Q0365|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=El%20partido%20final%20no%20fue%20tan%20emocionante.)
^es-Q0365-answer

**es-Q0366** — El partido final no fue tan emocionante.

The final match was not so exciting.

The preterite presents past events as bounded. Fue may be a form of ser or ir; context determines the verb. Common irregular forms need direct practice in sentences.

Why: Bounded past forms. [[Spanish#^es-Q0366|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=El%20partido%20final%20no%20fue%20tan%20emocionante.)
^es-Q0366-answer

**es-Q0367** — Mi comentario hizo que el grupo empezara a discutir.

My comment sparked off an argument in the group.

Expected form: **hizo**

Why: Bounded past forms. [[Spanish#^es-Q0367|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Mi%20comentario%20hizo%20que%20el%20grupo%20empezara%20a%20discutir.)
^es-Q0367-answer

**es-Q0368** — Mi comentario hizo que el grupo empezara a discutir.

My comment sparked off an argument in the group.

Expected form: **hizo**

Why: Bounded past forms. [[Spanish#^es-Q0368|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Mi%20comentario%20hizo%20que%20el%20grupo%20empezara%20a%20discutir.)
^es-Q0368-answer

**es-Q0369** — Él vino a Japón hace dos años.

He came to Japan two years ago.

Expected form: **vino**

Why: Bounded past forms. [[Spanish#^es-Q0369|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C3%89l%20vino%20a%20Jap%C3%B3n%20hace%20dos%20a%C3%B1os.)
^es-Q0369-answer

**es-Q0370** — Él vino a Japón hace dos años.

He came to Japan two years ago.

Why: Bounded past forms. [[Spanish#^es-Q0370|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C3%89l%20vino%20a%20Jap%C3%B3n%20hace%20dos%20a%C3%B1os.)
^es-Q0370-answer

**es-Q0371** — Un tal señor Tanaka vino a verte ayer.

A Mr. Tanaka came to see you yesterday.

Why: Bounded past forms. [[Spanish#^es-Q0371|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Un%20tal%20se%C3%B1or%20Tanaka%20vino%20a%20verte%20ayer.)
^es-Q0371-answer

**es-Q0372** — Un tal señor Tanaka vino a verte ayer.

A Mr. Tanaka came to see you yesterday.

The preterite presents past events as bounded. Fue may be a form of ser or ir; context determines the verb. Common irregular forms need direct practice in sentences.

Why: Bounded past forms. [[Spanish#^es-Q0372|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Un%20tal%20se%C3%B1or%20Tanaka%20vino%20a%20verte%20ayer.)
^es-Q0372-answer

**es-Q0373** — Él le dio un consejo.

He gave her a piece of advice.

Expected form: **dio**

Why: Bounded past forms. [[Spanish#^es-Q0373|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C3%89l%20le%20dio%20un%20consejo.)
^es-Q0373-answer

**es-Q0374** — Él le dio un consejo.

He gave her a piece of advice.

Expected form: **dio**

Why: Bounded past forms. [[Spanish#^es-Q0374|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C3%89l%20le%20dio%20un%20consejo.)
^es-Q0374-answer

**es-Q0375** — Él me lo dio a cambio de nada.

He gave it to me for nothing.

Expected form: **dio**

Why: Bounded past forms. [[Spanish#^es-Q0375|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C3%89l%20me%20lo%20dio%20a%20cambio%20de%20nada.)
^es-Q0375-answer

**es-Q0376** — Él me lo dio a cambio de nada.

He gave it to me for nothing.

Why: Bounded past forms. [[Spanish#^es-Q0376|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C3%89l%20me%20lo%20dio%20a%20cambio%20de%20nada.)
^es-Q0376-answer

**es-Q0377** — Las mujeres fueron a la fiesta muy encopetadas.

The women went to the celebration dressed to the nines.

Why: Bounded past forms. [[Spanish#^es-Q0377|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Las%20mujeres%20fueron%20a%20la%20fiesta%20muy%20encopetadas.)
^es-Q0377-answer

**es-Q0378** — Las mujeres fueron a la fiesta muy encopetadas.

The women went to the celebration dressed to the nines.

The preterite presents past events as bounded. Fue may be a form of ser or ir; context determines the verb. Common irregular forms need direct practice in sentences.

Why: Bounded past forms. [[Spanish#^es-Q0378|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Las%20mujeres%20fueron%20a%20la%20fiesta%20muy%20encopetadas.)
^es-Q0378-answer

**es-Q0379** — Un amigo mío lo hizo con una máscara.

A friend of mine made it with a mask.

Expected form: **hizo**

Why: Bounded past forms. [[Spanish#^es-Q0379|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Un%20amigo%20m%C3%ADo%20lo%20hizo%20con%20una%20m%C3%A1scara.)
^es-Q0379-answer

**es-Q0380** — Un amigo mío lo hizo con una máscara.

A friend of mine made it with a mask.

Expected form: **hizo**

Why: Bounded past forms. [[Spanish#^es-Q0380|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Un%20amigo%20m%C3%ADo%20lo%20hizo%20con%20una%20m%C3%A1scara.)
^es-Q0380-answer

**es-Q0381** — Cristóbal Colón, como todo el mundo sabe, es reverenciado por la posteridad, porque él fue el último en descubrir América.

Christopher Columbus, as everyone knows, is honored by posterity because he was the last to discover America.

Expected form: **fue**

Why: Bounded past forms. [[Spanish#^es-Q0381|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Crist%C3%B3bal%20Col%C3%B3n%2C%20como%20todo%20el%20mundo%20sabe%2C%20es%20reverenciado%20por%20la%20posteridad%2C%20porque%20%C3%A9l%20fue%20el%20%C3%BAltimo%20en%20descubrir%20Am%C3%A9rica.)
^es-Q0381-answer

**es-Q0382** — Cristóbal Colón, como todo el mundo sabe, es reverenciado por la posteridad, porque él fue el último en descubrir América.

Christopher Columbus, as everyone knows, is honored by posterity because he was the last to discover America.

Why: Bounded past forms. [[Spanish#^es-Q0382|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Crist%C3%B3bal%20Col%C3%B3n%2C%20como%20todo%20el%20mundo%20sabe%2C%20es%20reverenciado%20por%20la%20posteridad%2C%20porque%20%C3%A9l%20fue%20el%20%C3%BAltimo%20en%20descubrir%20Am%C3%A9rica.)
^es-Q0382-answer

**es-Q0383** — La capital fue bombardeada una y otra vez.

The capital was bombed again and again.

Why: Bounded past forms. [[Spanish#^es-Q0383|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=La%20capital%20fue%20bombardeada%20una%20y%20otra%20vez.)
^es-Q0383-answer

**es-Q0384** — La capital fue bombardeada una y otra vez.

The capital was bombed again and again.

The preterite presents past events as bounded. Fue may be a form of ser or ir; context determines the verb. Common irregular forms need direct practice in sentences.

Why: Bounded past forms. [[Spanish#^es-Q0384|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=La%20capital%20fue%20bombardeada%20una%20y%20otra%20vez.)
^es-Q0384-answer

**es-Q0385** — Su última obra tuvo un gran éxito.

His last play was a great success.

Expected form: **tuvo**

Why: Bounded past forms. [[Spanish#^es-Q0385|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Su%20%C3%BAltima%20obra%20tuvo%20un%20gran%20%C3%A9xito.)
^es-Q0385-answer

**es-Q0386** — Su última obra tuvo un gran éxito.

His last play was a great success.

Expected form: **tuvo**

Why: Bounded past forms. [[Spanish#^es-Q0386|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Su%20%C3%BAltima%20obra%20tuvo%20un%20gran%20%C3%A9xito.)
^es-Q0386-answer

**es-Q0387** — Este es mi vino.

This is my wine.

Expected form: **vino**

Why: Bounded past forms. [[Spanish#^es-Q0387|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Este%20es%20mi%20vino.)
^es-Q0387-answer

**es-Q0388** — Este es mi vino.

This is my wine.

Why: Bounded past forms. [[Spanish#^es-Q0388|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Este%20es%20mi%20vino.)
^es-Q0388-answer

**es-Q0389** — Vi a un oso manejando una van.

I saw a bear driving a van.

Why: Bounded past forms. [[Spanish#^es-Q0389|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Vi%20a%20un%20oso%20manejando%20una%20van.)
^es-Q0389-answer

**es-Q0390** — Vi a un oso manejando una van.

I saw a bear driving a van.

The preterite presents past events as bounded. Fue may be a form of ser or ir; context determines the verb. Common irregular forms need direct practice in sentences.

Why: Bounded past forms. [[Spanish#^es-Q0390|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Vi%20a%20un%20oso%20manejando%20una%20van.)
^es-Q0390-answer

**es-Q0391** — Tom dijo que la caja pesaba mucho para levantarla él solo.

Tom said that the box was too heavy to lift by himself.

Expected form: **dijo**

Why: Bounded past forms. [[Spanish#^es-Q0391|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tom%20dijo%20que%20la%20caja%20pesaba%20mucho%20para%20levantarla%20%C3%A9l%20solo.)
^es-Q0391-answer

**es-Q0392** — Tom dijo que la caja pesaba mucho para levantarla él solo.

Tom said that the box was too heavy to lift by himself.

Expected form: **dijo**

Why: Bounded past forms. [[Spanish#^es-Q0392|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tom%20dijo%20que%20la%20caja%20pesaba%20mucho%20para%20levantarla%20%C3%A9l%20solo.)
^es-Q0392-answer

**es-Q0393** — La vieja mezquita fue abandonada y caye a pedazos.

The old mosque was derelict and rotting.

Expected form: **fue**

Why: Bounded past forms. [[Spanish#^es-Q0393|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=La%20vieja%20mezquita%20fue%20abandonada%20y%20caye%20a%20pedazos.)
^es-Q0393-answer

**es-Q0394** — La vieja mezquita fue abandonada y caye a pedazos.

The old mosque was derelict and rotting.

Why: Bounded past forms. [[Spanish#^es-Q0394|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=La%20vieja%20mezquita%20fue%20abandonada%20y%20caye%20a%20pedazos.)
^es-Q0394-answer

**es-Q0395** — Él dio lo mejor que pudo.

He did his best.

Why: Bounded past forms. [[Spanish#^es-Q0395|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C3%89l%20dio%20lo%20mejor%20que%20pudo.)
^es-Q0395-answer

**es-Q0396** — Él dio lo mejor que pudo.

He did his best.

The preterite presents past events as bounded. Fue may be a form of ser or ir; context determines the verb. Common irregular forms need direct practice in sentences.

Why: Bounded past forms. [[Spanish#^es-Q0396|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C3%89l%20dio%20lo%20mejor%20que%20pudo.)
^es-Q0396-answer

**es-Q0397** — La experiencia le dio una ventaja sobre los demás.

The experience gave him an advantage over the others.

Expected form: **dio**

Why: Bounded past forms. [[Spanish#^es-Q0397|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=La%20experiencia%20le%20dio%20una%20ventaja%20sobre%20los%20dem%C3%A1s.)
^es-Q0397-answer

**es-Q0398** — La experiencia le dio una ventaja sobre los demás.

The experience gave him an advantage over the others.

Expected form: **dio**

Why: Bounded past forms. [[Spanish#^es-Q0398|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=La%20experiencia%20le%20dio%20una%20ventaja%20sobre%20los%20dem%C3%A1s.)
^es-Q0398-answer

**es-Q0399** — Su concierto fue un gran éxito.

Their concert was a big hit.

Expected form: **fue**

Why: Bounded past forms. [[Spanish#^es-Q0399|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Su%20concierto%20fue%20un%20gran%20%C3%A9xito.)
^es-Q0399-answer

**es-Q0400** — Su concierto fue un gran éxito.

Their concert was a big hit.

Why: Bounded past forms. [[Spanish#^es-Q0400|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Su%20concierto%20fue%20un%20gran%20%C3%A9xito.)
^es-Q0400-answer


### Answers 401–450

**es-Q0401** — «Quiero que mi elfo oscuro sea azul.» «De acuerdo... Ése es morado. Serás morado esta semana.»

"I want my dark elf to be blue." "OK... That one's purple. You'll be purple for this week."

Why: Subjunctive forms. [[Spanish#^es-Q0401|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%ABQuiero%20que%20mi%20elfo%20oscuro%20sea%20azul.%C2%BB%20%C2%ABDe%20acuerdo...%20%C3%89se%20es%20morado.%20Ser%C3%A1s%20morado%20esta%20semana.%C2%BB)
^es-Q0401-answer

**es-Q0402** — «Quiero que mi elfo oscuro sea azul.» «De acuerdo... Ése es morado. Serás morado esta semana.»

"I want my dark elf to be blue." "OK... That one's purple. You'll be purple for this week."

Subjunctive selection depends on a governing expression and the status of the proposition. Wishes, evaluation, negation and non-specific relatives often matter. It is not merely a marker of anything uncertain.

Why: Subjunctive forms. [[Spanish#^es-Q0402|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%ABQuiero%20que%20mi%20elfo%20oscuro%20sea%20azul.%C2%BB%20%C2%ABDe%20acuerdo...%20%C3%89se%20es%20morado.%20Ser%C3%A1s%20morado%20esta%20semana.%C2%BB)
^es-Q0402-answer

**es-Q0403** — Recojan tantas monedas como sea posible.

Collect as many coins as possible.

Expected form: **sea**

Why: Subjunctive forms. [[Spanish#^es-Q0403|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Recojan%20tantas%20monedas%20como%20sea%20posible.)
^es-Q0403-answer

**es-Q0404** — Recojan tantas monedas como sea posible.

Collect as many coins as possible.

Expected form: **sea**

Why: Subjunctive forms. [[Spanish#^es-Q0404|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Recojan%20tantas%20monedas%20como%20sea%20posible.)
^es-Q0404-answer

**es-Q0405** — No creo que esto sea gracioso.

I don't think this is funny.

Expected form: **sea**

Why: Subjunctive forms. [[Spanish#^es-Q0405|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20creo%20que%20esto%20sea%20gracioso.)
^es-Q0405-answer

**es-Q0406** — No creo que esto sea gracioso.

I don't think this is funny.

Why: Subjunctive forms. [[Spanish#^es-Q0406|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20creo%20que%20esto%20sea%20gracioso.)
^es-Q0406-answer

**es-Q0407** — Nuestra empresa necesita a alguien que esté adaptado a tecnología avanzada.

Our company needs someone who is at home in advanced technology.

Why: Subjunctive forms. [[Spanish#^es-Q0407|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Nuestra%20empresa%20necesita%20a%20alguien%20que%20est%C3%A9%20adaptado%20a%20tecnolog%C3%ADa%20avanzada.)
^es-Q0407-answer

**es-Q0408** — Nuestra empresa necesita a alguien que esté adaptado a tecnología avanzada.

Our company needs someone who is at home in advanced technology.

Subjunctive selection depends on a governing expression and the status of the proposition. Wishes, evaluation, negation and non-specific relatives often matter. It is not merely a marker of anything uncertain.

Why: Subjunctive forms. [[Spanish#^es-Q0408|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Nuestra%20empresa%20necesita%20a%20alguien%20que%20est%C3%A9%20adaptado%20a%20tecnolog%C3%ADa%20avanzada.)
^es-Q0408-answer

**es-Q0409** — No creo que ella esté feliz.

I don't think she is happy.

Expected form: **esté**

Why: Subjunctive forms. [[Spanish#^es-Q0409|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20creo%20que%20ella%20est%C3%A9%20feliz.)
^es-Q0409-answer

**es-Q0410** — No creo que ella esté feliz.

I don't think she is happy.

Expected form: **esté**

Why: Subjunctive forms. [[Spanish#^es-Q0410|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20creo%20que%20ella%20est%C3%A9%20feliz.)
^es-Q0410-answer

**es-Q0411** — Quizá Tom tenga problemas.

Maybe Tom has problems.

Expected form: **tenga**

Why: Subjunctive forms. [[Spanish#^es-Q0411|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Quiz%C3%A1%20Tom%20tenga%20problemas.)
^es-Q0411-answer

**es-Q0412** — Quizá Tom tenga problemas.

Maybe Tom has problems.

Why: Subjunctive forms. [[Spanish#^es-Q0412|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Quiz%C3%A1%20Tom%20tenga%20problemas.)
^es-Q0412-answer

**es-Q0413** — Mastica bien tu comida para que se pueda digerir bien.

Chew your food well so it can be digested properly.

Why: Subjunctive forms. [[Spanish#^es-Q0413|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Mastica%20bien%20tu%20comida%20para%20que%20se%20pueda%20digerir%20bien.)
^es-Q0413-answer

**es-Q0414** — Mastica bien tu comida para que se pueda digerir bien.

Chew your food well so it can be digested properly.

Subjunctive selection depends on a governing expression and the status of the proposition. Wishes, evaluation, negation and non-specific relatives often matter. It is not merely a marker of anything uncertain.

Why: Subjunctive forms. [[Spanish#^es-Q0414|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Mastica%20bien%20tu%20comida%20para%20que%20se%20pueda%20digerir%20bien.)
^es-Q0414-answer

**es-Q0415** — Tal vez no sea una mala idea después de todo.

Maybe it's not such a bad idea after all.

Expected form: **sea**

Why: Subjunctive forms. [[Spanish#^es-Q0415|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tal%20vez%20no%20sea%20una%20mala%20idea%20despu%C3%A9s%20de%20todo.)
^es-Q0415-answer

**es-Q0416** — Tal vez no sea una mala idea después de todo.

Maybe it's not such a bad idea after all.

Expected form: **sea**

Why: Subjunctive forms. [[Spanish#^es-Q0416|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tal%20vez%20no%20sea%20una%20mala%20idea%20despu%C3%A9s%20de%20todo.)
^es-Q0416-answer

**es-Q0417** — En Brasil, el pronombre "você" se utiliza de modo informal como "tú". En cambio, en Portugal se utiliza como forma de cortesía, o sea, "usted".

In Brazil, the pronoun "você" is the casual way of saying "you", whilst in Portugal it's used in more formal contexts to denote courteousness.

Expected form: **sea**

Why: Subjunctive forms. [[Spanish#^es-Q0417|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=En%20Brasil%2C%20el%20pronombre%20%22voc%C3%AA%22%20se%20utiliza%20de%20modo%20informal%20como%20%22t%C3%BA%22.%20En%20cambio%2C%20en%20Portugal%20se%20utiliza%20como%20forma%20de%20cortes%C3%ADa%2C%20o%20sea%2C%20%22usted%22.)
^es-Q0417-answer

**es-Q0418** — En Brasil, el pronombre "você" se utiliza de modo informal como "tú". En cambio, en Portugal se utiliza como forma de cortesía, o sea, "usted".

In Brazil, the pronoun "você" is the casual way of saying "you", whilst in Portugal it's used in more formal contexts to denote courteousness.

Why: Subjunctive forms. [[Spanish#^es-Q0418|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=En%20Brasil%2C%20el%20pronombre%20%22voc%C3%AA%22%20se%20utiliza%20de%20modo%20informal%20como%20%22t%C3%BA%22.%20En%20cambio%2C%20en%20Portugal%20se%20utiliza%20como%20forma%20de%20cortes%C3%ADa%2C%20o%20sea%2C%20%22usted%22.)
^es-Q0418-answer

**es-Q0419** — Cualquier persona cuyo nivel de comodidad dependa de lo que los demás estén vistiendo realmente necesita echarse una larga y escrutadora mirada a sí mismo.

Anyone whose comfort level depends on what someone else is wearing really needs to take a long, hard look at themselves.

Why: Subjunctive forms. [[Spanish#^es-Q0419|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Cualquier%20persona%20cuyo%20nivel%20de%20comodidad%20dependa%20de%20lo%20que%20los%20dem%C3%A1s%20est%C3%A9n%20vistiendo%20realmente%20necesita%20echarse%20una%20larga%20y%20escrutadora%20mirada%20a%20s%C3%AD%20mismo.)
^es-Q0419-answer

**es-Q0420** — Cualquier persona cuyo nivel de comodidad dependa de lo que los demás estén vistiendo realmente necesita echarse una larga y escrutadora mirada a sí mismo.

Anyone whose comfort level depends on what someone else is wearing really needs to take a long, hard look at themselves.

Subjunctive selection depends on a governing expression and the status of the proposition. Wishes, evaluation, negation and non-specific relatives often matter. It is not merely a marker of anything uncertain.

Why: Subjunctive forms. [[Spanish#^es-Q0420|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Cualquier%20persona%20cuyo%20nivel%20de%20comodidad%20dependa%20de%20lo%20que%20los%20dem%C3%A1s%20est%C3%A9n%20vistiendo%20realmente%20necesita%20echarse%20una%20larga%20y%20escrutadora%20mirada%20a%20s%C3%AD%20mismo.)
^es-Q0420-answer

**es-Q0421** — Haz lo que sea necesario.

Do whatever it takes.

Expected form: **sea**

Why: Subjunctive forms. [[Spanish#^es-Q0421|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Haz%20lo%20que%20sea%20necesario.)
^es-Q0421-answer

**es-Q0422** — Haz lo que sea necesario.

Do whatever it takes.

Expected form: **sea**

Why: Subjunctive forms. [[Spanish#^es-Q0422|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Haz%20lo%20que%20sea%20necesario.)
^es-Q0422-answer

**es-Q0423** — Me pides que haga lo imposible.

You ask me to do the impossible.

Expected form: **haga**

Why: Subjunctive forms. [[Spanish#^es-Q0423|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Me%20pides%20que%20haga%20lo%20imposible.)
^es-Q0423-answer

**es-Q0424** — Me pides que haga lo imposible.

You ask me to do the impossible.

Why: Subjunctive forms. [[Spanish#^es-Q0424|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Me%20pides%20que%20haga%20lo%20imposible.)
^es-Q0424-answer

**es-Q0425** — Queremos que todo el mundo tenga una feliz Navidad.

We want everybody to have a good Christmas.

Why: Subjunctive forms. [[Spanish#^es-Q0425|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Queremos%20que%20todo%20el%20mundo%20tenga%20una%20feliz%20Navidad.)
^es-Q0425-answer

**es-Q0426** — Queremos que todo el mundo tenga una feliz Navidad.

We want everybody to have a good Christmas.

Subjunctive selection depends on a governing expression and the status of the proposition. Wishes, evaluation, negation and non-specific relatives often matter. It is not merely a marker of anything uncertain.

Why: Subjunctive forms. [[Spanish#^es-Q0426|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Queremos%20que%20todo%20el%20mundo%20tenga%20una%20feliz%20Navidad.)
^es-Q0426-answer

**es-Q0427** — Dudo que Tom sea feliz con su nuevo empleo.

I doubt that Tom is happy with his new job.

Expected form: **sea**

Why: Subjunctive forms. [[Spanish#^es-Q0427|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Dudo%20que%20Tom%20sea%20feliz%20con%20su%20nuevo%20empleo.)
^es-Q0427-answer

**es-Q0428** — Dudo que Tom sea feliz con su nuevo empleo.

I doubt that Tom is happy with his new job.

Expected form: **sea**

Why: Subjunctive forms. [[Spanish#^es-Q0428|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Dudo%20que%20Tom%20sea%20feliz%20con%20su%20nuevo%20empleo.)
^es-Q0428-answer

**es-Q0429** — No puedo creer que todo esto esté pasando.

I can't really believe all this is happening.

Expected form: **esté**

Why: Subjunctive forms. [[Spanish#^es-Q0429|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20puedo%20creer%20que%20todo%20esto%20est%C3%A9%20pasando.)
^es-Q0429-answer

**es-Q0430** — No puedo creer que todo esto esté pasando.

I can't really believe all this is happening.

Why: Subjunctive forms. [[Spanish#^es-Q0430|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20puedo%20creer%20que%20todo%20esto%20est%C3%A9%20pasando.)
^es-Q0430-answer

**es-Q0431** — Tenga en cuenta lo que le digo.

Keep in mind what I tell you.

Why: Subjunctive forms. [[Spanish#^es-Q0431|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tenga%20en%20cuenta%20lo%20que%20le%20digo.)
^es-Q0431-answer

**es-Q0432** — Tenga en cuenta lo que le digo.

Keep in mind what I tell you.

Subjunctive selection depends on a governing expression and the status of the proposition. Wishes, evaluation, negation and non-specific relatives often matter. It is not merely a marker of anything uncertain.

Why: Subjunctive forms. [[Spanish#^es-Q0432|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tenga%20en%20cuenta%20lo%20que%20le%20digo.)
^es-Q0432-answer

**es-Q0433** — No creo que ella esté de vuelta para las cinco.

I don't think she will come back by five.

Expected form: **esté**

Why: Subjunctive forms. [[Spanish#^es-Q0433|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20creo%20que%20ella%20est%C3%A9%20de%20vuelta%20para%20las%20cinco.)
^es-Q0433-answer

**es-Q0434** — No creo que ella esté de vuelta para las cinco.

I don't think she will come back by five.

Expected form: **esté**

Why: Subjunctive forms. [[Spanish#^es-Q0434|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20creo%20que%20ella%20est%C3%A9%20de%20vuelta%20para%20las%20cinco.)
^es-Q0434-answer

**es-Q0435** — ¡No vaya tan ligero!

Don't go so fast!

Expected form: **vaya**

Why: Subjunctive forms. [[Spanish#^es-Q0435|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%A1No%20vaya%20tan%20ligero%21)
^es-Q0435-answer

**es-Q0436** — ¡No vaya tan ligero!

Don't go so fast!

Why: Subjunctive forms. [[Spanish#^es-Q0436|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%A1No%20vaya%20tan%20ligero%21)
^es-Q0436-answer

**es-Q0437** — La Policía no puede cuestionar a Tom hasta que su abogado esté aquí.

The police can't question Tom until his lawyer gets here.

Why: Subjunctive forms. [[Spanish#^es-Q0437|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=La%20Polic%C3%ADa%20no%20puede%20cuestionar%20a%20Tom%20hasta%20que%20su%20abogado%20est%C3%A9%20aqu%C3%AD.)
^es-Q0437-answer

**es-Q0438** — La Policía no puede cuestionar a Tom hasta que su abogado esté aquí.

The police can't question Tom until his lawyer gets here.

Subjunctive selection depends on a governing expression and the status of the proposition. Wishes, evaluation, negation and non-specific relatives often matter. It is not merely a marker of anything uncertain.

Why: Subjunctive forms. [[Spanish#^es-Q0438|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=La%20Polic%C3%ADa%20no%20puede%20cuestionar%20a%20Tom%20hasta%20que%20su%20abogado%20est%C3%A9%20aqu%C3%AD.)
^es-Q0438-answer

**es-Q0439** — Tengo que salvar como sea al niño que se está ahogando.

I must save the drowning child by all means.

Expected form: **sea**

Why: Subjunctive forms. [[Spanish#^es-Q0439|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tengo%20que%20salvar%20como%20sea%20al%20ni%C3%B1o%20que%20se%20est%C3%A1%20ahogando.)
^es-Q0439-answer

**es-Q0440** — Tengo que salvar como sea al niño que se está ahogando.

I must save the drowning child by all means.

Expected form: **sea**

Why: Subjunctive forms. [[Spanish#^es-Q0440|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tengo%20que%20salvar%20como%20sea%20al%20ni%C3%B1o%20que%20se%20est%C3%A1%20ahogando.)
^es-Q0440-answer

**es-Q0441** — Para editar una frase, haga clic en el icono de lápiz.

To edit a sentence, click on the pencil icon.

Expected form: **haga**

Why: Subjunctive forms. [[Spanish#^es-Q0441|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Para%20editar%20una%20frase%2C%20haga%20clic%20en%20el%20icono%20de%20l%C3%A1piz.)
^es-Q0441-answer

**es-Q0442** — Para editar una frase, haga clic en el icono de lápiz.

To edit a sentence, click on the pencil icon.

Why: Subjunctive forms. [[Spanish#^es-Q0442|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Para%20editar%20una%20frase%2C%20haga%20clic%20en%20el%20icono%20de%20l%C3%A1piz.)
^es-Q0442-answer

**es-Q0443** — Tranquilízate. Iré tan pronto como sea posible.

Calm down. I'll come over as soon as possible.

Why: Subjunctive forms. [[Spanish#^es-Q0443|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tranquil%C3%ADzate.%20Ir%C3%A9%20tan%20pronto%20como%20sea%20posible.)
^es-Q0443-answer

**es-Q0444** — Tranquilízate. Iré tan pronto como sea posible.

Calm down. I'll come over as soon as possible.

Subjunctive selection depends on a governing expression and the status of the proposition. Wishes, evaluation, negation and non-specific relatives often matter. It is not merely a marker of anything uncertain.

Why: Subjunctive forms. [[Spanish#^es-Q0444|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tranquil%C3%ADzate.%20Ir%C3%A9%20tan%20pronto%20como%20sea%20posible.)
^es-Q0444-answer

**es-Q0445** — Probablemente sea un mal modo de empezar.

That's probably a bad way to start.

Expected form: **sea**

Why: Subjunctive forms. [[Spanish#^es-Q0445|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Probablemente%20sea%20un%20mal%20modo%20de%20empezar.)
^es-Q0445-answer

**es-Q0446** — Probablemente sea un mal modo de empezar.

That's probably a bad way to start.

Expected form: **sea**

Why: Subjunctive forms. [[Spanish#^es-Q0446|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Probablemente%20sea%20un%20mal%20modo%20de%20empezar.)
^es-Q0446-answer

**es-Q0447** — Haga el favor de llamarme un taxi.

Please call a taxi for me.

Expected form: **Haga**

Why: Subjunctive forms. [[Spanish#^es-Q0447|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Haga%20el%20favor%20de%20llamarme%20un%20taxi.)
^es-Q0447-answer

**es-Q0448** — Haga el favor de llamarme un taxi.

Please call a taxi for me.

Why: Subjunctive forms. [[Spanish#^es-Q0448|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Haga%20el%20favor%20de%20llamarme%20un%20taxi.)
^es-Q0448-answer

**es-Q0449** — Tenga cuidado, no bote esos papeles.

Be careful. Don't throw away those papers.

Why: Subjunctive forms. [[Spanish#^es-Q0449|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tenga%20cuidado%2C%20no%20bote%20esos%20papeles.)
^es-Q0449-answer

**es-Q0450** — Tenga cuidado, no bote esos papeles.

Be careful. Don't throw away those papers.

Subjunctive selection depends on a governing expression and the status of the proposition. Wishes, evaluation, negation and non-specific relatives often matter. It is not merely a marker of anything uncertain.

Why: Subjunctive forms. [[Spanish#^es-Q0450|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tenga%20cuidado%2C%20no%20bote%20esos%20papeles.)
^es-Q0450-answer


### Answers 451–500

**es-Q0451** — Por favor, ¿Podría canjear estos cheques de viaje?

Would you cash these travelers checks, please?

Expected form: **Podría**

Why: Conditional forms. [[Spanish#^es-Q0451|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Por%20favor%2C%20%C2%BFPodr%C3%ADa%20canjear%20estos%20cheques%20de%20viaje%3F)
^es-Q0451-answer

**es-Q0452** — Por favor, ¿Podría canjear estos cheques de viaje?

Would you cash these travelers checks, please?

Expected form: **Podría**

Why: Conditional forms. [[Spanish#^es-Q0452|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Por%20favor%2C%20%C2%BFPodr%C3%ADa%20canjear%20estos%20cheques%20de%20viaje%3F)
^es-Q0452-answer

**es-Q0453** — Si fuera invisible no tendría que vestirme.

If I were invisible I wouldn't have to dress myself.

Expected form: **tendría**

Why: Conditional forms. [[Spanish#^es-Q0453|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Si%20fuera%20invisible%20no%20tendr%C3%ADa%20que%20vestirme.)
^es-Q0453-answer

**es-Q0454** — Si fuera invisible no tendría que vestirme.

If I were invisible I wouldn't have to dress myself.

Why: Conditional forms. [[Spanish#^es-Q0454|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Si%20fuera%20invisible%20no%20tendr%C3%ADa%20que%20vestirme.)
^es-Q0454-answer

**es-Q0455** — Con tus habilidades, estoy seguro de que no te sería muy difícil encontrar otro trabajo.

With your skills, I'm sure it wouldn't be too hard to find another job.

Why: Conditional forms. [[Spanish#^es-Q0455|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Con%20tus%20habilidades%2C%20estoy%20seguro%20de%20que%20no%20te%20ser%C3%ADa%20muy%20dif%C3%ADcil%20encontrar%20otro%20trabajo.)
^es-Q0455-answer

**es-Q0456** — Con tus habilidades, estoy seguro de que no te sería muy difícil encontrar otro trabajo.

With your skills, I'm sure it wouldn't be too hard to find another job.

The conditional can express a hypothetical result or politeness. A common unreal present pattern is si + imperfect subjunctive followed by conditional.

Why: Conditional forms. [[Spanish#^es-Q0456|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Con%20tus%20habilidades%2C%20estoy%20seguro%20de%20que%20no%20te%20ser%C3%ADa%20muy%20dif%C3%ADcil%20encontrar%20otro%20trabajo.)
^es-Q0456-answer

**es-Q0457** — ¿Cuántos años podría tener su abuelo?

How old might his grandfather be?

Expected form: **podría**

Why: Conditional forms. [[Spanish#^es-Q0457|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFCu%C3%A1ntos%20a%C3%B1os%20podr%C3%ADa%20tener%20su%20abuelo%3F)
^es-Q0457-answer

**es-Q0458** — ¿Cuántos años podría tener su abuelo?

How old might his grandfather be?

Expected form: **podría**

Why: Conditional forms. [[Spanish#^es-Q0458|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFCu%C3%A1ntos%20a%C3%B1os%20podr%C3%ADa%20tener%20su%20abuelo%3F)
^es-Q0458-answer

**es-Q0459** — Nada más no entiendo por qué la gente querría vivir aquí.

I just don't understand why people would want to live here.

Expected form: **querría**

Why: Conditional forms. [[Spanish#^es-Q0459|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Nada%20m%C3%A1s%20no%20entiendo%20por%20qu%C3%A9%20la%20gente%20querr%C3%ADa%20vivir%20aqu%C3%AD.)
^es-Q0459-answer

**es-Q0460** — Nada más no entiendo por qué la gente querría vivir aquí.

I just don't understand why people would want to live here.

Why: Conditional forms. [[Spanish#^es-Q0460|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Nada%20m%C3%A1s%20no%20entiendo%20por%20qu%C3%A9%20la%20gente%20querr%C3%ADa%20vivir%20aqu%C3%AD.)
^es-Q0460-answer

**es-Q0461** — Querría un poco de queso.

I'd like some cheese.

Why: Conditional forms. [[Spanish#^es-Q0461|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Querr%C3%ADa%20un%20poco%20de%20queso.)
^es-Q0461-answer

**es-Q0462** — Querría un poco de queso.

I'd like some cheese.

The conditional can express a hypothetical result or politeness. A common unreal present pattern is si + imperfect subjunctive followed by conditional.

Why: Conditional forms. [[Spanish#^es-Q0462|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Querr%C3%ADa%20un%20poco%20de%20queso.)
^es-Q0462-answer

**es-Q0463** — Nos gustaría escalar esa montaña.

We'd like to climb that mountain.

Expected form: **gustaría**

Why: Conditional forms. [[Spanish#^es-Q0463|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Nos%20gustar%C3%ADa%20escalar%20esa%20monta%C3%B1a.)
^es-Q0463-answer

**es-Q0464** — Nos gustaría escalar esa montaña.

We'd like to climb that mountain.

Expected form: **gustaría**

Why: Conditional forms. [[Spanish#^es-Q0464|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Nos%20gustar%C3%ADa%20escalar%20esa%20monta%C3%B1a.)
^es-Q0464-answer

**es-Q0465** — Tom podría ir contigo.

Tom might go with you.

Expected form: **podría**

Why: Conditional forms. [[Spanish#^es-Q0465|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tom%20podr%C3%ADa%20ir%20contigo.)
^es-Q0465-answer

**es-Q0466** — Tom podría ir contigo.

Tom might go with you.

Why: Conditional forms. [[Spanish#^es-Q0466|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tom%20podr%C3%ADa%20ir%20contigo.)
^es-Q0466-answer

**es-Q0467** — Señorita, ¿podría atenderme?

Will you please wait on me, miss?

Why: Conditional forms. [[Spanish#^es-Q0467|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Se%C3%B1orita%2C%20%C2%BFpodr%C3%ADa%20atenderme%3F)
^es-Q0467-answer

**es-Q0468** — Señorita, ¿podría atenderme?

Will you please wait on me, miss?

The conditional can express a hypothetical result or politeness. A common unreal present pattern is si + imperfect subjunctive followed by conditional.

Why: Conditional forms. [[Spanish#^es-Q0468|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Se%C3%B1orita%2C%20%C2%BFpodr%C3%ADa%20atenderme%3F)
^es-Q0468-answer

**es-Q0469** — Yo nunca les haría eso.

I'd never do that to them.

Expected form: **haría**

Why: Conditional forms. [[Spanish#^es-Q0469|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Yo%20nunca%20les%20har%C3%ADa%20eso.)
^es-Q0469-answer

**es-Q0470** — Yo nunca les haría eso.

I'd never do that to them.

Expected form: **haría**

Why: Conditional forms. [[Spanish#^es-Q0470|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Yo%20nunca%20les%20har%C3%ADa%20eso.)
^es-Q0470-answer

**es-Q0471** — Sería mejor que no comieses demasiado.

You'd better not eat too much.

Expected form: **Sería**

Why: Conditional forms. [[Spanish#^es-Q0471|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Ser%C3%ADa%20mejor%20que%20no%20comieses%20demasiado.)
^es-Q0471-answer

**es-Q0472** — Sería mejor que no comieses demasiado.

You'd better not eat too much.

Why: Conditional forms. [[Spanish#^es-Q0472|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Ser%C3%ADa%20mejor%20que%20no%20comieses%20demasiado.)
^es-Q0472-answer

**es-Q0473** — Ella podría venir.

She might come.

Why: Conditional forms. [[Spanish#^es-Q0473|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Ella%20podr%C3%ADa%20venir.)
^es-Q0473-answer

**es-Q0474** — Ella podría venir.

She might come.

The conditional can express a hypothetical result or politeness. A common unreal present pattern is si + imperfect subjunctive followed by conditional.

Why: Conditional forms. [[Spanish#^es-Q0474|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Ella%20podr%C3%ADa%20venir.)
^es-Q0474-answer

**es-Q0475** — Me gustaría hacerte una pregunta.

I would like to ask you a question.

Expected form: **gustaría**

Why: Conditional forms. [[Spanish#^es-Q0475|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Me%20gustar%C3%ADa%20hacerte%20una%20pregunta.)
^es-Q0475-answer

**es-Q0476** — Me gustaría hacerte una pregunta.

I would like to ask you a question.

Expected form: **gustaría**

Why: Conditional forms. [[Spanish#^es-Q0476|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Me%20gustar%C3%ADa%20hacerte%20una%20pregunta.)
^es-Q0476-answer

**es-Q0477** — Querría un poco de té caliente, por favor.

I'd like some hot tea, please.

Expected form: **Querría**

Why: Conditional forms. [[Spanish#^es-Q0477|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Querr%C3%ADa%20un%20poco%20de%20t%C3%A9%20caliente%2C%20por%20favor.)
^es-Q0477-answer

**es-Q0478** — Querría un poco de té caliente, por favor.

I'd like some hot tea, please.

Why: Conditional forms. [[Spanish#^es-Q0478|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Querr%C3%ADa%20un%20poco%20de%20t%C3%A9%20caliente%2C%20por%20favor.)
^es-Q0478-answer

**es-Q0479** — Cuando a una mujer se la deja sola mucho tiempo, tarde o temprano, ésta empieza a pensar; y ningún hombre sabe lo que ella podría descubrir.

For when a woman is left too much alone, sooner or later she begins to think;- And no man knows what then she may discover.

Why: Conditional forms. [[Spanish#^es-Q0479|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Cuando%20a%20una%20mujer%20se%20la%20deja%20sola%20mucho%20tiempo%2C%20tarde%20o%20temprano%2C%20%C3%A9sta%20empieza%20a%20pensar%3B%20y%20ning%C3%BAn%20hombre%20sabe%20lo%20que%20ella%20podr%C3%ADa%20descubrir.)
^es-Q0479-answer

**es-Q0480** — Cuando a una mujer se la deja sola mucho tiempo, tarde o temprano, ésta empieza a pensar; y ningún hombre sabe lo que ella podría descubrir.

For when a woman is left too much alone, sooner or later she begins to think;- And no man knows what then she may discover.

The conditional can express a hypothetical result or politeness. A common unreal present pattern is si + imperfect subjunctive followed by conditional.

Why: Conditional forms. [[Spanish#^es-Q0480|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Cuando%20a%20una%20mujer%20se%20la%20deja%20sola%20mucho%20tiempo%2C%20tarde%20o%20temprano%2C%20%C3%A9sta%20empieza%20a%20pensar%3B%20y%20ning%C3%BAn%20hombre%20sabe%20lo%20que%20ella%20podr%C3%ADa%20descubrir.)
^es-Q0480-answer

**es-Q0481** — Si me hubieras dicho la verdad, yo no estaría enojada ahora.

If you had told me the truth, I would not be angry now.

Expected form: **estaría**

Why: Conditional forms. [[Spanish#^es-Q0481|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Si%20me%20hubieras%20dicho%20la%20verdad%2C%20yo%20no%20estar%C3%ADa%20enojada%20ahora.)
^es-Q0481-answer

**es-Q0482** — Si me hubieras dicho la verdad, yo no estaría enojada ahora.

If you had told me the truth, I would not be angry now.

Expected form: **estaría**

Why: Conditional forms. [[Spanish#^es-Q0482|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Si%20me%20hubieras%20dicho%20la%20verdad%2C%20yo%20no%20estar%C3%ADa%20enojada%20ahora.)
^es-Q0482-answer

**es-Q0483** — Alguien quizás podría resultar herido.

Someone might get hurt.

Expected form: **podría**

Why: Conditional forms. [[Spanish#^es-Q0483|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Alguien%20quiz%C3%A1s%20podr%C3%ADa%20resultar%20herido.)
^es-Q0483-answer

**es-Q0484** — Alguien quizás podría resultar herido.

Someone might get hurt.

Why: Conditional forms. [[Spanish#^es-Q0484|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Alguien%20quiz%C3%A1s%20podr%C3%ADa%20resultar%20herido.)
^es-Q0484-answer

**es-Q0485** — Eso sería excelente.

That would be outstanding.

Why: Conditional forms. [[Spanish#^es-Q0485|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Eso%20ser%C3%ADa%20excelente.)
^es-Q0485-answer

**es-Q0486** — Eso sería excelente.

That would be outstanding.

The conditional can express a hypothetical result or politeness. A common unreal present pattern is si + imperfect subjunctive followed by conditional.

Why: Conditional forms. [[Spanish#^es-Q0486|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Eso%20ser%C3%ADa%20excelente.)
^es-Q0486-answer

**es-Q0487** — Me gustaría ir a verte.

I would like to come and see you.

Expected form: **gustaría**

Why: Conditional forms. [[Spanish#^es-Q0487|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Me%20gustar%C3%ADa%20ir%20a%20verte.)
^es-Q0487-answer

**es-Q0488** — Me gustaría ir a verte.

I would like to come and see you.

Expected form: **gustaría**

Why: Conditional forms. [[Spanish#^es-Q0488|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Me%20gustar%C3%ADa%20ir%20a%20verte.)
^es-Q0488-answer

**es-Q0489** — Me gustaría saber cuando podrás enviarlo.

I'd like to know when you can send it out.

Expected form: **gustaría**

Why: Conditional forms. [[Spanish#^es-Q0489|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Me%20gustar%C3%ADa%20saber%20cuando%20podr%C3%A1s%20enviarlo.)
^es-Q0489-answer

**es-Q0490** — Me gustaría saber cuando podrás enviarlo.

I'd like to know when you can send it out.

Why: Conditional forms. [[Spanish#^es-Q0490|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Me%20gustar%C3%ADa%20saber%20cuando%20podr%C3%A1s%20enviarlo.)
^es-Q0490-answer

**es-Q0491** — Creo que me gustaría ser tu amigo.

I think I'd like to be your friend.

Why: Conditional forms. [[Spanish#^es-Q0491|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Creo%20que%20me%20gustar%C3%ADa%20ser%20tu%20amigo.)
^es-Q0491-answer

**es-Q0492** — Creo que me gustaría ser tu amigo.

I think I'd like to be your friend.

The conditional can express a hypothetical result or politeness. A common unreal present pattern is si + imperfect subjunctive followed by conditional.

Why: Conditional forms. [[Spanish#^es-Q0492|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Creo%20que%20me%20gustar%C3%ADa%20ser%20tu%20amigo.)
^es-Q0492-answer

**es-Q0493** — Me gustaría hablar contigo a solas.

I'd like to talk with you in private.

Expected form: **gustaría**

Why: Conditional forms. [[Spanish#^es-Q0493|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Me%20gustar%C3%ADa%20hablar%20contigo%20a%20solas.)
^es-Q0493-answer

**es-Q0494** — Me gustaría hablar contigo a solas.

I'd like to talk with you in private.

Expected form: **gustaría**

Why: Conditional forms. [[Spanish#^es-Q0494|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Me%20gustar%C3%ADa%20hablar%20contigo%20a%20solas.)
^es-Q0494-answer

**es-Q0495** — Sería mejor que os dierais prisa, el tren sale a las tres.

You had better hurry. The train leaves at three.

Expected form: **Sería**

Why: Conditional forms. [[Spanish#^es-Q0495|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Ser%C3%ADa%20mejor%20que%20os%20dierais%20prisa%2C%20el%20tren%20sale%20a%20las%20tres.)
^es-Q0495-answer

**es-Q0496** — Sería mejor que os dierais prisa, el tren sale a las tres.

You had better hurry. The train leaves at three.

Why: Conditional forms. [[Spanish#^es-Q0496|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Ser%C3%ADa%20mejor%20que%20os%20dierais%20prisa%2C%20el%20tren%20sale%20a%20las%20tres.)
^es-Q0496-answer

**es-Q0497** — Me gustaría saber cuándo lo puede enviar.

I'd like to know when you can send it out.

Why: Conditional forms. [[Spanish#^es-Q0497|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Me%20gustar%C3%ADa%20saber%20cu%C3%A1ndo%20lo%20puede%20enviar.)
^es-Q0497-answer

**es-Q0498** — Me gustaría saber cuándo lo puede enviar.

I'd like to know when you can send it out.

The conditional can express a hypothetical result or politeness. A common unreal present pattern is si + imperfect subjunctive followed by conditional.

Why: Conditional forms. [[Spanish#^es-Q0498|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Me%20gustar%C3%ADa%20saber%20cu%C3%A1ndo%20lo%20puede%20enviar.)
^es-Q0498-answer

**es-Q0499** — Le estaría enormemente agradecido si me ayudara.

I'd be very grateful if you'd help me.

Expected form: **estaría**

Why: Conditional forms. [[Spanish#^es-Q0499|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Le%20estar%C3%ADa%20enormemente%20agradecido%20si%20me%20ayudara.)
^es-Q0499-answer

**es-Q0500** — Le estaría enormemente agradecido si me ayudara.

I'd be very grateful if you'd help me.

Expected form: **estaría**

Why: Conditional forms. [[Spanish#^es-Q0500|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Le%20estar%C3%ADa%20enormemente%20agradecido%20si%20me%20ayudara.)
^es-Q0500-answer


### Answers 501–550

**es-Q0501** — «Solo estaba hablando con él.» «¿Hablando con él de qué?» «Eso no es asunto tuyo.»

"I was just talking to him." "Talking to him about what?" "That's none of your business."

Expected form: **hablando**

Why: Progressive constructions. [[Spanish#^es-Q0501|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%ABSolo%20estaba%20hablando%20con%20%C3%A9l.%C2%BB%20%C2%AB%C2%BFHablando%20con%20%C3%A9l%20de%20qu%C3%A9%3F%C2%BB%20%C2%ABEso%20no%20es%20asunto%20tuyo.%C2%BB)
^es-Q0501-answer

**es-Q0502** — «Solo estaba hablando con él.» «¿Hablando con él de qué?» «Eso no es asunto tuyo.»

"I was just talking to him." "Talking to him about what?" "That's none of your business."

Why: Progressive constructions. [[Spanish#^es-Q0502|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%ABSolo%20estaba%20hablando%20con%20%C3%A9l.%C2%BB%20%C2%AB%C2%BFHablando%20con%20%C3%A9l%20de%20qu%C3%A9%3F%C2%BB%20%C2%ABEso%20no%20es%20asunto%20tuyo.%C2%BB)
^es-Q0502-answer

**es-Q0503** — ¿Por qué Tom sigue haciendo eso?

Why's Tom still doing that?

Why: Progressive constructions. [[Spanish#^es-Q0503|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFPor%20qu%C3%A9%20Tom%20sigue%20haciendo%20eso%3F)
^es-Q0503-answer

**es-Q0504** — ¿Por qué Tom sigue haciendo eso?

Why's Tom still doing that?

Estar + gerund focuses on an ongoing action. Spanish does not use the progressive in all situations where English does. A gerund can also appear with other verbs or as an adverbial.

Why: Progressive constructions. [[Spanish#^es-Q0504|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFPor%20qu%C3%A9%20Tom%20sigue%20haciendo%20eso%3F)
^es-Q0504-answer

**es-Q0505** — Como muchos de los estudiantes de nuestra escuela, Tom se queda despierto hasta tarde en la noche estudiando.

Like many students at our school, Tom stays up until late at night studying.

Expected form: **estudiando**

Why: Progressive constructions. [[Spanish#^es-Q0505|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Como%20muchos%20de%20los%20estudiantes%20de%20nuestra%20escuela%2C%20Tom%20se%20queda%20despierto%20hasta%20tarde%20en%20la%20noche%20estudiando.)
^es-Q0505-answer

**es-Q0506** — Como muchos de los estudiantes de nuestra escuela, Tom se queda despierto hasta tarde en la noche estudiando.

Like many students at our school, Tom stays up until late at night studying.

Expected form: **estudiando**

Why: Progressive constructions. [[Spanish#^es-Q0506|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Como%20muchos%20de%20los%20estudiantes%20de%20nuestra%20escuela%2C%20Tom%20se%20queda%20despierto%20hasta%20tarde%20en%20la%20noche%20estudiando.)
^es-Q0506-answer

**es-Q0507** — Tom está estudiando patología ocular.

Tom is studying ocular pathology.

Expected form: **estudiando**

Why: Progressive constructions. [[Spanish#^es-Q0507|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tom%20est%C3%A1%20estudiando%20patolog%C3%ADa%20ocular.)
^es-Q0507-answer

**es-Q0508** — Tom está estudiando patología ocular.

Tom is studying ocular pathology.

Why: Progressive constructions. [[Spanish#^es-Q0508|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tom%20est%C3%A1%20estudiando%20patolog%C3%ADa%20ocular.)
^es-Q0508-answer

**es-Q0509** — ¿Qué estaba haciendo tu madre cuando llegaste a casa?

What was your mother doing when you got home?

Why: Progressive constructions. [[Spanish#^es-Q0509|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFQu%C3%A9%20estaba%20haciendo%20tu%20madre%20cuando%20llegaste%20a%20casa%3F)
^es-Q0509-answer

**es-Q0510** — ¿Qué estaba haciendo tu madre cuando llegaste a casa?

What was your mother doing when you got home?

Estar + gerund focuses on an ongoing action. Spanish does not use the progressive in all situations where English does. A gerund can also appear with other verbs or as an adverbial.

Why: Progressive constructions. [[Spanish#^es-Q0510|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFQu%C3%A9%20estaba%20haciendo%20tu%20madre%20cuando%20llegaste%20a%20casa%3F)
^es-Q0510-answer

**es-Q0511** — ¿Ha estado Tom haciendo sus labores?

Has Tom been doing his chores?

Expected form: **haciendo**

Why: Progressive constructions. [[Spanish#^es-Q0511|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFHa%20estado%20Tom%20haciendo%20sus%20labores%3F)
^es-Q0511-answer

**es-Q0512** — ¿Ha estado Tom haciendo sus labores?

Has Tom been doing his chores?

Expected form: **haciendo**

Why: Progressive constructions. [[Spanish#^es-Q0512|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFHa%20estado%20Tom%20haciendo%20sus%20labores%3F)
^es-Q0512-answer

**es-Q0513** — La inspiración existe, pero tiene que encontrarte trabajando.

Inspiration exists, but it has to find you working.

Expected form: **trabajando**

Why: Progressive constructions. [[Spanish#^es-Q0513|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=La%20inspiraci%C3%B3n%20existe%2C%20pero%20tiene%20que%20encontrarte%20trabajando.)
^es-Q0513-answer

**es-Q0514** — La inspiración existe, pero tiene que encontrarte trabajando.

Inspiration exists, but it has to find you working.

Why: Progressive constructions. [[Spanish#^es-Q0514|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=La%20inspiraci%C3%B3n%20existe%2C%20pero%20tiene%20que%20encontrarte%20trabajando.)
^es-Q0514-answer

**es-Q0515** — Él estaba trabajando en la oficina ayer por la tarde.

He was working at the office yesterday evening.

Why: Progressive constructions. [[Spanish#^es-Q0515|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C3%89l%20estaba%20trabajando%20en%20la%20oficina%20ayer%20por%20la%20tarde.)
^es-Q0515-answer

**es-Q0516** — Él estaba trabajando en la oficina ayer por la tarde.

He was working at the office yesterday evening.

Estar + gerund focuses on an ongoing action. Spanish does not use the progressive in all situations where English does. A gerund can also appear with other verbs or as an adverbial.

Why: Progressive constructions. [[Spanish#^es-Q0516|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C3%89l%20estaba%20trabajando%20en%20la%20oficina%20ayer%20por%20la%20tarde.)
^es-Q0516-answer

**es-Q0517** — Creo que estoy haciendo todo lo que puedo en ese trabajo.

I think I'm doing all I can in that job.

Expected form: **haciendo**

Why: Progressive constructions. [[Spanish#^es-Q0517|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Creo%20que%20estoy%20haciendo%20todo%20lo%20que%20puedo%20en%20ese%20trabajo.)
^es-Q0517-answer

**es-Q0518** — Creo que estoy haciendo todo lo que puedo en ese trabajo.

I think I'm doing all I can in that job.

Expected form: **haciendo**

Why: Progressive constructions. [[Spanish#^es-Q0518|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Creo%20que%20estoy%20haciendo%20todo%20lo%20que%20puedo%20en%20ese%20trabajo.)
^es-Q0518-answer

**es-Q0519** — ¿Qué me estás haciendo?

What are you doing to me?

Expected form: **haciendo**

Why: Progressive constructions. [[Spanish#^es-Q0519|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFQu%C3%A9%20me%20est%C3%A1s%20haciendo%3F)
^es-Q0519-answer

**es-Q0520** — ¿Qué me estás haciendo?

What are you doing to me?

Why: Progressive constructions. [[Spanish#^es-Q0520|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFQu%C3%A9%20me%20est%C3%A1s%20haciendo%3F)
^es-Q0520-answer

**es-Q0521** — Tom no sabe si Mary está diciendo la verdad o no.

Tom doesn't know whether Mary is telling the truth or not.

Why: Progressive constructions. [[Spanish#^es-Q0521|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tom%20no%20sabe%20si%20Mary%20est%C3%A1%20diciendo%20la%20verdad%20o%20no.)
^es-Q0521-answer

**es-Q0522** — Tom no sabe si Mary está diciendo la verdad o no.

Tom doesn't know whether Mary is telling the truth or not.

Estar + gerund focuses on an ongoing action. Spanish does not use the progressive in all situations where English does. A gerund can also appear with other verbs or as an adverbial.

Why: Progressive constructions. [[Spanish#^es-Q0522|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tom%20no%20sabe%20si%20Mary%20est%C3%A1%20diciendo%20la%20verdad%20o%20no.)
^es-Q0522-answer

**es-Q0523** — Estoy hablando con Tom.

I am talking with Tom.

Expected form: **hablando**

Why: Progressive constructions. [[Spanish#^es-Q0523|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Estoy%20hablando%20con%20Tom.)
^es-Q0523-answer

**es-Q0524** — Estoy hablando con Tom.

I am talking with Tom.

Expected form: **hablando**

Why: Progressive constructions. [[Spanish#^es-Q0524|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Estoy%20hablando%20con%20Tom.)
^es-Q0524-answer

**es-Q0525** — Tengo una idea muy vaga de lo que estás hablando.

I have a very vague idea of what you are talking about.

Expected form: **hablando**

Why: Progressive constructions. [[Spanish#^es-Q0525|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tengo%20una%20idea%20muy%20vaga%20de%20lo%20que%20est%C3%A1s%20hablando.)
^es-Q0525-answer

**es-Q0526** — Tengo una idea muy vaga de lo que estás hablando.

I have a very vague idea of what you are talking about.

Why: Progressive constructions. [[Spanish#^es-Q0526|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tengo%20una%20idea%20muy%20vaga%20de%20lo%20que%20est%C3%A1s%20hablando.)
^es-Q0526-answer

**es-Q0527** — El hombre está haciendo una llamada de larga distancia.

The man is making a long-distance call.

Why: Progressive constructions. [[Spanish#^es-Q0527|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=El%20hombre%20est%C3%A1%20haciendo%20una%20llamada%20de%20larga%20distancia.)
^es-Q0527-answer

**es-Q0528** — El hombre está haciendo una llamada de larga distancia.

The man is making a long-distance call.

Estar + gerund focuses on an ongoing action. Spanish does not use the progressive in all situations where English does. A gerund can also appear with other verbs or as an adverbial.

Why: Progressive constructions. [[Spanish#^es-Q0528|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=El%20hombre%20est%C3%A1%20haciendo%20una%20llamada%20de%20larga%20distancia.)
^es-Q0528-answer

**es-Q0529** — ¿Con quién estabas hablando en el teléfono?

Who were you speaking to on the phone?

Expected form: **hablando**

Why: Progressive constructions. [[Spanish#^es-Q0529|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFCon%20qui%C3%A9n%20estabas%20hablando%20en%20el%20tel%C3%A9fono%3F)
^es-Q0529-answer

**es-Q0530** — ¿Con quién estabas hablando en el teléfono?

Who were you speaking to on the phone?

Expected form: **hablando**

Why: Progressive constructions. [[Spanish#^es-Q0530|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFCon%20qui%C3%A9n%20estabas%20hablando%20en%20el%20tel%C3%A9fono%3F)
^es-Q0530-answer

**es-Q0531** — Estoy convencida de que Tom no nos está diciendo todo.

I'm convinced that Tom isn't telling us everything.

Expected form: **diciendo**

Why: Progressive constructions. [[Spanish#^es-Q0531|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Estoy%20convencida%20de%20que%20Tom%20no%20nos%20est%C3%A1%20diciendo%20todo.)
^es-Q0531-answer

**es-Q0532** — Estoy convencida de que Tom no nos está diciendo todo.

I'm convinced that Tom isn't telling us everything.

Why: Progressive constructions. [[Spanish#^es-Q0532|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Estoy%20convencida%20de%20que%20Tom%20no%20nos%20est%C3%A1%20diciendo%20todo.)
^es-Q0532-answer

**es-Q0533** — ¿A quién le está hablando?

Who is he talking to?

Why: Progressive constructions. [[Spanish#^es-Q0533|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFA%20qui%C3%A9n%20le%20est%C3%A1%20hablando%3F)
^es-Q0533-answer

**es-Q0534** — ¿A quién le está hablando?

Who is he talking to?

Estar + gerund focuses on an ongoing action. Spanish does not use the progressive in all situations where English does. A gerund can also appear with other verbs or as an adverbial.

Why: Progressive constructions. [[Spanish#^es-Q0534|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFA%20qui%C3%A9n%20le%20est%C3%A1%20hablando%3F)
^es-Q0534-answer

**es-Q0535** — De verdad espero que nadie nos viera haciendo eso.

I really hope nobody saw us doing that.

Expected form: **haciendo**

Why: Progressive constructions. [[Spanish#^es-Q0535|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=De%20verdad%20espero%20que%20nadie%20nos%20viera%20haciendo%20eso.)
^es-Q0535-answer

**es-Q0536** — De verdad espero que nadie nos viera haciendo eso.

I really hope nobody saw us doing that.

Expected form: **haciendo**

Why: Progressive constructions. [[Spanish#^es-Q0536|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=De%20verdad%20espero%20que%20nadie%20nos%20viera%20haciendo%20eso.)
^es-Q0536-answer

**es-Q0537** — Mi hermana no está estudiando ahora.

My sister isn't studying now.

Expected form: **estudiando**

Why: Progressive constructions. [[Spanish#^es-Q0537|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Mi%20hermana%20no%20est%C3%A1%20estudiando%20ahora.)
^es-Q0537-answer

**es-Q0538** — Mi hermana no está estudiando ahora.

My sister isn't studying now.

Why: Progressive constructions. [[Spanish#^es-Q0538|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Mi%20hermana%20no%20est%C3%A1%20estudiando%20ahora.)
^es-Q0538-answer

**es-Q0539** — Tom sigue diciendo que es inocente.

Tom keeps saying he's innocent.

Why: Progressive constructions. [[Spanish#^es-Q0539|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tom%20sigue%20diciendo%20que%20es%20inocente.)
^es-Q0539-answer

**es-Q0540** — Tom sigue diciendo que es inocente.

Tom keeps saying he's innocent.

Estar + gerund focuses on an ongoing action. Spanish does not use the progressive in all situations where English does. A gerund can also appear with other verbs or as an adverbial.

Why: Progressive constructions. [[Spanish#^es-Q0540|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tom%20sigue%20diciendo%20que%20es%20inocente.)
^es-Q0540-answer

**es-Q0541** — Pasé toda la mañana estudiando inglés.

I spent the whole morning studying English.

Expected form: **estudiando**

Why: Progressive constructions. [[Spanish#^es-Q0541|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Pas%C3%A9%20toda%20la%20ma%C3%B1ana%20estudiando%20ingl%C3%A9s.)
^es-Q0541-answer

**es-Q0542** — Pasé toda la mañana estudiando inglés.

I spent the whole morning studying English.

Expected form: **estudiando**

Why: Progressive constructions. [[Spanish#^es-Q0542|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Pas%C3%A9%20toda%20la%20ma%C3%B1ana%20estudiando%20ingl%C3%A9s.)
^es-Q0542-answer

**es-Q0543** — ¿Con quién estás hablando ahora?

Who are you talking with now?

Expected form: **hablando**

Why: Progressive constructions. [[Spanish#^es-Q0543|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFCon%20qui%C3%A9n%20est%C3%A1s%20hablando%20ahora%3F)
^es-Q0543-answer

**es-Q0544** — ¿Con quién estás hablando ahora?

Who are you talking with now?

Why: Progressive constructions. [[Spanish#^es-Q0544|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFCon%20qui%C3%A9n%20est%C3%A1s%20hablando%20ahora%3F)
^es-Q0544-answer

**es-Q0545** — Va haciendo más calor día a día.

It is getting hotter day by day.

Why: Progressive constructions. [[Spanish#^es-Q0545|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Va%20haciendo%20m%C3%A1s%20calor%20d%C3%ADa%20a%20d%C3%ADa.)
^es-Q0545-answer

**es-Q0546** — Va haciendo más calor día a día.

It is getting hotter day by day.

Estar + gerund focuses on an ongoing action. Spanish does not use the progressive in all situations where English does. A gerund can also appear with other verbs or as an adverbial.

Why: Progressive constructions. [[Spanish#^es-Q0546|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Va%20haciendo%20m%C3%A1s%20calor%20d%C3%ADa%20a%20d%C3%ADa.)
^es-Q0546-answer

**es-Q0547** — Dejen a Tom terminar lo que está haciendo.

Let Tom finish what he's doing.

Expected form: **haciendo**

Why: Progressive constructions. [[Spanish#^es-Q0547|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Dejen%20a%20Tom%20terminar%20lo%20que%20est%C3%A1%20haciendo.)
^es-Q0547-answer

**es-Q0548** — Dejen a Tom terminar lo que está haciendo.

Let Tom finish what he's doing.

Expected form: **haciendo**

Why: Progressive constructions. [[Spanish#^es-Q0548|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Dejen%20a%20Tom%20terminar%20lo%20que%20est%C3%A1%20haciendo.)
^es-Q0548-answer

**es-Q0549** — ¿Qué está haciendo Tom aquí fuera?

What's Tom doing out here?

Expected form: **haciendo**

Why: Progressive constructions. [[Spanish#^es-Q0549|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFQu%C3%A9%20est%C3%A1%20haciendo%20Tom%20aqu%C3%AD%20fuera%3F)
^es-Q0549-answer

**es-Q0550** — ¿Qué está haciendo Tom aquí fuera?

What's Tom doing out here?

Why: Progressive constructions. [[Spanish#^es-Q0550|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFQu%C3%A9%20est%C3%A1%20haciendo%20Tom%20aqu%C3%AD%20fuera%3F)
^es-Q0550-answer


### Answers 551–600

**es-Q0551** — Tom no le creyó a Mary.

Tom didn't believe Mary.

Why: Object pronouns. [[Spanish#^es-Q0551|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tom%20no%20le%20crey%C3%B3%20a%20Mary.)
^es-Q0551-answer

**es-Q0552** — Tom no le creyó a Mary.

Tom didn't believe Mary.

Lo/la/los/las generally mark direct objects; le/les generally mark indirect objects. Regional leísmo complicates some personal direct objects. Before lo/la/los/las, an indirect le/les becomes se.

Why: Object pronouns. [[Spanish#^es-Q0552|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tom%20no%20le%20crey%C3%B3%20a%20Mary.)
^es-Q0552-answer

**es-Q0553** — Ha de haber alguna razón por lo que ha hecho.

There must be some reason for what he has done.

Expected form: **lo**

Why: Object pronouns. [[Spanish#^es-Q0553|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Ha%20de%20haber%20alguna%20raz%C3%B3n%20por%20lo%20que%20ha%20hecho.)
^es-Q0553-answer

**es-Q0554** — Ha de haber alguna razón por lo que ha hecho.

There must be some reason for what he has done.

Expected form: **lo**

Why: Object pronouns. [[Spanish#^es-Q0554|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Ha%20de%20haber%20alguna%20raz%C3%B3n%20por%20lo%20que%20ha%20hecho.)
^es-Q0554-answer

**es-Q0555** — Me siento totalmente fuera de lugar.

I feel so out of place.

Expected form: **Me**

Why: Object pronouns. [[Spanish#^es-Q0555|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Me%20siento%20totalmente%20fuera%20de%20lugar.)
^es-Q0555-answer

**es-Q0556** — Me siento totalmente fuera de lugar.

I feel so out of place.

Why: Object pronouns. [[Spanish#^es-Q0556|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Me%20siento%20totalmente%20fuera%20de%20lugar.)
^es-Q0556-answer

**es-Q0557** — ¿Cómo dices? No te he entendido.

Sorry. I beg your pardon?

Why: Object pronouns. [[Spanish#^es-Q0557|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFC%C3%B3mo%20dices%3F%20No%20te%20he%20entendido.)
^es-Q0557-answer

**es-Q0558** — ¿Cómo dices? No te he entendido.

Sorry. I beg your pardon?

Lo/la/los/las generally mark direct objects; le/les generally mark indirect objects. Regional leísmo complicates some personal direct objects. Before lo/la/los/las, an indirect le/les becomes se.

Why: Object pronouns. [[Spanish#^es-Q0558|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFC%C3%B3mo%20dices%3F%20No%20te%20he%20entendido.)
^es-Q0558-answer

**es-Q0559** — No lo veo como arte.

I don't see it as art.

Expected form: **lo**

Why: Object pronouns. [[Spanish#^es-Q0559|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20lo%20veo%20como%20arte.)
^es-Q0559-answer

**es-Q0560** — No lo veo como arte.

I don't see it as art.

Expected form: **lo**

Why: Object pronouns. [[Spanish#^es-Q0560|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20lo%20veo%20como%20arte.)
^es-Q0560-answer

**es-Q0561** — El costo de reparar el techo la dejó pasmada.

The cost of repairing the roof shocked her.

Expected form: **la**

Why: Object pronouns. [[Spanish#^es-Q0561|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=El%20costo%20de%20reparar%20el%20techo%20la%20dej%C3%B3%20pasmada.)
^es-Q0561-answer

**es-Q0562** — El costo de reparar el techo la dejó pasmada.

The cost of repairing the roof shocked her.

Why: Object pronouns. [[Spanish#^es-Q0562|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=El%20costo%20de%20reparar%20el%20techo%20la%20dej%C3%B3%20pasmada.)
^es-Q0562-answer

**es-Q0563** — ¿Y si te equivocas?

What if you're wrong?

Why: Object pronouns. [[Spanish#^es-Q0563|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFY%20si%20te%20equivocas%3F)
^es-Q0563-answer

**es-Q0564** — ¿Y si te equivocas?

What if you're wrong?

Lo/la/los/las generally mark direct objects; le/les generally mark indirect objects. Regional leísmo complicates some personal direct objects. Before lo/la/los/las, an indirect le/les becomes se.

Why: Object pronouns. [[Spanish#^es-Q0564|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFY%20si%20te%20equivocas%3F)
^es-Q0564-answer

**es-Q0565** — Estuvimos viendo la tele ayer.

We were watching TV yesterday.

Expected form: **la**

Why: Object pronouns. [[Spanish#^es-Q0565|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Estuvimos%20viendo%20la%20tele%20ayer.)
^es-Q0565-answer

**es-Q0566** — Estuvimos viendo la tele ayer.

We were watching TV yesterday.

Expected form: **la**

Why: Object pronouns. [[Spanish#^es-Q0566|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Estuvimos%20viendo%20la%20tele%20ayer.)
^es-Q0566-answer

**es-Q0567** — A ella también le encanta el chocolate.

She loves chocolate, too.

Expected form: **le**

Why: Object pronouns. [[Spanish#^es-Q0567|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=A%20ella%20tambi%C3%A9n%20le%20encanta%20el%20chocolate.)
^es-Q0567-answer

**es-Q0568** — A ella también le encanta el chocolate.

She loves chocolate, too.

Why: Object pronouns. [[Spanish#^es-Q0568|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=A%20ella%20tambi%C3%A9n%20le%20encanta%20el%20chocolate.)
^es-Q0568-answer

**es-Q0569** — Ese truco yo no lo sabía.

I didn't know that trick.

Why: Object pronouns. [[Spanish#^es-Q0569|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Ese%20truco%20yo%20no%20lo%20sab%C3%ADa.)
^es-Q0569-answer

**es-Q0570** — Ese truco yo no lo sabía.

I didn't know that trick.

Lo/la/los/las generally mark direct objects; le/les generally mark indirect objects. Regional leísmo complicates some personal direct objects. Before lo/la/los/las, an indirect le/les becomes se.

Why: Object pronouns. [[Spanish#^es-Q0570|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Ese%20truco%20yo%20no%20lo%20sab%C3%ADa.)
^es-Q0570-answer

**es-Q0571** — No os preocupéis por mí.

Don't worry about me.

Expected form: **os**

Why: Object pronouns. [[Spanish#^es-Q0571|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20os%20preocup%C3%A9is%20por%20m%C3%AD.)
^es-Q0571-answer

**es-Q0572** — No os preocupéis por mí.

Don't worry about me.

Expected form: **os**

Why: Object pronouns. [[Spanish#^es-Q0572|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20os%20preocup%C3%A9is%20por%20m%C3%AD.)
^es-Q0572-answer

**es-Q0573** — Por favor, ponga la palanca hacia arriba.

Please push up the lever.

Expected form: **la**

Why: Object pronouns. [[Spanish#^es-Q0573|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Por%20favor%2C%20ponga%20la%20palanca%20hacia%20arriba.)
^es-Q0573-answer

**es-Q0574** — Por favor, ponga la palanca hacia arriba.

Please push up the lever.

Why: Object pronouns. [[Spanish#^es-Q0574|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Por%20favor%2C%20ponga%20la%20palanca%20hacia%20arriba.)
^es-Q0574-answer

**es-Q0575** — El dinero le gusta a todo el mundo.

Everybody likes money.

Why: Object pronouns. [[Spanish#^es-Q0575|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=El%20dinero%20le%20gusta%20a%20todo%20el%20mundo.)
^es-Q0575-answer

**es-Q0576** — El dinero le gusta a todo el mundo.

Everybody likes money.

Lo/la/los/las generally mark direct objects; le/les generally mark indirect objects. Regional leísmo complicates some personal direct objects. Before lo/la/los/las, an indirect le/les becomes se.

Why: Object pronouns. [[Spanish#^es-Q0576|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=El%20dinero%20le%20gusta%20a%20todo%20el%20mundo.)
^es-Q0576-answer

**es-Q0577** — Las chicas excitadas a veces parecen bonitas.

Excited girls look pretty sometimes.

Expected form: **Las**

Why: Object pronouns. [[Spanish#^es-Q0577|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Las%20chicas%20excitadas%20a%20veces%20parecen%20bonitas.)
^es-Q0577-answer

**es-Q0578** — Las chicas excitadas a veces parecen bonitas.

Excited girls look pretty sometimes.

Expected form: **Las**

Why: Object pronouns. [[Spanish#^es-Q0578|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Las%20chicas%20excitadas%20a%20veces%20parecen%20bonitas.)
^es-Q0578-answer

**es-Q0579** — Compré la mesa de caoba por ser la más elegante.

I bought the mahogany table because it was the most elegant.

Expected form: **la**

Why: Object pronouns. [[Spanish#^es-Q0579|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Compr%C3%A9%20la%20mesa%20de%20caoba%20por%20ser%20la%20m%C3%A1s%20elegante.)
^es-Q0579-answer

**es-Q0580** — Compré la mesa de caoba por ser la más elegante.

I bought the mahogany table because it was the most elegant.

Why: Object pronouns. [[Spanish#^es-Q0580|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Compr%C3%A9%20la%20mesa%20de%20caoba%20por%20ser%20la%20m%C3%A1s%20elegante.)
^es-Q0580-answer

**es-Q0581** — Yanni ganó la lotería en Argelia.

Yanni won the lottery in Algeria.

Why: Object pronouns. [[Spanish#^es-Q0581|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Yanni%20gan%C3%B3%20la%20loter%C3%ADa%20en%20Argelia.)
^es-Q0581-answer

**es-Q0582** — Yanni ganó la lotería en Argelia.

Yanni won the lottery in Algeria.

Lo/la/los/las generally mark direct objects; le/les generally mark indirect objects. Regional leísmo complicates some personal direct objects. Before lo/la/los/las, an indirect le/les becomes se.

Why: Object pronouns. [[Spanish#^es-Q0582|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Yanni%20gan%C3%B3%20la%20loter%C3%ADa%20en%20Argelia.)
^es-Q0582-answer

**es-Q0583** — He visto cada fotograma de las películas de Dan.

I have seen every frame of Dan's movies.

Expected form: **las**

Why: Object pronouns. [[Spanish#^es-Q0583|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=He%20visto%20cada%20fotograma%20de%20las%20pel%C3%ADculas%20de%20Dan.)
^es-Q0583-answer

**es-Q0584** — He visto cada fotograma de las películas de Dan.

I have seen every frame of Dan's movies.

Expected form: **las**

Why: Object pronouns. [[Spanish#^es-Q0584|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=He%20visto%20cada%20fotograma%20de%20las%20pel%C3%ADculas%20de%20Dan.)
^es-Q0584-answer

**es-Q0585** — Lo ha hecho mejor que la vez pasada.

He has done better than last time.

Expected form: **Lo**

Why: Object pronouns. [[Spanish#^es-Q0585|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Lo%20ha%20hecho%20mejor%20que%20la%20vez%20pasada.)
^es-Q0585-answer

**es-Q0586** — Lo ha hecho mejor que la vez pasada.

He has done better than last time.

Why: Object pronouns. [[Spanish#^es-Q0586|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Lo%20ha%20hecho%20mejor%20que%20la%20vez%20pasada.)
^es-Q0586-answer

**es-Q0587** — Existen numerosas teorías acerca del origen de la vida.

There are numerous theories about the origin of life.

Why: Object pronouns. [[Spanish#^es-Q0587|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Existen%20numerosas%20teor%C3%ADas%20acerca%20del%20origen%20de%20la%20vida.)
^es-Q0587-answer

**es-Q0588** — Existen numerosas teorías acerca del origen de la vida.

There are numerous theories about the origin of life.

Lo/la/los/las generally mark direct objects; le/les generally mark indirect objects. Regional leísmo complicates some personal direct objects. Before lo/la/los/las, an indirect le/les becomes se.

Why: Object pronouns. [[Spanish#^es-Q0588|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Existen%20numerosas%20teor%C3%ADas%20acerca%20del%20origen%20de%20la%20vida.)
^es-Q0588-answer

**es-Q0589** — ¿Se os ha olvidado hacer los deberes?

Did you forget to do your homework?

Expected form: **os**

Why: Object pronouns. [[Spanish#^es-Q0589|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFSe%20os%20ha%20olvidado%20hacer%20los%20deberes%3F)
^es-Q0589-answer

**es-Q0590** — ¿Se os ha olvidado hacer los deberes?

Did you forget to do your homework?

Expected form: **os**

Why: Object pronouns. [[Spanish#^es-Q0590|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFSe%20os%20ha%20olvidado%20hacer%20los%20deberes%3F)
^es-Q0590-answer

**es-Q0591** — Devuélvete a la casa.

Go back home.

Expected form: **la**

Why: Object pronouns. [[Spanish#^es-Q0591|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Devu%C3%A9lvete%20a%20la%20casa.)
^es-Q0591-answer

**es-Q0592** — Devuélvete a la casa.

Go back home.

Why: Object pronouns. [[Spanish#^es-Q0592|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Devu%C3%A9lvete%20a%20la%20casa.)
^es-Q0592-answer

**es-Q0593** — Voy a ir a jugar a la pelota con Mohan.

I am going to go play ball with Mohan.

Why: Object pronouns. [[Spanish#^es-Q0593|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Voy%20a%20ir%20a%20jugar%20a%20la%20pelota%20con%20Mohan.)
^es-Q0593-answer

**es-Q0594** — Voy a ir a jugar a la pelota con Mohan.

I am going to go play ball with Mohan.

Lo/la/los/las generally mark direct objects; le/les generally mark indirect objects. Regional leísmo complicates some personal direct objects. Before lo/la/los/las, an indirect le/les becomes se.

Why: Object pronouns. [[Spanish#^es-Q0594|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Voy%20a%20ir%20a%20jugar%20a%20la%20pelota%20con%20Mohan.)
^es-Q0594-answer

**es-Q0595** — Me gusta jugar al futbol.

I like to play soccer.

Expected form: **Me**

Why: Object pronouns. [[Spanish#^es-Q0595|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Me%20gusta%20jugar%20al%20futbol.)
^es-Q0595-answer

**es-Q0596** — Me gusta jugar al futbol.

I like to play soccer.

Expected form: **Me**

Why: Object pronouns. [[Spanish#^es-Q0596|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Me%20gusta%20jugar%20al%20futbol.)
^es-Q0596-answer

**es-Q0597** — La propia voluntad supera cualquier orden.

One's own will overrides any command.

Expected form: **La**

Why: Object pronouns. [[Spanish#^es-Q0597|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=La%20propia%20voluntad%20supera%20cualquier%20orden.)
^es-Q0597-answer

**es-Q0598** — La propia voluntad supera cualquier orden.

One's own will overrides any command.

Why: Object pronouns. [[Spanish#^es-Q0598|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=La%20propia%20voluntad%20supera%20cualquier%20orden.)
^es-Q0598-answer

**es-Q0599** — La señal cambió de roja a verde.

The signal turned from red to green.

Why: Object pronouns. [[Spanish#^es-Q0599|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=La%20se%C3%B1al%20cambi%C3%B3%20de%20roja%20a%20verde.)
^es-Q0599-answer

**es-Q0600** — La señal cambió de roja a verde.

The signal turned from red to green.

Lo/la/los/las generally mark direct objects; le/les generally mark indirect objects. Regional leísmo complicates some personal direct objects. Before lo/la/los/las, an indirect le/les becomes se.

Why: Object pronouns. [[Spanish#^es-Q0600|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=La%20se%C3%B1al%20cambi%C3%B3%20de%20roja%20a%20verde.)
^es-Q0600-answer


### Answers 601–650

**es-Q0601** — Tom se bebió un vaso de leche.

Tom drank a glass of milk.

Expected form: **se**

Why: Reflexive and other se. [[Spanish#^es-Q0601|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tom%20se%20bebi%C3%B3%20un%20vaso%20de%20leche.)
^es-Q0601-answer

**es-Q0602** — Tom se bebió un vaso de leche.

Tom drank a glass of milk.

Expected form: **se**

Why: Reflexive and other se. [[Spanish#^es-Q0602|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tom%20se%20bebi%C3%B3%20un%20vaso%20de%20leche.)
^es-Q0602-answer

**es-Q0603** — ¿Qué se puede encontrar más allá del final del universo?

What can be found beyond the end of the universe?

Expected form: **se**

Why: Reflexive and other se. [[Spanish#^es-Q0603|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFQu%C3%A9%20se%20puede%20encontrar%20m%C3%A1s%20all%C3%A1%20del%20final%20del%20universo%3F)
^es-Q0603-answer

**es-Q0604** — ¿Qué se puede encontrar más allá del final del universo?

What can be found beyond the end of the universe?

Why: Reflexive and other se. [[Spanish#^es-Q0604|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFQu%C3%A9%20se%20puede%20encontrar%20m%C3%A1s%20all%C3%A1%20del%20final%20del%20universo%3F)
^es-Q0604-answer

**es-Q0605** — ¿Como se dice eso en cabilio?

What's it called in Kabyle?

Why: Reflexive and other se. [[Spanish#^es-Q0605|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFComo%20se%20dice%20eso%20en%20cabilio%3F)
^es-Q0605-answer

**es-Q0606** — ¿Como se dice eso en cabilio?

What's it called in Kabyle?

Se can mark reflexivity, reciprocal action, an impersonal/passive-like construction or an indirect object before a direct clitic. Decide from the verb and participants rather than treating all se alike.

Why: Reflexive and other se. [[Spanish#^es-Q0606|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFComo%20se%20dice%20eso%20en%20cabilio%3F)
^es-Q0606-answer

**es-Q0607** — Parece que Tony se compró un auto costoso.

It seems that Tony bought an expensive car.

Expected form: **se**

Why: Reflexive and other se. [[Spanish#^es-Q0607|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Parece%20que%20Tony%20se%20compr%C3%B3%20un%20auto%20costoso.)
^es-Q0607-answer

**es-Q0608** — Parece que Tony se compró un auto costoso.

It seems that Tony bought an expensive car.

Expected form: **se**

Why: Reflexive and other se. [[Spanish#^es-Q0608|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Parece%20que%20Tony%20se%20compr%C3%B3%20un%20auto%20costoso.)
^es-Q0608-answer

**es-Q0609** — Si la pintamos de blanco, la habitación se volverá más luminosa.

White paint will brighten the room.

Expected form: **se**

Why: Reflexive and other se. [[Spanish#^es-Q0609|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Si%20la%20pintamos%20de%20blanco%2C%20la%20habitaci%C3%B3n%20se%20volver%C3%A1%20m%C3%A1s%20luminosa.)
^es-Q0609-answer

**es-Q0610** — Si la pintamos de blanco, la habitación se volverá más luminosa.

White paint will brighten the room.

Why: Reflexive and other se. [[Spanish#^es-Q0610|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Si%20la%20pintamos%20de%20blanco%2C%20la%20habitaci%C3%B3n%20se%20volver%C3%A1%20m%C3%A1s%20luminosa.)
^es-Q0610-answer

**es-Q0611** — Se requiere coraje para cambiar una costumbre.

Courage is needed to change a custom.

Why: Reflexive and other se. [[Spanish#^es-Q0611|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Se%20requiere%20coraje%20para%20cambiar%20una%20costumbre.)
^es-Q0611-answer

**es-Q0612** — Se requiere coraje para cambiar una costumbre.

Courage is needed to change a custom.

Se can mark reflexivity, reciprocal action, an impersonal/passive-like construction or an indirect object before a direct clitic. Decide from the verb and participants rather than treating all se alike.

Why: Reflexive and other se. [[Spanish#^es-Q0612|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Se%20requiere%20coraje%20para%20cambiar%20una%20costumbre.)
^es-Q0612-answer

**es-Q0613** — Desde que se hirió en un accidente, no ha podido volver a andar.

Since he was injured in an accident, he could no longer walk.

Expected form: **se**

Why: Reflexive and other se. [[Spanish#^es-Q0613|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Desde%20que%20se%20hiri%C3%B3%20en%20un%20accidente%2C%20no%20ha%20podido%20volver%20a%20andar.)
^es-Q0613-answer

**es-Q0614** — Desde que se hirió en un accidente, no ha podido volver a andar.

Since he was injured in an accident, he could no longer walk.

Expected form: **se**

Why: Reflexive and other se. [[Spanish#^es-Q0614|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Desde%20que%20se%20hiri%C3%B3%20en%20un%20accidente%2C%20no%20ha%20podido%20volver%20a%20andar.)
^es-Q0614-answer

**es-Q0615** — Los huevos se pueden ocupar como armas.

Eggs can be used as weapons.

Expected form: **se**

Why: Reflexive and other se. [[Spanish#^es-Q0615|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Los%20huevos%20se%20pueden%20ocupar%20como%20armas.)
^es-Q0615-answer

**es-Q0616** — Los huevos se pueden ocupar como armas.

Eggs can be used as weapons.

Why: Reflexive and other se. [[Spanish#^es-Q0616|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Los%20huevos%20se%20pueden%20ocupar%20como%20armas.)
^es-Q0616-answer

**es-Q0617** — Ella se tranquilizó antes de hablar.

She composed herself before speaking.

Why: Reflexive and other se. [[Spanish#^es-Q0617|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Ella%20se%20tranquiliz%C3%B3%20antes%20de%20hablar.)
^es-Q0617-answer

**es-Q0618** — Ella se tranquilizó antes de hablar.

She composed herself before speaking.

Se can mark reflexivity, reciprocal action, an impersonal/passive-like construction or an indirect object before a direct clitic. Decide from the verb and participants rather than treating all se alike.

Why: Reflexive and other se. [[Spanish#^es-Q0618|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Ella%20se%20tranquiliz%C3%B3%20antes%20de%20hablar.)
^es-Q0618-answer

**es-Q0619** — Tom se vio obligado a abandonar la misión.

Tom was forced to abandon the mission.

Expected form: **se**

Why: Reflexive and other se. [[Spanish#^es-Q0619|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tom%20se%20vio%20obligado%20a%20abandonar%20la%20misi%C3%B3n.)
^es-Q0619-answer

**es-Q0620** — Tom se vio obligado a abandonar la misión.

Tom was forced to abandon the mission.

Expected form: **se**

Why: Reflexive and other se. [[Spanish#^es-Q0620|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tom%20se%20vio%20obligado%20a%20abandonar%20la%20misi%C3%B3n.)
^es-Q0620-answer

**es-Q0621** — Tom se subió al bus equivocado.

Tom got on the wrong bus.

Expected form: **se**

Why: Reflexive and other se. [[Spanish#^es-Q0621|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tom%20se%20subi%C3%B3%20al%20bus%20equivocado.)
^es-Q0621-answer

**es-Q0622** — Tom se subió al bus equivocado.

Tom got on the wrong bus.

Why: Reflexive and other se. [[Spanish#^es-Q0622|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tom%20se%20subi%C3%B3%20al%20bus%20equivocado.)
^es-Q0622-answer

**es-Q0623** — Es por esto que él se enojó contigo.

This is why he got angry with you.

Why: Reflexive and other se. [[Spanish#^es-Q0623|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Es%20por%20esto%20que%20%C3%A9l%20se%20enoj%C3%B3%20contigo.)
^es-Q0623-answer

**es-Q0624** — Es por esto que él se enojó contigo.

This is why he got angry with you.

Se can mark reflexivity, reciprocal action, an impersonal/passive-like construction or an indirect object before a direct clitic. Decide from the verb and participants rather than treating all se alike.

Why: Reflexive and other se. [[Spanish#^es-Q0624|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Es%20por%20esto%20que%20%C3%A9l%20se%20enoj%C3%B3%20contigo.)
^es-Q0624-answer

**es-Q0625** — Él se metió las manos en los bolsillos.

He put his hands in his pockets.

Expected form: **se**

Why: Reflexive and other se. [[Spanish#^es-Q0625|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C3%89l%20se%20meti%C3%B3%20las%20manos%20en%20los%20bolsillos.)
^es-Q0625-answer

**es-Q0626** — Él se metió las manos en los bolsillos.

He put his hands in his pockets.

Expected form: **se**

Why: Reflexive and other se. [[Spanish#^es-Q0626|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C3%89l%20se%20meti%C3%B3%20las%20manos%20en%20los%20bolsillos.)
^es-Q0626-answer

**es-Q0627** — Se situó en el centro de la calle con un cartel que decía "Abrazos gratis".

He placed himself in the middle of the street with a sign that said, "Free hugs."

Expected form: **Se**

Why: Reflexive and other se. [[Spanish#^es-Q0627|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Se%20situ%C3%B3%20en%20el%20centro%20de%20la%20calle%20con%20un%20cartel%20que%20dec%C3%ADa%20%22Abrazos%20gratis%22.)
^es-Q0627-answer

**es-Q0628** — Se situó en el centro de la calle con un cartel que decía "Abrazos gratis".

He placed himself in the middle of the street with a sign that said, "Free hugs."

Why: Reflexive and other se. [[Spanish#^es-Q0628|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Se%20situ%C3%B3%20en%20el%20centro%20de%20la%20calle%20con%20un%20cartel%20que%20dec%C3%ADa%20%22Abrazos%20gratis%22.)
^es-Q0628-answer

**es-Q0629** — Se produjo un incendio durante la noche.

A fire broke out during the night.

Why: Reflexive and other se. [[Spanish#^es-Q0629|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Se%20produjo%20un%20incendio%20durante%20la%20noche.)
^es-Q0629-answer

**es-Q0630** — Se produjo un incendio durante la noche.

A fire broke out during the night.

Se can mark reflexivity, reciprocal action, an impersonal/passive-like construction or an indirect object before a direct clitic. Decide from the verb and participants rather than treating all se alike.

Why: Reflexive and other se. [[Spanish#^es-Q0630|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Se%20produjo%20un%20incendio%20durante%20la%20noche.)
^es-Q0630-answer

**es-Q0631** — No se permiten mascotas.

No pets allowed.

Expected form: **se**

Why: Reflexive and other se. [[Spanish#^es-Q0631|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20se%20permiten%20mascotas.)
^es-Q0631-answer

**es-Q0632** — No se permiten mascotas.

No pets allowed.

Expected form: **se**

Why: Reflexive and other se. [[Spanish#^es-Q0632|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20se%20permiten%20mascotas.)
^es-Q0632-answer

**es-Q0633** — ¿Se te ha ido la pinza?

Are you out of your mind?

Expected form: **Se**

Why: Reflexive and other se. [[Spanish#^es-Q0633|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFSe%20te%20ha%20ido%20la%20pinza%3F)
^es-Q0633-answer

**es-Q0634** — ¿Se te ha ido la pinza?

Are you out of your mind?

Why: Reflexive and other se. [[Spanish#^es-Q0634|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFSe%20te%20ha%20ido%20la%20pinza%3F)
^es-Q0634-answer

**es-Q0635** — Debido a su puntaje de cero, no se atrevía a volver.

Because of his score of zero, he didn't dare to return.

Why: Reflexive and other se. [[Spanish#^es-Q0635|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Debido%20a%20su%20puntaje%20de%20cero%2C%20no%20se%20atrev%C3%ADa%20a%20volver.)
^es-Q0635-answer

**es-Q0636** — Debido a su puntaje de cero, no se atrevía a volver.

Because of his score of zero, he didn't dare to return.

Se can mark reflexivity, reciprocal action, an impersonal/passive-like construction or an indirect object before a direct clitic. Decide from the verb and participants rather than treating all se alike.

Why: Reflexive and other se. [[Spanish#^es-Q0636|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Debido%20a%20su%20puntaje%20de%20cero%2C%20no%20se%20atrev%C3%ADa%20a%20volver.)
^es-Q0636-answer

**es-Q0637** — Mary no se puede decidir si comprar el vestido o no.

Mary can't decide whether or not to buy the dress.

Expected form: **se**

Why: Reflexive and other se. [[Spanish#^es-Q0637|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Mary%20no%20se%20puede%20decidir%20si%20comprar%20el%20vestido%20o%20no.)
^es-Q0637-answer

**es-Q0638** — Mary no se puede decidir si comprar el vestido o no.

Mary can't decide whether or not to buy the dress.

Expected form: **se**

Why: Reflexive and other se. [[Spanish#^es-Q0638|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Mary%20no%20se%20puede%20decidir%20si%20comprar%20el%20vestido%20o%20no.)
^es-Q0638-answer

**es-Q0639** — Los cursos intermedios y avanzados de una lengua se dan en la lengua que se está aprendiendo.

Intermediate and advanced language courses are given in the language being learned.

Expected form: **se**

Why: Reflexive and other se. [[Spanish#^es-Q0639|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Los%20cursos%20intermedios%20y%20avanzados%20de%20una%20lengua%20se%20dan%20en%20la%20lengua%20que%20se%20est%C3%A1%20aprendiendo.)
^es-Q0639-answer

**es-Q0640** — Los cursos intermedios y avanzados de una lengua se dan en la lengua que se está aprendiendo.

Intermediate and advanced language courses are given in the language being learned.

Why: Reflexive and other se. [[Spanish#^es-Q0640|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Los%20cursos%20intermedios%20y%20avanzados%20de%20una%20lengua%20se%20dan%20en%20la%20lengua%20que%20se%20est%C3%A1%20aprendiendo.)
^es-Q0640-answer

**es-Q0641** — Mi hermano se ha comprado una guitarra eléctrica.

My brother bought an electric guitar.

Why: Reflexive and other se. [[Spanish#^es-Q0641|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Mi%20hermano%20se%20ha%20comprado%20una%20guitarra%20el%C3%A9ctrica.)
^es-Q0641-answer

**es-Q0642** — Mi hermano se ha comprado una guitarra eléctrica.

My brother bought an electric guitar.

Se can mark reflexivity, reciprocal action, an impersonal/passive-like construction or an indirect object before a direct clitic. Decide from the verb and participants rather than treating all se alike.

Why: Reflexive and other se. [[Spanish#^es-Q0642|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Mi%20hermano%20se%20ha%20comprado%20una%20guitarra%20el%C3%A9ctrica.)
^es-Q0642-answer

**es-Q0643** — Ella se casó con ella.

She got married to her.

Expected form: **se**

Why: Reflexive and other se. [[Spanish#^es-Q0643|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Ella%20se%20cas%C3%B3%20con%20ella.)
^es-Q0643-answer

**es-Q0644** — Ella se casó con ella.

She got married to her.

Expected form: **se**

Why: Reflexive and other se. [[Spanish#^es-Q0644|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Ella%20se%20cas%C3%B3%20con%20ella.)
^es-Q0644-answer

**es-Q0645** — No creo que se me necesite más aquí.

I don't think I'm needed here any longer.

Expected form: **se**

Why: Reflexive and other se. [[Spanish#^es-Q0645|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20creo%20que%20se%20me%20necesite%20m%C3%A1s%20aqu%C3%AD.)
^es-Q0645-answer

**es-Q0646** — No creo que se me necesite más aquí.

I don't think I'm needed here any longer.

Why: Reflexive and other se. [[Spanish#^es-Q0646|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20creo%20que%20se%20me%20necesite%20m%C3%A1s%20aqu%C3%AD.)
^es-Q0646-answer

**es-Q0647** — Mucha gente se casa los sábados.

Lots of people get married on Saturdays.

Why: Reflexive and other se. [[Spanish#^es-Q0647|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Mucha%20gente%20se%20casa%20los%20s%C3%A1bados.)
^es-Q0647-answer

**es-Q0648** — Mucha gente se casa los sábados.

Lots of people get married on Saturdays.

Se can mark reflexivity, reciprocal action, an impersonal/passive-like construction or an indirect object before a direct clitic. Decide from the verb and participants rather than treating all se alike.

Why: Reflexive and other se. [[Spanish#^es-Q0648|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Mucha%20gente%20se%20casa%20los%20s%C3%A1bados.)
^es-Q0648-answer

**es-Q0649** — Deseo oír la historia completa, y no se salte ningún detalle.

I want to hear the whole story, and don't skip any details.

Expected form: **se**

Why: Reflexive and other se. [[Spanish#^es-Q0649|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Deseo%20o%C3%ADr%20la%20historia%20completa%2C%20y%20no%20se%20salte%20ning%C3%BAn%20detalle.)
^es-Q0649-answer

**es-Q0650** — Deseo oír la historia completa, y no se salte ningún detalle.

I want to hear the whole story, and don't skip any details.

Expected form: **se**

Why: Reflexive and other se. [[Spanish#^es-Q0650|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Deseo%20o%C3%ADr%20la%20historia%20completa%2C%20y%20no%20se%20salte%20ning%C3%BAn%20detalle.)
^es-Q0650-answer


### Answers 651–700

**es-Q0651** — No puedo, a pesar que quiero.

I can't even if I want to.

Expected form: **que**

Why: Relative words. [[Spanish#^es-Q0651|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20puedo%2C%20a%20pesar%20que%20quiero.)
^es-Q0651-answer

**es-Q0652** — No puedo, a pesar que quiero.

I can't even if I want to.

Why: Relative words. [[Spanish#^es-Q0652|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20puedo%2C%20a%20pesar%20que%20quiero.)
^es-Q0652-answer

**es-Q0653** — No puedo creer que Tom aceptara nuestra oferta.

I can't believe Tom accepted our offer.

Why: Relative words. [[Spanish#^es-Q0653|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20puedo%20creer%20que%20Tom%20aceptara%20nuestra%20oferta.)
^es-Q0653-answer

**es-Q0654** — No puedo creer que Tom aceptara nuestra oferta.

I can't believe Tom accepted our offer.

Relative words connect a clause to a referent. Cuyo agrees with the possessed noun, not the possessor. Que also introduces complement clauses; compare functions in the whole sentence.

Why: Relative words. [[Spanish#^es-Q0654|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20puedo%20creer%20que%20Tom%20aceptara%20nuestra%20oferta.)
^es-Q0654-answer

**es-Q0655** — Tuve que ir ahí solo.

I had to go there alone.

Expected form: **que**

Why: Relative words. [[Spanish#^es-Q0655|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tuve%20que%20ir%20ah%C3%AD%20solo.)
^es-Q0655-answer

**es-Q0656** — Tuve que ir ahí solo.

I had to go there alone.

Expected form: **que**

Why: Relative words. [[Spanish#^es-Q0656|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tuve%20que%20ir%20ah%C3%AD%20solo.)
^es-Q0656-answer

**es-Q0657** — Suba la persiana para que entre un poquito de luz.

Raise the blinds to let in a little light.

Expected form: **que**

Why: Relative words. [[Spanish#^es-Q0657|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Suba%20la%20persiana%20para%20que%20entre%20un%20poquito%20de%20luz.)
^es-Q0657-answer

**es-Q0658** — Suba la persiana para que entre un poquito de luz.

Raise the blinds to let in a little light.

Why: Relative words. [[Spanish#^es-Q0658|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Suba%20la%20persiana%20para%20que%20entre%20un%20poquito%20de%20luz.)
^es-Q0658-answer

**es-Q0659** — Hice a Tom prometer que no le dijera a Mary.

I made Tom promise not to tell Mary.

Why: Relative words. [[Spanish#^es-Q0659|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Hice%20a%20Tom%20prometer%20que%20no%20le%20dijera%20a%20Mary.)
^es-Q0659-answer

**es-Q0660** — Hice a Tom prometer que no le dijera a Mary.

I made Tom promise not to tell Mary.

Relative words connect a clause to a referent. Cuyo agrees with the possessed noun, not the possessor. Que also introduces complement clauses; compare functions in the whole sentence.

Why: Relative words. [[Spanish#^es-Q0660|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Hice%20a%20Tom%20prometer%20que%20no%20le%20dijera%20a%20Mary.)
^es-Q0660-answer

**es-Q0661** — Solo necesito que vengas conmigo.

I just need you to come with me.

Expected form: **que**

Why: Relative words. [[Spanish#^es-Q0661|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Solo%20necesito%20que%20vengas%20conmigo.)
^es-Q0661-answer

**es-Q0662** — Solo necesito que vengas conmigo.

I just need you to come with me.

Expected form: **que**

Why: Relative words. [[Spanish#^es-Q0662|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Solo%20necesito%20que%20vengas%20conmigo.)
^es-Q0662-answer

**es-Q0663** — Tom espera que Mary venga el próximo fin de semana.

Tom hopes that Mary will come next weekend.

Expected form: **que**

Why: Relative words. [[Spanish#^es-Q0663|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tom%20espera%20que%20Mary%20venga%20el%20pr%C3%B3ximo%20fin%20de%20semana.)
^es-Q0663-answer

**es-Q0664** — Tom espera que Mary venga el próximo fin de semana.

Tom hopes that Mary will come next weekend.

Why: Relative words. [[Spanish#^es-Q0664|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tom%20espera%20que%20Mary%20venga%20el%20pr%C3%B3ximo%20fin%20de%20semana.)
^es-Q0664-answer

**es-Q0665** — Si no lo intentas, nunca sabrás lo que eres capaz de hacer.

You never know what you can do till you try.

Why: Relative words. [[Spanish#^es-Q0665|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Si%20no%20lo%20intentas%2C%20nunca%20sabr%C3%A1s%20lo%20que%20eres%20capaz%20de%20hacer.)
^es-Q0665-answer

**es-Q0666** — Si no lo intentas, nunca sabrás lo que eres capaz de hacer.

You never know what you can do till you try.

Relative words connect a clause to a referent. Cuyo agrees with the possessed noun, not the possessor. Que also introduces complement clauses; compare functions in the whole sentence.

Why: Relative words. [[Spanish#^es-Q0666|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Si%20no%20lo%20intentas%2C%20nunca%20sabr%C3%A1s%20lo%20que%20eres%20capaz%20de%20hacer.)
^es-Q0666-answer

**es-Q0667** — Tom sostiene que no sabe nada acerca de Mary.

Tom claims he knows nothing about Mary.

Expected form: **que**

Why: Relative words. [[Spanish#^es-Q0667|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tom%20sostiene%20que%20no%20sabe%20nada%20acerca%20de%20Mary.)
^es-Q0667-answer

**es-Q0668** — Tom sostiene que no sabe nada acerca de Mary.

Tom claims he knows nothing about Mary.

Expected form: **que**

Why: Relative words. [[Spanish#^es-Q0668|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tom%20sostiene%20que%20no%20sabe%20nada%20acerca%20de%20Mary.)
^es-Q0668-answer

**es-Q0669** — ¿Crees que Tom tendrá éxito?

Do you think Tom will succeed?

Expected form: **que**

Why: Relative words. [[Spanish#^es-Q0669|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFCrees%20que%20Tom%20tendr%C3%A1%20%C3%A9xito%3F)
^es-Q0669-answer

**es-Q0670** — ¿Crees que Tom tendrá éxito?

Do you think Tom will succeed?

Why: Relative words. [[Spanish#^es-Q0670|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFCrees%20que%20Tom%20tendr%C3%A1%20%C3%A9xito%3F)
^es-Q0670-answer

**es-Q0671** — No es de sorprenderse que saliera electo alcalde.

It is not surprising that he was elected mayor.

Why: Relative words. [[Spanish#^es-Q0671|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20es%20de%20sorprenderse%20que%20saliera%20electo%20alcalde.)
^es-Q0671-answer

**es-Q0672** — No es de sorprenderse que saliera electo alcalde.

It is not surprising that he was elected mayor.

Relative words connect a clause to a referent. Cuyo agrees with the possessed noun, not the possessor. Que also introduces complement clauses; compare functions in the whole sentence.

Why: Relative words. [[Spanish#^es-Q0672|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20es%20de%20sorprenderse%20que%20saliera%20electo%20alcalde.)
^es-Q0672-answer

**es-Q0673** — No permito que duerman durante la clase.

I do not allow sleeping in class.

Expected form: **que**

Why: Relative words. [[Spanish#^es-Q0673|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20permito%20que%20duerman%20durante%20la%20clase.)
^es-Q0673-answer

**es-Q0674** — No permito que duerman durante la clase.

I do not allow sleeping in class.

Expected form: **que**

Why: Relative words. [[Spanish#^es-Q0674|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20permito%20que%20duerman%20durante%20la%20clase.)
^es-Q0674-answer

**es-Q0675** — María piensa que aprender idiomas extranjeros es tedioso y aburrido.

Mary thinks that learning foreign languages is tedious and boring.

Expected form: **que**

Why: Relative words. [[Spanish#^es-Q0675|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Mar%C3%ADa%20piensa%20que%20aprender%20idiomas%20extranjeros%20es%20tedioso%20y%20aburrido.)
^es-Q0675-answer

**es-Q0676** — María piensa que aprender idiomas extranjeros es tedioso y aburrido.

Mary thinks that learning foreign languages is tedious and boring.

Why: Relative words. [[Spanish#^es-Q0676|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Mar%C3%ADa%20piensa%20que%20aprender%20idiomas%20extranjeros%20es%20tedioso%20y%20aburrido.)
^es-Q0676-answer

**es-Q0677** — Mi chino no es perfecto, pero pude entender bastante de lo que él habló.

My Chinese is not perfect, but I could understand enough of what he said.

Why: Relative words. [[Spanish#^es-Q0677|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Mi%20chino%20no%20es%20perfecto%2C%20pero%20pude%20entender%20bastante%20de%20lo%20que%20%C3%A9l%20habl%C3%B3.)
^es-Q0677-answer

**es-Q0678** — Mi chino no es perfecto, pero pude entender bastante de lo que él habló.

My Chinese is not perfect, but I could understand enough of what he said.

Relative words connect a clause to a referent. Cuyo agrees with the possessed noun, not the possessor. Que also introduces complement clauses; compare functions in the whole sentence.

Why: Relative words. [[Spanish#^es-Q0678|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Mi%20chino%20no%20es%20perfecto%2C%20pero%20pude%20entender%20bastante%20de%20lo%20que%20%C3%A9l%20habl%C3%B3.)
^es-Q0678-answer

**es-Q0679** — El que lucha puede perder, el que no lucha ya perdió.

He who fights may lose, but he who doesn't has already lost.

Expected form: **que**

Why: Relative words. [[Spanish#^es-Q0679|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=El%20que%20lucha%20puede%20perder%2C%20el%20que%20no%20lucha%20ya%20perdi%C3%B3.)
^es-Q0679-answer

**es-Q0680** — El que lucha puede perder, el que no lucha ya perdió.

He who fights may lose, but he who doesn't has already lost.

Expected form: **que**

Why: Relative words. [[Spanish#^es-Q0680|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=El%20que%20lucha%20puede%20perder%2C%20el%20que%20no%20lucha%20ya%20perdi%C3%B3.)
^es-Q0680-answer

**es-Q0681** — Finjamos que somos ninjas.

Let's make believe we are ninja.

Expected form: **que**

Why: Relative words. [[Spanish#^es-Q0681|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Finjamos%20que%20somos%20ninjas.)
^es-Q0681-answer

**es-Q0682** — Finjamos que somos ninjas.

Let's make believe we are ninja.

Why: Relative words. [[Spanish#^es-Q0682|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Finjamos%20que%20somos%20ninjas.)
^es-Q0682-answer

**es-Q0683** — Será mejor que pares.

You'd better leave it.

Why: Relative words. [[Spanish#^es-Q0683|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Ser%C3%A1%20mejor%20que%20pares.)
^es-Q0683-answer

**es-Q0684** — Será mejor que pares.

You'd better leave it.

Relative words connect a clause to a referent. Cuyo agrees with the possessed noun, not the possessor. Que also introduces complement clauses; compare functions in the whole sentence.

Why: Relative words. [[Spanish#^es-Q0684|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Ser%C3%A1%20mejor%20que%20pares.)
^es-Q0684-answer

**es-Q0685** — Puedes hacer lo que gustes.

You can do whatever you like.

Expected form: **que**

Why: Relative words. [[Spanish#^es-Q0685|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Puedes%20hacer%20lo%20que%20gustes.)
^es-Q0685-answer

**es-Q0686** — Puedes hacer lo que gustes.

You can do whatever you like.

Expected form: **que**

Why: Relative words. [[Spanish#^es-Q0686|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Puedes%20hacer%20lo%20que%20gustes.)
^es-Q0686-answer

**es-Q0687** — A la hora que llegue a casa estaré demasiado cansado para hacerlo.

By the time I get home I'll be too tired to do that.

Expected form: **que**

Why: Relative words. [[Spanish#^es-Q0687|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=A%20la%20hora%20que%20llegue%20a%20casa%20estar%C3%A9%20demasiado%20cansado%20para%20hacerlo.)
^es-Q0687-answer

**es-Q0688** — A la hora que llegue a casa estaré demasiado cansado para hacerlo.

By the time I get home I'll be too tired to do that.

Why: Relative words. [[Spanish#^es-Q0688|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=A%20la%20hora%20que%20llegue%20a%20casa%20estar%C3%A9%20demasiado%20cansado%20para%20hacerlo.)
^es-Q0688-answer

**es-Q0689** — Es importante que comparta su dolor.

It's important that you share your pain.

Why: Relative words. [[Spanish#^es-Q0689|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Es%20importante%20que%20comparta%20su%20dolor.)
^es-Q0689-answer

**es-Q0690** — Es importante que comparta su dolor.

It's important that you share your pain.

Relative words connect a clause to a referent. Cuyo agrees with the possessed noun, not the possessor. Que also introduces complement clauses; compare functions in the whole sentence.

Why: Relative words. [[Spanish#^es-Q0690|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Es%20importante%20que%20comparta%20su%20dolor.)
^es-Q0690-answer

**es-Q0691** — Dicen que ella es la mujer más amable del mundo.

They say she is the kindest woman on earth.

Expected form: **que**

Why: Relative words. [[Spanish#^es-Q0691|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Dicen%20que%20ella%20es%20la%20mujer%20m%C3%A1s%20amable%20del%20mundo.)
^es-Q0691-answer

**es-Q0692** — Dicen que ella es la mujer más amable del mundo.

They say she is the kindest woman on earth.

Expected form: **que**

Why: Relative words. [[Spanish#^es-Q0692|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Dicen%20que%20ella%20es%20la%20mujer%20m%C3%A1s%20amable%20del%20mundo.)
^es-Q0692-answer

**es-Q0693** — Quiero que conozcas a mis padres.

I want you to meet my parents.

Expected form: **que**

Why: Relative words. [[Spanish#^es-Q0693|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Quiero%20que%20conozcas%20a%20mis%20padres.)
^es-Q0693-answer

**es-Q0694** — Quiero que conozcas a mis padres.

I want you to meet my parents.

Why: Relative words. [[Spanish#^es-Q0694|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Quiero%20que%20conozcas%20a%20mis%20padres.)
^es-Q0694-answer

**es-Q0695** — ¿Encontraste lo que estabas buscando?

Did you find what you were looking for?

Why: Relative words. [[Spanish#^es-Q0695|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFEncontraste%20lo%20que%20estabas%20buscando%3F)
^es-Q0695-answer

**es-Q0696** — ¿Encontraste lo que estabas buscando?

Did you find what you were looking for?

Relative words connect a clause to a referent. Cuyo agrees with the possessed noun, not the possessor. Que also introduces complement clauses; compare functions in the whole sentence.

Why: Relative words. [[Spanish#^es-Q0696|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFEncontraste%20lo%20que%20estabas%20buscando%3F)
^es-Q0696-answer

**es-Q0697** — Sin importar lo que pase, Tom siempre llega a tiempo.

No matter what happens, Tom always shows up on time.

Expected form: **que**

Why: Relative words. [[Spanish#^es-Q0697|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Sin%20importar%20lo%20que%20pase%2C%20Tom%20siempre%20llega%20a%20tiempo.)
^es-Q0697-answer

**es-Q0698** — Sin importar lo que pase, Tom siempre llega a tiempo.

No matter what happens, Tom always shows up on time.

Expected form: **que**

Why: Relative words. [[Spanish#^es-Q0698|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Sin%20importar%20lo%20que%20pase%2C%20Tom%20siempre%20llega%20a%20tiempo.)
^es-Q0698-answer

**es-Q0699** — Pateó al perro que corrió hacia él.

He kicked the dog which ran at him.

Expected form: **que**

Why: Relative words. [[Spanish#^es-Q0699|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Pate%C3%B3%20al%20perro%20que%20corri%C3%B3%20hacia%20%C3%A9l.)
^es-Q0699-answer

**es-Q0700** — Pateó al perro que corrió hacia él.

He kicked the dog which ran at him.

Why: Relative words. [[Spanish#^es-Q0700|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Pate%C3%B3%20al%20perro%20que%20corri%C3%B3%20hacia%20%C3%A9l.)
^es-Q0700-answer


### Answers 701–750

**es-Q0701** — Esa clase de cosas no puede encontrarse en cualquier parte.

That kind of thing can't be found just anywhere.

Why: Negation. [[Spanish#^es-Q0701|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Esa%20clase%20de%20cosas%20no%20puede%20encontrarse%20en%20cualquier%20parte.)
^es-Q0701-answer

**es-Q0702** — Esa clase de cosas no puede encontrarse en cualquier parte.

That kind of thing can't be found just anywhere.

Spanish permits negative concord: No vi a nadie. A negative word before the verb normally makes a separate no unnecessary: Nadie vino. Concord does not cancel the negative meaning.

Why: Negation. [[Spanish#^es-Q0702|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Esa%20clase%20de%20cosas%20no%20puede%20encontrarse%20en%20cualquier%20parte.)
^es-Q0702-answer

**es-Q0703** — No nací sabiendo.

I wasn't born knowing.

Expected form: **No**

Why: Negation. [[Spanish#^es-Q0703|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20nac%C3%AD%20sabiendo.)
^es-Q0703-answer

**es-Q0704** — No nací sabiendo.

I wasn't born knowing.

Expected form: **No**

Why: Negation. [[Spanish#^es-Q0704|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20nac%C3%AD%20sabiendo.)
^es-Q0704-answer

**es-Q0705** — Si tú no vas a esquiar, yo tampoco iré.

If you don't go skiing, I won't, either.

Expected form: **no**

Why: Negation. [[Spanish#^es-Q0705|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Si%20t%C3%BA%20no%20vas%20a%20esquiar%2C%20yo%20tampoco%20ir%C3%A9.)
^es-Q0705-answer

**es-Q0706** — Si tú no vas a esquiar, yo tampoco iré.

If you don't go skiing, I won't, either.

Why: Negation. [[Spanish#^es-Q0706|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Si%20t%C3%BA%20no%20vas%20a%20esquiar%2C%20yo%20tampoco%20ir%C3%A9.)
^es-Q0706-answer

**es-Q0707** — Ella no cree en Dios.

She doesn't believe in God.

Why: Negation. [[Spanish#^es-Q0707|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Ella%20no%20cree%20en%20Dios.)
^es-Q0707-answer

**es-Q0708** — Ella no cree en Dios.

She doesn't believe in God.

Spanish permits negative concord: No vi a nadie. A negative word before the verb normally makes a separate no unnecessary: Nadie vino. Concord does not cancel the negative meaning.

Why: Negation. [[Spanish#^es-Q0708|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Ella%20no%20cree%20en%20Dios.)
^es-Q0708-answer

**es-Q0709** — No sabe nada.

He knows nothing.

Expected form: **No**

Why: Negation. [[Spanish#^es-Q0709|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20sabe%20nada.)
^es-Q0709-answer

**es-Q0710** — No sabe nada.

He knows nothing.

Expected form: **No**

Why: Negation. [[Spanish#^es-Q0710|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20sabe%20nada.)
^es-Q0710-answer

**es-Q0711** — Para mi sorpresa, él no sabía usar el diccionario.

To my surprise, he didn't know how to use the dictionary.

Expected form: **no**

Why: Negation. [[Spanish#^es-Q0711|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Para%20mi%20sorpresa%2C%20%C3%A9l%20no%20sab%C3%ADa%20usar%20el%20diccionario.)
^es-Q0711-answer

**es-Q0712** — Para mi sorpresa, él no sabía usar el diccionario.

To my surprise, he didn't know how to use the dictionary.

Why: Negation. [[Spanish#^es-Q0712|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Para%20mi%20sorpresa%2C%20%C3%A9l%20no%20sab%C3%ADa%20usar%20el%20diccionario.)
^es-Q0712-answer

**es-Q0713** — Él no puede venir con nosotros.

He can't come with us.

Why: Negation. [[Spanish#^es-Q0713|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C3%89l%20no%20puede%20venir%20con%20nosotros.)
^es-Q0713-answer

**es-Q0714** — Él no puede venir con nosotros.

He can't come with us.

Spanish permits negative concord: No vi a nadie. A negative word before the verb normally makes a separate no unnecessary: Nadie vino. Concord does not cancel the negative meaning.

Why: Negation. [[Spanish#^es-Q0714|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C3%89l%20no%20puede%20venir%20con%20nosotros.)
^es-Q0714-answer

**es-Q0715** — Lamentablemente, Apple no provee una garantía contra daños accidentales.

Unfortunately, Apple does not provide a warranty for accidental damages.

Expected form: **no**

Why: Negation. [[Spanish#^es-Q0715|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Lamentablemente%2C%20Apple%20no%20provee%20una%20garant%C3%ADa%20contra%20da%C3%B1os%20accidentales.)
^es-Q0715-answer

**es-Q0716** — Lamentablemente, Apple no provee una garantía contra daños accidentales.

Unfortunately, Apple does not provide a warranty for accidental damages.

Expected form: **no**

Why: Negation. [[Spanish#^es-Q0716|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Lamentablemente%2C%20Apple%20no%20provee%20una%20garant%C3%ADa%20contra%20da%C3%B1os%20accidentales.)
^es-Q0716-answer

**es-Q0717** — No seas tan ruidoso, por favor.

Don't be so noisy, please.

Expected form: **No**

Why: Negation. [[Spanish#^es-Q0717|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20seas%20tan%20ruidoso%2C%20por%20favor.)
^es-Q0717-answer

**es-Q0718** — No seas tan ruidoso, por favor.

Don't be so noisy, please.

Why: Negation. [[Spanish#^es-Q0718|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20seas%20tan%20ruidoso%2C%20por%20favor.)
^es-Q0718-answer

**es-Q0719** — No suelo merendar nunca.

I don't ever tend to have an afternoon meal.

Why: Negation. [[Spanish#^es-Q0719|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20suelo%20merendar%20nunca.)
^es-Q0719-answer

**es-Q0720** — No suelo merendar nunca.

I don't ever tend to have an afternoon meal.

Spanish permits negative concord: No vi a nadie. A negative word before the verb normally makes a separate no unnecessary: Nadie vino. Concord does not cancel the negative meaning.

Why: Negation. [[Spanish#^es-Q0720|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20suelo%20merendar%20nunca.)
^es-Q0720-answer

**es-Q0721** — Tom no habla francés con tanta fluidez como Mary.

Tom doesn't speak French as fluently as Mary does.

Expected form: **no**

Why: Negation. [[Spanish#^es-Q0721|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tom%20no%20habla%20franc%C3%A9s%20con%20tanta%20fluidez%20como%20Mary.)
^es-Q0721-answer

**es-Q0722** — Tom no habla francés con tanta fluidez como Mary.

Tom doesn't speak French as fluently as Mary does.

Expected form: **no**

Why: Negation. [[Spanish#^es-Q0722|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tom%20no%20habla%20franc%C3%A9s%20con%20tanta%20fluidez%20como%20Mary.)
^es-Q0722-answer

**es-Q0723** — No quiero ver a Tom.

I don't want to see Tom.

Expected form: **No**

Why: Negation. [[Spanish#^es-Q0723|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20quiero%20ver%20a%20Tom.)
^es-Q0723-answer

**es-Q0724** — No quiero ver a Tom.

I don't want to see Tom.

Why: Negation. [[Spanish#^es-Q0724|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20quiero%20ver%20a%20Tom.)
^es-Q0724-answer

**es-Q0725** — Él nunca cedió a la tentación.

He never gave in to temptation.

Why: Negation. [[Spanish#^es-Q0725|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C3%89l%20nunca%20cedi%C3%B3%20a%20la%20tentaci%C3%B3n.)
^es-Q0725-answer

**es-Q0726** — Él nunca cedió a la tentación.

He never gave in to temptation.

Spanish permits negative concord: No vi a nadie. A negative word before the verb normally makes a separate no unnecessary: Nadie vino. Concord does not cancel the negative meaning.

Why: Negation. [[Spanish#^es-Q0726|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C3%89l%20nunca%20cedi%C3%B3%20a%20la%20tentaci%C3%B3n.)
^es-Q0726-answer

**es-Q0727** — Si estuviera en su lugar no dejaría la escuela.

I wouldn't drop out of school if I were you.

Expected form: **no**

Why: Negation. [[Spanish#^es-Q0727|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Si%20estuviera%20en%20su%20lugar%20no%20dejar%C3%ADa%20la%20escuela.)
^es-Q0727-answer

**es-Q0728** — Si estuviera en su lugar no dejaría la escuela.

I wouldn't drop out of school if I were you.

Expected form: **no**

Why: Negation. [[Spanish#^es-Q0728|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Si%20estuviera%20en%20su%20lugar%20no%20dejar%C3%ADa%20la%20escuela.)
^es-Q0728-answer

**es-Q0729** — Ya no trabajo.

I don't work anymore.

Expected form: **no**

Why: Negation. [[Spanish#^es-Q0729|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Ya%20no%20trabajo.)
^es-Q0729-answer

**es-Q0730** — Ya no trabajo.

I don't work anymore.

Why: Negation. [[Spanish#^es-Q0730|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Ya%20no%20trabajo.)
^es-Q0730-answer

**es-Q0731** — No he oído de él desde junio pasado.

I haven't heard from him since last June.

Why: Negation. [[Spanish#^es-Q0731|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20he%20o%C3%ADdo%20de%20%C3%A9l%20desde%20junio%20pasado.)
^es-Q0731-answer

**es-Q0732** — No he oído de él desde junio pasado.

I haven't heard from him since last June.

Spanish permits negative concord: No vi a nadie. A negative word before the verb normally makes a separate no unnecessary: Nadie vino. Concord does not cancel the negative meaning.

Why: Negation. [[Spanish#^es-Q0732|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20he%20o%C3%ADdo%20de%20%C3%A9l%20desde%20junio%20pasado.)
^es-Q0732-answer

**es-Q0733** — Tú no eres perdedor.

You're not a loser.

Expected form: **no**

Why: Negation. [[Spanish#^es-Q0733|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=T%C3%BA%20no%20eres%20perdedor.)
^es-Q0733-answer

**es-Q0734** — Tú no eres perdedor.

You're not a loser.

Expected form: **no**

Why: Negation. [[Spanish#^es-Q0734|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=T%C3%BA%20no%20eres%20perdedor.)
^es-Q0734-answer

**es-Q0735** — No es tu turno.

It's not your turn.

Expected form: **No**

Why: Negation. [[Spanish#^es-Q0735|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20es%20tu%20turno.)
^es-Q0735-answer

**es-Q0736** — No es tu turno.

It's not your turn.

Why: Negation. [[Spanish#^es-Q0736|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20es%20tu%20turno.)
^es-Q0736-answer

**es-Q0737** — Si el sol saliera por el oeste, no cambiaría de idea.

If the sun were to rise in the west, I wouldn't change my mind.

Why: Negation. [[Spanish#^es-Q0737|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Si%20el%20sol%20saliera%20por%20el%20oeste%2C%20no%20cambiar%C3%ADa%20de%20idea.)
^es-Q0737-answer

**es-Q0738** — Si el sol saliera por el oeste, no cambiaría de idea.

If the sun were to rise in the west, I wouldn't change my mind.

Spanish permits negative concord: No vi a nadie. A negative word before the verb normally makes a separate no unnecessary: Nadie vino. Concord does not cancel the negative meaning.

Why: Negation. [[Spanish#^es-Q0738|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Si%20el%20sol%20saliera%20por%20el%20oeste%2C%20no%20cambiar%C3%ADa%20de%20idea.)
^es-Q0738-answer

**es-Q0739** — Tú me desprecias, ¿o no?

You despise me, don't you?

Expected form: **no**

Why: Negation. [[Spanish#^es-Q0739|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=T%C3%BA%20me%20desprecias%2C%20%C2%BFo%20no%3F)
^es-Q0739-answer

**es-Q0740** — Tú me desprecias, ¿o no?

You despise me, don't you?

Expected form: **no**

Why: Negation. [[Spanish#^es-Q0740|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=T%C3%BA%20me%20desprecias%2C%20%C2%BFo%20no%3F)
^es-Q0740-answer

**es-Q0741** — No tires las mascarillas al suelo.

Don’t throw masks to the ground.

Expected form: **No**

Why: Negation. [[Spanish#^es-Q0741|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20tires%20las%20mascarillas%20al%20suelo.)
^es-Q0741-answer

**es-Q0742** — No tires las mascarillas al suelo.

Don’t throw masks to the ground.

Why: Negation. [[Spanish#^es-Q0742|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20tires%20las%20mascarillas%20al%20suelo.)
^es-Q0742-answer

**es-Q0743** — No nos desanimemos ahora.

Now, let's not get discouraged.

Why: Negation. [[Spanish#^es-Q0743|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20nos%20desanimemos%20ahora.)
^es-Q0743-answer

**es-Q0744** — No nos desanimemos ahora.

Now, let's not get discouraged.

Spanish permits negative concord: No vi a nadie. A negative word before the verb normally makes a separate no unnecessary: Nadie vino. Concord does not cancel the negative meaning.

Why: Negation. [[Spanish#^es-Q0744|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20nos%20desanimemos%20ahora.)
^es-Q0744-answer

**es-Q0745** — María no puede ver ni oír.

Mary cannot see or hear.

Expected form: **no**

Why: Negation. [[Spanish#^es-Q0745|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Mar%C3%ADa%20no%20puede%20ver%20ni%20o%C3%ADr.)
^es-Q0745-answer

**es-Q0746** — María no puede ver ni oír.

Mary cannot see or hear.

Expected form: **no**

Why: Negation. [[Spanish#^es-Q0746|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Mar%C3%ADa%20no%20puede%20ver%20ni%20o%C3%ADr.)
^es-Q0746-answer

**es-Q0747** — Michael ya no vive aquí.

Michael doesn't live here anymore.

Expected form: **no**

Why: Negation. [[Spanish#^es-Q0747|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Michael%20ya%20no%20vive%20aqu%C3%AD.)
^es-Q0747-answer

**es-Q0748** — Michael ya no vive aquí.

Michael doesn't live here anymore.

Why: Negation. [[Spanish#^es-Q0748|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Michael%20ya%20no%20vive%20aqu%C3%AD.)
^es-Q0748-answer

**es-Q0749** — No puedo explicarme lo ocurrido.

I can't understand what happened.

Why: Negation. [[Spanish#^es-Q0749|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20puedo%20explicarme%20lo%20ocurrido.)
^es-Q0749-answer

**es-Q0750** — No puedo explicarme lo ocurrido.

I can't understand what happened.

Spanish permits negative concord: No vi a nadie. A negative word before the verb normally makes a separate no unnecessary: Nadie vino. Concord does not cancel the negative meaning.

Why: Negation. [[Spanish#^es-Q0750|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20puedo%20explicarme%20lo%20ocurrido.)
^es-Q0750-answer


### Answers 751–800

**es-Q0751** — ¿Por qué estabas enfadado conmigo?

Why were you angry with me?

Expected form: **Por qué**

Why: Question words. [[Spanish#^es-Q0751|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFPor%20qu%C3%A9%20estabas%20enfadado%20conmigo%3F)
^es-Q0751-answer

**es-Q0752** — ¿Por qué estabas enfadado conmigo?

Why were you angry with me?

Expected form: **Por qué**

Why: Question words. [[Spanish#^es-Q0752|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFPor%20qu%C3%A9%20estabas%20enfadado%20conmigo%3F)
^es-Q0752-answer

**es-Q0753** — ¿Qué quieres decir con relativismo cultural?

What do you mean by cultural relativism?

Expected form: **Qué**

Why: Question words. [[Spanish#^es-Q0753|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFQu%C3%A9%20quieres%20decir%20con%20relativismo%20cultural%3F)
^es-Q0753-answer

**es-Q0754** — ¿Qué quieres decir con relativismo cultural?

What do you mean by cultural relativism?

Why: Question words. [[Spanish#^es-Q0754|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFQu%C3%A9%20quieres%20decir%20con%20relativismo%20cultural%3F)
^es-Q0754-answer

**es-Q0755** — ¿Qué saben ustedes?

What do you know?

Why: Question words. [[Spanish#^es-Q0755|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFQu%C3%A9%20saben%20ustedes%3F)
^es-Q0755-answer

**es-Q0756** — ¿Qué saben ustedes?

What do you know?

Question and exclamation words take written accents, including many indirect questions. Compare donde as a relative with dónde in a question. Use the opening question mark in standard writing.

Why: Question words. [[Spanish#^es-Q0756|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFQu%C3%A9%20saben%20ustedes%3F)
^es-Q0756-answer

**es-Q0757** — ¿Cuánto has pagado por este ordenador?

How much have you paid for this computer?

Expected form: **Cuánto**

Why: Question words. [[Spanish#^es-Q0757|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFCu%C3%A1nto%20has%20pagado%20por%20este%20ordenador%3F)
^es-Q0757-answer

**es-Q0758** — ¿Cuánto has pagado por este ordenador?

How much have you paid for this computer?

Expected form: **Cuánto**

Why: Question words. [[Spanish#^es-Q0758|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFCu%C3%A1nto%20has%20pagado%20por%20este%20ordenador%3F)
^es-Q0758-answer

**es-Q0759** — ¿A quién le habla Tom?

Who's Tom talking to?

Expected form: **quién**

Why: Question words. [[Spanish#^es-Q0759|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFA%20qui%C3%A9n%20le%20habla%20Tom%3F)
^es-Q0759-answer

**es-Q0760** — ¿A quién le habla Tom?

Who's Tom talking to?

Why: Question words. [[Spanish#^es-Q0760|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFA%20qui%C3%A9n%20le%20habla%20Tom%3F)
^es-Q0760-answer

**es-Q0761** — ¿Quién más usa Tatoeba en tu oficina?

Who else uses Tatoeba in your office?

Why: Question words. [[Spanish#^es-Q0761|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFQui%C3%A9n%20m%C3%A1s%20usa%20Tatoeba%20en%20tu%20oficina%3F)
^es-Q0761-answer

**es-Q0762** — ¿Quién más usa Tatoeba en tu oficina?

Who else uses Tatoeba in your office?

Question and exclamation words take written accents, including many indirect questions. Compare donde as a relative with dónde in a question. Use the opening question mark in standard writing.

Why: Question words. [[Spanish#^es-Q0762|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFQui%C3%A9n%20m%C3%A1s%20usa%20Tatoeba%20en%20tu%20oficina%3F)
^es-Q0762-answer

**es-Q0763** — Eres la única persona en quién puedo confiar.

You're the only person that I can trust.

Expected form: **quién**

Why: Question words. [[Spanish#^es-Q0763|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Eres%20la%20%C3%BAnica%20persona%20en%20qui%C3%A9n%20puedo%20confiar.)
^es-Q0763-answer

**es-Q0764** — Eres la única persona en quién puedo confiar.

You're the only person that I can trust.

Expected form: **quién**

Why: Question words. [[Spanish#^es-Q0764|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Eres%20la%20%C3%BAnica%20persona%20en%20qui%C3%A9n%20puedo%20confiar.)
^es-Q0764-answer

**es-Q0765** — ¿Quién es tu compositor favorito?

Who is your favorite composer?

Expected form: **Quién**

Why: Question words. [[Spanish#^es-Q0765|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFQui%C3%A9n%20es%20tu%20compositor%20favorito%3F)
^es-Q0765-answer

**es-Q0766** — ¿Quién es tu compositor favorito?

Who is your favorite composer?

Why: Question words. [[Spanish#^es-Q0766|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFQui%C3%A9n%20es%20tu%20compositor%20favorito%3F)
^es-Q0766-answer

**es-Q0767** — ¿Por qué no cierras la ventana?

Why don't you shut the window?

Why: Question words. [[Spanish#^es-Q0767|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFPor%20qu%C3%A9%20no%20cierras%20la%20ventana%3F)
^es-Q0767-answer

**es-Q0768** — ¿Por qué no cierras la ventana?

Why don't you shut the window?

Question and exclamation words take written accents, including many indirect questions. Compare donde as a relative with dónde in a question. Use the opening question mark in standard writing.

Why: Question words. [[Spanish#^es-Q0768|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFPor%20qu%C3%A9%20no%20cierras%20la%20ventana%3F)
^es-Q0768-answer

**es-Q0769** — ¿Qué flor es esa?

What's that flower?

Expected form: **Qué**

Why: Question words. [[Spanish#^es-Q0769|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFQu%C3%A9%20flor%20es%20esa%3F)
^es-Q0769-answer

**es-Q0770** — ¿Qué flor es esa?

What's that flower?

Expected form: **Qué**

Why: Question words. [[Spanish#^es-Q0770|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFQu%C3%A9%20flor%20es%20esa%3F)
^es-Q0770-answer

**es-Q0771** — ¿Por qué no vamos a mi casa en vez de volver a la fiesta?

Instead of going back to the party, why don't we go to my place?

Expected form: **Por qué**

Why: Question words. [[Spanish#^es-Q0771|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFPor%20qu%C3%A9%20no%20vamos%20a%20mi%20casa%20en%20vez%20de%20volver%20a%20la%20fiesta%3F)
^es-Q0771-answer

**es-Q0772** — ¿Por qué no vamos a mi casa en vez de volver a la fiesta?

Instead of going back to the party, why don't we go to my place?

Why: Question words. [[Spanish#^es-Q0772|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFPor%20qu%C3%A9%20no%20vamos%20a%20mi%20casa%20en%20vez%20de%20volver%20a%20la%20fiesta%3F)
^es-Q0772-answer

**es-Q0773** — ¿Vos sabés cómo operar esta máquina?

Do you know how to operate this machine?

Why: Question words. [[Spanish#^es-Q0773|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFVos%20sab%C3%A9s%20c%C3%B3mo%20operar%20esta%20m%C3%A1quina%3F)
^es-Q0773-answer

**es-Q0774** — ¿Vos sabés cómo operar esta máquina?

Do you know how to operate this machine?

Question and exclamation words take written accents, including many indirect questions. Compare donde as a relative with dónde in a question. Use the opening question mark in standard writing.

Why: Question words. [[Spanish#^es-Q0774|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFVos%20sab%C3%A9s%20c%C3%B3mo%20operar%20esta%20m%C3%A1quina%3F)
^es-Q0774-answer

**es-Q0775** — Tom no entiende cómo usar un ordenador.

Tom doesn't understand how to use a computer.

Expected form: **cómo**

Why: Question words. [[Spanish#^es-Q0775|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tom%20no%20entiende%20c%C3%B3mo%20usar%20un%20ordenador.)
^es-Q0775-answer

**es-Q0776** — Tom no entiende cómo usar un ordenador.

Tom doesn't understand how to use a computer.

Expected form: **cómo**

Why: Question words. [[Spanish#^es-Q0776|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tom%20no%20entiende%20c%C3%B3mo%20usar%20un%20ordenador.)
^es-Q0776-answer

**es-Q0777** — ¿Y tú qué tal?

And you, how are you?

Expected form: **qué**

Why: Question words. [[Spanish#^es-Q0777|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFY%20t%C3%BA%20qu%C3%A9%20tal%3F)
^es-Q0777-answer

**es-Q0778** — ¿Y tú qué tal?

And you, how are you?

Why: Question words. [[Spanish#^es-Q0778|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFY%20t%C3%BA%20qu%C3%A9%20tal%3F)
^es-Q0778-answer

**es-Q0779** — ¿Qué tiempo hace esta mañana?

What's the weather like this morning?

Why: Question words. [[Spanish#^es-Q0779|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFQu%C3%A9%20tiempo%20hace%20esta%20ma%C3%B1ana%3F)
^es-Q0779-answer

**es-Q0780** — ¿Qué tiempo hace esta mañana?

What's the weather like this morning?

Question and exclamation words take written accents, including many indirect questions. Compare donde as a relative with dónde in a question. Use the opening question mark in standard writing.

Why: Question words. [[Spanish#^es-Q0780|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFQu%C3%A9%20tiempo%20hace%20esta%20ma%C3%B1ana%3F)
^es-Q0780-answer

**es-Q0781** — ¿Qué le impidió venir más temprano?

What prevented you from coming earlier?

Expected form: **Qué**

Why: Question words. [[Spanish#^es-Q0781|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFQu%C3%A9%20le%20impidi%C3%B3%20venir%20m%C3%A1s%20temprano%3F)
^es-Q0781-answer

**es-Q0782** — ¿Qué le impidió venir más temprano?

What prevented you from coming earlier?

Expected form: **Qué**

Why: Question words. [[Spanish#^es-Q0782|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFQu%C3%A9%20le%20impidi%C3%B3%20venir%20m%C3%A1s%20temprano%3F)
^es-Q0782-answer

**es-Q0783** — ¡Qué conjunto tan feo!

What an ugly outfit!

Expected form: **Qué**

Why: Question words. [[Spanish#^es-Q0783|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%A1Qu%C3%A9%20conjunto%20tan%20feo%21)
^es-Q0783-answer

**es-Q0784** — ¡Qué conjunto tan feo!

What an ugly outfit!

Why: Question words. [[Spanish#^es-Q0784|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%A1Qu%C3%A9%20conjunto%20tan%20feo%21)
^es-Q0784-answer

**es-Q0785** — Mamá, ¿dónde está mi pañuelo?

Mom, where's my handkerchief?

Why: Question words. [[Spanish#^es-Q0785|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Mam%C3%A1%2C%20%C2%BFd%C3%B3nde%20est%C3%A1%20mi%20pa%C3%B1uelo%3F)
^es-Q0785-answer

**es-Q0786** — Mamá, ¿dónde está mi pañuelo?

Mom, where's my handkerchief?

Question and exclamation words take written accents, including many indirect questions. Compare donde as a relative with dónde in a question. Use the opening question mark in standard writing.

Why: Question words. [[Spanish#^es-Q0786|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Mam%C3%A1%2C%20%C2%BFd%C3%B3nde%20est%C3%A1%20mi%20pa%C3%B1uelo%3F)
^es-Q0786-answer

**es-Q0787** — ¿A dónde quieres ir este verano?

Where do you want to go this summer?

Expected form: **dónde**

Why: Question words. [[Spanish#^es-Q0787|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFA%20d%C3%B3nde%20quieres%20ir%20este%20verano%3F)
^es-Q0787-answer

**es-Q0788** — ¿A dónde quieres ir este verano?

Where do you want to go this summer?

Expected form: **dónde**

Why: Question words. [[Spanish#^es-Q0788|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFA%20d%C3%B3nde%20quieres%20ir%20este%20verano%3F)
^es-Q0788-answer

**es-Q0789** — Sé exactamente con quién planea casarse Tom.

I know exactly who Tom plans to marry.

Expected form: **quién**

Why: Question words. [[Spanish#^es-Q0789|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=S%C3%A9%20exactamente%20con%20qui%C3%A9n%20planea%20casarse%20Tom.)
^es-Q0789-answer

**es-Q0790** — Sé exactamente con quién planea casarse Tom.

I know exactly who Tom plans to marry.

Why: Question words. [[Spanish#^es-Q0790|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=S%C3%A9%20exactamente%20con%20qui%C3%A9n%20planea%20casarse%20Tom.)
^es-Q0790-answer

**es-Q0791** — ¿En qué grupo está su amigo?

Which group is your friend in?

Why: Question words. [[Spanish#^es-Q0791|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFEn%20qu%C3%A9%20grupo%20est%C3%A1%20su%20amigo%3F)
^es-Q0791-answer

**es-Q0792** — ¿En qué grupo está su amigo?

Which group is your friend in?

Question and exclamation words take written accents, including many indirect questions. Compare donde as a relative with dónde in a question. Use the opening question mark in standard writing.

Why: Question words. [[Spanish#^es-Q0792|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFEn%20qu%C3%A9%20grupo%20est%C3%A1%20su%20amigo%3F)
^es-Q0792-answer

**es-Q0793** — ¿Por qué no nos vamos a cenar?

Why don't we have dinner?

Expected form: **Por qué**

Why: Question words. [[Spanish#^es-Q0793|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFPor%20qu%C3%A9%20no%20nos%20vamos%20a%20cenar%3F)
^es-Q0793-answer

**es-Q0794** — ¿Por qué no nos vamos a cenar?

Why don't we have dinner?

Expected form: **Por qué**

Why: Question words. [[Spanish#^es-Q0794|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFPor%20qu%C3%A9%20no%20nos%20vamos%20a%20cenar%3F)
^es-Q0794-answer

**es-Q0795** — Él explicó cómo hacer un fuego.

He explained how to make a fire.

Expected form: **cómo**

Why: Question words. [[Spanish#^es-Q0795|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C3%89l%20explic%C3%B3%20c%C3%B3mo%20hacer%20un%20fuego.)
^es-Q0795-answer

**es-Q0796** — Él explicó cómo hacer un fuego.

He explained how to make a fire.

Why: Question words. [[Spanish#^es-Q0796|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C3%89l%20explic%C3%B3%20c%C3%B3mo%20hacer%20un%20fuego.)
^es-Q0796-answer

**es-Q0797** — ¿Qué té tomas? ¿Té de limón está bien?

What tea do you drink? Is lemon tea okay?

Why: Question words. [[Spanish#^es-Q0797|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFQu%C3%A9%20t%C3%A9%20tomas%3F%20%C2%BFT%C3%A9%20de%20lim%C3%B3n%20est%C3%A1%20bien%3F)
^es-Q0797-answer

**es-Q0798** — ¿Qué té tomas? ¿Té de limón está bien?

What tea do you drink? Is lemon tea okay?

Question and exclamation words take written accents, including many indirect questions. Compare donde as a relative with dónde in a question. Use the opening question mark in standard writing.

Why: Question words. [[Spanish#^es-Q0798|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFQu%C3%A9%20t%C3%A9%20tomas%3F%20%C2%BFT%C3%A9%20de%20lim%C3%B3n%20est%C3%A1%20bien%3F)
^es-Q0798-answer

**es-Q0799** — ¿Sabe Tom qué hacer con esto?

Does Tom know what to do with this?

Expected form: **qué**

Why: Question words. [[Spanish#^es-Q0799|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFSabe%20Tom%20qu%C3%A9%20hacer%20con%20esto%3F)
^es-Q0799-answer

**es-Q0800** — ¿Sabe Tom qué hacer con esto?

Does Tom know what to do with this?

Expected form: **qué**

Why: Question words. [[Spanish#^es-Q0800|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFSabe%20Tom%20qu%C3%A9%20hacer%20con%20esto%3F)
^es-Q0800-answer


### Answers 801–850

**es-Q0801** — Si yo hubiera sabido su dirección, le habría mandado una carta.

If I had known her address, I would have written to her.

Expected form: **Si**

Why: Conditions with si. [[Spanish#^es-Q0801|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Si%20yo%20hubiera%20sabido%20su%20direcci%C3%B3n%2C%20le%20habr%C3%ADa%20mandado%20una%20carta.)
^es-Q0801-answer

**es-Q0802** — Si yo hubiera sabido su dirección, le habría mandado una carta.

If I had known her address, I would have written to her.

Why: Conditions with si. [[Spanish#^es-Q0802|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Si%20yo%20hubiera%20sabido%20su%20direcci%C3%B3n%2C%20le%20habr%C3%ADa%20mandado%20una%20carta.)
^es-Q0802-answer

**es-Q0803** — Léela tú misma, si quieres.

Read it yourself, if you like.

Why: Conditions with si. [[Spanish#^es-Q0803|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=L%C3%A9ela%20t%C3%BA%20misma%2C%20si%20quieres.)
^es-Q0803-answer

**es-Q0804** — Léela tú misma, si quieres.

Read it yourself, if you like.

Si has no accent when it means if or whether; sí means yes or emphatic affirmation. A real condition often uses present; an unreal one often uses imperfect subjunctive.

Why: Conditions with si. [[Spanish#^es-Q0804|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=L%C3%A9ela%20t%C3%BA%20misma%2C%20si%20quieres.)
^es-Q0804-answer

**es-Q0805** — Si te agachas un poco, verás la bandera de señalización apareciendo y ocultándose de la vista.

If you just crouch a little, the signal flag can just be seen flicking in and out of sight.

Expected form: **Si**

Why: Conditions with si. [[Spanish#^es-Q0805|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Si%20te%20agachas%20un%20poco%2C%20ver%C3%A1s%20la%20bandera%20de%20se%C3%B1alizaci%C3%B3n%20apareciendo%20y%20ocult%C3%A1ndose%20de%20la%20vista.)
^es-Q0805-answer

**es-Q0806** — Si te agachas un poco, verás la bandera de señalización apareciendo y ocultándose de la vista.

If you just crouch a little, the signal flag can just be seen flicking in and out of sight.

Expected form: **Si**

Why: Conditions with si. [[Spanish#^es-Q0806|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Si%20te%20agachas%20un%20poco%2C%20ver%C3%A1s%20la%20bandera%20de%20se%C3%B1alizaci%C3%B3n%20apareciendo%20y%20ocult%C3%A1ndose%20de%20la%20vista.)
^es-Q0806-answer

**es-Q0807** — Me sentía gracioso, como si todavía siguiera soñando.

I felt as happy as if I were still dreaming.

Expected form: **si**

Why: Conditions with si. [[Spanish#^es-Q0807|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Me%20sent%C3%ADa%20gracioso%2C%20como%20si%20todav%C3%ADa%20siguiera%20so%C3%B1ando.)
^es-Q0807-answer

**es-Q0808** — Me sentía gracioso, como si todavía siguiera soñando.

I felt as happy as if I were still dreaming.

Why: Conditions with si. [[Spanish#^es-Q0808|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Me%20sent%C3%ADa%20gracioso%2C%20como%20si%20todav%C3%ADa%20siguiera%20so%C3%B1ando.)
^es-Q0808-answer

**es-Q0809** — Siento como si estuviera convirtiéndome en alguien más.

I feel like I've become someone else.

Why: Conditions with si. [[Spanish#^es-Q0809|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Siento%20como%20si%20estuviera%20convirti%C3%A9ndome%20en%20alguien%20m%C3%A1s.)
^es-Q0809-answer

**es-Q0810** — Siento como si estuviera convirtiéndome en alguien más.

I feel like I've become someone else.

Si has no accent when it means if or whether; sí means yes or emphatic affirmation. A real condition often uses present; an unreal one often uses imperfect subjunctive.

Why: Conditions with si. [[Spanish#^es-Q0810|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Siento%20como%20si%20estuviera%20convirti%C3%A9ndome%20en%20alguien%20m%C3%A1s.)
^es-Q0810-answer

**es-Q0811** — Si yo fuera un ave, volaría hacia ti.

Were I a bird, I would fly to you.

Expected form: **Si**

Why: Conditions with si. [[Spanish#^es-Q0811|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Si%20yo%20fuera%20un%20ave%2C%20volar%C3%ADa%20hacia%20ti.)
^es-Q0811-answer

**es-Q0812** — Si yo fuera un ave, volaría hacia ti.

Were I a bird, I would fly to you.

Expected form: **Si**

Why: Conditions with si. [[Spanish#^es-Q0812|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Si%20yo%20fuera%20un%20ave%2C%20volar%C3%ADa%20hacia%20ti.)
^es-Q0812-answer

**es-Q0813** — Tom actúa como si estuviera agotado.

Tom acts like he's exhausted.

Expected form: **si**

Why: Conditions with si. [[Spanish#^es-Q0813|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tom%20act%C3%BAa%20como%20si%20estuviera%20agotado.)
^es-Q0813-answer

**es-Q0814** — Tom actúa como si estuviera agotado.

Tom acts like he's exhausted.

Why: Conditions with si. [[Spanish#^es-Q0814|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tom%20act%C3%BAa%20como%20si%20estuviera%20agotado.)
^es-Q0814-answer

**es-Q0815** — Si hubiera sido rico, os habría dado dinero.

If I had been rich, I would have given you some money.

Why: Conditions with si. [[Spanish#^es-Q0815|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Si%20hubiera%20sido%20rico%2C%20os%20habr%C3%ADa%20dado%20dinero.)
^es-Q0815-answer

**es-Q0816** — Si hubiera sido rico, os habría dado dinero.

If I had been rich, I would have given you some money.

Si has no accent when it means if or whether; sí means yes or emphatic affirmation. A real condition often uses present; an unreal one often uses imperfect subjunctive.

Why: Conditions with si. [[Spanish#^es-Q0816|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Si%20hubiera%20sido%20rico%2C%20os%20habr%C3%ADa%20dado%20dinero.)
^es-Q0816-answer

**es-Q0817** — Siento como si alguien nos estuviera observando.

I feel like someone is watching us.

Expected form: **si**

Why: Conditions with si. [[Spanish#^es-Q0817|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Siento%20como%20si%20alguien%20nos%20estuviera%20observando.)
^es-Q0817-answer

**es-Q0818** — Siento como si alguien nos estuviera observando.

I feel like someone is watching us.

Expected form: **si**

Why: Conditions with si. [[Spanish#^es-Q0818|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Siento%20como%20si%20alguien%20nos%20estuviera%20observando.)
^es-Q0818-answer

**es-Q0819** — Los dioses ayudan a los que se ayudan a si mismos.

The gods help them that help themselves.

Expected form: **si**

Why: Conditions with si. [[Spanish#^es-Q0819|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Los%20dioses%20ayudan%20a%20los%20que%20se%20ayudan%20a%20si%20mismos.)
^es-Q0819-answer

**es-Q0820** — Los dioses ayudan a los que se ayudan a si mismos.

The gods help them that help themselves.

Why: Conditions with si. [[Spanish#^es-Q0820|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Los%20dioses%20ayudan%20a%20los%20que%20se%20ayudan%20a%20si%20mismos.)
^es-Q0820-answer

**es-Q0821** — Si te comes eso, morirás.

If you eat that you will die.

Why: Conditions with si. [[Spanish#^es-Q0821|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Si%20te%20comes%20eso%2C%20morir%C3%A1s.)
^es-Q0821-answer

**es-Q0822** — Si te comes eso, morirás.

If you eat that you will die.

Si has no accent when it means if or whether; sí means yes or emphatic affirmation. A real condition often uses present; an unreal one often uses imperfect subjunctive.

Why: Conditions with si. [[Spanish#^es-Q0822|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Si%20te%20comes%20eso%2C%20morir%C3%A1s.)
^es-Q0822-answer

**es-Q0823** — Si quieres evitar el colesterol, come carnes magras sin grasa.

If you want to avoid cholesterol, eat lean meat with no fat.

Expected form: **Si**

Why: Conditions with si. [[Spanish#^es-Q0823|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Si%20quieres%20evitar%20el%20colesterol%2C%20come%20carnes%20magras%20sin%20grasa.)
^es-Q0823-answer

**es-Q0824** — Si quieres evitar el colesterol, come carnes magras sin grasa.

If you want to avoid cholesterol, eat lean meat with no fat.

Expected form: **Si**

Why: Conditions with si. [[Spanish#^es-Q0824|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Si%20quieres%20evitar%20el%20colesterol%2C%20come%20carnes%20magras%20sin%20grasa.)
^es-Q0824-answer

**es-Q0825** — Él me trata como si fuera un extraño.

He treats me as if I am a stranger.

Expected form: **si**

Why: Conditions with si. [[Spanish#^es-Q0825|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C3%89l%20me%20trata%20como%20si%20fuera%20un%20extra%C3%B1o.)
^es-Q0825-answer

**es-Q0826** — Él me trata como si fuera un extraño.

He treats me as if I am a stranger.

Why: Conditions with si. [[Spanish#^es-Q0826|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C3%89l%20me%20trata%20como%20si%20fuera%20un%20extra%C3%B1o.)
^es-Q0826-answer

**es-Q0827** — Si calientas hielo, se derrite.

If you heat ice, it melts.

Why: Conditions with si. [[Spanish#^es-Q0827|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Si%20calientas%20hielo%2C%20se%20derrite.)
^es-Q0827-answer

**es-Q0828** — Si calientas hielo, se derrite.

If you heat ice, it melts.

Si has no accent when it means if or whether; sí means yes or emphatic affirmation. A real condition often uses present; an unreal one often uses imperfect subjunctive.

Why: Conditions with si. [[Spanish#^es-Q0828|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Si%20calientas%20hielo%2C%20se%20derrite.)
^es-Q0828-answer

**es-Q0829** — Estás jugando con fuego si seguís andando en moto sin casco.

You're playing with fire if you insist on riding your motorcycle without a helmet on.

Expected form: **si**

Why: Conditions with si. [[Spanish#^es-Q0829|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Est%C3%A1s%20jugando%20con%20fuego%20si%20segu%C3%ADs%20andando%20en%20moto%20sin%20casco.)
^es-Q0829-answer

**es-Q0830** — Estás jugando con fuego si seguís andando en moto sin casco.

You're playing with fire if you insist on riding your motorcycle without a helmet on.

Expected form: **si**

Why: Conditions with si. [[Spanish#^es-Q0830|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Est%C3%A1s%20jugando%20con%20fuego%20si%20segu%C3%ADs%20andando%20en%20moto%20sin%20casco.)
^es-Q0830-answer

**es-Q0831** — Me pregunto si verdaderamente se trataba de una coincidencia.

I wonder if it really was a coincidence.

Expected form: **si**

Why: Conditions with si. [[Spanish#^es-Q0831|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Me%20pregunto%20si%20verdaderamente%20se%20trataba%20de%20una%20coincidencia.)
^es-Q0831-answer

**es-Q0832** — Me pregunto si verdaderamente se trataba de una coincidencia.

I wonder if it really was a coincidence.

Why: Conditions with si. [[Spanish#^es-Q0832|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Me%20pregunto%20si%20verdaderamente%20se%20trataba%20de%20una%20coincidencia.)
^es-Q0832-answer

**es-Q0833** — No te acerques al bulldog por si muerde.

Don't come near to the bulldog in case it bites.

Why: Conditions with si. [[Spanish#^es-Q0833|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20te%20acerques%20al%20bulldog%20por%20si%20muerde.)
^es-Q0833-answer

**es-Q0834** — No te acerques al bulldog por si muerde.

Don't come near to the bulldog in case it bites.

Si has no accent when it means if or whether; sí means yes or emphatic affirmation. A real condition often uses present; an unreal one often uses imperfect subjunctive.

Why: Conditions with si. [[Spanish#^es-Q0834|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20te%20acerques%20al%20bulldog%20por%20si%20muerde.)
^es-Q0834-answer

**es-Q0835** — Avíseme si le puedo dar alguna información adicional, o si desea contactarme para hacer alguna pregunta.

Please let me know if I can provide you with any further information, or if you would like to contact me for questions.

Expected form: **si**

Why: Conditions with si. [[Spanish#^es-Q0835|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Av%C3%ADseme%20si%20le%20puedo%20dar%20alguna%20informaci%C3%B3n%20adicional%2C%20o%20si%20desea%20contactarme%20para%20hacer%20alguna%20pregunta.)
^es-Q0835-answer

**es-Q0836** — Avíseme si le puedo dar alguna información adicional, o si desea contactarme para hacer alguna pregunta.

Please let me know if I can provide you with any further information, or if you would like to contact me for questions.

Expected form: **si**

Why: Conditions with si. [[Spanish#^es-Q0836|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Av%C3%ADseme%20si%20le%20puedo%20dar%20alguna%20informaci%C3%B3n%20adicional%2C%20o%20si%20desea%20contactarme%20para%20hacer%20alguna%20pregunta.)
^es-Q0836-answer

**es-Q0837** — Me preguntó si tenía experiencia en esa área, y le dije que no.

He asked me if I had experience in this area, and I said no.

Expected form: **si**

Why: Conditions with si. [[Spanish#^es-Q0837|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Me%20pregunt%C3%B3%20si%20ten%C3%ADa%20experiencia%20en%20esa%20%C3%A1rea%2C%20y%20le%20dije%20que%20no.)
^es-Q0837-answer

**es-Q0838** — Me preguntó si tenía experiencia en esa área, y le dije que no.

He asked me if I had experience in this area, and I said no.

Why: Conditions with si. [[Spanish#^es-Q0838|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Me%20pregunt%C3%B3%20si%20ten%C3%ADa%20experiencia%20en%20esa%20%C3%A1rea%2C%20y%20le%20dije%20que%20no.)
^es-Q0838-answer

**es-Q0839** — No sé si le interesa, pero traduje su artículo al francés.

I'm not sure if you're interested, but I translated your article into French.

Why: Conditions with si. [[Spanish#^es-Q0839|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20s%C3%A9%20si%20le%20interesa%2C%20pero%20traduje%20su%20art%C3%ADculo%20al%20franc%C3%A9s.)
^es-Q0839-answer

**es-Q0840** — No sé si le interesa, pero traduje su artículo al francés.

I'm not sure if you're interested, but I translated your article into French.

Si has no accent when it means if or whether; sí means yes or emphatic affirmation. A real condition often uses present; an unreal one often uses imperfect subjunctive.

Why: Conditions with si. [[Spanish#^es-Q0840|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20s%C3%A9%20si%20le%20interesa%2C%20pero%20traduje%20su%20art%C3%ADculo%20al%20franc%C3%A9s.)
^es-Q0840-answer

**es-Q0841** — Si tú quieres ir, iremos.

If you want to go, we'll go.

Expected form: **Si**

Why: Conditions with si. [[Spanish#^es-Q0841|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Si%20t%C3%BA%20quieres%20ir%2C%20iremos.)
^es-Q0841-answer

**es-Q0842** — Si tú quieres ir, iremos.

If you want to go, we'll go.

Expected form: **Si**

Why: Conditions with si. [[Spanish#^es-Q0842|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Si%20t%C3%BA%20quieres%20ir%2C%20iremos.)
^es-Q0842-answer

**es-Q0843** — No sé si he respondido a tu pregunta.

I don't know if I've answered your question.

Expected form: **si**

Why: Conditions with si. [[Spanish#^es-Q0843|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20s%C3%A9%20si%20he%20respondido%20a%20tu%20pregunta.)
^es-Q0843-answer

**es-Q0844** — No sé si he respondido a tu pregunta.

I don't know if I've answered your question.

Why: Conditions with si. [[Spanish#^es-Q0844|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20s%C3%A9%20si%20he%20respondido%20a%20tu%20pregunta.)
^es-Q0844-answer

**es-Q0845** — Si alguien te critica, es porque tu tienes algo que él nunca tendrá.

If someone criticize you, it's because you have something that he will never have.

Why: Conditions with si. [[Spanish#^es-Q0845|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Si%20alguien%20te%20critica%2C%20es%20porque%20tu%20tienes%20algo%20que%20%C3%A9l%20nunca%20tendr%C3%A1.)
^es-Q0845-answer

**es-Q0846** — Si alguien te critica, es porque tu tienes algo que él nunca tendrá.

If someone criticize you, it's because you have something that he will never have.

Si has no accent when it means if or whether; sí means yes or emphatic affirmation. A real condition often uses present; an unreal one often uses imperfect subjunctive.

Why: Conditions with si. [[Spanish#^es-Q0846|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Si%20alguien%20te%20critica%2C%20es%20porque%20tu%20tienes%20algo%20que%20%C3%A9l%20nunca%20tendr%C3%A1.)
^es-Q0846-answer

**es-Q0847** — Si querés, puedo volver.

If you want, I can come back.

Expected form: **Si**

Why: Conditions with si. [[Spanish#^es-Q0847|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Si%20quer%C3%A9s%2C%20puedo%20volver.)
^es-Q0847-answer

**es-Q0848** — Si querés, puedo volver.

If you want, I can come back.

Expected form: **Si**

Why: Conditions with si. [[Spanish#^es-Q0848|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Si%20quer%C3%A9s%2C%20puedo%20volver.)
^es-Q0848-answer

**es-Q0849** — Si el medicamento no surte efecto, quizá deberíamos aumentar la dosis.

If the medicine isn't working, maybe we should up the dosage.

Expected form: **Si**

Why: Conditions with si. [[Spanish#^es-Q0849|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Si%20el%20medicamento%20no%20surte%20efecto%2C%20quiz%C3%A1%20deber%C3%ADamos%20aumentar%20la%20dosis.)
^es-Q0849-answer

**es-Q0850** — Si el medicamento no surte efecto, quizá deberíamos aumentar la dosis.

If the medicine isn't working, maybe we should up the dosage.

Why: Conditions with si. [[Spanish#^es-Q0850|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Si%20el%20medicamento%20no%20surte%20efecto%2C%20quiz%C3%A1%20deber%C3%ADamos%20aumentar%20la%20dosis.)
^es-Q0850-answer


### Answers 851–900

**es-Q0851** — A la gente no le gusta trabajar con Tom porque es difícil llevarse bien con él.

People don't like working with Tom because he's hard to get along with.

Why: Cause and concession. [[Spanish#^es-Q0851|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=A%20la%20gente%20no%20le%20gusta%20trabajar%20con%20Tom%20porque%20es%20dif%C3%ADcil%20llevarse%20bien%20con%20%C3%A9l.)
^es-Q0851-answer

**es-Q0852** — A la gente no le gusta trabajar con Tom porque es difícil llevarse bien con él.

People don't like working with Tom because he's hard to get along with.

Porque supplies a reason; aunque introduces concession; por eso supplies a consequence. Aunque can take indicative or subjunctive according to how its content is presented.

Why: Cause and concession. [[Spanish#^es-Q0852|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=A%20la%20gente%20no%20le%20gusta%20trabajar%20con%20Tom%20porque%20es%20dif%C3%ADcil%20llevarse%20bien%20con%20%C3%A9l.)
^es-Q0852-answer

**es-Q0853** — Ya que estamos todos de acuerdo, empecemos la reunión.

Now we all agree, let's start the meeting.

Expected form: **Ya que**

Why: Cause and concession. [[Spanish#^es-Q0853|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Ya%20que%20estamos%20todos%20de%20acuerdo%2C%20empecemos%20la%20reuni%C3%B3n.)
^es-Q0853-answer

**es-Q0854** — Ya que estamos todos de acuerdo, empecemos la reunión.

Now we all agree, let's start the meeting.

Expected form: **Ya que**

Why: Cause and concession. [[Spanish#^es-Q0854|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Ya%20que%20estamos%20todos%20de%20acuerdo%2C%20empecemos%20la%20reuni%C3%B3n.)
^es-Q0854-answer

**es-Q0855** — No te tienes que sentir mal por eso.

You don't have to feel bad for that.

Expected form: **por eso**

Why: Cause and concession. [[Spanish#^es-Q0855|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20te%20tienes%20que%20sentir%20mal%20por%20eso.)
^es-Q0855-answer

**es-Q0856** — No te tienes que sentir mal por eso.

You don't have to feel bad for that.

Why: Cause and concession. [[Spanish#^es-Q0856|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20te%20tienes%20que%20sentir%20mal%20por%20eso.)
^es-Q0856-answer

**es-Q0857** — Es por eso que él se enojó.

That's why he got angry.

Why: Cause and concession. [[Spanish#^es-Q0857|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Es%20por%20eso%20que%20%C3%A9l%20se%20enoj%C3%B3.)
^es-Q0857-answer

**es-Q0858** — Es por eso que él se enojó.

That's why he got angry.

Porque supplies a reason; aunque introduces concession; por eso supplies a consequence. Aunque can take indicative or subjunctive according to how its content is presented.

Why: Cause and concession. [[Spanish#^es-Q0858|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Es%20por%20eso%20que%20%C3%A9l%20se%20enoj%C3%B3.)
^es-Q0858-answer

**es-Q0859** — Aunque estaba ocupada, ayudé a mi madre.

I helped my mother even though I was busy.

Expected form: **Aunque**

Why: Cause and concession. [[Spanish#^es-Q0859|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Aunque%20estaba%20ocupada%2C%20ayud%C3%A9%20a%20mi%20madre.)
^es-Q0859-answer

**es-Q0860** — Aunque estaba ocupada, ayudé a mi madre.

I helped my mother even though I was busy.

Expected form: **Aunque**

Why: Cause and concession. [[Spanish#^es-Q0860|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Aunque%20estaba%20ocupada%2C%20ayud%C3%A9%20a%20mi%20madre.)
^es-Q0860-answer

**es-Q0861** — Hay que alistarse temprano porque el tren no espera.

We'd better get ready early because the train won't wait.

Expected form: **porque**

Why: Cause and concession. [[Spanish#^es-Q0861|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Hay%20que%20alistarse%20temprano%20porque%20el%20tren%20no%20espera.)
^es-Q0861-answer

**es-Q0862** — Hay que alistarse temprano porque el tren no espera.

We'd better get ready early because the train won't wait.

Why: Cause and concession. [[Spanish#^es-Q0862|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Hay%20que%20alistarse%20temprano%20porque%20el%20tren%20no%20espera.)
^es-Q0862-answer

**es-Q0863** — Me voy a dormir de inmediato porque estoy con mucho sueño.

I am going to go to sleep right away because I'm very sleepy.

Why: Cause and concession. [[Spanish#^es-Q0863|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Me%20voy%20a%20dormir%20de%20inmediato%20porque%20estoy%20con%20mucho%20sue%C3%B1o.)
^es-Q0863-answer

**es-Q0864** — Me voy a dormir de inmediato porque estoy con mucho sueño.

I am going to go to sleep right away because I'm very sleepy.

Porque supplies a reason; aunque introduces concession; por eso supplies a consequence. Aunque can take indicative or subjunctive according to how its content is presented.

Why: Cause and concession. [[Spanish#^es-Q0864|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Me%20voy%20a%20dormir%20de%20inmediato%20porque%20estoy%20con%20mucho%20sue%C3%B1o.)
^es-Q0864-answer

**es-Q0865** — Esta chica sonríe continuamente, sin embargo no es feliz.

This girl is always smiling, but she's not happy.

Expected form: **sin embargo**

Why: Cause and concession. [[Spanish#^es-Q0865|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Esta%20chica%20sonr%C3%ADe%20continuamente%2C%20sin%20embargo%20no%20es%20feliz.)
^es-Q0865-answer

**es-Q0866** — Esta chica sonríe continuamente, sin embargo no es feliz.

This girl is always smiling, but she's not happy.

Expected form: **sin embargo**

Why: Cause and concession. [[Spanish#^es-Q0866|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Esta%20chica%20sonr%C3%ADe%20continuamente%2C%20sin%20embargo%20no%20es%20feliz.)
^es-Q0866-answer

**es-Q0867** — Agradecimos a Tomás por eso.

We thanked Tom for that.

Expected form: **por eso**

Why: Cause and concession. [[Spanish#^es-Q0867|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Agradecimos%20a%20Tom%C3%A1s%20por%20eso.)
^es-Q0867-answer

**es-Q0868** — Agradecimos a Tomás por eso.

We thanked Tom for that.

Why: Cause and concession. [[Spanish#^es-Q0868|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Agradecimos%20a%20Tom%C3%A1s%20por%20eso.)
^es-Q0868-answer

**es-Q0869** — Aunque su veterinario le dijo que no, ella continuó dando de comer a su perro verduras crudas.

Even though her vet told her not to, she continued to feed her dog raw vegetables.

Why: Cause and concession. [[Spanish#^es-Q0869|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Aunque%20su%20veterinario%20le%20dijo%20que%20no%2C%20ella%20continu%C3%B3%20dando%20de%20comer%20a%20su%20perro%20verduras%20crudas.)
^es-Q0869-answer

**es-Q0870** — Aunque su veterinario le dijo que no, ella continuó dando de comer a su perro verduras crudas.

Even though her vet told her not to, she continued to feed her dog raw vegetables.

Porque supplies a reason; aunque introduces concession; por eso supplies a consequence. Aunque can take indicative or subjunctive according to how its content is presented.

Why: Cause and concession. [[Spanish#^es-Q0870|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Aunque%20su%20veterinario%20le%20dijo%20que%20no%2C%20ella%20continu%C3%B3%20dando%20de%20comer%20a%20su%20perro%20verduras%20crudas.)
^es-Q0870-answer

**es-Q0871** — Tengo que irme porque he quedado con un amigo.

I have to go off because I have an appointment with a friend.

Expected form: **porque**

Why: Cause and concession. [[Spanish#^es-Q0871|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tengo%20que%20irme%20porque%20he%20quedado%20con%20un%20amigo.)
^es-Q0871-answer

**es-Q0872** — Tengo que irme porque he quedado con un amigo.

I have to go off because I have an appointment with a friend.

Expected form: **porque**

Why: Cause and concession. [[Spanish#^es-Q0872|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tengo%20que%20irme%20porque%20he%20quedado%20con%20un%20amigo.)
^es-Q0872-answer

**es-Q0873** — Se me pegaron las sábanas porque mi alarma no sonó.

I overslept because my alarm didn't go off.

Expected form: **porque**

Why: Cause and concession. [[Spanish#^es-Q0873|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Se%20me%20pegaron%20las%20s%C3%A1banas%20porque%20mi%20alarma%20no%20son%C3%B3.)
^es-Q0873-answer

**es-Q0874** — Se me pegaron las sábanas porque mi alarma no sonó.

I overslept because my alarm didn't go off.

Why: Cause and concession. [[Spanish#^es-Q0874|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Se%20me%20pegaron%20las%20s%C3%A1banas%20porque%20mi%20alarma%20no%20son%C3%B3.)
^es-Q0874-answer

**es-Q0875** — Aunque hagas un gran esfuerzo, no serás capaz de conseguirlo.

Even if you make great efforts, you won't be able to achieve it.

Why: Cause and concession. [[Spanish#^es-Q0875|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Aunque%20hagas%20un%20gran%20esfuerzo%2C%20no%20ser%C3%A1s%20capaz%20de%20conseguirlo.)
^es-Q0875-answer

**es-Q0876** — Aunque hagas un gran esfuerzo, no serás capaz de conseguirlo.

Even if you make great efforts, you won't be able to achieve it.

Porque supplies a reason; aunque introduces concession; por eso supplies a consequence. Aunque can take indicative or subjunctive according to how its content is presented.

Why: Cause and concession. [[Spanish#^es-Q0876|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Aunque%20hagas%20un%20gran%20esfuerzo%2C%20no%20ser%C3%A1s%20capaz%20de%20conseguirlo.)
^es-Q0876-answer

**es-Q0877** — Ella abrió la ventana aunque le dije que no lo hiciera.

She opened the window, even though I told her not to.

Expected form: **aunque**

Why: Cause and concession. [[Spanish#^es-Q0877|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Ella%20abri%C3%B3%20la%20ventana%20aunque%20le%20dije%20que%20no%20lo%20hiciera.)
^es-Q0877-answer

**es-Q0878** — Ella abrió la ventana aunque le dije que no lo hiciera.

She opened the window, even though I told her not to.

Expected form: **aunque**

Why: Cause and concession. [[Spanish#^es-Q0878|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Ella%20abri%C3%B3%20la%20ventana%20aunque%20le%20dije%20que%20no%20lo%20hiciera.)
^es-Q0878-answer

**es-Q0879** — Tom se interesó por la música porque su vecino tenía harto de músico.

Tom became interested in music because his neighbor was quite a musician.

Expected form: **porque**

Why: Cause and concession. [[Spanish#^es-Q0879|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tom%20se%20interes%C3%B3%20por%20la%20m%C3%BAsica%20porque%20su%20vecino%20ten%C3%ADa%20harto%20de%20m%C3%BAsico.)
^es-Q0879-answer

**es-Q0880** — Tom se interesó por la música porque su vecino tenía harto de músico.

Tom became interested in music because his neighbor was quite a musician.

Why: Cause and concession. [[Spanish#^es-Q0880|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tom%20se%20interes%C3%B3%20por%20la%20m%C3%BAsica%20porque%20su%20vecino%20ten%C3%ADa%20harto%20de%20m%C3%BAsico.)
^es-Q0880-answer

**es-Q0881** — ¿Por eso no ayudarás a Tom?

Is that why you won't help Tom?

Why: Cause and concession. [[Spanish#^es-Q0881|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFPor%20eso%20no%20ayudar%C3%A1s%20a%20Tom%3F)
^es-Q0881-answer

**es-Q0882** — ¿Por eso no ayudarás a Tom?

Is that why you won't help Tom?

Porque supplies a reason; aunque introduces concession; por eso supplies a consequence. Aunque can take indicative or subjunctive according to how its content is presented.

Why: Cause and concession. [[Spanish#^es-Q0882|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFPor%20eso%20no%20ayudar%C3%A1s%20a%20Tom%3F)
^es-Q0882-answer

**es-Q0883** — Nosotros llamamos "Doremon" a nuestro instructor, porque él es gordo.

We call our teacher "Doraemon" because he's fat.

Expected form: **porque**

Why: Cause and concession. [[Spanish#^es-Q0883|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Nosotros%20llamamos%20%22Doremon%22%20a%20nuestro%20instructor%2C%20porque%20%C3%A9l%20es%20gordo.)
^es-Q0883-answer

**es-Q0884** — Nosotros llamamos "Doremon" a nuestro instructor, porque él es gordo.

We call our teacher "Doraemon" because he's fat.

Expected form: **porque**

Why: Cause and concession. [[Spanish#^es-Q0884|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Nosotros%20llamamos%20%22Doremon%22%20a%20nuestro%20instructor%2C%20porque%20%C3%A9l%20es%20gordo.)
^es-Q0884-answer

**es-Q0885** — Porque ningún hombre sabe hablar mi idioma.

Because no man can speak my language.

Expected form: **Porque**

Why: Cause and concession. [[Spanish#^es-Q0885|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Porque%20ning%C3%BAn%20hombre%20sabe%20hablar%20mi%20idioma.)
^es-Q0885-answer

**es-Q0886** — Porque ningún hombre sabe hablar mi idioma.

Because no man can speak my language.

Why: Cause and concession. [[Spanish#^es-Q0886|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Porque%20ning%C3%BAn%20hombre%20sabe%20hablar%20mi%20idioma.)
^es-Q0886-answer

**es-Q0887** — Ella no dijo nada de nada, sin embargo yo adiviné todo.

She said absolutely nothing, and yet I guessed it all.

Why: Cause and concession. [[Spanish#^es-Q0887|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Ella%20no%20dijo%20nada%20de%20nada%2C%20sin%20embargo%20yo%20adivin%C3%A9%20todo.)
^es-Q0887-answer

**es-Q0888** — Ella no dijo nada de nada, sin embargo yo adiviné todo.

She said absolutely nothing, and yet I guessed it all.

Porque supplies a reason; aunque introduces concession; por eso supplies a consequence. Aunque can take indicative or subjunctive according to how its content is presented.

Why: Cause and concession. [[Spanish#^es-Q0888|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Ella%20no%20dijo%20nada%20de%20nada%2C%20sin%20embargo%20yo%20adivin%C3%A9%20todo.)
^es-Q0888-answer

**es-Q0889** — No tengo ganas de irme, porque aquí estoy sentado muy cómodamente.

I don't feel like going, because I am sitting here quite comfortably.

Expected form: **porque**

Why: Cause and concession. [[Spanish#^es-Q0889|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20tengo%20ganas%20de%20irme%2C%20porque%20aqu%C3%AD%20estoy%20sentado%20muy%20c%C3%B3modamente.)
^es-Q0889-answer

**es-Q0890** — No tengo ganas de irme, porque aquí estoy sentado muy cómodamente.

I don't feel like going, because I am sitting here quite comfortably.

Expected form: **porque**

Why: Cause and concession. [[Spanish#^es-Q0890|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20tengo%20ganas%20de%20irme%2C%20porque%20aqu%C3%AD%20estoy%20sentado%20muy%20c%C3%B3modamente.)
^es-Q0890-answer

**es-Q0891** — No te iguales a tu hermano porque vale más que tú.

Don't compare yourself with your brother because he's a better man than you.

Expected form: **porque**

Why: Cause and concession. [[Spanish#^es-Q0891|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20te%20iguales%20a%20tu%20hermano%20porque%20vale%20m%C3%A1s%20que%20t%C3%BA.)
^es-Q0891-answer

**es-Q0892** — No te iguales a tu hermano porque vale más que tú.

Don't compare yourself with your brother because he's a better man than you.

Why: Cause and concession. [[Spanish#^es-Q0892|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20te%20iguales%20a%20tu%20hermano%20porque%20vale%20m%C3%A1s%20que%20t%C3%BA.)
^es-Q0892-answer

**es-Q0893** — No vayas a por flores del parterre porque te pillarán.

Don't go picking the flowers in the flower bed, or else you'll be caught.

Why: Cause and concession. [[Spanish#^es-Q0893|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20vayas%20a%20por%20flores%20del%20parterre%20porque%20te%20pillar%C3%A1n.)
^es-Q0893-answer

**es-Q0894** — No vayas a por flores del parterre porque te pillarán.

Don't go picking the flowers in the flower bed, or else you'll be caught.

Porque supplies a reason; aunque introduces concession; por eso supplies a consequence. Aunque can take indicative or subjunctive according to how its content is presented.

Why: Cause and concession. [[Spanish#^es-Q0894|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20vayas%20a%20por%20flores%20del%20parterre%20porque%20te%20pillar%C3%A1n.)
^es-Q0894-answer

**es-Q0895** — Lo de ellos es un matrimonio por conveniencia, sin embargo, funciona.

Theirs is a marriage of convenience, however, it works.

Expected form: **sin embargo**

Why: Cause and concession. [[Spanish#^es-Q0895|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Lo%20de%20ellos%20es%20un%20matrimonio%20por%20conveniencia%2C%20sin%20embargo%2C%20funciona.)
^es-Q0895-answer

**es-Q0896** — Lo de ellos es un matrimonio por conveniencia, sin embargo, funciona.

Theirs is a marriage of convenience, however, it works.

Expected form: **sin embargo**

Why: Cause and concession. [[Spanish#^es-Q0896|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Lo%20de%20ellos%20es%20un%20matrimonio%20por%20conveniencia%2C%20sin%20embargo%2C%20funciona.)
^es-Q0896-answer

**es-Q0897** — Hoy estaba cansado, por eso me fui temprano a la cama.

I was tired today so I went to bed early.

Expected form: **por eso**

Why: Cause and concession. [[Spanish#^es-Q0897|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Hoy%20estaba%20cansado%2C%20por%20eso%20me%20fui%20temprano%20a%20la%20cama.)
^es-Q0897-answer

**es-Q0898** — Hoy estaba cansado, por eso me fui temprano a la cama.

I was tired today so I went to bed early.

Why: Cause and concession. [[Spanish#^es-Q0898|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Hoy%20estaba%20cansado%2C%20por%20eso%20me%20fui%20temprano%20a%20la%20cama.)
^es-Q0898-answer

**es-Q0899** — Es por eso que vine a hablar contigo.

That's why I came to talk to you.

Why: Cause and concession. [[Spanish#^es-Q0899|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Es%20por%20eso%20que%20vine%20a%20hablar%20contigo.)
^es-Q0899-answer

**es-Q0900** — Es por eso que vine a hablar contigo.

That's why I came to talk to you.

Porque supplies a reason; aunque introduces concession; por eso supplies a consequence. Aunque can take indicative or subjunctive according to how its content is presented.

Why: Cause and concession. [[Spanish#^es-Q0900|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Es%20por%20eso%20que%20vine%20a%20hablar%20contigo.)
^es-Q0900-answer


### Answers 901–950

**es-Q0901** — Pruébalo por favor.

Please have a try.

Expected form: **por**

Why: Contractions and prepositions. [[Spanish#^es-Q0901|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Pru%C3%A9balo%20por%20favor.)
^es-Q0901-answer

**es-Q0902** — Pruébalo por favor.

Please have a try.

Expected form: **por**

Why: Contractions and prepositions. [[Spanish#^es-Q0902|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Pru%C3%A9balo%20por%20favor.)
^es-Q0902-answer

**es-Q0903** — ¿Estarías de acuerdo con eso?

Would you agree with that?

Expected form: **con**

Why: Contractions and prepositions. [[Spanish#^es-Q0903|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFEstar%C3%ADas%20de%20acuerdo%20con%20eso%3F)
^es-Q0903-answer

**es-Q0904** — ¿Estarías de acuerdo con eso?

Would you agree with that?

Why: Contractions and prepositions. [[Spanish#^es-Q0904|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFEstar%C3%ADas%20de%20acuerdo%20con%20eso%3F)
^es-Q0904-answer

**es-Q0905** — Esta tarde voy a jugar con Naoko.

I will play with Naoko this afternoon.

Why: Contractions and prepositions. [[Spanish#^es-Q0905|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Esta%20tarde%20voy%20a%20jugar%20con%20Naoko.)
^es-Q0905-answer

**es-Q0906** — Esta tarde voy a jugar con Naoko.

I will play with Naoko this afternoon.

Al contracts a + el and del contracts de + el. Por and para encode different relationships, including route/cause versus purpose/recipient in common uses. Learn contrasts in complete phrases.

Why: Contractions and prepositions. [[Spanish#^es-Q0906|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Esta%20tarde%20voy%20a%20jugar%20con%20Naoko.)
^es-Q0906-answer

**es-Q0907** — Deberías presentarte para alcalde.

You should run for mayor.

Expected form: **para**

Why: Contractions and prepositions. [[Spanish#^es-Q0907|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Deber%C3%ADas%20presentarte%20para%20alcalde.)
^es-Q0907-answer

**es-Q0908** — Deberías presentarte para alcalde.

You should run for mayor.

Expected form: **para**

Why: Contractions and prepositions. [[Spanish#^es-Q0908|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Deber%C3%ADas%20presentarte%20para%20alcalde.)
^es-Q0908-answer

**es-Q0909** — Hagámonos compañía por un rato.

Let's keep each other company for a while.

Expected form: **por**

Why: Contractions and prepositions. [[Spanish#^es-Q0909|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Hag%C3%A1monos%20compa%C3%B1%C3%ADa%20por%20un%20rato.)
^es-Q0909-answer

**es-Q0910** — Hagámonos compañía por un rato.

Let's keep each other company for a while.

Why: Contractions and prepositions. [[Spanish#^es-Q0910|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Hag%C3%A1monos%20compa%C3%B1%C3%ADa%20por%20un%20rato.)
^es-Q0910-answer

**es-Q0911** — Lo consultaré con la almohada.

I'll sleep on it.

Why: Contractions and prepositions. [[Spanish#^es-Q0911|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Lo%20consultar%C3%A9%20con%20la%20almohada.)
^es-Q0911-answer

**es-Q0912** — Lo consultaré con la almohada.

I'll sleep on it.

Al contracts a + el and del contracts de + el. Por and para encode different relationships, including route/cause versus purpose/recipient in common uses. Learn contrasts in complete phrases.

Why: Contractions and prepositions. [[Spanish#^es-Q0912|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Lo%20consultar%C3%A9%20con%20la%20almohada.)
^es-Q0912-answer

**es-Q0913** — Él prometió recompensarme por mi trabajo.

He promised to reward me for my work.

Expected form: **por**

Why: Contractions and prepositions. [[Spanish#^es-Q0913|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C3%89l%20prometi%C3%B3%20recompensarme%20por%20mi%20trabajo.)
^es-Q0913-answer

**es-Q0914** — Él prometió recompensarme por mi trabajo.

He promised to reward me for my work.

Expected form: **por**

Why: Contractions and prepositions. [[Spanish#^es-Q0914|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C3%89l%20prometi%C3%B3%20recompensarme%20por%20mi%20trabajo.)
^es-Q0914-answer

**es-Q0915** — Yo te aliento a venir y arrodillarte conmigo al pie de la Cruz del Calvario y ser lavados por la sangre de Nuestro Salvador Jesucristo.

I encourage you to come and kneel with me at the foot of Calvary's Cross and be washed in the blood of Our Savior Jesus Christ.

Expected form: **al**

Why: Contractions and prepositions. [[Spanish#^es-Q0915|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Yo%20te%20aliento%20a%20venir%20y%20arrodillarte%20conmigo%20al%20pie%20de%20la%20Cruz%20del%20Calvario%20y%20ser%20lavados%20por%20la%20sangre%20de%20Nuestro%20Salvador%20Jesucristo.)
^es-Q0915-answer

**es-Q0916** — Yo te aliento a venir y arrodillarte conmigo al pie de la Cruz del Calvario y ser lavados por la sangre de Nuestro Salvador Jesucristo.

I encourage you to come and kneel with me at the foot of Calvary's Cross and be washed in the blood of Our Savior Jesus Christ.

Why: Contractions and prepositions. [[Spanish#^es-Q0916|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Yo%20te%20aliento%20a%20venir%20y%20arrodillarte%20conmigo%20al%20pie%20de%20la%20Cruz%20del%20Calvario%20y%20ser%20lavados%20por%20la%20sangre%20de%20Nuestro%20Salvador%20Jesucristo.)
^es-Q0916-answer

**es-Q0917** — Tom trepó por encima de la cerca.

Tom climbed over the fence.

Why: Contractions and prepositions. [[Spanish#^es-Q0917|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tom%20trep%C3%B3%20por%20encima%20de%20la%20cerca.)
^es-Q0917-answer

**es-Q0918** — Tom trepó por encima de la cerca.

Tom climbed over the fence.

Al contracts a + el and del contracts de + el. Por and para encode different relationships, including route/cause versus purpose/recipient in common uses. Learn contrasts in complete phrases.

Why: Contractions and prepositions. [[Spanish#^es-Q0918|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tom%20trep%C3%B3%20por%20encima%20de%20la%20cerca.)
^es-Q0918-answer

**es-Q0919** — ¿Es para mí?

Is that for me?

Expected form: **para**

Why: Contractions and prepositions. [[Spanish#^es-Q0919|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFEs%20para%20m%C3%AD%3F)
^es-Q0919-answer

**es-Q0920** — ¿Es para mí?

Is that for me?

Expected form: **para**

Why: Contractions and prepositions. [[Spanish#^es-Q0920|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFEs%20para%20m%C3%AD%3F)
^es-Q0920-answer

**es-Q0921** — ¿Habla usted con franqueza?

Are you speaking frankly?

Expected form: **con**

Why: Contractions and prepositions. [[Spanish#^es-Q0921|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFHabla%20usted%20con%20franqueza%3F)
^es-Q0921-answer

**es-Q0922** — ¿Habla usted con franqueza?

Are you speaking frankly?

Why: Contractions and prepositions. [[Spanish#^es-Q0922|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFHabla%20usted%20con%20franqueza%3F)
^es-Q0922-answer

**es-Q0923** — Necesito cambiar dólares por pesos.

I need to exchange dollars for pesos.

Why: Contractions and prepositions. [[Spanish#^es-Q0923|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Necesito%20cambiar%20d%C3%B3lares%20por%20pesos.)
^es-Q0923-answer

**es-Q0924** — Necesito cambiar dólares por pesos.

I need to exchange dollars for pesos.

Al contracts a + el and del contracts de + el. Por and para encode different relationships, including route/cause versus purpose/recipient in common uses. Learn contrasts in complete phrases.

Why: Contractions and prepositions. [[Spanish#^es-Q0924|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Necesito%20cambiar%20d%C3%B3lares%20por%20pesos.)
^es-Q0924-answer

**es-Q0925** — Nuevamente quiero agradecerte por creerme.

I want to thank you again for believing me.

Expected form: **por**

Why: Contractions and prepositions. [[Spanish#^es-Q0925|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Nuevamente%20quiero%20agradecerte%20por%20creerme.)
^es-Q0925-answer

**es-Q0926** — Nuevamente quiero agradecerte por creerme.

I want to thank you again for believing me.

Expected form: **por**

Why: Contractions and prepositions. [[Spanish#^es-Q0926|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Nuevamente%20quiero%20agradecerte%20por%20creerme.)
^es-Q0926-answer

**es-Q0927** — Él esperaba con ansias la cita de esa noche.

He was looking forward to that evening's date.

Expected form: **con**

Why: Contractions and prepositions. [[Spanish#^es-Q0927|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C3%89l%20esperaba%20con%20ansias%20la%20cita%20de%20esa%20noche.)
^es-Q0927-answer

**es-Q0928** — Él esperaba con ansias la cita de esa noche.

He was looking forward to that evening's date.

Why: Contractions and prepositions. [[Spanish#^es-Q0928|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C3%89l%20esperaba%20con%20ansias%20la%20cita%20de%20esa%20noche.)
^es-Q0928-answer

**es-Q0929** — Gracias por explicármelo.

Thanks for explaining it to me.

Why: Contractions and prepositions. [[Spanish#^es-Q0929|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Gracias%20por%20explic%C3%A1rmelo.)
^es-Q0929-answer

**es-Q0930** — Gracias por explicármelo.

Thanks for explaining it to me.

Al contracts a + el and del contracts de + el. Por and para encode different relationships, including route/cause versus purpose/recipient in common uses. Learn contrasts in complete phrases.

Why: Contractions and prepositions. [[Spanish#^es-Q0930|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Gracias%20por%20explic%C3%A1rmelo.)
^es-Q0930-answer

**es-Q0931** — Los italianos hacen una gran comida dos veces al día.

Italians eat a big meal twice a day.

Expected form: **al**

Why: Contractions and prepositions. [[Spanish#^es-Q0931|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Los%20italianos%20hacen%20una%20gran%20comida%20dos%20veces%20al%20d%C3%ADa.)
^es-Q0931-answer

**es-Q0932** — Los italianos hacen una gran comida dos veces al día.

Italians eat a big meal twice a day.

Expected form: **al**

Why: Contractions and prepositions. [[Spanish#^es-Q0932|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Los%20italianos%20hacen%20una%20gran%20comida%20dos%20veces%20al%20d%C3%ADa.)
^es-Q0932-answer

**es-Q0933** — Sacá un vaso limpio del aparador.

Take a clean glass from the cupboard.

Expected form: **del**

Why: Contractions and prepositions. [[Spanish#^es-Q0933|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Sac%C3%A1%20un%20vaso%20limpio%20del%20aparador.)
^es-Q0933-answer

**es-Q0934** — Sacá un vaso limpio del aparador.

Take a clean glass from the cupboard.

Why: Contractions and prepositions. [[Spanish#^es-Q0934|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Sac%C3%A1%20un%20vaso%20limpio%20del%20aparador.)
^es-Q0934-answer

**es-Q0935** — Cuando te encuentres con dificultades, los amigos pueden ayudarte a sobrellevarlas.

When you encounter difficulties, friends can help you deal with them.

Why: Contractions and prepositions. [[Spanish#^es-Q0935|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Cuando%20te%20encuentres%20con%20dificultades%2C%20los%20amigos%20pueden%20ayudarte%20a%20sobrellevarlas.)
^es-Q0935-answer

**es-Q0936** — Cuando te encuentres con dificultades, los amigos pueden ayudarte a sobrellevarlas.

When you encounter difficulties, friends can help you deal with them.

Al contracts a + el and del contracts de + el. Por and para encode different relationships, including route/cause versus purpose/recipient in common uses. Learn contrasts in complete phrases.

Why: Contractions and prepositions. [[Spanish#^es-Q0936|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Cuando%20te%20encuentres%20con%20dificultades%2C%20los%20amigos%20pueden%20ayudarte%20a%20sobrellevarlas.)
^es-Q0936-answer

**es-Q0937** — Yo no sé como tratar con niños.

I don't know how to handle children.

Expected form: **con**

Why: Contractions and prepositions. [[Spanish#^es-Q0937|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Yo%20no%20s%C3%A9%20como%20tratar%20con%20ni%C3%B1os.)
^es-Q0937-answer

**es-Q0938** — Yo no sé como tratar con niños.

I don't know how to handle children.

Expected form: **con**

Why: Contractions and prepositions. [[Spanish#^es-Q0938|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Yo%20no%20s%C3%A9%20como%20tratar%20con%20ni%C3%B1os.)
^es-Q0938-answer

**es-Q0939** — Tom y Mary podrían aprender mucho el uno del otro.

Tom and Mary could learn a lot from each other.

Expected form: **del**

Why: Contractions and prepositions. [[Spanish#^es-Q0939|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tom%20y%20Mary%20podr%C3%ADan%20aprender%20mucho%20el%20uno%20del%20otro.)
^es-Q0939-answer

**es-Q0940** — Tom y Mary podrían aprender mucho el uno del otro.

Tom and Mary could learn a lot from each other.

Why: Contractions and prepositions. [[Spanish#^es-Q0940|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tom%20y%20Mary%20podr%C3%ADan%20aprender%20mucho%20el%20uno%20del%20otro.)
^es-Q0940-answer

**es-Q0941** — Todo el mundo sin excepción debe realizar la prueba.

Everybody without exception must take the test.

Why: Contractions and prepositions. [[Spanish#^es-Q0941|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Todo%20el%20mundo%20sin%20excepci%C3%B3n%20debe%20realizar%20la%20prueba.)
^es-Q0941-answer

**es-Q0942** — Todo el mundo sin excepción debe realizar la prueba.

Everybody without exception must take the test.

Al contracts a + el and del contracts de + el. Por and para encode different relationships, including route/cause versus purpose/recipient in common uses. Learn contrasts in complete phrases.

Why: Contractions and prepositions. [[Spanish#^es-Q0942|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Todo%20el%20mundo%20sin%20excepci%C3%B3n%20debe%20realizar%20la%20prueba.)
^es-Q0942-answer

**es-Q0943** — Él es rico sin duda, pero no confío en él.

He is without a doubt rich, but I don't trust him.

Expected form: **sin**

Why: Contractions and prepositions. [[Spanish#^es-Q0943|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C3%89l%20es%20rico%20sin%20duda%2C%20pero%20no%20conf%C3%ADo%20en%20%C3%A9l.)
^es-Q0943-answer

**es-Q0944** — Él es rico sin duda, pero no confío en él.

He is without a doubt rich, but I don't trust him.

Expected form: **sin**

Why: Contractions and prepositions. [[Spanish#^es-Q0944|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C3%89l%20es%20rico%20sin%20duda%2C%20pero%20no%20conf%C3%ADo%20en%20%C3%A9l.)
^es-Q0944-answer

**es-Q0945** — Es la mejor casa del pueblo.

It's the best house in town.

Expected form: **del**

Why: Contractions and prepositions. [[Spanish#^es-Q0945|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Es%20la%20mejor%20casa%20del%20pueblo.)
^es-Q0945-answer

**es-Q0946** — Es la mejor casa del pueblo.

It's the best house in town.

Why: Contractions and prepositions. [[Spanish#^es-Q0946|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Es%20la%20mejor%20casa%20del%20pueblo.)
^es-Q0946-answer

**es-Q0947** — Hable con ella.

Talk to her.

Why: Contractions and prepositions. [[Spanish#^es-Q0947|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Hable%20con%20ella.)
^es-Q0947-answer

**es-Q0948** — Hable con ella.

Talk to her.

Al contracts a + el and del contracts de + el. Por and para encode different relationships, including route/cause versus purpose/recipient in common uses. Learn contrasts in complete phrases.

Why: Contractions and prepositions. [[Spanish#^es-Q0948|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Hable%20con%20ella.)
^es-Q0948-answer

**es-Q0949** — Ella toca piano por las tardes o las noches.

She practices the piano in the afternoon or in the evening.

Expected form: **por**

Why: Contractions and prepositions. [[Spanish#^es-Q0949|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Ella%20toca%20piano%20por%20las%20tardes%20o%20las%20noches.)
^es-Q0949-answer

**es-Q0950** — Ella toca piano por las tardes o las noches.

She practices the piano in the afternoon or in the evening.

Expected form: **por**

Why: Contractions and prepositions. [[Spanish#^es-Q0950|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Ella%20toca%20piano%20por%20las%20tardes%20o%20las%20noches.)
^es-Q0950-answer


### Answers 951–1000

**es-Q0951** — Cuanto peor mejor.

The worse the better.

Expected form: **peor**

Why: Comparison. [[Spanish#^es-Q0951|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Cuanto%20peor%20mejor.)
^es-Q0951-answer

**es-Q0952** — Cuanto peor mejor.

The worse the better.

Why: Comparison. [[Spanish#^es-Q0952|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Cuanto%20peor%20mejor.)
^es-Q0952-answer

**es-Q0953** — Sé tan poco como tú.

I know as little as you do.

Why: Comparison. [[Spanish#^es-Q0953|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=S%C3%A9%20tan%20poco%20como%20t%C3%BA.)
^es-Q0953-answer

**es-Q0954** — Sé tan poco como tú.

I know as little as you do.

Más/menos ... que compare. Tan ... como compares a quality; tanto ... como compares quantity and may require agreement. Mejor and peor are common irregular comparatives.

Why: Comparison. [[Spanish#^es-Q0954|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=S%C3%A9%20tan%20poco%20como%20t%C3%BA.)
^es-Q0954-answer

**es-Q0955** — Hasta un niño chico sabe algo tan simple.

The smallest child knows such a simple thing.

Expected form: **tan**

Why: Comparison. [[Spanish#^es-Q0955|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Hasta%20un%20ni%C3%B1o%20chico%20sabe%20algo%20tan%20simple.)
^es-Q0955-answer

**es-Q0956** — Hasta un niño chico sabe algo tan simple.

The smallest child knows such a simple thing.

Expected form: **tan**

Why: Comparison. [[Spanish#^es-Q0956|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Hasta%20un%20ni%C3%B1o%20chico%20sabe%20algo%20tan%20simple.)
^es-Q0956-answer

**es-Q0957** — ¿Necesitamos más inflación?

Do we need more inflation?

Expected form: **más**

Why: Comparison. [[Spanish#^es-Q0957|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFNecesitamos%20m%C3%A1s%20inflaci%C3%B3n%3F)
^es-Q0957-answer

**es-Q0958** — ¿Necesitamos más inflación?

Do we need more inflation?

Why: Comparison. [[Spanish#^es-Q0958|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C2%BFNecesitamos%20m%C3%A1s%20inflaci%C3%B3n%3F)
^es-Q0958-answer

**es-Q0959** — Exige lo mejor.

Insist on the best.

Why: Comparison. [[Spanish#^es-Q0959|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Exige%20lo%20mejor.)
^es-Q0959-answer

**es-Q0960** — Exige lo mejor.

Insist on the best.

Más/menos ... que compare. Tan ... como compares a quality; tanto ... como compares quantity and may require agreement. Mejor and peor are common irregular comparatives.

Why: Comparison. [[Spanish#^es-Q0960|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Exige%20lo%20mejor.)
^es-Q0960-answer

**es-Q0961** — El final es mucho más interesante.

The ending is much more interesting.

Expected form: **más**

Why: Comparison. [[Spanish#^es-Q0961|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=El%20final%20es%20mucho%20m%C3%A1s%20interesante.)
^es-Q0961-answer

**es-Q0962** — El final es mucho más interesante.

The ending is much more interesting.

Expected form: **más**

Why: Comparison. [[Spanish#^es-Q0962|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=El%20final%20es%20mucho%20m%C3%A1s%20interesante.)
^es-Q0962-answer

**es-Q0963** — No la veré más.

I'll see her no more.

Expected form: **más**

Why: Comparison. [[Spanish#^es-Q0963|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20la%20ver%C3%A9%20m%C3%A1s.)
^es-Q0963-answer

**es-Q0964** — No la veré más.

I'll see her no more.

Why: Comparison. [[Spanish#^es-Q0964|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20la%20ver%C3%A9%20m%C3%A1s.)
^es-Q0964-answer

**es-Q0965** — El secreto de influenciar a la gente no recae tanto en ser un buen orador como en ser un buen oidor.

The secret of influencing people lies not so much in being a good talker as in being a good listener.

Why: Comparison. [[Spanish#^es-Q0965|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=El%20secreto%20de%20influenciar%20a%20la%20gente%20no%20recae%20tanto%20en%20ser%20un%20buen%20orador%20como%20en%20ser%20un%20buen%20oidor.)
^es-Q0965-answer

**es-Q0966** — El secreto de influenciar a la gente no recae tanto en ser un buen orador como en ser un buen oidor.

The secret of influencing people lies not so much in being a good talker as in being a good listener.

Más/menos ... que compare. Tan ... como compares a quality; tanto ... como compares quantity and may require agreement. Mejor and peor are common irregular comparatives.

Why: Comparison. [[Spanish#^es-Q0966|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=El%20secreto%20de%20influenciar%20a%20la%20gente%20no%20recae%20tanto%20en%20ser%20un%20buen%20orador%20como%20en%20ser%20un%20buen%20oidor.)
^es-Q0966-answer

**es-Q0967** — Ambos, Tom y Mary, tan sólo miran a John.

Tom and Mary both just stare at John.

Expected form: **tan**

Why: Comparison. [[Spanish#^es-Q0967|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Ambos%2C%20Tom%20y%20Mary%2C%20tan%20s%C3%B3lo%20miran%20a%20John.)
^es-Q0967-answer

**es-Q0968** — Ambos, Tom y Mary, tan sólo miran a John.

Tom and Mary both just stare at John.

Expected form: **tan**

Why: Comparison. [[Spanish#^es-Q0968|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Ambos%2C%20Tom%20y%20Mary%2C%20tan%20s%C3%B3lo%20miran%20a%20John.)
^es-Q0968-answer

**es-Q0969** — No puedo seguirlo, ¿puede dictar más despacio?

I can't keep up with you. Could you dictate a bit slower?

Expected form: **más**

Why: Comparison. [[Spanish#^es-Q0969|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20puedo%20seguirlo%2C%20%C2%BFpuede%20dictar%20m%C3%A1s%20despacio%3F)
^es-Q0969-answer

**es-Q0970** — No puedo seguirlo, ¿puede dictar más despacio?

I can't keep up with you. Could you dictate a bit slower?

Why: Comparison. [[Spanish#^es-Q0970|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=No%20puedo%20seguirlo%2C%20%C2%BFpuede%20dictar%20m%C3%A1s%20despacio%3F)
^es-Q0970-answer

**es-Q0971** — Ben no es tan joven como aparenta.

Ben's not as young as he looks.

Why: Comparison. [[Spanish#^es-Q0971|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Ben%20no%20es%20tan%20joven%20como%20aparenta.)
^es-Q0971-answer

**es-Q0972** — Ben no es tan joven como aparenta.

Ben's not as young as he looks.

Más/menos ... que compare. Tan ... como compares a quality; tanto ... como compares quantity and may require agreement. Mejor and peor are common irregular comparatives.

Why: Comparison. [[Spanish#^es-Q0972|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Ben%20no%20es%20tan%20joven%20como%20aparenta.)
^es-Q0972-answer

**es-Q0973** — Por lo tanto la física cuántica revela una unidad básica del universo.

Quantum physics thus reveals a basic oneness of the universe.

Expected form: **tanto**

Why: Comparison. [[Spanish#^es-Q0973|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Por%20lo%20tanto%20la%20f%C3%ADsica%20cu%C3%A1ntica%20revela%20una%20unidad%20b%C3%A1sica%20del%20universo.)
^es-Q0973-answer

**es-Q0974** — Por lo tanto la física cuántica revela una unidad básica del universo.

Quantum physics thus reveals a basic oneness of the universe.

Expected form: **tanto**

Why: Comparison. [[Spanish#^es-Q0974|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Por%20lo%20tanto%20la%20f%C3%ADsica%20cu%C3%A1ntica%20revela%20una%20unidad%20b%C3%A1sica%20del%20universo.)
^es-Q0974-answer

**es-Q0975** — Me parece que las patinetas en general son más baratas que los patines.

I think skateboards are usually cheaper than rollerblades.

Expected form: **más**

Why: Comparison. [[Spanish#^es-Q0975|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Me%20parece%20que%20las%20patinetas%20en%20general%20son%20m%C3%A1s%20baratas%20que%20los%20patines.)
^es-Q0975-answer

**es-Q0976** — Me parece que las patinetas en general son más baratas que los patines.

I think skateboards are usually cheaper than rollerblades.

Why: Comparison. [[Spanish#^es-Q0976|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Me%20parece%20que%20las%20patinetas%20en%20general%20son%20m%C3%A1s%20baratas%20que%20los%20patines.)
^es-Q0976-answer

**es-Q0977** — A veces, las preguntas nos proporcionan más información que las respuestas.

Sometimes, questions provide us with more information than answers.

Why: Comparison. [[Spanish#^es-Q0977|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=A%20veces%2C%20las%20preguntas%20nos%20proporcionan%20m%C3%A1s%20informaci%C3%B3n%20que%20las%20respuestas.)
^es-Q0977-answer

**es-Q0978** — A veces, las preguntas nos proporcionan más información que las respuestas.

Sometimes, questions provide us with more information than answers.

Más/menos ... que compare. Tan ... como compares a quality; tanto ... como compares quantity and may require agreement. Mejor and peor are common irregular comparatives.

Why: Comparison. [[Spanish#^es-Q0978|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=A%20veces%2C%20las%20preguntas%20nos%20proporcionan%20m%C3%A1s%20informaci%C3%B3n%20que%20las%20respuestas.)
^es-Q0978-answer

**es-Q0979** — Pienso que es poco saludable comer más de 20 naranjas en un día.

I think it's unhealthy to eat more than 20 oranges a day.

Expected form: **más**

Why: Comparison. [[Spanish#^es-Q0979|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Pienso%20que%20es%20poco%20saludable%20comer%20m%C3%A1s%20de%2020%20naranjas%20en%20un%20d%C3%ADa.)
^es-Q0979-answer

**es-Q0980** — Pienso que es poco saludable comer más de 20 naranjas en un día.

I think it's unhealthy to eat more than 20 oranges a day.

Expected form: **más**

Why: Comparison. [[Spanish#^es-Q0980|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Pienso%20que%20es%20poco%20saludable%20comer%20m%C3%A1s%20de%2020%20naranjas%20en%20un%20d%C3%ADa.)
^es-Q0980-answer

**es-Q0981** — Mi amor por ti no me deja contarte todo. Es mejor no contar algunas cosas.

My love for you won't let me tell you everything. Some things are better left unsaid.

Expected form: **mejor**

Why: Comparison. [[Spanish#^es-Q0981|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Mi%20amor%20por%20ti%20no%20me%20deja%20contarte%20todo.%20Es%20mejor%20no%20contar%20algunas%20cosas.)
^es-Q0981-answer

**es-Q0982** — Mi amor por ti no me deja contarte todo. Es mejor no contar algunas cosas.

My love for you won't let me tell you everything. Some things are better left unsaid.

Why: Comparison. [[Spanish#^es-Q0982|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Mi%20amor%20por%20ti%20no%20me%20deja%20contarte%20todo.%20Es%20mejor%20no%20contar%20algunas%20cosas.)
^es-Q0982-answer

**es-Q0983** — Quizá más tarde.

Maybe later.

Why: Comparison. [[Spanish#^es-Q0983|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Quiz%C3%A1%20m%C3%A1s%20tarde.)
^es-Q0983-answer

**es-Q0984** — Quizá más tarde.

Maybe later.

Más/menos ... que compare. Tan ... como compares a quality; tanto ... como compares quantity and may require agreement. Mejor and peor are common irregular comparatives.

Why: Comparison. [[Spanish#^es-Q0984|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Quiz%C3%A1%20m%C3%A1s%20tarde.)
^es-Q0984-answer

**es-Q0985** — Fumar te hace más daño que bien.

Smoking does you more harm than good.

Expected form: **más**

Why: Comparison. [[Spanish#^es-Q0985|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Fumar%20te%20hace%20m%C3%A1s%20da%C3%B1o%20que%20bien.)
^es-Q0985-answer

**es-Q0986** — Fumar te hace más daño que bien.

Smoking does you more harm than good.

Expected form: **más**

Why: Comparison. [[Spanish#^es-Q0986|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Fumar%20te%20hace%20m%C3%A1s%20da%C3%B1o%20que%20bien.)
^es-Q0986-answer

**es-Q0987** — Tom tiene más corazón que cabeza.

Tom has more heart than brains.

Expected form: **más**

Why: Comparison. [[Spanish#^es-Q0987|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tom%20tiene%20m%C3%A1s%20coraz%C3%B3n%20que%20cabeza.)
^es-Q0987-answer

**es-Q0988** — Tom tiene más corazón que cabeza.

Tom has more heart than brains.

Why: Comparison. [[Spanish#^es-Q0988|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Tom%20tiene%20m%C3%A1s%20coraz%C3%B3n%20que%20cabeza.)
^es-Q0988-answer

**es-Q0989** — La Gran Muralla China tiene más de 5,500 millas de largo.

The Great Wall of China is more than 5,500 miles long.

Why: Comparison. [[Spanish#^es-Q0989|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=La%20Gran%20Muralla%20China%20tiene%20m%C3%A1s%20de%205%2C500%20millas%20de%20largo.)
^es-Q0989-answer

**es-Q0990** — La Gran Muralla China tiene más de 5,500 millas de largo.

The Great Wall of China is more than 5,500 miles long.

Más/menos ... que compare. Tan ... como compares a quality; tanto ... como compares quantity and may require agreement. Mejor and peor are common irregular comparatives.

Why: Comparison. [[Spanish#^es-Q0990|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=La%20Gran%20Muralla%20China%20tiene%20m%C3%A1s%20de%205%2C500%20millas%20de%20largo.)
^es-Q0990-answer

**es-Q0991** — Mi mejor amigo está en Roma en este momento.

My best friend is in Rome now.

Expected form: **mejor**

Why: Comparison. [[Spanish#^es-Q0991|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Mi%20mejor%20amigo%20est%C3%A1%20en%20Roma%20en%20este%20momento.)
^es-Q0991-answer

**es-Q0992** — Mi mejor amigo está en Roma en este momento.

My best friend is in Rome now.

Expected form: **mejor**

Why: Comparison. [[Spanish#^es-Q0992|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Mi%20mejor%20amigo%20est%C3%A1%20en%20Roma%20en%20este%20momento.)
^es-Q0992-answer

**es-Q0993** — El viejo método probó ser mejor después de todo.

The old method proved to be best after all.

Expected form: **mejor**

Why: Comparison. [[Spanish#^es-Q0993|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=El%20viejo%20m%C3%A9todo%20prob%C3%B3%20ser%20mejor%20despu%C3%A9s%20de%20todo.)
^es-Q0993-answer

**es-Q0994** — El viejo método probó ser mejor después de todo.

The old method proved to be best after all.

Why: Comparison. [[Spanish#^es-Q0994|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=El%20viejo%20m%C3%A9todo%20prob%C3%B3%20ser%20mejor%20despu%C3%A9s%20de%20todo.)
^es-Q0994-answer

**es-Q0995** — Se volverá más y más difícil vivir en la villa.

It will become more and more difficult to live in the village.

Why: Comparison. [[Spanish#^es-Q0995|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Se%20volver%C3%A1%20m%C3%A1s%20y%20m%C3%A1s%20dif%C3%ADcil%20vivir%20en%20la%20villa.)
^es-Q0995-answer

**es-Q0996** — Se volverá más y más difícil vivir en la villa.

It will become more and more difficult to live in the village.

Más/menos ... que compare. Tan ... como compares a quality; tanto ... como compares quantity and may require agreement. Mejor and peor are common irregular comparatives.

Why: Comparison. [[Spanish#^es-Q0996|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=Se%20volver%C3%A1%20m%C3%A1s%20y%20m%C3%A1s%20dif%C3%ADcil%20vivir%20en%20la%20villa.)
^es-Q0996-answer

**es-Q0997** — La montaña más alta del mundo es el monte Everest.

The tallest mountain in the world is Mount Everest.

Expected form: **más**

Why: Comparison. [[Spanish#^es-Q0997|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=La%20monta%C3%B1a%20m%C3%A1s%20alta%20del%20mundo%20es%20el%20monte%20Everest.)
^es-Q0997-answer

**es-Q0998** — La montaña más alta del mundo es el monte Everest.

The tallest mountain in the world is Mount Everest.

Expected form: **más**

Why: Comparison. [[Spanish#^es-Q0998|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=La%20monta%C3%B1a%20m%C3%A1s%20alta%20del%20mundo%20es%20el%20monte%20Everest.)
^es-Q0998-answer

**es-Q0999** — Él no es tan activo como solía ser.

He is not the active person he used to be.

Expected form: **tan**

Why: Comparison. [[Spanish#^es-Q0999|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C3%89l%20no%20es%20tan%20activo%20como%20sol%C3%ADa%20ser.)
^es-Q0999-answer

**es-Q1000** — Él no es tan activo como solía ser.

He is not the active person he used to be.

Why: Comparison. [[Spanish#^es-Q1000|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=spa&query=%C3%89l%20no%20es%20tan%20activo%20como%20sol%C3%ADa%20ser.)
^es-Q1000-answer


## Read and speak

Read the native sentence first, identify its predicate and one grammar form, then check the translation. Say it aloud and change one detail.

### Learning with a clear purpose

Estoy aprendiendo un idioma nuevo. Cada día leo un texto corto y escucho ejemplos claros. Escribo palabras útiles en un cuaderno. Cuando cometo un error, reviso la regla y lo intento de nuevo. Mi objetivo es comprender a las personas y expresar mis ideas con claridad.

I am learning a new language. Each day, I read a short text and listen to clear examples. I write useful words in a notebook. When I make a mistake, I check the rule and try again. My goal is to understand people and express my ideas clearly.

### Art: interpretation and context

Una obra puede admitir varias interpretaciones sin que todas estén igualmente justificadas. El lector o espectador debe prestar atención a los detalles de la obra, a su contexto y a las razones que ofrece cada interpretación. La intención del creador puede ser relevante, pero no siempre resuelve todas las preguntas. También importa distinguir una reacción personal de una afirmación sobre lo que la obra expresa. Una discusión cuidadosa permite comparar lecturas diferentes sin reducirlas a una sola respuesta ni aceptar cualquier explicación sin argumentos.

A work can support several interpretations without all being equally justified. The reader or viewer should consider details, context and reasons. The creator's intention may matter without resolving every question. A personal reaction differs from a claim about what the work expresses. Careful discussion compares interpretations without forcing one answer or accepting unsupported explanations.

![[Resources/Audio/es/Reading passage.mp3]]

**No han igualado la carretera.**

The road hasn't been leveled.

**Cuanto peor mejor.**

The worse the better.

**Esa clase de cosas no puede encontrarse en cualquier parte.**

That kind of thing can't be found just anywhere.

**Tom le dijo a Mary lo que había pasado.**

Tom told Mary what had happened.

**Tom siempre dice eso.**

Tom always says that.

**Yo tengo un anillo.**

I have a ring.

**Tom no le creyó a Mary.**

Tom didn't believe Mary.

**Ha de haber alguna razón por lo que ha hecho.**

There must be some reason for what he has done.

**Hay un ratón en la despensa.**

There's a mouse in the pantry.

**¿Por qué estabas enfadado conmigo?**

Why were you angry with me?

**Ken juega fútbol todos los días.**

Ken plays soccer every day.

**Ella estaba profundamente emocionada.**

She was deeply moved.

**¿Qué quieres decir con relativismo cultural?**

What do you mean by cultural relativism?

**Una multitud esperaba verlo.**

A crowd waited to see him.

**Él me dio todo pero no aceptó nada a cambio.**

He gave me everything but took nothing in return.

## Professional writing

Write an introduction, a polite request, an explanation of a finding, a summary of a passage and a tactful disagreement. Use the professional/advanced lessons for models.

## PDF edition

[[Resources/PDFs/Spanish.pdf|Open the complete printable book]]
